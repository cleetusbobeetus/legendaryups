execute if score #particles dp_cfg matches 1.. run particle minecraft:happy_villager ~ ~1 ~ 1 1 1 0.1 25 force
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.8 1.3
