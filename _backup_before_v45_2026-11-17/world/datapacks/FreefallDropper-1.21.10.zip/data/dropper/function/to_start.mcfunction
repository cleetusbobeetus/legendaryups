function dropper:tp/n50_103
scoreboard players set @s dp_grace 6
scoreboard players set @s dp_wait 0
function dropper:hz/sync
execute if score @s dp_snd matches 1.. at @s run function dropper:entrance_sfx
scoreboard players set @s dp_snd 0
