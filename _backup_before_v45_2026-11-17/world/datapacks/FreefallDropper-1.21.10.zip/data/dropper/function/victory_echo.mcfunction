execute as @a[tag=dp_play] at @s run particle minecraft:firework ~ ~1 ~ 3 3 3 0.3 80 force
execute as @a[tag=dp_play] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 1 1.2
