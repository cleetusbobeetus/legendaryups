scoreboard players operation #hardcore dp_cfg = #hc_saved dp_ev
scoreboard players set #hc_temp dp_ev 0
