$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
execute if score #evnotify dp_ev matches 1 run scoreboard players set @a[tag=dp_play,tag=!dp_no_none] dp_notek 100
execute if score #evnotify dp_ev matches 1 as @a[tag=dp_play,tag=!dp_no_none] run function dropper:hud/notify
