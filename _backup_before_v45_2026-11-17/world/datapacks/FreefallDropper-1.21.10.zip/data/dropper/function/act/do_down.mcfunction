scoreboard players operation @s dp_plevel = @s dp_level
scoreboard players set @s dp_dir -1
scoreboard players operation @s dp_level -= #arg_n dp_ev
execute if score #cpmode dp_cfg matches 2 run function dropper:progress/floor
execute if score #cpmode dp_cfg matches 2 run scoreboard players operation @s dp_level > @s dp_floor
function dropper:move/apply
