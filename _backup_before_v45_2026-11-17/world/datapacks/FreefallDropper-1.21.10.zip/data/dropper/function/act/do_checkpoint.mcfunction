scoreboard players operation @s dp_plevel = @s dp_level
function dropper:progress/stage_floor
execute if score @s dp_cp = @s dp_cp run scoreboard players operation @s dp_floor = @s dp_cp
scoreboard players operation @s dp_level = @s dp_floor
scoreboard players set @s dp_dir -1
function dropper:move/apply
