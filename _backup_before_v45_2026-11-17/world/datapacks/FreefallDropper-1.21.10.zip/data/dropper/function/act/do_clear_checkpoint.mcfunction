scoreboard players reset @s dp_cp
