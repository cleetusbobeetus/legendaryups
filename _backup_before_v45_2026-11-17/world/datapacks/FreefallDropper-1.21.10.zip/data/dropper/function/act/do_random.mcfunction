scoreboard players operation @s dp_plevel = @s dp_level
scoreboard players set @s dp_dir 1
function dropper:progress/random_next
function dropper:progress/cap_final
function dropper:move/apply
