scoreboard players operation @s dp_plevel = @s dp_level
execute if score #negative dp_cfg matches 0 run return 0
scoreboard players set @s dp_dir -1
scoreboard players set @s dp_level 0
scoreboard players operation @s dp_level -= #arg_n dp_ev
function dropper:move/apply
