execute as @a[tag=dp_play] run function dropper:set_gravity
