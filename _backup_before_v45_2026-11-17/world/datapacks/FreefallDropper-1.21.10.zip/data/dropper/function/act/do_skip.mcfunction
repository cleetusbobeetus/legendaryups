function dropper:finish
