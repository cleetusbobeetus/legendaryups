$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
execute if score #allowskip dp_cfg matches 0 run return 0
execute as @a[tag=dp_play,tag=!dp_no_random] at @s run function dropper:act/do_random
execute if score #evnotify dp_ev matches 1 run scoreboard players set @a[tag=dp_play,tag=!dp_no_random] dp_notek 109
execute if score #evnotify dp_ev matches 1 as @a[tag=dp_play,tag=!dp_no_random] run function dropper:hud/notify
