$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
execute as @a[tag=dp_play,tag=!dp_no_abyss] at @s run function dropper:act/do_abyss
execute if score #evnotify dp_ev matches 1 run scoreboard players set @a[tag=dp_play,tag=!dp_no_abyss] dp_notek 104
execute if score #evnotify dp_ev matches 1 as @a[tag=dp_play,tag=!dp_no_abyss] run function dropper:hud/notify
