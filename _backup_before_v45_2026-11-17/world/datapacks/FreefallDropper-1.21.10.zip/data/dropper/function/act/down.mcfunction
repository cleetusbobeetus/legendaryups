$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
execute as @a[tag=dp_play,tag=!dp_no_down] at @s run function dropper:act/do_down
execute if score #evnotify dp_ev matches 1 run scoreboard players set @a[tag=dp_play,tag=!dp_no_down] dp_notek 102
execute if score #evnotify dp_ev matches 1 as @a[tag=dp_play,tag=!dp_no_down] run function dropper:hud/notify
