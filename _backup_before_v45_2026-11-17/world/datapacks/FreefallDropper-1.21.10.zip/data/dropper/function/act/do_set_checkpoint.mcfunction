scoreboard players operation @s dp_cp = @s dp_level
