$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
$effect give @a[tag=dp_play] minecraft:nausea $(dur) 0 true
execute if score #evnotify dp_ev matches 1 run scoreboard players set @a[tag=dp_play,tag=!dp_no_nausea] dp_notek 116
execute if score #evnotify dp_ev matches 1 as @a[tag=dp_play,tag=!dp_no_nausea] run function dropper:hud/notify
