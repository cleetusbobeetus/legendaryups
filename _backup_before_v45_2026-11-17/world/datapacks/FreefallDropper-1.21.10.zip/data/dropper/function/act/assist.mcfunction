$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
$effect give @a[tag=dp_play] minecraft:slow_falling $(dur) 0 true
effect give @a[tag=dp_play] minecraft:night_vision 30 0 true
execute if score #evnotify dp_ev matches 1 run scoreboard players set @a[tag=dp_play,tag=!dp_no_assist] dp_notek 120
execute if score #evnotify dp_ev matches 1 as @a[tag=dp_play,tag=!dp_no_assist] run function dropper:hud/notify
