$scoreboard players set #arg_n dp_ev $(n)
$scoreboard players set #arg_dur dp_ev $(dur)
$effect give @a[tag=dp_play] minecraft:darkness $(dur) 0 true
execute if score #evnotify dp_ev matches 1 run scoreboard players set @a[tag=dp_play,tag=!dp_no_darkness] dp_notek 117
execute if score #evnotify dp_ev matches 1 as @a[tag=dp_play,tag=!dp_no_darkness] run function dropper:hud/notify
