scoreboard players operation @s dp_plevel = @s dp_level
execute if score @s dp_level matches 100.. run return 0
scoreboard players set @s dp_tmp 100
execute if score @s dp_level matches 76..100 run scoreboard players set @s dp_tmp 100
execute if score @s dp_level matches 51..75 run scoreboard players set @s dp_tmp 75
execute if score @s dp_level matches 26..50 run scoreboard players set @s dp_tmp 50
execute if score @s dp_level matches -50..25 run scoreboard players set @s dp_tmp 25
scoreboard players operation @s dp_level = @s dp_tmp
scoreboard players set @s dp_dir 1
function dropper:move/apply
