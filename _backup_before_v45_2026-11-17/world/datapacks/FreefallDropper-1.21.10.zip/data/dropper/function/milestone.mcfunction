execute if score #particles dp_cfg matches 1.. run particle minecraft:firework ~ ~1 ~ 1.5 1.5 1.5 0.15 30 force
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.7 0.8
tellraw @a [{"selector":"@s","color":"gold"},{"text":" reached a new milestone: LEVEL ","color":"yellow"},{"score":{"name":"@s","objective":"dp_level"},"color":"gold","bold":true}]
