tellraw @a {"text":"[Freefall] Build finished! Players run /function dropper:start","color":"green"}
