execute unless entity @s[tag=dp_test] run scoreboard players add @s dp_wins 1
scoreboard players set #vic dp_ev 1
scoreboard players set @s dp_notek 7
function dropper:hud/notify
scoreboard players operation @s dp_note += #notifyticks dp_cfg
execute if score #milestones dp_cfg matches 1 run title @s times 5 50 15
execute if score #milestones dp_cfg matches 1 run title @s title {"text":"REALITY CONQUERED!","color":"gold","bold":true}
execute if score #milestones dp_cfg matches 1 run title @s subtitle {"text":"Infinite Dropper beaten - all 100 levels","color":"yellow"}
tellraw @a [{"text":"*** ","color":"gold"},{"selector":"@s","color":"gold","bold":true},{"text":" DEFEATED THE END OF REALITY! Level 100 (all 4 stages) beaten with ","color":"yellow"},{"score":{"name":"@s","objective":"dp_fails"},"color":"red"},{"text":" fails  (wins: ","color":"yellow"},{"score":{"name":"@s","objective":"dp_wins"},"color":"aqua"},{"text":") ***","color":"gold"}]
scoreboard players operation @s dp_secs = @s dp_time
scoreboard players operation @s dp_secs /= #twenty dp_cfg
execute if score #speedrun dp_cfg matches 1 run tellraw @a [{"text":"    speedrun time: ","color":"gray"},{"score":{"name":"@s","objective":"dp_secs"},"color":"aqua"},{"text":" s","color":"aqua"}]
schedule function dropper:victory_echo 20t
