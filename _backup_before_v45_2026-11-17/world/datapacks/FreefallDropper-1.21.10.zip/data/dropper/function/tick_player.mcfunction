execute if score #speedrun dp_cfg matches 1 run scoreboard players add @s dp_time 1
execute if score @s dp_note matches 1.. run scoreboard players remove @s dp_note 1
execute if score @s dp_note matches 0 if score @s dp_noten matches 1.. run function dropper:hud/note_next
scoreboard players remove @s dp_hudt 1
execute if score @s dp_hudt matches ..0 run function dropper:hud/render
execute if score @s dp_wait matches 1.. run scoreboard players remove @s dp_wait 1
execute if score @s dp_wait matches 0 if entity @s[tag=dp_wait] run function dropper:wait_done
execute if score @s dp_wait matches 1.. run return run tag @s add dp_wait
execute if entity @s[tag=dp_plat] run return run function dropper:platform/tick
execute if score @s dp_grace matches 1.. run return run scoreboard players remove @s dp_grace 1
execute if block ~ ~ ~ minecraft:water if block ~ ~-1 ~ minecraft:lime_concrete run return run function dropper:finish
execute if entity @s[tag=dp_god] run return 0
execute if entity @s[nbt={OnGround:1b}] run return run function dropper:fail
