playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
playsound minecraft:entity.firework_rocket.launch master @s ~ ~ ~ 1 1
playsound minecraft:entity.firework_rocket.large_blast master @s ~ ~ ~ 1 0.8
playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 1 1
particle minecraft:totem_of_undying ~ ~1 ~ 2 2 2 0.6 200 force
particle minecraft:firework ~ ~1 ~ 3 3 3 0.3 150 force
