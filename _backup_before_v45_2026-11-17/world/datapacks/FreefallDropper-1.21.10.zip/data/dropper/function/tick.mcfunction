execute as @a[tag=dp_play] at @s run function dropper:tick_player
execute as @a[tag=dp_play,scores={dp_deaths=1..}] run function dropper:on_death
execute as @a[tag=!dp_play,scores={dp_deaths=1..}] run scoreboard players reset @s dp_deaths
execute as @a[tag=!dp_play] run attribute @s minecraft:gravity base set 0.08
scoreboard players add #evtick dp_ev 1
function dropper:chat/tick
execute if score #evtick dp_ev matches 20.. run function dropper:chat/second
execute if score #evtick dp_ev matches 20.. run function dropper:event/second
execute if score #hazards dp_cfg matches 1 run function dropper:hz/tick
