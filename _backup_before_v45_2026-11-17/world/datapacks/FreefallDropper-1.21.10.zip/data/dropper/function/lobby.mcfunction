tag @s remove dp_play
effect clear @s
attribute @s minecraft:gravity base set 0.08
attribute @s minecraft:fall_damage_multiplier base set 1
tp @s -21 200 20 0 0
