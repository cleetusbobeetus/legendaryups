execute if score @s dp_streak matches 5 run scoreboard players set #q dp_ev 30
execute if score @s dp_streak matches 5 run data modify storage dropper:ev smsg set from storage dropper:msgs s5
execute if score @s dp_streak matches 10 run scoreboard players set #q dp_ev 30
execute if score @s dp_streak matches 10 run data modify storage dropper:ev smsg set from storage dropper:msgs s10
execute if score @s dp_streak matches 25 run scoreboard players set #q dp_ev 30
execute if score @s dp_streak matches 25 run data modify storage dropper:ev smsg set from storage dropper:msgs s25
execute if score @s dp_streak matches 50 run scoreboard players set #q dp_ev 30
execute if score @s dp_streak matches 50 run data modify storage dropper:ev smsg set from storage dropper:msgs s50
execute if score #q dp_ev matches 30 run function dropper:hud/queue
