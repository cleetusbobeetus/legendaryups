scoreboard players operation #oldbest dp_ev = @s dp_best
scoreboard players operation @s dp_best = @s dp_level
execute if entity @s[tag=dp_below] run scoreboard players set #q dp_ev 31
execute if entity @s[tag=dp_below] run function dropper:hud/queue
tag @s remove dp_below
execute if score @s dp_level matches 10 if score #milestonefx dp_cfg matches 1 run function dropper:milestone
execute if score @s dp_level matches 25 if score #milestonefx dp_cfg matches 1 run function dropper:milestone
execute if score @s dp_level matches 50 if score #milestonefx dp_cfg matches 1 run function dropper:milestone
execute if score @s dp_level matches 75 if score #milestonefx dp_cfg matches 1 run function dropper:milestone
execute if score @s dp_level matches 90 if score #milestonefx dp_cfg matches 1 run function dropper:milestone
execute if score @s dp_level matches 100 if score #milestonefx dp_cfg matches 1 run function dropper:milestone
