function dropper:hud/queue_intro
