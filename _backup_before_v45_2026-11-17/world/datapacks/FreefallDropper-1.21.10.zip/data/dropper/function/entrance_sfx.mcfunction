execute if score @s dp_snd matches 1 run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.6 1
execute if score @s dp_snd matches 2 run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.7 1
execute if score @s dp_snd matches 3 run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 1 0.8
execute if score @s dp_snd matches 4 run playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.8 0.6
execute if score @s dp_snd matches 4 run playsound minecraft:entity.iron_golem.repair master @s ~ ~ ~ 1 0.5
execute if score @s dp_snd matches 5 run playsound minecraft:entity.lightning_bolt.thunder master @s ~ ~ ~ 0.8 1
execute if score @s dp_snd matches 6 run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.7 1
execute if score @s dp_snd matches 3.. if score #particles dp_cfg matches 1.. run particle minecraft:soul_fire_flame ~ ~1 ~ 2 2 2 0.05 60 force
execute if score @s dp_snd matches 6 if score #particles dp_cfg matches 1.. run particle minecraft:reverse_portal ~ ~1 ~ 3 2 3 0.5 150 force
