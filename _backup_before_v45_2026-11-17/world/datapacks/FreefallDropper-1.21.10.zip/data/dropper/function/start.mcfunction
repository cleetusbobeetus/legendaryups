tag @s add dp_play
execute unless score @s dp_level matches -50..103 run scoreboard players operation @s dp_level = #startlevel dp_cfg
execute unless score @s dp_fails matches 0.. run scoreboard players set @s dp_fails 0
execute unless score @s dp_time matches 0.. run scoreboard players set @s dp_time 0
gamemode adventure @s
effect give @s minecraft:resistance infinite 4 true
effect give @s minecraft:saturation infinite 0 true
attribute @s minecraft:fall_damage_multiplier base set 0
scoreboard players set @s dp_plevel -999
scoreboard players set @s dp_note 0
scoreboard players set @s dp_noten 0
scoreboard players set @s dp_dir 1
function dropper:move/apply
