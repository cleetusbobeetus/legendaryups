scoreboard players reset @s dp_deaths
execute if score #practice dp_cfg matches 0 run scoreboard players add @s dp_fails 1
function dropper:to_start
