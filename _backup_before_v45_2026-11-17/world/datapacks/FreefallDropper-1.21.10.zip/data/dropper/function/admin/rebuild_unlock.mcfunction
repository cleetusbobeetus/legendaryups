scoreboard players set #rbrel dp_ev 0
tellraw @s {"text":"[Freefall] Rebuild lock cleared (only needed if the server stopped during a release rebuild).","color":"yellow"}
