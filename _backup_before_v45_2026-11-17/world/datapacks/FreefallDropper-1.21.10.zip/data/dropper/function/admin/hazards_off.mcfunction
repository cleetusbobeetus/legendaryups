scoreboard players set #hazards dp_cfg 0
function dropper:config/apply
