$scoreboard players set #hzslow dp_cfg $(div)
function dropper:config/apply
tellraw @s {"text":"[Test] hazards slowed (1 = normal). Safe windows are only proven at 1 - set it back before playing for real.","color":"yellow"}
