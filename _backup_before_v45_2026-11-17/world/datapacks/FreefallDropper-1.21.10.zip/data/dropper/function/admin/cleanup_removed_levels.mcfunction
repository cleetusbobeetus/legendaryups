tellraw @s {"text":"[Freefall] Clearing the rooms of removed levels 104-400 (about 6 minutes, nothing else is touched)...","color":"yellow"}
function dropper:cleanup/c104
