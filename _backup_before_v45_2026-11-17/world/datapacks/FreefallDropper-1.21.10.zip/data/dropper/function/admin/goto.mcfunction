function dropper:admin/test_begin
$scoreboard players set @s dp_level $(level)
execute if score @s dp_level matches 101.. run scoreboard players set @s dp_level 100
execute if score @s dp_level matches ..-51 run scoreboard players set @s dp_level -50
scoreboard players operation @s dp_plevel = @s dp_level
scoreboard players remove @s dp_plevel 1
function dropper:move/apply
