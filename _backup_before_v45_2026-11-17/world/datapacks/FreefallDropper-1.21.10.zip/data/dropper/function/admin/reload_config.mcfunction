function dropper:config/defaults
function dropper:config/event_defaults
function #dropper:user_settings
function dropper:config/apply
function dropper:config/validate
