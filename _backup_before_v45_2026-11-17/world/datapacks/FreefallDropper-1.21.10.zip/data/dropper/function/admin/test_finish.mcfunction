function dropper:admin/test_begin
scoreboard players operation #tf_from dp_ev = @s dp_level
function dropper:finish
tellraw @s [{"text":"[Test] completion detected: level ","color":"light_purple"},{"score":{"name":"#tf_from","objective":"dp_ev"},"color":"yellow"},{"text":" -> ","color":"gray"},{"score":{"name":"@s","objective":"dp_level"},"color":"yellow"},{"text":"  (test mode: run admin/test_end to restore)","color":"gray"}]
