tellraw @s {"text":"--- creator testing (op only) ---","color":"gold"}
tellraw @s {"text":"/function dropper:admin/goto {level:57}  - jump to a level (test mode: progress saved)","color":"white"}
tellraw @s {"text":"/function dropper:admin/stage {n:3}  - Level 100 stage 1-4","color":"white"}
tellraw @s {"text":"/function dropper:admin/restart  /  admin/reset_stage  - restart the current level / stage","color":"white"}
tellraw @s {"text":"/function dropper:admin/god  - sightseeing: no fails, nothing counted","color":"white"}
tellraw @s {"text":"/function dropper:admin/hazards_on | hazards_off  /  admin/hazard_speed {div:3}  (1 = normal)","color":"white"}
tellraw @s {"text":"/function dropper:admin/test_finish  - run completion detection on your current level","color":"white"}
tellraw @s {"text":"/function dropper:admin/diag  - hazards, costs, live state","color":"white"}
tellraw @s {"text":"/function dropper:admin/reload_config  - re-apply settings + validate events","color":"white"}
tellraw @s {"text":"/function dropper:admin/test_end  - leave test mode and restore your real progress","color":"white"}
