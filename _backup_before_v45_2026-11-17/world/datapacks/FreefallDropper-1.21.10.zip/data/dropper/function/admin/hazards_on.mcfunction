scoreboard players set #hazards dp_cfg 1
function dropper:config/apply
