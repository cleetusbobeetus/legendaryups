$scoreboard players set #rb dp_ev $(n)
execute unless score #rb dp_ev matches 1..4 run return run tellraw @s {"text":"[Freefall] Stage must be 1..4","color":"red"}
execute if score #rb dp_ev matches 1 run function dropper:rebuild/l100
execute if score #rb dp_ev matches 2 run function dropper:rebuild/l101
execute if score #rb dp_ev matches 3 run function dropper:rebuild/l102
execute if score #rb dp_ev matches 4 run function dropper:rebuild/l103
