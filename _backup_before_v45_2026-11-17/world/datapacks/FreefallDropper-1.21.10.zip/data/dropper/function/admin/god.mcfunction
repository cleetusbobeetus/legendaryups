function dropper:admin/test_begin
execute if entity @s[tag=dp_god] run return run function dropper:admin/god_off
tag @s add dp_god
tellraw @s {"text":"[Test] sightseeing ON: landing never fails, nothing is counted (admin/god again to stop)","color":"light_purple"}
