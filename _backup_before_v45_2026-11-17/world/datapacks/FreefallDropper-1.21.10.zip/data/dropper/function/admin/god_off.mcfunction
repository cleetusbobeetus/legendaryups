tag @s remove dp_god
tellraw @s {"text":"[Test] sightseeing OFF","color":"light_purple"}
