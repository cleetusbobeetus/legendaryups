execute unless entity @s[tag=dp_test] run return 0
tag @s remove dp_test
tag @s remove dp_god
scoreboard players operation @s dp_level = @s dp_sv_lvl
scoreboard players operation @s dp_fails = @s dp_sv_fail
scoreboard players operation @s dp_best = @s dp_sv_best
scoreboard players operation @s dp_wins = @s dp_sv_wins
scoreboard players set @s dp_plevel -999
function dropper:move/apply
tellraw @s {"text":"[Test] test mode OFF - progress restored","color":"light_purple"}
