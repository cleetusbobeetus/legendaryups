execute if entity @s[tag=dp_test] run return 0
tag @s add dp_test
scoreboard players operation @s dp_sv_lvl = @s dp_level
scoreboard players operation @s dp_sv_fail = @s dp_fails
scoreboard players operation @s dp_sv_best = @s dp_best
scoreboard players operation @s dp_sv_wins = @s dp_wins
tellraw @s {"text":"[Test] test mode ON - your real level, deaths, best and wins are saved and restored by admin/test_end","color":"light_purple"}
