execute as @a run attribute @s minecraft:gravity base set 0.08
