scoreboard players set #q dp_ev 8
function dropper:hud/queue
function dropper:to_start
execute if score #clearfx dp_cfg matches 1 at @s run function dropper:fx_clear
