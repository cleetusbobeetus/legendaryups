execute if score #practice dp_cfg matches 1 run return run function dropper:finish_practice
function dropper:clear/hook
scoreboard players set @s dp_streak 0
scoreboard players operation @s dp_plevel = @s dp_level
scoreboard players set @s dp_dir 1
scoreboard players set #seq dp_ev 1
execute if score #order dp_cfg matches 1 if score @s dp_level matches ..98 run scoreboard players set #seq dp_ev 0
execute if score #seq dp_ev matches 0 run function dropper:progress/random_next
execute if score #seq dp_ev matches 1 run scoreboard players add @s dp_level 1
scoreboard players set #vic dp_ev 0
execute if score @s dp_level matches 104.. run return run function dropper:beat_game
execute if score #vic dp_ev matches 0 run scoreboard players set #q dp_ev 1
execute if score #vic dp_ev matches 0 run function dropper:hud/queue
function dropper:move/apply
execute if score #clearfx dp_cfg matches 1 at @s run function dropper:fx_clear
