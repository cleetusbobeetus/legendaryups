tellraw @a [{"selector":"@s","color":"gold","bold":true},{"text":" BEAT ALL 103 LEVELS with ","color":"yellow"},{"score":{"name":"@s","objective":"dp_fails"},"color":"red"},{"text":" fails!","color":"yellow"}]
particle minecraft:totem_of_undying ~ ~1 ~ 1 1 1 0.5 150 force
scoreboard players operation @s dp_level = #startlevel dp_cfg
function dropper:lobby
