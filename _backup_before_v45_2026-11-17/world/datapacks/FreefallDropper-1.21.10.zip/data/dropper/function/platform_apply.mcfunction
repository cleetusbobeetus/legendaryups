function dropper:platform/reload
