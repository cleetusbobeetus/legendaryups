execute if score #practice dp_cfg matches 1 run return run function dropper:fail_practice
execute unless entity @s[tag=dp_test] unless score #practice dp_cfg matches 1 run scoreboard players add @s dp_fails 1
scoreboard players add @s dp_streak 1
scoreboard players operation @s dp_plevel = @s dp_level
execute unless entity @s[tag=dp_test] unless score #practice dp_cfg matches 1 run function dropper:progress/penalty
execute if score #bossmode dp_cfg matches 2 if score @s dp_level matches 101..103 run scoreboard players set @s dp_level 100
scoreboard players set #q dp_ev 2
function dropper:hud/queue
execute if score #streakmsg dp_cfg matches 1 run function dropper:streak_msg
execute if score #respawn dp_cfg matches 1.. if score #deathfx dp_cfg matches 1 run function dropper:fx_death
execute if score #respawn dp_cfg matches 1.. run return run function dropper:respawn_wait
function dropper:move/apply
execute if score #deathfx dp_cfg matches 1 at @s run function dropper:fx_death
