scoreboard players operation @s dp_wait = #respawn dp_cfg
scoreboard players set @s dp_grace 0
tag @s add dp_wait
