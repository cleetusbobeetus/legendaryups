tag @s remove dp_wait
function dropper:move/apply
