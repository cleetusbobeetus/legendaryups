scoreboard players set #q dp_ev 9
function dropper:hud/queue
function dropper:to_start
execute if score #deathfx dp_cfg matches 1 at @s run function dropper:fx_death
