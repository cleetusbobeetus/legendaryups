scoreboard players operation @s dp_level = #startlevel dp_cfg
scoreboard players set @s dp_fails 0
scoreboard players set @s dp_time 0
scoreboard players reset @s dp_cp
function dropper:start
