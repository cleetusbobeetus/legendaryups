fill 119 186 361 119 189 361 minecraft:stone
fill 120 186 360 120 189 360 minecraft:stone
setblock 122 186 364 minecraft:deepslate
setblock 123 186 361 minecraft:stripped_spruce_log
setblock 124 186 360 minecraft:stripped_spruce_log
fill 124 186 361 124 189 361 minecraft:stone
fill 126 186 322 128 186 322 minecraft:deepslate
setblock 126 186 364 minecraft:diamond_block
fill 134 186 325 135 186 342 minecraft:spruce_planks
fill 134 186 344 135 186 361 minecraft:spruce_planks
setblock 135 186 324 minecraft:spruce_planks
setblock 135 186 343 minecraft:spruce_planks
setblock 135 186 362 minecraft:spruce_planks
fill 136 186 328 136 186 330 minecraft:deepslate
fill 136 186 341 136 186 342 minecraft:deepslate
fill 136 186 349 136 186 350 minecraft:deepslate
setblock 136 186 359 minecraft:diamond_block
setblock 136 186 361 minecraft:gold_block
fill 94 187 322 94 187 324 minecraft:andesite
fill 94 187 326 94 187 329 minecraft:andesite
fill 94 187 331 94 188 334 minecraft:andesite
fill 94 187 336 94 187 361 minecraft:andesite
fill 94 187 363 94 193 364 minecraft:andesite
fill 95 187 322 100 187 322 minecraft:andesite
setblock 95 187 323 minecraft:stripped_spruce_log
fill 95 187 324 95 187 327 minecraft:stone
setblock 95 187 328 minecraft:stripped_spruce_log
fill 95 187 329 95 187 332 minecraft:stone
setblock 95 187 333 minecraft:stripped_spruce_log
fill 95 187 334 95 187 337 minecraft:stone
setblock 95 187 338 minecraft:stripped_spruce_log
fill 95 187 339 95 187 342 minecraft:stone
setblock 95 187 343 minecraft:stripped_spruce_log
fill 95 187 344 95 187 347 minecraft:stone
fill 95 187 348 96 187 349 minecraft:stripped_spruce_log
setblock 95 187 353 minecraft:stripped_spruce_log
fill 95 187 354 95 187 357 minecraft:stone
setblock 95 187 358 minecraft:stripped_spruce_log
fill 95 187 359 95 187 362 minecraft:stone
setblock 95 187 363 minecraft:stripped_spruce_log
setblock 95 187 364 minecraft:raw_gold_block
fill 96 187 323 99 187 323 minecraft:stone
fill 96 187 330 96 187 331 minecraft:stone
setblock 96 187 332 minecraft:stripped_spruce_log
fill 96 187 333 96 187 336 minecraft:stone
setblock 96 187 337 minecraft:stripped_spruce_log
fill 96 187 338 96 187 341 minecraft:stone
setblock 96 187 342 minecraft:stripped_spruce_log
fill 96 187 343 96 188 345 minecraft:stone
fill 96 187 347 97 188 347 minecraft:stripped_spruce_log
setblock 96 187 357 minecraft:stripped_spruce_log
fill 96 187 358 96 187 361 minecraft:stone
setblock 96 187 362 minecraft:stripped_spruce_log
fill 96 187 363 99 187 363 minecraft:stone
setblock 96 187 364 minecraft:deepslate
setblock 97 187 325 minecraft:light[level=15]
fill 97 187 332 97 190 332 minecraft:stone
setblock 97 187 336 minecraft:stripped_spruce_log
fill 97 187 337 97 190 337 minecraft:stone
setblock 97 187 340 minecraft:stone
setblock 97 187 341 minecraft:stripped_spruce_log
fill 97 187 342 97 189 343 minecraft:stone
setblock 97 187 346 minecraft:light[level=12]
fill 97 187 349 97 190 349 minecraft:stripped_spruce_log
setblock 97 187 353 minecraft:light[level=12]
setblock 97 187 357 minecraft:light[level=15]
setblock 97 187 360 minecraft:light[level=12]
fill 97 187 362 100 187 362 minecraft:stone
fill 97 187 364 118 187 364 minecraft:andesite
setblock 98 187 324 minecraft:stone
setblock 98 187 334 minecraft:stone
setblock 98 187 335 minecraft:stripped_spruce_log
fill 98 187 336 98 190 336 minecraft:stone
setblock 98 187 340 minecraft:stripped_spruce_log
fill 98 187 341 98 190 341 minecraft:stone
setblock 99 187 324 minecraft:stripped_spruce_log
setblock 100 187 323 minecraft:stripped_spruce_log
fill 100 187 324 103 187 324 minecraft:stone
fill 100 187 361 101 187 361 minecraft:stone
setblock 100 187 363 minecraft:stripped_spruce_log
setblock 101 187 322 minecraft:gold_block
fill 101 187 323 104 187 323 minecraft:stone
setblock 101 187 362 minecraft:stripped_spruce_log
fill 101 187 363 104 187 363 minecraft:stone
fill 102 187 322 120 187 322 minecraft:andesite
fill 102 187 362 105 187 362 minecraft:stone
setblock 104 187 324 minecraft:stripped_spruce_log
setblock 104 187 325 minecraft:light[level=12]
setblock 104 187 332 minecraft:light[level=12]
setblock 104 187 339 minecraft:light[level=12]
setblock 104 187 346 minecraft:light[level=12]
setblock 104 187 353 minecraft:light[level=12]
setblock 104 187 360 minecraft:light[level=12]
setblock 105 187 323 minecraft:stripped_spruce_log
fill 105 187 324 105 190 324 minecraft:stone
setblock 105 187 325 minecraft:light[level=15]
setblock 105 187 329 minecraft:raw_gold_block
setblock 105 187 333 minecraft:light[level=15]
setblock 105 187 341 minecraft:light[level=15]
setblock 105 187 349 minecraft:light[level=15]
setblock 105 187 357 minecraft:light[level=15]
setblock 105 187 363 minecraft:stripped_spruce_log
fill 106 187 323 109 187 323 minecraft:stone
setblock 106 187 362 minecraft:stripped_spruce_log
fill 106 187 363 109 187 363 minecraft:stone
fill 107 187 362 108 189 362 minecraft:stone
setblock 110 187 323 minecraft:stripped_spruce_log
setblock 110 187 362 minecraft:stone
setblock 110 187 363 minecraft:stripped_spruce_log
fill 111 187 323 114 187 323 minecraft:stone
setblock 111 187 325 minecraft:light[level=12]
setblock 111 187 332 minecraft:light[level=12]
setblock 111 187 339 minecraft:light[level=12]
setblock 111 187 346 minecraft:light[level=12]
setblock 111 187 353 minecraft:light[level=12]
setblock 111 187 360 minecraft:light[level=12]
setblock 111 187 362 minecraft:stripped_spruce_log
fill 111 187 363 114 187 363 minecraft:stone
fill 112 187 362 115 187 362 minecraft:stone
setblock 113 187 325 minecraft:light[level=15]
setblock 113 187 333 minecraft:light[level=15]
setblock 113 187 341 minecraft:light[level=15]
setblock 113 187 349 minecraft:light[level=15]
setblock 113 187 357 minecraft:light[level=15]
fill 114 187 361 116 187 361 minecraft:stone
setblock 115 187 323 minecraft:stripped_spruce_log
setblock 115 187 363 minecraft:stripped_spruce_log
fill 116 187 323 118 187 324 minecraft:stone
fill 116 187 360 117 187 360 minecraft:stone
setblock 116 187 362 minecraft:stripped_spruce_log
fill 116 187 363 119 187 363 minecraft:stone
setblock 117 187 361 minecraft:stripped_spruce_log
fill 117 187 362 120 187 362 minecraft:stone
setblock 118 187 325 minecraft:light[level=12]
setblock 118 187 332 minecraft:light[level=12]
setblock 118 187 339 minecraft:light[level=12]
setblock 118 187 346 minecraft:light[level=12]
setblock 118 187 353 minecraft:light[level=12]
setblock 118 187 360 minecraft:stripped_spruce_log
fill 118 187 361 118 190 361 minecraft:stone
setblock 119 187 323 minecraft:stone
setblock 119 187 324 minecraft:stripped_spruce_log
setblock 119 187 359 minecraft:stripped_spruce_log
fill 119 187 360 119 190 360 minecraft:stone
setblock 119 187 364 minecraft:deepslate
setblock 120 187 323 minecraft:stripped_spruce_log
fill 120 187 324 121 189 324 minecraft:stone
fill 120 187 359 121 189 359 minecraft:stone
setblock 120 187 363 minecraft:stripped_spruce_log
fill 120 187 364 123 227 364 minecraft:andesite
setblock 121 187 322 minecraft:deepslate
fill 121 187 323 124 187 323 minecraft:stone
setblock 121 187 325 minecraft:light[level=15]
setblock 121 187 333 minecraft:light[level=15]
setblock 121 187 341 minecraft:light[level=15]
setblock 121 187 349 minecraft:light[level=15]
setblock 121 187 357 minecraft:light[level=15]
setblock 121 187 362 minecraft:stripped_spruce_log
fill 121 187 363 124 187 363 minecraft:stone
fill 122 187 322 136 187 322 minecraft:andesite
setblock 122 187 360 minecraft:stone
setblock 122 187 361 minecraft:stripped_spruce_log
fill 122 187 362 125 187 362 minecraft:stone
setblock 123 187 360 minecraft:stripped_spruce_log
fill 123 187 361 123 190 361 minecraft:stone
fill 124 187 360 124 189 360 minecraft:stone
setblock 125 187 323 minecraft:stripped_spruce_log
setblock 125 187 325 minecraft:light[level=12]
setblock 125 187 332 minecraft:light[level=12]
setblock 125 187 339 minecraft:light[level=12]
setblock 125 187 346 minecraft:light[level=12]
setblock 125 187 353 minecraft:light[level=12]
setblock 125 187 360 minecraft:light[level=12]
setblock 125 187 363 minecraft:stripped_spruce_log
fill 125 187 364 134 187 364 minecraft:andesite
setblock 126 187 362 minecraft:stripped_spruce_log
fill 126 187 363 129 187 363 minecraft:stone
fill 127 187 362 128 189 362 minecraft:stone
setblock 129 187 325 minecraft:light[level=15]
setblock 129 187 333 minecraft:light[level=15]
setblock 129 187 341 minecraft:light[level=15]
setblock 129 187 349 minecraft:light[level=15]
setblock 129 187 357 minecraft:light[level=15]
setblock 130 187 363 minecraft:stripped_spruce_log
fill 131 187 359 131 189 359 minecraft:stripped_spruce_log
fill 131 187 361 131 189 361 minecraft:stripped_spruce_log
fill 131 187 363 134 187 363 minecraft:stone
setblock 132 187 325 minecraft:light[level=12]
setblock 132 187 332 minecraft:light[level=12]
setblock 132 187 339 minecraft:light[level=12]
setblock 132 187 353 minecraft:light[level=12]
fill 133 187 359 134 187 359 minecraft:stripped_spruce_log
fill 133 187 361 133 189 361 minecraft:stripped_spruce_log
fill 134 187 335 134 187 338 minecraft:stone
setblock 134 187 339 minecraft:stripped_spruce_log
fill 134 187 340 134 187 343 minecraft:stone
setblock 134 187 344 minecraft:stripped_spruce_log
fill 134 187 345 135 189 345 minecraft:stone
fill 134 187 355 134 187 358 minecraft:stone
fill 134 187 360 135 188 361 minecraft:stone
setblock 135 187 332 minecraft:stone
setblock 135 187 333 minecraft:stripped_spruce_log
fill 135 187 334 135 187 337 minecraft:stone
setblock 135 187 338 minecraft:stripped_spruce_log
fill 135 187 339 135 187 342 minecraft:stone
setblock 135 187 343 minecraft:stripped_spruce_log
fill 135 187 344 135 190 344 minecraft:stone
fill 135 187 346 135 187 347 minecraft:stone
setblock 135 187 348 minecraft:stripped_spruce_log
fill 135 187 349 135 187 352 minecraft:stone
setblock 135 187 353 minecraft:stripped_spruce_log
fill 135 187 354 135 187 357 minecraft:stone
setblock 135 187 358 minecraft:stripped_spruce_log
fill 135 187 359 135 190 359 minecraft:stone
setblock 135 187 362 minecraft:stone
setblock 135 187 363 minecraft:stripped_spruce_log
setblock 135 187 364 minecraft:deepslate
fill 136 187 324 136 187 329 minecraft:andesite
setblock 136 187 330 minecraft:deepslate
fill 136 187 332 136 203 333 minecraft:andesite
fill 136 187 335 136 191 337 minecraft:andesite
setblock 136 187 339 minecraft:deepslate
fill 136 187 340 136 187 346 minecraft:andesite
fill 136 187 349 136 189 353 minecraft:andesite
fill 136 187 355 136 188 364 minecraft:andesite
fill 94 188 322 95 188 322 minecraft:deepslate
setblock 94 188 323 minecraft:andesite
setblock 94 188 324 minecraft:deepslate
fill 94 188 326 94 189 326 minecraft:andesite
setblock 94 188 327 minecraft:deepslate
fill 94 188 328 94 188 330 minecraft:andesite
fill 94 188 335 94 188 339 minecraft:andesite
setblock 94 188 340 minecraft:deepslate
fill 94 188 341 94 197 341 minecraft:andesite
fill 94 188 342 94 189 342 minecraft:deepslate
fill 94 188 343 94 188 354 minecraft:andesite
setblock 94 188 355 minecraft:deepslate
setblock 94 188 356 minecraft:andesite
setblock 94 188 357 minecraft:deepslate
fill 94 188 358 94 192 362 minecraft:andesite
fill 95 188 323 95 188 326 minecraft:stone
setblock 95 188 327 minecraft:stripped_spruce_log
fill 95 188 328 95 188 331 minecraft:stone
setblock 95 188 332 minecraft:stripped_spruce_log
fill 95 188 333 95 188 336 minecraft:stone
setblock 95 188 337 minecraft:stripped_spruce_log
fill 95 188 338 95 188 341 minecraft:stone
setblock 95 188 342 minecraft:stripped_spruce_log
fill 95 188 343 95 188 346 minecraft:stone
setblock 95 188 347 minecraft:stripped_spruce_log
fill 95 188 348 95 189 350 minecraft:stone
setblock 95 188 352 minecraft:stripped_spruce_log
fill 95 188 353 95 188 356 minecraft:stone
setblock 95 188 357 minecraft:stripped_spruce_log
fill 95 188 358 95 188 361 minecraft:stone
setblock 95 188 362 minecraft:stripped_spruce_log
fill 95 188 363 98 188 363 minecraft:stone
fill 95 188 364 105 205 364 minecraft:andesite
fill 96 188 322 96 242 322 minecraft:andesite
fill 96 188 323 96 188 325 minecraft:stone
setblock 96 188 326 minecraft:stripped_spruce_log
fill 96 188 327 96 188 330 minecraft:stone
setblock 96 188 331 minecraft:stripped_spruce_log
fill 96 188 332 96 188 335 minecraft:stone
setblock 96 188 336 minecraft:stripped_spruce_log
fill 96 188 337 96 188 340 minecraft:stone
setblock 96 188 341 minecraft:stripped_spruce_log
fill 96 188 342 96 191 342 minecraft:stone
setblock 96 188 346 minecraft:stripped_spruce_log
fill 96 188 348 96 189 349 minecraft:stripped_spruce_log
fill 96 188 357 96 188 360 minecraft:stone
setblock 96 188 361 minecraft:stripped_spruce_log
fill 96 188 362 99 188 362 minecraft:stone
setblock 97 188 322 minecraft:deepslate
fill 97 188 323 97 188 324 minecraft:stone
fill 97 188 331 97 191 331 minecraft:stone
setblock 97 188 335 minecraft:stripped_spruce_log
fill 97 188 336 97 191 336 minecraft:stone
setblock 97 188 340 minecraft:stripped_spruce_log
fill 97 188 341 97 191 341 minecraft:stone
setblock 97 188 344 minecraft:stone
fill 98 188 322 114 188 322 minecraft:andesite
setblock 98 188 323 minecraft:stone
setblock 98 188 324 minecraft:stripped_spruce_log
setblock 98 188 333 minecraft:stone
setblock 98 188 334 minecraft:stripped_spruce_log
fill 98 188 335 98 190 335 minecraft:stone
setblock 98 188 339 minecraft:stripped_spruce_log
fill 98 188 340 98 191 340 minecraft:stone
fill 98 188 342 98 189 342 minecraft:stone
fill 98 188 361 100 188 361 minecraft:stone
setblock 99 188 323 minecraft:stripped_spruce_log
fill 99 188 324 102 188 324 minecraft:stone
setblock 99 188 337 minecraft:stone
setblock 99 188 338 minecraft:stripped_spruce_log
setblock 99 188 363 minecraft:stripped_spruce_log
fill 100 188 323 103 188 323 minecraft:stone
fill 100 188 325 101 188 325 minecraft:stone
setblock 100 188 362 minecraft:stripped_spruce_log
fill 100 188 363 103 188 363 minecraft:stone
setblock 101 188 361 minecraft:stripped_spruce_log
fill 101 188 362 104 188 362 minecraft:stone
fill 102 188 361 103 189 361 minecraft:stone
setblock 103 188 324 minecraft:stripped_spruce_log
setblock 104 188 323 minecraft:stripped_spruce_log
fill 104 188 324 104 191 324 minecraft:stone
setblock 104 188 363 minecraft:stripped_spruce_log
fill 105 188 323 108 188 323 minecraft:stone
setblock 105 188 330 minecraft:raw_gold_block
setblock 105 188 362 minecraft:stripped_spruce_log
fill 105 188 363 108 188 363 minecraft:stone
fill 106 188 324 106 189 324 minecraft:stone
fill 106 188 362 106 191 362 minecraft:stone
setblock 106 188 364 minecraft:deepslate
fill 107 188 364 119 188 364 minecraft:andesite
setblock 109 188 323 minecraft:stripped_spruce_log
setblock 109 188 362 minecraft:stone
setblock 109 188 363 minecraft:stripped_spruce_log
fill 110 188 323 113 188 323 minecraft:stone
setblock 110 188 362 minecraft:stripped_spruce_log
fill 110 188 363 113 188 363 minecraft:stone
fill 111 188 362 114 188 362 minecraft:stone
fill 112 188 361 115 188 361 minecraft:stone
setblock 114 188 323 minecraft:stripped_spruce_log
fill 114 188 324 117 188 324 minecraft:stone
setblock 114 188 363 minecraft:stripped_spruce_log
setblock 115 188 322 minecraft:deepslate
fill 115 188 323 118 188 323 minecraft:stone
fill 115 188 360 116 188 360 minecraft:stone
setblock 115 188 362 minecraft:stripped_spruce_log
fill 115 188 363 118 188 363 minecraft:stone
fill 116 188 322 118 197 322 minecraft:andesite
setblock 116 188 361 minecraft:stripped_spruce_log
fill 116 188 362 119 188 362 minecraft:stone
setblock 117 188 360 minecraft:stripped_spruce_log
fill 117 188 361 117 191 361 minecraft:stone
setblock 118 188 324 minecraft:stripped_spruce_log
setblock 118 188 359 minecraft:stripped_spruce_log
fill 118 188 360 118 191 360 minecraft:stone
setblock 119 188 322 minecraft:deepslate
setblock 119 188 323 minecraft:stripped_spruce_log
fill 119 188 324 119 191 324 minecraft:stone
fill 119 188 359 119 190 359 minecraft:stone
setblock 119 188 363 minecraft:stripped_spruce_log
fill 120 188 322 125 188 322 minecraft:andesite
fill 120 188 323 123 188 323 minecraft:stone
setblock 120 188 362 minecraft:stripped_spruce_log
fill 120 188 363 123 188 363 minecraft:stone
setblock 121 188 361 minecraft:stripped_spruce_log
fill 121 188 362 124 188 362 minecraft:stone
setblock 122 188 324 minecraft:stone
setblock 122 188 360 minecraft:stripped_spruce_log
fill 122 188 361 122 191 361 minecraft:stone
fill 123 188 360 123 190 360 minecraft:stone
setblock 124 188 323 minecraft:stripped_spruce_log
setblock 124 188 363 minecraft:stripped_spruce_log
fill 124 188 364 130 201 364 minecraft:andesite
fill 125 188 323 125 191 323 minecraft:stone
setblock 125 188 361 minecraft:stone
setblock 125 188 362 minecraft:stripped_spruce_log
fill 125 188 363 128 188 363 minecraft:stone
fill 126 188 322 127 188 322 minecraft:deepslate
setblock 126 188 361 minecraft:stripped_spruce_log
fill 126 188 362 126 191 362 minecraft:stone
fill 128 188 322 136 192 322 minecraft:andesite
setblock 129 188 362 minecraft:stone
setblock 129 188 363 minecraft:stripped_spruce_log
fill 130 188 363 133 188 363 minecraft:stone
setblock 131 188 364 minecraft:raw_iron_block
fill 132 188 364 135 247 364 minecraft:andesite
setblock 133 188 339 minecraft:stripped_spruce_log
fill 133 188 340 135 188 341 minecraft:stone
fill 133 188 359 133 189 359 minecraft:stripped_spruce_log
fill 133 188 362 134 188 362 minecraft:stone
fill 134 188 334 134 188 337 minecraft:stone
setblock 134 188 338 minecraft:stripped_spruce_log
fill 134 188 339 135 190 339 minecraft:stone
setblock 134 188 342 minecraft:stone
setblock 134 188 343 minecraft:stripped_spruce_log
fill 134 188 344 134 191 344 minecraft:stone
fill 134 188 346 134 188 347 minecraft:stone
fill 134 188 354 134 188 357 minecraft:stone
setblock 134 188 358 minecraft:stripped_spruce_log
fill 134 188 359 134 191 359 minecraft:stone
setblock 134 188 363 minecraft:stripped_spruce_log
setblock 135 188 331 minecraft:stone
setblock 135 188 332 minecraft:stripped_spruce_log
fill 135 188 333 135 188 336 minecraft:stone
setblock 135 188 337 minecraft:stripped_spruce_log
fill 135 188 338 135 191 338 minecraft:stone
setblock 135 188 342 minecraft:stripped_spruce_log
fill 135 188 343 135 191 343 minecraft:stone
setblock 135 188 346 minecraft:stone
setblock 135 188 347 minecraft:stripped_spruce_log
fill 135 188 348 135 188 351 minecraft:stone
setblock 135 188 352 minecraft:stripped_spruce_log
fill 135 188 353 135 188 356 minecraft:stone
setblock 135 188 357 minecraft:stripped_spruce_log
fill 135 188 358 135 191 358 minecraft:stone
setblock 135 188 362 minecraft:stripped_spruce_log
fill 135 188 363 135 191 363 minecraft:stone
fill 136 188 323 136 233 326 minecraft:andesite
setblock 136 188 327 minecraft:deepslate
fill 136 188 328 136 217 331 minecraft:andesite
fill 136 188 334 136 245 334 minecraft:andesite
fill 136 188 338 136 188 340 minecraft:andesite
fill 136 188 341 136 188 342 minecraft:deepslate
fill 136 188 343 136 188 346 minecraft:andesite
fill 136 188 348 136 193 348 minecraft:andesite
fill 136 188 354 136 247 354 minecraft:andesite
fill 94 189 322 94 245 322 minecraft:andesite
setblock 94 189 323 minecraft:deepslate
fill 94 189 324 94 195 325 minecraft:andesite
fill 94 189 327 94 247 328 minecraft:andesite
setblock 94 189 329 minecraft:deepslate
fill 94 189 330 94 197 330 minecraft:andesite
setblock 94 189 331 minecraft:deepslate
fill 94 189 332 94 214 337 minecraft:andesite
setblock 94 189 338 minecraft:deepslate
fill 94 189 339 94 201 340 minecraft:andesite
setblock 94 189 343 minecraft:deepslate
fill 94 189 344 94 189 355 minecraft:andesite
setblock 94 189 356 minecraft:deepslate
fill 94 189 357 94 208 357 minecraft:andesite
setblock 95 189 322 minecraft:deepslate
fill 95 189 323 95 189 325 minecraft:stone
setblock 95 189 326 minecraft:stripped_spruce_log
fill 95 189 327 95 189 330 minecraft:stone
setblock 95 189 331 minecraft:stripped_spruce_log
fill 95 189 332 95 189 335 minecraft:stone
setblock 95 189 336 minecraft:stripped_spruce_log
fill 95 189 337 95 189 340 minecraft:stone
setblock 95 189 341 minecraft:stripped_spruce_log
fill 95 189 342 95 189 345 minecraft:stone
setblock 95 189 346 minecraft:stripped_spruce_log
fill 95 189 347 96 191 347 minecraft:stone
setblock 95 189 351 minecraft:stripped_spruce_log
fill 95 189 352 95 189 355 minecraft:stone
setblock 95 189 356 minecraft:stripped_spruce_log
fill 95 189 357 95 189 360 minecraft:stone
setblock 95 189 361 minecraft:stripped_spruce_log
fill 95 189 362 97 189 363 minecraft:stone
fill 96 189 323 96 189 324 minecraft:stone
setblock 96 189 325 minecraft:stripped_spruce_log
fill 96 189 326 96 189 329 minecraft:stone
setblock 96 189 330 minecraft:stripped_spruce_log
fill 96 189 331 96 189 334 minecraft:stone
setblock 96 189 335 minecraft:stripped_spruce_log
fill 96 189 336 96 189 339 minecraft:stone
setblock 96 189 340 minecraft:stripped_spruce_log
fill 96 189 341 96 192 341 minecraft:stone
fill 96 189 343 96 189 344 minecraft:stone
setblock 96 189 345 minecraft:stripped_spruce_log
fill 96 189 346 96 192 346 minecraft:stone
fill 96 189 357 96 189 359 minecraft:stone
setblock 96 189 360 minecraft:stripped_spruce_log
fill 96 189 361 99 189 361 minecraft:stone
fill 97 189 322 101 194 322 minecraft:andesite
setblock 97 189 323 minecraft:stone
setblock 97 189 324 minecraft:stripped_spruce_log
fill 97 189 330 97 191 330 minecraft:stone
setblock 97 189 334 minecraft:stripped_spruce_log
fill 97 189 335 97 192 335 minecraft:stone
setblock 97 189 339 minecraft:stripped_spruce_log
fill 97 189 340 97 192 340 minecraft:stone
setblock 97 189 344 minecraft:stripped_spruce_log
fill 97 189 345 97 192 345 minecraft:stone
fill 97 189 347 97 190 347 minecraft:stripped_spruce_log
fill 97 189 360 97 190 360 minecraft:stone
setblock 98 189 323 minecraft:stripped_spruce_log
fill 98 189 324 100 189 325 minecraft:stone
fill 98 189 334 98 190 334 minecraft:stone
setblock 98 189 338 minecraft:stripped_spruce_log
fill 98 189 339 98 192 339 minecraft:stone
setblock 98 189 343 minecraft:stripped_spruce_log
setblock 98 189 362 minecraft:stone
setblock 98 189 363 minecraft:stripped_spruce_log
fill 99 189 323 102 189 323 minecraft:stone
setblock 99 189 338 minecraft:stone
setblock 99 189 362 minecraft:stripped_spruce_log
fill 99 189 363 102 189 363 minecraft:stone
setblock 100 189 361 minecraft:stripped_spruce_log
fill 100 189 362 103 189 362 minecraft:stone
setblock 101 189 324 minecraft:stone
setblock 101 189 325 minecraft:stripped_spruce_log
fill 101 189 361 101 191 361 minecraft:stone
setblock 102 189 322 minecraft:deepslate
setblock 102 189 324 minecraft:stripped_spruce_log
fill 102 189 325 102 192 325 minecraft:stone
fill 103 189 322 112 196 322 minecraft:andesite
setblock 103 189 323 minecraft:stripped_spruce_log
fill 103 189 324 103 192 324 minecraft:stone
setblock 103 189 363 minecraft:stripped_spruce_log
fill 104 189 323 107 189 323 minecraft:stone
setblock 104 189 362 minecraft:stripped_spruce_log
fill 104 189 363 107 189 363 minecraft:stone
fill 105 189 362 105 192 362 minecraft:stone
fill 106 189 364 109 214 364 minecraft:andesite
setblock 107 189 324 minecraft:stripped_spruce_log
setblock 108 189 323 minecraft:stripped_spruce_log
setblock 108 189 363 minecraft:stripped_spruce_log
fill 109 189 323 112 189 323 minecraft:stone
setblock 109 189 362 minecraft:stripped_spruce_log
fill 109 189 363 112 189 363 minecraft:stone
fill 110 189 362 113 189 362 minecraft:stone
setblock 110 189 364 minecraft:deepslate
fill 111 189 361 114 189 361 minecraft:stone
fill 111 189 364 112 221 364 minecraft:andesite
setblock 112 189 324 minecraft:stripped_spruce_log
setblock 113 189 322 minecraft:deepslate
setblock 113 189 323 minecraft:stripped_spruce_log
fill 113 189 324 116 189 324 minecraft:stone
setblock 113 189 363 minecraft:stripped_spruce_log
setblock 113 189 364 minecraft:raw_iron_block
fill 114 189 322 115 204 322 minecraft:andesite
fill 114 189 323 117 189 323 minecraft:stone
fill 114 189 360 115 189 360 minecraft:stone
setblock 114 189 362 minecraft:stripped_spruce_log
fill 114 189 363 117 189 363 minecraft:stone
fill 114 189 364 119 193 364 minecraft:andesite
setblock 115 189 361 minecraft:stripped_spruce_log
fill 115 189 362 118 189 362 minecraft:stone
setblock 116 189 360 minecraft:stripped_spruce_log
fill 116 189 361 116 192 361 minecraft:stone
setblock 117 189 324 minecraft:stripped_spruce_log
fill 117 189 360 117 192 360 minecraft:stone
setblock 118 189 323 minecraft:stripped_spruce_log
fill 118 189 324 118 192 324 minecraft:stone
fill 118 189 359 118 190 359 minecraft:stone
setblock 118 189 363 minecraft:stripped_spruce_log
fill 119 189 322 121 204 322 minecraft:andesite
fill 119 189 323 122 189 323 minecraft:stone
setblock 119 189 362 minecraft:stripped_spruce_log
fill 119 189 363 122 189 363 minecraft:stone
setblock 120 189 361 minecraft:stripped_spruce_log
fill 120 189 362 123 189 362 minecraft:stone
setblock 121 189 360 minecraft:stripped_spruce_log
fill 121 189 361 121 192 361 minecraft:stone
setblock 122 189 322 minecraft:deepslate
setblock 122 189 324 minecraft:stripped_spruce_log
fill 122 189 360 122 191 360 minecraft:stone
fill 123 189 322 126 198 322 minecraft:andesite
setblock 123 189 323 minecraft:stripped_spruce_log
setblock 123 189 363 minecraft:stripped_spruce_log
fill 124 189 323 124 192 323 minecraft:stone
setblock 124 189 362 minecraft:stripped_spruce_log
fill 124 189 363 127 189 363 minecraft:stone
setblock 125 189 361 minecraft:stripped_spruce_log
fill 125 189 362 125 192 362 minecraft:stone
setblock 126 189 361 minecraft:stone
setblock 127 189 322 minecraft:deepslate
setblock 128 189 363 minecraft:stripped_spruce_log
setblock 129 189 362 minecraft:stripped_spruce_log
fill 129 189 363 132 189 363 minecraft:stone
fill 130 189 362 133 189 362 minecraft:stone
fill 131 189 364 131 191 364 minecraft:andesite
setblock 133 189 338 minecraft:stripped_spruce_log
fill 133 189 339 133 189 342 minecraft:stone
setblock 133 189 343 minecraft:stripped_spruce_log
fill 133 189 344 133 192 344 minecraft:stone
setblock 133 189 363 minecraft:stripped_spruce_log
fill 134 189 323 135 191 323 minecraft:stone
fill 134 189 334 134 189 336 minecraft:stone
setblock 134 189 337 minecraft:stripped_spruce_log
fill 134 189 338 134 192 338 minecraft:stone
fill 134 189 340 134 189 341 minecraft:stone
setblock 134 189 342 minecraft:stripped_spruce_log
fill 134 189 343 134 192 343 minecraft:stone
setblock 134 189 346 minecraft:stone
setblock 134 189 347 minecraft:stripped_spruce_log
fill 134 189 348 135 190 349 minecraft:stone
fill 134 189 354 134 189 356 minecraft:stone
setblock 134 189 357 minecraft:stripped_spruce_log
fill 134 189 358 134 192 358 minecraft:stone
fill 134 189 360 134 189 361 minecraft:stone
setblock 134 189 362 minecraft:stripped_spruce_log
fill 134 189 363 134 192 363 minecraft:stone
fill 135 189 324 135 190 324 minecraft:stone
setblock 135 189 330 minecraft:stone
setblock 135 189 331 minecraft:stripped_spruce_log
fill 135 189 332 135 189 335 minecraft:stone
setblock 135 189 336 minecraft:stripped_spruce_log
fill 135 189 337 135 192 337 minecraft:stone
setblock 135 189 340 minecraft:stone
setblock 135 189 341 minecraft:stripped_spruce_log
fill 135 189 342 135 192 342 minecraft:stone
setblock 135 189 346 minecraft:stripped_spruce_log
fill 135 189 347 135 192 347 minecraft:stone
setblock 135 189 350 minecraft:stone
setblock 135 189 351 minecraft:stripped_spruce_log
fill 135 189 352 135 189 355 minecraft:stone
setblock 135 189 356 minecraft:stripped_spruce_log
fill 135 189 357 135 192 357 minecraft:stone
setblock 135 189 360 minecraft:stone
setblock 135 189 361 minecraft:stripped_spruce_log
fill 135 189 362 135 192 362 minecraft:stone
fill 136 189 327 136 247 327 minecraft:andesite
fill 136 189 338 136 201 339 minecraft:andesite
setblock 136 189 340 minecraft:deepslate
fill 136 189 341 136 192 342 minecraft:andesite
setblock 136 189 343 minecraft:deepslate
fill 136 189 344 136 206 347 minecraft:andesite
fill 136 189 355 136 202 360 minecraft:andesite
setblock 136 189 361 minecraft:deepslate
fill 136 189 362 136 243 364 minecraft:andesite
fill 94 190 323 94 235 323 minecraft:andesite
setblock 94 190 326 minecraft:raw_iron_block
fill 94 190 329 94 247 329 minecraft:andesite
fill 94 190 331 94 247 331 minecraft:andesite
fill 94 190 338 94 247 338 minecraft:andesite
fill 94 190 342 94 200 349 minecraft:andesite
setblock 94 190 350 minecraft:diamond_block
fill 94 190 351 94 196 356 minecraft:andesite
fill 95 190 322 95 243 322 minecraft:andesite
fill 95 190 323 95 190 324 minecraft:stone
setblock 95 190 325 minecraft:stripped_spruce_log
fill 95 190 326 95 190 329 minecraft:stone
setblock 95 190 330 minecraft:stripped_spruce_log
fill 95 190 331 95 190 334 minecraft:stone
setblock 95 190 335 minecraft:stripped_spruce_log
fill 95 190 336 95 190 339 minecraft:stone
setblock 95 190 340 minecraft:stripped_spruce_log
fill 95 190 341 95 190 344 minecraft:stone
setblock 95 190 345 minecraft:stripped_spruce_log
fill 95 190 346 95 193 346 minecraft:stone
fill 95 190 348 95 190 349 minecraft:stone
fill 95 190 350 96 190 350 minecraft:stripped_spruce_log
fill 95 190 351 95 190 354 minecraft:stone
setblock 95 190 355 minecraft:stripped_spruce_log
fill 95 190 356 95 190 359 minecraft:stone
setblock 95 190 360 minecraft:stripped_spruce_log
fill 95 190 361 96 190 363 minecraft:stone
setblock 96 190 323 minecraft:stone
setblock 96 190 324 minecraft:stripped_spruce_log
fill 96 190 325 96 190 328 minecraft:stone
setblock 96 190 329 minecraft:stripped_spruce_log
fill 96 190 330 96 190 333 minecraft:stone
setblock 96 190 334 minecraft:stripped_spruce_log
fill 96 190 335 96 190 338 minecraft:stone
setblock 96 190 339 minecraft:stripped_spruce_log
fill 96 190 340 96 193 340 minecraft:stone
setblock 96 190 343 minecraft:stone
setblock 96 190 344 minecraft:stripped_spruce_log
fill 96 190 345 96 193 345 minecraft:stone
setblock 96 190 348 minecraft:stone
setblock 96 190 349 minecraft:stripped_spruce_log
fill 96 190 357 96 190 358 minecraft:stone
setblock 96 190 359 minecraft:stripped_spruce_log
fill 96 190 360 96 193 360 minecraft:stone
setblock 97 190 323 minecraft:stripped_spruce_log
fill 97 190 324 97 190 327 minecraft:stone
fill 97 190 329 97 192 329 minecraft:stone
setblock 97 190 333 minecraft:stripped_spruce_log
fill 97 190 334 97 192 334 minecraft:stone
setblock 97 190 338 minecraft:stripped_spruce_log
fill 97 190 339 97 193 339 minecraft:stone
setblock 97 190 342 minecraft:stone
setblock 97 190 343 minecraft:stripped_spruce_log
fill 97 190 344 97 193 344 minecraft:stone
fill 97 190 361 97 190 362 minecraft:stone
setblock 97 190 363 minecraft:stripped_spruce_log
fill 98 190 323 99 190 325 minecraft:stone
setblock 98 190 337 minecraft:stripped_spruce_log
fill 98 190 338 98 192 338 minecraft:stone
setblock 98 190 342 minecraft:stripped_spruce_log
fill 98 190 343 98 191 343 minecraft:stone
setblock 98 190 348 minecraft:stripped_spruce_log
setblock 98 190 361 minecraft:stone
setblock 98 190 362 minecraft:stripped_spruce_log
fill 98 190 363 101 190 363 minecraft:stone
setblock 99 190 361 minecraft:stripped_spruce_log
fill 99 190 362 102 190 362 minecraft:stone
fill 100 190 323 100 190 324 minecraft:stone
setblock 100 190 325 minecraft:stripped_spruce_log
fill 100 190 361 100 191 361 minecraft:stone
setblock 101 190 323 minecraft:stone
setblock 101 190 324 minecraft:stripped_spruce_log
fill 101 190 325 101 193 325 minecraft:stone
fill 102 190 322 102 247 322 minecraft:andesite
setblock 102 190 323 minecraft:stripped_spruce_log
fill 102 190 324 102 193 324 minecraft:stone
setblock 102 190 361 minecraft:stone
setblock 102 190 363 minecraft:stripped_spruce_log
fill 103 190 323 106 190 323 minecraft:stone
setblock 103 190 362 minecraft:stripped_spruce_log
fill 103 190 363 106 190 363 minecraft:stone
fill 104 190 362 104 193 362 minecraft:stone
setblock 106 190 324 minecraft:stripped_spruce_log
setblock 107 190 323 minecraft:stripped_spruce_log
fill 107 190 324 110 190 324 minecraft:stone
setblock 107 190 362 minecraft:stone
setblock 107 190 363 minecraft:stripped_spruce_log
fill 108 190 323 111 190 323 minecraft:stone
setblock 108 190 362 minecraft:stripped_spruce_log
fill 108 190 363 111 190 363 minecraft:stone
fill 109 190 362 112 190 362 minecraft:stone
fill 110 190 364 110 201 364 minecraft:andesite
setblock 111 190 324 minecraft:stripped_spruce_log
fill 111 190 361 113 190 361 minecraft:stone
setblock 112 190 323 minecraft:stripped_spruce_log
fill 112 190 324 115 190 324 minecraft:stone
setblock 112 190 363 minecraft:stripped_spruce_log
fill 113 190 322 113 247 322 minecraft:andesite
fill 113 190 323 116 190 323 minecraft:stone
setblock 113 190 362 minecraft:stripped_spruce_log
fill 113 190 363 116 190 363 minecraft:stone
fill 113 190 364 113 201 364 minecraft:andesite
setblock 114 190 360 minecraft:stone
setblock 114 190 361 minecraft:stripped_spruce_log
fill 114 190 362 117 190 362 minecraft:stone
setblock 115 190 360 minecraft:stripped_spruce_log
fill 115 190 361 115 193 361 minecraft:stone
setblock 116 190 324 minecraft:stripped_spruce_log
fill 116 190 360 116 193 360 minecraft:stone
setblock 117 190 323 minecraft:stripped_spruce_log
fill 117 190 324 117 193 324 minecraft:stone
setblock 117 190 363 minecraft:stripped_spruce_log
fill 118 190 323 121 190 323 minecraft:stone
setblock 118 190 362 minecraft:stripped_spruce_log
fill 118 190 363 121 190 363 minecraft:stone
setblock 119 190 361 minecraft:stripped_spruce_log
fill 119 190 362 122 190 362 minecraft:stone
setblock 120 190 324 minecraft:stone
setblock 120 190 360 minecraft:stripped_spruce_log
fill 120 190 361 120 193 361 minecraft:stone
setblock 121 190 324 minecraft:stripped_spruce_log
fill 121 190 360 121 191 360 minecraft:stone
fill 122 190 322 122 207 322 minecraft:andesite
setblock 122 190 323 minecraft:stripped_spruce_log
setblock 122 190 324 minecraft:stone
setblock 122 190 363 minecraft:stripped_spruce_log
fill 123 190 323 123 193 323 minecraft:stone
setblock 123 190 362 minecraft:stripped_spruce_log
fill 123 190 363 126 190 363 minecraft:stone
setblock 124 190 361 minecraft:stripped_spruce_log
fill 124 190 362 124 193 362 minecraft:stone
setblock 125 190 361 minecraft:stone
fill 127 190 322 127 245 322 minecraft:andesite
setblock 127 190 362 minecraft:stone
setblock 127 190 363 minecraft:stripped_spruce_log
setblock 128 190 362 minecraft:stripped_spruce_log
fill 128 190 363 131 190 363 minecraft:stone
fill 129 190 362 132 190 362 minecraft:stone
setblock 132 190 363 minecraft:stripped_spruce_log
fill 133 190 323 133 193 323 minecraft:stone
setblock 133 190 337 minecraft:stripped_spruce_log
fill 133 190 338 133 190 341 minecraft:stone
setblock 133 190 342 minecraft:stripped_spruce_log
fill 133 190 343 133 193 343 minecraft:stone
fill 133 190 345 134 190 345 minecraft:stone
setblock 133 190 362 minecraft:stripped_spruce_log
fill 133 190 363 133 193 363 minecraft:stone
fill 134 190 334 134 190 335 minecraft:stone
setblock 134 190 336 minecraft:stripped_spruce_log
fill 134 190 337 134 193 337 minecraft:stone
setblock 134 190 340 minecraft:stone
setblock 134 190 341 minecraft:stripped_spruce_log
fill 134 190 342 134 193 342 minecraft:stone
setblock 134 190 346 minecraft:stripped_spruce_log
fill 134 190 347 134 193 347 minecraft:stone
setblock 134 190 350 minecraft:stone
setblock 134 190 355 minecraft:stone
setblock 134 190 356 minecraft:stripped_spruce_log
fill 134 190 357 134 191 357 minecraft:stone
setblock 134 190 360 minecraft:stone
setblock 134 190 361 minecraft:stripped_spruce_log
fill 134 190 362 134 193 362 minecraft:stone
setblock 135 190 325 minecraft:stripped_spruce_log
fill 135 190 326 135 190 329 minecraft:stone
setblock 135 190 330 minecraft:stripped_spruce_log
fill 135 190 331 135 190 334 minecraft:stone
setblock 135 190 335 minecraft:stripped_spruce_log
fill 135 190 336 135 193 336 minecraft:stone
setblock 135 190 340 minecraft:stripped_spruce_log
fill 135 190 341 135 193 341 minecraft:stone
setblock 135 190 345 minecraft:stripped_spruce_log
fill 135 190 346 135 193 346 minecraft:stone
setblock 135 190 350 minecraft:stripped_spruce_log
fill 135 190 351 135 190 354 minecraft:stone
setblock 135 190 355 minecraft:stripped_spruce_log
fill 135 190 356 135 193 356 minecraft:stone
setblock 135 190 360 minecraft:stripped_spruce_log
fill 135 190 361 135 193 361 minecraft:stone
fill 136 190 340 136 235 340 minecraft:andesite
fill 136 190 343 136 232 343 minecraft:andesite
setblock 136 190 349 minecraft:raw_iron_block
fill 136 190 350 136 199 353 minecraft:andesite
fill 136 190 361 136 247 361 minecraft:andesite
fill 94 191 326 94 192 326 minecraft:andesite
setblock 94 191 350 minecraft:andesite
setblock 95 191 323 minecraft:stone
setblock 95 191 324 minecraft:stripped_spruce_log
fill 95 191 325 95 191 328 minecraft:stone
setblock 95 191 329 minecraft:stripped_spruce_log
fill 95 191 330 95 191 333 minecraft:stone
setblock 95 191 334 minecraft:stripped_spruce_log
fill 95 191 335 95 191 338 minecraft:stone
setblock 95 191 339 minecraft:stripped_spruce_log
fill 95 191 340 95 191 343 minecraft:stone
setblock 95 191 344 minecraft:stripped_spruce_log
fill 95 191 345 95 194 345 minecraft:stone
setblock 95 191 348 minecraft:stone
setblock 95 191 349 minecraft:stripped_spruce_log
fill 95 191 350 95 191 352 minecraft:stone
setblock 95 191 354 minecraft:stripped_spruce_log
fill 95 191 355 95 191 358 minecraft:stone
setblock 95 191 359 minecraft:stripped_spruce_log
fill 95 191 360 95 191 363 minecraft:stone
setblock 96 191 323 minecraft:stripped_spruce_log
fill 96 191 324 96 191 327 minecraft:stone
setblock 96 191 328 minecraft:stripped_spruce_log
fill 96 191 329 96 191 332 minecraft:stone
setblock 96 191 333 minecraft:stripped_spruce_log
fill 96 191 334 96 191 337 minecraft:stone
setblock 96 191 338 minecraft:stripped_spruce_log
fill 96 191 339 96 194 339 minecraft:stone
setblock 96 191 343 minecraft:stripped_spruce_log
fill 96 191 344 96 194 344 minecraft:stone
setblock 96 191 348 minecraft:stripped_spruce_log
setblock 96 191 358 minecraft:stripped_spruce_log
fill 96 191 359 96 192 359 minecraft:stone
fill 96 191 361 96 191 362 minecraft:stone
setblock 96 191 363 minecraft:stripped_spruce_log
fill 97 191 323 97 191 326 minecraft:stone
setblock 97 191 327 minecraft:stripped_spruce_log
fill 97 191 328 97 194 328 minecraft:stone
setblock 97 191 332 minecraft:stripped_spruce_log
fill 97 191 333 97 192 333 minecraft:stone
setblock 97 191 337 minecraft:stripped_spruce_log
fill 97 191 338 97 194 338 minecraft:stone
setblock 97 191 342 minecraft:stripped_spruce_log
fill 97 191 343 97 194 343 minecraft:stone
setblock 97 191 346 minecraft:stone
setblock 97 191 361 minecraft:stone
setblock 97 191 362 minecraft:stripped_spruce_log
fill 97 191 363 100 191 363 minecraft:stone
fill 98 191 323 98 191 325 minecraft:stone
setblock 98 191 336 minecraft:stripped_spruce_log
setblock 98 191 337 minecraft:stone
setblock 98 191 341 minecraft:stripped_spruce_log
fill 98 191 342 98 192 342 minecraft:stone
setblock 98 191 361 minecraft:stripped_spruce_log
fill 98 191 362 101 191 362 minecraft:stone
fill 99 191 323 99 191 324 minecraft:stone
setblock 99 191 325 minecraft:stripped_spruce_log
setblock 99 191 361 minecraft:stone
setblock 100 191 323 minecraft:stone
setblock 100 191 324 minecraft:stripped_spruce_log
fill 100 191 325 100 194 325 minecraft:stone
setblock 101 191 323 minecraft:stripped_spruce_log
fill 101 191 324 101 194 324 minecraft:stone
setblock 101 191 363 minecraft:stripped_spruce_log
fill 102 191 323 105 191 323 minecraft:stone
setblock 102 191 362 minecraft:stripped_spruce_log
fill 102 191 363 105 191 363 minecraft:stone
fill 103 191 362 103 193 362 minecraft:stone
setblock 105 191 324 minecraft:stripped_spruce_log
setblock 106 191 323 minecraft:stripped_spruce_log
fill 106 191 324 109 191 324 minecraft:stone
setblock 106 191 363 minecraft:stripped_spruce_log
fill 107 191 323 110 191 323 minecraft:stone
setblock 107 191 362 minecraft:stripped_spruce_log
fill 107 191 363 110 191 363 minecraft:stone
fill 108 191 362 111 191 362 minecraft:stone
setblock 110 191 324 minecraft:stripped_spruce_log
setblock 111 191 323 minecraft:stripped_spruce_log
fill 111 191 324 114 191 324 minecraft:stone
fill 111 191 361 112 191 361 minecraft:stone
setblock 111 191 363 minecraft:stripped_spruce_log
fill 112 191 323 115 191 323 minecraft:stone
setblock 112 191 362 minecraft:stripped_spruce_log
fill 112 191 363 115 191 363 minecraft:stone
setblock 113 191 361 minecraft:stripped_spruce_log
fill 113 191 362 116 191 362 minecraft:stone
setblock 114 191 360 minecraft:stripped_spruce_log
fill 114 191 361 114 194 361 minecraft:stone
setblock 115 191 324 minecraft:stripped_spruce_log
fill 115 191 360 115 193 360 minecraft:stone
setblock 116 191 323 minecraft:stripped_spruce_log
fill 116 191 324 116 194 324 minecraft:stone
setblock 116 191 363 minecraft:stripped_spruce_log
fill 117 191 323 120 191 323 minecraft:stone
setblock 117 191 362 minecraft:stripped_spruce_log
fill 117 191 363 120 191 363 minecraft:stone
setblock 118 191 361 minecraft:stripped_spruce_log
fill 118 191 362 121 191 362 minecraft:stone
setblock 119 191 360 minecraft:stripped_spruce_log
fill 119 191 361 119 194 361 minecraft:stone
setblock 120 191 324 minecraft:stripped_spruce_log
fill 120 191 360 120 192 360 minecraft:stone
setblock 121 191 323 minecraft:stripped_spruce_log
fill 121 191 324 121 192 324 minecraft:stone
setblock 121 191 363 minecraft:stripped_spruce_log
fill 122 191 323 122 194 323 minecraft:stone
setblock 122 191 362 minecraft:stripped_spruce_log
fill 122 191 363 125 191 363 minecraft:stone
setblock 123 191 361 minecraft:stripped_spruce_log
fill 123 191 362 123 194 362 minecraft:stone
setblock 124 191 361 minecraft:stone
setblock 126 191 363 minecraft:stripped_spruce_log
setblock 127 191 362 minecraft:stripped_spruce_log
fill 127 191 363 130 191 363 minecraft:stone
setblock 128 191 362 minecraft:stone
setblock 131 191 362 minecraft:stone
setblock 131 191 363 minecraft:stripped_spruce_log
fill 132 191 323 132 194 323 minecraft:stone
setblock 132 191 362 minecraft:stripped_spruce_log
fill 132 191 363 132 194 363 minecraft:stone
fill 133 191 337 133 191 340 minecraft:stone
setblock 133 191 341 minecraft:stripped_spruce_log
fill 133 191 342 133 194 342 minecraft:stone
setblock 133 191 345 minecraft:stone
setblock 133 191 346 minecraft:stripped_spruce_log
fill 133 191 362 133 193 362 minecraft:stone
setblock 134 191 334 minecraft:stone
setblock 134 191 335 minecraft:stripped_spruce_log
fill 134 191 336 134 194 336 minecraft:stone
setblock 134 191 339 minecraft:stone
setblock 134 191 340 minecraft:stripped_spruce_log
fill 134 191 341 134 194 341 minecraft:stone
setblock 134 191 345 minecraft:stripped_spruce_log
fill 134 191 346 134 194 346 minecraft:stone
fill 134 191 348 134 191 349 minecraft:stone
setblock 134 191 350 minecraft:stripped_spruce_log
setblock 134 191 360 minecraft:stripped_spruce_log
fill 134 191 361 134 193 361 minecraft:stone
setblock 135 191 324 minecraft:stripped_spruce_log
fill 135 191 325 135 191 328 minecraft:stone
setblock 135 191 329 minecraft:stripped_spruce_log
fill 135 191 330 135 191 333 minecraft:stone
setblock 135 191 334 minecraft:stripped_spruce_log
fill 135 191 335 135 194 335 minecraft:stone
setblock 135 191 339 minecraft:stripped_spruce_log
fill 135 191 340 135 194 340 minecraft:stone
setblock 135 191 344 minecraft:stripped_spruce_log
fill 135 191 345 135 194 345 minecraft:stone
setblock 135 191 348 minecraft:stone
setblock 135 191 349 minecraft:stripped_spruce_log
fill 135 191 350 135 191 353 minecraft:stone
setblock 135 191 354 minecraft:stripped_spruce_log
fill 135 191 355 135 194 355 minecraft:stone
setblock 135 191 359 minecraft:stripped_spruce_log
fill 135 191 360 135 194 360 minecraft:stone
fill 136 191 349 136 247 349 minecraft:andesite
setblock 94 192 350 minecraft:gold_block
setblock 95 192 323 minecraft:stripped_spruce_log
fill 95 192 324 95 192 327 minecraft:stone
setblock 95 192 328 minecraft:stripped_spruce_log
fill 95 192 329 95 192 332 minecraft:stone
setblock 95 192 333 minecraft:stripped_spruce_log
fill 95 192 334 95 192 337 minecraft:stone
setblock 95 192 338 minecraft:stripped_spruce_log
fill 95 192 339 95 192 342 minecraft:stone
setblock 95 192 343 minecraft:stripped_spruce_log
fill 95 192 344 95 195 344 minecraft:stone
setblock 95 192 347 minecraft:stone
setblock 95 192 348 minecraft:stripped_spruce_log
fill 95 192 349 95 192 351 minecraft:stone
fill 95 192 356 95 192 357 minecraft:stone
setblock 95 192 358 minecraft:stripped_spruce_log
fill 95 192 359 95 192 362 minecraft:stone
setblock 95 192 363 minecraft:stripped_spruce_log
fill 96 192 323 96 192 326 minecraft:stone
setblock 96 192 327 minecraft:stripped_spruce_log
fill 96 192 328 96 192 331 minecraft:stone
setblock 96 192 332 minecraft:stripped_spruce_log
fill 96 192 333 96 192 336 minecraft:stone
setblock 96 192 337 minecraft:stripped_spruce_log
fill 96 192 338 96 195 338 minecraft:stone
setblock 96 192 342 minecraft:stripped_spruce_log
fill 96 192 343 96 195 343 minecraft:stone
setblock 96 192 347 minecraft:stripped_spruce_log
fill 96 192 348 96 195 348 minecraft:stone
setblock 96 192 361 minecraft:stone
setblock 96 192 362 minecraft:stripped_spruce_log
fill 96 192 363 99 192 363 minecraft:stone
fill 97 192 323 97 192 325 minecraft:stone
setblock 97 192 326 minecraft:stripped_spruce_log
fill 97 192 327 97 195 327 minecraft:stone
fill 97 192 330 97 199 330 minecraft:iron_bars
setblock 97 192 332 minecraft:stone
setblock 97 192 336 minecraft:stripped_spruce_log
fill 97 192 337 97 193 337 minecraft:stone
setblock 97 192 341 minecraft:stripped_spruce_log
fill 97 192 342 97 195 342 minecraft:stone
setblock 97 192 346 minecraft:stripped_spruce_log
fill 97 192 362 100 192 362 minecraft:stone
fill 98 192 323 98 192 324 minecraft:stone
setblock 98 192 325 minecraft:stripped_spruce_log
setblock 98 192 340 minecraft:stripped_spruce_log
setblock 98 192 341 minecraft:stone
setblock 99 192 323 minecraft:stone
setblock 99 192 324 minecraft:stripped_spruce_log
fill 99 192 325 99 195 325 minecraft:stone
setblock 100 192 323 minecraft:stripped_spruce_log
fill 100 192 324 100 195 324 minecraft:stone
setblock 100 192 363 minecraft:stripped_spruce_log
fill 101 192 323 104 192 323 minecraft:stone
setblock 101 192 362 minecraft:stripped_spruce_log
fill 101 192 363 104 192 363 minecraft:stone
fill 102 192 362 102 193 362 minecraft:stone
setblock 104 192 324 minecraft:stripped_spruce_log
setblock 105 192 323 minecraft:stripped_spruce_log
fill 105 192 324 108 192 324 minecraft:stone
setblock 105 192 363 minecraft:stripped_spruce_log
fill 106 192 323 109 192 323 minecraft:stone
setblock 106 192 362 minecraft:stripped_spruce_log
fill 106 192 363 109 192 363 minecraft:stone
fill 107 192 362 110 192 362 minecraft:stone
setblock 109 192 324 minecraft:stripped_spruce_log
setblock 110 192 323 minecraft:stripped_spruce_log
fill 110 192 324 113 192 324 minecraft:stone
setblock 110 192 363 minecraft:stripped_spruce_log
fill 111 192 323 114 192 323 minecraft:stone
setblock 111 192 361 minecraft:stone
setblock 111 192 362 minecraft:stripped_spruce_log
fill 111 192 363 114 192 363 minecraft:stone
setblock 112 192 361 minecraft:stripped_spruce_log
fill 112 192 362 115 192 362 minecraft:stone
fill 113 192 361 113 195 361 minecraft:stone
setblock 114 192 324 minecraft:stripped_spruce_log
setblock 114 192 360 minecraft:stone
setblock 115 192 323 minecraft:stripped_spruce_log
fill 115 192 324 115 195 324 minecraft:stone
setblock 115 192 363 minecraft:stripped_spruce_log
fill 116 192 323 119 192 323 minecraft:stone
setblock 116 192 325 minecraft:stone
setblock 116 192 362 minecraft:stripped_spruce_log
fill 116 192 363 119 192 363 minecraft:stone
setblock 117 192 361 minecraft:stripped_spruce_log
fill 117 192 362 120 192 362 minecraft:stone
setblock 118 192 360 minecraft:stripped_spruce_log
fill 118 192 361 118 195 361 minecraft:stone
setblock 119 192 324 minecraft:stripped_spruce_log
setblock 119 192 360 minecraft:stone
setblock 120 192 323 minecraft:stripped_spruce_log
fill 120 192 324 120 194 324 minecraft:stone
setblock 120 192 363 minecraft:stripped_spruce_log
fill 121 192 323 121 195 323 minecraft:stone
setblock 121 192 362 minecraft:stripped_spruce_log
fill 121 192 363 124 192 363 minecraft:stone
fill 122 192 324 122 193 333 minecraft:stripped_spruce_log
setblock 122 192 361 minecraft:stripped_spruce_log
fill 122 192 362 122 194 362 minecraft:stone
fill 123 192 329 123 193 340 minecraft:stripped_spruce_log
setblock 123 192 361 minecraft:stone
setblock 125 192 363 minecraft:stripped_spruce_log
fill 126 192 362 126 194 362 minecraft:stripped_spruce_log
fill 126 192 363 129 192 363 minecraft:stone
setblock 130 192 363 minecraft:stripped_spruce_log
fill 131 192 363 131 195 363 minecraft:stone
setblock 131 192 364 minecraft:diamond_block
setblock 132 192 362 minecraft:stone
fill 133 192 338 133 192 339 minecraft:stone
setblock 133 192 340 minecraft:stripped_spruce_log
fill 133 192 341 133 195 341 minecraft:stone
setblock 133 192 345 minecraft:stripped_spruce_log
fill 133 192 346 133 194 347 minecraft:stone
setblock 134 192 323 minecraft:stone
setblock 134 192 334 minecraft:stripped_spruce_log
fill 134 192 335 134 194 335 minecraft:stone
setblock 134 192 339 minecraft:stripped_spruce_log
fill 134 192 340 134 195 340 minecraft:stone
setblock 134 192 344 minecraft:stripped_spruce_log
fill 134 192 345 134 195 345 minecraft:stone
setblock 134 192 348 minecraft:stone
setblock 134 192 349 minecraft:stripped_spruce_log
fill 134 192 350 135 194 350 minecraft:stone
setblock 134 192 359 minecraft:stripped_spruce_log
fill 134 192 360 134 193 360 minecraft:stone
setblock 135 192 323 minecraft:stripped_spruce_log
fill 135 192 324 135 192 327 minecraft:stone
setblock 135 192 328 minecraft:stripped_spruce_log
fill 135 192 329 135 192 332 minecraft:stone
setblock 135 192 333 minecraft:stripped_spruce_log
fill 135 192 334 135 195 334 minecraft:stone
setblock 135 192 338 minecraft:stripped_spruce_log
fill 135 192 339 135 195 339 minecraft:stone
setblock 135 192 343 minecraft:stripped_spruce_log
fill 135 192 344 135 195 344 minecraft:stone
setblock 135 192 348 minecraft:stripped_spruce_log
fill 135 192 349 135 195 349 minecraft:stone
fill 135 192 351 135 192 352 minecraft:stone
setblock 135 192 353 minecraft:stripped_spruce_log
fill 135 192 354 135 194 354 minecraft:stone
setblock 135 192 358 minecraft:stripped_spruce_log
fill 135 192 359 135 195 359 minecraft:stone
setblock 135 192 363 minecraft:stripped_spruce_log
fill 136 192 335 136 247 335 minecraft:andesite
setblock 136 192 336 minecraft:gold_block
fill 136 192 337 136 220 337 minecraft:andesite
setblock 94 193 326 minecraft:raw_iron_block
fill 94 193 350 94 245 350 minecraft:andesite
fill 94 193 358 94 203 361 minecraft:andesite
setblock 94 193 362 minecraft:diamond_block
fill 95 193 323 95 193 326 minecraft:stone
setblock 95 193 327 minecraft:stripped_spruce_log
fill 95 193 328 95 193 331 minecraft:stone
setblock 95 193 332 minecraft:stripped_spruce_log
fill 95 193 333 95 193 336 minecraft:stone
setblock 95 193 337 minecraft:stripped_spruce_log
fill 95 193 338 95 193 341 minecraft:stone
setblock 95 193 342 minecraft:stripped_spruce_log
fill 95 193 343 95 196 343 minecraft:stone
setblock 95 193 347 minecraft:stripped_spruce_log
fill 95 193 348 95 194 350 minecraft:stone
setblock 95 193 357 minecraft:stripped_spruce_log
fill 95 193 358 95 193 361 minecraft:stone
setblock 95 193 362 minecraft:stripped_spruce_log
fill 95 193 363 98 193 363 minecraft:stone
fill 96 193 323 96 193 325 minecraft:stone
setblock 96 193 326 minecraft:stripped_spruce_log
fill 96 193 327 96 193 330 minecraft:stone
setblock 96 193 331 minecraft:stripped_spruce_log
fill 96 193 332 96 193 335 minecraft:stone
setblock 96 193 336 minecraft:stripped_spruce_log
fill 96 193 337 96 196 337 minecraft:stone
setblock 96 193 341 minecraft:stripped_spruce_log
fill 96 193 342 96 196 342 minecraft:stone
setblock 96 193 346 minecraft:stripped_spruce_log
fill 96 193 347 96 196 347 minecraft:stone
setblock 96 193 361 minecraft:stripped_spruce_log
fill 96 193 362 99 193 362 minecraft:stone
fill 97 193 323 97 193 324 minecraft:stone
setblock 97 193 325 minecraft:stripped_spruce_log
fill 97 193 326 97 196 326 minecraft:stone
setblock 97 193 332 minecraft:light[level=12]
setblock 97 193 335 minecraft:stripped_spruce_log
setblock 97 193 336 minecraft:stone
setblock 97 193 340 minecraft:stripped_spruce_log
fill 97 193 341 97 195 341 minecraft:stone
setblock 97 193 345 minecraft:stripped_spruce_log
setblock 97 193 346 minecraft:light[level=12]
setblock 97 193 353 minecraft:light[level=12]
setblock 97 193 360 minecraft:light[level=12]
setblock 98 193 323 minecraft:stone
setblock 98 193 324 minecraft:stripped_spruce_log
fill 98 193 325 98 196 325 minecraft:stone
setblock 99 193 323 minecraft:stripped_spruce_log
fill 99 193 324 99 196 324 minecraft:stone
setblock 99 193 363 minecraft:stripped_spruce_log
fill 100 193 323 103 193 323 minecraft:stone
setblock 100 193 362 minecraft:stripped_spruce_log
fill 100 193 363 103 193 363 minecraft:stone
fill 101 193 362 101 194 362 minecraft:stone
setblock 103 193 324 minecraft:stripped_spruce_log
setblock 104 193 323 minecraft:stripped_spruce_log
fill 104 193 324 107 193 324 minecraft:stone
setblock 104 193 325 minecraft:light[level=12]
setblock 104 193 332 minecraft:light[level=12]
setblock 104 193 339 minecraft:light[level=12]
setblock 104 193 346 minecraft:light[level=12]
setblock 104 193 353 minecraft:light[level=12]
setblock 104 193 360 minecraft:light[level=12]
setblock 104 193 363 minecraft:stripped_spruce_log
fill 105 193 323 108 193 323 minecraft:stone
fill 105 193 363 108 193 363 minecraft:stone
fill 107 193 362 109 193 362 minecraft:stone
setblock 108 193 324 minecraft:stripped_spruce_log
setblock 109 193 323 minecraft:stripped_spruce_log
fill 109 193 324 112 193 324 minecraft:stone
setblock 109 193 363 minecraft:stripped_spruce_log
fill 110 193 323 113 193 323 minecraft:stone
setblock 110 193 362 minecraft:stripped_spruce_log
fill 110 193 363 113 193 363 minecraft:stone
setblock 111 193 325 minecraft:light[level=12]
setblock 111 193 332 minecraft:light[level=12]
setblock 111 193 339 minecraft:light[level=12]
setblock 111 193 346 minecraft:light[level=12]
setblock 111 193 353 minecraft:light[level=12]
setblock 111 193 360 minecraft:light[level=12]
setblock 111 193 361 minecraft:stripped_spruce_log
fill 111 193 362 114 193 362 minecraft:stone
fill 112 193 361 112 195 361 minecraft:stone
setblock 113 193 324 minecraft:stripped_spruce_log
setblock 114 193 323 minecraft:stripped_spruce_log
fill 114 193 324 114 196 324 minecraft:stone
setblock 114 193 363 minecraft:stripped_spruce_log
fill 115 193 323 118 193 323 minecraft:stone
setblock 115 193 362 minecraft:stripped_spruce_log
fill 115 193 363 118 193 363 minecraft:stone
setblock 116 193 361 minecraft:stripped_spruce_log
fill 116 193 362 119 193 362 minecraft:stone
setblock 117 193 360 minecraft:stripped_spruce_log
fill 117 193 361 117 196 361 minecraft:stone
setblock 118 193 324 minecraft:stripped_spruce_log
setblock 118 193 325 minecraft:light[level=12]
setblock 118 193 332 minecraft:light[level=12]
setblock 118 193 339 minecraft:light[level=12]
setblock 118 193 346 minecraft:light[level=12]
setblock 118 193 353 minecraft:light[level=12]
setblock 118 193 360 minecraft:stone
setblock 119 193 323 minecraft:stripped_spruce_log
fill 119 193 324 119 195 324 minecraft:stone
setblock 119 193 363 minecraft:stripped_spruce_log
fill 120 193 323 120 196 323 minecraft:stone
setblock 120 193 362 minecraft:stripped_spruce_log
fill 120 193 363 123 193 363 minecraft:stone
fill 121 193 324 121 193 325 minecraft:stripped_spruce_log
setblock 121 193 361 minecraft:stripped_spruce_log
fill 121 193 362 121 195 362 minecraft:stone
fill 122 193 334 122 193 336 minecraft:stripped_spruce_log
setblock 122 193 361 minecraft:stone
fill 123 193 327 123 193 328 minecraft:stripped_spruce_log
fill 123 193 341 124 193 347 minecraft:stripped_spruce_log
fill 124 193 338 124 193 340 minecraft:stripped_spruce_log
fill 124 193 348 125 193 357 minecraft:stripped_spruce_log
setblock 124 193 363 minecraft:stripped_spruce_log
setblock 125 193 325 minecraft:light[level=12]
setblock 125 193 332 minecraft:light[level=12]
setblock 125 193 339 minecraft:light[level=12]
setblock 125 193 346 minecraft:light[level=12]
fill 125 193 358 125 194 362 minecraft:stripped_spruce_log
fill 125 193 363 128 193 363 minecraft:stone
fill 126 193 359 126 193 361 minecraft:stripped_spruce_log
fill 128 193 322 129 193 322 minecraft:andesite
setblock 129 193 363 minecraft:stripped_spruce_log
setblock 130 193 322 minecraft:raw_iron_block
fill 130 193 363 130 194 363 minecraft:stone
fill 131 193 322 136 218 322 minecraft:andesite
fill 131 193 323 131 195 323 minecraft:stone
fill 131 193 364 131 204 364 minecraft:andesite
setblock 132 193 325 minecraft:light[level=12]
setblock 132 193 332 minecraft:light[level=12]
setblock 132 193 339 minecraft:light[level=12]
setblock 132 193 346 minecraft:light[level=12]
setblock 132 193 353 minecraft:light[level=12]
setblock 132 193 360 minecraft:light[level=12]
setblock 133 193 338 minecraft:stone
setblock 133 193 339 minecraft:stripped_spruce_log
fill 133 193 340 133 196 340 minecraft:stone
setblock 133 193 344 minecraft:stripped_spruce_log
fill 133 193 345 133 196 345 minecraft:stone
setblock 134 193 323 minecraft:stripped_spruce_log
fill 134 193 324 135 195 324 minecraft:stone
setblock 134 193 338 minecraft:stripped_spruce_log
fill 134 193 339 134 196 339 minecraft:stone
setblock 134 193 343 minecraft:stripped_spruce_log
fill 134 193 344 134 196 344 minecraft:stone
setblock 134 193 348 minecraft:stripped_spruce_log
fill 134 193 349 134 196 349 minecraft:stone
setblock 134 193 363 minecraft:stripped_spruce_log
fill 135 193 323 135 196 323 minecraft:stone
fill 135 193 325 135 193 326 minecraft:stone
setblock 135 193 327 minecraft:stripped_spruce_log
fill 135 193 328 135 193 331 minecraft:stone
setblock 135 193 332 minecraft:stripped_spruce_log
fill 135 193 333 135 196 333 minecraft:stone
setblock 135 193 337 minecraft:stripped_spruce_log
fill 135 193 338 135 196 338 minecraft:stone
setblock 135 193 342 minecraft:stripped_spruce_log
fill 135 193 343 135 196 343 minecraft:stone
setblock 135 193 347 minecraft:stripped_spruce_log
fill 135 193 348 135 196 348 minecraft:stone
setblock 135 193 351 minecraft:stone
setblock 135 193 352 minecraft:stripped_spruce_log
fill 135 193 353 135 196 353 minecraft:stone
setblock 135 193 357 minecraft:stripped_spruce_log
fill 135 193 358 135 194 358 minecraft:stone
setblock 135 193 362 minecraft:stripped_spruce_log
fill 135 193 363 135 196 363 minecraft:stone
fill 136 193 336 136 247 336 minecraft:andesite
fill 136 193 341 136 203 341 minecraft:andesite
setblock 136 193 342 minecraft:diamond_block
fill 94 194 326 94 215 326 minecraft:andesite
fill 94 194 362 94 215 362 minecraft:andesite
setblock 94 194 363 minecraft:gold_block
fill 94 194 364 94 247 364 minecraft:andesite
fill 95 194 323 95 194 325 minecraft:stone
setblock 95 194 326 minecraft:stripped_spruce_log
fill 95 194 327 95 194 330 minecraft:stone
setblock 95 194 331 minecraft:stripped_spruce_log
fill 95 194 332 95 194 335 minecraft:stone
setblock 95 194 336 minecraft:stripped_spruce_log
fill 95 194 337 95 194 340 minecraft:stone
setblock 95 194 341 minecraft:stripped_spruce_log
fill 95 194 342 95 197 342 minecraft:stone
setblock 95 194 346 minecraft:stripped_spruce_log
fill 95 194 347 95 197 347 minecraft:stone
fill 95 194 359 95 194 360 minecraft:stone
setblock 95 194 361 minecraft:stripped_spruce_log
fill 95 194 362 97 194 363 minecraft:stone
fill 96 194 323 96 194 324 minecraft:stone
setblock 96 194 325 minecraft:stripped_spruce_log
fill 96 194 326 96 194 329 minecraft:stone
setblock 96 194 330 minecraft:stripped_spruce_log
fill 96 194 331 96 194 334 minecraft:stone
setblock 96 194 335 minecraft:stripped_spruce_log
fill 96 194 336 96 196 336 minecraft:stone
setblock 96 194 340 minecraft:stripped_spruce_log
fill 96 194 341 96 197 341 minecraft:stone
setblock 96 194 345 minecraft:stripped_spruce_log
fill 96 194 346 96 197 346 minecraft:stone
setblock 96 194 361 minecraft:stone
setblock 97 194 323 minecraft:stone
setblock 97 194 324 minecraft:stripped_spruce_log
fill 97 194 325 97 197 325 minecraft:stone
setblock 97 194 339 minecraft:stripped_spruce_log
setblock 97 194 340 minecraft:stone
setblock 97 194 344 minecraft:stripped_spruce_log
setblock 97 194 345 minecraft:stone
setblock 98 194 323 minecraft:stripped_spruce_log
fill 98 194 324 98 197 324 minecraft:stone
setblock 98 194 362 minecraft:stone
setblock 98 194 363 minecraft:stripped_spruce_log
fill 99 194 323 102 194 323 minecraft:stone
setblock 99 194 362 minecraft:stripped_spruce_log
fill 99 194 363 102 194 363 minecraft:stone
setblock 100 194 362 minecraft:stone
setblock 101 194 325 minecraft:stripped_spruce_log
setblock 102 194 324 minecraft:stripped_spruce_log
setblock 103 194 323 minecraft:stripped_spruce_log
fill 103 194 324 106 194 324 minecraft:stone
setblock 103 194 363 minecraft:stripped_spruce_log
fill 104 194 323 107 194 323 minecraft:stone
fill 104 194 363 107 194 363 minecraft:stone
setblock 107 194 324 minecraft:stripped_spruce_log
setblock 108 194 323 minecraft:stripped_spruce_log
fill 108 194 324 111 194 324 minecraft:stone
setblock 108 194 362 minecraft:stone
setblock 108 194 363 minecraft:stripped_spruce_log
fill 109 194 323 112 194 323 minecraft:stone
setblock 109 194 362 minecraft:stripped_spruce_log
fill 109 194 363 112 194 363 minecraft:stone
fill 110 194 362 113 194 362 minecraft:stone
setblock 112 194 324 minecraft:stripped_spruce_log
setblock 113 194 323 minecraft:stripped_spruce_log
fill 113 194 324 113 197 324 minecraft:stone
setblock 113 194 363 minecraft:stripped_spruce_log
fill 114 194 323 117 194 323 minecraft:stone
setblock 114 194 362 minecraft:stripped_spruce_log
fill 114 194 363 117 194 363 minecraft:stone
fill 114 194 364 114 236 364 minecraft:andesite
setblock 115 194 361 minecraft:stripped_spruce_log
fill 115 194 362 118 194 362 minecraft:stone
setblock 115 194 364 minecraft:diamond_block
fill 116 194 361 116 196 361 minecraft:stone
fill 116 194 364 119 202 364 minecraft:andesite
setblock 117 194 324 minecraft:stripped_spruce_log
setblock 118 194 323 minecraft:stripped_spruce_log
fill 118 194 324 118 197 324 minecraft:stone
setblock 118 194 363 minecraft:stripped_spruce_log
fill 119 194 323 119 197 323 minecraft:stone
setblock 119 194 362 minecraft:stripped_spruce_log
fill 119 194 363 122 194 363 minecraft:stone
setblock 120 194 361 minecraft:stripped_spruce_log
fill 120 194 362 120 196 362 minecraft:stone
fill 122 194 324 122 194 331 minecraft:stripped_dark_oak_log
setblock 123 194 323 minecraft:stripped_spruce_log
fill 123 194 331 123 194 341 minecraft:stripped_dark_oak_log
setblock 123 194 363 minecraft:stripped_spruce_log
setblock 124 194 344 minecraft:stripped_dark_oak_log
fill 124 194 345 124 194 354 minecraft:stripped_spruce_log
fill 124 194 363 127 194 363 minecraft:stone
fill 125 194 352 125 194 357 minecraft:stripped_spruce_log
fill 126 194 360 126 194 361 minecraft:stripped_spruce_log
setblock 128 194 322 minecraft:raw_gold_block
fill 129 194 322 130 243 322 minecraft:andesite
setblock 129 194 363 minecraft:stone
setblock 133 194 323 minecraft:stripped_spruce_log
fill 133 194 339 133 195 339 minecraft:stone
setblock 133 194 343 minecraft:stripped_spruce_log
fill 133 194 344 133 197 344 minecraft:stone
setblock 133 194 363 minecraft:stripped_spruce_log
fill 134 194 323 134 197 323 minecraft:stone
fill 134 194 325 135 194 325 minecraft:stone
setblock 134 194 337 minecraft:stripped_spruce_log
fill 134 194 338 134 197 338 minecraft:stone
setblock 134 194 342 minecraft:stripped_spruce_log
fill 134 194 343 134 195 343 minecraft:stone
setblock 134 194 347 minecraft:stripped_spruce_log
fill 134 194 348 134 197 348 minecraft:stone
setblock 134 194 362 minecraft:stripped_spruce_log
fill 134 194 363 134 197 363 minecraft:stone
setblock 135 194 326 minecraft:stripped_spruce_log
fill 135 194 327 135 194 330 minecraft:stone
setblock 135 194 331 minecraft:stripped_spruce_log
fill 135 194 332 135 197 332 minecraft:stone
setblock 135 194 336 minecraft:stripped_spruce_log
fill 135 194 337 135 197 337 minecraft:stone
setblock 135 194 341 minecraft:stripped_spruce_log
fill 135 194 342 135 197 342 minecraft:stone
setblock 135 194 346 minecraft:stripped_spruce_log
fill 135 194 347 135 197 347 minecraft:stone
setblock 135 194 351 minecraft:stripped_spruce_log
fill 135 194 352 135 197 352 minecraft:stone
setblock 135 194 356 minecraft:stripped_spruce_log
setblock 135 194 357 minecraft:stone
setblock 135 194 361 minecraft:stripped_spruce_log
fill 135 194 362 135 197 362 minecraft:stone
setblock 136 194 342 minecraft:andesite
setblock 136 194 348 minecraft:gold_block
fill 94 195 363 94 229 363 minecraft:andesite
fill 95 195 323 95 195 324 minecraft:stone
setblock 95 195 325 minecraft:stripped_spruce_log
fill 95 195 326 95 195 329 minecraft:stone
setblock 95 195 330 minecraft:stripped_spruce_log
fill 95 195 331 95 195 334 minecraft:stone
setblock 95 195 335 minecraft:stripped_spruce_log
fill 95 195 336 95 195 339 minecraft:stone
setblock 95 195 340 minecraft:stripped_spruce_log
fill 95 195 341 95 198 341 minecraft:stone
setblock 95 195 345 minecraft:stripped_spruce_log
fill 95 195 346 95 198 346 minecraft:stone
fill 95 195 348 95 195 349 minecraft:stone
setblock 95 195 350 minecraft:stripped_spruce_log
setblock 95 195 360 minecraft:stripped_spruce_log
fill 95 195 361 95 196 363 minecraft:stone
setblock 96 195 323 minecraft:stone
setblock 96 195 324 minecraft:stripped_spruce_log
fill 96 195 325 96 195 328 minecraft:stone
setblock 96 195 329 minecraft:stripped_spruce_log
fill 96 195 330 96 195 333 minecraft:stone
setblock 96 195 334 minecraft:stripped_spruce_log
setblock 96 195 335 minecraft:stone
setblock 96 195 339 minecraft:stripped_spruce_log
fill 96 195 340 96 197 340 minecraft:stone
setblock 96 195 344 minecraft:stripped_spruce_log
fill 96 195 345 96 198 345 minecraft:stone
fill 96 195 362 96 195 363 minecraft:stone
setblock 97 195 322 minecraft:raw_gold_block
setblock 97 195 323 minecraft:stripped_spruce_log
fill 97 195 324 97 198 324 minecraft:stone
setblock 97 195 328 minecraft:stripped_spruce_log
setblock 97 195 333 minecraft:light[level=15]
fill 97 195 340 97 196 340 minecraft:iron_bars
setblock 97 195 343 minecraft:stripped_spruce_log
setblock 97 195 349 minecraft:light[level=15]
setblock 97 195 357 minecraft:light[level=15]
setblock 97 195 362 minecraft:stone
setblock 97 195 363 minecraft:stripped_spruce_log
fill 98 195 322 101 195 322 minecraft:andesite
fill 98 195 323 101 195 323 minecraft:stone
setblock 98 195 362 minecraft:stripped_spruce_log
fill 98 195 363 101 195 363 minecraft:stone
setblock 100 195 325 minecraft:stripped_spruce_log
setblock 101 195 324 minecraft:stripped_spruce_log
setblock 102 195 323 minecraft:stripped_spruce_log
fill 102 195 324 105 195 324 minecraft:stone
setblock 102 195 363 minecraft:stripped_spruce_log
fill 103 195 323 106 195 323 minecraft:stone
fill 103 195 363 106 195 363 minecraft:stone
setblock 105 195 325 minecraft:light[level=15]
setblock 105 195 333 minecraft:light[level=15]
setblock 105 195 341 minecraft:light[level=15]
setblock 105 195 349 minecraft:light[level=15]
setblock 105 195 357 minecraft:light[level=15]
setblock 106 195 324 minecraft:stripped_spruce_log
setblock 107 195 323 minecraft:stripped_spruce_log
fill 107 195 324 110 195 324 minecraft:stone
setblock 107 195 363 minecraft:stripped_spruce_log
fill 108 195 323 111 195 323 minecraft:stone
fill 108 195 363 111 195 363 minecraft:stone
fill 109 195 362 112 195 362 minecraft:stone
setblock 111 195 324 minecraft:stripped_spruce_log
setblock 112 195 323 minecraft:stripped_spruce_log
fill 112 195 324 112 198 324 minecraft:stone
setblock 112 195 363 minecraft:stripped_spruce_log
fill 113 195 323 116 195 323 minecraft:stone
setblock 113 195 325 minecraft:light[level=15]
setblock 113 195 333 minecraft:light[level=15]
setblock 113 195 341 minecraft:light[level=15]
setblock 113 195 349 minecraft:light[level=15]
setblock 113 195 357 minecraft:light[level=15]
setblock 113 195 362 minecraft:stripped_spruce_log
fill 113 195 363 116 195 363 minecraft:stone
setblock 114 195 361 minecraft:stripped_spruce_log
fill 114 195 362 117 195 362 minecraft:stone
fill 115 195 361 115 197 361 minecraft:stone
fill 115 195 364 115 228 364 minecraft:andesite
setblock 116 195 324 minecraft:stripped_spruce_log
setblock 117 195 323 minecraft:stripped_spruce_log
fill 117 195 324 117 198 324 minecraft:stone
setblock 117 195 363 minecraft:stripped_spruce_log
fill 118 195 323 118 198 323 minecraft:stone
setblock 118 195 362 minecraft:stripped_spruce_log
fill 118 195 363 121 195 363 minecraft:stone
fill 119 195 362 119 197 362 minecraft:stone
setblock 121 195 325 minecraft:light[level=15]
setblock 121 195 333 minecraft:light[level=15]
setblock 121 195 341 minecraft:light[level=15]
setblock 121 195 349 minecraft:light[level=15]
setblock 121 195 357 minecraft:light[level=15]
setblock 122 195 323 minecraft:stripped_spruce_log
setblock 122 195 363 minecraft:stripped_spruce_log
fill 123 195 363 124 195 363 minecraft:stone
fill 124 195 346 124 195 351 minecraft:stripped_dark_oak_log
fill 125 195 354 125 195 362 minecraft:stripped_dark_oak_log
fill 128 195 322 128 206 322 minecraft:andesite
setblock 129 195 325 minecraft:light[level=15]
setblock 129 195 333 minecraft:light[level=15]
setblock 129 195 341 minecraft:light[level=15]
setblock 129 195 349 minecraft:light[level=15]
setblock 129 195 357 minecraft:light[level=15]
setblock 132 195 323 minecraft:stripped_spruce_log
setblock 132 195 363 minecraft:stripped_spruce_log
fill 133 195 323 133 197 324 minecraft:stone
setblock 133 195 342 minecraft:stripped_spruce_log
fill 133 195 343 133 198 343 minecraft:stone
setblock 133 195 346 minecraft:stone
setblock 133 195 347 minecraft:stripped_spruce_log
fill 133 195 348 133 198 348 minecraft:stone
fill 133 195 363 133 198 363 minecraft:stone
setblock 134 195 325 minecraft:stone
setblock 134 195 326 minecraft:stripped_spruce_log
setblock 134 195 336 minecraft:stripped_spruce_log
fill 134 195 337 134 198 337 minecraft:stone
setblock 134 195 341 minecraft:stripped_spruce_log
fill 134 195 342 134 198 342 minecraft:stone
setblock 134 195 346 minecraft:stripped_spruce_log
fill 134 195 347 134 198 347 minecraft:stone
setblock 134 195 350 minecraft:stone
setblock 135 195 325 minecraft:stripped_spruce_log
fill 135 195 326 135 195 329 minecraft:stone
setblock 135 195 330 minecraft:stripped_spruce_log
fill 135 195 331 135 198 331 minecraft:stone
setblock 135 195 335 minecraft:stripped_spruce_log
fill 135 195 336 135 198 336 minecraft:stone
setblock 135 195 340 minecraft:stripped_spruce_log
fill 135 195 341 135 198 341 minecraft:stone
setblock 135 195 345 minecraft:stripped_spruce_log
fill 135 195 346 135 198 346 minecraft:stone
setblock 135 195 350 minecraft:stripped_spruce_log
fill 135 195 351 135 198 351 minecraft:stone
setblock 135 195 360 minecraft:stripped_spruce_log
fill 135 195 361 135 196 361 minecraft:stone
setblock 136 195 342 minecraft:raw_gold_block
fill 136 195 348 136 197 348 minecraft:andesite
setblock 94 196 324 minecraft:diamond_block
fill 94 196 325 94 244 325 minecraft:andesite
setblock 95 196 323 minecraft:stone
setblock 95 196 324 minecraft:stripped_spruce_log
fill 95 196 325 95 196 328 minecraft:stone
setblock 95 196 329 minecraft:stripped_spruce_log
fill 95 196 330 95 196 333 minecraft:stone
setblock 95 196 334 minecraft:stripped_spruce_log
fill 95 196 335 95 196 338 minecraft:stone
setblock 95 196 339 minecraft:stripped_spruce_log
fill 95 196 340 95 199 340 minecraft:stone
setblock 95 196 344 minecraft:stripped_spruce_log
fill 95 196 345 95 199 345 minecraft:stone
setblock 95 196 348 minecraft:stone
setblock 95 196 349 minecraft:stripped_spruce_log
fill 95 196 350 95 199 350 minecraft:stone
setblock 95 196 360 minecraft:stone
setblock 96 196 323 minecraft:stripped_spruce_log
fill 96 196 324 96 199 324 minecraft:spruce_log
fill 96 196 325 96 196 327 minecraft:stone
setblock 96 196 328 minecraft:stripped_spruce_log
fill 96 196 329 96 196 332 minecraft:stone
setblock 96 196 333 minecraft:stripped_spruce_log
setblock 96 196 338 minecraft:stripped_spruce_log
fill 96 196 339 96 197 339 minecraft:stone
fill 96 196 343 96 199 343 minecraft:spruce_log
fill 96 196 344 96 199 344 minecraft:stone
fill 96 196 362 96 199 362 minecraft:spruce_log
setblock 96 196 363 minecraft:stripped_spruce_log
fill 97 196 322 99 214 322 minecraft:andesite
fill 97 196 323 100 196 323 minecraft:stone
setblock 97 196 327 minecraft:stripped_spruce_log
fill 97 196 328 97 199 328 minecraft:stone
fill 97 196 363 100 196 363 minecraft:stone
setblock 99 196 325 minecraft:stripped_spruce_log
setblock 100 196 322 minecraft:diamond_block
setblock 100 196 324 minecraft:stripped_spruce_log
setblock 100 196 325 minecraft:stone
fill 101 196 322 101 217 322 minecraft:andesite
setblock 101 196 323 minecraft:stripped_spruce_log
fill 101 196 324 104 196 324 minecraft:stone
setblock 101 196 363 minecraft:stripped_spruce_log
fill 102 196 323 105 196 323 minecraft:stone
fill 102 196 363 105 196 363 minecraft:stone
setblock 105 196 324 minecraft:stripped_spruce_log
setblock 106 196 323 minecraft:stripped_spruce_log
fill 106 196 324 109 196 324 minecraft:stone
setblock 106 196 363 minecraft:stripped_spruce_log
fill 107 196 323 110 196 323 minecraft:stone
fill 107 196 363 110 196 363 minecraft:stone
fill 109 196 362 111 196 362 minecraft:stone
setblock 110 196 324 minecraft:stripped_spruce_log
setblock 111 196 323 minecraft:stripped_spruce_log
fill 111 196 324 111 199 324 minecraft:stone
setblock 111 196 363 minecraft:stripped_spruce_log
fill 112 196 323 115 196 323 minecraft:stone
setblock 112 196 362 minecraft:stripped_spruce_log
fill 112 196 363 115 196 363 minecraft:stone
setblock 113 196 361 minecraft:stripped_spruce_log
fill 113 196 362 114 198 362 minecraft:stone
fill 114 196 361 114 197 361 minecraft:stone
fill 115 196 324 115 199 324 minecraft:spruce_log
fill 115 196 362 115 199 362 minecraft:spruce_log
setblock 116 196 323 minecraft:stripped_spruce_log
fill 116 196 324 116 199 324 minecraft:stone
setblock 116 196 362 minecraft:stone
setblock 116 196 363 minecraft:stripped_spruce_log
fill 117 196 323 117 199 323 minecraft:stone
setblock 117 196 362 minecraft:stripped_spruce_log
fill 117 196 363 120 196 363 minecraft:stone
fill 118 196 362 118 198 362 minecraft:stone
setblock 121 196 323 minecraft:stripped_spruce_log
setblock 121 196 363 minecraft:stripped_spruce_log
setblock 122 196 363 minecraft:stone
setblock 130 196 323 minecraft:stone
setblock 131 196 323 minecraft:stripped_spruce_log
setblock 131 196 363 minecraft:stripped_spruce_log
fill 132 196 323 132 199 323 minecraft:stone
fill 132 196 363 132 199 363 minecraft:stone
setblock 133 196 341 minecraft:stripped_spruce_log
fill 133 196 342 133 199 342 minecraft:stone
setblock 133 196 346 minecraft:stripped_spruce_log
fill 133 196 347 133 199 347 minecraft:stone
fill 134 196 324 134 199 324 minecraft:spruce_log
setblock 134 196 325 minecraft:stripped_spruce_log
fill 134 196 326 135 196 328 minecraft:stone
fill 134 196 336 134 199 336 minecraft:stone
setblock 134 196 340 minecraft:stripped_spruce_log
fill 134 196 341 134 199 341 minecraft:stone
fill 134 196 343 134 199 343 minecraft:spruce_log
setblock 134 196 345 minecraft:stripped_spruce_log
fill 134 196 346 134 199 346 minecraft:stone
setblock 134 196 350 minecraft:stripped_spruce_log
fill 134 196 362 134 199 362 minecraft:spruce_log
setblock 135 196 324 minecraft:stripped_spruce_log
fill 135 196 325 135 199 325 minecraft:stone
setblock 135 196 329 minecraft:stripped_spruce_log
fill 135 196 330 135 199 330 minecraft:stone
setblock 135 196 334 minecraft:stripped_spruce_log
fill 135 196 335 135 199 335 minecraft:stone
setblock 135 196 339 minecraft:stripped_spruce_log
fill 135 196 340 135 199 340 minecraft:stone
setblock 135 196 344 minecraft:stripped_spruce_log
fill 135 196 345 135 199 345 minecraft:stone
setblock 135 196 349 minecraft:stripped_spruce_log
fill 135 196 350 135 199 350 minecraft:stone
fill 136 196 342 136 235 342 minecraft:andesite
fill 94 197 324 94 199 324 minecraft:andesite
setblock 94 197 351 minecraft:raw_iron_block
fill 94 197 352 94 201 356 minecraft:andesite
setblock 95 197 323 minecraft:stripped_spruce_log
fill 95 197 324 95 197 327 minecraft:stone
setblock 95 197 328 minecraft:stripped_spruce_log
fill 95 197 329 95 197 332 minecraft:stone
setblock 95 197 333 minecraft:stripped_spruce_log
fill 95 197 334 95 197 337 minecraft:stone
setblock 95 197 338 minecraft:stripped_spruce_log
fill 95 197 339 95 200 339 minecraft:stone
setblock 95 197 343 minecraft:stripped_spruce_log
fill 95 197 344 95 200 344 minecraft:stone
setblock 95 197 348 minecraft:stripped_spruce_log
fill 95 197 349 95 200 349 minecraft:stone
fill 95 197 351 95 198 351 minecraft:stone
fill 95 197 361 95 197 362 minecraft:stone
setblock 95 197 363 minecraft:stripped_spruce_log
fill 96 197 323 99 197 323 minecraft:stone
fill 96 197 325 96 197 326 minecraft:stone
setblock 96 197 327 minecraft:stripped_spruce_log
fill 96 197 328 96 197 331 minecraft:stone
setblock 96 197 332 minecraft:stripped_spruce_log
setblock 96 197 342 minecraft:stripped_spruce_log
setblock 96 197 347 minecraft:stripped_spruce_log
fill 96 197 363 99 197 363 minecraft:stone
setblock 97 197 326 minecraft:stripped_spruce_log
fill 97 197 327 97 200 327 minecraft:stone
setblock 98 197 325 minecraft:stripped_spruce_log
setblock 99 197 324 minecraft:stripped_spruce_log
fill 99 197 325 99 200 325 minecraft:stone
fill 100 197 322 100 245 322 minecraft:andesite
setblock 100 197 323 minecraft:stripped_spruce_log
fill 100 197 324 103 197 324 minecraft:stone
setblock 100 197 363 minecraft:stripped_spruce_log
fill 101 197 323 104 197 323 minecraft:stone
fill 101 197 363 104 197 363 minecraft:stone
fill 103 197 322 110 199 322 minecraft:andesite
setblock 104 197 324 minecraft:stripped_spruce_log
setblock 105 197 323 minecraft:stripped_spruce_log
fill 105 197 324 108 197 324 minecraft:stone
setblock 105 197 363 minecraft:stripped_spruce_log
fill 106 197 323 109 197 323 minecraft:stone
fill 106 197 363 109 197 363 minecraft:stone
setblock 109 197 324 minecraft:stripped_spruce_log
fill 109 197 362 110 197 362 minecraft:stone
setblock 110 197 323 minecraft:stripped_spruce_log
fill 110 197 324 110 200 324 minecraft:stone
setblock 110 197 363 minecraft:stripped_spruce_log
setblock 111 197 322 minecraft:gold_block
fill 111 197 323 114 197 323 minecraft:stone
setblock 111 197 362 minecraft:stripped_spruce_log
fill 111 197 363 114 197 363 minecraft:stone
fill 112 197 322 112 243 322 minecraft:andesite
fill 112 197 362 112 200 362 minecraft:stone
setblock 114 197 324 minecraft:stripped_spruce_log
setblock 115 197 323 minecraft:stripped_spruce_log
setblock 115 197 363 minecraft:stripped_spruce_log
fill 116 197 323 116 200 323 minecraft:stone
setblock 116 197 362 minecraft:stripped_spruce_log
fill 116 197 363 119 197 363 minecraft:stone
fill 117 197 362 117 199 362 minecraft:stone
setblock 120 197 323 minecraft:stripped_spruce_log
setblock 120 197 363 minecraft:stripped_spruce_log
setblock 121 197 363 minecraft:stone
fill 126 197 355 133 197 355 minecraft:raw_gold_block
setblock 130 197 323 minecraft:stripped_spruce_log
fill 131 197 323 131 200 323 minecraft:stone
fill 132 197 324 132 198 324 minecraft:stone
setblock 133 197 340 minecraft:stripped_spruce_log
fill 133 197 341 133 200 341 minecraft:stone
setblock 133 197 345 minecraft:stripped_spruce_log
fill 133 197 346 133 200 346 minecraft:stone
setblock 133 197 349 minecraft:stone
fill 134 197 325 134 197 328 minecraft:stone
setblock 134 197 329 minecraft:stripped_spruce_log
fill 134 197 330 134 200 330 minecraft:stone
setblock 134 197 339 minecraft:stripped_spruce_log
fill 134 197 340 134 200 340 minecraft:stone
setblock 134 197 344 minecraft:stripped_spruce_log
fill 134 197 345 134 200 345 minecraft:stone
setblock 134 197 349 minecraft:stripped_spruce_log
fill 134 197 350 134 199 351 minecraft:stone
setblock 135 197 323 minecraft:stripped_spruce_log
fill 135 197 324 135 200 324 minecraft:stone
fill 135 197 326 135 197 327 minecraft:stone
setblock 135 197 328 minecraft:stripped_spruce_log
fill 135 197 329 135 200 329 minecraft:stone
setblock 135 197 333 minecraft:stripped_spruce_log
fill 135 197 334 135 200 334 minecraft:stone
setblock 135 197 338 minecraft:stripped_spruce_log
fill 135 197 339 135 200 339 minecraft:stone
setblock 135 197 343 minecraft:stripped_spruce_log
fill 135 197 344 135 200 344 minecraft:stone
setblock 135 197 348 minecraft:stripped_spruce_log
fill 135 197 349 135 200 349 minecraft:stone
setblock 135 197 353 minecraft:stripped_spruce_log
setblock 135 197 363 minecraft:stripped_spruce_log
setblock 94 198 330 minecraft:raw_iron_block
setblock 94 198 341 minecraft:raw_iron_block
fill 94 198 351 94 247 351 minecraft:andesite
fill 95 198 323 95 198 326 minecraft:stone
setblock 95 198 327 minecraft:stripped_spruce_log
fill 95 198 328 95 198 331 minecraft:stone
setblock 95 198 332 minecraft:stripped_spruce_log
fill 95 198 333 95 198 336 minecraft:stone
setblock 95 198 337 minecraft:stripped_spruce_log
fill 95 198 338 95 201 338 minecraft:stone
setblock 95 198 342 minecraft:stripped_spruce_log
fill 95 198 343 95 201 343 minecraft:stone
setblock 95 198 347 minecraft:stripped_spruce_log
fill 95 198 348 96 200 348 minecraft:stone
fill 95 198 355 95 201 355 minecraft:raw_gold_block
setblock 95 198 361 minecraft:stone
setblock 95 198 362 minecraft:stripped_spruce_log
fill 95 198 363 98 198 363 minecraft:stone
fill 96 198 323 98 198 323 minecraft:stone
setblock 96 198 325 minecraft:stone
setblock 96 198 326 minecraft:stripped_spruce_log
fill 96 198 327 96 198 330 minecraft:stone
setblock 96 198 331 minecraft:stripped_spruce_log
fill 96 198 332 96 200 333 minecraft:stone
setblock 96 198 341 minecraft:stripped_spruce_log
setblock 96 198 342 minecraft:stone
setblock 96 198 346 minecraft:stripped_spruce_log
fill 96 198 347 96 201 347 minecraft:stone
setblock 97 198 325 minecraft:stripped_spruce_log
fill 97 198 326 97 201 326 minecraft:stone
setblock 97 198 329 minecraft:stone
setblock 98 198 324 minecraft:stripped_spruce_log
fill 98 198 325 98 201 325 minecraft:stone
setblock 99 198 323 minecraft:stripped_spruce_log
fill 99 198 324 102 198 324 minecraft:stone
setblock 99 198 363 minecraft:stripped_spruce_log
fill 100 198 323 103 198 323 minecraft:stone
fill 100 198 363 101 198 363 minecraft:stone
setblock 103 198 324 minecraft:stripped_spruce_log
setblock 104 198 323 minecraft:stripped_spruce_log
fill 104 198 324 107 198 324 minecraft:stone
setblock 104 198 363 minecraft:stripped_spruce_log
fill 105 198 323 108 198 323 minecraft:stone
fill 105 198 363 108 198 363 minecraft:stone
setblock 108 198 324 minecraft:stripped_spruce_log
setblock 109 198 323 minecraft:stripped_spruce_log
fill 109 198 324 109 201 324 minecraft:stone
setblock 109 198 362 minecraft:stone
setblock 109 198 363 minecraft:stripped_spruce_log
fill 110 198 323 113 198 323 minecraft:stone
setblock 110 198 362 minecraft:stripped_spruce_log
fill 110 198 363 113 198 363 minecraft:stone
fill 111 198 322 111 247 322 minecraft:andesite
fill 111 198 362 111 201 362 minecraft:stone
setblock 112 198 325 minecraft:stripped_spruce_log
setblock 113 198 324 minecraft:stripped_spruce_log
fill 113 198 325 113 201 325 minecraft:stone
setblock 114 198 323 minecraft:stripped_spruce_log
fill 114 198 324 114 201 324 minecraft:stone
setblock 114 198 363 minecraft:stripped_spruce_log
fill 115 198 323 115 201 323 minecraft:stone
fill 115 198 363 118 198 363 minecraft:stone
setblock 116 198 322 minecraft:raw_gold_block
fill 116 198 362 116 201 362 minecraft:stone
fill 117 198 322 118 216 322 minecraft:andesite
setblock 119 198 323 minecraft:stripped_spruce_log
setblock 119 198 363 minecraft:stripped_spruce_log
setblock 120 198 323 minecraft:stone
fill 120 198 363 120 199 363 minecraft:stone
fill 128 198 354 135 198 356 minecraft:raw_gold_block
setblock 129 198 323 minecraft:stripped_spruce_log
fill 130 198 323 130 201 323 minecraft:stone
fill 131 198 324 131 199 324 minecraft:stone
setblock 133 198 323 minecraft:stone
setblock 133 198 324 minecraft:stripped_spruce_log
fill 133 198 340 133 201 340 minecraft:stone
setblock 133 198 344 minecraft:stripped_spruce_log
fill 133 198 345 133 201 345 minecraft:stone
setblock 133 198 349 minecraft:stripped_spruce_log
setblock 134 198 323 minecraft:stripped_spruce_log
fill 134 198 325 134 198 327 minecraft:stone
setblock 134 198 328 minecraft:stripped_spruce_log
fill 134 198 329 134 201 329 minecraft:stone
fill 134 198 331 134 198 332 minecraft:stone
setblock 134 198 333 minecraft:stripped_spruce_log
fill 134 198 334 134 200 335 minecraft:stone
setblock 134 198 338 minecraft:stripped_spruce_log
fill 134 198 339 134 201 339 minecraft:stone
fill 134 198 344 134 201 344 minecraft:stone
setblock 134 198 348 minecraft:stripped_spruce_log
fill 134 198 349 134 201 349 minecraft:stone
setblock 134 198 363 minecraft:stripped_spruce_log
fill 135 198 323 135 201 323 minecraft:stone
setblock 135 198 326 minecraft:stone
setblock 135 198 327 minecraft:stripped_spruce_log
fill 135 198 328 135 201 328 minecraft:stone
setblock 135 198 332 minecraft:stripped_spruce_log
fill 135 198 333 135 201 333 minecraft:stone
setblock 135 198 337 minecraft:stripped_spruce_log
fill 135 198 338 135 201 338 minecraft:stone
setblock 135 198 342 minecraft:stripped_spruce_log
fill 135 198 343 135 201 343 minecraft:stone
setblock 135 198 347 minecraft:stripped_spruce_log
fill 135 198 348 135 201 348 minecraft:stone
setblock 135 198 352 minecraft:stripped_spruce_log
fill 135 198 353 135 201 353 minecraft:stone
setblock 135 198 362 minecraft:stripped_spruce_log
fill 135 198 363 135 201 363 minecraft:stone
setblock 136 198 348 minecraft:raw_iron_block
fill 94 199 330 94 206 330 minecraft:andesite
fill 94 199 341 94 204 341 minecraft:andesite
fill 95 199 323 95 199 325 minecraft:stone
setblock 95 199 326 minecraft:stripped_spruce_log
fill 95 199 327 95 199 330 minecraft:stone
setblock 95 199 331 minecraft:stripped_spruce_log
fill 95 199 332 95 199 335 minecraft:stone
setblock 95 199 336 minecraft:stripped_spruce_log
fill 95 199 337 95 201 337 minecraft:stone
setblock 95 199 341 minecraft:stripped_spruce_log
fill 95 199 342 95 201 342 minecraft:stone
setblock 95 199 346 minecraft:stripped_spruce_log
fill 95 199 347 95 201 347 minecraft:stone
setblock 95 199 351 minecraft:stripped_spruce_log
fill 95 199 352 95 201 352 minecraft:stone
fill 95 199 354 96 200 354 minecraft:raw_gold_block
fill 95 199 356 96 200 356 minecraft:raw_gold_block
setblock 95 199 361 minecraft:stripped_spruce_log
fill 95 199 362 95 201 363 minecraft:stone
fill 96 199 323 97 199 323 minecraft:stone
setblock 96 199 325 minecraft:stripped_spruce_log
fill 96 199 326 96 199 329 minecraft:stone
setblock 96 199 330 minecraft:stripped_spruce_log
fill 96 199 331 96 201 331 minecraft:stone
setblock 96 199 345 minecraft:stripped_spruce_log
fill 96 199 346 96 201 346 minecraft:stone
fill 96 199 355 97 201 355 minecraft:raw_gold_block
fill 96 199 363 97 199 363 minecraft:stone
setblock 97 199 324 minecraft:stripped_spruce_log
fill 97 199 325 97 202 325 minecraft:stone
setblock 97 199 329 minecraft:stripped_spruce_log
setblock 97 199 332 minecraft:light[level=12]
setblock 97 199 339 minecraft:light[level=12]
setblock 97 199 346 minecraft:light[level=12]
setblock 97 199 353 minecraft:light[level=12]
setblock 97 199 360 minecraft:light[level=12]
setblock 98 199 323 minecraft:stripped_spruce_log
fill 98 199 324 101 199 324 minecraft:stone
setblock 98 199 363 minecraft:stripped_spruce_log
fill 99 199 323 102 199 323 minecraft:stone
fill 99 199 363 100 200 363 minecraft:stone
setblock 102 199 324 minecraft:stripped_spruce_log
setblock 103 199 323 minecraft:stripped_spruce_log
fill 103 199 324 106 199 324 minecraft:stone
fill 104 199 323 107 199 323 minecraft:stone
setblock 104 199 325 minecraft:light[level=12]
setblock 104 199 332 minecraft:light[level=12]
setblock 104 199 339 minecraft:light[level=12]
setblock 104 199 346 minecraft:light[level=12]
setblock 104 199 353 minecraft:light[level=12]
setblock 104 199 360 minecraft:light[level=12]
fill 104 199 363 107 199 363 minecraft:stone
setblock 107 199 324 minecraft:stripped_spruce_log
setblock 108 199 323 minecraft:stripped_spruce_log
fill 108 199 324 108 201 324 minecraft:stone
setblock 108 199 363 minecraft:stripped_spruce_log
fill 109 199 323 112 199 323 minecraft:stone
setblock 109 199 362 minecraft:stripped_spruce_log
fill 109 199 363 112 199 363 minecraft:stone
setblock 110 199 325 minecraft:stone
fill 110 199 362 110 201 362 minecraft:stone
setblock 111 199 325 minecraft:stripped_spruce_log
setblock 111 199 332 minecraft:light[level=12]
setblock 111 199 339 minecraft:light[level=12]
setblock 111 199 346 minecraft:light[level=12]
setblock 111 199 353 minecraft:light[level=12]
setblock 111 199 360 minecraft:light[level=12]
setblock 112 199 324 minecraft:stripped_spruce_log
fill 112 199 325 112 202 325 minecraft:stone
setblock 113 199 323 minecraft:stripped_spruce_log
fill 113 199 324 113 201 324 minecraft:stone
setblock 113 199 362 minecraft:stone
setblock 113 199 363 minecraft:stripped_spruce_log
fill 114 199 323 114 201 323 minecraft:stone
fill 114 199 325 114 200 325 minecraft:stone
setblock 114 199 362 minecraft:stripped_spruce_log
fill 114 199 363 117 199 363 minecraft:stone
fill 116 199 322 116 247 322 minecraft:andesite
setblock 117 199 324 minecraft:stripped_spruce_log
setblock 118 199 323 minecraft:stripped_spruce_log
setblock 118 199 325 minecraft:light[level=12]
setblock 118 199 332 minecraft:light[level=12]
setblock 118 199 339 minecraft:light[level=12]
setblock 118 199 346 minecraft:light[level=12]
setblock 118 199 353 minecraft:light[level=12]
setblock 118 199 360 minecraft:light[level=12]
setblock 118 199 363 minecraft:stripped_spruce_log
fill 119 199 323 119 200 323 minecraft:stone
fill 119 199 363 119 200 363 minecraft:stone
setblock 123 199 322 minecraft:diamond_block
fill 124 199 322 126 217 322 minecraft:andesite
setblock 125 199 325 minecraft:light[level=12]
setblock 125 199 332 minecraft:light[level=12]
setblock 125 199 339 minecraft:light[level=12]
setblock 125 199 346 minecraft:light[level=12]
setblock 125 199 353 minecraft:light[level=12]
setblock 125 199 360 minecraft:light[level=12]
fill 129 199 323 129 201 323 minecraft:stone
fill 129 199 355 135 199 355 minecraft:raw_gold_block
fill 130 199 354 134 199 354 minecraft:raw_gold_block
fill 130 199 356 135 199 356 minecraft:raw_gold_block
setblock 132 199 324 minecraft:stripped_spruce_log
setblock 132 199 325 minecraft:light[level=12]
setblock 132 199 332 minecraft:light[level=12]
setblock 132 199 339 minecraft:light[level=12]
fill 132 199 345 132 200 347 minecraft:stone
fill 132 199 353 134 199 353 minecraft:raw_gold_block
fill 132 199 357 135 199 357 minecraft:raw_gold_block
setblock 132 199 360 minecraft:light[level=12]
setblock 133 199 323 minecraft:stripped_spruce_log
fill 133 199 324 133 199 327 minecraft:stone
setblock 133 199 328 minecraft:stripped_spruce_log
fill 133 199 329 133 202 329 minecraft:stone
setblock 133 199 343 minecraft:stripped_spruce_log
fill 133 199 344 133 202 344 minecraft:stone
setblock 133 199 348 minecraft:stripped_spruce_log
fill 133 199 349 133 201 350 minecraft:stone
setblock 133 199 363 minecraft:stripped_spruce_log
fill 134 199 323 134 201 323 minecraft:stone
fill 134 199 325 134 199 326 minecraft:stone
setblock 134 199 327 minecraft:stripped_spruce_log
fill 134 199 328 134 201 328 minecraft:stone
setblock 134 199 331 minecraft:stone
setblock 134 199 332 minecraft:stripped_spruce_log
fill 134 199 333 134 201 333 minecraft:stone
setblock 134 199 337 minecraft:stripped_spruce_log
fill 134 199 338 134 201 338 minecraft:stone
setblock 134 199 342 minecraft:stripped_spruce_log
setblock 134 199 347 minecraft:stripped_spruce_log
fill 134 199 348 134 201 348 minecraft:stone
setblock 134 199 352 minecraft:stripped_spruce_log
fill 134 199 363 134 201 363 minecraft:stone
setblock 135 199 326 minecraft:stripped_spruce_log
fill 135 199 327 135 201 327 minecraft:stone
setblock 135 199 331 minecraft:stripped_spruce_log
fill 135 199 332 135 201 332 minecraft:stone
setblock 135 199 336 minecraft:stripped_spruce_log
fill 135 199 337 135 201 337 minecraft:stone
setblock 135 199 341 minecraft:stripped_spruce_log
fill 135 199 342 135 201 342 minecraft:stone
setblock 135 199 346 minecraft:stripped_spruce_log
fill 135 199 347 135 201 347 minecraft:stone
setblock 135 199 351 minecraft:stripped_spruce_log
fill 135 199 352 135 201 352 minecraft:stone
fill 135 199 354 135 200 354 minecraft:stone
fill 136 199 348 136 245 348 minecraft:andesite
setblock 94 200 324 minecraft:raw_gold_block
fill 95 200 323 95 200 324 minecraft:stone
setblock 95 200 325 minecraft:stripped_spruce_log
fill 95 200 326 95 200 329 minecraft:stone
setblock 95 200 330 minecraft:stripped_spruce_log
fill 95 200 331 95 200 334 minecraft:stone
setblock 95 200 335 minecraft:stripped_spruce_log
fill 95 200 336 95 201 336 minecraft:stone
setblock 95 200 340 minecraft:stripped_spruce_log
fill 95 200 341 95 201 341 minecraft:stone
setblock 95 200 345 minecraft:stripped_spruce_log
fill 95 200 346 95 201 346 minecraft:stone
setblock 95 200 350 minecraft:stripped_spruce_log
fill 95 200 351 95 201 351 minecraft:stone
fill 95 200 353 95 201 353 minecraft:stone
fill 95 200 361 95 201 361 minecraft:stone
setblock 96 200 323 minecraft:stone
setblock 96 200 324 minecraft:glowstone
fill 96 200 325 96 200 328 minecraft:stone
setblock 96 200 329 minecraft:stripped_spruce_log
fill 96 200 330 97 201 330 minecraft:stone
setblock 96 200 343 minecraft:glowstone
setblock 96 200 344 minecraft:stripped_spruce_log
setblock 96 200 345 minecraft:stone
setblock 96 200 349 minecraft:stripped_spruce_log
setblock 96 200 362 minecraft:glowstone
setblock 96 200 363 minecraft:stone
setblock 97 200 323 minecraft:stripped_spruce_log
fill 97 200 324 100 200 324 minecraft:stone
setblock 97 200 328 minecraft:stripped_spruce_log
fill 97 200 329 97 203 329 minecraft:stone
fill 97 200 354 97 201 354 minecraft:raw_gold_block
fill 97 200 356 97 201 356 minecraft:raw_gold_block
setblock 97 200 363 minecraft:stripped_spruce_log
fill 98 200 323 101 200 323 minecraft:stone
fill 98 200 355 98 201 355 minecraft:raw_gold_block
fill 98 200 363 98 201 363 minecraft:stone
setblock 101 200 324 minecraft:stripped_spruce_log
setblock 102 200 323 minecraft:stripped_spruce_log
fill 102 200 324 105 200 324 minecraft:stone
fill 103 200 322 104 218 322 minecraft:andesite
fill 103 200 323 106 200 323 minecraft:stone
fill 104 200 363 106 200 363 minecraft:stone
setblock 105 200 322 minecraft:gold_block
fill 106 200 322 110 200 322 minecraft:andesite
setblock 106 200 324 minecraft:stripped_spruce_log
setblock 107 200 323 minecraft:stripped_spruce_log
fill 107 200 324 107 201 324 minecraft:stone
setblock 107 200 363 minecraft:stripped_spruce_log
fill 108 200 323 111 200 323 minecraft:stone
setblock 108 200 362 minecraft:stripped_spruce_log
fill 108 200 363 111 200 363 minecraft:stone
setblock 109 200 325 minecraft:stone
fill 109 200 362 109 201 362 minecraft:stone
setblock 110 200 325 minecraft:stripped_spruce_log
setblock 111 200 324 minecraft:stripped_spruce_log
fill 111 200 325 111 203 325 minecraft:stone
setblock 112 200 323 minecraft:stripped_spruce_log
fill 112 200 324 112 201 324 minecraft:stone
setblock 112 200 363 minecraft:stripped_spruce_log
fill 113 200 323 113 201 323 minecraft:stone
setblock 113 200 362 minecraft:stripped_spruce_log
fill 113 200 363 116 200 363 minecraft:stone
fill 114 200 362 114 201 362 minecraft:stone
setblock 115 200 324 minecraft:glowstone
setblock 115 200 362 minecraft:glowstone
setblock 116 200 324 minecraft:stripped_spruce_log
setblock 117 200 323 minecraft:stripped_spruce_log
setblock 117 200 324 minecraft:stone
setblock 117 200 363 minecraft:stripped_spruce_log
fill 118 200 323 118 201 323 minecraft:stone
fill 118 200 363 118 201 363 minecraft:stone
fill 123 200 322 123 247 322 minecraft:andesite
fill 128 200 323 128 201 323 minecraft:stone
setblock 130 200 324 minecraft:stone
setblock 131 200 324 minecraft:stripped_spruce_log
fill 131 200 354 134 200 356 minecraft:raw_gold_block
setblock 131 200 363 minecraft:stone
setblock 132 200 323 minecraft:stripped_spruce_log
fill 132 200 324 133 201 325 minecraft:stone
fill 132 200 344 132 202 344 minecraft:stone
setblock 132 200 348 minecraft:stripped_spruce_log
setblock 132 200 363 minecraft:stripped_spruce_log
fill 133 200 323 133 201 323 minecraft:stone
setblock 133 200 326 minecraft:stone
setblock 133 200 327 minecraft:stripped_spruce_log
fill 133 200 328 133 203 328 minecraft:stone
fill 133 200 330 133 200 331 minecraft:stone
setblock 133 200 332 minecraft:stripped_spruce_log
setblock 133 200 342 minecraft:stripped_spruce_log
fill 133 200 343 133 203 343 minecraft:stone
setblock 133 200 347 minecraft:stripped_spruce_log
fill 133 200 348 133 203 348 minecraft:stone
setblock 133 200 351 minecraft:stone
setblock 133 200 353 minecraft:raw_gold_block
fill 133 200 357 135 200 357 minecraft:raw_gold_block
fill 133 200 363 133 201 363 minecraft:stone
setblock 134 200 324 minecraft:glowstone
setblock 134 200 325 minecraft:stone
setblock 134 200 326 minecraft:stripped_spruce_log
fill 134 200 327 134 201 327 minecraft:stone
setblock 134 200 331 minecraft:stripped_spruce_log
fill 134 200 332 134 201 332 minecraft:stone
setblock 134 200 336 minecraft:stripped_spruce_log
fill 134 200 337 134 201 337 minecraft:stone
setblock 134 200 341 minecraft:stripped_spruce_log
fill 134 200 342 134 201 342 minecraft:stone
setblock 134 200 343 minecraft:glowstone
setblock 134 200 346 minecraft:stripped_spruce_log
fill 134 200 347 134 201 347 minecraft:stone
setblock 134 200 350 minecraft:stone
setblock 134 200 351 minecraft:stripped_spruce_log
fill 134 200 352 134 201 353 minecraft:stone
setblock 134 200 362 minecraft:glowstone
setblock 135 200 325 minecraft:stripped_spruce_log
fill 135 200 326 135 201 326 minecraft:stone
setblock 135 200 330 minecraft:stripped_spruce_log
fill 135 200 331 135 201 331 minecraft:stone
setblock 135 200 335 minecraft:stripped_spruce_log
fill 135 200 336 135 201 336 minecraft:stone
setblock 135 200 340 minecraft:stripped_spruce_log
fill 135 200 341 135 201 341 minecraft:stone
setblock 135 200 345 minecraft:stripped_spruce_log
fill 135 200 346 135 201 346 minecraft:stone
setblock 135 200 350 minecraft:stripped_spruce_log
fill 135 200 351 135 201 351 minecraft:stone
fill 135 200 355 135 200 356 minecraft:raw_gold_block
fill 136 200 350 136 200 352 minecraft:andesite
setblock 136 200 353 minecraft:raw_gold_block
fill 94 201 324 94 206 324 minecraft:andesite
fill 94 201 342 94 201 346 minecraft:andesite
setblock 94 201 347 minecraft:diamond_block
fill 94 201 348 94 206 349 minecraft:andesite
setblock 95 201 323 minecraft:stone
setblock 95 201 324 minecraft:stripped_spruce_log
fill 95 201 325 95 201 328 minecraft:stone
setblock 95 201 329 minecraft:stripped_spruce_log
fill 95 201 330 95 201 333 minecraft:stone
setblock 95 201 334 minecraft:stripped_spruce_log
setblock 95 201 335 minecraft:stone
setblock 95 201 339 minecraft:stripped_spruce_log
setblock 95 201 340 minecraft:stone
setblock 95 201 344 minecraft:stripped_spruce_log
setblock 95 201 345 minecraft:stone
setblock 95 201 348 minecraft:stone
setblock 95 201 349 minecraft:stripped_spruce_log
setblock 95 201 350 minecraft:stone
setblock 95 201 354 minecraft:stripped_spruce_log
setblock 96 201 323 minecraft:stripped_spruce_log
fill 96 201 324 96 202 324 minecraft:spruce_log
fill 96 201 325 96 201 327 minecraft:stone
setblock 96 201 328 minecraft:stripped_spruce_log
setblock 96 201 329 minecraft:stone
setblock 96 201 332 minecraft:stone
setblock 96 201 333 minecraft:stripped_spruce_log
setblock 96 201 334 minecraft:stone
fill 96 201 343 96 202 343 minecraft:spruce_log
setblock 96 201 348 minecraft:stripped_spruce_log
setblock 96 201 349 minecraft:stone
setblock 96 201 354 minecraft:raw_gold_block
setblock 96 201 356 minecraft:raw_gold_block
fill 96 201 362 96 202 362 minecraft:spruce_log
setblock 96 201 363 minecraft:stripped_spruce_log
fill 97 201 323 99 201 324 minecraft:stone
setblock 97 201 327 minecraft:stripped_spruce_log
fill 97 201 328 97 204 328 minecraft:stone
setblock 97 201 363 minecraft:stone
setblock 99 201 325 minecraft:stripped_spruce_log
fill 99 201 355 100 201 355 minecraft:raw_gold_block
setblock 99 201 363 minecraft:stone
setblock 100 201 323 minecraft:stone
setblock 100 201 324 minecraft:stripped_spruce_log
setblock 101 201 323 minecraft:stripped_spruce_log
fill 101 201 324 104 201 324 minecraft:stone
fill 102 201 323 105 201 323 minecraft:stone
fill 103 201 363 105 201 363 minecraft:stone
fill 105 201 322 109 208 322 minecraft:andesite
setblock 105 201 324 minecraft:stripped_spruce_log
setblock 106 201 323 minecraft:stripped_spruce_log
setblock 106 201 324 minecraft:stone
setblock 106 201 363 minecraft:stripped_spruce_log
fill 107 201 323 110 201 323 minecraft:stone
fill 107 201 363 110 201 363 minecraft:stone
setblock 108 201 325 minecraft:stone
setblock 108 201 362 minecraft:stone
setblock 109 201 325 minecraft:stripped_spruce_log
setblock 110 201 322 minecraft:gold_block
setblock 110 201 324 minecraft:stripped_spruce_log
fill 110 201 325 110 204 325 minecraft:stone
setblock 111 201 323 minecraft:stripped_spruce_log
setblock 111 201 324 minecraft:stone
setblock 111 201 363 minecraft:stripped_spruce_log
setblock 112 201 323 minecraft:stone
setblock 112 201 362 minecraft:stripped_spruce_log
fill 112 201 363 115 201 363 minecraft:stone
setblock 113 201 362 minecraft:stone
setblock 114 201 325 minecraft:stripped_spruce_log
fill 115 201 324 115 202 324 minecraft:spruce_log
fill 115 201 362 115 202 362 minecraft:spruce_log
setblock 116 201 323 minecraft:stripped_spruce_log
setblock 116 201 324 minecraft:stone
setblock 116 201 363 minecraft:stripped_spruce_log
setblock 117 201 323 minecraft:stone
setblock 117 201 363 minecraft:stone
setblock 127 201 323 minecraft:stone
setblock 129 201 324 minecraft:stone
setblock 130 201 324 minecraft:stripped_spruce_log
setblock 131 201 323 minecraft:stripped_spruce_log
fill 131 201 324 131 201 325 minecraft:stone
setblock 131 201 363 minecraft:stripped_spruce_log
setblock 132 201 323 minecraft:stone
fill 132 201 345 132 201 346 minecraft:stone
setblock 132 201 347 minecraft:stripped_spruce_log
fill 132 201 348 132 203 349 minecraft:stone
fill 132 201 355 134 201 355 minecraft:raw_gold_block
setblock 132 201 363 minecraft:stone
setblock 133 201 326 minecraft:stripped_spruce_log
fill 133 201 327 133 204 327 minecraft:stone
setblock 133 201 330 minecraft:stone
setblock 133 201 331 minecraft:stripped_spruce_log
fill 133 201 332 133 202 334 minecraft:stone
setblock 133 201 341 minecraft:stripped_spruce_log
fill 133 201 342 133 204 342 minecraft:stone
setblock 133 201 346 minecraft:stripped_spruce_log
fill 133 201 347 133 204 347 minecraft:stone
setblock 133 201 351 minecraft:stripped_spruce_log
fill 133 201 352 133 204 352 minecraft:stone
fill 133 201 354 134 201 354 minecraft:raw_gold_block
fill 133 201 356 135 201 356 minecraft:raw_gold_block
fill 134 201 324 134 202 324 minecraft:spruce_log
setblock 134 201 325 minecraft:stripped_spruce_log
setblock 134 201 326 minecraft:stone
setblock 134 201 330 minecraft:stripped_spruce_log
setblock 134 201 331 minecraft:stone
setblock 134 201 334 minecraft:stone
setblock 134 201 335 minecraft:stripped_spruce_log
setblock 134 201 336 minecraft:stone
setblock 134 201 340 minecraft:stripped_spruce_log
setblock 134 201 341 minecraft:stone
fill 134 201 343 134 202 343 minecraft:spruce_log
setblock 134 201 345 minecraft:stripped_spruce_log
setblock 134 201 346 minecraft:stone
setblock 134 201 350 minecraft:stripped_spruce_log
setblock 134 201 351 minecraft:stone
fill 134 201 362 134 202 362 minecraft:spruce_log
setblock 135 201 324 minecraft:stripped_spruce_log
setblock 135 201 325 minecraft:stone
setblock 135 201 329 minecraft:stripped_spruce_log
setblock 135 201 330 minecraft:stone
setblock 135 201 334 minecraft:stripped_spruce_log
setblock 135 201 335 minecraft:stone
setblock 135 201 339 minecraft:stripped_spruce_log
setblock 135 201 340 minecraft:stone
setblock 135 201 344 minecraft:stripped_spruce_log
setblock 135 201 345 minecraft:stone
setblock 135 201 349 minecraft:stripped_spruce_log
setblock 135 201 350 minecraft:stone
setblock 135 201 354 minecraft:stripped_spruce_log
setblock 135 201 355 minecraft:stone
fill 136 201 350 136 222 350 minecraft:andesite
setblock 136 201 351 minecraft:raw_gold_block
fill 136 201 352 136 208 353 minecraft:andesite
fill 94 202 339 94 230 339 minecraft:andesite
setblock 94 202 340 minecraft:gold_block
fill 94 202 342 94 205 345 minecraft:andesite
setblock 94 202 346 minecraft:gold_block
setblock 94 202 347 minecraft:andesite
fill 94 202 352 94 233 354 minecraft:andesite
setblock 94 202 355 minecraft:diamond_block
fill 94 202 356 94 243 356 minecraft:andesite
fill 95 202 323 95 202 363 minecraft:spruce_planks
fill 96 202 323 135 202 323 minecraft:spruce_planks
fill 96 202 325 96 202 342 minecraft:spruce_planks
fill 96 202 344 96 202 361 minecraft:spruce_planks
fill 96 202 363 135 202 363 minecraft:spruce_planks
fill 97 202 324 114 202 324 minecraft:spruce_planks
setblock 97 202 326 minecraft:stripped_spruce_log
fill 97 202 327 97 205 327 minecraft:stone
setblock 97 202 330 minecraft:stone
setblock 97 202 331 minecraft:stripped_spruce_log
fill 97 202 362 114 202 362 minecraft:spruce_planks
setblock 98 202 325 minecraft:stripped_spruce_log
setblock 99 202 325 minecraft:stone
setblock 107 202 325 minecraft:stone
setblock 108 202 325 minecraft:stripped_spruce_log
fill 109 202 325 109 205 325 minecraft:stone
fill 110 202 322 110 247 322 minecraft:andesite
setblock 110 202 364 minecraft:raw_gold_block
setblock 111 202 361 minecraft:stone
setblock 112 202 361 minecraft:stripped_spruce_log
setblock 113 202 325 minecraft:stripped_spruce_log
setblock 113 202 364 minecraft:diamond_block
setblock 114 202 325 minecraft:stone
fill 116 202 324 133 202 324 minecraft:spruce_planks
fill 116 202 362 133 202 362 minecraft:spruce_planks
fill 124 202 364 124 228 364 minecraft:andesite
setblock 125 202 364 minecraft:gold_block
fill 126 202 364 130 207 364 minecraft:andesite
fill 130 202 325 132 202 325 minecraft:stone
setblock 132 202 326 minecraft:stripped_spruce_log
fill 132 202 327 132 202 330 minecraft:stone
setblock 132 202 331 minecraft:stripped_spruce_log
setblock 132 202 345 minecraft:stone
setblock 132 202 346 minecraft:stripped_spruce_log
fill 132 202 347 132 204 347 minecraft:stone
setblock 132 202 350 minecraft:stone
setblock 133 202 325 minecraft:stripped_spruce_log
fill 133 202 326 133 205 326 minecraft:stone
setblock 133 202 330 minecraft:stripped_spruce_log
fill 133 202 331 133 205 331 minecraft:stone
setblock 133 202 335 minecraft:stripped_spruce_log
fill 133 202 336 133 204 337 minecraft:stone
setblock 133 202 339 minecraft:stone
setblock 133 202 340 minecraft:stripped_spruce_log
fill 133 202 341 133 203 341 minecraft:stone
setblock 133 202 345 minecraft:stripped_spruce_log
fill 133 202 346 133 205 346 minecraft:stone
setblock 133 202 349 minecraft:stone
setblock 133 202 350 minecraft:stripped_spruce_log
fill 133 202 351 133 205 351 minecraft:stone
fill 134 202 325 135 202 342 minecraft:spruce_planks
fill 134 202 344 135 202 361 minecraft:spruce_planks
setblock 135 202 324 minecraft:spruce_planks
setblock 135 202 343 minecraft:spruce_planks
setblock 135 202 362 minecraft:spruce_planks
setblock 136 202 338 minecraft:diamond_block
fill 136 202 339 136 243 339 minecraft:andesite
fill 136 202 351 136 231 351 minecraft:andesite
fill 94 203 340 94 243 340 minecraft:andesite
fill 94 203 346 94 247 346 minecraft:andesite
setblock 94 203 347 minecraft:raw_iron_block
fill 94 203 355 94 243 355 minecraft:andesite
fill 95 203 323 95 203 326 minecraft:stone
setblock 95 203 327 minecraft:stripped_spruce_log
fill 95 203 328 95 203 331 minecraft:stone
setblock 95 203 332 minecraft:stripped_spruce_log
fill 95 203 333 95 203 336 minecraft:stone
setblock 95 203 337 minecraft:stripped_spruce_log
fill 95 203 338 95 203 341 minecraft:stone
setblock 95 203 342 minecraft:stripped_spruce_log
fill 95 203 343 95 203 346 minecraft:stone
setblock 95 203 347 minecraft:stripped_spruce_log
fill 95 203 348 95 203 351 minecraft:stone
setblock 95 203 352 minecraft:stripped_spruce_log
fill 95 203 353 95 203 356 minecraft:stone
setblock 95 203 357 minecraft:stripped_spruce_log
fill 95 203 358 95 206 358 minecraft:stone
fill 95 203 360 95 203 361 minecraft:stone
setblock 95 203 362 minecraft:stripped_spruce_log
fill 95 203 363 98 203 363 minecraft:stone
fill 96 203 323 96 203 325 minecraft:stone
setblock 96 203 326 minecraft:stripped_spruce_log
fill 96 203 327 96 203 330 minecraft:stone
setblock 96 203 331 minecraft:stripped_spruce_log
fill 96 203 332 96 204 334 minecraft:stone
fill 96 203 348 96 203 350 minecraft:stone
setblock 96 203 351 minecraft:stripped_spruce_log
fill 97 203 323 97 203 324 minecraft:stone
setblock 97 203 325 minecraft:stripped_spruce_log
fill 97 203 326 97 205 326 minecraft:stone
setblock 97 203 330 minecraft:stripped_spruce_log
fill 97 203 331 97 205 331 minecraft:stone
setblock 97 203 333 minecraft:light[level=15]
setblock 97 203 341 minecraft:light[level=15]
setblock 97 203 349 minecraft:light[level=15]
setblock 97 203 357 minecraft:light[level=15]
setblock 98 203 323 minecraft:stone
setblock 98 203 324 minecraft:stripped_spruce_log
setblock 98 203 325 minecraft:stone
setblock 99 203 323 minecraft:stripped_spruce_log
fill 99 203 324 102 203 324 minecraft:stone
setblock 99 203 363 minecraft:stripped_spruce_log
fill 100 203 323 103 203 323 minecraft:stone
fill 102 203 363 103 203 363 minecraft:stone
setblock 103 203 324 minecraft:stripped_spruce_log
setblock 104 203 323 minecraft:stripped_spruce_log
fill 104 203 324 107 203 324 minecraft:stone
setblock 104 203 363 minecraft:stripped_spruce_log
fill 105 203 323 108 203 323 minecraft:stone
setblock 105 203 325 minecraft:light[level=15]
setblock 105 203 333 minecraft:light[level=15]
setblock 105 203 341 minecraft:light[level=15]
setblock 105 203 349 minecraft:light[level=15]
setblock 105 203 357 minecraft:light[level=15]
fill 105 203 363 108 203 363 minecraft:stone
setblock 106 203 325 minecraft:stone
fill 106 203 362 109 203 362 minecraft:stone
setblock 107 203 325 minecraft:stripped_spruce_log
setblock 108 203 324 minecraft:stripped_spruce_log
fill 108 203 325 108 205 325 minecraft:stone
setblock 109 203 323 minecraft:stripped_spruce_log
fill 109 203 324 112 203 324 minecraft:stone
setblock 109 203 363 minecraft:stripped_spruce_log
fill 110 203 323 113 203 323 minecraft:stone
setblock 110 203 361 minecraft:stone
setblock 110 203 362 minecraft:stripped_spruce_log
fill 110 203 363 113 203 363 minecraft:stone
fill 110 203 364 110 237 364 minecraft:andesite
setblock 111 203 361 minecraft:stripped_spruce_log
fill 111 203 362 114 203 362 minecraft:stone
setblock 112 203 325 minecraft:stripped_spruce_log
fill 112 203 361 112 204 361 minecraft:stone
setblock 113 203 324 minecraft:stripped_spruce_log
setblock 113 203 325 minecraft:stone
setblock 113 203 333 minecraft:light[level=15]
setblock 113 203 341 minecraft:light[level=15]
setblock 113 203 349 minecraft:light[level=15]
setblock 113 203 357 minecraft:light[level=15]
fill 113 203 364 113 248 364 minecraft:andesite
setblock 114 203 323 minecraft:stripped_spruce_log
fill 114 203 324 115 203 324 minecraft:stone
setblock 114 203 363 minecraft:stripped_spruce_log
fill 115 203 323 117 203 323 minecraft:stone
setblock 115 203 362 minecraft:stripped_spruce_log
fill 115 203 363 117 203 363 minecraft:stone
setblock 116 203 364 minecraft:andesite
setblock 117 203 364 minecraft:gold_block
fill 118 203 364 119 244 364 minecraft:andesite
setblock 121 203 325 minecraft:light[level=15]
setblock 121 203 333 minecraft:light[level=15]
setblock 121 203 341 minecraft:light[level=15]
setblock 121 203 349 minecraft:light[level=15]
setblock 121 203 357 minecraft:light[level=15]
fill 125 203 364 125 247 364 minecraft:andesite
fill 126 203 323 128 203 323 minecraft:stone
setblock 128 203 324 minecraft:stripped_spruce_log
setblock 129 203 323 minecraft:stripped_spruce_log
fill 129 203 324 131 203 325 minecraft:stone
setblock 129 203 333 minecraft:light[level=15]
setblock 129 203 341 minecraft:light[level=15]
setblock 129 203 349 minecraft:light[level=15]
setblock 129 203 357 minecraft:light[level=15]
fill 130 203 323 133 203 323 minecraft:stone
fill 130 203 363 133 203 363 minecraft:stone
setblock 131 203 326 minecraft:stripped_spruce_log
setblock 132 203 324 minecraft:stone
setblock 132 203 325 minecraft:stripped_spruce_log
fill 132 203 326 132 203 329 minecraft:stone
setblock 132 203 330 minecraft:stripped_spruce_log
fill 132 203 331 132 204 333 minecraft:stone
setblock 132 203 345 minecraft:stripped_spruce_log
setblock 132 203 346 minecraft:stone
setblock 132 203 350 minecraft:stripped_spruce_log
fill 132 203 351 132 204 351 minecraft:stone
setblock 133 203 324 minecraft:stripped_spruce_log
fill 133 203 325 135 204 325 minecraft:stone
setblock 133 203 329 minecraft:stripped_spruce_log
fill 133 203 330 135 204 330 minecraft:stone
fill 133 203 332 133 203 333 minecraft:stone
setblock 133 203 334 minecraft:stripped_spruce_log
fill 133 203 335 135 204 335 minecraft:stone
setblock 133 203 338 minecraft:stone
setblock 133 203 339 minecraft:stripped_spruce_log
fill 133 203 340 135 203 340 minecraft:stone
setblock 133 203 344 minecraft:stripped_spruce_log
fill 133 203 345 135 204 345 minecraft:stone
setblock 133 203 349 minecraft:stripped_spruce_log
fill 133 203 350 135 204 350 minecraft:stone
setblock 133 203 353 minecraft:stone
setblock 134 203 323 minecraft:stripped_spruce_log
fill 134 203 324 135 205 324 minecraft:stone
fill 134 203 326 134 203 327 minecraft:stone
setblock 134 203 328 minecraft:stripped_spruce_log
fill 134 203 329 135 205 329 minecraft:stone
fill 134 203 331 134 203 332 minecraft:stone
setblock 134 203 333 minecraft:stripped_spruce_log
fill 134 203 334 135 205 334 minecraft:stone
fill 134 203 336 134 203 337 minecraft:stone
setblock 134 203 338 minecraft:stripped_spruce_log
fill 134 203 339 135 205 339 minecraft:stone
fill 134 203 341 134 203 342 minecraft:stone
setblock 134 203 343 minecraft:stripped_spruce_log
fill 134 203 344 135 205 344 minecraft:stone
fill 134 203 346 134 203 347 minecraft:stone
setblock 134 203 348 minecraft:stripped_spruce_log
fill 134 203 349 135 205 349 minecraft:stone
fill 134 203 351 134 203 352 minecraft:stone
setblock 134 203 353 minecraft:stripped_spruce_log
fill 134 203 354 135 204 355 minecraft:stone
setblock 134 203 363 minecraft:stripped_spruce_log
fill 135 203 323 135 206 323 minecraft:stone
setblock 135 203 326 minecraft:stone
setblock 135 203 327 minecraft:stripped_spruce_log
fill 135 203 328 135 206 328 minecraft:stone
setblock 135 203 331 minecraft:stone
setblock 135 203 332 minecraft:stripped_spruce_log
fill 135 203 333 135 206 333 minecraft:stone
setblock 135 203 336 minecraft:stone
setblock 135 203 337 minecraft:stripped_spruce_log
fill 135 203 338 135 206 338 minecraft:stone
setblock 135 203 341 minecraft:stone
setblock 135 203 342 minecraft:stripped_spruce_log
fill 135 203 343 135 206 343 minecraft:stone
setblock 135 203 346 minecraft:stone
setblock 135 203 347 minecraft:stripped_spruce_log
fill 135 203 348 135 206 348 minecraft:stone
setblock 135 203 351 minecraft:stone
setblock 135 203 352 minecraft:stripped_spruce_log
fill 135 203 353 135 206 353 minecraft:stone
setblock 135 203 356 minecraft:stone
fill 136 203 338 136 247 338 minecraft:andesite
fill 136 203 355 136 244 355 minecraft:andesite
setblock 136 203 356 minecraft:diamond_block
fill 136 203 357 136 204 360 minecraft:andesite
fill 94 204 347 94 233 347 minecraft:andesite
fill 94 204 358 94 240 358 minecraft:andesite
setblock 94 204 359 minecraft:gold_block
fill 94 204 360 94 218 361 minecraft:andesite
fill 95 204 323 95 204 325 minecraft:stone
setblock 95 204 326 minecraft:stripped_spruce_log
fill 95 204 327 95 204 330 minecraft:stone
setblock 95 204 331 minecraft:stripped_spruce_log
schedule function dropper:buildpart/74_6 1t
