setblock 131 282 402 minecraft:basalt
setblock 132 282 380 minecraft:basalt
setblock 132 282 400 minecraft:basalt
fill 133 282 381 133 282 382 minecraft:basalt
fill 133 282 398 133 282 399 minecraft:basalt
fill 134 282 383 134 282 386 minecraft:basalt
setblock 134 282 387 minecraft:blackstone
setblock 134 282 393 minecraft:blackstone
fill 134 282 394 134 282 397 minecraft:basalt
fill 135 282 387 135 282 393 minecraft:basalt
fill 95 283 370 97 300 370 minecraft:polished_blackstone_bricks
fill 95 283 380 95 300 382 minecraft:polished_blackstone_bricks
fill 95 283 392 95 300 394 minecraft:polished_blackstone_bricks
fill 95 283 404 95 300 406 minecraft:polished_blackstone_bricks
fill 96 283 379 96 285 381 minecraft:polished_blackstone_bricks
fill 96 283 386 96 283 394 minecraft:basalt
fill 96 283 403 96 285 405 minecraft:polished_blackstone_bricks
fill 97 283 383 97 283 385 minecraft:basalt
fill 97 283 386 105 283 394 minecraft:blackstone
fill 97 283 395 97 283 397 minecraft:basalt
fill 98 283 381 98 283 382 minecraft:basalt
fill 98 283 383 107 283 385 minecraft:blackstone
fill 98 283 395 108 283 397 minecraft:blackstone
fill 98 283 398 98 283 399 minecraft:basalt
fill 99 283 379 99 283 380 minecraft:basalt
fill 99 283 381 109 283 382 minecraft:blackstone
fill 99 283 398 131 283 399 minecraft:blackstone
fill 99 283 400 99 283 401 minecraft:basalt
setblock 100 283 378 minecraft:basalt
fill 100 283 379 130 283 380 minecraft:blackstone
fill 100 283 400 130 283 401 minecraft:blackstone
setblock 100 283 402 minecraft:basalt
setblock 101 283 377 minecraft:basalt
fill 101 283 378 129 283 378 minecraft:blackstone
fill 101 283 402 129 283 402 minecraft:blackstone
setblock 101 283 403 minecraft:basalt
fill 101 283 410 103 300 410 minecraft:polished_blackstone_bricks
setblock 102 283 376 minecraft:basalt
fill 102 283 377 128 283 377 minecraft:blackstone
fill 102 283 403 128 283 403 minecraft:blackstone
setblock 102 283 404 minecraft:basalt
fill 102 283 409 104 285 409 minecraft:polished_blackstone_bricks
setblock 103 283 375 minecraft:basalt
fill 103 283 376 127 283 376 minecraft:blackstone
fill 103 283 404 127 283 404 minecraft:blackstone
setblock 103 283 405 minecraft:basalt
fill 104 283 374 105 283 374 minecraft:basalt
fill 104 283 375 126 283 375 minecraft:blackstone
fill 104 283 405 126 283 405 minecraft:blackstone
fill 104 283 406 105 283 406 minecraft:basalt
fill 106 283 371 108 285 371 minecraft:polished_blackstone_bricks
fill 106 283 373 107 283 373 minecraft:basalt
fill 106 283 374 124 283 374 minecraft:blackstone
fill 106 283 386 106 283 387 minecraft:blackstone
fill 106 283 388 106 284 390 minecraft:magma_block
fill 106 283 391 106 283 394 minecraft:blackstone
fill 106 283 406 124 283 406 minecraft:blackstone
fill 106 283 407 107 283 407 minecraft:basalt
fill 107 283 370 109 300 370 minecraft:polished_blackstone_bricks
fill 107 283 386 107 283 387 minecraft:magma_block
fill 107 283 391 107 283 393 minecraft:magma_block
setblock 107 283 394 minecraft:blackstone
fill 108 283 372 110 283 372 minecraft:basalt
fill 108 283 373 122 283 373 minecraft:blackstone
setblock 108 283 383 minecraft:blackstone
fill 108 283 384 108 283 385 minecraft:magma_block
fill 108 283 393 108 283 394 minecraft:magma_block
fill 108 283 407 122 283 407 minecraft:blackstone
fill 108 283 408 110 283 408 minecraft:basalt
setblock 109 283 383 minecraft:magma_block
setblock 109 283 395 minecraft:magma_block
fill 109 283 396 109 283 397 minecraft:blackstone
fill 110 283 381 111 283 381 minecraft:blackstone
fill 110 283 382 111 283 382 minecraft:magma_block
fill 110 283 396 111 283 396 minecraft:magma_block
setblock 110 283 397 minecraft:blackstone
fill 111 283 371 119 283 371 minecraft:basalt
fill 111 283 372 119 283 372 minecraft:blackstone
fill 111 283 397 118 283 397 minecraft:magma_block
fill 111 283 408 119 283 408 minecraft:blackstone
fill 111 283 409 119 283 409 minecraft:basalt
fill 112 283 381 117 283 381 minecraft:magma_block
fill 113 283 410 115 300 410 minecraft:polished_blackstone_bricks
fill 118 283 381 131 283 381 minecraft:blackstone
fill 118 283 382 119 283 382 minecraft:magma_block
fill 118 283 396 119 283 396 minecraft:magma_block
fill 119 283 370 121 300 370 minecraft:polished_blackstone_bricks
fill 119 283 397 132 283 397 minecraft:blackstone
fill 120 283 371 120 285 371 minecraft:polished_blackstone_bricks
fill 120 283 372 122 283 372 minecraft:basalt
fill 120 283 382 131 283 382 minecraft:blackstone
setblock 120 283 383 minecraft:magma_block
setblock 120 283 395 minecraft:magma_block
fill 120 283 396 132 283 396 minecraft:blackstone
fill 120 283 408 122 283 408 minecraft:basalt
fill 121 283 383 132 283 383 minecraft:blackstone
fill 121 283 384 121 283 385 minecraft:magma_block
fill 121 283 393 121 283 394 minecraft:magma_block
fill 121 283 395 132 283 395 minecraft:blackstone
fill 122 283 384 132 283 384 minecraft:blackstone
fill 122 283 385 122 283 387 minecraft:magma_block
fill 122 283 391 122 283 393 minecraft:magma_block
fill 122 283 394 133 283 394 minecraft:blackstone
fill 123 283 373 124 283 373 minecraft:basalt
fill 123 283 385 132 283 387 minecraft:blackstone
fill 123 283 388 123 283 391 minecraft:magma_block
fill 123 283 392 133 283 393 minecraft:blackstone
fill 123 283 407 124 283 407 minecraft:basalt
fill 124 283 388 133 283 391 minecraft:blackstone
fill 125 283 374 126 283 374 minecraft:basalt
fill 125 283 406 126 283 406 minecraft:basalt
fill 125 283 410 127 300 410 minecraft:polished_blackstone_bricks
fill 126 283 409 128 285 409 minecraft:polished_blackstone_bricks
setblock 127 283 375 minecraft:basalt
setblock 127 283 405 minecraft:basalt
setblock 128 283 376 minecraft:basalt
setblock 128 283 404 minecraft:basalt
setblock 129 283 377 minecraft:basalt
setblock 129 283 403 minecraft:basalt
fill 130 283 371 132 285 371 minecraft:polished_blackstone_bricks
setblock 130 283 378 minecraft:basalt
setblock 130 283 402 minecraft:basalt
fill 131 283 370 133 300 370 minecraft:polished_blackstone_bricks
fill 131 283 379 131 283 380 minecraft:basalt
fill 131 283 400 131 283 401 minecraft:basalt
fill 132 283 381 132 283 382 minecraft:basalt
fill 132 283 398 132 283 399 minecraft:basalt
fill 133 283 383 133 283 385 minecraft:basalt
fill 133 283 386 133 283 387 minecraft:blackstone
fill 133 283 395 133 283 397 minecraft:basalt
fill 134 283 379 134 285 381 minecraft:polished_blackstone_bricks
fill 134 283 386 134 283 394 minecraft:basalt
fill 134 283 403 134 285 405 minecraft:polished_blackstone_bricks
fill 135 283 378 135 300 380 minecraft:polished_blackstone_bricks
fill 135 283 390 135 300 392 minecraft:polished_blackstone_bricks
fill 135 283 402 135 300 404 minecraft:polished_blackstone_bricks
fill 96 284 391 96 285 393 minecraft:polished_blackstone_bricks
fill 97 284 385 97 284 395 minecraft:basalt
fill 98 284 382 98 284 384 minecraft:basalt
fill 98 284 385 105 284 395 minecraft:blackstone
fill 98 284 396 98 284 398 minecraft:basalt
setblock 99 284 381 minecraft:basalt
fill 99 284 382 106 284 384 minecraft:blackstone
fill 99 284 396 107 284 398 minecraft:blackstone
setblock 99 284 399 minecraft:basalt
fill 100 284 379 100 284 380 minecraft:basalt
fill 100 284 381 109 284 381 minecraft:blackstone
fill 100 284 399 130 284 399 minecraft:blackstone
fill 100 284 400 100 284 401 minecraft:basalt
setblock 101 284 378 minecraft:basalt
fill 101 284 379 112 284 380 minecraft:blackstone
fill 101 284 400 129 284 401 minecraft:blackstone
setblock 101 284 402 minecraft:basalt
setblock 102 284 377 minecraft:basalt
fill 102 284 378 128 284 378 minecraft:blackstone
fill 102 284 402 128 284 402 minecraft:blackstone
setblock 102 284 403 minecraft:basalt
setblock 103 284 376 minecraft:basalt
fill 103 284 377 127 284 377 minecraft:blackstone
fill 103 284 403 127 284 403 minecraft:blackstone
setblock 103 284 404 minecraft:basalt
fill 104 284 375 105 284 375 minecraft:basalt
fill 104 284 376 126 284 376 minecraft:blackstone
fill 104 284 404 126 284 404 minecraft:blackstone
fill 104 284 405 105 284 405 minecraft:basalt
setblock 106 284 374 minecraft:basalt
fill 106 284 375 124 284 375 minecraft:blackstone
setblock 106 284 385 minecraft:blackstone
fill 106 284 386 106 284 387 minecraft:magma_block
fill 106 284 391 106 284 393 minecraft:magma_block
fill 106 284 394 106 284 395 minecraft:blackstone
fill 106 284 405 124 284 405 minecraft:blackstone
setblock 106 284 406 minecraft:basalt
fill 107 284 373 109 284 373 minecraft:basalt
fill 107 284 374 123 284 374 minecraft:blackstone
fill 107 284 382 107 284 383 minecraft:blackstone
fill 107 284 384 107 284 385 minecraft:magma_block
fill 107 284 394 107 284 395 minecraft:magma_block
fill 107 284 406 123 284 406 minecraft:blackstone
fill 107 284 407 109 284 407 minecraft:basalt
setblock 108 284 382 minecraft:blackstone
setblock 108 284 383 minecraft:magma_block
fill 108 284 395 108 284 396 minecraft:magma_block
fill 108 284 397 108 284 398 minecraft:blackstone
setblock 109 284 382 minecraft:magma_block
fill 109 284 396 109 284 397 minecraft:magma_block
fill 109 284 398 110 284 398 minecraft:blackstone
fill 110 284 372 120 284 372 minecraft:basalt
fill 110 284 373 120 284 373 minecraft:blackstone
fill 110 284 381 112 284 381 minecraft:magma_block
setblock 110 284 397 minecraft:magma_block
fill 110 284 407 120 284 407 minecraft:blackstone
fill 110 284 408 120 284 408 minecraft:basalt
fill 111 284 398 118 284 398 minecraft:magma_block
fill 113 284 379 129 284 379 minecraft:blackstone
fill 113 284 380 117 284 380 minecraft:magma_block
fill 114 284 409 116 285 409 minecraft:polished_blackstone_bricks
fill 118 284 371 119 285 371 minecraft:polished_blackstone_bricks
fill 118 284 380 129 284 380 minecraft:blackstone
fill 118 284 381 119 284 381 minecraft:magma_block
fill 119 284 397 120 284 397 minecraft:magma_block
fill 119 284 398 131 284 398 minecraft:blackstone
fill 120 284 381 130 284 381 minecraft:blackstone
setblock 120 284 382 minecraft:magma_block
fill 120 284 396 121 284 396 minecraft:magma_block
fill 121 284 373 123 284 373 minecraft:basalt
fill 121 284 382 131 284 382 minecraft:blackstone
setblock 121 284 383 minecraft:magma_block
fill 121 284 395 122 284 395 minecraft:magma_block
fill 121 284 397 131 284 397 minecraft:blackstone
fill 121 284 407 123 284 407 minecraft:basalt
fill 122 284 383 131 284 383 minecraft:blackstone
setblock 122 284 384 minecraft:magma_block
fill 122 284 394 123 284 394 minecraft:magma_block
fill 122 284 396 131 284 396 minecraft:blackstone
fill 123 284 384 131 284 384 minecraft:blackstone
fill 123 284 385 123 284 387 minecraft:magma_block
fill 123 284 392 123 284 393 minecraft:magma_block
fill 123 284 395 132 284 395 minecraft:blackstone
setblock 124 284 374 minecraft:basalt
fill 124 284 385 132 284 387 minecraft:blackstone
fill 124 284 388 124 284 391 minecraft:magma_block
fill 124 284 392 132 284 394 minecraft:blackstone
setblock 124 284 406 minecraft:basalt
fill 125 284 375 126 284 375 minecraft:basalt
fill 125 284 388 132 284 391 minecraft:blackstone
fill 125 284 405 126 284 405 minecraft:basalt
setblock 127 284 376 minecraft:basalt
setblock 127 284 404 minecraft:basalt
setblock 128 284 377 minecraft:basalt
setblock 128 284 403 minecraft:basalt
setblock 129 284 378 minecraft:basalt
setblock 129 284 402 minecraft:basalt
fill 130 284 379 130 284 380 minecraft:basalt
fill 130 284 400 130 284 401 minecraft:basalt
setblock 131 284 381 minecraft:basalt
setblock 131 284 399 minecraft:basalt
fill 132 284 382 132 284 384 minecraft:basalt
fill 132 284 396 132 284 398 minecraft:basalt
fill 133 284 385 133 284 395 minecraft:basalt
fill 134 284 391 134 285 393 minecraft:polished_blackstone_bricks
fill 95 285 373 95 285 378 minecraft:blackstone
fill 95 285 385 95 285 390 minecraft:blackstone
fill 95 285 397 95 285 402 minecraft:blackstone
fill 95 285 409 95 285 410 minecraft:blackstone
fill 96 285 410 99 285 410 minecraft:blackstone
fill 98 285 385 98 285 395 minecraft:basalt
fill 99 285 370 104 285 370 minecraft:blackstone
fill 99 285 382 99 285 384 minecraft:basalt
fill 99 285 385 104 285 395 minecraft:blackstone
fill 99 285 396 99 285 398 minecraft:basalt
fill 100 285 381 100 285 382 minecraft:basalt
fill 100 285 383 105 285 384 minecraft:blackstone
fill 100 285 396 106 285 397 minecraft:blackstone
fill 100 285 398 100 285 399 minecraft:basalt
fill 101 285 379 101 285 380 minecraft:basalt
fill 101 285 381 107 285 382 minecraft:blackstone
fill 101 285 398 108 285 399 minecraft:blackstone
fill 101 285 400 101 285 401 minecraft:basalt
fill 102 285 378 102 285 379 minecraft:basalt
fill 102 285 380 110 285 380 minecraft:blackstone
fill 102 285 400 112 285 400 minecraft:blackstone
fill 102 285 401 102 285 402 minecraft:basalt
fill 103 285 377 103 285 378 minecraft:basalt
fill 103 285 379 113 285 379 minecraft:blackstone
fill 103 285 401 127 285 401 minecraft:blackstone
fill 103 285 402 103 285 403 minecraft:basalt
fill 104 285 376 104 285 377 minecraft:basalt
fill 104 285 378 126 285 378 minecraft:blackstone
fill 104 285 402 126 285 402 minecraft:blackstone
fill 104 285 403 104 285 404 minecraft:basalt
setblock 105 285 376 minecraft:basalt
fill 105 285 377 125 285 377 minecraft:blackstone
setblock 105 285 385 minecraft:blackstone
fill 105 285 386 105 285 393 minecraft:shroomlight
fill 105 285 394 105 285 395 minecraft:blackstone
fill 105 285 403 125 285 403 minecraft:blackstone
setblock 105 285 404 minecraft:basalt
fill 106 285 375 107 285 375 minecraft:basalt
fill 106 285 376 124 285 376 minecraft:blackstone
setblock 106 285 383 minecraft:blackstone
fill 106 285 384 106 285 385 minecraft:shroomlight
fill 106 285 394 106 285 395 minecraft:shroomlight
fill 106 285 404 124 285 404 minecraft:blackstone
fill 106 285 405 107 285 405 minecraft:basalt
fill 106 285 410 111 285 410 minecraft:blackstone
fill 107 285 374 109 285 374 minecraft:basalt
setblock 107 285 383 minecraft:shroomlight
setblock 107 285 396 minecraft:shroomlight
setblock 107 285 397 minecraft:blackstone
fill 107 285 406 109 285 406 minecraft:basalt
fill 108 285 375 122 285 375 minecraft:blackstone
setblock 108 285 381 minecraft:blackstone
setblock 108 285 382 minecraft:shroomlight
setblock 108 285 397 minecraft:shroomlight
fill 108 285 405 122 285 405 minecraft:blackstone
fill 109 285 381 110 285 381 minecraft:shroomlight
fill 109 285 398 110 285 398 minecraft:shroomlight
setblock 109 285 399 minecraft:blackstone
fill 110 285 373 120 285 373 minecraft:basalt
fill 110 285 374 120 285 374 minecraft:blackstone
fill 110 285 399 119 285 399 minecraft:shroomlight
fill 110 285 406 120 285 406 minecraft:blackstone
fill 110 285 407 120 285 407 minecraft:basalt
fill 111 285 370 116 285 370 minecraft:blackstone
fill 111 285 380 113 285 380 minecraft:shroomlight
fill 113 285 400 116 285 400 minecraft:shroomlight
fill 114 285 379 116 285 379 minecraft:shroomlight
fill 117 285 379 127 285 379 minecraft:blackstone
fill 117 285 380 119 285 380 minecraft:shroomlight
fill 117 285 400 128 285 400 minecraft:blackstone
fill 118 285 410 123 285 410 minecraft:blackstone
fill 119 285 398 121 285 398 minecraft:shroomlight
fill 120 285 380 128 285 380 minecraft:blackstone
setblock 120 285 381 minecraft:shroomlight
fill 120 285 399 129 285 399 minecraft:blackstone
fill 121 285 374 123 285 374 minecraft:basalt
fill 121 285 381 129 285 381 minecraft:blackstone
fill 121 285 382 122 285 382 minecraft:shroomlight
fill 121 285 397 122 285 397 minecraft:shroomlight
fill 121 285 406 123 285 406 minecraft:basalt
setblock 122 285 383 minecraft:shroomlight
fill 122 285 396 123 285 396 minecraft:shroomlight
fill 122 285 398 129 285 398 minecraft:blackstone
fill 123 285 370 128 285 370 minecraft:blackstone
fill 123 285 375 124 285 375 minecraft:basalt
fill 123 285 382 129 285 383 minecraft:blackstone
setblock 123 285 384 minecraft:shroomlight
setblock 123 285 395 minecraft:shroomlight
fill 123 285 397 130 285 397 minecraft:blackstone
fill 123 285 405 124 285 405 minecraft:basalt
fill 124 285 384 130 285 384 minecraft:blackstone
fill 124 285 385 124 285 387 minecraft:shroomlight
fill 124 285 392 124 285 394 minecraft:shroomlight
fill 124 285 395 130 285 396 minecraft:blackstone
fill 125 285 376 126 285 376 minecraft:basalt
fill 125 285 385 131 285 386 minecraft:blackstone
fill 125 285 387 125 285 392 minecraft:shroomlight
fill 125 285 393 131 285 394 minecraft:blackstone
fill 125 285 404 126 285 404 minecraft:basalt
fill 126 285 377 127 285 377 minecraft:basalt
fill 126 285 387 131 285 392 minecraft:blackstone
fill 126 285 403 127 285 403 minecraft:basalt
fill 127 285 378 128 285 378 minecraft:basalt
fill 127 285 402 128 285 402 minecraft:basalt
fill 128 285 379 129 285 379 minecraft:basalt
fill 128 285 401 129 285 401 minecraft:basalt
setblock 129 285 380 minecraft:basalt
setblock 129 285 400 minecraft:basalt
fill 130 285 381 130 285 382 minecraft:basalt
setblock 130 285 383 minecraft:blackstone
fill 130 285 398 130 285 399 minecraft:basalt
fill 130 285 410 135 285 410 minecraft:blackstone
fill 131 285 382 131 285 384 minecraft:basalt
setblock 131 285 395 minecraft:blackstone
fill 131 285 396 131 285 398 minecraft:basalt
fill 132 285 385 132 285 395 minecraft:basalt
fill 135 285 370 135 285 375 minecraft:blackstone
fill 135 285 382 135 285 387 minecraft:blackstone
fill 135 285 394 135 285 399 minecraft:blackstone
fill 135 285 406 135 285 409 minecraft:blackstone
fill 94 286 375 94 291 378 minecraft:shroomlight
fill 94 286 387 94 291 390 minecraft:shroomlight
fill 94 286 399 94 291 402 minecraft:shroomlight
fill 94 286 411 97 291 411 minecraft:shroomlight
fill 99 286 385 99 286 395 minecraft:basalt
fill 100 286 383 100 286 387 minecraft:basalt
fill 100 286 388 103 286 392 minecraft:blackstone
fill 100 286 393 100 286 397 minecraft:basalt
fill 101 286 369 104 291 369 minecraft:shroomlight
fill 101 286 381 101 286 384 minecraft:basalt
fill 101 286 385 103 286 387 minecraft:blackstone
fill 101 286 393 103 286 395 minecraft:blackstone
fill 101 286 396 101 286 399 minecraft:basalt
fill 102 286 380 102 286 382 minecraft:basalt
fill 102 286 383 104 286 384 minecraft:blackstone
fill 102 286 396 105 286 397 minecraft:blackstone
fill 102 286 398 102 286 400 minecraft:basalt
fill 103 286 379 103 286 380 minecraft:basalt
fill 103 286 381 106 286 382 minecraft:blackstone
fill 103 286 398 106 286 399 minecraft:blackstone
fill 103 286 400 103 286 401 minecraft:basalt
fill 104 286 378 104 286 379 minecraft:basalt
fill 104 286 380 108 286 380 minecraft:blackstone
setblock 104 286 385 minecraft:blackstone
fill 104 286 386 104 286 393 minecraft:magma_block
fill 104 286 394 104 286 395 minecraft:blackstone
fill 104 286 400 109 286 400 minecraft:blackstone
fill 104 286 401 104 286 402 minecraft:basalt
fill 105 286 377 105 286 378 minecraft:basalt
fill 105 286 379 110 286 379 minecraft:blackstone
setblock 105 286 383 minecraft:blackstone
fill 105 286 384 105 286 385 minecraft:magma_block
fill 105 286 394 105 286 395 minecraft:magma_block
fill 105 286 401 111 286 401 minecraft:blackstone
fill 105 286 402 105 286 403 minecraft:basalt
fill 106 286 376 107 286 377 minecraft:basalt
fill 106 286 378 124 286 378 minecraft:blackstone
setblock 106 286 383 minecraft:magma_block
fill 106 286 396 106 286 397 minecraft:magma_block
fill 106 286 402 124 286 402 minecraft:blackstone
fill 106 286 403 107 286 404 minecraft:basalt
fill 106 286 411 109 291 411 minecraft:shroomlight
setblock 107 286 381 minecraft:blackstone
setblock 107 286 382 minecraft:magma_block
fill 107 286 397 107 286 398 minecraft:magma_block
setblock 107 286 399 minecraft:blackstone
fill 108 286 375 109 286 376 minecraft:basalt
fill 108 286 377 122 286 377 minecraft:blackstone
setblock 108 286 381 minecraft:magma_block
fill 108 286 398 108 286 399 minecraft:magma_block
fill 108 286 403 122 286 403 minecraft:blackstone
fill 108 286 404 109 286 405 minecraft:basalt
fill 109 286 380 110 286 380 minecraft:magma_block
setblock 109 286 399 minecraft:magma_block
fill 110 286 374 112 286 375 minecraft:basalt
fill 110 286 376 120 286 376 minecraft:blackstone
fill 110 286 400 112 286 400 minecraft:magma_block
fill 110 286 404 120 286 404 minecraft:blackstone
fill 110 286 405 112 286 406 minecraft:basalt
fill 111 286 379 119 286 379 minecraft:magma_block
fill 112 286 401 117 286 401 minecraft:magma_block
fill 113 286 369 116 291 369 minecraft:shroomlight
fill 113 286 374 120 286 374 minecraft:basalt
fill 113 286 375 117 286 375 minecraft:blackstone
fill 113 286 399 114 286 400 minecraft:blackstone
fill 113 286 405 117 286 405 minecraft:blackstone
fill 113 286 406 120 286 406 minecraft:basalt
fill 114 286 398 117 286 398 minecraft:blackstone
fill 115 286 399 118 286 399 minecraft:blackstone
fill 115 286 400 116 300 400 minecraft:polished_blackstone_bricks
fill 117 286 400 120 286 400 minecraft:magma_block
fill 118 286 375 122 286 375 minecraft:basalt
fill 118 286 401 125 286 401 minecraft:blackstone
fill 118 286 405 122 286 405 minecraft:basalt
fill 118 286 411 121 291 411 minecraft:shroomlight
fill 120 286 379 125 286 379 minecraft:blackstone
setblock 120 286 380 minecraft:magma_block
fill 120 286 399 121 286 399 minecraft:magma_block
fill 121 286 376 124 286 376 minecraft:basalt
fill 121 286 380 126 286 380 minecraft:blackstone
fill 121 286 381 122 286 381 minecraft:magma_block
fill 121 286 400 126 286 400 minecraft:blackstone
fill 121 286 404 124 286 404 minecraft:basalt
fill 122 286 398 123 286 398 minecraft:magma_block
fill 122 286 399 127 286 399 minecraft:blackstone
fill 123 286 377 125 286 377 minecraft:basalt
fill 123 286 381 127 286 381 minecraft:blackstone
fill 123 286 382 123 286 383 minecraft:magma_block
setblock 123 286 397 minecraft:magma_block
fill 123 286 403 125 286 403 minecraft:basalt
fill 124 286 382 127 286 382 minecraft:blackstone
fill 124 286 383 124 286 384 minecraft:magma_block
fill 124 286 395 124 286 396 minecraft:magma_block
fill 124 286 397 127 286 398 minecraft:blackstone
fill 125 286 369 128 291 369 minecraft:shroomlight
fill 125 286 378 126 286 378 minecraft:basalt
fill 125 286 383 128 286 384 minecraft:blackstone
fill 125 286 385 125 286 386 minecraft:magma_block
fill 125 286 393 125 286 395 minecraft:magma_block
fill 125 286 396 128 286 396 minecraft:blackstone
fill 125 286 402 126 286 402 minecraft:basalt
fill 126 286 379 127 286 379 minecraft:basalt
fill 126 286 385 129 286 386 minecraft:blackstone
fill 126 286 387 126 286 393 minecraft:magma_block
fill 126 286 394 129 286 395 minecraft:blackstone
fill 126 286 401 127 286 401 minecraft:basalt
fill 127 286 380 128 286 380 minecraft:basalt
fill 127 286 387 129 286 393 minecraft:blackstone
fill 127 286 400 128 286 400 minecraft:basalt
fill 128 286 381 129 286 382 minecraft:basalt
setblock 128 286 397 minecraft:blackstone
fill 128 286 398 129 286 399 minecraft:basalt
fill 129 286 383 130 286 384 minecraft:basalt
fill 129 286 396 130 286 397 minecraft:basalt
fill 130 286 385 131 286 387 minecraft:basalt
fill 130 286 388 130 286 392 minecraft:blackstone
fill 130 286 393 131 286 395 minecraft:basalt
fill 130 286 411 133 291 411 minecraft:shroomlight
fill 131 286 388 131 286 392 minecraft:basalt
fill 136 286 370 136 291 373 minecraft:shroomlight
fill 136 286 382 136 291 385 minecraft:shroomlight
fill 136 286 394 136 291 397 minecraft:shroomlight
fill 136 286 406 136 291 409 minecraft:shroomlight
setblock 97 287 372 minecraft:light[level=14]
setblock 97 287 380 minecraft:light[level=14]
setblock 97 287 388 minecraft:light[level=14]
setblock 97 287 396 minecraft:light[level=14]
setblock 97 287 404 minecraft:light[level=14]
fill 100 287 388 102 287 392 minecraft:basalt
fill 101 287 385 102 287 387 minecraft:basalt
fill 101 287 393 102 287 395 minecraft:basalt
fill 102 287 383 104 287 384 minecraft:basalt
fill 102 287 396 104 287 397 minecraft:basalt
fill 103 287 381 105 287 382 minecraft:basalt
fill 103 287 385 103 287 386 minecraft:basalt
fill 103 287 387 103 287 393 minecraft:magma_block
fill 103 287 394 103 287 395 minecraft:basalt
fill 103 287 398 105 287 399 minecraft:basalt
fill 104 287 380 107 287 380 minecraft:basalt
fill 104 287 385 104 287 386 minecraft:magma_block
fill 104 287 394 104 287 395 minecraft:magma_block
fill 104 287 400 107 287 400 minecraft:basalt
setblock 105 287 372 minecraft:light[level=14]
fill 105 287 379 109 287 379 minecraft:basalt
fill 105 287 383 105 287 384 minecraft:magma_block
setblock 105 287 388 minecraft:light[level=14]
fill 105 287 396 105 287 397 minecraft:magma_block
fill 105 287 401 109 287 401 minecraft:basalt
setblock 105 287 404 minecraft:light[level=14]
fill 106 287 378 111 287 378 minecraft:basalt
setblock 106 287 381 minecraft:basalt
setblock 106 287 382 minecraft:magma_block
setblock 106 287 398 minecraft:magma_block
setblock 106 287 399 minecraft:basalt
fill 106 287 402 111 287 402 minecraft:basalt
setblock 107 287 381 minecraft:magma_block
setblock 107 287 399 minecraft:magma_block
fill 108 287 377 122 287 377 minecraft:basalt
fill 108 287 380 109 287 380 minecraft:magma_block
fill 108 287 400 109 287 400 minecraft:magma_block
fill 108 287 403 122 287 403 minecraft:basalt
fill 110 287 376 120 287 376 minecraft:basalt
fill 110 287 379 111 287 379 minecraft:magma_block
fill 110 287 401 111 287 401 minecraft:magma_block
fill 110 287 404 120 287 404 minecraft:basalt
fill 112 287 378 118 287 378 minecraft:magma_block
fill 112 287 402 117 287 402 minecraft:magma_block
setblock 113 287 372 minecraft:light[level=14]
fill 113 287 375 117 287 375 minecraft:basalt
setblock 113 287 380 minecraft:light[level=14]
setblock 113 287 396 minecraft:light[level=14]
fill 113 287 405 117 287 405 minecraft:basalt
fill 114 287 401 117 300 401 minecraft:polished_blackstone_bricks
fill 118 287 401 120 287 401 minecraft:magma_block
fill 118 287 402 124 287 402 minecraft:basalt
fill 119 287 378 124 287 378 minecraft:basalt
fill 119 287 379 120 287 379 minecraft:magma_block
setblock 121 287 372 minecraft:light[level=14]
fill 121 287 379 125 287 379 minecraft:basalt
fill 121 287 380 122 287 380 minecraft:magma_block
setblock 121 287 388 minecraft:light[level=14]
setblock 121 287 396 minecraft:light[level=14]
setblock 121 287 400 minecraft:magma_block
fill 121 287 401 125 287 401 minecraft:basalt
setblock 121 287 404 minecraft:light[level=14]
fill 122 287 399 123 287 399 minecraft:magma_block
fill 122 287 400 126 287 400 minecraft:basalt
fill 123 287 380 126 287 380 minecraft:basalt
setblock 123 287 381 minecraft:magma_block
fill 124 287 381 127 287 381 minecraft:basalt
setblock 124 287 382 minecraft:magma_block
fill 124 287 397 124 287 398 minecraft:magma_block
fill 124 287 399 127 287 399 minecraft:basalt
fill 125 287 382 127 287 382 minecraft:basalt
fill 125 287 383 125 287 384 minecraft:magma_block
setblock 125 287 396 minecraft:magma_block
fill 125 287 397 127 287 398 minecraft:basalt
fill 126 287 383 128 287 384 minecraft:basalt
fill 126 287 385 126 287 386 minecraft:magma_block
fill 126 287 394 126 287 395 minecraft:magma_block
fill 126 287 396 128 287 396 minecraft:basalt
fill 127 287 385 129 287 386 minecraft:basalt
fill 127 287 387 127 287 393 minecraft:magma_block
fill 127 287 394 129 287 395 minecraft:basalt
fill 128 287 387 129 287 393 minecraft:basalt
setblock 128 287 397 minecraft:basalt
setblock 129 287 372 minecraft:light[level=14]
setblock 129 287 380 minecraft:light[level=14]
setblock 129 287 396 minecraft:light[level=14]
setblock 129 287 404 minecraft:light[level=14]
fill 130 287 388 130 287 392 minecraft:basalt
fill 114 288 402 117 300 404 minecraft:polished_blackstone_bricks
setblock 129 288 387 minecraft:netherite_block
fill 103 290 380 104 291 382 minecraft:magma_block
fill 94 292 375 94 307 375 minecraft:blackstone
fill 94 292 376 94 292 377 minecraft:shroomlight
fill 94 292 378 94 307 378 minecraft:blackstone
fill 94 292 387 94 307 387 minecraft:blackstone
fill 94 292 388 94 292 389 minecraft:shroomlight
fill 94 292 390 94 307 390 minecraft:blackstone
fill 94 292 399 94 307 399 minecraft:blackstone
fill 94 292 400 94 292 401 minecraft:shroomlight
fill 94 292 402 94 307 402 minecraft:blackstone
fill 94 292 411 94 307 411 minecraft:blackstone
fill 95 292 411 96 292 411 minecraft:shroomlight
fill 97 292 411 97 307 411 minecraft:blackstone
fill 101 292 369 101 307 369 minecraft:blackstone
fill 102 292 369 103 292 369 minecraft:shroomlight
fill 104 292 369 104 307 369 minecraft:blackstone
fill 106 292 411 106 307 411 minecraft:blackstone
fill 107 292 411 108 292 411 minecraft:shroomlight
fill 109 292 411 109 307 411 minecraft:blackstone
fill 113 292 369 113 307 369 minecraft:blackstone
fill 114 292 369 115 292 369 minecraft:shroomlight
fill 116 292 369 116 307 369 minecraft:blackstone
fill 118 292 411 118 307 411 minecraft:blackstone
fill 119 292 411 120 292 411 minecraft:shroomlight
fill 121 292 411 121 307 411 minecraft:blackstone
fill 125 292 369 125 307 369 minecraft:blackstone
fill 126 292 369 127 292 369 minecraft:shroomlight
fill 128 292 369 128 307 369 minecraft:blackstone
fill 130 292 411 130 307 411 minecraft:blackstone
fill 131 292 411 132 292 411 minecraft:shroomlight
fill 133 292 411 133 307 411 minecraft:blackstone
fill 136 292 370 136 307 370 minecraft:blackstone
fill 136 292 371 136 292 372 minecraft:shroomlight
fill 136 292 373 136 307 373 minecraft:blackstone
fill 136 292 382 136 307 382 minecraft:blackstone
fill 136 292 383 136 292 384 minecraft:shroomlight
fill 136 292 385 136 307 385 minecraft:blackstone
fill 136 292 394 136 307 394 minecraft:blackstone
fill 136 292 395 136 292 396 minecraft:shroomlight
fill 136 292 397 136 307 397 minecraft:blackstone
fill 136 292 406 136 307 406 minecraft:blackstone
fill 136 292 407 136 292 408 minecraft:shroomlight
fill 136 292 409 136 307 409 minecraft:blackstone
fill 94 293 376 94 307 377 minecraft:blackstone
fill 94 293 388 94 307 389 minecraft:blackstone
fill 94 293 400 94 307 401 minecraft:blackstone
fill 95 293 411 96 307 411 minecraft:blackstone
fill 102 293 369 103 307 369 minecraft:blackstone
fill 107 293 411 108 307 411 minecraft:blackstone
fill 114 293 369 115 307 369 minecraft:blackstone
fill 119 293 411 120 307 411 minecraft:blackstone
fill 126 293 369 127 307 369 minecraft:blackstone
fill 131 293 411 132 307 411 minecraft:blackstone
fill 136 293 371 136 307 372 minecraft:blackstone
fill 136 293 383 136 307 384 minecraft:blackstone
fill 136 293 395 136 307 396 minecraft:blackstone
fill 136 293 407 136 307 408 minecraft:blackstone
setblock 97 295 372 minecraft:light[level=14]
setblock 97 295 380 minecraft:light[level=14]
setblock 97 295 388 minecraft:light[level=14]
setblock 97 295 396 minecraft:light[level=14]
setblock 97 295 404 minecraft:light[level=14]
setblock 105 295 372 minecraft:light[level=14]
setblock 105 295 380 minecraft:light[level=14]
setblock 105 295 388 minecraft:light[level=14]
setblock 105 295 396 minecraft:light[level=14]
setblock 105 295 404 minecraft:light[level=14]
setblock 113 295 372 minecraft:light[level=14]
setblock 113 295 380 minecraft:light[level=14]
setblock 113 295 388 minecraft:light[level=14]
setblock 113 295 396 minecraft:light[level=14]
setblock 113 295 404 minecraft:light[level=14]
setblock 121 295 372 minecraft:light[level=14]
setblock 121 295 380 minecraft:light[level=14]
setblock 121 295 388 minecraft:light[level=14]
setblock 121 295 396 minecraft:light[level=14]
setblock 121 295 404 minecraft:light[level=14]
setblock 129 295 372 minecraft:light[level=14]
setblock 129 295 380 minecraft:light[level=14]
setblock 129 295 388 minecraft:light[level=14]
setblock 129 295 396 minecraft:light[level=14]
setblock 129 295 404 minecraft:light[level=14]
fill 111 297 401 113 297 403 minecraft:orange_concrete
fill 112 297 399 114 297 400 minecraft:orange_concrete
fill 112 297 404 113 297 405 minecraft:orange_concrete
fill 113 297 406 118 297 406 minecraft:orange_concrete
fill 114 297 398 117 297 398 minecraft:orange_concrete
fill 114 297 405 119 297 405 minecraft:orange_concrete
fill 115 297 399 119 297 399 minecraft:orange_concrete
fill 117 297 400 119 297 400 minecraft:orange_concrete
fill 118 297 401 119 297 404 minecraft:orange_concrete
fill 120 297 401 120 297 403 minecraft:orange_concrete
fill 112 298 401 113 298 403 minecraft:orange_concrete
fill 113 298 399 114 298 400 minecraft:orange_concrete
fill 113 298 404 113 298 405 minecraft:orange_concrete
fill 114 298 405 118 298 405 minecraft:orange_concrete
fill 115 298 399 118 298 399 minecraft:orange_concrete
fill 115 298 406 116 298 406 minecraft:orange_concrete
fill 117 298 400 118 298 400 minecraft:orange_concrete
fill 118 298 401 118 299 404 minecraft:orange_concrete
fill 119 298 401 119 298 403 minecraft:orange_concrete
fill 113 299 400 113 299 404 minecraft:orange_concrete
setblock 114 299 400 minecraft:orange_concrete
fill 115 299 399 116 299 399 minecraft:orange_concrete
fill 115 299 405 116 299 405 minecraft:orange_concrete
setblock 117 299 400 minecraft:orange_concrete
fill 96 300 379 96 300 381 minecraft:polished_blackstone_bricks
fill 96 300 391 96 300 393 minecraft:polished_blackstone_bricks
fill 96 300 403 96 300 405 minecraft:polished_blackstone_bricks
fill 102 300 409 104 300 409 minecraft:polished_blackstone_bricks
fill 106 300 371 108 300 371 minecraft:polished_blackstone_bricks
fill 114 300 409 116 300 409 minecraft:polished_blackstone_bricks
fill 118 300 371 120 300 371 minecraft:polished_blackstone_bricks
fill 126 300 409 128 300 409 minecraft:polished_blackstone_bricks
fill 130 300 371 132 300 371 minecraft:polished_blackstone_bricks
fill 134 300 379 134 300 381 minecraft:polished_blackstone_bricks
fill 134 300 391 134 300 393 minecraft:polished_blackstone_bricks
fill 134 300 403 134 300 405 minecraft:polished_blackstone_bricks
setblock 97 303 372 minecraft:light[level=14]
setblock 97 303 380 minecraft:light[level=14]
setblock 97 303 388 minecraft:light[level=14]
setblock 97 303 396 minecraft:light[level=14]
setblock 97 303 404 minecraft:light[level=14]
setblock 105 303 372 minecraft:light[level=14]
setblock 105 303 380 minecraft:light[level=14]
setblock 105 303 388 minecraft:light[level=14]
setblock 105 303 396 minecraft:light[level=14]
setblock 105 303 404 minecraft:light[level=14]
setblock 113 303 372 minecraft:light[level=14]
setblock 113 303 380 minecraft:light[level=14]
setblock 113 303 388 minecraft:light[level=14]
setblock 113 303 396 minecraft:light[level=14]
setblock 113 303 404 minecraft:light[level=14]
setblock 121 303 372 minecraft:light[level=14]
setblock 121 303 380 minecraft:light[level=14]
setblock 121 303 388 minecraft:light[level=14]
setblock 121 303 396 minecraft:light[level=14]
setblock 121 303 404 minecraft:light[level=14]
setblock 129 303 372 minecraft:light[level=14]
setblock 129 303 380 minecraft:light[level=14]
setblock 129 303 388 minecraft:light[level=14]
setblock 129 303 396 minecraft:light[level=14]
setblock 129 303 404 minecraft:light[level=14]
