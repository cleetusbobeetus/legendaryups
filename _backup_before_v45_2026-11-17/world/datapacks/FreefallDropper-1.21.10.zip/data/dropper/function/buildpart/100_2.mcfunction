fill 200 183 418 202 185 418 minecraft:polished_deepslate
fill 201 183 417 203 226 417 minecraft:polished_deepslate
fill 207 183 457 209 226 457 minecraft:polished_deepslate
fill 208 183 456 210 185 456 minecraft:polished_deepslate
fill 212 183 418 214 185 418 minecraft:polished_deepslate
fill 213 183 417 215 226 417 minecraft:polished_deepslate
fill 219 183 457 221 226 457 minecraft:polished_deepslate
fill 220 183 456 222 185 456 minecraft:polished_deepslate
fill 223 183 437 229 201 440 minecraft:polished_deepslate
fill 224 183 418 226 185 418 minecraft:polished_deepslate
fill 224 183 436 229 214 436 minecraft:polished_deepslate
fill 224 183 441 229 184 441 minecraft:polished_deepslate
fill 225 183 417 227 226 417 minecraft:polished_deepslate
fill 225 183 435 228 214 435 minecraft:polished_deepslate
fill 225 183 442 228 188 442 minecraft:polished_deepslate
fill 228 183 426 228 185 428 minecraft:polished_deepslate
fill 228 183 450 228 185 452 minecraft:polished_deepslate
fill 229 183 425 229 226 427 minecraft:polished_deepslate
fill 229 183 449 229 226 451 minecraft:polished_deepslate
fill 189 185 420 189 185 425 minecraft:deepslate
fill 189 185 432 189 185 437 minecraft:deepslate
fill 189 185 438 194 198 441 minecraft:polished_deepslate
fill 189 185 444 189 185 449 minecraft:deepslate
fill 189 185 456 189 185 457 minecraft:deepslate
fill 190 185 436 194 214 437 minecraft:polished_deepslate
fill 190 185 457 193 185 457 minecraft:deepslate
fill 193 185 417 198 185 417 minecraft:deepslate
fill 200 185 457 205 185 457 minecraft:deepslate
fill 205 185 417 210 185 417 minecraft:deepslate
fill 212 185 457 217 185 457 minecraft:deepslate
fill 217 185 417 222 185 417 minecraft:deepslate
fill 224 185 441 228 198 441 minecraft:polished_deepslate
fill 224 185 457 229 185 457 minecraft:deepslate
fill 229 185 417 229 185 422 minecraft:deepslate
fill 229 185 429 229 185 434 minecraft:deepslate
fill 229 185 441 229 185 446 minecraft:deepslate
fill 229 185 453 229 185 456 minecraft:deepslate
fill 188 186 422 188 191 425 minecraft:shroomlight
fill 188 186 434 188 191 437 minecraft:shroomlight
fill 188 186 446 188 191 449 minecraft:shroomlight
fill 188 186 458 191 191 458 minecraft:shroomlight
fill 189 186 436 189 204 437 minecraft:polished_deepslate
fill 194 186 435 194 214 435 minecraft:polished_deepslate
fill 195 186 416 198 191 416 minecraft:shroomlight
fill 195 186 436 195 214 436 minecraft:polished_deepslate
fill 200 186 458 203 191 458 minecraft:shroomlight
fill 207 186 416 210 191 416 minecraft:shroomlight
fill 212 186 458 215 191 458 minecraft:shroomlight
fill 219 186 416 222 191 416 minecraft:shroomlight
fill 223 186 436 223 214 436 minecraft:polished_deepslate
fill 224 186 435 224 214 435 minecraft:polished_deepslate
fill 224 186 458 227 191 458 minecraft:shroomlight
fill 229 186 441 229 192 441 minecraft:polished_deepslate
fill 230 186 417 230 191 420 minecraft:shroomlight
fill 230 186 429 230 191 432 minecraft:shroomlight
fill 230 186 441 230 191 444 minecraft:shroomlight
fill 230 186 453 230 191 456 minecraft:shroomlight
fill 189 187 435 189 204 435 minecraft:polished_deepslate
fill 229 187 435 229 213 435 minecraft:polished_deepslate
fill 192 188 434 192 214 434 minecraft:polished_deepslate
fill 226 188 434 226 214 434 minecraft:polished_deepslate
fill 191 189 434 191 214 434 minecraft:polished_deepslate
fill 191 189 442 193 190 442 minecraft:polished_deepslate
fill 225 189 442 227 190 442 minecraft:polished_deepslate
fill 227 189 434 227 214 434 minecraft:polished_deepslate
setblock 191 190 419 minecraft:light[level=13]
setblock 191 190 427 minecraft:light[level=13]
setblock 191 190 443 minecraft:light[level=13]
setblock 191 190 451 minecraft:light[level=13]
setblock 199 190 419 minecraft:light[level=13]
setblock 199 190 427 minecraft:light[level=13]
setblock 199 190 435 minecraft:light[level=13]
setblock 199 190 443 minecraft:light[level=13]
setblock 199 190 451 minecraft:light[level=13]
setblock 207 190 419 minecraft:light[level=13]
setblock 207 190 427 minecraft:light[level=13]
setblock 207 190 443 minecraft:light[level=13]
setblock 207 190 451 minecraft:light[level=13]
setblock 215 190 419 minecraft:light[level=13]
setblock 215 190 427 minecraft:light[level=13]
setblock 215 190 435 minecraft:light[level=13]
setblock 215 190 443 minecraft:light[level=13]
setblock 215 190 451 minecraft:light[level=13]
setblock 223 190 419 minecraft:light[level=13]
setblock 223 190 427 minecraft:light[level=13]
setblock 223 190 435 minecraft:light[level=13]
setblock 223 190 443 minecraft:light[level=13]
setblock 223 190 451 minecraft:light[level=13]
fill 191 191 442 192 192 442 minecraft:polished_deepslate
fill 193 191 434 193 214 434 minecraft:polished_deepslate
fill 225 191 434 225 214 434 minecraft:polished_deepslate
fill 226 191 442 227 192 442 minecraft:polished_deepslate
fill 188 192 422 188 205 422 minecraft:polished_andesite
fill 188 192 423 188 192 424 minecraft:shroomlight
fill 188 192 425 188 205 425 minecraft:polished_andesite
fill 188 192 434 188 205 434 minecraft:polished_andesite
fill 188 192 435 188 192 436 minecraft:shroomlight
fill 188 192 437 188 205 437 minecraft:polished_andesite
fill 188 192 446 188 205 446 minecraft:polished_andesite
fill 188 192 447 188 192 448 minecraft:shroomlight
fill 188 192 449 188 205 449 minecraft:polished_andesite
fill 188 192 458 188 205 458 minecraft:polished_andesite
fill 189 192 458 190 192 458 minecraft:shroomlight
fill 191 192 458 191 205 458 minecraft:polished_andesite
fill 195 192 416 195 205 416 minecraft:polished_andesite
fill 196 192 416 197 192 416 minecraft:shroomlight
fill 198 192 416 198 205 416 minecraft:polished_andesite
fill 200 192 458 200 205 458 minecraft:polished_andesite
fill 201 192 458 202 192 458 minecraft:shroomlight
fill 203 192 458 203 205 458 minecraft:polished_andesite
fill 207 192 416 207 205 416 minecraft:polished_andesite
fill 208 192 416 209 192 416 minecraft:shroomlight
fill 210 192 416 210 205 416 minecraft:polished_andesite
fill 212 192 458 212 205 458 minecraft:polished_andesite
fill 213 192 458 214 192 458 minecraft:shroomlight
fill 215 192 458 215 205 458 minecraft:polished_andesite
fill 219 192 416 219 205 416 minecraft:polished_andesite
fill 220 192 416 221 192 416 minecraft:shroomlight
fill 222 192 416 222 205 416 minecraft:polished_andesite
fill 224 192 458 224 205 458 minecraft:polished_andesite
fill 225 192 458 226 192 458 minecraft:shroomlight
fill 227 192 458 227 205 458 minecraft:polished_andesite
fill 230 192 417 230 205 417 minecraft:polished_andesite
fill 230 192 418 230 192 419 minecraft:shroomlight
fill 230 192 420 230 205 420 minecraft:polished_andesite
fill 230 192 429 230 205 429 minecraft:polished_andesite
fill 230 192 430 230 192 431 minecraft:shroomlight
fill 230 192 432 230 205 432 minecraft:polished_andesite
fill 230 192 441 230 205 441 minecraft:polished_andesite
fill 230 192 442 230 192 443 minecraft:shroomlight
fill 230 192 444 230 205 444 minecraft:polished_andesite
fill 230 192 453 230 205 453 minecraft:polished_andesite
fill 230 192 454 230 192 455 minecraft:shroomlight
fill 230 192 456 230 205 456 minecraft:polished_andesite
fill 188 193 423 188 205 424 minecraft:polished_andesite
fill 188 193 435 188 205 436 minecraft:polished_andesite
fill 188 193 447 188 205 448 minecraft:polished_andesite
fill 189 193 458 190 205 458 minecraft:polished_andesite
fill 190 193 434 190 213 434 minecraft:polished_deepslate
fill 196 193 416 197 205 416 minecraft:polished_andesite
fill 201 193 458 202 205 458 minecraft:polished_andesite
fill 208 193 416 209 205 416 minecraft:polished_andesite
fill 213 193 458 214 205 458 minecraft:polished_andesite
fill 220 193 416 221 205 416 minecraft:polished_andesite
fill 221 193 438 222 193 438 minecraft:orange_stained_glass
fill 225 193 458 226 205 458 minecraft:polished_andesite
fill 228 193 434 228 213 434 minecraft:polished_deepslate
fill 230 193 418 230 205 419 minecraft:polished_andesite
fill 230 193 430 230 205 431 minecraft:polished_andesite
fill 230 193 442 230 205 443 minecraft:polished_andesite
fill 230 193 454 230 205 455 minecraft:polished_andesite
fill 195 195 435 195 214 435 minecraft:polished_deepslate
fill 223 195 435 223 214 435 minecraft:polished_deepslate
fill 194 196 434 194 214 434 minecraft:polished_deepslate
fill 224 196 434 224 214 434 minecraft:polished_deepslate
fill 196 197 437 196 214 438 minecraft:polished_deepslate
fill 222 197 437 222 214 438 minecraft:polished_deepslate
setblock 191 198 419 minecraft:light[level=13]
setblock 191 198 427 minecraft:light[level=13]
setblock 191 198 443 minecraft:light[level=13]
setblock 191 198 451 minecraft:light[level=13]
setblock 199 198 419 minecraft:light[level=13]
setblock 199 198 427 minecraft:light[level=13]
setblock 199 198 435 minecraft:light[level=13]
setblock 199 198 443 minecraft:light[level=13]
setblock 199 198 451 minecraft:light[level=13]
setblock 207 198 419 minecraft:light[level=13]
setblock 207 198 427 minecraft:light[level=13]
setblock 207 198 443 minecraft:light[level=13]
setblock 207 198 451 minecraft:light[level=13]
setblock 215 198 419 minecraft:light[level=13]
setblock 215 198 427 minecraft:light[level=13]
setblock 215 198 435 minecraft:light[level=13]
setblock 215 198 443 minecraft:light[level=13]
setblock 215 198 451 minecraft:light[level=13]
setblock 223 198 419 minecraft:light[level=13]
setblock 223 198 427 minecraft:light[level=13]
setblock 223 198 443 minecraft:light[level=13]
setblock 223 198 451 minecraft:light[level=13]
fill 189 199 438 193 199 441 minecraft:polished_deepslate
fill 194 199 438 194 214 440 minecraft:polished_deepslate
fill 225 199 441 228 199 441 minecraft:polished_deepslate
fill 189 200 438 189 214 441 minecraft:polished_deepslate
fill 190 200 426 190 205 428 minecraft:polished_deepslate
fill 190 200 438 193 213 440 minecraft:polished_deepslate
fill 190 200 450 190 205 452 minecraft:polished_deepslate
fill 191 200 441 193 203 441 minecraft:polished_deepslate
fill 196 200 456 198 205 456 minecraft:polished_deepslate
fill 200 200 418 202 205 418 minecraft:polished_deepslate
fill 208 200 456 210 205 456 minecraft:polished_deepslate
fill 212 200 418 214 205 418 minecraft:polished_deepslate
fill 220 200 456 222 205 456 minecraft:polished_deepslate
fill 224 200 418 226 205 418 minecraft:polished_deepslate
fill 225 200 441 227 203 441 minecraft:polished_deepslate
fill 228 200 426 228 205 428 minecraft:polished_deepslate
fill 228 200 450 228 205 452 minecraft:polished_deepslate
fill 192 201 433 192 214 433 minecraft:polished_deepslate
fill 226 201 433 226 214 433 minecraft:polished_deepslate
fill 191 202 433 191 203 433 minecraft:polished_deepslate
fill 193 202 433 193 214 433 minecraft:polished_deepslate
fill 195 202 437 195 214 439 minecraft:polished_deepslate
fill 196 202 436 196 214 436 minecraft:polished_deepslate
fill 222 202 436 222 214 436 minecraft:polished_deepslate
fill 223 202 437 229 214 439 minecraft:polished_deepslate
fill 224 202 440 229 202 440 minecraft:polished_deepslate
fill 225 202 433 225 214 433 minecraft:polished_deepslate
fill 227 202 433 227 203 433 minecraft:polished_deepslate
fill 189 203 443 191 204 443 minecraft:iron_block
fill 224 203 440 228 213 440 minecraft:polished_deepslate
fill 192 204 441 194 214 441 minecraft:polished_deepslate
fill 194 204 433 194 214 433 minecraft:polished_deepslate
fill 195 204 434 195 214 434 minecraft:polished_deepslate
fill 195 204 440 195 214 440 minecraft:polished_deepslate
fill 196 204 435 196 214 435 minecraft:polished_deepslate
fill 196 204 439 196 214 439 minecraft:polished_deepslate
fill 197 204 436 197 214 438 minecraft:polished_deepslate
fill 221 204 436 221 214 438 minecraft:polished_deepslate
fill 222 204 435 222 214 435 minecraft:polished_deepslate
fill 222 204 439 222 214 439 minecraft:polished_deepslate
fill 223 204 434 223 214 434 minecraft:polished_deepslate
fill 223 204 440 223 214 440 minecraft:polished_deepslate
fill 224 204 433 224 214 433 minecraft:polished_deepslate
fill 224 204 441 226 214 441 minecraft:polished_deepslate
fill 189 205 420 189 205 425 minecraft:deepslate
fill 189 205 432 189 205 437 minecraft:deepslate
fill 189 205 444 189 205 449 minecraft:deepslate
fill 189 205 456 189 205 457 minecraft:deepslate
fill 190 205 433 191 213 433 minecraft:polished_deepslate
fill 190 205 441 191 213 441 minecraft:polished_deepslate
fill 190 205 457 193 205 457 minecraft:deepslate
fill 191 205 432 195 213 432 minecraft:polished_deepslate
fill 191 205 442 195 213 442 minecraft:polished_deepslate
fill 193 205 417 198 205 417 minecraft:deepslate
fill 195 205 433 196 213 433 minecraft:polished_deepslate
fill 195 205 441 196 213 441 minecraft:polished_deepslate
fill 196 205 434 197 213 434 minecraft:polished_deepslate
fill 196 205 440 197 213 440 minecraft:polished_deepslate
fill 197 205 435 198 213 435 minecraft:polished_deepslate
fill 197 205 439 198 213 439 minecraft:polished_deepslate
fill 198 205 436 198 213 438 minecraft:polished_deepslate
fill 200 205 457 205 205 457 minecraft:deepslate
fill 205 205 417 210 205 417 minecraft:deepslate
fill 212 205 457 217 205 457 minecraft:deepslate
fill 217 205 417 222 205 417 minecraft:deepslate
fill 220 205 435 220 213 439 minecraft:polished_deepslate
fill 221 205 434 221 213 435 minecraft:polished_deepslate
fill 221 205 439 221 213 440 minecraft:polished_deepslate
fill 222 205 433 222 213 434 minecraft:polished_deepslate
fill 222 205 440 222 213 441 minecraft:polished_deepslate
fill 223 205 432 223 213 433 minecraft:polished_deepslate
fill 223 205 441 223 213 442 minecraft:polished_deepslate
fill 224 205 432 227 213 432 minecraft:polished_deepslate
fill 224 205 442 227 213 442 minecraft:polished_deepslate
fill 224 205 457 229 205 457 minecraft:deepslate
fill 227 205 433 228 213 433 minecraft:polished_deepslate
fill 227 205 441 228 213 441 minecraft:polished_deepslate
fill 229 205 417 229 205 422 minecraft:deepslate
fill 229 205 429 229 205 434 minecraft:deepslate
fill 229 205 440 229 213 440 minecraft:polished_deepslate
fill 229 205 441 229 205 446 minecraft:deepslate
fill 229 205 453 229 205 456 minecraft:deepslate
fill 188 206 422 188 211 425 minecraft:shroomlight
fill 188 206 434 188 211 437 minecraft:shroomlight
fill 188 206 446 188 211 449 minecraft:shroomlight
fill 188 206 458 191 211 458 minecraft:shroomlight
fill 189 206 432 189 212 437 minecraft:polished_deepslate
fill 189 206 442 190 212 442 minecraft:polished_deepslate
fill 190 206 432 190 212 432 minecraft:polished_deepslate
setblock 191 206 419 minecraft:light[level=13]
setblock 191 206 427 minecraft:light[level=13]
fill 191 206 431 195 212 431 minecraft:polished_deepslate
fill 191 206 443 195 212 443 minecraft:polished_deepslate
setblock 191 206 451 minecraft:light[level=13]
fill 195 206 416 198 211 416 minecraft:shroomlight
fill 196 206 432 197 212 432 minecraft:polished_deepslate
fill 196 206 442 197 212 442 minecraft:polished_deepslate
fill 197 206 433 198 212 433 minecraft:polished_deepslate
fill 197 206 441 198 212 441 minecraft:polished_deepslate
fill 198 206 434 198 212 434 minecraft:polished_deepslate
fill 198 206 440 198 212 440 minecraft:polished_deepslate
setblock 199 206 419 minecraft:light[level=13]
setblock 199 206 427 minecraft:light[level=13]
fill 199 206 435 199 212 439 minecraft:polished_deepslate
setblock 199 206 443 minecraft:light[level=13]
setblock 199 206 451 minecraft:light[level=13]
fill 200 206 458 203 211 458 minecraft:shroomlight
fill 207 206 416 210 211 416 minecraft:shroomlight
setblock 207 206 419 minecraft:light[level=13]
setblock 207 206 427 minecraft:light[level=13]
setblock 207 206 443 minecraft:light[level=13]
setblock 207 206 451 minecraft:light[level=13]
fill 212 206 458 215 211 458 minecraft:shroomlight
setblock 215 206 419 minecraft:light[level=13]
setblock 215 206 427 minecraft:light[level=13]
setblock 215 206 435 minecraft:light[level=13]
setblock 215 206 443 minecraft:light[level=13]
setblock 215 206 451 minecraft:light[level=13]
fill 219 206 416 222 211 416 minecraft:shroomlight
fill 219 206 435 219 212 439 minecraft:polished_deepslate
fill 220 206 433 220 212 434 minecraft:polished_deepslate
fill 220 206 440 220 212 441 minecraft:polished_deepslate
fill 221 206 432 221 212 433 minecraft:polished_deepslate
fill 221 206 441 221 212 442 minecraft:polished_deepslate
fill 222 206 432 222 212 432 minecraft:polished_deepslate
fill 222 206 442 222 212 442 minecraft:polished_deepslate
setblock 223 206 419 minecraft:light[level=13]
setblock 223 206 427 minecraft:light[level=13]
fill 223 206 431 227 212 431 minecraft:polished_deepslate
fill 223 206 443 227 212 443 minecraft:polished_deepslate
setblock 223 206 451 minecraft:light[level=13]
fill 224 206 458 227 211 458 minecraft:shroomlight
fill 228 206 432 229 212 432 minecraft:polished_deepslate
fill 228 206 442 229 212 442 minecraft:polished_deepslate
fill 229 206 433 229 212 434 minecraft:polished_deepslate
fill 229 206 441 229 212 441 minecraft:polished_deepslate
fill 230 206 417 230 211 420 minecraft:shroomlight
fill 230 206 429 230 211 432 minecraft:shroomlight
fill 230 206 441 230 211 444 minecraft:shroomlight
fill 230 206 453 230 211 456 minecraft:shroomlight
fill 190 207 431 190 211 431 minecraft:polished_deepslate
fill 190 207 443 190 211 443 minecraft:polished_deepslate
fill 192 207 430 194 211 430 minecraft:polished_deepslate
fill 192 207 444 194 211 444 minecraft:polished_deepslate
fill 196 207 431 196 211 431 minecraft:polished_deepslate
fill 196 207 443 196 211 443 minecraft:polished_deepslate
fill 198 207 432 198 211 432 minecraft:polished_deepslate
fill 198 207 442 198 211 442 minecraft:polished_deepslate
fill 199 207 434 199 211 434 minecraft:polished_deepslate
fill 199 207 440 199 211 440 minecraft:polished_deepslate
fill 200 207 436 200 211 438 minecraft:polished_deepslate
fill 218 207 436 218 211 438 minecraft:polished_deepslate
fill 219 207 434 219 211 434 minecraft:polished_deepslate
fill 219 207 440 219 211 440 minecraft:polished_deepslate
fill 220 207 432 220 211 432 minecraft:polished_deepslate
fill 220 207 442 220 211 442 minecraft:polished_deepslate
fill 222 207 431 222 211 431 minecraft:polished_deepslate
fill 222 207 443 222 211 443 minecraft:polished_deepslate
fill 224 207 430 226 211 430 minecraft:polished_deepslate
fill 224 207 444 226 211 444 minecraft:polished_deepslate
fill 228 207 431 228 211 431 minecraft:polished_deepslate
fill 228 207 443 228 211 443 minecraft:polished_deepslate
fill 189 208 431 189 210 431 minecraft:polished_deepslate
fill 189 208 443 189 210 443 minecraft:polished_deepslate
fill 191 208 430 191 210 430 minecraft:polished_deepslate
fill 191 208 444 191 210 444 minecraft:polished_deepslate
fill 195 208 430 195 210 430 minecraft:polished_deepslate
fill 195 208 444 195 210 444 minecraft:polished_deepslate
fill 197 208 431 197 210 431 minecraft:polished_deepslate
fill 197 208 443 197 210 443 minecraft:polished_deepslate
fill 199 208 433 199 210 433 minecraft:polished_deepslate
fill 199 208 441 199 210 441 minecraft:polished_deepslate
fill 200 208 435 200 210 435 minecraft:polished_deepslate
fill 200 208 439 200 210 439 minecraft:polished_deepslate
fill 218 208 435 218 210 435 minecraft:polished_deepslate
fill 218 208 439 218 210 439 minecraft:polished_deepslate
fill 219 208 433 219 210 433 minecraft:polished_deepslate
fill 219 208 441 219 210 441 minecraft:polished_deepslate
fill 221 208 431 221 210 431 minecraft:polished_deepslate
fill 221 208 443 221 210 443 minecraft:polished_deepslate
fill 223 208 430 223 210 430 minecraft:polished_deepslate
fill 223 208 444 223 210 444 minecraft:polished_deepslate
fill 227 208 430 227 210 430 minecraft:polished_deepslate
fill 227 208 444 227 210 444 minecraft:polished_deepslate
fill 229 208 431 229 210 431 minecraft:polished_deepslate
fill 229 208 443 229 210 443 minecraft:polished_deepslate
fill 225 210 418 225 211 419 minecraft:iron_block
fill 189 211 431 189 212 431 minecraft:iron_block
fill 189 211 443 189 212 443 minecraft:iron_block
fill 190 211 430 191 211 430 minecraft:iron_block
fill 190 211 444 191 211 444 minecraft:iron_block
fill 195 211 430 196 211 430 minecraft:iron_block
fill 195 211 444 196 211 444 minecraft:iron_block
fill 197 211 431 197 212 431 minecraft:iron_block
fill 197 211 443 197 212 443 minecraft:iron_block
fill 199 211 433 199 212 433 minecraft:iron_block
fill 199 211 441 199 212 441 minecraft:iron_block
fill 200 211 434 200 211 435 minecraft:iron_block
fill 200 211 439 200 211 440 minecraft:iron_block
fill 218 211 434 218 211 435 minecraft:iron_block
fill 218 211 439 218 211 440 minecraft:iron_block
fill 219 211 433 219 212 433 minecraft:iron_block
fill 219 211 441 219 212 441 minecraft:iron_block
fill 221 211 431 221 212 431 minecraft:iron_block
fill 221 211 443 221 212 443 minecraft:iron_block
fill 222 211 430 223 211 430 minecraft:iron_block
fill 222 211 444 223 211 444 minecraft:iron_block
fill 227 211 430 228 211 430 minecraft:iron_block
fill 227 211 444 228 211 444 minecraft:iron_block
fill 229 211 431 229 212 431 minecraft:iron_block
fill 229 211 443 229 212 443 minecraft:iron_block
fill 188 212 422 188 219 422 minecraft:polished_andesite
fill 188 212 423 188 212 424 minecraft:shroomlight
fill 188 212 425 188 220 425 minecraft:polished_andesite
fill 188 212 434 188 215 434 minecraft:polished_andesite
fill 188 212 435 188 212 436 minecraft:shroomlight
fill 188 212 437 188 219 437 minecraft:polished_andesite
fill 188 212 446 188 219 446 minecraft:polished_andesite
fill 188 212 447 188 212 448 minecraft:shroomlight
fill 188 212 449 188 219 449 minecraft:polished_andesite
fill 188 212 458 188 215 458 minecraft:polished_andesite
fill 189 212 458 190 212 458 minecraft:shroomlight
fill 190 212 431 190 213 431 minecraft:iron_block
fill 190 212 443 190 213 443 minecraft:iron_block
fill 191 212 430 195 212 430 minecraft:iron_block
fill 191 212 444 195 212 444 minecraft:iron_block
fill 191 212 458 191 215 458 minecraft:polished_andesite
fill 195 212 416 195 219 416 minecraft:polished_andesite
fill 196 212 416 197 212 416 minecraft:shroomlight
fill 196 212 431 196 213 431 minecraft:iron_block
fill 196 212 443 196 213 443 minecraft:iron_block
fill 198 212 416 198 219 416 minecraft:polished_andesite
setblock 198 212 432 minecraft:iron_block
setblock 198 212 442 minecraft:iron_block
fill 199 212 434 199 213 434 minecraft:iron_block
fill 199 212 440 199 213 440 minecraft:iron_block
fill 200 212 435 200 212 439 minecraft:iron_block
fill 200 212 458 200 219 458 minecraft:polished_andesite
fill 201 212 458 202 212 458 minecraft:shroomlight
fill 203 212 458 203 219 458 minecraft:polished_andesite
fill 207 212 416 207 216 416 minecraft:polished_andesite
fill 208 212 416 209 212 416 minecraft:shroomlight
fill 210 212 416 210 219 416 minecraft:polished_andesite
fill 212 212 458 212 219 458 minecraft:polished_andesite
fill 213 212 458 214 212 458 minecraft:shroomlight
fill 215 212 458 215 219 458 minecraft:polished_andesite
fill 218 212 435 218 212 439 minecraft:iron_block
fill 219 212 416 219 220 416 minecraft:polished_andesite
fill 219 212 434 219 213 434 minecraft:iron_block
fill 219 212 440 219 213 440 minecraft:iron_block
fill 220 212 416 221 212 416 minecraft:shroomlight
setblock 220 212 432 minecraft:iron_block
setblock 220 212 442 minecraft:iron_block
fill 222 212 416 222 219 416 minecraft:polished_andesite
fill 222 212 431 222 213 431 minecraft:iron_block
fill 222 212 443 222 213 443 minecraft:iron_block
fill 223 212 430 227 212 430 minecraft:iron_block
fill 223 212 444 227 212 444 minecraft:iron_block
fill 224 212 458 224 219 458 minecraft:polished_andesite
fill 225 212 458 226 212 458 minecraft:shroomlight
fill 227 212 458 227 219 458 minecraft:polished_andesite
fill 228 212 431 228 213 431 minecraft:iron_block
fill 228 212 443 228 213 443 minecraft:iron_block
fill 230 212 417 230 215 417 minecraft:polished_andesite
fill 230 212 418 230 212 419 minecraft:shroomlight
fill 230 212 420 230 215 420 minecraft:polished_andesite
fill 230 212 429 230 219 429 minecraft:polished_andesite
fill 230 212 430 230 212 431 minecraft:shroomlight
fill 230 212 432 230 220 432 minecraft:polished_andesite
fill 230 212 441 230 219 441 minecraft:polished_andesite
fill 230 212 442 230 212 443 minecraft:shroomlight
fill 230 212 444 230 219 444 minecraft:polished_andesite
fill 230 212 453 230 216 453 minecraft:polished_andesite
fill 230 212 454 230 212 455 minecraft:shroomlight
fill 230 212 456 230 215 456 minecraft:polished_andesite
fill 188 213 423 188 215 424 minecraft:polished_andesite
fill 188 213 435 188 217 436 minecraft:polished_andesite
fill 188 213 447 188 219 448 minecraft:polished_andesite
fill 189 213 432 189 213 433 minecraft:iron_block
fill 189 213 434 189 213 437 minecraft:polished_deepslate
fill 189 213 442 190 213 442 minecraft:iron_block
fill 189 213 458 190 216 458 minecraft:polished_andesite
setblock 190 213 432 minecraft:iron_block
fill 191 213 431 195 213 431 minecraft:iron_block
fill 191 213 443 195 213 443 minecraft:iron_block
fill 196 213 416 197 217 416 minecraft:polished_andesite
fill 196 213 432 197 213 432 minecraft:iron_block
fill 196 213 442 197 213 442 minecraft:iron_block
fill 197 213 433 198 213 433 minecraft:iron_block
fill 197 213 441 198 213 441 minecraft:iron_block
setblock 198 213 434 minecraft:iron_block
setblock 198 213 440 minecraft:iron_block
fill 199 213 435 199 213 439 minecraft:iron_block
fill 201 213 458 202 219 458 minecraft:polished_andesite
fill 208 213 416 209 215 416 minecraft:polished_andesite
fill 213 213 458 214 219 458 minecraft:polished_andesite
fill 219 213 435 219 213 439 minecraft:iron_block
fill 220 213 416 221 219 416 minecraft:polished_andesite
fill 220 213 433 220 213 434 minecraft:iron_block
fill 220 213 440 220 213 441 minecraft:iron_block
fill 221 213 432 221 213 433 minecraft:iron_block
fill 221 213 441 221 213 442 minecraft:iron_block
setblock 222 213 432 minecraft:iron_block
setblock 222 213 442 minecraft:iron_block
fill 223 213 431 227 213 431 minecraft:iron_block
fill 223 213 443 227 213 443 minecraft:iron_block
fill 225 213 458 226 216 458 minecraft:polished_andesite
fill 228 213 432 229 213 432 minecraft:iron_block
fill 228 213 442 229 213 442 minecraft:iron_block
setblock 229 213 433 minecraft:iron_block
setblock 229 213 434 minecraft:polished_deepslate
setblock 229 213 441 minecraft:iron_block
fill 230 213 418 230 219 419 minecraft:polished_andesite
fill 230 213 430 230 216 431 minecraft:polished_andesite
fill 230 213 442 230 217 443 minecraft:polished_andesite
fill 230 213 454 230 215 455 minecraft:polished_andesite
fill 189 214 434 189 214 435 minecraft:iron_block
fill 189 214 436 189 214 437 minecraft:polished_deepslate
fill 190 214 433 190 214 434 minecraft:iron_block
fill 190 214 438 193 214 439 minecraft:polished_deepslate
fill 190 214 440 190 214 441 minecraft:iron_block
setblock 191 214 419 minecraft:light[level=13]
setblock 191 214 427 minecraft:light[level=13]
setblock 191 214 433 minecraft:iron_block
fill 191 214 440 193 214 440 minecraft:polished_deepslate
setblock 191 214 441 minecraft:iron_block
setblock 191 214 443 minecraft:light[level=13]
setblock 191 214 451 minecraft:light[level=13]
fill 192 214 432 194 214 432 minecraft:iron_block
fill 192 214 442 194 214 442 minecraft:iron_block
fill 195 214 433 196 214 433 minecraft:iron_block
fill 195 214 441 196 214 441 minecraft:iron_block
fill 196 214 434 197 214 434 minecraft:iron_block
fill 196 214 440 197 214 440 minecraft:iron_block
setblock 197 214 435 minecraft:iron_block
setblock 197 214 439 minecraft:iron_block
fill 198 214 436 198 214 438 minecraft:iron_block
setblock 199 214 419 minecraft:light[level=13]
setblock 199 214 427 minecraft:light[level=13]
setblock 199 214 435 minecraft:light[level=13]
setblock 199 214 443 minecraft:light[level=13]
setblock 199 214 451 minecraft:light[level=13]
setblock 207 214 419 minecraft:light[level=13]
setblock 207 214 427 minecraft:light[level=13]
setblock 207 214 443 minecraft:light[level=13]
setblock 207 214 451 minecraft:light[level=13]
setblock 215 214 419 minecraft:light[level=13]
setblock 215 214 427 minecraft:light[level=13]
setblock 215 214 435 minecraft:light[level=13]
setblock 215 214 443 minecraft:light[level=13]
setblock 215 214 451 minecraft:light[level=13]
fill 219 214 417 219 217 417 minecraft:orange_stained_glass
fill 220 214 436 220 214 438 minecraft:iron_block
fill 221 214 434 221 214 435 minecraft:iron_block
fill 221 214 439 221 214 440 minecraft:iron_block
fill 222 214 433 222 214 434 minecraft:iron_block
fill 222 214 440 222 214 441 minecraft:iron_block
setblock 223 214 419 minecraft:light[level=13]
setblock 223 214 427 minecraft:light[level=13]
setblock 223 214 433 minecraft:iron_block
setblock 223 214 441 minecraft:iron_block
setblock 223 214 443 minecraft:light[level=13]
setblock 223 214 451 minecraft:light[level=13]
fill 224 214 432 226 214 432 minecraft:iron_block
fill 224 214 440 227 214 440 minecraft:polished_deepslate
fill 224 214 442 226 214 442 minecraft:iron_block
fill 227 214 433 228 214 433 minecraft:iron_block
fill 227 214 441 228 214 441 minecraft:iron_block
fill 228 214 434 229 214 434 minecraft:iron_block
fill 228 214 440 229 214 440 minecraft:iron_block
setblock 229 214 435 minecraft:iron_block
fill 189 215 439 189 226 441 minecraft:polished_deepslate
fill 189 215 442 190 218 444 minecraft:orange_stained_glass
fill 190 215 435 190 221 435 minecraft:iron_block
fill 191 215 443 191 218 443 minecraft:orange_stained_glass
setblock 193 215 437 minecraft:polished_deepslate
fill 218 215 417 218 216 419 minecraft:orange_stained_glass
fill 219 215 418 219 216 422 minecraft:orange_stained_glass
fill 220 215 417 220 216 419 minecraft:orange_stained_glass
setblock 225 215 437 minecraft:polished_deepslate
fill 229 215 437 229 226 439 minecraft:polished_deepslate
fill 188 216 423 188 219 423 minecraft:polished_andesite
setblock 188 216 424 minecraft:stone
fill 188 216 426 188 219 426 minecraft:polished_andesite
setblock 188 216 427 minecraft:stone
fill 188 216 428 188 219 429 minecraft:polished_andesite
setblock 188 216 434 minecraft:stone
fill 188 216 442 188 220 442 minecraft:polished_andesite
setblock 188 216 443 minecraft:stone
setblock 188 216 458 minecraft:stone
fill 189 216 445 190 217 445 minecraft:orange_stained_glass
fill 190 216 441 190 217 441 minecraft:orange_stained_glass
fill 191 216 442 193 217 442 minecraft:orange_stained_glass
fill 191 216 444 193 217 444 minecraft:orange_stained_glass
setblock 191 216 458 minecraft:stone
fill 192 216 443 194 217 443 minecraft:orange_stained_glass
setblock 208 216 416 minecraft:polished_andesite
setblock 209 216 416 minecraft:stone
setblock 218 216 420 minecraft:orange_stained_glass
setblock 219 216 423 minecraft:orange_stained_glass
setblock 220 216 420 minecraft:orange_stained_glass
setblock 223 216 416 minecraft:stone
fill 224 216 416 224 219 416 minecraft:polished_andesite
fill 230 216 416 230 216 417 minecraft:stone
fill 230 216 420 230 218 420 minecraft:stone
fill 230 216 421 230 219 427 minecraft:polished_andesite
setblock 230 216 428 minecraft:stone
setblock 230 216 433 minecraft:stone
fill 230 216 434 230 217 435 minecraft:polished_andesite
fill 230 216 436 230 216 438 minecraft:stone
fill 230 216 439 230 219 440 minecraft:polished_andesite
fill 230 216 445 230 216 447 minecraft:stone
setblock 230 216 449 minecraft:stone
fill 230 216 450 230 219 451 minecraft:polished_andesite
fill 230 216 454 230 219 454 minecraft:polished_andesite
fill 230 216 455 230 216 457 minecraft:stone
setblock 188 217 420 minecraft:polished_andesite
setblock 188 217 421 minecraft:stone
fill 188 217 424 188 219 424 minecraft:polished_andesite
fill 188 217 427 188 219 427 minecraft:polished_andesite
setblock 188 217 431 minecraft:stone
fill 188 217 432 188 219 434 minecraft:polished_andesite
setblock 188 217 439 minecraft:stone
fill 188 217 440 188 219 441 minecraft:polished_andesite
setblock 188 217 443 minecraft:polished_andesite
setblock 188 217 458 minecraft:polished_andesite
setblock 189 217 458 minecraft:stone
fill 190 217 458 191 217 458 minecraft:polished_andesite
fill 192 217 416 192 219 416 minecraft:polished_andesite
setblock 193 217 416 minecraft:stone
setblock 195 217 443 minecraft:orange_stained_glass
fill 199 217 416 199 219 416 minecraft:polished_andesite
setblock 199 217 458 minecraft:stone
setblock 200 217 416 minecraft:stone
fill 207 217 416 208 217 416 minecraft:stone
fill 209 217 416 209 219 416 minecraft:polished_andesite
fill 223 217 416 223 219 416 minecraft:polished_andesite
fill 225 217 458 225 219 458 minecraft:polished_andesite
setblock 226 217 458 minecraft:stone
fill 230 217 416 230 219 417 minecraft:polished_andesite
fill 230 217 428 230 220 428 minecraft:polished_andesite
fill 230 217 430 230 218 430 minecraft:stone
fill 230 217 431 230 219 431 minecraft:polished_andesite
fill 230 217 433 230 219 433 minecraft:polished_andesite
fill 230 217 436 230 217 438 minecraft:polished_andesite
fill 230 217 445 230 219 447 minecraft:polished_andesite
fill 230 217 449 230 219 449 minecraft:polished_andesite
setblock 230 217 453 minecraft:stone
fill 230 217 455 230 219 457 minecraft:polished_andesite
fill 188 218 419 188 218 420 minecraft:stone
fill 188 218 421 188 219 421 minecraft:polished_andesite
fill 188 218 431 188 219 431 minecraft:polished_andesite
setblock 188 218 435 minecraft:stone
fill 188 218 436 188 219 436 minecraft:polished_andesite
fill 188 218 439 188 219 439 minecraft:polished_andesite
setblock 188 218 443 minecraft:stone
setblock 188 218 451 minecraft:stone
fill 188 218 452 188 219 453 minecraft:polished_andesite
setblock 188 218 458 minecraft:stone
fill 189 218 458 189 220 458 minecraft:polished_andesite
setblock 190 218 458 minecraft:stone
setblock 191 218 442 minecraft:orange_stained_glass
setblock 191 218 444 minecraft:orange_stained_glass
fill 191 218 458 193 219 458 minecraft:polished_andesite
setblock 192 218 443 minecraft:orange_stained_glass
fill 193 218 416 193 219 416 minecraft:polished_andesite
setblock 194 218 458 minecraft:stone
fill 195 218 458 197 219 458 minecraft:polished_andesite
fill 196 218 416 196 219 416 minecraft:polished_andesite
setblock 197 218 416 minecraft:stone
fill 199 218 458 199 220 458 minecraft:polished_andesite
fill 200 218 416 200 219 416 minecraft:polished_andesite
fill 203 218 416 205 219 416 minecraft:polished_andesite
setblock 204 218 458 minecraft:stone
fill 205 218 458 205 219 458 minecraft:polished_andesite
setblock 206 218 416 minecraft:stone
setblock 206 218 458 minecraft:stone
fill 207 218 416 208 219 416 minecraft:polished_andesite
fill 207 218 458 209 219 458 minecraft:polished_andesite
setblock 210 218 458 minecraft:stone
fill 211 218 416 211 220 416 minecraft:polished_andesite
setblock 212 218 416 minecraft:stone
fill 213 218 416 213 219 416 minecraft:polished_andesite
fill 225 218 416 225 219 416 minecraft:polished_andesite
setblock 226 218 416 minecraft:stone
fill 226 218 458 226 219 458 minecraft:polished_andesite
fill 230 218 434 230 220 434 minecraft:polished_andesite
fill 230 218 435 230 218 436 minecraft:stone
fill 230 218 437 230 219 438 minecraft:polished_andesite
setblock 230 218 442 minecraft:stone
fill 230 218 443 230 219 443 minecraft:polished_andesite
setblock 230 218 452 minecraft:stone
fill 230 218 453 230 219 453 minecraft:polished_andesite
fill 188 219 419 188 219 420 minecraft:polished_andesite
setblock 188 219 435 minecraft:polished_andesite
setblock 188 219 443 minecraft:polished_andesite
setblock 188 219 451 minecraft:polished_andesite
setblock 188 219 458 minecraft:polished_andesite
setblock 190 219 458 minecraft:polished_andesite
setblock 194 219 458 minecraft:polished_andesite
setblock 197 219 416 minecraft:polished_andesite
setblock 204 219 458 minecraft:polished_andesite
setblock 206 219 416 minecraft:polished_andesite
fill 206 219 458 206 220 458 minecraft:polished_andesite
setblock 210 219 458 minecraft:polished_andesite
setblock 212 219 416 minecraft:polished_andesite
setblock 226 219 416 minecraft:polished_andesite
setblock 230 219 420 minecraft:polished_andesite
setblock 230 219 430 minecraft:polished_andesite
fill 230 219 435 230 219 436 minecraft:polished_andesite
setblock 230 219 442 minecraft:polished_andesite
setblock 230 219 452 minecraft:polished_andesite
fill 188 220 417 188 225 424 minecraft:stone
fill 188 220 426 188 307 433 minecraft:stone
setblock 188 220 434 minecraft:polished_andesite
fill 188 220 435 188 220 441 minecraft:stone
fill 188 220 443 188 221 452 minecraft:stone
setblock 188 220 453 minecraft:polished_andesite
fill 188 220 454 188 225 458 minecraft:stone
fill 189 220 416 190 221 416 minecraft:stone
fill 190 220 426 190 225 428 minecraft:polished_deepslate
fill 190 220 438 190 225 440 minecraft:polished_deepslate
fill 190 220 450 190 225 452 minecraft:polished_deepslate
fill 190 220 458 195 225 458 minecraft:stone
fill 192 220 416 193 307 416 minecraft:stone
fill 195 220 416 210 220 416 minecraft:stone
fill 196 220 456 198 225 456 minecraft:polished_deepslate
fill 196 220 458 197 220 458 minecraft:polished_andesite
fill 200 220 418 202 225 418 minecraft:polished_deepslate
fill 200 220 458 205 225 458 minecraft:stone
fill 207 220 458 207 307 458 minecraft:stone
fill 208 220 456 210 225 456 minecraft:polished_deepslate
setblock 208 220 458 minecraft:polished_andesite
fill 209 220 458 228 220 458 minecraft:stone
fill 212 220 416 213 307 416 minecraft:stone
fill 212 220 418 214 225 418 minecraft:polished_deepslate
fill 215 220 416 218 221 416 minecraft:stone
fill 220 220 416 230 220 416 minecraft:stone
fill 220 220 456 222 225 456 minecraft:polished_deepslate
fill 224 220 418 226 225 418 minecraft:polished_deepslate
fill 228 220 426 228 225 428 minecraft:polished_deepslate
fill 228 220 438 228 225 440 minecraft:polished_deepslate
fill 228 220 450 228 225 452 minecraft:polished_deepslate
fill 230 220 417 230 220 427 minecraft:stone
fill 230 220 429 230 220 431 minecraft:stone
fill 230 220 433 230 307 433 minecraft:stone
fill 230 220 435 230 220 450 minecraft:stone
setblock 230 220 451 minecraft:polished_andesite
fill 230 220 452 230 220 458 minecraft:stone
fill 188 221 416 188 307 416 minecraft:stone
fill 188 221 425 188 225 425 minecraft:stone
fill 188 221 434 188 221 440 minecraft:stone
setblock 188 221 441 minecraft:polished_andesite
fill 188 221 442 188 307 442 minecraft:stone
fill 188 221 453 188 307 453 minecraft:stone
fill 189 221 458 189 225 458 minecraft:stone
fill 191 221 416 191 307 416 minecraft:stone
fill 194 221 416 195 225 416 minecraft:stone
fill 196 221 416 196 222 416 minecraft:polished_andesite
fill 196 221 458 196 307 458 minecraft:stone
fill 197 221 416 197 225 416 minecraft:stone
setblock 197 221 458 minecraft:polished_andesite
setblock 198 221 416 minecraft:polished_andesite
fill 198 221 458 199 307 458 minecraft:stone
fill 199 221 416 204 307 416 minecraft:stone
setblock 205 221 416 minecraft:polished_andesite
fill 206 221 416 211 221 416 minecraft:stone
fill 206 221 458 206 307 458 minecraft:stone
fill 208 221 458 209 307 458 minecraft:stone
setblock 210 221 458 minecraft:polished_andesite
fill 211 221 458 221 221 458 minecraft:stone
fill 214 221 416 214 307 416 minecraft:stone
fill 219 221 416 220 225 416 minecraft:stone
setblock 221 221 416 minecraft:polished_andesite
fill 222 221 416 223 225 416 minecraft:stone
setblock 222 221 458 minecraft:polished_andesite
fill 223 221 458 229 221 458 minecraft:stone
setblock 224 221 416 minecraft:polished_andesite
fill 225 221 416 230 221 416 minecraft:stone
fill 230 221 417 230 225 419 minecraft:stone
fill 230 221 420 230 221 421 minecraft:polished_andesite
fill 230 221 422 230 307 423 minecraft:stone
fill 230 221 424 230 222 424 minecraft:polished_andesite
fill 230 221 425 230 307 426 minecraft:stone
setblock 230 221 427 minecraft:polished_andesite
fill 230 221 428 230 225 429 minecraft:stone
setblock 230 221 430 minecraft:polished_andesite
fill 230 221 431 230 225 432 minecraft:stone
fill 230 221 434 230 307 434 minecraft:stone
fill 230 221 435 230 221 436 minecraft:polished_andesite
fill 230 221 437 230 307 439 minecraft:stone
setblock 230 221 440 minecraft:polished_andesite
fill 230 221 441 230 221 449 minecraft:stone
setblock 230 221 450 minecraft:polished_andesite
fill 230 221 451 230 307 452 minecraft:stone
fill 230 221 453 230 221 454 minecraft:polished_andesite
fill 230 221 455 230 225 457 minecraft:stone
setblock 230 221 458 minecraft:polished_andesite
fill 188 222 434 188 225 435 minecraft:stone
setblock 188 222 436 minecraft:polished_andesite
fill 188 222 437 188 225 441 minecraft:stone
fill 188 222 443 188 225 450 minecraft:stone
setblock 188 222 451 minecraft:polished_andesite
fill 188 222 452 188 307 452 minecraft:stone
fill 189 222 416 189 307 416 minecraft:stone
setblock 190 222 416 minecraft:polished_andesite
setblock 191 222 419 minecraft:light[level=13]
setblock 191 222 427 minecraft:light[level=13]
setblock 191 222 435 minecraft:light[level=13]
setblock 191 222 443 minecraft:light[level=13]
setblock 191 222 451 minecraft:light[level=13]
fill 197 222 458 197 307 458 minecraft:stone
fill 198 222 416 198 225 416 minecraft:stone
setblock 199 222 419 minecraft:light[level=13]
setblock 199 222 427 minecraft:light[level=13]
setblock 199 222 435 minecraft:light[level=13]
setblock 199 222 443 minecraft:light[level=13]
setblock 199 222 451 minecraft:light[level=13]
fill 205 222 416 210 225 416 minecraft:stone
setblock 207 222 419 minecraft:light[level=13]
setblock 207 222 427 minecraft:light[level=13]
setblock 207 222 435 minecraft:light[level=13]
setblock 207 222 443 minecraft:light[level=13]
setblock 207 222 451 minecraft:light[level=13]
fill 210 222 458 210 307 458 minecraft:stone
setblock 211 222 416 minecraft:polished_andesite
setblock 211 222 458 minecraft:polished_andesite
fill 212 222 458 226 225 458 minecraft:stone
fill 215 222 416 216 307 416 minecraft:stone
setblock 215 222 419 minecraft:light[level=13]
setblock 215 222 427 minecraft:light[level=13]
setblock 215 222 435 minecraft:light[level=13]
setblock 215 222 443 minecraft:light[level=13]
setblock 215 222 451 minecraft:light[level=13]
setblock 217 222 416 minecraft:polished_andesite
fill 218 222 416 218 307 416 minecraft:stone
fill 221 222 416 221 225 416 minecraft:stone
setblock 223 222 419 minecraft:light[level=13]
setblock 223 222 427 minecraft:light[level=13]
setblock 223 222 435 minecraft:light[level=13]
setblock 223 222 443 minecraft:light[level=13]
setblock 223 222 451 minecraft:light[level=13]
fill 224 222 416 224 307 416 minecraft:stone
setblock 225 222 416 minecraft:polished_andesite
fill 226 222 416 229 307 416 minecraft:stone
setblock 227 222 458 minecraft:polished_andesite
fill 228 222 458 230 307 458 minecraft:stone
setblock 230 222 416 minecraft:polished_andesite
fill 230 222 420 230 225 421 minecraft:stone
fill 230 222 427 230 307 427 minecraft:stone
fill 230 222 430 230 225 430 minecraft:stone
fill 230 222 435 230 307 436 minecraft:stone
fill 230 222 440 230 307 440 minecraft:stone
setblock 230 222 441 minecraft:polished_andesite
fill 230 222 442 230 225 446 minecraft:stone
setblock 230 222 447 minecraft:polished_andesite
fill 230 222 448 230 307 450 minecraft:stone
fill 230 222 453 230 225 454 minecraft:stone
fill 188 223 436 188 225 436 minecraft:stone
fill 188 223 451 188 307 451 minecraft:stone
fill 190 223 416 190 307 416 minecraft:stone
fill 196 223 416 196 225 416 minecraft:stone
fill 211 223 416 211 307 416 minecraft:stone
fill 211 223 458 211 307 458 minecraft:stone
fill 217 223 416 217 307 416 minecraft:stone
fill 225 223 416 225 307 416 minecraft:stone
fill 227 223 458 227 225 458 minecraft:stone
fill 230 223 416 230 307 416 minecraft:stone
fill 230 223 424 230 307 424 minecraft:stone
fill 230 223 441 230 225 441 minecraft:stone
fill 230 223 447 230 307 447 minecraft:stone
fill 189 225 420 189 225 425 minecraft:deepslate
fill 189 225 432 189 225 437 minecraft:deepslate
fill 189 225 444 189 225 449 minecraft:deepslate
fill 189 225 456 189 225 457 minecraft:deepslate
fill 190 225 457 193 225 457 minecraft:deepslate
fill 193 225 417 198 225 417 minecraft:deepslate
fill 200 225 457 205 225 457 minecraft:deepslate
fill 205 225 417 210 225 417 minecraft:deepslate
fill 212 225 457 217 225 457 minecraft:deepslate
fill 217 225 417 222 225 417 minecraft:deepslate
fill 224 225 457 229 225 457 minecraft:deepslate
fill 229 225 417 229 225 422 minecraft:deepslate
fill 229 225 429 229 225 434 minecraft:deepslate
fill 229 225 441 229 225 446 minecraft:deepslate
fill 229 225 453 229 225 456 minecraft:deepslate
fill 188 226 417 188 307 421 minecraft:stone
fill 188 226 422 188 226 425 minecraft:shroomlight
fill 188 226 434 188 226 437 minecraft:shroomlight
fill 188 226 438 188 307 441 minecraft:stone
fill 188 226 443 188 307 445 minecraft:stone
fill 188 226 446 188 226 449 minecraft:shroomlight
fill 188 226 450 188 307 450 minecraft:stone
fill 188 226 454 188 307 457 minecraft:stone
fill 188 226 458 191 226 458 minecraft:shroomlight
fill 192 226 458 195 307 458 minecraft:stone
fill 194 226 416 194 307 416 minecraft:stone
fill 195 226 416 198 226 416 minecraft:shroomlight
fill 200 226 458 203 226 458 minecraft:shroomlight
fill 204 226 458 205 307 458 minecraft:stone
fill 205 226 416 206 307 416 minecraft:stone
fill 207 226 416 210 226 416 minecraft:shroomlight
fill 212 226 458 215 226 458 minecraft:shroomlight
fill 216 226 458 223 307 458 minecraft:stone
fill 219 226 416 222 226 416 minecraft:shroomlight
fill 223 226 416 223 307 416 minecraft:stone
fill 224 226 458 227 226 458 minecraft:shroomlight
fill 230 226 417 230 226 420 minecraft:shroomlight
fill 230 226 421 230 307 421 minecraft:stone
fill 230 226 428 230 307 428 minecraft:stone
fill 230 226 429 230 226 432 minecraft:shroomlight
fill 230 226 441 230 226 444 minecraft:shroomlight
fill 230 226 445 230 307 446 minecraft:stone
fill 230 226 453 230 226 456 minecraft:shroomlight
fill 230 226 457 230 307 457 minecraft:stone
fill 188 227 422 188 245 425 minecraft:stone
fill 188 227 434 188 245 437 minecraft:stone
fill 188 227 446 188 245 449 minecraft:stone
fill 188 227 458 191 245 458 minecraft:stone
fill 195 227 416 198 245 416 minecraft:stone
fill 200 227 458 203 245 458 minecraft:stone
fill 207 227 416 210 245 416 minecraft:stone
fill 212 227 458 215 245 458 minecraft:stone
fill 219 227 416 222 245 416 minecraft:stone
fill 224 227 458 227 245 458 minecraft:stone
fill 230 227 417 230 245 420 minecraft:stone
fill 230 227 429 230 245 432 minecraft:stone
fill 230 227 441 230 245 444 minecraft:stone
fill 230 227 453 230 245 456 minecraft:stone
setblock 191 230 419 minecraft:light[level=13]
setblock 191 230 427 minecraft:light[level=13]
setblock 191 230 435 minecraft:light[level=13]
setblock 191 230 443 minecraft:light[level=13]
setblock 191 230 451 minecraft:light[level=13]
setblock 199 230 419 minecraft:light[level=13]
setblock 199 230 427 minecraft:light[level=13]
setblock 199 230 435 minecraft:light[level=13]
setblock 199 230 443 minecraft:light[level=13]
setblock 199 230 451 minecraft:light[level=13]
setblock 207 230 419 minecraft:light[level=13]
setblock 207 230 427 minecraft:light[level=13]
setblock 207 230 435 minecraft:light[level=13]
setblock 207 230 443 minecraft:light[level=13]
setblock 207 230 451 minecraft:light[level=13]
setblock 215 230 419 minecraft:light[level=13]
setblock 215 230 427 minecraft:light[level=13]
setblock 215 230 435 minecraft:light[level=13]
setblock 215 230 443 minecraft:light[level=13]
setblock 215 230 451 minecraft:light[level=13]
setblock 223 230 419 minecraft:light[level=13]
setblock 223 230 427 minecraft:light[level=13]
setblock 223 230 435 minecraft:light[level=13]
setblock 223 230 443 minecraft:light[level=13]
setblock 223 230 451 minecraft:light[level=13]
fill 194 232 436 205 232 436 minecraft:polished_deepslate
fill 195 232 432 195 233 433 minecraft:polished_deepslate
fill 195 232 435 205 232 435 minecraft:polished_deepslate
fill 195 232 438 206 232 438 minecraft:polished_deepslate
fill 195 232 441 196 233 441 minecraft:polished_deepslate
fill 196 232 430 218 232 430 minecraft:polished_deepslate
fill 196 232 433 219 232 433 minecraft:polished_deepslate
fill 196 232 440 219 232 440 minecraft:polished_deepslate
fill 196 232 443 217 232 443 minecraft:polished_deepslate
fill 197 232 428 216 232 428 minecraft:polished_deepslate
fill 197 232 431 218 232 432 minecraft:polished_deepslate
fill 197 232 434 206 232 434 minecraft:polished_deepslate
fill 197 232 437 205 232 437 minecraft:polished_deepslate
fill 197 232 439 221 232 439 minecraft:polished_deepslate
fill 198 232 427 198 233 427 minecraft:polished_deepslate
fill 198 232 441 219 232 442 minecraft:polished_deepslate
fill 199 232 426 200 233 426 minecraft:polished_deepslate
fill 199 232 429 220 232 429 minecraft:polished_deepslate
fill 199 232 445 199 233 445 minecraft:polished_deepslate
fill 200 232 425 200 233 425 minecraft:polished_deepslate
fill 200 232 427 215 232 427 minecraft:polished_deepslate
fill 200 232 444 219 232 444 minecraft:polished_deepslate
fill 201 232 445 201 233 448 minecraft:polished_deepslate
fill 202 232 424 202 233 426 minecraft:polished_deepslate
fill 202 232 445 214 233 446 minecraft:polished_deepslate
fill 203 232 425 212 233 426 minecraft:polished_deepslate
fill 203 232 448 203 233 449 minecraft:polished_deepslate
fill 204 232 423 205 233 423 minecraft:polished_deepslate
fill 204 232 447 204 233 448 minecraft:polished_deepslate
fill 205 232 424 205 233 424 minecraft:polished_deepslate
fill 205 232 447 214 233 447 minecraft:polished_deepslate
fill 206 232 448 206 233 449 minecraft:polished_deepslate
fill 207 232 423 207 233 424 minecraft:polished_deepslate
fill 208 232 424 208 233 424 minecraft:polished_deepslate
fill 208 232 448 209 233 448 minecraft:polished_deepslate
fill 209 232 449 209 233 449 minecraft:polished_deepslate
fill 210 232 423 210 233 424 minecraft:polished_deepslate
fill 210 232 434 221 232 434 minecraft:polished_deepslate
fill 210 232 438 219 232 438 minecraft:polished_deepslate
fill 211 232 435 219 232 437 minecraft:polished_deepslate
fill 211 232 448 211 233 449 minecraft:polished_deepslate
fill 212 232 424 213 233 424 minecraft:polished_deepslate
fill 212 232 449 212 233 449 minecraft:polished_deepslate
fill 213 232 423 213 233 423 minecraft:polished_deepslate
fill 213 232 426 215 233 426 minecraft:polished_deepslate
fill 214 232 448 214 233 448 minecraft:polished_deepslate
fill 215 232 424 215 233 425 minecraft:polished_deepslate
fill 215 232 445 216 233 445 minecraft:polished_deepslate
fill 216 232 446 216 233 447 minecraft:polished_deepslate
fill 217 232 427 217 233 427 minecraft:polished_deepslate
fill 217 232 446 217 233 446 minecraft:polished_deepslate
fill 218 232 445 218 233 445 minecraft:polished_deepslate
fill 219 232 432 220 233 432 minecraft:polished_deepslate
fill 220 232 431 221 233 431 minecraft:polished_deepslate
fill 220 232 436 221 233 437 minecraft:polished_deepslate
fill 220 232 442 220 233 442 minecraft:polished_deepslate
fill 221 232 440 221 233 440 minecraft:polished_deepslate
fill 222 232 436 222 233 436 minecraft:polished_deepslate
fill 189 233 417 193 233 457 minecraft:deepslate
fill 194 233 417 194 233 435 minecraft:deepslate
fill 194 233 436 204 233 436 minecraft:polished_deepslate
fill 194 233 437 194 233 457 minecraft:deepslate
fill 195 233 417 195 233 431 minecraft:deepslate
fill 195 233 434 196 233 434 minecraft:deepslate
fill 195 233 435 204 233 435 minecraft:polished_deepslate
fill 195 233 437 196 233 437 minecraft:deepslate
fill 195 233 438 198 233 438 minecraft:polished_deepslate
fill 195 233 439 195 233 440 minecraft:deepslate
fill 195 233 442 195 233 457 minecraft:deepslate
fill 196 233 417 196 233 429 minecraft:deepslate
fill 196 233 430 204 233 430 minecraft:polished_deepslate
fill 196 233 431 196 233 432 minecraft:deepslate
fill 196 233 433 205 233 433 minecraft:polished_deepslate
setblock 196 233 439 minecraft:deepslate
fill 196 233 440 199 233 440 minecraft:polished_deepslate
fill 196 233 442 197 233 442 minecraft:deepslate
fill 196 233 443 201 233 443 minecraft:polished_deepslate
fill 196 233 444 198 233 457 minecraft:deepslate
fill 197 233 417 197 233 427 minecraft:deepslate
fill 197 233 428 203 233 428 minecraft:polished_deepslate
fill 197 233 429 198 233 429 minecraft:deepslate
fill 197 233 431 205 233 432 minecraft:polished_deepslate
fill 197 233 434 204 233 434 minecraft:polished_deepslate
fill 197 233 437 198 233 437 minecraft:polished_deepslate
fill 197 233 439 198 233 439 minecraft:polished_deepslate
setblock 197 233 441 minecraft:deepslate
fill 198 233 417 198 233 426 minecraft:deepslate
fill 198 233 441 199 233 442 minecraft:polished_deepslate
fill 199 233 417 199 233 425 minecraft:deepslate
setblock 199 233 427 minecraft:deepslate
fill 199 233 429 203 233 429 minecraft:polished_deepslate
fill 199 233 437 204 233 439 minecraft:gold_block
setblock 199 233 444 minecraft:deepslate
fill 199 233 446 200 233 457 minecraft:deepslate
fill 200 233 417 201 233 424 minecraft:deepslate
fill 200 233 427 204 233 427 minecraft:polished_deepslate
fill 200 233 440 205 233 441 minecraft:gold_block
setblock 200 233 442 minecraft:polished_deepslate
fill 200 233 444 202 233 444 minecraft:polished_deepslate
setblock 200 233 445 minecraft:deepslate
fill 201 233 425 201 233 426 minecraft:deepslate
fill 201 233 442 204 233 442 minecraft:gold_block
fill 201 233 449 202 233 457 minecraft:deepslate
fill 202 233 417 203 233 423 minecraft:deepslate
fill 202 233 443 203 233 443 minecraft:gold_block
fill 202 233 447 202 233 448 minecraft:deepslate
fill 203 233 424 204 233 424 minecraft:deepslate
setblock 203 233 444 minecraft:gold_block
setblock 203 233 447 minecraft:deepslate
fill 203 233 450 229 233 457 minecraft:deepslate
fill 204 233 417 229 233 422 minecraft:deepslate
fill 204 233 428 212 233 429 minecraft:gold_block
fill 204 233 443 212 233 444 minecraft:polished_deepslate
fill 204 233 449 205 233 449 minecraft:deepslate
fill 205 233 427 211 233 427 minecraft:gold_block
fill 205 233 430 211 233 430 minecraft:gold_block
setblock 205 233 434 minecraft:shroomlight
fill 205 233 435 205 233 437 minecraft:ochre_froglight
setblock 205 233 438 minecraft:shroomlight
setblock 205 233 439 minecraft:gold_block
fill 205 233 442 211 233 442 minecraft:polished_deepslate
setblock 205 233 448 minecraft:deepslate
fill 206 233 423 206 233 424 minecraft:deepslate
fill 206 233 431 210 233 432 minecraft:gold_block
setblock 206 233 433 minecraft:shroomlight
setblock 206 233 434 minecraft:ochre_froglight
setblock 206 233 438 minecraft:ochre_froglight
setblock 206 233 439 minecraft:shroomlight
fill 206 233 440 210 233 441 minecraft:polished_deepslate
fill 207 233 433 209 233 433 minecraft:ochre_froglight
fill 207 233 439 209 233 439 minecraft:ochre_froglight
fill 207 233 448 207 233 449 minecraft:deepslate
fill 208 233 423 209 233 423 minecraft:deepslate
setblock 208 233 449 minecraft:deepslate
setblock 209 233 424 minecraft:deepslate
setblock 210 233 433 minecraft:shroomlight
setblock 210 233 434 minecraft:ochre_froglight
setblock 210 233 438 minecraft:ochre_froglight
setblock 210 233 439 minecraft:shroomlight
fill 210 233 448 210 233 449 minecraft:deepslate
fill 211 233 423 211 233 424 minecraft:deepslate
fill 211 233 431 218 233 433 minecraft:polished_deepslate
setblock 211 233 434 minecraft:shroomlight
fill 211 233 435 211 233 437 minecraft:ochre_froglight
setblock 211 233 438 minecraft:shroomlight
fill 211 233 439 216 233 441 minecraft:gold_block
setblock 212 233 423 minecraft:deepslate
fill 212 233 427 215 233 427 minecraft:polished_deepslate
fill 212 233 430 218 233 430 minecraft:polished_deepslate
fill 212 233 434 219 233 435 minecraft:polished_deepslate
fill 212 233 436 217 233 438 minecraft:gold_block
fill 212 233 442 215 233 442 minecraft:gold_block
fill 212 233 448 213 233 448 minecraft:deepslate
fill 213 233 425 214 233 425 minecraft:deepslate
fill 213 233 428 216 233 429 minecraft:polished_deepslate
fill 213 233 443 213 233 444 minecraft:gold_block
fill 213 233 449 229 233 449 minecraft:deepslate
fill 214 233 423 214 233 424 minecraft:deepslate
setblock 214 233 443 minecraft:gold_block
fill 214 233 444 219 233 444 minecraft:polished_deepslate
fill 215 233 423 229 233 423 minecraft:deepslate
fill 215 233 443 217 233 443 minecraft:polished_deepslate
fill 215 233 446 215 233 448 minecraft:deepslate
fill 216 233 424 216 233 427 minecraft:deepslate
fill 216 233 442 219 233 442 minecraft:polished_deepslate
fill 216 233 448 229 233 448 minecraft:deepslate
fill 217 233 424 229 233 426 minecraft:deepslate
fill 217 233 428 229 233 428 minecraft:deepslate
fill 217 233 429 220 233 429 minecraft:polished_deepslate
setblock 217 233 439 minecraft:gold_block
fill 217 233 440 219 233 441 minecraft:polished_deepslate
setblock 217 233 445 minecraft:deepslate
fill 217 233 447 229 233 447 minecraft:deepslate
fill 218 233 427 229 233 427 minecraft:deepslate
fill 218 233 436 219 233 439 minecraft:polished_deepslate
fill 218 233 443 229 233 443 minecraft:deepslate
fill 218 233 446 229 233 446 minecraft:deepslate
fill 219 233 430 219 233 431 minecraft:deepslate
setblock 219 233 433 minecraft:polished_deepslate
fill 219 233 445 229 233 445 minecraft:deepslate
fill 220 233 430 229 233 430 minecraft:deepslate
fill 220 233 433 229 233 433 minecraft:deepslate
fill 220 233 434 221 233 434 minecraft:polished_deepslate
fill 220 233 435 229 233 435 minecraft:deepslate
fill 220 233 438 229 233 438 minecraft:deepslate
fill 220 233 439 221 233 439 minecraft:polished_deepslate
fill 220 233 440 220 233 441 minecraft:deepslate
fill 220 233 444 229 233 444 minecraft:deepslate
fill 221 233 429 229 233 429 minecraft:deepslate
fill 221 233 432 229 233 432 minecraft:deepslate
fill 221 233 441 229 233 442 minecraft:deepslate
fill 222 233 431 229 233 431 minecraft:deepslate
fill 222 233 434 229 233 434 minecraft:deepslate
fill 222 233 437 229 233 437 minecraft:deepslate
fill 222 233 439 229 233 440 minecraft:deepslate
fill 223 233 436 229 233 436 minecraft:deepslate
fill 199 234 427 199 235 427 minecraft:bone_block
fill 199 234 436 199 240 436 minecraft:bone_block
fill 199 234 445 199 235 445 minecraft:bone_block
fill 202 234 427 202 235 427 minecraft:bone_block
fill 202 234 436 202 240 436 minecraft:bone_block
fill 202 234 445 202 235 445 minecraft:bone_block
fill 205 234 427 205 235 427 minecraft:bone_block
fill 205 234 436 205 240 436 minecraft:bone_block
fill 205 234 445 205 235 445 minecraft:bone_block
fill 208 234 427 208 235 427 minecraft:bone_block
fill 208 234 445 208 235 445 minecraft:bone_block
fill 211 234 427 211 235 427 minecraft:bone_block
fill 211 234 436 211 240 436 minecraft:bone_block
fill 211 234 445 211 235 445 minecraft:bone_block
fill 214 234 427 214 235 427 minecraft:bone_block
fill 214 234 436 214 240 436 minecraft:bone_block
fill 214 234 445 214 235 445 minecraft:bone_block
fill 217 234 427 217 235 427 minecraft:bone_block
fill 217 234 436 217 240 436 minecraft:bone_block
fill 217 234 445 217 235 445 minecraft:bone_block
fill 199 236 428 199 237 428 minecraft:bone_block
fill 199 236 444 199 237 444 minecraft:bone_block
fill 202 236 428 202 237 428 minecraft:bone_block
fill 202 236 444 202 237 444 minecraft:bone_block
fill 205 236 428 205 237 428 minecraft:bone_block
fill 205 236 444 205 237 444 minecraft:bone_block
fill 208 236 428 208 237 428 minecraft:bone_block
fill 208 236 444 208 237 444 minecraft:bone_block
fill 211 236 428 211 237 428 minecraft:bone_block
fill 211 236 444 211 237 444 minecraft:bone_block
fill 214 236 428 214 237 428 minecraft:bone_block
fill 214 236 444 214 237 444 minecraft:bone_block
fill 217 236 428 217 237 428 minecraft:bone_block
fill 217 236 444 217 237 444 minecraft:bone_block
fill 189 237 417 191 269 417 minecraft:polished_deepslate
fill 189 237 427 189 269 429 minecraft:polished_deepslate
fill 189 237 439 189 269 441 minecraft:polished_deepslate
fill 189 237 451 189 269 453 minecraft:polished_deepslate
fill 190 237 453 191 238 453 minecraft:iron_block
fill 195 237 457 197 269 457 minecraft:polished_deepslate
fill 201 237 417 203 269 417 minecraft:polished_deepslate
fill 207 237 457 209 269 457 minecraft:polished_deepslate
fill 213 237 417 215 269 417 minecraft:polished_deepslate
fill 219 237 457 221 269 457 minecraft:polished_deepslate
fill 225 237 417 227 269 417 minecraft:polished_deepslate
fill 229 237 425 229 269 427 minecraft:polished_deepslate
fill 229 237 437 229 269 439 minecraft:polished_deepslate
fill 229 237 449 229 269 451 minecraft:polished_deepslate
setblock 191 238 419 minecraft:light[level=13]
setblock 191 238 427 minecraft:light[level=13]
setblock 191 238 435 minecraft:light[level=13]
setblock 191 238 443 minecraft:light[level=13]
setblock 191 238 451 minecraft:light[level=13]
setblock 199 238 419 minecraft:light[level=13]
setblock 199 238 427 minecraft:light[level=13]
fill 199 238 429 199 239 429 minecraft:bone_block
setblock 199 238 435 minecraft:light[level=13]
fill 199 238 443 199 239 443 minecraft:bone_block
setblock 199 238 451 minecraft:light[level=13]
fill 202 238 429 202 239 429 minecraft:bone_block
fill 202 238 443 202 239 443 minecraft:bone_block
fill 205 238 429 205 239 429 minecraft:bone_block
fill 205 238 443 205 239 443 minecraft:bone_block
setblock 207 238 419 minecraft:light[level=13]
setblock 207 238 427 minecraft:light[level=13]
setblock 207 238 435 minecraft:light[level=13]
setblock 207 238 443 minecraft:light[level=13]
setblock 207 238 451 minecraft:light[level=13]
fill 208 238 429 208 239 429 minecraft:bone_block
fill 208 238 436 208 240 436 minecraft:bone_block
fill 208 238 443 208 239 443 minecraft:bone_block
fill 211 238 429 211 239 429 minecraft:bone_block
fill 211 238 443 211 239 443 minecraft:bone_block
fill 214 238 429 214 239 429 minecraft:bone_block
fill 214 238 443 214 239 443 minecraft:bone_block
setblock 215 238 419 minecraft:light[level=13]
setblock 215 238 427 minecraft:light[level=13]
setblock 215 238 435 minecraft:light[level=13]
setblock 215 238 443 minecraft:light[level=13]
setblock 215 238 451 minecraft:light[level=13]
fill 217 238 429 217 239 429 minecraft:bone_block
fill 217 238 443 217 239 443 minecraft:bone_block
fill 219 238 436 222 244 437 minecraft:bone_block
fill 220 238 435 222 245 435 minecraft:bone_block
setblock 223 238 419 minecraft:light[level=13]
setblock 223 238 427 minecraft:light[level=13]
setblock 223 238 435 minecraft:light[level=13]
fill 223 238 436 223 244 436 minecraft:bone_block
setblock 223 238 443 minecraft:light[level=13]
setblock 223 238 451 minecraft:light[level=13]
fill 199 239 430 199 241 430 minecraft:bone_block
fill 199 239 442 199 241 442 minecraft:bone_block
fill 202 239 430 202 241 430 minecraft:bone_block
fill 202 239 442 202 241 442 minecraft:bone_block
fill 205 239 430 205 241 430 minecraft:bone_block
fill 205 239 442 205 241 442 minecraft:bone_block
fill 208 239 430 208 241 430 minecraft:bone_block
fill 208 239 442 208 241 442 minecraft:bone_block
fill 211 239 430 211 241 430 minecraft:bone_block
fill 211 239 442 211 241 442 minecraft:bone_block
fill 214 239 430 214 241 430 minecraft:bone_block
fill 214 239 442 214 241 442 minecraft:bone_block
fill 217 239 430 217 241 430 minecraft:bone_block
fill 217 239 442 217 241 442 minecraft:bone_block
fill 219 239 434 219 243 435 minecraft:bone_block
fill 219 239 438 222 244 438 minecraft:bone_block
fill 220 239 433 220 243 434 minecraft:bone_block
fill 220 239 439 221 243 439 minecraft:bone_block
fill 221 239 434 223 244 434 minecraft:bone_block
fill 223 239 435 224 243 435 minecraft:bone_block
fill 223 239 437 223 244 437 minecraft:bone_block
fill 224 239 436 224 243 436 minecraft:bone_block
fill 190 240 426 190 245 428 minecraft:polished_deepslate
fill 190 240 438 190 245 440 minecraft:polished_deepslate
fill 190 240 450 190 245 452 minecraft:polished_deepslate
fill 196 240 456 198 245 456 minecraft:polished_deepslate
fill 199 240 435 199 243 435 minecraft:bone_block
fill 199 240 437 199 243 437 minecraft:bone_block
fill 200 240 418 202 245 418 minecraft:polished_deepslate
fill 202 240 435 202 243 435 minecraft:bone_block
fill 202 240 437 202 243 437 minecraft:bone_block
fill 205 240 435 205 243 435 minecraft:bone_block
fill 205 240 437 205 243 437 minecraft:bone_block
fill 208 240 435 208 243 435 minecraft:bone_block
fill 208 240 437 208 243 437 minecraft:bone_block
fill 208 240 456 210 245 456 minecraft:polished_deepslate
fill 211 240 435 211 243 435 minecraft:bone_block
fill 211 240 437 211 243 437 minecraft:bone_block
fill 212 240 418 214 245 418 minecraft:polished_deepslate
fill 214 240 435 214 243 435 minecraft:bone_block
fill 214 240 437 214 243 437 minecraft:bone_block
fill 217 240 435 218 243 435 minecraft:bone_block
fill 217 240 437 218 243 437 minecraft:bone_block
fill 218 240 434 218 242 434 minecraft:bone_block
fill 218 240 436 218 244 436 minecraft:bone_block
fill 218 240 438 218 243 438 minecraft:bone_block
fill 219 240 433 219 242 433 minecraft:bone_block
fill 219 240 439 219 243 439 minecraft:bone_block
fill 220 240 456 222 245 456 minecraft:polished_deepslate
fill 221 240 433 223 243 433 minecraft:bone_block
fill 222 240 439 222 244 439 minecraft:bone_block
fill 223 240 438 223 244 438 minecraft:bone_block
fill 224 240 418 226 245 418 minecraft:polished_deepslate
fill 224 240 434 224 243 434 minecraft:bone_block
fill 224 240 437 224 243 437 minecraft:bone_block
fill 228 240 426 228 245 428 minecraft:polished_deepslate
fill 228 240 438 228 245 440 minecraft:polished_deepslate
fill 228 240 450 228 245 452 minecraft:polished_deepslate
fill 199 241 431 199 242 431 minecraft:bone_block
fill 199 241 441 199 242 441 minecraft:bone_block
fill 202 241 431 202 242 431 minecraft:bone_block
fill 202 241 441 202 242 441 minecraft:bone_block
fill 205 241 431 205 242 431 minecraft:bone_block
fill 205 241 441 205 242 441 minecraft:bone_block
fill 208 241 431 208 242 431 minecraft:bone_block
fill 208 241 441 208 242 441 minecraft:bone_block
fill 211 241 431 211 242 431 minecraft:bone_block
fill 211 241 441 211 242 441 minecraft:bone_block
fill 214 241 431 214 242 431 minecraft:bone_block
fill 214 241 441 214 242 441 minecraft:bone_block
fill 217 241 431 217 242 431 minecraft:bone_block
fill 217 241 441 217 242 441 minecraft:bone_block
fill 220 241 440 221 241 440 minecraft:bone_block
fill 221 241 432 221 242 432 minecraft:bone_block
fill 223 241 439 223 243 439 minecraft:bone_block
fill 224 241 438 224 243 438 minecraft:bone_block
fill 199 242 432 199 243 432 minecraft:bone_block
fill 199 242 440 199 243 440 minecraft:bone_block
fill 202 242 432 202 243 432 minecraft:bone_block
fill 202 242 440 202 243 440 minecraft:bone_block
fill 205 242 432 205 243 432 minecraft:bone_block
fill 205 242 440 205 243 440 minecraft:bone_block
fill 208 242 432 208 243 432 minecraft:bone_block
fill 208 242 440 208 243 440 minecraft:bone_block
fill 211 242 432 211 243 432 minecraft:bone_block
fill 211 242 440 211 243 440 minecraft:bone_block
fill 214 242 432 214 243 432 minecraft:bone_block
fill 214 242 440 214 243 440 minecraft:bone_block
fill 217 242 432 217 243 432 minecraft:bone_block
fill 217 242 440 217 243 440 minecraft:bone_block
fill 222 242 432 222 243 432 minecraft:bone_block
fill 197 243 436 208 244 436 minecraft:bone_block
fill 199 243 433 199 243 434 minecraft:bone_block
fill 199 243 438 199 243 439 minecraft:bone_block
fill 202 243 433 202 243 434 minecraft:bone_block
fill 202 243 438 202 243 439 minecraft:bone_block
fill 205 243 433 205 243 434 minecraft:bone_block
fill 205 243 438 205 243 439 minecraft:bone_block
fill 208 243 433 208 243 434 minecraft:bone_block
fill 208 243 438 208 243 439 minecraft:bone_block
fill 211 243 433 211 243 434 minecraft:bone_block
fill 211 243 436 217 244 436 minecraft:bone_block
fill 211 243 438 211 243 439 minecraft:bone_block
fill 214 243 433 214 243 434 minecraft:bone_block
fill 214 243 438 214 243 439 minecraft:bone_block
fill 217 243 433 217 243 434 minecraft:bone_block
fill 217 243 438 217 243 439 minecraft:bone_block
setblock 218 244 437 minecraft:bone_block
setblock 219 244 435 minecraft:bone_block
setblock 220 244 434 minecraft:bone_block
fill 221 244 433 222 244 433 minecraft:bone_block
setblock 221 244 439 minecraft:bone_block
setblock 223 244 435 minecraft:bone_block
fill 189 245 420 189 245 425 minecraft:deepslate
fill 189 245 432 189 245 437 minecraft:deepslate
fill 189 245 444 189 245 449 minecraft:deepslate
fill 189 245 456 189 245 457 minecraft:deepslate
fill 190 245 457 193 245 457 minecraft:deepslate
fill 193 245 417 198 245 417 minecraft:deepslate
fill 200 245 457 205 245 457 minecraft:deepslate
fill 205 245 417 210 245 417 minecraft:deepslate
fill 212 245 457 217 245 457 minecraft:deepslate
fill 217 245 417 222 245 417 minecraft:deepslate
fill 220 245 436 222 245 437 minecraft:bone_block
fill 221 245 434 222 245 434 minecraft:bone_block
setblock 221 245 438 minecraft:bone_block
fill 224 245 457 229 245 457 minecraft:deepslate
fill 229 245 417 229 245 422 minecraft:deepslate
fill 229 245 429 229 245 434 minecraft:deepslate
fill 229 245 441 229 245 446 minecraft:deepslate
fill 229 245 453 229 245 456 minecraft:deepslate
fill 188 246 422 188 251 425 minecraft:shroomlight
fill 188 246 434 188 251 437 minecraft:shroomlight
fill 188 246 446 188 251 449 minecraft:shroomlight
fill 188 246 458 191 251 458 minecraft:shroomlight
setblock 191 246 419 minecraft:light[level=13]
setblock 191 246 427 minecraft:light[level=13]
setblock 191 246 435 minecraft:light[level=13]
setblock 191 246 443 minecraft:light[level=13]
setblock 191 246 451 minecraft:light[level=13]
fill 195 246 416 198 251 416 minecraft:shroomlight
setblock 199 246 419 minecraft:light[level=13]
setblock 199 246 427 minecraft:light[level=13]
setblock 199 246 435 minecraft:light[level=13]
setblock 199 246 443 minecraft:light[level=13]
setblock 199 246 451 minecraft:light[level=13]
fill 200 246 458 203 251 458 minecraft:shroomlight
fill 207 246 416 210 251 416 minecraft:shroomlight
setblock 207 246 419 minecraft:light[level=13]
setblock 207 246 427 minecraft:light[level=13]
setblock 207 246 435 minecraft:light[level=13]
setblock 207 246 443 minecraft:light[level=13]
setblock 207 246 451 minecraft:light[level=13]
fill 212 246 458 215 251 458 minecraft:shroomlight
setblock 215 246 419 minecraft:light[level=13]
setblock 215 246 427 minecraft:light[level=13]
setblock 215 246 435 minecraft:light[level=13]
setblock 215 246 443 minecraft:light[level=13]
setblock 215 246 451 minecraft:light[level=13]
fill 219 246 416 222 251 416 minecraft:shroomlight
fill 219 246 455 219 256 455 minecraft:red_wool
setblock 223 246 419 minecraft:light[level=13]
setblock 223 246 427 minecraft:light[level=13]
setblock 223 246 435 minecraft:light[level=13]
setblock 223 246 443 minecraft:light[level=13]
setblock 223 246 451 minecraft:light[level=13]
fill 224 246 458 227 251 458 minecraft:shroomlight
fill 230 246 417 230 251 420 minecraft:shroomlight
fill 230 246 429 230 251 432 minecraft:shroomlight
fill 230 246 441 230 251 444 minecraft:shroomlight
fill 230 246 453 230 251 456 minecraft:shroomlight
fill 189 247 434 191 248 434 minecraft:iron_block
fill 217 247 455 218 256 455 minecraft:red_wool
fill 220 247 455 221 256 455 minecraft:red_wool
fill 199 248 417 200 251 417 minecraft:orange_stained_glass
fill 200 248 418 202 251 418 minecraft:orange_stained_glass
fill 201 248 419 201 251 419 minecraft:orange_stained_glass
fill 199 249 418 199 250 418 minecraft:orange_stained_glass
fill 200 249 419 200 251 420 minecraft:orange_stained_glass
fill 201 249 420 202 251 420 minecraft:orange_stained_glass
fill 202 249 419 202 251 419 minecraft:orange_stained_glass
fill 203 249 418 203 250 418 minecraft:orange_stained_glass
fill 200 250 421 202 250 421 minecraft:orange_stained_glass
setblock 201 250 422 minecraft:orange_stained_glass
setblock 201 251 421 minecraft:orange_stained_glass
fill 188 252 422 188 265 422 minecraft:stone
fill 188 252 423 188 252 424 minecraft:shroomlight
fill 188 252 425 188 265 425 minecraft:stone
fill 188 252 434 188 265 434 minecraft:stone
fill 188 252 435 188 252 436 minecraft:shroomlight
fill 188 252 437 188 265 437 minecraft:stone
fill 188 252 446 188 265 446 minecraft:stone
fill 188 252 447 188 252 448 minecraft:shroomlight
fill 188 252 449 188 265 449 minecraft:stone
fill 188 252 458 188 265 458 minecraft:stone
fill 189 252 458 190 252 458 minecraft:shroomlight
fill 191 252 458 191 265 458 minecraft:stone
fill 195 252 416 195 265 416 minecraft:stone
fill 196 252 416 197 252 416 minecraft:shroomlight
fill 198 252 416 198 265 416 minecraft:stone
fill 200 252 458 200 265 458 minecraft:stone
fill 201 252 458 202 252 458 minecraft:shroomlight
fill 203 252 458 203 265 458 minecraft:stone
fill 207 252 416 207 265 416 minecraft:stone
fill 208 252 416 209 252 416 minecraft:shroomlight
fill 210 252 416 210 265 416 minecraft:stone
fill 212 252 458 212 265 458 minecraft:stone
fill 213 252 458 214 252 458 minecraft:shroomlight
fill 215 252 458 215 265 458 minecraft:stone
fill 219 252 416 219 265 416 minecraft:stone
fill 220 252 416 221 252 416 minecraft:shroomlight
fill 222 252 416 222 265 416 minecraft:stone
fill 224 252 458 224 265 458 minecraft:stone
fill 225 252 458 226 252 458 minecraft:shroomlight
fill 227 252 458 227 265 458 minecraft:stone
fill 230 252 417 230 265 417 minecraft:stone
fill 230 252 418 230 252 419 minecraft:shroomlight
fill 230 252 420 230 265 420 minecraft:stone
fill 230 252 429 230 265 429 minecraft:stone
fill 230 252 430 230 252 431 minecraft:shroomlight
fill 230 252 432 230 265 432 minecraft:stone
fill 230 252 441 230 265 441 minecraft:stone
fill 230 252 442 230 252 443 minecraft:shroomlight
fill 230 252 444 230 265 444 minecraft:stone
fill 230 252 453 230 265 453 minecraft:stone
fill 230 252 454 230 252 455 minecraft:shroomlight
fill 230 252 456 230 265 456 minecraft:stone
fill 188 253 423 188 265 424 minecraft:stone
fill 188 253 435 188 265 436 minecraft:stone
fill 188 253 447 188 265 448 minecraft:stone
fill 189 253 458 190 265 458 minecraft:stone
fill 196 253 416 197 265 416 minecraft:stone
fill 201 253 458 202 265 458 minecraft:stone
fill 208 253 416 209 265 416 minecraft:stone
fill 213 253 458 214 265 458 minecraft:stone
fill 220 253 416 221 265 416 minecraft:stone
fill 225 253 458 226 265 458 minecraft:stone
fill 230 253 418 230 265 419 minecraft:stone
fill 230 253 430 230 265 431 minecraft:stone
fill 230 253 442 230 265 443 minecraft:stone
fill 230 253 454 230 265 455 minecraft:stone
setblock 191 254 419 minecraft:light[level=13]
setblock 191 254 427 minecraft:light[level=13]
setblock 191 254 435 minecraft:light[level=13]
setblock 191 254 443 minecraft:light[level=13]
setblock 191 254 451 minecraft:light[level=13]
setblock 199 254 419 minecraft:light[level=13]
setblock 199 254 427 minecraft:light[level=13]
setblock 199 254 435 minecraft:light[level=13]
setblock 199 254 443 minecraft:light[level=13]
setblock 199 254 451 minecraft:light[level=13]
setblock 207 254 419 minecraft:light[level=13]
setblock 207 254 427 minecraft:light[level=13]
setblock 207 254 435 minecraft:light[level=13]
setblock 207 254 443 minecraft:light[level=13]
setblock 207 254 451 minecraft:light[level=13]
setblock 215 254 419 minecraft:light[level=13]
setblock 215 254 427 minecraft:light[level=13]
setblock 215 254 435 minecraft:light[level=13]
setblock 215 254 443 minecraft:light[level=13]
setblock 215 254 451 minecraft:light[level=13]
setblock 223 254 419 minecraft:light[level=13]
setblock 223 254 427 minecraft:light[level=13]
setblock 223 254 435 minecraft:light[level=13]
setblock 223 254 443 minecraft:light[level=13]
setblock 223 254 451 minecraft:light[level=13]
fill 216 257 455 222 258 455 minecraft:iron_block
fill 190 260 426 190 265 428 minecraft:polished_deepslate
fill 190 260 438 190 265 440 minecraft:polished_deepslate
fill 190 260 450 190 265 452 minecraft:polished_deepslate
fill 196 260 456 198 265 456 minecraft:polished_deepslate
fill 200 260 418 202 265 418 minecraft:polished_deepslate
fill 208 260 456 210 265 456 minecraft:polished_deepslate
fill 212 260 418 214 265 418 minecraft:polished_deepslate
fill 220 260 456 222 265 456 minecraft:polished_deepslate
fill 224 260 418 226 265 418 minecraft:polished_deepslate
fill 228 260 426 228 265 428 minecraft:polished_deepslate
fill 228 260 438 228 265 440 minecraft:polished_deepslate
fill 228 260 450 228 265 452 minecraft:polished_deepslate
setblock 191 262 419 minecraft:light[level=13]
setblock 191 262 427 minecraft:light[level=13]
setblock 191 262 435 minecraft:light[level=13]
setblock 191 262 443 minecraft:light[level=13]
setblock 191 262 451 minecraft:light[level=13]
setblock 199 262 419 minecraft:light[level=13]
setblock 199 262 427 minecraft:light[level=13]
setblock 199 262 435 minecraft:light[level=13]
setblock 199 262 443 minecraft:light[level=13]
setblock 199 262 451 minecraft:light[level=13]
setblock 207 262 419 minecraft:light[level=13]
setblock 207 262 427 minecraft:light[level=13]
setblock 207 262 435 minecraft:light[level=13]
setblock 207 262 443 minecraft:light[level=13]
setblock 207 262 451 minecraft:light[level=13]
setblock 215 262 419 minecraft:light[level=13]
setblock 215 262 427 minecraft:light[level=13]
setblock 215 262 435 minecraft:light[level=13]
setblock 215 262 443 minecraft:light[level=13]
setblock 215 262 451 minecraft:light[level=13]
setblock 223 262 419 minecraft:light[level=13]
setblock 223 262 427 minecraft:light[level=13]
setblock 223 262 435 minecraft:light[level=13]
setblock 223 262 443 minecraft:light[level=13]
setblock 223 262 451 minecraft:light[level=13]
fill 189 265 420 189 265 425 minecraft:deepslate
fill 189 265 432 189 265 437 minecraft:deepslate
fill 189 265 444 189 265 449 minecraft:deepslate
fill 189 265 456 189 265 457 minecraft:deepslate
fill 190 265 457 193 265 457 minecraft:deepslate
fill 193 265 417 198 265 417 minecraft:deepslate
fill 200 265 457 205 265 457 minecraft:deepslate
fill 205 265 417 210 265 417 minecraft:deepslate
fill 212 265 457 217 265 457 minecraft:deepslate
fill 217 265 417 222 265 417 minecraft:deepslate
fill 224 265 457 229 265 457 minecraft:deepslate
fill 229 265 417 229 265 422 minecraft:deepslate
fill 229 265 429 229 265 434 minecraft:deepslate
fill 229 265 441 229 265 446 minecraft:deepslate
fill 229 265 453 229 265 456 minecraft:deepslate
fill 188 266 422 188 269 425 minecraft:shroomlight
fill 188 266 434 188 269 437 minecraft:shroomlight
fill 188 266 446 188 269 449 minecraft:shroomlight
fill 188 266 458 191 269 458 minecraft:shroomlight
fill 195 266 416 198 269 416 minecraft:shroomlight
fill 200 266 458 203 269 458 minecraft:shroomlight
fill 207 266 416 210 269 416 minecraft:shroomlight
fill 212 266 458 215 269 458 minecraft:shroomlight
fill 219 266 416 222 269 416 minecraft:shroomlight
fill 224 266 458 227 269 458 minecraft:shroomlight
fill 230 266 417 230 269 420 minecraft:shroomlight
fill 230 266 429 230 269 432 minecraft:shroomlight
fill 230 266 441 230 269 444 minecraft:shroomlight
fill 230 266 453 230 269 456 minecraft:shroomlight
fill 188 270 422 188 285 425 minecraft:stone
fill 188 270 434 188 285 437 minecraft:stone
fill 188 270 446 188 285 449 minecraft:stone
fill 188 270 458 191 285 458 minecraft:stone
setblock 191 270 419 minecraft:light[level=13]
setblock 191 270 427 minecraft:light[level=13]
setblock 191 270 435 minecraft:light[level=13]
setblock 191 270 443 minecraft:light[level=13]
setblock 191 270 451 minecraft:light[level=13]
fill 195 270 416 198 285 416 minecraft:stone
setblock 199 270 419 minecraft:light[level=13]
setblock 199 270 427 minecraft:light[level=13]
setblock 199 270 435 minecraft:light[level=13]
setblock 199 270 443 minecraft:light[level=13]
setblock 199 270 451 minecraft:light[level=13]
fill 200 270 458 203 285 458 minecraft:stone
fill 207 270 416 210 285 416 minecraft:stone
setblock 207 270 419 minecraft:light[level=13]
setblock 207 270 427 minecraft:light[level=13]
setblock 207 270 435 minecraft:light[level=13]
setblock 207 270 443 minecraft:light[level=13]
setblock 207 270 451 minecraft:light[level=13]
fill 212 270 458 215 285 458 minecraft:stone
setblock 215 270 419 minecraft:light[level=13]
setblock 215 270 427 minecraft:light[level=13]
setblock 215 270 435 minecraft:light[level=13]
setblock 215 270 443 minecraft:light[level=13]
setblock 215 270 451 minecraft:light[level=13]
fill 219 270 416 222 285 416 minecraft:stone
setblock 223 270 419 minecraft:light[level=13]
setblock 223 270 427 minecraft:light[level=13]
setblock 223 270 435 minecraft:light[level=13]
setblock 223 270 443 minecraft:light[level=13]
setblock 223 270 451 minecraft:light[level=13]
fill 224 270 458 227 285 458 minecraft:stone
fill 230 270 417 230 285 420 minecraft:stone
fill 230 270 429 230 285 432 minecraft:stone
fill 230 270 441 230 285 444 minecraft:stone
fill 230 270 453 230 285 456 minecraft:stone
fill 189 275 419 208 275 455 minecraft:iron_block
fill 190 275 418 228 275 418 minecraft:iron_block
fill 190 275 456 228 275 456 minecraft:iron_block
fill 191 275 417 227 275 417 minecraft:iron_block
fill 191 275 457 227 275 457 minecraft:iron_block
fill 209 275 419 209 277 433 minecraft:iron_block
fill 209 275 437 209 277 455 minecraft:iron_block
fill 210 275 419 229 275 432 minecraft:iron_block
fill 210 275 438 229 275 455 minecraft:iron_block
fill 213 275 433 229 277 433 minecraft:iron_block
fill 213 275 437 229 277 437 minecraft:iron_block
fill 214 275 434 229 277 436 minecraft:iron_block
fill 189 276 420 208 276 454 minecraft:iron_block
fill 190 276 419 208 276 419 minecraft:iron_block
fill 190 276 455 208 276 455 minecraft:iron_block
fill 191 276 418 227 276 418 minecraft:iron_block
fill 191 276 456 227 276 456 minecraft:iron_block
fill 192 276 417 226 276 417 minecraft:iron_block
fill 192 276 457 226 276 457 minecraft:iron_block
fill 210 276 419 228 276 432 minecraft:iron_block
fill 210 276 438 228 276 455 minecraft:iron_block
fill 229 276 420 229 276 432 minecraft:iron_block
fill 229 276 438 229 276 454 minecraft:iron_block
fill 189 277 421 208 277 453 minecraft:iron_block
fill 190 277 420 208 279 420 minecraft:iron_block
fill 190 277 454 208 279 454 minecraft:iron_block
fill 191 277 419 208 279 419 minecraft:iron_block
fill 191 277 455 208 279 455 minecraft:iron_block
fill 192 277 418 226 279 418 minecraft:iron_block
fill 192 277 456 226 279 456 minecraft:iron_block
fill 193 277 417 225 279 417 minecraft:iron_block
fill 193 277 457 225 279 457 minecraft:iron_block
fill 210 277 419 227 277 432 minecraft:iron_block
fill 210 277 438 227 277 455 minecraft:iron_block
fill 228 277 420 228 279 432 minecraft:iron_block
fill 228 277 438 228 279 454 minecraft:iron_block
fill 229 277 421 229 279 432 minecraft:iron_block
fill 229 277 438 229 279 453 minecraft:iron_block
fill 189 278 421 207 278 453 minecraft:iron_block
fill 208 278 421 208 278 433 minecraft:iron_block
fill 208 278 434 208 278 436 minecraft:gold_block
fill 208 278 437 208 278 453 minecraft:iron_block
fill 209 278 419 210 278 432 minecraft:iron_block
setblock 209 278 433 minecraft:gold_block
setblock 209 278 437 minecraft:gold_block
fill 209 278 438 209 278 455 minecraft:iron_block
fill 210 278 438 212 278 438 minecraft:gold_block
fill 210 278 439 227 278 455 minecraft:iron_block
fill 211 278 419 227 278 431 minecraft:iron_block
setblock 211 278 432 minecraft:gold_block
fill 212 278 432 227 278 432 minecraft:iron_block
setblock 213 278 433 minecraft:gold_block
setblock 213 278 437 minecraft:gold_block
fill 213 278 438 227 278 438 minecraft:iron_block
fill 214 278 433 229 278 434 minecraft:iron_block
setblock 214 278 435 minecraft:gold_block
fill 214 278 436 229 278 437 minecraft:iron_block
fill 215 278 435 229 278 435 minecraft:iron_block
fill 189 279 417 189 279 457 minecraft:iron_block
fill 190 279 417 190 279 419 minecraft:iron_block
fill 190 279 421 206 279 453 minecraft:iron_block
fill 190 279 455 190 279 457 minecraft:iron_block
fill 191 279 417 191 279 418 minecraft:iron_block
fill 191 279 456 191 279 457 minecraft:iron_block
setblock 192 279 417 minecraft:iron_block
setblock 192 279 457 minecraft:iron_block
fill 207 279 421 207 279 433 minecraft:iron_block
fill 207 279 434 207 279 437 minecraft:polished_deepslate
fill 207 279 438 207 279 453 minecraft:iron_block
fill 208 279 421 208 279 432 minecraft:iron_block
fill 208 279 433 208 279 437 minecraft:shroomlight
setblock 208 279 438 minecraft:polished_deepslate
fill 208 279 439 208 279 453 minecraft:iron_block
fill 209 279 419 210 279 431 minecraft:iron_block
fill 209 279 432 209 279 433 minecraft:shroomlight
fill 209 279 437 209 279 438 minecraft:shroomlight
fill 209 279 439 212 279 439 minecraft:polished_deepslate
fill 209 279 440 227 279 455 minecraft:iron_block
fill 210 279 432 213 279 432 minecraft:shroomlight
fill 210 279 438 213 279 438 minecraft:shroomlight
fill 211 279 419 227 279 430 minecraft:iron_block
setblock 211 279 431 minecraft:polished_deepslate
fill 212 279 431 227 279 431 minecraft:iron_block
fill 213 279 433 214 279 433 minecraft:shroomlight
fill 213 279 437 214 279 437 minecraft:shroomlight
fill 213 279 439 227 279 439 minecraft:iron_block
fill 214 279 432 227 279 432 minecraft:iron_block
fill 214 279 434 214 279 436 minecraft:shroomlight
fill 214 279 438 227 279 438 minecraft:iron_block
fill 215 279 433 229 279 434 minecraft:iron_block
setblock 215 279 435 minecraft:polished_deepslate
fill 215 279 436 229 279 437 minecraft:iron_block
fill 216 279 435 229 280 435 minecraft:iron_block
fill 226 279 417 229 279 417 minecraft:iron_block
fill 226 279 457 229 279 457 minecraft:iron_block
fill 227 279 418 229 279 418 minecraft:iron_block
fill 227 279 456 229 279 456 minecraft:iron_block
fill 228 279 419 229 279 419 minecraft:iron_block
fill 228 279 455 229 279 455 minecraft:iron_block
setblock 229 279 420 minecraft:iron_block
setblock 229 279 454 minecraft:iron_block
fill 189 280 423 205 280 451 minecraft:iron_block
fill 190 280 422 228 280 422 minecraft:iron_block
fill 190 280 452 228 280 452 minecraft:iron_block
fill 191 280 421 227 281 421 minecraft:iron_block
fill 191 280 453 227 281 453 minecraft:iron_block
fill 192 280 420 226 281 420 minecraft:iron_block
fill 192 280 454 226 281 454 minecraft:iron_block
fill 193 280 419 225 281 419 minecraft:iron_block
fill 193 280 455 225 281 455 minecraft:iron_block
fill 194 280 418 224 280 418 minecraft:iron_block
fill 194 280 456 224 280 456 minecraft:iron_block
fill 195 280 417 223 280 417 minecraft:iron_block
fill 195 280 457 223 280 457 minecraft:iron_block
fill 206 280 423 206 280 432 minecraft:iron_block
fill 206 280 433 206 280 438 minecraft:gold_block
fill 206 280 439 206 280 451 minecraft:iron_block
fill 207 280 423 207 280 431 minecraft:iron_block
fill 207 280 432 207 280 433 minecraft:gold_block
fill 207 280 438 207 280 439 minecraft:gold_block
fill 207 280 440 207 280 451 minecraft:iron_block
fill 208 280 423 229 280 430 minecraft:iron_block
fill 208 280 431 208 280 432 minecraft:gold_block
fill 208 280 439 208 280 440 minecraft:gold_block
fill 208 280 441 229 280 451 minecraft:iron_block
fill 209 280 431 213 280 431 minecraft:gold_block
fill 209 280 440 213 280 440 minecraft:gold_block
fill 213 280 439 214 280 439 minecraft:gold_block
fill 214 280 431 229 280 431 minecraft:iron_block
setblock 214 280 432 minecraft:gold_block
fill 214 280 438 215 280 438 minecraft:gold_block
fill 214 280 440 229 280 440 minecraft:iron_block
fill 215 280 432 229 280 432 minecraft:iron_block
fill 215 280 433 215 280 437 minecraft:gold_block
fill 215 280 439 229 280 439 minecraft:iron_block
fill 216 280 433 229 280 434 minecraft:iron_block
fill 216 280 436 229 280 438 minecraft:iron_block
fill 189 281 424 204 281 450 minecraft:iron_block
fill 190 281 423 228 281 423 minecraft:iron_block
fill 190 281 451 228 281 451 minecraft:iron_block
fill 191 281 422 227 282 422 minecraft:iron_block
fill 191 281 452 227 282 452 minecraft:iron_block
fill 195 281 418 223 281 418 minecraft:iron_block
fill 195 281 456 223 281 456 minecraft:iron_block
fill 196 281 417 222 281 417 minecraft:iron_block
fill 196 281 457 222 281 457 minecraft:iron_block
fill 205 281 424 205 281 432 minecraft:iron_block
fill 205 281 433 205 281 438 minecraft:gold_block
fill 205 281 439 205 281 450 minecraft:iron_block
fill 206 281 424 206 281 431 minecraft:iron_block
setblock 206 281 432 minecraft:gold_block
fill 206 281 439 206 281 440 minecraft:gold_block
fill 206 281 441 207 281 450 minecraft:iron_block
fill 207 281 424 207 281 430 minecraft:iron_block
setblock 207 281 431 minecraft:gold_block
setblock 207 281 440 minecraft:gold_block
fill 208 281 424 229 281 429 minecraft:iron_block
fill 208 281 430 213 281 430 minecraft:gold_block
fill 208 281 441 213 281 441 minecraft:gold_block
fill 208 281 442 229 281 450 minecraft:iron_block
fill 214 281 430 229 281 430 minecraft:iron_block
setblock 214 281 431 minecraft:gold_block
setblock 214 281 440 minecraft:gold_block
fill 214 281 441 229 281 441 minecraft:iron_block
fill 215 281 431 229 281 431 minecraft:iron_block
setblock 215 281 432 minecraft:gold_block
setblock 215 281 439 minecraft:gold_block
fill 215 281 440 229 281 440 minecraft:iron_block
fill 216 281 432 229 281 432 minecraft:iron_block
fill 216 281 433 216 281 438 minecraft:gold_block
fill 216 281 439 229 281 439 minecraft:iron_block
fill 217 281 433 229 281 438 minecraft:iron_block
fill 189 282 425 202 282 449 minecraft:iron_block
fill 190 282 424 228 282 424 minecraft:iron_block
fill 190 282 450 228 282 450 minecraft:iron_block
fill 191 282 423 227 283 423 minecraft:iron_block
fill 191 282 451 227 283 451 minecraft:iron_block
fill 192 282 421 226 282 421 minecraft:iron_block
fill 192 282 453 226 282 453 minecraft:iron_block
fill 193 282 420 225 282 420 minecraft:iron_block
fill 193 282 454 225 282 454 minecraft:iron_block
fill 194 282 419 224 282 419 minecraft:iron_block
fill 194 282 455 224 282 455 minecraft:iron_block
fill 196 282 418 222 282 418 minecraft:iron_block
fill 196 282 456 222 282 456 minecraft:iron_block
fill 197 282 417 221 282 417 minecraft:iron_block
fill 197 282 457 221 282 457 minecraft:iron_block
fill 203 282 425 203 282 434 minecraft:iron_block
fill 203 282 435 204 282 437 minecraft:polished_deepslate
fill 203 282 438 203 282 449 minecraft:iron_block
fill 204 282 425 204 282 431 minecraft:iron_block
fill 204 282 432 204 282 434 minecraft:polished_deepslate
fill 204 282 438 204 282 439 minecraft:polished_deepslate
fill 204 282 440 204 282 449 minecraft:iron_block
fill 205 282 425 205 282 430 minecraft:iron_block
fill 205 282 431 205 282 432 minecraft:polished_deepslate
fill 205 282 439 205 282 440 minecraft:polished_deepslate
fill 205 282 441 205 282 449 minecraft:iron_block
fill 206 282 425 207 282 429 minecraft:iron_block
fill 206 282 430 206 282 431 minecraft:polished_deepslate
fill 206 282 441 207 282 441 minecraft:polished_deepslate
fill 206 282 442 206 282 449 minecraft:iron_block
setblock 207 282 430 minecraft:polished_deepslate
fill 207 282 442 214 282 442 minecraft:polished_deepslate
fill 207 282 443 208 282 449 minecraft:iron_block
fill 208 282 425 229 282 428 minecraft:iron_block
fill 208 282 429 213 282 429 minecraft:polished_deepslate
fill 209 282 443 211 282 443 minecraft:polished_deepslate
fill 209 282 444 229 282 449 minecraft:iron_block
fill 212 282 443 229 282 443 minecraft:iron_block
fill 214 282 429 229 282 429 minecraft:iron_block
setblock 214 282 430 minecraft:polished_deepslate
fill 214 282 441 215 282 441 minecraft:polished_deepslate
fill 215 282 430 229 282 430 minecraft:iron_block
setblock 215 282 431 minecraft:polished_deepslate
fill 215 282 440 216 282 440 minecraft:polished_deepslate
fill 215 282 442 229 282 442 minecraft:iron_block
fill 216 282 431 229 282 431 minecraft:iron_block
setblock 216 282 432 minecraft:polished_deepslate
setblock 216 282 439 minecraft:polished_deepslate
fill 216 282 441 229 282 441 minecraft:iron_block
fill 217 282 432 229 282 432 minecraft:iron_block
fill 217 282 433 217 282 438 minecraft:polished_deepslate
fill 217 282 439 229 282 440 minecraft:iron_block
fill 218 282 433 229 282 438 minecraft:iron_block
fill 189 283 417 191 300 417 minecraft:polished_deepslate
fill 189 283 426 201 283 448 minecraft:iron_block
fill 189 283 451 189 300 453 minecraft:polished_deepslate
fill 190 283 425 228 283 425 minecraft:iron_block
fill 190 283 449 228 283 449 minecraft:iron_block
fill 190 283 450 190 285 452 minecraft:polished_deepslate
fill 191 283 424 227 284 424 minecraft:iron_block
fill 191 283 450 227 284 450 minecraft:iron_block
fill 192 283 422 226 283 422 minecraft:iron_block
fill 192 283 452 226 283 452 minecraft:iron_block
fill 193 283 421 225 283 421 minecraft:iron_block
fill 193 283 453 225 283 453 minecraft:iron_block
fill 194 283 420 224 283 420 minecraft:iron_block
fill 194 283 454 224 283 454 minecraft:iron_block
fill 195 283 419 223 283 419 minecraft:iron_block
fill 195 283 455 223 283 455 minecraft:iron_block
fill 195 283 457 197 300 457 minecraft:polished_deepslate
fill 196 283 456 196 285 456 minecraft:polished_deepslate
fill 197 283 418 221 283 418 minecraft:iron_block
fill 197 283 456 221 283 456 minecraft:iron_block
fill 198 283 417 220 283 417 minecraft:iron_block
fill 198 283 457 220 283 457 minecraft:iron_block
fill 202 283 426 202 283 433 minecraft:iron_block
fill 202 283 434 202 283 438 minecraft:gold_block
fill 202 283 439 202 283 448 minecraft:iron_block
fill 203 283 426 203 283 431 minecraft:iron_block
fill 203 283 432 203 283 434 minecraft:gold_block
fill 203 283 438 203 283 440 minecraft:gold_block
fill 203 283 441 203 283 448 minecraft:iron_block
fill 204 283 426 204 283 430 minecraft:iron_block
setblock 204 283 431 minecraft:gold_block
fill 204 283 440 204 283 441 minecraft:gold_block
fill 204 283 442 204 283 448 minecraft:iron_block
fill 205 283 426 205 283 429 minecraft:iron_block
setblock 205 283 430 minecraft:gold_block
fill 205 283 441 205 283 442 minecraft:gold_block
fill 205 283 443 205 283 448 minecraft:iron_block
fill 206 283 426 207 283 428 minecraft:iron_block
fill 206 283 429 207 283 429 minecraft:gold_block
fill 206 283 442 206 283 443 minecraft:gold_block
fill 206 283 444 207 283 448 minecraft:iron_block
fill 207 283 443 208 283 443 minecraft:gold_block
fill 208 283 426 229 283 427 minecraft:iron_block
fill 208 283 428 212 283 428 minecraft:gold_block
fill 208 283 444 212 283 444 minecraft:gold_block
fill 208 283 445 229 283 448 minecraft:iron_block
fill 212 283 443 214 283 443 minecraft:gold_block
fill 213 283 428 229 283 428 minecraft:iron_block
fill 213 283 429 214 283 429 minecraft:gold_block
fill 213 283 444 229 283 444 minecraft:iron_block
fill 215 283 429 229 283 429 minecraft:iron_block
setblock 215 283 430 minecraft:gold_block
setblock 215 283 442 minecraft:gold_block
fill 215 283 443 229 283 443 minecraft:iron_block
fill 216 283 430 229 283 430 minecraft:iron_block
setblock 216 283 431 minecraft:gold_block
setblock 216 283 441 minecraft:gold_block
fill 216 283 442 229 283 442 minecraft:iron_block
fill 217 283 431 229 283 431 minecraft:iron_block
fill 217 283 432 217 283 433 minecraft:gold_block
fill 217 283 439 217 283 440 minecraft:gold_block
fill 217 283 441 229 283 441 minecraft:iron_block
fill 218 283 432 229 283 433 minecraft:iron_block
fill 218 283 434 218 283 438 minecraft:gold_block
fill 218 283 439 229 283 440 minecraft:iron_block
fill 219 283 434 229 283 438 minecraft:iron_block
fill 221 283 457 221 300 457 minecraft:polished_deepslate
fill 222 283 456 222 285 456 minecraft:polished_deepslate
fill 224 283 418 226 285 418 minecraft:polished_deepslate
fill 225 283 417 227 300 417 minecraft:polished_deepslate
fill 227 283 418 228 284 418 minecraft:iron_block
fill 228 283 450 228 285 452 minecraft:polished_deepslate
fill 229 283 425 229 300 425 minecraft:polished_deepslate
fill 229 283 449 229 300 451 minecraft:polished_deepslate
fill 189 284 427 189 300 427 minecraft:polished_deepslate
fill 189 284 428 200 284 446 minecraft:iron_block
fill 190 284 426 207 284 427 minecraft:iron_block
fill 190 284 447 228 284 448 minecraft:iron_block
fill 191 284 425 227 285 425 minecraft:iron_block
fill 191 284 449 227 285 449 minecraft:iron_block
fill 192 284 423 226 284 423 minecraft:iron_block
fill 192 284 451 226 284 451 minecraft:iron_block
fill 193 284 422 225 284 422 minecraft:iron_block
fill 193 284 452 225 284 452 minecraft:iron_block
fill 194 284 421 224 284 421 minecraft:iron_block
fill 194 284 453 224 284 453 minecraft:iron_block
fill 195 284 420 223 284 420 minecraft:iron_block
fill 195 284 454 223 284 454 minecraft:iron_block
fill 196 284 419 222 284 419 minecraft:iron_block
fill 196 284 455 222 284 455 minecraft:iron_block
fill 197 284 456 197 285 456 minecraft:polished_deepslate
fill 198 284 418 220 284 418 minecraft:iron_block
fill 198 284 456 220 284 456 minecraft:iron_block
fill 200 284 417 218 284 417 minecraft:iron_block
fill 200 284 457 218 284 457 minecraft:iron_block
fill 201 284 428 201 284 432 minecraft:iron_block
fill 201 284 433 201 284 439 minecraft:gold_block
fill 201 284 440 201 284 446 minecraft:iron_block
fill 202 284 428 202 284 431 minecraft:iron_block
fill 202 284 432 202 284 433 minecraft:gold_block
fill 202 284 439 202 284 441 minecraft:gold_block
fill 202 284 442 202 284 446 minecraft:iron_block
fill 203 284 428 203 284 429 minecraft:iron_block
fill 203 284 430 203 284 431 minecraft:gold_block
fill 203 284 441 203 284 442 minecraft:gold_block
fill 203 284 443 203 284 446 minecraft:iron_block
fill 204 284 428 205 284 428 minecraft:iron_block
fill 204 284 429 204 284 430 minecraft:gold_block
fill 204 284 442 204 284 443 minecraft:gold_block
fill 204 284 444 204 284 446 minecraft:iron_block
setblock 205 284 429 minecraft:gold_block
fill 205 284 443 205 284 444 minecraft:gold_block
fill 205 284 445 206 284 446 minecraft:iron_block
fill 206 284 428 207 284 428 minecraft:gold_block
fill 206 284 444 207 284 444 minecraft:gold_block
fill 207 284 445 213 284 445 minecraft:gold_block
fill 207 284 446 229 284 446 minecraft:iron_block
fill 208 284 426 228 284 426 minecraft:iron_block
fill 208 284 427 212 284 427 minecraft:gold_block
fill 213 284 427 228 284 427 minecraft:iron_block
fill 213 284 428 214 284 428 minecraft:gold_block
fill 213 284 444 214 284 444 minecraft:gold_block
fill 214 284 445 229 284 445 minecraft:iron_block
fill 215 284 428 229 284 428 minecraft:iron_block
setblock 215 284 429 minecraft:gold_block
fill 215 284 443 216 284 443 minecraft:gold_block
fill 215 284 444 229 284 444 minecraft:iron_block
fill 216 284 429 229 284 429 minecraft:iron_block
setblock 216 284 430 minecraft:gold_block
fill 216 284 442 217 284 442 minecraft:gold_block
fill 217 284 430 229 284 430 minecraft:iron_block
setblock 217 284 431 minecraft:gold_block
setblock 217 284 441 minecraft:gold_block
fill 217 284 443 229 284 443 minecraft:iron_block
fill 218 284 431 229 284 431 minecraft:iron_block
fill 218 284 432 218 284 433 minecraft:gold_block
fill 218 284 439 218 284 440 minecraft:gold_block
fill 218 284 441 229 284 442 minecraft:iron_block
fill 219 284 432 229 284 433 minecraft:iron_block
fill 219 284 434 219 284 438 minecraft:gold_block
fill 219 284 439 229 284 440 minecraft:iron_block
fill 219 284 457 220 300 457 minecraft:polished_deepslate
fill 220 284 434 229 284 438 minecraft:iron_block
fill 221 284 456 221 285 456 minecraft:polished_deepslate
fill 229 284 426 229 300 427 minecraft:polished_deepslate
fill 189 285 420 189 285 425 minecraft:deepslate
fill 189 285 428 189 300 428 minecraft:polished_deepslate
fill 189 285 429 199 285 445 minecraft:iron_block
fill 189 285 446 189 285 449 minecraft:deepslate
fill 189 285 456 189 285 457 minecraft:deepslate
setblock 190 285 426 minecraft:polished_deepslate
fill 190 285 427 203 285 428 minecraft:iron_block
fill 190 285 446 205 285 447 minecraft:iron_block
fill 190 285 457 193 285 457 minecraft:deepslate
fill 191 285 426 207 285 426 minecraft:iron_block
fill 191 285 448 227 285 448 minecraft:iron_block
fill 192 285 424 226 285 424 minecraft:iron_block
fill 192 285 450 226 285 450 minecraft:iron_block
fill 193 285 417 198 285 417 minecraft:deepslate
fill 193 285 423 225 285 423 minecraft:iron_block
fill 193 285 451 225 285 451 minecraft:iron_block
fill 194 285 422 224 285 422 minecraft:iron_block
fill 194 285 452 224 285 452 minecraft:iron_block
fill 195 285 421 223 285 421 minecraft:iron_block
fill 195 285 453 223 285 453 minecraft:iron_block
fill 196 285 420 222 285 420 minecraft:iron_block
fill 196 285 454 222 285 454 minecraft:iron_block
fill 197 285 419 221 285 419 minecraft:iron_block
fill 197 285 455 221 285 455 minecraft:iron_block
setblock 198 285 456 minecraft:polished_deepslate
fill 199 285 418 219 285 418 minecraft:iron_block
fill 199 285 456 219 285 456 minecraft:iron_block
fill 200 285 429 200 285 432 minecraft:iron_block
fill 200 285 433 200 285 440 minecraft:polished_deepslate
fill 200 285 441 200 285 445 minecraft:iron_block
setblock 200 285 457 minecraft:deepslate
fill 201 285 417 217 285 417 minecraft:iron_block
fill 201 285 429 201 285 430 minecraft:iron_block
fill 201 285 431 201 285 432 minecraft:polished_deepslate
fill 201 285 440 201 285 442 minecraft:polished_deepslate
fill 201 285 443 201 285 445 minecraft:iron_block
fill 201 285 457 217 285 457 minecraft:iron_block
setblock 202 285 429 minecraft:iron_block
fill 202 285 430 202 285 431 minecraft:polished_deepslate
fill 202 285 442 202 285 443 minecraft:polished_deepslate
fill 202 285 444 202 285 445 minecraft:iron_block
setblock 203 285 429 minecraft:polished_deepslate
fill 203 285 443 203 285 444 minecraft:polished_deepslate
setblock 203 285 445 minecraft:iron_block
fill 204 285 427 205 285 427 minecraft:iron_block
fill 204 285 428 205 285 428 minecraft:polished_deepslate
fill 204 285 444 204 285 445 minecraft:polished_deepslate
fill 205 285 445 206 285 445 minecraft:polished_deepslate
fill 206 285 427 207 285 427 minecraft:polished_deepslate
fill 206 285 446 213 285 446 minecraft:polished_deepslate
fill 206 285 447 228 285 447 minecraft:iron_block
fill 208 285 426 211 285 426 minecraft:polished_deepslate
fill 212 285 426 227 285 426 minecraft:iron_block
fill 212 285 427 214 285 427 minecraft:polished_deepslate
fill 214 285 445 215 285 445 minecraft:polished_deepslate
fill 214 285 446 228 285 446 minecraft:iron_block
fill 215 285 427 228 285 427 minecraft:iron_block
setblock 215 285 428 minecraft:polished_deepslate
fill 215 285 444 216 285 444 minecraft:polished_deepslate
fill 216 285 428 228 285 428 minecraft:iron_block
setblock 216 285 429 minecraft:polished_deepslate
fill 216 285 445 229 285 445 minecraft:iron_block
fill 217 285 429 229 285 429 minecraft:iron_block
setblock 217 285 430 minecraft:polished_deepslate
setblock 217 285 443 minecraft:polished_deepslate
fill 217 285 444 229 285 444 minecraft:iron_block
fill 218 285 417 222 285 417 minecraft:deepslate
fill 218 285 430 229 285 430 minecraft:iron_block
setblock 218 285 431 minecraft:polished_deepslate
fill 218 285 441 218 285 442 minecraft:polished_deepslate
fill 218 285 443 229 285 443 minecraft:iron_block
fill 219 285 431 229 285 431 minecraft:iron_block
fill 219 285 432 219 285 434 minecraft:polished_deepslate
fill 219 285 439 219 285 440 minecraft:polished_deepslate
fill 219 285 441 229 285 442 minecraft:iron_block
fill 220 285 432 229 285 434 minecraft:iron_block
fill 220 285 435 220 285 438 minecraft:polished_deepslate
fill 220 285 439 229 285 440 minecraft:iron_block
setblock 220 285 456 minecraft:polished_deepslate
fill 221 285 435 229 285 438 minecraft:iron_block
fill 224 285 457 229 285 457 minecraft:deepslate
setblock 228 285 426 minecraft:polished_deepslate
fill 229 285 417 229 285 422 minecraft:deepslate
setblock 229 285 446 minecraft:deepslate
fill 229 285 453 229 285 456 minecraft:deepslate
fill 188 286 422 188 291 425 minecraft:shroomlight
fill 188 286 434 188 291 437 minecraft:shroomlight
fill 188 286 446 188 291 449 minecraft:shroomlight
fill 188 286 458 191 291 458 minecraft:shroomlight
fill 189 286 429 189 300 429 minecraft:polished_deepslate
fill 189 286 432 198 286 442 minecraft:iron_block
fill 190 286 429 199 286 431 minecraft:iron_block
fill 190 286 443 200 286 445 minecraft:iron_block
setblock 191 286 419 minecraft:light[level=13]
fill 191 286 427 201 286 428 minecraft:iron_block
fill 191 286 446 203 286 447 minecraft:iron_block
setblock 191 286 451 minecraft:light[level=13]
fill 192 286 425 205 286 426 minecraft:iron_block
fill 192 286 448 226 286 449 minecraft:iron_block
fill 193 286 424 225 286 424 minecraft:iron_block
fill 193 286 450 225 286 450 minecraft:iron_block
fill 194 286 423 224 286 423 minecraft:iron_block
fill 194 286 451 224 286 451 minecraft:iron_block
fill 195 286 416 198 291 416 minecraft:shroomlight
fill 195 286 422 223 286 422 minecraft:iron_block
fill 195 286 452 223 286 452 minecraft:iron_block
fill 196 286 421 222 286 421 minecraft:iron_block
fill 196 286 453 222 286 453 minecraft:iron_block
fill 197 286 420 221 286 420 minecraft:iron_block
fill 197 286 454 221 286 454 minecraft:iron_block
fill 199 286 419 219 286 419 minecraft:iron_block
fill 199 286 432 199 286 441 minecraft:gold_block
setblock 199 286 442 minecraft:iron_block
fill 199 286 455 219 286 455 minecraft:iron_block
fill 200 286 429 200 286 430 minecraft:iron_block
fill 200 286 431 200 286 432 minecraft:gold_block
fill 200 286 441 200 286 442 minecraft:gold_block
fill 200 286 458 203 291 458 minecraft:shroomlight
fill 201 286 417 203 300 417 minecraft:polished_deepslate
fill 201 286 418 217 286 418 minecraft:iron_block
fill 201 286 429 201 286 430 minecraft:gold_block
fill 201 286 443 201 286 444 minecraft:gold_block
setblock 201 286 445 minecraft:iron_block
fill 201 286 456 217 286 456 minecraft:iron_block
fill 202 286 427 203 286 427 minecraft:iron_block
fill 202 286 428 202 286 429 minecraft:gold_block
fill 202 286 444 202 286 445 minecraft:gold_block
setblock 203 286 428 minecraft:gold_block
setblock 203 286 445 minecraft:gold_block
fill 204 286 417 214 286 417 minecraft:iron_block
fill 204 286 427 205 286 427 minecraft:gold_block
fill 204 286 446 205 286 446 minecraft:gold_block
setblock 204 286 447 minecraft:iron_block
fill 204 286 457 214 286 457 minecraft:iron_block
fill 205 286 447 214 286 447 minecraft:gold_block
fill 206 286 425 208 286 425 minecraft:iron_block
fill 206 286 426 208 286 426 minecraft:gold_block
fill 207 286 416 210 291 416 minecraft:shroomlight
setblock 207 286 427 minecraft:light[level=13]
setblock 207 286 435 minecraft:light[level=13]
setblock 207 286 443 minecraft:light[level=13]
fill 209 286 425 210 287 425 minecraft:gold_block
fill 211 286 425 226 286 425 minecraft:iron_block
fill 211 286 426 214 286 426 minecraft:gold_block
fill 212 286 458 215 291 458 minecraft:shroomlight
fill 214 286 446 215 286 446 minecraft:gold_block
fill 215 286 417 215 300 417 minecraft:polished_deepslate
fill 215 286 426 226 286 426 minecraft:iron_block
setblock 215 286 427 minecraft:gold_block
setblock 215 286 435 minecraft:light[level=13]
setblock 215 286 443 minecraft:light[level=13]
fill 215 286 447 227 286 447 minecraft:iron_block
fill 215 286 457 216 289 457 minecraft:orange_stained_glass
fill 216 286 427 227 286 427 minecraft:iron_block
fill 216 286 428 217 286 428 minecraft:gold_block
fill 216 286 445 217 286 445 minecraft:gold_block
fill 216 286 446 227 286 446 minecraft:iron_block
fill 217 286 429 218 286 429 minecraft:gold_block
fill 217 286 444 218 286 444 minecraft:gold_block
fill 218 286 428 227 286 428 minecraft:iron_block
setblock 218 286 430 minecraft:gold_block
setblock 218 286 443 minecraft:gold_block
fill 218 286 445 228 286 445 minecraft:iron_block
fill 219 286 416 222 291 416 minecraft:shroomlight
fill 219 286 429 228 286 430 minecraft:iron_block
setblock 219 286 431 minecraft:gold_block
fill 219 286 441 219 286 442 minecraft:gold_block
fill 219 286 443 228 286 444 minecraft:iron_block
fill 220 286 431 228 286 431 minecraft:iron_block
fill 220 286 432 220 286 435 minecraft:gold_block
fill 220 286 438 220 286 440 minecraft:gold_block
fill 220 286 441 229 286 442 minecraft:iron_block
fill 221 286 432 229 286 435 minecraft:iron_block
fill 221 286 436 221 287 437 minecraft:gold_block
fill 221 286 438 229 286 440 minecraft:iron_block
fill 222 286 436 229 286 437 minecraft:iron_block
setblock 223 286 419 minecraft:light[level=13]
fill 224 286 458 227 291 458 minecraft:shroomlight
fill 230 286 417 230 291 420 minecraft:shroomlight
fill 230 286 429 230 291 432 minecraft:shroomlight
fill 230 286 441 230 291 444 minecraft:shroomlight
fill 230 286 453 230 291 456 minecraft:shroomlight
fill 189 287 439 189 300 441 minecraft:polished_deepslate
fill 190 287 431 196 287 443 minecraft:iron_block
fill 191 287 429 198 287 430 minecraft:iron_block
fill 191 287 444 199 287 445 minecraft:iron_block
fill 192 287 427 200 287 428 minecraft:iron_block
fill 192 287 446 200 287 447 minecraft:iron_block
fill 193 287 426 202 287 426 minecraft:iron_block
fill 193 287 448 203 287 448 minecraft:iron_block
fill 194 287 424 205 287 425 minecraft:iron_block
fill 194 287 449 207 287 450 minecraft:iron_block
fill 195 287 423 223 287 423 minecraft:iron_block
fill 195 287 451 223 287 451 minecraft:iron_block
fill 196 287 422 222 287 422 minecraft:iron_block
fill 196 287 452 222 287 452 minecraft:iron_block
fill 197 287 431 197 287 434 minecraft:iron_block
fill 197 287 435 198 287 438 minecraft:gold_block
fill 197 287 439 197 287 443 minecraft:iron_block
fill 198 287 421 220 287 421 minecraft:iron_block
setblock 198 287 431 minecraft:iron_block
fill 198 287 432 198 287 434 minecraft:gold_block
fill 198 287 439 198 287 442 minecraft:gold_block
setblock 198 287 443 minecraft:iron_block
fill 198 287 453 220 287 453 minecraft:iron_block
fill 199 287 420 219 287 420 minecraft:iron_block
setblock 199 287 429 minecraft:iron_block
fill 199 287 430 199 287 431 minecraft:gold_block
fill 199 287 442 199 287 443 minecraft:gold_block
fill 199 287 454 219 287 454 minecraft:iron_block
fill 200 287 429 200 287 430 minecraft:gold_block
fill 200 287 437 201 287 437 minecraft:gold_block
fill 200 287 443 200 287 445 minecraft:gold_block
fill 201 287 419 217 287 419 minecraft:iron_block
setblock 201 287 427 minecraft:iron_block
setblock 201 287 428 minecraft:gold_block
fill 201 287 433 202 288 433 minecraft:gold_block
fill 201 287 441 202 288 441 minecraft:gold_block
fill 201 287 445 201 287 446 minecraft:gold_block
fill 201 287 447 202 287 447 minecraft:iron_block
fill 201 287 455 217 287 455 minecraft:iron_block
fill 202 287 427 203 287 427 minecraft:gold_block
fill 202 287 446 203 287 446 minecraft:gold_block
fill 203 287 418 215 287 418 minecraft:iron_block
fill 203 287 426 205 287 426 minecraft:gold_block
fill 203 287 447 204 287 447 minecraft:gold_block
fill 203 287 456 215 287 456 minecraft:iron_block
fill 204 287 448 214 287 448 minecraft:gold_block
fill 205 287 429 205 288 430 minecraft:gold_block
fill 205 287 444 205 288 445 minecraft:gold_block
fill 206 287 424 224 287 424 minecraft:iron_block
fill 206 287 425 208 287 425 minecraft:gold_block
fill 207 287 457 209 300 457 minecraft:polished_deepslate
fill 208 287 449 211 287 449 minecraft:gold_block
fill 208 287 450 224 287 450 minecraft:iron_block
fill 209 287 428 209 287 429 minecraft:gold_block
fill 209 287 445 209 287 446 minecraft:gold_block
fill 211 287 425 213 287 425 minecraft:gold_block
fill 212 287 449 224 287 449 minecraft:iron_block
fill 213 287 417 214 300 417 minecraft:polished_deepslate
fill 213 287 429 213 288 430 minecraft:gold_block
fill 213 287 444 213 288 445 minecraft:gold_block
fill 213 287 457 214 288 457 minecraft:orange_stained_glass
fill 214 287 425 224 287 425 minecraft:iron_block
fill 214 287 426 215 287 426 minecraft:gold_block
fill 215 287 447 216 287 447 minecraft:gold_block
fill 215 287 448 225 287 448 minecraft:iron_block
fill 216 287 426 225 287 426 minecraft:iron_block
fill 216 287 427 217 287 427 minecraft:gold_block
fill 216 287 433 217 288 433 minecraft:gold_block
fill 216 287 441 217 288 441 minecraft:gold_block
fill 216 287 446 217 287 446 minecraft:gold_block
fill 216 287 456 217 289 456 minecraft:orange_stained_glass
fill 217 287 437 218 287 437 minecraft:gold_block
fill 217 287 447 226 287 447 minecraft:iron_block
fill 217 287 457 217 288 457 minecraft:orange_stained_glass
fill 218 287 427 226 287 427 minecraft:iron_block
setblock 218 287 428 minecraft:gold_block
setblock 218 287 445 minecraft:gold_block
fill 218 287 446 226 287 446 minecraft:iron_block
fill 219 287 428 226 287 428 minecraft:iron_block
fill 219 287 429 219 287 430 minecraft:gold_block
fill 219 287 443 219 287 444 minecraft:gold_block
fill 219 287 445 227 287 445 minecraft:iron_block
fill 220 287 429 227 287 430 minecraft:iron_block
fill 220 287 431 220 287 432 minecraft:gold_block
fill 220 287 441 220 287 443 minecraft:gold_block
fill 220 287 444 227 287 444 minecraft:iron_block
fill 221 287 431 228 287 432 minecraft:iron_block
fill 221 287 433 221 287 435 minecraft:gold_block
fill 221 287 438 221 287 440 minecraft:gold_block
fill 221 287 441 228 287 443 minecraft:iron_block
fill 222 287 433 228 287 440 minecraft:iron_block
fill 229 287 437 229 300 439 minecraft:polished_deepslate
fill 191 288 432 195 288 442 minecraft:iron_block
fill 192 288 429 196 288 431 minecraft:iron_block
fill 192 288 443 197 288 445 minecraft:iron_block
fill 193 288 428 198 288 428 minecraft:iron_block
fill 193 288 446 199 288 446 minecraft:iron_block
fill 194 288 426 199 288 427 minecraft:iron_block
fill 194 288 447 200 288 448 minecraft:iron_block
fill 195 288 425 202 288 425 minecraft:iron_block
fill 195 288 449 203 288 449 minecraft:iron_block
fill 196 288 424 205 288 424 minecraft:iron_block
fill 196 288 432 196 288 433 minecraft:iron_block
fill 196 288 434 196 288 440 minecraft:polished_deepslate
fill 196 288 441 196 288 442 minecraft:iron_block
fill 196 288 450 205 288 450 minecraft:iron_block
fill 197 288 423 221 288 423 minecraft:iron_block
fill 197 288 429 197 288 430 minecraft:iron_block
fill 197 288 431 197 288 434 minecraft:polished_deepslate
fill 197 288 439 197 288 442 minecraft:polished_deepslate
fill 197 288 451 221 288 451 minecraft:iron_block
fill 198 288 422 220 288 422 minecraft:iron_block
setblock 198 288 429 minecraft:iron_block
fill 198 288 430 198 288 431 minecraft:polished_deepslate
fill 198 288 437 200 288 437 minecraft:gold_block
fill 198 288 443 198 288 444 minecraft:polished_deepslate
setblock 198 288 445 minecraft:iron_block
fill 198 288 452 220 288 452 minecraft:iron_block
fill 199 288 428 199 288 429 minecraft:polished_deepslate
fill 199 288 432 201 288 432 minecraft:gold_block
fill 199 288 442 201 288 442 minecraft:gold_block
fill 199 288 444 199 288 445 minecraft:polished_deepslate
fill 200 288 421 218 288 421 minecraft:iron_block
fill 200 288 426 201 288 426 minecraft:iron_block
fill 200 288 427 200 288 428 minecraft:polished_deepslate
fill 200 288 431 200 289 431 minecraft:gold_block
fill 200 288 443 200 289 443 minecraft:gold_block
setblock 200 288 446 minecraft:polished_deepslate
fill 200 288 453 218 288 453 minecraft:iron_block
fill 201 288 420 217 288 420 minecraft:iron_block
setblock 201 288 427 minecraft:polished_deepslate
fill 201 288 447 202 288 447 minecraft:polished_deepslate
setblock 201 288 448 minecraft:iron_block
fill 201 288 454 217 288 454 minecraft:iron_block
setblock 202 288 426 minecraft:polished_deepslate
fill 202 288 448 203 288 448 minecraft:polished_deepslate
fill 203 288 425 205 288 425 minecraft:polished_deepslate
fill 203 288 428 204 289 428 minecraft:gold_block
fill 203 288 446 204 289 446 minecraft:gold_block
fill 204 288 419 214 288 419 minecraft:iron_block
fill 204 288 427 204 289 427 minecraft:gold_block
setblock 204 288 429 minecraft:gold_block
setblock 204 288 445 minecraft:gold_block
fill 204 288 447 204 289 447 minecraft:gold_block
fill 204 288 449 207 288 449 minecraft:polished_deepslate
fill 204 288 455 214 288 455 minecraft:iron_block
fill 206 288 424 213 288 424 minecraft:polished_deepslate
fill 206 288 450 212 288 450 minecraft:polished_deepslate
fill 209 288 426 209 288 428 minecraft:gold_block
fill 209 288 446 209 288 448 minecraft:gold_block
fill 212 288 449 215 288 449 minecraft:polished_deepslate
fill 213 288 450 222 288 450 minecraft:iron_block
fill 213 288 456 215 289 456 minecraft:orange_stained_glass
fill 214 288 424 222 288 424 minecraft:iron_block
fill 214 288 425 215 288 425 minecraft:polished_deepslate
fill 214 288 427 214 288 429 minecraft:gold_block
fill 214 288 445 214 288 447 minecraft:gold_block
fill 215 288 428 215 289 428 minecraft:gold_block
fill 215 288 446 215 289 446 minecraft:gold_block
fill 215 288 448 216 288 448 minecraft:polished_deepslate
fill 215 288 455 217 288 455 minecraft:orange_stained_glass
fill 216 288 425 223 288 425 minecraft:iron_block
fill 216 288 426 217 288 426 minecraft:polished_deepslate
fill 216 288 449 223 288 449 minecraft:iron_block
fill 217 288 432 219 288 432 minecraft:gold_block
fill 217 288 442 219 288 442 minecraft:gold_block
fill 217 288 447 218 288 447 minecraft:polished_deepslate
fill 217 288 448 224 288 448 minecraft:iron_block
fill 218 288 426 224 288 426 minecraft:iron_block
setblock 218 288 427 minecraft:polished_deepslate
fill 218 288 431 218 289 431 minecraft:gold_block
fill 218 288 437 220 288 437 minecraft:gold_block
fill 218 288 443 218 289 443 minecraft:gold_block
fill 218 288 446 219 288 446 minecraft:polished_deepslate
fill 219 288 427 224 288 427 minecraft:iron_block
setblock 219 288 428 minecraft:polished_deepslate
setblock 219 288 445 minecraft:polished_deepslate
fill 219 288 447 224 288 447 minecraft:iron_block
fill 220 288 428 225 288 428 minecraft:iron_block
fill 220 288 429 220 288 430 minecraft:polished_deepslate
setblock 220 288 444 minecraft:polished_deepslate
fill 220 288 445 225 288 446 minecraft:iron_block
fill 221 288 429 226 288 430 minecraft:iron_block
fill 221 288 431 221 288 432 minecraft:polished_deepslate
fill 221 288 441 221 288 443 minecraft:polished_deepslate
fill 221 288 444 226 288 444 minecraft:iron_block
fill 222 288 431 226 288 432 minecraft:iron_block
fill 222 288 433 222 288 440 minecraft:polished_deepslate
fill 222 288 441 226 288 443 minecraft:iron_block
fill 223 288 433 227 288 440 minecraft:iron_block
setblock 226 288 445 minecraft:iron_block
setblock 227 288 432 minecraft:iron_block
fill 227 288 441 227 288 442 minecraft:iron_block
fill 192 289 435 194 289 439 minecraft:iron_block
fill 192 289 445 193 300 445 minecraft:polished_deepslate
fill 193 289 431 194 289 434 minecraft:iron_block
fill 193 289 440 194 289 443 minecraft:iron_block
fill 193 289 444 193 300 444 minecraft:polished_deepslate
fill 193 289 446 194 300 446 minecraft:polished_deepslate
fill 194 289 429 196 289 430 minecraft:iron_block
fill 194 289 444 196 289 445 minecraft:iron_block
fill 194 289 447 194 300 447 minecraft:polished_deepslate
fill 195 289 427 197 289 428 minecraft:iron_block
fill 195 289 431 195 289 433 minecraft:iron_block
fill 195 289 434 195 289 440 minecraft:gold_block
fill 195 289 441 195 289 443 minecraft:iron_block
fill 195 289 446 198 289 447 minecraft:iron_block
fill 196 289 426 199 289 426 minecraft:iron_block
fill 196 289 431 196 289 433 minecraft:gold_block
fill 196 289 436 198 289 438 minecraft:gold_block
fill 196 289 441 196 289 442 minecraft:gold_block
setblock 196 289 443 minecraft:iron_block
fill 196 289 448 200 289 448 minecraft:iron_block
fill 197 289 425 201 289 425 minecraft:iron_block
setblock 197 289 429 minecraft:iron_block
fill 197 289 430 199 290 431 minecraft:gold_block
fill 197 289 443 199 290 444 minecraft:gold_block
setblock 197 289 445 minecraft:iron_block
fill 197 289 449 201 289 449 minecraft:iron_block
fill 198 289 424 202 289 424 minecraft:iron_block
setblock 198 289 427 minecraft:iron_block
fill 198 289 428 198 289 429 minecraft:gold_block
fill 198 289 432 200 289 432 minecraft:gold_block
fill 198 289 442 200 289 442 minecraft:gold_block
fill 198 289 445 198 290 445 minecraft:gold_block
fill 198 289 450 203 289 450 minecraft:iron_block
fill 199 289 423 205 289 423 minecraft:iron_block
setblock 199 289 427 minecraft:gold_block
setblock 199 289 437 minecraft:gold_block
setblock 199 289 446 minecraft:gold_block
setblock 199 289 447 minecraft:iron_block
fill 199 289 451 205 289 451 minecraft:iron_block
fill 200 289 426 204 289 426 minecraft:gold_block
setblock 200 289 447 minecraft:gold_block
fill 201 289 422 217 289 422 minecraft:iron_block
fill 201 289 448 204 289 448 minecraft:gold_block
fill 201 289 452 217 289 452 minecraft:iron_block
fill 202 289 425 203 290 425 minecraft:gold_block
fill 202 289 427 203 290 427 minecraft:gold_block
fill 202 289 447 203 290 447 minecraft:gold_block
fill 202 289 449 203 290 449 minecraft:gold_block
fill 203 289 421 215 289 421 minecraft:iron_block
fill 203 289 424 205 289 424 minecraft:gold_block
fill 203 289 453 215 289 453 minecraft:iron_block
fill 204 289 450 205 289 450 minecraft:gold_block
fill 206 289 423 212 289 423 minecraft:gold_block
fill 206 289 451 212 289 451 minecraft:gold_block
fill 207 289 420 211 289 420 minecraft:iron_block
fill 207 289 454 211 289 454 minecraft:iron_block
fill 208 289 424 210 289 426 minecraft:gold_block
fill 208 289 448 210 289 450 minecraft:gold_block
setblock 209 289 427 minecraft:gold_block
setblock 209 289 447 minecraft:gold_block
fill 213 289 423 219 289 423 minecraft:iron_block
fill 213 289 424 215 289 424 minecraft:gold_block
fill 213 289 450 215 289 450 minecraft:gold_block
fill 213 289 451 219 289 451 minecraft:iron_block
fill 214 289 426 214 289 428 minecraft:gold_block
fill 214 289 446 214 289 448 minecraft:gold_block
fill 214 289 455 216 289 455 minecraft:orange_stained_glass
setblock 214 289 457 minecraft:orange_stained_glass
fill 215 289 425 216 290 427 minecraft:gold_block
fill 215 289 447 216 290 449 minecraft:gold_block
setblock 215 289 454 minecraft:orange_stained_glass
fill 216 289 424 220 289 424 minecraft:iron_block
fill 216 289 450 220 289 450 minecraft:iron_block
fill 217 289 425 217 290 425 minecraft:gold_block
fill 217 289 448 218 289 448 minecraft:gold_block
fill 217 289 449 221 289 449 minecraft:iron_block
fill 218 289 425 221 289 425 minecraft:iron_block
setblock 218 289 426 minecraft:gold_block
fill 218 289 432 220 289 432 minecraft:gold_block
fill 218 289 442 220 289 442 minecraft:gold_block
fill 219 289 426 222 289 426 minecraft:iron_block
setblock 219 289 427 minecraft:gold_block
fill 219 289 430 221 290 431 minecraft:gold_block
fill 219 289 437 223 289 437 minecraft:gold_block
fill 219 289 443 221 290 444 minecraft:gold_block
setblock 219 289 447 minecraft:gold_block
fill 219 289 448 222 289 448 minecraft:iron_block
fill 220 289 427 223 289 427 minecraft:iron_block
setblock 220 289 428 minecraft:gold_block
fill 220 289 436 223 289 436 minecraft:gold_block
fill 220 289 438 223 289 438 minecraft:gold_block
fill 220 289 445 220 289 446 minecraft:gold_block
fill 220 289 447 223 289 447 minecraft:iron_block
fill 221 289 428 223 289 428 minecraft:iron_block
fill 221 289 429 221 290 429 minecraft:gold_block
fill 221 289 445 223 289 446 minecraft:iron_block
fill 222 289 429 224 289 430 minecraft:iron_block
fill 222 289 431 222 289 433 minecraft:gold_block
fill 222 289 441 222 289 443 minecraft:gold_block
fill 222 289 444 224 289 444 minecraft:iron_block
fill 223 289 431 225 289 433 minecraft:iron_block
fill 223 289 434 223 289 435 minecraft:gold_block
fill 223 289 439 223 289 440 minecraft:gold_block
fill 223 289 441 225 289 443 minecraft:iron_block
fill 224 289 434 225 289 440 minecraft:iron_block
setblock 224 289 445 minecraft:iron_block
fill 226 289 435 226 289 439 minecraft:iron_block
fill 194 290 437 197 290 437 minecraft:gold_block
fill 194 290 443 194 300 445 minecraft:polished_deepslate
fill 195 290 436 197 290 436 minecraft:gold_block
fill 195 290 438 197 290 438 minecraft:gold_block
fill 195 290 444 195 300 446 minecraft:polished_deepslate
fill 196 290 430 196 290 431 minecraft:gold_block
fill 196 290 443 196 290 444 minecraft:gold_block
fill 196 290 445 196 300 445 minecraft:polished_deepslate
fill 197 290 429 198 290 429 minecraft:gold_block
setblock 197 290 445 minecraft:gold_block
fill 201 290 425 201 290 426 minecraft:gold_block
fill 201 290 448 201 290 449 minecraft:gold_block
fill 202 290 424 203 290 424 minecraft:gold_block
fill 202 290 426 203 290 426 minecraft:gold_block
fill 202 290 448 203 290 448 minecraft:gold_block
fill 202 290 450 203 290 450 minecraft:gold_block
fill 208 290 423 210 290 425 minecraft:gold_block
fill 208 290 449 210 290 451 minecraft:gold_block
setblock 209 290 422 minecraft:gold_block
setblock 209 290 452 minecraft:gold_block
fill 215 290 424 216 290 424 minecraft:gold_block
fill 215 290 450 216 290 450 minecraft:gold_block
setblock 215 290 456 minecraft:orange_stained_glass
setblock 217 290 426 minecraft:gold_block
fill 217 290 448 217 290 449 minecraft:gold_block
setblock 220 290 429 minecraft:gold_block
fill 220 290 445 221 290 445 minecraft:gold_block
fill 221 290 436 223 290 438 minecraft:gold_block
fill 222 290 430 222 290 431 minecraft:gold_block
fill 222 290 443 222 290 444 minecraft:gold_block
setblock 224 290 437 minecraft:gold_block
fill 188 292 422 188 307 422 minecraft:stone
fill 188 292 423 188 292 424 minecraft:shroomlight
fill 188 292 425 188 307 425 minecraft:stone
fill 188 292 434 188 307 434 minecraft:stone
fill 188 292 435 188 292 436 minecraft:shroomlight
fill 188 292 437 188 307 437 minecraft:stone
fill 188 292 446 188 307 446 minecraft:stone
fill 188 292 447 188 292 448 minecraft:shroomlight
fill 188 292 449 188 307 449 minecraft:stone
fill 188 292 458 188 307 458 minecraft:stone
fill 189 292 458 190 292 458 minecraft:shroomlight
fill 191 292 458 191 307 458 minecraft:stone
fill 195 292 416 195 307 416 minecraft:stone
fill 196 292 416 197 292 416 minecraft:shroomlight
fill 198 292 416 198 307 416 minecraft:stone
fill 200 292 458 200 307 458 minecraft:stone
fill 201 292 458 202 292 458 minecraft:shroomlight
fill 203 292 458 203 307 458 minecraft:stone
fill 207 292 416 207 307 416 minecraft:stone
fill 208 292 416 209 292 416 minecraft:shroomlight
fill 210 292 416 210 307 416 minecraft:stone
fill 212 292 458 212 307 458 minecraft:stone
fill 213 292 458 214 292 458 minecraft:shroomlight
fill 215 292 458 215 307 458 minecraft:stone
fill 219 292 416 219 307 416 minecraft:stone
fill 220 292 416 221 292 416 minecraft:shroomlight
schedule function dropper:buildpart/100_3 1t
