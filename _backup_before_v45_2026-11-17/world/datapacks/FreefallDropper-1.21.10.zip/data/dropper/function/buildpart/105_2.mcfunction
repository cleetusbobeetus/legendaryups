setblock 458 247 455 minecraft:glowstone
setblock 458 247 457 minecraft:glowstone
setblock 459 247 448 minecraft:glowstone
setblock 459 247 450 minecraft:glowstone
setblock 459 247 452 minecraft:glowstone
setblock 459 247 454 minecraft:glowstone
setblock 459 247 456 minecraft:glowstone
fill 459 247 457 459 262 457 minecraft:iron_block
fill 460 247 437 460 262 446 minecraft:iron_block
setblock 460 247 447 minecraft:glowstone
setblock 460 247 449 minecraft:glowstone
setblock 460 247 451 minecraft:glowstone
setblock 460 247 453 minecraft:glowstone
setblock 460 247 455 minecraft:glowstone
setblock 460 247 457 minecraft:glowstone
setblock 461 247 448 minecraft:glowstone
setblock 461 247 450 minecraft:glowstone
setblock 461 247 452 minecraft:glowstone
setblock 461 247 454 minecraft:glowstone
setblock 461 247 456 minecraft:glowstone
fill 461 247 457 461 262 457 minecraft:iron_block
setblock 462 247 447 minecraft:glowstone
setblock 462 247 449 minecraft:glowstone
setblock 462 247 451 minecraft:glowstone
setblock 462 247 453 minecraft:glowstone
setblock 462 247 455 minecraft:glowstone
setblock 462 247 457 minecraft:glowstone
fill 456 248 447 456 249 447 minecraft:iron_block
fill 456 248 449 456 249 449 minecraft:iron_block
fill 456 248 451 456 249 451 minecraft:iron_block
fill 456 248 453 456 249 453 minecraft:iron_block
fill 456 248 455 456 249 455 minecraft:iron_block
fill 456 248 457 456 249 457 minecraft:iron_block
fill 457 248 448 457 249 448 minecraft:iron_block
fill 457 248 450 457 249 450 minecraft:iron_block
fill 457 248 452 457 249 452 minecraft:iron_block
fill 457 248 454 457 249 454 minecraft:iron_block
fill 457 248 456 457 249 456 minecraft:iron_block
fill 458 248 447 458 249 447 minecraft:iron_block
fill 458 248 449 458 249 449 minecraft:iron_block
fill 458 248 451 458 249 451 minecraft:iron_block
fill 458 248 453 458 249 453 minecraft:iron_block
fill 458 248 455 458 249 455 minecraft:iron_block
fill 458 248 457 458 249 457 minecraft:iron_block
fill 459 248 448 459 249 448 minecraft:iron_block
fill 459 248 450 459 249 450 minecraft:iron_block
fill 459 248 452 459 249 452 minecraft:iron_block
fill 459 248 454 459 249 454 minecraft:iron_block
fill 459 248 456 459 249 456 minecraft:iron_block
fill 460 248 447 460 249 447 minecraft:iron_block
fill 460 248 449 460 249 449 minecraft:iron_block
fill 460 248 451 460 249 451 minecraft:iron_block
fill 460 248 453 460 249 453 minecraft:iron_block
fill 460 248 455 460 249 455 minecraft:iron_block
fill 460 248 457 460 249 457 minecraft:iron_block
fill 461 248 448 461 249 448 minecraft:iron_block
fill 461 248 450 461 249 450 minecraft:iron_block
fill 461 248 452 461 249 452 minecraft:iron_block
fill 461 248 454 461 249 454 minecraft:iron_block
fill 461 248 456 461 249 456 minecraft:iron_block
fill 462 248 447 462 249 447 minecraft:iron_block
fill 462 248 449 462 249 449 minecraft:iron_block
fill 462 248 451 462 249 451 minecraft:iron_block
fill 462 248 453 462 249 453 minecraft:iron_block
fill 462 248 455 462 249 455 minecraft:iron_block
fill 462 248 457 462 249 457 minecraft:iron_block
setblock 426 249 419 minecraft:light[level=12]
setblock 426 249 427 minecraft:light[level=12]
setblock 426 249 435 minecraft:light[level=12]
setblock 426 249 443 minecraft:light[level=12]
setblock 426 249 451 minecraft:light[level=12]
setblock 434 249 419 minecraft:light[level=12]
setblock 434 249 427 minecraft:light[level=12]
setblock 434 249 435 minecraft:light[level=12]
setblock 434 249 443 minecraft:light[level=12]
setblock 434 249 451 minecraft:light[level=12]
setblock 442 249 419 minecraft:light[level=12]
setblock 442 249 427 minecraft:light[level=12]
setblock 442 249 435 minecraft:light[level=12]
setblock 442 249 443 minecraft:light[level=12]
setblock 442 249 451 minecraft:light[level=12]
setblock 450 249 419 minecraft:light[level=12]
setblock 450 249 427 minecraft:light[level=12]
setblock 450 249 435 minecraft:light[level=12]
setblock 450 249 443 minecraft:light[level=12]
setblock 450 249 451 minecraft:light[level=12]
setblock 458 249 419 minecraft:light[level=12]
setblock 458 249 427 minecraft:light[level=12]
setblock 458 249 435 minecraft:light[level=12]
setblock 458 249 443 minecraft:light[level=12]
setblock 456 250 447 minecraft:glowstone
setblock 456 250 449 minecraft:glowstone
setblock 456 250 451 minecraft:glowstone
setblock 456 250 453 minecraft:glowstone
setblock 456 250 455 minecraft:glowstone
setblock 456 250 457 minecraft:glowstone
setblock 457 250 448 minecraft:glowstone
setblock 457 250 450 minecraft:glowstone
setblock 457 250 452 minecraft:glowstone
setblock 457 250 454 minecraft:glowstone
setblock 457 250 456 minecraft:glowstone
setblock 458 250 447 minecraft:glowstone
setblock 458 250 449 minecraft:glowstone
setblock 458 250 451 minecraft:glowstone
setblock 458 250 453 minecraft:glowstone
setblock 458 250 455 minecraft:glowstone
setblock 458 250 457 minecraft:glowstone
setblock 459 250 448 minecraft:glowstone
setblock 459 250 450 minecraft:glowstone
setblock 459 250 452 minecraft:glowstone
setblock 459 250 454 minecraft:glowstone
setblock 459 250 456 minecraft:glowstone
setblock 460 250 447 minecraft:glowstone
setblock 460 250 449 minecraft:glowstone
setblock 460 250 451 minecraft:glowstone
setblock 460 250 453 minecraft:glowstone
setblock 460 250 455 minecraft:glowstone
setblock 460 250 457 minecraft:glowstone
setblock 461 250 448 minecraft:glowstone
setblock 461 250 450 minecraft:glowstone
setblock 461 250 452 minecraft:glowstone
setblock 461 250 454 minecraft:glowstone
setblock 461 250 456 minecraft:glowstone
setblock 462 250 447 minecraft:glowstone
setblock 462 250 449 minecraft:glowstone
setblock 462 250 451 minecraft:glowstone
setblock 462 250 453 minecraft:glowstone
setblock 462 250 455 minecraft:glowstone
setblock 462 250 457 minecraft:glowstone
fill 456 251 447 456 252 447 minecraft:iron_block
fill 456 251 449 456 252 449 minecraft:iron_block
fill 456 251 451 456 252 451 minecraft:iron_block
fill 456 251 453 456 252 453 minecraft:iron_block
fill 456 251 455 456 252 455 minecraft:iron_block
fill 456 251 457 456 252 457 minecraft:iron_block
fill 457 251 448 457 252 448 minecraft:iron_block
fill 457 251 450 457 252 450 minecraft:iron_block
fill 457 251 452 457 252 452 minecraft:iron_block
fill 457 251 454 457 252 454 minecraft:iron_block
fill 457 251 456 457 252 456 minecraft:iron_block
fill 458 251 447 458 252 447 minecraft:iron_block
fill 458 251 449 458 252 449 minecraft:iron_block
fill 458 251 451 458 252 451 minecraft:iron_block
fill 458 251 453 458 252 453 minecraft:iron_block
fill 458 251 455 458 252 455 minecraft:iron_block
fill 458 251 457 458 252 457 minecraft:iron_block
fill 459 251 448 459 252 448 minecraft:iron_block
fill 459 251 450 459 252 450 minecraft:iron_block
fill 459 251 452 459 252 452 minecraft:iron_block
fill 459 251 454 459 252 454 minecraft:iron_block
fill 459 251 456 459 252 456 minecraft:iron_block
fill 460 251 447 460 252 447 minecraft:iron_block
fill 460 251 449 460 252 449 minecraft:iron_block
fill 460 251 451 460 252 451 minecraft:iron_block
fill 460 251 453 460 252 453 minecraft:iron_block
fill 460 251 455 460 252 455 minecraft:iron_block
fill 460 251 457 460 252 457 minecraft:iron_block
fill 461 251 448 461 252 448 minecraft:iron_block
fill 461 251 450 461 252 450 minecraft:iron_block
fill 461 251 452 461 252 452 minecraft:iron_block
fill 461 251 454 461 252 454 minecraft:iron_block
fill 461 251 456 461 252 456 minecraft:iron_block
fill 462 251 447 462 252 447 minecraft:iron_block
fill 462 251 449 462 252 449 minecraft:iron_block
fill 462 251 451 462 252 451 minecraft:iron_block
fill 462 251 453 462 252 453 minecraft:iron_block
fill 462 251 455 462 252 455 minecraft:iron_block
fill 462 251 457 462 252 457 minecraft:iron_block
fill 423 252 422 423 265 422 minecraft:stone_bricks
fill 423 252 423 423 252 424 minecraft:glowstone
fill 423 252 425 423 265 425 minecraft:stone_bricks
fill 423 252 434 423 265 434 minecraft:stone_bricks
fill 423 252 435 423 252 436 minecraft:glowstone
fill 423 252 437 423 265 437 minecraft:stone_bricks
fill 423 252 446 423 265 446 minecraft:stone_bricks
fill 423 252 447 423 252 448 minecraft:glowstone
fill 423 252 449 423 265 449 minecraft:stone_bricks
fill 423 252 458 423 265 458 minecraft:stone_bricks
fill 424 252 458 425 252 458 minecraft:glowstone
fill 426 252 458 426 265 458 minecraft:stone_bricks
fill 430 252 416 430 265 416 minecraft:stone_bricks
fill 431 252 416 432 252 416 minecraft:glowstone
fill 433 252 416 433 265 416 minecraft:stone_bricks
fill 435 252 458 435 265 458 minecraft:stone_bricks
fill 436 252 458 437 252 458 minecraft:glowstone
fill 438 252 458 438 265 458 minecraft:stone_bricks
fill 442 252 416 442 265 416 minecraft:stone_bricks
fill 443 252 416 444 252 416 minecraft:glowstone
fill 445 252 416 445 265 416 minecraft:stone_bricks
fill 447 252 458 447 265 458 minecraft:stone_bricks
fill 448 252 458 449 252 458 minecraft:glowstone
fill 450 252 458 450 265 458 minecraft:stone_bricks
fill 454 252 416 454 265 416 minecraft:stone_bricks
fill 455 252 416 456 252 416 minecraft:glowstone
fill 457 252 416 457 265 416 minecraft:stone_bricks
fill 459 252 458 459 265 458 minecraft:stone_bricks
fill 460 252 458 461 252 458 minecraft:glowstone
fill 462 252 458 462 265 458 minecraft:stone_bricks
fill 465 252 417 465 265 417 minecraft:stone_bricks
fill 465 252 418 465 252 419 minecraft:glowstone
fill 465 252 420 465 265 420 minecraft:stone_bricks
fill 465 252 429 465 265 429 minecraft:stone_bricks
fill 465 252 430 465 252 431 minecraft:glowstone
fill 465 252 432 465 265 432 minecraft:stone_bricks
fill 465 252 441 465 265 441 minecraft:stone_bricks
fill 465 252 442 465 252 443 minecraft:glowstone
fill 465 252 444 465 265 444 minecraft:stone_bricks
fill 465 252 453 465 265 453 minecraft:stone_bricks
fill 465 252 454 465 252 455 minecraft:glowstone
fill 465 252 456 465 265 456 minecraft:stone_bricks
fill 423 253 423 423 265 424 minecraft:stone_bricks
fill 423 253 435 423 265 436 minecraft:stone_bricks
fill 423 253 447 423 265 448 minecraft:stone_bricks
fill 424 253 458 425 265 458 minecraft:stone_bricks
fill 431 253 416 432 265 416 minecraft:stone_bricks
fill 436 253 458 437 265 458 minecraft:stone_bricks
fill 443 253 416 444 265 416 minecraft:stone_bricks
fill 448 253 458 449 265 458 minecraft:stone_bricks
fill 455 253 416 456 265 416 minecraft:stone_bricks
setblock 456 253 447 minecraft:glowstone
setblock 456 253 449 minecraft:glowstone
setblock 456 253 451 minecraft:glowstone
setblock 456 253 453 minecraft:glowstone
setblock 456 253 455 minecraft:glowstone
setblock 456 253 457 minecraft:glowstone
setblock 457 253 448 minecraft:glowstone
setblock 457 253 450 minecraft:glowstone
setblock 457 253 452 minecraft:glowstone
setblock 457 253 454 minecraft:glowstone
setblock 457 253 456 minecraft:glowstone
setblock 458 253 447 minecraft:glowstone
setblock 458 253 449 minecraft:glowstone
setblock 458 253 451 minecraft:glowstone
setblock 458 253 453 minecraft:glowstone
setblock 458 253 455 minecraft:glowstone
setblock 458 253 457 minecraft:glowstone
setblock 459 253 448 minecraft:glowstone
setblock 459 253 450 minecraft:glowstone
setblock 459 253 452 minecraft:glowstone
setblock 459 253 454 minecraft:glowstone
setblock 459 253 456 minecraft:glowstone
setblock 460 253 447 minecraft:glowstone
setblock 460 253 449 minecraft:glowstone
setblock 460 253 451 minecraft:glowstone
setblock 460 253 453 minecraft:glowstone
setblock 460 253 455 minecraft:glowstone
setblock 460 253 457 minecraft:glowstone
fill 460 253 458 461 265 458 minecraft:stone_bricks
setblock 461 253 448 minecraft:glowstone
setblock 461 253 450 minecraft:glowstone
setblock 461 253 452 minecraft:glowstone
setblock 461 253 454 minecraft:glowstone
setblock 461 253 456 minecraft:glowstone
setblock 462 253 447 minecraft:glowstone
setblock 462 253 449 minecraft:glowstone
setblock 462 253 451 minecraft:glowstone
setblock 462 253 453 minecraft:glowstone
setblock 462 253 455 minecraft:glowstone
setblock 462 253 457 minecraft:glowstone
fill 465 253 418 465 265 419 minecraft:stone_bricks
fill 465 253 430 465 265 431 minecraft:stone_bricks
fill 465 253 442 465 265 443 minecraft:stone_bricks
fill 465 253 454 465 265 455 minecraft:stone_bricks
fill 456 254 447 456 255 447 minecraft:iron_block
fill 456 254 449 456 255 449 minecraft:iron_block
fill 456 254 451 456 255 451 minecraft:iron_block
fill 456 254 453 456 255 453 minecraft:iron_block
fill 456 254 455 456 255 455 minecraft:iron_block
fill 456 254 457 456 255 457 minecraft:iron_block
fill 457 254 448 457 255 448 minecraft:iron_block
fill 457 254 450 457 255 450 minecraft:iron_block
fill 457 254 452 457 255 452 minecraft:iron_block
fill 457 254 454 457 255 454 minecraft:iron_block
fill 457 254 456 457 255 456 minecraft:iron_block
fill 458 254 447 458 255 447 minecraft:iron_block
fill 458 254 449 458 255 449 minecraft:iron_block
fill 458 254 451 458 255 451 minecraft:iron_block
fill 458 254 453 458 255 453 minecraft:iron_block
fill 458 254 455 458 255 455 minecraft:iron_block
fill 458 254 457 458 255 457 minecraft:iron_block
fill 459 254 448 459 255 448 minecraft:iron_block
fill 459 254 450 459 255 450 minecraft:iron_block
fill 459 254 452 459 255 452 minecraft:iron_block
fill 459 254 454 459 255 454 minecraft:iron_block
fill 459 254 456 459 255 456 minecraft:iron_block
fill 460 254 447 460 255 447 minecraft:iron_block
fill 460 254 449 460 255 449 minecraft:iron_block
fill 460 254 451 460 255 451 minecraft:iron_block
fill 460 254 453 460 255 453 minecraft:iron_block
fill 460 254 455 460 255 455 minecraft:iron_block
fill 460 254 457 460 255 457 minecraft:iron_block
fill 461 254 448 461 255 448 minecraft:iron_block
fill 461 254 450 461 255 450 minecraft:iron_block
fill 461 254 452 461 255 452 minecraft:iron_block
fill 461 254 454 461 255 454 minecraft:iron_block
fill 461 254 456 461 255 456 minecraft:iron_block
fill 462 254 447 462 255 447 minecraft:iron_block
fill 462 254 449 462 255 449 minecraft:iron_block
fill 462 254 451 462 255 451 minecraft:iron_block
fill 462 254 453 462 255 453 minecraft:iron_block
fill 462 254 455 462 255 455 minecraft:iron_block
fill 462 254 457 462 255 457 minecraft:iron_block
setblock 456 256 447 minecraft:glowstone
setblock 456 256 449 minecraft:glowstone
setblock 456 256 451 minecraft:glowstone
setblock 456 256 453 minecraft:glowstone
setblock 456 256 455 minecraft:glowstone
setblock 456 256 457 minecraft:glowstone
setblock 457 256 448 minecraft:glowstone
setblock 457 256 450 minecraft:glowstone
setblock 457 256 452 minecraft:glowstone
setblock 457 256 454 minecraft:glowstone
setblock 457 256 456 minecraft:glowstone
setblock 458 256 447 minecraft:glowstone
setblock 458 256 449 minecraft:glowstone
setblock 458 256 451 minecraft:glowstone
setblock 458 256 453 minecraft:glowstone
setblock 458 256 455 minecraft:glowstone
setblock 458 256 457 minecraft:glowstone
setblock 459 256 448 minecraft:glowstone
setblock 459 256 450 minecraft:glowstone
setblock 459 256 452 minecraft:glowstone
setblock 459 256 454 minecraft:glowstone
setblock 459 256 456 minecraft:glowstone
setblock 460 256 447 minecraft:glowstone
setblock 460 256 449 minecraft:glowstone
setblock 460 256 451 minecraft:glowstone
setblock 460 256 453 minecraft:glowstone
setblock 460 256 455 minecraft:glowstone
setblock 460 256 457 minecraft:glowstone
setblock 461 256 448 minecraft:glowstone
setblock 461 256 450 minecraft:glowstone
setblock 461 256 452 minecraft:glowstone
setblock 461 256 454 minecraft:glowstone
setblock 461 256 456 minecraft:glowstone
setblock 462 256 447 minecraft:glowstone
setblock 462 256 449 minecraft:glowstone
setblock 462 256 451 minecraft:glowstone
setblock 462 256 453 minecraft:glowstone
setblock 462 256 455 minecraft:glowstone
setblock 462 256 457 minecraft:glowstone
setblock 426 257 419 minecraft:light[level=12]
setblock 426 257 427 minecraft:light[level=12]
setblock 426 257 435 minecraft:light[level=12]
setblock 426 257 443 minecraft:light[level=12]
setblock 426 257 451 minecraft:light[level=12]
setblock 434 257 419 minecraft:light[level=12]
setblock 434 257 427 minecraft:light[level=12]
setblock 434 257 435 minecraft:light[level=12]
setblock 434 257 443 minecraft:light[level=12]
setblock 434 257 451 minecraft:light[level=12]
setblock 442 257 419 minecraft:light[level=12]
setblock 442 257 427 minecraft:light[level=12]
setblock 442 257 435 minecraft:light[level=12]
setblock 442 257 443 minecraft:light[level=12]
setblock 442 257 451 minecraft:light[level=12]
setblock 450 257 419 minecraft:light[level=12]
setblock 450 257 427 minecraft:light[level=12]
setblock 450 257 435 minecraft:light[level=12]
setblock 450 257 443 minecraft:light[level=12]
setblock 450 257 451 minecraft:light[level=12]
fill 456 257 447 456 258 447 minecraft:iron_block
fill 456 257 449 456 258 449 minecraft:iron_block
fill 456 257 451 456 258 451 minecraft:iron_block
fill 456 257 453 456 258 453 minecraft:iron_block
fill 456 257 455 456 258 455 minecraft:iron_block
fill 456 257 457 456 258 457 minecraft:iron_block
fill 457 257 448 457 258 448 minecraft:iron_block
fill 457 257 450 457 258 450 minecraft:iron_block
fill 457 257 452 457 258 452 minecraft:iron_block
fill 457 257 454 457 258 454 minecraft:iron_block
fill 457 257 456 457 258 456 minecraft:iron_block
setblock 458 257 419 minecraft:light[level=12]
setblock 458 257 427 minecraft:light[level=12]
setblock 458 257 435 minecraft:light[level=12]
setblock 458 257 443 minecraft:light[level=12]
fill 458 257 447 458 258 447 minecraft:iron_block
fill 458 257 449 458 258 449 minecraft:iron_block
fill 458 257 451 458 258 451 minecraft:iron_block
fill 458 257 453 458 258 453 minecraft:iron_block
fill 458 257 455 458 258 455 minecraft:iron_block
fill 458 257 457 458 258 457 minecraft:iron_block
fill 459 257 448 459 258 448 minecraft:iron_block
fill 459 257 450 459 258 450 minecraft:iron_block
fill 459 257 452 459 258 452 minecraft:iron_block
fill 459 257 454 459 258 454 minecraft:iron_block
fill 459 257 456 459 258 456 minecraft:iron_block
fill 460 257 447 460 258 447 minecraft:iron_block
fill 460 257 449 460 258 449 minecraft:iron_block
fill 460 257 451 460 258 451 minecraft:iron_block
fill 460 257 453 460 258 453 minecraft:iron_block
fill 460 257 455 460 258 455 minecraft:iron_block
fill 460 257 457 460 258 457 minecraft:iron_block
fill 461 257 448 461 258 448 minecraft:iron_block
fill 461 257 450 461 258 450 minecraft:iron_block
fill 461 257 452 461 258 452 minecraft:iron_block
fill 461 257 454 461 258 454 minecraft:iron_block
fill 461 257 456 461 258 456 minecraft:iron_block
fill 462 257 447 462 258 447 minecraft:iron_block
fill 462 257 449 462 258 449 minecraft:iron_block
fill 462 257 451 462 258 451 minecraft:iron_block
fill 462 257 453 462 258 453 minecraft:iron_block
fill 462 257 455 462 258 455 minecraft:iron_block
fill 462 257 457 462 258 457 minecraft:iron_block
setblock 456 259 447 minecraft:glowstone
setblock 456 259 449 minecraft:glowstone
setblock 456 259 451 minecraft:glowstone
setblock 456 259 453 minecraft:glowstone
setblock 456 259 455 minecraft:glowstone
setblock 456 259 457 minecraft:glowstone
setblock 457 259 448 minecraft:glowstone
setblock 457 259 450 minecraft:glowstone
setblock 457 259 452 minecraft:glowstone
setblock 457 259 454 minecraft:glowstone
setblock 457 259 456 minecraft:glowstone
setblock 458 259 447 minecraft:glowstone
setblock 458 259 449 minecraft:glowstone
setblock 458 259 451 minecraft:glowstone
setblock 458 259 453 minecraft:glowstone
setblock 458 259 455 minecraft:glowstone
setblock 458 259 457 minecraft:glowstone
setblock 459 259 448 minecraft:glowstone
setblock 459 259 450 minecraft:glowstone
setblock 459 259 452 minecraft:glowstone
setblock 459 259 454 minecraft:glowstone
setblock 459 259 456 minecraft:glowstone
setblock 460 259 447 minecraft:glowstone
setblock 460 259 449 minecraft:glowstone
setblock 460 259 451 minecraft:glowstone
setblock 460 259 453 minecraft:glowstone
setblock 460 259 455 minecraft:glowstone
setblock 460 259 457 minecraft:glowstone
setblock 461 259 448 minecraft:glowstone
setblock 461 259 450 minecraft:glowstone
setblock 461 259 452 minecraft:glowstone
setblock 461 259 454 minecraft:glowstone
setblock 461 259 456 minecraft:glowstone
setblock 462 259 447 minecraft:glowstone
setblock 462 259 449 minecraft:glowstone
setblock 462 259 451 minecraft:glowstone
setblock 462 259 453 minecraft:glowstone
setblock 462 259 455 minecraft:glowstone
setblock 462 259 457 minecraft:glowstone
fill 425 260 426 425 265 428 minecraft:iron_block
fill 425 260 438 425 265 440 minecraft:iron_block
fill 425 260 450 425 265 452 minecraft:iron_block
fill 431 260 456 433 265 456 minecraft:iron_block
fill 435 260 418 437 265 418 minecraft:iron_block
fill 443 260 456 445 265 456 minecraft:iron_block
fill 447 260 418 449 265 418 minecraft:iron_block
fill 455 260 456 455 265 456 minecraft:iron_block
fill 456 260 447 456 262 447 minecraft:iron_block
fill 456 260 449 456 262 449 minecraft:iron_block
fill 456 260 451 456 262 451 minecraft:iron_block
fill 456 260 453 456 262 453 minecraft:iron_block
fill 456 260 455 456 262 455 minecraft:iron_block
fill 456 260 457 456 273 457 minecraft:iron_block
fill 457 260 448 457 262 448 minecraft:iron_block
fill 457 260 450 457 262 450 minecraft:iron_block
fill 457 260 452 457 262 452 minecraft:iron_block
fill 457 260 454 457 262 454 minecraft:iron_block
fill 457 260 456 457 265 456 minecraft:iron_block
fill 458 260 447 458 262 447 minecraft:iron_block
fill 458 260 449 458 262 449 minecraft:iron_block
fill 458 260 451 458 262 451 minecraft:iron_block
fill 458 260 453 458 262 453 minecraft:iron_block
fill 458 260 455 458 262 455 minecraft:iron_block
fill 458 260 457 458 262 457 minecraft:iron_block
fill 459 260 418 461 265 418 minecraft:iron_block
fill 459 260 448 459 262 448 minecraft:iron_block
fill 459 260 450 459 262 450 minecraft:iron_block
fill 459 260 452 459 262 452 minecraft:iron_block
fill 459 260 454 459 262 454 minecraft:iron_block
fill 459 260 456 459 262 456 minecraft:iron_block
fill 460 260 447 460 262 447 minecraft:iron_block
fill 460 260 449 460 262 449 minecraft:iron_block
fill 460 260 451 460 262 451 minecraft:iron_block
fill 460 260 453 460 262 453 minecraft:iron_block
fill 460 260 455 460 262 455 minecraft:iron_block
fill 460 260 457 460 262 457 minecraft:iron_block
fill 461 260 448 461 262 448 minecraft:iron_block
fill 461 260 450 461 262 450 minecraft:iron_block
fill 461 260 452 461 262 452 minecraft:iron_block
fill 461 260 454 461 262 454 minecraft:iron_block
fill 461 260 456 461 262 456 minecraft:iron_block
fill 462 260 447 462 262 447 minecraft:iron_block
fill 462 260 449 462 262 449 minecraft:iron_block
fill 462 260 451 463 262 451 minecraft:iron_block
fill 462 260 453 462 262 453 minecraft:iron_block
fill 462 260 455 462 262 455 minecraft:iron_block
fill 462 260 457 462 262 457 minecraft:iron_block
fill 463 260 426 463 265 428 minecraft:iron_block
fill 463 260 450 463 265 450 minecraft:iron_block
fill 463 260 452 463 265 452 minecraft:iron_block
fill 448 263 420 448 272 420 minecraft:iron_bars
fill 463 263 438 463 265 440 minecraft:iron_block
fill 463 263 451 463 265 451 minecraft:iron_block
fill 464 263 437 464 273 439 minecraft:iron_block
fill 424 265 420 424 265 425 minecraft:cobblestone
fill 424 265 432 424 265 437 minecraft:cobblestone
fill 424 265 444 424 265 449 minecraft:cobblestone
fill 424 265 456 424 265 457 minecraft:cobblestone
fill 425 265 457 428 265 457 minecraft:cobblestone
setblock 426 265 419 minecraft:light[level=12]
setblock 426 265 427 minecraft:light[level=12]
setblock 426 265 435 minecraft:light[level=12]
setblock 426 265 443 minecraft:light[level=12]
setblock 426 265 451 minecraft:light[level=12]
fill 428 265 417 433 265 417 minecraft:cobblestone
setblock 434 265 419 minecraft:light[level=12]
setblock 434 265 427 minecraft:light[level=12]
setblock 434 265 435 minecraft:light[level=12]
setblock 434 265 443 minecraft:light[level=12]
setblock 434 265 451 minecraft:light[level=12]
fill 435 265 457 440 265 457 minecraft:cobblestone
fill 440 265 417 445 265 417 minecraft:cobblestone
setblock 442 265 419 minecraft:light[level=12]
setblock 442 265 427 minecraft:light[level=12]
setblock 442 265 435 minecraft:light[level=12]
setblock 442 265 443 minecraft:light[level=12]
setblock 442 265 451 minecraft:light[level=12]
fill 447 265 457 452 265 457 minecraft:cobblestone
setblock 450 265 419 minecraft:light[level=12]
setblock 450 265 427 minecraft:light[level=12]
setblock 450 265 435 minecraft:light[level=12]
setblock 450 265 443 minecraft:light[level=12]
setblock 450 265 451 minecraft:light[level=12]
fill 452 265 417 457 265 417 minecraft:cobblestone
setblock 458 265 419 minecraft:light[level=12]
setblock 458 265 427 minecraft:light[level=12]
setblock 458 265 435 minecraft:light[level=12]
setblock 458 265 443 minecraft:light[level=12]
setblock 458 265 451 minecraft:light[level=12]
fill 459 265 457 464 265 457 minecraft:cobblestone
fill 464 265 417 464 265 422 minecraft:cobblestone
fill 464 265 429 464 265 434 minecraft:cobblestone
fill 464 265 441 464 265 446 minecraft:cobblestone
fill 464 265 453 464 265 456 minecraft:cobblestone
fill 423 266 422 423 271 425 minecraft:glowstone
fill 423 266 434 423 271 437 minecraft:glowstone
fill 423 266 446 423 271 449 minecraft:glowstone
fill 423 266 458 426 271 458 minecraft:glowstone
fill 430 266 416 433 271 416 minecraft:glowstone
fill 435 266 458 438 271 458 minecraft:glowstone
fill 442 266 416 445 271 416 minecraft:glowstone
fill 447 266 458 450 271 458 minecraft:glowstone
fill 454 266 416 457 271 416 minecraft:glowstone
fill 459 266 458 462 271 458 minecraft:glowstone
fill 465 266 417 465 271 420 minecraft:glowstone
fill 465 266 429 465 271 432 minecraft:glowstone
fill 465 266 441 465 271 444 minecraft:glowstone
fill 465 266 453 465 271 456 minecraft:glowstone
fill 423 272 422 423 285 422 minecraft:stone_bricks
fill 423 272 423 423 272 424 minecraft:glowstone
fill 423 272 425 423 285 425 minecraft:stone_bricks
fill 423 272 434 423 285 434 minecraft:stone_bricks
fill 423 272 435 423 272 436 minecraft:glowstone
fill 423 272 437 423 285 437 minecraft:stone_bricks
fill 423 272 446 423 285 446 minecraft:stone_bricks
fill 423 272 447 423 272 448 minecraft:glowstone
fill 423 272 449 423 285 449 minecraft:stone_bricks
fill 423 272 458 423 285 458 minecraft:stone_bricks
fill 424 272 458 425 272 458 minecraft:glowstone
fill 426 272 458 426 285 458 minecraft:stone_bricks
fill 430 272 416 430 285 416 minecraft:stone_bricks
fill 431 272 416 432 272 416 minecraft:glowstone
fill 433 272 416 433 285 416 minecraft:stone_bricks
fill 435 272 458 435 285 458 minecraft:stone_bricks
fill 436 272 458 437 272 458 minecraft:glowstone
fill 438 272 458 438 285 458 minecraft:stone_bricks
fill 442 272 416 442 285 416 minecraft:stone_bricks
fill 443 272 416 444 272 416 minecraft:glowstone
fill 445 272 416 445 285 416 minecraft:stone_bricks
fill 447 272 458 447 285 458 minecraft:stone_bricks
fill 448 272 458 449 272 458 minecraft:glowstone
fill 450 272 458 450 285 458 minecraft:stone_bricks
fill 454 272 416 454 285 416 minecraft:stone_bricks
fill 455 272 416 456 272 416 minecraft:glowstone
fill 457 272 416 457 285 416 minecraft:stone_bricks
fill 459 272 458 459 285 458 minecraft:stone_bricks
fill 460 272 458 461 272 458 minecraft:glowstone
fill 462 272 458 462 285 458 minecraft:stone_bricks
fill 465 272 417 465 285 417 minecraft:stone_bricks
fill 465 272 418 465 272 419 minecraft:glowstone
fill 465 272 420 465 285 420 minecraft:stone_bricks
fill 465 272 429 465 285 429 minecraft:stone_bricks
fill 465 272 430 465 272 431 minecraft:glowstone
fill 465 272 432 465 285 432 minecraft:stone_bricks
fill 465 272 441 465 285 441 minecraft:stone_bricks
fill 465 272 442 465 272 443 minecraft:glowstone
fill 465 272 444 465 285 444 minecraft:stone_bricks
fill 465 272 453 465 285 453 minecraft:stone_bricks
fill 465 272 454 465 272 455 minecraft:glowstone
fill 465 272 456 465 285 456 minecraft:stone_bricks
fill 423 273 423 423 285 424 minecraft:stone_bricks
fill 423 273 435 423 285 436 minecraft:stone_bricks
fill 423 273 447 423 285 448 minecraft:stone_bricks
fill 424 273 458 425 285 458 minecraft:stone_bricks
setblock 426 273 419 minecraft:light[level=12]
setblock 426 273 427 minecraft:light[level=12]
setblock 426 273 435 minecraft:light[level=12]
setblock 426 273 443 minecraft:light[level=12]
setblock 426 273 451 minecraft:light[level=12]
fill 431 273 416 432 285 416 minecraft:stone_bricks
setblock 434 273 419 minecraft:light[level=12]
setblock 434 273 427 minecraft:light[level=12]
setblock 434 273 435 minecraft:light[level=12]
setblock 434 273 443 minecraft:light[level=12]
setblock 434 273 451 minecraft:light[level=12]
fill 436 273 458 437 285 458 minecraft:stone_bricks
setblock 442 273 419 minecraft:light[level=12]
setblock 442 273 427 minecraft:light[level=12]
setblock 442 273 443 minecraft:light[level=12]
setblock 442 273 451 minecraft:light[level=12]
fill 443 273 416 444 285 416 minecraft:stone_bricks
fill 448 273 458 449 285 458 minecraft:stone_bricks
setblock 450 273 419 minecraft:light[level=12]
setblock 450 273 427 minecraft:light[level=12]
setblock 450 273 435 minecraft:light[level=12]
setblock 450 273 443 minecraft:light[level=12]
setblock 450 273 451 minecraft:light[level=12]
fill 455 273 416 456 285 416 minecraft:stone_bricks
setblock 458 273 419 minecraft:light[level=12]
setblock 458 273 427 minecraft:light[level=12]
setblock 458 273 435 minecraft:light[level=12]
setblock 458 273 443 minecraft:light[level=12]
setblock 458 273 451 minecraft:light[level=12]
fill 460 273 458 461 285 458 minecraft:stone_bricks
fill 465 273 418 465 285 419 minecraft:stone_bricks
fill 465 273 430 465 285 431 minecraft:stone_bricks
fill 465 273 442 465 285 443 minecraft:stone_bricks
fill 465 273 454 465 285 455 minecraft:stone_bricks
fill 433 279 436 439 279 436 minecraft:stone_bricks
fill 434 279 432 439 279 435 minecraft:stone_bricks
fill 434 279 437 439 279 440 minecraft:stone_bricks
fill 435 279 431 449 279 431 minecraft:stone_bricks
fill 435 279 441 449 279 441 minecraft:stone_bricks
fill 436 279 430 448 279 430 minecraft:stone_bricks
fill 436 279 442 448 279 442 minecraft:stone_bricks
fill 437 279 429 447 279 429 minecraft:stone_bricks
fill 437 279 443 447 279 443 minecraft:stone_bricks
fill 438 279 428 446 279 428 minecraft:stone_bricks
fill 438 279 444 446 279 444 minecraft:stone_bricks
fill 440 279 432 440 279 434 minecraft:stone_bricks
fill 440 279 438 440 279 440 minecraft:stone_bricks
fill 441 279 432 450 279 433 minecraft:stone_bricks
fill 441 279 439 450 279 440 minecraft:stone_bricks
fill 442 279 427 442 280 427 minecraft:stone_bricks
fill 442 279 445 442 280 445 minecraft:stone_bricks
fill 444 279 434 450 279 434 minecraft:stone_bricks
fill 444 279 438 450 279 438 minecraft:stone_bricks
fill 445 279 435 450 279 437 minecraft:stone_bricks
fill 451 279 436 451 280 436 minecraft:stone_bricks
fill 424 280 417 432 280 457 minecraft:cobblestone
fill 433 280 417 433 280 435 minecraft:cobblestone
fill 433 280 436 438 280 436 minecraft:stone_bricks
fill 433 280 437 433 280 457 minecraft:cobblestone
fill 434 280 417 434 280 431 minecraft:cobblestone
fill 434 280 432 434 280 435 minecraft:iron_block
fill 434 280 437 434 280 440 minecraft:iron_block
fill 434 280 441 434 280 457 minecraft:cobblestone
fill 435 280 417 435 280 430 minecraft:cobblestone
fill 435 280 431 435 280 432 minecraft:iron_block
fill 435 280 433 438 280 435 minecraft:stone_bricks
fill 435 280 437 438 280 439 minecraft:stone_bricks
fill 435 280 440 435 280 441 minecraft:iron_block
fill 435 280 442 435 280 457 minecraft:cobblestone
fill 436 280 417 436 280 429 minecraft:cobblestone
setblock 436 280 430 minecraft:iron_block
fill 436 280 431 438 280 431 minecraft:cobblestone
setblock 436 280 432 minecraft:stone_bricks
setblock 436 280 440 minecraft:stone_bricks
fill 436 280 441 438 280 441 minecraft:cobblestone
setblock 436 280 442 minecraft:iron_block
fill 436 280 443 436 280 457 minecraft:cobblestone
fill 437 280 417 437 280 428 minecraft:cobblestone
fill 437 280 429 438 280 429 minecraft:iron_block
setblock 437 280 430 minecraft:cobblestone
fill 437 280 432 438 280 432 minecraft:cobblestone
fill 437 280 440 438 280 440 minecraft:cobblestone
setblock 437 280 442 minecraft:cobblestone
fill 437 280 443 438 280 443 minecraft:iron_block
fill 437 280 444 437 280 457 minecraft:cobblestone
fill 438 280 417 441 280 427 minecraft:cobblestone
fill 438 280 428 441 280 428 minecraft:iron_block
fill 438 280 430 446 280 430 minecraft:stone_bricks
fill 438 280 442 446 280 442 minecraft:stone_bricks
fill 438 280 444 441 280 444 minecraft:iron_block
fill 438 280 445 441 280 457 minecraft:cobblestone
fill 439 280 429 445 280 429 minecraft:stone_bricks
fill 439 280 431 445 280 432 minecraft:stone_bricks
setblock 439 280 433 minecraft:cobblestone
fill 439 280 434 439 280 438 minecraft:glowstone
setblock 439 280 439 minecraft:cobblestone
fill 439 280 440 445 280 441 minecraft:stone_bricks
fill 439 280 443 445 280 443 minecraft:stone_bricks
fill 440 280 433 440 280 434 minecraft:glowstone
fill 440 280 438 440 280 439 minecraft:glowstone
fill 441 280 433 444 280 433 minecraft:glowstone
fill 441 280 439 444 280 439 minecraft:glowstone
fill 442 280 417 464 280 426 minecraft:cobblestone
setblock 442 280 428 minecraft:stone_bricks
setblock 442 280 444 minecraft:stone_bricks
fill 442 280 446 464 280 457 minecraft:cobblestone
fill 443 280 427 464 280 427 minecraft:cobblestone
fill 443 280 428 446 280 428 minecraft:iron_block
fill 443 280 444 446 280 444 minecraft:iron_block
fill 443 280 445 464 280 445 minecraft:cobblestone
fill 444 280 434 445 280 434 minecraft:glowstone
fill 444 280 438 445 280 438 minecraft:glowstone
setblock 445 280 433 minecraft:cobblestone
fill 445 280 435 445 280 437 minecraft:glowstone
setblock 445 280 439 minecraft:cobblestone
fill 446 280 429 447 280 429 minecraft:iron_block
fill 446 280 431 447 280 432 minecraft:cobblestone
fill 446 280 433 449 280 439 minecraft:stone_bricks
fill 446 280 440 447 280 441 minecraft:cobblestone
fill 446 280 443 447 280 443 minecraft:iron_block
fill 447 280 428 464 280 428 minecraft:cobblestone
setblock 447 280 430 minecraft:cobblestone
setblock 447 280 442 minecraft:cobblestone
fill 447 280 444 464 280 444 minecraft:cobblestone
fill 448 280 429 464 280 429 minecraft:cobblestone
setblock 448 280 430 minecraft:iron_block
setblock 448 280 431 minecraft:cobblestone
setblock 448 280 432 minecraft:stone_bricks
setblock 448 280 440 minecraft:stone_bricks
setblock 448 280 441 minecraft:cobblestone
setblock 448 280 442 minecraft:iron_block
fill 448 280 443 464 280 443 minecraft:cobblestone
fill 449 280 430 464 280 430 minecraft:cobblestone
fill 449 280 431 449 280 432 minecraft:iron_block
fill 449 280 440 449 280 441 minecraft:iron_block
fill 449 280 442 464 280 442 minecraft:cobblestone
fill 450 280 431 464 280 431 minecraft:cobblestone
fill 450 280 432 450 280 435 minecraft:iron_block
setblock 450 280 436 minecraft:stone_bricks
fill 450 280 437 450 280 440 minecraft:iron_block
fill 450 280 441 464 280 441 minecraft:cobblestone
fill 451 280 432 464 280 435 minecraft:cobblestone
fill 451 280 437 464 280 440 minecraft:cobblestone
fill 452 280 436 464 280 436 minecraft:cobblestone
setblock 426 281 419 minecraft:light[level=12]
setblock 426 281 427 minecraft:light[level=12]
setblock 426 281 435 minecraft:light[level=12]
setblock 426 281 443 minecraft:light[level=12]
setblock 426 281 451 minecraft:light[level=12]
setblock 434 281 419 minecraft:light[level=12]
setblock 434 281 427 minecraft:light[level=12]
setblock 434 281 435 minecraft:light[level=12]
setblock 434 281 443 minecraft:light[level=12]
setblock 434 281 451 minecraft:light[level=12]
setblock 442 281 419 minecraft:light[level=12]
setblock 442 281 427 minecraft:light[level=12]
setblock 442 281 443 minecraft:light[level=12]
setblock 442 281 451 minecraft:light[level=12]
setblock 450 281 419 minecraft:light[level=12]
setblock 450 281 427 minecraft:light[level=12]
setblock 450 281 435 minecraft:light[level=12]
setblock 450 281 443 minecraft:light[level=12]
setblock 450 281 451 minecraft:light[level=12]
setblock 458 281 419 minecraft:light[level=12]
setblock 458 281 427 minecraft:light[level=12]
setblock 458 281 435 minecraft:light[level=12]
setblock 458 281 443 minecraft:light[level=12]
setblock 458 281 451 minecraft:light[level=12]
fill 424 284 417 426 300 417 minecraft:iron_block
fill 424 284 423 432 284 429 minecraft:iron_block
fill 424 284 439 424 300 441 minecraft:iron_block
fill 424 284 451 424 300 453 minecraft:iron_block
fill 425 284 438 425 285 440 minecraft:iron_block
fill 425 284 450 425 285 452 minecraft:iron_block
fill 430 284 457 432 300 457 minecraft:iron_block
fill 431 284 456 433 285 456 minecraft:iron_block
fill 435 284 418 437 285 418 minecraft:iron_block
fill 436 284 417 438 300 417 minecraft:iron_block
fill 441 284 417 449 284 425 minecraft:iron_block
fill 442 284 457 444 300 457 minecraft:iron_block
fill 443 284 456 445 285 456 minecraft:iron_block
fill 450 284 417 450 300 417 minecraft:iron_block
fill 454 284 457 456 300 457 minecraft:iron_block
fill 455 284 456 457 285 456 minecraft:iron_block
fill 459 284 418 461 285 418 minecraft:iron_block
fill 460 284 417 462 300 417 minecraft:iron_block
fill 463 284 426 463 285 428 minecraft:iron_block
fill 463 284 438 463 285 440 minecraft:iron_block
fill 463 284 450 463 285 452 minecraft:iron_block
fill 464 284 425 464 300 427 minecraft:iron_block
fill 464 284 437 464 300 439 minecraft:iron_block
fill 464 284 449 464 300 451 minecraft:iron_block
fill 424 285 420 424 285 425 minecraft:cobblestone
fill 424 285 426 432 285 429 minecraft:iron_block
fill 424 285 432 424 285 437 minecraft:cobblestone
fill 424 285 444 424 285 449 minecraft:cobblestone
fill 424 285 456 424 285 457 minecraft:cobblestone
fill 425 285 423 432 285 425 minecraft:iron_block
fill 425 285 457 428 285 457 minecraft:cobblestone
fill 428 285 417 433 285 417 minecraft:cobblestone
fill 435 285 457 440 285 457 minecraft:cobblestone
fill 440 285 417 445 285 417 minecraft:cobblestone
fill 441 285 418 449 285 425 minecraft:iron_block
fill 446 285 417 449 285 417 minecraft:iron_block
fill 447 285 457 452 285 457 minecraft:cobblestone
fill 452 285 417 457 285 417 minecraft:cobblestone
fill 459 285 457 464 285 457 minecraft:cobblestone
fill 464 285 417 464 285 422 minecraft:cobblestone
fill 464 285 429 464 285 434 minecraft:cobblestone
fill 464 285 441 464 285 446 minecraft:cobblestone
fill 464 285 453 464 285 456 minecraft:cobblestone
fill 423 286 422 423 291 425 minecraft:glowstone
fill 423 286 434 423 291 437 minecraft:glowstone
fill 423 286 446 423 291 449 minecraft:glowstone
fill 423 286 458 426 291 458 minecraft:glowstone
setblock 424 286 423 minecraft:glowstone
fill 424 286 424 424 298 424 minecraft:iron_block
setblock 424 286 425 minecraft:glowstone
fill 424 286 426 424 298 426 minecraft:iron_block
setblock 424 286 427 minecraft:glowstone
fill 424 286 428 424 300 428 minecraft:iron_block
setblock 424 286 429 minecraft:glowstone
fill 425 286 423 425 298 423 minecraft:iron_block
setblock 425 286 424 minecraft:glowstone
fill 425 286 425 425 298 425 minecraft:iron_block
setblock 425 286 426 minecraft:glowstone
fill 425 286 427 425 298 427 minecraft:iron_block
setblock 425 286 428 minecraft:glowstone
fill 425 286 429 425 298 429 minecraft:iron_block
setblock 426 286 423 minecraft:glowstone
fill 426 286 424 426 298 424 minecraft:iron_block
setblock 426 286 425 minecraft:glowstone
fill 426 286 426 426 298 426 minecraft:iron_block
setblock 426 286 427 minecraft:glowstone
fill 426 286 428 426 298 428 minecraft:iron_block
setblock 426 286 429 minecraft:glowstone
fill 427 286 423 427 298 423 minecraft:iron_block
setblock 427 286 424 minecraft:glowstone
fill 427 286 425 427 298 425 minecraft:iron_block
setblock 427 286 426 minecraft:glowstone
fill 427 286 427 427 298 427 minecraft:iron_block
setblock 427 286 428 minecraft:glowstone
fill 427 286 429 427 298 429 minecraft:iron_block
setblock 428 286 423 minecraft:glowstone
fill 428 286 424 428 298 424 minecraft:iron_block
setblock 428 286 425 minecraft:glowstone
fill 428 286 426 428 298 426 minecraft:iron_block
setblock 428 286 427 minecraft:glowstone
fill 428 286 428 428 298 428 minecraft:iron_block
setblock 428 286 429 minecraft:glowstone
fill 429 286 423 429 298 423 minecraft:iron_block
setblock 429 286 424 minecraft:glowstone
fill 429 286 425 429 298 425 minecraft:iron_block
setblock 429 286 426 minecraft:glowstone
fill 429 286 427 429 298 427 minecraft:iron_block
setblock 429 286 428 minecraft:glowstone
fill 429 286 429 429 298 429 minecraft:iron_block
fill 430 286 416 433 291 416 minecraft:glowstone
setblock 430 286 423 minecraft:glowstone
fill 430 286 424 430 298 424 minecraft:iron_block
setblock 430 286 425 minecraft:glowstone
fill 430 286 426 430 298 426 minecraft:iron_block
setblock 430 286 427 minecraft:glowstone
fill 430 286 428 430 298 428 minecraft:iron_block
setblock 430 286 429 minecraft:glowstone
fill 431 286 423 431 298 423 minecraft:iron_block
setblock 431 286 424 minecraft:glowstone
fill 431 286 425 431 298 425 minecraft:iron_block
setblock 431 286 426 minecraft:glowstone
fill 431 286 427 431 298 427 minecraft:iron_block
setblock 431 286 428 minecraft:glowstone
fill 431 286 429 431 298 429 minecraft:iron_block
setblock 432 286 423 minecraft:glowstone
fill 432 286 424 432 298 424 minecraft:iron_block
setblock 432 286 425 minecraft:glowstone
fill 432 286 426 432 298 426 minecraft:iron_block
setblock 432 286 427 minecraft:glowstone
fill 432 286 428 432 298 428 minecraft:iron_block
setblock 432 286 429 minecraft:glowstone
fill 435 286 458 438 291 458 minecraft:glowstone
fill 441 286 417 441 300 417 minecraft:iron_block
setblock 441 286 418 minecraft:glowstone
fill 441 286 419 441 300 419 minecraft:iron_block
setblock 441 286 420 minecraft:glowstone
fill 441 286 421 441 300 421 minecraft:iron_block
setblock 441 286 422 minecraft:glowstone
fill 441 286 423 441 300 423 minecraft:iron_block
setblock 441 286 424 minecraft:glowstone
fill 441 286 425 441 300 425 minecraft:iron_block
fill 442 286 416 442 286 417 minecraft:glowstone
fill 442 286 418 442 300 418 minecraft:iron_block
setblock 442 286 419 minecraft:glowstone
fill 442 286 420 442 300 420 minecraft:iron_block
setblock 442 286 421 minecraft:glowstone
fill 442 286 422 442 300 422 minecraft:iron_block
setblock 442 286 423 minecraft:glowstone
fill 442 286 424 442 300 424 minecraft:iron_block
setblock 442 286 425 minecraft:glowstone
fill 443 286 416 445 291 416 minecraft:glowstone
fill 443 286 417 443 300 417 minecraft:iron_block
setblock 443 286 418 minecraft:glowstone
fill 443 286 419 443 300 419 minecraft:iron_block
setblock 443 286 420 minecraft:glowstone
fill 443 286 421 443 300 421 minecraft:iron_block
setblock 443 286 422 minecraft:glowstone
fill 443 286 423 443 300 423 minecraft:iron_block
setblock 443 286 424 minecraft:glowstone
fill 443 286 425 443 300 425 minecraft:iron_block
setblock 444 286 417 minecraft:glowstone
fill 444 286 418 444 300 418 minecraft:iron_block
setblock 444 286 419 minecraft:glowstone
fill 444 286 420 444 300 420 minecraft:iron_block
setblock 444 286 421 minecraft:glowstone
fill 444 286 422 444 300 422 minecraft:iron_block
setblock 444 286 423 minecraft:glowstone
fill 444 286 424 444 300 424 minecraft:iron_block
setblock 444 286 425 minecraft:glowstone
fill 445 286 417 445 300 417 minecraft:iron_block
setblock 445 286 418 minecraft:glowstone
fill 445 286 419 445 300 419 minecraft:iron_block
setblock 445 286 420 minecraft:glowstone
fill 445 286 421 445 300 421 minecraft:iron_block
setblock 445 286 422 minecraft:glowstone
fill 445 286 423 445 300 423 minecraft:iron_block
setblock 445 286 424 minecraft:glowstone
fill 445 286 425 445 300 425 minecraft:iron_block
setblock 446 286 417 minecraft:glowstone
fill 446 286 418 446 300 418 minecraft:iron_block
setblock 446 286 419 minecraft:glowstone
fill 446 286 420 446 300 420 minecraft:iron_block
setblock 446 286 421 minecraft:glowstone
fill 446 286 422 446 300 422 minecraft:iron_block
setblock 446 286 423 minecraft:glowstone
fill 446 286 424 446 300 424 minecraft:iron_block
setblock 446 286 425 minecraft:glowstone
fill 447 286 417 447 300 417 minecraft:iron_block
setblock 447 286 418 minecraft:glowstone
fill 447 286 419 447 300 419 minecraft:iron_block
setblock 447 286 420 minecraft:glowstone
fill 447 286 421 447 300 421 minecraft:iron_block
setblock 447 286 422 minecraft:glowstone
fill 447 286 423 447 300 423 minecraft:iron_block
setblock 447 286 424 minecraft:glowstone
fill 447 286 425 447 300 425 minecraft:iron_block
fill 447 286 458 450 291 458 minecraft:glowstone
setblock 448 286 417 minecraft:glowstone
fill 448 286 418 448 300 418 minecraft:iron_block
setblock 448 286 419 minecraft:glowstone
fill 448 286 420 448 300 420 minecraft:iron_block
setblock 448 286 421 minecraft:glowstone
fill 448 286 422 448 300 422 minecraft:iron_block
setblock 448 286 423 minecraft:glowstone
fill 448 286 424 448 300 424 minecraft:iron_block
setblock 448 286 425 minecraft:glowstone
fill 449 286 417 449 300 417 minecraft:iron_block
setblock 449 286 418 minecraft:glowstone
fill 449 286 419 449 300 419 minecraft:iron_block
setblock 449 286 420 minecraft:glowstone
fill 449 286 421 449 300 421 minecraft:iron_block
setblock 449 286 422 minecraft:glowstone
fill 449 286 423 449 300 423 minecraft:iron_block
setblock 449 286 424 minecraft:glowstone
fill 449 286 425 449 300 425 minecraft:iron_block
fill 454 286 416 457 291 416 minecraft:glowstone
fill 459 286 458 462 291 458 minecraft:glowstone
fill 465 286 417 465 291 420 minecraft:glowstone
fill 465 286 429 465 291 432 minecraft:glowstone
fill 465 286 441 465 291 444 minecraft:glowstone
fill 465 286 453 465 291 456 minecraft:glowstone
fill 424 287 423 424 288 423 minecraft:iron_block
fill 424 287 425 424 288 425 minecraft:iron_block
fill 424 287 427 424 288 427 minecraft:iron_block
fill 424 287 429 424 288 429 minecraft:iron_block
fill 425 287 424 425 288 424 minecraft:iron_block
fill 425 287 426 425 288 426 minecraft:iron_block
fill 425 287 428 425 288 428 minecraft:iron_block
fill 426 287 423 426 288 423 minecraft:iron_block
fill 426 287 425 426 288 425 minecraft:iron_block
fill 426 287 427 426 288 427 minecraft:iron_block
fill 426 287 429 426 288 429 minecraft:iron_block
fill 427 287 424 427 288 424 minecraft:iron_block
fill 427 287 426 427 288 426 minecraft:iron_block
fill 427 287 428 427 288 428 minecraft:iron_block
fill 428 287 423 428 288 423 minecraft:iron_block
fill 428 287 425 428 288 425 minecraft:iron_block
fill 428 287 427 428 288 427 minecraft:iron_block
fill 428 287 429 428 288 429 minecraft:iron_block
fill 429 287 424 429 288 424 minecraft:iron_block
fill 429 287 426 429 288 426 minecraft:iron_block
fill 429 287 428 429 288 428 minecraft:iron_block
fill 430 287 423 430 288 423 minecraft:iron_block
fill 430 287 425 430 288 425 minecraft:iron_block
fill 430 287 427 430 288 427 minecraft:iron_block
fill 430 287 429 430 288 429 minecraft:iron_block
fill 431 287 424 431 288 424 minecraft:iron_block
fill 431 287 426 431 288 426 minecraft:iron_block
fill 431 287 428 431 288 428 minecraft:iron_block
fill 432 287 423 432 288 423 minecraft:iron_block
fill 432 287 425 432 288 425 minecraft:iron_block
fill 432 287 427 432 288 427 minecraft:iron_block
fill 432 287 429 432 288 429 minecraft:iron_block
fill 441 287 418 441 288 418 minecraft:iron_block
fill 441 287 420 441 288 420 minecraft:iron_block
fill 441 287 422 441 288 422 minecraft:iron_block
fill 441 287 424 441 288 424 minecraft:iron_block
fill 442 287 416 442 291 416 minecraft:glowstone
fill 442 287 417 442 288 417 minecraft:iron_block
fill 442 287 419 442 288 419 minecraft:iron_block
fill 442 287 421 442 288 421 minecraft:iron_block
fill 442 287 423 442 288 423 minecraft:iron_block
fill 442 287 425 442 288 425 minecraft:iron_block
fill 443 287 418 443 288 418 minecraft:iron_block
fill 443 287 420 443 288 420 minecraft:iron_block
fill 443 287 422 443 288 422 minecraft:iron_block
fill 443 287 424 443 288 424 minecraft:iron_block
fill 444 287 417 444 288 417 minecraft:iron_block
fill 444 287 419 444 288 419 minecraft:iron_block
fill 444 287 421 444 288 421 minecraft:iron_block
fill 444 287 423 444 288 423 minecraft:iron_block
fill 444 287 425 444 288 425 minecraft:iron_block
fill 445 287 418 445 288 418 minecraft:iron_block
fill 445 287 420 445 288 420 minecraft:iron_block
fill 445 287 422 445 288 422 minecraft:iron_block
fill 445 287 424 445 288 424 minecraft:iron_block
fill 446 287 417 446 288 417 minecraft:iron_block
fill 446 287 419 446 288 419 minecraft:iron_block
fill 446 287 421 446 288 421 minecraft:iron_block
fill 446 287 423 446 288 423 minecraft:iron_block
fill 446 287 425 446 288 425 minecraft:iron_block
fill 447 287 418 447 288 418 minecraft:iron_block
fill 447 287 420 447 288 420 minecraft:iron_block
fill 447 287 422 447 288 422 minecraft:iron_block
fill 447 287 424 447 288 424 minecraft:iron_block
fill 448 287 417 448 288 417 minecraft:iron_block
fill 448 287 419 448 288 419 minecraft:iron_block
fill 448 287 421 448 288 421 minecraft:iron_block
fill 448 287 423 448 288 423 minecraft:iron_block
fill 448 287 425 448 288 425 minecraft:iron_block
fill 449 287 418 449 288 418 minecraft:iron_block
fill 449 287 420 449 288 420 minecraft:iron_block
fill 449 287 422 449 288 422 minecraft:iron_block
fill 449 287 424 449 288 424 minecraft:iron_block
setblock 424 289 423 minecraft:glowstone
setblock 424 289 425 minecraft:glowstone
setblock 424 289 427 minecraft:glowstone
setblock 424 289 429 minecraft:glowstone
setblock 425 289 424 minecraft:glowstone
setblock 425 289 426 minecraft:glowstone
setblock 425 289 428 minecraft:glowstone
setblock 426 289 419 minecraft:light[level=12]
setblock 426 289 423 minecraft:glowstone
setblock 426 289 425 minecraft:glowstone
setblock 426 289 427 minecraft:glowstone
setblock 426 289 429 minecraft:glowstone
setblock 426 289 435 minecraft:light[level=12]
setblock 426 289 443 minecraft:light[level=12]
setblock 426 289 451 minecraft:light[level=12]
setblock 427 289 424 minecraft:glowstone
setblock 427 289 426 minecraft:glowstone
setblock 427 289 428 minecraft:glowstone
setblock 428 289 423 minecraft:glowstone
setblock 428 289 425 minecraft:glowstone
setblock 428 289 427 minecraft:glowstone
setblock 428 289 429 minecraft:glowstone
setblock 429 289 424 minecraft:glowstone
setblock 429 289 426 minecraft:glowstone
setblock 429 289 428 minecraft:glowstone
setblock 430 289 423 minecraft:glowstone
setblock 430 289 425 minecraft:glowstone
setblock 430 289 427 minecraft:glowstone
setblock 430 289 429 minecraft:glowstone
setblock 431 289 424 minecraft:glowstone
setblock 431 289 426 minecraft:glowstone
setblock 431 289 428 minecraft:glowstone
setblock 432 289 423 minecraft:glowstone
setblock 432 289 425 minecraft:glowstone
setblock 432 289 427 minecraft:glowstone
setblock 432 289 429 minecraft:glowstone
setblock 434 289 419 minecraft:light[level=12]
setblock 434 289 427 minecraft:light[level=12]
setblock 434 289 435 minecraft:light[level=12]
setblock 434 289 443 minecraft:light[level=12]
setblock 434 289 451 minecraft:light[level=12]
setblock 441 289 418 minecraft:glowstone
setblock 441 289 420 minecraft:glowstone
setblock 441 289 422 minecraft:glowstone
setblock 441 289 424 minecraft:glowstone
setblock 442 289 417 minecraft:glowstone
setblock 442 289 419 minecraft:glowstone
setblock 442 289 421 minecraft:glowstone
setblock 442 289 423 minecraft:glowstone
setblock 442 289 425 minecraft:glowstone
setblock 442 289 427 minecraft:light[level=12]
setblock 442 289 443 minecraft:light[level=12]
setblock 442 289 451 minecraft:light[level=12]
setblock 443 289 418 minecraft:glowstone
setblock 443 289 420 minecraft:glowstone
setblock 443 289 422 minecraft:glowstone
setblock 443 289 424 minecraft:glowstone
setblock 444 289 417 minecraft:glowstone
setblock 444 289 419 minecraft:glowstone
setblock 444 289 421 minecraft:glowstone
setblock 444 289 423 minecraft:glowstone
setblock 444 289 425 minecraft:glowstone
setblock 445 289 418 minecraft:glowstone
setblock 445 289 420 minecraft:glowstone
setblock 445 289 422 minecraft:glowstone
setblock 445 289 424 minecraft:glowstone
setblock 446 289 417 minecraft:glowstone
setblock 446 289 419 minecraft:glowstone
setblock 446 289 421 minecraft:glowstone
setblock 446 289 423 minecraft:glowstone
setblock 446 289 425 minecraft:glowstone
setblock 447 289 418 minecraft:glowstone
setblock 447 289 420 minecraft:glowstone
setblock 447 289 422 minecraft:glowstone
setblock 447 289 424 minecraft:glowstone
setblock 448 289 417 minecraft:glowstone
setblock 448 289 419 minecraft:glowstone
setblock 448 289 421 minecraft:glowstone
setblock 448 289 423 minecraft:glowstone
setblock 448 289 425 minecraft:glowstone
setblock 449 289 418 minecraft:glowstone
setblock 449 289 420 minecraft:glowstone
setblock 449 289 422 minecraft:glowstone
setblock 449 289 424 minecraft:glowstone
setblock 450 289 419 minecraft:light[level=12]
setblock 450 289 427 minecraft:light[level=12]
setblock 450 289 435 minecraft:light[level=12]
setblock 450 289 443 minecraft:light[level=12]
setblock 450 289 451 minecraft:light[level=12]
fill 457 289 436 457 300 436 minecraft:iron_bars
setblock 458 289 419 minecraft:light[level=12]
setblock 458 289 427 minecraft:light[level=12]
setblock 458 289 435 minecraft:light[level=12]
setblock 458 289 443 minecraft:light[level=12]
setblock 458 289 451 minecraft:light[level=12]
fill 424 290 423 424 291 423 minecraft:iron_block
fill 424 290 425 424 291 425 minecraft:iron_block
fill 424 290 427 424 291 427 minecraft:iron_block
fill 424 290 429 424 291 429 minecraft:iron_block
fill 425 290 424 425 291 424 minecraft:iron_block
fill 425 290 426 425 291 426 minecraft:iron_block
fill 425 290 428 425 291 428 minecraft:iron_block
fill 426 290 423 426 291 423 minecraft:iron_block
fill 426 290 425 426 291 425 minecraft:iron_block
fill 426 290 427 426 291 427 minecraft:iron_block
fill 426 290 429 426 291 429 minecraft:iron_block
fill 427 290 424 427 291 424 minecraft:iron_block
fill 427 290 426 427 291 426 minecraft:iron_block
fill 427 290 428 427 291 428 minecraft:iron_block
fill 428 290 423 428 291 423 minecraft:iron_block
fill 428 290 425 428 291 425 minecraft:iron_block
fill 428 290 427 428 291 427 minecraft:iron_block
fill 428 290 429 428 291 429 minecraft:iron_block
fill 429 290 424 429 291 424 minecraft:iron_block
fill 429 290 426 429 291 426 minecraft:iron_block
fill 429 290 428 429 291 428 minecraft:iron_block
fill 430 290 423 430 291 423 minecraft:iron_block
fill 430 290 425 430 291 425 minecraft:iron_block
fill 430 290 427 430 291 427 minecraft:iron_block
fill 430 290 429 430 291 429 minecraft:iron_block
fill 431 290 424 431 291 424 minecraft:iron_block
fill 431 290 426 431 291 426 minecraft:iron_block
fill 431 290 428 431 291 428 minecraft:iron_block
fill 432 290 423 432 291 423 minecraft:iron_block
fill 432 290 425 432 291 425 minecraft:iron_block
fill 432 290 427 432 291 427 minecraft:iron_block
fill 432 290 429 432 291 429 minecraft:iron_block
fill 441 290 418 441 291 418 minecraft:iron_block
fill 441 290 420 441 291 420 minecraft:iron_block
fill 441 290 422 441 291 422 minecraft:iron_block
fill 441 290 424 441 291 424 minecraft:iron_block
fill 442 290 417 442 291 417 minecraft:iron_block
fill 442 290 419 442 291 419 minecraft:iron_block
fill 442 290 421 442 291 421 minecraft:iron_block
fill 442 290 423 442 291 423 minecraft:iron_block
fill 442 290 425 442 291 425 minecraft:iron_block
fill 443 290 418 443 291 418 minecraft:iron_block
fill 443 290 420 443 291 420 minecraft:iron_block
fill 443 290 422 443 291 422 minecraft:iron_block
fill 443 290 424 443 291 424 minecraft:iron_block
fill 444 290 417 444 291 417 minecraft:iron_block
fill 444 290 419 444 291 419 minecraft:iron_block
fill 444 290 421 444 291 421 minecraft:iron_block
fill 444 290 423 444 291 423 minecraft:iron_block
fill 444 290 425 444 291 425 minecraft:iron_block
fill 445 290 418 445 291 418 minecraft:iron_block
fill 445 290 420 445 291 420 minecraft:iron_block
fill 445 290 422 445 291 422 minecraft:iron_block
fill 445 290 424 445 291 424 minecraft:iron_block
fill 446 290 417 446 291 417 minecraft:iron_block
fill 446 290 419 446 291 419 minecraft:iron_block
fill 446 290 421 446 291 421 minecraft:iron_block
fill 446 290 423 446 291 423 minecraft:iron_block
fill 446 290 425 446 291 425 minecraft:iron_block
fill 447 290 418 447 291 418 minecraft:iron_block
fill 447 290 420 447 291 420 minecraft:iron_block
fill 447 290 422 447 291 422 minecraft:iron_block
fill 447 290 424 447 291 424 minecraft:iron_block
fill 448 290 417 448 291 417 minecraft:iron_block
fill 448 290 419 448 291 419 minecraft:iron_block
fill 448 290 421 448 291 421 minecraft:iron_block
fill 448 290 423 448 291 423 minecraft:iron_block
fill 448 290 425 448 291 425 minecraft:iron_block
fill 449 290 418 449 291 418 minecraft:iron_block
fill 449 290 420 449 291 420 minecraft:iron_block
fill 449 290 422 449 291 422 minecraft:iron_block
fill 449 290 424 449 291 424 minecraft:iron_block
fill 423 292 422 423 307 422 minecraft:stone_bricks
fill 423 292 423 423 292 424 minecraft:glowstone
fill 423 292 425 423 307 425 minecraft:stone_bricks
fill 423 292 434 423 307 434 minecraft:stone_bricks
fill 423 292 435 423 292 436 minecraft:glowstone
fill 423 292 437 423 307 437 minecraft:stone_bricks
fill 423 292 446 423 307 446 minecraft:stone_bricks
fill 423 292 447 423 292 448 minecraft:glowstone
fill 423 292 449 423 307 449 minecraft:stone_bricks
fill 423 292 458 423 307 458 minecraft:stone_bricks
setblock 424 292 423 minecraft:glowstone
setblock 424 292 425 minecraft:glowstone
setblock 424 292 427 minecraft:glowstone
setblock 424 292 429 minecraft:glowstone
fill 424 292 458 425 292 458 minecraft:glowstone
setblock 425 292 424 minecraft:glowstone
setblock 425 292 426 minecraft:glowstone
setblock 425 292 428 minecraft:glowstone
setblock 426 292 423 minecraft:glowstone
setblock 426 292 425 minecraft:glowstone
setblock 426 292 427 minecraft:glowstone
setblock 426 292 429 minecraft:glowstone
fill 426 292 458 426 307 458 minecraft:stone_bricks
setblock 427 292 424 minecraft:glowstone
setblock 427 292 426 minecraft:glowstone
setblock 427 292 428 minecraft:glowstone
setblock 428 292 423 minecraft:glowstone
setblock 428 292 425 minecraft:glowstone
setblock 428 292 427 minecraft:glowstone
setblock 428 292 429 minecraft:glowstone
setblock 429 292 424 minecraft:glowstone
setblock 429 292 426 minecraft:glowstone
setblock 429 292 428 minecraft:glowstone
fill 430 292 416 430 307 416 minecraft:stone_bricks
setblock 430 292 423 minecraft:glowstone
setblock 430 292 425 minecraft:glowstone
setblock 430 292 427 minecraft:glowstone
setblock 430 292 429 minecraft:glowstone
fill 431 292 416 432 292 416 minecraft:glowstone
setblock 431 292 424 minecraft:glowstone
setblock 431 292 426 minecraft:glowstone
setblock 431 292 428 minecraft:glowstone
setblock 432 292 423 minecraft:glowstone
setblock 432 292 425 minecraft:glowstone
setblock 432 292 427 minecraft:glowstone
setblock 432 292 429 minecraft:glowstone
fill 433 292 416 433 307 416 minecraft:stone_bricks
fill 435 292 458 435 307 458 minecraft:stone_bricks
fill 436 292 458 437 292 458 minecraft:glowstone
fill 438 292 458 438 307 458 minecraft:stone_bricks
setblock 441 292 418 minecraft:glowstone
setblock 441 292 420 minecraft:glowstone
setblock 441 292 422 minecraft:glowstone
setblock 441 292 424 minecraft:glowstone
fill 442 292 416 442 307 416 minecraft:stone_bricks
setblock 442 292 417 minecraft:glowstone
setblock 442 292 419 minecraft:glowstone
setblock 442 292 421 minecraft:glowstone
setblock 442 292 423 minecraft:glowstone
setblock 442 292 425 minecraft:glowstone
fill 443 292 416 444 292 416 minecraft:glowstone
setblock 443 292 418 minecraft:glowstone
setblock 443 292 420 minecraft:glowstone
setblock 443 292 422 minecraft:glowstone
setblock 443 292 424 minecraft:glowstone
setblock 444 292 417 minecraft:glowstone
setblock 444 292 419 minecraft:glowstone
setblock 444 292 421 minecraft:glowstone
setblock 444 292 423 minecraft:glowstone
setblock 444 292 425 minecraft:glowstone
fill 445 292 416 445 307 416 minecraft:stone_bricks
setblock 445 292 418 minecraft:glowstone
setblock 445 292 420 minecraft:glowstone
setblock 445 292 422 minecraft:glowstone
setblock 445 292 424 minecraft:glowstone
setblock 446 292 417 minecraft:glowstone
setblock 446 292 419 minecraft:glowstone
setblock 446 292 421 minecraft:glowstone
setblock 446 292 423 minecraft:glowstone
setblock 446 292 425 minecraft:glowstone
setblock 447 292 418 minecraft:glowstone
setblock 447 292 420 minecraft:glowstone
setblock 447 292 422 minecraft:glowstone
setblock 447 292 424 minecraft:glowstone
fill 447 292 458 447 307 458 minecraft:stone_bricks
setblock 448 292 417 minecraft:glowstone
setblock 448 292 419 minecraft:glowstone
setblock 448 292 421 minecraft:glowstone
setblock 448 292 423 minecraft:glowstone
setblock 448 292 425 minecraft:glowstone
fill 448 292 458 449 292 458 minecraft:glowstone
setblock 449 292 418 minecraft:glowstone
setblock 449 292 420 minecraft:glowstone
setblock 449 292 422 minecraft:glowstone
setblock 449 292 424 minecraft:glowstone
fill 450 292 458 450 307 458 minecraft:stone_bricks
fill 454 292 416 454 307 416 minecraft:stone_bricks
fill 455 292 416 456 292 416 minecraft:glowstone
fill 457 292 416 457 307 416 minecraft:stone_bricks
fill 459 292 458 459 307 458 minecraft:stone_bricks
fill 460 292 458 461 292 458 minecraft:glowstone
fill 462 292 458 462 307 458 minecraft:stone_bricks
fill 465 292 417 465 307 417 minecraft:stone_bricks
fill 465 292 418 465 292 419 minecraft:glowstone
fill 465 292 420 465 307 420 minecraft:stone_bricks
fill 465 292 429 465 307 429 minecraft:stone_bricks
fill 465 292 430 465 292 431 minecraft:glowstone
fill 465 292 432 465 307 432 minecraft:stone_bricks
fill 465 292 441 465 307 441 minecraft:stone_bricks
fill 465 292 442 465 292 443 minecraft:glowstone
fill 465 292 444 465 307 444 minecraft:stone_bricks
fill 465 292 453 465 307 453 minecraft:stone_bricks
fill 465 292 454 465 292 455 minecraft:glowstone
fill 465 292 456 465 307 456 minecraft:stone_bricks
fill 423 293 423 423 307 424 minecraft:stone_bricks
fill 423 293 435 423 307 436 minecraft:stone_bricks
fill 423 293 447 423 307 448 minecraft:stone_bricks
fill 424 293 423 424 294 423 minecraft:iron_block
fill 424 293 425 424 294 425 minecraft:iron_block
fill 424 293 427 424 294 427 minecraft:iron_block
fill 424 293 429 424 294 429 minecraft:iron_block
fill 424 293 458 425 307 458 minecraft:stone_bricks
fill 425 293 424 425 294 424 minecraft:iron_block
fill 425 293 426 425 294 426 minecraft:iron_block
fill 425 293 428 425 294 428 minecraft:iron_block
fill 426 293 423 426 294 423 minecraft:iron_block
fill 426 293 425 426 294 425 minecraft:iron_block
fill 426 293 427 426 294 427 minecraft:iron_block
fill 426 293 429 426 294 429 minecraft:iron_block
fill 427 293 424 427 294 424 minecraft:iron_block
fill 427 293 426 427 294 426 minecraft:iron_block
fill 427 293 428 427 294 428 minecraft:iron_block
fill 428 293 423 428 294 423 minecraft:iron_block
fill 428 293 425 428 294 425 minecraft:iron_block
fill 428 293 427 428 294 427 minecraft:iron_block
fill 428 293 429 428 294 429 minecraft:iron_block
fill 429 293 424 429 294 424 minecraft:iron_block
fill 429 293 426 429 294 426 minecraft:iron_block
fill 429 293 428 429 294 428 minecraft:iron_block
fill 430 293 423 430 294 423 minecraft:iron_block
fill 430 293 425 430 294 425 minecraft:iron_block
fill 430 293 427 430 294 427 minecraft:iron_block
fill 430 293 429 430 294 429 minecraft:iron_block
fill 431 293 416 432 307 416 minecraft:stone_bricks
fill 431 293 424 431 294 424 minecraft:iron_block
fill 431 293 426 431 294 426 minecraft:iron_block
fill 431 293 428 431 294 428 minecraft:iron_block
fill 432 293 423 432 294 423 minecraft:iron_block
fill 432 293 425 432 294 425 minecraft:iron_block
fill 432 293 427 432 294 427 minecraft:iron_block
fill 432 293 429 432 294 429 minecraft:iron_block
fill 436 293 458 437 307 458 minecraft:stone_bricks
fill 441 293 418 441 294 418 minecraft:iron_block
fill 441 293 420 441 294 420 minecraft:iron_block
fill 441 293 422 441 294 422 minecraft:iron_block
fill 441 293 424 441 294 424 minecraft:iron_block
fill 442 293 417 442 294 417 minecraft:iron_block
fill 442 293 419 442 294 419 minecraft:iron_block
fill 442 293 421 442 294 421 minecraft:iron_block
fill 442 293 423 442 294 423 minecraft:iron_block
fill 442 293 425 442 294 425 minecraft:iron_block
fill 443 293 416 444 307 416 minecraft:stone_bricks
fill 443 293 418 443 294 418 minecraft:iron_block
fill 443 293 420 443 294 420 minecraft:iron_block
fill 443 293 422 443 294 422 minecraft:iron_block
fill 443 293 424 443 294 424 minecraft:iron_block
fill 444 293 417 444 294 417 minecraft:iron_block
fill 444 293 419 444 294 419 minecraft:iron_block
fill 444 293 421 444 294 421 minecraft:iron_block
fill 444 293 423 444 294 423 minecraft:iron_block
fill 444 293 425 444 294 425 minecraft:iron_block
fill 445 293 418 445 294 418 minecraft:iron_block
fill 445 293 420 445 294 420 minecraft:iron_block
fill 445 293 422 445 294 422 minecraft:iron_block
fill 445 293 424 445 294 424 minecraft:iron_block
fill 446 293 417 446 294 417 minecraft:iron_block
fill 446 293 419 446 294 419 minecraft:iron_block
fill 446 293 421 446 294 421 minecraft:iron_block
fill 446 293 423 446 294 423 minecraft:iron_block
fill 446 293 425 446 294 425 minecraft:iron_block
fill 447 293 418 447 294 418 minecraft:iron_block
fill 447 293 420 447 294 420 minecraft:iron_block
fill 447 293 422 447 294 422 minecraft:iron_block
fill 447 293 424 447 294 424 minecraft:iron_block
fill 448 293 417 448 294 417 minecraft:iron_block
fill 448 293 419 448 294 419 minecraft:iron_block
fill 448 293 421 448 294 421 minecraft:iron_block
fill 448 293 423 448 294 423 minecraft:iron_block
fill 448 293 425 448 294 425 minecraft:iron_block
fill 448 293 458 449 307 458 minecraft:stone_bricks
fill 449 293 418 449 294 418 minecraft:iron_block
fill 449 293 420 449 294 420 minecraft:iron_block
fill 449 293 422 449 294 422 minecraft:iron_block
fill 449 293 424 449 294 424 minecraft:iron_block
fill 453 293 417 453 294 419 minecraft:iron_bars
fill 455 293 416 456 307 416 minecraft:stone_bricks
fill 460 293 458 461 307 458 minecraft:stone_bricks
fill 465 293 418 465 307 419 minecraft:stone_bricks
fill 465 293 430 465 307 431 minecraft:stone_bricks
fill 465 293 442 465 307 443 minecraft:stone_bricks
fill 465 293 454 465 307 455 minecraft:stone_bricks
setblock 424 295 423 minecraft:glowstone
setblock 424 295 425 minecraft:glowstone
setblock 424 295 427 minecraft:glowstone
setblock 424 295 429 minecraft:glowstone
setblock 425 295 424 minecraft:glowstone
setblock 425 295 426 minecraft:glowstone
setblock 425 295 428 minecraft:glowstone
setblock 426 295 423 minecraft:glowstone
setblock 426 295 425 minecraft:glowstone
setblock 426 295 427 minecraft:glowstone
setblock 426 295 429 minecraft:glowstone
setblock 427 295 424 minecraft:glowstone
setblock 427 295 426 minecraft:glowstone
setblock 427 295 428 minecraft:glowstone
setblock 428 295 423 minecraft:glowstone
setblock 428 295 425 minecraft:glowstone
setblock 428 295 427 minecraft:glowstone
setblock 428 295 429 minecraft:glowstone
setblock 429 295 424 minecraft:glowstone
setblock 429 295 426 minecraft:glowstone
setblock 429 295 428 minecraft:glowstone
setblock 430 295 423 minecraft:glowstone
setblock 430 295 425 minecraft:glowstone
setblock 430 295 427 minecraft:glowstone
setblock 430 295 429 minecraft:glowstone
setblock 431 295 424 minecraft:glowstone
setblock 431 295 426 minecraft:glowstone
setblock 431 295 428 minecraft:glowstone
setblock 432 295 423 minecraft:glowstone
setblock 432 295 425 minecraft:glowstone
setblock 432 295 427 minecraft:glowstone
setblock 432 295 429 minecraft:glowstone
setblock 441 295 418 minecraft:glowstone
setblock 441 295 420 minecraft:glowstone
setblock 441 295 422 minecraft:glowstone
setblock 441 295 424 minecraft:glowstone
setblock 442 295 417 minecraft:glowstone
setblock 442 295 419 minecraft:glowstone
setblock 442 295 421 minecraft:glowstone
setblock 442 295 423 minecraft:glowstone
setblock 442 295 425 minecraft:glowstone
setblock 443 295 418 minecraft:glowstone
setblock 443 295 420 minecraft:glowstone
setblock 443 295 422 minecraft:glowstone
setblock 443 295 424 minecraft:glowstone
setblock 444 295 417 minecraft:glowstone
setblock 444 295 419 minecraft:glowstone
setblock 444 295 421 minecraft:glowstone
setblock 444 295 423 minecraft:glowstone
setblock 444 295 425 minecraft:glowstone
setblock 445 295 418 minecraft:glowstone
setblock 445 295 420 minecraft:glowstone
setblock 445 295 422 minecraft:glowstone
setblock 445 295 424 minecraft:glowstone
setblock 446 295 417 minecraft:glowstone
setblock 446 295 419 minecraft:glowstone
setblock 446 295 421 minecraft:glowstone
setblock 446 295 423 minecraft:glowstone
setblock 446 295 425 minecraft:glowstone
setblock 447 295 418 minecraft:glowstone
setblock 447 295 420 minecraft:glowstone
setblock 447 295 422 minecraft:glowstone
setblock 447 295 424 minecraft:glowstone
setblock 448 295 417 minecraft:glowstone
setblock 448 295 419 minecraft:glowstone
setblock 448 295 421 minecraft:glowstone
setblock 448 295 423 minecraft:glowstone
setblock 448 295 425 minecraft:glowstone
setblock 449 295 418 minecraft:glowstone
setblock 449 295 420 minecraft:glowstone
setblock 449 295 422 minecraft:glowstone
setblock 449 295 424 minecraft:glowstone
fill 424 296 423 424 298 423 minecraft:iron_block
fill 424 296 425 424 298 425 minecraft:iron_block
fill 424 296 427 424 300 427 minecraft:iron_block
fill 424 296 429 424 300 429 minecraft:iron_block
fill 425 296 424 425 298 424 minecraft:iron_block
fill 425 296 426 425 298 426 minecraft:iron_block
fill 425 296 428 425 298 428 minecraft:iron_block
fill 426 296 423 426 298 423 minecraft:iron_block
fill 426 296 425 426 298 425 minecraft:iron_block
fill 426 296 427 426 298 427 minecraft:iron_block
fill 426 296 429 426 298 429 minecraft:iron_block
fill 427 296 424 427 298 424 minecraft:iron_block
fill 427 296 426 427 298 426 minecraft:iron_block
fill 427 296 428 427 298 428 minecraft:iron_block
fill 428 296 423 428 298 423 minecraft:iron_block
fill 428 296 425 428 298 425 minecraft:iron_block
fill 428 296 427 428 298 427 minecraft:iron_block
fill 428 296 429 428 298 429 minecraft:iron_block
fill 429 296 424 429 298 424 minecraft:iron_block
fill 429 296 426 429 298 426 minecraft:iron_block
fill 429 296 428 429 298 428 minecraft:iron_block
fill 430 296 423 430 298 423 minecraft:iron_block
fill 430 296 425 430 298 425 minecraft:iron_block
fill 430 296 427 430 298 427 minecraft:iron_block
fill 430 296 429 430 298 429 minecraft:iron_block
fill 431 296 424 431 298 424 minecraft:iron_block
fill 431 296 426 431 298 426 minecraft:iron_block
fill 431 296 428 431 298 428 minecraft:iron_block
fill 432 296 423 432 298 423 minecraft:iron_block
fill 432 296 425 432 298 425 minecraft:iron_block
fill 432 296 427 432 298 427 minecraft:iron_block
fill 432 296 429 432 298 429 minecraft:iron_block
fill 441 296 418 441 297 418 minecraft:iron_block
fill 441 296 420 441 297 420 minecraft:iron_block
fill 441 296 422 441 297 422 minecraft:iron_block
fill 441 296 424 441 297 424 minecraft:iron_block
fill 442 296 417 442 297 417 minecraft:iron_block
fill 442 296 419 442 297 419 minecraft:iron_block
fill 442 296 421 442 297 421 minecraft:iron_block
fill 442 296 423 442 297 423 minecraft:iron_block
fill 442 296 425 442 297 425 minecraft:iron_block
fill 443 296 418 443 297 418 minecraft:iron_block
fill 443 296 420 443 297 420 minecraft:iron_block
fill 443 296 422 443 297 422 minecraft:iron_block
fill 443 296 424 443 297 424 minecraft:iron_block
fill 444 296 417 444 297 417 minecraft:iron_block
fill 444 296 419 444 297 419 minecraft:iron_block
fill 444 296 421 444 297 421 minecraft:iron_block
fill 444 296 423 444 297 423 minecraft:iron_block
fill 444 296 425 444 297 425 minecraft:iron_block
fill 445 296 418 445 297 418 minecraft:iron_block
fill 445 296 420 445 297 420 minecraft:iron_block
fill 445 296 422 445 297 422 minecraft:iron_block
fill 445 296 424 445 297 424 minecraft:iron_block
fill 446 296 417 446 297 417 minecraft:iron_block
fill 446 296 419 446 297 419 minecraft:iron_block
fill 446 296 421 446 297 421 minecraft:iron_block
fill 446 296 423 446 297 423 minecraft:iron_block
fill 446 296 425 446 297 425 minecraft:iron_block
fill 447 296 418 447 297 418 minecraft:iron_block
fill 447 296 420 447 297 420 minecraft:iron_block
fill 447 296 422 447 297 422 minecraft:iron_block
fill 447 296 424 447 297 424 minecraft:iron_block
fill 448 296 417 448 297 417 minecraft:iron_block
fill 448 296 419 448 297 419 minecraft:iron_block
fill 448 296 421 448 297 421 minecraft:iron_block
fill 448 296 423 448 297 423 minecraft:iron_block
fill 448 296 425 448 297 425 minecraft:iron_block
fill 449 296 418 449 297 418 minecraft:iron_block
fill 449 296 420 449 297 420 minecraft:iron_block
fill 449 296 422 449 297 422 minecraft:iron_block
fill 449 296 424 449 297 424 minecraft:iron_block
setblock 426 297 419 minecraft:light[level=12]
setblock 426 297 435 minecraft:light[level=12]
setblock 426 297 443 minecraft:light[level=12]
setblock 426 297 451 minecraft:light[level=12]
setblock 434 297 419 minecraft:light[level=12]
setblock 434 297 427 minecraft:light[level=12]
setblock 434 297 435 minecraft:light[level=12]
setblock 434 297 443 minecraft:light[level=12]
setblock 434 297 451 minecraft:light[level=12]
setblock 442 297 427 minecraft:light[level=12]
setblock 442 297 435 minecraft:light[level=12]
setblock 442 297 443 minecraft:light[level=12]
setblock 442 297 451 minecraft:light[level=12]
setblock 450 297 419 minecraft:light[level=12]
setblock 450 297 427 minecraft:light[level=12]
setblock 450 297 435 minecraft:light[level=12]
setblock 450 297 443 minecraft:light[level=12]
setblock 450 297 451 minecraft:light[level=12]
setblock 458 297 419 minecraft:light[level=12]
setblock 458 297 427 minecraft:light[level=12]
setblock 458 297 435 minecraft:light[level=12]
setblock 458 297 443 minecraft:light[level=12]
setblock 458 297 451 minecraft:light[level=12]
setblock 441 298 418 minecraft:glowstone
setblock 441 298 420 minecraft:glowstone
setblock 441 298 422 minecraft:glowstone
setblock 441 298 424 minecraft:glowstone
setblock 442 298 417 minecraft:glowstone
setblock 442 298 419 minecraft:glowstone
setblock 442 298 421 minecraft:glowstone
setblock 442 298 423 minecraft:glowstone
setblock 442 298 425 minecraft:glowstone
setblock 443 298 418 minecraft:glowstone
setblock 443 298 420 minecraft:glowstone
setblock 443 298 422 minecraft:glowstone
setblock 443 298 424 minecraft:glowstone
setblock 444 298 417 minecraft:glowstone
setblock 444 298 419 minecraft:glowstone
setblock 444 298 421 minecraft:glowstone
setblock 444 298 423 minecraft:glowstone
setblock 444 298 425 minecraft:glowstone
setblock 445 298 418 minecraft:glowstone
setblock 445 298 420 minecraft:glowstone
setblock 445 298 422 minecraft:glowstone
setblock 445 298 424 minecraft:glowstone
setblock 446 298 417 minecraft:glowstone
setblock 446 298 419 minecraft:glowstone
setblock 446 298 421 minecraft:glowstone
setblock 446 298 423 minecraft:glowstone
setblock 446 298 425 minecraft:glowstone
setblock 447 298 418 minecraft:glowstone
setblock 447 298 420 minecraft:glowstone
setblock 447 298 422 minecraft:glowstone
setblock 447 298 424 minecraft:glowstone
setblock 448 298 417 minecraft:glowstone
setblock 448 298 419 minecraft:glowstone
setblock 448 298 421 minecraft:glowstone
setblock 448 298 423 minecraft:glowstone
setblock 448 298 425 minecraft:glowstone
setblock 449 298 418 minecraft:glowstone
setblock 449 298 420 minecraft:glowstone
setblock 449 298 422 minecraft:glowstone
setblock 449 298 424 minecraft:glowstone
fill 441 299 418 441 300 418 minecraft:iron_block
fill 441 299 420 441 300 420 minecraft:iron_block
fill 441 299 422 441 300 422 minecraft:iron_block
fill 441 299 424 441 300 424 minecraft:iron_block
fill 442 299 417 442 300 417 minecraft:iron_block
fill 442 299 419 442 300 419 minecraft:iron_block
fill 442 299 421 442 300 421 minecraft:iron_block
fill 442 299 423 442 300 423 minecraft:iron_block
fill 442 299 425 442 300 425 minecraft:iron_block
fill 443 299 418 443 300 418 minecraft:iron_block
fill 443 299 420 443 300 420 minecraft:iron_block
fill 443 299 422 443 300 422 minecraft:iron_block
fill 443 299 424 443 300 424 minecraft:iron_block
fill 444 299 417 444 300 417 minecraft:iron_block
fill 444 299 419 444 300 419 minecraft:iron_block
fill 444 299 421 444 300 421 minecraft:iron_block
fill 444 299 423 444 300 423 minecraft:iron_block
fill 444 299 425 444 300 425 minecraft:iron_block
fill 445 299 418 445 300 418 minecraft:iron_block
fill 445 299 420 445 300 420 minecraft:iron_block
fill 445 299 422 445 300 422 minecraft:iron_block
fill 445 299 424 445 300 424 minecraft:iron_block
fill 446 299 417 446 300 417 minecraft:iron_block
fill 446 299 419 446 300 419 minecraft:iron_block
fill 446 299 421 446 300 421 minecraft:iron_block
fill 446 299 423 446 300 423 minecraft:iron_block
fill 446 299 425 446 300 425 minecraft:iron_block
fill 447 299 418 447 300 418 minecraft:iron_block
fill 447 299 420 447 300 420 minecraft:iron_block
fill 447 299 422 447 300 422 minecraft:iron_block
fill 447 299 424 447 300 424 minecraft:iron_block
fill 448 299 417 448 300 417 minecraft:iron_block
fill 448 299 419 448 300 419 minecraft:iron_block
fill 448 299 421 448 300 421 minecraft:iron_block
fill 448 299 423 448 300 423 minecraft:iron_block
fill 448 299 425 448 300 425 minecraft:iron_block
fill 449 299 418 449 300 418 minecraft:iron_block
fill 449 299 420 449 300 420 minecraft:iron_block
fill 449 299 422 449 300 422 minecraft:iron_block
fill 449 299 424 449 300 424 minecraft:iron_block
fill 425 300 426 425 300 428 minecraft:iron_block
fill 425 300 438 425 300 440 minecraft:iron_block
fill 425 300 450 425 300 452 minecraft:iron_block
fill 431 300 456 433 300 456 minecraft:iron_block
fill 435 300 418 437 300 418 minecraft:iron_block
fill 443 300 456 445 300 456 minecraft:iron_block
fill 455 300 456 457 300 456 minecraft:iron_block
fill 459 300 418 461 300 418 minecraft:iron_block
fill 463 300 426 463 300 428 minecraft:iron_block
fill 463 300 438 463 300 440 minecraft:iron_block
fill 463 300 450 463 300 452 minecraft:iron_block
