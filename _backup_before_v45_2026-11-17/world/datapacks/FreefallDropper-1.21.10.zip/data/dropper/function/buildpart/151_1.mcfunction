fill 347 160 609 347 161 609 minecraft:magenta_stained_glass
fill 348 160 616 349 163 616 minecraft:black_concrete
fill 350 160 609 351 163 609 minecraft:black_concrete
fill 351 160 615 351 163 615 minecraft:black_concrete
fill 352 160 610 352 163 611 minecraft:black_concrete
fill 352 160 614 352 163 614 minecraft:black_concrete
fill 358 160 631 358 161 631 minecraft:gold_block
fill 361 160 633 362 160 634 minecraft:magenta_stained_glass
setblock 362 160 632 minecraft:magenta_stained_glass
setblock 363 160 633 minecraft:magenta_stained_glass
setblock 329 161 617 minecraft:crying_obsidian
setblock 332 161 607 minecraft:light[level=12]
setblock 332 161 615 minecraft:light[level=12]
setblock 332 161 623 minecraft:light[level=12]
setblock 332 161 631 minecraft:light[level=12]
setblock 332 161 639 minecraft:light[level=12]
fill 337 161 615 340 166 615 minecraft:orange_concrete
fill 338 161 614 340 166 614 minecraft:orange_concrete
fill 338 161 616 340 166 616 minecraft:orange_concrete
fill 339 161 613 339 166 613 minecraft:orange_concrete
setblock 339 161 646 minecraft:crying_obsidian
setblock 340 161 607 minecraft:light[level=12]
setblock 340 161 623 minecraft:light[level=12]
setblock 340 161 631 minecraft:light[level=12]
setblock 340 161 639 minecraft:light[level=12]
fill 344 161 646 344 173 646 minecraft:black_concrete
fill 345 161 610 345 163 611 minecraft:black_concrete
fill 345 161 614 345 163 614 minecraft:black_concrete
fill 346 161 609 346 163 609 minecraft:black_concrete
fill 346 161 615 346 163 615 minecraft:black_concrete
fill 347 161 610 347 163 610 minecraft:black_concrete
fill 347 161 616 347 163 616 minecraft:black_concrete
setblock 348 161 607 minecraft:light[level=12]
fill 348 161 608 350 163 608 minecraft:black_concrete
setblock 348 161 623 minecraft:light[level=12]
setblock 348 161 631 minecraft:light[level=12]
setblock 348 161 639 minecraft:light[level=12]
fill 350 161 616 350 163 616 minecraft:black_concrete
fill 352 161 615 352 163 615 minecraft:black_concrete
fill 353 161 611 353 163 613 minecraft:black_concrete
setblock 355 161 646 minecraft:crying_obsidian
setblock 356 161 607 minecraft:light[level=12]
setblock 356 161 615 minecraft:light[level=12]
setblock 356 161 623 minecraft:light[level=12]
setblock 356 161 631 minecraft:light[level=12]
setblock 356 161 639 minecraft:light[level=12]
fill 361 161 633 362 161 633 minecraft:magenta_stained_glass
setblock 362 161 634 minecraft:magenta_stained_glass
setblock 364 161 607 minecraft:light[level=12]
setblock 364 161 615 minecraft:light[level=12]
setblock 364 161 623 minecraft:light[level=12]
setblock 364 161 631 minecraft:light[level=12]
setblock 364 161 639 minecraft:light[level=12]
fill 329 162 612 329 164 612 minecraft:magenta_concrete
fill 329 162 617 329 167 617 minecraft:black_concrete
fill 329 162 628 329 164 628 minecraft:magenta_concrete
setblock 329 162 643 minecraft:white_concrete
fill 329 162 644 329 164 644 minecraft:magenta_concrete
fill 331 162 620 332 163 621 minecraft:obsidian
fill 332 162 622 332 163 622 minecraft:obsidian
fill 333 162 604 333 164 604 minecraft:magenta_concrete
fill 337 162 613 337 165 614 minecraft:orange_concrete
fill 337 162 616 337 165 617 minecraft:orange_concrete
fill 338 162 613 338 165 613 minecraft:orange_concrete
fill 338 162 617 340 165 617 minecraft:orange_concrete
fill 339 162 646 339 169 646 minecraft:black_concrete
fill 340 162 613 340 165 613 minecraft:orange_concrete
fill 341 162 614 341 165 616 minecraft:orange_concrete
fill 343 162 646 343 164 646 minecraft:magenta_concrete
fill 344 162 612 344 163 613 minecraft:black_concrete
fill 345 162 615 345 163 615 minecraft:black_concrete
fill 346 162 616 346 163 616 minecraft:black_concrete
fill 347 162 608 347 163 609 minecraft:black_concrete
fill 348 162 617 349 163 617 minecraft:black_concrete
fill 349 162 604 349 164 604 minecraft:magenta_concrete
fill 351 162 608 351 163 608 minecraft:black_concrete
fill 351 162 616 351 163 616 minecraft:black_concrete
fill 352 162 609 352 163 609 minecraft:black_concrete
fill 353 162 610 353 163 610 minecraft:black_concrete
fill 353 162 614 353 163 614 minecraft:black_concrete
fill 355 162 637 356 163 637 minecraft:crying_obsidian
setblock 355 162 646 minecraft:black_concrete
fill 359 162 646 359 164 646 minecraft:magenta_concrete
fill 362 162 633 362 164 633 minecraft:magenta_stained_glass
fill 365 162 604 365 164 604 minecraft:magenta_concrete
fill 371 162 614 371 164 614 minecraft:magenta_concrete
fill 371 162 630 371 164 630 minecraft:magenta_concrete
setblock 329 163 632 minecraft:white_concrete
fill 329 163 643 329 165 643 minecraft:black_concrete
fill 336 163 614 336 164 616 minecraft:orange_concrete
fill 338 163 612 340 164 612 minecraft:orange_concrete
fill 339 163 618 339 164 618 minecraft:orange_concrete
fill 341 163 613 341 164 613 minecraft:orange_concrete
fill 341 163 617 341 164 617 minecraft:orange_concrete
setblock 341 163 646 minecraft:crying_obsidian
fill 342 163 615 342 164 615 minecraft:orange_concrete
fill 344 163 610 344 163 611 minecraft:black_concrete
setblock 344 163 614 minecraft:black_concrete
setblock 345 163 609 minecraft:black_concrete
setblock 345 163 616 minecraft:black_concrete
setblock 346 163 608 minecraft:black_concrete
setblock 347 163 617 minecraft:black_concrete
fill 348 163 607 350 163 607 minecraft:black_concrete
fill 350 163 617 351 163 617 minecraft:black_concrete
setblock 350 163 646 minecraft:crying_obsidian
setblock 352 163 608 minecraft:black_concrete
setblock 352 163 616 minecraft:black_concrete
setblock 353 163 609 minecraft:black_concrete
setblock 353 163 615 minecraft:black_concrete
fill 354 163 611 354 163 613 minecraft:black_concrete
setblock 355 163 604 minecraft:magenta_stained_glass
setblock 355 163 646 minecraft:white_concrete
fill 357 163 637 357 164 637 minecraft:crying_obsidian
fill 329 164 632 329 165 632 minecraft:black_concrete
fill 341 164 646 341 168 646 minecraft:black_concrete
fill 348 164 612 349 164 613 minecraft:magenta_stained_glass
setblock 349 164 611 minecraft:magenta_stained_glass
setblock 350 164 612 minecraft:magenta_stained_glass
fill 350 164 646 350 173 646 minecraft:black_concrete
fill 355 164 604 355 173 604 minecraft:black_concrete
fill 355 164 646 355 171 646 minecraft:black_concrete
fill 358 164 637 359 164 637 minecraft:crying_obsidian
setblock 371 164 621 minecraft:magenta_stained_glass
setblock 329 165 609 minecraft:crying_obsidian
fill 329 165 612 329 169 612 minecraft:black_concrete
setblock 329 165 624 minecraft:crying_obsidian
setblock 329 165 627 minecraft:white_concrete
fill 329 165 628 329 170 628 minecraft:black_concrete
setblock 329 165 629 minecraft:magenta_stained_glass
fill 329 165 644 329 170 644 minecraft:black_concrete
fill 333 165 604 333 170 604 minecraft:black_concrete
setblock 338 165 604 minecraft:white_concrete
fill 343 165 646 343 170 646 minecraft:black_concrete
fill 348 165 612 349 166 612 minecraft:magenta_stained_glass
fill 349 165 604 349 170 604 minecraft:black_concrete
setblock 349 165 613 minecraft:magenta_stained_glass
fill 359 165 637 360 165 638 minecraft:crying_obsidian
fill 359 165 646 359 169 646 minecraft:black_concrete
fill 365 165 604 365 170 604 minecraft:black_concrete
fill 371 165 614 371 169 614 minecraft:black_concrete
fill 371 165 621 371 173 621 minecraft:black_concrete
fill 371 165 630 371 170 630 minecraft:black_concrete
fill 329 166 609 329 173 609 minecraft:black_concrete
setblock 329 166 618 minecraft:crying_obsidian
fill 329 166 621 329 173 621 minecraft:black_concrete
setblock 329 166 622 minecraft:crying_obsidian
fill 329 166 624 329 170 624 minecraft:black_concrete
fill 329 166 627 329 173 627 minecraft:black_concrete
fill 329 166 629 329 173 629 minecraft:black_concrete
setblock 329 166 632 minecraft:magenta_stained_glass
setblock 329 166 643 minecraft:magenta_stained_glass
fill 338 166 604 338 173 604 minecraft:black_concrete
setblock 341 166 604 minecraft:white_concrete
fill 342 166 604 342 173 604 minecraft:black_concrete
setblock 352 166 646 minecraft:white_concrete
fill 361 166 637 362 166 638 minecraft:crying_obsidian
setblock 329 167 605 minecraft:magenta_stained_glass
fill 329 167 618 329 169 618 minecraft:black_concrete
fill 329 167 622 329 173 622 minecraft:black_concrete
fill 329 167 632 329 173 632 minecraft:black_concrete
fill 329 167 643 329 173 643 minecraft:black_concrete
fill 341 167 604 341 171 604 minecraft:black_concrete
fill 346 167 634 347 168 634 minecraft:gold_block
fill 349 167 612 349 168 612 minecraft:magenta_stained_glass
fill 352 167 646 352 169 646 minecraft:black_concrete
fill 362 167 638 364 167 638 minecraft:crying_obsidian
setblock 371 167 607 minecraft:white_concrete
fill 329 168 605 329 170 605 minecraft:black_concrete
setblock 329 168 617 minecraft:white_concrete
setblock 332 168 646 minecraft:crying_obsidian
setblock 364 168 638 minecraft:crying_obsidian
fill 371 168 607 371 173 607 minecraft:black_concrete
fill 329 169 617 329 170 617 minecraft:black_concrete
setblock 332 169 607 minecraft:light[level=12]
setblock 332 169 615 minecraft:light[level=12]
setblock 332 169 623 minecraft:light[level=12]
setblock 332 169 631 minecraft:light[level=12]
setblock 332 169 639 minecraft:light[level=12]
fill 332 169 646 332 173 646 minecraft:black_concrete
fill 337 169 624 337 170 625 minecraft:crying_obsidian
setblock 340 169 607 minecraft:light[level=12]
setblock 340 169 615 minecraft:light[level=12]
setblock 340 169 623 minecraft:light[level=12]
setblock 340 169 631 minecraft:light[level=12]
setblock 340 169 639 minecraft:light[level=12]
setblock 341 169 646 minecraft:magenta_stained_glass
setblock 348 169 607 minecraft:light[level=12]
setblock 348 169 615 minecraft:light[level=12]
setblock 348 169 623 minecraft:light[level=12]
setblock 348 169 631 minecraft:light[level=12]
setblock 348 169 639 minecraft:light[level=12]
setblock 356 169 607 minecraft:light[level=12]
setblock 356 169 615 minecraft:light[level=12]
setblock 356 169 623 minecraft:light[level=12]
setblock 356 169 631 minecraft:light[level=12]
setblock 356 169 639 minecraft:light[level=12]
setblock 364 169 607 minecraft:light[level=12]
setblock 364 169 615 minecraft:light[level=12]
setblock 364 169 623 minecraft:light[level=12]
setblock 364 169 631 minecraft:light[level=12]
setblock 364 169 639 minecraft:light[level=12]
setblock 329 170 608 minecraft:crying_obsidian
setblock 329 170 612 minecraft:crying_obsidian
setblock 329 170 615 minecraft:magenta_concrete
setblock 329 170 618 minecraft:magenta_concrete
fill 336 170 625 336 170 626 minecraft:crying_obsidian
setblock 337 170 646 minecraft:magenta_concrete
setblock 339 170 646 minecraft:magenta_concrete
setblock 341 170 646 minecraft:black_concrete
setblock 348 170 646 minecraft:crying_obsidian
setblock 352 170 646 minecraft:white_concrete
setblock 353 170 604 minecraft:magenta_concrete
fill 357 170 604 357 171 604 minecraft:magenta_concrete
fill 359 170 646 359 204 646 minecraft:magenta_concrete
fill 361 170 604 363 170 604 minecraft:magenta_concrete
setblock 364 170 646 minecraft:magenta_concrete
setblock 366 170 646 minecraft:magenta_concrete
setblock 367 170 604 minecraft:magenta_concrete
setblock 370 170 604 minecraft:magenta_stained_glass
setblock 371 170 614 minecraft:white_concrete
setblock 371 170 617 minecraft:magenta_concrete
setblock 371 170 628 minecraft:magenta_concrete
setblock 371 170 632 minecraft:white_concrete
setblock 329 171 605 minecraft:magenta_concrete
fill 329 171 608 329 173 608 minecraft:black_concrete
fill 329 171 611 329 171 612 minecraft:magenta_concrete
fill 329 171 615 329 173 615 minecraft:black_concrete
fill 329 171 616 329 171 617 minecraft:magenta_concrete
fill 329 171 618 329 173 618 minecraft:black_concrete
setblock 329 171 624 minecraft:magenta_concrete
fill 329 171 628 329 178 628 minecraft:magenta_concrete
setblock 329 171 634 minecraft:crying_obsidian
setblock 329 171 642 minecraft:magenta_concrete
fill 329 171 644 329 172 645 minecraft:magenta_concrete
fill 332 171 604 334 171 604 minecraft:magenta_concrete
fill 335 171 627 335 172 628 minecraft:crying_obsidian
fill 336 171 626 336 171 627 minecraft:crying_obsidian
fill 337 171 646 337 173 646 minecraft:black_concrete
setblock 339 171 646 minecraft:black_concrete
fill 340 171 646 340 172 646 minecraft:magenta_concrete
setblock 341 171 646 minecraft:magenta_stained_glass
fill 343 171 646 343 175 646 minecraft:magenta_concrete
setblock 347 171 604 minecraft:magenta_concrete
setblock 348 171 646 minecraft:black_concrete
fill 349 171 604 349 176 604 minecraft:magenta_concrete
fill 352 171 646 352 172 646 minecraft:black_concrete
fill 353 171 604 353 173 604 minecraft:black_concrete
setblock 360 171 646 minecraft:magenta_concrete
fill 361 171 604 363 173 604 minecraft:black_concrete
setblock 363 171 646 minecraft:magenta_concrete
fill 364 171 646 364 173 646 minecraft:black_concrete
fill 365 171 604 365 232 604 minecraft:magenta_concrete
fill 366 171 646 366 174 646 minecraft:black_concrete
setblock 367 171 604 minecraft:black_concrete
setblock 369 171 604 minecraft:magenta_concrete
fill 370 171 604 370 173 604 minecraft:black_concrete
setblock 371 171 604 minecraft:magenta_concrete
setblock 371 171 611 minecraft:magenta_concrete
fill 371 171 614 371 204 614 minecraft:magenta_concrete
fill 371 171 617 371 173 617 minecraft:black_concrete
setblock 371 171 620 minecraft:magenta_concrete
setblock 371 171 628 minecraft:black_concrete
fill 371 171 630 371 199 630 minecraft:magenta_concrete
fill 371 171 632 371 174 632 minecraft:black_concrete
setblock 371 171 639 minecraft:magenta_concrete
fill 329 172 605 329 174 605 minecraft:black_concrete
fill 329 172 611 329 173 611 minecraft:black_concrete
fill 329 172 612 329 240 612 minecraft:magenta_concrete
fill 329 172 616 329 173 617 minecraft:black_concrete
setblock 329 172 624 minecraft:white_concrete
setblock 329 172 625 minecraft:magenta_concrete
setblock 329 172 630 minecraft:magenta_concrete
fill 329 172 634 329 173 634 minecraft:black_concrete
fill 329 172 642 329 173 642 minecraft:black_concrete
fill 332 172 604 332 174 604 minecraft:black_concrete
fill 333 172 604 333 240 604 minecraft:magenta_concrete
fill 334 172 604 334 173 604 minecraft:black_concrete
fill 334 172 628 334 172 629 minecraft:crying_obsidian
setblock 335 172 646 minecraft:magenta_concrete
setblock 339 172 604 minecraft:magenta_concrete
setblock 339 172 646 minecraft:magenta_concrete
setblock 341 172 604 minecraft:magenta_concrete
fill 341 172 646 341 173 646 minecraft:black_concrete
setblock 344 172 604 minecraft:magenta_concrete
setblock 345 172 646 minecraft:magenta_concrete
fill 347 172 604 347 173 604 minecraft:black_concrete
setblock 348 172 646 minecraft:magenta_concrete
setblock 354 172 604 minecraft:magenta_concrete
setblock 355 172 646 minecraft:magenta_concrete
fill 357 172 604 357 174 604 minecraft:black_concrete
setblock 360 172 604 minecraft:magenta_concrete
fill 360 172 646 360 174 646 minecraft:black_concrete
fill 363 172 646 363 174 646 minecraft:black_concrete
fill 366 172 604 368 172 604 minecraft:magenta_concrete
fill 369 172 604 369 173 604 minecraft:black_concrete
fill 371 172 604 371 173 604 minecraft:black_concrete
setblock 371 172 606 minecraft:magenta_concrete
fill 371 172 611 371 173 611 minecraft:black_concrete
fill 371 172 615 371 172 616 minecraft:magenta_concrete
fill 371 172 620 371 173 620 minecraft:black_concrete
setblock 371 172 628 minecraft:magenta_concrete
fill 371 172 639 371 173 639 minecraft:black_concrete
fill 329 173 624 329 173 625 minecraft:black_concrete
setblock 329 173 630 minecraft:black_concrete
fill 329 173 644 329 174 644 minecraft:magenta_concrete
setblock 329 173 645 minecraft:black_concrete
fill 333 173 630 334 173 630 minecraft:crying_obsidian
setblock 334 173 629 minecraft:crying_obsidian
setblock 335 173 646 minecraft:black_concrete
setblock 339 173 604 minecraft:black_concrete
fill 339 173 646 340 173 646 minecraft:black_concrete
setblock 341 173 604 minecraft:black_concrete
setblock 344 173 604 minecraft:black_concrete
setblock 345 173 646 minecraft:black_concrete
setblock 348 173 646 minecraft:black_concrete
setblock 352 173 646 minecraft:white_concrete
setblock 354 173 604 minecraft:black_concrete
setblock 355 173 646 minecraft:black_concrete
setblock 360 173 604 minecraft:black_concrete
fill 366 173 604 368 173 604 minecraft:black_concrete
setblock 371 173 606 minecraft:black_concrete
setblock 371 173 609 minecraft:magenta_stained_glass
fill 371 173 615 371 173 616 minecraft:black_concrete
setblock 371 173 628 minecraft:black_concrete
setblock 371 173 641 minecraft:crying_obsidian
fill 329 174 604 331 174 604 minecraft:magenta_concrete
fill 329 174 606 329 175 611 minecraft:magenta_concrete
fill 329 174 613 329 175 627 minecraft:magenta_concrete
fill 329 174 629 329 174 637 minecraft:magenta_concrete
fill 329 174 639 329 188 643 minecraft:magenta_concrete
fill 329 174 645 329 196 645 minecraft:magenta_concrete
fill 330 174 646 330 200 646 minecraft:magenta_concrete
fill 332 174 631 332 174 632 minecraft:crying_obsidian
fill 332 174 646 332 189 646 minecraft:magenta_concrete
fill 333 174 630 333 174 631 minecraft:crying_obsidian
fill 334 174 604 348 174 604 minecraft:magenta_concrete
fill 334 174 646 335 175 646 minecraft:magenta_concrete
fill 337 174 646 341 178 646 minecraft:magenta_concrete
fill 344 174 646 358 174 646 minecraft:magenta_concrete
fill 351 174 604 356 182 604 minecraft:magenta_concrete
fill 358 174 604 364 174 604 minecraft:magenta_concrete
fill 361 174 646 362 181 646 minecraft:magenta_concrete
fill 364 174 646 364 222 646 minecraft:magenta_concrete
fill 366 174 604 371 174 604 minecraft:magenta_concrete
fill 368 174 646 371 234 646 minecraft:magenta_concrete
fill 371 174 605 371 174 613 minecraft:magenta_concrete
fill 371 174 615 371 174 616 minecraft:magenta_concrete
setblock 371 174 617 minecraft:magenta_stained_glass
fill 371 174 618 371 174 622 minecraft:magenta_concrete
setblock 371 174 623 minecraft:magenta_stained_glass
fill 371 174 624 371 174 629 minecraft:magenta_concrete
fill 371 174 633 371 174 637 minecraft:magenta_concrete
setblock 371 174 639 minecraft:magenta_concrete
fill 371 174 641 371 174 645 minecraft:magenta_concrete
setblock 329 175 604 minecraft:black_concrete
setblock 329 175 605 minecraft:magenta_concrete
fill 329 175 629 329 177 632 minecraft:magenta_concrete
setblock 329 175 633 minecraft:crying_obsidian
fill 329 175 634 329 236 635 minecraft:magenta_concrete
setblock 329 175 636 minecraft:black_concrete
fill 329 175 637 329 209 638 minecraft:magenta_concrete
fill 329 175 644 329 176 644 minecraft:black_concrete
fill 329 175 646 329 236 646 minecraft:magenta_concrete
fill 330 175 604 332 175 604 minecraft:magenta_concrete
fill 331 175 646 331 176 646 minecraft:magenta_concrete
setblock 332 175 632 minecraft:crying_obsidian
fill 333 175 646 333 205 646 minecraft:magenta_concrete
fill 334 175 604 337 175 604 minecraft:magenta_concrete
fill 336 175 646 336 192 646 minecraft:magenta_concrete
setblock 338 175 604 minecraft:black_concrete
fill 339 175 604 347 179 604 minecraft:magenta_concrete
fill 342 175 646 342 238 646 minecraft:magenta_concrete
fill 344 175 646 355 175 646 minecraft:magenta_concrete
setblock 348 175 604 minecraft:black_concrete
fill 350 175 604 350 210 604 minecraft:magenta_concrete
fill 356 175 646 357 175 646 minecraft:black_concrete
fill 357 175 604 358 175 604 minecraft:magenta_concrete
fill 358 175 646 358 228 646 minecraft:magenta_concrete
setblock 359 175 604 minecraft:black_concrete
fill 360 175 604 364 178 604 minecraft:magenta_concrete
fill 360 175 646 360 240 646 minecraft:magenta_concrete
fill 363 175 646 363 188 646 minecraft:magenta_concrete
fill 365 175 646 366 205 646 minecraft:magenta_concrete
setblock 366 175 604 minecraft:black_concrete
fill 367 175 604 371 191 604 minecraft:magenta_concrete
setblock 371 175 605 minecraft:magenta_concrete
setblock 371 175 606 minecraft:magenta_stained_glass
fill 371 175 607 371 175 612 minecraft:magenta_concrete
setblock 371 175 613 minecraft:black_concrete
fill 371 175 615 371 240 615 minecraft:magenta_concrete
setblock 371 175 616 minecraft:black_concrete
fill 371 175 617 371 175 621 minecraft:magenta_concrete
setblock 371 175 622 minecraft:black_concrete
fill 371 175 623 371 175 628 minecraft:magenta_concrete
setblock 371 175 629 minecraft:crying_obsidian
fill 371 175 631 371 184 633 minecraft:magenta_concrete
setblock 371 175 634 minecraft:black_concrete
fill 371 175 635 371 180 638 minecraft:magenta_concrete
setblock 371 175 639 minecraft:black_concrete
fill 371 175 640 371 175 643 minecraft:magenta_concrete
setblock 371 175 644 minecraft:black_concrete
fill 371 175 645 371 189 645 minecraft:magenta_concrete
fill 329 176 604 331 194 604 minecraft:magenta_concrete
setblock 329 176 605 minecraft:black_concrete
fill 329 176 606 329 183 608 minecraft:magenta_concrete
setblock 329 176 609 minecraft:crying_obsidian
fill 329 176 610 329 182 611 minecraft:magenta_concrete
fill 329 176 613 329 237 613 minecraft:magenta_concrete
setblock 329 176 614 minecraft:black_concrete
fill 329 176 615 329 180 626 minecraft:magenta_concrete
setblock 329 176 627 minecraft:black_concrete
fill 329 176 633 329 192 633 minecraft:magenta_concrete
fill 329 176 636 329 187 636 minecraft:magenta_concrete
setblock 332 176 604 minecraft:black_concrete
setblock 334 176 604 minecraft:black_concrete
setblock 334 176 646 minecraft:black_concrete
fill 335 176 604 338 178 604 minecraft:magenta_concrete
setblock 335 176 646 minecraft:white_concrete
fill 343 176 646 344 176 646 minecraft:black_concrete
fill 345 176 646 356 183 646 minecraft:magenta_concrete
fill 348 176 604 348 234 604 minecraft:magenta_concrete
fill 357 176 604 357 240 604 minecraft:magenta_concrete
setblock 357 176 646 minecraft:black_concrete
setblock 358 176 604 minecraft:black_concrete
fill 359 176 604 359 221 604 minecraft:magenta_concrete
fill 366 176 604 366 199 604 minecraft:magenta_concrete
fill 367 176 646 367 200 646 minecraft:magenta_concrete
setblock 371 176 605 minecraft:black_concrete
fill 371 176 606 371 176 610 minecraft:magenta_concrete
fill 371 176 611 371 176 612 minecraft:black_concrete
fill 371 176 613 371 240 613 minecraft:magenta_concrete
fill 371 176 616 371 186 618 minecraft:magenta_concrete
setblock 371 176 619 minecraft:black_concrete
fill 371 176 620 371 180 627 minecraft:magenta_concrete
setblock 371 176 628 minecraft:black_concrete
fill 371 176 629 371 226 629 minecraft:magenta_concrete
fill 371 176 634 371 177 634 minecraft:magenta_concrete
fill 371 176 639 371 240 639 minecraft:magenta_concrete
setblock 371 176 640 minecraft:black_concrete
fill 371 176 641 371 177 644 minecraft:magenta_concrete
fill 329 177 605 329 187 605 minecraft:magenta_concrete
fill 329 177 609 329 240 609 minecraft:magenta_concrete
fill 329 177 614 329 240 614 minecraft:magenta_concrete
fill 329 177 627 329 230 627 minecraft:magenta_concrete
fill 329 177 644 329 189 644 minecraft:magenta_concrete
setblock 331 177 646 minecraft:crying_obsidian
fill 332 177 604 332 227 604 minecraft:magenta_concrete
setblock 332 177 607 minecraft:light[level=12]
setblock 332 177 615 minecraft:light[level=12]
setblock 332 177 623 minecraft:light[level=12]
setblock 332 177 631 minecraft:light[level=12]
setblock 332 177 639 minecraft:light[level=12]
fill 334 177 604 334 231 604 minecraft:magenta_concrete
fill 334 177 646 335 188 646 minecraft:magenta_concrete
setblock 340 177 607 minecraft:light[level=12]
setblock 340 177 615 minecraft:light[level=12]
setblock 340 177 623 minecraft:light[level=12]
setblock 340 177 631 minecraft:light[level=12]
setblock 340 177 639 minecraft:light[level=12]
fill 343 177 646 344 211 646 minecraft:magenta_concrete
setblock 348 177 607 minecraft:light[level=12]
setblock 348 177 615 minecraft:light[level=12]
setblock 348 177 623 minecraft:light[level=12]
setblock 348 177 631 minecraft:light[level=12]
setblock 348 177 639 minecraft:light[level=12]
setblock 349 177 604 minecraft:white_concrete
setblock 356 177 607 minecraft:light[level=12]
setblock 356 177 615 minecraft:light[level=12]
setblock 356 177 623 minecraft:light[level=12]
setblock 356 177 631 minecraft:light[level=12]
setblock 356 177 639 minecraft:light[level=12]
fill 357 177 646 357 203 646 minecraft:magenta_concrete
fill 358 177 604 358 183 604 minecraft:magenta_concrete
setblock 364 177 607 minecraft:light[level=12]
setblock 364 177 615 minecraft:light[level=12]
setblock 364 177 623 minecraft:light[level=12]
setblock 364 177 631 minecraft:light[level=12]
setblock 364 177 639 minecraft:light[level=12]
fill 371 177 605 371 240 606 minecraft:magenta_concrete
setblock 371 177 607 minecraft:crying_obsidian
fill 371 177 608 371 184 612 minecraft:magenta_concrete
setblock 371 177 619 minecraft:magenta_concrete
fill 371 177 628 371 240 628 minecraft:magenta_concrete
fill 371 177 640 371 202 640 minecraft:magenta_concrete
fill 329 178 629 329 194 631 minecraft:magenta_concrete
setblock 329 178 632 minecraft:crying_obsidian
fill 331 178 646 331 240 646 minecraft:magenta_concrete
fill 349 178 604 349 198 604 minecraft:magenta_concrete
fill 367 178 625 369 179 625 minecraft:gold_block
fill 368 178 624 368 179 624 minecraft:gold_block
fill 371 178 607 371 202 607 minecraft:magenta_concrete
setblock 371 178 619 minecraft:magenta_stained_glass
setblock 371 178 634 minecraft:crying_obsidian
setblock 371 178 641 minecraft:magenta_concrete
setblock 371 178 642 minecraft:magenta_stained_glass
fill 371 178 643 371 187 644 minecraft:magenta_concrete
setblock 329 179 628 minecraft:white_concrete
fill 329 179 632 329 190 632 minecraft:magenta_concrete
setblock 335 179 604 minecraft:crying_obsidian
fill 336 179 604 338 204 604 minecraft:magenta_concrete
fill 337 179 646 337 240 646 minecraft:magenta_concrete
setblock 338 179 646 minecraft:magenta_stained_glass
fill 339 179 646 341 199 646 minecraft:magenta_concrete
fill 360 179 604 363 180 604 minecraft:magenta_concrete
setblock 364 179 604 minecraft:magenta_stained_glass
fill 371 179 619 371 215 619 minecraft:magenta_concrete
fill 371 179 634 371 238 634 minecraft:magenta_concrete
setblock 371 179 641 minecraft:crying_obsidian
fill 371 179 642 371 225 642 minecraft:magenta_concrete
fill 329 180 628 329 240 628 minecraft:magenta_concrete
fill 335 180 604 335 193 604 minecraft:magenta_concrete
fill 338 180 646 338 190 646 minecraft:magenta_concrete
fill 339 180 604 343 194 604 minecraft:magenta_concrete
setblock 344 180 604 minecraft:magenta_stained_glass
fill 345 180 604 347 183 604 minecraft:magenta_concrete
fill 364 180 604 364 241 604 minecraft:magenta_concrete
fill 371 180 641 371 240 641 minecraft:magenta_concrete
fill 329 181 615 329 181 617 minecraft:magenta_concrete
setblock 329 181 618 minecraft:magenta_stained_glass
fill 329 181 619 329 227 620 minecraft:magenta_concrete
setblock 329 181 621 minecraft:crying_obsidian
fill 329 181 622 329 195 626 minecraft:magenta_concrete
fill 336 181 626 338 182 626 minecraft:gold_block
fill 337 181 627 337 182 627 minecraft:gold_block
fill 344 181 604 344 215 604 minecraft:magenta_concrete
fill 360 181 604 360 236 604 minecraft:magenta_concrete
setblock 361 181 604 minecraft:white_concrete
fill 362 181 604 363 223 604 minecraft:magenta_concrete
fill 371 181 620 371 182 624 minecraft:magenta_concrete
setblock 371 181 625 minecraft:magenta_stained_glass
fill 371 181 626 371 182 627 minecraft:magenta_concrete
fill 371 181 635 371 194 637 minecraft:magenta_concrete
setblock 371 181 638 minecraft:magenta_stained_glass
fill 329 182 615 329 191 616 minecraft:magenta_concrete
setblock 329 182 617 minecraft:white_concrete
fill 329 182 618 329 201 618 minecraft:magenta_concrete
fill 329 182 621 329 204 621 minecraft:magenta_concrete
fill 361 182 604 361 204 604 minecraft:magenta_concrete
setblock 361 182 646 minecraft:crying_obsidian
fill 362 182 646 362 197 646 minecraft:magenta_concrete
fill 371 182 625 371 232 625 minecraft:magenta_concrete
fill 371 182 638 371 221 638 minecraft:magenta_concrete
setblock 329 183 610 minecraft:white_concrete
fill 329 183 611 329 216 611 minecraft:magenta_concrete
fill 329 183 617 329 224 617 minecraft:magenta_concrete
fill 351 183 604 355 193 604 minecraft:magenta_concrete
setblock 356 183 604 minecraft:white_concrete
fill 361 183 646 361 240 646 minecraft:magenta_concrete
fill 371 183 620 371 240 620 minecraft:magenta_concrete
setblock 371 183 621 minecraft:white_concrete
fill 371 183 622 371 183 624 minecraft:magenta_concrete
setblock 371 183 626 minecraft:magenta_stained_glass
fill 371 183 627 371 208 627 minecraft:magenta_concrete
fill 329 184 606 329 186 607 minecraft:magenta_concrete
setblock 329 184 608 minecraft:magenta_stained_glass
fill 329 184 610 329 240 610 minecraft:magenta_concrete
fill 345 184 604 346 185 604 minecraft:magenta_concrete
fill 345 184 646 354 198 646 minecraft:magenta_concrete
setblock 347 184 604 minecraft:magenta_stained_glass
setblock 355 184 646 minecraft:white_concrete
fill 356 184 604 356 213 604 minecraft:magenta_concrete
fill 356 184 646 356 186 646 minecraft:magenta_concrete
setblock 358 184 604 minecraft:magenta_stained_glass
fill 371 184 621 371 198 621 minecraft:magenta_concrete
setblock 371 184 622 minecraft:white_concrete
fill 371 184 623 371 201 624 minecraft:magenta_concrete
fill 371 184 626 371 224 626 minecraft:magenta_concrete
fill 329 185 608 329 211 608 minecraft:magenta_concrete
setblock 332 185 607 minecraft:light[level=12]
setblock 332 185 615 minecraft:light[level=12]
setblock 332 185 623 minecraft:light[level=12]
setblock 332 185 631 minecraft:light[level=12]
setblock 332 185 639 minecraft:light[level=12]
setblock 340 185 607 minecraft:light[level=12]
setblock 340 185 615 minecraft:light[level=12]
setblock 340 185 623 minecraft:light[level=12]
setblock 340 185 631 minecraft:light[level=12]
setblock 340 185 639 minecraft:light[level=12]
setblock 347 185 604 minecraft:magenta_concrete
setblock 348 185 607 minecraft:light[level=12]
setblock 348 185 615 minecraft:light[level=12]
setblock 348 185 623 minecraft:light[level=12]
setblock 348 185 631 minecraft:light[level=12]
setblock 348 185 639 minecraft:light[level=12]
fill 355 185 646 355 193 646 minecraft:magenta_concrete
setblock 356 185 607 minecraft:light[level=12]
setblock 356 185 615 minecraft:light[level=12]
setblock 356 185 623 minecraft:light[level=12]
setblock 356 185 631 minecraft:light[level=12]
setblock 356 185 639 minecraft:light[level=12]
fill 358 185 604 358 236 604 minecraft:magenta_concrete
setblock 364 185 607 minecraft:light[level=12]
setblock 364 185 615 minecraft:light[level=12]
setblock 364 185 623 minecraft:light[level=12]
setblock 364 185 631 minecraft:light[level=12]
setblock 364 185 639 minecraft:light[level=12]
setblock 371 185 608 minecraft:white_concrete
fill 371 185 609 371 217 612 minecraft:magenta_concrete
fill 371 185 622 371 196 622 minecraft:magenta_concrete
setblock 371 185 631 minecraft:crying_obsidian
fill 371 185 632 371 213 633 minecraft:magenta_concrete
fill 345 186 604 345 191 604 minecraft:magenta_concrete
setblock 346 186 604 minecraft:white_concrete
setblock 347 186 604 minecraft:crying_obsidian
fill 348 186 624 348 186 627 minecraft:shroomlight
fill 349 186 624 352 186 624 minecraft:shroomlight
setblock 349 186 627 minecraft:shroomlight
setblock 350 186 623 minecraft:shroomlight
setblock 350 186 628 minecraft:shroomlight
fill 351 186 625 352 186 627 minecraft:shroomlight
fill 371 186 608 371 191 608 minecraft:magenta_concrete
fill 371 186 631 371 224 631 minecraft:magenta_concrete
fill 329 187 606 329 240 606 minecraft:magenta_concrete
setblock 329 187 607 minecraft:magenta_stained_glass
fill 346 187 604 347 191 604 minecraft:magenta_concrete
fill 346 187 624 347 187 627 minecraft:shroomlight
fill 347 187 623 349 187 623 minecraft:shroomlight
fill 347 187 628 349 187 628 minecraft:shroomlight
fill 348 187 622 352 187 622 minecraft:shroomlight
fill 348 187 624 348 196 627 minecraft:orange_concrete
fill 348 187 629 352 187 629 minecraft:shroomlight
fill 349 187 624 352 196 624 minecraft:orange_concrete
fill 350 187 623 350 198 623 minecraft:orange_concrete
fill 350 187 628 350 196 628 minecraft:orange_concrete
fill 351 187 623 353 187 623 minecraft:shroomlight
fill 351 187 628 353 187 628 minecraft:shroomlight
fill 352 187 625 352 196 627 minecraft:orange_concrete
fill 353 187 624 354 187 627 minecraft:shroomlight
setblock 356 187 646 minecraft:white_concrete
fill 371 187 616 371 193 616 minecraft:magenta_concrete
setblock 371 187 617 minecraft:magenta_stained_glass
fill 371 187 618 371 237 618 minecraft:magenta_concrete
setblock 329 188 605 minecraft:white_concrete
fill 329 188 607 329 191 607 minecraft:magenta_concrete
setblock 329 188 636 minecraft:magenta_stained_glass
fill 345 188 624 345 188 627 minecraft:shroomlight
fill 346 188 622 346 188 623 minecraft:shroomlight
fill 346 188 624 347 194 627 minecraft:orange_concrete
fill 346 188 628 346 188 629 minecraft:shroomlight
setblock 347 188 622 minecraft:shroomlight
fill 347 188 623 349 194 623 minecraft:orange_concrete
fill 347 188 628 349 196 628 minecraft:orange_concrete
setblock 347 188 629 minecraft:shroomlight
fill 348 188 621 352 188 621 minecraft:shroomlight
fill 348 188 622 352 194 622 minecraft:orange_concrete
fill 348 188 629 352 194 629 minecraft:orange_concrete
fill 348 188 630 352 188 630 minecraft:shroomlight
fill 351 188 623 353 194 623 minecraft:orange_concrete
fill 351 188 628 353 194 628 minecraft:orange_concrete
fill 353 188 622 354 188 622 minecraft:shroomlight
fill 353 188 624 354 196 627 minecraft:orange_concrete
fill 353 188 629 354 188 629 minecraft:shroomlight
setblock 354 188 623 minecraft:shroomlight
setblock 354 188 628 minecraft:shroomlight
fill 355 188 624 355 188 627 minecraft:shroomlight
fill 356 188 646 356 224 646 minecraft:magenta_concrete
fill 371 188 617 371 199 617 minecraft:magenta_concrete
fill 371 188 643 371 189 643 minecraft:magenta_concrete
setblock 371 188 644 minecraft:white_concrete
fill 329 189 605 329 211 605 minecraft:magenta_concrete
fill 329 189 636 329 236 636 minecraft:magenta_concrete
fill 329 189 639 329 194 642 minecraft:magenta_concrete
setblock 329 189 643 minecraft:magenta_stained_glass
fill 334 189 646 334 228 646 minecraft:magenta_concrete
setblock 335 189 646 minecraft:magenta_stained_glass
fill 344 189 625 344 196 626 minecraft:shroomlight
fill 345 189 623 345 189 624 minecraft:shroomlight
fill 345 189 625 345 196 626 minecraft:orange_concrete
fill 345 189 627 345 189 628 minecraft:shroomlight
fill 346 189 621 346 189 622 minecraft:shroomlight
fill 346 189 623 346 194 623 minecraft:orange_concrete
fill 346 189 628 346 196 628 minecraft:orange_concrete
fill 346 189 629 346 189 630 minecraft:shroomlight
setblock 347 189 621 minecraft:shroomlight
fill 347 189 622 347 194 622 minecraft:orange_concrete
fill 347 189 629 347 194 629 minecraft:orange_concrete
setblock 347 189 630 minecraft:shroomlight
fill 348 189 620 352 189 620 minecraft:shroomlight
fill 348 189 621 352 194 621 minecraft:orange_concrete
fill 348 189 630 352 194 630 minecraft:orange_concrete
fill 348 189 631 352 189 631 minecraft:shroomlight
fill 353 189 621 354 189 621 minecraft:shroomlight
fill 353 189 622 353 194 622 minecraft:orange_concrete
fill 353 189 629 353 194 629 minecraft:orange_concrete
fill 353 189 630 354 189 630 minecraft:shroomlight
setblock 354 189 622 minecraft:shroomlight
fill 354 189 623 354 194 623 minecraft:orange_concrete
fill 354 189 628 354 194 628 minecraft:orange_concrete
setblock 354 189 629 minecraft:shroomlight
fill 355 189 623 355 189 624 minecraft:shroomlight
fill 355 189 625 355 196 626 minecraft:orange_concrete
fill 355 189 627 355 189 628 minecraft:shroomlight
fill 356 189 625 356 196 626 minecraft:shroomlight
setblock 363 189 646 minecraft:crying_obsidian
fill 371 189 644 371 197 644 minecraft:magenta_concrete
fill 329 190 643 329 191 643 minecraft:magenta_concrete
setblock 329 190 644 minecraft:crying_obsidian
setblock 332 190 646 minecraft:magenta_stained_glass
fill 335 190 646 335 237 646 minecraft:magenta_concrete
fill 344 190 623 344 195 624 minecraft:shroomlight
fill 344 190 627 344 195 628 minecraft:shroomlight
fill 345 190 622 345 191 622 minecraft:shroomlight
fill 345 190 623 345 194 624 minecraft:orange_concrete
fill 345 190 627 345 195 628 minecraft:orange_concrete
fill 345 190 629 345 191 629 minecraft:shroomlight
setblock 346 190 621 minecraft:shroomlight
fill 346 190 622 346 194 622 minecraft:orange_concrete
fill 346 190 629 346 194 629 minecraft:orange_concrete
setblock 346 190 630 minecraft:shroomlight
fill 347 190 620 349 190 620 minecraft:shroomlight
fill 347 190 621 347 195 621 minecraft:orange_concrete
fill 347 190 630 347 194 630 minecraft:orange_concrete
fill 347 190 631 349 190 631 minecraft:shroomlight
fill 350 190 619 350 195 619 minecraft:shroomlight
fill 350 190 620 350 195 620 minecraft:orange_concrete
fill 350 190 631 350 195 631 minecraft:orange_concrete
fill 350 190 632 350 195 632 minecraft:shroomlight
fill 351 190 620 353 190 620 minecraft:shroomlight
fill 351 190 631 353 190 631 minecraft:shroomlight
fill 353 190 621 353 194 621 minecraft:orange_concrete
fill 353 190 630 353 194 630 minecraft:orange_concrete
setblock 354 190 621 minecraft:shroomlight
fill 354 190 622 354 194 622 minecraft:orange_concrete
fill 354 190 629 354 194 629 minecraft:orange_concrete
setblock 354 190 630 minecraft:shroomlight
fill 355 190 622 355 191 622 minecraft:shroomlight
fill 355 190 623 355 195 624 minecraft:orange_concrete
fill 355 190 627 355 194 628 minecraft:orange_concrete
fill 355 190 629 355 191 629 minecraft:shroomlight
fill 356 190 623 356 195 624 minecraft:shroomlight
fill 356 190 627 356 195 628 minecraft:shroomlight
fill 363 190 646 363 191 646 minecraft:magenta_concrete
setblock 371 190 643 minecraft:white_concrete
setblock 371 190 645 minecraft:white_concrete
setblock 329 191 632 minecraft:white_concrete
fill 329 191 644 329 236 644 minecraft:magenta_concrete
fill 332 191 646 332 240 646 minecraft:magenta_concrete
setblock 338 191 646 minecraft:white_concrete
fill 345 191 621 345 194 621 minecraft:shroomlight
fill 345 191 630 345 194 630 minecraft:shroomlight
fill 346 191 620 347 194 620 minecraft:shroomlight
fill 346 191 621 346 194 621 minecraft:orange_concrete
fill 346 191 630 346 194 630 minecraft:orange_concrete
fill 346 191 631 347 194 631 minecraft:shroomlight
fill 348 191 619 349 194 619 minecraft:shroomlight
fill 348 191 620 349 194 620 minecraft:orange_concrete
fill 348 191 631 349 194 631 minecraft:orange_concrete
fill 348 191 632 349 194 632 minecraft:shroomlight
fill 351 191 619 352 194 619 minecraft:shroomlight
fill 351 191 620 352 194 620 minecraft:orange_concrete
fill 351 191 631 352 194 631 minecraft:orange_concrete
fill 351 191 632 352 194 632 minecraft:shroomlight
fill 353 191 620 354 194 620 minecraft:shroomlight
fill 353 191 631 354 194 631 minecraft:shroomlight
fill 354 191 621 354 194 621 minecraft:orange_concrete
fill 354 191 630 354 194 630 minecraft:orange_concrete
fill 355 191 621 355 194 621 minecraft:shroomlight
fill 355 191 630 355 194 630 minecraft:shroomlight
fill 371 191 643 371 240 643 minecraft:magenta_concrete
fill 371 191 645 371 240 645 minecraft:magenta_concrete
setblock 329 192 607 minecraft:white_concrete
fill 329 192 615 329 235 615 minecraft:magenta_concrete
setblock 329 192 616 minecraft:white_concrete
fill 329 192 632 329 219 632 minecraft:magenta_concrete
setblock 329 192 643 minecraft:white_concrete
fill 338 192 646 338 215 646 minecraft:magenta_concrete
fill 344 192 622 344 193 622 minecraft:shroomlight
fill 344 192 629 344 193 629 minecraft:shroomlight
setblock 345 192 604 minecraft:crying_obsidian
fill 345 192 622 345 193 622 minecraft:orange_concrete
fill 345 192 629 345 193 629 minecraft:orange_concrete
fill 346 192 604 346 238 604 minecraft:magenta_concrete
setblock 347 192 604 minecraft:crying_obsidian
fill 355 192 622 355 193 622 minecraft:orange_concrete
fill 355 192 629 355 193 629 minecraft:orange_concrete
fill 356 192 622 356 193 622 minecraft:shroomlight
fill 356 192 629 356 193 629 minecraft:shroomlight
setblock 363 192 646 minecraft:white_concrete
fill 367 192 604 368 220 604 minecraft:magenta_concrete
setblock 369 192 604 minecraft:magenta_stained_glass
fill 370 192 604 371 200 604 minecraft:magenta_concrete
setblock 371 192 608 minecraft:white_concrete
fill 329 193 607 329 241 607 minecraft:magenta_concrete
setblock 329 193 616 minecraft:magenta_concrete
setblock 329 193 633 minecraft:crying_obsidian
fill 329 193 643 329 194 643 minecraft:magenta_stained_glass
setblock 332 193 607 minecraft:light[level=12]
setblock 332 193 615 minecraft:light[level=12]
setblock 332 193 623 minecraft:light[level=12]
setblock 332 193 631 minecraft:light[level=12]
setblock 332 193 639 minecraft:light[level=12]
setblock 336 193 646 minecraft:crying_obsidian
setblock 340 193 607 minecraft:light[level=12]
setblock 340 193 615 minecraft:light[level=12]
setblock 340 193 623 minecraft:light[level=12]
setblock 340 193 631 minecraft:light[level=12]
setblock 340 193 639 minecraft:light[level=12]
fill 345 193 604 345 241 604 minecraft:magenta_concrete
fill 347 193 604 347 241 604 minecraft:magenta_concrete
setblock 348 193 607 minecraft:light[level=12]
setblock 348 193 615 minecraft:light[level=12]
setblock 348 193 639 minecraft:light[level=12]
setblock 356 193 607 minecraft:light[level=12]
setblock 356 193 615 minecraft:light[level=12]
setblock 356 193 631 minecraft:light[level=12]
setblock 356 193 639 minecraft:light[level=12]
fill 363 193 646 363 208 646 minecraft:magenta_concrete
setblock 364 193 607 minecraft:light[level=12]
setblock 364 193 615 minecraft:light[level=12]
setblock 364 193 623 minecraft:light[level=12]
setblock 364 193 631 minecraft:light[level=12]
setblock 364 193 639 minecraft:light[level=12]
fill 369 193 604 369 238 604 minecraft:magenta_concrete
fill 371 193 608 371 239 608 minecraft:magenta_concrete
setblock 329 194 616 minecraft:magenta_stained_glass
fill 329 194 633 329 198 633 minecraft:magenta_concrete
setblock 335 194 604 minecraft:crying_obsidian
fill 336 194 646 336 240 646 minecraft:magenta_concrete
setblock 345 194 622 minecraft:shroomlight
fill 345 194 629 345 195 629 minecraft:shroomlight
fill 351 194 604 352 227 604 minecraft:magenta_concrete
setblock 353 194 604 minecraft:magenta_stained_glass
fill 354 194 604 355 216 604 minecraft:magenta_concrete
fill 355 194 622 355 195 622 minecraft:shroomlight
setblock 355 194 629 minecraft:shroomlight
setblock 355 194 646 minecraft:white_concrete
setblock 371 194 616 minecraft:crying_obsidian
fill 329 195 604 330 226 604 minecraft:magenta_concrete
fill 329 195 616 329 236 616 minecraft:magenta_concrete
fill 329 195 629 329 240 629 minecraft:magenta_concrete
setblock 329 195 630 minecraft:magenta_stained_glass
fill 329 195 631 329 204 631 minecraft:magenta_concrete
fill 329 195 639 329 240 639 minecraft:magenta_concrete
setblock 329 195 640 minecraft:crying_obsidian
fill 329 195 641 329 209 643 minecraft:magenta_concrete
setblock 331 195 604 minecraft:magenta_stained_glass
fill 335 195 604 335 216 604 minecraft:magenta_concrete
fill 339 195 604 342 201 604 minecraft:magenta_concrete
setblock 343 195 604 minecraft:magenta_stained_glass
fill 345 195 622 347 195 624 minecraft:redstone_block
fill 346 195 621 346 196 621 minecraft:shroomlight
fill 346 195 625 347 196 627 minecraft:orange_concrete
fill 346 195 629 348 195 631 minecraft:redstone_block
fill 347 195 620 349 195 620 minecraft:shroomlight
fill 348 195 621 349 196 623 minecraft:orange_concrete
fill 349 195 629 352 196 630 minecraft:orange_concrete
fill 349 195 631 349 196 631 minecraft:shroomlight
fill 350 195 621 351 196 622 minecraft:orange_concrete
fill 351 195 620 353 195 620 minecraft:shroomlight
fill 351 195 623 351 196 623 minecraft:orange_concrete
fill 351 195 628 352 196 628 minecraft:orange_concrete
fill 351 195 631 353 195 631 minecraft:shroomlight
fill 352 195 621 354 195 623 minecraft:redstone_block
fill 353 195 604 353 240 604 minecraft:magenta_concrete
fill 353 195 628 355 195 630 minecraft:redstone_block
setblock 355 195 627 minecraft:orange_concrete
fill 355 195 646 355 230 646 minecraft:magenta_concrete
fill 371 195 616 371 240 616 minecraft:magenta_concrete
fill 371 195 635 371 211 635 minecraft:magenta_concrete
setblock 371 195 636 minecraft:magenta_stained_glass
fill 371 195 637 371 240 637 minecraft:magenta_concrete
fill 329 196 622 329 225 623 minecraft:magenta_concrete
setblock 329 196 624 minecraft:magenta_stained_glass
fill 329 196 625 329 206 626 minecraft:magenta_concrete
fill 329 196 630 329 205 630 minecraft:magenta_concrete
fill 329 196 640 329 240 640 minecraft:magenta_concrete
fill 331 196 604 331 240 604 minecraft:magenta_concrete
fill 343 196 604 343 227 604 minecraft:magenta_concrete
fill 345 196 627 345 196 628 minecraft:shroomlight
setblock 347 196 621 minecraft:shroomlight
fill 348 196 620 352 196 620 minecraft:shroomlight
fill 350 196 631 352 196 631 minecraft:shroomlight
fill 355 196 623 355 196 624 minecraft:shroomlight
setblock 355 196 627 minecraft:shroomlight
fill 371 196 636 371 240 636 minecraft:magenta_concrete
fill 329 197 624 329 201 624 minecraft:magenta_concrete
setblock 329 197 645 minecraft:white_concrete
fill 330 197 605 343 197 645 minecraft:black_concrete
fill 344 197 605 350 197 620 minecraft:black_concrete
fill 344 197 621 344 197 625 minecraft:crying_obsidian
fill 344 197 626 344 197 645 minecraft:black_concrete
fill 345 197 621 348 197 621 minecraft:crying_obsidian
fill 345 197 622 347 197 624 minecraft:black_concrete
fill 345 197 625 347 197 625 minecraft:crying_obsidian
fill 345 197 626 345 197 627 minecraft:shroomlight
fill 345 197 628 345 197 632 minecraft:crying_obsidian
fill 345 197 633 370 197 645 minecraft:black_concrete
fill 346 197 626 347 197 627 minecraft:orange_concrete
fill 346 197 628 348 197 628 minecraft:crying_obsidian
fill 346 197 629 348 197 631 minecraft:black_concrete
fill 346 197 632 349 197 632 minecraft:crying_obsidian
fill 348 197 622 348 197 624 minecraft:crying_obsidian
fill 348 197 625 348 197 627 minecraft:ochre_froglight
fill 349 197 621 350 197 621 minecraft:shroomlight
fill 349 197 622 349 197 623 minecraft:orange_concrete
fill 349 197 624 351 197 624 minecraft:ochre_froglight
fill 349 197 628 351 197 628 minecraft:ochre_froglight
fill 349 197 629 349 197 631 minecraft:crying_obsidian
setblock 350 197 622 minecraft:orange_concrete
fill 350 197 629 351 197 629 minecraft:orange_concrete
fill 350 197 630 351 197 630 minecraft:shroomlight
fill 350 197 631 351 197 632 minecraft:black_concrete
fill 351 197 605 370 197 619 minecraft:black_concrete
fill 351 197 620 351 197 623 minecraft:crying_obsidian
fill 352 197 620 355 197 620 minecraft:crying_obsidian
fill 352 197 621 354 197 623 minecraft:black_concrete
fill 352 197 624 355 197 624 minecraft:crying_obsidian
fill 352 197 625 352 197 627 minecraft:ochre_froglight
fill 352 197 628 352 197 631 minecraft:crying_obsidian
fill 352 197 632 370 197 632 minecraft:black_concrete
fill 353 197 625 354 197 626 minecraft:orange_concrete
fill 353 197 627 356 197 627 minecraft:crying_obsidian
fill 353 197 628 355 197 630 minecraft:black_concrete
fill 353 197 631 356 197 631 minecraft:crying_obsidian
fill 355 197 621 355 197 623 minecraft:crying_obsidian
fill 355 197 625 355 197 626 minecraft:shroomlight
fill 356 197 620 370 197 626 minecraft:black_concrete
fill 356 197 628 356 197 630 minecraft:crying_obsidian
fill 357 197 627 370 197 631 minecraft:black_concrete
setblock 371 197 622 minecraft:crying_obsidian
fill 329 198 645 329 230 645 minecraft:magenta_concrete
fill 337 198 617 346 206 635 minecraft:smooth_stone
fill 347 198 617 347 206 635 minecraft:oak_planks
fill 348 198 622 349 198 623 minecraft:shroomlight
fill 348 198 624 348 198 627 minecraft:orange_concrete
fill 348 198 628 349 198 629 minecraft:shroomlight
fill 349 198 624 352 198 624 minecraft:orange_concrete
fill 350 198 622 352 198 622 minecraft:shroomlight
setblock 350 198 628 minecraft:orange_concrete
fill 350 198 629 352 198 629 minecraft:shroomlight
fill 351 198 623 353 198 623 minecraft:shroomlight
fill 351 198 628 353 198 628 minecraft:shroomlight
fill 352 198 625 352 198 627 minecraft:orange_concrete
fill 353 198 624 353 198 627 minecraft:shroomlight
fill 354 198 617 354 206 635 minecraft:oak_planks
fill 355 198 617 363 206 635 minecraft:smooth_stone
setblock 362 198 646 minecraft:white_concrete
fill 371 198 622 371 236 622 minecraft:magenta_concrete
setblock 371 198 644 minecraft:magenta_stained_glass
setblock 329 199 633 minecraft:crying_obsidian
fill 345 199 646 347 224 646 minecraft:magenta_concrete
fill 348 199 624 348 199 627 minecraft:shroomlight
setblock 348 199 646 minecraft:magenta_stained_glass
setblock 349 199 604 minecraft:magenta_stained_glass
fill 349 199 624 352 199 624 minecraft:shroomlight
fill 349 199 646 354 205 646 minecraft:magenta_concrete
setblock 350 199 623 minecraft:shroomlight
setblock 350 199 628 minecraft:shroomlight
fill 352 199 625 352 199 627 minecraft:shroomlight
fill 362 199 646 362 202 646 minecraft:magenta_concrete
setblock 371 199 621 minecraft:crying_obsidian
fill 371 199 644 371 238 644 minecraft:magenta_concrete
fill 329 200 633 329 219 633 minecraft:magenta_concrete
fill 339 200 646 340 215 646 minecraft:magenta_concrete
setblock 341 200 646 minecraft:magenta_stained_glass
fill 348 200 646 348 201 646 minecraft:magenta_concrete
fill 349 200 604 349 240 604 minecraft:magenta_concrete
setblock 366 200 604 minecraft:crying_obsidian
setblock 371 200 617 minecraft:crying_obsidian
fill 371 200 621 371 239 621 minecraft:magenta_concrete
setblock 371 200 630 minecraft:magenta_stained_glass
setblock 330 201 646 minecraft:crying_obsidian
setblock 332 201 607 minecraft:light[level=12]
setblock 332 201 615 minecraft:light[level=12]
setblock 332 201 623 minecraft:light[level=12]
setblock 332 201 631 minecraft:light[level=12]
setblock 332 201 639 minecraft:light[level=12]
setblock 340 201 607 minecraft:light[level=12]
setblock 340 201 615 minecraft:light[level=12]
setblock 340 201 639 minecraft:light[level=12]
fill 341 201 646 341 214 646 minecraft:magenta_concrete
fill 346 201 639 348 202 640 minecraft:obsidian
setblock 348 201 607 minecraft:light[level=12]
setblock 348 201 615 minecraft:light[level=12]
setblock 348 201 623 minecraft:light[level=12]
setblock 348 201 631 minecraft:light[level=12]
setblock 356 201 607 minecraft:light[level=12]
setblock 356 201 615 minecraft:light[level=12]
setblock 356 201 639 minecraft:light[level=12]
setblock 364 201 607 minecraft:light[level=12]
setblock 364 201 615 minecraft:light[level=12]
setblock 364 201 623 minecraft:light[level=12]
setblock 364 201 631 minecraft:light[level=12]
setblock 364 201 639 minecraft:light[level=12]
fill 366 201 604 366 220 604 minecraft:magenta_concrete
setblock 367 201 646 minecraft:magenta_stained_glass
setblock 370 201 604 minecraft:magenta_stained_glass
fill 371 201 604 371 240 604 minecraft:magenta_concrete
fill 371 201 617 371 240 617 minecraft:magenta_concrete
fill 371 201 630 371 240 630 minecraft:magenta_concrete
setblock 329 202 618 minecraft:magenta_stained_glass
setblock 329 202 624 minecraft:magenta_stained_glass
fill 330 202 646 330 240 646 minecraft:magenta_concrete
setblock 339 202 604 minecraft:crying_obsidian
fill 340 202 604 342 236 604 minecraft:magenta_concrete
setblock 348 202 646 minecraft:magenta_stained_glass
fill 367 202 646 367 240 646 minecraft:magenta_concrete
fill 370 202 604 370 237 604 minecraft:magenta_concrete
fill 371 202 623 371 237 623 minecraft:magenta_concrete
setblock 371 202 624 minecraft:white_concrete
fill 329 203 618 329 240 618 minecraft:magenta_concrete
fill 329 203 624 329 240 624 minecraft:magenta_concrete
fill 339 203 604 339 234 604 minecraft:magenta_concrete
fill 348 203 646 348 234 646 minecraft:magenta_concrete
setblock 362 203 646 minecraft:crying_obsidian
setblock 371 203 607 minecraft:white_concrete
fill 371 203 624 371 214 624 minecraft:magenta_concrete
setblock 371 203 640 minecraft:white_concrete
setblock 357 204 646 minecraft:white_concrete
setblock 362 204 646 minecraft:magenta_concrete
fill 371 204 607 371 210 607 minecraft:magenta_concrete
fill 371 204 640 371 229 640 minecraft:magenta_concrete
setblock 329 205 621 minecraft:white_concrete
setblock 329 205 631 minecraft:white_concrete
fill 336 205 604 336 223 604 minecraft:magenta_concrete
setblock 337 205 604 minecraft:white_concrete
fill 338 205 604 338 240 604 minecraft:magenta_concrete
fill 357 205 646 357 238 646 minecraft:magenta_concrete
setblock 359 205 646 minecraft:magenta_stained_glass
setblock 361 205 604 minecraft:crying_obsidian
setblock 362 205 646 minecraft:white_concrete
setblock 371 205 614 minecraft:white_concrete
fill 329 206 621 329 220 621 minecraft:magenta_concrete
setblock 329 206 630 minecraft:crying_obsidian
fill 329 206 631 329 240 631 minecraft:magenta_concrete
setblock 333 206 646 minecraft:crying_obsidian
fill 337 206 604 337 218 604 minecraft:magenta_concrete
fill 349 206 646 350 237 646 minecraft:magenta_concrete
setblock 351 206 646 minecraft:magenta_stained_glass
fill 352 206 646 354 211 646 minecraft:magenta_concrete
fill 359 206 646 359 240 646 minecraft:magenta_concrete
fill 361 206 604 361 238 604 minecraft:magenta_concrete
fill 362 206 646 362 222 646 minecraft:magenta_concrete
setblock 365 206 646 minecraft:white_concrete
fill 366 206 646 366 236 646 minecraft:magenta_concrete
fill 371 206 614 371 240 614 minecraft:magenta_concrete
setblock 329 207 625 minecraft:white_concrete
fill 329 207 626 329 218 626 minecraft:magenta_concrete
fill 329 207 630 329 217 630 minecraft:magenta_concrete
fill 333 207 646 333 229 646 minecraft:magenta_concrete
fill 351 207 646 351 212 646 minecraft:magenta_concrete
fill 354 207 609 355 208 610 minecraft:magenta_concrete
fill 365 207 646 365 240 646 minecraft:magenta_concrete
fill 329 208 625 329 217 625 minecraft:magenta_concrete
setblock 337 208 624 minecraft:crying_obsidian
setblock 332 209 607 minecraft:light[level=12]
setblock 332 209 615 minecraft:light[level=12]
setblock 332 209 623 minecraft:light[level=12]
setblock 332 209 631 minecraft:light[level=12]
setblock 332 209 639 minecraft:light[level=12]
fill 336 209 625 336 209 626 minecraft:crying_obsidian
fill 337 209 624 363 210 625 minecraft:iron_block
setblock 340 209 607 minecraft:light[level=12]
setblock 340 209 615 minecraft:light[level=12]
setblock 340 209 623 minecraft:light[level=12]
setblock 340 209 631 minecraft:light[level=12]
setblock 340 209 639 minecraft:light[level=12]
setblock 348 209 607 minecraft:light[level=12]
setblock 348 209 615 minecraft:light[level=12]
setblock 348 209 623 minecraft:light[level=12]
setblock 348 209 631 minecraft:light[level=12]
setblock 348 209 639 minecraft:light[level=12]
setblock 356 209 607 minecraft:light[level=12]
setblock 356 209 615 minecraft:light[level=12]
setblock 356 209 623 minecraft:light[level=12]
setblock 356 209 631 minecraft:light[level=12]
setblock 356 209 639 minecraft:light[level=12]
setblock 363 209 646 minecraft:magenta_stained_glass
setblock 364 209 607 minecraft:light[level=12]
setblock 364 209 615 minecraft:light[level=12]
setblock 364 209 623 minecraft:light[level=12]
setblock 364 209 631 minecraft:light[level=12]
setblock 364 209 639 minecraft:light[level=12]
setblock 371 209 627 minecraft:white_concrete
fill 329 210 637 329 240 637 minecraft:magenta_concrete
setblock 329 210 638 minecraft:magenta_stained_glass
setblock 329 210 641 minecraft:crying_obsidian
fill 329 210 642 329 226 643 minecraft:magenta_concrete
fill 335 210 626 336 210 627 minecraft:crying_obsidian
fill 363 210 646 363 240 646 minecraft:magenta_concrete
setblock 371 210 627 minecraft:magenta_concrete
fill 329 211 638 329 240 638 minecraft:magenta_concrete
fill 329 211 641 329 240 641 minecraft:magenta_concrete
fill 334 211 628 334 212 629 minecraft:crying_obsidian
fill 335 211 627 335 211 628 minecraft:crying_obsidian
setblock 350 211 604 minecraft:magenta_stained_glass
setblock 371 211 607 minecraft:white_concrete
setblock 371 211 627 minecraft:crying_obsidian
setblock 329 212 605 minecraft:crying_obsidian
setblock 329 212 608 minecraft:magenta_stained_glass
fill 333 212 629 333 212 630 minecraft:crying_obsidian
setblock 334 212 630 minecraft:crying_obsidian
fill 343 212 646 343 236 646 minecraft:magenta_concrete
setblock 344 212 646 minecraft:magenta_stained_glass
fill 350 212 604 350 240 604 minecraft:magenta_concrete
setblock 352 212 646 minecraft:magenta_stained_glass
fill 353 212 646 354 229 646 minecraft:magenta_concrete
fill 371 212 607 371 240 607 minecraft:magenta_concrete
fill 371 212 627 371 242 627 minecraft:magenta_concrete
setblock 371 212 635 minecraft:crying_obsidian
fill 329 213 605 329 237 605 minecraft:magenta_concrete
fill 329 213 608 329 240 608 minecraft:magenta_concrete
fill 332 213 631 332 214 632 minecraft:crying_obsidian
fill 333 213 630 333 213 631 minecraft:crying_obsidian
fill 344 213 646 344 235 646 minecraft:magenta_concrete
setblock 351 213 646 minecraft:crying_obsidian
fill 352 213 646 352 240 646 minecraft:magenta_concrete
fill 371 213 635 371 240 635 minecraft:magenta_concrete
fill 351 214 646 351 223 646 minecraft:magenta_concrete
setblock 356 214 604 minecraft:white_concrete
setblock 371 214 632 minecraft:crying_obsidian
fill 371 214 633 371 229 633 minecraft:magenta_concrete
fill 336 215 616 336 216 616 minecraft:gold_block
setblock 341 215 646 minecraft:magenta_stained_glass
fill 356 215 604 356 237 604 minecraft:magenta_concrete
setblock 371 215 624 minecraft:white_concrete
fill 371 215 632 371 219 632 minecraft:magenta_concrete
setblock 338 216 646 minecraft:magenta_stained_glass
setblock 339 216 646 minecraft:white_concrete
fill 340 216 646 341 223 646 minecraft:magenta_concrete
setblock 344 216 604 minecraft:magenta_stained_glass
setblock 371 216 619 minecraft:white_concrete
fill 371 216 624 371 240 624 minecraft:magenta_concrete
setblock 329 217 611 minecraft:magenta_stained_glass
setblock 332 217 607 minecraft:light[level=12]
setblock 332 217 615 minecraft:light[level=12]
setblock 332 217 623 minecraft:light[level=12]
setblock 332 217 631 minecraft:light[level=12]
setblock 332 217 639 minecraft:light[level=12]
setblock 335 217 604 minecraft:white_concrete
fill 335 217 627 335 222 627 minecraft:red_terracotta
fill 338 217 646 339 233 646 minecraft:magenta_concrete
setblock 340 217 607 minecraft:light[level=12]
setblock 340 217 615 minecraft:light[level=12]
setblock 340 217 623 minecraft:light[level=12]
setblock 340 217 631 minecraft:light[level=12]
setblock 340 217 639 minecraft:light[level=12]
fill 344 217 604 344 241 604 minecraft:magenta_concrete
setblock 348 217 607 minecraft:light[level=12]
setblock 348 217 615 minecraft:light[level=12]
setblock 348 217 623 minecraft:light[level=12]
setblock 348 217 631 minecraft:light[level=12]
setblock 348 217 639 minecraft:light[level=12]
setblock 354 217 604 minecraft:crying_obsidian
fill 355 217 604 355 227 604 minecraft:magenta_concrete
setblock 356 217 607 minecraft:light[level=12]
setblock 356 217 615 minecraft:light[level=12]
setblock 356 217 623 minecraft:light[level=12]
setblock 356 217 631 minecraft:light[level=12]
setblock 356 217 639 minecraft:light[level=12]
setblock 364 217 607 minecraft:light[level=12]
setblock 364 217 615 minecraft:light[level=12]
setblock 364 217 623 minecraft:light[level=12]
setblock 364 217 631 minecraft:light[level=12]
setblock 364 217 639 minecraft:light[level=12]
fill 371 217 619 371 240 619 minecraft:magenta_concrete
fill 329 218 611 329 240 611 minecraft:magenta_concrete
setblock 329 218 625 minecraft:crying_obsidian
setblock 329 218 630 minecraft:magenta_stained_glass
fill 333 218 627 334 221 628 minecraft:red_terracotta
fill 334 218 626 336 221 626 minecraft:red_terracotta
fill 334 218 629 335 221 629 minecraft:red_terracotta
fill 335 218 604 335 221 604 minecraft:magenta_concrete
fill 335 218 628 336 221 628 minecraft:red_terracotta
fill 336 218 627 336 221 627 minecraft:red_terracotta
fill 354 218 604 354 237 604 minecraft:magenta_concrete
fill 371 218 609 371 238 609 minecraft:magenta_concrete
setblock 371 218 610 minecraft:crying_obsidian
fill 371 218 611 371 233 612 minecraft:magenta_concrete
fill 329 219 625 329 237 625 minecraft:magenta_concrete
setblock 329 219 626 minecraft:magenta_stained_glass
fill 329 219 630 329 231 630 minecraft:magenta_concrete
fill 333 219 626 333 220 626 minecraft:red_terracotta
fill 334 219 625 336 220 625 minecraft:red_terracotta
fill 336 219 629 336 220 629 minecraft:red_terracotta
setblock 337 219 604 minecraft:crying_obsidian
fill 337 219 626 337 220 628 minecraft:red_terracotta
fill 371 219 610 371 240 610 minecraft:magenta_concrete
fill 329 220 626 329 240 626 minecraft:magenta_concrete
setblock 329 220 632 minecraft:white_concrete
setblock 329 220 633 minecraft:magenta_stained_glass
fill 337 220 604 337 238 604 minecraft:magenta_concrete
setblock 371 220 632 minecraft:magenta_stained_glass
setblock 329 221 621 minecraft:crying_obsidian
fill 329 221 632 329 221 633 minecraft:magenta_concrete
fill 366 221 604 367 221 604 minecraft:magenta_stained_glass
fill 368 221 604 368 241 604 minecraft:magenta_concrete
fill 371 221 632 371 236 632 minecraft:magenta_concrete
fill 329 222 621 329 229 621 minecraft:magenta_concrete
fill 329 222 632 329 240 632 minecraft:magenta_concrete
setblock 329 222 633 minecraft:crying_obsidian
setblock 335 222 604 minecraft:crying_obsidian
setblock 359 222 604 minecraft:white_concrete
fill 366 222 604 367 237 604 minecraft:magenta_concrete
setblock 371 222 638 minecraft:magenta_stained_glass
fill 329 223 633 329 241 633 minecraft:magenta_concrete
fill 335 223 604 335 236 604 minecraft:magenta_concrete
fill 353 223 638 353 224 638 minecraft:crying_obsidian
fill 359 223 604 359 240 604 minecraft:magenta_concrete
setblock 362 223 646 minecraft:magenta_stained_glass
setblock 364 223 646 minecraft:crying_obsidian
fill 371 223 638 371 240 638 minecraft:magenta_concrete
setblock 336 224 604 minecraft:white_concrete
setblock 340 224 646 minecraft:crying_obsidian
fill 341 224 646 341 240 646 minecraft:magenta_concrete
fill 345 224 613 345 225 613 minecraft:gold_block
setblock 351 224 646 minecraft:white_concrete
fill 354 224 637 354 224 638 minecraft:crying_obsidian
fill 355 224 638 355 225 638 minecraft:crying_obsidian
setblock 362 224 604 minecraft:magenta_stained_glass
fill 362 224 646 362 240 646 minecraft:magenta_concrete
fill 363 224 604 363 240 604 minecraft:magenta_concrete
fill 364 224 646 364 225 646 minecraft:magenta_concrete
setblock 329 225 617 minecraft:magenta_stained_glass
setblock 332 225 607 minecraft:light[level=12]
setblock 332 225 615 minecraft:light[level=12]
setblock 332 225 623 minecraft:light[level=12]
setblock 332 225 631 minecraft:light[level=12]
setblock 332 225 639 minecraft:light[level=12]
fill 336 225 604 336 236 604 minecraft:magenta_concrete
setblock 340 225 607 minecraft:light[level=12]
setblock 340 225 615 minecraft:light[level=12]
setblock 340 225 623 minecraft:light[level=12]
setblock 340 225 631 minecraft:light[level=12]
setblock 340 225 639 minecraft:light[level=12]
fill 340 225 646 340 237 646 minecraft:magenta_concrete
setblock 345 225 646 minecraft:crying_obsidian
fill 346 225 646 347 228 646 minecraft:magenta_concrete
setblock 348 225 607 minecraft:light[level=12]
setblock 348 225 615 minecraft:light[level=12]
setblock 348 225 623 minecraft:light[level=12]
setblock 348 225 631 minecraft:light[level=12]
setblock 348 225 639 minecraft:light[level=12]
fill 351 225 646 351 235 646 minecraft:magenta_concrete
fill 353 225 617 354 226 618 minecraft:obsidian
fill 354 225 642 355 226 643 minecraft:obsidian
fill 355 225 618 355 226 618 minecraft:obsidian
setblock 356 225 607 minecraft:light[level=12]
setblock 356 225 615 minecraft:light[level=12]
setblock 356 225 623 minecraft:light[level=12]
setblock 356 225 631 minecraft:light[level=12]
fill 356 225 638 356 225 639 minecraft:crying_obsidian
setblock 356 225 646 minecraft:white_concrete
fill 357 225 639 357 226 639 minecraft:crying_obsidian
fill 362 225 604 362 240 604 minecraft:magenta_concrete
setblock 364 225 607 minecraft:light[level=12]
setblock 364 225 615 minecraft:light[level=12]
setblock 364 225 623 minecraft:light[level=12]
setblock 364 225 631 minecraft:light[level=12]
setblock 364 225 639 minecraft:light[level=12]
setblock 371 225 626 minecraft:white_concrete
setblock 371 225 631 minecraft:white_concrete
fill 329 226 617 329 240 617 minecraft:magenta_concrete
setblock 329 226 622 minecraft:magenta_stained_glass
fill 329 226 623 329 240 623 minecraft:magenta_concrete
fill 345 226 646 345 230 646 minecraft:magenta_concrete
fill 348 226 640 349 227 640 minecraft:gold_block
fill 349 226 639 349 227 639 minecraft:gold_block
fill 356 226 646 356 233 646 minecraft:magenta_concrete
setblock 357 226 638 minecraft:crying_obsidian
fill 358 226 639 359 227 639 minecraft:crying_obsidian
setblock 364 226 646 minecraft:magenta_stained_glass
fill 371 226 626 371 240 626 minecraft:magenta_concrete
fill 371 226 631 371 240 631 minecraft:magenta_concrete
setblock 371 226 642 minecraft:crying_obsidian
fill 329 227 604 329 237 604 minecraft:magenta_concrete
fill 329 227 622 329 241 622 minecraft:magenta_concrete
fill 329 227 642 329 240 642 minecraft:magenta_concrete
setblock 329 227 643 minecraft:magenta_stained_glass
setblock 330 227 604 minecraft:white_concrete
fill 359 227 640 360 227 640 minecraft:crying_obsidian
fill 360 227 639 360 228 639 minecraft:crying_obsidian
fill 364 227 646 364 240 646 minecraft:magenta_concrete
setblock 371 227 629 minecraft:white_concrete
fill 371 227 642 371 240 642 minecraft:magenta_concrete
setblock 329 228 619 minecraft:white_concrete
fill 329 228 620 329 240 620 minecraft:magenta_concrete
fill 329 228 643 329 237 643 minecraft:magenta_concrete
fill 330 228 604 330 240 604 minecraft:magenta_concrete
setblock 332 228 604 minecraft:crying_obsidian
fill 335 228 613 336 229 614 minecraft:gold_block
fill 341 228 635 341 229 635 minecraft:magenta_stained_glass
setblock 343 228 604 minecraft:crying_obsidian
setblock 351 228 604 minecraft:crying_obsidian
fill 352 228 604 352 240 604 minecraft:magenta_concrete
setblock 355 228 604 minecraft:crying_obsidian
fill 360 228 640 362 228 640 minecraft:crying_obsidian
setblock 361 228 639 minecraft:crying_obsidian
fill 371 228 629 371 234 629 minecraft:magenta_concrete
fill 329 229 619 329 236 619 minecraft:magenta_concrete
fill 332 229 604 332 240 604 minecraft:magenta_concrete
setblock 334 229 646 minecraft:crying_obsidian
fill 343 229 604 343 237 604 minecraft:magenta_concrete
setblock 346 229 646 minecraft:magenta_stained_glass
fill 347 229 646 347 240 646 minecraft:magenta_concrete
fill 351 229 604 351 240 604 minecraft:magenta_concrete
fill 355 229 604 355 238 604 minecraft:magenta_concrete
setblock 358 229 646 minecraft:magenta_stained_glass
fill 361 229 640 362 229 640 minecraft:crying_obsidian
setblock 329 230 621 minecraft:white_concrete
setblock 333 230 646 minecraft:magenta_stained_glass
fill 334 230 646 334 233 646 minecraft:magenta_concrete
fill 341 230 635 341 237 635 minecraft:black_concrete
fill 346 230 646 346 240 646 minecraft:magenta_concrete
fill 353 230 638 353 231 638 minecraft:crying_obsidian
fill 353 230 646 353 238 646 minecraft:magenta_concrete
setblock 354 230 646 minecraft:magenta_stained_glass
fill 358 230 646 358 237 646 minecraft:magenta_concrete
setblock 371 230 633 minecraft:white_concrete
setblock 371 230 640 minecraft:white_concrete
fill 329 231 621 329 240 621 minecraft:magenta_concrete
setblock 329 231 627 minecraft:white_concrete
setblock 329 231 645 minecraft:white_concrete
fill 333 231 646 333 238 646 minecraft:magenta_concrete
fill 340 231 616 340 232 616 minecraft:crying_obsidian
fill 341 231 636 341 237 636 minecraft:black_concrete
setblock 345 231 646 minecraft:white_concrete
fill 354 231 638 355 232 638 minecraft:crying_obsidian
fill 354 231 646 354 240 646 minecraft:magenta_concrete
setblock 355 231 646 minecraft:white_concrete
fill 371 231 633 371 240 633 minecraft:magenta_concrete
fill 371 231 640 371 233 640 minecraft:magenta_concrete
fill 329 232 627 329 240 627 minecraft:magenta_concrete
setblock 329 232 630 minecraft:white_concrete
fill 329 232 645 329 234 645 minecraft:magenta_concrete
setblock 334 232 604 minecraft:white_concrete
fill 339 232 616 339 232 617 minecraft:crying_obsidian
setblock 340 232 617 minecraft:crying_obsidian
fill 340 232 635 340 237 636 minecraft:black_concrete
fill 341 232 634 341 237 634 minecraft:black_concrete
fill 342 232 635 342 237 636 minecraft:black_concrete
fill 345 232 646 345 237 646 minecraft:magenta_concrete
fill 348 232 634 349 233 635 minecraft:magenta_concrete
fill 355 232 639 356 232 639 minecraft:crying_obsidian
fill 355 232 646 355 240 646 minecraft:magenta_concrete
setblock 356 232 638 minecraft:crying_obsidian
fill 363 232 637 364 233 638 minecraft:obsidian
fill 329 233 630 329 240 630 minecraft:magenta_concrete
setblock 332 233 607 minecraft:light[level=12]
setblock 332 233 615 minecraft:light[level=12]
setblock 332 233 623 minecraft:light[level=12]
setblock 332 233 631 minecraft:light[level=12]
setblock 332 233 639 minecraft:light[level=12]
fill 334 233 604 334 240 604 minecraft:magenta_concrete
fill 337 233 617 339 233 617 minecraft:crying_obsidian
setblock 340 233 607 minecraft:light[level=12]
setblock 340 233 615 minecraft:light[level=12]
setblock 340 233 623 minecraft:light[level=12]
setblock 340 233 631 minecraft:light[level=12]
fill 340 233 634 340 237 634 minecraft:black_concrete
setblock 340 233 639 minecraft:light[level=12]
fill 341 233 637 341 237 637 minecraft:black_concrete
fill 342 233 634 342 237 634 minecraft:black_concrete
setblock 348 233 607 minecraft:light[level=12]
setblock 348 233 615 minecraft:light[level=12]
setblock 348 233 623 minecraft:light[level=12]
setblock 348 233 631 minecraft:light[level=12]
setblock 348 233 639 minecraft:light[level=12]
setblock 356 233 607 minecraft:light[level=12]
setblock 356 233 615 minecraft:light[level=12]
setblock 356 233 623 minecraft:light[level=12]
setblock 356 233 631 minecraft:light[level=12]
fill 356 233 639 358 233 639 minecraft:crying_obsidian
setblock 364 233 607 minecraft:light[level=12]
setblock 364 233 615 minecraft:light[level=12]
setblock 364 233 623 minecraft:light[level=12]
setblock 364 233 631 minecraft:light[level=12]
setblock 364 233 639 minecraft:light[level=12]
setblock 365 233 604 minecraft:magenta_stained_glass
setblock 371 233 625 minecraft:crying_obsidian
setblock 334 234 646 minecraft:white_concrete
fill 335 234 618 337 234 618 minecraft:crying_obsidian
fill 336 234 617 337 234 617 minecraft:crying_obsidian
fill 338 234 646 338 241 646 minecraft:magenta_concrete
fill 339 234 634 339 237 636 minecraft:black_concrete
setblock 339 234 646 minecraft:magenta_stained_glass
fill 340 234 637 340 237 637 minecraft:black_concrete
fill 341 234 633 341 237 633 minecraft:black_concrete
fill 342 234 637 342 237 637 minecraft:black_concrete
fill 343 234 634 343 237 636 minecraft:black_concrete
setblock 356 234 646 minecraft:white_concrete
fill 358 234 639 359 234 640 minecraft:crying_obsidian
fill 360 234 640 360 235 640 minecraft:crying_obsidian
fill 365 234 604 365 240 604 minecraft:magenta_concrete
fill 371 234 611 371 241 611 minecraft:magenta_concrete
setblock 371 234 612 minecraft:white_concrete
fill 371 234 625 371 237 625 minecraft:magenta_concrete
setblock 371 234 640 minecraft:magenta_stained_glass
setblock 329 235 645 minecraft:white_concrete
fill 334 235 618 335 235 618 minecraft:crying_obsidian
fill 334 235 646 334 241 646 minecraft:magenta_concrete
setblock 339 235 604 minecraft:white_concrete
fill 339 235 610 340 236 610 minecraft:gold_block
fill 339 235 637 339 237 637 minecraft:black_concrete
fill 339 235 646 339 241 646 minecraft:magenta_concrete
fill 340 235 633 340 237 633 minecraft:black_concrete
fill 341 235 638 341 237 638 minecraft:black_concrete
fill 342 235 633 342 237 633 minecraft:black_concrete
fill 343 235 637 343 237 637 minecraft:black_concrete
setblock 348 235 604 minecraft:crying_obsidian
setblock 348 235 646 minecraft:magenta_stained_glass
fill 356 235 646 356 241 646 minecraft:magenta_concrete
setblock 359 235 640 minecraft:crying_obsidian
fill 361 235 640 361 236 641 minecraft:crying_obsidian
fill 368 235 646 369 237 646 minecraft:magenta_concrete
setblock 370 235 646 minecraft:white_concrete
fill 371 235 612 371 240 612 minecraft:magenta_concrete
setblock 371 235 629 minecraft:white_concrete
fill 371 235 640 371 240 640 minecraft:magenta_concrete
fill 371 235 646 371 241 646 minecraft:magenta_concrete
setblock 329 236 615 minecraft:crying_obsidian
fill 329 236 645 329 240 645 minecraft:magenta_concrete
fill 332 236 618 333 236 619 minecraft:crying_obsidian
setblock 334 236 618 minecraft:crying_obsidian
fill 338 236 634 338 237 636 minecraft:black_concrete
fill 339 236 604 339 240 604 minecraft:magenta_concrete
fill 339 236 633 339 237 633 minecraft:black_concrete
fill 340 236 638 340 237 638 minecraft:black_concrete
fill 341 236 632 341 237 632 minecraft:black_concrete
fill 342 236 638 342 237 638 minecraft:black_concrete
fill 343 236 633 343 237 633 minecraft:black_concrete
fill 344 236 634 344 237 636 minecraft:black_concrete
setblock 344 236 646 minecraft:crying_obsidian
fill 348 236 604 348 240 604 minecraft:magenta_concrete
setblock 348 236 646 minecraft:magenta_concrete
setblock 351 236 646 minecraft:crying_obsidian
fill 354 236 641 356 237 642 minecraft:obsidian
setblock 370 236 646 minecraft:magenta_concrete
fill 371 236 629 371 240 629 minecraft:magenta_concrete
fill 329 237 615 329 240 615 minecraft:magenta_concrete
setblock 329 237 616 minecraft:white_concrete
setblock 329 237 619 minecraft:purple_concrete
setblock 329 237 634 minecraft:magenta_concrete
setblock 329 237 635 minecraft:purple_concrete
setblock 329 237 636 minecraft:white_concrete
setblock 329 237 644 minecraft:purple_concrete
setblock 329 237 646 minecraft:purple_concrete
setblock 332 237 619 minecraft:crying_obsidian
setblock 335 237 604 minecraft:purple_concrete
setblock 336 237 604 minecraft:crying_obsidian
setblock 338 237 633 minecraft:black_concrete
setblock 338 237 637 minecraft:black_concrete
fill 339 237 632 340 237 632 minecraft:black_concrete
setblock 339 237 638 minecraft:black_concrete
setblock 340 237 604 minecraft:magenta_concrete
setblock 341 237 604 minecraft:purple_concrete
fill 342 237 604 342 240 604 minecraft:magenta_concrete
fill 342 237 632 343 237 632 minecraft:black_concrete
setblock 343 237 638 minecraft:black_concrete
fill 343 237 646 344 237 646 minecraft:purple_concrete
setblock 344 237 633 minecraft:black_concrete
setblock 344 237 637 minecraft:black_concrete
setblock 348 237 646 minecraft:purple_concrete
fill 351 237 646 351 240 646 minecraft:magenta_concrete
setblock 358 237 604 minecraft:crying_obsidian
setblock 360 237 604 minecraft:purple_concrete
setblock 366 237 646 minecraft:purple_concrete
setblock 370 237 646 minecraft:magenta_stained_glass
setblock 371 237 622 minecraft:purple_concrete
fill 371 237 632 371 238 632 minecraft:purple_concrete
setblock 329 238 604 minecraft:purple_concrete
setblock 329 238 605 minecraft:magenta_stained_glass
setblock 329 238 613 minecraft:crying_obsidian
fill 329 238 616 329 240 616 minecraft:magenta_concrete
fill 329 238 619 329 240 619 minecraft:magenta_concrete
setblock 329 238 625 minecraft:purple_concrete
setblock 329 238 634 minecraft:purple_concrete
fill 329 238 635 329 240 636 minecraft:magenta_concrete
setblock 329 238 643 minecraft:purple_concrete
fill 329 238 644 329 240 644 minecraft:magenta_concrete
fill 329 238 646 329 240 646 minecraft:magenta_concrete
fill 335 238 604 336 240 604 minecraft:magenta_concrete
setblock 335 238 646 minecraft:purple_concrete
setblock 340 238 604 minecraft:purple_concrete
setblock 340 238 646 minecraft:purple_concrete
fill 341 238 604 341 240 604 minecraft:magenta_concrete
setblock 343 238 604 minecraft:purple_concrete
fill 343 238 646 344 240 646 minecraft:magenta_concrete
setblock 345 238 646 minecraft:purple_concrete
fill 348 238 646 348 240 646 minecraft:magenta_concrete
setblock 349 238 646 minecraft:purple_concrete
fill 350 238 646 350 240 646 minecraft:magenta_concrete
fill 354 238 604 354 239 604 minecraft:purple_concrete
setblock 356 238 604 minecraft:purple_concrete
fill 358 238 604 358 240 604 minecraft:magenta_concrete
setblock 358 238 646 minecraft:purple_concrete
fill 360 238 604 360 240 604 minecraft:magenta_concrete
fill 366 238 604 366 240 604 minecraft:magenta_concrete
fill 366 238 646 366 241 646 minecraft:magenta_concrete
setblock 367 238 604 minecraft:purple_concrete
setblock 368 238 646 minecraft:purple_concrete
fill 369 238 646 370 240 646 minecraft:magenta_concrete
setblock 370 238 604 minecraft:magenta_stained_glass
setblock 371 238 618 minecraft:purple_concrete
fill 371 238 622 371 240 622 minecraft:magenta_concrete
fill 371 238 623 371 239 623 minecraft:purple_concrete
setblock 371 238 625 minecraft:purple_concrete
fill 329 239 604 329 240 605 minecraft:magenta_concrete
fill 329 239 613 329 240 613 minecraft:magenta_concrete
fill 329 239 625 329 240 625 minecraft:magenta_concrete
fill 329 239 634 329 240 634 minecraft:magenta_concrete
fill 329 239 643 329 240 643 minecraft:magenta_concrete
setblock 333 239 646 minecraft:purple_concrete
fill 335 239 646 335 240 646 minecraft:magenta_concrete
setblock 337 239 604 minecraft:purple_concrete
fill 340 239 604 340 240 604 minecraft:magenta_concrete
fill 340 239 646 340 240 646 minecraft:magenta_concrete
setblock 342 239 646 minecraft:purple_concrete
fill 343 239 604 343 240 604 minecraft:magenta_concrete
fill 345 239 646 345 240 646 minecraft:magenta_concrete
setblock 346 239 604 minecraft:purple_concrete
fill 349 239 646 349 240 646 minecraft:magenta_concrete
setblock 353 239 646 minecraft:purple_concrete
setblock 355 239 604 minecraft:purple_concrete
fill 356 239 604 356 240 604 minecraft:magenta_concrete
setblock 357 239 646 minecraft:purple_concrete
fill 358 239 646 358 241 646 minecraft:magenta_concrete
setblock 361 239 604 minecraft:purple_concrete
fill 367 239 604 367 240 604 minecraft:magenta_concrete
fill 368 239 646 368 240 646 minecraft:magenta_concrete
setblock 369 239 604 minecraft:purple_concrete
fill 370 239 604 370 240 604 minecraft:magenta_concrete
setblock 371 239 609 minecraft:purple_concrete
fill 371 239 618 371 240 618 minecraft:magenta_concrete
fill 371 239 625 371 240 625 minecraft:magenta_concrete
fill 371 239 632 371 240 632 minecraft:magenta_concrete
setblock 371 239 634 minecraft:crying_obsidian
setblock 371 239 644 minecraft:purple_concrete
setblock 333 240 646 minecraft:magenta_concrete
setblock 337 240 604 minecraft:magenta_concrete
setblock 342 240 646 minecraft:magenta_concrete
setblock 346 240 604 minecraft:magenta_concrete
setblock 353 240 646 minecraft:magenta_concrete
fill 354 240 604 355 240 604 minecraft:magenta_concrete
setblock 357 240 646 minecraft:magenta_concrete
fill 361 240 604 361 241 604 minecraft:magenta_concrete
setblock 369 240 604 minecraft:magenta_concrete
setblock 371 240 608 minecraft:crying_obsidian
setblock 371 240 609 minecraft:magenta_concrete
setblock 371 240 621 minecraft:magenta_stained_glass
setblock 371 240 623 minecraft:magenta_concrete
setblock 371 240 634 minecraft:magenta_concrete
setblock 371 240 644 minecraft:magenta_concrete
fill 329 241 604 329 242 606 minecraft:purple_concrete
fill 329 241 608 329 241 621 minecraft:purple_concrete
fill 329 241 623 329 241 632 minecraft:purple_concrete
fill 329 241 634 329 254 634 minecraft:purple_concrete
setblock 329 241 635 minecraft:magenta_concrete
fill 329 241 636 329 249 636 minecraft:purple_concrete
setblock 329 241 637 minecraft:magenta_stained_glass
fill 329 241 638 329 247 640 minecraft:purple_concrete
setblock 329 241 641 minecraft:magenta_stained_glass
fill 329 241 642 329 242 646 minecraft:purple_concrete
fill 330 241 604 339 241 604 minecraft:purple_concrete
fill 330 241 646 333 241 646 minecraft:purple_concrete
setblock 332 241 607 minecraft:light[level=12]
setblock 332 241 615 minecraft:light[level=12]
setblock 332 241 623 minecraft:light[level=12]
setblock 332 241 631 minecraft:light[level=12]
setblock 332 241 639 minecraft:light[level=12]
fill 335 241 646 337 247 646 minecraft:purple_concrete
setblock 340 241 604 minecraft:crying_obsidian
setblock 340 241 607 minecraft:light[level=12]
setblock 340 241 615 minecraft:light[level=12]
setblock 340 241 623 minecraft:light[level=12]
setblock 340 241 631 minecraft:light[level=12]
setblock 340 241 639 minecraft:light[level=12]
fill 340 241 646 342 242 646 minecraft:purple_concrete
setblock 341 241 604 minecraft:white_concrete
fill 342 241 604 343 241 604 minecraft:purple_concrete
setblock 343 241 646 minecraft:magenta_concrete
fill 344 241 646 355 242 646 minecraft:purple_concrete
fill 346 241 604 346 265 604 minecraft:purple_concrete
fill 348 241 604 360 241 604 minecraft:purple_concrete
setblock 348 241 607 minecraft:light[level=12]
setblock 348 241 615 minecraft:light[level=12]
setblock 348 241 623 minecraft:light[level=12]
setblock 348 241 631 minecraft:light[level=12]
setblock 348 241 639 minecraft:light[level=12]
setblock 356 241 607 minecraft:light[level=12]
setblock 356 241 615 minecraft:light[level=12]
setblock 356 241 623 minecraft:light[level=12]
setblock 356 241 631 minecraft:light[level=12]
setblock 356 241 639 minecraft:light[level=12]
fill 357 241 646 357 269 646 minecraft:purple_concrete
fill 359 241 646 365 242 646 minecraft:purple_concrete
fill 362 241 604 363 242 604 minecraft:purple_concrete
setblock 364 241 607 minecraft:light[level=12]
setblock 364 241 615 minecraft:light[level=12]
setblock 364 241 623 minecraft:light[level=12]
setblock 364 241 631 minecraft:light[level=12]
setblock 364 241 639 minecraft:light[level=12]
fill 365 241 604 367 242 604 minecraft:purple_concrete
fill 367 241 646 369 241 646 minecraft:purple_concrete
fill 369 241 604 371 241 604 minecraft:purple_concrete
setblock 370 241 646 minecraft:magenta_concrete
fill 371 241 605 371 241 610 minecraft:purple_concrete
fill 371 241 612 371 241 622 minecraft:purple_concrete
setblock 371 241 623 minecraft:magenta_stained_glass
fill 371 241 624 371 256 626 minecraft:purple_concrete
fill 371 241 628 371 241 634 minecraft:purple_concrete
setblock 371 241 635 minecraft:white_concrete
fill 371 241 636 371 241 645 minecraft:purple_concrete
fill 329 242 607 329 242 612 minecraft:purple_concrete
setblock 329 242 613 minecraft:magenta_concrete
fill 329 242 614 329 242 616 minecraft:purple_concrete
fill 329 242 617 329 243 617 minecraft:magenta_concrete
fill 329 242 618 329 242 628 minecraft:purple_concrete
fill 329 242 629 329 242 630 minecraft:magenta_concrete
fill 329 242 631 329 263 633 minecraft:purple_concrete
setblock 329 242 635 minecraft:purple_concrete
fill 329 242 637 329 249 637 minecraft:purple_concrete
fill 329 242 641 329 261 641 minecraft:purple_concrete
fill 330 242 604 332 270 604 minecraft:purple_concrete
setblock 330 242 646 minecraft:magenta_concrete
fill 331 242 646 331 307 646 minecraft:purple_concrete
setblock 332 242 646 minecraft:magenta_concrete
setblock 333 242 604 minecraft:white_concrete
fill 333 242 646 334 247 646 minecraft:purple_concrete
fill 334 242 604 336 265 604 minecraft:purple_concrete
fill 337 242 604 337 243 604 minecraft:magenta_concrete
fill 338 242 604 341 251 604 minecraft:purple_concrete
fill 338 242 646 339 242 646 minecraft:purple_concrete
setblock 342 242 604 minecraft:magenta_concrete
fill 343 242 604 345 252 604 minecraft:purple_concrete
fill 343 242 646 343 251 646 minecraft:purple_concrete
fill 347 242 604 358 251 604 minecraft:purple_concrete
fill 348 242 622 350 242 624 minecraft:redstone_block
fill 350 242 631 352 242 633 minecraft:redstone_block
fill 354 242 622 356 242 624 minecraft:redstone_block
fill 355 242 629 357 242 631 minecraft:redstone_block
fill 356 242 646 356 257 646 minecraft:purple_concrete
fill 358 242 646 358 307 646 minecraft:purple_concrete
setblock 359 242 604 minecraft:magenta_concrete
fill 360 242 604 361 242 604 minecraft:purple_concrete
fill 364 242 604 364 307 604 minecraft:purple_concrete
fill 366 242 646 368 242 646 minecraft:purple_concrete
fill 368 242 604 369 249 604 minecraft:purple_concrete
setblock 369 242 646 minecraft:magenta_concrete
setblock 370 242 604 minecraft:magenta_concrete
fill 370 242 646 371 277 646 minecraft:purple_concrete
fill 371 242 604 371 245 608 minecraft:purple_concrete
setblock 371 242 609 minecraft:magenta_concrete
fill 371 242 610 371 242 621 minecraft:purple_concrete
setblock 371 242 622 minecraft:magenta_concrete
fill 371 242 623 371 307 623 minecraft:purple_concrete
fill 371 242 628 371 242 629 minecraft:purple_concrete
setblock 371 242 630 minecraft:magenta_concrete
fill 371 242 631 371 242 634 minecraft:purple_concrete
setblock 371 242 635 minecraft:magenta_concrete
fill 371 242 636 371 242 641 minecraft:purple_concrete
setblock 371 242 642 minecraft:magenta_concrete
fill 371 242 643 371 261 645 minecraft:purple_concrete
fill 329 243 604 329 307 605 minecraft:purple_concrete
setblock 329 243 606 minecraft:magenta_concrete
fill 329 243 607 329 245 610 minecraft:purple_concrete
setblock 329 243 611 minecraft:magenta_concrete
fill 329 243 612 329 243 614 minecraft:purple_concrete
setblock 329 243 615 minecraft:magenta_concrete
fill 329 243 616 329 250 616 minecraft:purple_concrete
setblock 329 243 618 minecraft:magenta_stained_glass
fill 329 243 619 329 261 621 minecraft:purple_concrete
fill 329 243 622 329 243 624 minecraft:magenta_concrete
fill 329 243 625 329 259 625 minecraft:purple_concrete
setblock 329 243 626 minecraft:magenta_stained_glass
fill 329 243 627 329 247 630 minecraft:purple_concrete
setblock 329 243 635 minecraft:magenta_concrete
fill 329 243 642 329 256 643 minecraft:purple_concrete
setblock 329 243 644 minecraft:magenta_concrete
fill 329 243 645 329 268 646 minecraft:purple_concrete
fill 330 243 646 330 296 646 minecraft:purple_concrete
fill 332 243 646 332 307 646 minecraft:purple_concrete
fill 333 243 604 333 251 604 minecraft:purple_concrete
fill 336 243 627 341 243 627 minecraft:black_concrete
fill 337 243 622 337 244 623 minecraft:magenta_concrete
fill 337 243 624 342 243 626 minecraft:black_concrete
fill 337 243 628 338 244 632 minecraft:black_concrete
fill 338 243 620 338 244 622 minecraft:magenta_concrete
fill 338 243 623 347 243 623 minecraft:black_concrete
fill 338 243 633 338 244 634 minecraft:black_concrete
fill 338 243 646 338 282 646 minecraft:purple_concrete
fill 339 243 618 339 244 621 minecraft:magenta_concrete
fill 339 243 622 347 243 622 minecraft:black_concrete
fill 339 243 628 339 244 631 minecraft:black_concrete
fill 339 243 632 342 243 636 minecraft:magenta_concrete
setblock 339 243 646 minecraft:magenta_concrete
fill 340 243 617 341 244 620 minecraft:magenta_concrete
fill 340 243 621 350 243 621 minecraft:black_concrete
setblock 340 243 628 minecraft:black_concrete
fill 340 243 629 342 243 631 minecraft:magenta_concrete
fill 340 243 637 342 244 637 minecraft:magenta_concrete
fill 340 243 646 341 281 646 minecraft:purple_concrete
fill 341 243 616 343 244 616 minecraft:black_concrete
fill 341 243 628 344 243 628 minecraft:magenta_concrete
fill 341 243 638 342 244 638 minecraft:magenta_concrete
fill 342 243 604 342 245 604 minecraft:purple_concrete
fill 342 243 615 355 243 615 minecraft:black_concrete
fill 342 243 617 349 243 619 minecraft:magenta_concrete
fill 342 243 620 348 243 620 minecraft:black_concrete
fill 342 243 627 345 243 627 minecraft:magenta_concrete
fill 342 243 639 343 244 639 minecraft:magenta_concrete
setblock 342 243 646 minecraft:magenta_concrete
fill 343 243 614 354 244 614 minecraft:black_concrete
fill 343 243 624 343 243 625 minecraft:black_concrete
fill 343 243 626 347 243 626 minecraft:magenta_concrete
fill 343 243 629 343 243 630 minecraft:magenta_concrete
fill 343 243 631 347 243 638 minecraft:black_concrete
fill 343 243 640 343 244 640 minecraft:magenta_concrete
fill 344 243 616 345 244 616 minecraft:magenta_concrete
fill 344 243 624 346 243 624 minecraft:black_concrete
fill 344 243 625 349 243 625 minecraft:magenta_concrete
fill 344 243 629 347 243 630 minecraft:black_concrete
fill 344 243 639 350 243 640 minecraft:black_concrete
fill 344 243 646 345 243 646 minecraft:purple_concrete
fill 345 243 613 353 244 613 minecraft:black_concrete
fill 345 243 628 348 243 628 minecraft:black_concrete
fill 345 243 641 352 244 641 minecraft:black_concrete
fill 346 243 616 356 243 616 minecraft:black_concrete
fill 346 243 627 348 243 627 minecraft:black_concrete
setblock 346 243 646 minecraft:magenta_stained_glass
fill 347 243 612 351 244 612 minecraft:black_concrete
setblock 347 243 624 minecraft:magenta_concrete
fill 347 243 642 354 244 642 minecraft:black_concrete
fill 347 243 646 353 246 646 minecraft:purple_concrete
setblock 348 243 626 minecraft:black_concrete
setblock 348 243 629 minecraft:black_concrete
fill 348 243 630 349 243 635 minecraft:magenta_concrete
fill 348 243 636 348 243 638 minecraft:black_concrete
fill 349 243 620 352 243 620 minecraft:magenta_concrete
fill 349 243 626 350 243 628 minecraft:gold_block
setblock 349 243 629 minecraft:magenta_concrete
fill 349 243 636 351 243 637 minecraft:magenta_concrete
setblock 349 243 638 minecraft:black_concrete
fill 350 243 617 356 243 617 minecraft:black_concrete
fill 350 243 618 350 243 619 minecraft:magenta_concrete
fill 350 243 625 354 243 625 minecraft:gold_block
fill 350 243 629 354 243 629 minecraft:gold_block
setblock 350 243 630 minecraft:black_concrete
fill 350 243 634 350 243 635 minecraft:magenta_concrete
fill 350 243 638 354 243 638 minecraft:magenta_concrete
fill 351 243 618 357 243 618 minecraft:black_concrete
setblock 351 243 619 minecraft:magenta_concrete
fill 351 243 621 353 243 621 minecraft:magenta_concrete
fill 351 243 622 351 243 623 minecraft:black_concrete
fill 351 243 624 353 243 624 minecraft:gold_block
fill 351 243 630 353 243 630 minecraft:gold_block
fill 351 243 634 365 243 635 minecraft:black_concrete
fill 351 243 639 357 243 639 minecraft:magenta_concrete
fill 351 243 640 351 244 640 minecraft:black_concrete
fill 352 243 611 352 244 612 minecraft:magenta_concrete
fill 352 243 619 357 243 619 minecraft:black_concrete
fill 352 243 622 353 243 623 minecraft:magenta_concrete
fill 352 243 636 365 243 636 minecraft:black_concrete
setblock 352 243 637 minecraft:magenta_concrete
fill 352 243 640 361 244 640 minecraft:magenta_concrete
fill 352 243 643 352 244 643 minecraft:black_concrete
fill 353 243 612 357 244 612 minecraft:magenta_concrete
fill 353 243 620 357 243 620 minecraft:black_concrete
fill 353 243 631 354 243 631 minecraft:magenta_concrete
fill 353 243 632 353 243 633 minecraft:black_concrete
fill 353 243 637 364 243 637 minecraft:black_concrete
fill 353 243 641 359 244 641 minecraft:magenta_concrete
fill 354 243 613 358 244 613 minecraft:magenta_concrete
fill 354 243 621 357 243 621 minecraft:black_concrete
fill 354 243 626 355 243 628 minecraft:gold_block
setblock 354 243 630 minecraft:magenta_concrete
fill 354 243 632 363 243 632 minecraft:magenta_concrete
fill 354 243 633 355 243 633 minecraft:black_concrete
setblock 354 243 646 minecraft:magenta_concrete
fill 355 243 614 359 244 614 minecraft:magenta_concrete
fill 355 243 625 356 243 625 minecraft:black_concrete
fill 355 243 638 363 243 638 minecraft:black_concrete
fill 355 243 642 357 244 642 minecraft:magenta_concrete
fill 355 243 646 355 264 646 minecraft:purple_concrete
fill 356 243 615 359 244 615 minecraft:magenta_concrete
fill 356 243 626 357 243 627 minecraft:magenta_concrete
fill 356 243 628 363 243 628 minecraft:black_concrete
fill 356 243 633 361 243 633 minecraft:magenta_concrete
fill 357 243 616 360 243 617 minecraft:magenta_concrete
fill 357 243 622 357 243 623 minecraft:black_concrete
fill 357 243 624 359 243 625 minecraft:magenta_concrete
fill 358 243 618 360 243 623 minecraft:magenta_concrete
setblock 358 243 626 minecraft:magenta_concrete
fill 358 243 627 364 243 627 minecraft:black_concrete
fill 358 243 629 360 243 630 minecraft:black_concrete
fill 358 243 631 365 243 631 minecraft:magenta_concrete
fill 358 243 639 361 244 639 minecraft:black_concrete
fill 359 243 604 360 253 604 minecraft:purple_concrete
fill 359 243 613 359 244 613 minecraft:black_concrete
fill 359 243 626 364 243 626 minecraft:black_concrete
setblock 359 243 646 minecraft:magenta_concrete
fill 360 243 614 361 244 615 minecraft:black_concrete
fill 360 243 624 365 243 625 minecraft:black_concrete
fill 360 243 646 365 246 646 minecraft:purple_concrete
fill 361 243 604 362 243 604 minecraft:magenta_concrete
fill 361 243 616 363 243 623 minecraft:black_concrete
fill 361 243 629 362 243 629 minecraft:black_concrete
fill 361 243 630 366 243 630 minecraft:magenta_concrete
fill 362 243 615 362 244 615 minecraft:black_concrete
fill 362 243 633 366 243 633 minecraft:black_concrete
fill 362 243 639 362 244 639 minecraft:magenta_concrete
fill 363 243 604 363 307 604 minecraft:purple_concrete
fill 363 243 629 367 244 629 minecraft:magenta_concrete
fill 364 243 617 364 243 623 minecraft:black_concrete
fill 364 243 628 367 243 628 minecraft:magenta_concrete
fill 364 243 632 367 243 632 minecraft:black_concrete
fill 365 243 604 365 251 604 minecraft:purple_concrete
fill 365 243 618 365 244 623 minecraft:black_concrete
fill 365 243 626 367 243 627 minecraft:magenta_concrete
fill 366 243 604 367 243 604 minecraft:magenta_concrete
fill 366 243 620 366 244 623 minecraft:black_concrete
fill 366 243 624 367 244 625 minecraft:magenta_concrete
fill 366 243 631 367 244 631 minecraft:black_concrete
fill 366 243 634 366 244 634 minecraft:black_concrete
setblock 366 243 646 minecraft:magenta_concrete
fill 367 243 622 367 244 623 minecraft:magenta_concrete
fill 367 243 630 367 244 630 minecraft:black_concrete
fill 367 243 646 369 246 646 minecraft:purple_concrete
fill 368 243 627 368 244 627 minecraft:magenta_concrete
fill 370 243 604 370 262 604 minecraft:purple_concrete
fill 371 243 609 371 278 609 minecraft:purple_concrete
setblock 371 243 610 minecraft:magenta_concrete
fill 371 243 611 371 244 620 minecraft:purple_concrete
setblock 371 243 621 minecraft:magenta_concrete
fill 371 243 622 371 245 622 minecraft:purple_concrete
fill 371 243 627 371 245 628 minecraft:purple_concrete
setblock 371 243 629 minecraft:magenta_concrete
setblock 371 243 630 minecraft:white_concrete
fill 371 243 631 371 248 633 minecraft:purple_concrete
setblock 371 243 634 minecraft:magenta_concrete
fill 371 243 635 371 264 639 minecraft:purple_concrete
setblock 371 243 640 minecraft:magenta_concrete
fill 371 243 641 371 262 642 minecraft:purple_concrete
fill 329 244 606 329 307 606 minecraft:purple_concrete
fill 329 244 611 329 260 611 minecraft:purple_concrete
setblock 329 244 612 minecraft:crying_obsidian
fill 329 244 613 329 271 615 minecraft:purple_concrete
fill 329 244 617 329 287 618 minecraft:purple_concrete
fill 329 244 622 329 301 624 minecraft:purple_concrete
fill 329 244 626 329 267 626 minecraft:purple_concrete
fill 329 244 635 329 270 635 minecraft:purple_concrete
fill 329 244 644 329 251 644 minecraft:purple_concrete
fill 330 244 605 335 244 645 minecraft:obsidian
fill 336 244 605 336 244 626 minecraft:obsidian
fill 336 244 627 338 244 627 minecraft:black_concrete
fill 336 244 628 336 244 645 minecraft:obsidian
fill 337 244 604 337 307 604 minecraft:purple_concrete
fill 337 244 605 337 244 621 minecraft:obsidian
fill 337 244 624 339 244 626 minecraft:black_concrete
fill 337 244 633 337 244 645 minecraft:obsidian
fill 338 244 605 338 244 619 minecraft:obsidian
fill 338 244 623 340 244 623 minecraft:black_concrete
fill 338 244 635 338 244 645 minecraft:obsidian
fill 339 244 605 339 244 617 minecraft:obsidian
setblock 339 244 622 minecraft:black_concrete
fill 339 244 627 348 245 627 minecraft:iron_block
fill 339 244 632 339 244 636 minecraft:magenta_concrete
fill 339 244 637 339 244 645 minecraft:obsidian
fill 339 244 646 339 307 646 minecraft:purple_concrete
fill 340 244 605 340 244 616 minecraft:obsidian
setblock 340 244 621 minecraft:black_concrete
fill 340 244 622 364 245 622 minecraft:iron_block
fill 340 244 624 341 244 625 minecraft:black_concrete
fill 340 244 626 340 245 626 minecraft:iron_block
fill 340 244 628 340 245 628 minecraft:iron_block
fill 340 244 629 340 244 631 minecraft:magenta_concrete
fill 340 244 632 364 245 632 minecraft:iron_block
fill 340 244 633 340 244 636 minecraft:magenta_concrete
fill 340 244 638 340 244 645 minecraft:obsidian
fill 341 244 605 341 244 615 minecraft:obsidian
fill 341 244 621 363 245 621 minecraft:iron_block
fill 341 244 623 363 245 623 minecraft:iron_block
setblock 341 244 626 minecraft:black_concrete
fill 341 244 628 341 244 630 minecraft:magenta_concrete
fill 341 244 631 363 245 631 minecraft:iron_block
fill 341 244 633 363 245 633 minecraft:iron_block
fill 341 244 634 342 244 636 minecraft:magenta_concrete
fill 341 244 639 341 244 645 minecraft:obsidian
fill 342 244 605 342 244 614 minecraft:obsidian
fill 342 244 615 348 244 615 minecraft:black_concrete
fill 342 244 617 343 244 619 minecraft:magenta_concrete
fill 342 244 620 343 244 620 minecraft:black_concrete
fill 342 244 624 349 245 626 minecraft:iron_block
fill 342 244 628 349 245 630 minecraft:iron_block
fill 342 244 640 342 244 645 minecraft:obsidian
fill 342 244 646 342 283 646 minecraft:purple_concrete
fill 343 244 605 344 244 613 minecraft:obsidian
fill 343 244 634 343 244 638 minecraft:black_concrete
fill 343 244 641 344 244 645 minecraft:obsidian
fill 344 244 617 345 245 618 minecraft:iron_block
setblock 344 244 619 minecraft:magenta_concrete
fill 344 244 620 360 245 620 minecraft:iron_block
fill 344 244 634 360 245 634 minecraft:iron_block
setblock 344 244 635 minecraft:black_concrete
fill 344 244 636 345 245 637 minecraft:iron_block
fill 344 244 638 348 244 640 minecraft:black_concrete
fill 344 244 646 344 307 646 minecraft:purple_concrete
fill 345 244 605 346 244 612 minecraft:obsidian
fill 345 244 619 359 245 619 minecraft:iron_block
fill 345 244 635 359 245 635 minecraft:iron_block
fill 345 244 642 346 244 645 minecraft:obsidian
setblock 345 244 646 minecraft:white_concrete
fill 346 244 616 348 244 616 minecraft:black_concrete
fill 346 244 617 347 244 617 minecraft:magenta_concrete
fill 346 244 618 360 245 618 minecraft:iron_block
fill 346 244 636 360 245 636 minecraft:iron_block
fill 346 244 637 347 244 637 minecraft:black_concrete
fill 346 244 646 346 253 646 minecraft:purple_concrete
fill 347 244 605 351 244 611 minecraft:obsidian
fill 347 244 643 351 244 645 minecraft:obsidian
fill 348 244 617 356 245 617 minecraft:iron_block
fill 348 244 637 356 245 637 minecraft:iron_block
fill 349 244 615 350 245 616 minecraft:iron_block
fill 349 244 627 350 244 627 minecraft:waxed_copper_block
fill 349 244 638 350 245 639 minecraft:iron_block
fill 349 244 640 350 244 640 minecraft:black_concrete
fill 350 244 624 351 245 624 minecraft:iron_block
fill 350 244 625 350 245 626 minecraft:waxed_copper_block
fill 350 244 628 350 245 629 minecraft:waxed_copper_block
fill 350 244 630 351 245 630 minecraft:iron_block
fill 351 244 615 351 244 616 minecraft:black_concrete
fill 351 244 625 354 244 625 minecraft:waxed_copper_block
fill 351 244 629 354 244 629 minecraft:waxed_copper_block
fill 351 244 638 351 244 639 minecraft:magenta_concrete
fill 352 244 605 370 244 610 minecraft:obsidian
fill 352 244 615 353 244 615 minecraft:black_concrete
fill 352 244 616 352 245 616 minecraft:iron_block
fill 352 244 624 352 246 624 minecraft:waxed_copper_block
fill 352 244 630 352 246 630 minecraft:waxed_copper_block
fill 352 244 638 352 245 638 minecraft:iron_block
fill 352 244 639 353 244 639 minecraft:magenta_concrete
fill 352 244 644 370 244 645 minecraft:obsidian
fill 353 244 611 370 244 611 minecraft:obsidian
setblock 353 244 616 minecraft:black_concrete
fill 353 244 624 362 245 624 minecraft:iron_block
fill 353 244 630 362 245 630 minecraft:iron_block
setblock 353 244 638 minecraft:magenta_concrete
fill 353 244 643 370 244 643 minecraft:obsidian
fill 354 244 615 355 245 616 minecraft:iron_block
fill 354 244 626 354 244 628 minecraft:waxed_copper_block
fill 354 244 638 355 245 639 minecraft:iron_block
fill 354 244 646 354 307 646 minecraft:purple_concrete
fill 355 244 625 362 245 626 minecraft:iron_block
fill 355 244 627 355 246 627 minecraft:waxed_copper_block
fill 355 244 628 362 245 629 minecraft:iron_block
setblock 356 244 616 minecraft:black_concrete
fill 356 244 627 365 245 627 minecraft:iron_block
fill 356 244 638 363 244 638 minecraft:black_concrete
fill 356 244 639 357 244 639 minecraft:magenta_concrete
fill 357 244 616 358 244 617 minecraft:magenta_concrete
fill 357 244 637 358 244 637 minecraft:black_concrete
fill 358 244 612 370 244 612 minecraft:obsidian
fill 358 244 642 370 244 642 minecraft:obsidian
fill 359 244 616 360 244 616 minecraft:magenta_concrete
fill 359 244 617 360 245 617 minecraft:iron_block
fill 359 244 637 360 245 637 minecraft:iron_block
fill 359 244 646 359 251 646 minecraft:purple_concrete
fill 360 244 613 370 244 613 minecraft:obsidian
setblock 360 244 619 minecraft:magenta_concrete
fill 360 244 635 365 244 635 minecraft:black_concrete
fill 360 244 641 370 244 641 minecraft:obsidian
fill 361 244 604 362 283 604 minecraft:purple_concrete
fill 361 244 616 363 244 620 minecraft:black_concrete
fill 361 244 634 365 244 634 minecraft:black_concrete
fill 361 244 636 364 244 637 minecraft:black_concrete
fill 362 244 614 370 244 614 minecraft:obsidian
fill 362 244 640 370 244 640 minecraft:obsidian
fill 363 244 615 370 244 615 minecraft:obsidian
fill 363 244 624 363 244 626 minecraft:black_concrete
setblock 363 244 628 minecraft:black_concrete
fill 363 244 630 366 244 630 minecraft:magenta_concrete
fill 363 244 639 370 244 639 minecraft:obsidian
fill 364 244 616 370 244 616 minecraft:obsidian
fill 364 244 617 364 244 621 minecraft:black_concrete
fill 364 244 623 364 244 625 minecraft:black_concrete
fill 364 244 626 364 245 626 minecraft:iron_block
fill 364 244 628 364 245 628 minecraft:iron_block
fill 364 244 631 365 244 631 minecraft:magenta_concrete
fill 364 244 633 366 244 633 minecraft:black_concrete
fill 364 244 638 370 244 638 minecraft:obsidian
fill 365 244 617 370 244 617 minecraft:obsidian
fill 365 244 624 365 244 625 minecraft:black_concrete
fill 365 244 626 367 244 626 minecraft:magenta_concrete
fill 365 244 628 367 244 628 minecraft:magenta_concrete
fill 365 244 632 367 244 632 minecraft:black_concrete
setblock 365 244 636 minecraft:black_concrete
fill 365 244 637 370 244 637 minecraft:obsidian
fill 366 244 604 367 266 604 minecraft:purple_concrete
fill 366 244 618 370 244 619 minecraft:obsidian
fill 366 244 627 367 244 627 minecraft:magenta_concrete
fill 366 244 635 370 244 636 minecraft:obsidian
fill 366 244 646 366 252 646 minecraft:purple_concrete
fill 367 244 620 370 244 621 minecraft:obsidian
fill 367 244 633 370 244 634 minecraft:obsidian
fill 368 244 622 370 244 626 minecraft:obsidian
fill 368 244 628 370 244 632 minecraft:obsidian
fill 369 244 627 370 244 627 minecraft:obsidian
fill 371 244 610 371 271 610 minecraft:purple_concrete
fill 371 244 621 371 249 621 minecraft:purple_concrete
fill 371 244 629 371 251 630 minecraft:purple_concrete
fill 371 244 634 371 268 634 minecraft:purple_concrete
fill 371 244 640 371 281 640 minecraft:purple_concrete
fill 329 245 612 329 251 612 minecraft:purple_concrete
fill 345 245 646 345 307 646 minecraft:purple_concrete
fill 349 245 627 349 246 627 minecraft:waxed_copper_block
setblock 351 245 625 minecraft:waxed_copper_block
setblock 351 245 629 minecraft:waxed_copper_block
fill 353 245 625 354 245 625 minecraft:waxed_copper_block
fill 353 245 629 354 245 629 minecraft:waxed_copper_block
setblock 354 245 626 minecraft:waxed_copper_block
setblock 354 245 628 minecraft:waxed_copper_block
fill 371 245 611 371 246 619 minecraft:purple_concrete
setblock 371 245 620 minecraft:magenta_stained_glass
setblock 329 246 607 minecraft:crying_obsidian
fill 329 246 608 329 294 609 minecraft:purple_concrete
setblock 329 246 610 minecraft:magenta_stained_glass
setblock 342 246 604 minecraft:white_concrete
fill 345 246 625 345 246 629 minecraft:waxed_oxidized_copper
fill 346 246 623 346 246 624 minecraft:waxed_oxidized_copper
fill 346 246 630 346 246 631 minecraft:waxed_oxidized_copper
setblock 347 246 622 minecraft:waxed_oxidized_copper
setblock 347 246 632 minecraft:waxed_oxidized_copper
fill 348 246 621 349 246 621 minecraft:waxed_oxidized_copper
fill 348 246 633 349 246 633 minecraft:waxed_oxidized_copper
fill 350 246 620 354 246 620 minecraft:waxed_oxidized_copper
setblock 350 246 625 minecraft:waxed_copper_block
setblock 350 246 629 minecraft:waxed_copper_block
fill 350 246 634 354 246 634 minecraft:waxed_oxidized_copper
setblock 354 246 625 minecraft:waxed_copper_block
setblock 354 246 629 minecraft:waxed_copper_block
fill 355 246 621 356 246 621 minecraft:waxed_oxidized_copper
fill 355 246 633 356 246 633 minecraft:waxed_oxidized_copper
setblock 357 246 622 minecraft:waxed_oxidized_copper
setblock 357 246 632 minecraft:waxed_oxidized_copper
fill 358 246 623 358 246 624 minecraft:waxed_oxidized_copper
fill 358 246 630 358 246 631 minecraft:waxed_oxidized_copper
fill 359 246 625 359 246 629 minecraft:waxed_oxidized_copper
fill 371 246 604 371 274 605 minecraft:purple_concrete
setblock 371 246 606 minecraft:magenta_stained_glass
fill 371 246 607 371 252 608 minecraft:purple_concrete
fill 371 246 620 371 294 620 minecraft:purple_concrete
setblock 371 246 622 minecraft:white_concrete
fill 371 246 627 371 276 627 minecraft:purple_concrete
setblock 371 246 628 minecraft:white_concrete
fill 329 247 607 329 283 607 minecraft:purple_concrete
fill 329 247 610 329 307 610 minecraft:purple_concrete
fill 342 247 604 342 291 604 minecraft:purple_concrete
fill 347 247 646 347 307 646 minecraft:purple_concrete
setblock 348 247 646 minecraft:white_concrete
fill 349 247 646 353 251 646 minecraft:purple_concrete
fill 360 247 646 360 307 646 minecraft:purple_concrete
setblock 361 247 646 minecraft:crying_obsidian
fill 362 247 646 365 248 646 minecraft:purple_concrete
fill 367 247 646 368 306 646 minecraft:purple_concrete
setblock 369 247 646 minecraft:crying_obsidian
fill 371 247 606 371 307 606 minecraft:purple_concrete
fill 371 247 611 371 251 615 minecraft:purple_concrete
setblock 371 247 616 minecraft:magenta_stained_glass
fill 371 247 617 371 279 619 minecraft:purple_concrete
fill 371 247 622 371 250 622 minecraft:purple_concrete
fill 371 247 628 371 307 628 minecraft:purple_concrete
setblock 329 248 627 minecraft:magenta_stained_glass
fill 329 248 628 329 251 630 minecraft:purple_concrete
setblock 329 248 638 minecraft:magenta_stained_glass
fill 329 248 639 329 299 640 minecraft:purple_concrete
fill 333 248 646 333 263 646 minecraft:purple_concrete
setblock 334 248 646 minecraft:white_concrete
fill 335 248 624 336 248 625 minecraft:crying_obsidian
fill 335 248 646 335 289 646 minecraft:purple_concrete
setblock 336 248 646 minecraft:white_concrete
fill 337 248 646 337 284 646 minecraft:purple_concrete
fill 348 248 646 348 277 646 minecraft:purple_concrete
fill 361 248 646 361 307 646 minecraft:purple_concrete
fill 369 248 646 369 274 646 minecraft:purple_concrete
fill 371 248 616 371 284 616 minecraft:purple_concrete
fill 329 249 627 329 256 627 minecraft:purple_concrete
fill 329 249 638 329 268 638 minecraft:purple_concrete
setblock 332 249 607 minecraft:light[level=12]
setblock 332 249 615 minecraft:light[level=12]
setblock 332 249 623 minecraft:light[level=12]
setblock 332 249 631 minecraft:light[level=12]
setblock 332 249 639 minecraft:light[level=12]
fill 334 249 626 334 250 627 minecraft:crying_obsidian
fill 334 249 646 334 260 646 minecraft:purple_concrete
fill 335 249 625 335 249 626 minecraft:crying_obsidian
fill 336 249 646 336 257 646 minecraft:purple_concrete
setblock 340 249 607 minecraft:light[level=12]
setblock 340 249 615 minecraft:light[level=12]
setblock 340 249 623 minecraft:light[level=12]
setblock 340 249 631 minecraft:light[level=12]
setblock 340 249 639 minecraft:light[level=12]
setblock 348 249 607 minecraft:light[level=12]
setblock 348 249 615 minecraft:light[level=12]
setblock 348 249 623 minecraft:light[level=12]
setblock 348 249 631 minecraft:light[level=12]
setblock 348 249 639 minecraft:light[level=12]
setblock 356 249 607 minecraft:light[level=12]
setblock 356 249 615 minecraft:light[level=12]
setblock 356 249 623 minecraft:light[level=12]
setblock 356 249 631 minecraft:light[level=12]
setblock 356 249 639 minecraft:light[level=12]
setblock 362 249 646 minecraft:crying_obsidian
fill 363 249 646 365 261 646 minecraft:purple_concrete
setblock 364 249 607 minecraft:light[level=12]
setblock 364 249 615 minecraft:light[level=12]
setblock 364 249 623 minecraft:light[level=12]
setblock 364 249 631 minecraft:light[level=12]
setblock 364 249 639 minecraft:light[level=12]
fill 371 249 631 371 307 631 minecraft:purple_concrete
setblock 371 249 632 minecraft:crying_obsidian
fill 371 249 633 371 259 633 minecraft:purple_concrete
fill 329 250 636 329 250 637 minecraft:magenta_stained_glass
fill 332 250 628 333 251 628 minecraft:crying_obsidian
setblock 333 250 627 minecraft:crying_obsidian
fill 356 250 624 357 251 630 minecraft:waxed_copper_block
fill 357 250 623 365 251 623 minecraft:waxed_copper_block
fill 357 250 631 365 251 631 minecraft:waxed_copper_block
fill 358 250 622 364 251 622 minecraft:waxed_copper_block
fill 358 250 624 358 251 626 minecraft:waxed_copper_block
fill 358 250 628 358 251 630 minecraft:waxed_copper_block
fill 358 250 632 364 251 632 minecraft:waxed_copper_block
fill 359 250 624 360 251 624 minecraft:waxed_copper_block
fill 359 250 630 360 251 630 minecraft:waxed_copper_block
fill 361 250 621 361 251 621 minecraft:waxed_copper_block
fill 361 250 633 361 251 633 minecraft:waxed_copper_block
fill 362 250 624 366 251 624 minecraft:waxed_copper_block
fill 362 250 630 366 251 630 minecraft:waxed_copper_block
fill 362 250 646 362 256 646 minecraft:purple_concrete
fill 364 250 625 366 251 626 minecraft:waxed_copper_block
fill 364 250 628 366 251 629 minecraft:waxed_copper_block
fill 365 250 627 367 251 627 minecraft:waxed_copper_block
fill 368 250 604 368 285 604 minecraft:purple_concrete
setblock 369 250 604 minecraft:crying_obsidian
setblock 371 250 621 minecraft:white_concrete
fill 371 250 632 371 253 632 minecraft:purple_concrete
setblock 329 251 616 minecraft:white_concrete
fill 329 251 636 329 277 637 minecraft:purple_concrete
fill 331 251 629 332 252 629 minecraft:crying_obsidian
fill 344 251 637 345 252 638 minecraft:magenta_concrete
fill 365 251 633 366 252 634 minecraft:obsidian
fill 369 251 604 369 295 604 minecraft:purple_concrete
fill 371 251 621 371 257 621 minecraft:purple_concrete
setblock 371 251 622 minecraft:crying_obsidian
fill 329 252 612 329 254 612 minecraft:magenta_concrete
fill 329 252 616 329 307 616 minecraft:purple_concrete
fill 329 252 628 329 254 628 minecraft:magenta_concrete
fill 329 252 629 329 254 630 minecraft:purple_concrete
fill 329 252 644 329 254 644 minecraft:magenta_concrete
fill 333 252 604 333 254 604 minecraft:magenta_concrete
fill 338 252 604 338 304 604 minecraft:purple_concrete
setblock 339 252 604 minecraft:white_concrete
fill 340 252 604 341 263 604 minecraft:purple_concrete
fill 343 252 646 343 254 646 minecraft:magenta_concrete
fill 347 252 604 348 303 604 minecraft:purple_concrete
fill 349 252 604 349 254 604 minecraft:magenta_concrete
fill 349 252 646 352 254 646 minecraft:purple_concrete
fill 350 252 604 358 252 604 minecraft:purple_concrete
setblock 353 252 646 minecraft:white_concrete
fill 359 252 646 359 254 646 minecraft:magenta_concrete
fill 365 252 604 365 254 604 minecraft:magenta_concrete
fill 371 252 611 371 264 613 minecraft:purple_concrete
fill 371 252 614 371 254 614 minecraft:magenta_concrete
setblock 371 252 615 minecraft:crying_obsidian
fill 371 252 622 371 266 622 minecraft:purple_concrete
fill 371 252 629 371 286 629 minecraft:purple_concrete
fill 371 252 630 371 254 630 minecraft:magenta_concrete
fill 339 253 604 339 307 604 minecraft:purple_concrete
fill 343 253 604 344 263 604 minecraft:purple_concrete
setblock 345 253 604 minecraft:magenta_stained_glass
fill 345 253 611 345 254 611 minecraft:magenta_stained_glass
setblock 350 253 604 minecraft:magenta_stained_glass
fill 351 253 604 358 260 604 minecraft:purple_concrete
fill 353 253 646 353 307 646 minecraft:purple_concrete
setblock 366 253 646 minecraft:white_concrete
fill 371 253 607 371 264 607 minecraft:purple_concrete
setblock 371 253 608 minecraft:magenta_stained_glass
fill 371 253 615 371 257 615 minecraft:purple_concrete
fill 345 254 604 345 264 604 minecraft:purple_concrete
setblock 346 254 646 minecraft:crying_obsidian
fill 350 254 604 350 307 604 minecraft:purple_concrete
fill 359 254 604 359 274 604 minecraft:purple_concrete
setblock 360 254 604 minecraft:magenta_stained_glass
fill 366 254 646 366 283 646 minecraft:purple_concrete
fill 371 254 608 371 307 608 minecraft:purple_concrete
setblock 371 254 632 minecraft:crying_obsidian
fill 329 255 612 329 260 612 minecraft:purple_concrete
fill 329 255 628 329 260 628 minecraft:purple_concrete
setblock 329 255 629 minecraft:white_concrete
fill 329 255 630 329 258 630 minecraft:purple_concrete
setblock 329 255 634 minecraft:white_concrete
fill 329 255 644 329 257 644 minecraft:purple_concrete
fill 333 255 604 333 260 604 minecraft:purple_concrete
fill 335 255 616 335 256 617 minecraft:gold_block
fill 343 255 646 343 260 646 minecraft:purple_concrete
fill 344 255 611 345 265 611 minecraft:black_concrete
fill 346 255 646 346 256 646 minecraft:purple_concrete
fill 349 255 604 349 260 604 minecraft:purple_concrete
fill 349 255 646 350 307 646 minecraft:purple_concrete
setblock 351 255 646 minecraft:white_concrete
fill 352 255 646 352 307 646 minecraft:purple_concrete
fill 359 255 646 359 260 646 minecraft:purple_concrete
fill 360 255 604 360 307 604 minecraft:purple_concrete
fill 365 255 604 365 260 604 minecraft:purple_concrete
fill 371 255 614 371 260 614 minecraft:purple_concrete
fill 371 255 630 371 260 630 minecraft:purple_concrete
fill 371 255 632 371 270 632 minecraft:purple_concrete
fill 329 256 629 329 307 629 minecraft:purple_concrete
fill 329 256 634 329 307 634 minecraft:purple_concrete
fill 351 256 646 351 277 646 minecraft:purple_concrete
setblock 329 257 627 minecraft:crying_obsidian
setblock 329 257 642 minecraft:magenta_stained_glass
fill 329 257 643 329 274 643 minecraft:purple_concrete
setblock 332 257 607 minecraft:light[level=12]
setblock 332 257 615 minecraft:light[level=12]
setblock 332 257 623 minecraft:light[level=12]
setblock 332 257 631 minecraft:light[level=12]
setblock 332 257 639 minecraft:light[level=12]
setblock 340 257 607 minecraft:light[level=12]
setblock 340 257 615 minecraft:light[level=12]
setblock 340 257 623 minecraft:light[level=12]
setblock 340 257 631 minecraft:light[level=12]
setblock 340 257 639 minecraft:light[level=12]
fill 344 257 610 345 265 610 minecraft:black_concrete
setblock 346 257 646 minecraft:magenta_stained_glass
setblock 348 257 607 minecraft:light[level=12]
setblock 348 257 615 minecraft:light[level=12]
setblock 348 257 623 minecraft:light[level=12]
setblock 348 257 631 minecraft:light[level=12]
setblock 348 257 639 minecraft:light[level=12]
setblock 356 257 607 minecraft:light[level=12]
setblock 356 257 615 minecraft:light[level=12]
setblock 356 257 623 minecraft:light[level=12]
setblock 356 257 631 minecraft:light[level=12]
setblock 356 257 639 minecraft:light[level=12]
fill 361 257 618 361 258 618 minecraft:obsidian
setblock 362 257 646 minecraft:white_concrete
setblock 364 257 607 minecraft:light[level=12]
setblock 364 257 615 minecraft:light[level=12]
setblock 364 257 623 minecraft:light[level=12]
setblock 364 257 631 minecraft:light[level=12]
setblock 364 257 639 minecraft:light[level=12]
setblock 371 257 624 minecraft:magenta_stained_glass
fill 371 257 625 371 306 626 minecraft:purple_concrete
fill 329 258 627 329 273 627 minecraft:purple_concrete
fill 329 258 642 329 307 642 minecraft:purple_concrete
setblock 329 258 644 minecraft:white_concrete
setblock 336 258 646 minecraft:crying_obsidian
fill 343 258 610 343 265 611 minecraft:black_concrete
fill 344 258 612 345 265 612 minecraft:black_concrete
fill 346 258 610 346 265 611 minecraft:black_concrete
fill 346 258 646 346 259 646 minecraft:purple_concrete
fill 348 258 634 348 259 634 minecraft:magenta_concrete
setblock 356 258 646 minecraft:crying_obsidian
fill 362 258 646 362 307 646 minecraft:purple_concrete
setblock 371 258 615 minecraft:white_concrete
setblock 371 258 621 minecraft:white_concrete
fill 371 258 624 371 307 624 minecraft:purple_concrete
setblock 329 259 630 minecraft:magenta_stained_glass
fill 329 259 644 329 260 644 minecraft:purple_concrete
fill 336 259 646 336 260 646 minecraft:purple_concrete
fill 343 259 612 343 265 612 minecraft:black_concrete
fill 344 259 609 345 265 609 minecraft:black_concrete
fill 346 259 612 346 265 612 minecraft:black_concrete
fill 356 259 646 356 307 646 minecraft:purple_concrete
fill 371 259 615 371 270 615 minecraft:purple_concrete
fill 371 259 621 371 307 621 minecraft:purple_concrete
setblock 329 260 625 minecraft:white_concrete
fill 329 260 630 329 307 630 minecraft:purple_concrete
fill 342 260 610 342 265 611 minecraft:black_concrete
fill 343 260 609 343 265 609 minecraft:black_concrete
fill 343 260 613 346 265 613 minecraft:black_concrete
fill 346 260 609 346 265 609 minecraft:black_concrete
setblock 346 260 646 minecraft:white_concrete
fill 347 260 610 347 265 611 minecraft:black_concrete
setblock 371 260 633 minecraft:white_concrete
setblock 329 261 611 minecraft:crying_obsidian
fill 329 261 612 329 263 612 minecraft:magenta_concrete
fill 329 261 625 329 280 625 minecraft:purple_concrete
fill 329 261 628 329 263 628 minecraft:magenta_concrete
fill 329 261 644 329 263 644 minecraft:magenta_concrete
fill 333 261 604 333 263 604 minecraft:magenta_concrete
setblock 334 261 646 minecraft:magenta_stained_glass
setblock 336 261 646 minecraft:crying_obsidian
fill 342 261 609 342 265 609 minecraft:black_concrete
fill 342 261 612 342 265 612 minecraft:black_concrete
fill 343 261 608 346 265 608 minecraft:black_concrete
fill 343 261 646 343 263 646 minecraft:magenta_concrete
fill 346 261 646 346 294 646 minecraft:purple_concrete
fill 347 261 609 347 265 609 minecraft:black_concrete
fill 347 261 612 347 265 612 minecraft:black_concrete
fill 349 261 604 349 263 604 minecraft:magenta_concrete
fill 351 261 604 357 265 604 minecraft:purple_concrete
setblock 358 261 604 minecraft:crying_obsidian
fill 359 261 646 359 263 646 minecraft:magenta_concrete
fill 365 261 604 365 263 604 minecraft:magenta_concrete
fill 371 261 614 371 263 614 minecraft:magenta_concrete
fill 371 261 630 371 263 630 minecraft:magenta_concrete
fill 371 261 633 371 307 633 minecraft:purple_concrete
fill 329 262 611 329 307 611 minecraft:purple_concrete
fill 329 262 619 329 307 619 minecraft:purple_concrete
setblock 329 262 620 minecraft:magenta_stained_glass
fill 329 262 621 329 307 621 minecraft:purple_concrete
setblock 329 262 641 minecraft:crying_obsidian
fill 334 262 646 334 270 646 minecraft:purple_concrete
fill 336 262 646 336 265 646 minecraft:purple_concrete
fill 341 262 610 341 265 612 minecraft:black_concrete
fill 342 262 608 342 265 608 minecraft:black_concrete
fill 342 262 613 342 265 613 minecraft:black_concrete
fill 343 262 614 346 265 614 minecraft:black_concrete
fill 347 262 608 347 265 608 minecraft:black_concrete
fill 347 262 613 347 265 613 minecraft:black_concrete
fill 348 262 610 348 265 612 minecraft:black_concrete
fill 358 262 604 358 266 604 minecraft:purple_concrete
fill 363 262 646 364 272 646 minecraft:purple_concrete
setblock 365 262 646 minecraft:crying_obsidian
setblock 371 262 643 minecraft:magenta_stained_glass
fill 371 262 644 371 274 645 minecraft:purple_concrete
fill 329 263 620 329 278 620 minecraft:purple_concrete
fill 329 263 641 329 307 641 minecraft:purple_concrete
fill 341 263 609 341 265 609 minecraft:black_concrete
fill 341 263 613 341 265 613 minecraft:black_concrete
fill 342 263 614 342 265 614 minecraft:black_concrete
fill 343 263 607 346 265 607 minecraft:black_concrete
fill 347 263 614 347 265 614 minecraft:black_concrete
fill 348 263 609 348 265 609 minecraft:black_concrete
fill 348 263 613 348 265 613 minecraft:black_concrete
fill 365 263 646 365 269 646 minecraft:purple_concrete
setblock 370 263 604 minecraft:white_concrete
setblock 371 263 641 minecraft:magenta_stained_glass
fill 371 263 642 371 271 643 minecraft:purple_concrete
fill 329 264 612 329 269 612 minecraft:purple_concrete
fill 329 264 628 329 269 628 minecraft:purple_concrete
fill 329 264 631 329 277 631 minecraft:purple_concrete
setblock 329 264 632 minecraft:crying_obsidian
fill 329 264 633 329 268 633 minecraft:purple_concrete
fill 329 264 644 329 269 644 minecraft:purple_concrete
fill 333 264 604 333 269 604 minecraft:purple_concrete
setblock 333 264 646 minecraft:white_concrete
setblock 340 264 604 minecraft:crying_obsidian
fill 340 264 610 340 265 612 minecraft:black_concrete
fill 341 264 604 341 265 604 minecraft:purple_concrete
fill 341 264 608 341 265 608 minecraft:black_concrete
fill 341 264 631 343 265 631 minecraft:obsidian
fill 342 264 607 342 265 607 minecraft:black_concrete
fill 342 264 632 343 265 632 minecraft:obsidian
setblock 343 264 604 minecraft:white_concrete
fill 343 264 615 346 265 615 minecraft:black_concrete
fill 343 264 646 343 269 646 minecraft:purple_concrete
fill 344 264 604 344 303 604 minecraft:purple_concrete
fill 347 264 607 347 265 607 minecraft:black_concrete
fill 348 264 608 348 265 608 minecraft:black_concrete
fill 349 264 604 349 267 604 minecraft:purple_concrete
fill 349 264 610 349 265 612 minecraft:black_concrete
fill 359 264 646 359 269 646 minecraft:purple_concrete
fill 365 264 604 365 269 604 minecraft:purple_concrete
fill 370 264 604 370 279 604 minecraft:purple_concrete
fill 371 264 614 371 269 614 minecraft:purple_concrete
fill 371 264 630 371 269 630 minecraft:purple_concrete
fill 371 264 641 371 276 641 minecraft:purple_concrete
fill 329 265 632 329 307 632 minecraft:purple_concrete
setblock 332 265 607 minecraft:light[level=12]
setblock 332 265 615 minecraft:light[level=12]
setblock 332 265 623 minecraft:light[level=12]
setblock 332 265 631 minecraft:light[level=12]
setblock 332 265 639 minecraft:light[level=12]
fill 333 265 646 333 307 646 minecraft:purple_concrete
fill 340 265 604 340 304 604 minecraft:purple_concrete
setblock 340 265 607 minecraft:light[level=12]
setblock 340 265 609 minecraft:black_concrete
setblock 340 265 613 minecraft:black_concrete
setblock 340 265 615 minecraft:light[level=12]
setblock 340 265 623 minecraft:light[level=12]
setblock 340 265 631 minecraft:light[level=12]
setblock 340 265 639 minecraft:light[level=12]
setblock 341 265 607 minecraft:black_concrete
setblock 341 265 614 minecraft:black_concrete
setblock 342 265 615 minecraft:black_concrete
fill 343 265 604 343 307 604 minecraft:purple_concrete
fill 343 265 606 346 265 606 minecraft:black_concrete
setblock 345 265 604 minecraft:magenta_stained_glass
setblock 347 265 615 minecraft:black_concrete
setblock 348 265 607 minecraft:black_concrete
setblock 348 265 614 minecraft:black_concrete
setblock 348 265 615 minecraft:light[level=12]
setblock 348 265 623 minecraft:light[level=12]
setblock 348 265 631 minecraft:light[level=12]
setblock 348 265 639 minecraft:light[level=12]
setblock 349 265 609 minecraft:black_concrete
setblock 349 265 613 minecraft:black_concrete
setblock 355 265 646 minecraft:crying_obsidian
setblock 356 265 607 minecraft:light[level=12]
setblock 356 265 615 minecraft:light[level=12]
setblock 356 265 623 minecraft:light[level=12]
setblock 356 265 631 minecraft:light[level=12]
setblock 356 265 639 minecraft:light[level=12]
setblock 364 265 607 minecraft:light[level=12]
setblock 364 265 615 minecraft:light[level=12]
setblock 364 265 623 minecraft:light[level=12]
setblock 364 265 631 minecraft:light[level=12]
setblock 364 265 639 minecraft:light[level=12]
setblock 371 265 607 minecraft:magenta_stained_glass
fill 371 265 611 371 272 612 minecraft:purple_concrete
setblock 371 265 613 minecraft:magenta_stained_glass
fill 371 265 635 371 279 637 minecraft:purple_concrete
setblock 371 265 638 minecraft:magenta_stained_glass
fill 371 265 639 371 307 639 minecraft:purple_concrete
fill 334 266 604 334 269 604 minecraft:purple_concrete
setblock 335 266 604 minecraft:white_concrete
fill 336 266 604 336 299 604 minecraft:purple_concrete
setblock 336 266 646 minecraft:crying_obsidian
setblock 341 266 604 minecraft:crying_obsidian
fill 344 266 610 345 267 611 minecraft:magenta_stained_glass
fill 345 266 604 345 285 604 minecraft:purple_concrete
setblock 346 266 604 minecraft:crying_obsidian
fill 351 266 604 352 286 604 minecraft:purple_concrete
setblock 353 266 604 minecraft:white_concrete
fill 354 266 604 357 278 604 minecraft:purple_concrete
fill 355 266 646 355 307 646 minecraft:purple_concrete
fill 371 266 607 371 307 607 minecraft:purple_concrete
fill 371 266 613 371 288 613 minecraft:purple_concrete
fill 371 266 638 371 295 638 minecraft:purple_concrete
fill 335 267 604 335 307 604 minecraft:purple_concrete
fill 336 267 646 336 293 646 minecraft:purple_concrete
fill 341 267 604 341 307 604 minecraft:purple_concrete
setblock 346 267 604 minecraft:magenta_stained_glass
fill 353 267 604 353 277 604 minecraft:purple_concrete
setblock 358 267 604 minecraft:crying_obsidian
setblock 366 267 604 minecraft:magenta_stained_glass
fill 367 267 604 367 307 604 minecraft:purple_concrete
setblock 371 267 622 minecraft:crying_obsidian
setblock 329 268 626 minecraft:white_concrete
fill 339 268 623 340 269 624 minecraft:gold_block
fill 340 268 622 340 269 622 minecraft:gold_block
fill 344 268 611 345 268 611 minecraft:magenta_stained_glass
fill 346 268 604 346 307 604 minecraft:purple_concrete
setblock 349 268 604 minecraft:white_concrete
fill 358 268 604 358 298 604 minecraft:purple_concrete
fill 366 268 604 366 307 604 minecraft:purple_concrete
fill 371 268 622 371 288 622 minecraft:purple_concrete
fill 329 269 626 329 307 626 minecraft:purple_concrete
setblock 329 269 633 minecraft:crying_obsidian
setblock 329 269 638 minecraft:crying_obsidian
setblock 329 269 645 minecraft:crying_obsidian
fill 329 269 646 329 307 646 minecraft:purple_concrete
setblock 349 269 604 minecraft:purple_concrete
setblock 371 269 634 minecraft:magenta_stained_glass
fill 329 270 612 329 272 612 minecraft:magenta_concrete
fill 329 270 628 329 272 628 minecraft:magenta_concrete
fill 329 270 633 329 307 633 minecraft:purple_concrete
fill 329 270 638 329 307 638 minecraft:purple_concrete
fill 329 270 644 329 272 644 minecraft:magenta_concrete
fill 329 270 645 329 307 645 minecraft:purple_concrete
fill 333 270 604 333 272 604 minecraft:magenta_concrete
setblock 334 270 604 minecraft:crying_obsidian
fill 343 270 646 343 272 646 minecraft:magenta_concrete
fill 349 270 604 349 272 604 minecraft:magenta_concrete
setblock 357 270 646 minecraft:crying_obsidian
fill 359 270 646 359 272 646 minecraft:magenta_concrete
fill 365 270 604 365 272 604 minecraft:magenta_concrete
setblock 365 270 646 minecraft:crying_obsidian
fill 371 270 614 371 272 614 minecraft:magenta_concrete
fill 371 270 630 371 272 630 minecraft:magenta_concrete
fill 371 270 634 371 293 634 minecraft:purple_concrete
setblock 329 271 635 minecraft:white_concrete
fill 330 271 604 331 279 604 minecraft:purple_concrete
setblock 332 271 604 minecraft:crying_obsidian
fill 334 271 604 334 307 604 minecraft:purple_concrete
setblock 334 271 646 minecraft:white_concrete
fill 357 271 646 357 307 646 minecraft:purple_concrete
fill 365 271 646 365 307 646 minecraft:purple_concrete
setblock 371 271 615 minecraft:white_concrete
setblock 371 271 632 minecraft:white_concrete
fill 329 272 613 329 307 614 minecraft:purple_concrete
setblock 329 272 615 minecraft:crying_obsidian
fill 329 272 635 329 307 635 minecraft:purple_concrete
fill 332 272 604 332 307 604 minecraft:purple_concrete
fill 334 272 646 334 307 646 minecraft:purple_concrete
setblock 371 272 610 minecraft:crying_obsidian
fill 371 272 615 371 297 615 minecraft:purple_concrete
fill 371 272 632 371 284 632 minecraft:purple_concrete
fill 371 272 642 371 307 642 minecraft:purple_concrete
setblock 371 272 643 minecraft:magenta_stained_glass
fill 329 273 612 329 287 612 minecraft:purple_concrete
fill 329 273 615 329 285 615 minecraft:purple_concrete
setblock 329 273 628 minecraft:purple_concrete
fill 329 273 644 329 287 644 minecraft:purple_concrete
setblock 332 273 607 minecraft:light[level=12]
setblock 332 273 615 minecraft:light[level=12]
setblock 332 273 623 minecraft:light[level=12]
setblock 332 273 631 minecraft:light[level=12]
setblock 332 273 639 minecraft:light[level=12]
fill 333 273 604 333 287 604 minecraft:purple_concrete
setblock 340 273 607 minecraft:light[level=12]
setblock 340 273 615 minecraft:light[level=12]
setblock 340 273 623 minecraft:light[level=12]
setblock 340 273 631 minecraft:light[level=12]
setblock 340 273 639 minecraft:light[level=12]
fill 343 273 646 343 287 646 minecraft:purple_concrete
setblock 348 273 607 minecraft:light[level=12]
setblock 348 273 615 minecraft:light[level=12]
schedule function dropper:buildpart/151_2 1t
