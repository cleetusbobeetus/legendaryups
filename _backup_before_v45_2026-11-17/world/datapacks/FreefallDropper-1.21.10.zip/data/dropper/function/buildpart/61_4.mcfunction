setblock 87 256 316 minecraft:spruce_planks
setblock 88 256 276 minecraft:spruce_planks
setblock 88 256 283 minecraft:spruce_planks
setblock 88 256 290 minecraft:spruce_planks
setblock 88 256 297 minecraft:spruce_planks
setblock 88 256 304 minecraft:spruce_planks
setblock 88 256 311 minecraft:spruce_planks
fill 89 256 310 89 282 310 minecraft:light_blue_concrete
fill 47 257 282 47 308 282 minecraft:light_blue_concrete
fill 47 257 293 47 267 293 minecraft:light_blue_concrete
setblock 47 257 309 minecraft:light_blue_wool
setblock 48 257 279 minecraft:spruce_planks
setblock 48 257 286 minecraft:spruce_planks
setblock 48 257 293 minecraft:spruce_planks
setblock 48 257 300 minecraft:spruce_planks
setblock 48 257 307 minecraft:spruce_planks
setblock 48 257 314 minecraft:spruce_planks
setblock 50 257 278 minecraft:light[level=15]
setblock 50 257 286 minecraft:light[level=15]
setblock 50 257 294 minecraft:light[level=15]
setblock 50 257 302 minecraft:light[level=15]
setblock 50 257 310 minecraft:light[level=15]
setblock 52 257 276 minecraft:spruce_planks
fill 52 257 317 52 308 317 minecraft:light_blue_concrete
setblock 53 257 316 minecraft:spruce_planks
setblock 58 257 278 minecraft:light[level=15]
setblock 58 257 286 minecraft:light[level=15]
setblock 58 257 294 minecraft:light[level=15]
setblock 58 257 302 minecraft:light[level=15]
setblock 58 257 310 minecraft:light[level=15]
setblock 59 257 276 minecraft:spruce_planks
setblock 60 257 316 minecraft:spruce_planks
setblock 66 257 276 minecraft:spruce_planks
setblock 66 257 278 minecraft:light[level=15]
setblock 66 257 286 minecraft:light[level=15]
setblock 66 257 294 minecraft:light[level=15]
setblock 66 257 302 minecraft:light[level=15]
setblock 66 257 310 minecraft:light[level=15]
setblock 67 257 316 minecraft:spruce_planks
setblock 73 257 276 minecraft:spruce_planks
setblock 74 257 278 minecraft:light[level=15]
setblock 74 257 286 minecraft:light[level=15]
setblock 74 257 294 minecraft:light[level=15]
setblock 74 257 302 minecraft:light[level=15]
setblock 74 257 310 minecraft:light[level=15]
setblock 74 257 316 minecraft:spruce_planks
setblock 80 257 276 minecraft:spruce_planks
setblock 81 257 316 minecraft:spruce_planks
setblock 82 257 278 minecraft:light[level=15]
setblock 82 257 286 minecraft:light[level=15]
setblock 82 257 294 minecraft:light[level=15]
setblock 82 257 302 minecraft:light[level=15]
setblock 82 257 310 minecraft:light[level=15]
setblock 87 257 276 minecraft:spruce_planks
setblock 88 257 282 minecraft:spruce_planks
setblock 88 257 289 minecraft:spruce_planks
setblock 88 257 296 minecraft:spruce_planks
setblock 88 257 303 minecraft:spruce_planks
setblock 88 257 310 minecraft:spruce_planks
setblock 88 257 316 minecraft:spruce_planks
fill 47 258 309 47 266 311 minecraft:light_blue_concrete
setblock 47 258 312 minecraft:white_wool
fill 47 258 313 47 308 315 minecraft:light_blue_concrete
setblock 48 258 280 minecraft:spruce_planks
setblock 48 258 287 minecraft:spruce_planks
setblock 48 258 294 minecraft:spruce_planks
setblock 48 258 301 minecraft:spruce_planks
setblock 48 258 308 minecraft:spruce_planks
setblock 48 258 315 minecraft:spruce_planks
setblock 51 258 276 minecraft:spruce_planks
setblock 54 258 316 minecraft:spruce_planks
setblock 58 258 276 minecraft:spruce_planks
setblock 61 258 316 minecraft:spruce_planks
fill 61 258 317 61 308 317 minecraft:light_blue_concrete
setblock 62 258 317 minecraft:white_wool
setblock 65 258 276 minecraft:spruce_planks
setblock 68 258 316 minecraft:spruce_planks
setblock 72 258 276 minecraft:spruce_planks
setblock 75 258 316 minecraft:spruce_planks
setblock 79 258 276 minecraft:spruce_planks
setblock 82 258 316 minecraft:spruce_planks
setblock 86 258 276 minecraft:spruce_planks
setblock 88 258 281 minecraft:spruce_planks
setblock 88 258 288 minecraft:spruce_planks
setblock 88 258 295 minecraft:spruce_planks
setblock 88 258 302 minecraft:spruce_planks
setblock 88 258 309 minecraft:spruce_planks
fill 47 259 296 47 308 296 minecraft:light_blue_concrete
setblock 47 259 297 minecraft:white_wool
fill 47 259 298 47 262 308 minecraft:light_blue_concrete
fill 47 259 312 47 308 312 minecraft:light_blue_concrete
fill 62 259 317 62 271 317 minecraft:light_blue_concrete
fill 47 260 275 50 308 275 minecraft:light_blue_concrete
fill 47 260 284 47 263 284 minecraft:light_blue_concrete
setblock 47 260 285 minecraft:white_wool
fill 47 260 297 47 308 297 minecraft:light_blue_concrete
fill 48 260 276 48 260 280 minecraft:spruce_planks
fill 48 260 282 48 260 287 minecraft:spruce_planks
fill 48 260 289 48 260 294 minecraft:spruce_planks
fill 48 260 296 48 260 301 minecraft:spruce_planks
fill 48 260 303 48 260 308 minecraft:spruce_planks
fill 48 260 310 48 260 315 minecraft:spruce_planks
setblock 49 260 276 minecraft:spruce_planks
fill 49 260 285 49 261 291 minecraft:iron_bars
fill 49 260 316 54 260 316 minecraft:spruce_planks
setblock 51 260 275 minecraft:light_blue_wool
fill 51 260 276 56 260 276 minecraft:spruce_planks
fill 52 260 275 54 286 275 minecraft:light_blue_concrete
setblock 53 260 317 minecraft:light_blue_wool
fill 54 260 317 54 264 317 minecraft:light_blue_concrete
setblock 55 260 317 minecraft:white_wool
fill 56 260 316 61 260 316 minecraft:spruce_planks
fill 56 260 317 56 274 317 minecraft:light_blue_concrete
fill 58 260 276 63 260 276 minecraft:spruce_planks
fill 63 260 316 68 260 316 minecraft:spruce_planks
fill 65 260 276 70 260 276 minecraft:spruce_planks
fill 70 260 316 75 260 316 minecraft:spruce_planks
fill 72 260 276 77 260 276 minecraft:spruce_planks
setblock 74 260 275 minecraft:light_blue_wool
fill 75 260 275 84 276 275 minecraft:light_blue_concrete
fill 77 260 316 82 260 316 minecraft:spruce_planks
fill 79 260 276 84 260 276 minecraft:spruce_planks
fill 84 260 316 88 260 316 minecraft:spruce_planks
fill 86 260 276 88 260 276 minecraft:spruce_planks
fill 88 260 277 88 260 279 minecraft:spruce_planks
fill 88 260 281 88 260 286 minecraft:spruce_planks
fill 88 260 288 88 260 293 minecraft:spruce_planks
fill 88 260 295 88 260 300 minecraft:spruce_planks
fill 88 260 302 88 260 307 minecraft:spruce_planks
fill 88 260 309 88 260 314 minecraft:spruce_planks
fill 89 260 284 89 263 285 minecraft:light_blue_concrete
setblock 89 260 286 minecraft:light_blue_wool
fill 89 260 287 89 272 288 minecraft:light_blue_concrete
fill 47 261 285 47 308 285 minecraft:light_blue_concrete
setblock 48 261 276 minecraft:spruce_planks
setblock 48 261 283 minecraft:spruce_planks
setblock 48 261 290 minecraft:spruce_planks
setblock 48 261 297 minecraft:spruce_planks
setblock 48 261 304 minecraft:spruce_planks
setblock 48 261 311 minecraft:spruce_planks
setblock 50 261 278 minecraft:light[level=12]
setblock 50 261 285 minecraft:light[level=12]
setblock 50 261 292 minecraft:light[level=12]
setblock 50 261 299 minecraft:light[level=12]
setblock 50 261 306 minecraft:light[level=12]
setblock 50 261 313 minecraft:light[level=12]
setblock 50 261 316 minecraft:spruce_planks
fill 51 261 275 51 308 275 minecraft:light_blue_concrete
setblock 53 261 317 minecraft:light_blue_concrete
setblock 55 261 276 minecraft:spruce_planks
fill 55 261 317 55 264 317 minecraft:light_blue_concrete
setblock 57 261 278 minecraft:light[level=12]
setblock 57 261 285 minecraft:light[level=12]
setblock 57 261 292 minecraft:light[level=12]
setblock 57 261 299 minecraft:light[level=12]
setblock 57 261 306 minecraft:light[level=12]
setblock 57 261 313 minecraft:light[level=12]
setblock 57 261 316 minecraft:spruce_planks
setblock 62 261 276 minecraft:spruce_planks
setblock 64 261 278 minecraft:light[level=12]
setblock 64 261 285 minecraft:light[level=12]
setblock 64 261 292 minecraft:light[level=12]
setblock 64 261 299 minecraft:light[level=12]
setblock 64 261 306 minecraft:light[level=12]
setblock 64 261 313 minecraft:light[level=12]
setblock 64 261 316 minecraft:spruce_planks
setblock 69 261 276 minecraft:spruce_planks
setblock 71 261 278 minecraft:light[level=12]
setblock 71 261 285 minecraft:light[level=12]
setblock 71 261 292 minecraft:light[level=12]
setblock 71 261 299 minecraft:light[level=12]
setblock 71 261 306 minecraft:light[level=12]
setblock 71 261 313 minecraft:light[level=12]
setblock 71 261 316 minecraft:spruce_planks
fill 74 261 275 74 308 275 minecraft:light_blue_concrete
setblock 76 261 276 minecraft:spruce_planks
setblock 78 261 278 minecraft:light[level=12]
setblock 78 261 285 minecraft:light[level=12]
setblock 78 261 292 minecraft:light[level=12]
setblock 78 261 299 minecraft:light[level=12]
setblock 78 261 306 minecraft:light[level=12]
setblock 78 261 313 minecraft:light[level=12]
setblock 78 261 316 minecraft:spruce_planks
setblock 83 261 276 minecraft:spruce_planks
setblock 85 261 278 minecraft:light[level=12]
setblock 85 261 285 minecraft:light[level=12]
setblock 85 261 292 minecraft:light[level=12]
setblock 85 261 299 minecraft:light[level=12]
setblock 85 261 306 minecraft:light[level=12]
setblock 85 261 313 minecraft:light[level=12]
setblock 85 261 316 minecraft:spruce_planks
setblock 88 261 278 minecraft:spruce_planks
setblock 88 261 285 minecraft:spruce_planks
setblock 88 261 292 minecraft:spruce_planks
setblock 88 261 299 minecraft:spruce_planks
setblock 88 261 306 minecraft:spruce_planks
setblock 88 261 313 minecraft:spruce_planks
fill 89 261 286 89 271 286 minecraft:light_blue_concrete
setblock 48 262 277 minecraft:spruce_planks
setblock 48 262 284 minecraft:spruce_planks
setblock 48 262 291 minecraft:spruce_planks
setblock 48 262 298 minecraft:spruce_planks
setblock 48 262 305 minecraft:spruce_planks
setblock 48 262 312 minecraft:spruce_planks
setblock 51 262 316 minecraft:spruce_planks
setblock 53 262 317 minecraft:white_wool
setblock 54 262 276 minecraft:spruce_planks
fill 56 262 314 62 263 314 minecraft:iron_bars
setblock 58 262 316 minecraft:spruce_planks
setblock 61 262 276 minecraft:spruce_planks
fill 65 262 279 65 263 279 minecraft:shroomlight
setblock 65 262 316 minecraft:spruce_planks
setblock 68 262 276 minecraft:spruce_planks
setblock 72 262 316 minecraft:spruce_planks
setblock 75 262 276 minecraft:spruce_planks
setblock 79 262 316 minecraft:spruce_planks
setblock 82 262 276 minecraft:spruce_planks
fill 84 262 280 84 270 280 minecraft:green_terracotta
setblock 86 262 316 minecraft:spruce_planks
setblock 88 262 277 minecraft:spruce_planks
setblock 88 262 284 minecraft:spruce_planks
setblock 88 262 291 minecraft:spruce_planks
setblock 88 262 298 minecraft:spruce_planks
setblock 88 262 305 minecraft:spruce_planks
setblock 88 262 312 minecraft:spruce_planks
setblock 89 262 281 minecraft:white_wool
fill 89 262 282 89 308 282 minecraft:light_blue_concrete
fill 47 263 298 47 299 299 minecraft:light_blue_concrete
setblock 47 263 300 minecraft:light_blue_wool
fill 47 263 301 47 267 308 minecraft:light_blue_concrete
setblock 48 263 278 minecraft:spruce_planks
fill 48 263 280 56 269 280 minecraft:white_wool
setblock 48 263 285 minecraft:spruce_planks
setblock 48 263 292 minecraft:spruce_planks
setblock 48 263 299 minecraft:spruce_planks
setblock 48 263 306 minecraft:spruce_planks
setblock 48 263 313 minecraft:spruce_planks
setblock 52 263 316 minecraft:spruce_planks
setblock 53 263 276 minecraft:spruce_planks
fill 53 263 317 53 308 317 minecraft:light_blue_concrete
setblock 59 263 316 minecraft:spruce_planks
setblock 60 263 276 minecraft:spruce_planks
setblock 66 263 316 minecraft:spruce_planks
setblock 67 263 276 minecraft:spruce_planks
setblock 73 263 316 minecraft:spruce_planks
setblock 74 263 276 minecraft:spruce_planks
fill 80 263 312 88 269 312 minecraft:white_wool
setblock 80 263 316 minecraft:spruce_planks
setblock 81 263 276 minecraft:spruce_planks
setblock 87 263 316 minecraft:spruce_planks
setblock 88 263 276 minecraft:spruce_planks
setblock 88 263 283 minecraft:spruce_planks
setblock 88 263 290 minecraft:spruce_planks
setblock 88 263 297 minecraft:spruce_planks
setblock 88 263 304 minecraft:spruce_planks
setblock 88 263 311 minecraft:spruce_planks
fill 89 263 281 89 308 281 minecraft:light_blue_concrete
setblock 47 264 284 minecraft:white_wool
fill 47 264 300 47 308 300 minecraft:light_blue_concrete
setblock 48 264 279 minecraft:spruce_planks
setblock 48 264 286 minecraft:spruce_planks
setblock 48 264 293 minecraft:spruce_planks
setblock 48 264 300 minecraft:spruce_planks
setblock 48 264 307 minecraft:spruce_planks
setblock 48 264 314 minecraft:spruce_planks
setblock 52 264 276 minecraft:spruce_planks
setblock 53 264 316 minecraft:spruce_planks
setblock 59 264 276 minecraft:spruce_planks
setblock 60 264 316 minecraft:spruce_planks
fill 65 264 279 65 270 280 minecraft:dark_oak_planks
setblock 66 264 276 minecraft:spruce_planks
setblock 67 264 316 minecraft:spruce_planks
fill 72 264 317 72 308 317 minecraft:light_blue_concrete
setblock 73 264 276 minecraft:spruce_planks
setblock 73 264 317 minecraft:white_wool
setblock 74 264 316 minecraft:spruce_planks
fill 74 264 317 76 308 317 minecraft:light_blue_concrete
setblock 80 264 276 minecraft:spruce_planks
setblock 81 264 316 minecraft:spruce_planks
setblock 87 264 276 minecraft:spruce_planks
setblock 88 264 282 minecraft:spruce_planks
setblock 88 264 289 minecraft:spruce_planks
setblock 88 264 296 minecraft:spruce_planks
setblock 88 264 303 minecraft:spruce_planks
setblock 88 264 310 minecraft:spruce_planks
setblock 88 264 316 minecraft:spruce_planks
setblock 89 264 284 minecraft:white_wool
fill 89 264 285 89 308 285 minecraft:light_blue_concrete
fill 89 264 290 89 274 295 minecraft:light_blue_concrete
setblock 89 264 296 minecraft:light_blue_wool
fill 47 265 284 47 270 284 minecraft:light_blue_concrete
setblock 48 265 287 minecraft:spruce_planks
setblock 48 265 294 minecraft:spruce_planks
setblock 48 265 301 minecraft:spruce_planks
setblock 48 265 308 minecraft:spruce_planks
setblock 48 265 315 minecraft:spruce_planks
setblock 50 265 278 minecraft:light[level=15]
setblock 50 265 286 minecraft:light[level=15]
setblock 50 265 294 minecraft:light[level=15]
setblock 50 265 302 minecraft:light[level=15]
setblock 50 265 310 minecraft:light[level=15]
setblock 50 265 317 minecraft:light_blue_wool
setblock 51 265 276 minecraft:spruce_planks
fill 51 265 317 51 274 317 minecraft:light_blue_concrete
setblock 54 265 316 minecraft:spruce_planks
fill 54 265 317 55 265 317 minecraft:light_blue_wool
setblock 58 265 276 minecraft:spruce_planks
setblock 58 265 278 minecraft:light[level=15]
setblock 58 265 286 minecraft:light[level=15]
setblock 58 265 294 minecraft:light[level=15]
setblock 58 265 302 minecraft:light[level=15]
setblock 58 265 310 minecraft:light[level=15]
fill 61 265 276 62 266 278 minecraft:spruce_planks
setblock 61 265 316 minecraft:spruce_planks
fill 62 265 279 62 266 286 minecraft:spruce_planks
fill 63 265 284 63 266 293 minecraft:spruce_planks
setblock 65 265 276 minecraft:spruce_planks
setblock 66 265 278 minecraft:light[level=15]
setblock 66 265 286 minecraft:light[level=15]
setblock 66 265 294 minecraft:light[level=15]
setblock 66 265 302 minecraft:light[level=15]
setblock 66 265 310 minecraft:light[level=15]
setblock 68 265 316 minecraft:spruce_planks
setblock 72 265 276 minecraft:spruce_planks
fill 73 265 317 73 286 317 minecraft:light_blue_concrete
setblock 74 265 278 minecraft:light[level=15]
setblock 74 265 286 minecraft:light[level=15]
setblock 74 265 294 minecraft:light[level=15]
setblock 74 265 302 minecraft:light[level=15]
setblock 74 265 310 minecraft:light[level=15]
setblock 75 265 316 minecraft:spruce_planks
setblock 79 265 276 minecraft:spruce_planks
setblock 82 265 278 minecraft:light[level=15]
setblock 82 265 286 minecraft:light[level=15]
setblock 82 265 294 minecraft:light[level=15]
setblock 82 265 302 minecraft:light[level=15]
setblock 82 265 310 minecraft:light[level=15]
setblock 82 265 316 minecraft:spruce_planks
setblock 86 265 276 minecraft:spruce_planks
setblock 88 265 281 minecraft:spruce_planks
setblock 88 265 288 minecraft:spruce_planks
setblock 88 265 295 minecraft:spruce_planks
setblock 88 265 302 minecraft:spruce_planks
setblock 88 265 309 minecraft:spruce_planks
fill 89 265 284 89 308 284 minecraft:light_blue_concrete
fill 89 265 296 89 308 296 minecraft:light_blue_concrete
fill 50 266 317 50 269 317 minecraft:light_blue_concrete
fill 54 266 317 55 308 317 minecraft:light_blue_concrete
setblock 61 266 279 minecraft:spruce_planks
fill 62 266 287 62 266 290 minecraft:spruce_planks
fill 63 266 281 63 266 283 minecraft:spruce_planks
fill 63 266 294 63 266 298 minecraft:spruce_planks
setblock 63 266 300 minecraft:spruce_planks
fill 64 266 291 64 266 296 minecraft:spruce_planks
fill 64 266 302 64 266 310 minecraft:spruce_planks
fill 65 266 303 65 266 316 minecraft:spruce_planks
fill 66 266 279 66 269 280 minecraft:dark_oak_planks
fill 66 266 312 66 266 316 minecraft:spruce_planks
fill 80 266 317 82 271 317 minecraft:light_blue_concrete
setblock 83 266 317 minecraft:white_wool
fill 84 266 317 85 281 317 minecraft:light_blue_concrete
setblock 47 267 309 minecraft:white_wool
fill 47 267 310 47 308 311 minecraft:light_blue_concrete
setblock 48 267 282 minecraft:spruce_planks
setblock 48 267 289 minecraft:spruce_planks
setblock 48 267 296 minecraft:spruce_planks
setblock 48 267 303 minecraft:spruce_planks
setblock 48 267 310 minecraft:spruce_planks
setblock 49 267 276 minecraft:spruce_planks
setblock 49 267 316 minecraft:spruce_planks
setblock 50 267 278 minecraft:light[level=12]
setblock 50 267 285 minecraft:light[level=12]
setblock 50 267 292 minecraft:light[level=12]
setblock 50 267 299 minecraft:light[level=12]
setblock 50 267 306 minecraft:light[level=12]
setblock 50 267 313 minecraft:light[level=12]
setblock 56 267 276 minecraft:spruce_planks
setblock 56 267 316 minecraft:spruce_planks
setblock 57 267 278 minecraft:light[level=12]
setblock 57 267 285 minecraft:light[level=12]
setblock 57 267 292 minecraft:light[level=12]
setblock 57 267 299 minecraft:light[level=12]
setblock 57 267 306 minecraft:light[level=12]
setblock 57 267 313 minecraft:light[level=12]
fill 62 267 276 62 267 285 minecraft:dark_oak_planks
setblock 63 267 276 minecraft:spruce_planks
fill 63 267 286 63 267 294 minecraft:dark_oak_planks
setblock 63 267 316 minecraft:spruce_planks
setblock 64 267 278 minecraft:light[level=12]
fill 64 267 279 64 270 280 minecraft:dark_oak_planks
setblock 64 267 285 minecraft:light[level=12]
setblock 64 267 292 minecraft:light[level=12]
setblock 64 267 299 minecraft:light[level=12]
fill 64 267 302 64 267 308 minecraft:spruce_planks
setblock 64 267 313 minecraft:light[level=12]
fill 65 267 278 66 269 278 minecraft:dark_oak_planks
fill 65 267 281 66 269 281 minecraft:dark_oak_planks
fill 65 267 305 65 267 316 minecraft:spruce_planks
fill 66 267 313 66 267 316 minecraft:spruce_planks
fill 69 267 310 69 268 314 minecraft:spruce_planks
setblock 70 267 276 minecraft:spruce_planks
fill 70 267 311 70 268 316 minecraft:spruce_planks
setblock 71 267 278 minecraft:light[level=12]
setblock 71 267 285 minecraft:light[level=12]
setblock 71 267 292 minecraft:light[level=12]
setblock 71 267 299 minecraft:light[level=12]
setblock 71 267 306 minecraft:light[level=12]
setblock 71 267 313 minecraft:light[level=12]
setblock 77 267 276 minecraft:spruce_planks
setblock 77 267 316 minecraft:spruce_planks
setblock 78 267 278 minecraft:light[level=12]
setblock 78 267 285 minecraft:light[level=12]
setblock 78 267 292 minecraft:light[level=12]
setblock 78 267 299 minecraft:light[level=12]
setblock 78 267 306 minecraft:light[level=12]
setblock 78 267 313 minecraft:light[level=12]
fill 83 267 317 83 287 317 minecraft:light_blue_concrete
setblock 84 267 276 minecraft:spruce_planks
setblock 84 267 316 minecraft:spruce_planks
setblock 85 267 278 minecraft:light[level=12]
setblock 85 267 285 minecraft:light[level=12]
setblock 85 267 292 minecraft:light[level=12]
setblock 85 267 299 minecraft:light[level=12]
setblock 85 267 306 minecraft:light[level=12]
setblock 85 267 313 minecraft:light[level=12]
setblock 88 267 279 minecraft:spruce_planks
setblock 88 267 286 minecraft:spruce_planks
setblock 88 267 293 minecraft:spruce_planks
setblock 88 267 300 minecraft:spruce_planks
setblock 88 267 307 minecraft:spruce_planks
setblock 88 267 314 minecraft:spruce_planks
setblock 47 268 293 minecraft:light_blue_wool
fill 47 268 301 47 275 307 minecraft:light_blue_concrete
setblock 47 268 308 minecraft:white_wool
fill 47 268 309 47 308 309 minecraft:light_blue_concrete
setblock 48 268 276 minecraft:spruce_planks
setblock 48 268 283 minecraft:spruce_planks
setblock 48 268 290 minecraft:spruce_planks
setblock 48 268 297 minecraft:spruce_planks
setblock 48 268 304 minecraft:spruce_planks
setblock 48 268 311 minecraft:spruce_planks
setblock 50 268 316 minecraft:spruce_planks
setblock 55 268 276 minecraft:spruce_planks
setblock 57 268 316 minecraft:spruce_planks
setblock 62 268 276 minecraft:spruce_planks
fill 64 268 278 64 270 278 minecraft:dark_oak_planks
fill 64 268 281 64 270 281 minecraft:dark_oak_planks
fill 64 268 302 64 268 304 minecraft:dark_oak_planks
setblock 64 268 316 minecraft:spruce_planks
fill 65 268 307 65 268 315 minecraft:dark_oak_planks
fill 67 268 279 67 269 280 minecraft:dark_oak_planks
fill 68 268 303 69 268 306 minecraft:spruce_planks
setblock 69 268 276 minecraft:spruce_planks
fill 69 268 302 69 269 302 minecraft:spruce_planks
fill 69 268 307 70 268 309 minecraft:spruce_planks
setblock 69 268 315 minecraft:spruce_planks
setblock 70 268 310 minecraft:spruce_planks
setblock 71 268 316 minecraft:spruce_planks
setblock 76 268 276 minecraft:spruce_planks
setblock 78 268 316 minecraft:spruce_planks
setblock 83 268 276 minecraft:spruce_planks
setblock 85 268 316 minecraft:spruce_planks
setblock 88 268 278 minecraft:spruce_planks
setblock 88 268 285 minecraft:spruce_planks
setblock 88 268 292 minecraft:spruce_planks
setblock 88 268 299 minecraft:spruce_planks
setblock 88 268 306 minecraft:spruce_planks
setblock 88 268 313 minecraft:spruce_planks
setblock 47 269 287 minecraft:white_wool
fill 47 269 288 47 269 291 minecraft:light_blue_concrete
fill 47 269 293 47 297 293 minecraft:light_blue_concrete
fill 47 269 308 47 308 308 minecraft:light_blue_concrete
fill 48 269 277 48 270 277 minecraft:spruce_planks
fill 48 269 284 48 270 284 minecraft:spruce_planks
fill 48 269 291 48 270 291 minecraft:spruce_planks
fill 48 269 298 48 270 298 minecraft:spruce_planks
fill 48 269 305 48 270 305 minecraft:spruce_planks
fill 48 269 312 48 270 312 minecraft:spruce_planks
fill 51 269 316 51 270 316 minecraft:spruce_planks
fill 54 269 276 54 270 276 minecraft:spruce_planks
fill 58 269 316 58 270 316 minecraft:spruce_planks
fill 61 269 276 61 270 276 minecraft:spruce_planks
fill 63 269 279 63 270 280 minecraft:dark_oak_planks
setblock 65 269 277 minecraft:dark_oak_planks
fill 65 269 282 65 270 282 minecraft:dark_oak_planks
fill 65 269 316 65 270 316 minecraft:spruce_planks
fill 67 269 278 67 270 278 minecraft:dark_oak_planks
setblock 67 269 281 minecraft:dark_oak_planks
fill 67 269 284 67 269 295 minecraft:spruce_planks
fill 68 269 276 68 270 276 minecraft:spruce_planks
fill 68 269 290 68 270 295 minecraft:spruce_planks
fill 68 269 303 69 269 304 minecraft:spruce_planks
fill 69 269 305 69 269 308 minecraft:spruce_planks
fill 69 269 309 69 269 311 minecraft:dark_oak_planks
fill 70 269 312 70 269 316 minecraft:dark_oak_planks
fill 72 269 316 72 270 316 minecraft:spruce_planks
fill 75 269 276 75 270 276 minecraft:spruce_planks
fill 79 269 316 79 270 316 minecraft:spruce_planks
fill 82 269 276 82 270 276 minecraft:spruce_planks
fill 86 269 275 86 308 275 minecraft:light_blue_concrete
fill 86 269 316 86 270 316 minecraft:spruce_planks
setblock 87 269 275 minecraft:light_blue_wool
fill 88 269 275 89 287 275 minecraft:light_blue_concrete
fill 88 269 277 88 270 277 minecraft:spruce_planks
fill 88 269 284 88 270 284 minecraft:spruce_planks
fill 88 269 291 88 270 291 minecraft:spruce_planks
fill 88 269 298 88 270 298 minecraft:spruce_planks
fill 88 269 305 88 270 305 minecraft:spruce_planks
fill 47 270 287 47 298 287 minecraft:light_blue_concrete
setblock 47 270 288 minecraft:white_wool
fill 47 270 289 47 278 291 minecraft:light_blue_concrete
fill 48 270 276 49 270 276 minecraft:spruce_planks
fill 48 270 278 48 270 279 minecraft:spruce_planks
fill 48 270 280 56 270 280 minecraft:spruce_log
fill 48 270 282 48 270 283 minecraft:spruce_planks
fill 48 270 285 48 270 287 minecraft:spruce_planks
fill 48 270 289 48 270 290 minecraft:spruce_planks
fill 48 270 292 48 270 294 minecraft:spruce_planks
fill 48 270 296 48 270 297 minecraft:spruce_planks
fill 48 270 299 48 270 301 minecraft:spruce_planks
fill 48 270 303 48 270 304 minecraft:spruce_planks
fill 48 270 306 48 270 308 minecraft:spruce_planks
fill 48 270 310 48 270 311 minecraft:spruce_planks
fill 48 270 313 48 270 315 minecraft:spruce_planks
fill 49 270 316 50 270 316 minecraft:spruce_planks
setblock 50 270 317 minecraft:light_blue_wool
fill 51 270 276 53 270 276 minecraft:spruce_planks
fill 52 270 316 54 270 316 minecraft:spruce_planks
fill 55 270 276 56 270 276 minecraft:spruce_planks
fill 56 270 316 57 270 316 minecraft:spruce_planks
fill 58 270 276 60 270 276 minecraft:spruce_planks
fill 59 270 316 61 270 316 minecraft:spruce_planks
fill 62 270 276 63 270 276 minecraft:spruce_planks
setblock 63 270 278 minecraft:dark_oak_planks
setblock 63 270 281 minecraft:dark_oak_planks
fill 63 270 316 64 270 316 minecraft:spruce_planks
setblock 64 270 277 minecraft:dark_oak_planks
setblock 64 270 282 minecraft:dark_oak_planks
fill 65 270 276 66 270 278 minecraft:spruce_planks
setblock 65 270 281 minecraft:dark_oak_planks
fill 66 270 279 67 270 287 minecraft:spruce_planks
fill 66 270 316 68 270 316 minecraft:spruce_planks
setblock 67 270 276 minecraft:spruce_planks
fill 67 270 288 67 270 293 minecraft:spruce_planks
fill 68 270 279 68 270 280 minecraft:dark_oak_planks
fill 69 270 276 70 270 276 minecraft:spruce_planks
fill 69 270 302 69 270 307 minecraft:dark_oak_planks
fill 70 270 316 71 270 316 minecraft:spruce_planks
fill 72 270 276 74 270 276 minecraft:spruce_planks
fill 73 270 316 75 270 316 minecraft:spruce_planks
fill 76 270 276 77 270 276 minecraft:spruce_planks
fill 77 270 316 78 270 316 minecraft:spruce_planks
setblock 77 270 317 minecraft:white_wool
fill 78 270 317 78 308 317 minecraft:light_blue_concrete
fill 79 270 276 81 270 276 minecraft:spruce_planks
fill 80 270 312 88 270 312 minecraft:spruce_log
fill 80 270 316 82 270 316 minecraft:spruce_planks
fill 83 270 276 84 270 276 minecraft:spruce_planks
fill 84 270 316 85 270 316 minecraft:spruce_planks
fill 86 270 276 88 270 276 minecraft:spruce_planks
fill 87 270 275 87 308 275 minecraft:light_blue_concrete
fill 87 270 316 88 270 316 minecraft:spruce_planks
fill 88 270 278 88 270 279 minecraft:spruce_planks
fill 88 270 281 88 270 283 minecraft:spruce_planks
fill 88 270 285 88 270 286 minecraft:spruce_planks
fill 88 270 288 88 270 290 minecraft:spruce_planks
fill 88 270 292 88 270 293 minecraft:spruce_planks
fill 88 270 295 88 270 297 minecraft:spruce_planks
fill 88 270 299 88 270 300 minecraft:spruce_planks
fill 88 270 302 88 270 304 minecraft:spruce_planks
fill 88 270 306 88 270 307 minecraft:spruce_planks
fill 88 270 309 88 270 311 minecraft:spruce_planks
fill 88 270 313 88 270 314 minecraft:spruce_planks
setblock 47 271 284 minecraft:light_blue_wool
fill 47 271 288 47 308 288 minecraft:light_blue_concrete
setblock 48 271 279 minecraft:spruce_planks
setblock 48 271 286 minecraft:spruce_planks
setblock 48 271 293 minecraft:spruce_planks
setblock 48 271 300 minecraft:spruce_planks
setblock 48 271 307 minecraft:spruce_planks
setblock 48 271 314 minecraft:spruce_planks
fill 50 271 317 50 308 317 minecraft:light_blue_concrete
fill 51 271 280 53 277 280 minecraft:spruce_log
setblock 52 271 276 minecraft:spruce_planks
setblock 53 271 316 minecraft:spruce_planks
setblock 59 271 276 minecraft:spruce_planks
setblock 60 271 316 minecraft:spruce_planks
fill 64 271 281 64 272 281 minecraft:spruce_planks
fill 65 271 276 66 271 276 minecraft:spruce_planks
fill 65 271 278 66 271 278 minecraft:spruce_planks
setblock 66 271 277 minecraft:spruce_planks
fill 66 271 279 66 271 281 minecraft:spruce_planks
setblock 66 271 282 minecraft:dark_oak_planks
fill 67 271 280 67 272 280 minecraft:spruce_planks
fill 67 271 284 67 271 292 minecraft:dark_oak_planks
setblock 67 271 316 minecraft:spruce_planks
setblock 73 271 276 minecraft:spruce_planks
setblock 74 271 316 minecraft:spruce_planks
fill 77 271 317 77 299 317 minecraft:light_blue_concrete
setblock 80 271 276 minecraft:spruce_planks
setblock 81 271 316 minecraft:spruce_planks
fill 83 271 312 85 277 312 minecraft:spruce_log
setblock 87 271 276 minecraft:spruce_planks
setblock 88 271 282 minecraft:spruce_planks
setblock 88 271 289 minecraft:spruce_planks
setblock 88 271 296 minecraft:spruce_planks
setblock 88 271 303 minecraft:spruce_planks
setblock 88 271 310 minecraft:spruce_planks
setblock 88 271 316 minecraft:spruce_planks
fill 89 271 298 89 273 305 minecraft:light_blue_concrete
setblock 89 271 306 minecraft:white_wool
fill 47 272 284 47 292 284 minecraft:light_blue_concrete
setblock 48 272 280 minecraft:spruce_planks
setblock 48 272 287 minecraft:spruce_planks
setblock 48 272 294 minecraft:spruce_planks
setblock 48 272 301 minecraft:spruce_planks
setblock 48 272 308 minecraft:spruce_planks
setblock 48 272 315 minecraft:spruce_planks
setblock 51 272 276 minecraft:spruce_planks
setblock 54 272 316 minecraft:spruce_planks
setblock 58 272 276 minecraft:spruce_planks
setblock 61 272 316 minecraft:spruce_planks
setblock 62 272 317 minecraft:light_blue_wool
setblock 65 272 276 minecraft:spruce_planks
setblock 65 272 278 minecraft:spruce_planks
fill 66 272 276 66 272 280 minecraft:dark_oak_planks
setblock 68 272 316 minecraft:spruce_planks
setblock 72 272 276 minecraft:spruce_planks
setblock 75 272 316 minecraft:spruce_planks
setblock 79 272 276 minecraft:spruce_planks
fill 80 272 317 81 300 317 minecraft:light_blue_concrete
setblock 82 272 316 minecraft:spruce_planks
setblock 82 272 317 minecraft:light_blue_wool
setblock 86 272 276 minecraft:spruce_planks
setblock 88 272 281 minecraft:spruce_planks
setblock 88 272 288 minecraft:spruce_planks
setblock 88 272 295 minecraft:spruce_planks
setblock 88 272 302 minecraft:spruce_planks
setblock 88 272 309 minecraft:spruce_planks
setblock 89 272 286 minecraft:light_blue_wool
fill 89 272 306 89 308 306 minecraft:light_blue_concrete
setblock 89 272 308 minecraft:light_blue_wool
setblock 50 273 278 minecraft:light[level=15]
setblock 50 273 285 minecraft:light[level=12]
setblock 50 273 286 minecraft:light[level=15]
setblock 50 273 292 minecraft:light[level=12]
setblock 50 273 294 minecraft:light[level=15]
setblock 50 273 299 minecraft:light[level=12]
setblock 50 273 302 minecraft:light[level=15]
setblock 50 273 306 minecraft:light[level=12]
setblock 50 273 310 minecraft:light[level=15]
setblock 50 273 313 minecraft:light[level=12]
setblock 57 273 278 minecraft:light[level=12]
setblock 57 273 285 minecraft:light[level=12]
setblock 57 273 292 minecraft:light[level=12]
setblock 57 273 299 minecraft:light[level=12]
setblock 57 273 306 minecraft:light[level=12]
setblock 57 273 313 minecraft:light[level=12]
setblock 58 273 278 minecraft:light[level=15]
setblock 58 273 286 minecraft:light[level=15]
setblock 58 273 294 minecraft:light[level=15]
setblock 58 273 302 minecraft:light[level=15]
setblock 58 273 310 minecraft:light[level=15]
fill 62 273 317 62 282 317 minecraft:light_blue_concrete
setblock 64 273 278 minecraft:light[level=12]
setblock 64 273 285 minecraft:light[level=12]
setblock 64 273 292 minecraft:light[level=12]
setblock 64 273 299 minecraft:light[level=12]
setblock 64 273 306 minecraft:light[level=12]
setblock 64 273 313 minecraft:light[level=12]
setblock 66 273 278 minecraft:light[level=15]
setblock 66 273 286 minecraft:light[level=15]
setblock 66 273 294 minecraft:light[level=15]
setblock 66 273 302 minecraft:light[level=15]
setblock 66 273 310 minecraft:light[level=15]
setblock 71 273 278 minecraft:light[level=12]
setblock 71 273 285 minecraft:light[level=12]
setblock 71 273 292 minecraft:light[level=12]
setblock 71 273 299 minecraft:light[level=12]
setblock 71 273 306 minecraft:light[level=12]
setblock 71 273 313 minecraft:light[level=12]
setblock 74 273 278 minecraft:light[level=15]
setblock 74 273 286 minecraft:light[level=15]
setblock 74 273 294 minecraft:light[level=15]
setblock 74 273 302 minecraft:light[level=15]
setblock 74 273 310 minecraft:light[level=15]
setblock 78 273 278 minecraft:light[level=12]
setblock 78 273 285 minecraft:light[level=12]
setblock 78 273 292 minecraft:light[level=12]
setblock 78 273 299 minecraft:light[level=12]
setblock 78 273 306 minecraft:light[level=12]
setblock 78 273 313 minecraft:light[level=12]
setblock 82 273 278 minecraft:light[level=15]
setblock 82 273 286 minecraft:light[level=15]
setblock 82 273 294 minecraft:light[level=15]
setblock 82 273 302 minecraft:light[level=15]
setblock 82 273 310 minecraft:light[level=15]
fill 82 273 317 82 308 317 minecraft:light_blue_concrete
setblock 85 273 278 minecraft:light[level=12]
setblock 85 273 285 minecraft:light[level=12]
setblock 85 273 292 minecraft:light[level=12]
setblock 85 273 299 minecraft:light[level=12]
setblock 85 273 306 minecraft:light[level=12]
setblock 85 273 313 minecraft:light[level=12]
fill 89 273 278 89 274 279 minecraft:light_blue_concrete
setblock 89 273 280 minecraft:white_wool
fill 89 273 286 89 308 287 minecraft:light_blue_concrete
setblock 89 273 288 minecraft:white_wool
fill 89 273 308 89 308 308 minecraft:light_blue_concrete
fill 89 274 280 89 306 280 minecraft:light_blue_concrete
fill 89 274 288 89 308 288 minecraft:light_blue_concrete
fill 89 274 298 89 278 304 minecraft:light_blue_concrete
setblock 89 274 305 minecraft:light_blue_wool
setblock 51 275 317 minecraft:light_blue_wool
setblock 56 275 317 minecraft:white_wool
setblock 89 275 278 minecraft:light_blue_wool
fill 89 275 279 89 308 279 minecraft:light_blue_concrete
fill 89 275 290 89 277 293 minecraft:light_blue_concrete
setblock 89 275 294 minecraft:light_blue_wool
fill 89 275 295 89 308 295 minecraft:light_blue_concrete
fill 89 275 305 89 308 305 minecraft:light_blue_concrete
fill 47 276 280 47 297 280 minecraft:light_blue_concrete
setblock 47 276 281 minecraft:white_wool
fill 47 276 301 47 296 306 minecraft:light_blue_concrete
setblock 47 276 307 minecraft:white_wool
fill 51 276 317 51 308 317 minecraft:light_blue_concrete
fill 56 276 317 56 308 317 minecraft:light_blue_concrete
fill 69 276 317 69 289 317 minecraft:light_blue_concrete
setblock 70 276 317 minecraft:white_wool
fill 71 276 317 71 305 317 minecraft:light_blue_concrete
fill 89 276 278 89 308 278 minecraft:light_blue_concrete
fill 89 276 294 89 281 294 minecraft:light_blue_concrete
fill 47 277 281 47 308 281 minecraft:light_blue_concrete
fill 47 277 307 47 308 307 minecraft:light_blue_concrete
fill 64 277 275 71 278 275 minecraft:light_blue_concrete
fill 64 277 317 66 308 317 minecraft:light_blue_concrete
setblock 67 277 317 minecraft:white_wool
fill 70 277 317 70 299 317 minecraft:light_blue_concrete
setblock 72 277 275 minecraft:light_blue_wool
fill 75 277 275 82 289 275 minecraft:light_blue_concrete
setblock 83 277 275 minecraft:white_wool
fill 84 277 275 84 308 275 minecraft:light_blue_concrete
setblock 86 277 317 minecraft:white_wool
fill 47 278 294 47 308 294 minecraft:light_blue_concrete
setblock 47 278 295 minecraft:light_blue_wool
fill 48 278 276 88 279 280 minecraft:white_wool
fill 48 278 281 88 279 281 minecraft:light_gray_wool
fill 48 278 282 88 279 286 minecraft:white_wool
fill 48 278 287 88 279 287 minecraft:light_gray_wool
fill 48 278 288 88 279 292 minecraft:white_wool
fill 48 278 293 88 279 293 minecraft:light_gray_wool
fill 48 278 294 64 278 298 minecraft:white_wool
fill 48 278 299 63 278 299 minecraft:light_gray_wool
fill 48 278 300 64 278 304 minecraft:white_wool
fill 48 278 305 88 278 305 minecraft:light_gray_wool
fill 48 278 306 88 278 310 minecraft:white_wool
fill 48 278 311 88 278 311 minecraft:light_gray_wool
fill 48 278 312 88 278 316 minecraft:white_wool
fill 65 278 294 66 278 296 minecraft:white_wool
fill 65 278 302 66 278 304 minecraft:white_wool
fill 67 278 294 88 278 295 minecraft:white_wool
fill 67 278 303 88 278 304 minecraft:white_wool
fill 67 278 317 67 308 317 minecraft:light_blue_concrete
fill 68 278 296 88 278 296 minecraft:white_wool
fill 68 278 302 88 278 302 minecraft:white_wool
fill 70 278 297 88 278 298 minecraft:white_wool
fill 70 278 300 88 278 301 minecraft:white_wool
fill 71 278 299 88 278 299 minecraft:light_gray_wool
fill 72 278 275 72 308 275 minecraft:light_blue_concrete
fill 83 278 275 83 308 275 minecraft:light_blue_concrete
fill 86 278 317 86 308 317 minecraft:light_blue_concrete
fill 89 278 290 89 308 290 minecraft:light_blue_concrete
setblock 89 278 291 minecraft:white_wool
fill 89 278 292 89 295 293 minecraft:light_blue_concrete
setblock 47 279 277 minecraft:light_blue_wool
fill 47 279 278 47 308 278 minecraft:light_blue_concrete
setblock 47 279 289 minecraft:white_wool
fill 47 279 290 47 290 291 minecraft:light_blue_concrete
fill 47 279 295 47 283 295 minecraft:light_blue_concrete
fill 48 279 294 62 279 298 minecraft:white_wool
fill 48 279 299 62 279 299 minecraft:light_gray_wool
fill 48 279 300 62 279 304 minecraft:white_wool
fill 48 279 305 67 279 305 minecraft:light_gray_wool
fill 48 279 306 67 279 310 minecraft:white_wool
fill 48 279 311 69 279 311 minecraft:light_gray_wool
fill 48 279 312 69 279 316 minecraft:white_wool
fill 58 279 275 60 291 275 minecraft:light_blue_concrete
setblock 61 279 275 minecraft:light_blue_wool
fill 63 279 294 63 279 297 minecraft:white_wool
fill 63 279 298 63 279 300 minecraft:red_wool
fill 63 279 301 63 279 304 minecraft:white_wool
fill 64 279 275 67 283 275 minecraft:light_blue_concrete
fill 64 279 294 65 279 295 minecraft:white_wool
fill 64 279 296 64 279 298 minecraft:red_wool
fill 64 279 300 64 279 302 minecraft:red_wool
fill 64 279 303 65 279 304 minecraft:white_wool
fill 65 279 296 66 279 296 minecraft:red_wool
fill 65 279 302 66 279 302 minecraft:red_wool
fill 66 279 294 88 279 294 minecraft:white_wool
fill 66 279 295 68 279 295 minecraft:red_wool
fill 66 279 303 68 279 303 minecraft:red_wool
fill 66 279 304 67 279 304 minecraft:white_wool
setblock 68 279 275 minecraft:light_blue_wool
fill 68 279 296 70 279 296 minecraft:red_wool
fill 68 279 302 70 279 302 minecraft:red_wool
fill 68 279 304 69 279 310 minecraft:black_wool
fill 69 279 275 71 282 275 minecraft:light_blue_concrete
fill 69 279 295 88 279 295 minecraft:white_wool
fill 69 279 303 73 279 303 minecraft:black_wool
fill 70 279 297 70 279 298 minecraft:red_wool
fill 70 279 300 70 279 301 minecraft:red_wool
fill 70 279 304 73 279 304 minecraft:black_wool
fill 70 279 305 73 279 305 minecraft:light_gray_wool
fill 70 279 306 73 279 308 minecraft:white_wool
fill 70 279 309 79 279 312 minecraft:black_wool
fill 70 279 313 88 279 316 minecraft:white_wool
fill 71 279 296 88 279 297 minecraft:white_wool
fill 71 279 298 71 279 300 minecraft:red_wool
fill 71 279 301 79 279 302 minecraft:black_wool
fill 72 279 298 88 279 298 minecraft:white_wool
fill 72 279 299 73 279 299 minecraft:light_gray_wool
fill 72 279 300 73 279 300 minecraft:white_wool
fill 74 279 299 75 279 300 minecraft:black_wool
fill 74 279 303 75 279 304 minecraft:white_wool
fill 74 279 305 75 279 308 minecraft:black_wool
fill 76 279 299 77 279 299 minecraft:light_gray_wool
fill 76 279 300 77 279 300 minecraft:white_wool
fill 76 279 303 81 279 304 minecraft:black_wool
fill 76 279 305 79 279 305 minecraft:light_gray_wool
fill 76 279 306 79 279 308 minecraft:white_wool
fill 78 279 299 79 279 300 minecraft:black_wool
fill 80 279 299 88 279 299 minecraft:light_gray_wool
fill 80 279 300 88 279 302 minecraft:white_wool
fill 80 279 305 81 279 310 minecraft:black_wool
fill 80 279 311 88 279 311 minecraft:light_gray_wool
fill 80 279 312 88 279 312 minecraft:white_wool
fill 82 279 303 88 279 304 minecraft:white_wool
fill 82 279 305 88 279 305 minecraft:light_gray_wool
fill 82 279 306 88 279 310 minecraft:white_wool
setblock 89 279 277 minecraft:white_wool
fill 89 279 291 89 308 291 minecraft:light_blue_concrete
fill 89 279 298 89 298 301 minecraft:light_blue_concrete
setblock 89 279 302 minecraft:light_blue_wool
fill 89 279 303 89 308 304 minecraft:light_blue_concrete
fill 47 280 277 47 308 277 minecraft:light_blue_concrete
fill 47 280 289 47 308 289 minecraft:light_blue_concrete
fill 51 280 280 53 286 280 minecraft:spruce_log
fill 52 280 279 52 303 279 minecraft:spruce_log
fill 52 280 281 52 303 281 minecraft:spruce_log
fill 61 280 275 61 300 275 minecraft:light_blue_concrete
fill 68 280 275 68 308 275 minecraft:light_blue_concrete
fill 83 280 312 85 286 312 minecraft:spruce_log
fill 84 280 311 84 303 311 minecraft:spruce_log
fill 84 280 313 84 303 313 minecraft:spruce_log
fill 89 280 277 89 308 277 minecraft:light_blue_concrete
fill 89 280 302 89 308 302 minecraft:light_blue_concrete
setblock 50 281 278 minecraft:light[level=15]
setblock 50 281 286 minecraft:light[level=15]
setblock 50 281 294 minecraft:light[level=15]
setblock 50 281 302 minecraft:light[level=15]
setblock 50 281 310 minecraft:light[level=15]
setblock 58 281 278 minecraft:light[level=15]
setblock 58 281 286 minecraft:light[level=15]
setblock 58 281 294 minecraft:light[level=15]
setblock 58 281 302 minecraft:light[level=15]
setblock 58 281 310 minecraft:light[level=15]
setblock 66 281 278 minecraft:light[level=15]
setblock 66 281 286 minecraft:light[level=15]
setblock 66 281 294 minecraft:light[level=15]
setblock 66 281 302 minecraft:light[level=15]
setblock 66 281 310 minecraft:light[level=15]
setblock 74 281 278 minecraft:light[level=15]
setblock 74 281 286 minecraft:light[level=15]
setblock 74 281 294 minecraft:light[level=15]
setblock 74 281 302 minecraft:light[level=15]
setblock 74 281 310 minecraft:light[level=15]
setblock 82 281 278 minecraft:light[level=15]
setblock 82 281 286 minecraft:light[level=15]
setblock 82 281 294 minecraft:light[level=15]
setblock 82 281 302 minecraft:light[level=15]
setblock 82 281 310 minecraft:light[level=15]
setblock 84 282 317 minecraft:light_blue_wool
fill 85 282 317 85 308 317 minecraft:light_blue_concrete
setblock 89 282 294 minecraft:white_wool
setblock 48 283 277 minecraft:spruce_planks
fill 48 283 281 48 300 281 minecraft:spruce_planks
setblock 48 283 284 minecraft:spruce_planks
fill 48 283 288 48 300 288 minecraft:spruce_planks
setblock 48 283 291 minecraft:spruce_planks
fill 48 283 295 48 300 295 minecraft:spruce_planks
setblock 48 283 298 minecraft:spruce_planks
fill 48 283 302 48 300 302 minecraft:spruce_planks
setblock 48 283 305 minecraft:spruce_planks
fill 48 283 309 48 300 309 minecraft:spruce_planks
setblock 48 283 312 minecraft:spruce_planks
fill 48 283 316 48 300 316 minecraft:spruce_planks
fill 50 283 276 50 300 276 minecraft:spruce_planks
setblock 51 283 316 minecraft:spruce_planks
setblock 54 283 276 minecraft:spruce_planks
fill 55 283 314 55 283 315 minecraft:dark_oak_planks
fill 55 283 316 55 300 316 minecraft:spruce_planks
fill 57 283 276 57 300 276 minecraft:spruce_planks
fill 58 283 312 77 285 316 minecraft:spruce_planks
fill 60 283 310 60 291 310 minecraft:green_terracotta
setblock 61 283 276 minecraft:spruce_planks
setblock 62 283 317 minecraft:white_wool
fill 64 283 276 64 300 276 minecraft:spruce_planks
setblock 68 283 276 minecraft:spruce_planks
fill 69 283 275 70 298 275 minecraft:light_blue_concrete
fill 70 283 276 70 283 277 minecraft:dark_oak_planks
setblock 71 283 275 minecraft:light_blue_wool
fill 71 283 276 78 285 276 minecraft:spruce_planks
fill 71 283 307 77 285 311 minecraft:spruce_planks
fill 72 283 277 78 285 281 minecraft:spruce_planks
setblock 79 283 316 minecraft:spruce_planks
setblock 82 283 276 minecraft:spruce_planks
fill 83 283 316 83 300 316 minecraft:spruce_planks
fill 84 283 302 84 286 302 minecraft:iron_bars
fill 84 283 317 84 289 317 minecraft:light_blue_concrete
fill 85 283 276 85 300 276 minecraft:spruce_planks
fill 86 283 281 86 284 285 minecraft:white_wool
fill 86 283 288 87 283 288 minecraft:dark_oak_planks
fill 86 283 303 87 283 303 minecraft:dark_oak_planks
fill 86 283 308 87 283 308 minecraft:dark_oak_planks
setblock 86 283 316 minecraft:spruce_planks
setblock 88 283 277 minecraft:spruce_planks
fill 88 283 280 88 300 280 minecraft:spruce_planks
setblock 88 283 284 minecraft:spruce_planks
fill 88 283 287 88 300 287 minecraft:spruce_planks
setblock 88 283 291 minecraft:spruce_planks
fill 88 283 294 88 300 294 minecraft:spruce_planks
setblock 88 283 298 minecraft:spruce_planks
fill 88 283 301 88 300 301 minecraft:spruce_planks
setblock 88 283 305 minecraft:spruce_planks
fill 88 283 308 88 300 308 minecraft:spruce_planks
setblock 88 283 312 minecraft:spruce_planks
fill 88 283 315 88 300 315 minecraft:spruce_planks
fill 89 283 294 89 308 294 minecraft:light_blue_concrete
setblock 89 283 310 minecraft:white_wool
setblock 47 284 295 minecraft:white_wool
fill 48 284 278 48 285 278 minecraft:spruce_planks
fill 48 284 285 48 285 285 minecraft:spruce_planks
fill 48 284 292 48 285 292 minecraft:spruce_planks
fill 48 284 299 48 285 299 minecraft:spruce_planks
fill 48 284 306 48 285 306 minecraft:spruce_planks
fill 48 284 313 48 285 313 minecraft:spruce_planks
setblock 51 284 283 minecraft:shroomlight
setblock 51 284 289 minecraft:shroomlight
setblock 51 284 295 minecraft:shroomlight
setblock 51 284 301 minecraft:shroomlight
setblock 51 284 307 minecraft:shroomlight
setblock 51 284 313 minecraft:shroomlight
fill 52 284 316 52 285 316 minecraft:spruce_planks
fill 53 284 276 53 285 276 minecraft:spruce_planks
setblock 55 284 279 minecraft:shroomlight
setblock 55 284 315 minecraft:dark_oak_planks
setblock 57 284 313 minecraft:shroomlight
fill 60 284 276 60 285 276 minecraft:spruce_planks
setblock 61 284 279 minecraft:shroomlight
fill 62 284 317 62 308 317 minecraft:light_blue_concrete
fill 64 284 275 64 308 275 minecraft:light_blue_concrete
setblock 65 284 275 minecraft:white_wool
fill 66 284 275 67 307 275 minecraft:light_blue_concrete
fill 67 284 276 67 285 276 minecraft:spruce_planks
setblock 67 284 279 minecraft:shroomlight
setblock 70 284 276 minecraft:dark_oak_planks
fill 71 284 275 71 308 275 minecraft:light_blue_concrete
setblock 79 284 279 minecraft:shroomlight
fill 80 284 316 80 285 316 minecraft:spruce_planks
fill 81 284 276 81 285 276 minecraft:spruce_planks
setblock 81 284 313 minecraft:shroomlight
setblock 85 284 279 minecraft:shroomlight
setblock 85 284 285 minecraft:shroomlight
setblock 85 284 291 minecraft:shroomlight
setblock 85 284 297 minecraft:shroomlight
setblock 85 284 303 minecraft:shroomlight
setblock 85 284 309 minecraft:shroomlight
setblock 87 284 288 minecraft:dark_oak_planks
setblock 87 284 303 minecraft:dark_oak_planks
setblock 87 284 308 minecraft:dark_oak_planks
fill 87 284 316 87 285 316 minecraft:spruce_planks
fill 88 284 276 88 285 276 minecraft:spruce_planks
fill 88 284 283 88 285 283 minecraft:spruce_planks
fill 88 284 290 88 285 290 minecraft:spruce_planks
fill 88 284 297 88 285 297 minecraft:spruce_planks
fill 88 284 304 88 285 304 minecraft:spruce_planks
fill 88 284 311 88 285 311 minecraft:spruce_planks
fill 89 284 310 89 308 310 minecraft:light_blue_concrete
fill 47 285 295 47 308 295 minecraft:light_blue_concrete
fill 48 285 276 49 285 277 minecraft:spruce_planks
fill 48 285 279 50 285 280 minecraft:spruce_planks
fill 48 285 282 51 285 284 minecraft:spruce_planks
fill 48 285 286 51 285 287 minecraft:spruce_planks
fill 48 285 289 51 285 291 minecraft:spruce_planks
fill 48 285 293 51 285 294 minecraft:spruce_planks
fill 48 285 296 51 285 298 minecraft:spruce_planks
fill 48 285 300 51 285 301 minecraft:spruce_planks
fill 48 285 303 51 285 305 minecraft:spruce_planks
fill 48 285 307 51 285 308 minecraft:spruce_planks
fill 48 285 310 51 285 312 minecraft:spruce_planks
fill 48 285 314 57 285 315 minecraft:spruce_planks
fill 49 285 278 71 285 278 minecraft:spruce_planks
fill 49 285 281 51 285 281 minecraft:spruce_planks
fill 49 285 285 51 285 285 minecraft:spruce_planks
fill 49 285 288 51 285 288 minecraft:spruce_planks
fill 49 285 292 51 285 292 minecraft:spruce_planks
fill 49 285 295 51 285 295 minecraft:spruce_planks
fill 49 285 299 51 285 299 minecraft:spruce_planks
fill 49 285 302 51 285 302 minecraft:spruce_planks
fill 49 285 306 51 285 306 minecraft:spruce_planks
fill 49 285 309 51 285 309 minecraft:spruce_planks
fill 49 285 313 57 285 313 minecraft:spruce_planks
fill 49 285 316 51 285 316 minecraft:spruce_planks
fill 50 285 277 71 285 277 minecraft:spruce_planks
fill 51 285 276 52 285 276 minecraft:spruce_planks
setblock 51 285 279 minecraft:spruce_planks
fill 53 285 279 71 285 279 minecraft:spruce_planks
fill 53 285 316 54 285 316 minecraft:spruce_planks
fill 54 285 276 56 285 276 minecraft:spruce_planks
fill 56 285 316 57 285 316 minecraft:spruce_planks
setblock 57 285 285 minecraft:light[level=12]
setblock 57 285 292 minecraft:light[level=12]
setblock 57 285 299 minecraft:light[level=12]
setblock 57 285 306 minecraft:light[level=12]
fill 58 285 276 59 285 276 minecraft:spruce_planks
fill 61 285 276 63 285 276 minecraft:spruce_planks
setblock 64 285 285 minecraft:light[level=12]
setblock 64 285 292 minecraft:light[level=12]
setblock 64 285 299 minecraft:light[level=12]
setblock 64 285 306 minecraft:light[level=12]
fill 65 285 275 65 308 275 minecraft:light_blue_concrete
fill 65 285 276 66 285 276 minecraft:spruce_planks
fill 68 285 276 70 285 276 minecraft:spruce_planks
setblock 71 285 285 minecraft:light[level=12]
setblock 71 285 292 minecraft:light[level=12]
setblock 71 285 299 minecraft:light[level=12]
setblock 71 285 306 minecraft:light[level=12]
setblock 78 285 285 minecraft:light[level=12]
setblock 78 285 292 minecraft:light[level=12]
setblock 78 285 299 minecraft:light[level=12]
setblock 78 285 306 minecraft:light[level=12]
fill 78 285 313 79 285 316 minecraft:spruce_planks
fill 79 285 276 80 285 279 minecraft:spruce_planks
fill 80 285 313 83 285 315 minecraft:spruce_planks
fill 81 285 277 88 285 279 minecraft:spruce_planks
fill 81 285 316 82 285 316 minecraft:spruce_planks
fill 82 285 276 84 285 276 minecraft:spruce_planks
fill 84 285 314 86 285 316 minecraft:spruce_planks
fill 85 285 280 87 285 311 minecraft:spruce_planks
fill 85 285 313 88 285 313 minecraft:spruce_planks
fill 86 285 276 87 285 276 minecraft:spruce_planks
fill 86 285 312 88 285 312 minecraft:spruce_planks
fill 87 285 314 87 285 315 minecraft:spruce_planks
fill 88 285 281 88 285 282 minecraft:spruce_planks
fill 88 285 284 88 285 286 minecraft:spruce_planks
fill 88 285 288 88 285 289 minecraft:spruce_planks
fill 88 285 291 88 285 293 minecraft:spruce_planks
fill 88 285 295 88 285 296 minecraft:spruce_planks
fill 88 285 298 88 285 300 minecraft:spruce_planks
fill 88 285 302 88 285 303 minecraft:spruce_planks
fill 88 285 305 88 285 307 minecraft:spruce_planks
fill 88 285 309 88 285 310 minecraft:spruce_planks
setblock 88 285 314 minecraft:spruce_planks
setblock 88 285 316 minecraft:spruce_planks
setblock 89 285 289 minecraft:white_wool
setblock 48 286 280 minecraft:spruce_planks
setblock 48 286 287 minecraft:spruce_planks
setblock 48 286 294 minecraft:spruce_planks
setblock 48 286 301 minecraft:spruce_planks
setblock 48 286 308 minecraft:spruce_planks
setblock 48 286 315 minecraft:spruce_planks
setblock 51 286 276 minecraft:spruce_planks
setblock 51 286 279 minecraft:dark_oak_planks
fill 51 286 281 51 286 313 minecraft:dark_oak_planks
fill 52 286 313 57 286 313 minecraft:dark_oak_planks
fill 53 286 279 71 286 279 minecraft:dark_oak_planks
setblock 54 286 316 minecraft:spruce_planks
setblock 58 286 276 minecraft:spruce_planks
setblock 58 286 312 minecraft:shroomlight
fill 58 286 313 58 293 313 minecraft:spruce_planks
setblock 58 286 314 minecraft:shroomlight
fill 58 286 315 58 293 315 minecraft:spruce_planks
setblock 58 286 316 minecraft:shroomlight
fill 59 286 312 59 293 312 minecraft:spruce_planks
setblock 59 286 313 minecraft:shroomlight
fill 59 286 314 59 293 314 minecraft:spruce_planks
setblock 59 286 315 minecraft:shroomlight
fill 59 286 316 59 293 316 minecraft:spruce_planks
setblock 60 286 312 minecraft:shroomlight
fill 60 286 313 60 293 313 minecraft:spruce_planks
setblock 60 286 314 minecraft:shroomlight
fill 60 286 315 60 293 315 minecraft:spruce_planks
setblock 60 286 316 minecraft:shroomlight
fill 61 286 312 61 293 312 minecraft:spruce_planks
setblock 61 286 313 minecraft:shroomlight
fill 61 286 314 61 293 314 minecraft:spruce_planks
setblock 61 286 315 minecraft:shroomlight
fill 61 286 316 61 293 316 minecraft:spruce_planks
setblock 62 286 312 minecraft:shroomlight
fill 62 286 313 62 293 313 minecraft:spruce_planks
setblock 62 286 314 minecraft:shroomlight
fill 62 286 315 62 293 315 minecraft:spruce_planks
setblock 62 286 316 minecraft:shroomlight
fill 63 286 312 63 293 312 minecraft:spruce_planks
setblock 63 286 313 minecraft:shroomlight
fill 63 286 314 63 293 314 minecraft:spruce_planks
setblock 63 286 315 minecraft:shroomlight
fill 63 286 316 63 293 316 minecraft:spruce_planks
setblock 64 286 312 minecraft:shroomlight
fill 64 286 313 64 293 313 minecraft:spruce_planks
setblock 64 286 314 minecraft:shroomlight
fill 64 286 315 64 293 315 minecraft:spruce_planks
setblock 64 286 316 minecraft:shroomlight
setblock 65 286 276 minecraft:spruce_planks
fill 65 286 312 65 293 312 minecraft:spruce_planks
setblock 65 286 313 minecraft:shroomlight
fill 65 286 314 65 293 314 minecraft:spruce_planks
setblock 65 286 315 minecraft:shroomlight
fill 65 286 316 65 293 316 minecraft:spruce_planks
setblock 66 286 312 minecraft:shroomlight
fill 66 286 313 66 293 313 minecraft:spruce_planks
setblock 66 286 314 minecraft:shroomlight
fill 66 286 315 66 293 315 minecraft:spruce_planks
setblock 66 286 316 minecraft:shroomlight
fill 67 286 312 67 293 312 minecraft:spruce_planks
setblock 67 286 313 minecraft:shroomlight
fill 67 286 314 67 293 314 minecraft:spruce_planks
setblock 67 286 315 minecraft:shroomlight
fill 67 286 316 67 293 316 minecraft:spruce_planks
setblock 68 286 312 minecraft:shroomlight
fill 68 286 313 68 293 313 minecraft:spruce_planks
setblock 68 286 314 minecraft:shroomlight
fill 68 286 315 68 293 315 minecraft:spruce_planks
setblock 68 286 316 minecraft:shroomlight
setblock 68 286 317 minecraft:white_wool
fill 69 286 312 69 293 312 minecraft:spruce_planks
setblock 69 286 313 minecraft:shroomlight
fill 69 286 314 69 293 314 minecraft:spruce_planks
setblock 69 286 315 minecraft:shroomlight
fill 69 286 316 69 300 316 minecraft:spruce_planks
setblock 70 286 312 minecraft:shroomlight
fill 70 286 313 70 293 313 minecraft:spruce_planks
setblock 70 286 314 minecraft:shroomlight
fill 70 286 315 70 293 315 minecraft:spruce_planks
setblock 70 286 316 minecraft:shroomlight
fill 71 286 276 71 300 276 minecraft:spruce_planks
setblock 71 286 307 minecraft:shroomlight
fill 71 286 308 71 300 308 minecraft:spruce_planks
setblock 71 286 309 minecraft:shroomlight
fill 71 286 310 71 300 310 minecraft:spruce_planks
setblock 71 286 311 minecraft:shroomlight
fill 71 286 312 71 300 312 minecraft:spruce_planks
setblock 71 286 313 minecraft:shroomlight
fill 71 286 314 71 300 314 minecraft:spruce_planks
setblock 71 286 315 minecraft:shroomlight
fill 71 286 316 71 300 316 minecraft:spruce_planks
setblock 72 286 276 minecraft:shroomlight
fill 72 286 277 72 300 277 minecraft:spruce_planks
setblock 72 286 278 minecraft:shroomlight
fill 72 286 279 72 300 279 minecraft:spruce_planks
setblock 72 286 280 minecraft:shroomlight
fill 72 286 281 72 300 281 minecraft:spruce_planks
fill 72 286 307 72 300 307 minecraft:spruce_planks
setblock 72 286 308 minecraft:shroomlight
fill 72 286 309 72 300 309 minecraft:spruce_planks
setblock 72 286 310 minecraft:shroomlight
fill 72 286 311 72 300 311 minecraft:spruce_planks
setblock 72 286 312 minecraft:shroomlight
fill 72 286 313 72 300 313 minecraft:spruce_planks
setblock 72 286 314 minecraft:shroomlight
fill 72 286 315 72 300 315 minecraft:spruce_planks
setblock 72 286 316 minecraft:shroomlight
fill 73 286 276 73 300 276 minecraft:spruce_planks
setblock 73 286 277 minecraft:shroomlight
fill 73 286 278 73 300 278 minecraft:spruce_planks
setblock 73 286 279 minecraft:shroomlight
fill 73 286 280 73 300 280 minecraft:spruce_planks
setblock 73 286 281 minecraft:shroomlight
setblock 73 286 307 minecraft:shroomlight
fill 73 286 308 73 300 308 minecraft:spruce_planks
setblock 73 286 309 minecraft:shroomlight
fill 73 286 310 73 300 310 minecraft:spruce_planks
setblock 73 286 311 minecraft:shroomlight
fill 73 286 312 73 300 312 minecraft:spruce_planks
setblock 73 286 313 minecraft:shroomlight
fill 73 286 314 73 300 314 minecraft:spruce_planks
setblock 73 286 315 minecraft:shroomlight
fill 73 286 316 73 300 316 minecraft:spruce_planks
setblock 74 286 276 minecraft:shroomlight
fill 74 286 277 74 300 277 minecraft:spruce_planks
setblock 74 286 278 minecraft:shroomlight
fill 74 286 279 74 300 279 minecraft:spruce_planks
setblock 74 286 280 minecraft:shroomlight
fill 74 286 281 74 300 281 minecraft:spruce_planks
fill 74 286 307 74 300 307 minecraft:spruce_planks
setblock 74 286 308 minecraft:shroomlight
fill 74 286 309 74 300 309 minecraft:spruce_planks
setblock 74 286 310 minecraft:shroomlight
fill 74 286 311 74 300 311 minecraft:spruce_planks
setblock 74 286 312 minecraft:shroomlight
fill 74 286 313 74 300 313 minecraft:spruce_planks
setblock 74 286 314 minecraft:shroomlight
fill 74 286 315 74 300 315 minecraft:spruce_planks
setblock 74 286 316 minecraft:shroomlight
fill 75 286 276 75 300 276 minecraft:spruce_planks
setblock 75 286 277 minecraft:shroomlight
fill 75 286 278 75 300 278 minecraft:spruce_planks
setblock 75 286 279 minecraft:shroomlight
fill 75 286 280 75 300 280 minecraft:spruce_planks
setblock 75 286 281 minecraft:shroomlight
setblock 75 286 307 minecraft:shroomlight
fill 75 286 308 75 300 308 minecraft:spruce_planks
setblock 75 286 309 minecraft:shroomlight
fill 75 286 310 75 300 310 minecraft:spruce_planks
setblock 75 286 311 minecraft:shroomlight
fill 75 286 312 75 300 312 minecraft:spruce_planks
setblock 75 286 313 minecraft:shroomlight
fill 75 286 314 75 300 314 minecraft:spruce_planks
setblock 75 286 315 minecraft:shroomlight
fill 75 286 316 75 300 316 minecraft:spruce_planks
setblock 76 286 276 minecraft:shroomlight
fill 76 286 277 76 300 277 minecraft:spruce_planks
setblock 76 286 278 minecraft:shroomlight
fill 76 286 279 76 300 279 minecraft:spruce_planks
setblock 76 286 280 minecraft:shroomlight
fill 76 286 281 76 300 281 minecraft:spruce_planks
fill 76 286 307 76 300 307 minecraft:spruce_planks
setblock 76 286 308 minecraft:shroomlight
fill 76 286 309 76 300 309 minecraft:spruce_planks
setblock 76 286 310 minecraft:shroomlight
fill 76 286 311 76 300 311 minecraft:spruce_planks
setblock 76 286 312 minecraft:shroomlight
fill 76 286 313 76 300 313 minecraft:spruce_planks
setblock 76 286 314 minecraft:shroomlight
fill 76 286 315 76 300 315 minecraft:spruce_planks
setblock 76 286 316 minecraft:shroomlight
fill 77 286 276 77 300 276 minecraft:spruce_planks
setblock 77 286 277 minecraft:shroomlight
fill 77 286 278 77 300 278 minecraft:spruce_planks
setblock 77 286 279 minecraft:shroomlight
fill 77 286 280 77 300 280 minecraft:spruce_planks
setblock 77 286 281 minecraft:shroomlight
setblock 77 286 307 minecraft:shroomlight
fill 77 286 308 77 300 308 minecraft:spruce_planks
setblock 77 286 309 minecraft:shroomlight
fill 77 286 310 77 300 310 minecraft:spruce_planks
setblock 77 286 311 minecraft:shroomlight
fill 77 286 312 77 300 312 minecraft:spruce_planks
setblock 77 286 313 minecraft:shroomlight
fill 77 286 314 77 300 314 minecraft:spruce_planks
setblock 77 286 315 minecraft:shroomlight
fill 77 286 316 77 300 316 minecraft:spruce_planks
setblock 78 286 276 minecraft:shroomlight
fill 78 286 277 78 300 277 minecraft:spruce_planks
setblock 78 286 278 minecraft:shroomlight
fill 78 286 279 78 300 279 minecraft:spruce_planks
setblock 78 286 280 minecraft:shroomlight
fill 78 286 281 78 300 281 minecraft:spruce_planks
fill 78 286 313 83 286 313 minecraft:dark_oak_planks
setblock 79 286 276 minecraft:spruce_planks
fill 79 286 279 85 286 279 minecraft:dark_oak_planks
setblock 82 286 316 minecraft:spruce_planks
fill 85 286 280 85 286 311 minecraft:dark_oak_planks
setblock 85 286 313 minecraft:dark_oak_planks
setblock 86 286 276 minecraft:spruce_planks
fill 86 286 281 86 289 285 minecraft:white_wool
setblock 88 286 281 minecraft:spruce_planks
setblock 88 286 288 minecraft:spruce_planks
setblock 88 286 295 minecraft:spruce_planks
setblock 88 286 302 minecraft:spruce_planks
setblock 88 286 309 minecraft:spruce_planks
fill 89 286 289 89 308 289 minecraft:light_blue_concrete
fill 48 287 280 56 293 280 minecraft:white_wool
setblock 52 287 275 minecraft:white_wool
fill 53 287 275 54 308 275 minecraft:light_blue_concrete
fill 58 287 312 58 288 312 minecraft:spruce_planks
fill 58 287 314 58 288 314 minecraft:spruce_planks
fill 58 287 316 58 288 316 minecraft:spruce_planks
fill 59 287 313 59 288 313 minecraft:spruce_planks
fill 59 287 315 59 288 315 minecraft:spruce_planks
fill 60 287 312 60 288 312 minecraft:spruce_planks
fill 60 287 314 60 288 314 minecraft:spruce_planks
fill 60 287 316 60 288 316 minecraft:spruce_planks
fill 61 287 313 61 288 313 minecraft:spruce_planks
fill 61 287 315 61 288 315 minecraft:spruce_planks
fill 62 287 312 62 288 312 minecraft:spruce_planks
fill 62 287 314 62 288 314 minecraft:spruce_planks
fill 62 287 316 62 288 316 minecraft:spruce_planks
fill 63 287 313 63 288 313 minecraft:spruce_planks
fill 63 287 315 63 288 315 minecraft:spruce_planks
fill 64 287 312 64 288 312 minecraft:spruce_planks
fill 64 287 314 64 288 314 minecraft:spruce_planks
fill 64 287 316 64 288 316 minecraft:spruce_planks
fill 65 287 313 65 288 313 minecraft:spruce_planks
fill 65 287 315 65 288 315 minecraft:spruce_planks
fill 66 287 312 66 288 312 minecraft:spruce_planks
fill 66 287 314 66 288 314 minecraft:spruce_planks
fill 66 287 316 66 288 316 minecraft:spruce_planks
fill 67 287 313 67 288 313 minecraft:spruce_planks
fill 67 287 315 67 288 315 minecraft:spruce_planks
fill 68 287 312 68 288 312 minecraft:spruce_planks
fill 68 287 314 68 288 314 minecraft:spruce_planks
fill 68 287 316 68 288 316 minecraft:spruce_planks
fill 68 287 317 68 297 317 minecraft:light_blue_concrete
fill 69 287 313 69 288 313 minecraft:spruce_planks
fill 69 287 315 69 288 315 minecraft:spruce_planks
fill 70 287 312 70 288 312 minecraft:spruce_planks
fill 70 287 314 70 288 314 minecraft:spruce_planks
fill 70 287 316 70 288 316 minecraft:spruce_planks
fill 71 287 307 71 288 307 minecraft:spruce_planks
fill 71 287 309 71 288 309 minecraft:spruce_planks
fill 71 287 311 71 288 311 minecraft:spruce_planks
fill 71 287 313 71 288 313 minecraft:spruce_planks
fill 71 287 315 71 288 315 minecraft:spruce_planks
fill 72 287 276 72 288 276 minecraft:spruce_planks
fill 72 287 278 72 288 278 minecraft:spruce_planks
fill 72 287 280 72 288 280 minecraft:spruce_planks
fill 72 287 308 72 288 308 minecraft:spruce_planks
fill 72 287 310 72 288 310 minecraft:spruce_planks
fill 72 287 312 72 288 312 minecraft:spruce_planks
fill 72 287 314 72 288 314 minecraft:spruce_planks
fill 72 287 316 72 288 316 minecraft:spruce_planks
fill 73 287 277 73 288 277 minecraft:spruce_planks
fill 73 287 279 73 288 279 minecraft:spruce_planks
fill 73 287 281 73 288 281 minecraft:spruce_planks
fill 73 287 307 73 288 307 minecraft:spruce_planks
fill 73 287 309 73 288 309 minecraft:spruce_planks
fill 73 287 311 73 288 311 minecraft:spruce_planks
fill 73 287 313 73 288 313 minecraft:spruce_planks
fill 73 287 315 73 288 315 minecraft:spruce_planks
setblock 73 287 317 minecraft:white_wool
fill 74 287 276 74 288 276 minecraft:spruce_planks
fill 74 287 278 74 288 278 minecraft:spruce_planks
fill 74 287 280 74 288 280 minecraft:spruce_planks
fill 74 287 308 74 288 308 minecraft:spruce_planks
fill 74 287 310 74 288 310 minecraft:spruce_planks
fill 74 287 312 74 288 312 minecraft:spruce_planks
fill 74 287 314 74 288 314 minecraft:spruce_planks
fill 74 287 316 74 288 316 minecraft:spruce_planks
fill 75 287 277 75 288 277 minecraft:spruce_planks
fill 75 287 279 75 288 279 minecraft:spruce_planks
fill 75 287 281 75 288 281 minecraft:spruce_planks
fill 75 287 307 75 288 307 minecraft:spruce_planks
fill 75 287 309 75 288 309 minecraft:spruce_planks
fill 75 287 311 75 288 311 minecraft:spruce_planks
fill 75 287 313 75 288 313 minecraft:spruce_planks
fill 75 287 315 75 288 315 minecraft:spruce_planks
fill 76 287 276 76 288 276 minecraft:spruce_planks
fill 76 287 278 76 288 278 minecraft:spruce_planks
fill 76 287 280 76 288 280 minecraft:spruce_planks
fill 76 287 308 76 288 308 minecraft:spruce_planks
fill 76 287 310 76 288 310 minecraft:spruce_planks
fill 76 287 312 76 288 312 minecraft:spruce_planks
fill 76 287 314 76 288 314 minecraft:spruce_planks
fill 76 287 316 76 288 316 minecraft:spruce_planks
fill 77 287 277 77 288 277 minecraft:spruce_planks
fill 77 287 279 77 288 279 minecraft:spruce_planks
fill 77 287 281 77 288 281 minecraft:spruce_planks
fill 77 287 307 77 288 307 minecraft:spruce_planks
fill 77 287 309 77 288 309 minecraft:spruce_planks
fill 77 287 311 77 288 311 minecraft:spruce_planks
fill 77 287 313 77 288 313 minecraft:spruce_planks
fill 77 287 315 77 288 315 minecraft:spruce_planks
fill 78 287 276 78 288 276 minecraft:spruce_planks
fill 78 287 278 78 288 278 minecraft:spruce_planks
fill 78 287 280 78 288 280 minecraft:spruce_planks
fill 80 287 312 88 293 312 minecraft:white_wool
setblock 48 288 282 minecraft:spruce_planks
setblock 48 288 289 minecraft:spruce_planks
setblock 48 288 296 minecraft:spruce_planks
setblock 48 288 303 minecraft:spruce_planks
setblock 48 288 310 minecraft:spruce_planks
setblock 49 288 276 minecraft:spruce_planks
setblock 49 288 316 minecraft:spruce_planks
fill 52 288 275 52 308 275 minecraft:light_blue_concrete
setblock 56 288 276 minecraft:spruce_planks
setblock 56 288 316 minecraft:spruce_planks
setblock 63 288 276 minecraft:spruce_planks
setblock 70 288 276 minecraft:spruce_planks
fill 73 288 317 73 308 317 minecraft:light_blue_concrete
setblock 83 288 317 minecraft:white_wool
setblock 84 288 276 minecraft:spruce_planks
setblock 84 288 316 minecraft:spruce_planks
setblock 88 288 275 minecraft:light_blue_wool
setblock 88 288 279 minecraft:spruce_planks
setblock 88 288 286 minecraft:spruce_planks
setblock 88 288 293 minecraft:spruce_planks
setblock 88 288 300 minecraft:spruce_planks
setblock 88 288 307 minecraft:spruce_planks
setblock 88 288 314 minecraft:spruce_planks
fill 89 288 275 89 308 275 minecraft:light_blue_concrete
fill 48 289 276 48 290 276 minecraft:spruce_planks
fill 48 289 283 48 290 283 minecraft:spruce_planks
fill 48 289 290 48 290 290 minecraft:spruce_planks
fill 48 289 297 48 290 297 minecraft:spruce_planks
fill 48 289 304 48 290 304 minecraft:spruce_planks
fill 48 289 311 48 290 311 minecraft:spruce_planks
setblock 50 289 278 minecraft:light[level=15]
setblock 50 289 286 minecraft:light[level=15]
setblock 50 289 294 minecraft:light[level=15]
setblock 50 289 302 minecraft:light[level=15]
setblock 50 289 310 minecraft:light[level=15]
fill 50 289 316 50 290 316 minecraft:spruce_planks
fill 55 289 276 55 290 276 minecraft:spruce_planks
fill 57 289 316 57 290 316 minecraft:spruce_planks
setblock 58 289 278 minecraft:light[level=15]
setblock 58 289 286 minecraft:light[level=15]
setblock 58 289 294 minecraft:light[level=15]
setblock 58 289 302 minecraft:light[level=15]
setblock 58 289 310 minecraft:light[level=15]
setblock 58 289 312 minecraft:shroomlight
setblock 58 289 314 minecraft:shroomlight
setblock 58 289 316 minecraft:shroomlight
setblock 59 289 313 minecraft:shroomlight
setblock 59 289 315 minecraft:shroomlight
setblock 60 289 312 minecraft:shroomlight
setblock 60 289 314 minecraft:shroomlight
setblock 60 289 316 minecraft:shroomlight
setblock 61 289 313 minecraft:shroomlight
setblock 61 289 315 minecraft:shroomlight
fill 62 289 276 62 290 276 minecraft:spruce_planks
setblock 62 289 312 minecraft:shroomlight
setblock 62 289 314 minecraft:shroomlight
setblock 62 289 316 minecraft:shroomlight
setblock 63 289 313 minecraft:shroomlight
setblock 63 289 315 minecraft:shroomlight
setblock 64 289 312 minecraft:shroomlight
setblock 64 289 314 minecraft:shroomlight
setblock 64 289 316 minecraft:shroomlight
setblock 65 289 313 minecraft:shroomlight
setblock 65 289 315 minecraft:shroomlight
setblock 66 289 278 minecraft:light[level=15]
setblock 66 289 286 minecraft:light[level=15]
setblock 66 289 294 minecraft:light[level=15]
setblock 66 289 302 minecraft:light[level=15]
setblock 66 289 310 minecraft:light[level=15]
setblock 66 289 312 minecraft:shroomlight
setblock 66 289 314 minecraft:shroomlight
setblock 66 289 316 minecraft:shroomlight
setblock 67 289 313 minecraft:shroomlight
setblock 67 289 315 minecraft:shroomlight
setblock 68 289 312 minecraft:shroomlight
setblock 68 289 314 minecraft:shroomlight
setblock 68 289 316 minecraft:shroomlight
fill 69 289 276 69 290 276 minecraft:spruce_planks
setblock 69 289 313 minecraft:shroomlight
setblock 69 289 315 minecraft:shroomlight
setblock 70 289 312 minecraft:shroomlight
setblock 70 289 314 minecraft:shroomlight
setblock 70 289 316 minecraft:shroomlight
setblock 71 289 307 minecraft:shroomlight
setblock 71 289 309 minecraft:shroomlight
setblock 71 289 311 minecraft:shroomlight
setblock 71 289 313 minecraft:shroomlight
setblock 71 289 315 minecraft:shroomlight
setblock 72 289 276 minecraft:shroomlight
setblock 72 289 278 minecraft:shroomlight
setblock 72 289 280 minecraft:shroomlight
setblock 72 289 308 minecraft:shroomlight
setblock 72 289 310 minecraft:shroomlight
setblock 72 289 312 minecraft:shroomlight
setblock 72 289 314 minecraft:shroomlight
setblock 72 289 316 minecraft:shroomlight
setblock 73 289 277 minecraft:shroomlight
setblock 73 289 279 minecraft:shroomlight
setblock 73 289 281 minecraft:shroomlight
setblock 73 289 307 minecraft:shroomlight
setblock 73 289 309 minecraft:shroomlight
setblock 73 289 311 minecraft:shroomlight
setblock 73 289 313 minecraft:shroomlight
setblock 73 289 315 minecraft:shroomlight
setblock 74 289 276 minecraft:shroomlight
setblock 74 289 278 minecraft:shroomlight
setblock 74 289 280 minecraft:shroomlight
setblock 74 289 286 minecraft:light[level=15]
setblock 74 289 294 minecraft:light[level=15]
setblock 74 289 302 minecraft:light[level=15]
setblock 74 289 308 minecraft:shroomlight
setblock 74 289 310 minecraft:shroomlight
setblock 74 289 312 minecraft:shroomlight
setblock 74 289 314 minecraft:shroomlight
setblock 74 289 316 minecraft:shroomlight
setblock 75 289 277 minecraft:shroomlight
setblock 75 289 279 minecraft:shroomlight
setblock 75 289 281 minecraft:shroomlight
setblock 75 289 307 minecraft:shroomlight
setblock 75 289 309 minecraft:shroomlight
setblock 75 289 311 minecraft:shroomlight
setblock 75 289 313 minecraft:shroomlight
setblock 75 289 315 minecraft:shroomlight
setblock 76 289 276 minecraft:shroomlight
setblock 76 289 278 minecraft:shroomlight
setblock 76 289 280 minecraft:shroomlight
setblock 76 289 308 minecraft:shroomlight
setblock 76 289 310 minecraft:shroomlight
setblock 76 289 312 minecraft:shroomlight
setblock 76 289 314 minecraft:shroomlight
setblock 76 289 316 minecraft:shroomlight
setblock 77 289 277 minecraft:shroomlight
setblock 77 289 279 minecraft:shroomlight
setblock 77 289 281 minecraft:shroomlight
setblock 77 289 307 minecraft:shroomlight
setblock 77 289 309 minecraft:shroomlight
setblock 77 289 311 minecraft:shroomlight
setblock 77 289 313 minecraft:shroomlight
setblock 77 289 315 minecraft:shroomlight
setblock 78 289 276 minecraft:shroomlight
setblock 78 289 278 minecraft:shroomlight
setblock 78 289 280 minecraft:shroomlight
fill 78 289 316 78 290 316 minecraft:spruce_planks
setblock 82 289 278 minecraft:light[level=15]
setblock 82 289 286 minecraft:light[level=15]
setblock 82 289 294 minecraft:light[level=15]
setblock 82 289 302 minecraft:light[level=15]
setblock 82 289 310 minecraft:light[level=15]
fill 83 289 276 83 290 276 minecraft:spruce_planks
fill 83 289 317 83 294 317 minecraft:light_blue_concrete
fill 85 289 316 85 290 316 minecraft:spruce_planks
fill 88 289 275 88 300 275 minecraft:light_blue_concrete
fill 88 289 278 88 290 278 minecraft:spruce_planks
fill 88 289 285 88 290 285 minecraft:spruce_planks
fill 88 289 292 88 290 292 minecraft:spruce_planks
fill 88 289 299 88 290 299 minecraft:spruce_planks
fill 88 289 306 88 290 306 minecraft:spruce_planks
fill 88 289 313 88 290 313 minecraft:spruce_planks
setblock 89 289 313 minecraft:white_wool
fill 48 290 277 48 290 279 minecraft:spruce_planks
setblock 48 290 282 minecraft:spruce_planks
fill 48 290 284 48 290 287 minecraft:spruce_planks
setblock 48 290 289 minecraft:spruce_planks
fill 48 290 291 48 290 294 minecraft:spruce_planks
setblock 48 290 296 minecraft:spruce_planks
fill 48 290 298 48 290 301 minecraft:spruce_planks
setblock 48 290 303 minecraft:spruce_planks
fill 48 290 305 48 290 308 minecraft:spruce_planks
setblock 48 290 310 minecraft:spruce_planks
fill 48 290 312 48 290 315 minecraft:spruce_planks
setblock 49 290 276 minecraft:spruce_planks
setblock 49 290 316 minecraft:spruce_planks
fill 51 290 276 54 290 276 minecraft:spruce_planks
fill 51 290 316 54 290 316 minecraft:spruce_planks
setblock 55 290 275 minecraft:light_blue_wool
setblock 56 290 276 minecraft:spruce_planks
setblock 56 290 316 minecraft:spruce_planks
fill 58 290 276 61 290 276 minecraft:spruce_planks
fill 58 290 312 58 291 312 minecraft:spruce_planks
fill 58 290 314 58 291 314 minecraft:spruce_planks
fill 58 290 316 58 291 316 minecraft:spruce_planks
fill 59 290 313 59 291 313 minecraft:spruce_planks
fill 59 290 315 59 291 315 minecraft:spruce_planks
fill 60 290 312 60 291 312 minecraft:spruce_planks
fill 60 290 314 60 291 314 minecraft:spruce_planks
fill 60 290 316 60 291 316 minecraft:spruce_planks
fill 61 290 313 61 291 313 minecraft:spruce_planks
fill 61 290 315 61 291 315 minecraft:spruce_planks
fill 62 290 312 62 291 312 minecraft:spruce_planks
fill 62 290 314 62 291 314 minecraft:spruce_planks
fill 62 290 316 62 291 316 minecraft:spruce_planks
setblock 63 290 276 minecraft:spruce_planks
fill 63 290 313 63 291 313 minecraft:spruce_planks
fill 63 290 315 63 291 315 minecraft:spruce_planks
fill 64 290 312 64 291 312 minecraft:spruce_planks
fill 64 290 314 64 291 314 minecraft:spruce_planks
fill 64 290 316 64 291 316 minecraft:spruce_planks
fill 65 290 276 68 290 276 minecraft:spruce_planks
fill 65 290 313 65 291 313 minecraft:spruce_planks
fill 65 290 315 65 291 315 minecraft:spruce_planks
fill 66 290 312 66 291 312 minecraft:spruce_planks
fill 66 290 314 66 291 314 minecraft:spruce_planks
fill 66 290 316 66 291 316 minecraft:spruce_planks
fill 67 290 313 67 291 313 minecraft:spruce_planks
fill 67 290 315 67 291 315 minecraft:spruce_planks
fill 68 290 312 68 291 312 minecraft:spruce_planks
fill 68 290 314 68 291 314 minecraft:spruce_planks
fill 68 290 316 68 291 316 minecraft:spruce_planks
fill 69 290 313 69 291 313 minecraft:spruce_planks
fill 69 290 315 69 291 315 minecraft:spruce_planks
setblock 69 290 317 minecraft:white_wool
setblock 70 290 276 minecraft:spruce_planks
fill 70 290 312 70 291 312 minecraft:spruce_planks
fill 70 290 314 70 291 314 minecraft:spruce_planks
fill 70 290 316 70 291 316 minecraft:spruce_planks
fill 71 290 307 71 291 307 minecraft:spruce_planks
fill 71 290 309 71 291 309 minecraft:spruce_planks
fill 71 290 311 71 291 311 minecraft:spruce_planks
fill 71 290 313 71 291 313 minecraft:spruce_planks
fill 71 290 315 71 291 315 minecraft:spruce_planks
fill 72 290 276 72 291 276 minecraft:spruce_planks
fill 72 290 278 72 291 278 minecraft:spruce_planks
fill 72 290 280 72 291 280 minecraft:spruce_planks
fill 72 290 308 72 291 308 minecraft:spruce_planks
fill 72 290 310 72 291 310 minecraft:spruce_planks
fill 72 290 312 72 291 312 minecraft:spruce_planks
fill 72 290 314 72 291 314 minecraft:spruce_planks
fill 72 290 316 72 291 316 minecraft:spruce_planks
setblock 73 290 275 minecraft:light_blue_wool
fill 73 290 277 73 291 277 minecraft:spruce_planks
fill 73 290 279 73 291 279 minecraft:spruce_planks
fill 73 290 281 73 291 281 minecraft:spruce_planks
fill 73 290 307 73 291 307 minecraft:spruce_planks
fill 73 290 309 73 291 309 minecraft:spruce_planks
fill 73 290 311 73 291 311 minecraft:spruce_planks
fill 73 290 313 73 291 313 minecraft:spruce_planks
fill 73 290 315 73 291 315 minecraft:spruce_planks
fill 74 290 276 74 291 276 minecraft:spruce_planks
fill 74 290 278 74 291 278 minecraft:spruce_planks
fill 74 290 280 74 291 280 minecraft:spruce_planks
fill 74 290 308 74 291 308 minecraft:spruce_planks
fill 74 290 310 74 291 310 minecraft:spruce_planks
fill 74 290 312 74 291 312 minecraft:spruce_planks
fill 74 290 314 74 291 314 minecraft:spruce_planks
fill 74 290 316 74 291 316 minecraft:spruce_planks
fill 75 290 275 81 294 275 minecraft:light_blue_concrete
fill 75 290 277 75 291 277 minecraft:spruce_planks
fill 75 290 279 75 291 279 minecraft:spruce_planks
fill 75 290 281 75 291 281 minecraft:spruce_planks
fill 75 290 307 75 291 307 minecraft:spruce_planks
fill 75 290 309 75 291 309 minecraft:spruce_planks
fill 75 290 311 75 291 311 minecraft:spruce_planks
fill 75 290 313 75 291 313 minecraft:spruce_planks
fill 75 290 315 75 291 315 minecraft:spruce_planks
fill 76 290 276 76 291 276 minecraft:spruce_planks
fill 76 290 278 76 291 278 minecraft:spruce_planks
fill 76 290 280 76 291 280 minecraft:spruce_planks
fill 76 290 308 76 291 308 minecraft:spruce_planks
fill 76 290 310 76 291 310 minecraft:spruce_planks
fill 76 290 312 76 291 312 minecraft:spruce_planks
fill 76 290 314 76 291 314 minecraft:spruce_planks
fill 76 290 316 76 291 316 minecraft:spruce_planks
fill 77 290 277 77 291 277 minecraft:spruce_planks
fill 77 290 279 77 291 279 minecraft:spruce_planks
fill 77 290 281 77 291 281 minecraft:spruce_planks
fill 77 290 307 77 291 307 minecraft:spruce_planks
fill 77 290 309 77 291 309 minecraft:spruce_planks
fill 77 290 311 77 291 311 minecraft:spruce_planks
fill 77 290 313 77 291 313 minecraft:spruce_planks
fill 77 290 315 77 291 315 minecraft:spruce_planks
fill 78 290 276 82 290 276 minecraft:spruce_planks
fill 78 290 278 78 291 278 minecraft:spruce_planks
fill 78 290 280 78 291 280 minecraft:spruce_planks
fill 79 290 316 82 290 316 minecraft:spruce_planks
setblock 79 290 317 minecraft:white_wool
setblock 82 290 275 minecraft:light_blue_wool
setblock 84 290 276 minecraft:spruce_planks
setblock 84 290 316 minecraft:spruce_planks
setblock 84 290 317 minecraft:white_wool
fill 86 290 276 88 290 276 minecraft:spruce_planks
fill 86 290 280 86 291 286 minecraft:iron_bars
fill 86 290 316 88 290 316 minecraft:spruce_planks
setblock 88 290 277 minecraft:spruce_planks
setblock 88 290 279 minecraft:spruce_planks
fill 88 290 281 88 290 284 minecraft:spruce_planks
setblock 88 290 286 minecraft:spruce_planks
fill 88 290 288 88 290 291 minecraft:spruce_planks
setblock 88 290 293 minecraft:spruce_planks
fill 88 290 295 88 290 298 minecraft:spruce_planks
setblock 88 290 300 minecraft:spruce_planks
fill 88 290 302 88 290 305 minecraft:spruce_planks
setblock 88 290 307 minecraft:spruce_planks
fill 88 290 309 88 290 311 minecraft:spruce_planks
setblock 88 290 314 minecraft:spruce_planks
fill 89 290 313 89 307 313 minecraft:light_blue_concrete
fill 89 290 315 89 307 315 minecraft:light_blue_concrete
setblock 89 290 316 minecraft:light_blue_wool
setblock 47 291 290 minecraft:white_wool
fill 47 291 291 47 308 291 minecraft:light_blue_concrete
setblock 48 291 278 minecraft:spruce_planks
setblock 48 291 285 minecraft:spruce_planks
setblock 48 291 292 minecraft:spruce_planks
setblock 48 291 299 minecraft:spruce_planks
setblock 48 291 306 minecraft:spruce_planks
setblock 48 291 313 minecraft:spruce_planks
setblock 50 291 278 minecraft:light[level=12]
setblock 50 291 285 minecraft:light[level=12]
setblock 50 291 292 minecraft:light[level=12]
setblock 50 291 299 minecraft:light[level=12]
setblock 50 291 306 minecraft:light[level=12]
setblock 50 291 313 minecraft:light[level=12]
setblock 52 291 316 minecraft:spruce_planks
setblock 53 291 276 minecraft:spruce_planks
fill 55 291 275 55 308 275 minecraft:light_blue_concrete
setblock 57 291 278 minecraft:light[level=12]
setblock 57 291 285 minecraft:light[level=12]
setblock 57 291 292 minecraft:light[level=12]
setblock 57 291 299 minecraft:light[level=12]
setblock 57 291 306 minecraft:light[level=12]
setblock 57 291 313 minecraft:light[level=12]
setblock 60 291 276 minecraft:spruce_planks
setblock 64 291 278 minecraft:light[level=12]
setblock 64 291 285 minecraft:light[level=12]
setblock 64 291 292 minecraft:light[level=12]
setblock 64 291 299 minecraft:light[level=12]
setblock 64 291 306 minecraft:light[level=12]
setblock 67 291 276 minecraft:spruce_planks
fill 69 291 317 69 308 317 minecraft:light_blue_concrete
setblock 71 291 278 minecraft:light[level=12]
setblock 71 291 285 minecraft:light[level=12]
setblock 71 291 292 minecraft:light[level=12]
setblock 71 291 299 minecraft:light[level=12]
setblock 71 291 306 minecraft:light[level=12]
fill 73 291 275 73 308 275 minecraft:light_blue_concrete
setblock 78 291 276 minecraft:spruce_planks
setblock 78 291 285 minecraft:light[level=12]
setblock 78 291 292 minecraft:light[level=12]
setblock 78 291 299 minecraft:light[level=12]
setblock 78 291 306 minecraft:light[level=12]
setblock 78 291 313 minecraft:light[level=12]
fill 79 291 317 79 308 317 minecraft:light_blue_concrete
setblock 80 291 316 minecraft:spruce_planks
setblock 81 291 276 minecraft:spruce_planks
fill 82 291 275 82 308 275 minecraft:light_blue_concrete
fill 84 291 317 84 308 317 minecraft:light_blue_concrete
setblock 85 291 278 minecraft:light[level=12]
setblock 85 291 285 minecraft:light[level=12]
setblock 85 291 292 minecraft:light[level=12]
setblock 85 291 299 minecraft:light[level=12]
setblock 85 291 306 minecraft:light[level=12]
setblock 85 291 313 minecraft:light[level=12]
setblock 87 291 316 minecraft:spruce_planks
setblock 88 291 276 minecraft:spruce_planks
setblock 88 291 283 minecraft:spruce_planks
setblock 88 291 290 minecraft:spruce_planks
setblock 88 291 297 minecraft:spruce_planks
setblock 88 291 304 minecraft:spruce_planks
setblock 88 291 311 minecraft:spruce_planks
fill 89 291 316 89 295 316 minecraft:light_blue_concrete
fill 47 292 290 47 308 290 minecraft:light_blue_concrete
setblock 48 292 279 minecraft:spruce_planks
setblock 48 292 286 minecraft:spruce_planks
setblock 48 292 293 minecraft:spruce_planks
setblock 48 292 300 minecraft:spruce_planks
setblock 48 292 307 minecraft:spruce_planks
setblock 48 292 314 minecraft:spruce_planks
setblock 52 292 276 minecraft:spruce_planks
setblock 53 292 316 minecraft:spruce_planks
setblock 56 292 275 minecraft:light_blue_wool
fill 58 292 275 59 308 275 minecraft:light_blue_concrete
setblock 58 292 312 minecraft:shroomlight
setblock 58 292 314 minecraft:shroomlight
setblock 58 292 316 minecraft:shroomlight
setblock 59 292 276 minecraft:spruce_planks
setblock 59 292 313 minecraft:shroomlight
setblock 59 292 315 minecraft:shroomlight
setblock 60 292 275 minecraft:white_wool
setblock 60 292 312 minecraft:shroomlight
setblock 60 292 314 minecraft:shroomlight
setblock 60 292 316 minecraft:shroomlight
setblock 61 292 313 minecraft:shroomlight
setblock 61 292 315 minecraft:shroomlight
setblock 62 292 312 minecraft:shroomlight
setblock 62 292 314 minecraft:shroomlight
setblock 62 292 316 minecraft:shroomlight
setblock 63 292 313 minecraft:shroomlight
setblock 63 292 315 minecraft:shroomlight
setblock 64 292 312 minecraft:shroomlight
setblock 64 292 314 minecraft:shroomlight
setblock 64 292 316 minecraft:shroomlight
setblock 65 292 313 minecraft:shroomlight
setblock 65 292 315 minecraft:shroomlight
setblock 66 292 276 minecraft:spruce_planks
setblock 66 292 312 minecraft:shroomlight
setblock 66 292 314 minecraft:shroomlight
setblock 66 292 316 minecraft:shroomlight
setblock 67 292 313 minecraft:shroomlight
setblock 67 292 315 minecraft:shroomlight
setblock 68 292 312 minecraft:shroomlight
setblock 68 292 314 minecraft:shroomlight
setblock 68 292 316 minecraft:shroomlight
setblock 69 292 313 minecraft:shroomlight
setblock 69 292 315 minecraft:shroomlight
setblock 70 292 312 minecraft:shroomlight
setblock 70 292 314 minecraft:shroomlight
setblock 70 292 316 minecraft:shroomlight
setblock 71 292 307 minecraft:shroomlight
setblock 71 292 309 minecraft:shroomlight
setblock 71 292 311 minecraft:shroomlight
setblock 71 292 313 minecraft:shroomlight
setblock 71 292 315 minecraft:shroomlight
setblock 72 292 276 minecraft:shroomlight
setblock 72 292 278 minecraft:shroomlight
setblock 72 292 280 minecraft:shroomlight
setblock 72 292 308 minecraft:shroomlight
setblock 72 292 310 minecraft:shroomlight
setblock 72 292 312 minecraft:shroomlight
setblock 72 292 314 minecraft:shroomlight
setblock 72 292 316 minecraft:shroomlight
setblock 73 292 277 minecraft:shroomlight
setblock 73 292 279 minecraft:shroomlight
setblock 73 292 281 minecraft:shroomlight
setblock 73 292 307 minecraft:shroomlight
setblock 73 292 309 minecraft:shroomlight
setblock 73 292 311 minecraft:shroomlight
setblock 73 292 313 minecraft:shroomlight
setblock 73 292 315 minecraft:shroomlight
setblock 74 292 276 minecraft:shroomlight
setblock 74 292 278 minecraft:shroomlight
setblock 74 292 280 minecraft:shroomlight
setblock 74 292 308 minecraft:shroomlight
setblock 74 292 310 minecraft:shroomlight
setblock 74 292 312 minecraft:shroomlight
setblock 74 292 314 minecraft:shroomlight
setblock 74 292 316 minecraft:shroomlight
setblock 75 292 277 minecraft:shroomlight
setblock 75 292 279 minecraft:shroomlight
setblock 75 292 281 minecraft:shroomlight
setblock 75 292 307 minecraft:shroomlight
setblock 75 292 309 minecraft:shroomlight
setblock 75 292 311 minecraft:shroomlight
setblock 75 292 313 minecraft:shroomlight
setblock 75 292 315 minecraft:shroomlight
setblock 76 292 276 minecraft:shroomlight
setblock 76 292 278 minecraft:shroomlight
setblock 76 292 280 minecraft:shroomlight
setblock 76 292 308 minecraft:shroomlight
setblock 76 292 310 minecraft:shroomlight
setblock 76 292 312 minecraft:shroomlight
setblock 76 292 314 minecraft:shroomlight
setblock 76 292 316 minecraft:shroomlight
setblock 77 292 277 minecraft:shroomlight
setblock 77 292 279 minecraft:shroomlight
setblock 77 292 281 minecraft:shroomlight
setblock 77 292 307 minecraft:shroomlight
setblock 77 292 309 minecraft:shroomlight
setblock 77 292 311 minecraft:shroomlight
setblock 77 292 313 minecraft:shroomlight
setblock 77 292 315 minecraft:shroomlight
setblock 78 292 276 minecraft:shroomlight
setblock 78 292 278 minecraft:shroomlight
setblock 78 292 280 minecraft:shroomlight
setblock 80 292 276 minecraft:spruce_planks
setblock 81 292 316 minecraft:spruce_planks
setblock 87 292 276 minecraft:spruce_planks
setblock 88 292 282 minecraft:spruce_planks
setblock 88 292 289 minecraft:spruce_planks
setblock 88 292 296 minecraft:spruce_planks
setblock 88 292 303 minecraft:spruce_planks
setblock 88 292 310 minecraft:spruce_planks
setblock 88 292 316 minecraft:spruce_planks
setblock 89 292 283 minecraft:white_wool
setblock 89 292 307 minecraft:white_wool
setblock 47 293 284 minecraft:light_blue_wool
setblock 48 293 287 minecraft:spruce_planks
setblock 48 293 294 minecraft:spruce_planks
setblock 48 293 301 minecraft:spruce_planks
setblock 48 293 308 minecraft:spruce_planks
setblock 48 293 315 minecraft:spruce_planks
setblock 51 293 276 minecraft:spruce_planks
setblock 54 293 316 minecraft:spruce_planks
fill 56 293 275 56 308 275 minecraft:light_blue_concrete
setblock 58 293 276 minecraft:spruce_planks
setblock 58 293 312 minecraft:spruce_planks
setblock 58 293 314 minecraft:spruce_planks
setblock 58 293 316 minecraft:spruce_planks
setblock 59 293 313 minecraft:spruce_planks
setblock 59 293 315 minecraft:spruce_planks
fill 60 293 275 60 308 275 minecraft:light_blue_concrete
setblock 60 293 312 minecraft:spruce_planks
setblock 60 293 314 minecraft:spruce_planks
setblock 60 293 316 minecraft:spruce_planks
setblock 61 293 313 minecraft:spruce_planks
setblock 61 293 315 minecraft:spruce_planks
setblock 62 293 312 minecraft:spruce_planks
setblock 62 293 314 minecraft:spruce_planks
fill 62 293 316 62 300 316 minecraft:spruce_planks
setblock 63 293 313 minecraft:spruce_planks
setblock 63 293 315 minecraft:spruce_planks
setblock 64 293 312 minecraft:spruce_planks
setblock 64 293 314 minecraft:spruce_planks
setblock 64 293 316 minecraft:spruce_planks
setblock 65 293 276 minecraft:spruce_planks
setblock 65 293 313 minecraft:spruce_planks
setblock 65 293 315 minecraft:spruce_planks
setblock 66 293 312 minecraft:spruce_planks
setblock 66 293 314 minecraft:spruce_planks
setblock 66 293 316 minecraft:spruce_planks
setblock 67 293 313 minecraft:spruce_planks
setblock 67 293 315 minecraft:spruce_planks
setblock 68 293 312 minecraft:spruce_planks
setblock 68 293 314 minecraft:spruce_planks
setblock 68 293 316 minecraft:spruce_planks
setblock 69 293 313 minecraft:spruce_planks
setblock 69 293 315 minecraft:spruce_planks
setblock 70 293 312 minecraft:spruce_planks
setblock 70 293 314 minecraft:spruce_planks
setblock 70 293 316 minecraft:spruce_planks
fill 71 293 307 71 294 307 minecraft:spruce_planks
fill 71 293 309 71 294 309 minecraft:spruce_planks
fill 71 293 311 71 294 311 minecraft:spruce_planks
fill 71 293 313 71 294 313 minecraft:spruce_planks
fill 71 293 315 71 294 315 minecraft:spruce_planks
fill 72 293 276 72 294 276 minecraft:spruce_planks
fill 72 293 278 72 294 278 minecraft:spruce_planks
fill 72 293 280 72 294 280 minecraft:spruce_planks
fill 72 293 308 72 294 308 minecraft:spruce_planks
fill 72 293 310 72 294 310 minecraft:spruce_planks
fill 72 293 312 72 294 312 minecraft:spruce_planks
fill 72 293 314 72 294 314 minecraft:spruce_planks
fill 72 293 316 72 294 316 minecraft:spruce_planks
fill 73 293 277 73 294 277 minecraft:spruce_planks
fill 73 293 279 73 294 279 minecraft:spruce_planks
fill 73 293 281 73 294 281 minecraft:spruce_planks
fill 73 293 307 73 294 307 minecraft:spruce_planks
fill 73 293 309 73 294 309 minecraft:spruce_planks
fill 73 293 311 73 294 311 minecraft:spruce_planks
fill 73 293 313 73 294 313 minecraft:spruce_planks
fill 73 293 315 73 294 315 minecraft:spruce_planks
fill 74 293 276 74 294 276 minecraft:spruce_planks
fill 74 293 278 74 294 278 minecraft:spruce_planks
fill 74 293 280 74 294 280 minecraft:spruce_planks
fill 74 293 308 74 294 308 minecraft:spruce_planks
fill 74 293 310 74 294 310 minecraft:spruce_planks
fill 74 293 312 74 294 312 minecraft:spruce_planks
fill 74 293 314 74 294 314 minecraft:spruce_planks
fill 74 293 316 74 294 316 minecraft:spruce_planks
fill 75 293 277 75 294 277 minecraft:spruce_planks
fill 75 293 279 75 294 279 minecraft:spruce_planks
fill 75 293 281 75 294 281 minecraft:spruce_planks
fill 75 293 307 75 294 307 minecraft:spruce_planks
fill 75 293 309 75 294 309 minecraft:spruce_planks
fill 75 293 311 75 294 311 minecraft:spruce_planks
fill 75 293 313 75 294 313 minecraft:spruce_planks
fill 75 293 315 75 294 315 minecraft:spruce_planks
fill 76 293 276 76 294 276 minecraft:spruce_planks
fill 76 293 278 76 294 278 minecraft:spruce_planks
fill 76 293 280 76 294 280 minecraft:spruce_planks
fill 76 293 308 76 294 308 minecraft:spruce_planks
fill 76 293 310 76 294 310 minecraft:spruce_planks
fill 76 293 312 76 294 312 minecraft:spruce_planks
fill 76 293 314 76 294 314 minecraft:spruce_planks
fill 76 293 316 76 294 316 minecraft:spruce_planks
fill 77 293 277 77 294 277 minecraft:spruce_planks
fill 77 293 279 77 294 279 minecraft:spruce_planks
fill 77 293 281 77 294 281 minecraft:spruce_planks
fill 77 293 307 77 294 307 minecraft:spruce_planks
fill 77 293 309 77 294 309 minecraft:spruce_planks
fill 77 293 311 77 294 311 minecraft:spruce_planks
fill 77 293 313 77 294 313 minecraft:spruce_planks
fill 77 293 315 77 294 315 minecraft:spruce_planks
fill 78 293 276 79 293 276 minecraft:spruce_planks
fill 78 293 278 78 294 278 minecraft:spruce_planks
fill 78 293 280 78 294 280 minecraft:spruce_planks
fill 79 293 313 79 294 315 minecraft:iron_bars
fill 81 293 313 81 294 315 minecraft:iron_bars
setblock 82 293 316 minecraft:spruce_planks
setblock 86 293 276 minecraft:spruce_planks
setblock 88 293 281 minecraft:spruce_planks
setblock 88 293 288 minecraft:spruce_planks
setblock 88 293 295 minecraft:spruce_planks
setblock 88 293 302 minecraft:spruce_planks
setblock 88 293 309 minecraft:spruce_planks
fill 89 293 283 89 308 283 minecraft:light_blue_concrete
fill 89 293 307 89 308 307 minecraft:light_blue_concrete
fill 47 294 284 47 308 284 minecraft:light_blue_concrete
fill 48 294 280 56 294 280 minecraft:spruce_log
setblock 78 294 276 minecraft:spruce_planks
fill 80 294 312 88 294 312 minecraft:spruce_log
setblock 48 295 282 minecraft:spruce_planks
setblock 48 295 289 minecraft:spruce_planks
setblock 48 295 296 minecraft:spruce_planks
setblock 48 295 303 minecraft:spruce_planks
setblock 48 295 310 minecraft:spruce_planks
setblock 49 295 276 minecraft:spruce_planks
setblock 49 295 316 minecraft:spruce_planks
fill 51 295 280 53 303 280 minecraft:spruce_log
setblock 56 295 276 minecraft:spruce_planks
setblock 56 295 316 minecraft:spruce_planks
setblock 63 295 276 minecraft:spruce_planks
setblock 63 295 316 minecraft:spruce_planks
setblock 70 295 276 minecraft:spruce_planks
setblock 70 295 316 minecraft:spruce_planks
setblock 71 295 307 minecraft:shroomlight
setblock 71 295 309 minecraft:shroomlight
setblock 71 295 311 minecraft:shroomlight
setblock 71 295 313 minecraft:shroomlight
setblock 71 295 315 minecraft:shroomlight
setblock 72 295 276 minecraft:shroomlight
setblock 72 295 278 minecraft:shroomlight
setblock 72 295 280 minecraft:shroomlight
setblock 72 295 308 minecraft:shroomlight
setblock 72 295 310 minecraft:shroomlight
setblock 72 295 312 minecraft:shroomlight
setblock 72 295 314 minecraft:shroomlight
setblock 72 295 316 minecraft:shroomlight
setblock 73 295 277 minecraft:shroomlight
setblock 73 295 279 minecraft:shroomlight
setblock 73 295 281 minecraft:shroomlight
setblock 73 295 307 minecraft:shroomlight
setblock 73 295 309 minecraft:shroomlight
setblock 73 295 311 minecraft:shroomlight
setblock 73 295 313 minecraft:shroomlight
setblock 73 295 315 minecraft:shroomlight
setblock 74 295 276 minecraft:shroomlight
setblock 74 295 278 minecraft:shroomlight
setblock 74 295 280 minecraft:shroomlight
setblock 74 295 308 minecraft:shroomlight
setblock 74 295 310 minecraft:shroomlight
setblock 74 295 312 minecraft:shroomlight
setblock 74 295 314 minecraft:shroomlight
setblock 74 295 316 minecraft:shroomlight
fill 75 295 275 76 308 275 minecraft:light_blue_concrete
setblock 75 295 277 minecraft:shroomlight
setblock 75 295 279 minecraft:shroomlight
setblock 75 295 281 minecraft:shroomlight
setblock 75 295 307 minecraft:shroomlight
setblock 75 295 309 minecraft:shroomlight
setblock 75 295 311 minecraft:shroomlight
setblock 75 295 313 minecraft:shroomlight
setblock 75 295 315 minecraft:shroomlight
setblock 76 295 276 minecraft:shroomlight
setblock 76 295 278 minecraft:shroomlight
setblock 76 295 280 minecraft:shroomlight
setblock 76 295 308 minecraft:shroomlight
setblock 76 295 310 minecraft:shroomlight
setblock 76 295 312 minecraft:shroomlight
setblock 76 295 314 minecraft:shroomlight
setblock 76 295 316 minecraft:shroomlight
setblock 77 295 275 minecraft:white_wool
setblock 77 295 277 minecraft:shroomlight
setblock 77 295 279 minecraft:shroomlight
setblock 77 295 281 minecraft:shroomlight
setblock 77 295 307 minecraft:shroomlight
setblock 77 295 309 minecraft:shroomlight
setblock 77 295 311 minecraft:shroomlight
setblock 77 295 313 minecraft:shroomlight
setblock 77 295 315 minecraft:shroomlight
fill 78 295 275 81 308 275 minecraft:light_blue_concrete
setblock 78 295 276 minecraft:shroomlight
setblock 78 295 278 minecraft:shroomlight
setblock 78 295 280 minecraft:shroomlight
fill 83 295 312 85 303 312 minecraft:spruce_log
setblock 83 295 317 minecraft:light_blue_wool
setblock 84 295 276 minecraft:spruce_planks
setblock 84 295 316 minecraft:spruce_planks
setblock 88 295 279 minecraft:spruce_planks
setblock 88 295 286 minecraft:spruce_planks
setblock 88 295 293 minecraft:spruce_planks
setblock 88 295 300 minecraft:spruce_planks
setblock 88 295 307 minecraft:spruce_planks
setblock 88 295 314 minecraft:spruce_planks
setblock 48 296 276 minecraft:spruce_planks
setblock 48 296 283 minecraft:spruce_planks
setblock 48 296 290 minecraft:spruce_planks
setblock 48 296 297 minecraft:spruce_planks
setblock 48 296 304 minecraft:spruce_planks
setblock 48 296 311 minecraft:spruce_planks
setblock 50 296 316 minecraft:spruce_planks
setblock 55 296 276 minecraft:spruce_planks
setblock 57 296 316 minecraft:spruce_planks
setblock 62 296 276 minecraft:spruce_planks
setblock 64 296 316 minecraft:spruce_planks
setblock 69 296 276 minecraft:spruce_planks
fill 71 296 307 71 297 307 minecraft:spruce_planks
fill 71 296 309 71 297 309 minecraft:spruce_planks
fill 71 296 311 71 297 311 minecraft:spruce_planks
fill 71 296 313 71 297 313 minecraft:spruce_planks
fill 71 296 315 71 297 315 minecraft:spruce_planks
fill 72 296 276 72 297 276 minecraft:spruce_planks
fill 72 296 278 72 297 278 minecraft:spruce_planks
fill 72 296 280 72 297 280 minecraft:spruce_planks
fill 72 296 308 72 297 308 minecraft:spruce_planks
fill 72 296 310 72 297 310 minecraft:spruce_planks
fill 72 296 312 72 297 312 minecraft:spruce_planks
fill 72 296 314 72 297 314 minecraft:spruce_planks
fill 72 296 316 72 297 316 minecraft:spruce_planks
fill 73 296 277 73 297 277 minecraft:spruce_planks
fill 73 296 279 73 297 279 minecraft:spruce_planks
fill 73 296 281 73 297 281 minecraft:spruce_planks
fill 73 296 307 73 297 307 minecraft:spruce_planks
fill 73 296 309 73 297 309 minecraft:spruce_planks
fill 73 296 311 73 297 311 minecraft:spruce_planks
fill 73 296 313 73 297 313 minecraft:spruce_planks
fill 73 296 315 73 297 315 minecraft:spruce_planks
fill 74 296 276 74 297 276 minecraft:spruce_planks
fill 74 296 278 74 297 278 minecraft:spruce_planks
fill 74 296 280 74 297 280 minecraft:spruce_planks
fill 74 296 308 74 297 308 minecraft:spruce_planks
fill 74 296 310 74 297 310 minecraft:spruce_planks
fill 74 296 312 74 297 312 minecraft:spruce_planks
fill 74 296 314 74 297 314 minecraft:spruce_planks
fill 74 296 316 74 297 316 minecraft:spruce_planks
fill 75 296 277 75 297 277 minecraft:spruce_planks
fill 75 296 279 75 297 279 minecraft:spruce_planks
fill 75 296 281 75 297 281 minecraft:spruce_planks
fill 75 296 307 75 297 307 minecraft:spruce_planks
fill 75 296 309 75 297 309 minecraft:spruce_planks
fill 75 296 311 75 297 311 minecraft:spruce_planks
fill 75 296 313 75 297 313 minecraft:spruce_planks
fill 75 296 315 75 297 315 minecraft:spruce_planks
fill 76 296 276 76 297 276 minecraft:spruce_planks
fill 76 296 278 76 297 278 minecraft:spruce_planks
fill 76 296 280 76 297 280 minecraft:spruce_planks
fill 76 296 308 76 297 308 minecraft:spruce_planks
fill 76 296 310 76 297 310 minecraft:spruce_planks
fill 76 296 312 76 297 312 minecraft:spruce_planks
fill 76 296 314 76 297 314 minecraft:spruce_planks
fill 76 296 316 76 297 316 minecraft:spruce_planks
fill 77 296 275 77 308 275 minecraft:light_blue_concrete
fill 77 296 277 77 297 277 minecraft:spruce_planks
fill 77 296 279 77 297 279 minecraft:spruce_planks
fill 77 296 281 77 297 281 minecraft:spruce_planks
fill 77 296 307 77 297 307 minecraft:spruce_planks
fill 77 296 309 77 297 309 minecraft:spruce_planks
fill 77 296 311 77 297 311 minecraft:spruce_planks
fill 77 296 313 77 297 313 minecraft:spruce_planks
fill 77 296 315 77 297 315 minecraft:spruce_planks
fill 78 296 276 78 297 276 minecraft:spruce_planks
fill 78 296 278 78 297 278 minecraft:spruce_planks
fill 78 296 280 78 297 280 minecraft:spruce_planks
setblock 78 296 316 minecraft:spruce_planks
setblock 83 296 276 minecraft:spruce_planks
fill 83 296 317 83 305 317 minecraft:light_blue_concrete
setblock 85 296 316 minecraft:spruce_planks
setblock 88 296 278 minecraft:spruce_planks
setblock 88 296 285 minecraft:spruce_planks
setblock 88 296 292 minecraft:spruce_planks
setblock 88 296 299 minecraft:spruce_planks
setblock 88 296 306 minecraft:spruce_planks
setblock 88 296 313 minecraft:spruce_planks
setblock 89 296 292 minecraft:light_blue_wool
fill 89 296 293 89 299 293 minecraft:light_blue_concrete
setblock 89 296 316 minecraft:white_wool
setblock 47 297 301 minecraft:light_blue_wool
fill 47 297 302 47 306 306 minecraft:light_blue_concrete
setblock 48 297 277 minecraft:spruce_planks
setblock 48 297 284 minecraft:spruce_planks
setblock 48 297 291 minecraft:spruce_planks
setblock 48 297 298 minecraft:spruce_planks
setblock 48 297 305 minecraft:spruce_planks
setblock 48 297 312 minecraft:spruce_planks
setblock 50 297 278 minecraft:light[level=15]
setblock 50 297 285 minecraft:light[level=12]
setblock 50 297 286 minecraft:light[level=15]
setblock 50 297 292 minecraft:light[level=12]
setblock 50 297 294 minecraft:light[level=15]
setblock 50 297 299 minecraft:light[level=12]
setblock 50 297 302 minecraft:light[level=15]
setblock 50 297 306 minecraft:light[level=12]
setblock 50 297 310 minecraft:light[level=15]
setblock 50 297 313 minecraft:light[level=12]
setblock 51 297 316 minecraft:spruce_planks
setblock 54 297 276 minecraft:spruce_planks
setblock 57 297 278 minecraft:light[level=12]
setblock 57 297 285 minecraft:light[level=12]
setblock 57 297 292 minecraft:light[level=12]
setblock 57 297 299 minecraft:light[level=12]
setblock 57 297 306 minecraft:light[level=12]
setblock 57 297 313 minecraft:light[level=12]
setblock 58 297 278 minecraft:light[level=15]
setblock 58 297 286 minecraft:light[level=15]
setblock 58 297 294 minecraft:light[level=15]
setblock 58 297 302 minecraft:light[level=15]
setblock 58 297 310 minecraft:light[level=15]
setblock 58 297 316 minecraft:spruce_planks
setblock 61 297 276 minecraft:spruce_planks
setblock 63 297 317 minecraft:white_wool
setblock 64 297 278 minecraft:light[level=12]
setblock 64 297 285 minecraft:light[level=12]
setblock 64 297 292 minecraft:light[level=12]
setblock 64 297 299 minecraft:light[level=12]
setblock 64 297 306 minecraft:light[level=12]
setblock 64 297 313 minecraft:light[level=12]
setblock 65 297 316 minecraft:spruce_planks
setblock 66 297 278 minecraft:light[level=15]
setblock 66 297 286 minecraft:light[level=15]
setblock 66 297 294 minecraft:light[level=15]
setblock 66 297 302 minecraft:light[level=15]
setblock 66 297 310 minecraft:light[level=15]
setblock 68 297 276 minecraft:spruce_planks
setblock 71 297 278 minecraft:light[level=12]
setblock 71 297 285 minecraft:light[level=12]
setblock 71 297 292 minecraft:light[level=12]
setblock 71 297 299 minecraft:light[level=12]
setblock 71 297 306 minecraft:light[level=12]
setblock 74 297 286 minecraft:light[level=15]
setblock 74 297 294 minecraft:light[level=15]
setblock 74 297 302 minecraft:light[level=15]
setblock 78 297 285 minecraft:light[level=12]
setblock 78 297 292 minecraft:light[level=12]
setblock 78 297 299 minecraft:light[level=12]
setblock 78 297 306 minecraft:light[level=12]
setblock 78 297 313 minecraft:light[level=12]
setblock 79 297 316 minecraft:spruce_planks
setblock 82 297 276 minecraft:spruce_planks
setblock 82 297 278 minecraft:light[level=15]
setblock 82 297 286 minecraft:light[level=15]
setblock 82 297 294 minecraft:light[level=15]
setblock 82 297 302 minecraft:light[level=15]
setblock 82 297 310 minecraft:light[level=15]
setblock 85 297 278 minecraft:light[level=12]
setblock 85 297 285 minecraft:light[level=12]
setblock 85 297 292 minecraft:light[level=12]
setblock 85 297 299 minecraft:light[level=12]
setblock 85 297 306 minecraft:light[level=12]
setblock 85 297 313 minecraft:light[level=12]
setblock 86 297 316 minecraft:spruce_planks
setblock 88 297 277 minecraft:spruce_planks
setblock 88 297 284 minecraft:spruce_planks
setblock 88 297 291 minecraft:spruce_planks
setblock 88 297 298 minecraft:spruce_planks
setblock 88 297 305 minecraft:spruce_planks
setblock 88 297 312 minecraft:spruce_planks
fill 89 297 292 89 308 292 minecraft:light_blue_concrete
fill 89 297 316 89 308 316 minecraft:light_blue_concrete
setblock 47 298 280 minecraft:light_blue_wool
setblock 47 298 293 minecraft:white_wool
fill 47 298 301 47 308 301 minecraft:light_blue_concrete
setblock 48 298 278 minecraft:spruce_planks
setblock 48 298 285 minecraft:spruce_planks
setblock 48 298 292 minecraft:spruce_planks
setblock 48 298 299 minecraft:spruce_planks
setblock 48 298 306 minecraft:spruce_planks
setblock 48 298 313 minecraft:spruce_planks
setblock 52 298 316 minecraft:spruce_planks
setblock 53 298 276 minecraft:spruce_planks
setblock 59 298 316 minecraft:spruce_planks
setblock 60 298 276 minecraft:spruce_planks
fill 63 298 317 63 308 317 minecraft:light_blue_concrete
setblock 66 298 316 minecraft:spruce_planks
setblock 67 298 276 minecraft:spruce_planks
setblock 68 298 317 minecraft:white_wool
setblock 71 298 307 minecraft:shroomlight
setblock 71 298 309 minecraft:shroomlight
setblock 71 298 311 minecraft:shroomlight
setblock 71 298 313 minecraft:shroomlight
setblock 71 298 315 minecraft:shroomlight
setblock 72 298 276 minecraft:shroomlight
setblock 72 298 278 minecraft:shroomlight
setblock 72 298 280 minecraft:shroomlight
setblock 72 298 308 minecraft:shroomlight
setblock 72 298 310 minecraft:shroomlight
setblock 72 298 312 minecraft:shroomlight
setblock 72 298 314 minecraft:shroomlight
setblock 72 298 316 minecraft:shroomlight
setblock 73 298 277 minecraft:shroomlight
setblock 73 298 279 minecraft:shroomlight
setblock 73 298 281 minecraft:shroomlight
setblock 73 298 307 minecraft:shroomlight
setblock 73 298 309 minecraft:shroomlight
setblock 73 298 311 minecraft:shroomlight
setblock 73 298 313 minecraft:shroomlight
setblock 73 298 315 minecraft:shroomlight
setblock 74 298 276 minecraft:shroomlight
setblock 74 298 278 minecraft:shroomlight
setblock 74 298 280 minecraft:shroomlight
setblock 74 298 308 minecraft:shroomlight
setblock 74 298 310 minecraft:shroomlight
setblock 74 298 312 minecraft:shroomlight
setblock 74 298 314 minecraft:shroomlight
setblock 74 298 316 minecraft:shroomlight
setblock 75 298 277 minecraft:shroomlight
setblock 75 298 279 minecraft:shroomlight
setblock 75 298 281 minecraft:shroomlight
setblock 75 298 307 minecraft:shroomlight
setblock 75 298 309 minecraft:shroomlight
setblock 75 298 311 minecraft:shroomlight
setblock 75 298 313 minecraft:shroomlight
setblock 75 298 315 minecraft:shroomlight
setblock 76 298 276 minecraft:shroomlight
setblock 76 298 278 minecraft:shroomlight
setblock 76 298 280 minecraft:shroomlight
setblock 76 298 308 minecraft:shroomlight
setblock 76 298 310 minecraft:shroomlight
setblock 76 298 312 minecraft:shroomlight
setblock 76 298 314 minecraft:shroomlight
setblock 76 298 316 minecraft:shroomlight
setblock 77 298 277 minecraft:shroomlight
setblock 77 298 279 minecraft:shroomlight
setblock 77 298 281 minecraft:shroomlight
setblock 77 298 307 minecraft:shroomlight
setblock 77 298 309 minecraft:shroomlight
setblock 77 298 311 minecraft:shroomlight
setblock 77 298 313 minecraft:shroomlight
setblock 77 298 315 minecraft:shroomlight
setblock 78 298 276 minecraft:shroomlight
setblock 78 298 278 minecraft:shroomlight
setblock 78 298 280 minecraft:shroomlight
setblock 80 298 316 minecraft:spruce_planks
setblock 81 298 276 minecraft:spruce_planks
setblock 87 298 316 minecraft:spruce_planks
setblock 88 298 276 minecraft:spruce_planks
setblock 88 298 283 minecraft:spruce_planks
setblock 88 298 290 minecraft:spruce_planks
setblock 88 298 297 minecraft:spruce_planks
setblock 88 298 304 minecraft:spruce_planks
setblock 88 298 311 minecraft:spruce_planks
fill 47 299 280 47 308 280 minecraft:light_blue_concrete
setblock 47 299 287 minecraft:light_blue_wool
fill 47 299 293 47 308 293 minecraft:light_blue_concrete
fill 48 299 279 48 300 279 minecraft:spruce_planks
fill 48 299 286 48 300 286 minecraft:spruce_planks
fill 48 299 293 48 300 293 minecraft:spruce_planks
fill 48 299 300 48 300 300 minecraft:spruce_planks
fill 48 299 307 48 300 307 minecraft:spruce_planks
fill 48 299 314 48 300 314 minecraft:spruce_planks
fill 52 299 276 52 300 276 minecraft:spruce_planks
fill 53 299 316 53 300 316 minecraft:spruce_planks
fill 59 299 276 59 300 276 minecraft:spruce_planks
fill 60 299 316 60 300 316 minecraft:spruce_planks
fill 66 299 276 66 300 276 minecraft:spruce_planks
fill 67 299 316 67 300 316 minecraft:spruce_planks
setblock 68 299 317 minecraft:light_blue_concrete
setblock 69 299 275 minecraft:light_blue_wool
fill 70 299 275 70 308 275 minecraft:light_blue_concrete
fill 71 299 307 71 300 307 minecraft:spruce_planks
fill 71 299 309 71 300 309 minecraft:spruce_planks
fill 71 299 311 71 300 311 minecraft:spruce_planks
fill 71 299 313 71 300 313 minecraft:spruce_planks
fill 71 299 315 71 300 315 minecraft:spruce_planks
fill 72 299 276 72 300 276 minecraft:spruce_planks
fill 72 299 278 72 300 278 minecraft:spruce_planks
fill 72 299 280 72 300 280 minecraft:spruce_planks
fill 72 299 308 72 300 308 minecraft:spruce_planks
fill 72 299 310 72 300 310 minecraft:spruce_planks
fill 72 299 312 72 300 312 minecraft:spruce_planks
fill 72 299 314 72 300 314 minecraft:spruce_planks
fill 72 299 316 72 300 316 minecraft:spruce_planks
fill 73 299 277 73 300 277 minecraft:spruce_planks
fill 73 299 279 73 300 279 minecraft:spruce_planks
fill 73 299 281 73 300 281 minecraft:spruce_planks
fill 73 299 307 73 300 307 minecraft:spruce_planks
fill 73 299 309 73 300 309 minecraft:spruce_planks
fill 73 299 311 73 300 311 minecraft:spruce_planks
fill 73 299 313 73 300 313 minecraft:spruce_planks
fill 73 299 315 73 300 315 minecraft:spruce_planks
fill 74 299 276 74 300 276 minecraft:spruce_planks
fill 74 299 278 74 300 278 minecraft:spruce_planks
fill 74 299 280 74 300 280 minecraft:spruce_planks
fill 74 299 308 74 300 308 minecraft:spruce_planks
fill 74 299 310 74 300 310 minecraft:spruce_planks
fill 74 299 312 74 300 312 minecraft:spruce_planks
fill 74 299 314 74 300 314 minecraft:spruce_planks
fill 74 299 316 74 300 316 minecraft:spruce_planks
fill 75 299 277 75 300 277 minecraft:spruce_planks
fill 75 299 279 75 300 279 minecraft:spruce_planks
fill 75 299 281 75 300 281 minecraft:spruce_planks
fill 75 299 307 75 300 307 minecraft:spruce_planks
fill 75 299 309 75 300 309 minecraft:spruce_planks
fill 75 299 311 75 300 311 minecraft:spruce_planks
fill 75 299 313 75 300 313 minecraft:spruce_planks
fill 75 299 315 75 300 315 minecraft:spruce_planks
fill 76 299 276 76 300 276 minecraft:spruce_planks
fill 76 299 278 76 300 278 minecraft:spruce_planks
fill 76 299 280 76 300 280 minecraft:spruce_planks
fill 76 299 308 76 300 308 minecraft:spruce_planks
fill 76 299 310 76 300 310 minecraft:spruce_planks
fill 76 299 312 76 300 312 minecraft:spruce_planks
fill 76 299 314 76 300 314 minecraft:spruce_planks
fill 76 299 316 76 300 316 minecraft:spruce_planks
fill 77 299 277 77 300 277 minecraft:spruce_planks
fill 77 299 279 77 300 279 minecraft:spruce_planks
fill 77 299 281 77 300 281 minecraft:spruce_planks
fill 77 299 307 77 300 307 minecraft:spruce_planks
fill 77 299 309 77 300 309 minecraft:spruce_planks
fill 77 299 311 77 300 311 minecraft:spruce_planks
fill 77 299 313 77 300 313 minecraft:spruce_planks
fill 77 299 315 77 300 315 minecraft:spruce_planks
fill 78 299 276 78 300 276 minecraft:spruce_planks
fill 78 299 278 78 300 278 minecraft:spruce_planks
fill 78 299 280 78 300 280 minecraft:spruce_planks
fill 80 299 276 80 300 276 minecraft:spruce_planks
fill 81 299 316 81 300 316 minecraft:spruce_planks
fill 87 299 276 87 300 276 minecraft:spruce_planks
fill 88 299 282 88 300 282 minecraft:spruce_planks
fill 88 299 289 88 300 289 minecraft:spruce_planks
fill 88 299 296 88 300 296 minecraft:spruce_planks
fill 88 299 303 88 300 303 minecraft:spruce_planks
fill 88 299 310 88 300 310 minecraft:spruce_planks
fill 88 299 316 88 300 316 minecraft:spruce_planks
fill 89 299 298 89 308 299 minecraft:light_blue_concrete
setblock 89 299 300 minecraft:light_blue_wool
fill 89 299 301 89 308 301 minecraft:light_blue_concrete
fill 47 300 287 47 308 287 minecraft:light_blue_concrete
fill 47 300 298 47 308 298 minecraft:light_blue_concrete
setblock 47 300 299 minecraft:white_wool
fill 48 300 276 48 300 278 minecraft:spruce_planks
setblock 48 300 280 minecraft:spruce_planks
fill 48 300 282 48 300 285 minecraft:spruce_planks
setblock 48 300 287 minecraft:spruce_planks
fill 48 300 289 48 300 292 minecraft:spruce_planks
setblock 48 300 294 minecraft:spruce_planks
fill 48 300 296 48 300 299 minecraft:spruce_planks
setblock 48 300 301 minecraft:spruce_planks
fill 48 300 303 48 300 306 minecraft:spruce_planks
setblock 48 300 308 minecraft:spruce_planks
fill 48 300 310 48 300 313 minecraft:spruce_planks
setblock 48 300 315 minecraft:spruce_planks
setblock 49 300 276 minecraft:spruce_planks
fill 49 300 316 52 300 316 minecraft:spruce_planks
setblock 51 300 276 minecraft:spruce_planks
fill 53 300 276 56 300 276 minecraft:spruce_planks
setblock 54 300 316 minecraft:spruce_planks
fill 56 300 316 59 300 316 minecraft:spruce_planks
setblock 58 300 276 minecraft:spruce_planks
fill 60 300 276 63 300 276 minecraft:spruce_planks
setblock 61 300 316 minecraft:spruce_planks
fill 63 300 316 66 300 316 minecraft:spruce_planks
setblock 65 300 276 minecraft:spruce_planks
fill 67 300 276 70 300 276 minecraft:spruce_planks
setblock 68 300 316 minecraft:spruce_planks
setblock 68 300 317 minecraft:light_blue_wool
fill 69 300 275 69 308 275 minecraft:light_blue_concrete
setblock 70 300 316 minecraft:spruce_planks
setblock 70 300 317 minecraft:white_wool
setblock 77 300 317 minecraft:white_wool
fill 78 300 316 80 300 316 minecraft:spruce_planks
setblock 79 300 276 minecraft:spruce_planks
fill 81 300 276 84 300 276 minecraft:spruce_planks
setblock 82 300 316 minecraft:spruce_planks
fill 84 300 316 87 300 316 minecraft:spruce_planks
setblock 86 300 276 minecraft:spruce_planks
fill 88 300 276 88 300 279 minecraft:spruce_planks
setblock 88 300 281 minecraft:spruce_planks
fill 88 300 283 88 300 286 minecraft:spruce_planks
setblock 88 300 288 minecraft:spruce_planks
fill 88 300 290 88 300 293 minecraft:spruce_planks
setblock 88 300 295 minecraft:spruce_planks
fill 88 300 297 88 300 300 minecraft:spruce_planks
setblock 88 300 302 minecraft:spruce_planks
fill 88 300 304 88 300 307 minecraft:spruce_planks
setblock 88 300 309 minecraft:spruce_planks
fill 88 300 311 88 300 314 minecraft:spruce_planks
setblock 89 300 293 minecraft:light_blue_wool
fill 89 300 300 89 308 300 minecraft:light_blue_concrete
fill 47 301 299 47 308 299 minecraft:light_blue_concrete
setblock 61 301 275 minecraft:white_wool
fill 68 301 317 68 308 317 minecraft:light_blue_concrete
setblock 70 301 317 minecraft:light_blue_wool
fill 77 301 317 77 308 317 minecraft:light_blue_concrete
setblock 80 301 317 minecraft:white_wool
fill 81 301 317 81 308 317 minecraft:light_blue_concrete
setblock 88 301 275 minecraft:white_wool
fill 89 301 293 89 308 293 minecraft:light_blue_concrete
setblock 47 302 279 minecraft:light_blue_wool
setblock 49 302 317 minecraft:white_wool
fill 61 302 275 61 308 275 minecraft:light_blue_concrete
fill 70 302 317 70 308 317 minecraft:light_blue_concrete
fill 80 302 317 80 308 317 minecraft:light_blue_concrete
fill 88 302 275 88 308 275 minecraft:light_blue_concrete
setblock 89 302 309 minecraft:light_blue_wool
fill 47 303 279 47 308 279 minecraft:light_blue_concrete
fill 49 303 317 49 308 317 minecraft:light_blue_concrete
setblock 50 303 278 minecraft:light[level=12]
setblock 50 303 285 minecraft:light[level=12]
setblock 50 303 292 minecraft:light[level=12]
setblock 50 303 299 minecraft:light[level=12]
setblock 50 303 306 minecraft:light[level=12]
setblock 50 303 313 minecraft:light[level=12]
setblock 57 303 278 minecraft:light[level=12]
setblock 57 303 285 minecraft:light[level=12]
setblock 57 303 292 minecraft:light[level=12]
setblock 57 303 299 minecraft:light[level=12]
setblock 57 303 306 minecraft:light[level=12]
setblock 57 303 313 minecraft:light[level=12]
setblock 64 303 278 minecraft:light[level=12]
setblock 64 303 285 minecraft:light[level=12]
setblock 64 303 292 minecraft:light[level=12]
setblock 64 303 299 minecraft:light[level=12]
setblock 64 303 306 minecraft:light[level=12]
setblock 64 303 313 minecraft:light[level=12]
setblock 71 303 278 minecraft:light[level=12]
setblock 71 303 285 minecraft:light[level=12]
setblock 71 303 292 minecraft:light[level=12]
setblock 71 303 299 minecraft:light[level=12]
setblock 71 303 306 minecraft:light[level=12]
setblock 71 303 313 minecraft:light[level=12]
setblock 78 303 278 minecraft:light[level=12]
setblock 78 303 285 minecraft:light[level=12]
setblock 78 303 292 minecraft:light[level=12]
setblock 78 303 299 minecraft:light[level=12]
setblock 78 303 306 minecraft:light[level=12]
setblock 78 303 313 minecraft:light[level=12]
setblock 85 303 278 minecraft:light[level=12]
setblock 85 303 285 minecraft:light[level=12]
setblock 85 303 292 minecraft:light[level=12]
setblock 85 303 299 minecraft:light[level=12]
setblock 85 303 306 minecraft:light[level=12]
setblock 85 303 313 minecraft:light[level=12]
fill 89 303 309 89 308 309 minecraft:light_blue_concrete
setblock 71 306 317 minecraft:white_wool
setblock 83 306 317 minecraft:light_blue_wool
setblock 47 307 302 minecraft:white_wool
fill 47 307 303 47 308 305 minecraft:light_blue_concrete
setblock 47 307 306 minecraft:light_blue_wool
setblock 63 307 275 minecraft:white_wool
fill 71 307 317 71 308 317 minecraft:light_blue_concrete
fill 83 307 317 83 308 317 minecraft:light_blue_concrete
setblock 89 307 280 minecraft:light_blue_wool
setblock 89 307 297 minecraft:light_blue_wool
setblock 47 308 302 minecraft:light_blue_concrete
setblock 47 308 306 minecraft:light_blue_concrete
setblock 63 308 275 minecraft:light_blue_concrete
setblock 66 308 275 minecraft:light_blue_concrete
setblock 67 308 275 minecraft:white_wool
setblock 89 308 280 minecraft:light_blue_concrete
setblock 89 308 297 minecraft:light_blue_concrete
setblock 89 308 313 minecraft:white_wool
setblock 89 308 315 minecraft:light_blue_wool
