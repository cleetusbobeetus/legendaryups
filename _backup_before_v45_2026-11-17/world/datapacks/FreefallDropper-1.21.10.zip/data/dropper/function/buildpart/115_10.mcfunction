setblock 365 289 466 minecraft:pink_terracotta
setblock 367 289 465 minecraft:red_nether_bricks
setblock 368 289 464 minecraft:red_nether_bricks
fill 368 289 465 368 292 465 minecraft:pink_terracotta
setblock 368 289 504 minecraft:red_nether_bricks
fill 369 289 464 369 292 464 minecraft:pink_terracotta
fill 369 289 466 369 289 467 minecraft:pink_terracotta
setblock 369 289 468 minecraft:red_nether_bricks
setblock 369 289 483 minecraft:red_nether_bricks
setblock 369 289 484 minecraft:pink_terracotta
fill 369 289 504 369 291 504 minecraft:pink_terracotta
setblock 370 289 467 minecraft:red_nether_bricks
fill 370 289 468 370 290 470 minecraft:pink_terracotta
setblock 370 289 478 minecraft:pink_terracotta
setblock 370 289 482 minecraft:red_nether_bricks
fill 370 289 483 370 291 483 minecraft:pink_terracotta
fill 330 290 464 330 290 465 minecraft:pink_terracotta
setblock 330 290 466 minecraft:red_nether_bricks
fill 330 290 467 330 293 467 minecraft:pink_terracotta
fill 330 290 469 330 291 469 minecraft:pink_terracotta
setblock 330 290 488 minecraft:white_concrete
setblock 330 290 502 minecraft:pink_terracotta
setblock 331 290 464 minecraft:pink_terracotta
setblock 331 290 465 minecraft:red_nether_bricks
setblock 331 290 504 minecraft:pink_terracotta
setblock 332 290 464 minecraft:red_nether_bricks
setblock 332 290 504 minecraft:red_nether_bricks
fill 333 290 464 336 290 464 minecraft:pink_terracotta
fill 333 290 504 336 290 504 minecraft:pink_terracotta
fill 336 290 503 337 290 503 minecraft:pink_terracotta
setblock 337 290 464 minecraft:red_nether_bricks
setblock 337 290 504 minecraft:red_nether_bricks
fill 338 290 464 340 290 465 minecraft:pink_terracotta
setblock 338 290 500 minecraft:black_concrete
setblock 338 290 503 minecraft:red_nether_bricks
fill 338 290 504 341 290 504 minecraft:pink_terracotta
fill 339 290 503 342 290 503 minecraft:pink_terracotta
setblock 340 290 502 minecraft:white_concrete
setblock 341 290 464 minecraft:pink_terracotta
setblock 341 290 465 minecraft:red_nether_bricks
fill 341 290 502 343 290 502 minecraft:pink_terracotta
setblock 342 290 464 minecraft:red_nether_bricks
fill 342 290 465 342 293 465 minecraft:pink_terracotta
setblock 342 290 504 minecraft:red_nether_bricks
fill 343 290 464 343 293 464 minecraft:pink_terracotta
setblock 343 290 503 minecraft:red_nether_bricks
fill 343 290 504 346 290 504 minecraft:pink_terracotta
setblock 344 290 502 minecraft:red_nether_bricks
fill 344 290 503 347 290 503 minecraft:pink_terracotta
setblock 347 290 464 minecraft:red_nether_bricks
setblock 347 290 504 minecraft:red_nether_bricks
fill 348 290 464 348 293 464 minecraft:pink_terracotta
fill 348 290 504 348 293 504 minecraft:pink_terracotta
fill 358 290 464 361 290 464 minecraft:pink_terracotta
setblock 358 290 504 minecraft:white_concrete
fill 359 290 504 361 290 504 minecraft:pink_terracotta
setblock 360 290 465 minecraft:pink_terracotta
setblock 361 290 465 minecraft:red_nether_bricks
setblock 362 290 464 minecraft:red_nether_bricks
fill 362 290 465 362 293 465 minecraft:pink_terracotta
setblock 362 290 504 minecraft:red_nether_bricks
fill 363 290 464 363 293 464 minecraft:pink_terracotta
fill 363 290 466 364 290 466 minecraft:pink_terracotta
fill 363 290 504 363 293 504 minecraft:pink_terracotta
setblock 365 290 466 minecraft:red_nether_bricks
setblock 366 290 465 minecraft:red_nether_bricks
fill 366 290 466 366 293 466 minecraft:pink_terracotta
setblock 367 290 464 minecraft:red_nether_bricks
fill 367 290 465 367 293 465 minecraft:pink_terracotta
setblock 367 290 504 minecraft:red_nether_bricks
fill 368 290 464 368 293 464 minecraft:pink_terracotta
fill 368 290 504 368 293 504 minecraft:pink_terracotta
setblock 369 290 466 minecraft:pink_terracotta
setblock 369 290 467 minecraft:red_nether_bricks
fill 369 290 468 369 293 468 minecraft:pink_terracotta
setblock 370 290 466 minecraft:red_nether_bricks
fill 370 290 467 370 293 467 minecraft:pink_terracotta
setblock 370 290 471 minecraft:red_nether_bricks
setblock 370 290 481 minecraft:red_nether_bricks
setblock 370 290 482 minecraft:pink_terracotta
setblock 370 290 486 minecraft:red_nether_bricks
setblock 370 290 499 minecraft:white_concrete
setblock 330 291 464 minecraft:pink_terracotta
setblock 330 291 465 minecraft:red_nether_bricks
fill 330 291 466 330 294 466 minecraft:pink_terracotta
setblock 330 291 475 minecraft:white_concrete
setblock 330 291 494 minecraft:white_concrete
setblock 331 291 464 minecraft:red_nether_bricks
fill 331 291 465 331 294 465 minecraft:pink_terracotta
setblock 331 291 504 minecraft:red_nether_bricks
fill 332 291 464 335 291 464 minecraft:pink_terracotta
fill 332 291 504 335 291 504 minecraft:pink_terracotta
setblock 336 291 464 minecraft:red_nether_bricks
fill 336 291 465 339 291 465 minecraft:pink_terracotta
setblock 336 291 503 minecraft:pink_terracotta
setblock 336 291 504 minecraft:red_nether_bricks
fill 337 291 464 340 291 464 minecraft:pink_terracotta
setblock 337 291 503 minecraft:red_nether_bricks
fill 337 291 504 340 291 504 minecraft:pink_terracotta
fill 338 291 503 341 291 503 minecraft:pink_terracotta
setblock 340 291 465 minecraft:red_nether_bricks
fill 340 291 502 342 291 502 minecraft:pink_terracotta
setblock 341 291 464 minecraft:red_nether_bricks
fill 341 291 465 341 294 465 minecraft:pink_terracotta
setblock 341 291 504 minecraft:red_nether_bricks
fill 342 291 464 342 294 464 minecraft:pink_terracotta
setblock 342 291 503 minecraft:red_nether_bricks
fill 342 291 504 345 291 504 minecraft:pink_terracotta
setblock 343 291 502 minecraft:red_nether_bricks
fill 343 291 503 346 291 503 minecraft:pink_terracotta
setblock 345 291 465 minecraft:red_nether_bricks
setblock 346 291 464 minecraft:red_nether_bricks
setblock 346 291 504 minecraft:red_nether_bricks
fill 347 291 464 347 294 464 minecraft:pink_terracotta
fill 347 291 504 347 294 504 minecraft:pink_terracotta
setblock 349 291 504 minecraft:pink_terracotta
setblock 355 291 464 minecraft:white_concrete
fill 357 291 464 360 291 464 minecraft:pink_terracotta
setblock 359 291 465 minecraft:pink_terracotta
fill 359 291 504 360 291 504 minecraft:pink_terracotta
setblock 360 291 465 minecraft:red_nether_bricks
setblock 361 291 464 minecraft:red_nether_bricks
fill 361 291 465 361 294 465 minecraft:pink_terracotta
setblock 361 291 504 minecraft:red_nether_bricks
fill 362 291 464 362 294 464 minecraft:pink_terracotta
fill 362 291 466 363 291 466 minecraft:pink_terracotta
fill 362 291 504 362 294 504 minecraft:pink_terracotta
setblock 364 291 466 minecraft:red_nether_bricks
setblock 365 291 465 minecraft:red_nether_bricks
fill 365 291 466 365 294 466 minecraft:pink_terracotta
setblock 366 291 464 minecraft:red_nether_bricks
fill 366 291 465 366 294 465 minecraft:pink_terracotta
setblock 366 291 504 minecraft:red_nether_bricks
fill 367 291 464 367 294 464 minecraft:pink_terracotta
fill 367 291 466 367 292 466 minecraft:pink_terracotta
fill 367 291 504 367 294 504 minecraft:pink_terracotta
setblock 369 291 466 minecraft:red_nether_bricks
fill 369 291 467 369 294 467 minecraft:pink_terracotta
fill 369 291 469 370 291 469 minecraft:pink_terracotta
setblock 370 291 465 minecraft:red_nether_bricks
fill 370 291 466 370 294 466 minecraft:pink_terracotta
fill 370 291 468 370 292 468 minecraft:pink_terracotta
setblock 370 291 470 minecraft:red_nether_bricks
fill 370 291 471 370 294 471 minecraft:pink_terracotta
setblock 370 291 474 minecraft:white_concrete
setblock 370 291 485 minecraft:red_nether_bricks
setblock 370 291 486 minecraft:pink_terracotta
setblock 370 291 493 minecraft:white_concrete
setblock 330 292 464 minecraft:red_nether_bricks
fill 330 292 465 330 295 465 minecraft:pink_terracotta
setblock 330 292 469 minecraft:red_nether_bricks
setblock 330 292 481 minecraft:white_concrete
setblock 330 292 500 minecraft:white_concrete
setblock 330 292 503 minecraft:pink_terracotta
setblock 330 292 504 minecraft:red_nether_bricks
fill 331 292 464 334 292 464 minecraft:pink_terracotta
fill 331 292 466 331 293 466 minecraft:pink_terracotta
fill 331 292 504 334 292 504 minecraft:pink_terracotta
fill 332 292 465 333 292 465 minecraft:pink_terracotta
setblock 334 292 465 minecraft:red_nether_bricks
setblock 335 292 464 minecraft:red_nether_bricks
fill 335 292 465 338 292 465 minecraft:pink_terracotta
setblock 335 292 504 minecraft:red_nether_bricks
fill 336 292 464 339 292 464 minecraft:pink_terracotta
setblock 336 292 503 minecraft:red_nether_bricks
fill 336 292 504 339 292 504 minecraft:pink_terracotta
fill 337 292 503 340 292 503 minecraft:pink_terracotta
setblock 339 292 465 minecraft:red_nether_bricks
setblock 340 292 464 minecraft:red_nether_bricks
fill 340 292 465 340 295 465 minecraft:pink_terracotta
fill 340 292 502 341 292 502 minecraft:pink_terracotta
setblock 340 292 504 minecraft:red_nether_bricks
fill 341 292 464 341 295 464 minecraft:pink_terracotta
setblock 341 292 503 minecraft:red_nether_bricks
fill 341 292 504 344 292 504 minecraft:pink_terracotta
setblock 342 292 502 minecraft:red_nether_bricks
fill 342 292 503 345 292 503 minecraft:pink_terracotta
setblock 344 292 465 minecraft:red_nether_bricks
setblock 345 292 464 minecraft:red_nether_bricks
fill 345 292 465 345 295 465 minecraft:pink_terracotta
setblock 345 292 504 minecraft:red_nether_bricks
fill 346 292 464 346 295 464 minecraft:pink_terracotta
setblock 346 292 503 minecraft:red_nether_bricks
fill 346 292 504 346 295 504 minecraft:pink_terracotta
setblock 349 292 464 minecraft:white_concrete
setblock 351 292 504 minecraft:white_concrete
fill 356 292 464 359 292 464 minecraft:pink_terracotta
setblock 358 292 465 minecraft:pink_terracotta
setblock 359 292 465 minecraft:red_nether_bricks
setblock 359 292 504 minecraft:pink_terracotta
setblock 360 292 464 minecraft:red_nether_bricks
fill 360 292 465 360 294 466 minecraft:pink_terracotta
setblock 360 292 504 minecraft:red_nether_bricks
fill 361 292 464 361 295 464 minecraft:pink_terracotta
fill 361 292 466 362 292 466 minecraft:pink_terracotta
fill 361 292 504 361 295 504 minecraft:pink_terracotta
setblock 363 292 466 minecraft:red_nether_bricks
setblock 364 292 465 minecraft:red_nether_bricks
fill 364 292 466 364 295 466 minecraft:pink_terracotta
setblock 365 292 464 minecraft:red_nether_bricks
fill 365 292 465 365 295 465 minecraft:pink_terracotta
setblock 365 292 504 minecraft:red_nether_bricks
fill 366 292 464 366 295 464 minecraft:pink_terracotta
fill 366 292 504 366 295 504 minecraft:pink_terracotta
setblock 368 292 466 minecraft:red_nether_bricks
fill 368 292 467 368 295 467 minecraft:pink_terracotta
setblock 369 292 465 minecraft:red_nether_bricks
fill 369 292 466 369 295 466 minecraft:pink_terracotta
setblock 369 292 469 minecraft:pink_terracotta
setblock 369 292 470 minecraft:red_nether_bricks
setblock 370 292 464 minecraft:red_nether_bricks
fill 370 292 465 370 295 465 minecraft:pink_terracotta
setblock 370 292 469 minecraft:red_nether_bricks
fill 370 292 470 370 295 470 minecraft:pink_terracotta
fill 370 292 472 370 293 472 minecraft:pink_terracotta
setblock 370 292 485 minecraft:pink_terracotta
setblock 370 292 487 minecraft:white_concrete
setblock 370 292 504 minecraft:white_concrete
fill 330 293 464 333 293 464 minecraft:pink_terracotta
setblock 330 293 468 minecraft:red_nether_bricks
fill 330 293 469 330 295 470 minecraft:pink_terracotta
setblock 330 293 487 minecraft:white_concrete
setblock 330 293 503 minecraft:red_nether_bricks
fill 330 293 504 333 293 504 minecraft:pink_terracotta
setblock 331 293 467 minecraft:red_nether_bricks
setblock 332 293 465 minecraft:pink_terracotta
setblock 333 293 465 minecraft:red_nether_bricks
setblock 334 293 464 minecraft:red_nether_bricks
fill 334 293 465 337 293 465 minecraft:pink_terracotta
setblock 334 293 504 minecraft:red_nether_bricks
fill 335 293 464 338 293 464 minecraft:pink_terracotta
setblock 335 293 503 minecraft:red_nether_bricks
fill 335 293 504 338 293 504 minecraft:pink_terracotta
fill 336 293 503 339 293 503 minecraft:pink_terracotta
setblock 338 293 465 minecraft:red_nether_bricks
setblock 339 293 464 minecraft:red_nether_bricks
fill 339 293 465 339 295 466 minecraft:pink_terracotta
setblock 339 293 504 minecraft:red_nether_bricks
fill 340 293 464 340 296 464 minecraft:pink_terracotta
fill 340 293 466 341 293 466 minecraft:pink_terracotta
setblock 340 293 502 minecraft:pink_terracotta
setblock 340 293 503 minecraft:red_nether_bricks
fill 340 293 504 343 293 504 minecraft:pink_terracotta
setblock 341 293 502 minecraft:red_nether_bricks
fill 341 293 503 344 293 503 minecraft:pink_terracotta
setblock 342 293 466 minecraft:red_nether_bricks
setblock 342 293 502 minecraft:pink_terracotta
setblock 343 293 465 minecraft:red_nether_bricks
setblock 344 293 464 minecraft:red_nether_bricks
fill 344 293 465 344 296 465 minecraft:pink_terracotta
setblock 344 293 504 minecraft:red_nether_bricks
fill 345 293 464 345 296 464 minecraft:pink_terracotta
setblock 345 293 503 minecraft:red_nether_bricks
fill 345 293 504 345 296 504 minecraft:pink_terracotta
fill 355 293 464 358 293 464 minecraft:pink_terracotta
setblock 357 293 465 minecraft:pink_terracotta
setblock 357 293 504 minecraft:white_concrete
setblock 358 293 465 minecraft:red_nether_bricks
setblock 358 293 504 minecraft:pink_terracotta
setblock 359 293 464 minecraft:red_nether_bricks
fill 359 293 465 359 295 466 minecraft:pink_terracotta
setblock 359 293 504 minecraft:red_nether_bricks
fill 360 293 464 360 296 464 minecraft:pink_terracotta
fill 360 293 504 360 296 504 minecraft:pink_terracotta
setblock 361 293 466 minecraft:pink_terracotta
setblock 362 293 466 minecraft:red_nether_bricks
fill 362 293 467 364 294 467 minecraft:pink_terracotta
setblock 363 293 465 minecraft:red_nether_bricks
fill 363 293 466 363 296 466 minecraft:pink_terracotta
setblock 364 293 464 minecraft:red_nether_bricks
fill 364 293 465 364 296 465 minecraft:pink_terracotta
setblock 364 293 504 minecraft:red_nether_bricks
fill 365 293 464 365 296 464 minecraft:pink_terracotta
fill 365 293 504 365 296 504 minecraft:pink_terracotta
setblock 367 293 466 minecraft:red_nether_bricks
setblock 368 293 465 minecraft:red_nether_bricks
fill 368 293 466 368 296 466 minecraft:pink_terracotta
fill 368 293 468 368 294 468 minecraft:pink_terracotta
setblock 369 293 464 minecraft:red_nether_bricks
fill 369 293 465 369 296 465 minecraft:pink_terracotta
setblock 369 293 469 minecraft:red_nether_bricks
fill 369 293 470 369 296 470 minecraft:pink_terracotta
fill 370 293 464 370 296 464 minecraft:pink_terracotta
setblock 370 293 468 minecraft:red_nether_bricks
fill 370 293 469 370 296 469 minecraft:pink_terracotta
setblock 370 293 481 minecraft:white_concrete
fill 330 294 464 332 294 464 minecraft:pink_terracotta
setblock 330 294 467 minecraft:red_nether_bricks
fill 330 294 468 331 296 468 minecraft:pink_terracotta
setblock 330 294 471 minecraft:pink_terracotta
fill 330 294 489 330 296 489 minecraft:pink_terracotta
setblock 330 294 493 minecraft:white_concrete
fill 330 294 503 330 296 504 minecraft:pink_terracotta
setblock 331 294 466 minecraft:red_nether_bricks
fill 331 294 467 331 297 467 minecraft:pink_terracotta
fill 331 294 504 332 294 504 minecraft:pink_terracotta
setblock 332 294 465 minecraft:red_nether_bricks
setblock 333 294 464 minecraft:red_nether_bricks
fill 333 294 465 336 294 465 minecraft:pink_terracotta
setblock 333 294 504 minecraft:red_nether_bricks
fill 334 294 464 337 294 464 minecraft:pink_terracotta
fill 334 294 504 337 294 504 minecraft:pink_terracotta
fill 335 294 503 338 294 503 minecraft:pink_terracotta
setblock 337 294 465 minecraft:red_nether_bricks
fill 337 294 466 338 296 466 minecraft:pink_terracotta
setblock 338 294 464 minecraft:red_nether_bricks
fill 338 294 465 338 297 465 minecraft:pink_terracotta
setblock 338 294 504 minecraft:red_nether_bricks
fill 339 294 464 339 297 464 minecraft:pink_terracotta
setblock 339 294 502 minecraft:pink_terracotta
setblock 339 294 503 minecraft:red_nether_bricks
fill 339 294 504 342 294 504 minecraft:pink_terracotta
setblock 340 294 466 minecraft:pink_terracotta
setblock 340 294 502 minecraft:red_nether_bricks
fill 340 294 503 343 294 503 minecraft:pink_terracotta
setblock 341 294 466 minecraft:red_nether_bricks
fill 341 294 502 341 295 502 minecraft:pink_terracotta
setblock 342 294 465 minecraft:red_nether_bricks
fill 342 294 466 342 295 466 minecraft:pink_terracotta
setblock 343 294 464 minecraft:red_nether_bricks
fill 343 294 465 343 297 465 minecraft:pink_terracotta
setblock 343 294 504 minecraft:red_nether_bricks
fill 344 294 464 344 297 464 minecraft:pink_terracotta
setblock 344 294 503 minecraft:red_nether_bricks
fill 344 294 504 344 297 504 minecraft:pink_terracotta
setblock 345 294 503 minecraft:pink_terracotta
fill 354 294 464 357 294 464 minecraft:pink_terracotta
setblock 356 294 465 minecraft:pink_terracotta
setblock 357 294 465 minecraft:red_nether_bricks
setblock 358 294 464 minecraft:red_nether_bricks
fill 358 294 465 358 296 466 minecraft:pink_terracotta
setblock 358 294 504 minecraft:red_nether_bricks
fill 359 294 464 359 297 464 minecraft:pink_terracotta
fill 359 294 504 359 297 504 minecraft:pink_terracotta
setblock 360 294 467 minecraft:red_nether_bricks
setblock 361 294 466 minecraft:red_nether_bricks
fill 361 294 467 361 297 467 minecraft:pink_terracotta
setblock 362 294 465 minecraft:red_nether_bricks
fill 362 294 466 362 297 466 minecraft:pink_terracotta
setblock 363 294 464 minecraft:red_nether_bricks
fill 363 294 465 363 297 465 minecraft:pink_terracotta
setblock 363 294 504 minecraft:red_nether_bricks
fill 364 294 464 364 297 464 minecraft:pink_terracotta
fill 364 294 504 364 297 504 minecraft:pink_terracotta
setblock 365 294 467 minecraft:red_nether_bricks
setblock 366 294 466 minecraft:red_nether_bricks
setblock 367 294 465 minecraft:red_nether_bricks
fill 367 294 466 367 297 466 minecraft:pink_terracotta
setblock 368 294 464 minecraft:red_nether_bricks
fill 368 294 465 368 297 465 minecraft:pink_terracotta
setblock 368 294 469 minecraft:red_nether_bricks
fill 369 294 464 369 297 464 minecraft:pink_terracotta
setblock 369 294 468 minecraft:red_nether_bricks
fill 369 294 469 369 297 469 minecraft:pink_terracotta
fill 369 294 471 369 295 471 minecraft:pink_terracotta
setblock 370 294 467 minecraft:red_nether_bricks
fill 370 294 468 370 297 468 minecraft:pink_terracotta
setblock 370 294 472 minecraft:red_nether_bricks
fill 370 294 473 370 297 473 minecraft:pink_terracotta
setblock 370 294 475 minecraft:white_concrete
fill 370 294 494 370 295 494 minecraft:white_concrete
setblock 370 294 500 minecraft:white_concrete
fill 330 295 464 331 295 464 minecraft:pink_terracotta
setblock 330 295 466 minecraft:red_nether_bricks
fill 330 295 467 330 298 467 minecraft:pink_terracotta
setblock 330 295 471 minecraft:red_nether_bricks
setblock 330 295 474 minecraft:white_concrete
fill 330 295 488 330 297 488 minecraft:pink_terracotta
setblock 330 295 490 minecraft:pink_terracotta
setblock 330 295 491 minecraft:red_nether_bricks
fill 330 295 492 330 297 493 minecraft:pink_terracotta
setblock 330 295 499 minecraft:white_concrete
setblock 331 295 465 minecraft:red_nether_bricks
fill 331 295 466 331 298 466 minecraft:pink_terracotta
setblock 331 295 504 minecraft:pink_terracotta
setblock 332 295 464 minecraft:red_nether_bricks
fill 332 295 465 335 295 465 minecraft:pink_terracotta
setblock 332 295 466 minecraft:light[level=12]
setblock 332 295 474 minecraft:light[level=12]
setblock 332 295 482 minecraft:light[level=12]
setblock 332 295 490 minecraft:light[level=12]
setblock 332 295 498 minecraft:light[level=12]
setblock 332 295 504 minecraft:red_nether_bricks
fill 333 295 464 336 295 464 minecraft:pink_terracotta
fill 333 295 504 336 295 504 minecraft:pink_terracotta
fill 334 295 503 337 295 503 minecraft:pink_terracotta
setblock 336 295 465 minecraft:red_nether_bricks
fill 336 295 466 336 297 466 minecraft:pink_terracotta
setblock 337 295 464 minecraft:red_nether_bricks
fill 337 295 465 337 298 465 minecraft:pink_terracotta
setblock 337 295 504 minecraft:red_nether_bricks
fill 338 295 464 338 298 464 minecraft:pink_terracotta
setblock 338 295 502 minecraft:pink_terracotta
setblock 338 295 503 minecraft:red_nether_bricks
fill 338 295 504 341 295 504 minecraft:pink_terracotta
setblock 339 295 502 minecraft:red_nether_bricks
fill 339 295 503 342 295 503 minecraft:pink_terracotta
setblock 340 295 466 minecraft:red_nether_bricks
setblock 340 295 474 minecraft:light[level=12]
setblock 340 295 482 minecraft:light[level=12]
setblock 340 295 490 minecraft:light[level=12]
setblock 340 295 498 minecraft:light[level=12]
fill 340 295 502 340 296 502 minecraft:pink_terracotta
setblock 341 295 465 minecraft:red_nether_bricks
fill 341 295 466 341 296 466 minecraft:pink_terracotta
setblock 342 295 464 minecraft:red_nether_bricks
fill 342 295 465 342 298 465 minecraft:pink_terracotta
setblock 342 295 504 minecraft:red_nether_bricks
fill 343 295 464 343 298 464 minecraft:pink_terracotta
setblock 343 295 503 minecraft:red_nether_bricks
fill 343 295 504 343 298 504 minecraft:pink_terracotta
setblock 344 295 503 minecraft:pink_terracotta
setblock 347 295 464 minecraft:red_nether_bricks
setblock 348 295 466 minecraft:light[level=12]
setblock 348 295 474 minecraft:light[level=12]
setblock 348 295 482 minecraft:light[level=12]
setblock 348 295 490 minecraft:light[level=12]
setblock 348 295 498 minecraft:light[level=12]
setblock 350 295 464 minecraft:white_concrete
fill 350 295 504 350 296 504 minecraft:white_concrete
fill 353 295 464 356 295 464 minecraft:pink_terracotta
setblock 355 295 465 minecraft:pink_terracotta
setblock 356 295 465 minecraft:red_nether_bricks
setblock 356 295 466 minecraft:light[level=12]
setblock 356 295 474 minecraft:light[level=12]
setblock 356 295 482 minecraft:light[level=12]
setblock 356 295 490 minecraft:light[level=12]
setblock 356 295 498 minecraft:light[level=12]
setblock 357 295 464 minecraft:red_nether_bricks
fill 357 295 465 357 297 466 minecraft:pink_terracotta
setblock 357 295 504 minecraft:red_nether_bricks
fill 358 295 464 358 298 464 minecraft:pink_terracotta
fill 358 295 504 358 298 504 minecraft:pink_terracotta
setblock 359 295 467 minecraft:red_nether_bricks
setblock 360 295 465 minecraft:pink_terracotta
setblock 360 295 466 minecraft:red_nether_bricks
fill 360 295 467 360 298 467 minecraft:pink_terracotta
setblock 361 295 465 minecraft:red_nether_bricks
fill 361 295 466 361 298 466 minecraft:pink_terracotta
setblock 362 295 464 minecraft:red_nether_bricks
fill 362 295 465 362 298 465 minecraft:pink_terracotta
fill 362 295 467 363 295 467 minecraft:pink_terracotta
setblock 362 295 504 minecraft:red_nether_bricks
fill 363 295 464 363 298 464 minecraft:pink_terracotta
fill 363 295 504 363 298 504 minecraft:pink_terracotta
setblock 364 295 467 minecraft:red_nether_bricks
setblock 364 295 474 minecraft:light[level=12]
setblock 364 295 482 minecraft:light[level=12]
setblock 364 295 490 minecraft:light[level=12]
setblock 364 295 498 minecraft:light[level=12]
setblock 365 295 466 minecraft:red_nether_bricks
fill 365 295 467 365 297 467 minecraft:pink_terracotta
setblock 366 295 465 minecraft:red_nether_bricks
fill 366 295 466 366 298 466 minecraft:pink_terracotta
setblock 367 295 464 minecraft:red_nether_bricks
fill 367 295 465 367 298 465 minecraft:pink_terracotta
setblock 367 295 504 minecraft:red_nether_bricks
fill 368 295 464 368 298 464 minecraft:pink_terracotta
setblock 368 295 468 minecraft:red_nether_bricks
fill 368 295 469 368 297 470 minecraft:pink_terracotta
setblock 369 295 467 minecraft:red_nether_bricks
fill 369 295 468 369 298 468 minecraft:pink_terracotta
setblock 369 295 472 minecraft:red_nether_bricks
setblock 369 295 504 minecraft:white_concrete
setblock 370 295 466 minecraft:red_nether_bricks
fill 370 295 467 370 298 467 minecraft:pink_terracotta
setblock 370 295 471 minecraft:red_nether_bricks
fill 370 295 472 370 298 472 minecraft:pink_terracotta
fill 370 295 474 370 296 474 minecraft:pink_terracotta
setblock 370 295 488 minecraft:pink_terracotta
setblock 330 296 464 minecraft:pink_terracotta
setblock 330 296 465 minecraft:red_nether_bricks
fill 330 296 466 330 299 466 minecraft:pink_terracotta
setblock 330 296 469 minecraft:pink_terracotta
setblock 330 296 470 minecraft:red_nether_bricks
fill 330 296 471 330 298 472 minecraft:pink_terracotta
setblock 330 296 480 minecraft:white_concrete
fill 330 296 486 330 297 486 minecraft:white_concrete
setblock 330 296 487 minecraft:pink_terracotta
setblock 330 296 490 minecraft:red_nether_bricks
fill 330 296 491 330 299 491 minecraft:pink_terracotta
setblock 330 296 494 minecraft:pink_terracotta
setblock 330 296 495 minecraft:red_nether_bricks
fill 330 296 502 330 297 502 minecraft:pink_terracotta
setblock 331 296 464 minecraft:red_nether_bricks
fill 331 296 465 334 296 465 minecraft:pink_terracotta
setblock 331 296 469 minecraft:red_nether_bricks
setblock 331 296 504 minecraft:red_nether_bricks
fill 332 296 464 335 296 464 minecraft:pink_terracotta
fill 332 296 504 335 296 504 minecraft:pink_terracotta
fill 334 296 503 336 296 503 minecraft:pink_terracotta
setblock 335 296 465 minecraft:red_nether_bricks
setblock 335 296 466 minecraft:pink_terracotta
setblock 336 296 464 minecraft:red_nether_bricks
fill 336 296 465 336 299 465 minecraft:pink_terracotta
setblock 336 296 504 minecraft:red_nether_bricks
fill 337 296 464 337 299 464 minecraft:pink_terracotta
setblock 337 296 503 minecraft:red_nether_bricks
fill 337 296 504 340 296 504 minecraft:pink_terracotta
setblock 338 296 502 minecraft:red_nether_bricks
fill 338 296 503 341 296 503 minecraft:pink_terracotta
setblock 339 296 465 minecraft:pink_terracotta
setblock 339 296 466 minecraft:red_nether_bricks
fill 339 296 502 339 297 502 minecraft:pink_terracotta
setblock 340 296 465 minecraft:red_nether_bricks
fill 340 296 466 340 297 466 minecraft:pink_terracotta
setblock 341 296 464 minecraft:red_nether_bricks
fill 341 296 465 341 298 465 minecraft:pink_terracotta
setblock 341 296 504 minecraft:red_nether_bricks
fill 342 296 464 342 299 464 minecraft:pink_terracotta
setblock 342 296 503 minecraft:red_nether_bricks
fill 342 296 504 342 299 504 minecraft:pink_terracotta
setblock 343 296 503 minecraft:pink_terracotta
setblock 346 296 464 minecraft:red_nether_bricks
setblock 346 296 504 minecraft:red_nether_bricks
fill 353 296 464 355 296 464 minecraft:pink_terracotta
setblock 355 296 465 minecraft:red_nether_bricks
setblock 356 296 464 minecraft:red_nether_bricks
fill 356 296 465 356 298 466 minecraft:pink_terracotta
setblock 356 296 504 minecraft:white_concrete
fill 357 296 464 357 299 464 minecraft:pink_terracotta
fill 357 296 504 357 298 504 minecraft:pink_terracotta
setblock 358 296 467 minecraft:red_nether_bricks
setblock 359 296 465 minecraft:pink_terracotta
setblock 359 296 466 minecraft:red_nether_bricks
fill 359 296 467 359 299 467 minecraft:pink_terracotta
setblock 360 296 465 minecraft:red_nether_bricks
fill 360 296 466 360 299 466 minecraft:pink_terracotta
setblock 361 296 464 minecraft:red_nether_bricks
fill 361 296 465 361 299 465 minecraft:pink_terracotta
setblock 361 296 504 minecraft:red_nether_bricks
fill 362 296 464 362 299 464 minecraft:pink_terracotta
setblock 362 296 467 minecraft:pink_terracotta
fill 362 296 504 362 298 504 minecraft:pink_terracotta
setblock 363 296 467 minecraft:red_nether_bricks
setblock 364 296 466 minecraft:red_nether_bricks
fill 364 296 467 364 297 467 minecraft:pink_terracotta
setblock 365 296 465 minecraft:red_nether_bricks
fill 365 296 466 365 298 466 minecraft:pink_terracotta
setblock 366 296 464 minecraft:red_nether_bricks
fill 366 296 465 366 299 465 minecraft:pink_terracotta
setblock 366 296 504 minecraft:red_nether_bricks
fill 367 296 464 367 299 464 minecraft:pink_terracotta
fill 367 296 468 367 299 468 minecraft:white_concrete
setblock 368 296 467 minecraft:red_nether_bricks
fill 368 296 468 368 298 468 minecraft:pink_terracotta
setblock 369 296 466 minecraft:red_nether_bricks
fill 369 296 467 369 299 467 minecraft:pink_terracotta
setblock 369 296 471 minecraft:red_nether_bricks
fill 369 296 472 369 299 472 minecraft:pink_terracotta
setblock 370 296 465 minecraft:red_nether_bricks
fill 370 296 466 370 299 466 minecraft:pink_terracotta
setblock 370 296 470 minecraft:red_nether_bricks
fill 370 296 471 370 299 471 minecraft:pink_terracotta
setblock 370 296 482 minecraft:white_concrete
setblock 370 296 489 minecraft:pink_terracotta
setblock 370 296 490 minecraft:red_nether_bricks
setblock 330 297 464 minecraft:red_nether_bricks
fill 330 297 465 333 297 465 minecraft:pink_terracotta
setblock 330 297 468 minecraft:pink_terracotta
setblock 330 297 469 minecraft:red_nether_bricks
fill 330 297 470 330 300 470 minecraft:pink_terracotta
setblock 330 297 489 minecraft:red_nether_bricks
fill 330 297 490 330 300 490 minecraft:pink_terracotta
setblock 330 297 494 minecraft:red_nether_bricks
fill 330 297 495 330 298 497 minecraft:pink_terracotta
setblock 330 297 503 minecraft:pink_terracotta
setblock 330 297 504 minecraft:red_nether_bricks
fill 331 297 464 334 297 464 minecraft:pink_terracotta
setblock 331 297 468 minecraft:red_nether_bricks
fill 331 297 469 331 298 469 minecraft:pink_terracotta
fill 331 297 491 331 297 492 minecraft:pink_terracotta
setblock 331 297 493 minecraft:red_nether_bricks
fill 331 297 504 334 297 504 minecraft:pink_terracotta
setblock 334 297 465 minecraft:red_nether_bricks
fill 334 297 503 335 297 503 minecraft:pink_terracotta
setblock 335 297 464 minecraft:red_nether_bricks
fill 335 297 465 335 299 465 minecraft:pink_terracotta
setblock 335 297 504 minecraft:red_nether_bricks
fill 336 297 464 336 300 464 minecraft:pink_terracotta
setblock 336 297 503 minecraft:red_nether_bricks
fill 336 297 504 339 297 504 minecraft:pink_terracotta
setblock 337 297 466 minecraft:pink_terracotta
fill 337 297 503 340 297 503 minecraft:pink_terracotta
setblock 338 297 466 minecraft:red_nether_bricks
setblock 338 297 502 minecraft:pink_terracotta
setblock 339 297 465 minecraft:red_nether_bricks
setblock 339 297 466 minecraft:pink_terracotta
setblock 340 297 464 minecraft:red_nether_bricks
fill 340 297 465 340 299 465 minecraft:pink_terracotta
setblock 340 297 504 minecraft:red_nether_bricks
fill 341 297 464 341 299 464 minecraft:pink_terracotta
setblock 341 297 503 minecraft:red_nether_bricks
fill 341 297 504 341 300 504 minecraft:pink_terracotta
setblock 342 297 503 minecraft:pink_terracotta
setblock 345 297 464 minecraft:red_nether_bricks
setblock 345 297 504 minecraft:red_nether_bricks
fill 353 297 464 354 297 464 minecraft:pink_terracotta
setblock 355 297 464 minecraft:red_nether_bricks
fill 355 297 465 355 300 465 minecraft:pink_terracotta
fill 356 297 464 356 300 464 minecraft:pink_terracotta
setblock 357 297 467 minecraft:red_nether_bricks
setblock 358 297 465 minecraft:pink_terracotta
setblock 358 297 466 minecraft:red_nether_bricks
fill 358 297 467 358 299 467 minecraft:pink_terracotta
setblock 359 297 465 minecraft:red_nether_bricks
fill 359 297 466 359 300 466 minecraft:pink_terracotta
setblock 360 297 464 minecraft:red_nether_bricks
fill 360 297 465 360 300 465 minecraft:pink_terracotta
setblock 360 297 504 minecraft:red_nether_bricks
fill 361 297 464 361 300 464 minecraft:pink_terracotta
fill 361 297 504 361 298 504 minecraft:pink_terracotta
setblock 362 297 467 minecraft:red_nether_bricks
setblock 363 297 466 minecraft:red_nether_bricks
fill 363 297 467 363 298 467 minecraft:pink_terracotta
setblock 364 297 465 minecraft:red_nether_bricks
fill 364 297 466 364 299 466 minecraft:pink_terracotta
setblock 365 297 464 minecraft:red_nether_bricks
fill 365 297 465 365 299 465 minecraft:pink_terracotta
fill 366 297 464 366 300 464 minecraft:pink_terracotta
fill 367 297 467 367 298 467 minecraft:white_concrete
fill 367 297 469 367 298 469 minecraft:white_concrete
setblock 368 297 466 minecraft:red_nether_bricks
fill 368 297 467 368 298 467 minecraft:pink_terracotta
setblock 369 297 465 minecraft:red_nether_bricks
fill 369 297 466 369 299 466 minecraft:pink_terracotta
setblock 369 297 470 minecraft:red_nether_bricks
fill 369 297 471 369 300 471 minecraft:pink_terracotta
fill 369 297 473 369 298 473 minecraft:pink_terracotta
setblock 370 297 464 minecraft:red_nether_bricks
fill 370 297 465 370 300 465 minecraft:pink_terracotta
setblock 370 297 469 minecraft:red_nether_bricks
fill 370 297 470 370 300 470 minecraft:pink_terracotta
setblock 370 297 474 minecraft:red_nether_bricks
fill 370 297 475 370 300 475 minecraft:pink_terracotta
setblock 370 297 476 minecraft:white_concrete
fill 370 297 490 370 297 491 minecraft:pink_terracotta
setblock 370 297 501 minecraft:white_concrete
fill 330 298 464 330 299 465 minecraft:pink_terracotta
setblock 330 298 468 minecraft:red_nether_bricks
fill 330 298 469 330 300 469 minecraft:pink_terracotta
setblock 330 298 473 minecraft:white_concrete
setblock 330 298 488 minecraft:red_nether_bricks
fill 330 298 489 330 300 489 minecraft:pink_terracotta
setblock 330 298 492 minecraft:pink_terracotta
setblock 330 298 493 minecraft:red_nether_bricks
fill 330 298 494 331 300 494 minecraft:pink_terracotta
setblock 330 298 498 minecraft:red_nether_bricks
fill 330 298 499 330 300 499 minecraft:pink_terracotta
setblock 330 298 503 minecraft:red_nether_bricks
fill 330 298 504 333 298 504 minecraft:pink_terracotta
fill 331 298 464 333 298 464 minecraft:pink_terracotta
setblock 331 298 467 minecraft:red_nether_bricks
setblock 331 298 468 minecraft:pink_terracotta
fill 331 298 490 331 298 491 minecraft:pink_terracotta
setblock 331 298 492 minecraft:red_nether_bricks
fill 331 298 493 331 300 493 minecraft:pink_terracotta
fill 331 298 495 331 299 495 minecraft:pink_terracotta
setblock 332 298 465 minecraft:pink_terracotta
setblock 333 298 465 minecraft:red_nether_bricks
setblock 334 298 464 minecraft:red_nether_bricks
fill 334 298 465 334 299 465 minecraft:pink_terracotta
setblock 334 298 503 minecraft:pink_terracotta
setblock 334 298 504 minecraft:red_nether_bricks
fill 335 298 464 335 300 464 minecraft:pink_terracotta
setblock 335 298 503 minecraft:red_nether_bricks
fill 335 298 504 338 298 504 minecraft:pink_terracotta
fill 336 298 503 339 298 503 minecraft:pink_terracotta
setblock 337 298 466 minecraft:red_nether_bricks
setblock 338 298 465 minecraft:red_nether_bricks
setblock 338 298 466 minecraft:pink_terracotta
setblock 339 298 464 minecraft:red_nether_bricks
fill 339 298 465 339 299 465 minecraft:pink_terracotta
setblock 339 298 504 minecraft:red_nether_bricks
fill 340 298 464 340 300 464 minecraft:pink_terracotta
setblock 340 298 503 minecraft:red_nether_bricks
fill 340 298 504 340 300 504 minecraft:pink_terracotta
setblock 341 298 503 minecraft:pink_terracotta
setblock 344 298 464 minecraft:red_nether_bricks
setblock 353 298 464 minecraft:pink_terracotta
setblock 354 298 464 minecraft:red_nether_bricks
fill 355 298 464 355 300 464 minecraft:pink_terracotta
setblock 357 298 465 minecraft:pink_terracotta
setblock 357 298 466 minecraft:red_nether_bricks
setblock 357 298 467 minecraft:pink_terracotta
setblock 358 298 465 minecraft:red_nether_bricks
fill 358 298 466 358 300 466 minecraft:pink_terracotta
setblock 359 298 464 minecraft:red_nether_bricks
fill 359 298 465 359 300 465 minecraft:pink_terracotta
setblock 359 298 504 minecraft:red_nether_bricks
fill 360 298 464 360 300 464 minecraft:pink_terracotta
fill 360 298 504 360 299 504 minecraft:pink_terracotta
setblock 361 298 467 minecraft:red_nether_bricks
setblock 362 298 466 minecraft:red_nether_bricks
setblock 362 298 467 minecraft:pink_terracotta
setblock 363 298 465 minecraft:red_nether_bricks
fill 363 298 466 363 299 466 minecraft:pink_terracotta
setblock 364 298 464 minecraft:red_nether_bricks
fill 364 298 465 364 300 465 minecraft:pink_terracotta
fill 365 298 464 365 300 464 minecraft:pink_terracotta
setblock 366 298 468 minecraft:black_concrete
setblock 368 298 465 minecraft:red_nether_bricks
setblock 368 298 466 minecraft:white_concrete
setblock 368 298 469 minecraft:pink_terracotta
setblock 368 298 470 minecraft:red_nether_bricks
setblock 368 298 504 minecraft:white_concrete
setblock 369 298 464 minecraft:red_nether_bricks
fill 369 298 465 369 299 465 minecraft:pink_terracotta
setblock 369 298 469 minecraft:red_nether_bricks
fill 369 298 470 369 300 470 minecraft:pink_terracotta
fill 370 298 464 370 300 464 minecraft:pink_terracotta
setblock 370 298 468 minecraft:red_nether_bricks
fill 370 298 469 370 300 469 minecraft:pink_terracotta
setblock 370 298 473 minecraft:red_nether_bricks
fill 370 298 474 370 300 474 minecraft:pink_terracotta
fill 370 298 491 370 298 492 minecraft:pink_terracotta
setblock 370 298 495 minecraft:white_concrete
setblock 330 299 467 minecraft:red_nether_bricks
fill 330 299 468 330 300 468 minecraft:pink_terracotta
setblock 330 299 471 minecraft:pink_terracotta
setblock 330 299 472 minecraft:red_nether_bricks
setblock 330 299 479 minecraft:white_concrete
setblock 330 299 492 minecraft:red_nether_bricks
fill 330 299 493 330 300 493 minecraft:pink_terracotta
fill 330 299 495 330 299 496 minecraft:pink_terracotta
setblock 330 299 497 minecraft:red_nether_bricks
fill 330 299 498 330 300 498 minecraft:pink_terracotta
fill 330 299 500 330 300 500 minecraft:pink_terracotta
fill 330 299 504 332 299 504 minecraft:pink_terracotta
fill 331 299 464 332 299 464 minecraft:pink_terracotta
setblock 331 299 490 minecraft:pink_terracotta
setblock 331 299 491 minecraft:red_nether_bricks
fill 331 299 492 331 300 492 minecraft:pink_terracotta
setblock 331 299 496 minecraft:red_nether_bricks
setblock 333 299 464 minecraft:red_nether_bricks
setblock 333 299 504 minecraft:red_nether_bricks
fill 334 299 464 334 300 464 minecraft:pink_terracotta
setblock 334 299 503 minecraft:red_nether_bricks
fill 334 299 504 337 299 504 minecraft:pink_terracotta
fill 335 299 503 338 299 503 minecraft:pink_terracotta
setblock 337 299 465 minecraft:red_nether_bricks
setblock 338 299 464 minecraft:red_nether_bricks
setblock 338 299 465 minecraft:pink_terracotta
setblock 338 299 504 minecraft:red_nether_bricks
fill 339 299 464 339 300 464 minecraft:pink_terracotta
setblock 339 299 503 minecraft:red_nether_bricks
fill 339 299 504 339 300 504 minecraft:pink_terracotta
setblock 340 299 503 minecraft:pink_terracotta
setblock 349 299 504 minecraft:white_concrete
setblock 351 299 464 minecraft:white_concrete
fill 354 299 464 354 300 464 minecraft:pink_terracotta
setblock 356 299 465 minecraft:pink_terracotta
setblock 356 299 466 minecraft:red_nether_bricks
setblock 357 299 465 minecraft:red_nether_bricks
fill 357 299 466 357 300 466 minecraft:pink_terracotta
setblock 358 299 464 minecraft:red_nether_bricks
fill 358 299 465 358 300 465 minecraft:pink_terracotta
setblock 358 299 504 minecraft:red_nether_bricks
fill 359 299 464 359 300 464 minecraft:pink_terracotta
setblock 359 299 504 minecraft:pink_terracotta
setblock 360 299 467 minecraft:red_nether_bricks
setblock 361 299 466 minecraft:red_nether_bricks
setblock 361 299 467 minecraft:pink_terracotta
setblock 362 299 465 minecraft:red_nether_bricks
fill 362 299 466 362 300 466 minecraft:pink_terracotta
setblock 363 299 464 minecraft:red_nether_bricks
fill 363 299 465 363 300 465 minecraft:pink_terracotta
fill 364 299 464 364 300 464 minecraft:pink_terracotta
setblock 367 299 465 minecraft:red_nether_bricks
setblock 368 299 464 minecraft:red_nether_bricks
setblock 368 299 465 minecraft:pink_terracotta
fill 368 299 467 368 299 469 minecraft:white_concrete
fill 369 299 464 369 300 464 minecraft:pink_terracotta
setblock 369 299 468 minecraft:red_nether_bricks
fill 369 299 469 369 300 469 minecraft:pink_terracotta
setblock 369 299 473 minecraft:red_nether_bricks
setblock 370 299 467 minecraft:red_nether_bricks
fill 370 299 468 370 300 468 minecraft:pink_terracotta
setblock 370 299 472 minecraft:red_nether_bricks
fill 370 299 473 370 300 473 minecraft:pink_terracotta
setblock 370 299 489 minecraft:white_concrete
setblock 370 299 492 minecraft:red_nether_bricks
setblock 330 300 465 minecraft:pink_terracotta
setblock 330 300 466 minecraft:red_nether_bricks
setblock 330 300 467 minecraft:pink_terracotta
setblock 330 300 471 minecraft:red_nether_bricks
setblock 330 300 472 minecraft:pink_terracotta
setblock 330 300 485 minecraft:white_concrete
setblock 330 300 491 minecraft:red_nether_bricks
setblock 330 300 492 minecraft:pink_terracotta
setblock 330 300 495 minecraft:pink_terracotta
setblock 330 300 496 minecraft:red_nether_bricks
fill 330 300 497 331 300 497 minecraft:pink_terracotta
setblock 330 300 501 minecraft:red_nether_bricks
setblock 331 300 464 minecraft:pink_terracotta
setblock 331 300 491 minecraft:pink_terracotta
setblock 331 300 495 minecraft:red_nether_bricks
setblock 331 300 496 minecraft:pink_terracotta
setblock 331 300 504 minecraft:pink_terracotta
setblock 332 300 464 minecraft:red_nether_bricks
setblock 332 300 493 minecraft:pink_terracotta
setblock 332 300 494 minecraft:red_nether_bricks
setblock 332 300 504 minecraft:red_nether_bricks
setblock 333 300 464 minecraft:pink_terracotta
fill 333 300 504 336 300 504 minecraft:pink_terracotta
fill 334 300 503 337 300 503 minecraft:pink_terracotta
setblock 336 300 465 minecraft:red_nether_bricks
setblock 337 300 464 minecraft:red_nether_bricks
setblock 337 300 465 minecraft:pink_terracotta
setblock 337 300 504 minecraft:red_nether_bricks
setblock 338 300 464 minecraft:pink_terracotta
setblock 338 300 503 minecraft:red_nether_bricks
setblock 338 300 504 minecraft:pink_terracotta
setblock 339 300 503 minecraft:pink_terracotta
setblock 345 300 464 minecraft:white_concrete
setblock 355 300 504 minecraft:white_concrete
setblock 356 300 465 minecraft:red_nether_bricks
setblock 357 300 464 minecraft:red_nether_bricks
setblock 357 300 465 minecraft:pink_terracotta
setblock 358 300 464 minecraft:pink_terracotta
setblock 360 300 466 minecraft:red_nether_bricks
setblock 361 300 465 minecraft:red_nether_bricks
setblock 361 300 466 minecraft:pink_terracotta
setblock 362 300 464 minecraft:red_nether_bricks
setblock 362 300 465 minecraft:pink_terracotta
setblock 363 300 464 minecraft:pink_terracotta
setblock 367 300 464 minecraft:red_nether_bricks
setblock 368 300 464 minecraft:pink_terracotta
setblock 369 300 467 minecraft:red_nether_bricks
setblock 369 300 468 minecraft:pink_terracotta
setblock 369 300 472 minecraft:red_nether_bricks
setblock 370 300 466 minecraft:red_nether_bricks
setblock 370 300 467 minecraft:pink_terracotta
setblock 370 300 471 minecraft:red_nether_bricks
setblock 370 300 472 minecraft:pink_terracotta
setblock 370 300 483 minecraft:white_concrete
setblock 370 300 502 minecraft:white_concrete
setblock 332 303 466 minecraft:light[level=12]
setblock 332 303 474 minecraft:light[level=12]
setblock 332 303 482 minecraft:light[level=12]
setblock 332 303 490 minecraft:light[level=12]
setblock 332 303 498 minecraft:light[level=12]
setblock 340 303 466 minecraft:light[level=12]
setblock 340 303 474 minecraft:light[level=12]
setblock 340 303 482 minecraft:light[level=12]
setblock 340 303 490 minecraft:light[level=12]
setblock 340 303 498 minecraft:light[level=12]
setblock 348 303 466 minecraft:light[level=12]
setblock 348 303 474 minecraft:light[level=12]
setblock 348 303 482 minecraft:light[level=12]
setblock 348 303 490 minecraft:light[level=12]
setblock 348 303 498 minecraft:light[level=12]
setblock 356 303 466 minecraft:light[level=12]
setblock 356 303 474 minecraft:light[level=12]
setblock 356 303 482 minecraft:light[level=12]
setblock 356 303 490 minecraft:light[level=12]
setblock 356 303 498 minecraft:light[level=12]
setblock 364 303 466 minecraft:light[level=12]
setblock 364 303 474 minecraft:light[level=12]
setblock 364 303 482 minecraft:light[level=12]
setblock 364 303 490 minecraft:light[level=12]
setblock 364 303 498 minecraft:light[level=12]
