setblock 345 200 251 minecraft:gray_concrete
setblock 345 200 252 minecraft:light_gray_concrete
setblock 345 200 253 minecraft:gray_concrete
setblock 345 200 254 minecraft:light_gray_concrete
setblock 345 200 255 minecraft:gray_concrete
setblock 345 200 257 minecraft:stone_bricks
setblock 346 200 244 minecraft:gray_concrete
setblock 346 200 245 minecraft:light_gray_concrete
setblock 346 200 246 minecraft:gray_concrete
setblock 346 200 247 minecraft:light_gray_concrete
setblock 346 200 248 minecraft:gray_concrete
setblock 346 200 249 minecraft:light_gray_concrete
setblock 346 200 250 minecraft:gray_concrete
setblock 346 200 251 minecraft:light_gray_concrete
setblock 346 200 252 minecraft:gray_concrete
setblock 346 200 253 minecraft:light_gray_concrete
setblock 346 200 254 minecraft:gray_concrete
setblock 346 200 255 minecraft:light_gray_concrete
setblock 346 200 256 minecraft:gray_concrete
setblock 347 200 241 minecraft:stone_bricks
setblock 347 200 243 minecraft:gray_concrete
setblock 347 200 244 minecraft:iron_block
setblock 347 200 245 minecraft:gray_concrete
setblock 347 200 246 minecraft:light_gray_concrete
setblock 347 200 247 minecraft:gray_concrete
setblock 347 200 248 minecraft:light_gray_concrete
setblock 347 200 249 minecraft:gray_concrete
setblock 347 200 250 minecraft:light_gray_concrete
setblock 347 200 251 minecraft:gray_concrete
setblock 347 200 252 minecraft:light_gray_concrete
setblock 347 200 253 minecraft:gray_concrete
setblock 347 200 254 minecraft:light_gray_concrete
setblock 347 200 255 minecraft:gray_concrete
setblock 347 200 256 minecraft:iron_block
setblock 347 200 257 minecraft:gray_concrete
setblock 348 200 242 minecraft:gray_concrete
setblock 348 200 243 minecraft:light_gray_concrete
setblock 348 200 244 minecraft:gray_concrete
setblock 348 200 245 minecraft:light_gray_concrete
setblock 348 200 246 minecraft:gray_concrete
setblock 348 200 247 minecraft:light_gray_concrete
setblock 348 200 248 minecraft:gray_concrete
setblock 348 200 249 minecraft:light_gray_concrete
setblock 348 200 250 minecraft:gray_concrete
setblock 348 200 251 minecraft:light_gray_concrete
setblock 348 200 252 minecraft:gray_concrete
setblock 348 200 253 minecraft:light_gray_concrete
setblock 348 200 254 minecraft:gray_concrete
setblock 348 200 255 minecraft:light_gray_concrete
setblock 348 200 256 minecraft:gray_concrete
setblock 348 200 257 minecraft:light_gray_concrete
setblock 348 200 258 minecraft:gray_concrete
fill 348 200 260 349 200 260 minecraft:stone_bricks
setblock 349 200 242 minecraft:light_gray_concrete
setblock 349 200 243 minecraft:gray_concrete
setblock 349 200 244 minecraft:light_gray_concrete
setblock 349 200 245 minecraft:gray_concrete
setblock 349 200 246 minecraft:light_gray_concrete
setblock 349 200 247 minecraft:gray_concrete
fill 349 200 248 350 200 248 minecraft:yellow_concrete
fill 349 200 249 349 200 251 minecraft:ochre_froglight
fill 349 200 252 350 200 252 minecraft:yellow_concrete
setblock 349 200 253 minecraft:gray_concrete
setblock 349 200 254 minecraft:light_gray_concrete
setblock 349 200 255 minecraft:gray_concrete
setblock 349 200 256 minecraft:light_gray_concrete
setblock 349 200 257 minecraft:gray_concrete
setblock 349 200 258 minecraft:light_gray_concrete
setblock 350 200 241 minecraft:light_gray_concrete
setblock 350 200 242 minecraft:gray_concrete
setblock 350 200 243 minecraft:light_gray_concrete
setblock 350 200 244 minecraft:gray_concrete
setblock 350 200 245 minecraft:light_gray_concrete
setblock 350 200 246 minecraft:gray_concrete
setblock 350 200 247 minecraft:ochre_froglight
setblock 350 200 253 minecraft:ochre_froglight
setblock 350 200 254 minecraft:gray_concrete
setblock 350 200 255 minecraft:light_gray_concrete
setblock 350 200 256 minecraft:gray_concrete
setblock 350 200 257 minecraft:light_gray_concrete
setblock 350 200 258 minecraft:gray_concrete
setblock 350 200 259 minecraft:light_gray_concrete
setblock 351 200 241 minecraft:gray_concrete
setblock 351 200 242 minecraft:light_gray_concrete
setblock 351 200 243 minecraft:gray_concrete
setblock 351 200 244 minecraft:light_gray_concrete
setblock 351 200 245 minecraft:gray_concrete
fill 351 200 246 351 200 247 minecraft:yellow_concrete
fill 351 200 253 351 200 254 minecraft:yellow_concrete
setblock 351 200 255 minecraft:gray_concrete
setblock 351 200 256 minecraft:light_gray_concrete
setblock 351 200 257 minecraft:gray_concrete
setblock 351 200 258 minecraft:light_gray_concrete
setblock 351 200 259 minecraft:gray_concrete
setblock 352 200 241 minecraft:light_gray_concrete
setblock 352 200 242 minecraft:gray_concrete
setblock 352 200 243 minecraft:light_gray_concrete
setblock 352 200 244 minecraft:gray_concrete
setblock 352 200 245 minecraft:light_gray_concrete
fill 352 200 246 354 200 246 minecraft:ochre_froglight
fill 352 200 254 354 200 254 minecraft:ochre_froglight
setblock 352 200 255 minecraft:light_gray_concrete
setblock 352 200 256 minecraft:gray_concrete
setblock 352 200 257 minecraft:light_gray_concrete
setblock 352 200 258 minecraft:gray_concrete
setblock 352 200 259 minecraft:light_gray_concrete
fill 353 200 241 353 201 242 minecraft:iron_block
setblock 353 200 243 minecraft:gray_concrete
setblock 353 200 244 minecraft:light_gray_concrete
setblock 353 200 245 minecraft:gray_concrete
setblock 353 200 255 minecraft:gray_concrete
setblock 353 200 256 minecraft:light_gray_concrete
setblock 353 200 257 minecraft:gray_concrete
fill 353 200 258 353 201 259 minecraft:iron_block
setblock 354 200 241 minecraft:light_gray_concrete
setblock 354 200 242 minecraft:gray_concrete
setblock 354 200 243 minecraft:light_gray_concrete
setblock 354 200 244 minecraft:gray_concrete
setblock 354 200 245 minecraft:light_gray_concrete
setblock 354 200 255 minecraft:light_gray_concrete
setblock 354 200 256 minecraft:gray_concrete
setblock 354 200 257 minecraft:light_gray_concrete
setblock 354 200 258 minecraft:gray_concrete
setblock 354 200 259 minecraft:light_gray_concrete
setblock 355 200 241 minecraft:gray_concrete
setblock 355 200 242 minecraft:light_gray_concrete
setblock 355 200 243 minecraft:gray_concrete
setblock 355 200 244 minecraft:light_gray_concrete
setblock 355 200 245 minecraft:gray_concrete
fill 355 200 246 355 200 247 minecraft:yellow_concrete
fill 355 200 253 355 200 254 minecraft:yellow_concrete
setblock 355 200 255 minecraft:gray_concrete
setblock 355 200 256 minecraft:light_gray_concrete
setblock 355 200 257 minecraft:gray_concrete
setblock 355 200 258 minecraft:light_gray_concrete
setblock 355 200 259 minecraft:gray_concrete
setblock 356 200 241 minecraft:light_gray_concrete
setblock 356 200 242 minecraft:gray_concrete
setblock 356 200 243 minecraft:light_gray_concrete
setblock 356 200 244 minecraft:gray_concrete
setblock 356 200 245 minecraft:light_gray_concrete
setblock 356 200 246 minecraft:gray_concrete
setblock 356 200 247 minecraft:ochre_froglight
fill 356 200 248 357 200 248 minecraft:yellow_concrete
fill 356 200 252 357 200 252 minecraft:yellow_concrete
setblock 356 200 253 minecraft:ochre_froglight
setblock 356 200 254 minecraft:gray_concrete
setblock 356 200 255 minecraft:light_gray_concrete
setblock 356 200 256 minecraft:gray_concrete
setblock 356 200 257 minecraft:light_gray_concrete
setblock 356 200 258 minecraft:gray_concrete
setblock 356 200 259 minecraft:light_gray_concrete
fill 357 200 240 361 200 240 minecraft:mossy_stone_bricks
setblock 357 200 242 minecraft:light_gray_concrete
setblock 357 200 243 minecraft:gray_concrete
setblock 357 200 244 minecraft:light_gray_concrete
setblock 357 200 245 minecraft:gray_concrete
setblock 357 200 246 minecraft:light_gray_concrete
setblock 357 200 247 minecraft:gray_concrete
fill 357 200 249 357 200 251 minecraft:ochre_froglight
setblock 357 200 253 minecraft:gray_concrete
setblock 357 200 254 minecraft:light_gray_concrete
setblock 357 200 255 minecraft:gray_concrete
setblock 357 200 256 minecraft:light_gray_concrete
setblock 357 200 257 minecraft:gray_concrete
setblock 357 200 258 minecraft:light_gray_concrete
fill 357 200 260 361 200 260 minecraft:stone_bricks
setblock 358 200 242 minecraft:gray_concrete
setblock 358 200 243 minecraft:light_gray_concrete
setblock 358 200 244 minecraft:gray_concrete
setblock 358 200 245 minecraft:light_gray_concrete
setblock 358 200 246 minecraft:gray_concrete
setblock 358 200 247 minecraft:light_gray_concrete
setblock 358 200 248 minecraft:gray_concrete
setblock 358 200 249 minecraft:light_gray_concrete
setblock 358 200 250 minecraft:gray_concrete
setblock 358 200 251 minecraft:light_gray_concrete
setblock 358 200 252 minecraft:gray_concrete
setblock 358 200 253 minecraft:light_gray_concrete
setblock 358 200 254 minecraft:gray_concrete
setblock 358 200 255 minecraft:light_gray_concrete
setblock 358 200 256 minecraft:gray_concrete
setblock 358 200 257 minecraft:light_gray_concrete
setblock 358 200 258 minecraft:gray_concrete
fill 359 200 241 361 200 241 minecraft:stone_bricks
setblock 359 200 243 minecraft:gray_concrete
setblock 359 200 244 minecraft:iron_block
setblock 359 200 245 minecraft:gray_concrete
setblock 359 200 246 minecraft:light_gray_concrete
setblock 359 200 247 minecraft:gray_concrete
setblock 359 200 248 minecraft:light_gray_concrete
setblock 359 200 249 minecraft:gray_concrete
setblock 359 200 250 minecraft:light_gray_concrete
setblock 359 200 251 minecraft:gray_concrete
setblock 359 200 252 minecraft:light_gray_concrete
setblock 359 200 253 minecraft:gray_concrete
setblock 359 200 254 minecraft:light_gray_concrete
setblock 359 200 255 minecraft:gray_concrete
setblock 359 200 256 minecraft:iron_block
setblock 359 200 257 minecraft:gray_concrete
fill 359 200 259 361 200 259 minecraft:stone_bricks
fill 360 200 242 362 200 242 minecraft:stone_bricks
setblock 360 200 244 minecraft:gray_concrete
setblock 360 200 245 minecraft:light_gray_concrete
setblock 360 200 246 minecraft:gray_concrete
setblock 360 200 247 minecraft:light_gray_concrete
setblock 360 200 248 minecraft:gray_concrete
setblock 360 200 249 minecraft:light_gray_concrete
setblock 360 200 250 minecraft:gray_concrete
setblock 360 200 251 minecraft:light_gray_concrete
setblock 360 200 252 minecraft:gray_concrete
setblock 360 200 253 minecraft:light_gray_concrete
setblock 360 200 254 minecraft:gray_concrete
setblock 360 200 255 minecraft:light_gray_concrete
setblock 360 200 256 minecraft:gray_concrete
fill 360 200 258 362 200 258 minecraft:mossy_stone_bricks
fill 361 200 243 362 200 243 minecraft:mossy_stone_bricks
setblock 361 200 245 minecraft:gray_concrete
setblock 361 200 246 minecraft:light_gray_concrete
setblock 361 200 247 minecraft:gray_concrete
setblock 361 200 248 minecraft:light_gray_concrete
setblock 361 200 249 minecraft:gray_concrete
fill 361 200 250 362 200 250 minecraft:iron_block
setblock 361 200 251 minecraft:gray_concrete
setblock 361 200 252 minecraft:light_gray_concrete
setblock 361 200 253 minecraft:gray_concrete
setblock 361 200 254 minecraft:light_gray_concrete
setblock 361 200 255 minecraft:gray_concrete
fill 361 200 257 362 200 257 minecraft:stone_bricks
setblock 362 200 244 minecraft:stone_bricks
setblock 362 200 247 minecraft:light_gray_concrete
setblock 362 200 248 minecraft:gray_concrete
setblock 362 200 249 minecraft:light_gray_concrete
setblock 362 200 251 minecraft:light_gray_concrete
setblock 362 200 252 minecraft:gray_concrete
setblock 362 200 253 minecraft:light_gray_concrete
setblock 362 200 256 minecraft:stone_bricks
setblock 362 200 263 minecraft:stone_bricks
setblock 362 200 270 minecraft:mossy_cobblestone
fill 366 200 228 366 200 230 minecraft:stone_bricks
fill 366 200 235 366 200 236 minecraft:stone_bricks
setblock 366 200 237 minecraft:mossy_stone_bricks
setblock 366 200 242 minecraft:stone_bricks
setblock 366 200 243 minecraft:mossy_stone_bricks
setblock 366 200 244 minecraft:stone_bricks
setblock 366 200 249 minecraft:mossy_stone_bricks
fill 366 200 250 366 200 251 minecraft:stone_bricks
fill 366 200 256 366 200 257 minecraft:stone_bricks
setblock 366 200 258 minecraft:mossy_stone_bricks
setblock 366 200 263 minecraft:stone_bricks
setblock 366 200 264 minecraft:mossy_stone_bricks
fill 366 200 265 366 200 266 minecraft:stone_bricks
setblock 366 200 267 minecraft:mossy_stone_bricks
fill 366 200 268 366 200 269 minecraft:stone_bricks
fill 367 200 228 367 200 230 minecraft:iron_block
fill 367 200 235 367 200 237 minecraft:iron_block
fill 367 200 242 367 200 244 minecraft:iron_block
fill 367 200 249 367 200 251 minecraft:iron_block
fill 367 200 256 367 200 258 minecraft:iron_block
fill 367 200 263 367 200 269 minecraft:iron_block
fill 367 200 270 367 203 270 minecraft:stone_bricks
fill 368 200 228 368 200 230 minecraft:stone_bricks
fill 368 200 235 370 200 236 minecraft:stone_bricks
fill 368 200 237 370 200 237 minecraft:mossy_stone_bricks
fill 368 200 242 370 200 242 minecraft:stone_bricks
fill 368 200 243 370 200 243 minecraft:mossy_stone_bricks
fill 368 200 244 370 200 244 minecraft:stone_bricks
fill 368 200 249 370 200 249 minecraft:mossy_stone_bricks
fill 368 200 250 370 200 251 minecraft:stone_bricks
fill 368 200 256 370 200 257 minecraft:stone_bricks
fill 368 200 258 370 200 258 minecraft:mossy_stone_bricks
fill 368 200 263 370 200 263 minecraft:stone_bricks
fill 368 200 264 370 200 264 minecraft:mossy_stone_bricks
fill 368 200 265 370 200 266 minecraft:stone_bricks
fill 368 200 267 370 200 267 minecraft:mossy_stone_bricks
fill 368 200 268 370 200 269 minecraft:stone_bricks
fill 369 200 229 370 200 230 minecraft:stone_bricks
fill 369 200 231 370 200 231 minecraft:mossy_stone_bricks
fill 369 200 232 370 200 233 minecraft:stone_bricks
fill 369 200 234 370 200 234 minecraft:mossy_stone_bricks
fill 369 200 238 370 200 239 minecraft:stone_bricks
fill 369 200 240 370 200 240 minecraft:mossy_stone_bricks
fill 369 200 241 370 200 241 minecraft:stone_bricks
fill 369 200 245 370 200 245 minecraft:stone_bricks
fill 369 200 246 370 200 246 minecraft:mossy_stone_bricks
fill 369 200 247 370 200 248 minecraft:stone_bricks
fill 369 200 252 370 200 252 minecraft:mossy_stone_bricks
fill 369 200 253 370 200 254 minecraft:stone_bricks
fill 369 200 255 370 200 255 minecraft:mossy_stone_bricks
fill 369 200 259 370 200 260 minecraft:stone_bricks
fill 369 200 261 370 200 261 minecraft:mossy_stone_bricks
fill 369 200 262 370 200 262 minecraft:stone_bricks
fill 371 200 229 371 270 229 minecraft:stone_bricks
fill 371 200 237 371 216 237 minecraft:stone_bricks
fill 371 200 250 371 206 250 minecraft:stone_bricks
fill 329 201 240 329 280 240 minecraft:stone_bricks
setblock 332 201 231 minecraft:light[level=12]
setblock 332 201 238 minecraft:light[level=12]
setblock 332 201 245 minecraft:light[level=12]
setblock 332 201 252 minecraft:light[level=12]
setblock 332 201 259 minecraft:light[level=12]
setblock 332 201 266 minecraft:light[level=12]
setblock 339 201 228 minecraft:mossy_stone_bricks
setblock 339 201 231 minecraft:light[level=12]
setblock 339 201 238 minecraft:light[level=12]
setblock 339 201 245 minecraft:light[level=12]
setblock 339 201 252 minecraft:light[level=12]
setblock 339 201 259 minecraft:light[level=12]
setblock 339 201 266 minecraft:light[level=12]
fill 340 201 241 347 209 259 minecraft:smooth_stone
setblock 346 201 231 minecraft:light[level=12]
setblock 346 201 238 minecraft:light[level=12]
setblock 346 201 266 minecraft:light[level=12]
fill 348 201 241 348 209 259 minecraft:oak_planks
fill 349 201 247 349 202 248 minecraft:red_concrete
fill 349 201 252 349 202 253 minecraft:red_concrete
fill 350 201 246 351 202 246 minecraft:red_concrete
fill 350 201 254 351 202 254 minecraft:red_concrete
fill 351 201 245 355 202 245 minecraft:red_concrete
fill 351 201 255 355 202 255 minecraft:red_concrete
setblock 353 201 231 minecraft:light[level=12]
setblock 353 201 238 minecraft:light[level=12]
setblock 353 201 266 minecraft:light[level=12]
fill 355 201 246 356 202 246 minecraft:red_concrete
fill 355 201 254 356 202 254 minecraft:red_concrete
fill 357 201 247 357 202 248 minecraft:red_concrete
fill 357 201 252 357 202 253 minecraft:red_concrete
fill 358 201 248 358 202 252 minecraft:red_concrete
fill 359 201 241 359 209 259 minecraft:oak_planks
setblock 360 201 231 minecraft:light[level=12]
setblock 360 201 238 minecraft:light[level=12]
fill 360 201 241 366 209 259 minecraft:smooth_stone
setblock 360 201 266 minecraft:light[level=12]
fill 362 201 270 362 280 270 minecraft:stone_bricks
fill 363 201 228 363 252 228 minecraft:stone_bricks
fill 363 201 229 363 201 230 minecraft:waxed_cut_copper
fill 363 201 235 365 201 235 minecraft:waxed_cut_copper
fill 363 201 237 365 201 237 minecraft:waxed_cut_copper
fill 363 201 238 365 201 240 minecraft:gray_concrete
fill 363 201 260 365 201 262 minecraft:gray_concrete
fill 363 201 263 363 201 268 minecraft:waxed_cut_copper
fill 364 201 230 365 201 230 minecraft:waxed_cut_copper
fill 364 201 263 365 201 263 minecraft:waxed_cut_copper
fill 364 201 270 364 280 270 minecraft:stone_bricks
fill 365 201 228 368 202 228 minecraft:stone_bricks
setblock 367 201 231 minecraft:light[level=12]
setblock 367 201 238 minecraft:light[level=12]
setblock 367 201 245 minecraft:light[level=12]
setblock 367 201 252 minecraft:light[level=12]
setblock 367 201 259 minecraft:light[level=12]
setblock 367 201 266 minecraft:light[level=12]
setblock 329 202 242 minecraft:mossy_cobblestone
setblock 332 202 231 minecraft:light[level=15]
setblock 332 202 239 minecraft:light[level=15]
setblock 332 202 247 minecraft:light[level=15]
setblock 332 202 255 minecraft:light[level=15]
setblock 332 202 263 minecraft:light[level=15]
fill 339 202 228 339 280 228 minecraft:stone_bricks
setblock 340 202 231 minecraft:light[level=15]
setblock 340 202 239 minecraft:light[level=15]
setblock 340 202 263 minecraft:light[level=15]
setblock 345 202 270 minecraft:mossy_stone_bricks
setblock 348 202 231 minecraft:light[level=15]
setblock 348 202 239 minecraft:light[level=15]
setblock 348 202 263 minecraft:light[level=15]
setblock 349 202 246 minecraft:red_concrete
setblock 349 202 250 minecraft:red_concrete
setblock 349 202 254 minecraft:red_concrete
setblock 350 202 245 minecraft:red_concrete
setblock 350 202 247 minecraft:red_concrete
setblock 350 202 253 minecraft:red_concrete
setblock 350 202 255 minecraft:red_concrete
setblock 353 202 246 minecraft:red_concrete
setblock 353 202 254 minecraft:red_concrete
setblock 356 202 231 minecraft:light[level=15]
setblock 356 202 239 minecraft:light[level=15]
setblock 356 202 245 minecraft:red_concrete
setblock 356 202 247 minecraft:red_concrete
setblock 356 202 253 minecraft:red_concrete
setblock 356 202 255 minecraft:red_concrete
setblock 356 202 263 minecraft:light[level=15]
setblock 357 202 246 minecraft:red_concrete
setblock 357 202 250 minecraft:red_concrete
setblock 357 202 254 minecraft:red_concrete
setblock 358 202 247 minecraft:red_concrete
setblock 358 202 253 minecraft:red_concrete
setblock 361 202 270 minecraft:mossy_cobblestone
fill 364 202 228 364 280 228 minecraft:stone_bricks
setblock 364 202 231 minecraft:light[level=15]
setblock 364 202 239 minecraft:light[level=15]
setblock 364 202 263 minecraft:light[level=15]
fill 329 203 242 329 280 242 minecraft:stone_bricks
setblock 336 203 269 minecraft:lime_terracotta
fill 345 203 270 345 213 270 minecraft:stone_bricks
fill 361 203 270 361 242 270 minecraft:stone_bricks
setblock 363 203 270 minecraft:mossy_stone_bricks
fill 365 203 228 367 203 228 minecraft:stone_bricks
fill 367 203 231 369 208 234 minecraft:gray_concrete
fill 367 203 238 369 208 241 minecraft:gray_concrete
fill 367 203 245 369 208 248 minecraft:gray_concrete
fill 367 203 252 369 208 255 minecraft:gray_concrete
fill 367 203 259 369 208 262 minecraft:gray_concrete
fill 368 203 228 368 203 230 minecraft:light_gray_concrete
fill 368 203 235 368 203 237 minecraft:light_gray_concrete
fill 368 203 242 368 203 244 minecraft:light_gray_concrete
fill 368 203 249 368 203 251 minecraft:light_gray_concrete
fill 368 203 256 368 203 258 minecraft:light_gray_concrete
fill 368 203 263 368 203 269 minecraft:light_gray_concrete
fill 332 204 249 332 259 249 minecraft:iron_block
setblock 356 204 228 minecraft:mossy_stone_bricks
fill 363 204 230 365 204 232 minecraft:iron_block
fill 363 204 270 363 218 270 minecraft:stone_bricks
fill 365 204 228 365 231 228 minecraft:stone_bricks
fill 366 204 228 366 204 230 minecraft:light_gray_concrete
fill 366 204 231 366 207 234 minecraft:gray_concrete
fill 366 204 235 366 204 237 minecraft:light_gray_concrete
fill 366 204 238 366 207 240 minecraft:gray_concrete
fill 366 204 260 366 207 262 minecraft:gray_concrete
fill 366 204 263 366 204 269 minecraft:light_gray_concrete
fill 367 204 228 370 204 229 minecraft:light_gray_concrete
fill 367 204 230 369 207 230 minecraft:gray_concrete
fill 367 204 235 369 207 235 minecraft:gray_concrete
fill 367 204 236 370 204 236 minecraft:light_gray_concrete
fill 367 204 237 369 207 237 minecraft:gray_concrete
fill 367 204 242 369 207 242 minecraft:gray_concrete
fill 367 204 243 370 204 243 minecraft:light_gray_concrete
fill 367 204 244 369 207 244 minecraft:gray_concrete
fill 367 204 249 369 207 249 minecraft:gray_concrete
fill 367 204 250 370 204 250 minecraft:light_gray_concrete
fill 367 204 251 369 207 251 minecraft:gray_concrete
fill 367 204 256 369 207 256 minecraft:gray_concrete
fill 367 204 257 370 204 257 minecraft:light_gray_concrete
fill 367 204 258 369 207 258 minecraft:gray_concrete
fill 367 204 263 369 207 263 minecraft:gray_concrete
fill 367 204 264 369 204 270 minecraft:light_gray_concrete
setblock 370 204 230 minecraft:light_gray_concrete
fill 370 204 231 370 207 234 minecraft:gray_concrete
setblock 370 204 235 minecraft:light_gray_concrete
setblock 370 204 237 minecraft:light_gray_concrete
fill 370 204 238 370 207 241 minecraft:gray_concrete
setblock 370 204 242 minecraft:light_gray_concrete
setblock 370 204 244 minecraft:light_gray_concrete
fill 370 204 245 370 207 248 minecraft:gray_concrete
setblock 370 204 249 minecraft:light_gray_concrete
setblock 370 204 251 minecraft:lime_concrete
fill 370 204 252 370 207 255 minecraft:gray_concrete
setblock 370 204 256 minecraft:light_gray_concrete
setblock 370 204 258 minecraft:light_gray_concrete
fill 370 204 259 370 207 262 minecraft:gray_concrete
fill 370 204 263 370 204 269 minecraft:light_gray_concrete
fill 371 204 228 371 280 228 minecraft:stone_bricks
fill 356 205 228 356 212 228 minecraft:stone_bricks
fill 363 205 230 364 232 232 minecraft:iron_block
fill 365 205 230 365 233 231 minecraft:iron_block
fill 365 205 232 365 206 233 minecraft:gray_concrete
fill 365 205 239 365 206 240 minecraft:gray_concrete
fill 365 205 260 365 206 261 minecraft:gray_concrete
fill 366 205 228 367 207 229 minecraft:light_gray_concrete
fill 366 205 230 366 206 230 minecraft:gray_concrete
fill 366 205 235 366 206 235 minecraft:gray_concrete
fill 366 205 236 367 207 236 minecraft:light_gray_concrete
fill 366 205 237 366 206 237 minecraft:gray_concrete
fill 366 205 263 366 206 263 minecraft:gray_concrete
fill 366 205 264 367 206 270 minecraft:light_gray_concrete
fill 367 205 243 367 207 243 minecraft:light_gray_concrete
fill 367 205 250 367 207 250 minecraft:light_gray_concrete
fill 367 205 257 367 207 257 minecraft:light_gray_concrete
fill 368 205 228 370 207 228 minecraft:light_gray_concrete
fill 368 205 229 368 206 229 minecraft:gray_concrete
fill 368 205 236 368 206 236 minecraft:gray_concrete
fill 368 205 243 368 206 243 minecraft:gray_concrete
fill 368 205 250 368 206 250 minecraft:gray_concrete
fill 368 205 257 368 206 257 minecraft:gray_concrete
fill 368 205 264 368 206 264 minecraft:gray_concrete
fill 368 205 265 370 206 270 minecraft:light_gray_concrete
fill 369 205 229 370 207 229 minecraft:light_gray_concrete
fill 369 205 236 370 207 236 minecraft:light_gray_concrete
fill 369 205 243 370 207 243 minecraft:light_gray_concrete
fill 369 205 250 370 207 250 minecraft:light_gray_concrete
fill 369 205 257 370 207 257 minecraft:light_gray_concrete
fill 369 205 264 370 207 264 minecraft:light_gray_concrete
fill 370 205 230 370 206 230 minecraft:gray_concrete
fill 370 205 235 370 206 235 minecraft:gray_concrete
fill 370 205 237 370 206 237 minecraft:gray_concrete
fill 370 205 242 370 206 242 minecraft:gray_concrete
fill 370 205 244 370 206 244 minecraft:gray_concrete
fill 370 205 249 370 206 249 minecraft:gray_concrete
fill 370 205 251 370 206 251 minecraft:gray_concrete
fill 370 205 256 370 206 256 minecraft:gray_concrete
fill 370 205 258 370 206 258 minecraft:gray_concrete
fill 370 205 263 370 206 263 minecraft:gray_concrete
fill 371 205 232 371 206 233 minecraft:gray_concrete
fill 371 205 239 371 206 240 minecraft:gray_concrete
fill 371 205 246 371 206 247 minecraft:gray_concrete
fill 371 205 253 371 206 254 minecraft:gray_concrete
fill 371 205 260 371 206 261 minecraft:gray_concrete
fill 331 206 248 331 206 250 minecraft:light_gray_concrete
fill 332 206 248 333 206 248 minecraft:light_gray_concrete
fill 332 206 250 333 206 250 minecraft:light_gray_concrete
setblock 333 206 249 minecraft:light_gray_concrete
setblock 351 206 229 minecraft:lime_terracotta
fill 362 206 230 362 206 232 minecraft:light_gray_concrete
fill 363 206 229 365 206 229 minecraft:light_gray_concrete
fill 363 206 233 364 206 233 minecraft:light_gray_concrete
setblock 371 206 235 minecraft:cobblestone
setblock 330 207 238 minecraft:lime_concrete
setblock 332 207 231 minecraft:light[level=12]
setblock 332 207 238 minecraft:light[level=12]
setblock 332 207 245 minecraft:light[level=12]
setblock 332 207 252 minecraft:light[level=12]
setblock 332 207 259 minecraft:light[level=12]
setblock 332 207 266 minecraft:light[level=12]
setblock 339 207 231 minecraft:light[level=12]
setblock 339 207 238 minecraft:light[level=12]
setblock 339 207 245 minecraft:light[level=12]
setblock 339 207 252 minecraft:light[level=12]
setblock 339 207 259 minecraft:light[level=12]
setblock 339 207 266 minecraft:light[level=12]
setblock 346 207 231 minecraft:light[level=12]
setblock 346 207 238 minecraft:light[level=12]
setblock 346 207 266 minecraft:light[level=12]
setblock 353 207 231 minecraft:light[level=12]
setblock 353 207 238 minecraft:light[level=12]
setblock 353 207 245 minecraft:light[level=12]
setblock 353 207 252 minecraft:light[level=12]
setblock 353 207 259 minecraft:light[level=12]
setblock 353 207 266 minecraft:light[level=12]
setblock 360 207 231 minecraft:light[level=12]
setblock 360 207 238 minecraft:light[level=12]
setblock 360 207 266 minecraft:light[level=12]
fill 365 207 232 365 233 232 minecraft:iron_block
setblock 366 207 230 minecraft:light_gray_concrete
setblock 366 207 235 minecraft:light_gray_concrete
setblock 366 207 237 minecraft:light_gray_concrete
fill 366 207 263 366 207 269 minecraft:light_gray_concrete
fill 366 207 270 366 280 270 minecraft:stone_bricks
fill 367 207 264 368 207 270 minecraft:light_gray_concrete
fill 368 207 229 368 208 229 minecraft:light_gray_concrete
fill 368 207 236 368 208 236 minecraft:light_gray_concrete
fill 368 207 243 368 208 243 minecraft:light_gray_concrete
fill 368 207 250 368 208 250 minecraft:light_gray_concrete
fill 368 207 257 368 208 257 minecraft:light_gray_concrete
fill 369 207 265 369 207 270 minecraft:light_gray_concrete
setblock 370 207 230 minecraft:light_gray_concrete
setblock 370 207 235 minecraft:light_gray_concrete
setblock 370 207 237 minecraft:light_gray_concrete
setblock 370 207 242 minecraft:light_gray_concrete
setblock 370 207 244 minecraft:light_gray_concrete
setblock 370 207 249 minecraft:light_gray_concrete
setblock 370 207 251 minecraft:light_gray_concrete
setblock 370 207 256 minecraft:light_gray_concrete
setblock 370 207 258 minecraft:light_gray_concrete
setblock 370 207 263 minecraft:light_gray_concrete
fill 370 207 265 370 207 269 minecraft:light_gray_concrete
fill 370 207 270 370 249 270 minecraft:stone_bricks
fill 371 207 232 371 223 233 minecraft:stone_bricks
fill 371 207 235 371 264 235 minecraft:stone_bricks
fill 371 207 239 371 223 240 minecraft:stone_bricks
fill 371 207 246 371 280 247 minecraft:stone_bricks
setblock 371 207 250 minecraft:mossy_stone_bricks
fill 371 207 253 371 258 254 minecraft:stone_bricks
fill 371 207 260 371 238 261 minecraft:stone_bricks
setblock 371 207 264 minecraft:mossy_cobblestone
fill 371 207 265 371 280 265 minecraft:stone_bricks
setblock 329 208 256 minecraft:mossy_stone_bricks
fill 366 208 228 367 228 228 minecraft:stone_bricks
fill 367 208 251 367 259 251 minecraft:iron_block
fill 367 208 270 369 213 270 minecraft:stone_bricks
setblock 368 208 228 minecraft:light_gray_concrete
setblock 368 208 230 minecraft:light_gray_concrete
setblock 368 208 235 minecraft:light_gray_concrete
setblock 368 208 237 minecraft:light_gray_concrete
setblock 368 208 242 minecraft:light_gray_concrete
setblock 368 208 244 minecraft:light_gray_concrete
setblock 368 208 249 minecraft:light_gray_concrete
setblock 368 208 251 minecraft:light_gray_concrete
setblock 368 208 256 minecraft:light_gray_concrete
setblock 368 208 258 minecraft:light_gray_concrete
fill 368 208 263 368 208 269 minecraft:light_gray_concrete
fill 369 208 228 370 214 228 minecraft:stone_bricks
fill 371 208 250 371 280 250 minecraft:stone_bricks
fill 371 208 264 371 280 264 minecraft:stone_bricks
setblock 329 209 248 minecraft:cobblestone
fill 329 209 256 329 280 256 minecraft:stone_bricks
setblock 332 209 231 minecraft:light[level=15]
setblock 332 209 239 minecraft:light[level=15]
setblock 332 209 247 minecraft:light[level=15]
setblock 332 209 255 minecraft:light[level=15]
setblock 332 209 263 minecraft:light[level=15]
setblock 340 209 231 minecraft:light[level=15]
setblock 340 209 239 minecraft:light[level=15]
setblock 340 209 263 minecraft:light[level=15]
setblock 348 209 231 minecraft:light[level=15]
setblock 348 209 239 minecraft:light[level=15]
setblock 348 209 263 minecraft:light[level=15]
setblock 356 209 231 minecraft:light[level=15]
setblock 356 209 239 minecraft:light[level=15]
setblock 356 209 247 minecraft:light[level=15]
setblock 356 209 255 minecraft:light[level=15]
setblock 356 209 263 minecraft:light[level=15]
setblock 364 209 239 minecraft:light[level=15]
setblock 364 209 263 minecraft:light[level=15]
fill 368 209 228 368 235 228 minecraft:stone_bricks
fill 329 210 248 329 219 248 minecraft:stone_bricks
fill 344 210 259 345 211 259 minecraft:white_stained_glass
fill 365 210 251 366 259 251 minecraft:iron_block
fill 366 210 250 366 259 250 minecraft:iron_block
fill 366 210 252 366 259 252 minecraft:iron_block
setblock 371 210 231 minecraft:mossy_stone_bricks
setblock 333 211 270 minecraft:mossy_cobblestone
fill 371 211 231 371 233 231 minecraft:stone_bricks
setblock 329 212 233 minecraft:mossy_cobblestone
setblock 330 212 258 minecraft:lime_terracotta
fill 333 212 270 333 280 270 minecraft:stone_bricks
fill 340 212 248 352 213 249 minecraft:iron_block
setblock 343 212 228 minecraft:mossy_stone_bricks
setblock 355 212 229 minecraft:lime_concrete
fill 355 212 248 366 213 249 minecraft:iron_block
fill 362 212 230 362 212 232 minecraft:light_gray_concrete
fill 363 212 229 365 212 229 minecraft:light_gray_concrete
fill 363 212 233 365 212 233 minecraft:light_gray_concrete
setblock 365 212 250 minecraft:light_gray_concrete
setblock 365 212 252 minecraft:light_gray_concrete
fill 366 212 230 366 212 232 minecraft:light_gray_concrete
setblock 367 212 250 minecraft:light_gray_concrete
setblock 367 212 252 minecraft:light_gray_concrete
setblock 370 212 233 minecraft:lime_terracotta
setblock 371 212 241 minecraft:mossy_cobblestone
fill 329 213 233 329 234 233 minecraft:stone_bricks
setblock 330 213 230 minecraft:green_concrete
setblock 332 213 231 minecraft:light[level=12]
setblock 332 213 238 minecraft:light[level=12]
setblock 332 213 245 minecraft:light[level=12]
setblock 332 213 252 minecraft:light[level=12]
setblock 332 213 259 minecraft:light[level=12]
setblock 332 213 266 minecraft:light[level=12]
setblock 339 213 231 minecraft:light[level=12]
setblock 339 213 238 minecraft:light[level=12]
setblock 339 213 245 minecraft:light[level=12]
setblock 339 213 252 minecraft:light[level=12]
setblock 339 213 259 minecraft:light[level=12]
setblock 339 213 266 minecraft:light[level=12]
fill 343 213 228 343 280 228 minecraft:stone_bricks
setblock 346 213 231 minecraft:light[level=12]
setblock 346 213 238 minecraft:light[level=12]
setblock 346 213 245 minecraft:light[level=12]
setblock 346 213 252 minecraft:light[level=12]
setblock 346 213 259 minecraft:light[level=12]
setblock 346 213 266 minecraft:light[level=12]
setblock 347 213 270 minecraft:cobblestone
setblock 353 213 231 minecraft:light[level=12]
setblock 353 213 238 minecraft:light[level=12]
setblock 353 213 245 minecraft:light[level=12]
setblock 353 213 252 minecraft:light[level=12]
setblock 353 213 259 minecraft:light[level=12]
setblock 353 213 266 minecraft:light[level=12]
setblock 356 213 228 minecraft:mossy_cobblestone
setblock 360 213 231 minecraft:light[level=12]
setblock 360 213 238 minecraft:light[level=12]
setblock 360 213 245 minecraft:light[level=12]
setblock 360 213 252 minecraft:light[level=12]
setblock 360 213 259 minecraft:light[level=12]
setblock 360 213 266 minecraft:light[level=12]
setblock 367 213 231 minecraft:light[level=12]
setblock 367 213 238 minecraft:light[level=12]
setblock 367 213 245 minecraft:light[level=12]
setblock 367 213 252 minecraft:light[level=12]
setblock 367 213 259 minecraft:light[level=12]
setblock 367 213 266 minecraft:light[level=12]
fill 371 213 241 371 264 241 minecraft:stone_bricks
fill 331 214 248 331 214 250 minecraft:light_gray_concrete
fill 332 214 248 333 214 248 minecraft:light_gray_concrete
fill 332 214 250 333 214 250 minecraft:light_gray_concrete
setblock 332 214 270 minecraft:mossy_stone_bricks
setblock 333 214 249 minecraft:light_gray_concrete
setblock 341 214 228 minecraft:mossy_stone_bricks
setblock 345 214 270 minecraft:mossy_cobblestone
fill 347 214 270 347 275 270 minecraft:stone_bricks
setblock 350 214 270 minecraft:cobblestone
fill 356 214 228 356 280 228 minecraft:stone_bricks
setblock 367 214 270 minecraft:cobblestone
fill 368 214 270 369 280 270 minecraft:stone_bricks
setblock 371 214 266 minecraft:cobblestone
setblock 329 215 249 minecraft:mossy_cobblestone
fill 332 215 270 332 224 270 minecraft:stone_bricks
fill 341 215 228 341 229 228 minecraft:stone_bricks
fill 345 215 270 345 280 270 minecraft:stone_bricks
setblock 348 215 228 minecraft:mossy_cobblestone
fill 350 215 270 350 280 270 minecraft:stone_bricks
fill 367 215 270 367 280 270 minecraft:stone_bricks
fill 369 215 228 369 280 228 minecraft:stone_bricks
setblock 370 215 228 minecraft:cobblestone
setblock 370 215 258 minecraft:green_concrete
fill 371 215 266 371 280 266 minecraft:stone_bricks
fill 329 216 249 329 232 249 minecraft:stone_bricks
setblock 330 216 266 minecraft:lime_terracotta
setblock 332 216 231 minecraft:light[level=15]
setblock 332 216 239 minecraft:light[level=15]
setblock 332 216 247 minecraft:light[level=15]
setblock 332 216 255 minecraft:light[level=15]
setblock 332 216 263 minecraft:light[level=15]
setblock 340 216 231 minecraft:light[level=15]
setblock 340 216 239 minecraft:light[level=15]
setblock 340 216 247 minecraft:light[level=15]
setblock 340 216 255 minecraft:light[level=15]
setblock 340 216 263 minecraft:light[level=15]
fill 348 216 228 348 218 228 minecraft:stone_bricks
setblock 348 216 231 minecraft:light[level=15]
setblock 348 216 239 minecraft:light[level=15]
setblock 348 216 247 minecraft:light[level=15]
setblock 348 216 255 minecraft:light[level=15]
setblock 348 216 263 minecraft:light[level=15]
setblock 351 216 270 minecraft:mossy_cobblestone
setblock 353 216 228 minecraft:mossy_stone_bricks
setblock 356 216 231 minecraft:light[level=15]
setblock 356 216 239 minecraft:light[level=15]
setblock 356 216 247 minecraft:light[level=15]
setblock 356 216 255 minecraft:light[level=15]
setblock 356 216 263 minecraft:light[level=15]
setblock 364 216 239 minecraft:light[level=15]
setblock 364 216 247 minecraft:light[level=15]
setblock 364 216 255 minecraft:light[level=15]
setblock 364 216 263 minecraft:light[level=15]
fill 370 216 228 370 280 228 minecraft:stone_bricks
fill 351 217 270 351 230 270 minecraft:stone_bricks
fill 353 217 228 353 257 228 minecraft:stone_bricks
setblock 371 217 237 minecraft:mossy_stone_bricks
fill 362 218 230 362 218 232 minecraft:light_gray_concrete
fill 363 218 229 365 218 229 minecraft:light_gray_concrete
fill 363 218 233 365 218 233 minecraft:light_gray_concrete
setblock 365 218 250 minecraft:light_gray_concrete
setblock 365 218 252 minecraft:light_gray_concrete
fill 366 218 230 366 218 232 minecraft:light_gray_concrete
setblock 367 218 250 minecraft:light_gray_concrete
setblock 367 218 252 minecraft:light_gray_concrete
fill 371 218 237 371 234 237 minecraft:stone_bricks
setblock 332 219 231 minecraft:light[level=12]
setblock 332 219 238 minecraft:light[level=12]
setblock 332 219 245 minecraft:light[level=12]
setblock 332 219 252 minecraft:light[level=12]
setblock 332 219 259 minecraft:light[level=12]
setblock 332 219 266 minecraft:light[level=12]
setblock 339 219 231 minecraft:light[level=12]
setblock 339 219 238 minecraft:light[level=12]
setblock 339 219 245 minecraft:light[level=12]
setblock 339 219 252 minecraft:light[level=12]
setblock 339 219 259 minecraft:light[level=12]
setblock 339 219 266 minecraft:light[level=12]
setblock 346 219 231 minecraft:light[level=12]
setblock 346 219 238 minecraft:light[level=12]
setblock 346 219 245 minecraft:light[level=12]
setblock 346 219 252 minecraft:light[level=12]
setblock 346 219 259 minecraft:light[level=12]
setblock 346 219 266 minecraft:light[level=12]
setblock 346 219 270 minecraft:mossy_cobblestone
setblock 348 219 228 minecraft:mossy_stone_bricks
setblock 350 219 228 minecraft:mossy_stone_bricks
setblock 353 219 231 minecraft:light[level=12]
setblock 353 219 238 minecraft:light[level=12]
setblock 353 219 245 minecraft:light[level=12]
setblock 353 219 252 minecraft:light[level=12]
setblock 353 219 259 minecraft:light[level=12]
setblock 353 219 266 minecraft:light[level=12]
setblock 360 219 231 minecraft:light[level=12]
setblock 360 219 238 minecraft:light[level=12]
setblock 360 219 245 minecraft:light[level=12]
setblock 360 219 252 minecraft:light[level=12]
setblock 360 219 259 minecraft:light[level=12]
setblock 360 219 266 minecraft:light[level=12]
setblock 361 219 228 minecraft:cobblestone
fill 362 219 228 362 267 228 minecraft:stone_bricks
setblock 363 219 270 minecraft:cobblestone
setblock 367 219 231 minecraft:light[level=12]
setblock 367 219 238 minecraft:light[level=12]
setblock 367 219 245 minecraft:light[level=12]
setblock 367 219 252 minecraft:light[level=12]
setblock 367 219 259 minecraft:light[level=12]
setblock 367 219 266 minecraft:light[level=12]
setblock 371 219 249 minecraft:mossy_cobblestone
setblock 329 220 248 minecraft:mossy_cobblestone
fill 330 220 249 331 221 249 minecraft:iron_block
fill 346 220 270 346 280 270 minecraft:stone_bricks
fill 348 220 228 348 222 228 minecraft:stone_bricks
setblock 349 220 228 minecraft:mossy_stone_bricks
fill 350 220 228 350 230 228 minecraft:stone_bricks
fill 361 220 228 361 230 228 minecraft:stone_bricks
fill 361 220 255 361 221 255 minecraft:white_stained_glass
fill 363 220 270 363 223 270 minecraft:stone_bricks
fill 371 220 249 371 280 249 minecraft:stone_bricks
fill 329 221 248 329 279 248 minecraft:stone_bricks
setblock 333 221 249 minecraft:sea_lantern
fill 349 221 228 349 280 228 minecraft:stone_bricks
fill 331 222 248 331 222 250 minecraft:light_gray_concrete
fill 332 222 248 333 222 248 minecraft:light_gray_concrete
fill 332 222 250 333 222 250 minecraft:light_gray_concrete
setblock 333 222 249 minecraft:light_gray_concrete
setblock 332 223 231 minecraft:light[level=15]
setblock 332 223 239 minecraft:light[level=15]
setblock 332 223 247 minecraft:light[level=15]
setblock 332 223 255 minecraft:light[level=15]
setblock 332 223 263 minecraft:light[level=15]
setblock 340 223 231 minecraft:light[level=15]
setblock 340 223 239 minecraft:light[level=15]
setblock 340 223 247 minecraft:light[level=15]
setblock 340 223 255 minecraft:light[level=15]
setblock 340 223 263 minecraft:light[level=15]
setblock 348 223 228 minecraft:cobblestone
setblock 348 223 231 minecraft:light[level=15]
setblock 348 223 239 minecraft:light[level=15]
setblock 348 223 247 minecraft:light[level=15]
setblock 348 223 255 minecraft:light[level=15]
setblock 348 223 263 minecraft:light[level=15]
setblock 356 223 231 minecraft:light[level=15]
setblock 356 223 239 minecraft:light[level=15]
setblock 356 223 247 minecraft:light[level=15]
setblock 356 223 255 minecraft:light[level=15]
setblock 356 223 263 minecraft:light[level=15]
setblock 364 223 239 minecraft:light[level=15]
setblock 364 223 247 minecraft:light[level=15]
setblock 364 223 255 minecraft:light[level=15]
setblock 364 223 263 minecraft:light[level=15]
fill 348 224 228 348 263 228 minecraft:stone_bricks
setblock 360 224 270 minecraft:mossy_cobblestone
fill 362 224 230 362 224 232 minecraft:light_gray_concrete
fill 363 224 229 365 224 229 minecraft:light_gray_concrete
fill 363 224 233 365 224 233 minecraft:light_gray_concrete
setblock 363 224 270 minecraft:mossy_cobblestone
setblock 365 224 250 minecraft:light_gray_concrete
setblock 365 224 252 minecraft:light_gray_concrete
fill 366 224 230 366 224 232 minecraft:light_gray_concrete
setblock 367 224 250 minecraft:light_gray_concrete
setblock 367 224 252 minecraft:light_gray_concrete
setblock 371 224 232 minecraft:cobblestone
fill 371 224 233 371 268 233 minecraft:stone_bricks
fill 371 224 239 371 280 239 minecraft:stone_bricks
setblock 371 224 240 minecraft:mossy_cobblestone
setblock 329 225 264 minecraft:mossy_stone_bricks
setblock 330 225 244 minecraft:lime_concrete
setblock 332 225 231 minecraft:light[level=12]
setblock 332 225 238 minecraft:light[level=12]
setblock 332 225 245 minecraft:light[level=12]
setblock 332 225 252 minecraft:light[level=12]
setblock 332 225 259 minecraft:light[level=12]
setblock 332 225 266 minecraft:light[level=12]
setblock 332 225 270 minecraft:cobblestone
setblock 339 225 231 minecraft:light[level=12]
setblock 339 225 238 minecraft:light[level=12]
setblock 339 225 245 minecraft:light[level=12]
setblock 339 225 252 minecraft:light[level=12]
setblock 339 225 259 minecraft:light[level=12]
setblock 339 225 266 minecraft:light[level=12]
setblock 343 225 270 minecraft:mossy_stone_bricks
setblock 346 225 231 minecraft:light[level=12]
setblock 346 225 238 minecraft:light[level=12]
setblock 346 225 245 minecraft:light[level=12]
setblock 346 225 252 minecraft:light[level=12]
setblock 346 225 259 minecraft:light[level=12]
setblock 346 225 266 minecraft:light[level=12]
setblock 353 225 231 minecraft:light[level=12]
setblock 353 225 238 minecraft:light[level=12]
setblock 353 225 245 minecraft:light[level=12]
setblock 353 225 252 minecraft:light[level=12]
setblock 353 225 259 minecraft:light[level=12]
setblock 353 225 266 minecraft:light[level=12]
setblock 360 225 231 minecraft:light[level=12]
setblock 360 225 238 minecraft:light[level=12]
setblock 360 225 245 minecraft:light[level=12]
setblock 360 225 252 minecraft:light[level=12]
setblock 360 225 259 minecraft:light[level=12]
setblock 360 225 266 minecraft:light[level=12]
fill 360 225 270 360 248 270 minecraft:stone_bricks
fill 363 225 270 363 231 270 minecraft:stone_bricks
setblock 367 225 231 minecraft:light[level=12]
setblock 367 225 238 minecraft:light[level=12]
setblock 367 225 245 minecraft:light[level=12]
setblock 367 225 252 minecraft:light[level=12]
setblock 367 225 259 minecraft:light[level=12]
setblock 367 225 266 minecraft:light[level=12]
fill 371 225 232 371 233 232 minecraft:stone_bricks
fill 371 225 240 371 271 240 minecraft:stone_bricks
setblock 371 225 263 minecraft:mossy_cobblestone
fill 329 226 264 329 246 264 minecraft:stone_bricks
fill 332 226 270 332 280 270 minecraft:stone_bricks
fill 343 226 270 343 280 270 minecraft:stone_bricks
setblock 365 226 270 minecraft:cobblestone
fill 371 226 263 371 280 263 minecraft:stone_bricks
setblock 329 227 243 minecraft:mossy_cobblestone
fill 365 227 270 365 280 270 minecraft:stone_bricks
fill 329 228 243 329 280 243 minecraft:stone_bricks
setblock 329 228 265 minecraft:mossy_stone_bricks
setblock 370 228 264 minecraft:lime_concrete
setblock 329 229 262 minecraft:mossy_stone_bricks
fill 329 229 265 329 280 265 minecraft:stone_bricks
fill 366 229 228 366 254 228 minecraft:stone_bricks
setblock 367 229 228 minecraft:cobblestone
fill 329 230 262 329 280 262 minecraft:stone_bricks
setblock 330 230 259 minecraft:lime_terracotta
fill 331 230 248 331 230 250 minecraft:light_gray_concrete
setblock 332 230 231 minecraft:light[level=15]
setblock 332 230 239 minecraft:light[level=15]
setblock 332 230 247 minecraft:light[level=15]
fill 332 230 248 333 230 248 minecraft:light_gray_concrete
fill 332 230 250 333 230 250 minecraft:light_gray_concrete
setblock 332 230 255 minecraft:light[level=15]
setblock 332 230 263 minecraft:light[level=15]
setblock 333 230 249 minecraft:light_gray_concrete
setblock 340 230 231 minecraft:light[level=15]
setblock 340 230 239 minecraft:light[level=15]
setblock 340 230 247 minecraft:light[level=15]
setblock 340 230 255 minecraft:light[level=15]
setblock 340 230 263 minecraft:light[level=15]
setblock 341 230 228 minecraft:cobblestone
setblock 348 230 231 minecraft:light[level=15]
setblock 348 230 239 minecraft:light[level=15]
setblock 348 230 247 minecraft:light[level=15]
setblock 348 230 255 minecraft:light[level=15]
setblock 348 230 263 minecraft:light[level=15]
setblock 356 230 231 minecraft:light[level=15]
setblock 356 230 239 minecraft:light[level=15]
setblock 356 230 247 minecraft:light[level=15]
setblock 356 230 255 minecraft:light[level=15]
setblock 356 230 263 minecraft:light[level=15]
fill 362 230 230 362 230 232 minecraft:light_gray_concrete
fill 363 230 229 365 230 229 minecraft:light_gray_concrete
fill 363 230 233 365 230 233 minecraft:light_gray_concrete
setblock 364 230 239 minecraft:light[level=15]
setblock 364 230 247 minecraft:light[level=15]
setblock 364 230 255 minecraft:light[level=15]
setblock 364 230 263 minecraft:light[level=15]
setblock 365 230 250 minecraft:light_gray_concrete
setblock 365 230 252 minecraft:light_gray_concrete
fill 366 230 230 366 230 232 minecraft:light_gray_concrete
fill 367 230 228 367 280 228 minecraft:stone_bricks
setblock 367 230 250 minecraft:light_gray_concrete
setblock 367 230 252 minecraft:light_gray_concrete
setblock 332 231 231 minecraft:light[level=12]
setblock 332 231 238 minecraft:light[level=12]
setblock 332 231 245 minecraft:light[level=12]
setblock 332 231 252 minecraft:light[level=12]
setblock 332 231 259 minecraft:light[level=12]
setblock 332 231 266 minecraft:light[level=12]
setblock 339 231 231 minecraft:light[level=12]
setblock 339 231 238 minecraft:light[level=12]
setblock 339 231 245 minecraft:light[level=12]
setblock 339 231 252 minecraft:light[level=12]
setblock 339 231 259 minecraft:light[level=12]
setblock 339 231 266 minecraft:light[level=12]
fill 341 231 228 341 255 228 minecraft:stone_bricks
setblock 346 231 231 minecraft:light[level=12]
setblock 346 231 238 minecraft:light[level=12]
setblock 346 231 245 minecraft:light[level=12]
setblock 346 231 252 minecraft:light[level=12]
setblock 346 231 259 minecraft:light[level=12]
setblock 346 231 266 minecraft:light[level=12]
setblock 350 231 228 minecraft:mossy_cobblestone
setblock 351 231 270 minecraft:mossy_cobblestone
setblock 353 231 231 minecraft:light[level=12]
setblock 353 231 238 minecraft:light[level=12]
setblock 353 231 245 minecraft:light[level=12]
setblock 353 231 252 minecraft:light[level=12]
setblock 353 231 259 minecraft:light[level=12]
setblock 353 231 266 minecraft:light[level=12]
setblock 360 231 231 minecraft:light[level=12]
setblock 360 231 238 minecraft:light[level=12]
setblock 360 231 245 minecraft:light[level=12]
setblock 360 231 252 minecraft:light[level=12]
setblock 360 231 259 minecraft:light[level=12]
setblock 360 231 266 minecraft:light[level=12]
setblock 361 231 228 minecraft:mossy_stone_bricks
setblock 367 231 231 minecraft:light[level=12]
setblock 367 231 238 minecraft:light[level=12]
setblock 367 231 245 minecraft:light[level=12]
setblock 367 231 252 minecraft:light[level=12]
setblock 367 231 259 minecraft:light[level=12]
setblock 367 231 266 minecraft:light[level=12]
setblock 330 232 240 minecraft:lime_concrete
setblock 330 232 242 minecraft:lime_terracotta
setblock 335 232 229 minecraft:lime_terracotta
fill 350 232 228 350 270 228 minecraft:stone_bricks
fill 351 232 270 351 276 270 minecraft:stone_bricks
fill 355 232 241 355 233 241 minecraft:light_blue_stained_glass
fill 361 232 228 361 280 228 minecraft:stone_bricks
setblock 363 232 270 minecraft:cobblestone
setblock 365 232 228 minecraft:mossy_stone_bricks
setblock 371 232 268 minecraft:mossy_stone_bricks
setblock 329 233 249 minecraft:mossy_stone_bricks
setblock 329 233 254 minecraft:mossy_stone_bricks
fill 332 233 230 335 238 232 minecraft:gray_concrete
fill 339 233 230 342 238 232 minecraft:gray_concrete
fill 346 233 230 349 238 232 minecraft:gray_concrete
fill 353 233 230 356 238 232 minecraft:gray_concrete
fill 360 233 230 363 238 232 minecraft:gray_concrete
fill 363 233 270 363 280 270 minecraft:stone_bricks
fill 364 233 230 364 233 232 minecraft:iron_block
fill 365 233 228 365 280 228 minecraft:stone_bricks
fill 371 233 268 371 280 268 minecraft:stone_bricks
fill 329 234 230 330 237 232 minecraft:waxed_copper_block
fill 329 234 249 329 260 249 minecraft:stone_bricks
fill 329 234 254 329 265 254 minecraft:stone_bricks
fill 331 234 230 331 237 232 minecraft:gray_concrete
fill 332 234 229 335 237 229 minecraft:gray_concrete
fill 332 234 233 335 237 233 minecraft:gray_concrete
fill 336 234 230 336 237 232 minecraft:gray_concrete
fill 337 234 230 337 237 232 minecraft:waxed_copper_block
fill 338 234 230 338 237 232 minecraft:gray_concrete
fill 339 234 229 342 237 229 minecraft:gray_concrete
fill 339 234 233 342 237 233 minecraft:gray_concrete
fill 343 234 230 343 237 232 minecraft:gray_concrete
fill 344 234 230 344 237 232 minecraft:waxed_copper_block
fill 345 234 230 345 237 232 minecraft:gray_concrete
fill 346 234 229 349 237 229 minecraft:gray_concrete
fill 346 234 233 349 237 233 minecraft:gray_concrete
fill 350 234 230 350 237 232 minecraft:gray_concrete
fill 351 234 230 351 237 232 minecraft:waxed_copper_block
fill 352 234 230 352 237 232 minecraft:gray_concrete
fill 353 234 229 356 237 229 minecraft:gray_concrete
fill 353 234 233 356 237 233 minecraft:gray_concrete
fill 357 234 230 357 237 232 minecraft:gray_concrete
fill 358 234 230 358 237 232 minecraft:waxed_copper_block
fill 359 234 230 359 237 232 minecraft:gray_concrete
fill 360 234 229 363 237 229 minecraft:gray_concrete
fill 360 234 233 363 237 233 minecraft:gray_concrete
fill 364 234 230 364 237 232 minecraft:gray_concrete
setblock 365 234 229 minecraft:lime_concrete
fill 365 234 230 371 237 232 minecraft:waxed_copper_block
fill 329 235 229 330 236 229 minecraft:waxed_copper_block
fill 329 235 233 330 236 233 minecraft:waxed_copper_block
setblock 329 235 252 minecraft:mossy_stone_bricks
fill 331 235 229 331 236 229 minecraft:gray_concrete
fill 331 235 233 331 236 233 minecraft:gray_concrete
fill 336 235 229 336 236 229 minecraft:gray_concrete
fill 336 235 233 336 236 233 minecraft:gray_concrete
fill 337 235 229 337 236 229 minecraft:waxed_copper_block
fill 337 235 233 337 236 233 minecraft:waxed_copper_block
fill 338 235 229 338 236 229 minecraft:gray_concrete
fill 338 235 233 338 236 233 minecraft:gray_concrete
fill 343 235 229 343 236 229 minecraft:gray_concrete
fill 343 235 233 343 236 233 minecraft:gray_concrete
fill 344 235 229 344 236 229 minecraft:waxed_copper_block
fill 344 235 233 344 236 233 minecraft:waxed_copper_block
fill 345 235 229 345 236 229 minecraft:gray_concrete
fill 345 235 233 345 236 233 minecraft:gray_concrete
fill 350 235 229 350 236 229 minecraft:gray_concrete
fill 350 235 233 350 236 233 minecraft:gray_concrete
fill 351 235 229 351 236 229 minecraft:waxed_copper_block
fill 351 235 233 351 236 233 minecraft:waxed_copper_block
fill 352 235 229 352 236 229 minecraft:gray_concrete
fill 352 235 233 352 236 233 minecraft:gray_concrete
fill 357 235 229 357 236 229 minecraft:gray_concrete
fill 357 235 233 357 236 233 minecraft:gray_concrete
fill 358 235 229 358 236 229 minecraft:waxed_copper_block
fill 358 235 233 358 236 233 minecraft:waxed_copper_block
fill 359 235 229 359 236 229 minecraft:gray_concrete
fill 359 235 233 359 236 233 minecraft:gray_concrete
fill 364 235 229 364 236 229 minecraft:gray_concrete
fill 364 235 233 364 236 233 minecraft:gray_concrete
fill 365 235 229 370 236 229 minecraft:waxed_copper_block
fill 365 235 233 370 236 233 minecraft:waxed_copper_block
setblock 371 235 237 minecraft:mossy_stone_bricks
fill 329 236 252 329 237 252 minecraft:stone_bricks
setblock 331 236 228 minecraft:cobblestone
fill 363 236 243 363 237 243 minecraft:light_blue_stained_glass
setblock 365 236 250 minecraft:light_gray_concrete
setblock 365 236 252 minecraft:light_gray_concrete
setblock 367 236 250 minecraft:light_gray_concrete
setblock 367 236 252 minecraft:light_gray_concrete
setblock 368 236 228 minecraft:mossy_cobblestone
setblock 371 236 234 minecraft:mossy_stone_bricks
fill 371 236 237 371 280 237 minecraft:stone_bricks
setblock 371 236 269 minecraft:mossy_cobblestone
fill 329 237 229 329 241 229 minecraft:stone_bricks
fill 329 237 233 329 280 233 minecraft:stone_bricks
fill 331 237 228 331 248 228 minecraft:stone_bricks
setblock 332 237 238 minecraft:light[level=12]
setblock 332 237 239 minecraft:light[level=15]
setblock 332 237 245 minecraft:light[level=12]
setblock 332 237 247 minecraft:light[level=15]
setblock 332 237 252 minecraft:light[level=12]
setblock 332 237 255 minecraft:light[level=15]
setblock 332 237 259 minecraft:light[level=12]
setblock 332 237 263 minecraft:light[level=15]
setblock 332 237 266 minecraft:light[level=12]
setblock 339 237 238 minecraft:light[level=12]
setblock 339 237 245 minecraft:light[level=12]
setblock 339 237 252 minecraft:light[level=12]
setblock 339 237 259 minecraft:light[level=12]
setblock 339 237 266 minecraft:light[level=12]
setblock 340 237 239 minecraft:light[level=15]
setblock 340 237 247 minecraft:light[level=15]
setblock 340 237 255 minecraft:light[level=15]
setblock 340 237 263 minecraft:light[level=15]
setblock 345 237 228 minecraft:mossy_cobblestone
setblock 346 237 238 minecraft:light[level=12]
setblock 346 237 245 minecraft:light[level=12]
setblock 346 237 252 minecraft:light[level=12]
setblock 346 237 259 minecraft:light[level=12]
setblock 346 237 266 minecraft:light[level=12]
setblock 348 237 239 minecraft:light[level=15]
setblock 348 237 247 minecraft:light[level=15]
setblock 348 237 255 minecraft:light[level=15]
setblock 348 237 263 minecraft:light[level=15]
setblock 353 237 238 minecraft:light[level=12]
setblock 353 237 245 minecraft:light[level=12]
setblock 353 237 252 minecraft:light[level=12]
setblock 353 237 259 minecraft:light[level=12]
setblock 353 237 266 minecraft:light[level=12]
setblock 356 237 239 minecraft:light[level=15]
setblock 356 237 247 minecraft:light[level=15]
setblock 356 237 255 minecraft:light[level=15]
setblock 356 237 263 minecraft:light[level=15]
setblock 360 237 238 minecraft:light[level=12]
setblock 360 237 245 minecraft:light[level=12]
setblock 360 237 252 minecraft:light[level=12]
setblock 360 237 259 minecraft:light[level=12]
setblock 360 237 266 minecraft:light[level=12]
setblock 364 237 239 minecraft:light[level=15]
setblock 364 237 247 minecraft:light[level=15]
setblock 364 237 255 minecraft:light[level=15]
setblock 364 237 263 minecraft:light[level=15]
setblock 367 237 238 minecraft:light[level=12]
setblock 367 237 245 minecraft:light[level=12]
setblock 367 237 252 minecraft:light[level=12]
setblock 367 237 259 minecraft:light[level=12]
setblock 367 237 266 minecraft:light[level=12]
fill 368 237 228 368 247 228 minecraft:stone_bricks
fill 371 237 234 371 280 234 minecraft:stone_bricks
fill 371 237 269 371 280 269 minecraft:stone_bricks
fill 329 238 230 329 244 232 minecraft:stone_bricks
setblock 329 238 237 minecraft:mossy_stone_bricks
setblock 329 238 252 minecraft:mossy_stone_bricks
setblock 329 238 259 minecraft:mossy_stone_bricks
setblock 331 238 229 minecraft:lime_terracotta
fill 331 238 248 331 238 250 minecraft:light_gray_concrete
fill 332 238 248 333 238 248 minecraft:light_gray_concrete
fill 332 238 250 333 238 250 minecraft:light_gray_concrete
setblock 333 238 249 minecraft:light_gray_concrete
fill 345 238 228 345 280 228 minecraft:stone_bricks
setblock 346 238 228 minecraft:mossy_cobblestone
fill 364 238 230 365 259 232 minecraft:iron_block
fill 371 238 230 371 241 232 minecraft:stone_bricks
setblock 371 238 236 minecraft:cobblestone
setblock 371 238 242 minecraft:mossy_cobblestone
setblock 371 238 248 minecraft:cobblestone
setblock 371 238 258 minecraft:mossy_stone_bricks
fill 329 239 237 329 264 237 minecraft:stone_bricks
fill 329 239 252 329 280 252 minecraft:stone_bricks
fill 329 239 259 329 254 259 minecraft:stone_bricks
setblock 331 239 270 minecraft:cobblestone
fill 346 239 228 346 242 228 minecraft:stone_bricks
fill 363 239 229 363 240 232 minecraft:iron_block
fill 364 239 229 365 240 229 minecraft:iron_block
fill 371 239 236 371 267 236 minecraft:stone_bricks
fill 371 239 242 371 280 242 minecraft:stone_bricks
fill 371 239 248 371 280 248 minecraft:stone_bricks
fill 371 239 258 371 244 258 minecraft:stone_bricks
setblock 371 239 260 minecraft:mossy_cobblestone
fill 371 239 261 371 280 261 minecraft:stone_bricks
setblock 329 240 261 minecraft:mossy_cobblestone
fill 331 240 270 331 280 270 minecraft:stone_bricks
setblock 352 240 228 minecraft:cobblestone
setblock 364 240 233 minecraft:sea_lantern
fill 371 240 260 371 273 260 minecraft:stone_bricks
fill 329 241 261 329 280 261 minecraft:stone_bricks
fill 335 241 251 335 242 251 minecraft:light_blue_stained_glass
fill 352 241 228 352 267 228 minecraft:stone_bricks
fill 363 241 230 363 259 232 minecraft:iron_block
setblock 329 242 229 minecraft:mossy_stone_bricks
setblock 330 242 260 minecraft:lime_terracotta
setblock 355 242 228 minecraft:cobblestone
fill 362 242 230 362 242 232 minecraft:light_gray_concrete
fill 363 242 229 365 242 229 minecraft:light_gray_concrete
fill 363 242 233 365 242 233 minecraft:light_gray_concrete
setblock 365 242 250 minecraft:light_gray_concrete
setblock 365 242 252 minecraft:light_gray_concrete
fill 366 242 230 366 242 232 minecraft:light_gray_concrete
setblock 367 242 250 minecraft:light_gray_concrete
setblock 367 242 252 minecraft:light_gray_concrete
setblock 371 242 230 minecraft:mossy_cobblestone
fill 371 242 231 371 246 232 minecraft:stone_bricks
fill 329 243 229 329 280 229 minecraft:stone_bricks
setblock 332 243 231 minecraft:light[level=12]
setblock 332 243 238 minecraft:light[level=12]
setblock 332 243 245 minecraft:light[level=12]
setblock 332 243 252 minecraft:light[level=12]
setblock 332 243 259 minecraft:light[level=12]
setblock 332 243 266 minecraft:light[level=12]
setblock 339 243 231 minecraft:light[level=12]
setblock 339 243 238 minecraft:light[level=12]
setblock 339 243 245 minecraft:light[level=12]
setblock 339 243 252 minecraft:light[level=12]
setblock 339 243 259 minecraft:light[level=12]
setblock 339 243 266 minecraft:light[level=12]
setblock 344 243 270 minecraft:mossy_stone_bricks
setblock 346 243 228 minecraft:cobblestone
setblock 346 243 231 minecraft:light[level=12]
setblock 346 243 238 minecraft:light[level=12]
setblock 346 243 245 minecraft:light[level=12]
setblock 346 243 252 minecraft:light[level=12]
setblock 346 243 259 minecraft:light[level=12]
setblock 346 243 266 minecraft:light[level=12]
setblock 353 243 231 minecraft:light[level=12]
setblock 353 243 238 minecraft:light[level=12]
setblock 353 243 245 minecraft:light[level=12]
setblock 353 243 252 minecraft:light[level=12]
setblock 353 243 259 minecraft:light[level=12]
setblock 353 243 266 minecraft:light[level=12]
fill 355 243 228 355 280 228 minecraft:stone_bricks
setblock 360 243 231 minecraft:light[level=12]
setblock 360 243 238 minecraft:light[level=12]
setblock 360 243 245 minecraft:light[level=12]
setblock 360 243 252 minecraft:light[level=12]
setblock 360 243 259 minecraft:light[level=12]
setblock 360 243 266 minecraft:light[level=12]
setblock 361 243 270 minecraft:mossy_stone_bricks
setblock 367 243 231 minecraft:light[level=12]
setblock 367 243 238 minecraft:light[level=12]
setblock 367 243 245 minecraft:light[level=12]
setblock 367 243 252 minecraft:light[level=12]
setblock 367 243 259 minecraft:light[level=12]
setblock 367 243 266 minecraft:light[level=12]
fill 371 243 230 371 280 230 minecraft:stone_bricks
setblock 332 244 231 minecraft:light[level=15]
setblock 332 244 239 minecraft:light[level=15]
setblock 332 244 247 minecraft:light[level=15]
setblock 332 244 255 minecraft:light[level=15]
setblock 332 244 263 minecraft:light[level=15]
setblock 335 244 229 minecraft:green_concrete
setblock 340 244 231 minecraft:light[level=15]
setblock 340 244 239 minecraft:light[level=15]
setblock 340 244 247 minecraft:light[level=15]
setblock 340 244 255 minecraft:light[level=15]
setblock 340 244 263 minecraft:light[level=15]
fill 344 244 270 344 280 270 minecraft:stone_bricks
fill 346 244 228 346 247 228 minecraft:stone_bricks
setblock 348 244 231 minecraft:light[level=15]
setblock 348 244 239 minecraft:light[level=15]
setblock 348 244 247 minecraft:light[level=15]
setblock 348 244 255 minecraft:light[level=15]
setblock 348 244 263 minecraft:light[level=15]
setblock 348 244 270 minecraft:mossy_stone_bricks
setblock 356 244 231 minecraft:light[level=15]
setblock 356 244 239 minecraft:light[level=15]
setblock 356 244 247 minecraft:light[level=15]
setblock 356 244 255 minecraft:light[level=15]
setblock 356 244 263 minecraft:light[level=15]
fill 361 244 270 361 280 270 minecraft:stone_bricks
setblock 364 244 239 minecraft:light[level=15]
setblock 364 244 247 minecraft:light[level=15]
setblock 364 244 255 minecraft:light[level=15]
setblock 364 244 263 minecraft:light[level=15]
setblock 329 245 230 minecraft:mossy_stone_bricks
fill 329 245 231 329 245 232 minecraft:stone_bricks
fill 348 245 270 348 275 270 minecraft:stone_bricks
setblock 354 245 270 minecraft:cobblestone
setblock 371 245 258 minecraft:mossy_cobblestone
fill 329 246 230 329 268 231 minecraft:stone_bricks
setblock 329 246 232 minecraft:cobblestone
setblock 329 246 251 minecraft:mossy_cobblestone
fill 331 246 248 331 246 250 minecraft:light_gray_concrete
fill 332 246 248 333 246 248 minecraft:light_gray_concrete
fill 332 246 250 333 246 250 minecraft:light_gray_concrete
setblock 333 246 249 minecraft:light_gray_concrete
fill 354 246 270 354 280 270 minecraft:stone_bricks
fill 371 246 258 371 259 258 minecraft:stone_bricks
fill 329 247 232 329 270 232 minecraft:stone_bricks
fill 329 247 251 329 280 251 minecraft:stone_bricks
setblock 329 247 264 minecraft:mossy_cobblestone
setblock 348 247 229 minecraft:lime_terracotta
setblock 358 247 228 minecraft:cobblestone
setblock 370 247 235 minecraft:green_concrete
fill 371 247 231 371 261 231 minecraft:stone_bricks
setblock 371 247 232 minecraft:cobblestone
fill 329 248 264 329 278 264 minecraft:stone_bricks
setblock 346 248 228 minecraft:mossy_cobblestone
fill 358 248 228 358 280 228 minecraft:stone_bricks
fill 362 248 230 362 248 232 minecraft:light_gray_concrete
fill 363 248 229 365 248 229 minecraft:light_gray_concrete
fill 363 248 233 365 248 233 minecraft:light_gray_concrete
setblock 365 248 250 minecraft:light_gray_concrete
setblock 365 248 252 minecraft:light_gray_concrete
fill 366 248 230 366 248 232 minecraft:light_gray_concrete
setblock 367 248 250 minecraft:light_gray_concrete
setblock 367 248 252 minecraft:light_gray_concrete
setblock 368 248 228 minecraft:cobblestone
fill 371 248 232 371 250 232 minecraft:stone_bricks
setblock 331 249 228 minecraft:cobblestone
setblock 332 249 231 minecraft:light[level=12]
setblock 332 249 238 minecraft:light[level=12]
setblock 332 249 245 minecraft:light[level=12]
setblock 332 249 252 minecraft:light[level=12]
setblock 332 249 259 minecraft:light[level=12]
setblock 332 249 266 minecraft:light[level=12]
setblock 339 249 231 minecraft:light[level=12]
setblock 339 249 238 minecraft:light[level=12]
setblock 339 249 245 minecraft:light[level=12]
setblock 339 249 252 minecraft:light[level=12]
setblock 339 249 259 minecraft:light[level=12]
setblock 339 249 266 minecraft:light[level=12]
setblock 343 249 229 minecraft:green_concrete
fill 346 249 228 346 280 228 minecraft:stone_bricks
setblock 346 249 231 minecraft:light[level=12]
setblock 346 249 238 minecraft:light[level=12]
setblock 346 249 245 minecraft:light[level=12]
setblock 346 249 252 minecraft:light[level=12]
setblock 346 249 259 minecraft:light[level=12]
setblock 346 249 266 minecraft:light[level=12]
setblock 352 249 270 minecraft:mossy_cobblestone
setblock 353 249 231 minecraft:light[level=12]
setblock 353 249 238 minecraft:light[level=12]
setblock 353 249 245 minecraft:light[level=12]
setblock 353 249 252 minecraft:light[level=12]
setblock 353 249 259 minecraft:light[level=12]
setblock 353 249 266 minecraft:light[level=12]
setblock 360 249 231 minecraft:light[level=12]
setblock 360 249 238 minecraft:light[level=12]
setblock 360 249 245 minecraft:light[level=12]
setblock 360 249 252 minecraft:light[level=12]
setblock 360 249 259 minecraft:light[level=12]
setblock 360 249 266 minecraft:light[level=12]
setblock 360 249 270 minecraft:cobblestone
setblock 367 249 231 minecraft:light[level=12]
setblock 367 249 238 minecraft:light[level=12]
setblock 367 249 245 minecraft:light[level=12]
setblock 367 249 252 minecraft:light[level=12]
setblock 367 249 259 minecraft:light[level=12]
setblock 367 249 266 minecraft:light[level=12]
fill 368 249 228 368 280 228 minecraft:stone_bricks
setblock 329 250 255 minecraft:cobblestone
fill 331 250 228 331 280 228 minecraft:stone_bricks
fill 352 250 270 352 280 270 minecraft:stone_bricks
fill 360 250 270 360 280 270 minecraft:stone_bricks
setblock 364 250 269 minecraft:lime_terracotta
setblock 370 250 270 minecraft:mossy_cobblestone
fill 329 251 255 329 280 255 minecraft:stone_bricks
setblock 332 251 231 minecraft:light[level=15]
setblock 332 251 239 minecraft:light[level=15]
setblock 332 251 247 minecraft:light[level=15]
setblock 332 251 255 minecraft:light[level=15]
setblock 332 251 263 minecraft:light[level=15]
setblock 340 251 231 minecraft:light[level=15]
setblock 340 251 239 minecraft:light[level=15]
setblock 340 251 247 minecraft:light[level=15]
setblock 340 251 255 minecraft:light[level=15]
setblock 340 251 263 minecraft:light[level=15]
setblock 348 251 231 minecraft:light[level=15]
setblock 348 251 239 minecraft:light[level=15]
setblock 348 251 247 minecraft:light[level=15]
setblock 348 251 255 minecraft:light[level=15]
setblock 348 251 263 minecraft:light[level=15]
setblock 356 251 231 minecraft:light[level=15]
setblock 356 251 239 minecraft:light[level=15]
setblock 356 251 247 minecraft:light[level=15]
setblock 356 251 255 minecraft:light[level=15]
setblock 356 251 263 minecraft:light[level=15]
setblock 364 251 239 minecraft:light[level=15]
setblock 364 251 247 minecraft:light[level=15]
setblock 364 251 255 minecraft:light[level=15]
setblock 364 251 263 minecraft:light[level=15]
fill 370 251 270 370 280 270 minecraft:stone_bricks
setblock 371 251 232 minecraft:cobblestone
fill 371 252 232 371 254 232 minecraft:stone_bricks
setblock 363 253 228 minecraft:mossy_cobblestone
setblock 329 254 267 minecraft:cobblestone
fill 331 254 248 331 254 250 minecraft:light_gray_concrete
fill 332 254 248 333 254 248 minecraft:light_gray_concrete
fill 332 254 250 333 254 250 minecraft:light_gray_concrete
setblock 333 254 249 minecraft:light_gray_concrete
setblock 355 254 270 minecraft:mossy_cobblestone
fill 362 254 230 362 254 232 minecraft:light_gray_concrete
fill 363 254 228 363 280 228 minecraft:stone_bricks
fill 363 254 229 365 254 229 minecraft:light_gray_concrete
fill 363 254 233 365 254 233 minecraft:light_gray_concrete
setblock 365 254 250 minecraft:light_gray_concrete
setblock 365 254 252 minecraft:light_gray_concrete
fill 366 254 230 366 254 232 minecraft:light_gray_concrete
setblock 367 254 250 minecraft:light_gray_concrete
setblock 367 254 252 minecraft:light_gray_concrete
setblock 371 254 238 minecraft:mossy_cobblestone
setblock 329 255 259 minecraft:cobblestone
fill 329 255 267 329 280 267 minecraft:stone_bricks
setblock 332 255 231 minecraft:light[level=12]
setblock 332 255 238 minecraft:light[level=12]
setblock 332 255 245 minecraft:light[level=12]
setblock 332 255 252 minecraft:light[level=12]
setblock 332 255 259 minecraft:light[level=12]
setblock 332 255 266 minecraft:light[level=12]
setblock 339 255 231 minecraft:light[level=12]
setblock 339 255 238 minecraft:light[level=12]
setblock 339 255 245 minecraft:light[level=12]
setblock 339 255 252 minecraft:light[level=12]
setblock 339 255 259 minecraft:light[level=12]
setblock 339 255 266 minecraft:light[level=12]
setblock 346 255 231 minecraft:light[level=12]
setblock 346 255 238 minecraft:light[level=12]
setblock 346 255 245 minecraft:light[level=12]
setblock 346 255 252 minecraft:light[level=12]
setblock 346 255 259 minecraft:light[level=12]
setblock 346 255 266 minecraft:light[level=12]
setblock 353 255 231 minecraft:light[level=12]
setblock 353 255 238 minecraft:light[level=12]
setblock 353 255 252 minecraft:light[level=12]
setblock 353 255 259 minecraft:light[level=12]
setblock 353 255 266 minecraft:light[level=12]
fill 355 255 270 355 280 270 minecraft:stone_bricks
setblock 360 255 231 minecraft:light[level=12]
setblock 360 255 238 minecraft:light[level=12]
setblock 360 255 245 minecraft:light[level=12]
setblock 360 255 252 minecraft:light[level=12]
setblock 360 255 259 minecraft:light[level=12]
setblock 360 255 266 minecraft:light[level=12]
setblock 366 255 228 minecraft:mossy_cobblestone
setblock 367 255 231 minecraft:light[level=12]
setblock 367 255 238 minecraft:light[level=12]
setblock 367 255 245 minecraft:light[level=12]
setblock 367 255 252 minecraft:light[level=12]
setblock 367 255 259 minecraft:light[level=12]
setblock 367 255 266 minecraft:light[level=12]
setblock 371 255 232 minecraft:mossy_stone_bricks
fill 371 255 238 371 280 238 minecraft:stone_bricks
fill 329 256 259 329 280 259 minecraft:stone_bricks
setblock 341 256 228 minecraft:mossy_cobblestone
fill 366 256 228 366 280 228 minecraft:stone_bricks
fill 368 256 251 369 257 251 minecraft:iron_block
fill 371 256 232 371 272 232 minecraft:stone_bricks
fill 341 257 228 341 280 228 minecraft:stone_bricks
setblock 347 257 228 minecraft:mossy_stone_bricks
setblock 364 257 251 minecraft:sea_lantern
setblock 332 258 231 minecraft:light[level=15]
setblock 332 258 239 minecraft:light[level=15]
setblock 332 258 247 minecraft:light[level=15]
setblock 332 258 255 minecraft:light[level=15]
setblock 332 258 263 minecraft:light[level=15]
setblock 340 258 231 minecraft:light[level=15]
setblock 340 258 239 minecraft:light[level=15]
setblock 340 258 247 minecraft:light[level=15]
setblock 340 258 255 minecraft:light[level=15]
setblock 340 258 263 minecraft:light[level=15]
fill 347 258 228 347 261 228 minecraft:stone_bricks
setblock 348 258 231 minecraft:light[level=15]
setblock 348 258 239 minecraft:light[level=15]
setblock 348 258 247 minecraft:light[level=15]
setblock 348 258 255 minecraft:light[level=15]
setblock 348 258 263 minecraft:light[level=15]
setblock 353 258 228 minecraft:mossy_cobblestone
setblock 356 258 231 minecraft:light[level=15]
setblock 356 258 239 minecraft:light[level=15]
setblock 356 258 247 minecraft:light[level=15]
setblock 356 258 255 minecraft:light[level=15]
setblock 356 258 263 minecraft:light[level=15]
setblock 364 258 239 minecraft:light[level=15]
setblock 364 258 247 minecraft:light[level=15]
setblock 364 258 255 minecraft:light[level=15]
setblock 364 258 263 minecraft:light[level=15]
setblock 371 258 244 minecraft:cobblestone
fill 334 259 228 334 260 228 minecraft:mossy_stone_bricks
fill 353 259 228 353 280 228 minecraft:stone_bricks
setblock 370 259 234 minecraft:lime_terracotta
fill 371 259 244 371 274 244 minecraft:stone_bricks
fill 371 259 253 371 280 253 minecraft:stone_bricks
setblock 371 259 254 minecraft:mossy_cobblestone
fill 371 260 254 371 280 254 minecraft:stone_bricks
setblock 371 260 258 minecraft:cobblestone
setblock 329 261 249 minecraft:mossy_stone_bricks
setblock 332 261 231 minecraft:light[level=12]
setblock 332 261 238 minecraft:light[level=12]
setblock 332 261 245 minecraft:light[level=12]
setblock 332 261 252 minecraft:light[level=12]
setblock 332 261 259 minecraft:light[level=12]
setblock 332 261 266 minecraft:light[level=12]
setblock 333 261 229 minecraft:green_concrete
fill 334 261 228 334 280 228 minecraft:stone_bricks
setblock 339 261 231 minecraft:light[level=12]
setblock 339 261 238 minecraft:light[level=12]
setblock 339 261 245 minecraft:light[level=12]
setblock 339 261 252 minecraft:light[level=12]
setblock 339 261 259 minecraft:light[level=12]
setblock 339 261 266 minecraft:light[level=12]
setblock 346 261 231 minecraft:light[level=12]
setblock 346 261 238 minecraft:light[level=12]
setblock 346 261 245 minecraft:light[level=12]
setblock 346 261 252 minecraft:light[level=12]
setblock 346 261 259 minecraft:light[level=12]
setblock 346 261 266 minecraft:light[level=12]
setblock 353 261 231 minecraft:light[level=12]
setblock 353 261 238 minecraft:light[level=12]
setblock 353 261 252 minecraft:light[level=12]
setblock 353 261 259 minecraft:light[level=12]
setblock 353 261 266 minecraft:light[level=12]
setblock 360 261 231 minecraft:light[level=12]
setblock 360 261 238 minecraft:light[level=12]
setblock 360 261 245 minecraft:light[level=12]
setblock 360 261 252 minecraft:light[level=12]
setblock 360 261 259 minecraft:light[level=12]
setblock 360 261 266 minecraft:light[level=12]
setblock 367 261 231 minecraft:light[level=12]
setblock 367 261 238 minecraft:light[level=12]
setblock 367 261 245 minecraft:light[level=12]
setblock 367 261 252 minecraft:light[level=12]
setblock 367 261 259 minecraft:light[level=12]
setblock 367 261 266 minecraft:light[level=12]
fill 371 261 258 371 280 258 minecraft:stone_bricks
fill 329 262 249 329 280 249 minecraft:stone_bricks
setblock 347 262 228 minecraft:cobblestone
setblock 371 262 231 minecraft:mossy_cobblestone
setblock 336 263 269 minecraft:lime_concrete
fill 347 263 228 347 280 228 minecraft:stone_bricks
fill 371 263 231 371 280 231 minecraft:stone_bricks
setblock 348 264 228 minecraft:mossy_stone_bricks
setblock 370 264 246 minecraft:green_concrete
setblock 329 265 237 minecraft:cobblestone
fill 330 265 229 349 266 269 minecraft:white_concrete
fill 348 265 228 348 280 228 minecraft:stone_bricks
fill 350 265 229 350 266 244 minecraft:white_concrete
fill 350 265 248 350 266 269 minecraft:white_concrete
fill 351 265 229 351 266 243 minecraft:white_concrete
fill 351 265 249 351 266 269 minecraft:white_concrete
fill 352 265 229 370 266 242 minecraft:white_concrete
fill 352 265 250 370 266 269 minecraft:white_concrete
fill 355 265 243 370 266 243 minecraft:white_concrete
fill 355 265 249 370 266 249 minecraft:white_concrete
fill 356 265 244 370 266 244 minecraft:white_concrete
fill 356 265 248 370 266 248 minecraft:white_concrete
fill 357 265 245 370 266 247 minecraft:white_concrete
setblock 371 265 235 minecraft:mossy_cobblestone
setblock 371 265 241 minecraft:mossy_cobblestone
fill 329 266 237 329 280 237 minecraft:stone_bricks
setblock 329 266 254 minecraft:mossy_cobblestone
setblock 329 266 260 minecraft:cobblestone
setblock 353 266 270 minecraft:mossy_cobblestone
fill 371 266 235 371 280 235 minecraft:stone_bricks
fill 371 266 241 371 280 241 minecraft:stone_bricks
fill 329 267 254 329 280 254 minecraft:stone_bricks
fill 329 267 260 329 280 260 minecraft:stone_bricks
fill 330 267 229 343 267 269 minecraft:smooth_quartz
fill 344 267 229 344 267 246 minecraft:smooth_quartz
fill 344 267 247 344 267 252 minecraft:white_stained_glass
setblock 344 267 253 minecraft:blue_stained_glass
fill 344 267 254 344 267 269 minecraft:smooth_quartz
fill 345 267 229 345 267 244 minecraft:smooth_quartz
setblock 345 267 245 minecraft:white_stained_glass
fill 345 267 246 345 267 252 minecraft:light_blue_stained_glass
fill 345 267 253 345 267 254 minecraft:white_stained_glass
setblock 345 267 255 minecraft:blue_stained_glass
fill 345 267 256 345 267 269 minecraft:smooth_quartz
fill 346 267 229 347 267 243 minecraft:smooth_quartz
fill 346 267 244 347 267 246 minecraft:light_blue_stained_glass
fill 346 267 247 347 268 247 minecraft:white_stained_glass
fill 346 267 248 347 267 254 minecraft:light_blue_stained_glass
fill 346 267 255 346 267 256 minecraft:white_stained_glass
fill 346 267 257 347 267 269 minecraft:smooth_quartz
fill 347 267 255 350 267 255 minecraft:light_blue_stained_glass
setblock 347 267 256 minecraft:white_stained_glass
fill 348 267 229 350 267 242 minecraft:smooth_quartz
fill 348 267 243 348 267 245 minecraft:light_blue_stained_glass
fill 348 267 246 348 267 251 minecraft:blue_stained_glass
fill 348 267 252 348 267 254 minecraft:light_blue_stained_glass
fill 348 267 256 353 267 256 minecraft:light_blue_stained_glass
setblock 348 267 257 minecraft:white_stained_glass
fill 348 267 258 370 267 269 minecraft:smooth_quartz
setblock 349 267 243 minecraft:light_blue_stained_glass
fill 349 267 244 349 267 248 minecraft:white_concrete
setblock 349 267 249 minecraft:white_stained_glass
fill 349 267 250 349 267 253 minecraft:blue_stained_glass
setblock 349 267 254 minecraft:light_blue_stained_glass
fill 349 267 257 352 267 257 minecraft:light_blue_stained_glass
fill 350 267 243 350 267 244 minecraft:white_concrete
fill 350 267 248 350 267 249 minecraft:white_concrete
fill 350 267 250 350 267 251 minecraft:white_stained_glass
fill 350 267 252 350 267 254 minecraft:blue_stained_glass
fill 351 267 229 370 267 241 minecraft:smooth_quartz
fill 351 267 242 351 267 243 minecraft:white_concrete
fill 351 267 249 351 267 250 minecraft:white_concrete
fill 351 267 251 356 267 251 minecraft:light_blue_stained_glass
fill 351 267 252 352 267 252 minecraft:white_stained_glass
fill 351 267 253 351 267 255 minecraft:blue_stained_glass
fill 352 267 242 355 268 242 minecraft:white_concrete
fill 352 267 250 355 267 250 minecraft:white_concrete
fill 352 267 253 354 267 253 minecraft:white_stained_glass
fill 352 267 254 353 267 255 minecraft:blue_stained_glass
fill 353 267 252 356 267 252 minecraft:light_blue_stained_glass
setblock 353 267 257 minecraft:smooth_quartz
fill 353 267 270 353 275 270 minecraft:stone_bricks
fill 354 267 254 355 267 254 minecraft:white_stained_glass
fill 354 267 255 354 267 256 minecraft:blue_stained_glass
fill 354 267 257 354 268 257 minecraft:white_stained_glass
fill 355 267 243 356 269 243 minecraft:white_concrete
fill 355 267 249 356 267 249 minecraft:white_concrete
fill 355 267 253 356 267 253 minecraft:light_blue_stained_glass
setblock 355 267 255 minecraft:blue_stained_glass
fill 355 267 256 370 267 257 minecraft:smooth_quartz
fill 356 267 242 370 267 242 minecraft:smooth_quartz
fill 356 267 244 357 269 244 minecraft:white_concrete
fill 356 267 248 357 267 248 minecraft:white_concrete
setblock 356 267 250 minecraft:blue_stained_glass
fill 356 267 254 370 267 255 minecraft:smooth_quartz
fill 357 267 243 370 267 243 minecraft:smooth_quartz
fill 357 267 245 357 268 247 minecraft:white_concrete
fill 357 267 249 370 267 253 minecraft:smooth_quartz
fill 358 267 244 370 267 248 minecraft:smooth_quartz
setblock 329 268 268 minecraft:mossy_stone_bricks
fill 330 268 229 342 269 269 minecraft:white_concrete
setblock 336 268 228 minecraft:mossy_cobblestone
fill 343 268 229 343 268 248 minecraft:white_concrete
fill 343 268 252 343 268 269 minecraft:white_concrete
fill 344 268 229 344 268 245 minecraft:white_concrete
fill 344 268 255 344 268 269 minecraft:white_concrete
fill 345 268 229 345 268 244 minecraft:white_concrete
fill 345 268 256 345 268 269 minecraft:white_concrete
fill 346 268 229 346 268 243 minecraft:white_concrete
fill 346 268 257 346 268 269 minecraft:white_concrete
fill 347 268 229 348 268 242 minecraft:white_concrete
fill 347 268 258 348 268 269 minecraft:white_concrete
fill 349 268 229 370 269 241 minecraft:white_concrete
fill 349 268 259 370 269 269 minecraft:white_concrete
setblock 352 268 228 minecraft:cobblestone
fill 352 268 258 353 268 258 minecraft:white_concrete
setblock 353 268 257 minecraft:white_stained_glass
setblock 354 268 258 minecraft:white_stained_glass
fill 355 268 256 370 268 258 minecraft:white_concrete
fill 356 268 242 370 269 242 minecraft:white_concrete
fill 356 268 255 370 268 255 minecraft:white_concrete
fill 357 268 243 370 269 243 minecraft:white_concrete
fill 357 268 248 370 268 248 minecraft:white_concrete
fill 357 268 252 370 268 254 minecraft:white_concrete
fill 358 268 244 370 269 247 minecraft:white_concrete
fill 358 268 249 370 269 251 minecraft:white_concrete
setblock 362 268 228 minecraft:cobblestone
setblock 371 268 236 minecraft:cobblestone
fill 329 269 230 329 280 230 minecraft:stone_bricks
setblock 329 269 231 minecraft:mossy_stone_bricks
fill 329 269 268 329 273 268 minecraft:stone_bricks
fill 336 269 228 336 280 228 minecraft:stone_bricks
fill 343 269 229 343 269 246 minecraft:white_concrete
fill 343 269 254 343 269 269 minecraft:white_concrete
fill 344 269 229 344 269 244 minecraft:white_concrete
fill 344 269 256 344 269 269 minecraft:white_concrete
fill 345 269 229 345 269 243 minecraft:white_concrete
fill 345 269 257 345 269 269 minecraft:white_concrete
fill 346 269 229 347 269 242 minecraft:white_concrete
fill 346 269 258 347 269 269 minecraft:white_concrete
fill 348 269 229 348 269 241 minecraft:white_concrete
fill 348 269 259 348 269 269 minecraft:white_concrete
fill 352 269 228 352 280 228 minecraft:stone_bricks
fill 353 269 242 355 269 242 minecraft:white_concrete
fill 353 269 258 370 269 258 minecraft:white_concrete
fill 355 269 257 370 269 257 minecraft:white_concrete
fill 356 269 256 370 269 256 minecraft:white_concrete
fill 357 269 245 357 269 246 minecraft:white_concrete
fill 357 269 254 370 269 255 minecraft:white_concrete
fill 358 269 248 370 269 248 minecraft:white_concrete
fill 358 269 252 370 269 253 minecraft:white_concrete
fill 362 269 228 362 280 228 minecraft:stone_bricks
setblock 371 269 233 minecraft:mossy_stone_bricks
fill 371 269 236 371 280 236 minecraft:stone_bricks
fill 329 270 231 329 280 231 minecraft:stone_bricks
fill 330 270 229 342 270 269 minecraft:smooth_quartz
fill 343 270 229 343 270 245 minecraft:smooth_quartz
fill 343 270 255 343 270 269 minecraft:smooth_quartz
fill 344 270 229 344 270 243 minecraft:smooth_quartz
fill 344 270 257 344 270 269 minecraft:smooth_quartz
fill 345 270 229 346 270 242 minecraft:smooth_quartz
fill 345 270 258 346 270 269 minecraft:smooth_quartz
fill 347 270 229 348 270 241 minecraft:smooth_quartz
fill 347 270 259 348 270 269 minecraft:smooth_quartz
fill 349 270 229 370 270 240 minecraft:smooth_quartz
fill 349 270 260 370 270 269 minecraft:smooth_quartz
fill 352 270 241 370 270 241 minecraft:smooth_quartz
fill 352 270 259 370 270 259 minecraft:smooth_quartz
fill 354 270 242 370 270 242 minecraft:smooth_quartz
fill 354 270 258 370 270 258 minecraft:smooth_quartz
fill 356 270 243 370 270 243 minecraft:smooth_quartz
fill 356 270 257 370 270 257 minecraft:smooth_quartz
fill 357 270 244 370 270 245 minecraft:smooth_quartz
fill 357 270 255 370 270 256 minecraft:smooth_quartz
fill 358 270 246 370 270 254 minecraft:smooth_quartz
fill 371 270 233 371 280 233 minecraft:stone_bricks
setblock 329 271 232 minecraft:cobblestone
fill 330 271 229 341 272 269 minecraft:white_concrete
setblock 342 271 228 minecraft:cobblestone
fill 342 271 229 342 271 247 minecraft:white_concrete
fill 342 271 253 342 271 269 minecraft:white_concrete
fill 343 271 229 343 271 244 minecraft:white_concrete
fill 343 271 256 343 271 269 minecraft:white_concrete
fill 344 271 229 344 271 243 minecraft:white_concrete
fill 344 271 257 344 271 269 minecraft:white_concrete
fill 345 271 229 345 271 242 minecraft:white_concrete
fill 345 271 258 345 271 269 minecraft:white_concrete
fill 346 271 229 347 271 241 minecraft:white_concrete
fill 346 271 259 347 271 269 minecraft:white_concrete
fill 348 271 229 370 271 240 minecraft:white_concrete
fill 348 271 260 370 271 269 minecraft:white_concrete
setblock 350 271 228 minecraft:mossy_stone_bricks
fill 353 271 241 370 271 241 minecraft:white_concrete
fill 353 271 259 370 271 259 minecraft:white_concrete
fill 355 271 242 370 271 242 minecraft:white_concrete
fill 355 271 258 370 271 258 minecraft:white_concrete
fill 356 271 243 370 271 243 minecraft:white_concrete
fill 356 271 257 370 271 257 minecraft:white_concrete
fill 357 271 244 370 271 244 minecraft:white_concrete
fill 357 271 256 370 271 256 minecraft:white_concrete
fill 358 271 245 370 271 247 minecraft:white_concrete
fill 358 271 253 370 271 255 minecraft:white_concrete
fill 359 271 248 370 272 252 minecraft:white_concrete
setblock 371 271 229 minecraft:mossy_cobblestone
fill 329 272 232 329 280 232 minecraft:stone_bricks
setblock 329 272 236 minecraft:mossy_cobblestone
fill 342 272 228 342 280 228 minecraft:stone_bricks
fill 342 272 229 342 272 245 minecraft:white_concrete
fill 342 272 255 342 272 269 minecraft:white_concrete
fill 343 272 229 343 272 243 minecraft:white_concrete
fill 343 272 257 343 272 269 minecraft:white_concrete
fill 344 272 229 344 272 242 minecraft:white_concrete
fill 344 272 258 344 272 269 minecraft:white_concrete
fill 345 272 229 346 272 241 minecraft:white_concrete
fill 345 272 259 346 272 269 minecraft:white_concrete
fill 347 272 229 348 272 240 minecraft:white_concrete
fill 347 272 260 348 272 269 minecraft:white_concrete
setblock 348 272 247 minecraft:light[level=15]
setblock 348 272 255 minecraft:light[level=15]
fill 349 272 229 370 272 239 minecraft:white_concrete
fill 349 272 261 370 272 269 minecraft:white_concrete
fill 350 272 228 350 280 228 minecraft:stone_bricks
fill 352 272 240 370 272 240 minecraft:white_concrete
fill 352 272 260 370 272 260 minecraft:white_concrete
fill 354 272 241 370 272 241 minecraft:white_concrete
fill 354 272 259 370 272 259 minecraft:white_concrete
fill 356 272 242 370 272 242 minecraft:white_concrete
setblock 356 272 247 minecraft:light[level=15]
setblock 356 272 255 minecraft:light[level=15]
fill 356 272 258 370 272 258 minecraft:white_concrete
fill 357 272 243 370 272 243 minecraft:white_concrete
fill 357 272 257 370 272 257 minecraft:white_concrete
fill 358 272 244 370 272 245 minecraft:white_concrete
fill 358 272 255 370 272 256 minecraft:white_concrete
fill 359 272 246 370 272 247 minecraft:white_concrete
fill 359 272 253 370 272 254 minecraft:white_concrete
fill 371 272 229 371 280 229 minecraft:stone_bricks
setblock 371 272 240 minecraft:mossy_stone_bricks
fill 329 273 236 329 280 236 minecraft:stone_bricks
fill 330 273 229 340 273 269 minecraft:smooth_quartz
fill 341 273 229 341 273 247 minecraft:smooth_quartz
fill 341 273 253 341 273 269 minecraft:smooth_quartz
fill 342 273 229 342 273 244 minecraft:smooth_quartz
fill 342 273 256 342 273 269 minecraft:smooth_quartz
fill 343 273 229 343 273 243 minecraft:smooth_quartz
fill 343 273 257 343 273 269 minecraft:smooth_quartz
fill 344 273 229 345 273 241 minecraft:smooth_quartz
fill 344 273 259 345 273 269 minecraft:smooth_quartz
fill 346 273 229 347 273 240 minecraft:smooth_quartz
setblock 346 273 245 minecraft:light[level=12]
setblock 346 273 252 minecraft:light[level=12]
setblock 346 273 259 minecraft:light[level=12]
fill 346 273 260 347 273 269 minecraft:smooth_quartz
fill 348 273 229 370 273 239 minecraft:smooth_quartz
fill 348 273 261 370 273 269 minecraft:smooth_quartz
fill 353 273 240 370 273 240 minecraft:smooth_quartz
setblock 353 273 252 minecraft:light[level=12]
setblock 353 273 259 minecraft:light[level=12]
fill 353 273 260 370 273 260 minecraft:smooth_quartz
fill 355 273 241 370 273 241 minecraft:smooth_quartz
fill 355 273 259 370 273 259 minecraft:smooth_quartz
fill 357 273 242 370 273 243 minecraft:smooth_quartz
fill 357 273 257 370 273 258 minecraft:smooth_quartz
fill 358 273 244 370 273 244 minecraft:smooth_quartz
fill 358 273 256 370 273 256 minecraft:smooth_quartz
fill 359 273 245 370 273 247 minecraft:smooth_quartz
fill 359 273 253 370 273 255 minecraft:smooth_quartz
fill 360 273 248 370 273 252 minecraft:smooth_quartz
setblock 371 273 232 minecraft:mossy_stone_bricks
fill 371 273 240 371 280 240 minecraft:stone_bricks
setblock 329 274 268 minecraft:cobblestone
fill 330 274 229 340 274 269 minecraft:white_concrete
fill 341 274 229 341 274 246 minecraft:white_concrete
fill 341 274 254 341 274 269 minecraft:white_concrete
fill 342 274 229 342 275 243 minecraft:white_concrete
fill 342 274 257 342 275 269 minecraft:white_concrete
fill 343 274 229 343 274 242 minecraft:white_concrete
fill 343 274 258 343 274 269 minecraft:white_concrete
fill 344 274 229 344 274 241 minecraft:white_concrete
fill 344 274 259 344 274 269 minecraft:white_concrete
fill 345 274 229 345 275 240 minecraft:white_concrete
fill 345 274 260 345 275 269 minecraft:white_concrete
fill 346 274 229 349 274 239 minecraft:white_concrete
fill 346 274 261 349 274 269 minecraft:white_concrete
fill 350 274 229 370 275 238 minecraft:white_concrete
fill 350 274 262 370 275 269 minecraft:white_concrete
fill 351 274 239 370 274 239 minecraft:white_concrete
fill 351 274 261 370 274 261 minecraft:white_concrete
fill 355 274 240 370 275 240 minecraft:white_concrete
fill 355 274 260 370 275 260 minecraft:white_concrete
fill 356 274 241 370 274 241 minecraft:white_concrete
fill 356 274 259 370 274 259 minecraft:white_concrete
fill 357 274 242 370 274 242 minecraft:white_concrete
fill 357 274 258 370 274 258 minecraft:white_concrete
fill 358 274 243 370 275 243 minecraft:white_concrete
fill 358 274 257 370 275 257 minecraft:white_concrete
fill 359 274 244 370 274 246 minecraft:white_concrete
fill 359 274 254 370 274 256 minecraft:white_concrete
fill 360 274 247 370 274 253 minecraft:white_concrete
fill 371 274 232 371 280 232 minecraft:stone_bricks
setblock 371 274 260 minecraft:mossy_stone_bricks
setblock 329 275 268 minecraft:mossy_stone_bricks
fill 330 275 229 339 275 269 minecraft:white_concrete
fill 340 275 229 340 275 248 minecraft:white_concrete
fill 340 275 252 340 275 269 minecraft:white_concrete
fill 341 275 229 341 275 244 minecraft:white_concrete
fill 341 275 256 341 275 269 minecraft:white_concrete
fill 343 275 229 343 275 241 minecraft:white_concrete
fill 343 275 259 343 275 269 minecraft:white_concrete
fill 344 275 229 344 275 240 minecraft:white_concrete
fill 344 275 260 344 275 269 minecraft:white_concrete
fill 346 275 229 347 275 239 minecraft:white_concrete
fill 346 275 261 347 275 269 minecraft:white_concrete
fill 348 275 229 349 275 238 minecraft:white_concrete
fill 348 275 262 349 275 269 minecraft:white_concrete
fill 353 275 239 370 275 239 minecraft:white_concrete
fill 353 275 261 370 275 261 minecraft:white_concrete
fill 357 275 241 370 275 241 minecraft:white_concrete
fill 357 275 259 370 275 259 minecraft:white_concrete
fill 358 275 242 370 275 242 minecraft:white_concrete
fill 358 275 258 370 275 258 minecraft:white_concrete
fill 359 275 244 370 275 244 minecraft:white_concrete
fill 359 275 256 370 275 256 minecraft:white_concrete
fill 360 275 245 370 275 248 minecraft:white_concrete
fill 360 275 252 370 275 255 minecraft:white_concrete
fill 361 275 249 370 275 251 minecraft:white_concrete
setblock 371 275 244 minecraft:mossy_stone_bricks
fill 371 275 260 371 280 260 minecraft:stone_bricks
fill 329 276 268 329 280 268 minecraft:stone_bricks
fill 330 276 229 339 276 269 minecraft:smooth_quartz
fill 340 276 229 340 276 246 minecraft:smooth_quartz
fill 340 276 254 340 276 269 minecraft:smooth_quartz
fill 341 276 229 341 276 243 minecraft:smooth_quartz
fill 341 276 257 341 276 269 minecraft:smooth_quartz
fill 342 276 229 342 276 242 minecraft:smooth_quartz
fill 342 276 258 342 276 269 minecraft:smooth_quartz
fill 343 276 229 343 276 241 minecraft:smooth_quartz
fill 343 276 259 343 276 269 minecraft:smooth_quartz
fill 344 276 229 344 276 240 minecraft:smooth_quartz
fill 344 276 260 344 276 269 minecraft:smooth_quartz
fill 345 276 229 345 276 239 minecraft:smooth_quartz
fill 345 276 261 345 276 269 minecraft:smooth_quartz
fill 346 276 229 370 276 238 minecraft:smooth_quartz
fill 346 276 262 370 276 269 minecraft:smooth_quartz
setblock 347 276 270 minecraft:cobblestone
setblock 348 276 270 minecraft:mossy_cobblestone
setblock 353 276 270 minecraft:cobblestone
fill 355 276 239 370 276 239 minecraft:smooth_quartz
fill 355 276 261 370 276 261 minecraft:smooth_quartz
fill 356 276 240 370 276 240 minecraft:smooth_quartz
fill 356 276 260 370 276 260 minecraft:smooth_quartz
fill 357 276 241 370 276 241 minecraft:smooth_quartz
fill 357 276 259 370 276 259 minecraft:smooth_quartz
fill 358 276 242 370 276 242 minecraft:smooth_quartz
fill 358 276 258 370 276 258 minecraft:smooth_quartz
fill 359 276 243 370 276 243 minecraft:smooth_quartz
fill 359 276 257 370 276 257 minecraft:smooth_quartz
fill 360 276 244 370 276 246 minecraft:smooth_quartz
fill 360 276 254 370 276 256 minecraft:smooth_quartz
fill 361 276 247 370 276 253 minecraft:smooth_quartz
fill 371 276 244 371 280 244 minecraft:stone_bricks
fill 330 277 229 339 277 269 minecraft:white_concrete
fill 340 277 229 340 277 245 minecraft:white_concrete
fill 340 277 255 340 277 269 minecraft:white_concrete
fill 341 277 229 341 277 243 minecraft:white_concrete
fill 341 277 257 341 277 269 minecraft:white_concrete
fill 342 277 229 342 277 241 minecraft:white_concrete
fill 342 277 259 342 277 269 minecraft:white_concrete
fill 343 277 229 343 277 240 minecraft:white_concrete
fill 343 277 260 343 277 269 minecraft:white_concrete
fill 344 277 229 344 278 239 minecraft:white_concrete
fill 344 277 261 344 278 269 minecraft:white_concrete
fill 345 277 229 347 277 238 minecraft:white_concrete
fill 345 277 262 347 277 269 minecraft:white_concrete
fill 347 277 270 348 280 270 minecraft:stone_bricks
fill 348 277 229 370 278 237 minecraft:white_concrete
fill 348 277 263 370 278 269 minecraft:white_concrete
setblock 351 277 270 minecraft:mossy_stone_bricks
fill 353 277 238 370 277 238 minecraft:white_concrete
fill 353 277 262 370 277 262 minecraft:white_concrete
fill 353 277 270 353 280 270 minecraft:stone_bricks
fill 356 277 239 370 278 239 minecraft:white_concrete
fill 356 277 261 370 278 261 minecraft:white_concrete
fill 357 277 240 370 277 240 minecraft:white_concrete
fill 357 277 260 370 277 260 minecraft:white_concrete
fill 358 277 241 370 277 241 minecraft:white_concrete
fill 358 277 259 370 277 259 minecraft:white_concrete
fill 359 277 242 370 277 243 minecraft:white_concrete
fill 359 277 257 370 277 258 minecraft:white_concrete
fill 360 277 244 370 277 245 minecraft:white_concrete
fill 360 277 255 370 277 256 minecraft:white_concrete
fill 361 277 246 370 277 254 minecraft:white_concrete
fill 330 278 229 338 278 269 minecraft:white_concrete
fill 339 278 229 339 278 247 minecraft:white_concrete
fill 339 278 253 339 278 269 minecraft:white_concrete
fill 340 278 229 340 278 243 minecraft:white_concrete
fill 340 278 257 340 278 269 minecraft:white_concrete
fill 341 278 229 341 278 242 minecraft:white_concrete
fill 341 278 258 341 278 269 minecraft:white_concrete
fill 342 278 229 342 278 240 minecraft:white_concrete
fill 342 278 260 342 278 269 minecraft:white_concrete
fill 343 278 229 343 278 239 minecraft:white_concrete
fill 343 278 261 343 278 269 minecraft:white_concrete
fill 345 278 229 345 278 238 minecraft:white_concrete
fill 345 278 262 345 278 269 minecraft:white_concrete
fill 346 278 229 347 278 237 minecraft:white_concrete
fill 346 278 263 347 278 269 minecraft:white_concrete
fill 351 278 270 351 280 270 minecraft:stone_bricks
fill 355 278 238 370 278 238 minecraft:white_concrete
fill 355 278 262 370 278 262 minecraft:white_concrete
fill 358 278 240 370 278 240 minecraft:white_concrete
fill 358 278 260 370 278 260 minecraft:white_concrete
fill 359 278 241 370 278 242 minecraft:white_concrete
fill 359 278 258 370 278 259 minecraft:white_concrete
fill 360 278 243 370 278 243 minecraft:white_concrete
fill 360 278 257 370 278 257 minecraft:white_concrete
fill 361 278 244 370 278 247 minecraft:white_concrete
fill 361 278 253 370 278 256 minecraft:white_concrete
fill 362 278 248 370 278 252 minecraft:white_concrete
setblock 329 279 264 minecraft:mossy_stone_bricks
fill 330 279 229 338 279 269 minecraft:smooth_quartz
fill 339 279 229 339 279 245 minecraft:smooth_quartz
setblock 339 279 252 minecraft:light[level=12]
fill 339 279 255 339 279 269 minecraft:smooth_quartz
fill 340 279 229 340 279 243 minecraft:smooth_quartz
setblock 340 279 247 minecraft:light[level=15]
setblock 340 279 255 minecraft:light[level=15]
fill 340 279 257 340 279 269 minecraft:smooth_quartz
fill 341 279 229 341 279 241 minecraft:smooth_quartz
fill 341 279 259 341 279 269 minecraft:smooth_quartz
fill 342 279 229 342 279 240 minecraft:smooth_quartz
fill 342 279 260 342 279 269 minecraft:smooth_quartz
fill 343 279 229 343 279 239 minecraft:smooth_quartz
fill 343 279 261 343 279 269 minecraft:smooth_quartz
fill 344 279 229 344 279 238 minecraft:smooth_quartz
fill 344 279 262 344 279 269 minecraft:smooth_quartz
fill 345 279 229 347 279 237 minecraft:smooth_quartz
fill 345 279 263 347 279 269 minecraft:smooth_quartz
setblock 346 279 238 minecraft:light[level=12]
setblock 346 279 245 minecraft:light[level=12]
setblock 346 279 252 minecraft:light[level=12]
setblock 346 279 259 minecraft:light[level=12]
fill 348 279 229 370 279 236 minecraft:smooth_quartz
setblock 348 279 239 minecraft:light[level=15]
setblock 348 279 247 minecraft:light[level=15]
setblock 348 279 255 minecraft:light[level=15]
setblock 348 279 263 minecraft:light[level=15]
fill 348 279 264 370 279 269 minecraft:smooth_quartz
fill 353 279 237 370 279 237 minecraft:smooth_quartz
setblock 353 279 238 minecraft:light[level=12]
setblock 353 279 245 minecraft:light[level=12]
setblock 353 279 252 minecraft:light[level=12]
setblock 353 279 259 minecraft:light[level=12]
fill 353 279 263 370 279 263 minecraft:smooth_quartz
fill 356 279 238 370 279 238 minecraft:smooth_quartz
setblock 356 279 239 minecraft:light[level=15]
setblock 356 279 247 minecraft:light[level=15]
setblock 356 279 255 minecraft:light[level=15]
fill 356 279 262 370 279 262 minecraft:smooth_quartz
fill 357 279 239 370 279 239 minecraft:smooth_quartz
fill 357 279 261 370 279 261 minecraft:smooth_quartz
fill 358 279 240 370 279 240 minecraft:smooth_quartz
fill 358 279 260 370 279 260 minecraft:smooth_quartz
fill 359 279 241 370 279 241 minecraft:smooth_quartz
fill 359 279 259 370 279 259 minecraft:smooth_quartz
fill 360 279 242 370 279 243 minecraft:smooth_quartz
setblock 360 279 245 minecraft:light[level=12]
setblock 360 279 252 minecraft:light[level=12]
fill 360 279 257 370 279 258 minecraft:smooth_quartz
fill 361 279 244 370 279 245 minecraft:smooth_quartz
fill 361 279 255 370 279 256 minecraft:smooth_quartz
fill 362 279 246 370 279 254 minecraft:smooth_quartz
setblock 329 280 248 minecraft:mossy_cobblestone
setblock 329 280 264 minecraft:stone_bricks
fill 330 280 229 337 281 269 minecraft:white_concrete
fill 338 280 229 338 280 248 minecraft:white_concrete
fill 338 280 252 338 280 269 minecraft:white_concrete
fill 339 280 229 339 280 244 minecraft:white_concrete
fill 339 280 256 339 280 269 minecraft:white_concrete
fill 340 280 229 340 280 242 minecraft:white_concrete
fill 340 280 258 340 280 269 minecraft:white_concrete
fill 341 280 229 341 281 240 minecraft:white_concrete
fill 341 280 260 341 281 269 minecraft:white_concrete
fill 342 280 229 342 280 239 minecraft:white_concrete
fill 342 280 261 342 280 269 minecraft:white_concrete
fill 343 280 229 343 281 238 minecraft:white_concrete
fill 343 280 262 343 281 269 minecraft:white_concrete
fill 344 280 229 345 280 237 minecraft:white_concrete
fill 344 280 263 345 280 269 minecraft:white_concrete
fill 346 280 229 370 280 236 minecraft:white_concrete
fill 346 280 264 370 280 269 minecraft:white_concrete
fill 355 280 237 370 280 237 minecraft:white_concrete
fill 355 280 263 370 280 263 minecraft:white_concrete
fill 357 280 238 370 281 238 minecraft:white_concrete
fill 357 280 262 370 281 262 minecraft:white_concrete
fill 358 280 239 370 280 239 minecraft:white_concrete
fill 358 280 261 370 280 261 minecraft:white_concrete
fill 359 280 240 370 281 240 minecraft:white_concrete
fill 359 280 260 370 281 260 minecraft:white_concrete
fill 360 280 241 370 280 242 minecraft:white_concrete
fill 360 280 258 370 280 259 minecraft:white_concrete
fill 361 280 243 370 280 244 minecraft:white_concrete
fill 361 280 256 370 280 257 minecraft:white_concrete
fill 362 280 245 370 280 248 minecraft:white_concrete
fill 362 280 252 370 280 255 minecraft:white_concrete
fill 363 280 249 370 281 251 minecraft:white_concrete
fill 329 281 228 329 281 229 minecraft:light_blue_concrete
fill 329 281 230 329 281 231 minecraft:white_concrete
fill 329 281 232 329 281 233 minecraft:light_blue_concrete
fill 329 281 234 329 281 235 minecraft:white_concrete
fill 329 281 236 329 281 237 minecraft:light_blue_concrete
fill 329 281 238 329 281 239 minecraft:white_concrete
fill 329 281 240 329 281 241 minecraft:light_blue_concrete
fill 329 281 242 329 281 243 minecraft:white_concrete
fill 329 281 244 329 281 245 minecraft:light_blue_concrete
fill 329 281 246 329 281 247 minecraft:white_concrete
fill 329 281 248 329 281 249 minecraft:light_blue_concrete
fill 329 281 250 329 281 251 minecraft:white_concrete
fill 329 281 252 329 281 253 minecraft:light_blue_concrete
fill 329 281 254 329 281 255 minecraft:white_concrete
fill 329 281 256 329 281 257 minecraft:light_blue_concrete
fill 329 281 258 329 281 259 minecraft:white_concrete
fill 329 281 260 329 281 261 minecraft:light_blue_concrete
fill 329 281 262 329 281 263 minecraft:white_concrete
fill 329 281 264 329 281 265 minecraft:light_blue_concrete
fill 329 281 266 329 281 267 minecraft:white_concrete
fill 329 281 268 329 281 270 minecraft:light_blue_concrete
setblock 330 281 228 minecraft:light_blue_concrete
setblock 330 281 270 minecraft:light_blue_concrete
fill 331 281 228 332 281 228 minecraft:white_concrete
fill 331 281 270 332 281 270 minecraft:white_concrete
fill 333 281 228 334 281 228 minecraft:light_blue_concrete
fill 333 281 270 334 281 270 minecraft:light_blue_concrete
fill 335 281 228 336 281 228 minecraft:white_concrete
fill 335 281 270 336 281 270 minecraft:white_concrete
fill 337 281 228 338 281 228 minecraft:light_blue_concrete
fill 337 281 270 338 281 270 minecraft:light_blue_concrete
fill 338 281 229 338 281 245 minecraft:white_concrete
fill 338 281 255 338 281 269 minecraft:white_concrete
fill 339 281 228 339 281 243 minecraft:white_concrete
fill 339 281 257 339 281 270 minecraft:white_concrete
fill 340 281 228 340 281 241 minecraft:white_concrete
fill 340 281 259 340 281 270 minecraft:white_concrete
fill 341 281 228 342 281 228 minecraft:light_blue_concrete
fill 341 281 270 342 281 270 minecraft:light_blue_concrete
fill 342 281 229 342 281 238 minecraft:white_concrete
fill 342 281 262 342 281 269 minecraft:white_concrete
fill 343 281 228 344 281 228 minecraft:white_concrete
fill 343 281 270 344 281 270 minecraft:white_concrete
fill 344 281 229 344 281 237 minecraft:white_concrete
fill 344 281 263 344 281 269 minecraft:white_concrete
fill 345 281 228 346 281 228 minecraft:light_blue_concrete
fill 345 281 229 347 281 236 minecraft:white_concrete
fill 345 281 264 347 281 269 minecraft:white_concrete
fill 345 281 270 346 281 270 minecraft:light_blue_concrete
fill 347 281 228 348 281 228 minecraft:white_concrete
fill 347 281 270 348 281 270 minecraft:white_concrete
fill 348 281 229 370 281 235 minecraft:white_concrete
fill 348 281 265 370 281 269 minecraft:white_concrete
fill 349 281 228 350 281 228 minecraft:light_blue_concrete
fill 349 281 270 350 281 270 minecraft:light_blue_concrete
fill 351 281 228 352 281 228 minecraft:white_concrete
fill 351 281 270 352 281 270 minecraft:white_concrete
fill 353 281 228 354 281 228 minecraft:light_blue_concrete
fill 353 281 236 370 281 236 minecraft:white_concrete
fill 353 281 264 370 281 264 minecraft:white_concrete
fill 353 281 270 354 281 270 minecraft:light_blue_concrete
fill 355 281 228 356 281 228 minecraft:white_concrete
fill 355 281 270 356 281 270 minecraft:white_concrete
fill 356 281 237 370 281 237 minecraft:white_concrete
fill 356 281 263 371 281 263 minecraft:white_concrete
fill 357 281 228 358 281 228 minecraft:light_blue_concrete
fill 357 281 270 358 281 270 minecraft:light_blue_concrete
fill 359 281 228 360 281 228 minecraft:white_concrete
fill 359 281 239 371 281 239 minecraft:white_concrete
fill 359 281 261 370 281 261 minecraft:white_concrete
fill 359 281 270 360 281 270 minecraft:white_concrete
fill 360 281 241 370 281 241 minecraft:white_concrete
fill 360 281 259 371 281 259 minecraft:white_concrete
fill 361 281 228 362 281 228 minecraft:light_blue_concrete
fill 361 281 242 371 281 243 minecraft:white_concrete
fill 361 281 257 370 281 258 minecraft:white_concrete
fill 361 281 270 362 281 270 minecraft:light_blue_concrete
fill 362 281 244 370 281 245 minecraft:white_concrete
fill 362 281 255 370 281 256 minecraft:white_concrete
fill 363 281 228 364 281 228 minecraft:white_concrete
fill 363 281 246 370 281 248 minecraft:white_concrete
fill 363 281 252 370 281 254 minecraft:white_concrete
fill 363 281 270 364 281 270 minecraft:white_concrete
fill 365 281 228 366 281 228 minecraft:light_blue_concrete
fill 365 281 270 366 281 270 minecraft:light_blue_concrete
fill 367 281 228 368 281 228 minecraft:white_concrete
fill 367 281 270 368 281 270 minecraft:white_concrete
fill 369 281 228 371 281 228 minecraft:light_blue_concrete
fill 369 281 270 370 281 270 minecraft:light_blue_concrete
setblock 371 281 229 minecraft:light_blue_concrete
fill 371 281 230 371 281 231 minecraft:white_concrete
fill 371 281 232 371 281 233 minecraft:light_blue_concrete
fill 371 281 234 371 281 235 minecraft:white_concrete
fill 371 281 236 371 281 237 minecraft:light_blue_concrete
setblock 371 281 238 minecraft:white_concrete
fill 371 281 240 371 281 241 minecraft:light_blue_concrete
fill 371 281 244 371 281 245 minecraft:light_blue_concrete
fill 371 281 246 371 281 247 minecraft:white_concrete
fill 371 281 248 371 281 249 minecraft:light_blue_concrete
fill 371 281 250 371 281 251 minecraft:white_concrete
fill 371 281 252 371 281 253 minecraft:light_blue_concrete
fill 371 281 254 371 281 255 minecraft:white_concrete
fill 371 281 256 371 281 257 minecraft:light_blue_concrete
setblock 371 281 258 minecraft:white_concrete
fill 371 281 260 371 281 261 minecraft:light_blue_concrete
setblock 371 281 262 minecraft:white_concrete
fill 371 281 264 371 281 265 minecraft:light_blue_concrete
fill 371 281 266 371 281 267 minecraft:white_concrete
fill 371 281 268 371 281 269 minecraft:light_blue_concrete
setblock 371 281 270 minecraft:white_concrete
fill 329 282 228 329 283 229 minecraft:white_concrete
fill 329 282 230 329 283 231 minecraft:light_blue_concrete
fill 329 282 232 329 283 233 minecraft:white_concrete
fill 329 282 234 329 283 235 minecraft:light_blue_concrete
fill 329 282 236 329 283 237 minecraft:white_concrete
fill 329 282 238 329 283 239 minecraft:light_blue_concrete
fill 329 282 240 329 283 241 minecraft:white_concrete
fill 329 282 242 329 283 243 minecraft:light_blue_concrete
fill 329 282 244 329 283 245 minecraft:white_concrete
fill 329 282 246 329 283 247 minecraft:light_blue_concrete
fill 329 282 248 329 283 249 minecraft:white_concrete
fill 329 282 250 329 283 251 minecraft:light_blue_concrete
fill 329 282 252 329 283 253 minecraft:white_concrete
fill 329 282 254 329 283 255 minecraft:light_blue_concrete
fill 329 282 256 329 283 257 minecraft:white_concrete
fill 329 282 258 329 283 259 minecraft:light_blue_concrete
fill 329 282 260 329 283 261 minecraft:white_concrete
fill 329 282 262 329 283 263 minecraft:light_blue_concrete
fill 329 282 264 329 283 265 minecraft:white_concrete
fill 329 282 266 329 283 267 minecraft:light_blue_concrete
fill 329 282 268 329 283 269 minecraft:white_concrete
fill 329 282 270 329 308 270 minecraft:light_blue_concrete
fill 330 282 228 330 283 228 minecraft:white_concrete
fill 330 282 229 337 282 269 minecraft:smooth_quartz
fill 330 282 270 330 283 270 minecraft:white_concrete
fill 331 282 228 332 283 228 minecraft:light_blue_concrete
fill 331 282 270 332 283 270 minecraft:light_blue_concrete
fill 333 282 228 334 283 228 minecraft:white_concrete
fill 333 282 270 334 283 270 minecraft:white_concrete
fill 335 282 228 336 283 228 minecraft:light_blue_concrete
fill 335 282 270 336 283 270 minecraft:light_blue_concrete
fill 337 282 228 338 283 228 minecraft:white_concrete
fill 337 282 270 338 283 270 minecraft:white_concrete
fill 338 282 229 338 282 244 minecraft:smooth_quartz
fill 338 282 256 338 282 269 minecraft:smooth_quartz
fill 339 282 228 340 283 228 minecraft:light_blue_concrete
fill 339 282 229 339 282 242 minecraft:smooth_quartz
fill 339 282 258 339 282 269 minecraft:smooth_quartz
fill 339 282 270 340 283 270 minecraft:light_blue_concrete
fill 340 282 229 340 282 240 minecraft:smooth_quartz
fill 340 282 260 340 282 269 minecraft:smooth_quartz
fill 341 282 228 342 283 228 minecraft:white_concrete
fill 341 282 229 341 282 239 minecraft:smooth_quartz
fill 341 282 261 341 282 269 minecraft:smooth_quartz
fill 341 282 270 342 283 270 minecraft:white_concrete
fill 342 282 229 342 282 238 minecraft:smooth_quartz
fill 342 282 262 342 282 269 minecraft:smooth_quartz
fill 343 282 228 344 283 228 minecraft:light_blue_concrete
fill 343 282 229 343 282 237 minecraft:smooth_quartz
fill 343 282 263 343 282 269 minecraft:smooth_quartz
fill 343 282 270 344 283 270 minecraft:light_blue_concrete
fill 344 282 229 345 282 236 minecraft:smooth_quartz
fill 344 282 264 345 282 269 minecraft:smooth_quartz
fill 345 282 228 346 283 228 minecraft:white_concrete
fill 345 282 270 346 283 270 minecraft:white_concrete
fill 346 282 229 370 282 235 minecraft:smooth_quartz
fill 346 282 265 370 282 269 minecraft:smooth_quartz
fill 347 282 228 348 283 228 minecraft:light_blue_concrete
fill 347 282 270 348 283 270 minecraft:light_blue_concrete
fill 349 282 228 350 283 228 minecraft:white_concrete
fill 349 282 270 350 283 270 minecraft:white_concrete
fill 351 282 228 352 283 228 minecraft:light_blue_concrete
fill 351 282 270 352 283 270 minecraft:light_blue_concrete
fill 353 282 228 354 283 228 minecraft:white_concrete
fill 353 282 270 354 283 270 minecraft:white_concrete
fill 355 282 228 356 283 228 minecraft:light_blue_concrete
fill 355 282 236 370 282 236 minecraft:smooth_quartz
fill 355 282 264 370 282 264 minecraft:smooth_quartz
fill 355 282 270 356 283 270 minecraft:light_blue_concrete
fill 357 282 228 358 283 228 minecraft:white_concrete
fill 357 282 237 370 282 237 minecraft:smooth_quartz
fill 357 282 263 370 282 263 minecraft:smooth_quartz
fill 357 282 270 358 283 270 minecraft:white_concrete
fill 358 282 238 370 282 238 minecraft:smooth_quartz
fill 358 282 262 370 282 262 minecraft:smooth_quartz
fill 359 282 228 360 283 228 minecraft:light_blue_concrete
fill 359 282 239 370 282 239 minecraft:smooth_quartz
fill 359 282 261 370 282 261 minecraft:smooth_quartz
fill 359 282 270 360 283 270 minecraft:light_blue_concrete
fill 360 282 240 370 282 240 minecraft:smooth_quartz
fill 360 282 260 370 282 260 minecraft:smooth_quartz
fill 361 282 228 362 283 228 minecraft:white_concrete
fill 361 282 241 370 282 242 minecraft:smooth_quartz
fill 361 282 258 370 282 259 minecraft:smooth_quartz
fill 361 282 270 362 283 270 minecraft:white_concrete
fill 362 282 243 370 282 244 minecraft:smooth_quartz
fill 362 282 256 370 282 257 minecraft:smooth_quartz
fill 363 282 228 364 283 228 minecraft:light_blue_concrete
fill 363 282 245 370 282 255 minecraft:smooth_quartz
fill 363 282 270 364 283 270 minecraft:light_blue_concrete
fill 365 282 228 366 283 228 minecraft:white_concrete
fill 365 282 270 366 283 270 minecraft:white_concrete
fill 367 282 228 368 283 228 minecraft:light_blue_concrete
fill 367 282 270 368 283 270 minecraft:light_blue_concrete
fill 369 282 228 370 283 228 minecraft:white_concrete
fill 369 282 270 370 283 270 minecraft:white_concrete
fill 371 282 228 371 308 228 minecraft:light_blue_concrete
fill 371 282 229 371 283 229 minecraft:white_concrete
fill 371 282 230 371 283 231 minecraft:light_blue_concrete
fill 371 282 232 371 283 233 minecraft:white_concrete
fill 371 282 234 371 283 235 minecraft:light_blue_concrete
fill 371 282 236 371 283 237 minecraft:white_concrete
fill 371 282 238 371 283 239 minecraft:light_blue_concrete
fill 371 282 240 371 283 241 minecraft:white_concrete
fill 371 282 242 371 283 243 minecraft:light_blue_concrete
fill 371 282 244 371 283 245 minecraft:white_concrete
fill 371 282 246 371 283 247 minecraft:light_blue_concrete
fill 371 282 248 371 283 249 minecraft:white_concrete
fill 371 282 250 371 283 251 minecraft:light_blue_concrete
fill 371 282 252 371 283 253 minecraft:white_concrete
fill 371 282 254 371 283 255 minecraft:light_blue_concrete
fill 371 282 256 371 283 257 minecraft:white_concrete
fill 371 282 258 371 283 259 minecraft:light_blue_concrete
fill 371 282 260 371 283 261 minecraft:white_concrete
fill 371 282 262 371 283 263 minecraft:light_blue_concrete
fill 371 282 264 371 283 265 minecraft:white_concrete
fill 371 282 266 371 283 267 minecraft:light_blue_concrete
fill 371 282 268 371 283 269 minecraft:white_concrete
fill 371 282 270 371 283 270 minecraft:light_blue_concrete
fill 330 283 229 336 284 269 minecraft:white_concrete
fill 337 283 229 337 283 246 minecraft:white_concrete
fill 337 283 254 337 283 269 minecraft:white_concrete
fill 338 283 229 338 283 243 minecraft:white_concrete
fill 338 283 257 338 283 269 minecraft:white_concrete
fill 339 283 229 339 283 241 minecraft:white_concrete
fill 339 283 259 339 283 269 minecraft:white_concrete
fill 340 283 229 340 284 239 minecraft:white_concrete
fill 340 283 261 340 284 269 minecraft:white_concrete
fill 341 283 229 341 284 238 minecraft:white_concrete
fill 341 283 262 341 284 269 minecraft:white_concrete
fill 342 283 229 342 284 237 minecraft:white_concrete
fill 342 283 263 342 284 269 minecraft:white_concrete
fill 343 283 229 344 283 236 minecraft:white_concrete
fill 343 283 264 344 283 269 minecraft:white_concrete
fill 345 283 229 347 283 235 minecraft:white_concrete
fill 345 283 265 347 283 269 minecraft:white_concrete
fill 348 283 229 370 284 234 minecraft:white_concrete
fill 348 283 266 370 284 269 minecraft:white_concrete
fill 353 283 235 370 283 235 minecraft:white_concrete
fill 353 283 265 370 283 265 minecraft:white_concrete
fill 356 283 236 370 283 236 minecraft:white_concrete
fill 356 283 264 370 283 264 minecraft:white_concrete
fill 358 283 237 370 284 237 minecraft:white_concrete
fill 358 283 263 370 284 263 minecraft:white_concrete
fill 359 283 238 370 284 238 minecraft:white_concrete
fill 359 283 262 370 284 262 minecraft:white_concrete
fill 360 283 239 370 284 239 minecraft:white_concrete
fill 360 283 261 370 284 261 minecraft:white_concrete
fill 361 283 240 370 283 241 minecraft:white_concrete
fill 361 283 259 370 283 260 minecraft:white_concrete
fill 362 283 242 370 283 243 minecraft:white_concrete
fill 362 283 257 370 283 258 minecraft:white_concrete
fill 363 283 244 370 283 246 minecraft:white_concrete
fill 363 283 254 370 283 256 minecraft:white_concrete
fill 364 283 247 370 284 253 minecraft:white_concrete
fill 329 284 228 329 285 229 minecraft:light_blue_concrete
fill 329 284 230 329 285 231 minecraft:white_concrete
fill 329 284 232 329 285 233 minecraft:light_blue_concrete
fill 329 284 234 329 285 235 minecraft:white_concrete
fill 329 284 236 329 285 237 minecraft:light_blue_concrete
fill 329 284 238 329 285 239 minecraft:white_concrete
fill 329 284 240 329 285 241 minecraft:light_blue_concrete
fill 329 284 242 329 285 243 minecraft:white_concrete
fill 329 284 244 329 285 245 minecraft:light_blue_concrete
fill 329 284 246 329 285 247 minecraft:white_concrete
fill 329 284 248 329 285 249 minecraft:light_blue_concrete
fill 329 284 250 329 285 251 minecraft:white_concrete
fill 329 284 252 329 285 253 minecraft:light_blue_concrete
fill 329 284 254 329 285 255 minecraft:white_concrete
fill 329 284 256 329 285 257 minecraft:light_blue_concrete
fill 329 284 258 329 285 259 minecraft:white_concrete
fill 329 284 260 329 285 261 minecraft:light_blue_concrete
fill 329 284 262 329 285 263 minecraft:white_concrete
fill 329 284 264 329 285 265 minecraft:light_blue_concrete
fill 329 284 266 329 285 267 minecraft:white_concrete
fill 329 284 268 329 285 269 minecraft:light_blue_concrete
fill 330 284 228 330 285 228 minecraft:light_blue_concrete
fill 330 284 270 330 285 270 minecraft:light_blue_concrete
fill 331 284 228 332 285 228 minecraft:white_concrete
fill 331 284 270 332 285 270 minecraft:white_concrete
fill 333 284 228 334 285 228 minecraft:light_blue_concrete
fill 333 284 270 334 285 270 minecraft:light_blue_concrete
fill 335 284 228 336 285 228 minecraft:white_concrete
fill 335 284 270 336 285 270 minecraft:white_concrete
fill 337 284 228 338 285 228 minecraft:light_blue_concrete
fill 337 284 229 337 284 244 minecraft:white_concrete
setblock 337 284 250 minecraft:sea_lantern
fill 337 284 256 337 284 269 minecraft:white_concrete
fill 337 284 270 338 285 270 minecraft:light_blue_concrete
fill 338 284 229 338 284 242 minecraft:white_concrete
fill 338 284 258 338 284 269 minecraft:white_concrete
fill 339 284 228 339 284 240 minecraft:white_concrete
fill 339 284 260 339 284 270 minecraft:white_concrete
fill 340 284 228 340 285 228 minecraft:white_concrete
fill 340 284 270 340 285 270 minecraft:white_concrete
fill 341 284 228 342 285 228 minecraft:light_blue_concrete
fill 341 284 270 342 285 270 minecraft:light_blue_concrete
fill 343 284 228 343 284 236 minecraft:white_concrete
setblock 343 284 262 minecraft:sea_lantern
fill 343 284 264 343 284 270 minecraft:white_concrete
fill 344 284 228 344 284 235 minecraft:white_concrete
fill 344 284 265 344 284 270 minecraft:white_concrete
fill 345 284 228 346 285 228 minecraft:light_blue_concrete
fill 345 284 229 345 284 235 minecraft:white_concrete
setblock 345 284 236 minecraft:sea_lantern
fill 345 284 265 345 284 269 minecraft:white_concrete
fill 345 284 270 346 285 270 minecraft:light_blue_concrete
fill 346 284 229 347 284 234 minecraft:white_concrete
fill 346 284 266 347 284 269 minecraft:white_concrete
fill 347 284 228 348 285 228 minecraft:white_concrete
fill 347 284 270 348 285 270 minecraft:white_concrete
fill 349 284 228 350 285 228 minecraft:light_blue_concrete
setblock 349 284 262 minecraft:sea_lantern
fill 349 284 270 350 285 270 minecraft:light_blue_concrete
fill 351 284 228 352 285 228 minecraft:white_concrete
setblock 351 284 236 minecraft:sea_lantern
fill 351 284 270 352 285 270 minecraft:white_concrete
fill 353 284 228 354 285 228 minecraft:light_blue_concrete
fill 353 284 270 354 285 270 minecraft:light_blue_concrete
fill 355 284 228 356 285 228 minecraft:white_concrete
fill 355 284 235 371 284 235 minecraft:white_concrete
setblock 355 284 262 minecraft:sea_lantern
fill 355 284 265 370 284 265 minecraft:white_concrete
fill 355 284 270 356 285 270 minecraft:white_concrete
fill 357 284 228 358 285 228 minecraft:light_blue_concrete
fill 357 284 236 370 284 236 minecraft:white_concrete
fill 357 284 264 370 284 264 minecraft:white_concrete
fill 357 284 270 358 285 270 minecraft:light_blue_concrete
fill 359 284 228 360 285 228 minecraft:white_concrete
fill 359 284 270 360 285 270 minecraft:white_concrete
fill 361 284 228 362 285 228 minecraft:light_blue_concrete
fill 361 284 240 370 284 240 minecraft:white_concrete
fill 361 284 260 370 284 260 minecraft:white_concrete
fill 361 284 270 362 285 270 minecraft:light_blue_concrete
fill 362 284 241 370 284 242 minecraft:white_concrete
fill 362 284 258 371 284 259 minecraft:white_concrete
fill 363 284 228 364 285 228 minecraft:white_concrete
fill 363 284 243 370 284 244 minecraft:white_concrete
setblock 363 284 248 minecraft:sea_lantern
setblock 363 284 254 minecraft:sea_lantern
fill 363 284 256 370 284 257 minecraft:white_concrete
fill 363 284 270 364 285 270 minecraft:white_concrete
fill 364 284 245 370 284 246 minecraft:white_concrete
fill 364 284 254 371 284 255 minecraft:white_concrete
fill 365 284 228 366 285 228 minecraft:light_blue_concrete
fill 365 284 270 366 285 270 minecraft:light_blue_concrete
fill 367 284 228 368 285 228 minecraft:white_concrete
fill 367 284 270 368 285 270 minecraft:white_concrete
fill 369 284 228 370 285 228 minecraft:light_blue_concrete
fill 369 284 270 370 285 270 minecraft:light_blue_concrete
fill 371 284 229 371 285 229 minecraft:light_blue_concrete
fill 371 284 230 371 285 231 minecraft:white_concrete
fill 371 284 232 371 285 233 minecraft:light_blue_concrete
fill 371 284 234 371 285 234 minecraft:white_concrete
fill 371 284 236 371 285 237 minecraft:light_blue_concrete
fill 371 284 238 371 285 239 minecraft:white_concrete
fill 371 284 240 371 285 241 minecraft:light_blue_concrete
fill 371 284 242 371 285 243 minecraft:white_concrete
fill 371 284 244 371 285 245 minecraft:light_blue_concrete
fill 371 284 246 371 285 247 minecraft:white_concrete
fill 371 284 248 371 285 249 minecraft:light_blue_concrete
fill 371 284 250 371 285 251 minecraft:white_concrete
fill 371 284 252 371 285 253 minecraft:light_blue_concrete
fill 371 284 256 371 285 257 minecraft:light_blue_concrete
fill 371 284 260 371 285 261 minecraft:light_blue_concrete
fill 371 284 262 371 285 263 minecraft:white_concrete
fill 371 284 264 371 285 265 minecraft:light_blue_concrete
fill 371 284 266 371 285 267 minecraft:white_concrete
fill 371 284 268 371 285 269 minecraft:light_blue_concrete
fill 371 284 270 371 285 270 minecraft:white_concrete
setblock 330 285 229 minecraft:light_gray_concrete
fill 330 285 231 330 285 232 minecraft:light_gray_concrete
fill 330 285 234 330 285 235 minecraft:light_gray_concrete
fill 330 285 237 330 285 238 minecraft:light_gray_concrete
fill 330 285 240 330 285 241 minecraft:light_gray_concrete
fill 330 285 243 330 285 244 minecraft:light_gray_concrete
fill 330 285 246 330 285 247 minecraft:light_gray_concrete
fill 330 285 249 330 285 250 minecraft:light_gray_concrete
fill 330 285 252 330 285 253 minecraft:light_gray_concrete
fill 330 285 255 330 285 256 minecraft:light_gray_concrete
fill 330 285 258 330 285 259 minecraft:light_gray_concrete
fill 330 285 261 330 285 262 minecraft:light_gray_concrete
fill 330 285 264 330 285 265 minecraft:light_gray_concrete
fill 330 285 267 330 285 268 minecraft:light_gray_concrete
fill 331 285 230 331 285 231 minecraft:light_gray_concrete
fill 331 285 233 331 285 234 minecraft:light_gray_concrete
fill 331 285 236 331 285 237 minecraft:light_gray_concrete
fill 331 285 239 331 285 240 minecraft:light_gray_concrete
fill 331 285 242 331 285 243 minecraft:light_gray_concrete
fill 331 285 245 331 285 246 minecraft:light_gray_concrete
fill 331 285 248 331 285 249 minecraft:light_gray_concrete
fill 331 285 251 331 285 252 minecraft:light_gray_concrete
fill 331 285 254 331 285 255 minecraft:light_gray_concrete
fill 331 285 257 331 285 258 minecraft:light_gray_concrete
fill 331 285 260 331 285 261 minecraft:light_gray_concrete
fill 331 285 263 331 285 264 minecraft:light_gray_concrete
fill 331 285 266 331 285 267 minecraft:light_gray_concrete
fill 331 285 269 332 285 269 minecraft:light_gray_concrete
fill 332 285 229 332 285 230 minecraft:light_gray_concrete
setblock 332 285 231 minecraft:light[level=12]
fill 332 285 232 332 285 233 minecraft:light_gray_concrete
fill 332 285 235 332 285 236 minecraft:light_gray_concrete
fill 332 285 238 332 285 239 minecraft:light_gray_concrete
fill 332 285 241 332 285 242 minecraft:light_gray_concrete
fill 332 285 244 332 285 245 minecraft:light_gray_concrete
fill 332 285 247 332 285 248 minecraft:light_gray_concrete
fill 332 285 250 332 285 251 minecraft:light_gray_concrete
setblock 332 285 252 minecraft:light[level=12]
fill 332 285 253 332 285 254 minecraft:light_gray_concrete
fill 332 285 256 332 285 257 minecraft:light_gray_concrete
fill 332 285 259 332 285 260 minecraft:light_gray_concrete
fill 332 285 262 332 285 263 minecraft:light_gray_concrete
fill 332 285 265 332 285 266 minecraft:light_gray_concrete
fill 332 285 268 333 285 268 minecraft:light_gray_concrete
setblock 333 285 229 minecraft:light_gray_concrete
fill 333 285 231 333 285 232 minecraft:light_gray_concrete
fill 333 285 234 333 285 235 minecraft:light_gray_concrete
fill 333 285 237 333 285 238 minecraft:light_gray_concrete
fill 333 285 240 333 285 241 minecraft:light_gray_concrete
fill 333 285 243 339 285 244 minecraft:light_gray_concrete
fill 333 285 246 338 285 247 minecraft:light_gray_concrete
fill 333 285 249 337 285 250 minecraft:light_gray_concrete
fill 333 285 252 338 285 253 minecraft:light_gray_concrete
fill 333 285 255 338 285 256 minecraft:light_gray_concrete
fill 333 285 258 333 285 259 minecraft:light_gray_concrete
fill 333 285 261 333 285 262 minecraft:light_gray_concrete
fill 333 285 264 333 285 265 minecraft:light_gray_concrete
fill 333 285 267 334 285 267 minecraft:light_gray_concrete
fill 334 285 229 341 299 233 minecraft:white_concrete
setblock 334 285 234 minecraft:light_gray_concrete
fill 334 285 236 334 285 237 minecraft:light_gray_concrete
fill 334 285 239 334 285 240 minecraft:light_gray_concrete
fill 334 285 242 340 285 242 minecraft:light_gray_concrete
fill 334 285 245 338 285 245 minecraft:light_gray_concrete
fill 334 285 248 338 285 248 minecraft:light_gray_concrete
fill 334 285 251 337 285 251 minecraft:light_gray_concrete
fill 334 285 254 338 285 254 minecraft:light_gray_concrete
fill 334 285 257 339 285 258 minecraft:light_gray_concrete
fill 334 285 260 334 285 261 minecraft:light_gray_concrete
fill 334 285 263 334 285 264 minecraft:light_gray_concrete
fill 334 285 266 335 285 266 minecraft:light_gray_concrete
fill 334 285 269 335 285 269 minecraft:light_gray_concrete
fill 335 285 235 335 285 236 minecraft:light_gray_concrete
fill 335 285 238 335 285 239 minecraft:light_gray_concrete
fill 335 285 241 340 285 241 minecraft:light_gray_concrete
fill 335 285 259 340 285 260 minecraft:light_gray_concrete
fill 335 285 262 335 285 263 minecraft:light_gray_concrete
fill 335 285 265 336 285 265 minecraft:light_gray_concrete
fill 335 285 268 336 285 268 minecraft:light_gray_concrete
fill 336 285 234 336 285 235 minecraft:light_gray_concrete
fill 336 285 237 344 285 238 minecraft:light_gray_concrete
fill 336 285 240 341 285 240 minecraft:light_gray_concrete
fill 336 285 261 342 285 262 minecraft:light_gray_concrete
fill 336 285 264 337 285 264 minecraft:light_gray_concrete
fill 336 285 267 337 285 267 minecraft:light_gray_concrete
setblock 337 285 234 minecraft:light_gray_concrete
fill 337 285 236 362 285 236 minecraft:light_gray_concrete
fill 337 285 239 342 285 239 minecraft:light_gray_concrete
fill 337 285 263 347 285 263 minecraft:light_gray_concrete
fill 337 285 266 338 285 266 minecraft:light_gray_concrete
fill 337 285 269 338 285 269 minecraft:light_gray_concrete
fill 338 285 235 360 285 235 minecraft:light_gray_concrete
fill 338 285 265 360 285 265 minecraft:light_gray_concrete
fill 338 285 268 339 285 268 minecraft:light_gray_concrete
setblock 339 285 228 minecraft:white_concrete
fill 339 285 234 361 285 234 minecraft:light_gray_concrete
setblock 339 285 245 minecraft:light[level=12]
setblock 339 285 252 minecraft:light[level=12]
setblock 339 285 256 minecraft:light_gray_concrete
fill 339 285 264 361 285 264 minecraft:light_gray_concrete
setblock 339 285 266 minecraft:light[level=12]
fill 339 285 267 340 285 267 minecraft:light_gray_concrete
setblock 339 285 270 minecraft:white_concrete
setblock 340 285 258 minecraft:light_gray_concrete
fill 340 285 266 359 285 266 minecraft:light_gray_concrete
fill 340 285 269 341 285 269 minecraft:light_gray_concrete
setblock 341 285 260 minecraft:light_gray_concrete
fill 341 285 268 342 285 268 minecraft:light_gray_concrete
fill 342 285 229 343 299 232 minecraft:white_concrete
fill 342 285 233 358 285 233 minecraft:light_gray_concrete
fill 342 285 267 358 285 267 minecraft:light_gray_concrete
fill 343 285 228 344 285 228 minecraft:white_concrete
fill 343 285 262 345 285 262 minecraft:light_gray_concrete
fill 343 285 269 344 285 269 minecraft:light_gray_concrete
schedule function dropper:buildpart/55_3 1t
