setblock 82 182 289 minecraft:shroomlight
fill 83 182 288 83 183 290 minecraft:spruce_planks
fill 84 182 288 84 183 288 minecraft:spruce_planks
fill 84 182 290 84 183 290 minecraft:spruce_planks
fill 86 182 280 86 183 286 minecraft:iron_bars
setblock 87 182 289 minecraft:dark_oak_planks
fill 89 182 316 89 187 316 minecraft:blue_concrete
setblock 48 183 282 minecraft:spruce_planks
setblock 48 183 289 minecraft:spruce_planks
setblock 48 183 296 minecraft:spruce_planks
setblock 48 183 303 minecraft:spruce_planks
setblock 48 183 310 minecraft:spruce_planks
setblock 49 183 276 minecraft:spruce_planks
setblock 49 183 316 minecraft:spruce_planks
setblock 50 183 278 minecraft:light[level=12]
setblock 50 183 285 minecraft:light[level=12]
setblock 50 183 289 minecraft:dark_oak_planks
setblock 50 183 292 minecraft:light[level=12]
setblock 50 183 299 minecraft:light[level=12]
setblock 50 183 306 minecraft:light[level=12]
setblock 50 183 313 minecraft:light[level=12]
setblock 53 183 275 minecraft:white_wool
fill 53 183 288 53 184 290 minecraft:spruce_planks
fill 54 183 289 54 185 289 minecraft:spruce_planks
setblock 56 183 276 minecraft:spruce_planks
setblock 56 183 316 minecraft:spruce_planks
setblock 57 183 278 minecraft:light[level=12]
setblock 57 183 285 minecraft:light[level=12]
setblock 57 183 292 minecraft:light[level=12]
setblock 57 183 299 minecraft:light[level=12]
setblock 57 183 306 minecraft:light[level=12]
setblock 57 183 313 minecraft:light[level=12]
setblock 63 183 276 minecraft:spruce_planks
setblock 63 183 316 minecraft:spruce_planks
setblock 64 183 278 minecraft:light[level=12]
setblock 64 183 285 minecraft:light[level=12]
setblock 64 183 292 minecraft:light[level=12]
setblock 64 183 299 minecraft:light[level=12]
setblock 64 183 306 minecraft:light[level=12]
setblock 64 183 313 minecraft:light[level=12]
setblock 70 183 276 minecraft:spruce_planks
setblock 71 183 278 minecraft:light[level=12]
setblock 71 183 285 minecraft:light[level=12]
setblock 71 183 292 minecraft:light[level=12]
setblock 71 183 299 minecraft:light[level=12]
setblock 71 183 306 minecraft:light[level=12]
setblock 72 183 317 minecraft:blue_concrete
setblock 73 183 317 minecraft:light_blue_wool
fill 74 183 317 74 184 317 minecraft:blue_concrete
setblock 77 183 276 minecraft:spruce_planks
setblock 78 183 278 minecraft:light[level=12]
setblock 78 183 285 minecraft:light[level=12]
setblock 78 183 292 minecraft:light[level=12]
setblock 78 183 299 minecraft:light[level=12]
setblock 78 183 306 minecraft:light[level=12]
fill 81 183 289 82 185 289 minecraft:spruce_planks
fill 82 183 288 82 184 288 minecraft:spruce_planks
fill 82 183 290 82 184 290 minecraft:spruce_planks
setblock 84 183 276 minecraft:spruce_planks
setblock 84 183 316 minecraft:spruce_planks
setblock 85 183 278 minecraft:light[level=12]
setblock 85 183 285 minecraft:light[level=12]
setblock 85 183 289 minecraft:dark_oak_planks
setblock 85 183 292 minecraft:light[level=12]
setblock 85 183 299 minecraft:light[level=12]
setblock 85 183 306 minecraft:light[level=12]
fill 86 183 301 86 196 301 minecraft:white_wool
setblock 88 183 279 minecraft:spruce_planks
setblock 88 183 286 minecraft:spruce_planks
setblock 88 183 293 minecraft:spruce_planks
setblock 88 183 300 minecraft:spruce_planks
setblock 88 183 307 minecraft:spruce_planks
setblock 88 183 314 minecraft:spruce_planks
setblock 89 183 287 minecraft:light_blue_wool
setblock 48 184 276 minecraft:spruce_planks
setblock 48 184 283 minecraft:spruce_planks
setblock 48 184 290 minecraft:spruce_planks
setblock 48 184 297 minecraft:spruce_planks
setblock 48 184 304 minecraft:spruce_planks
setblock 48 184 311 minecraft:spruce_planks
fill 50 184 310 51 184 310 minecraft:dark_oak_planks
setblock 50 184 313 minecraft:dark_oak_planks
setblock 50 184 316 minecraft:spruce_planks
setblock 51 184 289 minecraft:dark_oak_planks
fill 51 184 314 52 184 314 minecraft:dark_oak_planks
fill 53 184 275 53 194 275 minecraft:blue_concrete
setblock 53 184 310 minecraft:dark_oak_planks
setblock 53 184 313 minecraft:dark_oak_planks
fill 54 184 288 54 185 288 minecraft:spruce_planks
fill 54 184 290 54 185 290 minecraft:spruce_planks
fill 54 184 311 54 184 312 minecraft:dark_oak_planks
setblock 55 184 276 minecraft:spruce_planks
fill 55 184 289 55 186 289 minecraft:spruce_planks
setblock 57 184 316 minecraft:spruce_planks
setblock 62 184 276 minecraft:spruce_planks
setblock 64 184 316 minecraft:spruce_planks
setblock 68 184 275 minecraft:white_wool
setblock 69 184 276 minecraft:spruce_planks
setblock 69 184 311 minecraft:shroomlight
setblock 69 184 313 minecraft:shroomlight
setblock 69 184 315 minecraft:shroomlight
setblock 70 184 310 minecraft:shroomlight
setblock 70 184 312 minecraft:shroomlight
setblock 70 184 314 minecraft:shroomlight
setblock 70 184 316 minecraft:shroomlight
setblock 71 184 311 minecraft:shroomlight
setblock 71 184 313 minecraft:shroomlight
setblock 71 184 315 minecraft:shroomlight
setblock 72 184 310 minecraft:shroomlight
setblock 72 184 312 minecraft:shroomlight
setblock 72 184 314 minecraft:shroomlight
setblock 72 184 316 minecraft:shroomlight
setblock 72 184 317 minecraft:light_blue_wool
setblock 73 184 311 minecraft:shroomlight
setblock 73 184 313 minecraft:shroomlight
setblock 73 184 315 minecraft:shroomlight
fill 73 184 317 73 189 317 minecraft:blue_concrete
setblock 74 184 310 minecraft:shroomlight
setblock 74 184 312 minecraft:shroomlight
setblock 74 184 314 minecraft:shroomlight
setblock 74 184 316 minecraft:shroomlight
setblock 75 184 311 minecraft:shroomlight
setblock 75 184 313 minecraft:shroomlight
setblock 75 184 315 minecraft:shroomlight
setblock 76 184 276 minecraft:spruce_planks
setblock 76 184 310 minecraft:shroomlight
setblock 76 184 312 minecraft:shroomlight
setblock 76 184 314 minecraft:shroomlight
setblock 76 184 316 minecraft:shroomlight
setblock 77 184 311 minecraft:shroomlight
setblock 77 184 313 minecraft:shroomlight
setblock 77 184 315 minecraft:shroomlight
setblock 78 184 310 minecraft:shroomlight
setblock 78 184 312 minecraft:shroomlight
setblock 78 184 314 minecraft:shroomlight
setblock 78 184 316 minecraft:shroomlight
setblock 79 184 311 minecraft:shroomlight
setblock 79 184 313 minecraft:shroomlight
setblock 79 184 315 minecraft:shroomlight
fill 80 184 289 80 186 289 minecraft:spruce_planks
setblock 80 184 310 minecraft:shroomlight
setblock 80 184 312 minecraft:shroomlight
setblock 80 184 314 minecraft:shroomlight
setblock 80 184 316 minecraft:shroomlight
fill 81 184 288 81 185 288 minecraft:spruce_planks
fill 81 184 290 81 185 290 minecraft:spruce_planks
setblock 81 184 311 minecraft:shroomlight
setblock 81 184 313 minecraft:shroomlight
setblock 81 184 315 minecraft:shroomlight
fill 82 184 311 82 184 312 minecraft:dark_oak_planks
setblock 83 184 276 minecraft:spruce_planks
setblock 83 184 289 minecraft:spruce_planks
fill 83 184 310 86 184 310 minecraft:dark_oak_planks
fill 83 184 313 83 184 314 minecraft:dark_oak_planks
setblock 84 184 289 minecraft:dark_oak_planks
fill 84 184 314 85 184 314 minecraft:dark_oak_planks
setblock 85 184 316 minecraft:spruce_planks
fill 86 184 299 86 196 300 minecraft:white_wool
fill 86 184 302 86 196 303 minecraft:white_wool
setblock 86 184 311 minecraft:dark_oak_planks
setblock 86 184 313 minecraft:dark_oak_planks
setblock 88 184 278 minecraft:spruce_planks
setblock 88 184 285 minecraft:spruce_planks
setblock 88 184 292 minecraft:spruce_planks
setblock 88 184 299 minecraft:spruce_planks
setblock 88 184 306 minecraft:spruce_planks
setblock 88 184 313 minecraft:spruce_planks
fill 89 184 287 89 187 287 minecraft:blue_concrete
setblock 47 185 294 minecraft:light_blue_wool
setblock 48 185 277 minecraft:spruce_planks
setblock 48 185 284 minecraft:spruce_planks
setblock 48 185 291 minecraft:spruce_planks
setblock 48 185 298 minecraft:spruce_planks
setblock 48 185 305 minecraft:spruce_planks
setblock 48 185 312 minecraft:spruce_planks
setblock 50 185 278 minecraft:light[level=15]
setblock 50 185 286 minecraft:light[level=15]
setblock 50 185 294 minecraft:light[level=15]
setblock 50 185 302 minecraft:light[level=15]
setblock 50 185 310 minecraft:light[level=15]
setblock 51 185 316 minecraft:spruce_planks
setblock 52 185 289 minecraft:dark_oak_planks
setblock 53 185 289 minecraft:spruce_planks
setblock 54 185 276 minecraft:spruce_planks
fill 55 185 288 56 185 288 minecraft:spruce_planks
fill 55 185 290 56 185 290 minecraft:spruce_planks
fill 56 185 289 57 186 289 minecraft:spruce_planks
setblock 58 185 278 minecraft:light[level=15]
setblock 58 185 286 minecraft:light[level=15]
setblock 58 185 294 minecraft:light[level=15]
setblock 58 185 302 minecraft:light[level=15]
setblock 58 185 310 minecraft:light[level=15]
setblock 58 185 316 minecraft:spruce_planks
setblock 61 185 276 minecraft:spruce_planks
fill 65 185 276 67 185 279 minecraft:dark_oak_planks
setblock 65 185 316 minecraft:spruce_planks
setblock 66 185 286 minecraft:light[level=15]
setblock 66 185 294 minecraft:light[level=15]
setblock 66 185 302 minecraft:light[level=15]
setblock 66 185 310 minecraft:light[level=15]
fill 68 185 275 68 186 275 minecraft:blue_concrete
fill 68 185 276 68 186 276 minecraft:spruce_planks
fill 68 185 277 73 185 279 minecraft:dark_oak_planks
fill 69 185 276 70 185 276 minecraft:dark_oak_planks
fill 69 185 311 69 187 311 minecraft:spruce_planks
fill 69 185 313 69 187 313 minecraft:spruce_planks
fill 69 185 315 69 187 315 minecraft:spruce_planks
fill 70 185 310 70 187 310 minecraft:spruce_planks
fill 70 185 312 70 187 312 minecraft:spruce_planks
fill 70 185 314 70 187 314 minecraft:spruce_planks
fill 70 185 316 70 187 316 minecraft:spruce_planks
fill 71 185 311 71 187 311 minecraft:spruce_planks
fill 71 185 313 71 187 313 minecraft:spruce_planks
fill 71 185 315 71 187 315 minecraft:spruce_planks
fill 72 185 276 73 185 276 minecraft:dark_oak_planks
fill 72 185 310 72 187 310 minecraft:spruce_planks
fill 72 185 312 72 187 312 minecraft:spruce_planks
fill 72 185 314 72 187 314 minecraft:spruce_planks
fill 72 185 316 72 187 316 minecraft:spruce_planks
fill 72 185 317 72 193 317 minecraft:blue_concrete
fill 73 185 311 73 187 311 minecraft:spruce_planks
fill 73 185 313 73 187 313 minecraft:spruce_planks
fill 73 185 315 73 187 315 minecraft:spruce_planks
setblock 74 185 278 minecraft:light[level=15]
setblock 74 185 286 minecraft:light[level=15]
setblock 74 185 294 minecraft:light[level=15]
setblock 74 185 302 minecraft:light[level=15]
fill 74 185 310 74 187 310 minecraft:spruce_planks
fill 74 185 312 74 187 312 minecraft:spruce_planks
fill 74 185 314 74 187 314 minecraft:spruce_planks
fill 74 185 316 74 187 316 minecraft:spruce_planks
setblock 74 185 317 minecraft:light_blue_wool
setblock 75 185 276 minecraft:spruce_planks
fill 75 185 311 75 187 311 minecraft:spruce_planks
fill 75 185 313 75 187 313 minecraft:spruce_planks
fill 75 185 315 75 187 315 minecraft:spruce_planks
fill 76 185 310 76 187 310 minecraft:spruce_planks
fill 76 185 312 76 187 312 minecraft:spruce_planks
fill 76 185 314 76 187 314 minecraft:spruce_planks
fill 76 185 316 76 222 316 minecraft:spruce_planks
fill 77 185 311 77 187 311 minecraft:spruce_planks
fill 77 185 313 77 187 313 minecraft:spruce_planks
fill 77 185 315 77 187 315 minecraft:spruce_planks
fill 78 185 289 79 186 289 minecraft:spruce_planks
fill 78 185 310 78 187 310 minecraft:spruce_planks
fill 78 185 312 78 187 312 minecraft:spruce_planks
fill 78 185 314 78 187 314 minecraft:spruce_planks
fill 78 185 316 78 187 316 minecraft:spruce_planks
fill 79 185 288 80 185 288 minecraft:spruce_planks
fill 79 185 290 80 185 290 minecraft:spruce_planks
fill 79 185 311 79 187 311 minecraft:spruce_planks
fill 79 185 313 79 187 313 minecraft:spruce_planks
fill 79 185 315 79 187 315 minecraft:spruce_planks
fill 80 185 310 80 187 310 minecraft:spruce_planks
fill 80 185 312 80 187 312 minecraft:spruce_planks
fill 80 185 314 80 187 314 minecraft:spruce_planks
fill 80 185 316 80 187 316 minecraft:spruce_planks
fill 81 185 311 81 187 311 minecraft:spruce_planks
fill 81 185 313 81 187 313 minecraft:spruce_planks
fill 81 185 315 81 187 315 minecraft:spruce_planks
setblock 82 185 276 minecraft:spruce_planks
setblock 82 185 278 minecraft:light[level=15]
setblock 82 185 286 minecraft:light[level=15]
fill 82 185 290 82 192 290 minecraft:dark_oak_planks
setblock 82 185 294 minecraft:light[level=15]
setblock 82 185 302 minecraft:light[level=15]
setblock 82 185 310 minecraft:light[level=15]
fill 83 185 289 83 192 289 minecraft:dark_oak_planks
fill 83 185 317 83 193 317 minecraft:blue_concrete
setblock 84 185 317 minecraft:white_wool
setblock 86 185 316 minecraft:spruce_planks
setblock 88 185 277 minecraft:spruce_planks
setblock 88 185 284 minecraft:spruce_planks
setblock 88 185 291 minecraft:spruce_planks
setblock 88 185 298 minecraft:spruce_planks
setblock 88 185 305 minecraft:spruce_planks
setblock 88 185 312 minecraft:spruce_planks
setblock 89 185 296 minecraft:light_blue_wool
fill 89 185 297 89 191 297 minecraft:blue_concrete
fill 47 186 294 47 189 294 minecraft:blue_concrete
setblock 48 186 278 minecraft:spruce_planks
setblock 48 186 285 minecraft:spruce_planks
setblock 48 186 292 minecraft:spruce_planks
setblock 48 186 299 minecraft:spruce_planks
setblock 48 186 306 minecraft:spruce_planks
setblock 48 186 313 minecraft:spruce_planks
setblock 52 186 316 minecraft:spruce_planks
setblock 53 186 276 minecraft:spruce_planks
setblock 54 186 289 minecraft:dark_oak_planks
fill 56 186 288 58 186 288 minecraft:spruce_planks
fill 56 186 290 58 186 290 minecraft:spruce_planks
fill 58 186 289 59 188 289 minecraft:spruce_planks
setblock 59 186 316 minecraft:spruce_planks
setblock 59 186 317 minecraft:light_blue_wool
setblock 60 186 276 minecraft:spruce_planks
fill 65 186 276 67 186 279 minecraft:spruce_planks
setblock 66 186 316 minecraft:spruce_planks
fill 68 186 277 73 186 279 minecraft:spruce_planks
fill 69 186 276 70 186 276 minecraft:spruce_planks
fill 72 186 276 74 186 276 minecraft:spruce_planks
fill 74 186 317 74 189 317 minecraft:blue_concrete
setblock 75 186 275 minecraft:white_wool
fill 76 186 275 76 189 275 minecraft:blue_concrete
fill 76 186 289 77 188 289 minecraft:spruce_planks
fill 77 186 288 79 186 288 minecraft:spruce_planks
fill 77 186 290 79 186 290 minecraft:spruce_planks
setblock 81 186 276 minecraft:spruce_planks
fill 81 186 288 81 192 290 minecraft:dark_oak_planks
fill 82 186 288 82 192 289 minecraft:dark_oak_planks
fill 84 186 317 84 193 317 minecraft:blue_concrete
setblock 87 186 316 minecraft:spruce_planks
setblock 88 186 276 minecraft:spruce_planks
setblock 88 186 283 minecraft:spruce_planks
setblock 88 186 290 minecraft:spruce_planks
setblock 88 186 297 minecraft:spruce_planks
setblock 88 186 304 minecraft:spruce_planks
setblock 88 186 311 minecraft:spruce_planks
fill 89 186 296 89 189 296 minecraft:blue_concrete
setblock 47 187 313 minecraft:light_blue_wool
setblock 48 187 279 minecraft:spruce_planks
setblock 48 187 286 minecraft:spruce_planks
setblock 48 187 293 minecraft:spruce_planks
setblock 48 187 300 minecraft:spruce_planks
setblock 48 187 307 minecraft:spruce_planks
setblock 48 187 314 minecraft:spruce_planks
setblock 49 187 275 minecraft:light_blue_wool
setblock 52 187 276 minecraft:spruce_planks
setblock 53 187 316 minecraft:spruce_planks
fill 55 187 289 56 187 289 minecraft:dark_oak_planks
setblock 57 187 289 minecraft:spruce_planks
fill 58 187 288 60 187 288 minecraft:spruce_planks
fill 58 187 290 60 187 290 minecraft:spruce_planks
setblock 59 187 276 minecraft:spruce_planks
setblock 59 187 317 minecraft:white_wool
fill 60 187 289 61 189 289 minecraft:spruce_planks
setblock 60 187 316 minecraft:spruce_planks
fill 65 187 279 73 187 279 minecraft:dark_oak_planks
setblock 66 187 276 minecraft:spruce_planks
setblock 67 187 316 minecraft:spruce_planks
fill 68 187 275 70 190 275 minecraft:shroomlight
setblock 71 187 275 minecraft:white_wool
setblock 73 187 276 minecraft:spruce_planks
fill 74 187 289 75 189 289 minecraft:spruce_planks
fill 75 187 275 75 193 275 minecraft:blue_concrete
fill 75 187 288 77 187 288 minecraft:spruce_planks
fill 75 187 290 77 187 290 minecraft:spruce_planks
setblock 78 187 289 minecraft:spruce_planks
fill 79 187 289 80 187 289 minecraft:dark_oak_planks
setblock 80 187 276 minecraft:spruce_planks
fill 80 187 290 80 192 290 minecraft:dark_oak_planks
fill 82 187 291 82 192 291 minecraft:dark_oak_planks
fill 83 187 288 83 192 288 minecraft:dark_oak_planks
fill 83 187 290 83 192 290 minecraft:dark_oak_planks
setblock 87 187 276 minecraft:spruce_planks
setblock 88 187 282 minecraft:spruce_planks
setblock 88 187 289 minecraft:spruce_planks
setblock 88 187 296 minecraft:spruce_planks
setblock 88 187 303 minecraft:spruce_planks
setblock 88 187 310 minecraft:spruce_planks
setblock 88 187 316 minecraft:spruce_planks
fill 89 187 290 89 193 290 minecraft:blue_concrete
setblock 89 187 291 minecraft:white_wool
fill 89 187 292 89 193 292 minecraft:blue_concrete
fill 47 188 313 47 191 313 minecraft:blue_concrete
setblock 48 188 280 minecraft:spruce_planks
setblock 48 188 287 minecraft:spruce_planks
setblock 48 188 294 minecraft:spruce_planks
setblock 48 188 301 minecraft:spruce_planks
setblock 48 188 308 minecraft:spruce_planks
setblock 48 188 315 minecraft:spruce_planks
fill 49 188 275 49 193 275 minecraft:blue_concrete
setblock 51 188 276 minecraft:spruce_planks
setblock 54 188 316 minecraft:spruce_planks
setblock 57 188 289 minecraft:dark_oak_planks
setblock 58 188 276 minecraft:spruce_planks
fill 59 188 288 63 188 288 minecraft:spruce_planks
fill 59 188 290 63 188 290 minecraft:spruce_planks
fill 59 188 317 59 193 317 minecraft:blue_concrete
setblock 61 188 316 minecraft:spruce_planks
fill 62 188 275 62 194 275 minecraft:blue_concrete
fill 62 188 289 66 189 289 minecraft:spruce_planks
setblock 63 188 275 minecraft:light_blue_wool
setblock 65 188 276 minecraft:spruce_planks
setblock 65 188 279 minecraft:spruce_planks
setblock 68 188 316 minecraft:spruce_planks
setblock 69 188 279 minecraft:spruce_planks
fill 69 188 289 73 189 289 minecraft:spruce_planks
fill 71 188 275 71 189 275 minecraft:blue_concrete
setblock 71 188 317 minecraft:light_blue_wool
setblock 72 188 276 minecraft:spruce_planks
fill 72 188 288 76 188 288 minecraft:spruce_planks
fill 72 188 290 76 188 290 minecraft:spruce_planks
setblock 73 188 279 minecraft:spruce_planks
setblock 78 188 289 minecraft:dark_oak_planks
setblock 79 188 276 minecraft:spruce_planks
fill 80 188 288 80 192 289 minecraft:dark_oak_planks
fill 81 188 287 82 192 287 minecraft:dark_oak_planks
fill 81 188 291 81 192 291 minecraft:dark_oak_planks
setblock 82 188 316 minecraft:spruce_planks
fill 83 188 291 83 192 291 minecraft:dark_oak_planks
fill 84 188 289 84 192 289 minecraft:dark_oak_planks
setblock 86 188 276 minecraft:spruce_planks
setblock 88 188 281 minecraft:spruce_planks
setblock 88 188 288 minecraft:spruce_planks
setblock 88 188 295 minecraft:spruce_planks
setblock 88 188 302 minecraft:spruce_planks
setblock 88 188 309 minecraft:spruce_planks
setblock 89 188 287 minecraft:light_blue_wool
fill 89 188 291 89 193 291 minecraft:blue_concrete
setblock 89 188 316 minecraft:white_wool
setblock 50 189 278 minecraft:light[level=12]
setblock 50 189 285 minecraft:light[level=12]
setblock 50 189 292 minecraft:light[level=12]
setblock 50 189 299 minecraft:light[level=12]
setblock 50 189 306 minecraft:light[level=12]
setblock 50 189 313 minecraft:light[level=12]
setblock 57 189 278 minecraft:light[level=12]
setblock 57 189 285 minecraft:light[level=12]
setblock 57 189 292 minecraft:light[level=12]
setblock 57 189 299 minecraft:light[level=12]
setblock 57 189 306 minecraft:light[level=12]
setblock 57 189 313 minecraft:light[level=12]
setblock 59 189 289 minecraft:dark_oak_planks
fill 62 189 288 73 189 288 minecraft:spruce_planks
fill 62 189 290 73 189 290 minecraft:spruce_planks
fill 63 189 275 63 193 275 minecraft:blue_concrete
setblock 64 189 278 minecraft:light[level=12]
setblock 64 189 285 minecraft:light[level=12]
setblock 64 189 292 minecraft:light[level=12]
setblock 64 189 299 minecraft:light[level=12]
setblock 64 189 306 minecraft:light[level=12]
setblock 64 189 313 minecraft:light[level=12]
fill 67 189 289 68 190 289 minecraft:spruce_planks
setblock 71 189 278 minecraft:light[level=12]
setblock 71 189 285 minecraft:light[level=12]
setblock 71 189 292 minecraft:light[level=12]
setblock 71 189 299 minecraft:light[level=12]
setblock 71 189 306 minecraft:light[level=12]
setblock 71 189 313 minecraft:light[level=12]
fill 71 189 317 71 193 317 minecraft:blue_concrete
setblock 76 189 289 minecraft:dark_oak_planks
setblock 78 189 278 minecraft:light[level=12]
setblock 78 189 285 minecraft:light[level=12]
setblock 78 189 292 minecraft:light[level=12]
setblock 78 189 299 minecraft:light[level=12]
setblock 78 189 306 minecraft:light[level=12]
setblock 78 189 313 minecraft:light[level=12]
fill 79 189 289 79 192 290 minecraft:dark_oak_planks
fill 80 189 287 80 192 287 minecraft:dark_oak_planks
fill 80 189 291 80 192 291 minecraft:dark_oak_planks
fill 83 189 287 83 192 287 minecraft:dark_oak_planks
fill 84 189 288 84 192 288 minecraft:dark_oak_planks
fill 84 189 290 84 192 290 minecraft:dark_oak_planks
setblock 85 189 278 minecraft:light[level=12]
setblock 85 189 285 minecraft:light[level=12]
setblock 85 189 292 minecraft:light[level=12]
setblock 85 189 299 minecraft:light[level=12]
setblock 85 189 306 minecraft:light[level=12]
setblock 89 189 287 minecraft:white_wool
fill 89 189 316 89 193 316 minecraft:blue_concrete
setblock 47 190 283 minecraft:light_blue_wool
setblock 47 190 284 minecraft:cyan_concrete
setblock 47 190 288 minecraft:cyan_concrete
setblock 47 190 294 minecraft:light_blue_wool
setblock 47 190 296 minecraft:cyan_concrete
fill 48 190 276 48 190 280 minecraft:spruce_planks
fill 48 190 282 48 190 287 minecraft:spruce_planks
fill 48 190 289 48 190 294 minecraft:spruce_planks
fill 48 190 296 48 190 301 minecraft:spruce_planks
fill 48 190 303 48 190 308 minecraft:spruce_planks
fill 48 190 310 48 190 315 minecraft:spruce_planks
fill 48 190 317 49 193 317 minecraft:blue_concrete
setblock 49 190 276 minecraft:spruce_planks
fill 49 190 316 54 190 316 minecraft:spruce_planks
setblock 50 190 317 minecraft:cyan_concrete
fill 51 190 276 56 190 276 minecraft:spruce_planks
fill 51 190 314 51 191 315 minecraft:iron_bars
setblock 53 190 317 minecraft:cyan_concrete
setblock 55 190 317 minecraft:light_blue_wool
fill 56 190 316 61 190 316 minecraft:spruce_planks
setblock 56 190 317 minecraft:cyan_concrete
fill 58 190 276 63 190 276 minecraft:spruce_planks
fill 61 190 289 63 190 289 minecraft:dark_oak_planks
fill 63 190 316 68 190 316 minecraft:spruce_planks
fill 63 190 317 64 190 317 minecraft:blue_concrete
fill 64 190 289 66 190 289 minecraft:spruce_planks
fill 65 190 276 70 190 276 minecraft:spruce_planks
setblock 65 190 317 minecraft:cyan_concrete
fill 66 190 317 67 193 317 minecraft:blue_concrete
fill 67 190 288 68 190 288 minecraft:spruce_planks
fill 67 190 290 68 190 290 minecraft:spruce_planks
fill 69 190 289 71 190 289 minecraft:spruce_planks
fill 70 190 316 75 190 316 minecraft:spruce_planks
setblock 71 190 275 minecraft:cyan_concrete
fill 72 190 276 77 190 276 minecraft:spruce_planks
fill 72 190 289 74 190 289 minecraft:dark_oak_planks
fill 73 190 317 74 190 317 minecraft:cyan_concrete
setblock 76 190 275 minecraft:light_blue_wool
fill 77 190 316 82 190 316 minecraft:spruce_planks
fill 79 190 276 84 190 276 minecraft:spruce_planks
fill 79 190 288 79 192 288 minecraft:dark_oak_planks
fill 79 190 291 79 192 291 minecraft:dark_oak_planks
setblock 79 190 317 minecraft:cyan_concrete
fill 80 190 292 83 192 292 minecraft:dark_oak_planks
fill 81 190 286 82 192 286 minecraft:dark_oak_planks
setblock 81 190 317 minecraft:cyan_concrete
fill 84 190 287 84 192 287 minecraft:dark_oak_planks
fill 84 190 291 84 192 291 minecraft:dark_oak_planks
fill 84 190 316 88 190 316 minecraft:spruce_planks
fill 85 190 289 85 192 289 minecraft:dark_oak_planks
fill 86 190 276 88 190 276 minecraft:spruce_planks
fill 88 190 277 88 190 279 minecraft:spruce_planks
fill 88 190 281 88 190 286 minecraft:spruce_planks
fill 88 190 288 88 190 293 minecraft:spruce_planks
fill 88 190 295 88 190 300 minecraft:spruce_planks
fill 88 190 302 88 190 307 minecraft:spruce_planks
fill 88 190 309 88 190 314 minecraft:spruce_planks
setblock 89 190 276 minecraft:cyan_concrete
setblock 89 190 284 minecraft:cyan_concrete
fill 89 190 285 89 193 285 minecraft:blue_concrete
fill 89 190 287 89 193 287 minecraft:blue_concrete
setblock 89 190 296 minecraft:cyan_concrete
setblock 89 190 306 minecraft:cyan_concrete
fill 89 190 307 89 190 309 minecraft:blue_concrete
fill 47 191 283 47 191 284 minecraft:blue_concrete
fill 47 191 288 47 193 288 minecraft:blue_concrete
fill 47 191 294 47 193 294 minecraft:blue_concrete
fill 47 191 295 47 192 295 minecraft:cyan_concrete
fill 47 191 296 47 193 296 minecraft:blue_concrete
fill 47 191 308 47 192 308 minecraft:cyan_concrete
setblock 48 191 276 minecraft:spruce_planks
fill 48 191 280 56 197 280 minecraft:white_wool
setblock 48 191 283 minecraft:spruce_planks
setblock 48 191 290 minecraft:spruce_planks
setblock 48 191 297 minecraft:spruce_planks
setblock 48 191 304 minecraft:spruce_planks
setblock 48 191 311 minecraft:spruce_planks
setblock 50 191 316 minecraft:spruce_planks
fill 50 191 317 50 193 317 minecraft:blue_concrete
fill 53 191 317 53 193 317 minecraft:blue_concrete
fill 54 191 275 55 191 275 minecraft:blue_concrete
setblock 55 191 276 minecraft:spruce_planks
fill 55 191 317 56 193 317 minecraft:blue_concrete
setblock 56 191 275 minecraft:cyan_concrete
setblock 57 191 316 minecraft:spruce_planks
setblock 62 191 276 minecraft:spruce_planks
setblock 63 191 317 minecraft:cyan_concrete
fill 64 191 289 71 191 289 minecraft:dark_oak_planks
setblock 64 191 316 minecraft:spruce_planks
fill 64 191 317 65 193 317 minecraft:blue_concrete
fill 65 191 275 65 192 275 minecraft:cyan_concrete
fill 68 191 275 70 191 275 minecraft:blue_concrete
setblock 68 191 317 minecraft:cyan_concrete
setblock 69 191 276 minecraft:spruce_planks
setblock 71 191 275 minecraft:white_wool
setblock 71 191 316 minecraft:spruce_planks
fill 73 191 317 74 193 317 minecraft:blue_concrete
fill 76 191 275 76 193 275 minecraft:blue_concrete
setblock 76 191 276 minecraft:spruce_planks
setblock 77 191 275 minecraft:cyan_concrete
fill 78 191 289 78 192 290 minecraft:dark_oak_planks
setblock 78 191 316 minecraft:spruce_planks
fill 79 191 287 79 192 287 minecraft:dark_oak_planks
fill 79 191 317 79 193 317 minecraft:blue_concrete
fill 80 191 286 80 192 286 minecraft:dark_oak_planks
fill 80 191 312 88 197 312 minecraft:white_wool
fill 81 191 317 81 193 317 minecraft:blue_concrete
setblock 83 191 276 minecraft:spruce_planks
fill 83 191 286 83 192 286 minecraft:dark_oak_planks
fill 84 191 292 84 192 292 minecraft:dark_oak_planks
fill 85 191 275 88 193 275 minecraft:blue_concrete
fill 85 191 288 85 192 288 minecraft:dark_oak_planks
fill 85 191 290 85 192 291 minecraft:dark_oak_planks
setblock 85 191 316 minecraft:spruce_planks
setblock 88 191 278 minecraft:spruce_planks
setblock 88 191 285 minecraft:spruce_planks
setblock 88 191 292 minecraft:spruce_planks
setblock 88 191 299 minecraft:spruce_planks
setblock 88 191 306 minecraft:spruce_planks
setblock 88 191 313 minecraft:spruce_planks
setblock 89 191 275 minecraft:cyan_concrete
fill 89 191 276 89 193 276 minecraft:blue_concrete
fill 89 191 277 89 192 277 minecraft:cyan_concrete
fill 89 191 284 89 193 284 minecraft:blue_concrete
setblock 89 191 288 minecraft:cyan_concrete
fill 89 191 296 89 193 296 minecraft:blue_concrete
fill 89 191 299 89 191 300 minecraft:cyan_concrete
fill 89 191 306 89 193 307 minecraft:blue_concrete
fill 89 191 308 89 192 308 minecraft:cyan_concrete
fill 89 191 309 89 192 309 minecraft:blue_concrete
fill 89 191 317 89 192 317 minecraft:cyan_concrete
fill 47 192 278 47 193 278 minecraft:blue_concrete
setblock 47 192 279 minecraft:cyan_concrete
fill 47 192 283 47 193 283 minecraft:blue_concrete
setblock 47 192 284 minecraft:cyan_concrete
setblock 47 192 293 minecraft:cyan_concrete
setblock 47 192 298 minecraft:cyan_concrete
setblock 47 192 300 minecraft:cyan_concrete
fill 47 192 301 47 193 301 minecraft:blue_concrete
setblock 47 192 304 minecraft:cyan_concrete
setblock 47 192 311 minecraft:white_wool
setblock 47 192 313 minecraft:cyan_concrete
setblock 48 192 277 minecraft:spruce_planks
setblock 48 192 284 minecraft:spruce_planks
setblock 48 192 291 minecraft:spruce_planks
setblock 48 192 298 minecraft:spruce_planks
setblock 48 192 305 minecraft:spruce_planks
setblock 48 192 312 minecraft:spruce_planks
setblock 50 192 275 minecraft:cyan_concrete
fill 50 192 310 51 192 310 minecraft:dark_oak_planks
setblock 50 192 313 minecraft:dark_oak_planks
fill 51 192 314 52 192 314 minecraft:dark_oak_planks
setblock 51 192 316 minecraft:spruce_planks
setblock 52 192 275 minecraft:cyan_concrete
setblock 53 192 310 minecraft:dark_oak_planks
setblock 53 192 313 minecraft:dark_oak_planks
fill 54 192 275 55 192 275 minecraft:cyan_concrete
setblock 54 192 276 minecraft:spruce_planks
fill 54 192 311 54 192 312 minecraft:dark_oak_planks
fill 56 192 275 57 193 275 minecraft:blue_concrete
setblock 58 192 275 minecraft:cyan_concrete
setblock 58 192 316 minecraft:spruce_planks
setblock 61 192 275 minecraft:cyan_concrete
setblock 61 192 276 minecraft:spruce_planks
fill 63 192 317 63 193 317 minecraft:blue_concrete
setblock 65 192 316 minecraft:spruce_planks
fill 68 192 275 69 193 275 minecraft:blue_concrete
setblock 68 192 276 minecraft:spruce_planks
fill 68 192 317 68 193 317 minecraft:blue_concrete
setblock 70 192 275 minecraft:light_blue_wool
fill 71 192 275 71 193 275 minecraft:blue_concrete
setblock 72 192 316 minecraft:spruce_planks
setblock 75 192 276 minecraft:spruce_planks
fill 77 192 275 77 193 275 minecraft:blue_concrete
setblock 78 192 275 minecraft:cyan_concrete
fill 78 192 287 78 192 288 minecraft:dark_oak_planks
setblock 78 192 291 minecraft:dark_oak_planks
fill 79 192 275 79 193 275 minecraft:blue_concrete
setblock 79 192 286 minecraft:dark_oak_planks
setblock 79 192 292 minecraft:dark_oak_planks
setblock 79 192 316 minecraft:spruce_planks
setblock 80 192 275 minecraft:cyan_concrete
fill 80 192 293 83 192 293 minecraft:dark_oak_planks
fill 81 192 285 83 192 285 minecraft:dark_oak_planks
setblock 82 192 276 minecraft:spruce_planks
setblock 82 192 311 minecraft:dark_oak_planks
fill 83 192 310 86 192 310 minecraft:dark_oak_planks
fill 83 192 313 83 192 314 minecraft:dark_oak_planks
setblock 84 192 286 minecraft:dark_oak_planks
fill 84 192 314 85 192 314 minecraft:dark_oak_planks
setblock 85 192 287 minecraft:dark_oak_planks
setblock 86 192 289 minecraft:dark_oak_planks
setblock 86 192 311 minecraft:dark_oak_planks
setblock 86 192 313 minecraft:dark_oak_planks
setblock 86 192 316 minecraft:spruce_planks
setblock 88 192 277 minecraft:spruce_planks
setblock 88 192 284 minecraft:spruce_planks
setblock 88 192 291 minecraft:spruce_planks
setblock 88 192 298 minecraft:spruce_planks
setblock 88 192 305 minecraft:spruce_planks
fill 89 192 275 89 193 275 minecraft:blue_concrete
setblock 89 192 281 minecraft:cyan_concrete
fill 89 192 288 89 193 288 minecraft:blue_concrete
setblock 89 192 289 minecraft:cyan_concrete
setblock 89 192 297 minecraft:cyan_concrete
fill 89 192 299 89 193 300 minecraft:blue_concrete
setblock 47 193 279 minecraft:blue_concrete
setblock 47 193 284 minecraft:blue_concrete
setblock 47 193 293 minecraft:blue_concrete
setblock 47 193 295 minecraft:blue_concrete
setblock 47 193 298 minecraft:blue_concrete
setblock 47 193 300 minecraft:blue_concrete
setblock 47 193 304 minecraft:blue_concrete
setblock 47 193 308 minecraft:blue_concrete
setblock 47 193 311 minecraft:blue_concrete
fill 47 193 313 47 194 313 minecraft:blue_concrete
setblock 48 193 278 minecraft:spruce_planks
setblock 48 193 285 minecraft:spruce_planks
setblock 48 193 292 minecraft:spruce_planks
setblock 48 193 299 minecraft:spruce_planks
setblock 48 193 306 minecraft:spruce_planks
setblock 48 193 313 minecraft:spruce_planks
setblock 50 193 275 minecraft:blue_concrete
setblock 50 193 278 minecraft:light[level=15]
setblock 50 193 286 minecraft:light[level=15]
setblock 50 193 294 minecraft:light[level=15]
setblock 50 193 302 minecraft:light[level=15]
setblock 50 193 310 minecraft:light[level=15]
setblock 52 193 275 minecraft:blue_concrete
setblock 52 193 316 minecraft:spruce_planks
setblock 53 193 276 minecraft:spruce_planks
fill 54 193 275 55 193 275 minecraft:blue_concrete
setblock 58 193 275 minecraft:blue_concrete
setblock 58 193 278 minecraft:light[level=15]
setblock 58 193 286 minecraft:light[level=15]
setblock 58 193 294 minecraft:light[level=15]
setblock 58 193 302 minecraft:light[level=15]
setblock 58 193 310 minecraft:light[level=15]
setblock 59 193 316 minecraft:spruce_planks
setblock 60 193 276 minecraft:spruce_planks
setblock 61 193 275 minecraft:blue_concrete
setblock 65 193 275 minecraft:blue_concrete
setblock 66 193 278 minecraft:light[level=15]
setblock 66 193 286 minecraft:light[level=15]
setblock 66 193 294 minecraft:light[level=15]
setblock 66 193 302 minecraft:light[level=15]
setblock 66 193 310 minecraft:light[level=15]
setblock 66 193 316 minecraft:spruce_planks
setblock 67 193 276 minecraft:spruce_planks
setblock 70 193 275 minecraft:blue_concrete
setblock 73 193 316 minecraft:spruce_planks
setblock 74 193 276 minecraft:spruce_planks
setblock 74 193 278 minecraft:light[level=15]
setblock 74 193 286 minecraft:light[level=15]
setblock 74 193 294 minecraft:light[level=15]
setblock 74 193 302 minecraft:light[level=15]
setblock 74 193 310 minecraft:light[level=15]
setblock 78 193 275 minecraft:blue_concrete
setblock 80 193 275 minecraft:blue_concrete
fill 80 193 288 80 194 288 minecraft:spruce_planks
setblock 80 193 316 minecraft:spruce_planks
setblock 81 193 276 minecraft:spruce_planks
setblock 82 193 278 minecraft:light[level=15]
setblock 82 193 286 minecraft:light[level=15]
fill 82 193 291 82 197 291 minecraft:spruce_planks
setblock 82 193 294 minecraft:light[level=15]
setblock 82 193 302 minecraft:light[level=15]
setblock 82 193 310 minecraft:light[level=15]
fill 83 193 288 83 197 288 minecraft:spruce_planks
setblock 87 193 316 minecraft:spruce_planks
setblock 88 193 276 minecraft:spruce_planks
setblock 88 193 283 minecraft:spruce_planks
setblock 88 193 290 minecraft:spruce_planks
setblock 88 193 297 minecraft:spruce_planks
setblock 88 193 304 minecraft:spruce_planks
setblock 88 193 311 minecraft:spruce_planks
setblock 89 193 277 minecraft:blue_concrete
setblock 89 193 281 minecraft:blue_concrete
setblock 89 193 289 minecraft:blue_concrete
setblock 89 193 297 minecraft:blue_concrete
setblock 89 193 303 minecraft:white_wool
setblock 89 193 308 minecraft:blue_concrete
setblock 89 193 309 minecraft:light_blue_wool
setblock 89 193 317 minecraft:blue_concrete
fill 47 194 275 47 195 285 minecraft:cyan_concrete
fill 47 194 287 47 194 288 minecraft:cyan_concrete
fill 47 194 290 47 194 305 minecraft:cyan_concrete
setblock 47 194 306 minecraft:light_blue_wool
fill 47 194 308 47 223 311 minecraft:cyan_concrete
fill 47 194 314 47 196 317 minecraft:cyan_concrete
fill 48 194 275 52 194 275 minecraft:cyan_concrete
setblock 48 194 279 minecraft:spruce_planks
setblock 48 194 286 minecraft:spruce_planks
setblock 48 194 293 minecraft:spruce_planks
setblock 48 194 300 minecraft:spruce_planks
setblock 48 194 307 minecraft:spruce_planks
setblock 48 194 314 minecraft:spruce_planks
fill 48 194 317 56 194 317 minecraft:cyan_concrete
setblock 52 194 276 minecraft:spruce_planks
setblock 53 194 316 minecraft:spruce_planks
fill 54 194 275 59 195 275 minecraft:cyan_concrete
fill 58 194 317 61 195 317 minecraft:cyan_concrete
setblock 59 194 276 minecraft:spruce_planks
setblock 60 194 316 minecraft:spruce_planks
fill 61 194 275 61 251 275 minecraft:cyan_concrete
setblock 62 194 317 minecraft:blue_concrete
fill 63 194 275 83 194 275 minecraft:cyan_concrete
fill 63 194 317 72 194 317 minecraft:cyan_concrete
setblock 66 194 276 minecraft:spruce_planks
setblock 67 194 316 minecraft:spruce_planks
setblock 73 194 276 minecraft:spruce_planks
setblock 73 194 317 minecraft:blue_concrete
setblock 74 194 316 minecraft:spruce_planks
fill 74 194 317 76 195 317 minecraft:cyan_concrete
fill 78 194 317 89 194 317 minecraft:cyan_concrete
setblock 80 194 276 minecraft:spruce_planks
setblock 81 194 316 minecraft:spruce_planks
fill 85 194 275 86 225 275 minecraft:cyan_concrete
setblock 87 194 275 minecraft:blue_concrete
setblock 87 194 276 minecraft:spruce_planks
fill 88 194 275 89 243 275 minecraft:cyan_concrete
setblock 88 194 282 minecraft:spruce_planks
setblock 88 194 289 minecraft:spruce_planks
setblock 88 194 296 minecraft:spruce_planks
setblock 88 194 303 minecraft:spruce_planks
setblock 88 194 310 minecraft:spruce_planks
setblock 88 194 316 minecraft:spruce_planks
fill 89 194 276 89 202 277 minecraft:cyan_concrete
fill 89 194 279 89 194 298 minecraft:cyan_concrete
setblock 89 194 299 minecraft:blue_concrete
fill 89 194 300 89 194 315 minecraft:cyan_concrete
setblock 89 194 316 minecraft:light_blue_wool
setblock 47 195 286 minecraft:cyan_concrete
fill 47 195 287 47 196 287 minecraft:blue_concrete
fill 47 195 288 47 211 291 minecraft:cyan_concrete
fill 47 195 292 47 196 292 minecraft:blue_concrete
fill 47 195 293 47 196 303 minecraft:cyan_concrete
fill 47 195 304 47 195 305 minecraft:blue_concrete
fill 47 195 306 47 222 307 minecraft:cyan_concrete
fill 47 195 312 47 195 313 minecraft:cyan_concrete
fill 48 195 275 49 195 275 minecraft:blue_concrete
setblock 48 195 287 minecraft:spruce_planks
setblock 48 195 294 minecraft:spruce_planks
setblock 48 195 301 minecraft:spruce_planks
setblock 48 195 308 minecraft:spruce_planks
setblock 48 195 315 minecraft:spruce_planks
fill 48 195 317 50 195 317 minecraft:cyan_concrete
fill 50 195 275 53 195 275 minecraft:cyan_concrete
setblock 50 195 278 minecraft:light[level=12]
setblock 50 195 285 minecraft:light[level=12]
setblock 50 195 292 minecraft:light[level=12]
setblock 50 195 299 minecraft:light[level=12]
setblock 50 195 306 minecraft:light[level=12]
setblock 50 195 313 minecraft:light[level=12]
setblock 51 195 276 minecraft:spruce_planks
fill 51 195 317 51 196 317 minecraft:blue_concrete
fill 52 195 317 55 207 317 minecraft:cyan_concrete
fill 54 195 296 54 202 296 minecraft:green_terracotta
setblock 54 195 316 minecraft:spruce_planks
setblock 56 195 317 minecraft:blue_concrete
setblock 57 195 278 minecraft:light[level=12]
setblock 57 195 285 minecraft:light[level=12]
setblock 57 195 292 minecraft:light[level=12]
setblock 57 195 299 minecraft:light[level=12]
setblock 57 195 306 minecraft:light[level=12]
setblock 57 195 313 minecraft:light[level=12]
fill 57 195 317 57 244 317 minecraft:cyan_concrete
setblock 58 195 276 minecraft:spruce_planks
fill 60 195 275 60 251 275 minecraft:cyan_concrete
setblock 61 195 316 minecraft:spruce_planks
fill 62 195 275 69 195 275 minecraft:cyan_concrete
fill 62 195 317 69 195 317 minecraft:cyan_concrete
setblock 64 195 278 minecraft:light[level=12]
setblock 64 195 285 minecraft:light[level=12]
setblock 64 195 292 minecraft:light[level=12]
setblock 64 195 299 minecraft:light[level=12]
setblock 64 195 306 minecraft:light[level=12]
setblock 64 195 313 minecraft:light[level=12]
setblock 65 195 276 minecraft:spruce_planks
setblock 68 195 316 minecraft:spruce_planks
setblock 70 195 275 minecraft:blue_concrete
fill 70 195 317 71 195 317 minecraft:blue_concrete
fill 71 195 275 73 214 275 minecraft:cyan_concrete
setblock 71 195 278 minecraft:light[level=12]
setblock 71 195 285 minecraft:light[level=12]
setblock 71 195 292 minecraft:light[level=12]
setblock 71 195 299 minecraft:light[level=12]
setblock 71 195 306 minecraft:light[level=12]
setblock 71 195 313 minecraft:light[level=12]
setblock 72 195 276 minecraft:spruce_planks
setblock 72 195 317 minecraft:white_wool
fill 73 195 317 73 251 317 minecraft:cyan_concrete
fill 74 195 275 75 195 275 minecraft:blue_concrete
setblock 75 195 316 minecraft:spruce_planks
fill 76 195 275 84 195 275 minecraft:cyan_concrete
fill 77 195 317 79 239 317 minecraft:cyan_concrete
setblock 78 195 278 minecraft:light[level=12]
setblock 78 195 285 minecraft:light[level=12]
setblock 78 195 292 minecraft:light[level=12]
setblock 78 195 299 minecraft:light[level=12]
setblock 78 195 306 minecraft:light[level=12]
setblock 78 195 313 minecraft:light[level=12]
setblock 79 195 276 minecraft:spruce_planks
setblock 80 195 317 minecraft:blue_concrete
fill 81 195 317 81 247 317 minecraft:cyan_concrete
setblock 82 195 316 minecraft:spruce_planks
setblock 82 195 317 minecraft:blue_concrete
fill 83 195 317 89 195 317 minecraft:cyan_concrete
setblock 85 195 278 minecraft:light[level=12]
setblock 85 195 285 minecraft:light[level=12]
setblock 85 195 292 minecraft:light[level=12]
setblock 85 195 299 minecraft:light[level=12]
setblock 85 195 306 minecraft:light[level=12]
fill 85 195 310 87 196 310 minecraft:iron_bars
setblock 86 195 276 minecraft:spruce_planks
fill 87 195 275 87 226 275 minecraft:cyan_concrete
setblock 88 195 281 minecraft:spruce_planks
setblock 88 195 288 minecraft:spruce_planks
setblock 88 195 295 minecraft:spruce_planks
setblock 88 195 302 minecraft:spruce_planks
setblock 88 195 309 minecraft:spruce_planks
fill 89 195 278 89 238 280 minecraft:cyan_concrete
setblock 89 195 281 minecraft:blue_concrete
fill 89 195 282 89 247 283 minecraft:cyan_concrete
setblock 89 195 284 minecraft:blue_concrete
fill 89 195 285 89 195 299 minecraft:cyan_concrete
setblock 89 195 300 minecraft:blue_concrete
fill 89 195 301 89 198 316 minecraft:cyan_concrete
fill 47 196 275 47 204 278 minecraft:cyan_concrete
setblock 47 196 279 minecraft:blue_concrete
fill 47 196 280 47 198 280 minecraft:cyan_concrete
setblock 47 196 281 minecraft:blue_concrete
fill 47 196 282 47 211 282 minecraft:cyan_concrete
setblock 47 196 283 minecraft:blue_concrete
fill 47 196 284 47 215 285 minecraft:cyan_concrete
setblock 47 196 286 minecraft:blue_concrete
fill 47 196 304 47 197 305 minecraft:cyan_concrete
setblock 47 196 312 minecraft:blue_concrete
fill 47 196 313 47 223 313 minecraft:cyan_concrete
fill 48 196 275 49 205 275 minecraft:cyan_concrete
fill 48 196 317 48 207 317 minecraft:cyan_concrete
setblock 49 196 317 minecraft:blue_concrete
fill 50 196 275 50 197 275 minecraft:light_blue_wool
fill 50 196 317 50 248 317 minecraft:cyan_concrete
setblock 51 196 275 minecraft:blue_concrete
fill 52 196 275 55 235 275 minecraft:cyan_concrete
setblock 56 196 275 minecraft:blue_concrete
fill 56 196 317 56 211 317 minecraft:cyan_concrete
fill 57 196 275 59 244 275 minecraft:cyan_concrete
fill 58 196 317 60 198 317 minecraft:cyan_concrete
fill 61 196 317 62 196 317 minecraft:blue_concrete
fill 62 196 275 66 197 275 minecraft:cyan_concrete
fill 63 196 317 63 207 317 minecraft:cyan_concrete
setblock 64 196 317 minecraft:blue_concrete
fill 65 196 317 72 204 317 minecraft:cyan_concrete
setblock 67 196 275 minecraft:blue_concrete
fill 68 196 275 70 199 275 minecraft:cyan_concrete
setblock 74 196 275 minecraft:blue_concrete
fill 74 196 317 74 204 317 minecraft:cyan_concrete
fill 75 196 275 79 224 275 minecraft:cyan_concrete
fill 75 196 317 76 196 317 minecraft:blue_concrete
setblock 80 196 275 minecraft:blue_concrete
fill 80 196 317 80 251 317 minecraft:cyan_concrete
fill 81 196 275 81 246 275 minecraft:cyan_concrete
setblock 82 196 275 minecraft:blue_concrete
fill 82 196 317 82 251 317 minecraft:cyan_concrete
fill 83 196 275 84 247 275 minecraft:cyan_concrete
setblock 83 196 317 minecraft:blue_concrete
fill 84 196 317 89 220 317 minecraft:cyan_concrete
fill 89 196 281 89 251 281 minecraft:cyan_concrete
fill 89 196 284 89 201 286 minecraft:cyan_concrete
setblock 89 196 287 minecraft:blue_concrete
fill 89 196 288 89 248 288 minecraft:cyan_concrete
setblock 89 196 289 minecraft:white_wool
fill 89 196 290 89 219 300 minecraft:cyan_concrete
fill 47 197 279 47 243 279 minecraft:cyan_concrete
fill 47 197 281 47 216 281 minecraft:cyan_concrete
fill 47 197 283 47 252 283 minecraft:cyan_concrete
fill 47 197 286 47 205 287 minecraft:cyan_concrete
fill 47 197 292 47 198 297 minecraft:cyan_concrete
setblock 47 197 298 minecraft:light_blue_wool
fill 47 197 299 47 202 303 minecraft:cyan_concrete
fill 47 197 312 47 249 312 minecraft:cyan_concrete
fill 47 197 314 47 246 315 minecraft:cyan_concrete
setblock 47 197 316 minecraft:white_wool
fill 47 197 317 47 249 317 minecraft:cyan_concrete
setblock 48 197 282 minecraft:spruce_planks
setblock 48 197 289 minecraft:spruce_planks
setblock 48 197 296 minecraft:spruce_planks
setblock 48 197 303 minecraft:spruce_planks
setblock 48 197 310 minecraft:spruce_planks
setblock 49 197 276 minecraft:spruce_planks
setblock 49 197 316 minecraft:spruce_planks
fill 49 197 317 49 251 317 minecraft:cyan_concrete
setblock 51 197 275 minecraft:light_blue_wool
fill 51 197 317 51 241 317 minecraft:cyan_concrete
fill 56 197 275 56 225 275 minecraft:cyan_concrete
setblock 56 197 276 minecraft:spruce_planks
setblock 56 197 316 minecraft:spruce_planks
fill 61 197 317 62 249 317 minecraft:cyan_concrete
setblock 63 197 276 minecraft:spruce_planks
setblock 63 197 316 minecraft:spruce_planks
fill 64 197 317 64 241 317 minecraft:cyan_concrete
setblock 67 197 275 minecraft:light_blue_wool
setblock 70 197 276 minecraft:spruce_planks
setblock 70 197 316 minecraft:spruce_planks
fill 74 197 275 74 251 275 minecraft:cyan_concrete
fill 75 197 317 76 213 317 minecraft:cyan_concrete
setblock 77 197 276 minecraft:spruce_planks
setblock 77 197 316 minecraft:spruce_planks
fill 80 197 275 80 248 275 minecraft:cyan_concrete
fill 82 197 275 82 251 275 minecraft:cyan_concrete
fill 83 197 317 83 252 317 minecraft:cyan_concrete
setblock 84 197 276 minecraft:spruce_planks
setblock 84 197 316 minecraft:spruce_planks
fill 86 197 298 86 198 304 minecraft:iron_bars
setblock 88 197 279 minecraft:spruce_planks
setblock 88 197 286 minecraft:spruce_planks
setblock 88 197 293 minecraft:spruce_planks
setblock 88 197 300 minecraft:spruce_planks
setblock 88 197 307 minecraft:spruce_planks
setblock 88 197 314 minecraft:spruce_planks
setblock 89 197 287 minecraft:cyan_concrete
fill 89 197 289 89 221 289 minecraft:cyan_concrete
fill 47 198 298 47 217 298 minecraft:cyan_concrete
setblock 47 198 304 minecraft:light_blue_wool
fill 47 198 305 47 251 305 minecraft:cyan_concrete
fill 47 198 316 47 210 316 minecraft:cyan_concrete
setblock 48 198 276 minecraft:spruce_planks
fill 48 198 280 56 198 280 minecraft:spruce_log
setblock 48 198 283 minecraft:spruce_planks
setblock 48 198 290 minecraft:spruce_planks
setblock 48 198 297 minecraft:spruce_planks
setblock 48 198 304 minecraft:spruce_planks
setblock 48 198 311 minecraft:spruce_planks
fill 50 198 275 51 198 275 minecraft:cyan_concrete
setblock 50 198 316 minecraft:spruce_planks
setblock 55 198 276 minecraft:spruce_planks
setblock 57 198 316 minecraft:spruce_planks
fill 62 198 275 62 208 275 minecraft:cyan_concrete
setblock 62 198 276 minecraft:spruce_planks
setblock 63 198 275 minecraft:light_blue_wool
fill 64 198 275 67 247 275 minecraft:cyan_concrete
setblock 64 198 316 minecraft:spruce_planks
setblock 69 198 276 minecraft:spruce_planks
setblock 71 198 316 minecraft:spruce_planks
setblock 76 198 276 minecraft:spruce_planks
setblock 78 198 316 minecraft:spruce_planks
fill 80 198 281 80 199 291 minecraft:spruce_planks
fill 80 198 312 88 198 312 minecraft:spruce_log
fill 81 198 276 81 199 285 minecraft:spruce_planks
fill 82 198 276 82 199 277 minecraft:spruce_planks
setblock 83 198 276 minecraft:spruce_planks
setblock 85 198 316 minecraft:spruce_planks
setblock 88 198 278 minecraft:spruce_planks
setblock 88 198 285 minecraft:spruce_planks
setblock 88 198 292 minecraft:spruce_planks
setblock 88 198 299 minecraft:spruce_planks
setblock 88 198 306 minecraft:spruce_planks
setblock 88 198 313 minecraft:spruce_planks
setblock 89 198 287 minecraft:light_blue_wool
setblock 47 199 280 minecraft:light_blue_wool
fill 47 199 292 47 237 294 minecraft:cyan_concrete
setblock 47 199 295 minecraft:light_blue_wool
fill 47 199 296 47 216 297 minecraft:cyan_concrete
fill 47 199 304 47 251 304 minecraft:cyan_concrete
fill 48 199 277 48 200 277 minecraft:spruce_planks
fill 48 199 284 48 200 284 minecraft:spruce_planks
fill 48 199 291 48 200 291 minecraft:spruce_planks
fill 48 199 298 48 200 298 minecraft:spruce_planks
fill 48 199 305 48 200 305 minecraft:spruce_planks
fill 48 199 312 48 200 312 minecraft:spruce_planks
setblock 50 199 275 minecraft:light_blue_wool
fill 51 199 275 51 247 275 minecraft:cyan_concrete
fill 51 199 280 53 214 280 minecraft:spruce_log
fill 51 199 316 51 200 316 minecraft:spruce_planks
fill 54 199 276 54 200 276 minecraft:spruce_planks
fill 58 199 316 58 200 316 minecraft:spruce_planks
fill 58 199 317 59 210 317 minecraft:cyan_concrete
setblock 60 199 317 minecraft:white_wool
fill 61 199 276 61 200 276 minecraft:spruce_planks
fill 63 199 275 63 251 275 minecraft:cyan_concrete
fill 65 199 316 65 200 316 minecraft:spruce_planks
fill 68 199 276 68 200 276 minecraft:spruce_planks
fill 72 199 316 72 200 316 minecraft:spruce_planks
fill 75 199 276 75 200 276 minecraft:spruce_planks
fill 77 199 307 77 199 316 minecraft:spruce_planks
fill 78 199 298 78 199 314 minecraft:spruce_planks
fill 79 199 289 79 199 306 minecraft:spruce_planks
fill 79 199 316 79 200 316 minecraft:spruce_planks
setblock 80 199 280 minecraft:spruce_planks
fill 80 199 292 80 199 297 minecraft:spruce_planks
fill 81 199 286 81 199 287 minecraft:spruce_planks
fill 83 199 312 85 214 312 minecraft:spruce_log
fill 86 199 312 86 214 312 minecraft:spruce_planks
fill 86 199 316 86 200 316 minecraft:spruce_planks
fill 88 199 277 88 200 277 minecraft:spruce_planks
fill 88 199 284 88 200 284 minecraft:spruce_planks
fill 88 199 291 88 200 291 minecraft:spruce_planks
fill 88 199 298 88 200 298 minecraft:spruce_planks
fill 88 199 305 88 200 305 minecraft:spruce_planks
fill 88 199 312 88 200 312 minecraft:spruce_planks
fill 89 199 287 89 203 287 minecraft:cyan_concrete
fill 89 199 301 89 203 307 minecraft:cyan_concrete
setblock 89 199 308 minecraft:light_blue_wool
fill 89 199 309 89 208 316 minecraft:cyan_concrete
fill 47 200 280 47 251 280 minecraft:cyan_concrete
fill 47 200 295 47 251 295 minecraft:cyan_concrete
fill 48 200 276 49 200 276 minecraft:spruce_planks
fill 48 200 278 48 200 280 minecraft:spruce_planks
fill 48 200 282 48 200 283 minecraft:spruce_planks
fill 48 200 285 48 200 287 minecraft:spruce_planks
fill 48 200 289 48 200 290 minecraft:spruce_planks
fill 48 200 292 48 200 294 minecraft:spruce_planks
fill 48 200 296 48 200 297 minecraft:spruce_planks
fill 48 200 299 48 200 301 minecraft:spruce_planks
fill 48 200 303 48 200 304 minecraft:spruce_planks
fill 48 200 306 48 200 308 minecraft:spruce_planks
fill 48 200 310 48 200 311 minecraft:spruce_planks
fill 48 200 313 48 200 315 minecraft:spruce_planks
fill 49 200 316 50 200 316 minecraft:spruce_planks
fill 50 200 275 50 221 275 minecraft:cyan_concrete
fill 50 200 310 51 200 310 minecraft:dark_oak_planks
setblock 50 200 313 minecraft:dark_oak_planks
fill 51 200 276 53 200 276 minecraft:spruce_planks
fill 51 200 314 52 200 314 minecraft:dark_oak_planks
fill 52 200 316 54 200 316 minecraft:spruce_planks
setblock 53 200 310 minecraft:dark_oak_planks
setblock 53 200 313 minecraft:dark_oak_planks
fill 54 200 311 54 200 312 minecraft:dark_oak_planks
fill 55 200 276 56 200 276 minecraft:spruce_planks
fill 56 200 316 57 200 316 minecraft:spruce_planks
fill 58 200 276 60 200 276 minecraft:spruce_planks
fill 59 200 316 61 200 316 minecraft:spruce_planks
fill 60 200 317 60 206 317 minecraft:cyan_concrete
fill 62 200 276 63 200 276 minecraft:spruce_planks
fill 63 200 316 64 200 316 minecraft:spruce_planks
fill 65 200 276 67 200 276 minecraft:spruce_planks
fill 66 200 316 68 200 316 minecraft:spruce_planks
fill 68 200 275 68 241 275 minecraft:cyan_concrete
setblock 69 200 275 minecraft:light_blue_wool
fill 69 200 276 70 200 276 minecraft:spruce_planks
fill 70 200 275 70 222 275 minecraft:cyan_concrete
fill 70 200 316 71 200 316 minecraft:spruce_planks
fill 72 200 276 74 200 276 minecraft:spruce_planks
fill 73 200 316 75 200 316 minecraft:spruce_planks
fill 76 200 276 77 200 276 minecraft:spruce_planks
fill 77 200 309 77 200 316 minecraft:spruce_planks
fill 78 200 302 78 200 314 minecraft:spruce_planks
setblock 78 200 316 minecraft:spruce_planks
fill 79 200 276 84 200 276 minecraft:spruce_planks
fill 79 200 294 79 200 295 minecraft:dark_oak_planks
fill 79 200 296 79 200 302 minecraft:spruce_planks
fill 80 200 283 80 200 292 minecraft:dark_oak_planks
fill 80 200 316 82 200 316 minecraft:spruce_planks
fill 81 200 277 81 200 283 minecraft:dark_oak_planks
fill 82 200 311 82 200 312 minecraft:dark_oak_planks
fill 83 200 310 86 200 310 minecraft:dark_oak_planks
fill 83 200 313 83 200 314 minecraft:dark_oak_planks
fill 84 200 314 85 200 314 minecraft:dark_oak_planks
fill 84 200 316 85 200 316 minecraft:spruce_planks
fill 86 200 276 88 200 276 minecraft:spruce_planks
setblock 86 200 311 minecraft:dark_oak_planks
setblock 86 200 313 minecraft:dark_oak_planks
fill 87 200 316 88 200 316 minecraft:spruce_planks
fill 88 200 278 88 200 279 minecraft:spruce_planks
fill 88 200 281 88 200 283 minecraft:spruce_planks
fill 88 200 285 88 200 286 minecraft:spruce_planks
fill 88 200 288 88 200 290 minecraft:spruce_planks
fill 88 200 292 88 200 293 minecraft:spruce_planks
fill 88 200 295 88 200 297 minecraft:spruce_planks
fill 88 200 299 88 200 300 minecraft:spruce_planks
fill 88 200 302 88 200 304 minecraft:spruce_planks
fill 88 200 306 88 200 307 minecraft:spruce_planks
fill 88 200 309 88 200 311 minecraft:spruce_planks
fill 88 200 313 88 200 314 minecraft:spruce_planks
fill 89 200 308 89 225 308 minecraft:cyan_concrete
setblock 48 201 279 minecraft:spruce_planks
setblock 48 201 286 minecraft:spruce_planks
setblock 48 201 293 minecraft:spruce_planks
setblock 48 201 300 minecraft:spruce_planks
setblock 48 201 307 minecraft:spruce_planks
setblock 48 201 314 minecraft:spruce_planks
setblock 50 201 278 minecraft:light[level=15]
setblock 50 201 285 minecraft:light[level=12]
setblock 50 201 286 minecraft:light[level=15]
setblock 50 201 292 minecraft:light[level=12]
setblock 50 201 294 minecraft:light[level=15]
setblock 50 201 299 minecraft:light[level=12]
setblock 50 201 302 minecraft:light[level=15]
setblock 50 201 306 minecraft:light[level=12]
setblock 50 201 310 minecraft:light[level=15]
setblock 50 201 313 minecraft:light[level=12]
setblock 52 201 276 minecraft:spruce_planks
setblock 53 201 316 minecraft:spruce_planks
setblock 57 201 278 minecraft:light[level=12]
setblock 57 201 285 minecraft:light[level=12]
setblock 57 201 292 minecraft:light[level=12]
setblock 57 201 299 minecraft:light[level=12]
setblock 57 201 306 minecraft:light[level=12]
setblock 57 201 313 minecraft:light[level=12]
setblock 58 201 278 minecraft:light[level=15]
setblock 58 201 286 minecraft:light[level=15]
setblock 58 201 294 minecraft:light[level=15]
setblock 58 201 302 minecraft:light[level=15]
setblock 58 201 310 minecraft:light[level=15]
setblock 59 201 276 minecraft:spruce_planks
setblock 60 201 316 minecraft:spruce_planks
setblock 64 201 278 minecraft:light[level=12]
setblock 64 201 285 minecraft:light[level=12]
setblock 64 201 292 minecraft:light[level=12]
setblock 64 201 299 minecraft:light[level=12]
setblock 64 201 306 minecraft:light[level=12]
setblock 64 201 313 minecraft:light[level=12]
setblock 66 201 276 minecraft:spruce_planks
setblock 66 201 278 minecraft:light[level=15]
setblock 66 201 286 minecraft:light[level=15]
setblock 66 201 294 minecraft:light[level=15]
setblock 66 201 302 minecraft:light[level=15]
setblock 66 201 310 minecraft:light[level=15]
setblock 67 201 316 minecraft:spruce_planks
fill 69 201 275 69 248 275 minecraft:cyan_concrete
setblock 71 201 278 minecraft:light[level=12]
setblock 71 201 285 minecraft:light[level=12]
setblock 71 201 292 minecraft:light[level=12]
setblock 71 201 299 minecraft:light[level=12]
setblock 71 201 306 minecraft:light[level=12]
setblock 71 201 313 minecraft:light[level=12]
setblock 73 201 276 minecraft:spruce_planks
setblock 74 201 278 minecraft:light[level=15]
setblock 74 201 286 minecraft:light[level=15]
setblock 74 201 294 minecraft:light[level=15]
setblock 74 201 302 minecraft:light[level=15]
setblock 74 201 310 minecraft:light[level=15]
setblock 74 201 316 minecraft:spruce_planks
fill 77 201 311 77 201 316 minecraft:dark_oak_planks
setblock 78 201 278 minecraft:light[level=12]
setblock 78 201 285 minecraft:light[level=12]
setblock 78 201 292 minecraft:light[level=12]
setblock 78 201 299 minecraft:light[level=12]
fill 78 201 304 78 201 311 minecraft:dark_oak_planks
setblock 78 201 313 minecraft:light[level=12]
fill 79 201 298 79 201 299 minecraft:dark_oak_planks
setblock 80 201 276 minecraft:spruce_planks
setblock 81 201 316 minecraft:spruce_planks
setblock 82 201 278 minecraft:light[level=15]
setblock 82 201 286 minecraft:light[level=15]
setblock 82 201 294 minecraft:light[level=15]
setblock 82 201 302 minecraft:light[level=15]
setblock 82 201 310 minecraft:light[level=15]
setblock 85 201 278 minecraft:light[level=12]
setblock 85 201 285 minecraft:light[level=12]
setblock 85 201 292 minecraft:light[level=12]
setblock 85 201 299 minecraft:light[level=12]
setblock 85 201 306 minecraft:light[level=12]
setblock 87 201 276 minecraft:spruce_planks
setblock 88 201 282 minecraft:spruce_planks
setblock 88 201 289 minecraft:spruce_planks
setblock 88 201 296 minecraft:spruce_planks
setblock 88 201 303 minecraft:spruce_planks
setblock 88 201 310 minecraft:spruce_planks
setblock 88 201 316 minecraft:spruce_planks
setblock 48 202 280 minecraft:spruce_planks
setblock 48 202 287 minecraft:spruce_planks
setblock 48 202 294 minecraft:spruce_planks
setblock 48 202 301 minecraft:spruce_planks
setblock 48 202 308 minecraft:spruce_planks
setblock 48 202 315 minecraft:spruce_planks
setblock 51 202 276 minecraft:spruce_planks
setblock 54 202 316 minecraft:spruce_planks
setblock 58 202 276 minecraft:spruce_planks
setblock 61 202 316 minecraft:spruce_planks
setblock 65 202 276 minecraft:spruce_planks
setblock 68 202 316 minecraft:spruce_planks
setblock 72 202 276 minecraft:spruce_planks
setblock 75 202 316 minecraft:spruce_planks
setblock 79 202 276 minecraft:spruce_planks
setblock 82 202 316 minecraft:spruce_planks
setblock 86 202 276 minecraft:spruce_planks
setblock 88 202 281 minecraft:spruce_planks
setblock 88 202 288 minecraft:spruce_planks
setblock 88 202 295 minecraft:spruce_planks
setblock 88 202 302 minecraft:spruce_planks
setblock 88 202 309 minecraft:spruce_planks
setblock 89 202 284 minecraft:light_blue_wool
fill 89 202 285 89 237 286 minecraft:cyan_concrete
fill 47 203 299 47 231 299 minecraft:cyan_concrete
setblock 47 203 300 minecraft:white_wool
fill 47 203 301 47 247 303 minecraft:cyan_concrete
fill 89 203 276 89 251 276 minecraft:cyan_concrete
setblock 89 203 277 minecraft:light_blue_wool
fill 89 203 284 89 249 284 minecraft:cyan_concrete
fill 47 204 300 47 251 300 minecraft:cyan_concrete
setblock 48 204 282 minecraft:spruce_planks
setblock 48 204 289 minecraft:spruce_planks
setblock 48 204 296 minecraft:spruce_planks
setblock 48 204 303 minecraft:spruce_planks
setblock 48 204 310 minecraft:spruce_planks
setblock 49 204 276 minecraft:spruce_planks
setblock 49 204 316 minecraft:spruce_planks
setblock 56 204 276 minecraft:spruce_planks
setblock 56 204 316 minecraft:spruce_planks
setblock 63 204 276 minecraft:spruce_planks
setblock 63 204 316 minecraft:spruce_planks
fill 69 204 276 69 204 278 minecraft:iron_bars
setblock 70 204 276 minecraft:spruce_planks
setblock 70 204 316 minecraft:spruce_planks
setblock 77 204 276 minecraft:spruce_planks
setblock 77 204 316 minecraft:spruce_planks
setblock 84 204 276 minecraft:spruce_planks
setblock 84 204 316 minecraft:spruce_planks
fill 85 204 287 87 205 287 minecraft:iron_bars
setblock 88 204 279 minecraft:spruce_planks
setblock 88 204 286 minecraft:spruce_planks
setblock 88 204 293 minecraft:spruce_planks
setblock 88 204 300 minecraft:spruce_planks
setblock 88 204 307 minecraft:spruce_planks
setblock 88 204 314 minecraft:spruce_planks
fill 89 204 277 89 247 277 minecraft:cyan_concrete
setblock 89 204 287 minecraft:light_blue_wool
setblock 89 204 301 minecraft:white_wool
fill 89 204 302 89 207 307 minecraft:cyan_concrete
fill 47 205 275 47 251 275 minecraft:cyan_concrete
setblock 47 205 276 minecraft:light_blue_wool
fill 47 205 277 47 239 278 minecraft:cyan_concrete
setblock 48 205 276 minecraft:spruce_planks
setblock 48 205 283 minecraft:spruce_planks
setblock 48 205 290 minecraft:spruce_planks
setblock 48 205 297 minecraft:spruce_planks
setblock 48 205 304 minecraft:spruce_planks
setblock 48 205 311 minecraft:spruce_planks
setblock 50 205 316 minecraft:spruce_planks
setblock 55 205 276 minecraft:spruce_planks
setblock 57 205 316 minecraft:spruce_planks
setblock 62 205 276 minecraft:spruce_planks
setblock 64 205 316 minecraft:spruce_planks
fill 65 205 317 69 221 317 minecraft:cyan_concrete
setblock 69 205 276 minecraft:spruce_planks
fill 69 205 277 69 205 278 minecraft:iron_bars
setblock 70 205 317 minecraft:white_wool
setblock 71 205 316 minecraft:spruce_planks
fill 71 205 317 72 230 317 minecraft:cyan_concrete
fill 74 205 317 74 206 317 minecraft:light_blue_wool
setblock 76 205 276 minecraft:spruce_planks
setblock 78 205 316 minecraft:spruce_planks
setblock 83 205 276 minecraft:spruce_planks
setblock 85 205 316 minecraft:spruce_planks
setblock 88 205 278 minecraft:spruce_planks
setblock 88 205 285 minecraft:spruce_planks
setblock 88 205 292 minecraft:spruce_planks
setblock 88 205 299 minecraft:spruce_planks
setblock 88 205 306 minecraft:spruce_planks
setblock 88 205 313 minecraft:spruce_planks
fill 89 205 287 89 251 287 minecraft:cyan_concrete
fill 89 205 301 89 251 301 minecraft:cyan_concrete
fill 47 206 276 47 249 276 minecraft:cyan_concrete
fill 47 206 286 47 223 286 minecraft:cyan_concrete
setblock 47 206 287 minecraft:light_blue_wool
fill 48 206 275 48 250 275 minecraft:cyan_concrete
setblock 48 206 277 minecraft:spruce_planks
setblock 48 206 284 minecraft:spruce_planks
setblock 48 206 291 minecraft:spruce_planks
setblock 48 206 298 minecraft:spruce_planks
setblock 48 206 305 minecraft:spruce_planks
setblock 48 206 312 minecraft:spruce_planks
fill 49 206 275 49 207 275 minecraft:white_wool
setblock 51 206 316 minecraft:spruce_planks
setblock 54 206 276 minecraft:spruce_planks
setblock 58 206 316 minecraft:spruce_planks
setblock 61 206 276 minecraft:spruce_planks
setblock 65 206 316 minecraft:spruce_planks
setblock 68 206 276 minecraft:spruce_planks
fill 70 206 317 70 251 317 minecraft:cyan_concrete
setblock 72 206 316 minecraft:spruce_planks
setblock 75 206 276 minecraft:spruce_planks
setblock 79 206 316 minecraft:spruce_planks
setblock 82 206 276 minecraft:spruce_planks
setblock 86 206 316 minecraft:spruce_planks
setblock 88 206 277 minecraft:spruce_planks
setblock 88 206 284 minecraft:spruce_planks
setblock 88 206 291 minecraft:spruce_planks
setblock 88 206 298 minecraft:spruce_planks
setblock 88 206 305 minecraft:spruce_planks
setblock 88 206 312 minecraft:spruce_planks
fill 47 207 287 47 247 287 minecraft:cyan_concrete
setblock 48 207 278 minecraft:spruce_planks
setblock 48 207 285 minecraft:spruce_planks
setblock 48 207 292 minecraft:spruce_planks
setblock 48 207 299 minecraft:spruce_planks
setblock 48 207 306 minecraft:spruce_planks
setblock 48 207 313 minecraft:spruce_planks
setblock 50 207 278 minecraft:light[level=12]
setblock 50 207 285 minecraft:light[level=12]
setblock 50 207 292 minecraft:light[level=12]
setblock 50 207 299 minecraft:light[level=12]
setblock 50 207 306 minecraft:light[level=12]
setblock 50 207 313 minecraft:light[level=12]
setblock 52 207 316 minecraft:spruce_planks
setblock 53 207 276 minecraft:spruce_planks
setblock 57 207 278 minecraft:light[level=12]
setblock 57 207 285 minecraft:light[level=12]
setblock 57 207 292 minecraft:light[level=12]
setblock 57 207 299 minecraft:light[level=12]
setblock 57 207 306 minecraft:light[level=12]
setblock 57 207 313 minecraft:light[level=12]
setblock 59 207 316 minecraft:spruce_planks
setblock 60 207 276 minecraft:spruce_planks
setblock 60 207 317 minecraft:white_wool
setblock 64 207 278 minecraft:light[level=12]
fill 64 207 279 64 216 279 minecraft:green_terracotta
setblock 64 207 285 minecraft:light[level=12]
setblock 64 207 292 minecraft:light[level=12]
setblock 64 207 299 minecraft:light[level=12]
setblock 64 207 306 minecraft:light[level=12]
setblock 64 207 313 minecraft:light[level=12]
setblock 66 207 316 minecraft:spruce_planks
setblock 67 207 276 minecraft:spruce_planks
setblock 71 207 278 minecraft:light[level=12]
setblock 71 207 285 minecraft:light[level=12]
setblock 71 207 292 minecraft:light[level=12]
setblock 71 207 299 minecraft:light[level=12]
setblock 71 207 306 minecraft:light[level=12]
setblock 71 207 313 minecraft:light[level=12]
setblock 73 207 316 minecraft:spruce_planks
setblock 74 207 276 minecraft:spruce_planks
fill 74 207 317 74 251 317 minecraft:cyan_concrete
setblock 78 207 278 minecraft:light[level=12]
setblock 78 207 285 minecraft:light[level=12]
setblock 78 207 292 minecraft:light[level=12]
setblock 78 207 299 minecraft:light[level=12]
setblock 78 207 306 minecraft:light[level=12]
setblock 78 207 313 minecraft:light[level=12]
setblock 80 207 316 minecraft:spruce_planks
setblock 81 207 276 minecraft:spruce_planks
setblock 85 207 278 minecraft:light[level=12]
setblock 85 207 285 minecraft:light[level=12]
setblock 85 207 292 minecraft:light[level=12]
setblock 85 207 299 minecraft:light[level=12]
setblock 85 207 306 minecraft:light[level=12]
setblock 87 207 316 minecraft:spruce_planks
setblock 88 207 276 minecraft:spruce_planks
setblock 88 207 283 minecraft:spruce_planks
setblock 88 207 290 minecraft:spruce_planks
setblock 88 207 297 minecraft:spruce_planks
setblock 88 207 304 minecraft:spruce_planks
setblock 88 207 311 minecraft:spruce_planks
setblock 48 208 279 minecraft:spruce_planks
setblock 48 208 286 minecraft:spruce_planks
setblock 48 208 293 minecraft:spruce_planks
setblock 48 208 300 minecraft:spruce_planks
setblock 48 208 307 minecraft:spruce_planks
setblock 48 208 314 minecraft:spruce_planks
setblock 48 208 317 minecraft:light_blue_wool
fill 49 208 275 49 242 275 minecraft:cyan_concrete
fill 50 208 310 51 208 310 minecraft:dark_oak_planks
setblock 50 208 313 minecraft:dark_oak_planks
fill 51 208 314 52 208 314 minecraft:dark_oak_planks
setblock 52 208 276 minecraft:spruce_planks
fill 52 208 315 52 209 315 minecraft:iron_bars
fill 52 208 317 54 247 317 minecraft:cyan_concrete
setblock 53 208 310 minecraft:dark_oak_planks
setblock 53 208 313 minecraft:dark_oak_planks
setblock 53 208 316 minecraft:spruce_planks
fill 54 208 311 54 208 312 minecraft:dark_oak_planks
setblock 55 208 317 minecraft:white_wool
setblock 59 208 276 minecraft:spruce_planks
setblock 60 208 316 minecraft:spruce_planks
fill 60 208 317 60 248 317 minecraft:cyan_concrete
setblock 63 208 317 minecraft:light_blue_wool
setblock 66 208 276 minecraft:spruce_planks
setblock 67 208 316 minecraft:spruce_planks
setblock 73 208 276 minecraft:spruce_planks
setblock 74 208 316 minecraft:spruce_planks
setblock 80 208 276 minecraft:spruce_planks
setblock 81 208 316 minecraft:spruce_planks
fill 82 208 311 82 208 312 minecraft:dark_oak_planks
fill 83 208 310 86 208 310 minecraft:dark_oak_planks
fill 83 208 313 83 208 314 minecraft:dark_oak_planks
fill 84 208 314 85 208 314 minecraft:dark_oak_planks
setblock 86 208 311 minecraft:dark_oak_planks
setblock 86 208 313 minecraft:dark_oak_planks
setblock 87 208 276 minecraft:spruce_planks
setblock 88 208 282 minecraft:spruce_planks
setblock 88 208 289 minecraft:spruce_planks
setblock 88 208 296 minecraft:spruce_planks
setblock 88 208 303 minecraft:spruce_planks
setblock 88 208 310 minecraft:spruce_planks
setblock 88 208 316 minecraft:spruce_planks
fill 89 208 302 89 208 305 minecraft:cyan_concrete
setblock 89 208 306 minecraft:white_wool
fill 89 208 307 89 217 307 minecraft:cyan_concrete
fill 48 209 280 48 210 280 minecraft:spruce_planks
fill 48 209 287 48 210 287 minecraft:spruce_planks
fill 48 209 294 48 210 294 minecraft:spruce_planks
fill 48 209 301 48 210 301 minecraft:spruce_planks
fill 48 209 308 48 210 308 minecraft:spruce_planks
fill 48 209 315 48 210 315 minecraft:spruce_planks
fill 48 209 317 48 239 317 minecraft:cyan_concrete
setblock 50 209 278 minecraft:light[level=15]
setblock 50 209 286 minecraft:light[level=15]
setblock 50 209 294 minecraft:light[level=15]
setblock 50 209 302 minecraft:light[level=15]
setblock 50 209 310 minecraft:light[level=15]
fill 51 209 276 51 210 276 minecraft:spruce_planks
setblock 52 209 314 minecraft:iron_bars
fill 54 209 316 54 210 316 minecraft:spruce_planks
fill 55 209 317 55 212 317 minecraft:cyan_concrete
fill 58 209 276 58 210 276 minecraft:spruce_planks
setblock 58 209 278 minecraft:light[level=15]
setblock 58 209 286 minecraft:light[level=15]
setblock 58 209 294 minecraft:light[level=15]
setblock 58 209 302 minecraft:light[level=15]
setblock 58 209 310 minecraft:light[level=15]
fill 61 209 316 61 210 316 minecraft:spruce_planks
setblock 62 209 275 minecraft:white_wool
fill 63 209 317 63 247 317 minecraft:cyan_concrete
fill 65 209 276 65 210 276 minecraft:spruce_planks
setblock 66 209 278 minecraft:light[level=15]
setblock 66 209 286 minecraft:light[level=15]
setblock 66 209 294 minecraft:light[level=15]
setblock 66 209 302 minecraft:light[level=15]
setblock 66 209 310 minecraft:light[level=15]
fill 68 209 316 68 210 316 minecraft:spruce_planks
fill 72 209 276 72 210 276 minecraft:spruce_planks
setblock 74 209 278 minecraft:light[level=15]
setblock 74 209 286 minecraft:light[level=15]
setblock 74 209 294 minecraft:light[level=15]
setblock 74 209 302 minecraft:light[level=15]
setblock 74 209 310 minecraft:light[level=15]
fill 75 209 316 75 210 316 minecraft:spruce_planks
fill 79 209 276 79 210 276 minecraft:spruce_planks
setblock 82 209 278 minecraft:light[level=15]
setblock 82 209 286 minecraft:light[level=15]
setblock 82 209 294 minecraft:light[level=15]
setblock 82 209 302 minecraft:light[level=15]
setblock 82 209 310 minecraft:light[level=15]
fill 82 209 316 82 210 316 minecraft:spruce_planks
fill 86 209 276 86 210 276 minecraft:spruce_planks
fill 88 209 281 88 210 281 minecraft:spruce_planks
fill 88 209 288 88 210 288 minecraft:spruce_planks
fill 88 209 295 88 210 295 minecraft:spruce_planks
fill 88 209 302 88 210 302 minecraft:spruce_planks
fill 88 209 309 88 210 309 minecraft:spruce_planks
fill 89 209 302 89 217 303 minecraft:cyan_concrete
setblock 89 209 304 minecraft:light_blue_wool
fill 89 209 305 89 215 306 minecraft:cyan_concrete
fill 89 209 309 89 249 310 minecraft:cyan_concrete
setblock 89 209 311 minecraft:light_blue_wool
fill 89 209 312 89 225 316 minecraft:cyan_concrete
fill 48 210 276 48 210 279 minecraft:spruce_planks
fill 48 210 282 48 210 286 minecraft:spruce_planks
fill 48 210 289 48 210 293 minecraft:spruce_planks
fill 48 210 296 48 210 300 minecraft:spruce_planks
fill 48 210 303 48 210 307 minecraft:spruce_planks
fill 48 210 310 48 210 314 minecraft:spruce_planks
fill 49 210 276 49 211 276 minecraft:spruce_planks
fill 49 210 316 53 210 316 minecraft:spruce_planks
fill 52 210 276 56 210 276 minecraft:spruce_planks
fill 56 210 316 60 210 316 minecraft:spruce_planks
fill 59 210 276 63 210 276 minecraft:spruce_planks
fill 62 210 275 62 249 275 minecraft:cyan_concrete
fill 63 210 316 67 210 316 minecraft:spruce_planks
fill 66 210 276 70 210 276 minecraft:spruce_planks
fill 70 210 316 74 210 316 minecraft:spruce_planks
fill 73 210 276 77 210 276 minecraft:spruce_planks
fill 77 210 316 81 210 316 minecraft:spruce_planks
fill 80 210 276 84 210 276 minecraft:spruce_planks
fill 84 210 316 88 210 316 minecraft:spruce_planks
fill 87 210 276 88 210 276 minecraft:spruce_planks
fill 88 210 277 88 210 279 minecraft:spruce_planks
fill 88 210 282 88 210 286 minecraft:spruce_planks
fill 88 210 289 88 210 293 minecraft:spruce_planks
fill 88 210 296 88 210 300 minecraft:spruce_planks
fill 88 210 303 88 210 307 minecraft:spruce_planks
fill 88 210 310 88 210 314 minecraft:spruce_planks
fill 89 210 304 89 248 304 minecraft:cyan_concrete
fill 89 210 311 89 251 311 minecraft:cyan_concrete
setblock 47 211 316 minecraft:white_wool
setblock 48 211 282 minecraft:spruce_planks
setblock 48 211 289 minecraft:spruce_planks
setblock 48 211 296 minecraft:spruce_planks
setblock 48 211 303 minecraft:spruce_planks
setblock 48 211 310 minecraft:spruce_planks
setblock 49 211 316 minecraft:spruce_planks
setblock 56 211 276 minecraft:spruce_planks
setblock 56 211 316 minecraft:spruce_planks
fill 58 211 317 58 239 317 minecraft:cyan_concrete
setblock 59 211 317 minecraft:white_wool
setblock 63 211 276 minecraft:spruce_planks
setblock 63 211 316 minecraft:spruce_planks
setblock 70 211 276 minecraft:spruce_planks
setblock 70 211 316 minecraft:spruce_planks
setblock 77 211 276 minecraft:spruce_planks
setblock 77 211 316 minecraft:spruce_planks
setblock 84 211 276 minecraft:spruce_planks
setblock 84 211 316 minecraft:spruce_planks
setblock 88 211 279 minecraft:spruce_planks
setblock 88 211 286 minecraft:spruce_planks
setblock 88 211 293 minecraft:spruce_planks
setblock 88 211 300 minecraft:spruce_planks
setblock 88 211 307 minecraft:spruce_planks
setblock 88 211 314 minecraft:spruce_planks
setblock 47 212 282 minecraft:white_wool
setblock 47 212 288 minecraft:light_blue_wool
fill 47 212 289 47 237 291 minecraft:cyan_concrete
fill 47 212 316 47 239 316 minecraft:cyan_concrete
setblock 48 212 276 minecraft:spruce_planks
setblock 48 212 283 minecraft:spruce_planks
setblock 48 212 290 minecraft:spruce_planks
setblock 48 212 297 minecraft:spruce_planks
setblock 48 212 304 minecraft:spruce_planks
setblock 48 212 311 minecraft:spruce_planks
setblock 50 212 316 minecraft:spruce_planks
setblock 55 212 276 minecraft:spruce_planks
setblock 56 212 317 minecraft:white_wool
setblock 57 212 316 minecraft:spruce_planks
fill 59 212 317 59 252 317 minecraft:cyan_concrete
setblock 62 212 276 minecraft:spruce_planks
setblock 64 212 316 minecraft:spruce_planks
setblock 69 212 276 minecraft:spruce_planks
setblock 71 212 316 minecraft:spruce_planks
setblock 76 212 276 minecraft:spruce_planks
setblock 78 212 316 minecraft:spruce_planks
setblock 83 212 276 minecraft:spruce_planks
setblock 85 212 316 minecraft:spruce_planks
setblock 88 212 278 minecraft:spruce_planks
setblock 88 212 285 minecraft:spruce_planks
setblock 88 212 292 minecraft:spruce_planks
setblock 88 212 299 minecraft:spruce_planks
setblock 88 212 306 minecraft:spruce_planks
setblock 88 212 313 minecraft:spruce_planks
fill 47 213 282 47 251 282 minecraft:cyan_concrete
fill 47 213 288 47 251 288 minecraft:cyan_concrete
setblock 48 213 277 minecraft:spruce_planks
setblock 48 213 284 minecraft:spruce_planks
setblock 48 213 291 minecraft:spruce_planks
setblock 48 213 298 minecraft:spruce_planks
setblock 48 213 305 minecraft:spruce_planks
setblock 48 213 312 minecraft:spruce_planks
setblock 50 213 278 minecraft:light[level=12]
setblock 50 213 285 minecraft:light[level=12]
setblock 50 213 292 minecraft:light[level=12]
setblock 50 213 299 minecraft:light[level=12]
setblock 50 213 306 minecraft:light[level=12]
setblock 50 213 313 minecraft:light[level=12]
setblock 51 213 316 minecraft:spruce_planks
setblock 54 213 276 minecraft:spruce_planks
setblock 55 213 317 minecraft:white_wool
fill 56 213 317 56 228 317 minecraft:cyan_concrete
setblock 57 213 278 minecraft:light[level=12]
setblock 57 213 285 minecraft:light[level=12]
setblock 57 213 292 minecraft:light[level=12]
setblock 57 213 299 minecraft:light[level=12]
setblock 57 213 306 minecraft:light[level=12]
setblock 57 213 313 minecraft:light[level=12]
setblock 58 213 316 minecraft:spruce_planks
setblock 61 213 276 minecraft:spruce_planks
setblock 64 213 278 minecraft:light[level=12]
setblock 64 213 285 minecraft:light[level=12]
setblock 64 213 292 minecraft:light[level=12]
setblock 64 213 299 minecraft:light[level=12]
setblock 64 213 306 minecraft:light[level=12]
setblock 64 213 313 minecraft:light[level=12]
setblock 65 213 316 minecraft:spruce_planks
setblock 68 213 276 minecraft:spruce_planks
setblock 71 213 278 minecraft:light[level=12]
setblock 71 213 285 minecraft:light[level=12]
setblock 71 213 292 minecraft:light[level=12]
setblock 71 213 299 minecraft:light[level=12]
setblock 71 213 306 minecraft:light[level=12]
setblock 71 213 313 minecraft:light[level=12]
setblock 72 213 316 minecraft:spruce_planks
setblock 75 213 276 minecraft:spruce_planks
setblock 78 213 278 minecraft:light[level=12]
setblock 78 213 285 minecraft:light[level=12]
setblock 78 213 292 minecraft:light[level=12]
setblock 78 213 299 minecraft:light[level=12]
setblock 78 213 306 minecraft:light[level=12]
setblock 78 213 313 minecraft:light[level=12]
setblock 79 213 316 minecraft:spruce_planks
setblock 82 213 276 minecraft:spruce_planks
setblock 85 213 278 minecraft:light[level=12]
setblock 85 213 285 minecraft:light[level=12]
setblock 85 213 292 minecraft:light[level=12]
setblock 85 213 299 minecraft:light[level=12]
setblock 85 213 306 minecraft:light[level=12]
setblock 86 213 316 minecraft:spruce_planks
setblock 88 213 277 minecraft:spruce_planks
setblock 88 213 284 minecraft:spruce_planks
setblock 88 213 291 minecraft:spruce_planks
setblock 88 213 298 minecraft:spruce_planks
setblock 88 213 305 minecraft:spruce_planks
setblock 88 213 312 minecraft:spruce_planks
setblock 48 214 278 minecraft:spruce_planks
setblock 48 214 285 minecraft:spruce_planks
setblock 48 214 292 minecraft:spruce_planks
setblock 48 214 299 minecraft:spruce_planks
setblock 48 214 306 minecraft:spruce_planks
setblock 48 214 313 minecraft:spruce_planks
setblock 52 214 316 minecraft:spruce_planks
setblock 53 214 276 minecraft:spruce_planks
fill 55 214 317 55 251 317 minecraft:cyan_concrete
setblock 59 214 316 minecraft:spruce_planks
setblock 60 214 276 minecraft:spruce_planks
setblock 66 214 316 minecraft:spruce_planks
setblock 67 214 276 minecraft:spruce_planks
setblock 73 214 316 minecraft:spruce_planks
setblock 74 214 276 minecraft:spruce_planks
fill 75 214 317 75 251 317 minecraft:cyan_concrete
setblock 76 214 317 minecraft:white_wool
setblock 80 214 316 minecraft:spruce_planks
setblock 81 214 276 minecraft:spruce_planks
setblock 87 214 316 minecraft:spruce_planks
setblock 88 214 276 minecraft:spruce_planks
setblock 88 214 283 minecraft:spruce_planks
setblock 88 214 290 minecraft:spruce_planks
setblock 88 214 297 minecraft:spruce_planks
setblock 88 214 304 minecraft:spruce_planks
setblock 88 214 311 minecraft:spruce_planks
setblock 48 215 279 minecraft:spruce_planks
fill 48 215 280 56 221 280 minecraft:white_wool
setblock 48 215 286 minecraft:spruce_planks
setblock 48 215 293 minecraft:spruce_planks
setblock 48 215 300 minecraft:spruce_planks
setblock 48 215 307 minecraft:spruce_planks
setblock 48 215 314 minecraft:spruce_planks
setblock 52 215 276 minecraft:spruce_planks
setblock 53 215 316 minecraft:spruce_planks
setblock 59 215 276 minecraft:spruce_planks
setblock 60 215 316 minecraft:spruce_planks
setblock 66 215 276 minecraft:spruce_planks
setblock 67 215 316 minecraft:spruce_planks
fill 71 215 275 72 245 275 minecraft:cyan_concrete
setblock 73 215 275 minecraft:light_blue_wool
setblock 73 215 276 minecraft:spruce_planks
setblock 74 215 316 minecraft:spruce_planks
fill 76 215 317 76 251 317 minecraft:cyan_concrete
setblock 80 215 276 minecraft:spruce_planks
fill 80 215 312 88 221 312 minecraft:white_wool
setblock 81 215 316 minecraft:spruce_planks
setblock 87 215 276 minecraft:spruce_planks
setblock 88 215 282 minecraft:spruce_planks
setblock 88 215 289 minecraft:spruce_planks
setblock 88 215 296 minecraft:spruce_planks
setblock 88 215 303 minecraft:spruce_planks
setblock 88 215 310 minecraft:spruce_planks
setblock 88 215 316 minecraft:spruce_planks
setblock 47 216 284 minecraft:light_blue_wool
fill 47 216 285 47 251 285 minecraft:cyan_concrete
setblock 48 216 287 minecraft:spruce_planks
setblock 48 216 294 minecraft:spruce_planks
setblock 48 216 301 minecraft:spruce_planks
setblock 48 216 308 minecraft:spruce_planks
setblock 48 216 315 minecraft:spruce_planks
fill 50 216 310 51 216 310 minecraft:dark_oak_planks
setblock 50 216 313 minecraft:dark_oak_planks
setblock 51 216 276 minecraft:spruce_planks
fill 51 216 314 52 216 314 minecraft:dark_oak_planks
setblock 53 216 310 minecraft:dark_oak_planks
setblock 53 216 313 minecraft:dark_oak_planks
fill 54 216 311 54 216 312 minecraft:dark_oak_planks
setblock 54 216 316 minecraft:spruce_planks
setblock 58 216 276 minecraft:spruce_planks
setblock 61 216 316 minecraft:spruce_planks
setblock 65 216 276 minecraft:spruce_planks
setblock 68 216 316 minecraft:spruce_planks
setblock 72 216 276 minecraft:spruce_planks
fill 73 216 275 73 224 275 minecraft:cyan_concrete
setblock 75 216 316 minecraft:spruce_planks
setblock 79 216 276 minecraft:spruce_planks
setblock 82 216 311 minecraft:dark_oak_planks
setblock 82 216 316 minecraft:spruce_planks
fill 83 216 310 86 216 310 minecraft:dark_oak_planks
fill 83 216 313 83 216 314 minecraft:dark_oak_planks
fill 84 216 314 85 216 314 minecraft:dark_oak_planks
setblock 86 216 276 minecraft:spruce_planks
setblock 86 216 311 minecraft:dark_oak_planks
setblock 86 216 313 minecraft:dark_oak_planks
setblock 88 216 281 minecraft:spruce_planks
setblock 88 216 288 minecraft:spruce_planks
setblock 88 216 295 minecraft:spruce_planks
setblock 88 216 302 minecraft:spruce_planks
setblock 88 216 309 minecraft:spruce_planks
fill 89 216 305 89 250 305 minecraft:cyan_concrete
setblock 89 216 306 minecraft:light_blue_wool
setblock 47 217 281 minecraft:white_wool
fill 47 217 284 47 218 284 minecraft:cyan_concrete
setblock 47 217 296 minecraft:light_blue_wool
fill 47 217 297 47 251 297 minecraft:cyan_concrete
setblock 50 217 278 minecraft:light[level=15]
setblock 50 217 286 minecraft:light[level=15]
setblock 50 217 294 minecraft:light[level=15]
setblock 50 217 302 minecraft:light[level=15]
setblock 50 217 310 minecraft:light[level=15]
setblock 58 217 278 minecraft:light[level=15]
setblock 58 217 286 minecraft:light[level=15]
setblock 58 217 294 minecraft:light[level=15]
setblock 58 217 302 minecraft:light[level=15]
setblock 58 217 310 minecraft:light[level=15]
setblock 66 217 278 minecraft:light[level=15]
setblock 66 217 286 minecraft:light[level=15]
setblock 66 217 294 minecraft:light[level=15]
setblock 66 217 302 minecraft:light[level=15]
setblock 66 217 310 minecraft:light[level=15]
setblock 74 217 278 minecraft:light[level=15]
setblock 74 217 286 minecraft:light[level=15]
setblock 74 217 294 minecraft:light[level=15]
setblock 74 217 302 minecraft:light[level=15]
setblock 74 217 310 minecraft:light[level=15]
setblock 82 217 278 minecraft:light[level=15]
setblock 82 217 286 minecraft:light[level=15]
setblock 82 217 294 minecraft:light[level=15]
setblock 82 217 302 minecraft:light[level=15]
setblock 82 217 310 minecraft:light[level=15]
fill 89 217 306 89 252 306 minecraft:cyan_concrete
fill 47 218 281 47 223 281 minecraft:cyan_concrete
fill 47 218 296 47 237 296 minecraft:cyan_concrete
setblock 47 218 298 minecraft:white_wool
setblock 48 218 282 minecraft:spruce_planks
setblock 48 218 289 minecraft:spruce_planks
setblock 48 218 296 minecraft:spruce_planks
setblock 48 218 303 minecraft:spruce_planks
setblock 48 218 310 minecraft:spruce_planks
setblock 49 218 276 minecraft:spruce_planks
setblock 49 218 316 minecraft:spruce_planks
setblock 56 218 276 minecraft:spruce_planks
setblock 56 218 316 minecraft:spruce_planks
setblock 63 218 276 minecraft:spruce_planks
setblock 63 218 316 minecraft:spruce_planks
setblock 70 218 276 minecraft:spruce_planks
setblock 70 218 316 minecraft:spruce_planks
setblock 77 218 276 minecraft:spruce_planks
setblock 77 218 316 minecraft:spruce_planks
setblock 84 218 276 minecraft:spruce_planks
setblock 84 218 316 minecraft:spruce_planks
setblock 88 218 279 minecraft:spruce_planks
setblock 88 218 286 minecraft:spruce_planks
setblock 88 218 293 minecraft:spruce_planks
setblock 88 218 300 minecraft:spruce_planks
setblock 88 218 307 minecraft:spruce_planks
setblock 88 218 314 minecraft:spruce_planks
setblock 89 218 302 minecraft:white_wool
fill 89 218 303 89 251 303 minecraft:cyan_concrete
setblock 89 218 307 minecraft:white_wool
setblock 47 219 284 minecraft:white_wool
fill 47 219 298 47 251 298 minecraft:cyan_concrete
fill 48 219 276 48 220 276 minecraft:spruce_planks
fill 48 219 283 48 220 283 minecraft:spruce_planks
fill 48 219 290 48 220 290 minecraft:spruce_planks
fill 48 219 297 48 220 297 minecraft:spruce_planks
fill 48 219 304 48 220 304 minecraft:spruce_planks
fill 48 219 311 48 220 311 minecraft:spruce_planks
setblock 50 219 278 minecraft:light[level=12]
setblock 50 219 285 minecraft:light[level=12]
setblock 50 219 292 minecraft:light[level=12]
setblock 50 219 299 minecraft:light[level=12]
setblock 50 219 306 minecraft:light[level=12]
setblock 50 219 313 minecraft:light[level=12]
fill 50 219 316 50 220 316 minecraft:spruce_planks
fill 55 219 276 55 220 276 minecraft:spruce_planks
setblock 57 219 278 minecraft:light[level=12]
setblock 57 219 285 minecraft:light[level=12]
setblock 57 219 292 minecraft:light[level=12]
setblock 57 219 299 minecraft:light[level=12]
setblock 57 219 306 minecraft:light[level=12]
setblock 57 219 313 minecraft:light[level=12]
fill 57 219 316 57 220 316 minecraft:spruce_planks
fill 62 219 276 62 220 276 minecraft:spruce_planks
setblock 64 219 278 minecraft:light[level=12]
setblock 64 219 285 minecraft:light[level=12]
setblock 64 219 292 minecraft:light[level=12]
setblock 64 219 299 minecraft:light[level=12]
setblock 64 219 306 minecraft:light[level=12]
setblock 64 219 313 minecraft:light[level=12]
fill 64 219 316 64 220 316 minecraft:spruce_planks
fill 69 219 276 69 220 276 minecraft:spruce_planks
setblock 71 219 278 minecraft:light[level=12]
setblock 71 219 285 minecraft:light[level=12]
setblock 71 219 292 minecraft:light[level=12]
setblock 71 219 299 minecraft:light[level=12]
setblock 71 219 306 minecraft:light[level=12]
setblock 71 219 313 minecraft:light[level=12]
fill 71 219 316 71 220 316 minecraft:spruce_planks
fill 76 219 276 76 220 276 minecraft:spruce_planks
setblock 78 219 278 minecraft:light[level=12]
setblock 78 219 285 minecraft:light[level=12]
setblock 78 219 292 minecraft:light[level=12]
setblock 78 219 299 minecraft:light[level=12]
setblock 78 219 306 minecraft:light[level=12]
setblock 78 219 313 minecraft:light[level=12]
fill 78 219 316 78 220 316 minecraft:spruce_planks
fill 83 219 276 83 220 276 minecraft:spruce_planks
setblock 85 219 278 minecraft:light[level=12]
setblock 85 219 285 minecraft:light[level=12]
setblock 85 219 292 minecraft:light[level=12]
setblock 85 219 299 minecraft:light[level=12]
setblock 85 219 306 minecraft:light[level=12]
fill 85 219 316 85 220 316 minecraft:spruce_planks
fill 88 219 278 88 220 278 minecraft:spruce_planks
fill 88 219 285 88 220 285 minecraft:spruce_planks
fill 88 219 292 88 220 292 minecraft:spruce_planks
fill 88 219 299 88 220 299 minecraft:spruce_planks
fill 88 219 306 88 220 306 minecraft:spruce_planks
fill 88 219 313 88 220 313 minecraft:spruce_planks
fill 89 219 302 89 222 302 minecraft:cyan_concrete
fill 89 219 307 89 238 307 minecraft:cyan_concrete
fill 47 220 284 47 222 284 minecraft:cyan_concrete
fill 48 220 277 48 220 279 minecraft:spruce_planks
setblock 48 220 282 minecraft:spruce_planks
fill 48 220 284 48 220 287 minecraft:spruce_planks
setblock 48 220 289 minecraft:spruce_planks
fill 48 220 291 48 220 294 minecraft:spruce_planks
setblock 48 220 296 minecraft:spruce_planks
fill 48 220 298 48 220 301 minecraft:spruce_planks
setblock 48 220 303 minecraft:spruce_planks
fill 48 220 305 48 220 308 minecraft:spruce_planks
setblock 48 220 310 minecraft:spruce_planks
fill 48 220 312 48 220 315 minecraft:spruce_planks
setblock 49 220 276 minecraft:spruce_planks
fill 49 220 284 51 221 285 minecraft:spruce_planks
setblock 49 220 316 minecraft:spruce_planks
fill 51 220 276 54 220 276 minecraft:spruce_planks
fill 51 220 316 54 220 316 minecraft:spruce_planks
fill 52 220 285 53 221 285 minecraft:spruce_planks
setblock 56 220 276 minecraft:spruce_planks
setblock 56 220 316 minecraft:spruce_planks
fill 58 220 276 61 220 276 minecraft:spruce_planks
fill 58 220 316 61 220 316 minecraft:spruce_planks
setblock 63 220 276 minecraft:spruce_planks
setblock 63 220 316 minecraft:spruce_planks
fill 65 220 276 68 220 276 minecraft:spruce_planks
fill 65 220 316 68 220 316 minecraft:spruce_planks
setblock 70 220 276 minecraft:spruce_planks
setblock 70 220 316 minecraft:spruce_planks
fill 72 220 276 75 220 276 minecraft:spruce_planks
fill 72 220 316 75 220 316 minecraft:spruce_planks
setblock 77 220 276 minecraft:spruce_planks
setblock 77 220 316 minecraft:spruce_planks
fill 79 220 276 82 220 276 minecraft:spruce_planks
fill 79 220 316 82 220 316 minecraft:spruce_planks
setblock 84 220 276 minecraft:spruce_planks
setblock 84 220 316 minecraft:spruce_planks
fill 86 220 276 88 220 276 minecraft:spruce_planks
fill 86 220 316 88 220 316 minecraft:spruce_planks
setblock 88 220 277 minecraft:spruce_planks
setblock 88 220 279 minecraft:spruce_planks
fill 88 220 281 88 220 284 minecraft:spruce_planks
setblock 88 220 286 minecraft:spruce_planks
fill 88 220 288 88 220 291 minecraft:spruce_planks
setblock 88 220 293 minecraft:spruce_planks
fill 88 220 295 88 220 298 minecraft:spruce_planks
setblock 88 220 300 minecraft:spruce_planks
fill 88 220 302 88 220 305 minecraft:spruce_planks
setblock 88 220 307 minecraft:spruce_planks
fill 88 220 309 88 220 311 minecraft:spruce_planks
setblock 88 220 314 minecraft:spruce_planks
fill 89 220 290 89 221 297 minecraft:cyan_concrete
setblock 89 220 298 minecraft:white_wool
fill 89 220 299 89 251 300 minecraft:cyan_concrete
setblock 48 221 278 minecraft:spruce_planks
fill 48 221 284 48 221 285 minecraft:spruce_planks
setblock 48 221 292 minecraft:spruce_planks
setblock 48 221 299 minecraft:spruce_planks
setblock 48 221 306 minecraft:spruce_planks
setblock 48 221 313 minecraft:spruce_planks
fill 50 221 310 51 222 310 minecraft:dark_oak_planks
fill 50 221 313 50 222 313 minecraft:dark_oak_planks
fill 51 221 314 52 222 314 minecraft:dark_oak_planks
fill 52 221 284 59 221 284 minecraft:spruce_planks
setblock 52 221 316 minecraft:spruce_planks
setblock 53 221 276 minecraft:spruce_planks
fill 53 221 310 53 222 310 minecraft:dark_oak_planks
fill 53 221 313 53 222 313 minecraft:dark_oak_planks
fill 54 221 285 67 221 285 minecraft:spruce_planks
fill 54 221 312 54 222 312 minecraft:dark_oak_planks
setblock 59 221 316 minecraft:spruce_planks
setblock 60 221 276 minecraft:spruce_planks
setblock 66 221 316 minecraft:spruce_planks
setblock 67 221 276 minecraft:spruce_planks
setblock 73 221 316 minecraft:spruce_planks
setblock 74 221 276 minecraft:spruce_planks
fill 76 221 276 76 222 278 minecraft:iron_bars
setblock 80 221 316 minecraft:spruce_planks
setblock 81 221 276 minecraft:spruce_planks
fill 83 221 310 85 222 310 minecraft:dark_oak_planks
fill 83 221 313 83 222 313 minecraft:dark_oak_planks
fill 84 221 314 85 222 314 minecraft:dark_oak_planks
fill 84 221 317 87 228 317 minecraft:cyan_concrete
fill 86 221 311 86 222 311 minecraft:dark_oak_planks
fill 86 221 313 86 222 313 minecraft:dark_oak_planks
setblock 87 221 316 minecraft:spruce_planks
setblock 88 221 276 minecraft:spruce_planks
setblock 88 221 283 minecraft:spruce_planks
setblock 88 221 290 minecraft:spruce_planks
setblock 88 221 297 minecraft:spruce_planks
setblock 88 221 304 minecraft:spruce_planks
setblock 88 221 311 minecraft:spruce_planks
setblock 88 221 317 minecraft:white_wool
fill 89 221 298 89 251 298 minecraft:cyan_concrete
fill 89 221 317 89 249 317 minecraft:cyan_concrete
setblock 48 222 279 minecraft:spruce_planks
fill 48 222 280 56 222 280 minecraft:spruce_log
fill 48 222 284 50 222 284 minecraft:dark_oak_planks
setblock 48 222 286 minecraft:spruce_planks
setblock 48 222 293 minecraft:spruce_planks
setblock 48 222 300 minecraft:spruce_planks
setblock 48 222 307 minecraft:spruce_planks
setblock 48 222 314 minecraft:spruce_planks
fill 49 222 285 54 222 285 minecraft:dark_oak_planks
setblock 50 222 275 minecraft:light_blue_wool
setblock 52 222 276 minecraft:spruce_planks
setblock 53 222 316 minecraft:spruce_planks
setblock 54 222 310 minecraft:iron_bars
fill 55 222 285 77 222 285 minecraft:spruce_planks
setblock 59 222 276 minecraft:spruce_planks
setblock 60 222 316 minecraft:spruce_planks
fill 64 222 286 80 222 286 minecraft:spruce_planks
fill 65 222 317 66 227 317 minecraft:cyan_concrete
setblock 66 222 276 minecraft:spruce_planks
setblock 67 222 316 minecraft:spruce_planks
setblock 67 222 317 minecraft:light_blue_wool
fill 68 222 317 69 226 317 minecraft:cyan_concrete
setblock 73 222 276 minecraft:spruce_planks
setblock 74 222 316 minecraft:spruce_planks
setblock 80 222 276 minecraft:spruce_planks
fill 80 222 312 88 222 312 minecraft:spruce_log
setblock 81 222 316 minecraft:spruce_planks
setblock 87 222 276 minecraft:spruce_planks
setblock 88 222 282 minecraft:spruce_planks
setblock 88 222 289 minecraft:spruce_planks
setblock 88 222 296 minecraft:spruce_planks
setblock 88 222 303 minecraft:spruce_planks
setblock 88 222 310 minecraft:spruce_planks
setblock 88 222 316 minecraft:spruce_planks
fill 88 222 317 88 251 317 minecraft:cyan_concrete
setblock 89 222 289 minecraft:light_blue_wool
fill 89 222 290 89 223 296 minecraft:cyan_concrete
setblock 89 222 297 minecraft:light_blue_wool
setblock 47 223 284 minecraft:light_blue_wool
fill 47 223 306 47 251 306 minecraft:cyan_concrete
setblock 47 223 307 minecraft:light_blue_wool
fill 50 223 275 50 248 275 minecraft:cyan_concrete
fill 51 223 280 53 238 280 minecraft:spruce_log
fill 67 223 317 67 248 317 minecraft:cyan_concrete
setblock 70 223 275 minecraft:white_wool
fill 83 223 312 85 238 312 minecraft:spruce_log
fill 89 223 289 89 251 289 minecraft:cyan_concrete
fill 89 223 297 89 251 297 minecraft:cyan_concrete
setblock 89 223 302 minecraft:white_wool
setblock 47 224 281 minecraft:white_wool
fill 47 224 284 47 249 284 minecraft:cyan_concrete
setblock 47 224 286 minecraft:light_blue_wool
fill 47 224 307 47 249 310 minecraft:cyan_concrete
setblock 47 224 311 minecraft:white_wool
setblock 47 224 313 minecraft:white_wool
fill 70 224 275 70 248 275 minecraft:cyan_concrete
setblock 89 224 290 minecraft:white_wool
fill 89 224 291 89 238 296 minecraft:cyan_concrete
fill 89 224 302 89 251 302 minecraft:cyan_concrete
fill 47 225 281 47 251 281 minecraft:cyan_concrete
fill 47 225 286 47 252 286 minecraft:cyan_concrete
fill 47 225 311 47 251 311 minecraft:cyan_concrete
fill 47 225 313 47 229 313 minecraft:cyan_concrete
setblock 50 225 278 minecraft:light[level=15]
setblock 50 225 285 minecraft:light[level=12]
setblock 50 225 286 minecraft:light[level=15]
setblock 50 225 292 minecraft:light[level=12]
setblock 50 225 294 minecraft:light[level=15]
setblock 50 225 299 minecraft:light[level=12]
setblock 50 225 302 minecraft:light[level=15]
setblock 50 225 306 minecraft:light[level=12]
setblock 50 225 310 minecraft:light[level=15]
setblock 50 225 313 minecraft:light[level=12]
setblock 57 225 278 minecraft:light[level=12]
setblock 57 225 285 minecraft:light[level=12]
setblock 57 225 292 minecraft:light[level=12]
setblock 57 225 299 minecraft:light[level=12]
setblock 57 225 306 minecraft:light[level=12]
setblock 57 225 313 minecraft:light[level=12]
setblock 58 225 278 minecraft:light[level=15]
setblock 58 225 286 minecraft:light[level=15]
setblock 58 225 294 minecraft:light[level=15]
setblock 58 225 302 minecraft:light[level=15]
setblock 58 225 310 minecraft:light[level=15]
setblock 64 225 278 minecraft:light[level=12]
setblock 64 225 285 minecraft:light[level=12]
setblock 64 225 292 minecraft:light[level=12]
setblock 64 225 299 minecraft:light[level=12]
setblock 64 225 306 minecraft:light[level=12]
setblock 64 225 313 minecraft:light[level=12]
setblock 66 225 278 minecraft:light[level=15]
setblock 66 225 286 minecraft:light[level=15]
setblock 66 225 294 minecraft:light[level=15]
setblock 66 225 302 minecraft:light[level=15]
setblock 66 225 310 minecraft:light[level=15]
setblock 71 225 278 minecraft:light[level=12]
setblock 71 225 285 minecraft:light[level=12]
setblock 71 225 292 minecraft:light[level=12]
setblock 71 225 299 minecraft:light[level=12]
setblock 71 225 306 minecraft:light[level=12]
setblock 71 225 313 minecraft:light[level=12]
setblock 73 225 275 minecraft:white_wool
setblock 74 225 278 minecraft:light[level=15]
setblock 74 225 286 minecraft:light[level=15]
setblock 74 225 294 minecraft:light[level=15]
setblock 74 225 302 minecraft:light[level=15]
setblock 74 225 310 minecraft:light[level=15]
fill 75 225 275 78 232 275 minecraft:cyan_concrete
setblock 78 225 278 minecraft:light[level=12]
setblock 78 225 285 minecraft:light[level=12]
setblock 78 225 292 minecraft:light[level=12]
setblock 78 225 299 minecraft:light[level=12]
setblock 78 225 306 minecraft:light[level=12]
setblock 78 225 313 minecraft:light[level=12]
setblock 79 225 275 minecraft:light_blue_wool
setblock 82 225 278 minecraft:light[level=15]
setblock 82 225 286 minecraft:light[level=15]
setblock 82 225 294 minecraft:light[level=15]
setblock 82 225 302 minecraft:light[level=15]
setblock 82 225 310 minecraft:light[level=15]
setblock 85 225 278 minecraft:light[level=12]
setblock 85 225 285 minecraft:light[level=12]
setblock 85 225 292 minecraft:light[level=12]
setblock 85 225 299 minecraft:light[level=12]
setblock 85 225 306 minecraft:light[level=12]
setblock 85 225 313 minecraft:light[level=12]
fill 89 225 290 89 239 290 minecraft:cyan_concrete
fill 55 226 315 56 226 315 minecraft:white_concrete
setblock 56 226 275 minecraft:white_wool
fill 73 226 275 73 251 275 minecraft:cyan_concrete
fill 79 226 275 79 248 275 minecraft:cyan_concrete
setblock 85 226 275 minecraft:white_wool
fill 86 226 275 86 247 275 minecraft:cyan_concrete
setblock 89 226 308 minecraft:light_blue_wool
fill 89 226 312 89 226 313 minecraft:cyan_concrete
setblock 89 226 314 minecraft:light_blue_wool
fill 89 226 315 89 251 316 minecraft:cyan_concrete
fill 56 227 275 56 251 275 minecraft:cyan_concrete
setblock 68 227 317 minecraft:light_blue_wool
fill 69 227 317 69 249 317 minecraft:cyan_concrete
fill 85 227 275 85 251 275 minecraft:cyan_concrete
setblock 87 227 275 minecraft:light_blue_wool
fill 89 227 308 89 251 308 minecraft:cyan_concrete
setblock 89 227 312 minecraft:white_wool
fill 89 227 313 89 235 314 minecraft:cyan_concrete
fill 59 228 294 59 228 295 minecraft:spruce_planks
fill 59 228 296 61 229 296 minecraft:dark_oak_planks
fill 59 228 297 59 228 298 minecraft:spruce_planks
fill 60 228 292 60 228 294 minecraft:spruce_planks
fill 60 228 295 62 228 295 minecraft:dark_oak_planks
fill 60 228 297 62 228 297 minecraft:dark_oak_planks
fill 60 228 298 60 228 300 minecraft:spruce_planks
fill 61 228 291 63 228 293 minecraft:spruce_planks
fill 61 228 294 62 228 294 minecraft:dark_oak_planks
fill 61 228 298 62 228 298 minecraft:dark_oak_planks
fill 61 228 299 63 228 301 minecraft:spruce_planks
fill 63 228 290 67 228 290 minecraft:spruce_planks
fill 63 228 302 67 228 302 minecraft:spruce_planks
fill 64 228 291 69 228 292 minecraft:spruce_planks
setblock 64 228 293 minecraft:dark_oak_planks
setblock 64 228 299 minecraft:dark_oak_planks
fill 64 228 300 69 228 301 minecraft:spruce_planks
fill 65 228 317 65 251 317 minecraft:cyan_concrete
setblock 66 228 293 minecraft:dark_oak_planks
setblock 66 228 299 minecraft:dark_oak_planks
setblock 66 228 317 minecraft:light_blue_wool
fill 67 228 293 70 228 293 minecraft:spruce_planks
fill 67 228 299 70 228 299 minecraft:spruce_planks
fill 68 228 294 69 228 295 minecraft:dark_oak_planks
fill 68 228 297 69 228 298 minecraft:dark_oak_planks
fill 68 228 317 68 251 317 minecraft:cyan_concrete
fill 69 228 296 71 229 296 minecraft:dark_oak_planks
setblock 70 228 292 minecraft:spruce_planks
fill 70 228 294 71 228 294 minecraft:spruce_planks
fill 70 228 295 70 229 295 minecraft:dark_oak_planks
fill 70 228 297 70 229 297 minecraft:dark_oak_planks
fill 70 228 298 71 228 298 minecraft:spruce_planks
setblock 70 228 300 minecraft:spruce_planks
setblock 71 228 295 minecraft:spruce_planks
setblock 71 228 297 minecraft:spruce_planks
fill 87 228 275 87 247 275 minecraft:cyan_concrete
fill 89 228 312 89 251 312 minecraft:cyan_concrete
fill 48 229 276 48 229 277 minecraft:white_stained_glass
setblock 48 229 278 minecraft:light_blue_stained_glass
fill 48 229 279 48 229 281 minecraft:white_stained_glass
setblock 48 229 282 minecraft:light_blue_stained_glass
fill 48 229 283 48 229 285 minecraft:white_stained_glass
setblock 48 229 286 minecraft:light_blue_stained_glass
fill 48 229 287 48 229 289 minecraft:white_stained_glass
setblock 48 229 290 minecraft:light_blue_stained_glass
fill 48 229 291 48 229 293 minecraft:white_stained_glass
setblock 48 229 294 minecraft:light_blue_stained_glass
fill 48 229 295 48 229 297 minecraft:white_stained_glass
setblock 48 229 298 minecraft:light_blue_stained_glass
fill 48 229 299 48 229 301 minecraft:white_stained_glass
setblock 48 229 302 minecraft:light_blue_stained_glass
fill 48 229 303 48 229 305 minecraft:white_stained_glass
setblock 48 229 306 minecraft:light_blue_stained_glass
fill 48 229 307 48 229 309 minecraft:white_stained_glass
setblock 48 229 310 minecraft:light_blue_stained_glass
fill 48 229 311 48 229 313 minecraft:white_stained_glass
setblock 48 229 314 minecraft:light_blue_stained_glass
fill 48 229 315 49 229 316 minecraft:white_stained_glass
setblock 49 229 276 minecraft:white_stained_glass
setblock 49 229 277 minecraft:light_blue_stained_glass
fill 49 229 278 49 229 280 minecraft:white_stained_glass
setblock 49 229 281 minecraft:light_blue_stained_glass
fill 49 229 282 49 229 284 minecraft:white_stained_glass
setblock 49 229 285 minecraft:light_blue_stained_glass
fill 49 229 286 49 229 288 minecraft:white_stained_glass
setblock 49 229 289 minecraft:light_blue_stained_glass
fill 49 229 290 49 229 292 minecraft:white_stained_glass
setblock 49 229 293 minecraft:light_blue_stained_glass
fill 49 229 294 49 229 296 minecraft:white_stained_glass
setblock 49 229 297 minecraft:light_blue_stained_glass
fill 49 229 298 49 229 300 minecraft:white_stained_glass
setblock 49 229 301 minecraft:light_blue_stained_glass
fill 49 229 302 49 229 304 minecraft:white_stained_glass
setblock 49 229 305 minecraft:light_blue_stained_glass
fill 49 229 306 49 229 308 minecraft:white_stained_glass
setblock 49 229 309 minecraft:light_blue_stained_glass
fill 49 229 310 49 229 312 minecraft:white_stained_glass
setblock 49 229 313 minecraft:light_blue_stained_glass
fill 49 229 314 51 229 314 minecraft:white_stained_glass
setblock 50 229 276 minecraft:light_blue_stained_glass
fill 50 229 277 50 229 279 minecraft:white_stained_glass
setblock 50 229 280 minecraft:light_blue_stained_glass
fill 50 229 281 50 229 283 minecraft:white_stained_glass
setblock 50 229 284 minecraft:light_blue_stained_glass
fill 50 229 285 50 229 287 minecraft:white_stained_glass
setblock 50 229 288 minecraft:light_blue_stained_glass
fill 50 229 289 50 229 291 minecraft:white_stained_glass
setblock 50 229 292 minecraft:light_blue_stained_glass
fill 50 229 293 50 229 295 minecraft:white_stained_glass
setblock 50 229 296 minecraft:light_blue_stained_glass
fill 50 229 297 50 229 299 minecraft:white_stained_glass
setblock 50 229 300 minecraft:light_blue_stained_glass
fill 50 229 301 50 229 303 minecraft:white_stained_glass
setblock 50 229 304 minecraft:light_blue_stained_glass
fill 50 229 305 50 229 307 minecraft:white_stained_glass
setblock 50 229 308 minecraft:light_blue_stained_glass
fill 50 229 309 50 229 311 minecraft:white_stained_glass
setblock 50 229 312 minecraft:light_blue_stained_glass
fill 50 229 313 52 229 313 minecraft:white_stained_glass
setblock 50 229 315 minecraft:white_stained_glass
setblock 50 229 316 minecraft:light_blue_stained_glass
fill 51 229 276 51 229 278 minecraft:white_stained_glass
setblock 51 229 279 minecraft:light_blue_stained_glass
fill 51 229 281 51 229 282 minecraft:white_stained_glass
setblock 51 229 283 minecraft:light_blue_stained_glass
fill 51 229 284 51 229 286 minecraft:white_stained_glass
setblock 51 229 287 minecraft:light_blue_stained_glass
fill 51 229 288 51 229 290 minecraft:white_stained_glass
setblock 51 229 291 minecraft:light_blue_stained_glass
fill 51 229 292 51 229 294 minecraft:white_stained_glass
setblock 51 229 295 minecraft:light_blue_stained_glass
fill 51 229 296 51 229 298 minecraft:white_stained_glass
setblock 51 229 299 minecraft:light_blue_stained_glass
fill 51 229 300 51 229 302 minecraft:white_stained_glass
setblock 51 229 303 minecraft:light_blue_stained_glass
fill 51 229 304 51 229 306 minecraft:white_stained_glass
setblock 51 229 307 minecraft:light_blue_stained_glass
fill 51 229 308 51 229 310 minecraft:white_stained_glass
setblock 51 229 311 minecraft:light_blue_stained_glass
fill 51 229 312 53 229 312 minecraft:white_stained_glass
setblock 51 229 315 minecraft:light_blue_stained_glass
fill 51 229 316 53 229 316 minecraft:white_stained_glass
fill 52 229 276 52 229 277 minecraft:white_stained_glass
setblock 52 229 278 minecraft:light_blue_stained_glass
setblock 52 229 282 minecraft:light_blue_stained_glass
fill 52 229 283 52 229 285 minecraft:white_stained_glass
setblock 52 229 286 minecraft:light_blue_stained_glass
fill 52 229 287 52 229 289 minecraft:white_stained_glass
setblock 52 229 290 minecraft:light_blue_stained_glass
fill 52 229 291 52 229 293 minecraft:white_stained_glass
setblock 52 229 294 minecraft:light_blue_stained_glass
fill 52 229 295 52 229 297 minecraft:white_stained_glass
setblock 52 229 298 minecraft:light_blue_stained_glass
fill 52 229 299 52 229 301 minecraft:white_stained_glass
setblock 52 229 302 minecraft:light_blue_stained_glass
fill 52 229 303 52 229 305 minecraft:white_stained_glass
setblock 52 229 306 minecraft:light_blue_stained_glass
fill 52 229 307 52 229 309 minecraft:white_stained_glass
setblock 52 229 310 minecraft:light_blue_stained_glass
fill 52 229 311 54 229 311 minecraft:white_stained_glass
setblock 52 229 314 minecraft:light_blue_stained_glass
fill 52 229 315 54 229 315 minecraft:white_stained_glass
setblock 53 229 276 minecraft:white_stained_glass
setblock 53 229 277 minecraft:light_blue_stained_glass
fill 53 229 278 54 229 279 minecraft:white_stained_glass
setblock 53 229 281 minecraft:light_blue_stained_glass
fill 53 229 282 53 229 284 minecraft:white_stained_glass
setblock 53 229 285 minecraft:light_blue_stained_glass
fill 53 229 286 53 229 288 minecraft:white_stained_glass
setblock 53 229 289 minecraft:light_blue_stained_glass
fill 53 229 290 53 229 292 minecraft:white_stained_glass
setblock 53 229 293 minecraft:light_blue_stained_glass
fill 53 229 294 53 229 296 minecraft:white_stained_glass
setblock 53 229 297 minecraft:light_blue_stained_glass
fill 53 229 298 53 229 300 minecraft:white_stained_glass
setblock 53 229 301 minecraft:light_blue_stained_glass
fill 53 229 302 53 229 304 minecraft:white_stained_glass
setblock 53 229 305 minecraft:light_blue_stained_glass
fill 53 229 306 53 229 308 minecraft:white_stained_glass
setblock 53 229 309 minecraft:light_blue_stained_glass
fill 53 229 310 55 229 310 minecraft:white_stained_glass
setblock 53 229 313 minecraft:light_blue_stained_glass
fill 53 229 314 55 229 314 minecraft:white_stained_glass
setblock 54 229 276 minecraft:light_blue_stained_glass
fill 54 229 277 56 229 277 minecraft:white_stained_glass
setblock 54 229 280 minecraft:light_blue_stained_glass
fill 54 229 281 54 229 283 minecraft:white_stained_glass
setblock 54 229 284 minecraft:light_blue_stained_glass
fill 54 229 285 54 229 287 minecraft:white_stained_glass
setblock 54 229 288 minecraft:light_blue_stained_glass
fill 54 229 289 54 229 291 minecraft:white_stained_glass
setblock 54 229 292 minecraft:light_blue_stained_glass
fill 54 229 293 54 229 295 minecraft:white_stained_glass
setblock 54 229 296 minecraft:light_blue_stained_glass
fill 54 229 297 54 229 299 minecraft:white_stained_glass
setblock 54 229 300 minecraft:light_blue_stained_glass
fill 54 229 301 54 229 303 minecraft:white_stained_glass
setblock 54 229 304 minecraft:light_blue_stained_glass
fill 54 229 305 54 229 307 minecraft:white_stained_glass
setblock 54 229 308 minecraft:light_blue_stained_glass
fill 54 229 309 56 229 309 minecraft:white_stained_glass
setblock 54 229 312 minecraft:light_blue_stained_glass
fill 54 229 313 56 229 313 minecraft:white_stained_glass
setblock 54 229 316 minecraft:light_blue_stained_glass
fill 55 229 276 57 229 276 minecraft:white_stained_glass
setblock 55 229 278 minecraft:white_stained_glass
setblock 55 229 279 minecraft:light_blue_stained_glass
fill 55 229 280 55 229 282 minecraft:white_stained_glass
setblock 55 229 283 minecraft:light_blue_stained_glass
fill 55 229 284 55 229 286 minecraft:white_stained_glass
setblock 55 229 287 minecraft:light_blue_stained_glass
fill 55 229 288 55 229 290 minecraft:white_stained_glass
setblock 55 229 291 minecraft:light_blue_stained_glass
fill 55 229 292 55 229 294 minecraft:white_stained_glass
setblock 55 229 295 minecraft:light_blue_stained_glass
fill 55 229 296 55 229 298 minecraft:white_stained_glass
setblock 55 229 299 minecraft:light_blue_stained_glass
fill 55 229 300 55 229 302 minecraft:white_stained_glass
setblock 55 229 303 minecraft:light_blue_stained_glass
fill 55 229 304 55 229 306 minecraft:white_stained_glass
setblock 55 229 307 minecraft:light_blue_stained_glass
fill 55 229 308 57 229 308 minecraft:white_stained_glass
setblock 55 229 311 minecraft:light_blue_stained_glass
fill 55 229 312 57 229 312 minecraft:white_stained_glass
setblock 55 229 315 minecraft:light_blue_stained_glass
fill 55 229 316 57 229 316 minecraft:white_stained_glass
setblock 56 229 278 minecraft:light_blue_stained_glass
fill 56 229 279 56 229 281 minecraft:white_stained_glass
setblock 56 229 282 minecraft:light_blue_stained_glass
fill 56 229 283 56 229 285 minecraft:white_stained_glass
setblock 56 229 286 minecraft:light_blue_stained_glass
fill 56 229 287 56 229 289 minecraft:white_stained_glass
setblock 56 229 290 minecraft:light_blue_stained_glass
fill 56 229 291 56 229 293 minecraft:white_stained_glass
fill 56 229 294 58 229 298 minecraft:dark_oak_planks
fill 56 229 299 56 229 301 minecraft:white_stained_glass
setblock 56 229 302 minecraft:light_blue_stained_glass
fill 56 229 303 56 229 305 minecraft:white_stained_glass
setblock 56 229 306 minecraft:light_blue_stained_glass
fill 56 229 307 58 229 307 minecraft:white_stained_glass
setblock 56 229 310 minecraft:light_blue_stained_glass
fill 56 229 311 58 229 311 minecraft:white_stained_glass
setblock 56 229 314 minecraft:light_blue_stained_glass
fill 56 229 315 58 229 315 minecraft:white_stained_glass
setblock 56 229 317 minecraft:white_wool
setblock 57 229 277 minecraft:light_blue_stained_glass
fill 57 229 278 57 229 280 minecraft:white_stained_glass
setblock 57 229 281 minecraft:light_blue_stained_glass
fill 57 229 282 57 229 284 minecraft:white_stained_glass
setblock 57 229 285 minecraft:light_blue_stained_glass
fill 57 229 286 57 229 288 minecraft:white_stained_glass
setblock 57 229 289 minecraft:light_blue_stained_glass
fill 57 229 290 57 229 292 minecraft:white_stained_glass
setblock 57 229 293 minecraft:light_blue_stained_glass
fill 57 229 299 57 229 300 minecraft:white_stained_glass
setblock 57 229 301 minecraft:light_blue_stained_glass
fill 57 229 302 57 229 304 minecraft:white_stained_glass
setblock 57 229 305 minecraft:light_blue_stained_glass
fill 57 229 306 59 229 306 minecraft:white_stained_glass
setblock 57 229 309 minecraft:light_blue_stained_glass
fill 57 229 310 59 229 310 minecraft:white_stained_glass
setblock 57 229 313 minecraft:light_blue_stained_glass
fill 57 229 314 59 229 314 minecraft:white_stained_glass
setblock 58 229 276 minecraft:light_blue_stained_glass
fill 58 229 277 58 229 279 minecraft:white_stained_glass
setblock 58 229 280 minecraft:light_blue_stained_glass
fill 58 229 281 58 229 283 minecraft:white_stained_glass
setblock 58 229 284 minecraft:light_blue_stained_glass
fill 58 229 285 58 229 287 minecraft:white_stained_glass
setblock 58 229 288 minecraft:light_blue_stained_glass
fill 58 229 289 58 229 291 minecraft:white_stained_glass
setblock 58 229 292 minecraft:light_blue_stained_glass
fill 58 229 293 62 229 293 minecraft:dark_oak_planks
fill 58 229 299 62 229 299 minecraft:dark_oak_planks
setblock 58 229 300 minecraft:light_blue_stained_glass
fill 58 229 301 58 229 303 minecraft:white_stained_glass
setblock 58 229 304 minecraft:light_blue_stained_glass
fill 58 229 305 60 229 305 minecraft:white_stained_glass
setblock 58 229 308 minecraft:light_blue_stained_glass
fill 58 229 309 60 229 309 minecraft:white_stained_glass
setblock 58 229 312 minecraft:light_blue_stained_glass
fill 58 229 313 60 229 313 minecraft:white_stained_glass
setblock 58 229 316 minecraft:light_blue_stained_glass
fill 59 229 276 59 229 278 minecraft:white_stained_glass
setblock 59 229 279 minecraft:light_blue_stained_glass
fill 59 229 280 59 229 282 minecraft:white_stained_glass
setblock 59 229 283 minecraft:light_blue_stained_glass
fill 59 229 284 59 229 286 minecraft:white_stained_glass
setblock 59 229 287 minecraft:light_blue_stained_glass
fill 59 229 288 59 229 290 minecraft:white_stained_glass
setblock 59 229 291 minecraft:light_blue_stained_glass
setblock 59 229 292 minecraft:white_stained_glass
fill 59 229 294 61 229 295 minecraft:dark_oak_planks
fill 59 229 297 61 229 298 minecraft:dark_oak_planks
fill 59 229 300 59 229 302 minecraft:white_stained_glass
setblock 59 229 303 minecraft:light_blue_stained_glass
fill 59 229 304 61 229 304 minecraft:white_stained_glass
setblock 59 229 307 minecraft:light_blue_stained_glass
fill 59 229 308 61 229 308 minecraft:white_stained_glass
setblock 59 229 311 minecraft:light_blue_stained_glass
fill 59 229 312 61 229 312 minecraft:white_stained_glass
setblock 59 229 315 minecraft:light_blue_stained_glass
fill 59 229 316 61 229 316 minecraft:white_stained_glass
fill 60 229 276 60 229 277 minecraft:white_stained_glass
setblock 60 229 278 minecraft:light_blue_stained_glass
fill 60 229 279 60 229 281 minecraft:white_stained_glass
setblock 60 229 282 minecraft:light_blue_stained_glass
fill 60 229 283 60 229 285 minecraft:white_stained_glass
setblock 60 229 286 minecraft:light_blue_stained_glass
fill 60 229 287 60 229 289 minecraft:white_stained_glass
setblock 60 229 290 minecraft:light_blue_stained_glass
setblock 60 229 291 minecraft:white_stained_glass
fill 60 229 292 70 229 292 minecraft:dark_oak_planks
fill 60 229 300 70 229 300 minecraft:dark_oak_planks
setblock 60 229 301 minecraft:white_stained_glass
setblock 60 229 302 minecraft:light_blue_stained_glass
fill 60 229 303 62 229 303 minecraft:white_stained_glass
setblock 60 229 306 minecraft:light_blue_stained_glass
fill 60 229 307 62 229 307 minecraft:white_stained_glass
setblock 60 229 310 minecraft:light_blue_stained_glass
fill 60 229 311 62 229 311 minecraft:white_stained_glass
setblock 60 229 314 minecraft:light_blue_stained_glass
fill 60 229 315 62 229 315 minecraft:white_stained_glass
setblock 61 229 276 minecraft:white_stained_glass
setblock 61 229 277 minecraft:light_blue_stained_glass
fill 61 229 278 61 229 280 minecraft:white_stained_glass
setblock 61 229 281 minecraft:light_blue_stained_glass
fill 61 229 282 61 229 284 minecraft:white_stained_glass
setblock 61 229 285 minecraft:light_blue_stained_glass
fill 61 229 286 61 229 288 minecraft:white_stained_glass
setblock 61 229 289 minecraft:light_blue_stained_glass
fill 61 229 290 62 229 290 minecraft:white_stained_glass
fill 61 229 291 62 231 291 minecraft:dark_oak_planks
fill 61 229 301 62 231 301 minecraft:dark_oak_planks
fill 61 229 302 62 229 302 minecraft:white_stained_glass
setblock 61 229 305 minecraft:light_blue_stained_glass
fill 61 229 306 63 229 306 minecraft:white_stained_glass
setblock 61 229 309 minecraft:light_blue_stained_glass
fill 61 229 310 63 229 310 minecraft:white_stained_glass
setblock 61 229 313 minecraft:light_blue_stained_glass
fill 61 229 314 63 229 314 minecraft:white_stained_glass
setblock 62 229 276 minecraft:light_blue_stained_glass
fill 62 229 277 62 229 279 minecraft:white_stained_glass
setblock 62 229 280 minecraft:light_blue_stained_glass
fill 62 229 281 62 229 283 minecraft:white_stained_glass
setblock 62 229 284 minecraft:light_blue_stained_glass
fill 62 229 285 62 229 287 minecraft:white_stained_glass
setblock 62 229 288 minecraft:light_blue_stained_glass
fill 62 229 289 64 229 289 minecraft:white_stained_glass
fill 62 229 294 62 229 295 minecraft:sea_lantern
fill 62 229 297 62 229 298 minecraft:sea_lantern
setblock 62 229 304 minecraft:light_blue_stained_glass
fill 62 229 305 64 229 305 minecraft:white_stained_glass
setblock 62 229 308 minecraft:light_blue_stained_glass
fill 62 229 309 64 229 309 minecraft:white_stained_glass
setblock 62 229 312 minecraft:light_blue_stained_glass
fill 62 229 313 64 229 313 minecraft:white_stained_glass
setblock 62 229 316 minecraft:light_blue_stained_glass
fill 63 229 276 63 229 278 minecraft:white_stained_glass
setblock 63 229 279 minecraft:light_blue_stained_glass
fill 63 229 280 63 229 282 minecraft:white_stained_glass
setblock 63 229 283 minecraft:light_blue_stained_glass
fill 63 229 284 63 229 286 minecraft:white_stained_glass
setblock 63 229 287 minecraft:light_blue_stained_glass
fill 63 229 288 65 229 288 minecraft:white_stained_glass
fill 63 229 290 67 232 290 minecraft:dark_oak_planks
setblock 63 229 291 minecraft:spruce_log
fill 63 229 293 64 229 293 minecraft:sea_lantern
fill 63 229 299 64 229 299 minecraft:sea_lantern
setblock 63 229 301 minecraft:spruce_log
fill 63 229 302 67 232 302 minecraft:dark_oak_planks
setblock 63 229 303 minecraft:light_blue_stained_glass
fill 63 229 304 65 229 304 minecraft:white_stained_glass
setblock 63 229 307 minecraft:light_blue_stained_glass
fill 63 229 308 65 229 308 minecraft:white_stained_glass
setblock 63 229 311 minecraft:light_blue_stained_glass
fill 63 229 312 65 229 312 minecraft:white_stained_glass
setblock 63 229 315 minecraft:light_blue_stained_glass
fill 63 229 316 65 229 316 minecraft:white_stained_glass
fill 64 229 276 64 229 277 minecraft:white_stained_glass
setblock 64 229 278 minecraft:light_blue_stained_glass
fill 64 229 279 64 229 281 minecraft:white_stained_glass
setblock 64 229 282 minecraft:light_blue_stained_glass
fill 64 229 283 64 229 285 minecraft:white_stained_glass
setblock 64 229 286 minecraft:light_blue_stained_glass
fill 64 229 287 66 229 287 minecraft:white_stained_glass
fill 64 229 291 66 229 291 minecraft:spruce_planks
fill 64 229 301 66 229 301 minecraft:spruce_planks
fill 64 229 303 66 229 303 minecraft:white_stained_glass
setblock 64 229 306 minecraft:light_blue_stained_glass
fill 64 229 307 66 229 307 minecraft:white_stained_glass
setblock 64 229 310 minecraft:light_blue_stained_glass
fill 64 229 311 66 229 311 minecraft:white_stained_glass
setblock 64 229 314 minecraft:light_blue_stained_glass
fill 64 229 315 66 229 315 minecraft:white_stained_glass
setblock 65 229 276 minecraft:white_stained_glass
setblock 65 229 277 minecraft:light_blue_stained_glass
fill 65 229 278 65 229 280 minecraft:white_stained_glass
setblock 65 229 281 minecraft:light_blue_stained_glass
fill 65 229 282 65 229 284 minecraft:white_stained_glass
setblock 65 229 285 minecraft:light_blue_stained_glass
fill 65 229 286 67 229 286 minecraft:white_stained_glass
setblock 65 229 289 minecraft:light_blue_stained_glass
setblock 65 229 305 minecraft:light_blue_stained_glass
fill 65 229 306 67 229 306 minecraft:white_stained_glass
setblock 65 229 309 minecraft:light_blue_stained_glass
fill 65 229 310 67 229 310 minecraft:white_stained_glass
setblock 65 229 313 minecraft:light_blue_stained_glass
fill 65 229 314 67 229 314 minecraft:white_stained_glass
setblock 66 229 276 minecraft:light_blue_stained_glass
fill 66 229 277 66 229 279 minecraft:white_stained_glass
setblock 66 229 280 minecraft:light_blue_stained_glass
fill 66 229 281 66 229 283 minecraft:white_stained_glass
setblock 66 229 284 minecraft:light_blue_stained_glass
fill 66 229 285 68 229 285 minecraft:white_stained_glass
schedule function dropper:buildpart/61_3 1t
