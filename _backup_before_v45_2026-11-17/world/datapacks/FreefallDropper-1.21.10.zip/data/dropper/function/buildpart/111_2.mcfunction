setblock 152 225 498 minecraft:light[level=14]
setblock 160 225 466 minecraft:light[level=14]
setblock 160 225 474 minecraft:light[level=14]
setblock 160 225 482 minecraft:light[level=14]
setblock 160 225 490 minecraft:light[level=14]
setblock 160 225 498 minecraft:light[level=14]
setblock 168 225 466 minecraft:light[level=14]
setblock 168 225 474 minecraft:light[level=14]
setblock 168 225 482 minecraft:light[level=14]
setblock 168 225 490 minecraft:light[level=14]
setblock 168 225 498 minecraft:light[level=14]
fill 174 225 505 174 245 505 minecraft:purpur_block
setblock 176 225 466 minecraft:light[level=14]
setblock 176 225 474 minecraft:light[level=14]
setblock 176 225 482 minecraft:light[level=14]
setblock 176 225 490 minecraft:light[level=14]
setblock 176 225 498 minecraft:light[level=14]
setblock 141 226 500 minecraft:magenta_stained_glass
setblock 141 226 502 minecraft:magenta_stained_glass
setblock 161 226 505 minecraft:white_concrete
fill 162 226 505 162 274 505 minecraft:purpur_block
fill 141 227 500 141 228 500 minecraft:purpur_block
fill 141 227 502 141 228 502 minecraft:purpur_block
fill 161 227 505 161 243 505 minecraft:purpur_block
setblock 183 227 465 minecraft:pearlescent_froglight
setblock 148 228 463 minecraft:magenta_stained_glass
fill 149 228 463 149 233 463 minecraft:purpur_block
fill 149 228 505 150 231 505 minecraft:purpur_block
setblock 151 228 505 minecraft:pearlescent_froglight
fill 152 228 505 153 233 505 minecraft:purpur_block
setblock 167 228 463 minecraft:white_concrete
fill 168 228 463 169 243 463 minecraft:purpur_block
fill 183 228 465 183 251 465 minecraft:purpur_block
setblock 141 229 500 minecraft:white_concrete
setblock 141 229 502 minecraft:pearlescent_froglight
fill 148 229 463 148 269 463 minecraft:purpur_block
fill 151 229 505 151 248 505 minecraft:purpur_block
fill 167 229 463 167 248 463 minecraft:purpur_block
fill 183 229 466 183 295 468 minecraft:purpur_block
setblock 183 229 469 minecraft:white_concrete
fill 141 230 500 141 235 500 minecraft:purpur_block
fill 141 230 502 141 250 502 minecraft:purpur_block
setblock 153 230 463 minecraft:magenta_stained_glass
fill 183 230 469 183 307 469 minecraft:purpur_block
fill 153 231 463 153 307 463 minecraft:purpur_block
fill 154 231 489 156 232 489 minecraft:purpur_block
fill 155 231 488 155 232 488 minecraft:purpur_block
fill 155 231 490 155 232 490 minecraft:purpur_block
setblock 179 231 505 minecraft:pearlescent_froglight
setblock 149 232 505 minecraft:magenta_stained_glass
fill 150 232 505 150 236 505 minecraft:purpur_block
setblock 155 232 463 minecraft:white_concrete
fill 156 232 463 156 250 463 minecraft:purpur_block
setblock 158 232 463 minecraft:white_concrete
setblock 161 232 463 minecraft:white_concrete
setblock 171 232 505 minecraft:white_concrete
fill 179 232 505 179 307 505 minecraft:purpur_block
setblock 183 232 500 minecraft:pearlescent_froglight
setblock 144 233 466 minecraft:light[level=14]
setblock 144 233 474 minecraft:light[level=14]
setblock 144 233 482 minecraft:light[level=14]
setblock 144 233 490 minecraft:light[level=14]
setblock 144 233 498 minecraft:light[level=14]
fill 149 233 505 149 249 505 minecraft:purpur_block
setblock 152 233 466 minecraft:light[level=14]
setblock 152 233 474 minecraft:light[level=14]
setblock 152 233 482 minecraft:light[level=14]
setblock 152 233 490 minecraft:light[level=14]
setblock 152 233 498 minecraft:light[level=14]
fill 155 233 463 155 246 463 minecraft:purpur_block
fill 158 233 463 158 257 463 minecraft:purpur_block
setblock 160 233 466 minecraft:light[level=14]
setblock 160 233 474 minecraft:light[level=14]
setblock 160 233 482 minecraft:light[level=14]
setblock 160 233 490 minecraft:light[level=14]
setblock 160 233 498 minecraft:light[level=14]
setblock 161 233 463 minecraft:purpur_block
setblock 168 233 466 minecraft:light[level=14]
setblock 168 233 474 minecraft:light[level=14]
setblock 168 233 482 minecraft:light[level=14]
setblock 168 233 490 minecraft:light[level=14]
setblock 168 233 498 minecraft:light[level=14]
setblock 171 233 505 minecraft:purpur_block
setblock 176 233 466 minecraft:light[level=14]
setblock 176 233 474 minecraft:light[level=14]
setblock 176 233 482 minecraft:light[level=14]
setblock 176 233 490 minecraft:light[level=14]
setblock 176 233 498 minecraft:light[level=14]
fill 183 233 500 183 307 500 minecraft:purpur_block
fill 141 234 471 141 236 471 minecraft:magenta_concrete
fill 141 234 472 141 293 472 minecraft:purpur_block
fill 141 234 487 141 236 487 minecraft:magenta_concrete
fill 141 234 503 141 236 503 minecraft:magenta_concrete
fill 145 234 463 145 236 463 minecraft:magenta_concrete
setblock 146 234 505 minecraft:magenta_stained_glass
fill 147 234 505 147 247 505 minecraft:purpur_block
setblock 149 234 463 minecraft:pearlescent_froglight
fill 152 234 505 152 307 505 minecraft:purpur_block
setblock 153 234 505 minecraft:pearlescent_froglight
fill 155 234 505 155 236 505 minecraft:magenta_concrete
fill 156 234 505 156 307 505 minecraft:purpur_block
setblock 157 234 505 minecraft:pearlescent_froglight
fill 158 234 505 159 258 505 minecraft:purpur_block
fill 161 234 463 161 236 463 minecraft:magenta_concrete
fill 164 234 463 164 242 463 minecraft:purpur_block
setblock 165 234 463 minecraft:pearlescent_froglight
fill 171 234 505 171 236 505 minecraft:magenta_concrete
fill 177 234 463 177 236 463 minecraft:magenta_concrete
fill 183 234 473 183 236 473 minecraft:magenta_concrete
fill 183 234 489 183 236 489 minecraft:magenta_concrete
fill 146 235 505 146 238 505 minecraft:purpur_block
fill 149 235 463 149 246 463 minecraft:purpur_block
fill 153 235 505 153 242 505 minecraft:purpur_block
fill 157 235 505 157 288 505 minecraft:purpur_block
fill 165 235 463 165 239 463 minecraft:purpur_block
fill 166 235 474 168 236 474 minecraft:purpur_block
fill 167 235 473 167 236 473 minecraft:purpur_block
fill 167 235 475 167 236 475 minecraft:purpur_block
setblock 141 236 500 minecraft:pearlescent_froglight
fill 141 237 471 141 242 471 minecraft:purpur_block
fill 141 237 487 141 242 487 minecraft:purpur_block
fill 141 237 497 141 275 498 minecraft:purpur_block
setblock 141 237 499 minecraft:pearlescent_froglight
fill 141 237 500 141 253 500 minecraft:purpur_block
fill 141 237 503 141 242 503 minecraft:purpur_block
fill 145 237 463 145 242 463 minecraft:purpur_block
setblock 150 237 505 minecraft:white_concrete
fill 155 237 505 155 241 505 minecraft:purpur_block
fill 161 237 463 161 242 463 minecraft:purpur_block
fill 171 237 505 171 242 505 minecraft:purpur_block
setblock 174 237 463 minecraft:white_concrete
setblock 177 237 463 minecraft:purpur_block
fill 183 237 473 183 242 473 minecraft:purpur_block
fill 183 237 489 183 242 489 minecraft:purpur_block
setblock 141 238 486 minecraft:magenta_stained_glass
fill 141 238 491 141 239 491 minecraft:purpur_block
setblock 141 238 492 minecraft:pearlescent_froglight
fill 141 238 499 141 307 499 minecraft:purpur_block
fill 150 238 505 150 307 505 minecraft:purpur_block
setblock 154 238 505 minecraft:pearlescent_froglight
fill 174 238 463 174 287 463 minecraft:purpur_block
setblock 177 238 463 minecraft:magenta_stained_glass
setblock 180 238 505 minecraft:magenta_stained_glass
setblock 183 238 479 minecraft:magenta_stained_glass
fill 183 238 480 183 307 480 minecraft:purpur_block
fill 141 239 486 141 307 486 minecraft:purpur_block
fill 141 239 492 141 272 492 minecraft:purpur_block
setblock 146 239 505 minecraft:white_concrete
fill 154 239 486 154 240 486 minecraft:obsidian
fill 154 239 505 154 307 505 minecraft:purpur_block
setblock 166 239 505 minecraft:pearlescent_froglight
fill 167 239 505 170 247 505 minecraft:purpur_block
fill 173 239 478 173 240 478 minecraft:purpur_block
fill 177 239 463 177 242 463 minecraft:purpur_block
fill 180 239 505 180 307 505 minecraft:purpur_block
fill 183 239 479 183 297 479 minecraft:purpur_block
setblock 141 240 491 minecraft:magenta_stained_glass
fill 146 240 505 146 281 505 minecraft:purpur_block
setblock 165 240 463 minecraft:pearlescent_froglight
setblock 165 240 505 minecraft:magenta_stained_glass
fill 166 240 505 166 307 505 minecraft:purpur_block
setblock 141 241 467 minecraft:magenta_stained_glass
fill 141 241 491 141 307 491 minecraft:purpur_block
setblock 144 241 466 minecraft:light[level=14]
setblock 144 241 474 minecraft:light[level=14]
setblock 144 241 482 minecraft:light[level=14]
setblock 144 241 490 minecraft:light[level=14]
setblock 144 241 498 minecraft:light[level=14]
setblock 152 241 466 minecraft:light[level=14]
setblock 152 241 474 minecraft:light[level=14]
setblock 152 241 482 minecraft:light[level=14]
setblock 152 241 490 minecraft:light[level=14]
setblock 152 241 498 minecraft:light[level=14]
setblock 160 241 466 minecraft:light[level=14]
setblock 160 241 474 minecraft:light[level=14]
setblock 160 241 482 minecraft:light[level=14]
setblock 160 241 490 minecraft:light[level=14]
setblock 160 241 498 minecraft:light[level=14]
fill 165 241 463 165 307 463 minecraft:purpur_block
fill 165 241 505 165 251 505 minecraft:purpur_block
setblock 168 241 466 minecraft:light[level=14]
setblock 168 241 474 minecraft:light[level=14]
setblock 168 241 482 minecraft:light[level=14]
setblock 168 241 490 minecraft:light[level=14]
setblock 168 241 498 minecraft:light[level=14]
setblock 176 241 466 minecraft:light[level=14]
setblock 176 241 474 minecraft:light[level=14]
setblock 176 241 482 minecraft:light[level=14]
setblock 176 241 490 minecraft:light[level=14]
setblock 176 241 498 minecraft:light[level=14]
setblock 178 241 463 minecraft:magenta_stained_glass
fill 141 242 467 141 283 467 minecraft:purpur_block
setblock 155 242 505 minecraft:white_concrete
fill 178 242 463 178 307 463 minecraft:purpur_block
setblock 183 242 472 minecraft:magenta_stained_glass
setblock 183 242 477 minecraft:white_concrete
fill 141 243 471 141 245 471 minecraft:magenta_concrete
fill 141 243 487 141 245 487 minecraft:magenta_concrete
fill 141 243 503 141 245 503 minecraft:magenta_concrete
fill 145 243 463 145 245 463 minecraft:magenta_concrete
setblock 153 243 505 minecraft:magenta_stained_glass
fill 155 243 505 155 245 505 minecraft:magenta_concrete
fill 161 243 463 161 245 463 minecraft:magenta_concrete
setblock 164 243 463 minecraft:magenta_stained_glass
fill 171 243 505 171 245 505 minecraft:magenta_concrete
fill 177 243 463 177 245 463 minecraft:magenta_concrete
fill 183 243 472 183 307 472 minecraft:purpur_block
fill 183 243 473 183 245 473 minecraft:magenta_concrete
fill 183 243 477 183 245 477 minecraft:purpur_block
fill 183 243 489 183 245 489 minecraft:magenta_concrete
fill 183 243 490 183 307 490 minecraft:purpur_block
setblock 183 243 491 minecraft:white_concrete
fill 183 243 492 183 267 492 minecraft:purpur_block
fill 153 244 505 153 249 505 minecraft:purpur_block
fill 161 244 505 161 245 505 minecraft:pearlescent_froglight
fill 164 244 463 164 286 463 minecraft:purpur_block
setblock 168 244 463 minecraft:white_concrete
fill 169 244 463 169 262 463 minecraft:purpur_block
fill 183 244 491 183 307 491 minecraft:purpur_block
setblock 141 245 483 minecraft:pearlescent_froglight
fill 168 245 463 168 255 463 minecraft:purpur_block
fill 141 246 471 141 250 471 minecraft:purpur_block
fill 141 246 483 141 261 483 minecraft:purpur_block
fill 141 246 487 141 251 487 minecraft:purpur_block
fill 141 246 503 141 251 503 minecraft:purpur_block
fill 145 246 463 145 251 463 minecraft:purpur_block
fill 155 246 505 155 251 505 minecraft:purpur_block
fill 161 246 463 161 251 463 minecraft:purpur_block
fill 161 246 505 161 307 505 minecraft:purpur_block
fill 171 246 505 171 251 505 minecraft:purpur_block
setblock 174 246 505 minecraft:pearlescent_froglight
fill 177 246 463 177 251 463 minecraft:purpur_block
fill 183 246 473 183 251 473 minecraft:purpur_block
setblock 183 246 477 minecraft:pearlescent_froglight
fill 183 246 489 183 251 489 minecraft:purpur_block
setblock 141 247 473 minecraft:pearlescent_froglight
setblock 149 247 463 minecraft:white_concrete
setblock 155 247 463 minecraft:white_concrete
fill 174 247 505 174 281 505 minecraft:purpur_block
fill 183 247 477 183 248 477 minecraft:purpur_block
setblock 183 247 498 minecraft:pearlescent_froglight
fill 183 247 499 183 307 499 minecraft:purpur_block
fill 141 248 473 141 307 473 minecraft:purpur_block
setblock 142 248 505 minecraft:magenta_stained_glass
setblock 147 248 505 minecraft:magenta_stained_glass
fill 149 248 463 149 257 463 minecraft:purpur_block
fill 152 248 480 152 249 480 minecraft:purpur_block
fill 155 248 463 155 297 463 minecraft:purpur_block
setblock 167 248 505 minecraft:pearlescent_froglight
fill 168 248 505 170 248 505 minecraft:purpur_block
fill 183 248 498 183 254 498 minecraft:purpur_block
setblock 183 248 501 minecraft:pearlescent_froglight
fill 142 249 505 142 307 505 minecraft:purpur_block
setblock 144 249 466 minecraft:light[level=14]
setblock 144 249 474 minecraft:light[level=14]
setblock 144 249 482 minecraft:light[level=14]
setblock 144 249 490 minecraft:light[level=14]
setblock 144 249 498 minecraft:light[level=14]
fill 147 249 505 147 307 505 minecraft:purpur_block
setblock 151 249 505 minecraft:white_concrete
setblock 152 249 466 minecraft:light[level=14]
setblock 152 249 474 minecraft:light[level=14]
setblock 152 249 482 minecraft:light[level=14]
setblock 152 249 490 minecraft:light[level=14]
setblock 152 249 498 minecraft:light[level=14]
setblock 160 249 466 minecraft:light[level=14]
setblock 160 249 474 minecraft:light[level=14]
setblock 160 249 482 minecraft:light[level=14]
setblock 160 249 490 minecraft:light[level=14]
setblock 160 249 498 minecraft:light[level=14]
setblock 166 249 463 minecraft:pearlescent_froglight
setblock 167 249 463 minecraft:white_concrete
fill 167 249 505 168 285 505 minecraft:purpur_block
setblock 168 249 466 minecraft:light[level=14]
setblock 168 249 474 minecraft:light[level=14]
setblock 168 249 482 minecraft:light[level=14]
setblock 168 249 490 minecraft:light[level=14]
setblock 168 249 498 minecraft:light[level=14]
setblock 169 249 505 minecraft:white_concrete
fill 170 249 505 170 277 505 minecraft:purpur_block
setblock 176 249 466 minecraft:light[level=14]
setblock 176 249 474 minecraft:light[level=14]
setblock 176 249 482 minecraft:light[level=14]
setblock 176 249 490 minecraft:light[level=14]
setblock 176 249 498 minecraft:light[level=14]
setblock 183 249 477 minecraft:white_concrete
fill 183 249 501 183 268 501 minecraft:purpur_block
setblock 141 250 489 minecraft:pearlescent_froglight
setblock 149 250 505 minecraft:pearlescent_froglight
fill 151 250 505 151 251 505 minecraft:purpur_block
setblock 153 250 505 minecraft:magenta_stained_glass
fill 166 250 463 167 289 463 minecraft:purpur_block
fill 169 250 505 169 281 505 minecraft:purpur_block
fill 183 250 477 183 289 477 minecraft:purpur_block
setblock 183 250 482 minecraft:white_concrete
setblock 141 251 471 minecraft:white_concrete
fill 141 251 489 141 307 489 minecraft:purpur_block
setblock 141 251 502 minecraft:white_concrete
fill 149 251 505 149 263 505 minecraft:purpur_block
fill 153 251 505 153 292 505 minecraft:purpur_block
setblock 156 251 463 minecraft:pearlescent_froglight
setblock 181 251 505 minecraft:magenta_stained_glass
fill 183 251 482 183 288 482 minecraft:purpur_block
fill 141 252 471 141 254 471 minecraft:magenta_concrete
fill 141 252 487 141 254 487 minecraft:magenta_concrete
fill 141 252 502 141 307 502 minecraft:purpur_block
fill 141 252 503 141 254 503 minecraft:magenta_concrete
fill 145 252 463 145 254 463 minecraft:magenta_concrete
setblock 151 252 505 minecraft:magenta_stained_glass
fill 155 252 505 155 254 505 minecraft:magenta_concrete
setblock 156 252 463 minecraft:magenta_stained_glass
fill 161 252 463 161 254 463 minecraft:magenta_concrete
setblock 165 252 505 minecraft:pearlescent_froglight
fill 171 252 505 171 254 505 minecraft:magenta_concrete
fill 177 252 463 177 254 463 minecraft:magenta_concrete
fill 181 252 505 181 291 505 minecraft:purpur_block
setblock 183 252 465 minecraft:magenta_stained_glass
fill 183 252 473 183 254 473 minecraft:magenta_concrete
fill 183 252 489 183 254 489 minecraft:magenta_concrete
setblock 183 252 494 minecraft:white_concrete
fill 151 253 505 151 299 505 minecraft:purpur_block
fill 156 253 463 156 289 463 minecraft:purpur_block
fill 165 253 505 165 307 505 minecraft:purpur_block
setblock 182 253 463 minecraft:pearlescent_froglight
fill 183 253 465 183 307 465 minecraft:purpur_block
fill 183 253 494 183 307 494 minecraft:purpur_block
setblock 141 254 495 minecraft:white_concrete
setblock 141 254 500 minecraft:white_concrete
fill 147 254 493 147 255 493 minecraft:end_stone
fill 182 254 463 182 291 463 minecraft:purpur_block
fill 141 255 471 141 260 471 minecraft:purpur_block
fill 141 255 487 141 260 487 minecraft:purpur_block
fill 141 255 495 141 264 495 minecraft:purpur_block
fill 141 255 500 141 260 500 minecraft:purpur_block
fill 141 255 503 141 260 503 minecraft:purpur_block
fill 145 255 463 145 260 463 minecraft:purpur_block
setblock 150 255 463 minecraft:pearlescent_froglight
fill 155 255 505 155 260 505 minecraft:purpur_block
fill 161 255 463 161 260 463 minecraft:purpur_block
fill 171 255 505 171 260 505 minecraft:purpur_block
fill 177 255 463 177 260 463 minecraft:purpur_block
fill 183 255 473 183 260 473 minecraft:purpur_block
fill 183 255 489 183 260 489 minecraft:purpur_block
setblock 183 255 498 minecraft:magenta_stained_glass
fill 150 256 463 150 285 463 minecraft:purpur_block
setblock 168 256 463 minecraft:magenta_stained_glass
fill 183 256 498 183 268 498 minecraft:purpur_block
setblock 183 256 502 minecraft:pearlescent_froglight
fill 183 256 503 183 266 503 minecraft:purpur_block
setblock 144 257 466 minecraft:light[level=14]
setblock 144 257 474 minecraft:light[level=14]
setblock 144 257 482 minecraft:light[level=14]
setblock 144 257 490 minecraft:light[level=14]
setblock 144 257 498 minecraft:light[level=14]
setblock 152 257 466 minecraft:light[level=14]
setblock 152 257 474 minecraft:light[level=14]
setblock 152 257 482 minecraft:light[level=14]
setblock 152 257 490 minecraft:light[level=14]
setblock 152 257 498 minecraft:light[level=14]
setblock 160 257 466 minecraft:light[level=14]
setblock 160 257 474 minecraft:light[level=14]
setblock 160 257 482 minecraft:light[level=14]
setblock 160 257 490 minecraft:light[level=14]
setblock 160 257 498 minecraft:light[level=14]
setblock 162 257 463 minecraft:pearlescent_froglight
fill 163 257 463 163 301 463 minecraft:purpur_block
fill 168 257 463 168 307 463 minecraft:purpur_block
setblock 168 257 466 minecraft:light[level=14]
setblock 168 257 474 minecraft:light[level=14]
setblock 168 257 482 minecraft:light[level=14]
setblock 168 257 490 minecraft:light[level=14]
setblock 168 257 498 minecraft:light[level=14]
setblock 173 257 463 minecraft:magenta_stained_glass
setblock 176 257 466 minecraft:light[level=14]
setblock 176 257 474 minecraft:light[level=14]
setblock 176 257 482 minecraft:light[level=14]
setblock 176 257 490 minecraft:light[level=14]
setblock 176 257 498 minecraft:light[level=14]
fill 183 257 463 183 307 463 minecraft:purpur_block
setblock 183 257 464 minecraft:pearlescent_froglight
setblock 183 257 502 minecraft:purpur_block
setblock 143 258 463 minecraft:magenta_stained_glass
setblock 149 258 463 minecraft:pearlescent_froglight
fill 153 258 500 153 259 500 minecraft:obsidian
setblock 158 258 463 minecraft:white_concrete
fill 162 258 463 162 304 463 minecraft:purpur_block
fill 173 258 463 173 287 463 minecraft:purpur_block
setblock 177 258 505 minecraft:white_concrete
fill 183 258 464 183 283 464 minecraft:purpur_block
setblock 183 258 502 minecraft:magenta_stained_glass
fill 141 259 475 141 307 477 minecraft:purpur_block
setblock 141 259 478 minecraft:white_concrete
fill 143 259 463 143 274 463 minecraft:purpur_block
fill 147 259 484 147 260 484 minecraft:purpur_block
fill 149 259 463 149 307 463 minecraft:purpur_block
fill 158 259 463 158 295 463 minecraft:purpur_block
setblock 158 259 505 minecraft:pearlescent_froglight
fill 159 259 505 159 307 505 minecraft:purpur_block
fill 174 259 488 174 260 488 minecraft:magenta_stained_glass
fill 177 259 505 177 270 505 minecraft:purpur_block
fill 183 259 502 183 307 502 minecraft:purpur_block
fill 141 260 478 141 307 478 minecraft:purpur_block
fill 158 260 505 158 262 505 minecraft:purpur_block
fill 141 261 471 141 263 471 minecraft:magenta_concrete
fill 141 261 480 141 295 480 minecraft:purpur_block
setblock 141 261 481 minecraft:pearlescent_froglight
fill 141 261 487 141 263 487 minecraft:magenta_concrete
setblock 141 261 500 minecraft:pearlescent_froglight
fill 141 261 503 141 263 503 minecraft:magenta_concrete
fill 145 261 463 145 263 463 minecraft:magenta_concrete
fill 155 261 505 155 263 505 minecraft:magenta_concrete
fill 161 261 463 161 263 463 minecraft:magenta_concrete
fill 171 261 505 171 263 505 minecraft:magenta_concrete
fill 174 261 488 174 270 488 minecraft:purpur_block
fill 177 261 463 177 263 463 minecraft:magenta_concrete
fill 183 261 473 183 263 473 minecraft:magenta_concrete
fill 183 261 489 183 263 489 minecraft:magenta_concrete
fill 141 262 481 141 303 481 minecraft:purpur_block
setblock 141 262 483 minecraft:white_concrete
fill 141 262 500 141 307 500 minecraft:purpur_block
setblock 141 263 468 minecraft:white_concrete
fill 141 263 483 141 302 483 minecraft:purpur_block
setblock 158 263 505 minecraft:magenta_stained_glass
setblock 169 263 463 minecraft:magenta_stained_glass
fill 173 263 488 173 270 488 minecraft:purpur_block
setblock 173 263 505 minecraft:pearlescent_froglight
fill 174 263 487 174 270 487 minecraft:purpur_block
fill 174 263 489 174 270 489 minecraft:purpur_block
fill 175 263 488 175 270 488 minecraft:purpur_block
fill 175 263 505 176 263 505 minecraft:white_concrete
fill 141 264 468 141 307 468 minecraft:purpur_block
fill 141 264 471 141 269 471 minecraft:purpur_block
fill 141 264 487 141 269 487 minecraft:purpur_block
fill 141 264 503 141 269 503 minecraft:purpur_block
fill 145 264 463 145 269 463 minecraft:purpur_block
setblock 149 264 505 minecraft:white_concrete
fill 155 264 505 155 269 505 minecraft:purpur_block
fill 158 264 505 158 307 505 minecraft:purpur_block
fill 161 264 463 161 269 463 minecraft:purpur_block
fill 169 264 463 169 307 463 minecraft:purpur_block
fill 171 264 505 171 269 505 minecraft:purpur_block
setblock 172 264 505 minecraft:magenta_stained_glass
fill 173 264 487 173 270 487 minecraft:purpur_block
fill 173 264 489 173 270 489 minecraft:purpur_block
fill 173 264 505 173 307 505 minecraft:purpur_block
fill 175 264 487 175 270 487 minecraft:purpur_block
fill 175 264 489 175 270 489 minecraft:purpur_block
fill 175 264 505 176 265 505 minecraft:purpur_block
fill 177 264 463 177 269 463 minecraft:purpur_block
fill 183 264 473 183 269 473 minecraft:purpur_block
fill 183 264 489 183 269 489 minecraft:purpur_block
setblock 141 265 495 minecraft:white_concrete
setblock 144 265 466 minecraft:light[level=14]
setblock 144 265 474 minecraft:light[level=14]
setblock 144 265 482 minecraft:light[level=14]
setblock 144 265 490 minecraft:light[level=14]
setblock 144 265 498 minecraft:light[level=14]
fill 149 265 505 149 280 505 minecraft:purpur_block
setblock 152 265 466 minecraft:light[level=14]
setblock 152 265 474 minecraft:light[level=14]
setblock 152 265 482 minecraft:light[level=14]
setblock 152 265 490 minecraft:light[level=14]
setblock 152 265 498 minecraft:light[level=14]
setblock 160 265 466 minecraft:light[level=14]
setblock 160 265 474 minecraft:light[level=14]
setblock 160 265 482 minecraft:light[level=14]
setblock 160 265 490 minecraft:light[level=14]
setblock 160 265 498 minecraft:light[level=14]
setblock 168 265 466 minecraft:light[level=14]
setblock 168 265 474 minecraft:light[level=14]
setblock 168 265 482 minecraft:light[level=14]
setblock 168 265 490 minecraft:light[level=14]
setblock 168 265 498 minecraft:light[level=14]
fill 172 265 487 172 270 488 minecraft:purpur_block
fill 172 265 505 172 291 505 minecraft:purpur_block
fill 173 265 486 175 270 486 minecraft:purpur_block
fill 174 265 490 174 270 490 minecraft:purpur_block
setblock 176 265 466 minecraft:light[level=14]
setblock 176 265 474 minecraft:light[level=14]
setblock 176 265 482 minecraft:light[level=14]
fill 176 265 487 176 270 488 minecraft:purpur_block
setblock 176 265 490 minecraft:light[level=14]
setblock 176 265 498 minecraft:light[level=14]
setblock 183 265 484 minecraft:white_concrete
fill 183 265 495 183 278 495 minecraft:purpur_block
setblock 183 265 496 minecraft:magenta_stained_glass
setblock 141 266 464 minecraft:magenta_stained_glass
fill 141 266 495 141 307 495 minecraft:purpur_block
setblock 163 266 505 minecraft:pearlescent_froglight
fill 172 266 489 172 270 489 minecraft:purpur_block
fill 173 266 490 173 270 490 minecraft:purpur_block
fill 175 266 490 175 270 490 minecraft:purpur_block
setblock 175 266 505 minecraft:white_concrete
fill 176 266 486 176 270 486 minecraft:purpur_block
fill 176 266 489 176 270 489 minecraft:purpur_block
fill 176 266 505 176 307 505 minecraft:purpur_block
fill 183 266 484 183 307 484 minecraft:purpur_block
fill 183 266 496 183 307 496 minecraft:purpur_block
fill 141 267 464 141 307 464 minecraft:purpur_block
fill 163 267 505 163 307 505 minecraft:purpur_block
fill 171 267 487 171 270 488 minecraft:purpur_block
fill 172 267 486 172 270 486 minecraft:purpur_block
fill 172 267 490 172 270 490 minecraft:purpur_block
fill 173 267 485 175 270 485 minecraft:purpur_block
fill 175 267 505 175 285 505 minecraft:purpur_block
fill 176 267 490 176 270 490 minecraft:purpur_block
fill 177 267 487 177 270 488 minecraft:purpur_block
setblock 183 267 503 minecraft:white_concrete
fill 159 268 472 161 269 472 minecraft:purpur_block
fill 160 268 471 160 269 471 minecraft:purpur_block
fill 160 268 473 160 269 473 minecraft:purpur_block
fill 171 268 486 171 270 486 minecraft:purpur_block
fill 171 268 489 171 270 489 minecraft:purpur_block
fill 172 268 485 172 270 485 minecraft:purpur_block
fill 173 268 491 175 270 491 minecraft:purpur_block
fill 176 268 485 176 270 485 minecraft:purpur_block
fill 177 268 486 177 270 486 minecraft:purpur_block
fill 177 268 489 177 270 489 minecraft:purpur_block
setblock 183 268 492 minecraft:magenta_stained_glass
fill 183 268 503 183 307 503 minecraft:purpur_block
fill 170 269 487 170 270 488 minecraft:purpur_block
fill 171 269 485 171 270 485 minecraft:purpur_block
fill 171 269 490 171 270 490 minecraft:purpur_block
fill 172 269 491 172 270 491 minecraft:purpur_block
fill 173 269 484 175 270 484 minecraft:purpur_block
fill 176 269 491 176 270 491 minecraft:purpur_block
fill 177 269 485 177 270 485 minecraft:purpur_block
fill 177 269 490 177 270 490 minecraft:purpur_block
fill 178 269 487 178 270 488 minecraft:purpur_block
fill 183 269 492 183 307 492 minecraft:purpur_block
setblock 183 269 498 minecraft:magenta_stained_glass
setblock 183 269 501 minecraft:magenta_stained_glass
fill 141 270 471 141 272 471 minecraft:magenta_concrete
fill 141 270 487 141 272 487 minecraft:magenta_concrete
fill 141 270 503 141 272 503 minecraft:magenta_concrete
fill 145 270 463 145 272 463 minecraft:magenta_concrete
setblock 148 270 463 minecraft:pearlescent_froglight
fill 152 270 474 153 271 475 minecraft:purpur_block
fill 153 270 473 153 271 473 minecraft:purpur_block
fill 155 270 505 155 272 505 minecraft:magenta_concrete
fill 161 270 463 161 272 463 minecraft:magenta_concrete
setblock 170 270 486 minecraft:purpur_block
fill 170 270 489 170 270 490 minecraft:purpur_block
setblock 171 270 491 minecraft:purpur_block
fill 171 270 505 171 272 505 minecraft:magenta_concrete
setblock 172 270 484 minecraft:purpur_block
fill 173 270 492 175 270 492 minecraft:purpur_block
setblock 176 270 484 minecraft:purpur_block
fill 177 270 463 177 272 463 minecraft:magenta_concrete
setblock 177 270 491 minecraft:purpur_block
setblock 178 270 486 minecraft:purpur_block
fill 178 270 489 178 270 490 minecraft:purpur_block
fill 183 270 473 183 272 473 minecraft:magenta_concrete
fill 183 270 489 183 272 489 minecraft:magenta_concrete
fill 183 270 498 183 301 498 minecraft:purpur_block
fill 183 270 501 183 290 501 minecraft:purpur_block
fill 148 271 463 148 283 463 minecraft:purpur_block
fill 171 271 463 171 275 463 minecraft:purpur_block
setblock 172 271 463 minecraft:magenta_stained_glass
fill 173 271 489 173 272 489 minecraft:end_stone_bricks
fill 174 271 486 174 273 486 minecraft:end_stone_bricks
fill 176 271 488 176 272 488 minecraft:end_stone_bricks
setblock 177 271 505 minecraft:white_concrete
fill 172 272 463 172 307 463 minecraft:purpur_block
fill 177 272 505 177 288 505 minecraft:purpur_block
fill 141 273 471 141 287 471 minecraft:purpur_block
fill 141 273 487 141 287 487 minecraft:purpur_block
setblock 141 273 492 minecraft:white_concrete
fill 141 273 503 141 287 503 minecraft:purpur_block
setblock 142 273 463 minecraft:white_concrete
setblock 144 273 466 minecraft:light[level=14]
setblock 144 273 474 minecraft:light[level=14]
setblock 144 273 482 minecraft:light[level=14]
setblock 144 273 490 minecraft:light[level=14]
setblock 144 273 498 minecraft:light[level=14]
fill 145 273 463 145 287 463 minecraft:purpur_block
setblock 152 273 466 minecraft:light[level=14]
setblock 152 273 474 minecraft:light[level=14]
setblock 152 273 482 minecraft:light[level=14]
setblock 152 273 490 minecraft:light[level=14]
setblock 152 273 498 minecraft:light[level=14]
fill 155 273 505 155 278 505 minecraft:purpur_block
setblock 160 273 466 minecraft:light[level=14]
setblock 160 273 474 minecraft:light[level=14]
setblock 160 273 482 minecraft:light[level=14]
setblock 160 273 490 minecraft:light[level=14]
setblock 160 273 498 minecraft:light[level=14]
fill 161 273 463 161 276 463 minecraft:purpur_block
setblock 168 273 466 minecraft:light[level=14]
setblock 168 273 474 minecraft:light[level=14]
setblock 168 273 482 minecraft:light[level=14]
setblock 168 273 490 minecraft:light[level=14]
setblock 168 273 498 minecraft:light[level=14]
fill 171 273 505 171 287 505 minecraft:purpur_block
setblock 176 273 466 minecraft:light[level=14]
setblock 176 273 474 minecraft:light[level=14]
setblock 176 273 482 minecraft:light[level=14]
setblock 176 273 490 minecraft:light[level=14]
setblock 176 273 498 minecraft:light[level=14]
fill 177 273 463 177 287 463 minecraft:purpur_block
setblock 183 273 473 minecraft:white_concrete
fill 183 273 489 183 287 489 minecraft:purpur_block
fill 141 274 492 141 284 492 minecraft:purpur_block
setblock 141 274 496 minecraft:pearlescent_froglight
fill 142 274 463 142 276 463 minecraft:purpur_block
fill 183 274 473 183 287 473 minecraft:purpur_block
fill 141 275 496 141 301 496 minecraft:purpur_block
setblock 143 275 463 minecraft:pearlescent_froglight
fill 146 275 463 146 307 463 minecraft:purpur_block
setblock 147 275 463 minecraft:magenta_stained_glass
setblock 162 275 505 minecraft:white_concrete
setblock 141 276 469 minecraft:white_concrete
fill 141 276 497 141 307 497 minecraft:purpur_block
setblock 141 276 498 minecraft:white_concrete
fill 143 276 463 143 294 463 minecraft:purpur_block
fill 147 276 463 147 299 463 minecraft:purpur_block
fill 162 276 505 162 307 505 minecraft:purpur_block
setblock 171 276 463 minecraft:magenta_stained_glass
setblock 183 276 493 minecraft:pearlescent_froglight
fill 141 277 469 141 307 469 minecraft:purpur_block
setblock 141 277 488 minecraft:pearlescent_froglight
fill 141 277 498 141 307 498 minecraft:purpur_block
setblock 142 277 463 minecraft:pearlescent_froglight
setblock 161 277 463 minecraft:white_concrete
fill 171 277 463 171 307 463 minecraft:purpur_block
setblock 183 277 474 minecraft:pearlescent_froglight
fill 183 277 493 183 307 493 minecraft:purpur_block
setblock 141 278 466 minecraft:white_concrete
fill 141 278 488 141 307 488 minecraft:purpur_block
fill 142 278 463 142 307 463 minecraft:purpur_block
fill 161 278 463 161 287 463 minecraft:purpur_block
setblock 170 278 505 minecraft:white_concrete
fill 183 278 474 183 283 474 minecraft:purpur_block
fill 141 279 466 141 307 466 minecraft:purpur_block
fill 142 279 464 153 280 464 minecraft:end_stone
fill 142 279 465 142 280 465 minecraft:black_concrete
fill 142 279 466 144 280 471 minecraft:end_stone
fill 142 279 472 142 280 472 minecraft:black_concrete
fill 142 279 473 143 280 478 minecraft:end_stone
fill 142 279 479 142 280 479 minecraft:black_concrete
fill 142 279 480 143 280 485 minecraft:end_stone
fill 142 279 486 142 280 486 minecraft:black_concrete
fill 142 279 487 143 280 492 minecraft:end_stone
fill 142 279 493 142 280 493 minecraft:black_concrete
fill 142 279 494 143 280 499 minecraft:end_stone
fill 142 279 500 142 280 500 minecraft:black_concrete
fill 142 279 501 143 280 504 minecraft:end_stone
fill 143 279 465 162 280 465 minecraft:end_stone
fill 143 279 472 146 280 472 minecraft:end_stone
fill 143 279 479 146 280 479 minecraft:end_stone
fill 143 279 486 146 280 486 minecraft:end_stone
fill 143 279 493 146 280 493 minecraft:end_stone
fill 143 279 500 146 280 500 minecraft:end_stone
fill 144 279 473 150 280 473 minecraft:end_stone
fill 144 279 474 144 280 474 minecraft:black_concrete
fill 144 279 475 144 280 478 minecraft:end_stone
fill 144 279 480 150 280 480 minecraft:end_stone
fill 144 279 481 144 280 481 minecraft:black_concrete
fill 144 279 482 144 280 485 minecraft:end_stone
fill 144 279 487 150 280 487 minecraft:end_stone
fill 144 279 488 144 280 488 minecraft:black_concrete
fill 144 279 489 144 280 492 minecraft:end_stone
fill 144 279 494 150 280 494 minecraft:end_stone
fill 144 279 495 144 280 495 minecraft:black_concrete
fill 144 279 496 144 280 499 minecraft:end_stone
fill 144 279 501 150 280 501 minecraft:end_stone
fill 144 279 502 144 280 502 minecraft:black_concrete
fill 144 279 503 147 280 504 minecraft:end_stone
fill 145 279 466 147 280 469 minecraft:end_stone
fill 145 279 470 145 280 470 minecraft:black_concrete
fill 145 279 471 153 280 471 minecraft:end_stone
fill 145 279 474 147 280 476 minecraft:end_stone
fill 145 279 477 145 280 477 minecraft:black_concrete
fill 145 279 478 153 280 478 minecraft:end_stone
fill 145 279 481 147 280 483 minecraft:end_stone
fill 145 279 484 145 280 484 minecraft:black_concrete
fill 145 279 485 153 280 485 minecraft:end_stone
fill 145 279 488 147 280 490 minecraft:end_stone
fill 145 279 491 145 280 491 minecraft:black_concrete
fill 145 279 492 153 280 492 minecraft:end_stone
fill 145 279 495 147 280 497 minecraft:end_stone
fill 145 279 498 145 280 498 minecraft:black_concrete
fill 145 279 499 153 280 499 minecraft:end_stone
fill 145 279 502 164 280 502 minecraft:end_stone
fill 146 279 470 149 280 470 minecraft:end_stone
fill 146 279 477 149 280 477 minecraft:end_stone
fill 146 279 484 149 280 484 minecraft:end_stone
fill 146 279 491 149 280 491 minecraft:end_stone
fill 146 279 498 149 280 498 minecraft:end_stone
fill 147 279 472 147 280 472 minecraft:black_concrete
fill 147 279 479 147 280 479 minecraft:black_concrete
fill 147 279 486 147 280 486 minecraft:black_concrete
fill 147 279 493 147 280 493 minecraft:black_concrete
fill 147 279 500 147 280 500 minecraft:black_concrete
fill 148 279 466 150 280 467 minecraft:end_stone
fill 148 279 468 148 280 468 minecraft:black_concrete
fill 148 279 469 156 280 469 minecraft:end_stone
fill 148 279 472 162 280 472 minecraft:end_stone
fill 148 279 474 159 280 474 minecraft:end_stone
fill 148 279 475 148 280 475 minecraft:black_concrete
fill 148 279 476 156 280 476 minecraft:end_stone
fill 148 279 479 162 280 479 minecraft:end_stone
fill 148 279 481 159 280 481 minecraft:end_stone
fill 148 279 482 148 280 482 minecraft:black_concrete
fill 148 279 483 156 280 483 minecraft:end_stone
fill 148 279 486 162 279 486 minecraft:end_stone
fill 148 279 488 159 280 488 minecraft:end_stone
fill 148 279 489 148 280 489 minecraft:black_concrete
fill 148 279 490 156 280 490 minecraft:end_stone
fill 148 279 493 162 280 493 minecraft:end_stone
fill 148 279 495 159 280 495 minecraft:end_stone
fill 148 279 496 148 280 496 minecraft:black_concrete
fill 148 279 497 156 280 497 minecraft:end_stone
fill 148 279 500 167 280 500 minecraft:end_stone
fill 148 279 503 148 280 503 minecraft:black_concrete
fill 148 279 504 161 280 504 minecraft:end_stone
fill 149 279 468 152 280 468 minecraft:end_stone
fill 149 279 475 152 280 475 minecraft:end_stone
fill 149 279 482 152 280 482 minecraft:end_stone
fill 149 279 489 152 280 489 minecraft:end_stone
fill 149 279 496 152 280 496 minecraft:end_stone
fill 149 279 503 152 280 503 minecraft:end_stone
fill 150 279 470 150 280 470 minecraft:black_concrete
fill 150 279 477 150 280 477 minecraft:black_concrete
fill 150 279 484 150 280 484 minecraft:black_concrete
fill 150 279 491 150 280 491 minecraft:black_concrete
fill 150 279 498 150 280 498 minecraft:black_concrete
fill 151 279 466 151 280 466 minecraft:black_concrete
fill 151 279 467 159 280 467 minecraft:end_stone
fill 151 279 470 165 280 470 minecraft:end_stone
fill 151 279 473 151 280 473 minecraft:black_concrete
fill 151 279 477 165 280 477 minecraft:end_stone
fill 151 279 480 151 280 480 minecraft:black_concrete
fill 151 279 484 162 279 484 minecraft:end_stone
fill 151 279 487 151 280 487 minecraft:black_concrete
fill 151 279 491 165 280 491 minecraft:end_stone
fill 151 279 494 151 280 494 minecraft:black_concrete
fill 151 279 498 170 280 498 minecraft:end_stone
fill 151 279 501 151 280 501 minecraft:black_concrete
fill 152 279 466 155 280 466 minecraft:end_stone
fill 152 279 473 155 280 473 minecraft:end_stone
fill 152 279 480 155 280 480 minecraft:end_stone
fill 152 279 487 155 280 487 minecraft:end_stone
fill 152 279 494 155 280 494 minecraft:end_stone
fill 152 279 501 155 280 501 minecraft:end_stone
fill 153 279 468 153 280 468 minecraft:black_concrete
fill 153 279 475 153 280 475 minecraft:black_concrete
fill 153 279 482 153 280 482 minecraft:black_concrete
fill 153 279 489 153 280 489 minecraft:black_concrete
fill 153 279 496 153 280 496 minecraft:black_concrete
fill 153 279 503 153 280 503 minecraft:black_concrete
fill 154 279 464 154 280 464 minecraft:black_concrete
fill 154 279 468 168 280 468 minecraft:end_stone
fill 154 279 471 154 280 471 minecraft:black_concrete
fill 154 279 475 168 280 475 minecraft:end_stone
fill 154 279 478 154 280 478 minecraft:black_concrete
fill 154 279 482 168 279 482 minecraft:end_stone
fill 154 279 485 154 280 485 minecraft:black_concrete
fill 154 279 489 168 280 489 minecraft:end_stone
fill 154 279 492 154 280 492 minecraft:black_concrete
fill 154 279 496 173 280 496 minecraft:end_stone
fill 154 279 499 154 280 499 minecraft:black_concrete
fill 154 279 503 173 280 503 minecraft:end_stone
fill 155 279 464 158 280 464 minecraft:end_stone
fill 155 279 471 158 280 471 minecraft:end_stone
fill 155 279 478 158 280 478 minecraft:end_stone
fill 155 279 485 158 280 485 minecraft:end_stone
fill 155 279 492 158 280 492 minecraft:end_stone
fill 155 279 499 158 280 499 minecraft:end_stone
setblock 155 279 505 minecraft:white_concrete
fill 156 279 466 156 280 466 minecraft:black_concrete
fill 156 279 473 156 280 473 minecraft:black_concrete
fill 156 279 480 156 280 480 minecraft:black_concrete
fill 156 279 487 156 280 487 minecraft:black_concrete
fill 156 279 494 156 280 494 minecraft:black_concrete
fill 156 279 501 156 280 501 minecraft:black_concrete
fill 157 279 466 171 280 466 minecraft:end_stone
fill 157 279 469 157 280 469 minecraft:black_concrete
fill 157 279 473 171 280 473 minecraft:end_stone
fill 157 279 476 157 280 476 minecraft:black_concrete
fill 157 279 480 171 280 480 minecraft:end_stone
fill 157 279 483 157 280 483 minecraft:black_concrete
fill 157 279 487 163 279 487 minecraft:end_stone
fill 157 279 490 157 280 490 minecraft:black_concrete
fill 157 279 494 176 280 494 minecraft:end_stone
fill 157 279 497 157 280 497 minecraft:black_concrete
fill 157 279 501 176 280 501 minecraft:end_stone
fill 158 279 469 161 280 469 minecraft:end_stone
fill 158 279 476 161 280 476 minecraft:end_stone
fill 158 279 483 161 280 483 minecraft:end_stone
fill 158 279 490 161 280 490 minecraft:end_stone
fill 158 279 497 161 280 497 minecraft:end_stone
fill 159 279 464 159 280 464 minecraft:black_concrete
fill 159 279 471 159 280 471 minecraft:black_concrete
fill 159 279 478 159 280 478 minecraft:black_concrete
fill 159 279 485 159 280 485 minecraft:black_concrete
fill 159 279 492 159 280 492 minecraft:black_concrete
fill 159 279 499 159 280 499 minecraft:black_concrete
fill 160 279 464 174 280 464 minecraft:end_stone
fill 160 279 467 160 280 467 minecraft:black_concrete
fill 160 279 471 174 280 471 minecraft:end_stone
fill 160 279 474 160 280 474 minecraft:black_concrete
fill 160 279 478 174 280 478 minecraft:end_stone
fill 160 279 481 160 280 481 minecraft:black_concrete
fill 160 279 485 161 279 485 minecraft:end_stone
fill 160 279 488 160 280 488 minecraft:black_concrete
fill 160 279 492 179 280 492 minecraft:end_stone
fill 160 279 495 160 280 495 minecraft:black_concrete
fill 160 279 499 179 280 499 minecraft:end_stone
fill 161 279 467 164 280 467 minecraft:end_stone
fill 161 279 474 164 280 474 minecraft:end_stone
fill 161 279 481 164 280 481 minecraft:end_stone
fill 161 279 488 164 279 488 minecraft:end_stone
fill 161 279 495 164 280 495 minecraft:end_stone
fill 162 279 469 162 280 469 minecraft:black_concrete
fill 162 279 476 162 280 476 minecraft:black_concrete
setblock 162 279 483 minecraft:black_concrete
fill 162 279 490 162 280 490 minecraft:black_concrete
fill 162 279 497 162 280 497 minecraft:black_concrete
fill 162 279 504 162 280 504 minecraft:black_concrete
fill 163 279 465 163 280 465 minecraft:black_concrete
fill 163 279 469 177 280 469 minecraft:end_stone
fill 163 279 472 163 280 472 minecraft:black_concrete
fill 163 279 476 177 280 476 minecraft:end_stone
fill 163 279 479 163 280 479 minecraft:black_concrete
setblock 163 279 483 minecraft:end_stone
fill 163 279 490 182 280 490 minecraft:end_stone
fill 163 279 493 163 280 493 minecraft:black_concrete
fill 163 279 497 182 280 497 minecraft:end_stone
fill 163 279 504 182 280 504 minecraft:end_stone
fill 164 279 465 167 280 465 minecraft:end_stone
fill 164 279 472 167 280 472 minecraft:end_stone
fill 164 279 479 167 280 479 minecraft:end_stone
fill 164 279 493 167 280 493 minecraft:end_stone
fill 165 279 467 165 280 467 minecraft:black_concrete
fill 165 279 474 165 280 474 minecraft:black_concrete
fill 165 279 481 165 280 481 minecraft:black_concrete
fill 165 279 483 177 279 483 minecraft:end_stone
fill 165 279 487 171 279 487 minecraft:end_stone
setblock 165 279 488 minecraft:black_concrete
fill 165 279 495 165 280 495 minecraft:black_concrete
fill 165 279 502 165 280 502 minecraft:black_concrete
fill 166 279 467 180 280 467 minecraft:end_stone
fill 166 279 470 166 280 470 minecraft:black_concrete
fill 166 279 474 180 280 474 minecraft:end_stone
fill 166 279 477 166 280 477 minecraft:black_concrete
fill 166 279 481 180 280 481 minecraft:end_stone
setblock 166 279 484 minecraft:black_concrete
fill 166 279 486 167 279 486 minecraft:end_stone
fill 166 279 488 182 280 488 minecraft:end_stone
fill 166 279 491 166 280 491 minecraft:black_concrete
fill 166 279 495 182 280 495 minecraft:end_stone
fill 166 279 502 182 280 502 minecraft:end_stone
fill 167 279 470 170 280 470 minecraft:end_stone
fill 167 279 477 170 280 477 minecraft:end_stone
fill 167 279 484 170 279 485 minecraft:end_stone
fill 167 279 491 170 280 491 minecraft:end_stone
fill 168 279 465 168 280 465 minecraft:black_concrete
fill 168 279 472 168 280 472 minecraft:black_concrete
fill 168 279 479 168 280 479 minecraft:black_concrete
fill 168 279 486 168 280 486 minecraft:black_concrete
fill 168 279 493 168 280 493 minecraft:black_concrete
fill 168 279 500 168 280 500 minecraft:black_concrete
fill 169 279 465 182 280 465 minecraft:end_stone
fill 169 279 468 169 280 468 minecraft:black_concrete
fill 169 279 472 182 280 472 minecraft:end_stone
fill 169 279 475 169 280 475 minecraft:black_concrete
fill 169 279 479 182 280 479 minecraft:end_stone
fill 169 279 482 169 280 482 minecraft:black_concrete
fill 169 279 486 182 280 486 minecraft:end_stone
fill 169 279 489 169 280 489 minecraft:black_concrete
fill 169 279 493 182 280 493 minecraft:end_stone
fill 169 279 500 182 280 500 minecraft:end_stone
fill 170 279 468 173 280 468 minecraft:end_stone
fill 170 279 475 173 280 475 minecraft:end_stone
fill 170 279 482 173 280 482 minecraft:end_stone
fill 170 279 489 173 280 489 minecraft:end_stone
fill 170 279 505 170 285 505 minecraft:purpur_block
fill 171 279 470 171 280 470 minecraft:black_concrete
fill 171 279 477 171 280 477 minecraft:black_concrete
fill 171 279 484 171 280 484 minecraft:black_concrete
fill 171 279 485 174 280 485 minecraft:end_stone
fill 171 279 491 171 280 491 minecraft:black_concrete
fill 171 279 498 171 280 498 minecraft:black_concrete
fill 172 279 466 172 280 466 minecraft:black_concrete
fill 172 279 470 182 280 470 minecraft:end_stone
fill 172 279 473 172 280 473 minecraft:black_concrete
fill 172 279 477 182 280 477 minecraft:end_stone
fill 172 279 480 172 280 480 minecraft:black_concrete
fill 172 279 484 182 280 484 minecraft:end_stone
fill 172 279 487 172 280 487 minecraft:black_concrete
fill 172 279 491 182 280 491 minecraft:end_stone
fill 172 279 498 182 280 498 minecraft:end_stone
fill 173 279 466 176 280 466 minecraft:end_stone
fill 173 279 473 176 280 473 minecraft:end_stone
fill 173 279 480 176 280 480 minecraft:end_stone
fill 173 279 487 176 280 487 minecraft:end_stone
fill 174 279 468 174 280 468 minecraft:black_concrete
fill 174 279 475 174 280 475 minecraft:black_concrete
fill 174 279 482 174 280 482 minecraft:black_concrete
fill 174 279 489 174 280 489 minecraft:black_concrete
fill 174 279 496 174 280 496 minecraft:black_concrete
fill 174 279 503 174 280 503 minecraft:black_concrete
fill 175 279 464 175 280 464 minecraft:black_concrete
fill 175 279 468 182 280 468 minecraft:end_stone
fill 175 279 471 175 280 471 minecraft:black_concrete
fill 175 279 475 182 280 475 minecraft:end_stone
fill 175 279 478 175 280 478 minecraft:black_concrete
fill 175 279 482 182 280 482 minecraft:end_stone
fill 175 279 485 175 280 485 minecraft:black_concrete
fill 175 279 489 182 280 489 minecraft:end_stone
fill 175 279 496 182 280 496 minecraft:end_stone
fill 175 279 503 182 280 503 minecraft:end_stone
fill 176 279 464 179 280 464 minecraft:end_stone
fill 176 279 471 179 280 471 minecraft:end_stone
fill 176 279 478 179 280 478 minecraft:end_stone
fill 176 279 485 179 280 485 minecraft:end_stone
fill 177 279 466 177 280 466 minecraft:black_concrete
fill 177 279 473 177 280 473 minecraft:black_concrete
fill 177 279 480 177 280 480 minecraft:black_concrete
fill 177 279 487 177 280 487 minecraft:black_concrete
fill 177 279 494 177 280 494 minecraft:black_concrete
fill 177 279 501 177 280 501 minecraft:black_concrete
fill 178 279 466 182 280 466 minecraft:end_stone
fill 178 279 469 178 280 469 minecraft:black_concrete
fill 178 279 473 182 280 473 minecraft:end_stone
fill 178 279 476 178 280 476 minecraft:black_concrete
fill 178 279 480 182 280 480 minecraft:end_stone
fill 178 279 483 178 280 483 minecraft:black_concrete
fill 178 279 487 182 280 487 minecraft:end_stone
fill 178 279 494 182 280 494 minecraft:end_stone
fill 178 279 501 182 280 501 minecraft:end_stone
fill 179 279 469 182 280 469 minecraft:end_stone
fill 179 279 476 182 280 476 minecraft:end_stone
fill 179 279 483 182 280 483 minecraft:end_stone
fill 180 279 464 180 280 464 minecraft:black_concrete
fill 180 279 471 180 280 471 minecraft:black_concrete
fill 180 279 478 180 280 478 minecraft:black_concrete
fill 180 279 485 180 280 485 minecraft:black_concrete
fill 180 279 492 180 280 492 minecraft:black_concrete
fill 180 279 499 180 280 499 minecraft:black_concrete
fill 181 279 464 182 280 464 minecraft:end_stone
fill 181 279 467 181 280 467 minecraft:black_concrete
fill 181 279 471 182 280 471 minecraft:end_stone
fill 181 279 474 181 280 474 minecraft:black_concrete
fill 181 279 478 182 280 478 minecraft:end_stone
fill 181 279 481 181 280 481 minecraft:black_concrete
fill 181 279 485 182 280 485 minecraft:end_stone
fill 181 279 492 182 280 492 minecraft:end_stone
fill 181 279 499 182 280 499 minecraft:end_stone
fill 182 279 467 182 280 467 minecraft:end_stone
fill 182 279 474 182 280 474 minecraft:end_stone
fill 182 279 481 182 280 481 minecraft:end_stone
setblock 183 279 495 minecraft:pearlescent_froglight
fill 148 280 486 160 280 486 minecraft:end_stone
fill 151 280 484 160 280 484 minecraft:end_stone
fill 154 280 482 162 280 482 minecraft:end_stone
fill 155 280 505 155 287 505 minecraft:purpur_block
fill 157 280 487 161 280 487 minecraft:end_stone
setblock 160 280 485 minecraft:end_stone
fill 161 280 484 161 280 486 minecraft:pearlescent_froglight
fill 161 280 488 162 280 488 minecraft:end_stone
fill 162 280 483 162 280 484 minecraft:pearlescent_froglight
fill 162 280 486 162 280 487 minecraft:pearlescent_froglight
fill 163 280 482 163 280 483 minecraft:pearlescent_froglight
fill 163 280 487 163 280 488 minecraft:pearlescent_froglight
fill 164 280 482 165 280 482 minecraft:pearlescent_froglight
fill 164 280 488 165 280 488 minecraft:pearlescent_froglight
fill 165 280 483 166 280 483 minecraft:pearlescent_froglight
fill 165 280 487 166 280 487 minecraft:pearlescent_froglight
fill 166 280 482 168 280 482 minecraft:end_stone
fill 166 280 484 167 280 484 minecraft:pearlescent_froglight
fill 166 280 486 167 280 486 minecraft:pearlescent_froglight
fill 167 280 483 177 280 483 minecraft:end_stone
setblock 167 280 485 minecraft:pearlescent_froglight
fill 167 280 487 171 280 487 minecraft:end_stone
fill 168 280 484 170 280 485 minecraft:end_stone
fill 183 280 495 183 307 495 minecraft:purpur_block
setblock 144 281 466 minecraft:light[level=14]
setblock 144 281 474 minecraft:light[level=14]
setblock 144 281 482 minecraft:light[level=14]
setblock 144 281 490 minecraft:light[level=14]
setblock 144 281 498 minecraft:light[level=14]
setblock 144 281 505 minecraft:white_concrete
fill 145 281 505 145 307 505 minecraft:purpur_block
setblock 149 281 505 minecraft:white_concrete
setblock 152 281 466 minecraft:light[level=14]
setblock 152 281 474 minecraft:light[level=14]
setblock 152 281 482 minecraft:light[level=14]
setblock 152 281 490 minecraft:light[level=14]
setblock 152 281 498 minecraft:light[level=14]
setblock 160 281 466 minecraft:light[level=14]
setblock 160 281 474 minecraft:light[level=14]
setblock 160 281 482 minecraft:light[level=14]
setblock 160 281 490 minecraft:light[level=14]
setblock 160 281 498 minecraft:light[level=14]
setblock 168 281 466 minecraft:light[level=14]
setblock 168 281 474 minecraft:light[level=14]
setblock 168 281 482 minecraft:light[level=14]
setblock 168 281 490 minecraft:light[level=14]
setblock 168 281 498 minecraft:light[level=14]
setblock 176 281 466 minecraft:light[level=14]
setblock 176 281 474 minecraft:light[level=14]
setblock 176 281 482 minecraft:light[level=14]
setblock 176 281 490 minecraft:light[level=14]
setblock 176 281 498 minecraft:light[level=14]
fill 144 282 505 144 307 505 minecraft:purpur_block
setblock 146 282 505 minecraft:pearlescent_froglight
fill 149 282 505 149 307 505 minecraft:purpur_block
setblock 169 282 505 minecraft:magenta_stained_glass
setblock 174 282 505 minecraft:pearlescent_froglight
fill 146 283 505 146 294 505 minecraft:purpur_block
fill 169 283 505 169 307 505 minecraft:purpur_block
fill 174 283 505 174 307 505 minecraft:purpur_block
setblock 141 284 467 minecraft:white_concrete
setblock 148 284 463 minecraft:pearlescent_froglight
setblock 183 284 464 minecraft:magenta_stained_glass
setblock 183 284 474 minecraft:pearlescent_froglight
fill 141 285 467 141 307 467 minecraft:purpur_block
setblock 141 285 492 minecraft:magenta_stained_glass
fill 148 285 463 148 307 463 minecraft:purpur_block
setblock 176 285 463 minecraft:magenta_stained_glass
fill 183 285 464 183 307 464 minecraft:purpur_block
fill 183 285 474 183 307 474 minecraft:purpur_block
setblock 141 286 490 minecraft:magenta_stained_glass
fill 141 286 492 141 307 492 minecraft:purpur_block
setblock 150 286 463 minecraft:pearlescent_froglight
fill 167 286 505 167 307 505 minecraft:purpur_block
setblock 168 286 505 minecraft:magenta_stained_glass
setblock 170 286 505 minecraft:white_concrete
setblock 175 286 505 minecraft:pearlescent_froglight
fill 176 286 463 176 307 463 minecraft:purpur_block
fill 141 287 490 141 307 490 minecraft:purpur_block
fill 149 287 482 149 288 482 minecraft:magenta_stained_glass
fill 150 287 463 150 299 463 minecraft:purpur_block
setblock 164 287 463 minecraft:white_concrete
fill 168 287 505 168 307 505 minecraft:purpur_block
fill 170 287 505 170 292 505 minecraft:purpur_block
fill 175 287 505 175 290 505 minecraft:purpur_block
setblock 179 287 463 minecraft:white_concrete
fill 141 288 471 141 290 471 minecraft:magenta_concrete
fill 141 288 487 141 290 487 minecraft:magenta_concrete
fill 141 288 503 141 290 503 minecraft:magenta_concrete
fill 145 288 463 145 290 463 minecraft:magenta_concrete
fill 155 288 505 155 290 505 minecraft:magenta_concrete
fill 161 288 463 161 290 463 minecraft:magenta_concrete
fill 164 288 463 164 307 463 minecraft:purpur_block
fill 171 288 505 171 290 505 minecraft:magenta_concrete
setblock 173 288 463 minecraft:pearlescent_froglight
setblock 174 288 463 minecraft:magenta_stained_glass
fill 177 288 463 177 290 463 minecraft:magenta_concrete
fill 179 288 463 179 307 463 minecraft:purpur_block
fill 183 288 473 183 290 473 minecraft:magenta_concrete
fill 183 288 489 183 290 489 minecraft:magenta_concrete
setblock 144 289 466 minecraft:light[level=14]
setblock 144 289 474 minecraft:light[level=14]
setblock 144 289 482 minecraft:light[level=14]
setblock 144 289 490 minecraft:light[level=14]
setblock 144 289 498 minecraft:light[level=14]
fill 149 289 482 149 295 483 minecraft:purpur_block
setblock 152 289 466 minecraft:light[level=14]
setblock 152 289 474 minecraft:light[level=14]
setblock 152 289 482 minecraft:light[level=14]
setblock 152 289 490 minecraft:light[level=14]
setblock 152 289 498 minecraft:light[level=14]
setblock 157 289 505 minecraft:pearlescent_froglight
setblock 160 289 466 minecraft:light[level=14]
setblock 160 289 474 minecraft:light[level=14]
setblock 160 289 482 minecraft:light[level=14]
setblock 160 289 490 minecraft:light[level=14]
setblock 160 289 498 minecraft:light[level=14]
setblock 168 289 466 minecraft:light[level=14]
setblock 168 289 474 minecraft:light[level=14]
setblock 168 289 482 minecraft:light[level=14]
setblock 168 289 490 minecraft:light[level=14]
setblock 168 289 498 minecraft:light[level=14]
fill 173 289 463 174 307 463 minecraft:purpur_block
setblock 176 289 466 minecraft:light[level=14]
setblock 176 289 474 minecraft:light[level=14]
setblock 176 289 482 minecraft:light[level=14]
setblock 176 289 490 minecraft:light[level=14]
setblock 176 289 498 minecraft:light[level=14]
setblock 177 289 505 minecraft:magenta_stained_glass
setblock 183 289 482 minecraft:pearlescent_froglight
setblock 156 290 463 minecraft:magenta_stained_glass
fill 157 290 505 157 307 505 minecraft:purpur_block
fill 166 290 463 166 307 463 minecraft:purpur_block
setblock 167 290 463 minecraft:magenta_stained_glass
fill 177 290 505 177 307 505 minecraft:purpur_block
setblock 183 290 477 minecraft:white_concrete
fill 183 290 482 183 307 482 minecraft:purpur_block
setblock 141 291 471 minecraft:white_concrete
fill 141 291 487 141 296 487 minecraft:purpur_block
fill 141 291 503 141 296 503 minecraft:purpur_block
fill 145 291 463 145 296 463 minecraft:purpur_block
fill 150 291 482 150 295 483 minecraft:purpur_block
fill 155 291 505 155 296 505 minecraft:purpur_block
fill 156 291 463 156 307 463 minecraft:purpur_block
fill 161 291 463 161 296 463 minecraft:purpur_block
fill 167 291 463 167 307 463 minecraft:purpur_block
fill 171 291 505 171 296 505 minecraft:purpur_block
setblock 175 291 505 minecraft:pearlescent_froglight
fill 177 291 463 177 296 463 minecraft:purpur_block
setblock 183 291 473 minecraft:white_concrete
fill 183 291 477 183 293 477 minecraft:purpur_block
fill 183 291 489 183 296 489 minecraft:purpur_block
setblock 183 291 501 minecraft:pearlescent_froglight
fill 141 292 471 141 296 471 minecraft:purpur_block
fill 148 292 482 148 295 483 minecraft:purpur_block
fill 149 292 481 149 295 481 minecraft:purpur_block
fill 149 292 484 149 295 484 minecraft:purpur_block
setblock 172 292 505 minecraft:white_concrete
fill 175 292 505 175 307 505 minecraft:purpur_block
setblock 181 292 505 minecraft:pearlescent_froglight
setblock 182 292 463 minecraft:white_concrete
fill 183 292 473 183 296 473 minecraft:purpur_block
fill 183 292 501 183 307 501 minecraft:purpur_block
setblock 141 293 504 minecraft:magenta_stained_glass
fill 141 293 505 141 307 505 minecraft:purpur_block
fill 148 293 481 148 295 481 minecraft:purpur_block
fill 148 293 484 148 295 484 minecraft:purpur_block
fill 150 293 481 150 295 481 minecraft:purpur_block
fill 150 293 484 150 295 484 minecraft:purpur_block
fill 151 293 482 151 295 483 minecraft:purpur_block
setblock 153 293 505 minecraft:magenta_stained_glass
setblock 170 293 505 minecraft:magenta_stained_glass
fill 172 293 505 172 307 505 minecraft:purpur_block
fill 181 293 505 181 307 505 minecraft:purpur_block
fill 182 293 463 182 307 463 minecraft:purpur_block
setblock 183 293 486 minecraft:magenta_stained_glass
setblock 141 294 472 minecraft:white_concrete
fill 141 294 504 141 297 504 minecraft:purpur_block
fill 147 294 482 147 295 483 minecraft:purpur_block
fill 149 294 480 149 295 480 minecraft:purpur_block
fill 151 294 481 151 295 481 minecraft:purpur_block
fill 151 294 484 151 295 484 minecraft:purpur_block
fill 153 294 505 153 307 505 minecraft:purpur_block
fill 169 294 491 171 295 491 minecraft:obsidian
fill 170 294 490 170 295 490 minecraft:obsidian
fill 170 294 492 170 295 492 minecraft:obsidian
fill 170 294 505 170 307 505 minecraft:purpur_block
setblock 183 294 477 minecraft:white_concrete
fill 183 294 486 183 307 486 minecraft:purpur_block
fill 141 295 472 141 303 472 minecraft:purpur_block
setblock 143 295 463 minecraft:magenta_stained_glass
setblock 146 295 505 minecraft:pearlescent_froglight
setblock 147 295 481 minecraft:purpur_block
setblock 147 295 484 minecraft:purpur_block
setblock 148 295 480 minecraft:purpur_block
fill 148 295 485 150 295 485 minecraft:purpur_block
setblock 150 295 480 minecraft:purpur_block
fill 152 295 482 152 295 483 minecraft:purpur_block
fill 183 295 477 183 307 477 minecraft:purpur_block
setblock 141 296 480 minecraft:magenta_stained_glass
setblock 141 296 493 minecraft:pearlescent_froglight
fill 141 296 494 141 307 494 minecraft:purpur_block
fill 143 296 463 143 302 463 minecraft:purpur_block
fill 146 296 505 146 307 505 minecraft:purpur_block
fill 148 296 482 148 300 482 minecraft:end_stone_bricks
fill 150 296 481 150 299 481 minecraft:end_stone_bricks
fill 150 296 484 150 297 484 minecraft:end_stone_bricks
setblock 158 296 463 minecraft:white_concrete
fill 183 296 466 183 307 466 minecraft:purpur_block
setblock 183 296 467 minecraft:pearlescent_froglight
fill 183 296 468 183 307 468 minecraft:purpur_block
fill 183 296 470 183 307 470 minecraft:purpur_block
setblock 183 296 471 minecraft:white_concrete
fill 141 297 471 141 299 471 minecraft:magenta_concrete
fill 141 297 480 141 307 480 minecraft:purpur_block
fill 141 297 487 141 299 487 minecraft:magenta_concrete
fill 141 297 493 141 307 493 minecraft:purpur_block
fill 141 297 503 141 299 503 minecraft:magenta_concrete
setblock 144 297 466 minecraft:light[level=14]
setblock 144 297 474 minecraft:light[level=14]
setblock 144 297 482 minecraft:light[level=14]
setblock 144 297 490 minecraft:light[level=14]
setblock 144 297 498 minecraft:light[level=14]
fill 145 297 463 145 299 463 minecraft:magenta_concrete
setblock 152 297 466 minecraft:light[level=14]
setblock 152 297 474 minecraft:light[level=14]
setblock 152 297 482 minecraft:light[level=14]
setblock 152 297 490 minecraft:light[level=14]
setblock 152 297 498 minecraft:light[level=14]
fill 155 297 505 155 299 505 minecraft:magenta_concrete
fill 158 297 463 158 305 463 minecraft:purpur_block
setblock 160 297 466 minecraft:light[level=14]
setblock 160 297 474 minecraft:light[level=14]
setblock 160 297 482 minecraft:light[level=14]
setblock 160 297 490 minecraft:light[level=14]
setblock 160 297 498 minecraft:light[level=14]
fill 161 297 463 161 299 463 minecraft:magenta_concrete
setblock 168 297 466 minecraft:light[level=14]
setblock 168 297 474 minecraft:light[level=14]
setblock 168 297 482 minecraft:light[level=14]
setblock 168 297 490 minecraft:light[level=14]
setblock 168 297 498 minecraft:light[level=14]
fill 171 297 505 171 299 505 minecraft:magenta_concrete
setblock 176 297 466 minecraft:light[level=14]
setblock 176 297 474 minecraft:light[level=14]
setblock 176 297 482 minecraft:light[level=14]
setblock 176 297 490 minecraft:light[level=14]
setblock 176 297 498 minecraft:light[level=14]
fill 177 297 463 177 299 463 minecraft:magenta_concrete
fill 183 297 467 183 307 467 minecraft:purpur_block
fill 183 297 471 183 307 471 minecraft:purpur_block
fill 183 297 473 183 299 473 minecraft:magenta_concrete
fill 183 297 489 183 299 489 minecraft:magenta_concrete
setblock 141 298 504 minecraft:pearlescent_froglight
setblock 151 298 463 minecraft:magenta_stained_glass
setblock 155 298 463 minecraft:white_concrete
setblock 183 298 479 minecraft:white_concrete
fill 141 299 504 141 307 504 minecraft:purpur_block
fill 151 299 463 151 307 463 minecraft:purpur_block
fill 155 299 463 155 307 463 minecraft:purpur_block
fill 183 299 479 183 307 479 minecraft:purpur_block
fill 141 300 471 141 307 471 minecraft:purpur_block
fill 141 300 487 141 307 487 minecraft:purpur_block
fill 141 300 503 141 307 503 minecraft:purpur_block
fill 145 300 463 145 307 463 minecraft:purpur_block
setblock 147 300 463 minecraft:white_concrete
setblock 150 300 463 minecraft:white_concrete
setblock 151 300 505 minecraft:magenta_stained_glass
fill 155 300 505 155 307 505 minecraft:purpur_block
fill 161 300 463 161 307 463 minecraft:purpur_block
fill 171 300 505 171 303 505 minecraft:purpur_block
fill 177 300 463 177 302 463 minecraft:purpur_block
fill 183 300 473 183 307 473 minecraft:purpur_block
fill 183 300 489 183 307 489 minecraft:purpur_block
fill 147 301 463 147 307 463 minecraft:purpur_block
fill 150 301 463 150 307 463 minecraft:purpur_block
fill 151 301 505 151 307 505 minecraft:purpur_block
setblock 141 302 496 minecraft:magenta_stained_glass
setblock 163 302 463 minecraft:white_concrete
setblock 183 302 487 minecraft:magenta_stained_glass
fill 183 302 488 183 307 488 minecraft:purpur_block
setblock 183 302 498 minecraft:white_concrete
setblock 141 303 483 minecraft:magenta_stained_glass
fill 141 303 496 141 307 496 minecraft:purpur_block
setblock 143 303 463 minecraft:magenta_stained_glass
fill 163 303 463 163 307 463 minecraft:purpur_block
setblock 177 303 463 minecraft:magenta_stained_glass
fill 183 303 487 183 307 487 minecraft:purpur_block
fill 183 303 498 183 307 498 minecraft:purpur_block
setblock 141 304 472 minecraft:pearlescent_froglight
setblock 141 304 481 minecraft:magenta_stained_glass
fill 141 304 483 141 307 483 minecraft:purpur_block
fill 143 304 463 143 307 463 minecraft:purpur_block
setblock 171 304 505 minecraft:white_concrete
fill 177 304 463 177 307 463 minecraft:purpur_block
fill 141 305 472 141 307 472 minecraft:purpur_block
fill 141 305 481 141 307 481 minecraft:purpur_block
setblock 160 305 463 minecraft:pearlescent_froglight
setblock 162 305 463 minecraft:magenta_stained_glass
fill 171 305 505 171 307 505 minecraft:purpur_block
setblock 154 306 463 minecraft:magenta_stained_glass
setblock 158 306 463 minecraft:white_concrete
fill 160 306 463 160 307 463 minecraft:purpur_block
fill 162 306 463 162 307 463 minecraft:purpur_block
setblock 154 307 463 minecraft:purpur_block
setblock 158 307 463 minecraft:purpur_block
