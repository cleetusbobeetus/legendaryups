setblock 351 172 526 minecraft:ochre_froglight
fill 351 172 527 351 172 529 minecraft:pearlescent_froglight
fill 351 172 530 354 172 530 minecraft:ochre_froglight
fill 351 172 531 353 172 533 minecraft:gold_block
fill 351 172 534 354 172 534 minecraft:ochre_froglight
fill 352 172 518 370 172 518 minecraft:gold_block
fill 352 172 523 355 172 523 minecraft:ochre_froglight
fill 352 172 524 354 172 526 minecraft:gold_block
fill 352 172 527 355 172 527 minecraft:ochre_froglight
fill 352 172 528 355 172 529 minecraft:yellow_concrete
fill 352 172 538 370 172 538 minecraft:gold_block
fill 353 172 522 370 172 522 minecraft:gold_block
fill 354 172 519 370 172 519 minecraft:gold_block
fill 354 172 531 354 172 533 minecraft:ochre_froglight
fill 354 172 537 370 172 537 minecraft:gold_block
fill 355 172 524 355 172 526 minecraft:ochre_froglight
fill 355 172 530 355 172 531 minecraft:yellow_concrete
fill 355 172 532 357 172 534 minecraft:gold_block
fill 356 172 520 370 172 520 minecraft:gold_block
fill 356 172 523 358 172 527 minecraft:gold_block
setblock 356 172 528 minecraft:yellow_concrete
fill 356 172 529 357 172 531 minecraft:gold_block
fill 356 172 536 370 172 536 minecraft:gold_block
fill 357 172 528 370 172 528 minecraft:gold_block
fill 358 172 529 370 172 530 minecraft:gold_block
fill 358 172 533 370 172 534 minecraft:gold_block
fill 359 172 523 370 172 525 minecraft:gold_block
fill 359 172 527 370 172 527 minecraft:gold_block
fill 359 172 531 370 172 532 minecraft:gold_block
fill 360 172 526 370 172 526 minecraft:gold_block
fill 337 173 528 337 174 529 minecraft:cobblestone
fill 339 173 521 339 174 522 minecraft:cobblestone
fill 339 173 536 339 174 537 minecraft:cobblestone
fill 340 173 521 345 173 535 minecraft:dark_oak_planks
fill 346 173 517 346 174 518 minecraft:cobblestone
fill 346 173 521 358 173 524 minecraft:dark_oak_planks
fill 346 173 533 358 173 535 minecraft:dark_oak_planks
fill 346 173 540 346 174 541 minecraft:cobblestone
fill 353 173 517 353 174 518 minecraft:cobblestone
fill 353 173 540 353 174 541 minecraft:cobblestone
fill 354 173 525 358 173 532 minecraft:dark_oak_planks
fill 360 173 521 360 174 522 minecraft:cobblestone
fill 360 173 536 360 174 537 minecraft:cobblestone
fill 362 173 528 362 174 529 minecraft:cobblestone
fill 340 174 521 340 174 535 minecraft:dark_oak_planks
fill 341 174 521 358 174 521 minecraft:dark_oak_planks
fill 341 174 535 358 174 535 minecraft:dark_oak_planks
fill 345 174 528 345 175 528 minecraft:glass
fill 349 174 524 349 175 524 minecraft:glass
fill 358 174 522 358 174 534 minecraft:dark_oak_planks
fill 340 175 521 340 180 521 minecraft:dark_oak_planks
setblock 340 175 522 minecraft:ochre_froglight
fill 340 175 523 340 180 524 minecraft:dark_oak_planks
setblock 340 175 525 minecraft:ochre_froglight
fill 340 175 526 340 180 527 minecraft:dark_oak_planks
setblock 340 175 528 minecraft:ochre_froglight
fill 340 175 529 340 180 530 minecraft:dark_oak_planks
setblock 340 175 531 minecraft:ochre_froglight
fill 340 175 532 340 180 533 minecraft:dark_oak_planks
setblock 340 175 534 minecraft:ochre_froglight
fill 340 175 535 341 180 535 minecraft:dark_oak_planks
setblock 341 175 521 minecraft:ochre_froglight
fill 342 175 521 343 180 521 minecraft:dark_oak_planks
setblock 342 175 535 minecraft:ochre_froglight
fill 343 175 535 344 180 535 minecraft:dark_oak_planks
setblock 344 175 521 minecraft:ochre_froglight
fill 344 175 527 344 176 529 minecraft:glass
fill 345 175 521 346 180 521 minecraft:dark_oak_planks
fill 345 175 525 345 175 527 minecraft:glass
fill 345 175 529 345 175 531 minecraft:glass
setblock 345 175 535 minecraft:ochre_froglight
fill 346 175 524 348 175 524 minecraft:glass
fill 346 175 535 347 180 535 minecraft:dark_oak_planks
setblock 347 175 521 minecraft:ochre_froglight
fill 348 175 521 349 180 521 minecraft:dark_oak_planks
fill 348 175 523 350 176 523 minecraft:glass
fill 348 175 533 350 176 533 minecraft:glass
setblock 348 175 535 minecraft:ochre_froglight
fill 349 175 535 350 180 535 minecraft:dark_oak_planks
setblock 350 175 521 minecraft:ochre_froglight
fill 350 175 524 352 175 524 minecraft:glass
fill 351 175 521 352 180 521 minecraft:dark_oak_planks
setblock 351 175 535 minecraft:ochre_froglight
fill 352 175 535 353 180 535 minecraft:dark_oak_planks
setblock 353 175 521 minecraft:ochre_froglight
fill 354 175 521 355 180 521 minecraft:dark_oak_planks
fill 354 175 527 354 176 529 minecraft:glass
setblock 354 175 535 minecraft:ochre_froglight
fill 355 175 535 356 180 535 minecraft:dark_oak_planks
setblock 356 175 521 minecraft:ochre_froglight
fill 357 175 521 358 180 521 minecraft:dark_oak_planks
setblock 357 175 535 minecraft:ochre_froglight
setblock 358 175 522 minecraft:ochre_froglight
fill 358 175 523 358 180 524 minecraft:dark_oak_planks
setblock 358 175 525 minecraft:ochre_froglight
fill 358 175 526 358 180 527 minecraft:dark_oak_planks
setblock 358 175 528 minecraft:ochre_froglight
fill 358 175 529 358 180 530 minecraft:dark_oak_planks
setblock 358 175 531 minecraft:ochre_froglight
fill 358 175 532 358 180 533 minecraft:dark_oak_planks
setblock 358 175 534 minecraft:ochre_froglight
fill 358 175 535 358 180 535 minecraft:dark_oak_planks
fill 330 176 511 332 226 511 minecraft:gold_block
fill 330 176 521 330 226 523 minecraft:gold_block
fill 330 176 533 330 226 535 minecraft:gold_block
fill 330 176 545 330 226 547 minecraft:gold_block
fill 336 176 551 338 226 551 minecraft:gold_block
fill 340 176 522 340 178 522 minecraft:dark_oak_planks
fill 340 176 525 340 178 525 minecraft:dark_oak_planks
fill 340 176 528 340 178 528 minecraft:dark_oak_planks
fill 340 176 531 340 178 531 minecraft:dark_oak_planks
fill 340 176 534 340 178 534 minecraft:dark_oak_planks
fill 341 176 521 341 178 521 minecraft:dark_oak_planks
fill 342 176 511 344 226 511 minecraft:gold_block
fill 342 176 535 342 178 535 minecraft:dark_oak_planks
fill 343 176 527 343 177 529 minecraft:glass
fill 344 176 521 344 178 521 minecraft:dark_oak_planks
fill 344 176 525 344 176 526 minecraft:glass
fill 344 176 530 344 176 531 minecraft:glass
fill 345 176 524 345 176 525 minecraft:glass
fill 345 176 531 345 176 532 minecraft:glass
fill 345 176 535 345 178 535 minecraft:dark_oak_planks
fill 346 176 523 346 176 524 minecraft:glass
fill 346 176 533 347 176 533 minecraft:glass
fill 347 176 521 347 178 521 minecraft:dark_oak_planks
setblock 347 176 523 minecraft:glass
fill 348 176 522 350 177 522 minecraft:glass
fill 348 176 534 350 177 534 minecraft:glass
fill 348 176 535 348 178 535 minecraft:dark_oak_planks
fill 348 176 551 350 226 551 minecraft:gold_block
setblock 350 176 520 minecraft:yellow_concrete
fill 350 176 521 350 178 521 minecraft:dark_oak_planks
fill 351 176 523 352 176 523 minecraft:glass
fill 351 176 533 352 176 533 minecraft:glass
fill 351 176 535 351 178 535 minecraft:dark_oak_planks
fill 352 176 524 353 176 524 minecraft:glass
fill 353 176 521 353 178 521 minecraft:dark_oak_planks
fill 354 176 511 356 226 511 minecraft:gold_block
fill 354 176 525 354 176 526 minecraft:glass
fill 354 176 530 354 176 531 minecraft:glass
fill 354 176 535 354 178 535 minecraft:dark_oak_planks
fill 355 176 527 355 177 529 minecraft:glass
fill 356 176 521 356 178 521 minecraft:dark_oak_planks
fill 357 176 535 357 178 535 minecraft:dark_oak_planks
fill 358 176 522 358 178 522 minecraft:dark_oak_planks
fill 358 176 525 358 178 525 minecraft:dark_oak_planks
fill 358 176 528 358 178 528 minecraft:dark_oak_planks
fill 358 176 531 358 178 531 minecraft:dark_oak_planks
fill 358 176 534 358 178 534 minecraft:dark_oak_planks
fill 360 176 551 362 226 551 minecraft:gold_block
fill 366 176 511 368 226 511 minecraft:gold_block
fill 370 176 519 370 226 521 minecraft:gold_block
fill 370 176 531 370 226 533 minecraft:gold_block
fill 370 176 543 370 226 545 minecraft:gold_block
fill 342 177 527 342 178 529 minecraft:glass
fill 343 177 525 343 177 526 minecraft:glass
fill 343 177 530 343 177 531 minecraft:glass
fill 344 177 523 344 177 525 minecraft:glass
fill 344 177 531 344 177 533 minecraft:glass
fill 345 177 523 346 177 523 minecraft:glass
fill 345 177 533 346 177 533 minecraft:glass
fill 346 177 522 347 177 522 minecraft:glass
fill 346 177 534 347 177 534 minecraft:glass
fill 351 177 522 352 177 522 minecraft:glass
fill 351 177 534 352 177 534 minecraft:glass
fill 352 177 523 354 177 523 minecraft:glass
fill 352 177 533 354 177 533 minecraft:glass
fill 354 177 524 354 177 525 minecraft:glass
fill 354 177 531 354 177 532 minecraft:glass
fill 355 177 525 355 177 526 minecraft:glass
fill 355 177 530 355 177 531 minecraft:glass
fill 356 177 527 356 178 529 minecraft:glass
fill 341 178 527 341 179 529 minecraft:glass
fill 342 178 524 342 178 526 minecraft:glass
fill 342 178 530 342 178 532 minecraft:glass
fill 343 178 523 343 178 524 minecraft:glass
fill 343 178 532 343 178 533 minecraft:glass
fill 344 178 522 344 178 523 minecraft:glass
fill 344 178 533 344 178 534 minecraft:glass
setblock 345 178 522 minecraft:glass
setblock 345 178 534 minecraft:glass
fill 348 178 520 350 179 520 minecraft:glass
fill 348 178 536 350 179 536 minecraft:glass
fill 353 178 522 354 178 522 minecraft:glass
fill 353 178 534 354 178 534 minecraft:glass
fill 354 178 523 355 178 523 minecraft:glass
fill 354 178 533 355 178 533 minecraft:glass
fill 355 178 524 356 178 524 minecraft:glass
fill 355 178 532 356 178 532 minecraft:glass
fill 356 178 525 356 178 526 minecraft:glass
fill 356 178 530 356 178 531 minecraft:glass
fill 357 178 527 357 179 529 minecraft:glass
setblock 332 179 513 minecraft:light[level=14]
setblock 332 179 521 minecraft:light[level=14]
setblock 332 179 529 minecraft:light[level=14]
setblock 332 179 537 minecraft:light[level=14]
setblock 332 179 545 minecraft:light[level=14]
setblock 340 179 513 minecraft:light[level=14]
setblock 340 179 522 minecraft:ochre_froglight
setblock 340 179 525 minecraft:ochre_froglight
setblock 340 179 528 minecraft:ochre_froglight
setblock 340 179 531 minecraft:ochre_froglight
setblock 340 179 534 minecraft:ochre_froglight
setblock 340 179 537 minecraft:light[level=14]
setblock 340 179 545 minecraft:light[level=14]
setblock 341 179 521 minecraft:ochre_froglight
fill 341 179 524 341 179 526 minecraft:glass
fill 341 179 530 341 179 532 minecraft:glass
fill 342 179 523 342 179 524 minecraft:glass
fill 342 179 532 342 179 533 minecraft:glass
setblock 342 179 535 minecraft:ochre_froglight
fill 343 179 522 343 179 523 minecraft:glass
fill 343 179 533 343 179 534 minecraft:glass
setblock 344 179 521 minecraft:ochre_froglight
setblock 344 179 522 minecraft:glass
setblock 344 179 534 minecraft:glass
fill 345 179 520 347 179 520 minecraft:glass
setblock 345 179 535 minecraft:ochre_froglight
fill 345 179 536 347 179 536 minecraft:glass
setblock 347 179 521 minecraft:ochre_froglight
setblock 348 179 513 minecraft:light[level=14]
fill 348 179 519 350 180 519 minecraft:glass
setblock 348 179 535 minecraft:ochre_froglight
fill 348 179 537 350 180 537 minecraft:glass
setblock 348 179 545 minecraft:light[level=14]
setblock 350 179 521 minecraft:ochre_froglight
fill 351 179 520 353 179 520 minecraft:glass
setblock 351 179 535 minecraft:ochre_froglight
fill 351 179 536 353 179 536 minecraft:glass
setblock 353 179 521 minecraft:ochre_froglight
fill 354 179 522 355 179 522 minecraft:glass
fill 354 179 534 355 179 534 minecraft:glass
setblock 354 179 535 minecraft:ochre_froglight
fill 355 179 523 356 179 523 minecraft:glass
fill 355 179 533 356 179 533 minecraft:glass
setblock 356 179 513 minecraft:light[level=14]
setblock 356 179 521 minecraft:ochre_froglight
fill 356 179 524 357 179 524 minecraft:glass
setblock 356 179 529 minecraft:light[level=14]
fill 356 179 532 357 179 532 minecraft:glass
setblock 356 179 537 minecraft:light[level=14]
setblock 356 179 545 minecraft:light[level=14]
fill 357 179 525 357 179 526 minecraft:glass
fill 357 179 530 357 179 531 minecraft:glass
setblock 357 179 535 minecraft:ochre_froglight
setblock 358 179 522 minecraft:ochre_froglight
setblock 358 179 525 minecraft:ochre_froglight
setblock 358 179 528 minecraft:ochre_froglight
setblock 358 179 531 minecraft:ochre_froglight
setblock 358 179 534 minecraft:ochre_froglight
setblock 364 179 513 minecraft:light[level=14]
setblock 364 179 521 minecraft:light[level=14]
setblock 364 179 529 minecraft:light[level=14]
setblock 364 179 537 minecraft:light[level=14]
setblock 364 179 545 minecraft:light[level=14]
fill 331 180 520 331 185 522 minecraft:gold_block
fill 331 180 532 331 185 534 minecraft:gold_block
fill 331 180 544 331 185 546 minecraft:gold_block
fill 337 180 550 339 185 550 minecraft:gold_block
fill 339 180 527 339 180 529 minecraft:glass
fill 340 180 522 358 180 522 minecraft:dark_oak_planks
fill 340 180 525 345 180 525 minecraft:dark_oak_planks
fill 340 180 528 345 180 528 minecraft:dark_oak_planks
fill 340 180 531 345 180 531 minecraft:dark_oak_planks
fill 340 180 534 358 180 534 minecraft:dark_oak_planks
fill 341 180 512 343 185 512 minecraft:gold_block
setblock 341 180 521 minecraft:dark_oak_planks
fill 341 180 523 357 180 524 minecraft:dark_oak_planks
fill 341 180 526 345 180 527 minecraft:dark_oak_planks
fill 341 180 529 345 180 530 minecraft:dark_oak_planks
fill 341 180 532 345 180 533 minecraft:dark_oak_planks
setblock 342 180 535 minecraft:dark_oak_planks
fill 343 180 520 345 180 520 minecraft:glass
fill 343 180 536 345 180 536 minecraft:glass
setblock 344 180 521 minecraft:dark_oak_planks
fill 345 180 519 347 180 519 minecraft:glass
setblock 345 180 535 minecraft:dark_oak_planks
fill 345 180 537 347 180 537 minecraft:glass
fill 346 180 533 357 180 533 minecraft:dark_oak_planks
setblock 347 180 521 minecraft:dark_oak_planks
fill 348 180 518 350 180 518 minecraft:glass
setblock 348 180 535 minecraft:dark_oak_planks
fill 348 180 538 350 180 538 minecraft:glass
fill 349 180 550 351 185 550 minecraft:gold_block
setblock 350 180 521 minecraft:dark_oak_planks
fill 351 180 519 353 180 519 minecraft:glass
setblock 351 180 535 minecraft:dark_oak_planks
fill 351 180 537 353 180 537 minecraft:glass
fill 353 180 512 355 185 512 minecraft:gold_block
fill 353 180 520 355 180 520 minecraft:glass
setblock 353 180 521 minecraft:dark_oak_planks
fill 353 180 536 355 180 536 minecraft:glass
fill 354 180 525 357 180 532 minecraft:dark_oak_planks
setblock 354 180 535 minecraft:dark_oak_planks
setblock 356 180 521 minecraft:dark_oak_planks
setblock 357 180 535 minecraft:dark_oak_planks
setblock 358 180 525 minecraft:dark_oak_planks
setblock 358 180 528 minecraft:dark_oak_planks
setblock 358 180 531 minecraft:dark_oak_planks
fill 359 180 527 359 180 529 minecraft:glass
fill 361 180 550 363 185 550 minecraft:gold_block
fill 365 180 512 367 185 512 minecraft:gold_block
fill 369 180 520 369 185 522 minecraft:gold_block
fill 369 180 532 369 185 534 minecraft:gold_block
fill 369 180 544 369 185 546 minecraft:gold_block
fill 339 181 526 339 182 530 minecraft:gold_block
fill 340 181 521 345 181 535 minecraft:deepslate_tiles
fill 343 181 520 346 182 520 minecraft:gold_block
fill 343 181 536 346 182 536 minecraft:gold_block
fill 345 181 519 353 182 519 minecraft:gold_block
fill 345 181 537 353 182 537 minecraft:gold_block
fill 346 181 521 358 181 524 minecraft:deepslate_tiles
fill 346 181 533 358 181 535 minecraft:deepslate_tiles
fill 347 181 518 351 182 518 minecraft:gold_block
fill 347 181 538 351 182 538 minecraft:gold_block
fill 352 181 520 355 182 520 minecraft:gold_block
fill 352 181 536 355 182 536 minecraft:gold_block
fill 354 181 525 358 181 532 minecraft:deepslate_tiles
fill 359 181 526 359 182 530 minecraft:gold_block
fill 340 182 524 340 182 532 minecraft:gold_block
fill 341 182 522 345 182 534 minecraft:deepslate_tiles
fill 342 182 521 344 182 521 minecraft:gold_block
fill 342 182 535 344 182 535 minecraft:gold_block
fill 346 182 522 357 182 524 minecraft:deepslate_tiles
fill 346 182 533 357 182 534 minecraft:deepslate_tiles
fill 354 182 521 356 182 521 minecraft:gold_block
fill 354 182 525 357 182 532 minecraft:deepslate_tiles
fill 354 182 535 356 182 535 minecraft:gold_block
fill 358 182 524 358 182 532 minecraft:gold_block
fill 342 183 523 345 183 533 minecraft:deepslate_tiles
fill 346 183 523 356 183 524 minecraft:deepslate_tiles
fill 346 183 533 356 183 533 minecraft:deepslate_tiles
fill 354 183 525 356 183 532 minecraft:deepslate_tiles
fill 343 184 524 345 184 532 minecraft:deepslate_tiles
fill 346 184 524 355 184 524 minecraft:deepslate_tiles
fill 354 184 525 355 184 532 minecraft:deepslate_tiles
fill 330 185 514 330 185 519 minecraft:cut_sandstone
fill 330 185 526 330 185 531 minecraft:cut_sandstone
fill 330 185 538 330 185 543 minecraft:cut_sandstone
fill 330 185 550 330 185 551 minecraft:cut_sandstone
fill 331 185 551 334 185 551 minecraft:cut_sandstone
fill 334 185 511 339 185 511 minecraft:cut_sandstone
fill 341 185 551 346 185 551 minecraft:cut_sandstone
fill 344 185 525 345 185 531 minecraft:deepslate_tiles
fill 346 185 511 351 185 511 minecraft:cut_sandstone
fill 353 185 551 358 185 551 minecraft:cut_sandstone
fill 354 185 525 354 185 531 minecraft:deepslate_tiles
fill 358 185 511 363 185 511 minecraft:cut_sandstone
fill 365 185 551 370 185 551 minecraft:cut_sandstone
fill 370 185 511 370 185 516 minecraft:cut_sandstone
fill 370 185 523 370 185 528 minecraft:cut_sandstone
fill 370 185 535 370 185 540 minecraft:cut_sandstone
fill 370 185 547 370 185 550 minecraft:cut_sandstone
fill 329 186 516 329 191 519 minecraft:ochre_froglight
fill 329 186 528 329 191 531 minecraft:ochre_froglight
fill 329 186 540 329 191 543 minecraft:ochre_froglight
fill 329 186 552 332 191 552 minecraft:ochre_froglight
fill 336 186 510 339 191 510 minecraft:ochre_froglight
fill 341 186 552 344 191 552 minecraft:ochre_froglight
fill 345 186 526 345 186 530 minecraft:deepslate_tiles
fill 348 186 510 351 191 510 minecraft:ochre_froglight
fill 353 186 552 356 191 552 minecraft:ochre_froglight
fill 360 186 510 363 191 510 minecraft:ochre_froglight
fill 365 186 552 368 191 552 minecraft:ochre_froglight
fill 371 186 511 371 191 514 minecraft:ochre_froglight
fill 371 186 523 371 191 526 minecraft:ochre_froglight
fill 371 186 535 371 191 538 minecraft:ochre_froglight
fill 371 186 547 371 191 550 minecraft:ochre_froglight
setblock 332 187 513 minecraft:light[level=14]
setblock 332 187 521 minecraft:light[level=14]
setblock 332 187 529 minecraft:light[level=14]
setblock 332 187 537 minecraft:light[level=14]
setblock 332 187 545 minecraft:light[level=14]
setblock 340 187 513 minecraft:light[level=14]
setblock 340 187 521 minecraft:light[level=14]
setblock 340 187 529 minecraft:light[level=14]
setblock 340 187 537 minecraft:light[level=14]
setblock 340 187 545 minecraft:light[level=14]
setblock 348 187 513 minecraft:light[level=14]
setblock 348 187 521 minecraft:light[level=14]
setblock 348 187 537 minecraft:light[level=14]
setblock 348 187 545 minecraft:light[level=14]
setblock 356 187 513 minecraft:light[level=14]
setblock 356 187 521 minecraft:light[level=14]
setblock 356 187 529 minecraft:light[level=14]
setblock 356 187 537 minecraft:light[level=14]
setblock 356 187 545 minecraft:light[level=14]
fill 360 187 538 360 188 539 minecraft:sandstone
setblock 364 187 513 minecraft:light[level=14]
setblock 364 187 521 minecraft:light[level=14]
setblock 364 187 529 minecraft:light[level=14]
setblock 364 187 537 minecraft:light[level=14]
setblock 364 187 545 minecraft:light[level=14]
fill 329 191 510 329 191 511 minecraft:cut_sandstone
setblock 329 191 512 minecraft:sandstone
setblock 329 191 538 minecraft:sandstone
fill 329 191 544 329 191 545 minecraft:sandstone
fill 329 191 546 329 194 546 minecraft:cut_sandstone
fill 330 191 510 332 194 510 minecraft:cut_sandstone
setblock 333 191 510 minecraft:sandstone
fill 333 191 552 333 194 552 minecraft:cut_sandstone
fill 334 191 510 335 194 510 minecraft:cut_sandstone
setblock 334 191 552 minecraft:sandstone
fill 345 191 552 347 194 552 minecraft:cut_sandstone
setblock 347 191 510 minecraft:sandstone
setblock 348 191 552 minecraft:sandstone
fill 349 191 552 352 194 552 minecraft:cut_sandstone
fill 352 191 510 352 193 510 minecraft:sandstone
fill 353 191 510 358 192 510 minecraft:cut_sandstone
setblock 357 191 552 minecraft:cut_sandstone
fill 358 191 552 358 192 552 minecraft:sandstone
setblock 359 191 552 minecraft:cut_sandstone
setblock 364 191 510 minecraft:sandstone
setblock 370 191 552 minecraft:sandstone
fill 371 191 516 371 191 517 minecraft:sandstone
fill 371 191 518 371 192 521 minecraft:cut_sandstone
setblock 371 191 522 minecraft:sandstone
fill 371 191 527 371 191 528 minecraft:sandstone
fill 371 191 529 371 192 529 minecraft:cut_sandstone
fill 371 191 542 371 194 544 minecraft:cut_sandstone
fill 371 191 545 371 191 546 minecraft:sandstone
fill 329 192 510 329 194 510 minecraft:cut_sandstone
setblock 329 192 511 minecraft:sandstone
setblock 329 192 512 minecraft:cut_sandstone
setblock 329 192 516 minecraft:cut_sandstone
fill 329 192 517 329 192 518 minecraft:ochre_froglight
fill 329 192 519 329 194 519 minecraft:cut_sandstone
setblock 329 192 522 minecraft:sandstone
fill 329 192 525 329 194 525 minecraft:cut_sandstone
fill 329 192 526 329 193 526 minecraft:sandstone
fill 329 192 527 329 194 528 minecraft:cut_sandstone
fill 329 192 529 329 192 530 minecraft:ochre_froglight
fill 329 192 531 329 194 531 minecraft:cut_sandstone
fill 329 192 535 329 194 535 minecraft:cut_sandstone
setblock 329 192 536 minecraft:sandstone
setblock 329 192 538 minecraft:cut_sandstone
setblock 329 192 540 minecraft:sandstone
fill 329 192 541 329 192 542 minecraft:ochre_froglight
fill 329 192 543 329 192 545 minecraft:cut_sandstone
fill 329 192 552 329 195 552 minecraft:cut_sandstone
fill 330 192 552 331 192 552 minecraft:ochre_froglight
fill 332 192 552 332 195 552 minecraft:cut_sandstone
fill 333 192 510 333 194 510 minecraft:cut_sandstone
fill 334 192 552 334 194 552 minecraft:cut_sandstone
fill 336 192 510 336 194 510 minecraft:cut_sandstone
fill 337 192 510 338 192 510 minecraft:ochre_froglight
fill 339 192 510 339 194 510 minecraft:cut_sandstone
setblock 341 192 552 minecraft:sandstone
fill 342 192 552 343 192 552 minecraft:ochre_froglight
setblock 344 192 510 minecraft:sandstone
fill 344 192 552 344 194 552 minecraft:cut_sandstone
fill 345 192 510 348 194 510 minecraft:cut_sandstone
fill 348 192 552 348 194 552 minecraft:cut_sandstone
fill 349 192 510 350 192 510 minecraft:ochre_froglight
fill 351 192 510 351 196 510 minecraft:cut_sandstone
fill 353 192 552 353 194 552 minecraft:cut_sandstone
fill 354 192 552 355 192 552 minecraft:ochre_froglight
fill 356 192 552 357 192 552 minecraft:sandstone
fill 359 192 552 360 192 552 minecraft:sandstone
fill 360 192 510 360 194 510 minecraft:cut_sandstone
fill 361 192 510 362 192 510 minecraft:ochre_froglight
fill 361 192 552 361 194 552 minecraft:cut_sandstone
fill 363 192 510 364 194 510 minecraft:cut_sandstone
fill 365 192 552 365 194 552 minecraft:cut_sandstone
fill 366 192 552 367 192 552 minecraft:ochre_froglight
fill 368 192 552 368 194 552 minecraft:cut_sandstone
fill 370 192 510 370 194 510 minecraft:cut_sandstone
setblock 370 192 552 minecraft:cut_sandstone
setblock 371 192 510 minecraft:sandstone
setblock 371 192 511 minecraft:cut_sandstone
fill 371 192 512 371 192 513 minecraft:ochre_froglight
setblock 371 192 514 minecraft:sandstone
fill 371 192 516 371 194 517 minecraft:cut_sandstone
fill 371 192 522 371 194 523 minecraft:cut_sandstone
fill 371 192 524 371 192 525 minecraft:ochre_froglight
fill 371 192 526 371 194 528 minecraft:cut_sandstone
fill 371 192 530 371 194 530 minecraft:cut_sandstone
fill 371 192 531 371 193 531 minecraft:sandstone
fill 371 192 532 371 194 533 minecraft:cut_sandstone
setblock 371 192 534 minecraft:sandstone
fill 371 192 535 371 194 535 minecraft:cut_sandstone
fill 371 192 536 371 192 537 minecraft:ochre_froglight
fill 371 192 538 371 194 538 minecraft:cut_sandstone
setblock 371 192 541 minecraft:sandstone
fill 371 192 545 371 194 547 minecraft:cut_sandstone
fill 371 192 548 371 192 549 minecraft:ochre_froglight
fill 371 192 550 371 194 550 minecraft:cut_sandstone
fill 329 193 511 329 194 511 minecraft:cut_sandstone
setblock 329 193 512 minecraft:sandstone
setblock 329 193 516 minecraft:sandstone
fill 329 193 517 329 194 518 minecraft:cut_sandstone
fill 329 193 522 329 194 522 minecraft:cut_sandstone
setblock 329 193 523 minecraft:sandstone
fill 329 193 529 329 194 530 minecraft:cut_sandstone
fill 329 193 536 329 194 536 minecraft:cut_sandstone
setblock 329 193 538 minecraft:sandstone
fill 329 193 540 329 194 540 minecraft:cut_sandstone
setblock 329 193 541 minecraft:sandstone
fill 329 193 542 329 194 543 minecraft:cut_sandstone
setblock 329 193 544 minecraft:sandstone
fill 329 193 545 329 194 545 minecraft:cut_sandstone
fill 329 193 547 329 194 548 minecraft:cut_sandstone
setblock 329 193 549 minecraft:sandstone
fill 329 193 550 329 194 550 minecraft:cut_sandstone
fill 330 193 552 331 194 552 minecraft:cut_sandstone
fill 337 193 510 338 194 510 minecraft:cut_sandstone
fill 341 193 552 343 194 552 minecraft:cut_sandstone
fill 344 193 510 344 194 510 minecraft:cut_sandstone
fill 349 193 510 350 194 510 minecraft:cut_sandstone
fill 353 193 510 357 194 510 minecraft:cut_sandstone
fill 354 193 552 360 194 552 minecraft:cut_sandstone
setblock 358 193 510 minecraft:sandstone
fill 361 193 510 362 194 510 minecraft:cut_sandstone
setblock 366 193 552 minecraft:sandstone
fill 367 193 552 367 194 552 minecraft:cut_sandstone
setblock 368 193 510 minecraft:sandstone
setblock 370 193 552 minecraft:sandstone
fill 371 193 510 371 194 510 minecraft:cut_sandstone
setblock 371 193 511 minecraft:sandstone
fill 371 193 512 371 194 514 minecraft:cut_sandstone
fill 371 193 518 371 194 519 minecraft:cut_sandstone
fill 371 193 520 371 193 521 minecraft:sandstone
fill 371 193 524 371 194 525 minecraft:cut_sandstone
setblock 371 193 529 minecraft:sandstone
fill 371 193 534 371 194 534 minecraft:cut_sandstone
fill 371 193 536 371 194 537 minecraft:cut_sandstone
fill 371 193 541 371 194 541 minecraft:cut_sandstone
fill 371 193 548 371 194 549 minecraft:cut_sandstone
setblock 329 194 512 minecraft:cut_sandstone
setblock 329 194 516 minecraft:cut_sandstone
setblock 329 194 523 minecraft:cut_sandstone
setblock 329 194 526 minecraft:cut_sandstone
setblock 329 194 538 minecraft:cut_sandstone
setblock 329 194 541 minecraft:cut_sandstone
setblock 329 194 544 minecraft:cut_sandstone
setblock 329 194 549 minecraft:cut_sandstone
fill 342 194 523 342 195 523 minecraft:sandstone
fill 352 194 510 352 195 510 minecraft:cut_sandstone
setblock 358 194 510 minecraft:cut_sandstone
setblock 366 194 552 minecraft:cut_sandstone
fill 368 194 510 368 195 510 minecraft:cut_sandstone
setblock 370 194 552 minecraft:cut_sandstone
setblock 371 194 511 minecraft:cut_sandstone
fill 371 194 520 371 194 521 minecraft:cut_sandstone
setblock 371 194 529 minecraft:cut_sandstone
setblock 371 194 531 minecraft:cut_sandstone
fill 329 195 510 329 195 514 minecraft:sandstone
setblock 329 195 515 minecraft:cut_sandstone
fill 329 195 516 329 195 551 minecraft:sandstone
fill 330 195 510 333 196 510 minecraft:sandstone
fill 330 195 552 331 195 552 minecraft:sandstone
setblock 332 195 513 minecraft:light[level=14]
setblock 332 195 521 minecraft:light[level=14]
setblock 332 195 529 minecraft:light[level=14]
setblock 332 195 537 minecraft:light[level=14]
setblock 332 195 545 minecraft:light[level=14]
fill 333 195 552 371 195 552 minecraft:sandstone
setblock 334 195 510 minecraft:cut_sandstone
fill 335 195 510 336 195 510 minecraft:sandstone
setblock 337 195 510 minecraft:cut_sandstone
fill 338 195 510 345 196 510 minecraft:sandstone
setblock 340 195 513 minecraft:light[level=14]
setblock 340 195 521 minecraft:light[level=14]
setblock 340 195 529 minecraft:light[level=14]
setblock 340 195 537 minecraft:light[level=14]
setblock 340 195 545 minecraft:light[level=14]
setblock 346 195 510 minecraft:cut_sandstone
fill 347 195 510 350 205 510 minecraft:sandstone
setblock 348 195 513 minecraft:light[level=14]
setblock 348 195 521 minecraft:light[level=14]
setblock 348 195 529 minecraft:light[level=14]
setblock 348 195 537 minecraft:light[level=14]
setblock 348 195 545 minecraft:light[level=14]
fill 353 195 510 358 195 510 minecraft:sandstone
setblock 356 195 513 minecraft:light[level=14]
setblock 356 195 521 minecraft:light[level=14]
setblock 356 195 529 minecraft:light[level=14]
setblock 356 195 537 minecraft:light[level=14]
setblock 356 195 545 minecraft:light[level=14]
fill 360 195 510 367 195 510 minecraft:sandstone
setblock 364 195 513 minecraft:light[level=14]
setblock 364 195 521 minecraft:light[level=14]
setblock 364 195 529 minecraft:light[level=14]
setblock 364 195 537 minecraft:light[level=14]
setblock 364 195 545 minecraft:light[level=14]
fill 370 195 510 371 307 510 minecraft:sandstone
fill 371 195 511 371 205 514 minecraft:sandstone
fill 371 195 516 371 195 518 minecraft:sandstone
setblock 371 195 519 minecraft:cut_sandstone
fill 371 195 520 371 307 520 minecraft:sandstone
fill 371 195 521 371 195 522 minecraft:cut_sandstone
fill 371 195 523 371 195 532 minecraft:sandstone
setblock 371 195 533 minecraft:cut_sandstone
fill 371 195 534 371 195 544 minecraft:sandstone
setblock 371 195 545 minecraft:cut_sandstone
fill 371 195 546 371 195 550 minecraft:sandstone
setblock 371 195 551 minecraft:cut_sandstone
fill 329 196 510 329 307 512 minecraft:sandstone
setblock 329 196 513 minecraft:cut_sandstone
fill 329 196 514 329 205 517 minecraft:sandstone
setblock 329 196 518 minecraft:cut_sandstone
fill 329 196 519 329 205 519 minecraft:sandstone
setblock 329 196 520 minecraft:cut_sandstone
fill 329 196 521 329 196 525 minecraft:sandstone
setblock 329 196 526 minecraft:cut_sandstone
fill 329 196 527 329 196 536 minecraft:sandstone
setblock 329 196 537 minecraft:cut_sandstone
fill 329 196 538 329 205 541 minecraft:sandstone
setblock 329 196 542 minecraft:cut_sandstone
fill 329 196 543 329 205 543 minecraft:sandstone
fill 329 196 544 329 197 544 minecraft:cut_sandstone
fill 329 196 545 329 196 552 minecraft:sandstone
fill 330 196 552 330 205 552 minecraft:sandstone
setblock 331 196 552 minecraft:cut_sandstone
fill 332 196 552 341 205 552 minecraft:sandstone
fill 334 196 510 334 307 510 minecraft:sandstone
setblock 335 196 510 minecraft:cut_sandstone
fill 336 196 510 337 205 510 minecraft:sandstone
setblock 342 196 552 minecraft:cut_sandstone
fill 343 196 552 347 205 552 minecraft:sandstone
fill 346 196 510 346 307 510 minecraft:sandstone
fill 348 196 552 349 196 552 minecraft:cut_sandstone
fill 350 196 552 356 205 552 minecraft:sandstone
fill 352 196 510 353 307 510 minecraft:sandstone
setblock 354 196 510 minecraft:cut_sandstone
fill 355 196 510 355 307 510 minecraft:sandstone
setblock 356 196 510 minecraft:cut_sandstone
fill 357 196 510 359 196 510 minecraft:sandstone
setblock 357 196 552 minecraft:cut_sandstone
fill 358 196 552 369 196 552 minecraft:sandstone
setblock 360 196 510 minecraft:cut_sandstone
fill 361 196 510 368 205 510 minecraft:sandstone
fill 370 196 552 370 197 552 minecraft:cut_sandstone
fill 371 196 515 371 307 516 minecraft:sandstone
setblock 371 196 517 minecraft:cut_sandstone
fill 371 196 518 371 307 519 minecraft:sandstone
fill 371 196 521 371 196 530 minecraft:sandstone
setblock 371 196 531 minecraft:cut_sandstone
fill 371 196 532 371 205 537 minecraft:sandstone
setblock 371 196 538 minecraft:cut_sandstone
fill 371 196 539 371 196 548 minecraft:sandstone
fill 371 196 549 371 197 549 minecraft:cut_sandstone
fill 371 196 550 371 196 552 minecraft:sandstone
fill 329 197 513 329 307 513 minecraft:sandstone
fill 329 197 518 329 205 518 minecraft:sandstone
fill 329 197 520 329 307 523 minecraft:sandstone
setblock 329 197 524 minecraft:cut_sandstone
fill 329 197 525 329 307 527 minecraft:sandstone
setblock 329 197 528 minecraft:cut_sandstone
fill 329 197 529 329 205 531 minecraft:sandstone
setblock 329 197 532 minecraft:cut_sandstone
fill 329 197 533 329 307 534 minecraft:sandstone
setblock 329 197 535 minecraft:cut_sandstone
fill 329 197 536 329 307 537 minecraft:sandstone
fill 329 197 542 329 205 542 minecraft:sandstone
fill 329 197 545 329 307 550 minecraft:sandstone
setblock 329 197 551 minecraft:cut_sandstone
fill 329 197 552 329 205 552 minecraft:sandstone
setblock 330 197 510 minecraft:cut_sandstone
fill 331 197 510 333 307 510 minecraft:sandstone
fill 331 197 552 331 205 552 minecraft:sandstone
fill 335 197 510 335 307 510 minecraft:sandstone
fill 338 197 510 338 205 510 minecraft:sandstone
setblock 339 197 510 minecraft:cut_sandstone
fill 340 197 510 345 307 510 minecraft:sandstone
fill 342 197 552 342 205 552 minecraft:sandstone
fill 348 197 552 349 307 552 minecraft:sandstone
fill 351 197 510 351 205 510 minecraft:sandstone
fill 354 197 510 354 307 510 minecraft:sandstone
fill 356 197 510 357 307 510 minecraft:sandstone
fill 357 197 552 357 307 552 minecraft:sandstone
setblock 358 197 510 minecraft:cut_sandstone
setblock 358 197 552 minecraft:cut_sandstone
fill 359 197 510 360 205 510 minecraft:sandstone
fill 359 197 552 362 307 552 minecraft:sandstone
setblock 363 197 552 minecraft:cut_sandstone
fill 364 197 552 369 205 552 minecraft:sandstone
fill 369 197 510 369 307 510 minecraft:sandstone
fill 371 197 517 371 307 517 minecraft:sandstone
fill 371 197 521 371 205 523 minecraft:sandstone
setblock 371 197 524 minecraft:cut_sandstone
fill 371 197 525 371 205 531 minecraft:sandstone
fill 371 197 538 371 205 541 minecraft:sandstone
setblock 371 197 542 minecraft:cut_sandstone
fill 371 197 543 371 205 548 minecraft:sandstone
setblock 371 197 550 minecraft:cut_sandstone
fill 371 197 551 371 307 552 minecraft:sandstone
fill 329 198 524 329 307 524 minecraft:sandstone
fill 329 198 528 329 205 528 minecraft:sandstone
fill 329 198 532 329 307 532 minecraft:sandstone
fill 329 198 535 329 307 535 minecraft:sandstone
fill 329 198 544 329 307 544 minecraft:sandstone
fill 329 198 551 329 307 551 minecraft:sandstone
fill 330 198 510 330 307 510 minecraft:sandstone
fill 339 198 510 339 205 510 minecraft:sandstone
fill 358 198 510 358 307 510 minecraft:sandstone
fill 358 198 552 358 307 552 minecraft:sandstone
fill 363 198 552 363 307 552 minecraft:sandstone
fill 370 198 552 370 307 552 minecraft:sandstone
fill 371 198 524 371 205 524 minecraft:sandstone
fill 371 198 542 371 307 542 minecraft:sandstone
fill 371 198 549 371 205 550 minecraft:sandstone
fill 331 200 520 331 205 522 minecraft:gold_block
fill 331 200 532 331 205 534 minecraft:gold_block
fill 331 200 544 331 205 546 minecraft:gold_block
fill 337 200 550 339 205 550 minecraft:gold_block
fill 341 200 512 343 205 512 minecraft:gold_block
fill 349 200 550 351 205 550 minecraft:gold_block
fill 353 200 512 355 205 512 minecraft:gold_block
fill 361 200 550 363 205 550 minecraft:gold_block
fill 365 200 512 367 205 512 minecraft:gold_block
fill 369 200 520 369 205 522 minecraft:gold_block
fill 369 200 532 369 205 534 minecraft:gold_block
fill 369 200 544 369 205 546 minecraft:gold_block
setblock 332 203 513 minecraft:light[level=14]
setblock 332 203 521 minecraft:light[level=14]
setblock 332 203 529 minecraft:light[level=14]
setblock 332 203 537 minecraft:light[level=14]
setblock 332 203 545 minecraft:light[level=14]
setblock 340 203 513 minecraft:light[level=14]
setblock 340 203 521 minecraft:light[level=14]
setblock 340 203 529 minecraft:light[level=14]
setblock 340 203 537 minecraft:light[level=14]
setblock 340 203 545 minecraft:light[level=14]
setblock 348 203 513 minecraft:light[level=14]
setblock 348 203 521 minecraft:light[level=14]
setblock 348 203 529 minecraft:light[level=14]
setblock 348 203 537 minecraft:light[level=14]
setblock 348 203 545 minecraft:light[level=14]
setblock 356 203 513 minecraft:light[level=14]
setblock 356 203 521 minecraft:light[level=14]
setblock 356 203 529 minecraft:light[level=14]
setblock 356 203 537 minecraft:light[level=14]
setblock 356 203 545 minecraft:light[level=14]
setblock 364 203 513 minecraft:light[level=14]
setblock 364 203 521 minecraft:light[level=14]
setblock 364 203 529 minecraft:light[level=14]
setblock 364 203 537 minecraft:light[level=14]
setblock 364 203 545 minecraft:light[level=14]
fill 330 205 514 330 205 519 minecraft:cut_sandstone
fill 330 205 526 330 205 531 minecraft:cut_sandstone
fill 330 205 538 330 205 543 minecraft:cut_sandstone
fill 330 205 550 330 205 551 minecraft:cut_sandstone
fill 331 205 551 334 205 551 minecraft:cut_sandstone
fill 334 205 511 339 205 511 minecraft:cut_sandstone
fill 341 205 551 346 205 551 minecraft:cut_sandstone
fill 346 205 511 351 205 511 minecraft:cut_sandstone
fill 353 205 551 358 205 551 minecraft:cut_sandstone
fill 358 205 511 363 205 511 minecraft:cut_sandstone
fill 365 205 551 370 205 551 minecraft:cut_sandstone
fill 370 205 511 370 205 516 minecraft:cut_sandstone
fill 370 205 523 370 205 528 minecraft:cut_sandstone
fill 370 205 535 370 205 540 minecraft:cut_sandstone
fill 370 205 547 370 205 550 minecraft:cut_sandstone
fill 329 206 514 329 307 515 minecraft:sandstone
fill 329 206 516 329 211 519 minecraft:ochre_froglight
fill 329 206 528 329 211 531 minecraft:ochre_froglight
fill 329 206 538 329 307 539 minecraft:sandstone
fill 329 206 540 329 211 543 minecraft:ochre_froglight
fill 329 206 552 332 211 552 minecraft:ochre_froglight
fill 333 206 552 340 307 552 minecraft:sandstone
fill 336 206 510 339 211 510 minecraft:ochre_froglight
fill 341 206 552 344 211 552 minecraft:ochre_froglight
fill 345 206 552 347 307 552 minecraft:sandstone
fill 347 206 510 347 307 510 minecraft:sandstone
fill 348 206 510 351 211 510 minecraft:ochre_froglight
fill 350 206 552 352 307 552 minecraft:sandstone
fill 353 206 552 356 211 552 minecraft:ochre_froglight
fill 359 206 510 359 307 510 minecraft:sandstone
fill 360 206 510 363 211 510 minecraft:ochre_froglight
fill 364 206 510 368 307 510 minecraft:sandstone
fill 364 206 552 364 307 552 minecraft:sandstone
fill 365 206 552 368 211 552 minecraft:ochre_froglight
fill 369 206 552 369 307 552 minecraft:sandstone
fill 371 206 511 371 211 514 minecraft:ochre_froglight
fill 371 206 521 371 307 522 minecraft:sandstone
fill 371 206 523 371 211 526 minecraft:ochre_froglight
fill 371 206 527 371 307 534 minecraft:sandstone
fill 371 206 535 371 211 538 minecraft:ochre_froglight
fill 371 206 539 371 307 541 minecraft:sandstone
fill 371 206 543 371 307 546 minecraft:sandstone
fill 371 206 547 371 211 550 minecraft:ochre_froglight
fill 340 209 532 340 210 533 minecraft:yellow_concrete
setblock 332 211 513 minecraft:light[level=14]
setblock 332 211 521 minecraft:light[level=14]
setblock 332 211 529 minecraft:light[level=14]
setblock 332 211 537 minecraft:light[level=14]
setblock 332 211 545 minecraft:light[level=14]
setblock 340 211 513 minecraft:light[level=14]
setblock 340 211 521 minecraft:light[level=14]
setblock 340 211 529 minecraft:light[level=14]
setblock 340 211 537 minecraft:light[level=14]
setblock 340 211 545 minecraft:light[level=14]
setblock 348 211 513 minecraft:light[level=14]
setblock 348 211 521 minecraft:light[level=14]
setblock 348 211 529 minecraft:light[level=14]
setblock 348 211 537 minecraft:light[level=14]
setblock 348 211 545 minecraft:light[level=14]
setblock 356 211 513 minecraft:light[level=14]
setblock 356 211 521 minecraft:light[level=14]
setblock 356 211 529 minecraft:light[level=14]
setblock 356 211 537 minecraft:light[level=14]
setblock 356 211 545 minecraft:light[level=14]
setblock 364 211 513 minecraft:light[level=14]
setblock 364 211 521 minecraft:light[level=14]
setblock 364 211 529 minecraft:light[level=14]
setblock 364 211 537 minecraft:light[level=14]
setblock 364 211 545 minecraft:light[level=14]
fill 329 212 516 329 225 516 minecraft:sandstone
fill 329 212 517 329 212 518 minecraft:ochre_froglight
fill 329 212 519 329 225 519 minecraft:sandstone
fill 329 212 528 329 225 528 minecraft:sandstone
fill 329 212 529 329 212 530 minecraft:ochre_froglight
fill 329 212 531 329 225 531 minecraft:sandstone
fill 329 212 540 329 225 540 minecraft:sandstone
fill 329 212 541 329 212 542 minecraft:ochre_froglight
fill 329 212 543 329 225 543 minecraft:sandstone
fill 329 212 552 329 225 552 minecraft:sandstone
fill 330 212 552 331 212 552 minecraft:ochre_froglight
fill 332 212 552 332 225 552 minecraft:sandstone
fill 336 212 510 336 225 510 minecraft:sandstone
fill 337 212 510 338 212 510 minecraft:ochre_froglight
fill 339 212 510 339 225 510 minecraft:sandstone
fill 341 212 552 341 225 552 minecraft:sandstone
fill 342 212 552 343 212 552 minecraft:ochre_froglight
fill 344 212 552 344 225 552 minecraft:sandstone
fill 348 212 510 348 225 510 minecraft:sandstone
fill 349 212 510 350 212 510 minecraft:ochre_froglight
fill 351 212 510 351 225 510 minecraft:sandstone
fill 353 212 552 353 225 552 minecraft:sandstone
fill 354 212 552 355 212 552 minecraft:ochre_froglight
fill 356 212 552 356 225 552 minecraft:sandstone
fill 360 212 510 360 225 510 minecraft:sandstone
fill 361 212 510 362 212 510 minecraft:ochre_froglight
fill 363 212 510 363 225 510 minecraft:sandstone
fill 365 212 552 365 225 552 minecraft:sandstone
fill 366 212 552 367 212 552 minecraft:ochre_froglight
fill 368 212 552 368 225 552 minecraft:sandstone
fill 371 212 511 371 225 511 minecraft:sandstone
fill 371 212 512 371 212 513 minecraft:ochre_froglight
fill 371 212 514 371 225 514 minecraft:sandstone
fill 371 212 523 371 225 523 minecraft:sandstone
fill 371 212 524 371 212 525 minecraft:ochre_froglight
fill 371 212 526 371 225 526 minecraft:sandstone
fill 371 212 535 371 225 535 minecraft:sandstone
fill 371 212 536 371 212 537 minecraft:ochre_froglight
fill 371 212 538 371 225 538 minecraft:sandstone
fill 371 212 547 371 225 547 minecraft:sandstone
fill 371 212 548 371 212 549 minecraft:ochre_froglight
fill 371 212 550 371 225 550 minecraft:sandstone
fill 329 213 517 329 225 518 minecraft:sandstone
fill 329 213 529 329 225 530 minecraft:sandstone
fill 329 213 541 329 225 542 minecraft:sandstone
fill 330 213 552 331 225 552 minecraft:sandstone
fill 337 213 510 338 225 510 minecraft:sandstone
fill 342 213 552 343 225 552 minecraft:sandstone
fill 349 213 510 350 225 510 minecraft:sandstone
fill 354 213 552 355 225 552 minecraft:sandstone
fill 361 213 510 362 225 510 minecraft:sandstone
fill 366 213 552 367 225 552 minecraft:sandstone
fill 371 213 512 371 225 513 minecraft:sandstone
fill 371 213 524 371 225 525 minecraft:sandstone
fill 371 213 536 371 225 537 minecraft:sandstone
fill 371 213 548 371 225 549 minecraft:sandstone
setblock 332 219 513 minecraft:light[level=14]
setblock 332 219 521 minecraft:light[level=14]
setblock 332 219 529 minecraft:light[level=14]
setblock 332 219 537 minecraft:light[level=14]
setblock 332 219 545 minecraft:light[level=14]
setblock 340 219 513 minecraft:light[level=14]
setblock 340 219 521 minecraft:light[level=14]
setblock 340 219 529 minecraft:light[level=14]
setblock 340 219 537 minecraft:light[level=14]
setblock 340 219 545 minecraft:light[level=14]
setblock 348 219 513 minecraft:light[level=14]
setblock 348 219 521 minecraft:light[level=14]
setblock 348 219 529 minecraft:light[level=14]
setblock 348 219 537 minecraft:light[level=14]
setblock 348 219 545 minecraft:light[level=14]
fill 351 219 539 351 220 540 minecraft:sandstone
setblock 356 219 513 minecraft:light[level=14]
setblock 356 219 521 minecraft:light[level=14]
setblock 356 219 529 minecraft:light[level=14]
setblock 356 219 537 minecraft:light[level=14]
setblock 356 219 545 minecraft:light[level=14]
setblock 364 219 513 minecraft:light[level=14]
setblock 364 219 521 minecraft:light[level=14]
setblock 364 219 529 minecraft:light[level=14]
setblock 364 219 537 minecraft:light[level=14]
setblock 364 219 545 minecraft:light[level=14]
fill 331 220 520 331 225 522 minecraft:gold_block
fill 331 220 532 331 225 534 minecraft:gold_block
fill 331 220 544 331 225 546 minecraft:gold_block
fill 337 220 550 339 225 550 minecraft:gold_block
fill 341 220 512 343 225 512 minecraft:gold_block
fill 349 220 550 351 225 550 minecraft:gold_block
fill 353 220 512 355 225 512 minecraft:gold_block
fill 361 220 550 363 225 550 minecraft:gold_block
fill 365 220 512 367 225 512 minecraft:gold_block
fill 369 220 520 369 225 522 minecraft:gold_block
fill 369 220 532 369 225 534 minecraft:gold_block
fill 369 220 544 369 225 546 minecraft:gold_block
fill 337 221 525 337 222 525 minecraft:sandstone
fill 332 223 527 332 224 535 minecraft:gold_block
fill 333 223 524 333 224 527 minecraft:gold_block
fill 333 223 535 333 224 538 minecraft:gold_block
fill 334 223 522 334 224 524 minecraft:gold_block
fill 334 223 538 334 224 540 minecraft:gold_block
fill 335 223 520 335 224 522 minecraft:gold_block
fill 335 223 540 335 224 542 minecraft:gold_block
fill 336 223 519 336 224 520 minecraft:gold_block
fill 336 223 542 336 224 543 minecraft:gold_block
fill 337 223 518 337 224 519 minecraft:gold_block
fill 337 223 543 337 224 544 minecraft:gold_block
fill 338 223 517 338 224 518 minecraft:gold_block
fill 338 223 544 338 224 545 minecraft:gold_block
fill 339 223 516 339 224 517 minecraft:gold_block
fill 339 223 545 339 224 546 minecraft:gold_block
fill 340 223 516 341 224 516 minecraft:gold_block
fill 340 223 546 341 224 546 minecraft:gold_block
fill 341 223 515 343 224 515 minecraft:gold_block
fill 341 223 547 343 224 547 minecraft:gold_block
fill 343 223 514 346 224 514 minecraft:gold_block
fill 343 223 548 346 224 548 minecraft:gold_block
fill 346 223 513 354 224 513 minecraft:gold_block
fill 346 223 549 354 224 549 minecraft:gold_block
fill 354 223 514 357 224 514 minecraft:gold_block
fill 354 223 548 357 224 548 minecraft:gold_block
fill 357 223 515 359 224 515 minecraft:gold_block
fill 357 223 547 359 224 547 minecraft:gold_block
fill 359 223 516 361 224 516 minecraft:gold_block
fill 359 223 546 361 224 546 minecraft:gold_block
fill 361 223 517 362 224 517 minecraft:gold_block
fill 361 223 545 362 224 545 minecraft:gold_block
fill 362 223 518 363 224 518 minecraft:gold_block
fill 362 223 544 363 224 544 minecraft:gold_block
fill 363 223 519 364 224 519 minecraft:gold_block
fill 363 223 543 364 224 543 minecraft:gold_block
fill 364 223 520 365 224 520 minecraft:gold_block
fill 364 223 542 365 224 542 minecraft:gold_block
fill 365 223 521 365 224 522 minecraft:gold_block
fill 365 223 540 365 224 541 minecraft:gold_block
fill 366 223 522 366 224 524 minecraft:gold_block
fill 366 223 538 366 224 540 minecraft:gold_block
fill 367 223 524 367 224 527 minecraft:gold_block
fill 367 223 535 367 224 538 minecraft:gold_block
fill 368 223 527 368 224 535 minecraft:gold_block
fill 330 225 514 330 225 519 minecraft:cut_sandstone
fill 330 225 526 330 225 531 minecraft:cut_sandstone
fill 330 225 538 330 225 543 minecraft:cut_sandstone
fill 330 225 550 330 225 551 minecraft:cut_sandstone
fill 331 225 530 331 225 531 minecraft:ochre_froglight
fill 331 225 551 334 225 551 minecraft:cut_sandstone
fill 332 225 525 332 225 529 minecraft:ochre_froglight
fill 332 225 533 332 225 537 minecraft:ochre_froglight
fill 333 225 523 333 225 524 minecraft:ochre_froglight
fill 333 225 538 333 225 539 minecraft:ochre_froglight
fill 334 225 511 339 225 511 minecraft:cut_sandstone
fill 334 225 521 334 225 522 minecraft:ochre_froglight
fill 334 225 540 334 225 541 minecraft:ochre_froglight
setblock 335 225 520 minecraft:ochre_froglight
setblock 335 225 542 minecraft:ochre_froglight
setblock 336 225 519 minecraft:ochre_froglight
setblock 336 225 543 minecraft:ochre_froglight
setblock 337 225 518 minecraft:ochre_froglight
setblock 337 225 544 minecraft:ochre_froglight
setblock 338 225 517 minecraft:ochre_froglight
setblock 338 225 545 minecraft:ochre_froglight
setblock 339 225 516 minecraft:ochre_froglight
setblock 339 225 546 minecraft:ochre_froglight
fill 340 225 515 341 225 515 minecraft:ochre_froglight
fill 340 225 547 341 225 547 minecraft:ochre_froglight
fill 341 225 551 346 225 551 minecraft:cut_sandstone
fill 342 225 514 343 225 514 minecraft:ochre_froglight
fill 342 225 548 343 225 548 minecraft:ochre_froglight
fill 344 225 513 346 225 513 minecraft:ochre_froglight
fill 344 225 549 348 225 549 minecraft:ochre_froglight
fill 346 225 511 351 225 511 minecraft:cut_sandstone
fill 352 225 549 356 225 549 minecraft:ochre_froglight
fill 353 225 551 358 225 551 minecraft:cut_sandstone
fill 357 225 548 358 225 548 minecraft:ochre_froglight
fill 358 225 511 363 225 511 minecraft:cut_sandstone
fill 359 225 547 360 225 547 minecraft:ochre_froglight
setblock 361 225 546 minecraft:ochre_froglight
setblock 362 225 545 minecraft:ochre_froglight
setblock 363 225 544 minecraft:ochre_froglight
setblock 364 225 543 minecraft:ochre_froglight
fill 365 225 540 365 226 541 minecraft:sandstone
setblock 365 225 542 minecraft:ochre_froglight
fill 365 225 551 370 225 551 minecraft:cut_sandstone
fill 366 225 540 366 225 541 minecraft:ochre_froglight
fill 367 225 538 367 225 539 minecraft:ochre_froglight
fill 368 225 526 368 225 529 minecraft:ochre_froglight
fill 368 225 533 368 225 537 minecraft:ochre_froglight
fill 369 225 530 369 225 531 minecraft:ochre_froglight
fill 370 225 511 370 225 516 minecraft:cut_sandstone
fill 370 225 523 370 225 528 minecraft:cut_sandstone
fill 370 225 535 370 225 540 minecraft:cut_sandstone
fill 370 225 547 370 225 550 minecraft:cut_sandstone
fill 329 226 516 329 226 519 minecraft:ochre_froglight
fill 329 226 528 329 226 531 minecraft:ochre_froglight
fill 329 226 540 329 226 543 minecraft:ochre_froglight
fill 329 226 552 332 226 552 minecraft:ochre_froglight
fill 336 226 510 339 226 510 minecraft:ochre_froglight
fill 341 226 552 344 226 552 minecraft:ochre_froglight
fill 348 226 510 351 226 510 minecraft:ochre_froglight
fill 353 226 552 356 226 552 minecraft:ochre_froglight
fill 360 226 510 363 226 510 minecraft:ochre_froglight
fill 365 226 552 368 226 552 minecraft:ochre_froglight
fill 366 226 540 366 226 541 minecraft:sandstone
fill 371 226 511 371 226 514 minecraft:ochre_froglight
fill 371 226 523 371 226 526 minecraft:ochre_froglight
fill 371 226 535 371 226 538 minecraft:ochre_froglight
fill 371 226 547 371 226 550 minecraft:ochre_froglight
fill 329 227 516 329 245 519 minecraft:sandstone
fill 329 227 528 329 245 531 minecraft:sandstone
fill 329 227 540 329 245 543 minecraft:sandstone
fill 329 227 552 332 245 552 minecraft:sandstone
setblock 332 227 513 minecraft:light[level=14]
setblock 332 227 521 minecraft:light[level=14]
setblock 332 227 529 minecraft:light[level=14]
setblock 332 227 537 minecraft:light[level=14]
setblock 332 227 545 minecraft:light[level=14]
fill 336 227 510 339 245 510 minecraft:sandstone
setblock 340 227 513 minecraft:light[level=14]
setblock 340 227 521 minecraft:light[level=14]
setblock 340 227 529 minecraft:light[level=14]
setblock 340 227 537 minecraft:light[level=14]
setblock 340 227 545 minecraft:light[level=14]
fill 341 227 552 344 245 552 minecraft:sandstone
fill 348 227 510 351 245 510 minecraft:sandstone
setblock 348 227 513 minecraft:light[level=14]
setblock 348 227 521 minecraft:light[level=14]
setblock 348 227 529 minecraft:light[level=14]
setblock 348 227 537 minecraft:light[level=14]
setblock 348 227 545 minecraft:light[level=14]
fill 353 227 552 356 245 552 minecraft:sandstone
setblock 356 227 513 minecraft:light[level=14]
setblock 356 227 521 minecraft:light[level=14]
setblock 356 227 529 minecraft:light[level=14]
setblock 356 227 537 minecraft:light[level=14]
setblock 356 227 545 minecraft:light[level=14]
fill 360 227 510 363 245 510 minecraft:sandstone
setblock 364 227 513 minecraft:light[level=14]
setblock 364 227 521 minecraft:light[level=14]
setblock 364 227 529 minecraft:light[level=14]
setblock 364 227 537 minecraft:light[level=14]
setblock 364 227 545 minecraft:light[level=14]
fill 365 227 552 368 245 552 minecraft:sandstone
fill 371 227 511 371 245 514 minecraft:sandstone
fill 371 227 523 371 245 526 minecraft:sandstone
fill 371 227 535 371 245 538 minecraft:sandstone
fill 371 227 547 371 245 550 minecraft:sandstone
fill 335 232 531 337 233 531 minecraft:yellow_concrete
fill 336 232 526 338 233 530 minecraft:yellow_concrete
fill 336 232 532 337 233 536 minecraft:yellow_concrete
fill 337 232 524 337 233 524 minecraft:sandstone
fill 337 232 525 342 233 525 minecraft:yellow_concrete
fill 337 232 537 337 233 538 minecraft:yellow_concrete
fill 338 232 522 338 233 523 minecraft:sandstone
fill 338 232 524 344 233 524 minecraft:yellow_concrete
fill 338 232 531 343 233 538 minecraft:sandstone
fill 338 232 539 338 233 540 minecraft:yellow_concrete
fill 339 232 521 339 233 522 minecraft:sandstone
fill 339 232 523 354 233 523 minecraft:yellow_concrete
fill 339 232 526 339 233 528 minecraft:yellow_concrete
fill 339 232 529 345 233 530 minecraft:sandstone
fill 339 232 539 345 233 540 minecraft:sandstone
fill 339 232 541 339 233 541 minecraft:yellow_concrete
fill 340 232 520 341 233 521 minecraft:sandstone
fill 340 232 522 353 233 522 minecraft:yellow_concrete
fill 340 232 526 340 233 527 minecraft:yellow_concrete
fill 340 232 528 348 233 528 minecraft:sandstone
fill 340 232 541 348 233 542 minecraft:sandstone
fill 341 232 519 359 233 519 minecraft:sandstone
fill 341 232 526 341 233 526 minecraft:yellow_concrete
fill 341 232 527 352 233 527 minecraft:sandstone
fill 341 232 543 359 233 543 minecraft:sandstone
fill 342 232 520 343 233 520 minecraft:sandstone
fill 342 232 521 351 233 521 minecraft:yellow_concrete
fill 342 232 526 351 233 526 minecraft:sandstone
fill 343 232 518 357 233 518 minecraft:sandstone
fill 343 232 525 350 233 525 minecraft:sandstone
fill 343 232 544 357 233 544 minecraft:sandstone
fill 344 232 520 349 233 520 minecraft:yellow_concrete
fill 344 232 531 344 233 533 minecraft:sandstone
fill 344 232 534 347 233 534 minecraft:yellow_concrete
fill 344 232 535 344 233 538 minecraft:sandstone
fill 345 232 517 355 233 517 minecraft:sandstone
fill 345 232 524 348 233 524 minecraft:sandstone
fill 345 232 531 346 233 533 minecraft:yellow_concrete
fill 345 232 535 347 233 537 minecraft:yellow_concrete
fill 345 232 538 345 233 538 minecraft:sandstone
fill 345 232 545 355 233 545 minecraft:sandstone
fill 346 232 529 347 233 529 minecraft:sandstone
fill 346 232 530 346 233 530 minecraft:yellow_concrete
fill 346 232 538 351 233 539 minecraft:yellow_concrete
fill 346 232 540 346 233 540 minecraft:sandstone
fill 347 232 530 347 232 532 minecraft:gold_block
fill 347 232 533 347 233 533 minecraft:yellow_concrete
fill 347 232 540 360 233 540 minecraft:yellow_concrete
fill 348 232 529 348 232 530 minecraft:gold_block
fill 348 232 532 348 232 533 minecraft:gold_block
fill 348 232 534 348 233 535 minecraft:sandstone
fill 348 232 536 348 233 537 minecraft:yellow_concrete
fill 349 232 524 354 233 524 minecraft:yellow_concrete
fill 349 232 528 349 232 529 minecraft:gold_block
fill 349 232 533 349 232 534 minecraft:gold_block
fill 349 232 535 358 233 536 minecraft:sandstone
fill 349 232 537 349 233 537 minecraft:yellow_concrete
fill 349 232 541 358 233 541 minecraft:yellow_concrete
fill 349 232 542 350 233 542 minecraft:sandstone
fill 350 232 516 350 233 516 minecraft:sandstone
fill 350 232 520 360 233 520 minecraft:sandstone
fill 350 232 528 351 232 528 minecraft:gold_block
fill 350 232 534 351 232 534 minecraft:gold_block
fill 350 232 537 357 233 537 minecraft:sandstone
fill 350 232 546 350 233 546 minecraft:sandstone
fill 351 232 525 355 233 525 minecraft:yellow_concrete
fill 351 232 529 352 232 529 minecraft:gold_block
fill 351 232 533 352 232 533 minecraft:gold_block
fill 351 232 542 356 233 542 minecraft:yellow_concrete
fill 352 232 521 360 233 521 minecraft:sandstone
fill 352 232 526 355 233 526 minecraft:yellow_concrete
fill 352 232 528 352 233 528 minecraft:sandstone
fill 352 232 530 353 232 530 minecraft:gold_block
fill 352 232 532 353 232 532 minecraft:gold_block
fill 352 232 534 360 233 534 minecraft:sandstone
fill 352 232 538 355 233 538 minecraft:sandstone
fill 352 232 539 361 233 539 minecraft:yellow_concrete
fill 353 232 527 355 233 529 minecraft:yellow_concrete
setblock 353 232 531 minecraft:gold_block
fill 353 232 533 361 233 533 minecraft:sandstone
fill 354 232 522 361 233 522 minecraft:sandstone
fill 354 232 530 354 233 532 minecraft:yellow_concrete
fill 355 232 523 361 233 524 minecraft:sandstone
fill 355 232 530 355 233 531 minecraft:yellow_concrete
fill 355 232 532 361 233 532 minecraft:sandstone
fill 356 232 525 362 233 527 minecraft:sandstone
fill 356 232 528 356 233 528 minecraft:yellow_concrete
fill 356 232 529 362 233 531 minecraft:sandstone
fill 356 232 538 362 233 538 minecraft:yellow_concrete
fill 357 232 528 362 233 528 minecraft:sandstone
fill 357 232 542 360 233 542 minecraft:sandstone
fill 358 232 537 363 233 537 minecraft:yellow_concrete
fill 359 232 535 359 233 535 minecraft:sandstone
fill 359 232 536 364 233 536 minecraft:yellow_concrete
fill 359 232 541 361 233 541 minecraft:sandstone
fill 360 232 535 364 233 535 minecraft:yellow_concrete
fill 361 232 521 361 233 521 minecraft:yellow_concrete
fill 361 232 534 364 233 534 minecraft:yellow_concrete
fill 361 232 540 362 233 540 minecraft:sandstone
fill 362 232 522 362 233 523 minecraft:yellow_concrete
fill 362 232 524 362 233 524 minecraft:sandstone
fill 362 232 532 364 233 533 minecraft:yellow_concrete
fill 362 232 539 362 233 539 minecraft:sandstone
fill 363 232 524 363 233 531 minecraft:yellow_concrete
fill 363 232 538 363 233 538 minecraft:sandstone
fill 364 232 526 364 233 531 minecraft:yellow_concrete
fill 365 232 531 365 233 531 minecraft:yellow_concrete
fill 330 233 511 334 233 551 minecraft:cut_sandstone
fill 335 233 511 335 233 530 minecraft:cut_sandstone
fill 335 233 532 335 233 551 minecraft:cut_sandstone
fill 336 233 511 336 233 525 minecraft:cut_sandstone
fill 336 233 537 336 233 551 minecraft:cut_sandstone
fill 337 233 511 337 233 523 minecraft:cut_sandstone
fill 337 233 539 337 233 551 minecraft:cut_sandstone
fill 338 233 511 338 233 521 minecraft:cut_sandstone
fill 338 233 541 338 233 551 minecraft:cut_sandstone
fill 339 233 511 339 233 520 minecraft:cut_sandstone
fill 339 233 542 339 233 551 minecraft:cut_sandstone
fill 340 233 511 340 233 519 minecraft:cut_sandstone
fill 340 233 543 340 233 551 minecraft:cut_sandstone
fill 341 233 511 342 233 518 minecraft:cut_sandstone
fill 341 233 544 342 233 551 minecraft:cut_sandstone
fill 343 233 511 344 233 517 minecraft:cut_sandstone
fill 343 233 545 344 233 551 minecraft:cut_sandstone
fill 345 233 511 349 233 516 minecraft:cut_sandstone
fill 345 233 546 349 233 551 minecraft:cut_sandstone
fill 347 233 530 347 233 532 minecraft:ochre_froglight
fill 348 233 529 348 233 530 minecraft:ochre_froglight
fill 348 233 532 348 233 533 minecraft:ochre_froglight
fill 349 233 528 349 233 529 minecraft:ochre_froglight
fill 349 233 533 349 233 534 minecraft:ochre_froglight
fill 350 233 511 370 233 515 minecraft:cut_sandstone
fill 350 233 528 351 233 528 minecraft:ochre_froglight
fill 350 233 534 351 233 534 minecraft:ochre_froglight
fill 350 233 547 370 233 551 minecraft:cut_sandstone
fill 351 233 516 370 233 516 minecraft:cut_sandstone
fill 351 233 529 352 233 529 minecraft:ochre_froglight
fill 351 233 533 352 233 533 minecraft:ochre_froglight
fill 351 233 546 370 233 546 minecraft:cut_sandstone
fill 352 233 530 353 233 530 minecraft:ochre_froglight
fill 352 233 532 353 233 532 minecraft:ochre_froglight
setblock 353 233 531 minecraft:ochre_froglight
fill 356 233 517 370 233 517 minecraft:cut_sandstone
fill 356 233 545 370 233 545 minecraft:cut_sandstone
fill 358 233 518 370 233 518 minecraft:cut_sandstone
fill 358 233 544 370 233 544 minecraft:cut_sandstone
fill 360 233 519 370 233 519 minecraft:cut_sandstone
fill 360 233 543 370 233 543 minecraft:cut_sandstone
fill 361 233 520 370 233 520 minecraft:cut_sandstone
fill 361 233 542 370 233 542 minecraft:cut_sandstone
fill 362 233 521 370 233 521 minecraft:cut_sandstone
fill 362 233 541 370 233 541 minecraft:cut_sandstone
fill 363 233 522 370 233 523 minecraft:cut_sandstone
fill 363 233 539 370 233 540 minecraft:cut_sandstone
fill 364 233 524 370 233 525 minecraft:cut_sandstone
fill 364 233 537 370 233 538 minecraft:cut_sandstone
fill 365 233 526 370 233 530 minecraft:cut_sandstone
fill 365 233 532 370 233 536 minecraft:cut_sandstone
fill 366 233 531 370 233 531 minecraft:cut_sandstone
setblock 332 235 513 minecraft:light[level=14]
setblock 332 235 521 minecraft:light[level=14]
setblock 332 235 529 minecraft:light[level=14]
setblock 332 235 537 minecraft:light[level=14]
setblock 332 235 545 minecraft:light[level=14]
setblock 340 235 513 minecraft:light[level=14]
setblock 340 235 521 minecraft:light[level=14]
setblock 340 235 529 minecraft:light[level=14]
setblock 340 235 537 minecraft:light[level=14]
setblock 340 235 545 minecraft:light[level=14]
setblock 348 235 513 minecraft:light[level=14]
setblock 348 235 521 minecraft:light[level=14]
setblock 348 235 529 minecraft:light[level=14]
setblock 348 235 537 minecraft:light[level=14]
setblock 348 235 545 minecraft:light[level=14]
setblock 356 235 513 minecraft:light[level=14]
setblock 356 235 521 minecraft:light[level=14]
setblock 356 235 529 minecraft:light[level=14]
setblock 356 235 537 minecraft:light[level=14]
setblock 356 235 545 minecraft:light[level=14]
setblock 364 235 513 minecraft:light[level=14]
setblock 364 235 521 minecraft:light[level=14]
setblock 364 235 529 minecraft:light[level=14]
setblock 364 235 537 minecraft:light[level=14]
setblock 364 235 545 minecraft:light[level=14]
fill 330 237 511 332 273 511 minecraft:gold_block
fill 330 237 521 330 273 523 minecraft:gold_block
fill 330 237 533 330 273 535 minecraft:gold_block
fill 330 237 545 330 273 547 minecraft:gold_block
fill 332 237 513 332 237 514 minecraft:cut_sandstone
fill 332 237 515 335 273 515 minecraft:gold_block
setblock 332 237 516 minecraft:cut_sandstone
fill 333 237 513 335 237 513 minecraft:cut_sandstone
fill 333 237 514 335 273 514 minecraft:gold_block
fill 333 237 516 335 273 516 minecraft:gold_block
fill 333 237 517 335 237 517 minecraft:cut_sandstone
fill 336 237 514 336 237 516 minecraft:cut_sandstone
fill 336 237 551 338 273 551 minecraft:gold_block
fill 342 237 511 344 273 511 minecraft:gold_block
setblock 348 237 543 minecraft:yellow_concrete
fill 348 237 551 350 273 551 minecraft:gold_block
fill 354 237 511 356 273 511 minecraft:gold_block
fill 360 237 551 362 273 551 minecraft:gold_block
fill 366 237 511 368 273 511 minecraft:gold_block
fill 370 237 519 370 273 521 minecraft:gold_block
fill 370 237 531 370 273 533 minecraft:gold_block
fill 370 237 543 370 273 545 minecraft:gold_block
fill 331 240 520 331 245 522 minecraft:gold_block
fill 331 240 532 331 245 534 minecraft:gold_block
fill 331 240 544 331 245 546 minecraft:gold_block
fill 335 240 535 335 241 535 minecraft:sandstone
fill 337 240 550 339 245 550 minecraft:gold_block
fill 341 240 512 343 245 512 minecraft:gold_block
fill 349 240 550 351 245 550 minecraft:gold_block
fill 353 240 512 355 245 512 minecraft:gold_block
fill 361 240 550 363 245 550 minecraft:gold_block
fill 365 240 512 367 245 512 minecraft:gold_block
fill 369 240 520 369 245 522 minecraft:gold_block
fill 369 240 532 369 245 534 minecraft:gold_block
fill 369 240 544 369 245 546 minecraft:gold_block
setblock 332 243 513 minecraft:light[level=14]
setblock 332 243 521 minecraft:light[level=14]
setblock 332 243 529 minecraft:light[level=14]
setblock 332 243 537 minecraft:light[level=14]
setblock 332 243 545 minecraft:light[level=14]
setblock 340 243 513 minecraft:light[level=14]
setblock 340 243 521 minecraft:light[level=14]
setblock 340 243 529 minecraft:light[level=14]
setblock 340 243 537 minecraft:light[level=14]
setblock 340 243 545 minecraft:light[level=14]
setblock 348 243 513 minecraft:light[level=14]
setblock 348 243 521 minecraft:light[level=14]
setblock 348 243 529 minecraft:light[level=14]
setblock 348 243 537 minecraft:light[level=14]
setblock 348 243 545 minecraft:light[level=14]
setblock 356 243 513 minecraft:light[level=14]
setblock 356 243 521 minecraft:light[level=14]
setblock 356 243 529 minecraft:light[level=14]
setblock 356 243 537 minecraft:light[level=14]
setblock 356 243 545 minecraft:light[level=14]
setblock 364 243 513 minecraft:light[level=14]
setblock 364 243 521 minecraft:light[level=14]
setblock 364 243 529 minecraft:light[level=14]
setblock 364 243 537 minecraft:light[level=14]
setblock 364 243 545 minecraft:light[level=14]
fill 332 244 525 332 245 537 minecraft:gold_block
fill 333 244 523 333 245 530 minecraft:gold_block
fill 333 244 532 333 245 539 minecraft:gold_block
fill 334 244 521 334 245 525 minecraft:gold_block
fill 334 244 537 334 245 541 minecraft:gold_block
fill 335 244 520 335 245 522 minecraft:gold_block
fill 335 244 540 335 245 542 minecraft:gold_block
fill 336 244 519 336 245 521 minecraft:gold_block
fill 336 244 541 336 245 543 minecraft:gold_block
fill 337 244 518 337 245 520 minecraft:gold_block
fill 337 244 542 337 245 544 minecraft:gold_block
fill 338 244 517 339 245 518 minecraft:gold_block
fill 338 244 544 339 245 545 minecraft:gold_block
fill 339 244 516 341 245 516 minecraft:gold_block
fill 339 244 546 341 245 546 minecraft:gold_block
fill 340 244 515 344 245 515 minecraft:gold_block
fill 340 244 517 340 245 517 minecraft:gold_block
fill 340 244 545 340 245 545 minecraft:gold_block
fill 340 244 547 344 245 547 minecraft:gold_block
fill 342 244 514 349 245 514 minecraft:gold_block
fill 342 244 548 349 245 548 minecraft:gold_block
fill 344 244 513 356 245 513 minecraft:gold_block
fill 344 244 549 356 245 549 minecraft:gold_block
fill 351 244 514 358 245 514 minecraft:gold_block
fill 351 244 548 358 245 548 minecraft:gold_block
fill 356 244 515 360 245 515 minecraft:gold_block
fill 356 244 547 360 245 547 minecraft:gold_block
fill 359 244 516 361 245 516 minecraft:gold_block
fill 359 244 546 361 245 546 minecraft:gold_block
fill 360 244 517 362 245 517 minecraft:gold_block
fill 360 244 545 362 245 545 minecraft:gold_block
fill 361 244 518 363 245 518 minecraft:gold_block
fill 361 244 544 363 245 544 minecraft:gold_block
fill 363 244 519 364 245 520 minecraft:gold_block
fill 363 244 542 364 245 543 minecraft:gold_block
fill 364 244 521 366 245 521 minecraft:gold_block
fill 364 244 541 366 245 541 minecraft:gold_block
fill 365 244 520 365 245 520 minecraft:gold_block
fill 365 244 522 366 245 522 minecraft:gold_block
fill 365 244 540 366 245 540 minecraft:gold_block
fill 365 244 542 365 245 542 minecraft:gold_block
fill 366 244 523 367 245 525 minecraft:gold_block
fill 366 244 537 367 245 539 minecraft:gold_block
fill 367 244 526 368 245 530 minecraft:gold_block
fill 367 244 532 368 245 536 minecraft:gold_block
fill 368 244 525 368 245 525 minecraft:gold_block
fill 368 244 531 368 245 531 minecraft:gold_block
fill 368 244 537 368 245 537 minecraft:gold_block
fill 330 245 514 330 245 519 minecraft:cut_sandstone
fill 330 245 526 330 245 531 minecraft:cut_sandstone
fill 330 245 538 330 245 543 minecraft:cut_sandstone
fill 330 245 550 330 245 551 minecraft:cut_sandstone
fill 331 245 551 334 245 551 minecraft:cut_sandstone
fill 332 245 513 332 245 514 minecraft:cut_sandstone
setblock 332 245 516 minecraft:cut_sandstone
fill 333 245 513 335 245 513 minecraft:cut_sandstone
fill 333 245 517 335 245 517 minecraft:cut_sandstone
fill 334 245 511 339 245 511 minecraft:cut_sandstone
fill 336 245 514 336 245 516 minecraft:cut_sandstone
fill 341 245 551 346 245 551 minecraft:cut_sandstone
fill 346 245 511 351 245 511 minecraft:cut_sandstone
fill 353 245 551 358 245 551 minecraft:cut_sandstone
fill 358 245 511 363 245 511 minecraft:cut_sandstone
fill 365 245 551 370 245 551 minecraft:cut_sandstone
fill 370 245 511 370 245 516 minecraft:cut_sandstone
fill 370 245 523 370 245 528 minecraft:cut_sandstone
fill 370 245 535 370 245 540 minecraft:cut_sandstone
fill 370 245 547 370 245 550 minecraft:cut_sandstone
fill 329 246 516 329 251 519 minecraft:ochre_froglight
fill 329 246 528 329 251 531 minecraft:ochre_froglight
fill 329 246 540 329 251 543 minecraft:ochre_froglight
fill 329 246 552 332 251 552 minecraft:ochre_froglight
fill 336 246 510 339 251 510 minecraft:ochre_froglight
setblock 336 246 519 minecraft:ochre_froglight
setblock 337 246 518 minecraft:ochre_froglight
setblock 338 246 517 minecraft:ochre_froglight
setblock 339 246 516 minecraft:ochre_froglight
fill 340 246 515 341 246 515 minecraft:ochre_froglight
fill 341 246 552 344 251 552 minecraft:ochre_froglight
fill 342 246 514 343 246 514 minecraft:ochre_froglight
setblock 344 246 513 minecraft:ochre_froglight
fill 348 246 510 351 251 510 minecraft:ochre_froglight
fill 353 246 552 356 251 552 minecraft:ochre_froglight
fill 360 246 510 363 251 510 minecraft:ochre_froglight
fill 365 246 552 368 251 552 minecraft:ochre_froglight
fill 371 246 511 371 251 514 minecraft:ochre_froglight
fill 371 246 523 371 251 526 minecraft:ochre_froglight
fill 371 246 535 371 251 538 minecraft:ochre_froglight
fill 371 246 547 371 251 550 minecraft:ochre_froglight
fill 335 250 525 337 251 525 minecraft:yellow_concrete
fill 336 250 524 336 251 524 minecraft:yellow_concrete
fill 336 250 526 336 251 526 minecraft:yellow_concrete
setblock 332 251 513 minecraft:light[level=14]
setblock 332 251 521 minecraft:light[level=14]
setblock 332 251 529 minecraft:light[level=14]
setblock 332 251 537 minecraft:light[level=14]
setblock 332 251 545 minecraft:light[level=14]
setblock 340 251 513 minecraft:light[level=14]
setblock 340 251 521 minecraft:light[level=14]
setblock 340 251 529 minecraft:light[level=14]
setblock 340 251 537 minecraft:light[level=14]
setblock 340 251 545 minecraft:light[level=14]
setblock 348 251 513 minecraft:light[level=14]
setblock 348 251 521 minecraft:light[level=14]
setblock 348 251 529 minecraft:light[level=14]
setblock 348 251 537 minecraft:light[level=14]
setblock 348 251 545 minecraft:light[level=14]
setblock 356 251 513 minecraft:light[level=14]
setblock 356 251 521 minecraft:light[level=14]
setblock 356 251 529 minecraft:light[level=14]
setblock 356 251 537 minecraft:light[level=14]
setblock 356 251 545 minecraft:light[level=14]
setblock 364 251 513 minecraft:light[level=14]
setblock 364 251 521 minecraft:light[level=14]
setblock 364 251 529 minecraft:light[level=14]
setblock 364 251 537 minecraft:light[level=14]
setblock 364 251 545 minecraft:light[level=14]
fill 329 252 516 329 265 516 minecraft:sandstone
fill 329 252 517 329 252 518 minecraft:ochre_froglight
fill 329 252 519 329 265 519 minecraft:sandstone
fill 329 252 528 329 265 528 minecraft:sandstone
fill 329 252 529 329 252 530 minecraft:ochre_froglight
fill 329 252 531 329 265 531 minecraft:sandstone
fill 329 252 540 329 265 540 minecraft:sandstone
fill 329 252 541 329 252 542 minecraft:ochre_froglight
fill 329 252 543 329 265 543 minecraft:sandstone
fill 329 252 552 329 265 552 minecraft:sandstone
fill 330 252 552 331 252 552 minecraft:ochre_froglight
fill 332 252 552 332 265 552 minecraft:sandstone
fill 336 252 510 336 265 510 minecraft:sandstone
fill 337 252 510 338 252 510 minecraft:ochre_froglight
fill 339 252 510 339 265 510 minecraft:sandstone
fill 341 252 552 341 265 552 minecraft:sandstone
fill 342 252 552 343 252 552 minecraft:ochre_froglight
fill 344 252 552 344 265 552 minecraft:sandstone
fill 348 252 510 348 265 510 minecraft:sandstone
fill 349 252 510 350 252 510 minecraft:ochre_froglight
fill 351 252 510 351 265 510 minecraft:sandstone
fill 353 252 552 353 265 552 minecraft:sandstone
fill 354 252 552 355 252 552 minecraft:ochre_froglight
fill 356 252 552 356 265 552 minecraft:sandstone
fill 360 252 510 360 265 510 minecraft:sandstone
fill 361 252 510 362 252 510 minecraft:ochre_froglight
fill 363 252 510 363 265 510 minecraft:sandstone
fill 364 252 535 365 253 536 minecraft:yellow_concrete
fill 365 252 552 365 265 552 minecraft:sandstone
fill 366 252 552 367 252 552 minecraft:ochre_froglight
fill 368 252 552 368 265 552 minecraft:sandstone
fill 371 252 511 371 265 511 minecraft:sandstone
fill 371 252 512 371 252 513 minecraft:ochre_froglight
fill 371 252 514 371 265 514 minecraft:sandstone
fill 371 252 523 371 265 523 minecraft:sandstone
fill 371 252 524 371 252 525 minecraft:ochre_froglight
fill 371 252 526 371 265 526 minecraft:sandstone
fill 371 252 535 371 265 535 minecraft:sandstone
fill 371 252 536 371 252 537 minecraft:ochre_froglight
fill 371 252 538 371 265 538 minecraft:sandstone
fill 371 252 547 371 265 547 minecraft:sandstone
fill 371 252 548 371 252 549 minecraft:ochre_froglight
fill 371 252 550 371 265 550 minecraft:sandstone
fill 329 253 517 329 265 518 minecraft:sandstone
fill 329 253 529 329 265 530 minecraft:sandstone
fill 329 253 541 329 265 542 minecraft:sandstone
fill 330 253 536 336 253 536 minecraft:cut_sandstone
fill 330 253 552 331 265 552 minecraft:sandstone
fill 332 253 513 332 253 514 minecraft:cut_sandstone
setblock 332 253 516 minecraft:cut_sandstone
fill 332 253 534 336 254 535 minecraft:cut_sandstone
fill 332 253 537 336 254 538 minecraft:cut_sandstone
fill 333 253 513 335 253 513 minecraft:cut_sandstone
fill 333 253 517 335 253 517 minecraft:cut_sandstone
fill 336 253 514 336 253 516 minecraft:cut_sandstone
fill 337 253 510 338 265 510 minecraft:sandstone
fill 342 253 552 343 265 552 minecraft:sandstone
fill 349 253 510 350 265 510 minecraft:sandstone
fill 354 253 552 355 265 552 minecraft:sandstone
fill 361 253 510 362 265 510 minecraft:sandstone
fill 366 253 552 367 265 552 minecraft:sandstone
fill 371 253 512 371 265 513 minecraft:sandstone
fill 371 253 524 371 265 525 minecraft:sandstone
fill 371 253 536 371 265 537 minecraft:sandstone
fill 371 253 548 371 265 549 minecraft:sandstone
fill 332 254 536 336 254 536 minecraft:cut_sandstone
fill 333 255 535 335 256 537 minecraft:gold_block
fill 357 255 544 357 256 544 minecraft:yellow_concrete
fill 333 257 536 335 259 536 minecraft:gold_block
fill 334 257 535 334 259 535 minecraft:gold_block
fill 334 257 537 334 259 537 minecraft:gold_block
fill 339 257 529 339 258 529 minecraft:sandstone
setblock 332 259 513 minecraft:light[level=14]
setblock 332 259 521 minecraft:light[level=14]
setblock 332 259 529 minecraft:light[level=14]
setblock 332 259 537 minecraft:light[level=14]
setblock 332 259 545 minecraft:light[level=14]
setblock 340 259 513 minecraft:light[level=14]
setblock 340 259 521 minecraft:light[level=14]
setblock 340 259 529 minecraft:light[level=14]
setblock 340 259 537 minecraft:light[level=14]
setblock 340 259 545 minecraft:light[level=14]
setblock 348 259 513 minecraft:light[level=14]
setblock 348 259 521 minecraft:light[level=14]
setblock 348 259 529 minecraft:light[level=14]
setblock 348 259 537 minecraft:light[level=14]
setblock 348 259 545 minecraft:light[level=14]
setblock 356 259 513 minecraft:light[level=14]
setblock 356 259 521 minecraft:light[level=14]
setblock 356 259 529 minecraft:light[level=14]
setblock 356 259 537 minecraft:light[level=14]
setblock 356 259 545 minecraft:light[level=14]
setblock 364 259 513 minecraft:light[level=14]
setblock 364 259 521 minecraft:light[level=14]
setblock 364 259 529 minecraft:light[level=14]
setblock 364 259 537 minecraft:light[level=14]
setblock 364 259 545 minecraft:light[level=14]
fill 331 260 520 331 265 522 minecraft:gold_block
fill 331 260 532 331 265 534 minecraft:gold_block
fill 331 260 544 331 265 546 minecraft:gold_block
fill 334 260 536 334 264 536 minecraft:gold_block
fill 337 260 550 339 265 550 minecraft:gold_block
fill 341 260 512 343 265 512 minecraft:gold_block
fill 349 260 550 351 265 550 minecraft:gold_block
fill 353 260 512 355 265 512 minecraft:gold_block
fill 361 260 550 363 265 550 minecraft:gold_block
fill 365 260 512 367 265 512 minecraft:gold_block
fill 369 260 520 369 265 522 minecraft:gold_block
fill 369 260 532 369 265 534 minecraft:gold_block
fill 369 260 544 369 265 546 minecraft:gold_block
fill 332 261 513 332 261 514 minecraft:cut_sandstone
setblock 332 261 516 minecraft:cut_sandstone
fill 333 261 513 335 261 513 minecraft:cut_sandstone
fill 333 261 517 335 261 517 minecraft:cut_sandstone
fill 336 261 514 336 261 516 minecraft:cut_sandstone
fill 342 262 521 342 263 521 minecraft:sandstone
fill 351 263 513 353 264 513 minecraft:yellow_concrete
fill 352 263 512 352 264 512 minecraft:yellow_concrete
fill 330 265 514 330 265 519 minecraft:cut_sandstone
fill 330 265 526 330 265 531 minecraft:cut_sandstone
fill 330 265 538 330 265 543 minecraft:cut_sandstone
fill 330 265 550 330 265 551 minecraft:cut_sandstone
fill 331 265 551 334 265 551 minecraft:cut_sandstone
fill 334 265 511 339 265 511 minecraft:cut_sandstone
setblock 334 265 536 minecraft:ochre_froglight
fill 341 265 551 346 265 551 minecraft:cut_sandstone
fill 346 265 511 351 265 511 minecraft:cut_sandstone
fill 353 265 551 358 265 551 minecraft:cut_sandstone
fill 358 265 511 363 265 511 minecraft:cut_sandstone
fill 359 265 521 359 266 522 minecraft:sandstone
fill 365 265 551 370 265 551 minecraft:cut_sandstone
fill 370 265 511 370 265 516 minecraft:cut_sandstone
fill 370 265 523 370 265 528 minecraft:cut_sandstone
fill 370 265 535 370 265 540 minecraft:cut_sandstone
fill 370 265 547 370 265 550 minecraft:cut_sandstone
fill 329 266 516 329 271 519 minecraft:ochre_froglight
fill 329 266 528 329 271 531 minecraft:ochre_froglight
fill 329 266 540 329 271 543 minecraft:ochre_froglight
fill 329 266 552 332 271 552 minecraft:ochre_froglight
fill 336 266 510 339 271 510 minecraft:ochre_froglight
fill 341 266 552 344 271 552 minecraft:ochre_froglight
fill 348 266 510 351 271 510 minecraft:ochre_froglight
fill 353 266 552 356 271 552 minecraft:ochre_froglight
fill 360 266 510 363 271 510 minecraft:ochre_froglight
fill 365 266 552 368 271 552 minecraft:ochre_froglight
fill 371 266 511 371 271 514 minecraft:ochre_froglight
fill 371 266 523 371 271 526 minecraft:ochre_froglight
fill 371 266 535 371 271 538 minecraft:ochre_froglight
fill 371 266 547 371 271 550 minecraft:ochre_froglight
setblock 332 267 513 minecraft:light[level=14]
setblock 332 267 521 minecraft:light[level=14]
setblock 332 267 529 minecraft:light[level=14]
setblock 332 267 537 minecraft:light[level=14]
setblock 332 267 545 minecraft:light[level=14]
setblock 340 267 513 minecraft:light[level=14]
setblock 340 267 521 minecraft:light[level=14]
setblock 340 267 529 minecraft:light[level=14]
setblock 340 267 537 minecraft:light[level=14]
setblock 340 267 545 minecraft:light[level=14]
fill 345 267 515 346 268 516 minecraft:sandstone
setblock 348 267 513 minecraft:light[level=14]
setblock 348 267 521 minecraft:light[level=14]
setblock 348 267 529 minecraft:light[level=14]
setblock 348 267 537 minecraft:light[level=14]
setblock 348 267 545 minecraft:light[level=14]
setblock 356 267 513 minecraft:light[level=14]
setblock 356 267 521 minecraft:light[level=14]
setblock 356 267 529 minecraft:light[level=14]
setblock 356 267 537 minecraft:light[level=14]
setblock 356 267 545 minecraft:light[level=14]
setblock 364 267 513 minecraft:light[level=14]
setblock 364 267 521 minecraft:light[level=14]
setblock 364 267 529 minecraft:light[level=14]
setblock 364 267 537 minecraft:light[level=14]
setblock 364 267 545 minecraft:light[level=14]
fill 332 269 513 332 269 514 minecraft:cut_sandstone
setblock 332 269 516 minecraft:cut_sandstone
fill 333 269 513 335 269 513 minecraft:cut_sandstone
fill 333 269 517 335 269 517 minecraft:cut_sandstone
fill 336 269 514 336 269 516 minecraft:cut_sandstone
fill 352 269 515 353 270 516 minecraft:sandstone
fill 329 272 516 329 285 516 minecraft:sandstone
fill 329 272 517 329 272 518 minecraft:ochre_froglight
fill 329 272 519 329 285 519 minecraft:sandstone
fill 329 272 528 329 285 528 minecraft:sandstone
fill 329 272 529 329 272 530 minecraft:ochre_froglight
fill 329 272 531 329 285 531 minecraft:sandstone
fill 329 272 540 329 285 540 minecraft:sandstone
fill 329 272 541 329 272 542 minecraft:ochre_froglight
fill 329 272 543 329 285 543 minecraft:sandstone
fill 329 272 552 329 285 552 minecraft:sandstone
fill 330 272 552 331 272 552 minecraft:ochre_froglight
fill 332 272 514 332 273 514 minecraft:sandstone
fill 332 272 516 332 273 516 minecraft:sandstone
fill 332 272 552 332 285 552 minecraft:sandstone
fill 333 272 513 335 273 513 minecraft:sandstone
fill 333 272 517 334 273 517 minecraft:sandstone
fill 336 272 510 336 285 510 minecraft:sandstone
fill 336 272 514 336 273 515 minecraft:sandstone
fill 337 272 510 338 272 510 minecraft:ochre_froglight
fill 339 272 510 339 285 510 minecraft:sandstone
fill 341 272 552 341 285 552 minecraft:sandstone
fill 342 272 552 343 272 552 minecraft:ochre_froglight
fill 344 272 514 345 273 515 minecraft:yellow_concrete
fill 344 272 552 344 285 552 minecraft:sandstone
fill 348 272 510 348 285 510 minecraft:sandstone
fill 349 272 510 350 272 510 minecraft:ochre_froglight
fill 351 272 510 351 285 510 minecraft:sandstone
fill 353 272 552 353 285 552 minecraft:sandstone
fill 354 272 552 355 272 552 minecraft:ochre_froglight
fill 356 272 552 356 285 552 minecraft:sandstone
fill 360 272 510 360 285 510 minecraft:sandstone
fill 361 272 510 362 272 510 minecraft:ochre_froglight
fill 363 272 510 363 285 510 minecraft:sandstone
fill 365 272 552 365 285 552 minecraft:sandstone
fill 366 272 552 367 272 552 minecraft:ochre_froglight
fill 368 272 552 368 285 552 minecraft:sandstone
fill 371 272 511 371 285 511 minecraft:sandstone
fill 371 272 512 371 272 513 minecraft:ochre_froglight
fill 371 272 514 371 285 514 minecraft:sandstone
fill 371 272 523 371 285 523 minecraft:sandstone
fill 371 272 524 371 272 525 minecraft:ochre_froglight
fill 371 272 526 371 285 526 minecraft:sandstone
fill 371 272 535 371 285 535 minecraft:sandstone
fill 371 272 536 371 272 537 minecraft:ochre_froglight
fill 371 272 538 371 285 538 minecraft:sandstone
fill 371 272 547 371 285 547 minecraft:sandstone
fill 371 272 548 371 272 549 minecraft:ochre_froglight
fill 371 272 550 371 285 550 minecraft:sandstone
fill 329 273 517 329 285 518 minecraft:sandstone
fill 329 273 529 329 285 530 minecraft:sandstone
fill 329 273 541 329 285 542 minecraft:sandstone
fill 330 273 552 331 285 552 minecraft:sandstone
fill 337 273 510 338 285 510 minecraft:sandstone
fill 342 273 552 343 285 552 minecraft:sandstone
fill 349 273 510 350 285 510 minecraft:sandstone
fill 354 273 552 355 285 552 minecraft:sandstone
fill 361 273 510 362 285 510 minecraft:sandstone
fill 366 273 552 367 285 552 minecraft:sandstone
fill 371 273 512 371 285 513 minecraft:sandstone
fill 371 273 524 371 285 525 minecraft:sandstone
fill 371 273 536 371 285 537 minecraft:sandstone
fill 371 273 548 371 285 549 minecraft:sandstone
setblock 332 275 513 minecraft:light[level=14]
setblock 332 275 521 minecraft:light[level=14]
setblock 332 275 529 minecraft:light[level=14]
setblock 332 275 537 minecraft:light[level=14]
setblock 332 275 545 minecraft:light[level=14]
setblock 340 275 513 minecraft:light[level=14]
setblock 340 275 521 minecraft:light[level=14]
setblock 340 275 529 minecraft:light[level=14]
setblock 340 275 537 minecraft:light[level=14]
setblock 340 275 545 minecraft:light[level=14]
setblock 348 275 513 minecraft:light[level=14]
setblock 348 275 521 minecraft:light[level=14]
setblock 348 275 529 minecraft:light[level=14]
setblock 348 275 537 minecraft:light[level=14]
setblock 348 275 545 minecraft:light[level=14]
setblock 356 275 513 minecraft:light[level=14]
setblock 356 275 521 minecraft:light[level=14]
setblock 356 275 529 minecraft:light[level=14]
setblock 356 275 537 minecraft:light[level=14]
setblock 356 275 545 minecraft:light[level=14]
setblock 364 275 513 minecraft:light[level=14]
setblock 364 275 521 minecraft:light[level=14]
setblock 364 275 529 minecraft:light[level=14]
setblock 364 275 537 minecraft:light[level=14]
setblock 364 275 545 minecraft:light[level=14]
fill 336 279 532 347 279 536 minecraft:gold_block
fill 337 279 529 363 279 531 minecraft:gold_block
fill 337 279 537 363 279 539 minecraft:gold_block
fill 338 279 527 362 279 528 minecraft:gold_block
fill 338 279 540 362 279 541 minecraft:gold_block
fill 339 279 526 361 279 526 minecraft:gold_block
fill 339 279 542 361 279 542 minecraft:gold_block
fill 340 279 524 360 279 525 minecraft:gold_block
fill 340 279 543 360 279 544 minecraft:gold_block
fill 342 279 523 358 279 523 minecraft:gold_block
fill 342 279 545 358 279 545 minecraft:gold_block
fill 343 279 522 357 280 522 minecraft:gold_block
fill 343 279 546 357 280 546 minecraft:gold_block
fill 345 279 521 355 280 521 minecraft:gold_block
fill 345 279 547 355 280 547 minecraft:gold_block
fill 348 279 520 352 280 520 minecraft:gold_block
fill 348 279 532 348 279 533 minecraft:gold_block
fill 348 279 535 348 279 536 minecraft:gold_block
fill 348 279 548 352 280 548 minecraft:gold_block
setblock 349 279 532 minecraft:gold_block
setblock 349 279 536 minecraft:gold_block
fill 351 279 532 364 279 532 minecraft:gold_block
fill 351 279 536 364 279 536 minecraft:gold_block
fill 352 279 533 364 279 533 minecraft:gold_block
fill 352 279 535 364 279 535 minecraft:gold_block
fill 353 279 534 364 279 534 minecraft:gold_block
fill 330 280 511 335 280 551 minecraft:smooth_sandstone
fill 336 280 511 336 280 531 minecraft:smooth_sandstone
fill 336 280 532 338 280 536 minecraft:gold_block
fill 336 280 537 336 280 551 minecraft:smooth_sandstone
fill 337 280 511 337 280 528 minecraft:smooth_sandstone
fill 337 280 529 339 280 531 minecraft:gold_block
fill 337 280 537 339 280 539 minecraft:gold_block
fill 337 280 540 337 280 551 minecraft:smooth_sandstone
fill 338 280 511 338 280 526 minecraft:smooth_sandstone
fill 338 280 527 340 280 528 minecraft:gold_block
fill 338 280 540 340 280 541 minecraft:gold_block
fill 338 280 542 338 280 551 minecraft:smooth_sandstone
fill 339 280 511 339 280 525 minecraft:smooth_sandstone
fill 339 280 526 342 280 526 minecraft:gold_block
fill 339 280 532 339 280 533 minecraft:gold_block
fill 339 280 534 346 280 534 minecraft:sandstone
fill 339 280 535 339 280 536 minecraft:gold_block
fill 339 280 542 342 280 542 minecraft:gold_block
fill 339 280 543 339 280 551 minecraft:smooth_sandstone
fill 340 280 511 341 280 523 minecraft:smooth_sandstone
fill 340 280 524 343 280 525 minecraft:gold_block
setblock 340 280 529 minecraft:gold_block
fill 340 280 530 346 280 533 minecraft:sandstone
fill 340 280 535 346 280 538 minecraft:sandstone
setblock 340 280 539 minecraft:gold_block
fill 340 280 543 343 280 544 minecraft:gold_block
fill 340 280 545 341 280 551 minecraft:smooth_sandstone
setblock 341 280 527 minecraft:gold_block
fill 341 280 528 359 280 529 minecraft:sandstone
fill 341 280 539 359 280 540 minecraft:sandstone
setblock 341 280 541 minecraft:gold_block
fill 342 280 511 342 280 522 minecraft:smooth_sandstone
fill 342 280 523 349 280 523 minecraft:gold_block
fill 342 280 527 358 280 527 minecraft:sandstone
fill 342 280 541 358 280 541 minecraft:sandstone
fill 342 280 545 349 280 545 minecraft:gold_block
fill 342 280 546 342 280 551 minecraft:smooth_sandstone
fill 343 280 511 344 280 521 minecraft:smooth_sandstone
fill 343 280 526 357 280 526 minecraft:sandstone
fill 343 280 542 357 280 542 minecraft:sandstone
fill 343 280 547 344 280 551 minecraft:smooth_sandstone
fill 344 280 524 345 280 524 minecraft:gold_block
fill 344 280 525 356 280 525 minecraft:sandstone
fill 344 280 543 356 280 543 minecraft:sandstone
fill 344 280 544 345 280 544 minecraft:gold_block
fill 345 280 511 347 280 520 minecraft:smooth_sandstone
fill 345 280 548 347 280 551 minecraft:smooth_sandstone
fill 346 280 524 354 280 524 minecraft:sandstone
fill 346 280 544 354 280 544 minecraft:sandstone
fill 347 280 530 347 280 532 minecraft:sandstone
fill 347 280 533 347 280 535 minecraft:ochre_froglight
fill 347 280 536 347 280 538 minecraft:sandstone
fill 348 280 511 370 280 519 minecraft:smooth_sandstone
fill 348 280 530 348 280 531 minecraft:sandstone
fill 348 280 532 348 280 533 minecraft:ochre_froglight
fill 348 280 535 348 280 536 minecraft:ochre_froglight
fill 348 280 537 348 280 538 minecraft:sandstone
fill 348 280 549 370 280 551 minecraft:smooth_sandstone
fill 349 280 530 360 280 530 minecraft:sandstone
fill 349 280 531 349 280 532 minecraft:ochre_froglight
fill 349 280 536 349 280 537 minecraft:ochre_froglight
fill 349 280 538 360 280 538 minecraft:sandstone
setblock 350 280 523 minecraft:sandstone
fill 350 280 531 351 280 531 minecraft:ochre_froglight
fill 350 280 537 351 280 537 minecraft:ochre_froglight
setblock 350 280 545 minecraft:sandstone
fill 351 280 523 358 280 523 minecraft:gold_block
fill 351 280 532 352 280 532 minecraft:ochre_froglight
fill 351 280 536 352 280 536 minecraft:ochre_froglight
fill 351 280 545 358 280 545 minecraft:gold_block
fill 352 280 531 360 280 531 minecraft:sandstone
fill 352 280 533 353 280 533 minecraft:ochre_froglight
fill 352 280 535 353 280 535 minecraft:ochre_froglight
fill 352 280 537 360 280 537 minecraft:sandstone
fill 353 280 520 370 280 520 minecraft:smooth_sandstone
fill 353 280 532 360 280 532 minecraft:sandstone
setblock 353 280 534 minecraft:ochre_froglight
fill 353 280 536 360 280 536 minecraft:sandstone
fill 353 280 548 370 280 548 minecraft:smooth_sandstone
fill 354 280 533 360 280 535 minecraft:sandstone
fill 355 280 524 360 280 524 minecraft:gold_block
fill 355 280 544 360 280 544 minecraft:gold_block
fill 356 280 521 370 280 521 minecraft:smooth_sandstone
fill 356 280 547 370 280 547 minecraft:smooth_sandstone
fill 357 280 525 360 280 525 minecraft:gold_block
fill 357 280 543 360 280 543 minecraft:gold_block
fill 358 280 522 370 280 522 minecraft:smooth_sandstone
fill 358 280 526 361 280 526 minecraft:gold_block
fill 358 280 542 361 280 542 minecraft:gold_block
fill 358 280 546 370 280 546 minecraft:smooth_sandstone
fill 359 280 523 370 280 523 minecraft:smooth_sandstone
fill 359 280 527 362 280 527 minecraft:gold_block
fill 359 280 541 362 280 541 minecraft:gold_block
fill 359 280 545 370 280 545 minecraft:smooth_sandstone
fill 360 280 528 362 280 529 minecraft:gold_block
fill 360 280 539 362 280 540 minecraft:gold_block
fill 361 280 524 370 280 525 minecraft:smooth_sandstone
fill 361 280 530 363 280 533 minecraft:gold_block
setblock 361 280 534 minecraft:sandstone
fill 361 280 535 363 280 538 minecraft:gold_block
fill 361 280 543 370 280 544 minecraft:smooth_sandstone
fill 362 280 526 370 280 526 minecraft:smooth_sandstone
fill 362 280 534 364 280 534 minecraft:gold_block
fill 362 280 542 370 280 542 minecraft:smooth_sandstone
fill 363 280 527 370 280 528 minecraft:smooth_sandstone
setblock 363 280 529 minecraft:gold_block
setblock 363 280 539 minecraft:gold_block
fill 363 280 540 370 280 541 minecraft:smooth_sandstone
fill 364 280 529 370 280 531 minecraft:smooth_sandstone
fill 364 280 532 364 280 533 minecraft:gold_block
fill 364 280 535 364 280 536 minecraft:gold_block
fill 364 280 537 370 280 539 minecraft:smooth_sandstone
fill 365 280 532 370 280 536 minecraft:smooth_sandstone
fill 346 281 534 347 281 534 minecraft:glass
fill 347 281 532 347 281 533 minecraft:glass
fill 347 281 535 347 281 536 minecraft:glass
fill 348 281 531 348 281 532 minecraft:glass
fill 348 281 536 348 281 537 minecraft:glass
fill 349 281 531 352 281 531 minecraft:glass
fill 349 281 537 352 281 537 minecraft:glass
setblock 350 281 530 minecraft:glass
setblock 350 281 538 minecraft:glass
fill 352 281 532 353 281 532 minecraft:glass
fill 352 281 536 353 281 536 minecraft:glass
fill 353 281 533 353 281 535 minecraft:glass
setblock 354 281 534 minecraft:glass
fill 345 282 532 345 282 536 minecraft:glass
fill 346 282 531 346 282 532 minecraft:glass
fill 346 282 536 346 282 537 minecraft:glass
fill 347 282 530 347 282 531 minecraft:glass
fill 347 282 537 347 282 538 minecraft:glass
fill 348 282 529 348 282 530 minecraft:glass
fill 348 282 538 348 282 539 minecraft:glass
fill 349 282 529 352 282 529 minecraft:glass
fill 349 282 539 352 282 539 minecraft:glass
fill 352 282 530 353 282 530 minecraft:glass
fill 352 282 538 353 282 538 minecraft:glass
fill 353 282 531 354 282 531 minecraft:glass
fill 353 282 537 354 282 537 minecraft:glass
fill 354 282 532 355 282 532 minecraft:glass
fill 354 282 536 355 282 536 minecraft:glass
fill 355 282 533 355 282 535 minecraft:glass
setblock 332 283 513 minecraft:light[level=14]
setblock 332 283 521 minecraft:light[level=14]
setblock 332 283 529 minecraft:light[level=14]
setblock 332 283 537 minecraft:light[level=14]
setblock 332 283 545 minecraft:light[level=14]
setblock 340 283 513 minecraft:light[level=14]
setblock 340 283 521 minecraft:light[level=14]
setblock 340 283 529 minecraft:light[level=14]
setblock 340 283 537 minecraft:light[level=14]
setblock 340 283 545 minecraft:light[level=14]
fill 344 283 531 344 283 537 minecraft:glass
fill 345 283 530 345 283 531 minecraft:glass
fill 345 283 537 345 283 538 minecraft:glass
fill 346 283 529 346 283 530 minecraft:glass
fill 346 283 538 346 283 539 minecraft:glass
fill 347 283 528 347 283 529 minecraft:glass
fill 347 283 539 347 283 540 minecraft:glass
setblock 348 283 513 minecraft:light[level=14]
setblock 348 283 521 minecraft:light[level=14]
fill 348 283 528 353 283 528 minecraft:glass
setblock 348 283 529 minecraft:light[level=14]
setblock 348 283 537 minecraft:light[level=14]
fill 348 283 540 353 283 540 minecraft:glass
setblock 348 283 545 minecraft:light[level=14]
fill 353 283 529 354 283 529 minecraft:glass
fill 353 283 539 354 283 539 minecraft:glass
fill 354 283 530 355 283 530 minecraft:glass
fill 354 283 538 355 283 538 minecraft:glass
fill 355 283 531 356 283 531 minecraft:glass
fill 355 283 537 356 283 537 minecraft:glass
setblock 356 283 513 minecraft:light[level=14]
setblock 356 283 521 minecraft:light[level=14]
setblock 356 283 529 minecraft:light[level=14]
fill 356 283 532 356 283 536 minecraft:glass
setblock 356 283 545 minecraft:light[level=14]
setblock 364 283 513 minecraft:light[level=14]
setblock 364 283 521 minecraft:light[level=14]
setblock 364 283 529 minecraft:light[level=14]
setblock 364 283 537 minecraft:light[level=14]
setblock 364 283 545 minecraft:light[level=14]
fill 330 284 511 332 300 511 minecraft:gold_block
fill 330 284 521 330 300 523 minecraft:gold_block
fill 330 284 533 330 300 535 minecraft:gold_block
fill 330 284 545 330 300 547 minecraft:gold_block
fill 331 284 520 331 285 522 minecraft:gold_block
fill 331 284 532 331 285 534 minecraft:gold_block
fill 331 284 544 331 285 546 minecraft:gold_block
fill 336 284 551 338 300 551 minecraft:gold_block
fill 337 284 550 339 285 550 minecraft:gold_block
fill 339 284 540 339 285 540 minecraft:yellow_concrete
fill 341 284 512 343 285 512 minecraft:gold_block
fill 342 284 511 344 300 511 minecraft:gold_block
fill 342 284 532 342 284 536 minecraft:glass
fill 343 284 530 343 284 532 minecraft:glass
fill 343 284 536 343 284 538 minecraft:glass
fill 344 284 529 344 284 530 minecraft:glass
fill 344 284 538 344 284 539 minecraft:glass
fill 345 284 528 346 284 528 minecraft:glass
fill 345 284 540 346 284 540 minecraft:glass
fill 346 284 527 348 284 527 minecraft:glass
fill 346 284 541 348 284 541 minecraft:glass
fill 348 284 526 352 284 526 minecraft:glass
fill 348 284 542 352 284 542 minecraft:glass
fill 348 284 551 350 300 551 minecraft:gold_block
fill 349 284 550 351 285 550 minecraft:gold_block
fill 352 284 527 354 284 527 minecraft:glass
fill 352 284 541 354 284 541 minecraft:glass
fill 353 284 512 355 285 512 minecraft:gold_block
fill 354 284 511 356 300 511 minecraft:gold_block
fill 354 284 528 355 284 528 minecraft:glass
fill 354 284 540 355 284 540 minecraft:glass
fill 356 284 529 356 284 530 minecraft:glass
fill 356 284 538 356 284 539 minecraft:glass
fill 357 284 530 357 284 532 minecraft:glass
fill 357 284 536 357 284 538 minecraft:glass
fill 358 284 532 358 284 536 minecraft:glass
fill 360 284 551 362 300 551 minecraft:gold_block
fill 361 284 550 363 285 550 minecraft:gold_block
fill 363 284 513 363 284 515 minecraft:cut_sandstone
setblock 364 284 512 minecraft:cut_sandstone
fill 364 284 513 366 300 515 minecraft:gold_block
fill 364 284 516 366 284 516 minecraft:cut_sandstone
fill 365 284 512 367 285 512 minecraft:gold_block
fill 366 284 511 368 300 511 minecraft:gold_block
fill 367 284 513 367 284 515 minecraft:cut_sandstone
fill 369 284 520 369 285 522 minecraft:gold_block
fill 369 284 532 369 285 534 minecraft:gold_block
fill 369 284 544 369 285 546 minecraft:gold_block
fill 370 284 519 370 300 521 minecraft:gold_block
fill 370 284 531 370 300 533 minecraft:gold_block
fill 370 284 543 370 300 545 minecraft:gold_block
fill 330 285 514 330 285 519 minecraft:cut_sandstone
fill 330 285 526 330 285 531 minecraft:cut_sandstone
fill 330 285 538 330 285 543 minecraft:cut_sandstone
fill 330 285 550 330 285 551 minecraft:cut_sandstone
fill 331 285 551 334 285 551 minecraft:cut_sandstone
fill 334 285 511 339 285 511 minecraft:cut_sandstone
fill 341 285 531 341 285 537 minecraft:glass
fill 341 285 551 346 285 551 minecraft:cut_sandstone
fill 342 285 529 342 285 531 minecraft:glass
fill 342 285 537 342 285 539 minecraft:glass
fill 343 285 528 343 285 529 minecraft:glass
fill 343 285 539 343 285 540 minecraft:glass
fill 344 285 527 345 285 527 minecraft:glass
fill 344 285 541 345 285 541 minecraft:glass
fill 345 285 526 347 285 526 minecraft:glass
fill 345 285 542 347 285 542 minecraft:glass
fill 346 285 511 351 285 511 minecraft:cut_sandstone
fill 347 285 525 353 285 525 minecraft:glass
fill 347 285 543 353 285 543 minecraft:glass
fill 353 285 526 355 285 526 minecraft:glass
fill 353 285 542 355 285 542 minecraft:glass
fill 353 285 551 358 285 551 minecraft:cut_sandstone
fill 355 285 527 356 285 527 minecraft:glass
fill 355 285 541 356 285 541 minecraft:glass
fill 357 285 528 357 285 529 minecraft:glass
fill 357 285 539 357 285 540 minecraft:glass
fill 358 285 511 363 285 511 minecraft:cut_sandstone
fill 358 285 529 358 285 531 minecraft:glass
fill 358 285 537 358 285 539 minecraft:glass
fill 359 285 531 359 285 537 minecraft:glass
fill 365 285 551 370 285 551 minecraft:cut_sandstone
fill 370 285 511 370 285 516 minecraft:cut_sandstone
fill 370 285 523 370 285 528 minecraft:cut_sandstone
fill 370 285 535 370 285 540 minecraft:cut_sandstone
fill 370 285 547 370 285 550 minecraft:cut_sandstone
fill 329 286 516 329 291 519 minecraft:ochre_froglight
fill 329 286 528 329 291 531 minecraft:ochre_froglight
fill 329 286 540 329 291 543 minecraft:ochre_froglight
fill 329 286 552 332 291 552 minecraft:ochre_froglight
fill 336 286 510 339 291 510 minecraft:ochre_froglight
fill 339 286 532 340 286 536 minecraft:glass
fill 340 286 529 340 286 531 minecraft:glass
fill 340 286 537 340 286 539 minecraft:glass
fill 341 286 528 341 286 529 minecraft:glass
fill 341 286 539 341 286 540 minecraft:glass
fill 341 286 552 344 291 552 minecraft:ochre_froglight
fill 342 286 527 342 286 528 minecraft:glass
fill 342 286 540 342 286 541 minecraft:glass
fill 343 286 526 344 286 526 minecraft:glass
fill 343 286 542 344 286 542 minecraft:glass
fill 344 286 525 345 286 525 minecraft:glass
fill 344 286 543 345 286 543 minecraft:glass
fill 345 286 524 355 286 524 minecraft:glass
fill 345 286 544 355 286 544 minecraft:glass
fill 348 286 510 351 291 510 minecraft:ochre_froglight
fill 348 286 523 352 286 523 minecraft:glass
fill 348 286 545 352 286 545 minecraft:glass
fill 353 286 552 356 291 552 minecraft:ochre_froglight
fill 355 286 525 356 286 525 minecraft:glass
fill 355 286 543 356 286 543 minecraft:glass
fill 356 286 526 357 286 526 minecraft:glass
fill 356 286 542 357 286 542 minecraft:glass
fill 358 286 527 358 286 528 minecraft:glass
fill 358 286 540 358 286 541 minecraft:glass
fill 359 286 528 359 286 529 minecraft:glass
fill 359 286 539 359 286 540 minecraft:glass
fill 360 286 510 363 291 510 minecraft:ochre_froglight
fill 360 286 529 360 286 539 minecraft:glass
fill 361 286 532 361 286 536 minecraft:glass
fill 365 286 552 368 291 552 minecraft:ochre_froglight
fill 371 286 511 371 291 514 minecraft:ochre_froglight
fill 371 286 523 371 291 526 minecraft:ochre_froglight
fill 371 286 535 371 291 538 minecraft:ochre_froglight
fill 371 286 547 371 291 550 minecraft:ochre_froglight
fill 338 287 530 338 287 538 minecraft:glass
fill 339 287 528 339 287 530 minecraft:glass
fill 339 287 538 339 287 540 minecraft:glass
fill 340 287 527 340 287 528 minecraft:glass
fill 340 287 540 340 287 541 minecraft:glass
setblock 341 287 526 minecraft:glass
setblock 341 287 542 minecraft:glass
setblock 342 287 525 minecraft:glass
setblock 342 287 543 minecraft:glass
fill 343 287 524 344 287 524 minecraft:glass
fill 343 287 544 344 287 544 minecraft:glass
fill 344 287 523 346 287 523 minecraft:glass
fill 344 287 545 346 287 545 minecraft:glass
fill 346 287 522 354 287 522 minecraft:glass
fill 346 287 546 354 287 546 minecraft:glass
fill 354 287 523 356 287 523 minecraft:glass
fill 354 287 545 356 287 545 minecraft:glass
fill 356 287 524 357 287 524 minecraft:glass
fill 356 287 544 357 287 544 minecraft:glass
setblock 358 287 525 minecraft:glass
setblock 358 287 543 minecraft:glass
setblock 359 287 526 minecraft:glass
setblock 359 287 542 minecraft:glass
fill 360 287 527 360 287 528 minecraft:glass
fill 360 287 540 360 287 541 minecraft:glass
fill 361 287 528 361 287 530 minecraft:glass
fill 361 287 538 361 287 540 minecraft:glass
fill 362 287 530 362 287 538 minecraft:glass
fill 332 288 525 332 289 537 minecraft:gold_block
fill 333 288 523 333 289 530 minecraft:gold_block
fill 333 288 532 333 289 539 minecraft:gold_block
fill 334 288 521 334 289 525 minecraft:gold_block
fill 334 288 537 334 289 541 minecraft:gold_block
fill 335 288 520 335 289 522 minecraft:gold_block
fill 335 288 540 335 289 542 minecraft:gold_block
fill 336 288 519 336 289 521 minecraft:gold_block
fill 336 288 532 337 288 536 minecraft:glass
fill 336 288 541 336 289 543 minecraft:gold_block
fill 337 288 518 337 289 520 minecraft:gold_block
fill 337 288 529 337 288 531 minecraft:glass
fill 337 288 537 337 288 539 minecraft:glass
fill 337 288 542 337 289 544 minecraft:gold_block
fill 338 288 517 339 289 518 minecraft:gold_block
fill 338 288 527 338 288 529 minecraft:glass
fill 338 288 539 338 288 541 minecraft:glass
fill 338 288 544 339 289 545 minecraft:gold_block
fill 339 288 516 341 289 516 minecraft:gold_block
fill 339 288 526 339 288 527 minecraft:glass
fill 339 288 541 339 288 542 minecraft:glass
fill 339 288 546 341 289 546 minecraft:gold_block
fill 340 288 515 344 289 515 minecraft:gold_block
fill 340 288 517 340 289 517 minecraft:gold_block
fill 340 288 524 340 288 525 minecraft:glass
fill 340 288 543 340 288 544 minecraft:glass
fill 340 288 545 340 289 545 minecraft:gold_block
fill 340 288 547 344 289 547 minecraft:gold_block
setblock 341 288 524 minecraft:glass
setblock 341 288 544 minecraft:glass
fill 342 288 514 349 289 514 minecraft:gold_block
fill 342 288 523 343 288 523 minecraft:glass
fill 342 288 545 343 288 545 minecraft:glass
fill 342 288 548 347 289 548 minecraft:gold_block
fill 343 288 522 345 288 522 minecraft:glass
fill 343 288 546 345 288 546 minecraft:glass
fill 344 288 513 356 289 513 minecraft:gold_block
fill 344 288 549 356 289 549 minecraft:gold_block
fill 345 288 521 355 288 521 minecraft:glass
fill 345 288 547 355 288 547 minecraft:glass
fill 348 288 520 352 288 520 minecraft:glass
fill 348 288 548 352 288 548 minecraft:glass
fill 351 288 514 358 289 514 minecraft:gold_block
fill 353 288 548 358 289 548 minecraft:gold_block
fill 355 288 522 357 288 522 minecraft:glass
fill 355 288 546 357 288 546 minecraft:glass
fill 356 288 515 360 289 515 minecraft:gold_block
fill 356 288 547 360 289 547 minecraft:gold_block
fill 357 288 523 358 288 523 minecraft:glass
fill 357 288 545 358 288 545 minecraft:glass
fill 359 288 516 361 289 516 minecraft:gold_block
fill 359 288 524 360 288 524 minecraft:glass
fill 359 288 544 360 288 544 minecraft:glass
fill 359 288 546 361 289 546 minecraft:gold_block
fill 360 288 517 362 289 517 minecraft:gold_block
setblock 360 288 525 minecraft:glass
setblock 360 288 543 minecraft:glass
fill 360 288 545 362 289 545 minecraft:gold_block
fill 361 288 518 363 289 518 minecraft:gold_block
fill 361 288 526 361 288 527 minecraft:glass
fill 361 288 541 361 288 542 minecraft:glass
fill 361 288 544 363 289 544 minecraft:gold_block
fill 362 288 527 362 288 529 minecraft:glass
fill 362 288 539 362 288 541 minecraft:glass
fill 363 288 519 364 289 520 minecraft:gold_block
fill 363 288 529 363 288 539 minecraft:glass
fill 363 288 542 364 289 543 minecraft:gold_block
fill 364 288 521 366 289 521 minecraft:gold_block
fill 364 288 532 364 288 536 minecraft:glass
fill 364 288 541 366 289 541 minecraft:gold_block
fill 365 288 520 365 289 520 minecraft:gold_block
fill 365 288 522 366 289 522 minecraft:gold_block
fill 365 288 540 366 289 540 minecraft:gold_block
fill 365 288 542 365 289 542 minecraft:gold_block
fill 366 288 523 367 289 525 minecraft:gold_block
fill 366 288 537 367 289 539 minecraft:gold_block
fill 367 288 526 368 289 530 minecraft:gold_block
fill 367 288 532 368 289 536 minecraft:gold_block
fill 368 288 525 368 289 525 minecraft:gold_block
fill 368 288 531 368 289 531 minecraft:gold_block
fill 368 288 537 368 289 537 minecraft:gold_block
fill 336 289 532 337 290 536 minecraft:gold_block
fill 337 289 529 337 290 531 minecraft:gold_block
fill 337 289 537 337 290 539 minecraft:gold_block
fill 338 289 527 338 290 530 minecraft:gold_block
fill 338 289 538 338 290 541 minecraft:gold_block
fill 339 289 526 339 290 528 minecraft:gold_block
fill 339 289 540 339 290 542 minecraft:gold_block
fill 340 289 524 340 290 526 minecraft:gold_block
fill 340 289 542 340 290 544 minecraft:gold_block
fill 341 289 524 341 290 525 minecraft:gold_block
fill 341 289 543 341 290 544 minecraft:gold_block
fill 342 289 523 342 290 524 minecraft:gold_block
fill 342 289 544 342 290 545 minecraft:gold_block
fill 343 289 522 344 290 523 minecraft:gold_block
fill 343 289 545 344 290 546 minecraft:gold_block
fill 345 289 521 346 290 522 minecraft:gold_block
fill 345 289 546 346 290 547 minecraft:gold_block
fill 347 289 521 355 290 521 minecraft:gold_block
fill 347 289 547 355 290 547 minecraft:gold_block
fill 348 289 520 352 290 520 minecraft:gold_block
fill 348 289 541 349 290 541 minecraft:yellow_concrete
fill 348 289 548 352 290 548 minecraft:gold_block
fill 354 289 522 357 290 522 minecraft:gold_block
fill 354 289 546 357 290 546 minecraft:gold_block
fill 356 289 523 358 290 523 minecraft:gold_block
fill 356 289 545 358 290 545 minecraft:gold_block
fill 358 289 524 360 290 524 minecraft:gold_block
fill 358 289 544 360 290 544 minecraft:gold_block
fill 359 289 525 360 290 525 minecraft:gold_block
fill 359 289 543 360 290 543 minecraft:gold_block
fill 360 289 526 361 290 526 minecraft:gold_block
fill 360 289 542 361 290 542 minecraft:gold_block
fill 361 289 527 362 290 528 minecraft:gold_block
fill 361 289 540 362 290 541 minecraft:gold_block
fill 362 289 529 363 290 530 minecraft:gold_block
fill 362 289 538 363 290 539 minecraft:gold_block
fill 363 289 531 363 290 537 minecraft:gold_block
fill 364 289 532 364 290 536 minecraft:gold_block
fill 344 290 549 348 290 549 minecraft:ochre_froglight
fill 349 290 550 351 290 550 minecraft:ochre_froglight
fill 352 290 549 356 290 549 minecraft:ochre_froglight
fill 357 290 548 358 290 548 minecraft:ochre_froglight
fill 359 290 547 360 290 547 minecraft:ochre_froglight
setblock 361 290 546 minecraft:ochre_froglight
setblock 362 290 545 minecraft:ochre_froglight
setblock 332 291 513 minecraft:light[level=14]
setblock 332 291 521 minecraft:light[level=14]
setblock 332 291 529 minecraft:light[level=14]
setblock 332 291 537 minecraft:light[level=14]
setblock 332 291 545 minecraft:light[level=14]
setblock 340 291 513 minecraft:light[level=14]
setblock 340 291 521 minecraft:light[level=14]
setblock 340 291 529 minecraft:light[level=14]
setblock 340 291 537 minecraft:light[level=14]
setblock 340 291 545 minecraft:light[level=14]
setblock 348 291 513 minecraft:light[level=14]
setblock 348 291 521 minecraft:light[level=14]
setblock 348 291 529 minecraft:light[level=14]
setblock 348 291 537 minecraft:light[level=14]
setblock 348 291 545 minecraft:light[level=14]
setblock 356 291 513 minecraft:light[level=14]
setblock 356 291 521 minecraft:light[level=14]
setblock 356 291 529 minecraft:light[level=14]
setblock 356 291 537 minecraft:light[level=14]
setblock 356 291 545 minecraft:light[level=14]
setblock 364 291 521 minecraft:light[level=14]
setblock 364 291 529 minecraft:light[level=14]
setblock 364 291 537 minecraft:light[level=14]
setblock 364 291 545 minecraft:light[level=14]
fill 329 292 516 329 307 516 minecraft:sandstone
fill 329 292 517 329 292 518 minecraft:ochre_froglight
fill 329 292 519 329 307 519 minecraft:sandstone
fill 329 292 528 329 307 528 minecraft:sandstone
fill 329 292 529 329 292 530 minecraft:ochre_froglight
fill 329 292 531 329 307 531 minecraft:sandstone
fill 329 292 540 329 307 540 minecraft:sandstone
fill 329 292 541 329 292 542 minecraft:ochre_froglight
fill 329 292 543 329 307 543 minecraft:sandstone
fill 329 292 552 329 307 552 minecraft:sandstone
fill 330 292 552 331 292 552 minecraft:ochre_froglight
fill 332 292 552 332 307 552 minecraft:sandstone
fill 336 292 510 336 307 510 minecraft:sandstone
fill 337 292 510 338 292 510 minecraft:ochre_froglight
fill 339 292 510 339 307 510 minecraft:sandstone
fill 341 292 552 341 307 552 minecraft:sandstone
fill 342 292 552 343 292 552 minecraft:ochre_froglight
fill 344 292 552 344 307 552 minecraft:sandstone
fill 348 292 510 348 307 510 minecraft:sandstone
fill 349 292 510 350 292 510 minecraft:ochre_froglight
fill 351 292 510 351 307 510 minecraft:sandstone
fill 353 292 552 353 307 552 minecraft:sandstone
fill 354 292 552 355 292 552 minecraft:ochre_froglight
fill 356 292 552 356 307 552 minecraft:sandstone
fill 360 292 510 360 307 510 minecraft:sandstone
fill 360 292 522 360 293 522 minecraft:sandstone
fill 361 292 510 362 292 510 minecraft:ochre_froglight
fill 363 292 510 363 307 510 minecraft:sandstone
fill 363 292 513 363 292 515 minecraft:cut_sandstone
fill 364 292 512 366 292 512 minecraft:cut_sandstone
fill 364 292 516 366 292 516 minecraft:cut_sandstone
fill 365 292 552 365 307 552 minecraft:sandstone
fill 366 292 552 367 292 552 minecraft:ochre_froglight
fill 367 292 513 367 292 515 minecraft:cut_sandstone
fill 368 292 552 368 307 552 minecraft:sandstone
fill 371 292 511 371 307 511 minecraft:sandstone
fill 371 292 512 371 292 513 minecraft:ochre_froglight
fill 371 292 514 371 307 514 minecraft:sandstone
fill 371 292 523 371 307 523 minecraft:sandstone
fill 371 292 524 371 292 525 minecraft:ochre_froglight
fill 371 292 526 371 307 526 minecraft:sandstone
fill 371 292 535 371 307 535 minecraft:sandstone
fill 371 292 536 371 292 537 minecraft:ochre_froglight
fill 371 292 538 371 307 538 minecraft:sandstone
fill 371 292 547 371 307 547 minecraft:sandstone
fill 371 292 548 371 292 549 minecraft:ochre_froglight
fill 371 292 550 371 307 550 minecraft:sandstone
fill 329 293 517 329 307 518 minecraft:sandstone
fill 329 293 529 329 307 530 minecraft:sandstone
fill 329 293 541 329 307 542 minecraft:sandstone
fill 330 293 552 331 307 552 minecraft:sandstone
fill 337 293 510 338 307 510 minecraft:sandstone
fill 342 293 552 343 307 552 minecraft:sandstone
fill 349 293 510 350 307 510 minecraft:sandstone
fill 354 293 552 355 307 552 minecraft:sandstone
fill 361 293 510 362 307 510 minecraft:sandstone
fill 366 293 552 367 307 552 minecraft:sandstone
fill 371 293 512 371 307 513 minecraft:sandstone
fill 371 293 524 371 307 525 minecraft:sandstone
fill 371 293 536 371 307 537 minecraft:sandstone
fill 371 293 548 371 307 549 minecraft:sandstone
fill 361 295 542 362 296 543 minecraft:yellow_concrete
setblock 332 299 513 minecraft:light[level=14]
setblock 332 299 521 minecraft:light[level=14]
setblock 332 299 529 minecraft:light[level=14]
setblock 332 299 537 minecraft:light[level=14]
setblock 332 299 545 minecraft:light[level=14]
setblock 340 299 513 minecraft:light[level=14]
setblock 340 299 521 minecraft:light[level=14]
setblock 340 299 529 minecraft:light[level=14]
setblock 340 299 537 minecraft:light[level=14]
setblock 340 299 545 minecraft:light[level=14]
setblock 348 299 513 minecraft:light[level=14]
setblock 348 299 521 minecraft:light[level=14]
setblock 348 299 529 minecraft:light[level=14]
setblock 348 299 537 minecraft:light[level=14]
setblock 348 299 545 minecraft:light[level=14]
setblock 356 299 513 minecraft:light[level=14]
setblock 356 299 521 minecraft:light[level=14]
setblock 356 299 529 minecraft:light[level=14]
setblock 356 299 537 minecraft:light[level=14]
setblock 356 299 545 minecraft:light[level=14]
fill 363 299 513 363 300 515 minecraft:sandstone
fill 364 299 512 366 299 512 minecraft:sandstone
fill 364 299 516 366 300 516 minecraft:sandstone
setblock 364 299 521 minecraft:light[level=14]
setblock 364 299 529 minecraft:light[level=14]
setblock 364 299 537 minecraft:light[level=14]
setblock 364 299 545 minecraft:light[level=14]
fill 367 299 513 367 300 515 minecraft:sandstone
fill 331 300 520 331 300 522 minecraft:gold_block
fill 331 300 532 331 300 534 minecraft:gold_block
fill 331 300 544 331 300 546 minecraft:gold_block
fill 337 300 550 339 300 550 minecraft:gold_block
fill 341 300 512 343 300 512 minecraft:gold_block
fill 349 300 550 351 300 550 minecraft:gold_block
fill 353 300 512 355 300 512 minecraft:gold_block
fill 361 300 550 363 300 550 minecraft:gold_block
setblock 364 300 512 minecraft:sandstone
fill 365 300 512 367 300 512 minecraft:gold_block
fill 369 300 520 369 300 522 minecraft:gold_block
fill 369 300 532 369 300 534 minecraft:gold_block
fill 369 300 544 369 300 546 minecraft:gold_block
