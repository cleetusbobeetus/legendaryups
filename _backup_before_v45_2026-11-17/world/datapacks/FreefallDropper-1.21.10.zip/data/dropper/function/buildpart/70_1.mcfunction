setblock 470 15 304 minecraft:white_wool
fill 470 15 305 470 18 309 minecraft:cobbled_deepslate
setblock 471 15 278 minecraft:cobbled_deepslate
fill 471 15 279 471 18 279 minecraft:deepslate_tiles
setblock 471 15 283 minecraft:cobbled_deepslate
fill 471 15 284 471 18 284 minecraft:deepslate_tiles
setblock 471 15 288 minecraft:cobbled_deepslate
fill 471 15 289 471 18 289 minecraft:deepslate_tiles
setblock 471 15 293 minecraft:cobbled_deepslate
setblock 471 15 303 minecraft:cobbled_deepslate
fill 471 15 304 472 17 304 minecraft:deepslate_tiles
setblock 471 15 307 minecraft:deepslate_tiles
setblock 471 15 308 minecraft:cobbled_deepslate
fill 471 15 309 471 15 312 minecraft:deepslate_tiles
setblock 471 15 313 minecraft:cobbled_deepslate
fill 471 15 314 472 15 316 minecraft:deepslate_tiles
setblock 472 15 276 minecraft:deepslate_tiles
setblock 472 15 277 minecraft:cobbled_deepslate
setblock 472 15 281 minecraft:deepslate_tiles
setblock 472 15 282 minecraft:cobbled_deepslate
fill 472 15 283 472 18 283 minecraft:deepslate_tiles
setblock 472 15 287 minecraft:cobbled_deepslate
fill 472 15 288 472 18 288 minecraft:deepslate_tiles
fill 472 15 290 472 15 291 minecraft:deepslate_tiles
setblock 472 15 307 minecraft:cobbled_deepslate
fill 472 15 308 472 18 308 minecraft:deepslate_tiles
setblock 472 15 311 minecraft:deepslate_tiles
setblock 472 15 312 minecraft:cobbled_deepslate
fill 472 15 313 475 15 313 minecraft:deepslate_tiles
setblock 473 15 276 minecraft:cobbled_deepslate
fill 473 15 277 475 16 277 minecraft:deepslate_tiles
setblock 473 15 306 minecraft:cobbled_deepslate
fill 473 15 307 474 17 307 minecraft:deepslate_tiles
setblock 473 15 311 minecraft:cobbled_deepslate
fill 473 15 312 473 18 312 minecraft:deepslate_tiles
fill 473 15 314 473 15 315 minecraft:deepslate_tiles
setblock 473 15 316 minecraft:cobbled_deepslate
fill 474 15 276 474 18 276 minecraft:deepslate_tiles
setblock 474 15 309 minecraft:deepslate_tiles
setblock 474 15 310 minecraft:cobbled_deepslate
fill 474 15 311 474 18 311 minecraft:deepslate_tiles
setblock 474 15 314 minecraft:deepslate_tiles
setblock 474 15 315 minecraft:cobbled_deepslate
fill 474 15 316 477 15 316 minecraft:deepslate_tiles
setblock 475 15 314 minecraft:cobbled_deepslate
fill 475 15 315 475 18 315 minecraft:deepslate_tiles
setblock 476 15 313 minecraft:cobbled_deepslate
fill 476 15 314 476 18 314 minecraft:deepslate_tiles
fill 477 15 313 477 18 313 minecraft:deepslate_tiles
setblock 478 15 276 minecraft:cobbled_deepslate
setblock 478 15 316 minecraft:cobbled_deepslate
fill 479 15 276 479 17 276 minecraft:deepslate_tiles
setblock 479 15 315 minecraft:cobbled_deepslate
fill 479 15 316 479 18 316 minecraft:deepslate_tiles
setblock 480 15 314 minecraft:cobbled_deepslate
fill 480 15 315 480 18 315 minecraft:deepslate_tiles
fill 482 15 315 482 16 315 minecraft:deepslate_tiles
setblock 483 15 316 minecraft:cobbled_deepslate
fill 485 15 275 488 44 275 minecraft:cobbled_deepslate
setblock 489 15 275 minecraft:redstone_block
fill 490 15 275 490 92 275 minecraft:cobbled_deepslate
fill 491 15 316 492 15 316 minecraft:deepslate_tiles
setblock 493 15 316 minecraft:cobbled_deepslate
setblock 494 15 315 minecraft:cobbled_deepslate
fill 494 15 316 494 18 316 minecraft:deepslate_tiles
fill 495 15 276 497 15 276 minecraft:deepslate_tiles
fill 495 15 315 496 17 315 minecraft:deepslate_tiles
setblock 498 15 276 minecraft:cobbled_deepslate
setblock 498 15 316 minecraft:cobbled_deepslate
fill 501 15 311 501 25 311 minecraft:cobbled_deepslate
fill 509 15 276 509 18 276 minecraft:deepslate_tiles
fill 509 15 286 509 16 288 minecraft:deepslate_tiles
fill 510 15 281 510 17 281 minecraft:deepslate_tiles
setblock 510 15 284 minecraft:cobbled_deepslate
fill 510 15 285 510 18 285 minecraft:deepslate_tiles
setblock 510 15 289 minecraft:cobbled_deepslate
fill 510 15 290 510 18 290 minecraft:deepslate_tiles
fill 510 15 292 510 16 292 minecraft:deepslate_tiles
fill 510 15 311 510 17 311 minecraft:deepslate_tiles
fill 510 15 316 510 17 316 minecraft:deepslate_tiles
setblock 511 15 278 minecraft:cobbled_deepslate
fill 511 15 279 511 18 279 minecraft:deepslate_tiles
setblock 511 15 283 minecraft:cobbled_deepslate
fill 511 15 284 511 18 284 minecraft:deepslate_tiles
setblock 511 15 288 minecraft:cobbled_deepslate
fill 511 15 289 511 18 289 minecraft:deepslate_tiles
setblock 511 15 293 minecraft:cobbled_deepslate
fill 511 15 294 511 17 295 minecraft:deepslate_tiles
fill 511 15 305 511 15 307 minecraft:deepslate_tiles
setblock 511 15 308 minecraft:cobbled_deepslate
fill 511 15 309 511 18 309 minecraft:deepslate_tiles
setblock 511 15 313 minecraft:cobbled_deepslate
fill 511 15 314 511 18 314 minecraft:deepslate_tiles
fill 470 16 277 471 16 277 minecraft:cobbled_deepslate
fill 470 16 304 470 95 304 minecraft:cobbled_deepslate
setblock 471 16 276 minecraft:deepslate_tiles
fill 471 16 278 472 18 278 minecraft:deepslate_tiles
setblock 471 16 282 minecraft:cobbled_deepslate
fill 471 16 283 471 19 283 minecraft:deepslate_tiles
setblock 471 16 287 minecraft:cobbled_deepslate
fill 471 16 288 471 19 288 minecraft:deepslate_tiles
fill 471 16 290 471 16 291 minecraft:deepslate_tiles
setblock 471 16 292 minecraft:cobbled_deepslate
fill 471 16 293 471 17 295 minecraft:deepslate_tiles
setblock 471 16 302 minecraft:cobbled_deepslate
fill 471 16 303 471 19 303 minecraft:deepslate_tiles
setblock 471 16 307 minecraft:cobbled_deepslate
fill 471 16 308 471 16 311 minecraft:deepslate_tiles
setblock 471 16 312 minecraft:cobbled_deepslate
fill 471 16 313 471 16 316 minecraft:deepslate_tiles
setblock 472 16 276 minecraft:cobbled_deepslate
fill 472 16 277 472 19 277 minecraft:deepslate_tiles
fill 472 16 279 472 17 279 minecraft:deepslate_tiles
setblock 472 16 281 minecraft:cobbled_deepslate
fill 472 16 282 472 17 282 minecraft:deepslate_tiles
setblock 472 16 286 minecraft:cobbled_deepslate
fill 472 16 287 473 17 287 minecraft:deepslate_tiles
setblock 472 16 290 minecraft:deepslate_tiles
setblock 472 16 291 minecraft:cobbled_deepslate
fill 472 16 292 472 18 293 minecraft:deepslate_tiles
setblock 472 16 306 minecraft:cobbled_deepslate
fill 472 16 307 472 19 307 minecraft:deepslate_tiles
setblock 472 16 310 minecraft:deepslate_tiles
setblock 472 16 311 minecraft:cobbled_deepslate
fill 472 16 312 472 16 315 minecraft:deepslate_tiles
setblock 472 16 316 minecraft:cobbled_deepslate
fill 473 16 276 473 19 276 minecraft:deepslate_tiles
fill 473 16 288 473 16 289 minecraft:deepslate_tiles
setblock 473 16 305 minecraft:cobbled_deepslate
fill 473 16 306 473 19 306 minecraft:deepslate_tiles
setblock 473 16 310 minecraft:cobbled_deepslate
fill 473 16 311 473 19 311 minecraft:deepslate_tiles
fill 473 16 313 473 16 314 minecraft:deepslate_tiles
setblock 473 16 315 minecraft:cobbled_deepslate
fill 473 16 316 476 16 316 minecraft:deepslate_tiles
setblock 474 16 309 minecraft:cobbled_deepslate
fill 474 16 310 475 18 310 minecraft:deepslate_tiles
setblock 474 16 313 minecraft:deepslate_tiles
setblock 474 16 314 minecraft:cobbled_deepslate
fill 474 16 315 474 19 315 minecraft:deepslate_tiles
fill 475 16 311 475 16 312 minecraft:deepslate_tiles
setblock 475 16 313 minecraft:cobbled_deepslate
fill 475 16 314 475 19 314 minecraft:deepslate_tiles
setblock 476 16 312 minecraft:cobbled_deepslate
fill 476 16 313 476 19 313 minecraft:deepslate_tiles
setblock 477 16 276 minecraft:cobbled_deepslate
setblock 477 16 316 minecraft:cobbled_deepslate
fill 478 16 276 478 19 276 minecraft:deepslate_tiles
setblock 478 16 314 minecraft:deepslate_tiles
setblock 478 16 315 minecraft:cobbled_deepslate
fill 478 16 316 478 19 316 minecraft:deepslate_tiles
setblock 479 16 313 minecraft:deepslate_tiles
setblock 479 16 314 minecraft:cobbled_deepslate
fill 479 16 315 479 19 315 minecraft:deepslate_tiles
fill 480 16 314 480 19 314 minecraft:deepslate_tiles
setblock 482 16 316 minecraft:cobbled_deepslate
fill 483 16 316 484 18 316 minecraft:deepslate_tiles
fill 488 16 316 491 16 316 minecraft:deepslate_tiles
fill 489 16 275 489 31 275 minecraft:cobbled_deepslate
fill 491 16 315 492 16 315 minecraft:deepslate_tiles
setblock 492 16 316 minecraft:cobbled_deepslate
fill 493 16 276 496 16 276 minecraft:deepslate_tiles
setblock 493 16 315 minecraft:cobbled_deepslate
fill 493 16 316 493 19 316 minecraft:deepslate_tiles
fill 494 16 315 494 19 315 minecraft:deepslate_tiles
fill 495 16 316 496 16 316 minecraft:deepslate_tiles
setblock 497 16 276 minecraft:cobbled_deepslate
setblock 497 16 315 minecraft:deepslate_tiles
setblock 497 16 316 minecraft:cobbled_deepslate
fill 498 16 276 499 18 276 minecraft:deepslate_tiles
fill 498 16 316 499 18 316 minecraft:deepslate_tiles
setblock 507 16 276 minecraft:cobbled_deepslate
fill 508 16 276 508 19 276 minecraft:deepslate_tiles
fill 508 16 316 509 18 316 minecraft:deepslate_tiles
fill 509 16 285 509 17 285 minecraft:deepslate_tiles
setblock 509 16 289 minecraft:cobbled_deepslate
fill 509 16 290 509 19 290 minecraft:deepslate_tiles
setblock 510 16 277 minecraft:deepslate_tiles
setblock 510 16 278 minecraft:cobbled_deepslate
fill 510 16 279 510 18 280 minecraft:deepslate_tiles
setblock 510 16 283 minecraft:cobbled_deepslate
fill 510 16 284 510 19 284 minecraft:deepslate_tiles
setblock 510 16 288 minecraft:cobbled_deepslate
fill 510 16 289 510 19 289 minecraft:deepslate_tiles
setblock 510 16 293 minecraft:cobbled_deepslate
fill 510 16 309 510 18 310 minecraft:deepslate_tiles
setblock 510 16 312 minecraft:deepslate_tiles
setblock 510 16 313 minecraft:cobbled_deepslate
fill 510 16 314 510 18 315 minecraft:deepslate_tiles
setblock 511 16 277 minecraft:cobbled_deepslate
fill 511 16 278 511 19 278 minecraft:deepslate_tiles
setblock 511 16 282 minecraft:cobbled_deepslate
fill 511 16 283 511 19 283 minecraft:deepslate_tiles
setblock 511 16 287 minecraft:cobbled_deepslate
fill 511 16 288 511 19 288 minecraft:deepslate_tiles
setblock 511 16 291 minecraft:deepslate_tiles
setblock 511 16 292 minecraft:cobbled_deepslate
fill 511 16 293 511 19 293 minecraft:deepslate_tiles
setblock 511 16 296 minecraft:deepslate_tiles
fill 511 16 305 511 16 306 minecraft:deepslate_tiles
setblock 511 16 307 minecraft:cobbled_deepslate
fill 511 16 308 511 19 308 minecraft:deepslate_tiles
setblock 511 16 311 minecraft:deepslate_tiles
setblock 511 16 312 minecraft:cobbled_deepslate
fill 511 16 313 511 19 313 minecraft:deepslate_tiles
fill 470 17 277 470 92 277 minecraft:cobbled_deepslate
setblock 471 17 276 minecraft:cobbled_deepslate
fill 471 17 277 471 20 277 minecraft:deepslate_tiles
setblock 471 17 281 minecraft:cobbled_deepslate
fill 471 17 282 471 20 282 minecraft:deepslate_tiles
setblock 471 17 286 minecraft:cobbled_deepslate
fill 471 17 287 471 20 287 minecraft:deepslate_tiles
setblock 471 17 290 minecraft:deepslate_tiles
setblock 471 17 291 minecraft:cobbled_deepslate
fill 471 17 292 471 20 292 minecraft:deepslate_tiles
setblock 471 17 296 minecraft:cobbled_deepslate
fill 471 17 297 471 19 298 minecraft:deepslate_tiles
setblock 471 17 301 minecraft:cobbled_deepslate
fill 471 17 302 471 20 302 minecraft:deepslate_tiles
setblock 471 17 305 minecraft:deepslate_tiles
setblock 471 17 306 minecraft:cobbled_deepslate
fill 471 17 307 471 17 310 minecraft:deepslate_tiles
setblock 471 17 311 minecraft:cobbled_deepslate
fill 471 17 312 471 17 315 minecraft:deepslate_tiles
setblock 471 17 316 minecraft:cobbled_deepslate
fill 472 17 276 472 20 276 minecraft:deepslate_tiles
setblock 472 17 280 minecraft:cobbled_deepslate
setblock 472 17 281 minecraft:deepslate_tiles
setblock 472 17 285 minecraft:cobbled_deepslate
fill 472 17 286 472 19 286 minecraft:deepslate_tiles
setblock 472 17 290 minecraft:cobbled_deepslate
fill 472 17 291 473 19 291 minecraft:deepslate_tiles
setblock 472 17 294 minecraft:deepslate_tiles
setblock 472 17 295 minecraft:cobbled_deepslate
fill 472 17 303 472 18 303 minecraft:deepslate_tiles
setblock 472 17 305 minecraft:cobbled_deepslate
fill 472 17 306 472 20 306 minecraft:deepslate_tiles
setblock 472 17 310 minecraft:cobbled_deepslate
fill 472 17 311 472 17 314 minecraft:deepslate_tiles
setblock 472 17 315 minecraft:cobbled_deepslate
fill 472 17 316 475 17 316 minecraft:deepslate_tiles
fill 473 17 277 474 17 277 minecraft:deepslate_tiles
setblock 473 17 288 minecraft:deepslate_tiles
setblock 473 17 289 minecraft:cobbled_deepslate
fill 473 17 290 473 19 290 minecraft:deepslate_tiles
fill 473 17 305 473 18 305 minecraft:deepslate_tiles
setblock 473 17 308 minecraft:deepslate_tiles
setblock 473 17 309 minecraft:cobbled_deepslate
fill 473 17 310 473 20 310 minecraft:deepslate_tiles
setblock 473 17 313 minecraft:deepslate_tiles
setblock 473 17 314 minecraft:cobbled_deepslate
fill 473 17 315 473 20 315 minecraft:deepslate_tiles
setblock 474 17 308 minecraft:cobbled_deepslate
fill 474 17 309 474 20 309 minecraft:deepslate_tiles
setblock 474 17 313 minecraft:cobbled_deepslate
fill 474 17 314 474 20 314 minecraft:deepslate_tiles
setblock 475 17 277 minecraft:cobbled_deepslate
setblock 475 17 311 minecraft:deepslate_tiles
setblock 475 17 312 minecraft:cobbled_deepslate
fill 475 17 313 475 20 313 minecraft:deepslate_tiles
setblock 476 17 276 minecraft:cobbled_deepslate
fill 476 17 312 476 18 312 minecraft:deepslate_tiles
setblock 476 17 316 minecraft:cobbled_deepslate
fill 477 17 276 477 20 276 minecraft:deepslate_tiles
setblock 477 17 315 minecraft:cobbled_deepslate
fill 477 17 316 477 20 316 minecraft:deepslate_tiles
setblock 478 17 314 minecraft:cobbled_deepslate
fill 478 17 315 478 20 315 minecraft:deepslate_tiles
setblock 479 17 313 minecraft:cobbled_deepslate
fill 479 17 314 479 20 314 minecraft:deepslate_tiles
setblock 481 17 314 minecraft:deepslate_tiles
setblock 481 17 316 minecraft:cobbled_deepslate
setblock 482 17 315 minecraft:cobbled_deepslate
fill 482 17 316 482 20 316 minecraft:deepslate_tiles
setblock 485 17 316 minecraft:deepslate_tiles
setblock 486 17 316 minecraft:cobbled_deepslate
fill 487 17 316 490 17 316 minecraft:deepslate_tiles
fill 489 17 315 491 17 315 minecraft:deepslate_tiles
setblock 491 17 316 minecraft:cobbled_deepslate
fill 492 17 276 495 17 276 minecraft:deepslate_tiles
setblock 492 17 314 minecraft:deepslate_tiles
setblock 492 17 315 minecraft:cobbled_deepslate
fill 492 17 316 492 20 316 minecraft:deepslate_tiles
setblock 493 17 314 minecraft:cobbled_deepslate
fill 493 17 315 493 20 315 minecraft:deepslate_tiles
fill 494 17 314 495 18 314 minecraft:deepslate_tiles
setblock 495 17 316 minecraft:deepslate_tiles
setblock 496 17 276 minecraft:cobbled_deepslate
setblock 496 17 316 minecraft:cobbled_deepslate
fill 497 17 276 497 20 276 minecraft:deepslate_tiles
setblock 497 17 315 minecraft:cobbled_deepslate
fill 497 17 316 497 20 316 minecraft:deepslate_tiles
fill 498 17 315 498 18 315 minecraft:deepslate_tiles
setblock 500 17 276 minecraft:deepslate_tiles
setblock 500 17 316 minecraft:deepslate_tiles
setblock 506 17 276 minecraft:cobbled_deepslate
setblock 506 17 316 minecraft:cobbled_deepslate
fill 507 17 276 507 20 276 minecraft:deepslate_tiles
fill 507 17 316 507 20 316 minecraft:deepslate_tiles
setblock 509 17 277 minecraft:deepslate_tiles
fill 509 17 286 509 17 287 minecraft:deepslate_tiles
setblock 509 17 288 minecraft:cobbled_deepslate
fill 509 17 289 509 20 289 minecraft:deepslate_tiles
fill 509 17 291 509 18 291 minecraft:deepslate_tiles
fill 509 17 315 509 19 315 minecraft:deepslate_tiles
setblock 510 17 276 minecraft:deepslate_tiles
setblock 510 17 277 minecraft:cobbled_deepslate
fill 510 17 278 510 20 278 minecraft:deepslate_tiles
setblock 510 17 282 minecraft:cobbled_deepslate
fill 510 17 283 510 20 283 minecraft:deepslate_tiles
setblock 510 17 287 minecraft:cobbled_deepslate
fill 510 17 288 510 20 288 minecraft:deepslate_tiles
setblock 510 17 292 minecraft:cobbled_deepslate
fill 510 17 293 510 19 294 minecraft:deepslate_tiles
fill 510 17 308 510 19 308 minecraft:deepslate_tiles
setblock 510 17 312 minecraft:cobbled_deepslate
fill 510 17 313 510 20 313 minecraft:deepslate_tiles
setblock 511 17 276 minecraft:cobbled_deepslate
fill 511 17 277 511 20 277 minecraft:deepslate_tiles
setblock 511 17 281 minecraft:cobbled_deepslate
fill 511 17 282 511 20 282 minecraft:deepslate_tiles
setblock 511 17 286 minecraft:cobbled_deepslate
fill 511 17 287 511 20 287 minecraft:deepslate_tiles
setblock 511 17 291 minecraft:cobbled_deepslate
fill 511 17 292 511 20 292 minecraft:deepslate_tiles
setblock 511 17 296 minecraft:cobbled_deepslate
fill 511 17 297 511 20 297 minecraft:deepslate_tiles
fill 511 17 304 511 17 305 minecraft:deepslate_tiles
setblock 511 17 306 minecraft:cobbled_deepslate
fill 511 17 307 511 20 307 minecraft:deepslate_tiles
setblock 511 17 311 minecraft:cobbled_deepslate
fill 511 17 312 511 20 312 minecraft:deepslate_tiles
setblock 511 17 315 minecraft:deepslate_tiles
setblock 511 17 316 minecraft:cobbled_deepslate
setblock 512 17 285 minecraft:white_wool
fill 470 18 311 470 38 311 minecraft:cobbled_deepslate
setblock 470 18 312 minecraft:redstone_block
fill 470 18 313 470 90 314 minecraft:cobbled_deepslate
fill 471 18 276 471 21 276 minecraft:deepslate_tiles
setblock 471 18 280 minecraft:cobbled_deepslate
fill 471 18 281 471 21 281 minecraft:deepslate_tiles
setblock 471 18 285 minecraft:cobbled_deepslate
fill 471 18 286 471 21 286 minecraft:deepslate_tiles
setblock 471 18 290 minecraft:cobbled_deepslate
fill 471 18 291 471 21 291 minecraft:deepslate_tiles
fill 471 18 293 471 18 294 minecraft:deepslate_tiles
setblock 471 18 295 minecraft:cobbled_deepslate
fill 471 18 296 472 20 296 minecraft:deepslate_tiles
setblock 471 18 299 minecraft:deepslate_tiles
setblock 471 18 300 minecraft:cobbled_deepslate
fill 471 18 301 471 21 301 minecraft:deepslate_tiles
setblock 471 18 304 minecraft:deepslate_tiles
setblock 471 18 305 minecraft:cobbled_deepslate
fill 471 18 306 471 18 309 minecraft:deepslate_tiles
setblock 471 18 310 minecraft:cobbled_deepslate
fill 471 18 311 471 18 314 minecraft:deepslate_tiles
setblock 471 18 315 minecraft:cobbled_deepslate
fill 471 18 316 474 18 316 minecraft:deepslate_tiles
setblock 472 18 279 minecraft:cobbled_deepslate
setblock 472 18 284 minecraft:cobbled_deepslate
fill 472 18 285 472 19 285 minecraft:deepslate_tiles
fill 472 18 287 472 19 287 minecraft:deepslate_tiles
setblock 472 18 289 minecraft:cobbled_deepslate
fill 472 18 290 472 21 290 minecraft:deepslate_tiles
setblock 472 18 294 minecraft:cobbled_deepslate
fill 472 18 295 472 21 295 minecraft:deepslate_tiles
setblock 472 18 304 minecraft:cobbled_deepslate
fill 472 18 305 472 21 305 minecraft:deepslate_tiles
setblock 472 18 309 minecraft:cobbled_deepslate
fill 472 18 310 472 18 313 minecraft:deepslate_tiles
setblock 472 18 314 minecraft:cobbled_deepslate
fill 472 18 315 472 21 315 minecraft:deepslate_tiles
setblock 473 18 277 minecraft:deepslate_tiles
setblock 473 18 288 minecraft:cobbled_deepslate
setblock 473 18 289 minecraft:deepslate_tiles
setblock 473 18 292 minecraft:deepslate_tiles
setblock 473 18 307 minecraft:deepslate_tiles
setblock 473 18 308 minecraft:cobbled_deepslate
fill 473 18 309 473 21 309 minecraft:deepslate_tiles
setblock 473 18 313 minecraft:cobbled_deepslate
fill 473 18 314 473 21 314 minecraft:deepslate_tiles
setblock 474 18 277 minecraft:cobbled_deepslate
setblock 474 18 307 minecraft:cobbled_deepslate
fill 474 18 308 474 19 308 minecraft:deepslate_tiles
setblock 474 18 312 minecraft:cobbled_deepslate
fill 474 18 313 474 21 313 minecraft:deepslate_tiles
setblock 475 18 276 minecraft:cobbled_deepslate
fill 475 18 277 475 19 277 minecraft:deepslate_tiles
setblock 475 18 311 minecraft:cobbled_deepslate
fill 475 18 312 475 19 312 minecraft:deepslate_tiles
setblock 475 18 316 minecraft:cobbled_deepslate
fill 476 18 276 476 21 276 minecraft:deepslate_tiles
setblock 476 18 315 minecraft:cobbled_deepslate
fill 476 18 316 476 21 316 minecraft:deepslate_tiles
setblock 477 18 314 minecraft:cobbled_deepslate
fill 477 18 315 477 21 315 minecraft:deepslate_tiles
setblock 478 18 313 minecraft:cobbled_deepslate
fill 478 18 314 478 21 314 minecraft:deepslate_tiles
setblock 480 18 316 minecraft:cobbled_deepslate
fill 481 18 314 481 21 314 minecraft:white_wool
setblock 481 18 315 minecraft:cobbled_deepslate
fill 481 18 316 481 21 316 minecraft:deepslate_tiles
fill 482 18 315 483 19 315 minecraft:deepslate_tiles
setblock 484 18 275 minecraft:redstone_block
setblock 485 18 316 minecraft:cobbled_deepslate
fill 486 18 316 489 18 316 minecraft:deepslate_tiles
fill 487 18 315 490 18 315 minecraft:deepslate_tiles
setblock 490 18 316 minecraft:cobbled_deepslate
fill 491 18 276 494 18 276 minecraft:deepslate_tiles
setblock 491 18 314 minecraft:deepslate_tiles
setblock 491 18 315 minecraft:cobbled_deepslate
fill 491 18 316 491 21 316 minecraft:deepslate_tiles
setblock 492 18 314 minecraft:cobbled_deepslate
fill 492 18 315 492 21 315 minecraft:deepslate_tiles
fill 493 18 314 493 20 314 minecraft:deepslate_tiles
setblock 495 18 276 minecraft:cobbled_deepslate
setblock 495 18 315 minecraft:deepslate_tiles
setblock 495 18 316 minecraft:cobbled_deepslate
fill 496 18 276 496 21 276 minecraft:deepslate_tiles
setblock 496 18 315 minecraft:cobbled_deepslate
fill 496 18 316 496 21 316 minecraft:deepslate_tiles
fill 497 18 315 497 20 315 minecraft:deepslate_tiles
setblock 500 18 276 minecraft:cobbled_deepslate
setblock 500 18 316 minecraft:cobbled_deepslate
fill 501 18 276 501 21 276 minecraft:deepslate_tiles
fill 501 18 316 501 20 316 minecraft:deepslate_tiles
setblock 504 18 276 minecraft:deepslate_tiles
setblock 505 18 276 minecraft:cobbled_deepslate
setblock 505 18 316 minecraft:cobbled_deepslate
fill 506 18 276 506 21 276 minecraft:deepslate_tiles
fill 506 18 316 506 21 316 minecraft:deepslate_tiles
setblock 508 18 277 minecraft:deepslate_tiles
fill 508 18 315 508 20 315 minecraft:deepslate_tiles
setblock 509 18 277 minecraft:cobbled_deepslate
setblock 509 18 286 minecraft:deepslate_tiles
setblock 509 18 287 minecraft:cobbled_deepslate
fill 509 18 288 509 19 288 minecraft:deepslate_tiles
setblock 509 18 292 minecraft:cobbled_deepslate
setblock 510 18 276 minecraft:cobbled_deepslate
fill 510 18 277 510 21 277 minecraft:deepslate_tiles
setblock 510 18 281 minecraft:cobbled_deepslate
fill 510 18 282 510 21 282 minecraft:deepslate_tiles
setblock 510 18 286 minecraft:cobbled_deepslate
fill 510 18 287 510 21 287 minecraft:deepslate_tiles
setblock 510 18 291 minecraft:cobbled_deepslate
fill 510 18 292 510 21 292 minecraft:deepslate_tiles
setblock 510 18 295 minecraft:deepslate_tiles
setblock 510 18 311 minecraft:cobbled_deepslate
fill 510 18 312 510 21 312 minecraft:deepslate_tiles
setblock 510 18 316 minecraft:cobbled_deepslate
fill 511 18 276 511 21 276 minecraft:deepslate_tiles
setblock 511 18 280 minecraft:cobbled_deepslate
fill 511 18 281 511 21 281 minecraft:deepslate_tiles
fill 511 18 285 512 18 285 minecraft:cobbled_deepslate
fill 511 18 286 511 21 286 minecraft:deepslate_tiles
setblock 511 18 290 minecraft:cobbled_deepslate
fill 511 18 291 511 21 291 minecraft:deepslate_tiles
setblock 511 18 294 minecraft:deepslate_tiles
setblock 511 18 295 minecraft:cobbled_deepslate
fill 511 18 296 511 21 296 minecraft:deepslate_tiles
fill 511 18 298 511 19 298 minecraft:deepslate_tiles
setblock 511 18 304 minecraft:deepslate_tiles
setblock 511 18 305 minecraft:cobbled_deepslate
fill 511 18 306 511 21 306 minecraft:deepslate_tiles
setblock 511 18 310 minecraft:cobbled_deepslate
fill 511 18 311 511 21 311 minecraft:deepslate_tiles
setblock 511 18 315 minecraft:cobbled_deepslate
fill 511 18 316 511 21 316 minecraft:deepslate_tiles
setblock 470 19 305 minecraft:redstone_block
fill 470 19 306 470 54 309 minecraft:cobbled_deepslate
fill 470 19 312 470 94 312 minecraft:cobbled_deepslate
setblock 471 19 278 minecraft:deepslate_tiles
setblock 471 19 279 minecraft:cobbled_deepslate
fill 471 19 280 471 22 280 minecraft:deepslate_tiles
setblock 471 19 284 minecraft:cobbled_deepslate
fill 471 19 285 471 21 285 minecraft:deepslate_tiles
setblock 471 19 289 minecraft:cobbled_deepslate
fill 471 19 290 471 22 290 minecraft:deepslate_tiles
setblock 471 19 293 minecraft:deepslate_tiles
setblock 471 19 294 minecraft:cobbled_deepslate
fill 471 19 295 471 22 295 minecraft:deepslate_tiles
setblock 471 19 299 minecraft:cobbled_deepslate
fill 471 19 300 471 22 300 minecraft:deepslate_tiles
setblock 471 19 304 minecraft:cobbled_deepslate
fill 471 19 305 471 19 308 minecraft:deepslate_tiles
setblock 471 19 309 minecraft:cobbled_deepslate
fill 471 19 310 471 19 313 minecraft:deepslate_tiles
setblock 471 19 314 minecraft:cobbled_deepslate
fill 471 19 315 471 21 316 minecraft:deepslate_tiles
setblock 472 19 278 minecraft:cobbled_deepslate
setblock 472 19 279 minecraft:deepslate_tiles
setblock 472 19 288 minecraft:cobbled_deepslate
fill 472 19 289 472 21 289 minecraft:deepslate_tiles
setblock 472 19 292 minecraft:deepslate_tiles
setblock 472 19 293 minecraft:cobbled_deepslate
fill 472 19 294 472 22 294 minecraft:deepslate_tiles
setblock 472 19 297 minecraft:deepslate_tiles
setblock 472 19 303 minecraft:cobbled_deepslate
fill 472 19 304 472 21 304 minecraft:deepslate_tiles
setblock 472 19 308 minecraft:cobbled_deepslate
fill 472 19 309 472 19 312 minecraft:deepslate_tiles
setblock 472 19 313 minecraft:cobbled_deepslate
fill 472 19 314 472 22 314 minecraft:deepslate_tiles
fill 472 19 316 473 19 316 minecraft:deepslate_tiles
setblock 473 19 277 minecraft:cobbled_deepslate
setblock 473 19 278 minecraft:light[level=12]
setblock 473 19 285 minecraft:light[level=12]
setblock 473 19 292 minecraft:cobbled_deepslate
fill 473 19 293 473 20 293 minecraft:deepslate_tiles
fill 473 19 294 477 26 295 minecraft:white_wool
setblock 473 19 299 minecraft:light[level=12]
setblock 473 19 307 minecraft:cobbled_deepslate
fill 473 19 308 473 21 308 minecraft:deepslate_tiles
setblock 473 19 312 minecraft:cobbled_deepslate
fill 473 19 313 473 22 313 minecraft:deepslate_tiles
setblock 474 19 276 minecraft:cobbled_deepslate
fill 474 19 277 474 21 277 minecraft:deepslate_tiles
fill 474 19 292 476 35 293 minecraft:white_wool
fill 474 19 296 476 35 296 minecraft:white_wool
setblock 474 19 310 minecraft:deepslate_tiles
setblock 474 19 311 minecraft:cobbled_deepslate
fill 474 19 312 474 21 312 minecraft:deepslate_tiles
setblock 474 19 316 minecraft:cobbled_deepslate
fill 475 19 276 475 22 276 minecraft:deepslate_tiles
setblock 475 19 315 minecraft:cobbled_deepslate
fill 475 19 316 475 22 316 minecraft:deepslate_tiles
setblock 476 19 314 minecraft:cobbled_deepslate
fill 476 19 315 476 22 315 minecraft:deepslate_tiles
fill 477 19 293 477 35 293 minecraft:white_wool
setblock 477 19 313 minecraft:cobbled_deepslate
fill 477 19 314 477 22 314 minecraft:deepslate_tiles
setblock 478 19 313 minecraft:deepslate_tiles
setblock 479 19 316 minecraft:cobbled_deepslate
setblock 480 19 278 minecraft:light[level=12]
setblock 480 19 285 minecraft:light[level=12]
setblock 480 19 292 minecraft:light[level=12]
setblock 480 19 299 minecraft:light[level=12]
setblock 480 19 306 minecraft:light[level=12]
setblock 480 19 313 minecraft:light[level=12]
setblock 480 19 315 minecraft:cobbled_deepslate
fill 480 19 316 480 22 316 minecraft:deepslate_tiles
fill 481 19 315 481 20 315 minecraft:deepslate_tiles
setblock 483 19 316 minecraft:deepslate_tiles
fill 484 19 275 484 83 275 minecraft:cobbled_deepslate
setblock 484 19 316 minecraft:cobbled_deepslate
fill 485 19 316 488 19 316 minecraft:deepslate_tiles
fill 486 19 315 489 19 315 minecraft:deepslate_tiles
setblock 487 19 278 minecraft:light[level=12]
setblock 487 19 285 minecraft:light[level=12]
setblock 487 19 292 minecraft:light[level=12]
setblock 487 19 299 minecraft:light[level=12]
setblock 487 19 306 minecraft:light[level=12]
setblock 487 19 313 minecraft:light[level=12]
setblock 489 19 316 minecraft:cobbled_deepslate
fill 490 19 276 493 19 276 minecraft:deepslate_tiles
setblock 490 19 314 minecraft:deepslate_tiles
setblock 490 19 315 minecraft:cobbled_deepslate
fill 490 19 316 490 22 316 minecraft:deepslate_tiles
setblock 491 19 314 minecraft:cobbled_deepslate
fill 491 19 315 491 22 315 minecraft:deepslate_tiles
fill 492 19 314 492 20 314 minecraft:deepslate_tiles
setblock 494 19 276 minecraft:cobbled_deepslate
setblock 494 19 278 minecraft:light[level=12]
setblock 494 19 285 minecraft:light[level=12]
setblock 494 19 292 minecraft:light[level=12]
setblock 494 19 299 minecraft:light[level=12]
setblock 494 19 306 minecraft:light[level=12]
setblock 494 19 313 minecraft:light[level=12]
setblock 494 19 314 minecraft:deepslate_tiles
setblock 494 19 316 minecraft:cobbled_deepslate
fill 495 19 276 495 22 276 minecraft:deepslate_tiles
setblock 495 19 315 minecraft:cobbled_deepslate
fill 495 19 316 495 22 316 minecraft:deepslate_tiles
fill 496 19 315 496 21 315 minecraft:deepslate_tiles
setblock 498 19 276 minecraft:deepslate_tiles
setblock 498 19 316 minecraft:deepslate_tiles
setblock 499 19 276 minecraft:cobbled_deepslate
setblock 499 19 316 minecraft:cobbled_deepslate
fill 500 19 276 500 22 276 minecraft:deepslate_tiles
fill 500 19 316 500 20 316 minecraft:deepslate_tiles
setblock 500 19 317 minecraft:white_wool
setblock 501 19 278 minecraft:light[level=12]
setblock 501 19 285 minecraft:light[level=12]
setblock 501 19 292 minecraft:light[level=12]
setblock 501 19 299 minecraft:light[level=12]
setblock 501 19 306 minecraft:light[level=12]
setblock 501 19 313 minecraft:light[level=12]
fill 501 19 317 502 49 317 minecraft:cobbled_deepslate
fill 502 19 276 503 19 276 minecraft:deepslate_tiles
setblock 503 19 316 minecraft:deepslate_tiles
setblock 504 19 276 minecraft:cobbled_deepslate
setblock 504 19 316 minecraft:cobbled_deepslate
fill 505 19 276 505 22 276 minecraft:deepslate_tiles
fill 505 19 316 505 22 316 minecraft:deepslate_tiles
fill 507 19 315 507 21 315 minecraft:deepslate_tiles
fill 508 19 275 510 94 275 minecraft:cobbled_deepslate
setblock 508 19 277 minecraft:cobbled_deepslate
setblock 508 19 278 minecraft:light[level=12]
setblock 508 19 285 minecraft:light[level=12]
setblock 508 19 292 minecraft:light[level=12]
setblock 508 19 299 minecraft:light[level=12]
setblock 508 19 306 minecraft:light[level=12]
setblock 508 19 313 minecraft:light[level=12]
setblock 508 19 316 minecraft:deepslate_tiles
setblock 509 19 276 minecraft:cobbled_deepslate
fill 509 19 277 509 22 277 minecraft:deepslate_tiles
setblock 509 19 287 minecraft:deepslate_tiles
setblock 509 19 291 minecraft:cobbled_deepslate
fill 509 19 292 509 20 292 minecraft:deepslate_tiles
fill 509 19 312 509 20 314 minecraft:deepslate_tiles
setblock 509 19 316 minecraft:cobbled_deepslate
fill 510 19 276 510 22 276 minecraft:deepslate_tiles
setblock 510 19 279 minecraft:deepslate_tiles
setblock 510 19 280 minecraft:cobbled_deepslate
fill 510 19 281 510 22 281 minecraft:deepslate_tiles
setblock 510 19 285 minecraft:cobbled_deepslate
fill 510 19 286 510 21 286 minecraft:deepslate_tiles
setblock 510 19 290 minecraft:cobbled_deepslate
fill 510 19 291 510 22 291 minecraft:deepslate_tiles
setblock 510 19 295 minecraft:cobbled_deepslate
setblock 510 19 309 minecraft:deepslate_tiles
setblock 510 19 310 minecraft:cobbled_deepslate
fill 510 19 311 510 22 311 minecraft:deepslate_tiles
setblock 510 19 314 minecraft:deepslate_tiles
setblock 510 19 315 minecraft:cobbled_deepslate
fill 510 19 316 510 22 316 minecraft:deepslate_tiles
setblock 511 19 275 minecraft:white_wool
setblock 511 19 279 minecraft:cobbled_deepslate
fill 511 19 280 511 22 280 minecraft:deepslate_tiles
setblock 511 19 284 minecraft:cobbled_deepslate
fill 511 19 285 511 22 285 minecraft:deepslate_tiles
setblock 511 19 289 minecraft:cobbled_deepslate
fill 511 19 290 511 22 290 minecraft:deepslate_tiles
setblock 511 19 294 minecraft:cobbled_deepslate
fill 511 19 295 511 22 295 minecraft:deepslate_tiles
setblock 511 19 299 minecraft:cobbled_deepslate
fill 511 19 305 511 20 305 minecraft:deepslate_tiles
setblock 511 19 309 minecraft:cobbled_deepslate
fill 511 19 310 511 22 310 minecraft:deepslate_tiles
setblock 511 19 314 minecraft:cobbled_deepslate
fill 511 19 315 511 22 315 minecraft:deepslate_tiles
fill 512 19 275 512 94 275 minecraft:cobbled_deepslate
fill 512 19 285 512 51 285 minecraft:cobbled_deepslate
fill 470 20 305 470 94 305 minecraft:cobbled_deepslate
setblock 471 20 278 minecraft:cobbled_deepslate
fill 471 20 279 471 23 279 minecraft:deepslate_tiles
setblock 471 20 283 minecraft:cobbled_deepslate
fill 471 20 284 471 21 284 minecraft:deepslate_tiles
setblock 471 20 288 minecraft:cobbled_deepslate
fill 471 20 289 471 23 289 minecraft:deepslate_tiles
setblock 471 20 293 minecraft:cobbled_deepslate
fill 471 20 294 471 23 294 minecraft:deepslate_tiles
setblock 471 20 297 minecraft:deepslate_tiles
setblock 471 20 298 minecraft:cobbled_deepslate
fill 471 20 299 471 23 299 minecraft:deepslate_tiles
setblock 471 20 303 minecraft:cobbled_deepslate
fill 471 20 304 471 20 307 minecraft:deepslate_tiles
setblock 471 20 308 minecraft:cobbled_deepslate
fill 471 20 309 471 20 312 minecraft:deepslate_tiles
setblock 471 20 313 minecraft:cobbled_deepslate
fill 471 20 314 471 23 314 minecraft:deepslate_tiles
setblock 472 20 277 minecraft:cobbled_deepslate
fill 472 20 278 472 22 278 minecraft:deepslate_tiles
setblock 472 20 287 minecraft:cobbled_deepslate
setblock 472 20 288 minecraft:deepslate_tiles
setblock 472 20 291 minecraft:deepslate_tiles
setblock 472 20 292 minecraft:cobbled_deepslate
fill 472 20 293 472 23 293 minecraft:deepslate_tiles
setblock 472 20 297 minecraft:cobbled_deepslate
fill 472 20 298 472 23 298 minecraft:deepslate_tiles
setblock 472 20 307 minecraft:cobbled_deepslate
fill 472 20 308 472 20 311 minecraft:deepslate_tiles
setblock 472 20 312 minecraft:cobbled_deepslate
fill 472 20 313 472 23 313 minecraft:deepslate_tiles
setblock 472 20 316 minecraft:deepslate_tiles
setblock 473 20 276 minecraft:cobbled_deepslate
fill 473 20 277 473 23 277 minecraft:deepslate_tiles
fill 473 20 291 477 26 291 minecraft:white_wool
setblock 473 20 292 minecraft:deepslate_tiles
fill 473 20 296 473 34 297 minecraft:white_wool
setblock 473 20 307 minecraft:deepslate_tiles
setblock 473 20 311 minecraft:cobbled_deepslate
fill 473 20 312 473 23 312 minecraft:deepslate_tiles
setblock 473 20 316 minecraft:cobbled_deepslate
fill 474 20 276 474 23 276 minecraft:deepslate_tiles
fill 474 20 297 477 34 297 minecraft:white_wool
setblock 474 20 310 minecraft:cobbled_deepslate
fill 474 20 311 474 21 311 minecraft:deepslate_tiles
setblock 474 20 315 minecraft:cobbled_deepslate
fill 474 20 316 474 23 316 minecraft:deepslate_tiles
setblock 475 20 314 minecraft:cobbled_deepslate
fill 475 20 315 475 23 315 minecraft:deepslate_tiles
setblock 476 20 313 minecraft:cobbled_deepslate
fill 476 20 314 476 22 314 minecraft:deepslate_tiles
fill 477 20 292 478 34 292 minecraft:white_wool
fill 477 20 296 478 34 296 minecraft:white_wool
setblock 477 20 313 minecraft:deepslate_tiles
setblock 478 20 276 minecraft:cobbled_deepslate
fill 478 20 293 478 27 295 minecraft:white_wool
setblock 478 20 316 minecraft:cobbled_deepslate
setblock 479 20 315 minecraft:cobbled_deepslate
fill 479 20 316 479 23 316 minecraft:deepslate_tiles
fill 480 20 315 480 21 315 minecraft:deepslate_tiles
setblock 482 20 315 minecraft:deepslate_tiles
setblock 483 20 316 minecraft:cobbled_deepslate
fill 484 20 316 487 20 316 minecraft:deepslate_tiles
fill 486 20 315 488 20 315 minecraft:deepslate_tiles
setblock 488 20 316 minecraft:cobbled_deepslate
fill 489 20 276 492 20 276 minecraft:deepslate_tiles
setblock 489 20 315 minecraft:cobbled_deepslate
fill 489 20 316 489 23 316 minecraft:deepslate_tiles
setblock 490 20 314 minecraft:cobbled_deepslate
fill 490 20 315 490 23 315 minecraft:deepslate_tiles
setblock 491 20 314 minecraft:deepslate_tiles
setblock 493 20 276 minecraft:cobbled_deepslate
setblock 493 20 316 minecraft:cobbled_deepslate
fill 494 20 276 494 23 276 minecraft:deepslate_tiles
setblock 494 20 315 minecraft:cobbled_deepslate
fill 494 20 316 494 23 316 minecraft:deepslate_tiles
fill 495 20 315 495 21 315 minecraft:deepslate_tiles
setblock 498 20 276 minecraft:cobbled_deepslate
setblock 498 20 316 minecraft:cobbled_deepslate
fill 499 20 276 499 23 276 minecraft:deepslate_tiles
fill 499 20 316 499 21 316 minecraft:deepslate_tiles
fill 500 20 275 501 61 275 minecraft:cobbled_deepslate
fill 500 20 311 500 25 311 minecraft:cobbled_deepslate
fill 500 20 317 500 94 317 minecraft:cobbled_deepslate
fill 501 20 310 501 25 310 minecraft:cobbled_deepslate
fill 501 20 312 501 25 312 minecraft:cobbled_deepslate
setblock 502 20 275 minecraft:redstone_block
setblock 502 20 276 minecraft:deepslate_tiles
fill 502 20 311 502 25 311 minecraft:cobbled_deepslate
setblock 502 20 316 minecraft:deepslate_tiles
fill 503 20 275 503 20 276 minecraft:cobbled_deepslate
setblock 503 20 316 minecraft:cobbled_deepslate
fill 504 20 275 505 26 275 minecraft:cobbled_deepslate
fill 504 20 276 504 23 276 minecraft:deepslate_tiles
fill 504 20 316 504 23 316 minecraft:deepslate_tiles
fill 506 20 292 507 21 293 minecraft:white_wool
fill 506 20 315 506 22 315 minecraft:deepslate_tiles
setblock 507 20 277 minecraft:cobbled_deepslate
setblock 508 20 276 minecraft:cobbled_deepslate
fill 508 20 277 508 23 277 minecraft:deepslate_tiles
setblock 508 20 316 minecraft:cobbled_deepslate
fill 509 20 276 509 23 276 minecraft:deepslate_tiles
setblock 509 20 290 minecraft:cobbled_deepslate
setblock 509 20 291 minecraft:deepslate_tiles
setblock 509 20 315 minecraft:cobbled_deepslate
fill 509 20 316 509 23 316 minecraft:deepslate_tiles
setblock 510 20 279 minecraft:cobbled_deepslate
fill 510 20 280 510 23 280 minecraft:deepslate_tiles
setblock 510 20 284 minecraft:cobbled_deepslate
fill 510 20 285 510 21 285 minecraft:deepslate_tiles
setblock 510 20 289 minecraft:cobbled_deepslate
fill 510 20 290 510 23 290 minecraft:deepslate_tiles
setblock 510 20 293 minecraft:deepslate_tiles
setblock 510 20 294 minecraft:cobbled_deepslate
fill 510 20 295 510 22 296 minecraft:deepslate_tiles
setblock 510 20 309 minecraft:cobbled_deepslate
fill 510 20 310 510 23 310 minecraft:deepslate_tiles
setblock 510 20 314 minecraft:cobbled_deepslate
fill 510 20 315 510 23 315 minecraft:deepslate_tiles
fill 511 20 275 511 94 275 minecraft:cobbled_deepslate
setblock 511 20 278 minecraft:cobbled_deepslate
fill 511 20 279 511 23 279 minecraft:deepslate_tiles
setblock 511 20 283 minecraft:cobbled_deepslate
fill 511 20 284 511 23 284 minecraft:deepslate_tiles
setblock 511 20 288 minecraft:cobbled_deepslate
fill 511 20 289 511 23 289 minecraft:deepslate_tiles
setblock 511 20 293 minecraft:cobbled_deepslate
fill 511 20 294 511 23 294 minecraft:deepslate_tiles
setblock 511 20 298 minecraft:cobbled_deepslate
fill 511 20 299 511 23 299 minecraft:deepslate_tiles
setblock 511 20 308 minecraft:cobbled_deepslate
fill 511 20 309 511 23 309 minecraft:deepslate_tiles
setblock 511 20 313 minecraft:cobbled_deepslate
fill 511 20 314 511 23 314 minecraft:deepslate_tiles
setblock 512 20 298 minecraft:redstone_block
fill 512 20 299 512 61 301 minecraft:cobbled_deepslate
setblock 471 21 277 minecraft:cobbled_deepslate
fill 471 21 278 471 24 278 minecraft:deepslate_tiles
setblock 471 21 282 minecraft:cobbled_deepslate
setblock 471 21 283 minecraft:deepslate_tiles
setblock 471 21 287 minecraft:cobbled_deepslate
fill 471 21 288 471 23 288 minecraft:deepslate_tiles
setblock 471 21 292 minecraft:cobbled_deepslate
fill 471 21 293 471 24 293 minecraft:deepslate_tiles
setblock 471 21 296 minecraft:deepslate_tiles
setblock 471 21 297 minecraft:cobbled_deepslate
fill 471 21 298 471 24 298 minecraft:deepslate_tiles
setblock 471 21 302 minecraft:cobbled_deepslate
fill 471 21 303 471 21 306 minecraft:deepslate_tiles
setblock 471 21 307 minecraft:cobbled_deepslate
fill 471 21 308 471 21 311 minecraft:deepslate_tiles
setblock 471 21 312 minecraft:cobbled_deepslate
fill 471 21 313 471 24 313 minecraft:deepslate_tiles
setblock 472 21 276 minecraft:cobbled_deepslate
fill 472 21 277 472 24 277 minecraft:deepslate_tiles
setblock 472 21 291 minecraft:cobbled_deepslate
fill 472 21 292 472 23 292 minecraft:deepslate_tiles
setblock 472 21 296 minecraft:cobbled_deepslate
fill 472 21 297 472 24 297 minecraft:deepslate_tiles
fill 472 21 299 472 22 299 minecraft:deepslate_tiles
setblock 472 21 306 minecraft:cobbled_deepslate
fill 472 21 307 472 21 310 minecraft:deepslate_tiles
setblock 472 21 311 minecraft:cobbled_deepslate
fill 472 21 312 472 24 312 minecraft:deepslate_tiles
setblock 472 21 316 minecraft:cobbled_deepslate
fill 473 21 276 473 24 276 minecraft:deepslate_tiles
setblock 473 21 278 minecraft:light[level=13]
setblock 473 21 286 minecraft:light[level=13]
fill 473 21 290 477 33 290 minecraft:white_wool
fill 473 21 292 473 34 293 minecraft:white_wool
fill 473 21 298 477 28 298 minecraft:white_wool
setblock 473 21 302 minecraft:light[level=13]
setblock 473 21 310 minecraft:cobbled_deepslate
fill 473 21 311 473 23 311 minecraft:deepslate_tiles
setblock 473 21 315 minecraft:cobbled_deepslate
fill 473 21 316 473 24 316 minecraft:deepslate_tiles
setblock 474 21 314 minecraft:cobbled_deepslate
fill 474 21 315 474 24 315 minecraft:deepslate_tiles
fill 475 21 307 475 26 307 minecraft:black_concrete
setblock 475 21 313 minecraft:cobbled_deepslate
fill 475 21 314 475 23 314 minecraft:deepslate_tiles
setblock 477 21 276 minecraft:cobbled_deepslate
fill 477 21 284 477 38 284 minecraft:white_wool
setblock 477 21 316 minecraft:cobbled_deepslate
fill 478 21 291 478 26 291 minecraft:white_wool
fill 478 21 297 478 33 297 minecraft:white_wool
setblock 478 21 315 minecraft:cobbled_deepslate
fill 478 21 316 478 24 316 minecraft:deepslate_tiles
fill 479 21 292 479 27 296 minecraft:white_wool
fill 479 21 315 479 22 315 minecraft:deepslate_tiles
setblock 481 21 278 minecraft:light[level=13]
setblock 481 21 286 minecraft:light[level=13]
setblock 481 21 294 minecraft:light[level=13]
setblock 481 21 302 minecraft:light[level=13]
setblock 481 21 310 minecraft:light[level=13]
setblock 482 21 316 minecraft:cobbled_deepslate
fill 483 21 316 486 21 316 minecraft:deepslate_tiles
setblock 487 21 315 minecraft:deepslate_tiles
setblock 487 21 316 minecraft:cobbled_deepslate
fill 488 21 276 491 21 276 minecraft:deepslate_tiles
setblock 488 21 315 minecraft:cobbled_deepslate
fill 488 21 316 488 24 316 minecraft:deepslate_tiles
setblock 489 21 278 minecraft:light[level=13]
setblock 489 21 286 minecraft:light[level=13]
setblock 489 21 294 minecraft:light[level=13]
setblock 489 21 302 minecraft:light[level=13]
setblock 489 21 310 minecraft:light[level=13]
fill 489 21 315 489 24 315 minecraft:deepslate_tiles
setblock 492 21 276 minecraft:cobbled_deepslate
setblock 492 21 316 minecraft:cobbled_deepslate
fill 493 21 276 493 23 277 minecraft:deepslate_tiles
setblock 493 21 315 minecraft:cobbled_deepslate
fill 493 21 316 493 24 316 minecraft:deepslate_tiles
fill 494 21 315 494 22 315 minecraft:deepslate_tiles
setblock 497 21 276 minecraft:cobbled_deepslate
setblock 497 21 278 minecraft:light[level=13]
setblock 497 21 286 minecraft:light[level=13]
setblock 497 21 294 minecraft:light[level=13]
setblock 497 21 302 minecraft:light[level=13]
setblock 497 21 310 minecraft:light[level=13]
setblock 497 21 316 minecraft:cobbled_deepslate
fill 498 21 276 498 24 276 minecraft:deepslate_tiles
fill 498 21 316 498 22 316 minecraft:deepslate_tiles
fill 502 21 275 502 21 276 minecraft:cobbled_deepslate
fill 503 21 275 503 80 275 minecraft:cobbled_deepslate
fill 503 21 276 503 24 276 minecraft:deepslate_tiles
fill 503 21 316 503 24 316 minecraft:deepslate_tiles
setblock 505 21 278 minecraft:light[level=13]
setblock 505 21 286 minecraft:light[level=13]
setblock 505 21 294 minecraft:light[level=13]
setblock 505 21 302 minecraft:light[level=13]
setblock 505 21 310 minecraft:light[level=13]
setblock 506 21 277 minecraft:cobbled_deepslate
setblock 507 21 276 minecraft:cobbled_deepslate
fill 507 21 277 507 24 277 minecraft:deepslate_tiles
setblock 507 21 316 minecraft:cobbled_deepslate
fill 508 21 276 508 24 276 minecraft:deepslate_tiles
setblock 508 21 314 minecraft:deepslate_tiles
setblock 508 21 315 minecraft:cobbled_deepslate
fill 508 21 316 508 24 316 minecraft:deepslate_tiles
setblock 509 21 313 minecraft:deepslate_tiles
setblock 509 21 314 minecraft:cobbled_deepslate
fill 509 21 315 509 24 315 minecraft:deepslate_tiles
setblock 510 21 278 minecraft:cobbled_deepslate
fill 510 21 279 510 24 279 minecraft:deepslate_tiles
setblock 510 21 283 minecraft:cobbled_deepslate
setblock 510 21 284 minecraft:deepslate_tiles
setblock 510 21 288 minecraft:cobbled_deepslate
fill 510 21 289 510 23 289 minecraft:deepslate_tiles
setblock 510 21 293 minecraft:cobbled_deepslate
fill 510 21 294 510 24 294 minecraft:deepslate_tiles
setblock 510 21 309 minecraft:deepslate_tiles
setblock 510 21 313 minecraft:cobbled_deepslate
fill 510 21 314 510 24 314 minecraft:deepslate_tiles
setblock 511 21 277 minecraft:cobbled_deepslate
fill 511 21 278 511 24 278 minecraft:deepslate_tiles
setblock 511 21 282 minecraft:cobbled_deepslate
fill 511 21 283 511 24 283 minecraft:deepslate_tiles
setblock 511 21 287 minecraft:cobbled_deepslate
fill 511 21 288 511 24 288 minecraft:deepslate_tiles
fill 511 21 292 512 21 292 minecraft:cobbled_deepslate
fill 511 21 293 511 24 293 minecraft:deepslate_tiles
setblock 511 21 297 minecraft:cobbled_deepslate
fill 511 21 298 511 24 298 minecraft:deepslate_tiles
setblock 511 21 307 minecraft:cobbled_deepslate
fill 511 21 308 511 24 308 minecraft:deepslate_tiles
setblock 511 21 312 minecraft:cobbled_deepslate
fill 511 21 313 511 24 313 minecraft:deepslate_tiles
fill 512 21 293 512 85 293 minecraft:cobbled_deepslate
setblock 512 21 294 minecraft:white_wool
fill 512 21 295 512 94 295 minecraft:cobbled_deepslate
fill 512 21 298 512 92 298 minecraft:cobbled_deepslate
fill 470 22 283 470 43 286 minecraft:cobbled_deepslate
setblock 470 22 287 minecraft:white_wool
fill 470 22 288 470 38 297 minecraft:cobbled_deepslate
setblock 471 22 276 minecraft:cobbled_deepslate
fill 471 22 277 471 25 277 minecraft:deepslate_tiles
setblock 471 22 281 minecraft:cobbled_deepslate
setblock 471 22 287 minecraft:deepslate_tiles
setblock 471 22 291 minecraft:cobbled_deepslate
fill 471 22 292 471 25 292 minecraft:deepslate_tiles
setblock 471 22 296 minecraft:cobbled_deepslate
fill 471 22 297 471 25 297 minecraft:deepslate_tiles
setblock 471 22 301 minecraft:cobbled_deepslate
fill 471 22 302 471 22 305 minecraft:deepslate_tiles
setblock 471 22 306 minecraft:cobbled_deepslate
fill 471 22 307 471 22 310 minecraft:deepslate_tiles
setblock 471 22 311 minecraft:cobbled_deepslate
fill 471 22 312 471 25 312 minecraft:deepslate_tiles
setblock 471 22 315 minecraft:deepslate_tiles
setblock 471 22 316 minecraft:cobbled_deepslate
fill 472 22 276 472 25 276 minecraft:deepslate_tiles
setblock 472 22 290 minecraft:cobbled_deepslate
setblock 472 22 291 minecraft:deepslate_tiles
setblock 472 22 295 minecraft:cobbled_deepslate
fill 472 22 296 472 25 296 minecraft:deepslate_tiles
fill 472 22 306 472 22 309 minecraft:deepslate_tiles
setblock 472 22 310 minecraft:cobbled_deepslate
fill 472 22 311 472 25 311 minecraft:deepslate_tiles
setblock 472 22 315 minecraft:cobbled_deepslate
fill 472 22 316 472 25 316 minecraft:deepslate_tiles
setblock 473 22 309 minecraft:cobbled_deepslate
fill 473 22 310 473 23 310 minecraft:deepslate_tiles
setblock 473 22 314 minecraft:cobbled_deepslate
fill 473 22 315 473 25 315 minecraft:deepslate_tiles
fill 474 22 289 476 32 289 minecraft:white_wool
fill 474 22 299 476 26 299 minecraft:white_wool
fill 474 22 312 474 28 312 minecraft:black_concrete
setblock 474 22 313 minecraft:cobbled_deepslate
fill 474 22 314 474 24 314 minecraft:deepslate_tiles
setblock 476 22 276 minecraft:cobbled_deepslate
setblock 476 22 316 minecraft:cobbled_deepslate
setblock 477 22 315 minecraft:cobbled_deepslate
fill 477 22 316 477 25 316 minecraft:deepslate_tiles
fill 478 22 290 478 32 290 minecraft:white_wool
fill 478 22 298 478 32 298 minecraft:white_wool
fill 478 22 315 478 23 315 minecraft:deepslate_tiles
fill 479 22 291 479 26 291 minecraft:white_wool
fill 479 22 297 479 32 297 minecraft:white_wool
fill 480 22 293 480 27 295 minecraft:white_wool
setblock 481 22 316 minecraft:cobbled_deepslate
fill 482 22 316 485 22 316 minecraft:deepslate_tiles
fill 484 22 308 484 23 308 minecraft:white_wool
setblock 486 22 316 minecraft:cobbled_deepslate
setblock 487 22 315 minecraft:cobbled_deepslate
fill 487 22 316 487 25 316 minecraft:deepslate_tiles
fill 488 22 276 490 22 276 minecraft:deepslate_tiles
fill 488 22 315 488 24 315 minecraft:deepslate_tiles
setblock 491 22 276 minecraft:cobbled_deepslate
setblock 491 22 316 minecraft:cobbled_deepslate
fill 492 22 276 492 25 276 minecraft:deepslate_tiles
setblock 492 22 315 minecraft:cobbled_deepslate
fill 492 22 316 492 25 316 minecraft:deepslate_tiles
fill 493 22 315 493 23 315 minecraft:deepslate_tiles
setblock 496 22 276 minecraft:cobbled_deepslate
setblock 496 22 316 minecraft:cobbled_deepslate
fill 497 22 276 497 25 276 minecraft:deepslate_tiles
fill 497 22 316 497 23 316 minecraft:deepslate_tiles
fill 500 22 310 500 25 310 minecraft:cobbled_deepslate
fill 500 22 312 500 25 312 minecraft:cobbled_deepslate
setblock 501 22 276 minecraft:cobbled_deepslate
fill 502 22 275 502 95 275 minecraft:cobbled_deepslate
fill 502 22 276 502 25 276 minecraft:deepslate_tiles
fill 502 22 310 502 25 310 minecraft:cobbled_deepslate
fill 502 22 312 502 25 312 minecraft:cobbled_deepslate
setblock 506 22 276 minecraft:cobbled_deepslate
fill 506 22 277 506 25 277 minecraft:deepslate_tiles
fill 506 22 316 506 22 317 minecraft:cobbled_deepslate
fill 507 22 276 507 25 276 minecraft:deepslate_tiles
setblock 507 22 315 minecraft:cobbled_deepslate
fill 507 22 316 507 25 316 minecraft:deepslate_tiles
fill 507 22 317 508 73 317 minecraft:cobbled_deepslate
setblock 508 22 314 minecraft:cobbled_deepslate
fill 508 22 315 508 25 315 minecraft:deepslate_tiles
setblock 509 22 313 minecraft:cobbled_deepslate
fill 509 22 314 509 25 314 minecraft:deepslate_tiles
setblock 509 22 317 minecraft:redstone_block
setblock 510 22 277 minecraft:cobbled_deepslate
fill 510 22 278 510 25 278 minecraft:deepslate_tiles
setblock 510 22 287 minecraft:cobbled_deepslate
setblock 510 22 288 minecraft:deepslate_tiles
setblock 510 22 292 minecraft:cobbled_deepslate
fill 510 22 293 510 25 293 minecraft:deepslate_tiles
setblock 510 22 312 minecraft:cobbled_deepslate
fill 510 22 313 510 25 313 minecraft:deepslate_tiles
fill 510 22 317 510 94 317 minecraft:cobbled_deepslate
setblock 511 22 276 minecraft:cobbled_deepslate
fill 511 22 277 511 25 277 minecraft:deepslate_tiles
setblock 511 22 281 minecraft:cobbled_deepslate
fill 511 22 282 511 25 282 minecraft:deepslate_tiles
setblock 511 22 286 minecraft:cobbled_deepslate
fill 511 22 287 511 24 287 minecraft:deepslate_tiles
setblock 511 22 291 minecraft:cobbled_deepslate
fill 511 22 292 511 25 292 minecraft:deepslate_tiles
setblock 511 22 296 minecraft:cobbled_deepslate
fill 511 22 297 511 25 297 minecraft:deepslate_tiles
setblock 511 22 300 minecraft:deepslate_tiles
fill 511 22 307 511 23 307 minecraft:deepslate_tiles
setblock 511 22 311 minecraft:cobbled_deepslate
fill 511 22 312 511 25 312 minecraft:deepslate_tiles
setblock 511 22 316 minecraft:cobbled_deepslate
fill 512 22 292 512 94 292 minecraft:cobbled_deepslate
fill 512 22 294 512 94 294 minecraft:cobbled_deepslate
fill 512 22 307 512 56 310 minecraft:cobbled_deepslate
setblock 512 22 311 minecraft:white_wool
fill 512 22 312 512 73 315 minecraft:cobbled_deepslate
fill 470 23 287 470 91 287 minecraft:cobbled_deepslate
setblock 470 23 310 minecraft:redstone_block
setblock 470 23 315 minecraft:white_wool
fill 471 23 276 471 26 276 minecraft:deepslate_tiles
setblock 471 23 280 minecraft:cobbled_deepslate
setblock 471 23 290 minecraft:cobbled_deepslate
fill 471 23 291 471 26 291 minecraft:deepslate_tiles
setblock 471 23 295 minecraft:cobbled_deepslate
fill 471 23 296 471 26 296 minecraft:deepslate_tiles
setblock 471 23 300 minecraft:cobbled_deepslate
fill 471 23 301 471 23 304 minecraft:deepslate_tiles
setblock 471 23 305 minecraft:cobbled_deepslate
fill 471 23 306 471 23 309 minecraft:deepslate_tiles
setblock 471 23 310 minecraft:cobbled_deepslate
fill 471 23 311 471 26 311 minecraft:deepslate_tiles
setblock 471 23 315 minecraft:cobbled_deepslate
fill 471 23 316 471 26 316 minecraft:deepslate_tiles
fill 472 23 290 472 26 291 minecraft:white_wool
setblock 472 23 294 minecraft:cobbled_deepslate
fill 472 23 295 472 26 295 minecraft:deepslate_tiles
setblock 472 23 299 minecraft:cobbled_deepslate
fill 472 23 300 472 26 300 minecraft:deepslate_tiles
fill 472 23 307 472 23 308 minecraft:deepslate_tiles
setblock 472 23 309 minecraft:cobbled_deepslate
fill 472 23 310 472 26 310 minecraft:deepslate_tiles
setblock 472 23 314 minecraft:cobbled_deepslate
fill 472 23 315 472 26 315 minecraft:deepslate_tiles
fill 473 23 289 473 31 289 minecraft:white_wool
fill 473 23 299 473 26 299 minecraft:white_wool
setblock 473 23 313 minecraft:cobbled_deepslate
fill 473 23 314 473 25 314 minecraft:deepslate_tiles
setblock 475 23 276 minecraft:cobbled_deepslate
setblock 475 23 316 minecraft:cobbled_deepslate
setblock 476 23 276 minecraft:deepslate_tiles
setblock 476 23 315 minecraft:cobbled_deepslate
fill 476 23 316 476 26 316 minecraft:deepslate_tiles
fill 477 23 289 477 31 289 minecraft:white_wool
fill 477 23 299 477 26 299 minecraft:white_wool
fill 477 23 315 477 24 315 minecraft:deepslate_tiles
fill 479 23 290 479 31 290 minecraft:white_wool
fill 479 23 298 479 31 298 minecraft:white_wool
fill 480 23 292 480 31 292 minecraft:white_wool
fill 480 23 296 480 31 296 minecraft:white_wool
setblock 480 23 316 minecraft:cobbled_deepslate
fill 481 23 316 484 23 316 minecraft:deepslate_tiles
setblock 485 23 316 minecraft:cobbled_deepslate
fill 486 23 316 486 26 316 minecraft:deepslate_tiles
fill 487 23 276 489 23 276 minecraft:deepslate_tiles
setblock 490 23 276 minecraft:cobbled_deepslate
setblock 490 23 316 minecraft:cobbled_deepslate
fill 491 23 276 491 26 276 minecraft:deepslate_tiles
setblock 491 23 315 minecraft:cobbled_deepslate
fill 491 23 316 491 26 316 minecraft:deepslate_tiles
fill 492 23 277 492 24 277 minecraft:deepslate_tiles
setblock 492 23 315 minecraft:deepslate_tiles
setblock 495 23 276 minecraft:cobbled_deepslate
setblock 495 23 316 minecraft:cobbled_deepslate
fill 496 23 276 496 26 276 minecraft:deepslate_tiles
fill 496 23 312 496 33 312 minecraft:black_concrete
fill 496 23 316 496 24 316 minecraft:deepslate_tiles
setblock 500 23 276 minecraft:cobbled_deepslate
fill 501 23 276 501 26 276 minecraft:deepslate_tiles
setblock 505 23 276 minecraft:cobbled_deepslate
fill 505 23 277 505 26 277 minecraft:deepslate_tiles
setblock 505 23 316 minecraft:cobbled_deepslate
fill 506 23 276 506 26 276 minecraft:deepslate_tiles
setblock 506 23 315 minecraft:cobbled_deepslate
fill 506 23 316 506 26 316 minecraft:deepslate_tiles
fill 506 23 317 506 92 317 minecraft:cobbled_deepslate
fill 507 23 315 507 26 315 minecraft:deepslate_tiles
setblock 509 23 277 minecraft:cobbled_deepslate
fill 509 23 278 509 26 278 minecraft:deepslate_tiles
setblock 509 23 313 minecraft:deepslate_tiles
fill 509 23 317 509 94 317 minecraft:cobbled_deepslate
setblock 510 23 276 minecraft:cobbled_deepslate
fill 510 23 277 510 26 277 minecraft:deepslate_tiles
setblock 510 23 281 minecraft:cobbled_deepslate
setblock 510 23 291 minecraft:cobbled_deepslate
fill 510 23 292 510 24 292 minecraft:deepslate_tiles
setblock 510 23 295 minecraft:deepslate_tiles
setblock 510 23 296 minecraft:cobbled_deepslate
setblock 510 23 311 minecraft:cobbled_deepslate
fill 510 23 312 510 26 312 minecraft:deepslate_tiles
setblock 510 23 316 minecraft:cobbled_deepslate
fill 511 23 276 511 26 276 minecraft:deepslate_tiles
setblock 511 23 280 minecraft:cobbled_deepslate
fill 511 23 281 511 26 281 minecraft:deepslate_tiles
setblock 511 23 285 minecraft:cobbled_deepslate
fill 511 23 286 511 24 286 minecraft:deepslate_tiles
setblock 511 23 290 minecraft:cobbled_deepslate
fill 511 23 291 511 26 291 minecraft:deepslate_tiles
setblock 511 23 295 minecraft:cobbled_deepslate
fill 511 23 296 511 26 296 minecraft:deepslate_tiles
setblock 511 23 300 minecraft:cobbled_deepslate
setblock 511 23 310 minecraft:cobbled_deepslate
fill 511 23 311 511 26 311 minecraft:deepslate_tiles
setblock 511 23 315 minecraft:cobbled_deepslate
fill 511 23 316 511 26 316 minecraft:deepslate_tiles
fill 512 23 311 512 94 311 minecraft:cobbled_deepslate
fill 470 24 310 470 94 310 minecraft:cobbled_deepslate
fill 470 24 315 470 90 315 minecraft:cobbled_deepslate
setblock 471 24 279 minecraft:cobbled_deepslate
fill 471 24 280 471 27 280 minecraft:deepslate_tiles
setblock 471 24 290 minecraft:deepslate_tiles
setblock 471 24 294 minecraft:cobbled_deepslate
fill 471 24 295 471 27 295 minecraft:deepslate_tiles
setblock 471 24 299 minecraft:cobbled_deepslate
fill 471 24 300 471 24 303 minecraft:deepslate_tiles
setblock 471 24 304 minecraft:cobbled_deepslate
fill 471 24 305 471 24 308 minecraft:deepslate_tiles
setblock 471 24 309 minecraft:cobbled_deepslate
fill 471 24 310 471 27 310 minecraft:deepslate_tiles
setblock 471 24 314 minecraft:cobbled_deepslate
fill 471 24 315 471 27 315 minecraft:deepslate_tiles
fill 472 24 289 472 30 289 minecraft:white_wool
fill 472 24 292 472 34 292 minecraft:white_wool
setblock 472 24 293 minecraft:cobbled_deepslate
fill 472 24 294 472 27 294 minecraft:deepslate_tiles
setblock 472 24 298 minecraft:cobbled_deepslate
fill 472 24 299 472 27 299 minecraft:deepslate_tiles
setblock 472 24 308 minecraft:cobbled_deepslate
fill 472 24 309 472 25 309 minecraft:deepslate_tiles
setblock 472 24 313 minecraft:cobbled_deepslate
fill 472 24 314 472 27 314 minecraft:deepslate_tiles
setblock 473 24 312 minecraft:cobbled_deepslate
fill 473 24 313 473 25 313 minecraft:deepslate_tiles
setblock 474 24 276 minecraft:cobbled_deepslate
setblock 474 24 288 minecraft:crying_obsidian
setblock 474 24 300 minecraft:crying_obsidian
setblock 474 24 316 minecraft:cobbled_deepslate
fill 475 24 276 475 27 276 minecraft:deepslate_tiles
fill 475 24 288 475 30 288 minecraft:white_wool
fill 475 24 300 475 30 300 minecraft:white_wool
setblock 475 24 315 minecraft:cobbled_deepslate
fill 475 24 316 475 27 316 minecraft:deepslate_tiles
setblock 476 24 288 minecraft:crying_obsidian
setblock 476 24 300 minecraft:crying_obsidian
fill 476 24 315 476 25 315 minecraft:deepslate_tiles
fill 478 24 289 478 30 289 minecraft:white_wool
fill 478 24 299 478 26 299 minecraft:white_wool
setblock 479 24 316 minecraft:cobbled_deepslate
fill 480 24 291 480 26 291 minecraft:white_wool
fill 480 24 297 480 30 297 minecraft:white_wool
setblock 480 24 316 minecraft:deepslate_tiles
setblock 481 24 293 minecraft:crying_obsidian
fill 481 24 294 481 30 294 minecraft:white_wool
setblock 481 24 295 minecraft:crying_obsidian
setblock 483 24 316 minecraft:deepslate_tiles
setblock 484 24 316 minecraft:cobbled_deepslate
fill 485 24 316 485 27 316 minecraft:deepslate_tiles
fill 486 24 276 488 24 276 minecraft:deepslate_tiles
setblock 489 24 276 minecraft:cobbled_deepslate
setblock 489 24 316 minecraft:cobbled_deepslate
fill 490 24 276 490 26 277 minecraft:deepslate_tiles
setblock 490 24 315 minecraft:cobbled_deepslate
fill 490 24 316 490 27 316 minecraft:deepslate_tiles
fill 491 24 277 491 25 277 minecraft:deepslate_tiles
setblock 491 24 315 minecraft:deepslate_tiles
setblock 493 24 276 minecraft:deepslate_tiles
setblock 493 24 277 minecraft:cobbled_deepslate
setblock 494 24 276 minecraft:cobbled_deepslate
setblock 494 24 316 minecraft:cobbled_deepslate
fill 495 24 276 495 27 276 minecraft:deepslate_tiles
fill 495 24 316 495 25 316 minecraft:deepslate_tiles
setblock 499 24 276 minecraft:cobbled_deepslate
fill 500 24 276 500 27 276 minecraft:deepslate_tiles
setblock 504 24 276 minecraft:cobbled_deepslate
fill 504 24 277 504 27 277 minecraft:deepslate_tiles
setblock 504 24 316 minecraft:cobbled_deepslate
fill 505 24 276 505 27 276 minecraft:deepslate_tiles
fill 505 24 316 505 27 316 minecraft:deepslate_tiles
fill 506 24 315 506 27 315 minecraft:deepslate_tiles
setblock 508 24 277 minecraft:cobbled_deepslate
fill 508 24 278 508 27 278 minecraft:deepslate_tiles
setblock 509 24 276 minecraft:cobbled_deepslate
fill 509 24 277 509 27 277 minecraft:deepslate_tiles
setblock 509 24 316 minecraft:cobbled_deepslate
fill 510 24 276 510 27 276 minecraft:deepslate_tiles
setblock 510 24 280 minecraft:cobbled_deepslate
fill 510 24 281 510 27 281 minecraft:deepslate_tiles
setblock 510 24 295 minecraft:cobbled_deepslate
fill 510 24 296 510 27 296 minecraft:deepslate_tiles
fill 510 24 311 510 27 311 minecraft:deepslate_tiles
setblock 510 24 315 minecraft:cobbled_deepslate
fill 510 24 316 510 27 316 minecraft:deepslate_tiles
setblock 511 24 279 minecraft:cobbled_deepslate
fill 511 24 280 511 27 280 minecraft:deepslate_tiles
setblock 511 24 284 minecraft:cobbled_deepslate
setblock 511 24 285 minecraft:deepslate_tiles
setblock 511 24 289 minecraft:cobbled_deepslate
fill 511 24 290 511 26 290 minecraft:deepslate_tiles
setblock 511 24 294 minecraft:cobbled_deepslate
fill 511 24 295 511 27 295 minecraft:deepslate_tiles
setblock 511 24 299 minecraft:cobbled_deepslate
fill 511 24 300 511 27 300 minecraft:deepslate_tiles
setblock 511 24 309 minecraft:cobbled_deepslate
fill 511 24 310 511 27 310 minecraft:deepslate_tiles
setblock 511 24 314 minecraft:cobbled_deepslate
fill 511 24 315 511 27 315 minecraft:deepslate_tiles
setblock 471 25 278 minecraft:cobbled_deepslate
fill 471 25 279 471 28 279 minecraft:deepslate_tiles
fill 471 25 290 471 31 290 minecraft:white_wool
setblock 471 25 293 minecraft:cobbled_deepslate
fill 471 25 294 471 28 294 minecraft:deepslate_tiles
setblock 471 25 298 minecraft:cobbled_deepslate
fill 471 25 299 471 25 302 minecraft:deepslate_tiles
setblock 471 25 303 minecraft:cobbled_deepslate
fill 471 25 304 471 25 307 minecraft:deepslate_tiles
setblock 471 25 308 minecraft:cobbled_deepslate
fill 471 25 309 471 28 309 minecraft:deepslate_tiles
setblock 471 25 313 minecraft:cobbled_deepslate
fill 471 25 314 471 28 314 minecraft:deepslate_tiles
setblock 472 25 277 minecraft:cobbled_deepslate
fill 472 25 293 472 34 293 minecraft:white_wool
setblock 472 25 297 minecraft:cobbled_deepslate
fill 472 25 298 472 28 298 minecraft:deepslate_tiles
setblock 472 25 301 minecraft:deepslate_tiles
setblock 472 25 312 minecraft:cobbled_deepslate
fill 472 25 313 472 28 313 minecraft:deepslate_tiles
setblock 473 25 276 minecraft:cobbled_deepslate
setblock 473 25 278 minecraft:light[level=12]
setblock 473 25 285 minecraft:light[level=12]
setblock 473 25 288 minecraft:crying_obsidian
setblock 473 25 300 minecraft:crying_obsidian
setblock 473 25 306 minecraft:light[level=12]
setblock 473 25 316 minecraft:cobbled_deepslate
fill 474 25 276 474 28 276 minecraft:deepslate_tiles
fill 474 25 288 474 30 288 minecraft:white_wool
fill 474 25 300 474 30 300 minecraft:white_wool
fill 474 25 307 474 26 307 minecraft:black_concrete
setblock 474 25 315 minecraft:cobbled_deepslate
fill 474 25 316 474 28 316 minecraft:deepslate_tiles
fill 475 25 306 475 26 306 minecraft:black_concrete
fill 475 25 308 475 26 308 minecraft:black_concrete
fill 475 25 315 475 26 315 minecraft:deepslate_tiles
fill 476 25 288 476 29 288 minecraft:white_wool
fill 476 25 300 476 29 300 minecraft:white_wool
fill 476 25 307 476 26 307 minecraft:black_concrete
setblock 477 25 288 minecraft:crying_obsidian
setblock 477 25 300 minecraft:crying_obsidian
setblock 478 25 316 minecraft:cobbled_deepslate
setblock 479 25 316 minecraft:deepslate_tiles
setblock 480 25 278 minecraft:light[level=12]
setblock 480 25 285 minecraft:light[level=12]
setblock 480 25 299 minecraft:light[level=12]
setblock 480 25 306 minecraft:light[level=12]
setblock 480 25 313 minecraft:light[level=12]
setblock 481 25 292 minecraft:crying_obsidian
fill 481 25 293 481 29 293 minecraft:white_wool
fill 481 25 295 481 27 295 minecraft:white_wool
setblock 481 25 296 minecraft:crying_obsidian
fill 484 25 316 484 28 316 minecraft:deepslate_tiles
fill 486 25 276 487 25 276 minecraft:deepslate_tiles
setblock 487 25 278 minecraft:light[level=12]
setblock 487 25 285 minecraft:light[level=12]
setblock 487 25 292 minecraft:light[level=12]
setblock 487 25 299 minecraft:light[level=12]
setblock 487 25 306 minecraft:light[level=12]
setblock 487 25 313 minecraft:light[level=12]
setblock 488 25 276 minecraft:cobbled_deepslate
setblock 488 25 316 minecraft:cobbled_deepslate
fill 489 25 276 489 27 277 minecraft:deepslate_tiles
fill 489 25 316 489 28 316 minecraft:deepslate_tiles
setblock 492 25 277 minecraft:cobbled_deepslate
setblock 493 25 276 minecraft:cobbled_deepslate
fill 493 25 277 494 27 277 minecraft:deepslate_tiles
setblock 493 25 316 minecraft:cobbled_deepslate
fill 494 25 276 494 28 276 minecraft:deepslate_tiles
setblock 494 25 278 minecraft:light[level=12]
setblock 494 25 285 minecraft:light[level=12]
setblock 494 25 292 minecraft:light[level=12]
setblock 494 25 299 minecraft:light[level=12]
setblock 494 25 306 minecraft:light[level=12]
setblock 494 25 313 minecraft:light[level=12]
fill 494 25 316 494 27 316 minecraft:deepslate_tiles
setblock 498 25 276 minecraft:cobbled_deepslate
fill 499 25 276 499 28 276 minecraft:deepslate_tiles
setblock 499 25 311 minecraft:cobbled_deepslate
setblock 501 25 278 minecraft:light[level=12]
setblock 501 25 285 minecraft:light[level=12]
setblock 501 25 292 minecraft:light[level=12]
setblock 501 25 299 minecraft:light[level=12]
setblock 501 25 306 minecraft:light[level=12]
setblock 501 25 309 minecraft:cobbled_deepslate
setblock 501 25 313 minecraft:cobbled_deepslate
setblock 502 25 316 minecraft:deepslate_tiles
setblock 503 25 276 minecraft:cobbled_deepslate
fill 503 25 277 503 28 277 minecraft:deepslate_tiles
setblock 503 25 311 minecraft:cobbled_deepslate
setblock 503 25 316 minecraft:cobbled_deepslate
fill 504 25 276 504 28 276 minecraft:deepslate_tiles
fill 504 25 316 504 28 316 minecraft:deepslate_tiles
fill 505 25 315 505 28 315 minecraft:deepslate_tiles
setblock 507 25 277 minecraft:cobbled_deepslate
fill 507 25 278 507 28 278 minecraft:deepslate_tiles
setblock 508 25 276 minecraft:cobbled_deepslate
fill 508 25 277 508 28 277 minecraft:deepslate_tiles
setblock 508 25 285 minecraft:light[level=12]
setblock 508 25 292 minecraft:light[level=12]
setblock 508 25 299 minecraft:light[level=12]
setblock 508 25 306 minecraft:light[level=12]
setblock 508 25 313 minecraft:light[level=12]
setblock 508 25 316 minecraft:cobbled_deepslate
fill 509 25 276 509 28 276 minecraft:deepslate_tiles
setblock 509 25 279 minecraft:deepslate_tiles
setblock 509 25 315 minecraft:cobbled_deepslate
fill 509 25 316 509 28 316 minecraft:deepslate_tiles
setblock 510 25 279 minecraft:cobbled_deepslate
fill 510 25 280 510 28 280 minecraft:deepslate_tiles
setblock 510 25 294 minecraft:cobbled_deepslate
fill 510 25 295 510 28 295 minecraft:deepslate_tiles
fill 510 25 297 510 26 297 minecraft:deepslate_tiles
setblock 510 25 314 minecraft:cobbled_deepslate
fill 510 25 315 510 28 315 minecraft:deepslate_tiles
setblock 511 25 278 minecraft:cobbled_deepslate
fill 511 25 279 511 28 279 minecraft:deepslate_tiles
setblock 511 25 283 minecraft:cobbled_deepslate
setblock 511 25 284 minecraft:deepslate_tiles
setblock 511 25 289 minecraft:deepslate_tiles
setblock 511 25 293 minecraft:cobbled_deepslate
fill 511 25 294 511 28 294 minecraft:deepslate_tiles
setblock 511 25 298 minecraft:cobbled_deepslate
fill 511 25 299 511 28 299 minecraft:deepslate_tiles
fill 511 25 301 511 26 301 minecraft:deepslate_tiles
setblock 511 25 308 minecraft:cobbled_deepslate
fill 511 25 309 511 28 309 minecraft:deepslate_tiles
setblock 511 25 313 minecraft:cobbled_deepslate
fill 511 25 314 511 28 314 minecraft:deepslate_tiles
setblock 471 26 277 minecraft:cobbled_deepslate
fill 471 26 278 471 29 278 minecraft:deepslate_tiles
fill 471 26 289 471 28 289 minecraft:crying_obsidian
setblock 471 26 292 minecraft:cobbled_deepslate
fill 471 26 293 471 29 293 minecraft:deepslate_tiles
setblock 471 26 297 minecraft:cobbled_deepslate
fill 471 26 298 471 26 301 minecraft:deepslate_tiles
setblock 471 26 302 minecraft:cobbled_deepslate
fill 471 26 303 471 26 306 minecraft:deepslate_tiles
setblock 471 26 307 minecraft:cobbled_deepslate
fill 471 26 308 471 29 308 minecraft:deepslate_tiles
setblock 471 26 312 minecraft:cobbled_deepslate
fill 471 26 313 471 29 313 minecraft:deepslate_tiles
setblock 472 26 276 minecraft:cobbled_deepslate
fill 472 26 277 472 29 277 minecraft:deepslate_tiles
setblock 472 26 296 minecraft:cobbled_deepslate
fill 472 26 297 472 29 297 minecraft:deepslate_tiles
setblock 472 26 301 minecraft:cobbled_deepslate
fill 472 26 302 472 29 302 minecraft:deepslate_tiles
setblock 472 26 311 minecraft:cobbled_deepslate
fill 472 26 312 472 29 312 minecraft:deepslate_tiles
setblock 472 26 316 minecraft:cobbled_deepslate
fill 473 26 276 473 29 276 minecraft:deepslate_tiles
fill 473 26 288 473 28 288 minecraft:white_wool
fill 473 26 300 473 28 300 minecraft:white_wool
fill 473 26 312 473 28 312 minecraft:black_concrete
setblock 473 26 315 minecraft:cobbled_deepslate
fill 473 26 316 473 29 316 minecraft:deepslate_tiles
fill 474 26 311 474 27 311 minecraft:black_concrete
fill 474 26 313 474 28 313 minecraft:black_concrete
fill 474 26 315 474 28 315 minecraft:deepslate_tiles
fill 475 26 312 475 28 312 minecraft:black_concrete
fill 477 26 288 477 28 288 minecraft:white_wool
fill 477 26 300 477 28 300 minecraft:white_wool
setblock 477 26 316 minecraft:cobbled_deepslate
setblock 478 26 316 minecraft:deepslate_tiles
fill 479 26 289 479 28 289 minecraft:crying_obsidian
setblock 479 26 299 minecraft:crying_obsidian
fill 480 26 290 480 28 290 minecraft:crying_obsidian
fill 480 26 298 480 28 298 minecraft:crying_obsidian
fill 481 26 292 481 28 292 minecraft:white_wool
fill 481 26 296 481 28 296 minecraft:white_wool
fill 483 26 316 483 29 316 minecraft:deepslate_tiles
fill 485 26 276 486 26 276 minecraft:deepslate_tiles
setblock 487 26 276 minecraft:cobbled_deepslate
setblock 487 26 316 minecraft:cobbled_deepslate
fill 488 26 276 488 28 277 minecraft:deepslate_tiles
fill 488 26 316 488 29 316 minecraft:deepslate_tiles
setblock 491 26 277 minecraft:cobbled_deepslate
setblock 492 26 276 minecraft:cobbled_deepslate
fill 492 26 277 492 29 277 minecraft:deepslate_tiles
setblock 492 26 316 minecraft:cobbled_deepslate
fill 493 26 276 493 29 276 minecraft:deepslate_tiles
fill 493 26 316 493 29 316 minecraft:deepslate_tiles
setblock 497 26 276 minecraft:cobbled_deepslate
fill 498 26 276 498 29 276 minecraft:deepslate_tiles
fill 501 26 291 510 26 291 minecraft:cobbled_deepslate
setblock 502 26 276 minecraft:cobbled_deepslate
fill 502 26 277 502 29 277 minecraft:deepslate_tiles
setblock 502 26 316 minecraft:cobbled_deepslate
fill 503 26 276 503 29 276 minecraft:deepslate_tiles
fill 503 26 316 503 29 316 minecraft:deepslate_tiles
setblock 506 26 277 minecraft:cobbled_deepslate
fill 506 26 278 506 29 278 minecraft:deepslate_tiles
setblock 507 26 276 minecraft:cobbled_deepslate
fill 507 26 277 507 29 277 minecraft:deepslate_tiles
setblock 507 26 316 minecraft:cobbled_deepslate
fill 508 26 276 508 29 276 minecraft:deepslate_tiles
setblock 508 26 314 minecraft:deepslate_tiles
setblock 508 26 315 minecraft:cobbled_deepslate
fill 508 26 316 508 29 316 minecraft:deepslate_tiles
setblock 509 26 279 minecraft:cobbled_deepslate
setblock 509 26 314 minecraft:cobbled_deepslate
fill 509 26 315 509 29 315 minecraft:deepslate_tiles
setblock 510 26 278 minecraft:cobbled_deepslate
fill 510 26 279 510 29 279 minecraft:deepslate_tiles
setblock 510 26 294 minecraft:deepslate_tiles
setblock 510 26 298 minecraft:cobbled_deepslate
setblock 510 26 313 minecraft:cobbled_deepslate
fill 510 26 314 510 29 314 minecraft:deepslate_tiles
setblock 511 26 277 minecraft:cobbled_deepslate
fill 511 26 278 511 29 278 minecraft:deepslate_tiles
setblock 511 26 282 minecraft:cobbled_deepslate
fill 511 26 283 511 29 283 minecraft:deepslate_tiles
setblock 511 26 292 minecraft:cobbled_deepslate
fill 511 26 293 511 29 293 minecraft:deepslate_tiles
setblock 511 26 297 minecraft:cobbled_deepslate
fill 511 26 298 511 29 298 minecraft:deepslate_tiles
setblock 511 26 302 minecraft:cobbled_deepslate
fill 511 26 303 511 29 303 minecraft:deepslate_tiles
fill 511 26 308 511 29 308 minecraft:deepslate_tiles
setblock 511 26 312 minecraft:cobbled_deepslate
fill 511 26 313 511 29 313 minecraft:deepslate_tiles
setblock 471 27 276 minecraft:cobbled_deepslate
fill 471 27 277 471 30 277 minecraft:deepslate_tiles
setblock 471 27 281 minecraft:cobbled_deepslate
fill 471 27 283 472 28 283 minecraft:cobbled_deepslate
fill 471 27 287 485 28 287 minecraft:cobbled_deepslate
fill 471 27 291 486 27 291 minecraft:cobbled_deepslate
fill 471 27 292 471 30 292 minecraft:deepslate_tiles
setblock 471 27 296 minecraft:cobbled_deepslate
fill 471 27 297 471 27 300 minecraft:deepslate_tiles
setblock 471 27 301 minecraft:cobbled_deepslate
fill 471 27 302 471 27 305 minecraft:deepslate_tiles
setblock 471 27 306 minecraft:cobbled_deepslate
fill 471 27 307 471 30 307 minecraft:deepslate_tiles
setblock 471 27 311 minecraft:cobbled_deepslate
fill 471 27 312 471 30 312 minecraft:deepslate_tiles
setblock 471 27 316 minecraft:cobbled_deepslate
fill 472 27 276 472 30 276 minecraft:deepslate_tiles
fill 472 27 279 473 28 279 minecraft:cobbled_deepslate
fill 472 27 290 472 32 290 minecraft:white_wool
fill 472 27 295 473 27 295 minecraft:cobbled_deepslate
fill 472 27 296 472 30 296 minecraft:deepslate_tiles
setblock 472 27 300 minecraft:cobbled_deepslate
fill 472 27 301 472 30 301 minecraft:deepslate_tiles
fill 472 27 303 472 27 304 minecraft:deepslate_tiles
fill 472 27 307 473 28 307 minecraft:cobbled_deepslate
fill 472 27 311 472 28 311 minecraft:deepslate_tiles
setblock 472 27 315 minecraft:cobbled_deepslate
fill 472 27 316 472 30 316 minecraft:deepslate_tiles
fill 473 27 294 477 35 294 minecraft:white_wool
fill 473 27 299 509 27 299 minecraft:cobbled_deepslate
fill 473 27 311 473 28 311 minecraft:cobbled_deepslate
fill 473 27 315 473 29 315 minecraft:deepslate_tiles
fill 474 27 295 477 27 295 minecraft:white_wool
setblock 476 27 316 minecraft:cobbled_deepslate
fill 477 27 316 477 28 316 minecraft:deepslate_tiles
fill 483 27 276 485 27 276 minecraft:deepslate_tiles
setblock 486 27 276 minecraft:cobbled_deepslate
fill 486 27 277 487 29 277 minecraft:deepslate_tiles
setblock 486 27 316 minecraft:cobbled_deepslate
fill 487 27 276 487 30 276 minecraft:deepslate_tiles
fill 487 27 316 487 30 316 minecraft:deepslate_tiles
setblock 490 27 276 minecraft:deepslate_tiles
setblock 490 27 277 minecraft:cobbled_deepslate
setblock 491 27 276 minecraft:cobbled_deepslate
fill 491 27 277 491 30 277 minecraft:deepslate_tiles
setblock 491 27 316 minecraft:cobbled_deepslate
fill 492 27 276 492 30 276 minecraft:deepslate_tiles
fill 492 27 316 492 30 316 minecraft:deepslate_tiles
fill 494 27 291 503 27 291 minecraft:cobbled_deepslate
setblock 495 27 277 minecraft:cobbled_deepslate
setblock 496 27 276 minecraft:cobbled_deepslate
fill 496 27 277 496 30 277 minecraft:deepslate_tiles
fill 497 27 276 497 30 276 minecraft:deepslate_tiles
setblock 500 27 277 minecraft:cobbled_deepslate
setblock 501 27 276 minecraft:cobbled_deepslate
fill 501 27 277 501 30 277 minecraft:deepslate_tiles
setblock 501 27 316 minecraft:cobbled_deepslate
fill 502 27 276 502 30 276 minecraft:deepslate_tiles
fill 502 27 316 502 30 316 minecraft:deepslate_tiles
setblock 504 27 275 minecraft:redstone_block
setblock 504 27 278 minecraft:cobbled_deepslate
fill 505 27 275 505 94 275 minecraft:cobbled_deepslate
setblock 505 27 277 minecraft:cobbled_deepslate
fill 505 27 278 505 30 278 minecraft:deepslate_tiles
setblock 506 27 275 minecraft:white_wool
setblock 506 27 276 minecraft:cobbled_deepslate
fill 506 27 277 506 30 277 minecraft:deepslate_tiles
setblock 506 27 316 minecraft:cobbled_deepslate
fill 507 27 276 507 30 276 minecraft:deepslate_tiles
setblock 507 27 315 minecraft:cobbled_deepslate
fill 507 27 316 507 30 316 minecraft:deepslate_tiles
setblock 508 27 314 minecraft:cobbled_deepslate
fill 508 27 315 508 30 315 minecraft:deepslate_tiles
setblock 509 27 278 minecraft:cobbled_deepslate
fill 509 27 279 509 29 280 minecraft:deepslate_tiles
fill 509 27 314 509 30 314 minecraft:deepslate_tiles
setblock 510 27 277 minecraft:cobbled_deepslate
fill 510 27 278 510 30 278 minecraft:deepslate_tiles
setblock 510 27 282 minecraft:cobbled_deepslate
setblock 510 27 297 minecraft:cobbled_deepslate
fill 510 27 298 510 28 300 minecraft:deepslate_tiles
setblock 510 27 312 minecraft:cobbled_deepslate
fill 510 27 313 510 30 313 minecraft:deepslate_tiles
setblock 511 27 276 minecraft:cobbled_deepslate
fill 511 27 277 511 30 277 minecraft:deepslate_tiles
setblock 511 27 281 minecraft:cobbled_deepslate
fill 511 27 282 511 30 282 minecraft:deepslate_tiles
fill 511 27 284 511 28 284 minecraft:deepslate_tiles
setblock 511 27 291 minecraft:cobbled_deepslate
fill 511 27 292 511 28 292 minecraft:deepslate_tiles
setblock 511 27 296 minecraft:cobbled_deepslate
fill 511 27 297 511 30 297 minecraft:deepslate_tiles
setblock 511 27 301 minecraft:cobbled_deepslate
fill 511 27 302 511 30 302 minecraft:deepslate_tiles
fill 511 27 304 511 27 305 minecraft:deepslate_tiles
setblock 511 27 306 minecraft:cobbled_deepslate
fill 511 27 307 511 30 307 minecraft:deepslate_tiles
setblock 511 27 311 minecraft:cobbled_deepslate
fill 511 27 312 511 30 312 minecraft:deepslate_tiles
setblock 511 27 316 minecraft:cobbled_deepslate
fill 471 28 275 473 59 275 minecraft:cobbled_deepslate
fill 471 28 276 471 31 276 minecraft:deepslate_tiles
setblock 471 28 280 minecraft:cobbled_deepslate
fill 471 28 281 471 31 281 minecraft:deepslate_tiles
fill 471 28 291 472 28 291 minecraft:cobbled_deepslate
setblock 471 28 295 minecraft:cobbled_deepslate
fill 471 28 296 471 28 299 minecraft:deepslate_tiles
setblock 471 28 300 minecraft:cobbled_deepslate
fill 471 28 301 471 28 304 minecraft:deepslate_tiles
setblock 471 28 305 minecraft:cobbled_deepslate
fill 471 28 306 472 30 306 minecraft:deepslate_tiles
setblock 471 28 310 minecraft:cobbled_deepslate
fill 471 28 311 471 31 311 minecraft:deepslate_tiles
setblock 471 28 315 minecraft:cobbled_deepslate
fill 471 28 316 471 31 316 minecraft:deepslate_tiles
setblock 472 28 278 minecraft:deepslate_tiles
fill 472 28 294 472 34 294 minecraft:white_wool
fill 472 28 295 472 31 295 minecraft:deepslate_tiles
setblock 472 28 299 minecraft:cobbled_deepslate
fill 472 28 300 472 31 300 minecraft:deepslate_tiles
setblock 472 28 303 minecraft:deepslate_tiles
setblock 472 28 304 minecraft:cobbled_deepslate
fill 472 28 305 472 31 305 minecraft:deepslate_tiles
setblock 472 28 314 minecraft:cobbled_deepslate
fill 472 28 315 472 31 315 minecraft:deepslate_tiles
fill 473 28 283 508 28 283 minecraft:cobbled_deepslate
fill 473 28 291 480 30 291 minecraft:white_wool
fill 473 28 295 509 28 295 minecraft:cobbled_deepslate
fill 473 28 299 478 28 299 minecraft:white_wool
fill 473 28 303 507 28 303 minecraft:cobbled_deepslate
setblock 474 28 275 minecraft:white_wool
fill 474 28 279 507 28 279 minecraft:cobbled_deepslate
fill 474 28 307 510 28 307 minecraft:cobbled_deepslate
fill 474 28 311 493 28 311 minecraft:cobbled_deepslate
fill 475 28 275 475 28 276 minecraft:cobbled_deepslate
fill 475 28 315 475 28 316 minecraft:cobbled_deepslate
fill 476 28 275 476 94 275 minecraft:cobbled_deepslate
fill 476 28 315 493 28 315 minecraft:cobbled_deepslate
fill 476 28 316 476 30 316 minecraft:deepslate_tiles
fill 478 28 293 480 32 294 minecraft:white_wool
fill 479 28 292 479 33 292 minecraft:white_wool
fill 479 28 296 479 33 296 minecraft:white_wool
setblock 479 28 299 minecraft:crying_obsidian
fill 482 28 276 484 28 276 minecraft:deepslate_tiles
fill 482 28 316 482 30 316 minecraft:deepslate_tiles
setblock 485 28 276 minecraft:cobbled_deepslate
fill 485 28 277 485 31 277 minecraft:deepslate_tiles
setblock 485 28 316 minecraft:cobbled_deepslate
fill 486 28 276 486 31 276 minecraft:deepslate_tiles
fill 486 28 287 487 28 287 minecraft:cobbled_deepslate
fill 486 28 316 486 31 316 minecraft:deepslate_tiles
setblock 488 28 278 minecraft:cobbled_deepslate
setblock 489 28 276 minecraft:deepslate_tiles
setblock 489 28 277 minecraft:cobbled_deepslate
fill 489 28 278 491 29 278 minecraft:deepslate_tiles
setblock 490 28 276 minecraft:cobbled_deepslate
fill 490 28 277 490 31 277 minecraft:deepslate_tiles
setblock 490 28 316 minecraft:cobbled_deepslate
fill 491 28 276 491 31 276 minecraft:deepslate_tiles
fill 491 28 316 491 31 316 minecraft:deepslate_tiles
setblock 493 28 277 minecraft:deepslate_tiles
fill 493 28 287 510 28 287 minecraft:cobbled_deepslate
setblock 494 28 277 minecraft:cobbled_deepslate
fill 494 28 311 494 28 315 minecraft:white_wool
setblock 495 28 276 minecraft:cobbled_deepslate
fill 495 28 277 495 31 277 minecraft:deepslate_tiles
fill 495 28 311 510 28 311 minecraft:cobbled_deepslate
fill 495 28 312 495 33 312 minecraft:black_concrete
fill 495 28 315 503 28 315 minecraft:cobbled_deepslate
fill 496 28 276 496 31 276 minecraft:deepslate_tiles
fill 496 28 313 496 33 313 minecraft:black_concrete
fill 497 28 277 498 28 277 minecraft:deepslate_tiles
fill 497 28 312 497 33 312 minecraft:black_concrete
setblock 499 28 277 minecraft:cobbled_deepslate
setblock 500 28 276 minecraft:cobbled_deepslate
fill 500 28 277 500 31 277 minecraft:deepslate_tiles
fill 501 28 276 501 31 276 minecraft:deepslate_tiles
fill 501 28 316 501 31 316 minecraft:deepslate_tiles
setblock 502 28 278 minecraft:deepslate_tiles
setblock 503 28 278 minecraft:cobbled_deepslate
fill 504 28 275 504 95 275 minecraft:cobbled_deepslate
setblock 504 28 277 minecraft:cobbled_deepslate
fill 504 28 278 504 31 278 minecraft:deepslate_tiles
fill 504 28 315 504 29 315 minecraft:deepslate_tiles
setblock 505 28 276 minecraft:cobbled_deepslate
fill 505 28 277 505 31 277 minecraft:deepslate_tiles
setblock 505 28 316 minecraft:cobbled_deepslate
fill 506 28 275 506 43 275 minecraft:cobbled_deepslate
fill 506 28 276 506 31 276 minecraft:deepslate_tiles
setblock 506 28 315 minecraft:cobbled_deepslate
fill 506 28 316 506 31 316 minecraft:deepslate_tiles
setblock 507 28 314 minecraft:cobbled_deepslate
fill 507 28 315 507 31 315 minecraft:deepslate_tiles
setblock 508 28 278 minecraft:cobbled_deepslate
fill 508 28 279 508 31 279 minecraft:deepslate_tiles
fill 508 28 314 508 31 314 minecraft:deepslate_tiles
setblock 509 28 277 minecraft:cobbled_deepslate
fill 509 28 278 509 31 278 minecraft:deepslate_tiles
setblock 509 28 281 minecraft:deepslate_tiles
setblock 510 28 276 minecraft:cobbled_deepslate
fill 510 28 277 510 31 277 minecraft:deepslate_tiles
setblock 510 28 281 minecraft:cobbled_deepslate
fill 510 28 282 510 31 282 minecraft:deepslate_tiles
setblock 510 28 296 minecraft:cobbled_deepslate
fill 510 28 297 510 31 297 minecraft:deepslate_tiles
setblock 510 28 301 minecraft:cobbled_deepslate
fill 510 28 302 510 31 302 minecraft:deepslate_tiles
fill 510 28 312 510 31 312 minecraft:deepslate_tiles
setblock 510 28 316 minecraft:cobbled_deepslate
fill 511 28 276 511 31 276 minecraft:deepslate_tiles
setblock 511 28 280 minecraft:cobbled_deepslate
fill 511 28 281 511 31 281 minecraft:deepslate_tiles
setblock 511 28 295 minecraft:cobbled_deepslate
fill 511 28 296 511 31 296 minecraft:deepslate_tiles
setblock 511 28 300 minecraft:cobbled_deepslate
fill 511 28 301 511 31 301 minecraft:deepslate_tiles
setblock 511 28 304 minecraft:deepslate_tiles
setblock 511 28 305 minecraft:cobbled_deepslate
fill 511 28 306 511 31 306 minecraft:deepslate_tiles
setblock 511 28 310 minecraft:cobbled_deepslate
fill 511 28 311 511 31 311 minecraft:deepslate_tiles
setblock 511 28 315 minecraft:cobbled_deepslate
fill 511 28 316 511 31 316 minecraft:deepslate_tiles
setblock 471 29 279 minecraft:cobbled_deepslate
fill 471 29 280 471 32 280 minecraft:deepslate_tiles
fill 471 29 282 471 30 282 minecraft:deepslate_tiles
fill 471 29 291 472 32 291 minecraft:white_wool
setblock 471 29 294 minecraft:cobbled_deepslate
fill 471 29 295 471 29 298 minecraft:deepslate_tiles
setblock 471 29 299 minecraft:cobbled_deepslate
fill 471 29 300 471 29 303 minecraft:deepslate_tiles
setblock 471 29 304 minecraft:cobbled_deepslate
fill 471 29 305 471 32 305 minecraft:deepslate_tiles
setblock 471 29 309 minecraft:cobbled_deepslate
fill 471 29 310 471 32 310 minecraft:deepslate_tiles
setblock 471 29 314 minecraft:cobbled_deepslate
fill 471 29 315 471 32 315 minecraft:deepslate_tiles
setblock 472 29 278 minecraft:cobbled_deepslate
setblock 472 29 298 minecraft:cobbled_deepslate
fill 472 29 299 473 31 299 minecraft:deepslate_tiles
setblock 472 29 303 minecraft:cobbled_deepslate
fill 472 29 304 472 32 304 minecraft:deepslate_tiles
setblock 472 29 307 minecraft:deepslate_tiles
setblock 472 29 313 minecraft:cobbled_deepslate
fill 472 29 314 472 30 314 minecraft:deepslate_tiles
setblock 473 29 278 minecraft:light[level=13]
setblock 473 29 286 minecraft:light[level=13]
setblock 473 29 288 minecraft:crying_obsidian
fill 473 29 295 482 29 295 minecraft:white_wool
fill 473 29 298 473 31 298 minecraft:deepslate_tiles
fill 473 29 300 473 29 301 minecraft:deepslate_tiles
setblock 473 29 302 minecraft:light[level=13]
setblock 473 29 310 minecraft:light[level=13]
fill 474 29 275 474 29 276 minecraft:cobbled_deepslate
fill 474 29 277 474 30 277 minecraft:white_wool
fill 474 29 298 477 31 299 minecraft:white_wool
setblock 474 29 316 minecraft:cobbled_deepslate
fill 475 29 275 475 90 275 minecraft:cobbled_deepslate
fill 475 29 276 475 30 276 minecraft:deepslate_tiles
fill 475 29 316 475 31 316 minecraft:deepslate_tiles
setblock 477 29 288 minecraft:crying_obsidian
setblock 477 29 300 minecraft:crying_obsidian
fill 478 29 276 478 30 284 minecraft:white_wool
fill 478 29 299 478 30 299 minecraft:white_wool
fill 481 29 276 483 29 276 minecraft:deepslate_tiles
setblock 481 29 278 minecraft:light[level=13]
setblock 481 29 286 minecraft:light[level=13]
setblock 481 29 292 minecraft:crying_obsidian
setblock 481 29 296 minecraft:crying_obsidian
setblock 481 29 302 minecraft:light[level=13]
setblock 481 29 310 minecraft:light[level=13]
fill 482 29 277 482 29 294 minecraft:white_wool
fill 482 29 296 482 29 315 minecraft:white_wool
setblock 484 29 276 minecraft:cobbled_deepslate
fill 484 29 277 484 32 277 minecraft:deepslate_tiles
setblock 484 29 316 minecraft:cobbled_deepslate
fill 485 29 276 485 32 276 minecraft:deepslate_tiles
fill 485 29 316 485 32 316 minecraft:deepslate_tiles
setblock 486 29 278 minecraft:deepslate_tiles
fill 486 29 279 486 30 291 minecraft:white_wool
setblock 487 29 278 minecraft:cobbled_deepslate
setblock 488 29 276 minecraft:deepslate_tiles
setblock 488 29 277 minecraft:cobbled_deepslate
fill 488 29 278 488 32 278 minecraft:deepslate_tiles
setblock 489 29 276 minecraft:cobbled_deepslate
fill 489 29 277 489 32 277 minecraft:deepslate_tiles
setblock 489 29 286 minecraft:light[level=13]
setblock 489 29 294 minecraft:light[level=13]
setblock 489 29 302 minecraft:light[level=13]
setblock 489 29 310 minecraft:light[level=13]
setblock 489 29 316 minecraft:cobbled_deepslate
fill 490 29 276 490 32 276 minecraft:deepslate_tiles
fill 490 29 279 490 29 285 minecraft:white_wool
fill 490 29 294 490 29 315 minecraft:white_wool
fill 490 29 316 490 32 316 minecraft:deepslate_tiles
setblock 492 29 278 minecraft:cobbled_deepslate
setblock 493 29 277 minecraft:cobbled_deepslate
fill 493 29 278 493 32 278 minecraft:deepslate_tiles
setblock 494 29 276 minecraft:cobbled_deepslate
fill 494 29 277 494 32 277 minecraft:deepslate_tiles
fill 494 29 278 494 29 314 minecraft:white_wool
fill 495 29 276 495 32 276 minecraft:deepslate_tiles
fill 496 29 311 496 33 311 minecraft:black_concrete
setblock 497 29 277 minecraft:deepslate_tiles
setblock 497 29 278 minecraft:light[level=13]
setblock 497 29 286 minecraft:light[level=13]
setblock 497 29 294 minecraft:light[level=13]
setblock 497 29 302 minecraft:light[level=13]
setblock 497 29 310 minecraft:light[level=13]
setblock 498 29 277 minecraft:cobbled_deepslate
fill 498 29 278 498 30 278 minecraft:white_wool
setblock 499 29 276 minecraft:cobbled_deepslate
fill 499 29 277 499 32 277 minecraft:deepslate_tiles
fill 500 29 276 500 32 276 minecraft:deepslate_tiles
fill 500 29 316 500 32 316 minecraft:deepslate_tiles
setblock 501 29 278 minecraft:deepslate_tiles
setblock 502 29 278 minecraft:cobbled_deepslate
fill 502 29 279 502 29 315 minecraft:white_wool
setblock 503 29 277 minecraft:cobbled_deepslate
fill 503 29 278 503 32 278 minecraft:deepslate_tiles
fill 503 29 315 503 30 315 minecraft:deepslate_tiles
setblock 504 29 276 minecraft:cobbled_deepslate
fill 504 29 277 504 32 277 minecraft:deepslate_tiles
fill 504 29 303 509 29 303 minecraft:cobbled_deepslate
setblock 504 29 316 minecraft:cobbled_deepslate
fill 505 29 276 505 32 276 minecraft:deepslate_tiles
setblock 505 29 279 minecraft:deepslate_tiles
fill 505 29 283 509 29 283 minecraft:cobbled_deepslate
setblock 505 29 286 minecraft:light[level=13]
setblock 505 29 294 minecraft:light[level=13]
setblock 505 29 302 minecraft:light[level=13]
setblock 505 29 310 minecraft:light[level=13]
setblock 505 29 315 minecraft:cobbled_deepslate
fill 505 29 316 505 32 316 minecraft:deepslate_tiles
setblock 506 29 279 minecraft:cobbled_deepslate
fill 506 29 315 506 32 315 minecraft:deepslate_tiles
setblock 507 29 278 minecraft:cobbled_deepslate
fill 507 29 279 507 32 279 minecraft:deepslate_tiles
fill 507 29 314 507 32 314 minecraft:deepslate_tiles
setblock 508 29 277 minecraft:cobbled_deepslate
fill 508 29 278 508 32 278 minecraft:deepslate_tiles
fill 508 29 280 508 30 280 minecraft:deepslate_tiles
setblock 509 29 276 minecraft:cobbled_deepslate
fill 509 29 277 509 32 277 minecraft:deepslate_tiles
setblock 509 29 281 minecraft:cobbled_deepslate
setblock 509 29 316 minecraft:cobbled_deepslate
fill 510 29 276 510 32 276 minecraft:deepslate_tiles
setblock 510 29 280 minecraft:cobbled_deepslate
fill 510 29 281 510 32 281 minecraft:deepslate_tiles
fill 510 29 283 510 30 283 minecraft:deepslate_tiles
fill 510 29 284 510 29 294 minecraft:white_wool
setblock 510 29 295 minecraft:cobbled_deepslate
fill 510 29 296 510 31 296 minecraft:deepslate_tiles
fill 510 29 298 510 29 299 minecraft:deepslate_tiles
setblock 510 29 300 minecraft:cobbled_deepslate
fill 510 29 301 510 32 301 minecraft:deepslate_tiles
fill 510 29 303 510 29 304 minecraft:deepslate_tiles
fill 510 29 305 510 29 309 minecraft:white_wool
setblock 510 29 310 minecraft:cobbled_deepslate
fill 510 29 311 510 32 311 minecraft:deepslate_tiles
setblock 510 29 315 minecraft:cobbled_deepslate
fill 510 29 316 510 32 316 minecraft:deepslate_tiles
setblock 511 29 279 minecraft:cobbled_deepslate
fill 511 29 280 511 32 280 minecraft:deepslate_tiles
setblock 511 29 284 minecraft:cobbled_deepslate
fill 511 29 285 511 32 285 minecraft:deepslate_tiles
setblock 511 29 294 minecraft:cobbled_deepslate
fill 511 29 295 511 32 295 minecraft:deepslate_tiles
setblock 511 29 299 minecraft:cobbled_deepslate
fill 511 29 300 511 32 300 minecraft:deepslate_tiles
setblock 511 29 304 minecraft:cobbled_deepslate
fill 511 29 305 511 32 305 minecraft:deepslate_tiles
setblock 511 29 309 minecraft:cobbled_deepslate
fill 511 29 310 511 32 310 minecraft:deepslate_tiles
setblock 511 29 314 minecraft:cobbled_deepslate
fill 511 29 315 511 32 315 minecraft:deepslate_tiles
setblock 471 30 278 minecraft:cobbled_deepslate
fill 471 30 279 471 33 279 minecraft:deepslate_tiles
setblock 471 30 283 minecraft:cobbled_deepslate
setblock 471 30 293 minecraft:cobbled_deepslate
fill 471 30 294 471 30 297 minecraft:deepslate_tiles
setblock 471 30 298 minecraft:cobbled_deepslate
fill 471 30 299 471 30 302 minecraft:deepslate_tiles
setblock 471 30 303 minecraft:cobbled_deepslate
fill 471 30 304 471 33 304 minecraft:deepslate_tiles
setblock 471 30 308 minecraft:cobbled_deepslate
fill 471 30 309 471 33 309 minecraft:deepslate_tiles
setblock 471 30 313 minecraft:cobbled_deepslate
fill 471 30 314 471 33 314 minecraft:deepslate_tiles
setblock 472 30 277 minecraft:cobbled_deepslate
fill 472 30 278 472 31 278 minecraft:deepslate_tiles
setblock 472 30 297 minecraft:cobbled_deepslate
fill 472 30 298 472 33 298 minecraft:deepslate_tiles
setblock 472 30 302 minecraft:cobbled_deepslate
fill 472 30 303 473 32 303 minecraft:deepslate_tiles
setblock 472 30 307 minecraft:cobbled_deepslate
fill 472 30 308 472 33 308 minecraft:deepslate_tiles
setblock 472 30 313 minecraft:deepslate_tiles
setblock 473 30 276 minecraft:cobbled_deepslate
fill 473 30 295 480 32 295 minecraft:white_wool
setblock 473 30 300 minecraft:deepslate_tiles
setblock 473 30 301 minecraft:cobbled_deepslate
fill 473 30 302 473 33 302 minecraft:deepslate_tiles
setblock 473 30 316 minecraft:cobbled_deepslate
fill 474 30 275 474 94 275 minecraft:cobbled_deepslate
fill 474 30 276 474 32 276 minecraft:deepslate_tiles
fill 474 30 278 474 30 287 minecraft:white_wool
fill 474 30 301 474 30 308 minecraft:white_wool
fill 474 30 316 474 32 316 minecraft:deepslate_tiles
setblock 476 30 288 minecraft:crying_obsidian
setblock 476 30 300 minecraft:crying_obsidian
fill 478 30 285 478 30 288 minecraft:white_wool
fill 478 30 300 478 30 315 minecraft:white_wool
fill 480 30 276 482 30 276 minecraft:deepslate_tiles
setblock 481 30 293 minecraft:crying_obsidian
setblock 481 30 295 minecraft:crying_obsidian
fill 481 30 316 481 31 316 minecraft:deepslate_tiles
setblock 482 30 277 minecraft:cobbled_deepslate
fill 482 30 278 482 30 283 minecraft:white_wool
setblock 483 30 276 minecraft:cobbled_deepslate
fill 483 30 277 483 33 277 minecraft:deepslate_tiles
setblock 483 30 316 minecraft:cobbled_deepslate
fill 484 30 276 484 33 276 minecraft:deepslate_tiles
fill 484 30 316 484 33 316 minecraft:deepslate_tiles
setblock 485 30 278 minecraft:deepslate_tiles
setblock 486 30 277 minecraft:deepslate_tiles
setblock 486 30 278 minecraft:cobbled_deepslate
fill 486 30 292 486 30 315 minecraft:white_wool
setblock 487 30 277 minecraft:cobbled_deepslate
fill 487 30 278 487 33 278 minecraft:deepslate_tiles
setblock 488 30 276 minecraft:cobbled_deepslate
fill 488 30 277 488 33 277 minecraft:deepslate_tiles
setblock 488 30 316 minecraft:cobbled_deepslate
fill 489 30 276 489 33 276 minecraft:deepslate_tiles
fill 489 30 278 490 30 278 minecraft:deepslate_tiles
fill 489 30 316 489 33 316 minecraft:deepslate_tiles
setblock 490 30 279 minecraft:white_wool
setblock 491 30 278 minecraft:cobbled_deepslate
setblock 492 30 277 minecraft:cobbled_deepslate
fill 492 30 278 492 33 278 minecraft:deepslate_tiles
setblock 493 30 276 minecraft:cobbled_deepslate
fill 493 30 277 493 33 277 minecraft:deepslate_tiles
setblock 493 30 316 minecraft:cobbled_deepslate
fill 494 30 276 494 33 276 minecraft:deepslate_tiles
fill 494 30 278 494 31 278 minecraft:deepslate_tiles
fill 495 30 311 495 33 311 minecraft:black_concrete
fill 495 30 313 495 33 313 minecraft:black_concrete
setblock 497 30 277 minecraft:cobbled_deepslate
fill 497 30 311 497 33 311 minecraft:black_concrete
fill 497 30 313 497 33 313 minecraft:black_concrete
setblock 498 30 276 minecraft:cobbled_deepslate
fill 498 30 277 498 33 277 minecraft:deepslate_tiles
fill 498 30 279 498 30 316 minecraft:white_wool
fill 499 30 276 499 33 276 minecraft:deepslate_tiles
fill 499 30 278 500 30 278 minecraft:deepslate_tiles
fill 499 30 316 499 33 316 minecraft:deepslate_tiles
setblock 501 30 278 minecraft:cobbled_deepslate
setblock 502 30 277 minecraft:cobbled_deepslate
fill 502 30 278 502 33 278 minecraft:deepslate_tiles
setblock 503 30 276 minecraft:cobbled_deepslate
fill 503 30 277 503 33 277 minecraft:deepslate_tiles
fill 503 30 279 504 30 279 minecraft:deepslate_tiles
setblock 503 30 316 minecraft:cobbled_deepslate
fill 504 30 276 504 33 276 minecraft:deepslate_tiles
setblock 504 30 315 minecraft:cobbled_deepslate
fill 504 30 316 504 33 316 minecraft:deepslate_tiles
setblock 505 30 279 minecraft:cobbled_deepslate
fill 505 30 315 505 33 315 minecraft:deepslate_tiles
setblock 506 30 278 minecraft:cobbled_deepslate
fill 506 30 279 506 33 279 minecraft:deepslate_tiles
fill 506 30 280 506 30 303 minecraft:white_wool
fill 506 30 314 506 33 314 minecraft:deepslate_tiles
setblock 507 30 277 minecraft:cobbled_deepslate
fill 507 30 278 507 33 278 minecraft:deepslate_tiles
setblock 508 30 276 minecraft:cobbled_deepslate
fill 508 30 277 508 33 277 minecraft:deepslate_tiles
setblock 508 30 316 minecraft:cobbled_deepslate
fill 509 30 276 509 33 276 minecraft:deepslate_tiles
setblock 509 30 279 minecraft:deepslate_tiles
setblock 509 30 280 minecraft:cobbled_deepslate
fill 509 30 281 509 32 282 minecraft:deepslate_tiles
setblock 509 30 299 minecraft:deepslate_tiles
setblock 509 30 300 minecraft:cobbled_deepslate
fill 509 30 301 509 33 301 minecraft:deepslate_tiles
setblock 509 30 315 minecraft:cobbled_deepslate
fill 509 30 316 509 33 316 minecraft:deepslate_tiles
setblock 510 30 279 minecraft:cobbled_deepslate
fill 510 30 280 510 33 280 minecraft:deepslate_tiles
setblock 510 30 295 minecraft:deepslate_tiles
setblock 510 30 298 minecraft:deepslate_tiles
setblock 510 30 299 minecraft:cobbled_deepslate
fill 510 30 300 510 33 300 minecraft:deepslate_tiles
setblock 510 30 303 minecraft:deepslate_tiles
setblock 510 30 304 minecraft:cobbled_deepslate
fill 510 30 305 510 30 308 minecraft:deepslate_tiles
setblock 510 30 309 minecraft:cobbled_deepslate
fill 510 30 310 510 33 310 minecraft:deepslate_tiles
setblock 510 30 314 minecraft:cobbled_deepslate
fill 510 30 315 510 33 315 minecraft:deepslate_tiles
setblock 511 30 278 minecraft:cobbled_deepslate
fill 511 30 279 511 33 279 minecraft:deepslate_tiles
setblock 511 30 283 minecraft:cobbled_deepslate
fill 511 30 284 511 33 284 minecraft:deepslate_tiles
setblock 511 30 293 minecraft:cobbled_deepslate
fill 511 30 294 511 31 294 minecraft:deepslate_tiles
setblock 511 30 298 minecraft:cobbled_deepslate
fill 511 30 299 511 33 299 minecraft:deepslate_tiles
setblock 511 30 303 minecraft:cobbled_deepslate
fill 511 30 304 511 33 304 minecraft:deepslate_tiles
setblock 511 30 308 minecraft:cobbled_deepslate
fill 511 30 309 511 33 309 minecraft:deepslate_tiles
setblock 511 30 313 minecraft:cobbled_deepslate
fill 511 30 314 511 33 314 minecraft:deepslate_tiles
setblock 471 31 277 minecraft:cobbled_deepslate
fill 471 31 278 471 34 278 minecraft:deepslate_tiles
setblock 471 31 282 minecraft:cobbled_deepslate
fill 471 31 283 471 34 283 minecraft:deepslate_tiles
fill 471 31 292 471 33 292 minecraft:white_wool
fill 471 31 293 471 31 296 minecraft:deepslate_tiles
setblock 471 31 297 minecraft:cobbled_deepslate
fill 471 31 298 471 31 301 minecraft:deepslate_tiles
setblock 471 31 302 minecraft:cobbled_deepslate
fill 471 31 303 471 34 303 minecraft:deepslate_tiles
setblock 471 31 306 minecraft:deepslate_tiles
setblock 471 31 307 minecraft:cobbled_deepslate
fill 471 31 308 471 34 308 minecraft:deepslate_tiles
setblock 471 31 312 minecraft:cobbled_deepslate
fill 471 31 313 471 34 313 minecraft:deepslate_tiles
setblock 472 31 276 minecraft:cobbled_deepslate
setblock 472 31 277 minecraft:deepslate_tiles
setblock 472 31 296 minecraft:cobbled_deepslate
fill 472 31 297 472 34 297 minecraft:deepslate_tiles
setblock 472 31 301 minecraft:cobbled_deepslate
fill 472 31 302 472 34 302 minecraft:deepslate_tiles
setblock 472 31 306 minecraft:cobbled_deepslate
fill 472 31 307 472 34 307 minecraft:deepslate_tiles
setblock 472 31 316 minecraft:cobbled_deepslate
fill 473 31 276 473 32 276 minecraft:deepslate_tiles
setblock 473 31 278 minecraft:light[level=12]
setblock 473 31 285 minecraft:light[level=12]
fill 473 31 291 479 32 291 minecraft:white_wool
setblock 473 31 300 minecraft:cobbled_deepslate
fill 473 31 301 473 34 301 minecraft:deepslate_tiles
setblock 473 31 306 minecraft:light[level=12]
setblock 473 31 313 minecraft:light[level=12]
fill 473 31 316 473 32 316 minecraft:deepslate_tiles
fill 474 31 306 474 31 315 minecraft:white_wool
fill 479 31 276 481 31 276 minecraft:deepslate_tiles
setblock 480 31 278 minecraft:light[level=12]
setblock 480 31 285 minecraft:light[level=12]
setblock 480 31 299 minecraft:light[level=12]
setblock 480 31 306 minecraft:light[level=12]
setblock 480 31 313 minecraft:light[level=12]
setblock 482 31 276 minecraft:cobbled_deepslate
fill 482 31 277 482 34 277 minecraft:deepslate_tiles
setblock 482 31 316 minecraft:cobbled_deepslate
fill 483 31 276 483 34 276 minecraft:deepslate_tiles
fill 483 31 316 483 34 316 minecraft:deepslate_tiles
setblock 484 31 278 minecraft:deepslate_tiles
setblock 485 31 278 minecraft:cobbled_deepslate
setblock 486 31 277 minecraft:cobbled_deepslate
fill 486 31 278 486 34 278 minecraft:deepslate_tiles
setblock 487 31 276 minecraft:cobbled_deepslate
fill 487 31 277 487 34 277 minecraft:deepslate_tiles
fill 487 31 279 488 31 279 minecraft:deepslate_tiles
setblock 487 31 285 minecraft:light[level=12]
setblock 487 31 292 minecraft:light[level=12]
setblock 487 31 299 minecraft:light[level=12]
setblock 487 31 306 minecraft:light[level=12]
setblock 487 31 313 minecraft:light[level=12]
setblock 487 31 316 minecraft:cobbled_deepslate
fill 488 31 276 488 34 276 minecraft:deepslate_tiles
fill 488 31 316 488 33 316 minecraft:deepslate_tiles
setblock 489 31 278 minecraft:deepslate_tiles
setblock 489 31 279 minecraft:cobbled_deepslate
setblock 490 31 278 minecraft:cobbled_deepslate
setblock 491 31 277 minecraft:cobbled_deepslate
fill 491 31 278 491 34 278 minecraft:deepslate_tiles
setblock 492 31 276 minecraft:cobbled_deepslate
fill 492 31 277 492 34 277 minecraft:deepslate_tiles
setblock 492 31 316 minecraft:cobbled_deepslate
fill 493 31 276 493 34 276 minecraft:deepslate_tiles
setblock 494 31 285 minecraft:light[level=12]
setblock 494 31 292 minecraft:light[level=12]
setblock 494 31 299 minecraft:light[level=12]
setblock 494 31 306 minecraft:light[level=12]
setblock 494 31 313 minecraft:light[level=12]
setblock 495 31 278 minecraft:cobbled_deepslate
setblock 496 31 277 minecraft:cobbled_deepslate
setblock 497 31 276 minecraft:cobbled_deepslate
fill 497 31 277 497 33 278 minecraft:deepslate_tiles
fill 498 31 276 498 34 276 minecraft:deepslate_tiles
fill 498 31 278 499 31 278 minecraft:deepslate_tiles
setblock 500 31 278 minecraft:cobbled_deepslate
setblock 501 31 277 minecraft:cobbled_deepslate
fill 501 31 278 501 34 278 minecraft:deepslate_tiles
setblock 501 31 285 minecraft:light[level=12]
setblock 501 31 292 minecraft:light[level=12]
setblock 501 31 299 minecraft:light[level=12]
setblock 501 31 306 minecraft:light[level=12]
setblock 501 31 313 minecraft:light[level=12]
setblock 502 31 276 minecraft:cobbled_deepslate
fill 502 31 277 502 34 277 minecraft:deepslate_tiles
fill 502 31 279 503 31 279 minecraft:deepslate_tiles
setblock 502 31 315 minecraft:deepslate_tiles
setblock 502 31 316 minecraft:cobbled_deepslate
fill 503 31 276 503 34 276 minecraft:deepslate_tiles
setblock 503 31 315 minecraft:cobbled_deepslate
fill 503 31 316 503 34 316 minecraft:deepslate_tiles
setblock 504 31 279 minecraft:cobbled_deepslate
fill 504 31 315 504 34 315 minecraft:deepslate_tiles
setblock 505 31 278 minecraft:cobbled_deepslate
fill 505 31 279 505 34 279 minecraft:deepslate_tiles
setblock 506 31 277 minecraft:cobbled_deepslate
fill 506 31 278 506 34 278 minecraft:deepslate_tiles
fill 506 31 302 506 31 313 minecraft:white_wool
setblock 507 31 276 minecraft:cobbled_deepslate
fill 507 31 277 507 34 277 minecraft:deepslate_tiles
setblock 507 31 316 minecraft:cobbled_deepslate
fill 508 31 276 508 34 276 minecraft:deepslate_tiles
setblock 508 31 280 minecraft:cobbled_deepslate
fill 508 31 281 508 33 281 minecraft:deepslate_tiles
setblock 508 31 285 minecraft:light[level=12]
setblock 508 31 292 minecraft:light[level=12]
setblock 508 31 299 minecraft:light[level=12]
setblock 508 31 306 minecraft:light[level=12]
setblock 508 31 313 minecraft:light[level=12]
setblock 508 31 315 minecraft:cobbled_deepslate
fill 508 31 316 508 34 316 minecraft:deepslate_tiles
setblock 509 31 279 minecraft:cobbled_deepslate
fill 509 31 280 509 34 280 minecraft:deepslate_tiles
setblock 509 31 299 minecraft:cobbled_deepslate
fill 509 31 300 509 33 300 minecraft:deepslate_tiles
fill 509 31 302 509 31 303 minecraft:deepslate_tiles
setblock 509 31 304 minecraft:cobbled_deepslate
setblock 509 31 314 minecraft:cobbled_deepslate
fill 509 31 315 509 34 315 minecraft:deepslate_tiles
setblock 510 31 278 minecraft:cobbled_deepslate
fill 510 31 279 510 34 279 minecraft:deepslate_tiles
setblock 510 31 283 minecraft:cobbled_deepslate
fill 510 31 284 510 33 284 minecraft:deepslate_tiles
setblock 510 31 298 minecraft:cobbled_deepslate
fill 510 31 299 510 34 299 minecraft:deepslate_tiles
setblock 510 31 303 minecraft:cobbled_deepslate
fill 510 31 304 510 31 307 minecraft:deepslate_tiles
setblock 510 31 308 minecraft:cobbled_deepslate
fill 510 31 309 510 34 309 minecraft:deepslate_tiles
setblock 510 31 313 minecraft:cobbled_deepslate
fill 510 31 314 510 34 314 minecraft:deepslate_tiles
setblock 511 31 277 minecraft:cobbled_deepslate
fill 511 31 278 511 34 278 minecraft:deepslate_tiles
setblock 511 31 282 minecraft:cobbled_deepslate
fill 511 31 283 511 34 283 minecraft:deepslate_tiles
setblock 511 31 297 minecraft:cobbled_deepslate
fill 511 31 298 511 34 298 minecraft:deepslate_tiles
setblock 511 31 302 minecraft:cobbled_deepslate
fill 511 31 303 511 34 303 minecraft:deepslate_tiles
setblock 511 31 307 minecraft:cobbled_deepslate
fill 511 31 308 511 34 308 minecraft:deepslate_tiles
setblock 511 31 312 minecraft:cobbled_deepslate
fill 511 31 313 511 34 313 minecraft:deepslate_tiles
setblock 471 32 276 minecraft:cobbled_deepslate
fill 471 32 277 471 34 277 minecraft:deepslate_tiles
setblock 471 32 281 minecraft:cobbled_deepslate
fill 471 32 282 471 35 282 minecraft:deepslate_tiles
fill 471 32 284 471 33 284 minecraft:deepslate_tiles
fill 471 32 293 471 32 295 minecraft:deepslate_tiles
setblock 471 32 296 minecraft:cobbled_deepslate
fill 471 32 297 471 32 300 minecraft:deepslate_tiles
setblock 471 32 301 minecraft:cobbled_deepslate
fill 471 32 302 471 35 302 minecraft:deepslate_tiles
setblock 471 32 306 minecraft:cobbled_deepslate
fill 471 32 307 471 35 307 minecraft:deepslate_tiles
setblock 471 32 311 minecraft:cobbled_deepslate
fill 471 32 312 471 34 312 minecraft:deepslate_tiles
setblock 471 32 316 minecraft:cobbled_deepslate
fill 472 32 276 472 33 276 minecraft:deepslate_tiles
fill 472 32 295 472 34 295 minecraft:white_wool
setblock 472 32 296 minecraft:deepslate_tiles
setblock 472 32 299 minecraft:deepslate_tiles
setblock 472 32 300 minecraft:cobbled_deepslate
fill 472 32 301 472 35 301 minecraft:deepslate_tiles
setblock 472 32 305 minecraft:cobbled_deepslate
fill 472 32 306 472 35 306 minecraft:deepslate_tiles
fill 472 32 316 472 33 316 minecraft:deepslate_tiles
fill 473 32 298 477 33 298 minecraft:white_wool
setblock 473 32 299 minecraft:cobbled_deepslate
fill 473 32 300 473 33 300 minecraft:deepslate_tiles
setblock 473 32 304 minecraft:cobbled_deepslate
fill 474 32 299 476 32 299 minecraft:white_wool
fill 479 32 276 480 32 276 minecraft:deepslate_tiles
setblock 481 32 276 minecraft:cobbled_deepslate
fill 481 32 277 481 35 277 minecraft:deepslate_tiles
setblock 481 32 316 minecraft:cobbled_deepslate
fill 482 32 276 482 35 276 minecraft:deepslate_tiles
fill 482 32 316 482 33 316 minecraft:deepslate_tiles
setblock 483 32 278 minecraft:deepslate_tiles
setblock 484 32 278 minecraft:cobbled_deepslate
setblock 485 32 277 minecraft:cobbled_deepslate
fill 485 32 278 485 34 279 minecraft:deepslate_tiles
setblock 486 32 276 minecraft:cobbled_deepslate
fill 486 32 277 486 35 277 minecraft:deepslate_tiles
fill 486 32 279 487 32 279 minecraft:deepslate_tiles
setblock 486 32 316 minecraft:cobbled_deepslate
fill 487 32 276 487 35 276 minecraft:deepslate_tiles
fill 487 32 316 487 34 316 minecraft:deepslate_tiles
setblock 488 32 279 minecraft:cobbled_deepslate
setblock 489 32 275 minecraft:white_wool
setblock 489 32 278 minecraft:cobbled_deepslate
fill 489 32 279 490 32 279 minecraft:deepslate_tiles
setblock 490 32 277 minecraft:cobbled_deepslate
fill 490 32 278 490 34 278 minecraft:deepslate_tiles
setblock 491 32 276 minecraft:cobbled_deepslate
fill 491 32 277 491 35 277 minecraft:deepslate_tiles
setblock 491 32 316 minecraft:cobbled_deepslate
fill 492 32 276 492 35 276 minecraft:deepslate_tiles
setblock 494 32 278 minecraft:cobbled_deepslate
setblock 495 32 277 minecraft:cobbled_deepslate
fill 495 32 278 496 32 278 minecraft:deepslate_tiles
setblock 496 32 276 minecraft:cobbled_deepslate
fill 496 32 277 496 35 277 minecraft:deepslate_tiles
fill 497 32 276 497 35 276 minecraft:deepslate_tiles
setblock 498 32 278 minecraft:deepslate_tiles
setblock 499 32 278 minecraft:cobbled_deepslate
setblock 500 32 277 minecraft:cobbled_deepslate
fill 500 32 278 500 35 278 minecraft:deepslate_tiles
setblock 501 32 276 minecraft:cobbled_deepslate
fill 501 32 277 501 35 277 minecraft:deepslate_tiles
fill 501 32 279 502 32 279 minecraft:deepslate_tiles
setblock 501 32 316 minecraft:cobbled_deepslate
fill 502 32 276 502 35 276 minecraft:deepslate_tiles
setblock 502 32 315 minecraft:cobbled_deepslate
fill 502 32 316 502 35 316 minecraft:deepslate_tiles
setblock 503 32 279 minecraft:cobbled_deepslate
fill 503 32 315 503 35 315 minecraft:deepslate_tiles
setblock 504 32 278 minecraft:cobbled_deepslate
fill 504 32 279 504 35 279 minecraft:deepslate_tiles
setblock 505 32 277 minecraft:cobbled_deepslate
fill 505 32 278 505 35 278 minecraft:deepslate_tiles
setblock 506 32 276 minecraft:cobbled_deepslate
fill 506 32 277 506 35 277 minecraft:deepslate_tiles
setblock 506 32 316 minecraft:cobbled_deepslate
fill 507 32 276 507 35 276 minecraft:deepslate_tiles
setblock 507 32 315 minecraft:cobbled_deepslate
fill 507 32 316 507 35 316 minecraft:deepslate_tiles
setblock 508 32 279 minecraft:cobbled_deepslate
fill 508 32 280 508 33 280 minecraft:deepslate_tiles
setblock 508 32 314 minecraft:cobbled_deepslate
fill 508 32 315 508 35 315 minecraft:deepslate_tiles
setblock 509 32 278 minecraft:cobbled_deepslate
fill 509 32 279 509 34 279 minecraft:deepslate_tiles
setblock 509 32 283 minecraft:cobbled_deepslate
setblock 509 32 299 minecraft:deepslate_tiles
setblock 509 32 302 minecraft:deepslate_tiles
setblock 509 32 303 minecraft:cobbled_deepslate
fill 509 32 304 510 33 305 minecraft:deepslate_tiles
setblock 509 32 314 minecraft:deepslate_tiles
setblock 510 32 277 minecraft:cobbled_deepslate
fill 510 32 278 510 35 278 minecraft:deepslate_tiles
setblock 510 32 282 minecraft:cobbled_deepslate
fill 510 32 283 510 34 283 minecraft:deepslate_tiles
setblock 510 32 297 minecraft:cobbled_deepslate
fill 510 32 298 510 33 298 minecraft:deepslate_tiles
setblock 510 32 302 minecraft:cobbled_deepslate
fill 510 32 303 510 35 303 minecraft:deepslate_tiles
setblock 510 32 306 minecraft:deepslate_tiles
setblock 510 32 307 minecraft:cobbled_deepslate
fill 510 32 308 510 35 308 minecraft:deepslate_tiles
setblock 510 32 312 minecraft:cobbled_deepslate
fill 510 32 313 510 34 313 minecraft:deepslate_tiles
setblock 511 32 276 minecraft:cobbled_deepslate
fill 511 32 277 511 35 277 minecraft:deepslate_tiles
setblock 511 32 281 minecraft:cobbled_deepslate
fill 511 32 282 511 35 282 minecraft:deepslate_tiles
setblock 511 32 296 minecraft:cobbled_deepslate
fill 511 32 297 511 34 297 minecraft:deepslate_tiles
setblock 511 32 301 minecraft:cobbled_deepslate
fill 511 32 302 511 35 302 minecraft:deepslate_tiles
setblock 511 32 306 minecraft:cobbled_deepslate
fill 511 32 307 511 35 307 minecraft:deepslate_tiles
setblock 511 32 311 minecraft:cobbled_deepslate
fill 511 32 312 511 35 312 minecraft:deepslate_tiles
setblock 511 32 316 minecraft:cobbled_deepslate
fill 471 33 276 471 34 276 minecraft:deepslate_tiles
setblock 471 33 280 minecraft:cobbled_deepslate
fill 471 33 281 471 35 281 minecraft:deepslate_tiles
setblock 471 33 293 minecraft:white_wool
setblock 471 33 294 minecraft:deepslate_tiles
setblock 471 33 295 minecraft:cobbled_deepslate
fill 471 33 296 471 33 299 minecraft:deepslate_tiles
setblock 471 33 300 minecraft:cobbled_deepslate
fill 471 33 301 471 36 301 minecraft:deepslate_tiles
setblock 471 33 305 minecraft:cobbled_deepslate
fill 471 33 306 471 36 306 minecraft:deepslate_tiles
setblock 471 33 310 minecraft:cobbled_deepslate
fill 471 33 311 471 35 311 minecraft:deepslate_tiles
setblock 471 33 315 minecraft:cobbled_deepslate
fill 471 33 316 471 34 316 minecraft:deepslate_tiles
fill 472 33 291 478 33 291 minecraft:white_wool
fill 472 33 296 472 34 296 minecraft:white_wool
setblock 472 33 299 minecraft:cobbled_deepslate
fill 472 33 300 472 36 300 minecraft:deepslate_tiles
setblock 472 33 303 minecraft:deepslate_tiles
setblock 472 33 304 minecraft:cobbled_deepslate
fill 472 33 305 472 36 305 minecraft:deepslate_tiles
fill 473 33 295 479 33 295 minecraft:white_wool
setblock 473 33 299 minecraft:deepslate_tiles
setblock 473 33 303 minecraft:cobbled_deepslate
fill 473 33 304 473 34 304 minecraft:deepslate_tiles
fill 478 33 293 479 33 294 minecraft:white_wool
setblock 479 33 276 minecraft:deepslate_tiles
setblock 480 33 276 minecraft:cobbled_deepslate
fill 481 33 276 481 36 276 minecraft:deepslate_tiles
setblock 483 33 278 minecraft:cobbled_deepslate
setblock 484 33 277 minecraft:cobbled_deepslate
fill 484 33 278 484 35 278 minecraft:deepslate_tiles
setblock 485 33 276 minecraft:cobbled_deepslate
fill 485 33 277 485 36 277 minecraft:deepslate_tiles
setblock 485 33 316 minecraft:cobbled_deepslate
fill 486 33 276 486 36 276 minecraft:deepslate_tiles
setblock 486 33 279 minecraft:deepslate_tiles
fill 486 33 316 486 34 316 minecraft:deepslate_tiles
setblock 487 33 279 minecraft:cobbled_deepslate
setblock 488 33 278 minecraft:cobbled_deepslate
fill 488 33 279 489 33 279 minecraft:deepslate_tiles
fill 489 33 275 489 90 275 minecraft:cobbled_deepslate
setblock 489 33 277 minecraft:cobbled_deepslate
fill 489 33 278 489 35 278 minecraft:deepslate_tiles
setblock 490 33 276 minecraft:cobbled_deepslate
fill 490 33 277 490 35 277 minecraft:deepslate_tiles
fill 491 33 276 491 36 276 minecraft:deepslate_tiles
setblock 491 33 317 minecraft:white_wool
setblock 493 33 278 minecraft:cobbled_deepslate
setblock 494 33 277 minecraft:cobbled_deepslate
setblock 494 33 312 minecraft:black_concrete
setblock 495 33 276 minecraft:cobbled_deepslate
fill 495 33 277 495 35 277 minecraft:deepslate_tiles
fill 496 33 276 496 36 276 minecraft:deepslate_tiles
setblock 496 33 278 minecraft:deepslate_tiles
setblock 496 33 310 minecraft:black_concrete
setblock 496 33 314 minecraft:black_concrete
setblock 498 33 278 minecraft:cobbled_deepslate
setblock 498 33 312 minecraft:black_concrete
setblock 499 33 277 minecraft:cobbled_deepslate
fill 499 33 278 499 36 278 minecraft:deepslate_tiles
setblock 500 33 276 minecraft:cobbled_deepslate
fill 500 33 277 500 36 277 minecraft:deepslate_tiles
fill 500 33 279 501 33 279 minecraft:deepslate_tiles
setblock 500 33 316 minecraft:cobbled_deepslate
fill 501 33 276 501 36 276 minecraft:deepslate_tiles
fill 501 33 316 501 36 316 minecraft:deepslate_tiles
setblock 502 33 279 minecraft:cobbled_deepslate
fill 502 33 315 502 36 315 minecraft:deepslate_tiles
setblock 503 33 278 minecraft:cobbled_deepslate
fill 503 33 279 503 36 279 minecraft:deepslate_tiles
setblock 504 33 277 minecraft:cobbled_deepslate
fill 504 33 278 504 36 278 minecraft:deepslate_tiles
setblock 505 33 276 minecraft:cobbled_deepslate
fill 505 33 277 505 36 277 minecraft:deepslate_tiles
setblock 505 33 316 minecraft:cobbled_deepslate
fill 506 33 276 506 36 276 minecraft:deepslate_tiles
setblock 506 33 315 minecraft:cobbled_deepslate
fill 506 33 316 506 36 316 minecraft:deepslate_tiles
setblock 507 33 279 minecraft:cobbled_deepslate
setblock 507 33 314 minecraft:cobbled_deepslate
fill 507 33 315 507 36 315 minecraft:deepslate_tiles
setblock 508 33 278 minecraft:cobbled_deepslate
setblock 508 33 279 minecraft:deepslate_tiles
setblock 509 33 277 minecraft:cobbled_deepslate
fill 509 33 278 509 34 278 minecraft:deepslate_tiles
setblock 509 33 281 minecraft:deepslate_tiles
setblock 509 33 282 minecraft:cobbled_deepslate
setblock 509 33 302 minecraft:cobbled_deepslate
fill 509 33 303 509 35 303 minecraft:deepslate_tiles
setblock 509 33 306 minecraft:deepslate_tiles
setblock 510 33 276 minecraft:cobbled_deepslate
fill 510 33 277 510 35 277 minecraft:deepslate_tiles
setblock 510 33 281 minecraft:cobbled_deepslate
fill 510 33 282 510 35 282 minecraft:deepslate_tiles
setblock 510 33 301 minecraft:cobbled_deepslate
fill 510 33 302 510 36 302 minecraft:deepslate_tiles
setblock 510 33 306 minecraft:cobbled_deepslate
fill 510 33 307 510 36 307 minecraft:deepslate_tiles
setblock 510 33 311 minecraft:cobbled_deepslate
fill 510 33 312 510 34 312 minecraft:deepslate_tiles
setblock 510 33 316 minecraft:cobbled_deepslate
fill 511 33 276 511 35 276 minecraft:deepslate_tiles
setblock 511 33 280 minecraft:cobbled_deepslate
fill 511 33 281 511 36 281 minecraft:deepslate_tiles
setblock 511 33 285 minecraft:cobbled_deepslate
setblock 511 33 296 minecraft:deepslate_tiles
setblock 511 33 300 minecraft:cobbled_deepslate
fill 511 33 301 511 36 301 minecraft:deepslate_tiles
setblock 511 33 305 minecraft:cobbled_deepslate
fill 511 33 306 511 36 306 minecraft:deepslate_tiles
setblock 511 33 310 minecraft:cobbled_deepslate
fill 511 33 311 511 36 311 minecraft:deepslate_tiles
setblock 511 33 315 minecraft:cobbled_deepslate
fill 511 33 316 511 36 316 minecraft:deepslate_tiles
setblock 471 34 279 minecraft:cobbled_deepslate
fill 471 34 280 471 35 280 minecraft:deepslate_tiles
setblock 471 34 284 minecraft:cobbled_deepslate
fill 471 34 295 471 34 298 minecraft:deepslate_tiles
setblock 471 34 299 minecraft:cobbled_deepslate
fill 471 34 300 471 37 300 minecraft:deepslate_tiles
setblock 471 34 304 minecraft:cobbled_deepslate
fill 471 34 305 471 37 305 minecraft:deepslate_tiles
setblock 471 34 309 minecraft:cobbled_deepslate
fill 471 34 310 471 37 310 minecraft:deepslate_tiles
setblock 471 34 314 minecraft:cobbled_deepslate
setblock 471 34 315 minecraft:deepslate_tiles
setblock 472 34 298 minecraft:cobbled_deepslate
fill 472 34 299 472 35 299 minecraft:deepslate_tiles
setblock 472 34 303 minecraft:cobbled_deepslate
fill 472 34 304 472 37 304 minecraft:deepslate_tiles
setblock 472 34 308 minecraft:cobbled_deepslate
fill 473 34 291 477 34 291 minecraft:white_wool
fill 473 34 295 478 34 295 minecraft:white_wool
setblock 473 34 302 minecraft:cobbled_deepslate
setblock 473 34 303 minecraft:deepslate_tiles
fill 478 34 293 478 34 294 minecraft:white_wool
setblock 479 34 276 minecraft:cobbled_deepslate
fill 480 34 276 480 35 276 minecraft:deepslate_tiles
setblock 483 34 277 minecraft:cobbled_deepslate
fill 483 34 278 483 35 278 minecraft:deepslate_tiles
setblock 484 34 276 minecraft:cobbled_deepslate
fill 484 34 277 484 37 277 minecraft:deepslate_tiles
setblock 484 34 316 minecraft:cobbled_deepslate
fill 485 34 276 485 37 276 minecraft:deepslate_tiles
setblock 485 34 316 minecraft:deepslate_tiles
setblock 486 34 279 minecraft:cobbled_deepslate
setblock 487 34 278 minecraft:cobbled_deepslate
setblock 487 34 279 minecraft:deepslate_tiles
setblock 488 34 277 minecraft:cobbled_deepslate
fill 488 34 278 488 35 278 minecraft:deepslate_tiles
setblock 489 34 276 minecraft:cobbled_deepslate
fill 489 34 277 489 36 277 minecraft:deepslate_tiles
fill 490 34 276 490 36 276 minecraft:deepslate_tiles
fill 491 34 317 491 45 317 minecraft:cobbled_deepslate
setblock 493 34 277 minecraft:cobbled_deepslate
setblock 494 34 276 minecraft:cobbled_deepslate
fill 494 34 277 494 35 277 minecraft:deepslate_tiles
fill 495 34 276 495 37 276 minecraft:deepslate_tiles
setblock 495 34 317 minecraft:white_wool
fill 496 34 317 498 41 317 minecraft:cobbled_deepslate
setblock 497 34 277 minecraft:deepslate_tiles
fill 497 34 278 497 38 278 minecraft:cobbled_deepslate
setblock 498 34 277 minecraft:cobbled_deepslate
fill 498 34 278 498 35 278 minecraft:deepslate_tiles
setblock 499 34 276 minecraft:cobbled_deepslate
fill 499 34 277 499 37 277 minecraft:deepslate_tiles
setblock 499 34 316 minecraft:cobbled_deepslate
fill 500 34 276 500 37 276 minecraft:deepslate_tiles
setblock 500 34 279 minecraft:deepslate_tiles
fill 500 34 316 500 37 316 minecraft:deepslate_tiles
setblock 501 34 279 minecraft:cobbled_deepslate
setblock 502 34 278 minecraft:cobbled_deepslate
fill 502 34 279 502 36 279 minecraft:deepslate_tiles
setblock 503 34 277 minecraft:cobbled_deepslate
fill 503 34 278 503 37 278 minecraft:deepslate_tiles
setblock 504 34 276 minecraft:cobbled_deepslate
fill 504 34 277 504 37 277 minecraft:deepslate_tiles
setblock 504 34 316 minecraft:cobbled_deepslate
fill 505 34 276 505 37 276 minecraft:deepslate_tiles
setblock 505 34 315 minecraft:cobbled_deepslate
fill 505 34 316 505 37 316 minecraft:deepslate_tiles
setblock 506 34 279 minecraft:cobbled_deepslate
fill 506 34 315 506 37 315 minecraft:deepslate_tiles
setblock 507 34 278 minecraft:cobbled_deepslate
setblock 507 34 279 minecraft:deepslate_tiles
setblock 508 34 277 minecraft:cobbled_deepslate
fill 508 34 278 508 35 278 minecraft:deepslate_tiles
setblock 509 34 276 minecraft:cobbled_deepslate
fill 509 34 277 509 36 277 minecraft:deepslate_tiles
setblock 509 34 281 minecraft:cobbled_deepslate
setblock 509 34 282 minecraft:deepslate_tiles
setblock 509 34 301 minecraft:cobbled_deepslate
setblock 509 34 302 minecraft:deepslate_tiles
fill 509 34 304 509 34 305 minecraft:deepslate_tiles
setblock 509 34 306 minecraft:cobbled_deepslate
setblock 509 34 316 minecraft:cobbled_deepslate
fill 510 34 276 510 36 276 minecraft:deepslate_tiles
setblock 510 34 280 minecraft:cobbled_deepslate
fill 510 34 281 510 35 281 minecraft:deepslate_tiles
setblock 510 34 300 minecraft:cobbled_deepslate
fill 510 34 301 510 36 301 minecraft:deepslate_tiles
setblock 510 34 304 minecraft:deepslate_tiles
setblock 510 34 305 minecraft:cobbled_deepslate
fill 510 34 306 510 37 306 minecraft:deepslate_tiles
setblock 510 34 310 minecraft:cobbled_deepslate
setblock 510 34 311 minecraft:deepslate_tiles
setblock 510 34 315 minecraft:cobbled_deepslate
fill 510 34 316 510 36 316 minecraft:deepslate_tiles
setblock 511 34 279 minecraft:cobbled_deepslate
fill 511 34 280 511 36 280 minecraft:deepslate_tiles
setblock 511 34 284 minecraft:cobbled_deepslate
setblock 511 34 285 minecraft:deepslate_tiles
setblock 511 34 299 minecraft:cobbled_deepslate
fill 511 34 300 511 37 300 minecraft:deepslate_tiles
setblock 511 34 304 minecraft:cobbled_deepslate
fill 511 34 305 511 37 305 minecraft:deepslate_tiles
setblock 511 34 309 minecraft:cobbled_deepslate
fill 511 34 310 511 37 310 minecraft:deepslate_tiles
setblock 511 34 314 minecraft:cobbled_deepslate
fill 511 34 315 511 35 315 minecraft:deepslate_tiles
setblock 471 35 279 minecraft:deepslate_tiles
setblock 471 35 283 minecraft:cobbled_deepslate
fill 471 35 296 471 35 297 minecraft:deepslate_tiles
setblock 471 35 298 minecraft:cobbled_deepslate
fill 471 35 299 471 38 299 minecraft:deepslate_tiles
setblock 471 35 303 minecraft:cobbled_deepslate
fill 471 35 304 471 38 304 minecraft:deepslate_tiles
setblock 471 35 308 minecraft:cobbled_deepslate
fill 471 35 309 471 38 309 minecraft:deepslate_tiles
setblock 472 35 302 minecraft:cobbled_deepslate
fill 472 35 303 472 38 303 minecraft:deepslate_tiles
setblock 472 35 307 minecraft:cobbled_deepslate
setblock 473 35 293 minecraft:white_wool
fill 473 35 295 477 35 295 minecraft:white_wool
setblock 482 35 277 minecraft:cobbled_deepslate
setblock 483 35 276 minecraft:cobbled_deepslate
fill 483 35 277 483 37 277 minecraft:deepslate_tiles
fill 484 35 276 484 38 276 minecraft:deepslate_tiles
setblock 485 35 278 minecraft:deepslate_tiles
setblock 486 35 278 minecraft:cobbled_deepslate
setblock 487 35 277 minecraft:cobbled_deepslate
setblock 487 35 278 minecraft:deepslate_tiles
setblock 488 35 276 minecraft:cobbled_deepslate
fill 488 35 277 488 36 277 minecraft:deepslate_tiles
fill 489 35 276 489 37 276 minecraft:deepslate_tiles
setblock 492 35 277 minecraft:cobbled_deepslate
setblock 493 35 276 minecraft:cobbled_deepslate
setblock 493 35 277 minecraft:deepslate_tiles
fill 494 35 276 494 36 276 minecraft:deepslate_tiles
fill 495 35 317 495 94 317 minecraft:cobbled_deepslate
setblock 497 35 277 minecraft:cobbled_deepslate
setblock 498 35 276 minecraft:cobbled_deepslate
fill 498 35 277 498 38 277 minecraft:deepslate_tiles
fill 499 35 276 499 38 276 minecraft:deepslate_tiles
fill 499 35 316 499 38 316 minecraft:deepslate_tiles
setblock 501 35 278 minecraft:cobbled_deepslate
setblock 501 35 279 minecraft:deepslate_tiles
setblock 502 35 277 minecraft:cobbled_deepslate
fill 502 35 278 502 38 278 minecraft:deepslate_tiles
setblock 503 35 276 minecraft:cobbled_deepslate
fill 503 35 277 503 38 277 minecraft:deepslate_tiles
setblock 503 35 316 minecraft:cobbled_deepslate
fill 504 35 276 504 38 276 minecraft:deepslate_tiles
setblock 504 35 315 minecraft:cobbled_deepslate
fill 504 35 316 504 38 316 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_2 1t
