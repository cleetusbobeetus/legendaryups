fill 424 57 470 424 60 470 minecraft:blackstone
setblock 424 57 474 minecraft:polished_blackstone_bricks
fill 424 57 475 424 60 475 minecraft:blackstone
setblock 424 57 479 minecraft:polished_blackstone_bricks
setblock 424 57 498 minecraft:blackstone
setblock 424 57 499 minecraft:polished_blackstone_bricks
setblock 429 57 504 minecraft:polished_blackstone_bricks
fill 430 57 464 433 57 464 minecraft:blackstone
fill 430 57 504 433 57 504 minecraft:blackstone
fill 431 57 503 434 57 503 minecraft:blackstone
fill 432 57 502 435 57 502 minecraft:blackstone
setblock 434 57 464 minecraft:polished_blackstone_bricks
setblock 434 57 504 minecraft:polished_blackstone_bricks
fill 435 57 464 435 60 464 minecraft:blackstone
fill 435 57 501 436 57 501 minecraft:blackstone
setblock 435 57 503 minecraft:polished_blackstone_bricks
fill 435 57 504 438 57 504 minecraft:blackstone
setblock 436 57 502 minecraft:polished_blackstone_bricks
fill 436 57 503 436 60 503 minecraft:blackstone
setblock 437 57 501 minecraft:polished_blackstone_bricks
fill 437 57 502 437 60 502 minecraft:blackstone
setblock 439 57 504 minecraft:polished_blackstone_bricks
setblock 440 57 503 minecraft:polished_blackstone_bricks
fill 440 57 504 440 60 504 minecraft:blackstone
fill 441 57 503 441 60 503 minecraft:blackstone
setblock 454 57 504 minecraft:polished_blackstone_bricks
fill 455 57 504 457 58 504 minecraft:blackstone
setblock 462 57 476 minecraft:polished_blackstone_bricks
fill 462 57 477 462 59 478 minecraft:blackstone
setblock 463 57 471 minecraft:blackstone
setblock 463 57 475 minecraft:polished_blackstone_bricks
fill 463 57 476 463 60 476 minecraft:blackstone
setblock 463 57 480 minecraft:polished_blackstone_bricks
setblock 464 57 469 minecraft:polished_blackstone_bricks
fill 464 57 470 464 60 470 minecraft:blackstone
setblock 464 57 474 minecraft:polished_blackstone_bricks
fill 464 57 475 464 60 475 minecraft:blackstone
setblock 464 57 479 minecraft:polished_blackstone_bricks
fill 464 57 480 464 60 480 minecraft:blackstone
fill 424 58 469 424 59 469 minecraft:blackstone
setblock 424 58 473 minecraft:polished_blackstone_bricks
fill 424 58 474 424 61 474 minecraft:blackstone
setblock 424 58 478 minecraft:polished_blackstone_bricks
fill 424 58 479 424 61 479 minecraft:blackstone
setblock 424 58 497 minecraft:blackstone
setblock 424 58 498 minecraft:polished_blackstone_bricks
fill 424 58 499 424 58 502 minecraft:blackstone
fill 426 58 504 427 58 504 minecraft:blackstone
setblock 428 58 464 minecraft:polished_blackstone_bricks
setblock 428 58 504 minecraft:polished_blackstone_bricks
fill 429 58 464 432 58 464 minecraft:blackstone
setblock 429 58 503 minecraft:polished_blackstone_bricks
fill 429 58 504 432 58 504 minecraft:blackstone
fill 430 58 503 433 58 503 minecraft:blackstone
fill 431 58 502 434 58 502 minecraft:blackstone
setblock 433 58 464 minecraft:polished_blackstone_bricks
fill 433 58 465 434 60 465 minecraft:blackstone
fill 433 58 501 435 58 501 minecraft:blackstone
setblock 433 58 504 minecraft:polished_blackstone_bricks
fill 434 58 464 434 61 464 minecraft:blackstone
setblock 434 58 503 minecraft:polished_blackstone_bricks
fill 434 58 504 437 58 504 minecraft:blackstone
setblock 435 58 502 minecraft:polished_blackstone_bricks
fill 435 58 503 435 61 503 minecraft:blackstone
setblock 436 58 501 minecraft:polished_blackstone_bricks
fill 436 58 502 436 61 502 minecraft:blackstone
fill 437 58 501 438 60 501 minecraft:blackstone
setblock 438 58 464 minecraft:polished_blackstone_bricks
setblock 438 58 504 minecraft:polished_blackstone_bricks
setblock 439 58 503 minecraft:polished_blackstone_bricks
fill 439 58 504 439 61 504 minecraft:blackstone
setblock 440 58 502 minecraft:polished_blackstone_bricks
fill 440 58 503 440 61 503 minecraft:blackstone
setblock 443 58 504 minecraft:polished_blackstone_bricks
fill 451 58 504 452 58 504 minecraft:blackstone
setblock 453 58 504 minecraft:polished_blackstone_bricks
fill 454 58 504 454 61 504 minecraft:blackstone
fill 455 58 503 455 61 503 minecraft:blackstone
fill 456 58 464 457 58 464 minecraft:blackstone
setblock 458 58 504 minecraft:polished_blackstone_bricks
setblock 462 58 475 minecraft:polished_blackstone_bricks
fill 462 58 476 462 61 476 minecraft:blackstone
setblock 462 58 479 minecraft:blackstone
setblock 463 58 474 minecraft:polished_blackstone_bricks
fill 463 58 475 463 61 475 minecraft:blackstone
setblock 463 58 478 minecraft:blackstone
setblock 463 58 479 minecraft:polished_blackstone_bricks
fill 463 58 480 463 61 480 minecraft:blackstone
fill 464 58 469 464 61 469 minecraft:blackstone
setblock 464 58 473 minecraft:polished_blackstone_bricks
fill 464 58 474 464 61 474 minecraft:blackstone
setblock 464 58 478 minecraft:polished_blackstone_bricks
fill 464 58 479 464 61 479 minecraft:blackstone
setblock 464 58 482 minecraft:blackstone
fill 424 59 464 426 59 464 minecraft:blackstone
setblock 424 59 472 minecraft:polished_blackstone_bricks
fill 424 59 473 424 62 473 minecraft:blackstone
setblock 424 59 477 minecraft:polished_blackstone_bricks
fill 424 59 478 424 62 478 minecraft:blackstone
fill 424 59 480 424 60 480 minecraft:blackstone
setblock 424 59 497 minecraft:polished_blackstone_bricks
fill 424 59 498 424 59 501 minecraft:blackstone
setblock 424 59 502 minecraft:polished_blackstone_bricks
fill 424 59 503 424 61 504 minecraft:blackstone
fill 425 59 504 426 59 504 minecraft:blackstone
setblock 427 59 464 minecraft:polished_blackstone_bricks
setblock 427 59 503 minecraft:blackstone
setblock 427 59 504 minecraft:polished_blackstone_bricks
fill 428 59 464 431 59 464 minecraft:blackstone
setblock 428 59 503 minecraft:polished_blackstone_bricks
fill 428 59 504 431 59 504 minecraft:blackstone
setblock 429 59 502 minecraft:polished_blackstone_bricks
fill 429 59 503 432 59 503 minecraft:blackstone
fill 430 59 502 433 59 502 minecraft:blackstone
setblock 431 59 465 minecraft:polished_blackstone_bricks
fill 431 59 501 434 59 501 minecraft:blackstone
setblock 432 59 464 minecraft:polished_blackstone_bricks
fill 432 59 465 432 62 465 minecraft:blackstone
setblock 432 59 504 minecraft:polished_blackstone_bricks
fill 433 59 464 433 62 464 minecraft:blackstone
setblock 433 59 503 minecraft:polished_blackstone_bricks
fill 433 59 504 436 59 504 minecraft:blackstone
fill 434 59 500 435 59 500 minecraft:blackstone
setblock 434 59 502 minecraft:polished_blackstone_bricks
fill 434 59 503 434 62 503 minecraft:blackstone
setblock 435 59 465 minecraft:blackstone
setblock 435 59 501 minecraft:polished_blackstone_bricks
fill 435 59 502 435 62 502 minecraft:blackstone
setblock 436 59 500 minecraft:polished_blackstone_bricks
fill 436 59 501 436 62 501 minecraft:blackstone
setblock 437 59 464 minecraft:polished_blackstone_bricks
setblock 437 59 504 minecraft:polished_blackstone_bricks
fill 438 59 464 439 61 464 minecraft:blackstone
setblock 438 59 502 minecraft:blackstone
setblock 438 59 503 minecraft:polished_blackstone_bricks
fill 438 59 504 438 62 504 minecraft:blackstone
setblock 439 59 501 minecraft:blackstone
setblock 439 59 502 minecraft:polished_blackstone_bricks
fill 439 59 503 439 62 503 minecraft:blackstone
fill 440 59 502 440 62 502 minecraft:blackstone
setblock 442 59 503 minecraft:blackstone
setblock 442 59 504 minecraft:polished_blackstone_bricks
fill 443 59 504 444 61 504 minecraft:blackstone
fill 448 59 504 451 59 504 minecraft:blackstone
fill 451 59 503 452 59 503 minecraft:blackstone
setblock 452 59 504 minecraft:polished_blackstone_bricks
fill 453 59 464 456 59 464 minecraft:blackstone
setblock 453 59 503 minecraft:polished_blackstone_bricks
fill 453 59 504 453 62 504 minecraft:blackstone
fill 454 59 503 454 62 503 minecraft:blackstone
fill 455 59 504 456 59 504 minecraft:blackstone
fill 456 59 503 457 59 503 minecraft:blackstone
setblock 457 59 464 minecraft:polished_blackstone_bricks
setblock 457 59 504 minecraft:polished_blackstone_bricks
fill 458 59 464 459 61 464 minecraft:blackstone
fill 458 59 504 459 61 504 minecraft:blackstone
setblock 462 59 474 minecraft:polished_blackstone_bricks
fill 462 59 475 462 60 475 minecraft:blackstone
setblock 462 59 479 minecraft:polished_blackstone_bricks
setblock 463 59 473 minecraft:polished_blackstone_bricks
fill 463 59 474 463 62 474 minecraft:blackstone
setblock 463 59 478 minecraft:polished_blackstone_bricks
fill 463 59 479 463 62 479 minecraft:blackstone
fill 463 59 481 463 60 481 minecraft:blackstone
setblock 464 59 472 minecraft:polished_blackstone_bricks
fill 464 59 473 464 62 473 minecraft:blackstone
setblock 464 59 477 minecraft:polished_blackstone_bricks
fill 464 59 478 464 62 478 minecraft:blackstone
setblock 464 59 482 minecraft:polished_blackstone_bricks
fill 464 59 483 464 62 483 minecraft:blackstone
fill 424 60 464 424 60 465 minecraft:blackstone
setblock 424 60 466 minecraft:polished_blackstone_bricks
setblock 424 60 471 minecraft:polished_blackstone_bricks
fill 424 60 472 424 61 472 minecraft:blackstone
setblock 424 60 476 minecraft:polished_blackstone_bricks
fill 424 60 477 424 63 477 minecraft:blackstone
setblock 424 60 481 minecraft:polished_blackstone_bricks
setblock 424 60 496 minecraft:polished_blackstone_bricks
fill 424 60 497 424 60 500 minecraft:blackstone
setblock 424 60 501 minecraft:polished_blackstone_bricks
fill 424 60 502 425 62 502 minecraft:blackstone
setblock 425 60 464 minecraft:blackstone
setblock 425 60 499 minecraft:blackstone
setblock 425 60 500 minecraft:polished_blackstone_bricks
fill 425 60 501 425 63 501 minecraft:blackstone
fill 425 60 503 425 60 504 minecraft:blackstone
setblock 426 60 464 minecraft:polished_blackstone_bricks
setblock 426 60 503 minecraft:blackstone
setblock 426 60 504 minecraft:polished_blackstone_bricks
fill 427 60 464 430 60 464 minecraft:blackstone
setblock 427 60 503 minecraft:polished_blackstone_bricks
fill 427 60 504 430 60 504 minecraft:blackstone
setblock 428 60 502 minecraft:polished_blackstone_bricks
fill 428 60 503 431 60 503 minecraft:blackstone
fill 429 60 502 432 60 502 minecraft:blackstone
setblock 430 60 465 minecraft:polished_blackstone_bricks
fill 430 60 501 433 60 501 minecraft:blackstone
setblock 431 60 464 minecraft:polished_blackstone_bricks
fill 431 60 465 431 63 465 minecraft:blackstone
setblock 431 60 504 minecraft:polished_blackstone_bricks
fill 432 60 464 432 63 464 minecraft:blackstone
setblock 432 60 503 minecraft:polished_blackstone_bricks
fill 432 60 504 435 60 504 minecraft:blackstone
fill 433 60 500 434 60 500 minecraft:blackstone
setblock 433 60 502 minecraft:polished_blackstone_bricks
fill 433 60 503 433 63 503 minecraft:blackstone
setblock 434 60 501 minecraft:polished_blackstone_bricks
fill 434 60 502 434 63 502 minecraft:blackstone
setblock 435 60 465 minecraft:polished_blackstone_bricks
setblock 435 60 500 minecraft:polished_blackstone_bricks
fill 435 60 501 435 63 501 minecraft:blackstone
setblock 436 60 464 minecraft:polished_blackstone_bricks
fill 436 60 500 436 61 500 minecraft:blackstone
setblock 436 60 504 minecraft:polished_blackstone_bricks
fill 437 60 464 437 63 464 minecraft:blackstone
setblock 437 60 503 minecraft:polished_blackstone_bricks
fill 437 60 504 437 63 504 minecraft:blackstone
setblock 438 60 502 minecraft:polished_blackstone_bricks
fill 438 60 503 438 63 503 minecraft:blackstone
setblock 439 60 501 minecraft:polished_blackstone_bricks
fill 439 60 502 439 63 502 minecraft:blackstone
fill 441 60 502 441 61 502 minecraft:blackstone
setblock 441 60 504 minecraft:polished_blackstone_bricks
setblock 442 60 503 minecraft:polished_blackstone_bricks
fill 442 60 504 442 63 504 minecraft:blackstone
fill 443 60 503 443 62 503 minecraft:blackstone
setblock 445 60 504 minecraft:blackstone
setblock 446 60 504 minecraft:polished_blackstone_bricks
fill 447 60 504 450 60 504 minecraft:blackstone
fill 449 60 503 451 60 503 minecraft:blackstone
setblock 451 60 504 minecraft:polished_blackstone_bricks
fill 452 60 464 455 60 464 minecraft:blackstone
setblock 452 60 502 minecraft:blackstone
setblock 452 60 503 minecraft:polished_blackstone_bricks
fill 452 60 504 452 63 504 minecraft:blackstone
setblock 453 60 502 minecraft:polished_blackstone_bricks
fill 453 60 503 453 63 503 minecraft:blackstone
fill 454 60 502 455 62 502 minecraft:blackstone
setblock 455 60 504 minecraft:blackstone
setblock 456 60 464 minecraft:polished_blackstone_bricks
setblock 456 60 503 minecraft:blackstone
setblock 456 60 504 minecraft:polished_blackstone_bricks
fill 457 60 464 457 63 464 minecraft:blackstone
setblock 457 60 503 minecraft:polished_blackstone_bricks
fill 457 60 504 457 63 504 minecraft:blackstone
fill 458 60 503 458 62 503 minecraft:blackstone
setblock 460 60 464 minecraft:blackstone
setblock 460 60 504 minecraft:blackstone
setblock 462 60 477 minecraft:blackstone
setblock 462 60 478 minecraft:polished_blackstone_bricks
fill 462 60 479 462 61 480 minecraft:blackstone
setblock 463 60 472 minecraft:polished_blackstone_bricks
fill 463 60 473 463 61 473 minecraft:blackstone
setblock 463 60 477 minecraft:polished_blackstone_bricks
fill 463 60 478 463 63 478 minecraft:blackstone
setblock 464 60 471 minecraft:polished_blackstone_bricks
fill 464 60 472 464 63 472 minecraft:blackstone
setblock 464 60 476 minecraft:polished_blackstone_bricks
fill 464 60 477 464 63 477 minecraft:blackstone
setblock 464 60 481 minecraft:polished_blackstone_bricks
fill 464 60 482 464 63 482 minecraft:blackstone
fill 464 60 499 464 60 500 minecraft:blackstone
setblock 464 60 501 minecraft:polished_blackstone_bricks
setblock 424 61 464 minecraft:blackstone
setblock 424 61 465 minecraft:polished_blackstone_bricks
fill 424 61 466 424 64 466 minecraft:blackstone
setblock 424 61 471 minecraft:blackstone
setblock 424 61 475 minecraft:polished_blackstone_bricks
fill 424 61 476 424 63 476 minecraft:blackstone
setblock 424 61 480 minecraft:polished_blackstone_bricks
fill 424 61 481 424 64 481 minecraft:blackstone
fill 424 61 497 424 61 499 minecraft:blackstone
setblock 424 61 500 minecraft:polished_blackstone_bricks
fill 424 61 501 424 64 501 minecraft:blackstone
setblock 425 61 464 minecraft:polished_blackstone_bricks
setblock 425 61 499 minecraft:polished_blackstone_bricks
fill 425 61 500 425 64 500 minecraft:blackstone
setblock 425 61 503 minecraft:blackstone
setblock 425 61 504 minecraft:polished_blackstone_bricks
fill 426 61 464 429 61 464 minecraft:blackstone
setblock 426 61 503 minecraft:polished_blackstone_bricks
fill 426 61 504 429 61 504 minecraft:blackstone
setblock 427 61 502 minecraft:polished_blackstone_bricks
fill 427 61 503 430 61 503 minecraft:blackstone
setblock 428 61 465 minecraft:blackstone
fill 428 61 502 431 61 502 minecraft:blackstone
setblock 429 61 465 minecraft:polished_blackstone_bricks
fill 429 61 501 432 61 501 minecraft:blackstone
setblock 430 61 464 minecraft:polished_blackstone_bricks
fill 430 61 465 430 64 465 minecraft:blackstone
setblock 430 61 504 minecraft:polished_blackstone_bricks
fill 431 61 464 431 64 464 minecraft:blackstone
setblock 431 61 503 minecraft:polished_blackstone_bricks
fill 431 61 504 434 61 504 minecraft:blackstone
fill 432 61 500 433 61 500 minecraft:blackstone
setblock 432 61 502 minecraft:polished_blackstone_bricks
fill 432 61 503 432 64 503 minecraft:blackstone
setblock 433 61 465 minecraft:blackstone
setblock 433 61 501 minecraft:polished_blackstone_bricks
fill 433 61 502 433 64 502 minecraft:blackstone
setblock 434 61 465 minecraft:polished_blackstone_bricks
setblock 434 61 500 minecraft:polished_blackstone_bricks
fill 434 61 501 434 64 501 minecraft:blackstone
setblock 435 61 464 minecraft:polished_blackstone_bricks
fill 435 61 465 435 63 465 minecraft:blackstone
fill 435 61 500 435 62 500 minecraft:blackstone
setblock 435 61 504 minecraft:polished_blackstone_bricks
fill 436 61 464 436 64 464 minecraft:blackstone
setblock 436 61 503 minecraft:polished_blackstone_bricks
fill 436 61 504 436 64 504 minecraft:blackstone
setblock 437 61 501 minecraft:blackstone
setblock 437 61 502 minecraft:polished_blackstone_bricks
fill 437 61 503 437 64 503 minecraft:blackstone
setblock 438 61 501 minecraft:polished_blackstone_bricks
fill 438 61 502 438 64 502 minecraft:blackstone
setblock 439 61 501 minecraft:blackstone
setblock 440 61 504 minecraft:polished_blackstone_bricks
setblock 441 61 503 minecraft:polished_blackstone_bricks
fill 441 61 504 441 64 504 minecraft:blackstone
fill 442 61 503 442 63 503 minecraft:blackstone
setblock 445 61 504 minecraft:polished_blackstone_bricks
fill 446 61 504 449 61 504 minecraft:blackstone
fill 447 61 503 450 61 503 minecraft:blackstone
setblock 450 61 504 minecraft:polished_blackstone_bricks
fill 451 61 464 454 61 464 minecraft:blackstone
setblock 451 61 502 minecraft:blackstone
setblock 451 61 503 minecraft:polished_blackstone_bricks
fill 451 61 504 451 64 504 minecraft:blackstone
setblock 452 61 502 minecraft:polished_blackstone_bricks
fill 452 61 503 452 64 503 minecraft:blackstone
fill 453 61 502 453 63 502 minecraft:blackstone
setblock 455 61 464 minecraft:polished_blackstone_bricks
setblock 455 61 504 minecraft:polished_blackstone_bricks
fill 456 61 464 456 64 464 minecraft:blackstone
setblock 456 61 503 minecraft:polished_blackstone_bricks
fill 456 61 504 456 64 504 minecraft:blackstone
fill 457 61 503 457 63 503 minecraft:blackstone
setblock 460 61 464 minecraft:polished_blackstone_bricks
setblock 460 61 504 minecraft:polished_blackstone_bricks
fill 461 61 464 462 63 464 minecraft:blackstone
fill 461 61 504 461 64 504 minecraft:blackstone
setblock 462 61 477 minecraft:polished_blackstone_bricks
fill 462 61 478 462 62 478 minecraft:blackstone
setblock 463 61 476 minecraft:polished_blackstone_bricks
fill 463 61 477 463 63 477 minecraft:blackstone
setblock 463 61 481 minecraft:polished_blackstone_bricks
fill 463 61 482 463 62 482 minecraft:blackstone
setblock 464 61 464 minecraft:blackstone
setblock 464 61 470 minecraft:polished_blackstone_bricks
fill 464 61 471 464 63 471 minecraft:blackstone
setblock 464 61 475 minecraft:polished_blackstone_bricks
fill 464 61 476 464 64 476 minecraft:blackstone
setblock 464 61 480 minecraft:polished_blackstone_bricks
fill 464 61 481 464 64 481 minecraft:blackstone
setblock 464 61 499 minecraft:blackstone
setblock 464 61 500 minecraft:polished_blackstone_bricks
fill 464 61 501 464 62 503 minecraft:blackstone
setblock 424 62 464 minecraft:polished_blackstone_bricks
fill 424 62 465 424 65 465 minecraft:blackstone
setblock 424 62 474 minecraft:polished_blackstone_bricks
fill 424 62 475 424 63 475 minecraft:blackstone
setblock 424 62 479 minecraft:polished_blackstone_bricks
fill 424 62 480 424 64 480 minecraft:blackstone
fill 424 62 497 424 62 498 minecraft:blackstone
setblock 424 62 499 minecraft:polished_blackstone_bricks
fill 424 62 500 424 65 500 minecraft:blackstone
setblock 424 62 503 minecraft:blackstone
setblock 424 62 504 minecraft:polished_blackstone_bricks
fill 425 62 464 428 62 464 minecraft:blackstone
fill 425 62 499 425 64 499 minecraft:blackstone
setblock 425 62 503 minecraft:polished_blackstone_bricks
fill 425 62 504 428 62 504 minecraft:blackstone
setblock 426 62 501 minecraft:blackstone
setblock 426 62 502 minecraft:polished_blackstone_bricks
fill 426 62 503 429 62 503 minecraft:blackstone
setblock 427 62 465 minecraft:blackstone
fill 427 62 502 430 62 502 minecraft:blackstone
setblock 428 62 465 minecraft:polished_blackstone_bricks
setblock 429 62 464 minecraft:polished_blackstone_bricks
fill 429 62 465 429 65 465 minecraft:blackstone
fill 429 62 501 431 62 501 minecraft:blackstone
setblock 429 62 504 minecraft:polished_blackstone_bricks
fill 430 62 464 430 65 464 minecraft:blackstone
setblock 430 62 503 minecraft:polished_blackstone_bricks
fill 430 62 504 433 62 504 minecraft:blackstone
fill 431 62 500 432 62 500 minecraft:blackstone
setblock 431 62 502 minecraft:polished_blackstone_bricks
fill 431 62 503 431 65 503 minecraft:blackstone
setblock 432 62 501 minecraft:polished_blackstone_bricks
fill 432 62 502 432 65 502 minecraft:blackstone
setblock 433 62 465 minecraft:polished_blackstone_bricks
setblock 433 62 500 minecraft:polished_blackstone_bricks
fill 433 62 501 433 65 501 minecraft:blackstone
setblock 434 62 464 minecraft:polished_blackstone_bricks
fill 434 62 465 434 65 465 minecraft:blackstone
fill 434 62 500 434 63 500 minecraft:blackstone
setblock 434 62 504 minecraft:polished_blackstone_bricks
fill 435 62 464 435 65 464 minecraft:blackstone
setblock 435 62 503 minecraft:polished_blackstone_bricks
fill 435 62 504 435 65 504 minecraft:blackstone
setblock 436 62 502 minecraft:polished_blackstone_bricks
fill 436 62 503 436 65 503 minecraft:blackstone
setblock 437 62 501 minecraft:polished_blackstone_bricks
fill 437 62 502 437 65 502 minecraft:blackstone
setblock 438 62 464 minecraft:blackstone
setblock 438 62 501 minecraft:blackstone
setblock 439 62 504 minecraft:polished_blackstone_bricks
setblock 440 62 503 minecraft:polished_blackstone_bricks
fill 440 62 504 440 65 504 minecraft:blackstone
fill 441 62 503 441 64 503 minecraft:blackstone
setblock 443 62 504 minecraft:blackstone
setblock 444 62 504 minecraft:polished_blackstone_bricks
fill 445 62 504 448 62 504 minecraft:blackstone
fill 446 62 503 449 62 503 minecraft:blackstone
setblock 449 62 504 minecraft:polished_blackstone_bricks
fill 450 62 464 453 62 464 minecraft:blackstone
setblock 450 62 502 minecraft:blackstone
setblock 450 62 503 minecraft:polished_blackstone_bricks
fill 450 62 504 450 65 504 minecraft:blackstone
setblock 451 62 502 minecraft:polished_blackstone_bricks
fill 451 62 503 451 65 503 minecraft:blackstone
fill 452 62 502 452 63 502 minecraft:blackstone
setblock 454 62 464 minecraft:polished_blackstone_bricks
setblock 454 62 504 minecraft:polished_blackstone_bricks
fill 455 62 464 455 65 464 minecraft:blackstone
setblock 455 62 503 minecraft:polished_blackstone_bricks
fill 455 62 504 455 65 504 minecraft:blackstone
fill 456 62 503 456 64 503 minecraft:blackstone
setblock 458 62 464 minecraft:blackstone
setblock 458 62 504 minecraft:blackstone
setblock 459 62 464 minecraft:polished_blackstone_bricks
setblock 459 62 504 minecraft:polished_blackstone_bricks
fill 460 62 464 460 65 464 minecraft:blackstone
fill 460 62 504 460 64 504 minecraft:blackstone
setblock 462 62 479 minecraft:blackstone
fill 462 62 504 463 62 504 minecraft:blackstone
setblock 463 62 464 minecraft:blackstone
setblock 463 62 475 minecraft:polished_blackstone_bricks
fill 463 62 476 463 63 476 minecraft:blackstone
setblock 463 62 480 minecraft:polished_blackstone_bricks
fill 463 62 481 463 64 481 minecraft:blackstone
setblock 464 62 464 minecraft:polished_blackstone_bricks
fill 464 62 465 464 64 466 minecraft:blackstone
setblock 464 62 470 minecraft:blackstone
setblock 464 62 474 minecraft:polished_blackstone_bricks
fill 464 62 475 464 65 475 minecraft:blackstone
setblock 464 62 479 minecraft:polished_blackstone_bricks
fill 464 62 480 464 65 480 minecraft:blackstone
setblock 464 62 484 minecraft:polished_blackstone_bricks
fill 464 62 500 464 63 500 minecraft:blackstone
setblock 464 62 504 minecraft:polished_blackstone_bricks
fill 424 63 464 427 63 464 minecraft:blackstone
setblock 424 63 478 minecraft:polished_blackstone_bricks
fill 424 63 479 424 64 479 minecraft:blackstone
setblock 424 63 497 minecraft:blackstone
setblock 424 63 498 minecraft:polished_blackstone_bricks
fill 424 63 499 424 66 499 minecraft:blackstone
setblock 424 63 502 minecraft:blackstone
setblock 424 63 503 minecraft:polished_blackstone_bricks
fill 424 63 504 427 63 504 minecraft:blackstone
setblock 425 63 502 minecraft:polished_blackstone_bricks
fill 425 63 503 428 63 503 minecraft:blackstone
setblock 426 63 501 minecraft:polished_blackstone_bricks
fill 426 63 502 429 63 502 minecraft:blackstone
setblock 427 63 465 minecraft:polished_blackstone_bricks
setblock 428 63 464 minecraft:polished_blackstone_bricks
fill 428 63 465 428 66 465 minecraft:blackstone
fill 428 63 501 430 63 501 minecraft:blackstone
setblock 428 63 504 minecraft:polished_blackstone_bricks
fill 429 63 464 429 66 464 minecraft:blackstone
setblock 429 63 503 minecraft:polished_blackstone_bricks
fill 429 63 504 432 63 504 minecraft:blackstone
setblock 430 63 502 minecraft:polished_blackstone_bricks
fill 430 63 503 430 66 503 minecraft:blackstone
setblock 431 63 501 minecraft:polished_blackstone_bricks
fill 431 63 502 431 66 502 minecraft:blackstone
setblock 432 63 465 minecraft:polished_blackstone_bricks
setblock 432 63 500 minecraft:polished_blackstone_bricks
fill 432 63 501 432 66 501 minecraft:blackstone
setblock 433 63 464 minecraft:polished_blackstone_bricks
fill 433 63 465 433 66 465 minecraft:blackstone
setblock 433 63 500 minecraft:blackstone
setblock 433 63 504 minecraft:polished_blackstone_bricks
fill 434 63 464 434 66 464 minecraft:blackstone
setblock 434 63 503 minecraft:polished_blackstone_bricks
fill 434 63 504 434 66 504 minecraft:blackstone
setblock 435 63 502 minecraft:polished_blackstone_bricks
fill 435 63 503 435 66 503 minecraft:blackstone
setblock 436 63 501 minecraft:polished_blackstone_bricks
fill 436 63 502 436 66 502 minecraft:blackstone
setblock 437 63 501 minecraft:blackstone
setblock 438 63 464 minecraft:polished_blackstone_bricks
setblock 438 63 504 minecraft:polished_blackstone_bricks
setblock 439 63 503 minecraft:polished_blackstone_bricks
fill 439 63 504 439 66 504 minecraft:blackstone
fill 440 63 503 440 64 503 minecraft:blackstone
setblock 443 63 504 minecraft:polished_blackstone_bricks
fill 444 63 504 447 63 504 minecraft:blackstone
fill 446 63 503 448 63 503 minecraft:blackstone
setblock 448 63 504 minecraft:polished_blackstone_bricks
fill 449 63 464 452 63 464 minecraft:blackstone
setblock 449 63 503 minecraft:polished_blackstone_bricks
fill 449 63 504 449 66 504 minecraft:blackstone
setblock 450 63 502 minecraft:polished_blackstone_bricks
fill 450 63 503 450 66 503 minecraft:blackstone
fill 451 63 502 451 64 502 minecraft:blackstone
setblock 453 63 464 minecraft:polished_blackstone_bricks
fill 453 63 465 455 64 465 minecraft:blackstone
setblock 453 63 504 minecraft:polished_blackstone_bricks
fill 454 63 464 454 66 464 minecraft:blackstone
setblock 454 63 502 minecraft:blackstone
setblock 454 63 503 minecraft:polished_blackstone_bricks
fill 454 63 504 454 66 504 minecraft:blackstone
fill 455 63 503 455 65 503 minecraft:blackstone
setblock 458 63 464 minecraft:polished_blackstone_bricks
setblock 458 63 504 minecraft:polished_blackstone_bricks
fill 459 63 464 459 66 464 minecraft:blackstone
fill 459 63 504 459 65 504 minecraft:blackstone
setblock 462 63 504 minecraft:blackstone
setblock 463 63 464 minecraft:polished_blackstone_bricks
setblock 463 63 475 minecraft:blackstone
setblock 463 63 479 minecraft:polished_blackstone_bricks
fill 463 63 480 463 64 480 minecraft:blackstone
setblock 463 63 504 minecraft:polished_blackstone_bricks
fill 464 63 464 464 66 464 minecraft:blackstone
setblock 464 63 467 minecraft:blackstone
setblock 464 63 473 minecraft:polished_blackstone_bricks
fill 464 63 474 464 64 474 minecraft:blackstone
setblock 464 63 478 minecraft:polished_blackstone_bricks
fill 464 63 479 464 66 479 minecraft:blackstone
setblock 464 63 483 minecraft:polished_blackstone_bricks
fill 464 63 484 464 66 484 minecraft:blackstone
fill 464 63 501 464 63 502 minecraft:blackstone
setblock 464 63 503 minecraft:polished_blackstone_bricks
fill 464 63 504 464 66 504 minecraft:blackstone
fill 424 64 464 426 64 464 minecraft:blackstone
setblock 424 64 478 minecraft:blackstone
fill 424 64 498 424 65 498 minecraft:blackstone
setblock 424 64 502 minecraft:polished_blackstone_bricks
fill 424 64 503 426 64 504 minecraft:blackstone
setblock 425 64 501 minecraft:polished_blackstone_bricks
fill 425 64 502 428 64 502 minecraft:blackstone
setblock 426 64 465 minecraft:polished_blackstone_bricks
setblock 426 64 466 minecraft:light[level=11]
setblock 426 64 474 minecraft:light[level=11]
setblock 426 64 482 minecraft:light[level=11]
setblock 426 64 490 minecraft:light[level=11]
setblock 426 64 498 minecraft:light[level=11]
fill 426 64 501 426 65 501 minecraft:blackstone
setblock 427 64 464 minecraft:polished_blackstone_bricks
fill 427 64 465 427 67 465 minecraft:blackstone
setblock 427 64 503 minecraft:blackstone
setblock 427 64 504 minecraft:polished_blackstone_bricks
fill 428 64 464 428 67 464 minecraft:blackstone
fill 428 64 501 429 64 501 minecraft:blackstone
setblock 428 64 503 minecraft:polished_blackstone_bricks
fill 428 64 504 431 64 504 minecraft:blackstone
setblock 429 64 502 minecraft:polished_blackstone_bricks
fill 429 64 503 429 67 503 minecraft:blackstone
setblock 430 64 501 minecraft:polished_blackstone_bricks
fill 430 64 502 430 67 502 minecraft:blackstone
setblock 431 64 465 minecraft:polished_blackstone_bricks
fill 431 64 501 431 66 501 minecraft:blackstone
setblock 432 64 464 minecraft:polished_blackstone_bricks
fill 432 64 465 432 67 465 minecraft:blackstone
setblock 432 64 504 minecraft:polished_blackstone_bricks
fill 433 64 464 433 67 464 minecraft:blackstone
setblock 433 64 503 minecraft:polished_blackstone_bricks
fill 433 64 504 433 67 504 minecraft:blackstone
setblock 434 64 466 minecraft:light[level=11]
setblock 434 64 474 minecraft:light[level=11]
setblock 434 64 482 minecraft:light[level=11]
setblock 434 64 490 minecraft:light[level=11]
setblock 434 64 498 minecraft:light[level=11]
setblock 434 64 502 minecraft:polished_blackstone_bricks
fill 434 64 503 434 67 503 minecraft:blackstone
setblock 435 64 501 minecraft:polished_blackstone_bricks
fill 435 64 502 435 66 502 minecraft:blackstone
setblock 436 64 501 minecraft:blackstone
setblock 437 64 464 minecraft:polished_blackstone_bricks
setblock 437 64 504 minecraft:polished_blackstone_bricks
setblock 438 64 503 minecraft:polished_blackstone_bricks
fill 438 64 504 438 67 504 minecraft:blackstone
fill 439 64 503 439 65 503 minecraft:blackstone
setblock 442 64 466 minecraft:light[level=11]
setblock 442 64 474 minecraft:light[level=11]
setblock 442 64 482 minecraft:light[level=11]
setblock 442 64 490 minecraft:light[level=11]
setblock 442 64 498 minecraft:light[level=11]
setblock 442 64 504 minecraft:polished_blackstone_bricks
fill 443 64 504 446 64 504 minecraft:blackstone
fill 446 64 503 447 64 503 minecraft:blackstone
setblock 447 64 504 minecraft:polished_blackstone_bricks
fill 448 64 464 451 64 464 minecraft:blackstone
setblock 448 64 503 minecraft:polished_blackstone_bricks
fill 448 64 504 448 67 504 minecraft:blackstone
fill 449 64 503 449 67 503 minecraft:blackstone
setblock 450 64 466 minecraft:light[level=11]
setblock 450 64 474 minecraft:light[level=11]
setblock 450 64 482 minecraft:light[level=11]
setblock 450 64 490 minecraft:light[level=11]
setblock 450 64 498 minecraft:light[level=11]
setblock 452 64 464 minecraft:polished_blackstone_bricks
fill 452 64 465 452 67 465 minecraft:blackstone
setblock 452 64 504 minecraft:polished_blackstone_bricks
fill 453 64 464 453 67 464 minecraft:blackstone
setblock 453 64 503 minecraft:polished_blackstone_bricks
fill 453 64 504 453 67 504 minecraft:blackstone
fill 454 64 503 454 65 503 minecraft:blackstone
setblock 457 64 464 minecraft:polished_blackstone_bricks
setblock 457 64 504 minecraft:polished_blackstone_bricks
fill 458 64 464 458 67 464 minecraft:blackstone
setblock 458 64 466 minecraft:light[level=11]
setblock 458 64 474 minecraft:light[level=11]
setblock 458 64 482 minecraft:light[level=11]
setblock 458 64 490 minecraft:light[level=11]
setblock 458 64 498 minecraft:light[level=11]
fill 458 64 504 458 65 504 minecraft:blackstone
setblock 461 64 464 minecraft:blackstone
setblock 462 64 464 minecraft:polished_blackstone_bricks
setblock 462 64 504 minecraft:polished_blackstone_bricks
fill 463 64 464 463 67 464 minecraft:blackstone
setblock 463 64 478 minecraft:polished_blackstone_bricks
setblock 463 64 479 minecraft:blackstone
fill 463 64 504 463 67 504 minecraft:blackstone
setblock 464 64 467 minecraft:polished_blackstone_bricks
setblock 464 64 473 minecraft:blackstone
setblock 464 64 477 minecraft:polished_blackstone_bricks
fill 464 64 478 464 67 478 minecraft:blackstone
setblock 464 64 482 minecraft:polished_blackstone_bricks
fill 464 64 483 464 67 483 minecraft:blackstone
setblock 464 64 501 minecraft:blackstone
setblock 464 64 502 minecraft:polished_blackstone_bricks
fill 464 64 503 464 67 503 minecraft:blackstone
fill 424 65 464 425 65 464 minecraft:blackstone
setblock 424 65 466 minecraft:polished_blackstone_bricks
setblock 424 65 501 minecraft:polished_blackstone_bricks
fill 424 65 502 425 65 504 minecraft:blackstone
setblock 425 65 500 minecraft:polished_blackstone_bricks
fill 425 65 501 425 68 501 minecraft:blackstone
setblock 426 65 464 minecraft:polished_blackstone_bricks
fill 426 65 465 426 68 465 minecraft:blackstone
fill 426 65 502 426 65 503 minecraft:blackstone
setblock 426 65 504 minecraft:polished_blackstone_bricks
fill 427 65 464 427 68 464 minecraft:blackstone
setblock 427 65 502 minecraft:blackstone
setblock 427 65 503 minecraft:polished_blackstone_bricks
fill 427 65 504 430 65 504 minecraft:blackstone
setblock 428 65 502 minecraft:polished_blackstone_bricks
fill 428 65 503 428 68 503 minecraft:blackstone
setblock 429 65 501 minecraft:polished_blackstone_bricks
fill 429 65 502 429 68 502 minecraft:blackstone
setblock 430 65 465 minecraft:polished_blackstone_bricks
fill 430 65 501 430 66 501 minecraft:blackstone
setblock 431 65 464 minecraft:polished_blackstone_bricks
fill 431 65 465 431 68 465 minecraft:blackstone
setblock 431 65 504 minecraft:polished_blackstone_bricks
fill 432 65 464 432 68 464 minecraft:blackstone
setblock 432 65 503 minecraft:polished_blackstone_bricks
fill 432 65 504 432 68 504 minecraft:blackstone
setblock 433 65 502 minecraft:polished_blackstone_bricks
fill 433 65 503 433 68 503 minecraft:blackstone
setblock 434 65 501 minecraft:polished_blackstone_bricks
fill 434 65 502 434 67 502 minecraft:blackstone
setblock 436 65 464 minecraft:polished_blackstone_bricks
setblock 436 65 504 minecraft:polished_blackstone_bricks
setblock 437 65 464 minecraft:blackstone
setblock 437 65 503 minecraft:polished_blackstone_bricks
fill 437 65 504 437 68 504 minecraft:blackstone
fill 438 65 503 438 66 503 minecraft:blackstone
setblock 441 65 504 minecraft:polished_blackstone_bricks
fill 442 65 504 445 65 504 minecraft:blackstone
setblock 446 65 504 minecraft:polished_blackstone_bricks
setblock 447 65 503 minecraft:polished_blackstone_bricks
fill 447 65 504 447 68 504 minecraft:blackstone
fill 448 65 464 450 65 464 minecraft:blackstone
fill 448 65 503 448 67 503 minecraft:blackstone
setblock 451 65 464 minecraft:polished_blackstone_bricks
fill 451 65 470 451 66 470 minecraft:cyan_stained_glass
setblock 451 65 504 minecraft:polished_blackstone_bricks
fill 452 65 464 452 68 464 minecraft:blackstone
setblock 452 65 503 minecraft:polished_blackstone_bricks
fill 452 65 504 452 68 504 minecraft:blackstone
fill 453 65 465 454 65 465 minecraft:blackstone
fill 453 65 503 453 66 503 minecraft:blackstone
setblock 456 65 464 minecraft:polished_blackstone_bricks
setblock 456 65 504 minecraft:polished_blackstone_bricks
fill 457 65 464 457 68 464 minecraft:blackstone
fill 457 65 504 457 66 504 minecraft:blackstone
setblock 461 65 464 minecraft:polished_blackstone_bricks
fill 462 65 464 462 68 464 minecraft:blackstone
setblock 462 65 504 minecraft:blackstone
setblock 464 65 465 minecraft:blackstone
setblock 464 65 466 minecraft:polished_blackstone_bricks
fill 464 65 467 464 68 467 minecraft:blackstone
setblock 464 65 476 minecraft:polished_blackstone_bricks
fill 464 65 477 464 66 477 minecraft:blackstone
setblock 464 65 481 minecraft:polished_blackstone_bricks
fill 464 65 482 464 68 482 minecraft:blackstone
setblock 464 65 501 minecraft:polished_blackstone_bricks
fill 464 65 502 464 68 502 minecraft:blackstone
setblock 424 66 464 minecraft:blackstone
setblock 424 66 465 minecraft:polished_blackstone_bricks
fill 424 66 466 424 68 467 minecraft:blackstone
setblock 424 66 500 minecraft:polished_blackstone_bricks
fill 424 66 501 424 66 504 minecraft:blackstone
setblock 425 66 464 minecraft:polished_blackstone_bricks
fill 425 66 465 425 69 465 minecraft:blackstone
fill 425 66 500 425 69 500 minecraft:blackstone
fill 425 66 502 425 66 503 minecraft:blackstone
setblock 425 66 504 minecraft:polished_blackstone_bricks
fill 426 66 464 426 69 464 minecraft:blackstone
setblock 426 66 502 minecraft:blackstone
setblock 426 66 503 minecraft:polished_blackstone_bricks
fill 426 66 504 429 66 504 minecraft:blackstone
setblock 427 66 502 minecraft:polished_blackstone_bricks
fill 427 66 503 427 69 503 minecraft:blackstone
fill 428 66 502 428 69 502 minecraft:blackstone
setblock 429 66 465 minecraft:polished_blackstone_bricks
setblock 429 66 501 minecraft:blackstone
setblock 430 66 464 minecraft:polished_blackstone_bricks
fill 430 66 465 430 69 465 minecraft:blackstone
setblock 430 66 504 minecraft:polished_blackstone_bricks
fill 431 66 464 431 69 464 minecraft:blackstone
setblock 431 66 503 minecraft:polished_blackstone_bricks
fill 431 66 504 431 69 504 minecraft:blackstone
setblock 432 66 502 minecraft:polished_blackstone_bricks
fill 432 66 503 432 69 503 minecraft:blackstone
setblock 433 66 501 minecraft:polished_blackstone_bricks
fill 433 66 502 433 68 502 minecraft:blackstone
setblock 435 66 464 minecraft:polished_blackstone_bricks
setblock 435 66 504 minecraft:polished_blackstone_bricks
fill 436 66 464 436 67 464 minecraft:blackstone
setblock 436 66 503 minecraft:polished_blackstone_bricks
fill 436 66 504 436 69 504 minecraft:blackstone
fill 437 66 503 437 67 503 minecraft:blackstone
setblock 440 66 504 minecraft:polished_blackstone_bricks
fill 441 66 504 444 66 504 minecraft:blackstone
fill 444 66 474 444 67 474 minecraft:light_blue_stained_glass
setblock 445 66 504 minecraft:polished_blackstone_bricks
fill 446 66 504 446 69 504 minecraft:blackstone
fill 447 66 464 449 66 464 minecraft:blackstone
setblock 450 66 464 minecraft:polished_blackstone_bricks
setblock 450 66 504 minecraft:polished_blackstone_bricks
fill 451 66 464 451 68 465 minecraft:blackstone
setblock 451 66 503 minecraft:polished_blackstone_bricks
fill 451 66 504 451 69 504 minecraft:blackstone
fill 452 66 503 452 67 503 minecraft:blackstone
setblock 453 66 465 minecraft:blackstone
setblock 454 66 465 minecraft:polished_blackstone_bricks
setblock 455 66 464 minecraft:polished_blackstone_bricks
setblock 455 66 504 minecraft:polished_blackstone_bricks
fill 456 66 464 456 69 464 minecraft:blackstone
fill 456 66 504 456 67 504 minecraft:blackstone
setblock 460 66 464 minecraft:polished_blackstone_bricks
fill 461 66 464 461 69 464 minecraft:blackstone
setblock 464 66 465 minecraft:polished_blackstone_bricks
fill 464 66 466 464 69 466 minecraft:blackstone
fill 464 66 468 464 67 468 minecraft:blackstone
setblock 464 66 480 minecraft:polished_blackstone_bricks
fill 464 66 481 464 69 481 minecraft:blackstone
setblock 424 67 464 minecraft:polished_blackstone_bricks
fill 424 67 465 424 70 465 minecraft:blackstone
setblock 424 67 499 minecraft:polished_blackstone_bricks
fill 424 67 500 424 67 503 minecraft:blackstone
setblock 424 67 504 minecraft:polished_blackstone_bricks
fill 425 67 464 425 70 464 minecraft:blackstone
setblock 425 67 502 minecraft:blackstone
setblock 425 67 503 minecraft:polished_blackstone_bricks
fill 425 67 504 428 67 504 minecraft:blackstone
setblock 426 67 502 minecraft:polished_blackstone_bricks
fill 426 67 503 426 70 503 minecraft:blackstone
fill 427 67 502 427 70 502 minecraft:blackstone
setblock 428 67 465 minecraft:polished_blackstone_bricks
setblock 429 67 464 minecraft:polished_blackstone_bricks
fill 429 67 465 429 70 465 minecraft:blackstone
setblock 429 67 504 minecraft:polished_blackstone_bricks
fill 430 67 464 430 70 464 minecraft:blackstone
setblock 430 67 503 minecraft:polished_blackstone_bricks
fill 430 67 504 430 70 504 minecraft:blackstone
setblock 431 67 502 minecraft:polished_blackstone_bricks
fill 431 67 503 431 70 503 minecraft:blackstone
fill 432 67 502 432 69 502 minecraft:blackstone
setblock 434 67 464 minecraft:polished_blackstone_bricks
setblock 434 67 504 minecraft:polished_blackstone_bricks
fill 435 67 464 435 70 464 minecraft:blackstone
setblock 435 67 503 minecraft:polished_blackstone_bricks
fill 435 67 504 435 70 504 minecraft:blackstone
fill 436 67 503 436 68 503 minecraft:blackstone
setblock 439 67 504 minecraft:polished_blackstone_bricks
setblock 440 67 504 minecraft:blackstone
setblock 443 67 504 minecraft:blackstone
setblock 444 67 504 minecraft:polished_blackstone_bricks
fill 445 67 504 445 70 504 minecraft:blackstone
fill 446 67 464 448 67 464 minecraft:blackstone
setblock 449 67 464 minecraft:polished_blackstone_bricks
setblock 449 67 504 minecraft:polished_blackstone_bricks
fill 450 67 464 450 69 465 minecraft:blackstone
setblock 450 67 503 minecraft:polished_blackstone_bricks
fill 450 67 504 450 70 504 minecraft:blackstone
setblock 451 67 503 minecraft:blackstone
setblock 453 67 465 minecraft:polished_blackstone_bricks
setblock 454 67 464 minecraft:polished_blackstone_bricks
fill 454 67 465 454 70 465 minecraft:blackstone
setblock 454 67 504 minecraft:polished_blackstone_bricks
fill 455 67 464 455 70 464 minecraft:blackstone
fill 455 67 504 455 68 504 minecraft:blackstone
setblock 459 67 464 minecraft:polished_blackstone_bricks
fill 460 67 464 460 70 464 minecraft:blackstone
setblock 464 67 464 minecraft:polished_blackstone_bricks
fill 464 67 465 464 70 465 minecraft:blackstone
setblock 464 67 479 minecraft:polished_blackstone_bricks
fill 464 67 480 464 69 480 minecraft:blackstone
setblock 464 67 484 minecraft:polished_blackstone_bricks
setblock 464 67 504 minecraft:polished_blackstone_bricks
fill 424 68 464 424 71 464 minecraft:blackstone
fill 424 68 499 424 68 502 minecraft:blackstone
setblock 424 68 503 minecraft:polished_blackstone_bricks
fill 424 68 504 427 68 504 minecraft:blackstone
setblock 425 68 466 minecraft:blackstone
setblock 425 68 502 minecraft:polished_blackstone_bricks
fill 425 68 503 425 71 503 minecraft:blackstone
fill 426 68 502 426 71 502 minecraft:blackstone
setblock 427 68 465 minecraft:polished_blackstone_bricks
setblock 428 68 464 minecraft:polished_blackstone_bricks
fill 428 68 465 428 71 465 minecraft:blackstone
setblock 428 68 504 minecraft:polished_blackstone_bricks
fill 429 68 464 429 71 464 minecraft:blackstone
setblock 429 68 503 minecraft:polished_blackstone_bricks
fill 429 68 504 429 71 504 minecraft:blackstone
setblock 430 68 502 minecraft:polished_blackstone_bricks
fill 430 68 503 430 71 503 minecraft:blackstone
fill 431 68 502 431 71 502 minecraft:blackstone
setblock 432 68 465 minecraft:polished_blackstone_bricks
setblock 433 68 464 minecraft:polished_blackstone_bricks
setblock 433 68 504 minecraft:polished_blackstone_bricks
fill 434 68 464 434 71 464 minecraft:blackstone
setblock 434 68 503 minecraft:polished_blackstone_bricks
fill 434 68 504 434 71 504 minecraft:blackstone
fill 435 68 503 435 69 503 minecraft:blackstone
setblock 438 68 504 minecraft:polished_blackstone_bricks
setblock 439 68 504 minecraft:blackstone
fill 444 68 504 444 71 504 minecraft:blackstone
fill 446 68 464 447 68 464 minecraft:blackstone
setblock 448 68 464 minecraft:polished_blackstone_bricks
setblock 448 68 504 minecraft:polished_blackstone_bricks
fill 449 68 464 449 70 465 minecraft:blackstone
fill 449 68 504 449 71 504 minecraft:blackstone
setblock 452 68 465 minecraft:polished_blackstone_bricks
setblock 453 68 464 minecraft:polished_blackstone_bricks
fill 453 68 465 453 71 465 minecraft:blackstone
setblock 453 68 504 minecraft:polished_blackstone_bricks
fill 454 68 464 454 71 464 minecraft:blackstone
fill 454 68 504 454 70 504 minecraft:blackstone
setblock 458 68 464 minecraft:polished_blackstone_bricks
fill 459 68 464 459 71 464 minecraft:blackstone
setblock 463 68 464 minecraft:polished_blackstone_bricks
fill 463 68 465 463 71 465 minecraft:blackstone
setblock 463 68 504 minecraft:polished_blackstone_bricks
fill 464 68 464 464 71 464 minecraft:blackstone
setblock 464 68 468 minecraft:polished_blackstone_bricks
fill 464 68 469 464 71 469 minecraft:blackstone
setblock 464 68 483 minecraft:polished_blackstone_bricks
fill 464 68 484 464 71 484 minecraft:blackstone
setblock 464 68 503 minecraft:polished_blackstone_bricks
fill 464 68 504 464 71 504 minecraft:blackstone
setblock 424 69 466 minecraft:blackstone
setblock 424 69 467 minecraft:polished_blackstone_bricks
fill 424 69 468 424 72 468 minecraft:blackstone
fill 424 69 484 424 69 486 minecraft:blackstone
fill 424 69 499 424 69 501 minecraft:blackstone
setblock 424 69 502 minecraft:polished_blackstone_bricks
fill 424 69 503 424 71 504 minecraft:blackstone
setblock 425 69 466 minecraft:polished_blackstone_bricks
setblock 425 69 501 minecraft:polished_blackstone_bricks
fill 425 69 502 425 72 502 minecraft:blackstone
fill 425 69 504 426 69 504 minecraft:blackstone
setblock 426 69 465 minecraft:polished_blackstone_bricks
setblock 427 69 464 minecraft:polished_blackstone_bricks
fill 427 69 465 427 72 465 minecraft:blackstone
setblock 427 69 504 minecraft:polished_blackstone_bricks
fill 428 69 464 428 72 464 minecraft:blackstone
setblock 428 69 503 minecraft:polished_blackstone_bricks
fill 428 69 504 428 72 504 minecraft:blackstone
setblock 429 69 502 minecraft:polished_blackstone_bricks
fill 429 69 503 429 72 503 minecraft:blackstone
fill 430 69 502 430 72 502 minecraft:blackstone
setblock 431 69 465 minecraft:polished_blackstone_bricks
setblock 432 69 464 minecraft:polished_blackstone_bricks
fill 432 69 465 432 72 465 minecraft:blackstone
setblock 432 69 504 minecraft:polished_blackstone_bricks
fill 433 69 464 433 72 464 minecraft:blackstone
setblock 433 69 503 minecraft:polished_blackstone_bricks
fill 433 69 504 433 72 504 minecraft:blackstone
fill 434 69 503 434 70 503 minecraft:blackstone
setblock 437 69 504 minecraft:polished_blackstone_bricks
setblock 438 69 504 minecraft:blackstone
fill 445 69 464 446 69 464 minecraft:blackstone
setblock 447 69 464 minecraft:polished_blackstone_bricks
setblock 447 69 504 minecraft:polished_blackstone_bricks
fill 448 69 464 448 71 465 minecraft:blackstone
fill 448 69 504 448 72 504 minecraft:blackstone
setblock 451 69 464 minecraft:blackstone
setblock 451 69 465 minecraft:polished_blackstone_bricks
setblock 452 69 464 minecraft:polished_blackstone_bricks
fill 452 69 465 452 72 465 minecraft:blackstone
setblock 452 69 504 minecraft:polished_blackstone_bricks
fill 453 69 464 453 72 464 minecraft:blackstone
fill 453 69 504 453 72 504 minecraft:blackstone
setblock 457 69 464 minecraft:polished_blackstone_bricks
fill 458 69 464 458 72 464 minecraft:blackstone
setblock 462 69 464 minecraft:polished_blackstone_bricks
fill 462 69 465 462 72 465 minecraft:blackstone
setblock 462 69 504 minecraft:polished_blackstone_bricks
fill 463 69 464 463 72 464 minecraft:blackstone
fill 463 69 466 463 70 466 minecraft:blackstone
fill 463 69 504 463 72 504 minecraft:blackstone
setblock 464 69 467 minecraft:polished_blackstone_bricks
fill 464 69 468 464 72 468 minecraft:blackstone
fill 464 69 470 464 70 470 minecraft:blackstone
setblock 464 69 482 minecraft:polished_blackstone_bricks
fill 464 69 483 464 72 483 minecraft:blackstone
fill 464 69 485 464 70 485 minecraft:blackstone
setblock 464 69 502 minecraft:polished_blackstone_bricks
fill 464 69 503 464 72 503 minecraft:blackstone
setblock 424 70 466 minecraft:polished_blackstone_bricks
fill 424 70 467 425 72 467 minecraft:blackstone
fill 424 70 469 424 71 469 minecraft:blackstone
fill 424 70 483 424 70 485 minecraft:blackstone
setblock 424 70 486 minecraft:polished_blackstone_bricks
fill 424 70 487 424 71 489 minecraft:blackstone
fill 424 70 498 424 70 500 minecraft:blackstone
setblock 424 70 501 minecraft:polished_blackstone_bricks
fill 424 70 502 424 73 502 minecraft:blackstone
setblock 425 70 465 minecraft:polished_blackstone_bricks
fill 425 70 466 425 73 466 minecraft:blackstone
setblock 425 70 500 minecraft:polished_blackstone_bricks
fill 425 70 501 425 73 501 minecraft:blackstone
setblock 425 70 504 minecraft:blackstone
setblock 426 70 464 minecraft:polished_blackstone_bricks
fill 426 70 465 426 73 465 minecraft:blackstone
setblock 426 70 504 minecraft:polished_blackstone_bricks
fill 427 70 464 427 73 464 minecraft:blackstone
setblock 427 70 503 minecraft:polished_blackstone_bricks
fill 427 70 504 427 73 504 minecraft:blackstone
setblock 428 70 502 minecraft:polished_blackstone_bricks
fill 428 70 503 428 73 503 minecraft:blackstone
fill 429 70 502 429 73 502 minecraft:blackstone
setblock 430 70 465 minecraft:polished_blackstone_bricks
setblock 431 70 464 minecraft:polished_blackstone_bricks
fill 431 70 465 431 73 465 minecraft:blackstone
setblock 431 70 504 minecraft:polished_blackstone_bricks
fill 432 70 464 432 73 464 minecraft:blackstone
setblock 432 70 503 minecraft:polished_blackstone_bricks
fill 432 70 504 432 73 504 minecraft:blackstone
fill 433 70 503 433 72 503 minecraft:blackstone
setblock 436 70 504 minecraft:polished_blackstone_bricks
setblock 437 70 504 minecraft:blackstone
fill 443 70 504 443 72 504 minecraft:blackstone
fill 444 70 464 445 70 464 minecraft:blackstone
setblock 446 70 464 minecraft:polished_blackstone_bricks
fill 446 70 465 447 72 465 minecraft:blackstone
setblock 446 70 504 minecraft:polished_blackstone_bricks
fill 447 70 464 447 73 464 minecraft:blackstone
fill 447 70 504 447 73 504 minecraft:blackstone
setblock 450 70 464 minecraft:blackstone
setblock 450 70 465 minecraft:polished_blackstone_bricks
setblock 451 70 464 minecraft:polished_blackstone_bricks
fill 451 70 465 451 73 465 minecraft:blackstone
setblock 451 70 504 minecraft:polished_blackstone_bricks
fill 452 70 464 452 73 464 minecraft:blackstone
fill 452 70 504 452 73 504 minecraft:blackstone
setblock 455 70 465 minecraft:polished_blackstone_bricks
setblock 456 70 464 minecraft:polished_blackstone_bricks
fill 457 70 464 457 73 464 minecraft:blackstone
setblock 460 70 465 minecraft:polished_blackstone_bricks
setblock 461 70 464 minecraft:polished_blackstone_bricks
fill 461 70 465 461 73 465 minecraft:blackstone
fill 462 70 464 462 73 464 minecraft:blackstone
fill 462 70 504 462 73 504 minecraft:blackstone
setblock 463 70 467 minecraft:polished_blackstone_bricks
fill 463 70 468 463 73 468 minecraft:blackstone
setblock 464 70 466 minecraft:polished_blackstone_bricks
fill 464 70 467 464 73 467 minecraft:blackstone
setblock 464 70 471 minecraft:polished_blackstone_bricks
fill 464 70 472 464 73 472 minecraft:blackstone
setblock 464 70 481 minecraft:polished_blackstone_bricks
fill 464 70 482 464 73 482 minecraft:blackstone
setblock 464 70 486 minecraft:polished_blackstone_bricks
fill 464 70 487 464 73 487 minecraft:blackstone
fill 464 70 502 464 73 502 minecraft:blackstone
setblock 424 71 465 minecraft:polished_blackstone_bricks
fill 424 71 466 424 74 466 minecraft:blackstone
setblock 424 71 470 minecraft:polished_blackstone_bricks
fill 424 71 482 424 71 484 minecraft:blackstone
setblock 424 71 485 minecraft:polished_blackstone_bricks
fill 424 71 486 425 73 486 minecraft:blackstone
setblock 424 71 490 minecraft:polished_blackstone_bricks
fill 424 71 491 424 71 494 minecraft:blackstone
setblock 424 71 495 minecraft:polished_blackstone_bricks
fill 424 71 496 424 71 499 minecraft:blackstone
setblock 424 71 500 minecraft:polished_blackstone_bricks
fill 424 71 501 424 74 501 minecraft:blackstone
setblock 425 71 464 minecraft:polished_blackstone_bricks
fill 425 71 465 425 74 465 minecraft:blackstone
setblock 425 71 468 minecraft:blackstone
setblock 425 71 484 minecraft:polished_blackstone_bricks
fill 425 71 485 425 74 485 minecraft:blackstone
fill 425 71 487 425 71 488 minecraft:blackstone
setblock 425 71 489 minecraft:polished_blackstone_bricks
fill 425 71 490 425 74 490 minecraft:blackstone
setblock 425 71 499 minecraft:polished_blackstone_bricks
fill 425 71 500 425 74 500 minecraft:blackstone
setblock 425 71 504 minecraft:polished_blackstone_bricks
fill 426 71 464 426 74 464 minecraft:blackstone
fill 426 71 466 427 71 466 minecraft:blackstone
fill 426 71 501 426 72 501 minecraft:blackstone
setblock 426 71 503 minecraft:polished_blackstone_bricks
fill 426 71 504 426 74 504 minecraft:blackstone
setblock 427 71 502 minecraft:polished_blackstone_bricks
fill 427 71 503 427 74 503 minecraft:blackstone
setblock 428 71 466 minecraft:polished_blackstone_bricks
fill 428 71 502 428 74 502 minecraft:blackstone
setblock 429 71 465 minecraft:polished_blackstone_bricks
fill 429 71 466 429 74 466 minecraft:blackstone
fill 429 71 494 429 72 494 minecraft:light_blue_stained_glass
setblock 430 71 464 minecraft:polished_blackstone_bricks
fill 430 71 465 430 74 465 minecraft:blackstone
setblock 430 71 504 minecraft:polished_blackstone_bricks
fill 431 71 464 431 74 464 minecraft:blackstone
setblock 431 71 503 minecraft:polished_blackstone_bricks
fill 431 71 504 431 74 504 minecraft:blackstone
fill 432 71 503 432 74 503 minecraft:blackstone
setblock 435 71 464 minecraft:polished_blackstone_bricks
setblock 435 71 504 minecraft:polished_blackstone_bricks
fill 436 71 504 436 72 504 minecraft:blackstone
fill 443 71 464 444 71 464 minecraft:blackstone
setblock 445 71 464 minecraft:polished_blackstone_bricks
fill 445 71 465 445 74 465 minecraft:blackstone
setblock 445 71 504 minecraft:polished_blackstone_bricks
fill 446 71 464 446 74 464 minecraft:blackstone
fill 446 71 504 446 74 504 minecraft:blackstone
setblock 449 71 464 minecraft:blackstone
setblock 449 71 465 minecraft:polished_blackstone_bricks
fill 449 71 466 451 72 466 minecraft:blackstone
setblock 450 71 464 minecraft:polished_blackstone_bricks
fill 450 71 465 450 74 465 minecraft:blackstone
setblock 450 71 504 minecraft:polished_blackstone_bricks
fill 451 71 464 451 74 464 minecraft:blackstone
fill 451 71 504 451 74 504 minecraft:blackstone
setblock 454 71 465 minecraft:polished_blackstone_bricks
setblock 455 71 464 minecraft:polished_blackstone_bricks
fill 455 71 465 458 71 465 minecraft:blackstone
fill 456 71 464 456 74 464 minecraft:blackstone
setblock 459 71 465 minecraft:polished_blackstone_bricks
setblock 460 71 464 minecraft:polished_blackstone_bricks
fill 460 71 465 460 74 465 minecraft:blackstone
fill 461 71 464 461 74 464 minecraft:blackstone
fill 461 71 504 461 74 504 minecraft:blackstone
setblock 463 71 466 minecraft:polished_blackstone_bricks
fill 463 71 467 463 74 467 minecraft:blackstone
fill 463 71 469 463 72 469 minecraft:blackstone
setblock 464 71 465 minecraft:polished_blackstone_bricks
fill 464 71 466 464 74 466 minecraft:blackstone
setblock 464 71 470 minecraft:polished_blackstone_bricks
fill 464 71 471 464 74 471 minecraft:blackstone
fill 464 71 473 464 72 473 minecraft:blackstone
setblock 464 71 480 minecraft:polished_blackstone_bricks
fill 464 71 481 464 74 481 minecraft:blackstone
setblock 464 71 485 minecraft:polished_blackstone_bricks
fill 464 71 486 464 74 486 minecraft:blackstone
fill 464 71 488 464 71 489 minecraft:blackstone
fill 464 71 501 464 74 501 minecraft:blackstone
setblock 424 72 464 minecraft:polished_blackstone_bricks
fill 424 72 465 424 75 465 minecraft:blackstone
setblock 424 72 469 minecraft:polished_blackstone_bricks
fill 424 72 470 424 73 472 minecraft:blackstone
fill 424 72 481 424 72 483 minecraft:blackstone
setblock 424 72 484 minecraft:polished_blackstone_bricks
fill 424 72 485 424 75 485 minecraft:blackstone
fill 424 72 487 424 72 488 minecraft:blackstone
setblock 424 72 489 minecraft:polished_blackstone_bricks
fill 424 72 490 424 72 493 minecraft:blackstone
setblock 424 72 494 minecraft:polished_blackstone_bricks
fill 424 72 495 424 72 498 minecraft:blackstone
setblock 424 72 499 minecraft:polished_blackstone_bricks
fill 424 72 500 424 75 500 minecraft:blackstone
setblock 424 72 503 minecraft:blackstone
setblock 424 72 504 minecraft:polished_blackstone_bricks
fill 425 72 464 425 75 464 minecraft:blackstone
setblock 425 72 468 minecraft:polished_blackstone_bricks
fill 425 72 469 425 74 470 minecraft:blackstone
setblock 425 72 483 minecraft:polished_blackstone_bricks
fill 425 72 484 425 75 484 minecraft:blackstone
setblock 425 72 487 minecraft:blackstone
setblock 425 72 488 minecraft:polished_blackstone_bricks
fill 425 72 489 426 74 489 minecraft:blackstone
fill 425 72 491 425 72 492 minecraft:blackstone
setblock 425 72 493 minecraft:polished_blackstone_bricks
fill 425 72 494 425 74 495 minecraft:blackstone
setblock 425 72 497 minecraft:blackstone
setblock 425 72 498 minecraft:polished_blackstone_bricks
fill 425 72 499 425 75 499 minecraft:blackstone
setblock 425 72 503 minecraft:polished_blackstone_bricks
fill 425 72 504 425 75 504 minecraft:blackstone
setblock 426 72 466 minecraft:blackstone
setblock 426 72 467 minecraft:polished_blackstone_bricks
setblock 426 72 474 minecraft:light[level=11]
setblock 426 72 482 minecraft:light[level=11]
setblock 426 72 486 minecraft:blackstone
setblock 426 72 487 minecraft:polished_blackstone_bricks
fill 426 72 488 426 75 488 minecraft:blackstone
fill 426 72 490 426 73 490 minecraft:blackstone
setblock 426 72 498 minecraft:light[level=11]
setblock 426 72 502 minecraft:polished_blackstone_bricks
fill 426 72 503 426 75 503 minecraft:blackstone
setblock 427 72 466 minecraft:polished_blackstone_bricks
fill 427 72 502 427 75 502 minecraft:blackstone
setblock 428 72 465 minecraft:polished_blackstone_bricks
fill 428 72 466 428 75 466 minecraft:blackstone
setblock 429 72 464 minecraft:polished_blackstone_bricks
fill 429 72 465 429 75 465 minecraft:blackstone
setblock 429 72 504 minecraft:polished_blackstone_bricks
fill 430 72 464 430 75 464 minecraft:blackstone
setblock 430 72 503 minecraft:polished_blackstone_bricks
fill 430 72 504 430 75 504 minecraft:blackstone
fill 431 72 503 431 75 503 minecraft:blackstone
setblock 434 72 464 minecraft:polished_blackstone_bricks
setblock 434 72 466 minecraft:light[level=11]
setblock 434 72 474 minecraft:light[level=11]
setblock 434 72 482 minecraft:light[level=11]
setblock 434 72 490 minecraft:light[level=11]
setblock 434 72 498 minecraft:light[level=11]
setblock 434 72 504 minecraft:polished_blackstone_bricks
fill 435 72 464 435 73 464 minecraft:blackstone
fill 435 72 504 435 74 504 minecraft:blackstone
fill 441 72 464 443 72 464 minecraft:blackstone
setblock 442 72 466 minecraft:light[level=11]
setblock 442 72 474 minecraft:light[level=11]
setblock 442 72 482 minecraft:light[level=11]
setblock 442 72 490 minecraft:light[level=11]
setblock 442 72 498 minecraft:light[level=11]
fill 442 72 504 442 73 504 minecraft:blackstone
setblock 444 72 464 minecraft:polished_blackstone_bricks
fill 444 72 465 444 75 465 minecraft:blackstone
setblock 444 72 504 minecraft:polished_blackstone_bricks
fill 445 72 464 445 75 464 minecraft:blackstone
fill 445 72 504 445 75 504 minecraft:blackstone
setblock 447 72 466 minecraft:polished_blackstone_bricks
setblock 448 72 464 minecraft:blackstone
setblock 448 72 465 minecraft:polished_blackstone_bricks
fill 448 72 466 448 75 466 minecraft:blackstone
setblock 449 72 464 minecraft:polished_blackstone_bricks
fill 449 72 465 449 75 465 minecraft:blackstone
setblock 449 72 504 minecraft:polished_blackstone_bricks
fill 450 72 464 450 75 464 minecraft:blackstone
setblock 450 72 474 minecraft:light[level=11]
setblock 450 72 482 minecraft:light[level=11]
setblock 450 72 490 minecraft:light[level=11]
setblock 450 72 498 minecraft:light[level=11]
fill 450 72 504 450 75 504 minecraft:blackstone
setblock 452 72 466 minecraft:polished_blackstone_bricks
setblock 453 72 465 minecraft:polished_blackstone_bricks
setblock 454 72 464 minecraft:polished_blackstone_bricks
fill 454 72 465 457 72 465 minecraft:blackstone
fill 455 72 464 455 75 464 minecraft:blackstone
setblock 458 72 465 minecraft:polished_blackstone_bricks
setblock 458 72 466 minecraft:light[level=11]
setblock 458 72 474 minecraft:light[level=11]
setblock 458 72 482 minecraft:light[level=11]
setblock 458 72 490 minecraft:light[level=11]
setblock 458 72 498 minecraft:light[level=11]
setblock 459 72 464 minecraft:polished_blackstone_bricks
fill 459 72 465 459 75 465 minecraft:blackstone
fill 460 72 464 460 75 464 minecraft:blackstone
fill 460 72 504 460 75 504 minecraft:blackstone
setblock 461 72 466 minecraft:blackstone
setblock 462 72 466 minecraft:polished_blackstone_bricks
fill 462 72 467 462 75 467 minecraft:blackstone
setblock 463 72 465 minecraft:polished_blackstone_bricks
fill 463 72 466 463 75 466 minecraft:blackstone
setblock 463 72 470 minecraft:polished_blackstone_bricks
fill 463 72 471 463 75 471 minecraft:blackstone
setblock 464 72 464 minecraft:polished_blackstone_bricks
fill 464 72 465 464 75 465 minecraft:blackstone
setblock 464 72 469 minecraft:polished_blackstone_bricks
fill 464 72 470 464 75 470 minecraft:blackstone
setblock 464 72 474 minecraft:polished_blackstone_bricks
fill 464 72 475 464 75 475 minecraft:blackstone
fill 464 72 480 464 75 480 minecraft:blackstone
setblock 464 72 484 minecraft:polished_blackstone_bricks
fill 464 72 485 464 75 485 minecraft:blackstone
setblock 464 72 488 minecraft:blackstone
setblock 464 72 489 minecraft:polished_blackstone_bricks
fill 464 72 490 464 74 491 minecraft:blackstone
fill 464 72 500 464 75 500 minecraft:blackstone
setblock 464 72 504 minecraft:polished_blackstone_bricks
fill 424 73 464 424 76 464 minecraft:blackstone
setblock 424 73 467 minecraft:blackstone
setblock 424 73 468 minecraft:polished_blackstone_bricks
fill 424 73 469 424 76 469 minecraft:blackstone
setblock 424 73 473 minecraft:polished_blackstone_bricks
fill 424 73 481 424 73 482 minecraft:blackstone
setblock 424 73 483 minecraft:polished_blackstone_bricks
fill 424 73 484 424 76 484 minecraft:blackstone
setblock 424 73 487 minecraft:blackstone
setblock 424 73 488 minecraft:polished_blackstone_bricks
fill 424 73 489 424 73 492 minecraft:blackstone
setblock 424 73 493 minecraft:polished_blackstone_bricks
fill 424 73 494 424 73 497 minecraft:blackstone
setblock 424 73 498 minecraft:polished_blackstone_bricks
fill 424 73 499 424 76 499 minecraft:blackstone
setblock 424 73 503 minecraft:polished_blackstone_bricks
fill 424 73 504 424 76 504 minecraft:blackstone
setblock 425 73 467 minecraft:polished_blackstone_bricks
fill 425 73 468 426 75 468 minecraft:blackstone
setblock 425 73 471 minecraft:blackstone
fill 425 73 483 425 76 483 minecraft:blackstone
setblock 425 73 487 minecraft:polished_blackstone_bricks
fill 425 73 488 425 76 488 minecraft:blackstone
setblock 425 73 491 minecraft:blackstone
setblock 425 73 492 minecraft:polished_blackstone_bricks
fill 425 73 493 426 75 493 minecraft:blackstone
setblock 425 73 496 minecraft:blackstone
setblock 425 73 497 minecraft:polished_blackstone_bricks
fill 425 73 498 425 76 498 minecraft:blackstone
setblock 425 73 502 minecraft:polished_blackstone_bricks
fill 425 73 503 425 76 503 minecraft:blackstone
setblock 426 73 466 minecraft:polished_blackstone_bricks
fill 426 73 467 426 76 467 minecraft:blackstone
setblock 426 73 485 minecraft:blackstone
setblock 426 73 486 minecraft:polished_blackstone_bricks
fill 426 73 487 426 76 487 minecraft:blackstone
setblock 426 73 491 minecraft:polished_blackstone_bricks
fill 426 73 492 426 76 492 minecraft:blackstone
fill 426 73 494 426 74 494 minecraft:blackstone
setblock 426 73 500 minecraft:blackstone
setblock 426 73 501 minecraft:polished_blackstone_bricks
fill 426 73 502 426 76 502 minecraft:blackstone
setblock 427 73 465 minecraft:polished_blackstone_bricks
fill 427 73 466 427 76 466 minecraft:blackstone
setblock 428 73 464 minecraft:polished_blackstone_bricks
fill 428 73 465 428 76 465 minecraft:blackstone
setblock 428 73 504 minecraft:polished_blackstone_bricks
fill 429 73 464 429 76 464 minecraft:blackstone
setblock 429 73 503 minecraft:polished_blackstone_bricks
fill 429 73 504 429 76 504 minecraft:blackstone
fill 430 73 503 430 76 503 minecraft:blackstone
setblock 432 73 465 minecraft:polished_blackstone_bricks
setblock 433 73 464 minecraft:polished_blackstone_bricks
setblock 433 73 504 minecraft:polished_blackstone_bricks
fill 434 73 464 434 75 464 minecraft:blackstone
fill 434 73 504 434 75 504 minecraft:blackstone
fill 440 73 464 442 73 464 minecraft:blackstone
setblock 443 73 464 minecraft:polished_blackstone_bricks
fill 443 73 465 443 76 465 minecraft:blackstone
setblock 443 73 504 minecraft:polished_blackstone_bricks
fill 444 73 464 444 76 464 minecraft:blackstone
fill 444 73 504 444 76 504 minecraft:blackstone
setblock 445 73 466 minecraft:blackstone
setblock 446 73 465 minecraft:blackstone
setblock 446 73 466 minecraft:polished_blackstone_bricks
setblock 447 73 465 minecraft:polished_blackstone_bricks
fill 447 73 466 447 76 466 minecraft:blackstone
setblock 448 73 464 minecraft:polished_blackstone_bricks
fill 448 73 465 448 76 465 minecraft:blackstone
setblock 448 73 504 minecraft:polished_blackstone_bricks
fill 449 73 464 449 76 464 minecraft:blackstone
fill 449 73 466 450 73 466 minecraft:blackstone
fill 449 73 504 449 76 504 minecraft:blackstone
setblock 451 73 466 minecraft:polished_blackstone_bricks
setblock 452 73 465 minecraft:polished_blackstone_bricks
fill 452 73 466 453 75 466 minecraft:blackstone
setblock 453 73 464 minecraft:polished_blackstone_bricks
fill 453 73 465 456 73 465 minecraft:blackstone
fill 454 73 464 454 76 464 minecraft:blackstone
setblock 457 73 465 minecraft:polished_blackstone_bricks
setblock 458 73 464 minecraft:polished_blackstone_bricks
fill 458 73 465 458 76 465 minecraft:blackstone
fill 459 73 464 459 76 464 minecraft:blackstone
setblock 460 73 466 minecraft:blackstone
setblock 461 73 466 minecraft:polished_blackstone_bricks
setblock 462 73 465 minecraft:polished_blackstone_bricks
fill 462 73 466 462 76 466 minecraft:blackstone
fill 462 73 468 462 73 469 minecraft:blackstone
setblock 463 73 464 minecraft:polished_blackstone_bricks
fill 463 73 465 463 76 465 minecraft:blackstone
setblock 463 73 469 minecraft:polished_blackstone_bricks
fill 463 73 470 463 76 470 minecraft:blackstone
fill 463 73 472 463 74 472 minecraft:blackstone
fill 463 73 486 463 74 487 minecraft:blackstone
setblock 463 73 503 minecraft:blackstone
setblock 463 73 504 minecraft:polished_blackstone_bricks
fill 464 73 464 464 76 464 minecraft:blackstone
setblock 464 73 468 minecraft:polished_blackstone_bricks
fill 464 73 469 464 76 469 minecraft:blackstone
setblock 464 73 473 minecraft:polished_blackstone_bricks
fill 464 73 474 464 76 474 minecraft:blackstone
fill 464 73 476 464 73 477 minecraft:blackstone
setblock 464 73 478 minecraft:polished_blackstone_bricks
fill 464 73 479 464 76 479 minecraft:blackstone
setblock 464 73 483 minecraft:polished_blackstone_bricks
fill 464 73 484 464 76 484 minecraft:blackstone
setblock 464 73 488 minecraft:polished_blackstone_bricks
fill 464 73 489 464 76 489 minecraft:blackstone
setblock 464 73 492 minecraft:blackstone
setblock 464 73 493 minecraft:polished_blackstone_bricks
fill 464 73 494 464 76 494 minecraft:blackstone
fill 464 73 499 464 76 499 minecraft:blackstone
setblock 464 73 503 minecraft:polished_blackstone_bricks
fill 464 73 504 464 76 504 minecraft:blackstone
setblock 424 74 467 minecraft:polished_blackstone_bricks
fill 424 74 468 424 77 468 minecraft:blackstone
fill 424 74 470 424 74 471 minecraft:blackstone
setblock 424 74 472 minecraft:polished_blackstone_bricks
fill 424 74 473 424 76 474 minecraft:blackstone
fill 424 74 480 424 74 481 minecraft:blackstone
setblock 424 74 482 minecraft:polished_blackstone_bricks
fill 424 74 483 424 77 483 minecraft:blackstone
setblock 424 74 486 minecraft:blackstone
setblock 424 74 487 minecraft:polished_blackstone_bricks
fill 424 74 488 424 74 491 minecraft:blackstone
setblock 424 74 492 minecraft:polished_blackstone_bricks
fill 424 74 493 424 74 496 minecraft:blackstone
setblock 424 74 497 minecraft:polished_blackstone_bricks
fill 424 74 498 424 77 498 minecraft:blackstone
setblock 424 74 502 minecraft:polished_blackstone_bricks
fill 424 74 503 424 77 503 minecraft:blackstone
setblock 425 74 466 minecraft:polished_blackstone_bricks
fill 425 74 467 425 77 467 minecraft:blackstone
setblock 425 74 471 minecraft:polished_blackstone_bricks
fill 425 74 472 425 77 472 minecraft:blackstone
setblock 425 74 486 minecraft:polished_blackstone_bricks
fill 425 74 487 425 77 487 minecraft:blackstone
setblock 425 74 491 minecraft:polished_blackstone_bricks
fill 425 74 492 425 77 492 minecraft:blackstone
setblock 425 74 496 minecraft:polished_blackstone_bricks
fill 425 74 497 426 76 497 minecraft:blackstone
setblock 425 74 501 minecraft:polished_blackstone_bricks
fill 425 74 502 425 77 502 minecraft:blackstone
setblock 426 74 465 minecraft:polished_blackstone_bricks
fill 426 74 466 426 77 466 minecraft:blackstone
setblock 426 74 469 minecraft:blackstone
setblock 426 74 485 minecraft:polished_blackstone_bricks
fill 426 74 486 426 77 486 minecraft:blackstone
setblock 426 74 490 minecraft:polished_blackstone_bricks
fill 426 74 491 427 76 491 minecraft:blackstone
setblock 426 74 495 minecraft:polished_blackstone_bricks
fill 426 74 496 426 77 496 minecraft:blackstone
fill 426 74 498 426 74 499 minecraft:blackstone
setblock 426 74 500 minecraft:polished_blackstone_bricks
fill 426 74 501 426 77 501 minecraft:blackstone
setblock 427 74 464 minecraft:polished_blackstone_bricks
fill 427 74 465 427 77 465 minecraft:blackstone
fill 427 74 487 427 74 488 minecraft:blackstone
setblock 427 74 489 minecraft:polished_blackstone_bricks
fill 427 74 490 427 77 490 minecraft:blackstone
fill 427 74 492 427 75 492 minecraft:blackstone
setblock 427 74 504 minecraft:polished_blackstone_bricks
fill 428 74 464 428 77 464 minecraft:blackstone
setblock 428 74 503 minecraft:polished_blackstone_bricks
fill 428 74 504 428 77 504 minecraft:blackstone
setblock 429 74 502 minecraft:polished_blackstone_bricks
fill 429 74 503 429 77 503 minecraft:blackstone
setblock 431 74 465 minecraft:polished_blackstone_bricks
setblock 432 74 464 minecraft:polished_blackstone_bricks
setblock 432 74 465 minecraft:blackstone
setblock 432 74 504 minecraft:polished_blackstone_bricks
fill 433 74 464 433 75 464 minecraft:blackstone
fill 433 74 504 433 75 504 minecraft:blackstone
fill 439 74 464 441 74 464 minecraft:blackstone
setblock 442 74 464 minecraft:polished_blackstone_bricks
fill 442 74 465 442 77 465 minecraft:blackstone
setblock 442 74 504 minecraft:polished_blackstone_bricks
fill 443 74 464 443 77 464 minecraft:blackstone
fill 443 74 504 443 77 504 minecraft:blackstone
setblock 444 74 466 minecraft:blackstone
setblock 445 74 466 minecraft:polished_blackstone_bricks
setblock 446 74 465 minecraft:polished_blackstone_bricks
fill 446 74 466 446 77 466 minecraft:blackstone
setblock 447 74 464 minecraft:polished_blackstone_bricks
fill 447 74 465 447 77 465 minecraft:blackstone
fill 447 74 467 448 74 467 minecraft:blackstone
setblock 447 74 504 minecraft:polished_blackstone_bricks
fill 448 74 464 448 77 464 minecraft:blackstone
fill 448 74 504 448 77 504 minecraft:blackstone
setblock 449 74 466 minecraft:blackstone
setblock 449 74 467 minecraft:polished_blackstone_bricks
setblock 450 74 466 minecraft:polished_blackstone_bricks
setblock 451 74 465 minecraft:polished_blackstone_bricks
fill 451 74 466 451 77 466 minecraft:blackstone
setblock 452 74 464 minecraft:polished_blackstone_bricks
fill 452 74 465 455 74 465 minecraft:blackstone
setblock 452 74 504 minecraft:polished_blackstone_bricks
fill 453 74 464 453 77 464 minecraft:blackstone
setblock 454 74 466 minecraft:blackstone
setblock 456 74 465 minecraft:polished_blackstone_bricks
setblock 457 74 464 minecraft:polished_blackstone_bricks
fill 457 74 465 457 77 465 minecraft:blackstone
fill 458 74 464 458 77 464 minecraft:blackstone
fill 458 74 466 459 74 466 minecraft:blackstone
fill 459 74 504 459 76 504 minecraft:blackstone
setblock 460 74 466 minecraft:polished_blackstone_bricks
setblock 461 74 465 minecraft:polished_blackstone_bricks
fill 461 74 466 461 77 466 minecraft:blackstone
setblock 462 74 464 minecraft:polished_blackstone_bricks
fill 462 74 465 462 77 465 minecraft:blackstone
setblock 462 74 468 minecraft:blackstone
setblock 462 74 469 minecraft:polished_blackstone_bricks
fill 462 74 470 462 76 471 minecraft:blackstone
setblock 462 74 504 minecraft:polished_blackstone_bricks
fill 463 74 464 463 77 464 minecraft:blackstone
setblock 463 74 468 minecraft:polished_blackstone_bricks
fill 463 74 469 463 77 469 minecraft:blackstone
setblock 463 74 473 minecraft:polished_blackstone_bricks
fill 463 74 485 463 76 485 minecraft:blackstone
setblock 463 74 488 minecraft:polished_blackstone_bricks
fill 463 74 489 463 75 491 minecraft:blackstone
setblock 463 74 502 minecraft:blackstone
setblock 463 74 503 minecraft:polished_blackstone_bricks
fill 463 74 504 463 77 504 minecraft:blackstone
setblock 464 74 467 minecraft:polished_blackstone_bricks
fill 464 74 468 464 77 468 minecraft:blackstone
setblock 464 74 472 minecraft:polished_blackstone_bricks
fill 464 74 473 464 77 473 minecraft:blackstone
setblock 464 74 476 minecraft:blackstone
setblock 464 74 477 minecraft:polished_blackstone_bricks
fill 464 74 478 464 77 478 minecraft:blackstone
setblock 464 74 482 minecraft:polished_blackstone_bricks
fill 464 74 483 464 77 483 minecraft:blackstone
setblock 464 74 487 minecraft:polished_blackstone_bricks
fill 464 74 488 464 77 488 minecraft:blackstone
setblock 464 74 492 minecraft:polished_blackstone_bricks
fill 464 74 493 464 77 493 minecraft:blackstone
fill 464 74 495 464 74 496 minecraft:blackstone
setblock 464 74 497 minecraft:polished_blackstone_bricks
fill 464 74 498 464 77 498 minecraft:blackstone
setblock 464 74 502 minecraft:polished_blackstone_bricks
fill 464 74 503 464 77 503 minecraft:blackstone
setblock 424 75 466 minecraft:polished_blackstone_bricks
fill 424 75 467 424 78 467 minecraft:blackstone
setblock 424 75 470 minecraft:blackstone
setblock 424 75 471 minecraft:polished_blackstone_bricks
fill 424 75 472 424 78 472 minecraft:blackstone
setblock 424 75 475 minecraft:blackstone
setblock 424 75 476 minecraft:polished_blackstone_bricks
setblock 424 75 480 minecraft:blackstone
setblock 424 75 481 minecraft:polished_blackstone_bricks
fill 424 75 482 424 78 482 minecraft:blackstone
setblock 424 75 486 minecraft:polished_blackstone_bricks
fill 424 75 487 424 75 490 minecraft:blackstone
setblock 424 75 491 minecraft:polished_blackstone_bricks
fill 424 75 492 424 75 495 minecraft:blackstone
setblock 424 75 496 minecraft:polished_blackstone_bricks
fill 424 75 497 424 78 497 minecraft:blackstone
setblock 424 75 501 minecraft:polished_blackstone_bricks
fill 424 75 502 424 78 502 minecraft:blackstone
setblock 425 75 465 minecraft:polished_blackstone_bricks
fill 425 75 466 425 78 466 minecraft:blackstone
setblock 425 75 469 minecraft:blackstone
setblock 425 75 470 minecraft:polished_blackstone_bricks
fill 425 75 471 425 78 471 minecraft:blackstone
fill 425 75 473 425 76 473 minecraft:blackstone
setblock 425 75 485 minecraft:polished_blackstone_bricks
fill 425 75 486 425 78 486 minecraft:blackstone
setblock 425 75 489 minecraft:blackstone
setblock 425 75 490 minecraft:polished_blackstone_bricks
fill 425 75 491 425 78 491 minecraft:blackstone
setblock 425 75 494 minecraft:blackstone
setblock 425 75 495 minecraft:polished_blackstone_bricks
fill 425 75 496 425 78 496 minecraft:blackstone
setblock 425 75 500 minecraft:polished_blackstone_bricks
fill 425 75 501 425 78 501 minecraft:blackstone
setblock 426 75 464 minecraft:polished_blackstone_bricks
fill 426 75 465 426 78 465 minecraft:blackstone
setblock 426 75 469 minecraft:polished_blackstone_bricks
fill 426 75 470 426 77 470 minecraft:blackstone
fill 426 75 485 426 76 485 minecraft:blackstone
setblock 426 75 489 minecraft:polished_blackstone_bricks
fill 426 75 490 426 78 490 minecraft:blackstone
setblock 426 75 494 minecraft:polished_blackstone_bricks
fill 426 75 495 426 78 495 minecraft:blackstone
setblock 426 75 498 minecraft:blackstone
setblock 426 75 499 minecraft:polished_blackstone_bricks
fill 426 75 500 426 77 500 minecraft:blackstone
setblock 426 75 504 minecraft:polished_blackstone_bricks
fill 427 75 464 427 78 464 minecraft:blackstone
setblock 427 75 487 minecraft:blackstone
setblock 427 75 488 minecraft:polished_blackstone_bricks
fill 427 75 489 427 78 489 minecraft:blackstone
setblock 427 75 493 minecraft:polished_blackstone_bricks
fill 427 75 494 427 78 494 minecraft:blackstone
setblock 427 75 503 minecraft:polished_blackstone_bricks
fill 427 75 504 427 78 504 minecraft:blackstone
setblock 428 75 502 minecraft:polished_blackstone_bricks
fill 428 75 503 428 78 503 minecraft:blackstone
setblock 429 75 466 minecraft:polished_blackstone_bricks
setblock 430 75 465 minecraft:polished_blackstone_bricks
setblock 431 75 464 minecraft:polished_blackstone_bricks
setblock 431 75 465 minecraft:blackstone
setblock 431 75 504 minecraft:polished_blackstone_bricks
fill 432 75 464 432 76 464 minecraft:blackstone
fill 432 75 504 432 76 504 minecraft:blackstone
fill 439 75 464 440 75 464 minecraft:blackstone
setblock 441 75 464 minecraft:polished_blackstone_bricks
fill 441 75 465 441 78 465 minecraft:blackstone
fill 442 75 464 442 78 464 minecraft:blackstone
fill 442 75 504 442 77 504 minecraft:blackstone
setblock 443 75 466 minecraft:blackstone
setblock 444 75 466 minecraft:polished_blackstone_bricks
setblock 445 75 465 minecraft:polished_blackstone_bricks
fill 445 75 466 445 78 466 minecraft:blackstone
setblock 446 75 464 minecraft:polished_blackstone_bricks
fill 446 75 465 446 78 465 minecraft:blackstone
fill 446 75 467 447 75 467 minecraft:blackstone
setblock 446 75 504 minecraft:polished_blackstone_bricks
fill 447 75 464 447 78 464 minecraft:blackstone
fill 447 75 504 447 77 504 minecraft:blackstone
setblock 448 75 467 minecraft:polished_blackstone_bricks
setblock 449 75 466 minecraft:polished_blackstone_bricks
fill 449 75 467 450 75 467 minecraft:blackstone
setblock 450 75 465 minecraft:polished_blackstone_bricks
fill 450 75 466 450 77 466 minecraft:blackstone
setblock 451 75 464 minecraft:polished_blackstone_bricks
fill 451 75 465 454 75 465 minecraft:blackstone
setblock 451 75 504 minecraft:polished_blackstone_bricks
fill 452 75 464 452 78 464 minecraft:blackstone
setblock 454 75 466 minecraft:polished_blackstone_bricks
setblock 455 75 465 minecraft:polished_blackstone_bricks
fill 455 75 466 458 75 466 minecraft:blackstone
setblock 456 75 464 minecraft:polished_blackstone_bricks
fill 456 75 465 456 78 465 minecraft:blackstone
fill 457 75 464 457 78 464 minecraft:blackstone
setblock 459 75 466 minecraft:polished_blackstone_bricks
setblock 460 75 465 minecraft:polished_blackstone_bricks
fill 460 75 466 460 78 466 minecraft:blackstone
setblock 461 75 464 minecraft:polished_blackstone_bricks
fill 461 75 465 461 78 465 minecraft:blackstone
fill 461 75 467 461 75 468 minecraft:blackstone
setblock 461 75 504 minecraft:polished_blackstone_bricks
fill 462 75 464 462 78 464 minecraft:blackstone
setblock 462 75 468 minecraft:polished_blackstone_bricks
fill 462 75 469 462 78 469 minecraft:blackstone
setblock 462 75 472 minecraft:blackstone
setblock 462 75 503 minecraft:polished_blackstone_bricks
fill 462 75 504 462 78 504 minecraft:blackstone
setblock 463 75 467 minecraft:polished_blackstone_bricks
fill 463 75 468 463 78 468 minecraft:blackstone
setblock 463 75 472 minecraft:polished_blackstone_bricks
fill 463 75 473 463 77 474 minecraft:blackstone
setblock 463 75 486 minecraft:blackstone
setblock 463 75 487 minecraft:polished_blackstone_bricks
fill 463 75 488 463 78 488 minecraft:blackstone
setblock 463 75 492 minecraft:polished_blackstone_bricks
fill 463 75 493 463 78 493 minecraft:blackstone
setblock 463 75 502 minecraft:polished_blackstone_bricks
fill 463 75 503 463 78 503 minecraft:blackstone
setblock 464 75 466 minecraft:polished_blackstone_bricks
fill 464 75 467 464 78 467 minecraft:blackstone
setblock 464 75 471 minecraft:polished_blackstone_bricks
fill 464 75 472 464 78 472 minecraft:blackstone
setblock 464 75 476 minecraft:polished_blackstone_bricks
fill 464 75 477 464 78 477 minecraft:blackstone
setblock 464 75 481 minecraft:polished_blackstone_bricks
fill 464 75 482 464 77 482 minecraft:blackstone
setblock 464 75 486 minecraft:polished_blackstone_bricks
fill 464 75 487 464 78 487 minecraft:blackstone
setblock 464 75 490 minecraft:blackstone
setblock 464 75 491 minecraft:polished_blackstone_bricks
fill 464 75 492 464 78 492 minecraft:blackstone
setblock 464 75 495 minecraft:blackstone
setblock 464 75 496 minecraft:polished_blackstone_bricks
fill 464 75 497 464 78 497 minecraft:blackstone
setblock 464 75 501 minecraft:polished_blackstone_bricks
fill 464 75 502 464 78 502 minecraft:blackstone
setblock 424 76 465 minecraft:polished_blackstone_bricks
fill 424 76 466 424 79 466 minecraft:blackstone
setblock 424 76 470 minecraft:polished_blackstone_bricks
fill 424 76 471 424 79 471 minecraft:blackstone
setblock 424 76 475 minecraft:polished_blackstone_bricks
fill 424 76 476 424 78 477 minecraft:blackstone
setblock 424 76 480 minecraft:polished_blackstone_bricks
fill 424 76 481 424 78 481 minecraft:blackstone
setblock 424 76 485 minecraft:polished_blackstone_bricks
fill 424 76 486 424 76 489 minecraft:blackstone
setblock 424 76 490 minecraft:polished_blackstone_bricks
fill 424 76 491 424 76 494 minecraft:blackstone
setblock 424 76 495 minecraft:polished_blackstone_bricks
fill 424 76 496 424 79 496 minecraft:blackstone
setblock 424 76 500 minecraft:polished_blackstone_bricks
fill 424 76 501 424 79 501 minecraft:blackstone
setblock 425 76 464 minecraft:polished_blackstone_bricks
fill 425 76 465 425 79 465 minecraft:blackstone
setblock 425 76 468 minecraft:blackstone
setblock 425 76 469 minecraft:polished_blackstone_bricks
fill 425 76 470 425 79 470 minecraft:blackstone
setblock 425 76 484 minecraft:polished_blackstone_bricks
fill 425 76 485 425 79 485 minecraft:blackstone
setblock 425 76 489 minecraft:polished_blackstone_bricks
fill 425 76 490 425 79 490 minecraft:blackstone
setblock 425 76 493 minecraft:blackstone
setblock 425 76 494 minecraft:polished_blackstone_bricks
fill 425 76 495 425 79 495 minecraft:blackstone
setblock 425 76 499 minecraft:polished_blackstone_bricks
fill 425 76 500 425 79 500 minecraft:blackstone
setblock 425 76 504 minecraft:polished_blackstone_bricks
fill 426 76 464 426 79 464 minecraft:blackstone
setblock 426 76 468 minecraft:polished_blackstone_bricks
fill 426 76 469 426 80 469 minecraft:blackstone
setblock 426 76 488 minecraft:polished_blackstone_bricks
fill 426 76 489 426 79 489 minecraft:blackstone
setblock 426 76 493 minecraft:polished_blackstone_bricks
fill 426 76 494 426 79 494 minecraft:blackstone
setblock 426 76 498 minecraft:polished_blackstone_bricks
fill 426 76 499 426 78 499 minecraft:blackstone
setblock 426 76 503 minecraft:polished_blackstone_bricks
fill 426 76 504 426 79 504 minecraft:blackstone
setblock 427 76 487 minecraft:polished_blackstone_bricks
fill 427 76 488 427 77 488 minecraft:blackstone
setblock 427 76 492 minecraft:polished_blackstone_bricks
fill 427 76 493 427 79 493 minecraft:blackstone
setblock 427 76 502 minecraft:polished_blackstone_bricks
fill 427 76 503 427 78 503 minecraft:blackstone
setblock 428 76 466 minecraft:polished_blackstone_bricks
setblock 429 76 465 minecraft:polished_blackstone_bricks
setblock 430 76 464 minecraft:polished_blackstone_bricks
setblock 430 76 465 minecraft:blackstone
setblock 430 76 504 minecraft:polished_blackstone_bricks
fill 431 76 464 431 77 464 minecraft:blackstone
fill 431 76 504 431 77 504 minecraft:blackstone
setblock 439 76 464 minecraft:blackstone
setblock 440 76 464 minecraft:polished_blackstone_bricks
fill 441 76 464 441 79 464 minecraft:blackstone
setblock 443 76 466 minecraft:polished_blackstone_bricks
setblock 444 76 465 minecraft:polished_blackstone_bricks
fill 444 76 466 444 79 466 minecraft:blackstone
setblock 445 76 464 minecraft:polished_blackstone_bricks
fill 445 76 465 445 79 465 minecraft:blackstone
fill 445 76 467 446 76 467 minecraft:blackstone
setblock 445 76 504 minecraft:polished_blackstone_bricks
fill 446 76 464 446 79 464 minecraft:blackstone
fill 446 76 504 446 77 504 minecraft:blackstone
setblock 447 76 467 minecraft:polished_blackstone_bricks
setblock 448 76 466 minecraft:polished_blackstone_bricks
fill 448 76 467 449 76 467 minecraft:blackstone
setblock 449 76 465 minecraft:polished_blackstone_bricks
fill 449 76 466 449 78 466 minecraft:blackstone
setblock 450 76 464 minecraft:polished_blackstone_bricks
fill 450 76 465 453 76 465 minecraft:blackstone
fill 451 76 464 451 79 464 minecraft:blackstone
setblock 452 76 466 minecraft:blackstone
setblock 453 76 466 minecraft:polished_blackstone_bricks
setblock 454 76 465 minecraft:polished_blackstone_bricks
setblock 454 76 466 minecraft:blackstone
setblock 455 76 464 minecraft:polished_blackstone_bricks
fill 455 76 465 455 78 465 minecraft:blackstone
fill 456 76 464 456 79 464 minecraft:blackstone
fill 456 76 466 457 76 466 minecraft:blackstone
setblock 458 76 466 minecraft:polished_blackstone_bricks
setblock 459 76 465 minecraft:polished_blackstone_bricks
fill 459 76 466 459 79 466 minecraft:blackstone
setblock 460 76 464 minecraft:polished_blackstone_bricks
fill 460 76 465 460 79 465 minecraft:blackstone
fill 460 76 467 461 76 467 minecraft:blackstone
setblock 460 76 504 minecraft:polished_blackstone_bricks
fill 461 76 464 461 79 464 minecraft:blackstone
setblock 461 76 468 minecraft:polished_blackstone_bricks
fill 461 76 469 461 79 469 minecraft:blackstone
fill 461 76 504 461 79 504 minecraft:blackstone
setblock 462 76 467 minecraft:polished_blackstone_bricks
fill 462 76 468 462 79 468 minecraft:blackstone
setblock 462 76 472 minecraft:polished_blackstone_bricks
fill 462 76 503 462 79 503 minecraft:blackstone
setblock 463 76 466 minecraft:polished_blackstone_bricks
fill 463 76 467 463 79 467 minecraft:blackstone
setblock 463 76 471 minecraft:polished_blackstone_bricks
fill 463 76 472 463 79 472 minecraft:blackstone
setblock 463 76 475 minecraft:blackstone
setblock 463 76 486 minecraft:polished_blackstone_bricks
fill 463 76 487 463 78 487 minecraft:blackstone
fill 463 76 489 463 76 490 minecraft:blackstone
setblock 463 76 491 minecraft:polished_blackstone_bricks
fill 463 76 492 463 79 492 minecraft:blackstone
fill 463 76 494 463 76 495 minecraft:blackstone
setblock 463 76 496 minecraft:polished_blackstone_bricks
setblock 463 76 501 minecraft:polished_blackstone_bricks
fill 463 76 502 463 79 502 minecraft:blackstone
setblock 464 76 465 minecraft:polished_blackstone_bricks
fill 464 76 466 464 79 466 minecraft:blackstone
setblock 464 76 470 minecraft:polished_blackstone_bricks
fill 464 76 471 464 79 471 minecraft:blackstone
setblock 464 76 475 minecraft:polished_blackstone_bricks
fill 464 76 476 464 79 476 minecraft:blackstone
setblock 464 76 480 minecraft:polished_blackstone_bricks
fill 464 76 481 464 77 481 minecraft:blackstone
setblock 464 76 485 minecraft:polished_blackstone_bricks
fill 464 76 486 464 79 486 minecraft:blackstone
setblock 464 76 490 minecraft:polished_blackstone_bricks
fill 464 76 491 464 79 491 minecraft:blackstone
setblock 464 76 495 minecraft:polished_blackstone_bricks
fill 464 76 496 464 79 496 minecraft:blackstone
setblock 464 76 500 minecraft:polished_blackstone_bricks
fill 464 76 501 464 79 501 minecraft:blackstone
setblock 424 77 464 minecraft:polished_blackstone_bricks
fill 424 77 465 424 80 465 minecraft:blackstone
setblock 424 77 469 minecraft:polished_blackstone_bricks
fill 424 77 470 424 80 470 minecraft:blackstone
setblock 424 77 473 minecraft:blackstone
setblock 424 77 474 minecraft:polished_blackstone_bricks
fill 424 77 475 424 80 475 minecraft:blackstone
setblock 424 77 478 minecraft:blackstone
setblock 424 77 480 minecraft:blackstone
setblock 424 77 484 minecraft:polished_blackstone_bricks
fill 424 77 485 424 77 488 minecraft:blackstone
setblock 424 77 489 minecraft:polished_blackstone_bricks
fill 424 77 490 424 77 493 minecraft:blackstone
setblock 424 77 494 minecraft:polished_blackstone_bricks
fill 424 77 495 424 80 495 minecraft:blackstone
setblock 424 77 499 minecraft:polished_blackstone_bricks
fill 424 77 500 424 80 500 minecraft:blackstone
setblock 424 77 504 minecraft:polished_blackstone_bricks
fill 425 77 464 425 80 464 minecraft:blackstone
setblock 425 77 468 minecraft:polished_blackstone_bricks
fill 425 77 469 425 80 469 minecraft:blackstone
setblock 425 77 473 minecraft:polished_blackstone_bricks
fill 425 77 474 425 78 474 minecraft:blackstone
setblock 425 77 483 minecraft:polished_blackstone_bricks
fill 425 77 484 425 78 484 minecraft:blackstone
setblock 425 77 488 minecraft:polished_blackstone_bricks
fill 425 77 489 425 80 489 minecraft:blackstone
setblock 425 77 493 minecraft:polished_blackstone_bricks
fill 425 77 494 425 80 494 minecraft:blackstone
setblock 425 77 497 minecraft:blackstone
setblock 425 77 498 minecraft:polished_blackstone_bricks
fill 425 77 499 425 80 499 minecraft:blackstone
setblock 425 77 503 minecraft:polished_blackstone_bricks
fill 425 77 504 425 80 504 minecraft:blackstone
setblock 426 77 467 minecraft:polished_blackstone_bricks
fill 426 77 468 426 80 468 minecraft:blackstone
setblock 426 77 487 minecraft:polished_blackstone_bricks
fill 426 77 488 426 79 488 minecraft:blackstone
setblock 426 77 491 minecraft:blackstone
setblock 426 77 492 minecraft:polished_blackstone_bricks
fill 426 77 493 426 80 493 minecraft:blackstone
setblock 426 77 497 minecraft:polished_blackstone_bricks
fill 426 77 498 426 80 498 minecraft:blackstone
setblock 426 77 502 minecraft:polished_blackstone_bricks
fill 426 77 503 426 79 503 minecraft:blackstone
setblock 427 77 466 minecraft:polished_blackstone_bricks
setblock 427 77 491 minecraft:polished_blackstone_bricks
fill 427 77 492 427 79 492 minecraft:blackstone
setblock 427 77 495 minecraft:blackstone
setblock 428 77 465 minecraft:polished_blackstone_bricks
setblock 429 77 464 minecraft:polished_blackstone_bricks
setblock 429 77 465 minecraft:blackstone
setblock 429 77 504 minecraft:polished_blackstone_bricks
setblock 430 77 464 minecraft:blackstone
fill 430 77 504 430 78 504 minecraft:blackstone
setblock 439 77 464 minecraft:polished_blackstone_bricks
fill 440 77 464 440 79 464 minecraft:blackstone
setblock 443 77 465 minecraft:polished_blackstone_bricks
fill 443 77 466 443 78 466 minecraft:blackstone
setblock 444 77 464 minecraft:polished_blackstone_bricks
fill 444 77 465 444 80 465 minecraft:blackstone
setblock 444 77 504 minecraft:polished_blackstone_bricks
fill 445 77 464 445 80 464 minecraft:blackstone
setblock 445 77 467 minecraft:blackstone
fill 445 77 504 445 78 504 minecraft:blackstone
setblock 446 77 467 minecraft:polished_blackstone_bricks
setblock 447 77 466 minecraft:polished_blackstone_bricks
fill 447 77 467 448 77 467 minecraft:blackstone
setblock 448 77 465 minecraft:polished_blackstone_bricks
fill 448 77 466 448 78 466 minecraft:blackstone
setblock 449 77 464 minecraft:polished_blackstone_bricks
fill 449 77 465 452 77 465 minecraft:blackstone
fill 450 77 464 450 80 464 minecraft:blackstone
setblock 452 77 466 minecraft:polished_blackstone_bricks
setblock 453 77 465 minecraft:polished_blackstone_bricks
setblock 454 77 464 minecraft:polished_blackstone_bricks
fill 454 77 465 454 78 465 minecraft:blackstone
fill 455 77 464 455 80 464 minecraft:blackstone
setblock 457 77 466 minecraft:polished_blackstone_bricks
setblock 458 77 465 minecraft:polished_blackstone_bricks
fill 458 77 466 458 78 466 minecraft:blackstone
setblock 459 77 464 minecraft:polished_blackstone_bricks
fill 459 77 465 459 80 465 minecraft:blackstone
setblock 459 77 504 minecraft:polished_blackstone_bricks
fill 460 77 464 460 80 464 minecraft:blackstone
setblock 460 77 467 minecraft:blackstone
fill 460 77 504 460 80 504 minecraft:blackstone
setblock 461 77 467 minecraft:polished_blackstone_bricks
fill 461 77 468 461 79 468 minecraft:blackstone
fill 461 77 470 462 77 470 minecraft:blackstone
setblock 462 77 466 minecraft:polished_blackstone_bricks
fill 462 77 467 462 80 467 minecraft:blackstone
setblock 462 77 471 minecraft:polished_blackstone_bricks
fill 462 77 472 462 79 473 minecraft:blackstone
setblock 463 77 465 minecraft:polished_blackstone_bricks
fill 463 77 466 463 80 466 minecraft:blackstone
setblock 463 77 470 minecraft:polished_blackstone_bricks
fill 463 77 471 463 80 471 minecraft:blackstone
setblock 463 77 475 minecraft:polished_blackstone_bricks
setblock 463 77 486 minecraft:blackstone
setblock 463 77 489 minecraft:blackstone
setblock 463 77 490 minecraft:polished_blackstone_bricks
fill 463 77 491 463 80 491 minecraft:blackstone
setblock 463 77 494 minecraft:blackstone
setblock 463 77 495 minecraft:polished_blackstone_bricks
fill 463 77 496 463 77 499 minecraft:blackstone
setblock 463 77 500 minecraft:polished_blackstone_bricks
fill 463 77 501 463 80 501 minecraft:blackstone
setblock 464 77 464 minecraft:polished_blackstone_bricks
fill 464 77 465 464 80 465 minecraft:blackstone
setblock 464 77 469 minecraft:polished_blackstone_bricks
fill 464 77 470 464 80 470 minecraft:blackstone
setblock 464 77 474 minecraft:polished_blackstone_bricks
fill 464 77 475 464 80 475 minecraft:blackstone
setblock 464 77 479 minecraft:polished_blackstone_bricks
setblock 464 77 480 minecraft:blackstone
setblock 464 77 484 minecraft:polished_blackstone_bricks
fill 464 77 485 464 79 485 minecraft:blackstone
setblock 464 77 489 minecraft:polished_blackstone_bricks
fill 464 77 490 464 80 490 minecraft:blackstone
setblock 464 77 494 minecraft:polished_blackstone_bricks
fill 464 77 495 464 80 495 minecraft:blackstone
setblock 464 77 499 minecraft:polished_blackstone_bricks
fill 464 77 500 464 80 500 minecraft:blackstone
setblock 464 77 504 minecraft:polished_blackstone_bricks
fill 424 78 464 424 81 464 minecraft:blackstone
setblock 424 78 468 minecraft:polished_blackstone_bricks
fill 424 78 469 424 81 469 minecraft:blackstone
setblock 424 78 473 minecraft:polished_blackstone_bricks
fill 424 78 474 424 81 474 minecraft:blackstone
setblock 424 78 483 minecraft:polished_blackstone_bricks
fill 424 78 484 424 78 487 minecraft:blackstone
setblock 424 78 488 minecraft:polished_blackstone_bricks
fill 424 78 489 424 78 492 minecraft:blackstone
setblock 424 78 493 minecraft:polished_blackstone_bricks
fill 424 78 494 424 81 494 minecraft:blackstone
setblock 424 78 498 minecraft:polished_blackstone_bricks
fill 424 78 499 424 81 499 minecraft:blackstone
setblock 424 78 503 minecraft:polished_blackstone_bricks
fill 424 78 504 424 81 504 minecraft:blackstone
setblock 425 78 467 minecraft:polished_blackstone_bricks
fill 425 78 468 425 80 468 minecraft:blackstone
setblock 425 78 472 minecraft:polished_blackstone_bricks
fill 425 78 473 425 80 473 minecraft:blackstone
setblock 425 78 487 minecraft:polished_blackstone_bricks
fill 425 78 488 425 81 488 minecraft:blackstone
setblock 425 78 492 minecraft:polished_blackstone_bricks
fill 425 78 493 425 81 493 minecraft:blackstone
setblock 425 78 497 minecraft:polished_blackstone_bricks
fill 425 78 498 425 81 498 minecraft:blackstone
setblock 425 78 502 minecraft:polished_blackstone_bricks
fill 425 78 503 425 80 503 minecraft:blackstone
setblock 426 78 467 minecraft:blackstone
setblock 426 78 486 minecraft:polished_blackstone_bricks
fill 426 78 487 426 79 487 minecraft:blackstone
setblock 426 78 491 minecraft:polished_blackstone_bricks
fill 426 78 492 426 81 492 minecraft:blackstone
setblock 426 78 496 minecraft:polished_blackstone_bricks
fill 426 78 497 426 81 497 minecraft:blackstone
setblock 427 78 465 minecraft:polished_blackstone_bricks
setblock 427 78 490 minecraft:polished_blackstone_bricks
fill 427 78 491 427 79 491 minecraft:blackstone
setblock 427 78 495 minecraft:polished_blackstone_bricks
setblock 428 78 464 minecraft:polished_blackstone_bricks
setblock 428 78 465 minecraft:blackstone
setblock 428 78 504 minecraft:polished_blackstone_bricks
setblock 429 78 464 minecraft:blackstone
setblock 429 78 504 minecraft:blackstone
setblock 442 78 465 minecraft:polished_blackstone_bricks
setblock 443 78 464 minecraft:polished_blackstone_bricks
fill 443 78 465 443 80 465 minecraft:blackstone
fill 444 78 464 444 81 464 minecraft:blackstone
setblock 444 78 504 minecraft:blackstone
setblock 446 78 466 minecraft:polished_blackstone_bricks
setblock 447 78 465 minecraft:polished_blackstone_bricks
fill 447 78 466 447 79 466 minecraft:blackstone
setblock 448 78 464 minecraft:polished_blackstone_bricks
fill 448 78 465 451 78 465 minecraft:blackstone
fill 449 78 464 449 80 464 minecraft:blackstone
setblock 452 78 465 minecraft:polished_blackstone_bricks
setblock 453 78 464 minecraft:polished_blackstone_bricks
setblock 453 78 465 minecraft:blackstone
fill 454 78 464 454 79 464 minecraft:blackstone
setblock 457 78 465 minecraft:polished_blackstone_bricks
setblock 458 78 464 minecraft:polished_blackstone_bricks
fill 458 78 465 458 81 465 minecraft:blackstone
fill 459 78 464 459 81 464 minecraft:blackstone
fill 459 78 504 459 81 504 minecraft:blackstone
setblock 461 78 466 minecraft:polished_blackstone_bricks
setblock 461 78 467 minecraft:blackstone
setblock 461 78 470 minecraft:blackstone
setblock 462 78 465 minecraft:polished_blackstone_bricks
fill 462 78 466 462 81 466 minecraft:blackstone
setblock 462 78 470 minecraft:polished_blackstone_bricks
fill 462 78 471 462 81 471 minecraft:blackstone
setblock 463 78 464 minecraft:polished_blackstone_bricks
fill 463 78 465 463 81 465 minecraft:blackstone
setblock 463 78 469 minecraft:polished_blackstone_bricks
fill 463 78 470 463 81 470 minecraft:blackstone
setblock 463 78 473 minecraft:blackstone
setblock 463 78 474 minecraft:polished_blackstone_bricks
fill 463 78 475 463 81 475 minecraft:blackstone
setblock 463 78 489 minecraft:polished_blackstone_bricks
fill 463 78 490 463 81 490 minecraft:blackstone
setblock 463 78 494 minecraft:polished_blackstone_bricks
fill 463 78 495 463 78 498 minecraft:blackstone
setblock 463 78 499 minecraft:polished_blackstone_bricks
fill 463 78 500 463 81 500 minecraft:blackstone
setblock 463 78 504 minecraft:polished_blackstone_bricks
fill 464 78 464 464 81 464 minecraft:blackstone
setblock 464 78 468 minecraft:polished_blackstone_bricks
fill 464 78 469 464 81 469 minecraft:blackstone
setblock 464 78 473 minecraft:polished_blackstone_bricks
fill 464 78 474 464 81 474 minecraft:blackstone
setblock 464 78 478 minecraft:polished_blackstone_bricks
setblock 464 78 479 minecraft:blackstone
setblock 464 78 483 minecraft:polished_blackstone_bricks
fill 464 78 484 464 79 484 minecraft:blackstone
setblock 464 78 488 minecraft:polished_blackstone_bricks
fill 464 78 489 464 81 489 minecraft:blackstone
setblock 464 78 493 minecraft:polished_blackstone_bricks
fill 464 78 494 464 81 494 minecraft:blackstone
setblock 464 78 498 minecraft:polished_blackstone_bricks
fill 464 78 499 464 81 499 minecraft:blackstone
setblock 464 78 503 minecraft:polished_blackstone_bricks
fill 464 78 504 464 81 504 minecraft:blackstone
setblock 424 79 467 minecraft:polished_blackstone_bricks
fill 424 79 468 424 82 468 minecraft:blackstone
setblock 424 79 472 minecraft:polished_blackstone_bricks
fill 424 79 473 424 82 473 minecraft:blackstone
setblock 424 79 476 minecraft:blackstone
setblock 424 79 477 minecraft:polished_blackstone_bricks
setblock 424 79 482 minecraft:polished_blackstone_bricks
fill 424 79 483 424 79 486 minecraft:blackstone
setblock 424 79 487 minecraft:polished_blackstone_bricks
fill 424 79 488 424 79 491 minecraft:blackstone
setblock 424 79 492 minecraft:polished_blackstone_bricks
fill 424 79 493 424 82 493 minecraft:blackstone
setblock 424 79 497 minecraft:polished_blackstone_bricks
fill 424 79 498 424 82 498 minecraft:blackstone
setblock 424 79 502 minecraft:polished_blackstone_bricks
fill 424 79 503 424 82 503 minecraft:blackstone
setblock 425 79 466 minecraft:polished_blackstone_bricks
fill 425 79 467 425 80 467 minecraft:blackstone
setblock 425 79 471 minecraft:polished_blackstone_bricks
fill 425 79 472 430 80 472 minecraft:blackstone
setblock 425 79 486 minecraft:polished_blackstone_bricks
fill 425 79 487 425 81 487 minecraft:blackstone
setblock 425 79 491 minecraft:polished_blackstone_bricks
fill 425 79 492 425 82 492 minecraft:blackstone
setblock 425 79 496 minecraft:polished_blackstone_bricks
fill 425 79 497 425 82 497 minecraft:blackstone
setblock 425 79 501 minecraft:polished_blackstone_bricks
fill 425 79 502 425 80 502 minecraft:blackstone
setblock 426 79 465 minecraft:polished_blackstone_bricks
fill 426 79 470 430 80 471 minecraft:blackstone
setblock 426 79 490 minecraft:polished_blackstone_bricks
fill 426 79 491 426 82 491 minecraft:blackstone
setblock 426 79 495 minecraft:polished_blackstone_bricks
fill 426 79 496 426 82 496 minecraft:blackstone
setblock 427 79 464 minecraft:polished_blackstone_bricks
fill 427 79 468 430 80 469 minecraft:blackstone
setblock 427 79 494 minecraft:polished_blackstone_bricks
setblock 427 79 504 minecraft:polished_blackstone_bricks
setblock 428 79 464 minecraft:blackstone
setblock 428 79 504 minecraft:blackstone
setblock 442 79 464 minecraft:polished_blackstone_bricks
setblock 442 79 465 minecraft:blackstone
fill 443 79 464 443 82 464 minecraft:blackstone
setblock 445 79 466 minecraft:polished_blackstone_bricks
setblock 446 79 465 minecraft:polished_blackstone_bricks
setblock 446 79 466 minecraft:blackstone
setblock 447 79 464 minecraft:polished_blackstone_bricks
fill 447 79 465 450 79 465 minecraft:blackstone
fill 448 79 464 448 80 464 minecraft:blackstone
setblock 452 79 464 minecraft:polished_blackstone_bricks
setblock 453 79 464 minecraft:blackstone
setblock 457 79 464 minecraft:polished_blackstone_bricks
setblock 457 79 465 minecraft:blackstone
fill 458 79 464 458 82 464 minecraft:blackstone
setblock 460 79 466 minecraft:polished_blackstone_bricks
setblock 461 79 465 minecraft:polished_blackstone_bricks
fill 461 79 466 461 81 466 minecraft:blackstone
setblock 462 79 464 minecraft:polished_blackstone_bricks
fill 462 79 465 462 82 465 minecraft:blackstone
setblock 462 79 469 minecraft:polished_blackstone_bricks
fill 462 79 470 462 82 470 minecraft:blackstone
setblock 462 79 504 minecraft:polished_blackstone_bricks
fill 463 79 464 463 82 464 minecraft:blackstone
setblock 463 79 468 minecraft:polished_blackstone_bricks
fill 463 79 469 463 82 469 minecraft:blackstone
setblock 463 79 473 minecraft:polished_blackstone_bricks
fill 463 79 474 463 82 474 minecraft:blackstone
setblock 463 79 488 minecraft:polished_blackstone_bricks
fill 463 79 489 463 80 489 minecraft:blackstone
setblock 463 79 493 minecraft:polished_blackstone_bricks
fill 463 79 494 463 79 497 minecraft:blackstone
setblock 463 79 498 minecraft:polished_blackstone_bricks
fill 463 79 499 463 82 499 minecraft:blackstone
setblock 463 79 503 minecraft:polished_blackstone_bricks
fill 463 79 504 463 82 504 minecraft:blackstone
setblock 464 79 467 minecraft:polished_blackstone_bricks
fill 464 79 468 464 82 468 minecraft:blackstone
setblock 464 79 472 minecraft:polished_blackstone_bricks
fill 464 79 473 464 82 473 minecraft:blackstone
setblock 464 79 477 minecraft:polished_blackstone_bricks
fill 464 79 478 464 80 478 minecraft:blackstone
setblock 464 79 487 minecraft:polished_blackstone_bricks
fill 464 79 488 464 82 488 minecraft:blackstone
setblock 464 79 492 minecraft:polished_blackstone_bricks
fill 464 79 493 464 82 493 minecraft:blackstone
setblock 464 79 497 minecraft:polished_blackstone_bricks
fill 464 79 498 464 82 498 minecraft:blackstone
setblock 464 79 502 minecraft:polished_blackstone_bricks
fill 464 79 503 464 82 503 minecraft:blackstone
setblock 424 80 466 minecraft:polished_blackstone_bricks
fill 424 80 467 424 82 467 minecraft:blackstone
setblock 424 80 471 minecraft:polished_blackstone_bricks
fill 424 80 472 424 83 472 minecraft:blackstone
setblock 424 80 476 minecraft:polished_blackstone_bricks
fill 424 80 477 424 83 477 minecraft:blackstone
fill 424 80 483 424 80 485 minecraft:blackstone
setblock 424 80 486 minecraft:polished_blackstone_bricks
fill 424 80 487 424 80 490 minecraft:blackstone
setblock 424 80 491 minecraft:polished_blackstone_bricks
fill 424 80 492 424 83 492 minecraft:blackstone
setblock 424 80 496 minecraft:polished_blackstone_bricks
fill 424 80 497 424 83 497 minecraft:blackstone
setblock 424 80 501 minecraft:polished_blackstone_bricks
fill 424 80 502 424 83 502 minecraft:blackstone
setblock 425 80 466 minecraft:blackstone
setblock 425 80 470 minecraft:polished_blackstone_bricks
fill 425 80 471 425 81 471 minecraft:blackstone
setblock 425 80 486 minecraft:blackstone
setblock 425 80 490 minecraft:polished_blackstone_bricks
fill 425 80 491 425 83 491 minecraft:blackstone
setblock 425 80 495 minecraft:polished_blackstone_bricks
fill 425 80 496 425 83 496 minecraft:blackstone
setblock 425 80 500 minecraft:polished_blackstone_bricks
fill 425 80 501 425 83 501 minecraft:blackstone
setblock 426 80 464 minecraft:polished_blackstone_bricks
setblock 426 80 466 minecraft:light[level=11]
setblock 426 80 474 minecraft:light[level=11]
setblock 426 80 482 minecraft:light[level=11]
setblock 426 80 489 minecraft:polished_blackstone_bricks
fill 426 80 490 426 81 490 minecraft:blackstone
setblock 426 80 494 minecraft:polished_blackstone_bricks
fill 426 80 495 426 83 495 minecraft:blackstone
setblock 426 80 504 minecraft:polished_blackstone_bricks
setblock 427 80 504 minecraft:blackstone
setblock 434 80 466 minecraft:light[level=11]
setblock 434 80 474 minecraft:light[level=11]
setblock 434 80 482 minecraft:light[level=11]
setblock 434 80 490 minecraft:light[level=11]
setblock 434 80 498 minecraft:light[level=11]
setblock 441 80 464 minecraft:polished_blackstone_bricks
fill 442 80 464 442 81 464 minecraft:blackstone
setblock 442 80 466 minecraft:light[level=11]
setblock 442 80 474 minecraft:light[level=11]
setblock 442 80 482 minecraft:light[level=11]
setblock 442 80 490 minecraft:light[level=11]
setblock 442 80 498 minecraft:light[level=11]
setblock 445 80 465 minecraft:polished_blackstone_bricks
setblock 446 80 464 minecraft:polished_blackstone_bricks
fill 446 80 465 447 80 465 minecraft:blackstone
fill 447 80 464 447 81 464 minecraft:blackstone
setblock 450 80 466 minecraft:light[level=11]
setblock 450 80 474 minecraft:light[level=11]
setblock 450 80 482 minecraft:light[level=11]
setblock 450 80 490 minecraft:light[level=11]
setblock 450 80 498 minecraft:light[level=11]
setblock 456 80 464 minecraft:polished_blackstone_bricks
fill 457 80 464 457 83 464 minecraft:blackstone
setblock 458 80 466 minecraft:light[level=11]
setblock 458 80 474 minecraft:light[level=11]
setblock 458 80 482 minecraft:light[level=11]
setblock 458 80 490 minecraft:light[level=11]
setblock 458 80 498 minecraft:light[level=11]
setblock 460 80 465 minecraft:polished_blackstone_bricks
setblock 460 80 466 minecraft:blackstone
fill 460 80 490 461 81 491 minecraft:cyan_stained_glass
setblock 461 80 464 minecraft:polished_blackstone_bricks
fill 461 80 465 461 83 465 minecraft:blackstone
setblock 461 80 504 minecraft:polished_blackstone_bricks
fill 462 80 464 462 83 464 minecraft:blackstone
setblock 462 80 468 minecraft:polished_blackstone_bricks
fill 462 80 469 462 82 469 minecraft:blackstone
setblock 462 80 472 minecraft:blackstone
setblock 462 80 473 minecraft:polished_blackstone_bricks
setblock 462 80 503 minecraft:polished_blackstone_bricks
fill 462 80 504 462 83 504 minecraft:blackstone
setblock 463 80 467 minecraft:polished_blackstone_bricks
fill 463 80 468 463 83 468 minecraft:blackstone
setblock 463 80 472 minecraft:polished_blackstone_bricks
fill 463 80 473 463 83 473 minecraft:blackstone
setblock 463 80 492 minecraft:polished_blackstone_bricks
fill 463 80 493 463 80 496 minecraft:blackstone
setblock 463 80 497 minecraft:polished_blackstone_bricks
fill 463 80 498 463 83 498 minecraft:blackstone
setblock 463 80 502 minecraft:polished_blackstone_bricks
fill 463 80 503 463 83 503 minecraft:blackstone
setblock 464 80 466 minecraft:polished_blackstone_bricks
fill 464 80 467 464 83 467 minecraft:blackstone
setblock 464 80 471 minecraft:polished_blackstone_bricks
fill 464 80 472 464 83 472 minecraft:blackstone
setblock 464 80 476 minecraft:polished_blackstone_bricks
fill 464 80 477 464 83 477 minecraft:blackstone
setblock 464 80 486 minecraft:polished_blackstone_bricks
fill 464 80 487 464 81 487 minecraft:blackstone
setblock 464 80 491 minecraft:polished_blackstone_bricks
fill 464 80 492 464 83 492 minecraft:blackstone
setblock 464 80 496 minecraft:polished_blackstone_bricks
fill 464 80 497 464 83 497 minecraft:blackstone
setblock 464 80 501 minecraft:polished_blackstone_bricks
fill 464 80 502 464 83 502 minecraft:blackstone
setblock 424 81 465 minecraft:polished_blackstone_bricks
fill 424 81 466 424 82 466 minecraft:blackstone
setblock 424 81 470 minecraft:polished_blackstone_bricks
fill 424 81 471 424 84 471 minecraft:blackstone
setblock 424 81 475 minecraft:polished_blackstone_bricks
fill 424 81 476 424 84 476 minecraft:blackstone
setblock 424 81 484 minecraft:blackstone
setblock 424 81 485 minecraft:polished_blackstone_bricks
fill 424 81 486 424 81 489 minecraft:blackstone
setblock 424 81 490 minecraft:polished_blackstone_bricks
fill 424 81 491 424 84 491 minecraft:blackstone
setblock 424 81 495 minecraft:polished_blackstone_bricks
fill 424 81 496 424 84 496 minecraft:blackstone
setblock 424 81 500 minecraft:polished_blackstone_bricks
fill 424 81 501 424 84 501 minecraft:blackstone
setblock 425 81 464 minecraft:polished_blackstone_bricks
setblock 425 81 470 minecraft:blackstone
setblock 425 81 472 minecraft:blackstone
setblock 425 81 489 minecraft:polished_blackstone_bricks
fill 425 81 490 425 84 490 minecraft:blackstone
setblock 425 81 494 minecraft:polished_blackstone_bricks
fill 425 81 495 425 84 495 minecraft:blackstone
setblock 425 81 499 minecraft:polished_blackstone_bricks
fill 425 81 500 425 84 500 minecraft:blackstone
setblock 425 81 504 minecraft:polished_blackstone_bricks
setblock 426 81 493 minecraft:polished_blackstone_bricks
fill 426 81 494 426 84 494 minecraft:blackstone
setblock 426 81 504 minecraft:blackstone
fill 427 81 470 429 85 470 minecraft:polished_blackstone_bricks
setblock 445 81 464 minecraft:polished_blackstone_bricks
setblock 446 81 464 minecraft:blackstone
setblock 456 81 464 minecraft:blackstone
setblock 459 81 465 minecraft:polished_blackstone_bricks
setblock 460 81 464 minecraft:polished_blackstone_bricks
fill 460 81 465 460 84 465 minecraft:blackstone
setblock 460 81 504 minecraft:polished_blackstone_bricks
fill 461 81 464 461 84 464 minecraft:blackstone
fill 461 81 504 461 84 504 minecraft:blackstone
setblock 462 81 467 minecraft:polished_blackstone_bricks
fill 462 81 468 462 82 468 minecraft:blackstone
setblock 462 81 472 minecraft:polished_blackstone_bricks
fill 462 81 473 462 83 473 minecraft:blackstone
fill 462 81 503 462 84 503 minecraft:blackstone
setblock 463 81 466 minecraft:polished_blackstone_bricks
fill 463 81 467 463 84 467 minecraft:blackstone
setblock 463 81 471 minecraft:polished_blackstone_bricks
fill 463 81 472 463 84 472 minecraft:blackstone
setblock 463 81 491 minecraft:polished_blackstone_bricks
fill 463 81 492 463 81 495 minecraft:blackstone
setblock 463 81 496 minecraft:polished_blackstone_bricks
fill 463 81 497 463 84 497 minecraft:blackstone
setblock 463 81 501 minecraft:polished_blackstone_bricks
fill 463 81 502 463 84 502 minecraft:blackstone
setblock 464 81 465 minecraft:polished_blackstone_bricks
fill 464 81 466 464 84 466 minecraft:blackstone
setblock 464 81 470 minecraft:polished_blackstone_bricks
fill 464 81 471 464 84 471 minecraft:blackstone
setblock 464 81 475 minecraft:polished_blackstone_bricks
fill 464 81 476 464 84 476 minecraft:blackstone
setblock 464 81 490 minecraft:polished_blackstone_bricks
fill 464 81 491 464 84 491 minecraft:blackstone
setblock 464 81 495 minecraft:polished_blackstone_bricks
fill 464 81 496 464 84 496 minecraft:blackstone
setblock 464 81 500 minecraft:polished_blackstone_bricks
fill 464 81 501 464 84 501 minecraft:blackstone
setblock 424 82 469 minecraft:polished_blackstone_bricks
fill 424 82 470 424 85 470 minecraft:blackstone
setblock 424 82 474 minecraft:polished_blackstone_bricks
fill 424 82 475 424 85 475 minecraft:blackstone
fill 424 82 485 424 82 488 minecraft:blackstone
setblock 424 82 489 minecraft:polished_blackstone_bricks
fill 424 82 490 424 85 490 minecraft:blackstone
setblock 424 82 494 minecraft:polished_blackstone_bricks
fill 424 82 495 424 85 495 minecraft:blackstone
setblock 424 82 499 minecraft:polished_blackstone_bricks
fill 424 82 500 424 85 500 minecraft:blackstone
setblock 424 82 504 minecraft:polished_blackstone_bricks
setblock 425 82 488 minecraft:polished_blackstone_bricks
fill 425 82 489 425 84 489 minecraft:blackstone
setblock 425 82 493 minecraft:polished_blackstone_bricks
fill 425 82 494 425 85 494 minecraft:blackstone
setblock 425 82 498 minecraft:polished_blackstone_bricks
fill 425 82 499 425 85 499 minecraft:blackstone
fill 425 82 504 425 83 504 minecraft:blackstone
setblock 426 82 492 minecraft:polished_blackstone_bricks
fill 426 82 493 426 84 493 minecraft:blackstone
setblock 426 82 497 minecraft:polished_blackstone_bricks
setblock 444 82 464 minecraft:polished_blackstone_bricks
setblock 445 82 464 minecraft:blackstone
setblock 459 82 464 minecraft:polished_blackstone_bricks
fill 459 82 465 459 85 465 minecraft:blackstone
setblock 459 82 504 minecraft:polished_blackstone_bricks
fill 460 82 464 460 85 464 minecraft:blackstone
fill 460 82 504 460 85 504 minecraft:blackstone
setblock 462 82 471 minecraft:polished_blackstone_bricks
fill 462 82 472 462 83 472 minecraft:blackstone
fill 462 82 494 462 82 495 minecraft:blackstone
setblock 462 82 496 minecraft:polished_blackstone_bricks
setblock 463 82 465 minecraft:polished_blackstone_bricks
fill 463 82 466 463 83 466 minecraft:blackstone
setblock 463 82 470 minecraft:polished_blackstone_bricks
fill 463 82 471 463 85 471 minecraft:blackstone
setblock 463 82 475 minecraft:polished_blackstone_bricks
setblock 463 82 490 minecraft:polished_blackstone_bricks
fill 463 82 491 463 82 494 minecraft:blackstone
setblock 463 82 495 minecraft:polished_blackstone_bricks
fill 463 82 496 463 85 496 minecraft:blackstone
setblock 463 82 500 minecraft:polished_blackstone_bricks
fill 463 82 501 463 85 501 minecraft:blackstone
setblock 464 82 464 minecraft:polished_blackstone_bricks
fill 464 82 465 464 85 465 minecraft:blackstone
setblock 464 82 469 minecraft:polished_blackstone_bricks
fill 464 82 470 464 85 470 minecraft:blackstone
setblock 464 82 474 minecraft:polished_blackstone_bricks
fill 464 82 475 464 85 475 minecraft:blackstone
setblock 464 82 489 minecraft:polished_blackstone_bricks
fill 464 82 490 464 85 490 minecraft:blackstone
setblock 464 82 494 minecraft:polished_blackstone_bricks
fill 464 82 495 464 85 495 minecraft:blackstone
setblock 464 82 499 minecraft:polished_blackstone_bricks
fill 464 82 500 464 85 500 minecraft:blackstone
setblock 464 82 504 minecraft:polished_blackstone_bricks
setblock 424 83 468 minecraft:polished_blackstone_bricks
fill 424 83 469 424 84 469 minecraft:blackstone
setblock 424 83 473 minecraft:polished_blackstone_bricks
fill 424 83 474 424 86 474 minecraft:blackstone
setblock 424 83 478 minecraft:polished_blackstone_bricks
fill 424 83 486 424 83 487 minecraft:blackstone
setblock 424 83 488 minecraft:polished_blackstone_bricks
fill 424 83 489 424 86 489 minecraft:blackstone
setblock 424 83 493 minecraft:polished_blackstone_bricks
fill 424 83 494 424 86 494 minecraft:blackstone
setblock 424 83 498 minecraft:polished_blackstone_bricks
fill 424 83 499 424 86 499 minecraft:blackstone
setblock 424 83 503 minecraft:polished_blackstone_bricks
fill 424 83 504 424 86 504 minecraft:blackstone
setblock 425 83 492 minecraft:polished_blackstone_bricks
fill 425 83 493 425 86 493 minecraft:blackstone
setblock 425 83 497 minecraft:polished_blackstone_bricks
fill 425 83 498 425 86 498 minecraft:blackstone
setblock 426 83 492 minecraft:blackstone
setblock 426 83 496 minecraft:polished_blackstone_bricks
fill 426 83 497 426 86 497 minecraft:blackstone
fill 457 83 471 461 84 475 minecraft:blackstone
setblock 458 83 464 minecraft:polished_blackstone_bricks
setblock 458 83 504 minecraft:polished_blackstone_bricks
fill 459 83 464 459 86 464 minecraft:blackstone
fill 459 83 504 459 86 504 minecraft:blackstone
fill 461 83 503 461 85 503 minecraft:blackstone
setblock 462 83 465 minecraft:polished_blackstone_bricks
setblock 462 83 470 minecraft:polished_blackstone_bricks
setblock 462 83 471 minecraft:blackstone
setblock 462 83 494 minecraft:blackstone
setblock 462 83 495 minecraft:polished_blackstone_bricks
fill 462 83 496 462 84 498 minecraft:blackstone
setblock 463 83 464 minecraft:polished_blackstone_bricks
setblock 463 83 465 minecraft:blackstone
setblock 463 83 469 minecraft:polished_blackstone_bricks
fill 463 83 470 463 86 470 minecraft:blackstone
setblock 463 83 474 minecraft:polished_blackstone_bricks
fill 463 83 475 463 86 475 minecraft:blackstone
fill 463 83 491 463 83 493 minecraft:blackstone
setblock 463 83 494 minecraft:polished_blackstone_bricks
fill 463 83 495 463 86 495 minecraft:blackstone
setblock 463 83 499 minecraft:polished_blackstone_bricks
fill 463 83 500 463 86 500 minecraft:blackstone
setblock 463 83 504 minecraft:polished_blackstone_bricks
fill 464 83 464 464 86 464 minecraft:blackstone
setblock 464 83 468 minecraft:polished_blackstone_bricks
fill 464 83 469 464 86 469 minecraft:blackstone
setblock 464 83 473 minecraft:polished_blackstone_bricks
fill 464 83 474 464 86 474 minecraft:blackstone
fill 464 83 489 464 86 489 minecraft:blackstone
setblock 464 83 493 minecraft:polished_blackstone_bricks
fill 464 83 494 464 86 494 minecraft:blackstone
setblock 464 83 498 minecraft:polished_blackstone_bricks
fill 464 83 499 464 86 499 minecraft:blackstone
setblock 464 83 503 minecraft:polished_blackstone_bricks
fill 464 83 504 464 86 504 minecraft:blackstone
setblock 424 84 472 minecraft:polished_blackstone_bricks
fill 424 84 473 424 87 473 minecraft:blackstone
setblock 424 84 477 minecraft:polished_blackstone_bricks
fill 424 84 478 424 86 479 minecraft:blackstone
setblock 424 84 486 minecraft:blackstone
setblock 424 84 487 minecraft:polished_blackstone_bricks
fill 424 84 488 424 87 488 minecraft:blackstone
setblock 424 84 492 minecraft:polished_blackstone_bricks
fill 424 84 493 424 87 493 minecraft:blackstone
setblock 424 84 497 minecraft:polished_blackstone_bricks
fill 424 84 498 424 87 498 minecraft:blackstone
setblock 424 84 502 minecraft:polished_blackstone_bricks
fill 424 84 503 424 87 503 minecraft:blackstone
setblock 425 84 491 minecraft:polished_blackstone_bricks
fill 425 84 492 425 87 492 minecraft:blackstone
setblock 425 84 496 minecraft:polished_blackstone_bricks
fill 425 84 497 425 87 497 minecraft:blackstone
setblock 425 84 501 minecraft:polished_blackstone_bricks
setblock 426 84 495 minecraft:polished_blackstone_bricks
fill 426 84 496 426 87 496 minecraft:blackstone
fill 428 84 469 428 85 469 minecraft:polished_blackstone_bricks
fill 428 84 471 428 85 471 minecraft:polished_blackstone_bricks
setblock 456 84 464 minecraft:blackstone
setblock 457 84 464 minecraft:polished_blackstone_bricks
setblock 457 84 504 minecraft:polished_blackstone_bricks
fill 458 84 464 458 87 464 minecraft:blackstone
fill 458 84 504 458 87 504 minecraft:blackstone
fill 460 84 503 460 86 503 minecraft:blackstone
setblock 461 84 465 minecraft:polished_blackstone_bricks
setblock 462 84 464 minecraft:polished_blackstone_bricks
setblock 462 84 465 minecraft:blackstone
setblock 462 84 494 minecraft:polished_blackstone_bricks
fill 462 84 495 462 87 495 minecraft:blackstone
setblock 462 84 499 minecraft:polished_blackstone_bricks
fill 462 84 500 462 87 500 minecraft:blackstone
setblock 462 84 504 minecraft:polished_blackstone_bricks
fill 463 84 464 463 87 464 minecraft:blackstone
setblock 463 84 468 minecraft:polished_blackstone_bricks
fill 463 84 469 463 85 469 minecraft:blackstone
setblock 463 84 473 minecraft:polished_blackstone_bricks
fill 463 84 474 463 87 474 minecraft:blackstone
fill 463 84 476 463 85 476 minecraft:blackstone
fill 463 84 491 463 84 492 minecraft:blackstone
setblock 463 84 493 minecraft:polished_blackstone_bricks
fill 463 84 494 463 87 494 minecraft:blackstone
setblock 463 84 498 minecraft:polished_blackstone_bricks
fill 463 84 499 463 87 499 minecraft:blackstone
setblock 463 84 503 minecraft:polished_blackstone_bricks
fill 463 84 504 463 87 504 minecraft:blackstone
setblock 464 84 467 minecraft:polished_blackstone_bricks
fill 464 84 468 464 87 468 minecraft:blackstone
setblock 464 84 472 minecraft:polished_blackstone_bricks
fill 464 84 473 464 87 473 minecraft:blackstone
setblock 464 84 477 minecraft:polished_blackstone_bricks
fill 464 84 478 464 87 478 minecraft:blackstone
setblock 464 84 492 minecraft:polished_blackstone_bricks
fill 464 84 493 464 87 493 minecraft:blackstone
setblock 464 84 497 minecraft:polished_blackstone_bricks
fill 464 84 498 464 87 498 minecraft:blackstone
setblock 464 84 502 minecraft:polished_blackstone_bricks
fill 464 84 503 464 87 503 minecraft:blackstone
setblock 424 85 471 minecraft:polished_blackstone_bricks
fill 424 85 472 424 88 472 minecraft:blackstone
setblock 424 85 476 minecraft:polished_blackstone_bricks
fill 424 85 477 424 88 477 minecraft:blackstone
setblock 424 85 480 minecraft:blackstone
setblock 424 85 486 minecraft:polished_blackstone_bricks
fill 424 85 487 424 88 487 minecraft:blackstone
setblock 424 85 491 minecraft:polished_blackstone_bricks
fill 424 85 492 424 88 492 minecraft:blackstone
setblock 424 85 496 minecraft:polished_blackstone_bricks
fill 424 85 497 424 88 497 minecraft:blackstone
setblock 424 85 501 minecraft:polished_blackstone_bricks
fill 424 85 502 424 88 502 minecraft:blackstone
setblock 425 85 490 minecraft:polished_blackstone_bricks
fill 425 85 491 425 88 491 minecraft:blackstone
setblock 425 85 495 minecraft:polished_blackstone_bricks
fill 425 85 496 425 88 496 minecraft:blackstone
setblock 425 85 500 minecraft:polished_blackstone_bricks
fill 425 85 501 425 88 501 minecraft:blackstone
setblock 426 85 494 minecraft:polished_blackstone_bricks
fill 426 85 495 426 87 495 minecraft:blackstone
fill 442 85 464 442 88 464 minecraft:blackstone
setblock 456 85 464 minecraft:polished_blackstone_bricks
setblock 456 85 504 minecraft:polished_blackstone_bricks
fill 457 85 464 457 88 464 minecraft:blackstone
fill 457 85 484 461 86 488 minecraft:blackstone
fill 457 85 504 457 88 504 minecraft:blackstone
fill 458 85 473 460 89 473 minecraft:polished_blackstone_bricks
fill 458 85 503 459 87 503 minecraft:blackstone
setblock 460 85 465 minecraft:polished_blackstone_bricks
setblock 461 85 464 minecraft:polished_blackstone_bricks
fill 461 85 465 461 88 465 minecraft:blackstone
fill 461 85 502 462 85 502 minecraft:blackstone
setblock 461 85 504 minecraft:polished_blackstone_bricks
fill 462 85 464 462 88 464 minecraft:blackstone
fill 462 85 486 463 85 486 minecraft:blackstone
fill 462 85 494 462 88 494 minecraft:blackstone
fill 462 85 496 462 85 497 minecraft:blackstone
setblock 462 85 498 minecraft:polished_blackstone_bricks
fill 462 85 499 462 88 499 minecraft:blackstone
fill 462 85 501 462 86 501 minecraft:blackstone
setblock 462 85 503 minecraft:polished_blackstone_bricks
fill 462 85 504 462 88 504 minecraft:blackstone
setblock 463 85 472 minecraft:polished_blackstone_bricks
fill 463 85 473 463 88 473 minecraft:blackstone
setblock 463 85 491 minecraft:blackstone
setblock 463 85 492 minecraft:polished_blackstone_bricks
fill 463 85 493 463 88 493 minecraft:blackstone
setblock 463 85 497 minecraft:polished_blackstone_bricks
fill 463 85 498 463 88 498 minecraft:blackstone
setblock 463 85 502 minecraft:polished_blackstone_bricks
fill 463 85 503 463 88 503 minecraft:blackstone
setblock 464 85 466 minecraft:polished_blackstone_bricks
fill 464 85 467 464 86 467 minecraft:blackstone
setblock 464 85 471 minecraft:polished_blackstone_bricks
fill 464 85 472 464 88 472 minecraft:blackstone
setblock 464 85 476 minecraft:polished_blackstone_bricks
fill 464 85 477 464 88 477 minecraft:blackstone
setblock 464 85 491 minecraft:polished_blackstone_bricks
fill 464 85 492 464 88 492 minecraft:blackstone
setblock 464 85 496 minecraft:polished_blackstone_bricks
fill 464 85 497 464 88 497 minecraft:blackstone
setblock 464 85 501 minecraft:polished_blackstone_bricks
fill 464 85 502 464 88 502 minecraft:blackstone
setblock 424 86 471 minecraft:blackstone
setblock 424 86 475 minecraft:polished_blackstone_bricks
fill 424 86 476 424 89 476 minecraft:blackstone
setblock 424 86 480 minecraft:polished_blackstone_bricks
fill 424 86 481 424 86 484 minecraft:blackstone
setblock 424 86 485 minecraft:polished_blackstone_bricks
fill 424 86 486 424 89 486 minecraft:blackstone
setblock 424 86 490 minecraft:polished_blackstone_bricks
fill 424 86 491 424 89 491 minecraft:blackstone
setblock 424 86 495 minecraft:polished_blackstone_bricks
fill 424 86 496 424 89 496 minecraft:blackstone
setblock 424 86 500 minecraft:polished_blackstone_bricks
fill 424 86 501 424 89 501 minecraft:blackstone
setblock 425 86 490 minecraft:blackstone
setblock 425 86 494 minecraft:polished_blackstone_bricks
fill 425 86 495 425 89 495 minecraft:blackstone
setblock 425 86 499 minecraft:polished_blackstone_bricks
fill 425 86 500 425 89 500 minecraft:blackstone
setblock 425 86 504 minecraft:polished_blackstone_bricks
setblock 440 86 464 minecraft:polished_blackstone_bricks
fill 441 86 464 441 89 464 minecraft:blackstone
fill 443 86 464 443 87 464 minecraft:blackstone
fill 443 86 495 444 87 496 minecraft:cyan_stained_glass
setblock 454 86 464 minecraft:blackstone
setblock 455 86 464 minecraft:polished_blackstone_bricks
setblock 455 86 504 minecraft:polished_blackstone_bricks
fill 456 86 464 456 89 464 minecraft:blackstone
fill 456 86 504 456 89 504 minecraft:blackstone
fill 457 86 503 457 89 503 minecraft:blackstone
setblock 458 86 465 minecraft:blackstone
setblock 459 86 465 minecraft:polished_blackstone_bricks
fill 459 86 502 461 86 502 minecraft:blackstone
setblock 460 86 464 minecraft:polished_blackstone_bricks
fill 460 86 465 460 89 465 minecraft:blackstone
setblock 460 86 504 minecraft:polished_blackstone_bricks
fill 461 86 464 461 89 464 minecraft:blackstone
setblock 461 86 497 minecraft:blackstone
setblock 461 86 498 minecraft:polished_blackstone_bricks
fill 461 86 499 461 89 499 minecraft:blackstone
setblock 461 86 503 minecraft:polished_blackstone_bricks
fill 461 86 504 461 89 504 minecraft:blackstone
fill 462 86 493 462 88 493 minecraft:blackstone
setblock 462 86 496 minecraft:blackstone
setblock 462 86 497 minecraft:polished_blackstone_bricks
fill 462 86 498 462 89 498 minecraft:blackstone
setblock 462 86 502 minecraft:polished_blackstone_bricks
fill 462 86 503 462 89 503 minecraft:blackstone
setblock 463 86 471 minecraft:polished_blackstone_bricks
fill 463 86 472 463 87 472 minecraft:blackstone
setblock 463 86 476 minecraft:polished_blackstone_bricks
fill 463 86 477 463 89 477 minecraft:blackstone
setblock 463 86 491 minecraft:polished_blackstone_bricks
fill 463 86 492 463 89 492 minecraft:blackstone
setblock 463 86 496 minecraft:polished_blackstone_bricks
fill 463 86 497 463 89 497 minecraft:blackstone
setblock 463 86 501 minecraft:polished_blackstone_bricks
fill 463 86 502 463 89 502 minecraft:blackstone
setblock 464 86 465 minecraft:polished_blackstone_bricks
setblock 464 86 466 minecraft:blackstone
setblock 464 86 470 minecraft:polished_blackstone_bricks
fill 464 86 471 464 88 471 minecraft:blackstone
setblock 464 86 475 minecraft:polished_blackstone_bricks
fill 464 86 476 464 89 476 minecraft:blackstone
setblock 464 86 479 minecraft:blackstone
setblock 464 86 490 minecraft:polished_blackstone_bricks
fill 464 86 491 464 89 491 minecraft:blackstone
setblock 464 86 495 minecraft:polished_blackstone_bricks
fill 464 86 496 464 89 496 minecraft:blackstone
setblock 464 86 500 minecraft:polished_blackstone_bricks
fill 464 86 501 464 89 501 minecraft:blackstone
setblock 424 87 474 minecraft:polished_blackstone_bricks
fill 424 87 475 424 90 475 minecraft:blackstone
setblock 424 87 478 minecraft:blackstone
setblock 424 87 479 minecraft:polished_blackstone_bricks
fill 424 87 480 424 87 483 minecraft:blackstone
setblock 424 87 484 minecraft:polished_blackstone_bricks
fill 424 87 485 424 90 485 minecraft:blackstone
setblock 424 87 489 minecraft:polished_blackstone_bricks
schedule function dropper:buildpart/117_2 1t
