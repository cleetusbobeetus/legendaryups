fill 510 184 301 510 186 301 minecraft:deepslate_tiles
setblock 510 184 305 minecraft:cobbled_deepslate
fill 510 184 306 510 187 306 minecraft:deepslate_tiles
setblock 511 184 299 minecraft:cobbled_deepslate
fill 511 184 300 511 187 300 minecraft:deepslate_tiles
setblock 511 184 304 minecraft:cobbled_deepslate
fill 511 184 305 511 187 305 minecraft:deepslate_tiles
setblock 511 184 309 minecraft:cobbled_deepslate
setblock 471 185 298 minecraft:cobbled_deepslate
fill 471 185 299 471 187 299 minecraft:deepslate_tiles
setblock 471 185 303 minecraft:cobbled_deepslate
fill 471 185 304 471 188 304 minecraft:deepslate_tiles
fill 474 185 297 474 187 297 minecraft:black_concrete
fill 474 185 299 474 187 299 minecraft:black_concrete
fill 476 185 297 476 187 297 minecraft:black_concrete
fill 476 185 299 476 187 299 minecraft:black_concrete
fill 479 185 276 479 188 276 minecraft:deepslate_tiles
setblock 482 185 277 minecraft:cobbled_deepslate
fill 482 185 278 482 188 278 minecraft:deepslate_tiles
setblock 483 185 276 minecraft:cobbled_deepslate
fill 483 185 277 483 188 277 minecraft:deepslate_tiles
fill 484 185 276 484 188 276 minecraft:deepslate_tiles
setblock 486 185 278 minecraft:cobbled_deepslate
setblock 487 185 277 minecraft:cobbled_deepslate
setblock 487 185 278 minecraft:deepslate_tiles
setblock 488 185 276 minecraft:cobbled_deepslate
fill 488 185 277 488 186 277 minecraft:deepslate_tiles
fill 489 185 276 489 188 276 minecraft:deepslate_tiles
setblock 493 185 276 minecraft:cobbled_deepslate
setblock 494 185 276 minecraft:deepslate_tiles
setblock 498 185 276 minecraft:cobbled_deepslate
setblock 498 185 277 minecraft:deepslate_tiles
setblock 498 185 316 minecraft:cobbled_deepslate
fill 499 185 276 499 188 276 minecraft:deepslate_tiles
fill 499 185 316 499 188 316 minecraft:deepslate_tiles
setblock 502 185 277 minecraft:cobbled_deepslate
fill 502 185 284 502 186 285 minecraft:white_wool
setblock 503 185 276 minecraft:cobbled_deepslate
fill 503 185 277 503 187 277 minecraft:deepslate_tiles
setblock 503 185 316 minecraft:cobbled_deepslate
fill 504 185 276 504 188 276 minecraft:deepslate_tiles
setblock 504 185 315 minecraft:cobbled_deepslate
fill 504 185 316 504 188 316 minecraft:deepslate_tiles
fill 505 185 293 505 189 293 minecraft:cobbled_deepslate
setblock 505 185 315 minecraft:deepslate_tiles
setblock 505 185 317 minecraft:white_wool
fill 506 185 289 506 190 289 minecraft:bone_block
fill 506 185 292 506 189 292 minecraft:cobbled_deepslate
fill 506 185 294 506 189 294 minecraft:cobbled_deepslate
fill 507 185 293 507 189 293 minecraft:cobbled_deepslate
setblock 508 185 316 minecraft:cobbled_deepslate
fill 510 185 275 510 201 275 minecraft:black_concrete
setblock 510 185 304 minecraft:cobbled_deepslate
fill 510 185 305 510 188 305 minecraft:deepslate_tiles
setblock 511 185 275 minecraft:white_wool
fill 511 185 299 511 186 299 minecraft:deepslate_tiles
setblock 511 185 303 minecraft:cobbled_deepslate
fill 511 185 304 511 188 304 minecraft:deepslate_tiles
setblock 511 185 308 minecraft:cobbled_deepslate
fill 511 185 309 511 188 309 minecraft:deepslate_tiles
fill 512 185 302 512 199 302 minecraft:black_concrete
setblock 512 185 303 minecraft:redstone_block
setblock 471 186 298 minecraft:deepslate_tiles
setblock 471 186 302 minecraft:cobbled_deepslate
fill 471 186 303 471 189 303 minecraft:deepslate_tiles
setblock 471 186 307 minecraft:cobbled_deepslate
fill 474 186 296 474 192 296 minecraft:black_concrete
fill 475 186 294 475 191 294 minecraft:white_wool
setblock 481 186 277 minecraft:cobbled_deepslate
setblock 482 186 276 minecraft:cobbled_deepslate
fill 482 186 277 482 189 277 minecraft:deepslate_tiles
fill 483 186 276 483 189 276 minecraft:deepslate_tiles
setblock 485 186 278 minecraft:cobbled_deepslate
setblock 486 186 277 minecraft:cobbled_deepslate
setblock 487 186 276 minecraft:cobbled_deepslate
fill 487 186 277 487 187 277 minecraft:deepslate_tiles
fill 488 186 276 488 189 276 minecraft:deepslate_tiles
fill 491 186 312 491 187 312 minecraft:cobbled_deepslate
fill 491 186 314 491 187 314 minecraft:cobbled_deepslate
fill 493 186 312 493 187 312 minecraft:cobbled_deepslate
fill 493 186 314 493 187 314 minecraft:cobbled_deepslate
setblock 497 186 276 minecraft:cobbled_deepslate
fill 498 186 276 498 189 276 minecraft:deepslate_tiles
fill 498 186 316 498 189 316 minecraft:deepslate_tiles
setblock 501 186 277 minecraft:cobbled_deepslate
setblock 502 186 276 minecraft:cobbled_deepslate
fill 502 186 277 502 188 277 minecraft:deepslate_tiles
setblock 502 186 316 minecraft:cobbled_deepslate
fill 503 186 276 503 189 276 minecraft:deepslate_tiles
setblock 503 186 315 minecraft:cobbled_deepslate
fill 503 186 316 503 189 316 minecraft:deepslate_tiles
fill 504 186 288 505 189 290 minecraft:bone_block
fill 504 186 315 504 189 315 minecraft:deepslate_tiles
fill 505 186 287 507 189 287 minecraft:bone_block
fill 505 186 291 507 189 291 minecraft:bone_block
fill 505 186 317 505 195 317 minecraft:black_concrete
fill 506 186 288 508 189 288 minecraft:bone_block
fill 506 186 290 508 189 290 minecraft:bone_block
fill 507 186 289 508 189 289 minecraft:bone_block
setblock 507 186 316 minecraft:cobbled_deepslate
fill 508 186 307 508 190 307 minecraft:black_concrete
fill 509 186 306 509 189 306 minecraft:black_concrete
fill 509 186 308 509 190 308 minecraft:black_concrete
setblock 510 186 303 minecraft:cobbled_deepslate
fill 510 186 304 510 189 304 minecraft:deepslate_tiles
fill 511 186 275 511 201 275 minecraft:black_concrete
setblock 511 186 302 minecraft:cobbled_deepslate
fill 511 186 303 511 189 303 minecraft:deepslate_tiles
setblock 511 186 307 minecraft:cobbled_deepslate
fill 511 186 308 511 189 308 minecraft:deepslate_tiles
fill 512 186 303 512 201 303 minecraft:black_concrete
setblock 470 187 301 minecraft:redstone_block
fill 471 187 284 471 187 285 minecraft:deepslate_tiles
setblock 471 187 301 minecraft:cobbled_deepslate
fill 471 187 302 471 190 302 minecraft:deepslate_tiles
setblock 471 187 306 minecraft:cobbled_deepslate
fill 471 187 307 471 190 307 minecraft:deepslate_tiles
setblock 473 187 278 minecraft:light[level=12]
setblock 473 187 285 minecraft:light[level=12]
setblock 473 187 292 minecraft:light[level=12]
setblock 473 187 298 minecraft:black_concrete
setblock 473 187 299 minecraft:light[level=12]
setblock 473 187 306 minecraft:light[level=12]
setblock 473 187 313 minecraft:light[level=12]
setblock 475 187 296 minecraft:black_concrete
setblock 475 187 300 minecraft:black_concrete
fill 475 187 308 475 188 308 minecraft:black_concrete
setblock 475 187 312 minecraft:white_wool
setblock 476 187 313 minecraft:white_wool
setblock 477 187 298 minecraft:black_concrete
setblock 477 187 314 minecraft:white_wool
setblock 478 187 315 minecraft:white_wool
setblock 480 187 277 minecraft:cobbled_deepslate
setblock 480 187 278 minecraft:light[level=12]
setblock 480 187 285 minecraft:light[level=12]
setblock 480 187 292 minecraft:light[level=12]
setblock 480 187 299 minecraft:light[level=12]
setblock 480 187 306 minecraft:light[level=12]
setblock 480 187 313 minecraft:light[level=12]
setblock 481 187 276 minecraft:cobbled_deepslate
fill 481 187 277 481 190 277 minecraft:deepslate_tiles
fill 482 187 276 482 190 276 minecraft:deepslate_tiles
fill 483 187 311 483 188 311 minecraft:black_concrete
setblock 484 187 278 minecraft:cobbled_deepslate
setblock 485 187 277 minecraft:cobbled_deepslate
setblock 486 187 276 minecraft:cobbled_deepslate
fill 486 187 277 486 189 277 minecraft:deepslate_tiles
fill 487 187 276 487 190 276 minecraft:deepslate_tiles
setblock 487 187 278 minecraft:light[level=12]
setblock 487 187 285 minecraft:light[level=12]
setblock 487 187 292 minecraft:light[level=12]
setblock 487 187 299 minecraft:light[level=12]
setblock 487 187 306 minecraft:light[level=12]
setblock 487 187 313 minecraft:light[level=12]
setblock 494 187 278 minecraft:light[level=12]
setblock 494 187 285 minecraft:light[level=12]
setblock 494 187 292 minecraft:light[level=12]
setblock 494 187 299 minecraft:light[level=12]
setblock 494 187 306 minecraft:light[level=12]
fill 494 187 311 494 188 311 minecraft:black_concrete
setblock 494 187 313 minecraft:light[level=12]
setblock 496 187 276 minecraft:cobbled_deepslate
fill 497 187 276 497 190 276 minecraft:deepslate_tiles
setblock 497 187 317 minecraft:white_wool
setblock 498 187 317 minecraft:redstone_block
setblock 500 187 277 minecraft:cobbled_deepslate
setblock 501 187 276 minecraft:cobbled_deepslate
fill 501 187 277 501 190 277 minecraft:deepslate_tiles
setblock 501 187 278 minecraft:light[level=12]
setblock 501 187 285 minecraft:light[level=12]
setblock 501 187 292 minecraft:light[level=12]
setblock 501 187 299 minecraft:light[level=12]
setblock 501 187 306 minecraft:light[level=12]
setblock 501 187 313 minecraft:light[level=12]
setblock 501 187 315 minecraft:deepslate_tiles
setblock 501 187 316 minecraft:cobbled_deepslate
fill 502 187 276 502 190 276 minecraft:deepslate_tiles
setblock 502 187 315 minecraft:cobbled_deepslate
fill 502 187 316 502 190 316 minecraft:deepslate_tiles
fill 503 187 311 503 188 311 minecraft:black_concrete
fill 503 187 315 503 190 315 minecraft:deepslate_tiles
fill 505 187 292 505 189 292 minecraft:cobbled_deepslate
fill 505 187 294 505 189 294 minecraft:cobbled_deepslate
setblock 506 187 316 minecraft:cobbled_deepslate
fill 507 187 292 507 189 292 minecraft:cobbled_deepslate
fill 507 187 294 507 189 294 minecraft:cobbled_deepslate
setblock 508 187 278 minecraft:light[level=12]
setblock 508 187 285 minecraft:light[level=12]
setblock 508 187 292 minecraft:light[level=12]
setblock 508 187 299 minecraft:light[level=12]
setblock 508 187 306 minecraft:light[level=12]
setblock 508 187 313 minecraft:light[level=12]
setblock 510 187 302 minecraft:cobbled_deepslate
fill 510 187 303 510 190 303 minecraft:deepslate_tiles
setblock 510 187 307 minecraft:cobbled_deepslate
setblock 511 187 301 minecraft:cobbled_deepslate
fill 511 187 302 511 190 302 minecraft:deepslate_tiles
setblock 511 187 306 minecraft:cobbled_deepslate
fill 511 187 307 511 190 307 minecraft:deepslate_tiles
fill 470 188 301 470 201 301 minecraft:black_concrete
fill 471 188 283 471 188 284 minecraft:deepslate_tiles
setblock 471 188 285 minecraft:cobbled_deepslate
fill 471 188 286 471 189 288 minecraft:deepslate_tiles
setblock 471 188 300 minecraft:cobbled_deepslate
fill 471 188 301 471 191 301 minecraft:deepslate_tiles
setblock 471 188 305 minecraft:cobbled_deepslate
fill 471 188 306 471 191 306 minecraft:deepslate_tiles
setblock 471 188 308 minecraft:white_wool
setblock 472 188 309 minecraft:white_wool
setblock 473 188 310 minecraft:white_wool
fill 474 188 308 474 189 308 minecraft:black_concrete
setblock 474 188 311 minecraft:white_wool
fill 478 188 276 478 189 276 minecraft:deepslate_tiles
setblock 480 188 276 minecraft:cobbled_deepslate
fill 480 188 277 480 191 277 minecraft:deepslate_tiles
fill 481 188 276 481 191 276 minecraft:deepslate_tiles
setblock 483 188 278 minecraft:cobbled_deepslate
fill 483 188 312 483 189 312 minecraft:black_concrete
setblock 484 188 277 minecraft:cobbled_deepslate
setblock 485 188 276 minecraft:cobbled_deepslate
fill 485 188 277 485 191 277 minecraft:deepslate_tiles
fill 486 188 276 486 191 276 minecraft:deepslate_tiles
fill 494 188 312 494 189 312 minecraft:black_concrete
setblock 495 188 276 minecraft:cobbled_deepslate
fill 496 188 276 496 191 276 minecraft:deepslate_tiles
fill 497 188 316 497 190 316 minecraft:deepslate_tiles
fill 497 188 317 498 201 317 minecraft:black_concrete
setblock 499 188 277 minecraft:cobbled_deepslate
fill 499 188 315 500 188 315 minecraft:deepslate_tiles
setblock 500 188 276 minecraft:cobbled_deepslate
fill 500 188 277 500 191 277 minecraft:deepslate_tiles
setblock 500 188 316 minecraft:cobbled_deepslate
fill 501 188 276 501 191 276 minecraft:deepslate_tiles
setblock 501 188 315 minecraft:cobbled_deepslate
fill 501 188 316 501 191 316 minecraft:deepslate_tiles
fill 502 188 315 502 191 315 minecraft:deepslate_tiles
fill 503 188 312 503 189 312 minecraft:black_concrete
setblock 505 188 316 minecraft:cobbled_deepslate
fill 506 188 316 506 191 316 minecraft:deepslate_tiles
fill 508 188 306 508 190 306 minecraft:black_concrete
fill 508 188 308 508 190 308 minecraft:black_concrete
fill 510 188 302 510 190 302 minecraft:deepslate_tiles
setblock 510 188 306 minecraft:cobbled_deepslate
fill 510 188 307 510 190 308 minecraft:deepslate_tiles
setblock 511 188 300 minecraft:cobbled_deepslate
fill 511 188 301 511 191 301 minecraft:deepslate_tiles
setblock 511 188 305 minecraft:cobbled_deepslate
fill 511 188 306 511 191 306 minecraft:deepslate_tiles
setblock 511 188 310 minecraft:cobbled_deepslate
fill 471 189 282 471 189 283 minecraft:deepslate_tiles
setblock 471 189 284 minecraft:cobbled_deepslate
fill 471 189 285 471 192 285 minecraft:deepslate_tiles
setblock 471 189 289 minecraft:cobbled_deepslate
fill 471 189 290 471 192 290 minecraft:deepslate_tiles
fill 471 189 300 471 192 300 minecraft:deepslate_tiles
setblock 471 189 304 minecraft:cobbled_deepslate
fill 471 189 305 471 192 305 minecraft:deepslate_tiles
setblock 471 189 308 minecraft:deepslate_tiles
fill 472 189 286 472 190 286 minecraft:deepslate_tiles
setblock 473 189 278 minecraft:light[level=13]
setblock 473 189 286 minecraft:light[level=13]
setblock 473 189 294 minecraft:light[level=13]
setblock 473 189 302 minecraft:light[level=13]
fill 473 189 308 473 190 308 minecraft:black_concrete
setblock 473 189 310 minecraft:light[level=13]
setblock 479 189 276 minecraft:cobbled_deepslate
fill 479 189 277 479 192 277 minecraft:deepslate_tiles
fill 480 189 276 480 192 276 minecraft:deepslate_tiles
setblock 481 189 278 minecraft:deepslate_tiles
setblock 481 189 286 minecraft:light[level=13]
setblock 481 189 294 minecraft:light[level=13]
setblock 481 189 302 minecraft:light[level=13]
setblock 481 189 310 minecraft:light[level=13]
setblock 482 189 278 minecraft:cobbled_deepslate
setblock 483 189 277 minecraft:cobbled_deepslate
setblock 483 189 278 minecraft:deepslate_tiles
fill 483 189 313 483 190 313 minecraft:black_concrete
setblock 484 189 276 minecraft:cobbled_deepslate
fill 484 189 277 484 192 277 minecraft:deepslate_tiles
fill 485 189 276 485 192 276 minecraft:deepslate_tiles
setblock 489 189 278 minecraft:light[level=13]
setblock 489 189 286 minecraft:light[level=13]
setblock 489 189 294 minecraft:light[level=13]
setblock 489 189 302 minecraft:light[level=13]
setblock 489 189 310 minecraft:light[level=13]
fill 494 189 313 494 190 313 minecraft:black_concrete
fill 495 189 276 495 192 276 minecraft:deepslate_tiles
fill 495 189 316 496 191 316 minecraft:deepslate_tiles
fill 496 189 281 496 209 281 minecraft:white_wool
setblock 497 189 278 minecraft:light[level=13]
setblock 497 189 286 minecraft:light[level=13]
setblock 497 189 294 minecraft:light[level=13]
setblock 497 189 302 minecraft:light[level=13]
setblock 497 189 310 minecraft:light[level=13]
fill 498 189 315 499 189 315 minecraft:deepslate_tiles
setblock 499 189 276 minecraft:cobbled_deepslate
fill 499 189 277 499 192 277 minecraft:deepslate_tiles
setblock 499 189 316 minecraft:cobbled_deepslate
fill 500 189 276 500 192 276 minecraft:deepslate_tiles
fill 500 189 280 500 193 280 minecraft:cobbled_deepslate
setblock 500 189 315 minecraft:cobbled_deepslate
fill 500 189 316 500 192 316 minecraft:deepslate_tiles
fill 501 189 315 501 192 315 minecraft:deepslate_tiles
fill 503 189 313 503 190 313 minecraft:black_concrete
setblock 504 189 276 minecraft:cobbled_deepslate
setblock 504 189 316 minecraft:cobbled_deepslate
setblock 505 189 278 minecraft:light[level=13]
setblock 505 189 286 minecraft:light[level=13]
setblock 505 189 302 minecraft:light[level=13]
setblock 505 189 310 minecraft:light[level=13]
fill 505 189 316 505 192 316 minecraft:deepslate_tiles
setblock 510 189 305 minecraft:cobbled_deepslate
fill 510 189 306 510 192 306 minecraft:deepslate_tiles
setblock 510 189 309 minecraft:deepslate_tiles
fill 511 189 300 511 192 300 minecraft:deepslate_tiles
setblock 511 189 304 minecraft:cobbled_deepslate
fill 511 189 305 511 192 305 minecraft:deepslate_tiles
setblock 511 189 309 minecraft:cobbled_deepslate
fill 511 189 310 511 191 311 minecraft:deepslate_tiles
setblock 471 190 282 minecraft:deepslate_tiles
setblock 471 190 283 minecraft:cobbled_deepslate
fill 471 190 284 472 192 284 minecraft:deepslate_tiles
fill 471 190 286 471 190 287 minecraft:deepslate_tiles
setblock 471 190 288 minecraft:cobbled_deepslate
fill 471 190 289 472 192 289 minecraft:deepslate_tiles
fill 471 190 291 471 190 292 minecraft:deepslate_tiles
setblock 471 190 293 minecraft:cobbled_deepslate
setblock 471 190 303 minecraft:cobbled_deepslate
fill 471 190 304 471 193 304 minecraft:deepslate_tiles
setblock 471 190 308 minecraft:cobbled_deepslate
fill 471 190 309 471 193 309 minecraft:deepslate_tiles
fill 472 190 285 472 191 285 minecraft:deepslate_tiles
setblock 472 190 287 minecraft:cobbled_deepslate
fill 472 190 288 472 193 288 minecraft:deepslate_tiles
fill 472 190 308 472 191 308 minecraft:black_concrete
setblock 477 190 276 minecraft:deepslate_tiles
setblock 478 190 276 minecraft:cobbled_deepslate
fill 478 190 277 478 193 277 minecraft:deepslate_tiles
fill 479 190 276 479 193 276 minecraft:deepslate_tiles
setblock 480 190 278 minecraft:deepslate_tiles
fill 480 190 316 482 190 316 minecraft:deepslate_tiles
setblock 481 190 278 minecraft:cobbled_deepslate
setblock 482 190 277 minecraft:cobbled_deepslate
fill 482 190 278 482 191 278 minecraft:deepslate_tiles
setblock 483 190 276 minecraft:cobbled_deepslate
fill 483 190 277 483 193 277 minecraft:deepslate_tiles
fill 483 190 314 483 191 314 minecraft:black_concrete
setblock 483 190 316 minecraft:cobbled_deepslate
fill 484 190 276 484 193 276 minecraft:deepslate_tiles
fill 484 190 316 484 193 316 minecraft:deepslate_tiles
setblock 488 190 276 minecraft:cobbled_deepslate
fill 494 190 276 494 193 276 minecraft:deepslate_tiles
fill 494 190 314 494 191 314 minecraft:black_concrete
fill 494 190 316 494 193 316 minecraft:deepslate_tiles
fill 496 190 315 498 190 315 minecraft:deepslate_tiles
setblock 498 190 276 minecraft:cobbled_deepslate
fill 498 190 277 498 193 277 minecraft:deepslate_tiles
setblock 498 190 316 minecraft:cobbled_deepslate
fill 499 190 276 499 193 276 minecraft:deepslate_tiles
setblock 499 190 314 minecraft:deepslate_tiles
setblock 499 190 315 minecraft:cobbled_deepslate
fill 499 190 316 499 193 316 minecraft:deepslate_tiles
setblock 500 190 314 minecraft:cobbled_deepslate
fill 500 190 315 500 193 315 minecraft:deepslate_tiles
fill 501 190 314 503 191 314 minecraft:deepslate_tiles
setblock 503 190 276 minecraft:cobbled_deepslate
setblock 503 190 316 minecraft:cobbled_deepslate
setblock 504 190 276 minecraft:deepslate_tiles
setblock 504 190 315 minecraft:cobbled_deepslate
fill 504 190 316 504 193 316 minecraft:deepslate_tiles
fill 506 190 305 506 203 305 minecraft:white_wool
fill 509 190 306 509 191 306 minecraft:deepslate_tiles
setblock 510 190 304 minecraft:cobbled_deepslate
fill 510 190 305 510 193 305 minecraft:deepslate_tiles
setblock 510 190 309 minecraft:cobbled_deepslate
fill 510 190 310 510 193 310 minecraft:deepslate_tiles
fill 511 190 285 511 190 287 minecraft:deepslate_tiles
setblock 511 190 303 minecraft:cobbled_deepslate
fill 511 190 304 511 193 304 minecraft:deepslate_tiles
setblock 511 190 308 minecraft:cobbled_deepslate
fill 511 190 309 511 193 309 minecraft:deepslate_tiles
setblock 511 190 312 minecraft:deepslate_tiles
setblock 471 191 281 minecraft:deepslate_tiles
setblock 471 191 282 minecraft:cobbled_deepslate
fill 471 191 283 472 193 283 minecraft:deepslate_tiles
setblock 471 191 286 minecraft:deepslate_tiles
setblock 471 191 287 minecraft:cobbled_deepslate
fill 471 191 288 471 194 288 minecraft:deepslate_tiles
setblock 471 191 291 minecraft:deepslate_tiles
setblock 471 191 292 minecraft:cobbled_deepslate
fill 471 191 293 471 192 295 minecraft:deepslate_tiles
setblock 471 191 302 minecraft:cobbled_deepslate
fill 471 191 303 471 194 303 minecraft:deepslate_tiles
setblock 471 191 307 minecraft:cobbled_deepslate
setblock 471 191 308 minecraft:deepslate_tiles
fill 471 191 310 471 192 310 minecraft:deepslate_tiles
setblock 472 191 286 minecraft:cobbled_deepslate
fill 472 191 287 473 193 287 minecraft:deepslate_tiles
setblock 472 191 290 minecraft:deepslate_tiles
setblock 472 191 291 minecraft:cobbled_deepslate
setblock 473 191 285 minecraft:cobbled_deepslate
fill 473 191 286 473 194 286 minecraft:deepslate_tiles
fill 473 191 288 473 191 289 minecraft:deepslate_tiles
fill 473 191 296 473 192 296 minecraft:black_concrete
fill 474 191 295 474 192 295 minecraft:black_concrete
fill 474 191 297 474 192 297 minecraft:black_concrete
fill 475 191 296 475 192 296 minecraft:black_concrete
setblock 475 191 312 minecraft:white_wool
setblock 476 191 276 minecraft:deepslate_tiles
setblock 476 191 313 minecraft:white_wool
setblock 477 191 276 minecraft:cobbled_deepslate
setblock 477 191 314 minecraft:white_wool
fill 478 191 276 478 194 276 minecraft:deepslate_tiles
setblock 478 191 315 minecraft:white_wool
fill 478 191 316 481 191 316 minecraft:deepslate_tiles
setblock 480 191 278 minecraft:cobbled_deepslate
setblock 481 191 277 minecraft:cobbled_deepslate
fill 481 191 278 481 192 278 minecraft:deepslate_tiles
setblock 482 191 276 minecraft:cobbled_deepslate
fill 482 191 277 482 194 277 minecraft:deepslate_tiles
setblock 482 191 316 minecraft:cobbled_deepslate
fill 483 191 276 483 194 276 minecraft:deepslate_tiles
fill 483 191 315 483 192 315 minecraft:black_concrete
fill 483 191 316 483 194 316 minecraft:deepslate_tiles
fill 485 191 316 485 192 316 minecraft:deepslate_tiles
setblock 487 191 276 minecraft:cobbled_deepslate
fill 488 191 276 488 194 276 minecraft:deepslate_tiles
setblock 492 191 276 minecraft:cobbled_deepslate
setblock 492 191 316 minecraft:cobbled_deepslate
fill 493 191 276 493 194 276 minecraft:deepslate_tiles
fill 493 191 316 493 194 316 minecraft:deepslate_tiles
setblock 494 191 315 minecraft:black_concrete
fill 495 191 315 497 191 315 minecraft:deepslate_tiles
setblock 497 191 276 minecraft:cobbled_deepslate
fill 497 191 277 497 194 277 minecraft:deepslate_tiles
fill 497 191 314 498 191 314 minecraft:deepslate_tiles
setblock 497 191 316 minecraft:cobbled_deepslate
fill 498 191 276 498 194 276 minecraft:deepslate_tiles
setblock 498 191 315 minecraft:cobbled_deepslate
fill 498 191 316 498 194 316 minecraft:deepslate_tiles
setblock 499 191 313 minecraft:deepslate_tiles
setblock 499 191 314 minecraft:cobbled_deepslate
fill 499 191 315 499 194 315 minecraft:deepslate_tiles
setblock 500 191 313 minecraft:cobbled_deepslate
fill 500 191 314 500 194 314 minecraft:deepslate_tiles
fill 501 191 313 501 194 313 minecraft:deepslate_tiles
setblock 502 191 276 minecraft:cobbled_deepslate
setblock 502 191 316 minecraft:cobbled_deepslate
fill 503 191 276 503 192 276 minecraft:deepslate_tiles
setblock 503 191 315 minecraft:cobbled_deepslate
fill 503 191 316 503 194 316 minecraft:deepslate_tiles
fill 504 191 315 505 193 315 minecraft:deepslate_tiles
setblock 509 191 275 minecraft:redstone_block
fill 509 191 307 510 191 307 minecraft:deepslate_tiles
setblock 510 191 303 minecraft:cobbled_deepslate
fill 510 191 304 510 194 304 minecraft:deepslate_tiles
setblock 510 191 308 minecraft:cobbled_deepslate
fill 510 191 309 510 194 309 minecraft:deepslate_tiles
fill 511 191 284 511 191 286 minecraft:deepslate_tiles
setblock 511 191 287 minecraft:cobbled_deepslate
fill 511 191 288 511 191 291 minecraft:deepslate_tiles
fill 511 191 299 511 193 299 minecraft:deepslate_tiles
setblock 511 191 302 minecraft:cobbled_deepslate
fill 511 191 303 511 194 303 minecraft:deepslate_tiles
setblock 511 191 307 minecraft:cobbled_deepslate
fill 511 191 308 511 194 308 minecraft:deepslate_tiles
setblock 511 191 312 minecraft:cobbled_deepslate
setblock 470 192 281 minecraft:redstone_block
setblock 471 192 281 minecraft:cobbled_deepslate
fill 471 192 282 471 195 282 minecraft:deepslate_tiles
setblock 471 192 286 minecraft:cobbled_deepslate
fill 471 192 287 471 195 287 minecraft:deepslate_tiles
setblock 471 192 291 minecraft:cobbled_deepslate
fill 471 192 292 472 194 292 minecraft:deepslate_tiles
setblock 471 192 296 minecraft:cobbled_deepslate
fill 471 192 297 471 195 297 minecraft:deepslate_tiles
setblock 471 192 301 minecraft:cobbled_deepslate
fill 471 192 302 471 194 302 minecraft:deepslate_tiles
setblock 471 192 306 minecraft:cobbled_deepslate
fill 471 192 307 472 193 307 minecraft:deepslate_tiles
setblock 471 192 308 minecraft:white_wool
setblock 471 192 311 minecraft:cobbled_deepslate
setblock 472 192 285 minecraft:cobbled_deepslate
fill 472 192 286 472 195 286 minecraft:deepslate_tiles
setblock 472 192 290 minecraft:cobbled_deepslate
fill 472 192 291 473 194 291 minecraft:deepslate_tiles
fill 472 192 293 472 193 293 minecraft:deepslate_tiles
setblock 472 192 306 minecraft:deepslate_tiles
setblock 472 192 309 minecraft:white_wool
setblock 473 192 284 minecraft:cobbled_deepslate
fill 473 192 285 473 195 285 minecraft:deepslate_tiles
setblock 473 192 288 minecraft:deepslate_tiles
setblock 473 192 289 minecraft:cobbled_deepslate
fill 473 192 290 473 195 290 minecraft:deepslate_tiles
setblock 473 192 310 minecraft:white_wool
fill 474 192 286 474 192 287 minecraft:deepslate_tiles
setblock 474 192 288 minecraft:cobbled_deepslate
setblock 474 192 311 minecraft:white_wool
setblock 475 192 276 minecraft:deepslate_tiles
setblock 475 192 282 minecraft:crying_obsidian
setblock 475 192 288 minecraft:crying_obsidian
setblock 475 192 294 minecraft:crying_obsidian
setblock 475 192 300 minecraft:crying_obsidian
setblock 475 192 306 minecraft:crying_obsidian
setblock 475 192 312 minecraft:crying_obsidian
setblock 476 192 276 minecraft:cobbled_deepslate
fill 477 192 276 477 194 277 minecraft:deepslate_tiles
setblock 477 192 280 minecraft:crying_obsidian
fill 477 192 316 480 192 316 minecraft:deepslate_tiles
setblock 478 192 317 minecraft:white_wool
setblock 479 192 278 minecraft:cobbled_deepslate
setblock 480 192 277 minecraft:cobbled_deepslate
fill 480 192 278 480 193 278 minecraft:deepslate_tiles
fill 480 192 315 481 192 315 minecraft:deepslate_tiles
setblock 481 192 276 minecraft:cobbled_deepslate
fill 481 192 277 481 195 277 minecraft:deepslate_tiles
setblock 481 192 312 minecraft:crying_obsidian
setblock 481 192 316 minecraft:cobbled_deepslate
fill 482 192 276 482 195 276 minecraft:deepslate_tiles
fill 482 192 316 482 195 316 minecraft:deepslate_tiles
setblock 483 192 280 minecraft:crying_obsidian
setblock 486 192 276 minecraft:cobbled_deepslate
setblock 486 192 316 minecraft:cobbled_deepslate
fill 487 192 276 487 195 276 minecraft:deepslate_tiles
setblock 487 192 312 minecraft:crying_obsidian
fill 489 192 276 489 193 276 minecraft:deepslate_tiles
setblock 489 192 280 minecraft:crying_obsidian
setblock 490 192 316 minecraft:deepslate_tiles
setblock 491 192 276 minecraft:cobbled_deepslate
setblock 491 192 316 minecraft:cobbled_deepslate
fill 492 192 276 492 195 276 minecraft:deepslate_tiles
fill 492 192 316 492 195 316 minecraft:deepslate_tiles
setblock 493 192 312 minecraft:crying_obsidian
fill 493 192 315 496 192 315 minecraft:deepslate_tiles
setblock 495 192 280 minecraft:crying_obsidian
fill 495 192 314 497 192 314 minecraft:deepslate_tiles
setblock 495 192 316 minecraft:deepslate_tiles
setblock 496 192 276 minecraft:cobbled_deepslate
fill 496 192 277 496 194 277 minecraft:deepslate_tiles
setblock 496 192 316 minecraft:cobbled_deepslate
fill 497 192 276 497 195 276 minecraft:deepslate_tiles
fill 497 192 313 498 192 313 minecraft:deepslate_tiles
setblock 497 192 315 minecraft:cobbled_deepslate
fill 497 192 316 497 195 316 minecraft:deepslate_tiles
setblock 498 192 314 minecraft:cobbled_deepslate
fill 498 192 315 498 195 315 minecraft:deepslate_tiles
setblock 499 192 312 minecraft:crying_obsidian
setblock 499 192 313 minecraft:cobbled_deepslate
fill 499 192 314 499 195 314 minecraft:deepslate_tiles
fill 500 192 277 500 193 277 minecraft:cobbled_deepslate
fill 500 192 313 500 195 313 minecraft:deepslate_tiles
setblock 501 192 276 minecraft:cobbled_deepslate
setblock 501 192 280 minecraft:crying_obsidian
fill 501 192 314 502 192 314 minecraft:deepslate_tiles
setblock 501 192 316 minecraft:cobbled_deepslate
fill 502 192 276 502 194 276 minecraft:deepslate_tiles
fill 502 192 313 502 193 313 minecraft:deepslate_tiles
setblock 502 192 315 minecraft:cobbled_deepslate
fill 502 192 316 502 195 316 minecraft:deepslate_tiles
setblock 503 192 314 minecraft:cobbled_deepslate
fill 503 192 315 503 195 315 minecraft:deepslate_tiles
setblock 505 192 312 minecraft:crying_obsidian
setblock 506 192 316 minecraft:cobbled_deepslate
setblock 507 192 280 minecraft:crying_obsidian
setblock 507 192 286 minecraft:crying_obsidian
setblock 507 192 292 minecraft:crying_obsidian
setblock 507 192 298 minecraft:crying_obsidian
setblock 507 192 304 minecraft:crying_obsidian
setblock 507 192 310 minecraft:crying_obsidian
fill 509 192 275 509 201 275 minecraft:black_concrete
setblock 509 192 307 minecraft:deepslate_tiles
fill 509 192 308 509 193 308 minecraft:cobbled_deepslate
fill 510 192 303 510 193 303 minecraft:deepslate_tiles
setblock 510 192 307 minecraft:cobbled_deepslate
fill 510 192 308 510 195 308 minecraft:deepslate_tiles
setblock 510 192 311 minecraft:deepslate_tiles
fill 511 192 284 511 192 285 minecraft:deepslate_tiles
setblock 511 192 286 minecraft:cobbled_deepslate
fill 511 192 287 511 192 290 minecraft:deepslate_tiles
setblock 511 192 291 minecraft:cobbled_deepslate
fill 511 192 292 511 193 294 minecraft:deepslate_tiles
fill 511 192 298 511 194 298 minecraft:deepslate_tiles
setblock 511 192 301 minecraft:cobbled_deepslate
fill 511 192 302 511 195 302 minecraft:deepslate_tiles
setblock 511 192 306 minecraft:cobbled_deepslate
fill 511 192 307 511 195 307 minecraft:deepslate_tiles
setblock 511 192 310 minecraft:deepslate_tiles
setblock 511 192 311 minecraft:cobbled_deepslate
fill 511 192 312 511 194 313 minecraft:deepslate_tiles
fill 512 192 291 512 201 291 minecraft:black_concrete
setblock 512 192 292 minecraft:redstone_block
fill 512 192 293 512 201 294 minecraft:black_concrete
fill 470 193 281 470 194 281 minecraft:black_concrete
fill 471 193 276 475 193 280 minecraft:cobbled_deepslate
fill 471 193 281 471 195 281 minecraft:deepslate_tiles
setblock 471 193 284 minecraft:deepslate_tiles
setblock 471 193 285 minecraft:cobbled_deepslate
fill 471 193 286 471 196 286 minecraft:deepslate_tiles
setblock 471 193 289 minecraft:deepslate_tiles
setblock 471 193 290 minecraft:cobbled_deepslate
fill 471 193 291 471 196 291 minecraft:deepslate_tiles
fill 471 193 293 471 193 294 minecraft:deepslate_tiles
fill 471 193 295 475 193 295 minecraft:cobbled_deepslate
fill 471 193 296 471 196 296 minecraft:deepslate_tiles
fill 471 193 298 471 194 298 minecraft:deepslate_tiles
fill 471 193 299 475 193 300 minecraft:cobbled_deepslate
setblock 471 193 301 minecraft:deepslate_tiles
fill 471 193 305 475 193 305 minecraft:cobbled_deepslate
fill 471 193 306 471 196 306 minecraft:deepslate_tiles
fill 471 193 308 472 193 308 minecraft:deepslate_tiles
fill 471 193 310 475 193 310 minecraft:cobbled_deepslate
fill 471 193 311 471 195 312 minecraft:deepslate_tiles
fill 471 193 313 475 193 316 minecraft:cobbled_deepslate
fill 472 193 281 475 193 281 minecraft:cobbled_deepslate
fill 472 193 282 472 194 282 minecraft:deepslate_tiles
setblock 472 193 284 minecraft:cobbled_deepslate
fill 472 193 285 472 196 285 minecraft:deepslate_tiles
setblock 472 193 289 minecraft:cobbled_deepslate
fill 472 193 290 472 196 290 minecraft:deepslate_tiles
fill 472 193 294 475 193 294 minecraft:cobbled_deepslate
fill 472 193 296 475 193 298 minecraft:cobbled_deepslate
fill 472 193 301 475 193 304 minecraft:cobbled_deepslate
fill 472 193 306 475 193 306 minecraft:cobbled_deepslate
fill 472 193 309 475 193 309 minecraft:cobbled_deepslate
fill 472 193 311 475 193 312 minecraft:cobbled_deepslate
fill 473 193 282 475 193 283 minecraft:cobbled_deepslate
fill 473 193 284 473 196 284 minecraft:deepslate_tiles
setblock 473 193 288 minecraft:cobbled_deepslate
fill 473 193 289 474 195 289 minecraft:deepslate_tiles
setblock 473 193 292 minecraft:deepslate_tiles
fill 473 193 293 475 193 293 minecraft:cobbled_deepslate
fill 473 193 307 475 193 308 minecraft:cobbled_deepslate
fill 474 193 284 475 193 284 minecraft:cobbled_deepslate
fill 474 193 285 474 193 286 minecraft:deepslate_tiles
fill 474 193 287 475 193 287 minecraft:cobbled_deepslate
fill 474 193 288 474 196 288 minecraft:deepslate_tiles
fill 474 193 290 474 194 290 minecraft:deepslate_tiles
fill 474 193 291 475 193 292 minecraft:cobbled_deepslate
fill 475 193 275 478 197 275 minecraft:black_concrete
fill 475 193 285 475 193 286 minecraft:cobbled_deepslate
fill 475 193 288 475 193 290 minecraft:cobbled_deepslate
fill 476 193 276 476 195 277 minecraft:deepslate_tiles
fill 476 193 278 478 193 280 minecraft:cobbled_deepslate
fill 476 193 312 477 193 315 minecraft:cobbled_deepslate
fill 476 193 316 479 193 316 minecraft:deepslate_tiles
fill 478 193 312 493 193 314 minecraft:cobbled_deepslate
fill 478 193 315 480 193 315 minecraft:deepslate_tiles
fill 478 193 317 478 201 317 minecraft:black_concrete
setblock 479 193 275 minecraft:white_wool
setblock 479 193 277 minecraft:cobbled_deepslate
setblock 479 193 278 minecraft:deepslate_tiles
fill 479 193 279 499 193 280 minecraft:cobbled_deepslate
setblock 480 193 276 minecraft:cobbled_deepslate
fill 480 193 277 480 196 277 minecraft:deepslate_tiles
setblock 480 193 285 minecraft:light[level=12]
setblock 480 193 292 minecraft:light[level=12]
setblock 480 193 299 minecraft:light[level=12]
setblock 480 193 306 minecraft:light[level=12]
setblock 480 193 316 minecraft:cobbled_deepslate
fill 481 193 276 481 196 276 minecraft:deepslate_tiles
fill 481 193 278 511 193 278 minecraft:cobbled_deepslate
setblock 481 193 315 minecraft:cobbled_deepslate
fill 481 193 316 481 196 316 minecraft:deepslate_tiles
fill 482 193 315 482 196 315 minecraft:deepslate_tiles
fill 483 193 315 491 193 315 minecraft:cobbled_deepslate
fill 484 193 277 495 193 277 minecraft:cobbled_deepslate
setblock 485 193 276 minecraft:cobbled_deepslate
setblock 485 193 316 minecraft:cobbled_deepslate
fill 486 193 276 486 195 276 minecraft:deepslate_tiles
fill 486 193 316 489 193 316 minecraft:deepslate_tiles
setblock 487 193 285 minecraft:light[level=12]
setblock 487 193 292 minecraft:light[level=12]
setblock 487 193 299 minecraft:light[level=12]
setblock 487 193 306 minecraft:light[level=12]
setblock 490 193 276 minecraft:cobbled_deepslate
setblock 490 193 316 minecraft:cobbled_deepslate
fill 491 193 276 491 196 276 minecraft:deepslate_tiles
fill 491 193 316 491 196 316 minecraft:deepslate_tiles
fill 492 193 315 495 193 315 minecraft:deepslate_tiles
setblock 494 193 285 minecraft:light[level=12]
setblock 494 193 292 minecraft:light[level=12]
setblock 494 193 299 minecraft:light[level=12]
setblock 494 193 306 minecraft:light[level=12]
fill 494 193 312 495 193 313 minecraft:cobbled_deepslate
fill 494 193 314 496 193 314 minecraft:deepslate_tiles
setblock 495 193 276 minecraft:cobbled_deepslate
setblock 495 193 316 minecraft:cobbled_deepslate
fill 496 193 276 496 196 276 minecraft:deepslate_tiles
fill 496 193 312 510 193 312 minecraft:cobbled_deepslate
fill 496 193 313 497 193 313 minecraft:deepslate_tiles
setblock 496 193 315 minecraft:cobbled_deepslate
fill 496 193 316 496 196 316 minecraft:deepslate_tiles
setblock 497 193 314 minecraft:cobbled_deepslate
fill 497 193 315 497 196 315 minecraft:deepslate_tiles
setblock 498 193 313 minecraft:cobbled_deepslate
fill 498 193 314 498 196 314 minecraft:deepslate_tiles
setblock 499 193 277 minecraft:cobbled_deepslate
fill 499 193 313 499 196 313 minecraft:deepslate_tiles
setblock 500 193 276 minecraft:cobbled_deepslate
fill 500 193 279 511 193 279 minecraft:cobbled_deepslate
fill 500 193 281 500 196 281 minecraft:cobbled_deepslate
setblock 500 193 316 minecraft:cobbled_deepslate
fill 501 193 276 501 195 276 minecraft:deepslate_tiles
fill 501 193 277 511 193 277 minecraft:cobbled_deepslate
fill 501 193 280 511 193 280 minecraft:cobbled_deepslate
setblock 501 193 285 minecraft:light[level=12]
setblock 501 193 292 minecraft:light[level=12]
setblock 501 193 299 minecraft:light[level=12]
setblock 501 193 306 minecraft:light[level=12]
setblock 501 193 314 minecraft:deepslate_tiles
setblock 501 193 315 minecraft:cobbled_deepslate
fill 501 193 316 501 196 316 minecraft:deepslate_tiles
setblock 502 193 314 minecraft:cobbled_deepslate
fill 502 193 315 502 196 315 minecraft:deepslate_tiles
fill 503 193 276 511 193 276 minecraft:cobbled_deepslate
fill 503 193 313 510 193 313 minecraft:cobbled_deepslate
fill 503 193 314 504 193 314 minecraft:deepslate_tiles
fill 505 193 314 510 193 314 minecraft:cobbled_deepslate
setblock 505 193 316 minecraft:cobbled_deepslate
fill 506 193 315 511 193 315 minecraft:cobbled_deepslate
fill 506 193 316 506 195 316 minecraft:deepslate_tiles
fill 507 193 281 508 193 311 minecraft:cobbled_deepslate
fill 507 193 316 511 193 316 minecraft:cobbled_deepslate
fill 509 193 281 509 193 307 minecraft:cobbled_deepslate
fill 509 193 309 509 193 311 minecraft:cobbled_deepslate
fill 510 193 281 510 193 302 minecraft:cobbled_deepslate
setblock 510 193 306 minecraft:cobbled_deepslate
fill 510 193 307 510 196 307 minecraft:deepslate_tiles
setblock 510 193 311 minecraft:cobbled_deepslate
fill 511 193 281 511 193 283 minecraft:cobbled_deepslate
setblock 511 193 284 minecraft:deepslate_tiles
setblock 511 193 285 minecraft:cobbled_deepslate
fill 511 193 286 511 193 289 minecraft:deepslate_tiles
setblock 511 193 290 minecraft:cobbled_deepslate
fill 511 193 291 511 196 291 minecraft:deepslate_tiles
setblock 511 193 295 minecraft:cobbled_deepslate
fill 511 193 296 511 195 297 minecraft:deepslate_tiles
setblock 511 193 300 minecraft:cobbled_deepslate
fill 511 193 301 511 196 301 minecraft:deepslate_tiles
setblock 511 193 305 minecraft:cobbled_deepslate
fill 511 193 306 511 196 306 minecraft:deepslate_tiles
setblock 511 193 310 minecraft:cobbled_deepslate
fill 511 193 311 511 196 311 minecraft:deepslate_tiles
setblock 511 193 314 minecraft:deepslate_tiles
fill 512 193 292 512 201 292 minecraft:black_concrete
setblock 471 194 283 minecraft:deepslate_tiles
setblock 471 194 284 minecraft:cobbled_deepslate
fill 471 194 285 471 197 285 minecraft:deepslate_tiles
setblock 471 194 289 minecraft:cobbled_deepslate
fill 471 194 290 471 197 290 minecraft:deepslate_tiles
setblock 471 194 293 minecraft:deepslate_tiles
setblock 471 194 294 minecraft:cobbled_deepslate
fill 471 194 295 472 196 295 minecraft:deepslate_tiles
setblock 471 194 304 minecraft:cobbled_deepslate
fill 471 194 305 471 195 305 minecraft:deepslate_tiles
fill 471 194 307 471 194 308 minecraft:deepslate_tiles
setblock 471 194 309 minecraft:cobbled_deepslate
fill 471 194 310 471 197 310 minecraft:deepslate_tiles
setblock 472 194 283 minecraft:cobbled_deepslate
fill 472 194 284 472 197 284 minecraft:deepslate_tiles
setblock 472 194 287 minecraft:deepslate_tiles
setblock 472 194 288 minecraft:cobbled_deepslate
fill 472 194 289 472 197 289 minecraft:deepslate_tiles
setblock 472 194 293 minecraft:cobbled_deepslate
fill 472 194 294 472 197 294 minecraft:deepslate_tiles
setblock 473 194 287 minecraft:cobbled_deepslate
fill 473 194 288 473 197 288 minecraft:deepslate_tiles
setblock 473 194 292 minecraft:cobbled_deepslate
fill 473 194 293 473 197 293 minecraft:deepslate_tiles
fill 473 194 295 474 194 297 minecraft:black_concrete
setblock 474 194 276 minecraft:cobbled_deepslate
setblock 474 194 285 minecraft:deepslate_tiles
setblock 474 194 286 minecraft:cobbled_deepslate
fill 474 194 287 474 197 287 minecraft:deepslate_tiles
setblock 474 194 291 minecraft:cobbled_deepslate
setblock 474 194 316 minecraft:cobbled_deepslate
fill 475 194 276 475 197 276 minecraft:deepslate_tiles
fill 475 194 280 475 194 312 minecraft:white_wool
fill 475 194 316 478 194 316 minecraft:deepslate_tiles
fill 476 194 280 507 194 280 minecraft:white_wool
fill 476 194 312 497 194 312 minecraft:white_wool
fill 477 194 315 479 194 315 minecraft:deepslate_tiles
setblock 478 194 277 minecraft:cobbled_deepslate
fill 479 194 275 479 201 275 minecraft:black_concrete
setblock 479 194 276 minecraft:cobbled_deepslate
fill 479 194 277 479 197 277 minecraft:deepslate_tiles
setblock 479 194 316 minecraft:cobbled_deepslate
fill 480 194 276 480 197 276 minecraft:deepslate_tiles
setblock 480 194 315 minecraft:cobbled_deepslate
fill 480 194 316 480 197 316 minecraft:deepslate_tiles
fill 481 194 315 481 197 315 minecraft:deepslate_tiles
setblock 483 194 277 minecraft:cobbled_deepslate
fill 483 194 315 483 195 315 minecraft:deepslate_tiles
setblock 484 194 276 minecraft:cobbled_deepslate
setblock 484 194 316 minecraft:cobbled_deepslate
fill 485 194 276 485 197 276 minecraft:deepslate_tiles
fill 485 194 316 488 194 316 minecraft:deepslate_tiles
setblock 489 194 276 minecraft:cobbled_deepslate
setblock 489 194 316 minecraft:cobbled_deepslate
fill 490 194 276 490 197 276 minecraft:deepslate_tiles
fill 490 194 316 490 197 316 minecraft:deepslate_tiles
fill 491 194 315 494 194 315 minecraft:deepslate_tiles
fill 493 194 314 495 194 314 minecraft:deepslate_tiles
setblock 494 194 276 minecraft:cobbled_deepslate
setblock 494 194 316 minecraft:cobbled_deepslate
fill 495 194 276 495 197 276 minecraft:deepslate_tiles
fill 495 194 313 496 194 313 minecraft:deepslate_tiles
setblock 495 194 315 minecraft:cobbled_deepslate
fill 495 194 316 495 197 316 minecraft:deepslate_tiles
setblock 496 194 314 minecraft:cobbled_deepslate
fill 496 194 315 496 197 315 minecraft:deepslate_tiles
setblock 497 194 313 minecraft:cobbled_deepslate
fill 497 194 314 497 197 314 minecraft:deepslate_tiles
setblock 498 194 277 minecraft:cobbled_deepslate
setblock 498 194 312 minecraft:cobbled_deepslate
fill 498 194 313 498 197 313 minecraft:deepslate_tiles
setblock 499 194 276 minecraft:cobbled_deepslate
fill 499 194 279 501 196 279 minecraft:cobbled_deepslate
fill 499 194 281 499 196 281 minecraft:cobbled_deepslate
fill 499 194 312 500 194 312 minecraft:deepslate_tiles
setblock 499 194 316 minecraft:cobbled_deepslate
fill 500 194 276 500 197 276 minecraft:deepslate_tiles
setblock 500 194 315 minecraft:cobbled_deepslate
fill 500 194 316 500 197 316 minecraft:deepslate_tiles
fill 501 194 281 501 196 281 minecraft:cobbled_deepslate
fill 501 194 312 507 194 312 minecraft:white_wool
setblock 501 194 314 minecraft:cobbled_deepslate
fill 501 194 315 501 197 315 minecraft:deepslate_tiles
setblock 502 194 313 minecraft:cobbled_deepslate
fill 502 194 314 503 195 314 minecraft:deepslate_tiles
setblock 504 194 315 minecraft:deepslate_tiles
setblock 504 194 316 minecraft:cobbled_deepslate
setblock 505 194 315 minecraft:cobbled_deepslate
fill 505 194 316 505 196 316 minecraft:deepslate_tiles
fill 506 194 313 506 196 313 minecraft:white_wool
fill 507 194 281 507 194 311 minecraft:white_wool
fill 510 194 288 510 194 289 minecraft:deepslate_tiles
setblock 510 194 290 minecraft:cobbled_deepslate
fill 510 194 291 510 197 291 minecraft:deepslate_tiles
setblock 510 194 305 minecraft:cobbled_deepslate
fill 510 194 306 510 195 306 minecraft:deepslate_tiles
setblock 510 194 310 minecraft:cobbled_deepslate
fill 510 194 311 510 195 312 minecraft:deepslate_tiles
setblock 511 194 284 minecraft:cobbled_deepslate
fill 511 194 285 511 194 288 minecraft:deepslate_tiles
setblock 511 194 289 minecraft:cobbled_deepslate
fill 511 194 290 511 197 290 minecraft:deepslate_tiles
fill 511 194 292 511 194 293 minecraft:deepslate_tiles
setblock 511 194 294 minecraft:cobbled_deepslate
fill 511 194 295 511 197 295 minecraft:deepslate_tiles
setblock 511 194 299 minecraft:cobbled_deepslate
fill 511 194 300 511 197 300 minecraft:deepslate_tiles
setblock 511 194 304 minecraft:cobbled_deepslate
fill 511 194 305 511 197 305 minecraft:deepslate_tiles
setblock 511 194 309 minecraft:cobbled_deepslate
fill 511 194 310 511 197 310 minecraft:deepslate_tiles
setblock 511 194 314 minecraft:cobbled_deepslate
setblock 470 195 281 minecraft:redstone_block
setblock 471 195 283 minecraft:cobbled_deepslate
fill 471 195 284 471 198 284 minecraft:deepslate_tiles
setblock 471 195 288 minecraft:cobbled_deepslate
fill 471 195 289 471 198 289 minecraft:deepslate_tiles
setblock 471 195 292 minecraft:deepslate_tiles
setblock 471 195 293 minecraft:cobbled_deepslate
fill 471 195 294 471 198 294 minecraft:deepslate_tiles
setblock 471 195 298 minecraft:cobbled_deepslate
setblock 471 195 304 minecraft:deepslate_tiles
setblock 471 195 307 minecraft:deepslate_tiles
setblock 471 195 308 minecraft:cobbled_deepslate
fill 471 195 309 471 197 309 minecraft:deepslate_tiles
setblock 471 195 313 minecraft:cobbled_deepslate
fill 472 195 283 472 196 283 minecraft:deepslate_tiles
setblock 472 195 287 minecraft:cobbled_deepslate
fill 472 195 288 472 198 288 minecraft:deepslate_tiles
setblock 472 195 291 minecraft:deepslate_tiles
setblock 472 195 292 minecraft:cobbled_deepslate
fill 472 195 293 472 198 293 minecraft:deepslate_tiles
setblock 473 195 286 minecraft:cobbled_deepslate
fill 473 195 287 473 198 287 minecraft:deepslate_tiles
setblock 473 195 291 minecraft:cobbled_deepslate
fill 473 195 292 473 198 292 minecraft:deepslate_tiles
fill 474 195 276 474 198 276 minecraft:deepslate_tiles
fill 474 195 286 474 196 286 minecraft:deepslate_tiles
setblock 474 195 290 minecraft:cobbled_deepslate
fill 474 195 291 474 198 291 minecraft:deepslate_tiles
fill 474 195 316 477 195 316 minecraft:deepslate_tiles
fill 475 195 294 475 203 294 minecraft:white_wool
fill 476 195 315 478 195 315 minecraft:deepslate_tiles
setblock 477 195 276 minecraft:deepslate_tiles
setblock 477 195 277 minecraft:cobbled_deepslate
setblock 478 195 276 minecraft:cobbled_deepslate
fill 478 195 277 478 198 277 minecraft:deepslate_tiles
setblock 478 195 316 minecraft:cobbled_deepslate
fill 479 195 276 479 198 276 minecraft:deepslate_tiles
setblock 479 195 315 minecraft:cobbled_deepslate
fill 479 195 316 479 198 316 minecraft:deepslate_tiles
fill 480 195 315 480 198 315 minecraft:deepslate_tiles
setblock 482 195 277 minecraft:cobbled_deepslate
setblock 483 195 276 minecraft:cobbled_deepslate
setblock 483 195 316 minecraft:cobbled_deepslate
fill 484 195 276 484 198 276 minecraft:deepslate_tiles
fill 484 195 316 487 195 316 minecraft:deepslate_tiles
setblock 488 195 316 minecraft:cobbled_deepslate
fill 489 195 316 489 198 316 minecraft:deepslate_tiles
fill 490 195 315 493 195 315 minecraft:deepslate_tiles
fill 492 195 314 494 195 314 minecraft:deepslate_tiles
setblock 493 195 276 minecraft:cobbled_deepslate
setblock 493 195 316 minecraft:cobbled_deepslate
fill 494 195 276 494 198 276 minecraft:deepslate_tiles
fill 494 195 313 495 195 313 minecraft:deepslate_tiles
setblock 494 195 315 minecraft:cobbled_deepslate
fill 494 195 316 494 198 316 minecraft:deepslate_tiles
setblock 495 195 314 minecraft:cobbled_deepslate
fill 495 195 315 495 198 315 minecraft:deepslate_tiles
setblock 496 195 313 minecraft:cobbled_deepslate
fill 496 195 314 496 198 314 minecraft:deepslate_tiles
setblock 497 195 312 minecraft:cobbled_deepslate
fill 497 195 313 497 198 313 minecraft:deepslate_tiles
setblock 498 195 276 minecraft:cobbled_deepslate
fill 498 195 312 499 195 312 minecraft:deepslate_tiles
setblock 498 195 316 minecraft:cobbled_deepslate
fill 499 195 276 499 198 276 minecraft:deepslate_tiles
fill 499 195 280 501 196 280 minecraft:cobbled_deepslate
setblock 499 195 315 minecraft:cobbled_deepslate
fill 499 195 316 499 198 316 minecraft:deepslate_tiles
setblock 500 195 314 minecraft:cobbled_deepslate
fill 500 195 315 500 198 315 minecraft:deepslate_tiles
setblock 501 195 313 minecraft:cobbled_deepslate
fill 501 195 314 501 198 314 minecraft:deepslate_tiles
setblock 503 195 316 minecraft:cobbled_deepslate
setblock 504 195 315 minecraft:cobbled_deepslate
fill 504 195 316 504 198 316 minecraft:deepslate_tiles
fill 507 195 288 507 204 288 minecraft:black_concrete
setblock 510 195 288 minecraft:deepslate_tiles
setblock 510 195 289 minecraft:cobbled_deepslate
fill 510 195 290 510 198 290 minecraft:deepslate_tiles
fill 510 195 292 511 195 292 minecraft:deepslate_tiles
setblock 510 195 309 minecraft:cobbled_deepslate
fill 510 195 310 510 196 310 minecraft:deepslate_tiles
fill 511 195 284 511 195 287 minecraft:deepslate_tiles
setblock 511 195 288 minecraft:cobbled_deepslate
fill 511 195 289 511 198 289 minecraft:deepslate_tiles
setblock 511 195 293 minecraft:cobbled_deepslate
fill 511 195 294 511 198 294 minecraft:deepslate_tiles
setblock 511 195 298 minecraft:cobbled_deepslate
fill 511 195 299 511 198 299 minecraft:deepslate_tiles
setblock 511 195 303 minecraft:cobbled_deepslate
fill 511 195 304 511 197 304 minecraft:deepslate_tiles
setblock 511 195 308 minecraft:cobbled_deepslate
fill 511 195 309 511 198 309 minecraft:deepslate_tiles
setblock 511 195 312 minecraft:deepslate_tiles
setblock 511 195 313 minecraft:cobbled_deepslate
fill 511 195 314 511 198 314 minecraft:deepslate_tiles
fill 470 196 281 470 201 281 minecraft:black_concrete
setblock 471 196 282 minecraft:cobbled_deepslate
fill 471 196 283 471 199 283 minecraft:deepslate_tiles
setblock 471 196 287 minecraft:cobbled_deepslate
fill 471 196 288 471 199 288 minecraft:deepslate_tiles
setblock 471 196 292 minecraft:cobbled_deepslate
fill 471 196 293 471 199 293 minecraft:deepslate_tiles
setblock 471 196 297 minecraft:cobbled_deepslate
fill 471 196 298 471 199 298 minecraft:deepslate_tiles
setblock 471 196 307 minecraft:cobbled_deepslate
fill 471 196 308 471 197 308 minecraft:deepslate_tiles
setblock 471 196 311 minecraft:deepslate_tiles
setblock 471 196 312 minecraft:cobbled_deepslate
fill 471 196 313 471 199 313 minecraft:deepslate_tiles
setblock 472 196 286 minecraft:cobbled_deepslate
fill 472 196 287 472 199 287 minecraft:deepslate_tiles
setblock 472 196 291 minecraft:cobbled_deepslate
fill 472 196 292 472 199 292 minecraft:deepslate_tiles
setblock 472 196 296 minecraft:cobbled_deepslate
fill 473 196 276 473 199 276 minecraft:deepslate_tiles
setblock 473 196 285 minecraft:cobbled_deepslate
fill 473 196 286 473 198 286 minecraft:deepslate_tiles
setblock 473 196 289 minecraft:deepslate_tiles
setblock 473 196 290 minecraft:cobbled_deepslate
fill 473 196 291 473 199 291 minecraft:deepslate_tiles
setblock 473 196 294 minecraft:deepslate_tiles
fill 473 196 316 476 196 316 minecraft:deepslate_tiles
setblock 474 196 289 minecraft:cobbled_deepslate
fill 474 196 290 474 199 290 minecraft:deepslate_tiles
fill 474 196 292 474 197 292 minecraft:deepslate_tiles
setblock 475 196 277 minecraft:deepslate_tiles
fill 475 196 315 477 196 315 minecraft:deepslate_tiles
setblock 476 196 276 minecraft:deepslate_tiles
setblock 476 196 277 minecraft:cobbled_deepslate
setblock 477 196 276 minecraft:cobbled_deepslate
fill 477 196 277 477 199 277 minecraft:deepslate_tiles
setblock 477 196 316 minecraft:cobbled_deepslate
fill 478 196 276 478 199 276 minecraft:deepslate_tiles
setblock 478 196 315 minecraft:cobbled_deepslate
fill 478 196 316 478 199 316 minecraft:deepslate_tiles
fill 479 196 315 479 199 315 minecraft:deepslate_tiles
setblock 481 196 277 minecraft:cobbled_deepslate
setblock 482 196 276 minecraft:cobbled_deepslate
setblock 482 196 316 minecraft:cobbled_deepslate
fill 483 196 276 483 199 276 minecraft:deepslate_tiles
fill 483 196 316 486 196 316 minecraft:deepslate_tiles
setblock 487 196 316 minecraft:cobbled_deepslate
fill 488 196 316 488 199 316 minecraft:deepslate_tiles
fill 489 196 315 492 196 315 minecraft:deepslate_tiles
setblock 492 196 276 minecraft:cobbled_deepslate
fill 492 196 314 493 196 314 minecraft:deepslate_tiles
setblock 492 196 316 minecraft:cobbled_deepslate
fill 493 196 276 493 199 276 minecraft:deepslate_tiles
setblock 493 196 315 minecraft:cobbled_deepslate
fill 493 196 316 493 199 316 minecraft:deepslate_tiles
setblock 494 196 313 minecraft:deepslate_tiles
setblock 494 196 314 minecraft:cobbled_deepslate
fill 494 196 315 494 199 315 minecraft:deepslate_tiles
setblock 495 196 313 minecraft:cobbled_deepslate
fill 495 196 314 495 199 314 minecraft:deepslate_tiles
fill 496 196 313 496 199 313 minecraft:deepslate_tiles
setblock 497 196 276 minecraft:cobbled_deepslate
setblock 497 196 316 minecraft:cobbled_deepslate
fill 498 196 276 498 199 276 minecraft:deepslate_tiles
setblock 498 196 280 minecraft:cobbled_deepslate
setblock 498 196 315 minecraft:cobbled_deepslate
fill 498 196 316 498 199 316 minecraft:deepslate_tiles
setblock 499 196 314 minecraft:cobbled_deepslate
fill 499 196 315 499 199 315 minecraft:deepslate_tiles
setblock 500 196 278 minecraft:cobbled_deepslate
setblock 500 196 282 minecraft:cobbled_deepslate
setblock 500 196 313 minecraft:cobbled_deepslate
fill 500 196 314 500 199 314 minecraft:deepslate_tiles
setblock 501 196 313 minecraft:deepslate_tiles
setblock 502 196 280 minecraft:cobbled_deepslate
fill 502 196 314 502 197 314 minecraft:deepslate_tiles
setblock 502 196 316 minecraft:cobbled_deepslate
setblock 503 196 315 minecraft:cobbled_deepslate
fill 503 196 316 503 199 316 minecraft:deepslate_tiles
setblock 504 196 315 minecraft:deepslate_tiles
setblock 505 196 317 minecraft:white_wool
setblock 510 196 288 minecraft:cobbled_deepslate
fill 510 196 289 510 199 289 minecraft:deepslate_tiles
setblock 510 196 292 minecraft:deepslate_tiles
setblock 510 196 293 minecraft:cobbled_deepslate
setblock 510 196 308 minecraft:cobbled_deepslate
setblock 510 196 309 minecraft:deepslate_tiles
setblock 510 196 311 minecraft:deepslate_tiles
fill 511 196 285 511 196 286 minecraft:deepslate_tiles
setblock 511 196 287 minecraft:cobbled_deepslate
fill 511 196 288 511 199 288 minecraft:deepslate_tiles
setblock 511 196 292 minecraft:cobbled_deepslate
fill 511 196 293 511 199 293 minecraft:deepslate_tiles
setblock 511 196 296 minecraft:deepslate_tiles
setblock 511 196 297 minecraft:cobbled_deepslate
fill 511 196 298 511 199 298 minecraft:deepslate_tiles
setblock 511 196 302 minecraft:cobbled_deepslate
fill 511 196 303 511 197 303 minecraft:deepslate_tiles
setblock 511 196 307 minecraft:cobbled_deepslate
fill 511 196 308 511 199 308 minecraft:deepslate_tiles
setblock 511 196 312 minecraft:cobbled_deepslate
fill 511 196 313 511 199 313 minecraft:deepslate_tiles
fill 511 196 315 511 197 315 minecraft:deepslate_tiles
fill 471 197 282 471 200 282 minecraft:deepslate_tiles
setblock 471 197 286 minecraft:cobbled_deepslate
fill 471 197 287 471 200 287 minecraft:deepslate_tiles
setblock 471 197 291 minecraft:cobbled_deepslate
fill 471 197 292 471 200 292 minecraft:deepslate_tiles
setblock 471 197 295 minecraft:deepslate_tiles
setblock 471 197 296 minecraft:cobbled_deepslate
fill 471 197 297 471 200 297 minecraft:deepslate_tiles
setblock 471 197 311 minecraft:cobbled_deepslate
fill 471 197 312 471 200 312 minecraft:deepslate_tiles
fill 471 197 314 471 198 314 minecraft:deepslate_tiles
setblock 472 197 285 minecraft:cobbled_deepslate
fill 472 197 286 472 200 286 minecraft:deepslate_tiles
setblock 472 197 290 minecraft:cobbled_deepslate
fill 472 197 291 472 200 291 minecraft:deepslate_tiles
setblock 472 197 295 minecraft:cobbled_deepslate
fill 472 197 296 472 200 296 minecraft:deepslate_tiles
fill 472 197 316 475 197 316 minecraft:deepslate_tiles
setblock 473 197 278 minecraft:light[level=13]
setblock 473 197 285 minecraft:deepslate_tiles
setblock 473 197 289 minecraft:cobbled_deepslate
fill 473 197 290 473 200 290 minecraft:deepslate_tiles
setblock 473 197 294 minecraft:cobbled_deepslate
setblock 473 197 302 minecraft:light[level=13]
setblock 473 197 310 minecraft:light[level=13]
setblock 474 197 288 minecraft:cobbled_deepslate
fill 474 197 289 474 198 289 minecraft:deepslate_tiles
setblock 475 197 277 minecraft:cobbled_deepslate
fill 475 197 315 476 197 315 minecraft:deepslate_tiles
setblock 476 197 276 minecraft:cobbled_deepslate
fill 476 197 277 476 200 277 minecraft:deepslate_tiles
setblock 476 197 316 minecraft:cobbled_deepslate
fill 477 197 276 477 200 276 minecraft:deepslate_tiles
setblock 477 197 315 minecraft:cobbled_deepslate
fill 477 197 316 477 200 316 minecraft:deepslate_tiles
fill 478 197 315 478 200 315 minecraft:deepslate_tiles
setblock 480 197 277 minecraft:cobbled_deepslate
setblock 481 197 276 minecraft:cobbled_deepslate
setblock 481 197 278 minecraft:light[level=13]
setblock 481 197 286 minecraft:light[level=13]
setblock 481 197 294 minecraft:light[level=13]
setblock 481 197 302 minecraft:light[level=13]
setblock 481 197 310 minecraft:light[level=13]
setblock 481 197 316 minecraft:cobbled_deepslate
fill 482 197 276 482 200 276 minecraft:deepslate_tiles
setblock 482 197 315 minecraft:cobbled_deepslate
fill 482 197 316 485 197 316 minecraft:deepslate_tiles
setblock 486 197 316 minecraft:cobbled_deepslate
fill 487 197 316 487 200 316 minecraft:deepslate_tiles
setblock 489 197 278 minecraft:light[level=13]
setblock 489 197 286 minecraft:light[level=13]
setblock 489 197 294 minecraft:light[level=13]
setblock 489 197 302 minecraft:light[level=13]
setblock 489 197 310 minecraft:light[level=13]
fill 489 197 315 491 197 315 minecraft:deepslate_tiles
setblock 491 197 276 minecraft:cobbled_deepslate
fill 491 197 314 492 197 314 minecraft:deepslate_tiles
setblock 491 197 316 minecraft:cobbled_deepslate
fill 492 197 276 492 200 276 minecraft:deepslate_tiles
setblock 492 197 315 minecraft:cobbled_deepslate
fill 492 197 316 492 200 316 minecraft:deepslate_tiles
setblock 493 197 314 minecraft:cobbled_deepslate
fill 493 197 315 493 200 315 minecraft:deepslate_tiles
setblock 494 197 313 minecraft:cobbled_deepslate
fill 494 197 314 494 200 314 minecraft:deepslate_tiles
fill 495 197 313 495 200 313 minecraft:deepslate_tiles
setblock 496 197 276 minecraft:cobbled_deepslate
setblock 496 197 316 minecraft:cobbled_deepslate
fill 497 197 276 497 200 276 minecraft:deepslate_tiles
setblock 497 197 278 minecraft:light[level=13]
setblock 497 197 286 minecraft:light[level=13]
setblock 497 197 294 minecraft:light[level=13]
setblock 497 197 302 minecraft:light[level=13]
setblock 497 197 310 minecraft:light[level=13]
setblock 497 197 315 minecraft:cobbled_deepslate
fill 497 197 316 497 200 316 minecraft:deepslate_tiles
setblock 498 197 314 minecraft:cobbled_deepslate
fill 498 197 315 498 200 315 minecraft:deepslate_tiles
setblock 499 197 313 minecraft:cobbled_deepslate
fill 499 197 314 499 200 314 minecraft:deepslate_tiles
setblock 500 197 313 minecraft:deepslate_tiles
setblock 501 197 316 minecraft:cobbled_deepslate
setblock 502 197 315 minecraft:cobbled_deepslate
fill 502 197 316 502 200 316 minecraft:deepslate_tiles
setblock 503 197 315 minecraft:deepslate_tiles
setblock 505 197 278 minecraft:light[level=13]
setblock 505 197 286 minecraft:light[level=13]
setblock 505 197 294 minecraft:light[level=13]
setblock 505 197 302 minecraft:light[level=13]
setblock 505 197 310 minecraft:light[level=13]
setblock 505 197 317 minecraft:black_concrete
setblock 510 197 292 minecraft:cobbled_deepslate
fill 510 197 293 510 199 294 minecraft:deepslate_tiles
setblock 511 197 285 minecraft:deepslate_tiles
setblock 511 197 286 minecraft:cobbled_deepslate
fill 511 197 287 511 200 287 minecraft:deepslate_tiles
setblock 511 197 291 minecraft:cobbled_deepslate
fill 511 197 292 511 200 292 minecraft:deepslate_tiles
setblock 511 197 296 minecraft:cobbled_deepslate
fill 511 197 297 511 200 297 minecraft:deepslate_tiles
setblock 511 197 301 minecraft:cobbled_deepslate
setblock 511 197 302 minecraft:deepslate_tiles
setblock 511 197 306 minecraft:cobbled_deepslate
fill 511 197 307 511 199 307 minecraft:deepslate_tiles
setblock 511 197 311 minecraft:cobbled_deepslate
fill 511 197 312 511 200 312 minecraft:deepslate_tiles
fill 470 198 284 470 198 285 minecraft:deepslate_tiles
setblock 470 198 306 minecraft:deepslate_tiles
fill 471 198 275 471 201 275 minecraft:black_concrete
setblock 471 198 285 minecraft:cobbled_deepslate
fill 471 198 286 471 201 286 minecraft:deepslate_tiles
setblock 471 198 290 minecraft:cobbled_deepslate
fill 471 198 291 471 201 291 minecraft:deepslate_tiles
setblock 471 198 295 minecraft:cobbled_deepslate
fill 471 198 296 471 201 296 minecraft:deepslate_tiles
setblock 471 198 310 minecraft:cobbled_deepslate
fill 471 198 311 471 201 311 minecraft:deepslate_tiles
setblock 471 198 315 minecraft:cobbled_deepslate
fill 472 198 275 472 200 276 minecraft:deepslate_tiles
setblock 472 198 284 minecraft:cobbled_deepslate
fill 472 198 285 472 201 285 minecraft:deepslate_tiles
setblock 472 198 289 minecraft:cobbled_deepslate
fill 472 198 290 472 201 290 minecraft:deepslate_tiles
setblock 472 198 294 minecraft:cobbled_deepslate
fill 472 198 295 472 201 295 minecraft:deepslate_tiles
fill 472 198 316 474 198 316 minecraft:deepslate_tiles
setblock 473 198 288 minecraft:cobbled_deepslate
fill 473 198 289 473 201 289 minecraft:deepslate_tiles
setblock 473 198 293 minecraft:cobbled_deepslate
fill 473 198 294 473 201 294 minecraft:deepslate_tiles
fill 474 198 315 475 198 315 minecraft:deepslate_tiles
fill 475 198 275 475 201 275 minecraft:black_concrete
setblock 475 198 276 minecraft:cobbled_deepslate
fill 475 198 277 475 201 277 minecraft:deepslate_tiles
setblock 475 198 316 minecraft:cobbled_deepslate
fill 476 198 275 476 198 276 minecraft:deepslate_tiles
setblock 476 198 315 minecraft:cobbled_deepslate
fill 476 198 316 476 201 316 minecraft:deepslate_tiles
fill 477 198 275 478 199 275 minecraft:black_concrete
fill 477 198 315 477 201 315 minecraft:deepslate_tiles
setblock 479 198 277 minecraft:cobbled_deepslate
setblock 479 198 317 minecraft:deepslate_tiles
setblock 480 198 276 minecraft:cobbled_deepslate
setblock 480 198 316 minecraft:cobbled_deepslate
fill 481 198 276 481 201 276 minecraft:deepslate_tiles
setblock 481 198 315 minecraft:cobbled_deepslate
fill 481 198 316 484 198 316 minecraft:deepslate_tiles
setblock 483 198 275 minecraft:deepslate_tiles
setblock 485 198 316 minecraft:cobbled_deepslate
fill 486 198 316 486 201 316 minecraft:deepslate_tiles
fill 488 198 315 490 198 315 minecraft:deepslate_tiles
setblock 490 198 276 minecraft:cobbled_deepslate
setblock 490 198 316 minecraft:cobbled_deepslate
fill 491 198 276 491 201 276 minecraft:deepslate_tiles
setblock 491 198 314 minecraft:deepslate_tiles
setblock 491 198 315 minecraft:cobbled_deepslate
fill 491 198 316 491 198 317 minecraft:deepslate_tiles
setblock 492 198 314 minecraft:cobbled_deepslate
fill 492 198 315 492 201 315 minecraft:deepslate_tiles
fill 493 198 314 493 201 314 minecraft:deepslate_tiles
setblock 493 198 317 minecraft:deepslate_tiles
fill 494 198 313 494 201 313 minecraft:deepslate_tiles
setblock 495 198 276 minecraft:cobbled_deepslate
setblock 495 198 316 minecraft:cobbled_deepslate
fill 496 198 276 496 201 276 minecraft:deepslate_tiles
setblock 496 198 315 minecraft:cobbled_deepslate
fill 496 198 316 496 201 316 minecraft:deepslate_tiles
setblock 497 198 314 minecraft:cobbled_deepslate
fill 497 198 315 497 201 315 minecraft:deepslate_tiles
setblock 498 198 313 minecraft:cobbled_deepslate
fill 498 198 314 498 201 314 minecraft:deepslate_tiles
setblock 499 198 313 minecraft:deepslate_tiles
setblock 499 198 317 minecraft:deepslate_tiles
setblock 500 198 316 minecraft:cobbled_deepslate
setblock 501 198 315 minecraft:cobbled_deepslate
fill 501 198 316 501 201 316 minecraft:deepslate_tiles
fill 502 198 315 502 199 315 minecraft:deepslate_tiles
fill 504 198 281 508 199 285 minecraft:black_concrete
setblock 505 198 317 minecraft:deepslate_tiles
setblock 507 198 275 minecraft:deepslate_tiles
fill 508 198 275 508 201 275 minecraft:black_concrete
fill 509 198 283 510 198 283 minecraft:black_concrete
setblock 510 198 291 minecraft:cobbled_deepslate
fill 510 198 292 510 201 292 minecraft:deepslate_tiles
setblock 510 198 295 minecraft:deepslate_tiles
fill 511 198 286 511 201 286 minecraft:deepslate_tiles
setblock 511 198 290 minecraft:cobbled_deepslate
fill 511 198 291 511 201 291 minecraft:deepslate_tiles
setblock 511 198 295 minecraft:cobbled_deepslate
fill 511 198 296 512 198 296 minecraft:deepslate_tiles
setblock 511 198 300 minecraft:cobbled_deepslate
setblock 511 198 305 minecraft:cobbled_deepslate
setblock 511 198 306 minecraft:deepslate_tiles
setblock 511 198 310 minecraft:cobbled_deepslate
fill 511 198 311 511 201 311 minecraft:deepslate_tiles
setblock 511 198 315 minecraft:cobbled_deepslate
setblock 512 198 275 minecraft:deepslate_tiles
fill 512 198 277 512 199 277 minecraft:deepslate_tiles
fill 512 198 297 512 198 298 minecraft:deepslate_tiles
setblock 512 198 301 minecraft:deepslate_tiles
fill 470 199 282 470 200 282 minecraft:deepslate_tiles
fill 470 199 284 470 201 284 minecraft:black_concrete
fill 470 199 285 471 199 285 minecraft:deepslate_tiles
fill 470 199 294 470 201 295 minecraft:black_concrete
setblock 470 199 296 minecraft:deepslate_tiles
fill 470 199 297 470 201 297 minecraft:black_concrete
setblock 470 199 303 minecraft:deepslate_tiles
fill 470 199 304 470 201 304 minecraft:black_concrete
fill 470 199 306 470 201 306 minecraft:black_concrete
fill 471 199 276 471 201 276 minecraft:deepslate_tiles
setblock 471 199 284 minecraft:cobbled_deepslate
setblock 471 199 289 minecraft:cobbled_deepslate
fill 471 199 290 471 202 290 minecraft:deepslate_tiles
setblock 471 199 294 minecraft:cobbled_deepslate
fill 471 199 295 471 202 295 minecraft:deepslate_tiles
setblock 471 199 314 minecraft:cobbled_deepslate
fill 471 199 315 471 201 316 minecraft:deepslate_tiles
setblock 472 199 284 minecraft:deepslate_tiles
setblock 472 199 288 minecraft:cobbled_deepslate
fill 472 199 289 472 202 289 minecraft:deepslate_tiles
setblock 472 199 293 minecraft:cobbled_deepslate
fill 472 199 294 472 202 294 minecraft:deepslate_tiles
fill 472 199 316 473 199 316 minecraft:deepslate_tiles
setblock 473 199 278 minecraft:light[level=12]
setblock 473 199 285 minecraft:light[level=12]
setblock 473 199 287 minecraft:cobbled_deepslate
fill 473 199 288 473 202 288 minecraft:deepslate_tiles
setblock 473 199 292 minecraft:cobbled_deepslate
fill 473 199 293 473 202 293 minecraft:deepslate_tiles
setblock 473 199 299 minecraft:light[level=12]
setblock 473 199 306 minecraft:light[level=12]
setblock 473 199 313 minecraft:light[level=12]
setblock 474 199 276 minecraft:cobbled_deepslate
fill 474 199 277 474 202 277 minecraft:deepslate_tiles
setblock 474 199 315 minecraft:deepslate_tiles
setblock 474 199 316 minecraft:cobbled_deepslate
fill 475 199 276 476 201 276 minecraft:deepslate_tiles
setblock 475 199 315 minecraft:cobbled_deepslate
fill 475 199 316 475 202 316 minecraft:deepslate_tiles
fill 476 199 275 476 201 275 minecraft:black_concrete
fill 476 199 315 476 202 315 minecraft:deepslate_tiles
setblock 478 199 277 minecraft:cobbled_deepslate
setblock 479 199 276 minecraft:cobbled_deepslate
fill 479 199 277 479 202 277 minecraft:deepslate_tiles
setblock 479 199 316 minecraft:cobbled_deepslate
fill 479 199 317 479 201 317 minecraft:black_concrete
fill 480 199 276 480 202 276 minecraft:deepslate_tiles
setblock 480 199 278 minecraft:light[level=12]
setblock 480 199 285 minecraft:light[level=12]
setblock 480 199 292 minecraft:light[level=12]
setblock 480 199 299 minecraft:light[level=12]
setblock 480 199 306 minecraft:light[level=12]
setblock 480 199 313 minecraft:light[level=12]
setblock 480 199 315 minecraft:cobbled_deepslate
fill 480 199 316 483 199 316 minecraft:deepslate_tiles
setblock 481 199 315 minecraft:deepslate_tiles
setblock 482 199 275 minecraft:deepslate_tiles
fill 483 199 275 483 201 275 minecraft:black_concrete
setblock 484 199 276 minecraft:cobbled_deepslate
setblock 484 199 316 minecraft:cobbled_deepslate
fill 485 199 316 485 202 316 minecraft:deepslate_tiles
fill 486 199 275 487 201 275 minecraft:black_concrete
setblock 487 199 278 minecraft:light[level=12]
setblock 487 199 285 minecraft:light[level=12]
setblock 487 199 292 minecraft:light[level=12]
setblock 487 199 299 minecraft:light[level=12]
setblock 487 199 306 minecraft:light[level=12]
setblock 487 199 313 minecraft:light[level=12]
fill 488 199 275 489 199 275 minecraft:deepslate_tiles
fill 488 199 315 489 199 315 minecraft:deepslate_tiles
setblock 489 199 276 minecraft:cobbled_deepslate
setblock 489 199 316 minecraft:cobbled_deepslate
fill 490 199 276 490 202 276 minecraft:deepslate_tiles
setblock 490 199 315 minecraft:cobbled_deepslate
fill 490 199 316 490 199 317 minecraft:deepslate_tiles
setblock 491 199 314 minecraft:cobbled_deepslate
fill 491 199 315 491 201 316 minecraft:deepslate_tiles
fill 491 199 317 491 201 317 minecraft:black_concrete
fill 492 199 314 492 202 314 minecraft:deepslate_tiles
fill 493 199 313 493 202 313 minecraft:deepslate_tiles
fill 493 199 317 493 201 317 minecraft:black_concrete
setblock 494 199 276 minecraft:cobbled_deepslate
setblock 494 199 278 minecraft:light[level=12]
setblock 494 199 285 minecraft:light[level=12]
setblock 494 199 292 minecraft:light[level=12]
setblock 494 199 299 minecraft:light[level=12]
setblock 494 199 306 minecraft:light[level=12]
setblock 494 199 316 minecraft:cobbled_deepslate
fill 495 199 276 495 202 276 minecraft:deepslate_tiles
setblock 495 199 315 minecraft:cobbled_deepslate
fill 495 199 316 495 202 316 minecraft:deepslate_tiles
setblock 496 199 314 minecraft:cobbled_deepslate
fill 496 199 315 496 202 315 minecraft:deepslate_tiles
setblock 497 199 313 minecraft:cobbled_deepslate
fill 497 199 314 497 202 314 minecraft:deepslate_tiles
setblock 498 199 275 minecraft:deepslate_tiles
setblock 498 199 313 minecraft:deepslate_tiles
fill 499 199 275 500 199 275 minecraft:black_concrete
setblock 499 199 316 minecraft:cobbled_deepslate
fill 499 199 317 499 201 317 minecraft:black_concrete
setblock 500 199 315 minecraft:cobbled_deepslate
fill 500 199 316 500 199 317 minecraft:deepslate_tiles
setblock 501 199 278 minecraft:light[level=12]
setblock 501 199 285 minecraft:light[level=12]
setblock 501 199 292 minecraft:light[level=12]
setblock 501 199 299 minecraft:light[level=12]
setblock 501 199 306 minecraft:light[level=12]
setblock 501 199 313 minecraft:light[level=12]
fill 501 199 315 501 201 315 minecraft:deepslate_tiles
fill 505 199 317 505 201 317 minecraft:black_concrete
fill 507 199 275 507 201 275 minecraft:black_concrete
setblock 508 199 278 minecraft:light[level=12]
setblock 508 199 292 minecraft:light[level=12]
setblock 508 199 299 minecraft:light[level=12]
setblock 508 199 306 minecraft:light[level=12]
setblock 508 199 313 minecraft:light[level=12]
setblock 510 199 290 minecraft:cobbled_deepslate
fill 510 199 291 510 202 291 minecraft:deepslate_tiles
setblock 510 199 295 minecraft:cobbled_deepslate
fill 510 199 296 511 201 296 minecraft:deepslate_tiles
setblock 511 199 289 minecraft:cobbled_deepslate
fill 511 199 290 511 202 290 minecraft:deepslate_tiles
setblock 511 199 294 minecraft:cobbled_deepslate
fill 511 199 295 511 202 295 minecraft:deepslate_tiles
setblock 511 199 299 minecraft:cobbled_deepslate
fill 511 199 300 511 201 301 minecraft:deepslate_tiles
setblock 511 199 309 minecraft:cobbled_deepslate
fill 511 199 310 512 199 310 minecraft:deepslate_tiles
setblock 511 199 314 minecraft:cobbled_deepslate
fill 511 199 315 511 202 315 minecraft:deepslate_tiles
fill 512 199 275 512 201 275 minecraft:black_concrete
setblock 512 199 289 minecraft:deepslate_tiles
fill 512 199 296 512 199 298 minecraft:black_concrete
setblock 512 199 300 minecraft:redstone_block
fill 512 199 301 512 201 301 minecraft:black_concrete
setblock 512 199 312 minecraft:deepslate_tiles
fill 512 199 314 512 199 316 minecraft:black_concrete
fill 512 199 317 512 200 317 minecraft:deepslate_tiles
fill 470 200 279 471 200 279 minecraft:deepslate_tiles
fill 470 200 285 470 201 285 minecraft:black_concrete
fill 470 200 286 470 200 287 minecraft:deepslate_tiles
fill 470 200 288 470 201 289 minecraft:black_concrete
fill 470 200 296 470 201 296 minecraft:black_concrete
setblock 470 200 302 minecraft:deepslate_tiles
fill 470 200 303 470 201 303 minecraft:black_concrete
setblock 470 200 315 minecraft:deepslate_tiles
setblock 471 200 277 minecraft:deepslate_tiles
setblock 471 200 278 minecraft:cobbled_deepslate
fill 471 200 280 471 201 281 minecraft:deepslate_tiles
setblock 471 200 283 minecraft:cobbled_deepslate
fill 471 200 284 471 202 285 minecraft:deepslate_tiles
setblock 471 200 288 minecraft:cobbled_deepslate
fill 471 200 289 471 203 289 minecraft:deepslate_tiles
setblock 471 200 293 minecraft:cobbled_deepslate
fill 471 200 294 471 203 294 minecraft:deepslate_tiles
setblock 471 200 298 minecraft:cobbled_deepslate
fill 471 200 299 471 203 299 minecraft:deepslate_tiles
setblock 471 200 313 minecraft:cobbled_deepslate
fill 471 200 314 471 203 314 minecraft:deepslate_tiles
setblock 472 200 287 minecraft:cobbled_deepslate
fill 472 200 288 472 203 288 minecraft:deepslate_tiles
setblock 472 200 292 minecraft:cobbled_deepslate
fill 472 200 293 472 203 293 minecraft:deepslate_tiles
setblock 472 200 297 minecraft:cobbled_deepslate
setblock 472 200 316 minecraft:deepslate_tiles
setblock 473 200 275 minecraft:deepslate_tiles
setblock 473 200 276 minecraft:cobbled_deepslate
fill 473 200 277 473 203 277 minecraft:deepslate_tiles
setblock 473 200 287 minecraft:deepslate_tiles
setblock 473 200 291 minecraft:cobbled_deepslate
fill 473 200 292 473 203 292 minecraft:deepslate_tiles
setblock 473 200 295 minecraft:deepslate_tiles
setblock 473 200 315 minecraft:deepslate_tiles
setblock 473 200 316 minecraft:cobbled_deepslate
fill 474 200 276 474 203 276 minecraft:deepslate_tiles
setblock 474 200 315 minecraft:cobbled_deepslate
fill 474 200 316 474 203 316 minecraft:deepslate_tiles
fill 475 200 315 475 203 315 minecraft:deepslate_tiles
setblock 477 200 275 minecraft:deepslate_tiles
setblock 477 200 277 minecraft:cobbled_deepslate
setblock 477 200 317 minecraft:deepslate_tiles
fill 478 200 275 478 201 275 minecraft:black_concrete
setblock 478 200 276 minecraft:cobbled_deepslate
fill 478 200 277 478 203 277 minecraft:deepslate_tiles
setblock 478 200 316 minecraft:cobbled_deepslate
fill 479 200 276 479 203 276 minecraft:deepslate_tiles
setblock 479 200 315 minecraft:cobbled_deepslate
fill 479 200 316 482 200 316 minecraft:deepslate_tiles
fill 480 200 315 480 203 315 minecraft:deepslate_tiles
fill 482 200 275 482 201 275 minecraft:black_concrete
setblock 483 200 276 minecraft:cobbled_deepslate
setblock 483 200 316 minecraft:cobbled_deepslate
fill 484 200 276 484 203 276 minecraft:deepslate_tiles
fill 484 200 316 484 203 316 minecraft:deepslate_tiles
setblock 487 200 276 minecraft:deepslate_tiles
fill 487 200 315 488 200 315 minecraft:deepslate_tiles
fill 488 200 275 489 201 275 minecraft:black_concrete
setblock 488 200 276 minecraft:cobbled_deepslate
setblock 488 200 316 minecraft:cobbled_deepslate
fill 489 200 276 489 203 276 minecraft:deepslate_tiles
setblock 489 200 315 minecraft:cobbled_deepslate
fill 489 200 316 490 202 316 minecraft:deepslate_tiles
setblock 490 200 314 minecraft:cobbled_deepslate
fill 490 200 315 490 203 315 minecraft:deepslate_tiles
fill 490 200 317 490 201 317 minecraft:black_concrete
fill 491 200 314 491 203 314 minecraft:deepslate_tiles
setblock 493 200 276 minecraft:cobbled_deepslate
setblock 493 200 316 minecraft:cobbled_deepslate
fill 494 200 276 494 203 276 minecraft:deepslate_tiles
setblock 494 200 315 minecraft:cobbled_deepslate
fill 494 200 316 494 203 316 minecraft:deepslate_tiles
setblock 495 200 314 minecraft:cobbled_deepslate
fill 495 200 315 495 203 315 minecraft:deepslate_tiles
setblock 496 200 313 minecraft:cobbled_deepslate
fill 496 200 314 496 203 314 minecraft:deepslate_tiles
setblock 497 200 313 minecraft:deepslate_tiles
fill 498 200 275 498 201 275 minecraft:black_concrete
setblock 498 200 276 minecraft:cobbled_deepslate
setblock 498 200 316 minecraft:cobbled_deepslate
setblock 499 200 275 minecraft:deepslate_tiles
setblock 499 200 315 minecraft:cobbled_deepslate
fill 499 200 316 500 202 316 minecraft:deepslate_tiles
fill 500 200 275 500 201 275 minecraft:black_concrete
fill 500 200 315 500 203 315 minecraft:deepslate_tiles
fill 500 200 317 500 201 317 minecraft:black_concrete
setblock 501 200 275 minecraft:deepslate_tiles
setblock 503 200 316 minecraft:cobbled_deepslate
fill 506 200 283 506 205 283 minecraft:bone_block
setblock 506 200 317 minecraft:deepslate_tiles
setblock 510 200 289 minecraft:cobbled_deepslate
fill 510 200 290 510 203 290 minecraft:deepslate_tiles
setblock 510 200 293 minecraft:deepslate_tiles
setblock 510 200 294 minecraft:cobbled_deepslate
fill 510 200 295 510 203 295 minecraft:deepslate_tiles
fill 510 200 297 510 201 297 minecraft:deepslate_tiles
setblock 511 200 288 minecraft:cobbled_deepslate
fill 511 200 289 511 203 289 minecraft:deepslate_tiles
setblock 511 200 293 minecraft:cobbled_deepslate
fill 511 200 294 511 203 294 minecraft:deepslate_tiles
setblock 511 200 298 minecraft:cobbled_deepslate
fill 511 200 299 511 203 299 minecraft:deepslate_tiles
setblock 511 200 308 minecraft:cobbled_deepslate
fill 511 200 309 511 202 310 minecraft:deepslate_tiles
setblock 511 200 313 minecraft:cobbled_deepslate
fill 511 200 314 512 200 314 minecraft:deepslate_tiles
fill 511 200 316 511 201 316 minecraft:deepslate_tiles
fill 512 200 277 512 201 277 minecraft:black_concrete
setblock 512 200 280 minecraft:deepslate_tiles
setblock 512 200 288 minecraft:white_wool
fill 512 200 289 512 201 289 minecraft:black_concrete
fill 512 200 296 512 201 296 minecraft:black_concrete
setblock 512 200 297 minecraft:deepslate_tiles
fill 512 200 298 512 201 298 minecraft:black_concrete
fill 512 200 300 512 201 300 minecraft:black_concrete
setblock 512 200 302 minecraft:deepslate_tiles
setblock 512 200 309 minecraft:deepslate_tiles
fill 512 200 310 512 201 310 minecraft:black_concrete
setblock 512 200 311 minecraft:deepslate_tiles
fill 512 200 312 512 202 312 minecraft:black_concrete
fill 512 200 315 512 201 316 minecraft:black_concrete
setblock 470 201 279 minecraft:black_concrete
setblock 470 201 282 minecraft:black_concrete
fill 470 201 286 470 201 287 minecraft:black_concrete
setblock 470 201 302 minecraft:black_concrete
setblock 470 201 315 minecraft:black_concrete
setblock 471 201 277 minecraft:cobbled_deepslate
fill 471 201 278 471 203 279 minecraft:deepslate_tiles
setblock 471 201 282 minecraft:cobbled_deepslate
fill 471 201 283 471 204 283 minecraft:deepslate_tiles
setblock 471 201 287 minecraft:cobbled_deepslate
fill 471 201 288 471 204 288 minecraft:deepslate_tiles
setblock 471 201 292 minecraft:cobbled_deepslate
fill 471 201 293 471 204 293 minecraft:deepslate_tiles
setblock 471 201 297 minecraft:cobbled_deepslate
fill 471 201 298 471 204 298 minecraft:deepslate_tiles
setblock 471 201 312 minecraft:cobbled_deepslate
fill 471 201 313 471 204 313 minecraft:deepslate_tiles
fill 472 201 275 473 201 275 minecraft:black_concrete
setblock 472 201 276 minecraft:cobbled_deepslate
fill 472 201 277 472 203 278 minecraft:deepslate_tiles
fill 472 201 284 472 202 284 minecraft:deepslate_tiles
setblock 472 201 286 minecraft:cobbled_deepslate
fill 472 201 287 472 204 287 minecraft:deepslate_tiles
setblock 472 201 291 minecraft:cobbled_deepslate
fill 472 201 292 472 204 292 minecraft:deepslate_tiles
setblock 472 201 296 minecraft:cobbled_deepslate
fill 472 201 297 472 204 297 minecraft:deepslate_tiles
fill 472 201 314 472 201 315 minecraft:deepslate_tiles
setblock 472 201 316 minecraft:cobbled_deepslate
fill 473 201 276 473 204 276 minecraft:deepslate_tiles
setblock 473 201 290 minecraft:cobbled_deepslate
fill 473 201 291 473 204 291 minecraft:deepslate_tiles
setblock 473 201 295 minecraft:cobbled_deepslate
setblock 473 201 315 minecraft:cobbled_deepslate
fill 473 201 316 473 204 316 minecraft:deepslate_tiles
fill 474 201 315 474 204 315 minecraft:deepslate_tiles
setblock 476 201 277 minecraft:cobbled_deepslate
setblock 477 201 275 minecraft:black_concrete
setblock 477 201 276 minecraft:cobbled_deepslate
fill 477 201 277 477 204 277 minecraft:deepslate_tiles
setblock 477 201 316 minecraft:cobbled_deepslate
setblock 477 201 317 minecraft:black_concrete
fill 478 201 276 478 204 276 minecraft:deepslate_tiles
setblock 478 201 315 minecraft:cobbled_deepslate
fill 478 201 316 481 201 316 minecraft:deepslate_tiles
fill 479 201 315 479 204 315 minecraft:deepslate_tiles
setblock 482 201 276 minecraft:cobbled_deepslate
setblock 482 201 316 minecraft:cobbled_deepslate
fill 483 201 276 483 204 276 minecraft:deepslate_tiles
fill 483 201 316 483 204 316 minecraft:deepslate_tiles
fill 485 201 276 486 201 276 minecraft:deepslate_tiles
fill 486 201 315 487 201 315 minecraft:deepslate_tiles
setblock 487 201 276 minecraft:cobbled_deepslate
setblock 487 201 316 minecraft:cobbled_deepslate
fill 488 201 276 488 204 276 minecraft:deepslate_tiles
setblock 488 201 315 minecraft:cobbled_deepslate
fill 488 201 316 488 204 316 minecraft:deepslate_tiles
fill 489 201 315 489 204 315 minecraft:deepslate_tiles
fill 490 201 314 490 204 314 minecraft:deepslate_tiles
setblock 492 201 276 minecraft:cobbled_deepslate
setblock 492 201 316 minecraft:cobbled_deepslate
fill 493 201 276 493 204 276 minecraft:deepslate_tiles
setblock 493 201 315 minecraft:cobbled_deepslate
fill 493 201 316 493 204 316 minecraft:deepslate_tiles
setblock 494 201 314 minecraft:cobbled_deepslate
fill 494 201 315 494 204 315 minecraft:deepslate_tiles
setblock 495 201 313 minecraft:cobbled_deepslate
fill 495 201 314 495 204 314 minecraft:deepslate_tiles
setblock 496 201 313 minecraft:deepslate_tiles
setblock 497 201 276 minecraft:cobbled_deepslate
setblock 497 201 316 minecraft:cobbled_deepslate
fill 498 201 276 498 204 276 minecraft:deepslate_tiles
setblock 498 201 315 minecraft:cobbled_deepslate
fill 498 201 316 498 204 316 minecraft:deepslate_tiles
setblock 499 201 275 minecraft:black_concrete
setblock 499 201 314 minecraft:cobbled_deepslate
fill 499 201 315 499 204 315 minecraft:deepslate_tiles
setblock 501 201 275 minecraft:black_concrete
setblock 502 201 316 minecraft:cobbled_deepslate
fill 503 201 316 503 204 316 minecraft:deepslate_tiles
fill 504 201 282 505 204 284 minecraft:bone_block
fill 505 201 281 507 204 281 minecraft:bone_block
fill 505 201 285 507 204 285 minecraft:bone_block
fill 506 201 282 508 204 282 minecraft:bone_block
fill 506 201 284 508 204 284 minecraft:bone_block
fill 506 201 317 506 202 317 minecraft:black_concrete
fill 507 201 283 508 204 283 minecraft:bone_block
fill 510 201 289 510 204 289 minecraft:deepslate_tiles
setblock 510 201 293 minecraft:cobbled_deepslate
fill 510 201 294 510 204 294 minecraft:deepslate_tiles
setblock 510 201 298 minecraft:cobbled_deepslate
fill 510 201 316 510 202 316 minecraft:deepslate_tiles
setblock 511 201 287 minecraft:cobbled_deepslate
fill 511 201 288 511 204 288 minecraft:deepslate_tiles
setblock 511 201 292 minecraft:cobbled_deepslate
fill 511 201 293 511 204 293 minecraft:deepslate_tiles
setblock 511 201 297 minecraft:cobbled_deepslate
fill 511 201 298 511 204 298 minecraft:deepslate_tiles
setblock 511 201 302 minecraft:cobbled_deepslate
setblock 511 201 312 minecraft:cobbled_deepslate
fill 511 201 313 511 203 314 minecraft:deepslate_tiles
setblock 512 201 280 minecraft:black_concrete
setblock 512 201 288 minecraft:black_concrete
fill 512 201 297 512 202 297 minecraft:black_concrete
setblock 512 201 302 minecraft:black_concrete
setblock 512 201 309 minecraft:black_concrete
setblock 512 201 311 minecraft:black_concrete
setblock 512 201 314 minecraft:black_concrete
setblock 512 201 317 minecraft:black_concrete
fill 470 202 275 470 202 290 minecraft:deepslate_tiles
fill 470 202 291 470 203 291 minecraft:black_concrete
fill 470 202 292 470 240 296 minecraft:deepslate_tiles
setblock 470 202 297 minecraft:white_wool
fill 470 202 298 470 202 308 minecraft:deepslate_tiles
fill 470 202 311 470 203 311 minecraft:deepslate_tiles
fill 470 202 313 470 233 313 minecraft:deepslate_tiles
fill 470 202 315 470 275 316 minecraft:deepslate_tiles
fill 471 202 275 480 202 275 minecraft:deepslate_tiles
setblock 471 202 276 minecraft:cobbled_deepslate
fill 471 202 277 471 205 277 minecraft:deepslate_tiles
setblock 471 202 280 minecraft:deepslate_tiles
setblock 471 202 281 minecraft:cobbled_deepslate
fill 471 202 282 472 204 282 minecraft:deepslate_tiles
setblock 471 202 286 minecraft:cobbled_deepslate
fill 471 202 287 471 205 287 minecraft:deepslate_tiles
setblock 471 202 291 minecraft:cobbled_deepslate
fill 471 202 292 471 205 292 minecraft:deepslate_tiles
setblock 471 202 296 minecraft:cobbled_deepslate
fill 471 202 297 471 205 297 minecraft:deepslate_tiles
setblock 471 202 300 minecraft:deepslate_tiles
setblock 471 202 311 minecraft:cobbled_deepslate
fill 471 202 312 471 205 312 minecraft:deepslate_tiles
setblock 471 202 315 minecraft:deepslate_tiles
setblock 471 202 316 minecraft:cobbled_deepslate
fill 471 202 317 501 202 317 minecraft:deepslate_tiles
fill 472 202 276 472 205 276 minecraft:deepslate_tiles
setblock 472 202 279 minecraft:deepslate_tiles
setblock 472 202 280 minecraft:cobbled_deepslate
fill 472 202 281 472 205 281 minecraft:deepslate_tiles
fill 472 202 283 472 203 283 minecraft:deepslate_tiles
setblock 472 202 285 minecraft:cobbled_deepslate
fill 472 202 286 472 205 286 minecraft:deepslate_tiles
setblock 472 202 290 minecraft:cobbled_deepslate
fill 472 202 291 472 205 291 minecraft:deepslate_tiles
setblock 472 202 295 minecraft:cobbled_deepslate
fill 472 202 296 473 204 296 minecraft:deepslate_tiles
fill 472 202 298 472 203 298 minecraft:deepslate_tiles
fill 472 202 313 472 202 314 minecraft:deepslate_tiles
setblock 472 202 315 minecraft:cobbled_deepslate
fill 472 202 316 472 205 316 minecraft:deepslate_tiles
setblock 473 202 289 minecraft:cobbled_deepslate
fill 473 202 290 473 205 290 minecraft:deepslate_tiles
setblock 473 202 294 minecraft:cobbled_deepslate
fill 473 202 295 473 205 295 minecraft:deepslate_tiles
fill 473 202 315 473 205 315 minecraft:deepslate_tiles
setblock 475 202 276 minecraft:deepslate_tiles
setblock 475 202 277 minecraft:cobbled_deepslate
setblock 476 202 276 minecraft:cobbled_deepslate
fill 476 202 277 476 205 277 minecraft:deepslate_tiles
setblock 476 202 316 minecraft:cobbled_deepslate
fill 477 202 276 477 205 276 minecraft:deepslate_tiles
setblock 477 202 315 minecraft:cobbled_deepslate
fill 477 202 316 480 202 316 minecraft:deepslate_tiles
fill 478 202 315 478 205 315 minecraft:deepslate_tiles
setblock 480 202 277 minecraft:cobbled_deepslate
setblock 481 202 276 minecraft:cobbled_deepslate
setblock 481 202 315 minecraft:deepslate_tiles
setblock 481 202 316 minecraft:cobbled_deepslate
fill 482 202 275 482 202 276 minecraft:deepslate_tiles
fill 482 202 316 482 205 316 minecraft:deepslate_tiles
fill 483 202 275 484 202 275 minecraft:deepslate_tiles
setblock 485 202 276 minecraft:deepslate_tiles
fill 485 202 315 486 202 315 minecraft:deepslate_tiles
fill 486 202 275 493 227 275 minecraft:deepslate_tiles
setblock 486 202 276 minecraft:cobbled_deepslate
setblock 486 202 316 minecraft:cobbled_deepslate
fill 487 202 276 487 205 276 minecraft:deepslate_tiles
setblock 487 202 315 minecraft:cobbled_deepslate
fill 487 202 316 487 205 316 minecraft:deepslate_tiles
fill 488 202 315 488 205 315 minecraft:deepslate_tiles
fill 489 202 314 489 205 314 minecraft:deepslate_tiles
setblock 491 202 276 minecraft:cobbled_deepslate
fill 491 202 277 494 202 277 minecraft:deepslate_tiles
setblock 491 202 315 minecraft:deepslate_tiles
setblock 491 202 316 minecraft:cobbled_deepslate
fill 492 202 276 492 205 276 minecraft:deepslate_tiles
fill 492 202 313 492 203 313 minecraft:deepslate_tiles
setblock 492 202 315 minecraft:cobbled_deepslate
fill 492 202 316 492 205 316 minecraft:deepslate_tiles
setblock 493 202 314 minecraft:cobbled_deepslate
fill 493 202 315 493 205 315 minecraft:deepslate_tiles
fill 494 202 275 495 202 275 minecraft:black_concrete
setblock 494 202 313 minecraft:cobbled_deepslate
fill 494 202 314 494 205 314 minecraft:deepslate_tiles
fill 495 202 313 495 203 313 minecraft:deepslate_tiles
fill 496 202 275 503 202 275 minecraft:deepslate_tiles
setblock 496 202 276 minecraft:cobbled_deepslate
setblock 496 202 316 minecraft:cobbled_deepslate
fill 497 202 276 497 205 276 minecraft:deepslate_tiles
setblock 497 202 315 minecraft:cobbled_deepslate
fill 497 202 316 497 205 316 minecraft:deepslate_tiles
setblock 498 202 314 minecraft:cobbled_deepslate
fill 498 202 315 498 205 315 minecraft:deepslate_tiles
setblock 501 202 316 minecraft:cobbled_deepslate
fill 502 202 316 502 205 316 minecraft:deepslate_tiles
fill 503 202 317 505 305 317 minecraft:deepslate_tiles
fill 505 202 275 512 203 275 minecraft:deepslate_tiles
fill 506 202 288 506 204 288 minecraft:black_concrete
fill 507 202 287 507 204 287 minecraft:black_concrete
fill 507 202 289 507 204 289 minecraft:black_concrete
fill 508 202 288 508 204 288 minecraft:black_concrete
fill 508 202 316 509 203 317 minecraft:deepslate_tiles
setblock 509 202 293 minecraft:cobbled_deepslate
fill 509 202 294 509 203 296 minecraft:deepslate_tiles
setblock 510 202 292 minecraft:cobbled_deepslate
fill 510 202 293 510 205 293 minecraft:deepslate_tiles
setblock 510 202 296 minecraft:deepslate_tiles
setblock 510 202 297 minecraft:cobbled_deepslate
fill 510 202 298 510 203 300 minecraft:deepslate_tiles
fill 510 202 317 512 306 317 minecraft:deepslate_tiles
setblock 511 202 276 minecraft:cobbled_deepslate
fill 511 202 277 512 205 277 minecraft:deepslate_tiles
fill 511 202 285 512 202 285 minecraft:deepslate_tiles
setblock 511 202 286 minecraft:cobbled_deepslate
fill 511 202 287 512 203 287 minecraft:deepslate_tiles
setblock 511 202 291 minecraft:cobbled_deepslate
fill 511 202 292 512 205 292 minecraft:deepslate_tiles
setblock 511 202 296 minecraft:cobbled_deepslate
fill 511 202 297 511 205 297 minecraft:deepslate_tiles
fill 511 202 300 512 202 300 minecraft:deepslate_tiles
setblock 511 202 301 minecraft:cobbled_deepslate
fill 511 202 302 512 202 304 minecraft:deepslate_tiles
setblock 511 202 311 minecraft:cobbled_deepslate
fill 511 202 312 511 205 312 minecraft:deepslate_tiles
setblock 511 202 316 minecraft:cobbled_deepslate
fill 512 202 276 512 308 276 minecraft:deepslate_tiles
fill 512 202 278 512 202 284 minecraft:deepslate_tiles
fill 512 202 286 512 308 286 minecraft:deepslate_tiles
fill 512 202 288 512 239 291 minecraft:deepslate_tiles
fill 512 202 293 512 202 296 minecraft:deepslate_tiles
fill 512 202 298 512 297 299 minecraft:deepslate_tiles
fill 512 202 301 512 308 301 minecraft:deepslate_tiles
fill 512 202 305 512 246 311 minecraft:deepslate_tiles
fill 512 202 313 512 203 315 minecraft:deepslate_tiles
fill 512 202 316 512 203 316 minecraft:black_concrete
fill 470 203 275 470 204 275 minecraft:black_concrete
fill 470 203 276 471 206 276 minecraft:deepslate_tiles
setblock 470 203 277 minecraft:black_concrete
fill 470 203 278 470 308 280 minecraft:deepslate_tiles
setblock 470 203 281 minecraft:black_concrete
fill 470 203 282 470 253 285 minecraft:deepslate_tiles
setblock 470 203 286 minecraft:white_wool
setblock 470 203 287 minecraft:black_concrete
fill 470 203 288 470 290 290 minecraft:deepslate_tiles
fill 470 203 297 470 308 297 minecraft:deepslate_tiles
setblock 470 203 298 minecraft:black_concrete
fill 470 203 299 470 203 310 minecraft:deepslate_tiles
fill 470 203 314 470 242 314 minecraft:deepslate_tiles
fill 470 203 317 483 203 317 minecraft:deepslate_tiles
fill 471 203 275 475 302 275 minecraft:deepslate_tiles
setblock 471 203 280 minecraft:cobbled_deepslate
fill 471 203 281 471 206 281 minecraft:deepslate_tiles
setblock 471 203 284 minecraft:deepslate_tiles
setblock 471 203 285 minecraft:cobbled_deepslate
fill 471 203 286 471 206 286 minecraft:deepslate_tiles
setblock 471 203 290 minecraft:cobbled_deepslate
fill 471 203 291 471 206 291 minecraft:deepslate_tiles
setblock 471 203 295 minecraft:cobbled_deepslate
fill 471 203 296 471 206 296 minecraft:deepslate_tiles
setblock 471 203 300 minecraft:cobbled_deepslate
fill 471 203 301 471 206 301 minecraft:deepslate_tiles
fill 471 203 311 471 206 311 minecraft:deepslate_tiles
setblock 471 203 315 minecraft:cobbled_deepslate
fill 471 203 316 471 206 316 minecraft:deepslate_tiles
setblock 472 203 279 minecraft:cobbled_deepslate
fill 472 203 280 472 206 280 minecraft:deepslate_tiles
setblock 472 203 284 minecraft:cobbled_deepslate
fill 472 203 285 472 206 285 minecraft:deepslate_tiles
setblock 472 203 289 minecraft:cobbled_deepslate
fill 472 203 290 472 206 290 minecraft:deepslate_tiles
setblock 472 203 294 minecraft:cobbled_deepslate
fill 472 203 295 472 206 295 minecraft:deepslate_tiles
setblock 472 203 299 minecraft:cobbled_deepslate
setblock 472 203 313 minecraft:deepslate_tiles
setblock 472 203 314 minecraft:cobbled_deepslate
fill 472 203 315 472 206 315 minecraft:deepslate_tiles
setblock 473 203 278 minecraft:cobbled_deepslate
fill 473 203 279 473 206 279 minecraft:deepslate_tiles
setblock 473 203 288 minecraft:cobbled_deepslate
fill 473 203 289 473 205 289 minecraft:deepslate_tiles
setblock 473 203 293 minecraft:cobbled_deepslate
fill 473 203 294 473 206 294 minecraft:deepslate_tiles
setblock 473 203 297 minecraft:deepslate_tiles
setblock 474 203 277 minecraft:cobbled_deepslate
fill 474 203 278 476 204 278 minecraft:deepslate_tiles
setblock 475 203 276 minecraft:cobbled_deepslate
fill 475 203 277 475 206 277 minecraft:deepslate_tiles
setblock 475 203 316 minecraft:cobbled_deepslate
setblock 476 203 275 minecraft:black_concrete
fill 476 203 276 476 206 276 minecraft:deepslate_tiles
setblock 476 203 315 minecraft:cobbled_deepslate
fill 476 203 316 479 203 316 minecraft:deepslate_tiles
fill 477 203 275 478 226 275 minecraft:deepslate_tiles
fill 477 203 315 477 206 315 minecraft:deepslate_tiles
fill 479 203 275 480 203 275 minecraft:black_concrete
setblock 479 203 277 minecraft:cobbled_deepslate
setblock 480 203 276 minecraft:cobbled_deepslate
fill 480 203 277 481 205 277 minecraft:deepslate_tiles
setblock 480 203 316 minecraft:cobbled_deepslate
fill 481 203 275 481 206 276 minecraft:deepslate_tiles
setblock 481 203 315 minecraft:cobbled_deepslate
fill 481 203 316 481 206 316 minecraft:deepslate_tiles
setblock 482 203 275 minecraft:black_concrete
fill 482 203 276 482 205 276 minecraft:deepslate_tiles
fill 482 203 315 485 203 315 minecraft:deepslate_tiles
fill 483 203 275 483 308 275 minecraft:deepslate_tiles
setblock 484 203 275 minecraft:black_concrete
setblock 484 203 317 minecraft:black_concrete
fill 485 203 275 485 308 275 minecraft:deepslate_tiles
setblock 485 203 276 minecraft:cobbled_deepslate
setblock 485 203 316 minecraft:cobbled_deepslate
fill 485 203 317 502 203 317 minecraft:deepslate_tiles
fill 486 203 276 486 206 276 minecraft:deepslate_tiles
setblock 486 203 315 minecraft:cobbled_deepslate
fill 486 203 316 486 206 316 minecraft:deepslate_tiles
fill 487 203 315 487 206 315 minecraft:deepslate_tiles
setblock 488 203 277 minecraft:deepslate_tiles
fill 488 203 314 488 206 314 minecraft:deepslate_tiles
setblock 489 203 277 minecraft:cobbled_deepslate
setblock 489 203 316 minecraft:deepslate_tiles
setblock 490 203 276 minecraft:cobbled_deepslate
fill 490 203 277 493 203 277 minecraft:deepslate_tiles
setblock 490 203 316 minecraft:cobbled_deepslate
fill 491 203 276 491 206 276 minecraft:deepslate_tiles
setblock 491 203 315 minecraft:cobbled_deepslate
fill 491 203 316 491 206 316 minecraft:deepslate_tiles
setblock 492 203 314 minecraft:cobbled_deepslate
fill 492 203 315 492 206 315 minecraft:deepslate_tiles
setblock 493 203 313 minecraft:cobbled_deepslate
fill 493 203 314 493 206 314 minecraft:deepslate_tiles
fill 494 203 275 499 203 275 minecraft:deepslate_tiles
setblock 494 203 277 minecraft:cobbled_deepslate
fill 494 203 313 494 205 313 minecraft:deepslate_tiles
setblock 495 203 276 minecraft:cobbled_deepslate
fill 495 203 277 495 206 277 minecraft:deepslate_tiles
setblock 495 203 316 minecraft:cobbled_deepslate
fill 496 203 276 496 206 276 minecraft:deepslate_tiles
setblock 496 203 315 minecraft:cobbled_deepslate
fill 496 203 316 496 206 316 minecraft:deepslate_tiles
setblock 497 203 314 minecraft:cobbled_deepslate
fill 497 203 315 497 206 315 minecraft:deepslate_tiles
setblock 498 203 314 minecraft:deepslate_tiles
setblock 499 203 276 minecraft:deepslate_tiles
setblock 499 203 316 minecraft:deepslate_tiles
setblock 500 203 275 minecraft:black_concrete
setblock 500 203 316 minecraft:cobbled_deepslate
fill 501 203 275 504 308 275 minecraft:deepslate_tiles
fill 501 203 316 501 206 316 minecraft:deepslate_tiles
fill 506 203 317 507 308 317 minecraft:deepslate_tiles
fill 507 203 316 507 205 316 minecraft:deepslate_tiles
setblock 509 203 276 minecraft:deepslate_tiles
setblock 509 203 292 minecraft:cobbled_deepslate
fill 509 203 293 509 206 293 minecraft:deepslate_tiles
setblock 509 203 297 minecraft:cobbled_deepslate
fill 509 203 298 509 206 298 minecraft:deepslate_tiles
setblock 510 203 276 minecraft:cobbled_deepslate
fill 510 203 288 510 205 288 minecraft:deepslate_tiles
setblock 510 203 291 minecraft:cobbled_deepslate
fill 510 203 292 510 206 292 minecraft:deepslate_tiles
setblock 510 203 296 minecraft:cobbled_deepslate
fill 510 203 297 510 206 297 minecraft:deepslate_tiles
setblock 510 203 301 minecraft:cobbled_deepslate
setblock 510 203 316 minecraft:cobbled_deepslate
fill 511 203 276 511 206 276 minecraft:deepslate_tiles
fill 511 203 278 512 203 279 minecraft:deepslate_tiles
setblock 511 203 280 minecraft:cobbled_deepslate
fill 511 203 281 511 203 284 minecraft:deepslate_tiles
setblock 511 203 285 minecraft:cobbled_deepslate
fill 511 203 286 511 206 286 minecraft:deepslate_tiles
setblock 511 203 290 minecraft:cobbled_deepslate
fill 511 203 291 511 206 291 minecraft:deepslate_tiles
setblock 511 203 295 minecraft:cobbled_deepslate
fill 511 203 296 511 206 296 minecraft:deepslate_tiles
setblock 511 203 300 minecraft:cobbled_deepslate
fill 511 203 301 511 203 304 minecraft:deepslate_tiles
setblock 511 203 305 minecraft:cobbled_deepslate
fill 511 203 308 511 203 309 minecraft:deepslate_tiles
setblock 511 203 310 minecraft:cobbled_deepslate
fill 511 203 311 511 206 311 minecraft:deepslate_tiles
setblock 511 203 315 minecraft:cobbled_deepslate
fill 511 203 316 511 206 316 minecraft:deepslate_tiles
setblock 512 203 280 minecraft:deepslate_tiles
setblock 512 203 281 minecraft:black_concrete
fill 512 203 282 512 267 285 minecraft:deepslate_tiles
fill 512 203 293 512 267 295 minecraft:deepslate_tiles
setblock 512 203 296 minecraft:black_concrete
fill 512 203 297 512 308 297 minecraft:deepslate_tiles
fill 512 203 300 512 308 300 minecraft:deepslate_tiles
fill 512 203 302 512 245 303 minecraft:deepslate_tiles
setblock 512 203 304 minecraft:black_concrete
fill 512 203 312 512 308 312 minecraft:deepslate_tiles
fill 470 204 277 470 308 277 minecraft:deepslate_tiles
fill 470 204 281 470 222 281 minecraft:deepslate_tiles
fill 470 204 286 470 249 287 minecraft:deepslate_tiles
fill 470 204 291 470 308 291 minecraft:deepslate_tiles
fill 470 204 298 470 262 307 minecraft:deepslate_tiles
setblock 470 204 308 minecraft:black_concrete
fill 470 204 309 470 227 309 minecraft:deepslate_tiles
fill 470 204 310 470 204 311 minecraft:black_concrete
fill 470 204 312 470 308 312 minecraft:deepslate_tiles
fill 470 204 317 471 308 317 minecraft:deepslate_tiles
setblock 471 204 278 minecraft:deepslate_tiles
setblock 471 204 279 minecraft:cobbled_deepslate
fill 471 204 280 471 207 280 minecraft:deepslate_tiles
setblock 471 204 284 minecraft:cobbled_deepslate
fill 471 204 285 471 207 285 minecraft:deepslate_tiles
setblock 471 204 289 minecraft:cobbled_deepslate
fill 471 204 290 471 207 290 minecraft:deepslate_tiles
setblock 471 204 294 minecraft:cobbled_deepslate
fill 471 204 295 471 207 295 minecraft:deepslate_tiles
setblock 471 204 299 minecraft:cobbled_deepslate
fill 471 204 300 472 206 300 minecraft:deepslate_tiles
fill 471 204 302 471 204 303 minecraft:deepslate_tiles
fill 471 204 310 471 207 310 minecraft:deepslate_tiles
setblock 471 204 314 minecraft:cobbled_deepslate
fill 471 204 315 471 207 315 minecraft:deepslate_tiles
setblock 472 204 277 minecraft:deepslate_tiles
setblock 472 204 278 minecraft:cobbled_deepslate
fill 472 204 279 472 207 279 minecraft:deepslate_tiles
setblock 472 204 283 minecraft:cobbled_deepslate
fill 472 204 284 472 207 284 minecraft:deepslate_tiles
setblock 472 204 288 minecraft:cobbled_deepslate
fill 472 204 289 472 207 289 minecraft:deepslate_tiles
setblock 472 204 293 minecraft:cobbled_deepslate
fill 472 204 294 472 207 294 minecraft:deepslate_tiles
setblock 472 204 298 minecraft:cobbled_deepslate
fill 472 204 299 472 207 299 minecraft:deepslate_tiles
setblock 472 204 313 minecraft:cobbled_deepslate
fill 472 204 314 472 207 314 minecraft:deepslate_tiles
fill 472 204 317 473 204 317 minecraft:black_concrete
setblock 473 204 277 minecraft:cobbled_deepslate
fill 473 204 278 473 207 278 minecraft:deepslate_tiles
fill 473 204 280 473 204 281 minecraft:deepslate_tiles
setblock 473 204 288 minecraft:deepslate_tiles
setblock 473 204 292 minecraft:cobbled_deepslate
fill 473 204 293 473 207 293 minecraft:deepslate_tiles
setblock 473 204 297 minecraft:cobbled_deepslate
fill 473 204 298 473 207 298 minecraft:deepslate_tiles
setblock 474 204 276 minecraft:cobbled_deepslate
fill 474 204 277 474 207 277 minecraft:deepslate_tiles
setblock 474 204 316 minecraft:cobbled_deepslate
fill 474 204 317 487 214 317 minecraft:deepslate_tiles
fill 475 204 276 475 207 276 minecraft:deepslate_tiles
setblock 475 204 315 minecraft:cobbled_deepslate
fill 475 204 316 478 204 316 minecraft:deepslate_tiles
fill 476 204 275 476 269 275 minecraft:deepslate_tiles
fill 476 204 315 476 207 315 minecraft:deepslate_tiles
setblock 477 204 278 minecraft:cobbled_deepslate
setblock 478 204 277 minecraft:cobbled_deepslate
fill 479 204 275 480 286 275 minecraft:deepslate_tiles
setblock 479 204 276 minecraft:cobbled_deepslate
fill 479 204 277 479 207 277 minecraft:deepslate_tiles
setblock 479 204 316 minecraft:cobbled_deepslate
fill 480 204 276 480 207 276 minecraft:deepslate_tiles
setblock 480 204 315 minecraft:cobbled_deepslate
fill 480 204 316 480 207 316 minecraft:deepslate_tiles
fill 481 204 315 484 204 315 minecraft:deepslate_tiles
fill 482 204 275 482 308 275 minecraft:deepslate_tiles
setblock 482 204 277 minecraft:deepslate_tiles
setblock 483 204 277 minecraft:cobbled_deepslate
fill 484 204 275 484 308 275 minecraft:deepslate_tiles
setblock 484 204 276 minecraft:cobbled_deepslate
setblock 484 204 316 minecraft:cobbled_deepslate
fill 485 204 276 485 206 277 minecraft:deepslate_tiles
setblock 485 204 315 minecraft:cobbled_deepslate
fill 485 204 316 485 207 316 minecraft:deepslate_tiles
fill 486 204 277 487 204 277 minecraft:deepslate_tiles
fill 486 204 315 486 207 315 minecraft:deepslate_tiles
fill 487 204 314 487 207 314 minecraft:deepslate_tiles
setblock 488 204 277 minecraft:cobbled_deepslate
setblock 488 204 317 minecraft:redstone_block
setblock 489 204 276 minecraft:cobbled_deepslate
fill 489 204 277 492 204 277 minecraft:deepslate_tiles
setblock 489 204 316 minecraft:cobbled_deepslate
setblock 489 204 317 minecraft:black_concrete
fill 490 204 276 490 207 276 minecraft:deepslate_tiles
setblock 490 204 315 minecraft:cobbled_deepslate
fill 490 204 316 490 207 317 minecraft:deepslate_tiles
setblock 491 204 313 minecraft:deepslate_tiles
setblock 491 204 314 minecraft:cobbled_deepslate
fill 491 204 315 491 207 315 minecraft:deepslate_tiles
fill 491 204 317 492 245 317 minecraft:deepslate_tiles
setblock 492 204 313 minecraft:cobbled_deepslate
fill 492 204 314 492 207 314 minecraft:deepslate_tiles
setblock 493 204 277 minecraft:cobbled_deepslate
fill 493 204 313 493 206 313 minecraft:deepslate_tiles
fill 493 204 317 496 204 317 minecraft:black_concrete
setblock 494 204 275 minecraft:black_concrete
setblock 494 204 276 minecraft:cobbled_deepslate
fill 494 204 277 494 207 277 minecraft:deepslate_tiles
setblock 494 204 316 minecraft:cobbled_deepslate
fill 495 204 275 495 207 276 minecraft:deepslate_tiles
setblock 495 204 315 minecraft:cobbled_deepslate
fill 495 204 316 495 207 316 minecraft:deepslate_tiles
fill 496 204 275 500 269 275 minecraft:deepslate_tiles
fill 496 204 277 496 205 277 minecraft:deepslate_tiles
setblock 496 204 314 minecraft:cobbled_deepslate
fill 496 204 315 496 207 315 minecraft:deepslate_tiles
fill 497 204 314 497 205 314 minecraft:deepslate_tiles
setblock 497 204 317 minecraft:white_wool
setblock 498 204 317 minecraft:black_concrete
setblock 499 204 276 minecraft:cobbled_deepslate
setblock 499 204 316 minecraft:cobbled_deepslate
fill 499 204 317 502 221 317 minecraft:deepslate_tiles
setblock 500 204 315 minecraft:cobbled_deepslate
fill 500 204 316 500 207 316 minecraft:deepslate_tiles
setblock 504 204 316 minecraft:cobbled_deepslate
fill 505 204 275 507 204 275 minecraft:black_concrete
fill 505 204 316 506 206 316 minecraft:deepslate_tiles
fill 507 204 276 508 204 276 minecraft:deepslate_tiles
fill 508 204 275 512 240 275 minecraft:deepslate_tiles
setblock 508 204 316 minecraft:deepslate_tiles
setblock 508 204 317 minecraft:black_concrete
setblock 509 204 276 minecraft:cobbled_deepslate
setblock 509 204 291 minecraft:cobbled_deepslate
fill 509 204 292 509 207 292 minecraft:deepslate_tiles
fill 509 204 294 509 204 295 minecraft:deepslate_tiles
setblock 509 204 296 minecraft:cobbled_deepslate
fill 509 204 297 509 207 297 minecraft:deepslate_tiles
fill 509 204 299 510 204 299 minecraft:deepslate_tiles
setblock 509 204 316 minecraft:cobbled_deepslate
fill 509 204 317 509 308 317 minecraft:deepslate_tiles
fill 510 204 276 510 206 277 minecraft:deepslate_tiles
fill 510 204 287 511 205 287 minecraft:deepslate_tiles
setblock 510 204 290 minecraft:cobbled_deepslate
fill 510 204 291 510 207 291 minecraft:deepslate_tiles
setblock 510 204 295 minecraft:cobbled_deepslate
fill 510 204 296 510 207 296 minecraft:deepslate_tiles
fill 510 204 298 510 205 298 minecraft:deepslate_tiles
setblock 510 204 300 minecraft:cobbled_deepslate
fill 510 204 301 511 205 302 minecraft:deepslate_tiles
setblock 510 204 314 minecraft:deepslate_tiles
setblock 510 204 315 minecraft:cobbled_deepslate
fill 510 204 316 510 207 316 minecraft:deepslate_tiles
fill 511 204 278 512 204 278 minecraft:deepslate_tiles
setblock 511 204 279 minecraft:cobbled_deepslate
fill 511 204 280 511 204 283 minecraft:deepslate_tiles
setblock 511 204 284 minecraft:cobbled_deepslate
fill 511 204 285 511 207 285 minecraft:deepslate_tiles
setblock 511 204 289 minecraft:cobbled_deepslate
fill 511 204 290 511 207 290 minecraft:deepslate_tiles
setblock 511 204 294 minecraft:cobbled_deepslate
fill 511 204 295 511 207 295 minecraft:deepslate_tiles
setblock 511 204 299 minecraft:cobbled_deepslate
fill 511 204 300 511 207 300 minecraft:deepslate_tiles
setblock 511 204 303 minecraft:deepslate_tiles
setblock 511 204 304 minecraft:cobbled_deepslate
fill 511 204 305 511 204 308 minecraft:deepslate_tiles
setblock 511 204 309 minecraft:cobbled_deepslate
fill 511 204 310 511 207 310 minecraft:deepslate_tiles
fill 511 204 313 512 204 313 minecraft:deepslate_tiles
setblock 511 204 314 minecraft:cobbled_deepslate
fill 511 204 315 511 207 315 minecraft:deepslate_tiles
fill 512 204 279 512 308 279 minecraft:deepslate_tiles
setblock 512 204 280 minecraft:black_concrete
fill 512 204 281 512 308 281 minecraft:deepslate_tiles
setblock 512 204 287 minecraft:black_concrete
fill 512 204 296 512 219 296 minecraft:deepslate_tiles
fill 512 204 304 512 308 304 minecraft:deepslate_tiles
fill 512 204 314 512 204 315 minecraft:black_concrete
fill 512 204 316 512 216 316 minecraft:deepslate_tiles
fill 470 205 275 470 308 275 minecraft:deepslate_tiles
fill 470 205 308 470 308 308 minecraft:deepslate_tiles
fill 470 205 310 470 272 311 minecraft:deepslate_tiles
setblock 471 205 278 minecraft:cobbled_deepslate
fill 471 205 279 471 208 279 minecraft:deepslate_tiles
setblock 471 205 282 minecraft:deepslate_tiles
setblock 471 205 283 minecraft:cobbled_deepslate
fill 471 205 284 471 208 284 minecraft:deepslate_tiles
setblock 471 205 288 minecraft:cobbled_deepslate
fill 471 205 289 471 208 289 minecraft:deepslate_tiles
setblock 471 205 293 minecraft:cobbled_deepslate
fill 471 205 294 471 208 294 minecraft:deepslate_tiles
setblock 471 205 298 minecraft:cobbled_deepslate
fill 471 205 299 471 208 299 minecraft:deepslate_tiles
setblock 471 205 302 minecraft:deepslate_tiles
setblock 471 205 303 minecraft:cobbled_deepslate
fill 471 205 304 471 208 304 minecraft:deepslate_tiles
setblock 471 205 313 minecraft:cobbled_deepslate
fill 471 205 314 471 208 314 minecraft:deepslate_tiles
setblock 472 205 277 minecraft:cobbled_deepslate
fill 472 205 278 472 208 278 minecraft:deepslate_tiles
setblock 472 205 282 minecraft:cobbled_deepslate
fill 472 205 283 473 207 283 minecraft:deepslate_tiles
setblock 472 205 287 minecraft:cobbled_deepslate
fill 472 205 288 472 208 288 minecraft:deepslate_tiles
setblock 472 205 292 minecraft:cobbled_deepslate
fill 472 205 293 472 208 293 minecraft:deepslate_tiles
setblock 472 205 296 minecraft:deepslate_tiles
setblock 472 205 297 minecraft:cobbled_deepslate
fill 472 205 298 472 208 298 minecraft:deepslate_tiles
setblock 472 205 301 minecraft:deepslate_tiles
setblock 472 205 312 minecraft:cobbled_deepslate
fill 472 205 313 472 208 313 minecraft:deepslate_tiles
fill 472 205 317 473 225 317 minecraft:deepslate_tiles
setblock 473 205 276 minecraft:cobbled_deepslate
fill 473 205 277 473 208 277 minecraft:deepslate_tiles
setblock 473 205 280 minecraft:deepslate_tiles
setblock 473 205 281 minecraft:cobbled_deepslate
fill 473 205 282 473 208 282 minecraft:deepslate_tiles
setblock 473 205 285 minecraft:light[level=12]
setblock 473 205 286 minecraft:light[level=13]
setblock 473 205 291 minecraft:cobbled_deepslate
fill 473 205 292 473 207 292 minecraft:deepslate_tiles
setblock 473 205 296 minecraft:cobbled_deepslate
fill 473 205 297 473 208 297 minecraft:deepslate_tiles
setblock 473 205 299 minecraft:light[level=12]
setblock 473 205 302 minecraft:light[level=13]
setblock 473 205 306 minecraft:light[level=12]
setblock 473 205 310 minecraft:light[level=13]
setblock 473 205 313 minecraft:light[level=12]
setblock 473 205 316 minecraft:cobbled_deepslate
fill 474 205 276 474 208 276 minecraft:deepslate_tiles
fill 474 205 278 474 205 279 minecraft:deepslate_tiles
setblock 474 205 315 minecraft:cobbled_deepslate
fill 474 205 316 477 205 316 minecraft:deepslate_tiles
setblock 475 205 278 minecraft:deepslate_tiles
fill 475 205 315 475 208 315 minecraft:deepslate_tiles
setblock 476 205 278 minecraft:cobbled_deepslate
setblock 477 205 277 minecraft:cobbled_deepslate
fill 477 205 278 478 207 278 minecraft:deepslate_tiles
setblock 478 205 276 minecraft:cobbled_deepslate
fill 478 205 277 478 208 277 minecraft:deepslate_tiles
setblock 478 205 316 minecraft:cobbled_deepslate
fill 479 205 276 479 208 276 minecraft:deepslate_tiles
setblock 479 205 315 minecraft:cobbled_deepslate
fill 479 205 316 479 208 316 minecraft:deepslate_tiles
setblock 480 205 278 minecraft:light[level=12]
setblock 480 205 285 minecraft:light[level=12]
setblock 480 205 292 minecraft:light[level=12]
setblock 480 205 299 minecraft:light[level=12]
setblock 480 205 306 minecraft:light[level=12]
setblock 480 205 313 minecraft:light[level=12]
fill 480 205 315 483 205 315 minecraft:deepslate_tiles
setblock 481 205 278 minecraft:light[level=13]
setblock 481 205 286 minecraft:light[level=13]
setblock 481 205 294 minecraft:light[level=13]
setblock 481 205 302 minecraft:light[level=13]
setblock 481 205 310 minecraft:light[level=13]
setblock 482 205 277 minecraft:cobbled_deepslate
setblock 483 205 276 minecraft:cobbled_deepslate
fill 483 205 277 484 207 277 minecraft:deepslate_tiles
setblock 483 205 316 minecraft:cobbled_deepslate
fill 484 205 276 484 208 276 minecraft:deepslate_tiles
setblock 484 205 315 minecraft:cobbled_deepslate
fill 484 205 316 484 208 316 minecraft:deepslate_tiles
fill 485 205 315 485 208 315 minecraft:deepslate_tiles
setblock 486 205 277 minecraft:deepslate_tiles
setblock 487 205 277 minecraft:cobbled_deepslate
setblock 487 205 278 minecraft:light[level=12]
setblock 487 205 285 minecraft:light[level=12]
setblock 487 205 292 minecraft:light[level=12]
setblock 487 205 299 minecraft:light[level=12]
setblock 487 205 306 minecraft:light[level=12]
setblock 487 205 313 minecraft:light[level=12]
setblock 488 205 276 minecraft:cobbled_deepslate
fill 488 205 277 491 205 277 minecraft:deepslate_tiles
setblock 488 205 316 minecraft:cobbled_deepslate
fill 488 205 317 489 308 317 minecraft:deepslate_tiles
fill 489 205 276 489 208 276 minecraft:deepslate_tiles
setblock 489 205 278 minecraft:light[level=13]
setblock 489 205 286 minecraft:light[level=13]
setblock 489 205 294 minecraft:light[level=13]
setblock 489 205 302 minecraft:light[level=13]
setblock 489 205 310 minecraft:light[level=13]
setblock 489 205 315 minecraft:cobbled_deepslate
fill 489 205 316 489 208 316 minecraft:deepslate_tiles
setblock 490 205 313 minecraft:deepslate_tiles
setblock 490 205 314 minecraft:cobbled_deepslate
fill 490 205 315 490 208 315 minecraft:deepslate_tiles
setblock 491 205 278 minecraft:cobbled_deepslate
setblock 491 205 313 minecraft:cobbled_deepslate
fill 491 205 314 491 208 314 minecraft:deepslate_tiles
setblock 492 205 277 minecraft:cobbled_deepslate
fill 492 205 278 492 208 278 minecraft:deepslate_tiles
fill 492 205 313 492 207 313 minecraft:deepslate_tiles
setblock 493 205 276 minecraft:cobbled_deepslate
fill 493 205 277 493 208 277 minecraft:deepslate_tiles
setblock 493 205 316 minecraft:cobbled_deepslate
fill 493 205 317 498 239 317 minecraft:deepslate_tiles
fill 494 205 275 494 208 276 minecraft:deepslate_tiles
setblock 494 205 278 minecraft:light[level=12]
setblock 494 205 285 minecraft:light[level=12]
setblock 494 205 292 minecraft:light[level=12]
setblock 494 205 299 minecraft:light[level=12]
setblock 494 205 306 minecraft:light[level=12]
setblock 494 205 315 minecraft:cobbled_deepslate
fill 494 205 316 494 208 316 minecraft:deepslate_tiles
setblock 495 205 314 minecraft:cobbled_deepslate
fill 495 205 315 495 208 315 minecraft:deepslate_tiles
fill 496 205 314 496 206 314 minecraft:deepslate_tiles
setblock 497 205 278 minecraft:light[level=13]
setblock 497 205 286 minecraft:light[level=13]
setblock 497 205 294 minecraft:light[level=13]
setblock 497 205 302 minecraft:light[level=13]
setblock 497 205 310 minecraft:light[level=13]
setblock 498 205 276 minecraft:cobbled_deepslate
setblock 498 205 316 minecraft:cobbled_deepslate
fill 499 205 276 500 207 276 minecraft:deepslate_tiles
setblock 499 205 315 minecraft:cobbled_deepslate
fill 499 205 316 499 208 316 minecraft:deepslate_tiles
setblock 501 205 278 minecraft:light[level=12]
setblock 501 205 285 minecraft:light[level=12]
setblock 501 205 292 minecraft:light[level=12]
setblock 501 205 299 minecraft:light[level=12]
setblock 501 205 306 minecraft:light[level=12]
setblock 501 205 313 minecraft:light[level=12]
setblock 503 205 316 minecraft:cobbled_deepslate
fill 504 205 316 504 208 316 minecraft:deepslate_tiles
fill 505 205 275 507 218 275 minecraft:deepslate_tiles
setblock 505 205 278 minecraft:light[level=13]
setblock 505 205 286 minecraft:light[level=13]
setblock 505 205 294 minecraft:light[level=13]
setblock 505 205 302 minecraft:light[level=13]
setblock 505 205 310 minecraft:light[level=13]
fill 506 205 276 507 205 276 minecraft:deepslate_tiles
setblock 508 205 276 minecraft:cobbled_deepslate
setblock 508 205 278 minecraft:light[level=12]
setblock 508 205 285 minecraft:light[level=12]
setblock 508 205 292 minecraft:light[level=12]
setblock 508 205 295 minecraft:deepslate_tiles
setblock 508 205 296 minecraft:cobbled_deepslate
fill 508 205 297 508 208 297 minecraft:deepslate_tiles
setblock 508 205 299 minecraft:light[level=12]
setblock 508 205 306 minecraft:light[level=12]
setblock 508 205 313 minecraft:light[level=12]
setblock 508 205 316 minecraft:cobbled_deepslate
fill 508 205 317 508 308 317 minecraft:deepslate_tiles
fill 509 205 276 509 207 277 minecraft:deepslate_tiles
setblock 509 205 290 minecraft:cobbled_deepslate
fill 509 205 291 509 208 291 minecraft:deepslate_tiles
setblock 509 205 294 minecraft:deepslate_tiles
setblock 509 205 295 minecraft:cobbled_deepslate
fill 509 205 296 509 208 296 minecraft:deepslate_tiles
setblock 509 205 299 minecraft:deepslate_tiles
setblock 509 205 300 minecraft:cobbled_deepslate
fill 509 205 301 509 208 301 minecraft:deepslate_tiles
setblock 509 205 315 minecraft:cobbled_deepslate
fill 509 205 316 509 208 316 minecraft:deepslate_tiles
setblock 510 205 278 minecraft:deepslate_tiles
setblock 510 205 279 minecraft:cobbled_deepslate
fill 510 205 280 511 206 281 minecraft:deepslate_tiles
fill 510 205 286 510 207 286 minecraft:deepslate_tiles
setblock 510 205 289 minecraft:cobbled_deepslate
fill 510 205 290 510 208 290 minecraft:deepslate_tiles
setblock 510 205 294 minecraft:cobbled_deepslate
fill 510 205 295 510 208 295 minecraft:deepslate_tiles
setblock 510 205 299 minecraft:cobbled_deepslate
fill 510 205 300 510 208 300 minecraft:deepslate_tiles
setblock 510 205 303 minecraft:deepslate_tiles
setblock 510 205 314 minecraft:cobbled_deepslate
fill 510 205 315 510 208 315 minecraft:deepslate_tiles
setblock 511 205 278 minecraft:cobbled_deepslate
fill 511 205 279 511 208 279 minecraft:deepslate_tiles
setblock 511 205 282 minecraft:deepslate_tiles
setblock 511 205 283 minecraft:cobbled_deepslate
fill 511 205 284 511 208 284 minecraft:deepslate_tiles
setblock 511 205 288 minecraft:cobbled_deepslate
fill 511 205 289 511 208 289 minecraft:deepslate_tiles
setblock 511 205 293 minecraft:cobbled_deepslate
fill 511 205 294 511 208 294 minecraft:deepslate_tiles
setblock 511 205 298 minecraft:cobbled_deepslate
fill 511 205 299 511 208 299 minecraft:deepslate_tiles
setblock 511 205 303 minecraft:cobbled_deepslate
fill 511 205 304 511 205 307 minecraft:deepslate_tiles
setblock 511 205 308 minecraft:cobbled_deepslate
fill 511 205 309 511 208 309 minecraft:deepslate_tiles
setblock 511 205 313 minecraft:cobbled_deepslate
fill 511 205 314 512 208 314 minecraft:deepslate_tiles
fill 512 205 278 512 212 278 minecraft:deepslate_tiles
fill 512 205 280 512 308 280 minecraft:deepslate_tiles
fill 512 205 287 512 308 287 minecraft:deepslate_tiles
fill 512 205 313 512 209 313 minecraft:deepslate_tiles
fill 512 205 315 512 220 315 minecraft:deepslate_tiles
setblock 471 206 277 minecraft:cobbled_deepslate
fill 471 206 278 471 209 278 minecraft:deepslate_tiles
setblock 471 206 282 minecraft:cobbled_deepslate
fill 471 206 283 471 209 283 minecraft:deepslate_tiles
setblock 471 206 287 minecraft:cobbled_deepslate
fill 471 206 288 471 209 288 minecraft:deepslate_tiles
setblock 471 206 292 minecraft:cobbled_deepslate
fill 471 206 293 471 209 293 minecraft:deepslate_tiles
setblock 471 206 297 minecraft:cobbled_deepslate
fill 471 206 298 471 209 298 minecraft:deepslate_tiles
setblock 471 206 302 minecraft:cobbled_deepslate
fill 471 206 303 471 209 303 minecraft:deepslate_tiles
fill 471 206 305 471 206 306 minecraft:deepslate_tiles
fill 471 206 309 471 208 309 minecraft:deepslate_tiles
setblock 471 206 312 minecraft:cobbled_deepslate
fill 471 206 313 471 209 313 minecraft:deepslate_tiles
setblock 472 206 276 minecraft:cobbled_deepslate
fill 472 206 277 472 209 277 minecraft:deepslate_tiles
setblock 472 206 281 minecraft:cobbled_deepslate
fill 472 206 282 472 209 282 minecraft:deepslate_tiles
setblock 472 206 286 minecraft:cobbled_deepslate
fill 472 206 287 472 209 287 minecraft:deepslate_tiles
setblock 472 206 291 minecraft:cobbled_deepslate
fill 472 206 292 472 209 292 minecraft:deepslate_tiles
setblock 472 206 296 minecraft:cobbled_deepslate
fill 472 206 297 472 209 297 minecraft:deepslate_tiles
setblock 472 206 301 minecraft:cobbled_deepslate
fill 472 206 302 472 209 302 minecraft:deepslate_tiles
setblock 472 206 312 minecraft:deepslate_tiles
setblock 472 206 316 minecraft:cobbled_deepslate
fill 473 206 276 473 209 276 minecraft:deepslate_tiles
setblock 473 206 280 minecraft:cobbled_deepslate
fill 473 206 281 473 209 281 minecraft:deepslate_tiles
setblock 473 206 284 minecraft:deepslate_tiles
setblock 473 206 290 minecraft:cobbled_deepslate
fill 473 206 291 473 207 291 minecraft:deepslate_tiles
setblock 473 206 295 minecraft:cobbled_deepslate
fill 473 206 296 473 208 296 minecraft:deepslate_tiles
setblock 473 206 299 minecraft:deepslate_tiles
setblock 473 206 315 minecraft:cobbled_deepslate
fill 473 206 316 476 206 316 minecraft:deepslate_tiles
setblock 474 206 278 minecraft:deepslate_tiles
setblock 474 206 279 minecraft:cobbled_deepslate
fill 474 206 280 474 209 280 minecraft:deepslate_tiles
fill 474 206 315 474 209 315 minecraft:deepslate_tiles
setblock 475 206 278 minecraft:cobbled_deepslate
fill 475 206 279 475 209 279 minecraft:deepslate_tiles
setblock 476 206 277 minecraft:cobbled_deepslate
fill 476 206 278 476 209 278 minecraft:deepslate_tiles
setblock 477 206 276 minecraft:cobbled_deepslate
fill 477 206 277 477 209 277 minecraft:deepslate_tiles
setblock 477 206 316 minecraft:cobbled_deepslate
fill 478 206 276 478 209 276 minecraft:deepslate_tiles
setblock 478 206 315 minecraft:cobbled_deepslate
fill 478 206 316 478 209 316 minecraft:deepslate_tiles
setblock 479 206 278 minecraft:deepslate_tiles
fill 479 206 315 482 206 315 minecraft:deepslate_tiles
setblock 480 206 277 minecraft:deepslate_tiles
setblock 481 206 277 minecraft:cobbled_deepslate
setblock 482 206 276 minecraft:cobbled_deepslate
fill 482 206 277 482 209 277 minecraft:deepslate_tiles
setblock 482 206 316 minecraft:cobbled_deepslate
fill 483 206 276 483 209 276 minecraft:deepslate_tiles
setblock 483 206 315 minecraft:cobbled_deepslate
fill 483 206 316 483 209 316 minecraft:deepslate_tiles
fill 484 206 315 484 209 315 minecraft:deepslate_tiles
setblock 486 206 277 minecraft:cobbled_deepslate
fill 486 206 314 486 208 314 minecraft:deepslate_tiles
setblock 487 206 276 minecraft:cobbled_deepslate
fill 487 206 277 490 206 277 minecraft:deepslate_tiles
setblock 487 206 316 minecraft:cobbled_deepslate
fill 488 206 276 488 209 276 minecraft:deepslate_tiles
fill 488 206 278 489 206 278 minecraft:deepslate_tiles
setblock 488 206 315 minecraft:cobbled_deepslate
fill 488 206 316 488 209 316 minecraft:deepslate_tiles
setblock 489 206 314 minecraft:cobbled_deepslate
fill 489 206 315 489 209 315 minecraft:deepslate_tiles
setblock 490 206 278 minecraft:cobbled_deepslate
setblock 490 206 313 minecraft:cobbled_deepslate
fill 490 206 314 490 209 314 minecraft:deepslate_tiles
setblock 491 206 277 minecraft:cobbled_deepslate
fill 491 206 278 491 209 278 minecraft:deepslate_tiles
fill 491 206 313 491 207 313 minecraft:deepslate_tiles
setblock 492 206 276 minecraft:cobbled_deepslate
fill 492 206 277 492 209 277 minecraft:deepslate_tiles
setblock 492 206 316 minecraft:cobbled_deepslate
fill 493 206 276 493 209 276 minecraft:deepslate_tiles
fill 493 206 278 493 207 278 minecraft:deepslate_tiles
setblock 493 206 315 minecraft:cobbled_deepslate
fill 493 206 316 493 209 316 minecraft:deepslate_tiles
setblock 494 206 314 minecraft:cobbled_deepslate
fill 494 206 315 494 209 315 minecraft:deepslate_tiles
fill 495 206 314 495 207 314 minecraft:deepslate_tiles
setblock 496 206 277 minecraft:cobbled_deepslate
setblock 497 206 276 minecraft:cobbled_deepslate
setblock 497 206 277 minecraft:deepslate_tiles
setblock 497 206 316 minecraft:cobbled_deepslate
fill 498 206 276 498 209 276 minecraft:deepslate_tiles
setblock 498 206 315 minecraft:cobbled_deepslate
fill 498 206 316 498 209 316 minecraft:deepslate_tiles
setblock 499 206 315 minecraft:deepslate_tiles
setblock 502 206 316 minecraft:cobbled_deepslate
fill 503 206 316 503 208 316 minecraft:deepslate_tiles
fill 504 206 276 506 206 276 minecraft:deepslate_tiles
setblock 507 206 276 minecraft:cobbled_deepslate
fill 507 206 277 508 208 277 minecraft:deepslate_tiles
setblock 507 206 316 minecraft:cobbled_deepslate
fill 508 206 276 508 209 276 minecraft:deepslate_tiles
setblock 508 206 294 minecraft:deepslate_tiles
setblock 508 206 295 minecraft:cobbled_deepslate
fill 508 206 296 508 209 296 minecraft:deepslate_tiles
fill 508 206 298 508 206 299 minecraft:deepslate_tiles
setblock 508 206 315 minecraft:cobbled_deepslate
fill 508 206 316 508 209 316 minecraft:deepslate_tiles
fill 509 206 290 509 209 290 minecraft:deepslate_tiles
setblock 509 206 294 minecraft:cobbled_deepslate
fill 509 206 295 509 209 295 minecraft:deepslate_tiles
setblock 509 206 299 minecraft:cobbled_deepslate
fill 509 206 300 509 209 300 minecraft:deepslate_tiles
fill 509 206 302 510 206 302 minecraft:deepslate_tiles
fill 509 206 315 509 208 315 minecraft:deepslate_tiles
setblock 510 206 278 minecraft:cobbled_deepslate
fill 510 206 279 510 209 279 minecraft:deepslate_tiles
setblock 510 206 282 minecraft:deepslate_tiles
setblock 510 206 283 minecraft:cobbled_deepslate
fill 510 206 284 510 208 285 minecraft:deepslate_tiles
setblock 510 206 287 minecraft:deepslate_tiles
setblock 510 206 288 minecraft:cobbled_deepslate
fill 510 206 289 510 209 289 minecraft:deepslate_tiles
setblock 510 206 293 minecraft:cobbled_deepslate
fill 510 206 294 510 209 294 minecraft:deepslate_tiles
setblock 510 206 298 minecraft:cobbled_deepslate
fill 510 206 299 510 209 299 minecraft:deepslate_tiles
fill 510 206 301 511 206 301 minecraft:deepslate_tiles
setblock 510 206 303 minecraft:cobbled_deepslate
fill 510 206 304 511 208 304 minecraft:deepslate_tiles
fill 510 206 314 510 208 314 minecraft:deepslate_tiles
setblock 511 206 277 minecraft:cobbled_deepslate
fill 511 206 278 511 209 278 minecraft:deepslate_tiles
setblock 511 206 282 minecraft:cobbled_deepslate
fill 511 206 283 511 209 283 minecraft:deepslate_tiles
setblock 511 206 287 minecraft:cobbled_deepslate
fill 511 206 288 511 209 288 minecraft:deepslate_tiles
setblock 511 206 292 minecraft:cobbled_deepslate
fill 511 206 293 511 209 293 minecraft:deepslate_tiles
setblock 511 206 297 minecraft:cobbled_deepslate
fill 511 206 298 511 209 298 minecraft:deepslate_tiles
setblock 511 206 302 minecraft:cobbled_deepslate
fill 511 206 303 511 209 303 minecraft:deepslate_tiles
fill 511 206 305 511 206 306 minecraft:deepslate_tiles
setblock 511 206 307 minecraft:cobbled_deepslate
fill 511 206 308 511 209 308 minecraft:deepslate_tiles
setblock 511 206 312 minecraft:cobbled_deepslate
fill 511 206 313 511 209 313 minecraft:deepslate_tiles
fill 512 206 277 512 308 277 minecraft:deepslate_tiles
fill 512 206 292 512 269 292 minecraft:deepslate_tiles
fill 470 207 276 470 308 276 minecraft:deepslate_tiles
setblock 471 207 276 minecraft:cobbled_deepslate
fill 471 207 277 471 209 277 minecraft:deepslate_tiles
setblock 471 207 281 minecraft:cobbled_deepslate
fill 471 207 282 471 209 282 minecraft:deepslate_tiles
setblock 471 207 286 minecraft:cobbled_deepslate
fill 471 207 287 471 209 287 minecraft:deepslate_tiles
setblock 471 207 291 minecraft:cobbled_deepslate
fill 471 207 292 471 209 292 minecraft:deepslate_tiles
setblock 471 207 296 minecraft:cobbled_deepslate
fill 471 207 297 471 209 297 minecraft:deepslate_tiles
setblock 471 207 300 minecraft:deepslate_tiles
setblock 471 207 301 minecraft:cobbled_deepslate
fill 471 207 302 471 209 302 minecraft:deepslate_tiles
setblock 471 207 305 minecraft:deepslate_tiles
setblock 471 207 306 minecraft:cobbled_deepslate
fill 471 207 307 471 209 308 minecraft:deepslate_tiles
setblock 471 207 311 minecraft:cobbled_deepslate
fill 471 207 312 471 209 312 minecraft:deepslate_tiles
setblock 471 207 316 minecraft:cobbled_deepslate
fill 472 207 276 472 209 276 minecraft:deepslate_tiles
setblock 472 207 280 minecraft:cobbled_deepslate
fill 472 207 281 472 209 281 minecraft:deepslate_tiles
setblock 472 207 285 minecraft:cobbled_deepslate
fill 472 207 286 472 209 286 minecraft:deepslate_tiles
setblock 472 207 290 minecraft:cobbled_deepslate
fill 472 207 291 472 209 291 minecraft:deepslate_tiles
setblock 472 207 295 minecraft:cobbled_deepslate
fill 472 207 296 472 209 296 minecraft:deepslate_tiles
setblock 472 207 300 minecraft:cobbled_deepslate
fill 472 207 301 472 209 301 minecraft:deepslate_tiles
fill 472 207 303 472 208 303 minecraft:deepslate_tiles
setblock 472 207 315 minecraft:cobbled_deepslate
fill 472 207 316 475 207 316 minecraft:deepslate_tiles
setblock 473 207 279 minecraft:cobbled_deepslate
fill 473 207 280 473 209 280 minecraft:deepslate_tiles
setblock 473 207 284 minecraft:cobbled_deepslate
setblock 473 207 294 minecraft:cobbled_deepslate
fill 473 207 295 473 208 295 minecraft:deepslate_tiles
setblock 473 207 299 minecraft:cobbled_deepslate
fill 473 207 315 473 209 315 minecraft:deepslate_tiles
setblock 474 207 278 minecraft:cobbled_deepslate
fill 474 207 279 474 209 279 minecraft:deepslate_tiles
setblock 475 207 277 minecraft:cobbled_deepslate
schedule function dropper:buildpart/70_9 1t
