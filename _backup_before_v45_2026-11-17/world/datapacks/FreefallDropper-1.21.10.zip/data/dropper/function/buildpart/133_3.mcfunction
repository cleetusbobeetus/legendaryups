setblock 55 93 560 minecraft:calcite
fill 55 93 596 55 96 596 minecraft:cobbled_deepslate
setblock 56 93 559 minecraft:calcite
fill 56 93 560 56 96 560 minecraft:cobbled_deepslate
setblock 57 93 558 minecraft:calcite
fill 57 93 559 57 96 559 minecraft:cobbled_deepslate
setblock 57 93 597 minecraft:cobbled_deepslate
setblock 57 93 598 minecraft:calcite
fill 58 93 558 58 96 558 minecraft:cobbled_deepslate
setblock 58 93 597 minecraft:calcite
fill 58 93 598 58 96 598 minecraft:cobbled_deepslate
setblock 59 93 596 minecraft:calcite
fill 59 93 597 59 96 597 minecraft:cobbled_deepslate
setblock 61 93 598 minecraft:cobbled_deepslate
setblock 62 93 558 minecraft:calcite
setblock 62 93 597 minecraft:cobbled_deepslate
setblock 62 93 598 minecraft:calcite
fill 63 93 558 63 96 558 minecraft:cobbled_deepslate
setblock 63 93 597 minecraft:calcite
fill 63 93 598 66 93 598 minecraft:cobbled_deepslate
fill 64 93 597 67 93 597 minecraft:cobbled_deepslate
fill 65 93 558 66 93 558 minecraft:cobbled_deepslate
setblock 67 93 558 minecraft:calcite
setblock 67 93 598 minecraft:calcite
fill 68 93 558 71 93 558 minecraft:cobbled_deepslate
setblock 68 93 596 minecraft:cobbled_deepslate
setblock 68 93 597 minecraft:calcite
fill 68 93 598 68 96 598 minecraft:cobbled_deepslate
setblock 69 93 596 minecraft:calcite
fill 69 93 597 69 96 597 minecraft:cobbled_deepslate
setblock 70 93 595 minecraft:calcite
fill 70 93 596 73 93 596 minecraft:cobbled_deepslate
fill 71 93 595 74 93 595 minecraft:cobbled_deepslate
setblock 72 93 558 minecraft:calcite
setblock 72 93 598 minecraft:calcite
fill 73 93 558 73 96 558 minecraft:cobbled_deepslate
fill 73 93 594 75 93 594 minecraft:cobbled_deepslate
setblock 73 93 597 minecraft:calcite
fill 73 93 598 73 96 598 minecraft:cobbled_deepslate
setblock 74 93 596 minecraft:calcite
fill 74 93 597 74 96 597 minecraft:cobbled_deepslate
setblock 75 93 595 minecraft:calcite
fill 75 93 596 75 96 596 minecraft:cobbled_deepslate
setblock 76 93 594 minecraft:calcite
fill 76 93 595 76 96 595 minecraft:cobbled_deepslate
setblock 77 93 558 minecraft:calcite
setblock 77 93 598 minecraft:calcite
fill 78 93 558 78 96 558 minecraft:cobbled_deepslate
setblock 78 93 596 minecraft:cobbled_deepslate
setblock 78 93 597 minecraft:calcite
fill 78 93 598 78 96 598 minecraft:cobbled_deepslate
setblock 79 93 595 minecraft:cobbled_deepslate
setblock 79 93 596 minecraft:calcite
fill 79 93 597 79 96 597 minecraft:cobbled_deepslate
fill 80 93 596 80 94 596 minecraft:cobbled_deepslate
setblock 81 93 598 minecraft:cobbled_deepslate
setblock 82 93 598 minecraft:calcite
fill 83 93 598 83 96 598 minecraft:cobbled_deepslate
fill 87 93 569 87 96 569 minecraft:cobbled_deepslate
setblock 87 93 573 minecraft:calcite
fill 87 93 574 87 96 574 minecraft:cobbled_deepslate
fill 87 93 576 87 93 577 minecraft:cobbled_deepslate
setblock 87 93 592 minecraft:cobbled_deepslate
setblock 87 93 593 minecraft:calcite
setblock 88 93 566 minecraft:cobbled_deepslate
setblock 88 93 567 minecraft:calcite
fill 88 93 568 88 96 568 minecraft:cobbled_deepslate
setblock 88 93 572 minecraft:calcite
fill 88 93 573 88 96 573 minecraft:cobbled_deepslate
setblock 88 93 576 minecraft:cobbled_deepslate
setblock 88 93 577 minecraft:calcite
fill 88 93 578 88 93 581 minecraft:cobbled_deepslate
setblock 88 93 582 minecraft:calcite
fill 88 93 583 88 96 583 minecraft:cobbled_deepslate
setblock 88 93 587 minecraft:calcite
fill 88 93 588 88 96 588 minecraft:cobbled_deepslate
setblock 88 93 592 minecraft:calcite
fill 88 93 593 88 96 593 minecraft:cobbled_deepslate
setblock 88 93 597 minecraft:calcite
fill 48 94 558 48 94 560 minecraft:cobbled_deepslate
setblock 48 94 561 minecraft:calcite
fill 48 94 562 48 97 562 minecraft:cobbled_deepslate
setblock 48 94 565 minecraft:cobbled_deepslate
setblock 48 94 566 minecraft:calcite
fill 48 94 567 48 97 567 minecraft:cobbled_deepslate
setblock 48 94 571 minecraft:calcite
fill 48 94 572 48 97 572 minecraft:cobbled_deepslate
setblock 48 94 575 minecraft:cobbled_deepslate
setblock 48 94 576 minecraft:calcite
fill 48 94 577 48 97 577 minecraft:cobbled_deepslate
setblock 48 94 580 minecraft:cobbled_deepslate
setblock 48 94 590 minecraft:cobbled_deepslate
setblock 48 94 591 minecraft:calcite
fill 48 94 592 48 97 592 minecraft:cobbled_deepslate
setblock 48 94 595 minecraft:cobbled_deepslate
setblock 48 94 596 minecraft:calcite
fill 48 94 597 48 96 598 minecraft:cobbled_deepslate
setblock 49 94 565 minecraft:calcite
fill 49 94 566 49 97 566 minecraft:cobbled_deepslate
setblock 49 94 570 minecraft:calcite
fill 49 94 571 49 97 571 minecraft:cobbled_deepslate
setblock 49 94 575 minecraft:calcite
fill 49 94 576 49 97 576 minecraft:cobbled_deepslate
fill 49 94 578 49 95 578 minecraft:cobbled_deepslate
fill 49 94 593 49 94 594 minecraft:cobbled_deepslate
setblock 49 94 595 minecraft:calcite
fill 49 94 598 50 94 598 minecraft:cobbled_deepslate
setblock 50 94 558 minecraft:cobbled_deepslate
setblock 50 94 559 minecraft:calcite
setblock 50 94 569 minecraft:calcite
fill 50 94 570 50 97 570 minecraft:cobbled_deepslate
setblock 50 94 574 minecraft:calcite
fill 50 94 575 50 97 575 minecraft:cobbled_deepslate
fill 50 94 597 51 94 597 minecraft:cobbled_deepslate
setblock 51 94 558 minecraft:calcite
fill 51 94 559 51 97 559 minecraft:cobbled_deepslate
setblock 51 94 568 minecraft:calcite
fill 51 94 569 51 96 569 minecraft:cobbled_deepslate
setblock 51 94 573 minecraft:calcite
fill 51 94 574 51 97 574 minecraft:cobbled_deepslate
setblock 51 94 598 minecraft:calcite
fill 52 94 558 55 94 558 minecraft:cobbled_deepslate
setblock 52 94 596 minecraft:cobbled_deepslate
setblock 52 94 597 minecraft:calcite
fill 52 94 598 52 97 598 minecraft:cobbled_deepslate
setblock 53 94 560 minecraft:cobbled_deepslate
setblock 53 94 596 minecraft:calcite
fill 53 94 597 53 97 597 minecraft:cobbled_deepslate
setblock 54 94 560 minecraft:calcite
fill 54 94 596 54 97 596 minecraft:cobbled_deepslate
setblock 55 94 559 minecraft:calcite
fill 55 94 560 55 97 560 minecraft:cobbled_deepslate
setblock 56 94 558 minecraft:calcite
fill 56 94 559 56 97 559 minecraft:cobbled_deepslate
fill 56 94 596 57 94 596 minecraft:cobbled_deepslate
setblock 56 94 598 minecraft:calcite
fill 57 94 558 57 97 558 minecraft:cobbled_deepslate
setblock 57 94 597 minecraft:calcite
fill 57 94 598 57 97 598 minecraft:cobbled_deepslate
setblock 58 94 596 minecraft:calcite
fill 58 94 597 58 97 597 minecraft:cobbled_deepslate
setblock 59 94 559 minecraft:cobbled_deepslate
fill 59 94 596 60 95 596 minecraft:cobbled_deepslate
setblock 60 94 559 minecraft:calcite
setblock 61 94 558 minecraft:calcite
setblock 61 94 598 minecraft:calcite
fill 62 94 558 62 97 558 minecraft:cobbled_deepslate
setblock 62 94 597 minecraft:calcite
fill 62 94 598 65 94 598 minecraft:cobbled_deepslate
fill 63 94 597 66 94 597 minecraft:cobbled_deepslate
setblock 65 94 558 minecraft:cobbled_deepslate
setblock 66 94 558 minecraft:calcite
fill 66 94 596 67 94 596 minecraft:cobbled_deepslate
setblock 66 94 598 minecraft:calcite
fill 67 94 558 70 94 558 minecraft:cobbled_deepslate
setblock 67 94 597 minecraft:calcite
fill 67 94 598 67 97 598 minecraft:cobbled_deepslate
setblock 68 94 596 minecraft:calcite
fill 68 94 597 68 97 597 minecraft:cobbled_deepslate
setblock 69 94 595 minecraft:calcite
fill 69 94 596 72 94 596 minecraft:cobbled_deepslate
fill 70 94 595 73 94 595 minecraft:cobbled_deepslate
setblock 71 94 558 minecraft:calcite
setblock 71 94 598 minecraft:calcite
fill 72 94 558 72 97 558 minecraft:cobbled_deepslate
fill 72 94 594 74 94 594 minecraft:cobbled_deepslate
setblock 72 94 597 minecraft:calcite
fill 72 94 598 72 97 598 minecraft:cobbled_deepslate
setblock 73 94 596 minecraft:calcite
fill 73 94 597 73 97 597 minecraft:cobbled_deepslate
setblock 74 94 595 minecraft:calcite
fill 74 94 596 74 97 596 minecraft:cobbled_deepslate
setblock 75 94 594 minecraft:calcite
fill 75 94 595 75 97 595 minecraft:cobbled_deepslate
setblock 76 94 558 minecraft:calcite
setblock 76 94 594 minecraft:cobbled_deepslate
setblock 76 94 598 minecraft:calcite
fill 77 94 558 77 97 558 minecraft:cobbled_deepslate
setblock 77 94 597 minecraft:calcite
fill 77 94 598 77 97 598 minecraft:cobbled_deepslate
setblock 78 94 596 minecraft:calcite
fill 78 94 597 78 97 597 minecraft:cobbled_deepslate
fill 79 94 596 79 96 596 minecraft:cobbled_deepslate
setblock 81 94 598 minecraft:calcite
fill 82 94 598 82 97 598 minecraft:cobbled_deepslate
setblock 87 94 571 minecraft:cobbled_deepslate
setblock 87 94 572 minecraft:calcite
fill 87 94 573 87 97 573 minecraft:cobbled_deepslate
setblock 87 94 576 minecraft:cobbled_deepslate
setblock 87 94 577 minecraft:calcite
fill 87 94 578 88 96 578 minecraft:cobbled_deepslate
setblock 87 94 592 minecraft:calcite
fill 87 94 593 87 94 594 minecraft:cobbled_deepslate
setblock 88 94 566 minecraft:calcite
fill 88 94 567 88 97 567 minecraft:cobbled_deepslate
setblock 88 94 571 minecraft:calcite
fill 88 94 572 88 97 572 minecraft:cobbled_deepslate
setblock 88 94 576 minecraft:calcite
fill 88 94 577 88 97 577 minecraft:cobbled_deepslate
fill 88 94 579 88 94 580 minecraft:cobbled_deepslate
setblock 88 94 581 minecraft:calcite
fill 88 94 582 88 97 582 minecraft:cobbled_deepslate
setblock 88 94 586 minecraft:calcite
fill 88 94 587 88 96 587 minecraft:cobbled_deepslate
setblock 88 94 591 minecraft:calcite
fill 88 94 592 88 97 592 minecraft:cobbled_deepslate
fill 88 94 594 88 94 595 minecraft:cobbled_deepslate
setblock 88 94 596 minecraft:calcite
fill 88 94 597 88 96 598 minecraft:cobbled_deepslate
fill 48 95 558 48 95 559 minecraft:cobbled_deepslate
setblock 48 95 560 minecraft:calcite
fill 48 95 561 48 98 561 minecraft:cobbled_deepslate
setblock 48 95 565 minecraft:calcite
fill 48 95 566 48 98 566 minecraft:cobbled_deepslate
setblock 48 95 570 minecraft:calcite
fill 48 95 571 48 98 571 minecraft:cobbled_deepslate
setblock 48 95 575 minecraft:calcite
fill 48 95 576 48 98 576 minecraft:cobbled_deepslate
setblock 48 95 580 minecraft:calcite
fill 48 95 581 48 98 581 minecraft:cobbled_deepslate
setblock 48 95 590 minecraft:calcite
fill 48 95 591 48 96 591 minecraft:cobbled_deepslate
setblock 48 95 595 minecraft:calcite
fill 48 95 596 49 97 596 minecraft:cobbled_deepslate
setblock 49 95 563 minecraft:cobbled_deepslate
setblock 49 95 564 minecraft:calcite
fill 49 95 565 49 98 565 minecraft:cobbled_deepslate
setblock 49 95 569 minecraft:calcite
fill 49 95 570 49 98 570 minecraft:cobbled_deepslate
setblock 49 95 574 minecraft:calcite
fill 49 95 575 49 98 575 minecraft:cobbled_deepslate
setblock 49 95 579 minecraft:calcite
setblock 49 95 593 minecraft:cobbled_deepslate
setblock 49 95 594 minecraft:calcite
fill 49 95 595 49 98 595 minecraft:cobbled_deepslate
fill 49 95 597 49 95 598 minecraft:cobbled_deepslate
setblock 50 95 558 minecraft:calcite
fill 50 95 559 50 98 559 minecraft:cobbled_deepslate
setblock 50 95 568 minecraft:calcite
fill 50 95 569 50 98 569 minecraft:cobbled_deepslate
setblock 50 95 572 minecraft:cobbled_deepslate
setblock 50 95 573 minecraft:calcite
fill 50 95 574 50 98 574 minecraft:cobbled_deepslate
setblock 50 95 577 minecraft:cobbled_deepslate
setblock 50 95 597 minecraft:cobbled_deepslate
setblock 50 95 598 minecraft:calcite
fill 51 95 558 54 95 558 minecraft:cobbled_deepslate
setblock 51 95 568 minecraft:cobbled_deepslate
setblock 51 95 572 minecraft:calcite
fill 51 95 573 51 97 573 minecraft:cobbled_deepslate
fill 51 95 575 51 96 575 minecraft:cobbled_deepslate
setblock 51 95 596 minecraft:cobbled_deepslate
setblock 51 95 597 minecraft:calcite
fill 51 95 598 51 98 598 minecraft:cobbled_deepslate
setblock 52 95 560 minecraft:cobbled_deepslate
setblock 52 95 596 minecraft:calcite
fill 52 95 597 52 98 597 minecraft:cobbled_deepslate
setblock 53 95 560 minecraft:calcite
fill 53 95 596 53 98 596 minecraft:cobbled_deepslate
setblock 54 95 559 minecraft:calcite
fill 54 95 560 54 98 560 minecraft:cobbled_deepslate
setblock 55 95 558 minecraft:calcite
fill 55 95 559 55 98 559 minecraft:cobbled_deepslate
setblock 55 95 598 minecraft:calcite
fill 56 95 558 56 98 558 minecraft:cobbled_deepslate
setblock 56 95 596 minecraft:cobbled_deepslate
setblock 56 95 597 minecraft:calcite
fill 56 95 598 56 98 598 minecraft:cobbled_deepslate
setblock 57 95 596 minecraft:calcite
fill 57 95 597 57 98 597 minecraft:cobbled_deepslate
fill 58 95 596 58 97 596 minecraft:cobbled_deepslate
setblock 59 95 559 minecraft:calcite
setblock 60 95 558 minecraft:calcite
setblock 60 95 559 minecraft:cobbled_deepslate
setblock 60 95 598 minecraft:calcite
fill 61 95 558 61 98 558 minecraft:cobbled_deepslate
setblock 61 95 597 minecraft:calcite
fill 61 95 598 64 95 598 minecraft:cobbled_deepslate
fill 62 95 597 65 95 597 minecraft:cobbled_deepslate
setblock 65 95 558 minecraft:calcite
fill 65 95 596 66 95 596 minecraft:cobbled_deepslate
setblock 65 95 598 minecraft:calcite
fill 66 95 558 69 95 558 minecraft:cobbled_deepslate
setblock 66 95 597 minecraft:calcite
fill 66 95 598 66 98 598 minecraft:cobbled_deepslate
setblock 67 95 596 minecraft:calcite
fill 67 95 597 67 98 597 minecraft:cobbled_deepslate
fill 68 95 596 71 95 596 minecraft:cobbled_deepslate
fill 69 95 595 72 95 595 minecraft:cobbled_deepslate
setblock 70 95 558 minecraft:calcite
setblock 70 95 598 minecraft:calcite
fill 71 95 558 71 98 558 minecraft:cobbled_deepslate
setblock 71 95 597 minecraft:calcite
fill 71 95 598 71 98 598 minecraft:cobbled_deepslate
fill 72 95 559 73 95 559 minecraft:cobbled_deepslate
fill 72 95 594 73 95 594 minecraft:cobbled_deepslate
setblock 72 95 596 minecraft:calcite
fill 72 95 597 72 98 597 minecraft:cobbled_deepslate
setblock 73 95 595 minecraft:calcite
fill 73 95 596 73 98 596 minecraft:cobbled_deepslate
setblock 74 95 594 minecraft:calcite
fill 74 95 595 74 98 595 minecraft:cobbled_deepslate
setblock 75 95 558 minecraft:calcite
setblock 75 95 594 minecraft:cobbled_deepslate
setblock 75 95 598 minecraft:calcite
fill 76 95 558 76 98 558 minecraft:cobbled_deepslate
setblock 76 95 597 minecraft:calcite
fill 76 95 598 76 98 598 minecraft:cobbled_deepslate
setblock 77 95 596 minecraft:calcite
fill 77 95 597 77 98 597 minecraft:cobbled_deepslate
setblock 78 95 595 minecraft:calcite
fill 78 95 596 78 97 596 minecraft:cobbled_deepslate
setblock 80 95 598 minecraft:calcite
setblock 81 95 597 minecraft:calcite
fill 81 95 598 81 98 598 minecraft:cobbled_deepslate
fill 86 95 573 86 96 575 minecraft:cobbled_deepslate
setblock 87 95 571 minecraft:calcite
fill 87 95 572 87 98 572 minecraft:cobbled_deepslate
setblock 87 95 575 minecraft:cobbled_deepslate
setblock 87 95 576 minecraft:calcite
fill 87 95 577 87 98 577 minecraft:cobbled_deepslate
fill 87 95 579 88 95 579 minecraft:cobbled_deepslate
setblock 87 95 593 minecraft:cobbled_deepslate
fill 87 95 598 87 97 598 minecraft:cobbled_deepslate
fill 88 95 566 88 98 566 minecraft:cobbled_deepslate
setblock 88 95 570 minecraft:calcite
fill 88 95 571 88 98 571 minecraft:cobbled_deepslate
setblock 88 95 575 minecraft:calcite
fill 88 95 576 88 98 576 minecraft:cobbled_deepslate
setblock 88 95 580 minecraft:calcite
fill 88 95 581 88 98 581 minecraft:cobbled_deepslate
setblock 88 95 585 minecraft:calcite
fill 88 95 586 88 96 586 minecraft:cobbled_deepslate
setblock 88 95 590 minecraft:calcite
fill 88 95 591 88 98 591 minecraft:cobbled_deepslate
setblock 88 95 594 minecraft:cobbled_deepslate
setblock 88 95 595 minecraft:calcite
fill 88 95 596 88 98 596 minecraft:cobbled_deepslate
setblock 48 96 558 minecraft:cobbled_deepslate
setblock 48 96 559 minecraft:calcite
fill 48 96 560 49 98 560 minecraft:cobbled_deepslate
setblock 48 96 564 minecraft:calcite
fill 48 96 565 48 99 565 minecraft:cobbled_deepslate
setblock 48 96 569 minecraft:calcite
fill 48 96 570 48 99 570 minecraft:cobbled_deepslate
setblock 48 96 574 minecraft:calcite
fill 48 96 575 48 99 575 minecraft:cobbled_deepslate
setblock 48 96 578 minecraft:cobbled_deepslate
setblock 48 96 579 minecraft:calcite
fill 48 96 580 48 99 580 minecraft:cobbled_deepslate
setblock 48 96 594 minecraft:calcite
fill 48 96 595 48 99 595 minecraft:cobbled_deepslate
setblock 49 96 558 minecraft:calcite
fill 49 96 559 49 99 559 minecraft:cobbled_deepslate
fill 49 96 561 49 96 562 minecraft:cobbled_deepslate
setblock 49 96 563 minecraft:calcite
fill 49 96 564 49 99 564 minecraft:cobbled_deepslate
setblock 49 96 568 minecraft:calcite
fill 49 96 569 49 99 569 minecraft:cobbled_deepslate
setblock 49 96 573 minecraft:calcite
fill 49 96 574 49 99 574 minecraft:cobbled_deepslate
setblock 49 96 578 minecraft:calcite
fill 49 96 579 49 99 579 minecraft:cobbled_deepslate
setblock 49 96 593 minecraft:calcite
fill 49 96 594 49 98 594 minecraft:cobbled_deepslate
setblock 49 96 597 minecraft:cobbled_deepslate
setblock 49 96 598 minecraft:calcite
fill 50 96 558 53 96 558 minecraft:cobbled_deepslate
setblock 50 96 567 minecraft:calcite
fill 50 96 568 50 97 568 minecraft:cobbled_deepslate
setblock 50 96 572 minecraft:calcite
fill 50 96 573 50 99 573 minecraft:cobbled_deepslate
setblock 50 96 577 minecraft:calcite
setblock 50 96 597 minecraft:calcite
fill 50 96 598 50 99 598 minecraft:cobbled_deepslate
setblock 51 96 571 minecraft:calcite
fill 51 96 572 51 97 572 minecraft:cobbled_deepslate
setblock 51 96 596 minecraft:calcite
fill 51 96 597 51 99 597 minecraft:cobbled_deepslate
setblock 52 96 560 minecraft:calcite
fill 52 96 596 52 99 596 minecraft:cobbled_deepslate
setblock 53 96 559 minecraft:calcite
fill 53 96 560 53 99 560 minecraft:cobbled_deepslate
fill 53 96 573 54 96 574 minecraft:diamond_block
setblock 54 96 558 minecraft:calcite
fill 54 96 559 54 99 559 minecraft:cobbled_deepslate
fill 54 96 572 55 97 572 minecraft:diamond_block
fill 54 96 575 55 96 576 minecraft:diamond_block
setblock 54 96 598 minecraft:calcite
fill 55 96 558 55 99 558 minecraft:cobbled_deepslate
fill 55 96 571 59 96 571 minecraft:diamond_block
fill 55 96 577 58 96 577 minecraft:diamond_block
setblock 55 96 597 minecraft:calcite
fill 55 96 598 55 99 598 minecraft:cobbled_deepslate
fill 56 96 576 59 96 576 minecraft:diamond_block
setblock 56 96 596 minecraft:calcite
fill 56 96 597 56 99 597 minecraft:cobbled_deepslate
fill 57 96 596 57 97 596 minecraft:cobbled_deepslate
setblock 58 96 559 minecraft:calcite
fill 58 96 572 59 97 572 minecraft:diamond_block
setblock 59 96 558 minecraft:calcite
fill 59 96 559 59 97 559 minecraft:cobbled_deepslate
fill 59 96 573 60 96 575 minecraft:diamond_block
setblock 59 96 596 minecraft:cobbled_deepslate
setblock 59 96 598 minecraft:calcite
fill 60 96 558 60 99 558 minecraft:cobbled_deepslate
setblock 60 96 597 minecraft:calcite
fill 60 96 598 63 96 598 minecraft:cobbled_deepslate
fill 61 96 597 64 96 597 minecraft:cobbled_deepslate
fill 63 96 585 63 96 587 minecraft:diamond_block
setblock 64 96 558 minecraft:calcite
fill 64 96 584 66 96 584 minecraft:diamond_block
fill 64 96 587 66 96 587 minecraft:diamond_block
setblock 64 96 598 minecraft:calcite
fill 65 96 558 68 96 558 minecraft:cobbled_deepslate
setblock 65 96 596 minecraft:cobbled_deepslate
setblock 65 96 597 minecraft:calcite
fill 65 96 598 65 99 598 minecraft:cobbled_deepslate
fill 66 96 585 66 97 586 minecraft:diamond_block
setblock 66 96 596 minecraft:calcite
fill 66 96 597 66 99 597 minecraft:cobbled_deepslate
fill 67 96 596 70 96 596 minecraft:cobbled_deepslate
fill 68 96 595 71 96 595 minecraft:cobbled_deepslate
setblock 69 96 558 minecraft:calcite
setblock 69 96 598 minecraft:calcite
fill 70 96 558 70 99 558 minecraft:cobbled_deepslate
setblock 70 96 597 minecraft:calcite
fill 70 96 598 70 99 598 minecraft:cobbled_deepslate
fill 71 96 559 72 96 559 minecraft:cobbled_deepslate
setblock 71 96 596 minecraft:calcite
fill 71 96 597 71 99 597 minecraft:cobbled_deepslate
setblock 72 96 594 minecraft:cobbled_deepslate
setblock 72 96 595 minecraft:calcite
fill 72 96 596 72 99 596 minecraft:cobbled_deepslate
setblock 73 96 559 minecraft:calcite
setblock 73 96 594 minecraft:calcite
fill 73 96 595 73 98 595 minecraft:cobbled_deepslate
setblock 74 96 558 minecraft:calcite
setblock 74 96 594 minecraft:cobbled_deepslate
setblock 74 96 598 minecraft:calcite
fill 75 96 558 75 99 558 minecraft:cobbled_deepslate
setblock 75 96 597 minecraft:calcite
fill 75 96 598 75 99 598 minecraft:cobbled_deepslate
setblock 76 96 596 minecraft:calcite
fill 76 96 597 76 99 597 minecraft:cobbled_deepslate
fill 77 96 579 78 96 580 minecraft:diamond_block
setblock 77 96 595 minecraft:calcite
fill 77 96 596 77 98 596 minecraft:cobbled_deepslate
fill 78 96 577 79 96 578 minecraft:diamond_block
fill 78 96 581 79 96 582 minecraft:diamond_block
fill 79 96 576 83 96 576 minecraft:diamond_block
fill 79 96 583 83 96 583 minecraft:diamond_block
setblock 79 96 598 minecraft:calcite
fill 80 96 577 84 96 577 minecraft:diamond_block
fill 80 96 582 84 96 582 minecraft:diamond_block
setblock 80 96 597 minecraft:calcite
fill 80 96 598 80 99 598 minecraft:cobbled_deepslate
fill 83 96 578 84 97 578 minecraft:diamond_block
fill 83 96 581 84 97 581 minecraft:diamond_block
fill 84 96 579 85 96 580 minecraft:diamond_block
setblock 86 96 576 minecraft:calcite
fill 86 96 598 86 98 598 minecraft:cobbled_deepslate
setblock 87 96 570 minecraft:calcite
fill 87 96 571 87 99 571 minecraft:cobbled_deepslate
setblock 87 96 575 minecraft:calcite
fill 87 96 576 87 99 576 minecraft:cobbled_deepslate
setblock 87 96 579 minecraft:cobbled_deepslate
setblock 87 96 580 minecraft:calcite
setblock 88 96 569 minecraft:calcite
fill 88 96 570 88 99 570 minecraft:cobbled_deepslate
setblock 88 96 574 minecraft:calcite
fill 88 96 575 88 99 575 minecraft:cobbled_deepslate
setblock 88 96 579 minecraft:calcite
fill 88 96 580 88 99 580 minecraft:cobbled_deepslate
setblock 88 96 584 minecraft:calcite
fill 88 96 585 88 97 585 minecraft:cobbled_deepslate
setblock 88 96 589 minecraft:calcite
fill 88 96 590 88 97 590 minecraft:cobbled_deepslate
setblock 88 96 594 minecraft:calcite
fill 88 96 595 88 99 595 minecraft:cobbled_deepslate
setblock 48 97 558 minecraft:calcite
fill 48 97 559 48 99 559 minecraft:cobbled_deepslate
setblock 48 97 563 minecraft:calcite
fill 48 97 564 48 99 564 minecraft:cobbled_deepslate
setblock 48 97 568 minecraft:calcite
fill 48 97 569 48 99 569 minecraft:cobbled_deepslate
setblock 48 97 573 minecraft:calcite
fill 48 97 574 48 99 574 minecraft:cobbled_deepslate
setblock 48 97 578 minecraft:calcite
fill 48 97 579 48 99 579 minecraft:cobbled_deepslate
setblock 48 97 593 minecraft:calcite
fill 48 97 594 48 99 594 minecraft:cobbled_deepslate
setblock 48 97 597 minecraft:cobbled_deepslate
setblock 48 97 598 minecraft:calcite
fill 49 97 558 52 97 558 minecraft:cobbled_deepslate
setblock 49 97 561 minecraft:cobbled_deepslate
setblock 49 97 562 minecraft:calcite
fill 49 97 563 49 99 563 minecraft:cobbled_deepslate
setblock 49 97 567 minecraft:calcite
fill 49 97 568 49 99 568 minecraft:cobbled_deepslate
setblock 49 97 572 minecraft:calcite
fill 49 97 573 49 99 573 minecraft:cobbled_deepslate
setblock 49 97 577 minecraft:calcite
fill 49 97 578 50 97 578 minecraft:cobbled_deepslate
setblock 49 97 597 minecraft:calcite
fill 49 97 598 49 99 598 minecraft:cobbled_deepslate
setblock 50 97 567 minecraft:cobbled_deepslate
setblock 50 97 571 minecraft:calcite
fill 50 97 572 50 99 572 minecraft:cobbled_deepslate
setblock 50 97 576 minecraft:calcite
fill 50 97 577 50 99 577 minecraft:cobbled_deepslate
fill 50 97 597 50 99 597 minecraft:cobbled_deepslate
setblock 51 97 560 minecraft:calcite
setblock 51 97 571 minecraft:cobbled_deepslate
setblock 51 97 575 minecraft:calcite
fill 51 97 596 51 98 596 minecraft:cobbled_deepslate
setblock 52 97 559 minecraft:calcite
fill 52 97 560 52 99 560 minecraft:cobbled_deepslate
setblock 53 97 558 minecraft:calcite
fill 53 97 559 53 99 559 minecraft:cobbled_deepslate
setblock 53 97 598 minecraft:calcite
fill 54 97 558 54 99 558 minecraft:cobbled_deepslate
fill 54 97 573 54 97 575 minecraft:diamond_block
setblock 54 97 597 minecraft:calcite
fill 54 97 598 54 99 598 minecraft:cobbled_deepslate
fill 55 97 575 55 97 576 minecraft:diamond_block
setblock 55 97 596 minecraft:calcite
fill 55 97 597 55 99 597 minecraft:cobbled_deepslate
fill 56 97 571 58 97 571 minecraft:diamond_block
fill 56 97 576 58 97 576 minecraft:diamond_block
fill 56 97 596 56 98 596 minecraft:cobbled_deepslate
setblock 57 97 559 minecraft:calcite
setblock 58 97 558 minecraft:calcite
fill 58 97 559 58 99 559 minecraft:cobbled_deepslate
setblock 58 97 598 minecraft:calcite
fill 59 97 558 59 99 558 minecraft:cobbled_deepslate
fill 59 97 573 59 97 575 minecraft:diamond_block
setblock 59 97 597 minecraft:calcite
fill 59 97 598 62 97 598 minecraft:cobbled_deepslate
fill 60 97 597 63 97 597 minecraft:cobbled_deepslate
setblock 63 97 558 minecraft:calcite
fill 63 97 585 63 97 586 minecraft:diamond_block
setblock 63 97 598 minecraft:calcite
fill 64 97 558 67 97 558 minecraft:cobbled_deepslate
fill 64 97 584 65 97 584 minecraft:diamond_block
fill 64 97 587 65 98 587 minecraft:diamond_block
setblock 64 97 597 minecraft:calcite
fill 64 97 598 64 99 598 minecraft:cobbled_deepslate
setblock 65 97 596 minecraft:calcite
fill 65 97 597 65 99 597 minecraft:cobbled_deepslate
fill 66 97 596 69 97 596 minecraft:cobbled_deepslate
setblock 68 97 558 minecraft:calcite
setblock 68 97 598 minecraft:calcite
fill 69 97 558 69 99 558 minecraft:cobbled_deepslate
fill 69 97 595 70 97 595 minecraft:cobbled_deepslate
setblock 69 97 597 minecraft:calcite
fill 69 97 598 69 99 598 minecraft:cobbled_deepslate
setblock 70 97 596 minecraft:calcite
fill 70 97 597 70 99 597 minecraft:cobbled_deepslate
setblock 71 97 559 minecraft:cobbled_deepslate
setblock 71 97 595 minecraft:calcite
fill 71 97 596 71 99 596 minecraft:cobbled_deepslate
setblock 72 97 559 minecraft:calcite
fill 72 97 595 72 99 595 minecraft:cobbled_deepslate
setblock 73 97 558 minecraft:calcite
setblock 73 97 598 minecraft:calcite
fill 74 97 558 74 99 558 minecraft:cobbled_deepslate
setblock 74 97 597 minecraft:calcite
fill 74 97 598 74 99 598 minecraft:cobbled_deepslate
setblock 75 97 596 minecraft:calcite
fill 75 97 597 75 99 597 minecraft:cobbled_deepslate
setblock 76 97 595 minecraft:calcite
fill 76 97 596 76 98 596 minecraft:cobbled_deepslate
fill 78 97 578 78 97 581 minecraft:diamond_block
setblock 78 97 598 minecraft:calcite
fill 79 97 577 79 97 578 minecraft:diamond_block
fill 79 97 581 79 97 582 minecraft:diamond_block
setblock 79 97 597 minecraft:calcite
fill 79 97 598 79 99 598 minecraft:cobbled_deepslate
fill 80 97 577 83 97 577 minecraft:diamond_block
fill 80 97 582 83 97 582 minecraft:diamond_block
setblock 80 97 597 minecraft:cobbled_deepslate
fill 84 97 579 84 97 580 minecraft:diamond_block
fill 86 97 573 86 97 574 minecraft:cobbled_deepslate
setblock 86 97 575 minecraft:calcite
fill 86 97 576 86 99 576 minecraft:cobbled_deepslate
setblock 87 97 569 minecraft:calcite
fill 87 97 570 87 99 570 minecraft:cobbled_deepslate
setblock 87 97 574 minecraft:calcite
fill 87 97 575 87 99 575 minecraft:cobbled_deepslate
setblock 87 97 578 minecraft:cobbled_deepslate
setblock 87 97 579 minecraft:calcite
fill 87 97 580 87 99 580 minecraft:cobbled_deepslate
setblock 88 97 558 minecraft:calcite
setblock 88 97 568 minecraft:calcite
fill 88 97 569 88 99 569 minecraft:cobbled_deepslate
setblock 88 97 573 minecraft:calcite
fill 88 97 574 88 99 574 minecraft:cobbled_deepslate
setblock 88 97 578 minecraft:calcite
fill 88 97 579 88 99 579 minecraft:cobbled_deepslate
setblock 88 97 583 minecraft:calcite
fill 88 97 584 88 99 584 minecraft:cobbled_deepslate
setblock 88 97 589 minecraft:cobbled_deepslate
setblock 88 97 593 minecraft:calcite
fill 88 97 594 88 99 594 minecraft:cobbled_deepslate
setblock 88 97 597 minecraft:cobbled_deepslate
setblock 88 97 598 minecraft:calcite
fill 48 98 558 51 98 558 minecraft:cobbled_deepslate
setblock 48 98 562 minecraft:calcite
fill 48 98 563 48 99 563 minecraft:cobbled_deepslate
setblock 48 98 567 minecraft:calcite
fill 48 98 568 48 99 568 minecraft:cobbled_deepslate
setblock 48 98 572 minecraft:calcite
fill 48 98 573 48 99 573 minecraft:cobbled_deepslate
setblock 48 98 577 minecraft:calcite
fill 48 98 578 49 99 578 minecraft:cobbled_deepslate
setblock 48 98 592 minecraft:calcite
fill 48 98 593 48 99 593 minecraft:cobbled_deepslate
setblock 48 98 596 minecraft:cobbled_deepslate
setblock 48 98 597 minecraft:calcite
fill 48 98 598 48 99 598 minecraft:cobbled_deepslate
setblock 49 98 561 minecraft:calcite
fill 49 98 562 49 99 562 minecraft:cobbled_deepslate
setblock 49 98 566 minecraft:calcite
fill 49 98 567 49 99 567 minecraft:cobbled_deepslate
setblock 49 98 571 minecraft:calcite
fill 49 98 572 49 99 572 minecraft:cobbled_deepslate
setblock 49 98 576 minecraft:calcite
fill 49 98 577 49 99 577 minecraft:cobbled_deepslate
setblock 49 98 580 minecraft:cobbled_deepslate
setblock 49 98 596 minecraft:calcite
fill 49 98 597 49 99 597 minecraft:cobbled_deepslate
setblock 50 98 570 minecraft:calcite
fill 50 98 571 50 99 571 minecraft:cobbled_deepslate
setblock 50 98 575 minecraft:calcite
fill 50 98 576 50 99 576 minecraft:cobbled_deepslate
setblock 51 98 559 minecraft:calcite
fill 51 98 560 51 99 560 minecraft:cobbled_deepslate
setblock 52 98 558 minecraft:calcite
fill 52 98 559 52 99 559 minecraft:cobbled_deepslate
setblock 52 98 598 minecraft:calcite
fill 53 98 558 53 99 558 minecraft:cobbled_deepslate
setblock 53 98 597 minecraft:calcite
fill 53 98 598 53 99 598 minecraft:cobbled_deepslate
setblock 54 98 596 minecraft:calcite
fill 54 98 597 54 99 597 minecraft:cobbled_deepslate
setblock 55 98 572 minecraft:diamond_block
setblock 55 98 575 minecraft:diamond_block
setblock 55 98 596 minecraft:cobbled_deepslate
setblock 56 98 559 minecraft:calcite
fill 56 98 576 57 98 576 minecraft:diamond_block
setblock 57 98 558 minecraft:calcite
fill 57 98 559 57 99 559 minecraft:cobbled_deepslate
setblock 57 98 598 minecraft:calcite
fill 58 98 558 58 99 558 minecraft:cobbled_deepslate
setblock 58 98 572 minecraft:diamond_block
setblock 58 98 597 minecraft:calcite
fill 58 98 598 61 98 598 minecraft:cobbled_deepslate
setblock 59 98 574 minecraft:diamond_block
fill 59 98 597 62 98 597 minecraft:cobbled_deepslate
setblock 62 98 558 minecraft:calcite
setblock 62 98 598 minecraft:calcite
fill 63 98 558 66 98 558 minecraft:cobbled_deepslate
setblock 63 98 586 minecraft:diamond_block
setblock 63 98 597 minecraft:calcite
fill 63 98 598 63 99 598 minecraft:cobbled_deepslate
fill 64 98 597 64 99 597 minecraft:cobbled_deepslate
setblock 66 98 586 minecraft:diamond_block
fill 66 98 596 68 98 596 minecraft:cobbled_deepslate
setblock 67 98 558 minecraft:calcite
setblock 67 98 598 minecraft:calcite
fill 68 98 558 68 99 558 minecraft:cobbled_deepslate
setblock 68 98 597 minecraft:calcite
fill 68 98 598 68 99 598 minecraft:cobbled_deepslate
setblock 69 98 595 minecraft:cobbled_deepslate
setblock 69 98 596 minecraft:calcite
fill 69 98 597 69 99 597 minecraft:cobbled_deepslate
setblock 70 98 559 minecraft:cobbled_deepslate
setblock 70 98 595 minecraft:calcite
fill 70 98 596 70 99 596 minecraft:cobbled_deepslate
setblock 71 98 559 minecraft:calcite
fill 71 98 595 71 99 595 minecraft:cobbled_deepslate
setblock 72 98 558 minecraft:calcite
setblock 72 98 559 minecraft:cobbled_deepslate
setblock 72 98 598 minecraft:calcite
fill 73 98 558 73 99 558 minecraft:cobbled_deepslate
setblock 73 98 597 minecraft:calcite
fill 73 98 598 73 99 598 minecraft:cobbled_deepslate
setblock 74 98 596 minecraft:calcite
fill 74 98 597 74 99 597 minecraft:cobbled_deepslate
fill 75 98 596 75 99 596 minecraft:cobbled_deepslate
setblock 77 98 598 minecraft:calcite
setblock 78 98 597 minecraft:calcite
fill 78 98 598 78 99 598 minecraft:cobbled_deepslate
setblock 79 98 578 minecraft:diamond_block
setblock 79 98 581 minecraft:diamond_block
fill 80 98 577 82 98 577 minecraft:diamond_block
fill 80 98 582 82 98 582 minecraft:diamond_block
setblock 83 98 578 minecraft:diamond_block
setblock 83 98 581 minecraft:diamond_block
setblock 86 98 574 minecraft:calcite
fill 86 98 575 86 99 575 minecraft:cobbled_deepslate
fill 86 98 577 86 99 577 minecraft:cobbled_deepslate
setblock 87 98 573 minecraft:calcite
fill 87 98 574 87 99 574 minecraft:cobbled_deepslate
setblock 87 98 578 minecraft:calcite
fill 87 98 579 87 99 579 minecraft:cobbled_deepslate
fill 87 98 581 87 99 581 minecraft:cobbled_deepslate
setblock 87 98 598 minecraft:calcite
fill 88 98 558 88 99 559 minecraft:cobbled_deepslate
setblock 88 98 567 minecraft:calcite
fill 88 98 568 88 99 568 minecraft:cobbled_deepslate
setblock 88 98 572 minecraft:calcite
fill 88 98 573 88 99 573 minecraft:cobbled_deepslate
setblock 88 98 577 minecraft:calcite
fill 88 98 578 88 99 578 minecraft:cobbled_deepslate
setblock 88 98 582 minecraft:calcite
fill 88 98 583 88 99 583 minecraft:cobbled_deepslate
setblock 88 98 592 minecraft:calcite
fill 88 98 593 88 99 593 minecraft:cobbled_deepslate
setblock 88 98 597 minecraft:calcite
fill 88 98 598 88 99 598 minecraft:cobbled_deepslate
fill 48 99 558 50 99 558 minecraft:cobbled_deepslate
setblock 48 99 560 minecraft:cobbled_deepslate
setblock 48 99 561 minecraft:calcite
setblock 48 99 562 minecraft:cobbled_deepslate
setblock 48 99 566 minecraft:calcite
setblock 48 99 567 minecraft:cobbled_deepslate
setblock 48 99 571 minecraft:calcite
setblock 48 99 572 minecraft:cobbled_deepslate
setblock 48 99 576 minecraft:calcite
setblock 48 99 577 minecraft:cobbled_deepslate
setblock 48 99 581 minecraft:calcite
setblock 48 99 582 minecraft:cobbled_deepslate
setblock 48 99 596 minecraft:calcite
setblock 48 99 597 minecraft:cobbled_deepslate
setblock 49 99 560 minecraft:calcite
setblock 49 99 561 minecraft:cobbled_deepslate
setblock 49 99 565 minecraft:calcite
setblock 49 99 566 minecraft:cobbled_deepslate
setblock 49 99 570 minecraft:calcite
setblock 49 99 571 minecraft:cobbled_deepslate
setblock 49 99 575 minecraft:calcite
setblock 49 99 576 minecraft:cobbled_deepslate
setblock 49 99 580 minecraft:calcite
setblock 49 99 595 minecraft:calcite
setblock 49 99 596 minecraft:cobbled_deepslate
setblock 50 99 559 minecraft:calcite
setblock 50 99 560 minecraft:cobbled_deepslate
setblock 50 99 574 minecraft:calcite
setblock 50 99 575 minecraft:cobbled_deepslate
setblock 51 99 558 minecraft:calcite
setblock 51 99 559 minecraft:cobbled_deepslate
setblock 51 99 598 minecraft:calcite
setblock 52 99 558 minecraft:cobbled_deepslate
setblock 52 99 597 minecraft:calcite
setblock 52 99 598 minecraft:cobbled_deepslate
setblock 53 99 596 minecraft:calcite
setblock 53 99 597 minecraft:cobbled_deepslate
setblock 54 99 560 minecraft:calcite
setblock 54 99 596 minecraft:cobbled_deepslate
setblock 55 99 559 minecraft:calcite
setblock 56 99 558 minecraft:calcite
setblock 56 99 559 minecraft:cobbled_deepslate
setblock 56 99 598 minecraft:calcite
setblock 57 99 558 minecraft:cobbled_deepslate
setblock 57 99 597 minecraft:calcite
fill 57 99 598 60 99 598 minecraft:cobbled_deepslate
fill 58 99 597 61 99 597 minecraft:cobbled_deepslate
setblock 61 99 558 minecraft:calcite
setblock 61 99 598 minecraft:calcite
fill 62 99 558 65 99 558 minecraft:cobbled_deepslate
setblock 62 99 597 minecraft:calcite
setblock 62 99 598 minecraft:cobbled_deepslate
setblock 63 99 597 minecraft:cobbled_deepslate
setblock 66 99 558 minecraft:calcite
fill 66 99 596 67 99 596 minecraft:cobbled_deepslate
setblock 66 99 598 minecraft:calcite
setblock 67 99 558 minecraft:cobbled_deepslate
setblock 67 99 597 minecraft:calcite
setblock 67 99 598 minecraft:cobbled_deepslate
setblock 68 99 596 minecraft:calcite
setblock 68 99 597 minecraft:cobbled_deepslate
setblock 69 99 596 minecraft:cobbled_deepslate
setblock 70 99 559 minecraft:calcite
setblock 70 99 595 minecraft:cobbled_deepslate
setblock 71 99 558 minecraft:calcite
setblock 71 99 559 minecraft:cobbled_deepslate
setblock 71 99 598 minecraft:calcite
setblock 72 99 558 minecraft:cobbled_deepslate
setblock 72 99 597 minecraft:calcite
setblock 72 99 598 minecraft:cobbled_deepslate
setblock 73 99 596 minecraft:calcite
setblock 73 99 597 minecraft:cobbled_deepslate
setblock 74 99 596 minecraft:cobbled_deepslate
setblock 76 99 558 minecraft:calcite
setblock 76 99 598 minecraft:calcite
setblock 77 99 597 minecraft:calcite
setblock 77 99 598 minecraft:cobbled_deepslate
setblock 86 99 598 minecraft:calcite
setblock 87 99 558 minecraft:cobbled_deepslate
setblock 87 99 572 minecraft:calcite
setblock 87 99 573 minecraft:cobbled_deepslate
setblock 87 99 577 minecraft:calcite
setblock 87 99 578 minecraft:cobbled_deepslate
setblock 87 99 598 minecraft:cobbled_deepslate
setblock 88 99 560 minecraft:cobbled_deepslate
setblock 88 99 561 minecraft:calcite
setblock 88 99 566 minecraft:calcite
setblock 88 99 567 minecraft:cobbled_deepslate
setblock 88 99 571 minecraft:calcite
setblock 88 99 572 minecraft:cobbled_deepslate
setblock 88 99 576 minecraft:calcite
setblock 88 99 577 minecraft:cobbled_deepslate
setblock 88 99 581 minecraft:calcite
setblock 88 99 582 minecraft:cobbled_deepslate
setblock 88 99 596 minecraft:calcite
setblock 88 99 597 minecraft:cobbled_deepslate
setblock 50 100 560 minecraft:light[level=14]
setblock 50 100 568 minecraft:light[level=14]
setblock 50 100 576 minecraft:light[level=14]
setblock 50 100 584 minecraft:light[level=14]
setblock 50 100 592 minecraft:light[level=14]
setblock 58 100 560 minecraft:light[level=14]
setblock 58 100 568 minecraft:light[level=14]
setblock 58 100 576 minecraft:light[level=14]
setblock 58 100 584 minecraft:light[level=14]
setblock 58 100 592 minecraft:light[level=14]
setblock 66 100 560 minecraft:light[level=14]
setblock 66 100 568 minecraft:light[level=14]
setblock 66 100 576 minecraft:light[level=14]
setblock 66 100 584 minecraft:light[level=14]
setblock 66 100 592 minecraft:light[level=14]
fill 68 100 576 69 100 579 minecraft:sea_lantern
setblock 70 100 576 minecraft:sea_lantern
fill 70 100 578 70 100 579 minecraft:sea_lantern
setblock 71 100 579 minecraft:sea_lantern
setblock 74 100 560 minecraft:light[level=14]
setblock 74 100 568 minecraft:light[level=14]
setblock 74 100 576 minecraft:light[level=14]
setblock 74 100 584 minecraft:light[level=14]
setblock 74 100 592 minecraft:light[level=14]
setblock 82 100 560 minecraft:light[level=14]
setblock 82 100 568 minecraft:light[level=14]
setblock 82 100 576 minecraft:light[level=14]
setblock 82 100 584 minecraft:light[level=14]
setblock 82 100 592 minecraft:light[level=14]
fill 66 101 576 67 101 579 minecraft:sea_lantern
fill 67 101 575 72 101 575 minecraft:sea_lantern
fill 67 101 580 72 101 580 minecraft:sea_lantern
fill 68 101 574 71 101 574 minecraft:sea_lantern
fill 68 101 576 69 103 579 minecraft:diamond_block
fill 68 101 581 71 101 581 minecraft:sea_lantern
fill 70 101 576 70 102 576 minecraft:diamond_block
fill 70 101 578 70 103 579 minecraft:diamond_block
fill 71 101 579 71 105 579 minecraft:diamond_block
fill 72 101 576 73 101 576 minecraft:sea_lantern
fill 72 101 578 73 101 579 minecraft:sea_lantern
setblock 73 101 577 minecraft:sea_lantern
fill 65 102 576 65 103 579 minecraft:sea_lantern
setblock 66 102 575 minecraft:sea_lantern
fill 66 102 576 67 103 579 minecraft:diamond_block
setblock 66 102 580 minecraft:sea_lantern
setblock 67 102 574 minecraft:sea_lantern
fill 67 102 575 72 103 575 minecraft:diamond_block
fill 67 102 580 72 103 580 minecraft:diamond_block
setblock 67 102 581 minecraft:sea_lantern
fill 68 102 573 71 103 573 minecraft:sea_lantern
fill 68 102 574 71 103 574 minecraft:diamond_block
fill 68 102 581 71 103 581 minecraft:diamond_block
fill 68 102 582 71 103 582 minecraft:sea_lantern
setblock 72 102 574 minecraft:sea_lantern
fill 72 102 576 73 103 576 minecraft:diamond_block
fill 72 102 578 73 103 579 minecraft:diamond_block
setblock 72 102 581 minecraft:sea_lantern
setblock 73 102 575 minecraft:sea_lantern
fill 73 102 577 73 105 577 minecraft:diamond_block
setblock 73 102 580 minecraft:sea_lantern
fill 74 102 576 74 103 579 minecraft:sea_lantern
fill 65 103 575 65 108 575 minecraft:sea_lantern
fill 65 103 580 65 108 580 minecraft:sea_lantern
setblock 66 103 574 minecraft:sea_lantern
setblock 66 103 575 minecraft:diamond_block
setblock 66 103 580 minecraft:diamond_block
setblock 66 103 581 minecraft:sea_lantern
setblock 67 103 573 minecraft:sea_lantern
setblock 67 103 574 minecraft:diamond_block
setblock 67 103 581 minecraft:diamond_block
fill 67 103 582 67 108 582 minecraft:sea_lantern
fill 72 103 573 72 108 573 minecraft:sea_lantern
fill 72 103 574 72 105 574 minecraft:diamond_block
fill 72 103 581 72 105 581 minecraft:diamond_block
fill 72 103 582 72 108 582 minecraft:sea_lantern
setblock 73 103 574 minecraft:sea_lantern
fill 73 103 575 73 105 575 minecraft:diamond_block
setblock 73 103 580 minecraft:diamond_block
setblock 73 103 581 minecraft:sea_lantern
fill 74 103 575 74 108 575 minecraft:sea_lantern
setblock 74 103 580 minecraft:sea_lantern
fill 64 104 576 64 107 579 minecraft:sea_lantern
fill 65 104 574 65 107 574 minecraft:sea_lantern
fill 65 104 576 65 105 579 minecraft:diamond_block
fill 65 104 581 65 107 581 minecraft:sea_lantern
fill 66 104 573 68 104 575 minecraft:redstone_block
fill 66 104 576 69 105 578 minecraft:diamond_block
fill 66 104 579 68 104 581 minecraft:redstone_block
fill 66 104 582 66 107 582 minecraft:sea_lantern
fill 68 104 572 71 107 572 minecraft:sea_lantern
fill 68 104 582 71 105 582 minecraft:diamond_block
fill 68 104 583 71 107 583 minecraft:sea_lantern
fill 69 104 573 71 105 575 minecraft:diamond_block
fill 69 104 579 70 105 581 minecraft:diamond_block
fill 71 104 580 71 109 581 minecraft:diamond_block
fill 72 104 575 72 105 575 minecraft:diamond_block
fill 72 104 579 72 105 580 minecraft:diamond_block
fill 73 104 572 75 104 574 minecraft:redstone_block
fill 73 104 576 74 105 576 minecraft:diamond_block
fill 73 104 578 74 105 579 minecraft:diamond_block
fill 73 104 580 75 104 582 minecraft:redstone_block
fill 74 104 577 74 107 577 minecraft:diamond_block
fill 75 104 576 75 107 579 minecraft:sea_lantern
fill 47 106 557 47 106 562 minecraft:tuff
setblock 47 106 563 minecraft:cobbled_deepslate
fill 47 106 564 88 106 566 minecraft:tuff
setblock 47 106 567 minecraft:cobbled_deepslate
fill 47 106 568 64 106 572 minecraft:tuff
setblock 47 106 573 minecraft:cobbled_deepslate
fill 47 106 574 63 106 577 minecraft:tuff
setblock 47 106 578 minecraft:cobbled_deepslate
fill 47 106 579 63 106 580 minecraft:tuff
fill 47 106 581 47 106 582 minecraft:cobbled_deepslate
fill 47 106 583 67 106 587 minecraft:tuff
setblock 47 106 588 minecraft:cobbled_deepslate
fill 47 106 589 47 107 599 minecraft:tuff
setblock 48 106 557 minecraft:cobbled_deepslate
fill 48 106 558 89 106 563 minecraft:tuff
fill 48 106 567 89 106 567 minecraft:tuff
fill 48 106 573 64 106 573 minecraft:tuff
fill 48 106 578 63 106 578 minecraft:tuff
fill 48 106 581 64 106 582 minecraft:tuff
fill 48 106 588 88 106 598 minecraft:tuff
setblock 48 106 599 minecraft:cobbled_deepslate
fill 49 106 557 66 106 557 minecraft:tuff
fill 49 106 599 60 109 599 minecraft:tuff
setblock 61 106 599 minecraft:cobbled_deepslate
fill 62 106 599 65 106 599 minecraft:tuff
fill 64 106 574 64 106 575 minecraft:tuff
setblock 64 106 580 minecraft:tuff
fill 65 106 568 71 106 571 minecraft:tuff
fill 65 106 572 65 106 573 minecraft:sea_lantern
fill 65 106 576 69 106 576 minecraft:sea_lantern
fill 65 106 577 68 107 577 minecraft:diamond_block
fill 65 106 578 65 106 579 minecraft:sea_lantern
setblock 65 106 582 minecraft:sea_lantern
fill 66 106 572 67 106 572 minecraft:sea_lantern
fill 66 106 573 68 106 575 minecraft:tuff
fill 66 106 578 69 106 578 minecraft:sea_lantern
fill 66 106 579 68 106 581 minecraft:tuff
setblock 66 106 599 minecraft:cobbled_deepslate
setblock 67 106 557 minecraft:cobbled_deepslate
fill 67 106 599 89 107 599 minecraft:tuff
fill 68 106 557 89 106 557 minecraft:tuff
fill 68 106 582 69 106 582 minecraft:sea_lantern
fill 68 106 584 89 106 587 minecraft:tuff
fill 69 106 573 69 106 575 minecraft:sea_lantern
setblock 69 106 577 minecraft:sea_lantern
fill 69 106 579 69 106 581 minecraft:sea_lantern
fill 70 106 573 71 107 574 minecraft:diamond_block
fill 70 106 575 73 106 575 minecraft:sea_lantern
fill 70 106 579 74 106 579 minecraft:sea_lantern
fill 70 106 580 70 107 582 minecraft:diamond_block
fill 71 106 582 71 107 582 minecraft:diamond_block
fill 72 106 568 89 106 570 minecraft:tuff
fill 72 106 571 72 106 572 minecraft:sea_lantern
setblock 72 106 574 minecraft:sea_lantern
fill 72 106 580 72 106 581 minecraft:sea_lantern
fill 72 106 583 76 106 583 minecraft:sea_lantern
fill 73 106 571 76 106 571 minecraft:sea_lantern
fill 73 106 572 75 106 574 minecraft:tuff
fill 73 106 576 73 106 578 minecraft:sea_lantern
fill 73 106 580 75 106 582 minecraft:tuff
fill 74 106 576 74 107 576 minecraft:diamond_block
fill 74 106 578 74 107 578 minecraft:diamond_block
fill 75 106 575 76 106 575 minecraft:sea_lantern
fill 76 106 572 76 106 574 minecraft:sea_lantern
fill 76 106 576 89 106 578 minecraft:tuff
fill 76 106 579 76 106 582 minecraft:sea_lantern
fill 77 106 571 89 106 575 minecraft:tuff
fill 77 106 579 88 106 583 minecraft:tuff
setblock 89 106 564 minecraft:cobbled_deepslate
fill 89 106 565 89 109 566 minecraft:tuff
fill 89 106 579 89 109 579 minecraft:tuff
setblock 89 106 580 minecraft:cobbled_deepslate
fill 89 106 581 89 106 583 minecraft:tuff
fill 89 106 588 89 106 591 minecraft:tuff
setblock 89 106 592 minecraft:cobbled_deepslate
fill 89 106 593 89 109 598 minecraft:tuff
fill 47 107 557 61 107 557 minecraft:tuff
setblock 47 107 558 minecraft:cobbled_deepslate
fill 47 107 559 47 109 559 minecraft:tuff
fill 47 107 560 47 108 560 minecraft:cobbled_deepslate
fill 47 107 561 47 107 570 minecraft:tuff
setblock 47 107 571 minecraft:cobbled_deepslate
fill 47 107 572 47 109 578 minecraft:tuff
setblock 47 107 579 minecraft:cobbled_deepslate
fill 47 107 580 47 109 582 minecraft:tuff
setblock 47 107 583 minecraft:cobbled_deepslate
fill 47 107 584 47 107 588 minecraft:tuff
fill 48 107 599 48 110 599 minecraft:tuff
fill 61 107 599 63 109 599 minecraft:tuff
setblock 62 107 557 minecraft:cobbled_deepslate
fill 63 107 557 70 107 557 minecraft:tuff
setblock 64 107 599 minecraft:cobbled_deepslate
fill 65 107 576 69 107 576 minecraft:diamond_block
fill 65 107 578 69 107 579 minecraft:diamond_block
fill 65 107 599 66 109 599 minecraft:tuff
fill 66 107 573 67 107 573 minecraft:sea_lantern
fill 66 107 574 69 107 575 minecraft:diamond_block
fill 66 107 580 69 107 581 minecraft:diamond_block
fill 68 107 573 69 107 573 minecraft:diamond_block
fill 68 107 582 69 107 582 minecraft:diamond_block
fill 69 107 577 69 110 577 minecraft:diamond_block
fill 70 107 575 73 108 575 minecraft:diamond_block
fill 70 107 579 74 107 579 minecraft:diamond_block
setblock 71 107 557 minecraft:cobbled_deepslate
fill 72 107 557 89 107 557 minecraft:tuff
fill 72 107 574 73 107 574 minecraft:diamond_block
fill 72 107 580 73 107 581 minecraft:diamond_block
setblock 73 107 573 minecraft:sea_lantern
fill 73 107 576 73 109 578 minecraft:diamond_block
setblock 73 107 582 minecraft:sea_lantern
setblock 74 107 574 minecraft:sea_lantern
fill 74 107 580 74 107 581 minecraft:sea_lantern
fill 89 107 558 89 109 564 minecraft:tuff
fill 89 107 567 89 109 574 minecraft:tuff
fill 89 107 575 89 108 575 minecraft:cobbled_deepslate
fill 89 107 576 89 107 578 minecraft:tuff
fill 89 107 580 89 109 580 minecraft:tuff
setblock 89 107 581 minecraft:cobbled_deepslate
fill 89 107 582 89 107 584 minecraft:tuff
setblock 89 107 585 minecraft:cobbled_deepslate
fill 89 107 586 89 109 589 minecraft:tuff
fill 89 107 590 89 108 590 minecraft:cobbled_deepslate
fill 89 107 591 89 109 592 minecraft:tuff
setblock 47 108 557 minecraft:cobbled_deepslate
fill 47 108 558 47 109 558 minecraft:tuff
fill 47 108 561 47 109 564 minecraft:tuff
setblock 47 108 565 minecraft:cobbled_deepslate
fill 47 108 566 47 109 568 minecraft:tuff
fill 47 108 569 47 108 570 minecraft:cobbled_deepslate
fill 47 108 571 47 109 571 minecraft:tuff
fill 47 108 579 47 109 579 minecraft:tuff
fill 47 108 583 47 109 586 minecraft:tuff
setblock 47 108 587 minecraft:cobbled_deepslate
fill 47 108 588 47 109 598 minecraft:tuff
setblock 47 108 599 minecraft:cobbled_deepslate
fill 48 108 557 63 109 557 minecraft:tuff
setblock 50 108 560 minecraft:light[level=14]
setblock 50 108 568 minecraft:light[level=14]
setblock 50 108 576 minecraft:light[level=14]
setblock 50 108 584 minecraft:light[level=14]
setblock 50 108 592 minecraft:light[level=14]
setblock 58 108 560 minecraft:light[level=14]
setblock 58 108 568 minecraft:light[level=14]
setblock 58 108 576 minecraft:light[level=14]
setblock 58 108 584 minecraft:light[level=14]
setblock 58 108 592 minecraft:light[level=14]
setblock 64 108 557 minecraft:cobbled_deepslate
fill 64 108 599 64 110 599 minecraft:tuff
fill 65 108 557 80 109 557 minecraft:tuff
fill 65 108 576 65 109 579 minecraft:sea_lantern
setblock 66 108 560 minecraft:light[level=14]
setblock 66 108 568 minecraft:light[level=14]
setblock 66 108 574 minecraft:sea_lantern
fill 66 108 575 68 108 580 minecraft:diamond_block
setblock 66 108 581 minecraft:sea_lantern
setblock 66 108 584 minecraft:light[level=14]
setblock 66 108 592 minecraft:light[level=14]
fill 67 108 573 71 108 573 minecraft:sea_lantern
fill 67 108 574 72 108 574 minecraft:diamond_block
fill 67 108 581 70 108 581 minecraft:diamond_block
fill 67 108 599 68 109 599 minecraft:tuff
fill 68 108 582 71 109 582 minecraft:sea_lantern
fill 69 108 575 69 109 576 minecraft:diamond_block
fill 69 108 578 69 109 580 minecraft:diamond_block
setblock 69 108 599 minecraft:cobbled_deepslate
fill 70 108 579 70 109 580 minecraft:diamond_block
fill 70 108 599 70 109 599 minecraft:tuff
fill 71 108 579 73 109 579 minecraft:diamond_block
setblock 71 108 599 minecraft:cobbled_deepslate
fill 72 108 580 72 108 581 minecraft:diamond_block
fill 72 108 599 89 109 599 minecraft:tuff
setblock 73 108 574 minecraft:sea_lantern
setblock 73 108 580 minecraft:diamond_block
setblock 73 108 581 minecraft:sea_lantern
setblock 74 108 560 minecraft:light[level=14]
setblock 74 108 568 minecraft:light[level=14]
fill 74 108 576 74 108 580 minecraft:sea_lantern
setblock 74 108 584 minecraft:light[level=14]
setblock 74 108 592 minecraft:light[level=14]
fill 81 108 557 82 108 557 minecraft:cobbled_deepslate
setblock 82 108 560 minecraft:light[level=14]
setblock 82 108 568 minecraft:light[level=14]
setblock 82 108 576 minecraft:light[level=14]
setblock 82 108 584 minecraft:light[level=14]
setblock 82 108 592 minecraft:light[level=14]
fill 83 108 557 86 109 557 minecraft:tuff
setblock 87 108 557 minecraft:cobbled_deepslate
fill 88 108 557 88 109 557 minecraft:tuff
setblock 89 108 557 minecraft:cobbled_deepslate
fill 89 108 576 89 108 578 minecraft:cobbled_deepslate
fill 89 108 581 89 109 583 minecraft:tuff
setblock 89 108 584 minecraft:cobbled_deepslate
fill 89 108 585 89 109 585 minecraft:tuff
setblock 47 109 557 minecraft:tuff
setblock 47 109 560 minecraft:tuff
setblock 47 109 565 minecraft:tuff
fill 47 109 569 47 109 570 minecraft:tuff
setblock 47 109 587 minecraft:tuff
fill 47 109 599 47 111 599 minecraft:tuff
fill 64 109 557 64 110 557 minecraft:tuff
setblock 66 109 575 minecraft:sea_lantern
fill 66 109 576 68 109 579 minecraft:diamond_block
setblock 66 109 580 minecraft:sea_lantern
setblock 67 109 574 minecraft:sea_lantern
fill 67 109 575 68 109 575 minecraft:diamond_block
fill 67 109 580 68 109 580 minecraft:diamond_block
setblock 67 109 581 minecraft:sea_lantern
fill 68 109 573 71 109 573 minecraft:sea_lantern
fill 68 109 574 71 109 574 minecraft:diamond_block
fill 68 109 581 70 109 581 minecraft:diamond_block
setblock 69 109 599 minecraft:tuff
fill 70 109 575 72 109 575 minecraft:diamond_block
fill 70 109 578 72 109 578 minecraft:diamond_block
setblock 71 109 599 minecraft:tuff
setblock 72 109 574 minecraft:sea_lantern
setblock 72 109 576 minecraft:diamond_block
setblock 72 109 580 minecraft:diamond_block
setblock 72 109 581 minecraft:sea_lantern
setblock 73 109 575 minecraft:sea_lantern
setblock 73 109 580 minecraft:sea_lantern
fill 74 109 576 74 109 579 minecraft:sea_lantern
fill 81 109 557 82 109 557 minecraft:tuff
setblock 87 109 557 minecraft:tuff
setblock 89 109 557 minecraft:tuff
fill 89 109 575 89 109 578 minecraft:tuff
setblock 89 109 584 minecraft:tuff
setblock 89 109 590 minecraft:tuff
fill 47 110 557 47 111 563 minecraft:cobbled_deepslate
setblock 47 110 564 minecraft:tuff
setblock 47 110 565 minecraft:cobbled_deepslate
fill 47 110 566 47 110 567 minecraft:tuff
fill 47 110 568 47 110 572 minecraft:cobbled_deepslate
setblock 47 110 573 minecraft:tuff
fill 47 110 574 48 110 574 minecraft:cobbled_deepslate
setblock 47 110 575 minecraft:tuff
fill 47 110 576 47 110 589 minecraft:cobbled_deepslate
setblock 47 110 590 minecraft:tuff
fill 47 110 591 47 110 598 minecraft:cobbled_deepslate
fill 48 110 557 48 110 559 minecraft:cobbled_deepslate
setblock 48 110 560 minecraft:calcite
fill 48 110 561 48 110 564 minecraft:cobbled_deepslate
setblock 48 110 565 minecraft:calcite
fill 48 110 566 48 110 569 minecraft:cobbled_deepslate
setblock 48 110 570 minecraft:calcite
fill 48 110 571 48 111 573 minecraft:cobbled_deepslate
setblock 48 110 575 minecraft:calcite
fill 48 110 576 48 110 579 minecraft:cobbled_deepslate
setblock 48 110 580 minecraft:calcite
fill 48 110 581 48 110 584 minecraft:cobbled_deepslate
setblock 48 110 585 minecraft:calcite
fill 48 110 586 48 110 589 minecraft:cobbled_deepslate
setblock 48 110 590 minecraft:calcite
fill 48 110 591 48 110 594 minecraft:cobbled_deepslate
setblock 48 110 595 minecraft:calcite
fill 48 110 596 48 111 598 minecraft:cobbled_deepslate
fill 49 110 557 49 110 558 minecraft:cobbled_deepslate
setblock 49 110 559 minecraft:calcite
fill 49 110 560 49 110 563 minecraft:cobbled_deepslate
setblock 49 110 564 minecraft:calcite
fill 49 110 565 49 110 568 minecraft:cobbled_deepslate
setblock 49 110 569 minecraft:calcite
fill 49 110 580 49 110 583 minecraft:cobbled_deepslate
setblock 49 110 584 minecraft:calcite
fill 49 110 585 49 110 588 minecraft:cobbled_deepslate
fill 49 110 597 49 110 599 minecraft:cobbled_deepslate
fill 50 110 557 54 110 557 minecraft:cobbled_deepslate
setblock 50 110 558 minecraft:calcite
fill 50 110 559 50 110 562 minecraft:cobbled_deepslate
setblock 50 110 563 minecraft:calcite
fill 50 110 564 50 110 566 minecraft:cobbled_deepslate
setblock 50 110 598 minecraft:calcite
fill 50 110 599 58 111 599 minecraft:cobbled_deepslate
fill 51 110 558 52 110 560 minecraft:cobbled_deepslate
fill 51 110 598 54 110 598 minecraft:cobbled_deepslate
fill 53 110 558 53 110 559 minecraft:cobbled_deepslate
setblock 54 110 558 minecraft:cobbled_deepslate
setblock 54 110 559 minecraft:calcite
setblock 55 110 557 minecraft:tuff
setblock 55 110 558 minecraft:calcite
fill 55 110 559 58 110 559 minecraft:cobbled_deepslate
setblock 55 110 598 minecraft:calcite
fill 56 110 557 56 112 558 minecraft:cobbled_deepslate
fill 56 110 598 59 110 598 minecraft:cobbled_deepslate
setblock 57 110 557 minecraft:tuff
fill 57 110 558 59 110 558 minecraft:cobbled_deepslate
fill 58 110 557 62 204 557 minecraft:cobbled_deepslate
setblock 59 110 559 minecraft:calcite
setblock 59 110 599 minecraft:tuff
setblock 60 110 558 minecraft:calcite
fill 60 110 559 63 110 559 minecraft:cobbled_deepslate
setblock 60 110 597 minecraft:cobbled_deepslate
setblock 60 110 598 minecraft:calcite
fill 60 110 599 63 110 599 minecraft:cobbled_deepslate
fill 61 110 558 64 110 558 minecraft:cobbled_deepslate
setblock 61 110 597 minecraft:calcite
fill 61 110 598 64 110 598 minecraft:cobbled_deepslate
fill 62 110 597 65 110 597 minecraft:cobbled_deepslate
setblock 63 110 557 minecraft:tuff
setblock 63 110 560 minecraft:calcite
setblock 64 110 559 minecraft:calcite
fill 64 110 560 67 110 560 minecraft:cobbled_deepslate
fill 65 110 557 65 208 557 minecraft:cobbled_deepslate
setblock 65 110 558 minecraft:calcite
fill 65 110 559 68 110 559 minecraft:cobbled_deepslate
setblock 65 110 598 minecraft:calcite
fill 65 110 599 66 111 599 minecraft:cobbled_deepslate
setblock 66 110 557 minecraft:tuff
fill 66 110 558 69 110 558 minecraft:cobbled_deepslate
fill 66 110 576 67 110 579 minecraft:sea_lantern
setblock 66 110 597 minecraft:calcite
fill 66 110 598 69 110 598 minecraft:cobbled_deepslate
fill 67 110 557 71 205 557 minecraft:cobbled_deepslate
fill 67 110 575 72 110 575 minecraft:sea_lantern
fill 67 110 580 72 110 580 minecraft:sea_lantern
fill 67 110 597 68 110 597 minecraft:cobbled_deepslate
fill 67 110 599 67 111 599 minecraft:tuff
fill 68 110 574 71 110 574 minecraft:sea_lantern
fill 68 110 576 68 110 579 minecraft:diamond_block
fill 68 110 581 71 110 581 minecraft:sea_lantern
fill 68 110 599 89 110 599 minecraft:cobbled_deepslate
setblock 69 110 559 minecraft:calcite
setblock 69 110 576 minecraft:diamond_block
fill 69 110 578 71 110 579 minecraft:diamond_block
setblock 70 110 558 minecraft:calcite
fill 70 110 595 72 112 595 minecraft:calcite
setblock 70 110 598 minecraft:calcite
setblock 71 110 558 minecraft:cobbled_deepslate
fill 71 110 594 71 112 594 minecraft:calcite
fill 71 110 596 71 112 596 minecraft:calcite
setblock 71 110 598 minecraft:cobbled_deepslate
setblock 72 110 557 minecraft:tuff
fill 72 110 576 73 110 576 minecraft:sea_lantern
fill 72 110 578 73 110 579 minecraft:sea_lantern
fill 73 110 557 78 204 557 minecraft:cobbled_deepslate
setblock 73 110 577 minecraft:sea_lantern
setblock 79 110 557 minecraft:tuff
setblock 79 110 558 minecraft:cobbled_deepslate
fill 80 110 557 81 111 557 minecraft:cobbled_deepslate
setblock 80 110 558 minecraft:calcite
fill 81 110 558 83 110 559 minecraft:cobbled_deepslate
setblock 82 110 557 minecraft:tuff
setblock 82 110 560 minecraft:cobbled_deepslate
fill 83 110 557 89 110 557 minecraft:cobbled_deepslate
setblock 83 110 560 minecraft:calcite
fill 83 110 565 84 110 567 minecraft:light_blue_stained_glass
fill 83 110 598 84 110 598 minecraft:cobbled_deepslate
setblock 84 110 558 minecraft:cobbled_deepslate
setblock 84 110 559 minecraft:calcite
fill 84 110 560 86 110 561 minecraft:cobbled_deepslate
setblock 85 110 558 minecraft:calcite
fill 85 110 559 88 110 559 minecraft:cobbled_deepslate
setblock 85 110 562 minecraft:cobbled_deepslate
setblock 85 110 563 minecraft:calcite
fill 85 110 564 85 110 567 minecraft:cobbled_deepslate
setblock 85 110 568 minecraft:calcite
fill 85 110 581 85 110 582 minecraft:cobbled_deepslate
setblock 85 110 583 minecraft:calcite
setblock 85 110 598 minecraft:calcite
fill 86 110 558 89 111 558 minecraft:cobbled_deepslate
setblock 86 110 562 minecraft:calcite
fill 86 110 563 86 110 566 minecraft:cobbled_deepslate
setblock 86 110 567 minecraft:calcite
fill 86 110 568 86 110 571 minecraft:cobbled_deepslate
setblock 86 110 572 minecraft:calcite
fill 86 110 573 89 110 573 minecraft:cobbled_deepslate
fill 86 110 575 86 110 576 minecraft:cobbled_deepslate
setblock 86 110 577 minecraft:calcite
fill 86 110 578 86 110 581 minecraft:cobbled_deepslate
setblock 86 110 582 minecraft:calcite
fill 86 110 583 86 110 586 minecraft:cobbled_deepslate
setblock 86 110 587 minecraft:calcite
fill 86 110 598 89 111 598 minecraft:cobbled_deepslate
setblock 87 110 560 minecraft:cobbled_deepslate
setblock 87 110 561 minecraft:calcite
fill 87 110 562 87 110 565 minecraft:cobbled_deepslate
setblock 87 110 566 minecraft:calcite
fill 87 110 567 87 110 570 minecraft:cobbled_deepslate
setblock 87 110 571 minecraft:calcite
fill 87 110 572 89 112 572 minecraft:cobbled_deepslate
fill 87 110 574 87 110 575 minecraft:cobbled_deepslate
setblock 87 110 576 minecraft:calcite
fill 87 110 577 87 110 580 minecraft:cobbled_deepslate
setblock 87 110 581 minecraft:calcite
fill 87 110 582 87 110 585 minecraft:cobbled_deepslate
setblock 87 110 586 minecraft:calcite
fill 87 110 587 89 110 589 minecraft:cobbled_deepslate
setblock 88 110 560 minecraft:calcite
fill 88 110 561 89 110 564 minecraft:cobbled_deepslate
setblock 88 110 565 minecraft:calcite
fill 88 110 566 88 110 569 minecraft:cobbled_deepslate
setblock 88 110 570 minecraft:calcite
fill 88 110 571 89 113 571 minecraft:cobbled_deepslate
fill 88 110 574 89 110 574 minecraft:cobbled_deepslate
setblock 88 110 575 minecraft:calcite
fill 88 110 576 88 110 579 minecraft:cobbled_deepslate
setblock 88 110 580 minecraft:calcite
fill 88 110 581 88 110 584 minecraft:cobbled_deepslate
setblock 88 110 585 minecraft:calcite
fill 88 110 586 89 110 586 minecraft:cobbled_deepslate
setblock 88 110 590 minecraft:calcite
fill 88 110 591 89 110 592 minecraft:cobbled_deepslate
fill 88 110 596 89 110 597 minecraft:cobbled_deepslate
setblock 89 110 559 minecraft:tuff
fill 89 110 560 89 204 560 minecraft:cobbled_deepslate
setblock 89 110 565 minecraft:tuff
fill 89 110 566 89 204 566 minecraft:cobbled_deepslate
fill 89 110 567 89 110 568 minecraft:tuff
fill 89 110 569 89 204 570 minecraft:cobbled_deepslate
fill 89 110 575 89 110 577 minecraft:cobbled_deepslate
setblock 89 110 578 minecraft:tuff
fill 89 110 579 89 206 582 minecraft:cobbled_deepslate
setblock 89 110 583 minecraft:tuff
fill 89 110 584 89 205 585 minecraft:cobbled_deepslate
fill 89 110 590 89 208 590 minecraft:cobbled_deepslate
setblock 89 110 593 minecraft:tuff
fill 89 110 594 89 110 595 minecraft:cobbled_deepslate
fill 47 111 564 47 206 564 minecraft:cobbled_deepslate
fill 47 111 565 47 112 565 minecraft:tuff
fill 47 111 566 47 205 571 minecraft:cobbled_deepslate
setblock 47 111 572 minecraft:tuff
fill 47 111 573 47 111 582 minecraft:cobbled_deepslate
setblock 47 111 583 minecraft:tuff
fill 47 111 584 47 204 593 minecraft:cobbled_deepslate
setblock 47 111 594 minecraft:tuff
fill 47 111 595 47 111 598 minecraft:cobbled_deepslate
fill 48 111 557 48 111 558 minecraft:cobbled_deepslate
setblock 48 111 559 minecraft:calcite
fill 48 111 560 48 111 563 minecraft:cobbled_deepslate
setblock 48 111 564 minecraft:calcite
fill 48 111 565 48 111 568 minecraft:cobbled_deepslate
setblock 48 111 569 minecraft:calcite
fill 48 111 570 48 114 570 minecraft:cobbled_deepslate
fill 48 111 577 48 111 578 minecraft:cobbled_deepslate
setblock 48 111 579 minecraft:calcite
fill 48 111 580 48 111 583 minecraft:cobbled_deepslate
setblock 48 111 584 minecraft:calcite
fill 48 111 585 48 111 588 minecraft:cobbled_deepslate
setblock 48 111 589 minecraft:calcite
fill 48 111 590 48 111 593 minecraft:cobbled_deepslate
setblock 48 111 594 minecraft:calcite
fill 48 111 595 48 113 595 minecraft:cobbled_deepslate
fill 48 111 599 49 208 599 minecraft:cobbled_deepslate
fill 49 111 557 50 206 557 minecraft:cobbled_deepslate
setblock 49 111 558 minecraft:calcite
fill 49 111 559 49 111 562 minecraft:cobbled_deepslate
setblock 49 111 563 minecraft:calcite
fill 49 111 564 49 111 567 minecraft:cobbled_deepslate
setblock 49 111 568 minecraft:calcite
setblock 49 111 583 minecraft:calcite
fill 49 111 584 49 111 587 minecraft:cobbled_deepslate
setblock 49 111 588 minecraft:calcite
setblock 49 111 598 minecraft:calcite
fill 50 111 558 50 111 561 minecraft:cobbled_deepslate
setblock 50 111 562 minecraft:calcite
fill 50 111 563 50 111 565 minecraft:cobbled_deepslate
fill 50 111 598 53 111 598 minecraft:cobbled_deepslate
fill 51 111 557 51 112 557 minecraft:tuff
fill 51 111 558 51 111 560 minecraft:cobbled_deepslate
fill 52 111 557 52 111 559 minecraft:cobbled_deepslate
fill 53 111 557 53 111 558 minecraft:cobbled_deepslate
setblock 53 111 559 minecraft:calcite
fill 54 111 557 55 208 557 minecraft:cobbled_deepslate
setblock 54 111 558 minecraft:calcite
setblock 54 111 559 minecraft:cobbled_deepslate
setblock 54 111 598 minecraft:calcite
fill 55 111 558 55 112 558 minecraft:cobbled_deepslate
fill 55 111 598 58 111 598 minecraft:cobbled_deepslate
fill 57 111 557 57 112 558 minecraft:cobbled_deepslate
setblock 58 111 558 minecraft:cobbled_deepslate
setblock 59 111 558 minecraft:calcite
setblock 59 111 598 minecraft:calcite
fill 59 111 599 60 204 599 minecraft:cobbled_deepslate
fill 60 111 558 62 111 559 minecraft:cobbled_deepslate
fill 60 111 598 63 111 598 minecraft:cobbled_deepslate
fill 61 111 597 64 111 597 minecraft:cobbled_deepslate
fill 61 111 599 62 111 599 minecraft:tuff
fill 63 111 557 63 111 558 minecraft:cobbled_deepslate
setblock 63 111 559 minecraft:calcite
fill 63 111 599 64 111 599 minecraft:cobbled_deepslate
fill 64 111 557 64 208 557 minecraft:cobbled_deepslate
setblock 64 111 558 minecraft:calcite
fill 64 111 559 67 111 559 minecraft:cobbled_deepslate
setblock 64 111 598 minecraft:calcite
fill 65 111 558 68 111 558 minecraft:cobbled_deepslate
setblock 65 111 597 minecraft:calcite
fill 65 111 598 68 111 598 minecraft:cobbled_deepslate
fill 66 111 557 66 206 557 minecraft:cobbled_deepslate
fill 66 111 597 67 111 597 minecraft:cobbled_deepslate
setblock 68 111 559 minecraft:calcite
fill 68 111 576 69 111 579 minecraft:sea_lantern
fill 68 111 599 77 111 599 minecraft:cobbled_deepslate
setblock 69 111 558 minecraft:calcite
setblock 69 111 598 minecraft:calcite
setblock 70 111 558 minecraft:cobbled_deepslate
fill 70 111 578 71 111 579 minecraft:sea_lantern
fill 70 111 594 70 112 594 minecraft:calcite
fill 70 111 596 70 112 596 minecraft:calcite
fill 72 111 557 72 209 557 minecraft:cobbled_deepslate
fill 72 111 594 72 112 594 minecraft:calcite
fill 72 111 596 72 112 596 minecraft:calcite
setblock 78 111 599 minecraft:tuff
setblock 79 111 557 minecraft:cobbled_deepslate
fill 79 111 599 81 208 599 minecraft:cobbled_deepslate
fill 80 111 558 83 111 558 minecraft:cobbled_deepslate
fill 81 111 559 82 111 559 minecraft:cobbled_deepslate
fill 82 111 557 87 111 557 minecraft:cobbled_deepslate
setblock 82 111 560 minecraft:calcite
setblock 82 111 599 minecraft:tuff
setblock 83 111 559 minecraft:calcite
fill 83 111 560 86 111 560 minecraft:cobbled_deepslate
fill 83 111 599 89 111 599 minecraft:cobbled_deepslate
setblock 84 111 558 minecraft:calcite
fill 84 111 559 87 111 559 minecraft:cobbled_deepslate
fill 84 111 561 85 111 561 minecraft:cobbled_deepslate
setblock 84 111 566 minecraft:light_blue_stained_glass
setblock 84 111 598 minecraft:calcite
fill 85 111 558 85 114 558 minecraft:cobbled_deepslate
setblock 85 111 562 minecraft:calcite
fill 85 111 563 85 111 566 minecraft:cobbled_deepslate
setblock 85 111 567 minecraft:calcite
fill 85 111 568 89 111 568 minecraft:cobbled_deepslate
fill 85 111 598 85 112 598 minecraft:cobbled_deepslate
setblock 86 111 561 minecraft:calcite
fill 86 111 562 86 111 565 minecraft:cobbled_deepslate
setblock 86 111 566 minecraft:calcite
fill 86 111 567 89 112 567 minecraft:cobbled_deepslate
fill 86 111 569 86 111 570 minecraft:cobbled_deepslate
setblock 86 111 571 minecraft:calcite
fill 86 111 579 86 111 580 minecraft:cobbled_deepslate
setblock 86 111 581 minecraft:calcite
fill 86 111 582 86 111 585 minecraft:cobbled_deepslate
setblock 86 111 586 minecraft:calcite
setblock 87 111 560 minecraft:calcite
fill 87 111 561 87 111 564 minecraft:cobbled_deepslate
setblock 87 111 565 minecraft:calcite
fill 87 111 566 88 113 566 minecraft:cobbled_deepslate
setblock 87 111 569 minecraft:cobbled_deepslate
setblock 87 111 570 minecraft:calcite
fill 87 111 571 87 114 571 minecraft:cobbled_deepslate
fill 87 111 573 87 111 574 minecraft:cobbled_deepslate
setblock 87 111 575 minecraft:calcite
fill 87 111 576 87 111 579 minecraft:cobbled_deepslate
setblock 87 111 580 minecraft:calcite
fill 87 111 581 87 111 584 minecraft:cobbled_deepslate
setblock 87 111 585 minecraft:calcite
fill 87 111 586 87 111 589 minecraft:cobbled_deepslate
fill 88 111 557 89 111 557 minecraft:tuff
setblock 88 111 559 minecraft:calcite
fill 88 111 560 88 111 563 minecraft:cobbled_deepslate
setblock 88 111 564 minecraft:calcite
fill 88 111 565 89 114 565 minecraft:cobbled_deepslate
setblock 88 111 569 minecraft:calcite
fill 88 111 570 88 114 570 minecraft:cobbled_deepslate
setblock 88 111 573 minecraft:cobbled_deepslate
setblock 88 111 574 minecraft:calcite
fill 88 111 575 88 111 578 minecraft:cobbled_deepslate
setblock 88 111 579 minecraft:calcite
fill 88 111 580 88 111 583 minecraft:cobbled_deepslate
setblock 88 111 584 minecraft:calcite
fill 88 111 585 88 111 588 minecraft:cobbled_deepslate
setblock 88 111 589 minecraft:calcite
fill 88 111 590 88 112 591 minecraft:cobbled_deepslate
fill 88 111 597 89 111 597 minecraft:cobbled_deepslate
setblock 89 111 559 minecraft:cobbled_deepslate
fill 89 111 561 89 204 564 minecraft:cobbled_deepslate
setblock 89 111 573 minecraft:tuff
setblock 89 111 574 minecraft:cobbled_deepslate
fill 89 111 575 89 112 575 minecraft:tuff
fill 89 111 576 89 208 578 minecraft:cobbled_deepslate
fill 89 111 583 89 208 583 minecraft:cobbled_deepslate
setblock 89 111 586 minecraft:tuff
fill 89 111 587 89 208 588 minecraft:cobbled_deepslate
setblock 89 111 589 minecraft:tuff
fill 89 111 591 89 208 593 minecraft:cobbled_deepslate
fill 89 111 594 89 112 594 minecraft:tuff
fill 89 111 595 89 206 595 minecraft:cobbled_deepslate
setblock 89 111 596 minecraft:tuff
setblock 47 112 557 minecraft:tuff
fill 47 112 558 47 206 558 minecraft:cobbled_deepslate
setblock 47 112 559 minecraft:tuff
fill 47 112 560 47 206 563 minecraft:cobbled_deepslate
fill 47 112 572 47 205 572 minecraft:cobbled_deepslate
setblock 47 112 573 minecraft:tuff
fill 47 112 574 47 204 583 minecraft:cobbled_deepslate
fill 47 112 594 47 208 597 minecraft:cobbled_deepslate
setblock 47 112 598 minecraft:tuff
fill 47 112 599 47 206 599 minecraft:cobbled_deepslate
fill 48 112 557 48 205 557 minecraft:cobbled_deepslate
setblock 48 112 558 minecraft:calcite
fill 48 112 559 48 112 562 minecraft:cobbled_deepslate
setblock 48 112 563 minecraft:calcite
fill 48 112 564 48 112 567 minecraft:cobbled_deepslate
setblock 48 112 568 minecraft:calcite
fill 48 112 569 48 115 569 minecraft:cobbled_deepslate
setblock 48 112 571 minecraft:cobbled_deepslate
fill 48 112 580 48 112 582 minecraft:cobbled_deepslate
setblock 48 112 583 minecraft:calcite
fill 48 112 584 48 112 587 minecraft:cobbled_deepslate
setblock 48 112 588 minecraft:calcite
fill 48 112 589 48 112 592 minecraft:cobbled_deepslate
setblock 48 112 593 minecraft:calcite
fill 48 112 594 48 115 594 minecraft:cobbled_deepslate
fill 48 112 596 48 112 597 minecraft:cobbled_deepslate
setblock 48 112 598 minecraft:calcite
fill 49 112 558 49 112 561 minecraft:cobbled_deepslate
setblock 49 112 562 minecraft:calcite
fill 49 112 563 49 112 566 minecraft:cobbled_deepslate
setblock 49 112 567 minecraft:calcite
setblock 49 112 568 minecraft:cobbled_deepslate
fill 49 112 585 49 112 586 minecraft:cobbled_deepslate
setblock 49 112 587 minecraft:calcite
setblock 49 112 588 minecraft:cobbled_deepslate
fill 49 112 598 51 112 598 minecraft:cobbled_deepslate
fill 50 112 558 51 112 559 minecraft:cobbled_deepslate
setblock 50 112 561 minecraft:calcite
fill 50 112 562 50 112 564 minecraft:cobbled_deepslate
setblock 50 112 599 minecraft:tuff
fill 51 112 599 52 204 599 minecraft:cobbled_deepslate
fill 52 112 557 52 112 558 minecraft:cobbled_deepslate
setblock 53 112 557 minecraft:tuff
setblock 53 112 558 minecraft:calcite
setblock 53 112 599 minecraft:tuff
setblock 54 112 558 minecraft:cobbled_deepslate
fill 54 112 599 56 206 599 minecraft:cobbled_deepslate
setblock 57 112 598 minecraft:cobbled_deepslate
setblock 57 112 599 minecraft:tuff
setblock 58 112 558 minecraft:calcite
setblock 58 112 598 minecraft:calcite
fill 58 112 599 58 205 599 minecraft:cobbled_deepslate
fill 59 112 558 62 112 558 minecraft:cobbled_deepslate
fill 59 112 598 62 112 598 minecraft:cobbled_deepslate
setblock 61 112 559 minecraft:cobbled_deepslate
fill 61 112 597 63 112 597 minecraft:cobbled_deepslate
fill 61 112 599 62 208 599 minecraft:cobbled_deepslate
setblock 62 112 559 minecraft:calcite
fill 63 112 557 63 208 557 minecraft:cobbled_deepslate
setblock 63 112 558 minecraft:calcite
fill 63 112 559 66 112 559 minecraft:cobbled_deepslate
setblock 63 112 598 minecraft:calcite
setblock 63 112 599 minecraft:tuff
fill 64 112 558 67 112 558 minecraft:cobbled_deepslate
setblock 64 112 597 minecraft:calcite
fill 64 112 598 65 114 599 minecraft:cobbled_deepslate
setblock 65 112 597 minecraft:cobbled_deepslate
fill 66 112 598 67 112 598 minecraft:cobbled_deepslate
setblock 66 112 599 minecraft:tuff
fill 67 112 599 67 205 599 minecraft:cobbled_deepslate
setblock 68 112 558 minecraft:calcite
setblock 68 112 598 minecraft:calcite
setblock 68 112 599 minecraft:tuff
fill 69 112 599 76 204 599 minecraft:cobbled_deepslate
setblock 77 112 599 minecraft:tuff
fill 78 112 599 78 208 599 minecraft:cobbled_deepslate
fill 79 112 557 80 112 557 minecraft:tuff
fill 80 112 558 82 112 558 minecraft:cobbled_deepslate
fill 81 112 557 83 208 557 minecraft:cobbled_deepslate
setblock 81 112 559 minecraft:cobbled_deepslate
setblock 82 112 559 minecraft:calcite
fill 82 112 560 85 112 560 minecraft:cobbled_deepslate
fill 82 112 599 86 205 599 minecraft:cobbled_deepslate
setblock 83 112 558 minecraft:calcite
fill 83 112 559 86 112 559 minecraft:cobbled_deepslate
setblock 84 112 557 minecraft:tuff
fill 84 112 558 84 115 558 minecraft:cobbled_deepslate
setblock 84 112 561 minecraft:cobbled_deepslate
fill 85 112 557 89 208 557 minecraft:cobbled_deepslate
setblock 85 112 561 minecraft:calcite
fill 85 112 562 85 112 565 minecraft:cobbled_deepslate
setblock 85 112 566 minecraft:calcite
fill 85 112 567 85 114 568 minecraft:cobbled_deepslate
fill 86 112 558 87 112 558 minecraft:cobbled_deepslate
setblock 86 112 560 minecraft:calcite
fill 86 112 561 86 112 564 minecraft:cobbled_deepslate
setblock 86 112 565 minecraft:calcite
fill 86 112 566 86 115 566 minecraft:cobbled_deepslate
fill 86 112 568 86 112 569 minecraft:cobbled_deepslate
setblock 86 112 570 minecraft:calcite
setblock 86 112 571 minecraft:cobbled_deepslate
fill 86 112 582 86 112 584 minecraft:cobbled_deepslate
setblock 86 112 585 minecraft:calcite
fill 86 112 598 87 112 598 minecraft:cobbled_deepslate
setblock 87 112 559 minecraft:calcite
fill 87 112 560 87 112 563 minecraft:cobbled_deepslate
setblock 87 112 564 minecraft:calcite
fill 87 112 565 87 115 565 minecraft:cobbled_deepslate
setblock 87 112 568 minecraft:cobbled_deepslate
setblock 87 112 569 minecraft:calcite
fill 87 112 570 87 115 570 minecraft:cobbled_deepslate
setblock 87 112 573 minecraft:cobbled_deepslate
setblock 87 112 574 minecraft:calcite
setblock 87 112 578 minecraft:cobbled_deepslate
setblock 87 112 579 minecraft:calcite
fill 87 112 580 87 112 583 minecraft:cobbled_deepslate
setblock 87 112 584 minecraft:calcite
fill 87 112 585 87 112 588 minecraft:cobbled_deepslate
setblock 87 112 599 minecraft:tuff
setblock 88 112 558 minecraft:calcite
fill 88 112 559 88 112 562 minecraft:cobbled_deepslate
setblock 88 112 563 minecraft:calcite
fill 88 112 564 88 115 564 minecraft:cobbled_deepslate
setblock 88 112 568 minecraft:calcite
fill 88 112 569 88 115 569 minecraft:cobbled_deepslate
setblock 88 112 573 minecraft:calcite
fill 88 112 574 88 112 577 minecraft:cobbled_deepslate
setblock 88 112 578 minecraft:calcite
fill 88 112 579 88 112 582 minecraft:cobbled_deepslate
setblock 88 112 583 minecraft:calcite
fill 88 112 584 88 112 587 minecraft:cobbled_deepslate
setblock 88 112 588 minecraft:calcite
fill 88 112 589 89 115 589 minecraft:cobbled_deepslate
fill 88 112 599 89 206 599 minecraft:cobbled_deepslate
fill 89 112 558 89 208 558 minecraft:cobbled_deepslate
setblock 89 112 559 minecraft:tuff
fill 89 112 568 89 208 568 minecraft:cobbled_deepslate
fill 89 112 573 89 208 573 minecraft:cobbled_deepslate
setblock 89 112 574 minecraft:tuff
fill 89 112 586 89 208 586 minecraft:cobbled_deepslate
fill 89 112 596 89 208 596 minecraft:cobbled_deepslate
setblock 89 112 597 minecraft:tuff
fill 89 112 598 89 208 598 minecraft:cobbled_deepslate
fill 47 113 557 47 208 557 minecraft:cobbled_deepslate
fill 47 113 559 50 113 559 minecraft:cobbled_deepslate
fill 47 113 565 49 113 565 minecraft:cobbled_deepslate
fill 47 113 573 47 209 573 minecraft:cobbled_deepslate
fill 47 113 598 49 113 598 minecraft:cobbled_deepslate
fill 48 113 558 51 113 558 minecraft:cobbled_deepslate
fill 48 113 560 48 113 561 minecraft:cobbled_deepslate
setblock 48 113 562 minecraft:calcite
fill 48 113 563 49 114 564 minecraft:cobbled_deepslate
setblock 48 113 566 minecraft:cobbled_deepslate
setblock 48 113 567 minecraft:calcite
fill 48 113 568 48 116 568 minecraft:cobbled_deepslate
setblock 48 113 582 minecraft:calcite
fill 48 113 583 48 113 586 minecraft:cobbled_deepslate
setblock 48 113 587 minecraft:calcite
fill 48 113 588 48 113 591 minecraft:cobbled_deepslate
setblock 48 113 592 minecraft:calcite
fill 48 113 593 48 116 593 minecraft:cobbled_deepslate
setblock 48 113 596 minecraft:cobbled_deepslate
setblock 48 113 597 minecraft:calcite
setblock 49 113 560 minecraft:cobbled_deepslate
setblock 49 113 561 minecraft:calcite
fill 49 113 562 49 114 562 minecraft:cobbled_deepslate
setblock 49 113 566 minecraft:calcite
setblock 49 113 567 minecraft:cobbled_deepslate
fill 50 113 599 50 208 599 minecraft:cobbled_deepslate
fill 51 113 557 53 206 557 minecraft:cobbled_deepslate
setblock 52 113 558 minecraft:calcite
fill 53 113 599 53 208 599 minecraft:cobbled_deepslate
fill 56 113 557 57 204 557 minecraft:cobbled_deepslate
fill 57 113 599 57 210 599 minecraft:cobbled_deepslate
fill 58 113 598 61 113 598 minecraft:cobbled_deepslate
fill 59 113 558 61 113 558 minecraft:cobbled_deepslate
setblock 62 113 558 minecraft:calcite
setblock 62 113 598 minecraft:calcite
fill 63 113 558 66 113 558 minecraft:cobbled_deepslate
setblock 63 113 597 minecraft:calcite
fill 63 113 598 63 116 599 minecraft:cobbled_deepslate
fill 65 113 585 69 167 585 minecraft:calcite
fill 66 113 584 68 167 584 minecraft:calcite
fill 66 113 586 68 167 586 minecraft:calcite
fill 66 113 598 66 113 599 minecraft:cobbled_deepslate
fill 67 113 583 67 167 583 minecraft:calcite
fill 67 113 587 67 167 587 minecraft:calcite
setblock 67 113 598 minecraft:calcite
fill 68 113 599 68 208 599 minecraft:cobbled_deepslate
fill 77 113 599 77 209 599 minecraft:cobbled_deepslate
fill 79 113 557 80 208 557 minecraft:cobbled_deepslate
fill 80 113 558 81 113 558 minecraft:cobbled_deepslate
setblock 82 113 558 minecraft:calcite
fill 82 113 559 85 113 559 minecraft:cobbled_deepslate
fill 83 113 558 83 116 558 minecraft:cobbled_deepslate
fill 83 113 560 84 113 560 minecraft:cobbled_deepslate
fill 84 113 557 84 209 557 minecraft:cobbled_deepslate
setblock 85 113 560 minecraft:calcite
fill 85 113 562 85 113 564 minecraft:cobbled_deepslate
setblock 85 113 565 minecraft:calcite
fill 85 113 566 85 116 566 minecraft:cobbled_deepslate
setblock 86 113 558 minecraft:cobbled_deepslate
setblock 86 113 559 minecraft:calcite
fill 86 113 560 86 113 563 minecraft:cobbled_deepslate
setblock 86 113 564 minecraft:calcite
fill 86 113 565 86 116 565 minecraft:cobbled_deepslate
fill 86 113 567 86 113 568 minecraft:cobbled_deepslate
setblock 86 113 569 minecraft:calcite
fill 86 113 570 86 116 570 minecraft:cobbled_deepslate
setblock 87 113 558 minecraft:calcite
fill 87 113 559 87 113 562 minecraft:cobbled_deepslate
setblock 87 113 563 minecraft:calcite
fill 87 113 564 87 116 564 minecraft:cobbled_deepslate
setblock 87 113 567 minecraft:cobbled_deepslate
setblock 87 113 568 minecraft:calcite
fill 87 113 569 87 116 569 minecraft:cobbled_deepslate
setblock 87 113 572 minecraft:cobbled_deepslate
setblock 87 113 582 minecraft:cobbled_deepslate
setblock 87 113 583 minecraft:calcite
fill 87 113 584 87 113 587 minecraft:cobbled_deepslate
setblock 87 113 588 minecraft:calcite
fill 87 113 599 87 208 599 minecraft:cobbled_deepslate
fill 88 113 558 88 113 561 minecraft:cobbled_deepslate
setblock 88 113 562 minecraft:calcite
fill 88 113 563 88 116 563 minecraft:cobbled_deepslate
setblock 88 113 567 minecraft:calcite
fill 88 113 568 88 116 568 minecraft:cobbled_deepslate
setblock 88 113 572 minecraft:calcite
fill 88 113 573 88 113 575 minecraft:cobbled_deepslate
fill 88 113 578 88 113 581 minecraft:cobbled_deepslate
setblock 88 113 582 minecraft:calcite
fill 88 113 583 88 113 586 minecraft:cobbled_deepslate
setblock 88 113 587 minecraft:calcite
fill 88 113 588 88 115 588 minecraft:cobbled_deepslate
fill 88 113 590 88 114 590 minecraft:cobbled_deepslate
fill 89 113 559 89 208 559 minecraft:cobbled_deepslate
fill 89 113 567 89 205 567 minecraft:cobbled_deepslate
fill 89 113 572 89 205 572 minecraft:cobbled_deepslate
fill 89 113 574 89 208 575 minecraft:cobbled_deepslate
fill 89 113 594 89 208 594 minecraft:cobbled_deepslate
fill 89 113 597 89 208 597 minecraft:cobbled_deepslate
fill 47 114 559 48 115 559 minecraft:cobbled_deepslate
fill 47 114 565 48 114 565 minecraft:cobbled_deepslate
fill 47 114 598 48 114 598 minecraft:cobbled_deepslate
fill 48 114 558 50 114 558 minecraft:cobbled_deepslate
setblock 48 114 560 minecraft:cobbled_deepslate
setblock 48 114 561 minecraft:calcite
fill 48 114 562 48 117 562 minecraft:cobbled_deepslate
setblock 48 114 566 minecraft:calcite
fill 48 114 567 48 117 567 minecraft:cobbled_deepslate
fill 48 114 584 48 114 585 minecraft:cobbled_deepslate
setblock 48 114 586 minecraft:calcite
fill 48 114 587 48 114 590 minecraft:cobbled_deepslate
setblock 48 114 591 minecraft:calcite
fill 48 114 592 48 117 592 minecraft:cobbled_deepslate
setblock 49 114 560 minecraft:calcite
setblock 49 114 561 minecraft:cobbled_deepslate
setblock 49 114 565 minecraft:calcite
setblock 49 114 566 minecraft:cobbled_deepslate
fill 59 114 598 60 114 598 minecraft:cobbled_deepslate
setblock 61 114 558 minecraft:calcite
setblock 61 114 598 minecraft:calcite
fill 62 114 558 64 114 558 minecraft:cobbled_deepslate
fill 62 114 598 62 117 598 minecraft:cobbled_deepslate
fill 64 114 585 64 115 585 minecraft:deepslate
fill 65 114 583 65 115 584 minecraft:deepslate
fill 65 114 586 65 115 587 minecraft:deepslate
fill 66 114 583 66 115 583 minecraft:deepslate
fill 66 114 587 66 115 587 minecraft:deepslate
fill 66 114 599 66 208 599 minecraft:cobbled_deepslate
fill 67 114 588 67 115 588 minecraft:deepslate
fill 68 114 583 69 115 583 minecraft:deepslate
fill 68 114 587 69 115 587 minecraft:deepslate
fill 69 114 584 69 115 584 minecraft:deepslate
fill 69 114 586 69 115 586 minecraft:deepslate
setblock 81 114 558 minecraft:calcite
fill 82 114 558 82 114 559 minecraft:cobbled_deepslate
fill 83 114 559 84 114 559 minecraft:cobbled_deepslate
setblock 84 114 560 minecraft:calcite
setblock 85 114 559 minecraft:calcite
fill 85 114 560 88 114 560 minecraft:cobbled_deepslate
setblock 85 114 563 minecraft:cobbled_deepslate
setblock 85 114 564 minecraft:calcite
fill 85 114 565 85 115 565 minecraft:cobbled_deepslate
setblock 86 114 558 minecraft:calcite
fill 86 114 559 88 114 559 minecraft:cobbled_deepslate
fill 86 114 561 86 114 562 minecraft:cobbled_deepslate
setblock 86 114 563 minecraft:calcite
fill 86 114 564 86 117 564 minecraft:cobbled_deepslate
setblock 86 114 567 minecraft:cobbled_deepslate
setblock 86 114 568 minecraft:calcite
fill 86 114 569 86 117 569 minecraft:cobbled_deepslate
fill 87 114 558 88 116 558 minecraft:cobbled_deepslate
setblock 87 114 561 minecraft:cobbled_deepslate
setblock 87 114 562 minecraft:calcite
fill 87 114 563 87 117 563 minecraft:cobbled_deepslate
setblock 87 114 566 minecraft:cobbled_deepslate
setblock 87 114 567 minecraft:calcite
fill 87 114 568 87 117 568 minecraft:cobbled_deepslate
setblock 87 114 572 minecraft:calcite
setblock 88 114 561 minecraft:calcite
fill 88 114 562 88 117 562 minecraft:cobbled_deepslate
setblock 88 114 566 minecraft:calcite
fill 88 114 567 88 117 567 minecraft:cobbled_deepslate
setblock 88 114 571 minecraft:calcite
fill 88 114 572 88 114 573 minecraft:cobbled_deepslate
fill 88 114 582 88 114 585 minecraft:cobbled_deepslate
setblock 88 114 586 minecraft:calcite
fill 88 114 587 88 115 587 minecraft:cobbled_deepslate
fill 89 114 571 89 208 571 minecraft:cobbled_deepslate
fill 47 115 565 47 204 565 minecraft:cobbled_deepslate
fill 47 115 598 47 208 598 minecraft:cobbled_deepslate
setblock 48 115 558 minecraft:cobbled_deepslate
setblock 48 115 560 minecraft:calcite
fill 48 115 561 48 117 561 minecraft:cobbled_deepslate
fill 48 115 563 48 115 564 minecraft:cobbled_deepslate
setblock 48 115 565 minecraft:calcite
fill 48 115 566 48 118 566 minecraft:cobbled_deepslate
setblock 48 115 585 minecraft:calcite
fill 48 115 586 48 115 589 minecraft:cobbled_deepslate
setblock 48 115 590 minecraft:calcite
fill 48 115 591 48 118 591 minecraft:cobbled_deepslate
setblock 59 115 598 minecraft:cobbled_deepslate
setblock 60 115 598 minecraft:calcite
fill 61 115 598 61 118 598 minecraft:cobbled_deepslate
fill 64 115 583 64 115 584 minecraft:deepslate
fill 64 115 586 64 115 587 minecraft:deepslate
fill 64 115 598 64 115 599 minecraft:cobbled_deepslate
fill 65 115 582 69 115 582 minecraft:deepslate
fill 65 115 588 66 115 588 minecraft:deepslate
fill 65 115 599 65 208 599 minecraft:cobbled_deepslate
fill 68 115 588 69 115 588 minecraft:deepslate
fill 70 115 583 70 115 587 minecraft:deepslate
fill 81 115 558 82 117 558 minecraft:cobbled_deepslate
setblock 83 115 559 minecraft:cobbled_deepslate
setblock 84 115 559 minecraft:calcite
setblock 85 115 558 minecraft:calcite
fill 85 115 559 86 115 559 minecraft:cobbled_deepslate
setblock 85 115 564 minecraft:cobbled_deepslate
setblock 85 115 567 minecraft:cobbled_deepslate
fill 86 115 558 86 118 558 minecraft:cobbled_deepslate
setblock 86 115 562 minecraft:calcite
fill 86 115 563 86 116 563 minecraft:cobbled_deepslate
setblock 86 115 567 minecraft:calcite
fill 86 115 568 86 118 568 minecraft:cobbled_deepslate
setblock 87 115 560 minecraft:cobbled_deepslate
setblock 87 115 561 minecraft:calcite
fill 87 115 562 87 118 562 minecraft:cobbled_deepslate
setblock 87 115 566 minecraft:calcite
fill 87 115 567 87 118 567 minecraft:cobbled_deepslate
setblock 87 115 571 minecraft:calcite
setblock 88 115 559 minecraft:cobbled_deepslate
setblock 88 115 560 minecraft:calcite
fill 88 115 561 88 118 561 minecraft:cobbled_deepslate
setblock 88 115 565 minecraft:calcite
fill 88 115 566 88 118 566 minecraft:cobbled_deepslate
setblock 88 115 570 minecraft:calcite
fill 88 115 571 88 117 572 minecraft:cobbled_deepslate
setblock 88 115 585 minecraft:calcite
setblock 88 115 586 minecraft:cobbled_deepslate
fill 89 115 565 89 205 565 minecraft:cobbled_deepslate
fill 47 116 559 47 204 559 minecraft:cobbled_deepslate
setblock 48 116 559 minecraft:calcite
setblock 48 116 560 minecraft:cobbled_deepslate
setblock 48 116 563 minecraft:cobbled_deepslate
setblock 48 116 564 minecraft:calcite
fill 48 116 565 48 119 565 minecraft:cobbled_deepslate
setblock 48 116 569 minecraft:calcite
fill 48 116 586 48 116 588 minecraft:cobbled_deepslate
setblock 48 116 589 minecraft:calcite
fill 48 116 590 48 119 590 minecraft:cobbled_deepslate
setblock 48 116 594 minecraft:calcite
setblock 50 116 560 minecraft:light[level=14]
setblock 50 116 568 minecraft:light[level=14]
setblock 50 116 576 minecraft:light[level=14]
setblock 50 116 584 minecraft:light[level=14]
setblock 50 116 592 minecraft:light[level=14]
setblock 58 116 560 minecraft:light[level=14]
setblock 58 116 568 minecraft:light[level=14]
setblock 58 116 576 minecraft:light[level=14]
setblock 58 116 584 minecraft:light[level=14]
setblock 58 116 592 minecraft:light[level=14]
setblock 58 116 598 minecraft:cobbled_deepslate
setblock 59 116 598 minecraft:calcite
fill 60 116 598 60 119 598 minecraft:cobbled_deepslate
setblock 64 116 598 minecraft:calcite
fill 64 116 599 64 208 599 minecraft:cobbled_deepslate
setblock 66 116 560 minecraft:light[level=14]
setblock 66 116 568 minecraft:light[level=14]
setblock 66 116 576 minecraft:light[level=14]
setblock 66 116 592 minecraft:light[level=14]
setblock 74 116 560 minecraft:light[level=14]
setblock 74 116 568 minecraft:light[level=14]
setblock 74 116 576 minecraft:light[level=14]
setblock 74 116 584 minecraft:light[level=14]
setblock 74 116 592 minecraft:light[level=14]
setblock 82 116 560 minecraft:light[level=14]
setblock 82 116 568 minecraft:light[level=14]
setblock 82 116 576 minecraft:light[level=14]
setblock 82 116 584 minecraft:light[level=14]
setblock 82 116 592 minecraft:light[level=14]
setblock 83 116 559 minecraft:calcite
setblock 84 116 558 minecraft:calcite
setblock 84 116 559 minecraft:cobbled_deepslate
fill 85 116 558 85 119 558 minecraft:cobbled_deepslate
setblock 85 116 567 minecraft:calcite
setblock 86 116 566 minecraft:calcite
fill 86 116 567 86 119 567 minecraft:cobbled_deepslate
fill 87 116 561 87 117 561 minecraft:cobbled_deepslate
setblock 87 116 565 minecraft:calcite
fill 87 116 566 87 119 566 minecraft:cobbled_deepslate
setblock 87 116 570 minecraft:calcite
fill 87 116 571 87 119 571 minecraft:cobbled_deepslate
setblock 88 116 559 minecraft:calcite
fill 88 116 560 88 119 560 minecraft:cobbled_deepslate
setblock 88 116 564 minecraft:calcite
fill 88 116 565 88 119 565 minecraft:cobbled_deepslate
setblock 88 116 569 minecraft:calcite
fill 88 116 570 88 119 570 minecraft:cobbled_deepslate
fill 89 116 589 89 205 589 minecraft:cobbled_deepslate
setblock 48 117 563 minecraft:calcite
fill 48 117 564 48 119 564 minecraft:cobbled_deepslate
setblock 48 117 568 minecraft:calcite
fill 48 117 569 48 120 569 minecraft:cobbled_deepslate
setblock 48 117 587 minecraft:cobbled_deepslate
setblock 48 117 588 minecraft:calcite
fill 48 117 589 48 120 589 minecraft:cobbled_deepslate
setblock 48 117 593 minecraft:calcite
fill 48 117 594 48 119 595 minecraft:cobbled_deepslate
setblock 57 117 598 minecraft:cobbled_deepslate
setblock 58 117 598 minecraft:calcite
fill 59 117 598 59 120 598 minecraft:cobbled_deepslate
setblock 63 117 598 minecraft:calcite
fill 63 117 599 63 208 599 minecraft:cobbled_deepslate
fill 64 117 598 64 120 598 minecraft:cobbled_deepslate
fill 80 117 558 80 119 558 minecraft:cobbled_deepslate
setblock 83 117 558 minecraft:calcite
fill 84 117 558 84 120 558 minecraft:cobbled_deepslate
setblock 86 117 565 minecraft:calcite
fill 86 117 566 86 120 566 minecraft:cobbled_deepslate
setblock 86 117 570 minecraft:calcite
setblock 87 117 558 minecraft:cobbled_deepslate
setblock 87 117 564 minecraft:calcite
fill 87 117 565 87 120 565 minecraft:cobbled_deepslate
setblock 87 117 569 minecraft:calcite
fill 87 117 570 87 120 570 minecraft:cobbled_deepslate
setblock 88 117 559 minecraft:cobbled_deepslate
setblock 88 117 563 minecraft:calcite
fill 88 117 564 88 120 564 minecraft:cobbled_deepslate
setblock 88 117 568 minecraft:calcite
fill 88 117 569 88 120 569 minecraft:cobbled_deepslate
setblock 48 118 563 minecraft:cobbled_deepslate
setblock 48 118 567 minecraft:calcite
fill 48 118 568 48 121 568 minecraft:cobbled_deepslate
setblock 48 118 587 minecraft:calcite
fill 48 118 588 48 121 588 minecraft:cobbled_deepslate
setblock 48 118 592 minecraft:calcite
fill 48 118 593 48 121 593 minecraft:cobbled_deepslate
setblock 48 118 596 minecraft:cobbled_deepslate
setblock 56 118 598 minecraft:cobbled_deepslate
setblock 57 118 598 minecraft:calcite
fill 58 118 598 58 121 598 minecraft:cobbled_deepslate
fill 59 118 597 62 118 597 minecraft:cobbled_deepslate
setblock 62 118 598 minecraft:calcite
fill 63 118 598 63 121 598 minecraft:cobbled_deepslate
setblock 81 118 558 minecraft:cobbled_deepslate
setblock 82 118 558 minecraft:calcite
fill 83 118 558 83 121 558 minecraft:cobbled_deepslate
fill 84 118 589 84 126 589 minecraft:deepslate
setblock 86 118 564 minecraft:calcite
fill 86 118 565 86 119 565 minecraft:cobbled_deepslate
setblock 86 118 569 minecraft:calcite
fill 86 118 570 86 121 570 minecraft:cobbled_deepslate
setblock 87 118 558 minecraft:calcite
setblock 87 118 563 minecraft:calcite
fill 87 118 564 87 121 564 minecraft:cobbled_deepslate
setblock 87 118 568 minecraft:calcite
fill 87 118 569 87 121 569 minecraft:cobbled_deepslate
setblock 88 118 562 minecraft:calcite
fill 88 118 563 88 121 563 minecraft:cobbled_deepslate
setblock 88 118 567 minecraft:calcite
fill 88 118 568 88 121 568 minecraft:cobbled_deepslate
setblock 88 118 571 minecraft:cobbled_deepslate
setblock 88 118 572 minecraft:calcite
setblock 48 119 566 minecraft:calcite
fill 48 119 567 48 121 567 minecraft:cobbled_deepslate
fill 48 119 587 48 122 587 minecraft:cobbled_deepslate
setblock 48 119 591 minecraft:calcite
fill 48 119 592 49 121 592 minecraft:cobbled_deepslate
setblock 48 119 596 minecraft:calcite
fill 48 119 597 48 121 598 minecraft:cobbled_deepslate
fill 49 119 591 49 122 591 minecraft:cobbled_deepslate
fill 54 119 598 55 119 598 minecraft:cobbled_deepslate
setblock 56 119 597 minecraft:cobbled_deepslate
setblock 56 119 598 minecraft:calcite
setblock 57 119 597 minecraft:calcite
fill 57 119 598 57 122 598 minecraft:cobbled_deepslate
fill 58 119 597 61 119 597 minecraft:cobbled_deepslate
fill 59 119 596 60 121 596 minecraft:cobbled_deepslate
setblock 61 119 598 minecraft:calcite
setblock 62 119 597 minecraft:calcite
fill 62 119 598 62 122 598 minecraft:cobbled_deepslate
fill 79 119 558 79 120 558 minecraft:cobbled_deepslate
setblock 81 119 558 minecraft:calcite
fill 81 119 559 83 120 559 minecraft:cobbled_deepslate
setblock 81 119 598 minecraft:calcite
fill 82 119 558 82 122 558 minecraft:cobbled_deepslate
fill 82 119 598 84 120 598 minecraft:cobbled_deepslate
setblock 86 119 558 minecraft:calcite
setblock 86 119 568 minecraft:calcite
fill 86 119 569 86 122 569 minecraft:cobbled_deepslate
fill 87 119 558 87 122 558 minecraft:cobbled_deepslate
setblock 87 119 563 minecraft:cobbled_deepslate
setblock 87 119 567 minecraft:calcite
fill 87 119 568 87 122 568 minecraft:cobbled_deepslate
setblock 88 119 561 minecraft:calcite
fill 88 119 562 88 122 562 minecraft:cobbled_deepslate
setblock 88 119 566 minecraft:calcite
fill 88 119 567 88 122 567 minecraft:cobbled_deepslate
setblock 88 119 571 minecraft:calcite
fill 88 119 572 88 121 573 minecraft:cobbled_deepslate
setblock 88 119 590 minecraft:cobbled_deepslate
setblock 88 119 591 minecraft:calcite
fill 88 119 592 88 121 593 minecraft:cobbled_deepslate
setblock 48 120 566 minecraft:cobbled_deepslate
setblock 48 120 570 minecraft:calcite
setblock 48 120 590 minecraft:calcite
fill 48 120 591 48 123 591 minecraft:cobbled_deepslate
setblock 48 120 594 minecraft:cobbled_deepslate
setblock 48 120 595 minecraft:calcite
fill 48 120 596 48 123 596 minecraft:cobbled_deepslate
fill 49 120 590 49 123 590 minecraft:cobbled_deepslate
setblock 49 120 593 minecraft:cobbled_deepslate
setblock 49 120 594 minecraft:calcite
fill 49 120 595 49 123 595 minecraft:cobbled_deepslate
setblock 49 120 598 minecraft:cobbled_deepslate
setblock 50 120 598 minecraft:calcite
fill 51 120 598 54 120 598 minecraft:cobbled_deepslate
fill 54 120 597 55 120 597 minecraft:cobbled_deepslate
setblock 55 120 598 minecraft:calcite
setblock 56 120 596 minecraft:cobbled_deepslate
setblock 56 120 597 minecraft:calcite
fill 56 120 598 56 123 598 minecraft:cobbled_deepslate
setblock 57 120 596 minecraft:calcite
fill 57 120 597 60 120 597 minecraft:cobbled_deepslate
fill 58 120 596 58 123 596 minecraft:cobbled_deepslate
setblock 60 120 598 minecraft:calcite
setblock 61 120 596 minecraft:cobbled_deepslate
setblock 61 120 597 minecraft:calcite
fill 61 120 598 61 123 598 minecraft:cobbled_deepslate
setblock 62 120 596 minecraft:calcite
fill 62 120 597 63 122 597 minecraft:cobbled_deepslate
fill 78 120 558 78 121 558 minecraft:cobbled_deepslate
fill 78 120 598 79 120 598 minecraft:cobbled_deepslate
setblock 80 120 558 minecraft:calcite
fill 80 120 559 80 123 559 minecraft:cobbled_deepslate
setblock 80 120 598 minecraft:calcite
fill 81 120 558 81 123 558 minecraft:cobbled_deepslate
fill 81 120 598 81 123 598 minecraft:cobbled_deepslate
setblock 84 120 559 minecraft:calcite
setblock 85 120 558 minecraft:calcite
setblock 85 120 598 minecraft:calcite
fill 86 120 558 86 123 558 minecraft:cobbled_deepslate
setblock 86 120 567 minecraft:calcite
fill 86 120 568 86 121 568 minecraft:cobbled_deepslate
fill 86 120 598 86 123 598 minecraft:cobbled_deepslate
setblock 87 120 566 minecraft:calcite
fill 87 120 567 87 123 567 minecraft:cobbled_deepslate
setblock 87 120 571 minecraft:calcite
fill 87 120 572 87 123 572 minecraft:cobbled_deepslate
setblock 88 120 560 minecraft:calcite
fill 88 120 561 88 123 561 minecraft:cobbled_deepslate
setblock 88 120 565 minecraft:calcite
fill 88 120 566 88 123 566 minecraft:cobbled_deepslate
setblock 88 120 570 minecraft:calcite
fill 88 120 571 88 123 571 minecraft:cobbled_deepslate
setblock 88 120 590 minecraft:calcite
fill 88 120 591 88 123 591 minecraft:cobbled_deepslate
setblock 88 120 594 minecraft:cobbled_deepslate
setblock 88 120 595 minecraft:calcite
fill 88 120 596 88 123 596 minecraft:cobbled_deepslate
setblock 48 121 569 minecraft:calcite
fill 48 121 570 48 123 571 minecraft:cobbled_deepslate
setblock 48 121 589 minecraft:calcite
fill 48 121 590 48 124 590 minecraft:cobbled_deepslate
setblock 48 121 594 minecraft:calcite
fill 48 121 595 48 124 595 minecraft:cobbled_deepslate
setblock 49 121 593 minecraft:calcite
fill 49 121 594 49 124 594 minecraft:cobbled_deepslate
fill 49 121 596 49 122 596 minecraft:cobbled_deepslate
setblock 49 121 598 minecraft:calcite
fill 50 121 598 53 121 598 minecraft:cobbled_deepslate
fill 51 121 597 54 121 597 minecraft:cobbled_deepslate
fill 54 121 596 55 121 596 minecraft:cobbled_deepslate
setblock 54 121 598 minecraft:calcite
setblock 55 121 597 minecraft:calcite
fill 55 121 598 55 124 598 minecraft:cobbled_deepslate
setblock 56 121 596 minecraft:calcite
fill 56 121 597 59 121 597 minecraft:cobbled_deepslate
fill 57 121 558 58 121 558 minecraft:cobbled_deepslate
setblock 57 121 595 minecraft:calcite
fill 57 121 596 57 124 596 minecraft:cobbled_deepslate
fill 58 121 595 61 121 595 minecraft:cobbled_deepslate
setblock 59 121 558 minecraft:calcite
setblock 59 121 598 minecraft:calcite
fill 60 121 558 60 124 558 minecraft:cobbled_deepslate
setblock 60 121 597 minecraft:calcite
fill 60 121 598 60 124 598 minecraft:cobbled_deepslate
setblock 61 121 596 minecraft:calcite
fill 61 121 597 61 124 597 minecraft:cobbled_deepslate
fill 62 121 596 62 124 596 minecraft:cobbled_deepslate
setblock 64 121 598 minecraft:calcite
fill 65 121 598 65 124 598 minecraft:cobbled_deepslate
fill 76 121 558 77 122 558 minecraft:cobbled_deepslate
fill 77 121 598 78 121 598 minecraft:cobbled_deepslate
setblock 79 121 558 minecraft:calcite
fill 79 121 559 79 124 559 minecraft:cobbled_deepslate
setblock 79 121 597 minecraft:cobbled_deepslate
setblock 79 121 598 minecraft:calcite
fill 80 121 558 80 124 558 minecraft:cobbled_deepslate
setblock 80 121 597 minecraft:calcite
fill 80 121 598 80 124 598 minecraft:cobbled_deepslate
fill 81 121 559 82 121 559 minecraft:cobbled_deepslate
fill 81 121 597 83 122 597 minecraft:cobbled_deepslate
fill 82 121 598 83 121 598 minecraft:cobbled_deepslate
setblock 83 121 559 minecraft:calcite
setblock 84 121 558 minecraft:calcite
fill 84 121 559 84 124 559 minecraft:cobbled_deepslate
setblock 84 121 598 minecraft:calcite
fill 85 121 558 85 124 558 minecraft:cobbled_deepslate
fill 85 121 598 85 124 598 minecraft:cobbled_deepslate
setblock 86 121 567 minecraft:cobbled_deepslate
setblock 87 121 565 minecraft:calcite
fill 87 121 566 87 122 566 minecraft:cobbled_deepslate
setblock 87 121 570 minecraft:calcite
fill 87 121 571 87 124 571 minecraft:cobbled_deepslate
fill 87 121 598 88 121 598 minecraft:cobbled_deepslate
setblock 88 121 558 minecraft:cobbled_deepslate
setblock 88 121 559 minecraft:calcite
fill 88 121 560 88 124 560 minecraft:cobbled_deepslate
setblock 88 121 564 minecraft:calcite
fill 88 121 565 88 124 565 minecraft:cobbled_deepslate
setblock 88 121 569 minecraft:calcite
fill 88 121 570 88 124 570 minecraft:cobbled_deepslate
setblock 88 121 574 minecraft:calcite
fill 88 121 590 88 124 590 minecraft:cobbled_deepslate
setblock 88 121 594 minecraft:calcite
fill 88 121 595 88 124 595 minecraft:cobbled_deepslate
fill 88 121 597 88 122 597 minecraft:cobbled_deepslate
setblock 48 122 568 minecraft:calcite
setblock 48 122 569 minecraft:cobbled_deepslate
setblock 48 122 572 minecraft:cobbled_deepslate
setblock 48 122 588 minecraft:calcite
fill 48 122 589 49 123 589 minecraft:cobbled_deepslate
setblock 48 122 592 minecraft:cobbled_deepslate
setblock 48 122 593 minecraft:calcite
fill 48 122 594 48 125 594 minecraft:cobbled_deepslate
setblock 48 122 597 minecraft:cobbled_deepslate
setblock 48 122 598 minecraft:calcite
setblock 49 122 592 minecraft:calcite
fill 49 122 593 50 124 593 minecraft:cobbled_deepslate
setblock 49 122 597 minecraft:calcite
fill 49 122 598 52 122 598 minecraft:cobbled_deepslate
fill 50 122 592 50 125 592 minecraft:cobbled_deepslate
fill 50 122 594 50 123 594 minecraft:cobbled_deepslate
fill 50 122 597 53 122 597 minecraft:cobbled_deepslate
fill 52 122 596 54 122 596 minecraft:cobbled_deepslate
setblock 53 122 598 minecraft:calcite
setblock 54 122 597 minecraft:calcite
fill 54 122 598 54 125 598 minecraft:cobbled_deepslate
fill 55 122 558 57 122 558 minecraft:cobbled_deepslate
setblock 55 122 595 minecraft:cobbled_deepslate
setblock 55 122 596 minecraft:calcite
fill 55 122 597 58 122 597 minecraft:cobbled_deepslate
setblock 56 122 595 minecraft:calcite
fill 56 122 596 56 125 596 minecraft:cobbled_deepslate
fill 57 122 595 60 122 595 minecraft:cobbled_deepslate
setblock 58 122 558 minecraft:calcite
setblock 58 122 598 minecraft:calcite
fill 59 122 558 59 125 558 minecraft:cobbled_deepslate
setblock 59 122 596 minecraft:cobbled_deepslate
setblock 59 122 597 minecraft:calcite
fill 59 122 598 59 125 598 minecraft:cobbled_deepslate
setblock 60 122 596 minecraft:calcite
fill 60 122 597 60 125 597 minecraft:cobbled_deepslate
fill 61 122 558 61 123 558 minecraft:cobbled_deepslate
setblock 61 122 595 minecraft:calcite
fill 61 122 596 61 125 596 minecraft:cobbled_deepslate
setblock 63 122 598 minecraft:calcite
setblock 64 122 597 minecraft:calcite
fill 64 122 598 64 125 598 minecraft:cobbled_deepslate
fill 75 122 558 75 124 558 minecraft:cobbled_deepslate
fill 75 122 598 77 122 598 minecraft:cobbled_deepslate
setblock 77 122 559 minecraft:calcite
fill 77 122 597 78 122 597 minecraft:cobbled_deepslate
setblock 78 122 558 minecraft:calcite
fill 78 122 559 78 125 559 minecraft:cobbled_deepslate
setblock 78 122 598 minecraft:calcite
fill 79 122 558 79 125 558 minecraft:cobbled_deepslate
setblock 79 122 597 minecraft:calcite
fill 79 122 598 79 125 598 minecraft:cobbled_deepslate
fill 80 122 597 80 125 597 minecraft:cobbled_deepslate
setblock 81 122 559 minecraft:cobbled_deepslate
setblock 82 122 559 minecraft:calcite
setblock 82 122 598 minecraft:cobbled_deepslate
setblock 83 122 558 minecraft:calcite
fill 83 122 559 83 125 559 minecraft:cobbled_deepslate
setblock 83 122 598 minecraft:calcite
fill 84 122 558 84 125 558 minecraft:cobbled_deepslate
setblock 84 122 597 minecraft:calcite
fill 84 122 598 84 125 598 minecraft:cobbled_deepslate
fill 85 122 597 85 125 597 minecraft:cobbled_deepslate
setblock 86 122 570 minecraft:calcite
setblock 87 122 565 minecraft:cobbled_deepslate
setblock 87 122 569 minecraft:calcite
fill 87 122 570 87 124 570 minecraft:cobbled_deepslate
setblock 87 122 594 minecraft:calcite
fill 87 122 595 87 125 595 minecraft:cobbled_deepslate
setblock 87 122 598 minecraft:cobbled_deepslate
setblock 88 122 558 minecraft:calcite
fill 88 122 559 88 125 559 minecraft:cobbled_deepslate
setblock 88 122 563 minecraft:calcite
fill 88 122 564 88 123 564 minecraft:cobbled_deepslate
setblock 88 122 568 minecraft:calcite
fill 88 122 569 88 125 569 minecraft:cobbled_deepslate
setblock 88 122 572 minecraft:cobbled_deepslate
setblock 88 122 573 minecraft:calcite
fill 88 122 574 88 125 574 minecraft:cobbled_deepslate
setblock 88 122 592 minecraft:cobbled_deepslate
setblock 88 122 593 minecraft:calcite
fill 88 122 594 88 125 594 minecraft:cobbled_deepslate
setblock 88 122 598 minecraft:calcite
setblock 48 123 572 minecraft:calcite
setblock 48 123 587 minecraft:calcite
fill 48 123 588 48 125 588 minecraft:cobbled_deepslate
setblock 48 123 592 minecraft:calcite
fill 48 123 593 48 126 593 minecraft:cobbled_deepslate
setblock 48 123 597 minecraft:calcite
fill 48 123 598 51 123 598 minecraft:cobbled_deepslate
setblock 49 123 591 minecraft:calcite
fill 49 123 592 49 126 592 minecraft:cobbled_deepslate
setblock 49 123 596 minecraft:calcite
fill 49 123 597 52 123 597 minecraft:cobbled_deepslate
setblock 50 123 595 minecraft:calcite
fill 50 123 596 53 123 596 minecraft:cobbled_deepslate
setblock 52 123 598 minecraft:calcite
setblock 53 123 597 minecraft:calcite
fill 53 123 598 53 126 598 minecraft:cobbled_deepslate
fill 54 123 558 56 123 558 minecraft:cobbled_deepslate
setblock 54 123 595 minecraft:cobbled_deepslate
setblock 54 123 596 minecraft:calcite
fill 54 123 597 57 123 597 minecraft:cobbled_deepslate
setblock 55 123 595 minecraft:calcite
fill 55 123 596 55 126 596 minecraft:cobbled_deepslate
fill 56 123 595 59 123 595 minecraft:cobbled_deepslate
setblock 57 123 558 minecraft:calcite
fill 57 123 594 58 124 594 minecraft:cobbled_deepslate
setblock 57 123 598 minecraft:calcite
fill 58 123 558 58 126 558 minecraft:cobbled_deepslate
setblock 58 123 597 minecraft:calcite
fill 58 123 598 58 126 598 minecraft:cobbled_deepslate
setblock 59 123 596 minecraft:calcite
fill 59 123 597 59 126 597 minecraft:cobbled_deepslate
setblock 60 123 595 minecraft:calcite
fill 60 123 596 60 126 596 minecraft:cobbled_deepslate
fill 61 123 595 61 124 595 minecraft:cobbled_deepslate
setblock 62 123 597 minecraft:cobbled_deepslate
setblock 62 123 598 minecraft:calcite
setblock 63 123 597 minecraft:calcite
fill 63 123 598 63 126 598 minecraft:cobbled_deepslate
setblock 64 123 597 minecraft:cobbled_deepslate
fill 74 123 558 74 125 558 minecraft:cobbled_deepslate
fill 74 123 598 76 123 598 minecraft:cobbled_deepslate
setblock 76 123 558 minecraft:cobbled_deepslate
setblock 76 123 559 minecraft:calcite
fill 76 123 597 77 123 597 minecraft:cobbled_deepslate
setblock 77 123 558 minecraft:calcite
fill 77 123 559 77 126 559 minecraft:cobbled_deepslate
setblock 77 123 598 minecraft:calcite
fill 78 123 558 78 126 558 minecraft:cobbled_deepslate
setblock 78 123 596 minecraft:cobbled_deepslate
setblock 78 123 597 minecraft:calcite
fill 78 123 598 78 126 598 minecraft:cobbled_deepslate
setblock 79 123 596 minecraft:calcite
fill 79 123 597 79 126 597 minecraft:cobbled_deepslate
fill 80 123 596 81 125 596 minecraft:cobbled_deepslate
setblock 81 123 559 minecraft:calcite
fill 81 123 597 82 123 597 minecraft:cobbled_deepslate
setblock 82 123 558 minecraft:calcite
fill 82 123 559 82 126 559 minecraft:cobbled_deepslate
setblock 82 123 598 minecraft:calcite
fill 83 123 558 83 126 558 minecraft:cobbled_deepslate
fill 83 123 589 83 126 589 minecraft:deepslate
setblock 83 123 597 minecraft:calcite
fill 83 123 598 83 126 598 minecraft:cobbled_deepslate
fill 84 123 588 84 126 588 minecraft:deepslate
fill 84 123 590 84 126 590 minecraft:deepslate
fill 84 123 597 84 126 597 minecraft:cobbled_deepslate
fill 85 123 589 85 126 589 minecraft:deepslate
fill 86 123 597 87 123 597 minecraft:cobbled_deepslate
setblock 87 123 558 minecraft:calcite
setblock 87 123 568 minecraft:calcite
setblock 87 123 569 minecraft:cobbled_deepslate
setblock 87 123 593 minecraft:calcite
fill 87 123 594 87 125 594 minecraft:cobbled_deepslate
fill 87 123 596 87 124 596 minecraft:cobbled_deepslate
setblock 87 123 598 minecraft:calcite
fill 88 123 558 88 126 558 minecraft:cobbled_deepslate
setblock 88 123 562 minecraft:calcite
setblock 88 123 563 minecraft:cobbled_deepslate
setblock 88 123 567 minecraft:calcite
fill 88 123 568 88 125 568 minecraft:cobbled_deepslate
setblock 88 123 572 minecraft:calcite
fill 88 123 573 88 126 573 minecraft:cobbled_deepslate
setblock 88 123 592 minecraft:calcite
fill 88 123 593 88 126 593 minecraft:cobbled_deepslate
setblock 88 123 597 minecraft:calcite
fill 88 123 598 88 126 598 minecraft:cobbled_deepslate
setblock 48 124 572 minecraft:cobbled_deepslate
fill 48 124 589 48 125 589 minecraft:cobbled_deepslate
setblock 48 124 591 minecraft:calcite
fill 48 124 592 48 127 592 minecraft:cobbled_deepslate
setblock 48 124 596 minecraft:calcite
fill 48 124 597 50 124 598 minecraft:cobbled_deepslate
setblock 49 124 590 minecraft:calcite
fill 49 124 591 49 126 591 minecraft:cobbled_deepslate
setblock 49 124 595 minecraft:calcite
fill 49 124 596 52 124 596 minecraft:cobbled_deepslate
setblock 50 124 560 minecraft:light[level=14]
setblock 50 124 568 minecraft:light[level=14]
setblock 50 124 576 minecraft:light[level=14]
setblock 50 124 584 minecraft:light[level=14]
setblock 50 124 594 minecraft:calcite
fill 50 124 595 50 127 595 minecraft:cobbled_deepslate
setblock 51 124 597 minecraft:cobbled_deepslate
setblock 51 124 598 minecraft:calcite
fill 52 124 558 55 124 558 minecraft:cobbled_deepslate
setblock 52 124 597 minecraft:calcite
fill 52 124 598 52 127 598 minecraft:cobbled_deepslate
setblock 53 124 595 minecraft:cobbled_deepslate
setblock 53 124 596 minecraft:calcite
fill 53 124 597 56 124 597 minecraft:cobbled_deepslate
setblock 54 124 595 minecraft:calcite
fill 54 124 596 54 127 596 minecraft:cobbled_deepslate
fill 55 124 595 58 124 595 minecraft:cobbled_deepslate
setblock 56 124 558 minecraft:calcite
setblock 56 124 598 minecraft:calcite
fill 57 124 558 57 127 558 minecraft:cobbled_deepslate
setblock 57 124 597 minecraft:calcite
fill 57 124 598 57 127 598 minecraft:cobbled_deepslate
setblock 58 124 560 minecraft:light[level=14]
setblock 58 124 568 minecraft:light[level=14]
setblock 58 124 576 minecraft:light[level=14]
setblock 58 124 584 minecraft:light[level=14]
setblock 58 124 592 minecraft:light[level=14]
setblock 58 124 596 minecraft:calcite
fill 58 124 597 58 127 597 minecraft:cobbled_deepslate
setblock 59 124 595 minecraft:calcite
fill 59 124 596 59 127 596 minecraft:cobbled_deepslate
fill 60 124 595 60 125 595 minecraft:cobbled_deepslate
setblock 61 124 558 minecraft:calcite
setblock 61 124 598 minecraft:calcite
setblock 62 124 597 minecraft:calcite
fill 62 124 598 62 127 598 minecraft:cobbled_deepslate
fill 63 124 597 63 125 597 minecraft:cobbled_deepslate
setblock 66 124 560 minecraft:light[level=14]
setblock 66 124 568 minecraft:light[level=14]
setblock 66 124 576 minecraft:light[level=14]
setblock 66 124 592 minecraft:light[level=14]
fill 72 124 598 75 124 598 minecraft:cobbled_deepslate
fill 73 124 558 73 126 558 minecraft:cobbled_deepslate
setblock 74 124 560 minecraft:light[level=14]
setblock 74 124 568 minecraft:light[level=14]
setblock 74 124 576 minecraft:light[level=14]
setblock 74 124 584 minecraft:light[level=14]
setblock 74 124 592 minecraft:light[level=14]
fill 75 124 597 76 124 597 minecraft:cobbled_deepslate
setblock 76 124 558 minecraft:calcite
fill 76 124 559 76 127 559 minecraft:cobbled_deepslate
setblock 76 124 598 minecraft:calcite
fill 77 124 558 77 127 558 minecraft:cobbled_deepslate
setblock 77 124 596 minecraft:cobbled_deepslate
setblock 77 124 597 minecraft:calcite
fill 77 124 598 77 127 598 minecraft:cobbled_deepslate
setblock 78 124 596 minecraft:calcite
fill 78 124 597 78 127 597 minecraft:cobbled_deepslate
fill 79 124 596 79 126 596 minecraft:cobbled_deepslate
setblock 80 124 559 minecraft:calcite
setblock 81 124 558 minecraft:calcite
fill 81 124 559 81 127 559 minecraft:cobbled_deepslate
setblock 81 124 597 minecraft:cobbled_deepslate
setblock 81 124 598 minecraft:calcite
fill 82 124 558 82 127 558 minecraft:cobbled_deepslate
setblock 82 124 560 minecraft:light[level=14]
setblock 82 124 568 minecraft:light[level=14]
setblock 82 124 576 minecraft:light[level=14]
setblock 82 124 584 minecraft:light[level=14]
setblock 82 124 592 minecraft:light[level=14]
setblock 82 124 596 minecraft:cobbled_deepslate
setblock 82 124 597 minecraft:calcite
fill 82 124 598 82 127 598 minecraft:cobbled_deepslate
fill 83 124 597 83 127 597 minecraft:cobbled_deepslate
setblock 86 124 558 minecraft:calcite
setblock 86 124 597 minecraft:cobbled_deepslate
setblock 86 124 598 minecraft:calcite
fill 87 124 558 87 127 558 minecraft:cobbled_deepslate
setblock 87 124 593 minecraft:cobbled_deepslate
setblock 87 124 597 minecraft:calcite
fill 87 124 598 87 127 598 minecraft:cobbled_deepslate
setblock 88 124 566 minecraft:calcite
setblock 88 124 567 minecraft:cobbled_deepslate
setblock 88 124 571 minecraft:calcite
fill 88 124 572 88 126 572 minecraft:cobbled_deepslate
setblock 88 124 575 minecraft:cobbled_deepslate
setblock 88 124 591 minecraft:calcite
fill 88 124 592 88 127 592 minecraft:cobbled_deepslate
setblock 88 124 596 minecraft:calcite
fill 88 124 597 88 127 597 minecraft:cobbled_deepslate
fill 48 125 579 52 126 581 minecraft:light_blue_stained_glass
setblock 48 125 590 minecraft:calcite
fill 48 125 591 48 128 591 minecraft:cobbled_deepslate
setblock 48 125 595 minecraft:calcite
fill 48 125 596 49 125 598 minecraft:cobbled_deepslate
setblock 49 125 590 minecraft:cobbled_deepslate
setblock 49 125 593 minecraft:cobbled_deepslate
setblock 49 125 594 minecraft:calcite
fill 49 125 595 49 128 595 minecraft:cobbled_deepslate
fill 50 125 591 50 128 591 minecraft:light_blue_stained_glass
setblock 50 125 593 minecraft:calcite
fill 50 125 594 50 127 594 minecraft:cobbled_deepslate
fill 50 125 596 50 125 597 minecraft:cobbled_deepslate
setblock 50 125 598 minecraft:calcite
fill 51 125 558 54 125 558 minecraft:cobbled_deepslate
setblock 51 125 596 minecraft:cobbled_deepslate
setblock 51 125 597 minecraft:calcite
fill 51 125 598 51 128 598 minecraft:cobbled_deepslate
setblock 52 125 596 minecraft:calcite
fill 52 125 597 55 125 597 minecraft:cobbled_deepslate
fill 53 125 580 54 125 580 minecraft:light_blue_stained_glass
setblock 53 125 595 minecraft:calcite
fill 53 125 596 53 128 596 minecraft:cobbled_deepslate
fill 54 125 595 57 125 595 minecraft:cobbled_deepslate
setblock 55 125 558 minecraft:calcite
setblock 55 125 598 minecraft:calcite
fill 56 125 558 56 128 558 minecraft:cobbled_deepslate
setblock 56 125 597 minecraft:calcite
fill 56 125 598 56 128 598 minecraft:cobbled_deepslate
setblock 57 125 596 minecraft:calcite
fill 57 125 597 57 128 597 minecraft:cobbled_deepslate
setblock 58 125 595 minecraft:calcite
fill 58 125 596 58 128 596 minecraft:cobbled_deepslate
fill 59 125 595 59 126 595 minecraft:cobbled_deepslate
setblock 60 125 558 minecraft:calcite
setblock 60 125 598 minecraft:calcite
setblock 61 125 558 minecraft:cobbled_deepslate
setblock 61 125 597 minecraft:calcite
fill 61 125 598 61 128 598 minecraft:cobbled_deepslate
setblock 62 125 596 minecraft:calcite
fill 62 125 597 62 126 597 minecraft:cobbled_deepslate
setblock 65 125 598 minecraft:calcite
fill 72 125 558 72 127 558 minecraft:cobbled_deepslate
fill 72 125 598 74 125 598 minecraft:cobbled_deepslate
fill 74 125 597 75 125 597 minecraft:cobbled_deepslate
setblock 75 125 558 minecraft:calcite
fill 75 125 559 75 128 559 minecraft:cobbled_deepslate
setblock 75 125 598 minecraft:calcite
fill 76 125 558 76 128 558 minecraft:cobbled_deepslate
setblock 76 125 597 minecraft:calcite
fill 76 125 598 76 128 598 minecraft:cobbled_deepslate
setblock 77 125 596 minecraft:calcite
fill 77 125 597 77 128 597 minecraft:cobbled_deepslate
fill 78 125 596 78 127 596 minecraft:cobbled_deepslate
setblock 79 125 559 minecraft:calcite
setblock 80 125 558 minecraft:calcite
fill 80 125 559 80 128 559 minecraft:cobbled_deepslate
setblock 80 125 598 minecraft:calcite
fill 81 125 558 81 128 558 minecraft:cobbled_deepslate
setblock 81 125 597 minecraft:calcite
fill 81 125 598 81 128 598 minecraft:cobbled_deepslate
fill 82 125 597 82 128 597 minecraft:cobbled_deepslate
fill 83 125 588 83 126 588 minecraft:deepslate
fill 83 125 590 83 126 590 minecraft:deepslate
setblock 84 125 559 minecraft:calcite
setblock 85 125 558 minecraft:calcite
fill 85 125 561 88 129 561 minecraft:light_blue_stained_glass
fill 85 125 588 85 126 588 minecraft:deepslate
fill 85 125 590 85 126 590 minecraft:deepslate
setblock 85 125 598 minecraft:calcite
fill 86 125 558 86 128 558 minecraft:cobbled_deepslate
fill 86 125 560 88 129 560 minecraft:light_blue_stained_glass
fill 86 125 562 88 130 562 minecraft:light_blue_stained_glass
setblock 86 125 597 minecraft:calcite
fill 86 125 598 86 128 598 minecraft:cobbled_deepslate
setblock 87 125 596 minecraft:calcite
fill 87 125 597 87 128 597 minecraft:cobbled_deepslate
setblock 88 125 570 minecraft:calcite
fill 88 125 571 88 126 571 minecraft:cobbled_deepslate
setblock 88 125 591 minecraft:cobbled_deepslate
setblock 88 125 595 minecraft:calcite
fill 88 125 596 88 128 596 minecraft:cobbled_deepslate
fill 48 126 578 49 127 578 minecraft:light_blue_stained_glass
fill 48 126 582 49 127 582 minecraft:light_blue_stained_glass
schedule function dropper:buildpart/133_4 1t
