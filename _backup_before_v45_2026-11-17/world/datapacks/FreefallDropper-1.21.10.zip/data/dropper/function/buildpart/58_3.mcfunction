setblock 481 253 239 minecraft:light[level=15]
setblock 481 253 247 minecraft:light[level=15]
setblock 481 253 255 minecraft:light[level=15]
setblock 481 253 263 minecraft:light[level=15]
setblock 489 253 231 minecraft:light[level=15]
setblock 489 253 239 minecraft:light[level=15]
setblock 489 253 247 minecraft:light[level=15]
setblock 489 253 255 minecraft:light[level=15]
setblock 489 253 263 minecraft:light[level=15]
setblock 497 253 231 minecraft:light[level=15]
setblock 497 253 239 minecraft:light[level=15]
setblock 497 253 247 minecraft:light[level=15]
setblock 497 253 255 minecraft:light[level=15]
setblock 497 253 263 minecraft:light[level=15]
setblock 505 253 231 minecraft:light[level=15]
setblock 505 253 239 minecraft:light[level=15]
setblock 505 253 247 minecraft:light[level=15]
setblock 505 253 255 minecraft:light[level=15]
setblock 505 253 263 minecraft:light[level=15]
fill 508 253 229 508 257 229 minecraft:red_concrete
setblock 508 253 230 minecraft:white_concrete
fill 508 253 265 508 257 265 minecraft:red_concrete
setblock 508 253 266 minecraft:white_concrete
fill 510 253 232 510 257 233 minecraft:white_concrete
fill 510 253 268 510 257 269 minecraft:white_concrete
setblock 511 253 232 minecraft:red_concrete
setblock 511 253 268 minecraft:red_concrete
fill 471 254 230 472 257 230 minecraft:red_concrete
fill 471 254 266 472 257 266 minecraft:red_concrete
fill 475 254 232 475 258 232 minecraft:white_concrete
fill 475 254 268 475 258 268 minecraft:white_concrete
fill 507 254 230 508 257 230 minecraft:red_concrete
fill 507 254 266 508 257 266 minecraft:red_concrete
fill 511 254 232 511 258 232 minecraft:white_concrete
fill 511 254 268 511 258 268 minecraft:white_concrete
fill 471 255 231 472 259 231 minecraft:red_concrete
setblock 471 255 232 minecraft:white_concrete
fill 471 255 267 472 259 267 minecraft:red_concrete
setblock 471 255 268 minecraft:white_concrete
fill 473 255 231 475 259 231 minecraft:white_concrete
fill 473 255 267 475 259 267 minecraft:white_concrete
setblock 474 255 230 minecraft:red_concrete
setblock 474 255 266 minecraft:red_concrete
fill 475 255 230 475 260 230 minecraft:white_concrete
fill 475 255 266 475 260 266 minecraft:white_concrete
fill 505 255 269 505 265 269 minecraft:brown_terracotta
fill 507 255 231 508 259 231 minecraft:red_concrete
setblock 507 255 232 minecraft:white_concrete
fill 507 255 267 508 259 267 minecraft:red_concrete
setblock 507 255 268 minecraft:white_concrete
fill 509 255 231 511 259 231 minecraft:white_concrete
fill 509 255 267 511 259 267 minecraft:white_concrete
setblock 510 255 230 minecraft:red_concrete
setblock 510 255 266 minecraft:red_concrete
fill 511 255 230 511 260 230 minecraft:white_concrete
fill 511 255 266 511 260 266 minecraft:white_concrete
fill 471 256 232 472 259 232 minecraft:red_concrete
fill 471 256 268 472 259 268 minecraft:red_concrete
setblock 472 256 233 minecraft:white_concrete
setblock 472 256 269 minecraft:white_concrete
setblock 473 256 238 minecraft:light[level=12]
setblock 473 256 245 minecraft:light[level=12]
setblock 473 256 252 minecraft:light[level=12]
setblock 473 256 259 minecraft:light[level=12]
fill 474 256 229 474 260 230 minecraft:white_concrete
fill 474 256 265 474 260 266 minecraft:white_concrete
setblock 480 256 231 minecraft:light[level=12]
setblock 480 256 238 minecraft:light[level=12]
setblock 480 256 245 minecraft:light[level=12]
setblock 480 256 252 minecraft:light[level=12]
setblock 480 256 259 minecraft:light[level=12]
setblock 480 256 266 minecraft:light[level=12]
setblock 487 256 231 minecraft:light[level=12]
setblock 487 256 238 minecraft:light[level=12]
setblock 487 256 245 minecraft:light[level=12]
setblock 487 256 252 minecraft:light[level=12]
setblock 487 256 266 minecraft:light[level=12]
setblock 494 256 231 minecraft:light[level=12]
setblock 494 256 238 minecraft:light[level=12]
setblock 494 256 245 minecraft:light[level=12]
setblock 494 256 252 minecraft:light[level=12]
setblock 494 256 259 minecraft:light[level=12]
setblock 494 256 266 minecraft:light[level=12]
setblock 501 256 231 minecraft:light[level=12]
setblock 501 256 238 minecraft:light[level=12]
setblock 501 256 245 minecraft:light[level=12]
setblock 501 256 252 minecraft:light[level=12]
setblock 501 256 259 minecraft:light[level=12]
setblock 501 256 266 minecraft:light[level=12]
fill 507 256 232 508 259 232 minecraft:red_concrete
fill 507 256 268 508 259 268 minecraft:red_concrete
setblock 508 256 233 minecraft:white_concrete
setblock 508 256 238 minecraft:light[level=12]
setblock 508 256 245 minecraft:light[level=12]
setblock 508 256 252 minecraft:light[level=12]
setblock 508 256 259 minecraft:light[level=12]
setblock 508 256 269 minecraft:white_concrete
fill 510 256 229 510 260 230 minecraft:white_concrete
fill 510 256 265 510 260 266 minecraft:white_concrete
fill 472 257 233 473 260 233 minecraft:red_concrete
fill 472 257 269 473 260 269 minecraft:red_concrete
fill 473 257 229 473 261 230 minecraft:white_concrete
fill 473 257 232 473 261 232 minecraft:red_concrete
fill 473 257 265 473 261 266 minecraft:white_concrete
fill 473 257 268 473 261 268 minecraft:red_concrete
fill 508 257 233 509 260 233 minecraft:red_concrete
fill 508 257 269 509 260 269 minecraft:red_concrete
fill 509 257 229 509 261 230 minecraft:white_concrete
fill 509 257 232 509 261 232 minecraft:red_concrete
fill 509 257 265 509 261 266 minecraft:white_concrete
fill 509 257 268 509 261 268 minecraft:red_concrete
setblock 471 258 230 minecraft:red_concrete
setblock 471 258 266 minecraft:red_concrete
fill 472 258 229 472 262 230 minecraft:white_concrete
fill 472 258 265 472 262 266 minecraft:white_concrete
fill 473 258 238 473 261 242 minecraft:magenta_concrete
setblock 474 258 232 minecraft:white_concrete
fill 474 258 233 474 262 233 minecraft:red_concrete
fill 474 258 238 474 261 239 minecraft:magenta_concrete
fill 474 258 241 474 261 242 minecraft:magenta_concrete
setblock 474 258 268 minecraft:white_concrete
fill 474 258 269 474 262 269 minecraft:red_concrete
fill 475 258 238 477 261 238 minecraft:magenta_concrete
fill 475 258 242 477 261 242 minecraft:magenta_concrete
fill 476 258 239 477 261 239 minecraft:magenta_concrete
fill 476 258 241 477 261 241 minecraft:magenta_concrete
fill 477 258 240 477 261 240 minecraft:magenta_concrete
fill 504 258 257 508 259 261 minecraft:brown_terracotta
setblock 507 258 230 minecraft:red_concrete
setblock 507 258 266 minecraft:red_concrete
fill 508 258 229 508 262 230 minecraft:white_concrete
fill 508 258 265 508 262 266 minecraft:white_concrete
fill 509 258 259 510 258 259 minecraft:brown_terracotta
setblock 510 258 232 minecraft:white_concrete
fill 510 258 233 510 262 233 minecraft:red_concrete
setblock 510 258 268 minecraft:white_concrete
fill 510 258 269 510 262 269 minecraft:red_concrete
fill 471 259 230 471 263 230 minecraft:white_concrete
fill 471 259 266 471 263 266 minecraft:white_concrete
fill 472 259 238 472 260 242 minecraft:magenta_concrete
fill 473 259 237 477 260 237 minecraft:magenta_concrete
fill 473 259 243 477 260 243 minecraft:magenta_concrete
fill 474 259 232 475 262 232 minecraft:red_concrete
fill 474 259 268 475 262 268 minecraft:red_concrete
fill 478 259 238 478 260 242 minecraft:magenta_concrete
fill 507 259 230 507 263 230 minecraft:white_concrete
fill 507 259 266 507 263 266 minecraft:white_concrete
fill 510 259 232 511 262 232 minecraft:red_concrete
fill 510 259 268 511 262 268 minecraft:red_concrete
fill 471 260 231 471 264 232 minecraft:white_concrete
fill 471 260 267 471 264 268 minecraft:white_concrete
fill 472 260 231 472 264 231 minecraft:white_concrete
setblock 472 260 232 minecraft:red_concrete
fill 472 260 267 472 264 267 minecraft:white_concrete
setblock 472 260 268 minecraft:red_concrete
fill 473 260 231 475 264 231 minecraft:red_concrete
setblock 473 260 247 minecraft:light[level=15]
setblock 473 260 255 minecraft:light[level=15]
setblock 473 260 263 minecraft:light[level=15]
fill 473 260 267 475 264 267 minecraft:red_concrete
fill 474 260 240 476 261 240 minecraft:magenta_concrete
fill 475 260 239 475 261 239 minecraft:magenta_concrete
fill 475 260 241 475 261 241 minecraft:magenta_concrete
setblock 481 260 231 minecraft:light[level=15]
setblock 481 260 239 minecraft:light[level=15]
setblock 481 260 247 minecraft:light[level=15]
setblock 481 260 255 minecraft:light[level=15]
setblock 481 260 263 minecraft:light[level=15]
setblock 489 260 231 minecraft:light[level=15]
setblock 489 260 239 minecraft:light[level=15]
setblock 489 260 247 minecraft:light[level=15]
setblock 489 260 255 minecraft:light[level=15]
setblock 489 260 263 minecraft:light[level=15]
setblock 497 260 231 minecraft:light[level=15]
setblock 497 260 239 minecraft:light[level=15]
setblock 497 260 247 minecraft:light[level=15]
setblock 497 260 255 minecraft:light[level=15]
setblock 497 260 263 minecraft:light[level=15]
setblock 505 260 231 minecraft:light[level=15]
setblock 505 260 239 minecraft:light[level=15]
setblock 505 260 247 minecraft:light[level=15]
setblock 505 260 255 minecraft:light[level=15]
fill 505 260 259 507 264 259 minecraft:white_concrete
setblock 505 260 263 minecraft:light[level=15]
fill 506 260 258 506 264 258 minecraft:white_concrete
fill 506 260 260 506 264 260 minecraft:white_concrete
fill 507 260 231 507 264 232 minecraft:white_concrete
fill 507 260 267 507 264 268 minecraft:white_concrete
fill 508 260 231 508 264 231 minecraft:white_concrete
setblock 508 260 232 minecraft:red_concrete
fill 508 260 267 508 264 267 minecraft:white_concrete
setblock 508 260 268 minecraft:red_concrete
fill 509 260 231 511 264 231 minecraft:red_concrete
fill 509 260 267 511 264 267 minecraft:red_concrete
fill 472 261 232 472 264 233 minecraft:white_concrete
fill 472 261 268 472 264 269 minecraft:white_concrete
setblock 473 261 233 minecraft:red_concrete
setblock 473 261 269 minecraft:red_concrete
setblock 474 261 229 minecraft:white_concrete
fill 474 261 230 475 264 230 minecraft:red_concrete
setblock 474 261 265 minecraft:white_concrete
fill 474 261 266 475 264 266 minecraft:red_concrete
fill 477 261 243 478 262 243 minecraft:light_blue_concrete
fill 478 261 241 478 262 242 minecraft:light_blue_concrete
fill 478 261 244 478 262 245 minecraft:light_blue_concrete
fill 479 261 241 480 262 241 minecraft:light_blue_concrete
fill 479 261 245 482 262 245 minecraft:light_blue_concrete
fill 480 261 240 480 262 240 minecraft:light_blue_concrete
fill 481 261 239 481 261 241 minecraft:magenta_concrete
fill 482 261 238 482 261 239 minecraft:magenta_concrete
fill 482 261 241 482 261 242 minecraft:magenta_concrete
fill 482 261 243 482 262 244 minecraft:light_blue_concrete
fill 483 261 238 484 261 238 minecraft:magenta_concrete
fill 483 261 242 484 261 242 minecraft:magenta_concrete
fill 484 261 239 485 261 239 minecraft:magenta_concrete
fill 484 261 241 485 261 241 minecraft:magenta_concrete
fill 484 261 257 485 261 259 minecraft:magenta_concrete
setblock 485 261 240 minecraft:magenta_concrete
fill 485 261 256 489 261 256 minecraft:magenta_concrete
fill 485 261 260 486 262 260 minecraft:magenta_concrete
fill 486 261 255 488 261 255 minecraft:magenta_concrete
fill 486 261 261 489 261 261 minecraft:magenta_concrete
fill 488 261 260 490 261 260 minecraft:magenta_concrete
fill 489 261 257 490 261 257 minecraft:magenta_concrete
fill 489 261 259 490 262 259 minecraft:magenta_concrete
fill 490 261 258 490 262 258 minecraft:magenta_concrete
fill 508 261 232 508 265 233 minecraft:white_concrete
fill 508 261 268 508 264 269 minecraft:white_concrete
setblock 509 261 233 minecraft:red_concrete
setblock 509 261 269 minecraft:red_concrete
setblock 510 261 229 minecraft:white_concrete
fill 510 261 230 511 264 230 minecraft:red_concrete
setblock 510 261 265 minecraft:white_concrete
fill 510 261 266 511 264 266 minecraft:red_concrete
fill 473 262 229 473 264 230 minecraft:red_concrete
fill 473 262 232 473 264 233 minecraft:white_concrete
setblock 473 262 238 minecraft:light[level=12]
setblock 473 262 245 minecraft:light[level=12]
setblock 473 262 252 minecraft:light[level=12]
setblock 473 262 259 minecraft:light[level=12]
fill 473 262 265 473 264 266 minecraft:red_concrete
fill 473 262 268 473 264 269 minecraft:white_concrete
fill 474 262 229 474 264 229 minecraft:red_concrete
fill 474 262 265 474 265 265 minecraft:red_concrete
setblock 480 262 231 minecraft:light[level=12]
setblock 480 262 238 minecraft:light[level=12]
setblock 480 262 252 minecraft:light[level=12]
setblock 480 262 259 minecraft:light[level=12]
setblock 480 262 266 minecraft:light[level=12]
setblock 481 262 240 minecraft:magenta_concrete
setblock 481 262 241 minecraft:light_blue_concrete
fill 482 262 239 482 263 239 minecraft:magenta_concrete
fill 482 262 241 482 263 241 minecraft:magenta_concrete
setblock 482 262 242 minecraft:light_blue_concrete
setblock 483 262 238 minecraft:magenta_concrete
fill 484 262 239 484 263 239 minecraft:magenta_concrete
fill 484 262 241 484 263 241 minecraft:magenta_concrete
fill 485 262 257 485 262 259 minecraft:magenta_concrete
fill 486 262 256 489 262 256 minecraft:magenta_concrete
setblock 487 262 231 minecraft:light[level=12]
setblock 487 262 238 minecraft:light[level=12]
setblock 487 262 245 minecraft:light[level=12]
setblock 487 262 252 minecraft:light[level=12]
fill 487 262 261 488 262 261 minecraft:magenta_concrete
setblock 487 262 266 minecraft:light[level=12]
fill 488 262 260 489 262 260 minecraft:magenta_concrete
fill 489 262 257 489 263 257 minecraft:magenta_concrete
setblock 494 262 231 minecraft:light[level=12]
setblock 494 262 238 minecraft:light[level=12]
setblock 494 262 245 minecraft:light[level=12]
setblock 494 262 252 minecraft:light[level=12]
fill 494 262 259 495 263 260 minecraft:yellow_concrete
setblock 494 262 266 minecraft:light[level=12]
setblock 501 262 231 minecraft:light[level=12]
setblock 501 262 238 minecraft:light[level=12]
setblock 501 262 245 minecraft:light[level=12]
setblock 501 262 252 minecraft:light[level=12]
setblock 501 262 259 minecraft:light[level=12]
setblock 501 262 266 minecraft:light[level=12]
setblock 508 262 238 minecraft:light[level=12]
setblock 508 262 245 minecraft:light[level=12]
setblock 508 262 252 minecraft:light[level=12]
setblock 508 262 259 minecraft:light[level=12]
fill 509 262 229 509 264 230 minecraft:red_concrete
fill 509 262 232 509 264 233 minecraft:white_concrete
fill 509 262 265 509 264 266 minecraft:red_concrete
fill 509 262 268 509 264 269 minecraft:white_concrete
fill 510 262 229 510 264 229 minecraft:red_concrete
fill 510 262 265 510 264 265 minecraft:red_concrete
fill 472 263 229 472 264 229 minecraft:red_concrete
setblock 472 263 230 minecraft:white_concrete
fill 472 263 265 472 264 265 minecraft:red_concrete
setblock 472 263 266 minecraft:white_concrete
fill 474 263 232 474 267 233 minecraft:white_concrete
fill 474 263 268 474 264 269 minecraft:white_concrete
setblock 475 263 232 minecraft:red_concrete
setblock 475 263 268 minecraft:red_concrete
fill 485 263 258 485 263 259 minecraft:magenta_concrete
setblock 486 263 260 minecraft:magenta_concrete
fill 487 263 256 488 263 256 minecraft:magenta_concrete
setblock 488 263 260 minecraft:magenta_concrete
setblock 489 263 259 minecraft:magenta_concrete
fill 508 263 229 508 264 229 minecraft:red_concrete
setblock 508 263 230 minecraft:white_concrete
fill 508 263 265 508 267 265 minecraft:red_concrete
setblock 508 263 266 minecraft:white_concrete
fill 510 263 232 510 264 233 minecraft:white_concrete
fill 510 263 268 510 264 269 minecraft:white_concrete
setblock 511 263 232 minecraft:red_concrete
setblock 511 263 268 minecraft:red_concrete
fill 471 264 230 472 264 230 minecraft:red_concrete
fill 471 264 266 472 264 266 minecraft:red_concrete
fill 475 264 232 475 268 232 minecraft:white_concrete
setblock 475 264 268 minecraft:white_concrete
fill 507 264 230 508 264 230 minecraft:red_concrete
fill 507 264 266 508 267 266 minecraft:red_concrete
setblock 511 264 232 minecraft:white_concrete
setblock 511 264 268 minecraft:white_concrete
fill 471 265 229 473 265 264 minecraft:black_concrete
fill 471 265 265 471 271 265 minecraft:brown_terracotta
fill 471 265 266 473 265 269 minecraft:black_concrete
fill 472 265 265 473 265 265 minecraft:black_concrete
fill 474 265 229 500 265 231 minecraft:black_concrete
setblock 474 265 266 minecraft:red_concrete
fill 474 265 267 504 265 269 minecraft:black_concrete
fill 475 265 266 475 270 266 minecraft:white_concrete
fill 501 265 229 501 276 229 minecraft:brown_terracotta
fill 501 265 230 511 265 231 minecraft:black_concrete
fill 502 265 229 511 265 229 minecraft:black_concrete
fill 505 265 267 511 265 268 minecraft:black_concrete
fill 506 265 269 511 265 269 minecraft:black_concrete
setblock 507 265 232 minecraft:white_concrete
fill 509 265 232 511 265 266 minecraft:black_concrete
fill 471 266 229 473 266 264 minecraft:gray_concrete
fill 471 266 266 473 266 269 minecraft:gray_concrete
fill 472 266 265 473 266 265 minecraft:gray_concrete
fill 474 266 229 500 266 231 minecraft:gray_concrete
fill 474 266 265 474 270 266 minecraft:white_concrete
fill 474 266 267 511 266 269 minecraft:gray_concrete
fill 501 266 230 511 266 231 minecraft:gray_concrete
fill 502 266 229 511 266 229 minecraft:gray_concrete
fill 507 266 232 508 269 232 minecraft:red_concrete
setblock 508 266 233 minecraft:white_concrete
fill 509 266 232 511 266 266 minecraft:gray_concrete
fill 471 267 230 472 267 232 minecraft:red_concrete
setblock 471 267 237 minecraft:white_concrete
setblock 471 267 241 minecraft:red_concrete
fill 471 267 266 472 267 268 minecraft:red_concrete
setblock 472 267 229 minecraft:red_concrete
setblock 472 267 233 minecraft:orange_concrete
setblock 472 267 253 minecraft:orange_concrete
setblock 472 267 265 minecraft:red_concrete
fill 472 267 269 473 270 269 minecraft:red_concrete
fill 473 267 229 474 269 231 minecraft:white_concrete
fill 473 267 232 473 271 233 minecraft:red_concrete
setblock 473 267 239 minecraft:light[level=15]
setblock 473 267 247 minecraft:light[level=15]
setblock 473 267 255 minecraft:light[level=15]
setblock 473 267 263 minecraft:light[level=15]
fill 473 267 265 473 269 267 minecraft:white_concrete
fill 473 267 268 473 271 268 minecraft:red_concrete
fill 474 267 267 474 267 269 minecraft:white_concrete
fill 475 267 230 475 269 231 minecraft:white_concrete
fill 475 267 267 475 268 268 minecraft:white_concrete
setblock 481 267 231 minecraft:light[level=15]
setblock 481 267 239 minecraft:light[level=15]
fill 481 267 243 486 267 249 minecraft:yellow_terracotta
setblock 481 267 255 minecraft:light[level=15]
setblock 481 267 263 minecraft:light[level=15]
setblock 482 267 230 minecraft:orange_concrete
fill 482 267 241 488 267 242 minecraft:yellow_terracotta
fill 482 267 250 488 267 251 minecraft:yellow_terracotta
fill 483 267 240 499 267 240 minecraft:yellow_terracotta
fill 483 267 252 499 267 252 minecraft:yellow_terracotta
fill 484 267 239 498 267 239 minecraft:yellow_terracotta
fill 484 267 253 498 267 253 minecraft:yellow_terracotta
setblock 485 267 229 minecraft:magenta_concrete
fill 485 267 238 497 267 238 minecraft:yellow_terracotta
fill 485 267 254 497 267 254 minecraft:yellow_terracotta
fill 485 267 269 485 268 269 minecraft:brown_concrete
fill 486 267 237 496 267 237 minecraft:yellow_terracotta
fill 486 267 255 496 267 255 minecraft:yellow_terracotta
setblock 487 267 243 minecraft:yellow_terracotta
setblock 487 267 249 minecraft:yellow_terracotta
fill 488 267 230 488 268 230 minecraft:brown_concrete
fill 488 267 236 494 267 236 minecraft:yellow_terracotta
fill 488 267 256 494 267 256 minecraft:yellow_terracotta
setblock 489 267 231 minecraft:light[level=15]
fill 489 267 241 500 267 241 minecraft:yellow_terracotta
setblock 489 267 247 minecraft:light[level=15]
fill 489 267 251 500 267 251 minecraft:yellow_terracotta
setblock 489 267 263 minecraft:light[level=15]
setblock 492 267 231 minecraft:light_blue_concrete
fill 494 267 242 500 267 242 minecraft:yellow_terracotta
fill 494 267 250 500 267 250 minecraft:yellow_terracotta
fill 495 267 243 501 267 243 minecraft:yellow_terracotta
fill 495 267 249 501 267 249 minecraft:yellow_terracotta
fill 496 267 244 501 267 248 minecraft:yellow_terracotta
setblock 497 267 231 minecraft:light[level=15]
setblock 497 267 255 minecraft:light[level=15]
setblock 497 267 263 minecraft:light[level=15]
setblock 502 267 230 minecraft:red_concrete
setblock 505 267 231 minecraft:light[level=15]
setblock 505 267 239 minecraft:light[level=15]
setblock 505 267 247 minecraft:light[level=15]
setblock 505 267 255 minecraft:light[level=15]
setblock 505 267 263 minecraft:light[level=15]
setblock 506 267 267 minecraft:white_concrete
fill 507 267 230 508 267 231 minecraft:red_concrete
fill 507 267 267 508 269 268 minecraft:red_concrete
setblock 508 267 229 minecraft:red_concrete
fill 508 267 233 509 270 233 minecraft:red_concrete
fill 508 267 269 509 270 269 minecraft:red_concrete
fill 509 267 229 510 269 231 minecraft:white_concrete
fill 509 267 232 509 271 232 minecraft:red_concrete
fill 509 267 265 510 269 267 minecraft:white_concrete
fill 509 267 268 509 271 268 minecraft:red_concrete
fill 510 267 232 510 267 233 minecraft:white_concrete
fill 510 267 244 510 268 244 minecraft:brown_concrete
fill 510 267 249 510 268 249 minecraft:brown_concrete
fill 510 267 253 510 268 253 minecraft:brown_concrete
setblock 510 267 254 minecraft:red_concrete
fill 510 267 268 510 267 269 minecraft:white_concrete
fill 511 267 230 511 268 232 minecraft:white_concrete
setblock 511 267 261 minecraft:lime_concrete
fill 511 267 266 511 268 268 minecraft:white_concrete
fill 471 268 230 471 268 232 minecraft:red_concrete
fill 471 268 266 471 268 268 minecraft:red_concrete
fill 472 268 229 472 272 230 minecraft:white_concrete
fill 472 268 231 472 269 233 minecraft:red_concrete
fill 472 268 265 472 272 266 minecraft:white_concrete
fill 472 268 267 472 269 268 minecraft:red_concrete
setblock 473 268 238 minecraft:light[level=12]
setblock 473 268 245 minecraft:light[level=12]
setblock 473 268 252 minecraft:light[level=12]
setblock 473 268 259 minecraft:light[level=12]
setblock 474 268 232 minecraft:white_concrete
fill 474 268 233 474 272 233 minecraft:red_concrete
fill 474 268 267 474 268 268 minecraft:white_concrete
fill 474 268 269 474 272 269 minecraft:red_concrete
setblock 480 268 231 minecraft:light[level=12]
setblock 480 268 238 minecraft:light[level=12]
fill 480 268 243 486 269 249 minecraft:orange_terracotta
setblock 480 268 252 minecraft:light[level=12]
setblock 480 268 259 minecraft:light[level=12]
setblock 480 268 266 minecraft:light[level=12]
fill 481 268 241 490 269 242 minecraft:orange_terracotta
fill 481 268 250 490 269 251 minecraft:orange_terracotta
fill 482 268 239 500 269 240 minecraft:orange_terracotta
fill 482 268 252 500 269 253 minecraft:orange_terracotta
fill 483 268 238 499 269 238 minecraft:orange_terracotta
fill 483 268 254 499 269 254 minecraft:orange_terracotta
fill 484 268 237 498 269 237 minecraft:orange_terracotta
fill 484 268 255 498 269 255 minecraft:orange_terracotta
fill 486 268 236 496 269 236 minecraft:orange_terracotta
fill 486 268 256 496 269 256 minecraft:orange_terracotta
setblock 487 268 231 minecraft:light[level=12]
fill 487 268 243 487 269 245 minecraft:orange_terracotta
fill 487 268 247 487 269 249 minecraft:orange_terracotta
setblock 487 268 259 minecraft:light[level=12]
setblock 487 268 266 minecraft:light[level=12]
fill 488 268 235 494 269 235 minecraft:orange_terracotta
fill 488 268 243 488 270 243 minecraft:orange_terracotta
fill 488 268 249 488 269 249 minecraft:orange_terracotta
fill 488 268 257 494 269 257 minecraft:orange_terracotta
fill 491 268 241 501 269 241 minecraft:orange_terracotta
fill 491 268 251 501 269 251 minecraft:orange_terracotta
fill 492 268 242 501 269 242 minecraft:orange_terracotta
fill 492 268 250 501 269 250 minecraft:orange_terracotta
setblock 494 268 231 minecraft:light[level=12]
fill 494 268 243 502 269 243 minecraft:orange_terracotta
setblock 494 268 245 minecraft:light[level=12]
fill 494 268 249 502 269 249 minecraft:orange_terracotta
setblock 494 268 259 minecraft:light[level=12]
setblock 494 268 266 minecraft:light[level=12]
fill 495 268 244 502 269 245 minecraft:orange_terracotta
fill 495 268 247 502 269 248 minecraft:orange_terracotta
fill 496 268 246 502 269 246 minecraft:orange_terracotta
setblock 501 268 231 minecraft:light[level=12]
setblock 501 268 238 minecraft:light[level=12]
setblock 501 268 252 minecraft:light[level=12]
setblock 501 268 259 minecraft:light[level=12]
setblock 501 268 266 minecraft:light[level=12]
fill 507 268 230 507 268 231 minecraft:red_concrete
setblock 507 268 266 minecraft:red_concrete
fill 508 268 229 508 272 230 minecraft:white_concrete
fill 508 268 231 508 269 231 minecraft:red_concrete
setblock 508 268 238 minecraft:light[level=12]
setblock 508 268 245 minecraft:light[level=12]
setblock 508 268 252 minecraft:light[level=12]
setblock 508 268 259 minecraft:light[level=12]
fill 508 268 265 508 272 266 minecraft:white_concrete
setblock 510 268 232 minecraft:white_concrete
fill 510 268 233 510 272 233 minecraft:red_concrete
setblock 510 268 268 minecraft:white_concrete
fill 510 268 269 510 272 269 minecraft:red_concrete
fill 471 269 230 471 273 230 minecraft:white_concrete
fill 471 269 231 471 269 232 minecraft:red_concrete
fill 471 269 266 471 273 266 minecraft:white_concrete
fill 471 269 267 471 269 268 minecraft:red_concrete
fill 474 269 232 475 272 232 minecraft:red_concrete
fill 474 269 267 475 269 267 minecraft:white_concrete
fill 474 269 268 475 272 268 minecraft:red_concrete
setblock 480 269 242 minecraft:orange_terracotta
fill 480 269 250 480 270 250 minecraft:orange_terracotta
fill 481 269 240 481 270 240 minecraft:orange_terracotta
setblock 481 269 252 minecraft:orange_terracotta
setblock 485 269 236 minecraft:orange_terracotta
fill 485 269 256 485 270 256 minecraft:orange_terracotta
setblock 487 269 235 minecraft:orange_terracotta
setblock 487 269 246 minecraft:orange_terracotta
fill 487 269 257 487 270 257 minecraft:orange_terracotta
fill 488 269 244 488 270 244 minecraft:orange_terracotta
setblock 488 269 248 minecraft:orange_terracotta
setblock 489 269 243 minecraft:orange_terracotta
fill 489 269 249 489 270 249 minecraft:orange_terracotta
fill 491 269 242 491 270 242 minecraft:orange_terracotta
setblock 491 269 250 minecraft:orange_terracotta
setblock 493 269 243 minecraft:orange_terracotta
fill 493 269 249 493 270 249 minecraft:orange_terracotta
fill 494 269 244 494 270 244 minecraft:orange_terracotta
setblock 494 269 248 minecraft:orange_terracotta
setblock 495 269 235 minecraft:orange_terracotta
setblock 495 269 246 minecraft:orange_terracotta
fill 495 269 257 495 270 257 minecraft:orange_terracotta
setblock 497 269 236 minecraft:orange_terracotta
fill 497 269 256 497 270 256 minecraft:orange_terracotta
fill 501 269 240 501 270 240 minecraft:orange_terracotta
setblock 501 269 252 minecraft:orange_terracotta
setblock 502 269 242 minecraft:orange_terracotta
fill 502 269 250 502 270 250 minecraft:orange_terracotta
fill 507 269 230 507 273 230 minecraft:white_concrete
setblock 507 269 231 minecraft:red_concrete
fill 507 269 266 507 273 266 minecraft:white_concrete
fill 510 269 232 511 272 232 minecraft:red_concrete
fill 510 269 268 511 272 268 minecraft:red_concrete
fill 511 269 230 511 269 231 minecraft:white_concrete
fill 511 269 266 511 269 267 minecraft:white_concrete
fill 471 270 231 471 274 232 minecraft:white_concrete
fill 471 270 267 471 274 268 minecraft:white_concrete
fill 472 270 231 472 274 231 minecraft:white_concrete
fill 472 270 232 472 270 233 minecraft:red_concrete
fill 472 270 267 472 274 267 minecraft:white_concrete
setblock 472 270 268 minecraft:red_concrete
fill 473 270 229 474 270 230 minecraft:white_concrete
fill 473 270 231 475 274 231 minecraft:red_concrete
fill 473 270 265 473 271 266 minecraft:white_concrete
fill 473 270 267 475 274 267 minecraft:red_concrete
setblock 475 270 230 minecraft:white_concrete
fill 479 270 244 487 271 246 minecraft:pink_concrete
fill 479 270 247 486 270 248 minecraft:orange_terracotta
fill 480 270 241 481 271 243 minecraft:pink_concrete
fill 480 270 249 484 270 249 minecraft:orange_terracotta
fill 480 270 251 487 271 251 minecraft:pink_concrete
fill 481 270 239 485 270 239 minecraft:orange_terracotta
fill 481 270 250 482 270 250 minecraft:orange_terracotta
fill 481 270 252 485 271 253 minecraft:pink_concrete
fill 482 270 238 484 270 238 minecraft:orange_terracotta
fill 482 270 240 485 270 241 minecraft:orange_terracotta
fill 482 270 242 483 273 243 minecraft:pink_concrete
fill 482 270 254 484 270 254 minecraft:pink_concrete
setblock 483 270 237 minecraft:orange_terracotta
fill 483 270 250 487 273 250 minecraft:pink_concrete
fill 483 270 255 484 271 255 minecraft:pink_concrete
fill 484 270 236 488 271 237 minecraft:pink_concrete
fill 484 270 242 487 270 242 minecraft:orange_terracotta
fill 484 270 243 485 274 243 minecraft:pink_concrete
setblock 484 270 256 minecraft:orange_terracotta
fill 485 270 238 489 274 238 minecraft:pink_concrete
fill 485 270 249 488 273 249 minecraft:pink_concrete
fill 485 270 254 488 270 255 minecraft:orange_terracotta
fill 486 270 235 488 271 235 minecraft:pink_concrete
fill 486 270 239 489 273 240 minecraft:pink_concrete
setblock 486 270 241 minecraft:orange_terracotta
fill 486 270 243 487 270 243 minecraft:orange_terracotta
fill 486 270 252 486 274 252 minecraft:pink_concrete
fill 486 270 253 489 270 253 minecraft:orange_terracotta
fill 486 270 256 486 270 257 minecraft:orange_terracotta
fill 487 270 241 489 274 241 minecraft:pink_concrete
setblock 487 270 247 minecraft:orange_terracotta
fill 487 270 248 488 272 248 minecraft:pink_concrete
fill 487 270 252 489 270 252 minecraft:orange_terracotta
fill 487 270 256 488 270 256 minecraft:orange_terracotta
fill 488 270 242 490 272 242 minecraft:pink_concrete
fill 488 270 250 489 270 251 minecraft:orange_terracotta
setblock 488 270 257 minecraft:orange_terracotta
fill 489 270 234 493 270 236 minecraft:orange_terracotta
fill 489 270 237 489 273 237 minecraft:pink_concrete
fill 489 270 243 489 272 243 minecraft:pink_concrete
fill 489 270 254 493 271 258 minecraft:pink_concrete
fill 490 270 237 492 270 241 minecraft:orange_terracotta
fill 490 270 250 492 272 253 minecraft:pink_concrete
fill 492 270 242 494 273 242 minecraft:pink_concrete
fill 493 270 237 495 273 241 minecraft:pink_concrete
fill 493 270 243 493 272 243 minecraft:pink_concrete
fill 493 270 250 494 270 253 minecraft:orange_terracotta
fill 494 270 235 496 270 236 minecraft:pink_concrete
fill 494 270 243 496 270 243 minecraft:orange_terracotta
fill 494 270 248 495 271 249 minecraft:pink_concrete
fill 494 270 254 494 270 257 minecraft:orange_terracotta
fill 495 270 242 498 270 242 minecraft:orange_terracotta
fill 495 270 244 503 271 246 minecraft:pink_concrete
fill 495 270 247 503 270 247 minecraft:orange_terracotta
fill 495 270 250 499 273 251 minecraft:pink_concrete
fill 495 270 252 495 270 256 minecraft:orange_terracotta
fill 496 270 237 496 273 240 minecraft:pink_concrete
fill 496 270 241 500 270 241 minecraft:orange_terracotta
fill 496 270 248 503 270 248 minecraft:orange_terracotta
fill 496 270 249 497 273 249 minecraft:pink_concrete
fill 496 270 252 501 271 252 minecraft:pink_concrete
fill 496 270 253 496 270 257 minecraft:orange_terracotta
fill 497 270 236 497 272 238 minecraft:pink_concrete
fill 497 270 239 500 270 240 minecraft:orange_terracotta
fill 497 270 243 502 273 243 minecraft:pink_concrete
fill 497 270 253 501 271 253 minecraft:pink_concrete
fill 497 270 254 497 270 255 minecraft:orange_terracotta
fill 498 270 236 498 271 237 minecraft:pink_concrete
fill 498 270 238 500 270 238 minecraft:orange_terracotta
fill 498 270 249 502 270 249 minecraft:orange_terracotta
fill 498 270 254 499 271 255 minecraft:pink_concrete
setblock 498 270 256 minecraft:orange_terracotta
setblock 499 270 237 minecraft:orange_terracotta
fill 499 270 242 502 272 242 minecraft:pink_concrete
fill 500 270 250 501 270 250 minecraft:orange_terracotta
fill 500 270 251 502 271 251 minecraft:pink_concrete
fill 500 270 254 500 271 254 minecraft:pink_concrete
setblock 501 270 239 minecraft:orange_terracotta
fill 501 270 241 502 271 241 minecraft:pink_concrete
fill 507 270 231 507 274 232 minecraft:white_concrete
fill 507 270 267 507 274 268 minecraft:white_concrete
fill 508 270 231 508 274 231 minecraft:white_concrete
setblock 508 270 232 minecraft:red_concrete
fill 508 270 267 508 274 267 minecraft:white_concrete
setblock 508 270 268 minecraft:red_concrete
fill 509 270 229 510 270 230 minecraft:white_concrete
fill 509 270 231 511 274 231 minecraft:red_concrete
fill 509 270 265 510 270 266 minecraft:white_concrete
fill 509 270 267 511 274 267 minecraft:red_concrete
setblock 511 270 230 minecraft:white_concrete
setblock 511 270 266 minecraft:white_concrete
setblock 471 271 229 minecraft:pink_wool
fill 471 271 233 471 271 234 minecraft:pink_wool
setblock 471 271 235 minecraft:white_wool
fill 471 271 236 471 271 238 minecraft:pink_wool
setblock 471 271 239 minecraft:white_wool
fill 471 271 240 471 271 242 minecraft:pink_wool
setblock 471 271 243 minecraft:white_wool
fill 471 271 244 471 271 246 minecraft:pink_wool
setblock 471 271 247 minecraft:white_wool
fill 471 271 248 471 271 250 minecraft:pink_wool
setblock 471 271 251 minecraft:white_wool
fill 471 271 252 471 271 254 minecraft:pink_wool
setblock 471 271 255 minecraft:white_wool
fill 471 271 256 471 271 258 minecraft:pink_wool
setblock 471 271 259 minecraft:white_wool
fill 471 271 260 471 271 262 minecraft:pink_wool
setblock 471 271 263 minecraft:white_wool
fill 471 271 264 473 271 264 minecraft:pink_wool
setblock 471 271 269 minecraft:pink_wool
fill 472 271 232 472 275 233 minecraft:white_concrete
setblock 472 271 234 minecraft:white_wool
fill 472 271 235 472 271 237 minecraft:pink_wool
setblock 472 271 238 minecraft:white_wool
fill 472 271 239 472 271 241 minecraft:pink_wool
setblock 472 271 242 minecraft:white_wool
fill 472 271 243 472 271 245 minecraft:pink_wool
setblock 472 271 246 minecraft:white_wool
fill 472 271 247 472 271 249 minecraft:pink_wool
setblock 472 271 250 minecraft:white_wool
fill 472 271 251 472 271 253 minecraft:pink_wool
setblock 472 271 254 minecraft:white_wool
fill 472 271 255 472 271 257 minecraft:pink_wool
setblock 472 271 258 minecraft:white_wool
fill 472 271 259 472 271 261 minecraft:pink_wool
setblock 472 271 262 minecraft:white_wool
fill 472 271 263 474 271 263 minecraft:pink_wool
fill 472 271 268 472 275 269 minecraft:white_concrete
fill 473 271 229 473 271 230 minecraft:white_concrete
fill 473 271 234 473 271 236 minecraft:pink_wool
setblock 473 271 237 minecraft:white_wool
fill 473 271 238 473 271 240 minecraft:pink_wool
setblock 473 271 241 minecraft:white_wool
fill 473 271 242 473 271 244 minecraft:pink_wool
setblock 473 271 245 minecraft:white_wool
fill 473 271 246 473 271 248 minecraft:pink_wool
setblock 473 271 249 minecraft:white_wool
fill 473 271 250 473 271 252 minecraft:pink_wool
setblock 473 271 253 minecraft:white_wool
fill 473 271 254 473 271 256 minecraft:pink_wool
setblock 473 271 257 minecraft:white_wool
fill 473 271 258 473 271 260 minecraft:pink_wool
setblock 473 271 261 minecraft:white_wool
fill 473 271 262 475 271 262 minecraft:pink_wool
setblock 473 271 269 minecraft:red_concrete
setblock 474 271 229 minecraft:white_concrete
fill 474 271 230 475 274 230 minecraft:red_concrete
fill 474 271 234 474 271 235 minecraft:pink_wool
setblock 474 271 236 minecraft:white_wool
fill 474 271 237 474 271 239 minecraft:pink_wool
setblock 474 271 240 minecraft:white_wool
fill 474 271 241 474 271 243 minecraft:pink_wool
setblock 474 271 244 minecraft:white_wool
fill 474 271 245 474 271 247 minecraft:pink_wool
setblock 474 271 248 minecraft:white_wool
fill 474 271 249 474 271 251 minecraft:pink_wool
setblock 474 271 252 minecraft:white_wool
fill 474 271 253 474 271 255 minecraft:pink_wool
setblock 474 271 256 minecraft:white_wool
fill 474 271 257 474 271 259 minecraft:pink_wool
setblock 474 271 260 minecraft:white_wool
fill 474 271 261 476 271 261 minecraft:pink_wool
setblock 474 271 264 minecraft:white_wool
setblock 474 271 265 minecraft:white_concrete
fill 474 271 266 475 274 266 minecraft:red_concrete
fill 475 271 229 476 271 229 minecraft:pink_wool
fill 475 271 233 475 271 234 minecraft:pink_wool
setblock 475 271 235 minecraft:white_wool
fill 475 271 236 475 271 238 minecraft:pink_wool
setblock 475 271 239 minecraft:white_wool
fill 475 271 240 475 271 242 minecraft:pink_wool
setblock 475 271 243 minecraft:white_wool
fill 475 271 244 475 271 246 minecraft:pink_wool
setblock 475 271 247 minecraft:white_wool
fill 475 271 248 475 271 250 minecraft:pink_wool
setblock 475 271 251 minecraft:white_wool
fill 475 271 252 475 271 254 minecraft:pink_wool
setblock 475 271 255 minecraft:white_wool
fill 475 271 256 475 271 258 minecraft:pink_wool
setblock 475 271 259 minecraft:white_wool
fill 475 271 260 477 271 260 minecraft:pink_wool
setblock 475 271 263 minecraft:white_wool
fill 475 271 264 476 271 265 minecraft:pink_wool
fill 475 271 269 476 271 269 minecraft:pink_wool
setblock 476 271 230 minecraft:white_wool
fill 476 271 231 476 271 233 minecraft:pink_wool
setblock 476 271 234 minecraft:white_wool
fill 476 271 235 476 271 237 minecraft:pink_wool
setblock 476 271 238 minecraft:white_wool
fill 476 271 239 476 271 241 minecraft:pink_wool
setblock 476 271 242 minecraft:white_wool
fill 476 271 243 476 271 245 minecraft:pink_wool
setblock 476 271 246 minecraft:white_wool
fill 476 271 247 476 271 249 minecraft:pink_wool
setblock 476 271 250 minecraft:white_wool
fill 476 271 251 476 271 253 minecraft:pink_wool
setblock 476 271 254 minecraft:white_wool
fill 476 271 255 476 271 257 minecraft:pink_wool
setblock 476 271 258 minecraft:white_wool
fill 476 271 259 478 271 259 minecraft:pink_wool
setblock 476 271 262 minecraft:white_wool
fill 476 271 263 478 271 263 minecraft:pink_wool
setblock 476 271 266 minecraft:white_wool
fill 476 271 267 477 271 268 minecraft:pink_wool
setblock 477 271 229 minecraft:white_wool
fill 477 271 230 477 271 232 minecraft:pink_wool
setblock 477 271 233 minecraft:white_wool
fill 477 271 234 477 271 236 minecraft:pink_wool
setblock 477 271 237 minecraft:white_wool
fill 477 271 238 477 271 240 minecraft:pink_wool
setblock 477 271 241 minecraft:white_wool
fill 477 271 242 477 271 244 minecraft:pink_wool
setblock 477 271 245 minecraft:white_wool
fill 477 271 246 477 271 248 minecraft:pink_wool
setblock 477 271 249 minecraft:white_wool
fill 477 271 250 477 271 252 minecraft:pink_wool
setblock 477 271 253 minecraft:white_wool
fill 477 271 254 477 271 256 minecraft:pink_wool
setblock 477 271 257 minecraft:white_wool
fill 477 271 258 479 271 258 minecraft:pink_wool
setblock 477 271 261 minecraft:white_wool
fill 477 271 262 479 271 262 minecraft:pink_wool
setblock 477 271 264 minecraft:pink_wool
setblock 477 271 265 minecraft:white_wool
fill 477 271 266 479 271 266 minecraft:pink_wool
setblock 477 271 269 minecraft:white_wool
fill 478 271 229 478 271 231 minecraft:pink_wool
setblock 478 271 232 minecraft:white_wool
fill 478 271 233 478 271 235 minecraft:pink_wool
setblock 478 271 236 minecraft:white_wool
fill 478 271 237 478 271 239 minecraft:pink_wool
setblock 478 271 240 minecraft:white_wool
fill 478 271 241 478 271 243 minecraft:pink_wool
setblock 478 271 244 minecraft:white_wool
fill 478 271 245 478 271 247 minecraft:pink_wool
setblock 478 271 248 minecraft:white_wool
fill 478 271 249 478 271 251 minecraft:pink_wool
setblock 478 271 252 minecraft:white_wool
fill 478 271 253 478 271 255 minecraft:pink_wool
setblock 478 271 256 minecraft:white_wool
fill 478 271 257 480 271 257 minecraft:pink_wool
setblock 478 271 260 minecraft:white_wool
fill 478 271 261 480 271 261 minecraft:pink_wool
setblock 478 271 264 minecraft:white_wool
fill 478 271 265 480 271 265 minecraft:pink_wool
setblock 478 271 267 minecraft:pink_wool
setblock 478 271 268 minecraft:white_wool
fill 478 271 269 480 271 269 minecraft:pink_wool
fill 479 271 229 479 271 230 minecraft:pink_wool
setblock 479 271 231 minecraft:white_wool
fill 479 271 232 479 271 234 minecraft:pink_wool
setblock 479 271 235 minecraft:white_wool
fill 479 271 236 479 271 238 minecraft:pink_wool
setblock 479 271 239 minecraft:white_wool
fill 479 271 240 479 271 242 minecraft:pink_wool
setblock 479 271 243 minecraft:white_wool
fill 479 271 247 487 271 247 minecraft:pink_concrete
setblock 479 271 248 minecraft:red_concrete
fill 479 271 249 479 271 250 minecraft:pink_wool
setblock 479 271 251 minecraft:white_wool
fill 479 271 252 479 271 254 minecraft:pink_wool
setblock 479 271 255 minecraft:white_wool
fill 479 271 256 481 271 256 minecraft:pink_wool
setblock 479 271 259 minecraft:white_wool
fill 479 271 260 481 271 260 minecraft:pink_wool
setblock 479 271 263 minecraft:white_wool
fill 479 271 264 481 271 264 minecraft:pink_wool
setblock 479 271 267 minecraft:white_wool
fill 479 271 268 481 271 268 minecraft:pink_wool
setblock 480 271 229 minecraft:pink_wool
setblock 480 271 230 minecraft:white_wool
fill 480 271 231 480 271 233 minecraft:pink_wool
setblock 480 271 234 minecraft:white_wool
fill 480 271 235 480 271 237 minecraft:pink_wool
setblock 480 271 238 minecraft:white_wool
fill 480 271 239 480 271 240 minecraft:pink_wool
fill 480 271 248 482 271 250 minecraft:pink_concrete
fill 480 271 252 480 271 253 minecraft:pink_wool
setblock 480 271 254 minecraft:white_wool
fill 480 271 255 482 271 255 minecraft:pink_wool
setblock 480 271 258 minecraft:white_wool
fill 480 271 259 482 271 259 minecraft:pink_wool
setblock 480 271 262 minecraft:white_wool
fill 480 271 263 482 271 263 minecraft:pink_wool
setblock 480 271 266 minecraft:white_wool
fill 480 271 267 482 271 267 minecraft:pink_wool
setblock 481 271 229 minecraft:white_wool
fill 481 271 230 481 271 232 minecraft:pink_wool
setblock 481 271 233 minecraft:white_wool
fill 481 271 234 481 271 236 minecraft:pink_wool
setblock 481 271 237 minecraft:white_wool
setblock 481 271 238 minecraft:pink_wool
setblock 481 271 239 minecraft:magenta_concrete
fill 481 271 240 485 272 240 minecraft:pink_concrete
setblock 481 271 254 minecraft:pink_wool
setblock 481 271 257 minecraft:white_wool
fill 481 271 258 483 271 258 minecraft:pink_wool
setblock 481 271 261 minecraft:white_wool
fill 481 271 262 483 271 262 minecraft:pink_wool
setblock 481 271 265 minecraft:white_wool
fill 481 271 266 483 271 266 minecraft:pink_wool
setblock 481 271 269 minecraft:white_wool
fill 482 271 229 482 271 231 minecraft:pink_wool
setblock 482 271 232 minecraft:white_wool
fill 482 271 233 482 271 235 minecraft:pink_wool
setblock 482 271 236 minecraft:white_wool
setblock 482 271 237 minecraft:pink_wool
fill 482 271 238 484 271 239 minecraft:pink_concrete
fill 482 271 241 486 273 241 minecraft:pink_concrete
setblock 482 271 254 minecraft:yellow_concrete
setblock 482 271 256 minecraft:white_wool
fill 482 271 257 484 271 257 minecraft:pink_wool
setblock 482 271 260 minecraft:white_wool
fill 482 271 261 484 271 261 minecraft:pink_wool
setblock 482 271 264 minecraft:white_wool
fill 482 271 265 484 271 265 minecraft:pink_wool
setblock 482 271 268 minecraft:white_wool
fill 482 271 269 484 271 269 minecraft:pink_wool
fill 483 271 229 483 271 230 minecraft:pink_wool
setblock 483 271 231 minecraft:white_wool
fill 483 271 232 483 271 234 minecraft:pink_wool
setblock 483 271 235 minecraft:white_wool
setblock 483 271 236 minecraft:pink_wool
setblock 483 271 237 minecraft:pink_concrete
fill 483 271 248 484 273 249 minecraft:pink_concrete
fill 483 271 254 488 272 254 minecraft:pink_concrete
setblock 483 271 256 minecraft:pink_wool
setblock 483 271 259 minecraft:white_wool
fill 483 271 260 485 271 260 minecraft:pink_wool
setblock 483 271 263 minecraft:white_wool
fill 483 271 264 485 271 264 minecraft:pink_wool
setblock 483 271 267 minecraft:white_wool
fill 483 271 268 485 271 268 minecraft:pink_wool
setblock 484 271 229 minecraft:pink_wool
setblock 484 271 230 minecraft:white_wool
fill 484 271 231 484 271 233 minecraft:pink_wool
setblock 484 271 234 minecraft:white_wool
fill 484 271 235 485 271 235 minecraft:pink_wool
fill 484 271 242 487 273 242 minecraft:pink_concrete
fill 484 271 256 488 271 256 minecraft:pink_concrete
setblock 484 271 258 minecraft:white_wool
fill 484 271 259 486 271 259 minecraft:pink_wool
setblock 484 271 262 minecraft:white_wool
fill 484 271 263 486 271 263 minecraft:pink_wool
setblock 484 271 266 minecraft:white_wool
fill 484 271 267 486 271 267 minecraft:pink_wool
setblock 485 271 229 minecraft:white_wool
fill 485 271 230 485 271 232 minecraft:pink_wool
setblock 485 271 233 minecraft:white_wool
fill 485 271 234 487 271 234 minecraft:pink_wool
fill 485 271 239 485 274 239 minecraft:pink_concrete
fill 485 271 248 486 274 248 minecraft:pink_concrete
fill 485 271 255 488 273 255 minecraft:pink_concrete
setblock 485 271 257 minecraft:white_wool
fill 485 271 258 487 271 258 minecraft:pink_wool
setblock 485 271 261 minecraft:white_wool
fill 485 271 262 487 271 262 minecraft:pink_wool
setblock 485 271 265 minecraft:white_wool
fill 485 271 266 487 271 266 minecraft:pink_wool
setblock 485 271 269 minecraft:white_wool
fill 486 271 229 486 271 231 minecraft:pink_wool
setblock 486 271 232 minecraft:white_wool
fill 486 271 233 488 271 233 minecraft:pink_wool
fill 486 271 243 488 272 243 minecraft:pink_concrete
fill 486 271 253 489 273 253 minecraft:pink_concrete
fill 486 271 257 488 271 257 minecraft:pink_concrete
setblock 486 271 260 minecraft:white_wool
fill 486 271 261 488 271 261 minecraft:pink_wool
setblock 486 271 264 minecraft:white_wool
fill 486 271 265 488 271 265 minecraft:pink_wool
setblock 486 271 268 minecraft:white_wool
fill 486 271 269 488 271 269 minecraft:pink_wool
fill 487 271 229 487 271 230 minecraft:pink_wool
setblock 487 271 231 minecraft:white_wool
fill 487 271 232 489 271 232 minecraft:pink_wool
fill 487 271 252 489 274 252 minecraft:pink_concrete
setblock 487 271 259 minecraft:white_wool
fill 487 271 260 489 271 260 minecraft:pink_wool
setblock 487 271 263 minecraft:white_wool
fill 487 271 264 489 271 264 minecraft:pink_wool
setblock 487 271 267 minecraft:white_wool
fill 487 271 268 489 271 268 minecraft:pink_wool
setblock 488 271 229 minecraft:pink_wool
setblock 488 271 230 minecraft:white_wool
fill 488 271 231 490 271 231 minecraft:pink_wool
setblock 488 271 234 minecraft:white_wool
fill 488 271 244 488 272 244 minecraft:pink_concrete
setblock 488 271 245 minecraft:pink_wool
setblock 488 271 247 minecraft:pink_wool
fill 488 271 250 489 272 251 minecraft:pink_concrete
setblock 488 271 258 minecraft:white_wool
fill 488 271 259 490 271 259 minecraft:pink_wool
setblock 488 271 262 minecraft:white_wool
fill 488 271 263 490 271 263 minecraft:pink_wool
setblock 488 271 266 minecraft:white_wool
fill 488 271 267 490 271 267 minecraft:pink_wool
setblock 489 271 229 minecraft:white_wool
fill 489 271 230 491 271 230 minecraft:pink_wool
setblock 489 271 233 minecraft:white_wool
fill 489 271 234 491 271 236 minecraft:pink_concrete
setblock 489 271 249 minecraft:pink_concrete
setblock 489 271 261 minecraft:white_wool
fill 489 271 262 491 271 262 minecraft:pink_wool
setblock 489 271 265 minecraft:white_wool
fill 489 271 266 491 271 266 minecraft:pink_wool
setblock 489 271 269 minecraft:white_wool
fill 490 271 229 492 271 229 minecraft:pink_wool
setblock 490 271 232 minecraft:white_wool
fill 490 271 233 492 271 233 minecraft:pink_wool
fill 490 271 237 492 273 241 minecraft:pink_concrete
setblock 490 271 243 minecraft:pink_wool
setblock 490 271 249 minecraft:pink_wool
setblock 490 271 260 minecraft:white_wool
fill 490 271 261 492 271 261 minecraft:pink_wool
setblock 490 271 264 minecraft:white_wool
fill 490 271 265 492 271 265 minecraft:pink_wool
setblock 490 271 268 minecraft:white_wool
fill 490 271 269 492 271 269 minecraft:pink_wool
setblock 491 271 231 minecraft:white_wool
fill 491 271 232 493 271 232 minecraft:pink_wool
setblock 491 271 242 minecraft:pink_concrete
setblock 491 271 259 minecraft:white_wool
fill 491 271 260 493 271 260 minecraft:pink_wool
setblock 491 271 263 minecraft:white_wool
fill 491 271 264 493 271 264 minecraft:pink_wool
setblock 491 271 267 minecraft:white_wool
fill 491 271 268 493 271 268 minecraft:pink_wool
setblock 492 271 230 minecraft:white_wool
fill 492 271 231 494 271 231 minecraft:pink_wool
setblock 492 271 234 minecraft:white_concrete
fill 492 271 235 495 272 236 minecraft:pink_concrete
setblock 492 271 243 minecraft:pink_wool
setblock 492 271 249 minecraft:pink_wool
fill 492 271 259 494 271 259 minecraft:pink_wool
setblock 492 271 262 minecraft:white_wool
fill 492 271 263 494 271 263 minecraft:pink_wool
setblock 492 271 266 minecraft:white_wool
fill 492 271 267 494 271 267 minecraft:pink_wool
setblock 493 271 229 minecraft:white_wool
fill 493 271 230 495 271 230 minecraft:pink_wool
setblock 493 271 233 minecraft:white_wool
setblock 493 271 234 minecraft:pink_concrete
fill 493 271 249 493 272 253 minecraft:pink_concrete
setblock 493 271 261 minecraft:white_wool
fill 493 271 262 495 271 262 minecraft:pink_wool
setblock 493 271 265 minecraft:white_wool
fill 493 271 266 495 271 266 minecraft:pink_wool
setblock 493 271 269 minecraft:white_wool
fill 494 271 229 496 271 229 minecraft:pink_wool
setblock 494 271 232 minecraft:white_wool
fill 494 271 233 495 271 234 minecraft:pink_wool
fill 494 271 243 494 272 244 minecraft:pink_concrete
setblock 494 271 245 minecraft:pink_wool
setblock 494 271 247 minecraft:pink_wool
fill 494 271 250 494 273 257 minecraft:pink_concrete
fill 494 271 258 495 271 258 minecraft:pink_wool
setblock 494 271 260 minecraft:white_wool
fill 494 271 261 496 271 261 minecraft:pink_wool
setblock 494 271 264 minecraft:white_wool
fill 494 271 265 496 271 265 minecraft:pink_wool
setblock 494 271 268 minecraft:white_wool
fill 494 271 269 496 271 269 minecraft:pink_wool
setblock 495 271 231 minecraft:white_wool
fill 495 271 232 497 271 232 minecraft:pink_wool
fill 495 271 242 496 274 243 minecraft:pink_concrete
fill 495 271 247 503 271 247 minecraft:pink_concrete
fill 495 271 252 495 272 257 minecraft:pink_concrete
setblock 495 271 259 minecraft:white_wool
fill 495 271 260 497 271 260 minecraft:pink_wool
setblock 495 271 263 minecraft:white_wool
fill 495 271 264 497 271 264 minecraft:pink_wool
setblock 495 271 267 minecraft:white_wool
fill 495 271 268 497 271 268 minecraft:pink_wool
setblock 496 271 230 minecraft:white_wool
fill 496 271 231 498 271 231 minecraft:pink_wool
setblock 496 271 233 minecraft:pink_wool
setblock 496 271 234 minecraft:white_wool
setblock 496 271 235 minecraft:light_blue_concrete
fill 496 271 236 496 273 236 minecraft:pink_concrete
fill 496 271 241 500 274 241 minecraft:pink_concrete
fill 496 271 248 503 271 248 minecraft:pink_concrete
fill 496 271 253 496 271 257 minecraft:pink_concrete
setblock 496 271 258 minecraft:white_wool
fill 496 271 259 498 271 259 minecraft:pink_wool
setblock 496 271 262 minecraft:white_wool
fill 496 271 263 498 271 263 minecraft:pink_wool
setblock 496 271 266 minecraft:white_wool
fill 496 271 267 498 271 267 minecraft:pink_wool
setblock 497 271 229 minecraft:white_wool
fill 497 271 230 499 271 230 minecraft:pink_wool
setblock 497 271 233 minecraft:white_wool
fill 497 271 234 498 271 235 minecraft:pink_wool
fill 497 271 239 501 271 240 minecraft:pink_concrete
fill 497 271 242 498 273 242 minecraft:pink_concrete
fill 497 271 254 497 271 256 minecraft:pink_concrete
setblock 497 271 257 minecraft:white_wool
fill 497 271 258 499 271 258 minecraft:pink_wool
setblock 497 271 261 minecraft:white_wool
fill 497 271 262 499 271 262 minecraft:pink_wool
setblock 497 271 265 minecraft:white_wool
fill 497 271 266 499 271 266 minecraft:pink_wool
setblock 497 271 269 minecraft:white_wool
fill 498 271 229 500 271 229 minecraft:pink_wool
setblock 498 271 232 minecraft:white_wool
fill 498 271 233 500 271 233 minecraft:pink_wool
fill 498 271 238 499 273 238 minecraft:pink_concrete
fill 498 271 249 502 273 249 minecraft:pink_concrete
setblock 498 271 256 minecraft:magenta_concrete
fill 498 271 257 500 271 257 minecraft:pink_wool
setblock 498 271 260 minecraft:white_wool
fill 498 271 261 500 271 261 minecraft:pink_wool
setblock 498 271 264 minecraft:white_wool
fill 498 271 265 500 271 265 minecraft:pink_wool
setblock 498 271 268 minecraft:white_wool
fill 498 271 269 500 271 269 minecraft:pink_wool
setblock 499 271 231 minecraft:white_wool
fill 499 271 232 501 271 232 minecraft:pink_wool
setblock 499 271 234 minecraft:pink_wool
setblock 499 271 235 minecraft:white_wool
fill 499 271 236 501 271 236 minecraft:pink_wool
setblock 499 271 237 minecraft:pink_concrete
fill 499 271 256 501 271 256 minecraft:pink_wool
setblock 499 271 259 minecraft:white_wool
fill 499 271 260 501 271 260 minecraft:pink_wool
setblock 499 271 263 minecraft:white_wool
fill 499 271 264 501 271 264 minecraft:pink_wool
setblock 499 271 267 minecraft:white_wool
fill 499 271 268 501 271 268 minecraft:pink_wool
setblock 500 271 230 minecraft:white_wool
fill 500 271 231 502 271 231 minecraft:pink_wool
setblock 500 271 234 minecraft:white_wool
fill 500 271 235 502 271 235 minecraft:pink_wool
setblock 500 271 237 minecraft:pink_wool
setblock 500 271 238 minecraft:yellow_concrete
fill 500 271 250 502 271 250 minecraft:pink_concrete
fill 500 271 255 502 271 255 minecraft:pink_wool
setblock 500 271 258 minecraft:white_wool
fill 500 271 259 502 271 259 minecraft:pink_wool
setblock 500 271 262 minecraft:white_wool
fill 500 271 263 502 271 263 minecraft:pink_wool
setblock 500 271 266 minecraft:white_wool
fill 500 271 267 502 271 267 minecraft:pink_wool
fill 501 271 230 503 271 230 minecraft:pink_wool
setblock 501 271 233 minecraft:white_wool
fill 501 271 234 503 271 234 minecraft:pink_wool
setblock 501 271 237 minecraft:white_wool
fill 501 271 238 503 271 238 minecraft:pink_wool
fill 501 271 254 503 271 254 minecraft:pink_wool
setblock 501 271 257 minecraft:white_wool
fill 501 271 258 503 271 258 minecraft:pink_wool
setblock 501 271 261 minecraft:white_wool
fill 501 271 262 503 271 262 minecraft:pink_wool
setblock 501 271 265 minecraft:white_wool
fill 501 271 266 503 271 266 minecraft:pink_wool
setblock 501 271 269 minecraft:white_wool
fill 502 271 229 504 271 229 minecraft:pink_wool
setblock 502 271 232 minecraft:white_wool
fill 502 271 233 504 271 233 minecraft:pink_wool
setblock 502 271 236 minecraft:white_wool
fill 502 271 237 504 271 237 minecraft:pink_wool
setblock 502 271 239 minecraft:pink_wool
setblock 502 271 240 minecraft:white_wool
setblock 502 271 252 minecraft:white_wool
fill 502 271 253 504 271 253 minecraft:pink_wool
setblock 502 271 256 minecraft:white_wool
fill 502 271 257 504 271 257 minecraft:pink_wool
setblock 502 271 260 minecraft:white_wool
fill 502 271 261 504 271 261 minecraft:pink_wool
setblock 502 271 264 minecraft:white_wool
fill 502 271 265 504 271 265 minecraft:pink_wool
setblock 502 271 268 minecraft:white_wool
fill 502 271 269 504 271 269 minecraft:pink_wool
setblock 503 271 231 minecraft:white_wool
fill 503 271 232 505 271 232 minecraft:pink_wool
setblock 503 271 235 minecraft:white_wool
fill 503 271 236 505 271 236 minecraft:pink_wool
setblock 503 271 239 minecraft:white_wool
fill 503 271 240 503 271 242 minecraft:pink_wool
setblock 503 271 243 minecraft:white_wool
fill 503 271 249 503 271 250 minecraft:pink_wool
setblock 503 271 251 minecraft:white_wool
fill 503 271 252 505 271 252 minecraft:pink_wool
setblock 503 271 255 minecraft:white_wool
fill 503 271 256 505 271 256 minecraft:pink_wool
setblock 503 271 259 minecraft:white_wool
fill 503 271 260 505 271 260 minecraft:pink_wool
setblock 503 271 263 minecraft:white_wool
fill 503 271 264 505 271 264 minecraft:pink_wool
setblock 503 271 267 minecraft:white_wool
fill 503 271 268 505 271 268 minecraft:pink_wool
setblock 504 271 230 minecraft:white_wool
fill 504 271 231 506 271 231 minecraft:pink_wool
setblock 504 271 234 minecraft:white_wool
fill 504 271 235 506 271 235 minecraft:pink_wool
setblock 504 271 238 minecraft:white_wool
fill 504 271 239 504 271 241 minecraft:pink_wool
setblock 504 271 242 minecraft:white_wool
fill 504 271 243 504 271 245 minecraft:pink_wool
setblock 504 271 246 minecraft:white_wool
fill 504 271 247 504 271 249 minecraft:pink_wool
setblock 504 271 250 minecraft:white_wool
fill 504 271 251 506 271 251 minecraft:pink_wool
setblock 504 271 254 minecraft:white_wool
fill 504 271 255 506 271 255 minecraft:pink_wool
setblock 504 271 258 minecraft:white_wool
fill 504 271 259 506 271 259 minecraft:pink_wool
setblock 504 271 262 minecraft:white_wool
fill 504 271 263 506 271 263 minecraft:pink_wool
setblock 504 271 266 minecraft:white_wool
fill 504 271 267 506 271 267 minecraft:pink_wool
setblock 505 271 229 minecraft:white_wool
fill 505 271 230 506 271 230 minecraft:pink_wool
setblock 505 271 233 minecraft:white_wool
fill 505 271 234 507 271 234 minecraft:pink_wool
setblock 505 271 237 minecraft:white_wool
fill 505 271 238 505 271 240 minecraft:pink_wool
setblock 505 271 241 minecraft:white_wool
fill 505 271 242 505 271 244 minecraft:pink_wool
setblock 505 271 245 minecraft:white_wool
fill 505 271 246 505 271 248 minecraft:pink_wool
setblock 505 271 249 minecraft:white_wool
fill 505 271 250 507 271 250 minecraft:pink_wool
setblock 505 271 253 minecraft:white_wool
fill 505 271 254 507 271 254 minecraft:pink_wool
setblock 505 271 257 minecraft:white_wool
fill 505 271 258 507 271 258 minecraft:pink_wool
setblock 505 271 261 minecraft:white_wool
fill 505 271 262 507 271 262 minecraft:pink_wool
setblock 505 271 265 minecraft:white_wool
fill 505 271 266 506 271 266 minecraft:pink_wool
setblock 505 271 269 minecraft:white_wool
fill 506 271 229 507 271 229 minecraft:pink_wool
setblock 506 271 232 minecraft:white_wool
fill 506 271 233 507 271 233 minecraft:pink_wool
setblock 506 271 236 minecraft:white_wool
fill 506 271 237 506 271 239 minecraft:pink_wool
setblock 506 271 240 minecraft:white_wool
fill 506 271 241 506 271 243 minecraft:pink_wool
setblock 506 271 244 minecraft:white_wool
fill 506 271 245 506 271 247 minecraft:pink_wool
setblock 506 271 248 minecraft:white_wool
fill 506 271 249 508 271 249 minecraft:pink_wool
setblock 506 271 252 minecraft:white_wool
fill 506 271 253 508 271 253 minecraft:pink_wool
setblock 506 271 256 minecraft:white_wool
fill 506 271 257 508 271 257 minecraft:pink_wool
setblock 506 271 260 minecraft:white_wool
fill 506 271 261 508 271 261 minecraft:pink_wool
setblock 506 271 264 minecraft:white_wool
fill 506 271 265 507 271 265 minecraft:pink_wool
setblock 506 271 268 minecraft:white_wool
fill 506 271 269 507 271 269 minecraft:pink_wool
setblock 507 271 235 minecraft:white_wool
fill 507 271 236 507 271 238 minecraft:pink_wool
setblock 507 271 239 minecraft:white_wool
fill 507 271 240 507 271 242 minecraft:pink_wool
setblock 507 271 243 minecraft:white_wool
fill 507 271 244 507 271 246 minecraft:pink_wool
setblock 507 271 247 minecraft:white_wool
fill 507 271 248 509 271 248 minecraft:pink_wool
setblock 507 271 251 minecraft:white_wool
fill 507 271 252 509 271 252 minecraft:pink_wool
setblock 507 271 255 minecraft:white_wool
fill 507 271 256 509 271 256 minecraft:pink_wool
setblock 507 271 259 minecraft:white_wool
fill 507 271 260 509 271 260 minecraft:pink_wool
setblock 507 271 263 minecraft:white_wool
fill 507 271 264 509 271 264 minecraft:pink_wool
fill 508 271 232 508 275 233 minecraft:white_concrete
setblock 508 271 234 minecraft:white_wool
fill 508 271 235 508 271 237 minecraft:pink_wool
setblock 508 271 238 minecraft:white_wool
fill 508 271 239 508 271 241 minecraft:pink_wool
setblock 508 271 242 minecraft:white_wool
fill 508 271 243 508 271 245 minecraft:pink_wool
setblock 508 271 246 minecraft:white_wool
fill 508 271 247 510 271 247 minecraft:pink_wool
setblock 508 271 250 minecraft:white_wool
fill 508 271 251 510 271 251 minecraft:pink_wool
setblock 508 271 254 minecraft:white_wool
fill 508 271 255 510 271 255 minecraft:pink_wool
setblock 508 271 258 minecraft:white_wool
fill 508 271 259 510 271 259 minecraft:pink_wool
setblock 508 271 262 minecraft:white_wool
fill 508 271 263 510 271 263 minecraft:pink_wool
fill 508 271 268 508 275 269 minecraft:white_concrete
fill 509 271 229 509 271 230 minecraft:white_concrete
setblock 509 271 233 minecraft:red_concrete
fill 509 271 234 509 271 236 minecraft:pink_wool
setblock 509 271 237 minecraft:white_wool
fill 509 271 238 509 271 240 minecraft:pink_wool
setblock 509 271 241 minecraft:white_wool
fill 509 271 242 509 271 244 minecraft:pink_wool
setblock 509 271 245 minecraft:white_wool
fill 509 271 246 511 271 246 minecraft:pink_wool
setblock 509 271 249 minecraft:white_wool
fill 509 271 250 511 271 250 minecraft:pink_wool
setblock 509 271 253 minecraft:white_wool
fill 509 271 254 511 271 254 minecraft:pink_wool
setblock 509 271 257 minecraft:white_wool
fill 509 271 258 511 271 258 minecraft:pink_wool
setblock 509 271 261 minecraft:white_wool
fill 509 271 262 511 271 262 minecraft:pink_wool
fill 509 271 265 509 271 266 minecraft:white_concrete
setblock 509 271 269 minecraft:red_concrete
setblock 510 271 229 minecraft:white_concrete
fill 510 271 230 511 274 230 minecraft:red_concrete
fill 510 271 234 510 271 235 minecraft:pink_wool
setblock 510 271 236 minecraft:white_wool
fill 510 271 237 510 271 239 minecraft:pink_wool
setblock 510 271 240 minecraft:white_wool
fill 510 271 241 510 271 243 minecraft:pink_wool
setblock 510 271 244 minecraft:white_wool
fill 510 271 245 511 271 245 minecraft:pink_wool
setblock 510 271 248 minecraft:white_wool
fill 510 271 249 511 271 249 minecraft:pink_wool
setblock 510 271 252 minecraft:white_wool
fill 510 271 253 511 271 253 minecraft:pink_wool
setblock 510 271 256 minecraft:white_wool
fill 510 271 257 511 271 257 minecraft:pink_wool
setblock 510 271 260 minecraft:white_wool
fill 510 271 261 511 271 261 minecraft:pink_wool
setblock 510 271 264 minecraft:white_wool
setblock 510 271 265 minecraft:white_concrete
fill 510 271 266 511 274 266 minecraft:red_concrete
setblock 511 271 229 minecraft:pink_wool
fill 511 271 233 511 271 234 minecraft:pink_wool
setblock 511 271 235 minecraft:white_wool
fill 511 271 236 511 271 238 minecraft:pink_wool
setblock 511 271 239 minecraft:white_wool
fill 511 271 240 511 271 242 minecraft:pink_wool
setblock 511 271 243 minecraft:white_wool
setblock 511 271 244 minecraft:pink_wool
setblock 511 271 247 minecraft:white_wool
setblock 511 271 248 minecraft:pink_wool
setblock 511 271 251 minecraft:white_wool
setblock 511 271 252 minecraft:pink_wool
setblock 511 271 255 minecraft:white_wool
setblock 511 271 256 minecraft:pink_wool
setblock 511 271 259 minecraft:white_wool
setblock 511 271 260 minecraft:pink_wool
setblock 511 271 263 minecraft:white_wool
fill 511 271 264 511 271 265 minecraft:pink_wool
setblock 511 271 269 minecraft:pink_wool
fill 473 272 229 473 276 230 minecraft:red_concrete
fill 473 272 232 473 276 233 minecraft:white_concrete
fill 473 272 265 473 276 266 minecraft:red_concrete
fill 473 272 268 473 276 269 minecraft:white_concrete
fill 474 272 229 474 275 229 minecraft:red_concrete
fill 474 272 265 474 275 265 minecraft:red_concrete
fill 480 272 242 481 272 249 minecraft:pink_concrete
setblock 480 272 250 minecraft:white_concrete
setblock 481 272 241 minecraft:pink_concrete
fill 481 272 250 482 272 252 minecraft:pink_concrete
fill 482 272 239 484 273 239 minecraft:pink_concrete
fill 482 272 244 482 273 249 minecraft:pink_concrete
fill 482 272 253 485 273 253 minecraft:pink_concrete
fill 483 272 238 484 273 238 minecraft:pink_concrete
fill 483 272 244 487 272 247 minecraft:pink_concrete
fill 483 272 251 485 273 252 minecraft:pink_concrete
fill 484 272 237 488 273 237 minecraft:pink_concrete
fill 484 272 255 484 273 255 minecraft:pink_concrete
fill 484 272 269 484 283 269 minecraft:brown_terracotta
setblock 485 272 236 minecraft:white_concrete
setblock 485 272 256 minecraft:white_concrete
fill 486 272 236 491 273 236 minecraft:pink_concrete
fill 486 272 251 487 273 251 minecraft:pink_concrete
fill 486 272 256 493 273 256 minecraft:pink_concrete
fill 487 272 235 491 272 235 minecraft:pink_concrete
fill 487 272 257 493 272 257 minecraft:pink_concrete
setblock 489 272 249 minecraft:orange_concrete
fill 489 272 254 493 273 255 minecraft:pink_concrete
setblock 491 272 242 minecraft:light_blue_concrete
setblock 494 272 248 minecraft:lime_concrete
fill 494 272 249 495 273 249 minecraft:pink_concrete
fill 495 272 244 502 272 248 minecraft:pink_concrete
fill 496 272 252 496 273 256 minecraft:pink_concrete
fill 497 272 239 500 273 240 minecraft:pink_concrete
fill 497 272 252 498 273 255 minecraft:pink_concrete
setblock 497 272 256 minecraft:red_concrete
setblock 498 272 237 minecraft:pink_concrete
fill 499 272 252 499 272 254 minecraft:pink_concrete
fill 500 272 250 500 272 253 minecraft:pink_concrete
fill 501 272 240 501 272 241 minecraft:pink_concrete
fill 501 272 250 501 273 251 minecraft:pink_concrete
setblock 501 272 252 minecraft:light_blue_concrete
setblock 502 272 250 minecraft:white_concrete
fill 509 272 229 509 276 230 minecraft:red_concrete
fill 509 272 232 509 276 233 minecraft:white_concrete
fill 509 272 265 509 276 266 minecraft:red_concrete
fill 509 272 268 509 276 269 minecraft:white_concrete
fill 510 272 229 510 275 229 minecraft:red_concrete
fill 510 272 265 510 275 265 minecraft:red_concrete
fill 472 273 229 472 277 229 minecraft:red_concrete
setblock 472 273 230 minecraft:white_concrete
fill 472 273 265 472 277 265 minecraft:red_concrete
setblock 472 273 266 minecraft:white_concrete
fill 474 273 232 474 277 233 minecraft:white_concrete
fill 474 273 268 474 277 269 minecraft:white_concrete
setblock 475 273 232 minecraft:red_concrete
setblock 475 273 268 minecraft:red_concrete
fill 480 273 243 481 273 249 minecraft:pink_concrete
setblock 481 273 241 minecraft:light_blue_concrete
setblock 481 273 242 minecraft:pink_concrete
fill 481 273 250 481 273 251 minecraft:light_blue_concrete
fill 482 273 240 485 273 240 minecraft:pink_concrete
fill 482 273 250 482 273 252 minecraft:pink_concrete
fill 483 273 244 486 273 247 minecraft:pink_concrete
setblock 483 273 254 minecraft:pink_concrete
setblock 484 273 254 minecraft:orange_concrete
fill 485 273 254 488 274 254 minecraft:pink_concrete
fill 486 273 243 487 274 243 minecraft:pink_concrete
setblock 487 273 244 minecraft:pink_concrete
setblock 487 273 245 minecraft:white_concrete
fill 487 273 247 487 273 248 minecraft:pink_concrete
fill 488 273 235 490 273 235 minecraft:pink_concrete
fill 488 273 242 489 273 242 minecraft:pink_concrete
setblock 488 273 243 minecraft:magenta_concrete
fill 488 273 250 488 273 251 minecraft:pink_concrete
fill 488 273 257 493 273 257 minecraft:pink_concrete
setblock 489 273 250 minecraft:yellow_concrete
fill 489 273 251 493 274 251 minecraft:pink_concrete
setblock 490 273 242 minecraft:orange_concrete
setblock 490 273 250 minecraft:pink_concrete
fill 490 273 252 493 274 253 minecraft:pink_concrete
setblock 491 273 235 minecraft:magenta_concrete
fill 492 273 235 494 273 236 minecraft:pink_concrete
setblock 492 273 250 minecraft:magenta_concrete
setblock 493 273 250 minecraft:pink_concrete
setblock 494 273 243 minecraft:orange_concrete
setblock 495 273 236 minecraft:white_concrete
fill 495 273 244 502 273 244 minecraft:pink_concrete
setblock 495 273 245 minecraft:white_concrete
fill 495 273 247 502 273 248 minecraft:pink_concrete
fill 495 273 252 495 273 256 minecraft:pink_concrete
fill 496 273 245 501 273 246 minecraft:pink_concrete
fill 497 273 237 497 273 238 minecraft:pink_concrete
setblock 498 273 237 minecraft:lime_concrete
fill 499 273 242 500 273 242 minecraft:pink_concrete
fill 499 273 252 500 273 252 minecraft:pink_concrete
setblock 499 273 253 minecraft:red_concrete
setblock 499 273 254 minecraft:pink_concrete
fill 500 273 250 500 273 251 minecraft:pink_concrete
setblock 500 273 253 minecraft:yellow_concrete
setblock 501 273 241 minecraft:pink_concrete
setblock 501 273 242 minecraft:magenta_concrete
setblock 502 273 245 minecraft:pink_concrete
setblock 502 273 246 minecraft:light_blue_concrete
fill 508 273 229 508 277 229 minecraft:red_concrete
setblock 508 273 230 minecraft:white_concrete
fill 508 273 265 508 277 265 minecraft:red_concrete
setblock 508 273 266 minecraft:white_concrete
fill 510 273 232 510 277 233 minecraft:white_concrete
fill 510 273 268 510 277 269 minecraft:white_concrete
setblock 511 273 232 minecraft:red_concrete
setblock 511 273 268 minecraft:red_concrete
fill 471 274 230 472 277 230 minecraft:red_concrete
fill 471 274 266 472 277 266 minecraft:red_concrete
setblock 473 274 238 minecraft:light[level=12]
setblock 473 274 239 minecraft:light[level=15]
setblock 473 274 245 minecraft:light[level=12]
setblock 473 274 247 minecraft:light[level=15]
setblock 473 274 252 minecraft:light[level=12]
setblock 473 274 255 minecraft:light[level=15]
setblock 473 274 259 minecraft:light[level=12]
setblock 473 274 263 minecraft:light[level=15]
fill 475 274 232 475 278 232 minecraft:white_concrete
fill 475 274 268 475 278 268 minecraft:white_concrete
setblock 480 274 231 minecraft:light[level=12]
setblock 480 274 238 minecraft:light[level=12]
setblock 480 274 245 minecraft:light[level=12]
setblock 480 274 252 minecraft:light[level=12]
setblock 480 274 259 minecraft:light[level=12]
setblock 480 274 266 minecraft:light[level=12]
setblock 481 274 231 minecraft:light[level=15]
setblock 481 274 239 minecraft:light[level=15]
fill 481 274 243 482 274 243 minecraft:pink_concrete
setblock 481 274 244 minecraft:white_concrete
fill 481 274 245 481 274 249 minecraft:pink_concrete
setblock 481 274 255 minecraft:light[level=15]
setblock 481 274 263 minecraft:light[level=15]
setblock 482 274 241 minecraft:orange_concrete
fill 482 274 242 486 274 242 minecraft:pink_concrete
fill 482 274 244 482 274 245 minecraft:pink_concrete
setblock 482 274 246 minecraft:lime_concrete
fill 482 274 247 482 274 251 minecraft:pink_concrete
fill 483 274 240 486 274 241 minecraft:pink_concrete
setblock 483 274 243 minecraft:yellow_concrete
setblock 483 274 244 minecraft:magenta_concrete
fill 483 274 245 484 274 245 minecraft:orange_concrete
fill 483 274 246 483 274 248 minecraft:pink_concrete
setblock 483 274 249 minecraft:magenta_concrete
setblock 483 274 250 minecraft:white_concrete
fill 483 274 251 483 274 252 minecraft:pink_concrete
setblock 484 274 239 minecraft:pink_concrete
fill 484 274 244 486 274 244 minecraft:pink_concrete
setblock 484 274 246 minecraft:white_concrete
fill 484 274 247 484 274 251 minecraft:pink_concrete
setblock 484 274 252 minecraft:light_blue_concrete
fill 484 274 253 487 274 253 minecraft:pink_concrete
fill 485 274 245 486 274 245 minecraft:pink_concrete
setblock 485 274 246 minecraft:lime_concrete
setblock 485 274 247 minecraft:red_concrete
setblock 485 274 249 minecraft:light_blue_concrete
fill 485 274 250 485 274 252 minecraft:pink_concrete
setblock 486 274 237 minecraft:orange_concrete
fill 486 274 239 491 274 239 minecraft:pink_concrete
fill 486 274 246 486 274 247 minecraft:pink_concrete
setblock 486 274 249 minecraft:magenta_concrete
setblock 486 274 250 minecraft:red_concrete
setblock 486 274 251 minecraft:white_concrete
setblock 486 274 255 minecraft:pink_concrete
setblock 487 274 231 minecraft:light[level=12]
fill 487 274 237 488 274 237 minecraft:pink_concrete
fill 487 274 240 488 274 240 minecraft:pink_concrete
setblock 487 274 242 minecraft:light_blue_concrete
setblock 487 274 245 minecraft:light[level=12]
fill 487 274 249 487 274 251 minecraft:pink_concrete
setblock 487 274 255 minecraft:light_blue_concrete
setblock 487 274 259 minecraft:light[level=12]
setblock 487 274 266 minecraft:light[level=12]
fill 488 274 236 494 274 236 minecraft:pink_concrete
setblock 488 274 242 minecraft:pink_concrete
setblock 488 274 250 minecraft:orange_concrete
setblock 488 274 251 minecraft:pink_concrete
setblock 488 274 253 minecraft:light_blue_concrete
fill 488 274 255 490 274 256 minecraft:pink_concrete
setblock 489 274 231 minecraft:light[level=15]
setblock 489 274 237 minecraft:light_blue_concrete
setblock 489 274 240 minecraft:magenta_concrete
setblock 489 274 247 minecraft:light[level=15]
fill 489 274 253 489 274 254 minecraft:pink_concrete
setblock 489 274 263 minecraft:light[level=15]
fill 490 274 237 494 274 238 minecraft:pink_concrete
fill 490 274 240 490 274 241 minecraft:pink_concrete
fill 490 274 254 491 274 254 minecraft:magenta_concrete
setblock 491 274 240 minecraft:light_blue_concrete
fill 491 274 241 495 274 241 minecraft:pink_concrete
fill 491 274 255 493 274 255 minecraft:pink_concrete
setblock 491 274 256 minecraft:red_concrete
setblock 492 274 239 minecraft:orange_concrete
fill 492 274 240 493 274 240 minecraft:pink_concrete
setblock 492 274 254 minecraft:pink_concrete
setblock 492 274 256 minecraft:pink_concrete
fill 493 274 239 495 274 239 minecraft:pink_concrete
setblock 493 274 254 minecraft:yellow_concrete
setblock 493 274 256 minecraft:light_blue_concrete
setblock 494 274 231 minecraft:light[level=12]
setblock 494 274 240 minecraft:yellow_concrete
setblock 494 274 242 minecraft:pink_concrete
setblock 494 274 245 minecraft:light[level=12]
setblock 494 274 250 minecraft:white_concrete
fill 494 274 251 494 274 252 minecraft:pink_concrete
setblock 494 274 253 minecraft:orange_concrete
fill 494 274 254 497 274 254 minecraft:pink_concrete
setblock 494 274 255 minecraft:white_concrete
setblock 494 274 256 minecraft:pink_concrete
setblock 494 274 259 minecraft:light[level=12]
setblock 494 274 266 minecraft:light[level=12]
setblock 495 274 237 minecraft:orange_concrete
fill 495 274 238 497 274 238 minecraft:pink_concrete
fill 495 274 240 499 274 240 minecraft:pink_concrete
fill 495 274 249 495 274 251 minecraft:pink_concrete
setblock 495 274 252 minecraft:light_blue_concrete
setblock 495 274 253 minecraft:pink_concrete
fill 495 274 255 496 274 255 minecraft:pink_concrete
setblock 496 274 237 minecraft:pink_concrete
setblock 496 274 239 minecraft:lime_concrete
fill 496 274 244 496 274 248 minecraft:pink_concrete
fill 496 274 249 497 274 249 minecraft:red_concrete
fill 496 274 250 496 274 252 minecraft:pink_concrete
setblock 496 274 253 minecraft:light_blue_concrete
setblock 497 274 231 minecraft:light[level=15]
fill 497 274 239 498 274 239 minecraft:pink_concrete
fill 497 274 242 497 274 243 minecraft:pink_concrete
setblock 497 274 244 minecraft:orange_concrete
fill 497 274 245 497 274 248 minecraft:pink_concrete
setblock 497 274 250 minecraft:yellow_concrete
setblock 497 274 251 minecraft:lime_concrete
fill 497 274 252 498 274 253 minecraft:pink_concrete
setblock 497 274 255 minecraft:light[level=15]
setblock 497 274 263 minecraft:light[level=15]
setblock 498 274 242 minecraft:yellow_concrete
fill 498 274 243 498 274 244 minecraft:pink_concrete
setblock 498 274 245 minecraft:red_concrete
fill 498 274 246 501 274 246 minecraft:pink_concrete
setblock 498 274 247 minecraft:lime_concrete
fill 498 274 248 499 274 251 minecraft:pink_concrete
fill 499 274 242 499 274 243 minecraft:pink_concrete
setblock 499 274 244 minecraft:red_concrete
fill 499 274 245 501 274 245 minecraft:pink_concrete
setblock 499 274 247 minecraft:orange_concrete
setblock 499 274 252 minecraft:pink_concrete
setblock 500 274 242 minecraft:red_concrete
fill 500 274 243 500 274 244 minecraft:pink_concrete
setblock 500 274 247 minecraft:white_concrete
fill 500 274 248 500 274 250 minecraft:pink_concrete
setblock 500 274 251 minecraft:magenta_concrete
setblock 501 274 231 minecraft:light[level=12]
setblock 501 274 238 minecraft:light[level=12]
setblock 501 274 243 minecraft:pink_concrete
setblock 501 274 244 minecraft:white_concrete
fill 501 274 247 501 274 249 minecraft:pink_concrete
setblock 501 274 252 minecraft:light[level=12]
setblock 501 274 259 minecraft:light[level=12]
setblock 501 274 266 minecraft:light[level=12]
setblock 505 274 231 minecraft:light[level=15]
setblock 505 274 239 minecraft:light[level=15]
setblock 505 274 247 minecraft:light[level=15]
setblock 505 274 255 minecraft:light[level=15]
setblock 505 274 263 minecraft:light[level=15]
fill 507 274 230 508 277 230 minecraft:red_concrete
fill 507 274 266 508 277 266 minecraft:red_concrete
setblock 508 274 238 minecraft:light[level=12]
setblock 508 274 245 minecraft:light[level=12]
setblock 508 274 252 minecraft:light[level=12]
setblock 508 274 259 minecraft:light[level=12]
fill 511 274 232 511 278 232 minecraft:white_concrete
fill 511 274 268 511 278 268 minecraft:white_concrete
fill 471 275 231 472 279 231 minecraft:red_concrete
setblock 471 275 232 minecraft:white_concrete
fill 471 275 267 472 279 267 minecraft:red_concrete
setblock 471 275 268 minecraft:white_concrete
fill 473 275 231 475 279 231 minecraft:white_concrete
fill 473 275 267 475 279 267 minecraft:white_concrete
setblock 474 275 230 minecraft:red_concrete
setblock 474 275 266 minecraft:red_concrete
fill 475 275 230 475 280 230 minecraft:white_concrete
fill 475 275 266 475 280 266 minecraft:white_concrete
fill 507 275 231 508 279 231 minecraft:red_concrete
setblock 507 275 232 minecraft:white_concrete
fill 507 275 267 508 279 267 minecraft:red_concrete
setblock 507 275 268 minecraft:white_concrete
fill 509 275 231 511 279 231 minecraft:white_concrete
fill 509 275 267 511 279 267 minecraft:white_concrete
setblock 510 275 230 minecraft:red_concrete
setblock 510 275 266 minecraft:red_concrete
fill 511 275 230 511 280 230 minecraft:white_concrete
fill 511 275 266 511 280 266 minecraft:white_concrete
fill 471 276 232 472 279 232 minecraft:red_concrete
fill 471 276 268 472 279 268 minecraft:red_concrete
setblock 472 276 233 minecraft:white_concrete
setblock 472 276 269 minecraft:white_concrete
fill 474 276 229 474 280 230 minecraft:white_concrete
fill 474 276 265 474 280 266 minecraft:white_concrete
fill 507 276 232 508 279 232 minecraft:red_concrete
fill 507 276 268 508 279 268 minecraft:red_concrete
setblock 508 276 233 minecraft:white_concrete
setblock 508 276 269 minecraft:white_concrete
fill 510 276 229 510 280 230 minecraft:white_concrete
fill 510 276 265 510 280 266 minecraft:white_concrete
fill 472 277 233 473 280 233 minecraft:red_concrete
fill 472 277 269 473 280 269 minecraft:red_concrete
fill 473 277 229 473 281 230 minecraft:white_concrete
fill 473 277 232 473 281 232 minecraft:red_concrete
fill 473 277 265 473 281 266 minecraft:white_concrete
fill 473 277 268 473 281 268 minecraft:red_concrete
fill 508 277 233 509 280 233 minecraft:red_concrete
fill 508 277 269 509 280 269 minecraft:red_concrete
fill 509 277 229 509 281 230 minecraft:white_concrete
fill 509 277 232 509 281 232 minecraft:red_concrete
fill 509 277 265 509 281 266 minecraft:white_concrete
fill 509 277 268 509 281 268 minecraft:red_concrete
setblock 471 278 230 minecraft:red_concrete
setblock 471 278 266 minecraft:red_concrete
fill 472 278 229 472 282 230 minecraft:white_concrete
fill 472 278 265 472 282 266 minecraft:white_concrete
setblock 474 278 232 minecraft:white_concrete
fill 474 278 233 474 282 233 minecraft:red_concrete
setblock 474 278 268 minecraft:white_concrete
fill 474 278 269 474 282 269 minecraft:red_concrete
setblock 507 278 230 minecraft:red_concrete
setblock 507 278 266 minecraft:red_concrete
fill 508 278 229 508 282 230 minecraft:white_concrete
fill 508 278 265 508 282 266 minecraft:white_concrete
setblock 510 278 232 minecraft:white_concrete
fill 510 278 233 510 282 233 minecraft:red_concrete
setblock 510 278 268 minecraft:white_concrete
fill 510 278 269 510 282 269 minecraft:red_concrete
fill 471 279 230 471 283 230 minecraft:white_concrete
fill 471 279 266 471 283 266 minecraft:white_concrete
fill 474 279 232 475 282 232 minecraft:red_concrete
fill 474 279 268 475 282 268 minecraft:red_concrete
fill 507 279 230 507 283 230 minecraft:white_concrete
fill 507 279 266 507 283 266 minecraft:white_concrete
fill 510 279 232 511 282 232 minecraft:red_concrete
fill 510 279 268 511 282 268 minecraft:red_concrete
fill 471 280 231 471 284 232 minecraft:white_concrete
fill 471 280 267 471 284 268 minecraft:white_concrete
fill 472 280 231 472 284 231 minecraft:white_concrete
setblock 472 280 232 minecraft:red_concrete
fill 472 280 267 472 284 267 minecraft:white_concrete
setblock 472 280 268 minecraft:red_concrete
fill 473 280 231 475 284 231 minecraft:red_concrete
setblock 473 280 238 minecraft:light[level=12]
setblock 473 280 245 minecraft:light[level=12]
setblock 473 280 252 minecraft:light[level=12]
setblock 473 280 259 minecraft:light[level=12]
fill 473 280 267 475 284 267 minecraft:red_concrete
setblock 480 280 231 minecraft:light[level=12]
setblock 480 280 238 minecraft:light[level=12]
setblock 480 280 245 minecraft:light[level=12]
setblock 480 280 252 minecraft:light[level=12]
setblock 480 280 259 minecraft:light[level=12]
setblock 480 280 266 minecraft:light[level=12]
setblock 487 280 231 minecraft:light[level=12]
setblock 487 280 238 minecraft:light[level=12]
setblock 487 280 245 minecraft:light[level=12]
setblock 487 280 252 minecraft:light[level=12]
setblock 487 280 259 minecraft:light[level=12]
setblock 487 280 266 minecraft:light[level=12]
setblock 494 280 231 minecraft:light[level=12]
setblock 494 280 238 minecraft:light[level=12]
setblock 494 280 245 minecraft:light[level=12]
setblock 494 280 252 minecraft:light[level=12]
setblock 494 280 259 minecraft:light[level=12]
setblock 494 280 266 minecraft:light[level=12]
setblock 501 280 231 minecraft:light[level=12]
setblock 501 280 238 minecraft:light[level=12]
setblock 501 280 245 minecraft:light[level=12]
setblock 501 280 252 minecraft:light[level=12]
setblock 501 280 259 minecraft:light[level=12]
setblock 501 280 266 minecraft:light[level=12]
fill 507 280 231 507 284 232 minecraft:white_concrete
fill 507 280 267 507 284 268 minecraft:white_concrete
fill 508 280 231 508 284 231 minecraft:white_concrete
setblock 508 280 232 minecraft:red_concrete
setblock 508 280 238 minecraft:light[level=12]
setblock 508 280 245 minecraft:light[level=12]
setblock 508 280 252 minecraft:light[level=12]
setblock 508 280 259 minecraft:light[level=12]
fill 508 280 267 508 284 267 minecraft:white_concrete
setblock 508 280 268 minecraft:red_concrete
fill 509 280 231 511 284 231 minecraft:red_concrete
fill 509 280 267 511 284 267 minecraft:red_concrete
fill 511 280 251 511 292 251 minecraft:brown_concrete
fill 472 281 232 472 285 233 minecraft:white_concrete
fill 472 281 268 472 285 269 minecraft:white_concrete
setblock 473 281 233 minecraft:red_concrete
setblock 473 281 239 minecraft:light[level=15]
setblock 473 281 247 minecraft:light[level=15]
setblock 473 281 255 minecraft:light[level=15]
setblock 473 281 263 minecraft:light[level=15]
setblock 473 281 269 minecraft:red_concrete
setblock 474 281 229 minecraft:white_concrete
fill 474 281 230 475 284 230 minecraft:red_concrete
setblock 474 281 265 minecraft:white_concrete
fill 474 281 266 475 284 266 minecraft:red_concrete
setblock 481 281 231 minecraft:light[level=15]
setblock 481 281 239 minecraft:light[level=15]
setblock 481 281 247 minecraft:light[level=15]
setblock 481 281 255 minecraft:light[level=15]
setblock 481 281 263 minecraft:light[level=15]
setblock 489 281 231 minecraft:light[level=15]
setblock 489 281 239 minecraft:light[level=15]
setblock 489 281 247 minecraft:light[level=15]
setblock 489 281 255 minecraft:light[level=15]
setblock 489 281 263 minecraft:light[level=15]
setblock 497 281 231 minecraft:light[level=15]
setblock 497 281 239 minecraft:light[level=15]
setblock 497 281 247 minecraft:light[level=15]
setblock 497 281 255 minecraft:light[level=15]
setblock 497 281 263 minecraft:light[level=15]
setblock 505 281 231 minecraft:light[level=15]
setblock 505 281 239 minecraft:light[level=15]
setblock 505 281 247 minecraft:light[level=15]
setblock 505 281 255 minecraft:light[level=15]
setblock 505 281 263 minecraft:light[level=15]
fill 508 281 232 508 285 233 minecraft:white_concrete
fill 508 281 268 508 285 269 minecraft:white_concrete
setblock 509 281 233 minecraft:red_concrete
setblock 509 281 269 minecraft:red_concrete
setblock 510 281 229 minecraft:white_concrete
fill 510 281 230 511 284 230 minecraft:red_concrete
setblock 510 281 265 minecraft:white_concrete
fill 510 281 266 511 284 266 minecraft:red_concrete
fill 473 282 229 473 285 230 minecraft:red_concrete
fill 473 282 232 473 285 233 minecraft:white_concrete
fill 473 282 265 473 285 266 minecraft:red_concrete
fill 473 282 268 473 285 269 minecraft:white_concrete
fill 474 282 229 474 285 229 minecraft:red_concrete
fill 474 282 265 474 285 265 minecraft:red_concrete
fill 509 282 229 509 285 230 minecraft:red_concrete
fill 509 282 232 509 285 233 minecraft:white_concrete
fill 509 282 265 509 285 266 minecraft:red_concrete
fill 509 282 268 509 285 269 minecraft:white_concrete
fill 510 282 229 510 285 229 minecraft:red_concrete
fill 510 282 265 510 285 265 minecraft:red_concrete
fill 472 283 229 472 285 229 minecraft:red_concrete
setblock 472 283 230 minecraft:white_concrete
fill 472 283 265 472 285 265 minecraft:red_concrete
setblock 472 283 266 minecraft:white_concrete
fill 474 283 232 474 287 233 minecraft:white_concrete
fill 474 283 268 474 285 269 minecraft:white_concrete
setblock 475 283 232 minecraft:red_concrete
setblock 475 283 268 minecraft:red_concrete
fill 477 283 258 478 284 258 minecraft:yellow_concrete
fill 478 283 256 478 284 257 minecraft:yellow_concrete
fill 478 283 259 478 284 259 minecraft:yellow_concrete
fill 479 283 255 479 284 256 minecraft:yellow_concrete
fill 479 283 260 481 284 260 minecraft:yellow_concrete
fill 480 283 255 481 284 255 minecraft:yellow_concrete
fill 481 283 256 482 284 256 minecraft:yellow_concrete
fill 482 283 257 482 284 259 minecraft:yellow_concrete
fill 508 283 229 508 285 229 minecraft:red_concrete
setblock 508 283 230 minecraft:white_concrete
fill 508 283 265 508 287 265 minecraft:red_concrete
setblock 508 283 266 minecraft:white_concrete
fill 510 283 232 510 285 233 minecraft:white_concrete
fill 510 283 268 510 285 269 minecraft:white_concrete
setblock 511 283 232 minecraft:red_concrete
setblock 511 283 268 minecraft:red_concrete
fill 471 284 230 472 285 230 minecraft:red_concrete
fill 471 284 266 472 285 266 minecraft:red_concrete
fill 475 284 232 475 288 232 minecraft:white_concrete
fill 475 284 268 475 285 268 minecraft:white_concrete
fill 507 284 230 508 285 230 minecraft:red_concrete
fill 507 284 266 508 287 266 minecraft:red_concrete
fill 511 284 232 511 285 232 minecraft:white_concrete
fill 511 284 268 511 285 268 minecraft:white_concrete
fill 471 285 231 472 285 231 minecraft:red_concrete
setblock 471 285 232 minecraft:white_concrete
fill 471 285 267 472 285 267 minecraft:red_concrete
setblock 471 285 268 minecraft:white_concrete
fill 473 285 231 475 285 231 minecraft:white_concrete
fill 473 285 267 475 285 267 minecraft:white_concrete
setblock 474 285 230 minecraft:red_concrete
setblock 474 285 266 minecraft:red_concrete
setblock 475 285 230 minecraft:white_concrete
fill 475 285 266 475 290 266 minecraft:white_concrete
fill 491 285 262 491 286 262 minecraft:yellow_concrete
fill 507 285 231 508 285 231 minecraft:red_concrete
setblock 507 285 232 minecraft:white_concrete
fill 507 285 267 508 285 267 minecraft:red_concrete
setblock 507 285 268 minecraft:white_concrete
fill 509 285 231 511 285 231 minecraft:white_concrete
fill 509 285 267 511 285 267 minecraft:white_concrete
setblock 510 285 230 minecraft:red_concrete
setblock 510 285 266 minecraft:red_concrete
setblock 511 285 230 minecraft:white_concrete
setblock 511 285 266 minecraft:white_concrete
fill 471 286 229 473 286 269 minecraft:black_concrete
fill 474 286 229 511 286 231 minecraft:black_concrete
fill 474 286 265 474 290 266 minecraft:white_concrete
fill 474 286 267 511 286 269 minecraft:black_concrete
setblock 480 286 238 minecraft:light[level=12]
setblock 480 286 245 minecraft:light[level=12]
setblock 480 286 252 minecraft:light[level=12]
setblock 480 286 259 minecraft:light[level=12]
setblock 480 286 266 minecraft:light[level=12]
setblock 487 286 238 minecraft:light[level=12]
setblock 487 286 245 minecraft:light[level=12]
setblock 487 286 252 minecraft:light[level=12]
setblock 487 286 259 minecraft:light[level=12]
setblock 487 286 266 minecraft:light[level=12]
setblock 494 286 238 minecraft:light[level=12]
setblock 494 286 245 minecraft:light[level=12]
setblock 494 286 252 minecraft:light[level=12]
setblock 494 286 259 minecraft:light[level=12]
setblock 494 286 266 minecraft:light[level=12]
setblock 501 286 238 minecraft:light[level=12]
setblock 501 286 245 minecraft:light[level=12]
setblock 501 286 252 minecraft:light[level=12]
setblock 501 286 259 minecraft:light[level=12]
setblock 501 286 266 minecraft:light[level=12]
fill 507 286 232 508 289 232 minecraft:red_concrete
setblock 508 286 233 minecraft:white_concrete
setblock 508 286 238 minecraft:light[level=12]
setblock 508 286 245 minecraft:light[level=12]
setblock 508 286 252 minecraft:light[level=12]
setblock 508 286 259 minecraft:light[level=12]
fill 509 286 232 510 286 266 minecraft:black_concrete
fill 511 286 232 511 286 250 minecraft:black_concrete
fill 511 286 252 511 286 266 minecraft:black_concrete
fill 471 287 229 473 287 269 minecraft:gray_concrete
fill 474 287 229 511 287 231 minecraft:gray_concrete
fill 474 287 267 511 287 269 minecraft:gray_concrete
fill 508 287 233 508 290 233 minecraft:red_concrete
fill 509 287 232 510 287 266 minecraft:gray_concrete
fill 511 287 232 511 287 250 minecraft:gray_concrete
fill 511 287 252 511 287 266 minecraft:gray_concrete
fill 471 288 230 471 288 232 minecraft:red_concrete
setblock 471 288 251 minecraft:yellow_concrete
fill 471 288 266 471 288 268 minecraft:red_concrete
fill 472 288 229 474 290 230 minecraft:white_concrete
fill 472 288 231 472 289 233 minecraft:red_concrete
setblock 472 288 241 minecraft:red_concrete
fill 472 288 244 472 289 244 minecraft:brown_concrete
fill 472 288 257 472 289 257 minecraft:brown_concrete
fill 472 288 265 473 291 266 minecraft:white_concrete
fill 472 288 267 472 289 269 minecraft:red_concrete
fill 473 288 231 475 289 231 minecraft:white_concrete
fill 473 288 232 473 291 233 minecraft:red_concrete
setblock 473 288 239 minecraft:light[level=15]
setblock 473 288 247 minecraft:light[level=15]
setblock 473 288 255 minecraft:light[level=15]
fill 473 288 263 473 289 263 minecraft:brown_concrete
fill 473 288 267 475 289 267 minecraft:white_concrete
fill 473 288 268 473 291 269 minecraft:red_concrete
setblock 474 288 232 minecraft:white_concrete
fill 474 288 233 474 292 233 minecraft:red_concrete
setblock 474 288 268 minecraft:white_concrete
fill 474 288 269 474 292 269 minecraft:red_concrete
fill 475 288 230 475 290 230 minecraft:white_concrete
setblock 475 288 268 minecraft:orange_concrete
setblock 481 288 231 minecraft:light[level=15]
setblock 481 288 239 minecraft:light[level=15]
setblock 481 288 247 minecraft:light[level=15]
setblock 481 288 255 minecraft:light[level=15]
setblock 481 288 263 minecraft:light[level=15]
fill 486 288 230 486 289 230 minecraft:brown_concrete
fill 487 288 229 487 289 229 minecraft:brown_concrete
setblock 489 288 231 minecraft:light[level=15]
setblock 489 288 239 minecraft:light[level=15]
setblock 489 288 247 minecraft:light[level=15]
setblock 489 288 255 minecraft:light[level=15]
setblock 489 288 263 minecraft:light[level=15]
setblock 491 288 230 minecraft:light_blue_concrete
fill 491 288 262 491 289 262 minecraft:pink_concrete
setblock 497 288 231 minecraft:light[level=15]
setblock 497 288 239 minecraft:light[level=15]
setblock 497 288 247 minecraft:light[level=15]
setblock 497 288 255 minecraft:light[level=15]
setblock 497 288 263 minecraft:light[level=15]
setblock 497 288 268 minecraft:white_concrete
setblock 499 288 268 minecraft:orange_concrete
setblock 505 288 231 minecraft:light[level=15]
setblock 505 288 239 minecraft:light[level=15]
setblock 505 288 247 minecraft:light[level=15]
setblock 505 288 255 minecraft:light[level=15]
setblock 505 288 263 minecraft:light[level=15]
fill 507 288 230 507 288 231 minecraft:red_concrete
fill 507 288 266 507 288 268 minecraft:red_concrete
setblock 507 288 269 minecraft:magenta_concrete
fill 508 288 229 510 290 230 minecraft:white_concrete
fill 508 288 231 508 289 231 minecraft:red_concrete
fill 508 288 265 510 290 266 minecraft:white_concrete
fill 508 288 267 508 289 269 minecraft:red_concrete
fill 509 288 231 511 289 231 minecraft:white_concrete
fill 509 288 232 509 291 233 minecraft:red_concrete
setblock 509 288 234 minecraft:white_concrete
fill 509 288 267 511 289 267 minecraft:white_concrete
fill 509 288 268 509 291 269 minecraft:red_concrete
fill 510 288 232 511 288 232 minecraft:white_concrete
fill 510 288 233 510 292 233 minecraft:red_concrete
fill 510 288 248 510 289 248 minecraft:brown_concrete
fill 510 288 268 511 288 268 minecraft:white_concrete
fill 510 288 269 510 292 269 minecraft:red_concrete
fill 511 288 230 511 290 230 minecraft:white_concrete
fill 511 288 266 511 290 266 minecraft:white_concrete
fill 471 289 230 471 293 230 minecraft:white_concrete
fill 471 289 231 471 289 232 minecraft:red_concrete
fill 471 289 266 471 293 266 minecraft:white_concrete
fill 471 289 267 471 289 268 minecraft:red_concrete
fill 474 289 232 475 292 232 minecraft:red_concrete
fill 474 289 268 475 292 268 minecraft:red_concrete
setblock 497 289 268 minecraft:brown_concrete
fill 499 289 229 499 297 229 minecraft:brown_concrete
fill 507 289 230 507 293 230 minecraft:white_concrete
setblock 507 289 231 minecraft:red_concrete
fill 507 289 266 507 293 266 minecraft:white_concrete
fill 507 289 267 507 289 268 minecraft:red_concrete
fill 510 289 232 511 292 232 minecraft:red_concrete
fill 510 289 268 511 292 268 minecraft:red_concrete
fill 471 290 231 471 294 232 minecraft:white_concrete
fill 471 290 267 471 294 268 minecraft:white_concrete
fill 472 290 231 472 294 231 minecraft:white_concrete
fill 472 290 232 472 290 233 minecraft:red_concrete
fill 472 290 267 472 294 267 minecraft:white_concrete
fill 472 290 268 472 290 269 minecraft:red_concrete
fill 473 290 231 475 294 231 minecraft:red_concrete
fill 473 290 267 475 294 267 minecraft:red_concrete
fill 507 290 231 507 294 232 minecraft:white_concrete
fill 507 290 267 507 294 268 minecraft:white_concrete
fill 508 290 231 508 294 231 minecraft:white_concrete
setblock 508 290 232 minecraft:red_concrete
fill 508 290 267 508 294 267 minecraft:white_concrete
fill 508 290 268 508 290 269 minecraft:red_concrete
fill 509 290 231 511 294 231 minecraft:red_concrete
fill 509 290 267 511 294 267 minecraft:red_concrete
fill 472 291 229 473 291 230 minecraft:white_concrete
fill 472 291 232 472 295 233 minecraft:white_concrete
fill 472 291 268 472 295 269 minecraft:white_concrete
setblock 474 291 229 minecraft:white_concrete
fill 474 291 230 475 294 230 minecraft:red_concrete
setblock 474 291 265 minecraft:white_concrete
fill 474 291 266 475 294 266 minecraft:red_concrete
fill 508 291 229 509 291 230 minecraft:white_concrete
fill 508 291 232 508 295 233 minecraft:white_concrete
fill 508 291 265 509 291 266 minecraft:white_concrete
fill 508 291 268 508 295 269 minecraft:white_concrete
setblock 510 291 229 minecraft:white_concrete
fill 510 291 230 511 294 230 minecraft:red_concrete
setblock 510 291 265 minecraft:white_concrete
fill 510 291 266 511 294 266 minecraft:red_concrete
fill 472 292 229 472 292 230 minecraft:white_concrete
fill 472 292 265 472 292 266 minecraft:white_concrete
fill 473 292 229 473 296 230 minecraft:red_concrete
fill 473 292 232 473 296 233 minecraft:white_concrete
setblock 473 292 238 minecraft:light[level=12]
setblock 473 292 245 minecraft:light[level=12]
setblock 473 292 252 minecraft:light[level=12]
setblock 473 292 259 minecraft:light[level=12]
fill 473 292 265 473 296 266 minecraft:red_concrete
fill 473 292 268 473 296 269 minecraft:white_concrete
fill 474 292 229 474 295 229 minecraft:red_concrete
fill 474 292 265 474 295 265 minecraft:red_concrete
setblock 480 292 231 minecraft:light[level=12]
setblock 480 292 238 minecraft:light[level=12]
setblock 480 292 245 minecraft:light[level=12]
setblock 480 292 252 minecraft:light[level=12]
setblock 480 292 259 minecraft:light[level=12]
setblock 480 292 266 minecraft:light[level=12]
setblock 487 292 231 minecraft:light[level=12]
setblock 487 292 238 minecraft:light[level=12]
setblock 487 292 245 minecraft:light[level=12]
setblock 487 292 252 minecraft:light[level=12]
setblock 487 292 259 minecraft:light[level=12]
setblock 487 292 266 minecraft:light[level=12]
setblock 494 292 231 minecraft:light[level=12]
setblock 494 292 238 minecraft:light[level=12]
setblock 494 292 245 minecraft:light[level=12]
setblock 494 292 252 minecraft:light[level=12]
setblock 494 292 259 minecraft:light[level=12]
setblock 494 292 266 minecraft:light[level=12]
setblock 501 292 231 minecraft:light[level=12]
setblock 501 292 238 minecraft:light[level=12]
setblock 501 292 245 minecraft:light[level=12]
setblock 501 292 252 minecraft:light[level=12]
setblock 501 292 259 minecraft:light[level=12]
setblock 501 292 266 minecraft:light[level=12]
fill 508 292 229 508 292 230 minecraft:white_concrete
setblock 508 292 238 minecraft:light[level=12]
setblock 508 292 245 minecraft:light[level=12]
setblock 508 292 252 minecraft:light[level=12]
setblock 508 292 259 minecraft:light[level=12]
fill 508 292 265 508 292 266 minecraft:white_concrete
fill 509 292 229 509 296 230 minecraft:red_concrete
fill 509 292 232 509 296 233 minecraft:white_concrete
fill 509 292 265 509 296 266 minecraft:red_concrete
fill 509 292 268 509 296 269 minecraft:white_concrete
fill 510 292 229 510 295 229 minecraft:red_concrete
fill 510 292 265 510 295 265 minecraft:red_concrete
fill 472 293 229 472 297 229 minecraft:red_concrete
setblock 472 293 230 minecraft:white_concrete
fill 472 293 265 472 297 265 minecraft:red_concrete
setblock 472 293 266 minecraft:white_concrete
fill 474 293 232 474 297 233 minecraft:white_concrete
fill 474 293 268 474 297 269 minecraft:white_concrete
setblock 475 293 232 minecraft:red_concrete
setblock 475 293 268 minecraft:red_concrete
fill 507 293 229 507 298 229 minecraft:brown_terracotta
fill 508 293 229 508 297 229 minecraft:red_concrete
setblock 508 293 230 minecraft:white_concrete
fill 508 293 265 508 297 265 minecraft:red_concrete
setblock 508 293 266 minecraft:white_concrete
fill 510 293 232 510 297 233 minecraft:white_concrete
fill 510 293 268 510 297 269 minecraft:white_concrete
setblock 511 293 232 minecraft:red_concrete
setblock 511 293 268 minecraft:red_concrete
fill 471 294 230 472 297 230 minecraft:red_concrete
fill 471 294 266 472 297 266 minecraft:red_concrete
fill 475 294 232 475 298 232 minecraft:white_concrete
fill 475 294 268 475 298 268 minecraft:white_concrete
fill 507 294 230 508 297 230 minecraft:red_concrete
fill 507 294 266 508 297 266 minecraft:red_concrete
fill 511 294 232 511 298 232 minecraft:white_concrete
fill 511 294 268 511 298 268 minecraft:white_concrete
fill 471 295 231 472 299 231 minecraft:red_concrete
setblock 471 295 232 minecraft:white_concrete
fill 471 295 267 472 299 267 minecraft:red_concrete
setblock 471 295 268 minecraft:white_concrete
fill 473 295 231 475 299 231 minecraft:white_concrete
setblock 473 295 239 minecraft:light[level=15]
setblock 473 295 247 minecraft:light[level=15]
setblock 473 295 255 minecraft:light[level=15]
setblock 473 295 263 minecraft:light[level=15]
fill 473 295 267 475 299 267 minecraft:white_concrete
setblock 474 295 230 minecraft:red_concrete
setblock 474 295 266 minecraft:red_concrete
fill 475 295 230 475 300 230 minecraft:white_concrete
fill 475 295 266 475 300 266 minecraft:white_concrete
setblock 481 295 231 minecraft:light[level=15]
setblock 481 295 239 minecraft:light[level=15]
setblock 481 295 247 minecraft:light[level=15]
setblock 481 295 255 minecraft:light[level=15]
setblock 481 295 263 minecraft:light[level=15]
setblock 489 295 231 minecraft:light[level=15]
setblock 489 295 239 minecraft:light[level=15]
setblock 489 295 247 minecraft:light[level=15]
setblock 489 295 255 minecraft:light[level=15]
setblock 489 295 263 minecraft:light[level=15]
setblock 497 295 231 minecraft:light[level=15]
setblock 497 295 239 minecraft:light[level=15]
setblock 497 295 247 minecraft:light[level=15]
setblock 497 295 255 minecraft:light[level=15]
setblock 497 295 263 minecraft:light[level=15]
fill 499 295 231 503 296 235 minecraft:brown_terracotta
fill 501 295 229 501 295 230 minecraft:brown_terracotta
setblock 505 295 231 minecraft:light[level=15]
setblock 505 295 239 minecraft:light[level=15]
setblock 505 295 247 minecraft:light[level=15]
setblock 505 295 255 minecraft:light[level=15]
setblock 505 295 263 minecraft:light[level=15]
fill 507 295 231 508 299 231 minecraft:red_concrete
setblock 507 295 232 minecraft:white_concrete
fill 507 295 267 508 299 267 minecraft:red_concrete
setblock 507 295 268 minecraft:white_concrete
fill 509 295 231 511 299 231 minecraft:white_concrete
fill 509 295 267 511 299 267 minecraft:white_concrete
setblock 510 295 230 minecraft:red_concrete
setblock 510 295 266 minecraft:red_concrete
fill 511 295 230 511 300 230 minecraft:white_concrete
fill 511 295 266 511 300 266 minecraft:white_concrete
fill 471 296 232 472 299 232 minecraft:red_concrete
fill 471 296 268 472 299 268 minecraft:red_concrete
setblock 472 296 233 minecraft:white_concrete
setblock 472 296 269 minecraft:white_concrete
fill 474 296 229 474 300 230 minecraft:white_concrete
fill 474 296 265 474 300 266 minecraft:white_concrete
fill 507 296 232 508 299 232 minecraft:red_concrete
fill 507 296 268 508 299 268 minecraft:red_concrete
setblock 508 296 233 minecraft:white_concrete
setblock 508 296 269 minecraft:white_concrete
fill 510 296 229 510 300 230 minecraft:white_concrete
fill 510 296 265 510 300 266 minecraft:white_concrete
fill 472 297 233 473 300 233 minecraft:red_concrete
fill 472 297 269 473 300 269 minecraft:red_concrete
fill 473 297 229 473 301 230 minecraft:white_concrete
fill 473 297 232 473 301 232 minecraft:red_concrete
fill 473 297 265 473 301 266 minecraft:white_concrete
fill 473 297 268 473 301 268 minecraft:red_concrete
fill 500 297 233 502 300 233 minecraft:white_concrete
fill 501 297 232 501 300 232 minecraft:white_concrete
fill 501 297 234 501 300 234 minecraft:white_concrete
fill 508 297 233 509 300 233 minecraft:red_concrete
fill 508 297 269 509 300 269 minecraft:red_concrete
fill 509 297 229 509 301 230 minecraft:white_concrete
fill 509 297 232 509 301 232 minecraft:red_concrete
fill 509 297 265 509 301 266 minecraft:white_concrete
fill 509 297 268 509 301 268 minecraft:red_concrete
setblock 471 298 230 minecraft:red_concrete
setblock 471 298 266 minecraft:red_concrete
fill 472 298 229 472 302 230 minecraft:white_concrete
fill 472 298 265 472 302 266 minecraft:white_concrete
setblock 473 298 238 minecraft:light[level=12]
setblock 473 298 245 minecraft:light[level=12]
setblock 473 298 252 minecraft:light[level=12]
setblock 473 298 259 minecraft:light[level=12]
setblock 474 298 232 minecraft:white_concrete
fill 474 298 233 474 302 233 minecraft:red_concrete
setblock 474 298 268 minecraft:white_concrete
fill 474 298 269 474 302 269 minecraft:red_concrete
setblock 480 298 231 minecraft:light[level=12]
setblock 480 298 238 minecraft:light[level=12]
setblock 480 298 245 minecraft:light[level=12]
setblock 480 298 252 minecraft:light[level=12]
setblock 480 298 259 minecraft:light[level=12]
setblock 480 298 266 minecraft:light[level=12]
fill 486 298 262 487 299 263 minecraft:lime_concrete
setblock 487 298 231 minecraft:light[level=12]
setblock 487 298 238 minecraft:light[level=12]
setblock 487 298 245 minecraft:light[level=12]
setblock 487 298 252 minecraft:light[level=12]
setblock 487 298 259 minecraft:light[level=12]
setblock 487 298 266 minecraft:light[level=12]
setblock 494 298 231 minecraft:light[level=12]
setblock 494 298 238 minecraft:light[level=12]
setblock 494 298 245 minecraft:light[level=12]
setblock 494 298 252 minecraft:light[level=12]
setblock 494 298 259 minecraft:light[level=12]
setblock 494 298 266 minecraft:light[level=12]
setblock 501 298 231 minecraft:light[level=12]
setblock 501 298 238 minecraft:light[level=12]
setblock 501 298 245 minecraft:light[level=12]
setblock 501 298 252 minecraft:light[level=12]
setblock 501 298 259 minecraft:light[level=12]
setblock 501 298 266 minecraft:light[level=12]
setblock 507 298 230 minecraft:red_concrete
setblock 507 298 266 minecraft:red_concrete
fill 508 298 229 508 302 230 minecraft:white_concrete
setblock 508 298 238 minecraft:light[level=12]
setblock 508 298 245 minecraft:light[level=12]
setblock 508 298 252 minecraft:light[level=12]
setblock 508 298 259 minecraft:light[level=12]
fill 508 298 265 508 302 266 minecraft:white_concrete
setblock 510 298 232 minecraft:white_concrete
fill 510 298 233 510 302 233 minecraft:red_concrete
setblock 510 298 268 minecraft:white_concrete
fill 510 298 269 510 302 269 minecraft:red_concrete
fill 471 299 230 471 303 230 minecraft:white_concrete
fill 471 299 266 471 303 266 minecraft:white_concrete
fill 474 299 232 475 302 232 minecraft:red_concrete
fill 474 299 268 475 302 268 minecraft:red_concrete
fill 507 299 230 507 303 230 minecraft:white_concrete
fill 507 299 266 507 303 266 minecraft:white_concrete
fill 510 299 232 511 302 232 minecraft:red_concrete
fill 510 299 268 511 302 268 minecraft:red_concrete
fill 471 300 231 471 303 232 minecraft:white_concrete
fill 471 300 267 471 303 268 minecraft:white_concrete
fill 472 300 231 472 303 231 minecraft:white_concrete
setblock 472 300 232 minecraft:red_concrete
fill 472 300 267 472 303 267 minecraft:white_concrete
setblock 472 300 268 minecraft:red_concrete
fill 473 300 231 475 303 231 minecraft:red_concrete
fill 473 300 267 475 303 267 minecraft:red_concrete
fill 507 300 231 507 303 232 minecraft:white_concrete
fill 507 300 267 507 303 268 minecraft:white_concrete
fill 508 300 231 508 303 231 minecraft:white_concrete
setblock 508 300 232 minecraft:red_concrete
fill 508 300 267 508 303 267 minecraft:white_concrete
setblock 508 300 268 minecraft:red_concrete
fill 509 300 231 511 303 231 minecraft:red_concrete
fill 509 300 267 511 303 267 minecraft:red_concrete
fill 472 301 232 472 303 233 minecraft:white_concrete
fill 472 301 268 472 303 269 minecraft:white_concrete
setblock 473 301 233 minecraft:red_concrete
setblock 473 301 269 minecraft:red_concrete
setblock 474 301 229 minecraft:white_concrete
fill 474 301 230 475 303 230 minecraft:red_concrete
setblock 474 301 265 minecraft:white_concrete
fill 474 301 266 475 303 266 minecraft:red_concrete
fill 508 301 232 508 303 233 minecraft:white_concrete
fill 508 301 268 508 303 269 minecraft:white_concrete
setblock 509 301 233 minecraft:red_concrete
setblock 509 301 269 minecraft:red_concrete
setblock 510 301 229 minecraft:white_concrete
fill 510 301 230 511 303 230 minecraft:red_concrete
setblock 510 301 265 minecraft:white_concrete
fill 510 301 266 511 303 266 minecraft:red_concrete
fill 473 302 229 473 303 230 minecraft:red_concrete
fill 473 302 232 473 303 233 minecraft:white_concrete
setblock 473 302 239 minecraft:light[level=15]
setblock 473 302 247 minecraft:light[level=15]
setblock 473 302 255 minecraft:light[level=15]
setblock 473 302 263 minecraft:light[level=15]
fill 473 302 265 473 303 266 minecraft:red_concrete
fill 473 302 268 473 303 269 minecraft:white_concrete
fill 474 302 229 474 303 229 minecraft:red_concrete
fill 474 302 265 474 303 265 minecraft:red_concrete
setblock 481 302 231 minecraft:light[level=15]
setblock 481 302 239 minecraft:light[level=15]
setblock 481 302 247 minecraft:light[level=15]
setblock 481 302 255 minecraft:light[level=15]
setblock 481 302 263 minecraft:light[level=15]
setblock 489 302 231 minecraft:light[level=15]
setblock 489 302 239 minecraft:light[level=15]
setblock 489 302 247 minecraft:light[level=15]
setblock 489 302 255 minecraft:light[level=15]
setblock 489 302 263 minecraft:light[level=15]
setblock 497 302 231 minecraft:light[level=15]
setblock 497 302 239 minecraft:light[level=15]
setblock 497 302 247 minecraft:light[level=15]
setblock 497 302 255 minecraft:light[level=15]
setblock 497 302 263 minecraft:light[level=15]
setblock 505 302 231 minecraft:light[level=15]
setblock 505 302 239 minecraft:light[level=15]
setblock 505 302 247 minecraft:light[level=15]
setblock 505 302 255 minecraft:light[level=15]
setblock 505 302 263 minecraft:light[level=15]
fill 509 302 229 509 303 230 minecraft:red_concrete
fill 509 302 232 509 303 233 minecraft:white_concrete
fill 509 302 265 509 303 266 minecraft:red_concrete
fill 509 302 268 509 303 269 minecraft:white_concrete
fill 510 302 229 510 303 229 minecraft:red_concrete
fill 510 302 265 510 303 265 minecraft:red_concrete
setblock 472 303 229 minecraft:red_concrete
setblock 472 303 230 minecraft:white_concrete
setblock 472 303 265 minecraft:red_concrete
setblock 472 303 266 minecraft:white_concrete
fill 474 303 232 474 303 233 minecraft:white_concrete
fill 474 303 268 474 303 269 minecraft:white_concrete
setblock 475 303 232 minecraft:red_concrete
setblock 475 303 268 minecraft:red_concrete
setblock 508 303 229 minecraft:red_concrete
setblock 508 303 230 minecraft:white_concrete
setblock 508 303 265 minecraft:red_concrete
setblock 508 303 266 minecraft:white_concrete
fill 510 303 232 510 303 233 minecraft:white_concrete
fill 510 303 268 510 303 269 minecraft:white_concrete
setblock 511 303 232 minecraft:red_concrete
setblock 511 303 268 minecraft:red_concrete
