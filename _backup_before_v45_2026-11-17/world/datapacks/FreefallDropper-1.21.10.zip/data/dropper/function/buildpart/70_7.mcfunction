fill 511 162 307 511 162 310 minecraft:deepslate_tiles
setblock 511 162 311 minecraft:cobbled_deepslate
fill 511 162 312 511 165 312 minecraft:deepslate_tiles
fill 511 162 314 511 162 315 minecraft:deepslate_tiles
setblock 511 162 316 minecraft:cobbled_deepslate
setblock 512 162 280 minecraft:white_wool
fill 471 163 276 474 163 276 minecraft:deepslate_tiles
setblock 471 163 280 minecraft:cobbled_deepslate
fill 471 163 281 471 166 281 minecraft:deepslate_tiles
setblock 471 163 284 minecraft:deepslate_tiles
setblock 471 163 285 minecraft:cobbled_deepslate
fill 471 163 286 471 166 286 minecraft:deepslate_tiles
fill 471 163 288 471 163 289 minecraft:deepslate_tiles
setblock 471 163 290 minecraft:cobbled_deepslate
fill 471 163 291 472 165 291 minecraft:deepslate_tiles
fill 471 163 293 471 163 294 minecraft:deepslate_tiles
setblock 471 163 299 minecraft:deepslate_tiles
setblock 471 163 300 minecraft:cobbled_deepslate
fill 471 163 301 471 166 301 minecraft:deepslate_tiles
setblock 471 163 305 minecraft:cobbled_deepslate
fill 471 163 306 471 166 306 minecraft:deepslate_tiles
setblock 471 163 310 minecraft:cobbled_deepslate
fill 471 163 311 471 166 311 minecraft:deepslate_tiles
setblock 471 163 314 minecraft:deepslate_tiles
setblock 471 163 315 minecraft:cobbled_deepslate
fill 471 163 316 474 163 316 minecraft:deepslate_tiles
setblock 472 163 284 minecraft:cobbled_deepslate
fill 472 163 285 472 166 285 minecraft:deepslate_tiles
setblock 472 163 288 minecraft:deepslate_tiles
setblock 472 163 289 minecraft:cobbled_deepslate
fill 472 163 290 472 166 290 minecraft:deepslate_tiles
setblock 472 163 304 minecraft:cobbled_deepslate
fill 472 163 305 472 166 305 minecraft:deepslate_tiles
setblock 472 163 309 minecraft:cobbled_deepslate
fill 472 163 310 472 166 310 minecraft:deepslate_tiles
setblock 472 163 314 minecraft:cobbled_deepslate
fill 472 163 315 472 166 315 minecraft:deepslate_tiles
setblock 473 163 278 minecraft:light[level=12]
setblock 473 163 285 minecraft:light[level=12]
setblock 473 163 287 minecraft:deepslate_tiles
setblock 473 163 292 minecraft:light[level=12]
setblock 473 163 299 minecraft:light[level=12]
setblock 473 163 302 minecraft:deepslate_tiles
setblock 473 163 303 minecraft:cobbled_deepslate
fill 473 163 304 473 166 304 minecraft:deepslate_tiles
setblock 473 163 307 minecraft:deepslate_tiles
setblock 473 163 308 minecraft:cobbled_deepslate
fill 473 163 309 473 166 309 minecraft:deepslate_tiles
setblock 473 163 313 minecraft:cobbled_deepslate
fill 473 163 314 473 166 314 minecraft:deepslate_tiles
setblock 474 163 307 minecraft:cobbled_deepslate
fill 474 163 308 474 166 308 minecraft:deepslate_tiles
setblock 474 163 312 minecraft:cobbled_deepslate
fill 474 163 313 474 166 313 minecraft:deepslate_tiles
setblock 475 163 276 minecraft:cobbled_deepslate
setblock 475 163 306 minecraft:cobbled_deepslate
fill 475 163 307 475 164 307 minecraft:deepslate_tiles
setblock 475 163 311 minecraft:cobbled_deepslate
setblock 475 163 316 minecraft:cobbled_deepslate
fill 476 163 276 476 166 276 minecraft:deepslate_tiles
setblock 476 163 315 minecraft:cobbled_deepslate
fill 476 163 316 476 166 316 minecraft:deepslate_tiles
setblock 477 163 313 minecraft:deepslate_tiles
setblock 477 163 314 minecraft:cobbled_deepslate
fill 477 163 315 477 166 315 minecraft:deepslate_tiles
fill 478 163 299 479 166 299 minecraft:white_terracotta
fill 478 163 314 478 166 314 minecraft:deepslate_tiles
fill 479 163 300 479 166 300 minecraft:white_terracotta
setblock 480 163 278 minecraft:light[level=12]
setblock 480 163 285 minecraft:light[level=12]
setblock 480 163 292 minecraft:light[level=12]
setblock 480 163 299 minecraft:light[level=12]
setblock 480 163 306 minecraft:light[level=12]
setblock 480 163 313 minecraft:light[level=12]
setblock 480 163 315 minecraft:deepslate_tiles
setblock 480 163 316 minecraft:cobbled_deepslate
fill 481 163 316 481 164 316 minecraft:deepslate_tiles
setblock 487 163 278 minecraft:light[level=12]
setblock 487 163 285 minecraft:light[level=12]
setblock 487 163 292 minecraft:light[level=12]
setblock 487 163 299 minecraft:light[level=12]
setblock 487 163 306 minecraft:light[level=12]
setblock 487 163 313 minecraft:light[level=12]
fill 492 163 276 494 163 276 minecraft:deepslate_tiles
fill 492 163 316 494 163 316 minecraft:deepslate_tiles
setblock 494 163 278 minecraft:light[level=12]
setblock 494 163 285 minecraft:light[level=12]
setblock 494 163 292 minecraft:light[level=12]
setblock 494 163 299 minecraft:light[level=12]
setblock 494 163 306 minecraft:light[level=12]
setblock 494 163 313 minecraft:light[level=12]
setblock 495 163 276 minecraft:cobbled_deepslate
fill 495 163 277 495 166 277 minecraft:deepslate_tiles
setblock 495 163 316 minecraft:cobbled_deepslate
fill 496 163 276 496 166 276 minecraft:deepslate_tiles
fill 496 163 316 496 166 316 minecraft:deepslate_tiles
setblock 498 163 277 minecraft:deepslate_tiles
setblock 499 163 277 minecraft:cobbled_deepslate
setblock 500 163 276 minecraft:cobbled_deepslate
setblock 500 163 316 minecraft:cobbled_deepslate
fill 501 163 276 501 166 276 minecraft:deepslate_tiles
setblock 501 163 278 minecraft:light[level=12]
setblock 501 163 285 minecraft:light[level=12]
setblock 501 163 292 minecraft:light[level=12]
setblock 501 163 299 minecraft:light[level=12]
setblock 501 163 306 minecraft:light[level=12]
setblock 501 163 313 minecraft:light[level=12]
fill 506 163 276 507 165 276 minecraft:deepslate_tiles
setblock 508 163 278 minecraft:light[level=12]
setblock 508 163 285 minecraft:light[level=12]
setblock 508 163 292 minecraft:light[level=12]
setblock 508 163 299 minecraft:light[level=12]
setblock 508 163 306 minecraft:light[level=12]
setblock 508 163 313 minecraft:light[level=12]
fill 508 163 316 509 163 316 minecraft:deepslate_tiles
setblock 510 163 276 minecraft:cobbled_deepslate
setblock 510 163 281 minecraft:cobbled_deepslate
fill 510 163 282 510 166 282 minecraft:deepslate_tiles
setblock 510 163 285 minecraft:deepslate_tiles
setblock 510 163 286 minecraft:cobbled_deepslate
fill 510 163 287 510 166 287 minecraft:deepslate_tiles
setblock 510 163 290 minecraft:deepslate_tiles
setblock 510 163 306 minecraft:cobbled_deepslate
fill 510 163 307 510 163 310 minecraft:deepslate_tiles
setblock 510 163 311 minecraft:cobbled_deepslate
fill 510 163 312 510 166 312 minecraft:deepslate_tiles
fill 510 163 314 510 163 315 minecraft:deepslate_tiles
setblock 510 163 316 minecraft:cobbled_deepslate
fill 511 163 276 511 166 276 minecraft:deepslate_tiles
setblock 511 163 280 minecraft:cobbled_deepslate
fill 511 163 281 511 166 281 minecraft:deepslate_tiles
setblock 511 163 285 minecraft:cobbled_deepslate
fill 511 163 286 511 166 286 minecraft:deepslate_tiles
setblock 511 163 290 minecraft:cobbled_deepslate
fill 511 163 291 511 166 291 minecraft:deepslate_tiles
fill 511 163 293 511 164 293 minecraft:deepslate_tiles
fill 511 163 303 511 163 304 minecraft:deepslate_tiles
setblock 511 163 305 minecraft:cobbled_deepslate
fill 511 163 306 511 163 309 minecraft:deepslate_tiles
setblock 511 163 310 minecraft:cobbled_deepslate
fill 511 163 311 511 166 311 minecraft:deepslate_tiles
setblock 511 163 314 minecraft:deepslate_tiles
setblock 511 163 315 minecraft:cobbled_deepslate
fill 511 163 316 511 166 316 minecraft:deepslate_tiles
fill 512 163 280 512 199 280 minecraft:black_concrete
fill 471 164 276 473 164 276 minecraft:deepslate_tiles
setblock 471 164 279 minecraft:cobbled_deepslate
fill 471 164 280 471 166 280 minecraft:deepslate_tiles
setblock 471 164 283 minecraft:deepslate_tiles
setblock 471 164 284 minecraft:cobbled_deepslate
fill 471 164 285 471 167 285 minecraft:deepslate_tiles
setblock 471 164 288 minecraft:deepslate_tiles
setblock 471 164 289 minecraft:cobbled_deepslate
fill 471 164 290 471 167 290 minecraft:deepslate_tiles
setblock 471 164 293 minecraft:deepslate_tiles
setblock 471 164 294 minecraft:cobbled_deepslate
fill 471 164 295 471 164 298 minecraft:deepslate_tiles
setblock 471 164 299 minecraft:cobbled_deepslate
fill 471 164 300 472 166 300 minecraft:deepslate_tiles
setblock 471 164 304 minecraft:cobbled_deepslate
fill 471 164 305 471 167 305 minecraft:deepslate_tiles
setblock 471 164 309 minecraft:cobbled_deepslate
fill 471 164 310 471 167 310 minecraft:deepslate_tiles
setblock 471 164 314 minecraft:cobbled_deepslate
fill 471 164 315 471 166 316 minecraft:deepslate_tiles
setblock 472 164 283 minecraft:cobbled_deepslate
fill 472 164 284 472 165 284 minecraft:deepslate_tiles
setblock 472 164 288 minecraft:cobbled_deepslate
fill 472 164 289 473 166 289 minecraft:deepslate_tiles
setblock 472 164 292 minecraft:deepslate_tiles
setblock 472 164 293 minecraft:cobbled_deepslate
setblock 472 164 303 minecraft:cobbled_deepslate
fill 472 164 304 472 167 304 minecraft:deepslate_tiles
setblock 472 164 308 minecraft:cobbled_deepslate
fill 472 164 309 472 167 309 minecraft:deepslate_tiles
setblock 472 164 313 minecraft:cobbled_deepslate
fill 472 164 314 472 167 314 minecraft:deepslate_tiles
fill 472 164 316 473 164 316 minecraft:deepslate_tiles
setblock 473 164 287 minecraft:cobbled_deepslate
fill 473 164 288 473 166 288 minecraft:deepslate_tiles
fill 473 164 290 473 165 290 minecraft:deepslate_tiles
setblock 473 164 302 minecraft:cobbled_deepslate
fill 473 164 303 473 166 303 minecraft:deepslate_tiles
setblock 473 164 307 minecraft:cobbled_deepslate
fill 473 164 308 473 167 308 minecraft:deepslate_tiles
setblock 473 164 311 minecraft:deepslate_tiles
setblock 473 164 312 minecraft:cobbled_deepslate
fill 473 164 313 473 167 313 minecraft:deepslate_tiles
setblock 474 164 276 minecraft:cobbled_deepslate
setblock 474 164 306 minecraft:cobbled_deepslate
fill 474 164 307 474 167 307 minecraft:deepslate_tiles
setblock 474 164 311 minecraft:cobbled_deepslate
fill 474 164 312 475 164 312 minecraft:deepslate_tiles
setblock 474 164 316 minecraft:cobbled_deepslate
fill 475 164 276 475 167 276 minecraft:deepslate_tiles
setblock 475 164 310 minecraft:cobbled_deepslate
fill 475 164 311 475 165 311 minecraft:deepslate_tiles
setblock 475 164 315 minecraft:cobbled_deepslate
fill 475 164 316 475 167 316 minecraft:deepslate_tiles
setblock 476 164 314 minecraft:cobbled_deepslate
fill 476 164 315 476 167 315 minecraft:deepslate_tiles
setblock 477 164 313 minecraft:cobbled_deepslate
fill 477 164 314 477 167 314 minecraft:deepslate_tiles
fill 478 164 298 479 165 298 minecraft:white_terracotta
fill 478 164 300 478 165 300 minecraft:white_terracotta
setblock 479 164 316 minecraft:cobbled_deepslate
setblock 480 164 315 minecraft:cobbled_deepslate
fill 480 164 316 480 166 316 minecraft:deepslate_tiles
fill 491 164 316 493 164 316 minecraft:deepslate_tiles
fill 492 164 276 493 164 276 minecraft:deepslate_tiles
setblock 494 164 276 minecraft:cobbled_deepslate
fill 494 164 277 494 167 277 minecraft:deepslate_tiles
setblock 494 164 315 minecraft:deepslate_tiles
setblock 494 164 316 minecraft:cobbled_deepslate
fill 495 164 276 495 167 276 minecraft:deepslate_tiles
setblock 495 164 315 minecraft:cobbled_deepslate
fill 495 164 316 495 167 316 minecraft:deepslate_tiles
fill 496 164 315 497 166 315 minecraft:deepslate_tiles
fill 497 164 316 498 164 316 minecraft:deepslate_tiles
setblock 498 164 277 minecraft:cobbled_deepslate
setblock 499 164 276 minecraft:cobbled_deepslate
setblock 499 164 316 minecraft:cobbled_deepslate
fill 500 164 276 500 167 276 minecraft:deepslate_tiles
fill 500 164 316 501 166 316 minecraft:deepslate_tiles
setblock 504 164 276 minecraft:cobbled_deepslate
fill 505 164 276 505 167 276 minecraft:deepslate_tiles
fill 506 164 316 508 164 316 minecraft:deepslate_tiles
setblock 509 164 276 minecraft:cobbled_deepslate
setblock 509 164 315 minecraft:deepslate_tiles
setblock 509 164 316 minecraft:cobbled_deepslate
fill 510 164 276 510 165 278 minecraft:deepslate_tiles
setblock 510 164 280 minecraft:cobbled_deepslate
fill 510 164 281 510 165 281 minecraft:deepslate_tiles
setblock 510 164 285 minecraft:cobbled_deepslate
fill 510 164 286 510 167 286 minecraft:deepslate_tiles
setblock 510 164 290 minecraft:cobbled_deepslate
fill 510 164 291 510 167 291 minecraft:deepslate_tiles
fill 510 164 306 510 164 309 minecraft:deepslate_tiles
setblock 510 164 310 minecraft:cobbled_deepslate
fill 510 164 311 510 167 311 minecraft:deepslate_tiles
setblock 510 164 314 minecraft:deepslate_tiles
setblock 510 164 315 minecraft:cobbled_deepslate
fill 510 164 316 510 167 316 minecraft:deepslate_tiles
setblock 511 164 279 minecraft:cobbled_deepslate
fill 511 164 280 511 167 280 minecraft:deepslate_tiles
setblock 511 164 284 minecraft:cobbled_deepslate
fill 511 164 285 511 167 285 minecraft:deepslate_tiles
setblock 511 164 289 minecraft:cobbled_deepslate
fill 511 164 290 511 167 290 minecraft:deepslate_tiles
setblock 511 164 294 minecraft:cobbled_deepslate
fill 511 164 302 511 164 303 minecraft:deepslate_tiles
setblock 511 164 304 minecraft:cobbled_deepslate
fill 511 164 305 511 164 308 minecraft:deepslate_tiles
setblock 511 164 309 minecraft:cobbled_deepslate
fill 511 164 310 511 167 310 minecraft:deepslate_tiles
setblock 511 164 314 minecraft:cobbled_deepslate
fill 511 164 315 511 167 315 minecraft:deepslate_tiles
fill 471 165 276 472 165 276 minecraft:deepslate_tiles
setblock 471 165 278 minecraft:cobbled_deepslate
fill 471 165 279 471 166 279 minecraft:deepslate_tiles
setblock 471 165 283 minecraft:cobbled_deepslate
fill 471 165 284 471 167 284 minecraft:deepslate_tiles
setblock 471 165 288 minecraft:cobbled_deepslate
fill 471 165 289 471 168 289 minecraft:deepslate_tiles
setblock 471 165 293 minecraft:cobbled_deepslate
fill 471 165 294 471 165 297 minecraft:deepslate_tiles
setblock 471 165 298 minecraft:cobbled_deepslate
fill 471 165 299 471 168 299 minecraft:deepslate_tiles
setblock 471 165 303 minecraft:cobbled_deepslate
fill 471 165 304 471 168 304 minecraft:deepslate_tiles
setblock 471 165 308 minecraft:cobbled_deepslate
fill 471 165 309 471 168 309 minecraft:deepslate_tiles
setblock 471 165 313 minecraft:cobbled_deepslate
fill 471 165 314 471 168 314 minecraft:deepslate_tiles
setblock 472 165 287 minecraft:cobbled_deepslate
fill 472 165 288 472 168 288 minecraft:deepslate_tiles
setblock 472 165 292 minecraft:cobbled_deepslate
fill 472 165 293 472 166 295 minecraft:deepslate_tiles
setblock 472 165 302 minecraft:cobbled_deepslate
fill 472 165 303 472 168 303 minecraft:deepslate_tiles
setblock 472 165 307 minecraft:cobbled_deepslate
fill 472 165 308 472 168 308 minecraft:deepslate_tiles
setblock 472 165 312 minecraft:cobbled_deepslate
fill 472 165 313 472 168 313 minecraft:deepslate_tiles
setblock 472 165 316 minecraft:deepslate_tiles
setblock 473 165 276 minecraft:cobbled_deepslate
setblock 473 165 278 minecraft:light[level=13]
setblock 473 165 286 minecraft:light[level=13]
setblock 473 165 287 minecraft:deepslate_tiles
setblock 473 165 291 minecraft:cobbled_deepslate
setblock 473 165 294 minecraft:light[level=13]
setblock 473 165 302 minecraft:light[level=13]
setblock 473 165 306 minecraft:cobbled_deepslate
fill 473 165 307 473 168 307 minecraft:deepslate_tiles
setblock 473 165 311 minecraft:cobbled_deepslate
fill 473 165 312 474 167 312 minecraft:deepslate_tiles
setblock 473 165 316 minecraft:cobbled_deepslate
fill 474 165 276 474 168 276 minecraft:deepslate_tiles
setblock 474 165 305 minecraft:cobbled_deepslate
fill 474 165 306 474 166 306 minecraft:deepslate_tiles
setblock 474 165 309 minecraft:deepslate_tiles
setblock 474 165 310 minecraft:cobbled_deepslate
fill 474 165 311 474 168 311 minecraft:deepslate_tiles
setblock 474 165 315 minecraft:cobbled_deepslate
fill 474 165 316 474 168 316 minecraft:deepslate_tiles
setblock 475 165 309 minecraft:cobbled_deepslate
setblock 475 165 310 minecraft:deepslate_tiles
setblock 475 165 313 minecraft:deepslate_tiles
setblock 475 165 314 minecraft:cobbled_deepslate
fill 475 165 315 475 168 315 minecraft:deepslate_tiles
setblock 476 165 313 minecraft:cobbled_deepslate
fill 476 165 314 476 168 314 minecraft:deepslate_tiles
setblock 477 165 313 minecraft:deepslate_tiles
setblock 478 165 316 minecraft:cobbled_deepslate
setblock 479 165 315 minecraft:cobbled_deepslate
fill 479 165 316 479 168 316 minecraft:deepslate_tiles
setblock 481 165 278 minecraft:light[level=13]
setblock 481 165 286 minecraft:light[level=13]
setblock 481 165 294 minecraft:light[level=13]
setblock 481 165 302 minecraft:light[level=13]
setblock 481 165 310 minecraft:light[level=13]
setblock 489 165 278 minecraft:light[level=13]
setblock 489 165 286 minecraft:light[level=13]
setblock 489 165 294 minecraft:light[level=13]
setblock 489 165 302 minecraft:light[level=13]
setblock 489 165 310 minecraft:light[level=13]
fill 490 165 316 492 165 316 minecraft:deepslate_tiles
fill 491 165 276 492 165 276 minecraft:deepslate_tiles
fill 492 165 315 493 165 315 minecraft:deepslate_tiles
setblock 493 165 276 minecraft:cobbled_deepslate
setblock 493 165 316 minecraft:cobbled_deepslate
fill 494 165 276 494 168 276 minecraft:deepslate_tiles
setblock 494 165 315 minecraft:cobbled_deepslate
fill 494 165 316 494 168 316 minecraft:deepslate_tiles
fill 495 165 315 495 168 315 minecraft:deepslate_tiles
setblock 497 165 277 minecraft:cobbled_deepslate
setblock 497 165 278 minecraft:light[level=13]
setblock 497 165 286 minecraft:light[level=13]
setblock 497 165 294 minecraft:light[level=13]
setblock 497 165 302 minecraft:light[level=13]
setblock 497 165 310 minecraft:light[level=13]
setblock 497 165 316 minecraft:deepslate_tiles
setblock 498 165 276 minecraft:cobbled_deepslate
setblock 498 165 316 minecraft:cobbled_deepslate
fill 499 165 276 499 168 276 minecraft:deepslate_tiles
fill 499 165 316 499 168 316 minecraft:deepslate_tiles
setblock 502 165 276 minecraft:deepslate_tiles
setblock 503 165 276 minecraft:cobbled_deepslate
fill 504 165 276 504 168 276 minecraft:deepslate_tiles
setblock 505 165 278 minecraft:light[level=13]
setblock 505 165 286 minecraft:light[level=13]
setblock 505 165 294 minecraft:light[level=13]
setblock 505 165 302 minecraft:light[level=13]
setblock 505 165 310 minecraft:light[level=13]
fill 505 165 316 507 165 316 minecraft:deepslate_tiles
setblock 508 165 276 minecraft:cobbled_deepslate
setblock 508 165 315 minecraft:deepslate_tiles
setblock 508 165 316 minecraft:cobbled_deepslate
fill 509 165 276 509 168 276 minecraft:deepslate_tiles
setblock 509 165 310 minecraft:cobbled_deepslate
fill 509 165 311 509 166 313 minecraft:deepslate_tiles
setblock 509 165 315 minecraft:cobbled_deepslate
fill 509 165 316 509 168 316 minecraft:deepslate_tiles
setblock 510 165 279 minecraft:cobbled_deepslate
setblock 510 165 280 minecraft:deepslate_tiles
setblock 510 165 284 minecraft:cobbled_deepslate
fill 510 165 285 510 167 285 minecraft:deepslate_tiles
setblock 510 165 288 minecraft:deepslate_tiles
setblock 510 165 289 minecraft:cobbled_deepslate
fill 510 165 290 510 168 290 minecraft:deepslate_tiles
fill 510 165 306 510 165 308 minecraft:deepslate_tiles
setblock 510 165 309 minecraft:cobbled_deepslate
fill 510 165 310 510 168 310 minecraft:deepslate_tiles
setblock 510 165 313 minecraft:deepslate_tiles
setblock 510 165 314 minecraft:cobbled_deepslate
fill 510 165 315 510 168 315 minecraft:deepslate_tiles
setblock 511 165 278 minecraft:cobbled_deepslate
fill 511 165 279 511 168 279 minecraft:deepslate_tiles
setblock 511 165 283 minecraft:cobbled_deepslate
fill 511 165 284 511 168 284 minecraft:deepslate_tiles
setblock 511 165 288 minecraft:cobbled_deepslate
fill 511 165 289 511 168 289 minecraft:deepslate_tiles
setblock 511 165 293 minecraft:cobbled_deepslate
fill 511 165 294 511 167 295 minecraft:deepslate_tiles
setblock 511 165 302 minecraft:deepslate_tiles
setblock 511 165 303 minecraft:cobbled_deepslate
fill 511 165 304 511 165 307 minecraft:deepslate_tiles
setblock 511 165 308 minecraft:cobbled_deepslate
fill 511 165 309 511 168 309 minecraft:deepslate_tiles
setblock 511 165 313 minecraft:cobbled_deepslate
fill 511 165 314 511 168 314 minecraft:deepslate_tiles
setblock 471 166 276 minecraft:deepslate_tiles
setblock 471 166 277 minecraft:cobbled_deepslate
fill 471 166 278 471 167 278 minecraft:deepslate_tiles
setblock 471 166 282 minecraft:cobbled_deepslate
fill 471 166 283 471 167 283 minecraft:deepslate_tiles
setblock 471 166 287 minecraft:cobbled_deepslate
fill 471 166 288 471 169 288 minecraft:deepslate_tiles
setblock 471 166 291 minecraft:deepslate_tiles
setblock 471 166 292 minecraft:cobbled_deepslate
fill 471 166 293 471 166 296 minecraft:deepslate_tiles
setblock 471 166 297 minecraft:cobbled_deepslate
fill 471 166 298 472 168 298 minecraft:deepslate_tiles
setblock 471 166 302 minecraft:cobbled_deepslate
fill 471 166 303 471 169 303 minecraft:deepslate_tiles
setblock 471 166 307 minecraft:cobbled_deepslate
fill 471 166 308 471 169 308 minecraft:deepslate_tiles
setblock 471 166 312 minecraft:cobbled_deepslate
fill 471 166 313 471 169 313 minecraft:deepslate_tiles
setblock 472 166 276 minecraft:cobbled_deepslate
setblock 472 166 286 minecraft:cobbled_deepslate
fill 472 166 287 472 168 287 minecraft:deepslate_tiles
setblock 472 166 291 minecraft:cobbled_deepslate
fill 472 166 292 473 168 292 minecraft:deepslate_tiles
setblock 472 166 296 minecraft:cobbled_deepslate
fill 472 166 297 472 169 297 minecraft:deepslate_tiles
fill 472 166 299 472 167 299 minecraft:deepslate_tiles
setblock 472 166 301 minecraft:cobbled_deepslate
fill 472 166 302 472 169 302 minecraft:deepslate_tiles
setblock 472 166 306 minecraft:cobbled_deepslate
fill 472 166 307 472 169 307 minecraft:deepslate_tiles
setblock 472 166 311 minecraft:cobbled_deepslate
fill 472 166 312 472 169 312 minecraft:deepslate_tiles
setblock 472 166 316 minecraft:cobbled_deepslate
fill 473 166 276 473 169 276 minecraft:deepslate_tiles
setblock 473 166 290 minecraft:cobbled_deepslate
fill 473 166 291 473 168 291 minecraft:deepslate_tiles
setblock 473 166 305 minecraft:cobbled_deepslate
fill 473 166 306 473 168 306 minecraft:deepslate_tiles
setblock 473 166 310 minecraft:cobbled_deepslate
fill 473 166 311 473 169 311 minecraft:deepslate_tiles
setblock 473 166 315 minecraft:cobbled_deepslate
fill 473 166 316 473 169 316 minecraft:deepslate_tiles
setblock 474 166 309 minecraft:cobbled_deepslate
fill 474 166 310 474 168 310 minecraft:deepslate_tiles
setblock 474 166 314 minecraft:cobbled_deepslate
fill 474 166 315 474 169 315 minecraft:deepslate_tiles
setblock 475 166 313 minecraft:cobbled_deepslate
fill 475 166 314 475 169 314 minecraft:deepslate_tiles
setblock 476 166 313 minecraft:deepslate_tiles
setblock 477 166 316 minecraft:cobbled_deepslate
setblock 478 166 315 minecraft:cobbled_deepslate
fill 478 166 316 478 169 316 minecraft:deepslate_tiles
setblock 479 166 315 minecraft:deepslate_tiles
fill 489 166 316 491 166 316 minecraft:deepslate_tiles
fill 490 166 276 491 166 276 minecraft:deepslate_tiles
setblock 492 166 276 minecraft:cobbled_deepslate
setblock 492 166 315 minecraft:deepslate_tiles
setblock 492 166 316 minecraft:cobbled_deepslate
fill 493 166 276 493 169 276 minecraft:deepslate_tiles
setblock 493 166 315 minecraft:cobbled_deepslate
fill 493 166 316 493 169 316 minecraft:deepslate_tiles
fill 494 166 315 494 169 315 minecraft:deepslate_tiles
setblock 496 166 277 minecraft:cobbled_deepslate
setblock 497 166 276 minecraft:cobbled_deepslate
setblock 497 166 277 minecraft:deepslate_tiles
setblock 497 166 316 minecraft:cobbled_deepslate
fill 498 166 276 498 169 276 minecraft:deepslate_tiles
fill 498 166 316 498 169 316 minecraft:deepslate_tiles
setblock 502 166 276 minecraft:cobbled_deepslate
setblock 502 166 316 minecraft:cobbled_deepslate
setblock 503 166 276 minecraft:deepslate_tiles
fill 503 166 316 506 166 316 minecraft:deepslate_tiles
setblock 506 166 276 minecraft:deepslate_tiles
setblock 507 166 276 minecraft:cobbled_deepslate
fill 507 166 313 507 170 313 minecraft:cobbled_deepslate
setblock 507 166 315 minecraft:deepslate_tiles
setblock 507 166 316 minecraft:cobbled_deepslate
fill 508 166 276 508 169 276 minecraft:deepslate_tiles
setblock 508 166 315 minecraft:cobbled_deepslate
fill 508 166 316 508 169 316 minecraft:deepslate_tiles
fill 509 166 310 509 168 310 minecraft:deepslate_tiles
setblock 509 166 314 minecraft:cobbled_deepslate
fill 509 166 315 509 169 315 minecraft:deepslate_tiles
fill 510 166 276 510 166 277 minecraft:deepslate_tiles
setblock 510 166 283 minecraft:cobbled_deepslate
setblock 510 166 284 minecraft:deepslate_tiles
setblock 510 166 288 minecraft:cobbled_deepslate
fill 510 166 289 510 169 289 minecraft:deepslate_tiles
setblock 510 166 292 minecraft:deepslate_tiles
fill 510 166 306 510 166 307 minecraft:deepslate_tiles
setblock 510 166 308 minecraft:cobbled_deepslate
fill 510 166 309 510 169 309 minecraft:deepslate_tiles
setblock 510 166 313 minecraft:cobbled_deepslate
fill 510 166 314 510 169 314 minecraft:deepslate_tiles
setblock 511 166 277 minecraft:cobbled_deepslate
fill 511 166 278 511 169 278 minecraft:deepslate_tiles
setblock 511 166 282 minecraft:cobbled_deepslate
fill 511 166 283 511 169 283 minecraft:deepslate_tiles
setblock 511 166 287 minecraft:cobbled_deepslate
fill 511 166 288 511 169 288 minecraft:deepslate_tiles
setblock 511 166 292 minecraft:cobbled_deepslate
fill 511 166 293 511 169 293 minecraft:deepslate_tiles
setblock 511 166 296 minecraft:deepslate_tiles
fill 511 166 303 511 166 306 minecraft:deepslate_tiles
setblock 511 166 307 minecraft:cobbled_deepslate
fill 511 166 308 511 169 308 minecraft:deepslate_tiles
setblock 511 166 312 minecraft:cobbled_deepslate
fill 511 166 313 511 169 313 minecraft:deepslate_tiles
setblock 471 167 276 minecraft:cobbled_deepslate
fill 471 167 277 471 170 277 minecraft:deepslate_tiles
setblock 471 167 286 minecraft:cobbled_deepslate
fill 471 167 287 471 170 287 minecraft:deepslate_tiles
setblock 471 167 291 minecraft:cobbled_deepslate
fill 471 167 292 471 167 295 minecraft:deepslate_tiles
setblock 471 167 296 minecraft:cobbled_deepslate
fill 471 167 297 471 170 297 minecraft:deepslate_tiles
setblock 471 167 300 minecraft:deepslate_tiles
setblock 471 167 301 minecraft:cobbled_deepslate
fill 471 167 302 471 170 302 minecraft:deepslate_tiles
setblock 471 167 306 minecraft:cobbled_deepslate
fill 471 167 307 471 170 307 minecraft:deepslate_tiles
setblock 471 167 311 minecraft:cobbled_deepslate
fill 471 167 312 471 170 312 minecraft:deepslate_tiles
setblock 471 167 315 minecraft:deepslate_tiles
setblock 471 167 316 minecraft:cobbled_deepslate
fill 472 167 276 472 170 276 minecraft:deepslate_tiles
setblock 472 167 286 minecraft:deepslate_tiles
setblock 472 167 289 minecraft:deepslate_tiles
setblock 472 167 290 minecraft:cobbled_deepslate
fill 472 167 291 472 170 291 minecraft:deepslate_tiles
fill 472 167 293 472 167 294 minecraft:deepslate_tiles
setblock 472 167 295 minecraft:cobbled_deepslate
fill 472 167 296 472 170 296 minecraft:deepslate_tiles
setblock 472 167 300 minecraft:cobbled_deepslate
fill 472 167 301 472 168 301 minecraft:deepslate_tiles
setblock 472 167 305 minecraft:cobbled_deepslate
fill 472 167 306 472 170 306 minecraft:deepslate_tiles
setblock 472 167 310 minecraft:cobbled_deepslate
fill 472 167 311 472 170 311 minecraft:deepslate_tiles
setblock 472 167 315 minecraft:cobbled_deepslate
fill 472 167 316 472 170 316 minecraft:deepslate_tiles
setblock 473 167 290 minecraft:deepslate_tiles
setblock 473 167 293 minecraft:deepslate_tiles
setblock 473 167 304 minecraft:cobbled_deepslate
setblock 473 167 305 minecraft:deepslate_tiles
setblock 473 167 309 minecraft:cobbled_deepslate
fill 473 167 310 473 170 310 minecraft:deepslate_tiles
setblock 473 167 314 minecraft:cobbled_deepslate
fill 473 167 315 473 170 315 minecraft:deepslate_tiles
setblock 474 167 308 minecraft:cobbled_deepslate
fill 474 167 309 474 168 309 minecraft:deepslate_tiles
setblock 474 167 313 minecraft:cobbled_deepslate
fill 474 167 314 474 170 314 minecraft:deepslate_tiles
setblock 475 167 313 minecraft:deepslate_tiles
setblock 476 167 316 minecraft:cobbled_deepslate
setblock 477 167 315 minecraft:cobbled_deepslate
fill 477 167 316 477 170 316 minecraft:deepslate_tiles
setblock 478 167 315 minecraft:deepslate_tiles
fill 487 167 310 487 168 310 minecraft:white_wool
fill 489 167 316 490 167 316 minecraft:deepslate_tiles
setblock 490 167 276 minecraft:deepslate_tiles
setblock 491 167 276 minecraft:cobbled_deepslate
setblock 491 167 315 minecraft:deepslate_tiles
setblock 491 167 316 minecraft:cobbled_deepslate
fill 492 167 276 492 170 276 minecraft:deepslate_tiles
setblock 492 167 315 minecraft:cobbled_deepslate
fill 492 167 316 492 170 316 minecraft:deepslate_tiles
fill 493 167 277 493 168 277 minecraft:deepslate_tiles
fill 493 167 315 493 170 315 minecraft:deepslate_tiles
setblock 495 167 277 minecraft:cobbled_deepslate
setblock 496 167 276 minecraft:cobbled_deepslate
setblock 496 167 315 minecraft:deepslate_tiles
setblock 496 167 316 minecraft:cobbled_deepslate
fill 497 167 276 497 170 276 minecraft:deepslate_tiles
fill 497 167 316 497 170 316 minecraft:deepslate_tiles
setblock 500 167 316 minecraft:deepslate_tiles
setblock 501 167 276 minecraft:cobbled_deepslate
setblock 501 167 316 minecraft:cobbled_deepslate
fill 502 167 316 505 167 316 minecraft:deepslate_tiles
setblock 506 167 276 minecraft:cobbled_deepslate
setblock 506 167 315 minecraft:deepslate_tiles
setblock 506 167 316 minecraft:cobbled_deepslate
fill 507 167 276 507 170 276 minecraft:deepslate_tiles
setblock 507 167 315 minecraft:cobbled_deepslate
fill 507 167 316 507 170 316 minecraft:deepslate_tiles
setblock 508 167 314 minecraft:cobbled_deepslate
fill 508 167 315 508 170 315 minecraft:deepslate_tiles
fill 509 167 311 509 167 312 minecraft:deepslate_tiles
setblock 509 167 313 minecraft:cobbled_deepslate
fill 509 167 314 509 170 314 minecraft:deepslate_tiles
setblock 510 167 276 minecraft:deepslate_tiles
setblock 510 167 277 minecraft:cobbled_deepslate
setblock 510 167 287 minecraft:cobbled_deepslate
fill 510 167 288 510 168 288 minecraft:deepslate_tiles
setblock 510 167 292 minecraft:cobbled_deepslate
setblock 510 167 307 minecraft:cobbled_deepslate
fill 510 167 308 510 170 308 minecraft:deepslate_tiles
setblock 510 167 312 minecraft:cobbled_deepslate
fill 510 167 313 510 170 313 minecraft:deepslate_tiles
setblock 511 167 276 minecraft:cobbled_deepslate
fill 511 167 277 511 170 277 minecraft:deepslate_tiles
setblock 511 167 281 minecraft:cobbled_deepslate
fill 511 167 282 511 169 282 minecraft:deepslate_tiles
setblock 511 167 286 minecraft:cobbled_deepslate
fill 511 167 287 511 170 287 minecraft:deepslate_tiles
setblock 511 167 291 minecraft:cobbled_deepslate
fill 511 167 292 511 170 292 minecraft:deepslate_tiles
setblock 511 167 296 minecraft:cobbled_deepslate
fill 511 167 303 511 167 305 minecraft:deepslate_tiles
setblock 511 167 306 minecraft:cobbled_deepslate
fill 511 167 307 511 170 307 minecraft:deepslate_tiles
setblock 511 167 311 minecraft:cobbled_deepslate
fill 511 167 312 511 170 312 minecraft:deepslate_tiles
setblock 511 167 316 minecraft:cobbled_deepslate
fill 512 167 296 512 197 297 minecraft:black_concrete
setblock 512 167 298 minecraft:white_wool
fill 512 167 299 512 201 299 minecraft:black_concrete
fill 471 168 276 471 171 276 minecraft:deepslate_tiles
setblock 471 168 285 minecraft:cobbled_deepslate
fill 471 168 286 471 169 286 minecraft:deepslate_tiles
setblock 471 168 290 minecraft:cobbled_deepslate
fill 471 168 291 471 168 294 minecraft:deepslate_tiles
setblock 471 168 295 minecraft:cobbled_deepslate
fill 471 168 296 471 171 296 minecraft:deepslate_tiles
setblock 471 168 300 minecraft:cobbled_deepslate
fill 471 168 301 471 171 301 minecraft:deepslate_tiles
setblock 471 168 305 minecraft:cobbled_deepslate
fill 471 168 306 471 171 306 minecraft:deepslate_tiles
setblock 471 168 310 minecraft:cobbled_deepslate
fill 471 168 311 471 171 311 minecraft:deepslate_tiles
setblock 471 168 315 minecraft:cobbled_deepslate
fill 471 168 316 471 171 316 minecraft:deepslate_tiles
setblock 472 168 289 minecraft:cobbled_deepslate
fill 472 168 290 472 171 290 minecraft:deepslate_tiles
setblock 472 168 293 minecraft:deepslate_tiles
setblock 472 168 294 minecraft:cobbled_deepslate
fill 472 168 295 472 171 295 minecraft:deepslate_tiles
setblock 472 168 299 minecraft:cobbled_deepslate
fill 472 168 300 472 171 300 minecraft:deepslate_tiles
setblock 472 168 304 minecraft:cobbled_deepslate
fill 472 168 305 472 171 305 minecraft:deepslate_tiles
setblock 472 168 309 minecraft:cobbled_deepslate
fill 472 168 310 472 171 310 minecraft:deepslate_tiles
setblock 472 168 314 minecraft:cobbled_deepslate
fill 472 168 315 472 171 315 minecraft:deepslate_tiles
setblock 473 168 293 minecraft:cobbled_deepslate
setblock 473 168 308 minecraft:cobbled_deepslate
fill 473 168 309 473 170 309 minecraft:deepslate_tiles
setblock 473 168 312 minecraft:deepslate_tiles
setblock 473 168 313 minecraft:cobbled_deepslate
fill 473 168 314 473 171 314 minecraft:deepslate_tiles
setblock 474 168 312 minecraft:cobbled_deepslate
setblock 474 168 313 minecraft:deepslate_tiles
setblock 475 168 316 minecraft:cobbled_deepslate
setblock 476 168 315 minecraft:cobbled_deepslate
fill 476 168 316 476 171 316 minecraft:deepslate_tiles
fill 477 168 315 477 169 315 minecraft:deepslate_tiles
fill 488 168 316 489 168 316 minecraft:deepslate_tiles
setblock 490 168 276 minecraft:cobbled_deepslate
setblock 490 168 316 minecraft:cobbled_deepslate
fill 491 168 276 491 171 276 minecraft:deepslate_tiles
setblock 491 168 315 minecraft:cobbled_deepslate
fill 491 168 316 491 171 316 minecraft:deepslate_tiles
fill 492 168 315 492 171 315 minecraft:deepslate_tiles
setblock 494 168 277 minecraft:cobbled_deepslate
setblock 495 168 276 minecraft:cobbled_deepslate
setblock 495 168 316 minecraft:cobbled_deepslate
fill 496 168 276 496 171 276 minecraft:deepslate_tiles
setblock 496 168 315 minecraft:cobbled_deepslate
fill 496 168 316 496 171 316 minecraft:deepslate_tiles
setblock 500 168 276 minecraft:cobbled_deepslate
setblock 500 168 316 minecraft:cobbled_deepslate
fill 501 168 316 504 168 316 minecraft:deepslate_tiles
setblock 505 168 276 minecraft:cobbled_deepslate
setblock 505 168 316 minecraft:cobbled_deepslate
fill 506 168 276 506 171 276 minecraft:deepslate_tiles
setblock 506 168 315 minecraft:cobbled_deepslate
fill 506 168 316 506 171 316 minecraft:deepslate_tiles
fill 507 168 315 507 171 315 minecraft:deepslate_tiles
fill 508 168 314 508 171 314 minecraft:deepslate_tiles
setblock 509 168 311 minecraft:deepslate_tiles
setblock 509 168 312 minecraft:cobbled_deepslate
fill 509 168 313 509 171 313 minecraft:deepslate_tiles
setblock 510 168 276 minecraft:cobbled_deepslate
fill 510 168 277 510 171 277 minecraft:deepslate_tiles
setblock 510 168 287 minecraft:deepslate_tiles
setblock 510 168 291 minecraft:cobbled_deepslate
fill 510 168 292 510 171 292 minecraft:deepslate_tiles
setblock 510 168 307 minecraft:deepslate_tiles
setblock 510 168 311 minecraft:cobbled_deepslate
fill 510 168 312 510 171 312 minecraft:deepslate_tiles
setblock 510 168 316 minecraft:cobbled_deepslate
fill 511 168 276 511 171 276 minecraft:deepslate_tiles
setblock 511 168 280 minecraft:cobbled_deepslate
fill 511 168 281 511 169 281 minecraft:deepslate_tiles
setblock 511 168 285 minecraft:cobbled_deepslate
fill 511 168 286 511 170 286 minecraft:deepslate_tiles
setblock 511 168 290 minecraft:cobbled_deepslate
fill 511 168 291 511 171 291 minecraft:deepslate_tiles
setblock 511 168 294 minecraft:deepslate_tiles
setblock 511 168 295 minecraft:cobbled_deepslate
fill 511 168 296 511 170 297 minecraft:deepslate_tiles
setblock 511 168 304 minecraft:deepslate_tiles
setblock 511 168 305 minecraft:cobbled_deepslate
fill 511 168 306 511 171 306 minecraft:deepslate_tiles
setblock 511 168 310 minecraft:cobbled_deepslate
fill 511 168 311 511 171 311 minecraft:deepslate_tiles
setblock 511 168 315 minecraft:cobbled_deepslate
fill 511 168 316 511 171 316 minecraft:deepslate_tiles
setblock 512 168 298 minecraft:redstone_block
setblock 470 169 301 minecraft:white_wool
setblock 471 169 289 minecraft:cobbled_deepslate
fill 471 169 290 471 169 293 minecraft:deepslate_tiles
setblock 471 169 294 minecraft:cobbled_deepslate
fill 471 169 295 471 172 295 minecraft:deepslate_tiles
setblock 471 169 298 minecraft:deepslate_tiles
setblock 471 169 299 minecraft:cobbled_deepslate
fill 471 169 300 471 172 300 minecraft:deepslate_tiles
setblock 471 169 304 minecraft:cobbled_deepslate
fill 471 169 305 471 172 305 minecraft:deepslate_tiles
setblock 471 169 309 minecraft:cobbled_deepslate
fill 471 169 310 471 172 310 minecraft:deepslate_tiles
setblock 471 169 314 minecraft:cobbled_deepslate
fill 471 169 315 471 172 315 minecraft:deepslate_tiles
setblock 472 169 288 minecraft:cobbled_deepslate
fill 472 169 289 472 170 289 minecraft:deepslate_tiles
setblock 472 169 292 minecraft:deepslate_tiles
setblock 472 169 293 minecraft:cobbled_deepslate
fill 472 169 294 472 172 294 minecraft:deepslate_tiles
setblock 472 169 298 minecraft:cobbled_deepslate
fill 472 169 299 472 172 299 minecraft:deepslate_tiles
setblock 472 169 303 minecraft:cobbled_deepslate
fill 472 169 304 472 170 304 minecraft:deepslate_tiles
setblock 472 169 308 minecraft:cobbled_deepslate
fill 472 169 309 472 170 309 minecraft:deepslate_tiles
setblock 472 169 313 minecraft:cobbled_deepslate
fill 472 169 314 472 172 314 minecraft:deepslate_tiles
setblock 473 169 278 minecraft:light[level=12]
setblock 473 169 285 minecraft:light[level=12]
setblock 473 169 292 minecraft:light[level=12]
setblock 473 169 299 minecraft:light[level=12]
setblock 473 169 306 minecraft:light[level=12]
setblock 473 169 307 minecraft:cobbled_deepslate
setblock 473 169 308 minecraft:deepslate_tiles
setblock 473 169 312 minecraft:cobbled_deepslate
fill 473 169 313 473 172 313 minecraft:deepslate_tiles
setblock 474 169 276 minecraft:cobbled_deepslate
setblock 474 169 316 minecraft:cobbled_deepslate
setblock 475 169 315 minecraft:cobbled_deepslate
fill 475 169 316 475 172 316 minecraft:deepslate_tiles
fill 476 169 315 476 170 315 minecraft:deepslate_tiles
setblock 480 169 278 minecraft:light[level=12]
setblock 480 169 285 minecraft:light[level=12]
setblock 480 169 292 minecraft:light[level=12]
setblock 480 169 299 minecraft:light[level=12]
setblock 480 169 306 minecraft:light[level=12]
setblock 480 169 313 minecraft:light[level=12]
setblock 487 169 278 minecraft:light[level=12]
setblock 487 169 285 minecraft:light[level=12]
setblock 487 169 292 minecraft:light[level=12]
setblock 487 169 299 minecraft:light[level=12]
setblock 487 169 306 minecraft:light[level=12]
setblock 487 169 313 minecraft:light[level=12]
setblock 488 169 316 minecraft:deepslate_tiles
setblock 489 169 276 minecraft:cobbled_deepslate
setblock 489 169 316 minecraft:cobbled_deepslate
fill 490 169 276 490 172 276 minecraft:deepslate_tiles
fill 490 169 316 490 172 316 minecraft:deepslate_tiles
fill 491 169 315 491 172 315 minecraft:deepslate_tiles
setblock 493 169 277 minecraft:cobbled_deepslate
setblock 494 169 276 minecraft:cobbled_deepslate
fill 494 169 277 494 172 277 minecraft:deepslate_tiles
setblock 494 169 278 minecraft:light[level=12]
setblock 494 169 285 minecraft:light[level=12]
setblock 494 169 292 minecraft:light[level=12]
setblock 494 169 299 minecraft:light[level=12]
setblock 494 169 306 minecraft:light[level=12]
setblock 494 169 313 minecraft:light[level=12]
setblock 494 169 316 minecraft:cobbled_deepslate
fill 495 169 276 495 172 276 minecraft:deepslate_tiles
setblock 495 169 315 minecraft:cobbled_deepslate
fill 495 169 316 495 172 316 minecraft:deepslate_tiles
setblock 499 169 276 minecraft:cobbled_deepslate
setblock 499 169 316 minecraft:cobbled_deepslate
fill 500 169 276 500 172 276 minecraft:deepslate_tiles
fill 500 169 316 503 169 316 minecraft:deepslate_tiles
setblock 501 169 278 minecraft:light[level=12]
setblock 501 169 285 minecraft:light[level=12]
setblock 501 169 292 minecraft:light[level=12]
setblock 501 169 299 minecraft:light[level=12]
setblock 501 169 306 minecraft:light[level=12]
setblock 501 169 313 minecraft:light[level=12]
setblock 503 169 276 minecraft:deepslate_tiles
setblock 504 169 276 minecraft:cobbled_deepslate
setblock 504 169 316 minecraft:cobbled_deepslate
fill 505 169 276 505 172 276 minecraft:deepslate_tiles
setblock 505 169 315 minecraft:cobbled_deepslate
fill 505 169 316 505 172 316 minecraft:deepslate_tiles
fill 506 169 313 506 170 313 minecraft:cobbled_deepslate
fill 506 169 315 506 172 315 minecraft:deepslate_tiles
fill 507 169 312 507 170 312 minecraft:cobbled_deepslate
setblock 507 169 314 minecraft:cobbled_deepslate
setblock 508 169 278 minecraft:light[level=12]
setblock 508 169 285 minecraft:light[level=12]
setblock 508 169 292 minecraft:light[level=12]
setblock 508 169 299 minecraft:light[level=12]
setblock 508 169 306 minecraft:light[level=12]
fill 508 169 313 508 170 313 minecraft:cobbled_deepslate
setblock 509 169 276 minecraft:cobbled_deepslate
fill 509 169 277 509 172 277 minecraft:deepslate_tiles
setblock 509 169 311 minecraft:cobbled_deepslate
fill 509 169 312 509 172 312 minecraft:deepslate_tiles
setblock 509 169 316 minecraft:cobbled_deepslate
fill 510 169 276 510 172 276 minecraft:deepslate_tiles
setblock 510 169 290 minecraft:cobbled_deepslate
fill 510 169 291 510 170 291 minecraft:deepslate_tiles
setblock 510 169 310 minecraft:cobbled_deepslate
fill 510 169 311 510 172 311 minecraft:deepslate_tiles
setblock 510 169 315 minecraft:cobbled_deepslate
fill 510 169 316 510 172 316 minecraft:deepslate_tiles
setblock 511 169 279 minecraft:cobbled_deepslate
fill 511 169 280 511 172 280 minecraft:deepslate_tiles
setblock 511 169 284 minecraft:cobbled_deepslate
fill 511 169 285 511 170 285 minecraft:deepslate_tiles
setblock 511 169 289 minecraft:cobbled_deepslate
fill 511 169 290 511 172 290 minecraft:deepslate_tiles
setblock 511 169 294 minecraft:cobbled_deepslate
fill 511 169 295 511 172 295 minecraft:deepslate_tiles
setblock 511 169 298 minecraft:deepslate_tiles
setblock 511 169 304 minecraft:cobbled_deepslate
fill 511 169 305 511 172 305 minecraft:deepslate_tiles
setblock 511 169 309 minecraft:cobbled_deepslate
fill 511 169 310 511 172 310 minecraft:deepslate_tiles
setblock 511 169 314 minecraft:cobbled_deepslate
fill 511 169 315 511 172 315 minecraft:deepslate_tiles
fill 512 169 298 512 197 298 minecraft:black_concrete
fill 470 170 301 470 186 301 minecraft:black_concrete
setblock 471 170 288 minecraft:cobbled_deepslate
fill 471 170 289 471 170 292 minecraft:deepslate_tiles
setblock 471 170 293 minecraft:cobbled_deepslate
fill 471 170 294 471 173 294 minecraft:deepslate_tiles
setblock 471 170 298 minecraft:cobbled_deepslate
fill 471 170 299 471 173 299 minecraft:deepslate_tiles
setblock 471 170 303 minecraft:cobbled_deepslate
fill 471 170 304 471 173 304 minecraft:deepslate_tiles
setblock 471 170 308 minecraft:cobbled_deepslate
fill 471 170 309 471 173 309 minecraft:deepslate_tiles
setblock 471 170 313 minecraft:cobbled_deepslate
fill 471 170 314 471 173 314 minecraft:deepslate_tiles
setblock 472 170 292 minecraft:cobbled_deepslate
fill 472 170 293 472 173 293 minecraft:deepslate_tiles
setblock 472 170 297 minecraft:cobbled_deepslate
fill 472 170 298 472 173 298 minecraft:deepslate_tiles
setblock 472 170 303 minecraft:deepslate_tiles
setblock 472 170 307 minecraft:cobbled_deepslate
fill 472 170 308 472 173 308 minecraft:deepslate_tiles
setblock 472 170 312 minecraft:cobbled_deepslate
fill 472 170 313 472 173 313 minecraft:deepslate_tiles
setblock 473 170 276 minecraft:cobbled_deepslate
setblock 473 170 311 minecraft:cobbled_deepslate
fill 473 170 312 473 172 312 minecraft:deepslate_tiles
setblock 473 170 316 minecraft:cobbled_deepslate
setblock 474 170 315 minecraft:cobbled_deepslate
fill 474 170 316 474 173 316 minecraft:deepslate_tiles
setblock 475 170 312 minecraft:white_wool
fill 475 170 315 475 173 315 minecraft:deepslate_tiles
setblock 476 170 313 minecraft:white_wool
setblock 477 170 314 minecraft:white_wool
setblock 478 170 315 minecraft:white_wool
setblock 478 170 316 minecraft:cobbled_deepslate
setblock 487 170 316 minecraft:deepslate_tiles
setblock 488 170 276 minecraft:cobbled_deepslate
setblock 488 170 316 minecraft:cobbled_deepslate
fill 489 170 276 489 173 276 minecraft:deepslate_tiles
fill 489 170 316 489 173 316 minecraft:deepslate_tiles
fill 490 170 315 490 173 315 minecraft:deepslate_tiles
setblock 492 170 277 minecraft:cobbled_deepslate
setblock 493 170 276 minecraft:cobbled_deepslate
fill 493 170 277 493 173 277 minecraft:deepslate_tiles
setblock 493 170 316 minecraft:cobbled_deepslate
fill 494 170 276 494 173 276 minecraft:deepslate_tiles
setblock 494 170 315 minecraft:cobbled_deepslate
fill 494 170 316 494 173 316 minecraft:deepslate_tiles
setblock 498 170 276 minecraft:cobbled_deepslate
setblock 498 170 316 minecraft:cobbled_deepslate
fill 499 170 276 499 173 276 minecraft:deepslate_tiles
fill 499 170 316 502 170 316 minecraft:deepslate_tiles
fill 501 170 276 502 170 276 minecraft:deepslate_tiles
setblock 503 170 276 minecraft:cobbled_deepslate
setblock 503 170 316 minecraft:cobbled_deepslate
fill 504 170 276 504 173 276 minecraft:deepslate_tiles
fill 504 170 316 504 173 316 minecraft:deepslate_tiles
fill 505 170 315 505 173 315 minecraft:deepslate_tiles
setblock 506 170 312 minecraft:cobbled_deepslate
setblock 506 170 314 minecraft:cobbled_deepslate
fill 507 170 314 507 172 314 minecraft:deepslate_tiles
setblock 508 170 276 minecraft:cobbled_deepslate
fill 508 170 277 508 173 277 minecraft:deepslate_tiles
setblock 508 170 312 minecraft:cobbled_deepslate
setblock 508 170 316 minecraft:cobbled_deepslate
fill 509 170 276 509 173 276 minecraft:deepslate_tiles
fill 509 170 311 509 173 311 minecraft:deepslate_tiles
setblock 509 170 315 minecraft:cobbled_deepslate
fill 509 170 316 509 173 316 minecraft:deepslate_tiles
setblock 510 170 293 minecraft:deepslate_tiles
setblock 510 170 309 minecraft:cobbled_deepslate
fill 510 170 310 510 173 310 minecraft:deepslate_tiles
setblock 510 170 314 minecraft:cobbled_deepslate
fill 510 170 315 510 173 315 minecraft:deepslate_tiles
setblock 511 170 278 minecraft:cobbled_deepslate
fill 511 170 279 511 173 279 minecraft:deepslate_tiles
setblock 511 170 288 minecraft:cobbled_deepslate
fill 511 170 289 511 173 289 minecraft:deepslate_tiles
setblock 511 170 293 minecraft:cobbled_deepslate
fill 511 170 294 511 173 294 minecraft:deepslate_tiles
setblock 511 170 298 minecraft:cobbled_deepslate
fill 511 170 299 511 173 299 minecraft:deepslate_tiles
fill 511 170 304 511 173 304 minecraft:deepslate_tiles
setblock 511 170 308 minecraft:cobbled_deepslate
fill 511 170 309 511 173 309 minecraft:deepslate_tiles
setblock 511 170 313 minecraft:cobbled_deepslate
fill 511 170 314 511 173 314 minecraft:deepslate_tiles
setblock 471 171 277 minecraft:cobbled_deepslate
setblock 471 171 287 minecraft:cobbled_deepslate
fill 471 171 288 471 171 291 minecraft:deepslate_tiles
setblock 471 171 292 minecraft:cobbled_deepslate
fill 471 171 293 471 174 293 minecraft:deepslate_tiles
setblock 471 171 297 minecraft:cobbled_deepslate
fill 471 171 298 471 174 298 minecraft:deepslate_tiles
setblock 471 171 302 minecraft:cobbled_deepslate
fill 471 171 303 471 174 303 minecraft:deepslate_tiles
setblock 471 171 307 minecraft:cobbled_deepslate
setblock 471 171 308 minecraft:white_wool
setblock 471 171 312 minecraft:cobbled_deepslate
fill 471 171 313 471 174 313 minecraft:deepslate_tiles
setblock 472 171 276 minecraft:cobbled_deepslate
setblock 472 171 291 minecraft:cobbled_deepslate
fill 472 171 292 472 174 292 minecraft:deepslate_tiles
setblock 472 171 296 minecraft:cobbled_deepslate
fill 472 171 297 472 174 297 minecraft:deepslate_tiles
setblock 472 171 301 minecraft:cobbled_deepslate
setblock 472 171 306 minecraft:cobbled_deepslate
fill 472 171 307 472 174 307 minecraft:deepslate_tiles
setblock 472 171 309 minecraft:white_wool
setblock 472 171 311 minecraft:cobbled_deepslate
fill 472 171 312 472 174 312 minecraft:deepslate_tiles
setblock 472 171 316 minecraft:cobbled_deepslate
fill 473 171 276 473 174 276 minecraft:deepslate_tiles
setblock 473 171 310 minecraft:white_wool
setblock 473 171 311 minecraft:deepslate_tiles
setblock 473 171 315 minecraft:cobbled_deepslate
fill 473 171 316 473 174 316 minecraft:deepslate_tiles
setblock 474 171 311 minecraft:white_wool
setblock 474 171 314 minecraft:cobbled_deepslate
fill 474 171 315 474 174 315 minecraft:deepslate_tiles
setblock 477 171 316 minecraft:cobbled_deepslate
setblock 486 171 316 minecraft:deepslate_tiles
setblock 487 171 276 minecraft:cobbled_deepslate
setblock 487 171 316 minecraft:cobbled_deepslate
fill 488 171 276 488 174 276 minecraft:deepslate_tiles
fill 488 171 316 488 174 316 minecraft:deepslate_tiles
setblock 490 171 277 minecraft:deepslate_tiles
setblock 491 171 277 minecraft:cobbled_deepslate
setblock 492 171 276 minecraft:cobbled_deepslate
fill 492 171 277 492 174 277 minecraft:deepslate_tiles
setblock 492 171 316 minecraft:cobbled_deepslate
fill 493 171 276 493 174 276 minecraft:deepslate_tiles
setblock 493 171 315 minecraft:cobbled_deepslate
fill 493 171 316 493 174 316 minecraft:deepslate_tiles
setblock 494 171 315 minecraft:deepslate_tiles
setblock 497 171 276 minecraft:cobbled_deepslate
setblock 497 171 316 minecraft:cobbled_deepslate
fill 498 171 276 498 174 276 minecraft:deepslate_tiles
fill 498 171 316 501 171 316 minecraft:deepslate_tiles
setblock 501 171 276 minecraft:deepslate_tiles
setblock 502 171 276 minecraft:cobbled_deepslate
setblock 502 171 316 minecraft:cobbled_deepslate
fill 503 171 276 503 174 276 minecraft:deepslate_tiles
fill 503 171 316 503 174 316 minecraft:deepslate_tiles
fill 504 171 315 504 174 315 minecraft:deepslate_tiles
setblock 507 171 276 minecraft:cobbled_deepslate
fill 507 171 277 507 174 277 minecraft:deepslate_tiles
setblock 507 171 316 minecraft:cobbled_deepslate
fill 508 171 276 508 174 276 minecraft:deepslate_tiles
setblock 508 171 315 minecraft:cobbled_deepslate
fill 508 171 316 508 174 316 minecraft:deepslate_tiles
setblock 509 171 314 minecraft:cobbled_deepslate
fill 509 171 315 509 174 315 minecraft:deepslate_tiles
setblock 510 171 278 minecraft:cobbled_deepslate
setblock 510 171 293 minecraft:cobbled_deepslate
fill 510 171 294 510 174 294 minecraft:deepslate_tiles
setblock 510 171 308 minecraft:cobbled_deepslate
fill 510 171 309 510 174 309 minecraft:deepslate_tiles
setblock 510 171 313 minecraft:cobbled_deepslate
fill 510 171 314 510 174 314 minecraft:deepslate_tiles
setblock 511 171 277 minecraft:cobbled_deepslate
fill 511 171 278 511 174 278 minecraft:deepslate_tiles
setblock 511 171 287 minecraft:cobbled_deepslate
fill 511 171 288 511 172 288 minecraft:deepslate_tiles
setblock 511 171 292 minecraft:cobbled_deepslate
fill 511 171 293 511 174 293 minecraft:deepslate_tiles
setblock 511 171 296 minecraft:deepslate_tiles
setblock 511 171 297 minecraft:cobbled_deepslate
fill 511 171 298 511 174 298 minecraft:deepslate_tiles
fill 511 171 300 511 172 300 minecraft:deepslate_tiles
setblock 511 171 307 minecraft:cobbled_deepslate
fill 511 171 308 511 174 308 minecraft:deepslate_tiles
setblock 511 171 312 minecraft:cobbled_deepslate
fill 511 171 313 511 174 313 minecraft:deepslate_tiles
setblock 470 172 309 minecraft:redstone_block
setblock 471 172 276 minecraft:cobbled_deepslate
fill 471 172 277 471 174 278 minecraft:deepslate_tiles
fill 471 172 288 471 172 290 minecraft:deepslate_tiles
setblock 471 172 291 minecraft:cobbled_deepslate
fill 471 172 292 471 175 292 minecraft:deepslate_tiles
setblock 471 172 296 minecraft:cobbled_deepslate
fill 471 172 297 471 175 297 minecraft:deepslate_tiles
setblock 471 172 301 minecraft:cobbled_deepslate
fill 471 172 302 472 174 302 minecraft:deepslate_tiles
setblock 471 172 306 minecraft:cobbled_deepslate
fill 471 172 307 471 174 308 minecraft:deepslate_tiles
setblock 471 172 311 minecraft:cobbled_deepslate
fill 471 172 312 471 175 312 minecraft:deepslate_tiles
setblock 471 172 316 minecraft:cobbled_deepslate
fill 472 172 276 472 175 276 minecraft:deepslate_tiles
setblock 472 172 290 minecraft:cobbled_deepslate
fill 472 172 291 472 175 291 minecraft:deepslate_tiles
setblock 472 172 295 minecraft:cobbled_deepslate
fill 472 172 296 473 174 296 minecraft:deepslate_tiles
setblock 472 172 300 minecraft:cobbled_deepslate
fill 472 172 301 472 175 301 minecraft:deepslate_tiles
fill 472 172 303 472 173 303 minecraft:deepslate_tiles
setblock 472 172 305 minecraft:cobbled_deepslate
fill 472 172 306 472 175 306 minecraft:deepslate_tiles
setblock 472 172 309 minecraft:deepslate_tiles
setblock 472 172 310 minecraft:cobbled_deepslate
fill 472 172 311 472 175 311 minecraft:deepslate_tiles
setblock 472 172 315 minecraft:cobbled_deepslate
fill 472 172 316 472 175 316 minecraft:deepslate_tiles
setblock 473 172 294 minecraft:cobbled_deepslate
fill 473 172 295 473 175 295 minecraft:deepslate_tiles
setblock 473 172 314 minecraft:cobbled_deepslate
fill 473 172 315 473 175 315 minecraft:deepslate_tiles
setblock 476 172 316 minecraft:cobbled_deepslate
fill 477 172 316 477 175 316 minecraft:deepslate_tiles
fill 485 172 289 485 173 289 minecraft:white_wool
setblock 486 172 276 minecraft:cobbled_deepslate
setblock 486 172 316 minecraft:cobbled_deepslate
fill 487 172 276 487 175 276 minecraft:deepslate_tiles
fill 487 172 316 487 175 316 minecraft:deepslate_tiles
setblock 489 172 277 minecraft:deepslate_tiles
fill 489 172 315 489 174 315 minecraft:deepslate_tiles
setblock 490 172 277 minecraft:cobbled_deepslate
fill 490 172 283 490 175 284 minecraft:white_terracotta
setblock 491 172 276 minecraft:cobbled_deepslate
fill 491 172 277 491 175 277 minecraft:deepslate_tiles
fill 491 172 284 491 175 284 minecraft:white_terracotta
setblock 491 172 316 minecraft:cobbled_deepslate
fill 492 172 276 492 175 276 minecraft:deepslate_tiles
setblock 492 172 315 minecraft:cobbled_deepslate
fill 492 172 316 492 175 316 minecraft:deepslate_tiles
fill 493 172 315 493 175 315 minecraft:deepslate_tiles
setblock 495 172 277 minecraft:cobbled_deepslate
setblock 496 172 276 minecraft:cobbled_deepslate
setblock 496 172 316 minecraft:cobbled_deepslate
fill 497 172 276 497 175 276 minecraft:deepslate_tiles
fill 497 172 316 500 172 316 minecraft:deepslate_tiles
setblock 501 172 276 minecraft:cobbled_deepslate
setblock 501 172 316 minecraft:cobbled_deepslate
fill 502 172 276 502 175 276 minecraft:deepslate_tiles
fill 502 172 316 502 175 316 minecraft:deepslate_tiles
setblock 506 172 276 minecraft:cobbled_deepslate
fill 506 172 277 506 175 277 minecraft:deepslate_tiles
fill 506 172 314 506 173 314 minecraft:deepslate_tiles
setblock 506 172 316 minecraft:cobbled_deepslate
fill 507 172 276 507 175 276 minecraft:deepslate_tiles
setblock 507 172 315 minecraft:cobbled_deepslate
fill 507 172 316 507 175 316 minecraft:deepslate_tiles
setblock 508 172 314 minecraft:cobbled_deepslate
fill 508 172 315 508 175 315 minecraft:deepslate_tiles
setblock 509 172 313 minecraft:cobbled_deepslate
fill 509 172 314 509 175 314 minecraft:deepslate_tiles
setblock 510 172 277 minecraft:cobbled_deepslate
fill 510 172 278 510 175 278 minecraft:deepslate_tiles
setblock 510 172 292 minecraft:cobbled_deepslate
fill 510 172 293 510 175 293 minecraft:deepslate_tiles
fill 510 172 295 510 172 296 minecraft:deepslate_tiles
fill 510 172 308 510 175 308 minecraft:deepslate_tiles
setblock 510 172 312 minecraft:cobbled_deepslate
fill 510 172 313 510 175 313 minecraft:deepslate_tiles
setblock 511 172 276 minecraft:cobbled_deepslate
fill 511 172 277 511 175 277 minecraft:deepslate_tiles
setblock 511 172 291 minecraft:cobbled_deepslate
fill 511 172 292 511 175 292 minecraft:deepslate_tiles
setblock 511 172 296 minecraft:cobbled_deepslate
fill 511 172 297 511 175 297 minecraft:deepslate_tiles
setblock 511 172 301 minecraft:cobbled_deepslate
fill 511 172 302 511 174 303 minecraft:deepslate_tiles
setblock 511 172 306 minecraft:cobbled_deepslate
fill 511 172 307 511 175 307 minecraft:deepslate_tiles
setblock 511 172 311 minecraft:cobbled_deepslate
fill 511 172 312 511 175 312 minecraft:deepslate_tiles
setblock 511 172 316 minecraft:cobbled_deepslate
fill 470 173 309 470 202 309 minecraft:black_concrete
fill 471 173 276 471 176 276 minecraft:deepslate_tiles
fill 471 173 288 471 173 289 minecraft:deepslate_tiles
setblock 471 173 290 minecraft:cobbled_deepslate
fill 471 173 291 471 176 291 minecraft:deepslate_tiles
setblock 471 173 295 minecraft:cobbled_deepslate
fill 471 173 296 471 176 296 minecraft:deepslate_tiles
setblock 471 173 300 minecraft:cobbled_deepslate
fill 471 173 301 471 176 301 minecraft:deepslate_tiles
setblock 471 173 305 minecraft:cobbled_deepslate
fill 471 173 306 471 176 306 minecraft:deepslate_tiles
setblock 471 173 310 minecraft:cobbled_deepslate
fill 471 173 311 471 176 311 minecraft:deepslate_tiles
setblock 471 173 315 minecraft:cobbled_deepslate
fill 471 173 316 471 176 316 minecraft:deepslate_tiles
setblock 472 173 294 minecraft:cobbled_deepslate
fill 472 173 295 472 176 295 minecraft:deepslate_tiles
setblock 472 173 299 minecraft:cobbled_deepslate
fill 472 173 300 472 176 300 minecraft:deepslate_tiles
setblock 472 173 304 minecraft:cobbled_deepslate
fill 472 173 305 472 176 305 minecraft:deepslate_tiles
setblock 472 173 309 minecraft:cobbled_deepslate
fill 472 173 310 472 176 310 minecraft:deepslate_tiles
setblock 472 173 314 minecraft:cobbled_deepslate
fill 472 173 315 472 176 315 minecraft:deepslate_tiles
setblock 473 173 278 minecraft:light[level=13]
fill 473 173 282 473 181 282 minecraft:black_concrete
setblock 473 173 286 minecraft:light[level=13]
fill 473 173 294 473 176 294 minecraft:deepslate_tiles
setblock 473 173 297 minecraft:deepslate_tiles
setblock 473 173 298 minecraft:cobbled_deepslate
setblock 473 173 302 minecraft:light[level=13]
setblock 473 173 310 minecraft:light[level=13]
setblock 474 173 276 minecraft:deepslate_tiles
setblock 475 173 316 minecraft:cobbled_deepslate
fill 476 173 316 476 176 316 minecraft:deepslate_tiles
setblock 481 173 278 minecraft:light[level=13]
setblock 481 173 286 minecraft:light[level=13]
setblock 481 173 294 minecraft:light[level=13]
setblock 481 173 302 minecraft:light[level=13]
setblock 481 173 310 minecraft:light[level=13]
setblock 484 173 316 minecraft:deepslate_tiles
setblock 485 173 276 minecraft:cobbled_deepslate
setblock 485 173 316 minecraft:cobbled_deepslate
fill 486 173 276 486 176 276 minecraft:deepslate_tiles
fill 486 173 316 486 176 316 minecraft:deepslate_tiles
fill 487 173 277 488 173 277 minecraft:deepslate_tiles
fill 488 173 315 488 175 315 minecraft:deepslate_tiles
setblock 489 173 277 minecraft:cobbled_deepslate
setblock 489 173 278 minecraft:light[level=13]
fill 489 173 284 489 174 284 minecraft:white_terracotta
setblock 489 173 286 minecraft:light[level=13]
setblock 489 173 294 minecraft:light[level=13]
setblock 489 173 302 minecraft:light[level=13]
setblock 489 173 310 minecraft:light[level=13]
setblock 490 173 276 minecraft:cobbled_deepslate
fill 490 173 277 490 176 277 minecraft:deepslate_tiles
fill 490 173 285 491 174 285 minecraft:white_terracotta
setblock 490 173 316 minecraft:cobbled_deepslate
fill 491 173 276 491 176 276 minecraft:deepslate_tiles
fill 491 173 283 491 174 283 minecraft:white_terracotta
setblock 491 173 315 minecraft:cobbled_deepslate
fill 491 173 316 491 176 316 minecraft:deepslate_tiles
fill 492 173 315 492 176 315 minecraft:deepslate_tiles
fill 493 173 279 493 174 279 minecraft:white_wool
setblock 494 173 277 minecraft:cobbled_deepslate
setblock 495 173 276 minecraft:cobbled_deepslate
fill 495 173 277 496 175 277 minecraft:deepslate_tiles
setblock 495 173 316 minecraft:cobbled_deepslate
fill 496 173 276 496 176 276 minecraft:deepslate_tiles
fill 496 173 316 499 173 316 minecraft:deepslate_tiles
setblock 497 173 278 minecraft:light[level=13]
setblock 497 173 286 minecraft:light[level=13]
setblock 497 173 294 minecraft:light[level=13]
setblock 497 173 302 minecraft:light[level=13]
setblock 497 173 310 minecraft:light[level=13]
setblock 500 173 276 minecraft:cobbled_deepslate
setblock 500 173 316 minecraft:cobbled_deepslate
fill 501 173 276 501 176 276 minecraft:deepslate_tiles
fill 501 173 316 501 176 316 minecraft:deepslate_tiles
fill 503 173 315 503 175 315 minecraft:deepslate_tiles
setblock 504 173 277 minecraft:cobbled_deepslate
setblock 505 173 276 minecraft:cobbled_deepslate
fill 505 173 277 505 176 277 minecraft:deepslate_tiles
setblock 505 173 278 minecraft:light[level=13]
setblock 505 173 286 minecraft:light[level=13]
setblock 505 173 294 minecraft:light[level=13]
setblock 505 173 302 minecraft:light[level=13]
setblock 505 173 310 minecraft:light[level=13]
setblock 505 173 316 minecraft:cobbled_deepslate
fill 506 173 276 506 176 276 minecraft:deepslate_tiles
setblock 506 173 315 minecraft:cobbled_deepslate
fill 506 173 316 506 176 316 minecraft:deepslate_tiles
setblock 507 173 314 minecraft:cobbled_deepslate
fill 507 173 315 507 176 315 minecraft:deepslate_tiles
fill 508 173 314 508 176 314 minecraft:deepslate_tiles
setblock 509 173 277 minecraft:cobbled_deepslate
setblock 509 173 312 minecraft:cobbled_deepslate
fill 509 173 313 509 176 313 minecraft:deepslate_tiles
setblock 510 173 276 minecraft:cobbled_deepslate
fill 510 173 277 510 176 277 minecraft:deepslate_tiles
fill 510 173 279 510 174 279 minecraft:deepslate_tiles
fill 510 173 292 510 176 292 minecraft:deepslate_tiles
setblock 510 173 295 minecraft:deepslate_tiles
setblock 510 173 296 minecraft:cobbled_deepslate
fill 510 173 297 510 175 298 minecraft:deepslate_tiles
setblock 510 173 311 minecraft:cobbled_deepslate
fill 510 173 312 510 176 312 minecraft:deepslate_tiles
setblock 510 173 316 minecraft:cobbled_deepslate
fill 511 173 276 511 176 276 minecraft:deepslate_tiles
setblock 511 173 280 minecraft:cobbled_deepslate
fill 511 173 281 511 176 281 minecraft:deepslate_tiles
setblock 511 173 290 minecraft:cobbled_deepslate
fill 511 173 291 511 176 291 minecraft:deepslate_tiles
setblock 511 173 295 minecraft:cobbled_deepslate
fill 511 173 296 511 176 296 minecraft:deepslate_tiles
setblock 511 173 300 minecraft:cobbled_deepslate
fill 511 173 301 511 176 301 minecraft:deepslate_tiles
setblock 511 173 305 minecraft:cobbled_deepslate
fill 511 173 306 511 176 306 minecraft:deepslate_tiles
setblock 511 173 310 minecraft:cobbled_deepslate
fill 511 173 311 511 176 311 minecraft:deepslate_tiles
setblock 511 173 315 minecraft:cobbled_deepslate
fill 511 173 316 511 176 316 minecraft:deepslate_tiles
setblock 471 174 279 minecraft:cobbled_deepslate
setblock 471 174 288 minecraft:deepslate_tiles
setblock 471 174 289 minecraft:cobbled_deepslate
fill 471 174 290 471 177 290 minecraft:deepslate_tiles
setblock 471 174 294 minecraft:cobbled_deepslate
fill 471 174 295 471 177 295 minecraft:deepslate_tiles
setblock 471 174 299 minecraft:cobbled_deepslate
fill 471 174 300 471 177 300 minecraft:deepslate_tiles
setblock 471 174 304 minecraft:cobbled_deepslate
fill 471 174 305 471 177 305 minecraft:deepslate_tiles
setblock 471 174 309 minecraft:cobbled_deepslate
fill 471 174 310 471 177 310 minecraft:deepslate_tiles
setblock 471 174 314 minecraft:cobbled_deepslate
fill 471 174 315 471 177 315 minecraft:deepslate_tiles
setblock 472 174 293 minecraft:cobbled_deepslate
fill 472 174 294 472 177 294 minecraft:deepslate_tiles
setblock 472 174 298 minecraft:cobbled_deepslate
fill 472 174 299 473 176 299 minecraft:deepslate_tiles
setblock 472 174 303 minecraft:cobbled_deepslate
fill 472 174 304 472 177 304 minecraft:deepslate_tiles
setblock 472 174 308 minecraft:cobbled_deepslate
fill 472 174 309 472 176 309 minecraft:deepslate_tiles
setblock 472 174 313 minecraft:cobbled_deepslate
fill 472 174 314 472 177 314 minecraft:deepslate_tiles
setblock 473 174 297 minecraft:cobbled_deepslate
fill 473 174 298 473 177 298 minecraft:deepslate_tiles
setblock 474 174 276 minecraft:cobbled_deepslate
setblock 474 174 316 minecraft:cobbled_deepslate
fill 475 174 316 475 177 316 minecraft:deepslate_tiles
setblock 483 174 276 minecraft:deepslate_tiles
setblock 483 174 316 minecraft:deepslate_tiles
setblock 484 174 276 minecraft:cobbled_deepslate
setblock 484 174 316 minecraft:cobbled_deepslate
fill 485 174 276 485 177 276 minecraft:deepslate_tiles
fill 485 174 316 485 177 316 minecraft:deepslate_tiles
fill 486 174 277 487 174 277 minecraft:deepslate_tiles
fill 487 174 315 487 176 315 minecraft:deepslate_tiles
setblock 488 174 277 minecraft:cobbled_deepslate
setblock 489 174 276 minecraft:cobbled_deepslate
fill 489 174 277 489 176 278 minecraft:deepslate_tiles
setblock 489 174 316 minecraft:cobbled_deepslate
setblock 490 174 275 minecraft:white_wool
fill 490 174 276 490 177 276 minecraft:deepslate_tiles
fill 490 174 278 491 174 278 minecraft:deepslate_tiles
setblock 490 174 315 minecraft:cobbled_deepslate
fill 490 174 316 490 177 316 minecraft:deepslate_tiles
fill 491 174 315 491 177 315 minecraft:deepslate_tiles
setblock 492 174 278 minecraft:cobbled_deepslate
setblock 493 174 277 minecraft:cobbled_deepslate
setblock 494 174 276 minecraft:cobbled_deepslate
fill 494 174 277 494 177 277 minecraft:deepslate_tiles
setblock 494 174 316 minecraft:cobbled_deepslate
fill 495 174 276 495 177 276 minecraft:deepslate_tiles
fill 495 174 316 498 174 316 minecraft:deepslate_tiles
setblock 497 174 277 minecraft:deepslate_tiles
setblock 498 174 277 minecraft:cobbled_deepslate
setblock 499 174 276 minecraft:cobbled_deepslate
setblock 499 174 316 minecraft:cobbled_deepslate
fill 500 174 276 500 176 277 minecraft:deepslate_tiles
fill 500 174 316 500 177 316 minecraft:deepslate_tiles
fill 501 174 277 502 174 277 minecraft:deepslate_tiles
fill 502 174 315 502 176 315 minecraft:deepslate_tiles
setblock 503 174 277 minecraft:cobbled_deepslate
setblock 504 174 276 minecraft:cobbled_deepslate
fill 504 174 277 504 177 277 minecraft:deepslate_tiles
setblock 504 174 316 minecraft:cobbled_deepslate
fill 505 174 276 505 177 276 minecraft:deepslate_tiles
setblock 505 174 314 minecraft:deepslate_tiles
setblock 505 174 315 minecraft:cobbled_deepslate
fill 505 174 316 505 177 316 minecraft:deepslate_tiles
setblock 506 174 314 minecraft:cobbled_deepslate
fill 506 174 315 506 177 315 minecraft:deepslate_tiles
fill 507 174 314 507 177 314 minecraft:deepslate_tiles
setblock 508 174 277 minecraft:cobbled_deepslate
fill 508 174 278 508 177 278 minecraft:deepslate_tiles
setblock 509 174 276 minecraft:cobbled_deepslate
fill 509 174 277 509 177 277 minecraft:deepslate_tiles
setblock 509 174 311 minecraft:cobbled_deepslate
fill 509 174 312 509 177 312 minecraft:deepslate_tiles
setblock 509 174 316 minecraft:cobbled_deepslate
fill 510 174 276 510 177 276 minecraft:deepslate_tiles
setblock 510 174 295 minecraft:cobbled_deepslate
fill 510 174 296 510 177 296 minecraft:deepslate_tiles
setblock 510 174 299 minecraft:deepslate_tiles
setblock 510 174 300 minecraft:cobbled_deepslate
fill 510 174 301 510 177 301 minecraft:deepslate_tiles
fill 510 174 307 510 176 307 minecraft:deepslate_tiles
setblock 510 174 310 minecraft:cobbled_deepslate
fill 510 174 311 510 177 311 minecraft:deepslate_tiles
setblock 510 174 315 minecraft:cobbled_deepslate
fill 510 174 316 510 177 316 minecraft:deepslate_tiles
setblock 511 174 279 minecraft:cobbled_deepslate
fill 511 174 280 511 177 280 minecraft:deepslate_tiles
setblock 511 174 289 minecraft:cobbled_deepslate
fill 511 174 290 511 177 290 minecraft:deepslate_tiles
setblock 511 174 294 minecraft:cobbled_deepslate
fill 511 174 295 511 177 295 minecraft:deepslate_tiles
setblock 511 174 299 minecraft:cobbled_deepslate
fill 511 174 300 511 177 300 minecraft:deepslate_tiles
setblock 511 174 304 minecraft:cobbled_deepslate
fill 511 174 305 511 177 305 minecraft:deepslate_tiles
setblock 511 174 309 minecraft:cobbled_deepslate
fill 511 174 310 511 177 310 minecraft:deepslate_tiles
setblock 511 174 314 minecraft:cobbled_deepslate
fill 511 174 315 511 177 315 minecraft:deepslate_tiles
setblock 470 175 313 minecraft:redstone_block
setblock 471 175 277 minecraft:deepslate_tiles
setblock 471 175 278 minecraft:cobbled_deepslate
fill 471 175 279 471 177 280 minecraft:deepslate_tiles
setblock 471 175 288 minecraft:cobbled_deepslate
fill 471 175 289 471 178 289 minecraft:deepslate_tiles
setblock 471 175 293 minecraft:cobbled_deepslate
fill 471 175 294 471 178 294 minecraft:deepslate_tiles
setblock 471 175 298 minecraft:cobbled_deepslate
fill 471 175 299 471 178 299 minecraft:deepslate_tiles
setblock 471 175 302 minecraft:deepslate_tiles
setblock 471 175 303 minecraft:cobbled_deepslate
fill 471 175 304 471 178 304 minecraft:deepslate_tiles
setblock 471 175 307 minecraft:deepslate_tiles
setblock 471 175 308 minecraft:cobbled_deepslate
fill 471 175 309 471 178 309 minecraft:deepslate_tiles
setblock 471 175 313 minecraft:cobbled_deepslate
fill 471 175 314 471 178 314 minecraft:deepslate_tiles
setblock 472 175 292 minecraft:cobbled_deepslate
fill 472 175 293 472 178 293 minecraft:deepslate_tiles
setblock 472 175 296 minecraft:deepslate_tiles
setblock 472 175 297 minecraft:cobbled_deepslate
fill 472 175 298 472 178 298 minecraft:deepslate_tiles
setblock 472 175 302 minecraft:cobbled_deepslate
fill 472 175 303 472 178 303 minecraft:deepslate_tiles
setblock 472 175 307 minecraft:cobbled_deepslate
fill 472 175 308 472 176 308 minecraft:deepslate_tiles
setblock 472 175 312 minecraft:cobbled_deepslate
fill 472 175 313 472 177 313 minecraft:deepslate_tiles
setblock 473 175 276 minecraft:cobbled_deepslate
setblock 473 175 278 minecraft:light[level=12]
setblock 473 175 285 minecraft:light[level=12]
setblock 473 175 292 minecraft:light[level=12]
setblock 473 175 296 minecraft:cobbled_deepslate
fill 473 175 297 473 178 297 minecraft:deepslate_tiles
setblock 473 175 300 minecraft:deepslate_tiles
setblock 473 175 306 minecraft:light[level=12]
setblock 473 175 313 minecraft:light[level=12]
setblock 473 175 316 minecraft:cobbled_deepslate
fill 474 175 276 475 177 276 minecraft:deepslate_tiles
setblock 474 175 315 minecraft:cobbled_deepslate
fill 474 175 316 474 178 316 minecraft:deepslate_tiles
setblock 480 175 278 minecraft:light[level=12]
setblock 480 175 285 minecraft:light[level=12]
setblock 480 175 292 minecraft:light[level=12]
setblock 480 175 299 minecraft:light[level=12]
setblock 480 175 306 minecraft:light[level=12]
setblock 480 175 313 minecraft:light[level=12]
setblock 482 175 276 minecraft:deepslate_tiles
setblock 482 175 316 minecraft:deepslate_tiles
setblock 483 175 276 minecraft:cobbled_deepslate
setblock 483 175 316 minecraft:cobbled_deepslate
fill 484 175 276 484 177 277 minecraft:deepslate_tiles
fill 484 175 316 484 178 316 minecraft:deepslate_tiles
fill 485 175 277 486 175 277 minecraft:deepslate_tiles
fill 486 175 315 486 177 315 minecraft:deepslate_tiles
setblock 487 175 277 minecraft:cobbled_deepslate
fill 487 175 278 488 177 278 minecraft:deepslate_tiles
setblock 487 175 285 minecraft:light[level=12]
setblock 487 175 292 minecraft:light[level=12]
setblock 487 175 299 minecraft:light[level=12]
setblock 487 175 306 minecraft:light[level=12]
setblock 487 175 313 minecraft:light[level=12]
setblock 488 175 276 minecraft:cobbled_deepslate
fill 488 175 277 488 178 277 minecraft:deepslate_tiles
setblock 488 175 316 minecraft:cobbled_deepslate
fill 489 175 276 489 178 276 minecraft:deepslate_tiles
setblock 489 175 315 minecraft:cobbled_deepslate
fill 489 175 316 489 178 316 minecraft:deepslate_tiles
fill 490 175 275 490 201 275 minecraft:black_concrete
setblock 490 175 278 minecraft:deepslate_tiles
fill 490 175 315 490 178 315 minecraft:deepslate_tiles
setblock 491 175 278 minecraft:cobbled_deepslate
setblock 492 175 277 minecraft:cobbled_deepslate
fill 492 175 278 494 176 278 minecraft:deepslate_tiles
setblock 493 175 276 minecraft:cobbled_deepslate
fill 493 175 277 493 178 277 minecraft:deepslate_tiles
setblock 493 175 316 minecraft:cobbled_deepslate
fill 494 175 276 494 178 276 minecraft:deepslate_tiles
setblock 494 175 285 minecraft:light[level=12]
setblock 494 175 292 minecraft:light[level=12]
setblock 494 175 299 minecraft:light[level=12]
setblock 494 175 306 minecraft:light[level=12]
setblock 494 175 313 minecraft:light[level=12]
fill 494 175 316 497 175 316 minecraft:deepslate_tiles
setblock 497 175 277 minecraft:cobbled_deepslate
setblock 498 175 276 minecraft:cobbled_deepslate
fill 498 175 277 499 177 277 minecraft:deepslate_tiles
setblock 498 175 316 minecraft:cobbled_deepslate
fill 499 175 276 499 178 276 minecraft:deepslate_tiles
fill 499 175 316 499 178 316 minecraft:deepslate_tiles
setblock 501 175 277 minecraft:deepslate_tiles
setblock 501 175 278 minecraft:light[level=12]
setblock 501 175 285 minecraft:light[level=12]
setblock 501 175 292 minecraft:light[level=12]
setblock 501 175 299 minecraft:light[level=12]
setblock 501 175 306 minecraft:light[level=12]
setblock 501 175 313 minecraft:light[level=12]
fill 501 175 315 501 177 315 minecraft:deepslate_tiles
setblock 502 175 277 minecraft:cobbled_deepslate
setblock 503 175 276 minecraft:cobbled_deepslate
fill 503 175 277 503 178 277 minecraft:deepslate_tiles
setblock 503 175 316 minecraft:cobbled_deepslate
fill 504 175 276 504 178 276 minecraft:deepslate_tiles
setblock 504 175 314 minecraft:deepslate_tiles
setblock 504 175 315 minecraft:cobbled_deepslate
fill 504 175 316 504 178 316 minecraft:deepslate_tiles
setblock 505 175 278 minecraft:deepslate_tiles
setblock 505 175 314 minecraft:cobbled_deepslate
fill 505 175 315 505 178 315 minecraft:deepslate_tiles
setblock 506 175 278 minecraft:cobbled_deepslate
fill 506 175 314 506 178 314 minecraft:deepslate_tiles
setblock 507 175 277 minecraft:cobbled_deepslate
fill 507 175 278 507 178 278 minecraft:deepslate_tiles
setblock 508 175 276 minecraft:cobbled_deepslate
fill 508 175 277 508 178 277 minecraft:deepslate_tiles
setblock 508 175 285 minecraft:light[level=12]
setblock 508 175 292 minecraft:light[level=12]
setblock 508 175 299 minecraft:light[level=12]
setblock 508 175 306 minecraft:light[level=12]
fill 508 175 313 508 177 313 minecraft:deepslate_tiles
setblock 508 175 316 minecraft:cobbled_deepslate
fill 509 175 276 509 178 276 minecraft:deepslate_tiles
fill 509 175 278 509 176 278 minecraft:deepslate_tiles
fill 509 175 297 509 177 297 minecraft:deepslate_tiles
setblock 509 175 310 minecraft:cobbled_deepslate
fill 509 175 311 509 178 311 minecraft:deepslate_tiles
setblock 509 175 315 minecraft:cobbled_deepslate
fill 509 175 316 509 178 316 minecraft:deepslate_tiles
setblock 510 175 279 minecraft:cobbled_deepslate
fill 510 175 280 510 178 280 minecraft:deepslate_tiles
setblock 510 175 294 minecraft:cobbled_deepslate
fill 510 175 295 510 178 295 minecraft:deepslate_tiles
setblock 510 175 299 minecraft:cobbled_deepslate
fill 510 175 300 510 178 300 minecraft:deepslate_tiles
fill 510 175 302 510 175 303 minecraft:deepslate_tiles
setblock 510 175 304 minecraft:cobbled_deepslate
fill 510 175 305 510 177 306 minecraft:deepslate_tiles
setblock 510 175 309 minecraft:cobbled_deepslate
fill 510 175 310 510 178 310 minecraft:deepslate_tiles
setblock 510 175 314 minecraft:cobbled_deepslate
fill 510 175 315 510 178 315 minecraft:deepslate_tiles
setblock 511 175 278 minecraft:cobbled_deepslate
fill 511 175 279 511 178 279 minecraft:deepslate_tiles
setblock 511 175 282 minecraft:deepslate_tiles
setblock 511 175 289 minecraft:deepslate_tiles
setblock 511 175 293 minecraft:cobbled_deepslate
fill 511 175 294 511 178 294 minecraft:deepslate_tiles
setblock 511 175 298 minecraft:cobbled_deepslate
fill 511 175 299 511 178 299 minecraft:deepslate_tiles
setblock 511 175 302 minecraft:deepslate_tiles
setblock 511 175 303 minecraft:cobbled_deepslate
fill 511 175 304 511 178 304 minecraft:deepslate_tiles
setblock 511 175 308 minecraft:cobbled_deepslate
fill 511 175 309 511 178 309 minecraft:deepslate_tiles
setblock 511 175 313 minecraft:cobbled_deepslate
fill 511 175 314 511 178 314 minecraft:deepslate_tiles
fill 470 176 313 470 201 313 minecraft:black_concrete
setblock 471 176 277 minecraft:cobbled_deepslate
fill 471 176 278 471 179 278 minecraft:deepslate_tiles
setblock 471 176 281 minecraft:deepslate_tiles
fill 471 176 288 471 177 288 minecraft:deepslate_tiles
setblock 471 176 292 minecraft:cobbled_deepslate
fill 471 176 293 471 179 293 minecraft:deepslate_tiles
setblock 471 176 297 minecraft:cobbled_deepslate
fill 471 176 298 471 179 298 minecraft:deepslate_tiles
setblock 471 176 302 minecraft:cobbled_deepslate
fill 471 176 303 471 179 303 minecraft:deepslate_tiles
setblock 471 176 307 minecraft:cobbled_deepslate
fill 471 176 308 471 179 308 minecraft:deepslate_tiles
setblock 471 176 312 minecraft:cobbled_deepslate
fill 471 176 313 471 179 313 minecraft:deepslate_tiles
setblock 472 176 276 minecraft:cobbled_deepslate
fill 472 176 277 472 178 277 minecraft:deepslate_tiles
setblock 472 176 291 minecraft:cobbled_deepslate
fill 472 176 292 472 178 292 minecraft:deepslate_tiles
setblock 472 176 296 minecraft:cobbled_deepslate
fill 472 176 297 472 179 297 minecraft:deepslate_tiles
setblock 472 176 301 minecraft:cobbled_deepslate
fill 472 176 302 472 179 302 minecraft:deepslate_tiles
setblock 472 176 306 minecraft:cobbled_deepslate
fill 472 176 307 472 177 307 minecraft:deepslate_tiles
setblock 472 176 311 minecraft:cobbled_deepslate
fill 472 176 312 472 177 312 minecraft:deepslate_tiles
setblock 472 176 316 minecraft:cobbled_deepslate
fill 473 176 276 473 179 276 minecraft:deepslate_tiles
setblock 473 176 295 minecraft:cobbled_deepslate
fill 473 176 296 473 179 296 minecraft:deepslate_tiles
setblock 473 176 300 minecraft:cobbled_deepslate
fill 473 176 301 473 179 301 minecraft:deepslate_tiles
setblock 473 176 315 minecraft:cobbled_deepslate
fill 473 176 316 473 179 316 minecraft:deepslate_tiles
setblock 478 176 317 minecraft:white_wool
fill 480 176 276 481 176 276 minecraft:deepslate_tiles
setblock 481 176 316 minecraft:deepslate_tiles
setblock 482 176 276 minecraft:cobbled_deepslate
setblock 482 176 316 minecraft:cobbled_deepslate
fill 483 176 276 483 178 277 minecraft:deepslate_tiles
fill 483 176 316 483 179 316 minecraft:deepslate_tiles
setblock 485 176 277 minecraft:deepslate_tiles
setblock 485 176 278 minecraft:cobbled_deepslate
fill 485 176 315 485 178 315 minecraft:deepslate_tiles
setblock 486 176 277 minecraft:cobbled_deepslate
fill 486 176 278 486 179 278 minecraft:deepslate_tiles
setblock 487 176 276 minecraft:cobbled_deepslate
fill 487 176 277 487 179 277 minecraft:deepslate_tiles
setblock 487 176 316 minecraft:cobbled_deepslate
fill 488 176 276 488 179 276 minecraft:deepslate_tiles
setblock 488 176 315 minecraft:cobbled_deepslate
fill 488 176 316 488 179 316 minecraft:deepslate_tiles
setblock 489 176 279 minecraft:cobbled_deepslate
fill 489 176 315 489 179 315 minecraft:deepslate_tiles
setblock 490 176 278 minecraft:cobbled_deepslate
fill 490 176 284 490 179 284 minecraft:white_wool
setblock 491 176 277 minecraft:cobbled_deepslate
fill 491 176 278 491 179 278 minecraft:deepslate_tiles
setblock 492 176 276 minecraft:cobbled_deepslate
fill 492 176 277 492 179 277 minecraft:deepslate_tiles
setblock 492 176 316 minecraft:cobbled_deepslate
fill 493 176 276 493 179 276 minecraft:deepslate_tiles
setblock 493 176 315 minecraft:cobbled_deepslate
fill 493 176 316 496 176 316 minecraft:deepslate_tiles
setblock 495 176 277 minecraft:deepslate_tiles
setblock 495 176 278 minecraft:cobbled_deepslate
setblock 496 176 277 minecraft:cobbled_deepslate
setblock 497 176 276 minecraft:cobbled_deepslate
fill 497 176 277 497 179 277 minecraft:deepslate_tiles
setblock 497 176 316 minecraft:cobbled_deepslate
fill 498 176 276 498 179 276 minecraft:deepslate_tiles
fill 498 176 316 498 179 316 minecraft:deepslate_tiles
fill 500 176 315 500 178 315 minecraft:deepslate_tiles
setblock 501 176 277 minecraft:cobbled_deepslate
setblock 502 176 276 minecraft:cobbled_deepslate
fill 502 176 277 502 178 278 minecraft:deepslate_tiles
setblock 502 176 316 minecraft:cobbled_deepslate
fill 503 176 276 503 179 276 minecraft:deepslate_tiles
fill 503 176 278 504 176 278 minecraft:deepslate_tiles
setblock 503 176 315 minecraft:cobbled_deepslate
fill 503 176 316 503 179 316 minecraft:deepslate_tiles
setblock 504 176 314 minecraft:cobbled_deepslate
fill 504 176 315 504 179 315 minecraft:deepslate_tiles
setblock 505 176 278 minecraft:cobbled_deepslate
fill 505 176 314 505 179 314 minecraft:deepslate_tiles
setblock 506 176 277 minecraft:cobbled_deepslate
fill 506 176 278 506 179 278 minecraft:deepslate_tiles
setblock 507 176 276 minecraft:cobbled_deepslate
fill 507 176 277 507 179 277 minecraft:deepslate_tiles
setblock 507 176 316 minecraft:cobbled_deepslate
fill 508 176 276 508 179 276 minecraft:deepslate_tiles
setblock 508 176 315 minecraft:cobbled_deepslate
fill 508 176 316 508 179 316 minecraft:deepslate_tiles
setblock 509 176 279 minecraft:cobbled_deepslate
fill 509 176 295 509 178 296 minecraft:deepslate_tiles
setblock 509 176 298 minecraft:deepslate_tiles
setblock 509 176 299 minecraft:cobbled_deepslate
fill 509 176 300 509 178 301 minecraft:deepslate_tiles
fill 509 176 310 509 178 310 minecraft:deepslate_tiles
setblock 509 176 314 minecraft:cobbled_deepslate
fill 509 176 315 509 179 315 minecraft:deepslate_tiles
setblock 510 176 278 minecraft:cobbled_deepslate
fill 510 176 279 510 179 279 minecraft:deepslate_tiles
fill 510 176 281 510 177 281 minecraft:deepslate_tiles
setblock 510 176 293 minecraft:cobbled_deepslate
fill 510 176 294 510 179 294 minecraft:deepslate_tiles
setblock 510 176 297 minecraft:deepslate_tiles
setblock 510 176 298 minecraft:cobbled_deepslate
fill 510 176 299 510 179 299 minecraft:deepslate_tiles
setblock 510 176 302 minecraft:deepslate_tiles
setblock 510 176 303 minecraft:cobbled_deepslate
fill 510 176 304 510 179 304 minecraft:deepslate_tiles
setblock 510 176 308 minecraft:cobbled_deepslate
fill 510 176 309 510 179 309 minecraft:deepslate_tiles
setblock 510 176 313 minecraft:cobbled_deepslate
fill 510 176 314 510 179 314 minecraft:deepslate_tiles
setblock 511 176 277 minecraft:cobbled_deepslate
fill 511 176 278 511 179 278 minecraft:deepslate_tiles
setblock 511 176 282 minecraft:cobbled_deepslate
fill 511 176 283 511 179 283 minecraft:deepslate_tiles
setblock 511 176 292 minecraft:cobbled_deepslate
fill 511 176 293 511 179 293 minecraft:deepslate_tiles
setblock 511 176 297 minecraft:cobbled_deepslate
fill 511 176 298 511 179 298 minecraft:deepslate_tiles
setblock 511 176 302 minecraft:cobbled_deepslate
fill 511 176 303 511 179 303 minecraft:deepslate_tiles
setblock 511 176 307 minecraft:cobbled_deepslate
fill 511 176 308 511 179 308 minecraft:deepslate_tiles
setblock 511 176 312 minecraft:cobbled_deepslate
fill 511 176 313 511 179 313 minecraft:deepslate_tiles
setblock 471 177 276 minecraft:cobbled_deepslate
fill 471 177 277 471 180 277 minecraft:deepslate_tiles
setblock 471 177 281 minecraft:cobbled_deepslate
fill 471 177 282 471 180 282 minecraft:deepslate_tiles
setblock 471 177 291 minecraft:cobbled_deepslate
fill 471 177 292 471 180 292 minecraft:deepslate_tiles
setblock 471 177 296 minecraft:cobbled_deepslate
fill 471 177 297 471 180 297 minecraft:deepslate_tiles
setblock 471 177 301 minecraft:cobbled_deepslate
fill 471 177 302 471 180 302 minecraft:deepslate_tiles
setblock 471 177 306 minecraft:cobbled_deepslate
fill 471 177 307 471 180 307 minecraft:deepslate_tiles
setblock 471 177 311 minecraft:cobbled_deepslate
fill 471 177 312 471 180 312 minecraft:deepslate_tiles
setblock 471 177 316 minecraft:cobbled_deepslate
fill 472 177 276 472 180 276 minecraft:deepslate_tiles
setblock 472 177 291 minecraft:deepslate_tiles
setblock 472 177 295 minecraft:cobbled_deepslate
fill 472 177 296 472 180 296 minecraft:deepslate_tiles
setblock 472 177 299 minecraft:deepslate_tiles
setblock 472 177 300 minecraft:cobbled_deepslate
fill 472 177 301 472 180 301 minecraft:deepslate_tiles
setblock 472 177 305 minecraft:cobbled_deepslate
fill 472 177 306 472 180 306 minecraft:deepslate_tiles
setblock 472 177 315 minecraft:cobbled_deepslate
fill 472 177 316 472 180 316 minecraft:deepslate_tiles
setblock 473 177 294 minecraft:cobbled_deepslate
fill 473 177 295 473 178 295 minecraft:deepslate_tiles
setblock 473 177 299 minecraft:cobbled_deepslate
fill 473 177 300 473 180 300 minecraft:deepslate_tiles
fill 473 177 302 473 178 302 minecraft:deepslate_tiles
setblock 473 177 315 minecraft:deepslate_tiles
setblock 476 177 276 minecraft:cobbled_deepslate
setblock 476 177 316 minecraft:cobbled_deepslate
fill 477 177 276 480 177 276 minecraft:deepslate_tiles
fill 478 177 317 478 191 317 minecraft:black_concrete
setblock 481 177 276 minecraft:cobbled_deepslate
setblock 481 177 316 minecraft:cobbled_deepslate
fill 482 177 276 482 179 277 minecraft:deepslate_tiles
fill 482 177 316 482 180 316 minecraft:deepslate_tiles
setblock 484 177 278 minecraft:cobbled_deepslate
setblock 485 177 277 minecraft:cobbled_deepslate
fill 485 177 278 485 180 278 minecraft:deepslate_tiles
setblock 486 177 276 minecraft:cobbled_deepslate
fill 486 177 277 486 180 277 minecraft:deepslate_tiles
fill 486 177 279 487 177 279 minecraft:deepslate_tiles
setblock 486 177 316 minecraft:cobbled_deepslate
fill 487 177 276 487 180 276 minecraft:deepslate_tiles
setblock 487 177 315 minecraft:cobbled_deepslate
fill 487 177 316 487 180 316 minecraft:deepslate_tiles
setblock 488 177 279 minecraft:cobbled_deepslate
fill 488 177 315 488 179 315 minecraft:deepslate_tiles
setblock 489 177 277 minecraft:deepslate_tiles
setblock 489 177 278 minecraft:cobbled_deepslate
fill 489 177 279 491 178 279 minecraft:deepslate_tiles
setblock 490 177 277 minecraft:cobbled_deepslate
fill 490 177 278 490 180 278 minecraft:deepslate_tiles
setblock 491 177 276 minecraft:cobbled_deepslate
fill 491 177 277 491 180 277 minecraft:deepslate_tiles
setblock 491 177 316 minecraft:cobbled_deepslate
fill 492 177 276 492 180 276 minecraft:deepslate_tiles
fill 492 177 278 493 177 278 minecraft:deepslate_tiles
fill 492 177 313 492 187 313 minecraft:cobbled_deepslate
setblock 492 177 315 minecraft:cobbled_deepslate
fill 492 177 316 495 177 316 minecraft:deepslate_tiles
setblock 493 177 315 minecraft:deepslate_tiles
setblock 494 177 278 minecraft:cobbled_deepslate
setblock 495 177 277 minecraft:cobbled_deepslate
fill 495 177 278 496 179 278 minecraft:deepslate_tiles
setblock 496 177 276 minecraft:cobbled_deepslate
fill 496 177 277 496 180 277 minecraft:deepslate_tiles
setblock 496 177 316 minecraft:cobbled_deepslate
fill 497 177 276 497 180 276 minecraft:deepslate_tiles
fill 497 177 316 497 180 316 minecraft:deepslate_tiles
setblock 500 177 276 minecraft:deepslate_tiles
setblock 500 177 277 minecraft:cobbled_deepslate
fill 500 177 278 501 179 278 minecraft:deepslate_tiles
setblock 501 177 276 minecraft:cobbled_deepslate
fill 501 177 277 501 180 277 minecraft:deepslate_tiles
setblock 501 177 316 minecraft:cobbled_deepslate
fill 502 177 276 502 180 276 minecraft:deepslate_tiles
setblock 502 177 315 minecraft:cobbled_deepslate
fill 502 177 316 502 180 316 minecraft:deepslate_tiles
setblock 503 177 278 minecraft:deepslate_tiles
setblock 503 177 314 minecraft:cobbled_deepslate
fill 503 177 315 503 180 315 minecraft:deepslate_tiles
setblock 504 177 278 minecraft:cobbled_deepslate
fill 504 177 314 504 180 314 minecraft:deepslate_tiles
setblock 505 177 277 minecraft:cobbled_deepslate
fill 505 177 278 505 180 278 minecraft:deepslate_tiles
setblock 506 177 276 minecraft:cobbled_deepslate
fill 506 177 277 506 180 277 minecraft:deepslate_tiles
setblock 506 177 316 minecraft:cobbled_deepslate
fill 507 177 276 507 180 276 minecraft:deepslate_tiles
setblock 507 177 313 minecraft:deepslate_tiles
setblock 507 177 315 minecraft:cobbled_deepslate
fill 507 177 316 507 180 316 minecraft:deepslate_tiles
setblock 508 177 314 minecraft:cobbled_deepslate
fill 508 177 315 508 180 315 minecraft:deepslate_tiles
setblock 509 177 278 minecraft:cobbled_deepslate
fill 509 177 279 509 179 280 minecraft:deepslate_tiles
setblock 509 177 298 minecraft:cobbled_deepslate
fill 509 177 299 509 180 299 minecraft:deepslate_tiles
setblock 509 177 302 minecraft:deepslate_tiles
setblock 509 177 303 minecraft:cobbled_deepslate
setblock 509 177 313 minecraft:cobbled_deepslate
fill 509 177 314 509 180 314 minecraft:deepslate_tiles
setblock 510 177 277 minecraft:cobbled_deepslate
fill 510 177 278 510 180 278 minecraft:deepslate_tiles
fill 510 177 293 510 178 293 minecraft:deepslate_tiles
setblock 510 177 297 minecraft:cobbled_deepslate
fill 510 177 298 510 180 298 minecraft:deepslate_tiles
setblock 510 177 302 minecraft:cobbled_deepslate
fill 510 177 303 510 180 303 minecraft:deepslate_tiles
setblock 510 177 307 minecraft:cobbled_deepslate
fill 510 177 308 510 180 308 minecraft:deepslate_tiles
setblock 510 177 312 minecraft:cobbled_deepslate
fill 510 177 313 510 180 313 minecraft:deepslate_tiles
setblock 511 177 276 minecraft:cobbled_deepslate
fill 511 177 277 511 180 277 minecraft:deepslate_tiles
setblock 511 177 281 minecraft:cobbled_deepslate
fill 511 177 282 511 180 282 minecraft:deepslate_tiles
setblock 511 177 291 minecraft:cobbled_deepslate
fill 511 177 292 511 179 292 minecraft:deepslate_tiles
setblock 511 177 296 minecraft:cobbled_deepslate
fill 511 177 297 511 180 297 minecraft:deepslate_tiles
setblock 511 177 301 minecraft:cobbled_deepslate
fill 511 177 302 511 180 302 minecraft:deepslate_tiles
setblock 511 177 306 minecraft:cobbled_deepslate
fill 511 177 307 511 180 307 minecraft:deepslate_tiles
setblock 511 177 311 minecraft:cobbled_deepslate
fill 511 177 312 511 180 312 minecraft:deepslate_tiles
setblock 511 177 316 minecraft:cobbled_deepslate
fill 512 177 312 512 198 312 minecraft:black_concrete
setblock 512 177 313 minecraft:white_wool
fill 471 178 276 471 181 276 minecraft:deepslate_tiles
setblock 471 178 279 minecraft:deepslate_tiles
setblock 471 178 280 minecraft:cobbled_deepslate
fill 471 178 281 471 181 281 minecraft:deepslate_tiles
fill 471 178 283 471 179 283 minecraft:deepslate_tiles
setblock 471 178 290 minecraft:cobbled_deepslate
fill 471 178 291 471 180 291 minecraft:deepslate_tiles
setblock 471 178 295 minecraft:cobbled_deepslate
fill 471 178 296 471 181 296 minecraft:deepslate_tiles
setblock 471 178 300 minecraft:cobbled_deepslate
fill 471 178 301 471 181 301 minecraft:deepslate_tiles
setblock 471 178 305 minecraft:cobbled_deepslate
fill 471 178 306 471 181 306 minecraft:deepslate_tiles
setblock 471 178 310 minecraft:cobbled_deepslate
fill 471 178 311 471 180 311 minecraft:deepslate_tiles
setblock 471 178 315 minecraft:cobbled_deepslate
fill 471 178 316 471 180 316 minecraft:deepslate_tiles
fill 472 178 282 472 181 282 minecraft:black_concrete
setblock 472 178 294 minecraft:cobbled_deepslate
fill 472 178 295 472 181 295 minecraft:deepslate_tiles
setblock 472 178 299 minecraft:cobbled_deepslate
fill 472 178 300 472 181 300 minecraft:deepslate_tiles
setblock 472 178 304 minecraft:cobbled_deepslate
fill 472 178 305 472 181 305 minecraft:deepslate_tiles
setblock 472 178 315 minecraft:deepslate_tiles
fill 473 178 281 473 181 281 minecraft:black_concrete
fill 473 178 283 473 181 283 minecraft:black_concrete
setblock 473 178 298 minecraft:cobbled_deepslate
fill 473 178 299 473 181 299 minecraft:deepslate_tiles
setblock 474 178 276 minecraft:deepslate_tiles
fill 474 178 282 474 181 282 minecraft:black_concrete
setblock 475 178 276 minecraft:cobbled_deepslate
setblock 475 178 316 minecraft:cobbled_deepslate
fill 476 178 276 479 178 276 minecraft:deepslate_tiles
setblock 480 178 276 minecraft:cobbled_deepslate
fill 481 178 276 481 180 277 minecraft:deepslate_tiles
fill 481 178 316 481 180 316 minecraft:deepslate_tiles
setblock 483 178 278 minecraft:cobbled_deepslate
setblock 484 178 276 minecraft:deepslate_tiles
setblock 484 178 277 minecraft:cobbled_deepslate
fill 484 178 278 484 181 278 minecraft:deepslate_tiles
setblock 485 178 276 minecraft:cobbled_deepslate
fill 485 178 277 485 181 277 minecraft:deepslate_tiles
fill 485 178 279 486 178 279 minecraft:deepslate_tiles
setblock 485 178 316 minecraft:cobbled_deepslate
fill 486 178 276 486 181 276 minecraft:deepslate_tiles
setblock 486 178 315 minecraft:cobbled_deepslate
fill 486 178 316 486 181 316 minecraft:deepslate_tiles
setblock 487 178 278 minecraft:deepslate_tiles
setblock 487 178 279 minecraft:cobbled_deepslate
fill 487 178 315 487 180 315 minecraft:deepslate_tiles
setblock 488 178 278 minecraft:cobbled_deepslate
fill 488 178 279 488 181 279 minecraft:deepslate_tiles
setblock 489 178 277 minecraft:cobbled_deepslate
fill 489 178 278 489 181 278 minecraft:deepslate_tiles
setblock 490 178 276 minecraft:cobbled_deepslate
fill 490 178 277 490 181 277 minecraft:deepslate_tiles
setblock 490 178 316 minecraft:cobbled_deepslate
fill 491 178 276 491 181 276 minecraft:deepslate_tiles
setblock 491 178 315 minecraft:cobbled_deepslate
fill 491 178 316 494 178 316 minecraft:deepslate_tiles
setblock 492 178 278 minecraft:deepslate_tiles
setblock 492 178 315 minecraft:deepslate_tiles
setblock 493 178 278 minecraft:cobbled_deepslate
setblock 494 178 277 minecraft:cobbled_deepslate
fill 494 178 278 494 181 278 minecraft:deepslate_tiles
setblock 495 178 276 minecraft:cobbled_deepslate
fill 495 178 277 495 181 277 minecraft:deepslate_tiles
setblock 495 178 316 minecraft:cobbled_deepslate
fill 496 178 276 496 181 276 minecraft:deepslate_tiles
fill 496 178 316 496 181 316 minecraft:deepslate_tiles
setblock 497 178 278 minecraft:deepslate_tiles
setblock 498 178 277 minecraft:deepslate_tiles
setblock 498 178 278 minecraft:cobbled_deepslate
setblock 499 178 277 minecraft:cobbled_deepslate
fill 499 178 278 499 181 278 minecraft:deepslate_tiles
setblock 499 178 315 minecraft:deepslate_tiles
setblock 500 178 276 minecraft:cobbled_deepslate
fill 500 178 277 500 181 277 minecraft:deepslate_tiles
setblock 500 178 316 minecraft:cobbled_deepslate
fill 501 178 276 501 181 276 minecraft:deepslate_tiles
setblock 501 178 315 minecraft:cobbled_deepslate
fill 501 178 316 501 181 316 minecraft:deepslate_tiles
fill 502 178 315 502 181 315 minecraft:deepslate_tiles
setblock 503 178 278 minecraft:cobbled_deepslate
fill 503 178 314 503 180 314 minecraft:deepslate_tiles
setblock 504 178 277 minecraft:cobbled_deepslate
fill 504 178 278 504 181 278 minecraft:deepslate_tiles
setblock 505 178 276 minecraft:cobbled_deepslate
fill 505 178 277 505 181 277 minecraft:deepslate_tiles
fill 505 178 279 506 178 279 minecraft:deepslate_tiles
setblock 505 178 316 minecraft:cobbled_deepslate
fill 506 178 276 506 181 276 minecraft:deepslate_tiles
setblock 506 178 315 minecraft:cobbled_deepslate
fill 506 178 316 506 181 316 minecraft:deepslate_tiles
setblock 507 178 314 minecraft:cobbled_deepslate
fill 507 178 315 507 181 315 minecraft:deepslate_tiles
setblock 508 178 278 minecraft:cobbled_deepslate
fill 508 178 314 508 181 314 minecraft:deepslate_tiles
setblock 509 178 277 minecraft:cobbled_deepslate
fill 509 178 278 509 181 278 minecraft:deepslate_tiles
setblock 509 178 297 minecraft:cobbled_deepslate
fill 509 178 298 509 181 298 minecraft:deepslate_tiles
setblock 509 178 302 minecraft:cobbled_deepslate
fill 509 178 303 509 178 306 minecraft:deepslate_tiles
setblock 509 178 312 minecraft:cobbled_deepslate
fill 509 178 313 509 180 313 minecraft:deepslate_tiles
setblock 510 178 276 minecraft:cobbled_deepslate
fill 510 178 277 510 181 277 minecraft:deepslate_tiles
setblock 510 178 281 minecraft:cobbled_deepslate
setblock 510 178 296 minecraft:cobbled_deepslate
fill 510 178 297 510 181 297 minecraft:deepslate_tiles
setblock 510 178 301 minecraft:cobbled_deepslate
fill 510 178 302 510 181 302 minecraft:deepslate_tiles
setblock 510 178 305 minecraft:deepslate_tiles
setblock 510 178 306 minecraft:cobbled_deepslate
fill 510 178 307 510 181 307 minecraft:deepslate_tiles
setblock 510 178 311 minecraft:cobbled_deepslate
fill 510 178 312 510 181 312 minecraft:deepslate_tiles
setblock 510 178 316 minecraft:cobbled_deepslate
fill 511 178 276 511 181 276 minecraft:deepslate_tiles
setblock 511 178 280 minecraft:cobbled_deepslate
fill 511 178 281 511 181 281 minecraft:deepslate_tiles
setblock 511 178 291 minecraft:deepslate_tiles
setblock 511 178 295 minecraft:cobbled_deepslate
fill 511 178 296 511 181 296 minecraft:deepslate_tiles
setblock 511 178 300 minecraft:cobbled_deepslate
fill 511 178 301 511 181 301 minecraft:deepslate_tiles
setblock 511 178 305 minecraft:cobbled_deepslate
fill 511 178 306 511 181 306 minecraft:deepslate_tiles
setblock 511 178 310 minecraft:cobbled_deepslate
fill 511 178 311 511 181 311 minecraft:deepslate_tiles
setblock 511 178 315 minecraft:cobbled_deepslate
fill 511 178 316 511 181 316 minecraft:deepslate_tiles
fill 512 178 313 512 201 313 minecraft:black_concrete
setblock 470 179 311 minecraft:white_wool
setblock 471 179 279 minecraft:cobbled_deepslate
fill 471 179 280 471 182 280 minecraft:deepslate_tiles
setblock 471 179 289 minecraft:cobbled_deepslate
fill 471 179 290 471 180 290 minecraft:deepslate_tiles
setblock 471 179 294 minecraft:cobbled_deepslate
fill 471 179 295 471 182 295 minecraft:deepslate_tiles
setblock 471 179 299 minecraft:cobbled_deepslate
fill 471 179 300 471 182 300 minecraft:deepslate_tiles
setblock 471 179 304 minecraft:cobbled_deepslate
fill 471 179 305 471 182 305 minecraft:deepslate_tiles
setblock 471 179 309 minecraft:cobbled_deepslate
fill 471 179 310 471 180 310 minecraft:deepslate_tiles
setblock 471 179 314 minecraft:cobbled_deepslate
fill 471 179 315 471 180 315 minecraft:deepslate_tiles
setblock 472 179 293 minecraft:cobbled_deepslate
fill 472 179 294 472 180 294 minecraft:deepslate_tiles
setblock 472 179 298 minecraft:cobbled_deepslate
fill 472 179 299 472 182 299 minecraft:deepslate_tiles
setblock 472 179 303 minecraft:cobbled_deepslate
fill 472 179 304 472 182 304 minecraft:deepslate_tiles
setblock 473 179 297 minecraft:cobbled_deepslate
fill 473 179 298 473 180 298 minecraft:deepslate_tiles
setblock 473 179 302 minecraft:cobbled_deepslate
setblock 474 179 276 minecraft:cobbled_deepslate
fill 475 179 276 478 179 276 minecraft:deepslate_tiles
setblock 479 179 276 minecraft:cobbled_deepslate
fill 480 179 276 480 181 277 minecraft:deepslate_tiles
setblock 482 179 278 minecraft:cobbled_deepslate
setblock 483 179 276 minecraft:deepslate_tiles
setblock 483 179 277 minecraft:cobbled_deepslate
fill 483 179 278 483 182 278 minecraft:deepslate_tiles
setblock 484 179 276 minecraft:cobbled_deepslate
fill 484 179 277 484 182 277 minecraft:deepslate_tiles
fill 484 179 279 485 179 279 minecraft:deepslate_tiles
setblock 484 179 316 minecraft:cobbled_deepslate
fill 485 179 276 485 182 276 minecraft:deepslate_tiles
setblock 485 179 315 minecraft:cobbled_deepslate
fill 485 179 316 485 182 316 minecraft:deepslate_tiles
setblock 486 179 279 minecraft:cobbled_deepslate
setblock 486 179 315 minecraft:deepslate_tiles
setblock 487 179 278 minecraft:cobbled_deepslate
fill 487 179 279 487 182 279 minecraft:deepslate_tiles
setblock 488 179 277 minecraft:cobbled_deepslate
fill 488 179 278 488 182 278 minecraft:deepslate_tiles
setblock 489 179 276 minecraft:cobbled_deepslate
fill 489 179 277 489 182 277 minecraft:deepslate_tiles
fill 489 179 279 490 179 279 minecraft:deepslate_tiles
setblock 489 179 316 minecraft:cobbled_deepslate
fill 490 179 276 490 182 276 minecraft:deepslate_tiles
setblock 490 179 315 minecraft:cobbled_deepslate
fill 490 179 316 493 179 316 minecraft:deepslate_tiles
setblock 491 179 279 minecraft:cobbled_deepslate
setblock 492 179 278 minecraft:cobbled_deepslate
setblock 493 179 277 minecraft:cobbled_deepslate
fill 493 179 278 493 181 278 minecraft:deepslate_tiles
setblock 494 179 276 minecraft:cobbled_deepslate
fill 494 179 277 494 182 277 minecraft:deepslate_tiles
setblock 494 179 316 minecraft:cobbled_deepslate
fill 495 179 276 495 182 276 minecraft:deepslate_tiles
fill 495 179 316 495 181 316 minecraft:deepslate_tiles
setblock 497 179 278 minecraft:cobbled_deepslate
setblock 498 179 277 minecraft:cobbled_deepslate
fill 498 179 278 498 181 278 minecraft:deepslate_tiles
setblock 499 179 276 minecraft:cobbled_deepslate
fill 499 179 277 499 182 277 minecraft:deepslate_tiles
setblock 499 179 316 minecraft:cobbled_deepslate
fill 500 179 276 500 182 276 minecraft:deepslate_tiles
setblock 500 179 315 minecraft:cobbled_deepslate
fill 500 179 316 500 182 316 minecraft:deepslate_tiles
fill 501 179 315 501 182 315 minecraft:deepslate_tiles
setblock 502 179 277 minecraft:deepslate_tiles
setblock 502 179 278 minecraft:cobbled_deepslate
setblock 503 179 277 minecraft:cobbled_deepslate
fill 503 179 278 503 182 278 minecraft:deepslate_tiles
setblock 504 179 276 minecraft:cobbled_deepslate
fill 504 179 277 504 182 277 minecraft:deepslate_tiles
fill 504 179 279 505 179 279 minecraft:deepslate_tiles
setblock 504 179 316 minecraft:cobbled_deepslate
fill 505 179 276 505 182 276 minecraft:deepslate_tiles
setblock 505 179 315 minecraft:cobbled_deepslate
fill 505 179 316 505 182 316 minecraft:deepslate_tiles
setblock 506 179 279 minecraft:cobbled_deepslate
setblock 506 179 314 minecraft:cobbled_deepslate
fill 506 179 315 506 182 315 minecraft:deepslate_tiles
setblock 507 179 278 minecraft:cobbled_deepslate
setblock 507 179 279 minecraft:deepslate_tiles
fill 507 179 314 507 181 314 minecraft:deepslate_tiles
setblock 508 179 277 minecraft:cobbled_deepslate
fill 508 179 278 508 181 278 minecraft:deepslate_tiles
setblock 509 179 276 minecraft:cobbled_deepslate
fill 509 179 277 509 182 277 minecraft:deepslate_tiles
setblock 509 179 296 minecraft:cobbled_deepslate
fill 509 179 297 509 180 297 minecraft:deepslate_tiles
setblock 509 179 300 minecraft:deepslate_tiles
setblock 509 179 301 minecraft:cobbled_deepslate
fill 509 179 302 509 179 305 minecraft:deepslate_tiles
setblock 509 179 306 minecraft:cobbled_deepslate
setblock 509 179 311 minecraft:cobbled_deepslate
setblock 509 179 312 minecraft:deepslate_tiles
setblock 509 179 316 minecraft:cobbled_deepslate
fill 510 179 276 510 182 276 minecraft:deepslate_tiles
setblock 510 179 280 minecraft:cobbled_deepslate
fill 510 179 281 510 180 281 minecraft:deepslate_tiles
setblock 510 179 295 minecraft:cobbled_deepslate
fill 510 179 296 510 181 296 minecraft:deepslate_tiles
setblock 510 179 300 minecraft:cobbled_deepslate
fill 510 179 301 510 182 301 minecraft:deepslate_tiles
setblock 510 179 305 minecraft:cobbled_deepslate
fill 510 179 306 510 182 306 minecraft:deepslate_tiles
setblock 510 179 310 minecraft:cobbled_deepslate
fill 510 179 311 510 181 311 minecraft:deepslate_tiles
setblock 510 179 315 minecraft:cobbled_deepslate
fill 510 179 316 510 182 316 minecraft:deepslate_tiles
setblock 511 179 279 minecraft:cobbled_deepslate
fill 511 179 280 511 182 280 minecraft:deepslate_tiles
setblock 511 179 294 minecraft:cobbled_deepslate
fill 511 179 295 511 182 295 minecraft:deepslate_tiles
setblock 511 179 299 minecraft:cobbled_deepslate
fill 511 179 300 511 182 300 minecraft:deepslate_tiles
setblock 511 179 304 minecraft:cobbled_deepslate
fill 511 179 305 511 182 305 minecraft:deepslate_tiles
setblock 511 179 309 minecraft:cobbled_deepslate
fill 511 179 310 511 182 310 minecraft:deepslate_tiles
setblock 511 179 314 minecraft:cobbled_deepslate
fill 511 179 315 511 182 315 minecraft:deepslate_tiles
fill 470 180 285 470 197 285 minecraft:black_concrete
setblock 470 180 286 minecraft:white_wool
fill 470 180 287 470 199 289 minecraft:black_concrete
setblock 470 180 311 minecraft:redstone_block
setblock 471 180 278 minecraft:cobbled_deepslate
fill 471 180 279 471 182 279 minecraft:deepslate_tiles
setblock 471 180 283 minecraft:cobbled_deepslate
setblock 471 180 293 minecraft:cobbled_deepslate
fill 471 180 294 471 182 294 minecraft:deepslate_tiles
setblock 471 180 298 minecraft:cobbled_deepslate
fill 471 180 299 471 183 299 minecraft:deepslate_tiles
setblock 471 180 303 minecraft:cobbled_deepslate
fill 471 180 304 471 183 304 minecraft:deepslate_tiles
setblock 471 180 308 minecraft:cobbled_deepslate
fill 471 180 309 471 181 309 minecraft:deepslate_tiles
setblock 471 180 313 minecraft:cobbled_deepslate
setblock 471 180 314 minecraft:deepslate_tiles
fill 472 180 281 472 181 281 minecraft:black_concrete
fill 472 180 283 472 181 283 minecraft:black_concrete
setblock 472 180 297 minecraft:cobbled_deepslate
fill 472 180 298 472 183 298 minecraft:deepslate_tiles
setblock 472 180 302 minecraft:cobbled_deepslate
fill 472 180 303 472 183 303 minecraft:deepslate_tiles
setblock 473 180 276 minecraft:cobbled_deepslate
setblock 473 180 297 minecraft:deepslate_tiles
setblock 473 180 301 minecraft:cobbled_deepslate
setblock 473 180 302 minecraft:deepslate_tiles
fill 474 180 281 474 181 281 minecraft:black_concrete
fill 474 180 283 474 181 283 minecraft:black_concrete
setblock 477 180 276 minecraft:deepslate_tiles
setblock 478 180 276 minecraft:cobbled_deepslate
fill 479 180 276 479 183 276 minecraft:deepslate_tiles
setblock 482 180 276 minecraft:deepslate_tiles
setblock 482 180 277 minecraft:cobbled_deepslate
fill 482 180 278 482 183 278 minecraft:deepslate_tiles
setblock 483 180 276 minecraft:cobbled_deepslate
fill 483 180 277 483 183 277 minecraft:deepslate_tiles
setblock 483 180 316 minecraft:cobbled_deepslate
fill 484 180 276 484 183 276 minecraft:deepslate_tiles
setblock 484 180 279 minecraft:deepslate_tiles
fill 484 180 316 484 183 316 minecraft:deepslate_tiles
setblock 485 180 279 minecraft:cobbled_deepslate
fill 486 180 275 488 198 275 minecraft:black_concrete
setblock 486 180 278 minecraft:cobbled_deepslate
fill 486 180 279 486 183 279 minecraft:deepslate_tiles
setblock 487 180 277 minecraft:cobbled_deepslate
fill 487 180 278 487 183 278 minecraft:deepslate_tiles
setblock 488 180 276 minecraft:cobbled_deepslate
fill 488 180 277 488 183 277 minecraft:deepslate_tiles
setblock 488 180 316 minecraft:cobbled_deepslate
setblock 489 180 275 minecraft:white_wool
fill 489 180 276 489 183 276 minecraft:deepslate_tiles
setblock 489 180 279 minecraft:deepslate_tiles
fill 489 180 316 492 180 316 minecraft:deepslate_tiles
setblock 490 180 279 minecraft:cobbled_deepslate
setblock 491 180 278 minecraft:cobbled_deepslate
setblock 491 180 279 minecraft:deepslate_tiles
setblock 492 180 277 minecraft:cobbled_deepslate
fill 492 180 278 492 182 278 minecraft:deepslate_tiles
setblock 493 180 276 minecraft:cobbled_deepslate
fill 493 180 277 493 183 277 minecraft:deepslate_tiles
setblock 493 180 316 minecraft:cobbled_deepslate
fill 494 180 276 494 183 276 minecraft:deepslate_tiles
fill 494 180 316 494 181 316 minecraft:deepslate_tiles
setblock 495 180 278 minecraft:deepslate_tiles
setblock 496 180 278 minecraft:cobbled_deepslate
setblock 497 180 277 minecraft:cobbled_deepslate
setblock 497 180 278 minecraft:deepslate_tiles
setblock 498 180 276 minecraft:cobbled_deepslate
fill 498 180 277 498 183 277 minecraft:deepslate_tiles
setblock 498 180 316 minecraft:cobbled_deepslate
fill 499 180 276 499 183 276 minecraft:deepslate_tiles
fill 499 180 316 499 183 316 minecraft:deepslate_tiles
setblock 500 180 278 minecraft:deepslate_tiles
fill 500 180 315 500 181 315 minecraft:deepslate_tiles
setblock 501 180 278 minecraft:cobbled_deepslate
setblock 502 180 277 minecraft:cobbled_deepslate
fill 502 180 278 502 183 278 minecraft:deepslate_tiles
setblock 503 180 276 minecraft:cobbled_deepslate
fill 503 180 277 503 183 277 minecraft:deepslate_tiles
setblock 503 180 316 minecraft:cobbled_deepslate
fill 504 180 276 504 183 276 minecraft:deepslate_tiles
setblock 504 180 279 minecraft:deepslate_tiles
setblock 504 180 315 minecraft:cobbled_deepslate
fill 504 180 316 504 183 316 minecraft:deepslate_tiles
setblock 505 180 275 minecraft:white_wool
setblock 505 180 279 minecraft:cobbled_deepslate
setblock 505 180 314 minecraft:cobbled_deepslate
fill 505 180 315 505 183 315 minecraft:deepslate_tiles
setblock 506 180 278 minecraft:cobbled_deepslate
setblock 506 180 279 minecraft:deepslate_tiles
fill 506 180 293 506 189 293 minecraft:cobbled_deepslate
fill 506 180 314 506 181 314 minecraft:deepslate_tiles
setblock 507 180 277 minecraft:cobbled_deepslate
fill 507 180 278 507 182 278 minecraft:deepslate_tiles
setblock 508 180 276 minecraft:cobbled_deepslate
fill 508 180 277 508 183 277 minecraft:deepslate_tiles
setblock 508 180 316 minecraft:cobbled_deepslate
fill 509 180 276 509 183 276 minecraft:deepslate_tiles
setblock 509 180 279 minecraft:deepslate_tiles
setblock 509 180 300 minecraft:cobbled_deepslate
fill 509 180 301 509 180 304 minecraft:deepslate_tiles
setblock 509 180 305 minecraft:cobbled_deepslate
fill 509 180 306 509 182 306 minecraft:deepslate_tiles
setblock 509 180 315 minecraft:cobbled_deepslate
fill 509 180 316 509 183 316 minecraft:deepslate_tiles
setblock 510 180 279 minecraft:cobbled_deepslate
fill 510 180 280 510 181 280 minecraft:deepslate_tiles
setblock 510 180 295 minecraft:deepslate_tiles
setblock 510 180 299 minecraft:cobbled_deepslate
fill 510 180 300 510 183 300 minecraft:deepslate_tiles
setblock 510 180 304 minecraft:cobbled_deepslate
fill 510 180 305 510 183 305 minecraft:deepslate_tiles
setblock 510 180 309 minecraft:cobbled_deepslate
fill 510 180 310 510 181 310 minecraft:deepslate_tiles
setblock 510 180 314 minecraft:cobbled_deepslate
fill 510 180 315 510 181 315 minecraft:deepslate_tiles
setblock 511 180 278 minecraft:cobbled_deepslate
fill 511 180 279 511 183 279 minecraft:deepslate_tiles
setblock 511 180 283 minecraft:cobbled_deepslate
setblock 511 180 293 minecraft:cobbled_deepslate
fill 511 180 294 511 181 294 minecraft:deepslate_tiles
setblock 511 180 298 minecraft:cobbled_deepslate
fill 511 180 299 511 183 299 minecraft:deepslate_tiles
setblock 511 180 303 minecraft:cobbled_deepslate
fill 511 180 304 511 183 304 minecraft:deepslate_tiles
setblock 511 180 308 minecraft:cobbled_deepslate
fill 511 180 309 511 183 309 minecraft:deepslate_tiles
setblock 511 180 313 minecraft:cobbled_deepslate
fill 511 180 314 511 182 314 minecraft:deepslate_tiles
fill 470 181 286 470 199 286 minecraft:black_concrete
fill 470 181 311 470 201 311 minecraft:black_concrete
setblock 471 181 277 minecraft:cobbled_deepslate
fill 471 181 278 471 182 278 minecraft:deepslate_tiles
setblock 471 181 282 minecraft:cobbled_deepslate
setblock 471 181 283 minecraft:deepslate_tiles
setblock 471 181 292 minecraft:cobbled_deepslate
fill 471 181 293 471 182 293 minecraft:deepslate_tiles
setblock 471 181 297 minecraft:cobbled_deepslate
fill 471 181 298 471 184 298 minecraft:deepslate_tiles
setblock 471 181 302 minecraft:cobbled_deepslate
fill 471 181 303 471 184 303 minecraft:deepslate_tiles
setblock 471 181 307 minecraft:cobbled_deepslate
fill 471 181 308 471 182 308 minecraft:deepslate_tiles
setblock 472 181 296 minecraft:cobbled_deepslate
fill 472 181 297 472 182 297 minecraft:deepslate_tiles
setblock 472 181 301 minecraft:cobbled_deepslate
fill 472 181 302 472 184 302 minecraft:deepslate_tiles
setblock 473 181 278 minecraft:light[level=13]
setblock 473 181 285 minecraft:light[level=12]
setblock 473 181 286 minecraft:light[level=13]
setblock 473 181 292 minecraft:light[level=12]
setblock 473 181 294 minecraft:light[level=13]
setblock 473 181 300 minecraft:cobbled_deepslate
setblock 473 181 301 minecraft:deepslate_tiles
setblock 473 181 302 minecraft:light[level=13]
setblock 473 181 306 minecraft:light[level=12]
setblock 473 181 310 minecraft:light[level=13]
setblock 473 181 313 minecraft:light[level=12]
fill 475 181 298 475 187 298 minecraft:black_concrete
fill 478 181 276 478 182 276 minecraft:deepslate_tiles
setblock 480 181 278 minecraft:light[level=12]
setblock 480 181 285 minecraft:light[level=12]
setblock 480 181 292 minecraft:light[level=12]
setblock 480 181 299 minecraft:light[level=12]
setblock 480 181 306 minecraft:light[level=12]
setblock 480 181 313 minecraft:light[level=12]
setblock 481 181 276 minecraft:deepslate_tiles
setblock 481 181 277 minecraft:cobbled_deepslate
fill 481 181 278 481 183 278 minecraft:deepslate_tiles
setblock 481 181 286 minecraft:light[level=13]
setblock 481 181 294 minecraft:light[level=13]
setblock 481 181 302 minecraft:light[level=13]
setblock 481 181 310 minecraft:light[level=13]
setblock 482 181 276 minecraft:cobbled_deepslate
fill 482 181 277 482 184 277 minecraft:deepslate_tiles
setblock 482 181 316 minecraft:cobbled_deepslate
fill 483 181 276 483 184 276 minecraft:deepslate_tiles
setblock 483 181 279 minecraft:deepslate_tiles
fill 483 181 316 483 182 316 minecraft:deepslate_tiles
setblock 484 181 279 minecraft:cobbled_deepslate
setblock 485 181 278 minecraft:cobbled_deepslate
fill 485 181 279 485 184 279 minecraft:deepslate_tiles
setblock 486 181 277 minecraft:cobbled_deepslate
fill 486 181 278 486 184 278 minecraft:deepslate_tiles
setblock 487 181 276 minecraft:cobbled_deepslate
fill 487 181 277 487 184 277 minecraft:deepslate_tiles
setblock 487 181 285 minecraft:light[level=12]
setblock 487 181 292 minecraft:light[level=12]
setblock 487 181 299 minecraft:light[level=12]
setblock 487 181 306 minecraft:light[level=12]
setblock 487 181 313 minecraft:light[level=12]
setblock 487 181 316 minecraft:cobbled_deepslate
fill 488 181 276 488 184 276 minecraft:deepslate_tiles
fill 488 181 316 491 181 316 minecraft:deepslate_tiles
fill 489 181 275 489 198 275 minecraft:black_concrete
setblock 489 181 279 minecraft:cobbled_deepslate
setblock 489 181 286 minecraft:light[level=13]
setblock 489 181 294 minecraft:light[level=13]
setblock 489 181 302 minecraft:light[level=13]
setblock 489 181 310 minecraft:light[level=13]
setblock 490 181 278 minecraft:cobbled_deepslate
setblock 490 181 279 minecraft:deepslate_tiles
setblock 491 181 277 minecraft:cobbled_deepslate
fill 491 181 278 491 182 278 minecraft:deepslate_tiles
setblock 492 181 276 minecraft:cobbled_deepslate
fill 492 181 277 492 183 277 minecraft:deepslate_tiles
setblock 492 181 316 minecraft:cobbled_deepslate
fill 493 181 276 493 184 276 minecraft:deepslate_tiles
setblock 493 181 316 minecraft:deepslate_tiles
setblock 494 181 285 minecraft:light[level=12]
setblock 494 181 292 minecraft:light[level=12]
setblock 494 181 299 minecraft:light[level=12]
setblock 494 181 306 minecraft:light[level=12]
setblock 494 181 313 minecraft:light[level=12]
setblock 496 181 277 minecraft:cobbled_deepslate
setblock 497 181 276 minecraft:cobbled_deepslate
fill 497 181 277 497 184 277 minecraft:deepslate_tiles
setblock 497 181 278 minecraft:light[level=13]
setblock 497 181 286 minecraft:light[level=13]
setblock 497 181 294 minecraft:light[level=13]
setblock 497 181 302 minecraft:light[level=13]
setblock 497 181 310 minecraft:light[level=13]
setblock 497 181 316 minecraft:cobbled_deepslate
fill 498 181 276 498 184 276 minecraft:deepslate_tiles
fill 498 181 316 498 184 316 minecraft:deepslate_tiles
setblock 500 181 278 minecraft:cobbled_deepslate
setblock 501 181 277 minecraft:cobbled_deepslate
fill 501 181 278 501 184 278 minecraft:deepslate_tiles
setblock 501 181 285 minecraft:light[level=12]
setblock 501 181 292 minecraft:light[level=12]
setblock 501 181 299 minecraft:light[level=12]
setblock 501 181 306 minecraft:light[level=12]
setblock 501 181 313 minecraft:light[level=12]
setblock 502 181 276 minecraft:cobbled_deepslate
fill 502 181 277 502 184 277 minecraft:deepslate_tiles
setblock 502 181 316 minecraft:cobbled_deepslate
fill 503 181 276 503 184 276 minecraft:deepslate_tiles
setblock 503 181 315 minecraft:cobbled_deepslate
fill 503 181 316 503 184 316 minecraft:deepslate_tiles
setblock 504 181 314 minecraft:cobbled_deepslate
fill 504 181 315 504 184 315 minecraft:deepslate_tiles
fill 505 181 275 505 201 275 minecraft:black_concrete
setblock 505 181 278 minecraft:cobbled_deepslate
setblock 505 181 286 minecraft:light[level=13]
setblock 505 181 294 minecraft:light[level=13]
setblock 505 181 302 minecraft:light[level=13]
setblock 505 181 310 minecraft:light[level=13]
setblock 505 181 314 minecraft:deepslate_tiles
setblock 506 181 277 minecraft:cobbled_deepslate
fill 506 181 278 506 183 278 minecraft:deepslate_tiles
fill 506 181 313 506 192 313 minecraft:white_wool
setblock 507 181 276 minecraft:cobbled_deepslate
fill 507 181 277 507 184 277 minecraft:deepslate_tiles
setblock 507 181 316 minecraft:cobbled_deepslate
fill 508 181 276 508 184 276 minecraft:deepslate_tiles
setblock 508 181 285 minecraft:light[level=12]
setblock 508 181 292 minecraft:light[level=12]
setblock 508 181 299 minecraft:light[level=12]
setblock 508 181 306 minecraft:light[level=12]
setblock 508 181 313 minecraft:light[level=12]
setblock 508 181 315 minecraft:cobbled_deepslate
fill 508 181 316 508 184 316 minecraft:deepslate_tiles
setblock 509 181 299 minecraft:cobbled_deepslate
fill 509 181 300 509 181 303 minecraft:deepslate_tiles
setblock 509 181 304 minecraft:cobbled_deepslate
fill 509 181 305 509 183 305 minecraft:deepslate_tiles
fill 509 181 315 509 182 315 minecraft:deepslate_tiles
setblock 510 181 278 minecraft:cobbled_deepslate
setblock 510 181 279 minecraft:deepslate_tiles
setblock 510 181 298 minecraft:cobbled_deepslate
fill 510 181 299 510 183 299 minecraft:deepslate_tiles
setblock 510 181 303 minecraft:cobbled_deepslate
fill 510 181 304 510 184 304 minecraft:deepslate_tiles
setblock 510 181 308 minecraft:cobbled_deepslate
setblock 510 181 309 minecraft:deepslate_tiles
setblock 510 181 313 minecraft:cobbled_deepslate
setblock 510 181 314 minecraft:deepslate_tiles
setblock 511 181 277 minecraft:cobbled_deepslate
fill 511 181 278 511 183 278 minecraft:deepslate_tiles
setblock 511 181 282 minecraft:cobbled_deepslate
setblock 511 181 297 minecraft:cobbled_deepslate
fill 511 181 298 511 184 298 minecraft:deepslate_tiles
setblock 511 181 302 minecraft:cobbled_deepslate
fill 511 181 303 511 184 303 minecraft:deepslate_tiles
setblock 511 181 307 minecraft:cobbled_deepslate
fill 511 181 308 511 184 308 minecraft:deepslate_tiles
setblock 511 181 312 minecraft:cobbled_deepslate
fill 511 181 313 511 182 313 minecraft:deepslate_tiles
setblock 471 182 281 minecraft:cobbled_deepslate
setblock 471 182 282 minecraft:deepslate_tiles
setblock 471 182 296 minecraft:cobbled_deepslate
fill 471 182 297 471 185 297 minecraft:deepslate_tiles
setblock 471 182 301 minecraft:cobbled_deepslate
fill 471 182 302 471 185 302 minecraft:deepslate_tiles
setblock 471 182 306 minecraft:cobbled_deepslate
fill 471 182 307 471 185 307 minecraft:deepslate_tiles
setblock 472 182 296 minecraft:deepslate_tiles
setblock 472 182 300 minecraft:cobbled_deepslate
fill 472 182 301 472 184 301 minecraft:deepslate_tiles
setblock 472 182 305 minecraft:cobbled_deepslate
setblock 480 182 276 minecraft:deepslate_tiles
setblock 480 182 277 minecraft:cobbled_deepslate
setblock 481 182 276 minecraft:cobbled_deepslate
fill 481 182 277 481 185 277 minecraft:deepslate_tiles
fill 482 182 276 482 185 276 minecraft:deepslate_tiles
setblock 483 182 279 minecraft:cobbled_deepslate
setblock 484 182 278 minecraft:cobbled_deepslate
fill 484 182 279 484 183 279 minecraft:deepslate_tiles
setblock 485 182 277 minecraft:cobbled_deepslate
fill 485 182 278 485 185 278 minecraft:deepslate_tiles
setblock 486 182 276 minecraft:cobbled_deepslate
fill 486 182 277 486 185 277 minecraft:deepslate_tiles
setblock 486 182 316 minecraft:cobbled_deepslate
fill 487 182 276 487 185 276 minecraft:deepslate_tiles
fill 487 182 316 490 182 316 minecraft:deepslate_tiles
setblock 488 182 279 minecraft:cobbled_deepslate
setblock 489 182 278 minecraft:cobbled_deepslate
setblock 489 182 279 minecraft:deepslate_tiles
setblock 490 182 277 minecraft:cobbled_deepslate
fill 490 182 278 490 183 278 minecraft:deepslate_tiles
setblock 491 182 276 minecraft:cobbled_deepslate
fill 491 182 277 491 184 277 minecraft:deepslate_tiles
fill 492 182 276 492 185 276 minecraft:deepslate_tiles
setblock 495 182 277 minecraft:cobbled_deepslate
setblock 496 182 276 minecraft:cobbled_deepslate
fill 496 182 277 496 183 277 minecraft:deepslate_tiles
fill 497 182 276 497 185 276 minecraft:deepslate_tiles
setblock 497 182 316 minecraft:deepslate_tiles
setblock 499 182 278 minecraft:cobbled_deepslate
setblock 500 182 277 minecraft:cobbled_deepslate
fill 500 182 278 500 183 278 minecraft:deepslate_tiles
setblock 501 182 276 minecraft:cobbled_deepslate
fill 501 182 277 501 185 277 minecraft:deepslate_tiles
setblock 501 182 316 minecraft:cobbled_deepslate
fill 502 182 276 502 185 276 minecraft:deepslate_tiles
setblock 502 182 315 minecraft:cobbled_deepslate
fill 502 182 316 502 185 316 minecraft:deepslate_tiles
fill 503 182 315 503 185 315 minecraft:deepslate_tiles
setblock 504 182 278 minecraft:cobbled_deepslate
setblock 505 182 277 minecraft:cobbled_deepslate
fill 505 182 278 505 183 278 minecraft:deepslate_tiles
setblock 506 182 275 minecraft:white_wool
setblock 506 182 276 minecraft:cobbled_deepslate
fill 506 182 277 506 184 277 minecraft:deepslate_tiles
setblock 506 182 316 minecraft:cobbled_deepslate
fill 507 182 276 507 185 276 minecraft:deepslate_tiles
setblock 507 182 315 minecraft:cobbled_deepslate
fill 507 182 316 507 185 316 minecraft:deepslate_tiles
fill 508 182 315 508 183 315 minecraft:deepslate_tiles
fill 509 182 299 509 182 302 minecraft:deepslate_tiles
setblock 509 182 303 minecraft:cobbled_deepslate
fill 509 182 304 509 184 304 minecraft:deepslate_tiles
fill 509 182 307 509 190 307 minecraft:black_concrete
setblock 510 182 277 minecraft:cobbled_deepslate
setblock 510 182 278 minecraft:deepslate_tiles
setblock 510 182 297 minecraft:cobbled_deepslate
fill 510 182 298 510 183 298 minecraft:deepslate_tiles
setblock 510 182 302 minecraft:cobbled_deepslate
fill 510 182 303 510 185 303 minecraft:deepslate_tiles
setblock 510 182 307 minecraft:cobbled_deepslate
fill 510 182 308 510 183 308 minecraft:deepslate_tiles
setblock 511 182 276 minecraft:cobbled_deepslate
setblock 511 182 277 minecraft:deepslate_tiles
setblock 511 182 281 minecraft:cobbled_deepslate
setblock 511 182 282 minecraft:deepslate_tiles
setblock 511 182 296 minecraft:cobbled_deepslate
fill 511 182 297 511 183 297 minecraft:deepslate_tiles
setblock 511 182 301 minecraft:cobbled_deepslate
fill 511 182 302 511 185 302 minecraft:deepslate_tiles
setblock 511 182 306 minecraft:cobbled_deepslate
fill 511 182 307 511 185 307 minecraft:deepslate_tiles
setblock 511 182 311 minecraft:cobbled_deepslate
setblock 511 182 312 minecraft:deepslate_tiles
setblock 511 182 316 minecraft:cobbled_deepslate
setblock 471 183 281 minecraft:deepslate_tiles
setblock 471 183 295 minecraft:cobbled_deepslate
fill 471 183 296 471 184 296 minecraft:deepslate_tiles
setblock 471 183 300 minecraft:cobbled_deepslate
fill 471 183 301 471 186 301 minecraft:deepslate_tiles
setblock 471 183 305 minecraft:cobbled_deepslate
fill 471 183 306 471 186 306 minecraft:deepslate_tiles
setblock 472 183 299 minecraft:cobbled_deepslate
fill 472 183 300 472 184 300 minecraft:deepslate_tiles
setblock 472 183 304 minecraft:cobbled_deepslate
setblock 480 183 276 minecraft:cobbled_deepslate
fill 480 183 277 480 186 277 minecraft:deepslate_tiles
fill 481 183 276 481 186 276 minecraft:deepslate_tiles
setblock 483 183 278 minecraft:cobbled_deepslate
setblock 484 183 277 minecraft:cobbled_deepslate
fill 484 183 278 484 186 278 minecraft:deepslate_tiles
fill 484 183 283 484 184 285 minecraft:white_wool
setblock 485 183 276 minecraft:cobbled_deepslate
fill 485 183 277 485 186 277 minecraft:deepslate_tiles
fill 485 183 284 485 184 285 minecraft:white_wool
setblock 485 183 316 minecraft:cobbled_deepslate
fill 486 183 276 486 186 276 minecraft:deepslate_tiles
fill 486 183 316 487 183 316 minecraft:deepslate_tiles
setblock 487 183 279 minecraft:cobbled_deepslate
setblock 488 183 278 minecraft:cobbled_deepslate
setblock 489 183 277 minecraft:cobbled_deepslate
setblock 489 183 278 minecraft:deepslate_tiles
setblock 490 183 276 minecraft:cobbled_deepslate
fill 490 183 277 490 184 277 minecraft:deepslate_tiles
fill 491 183 276 491 186 276 minecraft:deepslate_tiles
fill 491 183 313 491 187 313 minecraft:cobbled_deepslate
fill 492 183 312 492 187 312 minecraft:cobbled_deepslate
fill 492 183 314 492 187 314 minecraft:cobbled_deepslate
fill 493 183 313 493 187 313 minecraft:cobbled_deepslate
setblock 494 183 277 minecraft:cobbled_deepslate
setblock 495 183 276 minecraft:cobbled_deepslate
setblock 495 183 277 minecraft:deepslate_tiles
fill 496 183 276 496 186 276 minecraft:deepslate_tiles
setblock 499 183 277 minecraft:cobbled_deepslate
fill 499 183 295 500 184 295 minecraft:white_wool
setblock 500 183 276 minecraft:cobbled_deepslate
fill 500 183 277 500 186 277 minecraft:deepslate_tiles
setblock 500 183 316 minecraft:cobbled_deepslate
fill 501 183 276 501 186 276 minecraft:deepslate_tiles
setblock 501 183 315 minecraft:cobbled_deepslate
fill 501 183 316 501 186 316 minecraft:deepslate_tiles
fill 502 183 315 502 186 315 minecraft:deepslate_tiles
setblock 503 183 278 minecraft:cobbled_deepslate
setblock 504 183 277 minecraft:cobbled_deepslate
fill 504 183 278 504 184 278 minecraft:deepslate_tiles
fill 504 183 287 508 184 291 minecraft:black_concrete
setblock 505 183 276 minecraft:cobbled_deepslate
fill 505 183 277 505 185 277 minecraft:deepslate_tiles
setblock 505 183 316 minecraft:cobbled_deepslate
fill 506 183 275 506 201 275 minecraft:black_concrete
fill 506 183 276 506 186 276 minecraft:deepslate_tiles
setblock 506 183 315 minecraft:cobbled_deepslate
fill 506 183 316 506 186 316 minecraft:deepslate_tiles
setblock 507 183 315 minecraft:deepslate_tiles
fill 509 183 289 510 183 289 minecraft:black_concrete
setblock 509 183 301 minecraft:deepslate_tiles
setblock 509 183 302 minecraft:cobbled_deepslate
fill 509 183 303 509 184 303 minecraft:deepslate_tiles
setblock 510 183 276 minecraft:cobbled_deepslate
setblock 510 183 301 minecraft:cobbled_deepslate
fill 510 183 302 510 186 302 minecraft:deepslate_tiles
setblock 510 183 306 minecraft:cobbled_deepslate
fill 510 183 307 510 186 307 minecraft:deepslate_tiles
setblock 510 183 316 minecraft:cobbled_deepslate
setblock 511 183 280 minecraft:cobbled_deepslate
setblock 511 183 300 minecraft:cobbled_deepslate
fill 511 183 301 511 186 301 minecraft:deepslate_tiles
setblock 511 183 305 minecraft:cobbled_deepslate
fill 511 183 306 511 186 306 minecraft:deepslate_tiles
setblock 511 183 310 minecraft:cobbled_deepslate
setblock 471 184 299 minecraft:cobbled_deepslate
fill 471 184 300 471 187 300 minecraft:deepslate_tiles
setblock 471 184 304 minecraft:cobbled_deepslate
fill 471 184 305 471 187 305 minecraft:deepslate_tiles
setblock 472 184 303 minecraft:cobbled_deepslate
fill 474 184 298 474 187 298 minecraft:black_concrete
fill 475 184 297 475 187 297 minecraft:black_concrete
fill 475 184 299 475 187 299 minecraft:black_concrete
fill 476 184 298 476 187 298 minecraft:black_concrete
setblock 479 184 276 minecraft:cobbled_deepslate
fill 480 184 276 480 187 276 minecraft:deepslate_tiles
setblock 482 184 278 minecraft:cobbled_deepslate
setblock 483 184 277 minecraft:cobbled_deepslate
fill 483 184 278 483 187 278 minecraft:deepslate_tiles
setblock 484 184 276 minecraft:cobbled_deepslate
fill 484 184 277 484 187 277 minecraft:deepslate_tiles
fill 485 184 276 485 187 276 minecraft:deepslate_tiles
setblock 487 184 278 minecraft:cobbled_deepslate
setblock 488 184 277 minecraft:cobbled_deepslate
setblock 488 184 278 minecraft:deepslate_tiles
setblock 489 184 276 minecraft:cobbled_deepslate
fill 489 184 277 489 185 277 minecraft:deepslate_tiles
fill 490 184 276 490 186 276 minecraft:deepslate_tiles
setblock 494 184 276 minecraft:cobbled_deepslate
fill 495 184 276 495 186 276 minecraft:deepslate_tiles
setblock 498 184 277 minecraft:cobbled_deepslate
setblock 499 184 276 minecraft:cobbled_deepslate
fill 499 184 277 499 187 277 minecraft:deepslate_tiles
setblock 499 184 316 minecraft:cobbled_deepslate
fill 500 184 276 500 187 276 minecraft:deepslate_tiles
fill 500 184 316 500 187 316 minecraft:deepslate_tiles
setblock 502 184 278 minecraft:cobbled_deepslate
setblock 503 184 277 minecraft:cobbled_deepslate
setblock 503 184 278 minecraft:deepslate_tiles
setblock 504 184 276 minecraft:cobbled_deepslate
fill 504 184 277 504 186 277 minecraft:deepslate_tiles
setblock 504 184 316 minecraft:cobbled_deepslate
fill 505 184 276 505 187 276 minecraft:deepslate_tiles
setblock 505 184 315 minecraft:cobbled_deepslate
fill 505 184 316 505 187 316 minecraft:deepslate_tiles
setblock 506 184 315 minecraft:deepslate_tiles
setblock 509 184 316 minecraft:cobbled_deepslate
setblock 510 184 300 minecraft:cobbled_deepslate
schedule function dropper:buildpart/70_8 1t
