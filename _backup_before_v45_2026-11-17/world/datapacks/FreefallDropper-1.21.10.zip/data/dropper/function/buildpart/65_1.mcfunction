fill 277 72 276 277 85 276 minecraft:smooth_sandstone
fill 277 72 277 277 72 278 minecraft:glowstone
fill 277 72 279 277 85 279 minecraft:smooth_sandstone
fill 277 72 288 277 84 288 minecraft:smooth_sandstone
fill 277 72 289 277 72 290 minecraft:glowstone
fill 277 72 291 277 85 291 minecraft:smooth_sandstone
fill 277 72 300 277 85 300 minecraft:smooth_sandstone
fill 277 72 301 277 72 302 minecraft:glowstone
setblock 277 72 303 minecraft:smooth_sandstone
fill 277 72 306 277 124 306 minecraft:smooth_sandstone
fill 277 72 312 277 85 312 minecraft:smooth_sandstone
fill 277 72 313 277 72 314 minecraft:glowstone
fill 277 72 315 277 85 315 minecraft:smooth_sandstone
fill 235 73 281 235 85 283 minecraft:smooth_sandstone
fill 235 73 294 235 85 295 minecraft:smooth_sandstone
fill 235 73 305 235 82 307 minecraft:smooth_sandstone
fill 236 73 317 237 85 317 minecraft:smooth_sandstone
fill 243 73 275 244 78 275 minecraft:smooth_sandstone
fill 247 73 314 253 74 314 minecraft:iron_block
fill 248 73 317 249 81 317 minecraft:smooth_sandstone
fill 255 73 275 256 85 275 minecraft:smooth_sandstone
fill 260 73 317 261 85 317 minecraft:smooth_sandstone
fill 267 73 275 268 85 275 minecraft:smooth_sandstone
setblock 272 73 275 minecraft:orange_terracotta
fill 272 73 317 273 85 317 minecraft:smooth_sandstone
fill 276 73 317 276 121 317 minecraft:smooth_sandstone
fill 277 73 277 277 85 278 minecraft:smooth_sandstone
fill 277 73 289 277 85 290 minecraft:smooth_sandstone
fill 277 73 301 277 85 302 minecraft:smooth_sandstone
setblock 277 73 303 minecraft:lapis_block
fill 277 73 313 277 82 314 minecraft:smooth_sandstone
setblock 235 74 316 minecraft:lapis_block
setblock 238 74 278 minecraft:light[level=15]
setblock 238 74 286 minecraft:light[level=15]
setblock 238 74 294 minecraft:light[level=15]
setblock 238 74 302 minecraft:light[level=15]
setblock 238 74 310 minecraft:light[level=15]
setblock 246 74 278 minecraft:light[level=15]
setblock 246 74 286 minecraft:light[level=15]
setblock 246 74 294 minecraft:light[level=15]
setblock 246 74 302 minecraft:light[level=15]
setblock 246 74 310 minecraft:light[level=15]
setblock 254 74 278 minecraft:light[level=15]
setblock 254 74 286 minecraft:light[level=15]
setblock 254 74 294 minecraft:light[level=15]
setblock 254 74 302 minecraft:light[level=15]
setblock 254 74 310 minecraft:light[level=15]
fill 256 74 277 256 85 277 minecraft:blue_wool
setblock 262 74 278 minecraft:light[level=15]
setblock 262 74 286 minecraft:light[level=15]
setblock 262 74 294 minecraft:light[level=15]
setblock 262 74 302 minecraft:light[level=15]
setblock 262 74 310 minecraft:light[level=15]
setblock 270 74 275 minecraft:black_terracotta
setblock 270 74 278 minecraft:light[level=15]
setblock 270 74 286 minecraft:light[level=15]
setblock 270 74 294 minecraft:light[level=15]
setblock 270 74 302 minecraft:light[level=15]
setblock 270 74 310 minecraft:light[level=15]
fill 272 74 275 272 121 275 minecraft:smooth_sandstone
fill 277 74 303 277 85 303 minecraft:smooth_sandstone
setblock 235 75 311 minecraft:orange_terracotta
fill 235 75 312 235 120 313 minecraft:smooth_sandstone
fill 235 75 316 235 124 316 minecraft:smooth_sandstone
setblock 240 75 275 minecraft:black_terracotta
fill 241 75 275 241 98 275 minecraft:smooth_sandstone
fill 254 75 277 255 85 277 minecraft:blue_wool
fill 257 75 277 258 85 277 minecraft:blue_wool
fill 270 75 275 270 124 275 minecraft:smooth_sandstone
setblock 235 76 292 minecraft:lapis_block
fill 235 76 311 235 125 311 minecraft:smooth_sandstone
setblock 238 76 278 minecraft:light[level=12]
setblock 238 76 285 minecraft:light[level=12]
setblock 238 76 292 minecraft:light[level=12]
setblock 238 76 299 minecraft:light[level=12]
setblock 238 76 306 minecraft:light[level=12]
setblock 238 76 313 minecraft:light[level=12]
fill 240 76 275 240 81 275 minecraft:smooth_sandstone
setblock 245 76 278 minecraft:light[level=12]
setblock 245 76 285 minecraft:light[level=12]
setblock 245 76 292 minecraft:light[level=12]
setblock 245 76 299 minecraft:light[level=12]
setblock 245 76 306 minecraft:light[level=12]
setblock 245 76 313 minecraft:light[level=12]
setblock 249 76 275 minecraft:lapis_block
setblock 252 76 278 minecraft:light[level=12]
setblock 252 76 285 minecraft:light[level=12]
setblock 252 76 292 minecraft:light[level=12]
setblock 252 76 299 minecraft:light[level=12]
setblock 252 76 306 minecraft:light[level=12]
setblock 252 76 313 minecraft:light[level=12]
setblock 259 76 278 minecraft:light[level=12]
setblock 259 76 285 minecraft:light[level=12]
setblock 259 76 292 minecraft:light[level=12]
setblock 259 76 299 minecraft:light[level=12]
setblock 259 76 306 minecraft:light[level=12]
setblock 259 76 313 minecraft:light[level=12]
setblock 266 76 278 minecraft:light[level=12]
setblock 266 76 285 minecraft:light[level=12]
setblock 266 76 292 minecraft:light[level=12]
setblock 266 76 299 minecraft:light[level=12]
setblock 266 76 306 minecraft:light[level=12]
setblock 266 76 313 minecraft:light[level=12]
setblock 273 76 278 minecraft:light[level=12]
setblock 273 76 285 minecraft:light[level=12]
setblock 273 76 292 minecraft:light[level=12]
setblock 273 76 299 minecraft:light[level=12]
setblock 273 76 306 minecraft:light[level=12]
setblock 273 76 313 minecraft:light[level=12]
setblock 277 76 284 minecraft:lapis_block
fill 235 77 292 235 124 292 minecraft:smooth_sandstone
fill 248 77 304 249 78 305 minecraft:sandstone
fill 249 77 275 249 122 275 minecraft:smooth_sandstone
fill 277 77 284 277 82 284 minecraft:smooth_sandstone
setblock 277 77 292 minecraft:lapis_block
setblock 275 78 317 minecraft:lapis_block
fill 277 78 292 277 124 292 minecraft:smooth_sandstone
fill 243 79 275 243 85 275 minecraft:smooth_sandstone
setblock 244 79 275 minecraft:black_terracotta
setblock 251 79 317 minecraft:blue_terracotta
fill 275 79 317 275 124 317 minecraft:smooth_sandstone
setblock 277 79 281 minecraft:orange_terracotta
fill 237 80 285 237 85 287 minecraft:cut_sandstone
fill 237 80 297 237 85 299 minecraft:cut_sandstone
fill 237 80 309 237 85 311 minecraft:cut_sandstone
fill 243 80 315 245 85 315 minecraft:cut_sandstone
fill 244 80 275 244 81 275 minecraft:smooth_sandstone
fill 247 80 277 249 85 277 minecraft:cut_sandstone
fill 251 80 317 251 103 317 minecraft:smooth_sandstone
setblock 253 80 317 minecraft:black_terracotta
fill 254 80 317 258 88 317 minecraft:smooth_sandstone
fill 255 80 315 257 85 315 minecraft:cut_sandstone
fill 259 80 277 261 85 277 minecraft:cut_sandstone
fill 267 80 315 269 85 315 minecraft:cut_sandstone
fill 271 80 277 273 85 277 minecraft:cut_sandstone
fill 275 80 285 275 85 287 minecraft:cut_sandstone
fill 275 80 297 275 85 299 minecraft:cut_sandstone
fill 275 80 309 275 85 311 minecraft:cut_sandstone
setblock 277 80 281 minecraft:smooth_sandstone
setblock 238 81 275 minecraft:orange_terracotta
fill 253 81 317 253 125 317 minecraft:smooth_sandstone
setblock 277 81 281 minecraft:blue_terracotta
setblock 277 81 316 minecraft:lapis_block
fill 238 82 275 238 124 275 minecraft:smooth_sandstone
setblock 238 82 278 minecraft:light[level=15]
setblock 238 82 285 minecraft:light[level=12]
setblock 238 82 286 minecraft:light[level=15]
setblock 238 82 292 minecraft:light[level=12]
setblock 238 82 294 minecraft:light[level=15]
setblock 238 82 299 minecraft:light[level=12]
setblock 238 82 302 minecraft:light[level=15]
setblock 238 82 306 minecraft:light[level=12]
setblock 238 82 310 minecraft:light[level=15]
setblock 238 82 313 minecraft:light[level=12]
setblock 240 82 275 minecraft:black_terracotta
setblock 244 82 275 minecraft:black_terracotta
setblock 245 82 278 minecraft:light[level=12]
setblock 245 82 285 minecraft:light[level=12]
setblock 245 82 292 minecraft:light[level=12]
setblock 245 82 299 minecraft:light[level=12]
setblock 245 82 306 minecraft:light[level=12]
setblock 245 82 313 minecraft:light[level=12]
setblock 246 82 278 minecraft:light[level=15]
setblock 246 82 286 minecraft:light[level=15]
setblock 246 82 294 minecraft:light[level=15]
setblock 246 82 302 minecraft:light[level=15]
setblock 246 82 310 minecraft:light[level=15]
fill 248 82 317 248 85 317 minecraft:smooth_sandstone
setblock 249 82 317 minecraft:lapis_block
setblock 252 82 278 minecraft:light[level=12]
setblock 252 82 285 minecraft:light[level=12]
setblock 252 82 292 minecraft:light[level=12]
setblock 252 82 299 minecraft:light[level=12]
setblock 252 82 306 minecraft:light[level=12]
setblock 252 82 313 minecraft:light[level=12]
setblock 254 82 278 minecraft:light[level=15]
setblock 254 82 286 minecraft:light[level=15]
setblock 254 82 294 minecraft:light[level=15]
setblock 254 82 302 minecraft:light[level=15]
setblock 254 82 310 minecraft:light[level=15]
setblock 259 82 278 minecraft:light[level=12]
setblock 259 82 285 minecraft:light[level=12]
setblock 259 82 292 minecraft:light[level=12]
setblock 259 82 299 minecraft:light[level=12]
setblock 259 82 306 minecraft:light[level=12]
setblock 259 82 313 minecraft:light[level=12]
setblock 262 82 278 minecraft:light[level=15]
setblock 262 82 286 minecraft:light[level=15]
setblock 262 82 294 minecraft:light[level=15]
setblock 262 82 302 minecraft:light[level=15]
setblock 262 82 310 minecraft:light[level=15]
setblock 266 82 278 minecraft:light[level=12]
setblock 266 82 285 minecraft:light[level=12]
setblock 266 82 292 minecraft:light[level=12]
setblock 266 82 299 minecraft:light[level=12]
setblock 266 82 306 minecraft:light[level=12]
setblock 266 82 313 minecraft:light[level=12]
setblock 270 82 278 minecraft:light[level=15]
setblock 270 82 286 minecraft:light[level=15]
setblock 270 82 294 minecraft:light[level=15]
setblock 270 82 302 minecraft:light[level=15]
setblock 270 82 310 minecraft:light[level=15]
setblock 273 82 278 minecraft:light[level=12]
setblock 273 82 285 minecraft:light[level=12]
setblock 273 82 292 minecraft:light[level=12]
setblock 273 82 299 minecraft:light[level=12]
setblock 273 82 306 minecraft:light[level=12]
setblock 273 82 313 minecraft:light[level=12]
fill 277 82 281 277 105 281 minecraft:smooth_sandstone
fill 277 82 294 277 96 297 minecraft:smooth_sandstone
setblock 277 82 298 minecraft:orange_terracotta
fill 277 82 299 277 120 299 minecraft:smooth_sandstone
fill 277 82 316 277 124 316 minecraft:smooth_sandstone
setblock 235 83 305 minecraft:orange_terracotta
fill 235 83 306 235 85 307 minecraft:smooth_sandstone
fill 240 83 275 240 105 275 minecraft:smooth_sandstone
fill 244 83 275 244 85 275 minecraft:smooth_sandstone
fill 249 83 317 249 85 317 minecraft:smooth_sandstone
setblock 277 83 284 minecraft:blue_terracotta
fill 277 83 298 277 124 298 minecraft:smooth_sandstone
fill 277 83 307 277 126 307 minecraft:smooth_sandstone
setblock 277 83 308 minecraft:lapis_block
setblock 277 83 313 minecraft:black_terracotta
fill 277 83 314 277 85 314 minecraft:smooth_sandstone
fill 235 84 305 235 85 305 minecraft:smooth_sandstone
fill 236 84 313 236 85 313 minecraft:cut_sandstone
fill 274 84 284 274 94 284 minecraft:blue_wool
fill 275 84 312 276 84 313 minecraft:cut_sandstone
fill 276 84 311 276 85 311 minecraft:cut_sandstone
fill 277 84 284 277 124 284 minecraft:smooth_sandstone
fill 277 84 308 277 116 308 minecraft:smooth_sandstone
fill 277 84 313 277 85 313 minecraft:smooth_sandstone
fill 235 85 290 235 112 290 minecraft:smooth_sandstone
setblock 235 85 291 minecraft:black_terracotta
fill 236 85 279 236 85 284 minecraft:chiseled_sandstone
fill 236 85 291 236 85 296 minecraft:chiseled_sandstone
fill 236 85 303 236 85 308 minecraft:chiseled_sandstone
fill 236 85 315 236 85 316 minecraft:chiseled_sandstone
fill 237 85 312 237 86 313 minecraft:cut_sandstone
fill 237 85 316 240 85 316 minecraft:chiseled_sandstone
fill 238 85 312 238 88 312 minecraft:cut_sandstone
fill 240 85 276 245 85 276 minecraft:chiseled_sandstone
fill 247 85 316 252 85 316 minecraft:chiseled_sandstone
fill 252 85 276 257 85 276 minecraft:chiseled_sandstone
fill 259 85 316 264 85 316 minecraft:chiseled_sandstone
fill 264 85 276 269 85 276 minecraft:chiseled_sandstone
fill 271 85 305 271 87 305 minecraft:shroomlight
fill 271 85 316 276 85 316 minecraft:chiseled_sandstone
fill 273 85 312 275 86 312 minecraft:cut_sandstone
fill 274 85 282 274 94 283 minecraft:blue_wool
fill 274 85 285 274 94 286 minecraft:blue_wool
fill 274 85 311 274 86 311 minecraft:cut_sandstone
fill 274 85 313 275 85 313 minecraft:cut_sandstone
fill 276 85 276 276 85 281 minecraft:chiseled_sandstone
fill 276 85 288 276 85 293 minecraft:chiseled_sandstone
fill 276 85 300 276 85 305 minecraft:chiseled_sandstone
fill 276 85 312 276 85 315 minecraft:chiseled_sandstone
setblock 277 85 288 minecraft:lapis_block
fill 235 86 281 235 91 284 minecraft:glowstone
fill 235 86 291 235 124 291 minecraft:smooth_sandstone
fill 235 86 293 235 91 296 minecraft:glowstone
fill 235 86 305 235 91 308 minecraft:glowstone
fill 235 86 317 238 91 317 minecraft:glowstone
fill 237 86 311 238 86 311 minecraft:cut_sandstone
fill 238 86 313 238 87 313 minecraft:cut_sandstone
fill 239 86 312 239 88 312 minecraft:cut_sandstone
fill 242 86 275 245 91 275 minecraft:glowstone
fill 247 86 317 250 91 317 minecraft:glowstone
fill 253 86 277 259 87 277 minecraft:iron_block
fill 254 86 275 257 91 275 minecraft:glowstone
fill 259 86 317 262 91 317 minecraft:glowstone
fill 266 86 275 269 91 275 minecraft:glowstone
fill 271 86 317 274 91 317 minecraft:glowstone
fill 272 86 312 272 88 312 minecraft:cut_sandstone
fill 273 86 311 273 87 311 minecraft:cut_sandstone
fill 273 86 313 274 86 313 minecraft:cut_sandstone
setblock 276 86 312 minecraft:lapis_block
fill 277 86 276 277 91 279 minecraft:glowstone
fill 277 86 288 277 91 291 minecraft:glowstone
fill 277 86 300 277 91 303 minecraft:glowstone
fill 277 86 312 277 91 315 minecraft:glowstone
setblock 237 87 312 minecraft:cut_sandstone
fill 238 87 311 240 87 311 minecraft:cut_sandstone
fill 239 87 313 240 88 313 minecraft:cut_sandstone
fill 240 87 312 240 89 312 minecraft:cut_sandstone
fill 267 87 313 267 89 313 minecraft:shroomlight
fill 271 87 311 271 88 313 minecraft:cut_sandstone
fill 272 87 311 272 88 311 minecraft:cut_sandstone
fill 272 87 313 273 87 313 minecraft:cut_sandstone
fill 273 87 312 274 87 312 minecraft:cut_sandstone
fill 274 87 299 274 99 299 minecraft:blue_wool
setblock 275 87 312 minecraft:lapis_block
setblock 235 88 278 minecraft:lapis_block
fill 235 88 279 235 120 279 minecraft:smooth_sandstone
setblock 235 88 289 minecraft:lapis_block
setblock 237 88 312 minecraft:lapis_block
setblock 238 88 278 minecraft:light[level=12]
setblock 238 88 285 minecraft:light[level=12]
setblock 238 88 292 minecraft:light[level=12]
setblock 238 88 299 minecraft:light[level=12]
setblock 238 88 306 minecraft:light[level=12]
setblock 238 88 313 minecraft:light[level=12]
fill 239 88 311 241 88 311 minecraft:cut_sandstone
fill 241 88 312 241 89 313 minecraft:cut_sandstone
fill 242 88 312 242 90 312 minecraft:cut_sandstone
setblock 245 88 278 minecraft:light[level=12]
setblock 245 88 285 minecraft:light[level=12]
setblock 245 88 292 minecraft:light[level=12]
setblock 245 88 299 minecraft:light[level=12]
setblock 245 88 306 minecraft:light[level=12]
setblock 245 88 313 minecraft:light[level=12]
setblock 252 88 278 minecraft:light[level=12]
setblock 252 88 285 minecraft:light[level=12]
setblock 252 88 292 minecraft:light[level=12]
setblock 252 88 299 minecraft:light[level=12]
setblock 252 88 306 minecraft:light[level=12]
setblock 252 88 313 minecraft:light[level=12]
setblock 259 88 278 minecraft:light[level=12]
setblock 259 88 285 minecraft:light[level=12]
setblock 259 88 292 minecraft:light[level=12]
setblock 259 88 299 minecraft:light[level=12]
setblock 259 88 306 minecraft:light[level=12]
setblock 259 88 313 minecraft:light[level=12]
setblock 266 88 278 minecraft:light[level=12]
setblock 266 88 285 minecraft:light[level=12]
setblock 266 88 292 minecraft:light[level=12]
setblock 266 88 299 minecraft:light[level=12]
setblock 266 88 306 minecraft:light[level=12]
setblock 266 88 313 minecraft:light[level=12]
fill 269 88 312 270 90 312 minecraft:cut_sandstone
fill 270 88 311 270 89 311 minecraft:cut_sandstone
fill 270 88 313 270 89 313 minecraft:cut_sandstone
setblock 272 88 313 minecraft:cut_sandstone
setblock 273 88 278 minecraft:light[level=12]
setblock 273 88 285 minecraft:light[level=12]
setblock 273 88 292 minecraft:light[level=12]
setblock 273 88 299 minecraft:light[level=12]
setblock 273 88 306 minecraft:light[level=12]
setblock 273 88 312 minecraft:cut_sandstone
setblock 273 88 313 minecraft:light[level=12]
fill 274 88 297 274 99 298 minecraft:blue_wool
fill 274 88 300 274 99 301 minecraft:blue_wool
setblock 274 88 312 minecraft:lapis_block
fill 235 89 278 235 103 278 minecraft:smooth_sandstone
fill 235 89 289 235 124 289 minecraft:smooth_sandstone
fill 235 89 301 235 94 303 minecraft:smooth_sandstone
setblock 235 89 304 minecraft:orange_terracotta
setblock 239 89 312 minecraft:lapis_block
fill 241 89 311 242 89 311 minecraft:cut_sandstone
fill 242 89 313 242 90 313 minecraft:cut_sandstone
fill 243 89 312 243 91 312 minecraft:cut_sandstone
setblock 246 89 275 minecraft:blue_terracotta
fill 247 89 275 248 124 275 minecraft:smooth_sandstone
fill 254 89 317 254 124 317 minecraft:smooth_sandstone
setblock 255 89 317 minecraft:blue_terracotta
fill 256 89 317 258 98 317 minecraft:smooth_sandstone
fill 268 89 312 268 91 312 minecraft:cut_sandstone
fill 269 89 311 269 90 311 minecraft:cut_sandstone
fill 269 89 313 269 90 313 minecraft:cut_sandstone
setblock 271 89 312 minecraft:cut_sandstone
setblock 272 89 312 minecraft:lapis_block
setblock 235 90 299 minecraft:lapis_block
fill 235 90 304 235 106 304 minecraft:smooth_sandstone
setblock 238 90 278 minecraft:light[level=15]
setblock 238 90 286 minecraft:light[level=15]
setblock 238 90 294 minecraft:light[level=15]
setblock 238 90 302 minecraft:light[level=15]
setblock 238 90 310 minecraft:light[level=15]
fill 240 90 312 241 90 312 minecraft:lapis_block
fill 242 90 311 244 90 311 minecraft:cut_sandstone
fill 243 90 313 244 90 313 minecraft:cut_sandstone
fill 244 90 312 245 92 312 minecraft:cut_sandstone
fill 246 90 275 246 102 275 minecraft:smooth_sandstone
setblock 246 90 278 minecraft:light[level=15]
setblock 246 90 286 minecraft:light[level=15]
setblock 246 90 294 minecraft:light[level=15]
setblock 246 90 302 minecraft:light[level=15]
setblock 246 90 310 minecraft:light[level=15]
fill 247 90 307 248 91 307 minecraft:sandstone
setblock 252 90 275 minecraft:orange_terracotta
fill 253 90 275 253 124 275 minecraft:smooth_sandstone
setblock 254 90 278 minecraft:light[level=15]
setblock 254 90 286 minecraft:light[level=15]
setblock 254 90 294 minecraft:light[level=15]
setblock 254 90 302 minecraft:light[level=15]
setblock 254 90 310 minecraft:light[level=15]
fill 255 90 317 255 124 317 minecraft:smooth_sandstone
setblock 262 90 278 minecraft:light[level=15]
setblock 262 90 286 minecraft:light[level=15]
setblock 262 90 294 minecraft:light[level=15]
setblock 262 90 302 minecraft:light[level=15]
setblock 262 90 310 minecraft:light[level=15]
fill 266 90 312 267 92 312 minecraft:cut_sandstone
fill 267 90 311 268 90 311 minecraft:cut_sandstone
fill 267 90 313 268 90 313 minecraft:cut_sandstone
setblock 270 90 278 minecraft:light[level=15]
setblock 270 90 286 minecraft:light[level=15]
setblock 270 90 294 minecraft:light[level=15]
setblock 270 90 302 minecraft:light[level=15]
setblock 270 90 310 minecraft:light[level=15]
setblock 271 90 312 minecraft:lapis_block
fill 235 91 299 235 124 299 minecraft:smooth_sandstone
setblock 242 91 312 minecraft:lapis_block
fill 244 91 311 246 91 311 minecraft:cut_sandstone
fill 244 91 313 246 91 313 minecraft:cut_sandstone
fill 246 91 312 247 92 312 minecraft:cut_sandstone
fill 252 91 275 252 124 275 minecraft:smooth_sandstone
fill 264 91 312 265 93 312 minecraft:cut_sandstone
fill 265 91 311 267 91 311 minecraft:cut_sandstone
fill 265 91 313 267 91 313 minecraft:cut_sandstone
setblock 269 91 312 minecraft:lapis_block
fill 235 92 281 235 100 281 minecraft:smooth_sandstone
fill 235 92 282 235 92 283 minecraft:glowstone
fill 235 92 284 235 100 284 minecraft:smooth_sandstone
fill 235 92 293 235 105 293 minecraft:smooth_sandstone
fill 235 92 294 235 92 295 minecraft:glowstone
fill 235 92 296 235 105 296 minecraft:smooth_sandstone
fill 235 92 305 235 93 305 minecraft:smooth_sandstone
fill 235 92 306 235 92 307 minecraft:glowstone
fill 235 92 308 235 105 308 minecraft:smooth_sandstone
fill 235 92 317 235 105 317 minecraft:smooth_sandstone
fill 236 92 317 237 92 317 minecraft:glowstone
fill 238 92 317 238 105 317 minecraft:smooth_sandstone
fill 242 92 275 242 105 275 minecraft:smooth_sandstone
fill 243 92 275 244 92 275 minecraft:glowstone
setblock 243 92 312 minecraft:lapis_block
fill 245 92 275 245 105 275 minecraft:smooth_sandstone
fill 245 92 311 248 92 311 minecraft:cut_sandstone
fill 245 92 313 248 92 313 minecraft:cut_sandstone
fill 247 92 317 247 105 317 minecraft:smooth_sandstone
fill 248 92 312 249 94 312 minecraft:cut_sandstone
fill 248 92 317 249 92 317 minecraft:glowstone
fill 250 92 317 250 105 317 minecraft:smooth_sandstone
setblock 251 92 275 minecraft:lapis_block
fill 254 92 275 254 105 275 minecraft:smooth_sandstone
fill 255 92 275 256 92 275 minecraft:glowstone
fill 257 92 275 257 105 275 minecraft:smooth_sandstone
fill 259 92 317 259 105 317 minecraft:smooth_sandstone
fill 260 92 317 261 92 317 minecraft:glowstone
fill 262 92 312 263 94 312 minecraft:cut_sandstone
fill 262 92 317 262 105 317 minecraft:smooth_sandstone
fill 263 92 311 266 92 311 minecraft:cut_sandstone
fill 263 92 313 266 92 313 minecraft:cut_sandstone
fill 266 92 275 266 105 275 minecraft:smooth_sandstone
fill 267 92 275 268 92 275 minecraft:glowstone
setblock 268 92 312 minecraft:lapis_block
fill 269 92 275 269 105 275 minecraft:smooth_sandstone
fill 271 92 317 271 105 317 minecraft:smooth_sandstone
fill 272 92 317 273 92 317 minecraft:glowstone
fill 274 92 317 274 105 317 minecraft:smooth_sandstone
fill 277 92 276 277 105 276 minecraft:smooth_sandstone
fill 277 92 277 277 92 278 minecraft:glowstone
fill 277 92 279 277 102 279 minecraft:smooth_sandstone
fill 277 92 288 277 105 288 minecraft:smooth_sandstone
fill 277 92 289 277 92 290 minecraft:glowstone
fill 277 92 291 277 105 291 minecraft:smooth_sandstone
fill 277 92 300 277 105 300 minecraft:smooth_sandstone
fill 277 92 301 277 92 302 minecraft:glowstone
fill 277 92 303 277 105 303 minecraft:smooth_sandstone
fill 277 92 312 277 105 312 minecraft:smooth_sandstone
fill 277 92 313 277 92 314 minecraft:glowstone
fill 277 92 315 277 105 315 minecraft:smooth_sandstone
fill 235 93 282 235 105 283 minecraft:smooth_sandstone
fill 235 93 294 235 105 295 minecraft:smooth_sandstone
fill 235 93 297 235 94 297 minecraft:smooth_sandstone
setblock 235 93 298 minecraft:black_terracotta
fill 235 93 306 235 105 307 minecraft:smooth_sandstone
fill 236 93 317 237 105 317 minecraft:smooth_sandstone
fill 243 93 275 244 105 275 minecraft:smooth_sandstone
fill 245 93 312 246 93 312 minecraft:lapis_block
fill 247 93 311 247 93 313 minecraft:cut_sandstone
fill 248 93 311 250 93 311 minecraft:cut_sandstone
fill 248 93 313 250 93 313 minecraft:cut_sandstone
fill 248 93 317 249 105 317 minecraft:smooth_sandstone
fill 250 93 312 254 94 312 minecraft:cut_sandstone
fill 251 93 275 251 106 275 minecraft:smooth_sandstone
fill 255 93 275 256 105 275 minecraft:smooth_sandstone
fill 257 93 312 261 94 312 minecraft:cut_sandstone
fill 260 93 317 261 97 317 minecraft:smooth_sandstone
fill 261 93 311 264 93 311 minecraft:cut_sandstone
fill 261 93 313 264 93 313 minecraft:cut_sandstone
setblock 266 93 312 minecraft:lapis_block
fill 267 93 275 268 105 275 minecraft:smooth_sandstone
fill 272 93 317 273 105 317 minecraft:smooth_sandstone
fill 277 93 277 277 105 278 minecraft:smooth_sandstone
fill 277 93 289 277 104 290 minecraft:smooth_sandstone
fill 277 93 301 277 105 302 minecraft:smooth_sandstone
fill 277 93 313 277 105 314 minecraft:smooth_sandstone
fill 235 94 298 235 122 298 minecraft:smooth_sandstone
setblock 235 94 305 minecraft:orange_terracotta
setblock 238 94 278 minecraft:light[level=12]
setblock 238 94 285 minecraft:light[level=12]
setblock 238 94 292 minecraft:light[level=12]
setblock 238 94 299 minecraft:light[level=12]
setblock 238 94 306 minecraft:light[level=12]
setblock 238 94 313 minecraft:light[level=12]
setblock 239 94 275 minecraft:black_terracotta
setblock 245 94 278 minecraft:light[level=12]
setblock 245 94 285 minecraft:light[level=12]
setblock 245 94 292 minecraft:light[level=12]
setblock 245 94 299 minecraft:light[level=12]
setblock 245 94 306 minecraft:light[level=12]
setblock 245 94 313 minecraft:light[level=12]
fill 246 94 312 247 94 312 minecraft:lapis_block
fill 250 94 311 261 94 311 minecraft:cut_sandstone
fill 250 94 313 261 94 313 minecraft:cut_sandstone
setblock 252 94 278 minecraft:light[level=12]
setblock 252 94 285 minecraft:light[level=12]
setblock 252 94 292 minecraft:light[level=12]
setblock 252 94 299 minecraft:light[level=12]
setblock 252 94 306 minecraft:light[level=12]
fill 255 94 312 256 95 312 minecraft:cut_sandstone
setblock 259 94 278 minecraft:light[level=12]
setblock 259 94 285 minecraft:light[level=12]
setblock 259 94 292 minecraft:light[level=12]
setblock 259 94 299 minecraft:light[level=12]
setblock 259 94 306 minecraft:light[level=12]
fill 264 94 312 265 94 312 minecraft:lapis_block
setblock 266 94 278 minecraft:light[level=12]
setblock 266 94 285 minecraft:light[level=12]
setblock 266 94 292 minecraft:light[level=12]
setblock 266 94 299 minecraft:light[level=12]
setblock 266 94 306 minecraft:light[level=12]
setblock 266 94 313 minecraft:light[level=12]
setblock 268 94 317 minecraft:black_terracotta
setblock 273 94 278 minecraft:light[level=12]
setblock 273 94 285 minecraft:light[level=12]
setblock 273 94 292 minecraft:light[level=12]
setblock 273 94 299 minecraft:light[level=12]
setblock 273 94 306 minecraft:light[level=12]
setblock 273 94 313 minecraft:light[level=12]
setblock 235 95 297 minecraft:blue_terracotta
setblock 235 95 301 minecraft:lapis_block
fill 235 95 302 235 108 303 minecraft:smooth_sandstone
fill 235 95 305 235 105 305 minecraft:smooth_sandstone
fill 239 95 275 239 120 275 minecraft:smooth_sandstone
fill 249 95 312 250 95 312 minecraft:lapis_block
fill 251 95 312 254 95 312 minecraft:cut_sandstone
fill 254 95 311 257 95 311 minecraft:cut_sandstone
fill 254 95 313 257 95 313 minecraft:cut_sandstone
fill 257 95 312 260 95 312 minecraft:cut_sandstone
fill 261 95 312 262 95 312 minecraft:lapis_block
fill 268 95 317 268 109 317 minecraft:smooth_sandstone
fill 274 95 281 274 96 287 minecraft:iron_block
fill 235 96 297 235 120 297 minecraft:smooth_sandstone
fill 235 96 301 235 124 301 minecraft:smooth_sandstone
fill 251 96 312 260 96 312 minecraft:lapis_block
fill 262 96 311 262 97 311 minecraft:sandstone
setblock 277 96 282 minecraft:lapis_block
setblock 235 97 287 minecraft:black_terracotta
fill 277 97 282 277 120 282 minecraft:smooth_sandstone
fill 277 97 294 277 124 294 minecraft:smooth_sandstone
setblock 277 97 295 minecraft:orange_terracotta
fill 277 97 296 277 98 297 minecraft:smooth_sandstone
fill 235 98 287 235 102 287 minecraft:smooth_sandstone
setblock 238 98 278 minecraft:light[level=15]
setblock 238 98 286 minecraft:light[level=15]
setblock 238 98 294 minecraft:light[level=15]
setblock 238 98 302 minecraft:light[level=15]
setblock 238 98 310 minecraft:light[level=15]
setblock 246 98 278 minecraft:light[level=15]
setblock 246 98 286 minecraft:light[level=15]
setblock 246 98 294 minecraft:light[level=15]
setblock 246 98 302 minecraft:light[level=15]
setblock 246 98 310 minecraft:light[level=15]
setblock 254 98 278 minecraft:light[level=15]
setblock 254 98 286 minecraft:light[level=15]
setblock 254 98 294 minecraft:light[level=15]
setblock 254 98 302 minecraft:light[level=15]
setblock 254 98 310 minecraft:light[level=15]
setblock 260 98 317 minecraft:blue_terracotta
fill 261 98 317 261 105 317 minecraft:smooth_sandstone
setblock 262 98 278 minecraft:light[level=15]
setblock 262 98 286 minecraft:light[level=15]
setblock 262 98 294 minecraft:light[level=15]
setblock 262 98 302 minecraft:light[level=15]
setblock 262 98 310 minecraft:light[level=15]
setblock 270 98 278 minecraft:light[level=15]
setblock 270 98 286 minecraft:light[level=15]
setblock 270 98 294 minecraft:light[level=15]
setblock 270 98 302 minecraft:light[level=15]
setblock 270 98 310 minecraft:light[level=15]
fill 277 98 295 277 122 295 minecraft:smooth_sandstone
setblock 241 99 275 minecraft:blue_terracotta
fill 256 99 317 257 99 317 minecraft:smooth_sandstone
setblock 258 99 317 minecraft:blue_terracotta
fill 260 99 317 260 105 317 minecraft:smooth_sandstone
setblock 277 99 287 minecraft:black_terracotta
fill 277 99 296 277 113 296 minecraft:smooth_sandstone
setblock 277 99 297 minecraft:black_terracotta
setblock 235 100 315 minecraft:blue_terracotta
fill 237 100 285 237 105 287 minecraft:cut_sandstone
fill 237 100 297 237 105 299 minecraft:cut_sandstone
fill 237 100 309 237 105 311 minecraft:cut_sandstone
setblock 238 100 278 minecraft:light[level=12]
setblock 238 100 285 minecraft:light[level=12]
setblock 238 100 292 minecraft:light[level=12]
setblock 238 100 299 minecraft:light[level=12]
setblock 238 100 306 minecraft:light[level=12]
setblock 238 100 313 minecraft:light[level=12]
fill 241 100 275 241 124 275 minecraft:smooth_sandstone
fill 243 100 315 245 105 315 minecraft:cut_sandstone
setblock 245 100 278 minecraft:light[level=12]
setblock 245 100 285 minecraft:light[level=12]
setblock 245 100 292 minecraft:light[level=12]
setblock 245 100 299 minecraft:light[level=12]
setblock 245 100 306 minecraft:light[level=12]
setblock 245 100 313 minecraft:light[level=12]
fill 247 100 277 249 105 277 minecraft:cut_sandstone
setblock 252 100 278 minecraft:light[level=12]
setblock 252 100 285 minecraft:light[level=12]
setblock 252 100 292 minecraft:light[level=12]
setblock 252 100 299 minecraft:light[level=12]
setblock 252 100 306 minecraft:light[level=12]
setblock 252 100 313 minecraft:light[level=12]
fill 255 100 315 257 105 315 minecraft:cut_sandstone
setblock 256 100 317 minecraft:blue_terracotta
fill 257 100 317 258 120 317 minecraft:smooth_sandstone
fill 259 100 277 261 105 277 minecraft:cut_sandstone
setblock 259 100 278 minecraft:light[level=12]
setblock 259 100 285 minecraft:light[level=12]
setblock 259 100 292 minecraft:light[level=12]
setblock 259 100 299 minecraft:light[level=12]
fill 259 100 304 259 101 305 minecraft:sandstone
setblock 259 100 306 minecraft:light[level=12]
setblock 259 100 313 minecraft:light[level=12]
setblock 266 100 278 minecraft:light[level=12]
setblock 266 100 285 minecraft:light[level=12]
setblock 266 100 292 minecraft:light[level=12]
setblock 266 100 299 minecraft:light[level=12]
setblock 266 100 306 minecraft:light[level=12]
setblock 266 100 313 minecraft:light[level=12]
fill 267 100 315 269 105 315 minecraft:cut_sandstone
fill 271 100 277 273 105 277 minecraft:cut_sandstone
setblock 273 100 278 minecraft:light[level=12]
setblock 273 100 285 minecraft:light[level=12]
setblock 273 100 292 minecraft:light[level=12]
setblock 273 100 299 minecraft:light[level=12]
setblock 273 100 306 minecraft:light[level=12]
setblock 273 100 313 minecraft:light[level=12]
fill 274 100 296 274 101 302 minecraft:iron_block
fill 275 100 285 275 105 287 minecraft:cut_sandstone
fill 275 100 297 275 105 299 minecraft:cut_sandstone
fill 275 100 309 275 105 311 minecraft:cut_sandstone
fill 277 100 287 277 104 287 minecraft:smooth_sandstone
fill 277 100 297 277 111 297 minecraft:smooth_sandstone
setblock 235 101 281 minecraft:black_terracotta
setblock 235 101 284 minecraft:lapis_block
fill 235 101 315 235 107 315 minecraft:smooth_sandstone
fill 256 101 317 256 124 317 minecraft:smooth_sandstone
fill 261 101 312 261 104 312 minecraft:iron_block
fill 235 102 281 235 105 281 minecraft:smooth_sandstone
fill 235 102 284 235 105 284 minecraft:smooth_sandstone
setblock 235 103 287 minecraft:blue_terracotta
setblock 235 103 310 minecraft:lapis_block
setblock 236 103 275 minecraft:lapis_block
setblock 246 103 275 minecraft:blue_terracotta
fill 265 103 281 266 104 282 minecraft:smooth_sandstone
fill 277 103 279 277 103 280 minecraft:lapis_block
setblock 235 104 278 minecraft:blue_terracotta
fill 235 104 287 235 118 287 minecraft:smooth_sandstone
setblock 235 104 288 minecraft:orange_terracotta
fill 235 104 310 235 124 310 minecraft:smooth_sandstone
fill 236 104 275 236 124 275 minecraft:smooth_sandstone
fill 246 104 275 246 124 275 minecraft:smooth_sandstone
setblock 251 104 317 minecraft:blue_terracotta
fill 277 104 279 277 105 280 minecraft:smooth_sandstone
fill 235 105 278 235 121 278 minecraft:smooth_sandstone
fill 235 105 288 235 121 288 minecraft:smooth_sandstone
fill 236 105 279 236 105 284 minecraft:chiseled_sandstone
fill 236 105 291 236 105 296 minecraft:chiseled_sandstone
fill 236 105 303 236 105 308 minecraft:chiseled_sandstone
fill 236 105 315 236 105 316 minecraft:chiseled_sandstone
fill 237 105 316 240 105 316 minecraft:chiseled_sandstone
fill 240 105 276 245 105 276 minecraft:chiseled_sandstone
fill 247 105 316 252 105 316 minecraft:chiseled_sandstone
fill 251 105 317 251 112 317 minecraft:smooth_sandstone
fill 252 105 276 257 105 276 minecraft:chiseled_sandstone
fill 258 105 312 264 105 315 minecraft:chiseled_sandstone
fill 259 105 316 264 105 316 minecraft:chiseled_sandstone
fill 264 105 276 269 105 276 minecraft:chiseled_sandstone
fill 271 105 316 276 105 316 minecraft:chiseled_sandstone
fill 276 105 276 276 105 281 minecraft:chiseled_sandstone
fill 276 105 288 276 105 293 minecraft:chiseled_sandstone
fill 276 105 300 276 105 305 minecraft:chiseled_sandstone
fill 276 105 312 276 105 315 minecraft:chiseled_sandstone
setblock 277 105 287 minecraft:black_terracotta
setblock 277 105 289 minecraft:black_terracotta
setblock 277 105 290 minecraft:smooth_sandstone
fill 235 106 281 235 111 284 minecraft:glowstone
fill 235 106 293 235 111 296 minecraft:glowstone
fill 235 106 305 235 111 308 minecraft:glowstone
fill 235 106 317 238 111 317 minecraft:glowstone
setblock 238 106 278 minecraft:light[level=15]
setblock 238 106 285 minecraft:light[level=12]
setblock 238 106 286 minecraft:light[level=15]
setblock 238 106 292 minecraft:light[level=12]
setblock 238 106 294 minecraft:light[level=15]
setblock 238 106 299 minecraft:light[level=12]
setblock 238 106 302 minecraft:light[level=15]
setblock 238 106 306 minecraft:light[level=12]
setblock 238 106 310 minecraft:light[level=15]
setblock 238 106 313 minecraft:light[level=12]
setblock 240 106 275 minecraft:blue_terracotta
fill 242 106 275 245 111 275 minecraft:glowstone
setblock 245 106 278 minecraft:light[level=12]
setblock 245 106 285 minecraft:light[level=12]
setblock 245 106 292 minecraft:light[level=12]
setblock 245 106 299 minecraft:light[level=12]
setblock 245 106 306 minecraft:light[level=12]
setblock 245 106 313 minecraft:light[level=12]
setblock 246 106 278 minecraft:light[level=15]
setblock 246 106 286 minecraft:light[level=15]
setblock 246 106 294 minecraft:light[level=15]
setblock 246 106 302 minecraft:light[level=15]
setblock 246 106 310 minecraft:light[level=15]
fill 247 106 317 250 111 317 minecraft:glowstone
setblock 252 106 278 minecraft:light[level=12]
setblock 252 106 285 minecraft:light[level=12]
setblock 252 106 292 minecraft:light[level=12]
setblock 252 106 299 minecraft:light[level=12]
setblock 252 106 306 minecraft:light[level=12]
setblock 252 106 313 minecraft:light[level=12]
fill 254 106 275 257 111 275 minecraft:glowstone
setblock 254 106 278 minecraft:light[level=15]
setblock 254 106 286 minecraft:light[level=15]
setblock 254 106 294 minecraft:light[level=15]
setblock 254 106 302 minecraft:light[level=15]
setblock 254 106 310 minecraft:light[level=15]
fill 258 106 312 264 106 315 minecraft:cut_sandstone
setblock 259 106 278 minecraft:light[level=12]
setblock 259 106 285 minecraft:light[level=12]
setblock 259 106 292 minecraft:light[level=12]
setblock 259 106 299 minecraft:light[level=12]
setblock 259 106 306 minecraft:light[level=12]
fill 259 106 317 262 111 317 minecraft:glowstone
setblock 262 106 278 minecraft:light[level=15]
setblock 262 106 286 minecraft:light[level=15]
setblock 262 106 294 minecraft:light[level=15]
setblock 262 106 302 minecraft:light[level=15]
setblock 262 106 310 minecraft:light[level=15]
fill 266 106 275 269 111 275 minecraft:glowstone
setblock 266 106 278 minecraft:light[level=12]
setblock 266 106 285 minecraft:light[level=12]
setblock 266 106 292 minecraft:light[level=12]
setblock 266 106 299 minecraft:light[level=12]
setblock 266 106 306 minecraft:light[level=12]
setblock 266 106 313 minecraft:light[level=12]
setblock 270 106 278 minecraft:light[level=15]
setblock 270 106 286 minecraft:light[level=15]
setblock 270 106 294 minecraft:light[level=15]
setblock 270 106 302 minecraft:light[level=15]
setblock 270 106 310 minecraft:light[level=15]
fill 271 106 317 274 111 317 minecraft:glowstone
setblock 273 106 278 minecraft:light[level=12]
setblock 273 106 285 minecraft:light[level=12]
setblock 273 106 292 minecraft:light[level=12]
setblock 273 106 299 minecraft:light[level=12]
setblock 273 106 306 minecraft:light[level=12]
setblock 273 106 313 minecraft:light[level=12]
fill 277 106 276 277 111 279 minecraft:glowstone
fill 277 106 280 277 121 280 minecraft:smooth_sandstone
setblock 277 106 281 minecraft:lapis_block
fill 277 106 287 277 120 287 minecraft:smooth_sandstone
fill 277 106 288 277 111 291 minecraft:glowstone
fill 277 106 300 277 111 303 minecraft:glowstone
fill 277 106 312 277 111 315 minecraft:glowstone
setblock 235 107 304 minecraft:blue_terracotta
fill 240 107 275 240 112 275 minecraft:smooth_sandstone
fill 248 107 290 248 108 290 minecraft:sandstone
setblock 251 107 275 minecraft:lapis_block
fill 258 107 312 264 107 312 minecraft:lapis_block
fill 260 107 316 262 110 316 minecraft:glowstone
fill 277 107 281 277 124 281 minecraft:smooth_sandstone
fill 235 108 304 235 124 304 minecraft:smooth_sandstone
setblock 235 108 309 minecraft:orange_terracotta
setblock 235 108 315 minecraft:orange_terracotta
fill 239 108 297 240 109 298 minecraft:sandstone
fill 241 108 317 244 109 317 minecraft:smooth_sandstone
setblock 245 108 317 minecraft:lapis_block
fill 246 108 317 246 121 317 minecraft:smooth_sandstone
fill 251 108 275 251 118 275 minecraft:smooth_sandstone
fill 258 108 275 263 117 275 minecraft:smooth_sandstone
setblock 258 108 312 minecraft:cut_sandstone
setblock 261 108 312 minecraft:cut_sandstone
setblock 264 108 275 minecraft:black_terracotta
setblock 264 108 312 minecraft:cut_sandstone
fill 265 108 275 265 124 275 minecraft:smooth_sandstone
fill 235 109 302 235 124 302 minecraft:smooth_sandstone
setblock 235 109 303 minecraft:lapis_block
fill 235 109 309 235 110 309 minecraft:smooth_sandstone
fill 235 109 315 235 116 315 minecraft:smooth_sandstone
fill 245 109 317 245 124 317 minecraft:smooth_sandstone
fill 257 109 284 259 110 284 minecraft:smooth_sandstone
fill 258 109 283 258 110 283 minecraft:smooth_sandstone
fill 258 109 285 258 110 285 minecraft:smooth_sandstone
setblock 263 109 317 minecraft:orange_terracotta
fill 264 109 275 264 121 275 minecraft:smooth_sandstone
fill 235 110 303 235 124 303 minecraft:smooth_sandstone
setblock 241 110 317 minecraft:blue_terracotta
fill 242 110 317 244 120 317 minecraft:smooth_sandstone
fill 263 110 317 263 112 317 minecraft:smooth_sandstone
setblock 268 110 317 minecraft:blue_terracotta
setblock 235 111 277 minecraft:blue_terracotta
setblock 235 111 309 minecraft:blue_terracotta
fill 237 111 287 242 111 287 minecraft:chiseled_sandstone
fill 238 111 285 242 112 286 minecraft:chiseled_sandstone
fill 238 111 288 242 112 289 minecraft:chiseled_sandstone
setblock 239 111 317 minecraft:blue_terracotta
fill 241 111 317 241 120 317 minecraft:smooth_sandstone
fill 268 111 317 268 124 317 minecraft:smooth_sandstone
setblock 271 111 275 minecraft:black_terracotta
fill 235 112 277 235 118 277 minecraft:smooth_sandstone
fill 235 112 281 235 123 281 minecraft:smooth_sandstone
fill 235 112 282 235 112 283 minecraft:glowstone
setblock 235 112 284 minecraft:smooth_sandstone
fill 235 112 293 235 115 293 minecraft:smooth_sandstone
fill 235 112 294 235 112 295 minecraft:glowstone
fill 235 112 296 235 124 296 minecraft:smooth_sandstone
fill 235 112 305 235 120 305 minecraft:smooth_sandstone
fill 235 112 306 235 112 307 minecraft:glowstone
fill 235 112 308 235 125 309 minecraft:smooth_sandstone
fill 235 112 317 235 120 317 minecraft:smooth_sandstone
fill 236 112 317 237 112 317 minecraft:glowstone
setblock 238 112 278 minecraft:light[level=12]
fill 238 112 287 242 112 287 minecraft:chiseled_sandstone
setblock 238 112 292 minecraft:light[level=12]
setblock 238 112 299 minecraft:light[level=12]
setblock 238 112 306 minecraft:light[level=12]
setblock 238 112 313 minecraft:light[level=12]
fill 238 112 317 239 115 317 minecraft:smooth_sandstone
fill 241 112 304 241 114 304 minecraft:shroomlight
fill 242 112 275 242 124 275 minecraft:smooth_sandstone
fill 243 112 275 244 112 275 minecraft:glowstone
fill 243 112 294 243 113 294 minecraft:sandstone
setblock 245 112 275 minecraft:black_terracotta
setblock 245 112 278 minecraft:light[level=12]
setblock 245 112 285 minecraft:light[level=12]
setblock 245 112 292 minecraft:light[level=12]
setblock 245 112 299 minecraft:light[level=12]
setblock 245 112 306 minecraft:light[level=12]
setblock 245 112 313 minecraft:light[level=12]
fill 247 112 317 247 124 317 minecraft:smooth_sandstone
fill 248 112 317 249 112 317 minecraft:glowstone
fill 250 112 317 250 125 317 minecraft:smooth_sandstone
setblock 252 112 278 minecraft:light[level=12]
setblock 252 112 285 minecraft:light[level=12]
setblock 252 112 292 minecraft:light[level=12]
setblock 252 112 299 minecraft:light[level=12]
setblock 252 112 306 minecraft:light[level=12]
setblock 252 112 313 minecraft:light[level=12]
fill 254 112 275 254 124 275 minecraft:smooth_sandstone
fill 255 112 275 256 112 275 minecraft:glowstone
fill 257 112 275 257 124 275 minecraft:smooth_sandstone
setblock 259 112 278 minecraft:light[level=12]
setblock 259 112 285 minecraft:light[level=12]
setblock 259 112 292 minecraft:light[level=12]
setblock 259 112 299 minecraft:light[level=12]
setblock 259 112 306 minecraft:light[level=12]
setblock 259 112 313 minecraft:light[level=12]
fill 259 112 317 259 125 317 minecraft:smooth_sandstone
fill 260 112 317 261 112 317 minecraft:glowstone
fill 262 112 317 262 124 317 minecraft:smooth_sandstone
fill 263 112 291 264 113 292 minecraft:smooth_sandstone
fill 266 112 275 266 124 275 minecraft:smooth_sandstone
setblock 266 112 278 minecraft:light[level=12]
setblock 266 112 285 minecraft:light[level=12]
setblock 266 112 292 minecraft:light[level=12]
setblock 266 112 299 minecraft:light[level=12]
setblock 266 112 306 minecraft:light[level=12]
setblock 266 112 313 minecraft:light[level=12]
fill 267 112 275 268 112 275 minecraft:glowstone
fill 269 112 275 269 124 275 minecraft:smooth_sandstone
fill 271 112 275 271 126 275 minecraft:smooth_sandstone
fill 271 112 317 271 124 317 minecraft:smooth_sandstone
fill 272 112 317 273 112 317 minecraft:glowstone
setblock 273 112 278 minecraft:light[level=12]
setblock 273 112 285 minecraft:light[level=12]
setblock 273 112 292 minecraft:light[level=12]
setblock 273 112 299 minecraft:light[level=12]
setblock 273 112 306 minecraft:light[level=12]
setblock 273 112 313 minecraft:light[level=12]
fill 274 112 317 274 124 317 minecraft:smooth_sandstone
fill 277 112 276 277 114 276 minecraft:smooth_sandstone
fill 277 112 277 277 112 278 minecraft:glowstone
fill 277 112 279 277 124 279 minecraft:smooth_sandstone
fill 277 112 288 277 114 288 minecraft:smooth_sandstone
fill 277 112 289 277 112 290 minecraft:glowstone
fill 277 112 291 277 125 291 minecraft:smooth_sandstone
setblock 277 112 297 minecraft:blue_terracotta
fill 277 112 300 277 124 300 minecraft:smooth_sandstone
fill 277 112 301 277 112 302 minecraft:glowstone
fill 277 112 303 277 124 303 minecraft:smooth_sandstone
fill 277 112 312 277 124 312 minecraft:smooth_sandstone
fill 277 112 313 277 112 314 minecraft:glowstone
fill 277 112 315 277 124 315 minecraft:smooth_sandstone
fill 235 113 282 235 122 283 minecraft:smooth_sandstone
setblock 235 113 284 minecraft:black_terracotta
setblock 235 113 290 minecraft:black_terracotta
fill 235 113 294 235 122 295 minecraft:smooth_sandstone
fill 235 113 306 235 122 307 minecraft:smooth_sandstone
fill 236 113 317 237 121 317 minecraft:smooth_sandstone
fill 239 113 286 241 114 288 minecraft:cut_sandstone
setblock 240 113 275 minecraft:orange_terracotta
fill 243 113 275 245 122 275 minecraft:smooth_sandstone
fill 248 113 317 249 120 317 minecraft:smooth_sandstone
setblock 251 113 317 minecraft:orange_terracotta
fill 255 113 275 256 113 275 minecraft:smooth_sandstone
fill 260 113 317 261 124 317 minecraft:smooth_sandstone
setblock 263 113 317 minecraft:lapis_block
fill 267 113 275 268 120 275 minecraft:smooth_sandstone
fill 269 113 300 273 114 304 minecraft:chiseled_sandstone
fill 272 113 317 273 122 317 minecraft:smooth_sandstone
fill 274 113 302 275 113 302 minecraft:chiseled_sandstone
fill 277 113 277 277 122 278 minecraft:smooth_sandstone
fill 277 113 289 277 117 290 minecraft:smooth_sandstone
fill 277 113 297 277 124 297 minecraft:smooth_sandstone
fill 277 113 301 277 115 302 minecraft:smooth_sandstone
fill 277 113 313 277 124 314 minecraft:smooth_sandstone
fill 235 114 284 235 124 284 minecraft:smooth_sandstone
fill 235 114 290 235 124 290 minecraft:smooth_sandstone
setblock 238 114 278 minecraft:light[level=15]
setblock 238 114 286 minecraft:light[level=15]
setblock 238 114 294 minecraft:light[level=15]
setblock 238 114 302 minecraft:light[level=15]
setblock 238 114 310 minecraft:light[level=15]
fill 240 114 275 240 120 275 minecraft:smooth_sandstone
setblock 246 114 278 minecraft:light[level=15]
setblock 246 114 286 minecraft:light[level=15]
setblock 246 114 294 minecraft:light[level=15]
setblock 246 114 302 minecraft:light[level=15]
setblock 246 114 310 minecraft:light[level=15]
fill 251 114 317 251 121 317 minecraft:smooth_sandstone
setblock 254 114 278 minecraft:light[level=15]
setblock 254 114 286 minecraft:light[level=15]
setblock 254 114 294 minecraft:light[level=15]
setblock 254 114 302 minecraft:light[level=15]
setblock 254 114 310 minecraft:light[level=15]
setblock 255 114 275 minecraft:orange_terracotta
fill 256 114 275 256 124 275 minecraft:smooth_sandstone
setblock 262 114 278 minecraft:light[level=15]
setblock 262 114 286 minecraft:light[level=15]
setblock 262 114 294 minecraft:light[level=15]
setblock 262 114 302 minecraft:light[level=15]
setblock 262 114 310 minecraft:light[level=15]
fill 263 114 317 263 120 317 minecraft:smooth_sandstone
setblock 270 114 278 minecraft:light[level=15]
setblock 270 114 286 minecraft:light[level=15]
setblock 270 114 294 minecraft:light[level=15]
setblock 270 114 310 minecraft:light[level=15]
setblock 277 114 296 minecraft:black_terracotta
fill 255 115 275 255 124 275 minecraft:smooth_sandstone
setblock 277 115 276 minecraft:blue_terracotta
setblock 277 115 288 minecraft:black_terracotta
fill 277 115 296 277 124 296 minecraft:smooth_sandstone
setblock 235 116 293 minecraft:orange_terracotta
setblock 238 116 317 minecraft:lapis_block
fill 239 116 317 239 124 317 minecraft:smooth_sandstone
fill 277 116 276 277 122 276 minecraft:smooth_sandstone
fill 277 116 288 277 124 288 minecraft:smooth_sandstone
setblock 277 116 301 minecraft:blue_terracotta
fill 277 116 302 277 121 302 minecraft:smooth_sandstone
fill 235 117 293 235 122 293 minecraft:smooth_sandstone
setblock 235 117 315 minecraft:blue_terracotta
fill 238 117 317 238 124 317 minecraft:smooth_sandstone
fill 277 117 301 277 124 301 minecraft:smooth_sandstone
setblock 277 117 308 minecraft:blue_terracotta
fill 235 118 315 235 121 315 minecraft:smooth_sandstone
setblock 238 118 278 minecraft:light[level=12]
setblock 238 118 285 minecraft:light[level=12]
setblock 238 118 292 minecraft:light[level=12]
setblock 238 118 299 minecraft:light[level=12]
setblock 238 118 306 minecraft:light[level=12]
setblock 238 118 313 minecraft:light[level=12]
setblock 245 118 278 minecraft:light[level=12]
setblock 245 118 285 minecraft:light[level=12]
setblock 245 118 292 minecraft:light[level=12]
setblock 245 118 299 minecraft:light[level=12]
setblock 245 118 306 minecraft:light[level=12]
setblock 245 118 313 minecraft:light[level=12]
setblock 252 118 278 minecraft:light[level=12]
setblock 252 118 285 minecraft:light[level=12]
setblock 252 118 292 minecraft:light[level=12]
setblock 252 118 299 minecraft:light[level=12]
setblock 252 118 306 minecraft:light[level=12]
setblock 252 118 313 minecraft:light[level=12]
setblock 258 118 275 minecraft:orange_terracotta
fill 259 118 275 263 120 275 minecraft:smooth_sandstone
setblock 259 118 278 minecraft:light[level=12]
setblock 259 118 285 minecraft:light[level=12]
setblock 259 118 292 minecraft:light[level=12]
setblock 259 118 299 minecraft:light[level=12]
setblock 259 118 306 minecraft:light[level=12]
setblock 259 118 313 minecraft:light[level=12]
setblock 266 118 278 minecraft:light[level=12]
setblock 266 118 285 minecraft:light[level=12]
setblock 266 118 292 minecraft:light[level=12]
setblock 266 118 299 minecraft:light[level=12]
setblock 266 118 306 minecraft:light[level=12]
setblock 266 118 313 minecraft:light[level=12]
setblock 273 118 278 minecraft:light[level=12]
setblock 273 118 285 minecraft:light[level=12]
setblock 273 118 292 minecraft:light[level=12]
setblock 273 118 299 minecraft:light[level=12]
setblock 273 118 306 minecraft:light[level=12]
setblock 273 118 313 minecraft:light[level=12]
fill 277 118 289 277 124 289 minecraft:smooth_sandstone
setblock 277 118 290 minecraft:black_terracotta
fill 277 118 308 277 124 308 minecraft:smooth_sandstone
setblock 235 119 277 minecraft:orange_terracotta
setblock 235 119 287 minecraft:black_terracotta
setblock 251 119 275 minecraft:black_terracotta
fill 258 119 275 258 124 275 minecraft:smooth_sandstone
fill 277 119 290 277 121 290 minecraft:smooth_sandstone
fill 235 120 277 235 124 277 minecraft:smooth_sandstone
fill 235 120 287 235 124 287 minecraft:smooth_sandstone
fill 244 120 296 252 120 296 minecraft:cyan_terracotta
fill 245 120 295 251 121 295 minecraft:cyan_terracotta
fill 245 120 297 251 121 297 minecraft:cyan_terracotta
fill 246 120 294 250 121 294 minecraft:cyan_terracotta
fill 246 120 298 250 121 298 minecraft:cyan_terracotta
fill 251 120 275 251 121 275 minecraft:smooth_sandstone
fill 251 120 293 253 120 294 minecraft:lapis_block
fill 251 120 298 253 120 299 minecraft:lapis_block
fill 252 120 292 260 120 292 minecraft:lapis_block
fill 252 120 295 253 120 295 minecraft:lapis_block
fill 252 120 297 253 120 297 minecraft:lapis_block
fill 252 120 300 260 120 300 minecraft:lapis_block
fill 253 120 291 259 120 291 minecraft:lapis_block
fill 253 120 301 259 120 301 minecraft:lapis_block
fill 254 120 293 255 120 293 minecraft:lapis_block
fill 254 120 299 255 120 299 minecraft:lapis_block
fill 256 120 290 256 121 290 minecraft:lapis_block
fill 256 120 302 256 121 302 minecraft:lapis_block
fill 257 120 293 261 120 293 minecraft:lapis_block
fill 257 120 299 261 120 299 minecraft:lapis_block
fill 259 120 294 260 120 295 minecraft:lapis_block
fill 259 120 297 260 120 298 minecraft:lapis_block
fill 260 120 296 268 120 296 minecraft:cyan_terracotta
setblock 261 120 294 minecraft:lapis_block
fill 261 120 295 267 121 295 minecraft:cyan_terracotta
fill 261 120 297 267 121 297 minecraft:cyan_terracotta
setblock 261 120 298 minecraft:lapis_block
fill 262 120 294 266 121 294 minecraft:cyan_terracotta
fill 262 120 298 266 121 298 minecraft:cyan_terracotta
fill 235 121 279 238 121 279 minecraft:sandstone
fill 235 121 297 236 121 297 minecraft:sandstone
fill 235 121 305 236 121 305 minecraft:sandstone
setblock 235 121 312 minecraft:smooth_sandstone
fill 235 121 313 236 121 313 minecraft:sandstone
fill 235 121 317 235 123 317 minecraft:sandstone
fill 236 121 276 236 121 277 minecraft:sandstone
setblock 236 121 278 minecraft:orange_terracotta
fill 236 121 280 236 121 281 minecraft:sandstone
setblock 236 121 282 minecraft:orange_terracotta
fill 236 121 283 236 121 285 minecraft:sandstone
setblock 236 121 286 minecraft:orange_terracotta
fill 236 121 287 236 121 289 minecraft:sandstone
setblock 236 121 290 minecraft:orange_terracotta
fill 236 121 291 236 121 293 minecraft:sandstone
setblock 236 121 294 minecraft:orange_terracotta
fill 236 121 295 237 121 296 minecraft:sandstone
setblock 236 121 298 minecraft:orange_terracotta
fill 236 121 299 236 121 301 minecraft:sandstone
setblock 236 121 302 minecraft:orange_terracotta
fill 236 121 303 237 121 304 minecraft:sandstone
setblock 236 121 306 minecraft:orange_terracotta
fill 236 121 307 236 121 309 minecraft:sandstone
setblock 236 121 310 minecraft:orange_terracotta
fill 236 121 311 237 121 312 minecraft:sandstone
setblock 236 121 314 minecraft:orange_terracotta
fill 236 121 315 237 121 316 minecraft:sandstone
setblock 237 121 276 minecraft:sandstone
setblock 237 121 277 minecraft:orange_terracotta
fill 237 121 278 239 121 278 minecraft:sandstone
setblock 237 121 280 minecraft:sandstone
setblock 237 121 281 minecraft:orange_terracotta
fill 237 121 282 237 121 284 minecraft:sandstone
setblock 237 121 285 minecraft:orange_terracotta
fill 237 121 286 237 121 288 minecraft:sandstone
setblock 237 121 289 minecraft:orange_terracotta
fill 237 121 290 237 121 292 minecraft:sandstone
setblock 237 121 293 minecraft:orange_terracotta
fill 237 121 294 239 121 294 minecraft:sandstone
setblock 237 121 297 minecraft:orange_terracotta
fill 237 121 298 237 121 300 minecraft:sandstone
setblock 237 121 301 minecraft:orange_terracotta
fill 237 121 302 239 121 302 minecraft:sandstone
setblock 237 121 305 minecraft:orange_terracotta
fill 237 121 306 237 121 308 minecraft:sandstone
setblock 237 121 309 minecraft:orange_terracotta
fill 237 121 310 239 121 310 minecraft:sandstone
setblock 237 121 313 minecraft:orange_terracotta
fill 237 121 314 239 121 314 minecraft:sandstone
setblock 238 121 276 minecraft:orange_terracotta
fill 238 121 277 240 121 277 minecraft:sandstone
setblock 238 121 280 minecraft:orange_terracotta
fill 238 121 281 238 121 283 minecraft:sandstone
setblock 238 121 284 minecraft:orange_terracotta
fill 238 121 285 238 121 287 minecraft:sandstone
setblock 238 121 288 minecraft:orange_terracotta
fill 238 121 289 238 121 291 minecraft:sandstone
setblock 238 121 292 minecraft:orange_terracotta
fill 238 121 293 240 121 293 minecraft:sandstone
setblock 238 121 295 minecraft:sandstone
setblock 238 121 296 minecraft:orange_terracotta
fill 238 121 297 238 121 299 minecraft:sandstone
setblock 238 121 300 minecraft:orange_terracotta
fill 238 121 301 240 121 301 minecraft:sandstone
setblock 238 121 303 minecraft:sandstone
setblock 238 121 304 minecraft:orange_terracotta
fill 238 121 305 238 121 307 minecraft:sandstone
setblock 238 121 308 minecraft:orange_terracotta
fill 238 121 309 240 121 309 minecraft:sandstone
setblock 238 121 311 minecraft:sandstone
setblock 238 121 312 minecraft:orange_terracotta
fill 238 121 313 240 121 313 minecraft:sandstone
setblock 238 121 315 minecraft:sandstone
setblock 238 121 316 minecraft:orange_terracotta
fill 239 121 275 240 121 276 minecraft:sandstone
setblock 239 121 279 minecraft:orange_terracotta
fill 239 121 280 239 121 282 minecraft:sandstone
setblock 239 121 283 minecraft:orange_terracotta
fill 239 121 284 239 121 286 minecraft:sandstone
setblock 239 121 287 minecraft:orange_terracotta
fill 239 121 288 239 121 290 minecraft:sandstone
setblock 239 121 291 minecraft:orange_terracotta
fill 239 121 292 241 121 292 minecraft:sandstone
setblock 239 121 295 minecraft:orange_terracotta
fill 239 121 296 239 121 298 minecraft:sandstone
setblock 239 121 299 minecraft:orange_terracotta
fill 239 121 300 241 121 300 minecraft:sandstone
setblock 239 121 303 minecraft:orange_terracotta
fill 239 121 304 239 121 306 minecraft:sandstone
setblock 239 121 307 minecraft:orange_terracotta
fill 239 121 308 241 121 308 minecraft:sandstone
setblock 239 121 311 minecraft:orange_terracotta
fill 239 121 312 241 121 312 minecraft:sandstone
setblock 239 121 315 minecraft:orange_terracotta
fill 239 121 316 241 121 316 minecraft:sandstone
setblock 240 121 278 minecraft:orange_terracotta
fill 240 121 279 240 121 281 minecraft:sandstone
setblock 240 121 282 minecraft:orange_terracotta
fill 240 121 283 240 121 285 minecraft:sandstone
setblock 240 121 286 minecraft:orange_terracotta
fill 240 121 287 240 121 289 minecraft:sandstone
setblock 240 121 290 minecraft:orange_terracotta
fill 240 121 291 242 121 291 minecraft:sandstone
setblock 240 121 294 minecraft:orange_terracotta
fill 240 121 295 240 121 297 minecraft:sandstone
setblock 240 121 298 minecraft:orange_terracotta
fill 240 121 299 242 121 299 minecraft:sandstone
setblock 240 121 302 minecraft:orange_terracotta
fill 240 121 303 240 121 305 minecraft:sandstone
setblock 240 121 306 minecraft:orange_terracotta
fill 240 121 307 242 121 307 minecraft:sandstone
setblock 240 121 310 minecraft:orange_terracotta
fill 240 121 311 242 121 311 minecraft:sandstone
setblock 240 121 314 minecraft:orange_terracotta
fill 240 121 315 242 121 315 minecraft:sandstone
setblock 241 121 276 minecraft:sandstone
setblock 241 121 277 minecraft:orange_terracotta
fill 241 121 278 241 121 280 minecraft:sandstone
setblock 241 121 281 minecraft:orange_terracotta
fill 241 121 282 241 121 284 minecraft:sandstone
setblock 241 121 285 minecraft:orange_terracotta
fill 241 121 286 241 121 288 minecraft:sandstone
setblock 241 121 289 minecraft:orange_terracotta
fill 241 121 290 243 121 290 minecraft:sandstone
setblock 241 121 293 minecraft:orange_terracotta
fill 241 121 294 241 121 296 minecraft:sandstone
setblock 241 121 297 minecraft:orange_terracotta
fill 241 121 298 243 121 298 minecraft:sandstone
setblock 241 121 301 minecraft:orange_terracotta
fill 241 121 302 241 121 304 minecraft:sandstone
setblock 241 121 305 minecraft:orange_terracotta
fill 241 121 306 243 121 306 minecraft:sandstone
setblock 241 121 309 minecraft:orange_terracotta
fill 241 121 310 243 121 310 minecraft:sandstone
setblock 241 121 313 minecraft:orange_terracotta
fill 241 121 314 243 121 314 minecraft:sandstone
fill 241 121 317 242 121 317 minecraft:sandstone
setblock 242 121 276 minecraft:orange_terracotta
fill 242 121 277 242 121 279 minecraft:sandstone
setblock 242 121 280 minecraft:orange_terracotta
fill 242 121 281 242 121 283 minecraft:sandstone
setblock 242 121 284 minecraft:orange_terracotta
fill 242 121 285 242 121 287 minecraft:sandstone
setblock 242 121 288 minecraft:orange_terracotta
fill 242 121 289 244 121 289 minecraft:sandstone
setblock 242 121 292 minecraft:orange_terracotta
fill 242 121 293 242 121 295 minecraft:sandstone
setblock 242 121 296 minecraft:orange_terracotta
fill 242 121 297 244 121 297 minecraft:sandstone
setblock 242 121 300 minecraft:orange_terracotta
fill 242 121 301 242 121 303 minecraft:sandstone
setblock 242 121 304 minecraft:orange_terracotta
fill 242 121 305 244 121 305 minecraft:sandstone
setblock 242 121 308 minecraft:orange_terracotta
fill 242 121 309 244 121 309 minecraft:sandstone
setblock 242 121 312 minecraft:orange_terracotta
fill 242 121 313 244 121 313 minecraft:sandstone
setblock 242 121 316 minecraft:orange_terracotta
fill 243 121 276 243 121 278 minecraft:sandstone
setblock 243 121 279 minecraft:orange_terracotta
fill 243 121 280 243 121 282 minecraft:sandstone
setblock 243 121 283 minecraft:orange_terracotta
fill 243 121 284 243 121 286 minecraft:sandstone
setblock 243 121 287 minecraft:orange_terracotta
fill 243 121 288 245 121 288 minecraft:sandstone
setblock 243 121 291 minecraft:orange_terracotta
fill 243 121 292 243 121 294 minecraft:sandstone
setblock 243 121 295 minecraft:orange_terracotta
setblock 243 121 296 minecraft:sandstone
setblock 243 121 299 minecraft:orange_terracotta
fill 243 121 300 243 121 302 minecraft:sandstone
setblock 243 121 303 minecraft:orange_terracotta
fill 243 121 304 245 121 304 minecraft:sandstone
setblock 243 121 307 minecraft:orange_terracotta
fill 243 121 308 245 121 308 minecraft:sandstone
setblock 243 121 311 minecraft:orange_terracotta
fill 243 121 312 245 121 312 minecraft:sandstone
setblock 243 121 315 minecraft:orange_terracotta
fill 243 121 316 245 121 316 minecraft:sandstone
fill 243 121 317 243 124 317 minecraft:smooth_sandstone
fill 244 121 276 244 121 277 minecraft:sandstone
setblock 244 121 278 minecraft:orange_terracotta
fill 244 121 279 244 121 281 minecraft:sandstone
setblock 244 121 282 minecraft:orange_terracotta
fill 244 121 283 244 121 285 minecraft:sandstone
setblock 244 121 286 minecraft:orange_terracotta
fill 244 121 287 246 121 287 minecraft:sandstone
setblock 244 121 290 minecraft:orange_terracotta
fill 244 121 291 244 121 293 minecraft:sandstone
setblock 244 121 294 minecraft:orange_terracotta
setblock 244 121 295 minecraft:sandstone
fill 244 121 296 251 121 296 minecraft:cyan_terracotta
setblock 244 121 298 minecraft:orange_terracotta
fill 244 121 299 244 121 301 minecraft:sandstone
setblock 244 121 302 minecraft:orange_terracotta
fill 244 121 303 246 121 303 minecraft:sandstone
setblock 244 121 306 minecraft:orange_terracotta
fill 244 121 307 246 121 307 minecraft:sandstone
setblock 244 121 310 minecraft:orange_terracotta
fill 244 121 311 246 121 311 minecraft:sandstone
setblock 244 121 314 minecraft:orange_terracotta
fill 244 121 315 246 121 315 minecraft:sandstone
setblock 244 121 317 minecraft:sandstone
setblock 245 121 276 minecraft:sandstone
setblock 245 121 277 minecraft:orange_terracotta
fill 245 121 278 245 121 280 minecraft:sandstone
setblock 245 121 281 minecraft:orange_terracotta
fill 245 121 282 245 121 284 minecraft:sandstone
setblock 245 121 285 minecraft:orange_terracotta
fill 245 121 286 247 121 286 minecraft:sandstone
setblock 245 121 289 minecraft:orange_terracotta
fill 245 121 290 245 121 292 minecraft:sandstone
setblock 245 121 293 minecraft:orange_terracotta
setblock 245 121 294 minecraft:sandstone
fill 245 121 298 245 121 300 minecraft:sandstone
setblock 245 121 301 minecraft:orange_terracotta
fill 245 121 302 247 121 302 minecraft:sandstone
setblock 245 121 305 minecraft:orange_terracotta
fill 245 121 306 247 121 306 minecraft:sandstone
setblock 245 121 309 minecraft:orange_terracotta
fill 245 121 310 247 121 310 minecraft:sandstone
setblock 245 121 313 minecraft:orange_terracotta
fill 245 121 314 247 121 314 minecraft:sandstone
setblock 246 121 276 minecraft:orange_terracotta
fill 246 121 277 246 121 279 minecraft:sandstone
setblock 246 121 280 minecraft:orange_terracotta
fill 246 121 281 246 121 283 minecraft:sandstone
setblock 246 121 284 minecraft:orange_terracotta
fill 246 121 285 248 121 285 minecraft:sandstone
setblock 246 121 288 minecraft:orange_terracotta
fill 246 121 289 246 121 291 minecraft:sandstone
setblock 246 121 292 minecraft:orange_terracotta
fill 246 121 293 248 121 293 minecraft:sandstone
setblock 246 121 299 minecraft:sandstone
setblock 246 121 300 minecraft:orange_terracotta
fill 246 121 301 248 121 301 minecraft:sandstone
setblock 246 121 304 minecraft:orange_terracotta
fill 246 121 305 248 121 305 minecraft:sandstone
setblock 246 121 308 minecraft:orange_terracotta
fill 246 121 309 248 121 309 minecraft:sandstone
setblock 246 121 312 minecraft:orange_terracotta
fill 246 121 313 248 121 313 minecraft:sandstone
setblock 246 121 316 minecraft:orange_terracotta
fill 247 121 276 247 121 278 minecraft:sandstone
setblock 247 121 279 minecraft:orange_terracotta
fill 247 121 280 247 121 282 minecraft:sandstone
setblock 247 121 283 minecraft:orange_terracotta
fill 247 121 284 249 121 284 minecraft:sandstone
setblock 247 121 287 minecraft:orange_terracotta
fill 247 121 288 247 121 290 minecraft:sandstone
setblock 247 121 291 minecraft:orange_terracotta
fill 247 121 292 249 121 292 minecraft:sandstone
setblock 247 121 299 minecraft:orange_terracotta
fill 247 121 300 249 121 300 minecraft:sandstone
setblock 247 121 303 minecraft:orange_terracotta
fill 247 121 304 249 121 304 minecraft:sandstone
setblock 247 121 307 minecraft:orange_terracotta
fill 247 121 308 249 121 308 minecraft:sandstone
setblock 247 121 311 minecraft:orange_terracotta
fill 247 121 312 249 121 312 minecraft:sandstone
setblock 247 121 315 minecraft:orange_terracotta
fill 247 121 316 249 121 316 minecraft:sandstone
fill 248 121 276 248 121 277 minecraft:sandstone
setblock 248 121 278 minecraft:orange_terracotta
fill 248 121 279 248 121 281 minecraft:sandstone
setblock 248 121 282 minecraft:orange_terracotta
fill 248 121 283 250 121 283 minecraft:sandstone
setblock 248 121 286 minecraft:orange_terracotta
fill 248 121 287 248 121 289 minecraft:sandstone
setblock 248 121 290 minecraft:orange_terracotta
fill 248 121 291 250 121 291 minecraft:sandstone
fill 248 121 299 250 121 299 minecraft:sandstone
setblock 248 121 302 minecraft:orange_terracotta
fill 248 121 303 250 121 303 minecraft:sandstone
setblock 248 121 306 minecraft:orange_terracotta
fill 248 121 307 250 121 307 minecraft:sandstone
setblock 248 121 310 minecraft:orange_terracotta
fill 248 121 311 250 121 311 minecraft:sandstone
setblock 248 121 314 minecraft:orange_terracotta
fill 248 121 315 250 121 315 minecraft:sandstone
fill 248 121 317 248 124 317 minecraft:smooth_sandstone
setblock 249 121 276 minecraft:sandstone
setblock 249 121 277 minecraft:orange_terracotta
fill 249 121 278 249 121 280 minecraft:sandstone
setblock 249 121 281 minecraft:orange_terracotta
fill 249 121 282 251 121 282 minecraft:sandstone
setblock 249 121 285 minecraft:orange_terracotta
fill 249 121 286 249 121 288 minecraft:sandstone
setblock 249 121 289 minecraft:orange_terracotta
fill 249 121 290 251 121 290 minecraft:sandstone
setblock 249 121 293 minecraft:orange_terracotta
setblock 249 121 301 minecraft:orange_terracotta
fill 249 121 302 251 121 302 minecraft:sandstone
setblock 249 121 305 minecraft:orange_terracotta
fill 249 121 306 251 121 306 minecraft:sandstone
setblock 249 121 309 minecraft:orange_terracotta
fill 249 121 310 251 121 310 minecraft:sandstone
setblock 249 121 313 minecraft:orange_terracotta
fill 249 121 314 251 121 314 minecraft:sandstone
setblock 249 121 317 minecraft:sandstone
setblock 250 121 276 minecraft:orange_terracotta
fill 250 121 277 250 121 279 minecraft:sandstone
setblock 250 121 280 minecraft:orange_terracotta
fill 250 121 281 252 121 281 minecraft:sandstone
setblock 250 121 284 minecraft:orange_terracotta
fill 250 121 285 250 121 287 minecraft:sandstone
setblock 250 121 288 minecraft:orange_terracotta
fill 250 121 289 252 121 289 minecraft:sandstone
setblock 250 121 292 minecraft:orange_terracotta
setblock 250 121 293 minecraft:sandstone
setblock 250 121 300 minecraft:orange_terracotta
fill 250 121 301 252 121 301 minecraft:sandstone
setblock 250 121 304 minecraft:orange_terracotta
fill 250 121 305 252 121 305 minecraft:sandstone
setblock 250 121 308 minecraft:orange_terracotta
fill 250 121 309 252 121 309 minecraft:sandstone
setblock 250 121 312 minecraft:orange_terracotta
fill 250 121 313 252 121 313 minecraft:sandstone
setblock 250 121 316 minecraft:orange_terracotta
fill 251 121 276 251 121 278 minecraft:sandstone
setblock 251 121 279 minecraft:orange_terracotta
fill 251 121 280 253 121 280 minecraft:sandstone
setblock 251 121 283 minecraft:orange_terracotta
fill 251 121 284 251 121 286 minecraft:sandstone
setblock 251 121 287 minecraft:orange_terracotta
fill 251 121 288 253 121 288 minecraft:sandstone
setblock 251 121 291 minecraft:orange_terracotta
setblock 251 121 292 minecraft:sandstone
fill 251 121 293 251 121 294 minecraft:gold_block
fill 251 121 298 251 121 299 minecraft:gold_block
setblock 251 121 300 minecraft:sandstone
setblock 251 121 303 minecraft:orange_terracotta
fill 251 121 304 253 121 304 minecraft:sandstone
setblock 251 121 307 minecraft:orange_terracotta
fill 251 121 308 253 121 308 minecraft:sandstone
setblock 251 121 311 minecraft:orange_terracotta
fill 251 121 312 253 121 312 minecraft:sandstone
setblock 251 121 315 minecraft:orange_terracotta
fill 251 121 316 253 121 316 minecraft:sandstone
fill 252 121 276 252 121 277 minecraft:sandstone
setblock 252 121 278 minecraft:orange_terracotta
fill 252 121 279 254 121 279 minecraft:sandstone
setblock 252 121 282 minecraft:orange_terracotta
fill 252 121 283 252 121 285 minecraft:sandstone
setblock 252 121 286 minecraft:orange_terracotta
fill 252 121 287 254 121 287 minecraft:sandstone
setblock 252 121 290 minecraft:orange_terracotta
setblock 252 121 291 minecraft:sandstone
setblock 252 121 292 minecraft:gold_block
fill 252 121 293 252 121 294 minecraft:lapis_block
fill 252 121 295 252 121 297 minecraft:gold_block
fill 252 121 298 252 121 299 minecraft:lapis_block
setblock 252 121 300 minecraft:gold_block
setblock 252 121 302 minecraft:orange_terracotta
fill 252 121 303 254 121 303 minecraft:sandstone
setblock 252 121 306 minecraft:orange_terracotta
fill 252 121 307 254 121 307 minecraft:sandstone
setblock 252 121 310 minecraft:orange_terracotta
fill 252 121 311 254 121 311 minecraft:sandstone
setblock 252 121 314 minecraft:orange_terracotta
fill 252 121 315 254 121 315 minecraft:sandstone
setblock 253 121 276 minecraft:sandstone
setblock 253 121 277 minecraft:orange_terracotta
fill 253 121 278 255 121 278 minecraft:sandstone
setblock 253 121 281 minecraft:orange_terracotta
fill 253 121 282 253 121 284 minecraft:sandstone
setblock 253 121 285 minecraft:orange_terracotta
fill 253 121 286 255 121 286 minecraft:sandstone
setblock 253 121 289 minecraft:orange_terracotta
fill 253 121 290 255 121 290 minecraft:sandstone
fill 253 121 291 255 121 291 minecraft:gold_block
fill 253 121 292 254 121 292 minecraft:lapis_block
fill 253 121 293 253 121 295 minecraft:gold_block
fill 253 121 297 253 121 299 minecraft:gold_block
fill 253 121 300 254 121 300 minecraft:lapis_block
fill 253 121 301 255 121 301 minecraft:gold_block
fill 253 121 302 255 121 302 minecraft:sandstone
setblock 253 121 305 minecraft:orange_terracotta
fill 253 121 306 255 121 306 minecraft:sandstone
setblock 253 121 309 minecraft:orange_terracotta
fill 253 121 310 255 121 310 minecraft:sandstone
setblock 253 121 313 minecraft:orange_terracotta
fill 253 121 314 255 121 314 minecraft:sandstone
setblock 254 121 276 minecraft:orange_terracotta
fill 254 121 277 256 121 277 minecraft:sandstone
setblock 254 121 280 minecraft:orange_terracotta
fill 254 121 281 254 121 283 minecraft:sandstone
setblock 254 121 284 minecraft:orange_terracotta
fill 254 121 285 256 121 285 minecraft:sandstone
setblock 254 121 288 minecraft:orange_terracotta
fill 254 121 289 256 121 289 minecraft:sandstone
fill 254 121 293 255 121 293 minecraft:gold_block
fill 254 121 299 255 121 299 minecraft:gold_block
setblock 254 121 304 minecraft:orange_terracotta
fill 254 121 305 256 121 305 minecraft:sandstone
setblock 254 121 308 minecraft:orange_terracotta
fill 254 121 309 256 121 309 minecraft:sandstone
setblock 254 121 312 minecraft:orange_terracotta
fill 254 121 313 256 121 313 minecraft:sandstone
setblock 254 121 316 minecraft:orange_terracotta
fill 255 121 276 257 121 276 minecraft:sandstone
setblock 255 121 279 minecraft:orange_terracotta
fill 255 121 280 255 121 282 minecraft:sandstone
setblock 255 121 283 minecraft:orange_terracotta
fill 255 121 284 257 121 284 minecraft:sandstone
setblock 255 121 287 minecraft:orange_terracotta
fill 255 121 288 257 121 288 minecraft:sandstone
fill 255 121 292 257 121 292 minecraft:gold_block
fill 255 121 300 257 121 300 minecraft:gold_block
setblock 255 121 303 minecraft:orange_terracotta
fill 255 121 304 257 121 304 minecraft:sandstone
setblock 255 121 307 minecraft:orange_terracotta
fill 255 121 308 257 121 308 minecraft:sandstone
setblock 255 121 311 minecraft:orange_terracotta
fill 255 121 312 257 121 312 minecraft:sandstone
setblock 255 121 315 minecraft:orange_terracotta
fill 255 121 316 257 121 316 minecraft:sandstone
setblock 256 121 278 minecraft:orange_terracotta
fill 256 121 279 256 121 281 minecraft:sandstone
setblock 256 121 282 minecraft:orange_terracotta
fill 256 121 283 258 121 283 minecraft:sandstone
setblock 256 121 286 minecraft:orange_terracotta
fill 256 121 287 258 121 287 minecraft:sandstone
setblock 256 121 291 minecraft:lapis_block
setblock 256 121 301 minecraft:lapis_block
fill 256 121 303 258 121 303 minecraft:sandstone
setblock 256 121 306 minecraft:orange_terracotta
fill 256 121 307 258 121 307 minecraft:sandstone
setblock 256 121 310 minecraft:orange_terracotta
fill 256 121 311 258 121 311 minecraft:sandstone
setblock 256 121 314 minecraft:orange_terracotta
fill 256 121 315 258 121 315 minecraft:sandstone
setblock 257 121 277 minecraft:orange_terracotta
fill 257 121 278 257 121 280 minecraft:sandstone
setblock 257 121 281 minecraft:orange_terracotta
fill 257 121 282 259 121 282 minecraft:sandstone
setblock 257 121 285 minecraft:orange_terracotta
fill 257 121 286 259 121 286 minecraft:sandstone
setblock 257 121 289 minecraft:orange_terracotta
fill 257 121 290 259 121 290 minecraft:sandstone
fill 257 121 291 259 121 291 minecraft:gold_block
fill 257 121 293 259 121 293 minecraft:gold_block
fill 257 121 299 259 121 299 minecraft:gold_block
fill 257 121 301 259 121 301 minecraft:gold_block
fill 257 121 302 259 121 302 minecraft:sandstone
setblock 257 121 305 minecraft:orange_terracotta
fill 257 121 306 259 121 306 minecraft:sandstone
setblock 257 121 309 minecraft:orange_terracotta
fill 257 121 310 259 121 310 minecraft:sandstone
setblock 257 121 313 minecraft:orange_terracotta
fill 257 121 314 259 121 314 minecraft:sandstone
fill 257 121 317 257 122 317 minecraft:smooth_sandstone
setblock 258 121 276 minecraft:orange_terracotta
fill 258 121 277 258 121 279 minecraft:sandstone
setblock 258 121 280 minecraft:orange_terracotta
fill 258 121 281 260 121 281 minecraft:sandstone
setblock 258 121 284 minecraft:orange_terracotta
fill 258 121 285 260 121 285 minecraft:sandstone
setblock 258 121 288 minecraft:orange_terracotta
fill 258 121 289 260 121 289 minecraft:sandstone
fill 258 121 292 259 121 292 minecraft:lapis_block
fill 258 121 300 259 121 300 minecraft:lapis_block
setblock 258 121 304 minecraft:orange_terracotta
fill 258 121 305 260 121 305 minecraft:sandstone
setblock 258 121 308 minecraft:orange_terracotta
fill 258 121 309 260 121 309 minecraft:sandstone
setblock 258 121 312 minecraft:orange_terracotta
fill 258 121 313 260 121 313 minecraft:sandstone
setblock 258 121 316 minecraft:orange_terracotta
setblock 258 121 317 minecraft:sandstone
fill 259 121 275 259 121 278 minecraft:sandstone
setblock 259 121 279 minecraft:orange_terracotta
fill 259 121 280 261 121 280 minecraft:sandstone
setblock 259 121 283 minecraft:orange_terracotta
fill 259 121 284 261 121 284 minecraft:sandstone
setblock 259 121 287 minecraft:orange_terracotta
fill 259 121 288 261 121 288 minecraft:sandstone
fill 259 121 294 259 121 295 minecraft:gold_block
fill 259 121 297 259 121 298 minecraft:gold_block
setblock 259 121 303 minecraft:orange_terracotta
fill 259 121 304 261 121 304 minecraft:sandstone
setblock 259 121 307 minecraft:orange_terracotta
fill 259 121 308 261 121 308 minecraft:sandstone
setblock 259 121 311 minecraft:orange_terracotta
fill 259 121 312 261 121 312 minecraft:sandstone
setblock 259 121 315 minecraft:orange_terracotta
fill 259 121 316 261 121 316 minecraft:sandstone
fill 260 121 275 263 124 275 minecraft:smooth_sandstone
fill 260 121 276 260 121 277 minecraft:sandstone
setblock 260 121 278 minecraft:orange_terracotta
fill 260 121 279 262 121 279 minecraft:sandstone
setblock 260 121 282 minecraft:orange_terracotta
fill 260 121 283 262 121 283 minecraft:sandstone
setblock 260 121 286 minecraft:orange_terracotta
fill 260 121 287 262 121 287 minecraft:sandstone
setblock 260 121 290 minecraft:orange_terracotta
fill 260 121 291 262 121 291 minecraft:sandstone
setblock 260 121 292 minecraft:gold_block
fill 260 121 293 260 121 294 minecraft:lapis_block
fill 260 121 295 260 121 297 minecraft:gold_block
fill 260 121 298 260 121 299 minecraft:lapis_block
setblock 260 121 300 minecraft:gold_block
setblock 260 121 301 minecraft:sandstone
setblock 260 121 302 minecraft:orange_terracotta
fill 260 121 303 262 121 303 minecraft:sandstone
setblock 260 121 306 minecraft:orange_terracotta
fill 260 121 307 262 121 307 minecraft:sandstone
setblock 260 121 310 minecraft:orange_terracotta
fill 260 121 311 262 121 311 minecraft:sandstone
setblock 260 121 314 minecraft:orange_terracotta
fill 260 121 315 262 121 315 minecraft:sandstone
setblock 261 121 276 minecraft:sandstone
setblock 261 121 277 minecraft:orange_terracotta
fill 261 121 278 263 121 278 minecraft:sandstone
setblock 261 121 281 minecraft:orange_terracotta
fill 261 121 282 263 121 282 minecraft:sandstone
setblock 261 121 285 minecraft:orange_terracotta
fill 261 121 286 263 121 286 minecraft:sandstone
setblock 261 121 289 minecraft:orange_terracotta
fill 261 121 290 263 121 290 minecraft:sandstone
setblock 261 121 292 minecraft:sandstone
fill 261 121 293 261 121 294 minecraft:gold_block
fill 261 121 296 268 121 296 minecraft:cyan_terracotta
fill 261 121 298 261 121 299 minecraft:gold_block
setblock 261 121 300 minecraft:sandstone
setblock 261 121 301 minecraft:orange_terracotta
fill 261 121 302 263 121 302 minecraft:sandstone
setblock 261 121 305 minecraft:orange_terracotta
fill 261 121 306 263 121 306 minecraft:sandstone
setblock 261 121 309 minecraft:orange_terracotta
fill 261 121 310 263 121 310 minecraft:sandstone
setblock 261 121 313 minecraft:orange_terracotta
fill 261 121 314 263 121 314 minecraft:sandstone
setblock 262 121 276 minecraft:orange_terracotta
fill 262 121 277 264 121 277 minecraft:sandstone
setblock 262 121 280 minecraft:orange_terracotta
fill 262 121 281 264 121 281 minecraft:sandstone
setblock 262 121 284 minecraft:orange_terracotta
fill 262 121 285 264 121 285 minecraft:sandstone
setblock 262 121 288 minecraft:orange_terracotta
fill 262 121 289 264 121 289 minecraft:sandstone
setblock 262 121 292 minecraft:orange_terracotta
fill 262 121 293 264 121 293 minecraft:sandstone
setblock 262 121 299 minecraft:sandstone
setblock 262 121 300 minecraft:orange_terracotta
fill 262 121 301 264 121 301 minecraft:sandstone
setblock 262 121 304 minecraft:orange_terracotta
fill 262 121 305 264 121 305 minecraft:sandstone
setblock 262 121 308 minecraft:orange_terracotta
fill 262 121 309 264 121 309 minecraft:sandstone
setblock 262 121 312 minecraft:orange_terracotta
fill 262 121 313 264 121 313 minecraft:sandstone
setblock 262 121 316 minecraft:orange_terracotta
fill 263 121 276 265 121 276 minecraft:sandstone
setblock 263 121 279 minecraft:orange_terracotta
fill 263 121 280 265 121 280 minecraft:sandstone
setblock 263 121 283 minecraft:orange_terracotta
fill 263 121 284 265 121 284 minecraft:sandstone
setblock 263 121 287 minecraft:orange_terracotta
fill 263 121 288 265 121 288 minecraft:sandstone
setblock 263 121 291 minecraft:orange_terracotta
fill 263 121 292 265 121 292 minecraft:sandstone
setblock 263 121 299 minecraft:orange_terracotta
fill 263 121 300 265 121 300 minecraft:sandstone
setblock 263 121 303 minecraft:orange_terracotta
fill 263 121 304 265 121 304 minecraft:sandstone
setblock 263 121 307 minecraft:orange_terracotta
fill 263 121 308 265 121 308 minecraft:sandstone
setblock 263 121 311 minecraft:orange_terracotta
fill 263 121 312 265 121 312 minecraft:sandstone
setblock 263 121 315 minecraft:orange_terracotta
fill 263 121 316 263 121 317 minecraft:sandstone
setblock 264 121 278 minecraft:orange_terracotta
fill 264 121 279 266 121 279 minecraft:sandstone
setblock 264 121 282 minecraft:orange_terracotta
fill 264 121 283 266 121 283 minecraft:sandstone
setblock 264 121 286 minecraft:orange_terracotta
fill 264 121 287 266 121 287 minecraft:sandstone
setblock 264 121 290 minecraft:orange_terracotta
fill 264 121 291 266 121 291 minecraft:sandstone
fill 264 121 299 266 121 299 minecraft:sandstone
setblock 264 121 302 minecraft:orange_terracotta
fill 264 121 303 266 121 303 minecraft:sandstone
setblock 264 121 306 minecraft:orange_terracotta
fill 264 121 307 266 121 307 minecraft:sandstone
setblock 264 121 310 minecraft:orange_terracotta
fill 264 121 311 266 121 311 minecraft:sandstone
setblock 264 121 314 minecraft:orange_terracotta
fill 264 121 315 265 121 316 minecraft:sandstone
setblock 265 121 277 minecraft:orange_terracotta
fill 265 121 278 267 121 278 minecraft:sandstone
setblock 265 121 281 minecraft:orange_terracotta
fill 265 121 282 267 121 282 minecraft:sandstone
setblock 265 121 285 minecraft:orange_terracotta
fill 265 121 286 267 121 286 minecraft:sandstone
setblock 265 121 289 minecraft:orange_terracotta
fill 265 121 290 267 121 290 minecraft:sandstone
setblock 265 121 293 minecraft:orange_terracotta
setblock 265 121 301 minecraft:orange_terracotta
fill 265 121 302 267 121 302 minecraft:sandstone
setblock 265 121 305 minecraft:orange_terracotta
fill 265 121 306 267 121 306 minecraft:sandstone
setblock 265 121 309 minecraft:orange_terracotta
fill 265 121 310 267 121 310 minecraft:sandstone
setblock 265 121 313 minecraft:orange_terracotta
fill 265 121 314 267 121 314 minecraft:sandstone
setblock 266 121 276 minecraft:orange_terracotta
fill 266 121 277 268 121 277 minecraft:sandstone
setblock 266 121 280 minecraft:orange_terracotta
fill 266 121 281 268 121 281 minecraft:sandstone
setblock 266 121 284 minecraft:orange_terracotta
fill 266 121 285 268 121 285 minecraft:sandstone
setblock 266 121 288 minecraft:orange_terracotta
fill 266 121 289 268 121 289 minecraft:sandstone
setblock 266 121 292 minecraft:orange_terracotta
fill 266 121 293 268 121 293 minecraft:sandstone
setblock 266 121 300 minecraft:orange_terracotta
fill 266 121 301 268 121 301 minecraft:sandstone
setblock 266 121 304 minecraft:orange_terracotta
fill 266 121 305 268 121 305 minecraft:sandstone
setblock 266 121 308 minecraft:orange_terracotta
fill 266 121 309 268 121 309 minecraft:sandstone
setblock 266 121 312 minecraft:orange_terracotta
fill 266 121 313 268 121 313 minecraft:sandstone
setblock 266 121 315 minecraft:sandstone
setblock 266 121 316 minecraft:orange_terracotta
fill 267 121 275 267 124 275 minecraft:smooth_sandstone
fill 267 121 276 269 121 276 minecraft:sandstone
setblock 267 121 279 minecraft:orange_terracotta
fill 267 121 280 269 121 280 minecraft:sandstone
setblock 267 121 283 minecraft:orange_terracotta
fill 267 121 284 269 121 284 minecraft:sandstone
setblock 267 121 287 minecraft:orange_terracotta
fill 267 121 288 269 121 288 minecraft:sandstone
setblock 267 121 291 minecraft:orange_terracotta
fill 267 121 292 269 121 292 minecraft:sandstone
setblock 267 121 294 minecraft:sandstone
setblock 267 121 298 minecraft:sandstone
setblock 267 121 299 minecraft:orange_terracotta
fill 267 121 300 269 121 300 minecraft:sandstone
setblock 267 121 303 minecraft:orange_terracotta
fill 267 121 304 269 121 304 minecraft:sandstone
setblock 267 121 307 minecraft:orange_terracotta
fill 267 121 308 269 121 308 minecraft:sandstone
setblock 267 121 311 minecraft:orange_terracotta
fill 267 121 312 269 121 312 minecraft:sandstone
setblock 267 121 315 minecraft:orange_terracotta
fill 267 121 316 267 121 317 minecraft:sandstone
setblock 268 121 275 minecraft:sandstone
setblock 268 121 278 minecraft:orange_terracotta
fill 268 121 279 270 121 279 minecraft:sandstone
setblock 268 121 282 minecraft:orange_terracotta
fill 268 121 283 270 121 283 minecraft:sandstone
setblock 268 121 286 minecraft:orange_terracotta
fill 268 121 287 270 121 287 minecraft:sandstone
setblock 268 121 290 minecraft:orange_terracotta
fill 268 121 291 270 121 291 minecraft:sandstone
setblock 268 121 294 minecraft:orange_terracotta
fill 268 121 295 270 121 295 minecraft:sandstone
setblock 268 121 297 minecraft:sandstone
setblock 268 121 298 minecraft:orange_terracotta
fill 268 121 299 270 121 299 minecraft:sandstone
setblock 268 121 302 minecraft:orange_terracotta
fill 268 121 303 270 121 303 minecraft:sandstone
setblock 268 121 306 minecraft:orange_terracotta
fill 268 121 307 270 121 307 minecraft:sandstone
setblock 268 121 310 minecraft:orange_terracotta
fill 268 121 311 270 121 311 minecraft:sandstone
setblock 268 121 314 minecraft:orange_terracotta
fill 268 121 315 269 121 316 minecraft:sandstone
setblock 269 121 277 minecraft:orange_terracotta
fill 269 121 278 271 121 278 minecraft:sandstone
setblock 269 121 281 minecraft:orange_terracotta
fill 269 121 282 271 121 282 minecraft:sandstone
setblock 269 121 285 minecraft:orange_terracotta
fill 269 121 286 271 121 286 minecraft:sandstone
setblock 269 121 289 minecraft:orange_terracotta
fill 269 121 290 271 121 290 minecraft:sandstone
setblock 269 121 293 minecraft:orange_terracotta
fill 269 121 294 271 121 294 minecraft:sandstone
setblock 269 121 296 minecraft:sandstone
setblock 269 121 297 minecraft:orange_terracotta
fill 269 121 298 271 121 298 minecraft:sandstone
setblock 269 121 301 minecraft:orange_terracotta
fill 269 121 302 271 121 302 minecraft:sandstone
setblock 269 121 305 minecraft:orange_terracotta
fill 269 121 306 271 121 306 minecraft:sandstone
setblock 269 121 309 minecraft:orange_terracotta
fill 269 121 310 271 121 310 minecraft:sandstone
setblock 269 121 313 minecraft:orange_terracotta
fill 269 121 314 271 121 314 minecraft:sandstone
setblock 270 121 276 minecraft:orange_terracotta
fill 270 121 277 272 121 277 minecraft:sandstone
setblock 270 121 280 minecraft:orange_terracotta
fill 270 121 281 272 121 281 minecraft:sandstone
setblock 270 121 284 minecraft:orange_terracotta
fill 270 121 285 272 121 285 minecraft:sandstone
setblock 270 121 288 minecraft:orange_terracotta
fill 270 121 289 272 121 289 minecraft:sandstone
setblock 270 121 292 minecraft:orange_terracotta
fill 270 121 293 272 121 293 minecraft:sandstone
setblock 270 121 296 minecraft:orange_terracotta
fill 270 121 297 272 121 297 minecraft:sandstone
setblock 270 121 300 minecraft:orange_terracotta
fill 270 121 301 272 121 301 minecraft:sandstone
setblock 270 121 304 minecraft:orange_terracotta
fill 270 121 305 272 121 305 minecraft:sandstone
setblock 270 121 308 minecraft:orange_terracotta
fill 270 121 309 272 121 309 minecraft:sandstone
setblock 270 121 312 minecraft:orange_terracotta
fill 270 121 313 272 121 313 minecraft:sandstone
setblock 270 121 315 minecraft:sandstone
setblock 270 121 316 minecraft:orange_terracotta
fill 271 121 276 273 121 276 minecraft:sandstone
setblock 271 121 279 minecraft:orange_terracotta
fill 271 121 280 273 121 280 minecraft:sandstone
setblock 271 121 283 minecraft:orange_terracotta
fill 271 121 284 273 121 284 minecraft:sandstone
setblock 271 121 287 minecraft:orange_terracotta
fill 271 121 288 273 121 288 minecraft:sandstone
setblock 271 121 291 minecraft:orange_terracotta
fill 271 121 292 273 121 292 minecraft:sandstone
setblock 271 121 295 minecraft:orange_terracotta
fill 271 121 296 273 121 296 minecraft:sandstone
setblock 271 121 299 minecraft:orange_terracotta
fill 271 121 300 273 121 300 minecraft:sandstone
setblock 271 121 303 minecraft:orange_terracotta
fill 271 121 304 273 121 304 minecraft:sandstone
setblock 271 121 307 minecraft:orange_terracotta
fill 271 121 308 273 121 308 minecraft:sandstone
setblock 271 121 311 minecraft:orange_terracotta
fill 271 121 312 273 121 312 minecraft:sandstone
setblock 271 121 315 minecraft:orange_terracotta
fill 271 121 316 273 121 316 minecraft:sandstone
setblock 272 121 278 minecraft:orange_terracotta
fill 272 121 279 274 121 279 minecraft:sandstone
setblock 272 121 282 minecraft:orange_terracotta
fill 272 121 283 274 121 283 minecraft:sandstone
setblock 272 121 286 minecraft:orange_terracotta
fill 272 121 287 274 121 287 minecraft:sandstone
setblock 272 121 290 minecraft:orange_terracotta
fill 272 121 291 274 121 291 minecraft:sandstone
setblock 272 121 294 minecraft:orange_terracotta
fill 272 121 295 274 121 295 minecraft:sandstone
setblock 272 121 298 minecraft:orange_terracotta
fill 272 121 299 274 121 299 minecraft:sandstone
setblock 272 121 302 minecraft:orange_terracotta
fill 272 121 303 274 121 303 minecraft:sandstone
setblock 272 121 306 minecraft:orange_terracotta
fill 272 121 307 274 121 307 minecraft:sandstone
setblock 272 121 310 minecraft:orange_terracotta
fill 272 121 311 274 121 311 minecraft:sandstone
setblock 272 121 314 minecraft:orange_terracotta
fill 272 121 315 274 121 315 minecraft:sandstone
fill 273 121 275 274 121 275 minecraft:sandstone
setblock 273 121 277 minecraft:orange_terracotta
fill 273 121 278 275 121 278 minecraft:sandstone
setblock 273 121 281 minecraft:orange_terracotta
fill 273 121 282 275 121 282 minecraft:sandstone
setblock 273 121 285 minecraft:orange_terracotta
fill 273 121 286 275 121 286 minecraft:sandstone
setblock 273 121 289 minecraft:orange_terracotta
fill 273 121 290 275 121 290 minecraft:sandstone
setblock 273 121 293 minecraft:orange_terracotta
fill 273 121 294 275 121 294 minecraft:sandstone
setblock 273 121 297 minecraft:orange_terracotta
fill 273 121 298 275 121 298 minecraft:sandstone
setblock 273 121 301 minecraft:orange_terracotta
fill 273 121 302 275 121 302 minecraft:sandstone
setblock 273 121 305 minecraft:orange_terracotta
fill 273 121 306 275 121 306 minecraft:sandstone
setblock 273 121 309 minecraft:orange_terracotta
fill 273 121 310 275 121 310 minecraft:sandstone
setblock 273 121 313 minecraft:orange_terracotta
fill 273 121 314 275 121 314 minecraft:sandstone
setblock 274 121 276 minecraft:orange_terracotta
fill 274 121 277 276 121 277 minecraft:sandstone
setblock 274 121 280 minecraft:orange_terracotta
fill 274 121 281 276 121 281 minecraft:sandstone
setblock 274 121 284 minecraft:orange_terracotta
fill 274 121 285 276 121 285 minecraft:sandstone
setblock 274 121 288 minecraft:orange_terracotta
fill 274 121 289 276 121 289 minecraft:sandstone
setblock 274 121 292 minecraft:orange_terracotta
fill 274 121 293 276 121 293 minecraft:sandstone
setblock 274 121 296 minecraft:orange_terracotta
fill 274 121 297 276 121 297 minecraft:sandstone
setblock 274 121 300 minecraft:orange_terracotta
fill 274 121 301 276 121 301 minecraft:sandstone
setblock 274 121 304 minecraft:orange_terracotta
fill 274 121 305 276 121 305 minecraft:sandstone
setblock 274 121 308 minecraft:orange_terracotta
fill 274 121 309 276 121 309 minecraft:sandstone
setblock 274 121 312 minecraft:orange_terracotta
fill 274 121 313 276 121 313 minecraft:sandstone
setblock 274 121 316 minecraft:orange_terracotta
fill 275 121 275 275 124 275 minecraft:smooth_sandstone
fill 275 121 276 276 121 276 minecraft:sandstone
setblock 275 121 279 minecraft:orange_terracotta
fill 275 121 280 276 121 280 minecraft:sandstone
setblock 275 121 283 minecraft:orange_terracotta
fill 275 121 284 276 121 284 minecraft:sandstone
setblock 275 121 287 minecraft:orange_terracotta
fill 275 121 288 276 121 288 minecraft:sandstone
setblock 275 121 291 minecraft:orange_terracotta
fill 275 121 292 276 121 292 minecraft:sandstone
setblock 275 121 295 minecraft:orange_terracotta
fill 275 121 296 276 121 296 minecraft:sandstone
setblock 275 121 299 minecraft:orange_terracotta
fill 275 121 300 276 121 300 minecraft:sandstone
setblock 275 121 303 minecraft:orange_terracotta
fill 275 121 304 276 121 304 minecraft:sandstone
setblock 275 121 307 minecraft:orange_terracotta
fill 275 121 308 276 121 308 minecraft:sandstone
setblock 275 121 311 minecraft:orange_terracotta
fill 275 121 312 276 121 312 minecraft:sandstone
setblock 275 121 315 minecraft:orange_terracotta
fill 275 121 316 276 121 316 minecraft:sandstone
setblock 276 121 278 minecraft:orange_terracotta
setblock 276 121 279 minecraft:sandstone
setblock 276 121 282 minecraft:orange_terracotta
setblock 276 121 283 minecraft:sandstone
setblock 276 121 286 minecraft:orange_terracotta
fill 276 121 287 277 121 287 minecraft:sandstone
setblock 276 121 290 minecraft:orange_terracotta
setblock 276 121 291 minecraft:sandstone
setblock 276 121 294 minecraft:orange_terracotta
setblock 276 121 295 minecraft:sandstone
setblock 276 121 298 minecraft:orange_terracotta
fill 276 121 299 277 121 299 minecraft:sandstone
setblock 276 121 302 minecraft:orange_terracotta
setblock 276 121 303 minecraft:sandstone
setblock 276 121 306 minecraft:orange_terracotta
setblock 276 121 307 minecraft:sandstone
setblock 276 121 310 minecraft:orange_terracotta
setblock 276 121 311 minecraft:sandstone
setblock 276 121 314 minecraft:orange_terracotta
setblock 276 121 315 minecraft:sandstone
setblock 277 121 282 minecraft:sandstone
setblock 235 122 278 minecraft:lapis_block
fill 235 122 279 235 124 279 minecraft:smooth_sandstone
setblock 235 122 288 minecraft:sandstone
fill 235 122 297 235 124 297 minecraft:smooth_sandstone
fill 235 122 305 235 124 305 minecraft:smooth_sandstone
setblock 235 122 312 minecraft:sandstone
fill 235 122 313 235 124 313 minecraft:smooth_sandstone
setblock 235 122 315 minecraft:sandstone
setblock 236 122 317 minecraft:sandstone
fill 237 122 317 237 124 317 minecraft:smooth_sandstone
setblock 238 122 278 minecraft:light[level=15]
setblock 238 122 286 minecraft:light[level=15]
setblock 238 122 294 minecraft:light[level=15]
setblock 238 122 302 minecraft:light[level=15]
setblock 238 122 310 minecraft:light[level=15]
fill 239 122 275 240 124 275 minecraft:smooth_sandstone
fill 241 122 317 242 122 317 minecraft:smooth_sandstone
fill 244 122 317 244 124 317 minecraft:smooth_sandstone
setblock 246 122 278 minecraft:light[level=15]
setblock 246 122 286 minecraft:light[level=15]
setblock 246 122 294 minecraft:light[level=15]
setblock 246 122 302 minecraft:light[level=15]
setblock 246 122 310 minecraft:light[level=15]
setblock 246 122 317 minecraft:sandstone
fill 249 122 317 249 124 317 minecraft:smooth_sandstone
fill 250 122 275 251 122 275 minecraft:sandstone
fill 251 122 317 252 122 317 minecraft:sandstone
setblock 254 122 278 minecraft:light[level=15]
setblock 254 122 286 minecraft:light[level=15]
setblock 254 122 302 minecraft:light[level=15]
setblock 254 122 310 minecraft:light[level=15]
fill 258 122 317 258 124 317 minecraft:smooth_sandstone
fill 259 122 275 259 123 275 minecraft:smooth_sandstone
setblock 262 122 278 minecraft:light[level=15]
setblock 262 122 286 minecraft:light[level=15]
setblock 262 122 294 minecraft:light[level=15]
setblock 262 122 302 minecraft:light[level=15]
setblock 262 122 310 minecraft:light[level=15]
fill 263 122 317 263 124 317 minecraft:smooth_sandstone
fill 264 122 275 264 123 275 minecraft:sandstone
setblock 265 122 317 minecraft:sandstone
fill 267 122 317 267 125 317 minecraft:smooth_sandstone
fill 268 122 275 268 124 275 minecraft:smooth_sandstone
setblock 270 122 278 minecraft:light[level=15]
setblock 270 122 286 minecraft:light[level=15]
setblock 270 122 294 minecraft:light[level=15]
setblock 270 122 302 minecraft:light[level=15]
setblock 270 122 310 minecraft:light[level=15]
setblock 272 122 275 minecraft:orange_terracotta
fill 273 122 275 274 124 275 minecraft:smooth_sandstone
setblock 276 122 317 minecraft:sandstone
setblock 277 122 280 minecraft:sandstone
fill 277 122 282 277 124 282 minecraft:smooth_sandstone
fill 277 122 287 277 124 287 minecraft:smooth_sandstone
setblock 277 122 290 minecraft:sandstone
fill 277 122 299 277 124 299 minecraft:smooth_sandstone
fill 277 122 302 277 123 302 minecraft:sandstone
fill 235 123 278 235 125 278 minecraft:smooth_sandstone
fill 235 123 282 235 124 282 minecraft:smooth_sandstone
setblock 235 123 283 minecraft:sandstone
fill 235 123 288 235 124 288 minecraft:smooth_sandstone
fill 235 123 293 235 123 294 minecraft:sandstone
fill 235 123 295 235 124 295 minecraft:smooth_sandstone
setblock 235 123 298 minecraft:sandstone
fill 235 123 306 235 124 306 minecraft:smooth_sandstone
setblock 235 123 307 minecraft:sandstone
fill 235 123 312 235 124 312 minecraft:smooth_sandstone
setblock 235 123 314 minecraft:sandstone
fill 235 123 315 235 125 315 minecraft:smooth_sandstone
setblock 236 123 317 minecraft:smooth_sandstone
fill 241 123 317 241 124 317 minecraft:smooth_sandstone
setblock 242 123 317 minecraft:lapis_block
fill 243 123 275 243 125 275 minecraft:smooth_sandstone
setblock 244 123 275 minecraft:sandstone
fill 245 123 275 245 124 275 minecraft:smooth_sandstone
fill 246 123 317 246 124 317 minecraft:smooth_sandstone
setblock 249 123 275 minecraft:sandstone
fill 250 123 275 250 124 275 minecraft:smooth_sandstone
setblock 251 123 275 minecraft:sandstone
fill 251 123 317 252 124 317 minecraft:smooth_sandstone
setblock 257 123 317 minecraft:sandstone
fill 265 123 317 265 124 317 minecraft:smooth_sandstone
setblock 266 123 317 minecraft:sandstone
setblock 270 123 317 minecraft:sandstone
fill 272 123 275 272 124 275 minecraft:smooth_sandstone
fill 272 123 317 272 124 317 minecraft:smooth_sandstone
setblock 273 123 317 minecraft:sandstone
fill 276 123 317 276 124 317 minecraft:smooth_sandstone
setblock 277 123 276 minecraft:lapis_block
setblock 277 123 277 minecraft:sandstone
fill 277 123 278 277 124 278 minecraft:smooth_sandstone
fill 277 123 280 277 124 280 minecraft:smooth_sandstone
fill 277 123 290 277 124 290 minecraft:smooth_sandstone
setblock 277 123 295 minecraft:sandstone
setblock 235 124 281 minecraft:lapis_block
setblock 235 124 283 minecraft:blue_terracotta
fill 235 124 293 235 124 294 minecraft:smooth_sandstone
setblock 235 124 298 minecraft:smooth_sandstone
setblock 235 124 307 minecraft:smooth_sandstone
setblock 235 124 314 minecraft:smooth_sandstone
fill 235 124 317 235 125 317 minecraft:smooth_sandstone
setblock 236 124 317 minecraft:lapis_block
setblock 238 124 278 minecraft:light[level=12]
setblock 238 124 285 minecraft:light[level=12]
setblock 238 124 292 minecraft:light[level=12]
setblock 238 124 299 minecraft:light[level=12]
setblock 238 124 306 minecraft:light[level=12]
setblock 238 124 313 minecraft:light[level=12]
setblock 242 124 317 minecraft:smooth_sandstone
setblock 244 124 275 minecraft:smooth_sandstone
setblock 245 124 278 minecraft:light[level=12]
setblock 245 124 285 minecraft:light[level=12]
setblock 245 124 292 minecraft:light[level=12]
setblock 245 124 299 minecraft:light[level=12]
setblock 245 124 306 minecraft:light[level=12]
setblock 245 124 313 minecraft:light[level=12]
setblock 249 124 275 minecraft:smooth_sandstone
setblock 251 124 275 minecraft:smooth_sandstone
setblock 252 124 278 minecraft:light[level=12]
setblock 252 124 285 minecraft:light[level=12]
setblock 252 124 292 minecraft:light[level=12]
setblock 252 124 299 minecraft:light[level=12]
setblock 252 124 306 minecraft:light[level=12]
setblock 252 124 313 minecraft:light[level=12]
setblock 257 124 317 minecraft:smooth_sandstone
setblock 259 124 275 minecraft:lapis_block
setblock 259 124 278 minecraft:light[level=12]
setblock 259 124 285 minecraft:light[level=12]
setblock 259 124 292 minecraft:light[level=12]
setblock 259 124 299 minecraft:light[level=12]
setblock 259 124 306 minecraft:light[level=12]
setblock 259 124 313 minecraft:light[level=12]
setblock 264 124 275 minecraft:smooth_sandstone
setblock 266 124 278 minecraft:light[level=12]
setblock 266 124 285 minecraft:light[level=12]
setblock 266 124 292 minecraft:light[level=12]
setblock 266 124 299 minecraft:light[level=12]
setblock 266 124 306 minecraft:light[level=12]
setblock 266 124 313 minecraft:light[level=12]
setblock 266 124 317 minecraft:smooth_sandstone
setblock 270 124 317 minecraft:smooth_sandstone
setblock 273 124 278 minecraft:light[level=12]
setblock 273 124 285 minecraft:light[level=12]
setblock 273 124 292 minecraft:light[level=12]
setblock 273 124 299 minecraft:light[level=12]
setblock 273 124 306 minecraft:light[level=12]
setblock 273 124 313 minecraft:light[level=12]
setblock 273 124 317 minecraft:smooth_sandstone
fill 277 124 276 277 124 277 minecraft:smooth_sandstone
setblock 277 124 295 minecraft:smooth_sandstone
setblock 277 124 302 minecraft:smooth_sandstone
fill 235 125 275 235 126 277 minecraft:sandstone
fill 235 125 279 235 125 307 minecraft:sandstone
fill 235 125 310 235 213 310 minecraft:sandstone
fill 235 125 312 235 192 314 minecraft:sandstone
fill 235 125 316 235 180 316 minecraft:sandstone
fill 236 125 275 242 125 275 minecraft:sandstone
fill 236 125 276 238 203 276 minecraft:cut_sandstone
fill 236 125 279 236 125 284 minecraft:chiseled_sandstone
fill 236 125 286 236 203 288 minecraft:cut_sandstone
fill 236 125 290 242 126 290 minecraft:cut_sandstone
fill 236 125 291 236 125 296 minecraft:chiseled_sandstone
fill 236 125 297 242 126 302 minecraft:cut_sandstone
fill 236 125 303 236 125 308 minecraft:chiseled_sandstone
fill 236 125 310 236 203 312 minecraft:cut_sandstone
fill 236 125 315 236 125 316 minecraft:chiseled_sandstone
fill 236 125 317 249 125 317 minecraft:sandstone
fill 237 125 285 237 125 287 minecraft:cut_sandstone
fill 237 125 291 242 126 296 minecraft:cut_sandstone
fill 237 125 303 237 125 311 minecraft:cut_sandstone
fill 237 125 316 240 125 316 minecraft:chiseled_sandstone
fill 238 125 303 242 126 308 minecraft:cut_sandstone
fill 240 125 276 245 125 276 minecraft:chiseled_sandstone
fill 242 125 316 244 203 316 minecraft:cut_sandstone
fill 243 125 315 245 125 315 minecraft:cut_sandstone
fill 244 125 275 261 125 275 minecraft:sandstone
fill 247 125 277 249 125 277 minecraft:cut_sandstone
fill 247 125 316 252 125 316 minecraft:chiseled_sandstone
fill 248 125 276 250 203 276 minecraft:cut_sandstone
fill 251 125 317 252 151 317 minecraft:sandstone
fill 252 125 276 257 125 276 minecraft:chiseled_sandstone
fill 254 125 316 256 203 316 minecraft:cut_sandstone
fill 254 125 317 258 125 317 minecraft:sandstone
fill 255 125 315 257 125 315 minecraft:cut_sandstone
fill 259 125 277 261 125 277 minecraft:cut_sandstone
fill 259 125 316 264 125 316 minecraft:chiseled_sandstone
fill 260 125 276 262 203 276 minecraft:cut_sandstone
setblock 260 125 317 minecraft:sandstone
setblock 261 125 317 minecraft:smooth_sandstone
setblock 262 125 275 minecraft:orange_terracotta
fill 262 125 317 266 125 317 minecraft:sandstone
fill 263 125 275 270 125 275 minecraft:sandstone
fill 264 125 276 269 125 276 minecraft:chiseled_sandstone
fill 266 125 316 268 203 316 minecraft:cut_sandstone
fill 267 125 281 275 126 291 minecraft:cut_sandstone
fill 267 125 315 269 125 315 minecraft:cut_sandstone
fill 268 125 317 277 125 317 minecraft:sandstone
fill 271 125 277 273 125 277 minecraft:cut_sandstone
setblock 271 125 302 minecraft:glowstone
fill 271 125 316 276 125 316 minecraft:chiseled_sandstone
fill 272 125 275 277 125 275 minecraft:sandstone
fill 272 125 276 274 203 276 minecraft:cut_sandstone
fill 275 125 297 275 125 299 minecraft:cut_sandstone
fill 275 125 309 275 125 311 minecraft:cut_sandstone
fill 276 125 276 276 125 281 minecraft:chiseled_sandstone
fill 276 125 282 276 126 287 minecraft:cut_sandstone
fill 276 125 288 276 125 293 minecraft:chiseled_sandstone
fill 276 125 296 276 203 298 minecraft:cut_sandstone
fill 276 125 300 276 125 305 minecraft:chiseled_sandstone
fill 276 125 308 276 203 310 minecraft:cut_sandstone
fill 276 125 312 276 125 315 minecraft:chiseled_sandstone
fill 277 125 276 277 125 290 minecraft:sandstone
fill 277 125 292 277 125 303 minecraft:sandstone
fill 277 125 305 277 145 306 minecraft:sandstone
fill 277 125 308 277 125 316 minecraft:sandstone
fill 235 126 278 235 126 280 minecraft:sandstone
fill 235 126 281 235 131 284 minecraft:glowstone
fill 235 126 285 235 126 287 minecraft:sandstone
setblock 235 126 288 minecraft:smooth_sandstone
fill 235 126 289 235 134 291 minecraft:sandstone
setblock 235 126 292 minecraft:blue_terracotta
fill 235 126 293 235 131 296 minecraft:glowstone
fill 235 126 297 235 174 299 minecraft:sandstone
fill 235 126 300 235 127 300 minecraft:smooth_sandstone
fill 235 126 301 235 134 302 minecraft:sandstone
setblock 235 126 303 minecraft:lapis_block
fill 235 126 304 235 178 304 minecraft:sandstone
fill 235 126 305 235 131 308 minecraft:glowstone
fill 235 126 309 235 216 309 minecraft:sandstone
fill 235 126 311 235 216 311 minecraft:sandstone
fill 235 126 315 235 160 315 minecraft:sandstone
fill 235 126 317 238 131 317 minecraft:glowstone
fill 236 126 275 241 126 275 minecraft:sandstone
fill 236 126 291 236 126 296 minecraft:cut_sandstone
fill 236 126 303 237 126 308 minecraft:cut_sandstone
fill 239 126 317 246 126 317 minecraft:sandstone
fill 242 126 275 245 131 275 minecraft:glowstone
fill 246 126 275 250 126 275 minecraft:sandstone
fill 247 126 317 250 131 317 minecraft:glowstone
fill 251 126 275 252 126 275 minecraft:smooth_sandstone
fill 253 126 275 253 212 275 minecraft:sandstone
fill 253 126 317 253 129 317 minecraft:sandstone
fill 254 126 275 257 131 275 minecraft:glowstone
fill 254 126 317 256 126 317 minecraft:smooth_sandstone
fill 257 126 317 258 160 317 minecraft:sandstone
fill 258 126 275 265 126 275 minecraft:sandstone
fill 259 126 317 262 131 317 minecraft:glowstone
fill 263 126 317 266 126 317 minecraft:sandstone
fill 266 126 275 269 131 275 minecraft:glowstone
setblock 267 126 317 minecraft:black_terracotta
fill 268 126 317 270 126 317 minecraft:sandstone
fill 270 126 275 270 143 275 minecraft:sandstone
fill 271 126 317 274 131 317 minecraft:glowstone
fill 272 126 275 273 126 275 minecraft:smooth_sandstone
fill 274 126 275 277 126 275 minecraft:sandstone
fill 275 126 317 276 126 317 minecraft:sandstone
fill 276 126 281 276 139 281 minecraft:cut_sandstone
fill 276 126 288 276 126 291 minecraft:cut_sandstone
fill 277 126 276 277 131 279 minecraft:glowstone
fill 277 126 280 277 132 281 minecraft:sandstone
setblock 277 126 282 minecraft:smooth_sandstone
fill 277 126 283 277 129 287 minecraft:sandstone
fill 277 126 288 277 131 291 minecraft:glowstone
fill 277 126 292 277 126 299 minecraft:sandstone
fill 277 126 300 277 131 303 minecraft:glowstone
fill 277 126 308 277 146 311 minecraft:sandstone
fill 277 126 312 277 131 315 minecraft:glowstone
setblock 277 126 316 minecraft:black_terracotta
setblock 277 126 317 minecraft:smooth_sandstone
setblock 235 127 275 minecraft:smooth_sandstone
fill 235 127 276 235 139 278 minecraft:sandstone
setblock 235 127 279 minecraft:smooth_sandstone
fill 235 127 280 235 157 280 minecraft:sandstone
fill 235 127 285 235 216 285 minecraft:sandstone
setblock 235 127 286 minecraft:black_terracotta
fill 235 127 287 235 185 288 minecraft:sandstone
fill 235 127 292 235 193 292 minecraft:sandstone
fill 235 127 303 235 147 303 minecraft:sandstone
fill 236 127 275 237 195 275 minecraft:sandstone
setblock 236 127 290 minecraft:glowstone
fill 236 127 291 236 144 291 minecraft:cut_sandstone
setblock 236 127 292 minecraft:glowstone
fill 236 127 293 236 144 293 minecraft:cut_sandstone
setblock 236 127 294 minecraft:glowstone
fill 236 127 295 236 144 295 minecraft:cut_sandstone
setblock 236 127 296 minecraft:glowstone
fill 236 127 297 236 148 297 minecraft:cut_sandstone
setblock 236 127 298 minecraft:glowstone
fill 236 127 299 236 203 299 minecraft:cut_sandstone
setblock 236 127 300 minecraft:glowstone
fill 236 127 301 236 148 301 minecraft:cut_sandstone
setblock 236 127 302 minecraft:glowstone
fill 236 127 303 236 144 303 minecraft:cut_sandstone
setblock 236 127 304 minecraft:glowstone
fill 236 127 305 236 144 305 minecraft:cut_sandstone
setblock 236 127 306 minecraft:glowstone
fill 236 127 307 236 144 307 minecraft:cut_sandstone
setblock 236 127 308 minecraft:glowstone
fill 237 127 290 237 147 290 minecraft:cut_sandstone
setblock 237 127 291 minecraft:glowstone
fill 237 127 292 237 147 292 minecraft:cut_sandstone
setblock 237 127 293 minecraft:glowstone
fill 237 127 294 237 147 294 minecraft:cut_sandstone
setblock 237 127 295 minecraft:glowstone
fill 237 127 296 237 148 296 minecraft:cut_sandstone
setblock 237 127 297 minecraft:glowstone
fill 237 127 298 237 148 298 minecraft:cut_sandstone
setblock 237 127 299 minecraft:glowstone
fill 237 127 300 237 148 300 minecraft:cut_sandstone
setblock 237 127 301 minecraft:glowstone
fill 237 127 302 237 148 302 minecraft:cut_sandstone
setblock 237 127 303 minecraft:glowstone
fill 237 127 304 237 148 304 minecraft:cut_sandstone
setblock 237 127 305 minecraft:glowstone
fill 237 127 306 237 148 306 minecraft:cut_sandstone
setblock 237 127 307 minecraft:glowstone
fill 237 127 308 237 148 308 minecraft:cut_sandstone
setblock 238 127 275 minecraft:smooth_sandstone
setblock 238 127 290 minecraft:glowstone
fill 238 127 291 238 147 291 minecraft:cut_sandstone
setblock 238 127 292 minecraft:glowstone
fill 238 127 293 238 147 293 minecraft:cut_sandstone
setblock 238 127 294 minecraft:glowstone
fill 238 127 295 238 147 295 minecraft:cut_sandstone
setblock 238 127 296 minecraft:glowstone
fill 238 127 297 238 148 297 minecraft:cut_sandstone
setblock 238 127 298 minecraft:glowstone
fill 238 127 299 238 148 299 minecraft:cut_sandstone
setblock 238 127 300 minecraft:glowstone
fill 238 127 301 238 148 301 minecraft:cut_sandstone
setblock 238 127 302 minecraft:glowstone
fill 238 127 303 238 148 303 minecraft:cut_sandstone
setblock 238 127 304 minecraft:glowstone
fill 238 127 305 238 148 305 minecraft:cut_sandstone
setblock 238 127 306 minecraft:glowstone
fill 238 127 307 238 148 307 minecraft:cut_sandstone
setblock 238 127 308 minecraft:glowstone
fill 239 127 275 241 159 275 minecraft:sandstone
fill 239 127 290 239 147 290 minecraft:cut_sandstone
setblock 239 127 291 minecraft:glowstone
fill 239 127 292 239 147 292 minecraft:cut_sandstone
setblock 239 127 293 minecraft:glowstone
fill 239 127 294 239 147 294 minecraft:cut_sandstone
setblock 239 127 295 minecraft:glowstone
fill 239 127 296 239 148 296 minecraft:cut_sandstone
setblock 239 127 297 minecraft:glowstone
fill 239 127 298 239 148 298 minecraft:cut_sandstone
setblock 239 127 299 minecraft:glowstone
fill 239 127 300 239 148 300 minecraft:cut_sandstone
setblock 239 127 301 minecraft:glowstone
fill 239 127 302 239 148 302 minecraft:cut_sandstone
setblock 239 127 303 minecraft:glowstone
fill 239 127 304 239 148 304 minecraft:cut_sandstone
setblock 239 127 305 minecraft:glowstone
fill 239 127 306 239 148 306 minecraft:cut_sandstone
setblock 239 127 307 minecraft:glowstone
fill 239 127 308 239 148 308 minecraft:cut_sandstone
fill 239 127 317 243 127 317 minecraft:sandstone
setblock 240 127 290 minecraft:glowstone
fill 240 127 291 240 147 291 minecraft:cut_sandstone
setblock 240 127 292 minecraft:glowstone
fill 240 127 293 240 147 293 minecraft:cut_sandstone
setblock 240 127 294 minecraft:glowstone
fill 240 127 295 240 147 295 minecraft:cut_sandstone
setblock 240 127 296 minecraft:glowstone
fill 240 127 297 240 148 297 minecraft:cut_sandstone
setblock 240 127 298 minecraft:glowstone
fill 240 127 299 240 148 299 minecraft:cut_sandstone
setblock 240 127 300 minecraft:glowstone
fill 240 127 301 240 148 301 minecraft:cut_sandstone
setblock 240 127 302 minecraft:glowstone
fill 240 127 303 240 148 303 minecraft:cut_sandstone
setblock 240 127 304 minecraft:glowstone
fill 240 127 305 240 148 305 minecraft:cut_sandstone
setblock 240 127 306 minecraft:glowstone
fill 240 127 307 240 148 307 minecraft:cut_sandstone
setblock 240 127 308 minecraft:glowstone
fill 241 127 290 241 147 290 minecraft:cut_sandstone
setblock 241 127 291 minecraft:glowstone
fill 241 127 292 241 147 292 minecraft:cut_sandstone
setblock 241 127 293 minecraft:glowstone
fill 241 127 294 241 147 294 minecraft:cut_sandstone
setblock 241 127 295 minecraft:glowstone
fill 241 127 296 241 148 296 minecraft:cut_sandstone
setblock 241 127 297 minecraft:glowstone
fill 241 127 298 241 148 298 minecraft:cut_sandstone
setblock 241 127 299 minecraft:glowstone
fill 241 127 300 241 148 300 minecraft:cut_sandstone
setblock 241 127 301 minecraft:glowstone
fill 241 127 302 241 148 302 minecraft:cut_sandstone
setblock 241 127 303 minecraft:glowstone
fill 241 127 304 241 148 304 minecraft:cut_sandstone
setblock 241 127 305 minecraft:glowstone
fill 241 127 306 241 148 306 minecraft:cut_sandstone
setblock 241 127 307 minecraft:glowstone
fill 241 127 308 241 148 308 minecraft:cut_sandstone
setblock 242 127 290 minecraft:glowstone
fill 242 127 291 242 147 291 minecraft:cut_sandstone
setblock 242 127 292 minecraft:glowstone
fill 242 127 293 242 147 293 minecraft:cut_sandstone
setblock 242 127 294 minecraft:glowstone
fill 242 127 295 242 147 295 minecraft:cut_sandstone
setblock 242 127 296 minecraft:glowstone
fill 242 127 297 242 148 297 minecraft:cut_sandstone
setblock 242 127 298 minecraft:glowstone
fill 242 127 299 242 148 299 minecraft:cut_sandstone
setblock 242 127 300 minecraft:glowstone
fill 242 127 301 242 148 301 minecraft:cut_sandstone
setblock 242 127 302 minecraft:glowstone
fill 242 127 303 242 148 303 minecraft:cut_sandstone
setblock 242 127 304 minecraft:glowstone
fill 242 127 305 242 148 305 minecraft:cut_sandstone
setblock 242 127 306 minecraft:glowstone
fill 242 127 307 242 148 307 minecraft:cut_sandstone
setblock 242 127 308 minecraft:glowstone
setblock 244 127 317 minecraft:smooth_sandstone
fill 245 127 317 246 140 317 minecraft:sandstone
fill 246 127 275 248 154 275 minecraft:sandstone
fill 246 127 311 246 130 311 minecraft:iron_block
setblock 249 127 275 minecraft:blue_terracotta
fill 250 127 275 250 216 275 minecraft:sandstone
setblock 251 127 275 minecraft:smooth_sandstone
fill 252 127 275 252 216 275 minecraft:sandstone
fill 254 127 317 256 140 317 minecraft:sandstone
fill 258 127 275 264 128 275 minecraft:sandstone
fill 263 127 317 264 175 317 minecraft:sandstone
setblock 265 127 275 minecraft:smooth_sandstone
setblock 265 127 317 minecraft:smooth_sandstone
fill 266 127 317 268 135 317 minecraft:sandstone
setblock 267 127 281 minecraft:glowstone
fill 267 127 282 267 139 282 minecraft:cut_sandstone
setblock 267 127 283 minecraft:glowstone
fill 267 127 284 267 139 284 minecraft:cut_sandstone
setblock 267 127 285 minecraft:glowstone
fill 267 127 286 267 139 286 minecraft:cut_sandstone
setblock 267 127 287 minecraft:glowstone
fill 267 127 288 267 139 288 minecraft:cut_sandstone
setblock 267 127 289 minecraft:glowstone
fill 267 127 290 267 139 290 minecraft:cut_sandstone
setblock 267 127 291 minecraft:glowstone
fill 268 127 281 268 139 281 minecraft:cut_sandstone
setblock 268 127 282 minecraft:glowstone
fill 268 127 283 268 139 283 minecraft:cut_sandstone
setblock 268 127 284 minecraft:glowstone
fill 268 127 285 268 139 285 minecraft:cut_sandstone
setblock 268 127 286 minecraft:glowstone
fill 268 127 287 268 139 287 minecraft:cut_sandstone
setblock 268 127 288 minecraft:glowstone
fill 268 127 289 268 139 289 minecraft:cut_sandstone
setblock 268 127 290 minecraft:glowstone
fill 268 127 291 268 139 291 minecraft:cut_sandstone
setblock 269 127 281 minecraft:glowstone
fill 269 127 282 269 139 282 minecraft:cut_sandstone
setblock 269 127 283 minecraft:glowstone
fill 269 127 284 269 139 284 minecraft:cut_sandstone
setblock 269 127 285 minecraft:glowstone
fill 269 127 286 269 139 286 minecraft:cut_sandstone
setblock 269 127 287 minecraft:glowstone
fill 269 127 288 269 139 288 minecraft:cut_sandstone
setblock 269 127 289 minecraft:glowstone
fill 269 127 290 269 139 290 minecraft:cut_sandstone
setblock 269 127 291 minecraft:glowstone
setblock 269 127 317 minecraft:smooth_sandstone
fill 270 127 281 270 139 281 minecraft:cut_sandstone
setblock 270 127 282 minecraft:glowstone
fill 270 127 283 270 139 283 minecraft:cut_sandstone
setblock 270 127 284 minecraft:glowstone
fill 270 127 285 270 139 285 minecraft:cut_sandstone
setblock 270 127 286 minecraft:glowstone
fill 270 127 287 270 139 287 minecraft:cut_sandstone
setblock 270 127 288 minecraft:glowstone
fill 270 127 289 270 139 289 minecraft:cut_sandstone
setblock 270 127 290 minecraft:glowstone
fill 270 127 291 270 139 291 minecraft:cut_sandstone
setblock 270 127 317 minecraft:blue_terracotta
fill 271 127 275 276 130 275 minecraft:sandstone
setblock 271 127 281 minecraft:glowstone
fill 271 127 282 271 139 282 minecraft:cut_sandstone
setblock 271 127 283 minecraft:glowstone
fill 271 127 284 271 139 284 minecraft:cut_sandstone
setblock 271 127 285 minecraft:glowstone
fill 271 127 286 271 139 286 minecraft:cut_sandstone
setblock 271 127 287 minecraft:glowstone
fill 271 127 288 271 139 288 minecraft:cut_sandstone
setblock 271 127 289 minecraft:glowstone
fill 271 127 290 271 139 290 minecraft:cut_sandstone
setblock 271 127 291 minecraft:glowstone
fill 272 127 281 272 139 281 minecraft:cut_sandstone
setblock 272 127 282 minecraft:glowstone
fill 272 127 283 272 139 283 minecraft:cut_sandstone
setblock 272 127 284 minecraft:glowstone
fill 272 127 285 272 139 285 minecraft:cut_sandstone
setblock 272 127 286 minecraft:glowstone
fill 272 127 287 272 139 287 minecraft:cut_sandstone
setblock 272 127 288 minecraft:glowstone
fill 272 127 289 272 139 289 minecraft:cut_sandstone
setblock 272 127 290 minecraft:glowstone
fill 272 127 291 272 139 291 minecraft:cut_sandstone
setblock 273 127 281 minecraft:glowstone
fill 273 127 282 273 139 282 minecraft:cut_sandstone
setblock 273 127 283 minecraft:glowstone
fill 273 127 284 273 139 284 minecraft:cut_sandstone
setblock 273 127 285 minecraft:glowstone
fill 273 127 286 273 139 286 minecraft:cut_sandstone
setblock 273 127 287 minecraft:glowstone
fill 273 127 288 273 139 288 minecraft:cut_sandstone
setblock 273 127 289 minecraft:glowstone
fill 273 127 290 273 139 290 minecraft:cut_sandstone
setblock 273 127 291 minecraft:glowstone
fill 274 127 281 274 139 281 minecraft:cut_sandstone
setblock 274 127 282 minecraft:glowstone
fill 274 127 283 274 139 283 minecraft:cut_sandstone
setblock 274 127 284 minecraft:glowstone
fill 274 127 285 274 139 285 minecraft:cut_sandstone
setblock 274 127 286 minecraft:glowstone
fill 274 127 287 274 139 287 minecraft:cut_sandstone
setblock 274 127 288 minecraft:glowstone
fill 274 127 289 274 139 289 minecraft:cut_sandstone
setblock 274 127 290 minecraft:glowstone
fill 274 127 291 274 139 291 minecraft:cut_sandstone
setblock 275 127 281 minecraft:glowstone
fill 275 127 282 275 139 282 minecraft:cut_sandstone
setblock 275 127 283 minecraft:glowstone
fill 275 127 284 275 139 284 minecraft:cut_sandstone
setblock 275 127 285 minecraft:glowstone
fill 275 127 286 275 145 286 minecraft:cut_sandstone
setblock 275 127 287 minecraft:glowstone
fill 275 127 288 275 139 288 minecraft:cut_sandstone
setblock 275 127 289 minecraft:glowstone
fill 275 127 290 275 139 290 minecraft:cut_sandstone
setblock 275 127 291 minecraft:glowstone
fill 275 127 317 275 217 317 minecraft:sandstone
setblock 276 127 282 minecraft:glowstone
fill 276 127 283 276 139 283 minecraft:cut_sandstone
setblock 276 127 284 minecraft:glowstone
fill 276 127 285 276 203 285 minecraft:cut_sandstone
setblock 276 127 286 minecraft:glowstone
fill 276 127 287 276 139 287 minecraft:cut_sandstone
setblock 276 127 288 minecraft:glowstone
fill 276 127 289 276 139 289 minecraft:cut_sandstone
setblock 276 127 290 minecraft:glowstone
fill 276 127 291 276 139 291 minecraft:cut_sandstone
setblock 276 127 317 minecraft:black_terracotta
setblock 277 127 275 minecraft:smooth_sandstone
fill 277 127 282 277 137 282 minecraft:sandstone
fill 277 127 292 277 167 297 minecraft:sandstone
setblock 277 127 298 minecraft:smooth_sandstone
fill 277 127 299 277 165 299 minecraft:sandstone
fill 277 127 307 277 182 307 minecraft:sandstone
fill 277 127 316 277 212 317 minecraft:sandstone
fill 235 128 275 235 217 275 minecraft:sandstone
fill 235 128 279 235 158 279 minecraft:sandstone
fill 235 128 286 235 216 286 minecraft:sandstone
fill 235 128 300 235 138 300 minecraft:sandstone
fill 236 128 290 236 129 290 minecraft:cut_sandstone
fill 236 128 292 236 129 292 minecraft:cut_sandstone
fill 236 128 294 236 129 294 minecraft:cut_sandstone
fill 236 128 296 236 129 296 minecraft:cut_sandstone
fill 236 128 298 236 129 298 minecraft:cut_sandstone
fill 236 128 300 236 129 300 minecraft:cut_sandstone
fill 236 128 302 236 129 302 minecraft:cut_sandstone
fill 236 128 304 236 129 304 minecraft:cut_sandstone
fill 236 128 306 236 129 306 minecraft:cut_sandstone
fill 236 128 308 236 129 308 minecraft:cut_sandstone
fill 237 128 291 237 129 291 minecraft:cut_sandstone
fill 237 128 293 237 129 293 minecraft:cut_sandstone
fill 237 128 295 237 129 295 minecraft:cut_sandstone
fill 237 128 297 237 129 297 minecraft:cut_sandstone
fill 237 128 299 237 129 299 minecraft:cut_sandstone
fill 237 128 301 237 129 301 minecraft:cut_sandstone
fill 237 128 303 237 129 303 minecraft:cut_sandstone
fill 237 128 305 237 129 305 minecraft:cut_sandstone
fill 237 128 307 237 129 307 minecraft:cut_sandstone
fill 238 128 275 238 175 275 minecraft:sandstone
fill 238 128 290 238 129 290 minecraft:cut_sandstone
fill 238 128 292 238 129 292 minecraft:cut_sandstone
fill 238 128 294 238 129 294 minecraft:cut_sandstone
fill 238 128 296 238 129 296 minecraft:cut_sandstone
fill 238 128 298 238 129 298 minecraft:cut_sandstone
fill 238 128 300 238 129 300 minecraft:cut_sandstone
fill 238 128 302 238 129 302 minecraft:cut_sandstone
fill 238 128 304 238 129 304 minecraft:cut_sandstone
fill 238 128 306 238 129 306 minecraft:cut_sandstone
fill 238 128 308 238 129 308 minecraft:cut_sandstone
fill 239 128 291 239 129 291 minecraft:cut_sandstone
fill 239 128 293 239 129 293 minecraft:cut_sandstone
fill 239 128 295 239 129 295 minecraft:cut_sandstone
fill 239 128 297 239 129 297 minecraft:cut_sandstone
fill 239 128 299 239 129 299 minecraft:cut_sandstone
fill 239 128 301 239 129 301 minecraft:cut_sandstone
fill 239 128 303 239 129 303 minecraft:cut_sandstone
fill 239 128 305 239 129 305 minecraft:cut_sandstone
fill 239 128 307 239 129 307 minecraft:cut_sandstone
fill 239 128 317 240 145 317 minecraft:sandstone
fill 240 128 290 240 129 290 minecraft:cut_sandstone
fill 240 128 292 240 129 292 minecraft:cut_sandstone
fill 240 128 294 240 129 294 minecraft:cut_sandstone
fill 240 128 296 240 129 296 minecraft:cut_sandstone
fill 240 128 298 240 129 298 minecraft:cut_sandstone
fill 240 128 300 240 129 300 minecraft:cut_sandstone
fill 240 128 302 240 129 302 minecraft:cut_sandstone
fill 240 128 304 240 129 304 minecraft:cut_sandstone
fill 240 128 306 240 129 306 minecraft:cut_sandstone
fill 240 128 308 240 129 308 minecraft:cut_sandstone
fill 241 128 291 241 129 291 minecraft:cut_sandstone
fill 241 128 293 241 129 293 minecraft:cut_sandstone
fill 241 128 295 241 129 295 minecraft:cut_sandstone
fill 241 128 297 241 129 297 minecraft:cut_sandstone
fill 241 128 299 241 129 299 minecraft:cut_sandstone
fill 241 128 301 241 129 301 minecraft:cut_sandstone
fill 241 128 303 241 129 303 minecraft:cut_sandstone
fill 241 128 305 241 129 305 minecraft:cut_sandstone
fill 241 128 307 241 129 307 minecraft:cut_sandstone
setblock 241 128 317 minecraft:orange_terracotta
fill 242 128 290 242 129 290 minecraft:cut_sandstone
fill 242 128 292 242 129 292 minecraft:cut_sandstone
schedule function dropper:buildpart/65_2 1t
