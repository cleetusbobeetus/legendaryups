fill 23 115 285 23 123 285 minecraft:basalt
setblock 23 115 286 minecraft:red_nether_bricks
fill 23 115 292 25 115 298 minecraft:red_nether_bricks
fill 23 115 303 23 123 303 minecraft:basalt
fill 24 115 279 27 115 279 minecraft:basalt
fill 24 115 286 24 123 286 minecraft:basalt
setblock 24 115 302 minecraft:magma_block
fill 24 115 309 26 115 310 minecraft:basalt
setblock 24 115 311 minecraft:magma_block
fill 25 115 282 29 116 282 minecraft:basalt
fill 25 115 287 25 123 287 minecraft:basalt
fill 25 115 301 25 123 301 minecraft:basalt
fill 25 115 306 29 116 306 minecraft:basalt
setblock 26 115 278 minecraft:basalt
fill 26 115 281 29 115 281 minecraft:basalt
fill 26 115 289 26 123 290 minecraft:basalt
fill 26 115 291 26 115 297 minecraft:red_nether_bricks
fill 26 115 298 26 123 299 minecraft:basalt
fill 26 115 308 28 115 308 minecraft:basalt
setblock 27 115 292 minecraft:magma_block
fill 27 115 293 27 123 294 minecraft:basalt
setblock 27 115 295 minecraft:magma_block
fill 27 115 296 28 121 296 minecraft:basalt
setblock 27 115 309 minecraft:basalt
fill 28 115 293 28 122 293 minecraft:basalt
fill 28 115 301 32 115 302 minecraft:basalt
setblock 28 115 309 minecraft:blackstone
fill 29 115 286 32 115 286 minecraft:basalt
fill 29 115 304 30 115 305 minecraft:basalt
setblock 29 115 307 minecraft:basalt
setblock 29 115 308 minecraft:blackstone
setblock 30 115 282 minecraft:magma_block
setblock 30 115 306 minecraft:magma_block
fill 30 115 317 30 129 317 minecraft:cobbled_deepslate
setblock 31 115 304 minecraft:basalt
setblock 32 115 285 minecraft:basalt
fill 32 115 287 32 115 290 minecraft:basalt
fill 32 115 294 34 115 294 minecraft:basalt
fill 32 115 298 32 115 299 minecraft:basalt
setblock 32 115 303 minecraft:basalt
fill 33 115 288 33 115 289 minecraft:basalt
setblock 33 115 290 minecraft:magma_block
setblock 33 115 298 minecraft:basalt
setblock 33 115 299 minecraft:magma_block
fill 1 116 280 1 116 284 minecraft:basalt
fill 1 116 290 1 122 290 minecraft:basalt
fill 1 116 303 1 116 308 minecraft:basalt
fill 2 116 279 4 116 279 minecraft:basalt
setblock 2 116 290 minecraft:magma_block
fill 2 116 291 2 123 292 minecraft:basalt
setblock 2 116 293 minecraft:magma_block
fill 2 116 294 2 124 295 minecraft:basalt
setblock 2 116 296 minecraft:magma_block
fill 2 116 297 2 123 297 minecraft:basalt
setblock 2 116 308 minecraft:magma_block
fill 2 116 309 4 116 309 minecraft:basalt
fill 3 116 288 3 123 289 minecraft:basalt
fill 3 116 299 3 123 300 minecraft:basalt
fill 3 116 308 4 117 308 minecraft:basalt
setblock 4 116 278 minecraft:basalt
fill 4 116 287 4 124 287 minecraft:basalt
fill 4 116 301 4 124 301 minecraft:basalt
fill 4 116 310 10 116 310 minecraft:basalt
setblock 5 116 277 minecraft:magma_block
setblock 5 116 286 minecraft:magma_block
fill 5 116 302 5 124 302 minecraft:basalt
fill 6 116 277 10 116 277 minecraft:basalt
fill 6 116 284 6 123 285 minecraft:basalt
fill 6 116 303 6 124 303 minecraft:basalt
setblock 6 116 317 minecraft:amethyst_block
fill 7 116 284 7 124 284 minecraft:basalt
fill 7 116 304 7 124 304 minecraft:basalt
setblock 8 116 276 minecraft:magma_block
fill 8 116 283 9 123 283 minecraft:basalt
fill 8 116 305 9 123 305 minecraft:basalt
setblock 8 116 312 minecraft:magma_block
fill 9 116 276 13 116 276 minecraft:basalt
fill 9 116 312 13 116 312 minecraft:basalt
setblock 10 116 292 minecraft:nether_wart_block
fill 10 116 294 11 117 294 minecraft:red_nether_bricks
setblock 10 116 295 minecraft:nether_wart_block
fill 10 116 297 10 117 297 minecraft:red_nether_bricks
setblock 10 116 298 minecraft:nether_wart_block
fill 10 116 299 10 116 300 minecraft:red_nether_bricks
setblock 10 116 313 minecraft:polished_blackstone
fill 11 116 282 16 116 282 minecraft:basalt
setblock 11 116 289 minecraft:nether_wart_block
fill 11 116 295 11 118 296 minecraft:red_nether_bricks
setblock 11 116 301 minecraft:nether_wart_block
fill 11 116 302 14 116 303 minecraft:red_nether_bricks
fill 11 116 306 16 116 306 minecraft:basalt
fill 12 116 287 23 116 287 minecraft:red_nether_bricks
fill 12 116 291 12 120 291 minecraft:red_nether_bricks
fill 12 116 292 12 116 296 minecraft:red_terracotta
setblock 12 116 304 minecraft:nether_wart_block
fill 12 116 305 18 116 305 minecraft:red_nether_bricks
fill 12 116 313 13 116 313 minecraft:basalt
setblock 12 116 314 minecraft:polished_blackstone
setblock 13 116 286 minecraft:nether_wart_block
setblock 13 116 291 minecraft:red_terracotta
fill 13 116 304 20 116 304 minecraft:red_nether_bricks
fill 14 116 285 21 116 285 minecraft:red_nether_bricks
setblock 14 116 301 minecraft:red_terracotta
setblock 14 116 313 minecraft:magma_block
fill 15 116 281 15 123 281 minecraft:basalt
fill 15 116 286 22 116 286 minecraft:red_nether_bricks
setblock 15 116 302 minecraft:red_terracotta
fill 15 116 303 21 116 303 minecraft:red_nether_bricks
setblock 16 116 283 minecraft:nether_wart_block
setblock 17 116 282 minecraft:magma_block
fill 17 116 283 18 116 284 minecraft:red_nether_bricks
setblock 17 116 306 minecraft:magma_block
fill 18 116 278 24 116 278 minecraft:basalt
fill 18 116 292 18 116 295 minecraft:quartz_block
fill 18 116 297 18 116 300 minecraft:quartz_block
fill 19 116 283 20 116 283 minecraft:basalt
fill 19 116 284 20 116 284 minecraft:red_nether_bricks
setblock 19 116 288 minecraft:red_terracotta
fill 19 116 290 20 116 290 minecraft:quartz_block
fill 19 116 302 20 116 302 minecraft:quartz_block
fill 19 116 305 19 124 305 minecraft:basalt
fill 20 116 288 24 116 288 minecraft:red_nether_bricks
setblock 20 116 289 minecraft:red_terracotta
setblock 20 116 301 minecraft:red_terracotta
setblock 20 116 305 minecraft:magma_block
fill 21 116 277 22 116 277 minecraft:basalt
fill 21 116 284 21 124 284 minecraft:basalt
fill 21 116 289 24 116 289 minecraft:red_nether_bricks
setblock 21 116 290 minecraft:red_terracotta
setblock 21 116 300 minecraft:red_terracotta
fill 21 116 301 21 116 302 minecraft:red_nether_bricks
fill 21 116 304 21 124 304 minecraft:basalt
fill 22 116 280 27 116 280 minecraft:basalt
fill 22 116 285 22 124 285 minecraft:basalt
fill 22 116 290 23 116 290 minecraft:quartz_block
fill 22 116 291 22 116 292 minecraft:red_terracotta
fill 22 116 298 22 116 299 minecraft:red_terracotta
fill 22 116 300 23 116 301 minecraft:red_nether_bricks
setblock 22 116 302 minecraft:quartz_block
fill 22 116 303 22 124 303 minecraft:basalt
setblock 23 116 277 minecraft:magma_block
setblock 23 116 286 minecraft:magma_block
fill 23 116 291 23 116 292 minecraft:red_nether_bricks
fill 23 116 293 23 116 297 minecraft:red_terracotta
fill 23 116 298 23 116 299 minecraft:red_nether_bricks
fill 23 116 302 24 123 302 minecraft:basalt
fill 24 116 279 25 116 279 minecraft:basalt
fill 24 116 287 24 123 287 minecraft:basalt
fill 24 116 290 25 116 291 minecraft:red_nether_bricks
fill 24 116 292 24 116 295 minecraft:quartz_block
fill 24 116 296 25 116 296 minecraft:red_nether_bricks
fill 24 116 297 24 116 300 minecraft:quartz_block
fill 24 116 301 24 124 301 minecraft:basalt
fill 24 116 309 24 116 310 minecraft:basalt
fill 25 116 288 25 122 289 minecraft:basalt
fill 25 116 292 25 116 295 minecraft:red_nether_bricks
fill 25 116 297 25 116 298 minecraft:red_nether_bricks
fill 25 116 299 25 116 300 minecraft:basalt
setblock 25 116 309 minecraft:basalt
setblock 25 116 310 minecraft:nether_wart_block
setblock 26 116 279 minecraft:magma_block
fill 26 116 281 28 116 281 minecraft:basalt
setblock 26 116 291 minecraft:magma_block
fill 26 116 292 26 124 293 minecraft:basalt
setblock 26 116 294 minecraft:magma_block
fill 26 116 295 26 124 296 minecraft:basalt
setblock 26 116 297 minecraft:magma_block
fill 26 116 308 27 116 308 minecraft:basalt
setblock 26 116 309 minecraft:magma_block
fill 27 116 284 30 116 285 minecraft:basalt
fill 27 116 292 27 123 292 minecraft:basalt
fill 27 116 295 27 123 295 minecraft:basalt
fill 28 116 301 31 116 302 minecraft:basalt
setblock 29 116 283 minecraft:basalt
fill 29 116 286 31 116 286 minecraft:basalt
fill 29 116 304 30 116 304 minecraft:basalt
setblock 29 116 305 minecraft:magma_block
setblock 30 116 305 minecraft:red_nether_bricks
setblock 31 116 285 minecraft:basalt
setblock 32 116 288 minecraft:basalt
setblock 32 116 289 minecraft:magma_block
setblock 32 116 290 minecraft:basalt
fill 32 116 292 33 116 296 minecraft:basalt
setblock 32 116 298 minecraft:magma_block
fill 32 116 299 32 116 300 minecraft:basalt
setblock 42 116 314 minecraft:crying_obsidian
fill 42 116 315 42 127 315 minecraft:cobbled_deepslate
fill 1 117 281 1 117 284 minecraft:basalt
fill 1 117 303 1 117 306 minecraft:basalt
setblock 1 117 307 minecraft:magma_block
fill 2 117 290 3 123 290 minecraft:basalt
fill 2 117 293 2 124 293 minecraft:basalt
fill 2 117 296 2 124 296 minecraft:basalt
fill 3 117 291 3 123 291 minecraft:basalt
fill 3 117 297 3 123 298 minecraft:basalt
setblock 4 117 279 minecraft:magma_block
setblock 4 117 288 minecraft:magma_block
setblock 4 117 300 minecraft:magma_block
setblock 4 117 309 minecraft:magma_block
fill 5 117 286 5 124 287 minecraft:basalt
fill 5 117 301 5 124 301 minecraft:basalt
fill 5 117 310 10 117 310 minecraft:basalt
setblock 6 117 286 minecraft:basalt
fill 6 117 302 6 125 302 minecraft:basalt
fill 6 117 317 6 129 317 minecraft:cobbled_deepslate
fill 7 117 277 9 117 277 minecraft:basalt
fill 7 117 285 7 125 285 minecraft:basalt
fill 7 117 303 7 125 303 minecraft:basalt
setblock 7 117 311 minecraft:magma_block
fill 8 117 284 8 124 284 minecraft:basalt
fill 8 117 304 8 124 304 minecraft:basalt
setblock 10 117 277 minecraft:magma_block
setblock 10 117 283 minecraft:magma_block
setblock 10 117 293 minecraft:nether_wart_block
setblock 10 117 295 minecraft:red_nether_bricks
setblock 10 117 296 minecraft:nether_wart_block
setblock 10 117 298 minecraft:red_nether_bricks
setblock 10 117 299 minecraft:nether_wart_block
fill 10 117 305 11 124 305 minecraft:basalt
fill 11 117 276 12 117 276 minecraft:basalt
fill 11 117 282 11 123 283 minecraft:basalt
setblock 11 117 290 minecraft:nether_wart_block
fill 11 117 293 11 119 293 minecraft:red_nether_bricks
fill 11 117 301 11 118 301 minecraft:red_nether_bricks
setblock 11 117 302 minecraft:nether_wart_block
fill 11 117 306 12 123 306 minecraft:basalt
fill 11 117 312 12 117 312 minecraft:basalt
fill 12 117 277 18 117 277 minecraft:basalt
fill 12 117 282 12 123 282 minecraft:basalt
fill 12 117 292 12 117 298 minecraft:magma_block
fill 12 117 302 14 117 304 minecraft:red_nether_bricks
setblock 13 117 276 minecraft:magma_block
setblock 13 117 282 minecraft:magma_block
setblock 13 117 286 minecraft:red_nether_bricks
setblock 13 117 287 minecraft:nether_wart_block
fill 13 117 290 13 117 291 minecraft:magma_block
fill 13 117 299 13 117 300 minecraft:magma_block
setblock 13 117 305 minecraft:nether_wart_block
setblock 13 117 306 minecraft:magma_block
setblock 13 117 312 minecraft:magma_block
fill 14 117 282 17 123 282 minecraft:basalt
fill 14 117 285 20 117 285 minecraft:red_nether_bricks
fill 14 117 287 16 117 287 minecraft:red_nether_bricks
setblock 14 117 289 minecraft:magma_block
setblock 14 117 301 minecraft:magma_block
fill 14 117 305 16 117 305 minecraft:red_nether_bricks
fill 14 117 306 17 123 306 minecraft:basalt
fill 15 117 276 17 117 276 minecraft:basalt
setblock 15 117 284 minecraft:nether_wart_block
fill 15 117 286 21 118 286 minecraft:red_nether_bricks
fill 15 117 288 16 117 288 minecraft:magma_block
setblock 15 117 302 minecraft:magma_block
fill 15 117 303 15 119 304 minecraft:red_nether_bricks
fill 15 117 312 17 117 312 minecraft:basalt
setblock 16 117 283 minecraft:red_nether_bricks
fill 16 117 295 17 118 295 minecraft:quartz_block
fill 16 117 297 17 118 297 minecraft:quartz_block
fill 16 117 303 18 117 303 minecraft:magma_block
fill 16 117 304 19 117 304 minecraft:red_nether_bricks
fill 17 117 283 18 123 283 minecraft:basalt
fill 17 117 284 19 117 284 minecraft:red_nether_bricks
fill 17 117 287 19 117 287 minecraft:magma_block
fill 17 117 291 17 118 293 minecraft:quartz_block
fill 17 117 299 17 118 301 minecraft:quartz_block
fill 17 117 305 18 124 305 minecraft:basalt
fill 18 117 278 23 117 278 minecraft:basalt
fill 18 117 291 18 118 291 minecraft:quartz_block
setblock 18 117 293 minecraft:quartz_block
setblock 18 117 299 minecraft:quartz_block
fill 18 117 301 18 118 301 minecraft:quartz_block
fill 18 117 311 21 117 311 minecraft:basalt
setblock 19 117 277 minecraft:magma_block
setblock 19 117 283 minecraft:magma_block
fill 19 117 289 19 118 290 minecraft:quartz_block
fill 19 117 302 19 118 303 minecraft:quartz_block
fill 20 117 283 20 123 284 minecraft:basalt
fill 20 117 287 22 117 287 minecraft:red_nether_bricks
fill 20 117 288 20 118 289 minecraft:quartz_block
setblock 20 117 302 minecraft:magma_block
setblock 20 117 303 minecraft:quartz_block
fill 20 117 304 20 123 305 minecraft:basalt
setblock 21 117 277 minecraft:basalt
fill 21 117 285 21 125 285 minecraft:basalt
setblock 21 117 288 minecraft:red_nether_bricks
setblock 21 117 289 minecraft:magma_block
fill 21 117 301 22 117 301 minecraft:magma_block
setblock 21 117 302 minecraft:red_nether_bricks
fill 21 117 303 21 125 303 minecraft:basalt
fill 21 117 310 23 117 310 minecraft:basalt
fill 22 117 280 25 117 280 minecraft:basalt
fill 22 117 286 23 124 286 minecraft:basalt
fill 22 117 288 22 118 289 minecraft:quartz_block
setblock 22 117 290 minecraft:magma_block
setblock 22 117 300 minecraft:magma_block
fill 22 117 302 22 125 302 minecraft:basalt
fill 22 117 308 24 118 308 minecraft:basalt
fill 23 117 287 23 125 287 minecraft:basalt
setblock 23 117 288 minecraft:red_nether_bricks
fill 23 117 289 23 118 290 minecraft:quartz_block
fill 23 117 291 23 117 293 minecraft:magma_block
fill 23 117 298 23 117 299 minecraft:magma_block
setblock 23 117 300 minecraft:red_nether_bricks
fill 23 117 301 23 124 301 minecraft:basalt
fill 23 117 307 27 117 307 minecraft:basalt
setblock 24 117 279 minecraft:basalt
fill 24 117 288 24 124 288 minecraft:basalt
fill 24 117 289 24 117 290 minecraft:red_nether_bricks
fill 24 117 291 24 118 291 minecraft:quartz_block
setblock 24 117 292 minecraft:red_nether_bricks
fill 24 117 293 25 117 293 minecraft:quartz_block
fill 24 117 294 24 117 297 minecraft:magma_block
setblock 24 117 298 minecraft:red_nether_bricks
setblock 24 117 299 minecraft:quartz_block
fill 24 117 300 25 122 300 minecraft:basalt
setblock 24 117 309 minecraft:basalt
setblock 24 117 310 minecraft:red_nether_bricks
fill 25 117 282 27 117 282 minecraft:basalt
setblock 25 117 290 minecraft:magma_block
fill 25 117 291 26 123 291 minecraft:basalt
setblock 25 117 292 minecraft:quartz_block
setblock 25 117 294 minecraft:red_nether_bricks
setblock 25 117 295 minecraft:quartz_block
setblock 25 117 296 minecraft:red_nether_bricks
fill 25 117 297 25 124 298 minecraft:basalt
setblock 25 117 299 minecraft:magma_block
fill 25 117 306 27 117 306 minecraft:basalt
setblock 25 117 308 minecraft:magma_block
fill 25 117 309 26 117 309 minecraft:red_nether_bricks
fill 26 117 281 27 117 281 minecraft:basalt
fill 26 117 283 27 118 283 minecraft:basalt
fill 26 117 294 26 124 294 minecraft:basalt
fill 26 117 297 26 123 297 minecraft:basalt
fill 26 117 308 26 118 308 minecraft:red_nether_bricks
fill 27 117 284 29 117 285 minecraft:basalt
setblock 27 117 308 minecraft:nether_wart_block
setblock 28 117 283 minecraft:magma_block
fill 28 117 301 30 117 302 minecraft:basalt
fill 28 117 306 28 117 307 minecraft:red_nether_bricks
fill 29 117 286 30 117 288 minecraft:basalt
fill 29 117 299 30 117 300 minecraft:basalt
fill 29 117 303 29 117 304 minecraft:basalt
setblock 29 117 305 minecraft:nether_wart_block
setblock 29 117 306 minecraft:red_nether_bricks
setblock 30 117 285 minecraft:basalt
setblock 30 117 303 minecraft:basalt
setblock 30 117 304 minecraft:red_nether_bricks
setblock 31 117 287 minecraft:basalt
setblock 31 117 288 minecraft:magma_block
setblock 31 117 299 minecraft:basalt
setblock 31 117 300 minecraft:magma_block
setblock 31 117 301 minecraft:basalt
setblock 31 117 302 minecraft:nether_wart_block
fill 32 117 291 32 117 297 minecraft:basalt
setblock 32 117 298 minecraft:red_nether_bricks
setblock 32 117 299 minecraft:nether_wart_block
fill 42 117 314 42 129 314 minecraft:cobbled_deepslate
fill 1 118 283 1 118 284 minecraft:basalt
fill 1 118 303 1 118 305 minecraft:basalt
fill 2 118 282 3 118 282 minecraft:basalt
setblock 3 118 281 minecraft:magma_block
fill 3 118 292 3 125 292 minecraft:basalt
setblock 3 118 293 minecraft:magma_block
fill 3 118 294 3 125 295 minecraft:basalt
setblock 3 118 296 minecraft:magma_block
fill 4 118 280 6 118 280 minecraft:basalt
fill 4 118 288 4 124 290 minecraft:basalt
fill 4 118 298 4 124 300 minecraft:basalt
setblock 4 118 308 minecraft:basalt
setblock 5 118 288 minecraft:basalt
setblock 5 118 300 minecraft:basalt
setblock 6 118 286 minecraft:magma_block
setblock 7 118 278 minecraft:basalt
fill 7 118 310 10 118 310 minecraft:basalt
fill 8 118 285 8 124 285 minecraft:basalt
fill 8 118 303 8 124 303 minecraft:basalt
fill 9 118 284 10 125 284 minecraft:basalt
fill 9 118 304 10 125 304 minecraft:basalt
setblock 10 118 277 minecraft:basalt
fill 10 118 283 10 124 283 minecraft:basalt
fill 10 118 311 11 118 311 minecraft:basalt
setblock 11 118 291 minecraft:nether_wart_block
setblock 11 118 294 minecraft:nether_wart_block
setblock 11 118 297 minecraft:nether_wart_block
fill 11 118 299 12 119 299 minecraft:red_nether_bricks
setblock 11 118 300 minecraft:nether_wart_block
fill 12 118 277 14 118 277 minecraft:basalt
fill 12 118 283 14 124 283 minecraft:basalt
fill 12 118 292 12 118 298 minecraft:red_terracotta
fill 12 118 300 12 120 300 minecraft:red_nether_bricks
fill 12 118 302 14 119 302 minecraft:red_nether_bricks
setblock 12 118 303 minecraft:nether_wart_block
setblock 12 118 305 minecraft:magma_block
setblock 12 118 311 minecraft:magma_block
fill 13 118 282 13 124 282 minecraft:basalt
fill 13 118 287 15 118 287 minecraft:red_nether_bricks
setblock 13 118 288 minecraft:nether_wart_block
fill 13 118 290 13 119 291 minecraft:red_terracotta
fill 13 118 299 13 119 300 minecraft:red_terracotta
fill 13 118 303 14 118 304 minecraft:red_nether_bricks
fill 13 118 305 13 124 306 minecraft:basalt
fill 13 118 311 16 118 311 minecraft:basalt
fill 14 118 289 14 119 289 minecraft:red_terracotta
fill 14 118 301 14 119 301 minecraft:red_terracotta
fill 14 118 305 16 125 305 minecraft:basalt
setblock 15 118 277 minecraft:magma_block
setblock 15 118 283 minecraft:magma_block
setblock 15 118 285 minecraft:nether_wart_block
fill 15 118 288 15 119 288 minecraft:red_terracotta
fill 15 118 302 15 119 302 minecraft:red_terracotta
fill 16 118 277 18 118 277 minecraft:basalt
fill 16 118 283 16 125 283 minecraft:basalt
fill 16 118 285 19 118 285 minecraft:red_nether_bricks
fill 16 118 287 19 119 287 minecraft:red_terracotta
fill 16 118 292 16 119 292 minecraft:quartz_block
fill 16 118 298 16 119 300 minecraft:quartz_block
fill 16 118 303 17 118 303 minecraft:red_terracotta
fill 16 118 304 17 118 304 minecraft:red_nether_bricks
setblock 17 118 284 minecraft:red_nether_bricks
fill 17 118 290 18 119 290 minecraft:quartz_block
fill 17 118 302 18 119 302 minecraft:quartz_block
setblock 17 118 317 minecraft:magma_block
fill 18 118 278 20 118 278 minecraft:basalt
fill 18 118 284 19 125 284 minecraft:basalt
fill 18 118 288 18 119 289 minecraft:quartz_block
fill 18 118 303 18 119 303 minecraft:quartz_block
fill 18 118 304 19 125 304 minecraft:basalt
setblock 18 118 311 minecraft:basalt
fill 19 118 283 19 124 283 minecraft:basalt
fill 19 118 288 19 119 288 minecraft:quartz_block
fill 20 118 285 20 125 285 minecraft:basalt
fill 20 118 287 20 119 287 minecraft:quartz_block
fill 20 118 303 20 125 303 minecraft:basalt
setblock 21 118 278 minecraft:magma_block
setblock 21 118 287 minecraft:red_nether_bricks
fill 21 118 288 21 119 288 minecraft:quartz_block
setblock 21 118 302 minecraft:red_terracotta
setblock 21 118 310 minecraft:basalt
fill 22 118 280 23 119 280 minecraft:basalt
setblock 22 118 287 minecraft:quartz_block
setblock 23 118 288 minecraft:basalt
setblock 23 118 300 minecraft:basalt
fill 23 118 307 25 118 307 minecraft:basalt
setblock 24 118 280 minecraft:magma_block
setblock 24 118 289 minecraft:magma_block
fill 24 118 290 25 124 290 minecraft:basalt
fill 24 118 292 24 118 297 minecraft:red_terracotta
setblock 24 118 298 minecraft:magma_block
fill 24 118 299 25 124 299 minecraft:basalt
fill 24 118 309 25 118 309 minecraft:nether_wart_block
fill 25 118 282 26 118 282 minecraft:basalt
fill 25 118 292 25 125 296 minecraft:basalt
fill 25 118 306 26 118 306 minecraft:basalt
fill 25 118 308 25 119 308 minecraft:red_nether_bricks
fill 26 118 307 27 118 307 minecraft:red_nether_bricks
fill 27 118 284 28 118 285 minecraft:basalt
fill 27 118 303 27 118 305 minecraft:basalt
fill 27 118 306 27 120 306 minecraft:red_nether_bricks
fill 28 118 301 28 118 304 minecraft:basalt
fill 28 118 305 29 118 305 minecraft:red_nether_bricks
setblock 28 118 306 minecraft:nether_wart_block
fill 29 118 285 29 118 288 minecraft:basalt
fill 29 118 299 29 118 303 minecraft:basalt
setblock 29 118 304 minecraft:red_nether_bricks
setblock 30 118 287 minecraft:magma_block
fill 30 118 288 30 118 298 minecraft:basalt
setblock 30 118 299 minecraft:magma_block
fill 30 118 300 30 118 301 minecraft:basalt
fill 30 118 302 30 119 302 minecraft:red_nether_bricks
setblock 30 118 303 minecraft:nether_wart_block
fill 31 118 290 31 118 298 minecraft:basalt
fill 31 118 299 31 119 299 minecraft:red_nether_bricks
setblock 31 118 300 minecraft:nether_wart_block
setblock 31 118 301 minecraft:red_nether_bricks
setblock 0 119 281 minecraft:amethyst_block
fill 0 119 282 0 130 282 minecraft:cobbled_deepslate
fill 1 119 284 2 119 284 minecraft:basalt
fill 1 119 303 1 119 304 minecraft:basalt
setblock 2 119 283 minecraft:magma_block
setblock 2 119 305 minecraft:basalt
setblock 3 119 282 minecraft:basalt
fill 3 119 293 3 125 293 minecraft:basalt
fill 3 119 296 4 119 296 minecraft:basalt
setblock 3 119 306 minecraft:basalt
fill 4 119 291 4 125 292 minecraft:basalt
fill 4 119 297 4 125 297 minecraft:basalt
fill 5 119 280 6 119 280 minecraft:basalt
setblock 5 119 288 minecraft:magma_block
fill 5 119 289 5 124 289 minecraft:basalt
fill 5 119 299 5 125 299 minecraft:basalt
setblock 5 119 300 minecraft:magma_block
fill 6 119 286 6 125 287 minecraft:basalt
fill 6 119 301 6 125 301 minecraft:basalt
fill 7 119 279 9 119 279 minecraft:basalt
fill 7 119 286 7 125 286 minecraft:basalt
fill 7 119 302 7 125 302 minecraft:basalt
fill 7 119 309 9 119 309 minecraft:basalt
fill 9 119 285 9 125 285 minecraft:basalt
fill 9 119 303 9 125 303 minecraft:basalt
fill 10 119 278 12 119 278 minecraft:basalt
setblock 10 119 310 minecraft:basalt
fill 11 119 284 12 124 284 minecraft:basalt
setblock 11 119 294 minecraft:red_nether_bricks
setblock 11 119 295 minecraft:nether_wart_block
fill 11 119 296 11 119 297 minecraft:red_nether_bricks
setblock 11 119 298 minecraft:nether_wart_block
setblock 11 119 304 minecraft:magma_block
fill 11 119 309 11 120 309 minecraft:basalt
setblock 11 119 310 minecraft:magma_block
setblock 12 119 292 minecraft:nether_wart_block
fill 12 119 293 12 119 298 minecraft:red_terracotta
setblock 12 119 301 minecraft:nether_wart_block
fill 12 119 304 12 125 305 minecraft:basalt
fill 12 119 310 18 119 310 minecraft:basalt
setblock 13 119 288 minecraft:red_nether_bricks
setblock 13 119 289 minecraft:nether_wart_block
setblock 13 119 292 minecraft:red_terracotta
fill 13 119 301 13 121 301 minecraft:red_nether_bricks
fill 13 119 303 14 120 303 minecraft:red_nether_bricks
setblock 13 119 304 minecraft:nether_wart_block
fill 14 119 278 16 119 278 minecraft:basalt
fill 14 119 287 15 119 287 minecraft:red_nether_bricks
setblock 14 119 304 minecraft:red_nether_bricks
fill 15 119 283 15 125 283 minecraft:basalt
setblock 15 119 286 minecraft:nether_wart_block
setblock 15 119 292 minecraft:quartz_block
fill 15 119 295 16 119 295 minecraft:quartz_block
fill 15 119 297 15 119 298 minecraft:quartz_block
setblock 15 119 300 minecraft:quartz_block
fill 16 119 284 16 125 284 minecraft:basalt
fill 16 119 285 18 119 286 minecraft:red_nether_bricks
fill 16 119 290 16 119 291 minecraft:quartz_block
setblock 16 119 297 minecraft:quartz_block
fill 16 119 301 16 119 302 minecraft:quartz_block
setblock 16 119 303 minecraft:red_terracotta
fill 16 119 304 17 119 304 minecraft:basalt
setblock 17 119 278 minecraft:magma_block
setblock 17 119 284 minecraft:magma_block
setblock 17 119 289 minecraft:quartz_block
setblock 17 119 292 minecraft:quartz_block
setblock 17 119 300 minecraft:quartz_block
setblock 17 119 303 minecraft:quartz_block
fill 17 119 317 17 129 317 minecraft:cobbled_deepslate
setblock 18 119 278 minecraft:basalt
setblock 19 119 285 minecraft:basalt
fill 19 119 286 20 119 286 minecraft:red_nether_bricks
setblock 19 119 289 minecraft:quartz_block
setblock 19 119 303 minecraft:basalt
setblock 20 119 288 minecraft:quartz_block
fill 20 119 308 20 119 309 minecraft:basalt
fill 21 119 286 21 125 286 minecraft:basalt
setblock 21 119 287 minecraft:quartz_block
fill 21 119 302 21 125 302 minecraft:basalt
fill 22 119 287 22 125 287 minecraft:basalt
setblock 22 119 288 minecraft:quartz_block
fill 22 119 301 22 125 301 minecraft:basalt
fill 22 119 308 23 119 308 minecraft:basalt
fill 22 119 309 23 119 309 minecraft:red_nether_bricks
fill 23 119 281 24 119 281 minecraft:basalt
setblock 23 119 288 minecraft:magma_block
fill 23 119 289 24 124 289 minecraft:basalt
fill 23 119 299 23 125 299 minecraft:basalt
setblock 23 119 300 minecraft:magma_block
fill 23 119 307 24 119 307 minecraft:basalt
fill 24 119 291 24 125 292 minecraft:basalt
fill 24 119 296 24 125 298 minecraft:basalt
setblock 24 119 308 minecraft:red_nether_bricks
setblock 25 119 282 minecraft:basalt
fill 25 119 305 25 119 306 minecraft:basalt
fill 25 119 307 25 120 307 minecraft:red_nether_bricks
setblock 26 119 283 minecraft:basalt
setblock 26 119 305 minecraft:magma_block
fill 26 119 306 26 120 306 minecraft:red_nether_bricks
setblock 26 119 307 minecraft:nether_wart_block
fill 27 119 284 27 119 285 minecraft:basalt
fill 27 119 303 27 119 304 minecraft:basalt
fill 27 119 305 28 119 305 minecraft:red_nether_bricks
setblock 28 119 285 minecraft:basalt
fill 28 119 301 28 119 303 minecraft:basalt
fill 28 119 304 28 120 304 minecraft:red_nether_bricks
fill 29 119 287 29 119 288 minecraft:basalt
setblock 29 119 289 minecraft:magma_block
fill 29 119 290 30 119 292 minecraft:basalt
fill 29 119 299 29 119 300 minecraft:basalt
setblock 29 119 301 minecraft:magma_block
fill 29 119 302 29 119 303 minecraft:red_nether_bricks
setblock 29 119 304 minecraft:nether_wart_block
fill 30 119 293 30 119 298 minecraft:basalt
fill 30 119 299 30 119 300 minecraft:red_nether_bricks
setblock 30 119 301 minecraft:nether_wart_block
fill 31 119 293 31 119 294 minecraft:red_nether_bricks
setblock 31 119 295 minecraft:nether_wart_block
fill 31 119 296 31 119 297 minecraft:red_nether_bricks
setblock 31 119 298 minecraft:nether_wart_block
fill 42 119 291 42 129 291 minecraft:cobbled_deepslate
setblock 42 119 292 minecraft:purple_concrete
fill 42 119 293 42 129 293 minecraft:cobbled_deepslate
fill 0 120 281 0 128 281 minecraft:cobbled_deepslate
setblock 1 120 285 minecraft:magma_block
setblock 1 120 303 minecraft:magma_block
fill 2 120 284 2 120 285 minecraft:basalt
setblock 3 120 278 minecraft:light[level=12]
fill 3 120 296 3 125 296 minecraft:basalt
setblock 3 120 306 minecraft:light[level=12]
setblock 3 120 310 minecraft:light[level=12]
setblock 3 120 313 minecraft:light[level=12]
setblock 4 120 293 minecraft:magma_block
fill 4 120 294 4 125 295 minecraft:basalt
setblock 4 120 296 minecraft:magma_block
setblock 5 120 281 minecraft:basalt
fill 5 120 288 6 125 288 minecraft:basalt
fill 5 120 290 5 125 291 minecraft:basalt
fill 5 120 297 5 124 298 minecraft:basalt
fill 5 120 300 6 125 300 minecraft:basalt
setblock 5 120 307 minecraft:basalt
setblock 7 120 280 minecraft:magma_block
fill 7 120 281 7 121 281 minecraft:basalt
fill 7 120 287 7 125 287 minecraft:basalt
setblock 7 120 301 minecraft:magma_block
fill 8 120 286 8 125 286 minecraft:basalt
fill 8 120 302 8 125 302 minecraft:basalt
setblock 9 120 279 minecraft:basalt
setblock 9 120 309 minecraft:basalt
fill 10 120 278 11 120 278 minecraft:light[level=12]
setblock 10 120 279 minecraft:magma_block
setblock 10 120 285 minecraft:magma_block
setblock 10 120 292 minecraft:light[level=12]
setblock 10 120 299 minecraft:light[level=12]
setblock 10 120 303 minecraft:magma_block
fill 10 120 308 10 121 308 minecraft:basalt
setblock 10 120 309 minecraft:magma_block
setblock 10 120 313 minecraft:light[level=12]
fill 11 120 285 11 125 285 minecraft:basalt
setblock 11 120 286 minecraft:light[level=12]
setblock 11 120 294 minecraft:light[level=12]
setblock 11 120 302 minecraft:light[level=12]
fill 11 120 303 11 125 304 minecraft:basalt
setblock 11 120 310 minecraft:light[level=12]
setblock 12 120 292 minecraft:red_nether_bricks
fill 12 120 293 12 120 297 minecraft:magma_block
setblock 12 120 298 minecraft:red_nether_bricks
setblock 12 120 299 minecraft:nether_wart_block
setblock 12 120 301 minecraft:red_nether_bricks
setblock 13 120 279 minecraft:basalt
setblock 13 120 284 minecraft:magma_block
setblock 13 120 289 minecraft:red_nether_bricks
setblock 13 120 290 minecraft:nether_wart_block
fill 13 120 291 13 120 292 minecraft:magma_block
fill 13 120 298 13 120 300 minecraft:magma_block
setblock 13 120 302 minecraft:nether_wart_block
fill 13 120 304 15 124 304 minecraft:basalt
fill 14 120 284 15 125 284 minecraft:basalt
fill 14 120 289 14 120 290 minecraft:magma_block
fill 14 120 301 14 120 302 minecraft:magma_block
fill 15 120 286 17 120 286 minecraft:red_nether_bricks
setblock 15 120 287 minecraft:nether_wart_block
setblock 15 120 288 minecraft:magma_block
fill 15 120 303 15 121 303 minecraft:magma_block
fill 16 120 287 17 120 287 minecraft:magma_block
setblock 16 120 304 minecraft:magma_block
setblock 17 120 278 minecraft:light[level=12]
fill 17 120 284 17 124 285 minecraft:basalt
setblock 17 120 292 minecraft:light[level=12]
setblock 17 120 299 minecraft:light[level=12]
fill 17 120 303 17 124 304 minecraft:basalt
setblock 17 120 313 minecraft:light[level=12]
fill 18 120 285 18 125 285 minecraft:basalt
fill 18 120 286 19 120 286 minecraft:magma_block
fill 18 120 303 18 125 303 minecraft:basalt
setblock 19 120 278 minecraft:light[level=12]
setblock 19 120 279 minecraft:magma_block
setblock 19 120 285 minecraft:magma_block
setblock 19 120 294 minecraft:light[level=12]
setblock 19 120 302 minecraft:light[level=12]
setblock 19 120 303 minecraft:magma_block
fill 19 120 308 21 120 308 minecraft:basalt
setblock 19 120 309 minecraft:magma_block
setblock 19 120 310 minecraft:light[level=12]
fill 20 120 280 21 120 280 minecraft:basalt
fill 20 120 286 20 125 286 minecraft:basalt
fill 20 120 302 20 124 302 minecraft:basalt
fill 21 120 281 21 121 281 minecraft:basalt
fill 21 120 287 21 125 287 minecraft:basalt
fill 21 120 301 21 125 301 minecraft:basalt
setblock 22 120 281 minecraft:magma_block
fill 22 120 288 23 125 288 minecraft:basalt
fill 22 120 300 23 125 300 minecraft:basalt
fill 22 120 308 24 120 308 minecraft:nether_wart_block
setblock 23 120 281 minecraft:basalt
fill 23 120 290 23 125 291 minecraft:basalt
fill 23 120 297 23 124 298 minecraft:basalt
setblock 23 120 307 minecraft:basalt
setblock 24 120 278 minecraft:light[level=12]
fill 24 120 283 24 121 283 minecraft:basalt
fill 24 120 293 24 125 295 minecraft:basalt
fill 24 120 307 24 121 307 minecraft:red_nether_bricks
setblock 24 120 313 minecraft:light[level=12]
setblock 25 120 283 minecraft:magma_block
setblock 25 120 305 minecraft:basalt
setblock 25 120 306 minecraft:red_nether_bricks
fill 26 120 305 26 121 305 minecraft:red_nether_bricks
fill 26 120 310 26 120 311 minecraft:red_nether_bricks
setblock 27 120 278 minecraft:light[level=12]
setblock 27 120 285 minecraft:basalt
setblock 27 120 303 minecraft:basalt
fill 27 120 304 27 121 304 minecraft:red_nether_bricks
setblock 27 120 305 minecraft:nether_wart_block
setblock 27 120 310 minecraft:light[level=12]
setblock 28 120 288 minecraft:magma_block
fill 28 120 289 29 120 290 minecraft:basalt
fill 28 120 298 28 121 299 minecraft:basalt
setblock 28 120 300 minecraft:magma_block
setblock 28 120 301 minecraft:basalt
fill 28 120 302 28 120 303 minecraft:red_nether_bricks
fill 29 120 291 29 120 292 minecraft:basalt
setblock 29 120 299 minecraft:basalt
fill 29 120 300 30 120 301 minecraft:red_nether_bricks
setblock 29 120 302 minecraft:nether_wart_block
setblock 29 120 303 minecraft:red_nether_bricks
fill 30 120 291 30 120 292 minecraft:red_nether_bricks
setblock 30 120 293 minecraft:nether_wart_block
fill 30 120 294 30 120 295 minecraft:red_nether_bricks
setblock 30 120 296 minecraft:nether_wart_block
fill 30 120 297 30 120 298 minecraft:red_nether_bricks
setblock 30 120 299 minecraft:nether_wart_block
setblock 31 120 278 minecraft:light[level=12]
setblock 31 120 285 minecraft:light[level=12]
setblock 31 120 292 minecraft:light[level=12]
setblock 31 120 299 minecraft:light[level=12]
setblock 31 120 306 minecraft:light[level=12]
setblock 31 120 313 minecraft:light[level=12]
setblock 35 120 278 minecraft:light[level=12]
setblock 35 120 286 minecraft:light[level=12]
setblock 35 120 294 minecraft:light[level=12]
setblock 35 120 302 minecraft:light[level=12]
setblock 35 120 310 minecraft:light[level=12]
setblock 38 120 278 minecraft:light[level=12]
setblock 38 120 285 minecraft:light[level=12]
setblock 38 120 292 minecraft:light[level=12]
setblock 38 120 299 minecraft:light[level=12]
setblock 38 120 306 minecraft:light[level=12]
setblock 38 120 313 minecraft:light[level=12]
fill 42 120 292 42 129 292 minecraft:cobbled_deepslate
setblock 0 121 304 minecraft:crying_obsidian
setblock 3 121 303 minecraft:basalt
setblock 3 121 304 minecraft:magma_block
fill 3 121 311 3 130 311 minecraft:blackstone
fill 4 121 293 5 121 293 minecraft:basalt
fill 4 121 296 5 125 296 minecraft:basalt
fill 5 121 292 5 124 292 minecraft:basalt
fill 5 121 294 5 124 295 minecraft:basalt
setblock 6 121 282 minecraft:magma_block
fill 6 121 283 6 122 283 minecraft:basalt
fill 6 121 289 6 125 290 minecraft:basalt
fill 6 121 298 6 125 299 minecraft:basalt
fill 6 121 305 6 122 305 minecraft:basalt
setblock 6 121 306 minecraft:magma_block
fill 7 121 288 7 125 288 minecraft:basalt
fill 7 121 300 7 125 301 minecraft:basalt
fill 8 121 287 8 125 287 minecraft:basalt
fill 8 121 301 8 125 301 minecraft:basalt
fill 9 121 286 10 125 286 minecraft:basalt
setblock 9 121 302 minecraft:magma_block
fill 9 121 307 9 122 307 minecraft:basalt
setblock 9 121 308 minecraft:magma_block
fill 10 121 285 10 125 285 minecraft:basalt
fill 10 121 302 10 125 303 minecraft:basalt
fill 11 121 288 11 123 290 minecraft:ochre_froglight
setblock 12 121 280 minecraft:magma_block
fill 12 121 285 14 125 285 minecraft:basalt
fill 12 121 288 12 123 288 minecraft:ochre_froglight
fill 12 121 289 12 124 289 minecraft:black_concrete
fill 12 121 290 12 124 290 minecraft:ochre_froglight
fill 12 121 295 12 121 297 minecraft:red_terracotta
fill 12 121 303 14 125 303 minecraft:basalt
fill 13 121 284 13 125 284 minecraft:basalt
fill 13 121 291 13 121 294 minecraft:red_terracotta
fill 13 121 298 13 121 300 minecraft:red_terracotta
fill 14 121 289 14 121 290 minecraft:red_terracotta
fill 14 121 301 14 121 302 minecraft:red_terracotta
setblock 15 121 285 minecraft:magma_block
setblock 15 121 288 minecraft:red_terracotta
fill 15 121 308 17 121 308 minecraft:basalt
fill 16 121 285 16 125 285 minecraft:basalt
setblock 16 121 287 minecraft:red_terracotta
fill 16 121 303 16 125 304 minecraft:basalt
setblock 17 121 286 minecraft:red_terracotta
fill 17 121 292 17 122 293 minecraft:bone_block
fill 17 121 295 17 122 297 minecraft:bone_block
fill 17 121 299 17 122 300 minecraft:bone_block
fill 18 121 286 19 125 286 minecraft:basalt
fill 18 121 290 18 122 290 minecraft:bone_block
setblock 18 121 302 minecraft:magma_block
setblock 18 121 308 minecraft:magma_block
fill 19 121 285 19 125 285 minecraft:basalt
fill 19 121 289 19 122 289 minecraft:bone_block
fill 19 121 302 19 125 303 minecraft:basalt
fill 19 121 307 19 121 308 minecraft:basalt
fill 20 121 287 20 124 287 minecraft:basalt
setblock 20 121 288 minecraft:bone_block
fill 20 121 301 20 125 301 minecraft:basalt
setblock 20 121 307 minecraft:basalt
fill 21 121 288 21 125 288 minecraft:basalt
fill 21 121 300 21 125 300 minecraft:basalt
setblock 21 121 307 minecraft:magma_block
fill 22 121 289 22 125 290 minecraft:basalt
fill 22 121 298 22 125 299 minecraft:basalt
fill 22 121 307 23 121 307 minecraft:red_nether_bricks
fill 23 121 292 23 121 296 minecraft:basalt
fill 23 121 306 23 122 306 minecraft:red_nether_bricks
fill 24 121 306 25 121 306 minecraft:nether_wart_block
setblock 24 121 310 minecraft:nether_wart_block
fill 24 121 311 24 123 311 minecraft:red_nether_bricks
fill 25 121 305 25 122 305 minecraft:red_nether_bricks
fill 25 121 309 25 121 310 minecraft:red_nether_bricks
setblock 25 121 311 minecraft:nether_wart_block
fill 25 121 312 25 123 312 minecraft:red_nether_bricks
fill 26 121 287 26 122 287 minecraft:basalt
setblock 26 121 302 minecraft:basalt
fill 26 121 303 26 121 304 minecraft:red_nether_bricks
fill 26 121 309 26 123 309 minecraft:red_nether_bricks
fill 26 121 310 27 122 311 minecraft:orange_terracotta
setblock 26 121 312 minecraft:nether_wart_block
setblock 27 121 287 minecraft:magma_block
fill 27 121 302 27 122 303 minecraft:red_nether_bricks
fill 27 121 309 28 123 309 minecraft:orange_terracotta
setblock 27 121 312 minecraft:red_nether_bricks
fill 28 121 289 28 121 290 minecraft:basalt
fill 28 121 300 28 121 302 minecraft:red_nether_bricks
setblock 28 121 303 minecraft:nether_wart_block
fill 28 121 310 28 123 310 minecraft:orange_terracotta
setblock 28 121 311 minecraft:red_nether_bricks
setblock 29 121 291 minecraft:nether_wart_block
fill 29 121 292 29 121 293 minecraft:red_nether_bricks
setblock 29 121 294 minecraft:nether_wart_block
fill 29 121 295 29 121 299 minecraft:red_nether_bricks
setblock 29 121 300 minecraft:nether_wart_block
setblock 29 121 301 minecraft:red_nether_bricks
fill 30 121 288 30 123 290 minecraft:ochre_froglight
fill 30 121 295 30 121 296 minecraft:red_nether_bricks
setblock 30 121 297 minecraft:nether_wart_block
fill 31 121 288 31 123 288 minecraft:ochre_froglight
fill 31 121 289 31 124 289 minecraft:black_concrete
fill 31 121 290 31 124 290 minecraft:ochre_froglight
fill 42 121 305 42 129 305 minecraft:cobbled_deepslate
setblock 42 121 306 minecraft:purple_concrete
fill 0 122 304 0 127 304 minecraft:cobbled_deepslate
setblock 1 122 289 minecraft:basalt
setblock 2 122 287 minecraft:basalt
setblock 2 122 288 minecraft:magma_block
setblock 2 122 300 minecraft:magma_block
setblock 2 122 301 minecraft:basalt
fill 4 122 293 4 125 293 minecraft:basalt
setblock 5 122 284 minecraft:magma_block
setblock 5 122 293 minecraft:magma_block
setblock 5 122 304 minecraft:basalt
fill 6 122 291 6 125 292 minecraft:basalt
fill 6 122 296 6 125 297 minecraft:basalt
fill 7 122 289 7 125 289 minecraft:basalt
fill 7 122 299 7 125 299 minecraft:basalt
fill 8 122 288 8 124 288 minecraft:basalt
fill 8 122 300 8 124 300 minecraft:basalt
setblock 8 122 306 minecraft:basalt
setblock 9 122 281 minecraft:basalt
fill 9 122 287 9 125 287 minecraft:basalt
fill 9 122 301 9 125 302 minecraft:basalt
fill 10 122 288 10 123 290 minecraft:ochre_froglight
setblock 11 122 281 minecraft:basalt
fill 11 122 286 12 125 286 minecraft:basalt
fill 11 122 302 12 124 302 minecraft:basalt
fill 13 122 288 13 123 290 minecraft:ochre_froglight
fill 13 122 294 13 122 298 minecraft:red_terracotta
setblock 13 122 308 minecraft:basalt
fill 14 122 280 15 122 280 minecraft:basalt
setblock 14 122 301 minecraft:red_terracotta
setblock 14 122 308 minecraft:magma_block
fill 15 122 285 15 125 285 minecraft:basalt
fill 15 122 296 16 123 296 minecraft:bone_block
fill 15 122 303 15 125 303 minecraft:basalt
setblock 15 122 308 minecraft:basalt
fill 16 122 286 16 125 286 minecraft:basalt
fill 16 122 291 16 124 292 minecraft:bone_block
fill 16 122 298 16 123 301 minecraft:bone_block
fill 16 122 302 18 125 302 minecraft:basalt
setblock 17 122 286 minecraft:magma_block
fill 17 122 289 18 123 289 minecraft:bone_block
fill 17 122 291 17 123 291 minecraft:bone_block
setblock 17 122 301 minecraft:bone_block
setblock 17 122 307 minecraft:magma_block
fill 18 122 288 19 122 288 minecraft:bone_block
fill 18 122 307 19 122 307 minecraft:basalt
fill 19 122 287 19 125 287 minecraft:basalt
fill 19 122 301 19 125 301 minecraft:basalt
setblock 20 122 282 minecraft:magma_block
setblock 20 122 288 minecraft:magma_block
setblock 20 122 300 minecraft:magma_block
setblock 20 122 306 minecraft:magma_block
setblock 21 122 282 minecraft:basalt
fill 21 122 289 21 125 289 minecraft:basalt
fill 21 122 299 21 125 299 minecraft:basalt
setblock 21 122 306 minecraft:basalt
fill 22 122 291 22 122 292 minecraft:basalt
fill 22 122 296 22 125 297 minecraft:basalt
setblock 22 122 305 minecraft:basalt
setblock 22 122 306 minecraft:red_nether_bricks
setblock 23 122 284 minecraft:magma_block
fill 23 122 292 23 124 292 minecraft:basalt
setblock 23 122 293 minecraft:magma_block
fill 23 122 294 23 124 296 minecraft:basalt
setblock 23 122 305 minecraft:red_terracotta
fill 24 122 304 24 124 304 minecraft:bone_block
setblock 24 122 305 minecraft:red_nether_bricks
setblock 24 122 309 minecraft:nether_wart_block
setblock 24 122 310 minecraft:red_nether_bricks
setblock 24 122 312 minecraft:red_nether_bricks
setblock 25 122 286 minecraft:basalt
fill 25 122 303 25 125 303 minecraft:bone_block
fill 25 122 304 26 122 304 minecraft:nether_wart_block
setblock 25 122 309 minecraft:red_nether_bricks
setblock 25 122 310 minecraft:nether_wart_block
fill 25 122 311 25 124 311 minecraft:red_nether_bricks
setblock 26 122 300 minecraft:basalt
setblock 26 122 301 minecraft:magma_block
setblock 26 122 302 minecraft:red_terracotta
setblock 26 122 303 minecraft:red_nether_bricks
fill 26 122 308 26 124 308 minecraft:red_nether_bricks
fill 26 122 312 26 124 312 minecraft:red_nether_bricks
setblock 27 122 289 minecraft:basalt
fill 27 122 296 27 123 296 minecraft:basalt
setblock 27 122 299 minecraft:basalt
setblock 27 122 300 minecraft:red_terracotta
fill 27 122 301 28 122 301 minecraft:nether_wart_block
setblock 27 122 308 minecraft:nether_wart_block
setblock 27 122 312 minecraft:nether_wart_block
setblock 28 122 291 minecraft:red_nether_bricks
setblock 28 122 292 minecraft:nether_wart_block
fill 28 122 296 29 122 297 minecraft:red_nether_bricks
fill 28 122 298 29 122 298 minecraft:nether_wart_block
fill 28 122 299 28 122 300 minecraft:red_nether_bricks
fill 28 122 308 29 122 308 minecraft:red_nether_bricks
setblock 28 122 311 minecraft:orange_terracotta
setblock 28 122 312 minecraft:red_nether_bricks
fill 29 122 288 29 123 290 minecraft:ochre_froglight
setblock 29 122 294 minecraft:red_nether_bricks
setblock 29 122 295 minecraft:nether_wart_block
fill 29 122 309 29 122 310 minecraft:orange_terracotta
fill 29 122 311 29 124 311 minecraft:red_nether_bricks
fill 30 122 308 30 124 308 minecraft:orange_terracotta
setblock 30 122 309 minecraft:red_nether_bricks
fill 32 122 288 32 123 290 minecraft:ochre_froglight
fill 42 122 306 42 123 306 minecraft:cobbled_deepslate
setblock 1 123 292 minecraft:basalt
setblock 1 123 293 minecraft:magma_block
fill 1 123 294 1 123 295 minecraft:basalt
setblock 1 123 296 minecraft:magma_block
setblock 2 123 299 minecraft:basalt
setblock 4 123 286 minecraft:magma_block
fill 5 123 293 6 125 293 minecraft:basalt
fill 6 123 294 6 125 295 minecraft:basalt
setblock 7 123 283 minecraft:basalt
fill 7 123 290 7 125 290 minecraft:basalt
setblock 7 123 291 minecraft:magma_block
setblock 7 123 297 minecraft:magma_block
fill 7 123 298 7 125 298 minecraft:basalt
setblock 7 123 305 minecraft:basalt
fill 8 123 289 8 125 289 minecraft:basalt
fill 8 123 299 8 125 299 minecraft:basalt
fill 9 123 288 9 125 288 minecraft:basalt
fill 9 123 300 9 125 300 minecraft:basalt
setblock 10 123 287 minecraft:magma_block
fill 10 123 301 11 125 301 minecraft:basalt
fill 11 123 287 11 124 287 minecraft:basalt
setblock 12 123 307 minecraft:basalt
setblock 13 123 286 minecraft:magma_block
fill 13 123 302 15 125 302 minecraft:basalt
setblock 13 123 307 minecraft:magma_block
fill 14 123 286 15 124 286 minecraft:basalt
fill 14 123 307 16 123 307 minecraft:basalt
fill 15 123 292 15 125 292 minecraft:bone_block
fill 15 123 298 15 125 298 minecraft:bone_block
fill 15 123 300 15 124 300 minecraft:bone_block
fill 16 123 290 17 123 290 minecraft:bone_block
fill 17 123 286 17 125 287 minecraft:basalt
fill 17 123 288 18 123 288 minecraft:bone_block
fill 17 123 301 18 125 301 minecraft:basalt
fill 18 123 287 18 125 287 minecraft:basalt
fill 18 123 309 19 124 310 minecraft:magma_block
fill 19 123 288 20 125 288 minecraft:basalt
fill 19 123 300 20 125 300 minecraft:basalt
fill 20 123 289 20 125 289 minecraft:basalt
fill 20 123 299 20 124 299 minecraft:basalt
setblock 21 123 283 minecraft:basalt
fill 21 123 290 21 123 291 minecraft:basalt
fill 21 123 297 21 123 298 minecraft:basalt
fill 21 123 306 21 125 306 minecraft:bone_block
fill 22 123 291 22 125 291 minecraft:basalt
setblock 22 123 292 minecraft:magma_block
fill 22 123 293 22 125 294 minecraft:basalt
setblock 22 123 295 minecraft:magma_block
setblock 22 123 304 minecraft:magma_block
fill 22 123 305 24 125 305 minecraft:bone_block
fill 23 123 293 23 125 293 minecraft:basalt
setblock 23 123 304 minecraft:bone_block
fill 23 123 309 24 124 310 minecraft:magma_block
fill 24 123 300 24 124 300 minecraft:basalt
setblock 24 123 303 minecraft:bone_block
setblock 24 123 312 minecraft:nether_wart_block
setblock 25 123 288 minecraft:magma_block
fill 25 123 289 25 124 289 minecraft:basalt
setblock 25 123 300 minecraft:magma_block
fill 25 123 302 26 123 302 minecraft:bone_block
fill 25 123 304 25 125 304 minecraft:bone_block
setblock 25 123 308 minecraft:red_nether_bricks
setblock 25 123 309 minecraft:nether_wart_block
fill 25 123 310 25 125 310 minecraft:red_nether_bricks
fill 26 123 300 26 124 301 minecraft:bone_block
setblock 26 123 310 minecraft:nether_wart_block
fill 26 123 311 26 125 311 minecraft:red_nether_bricks
fill 27 123 298 27 125 298 minecraft:bone_block
fill 27 123 300 27 125 300 minecraft:bone_block
fill 27 123 308 27 125 308 minecraft:red_nether_bricks
setblock 27 123 310 minecraft:orange_terracotta
setblock 27 123 311 minecraft:nether_wart_block
fill 27 123 312 27 124 312 minecraft:red_nether_bricks
fill 28 123 295 28 123 297 minecraft:magma_block
fill 28 123 307 29 123 307 minecraft:red_nether_bricks
setblock 28 123 308 minecraft:nether_wart_block
setblock 28 123 311 minecraft:red_nether_bricks
setblock 28 123 312 minecraft:nether_wart_block
fill 29 123 308 29 124 309 minecraft:orange_terracotta
fill 29 123 310 29 125 310 minecraft:red_nether_bricks
fill 30 123 307 31 124 307 minecraft:orange_terracotta
fill 30 123 309 31 124 309 minecraft:orange_terracotta
setblock 30 123 310 minecraft:nether_wart_block
fill 30 123 311 30 125 311 minecraft:red_nether_bricks
fill 31 123 308 31 125 308 minecraft:orange_terracotta
setblock 0 124 293 minecraft:magma_block
fill 0 124 294 0 129 294 minecraft:cobbled_deepslate
setblock 2 124 292 minecraft:basalt
fill 3 124 289 3 124 290 minecraft:basalt
setblock 3 124 291 minecraft:magma_block
setblock 3 124 297 minecraft:magma_block
fill 3 124 298 3 124 299 minecraft:basalt
setblock 6 124 285 minecraft:basalt
fill 7 124 291 7 124 297 minecraft:basalt
fill 8 124 290 8 125 290 minecraft:basalt
fill 8 124 298 8 125 298 minecraft:basalt
setblock 9 124 283 minecraft:magma_block
fill 9 124 289 9 125 289 minecraft:magma_block
setblock 9 124 299 minecraft:basalt
setblock 9 124 305 minecraft:basalt
fill 10 124 287 10 125 288 minecraft:basalt
fill 10 124 300 10 125 300 minecraft:basalt
fill 11 124 283 11 125 283 minecraft:basalt
fill 11 124 288 12 124 288 minecraft:bone_block
fill 11 124 289 11 124 290 minecraft:ochre_froglight
setblock 12 124 282 minecraft:magma_block
fill 12 124 287 14 124 287 minecraft:basalt
fill 12 124 301 16 124 301 minecraft:basalt
setblock 12 124 306 minecraft:magma_block
fill 13 124 286 13 125 286 minecraft:basalt
fill 14 124 282 16 124 282 minecraft:basalt
fill 14 124 291 14 125 300 minecraft:bone_block
fill 14 124 306 16 124 306 minecraft:basalt
fill 15 124 287 15 125 287 minecraft:magma_block
fill 15 124 289 15 125 291 minecraft:bone_block
fill 15 124 295 15 124 297 minecraft:bone_block
fill 15 124 299 15 125 299 minecraft:bone_block
fill 16 124 287 16 125 287 minecraft:basalt
fill 16 124 288 16 124 290 minecraft:bone_block
setblock 16 124 300 minecraft:bone_block
fill 17 124 283 17 125 283 minecraft:basalt
fill 17 124 288 17 124 289 minecraft:bone_block
setblock 18 124 283 minecraft:magma_block
fill 18 124 288 18 125 288 minecraft:basalt
fill 18 124 300 18 125 300 minecraft:basalt
fill 18 124 306 20 125 306 minecraft:bone_block
setblock 19 124 289 minecraft:basalt
setblock 19 124 299 minecraft:basalt
fill 19 124 307 23 125 307 minecraft:bone_block
setblock 20 124 284 minecraft:basalt
fill 20 124 290 21 124 290 minecraft:basalt
fill 20 124 298 21 125 298 minecraft:basalt
setblock 20 124 304 minecraft:basalt
fill 20 124 305 21 124 305 minecraft:bone_block
setblock 21 124 291 minecraft:magma_block
fill 21 124 292 21 124 293 minecraft:basalt
fill 21 124 294 21 125 294 minecraft:magma_block
fill 21 124 295 21 124 296 minecraft:basalt
setblock 21 124 297 minecraft:magma_block
setblock 22 124 275 minecraft:magma_block
fill 22 124 292 22 125 292 minecraft:basalt
fill 22 124 295 22 125 295 minecraft:basalt
fill 22 124 306 24 125 306 minecraft:bone_block
fill 23 124 285 23 125 285 minecraft:bone_block
setblock 23 124 302 minecraft:basalt
fill 24 124 286 24 125 286 minecraft:bone_block
setblock 24 124 287 minecraft:magma_block
setblock 24 124 311 minecraft:nether_wart_block
fill 25 124 287 25 125 288 minecraft:bone_block
fill 25 124 291 25 125 291 minecraft:basalt
fill 25 124 305 25 125 305 minecraft:bone_block
setblock 25 124 309 minecraft:red_nether_bricks
setblock 25 124 312 minecraft:nether_wart_block
fill 26 124 288 26 124 291 minecraft:bone_block
fill 26 124 302 26 125 304 minecraft:bone_block
setblock 26 124 309 minecraft:nether_wart_block
fill 26 124 310 26 125 310 minecraft:red_nether_bricks
fill 27 124 289 27 124 297 minecraft:bone_block
fill 27 124 299 28 125 299 minecraft:bone_block
fill 27 124 301 27 125 303 minecraft:bone_block
setblock 27 124 309 minecraft:red_nether_bricks
setblock 27 124 310 minecraft:nether_wart_block
fill 27 124 311 27 125 311 minecraft:red_nether_bricks
fill 28 124 291 28 125 298 minecraft:bone_block
fill 28 124 300 28 125 301 minecraft:bone_block
setblock 28 124 307 minecraft:nether_wart_block
fill 28 124 308 28 126 308 minecraft:red_nether_bricks
fill 28 124 309 28 127 310 minecraft:bone_block
setblock 28 124 311 minecraft:nether_wart_block
setblock 28 124 312 minecraft:red_nether_bricks
setblock 29 124 307 minecraft:red_nether_bricks
fill 30 124 286 31 125 288 minecraft:bone_block
fill 30 124 289 30 124 290 minecraft:ochre_froglight
fill 30 124 306 30 126 306 minecraft:red_nether_bricks
fill 30 124 310 30 126 310 minecraft:red_nether_bricks
setblock 31 124 306 minecraft:nether_wart_block
setblock 31 124 310 minecraft:nether_wart_block
fill 32 124 306 32 124 308 minecraft:orange_terracotta
fill 32 124 309 32 125 309 minecraft:red_nether_bricks
fill 33 124 306 33 126 306 minecraft:orange_terracotta
setblock 33 124 307 minecraft:red_nether_bricks
setblock 42 124 306 minecraft:amethyst_block
setblock 0 125 291 minecraft:crying_obsidian
setblock 0 125 293 minecraft:cobbled_deepslate
setblock 3 125 291 minecraft:basalt
setblock 3 125 297 minecraft:basalt
fill 4 125 289 4 125 290 minecraft:basalt
fill 4 125 298 4 125 299 minecraft:basalt
setblock 5 125 287 minecraft:basalt
setblock 5 125 289 minecraft:magma_block
setblock 5 125 292 minecraft:magma_block
setblock 5 125 294 minecraft:basalt
setblock 5 125 295 minecraft:magma_block
setblock 5 125 297 minecraft:basalt
setblock 5 125 298 minecraft:magma_block
setblock 5 125 301 minecraft:magma_block
fill 7 125 291 7 125 292 minecraft:basalt
fill 7 125 293 7 125 295 minecraft:magma_block
fill 7 125 296 7 125 297 minecraft:basalt
setblock 8 125 285 minecraft:magma_block
setblock 8 125 288 minecraft:magma_block
fill 8 125 291 8 125 293 minecraft:magma_block
fill 8 125 295 8 125 297 minecraft:magma_block
setblock 8 125 300 minecraft:magma_block
setblock 8 125 303 minecraft:magma_block
setblock 9 125 290 minecraft:magma_block
fill 9 125 298 9 125 299 minecraft:magma_block
setblock 10 125 289 minecraft:magma_block
setblock 10 125 299 minecraft:magma_block
setblock 11 125 284 minecraft:magma_block
fill 11 125 287 11 125 288 minecraft:magma_block
fill 11 125 300 13 125 300 minecraft:magma_block
setblock 11 125 302 minecraft:magma_block
setblock 11 125 305 minecraft:magma_block
fill 12 125 283 12 125 284 minecraft:basalt
setblock 12 125 287 minecraft:basalt
fill 12 125 288 13 125 288 minecraft:magma_block
fill 12 125 301 12 125 302 minecraft:basalt
setblock 13 125 283 minecraft:basalt
fill 13 125 287 14 125 287 minecraft:magma_block
fill 13 125 293 13 125 299 minecraft:bone_block
fill 13 125 301 15 125 301 minecraft:magma_block
fill 13 125 304 13 125 305 minecraft:basalt
setblock 14 125 283 minecraft:magma_block
setblock 14 125 286 minecraft:magma_block
setblock 14 125 289 minecraft:bone_block
setblock 14 125 304 minecraft:magma_block
setblock 15 125 286 minecraft:basalt
fill 15 125 288 17 125 288 minecraft:magma_block
setblock 15 125 296 minecraft:bone_block
fill 15 125 300 17 125 300 minecraft:magma_block
setblock 15 125 304 minecraft:basalt
fill 16 125 289 16 125 290 minecraft:bone_block
setblock 16 125 301 minecraft:basalt
setblock 17 125 284 minecraft:basalt
setblock 17 125 285 minecraft:magma_block
setblock 17 125 289 minecraft:bone_block
setblock 17 125 303 minecraft:magma_block
fill 17 125 304 17 125 305 minecraft:basalt
setblock 17 125 306 minecraft:bone_block
fill 18 125 289 19 125 289 minecraft:magma_block
fill 18 125 299 20 125 299 minecraft:magma_block
fill 18 125 305 20 125 305 minecraft:bone_block
setblock 18 125 307 minecraft:bone_block
fill 19 125 290 20 125 290 minecraft:magma_block
setblock 19 125 298 minecraft:magma_block
setblock 20 125 287 minecraft:magma_block
fill 20 125 291 20 125 293 minecraft:magma_block
fill 20 125 295 20 125 297 minecraft:magma_block
setblock 20 125 302 minecraft:magma_block
setblock 21 125 284 minecraft:bone_block
fill 21 125 290 21 125 292 minecraft:basalt
setblock 21 125 293 minecraft:magma_block
setblock 21 125 295 minecraft:magma_block
fill 21 125 296 21 125 297 minecraft:basalt
setblock 21 125 308 minecraft:bone_block
fill 22 125 275 22 129 275 minecraft:cobbled_deepslate
setblock 22 125 285 minecraft:bone_block
setblock 22 125 286 minecraft:basalt
setblock 23 125 286 minecraft:bone_block
setblock 23 125 289 minecraft:magma_block
setblock 23 125 292 minecraft:magma_block
setblock 23 125 294 minecraft:basalt
setblock 23 125 295 minecraft:magma_block
fill 23 125 296 23 125 297 minecraft:basalt
setblock 23 125 298 minecraft:magma_block
setblock 23 125 301 minecraft:magma_block
setblock 24 125 285 minecraft:bone_block
setblock 24 125 287 minecraft:bone_block
fill 24 125 289 24 125 290 minecraft:basalt
setblock 24 125 299 minecraft:basalt
setblock 24 125 307 minecraft:bone_block
setblock 25 125 286 minecraft:bone_block
fill 25 125 289 28 125 289 minecraft:bone_block
setblock 25 125 297 minecraft:basalt
setblock 25 125 306 minecraft:bone_block
fill 26 125 287 26 125 288 minecraft:bone_block
fill 26 125 290 27 125 290 minecraft:bone_block
setblock 26 125 305 minecraft:bone_block
setblock 26 125 309 minecraft:red_nether_bricks
setblock 27 125 288 minecraft:bone_block
fill 27 125 291 27 125 294 minecraft:bone_block
setblock 27 125 296 minecraft:bone_block
setblock 27 125 304 minecraft:bone_block
setblock 27 125 309 minecraft:nether_wart_block
fill 27 125 310 27 126 310 minecraft:red_nether_bricks
setblock 28 125 303 minecraft:bone_block
fill 28 125 307 28 126 307 minecraft:red_nether_bricks
setblock 28 125 311 minecraft:red_nether_bricks
fill 29 125 293 29 125 299 minecraft:bone_block
setblock 29 125 306 minecraft:red_nether_bricks
setblock 29 125 307 minecraft:nether_wart_block
fill 29 125 308 29 126 309 minecraft:red_nether_bricks
setblock 29 125 311 minecraft:nether_wart_block
setblock 30 125 307 minecraft:red_nether_bricks
setblock 30 125 308 minecraft:nether_wart_block
fill 30 125 309 30 127 309 minecraft:red_nether_bricks
fill 31 125 285 31 128 285 minecraft:bone_block
setblock 31 125 305 minecraft:nether_wart_block
fill 31 125 306 31 127 306 minecraft:red_nether_bricks
fill 31 125 307 33 125 307 minecraft:orange_terracotta
setblock 31 125 309 minecraft:nether_wart_block
fill 31 125 310 31 126 310 minecraft:red_nether_bricks
fill 32 125 286 32 127 286 minecraft:bone_block
fill 32 125 305 32 126 306 minecraft:orange_terracotta
fill 32 125 308 33 126 308 minecraft:red_nether_bricks
fill 33 125 304 33 126 305 minecraft:orange_terracotta
fill 34 125 305 34 126 306 minecraft:orange_terracotta
setblock 34 125 307 minecraft:red_nether_bricks
setblock 39 125 275 minecraft:purple_concrete
fill 40 125 275 42 125 275 minecraft:cobbled_deepslate
fill 42 125 306 42 129 306 minecraft:cobbled_deepslate
setblock 0 126 280 minecraft:blackstone
fill 0 126 291 0 127 291 minecraft:cobbled_deepslate
fill 0 126 292 0 126 293 minecraft:blackstone
fill 1 126 275 1 127 275 minecraft:blackstone
fill 2 126 311 2 130 311 minecraft:blackstone
fill 3 126 278 3 127 278 minecraft:light[level=12]
setblock 3 126 285 minecraft:light[level=12]
setblock 3 126 292 minecraft:light[level=12]
setblock 3 126 299 minecraft:light[level=12]
setblock 3 126 306 minecraft:light[level=12]
fill 3 126 310 3 130 310 minecraft:blackstone
fill 3 126 312 3 130 312 minecraft:blackstone
setblock 3 126 313 minecraft:light[level=12]
setblock 3 126 317 minecraft:blackstone
fill 4 126 311 4 130 311 minecraft:blackstone
setblock 5 126 317 minecraft:blackstone
setblock 7 126 275 minecraft:blackstone
setblock 10 126 278 minecraft:light[level=12]
fill 10 126 285 11 127 286 minecraft:bone_block
setblock 10 126 292 minecraft:light[level=12]
setblock 10 126 299 minecraft:light[level=12]
setblock 10 126 306 minecraft:light[level=12]
setblock 10 126 313 minecraft:light[level=12]
setblock 10 126 317 minecraft:blackstone
setblock 11 126 275 minecraft:blackstone
fill 11 126 287 12 126 287 minecraft:bone_block
setblock 12 126 286 minecraft:bone_block
setblock 12 126 317 minecraft:blackstone
setblock 13 126 317 minecraft:cobbled_deepslate
setblock 17 126 278 minecraft:light[level=12]
setblock 17 126 285 minecraft:light[level=12]
setblock 17 126 292 minecraft:light[level=12]
setblock 17 126 299 minecraft:light[level=12]
setblock 17 126 306 minecraft:light[level=12]
setblock 17 126 313 minecraft:light[level=12]
setblock 24 126 278 minecraft:light[level=12]
setblock 24 126 285 minecraft:light[level=12]
setblock 24 126 292 minecraft:light[level=12]
setblock 24 126 299 minecraft:light[level=12]
setblock 24 126 306 minecraft:light[level=12]
setblock 24 126 313 minecraft:light[level=12]
setblock 26 126 317 minecraft:blackstone
setblock 27 126 309 minecraft:red_nether_bricks
setblock 29 126 306 minecraft:nether_wart_block
fill 29 126 307 29 127 307 minecraft:red_nether_bricks
setblock 29 126 310 minecraft:nether_wart_block
fill 30 126 286 31 126 287 minecraft:bone_block
fill 30 126 305 31 127 305 minecraft:red_nether_bricks
setblock 30 126 307 minecraft:nether_wart_block
fill 30 126 308 30 127 308 minecraft:red_nether_bricks
setblock 31 126 278 minecraft:light[level=12]
setblock 31 126 292 minecraft:light[level=12]
setblock 31 126 299 minecraft:light[level=12]
setblock 31 126 304 minecraft:nether_wart_block
fill 31 126 307 33 126 307 minecraft:red_nether_bricks
setblock 31 126 308 minecraft:nether_wart_block
fill 31 126 309 31 127 309 minecraft:red_nether_bricks
setblock 31 126 313 minecraft:light[level=12]
fill 32 126 285 32 129 285 minecraft:bone_block
setblock 32 126 304 minecraft:red_nether_bricks
setblock 32 126 309 minecraft:nether_wart_block
fill 33 126 303 33 128 303 minecraft:red_nether_bricks
setblock 33 126 309 minecraft:red_nether_bricks
setblock 33 126 317 minecraft:blackstone
fill 34 126 275 34 127 275 minecraft:cobbled_deepslate
fill 34 126 303 35 127 304 minecraft:orange_terracotta
setblock 34 126 307 minecraft:nether_wart_block
fill 34 126 308 34 127 308 minecraft:red_nether_bricks
fill 34 126 317 35 129 317 minecraft:cobbled_deepslate
setblock 35 126 275 minecraft:blackstone
fill 35 126 302 35 128 302 minecraft:orange_terracotta
fill 35 126 305 35 127 306 minecraft:red_nether_bricks
fill 37 126 317 37 129 317 minecraft:cobbled_deepslate
setblock 38 126 278 minecraft:light[level=12]
setblock 38 126 285 minecraft:light[level=12]
setblock 38 126 292 minecraft:light[level=12]
setblock 38 126 299 minecraft:light[level=12]
setblock 38 126 306 minecraft:light[level=12]
setblock 38 126 313 minecraft:light[level=12]
setblock 38 126 317 minecraft:blackstone
fill 39 126 275 39 129 275 minecraft:cobbled_deepslate
setblock 40 126 275 minecraft:blackstone
fill 41 126 275 42 129 275 minecraft:cobbled_deepslate
setblock 42 126 276 minecraft:blackstone
setblock 42 126 280 minecraft:blackstone
setblock 42 126 283 minecraft:blackstone
setblock 42 126 300 minecraft:amethyst_block
setblock 0 127 275 minecraft:blackstone
fill 0 127 276 0 129 276 minecraft:cobbled_deepslate
fill 0 127 280 0 129 280 minecraft:cobbled_deepslate
fill 0 127 290 0 128 290 minecraft:blackstone
fill 0 127 292 0 127 293 minecraft:cobbled_deepslate
fill 0 127 307 0 128 307 minecraft:blackstone
setblock 0 127 317 minecraft:blackstone
setblock 2 127 275 minecraft:blackstone
setblock 3 127 286 minecraft:light[level=12]
setblock 3 127 294 minecraft:light[level=12]
setblock 3 127 302 minecraft:light[level=12]
fill 3 127 317 3 129 317 minecraft:cobbled_deepslate
fill 5 127 317 5 129 317 minecraft:cobbled_deepslate
fill 7 127 275 7 129 275 minecraft:cobbled_deepslate
fill 10 127 284 11 128 284 minecraft:bone_block
fill 10 127 317 10 129 317 minecraft:cobbled_deepslate
fill 11 127 275 11 129 275 minecraft:cobbled_deepslate
setblock 11 127 278 minecraft:light[level=12]
setblock 11 127 294 minecraft:light[level=12]
setblock 11 127 302 minecraft:light[level=12]
setblock 11 127 310 minecraft:light[level=12]
fill 12 127 317 12 129 317 minecraft:cobbled_deepslate
setblock 13 127 317 minecraft:blackstone
setblock 19 127 275 minecraft:blackstone
setblock 19 127 278 minecraft:light[level=12]
setblock 19 127 286 minecraft:light[level=12]
setblock 19 127 294 minecraft:light[level=12]
setblock 19 127 302 minecraft:light[level=12]
setblock 19 127 310 minecraft:light[level=12]
setblock 24 127 275 minecraft:cobbled_deepslate
setblock 25 127 275 minecraft:blackstone
fill 26 127 275 26 129 275 minecraft:cobbled_deepslate
fill 26 127 317 26 129 317 minecraft:cobbled_deepslate
setblock 27 127 278 minecraft:light[level=12]
setblock 27 127 286 minecraft:light[level=12]
setblock 27 127 294 minecraft:light[level=12]
setblock 27 127 302 minecraft:light[level=12]
setblock 27 127 310 minecraft:light[level=12]
fill 28 127 275 29 129 275 minecraft:cobbled_deepslate
setblock 29 127 308 minecraft:red_nether_bricks
setblock 29 127 309 minecraft:nether_wart_block
setblock 30 127 275 minecraft:blackstone
setblock 30 127 306 minecraft:nether_wart_block
fill 30 127 307 30 128 307 minecraft:red_nether_bricks
fill 31 127 284 32 128 284 minecraft:bone_block
setblock 31 127 286 minecraft:bone_block
fill 31 127 304 31 128 304 minecraft:red_nether_bricks
setblock 31 127 307 minecraft:nether_wart_block
fill 31 127 308 31 128 308 minecraft:red_nether_bricks
setblock 32 127 303 minecraft:red_nether_bricks
setblock 32 127 304 minecraft:nether_wart_block
fill 32 127 305 32 127 307 minecraft:red_nether_bricks
setblock 32 127 308 minecraft:nether_wart_block
setblock 32 127 309 minecraft:red_nether_bricks
setblock 32 127 317 minecraft:blackstone
fill 33 127 302 33 129 302 minecraft:red_nether_bricks
setblock 33 127 304 minecraft:red_nether_bricks
setblock 33 127 305 minecraft:orange_terracotta
fill 33 127 306 33 127 308 minecraft:red_nether_bricks
setblock 33 127 317 minecraft:cobbled_deepslate
setblock 34 127 301 minecraft:red_nether_bricks
fill 34 127 302 34 128 302 minecraft:orange_terracotta
setblock 34 127 305 minecraft:red_nether_bricks
setblock 34 127 306 minecraft:nether_wart_block
fill 34 127 307 34 128 307 minecraft:red_nether_bricks
fill 35 127 275 35 129 275 minecraft:cobbled_deepslate
setblock 35 127 278 minecraft:light[level=12]
setblock 35 127 286 minecraft:light[level=12]
setblock 35 127 294 minecraft:light[level=12]
fill 35 127 301 35 128 301 minecraft:orange_terracotta
setblock 35 127 310 minecraft:light[level=12]
setblock 36 127 275 minecraft:blackstone
fill 36 127 301 36 128 301 minecraft:red_nether_bricks
fill 36 127 302 36 127 303 minecraft:orange_terracotta
setblock 36 127 304 minecraft:nether_wart_block
fill 36 127 305 36 129 305 minecraft:red_nether_bricks
setblock 38 127 275 minecraft:blackstone
fill 38 127 317 38 129 317 minecraft:cobbled_deepslate
fill 40 127 275 40 129 275 minecraft:cobbled_deepslate
fill 42 127 276 42 129 276 minecraft:cobbled_deepslate
fill 42 127 280 42 129 280 minecraft:cobbled_deepslate
fill 42 127 283 42 129 283 minecraft:cobbled_deepslate
fill 42 127 297 42 128 297 minecraft:blackstone
fill 42 127 300 42 129 300 minecraft:cobbled_deepslate
setblock 42 127 308 minecraft:blackstone
setblock 42 127 313 minecraft:blackstone
fill 0 128 275 2 129 275 minecraft:cobbled_deepslate
fill 0 128 291 0 128 292 minecraft:blackstone
fill 0 128 293 0 129 293 minecraft:cobbled_deepslate
setblock 0 128 297 minecraft:blackstone
setblock 0 128 304 minecraft:blackstone
fill 0 128 308 0 129 308 minecraft:cobbled_deepslate
setblock 0 128 309 minecraft:blackstone
fill 0 128 317 0 130 317 minecraft:cobbled_deepslate
setblock 8 128 275 minecraft:blackstone
fill 9 128 283 9 128 285 minecraft:bone_block
fill 10 128 283 10 130 283 minecraft:bone_block
fill 10 128 285 11 128 285 minecraft:bone_block
fill 13 128 317 13 129 317 minecraft:cobbled_deepslate
setblock 14 128 317 minecraft:blackstone
setblock 18 128 275 minecraft:blackstone
setblock 18 128 317 minecraft:blackstone
fill 19 128 275 19 129 275 minecraft:cobbled_deepslate
fill 19 128 317 19 129 317 minecraft:cobbled_deepslate
setblock 24 128 275 minecraft:blackstone
fill 25 128 275 25 129 275 minecraft:cobbled_deepslate
setblock 27 128 317 minecraft:blackstone
fill 30 128 275 30 129 275 minecraft:cobbled_deepslate
fill 31 128 305 32 128 305 minecraft:red_nether_bricks
setblock 31 128 306 minecraft:nether_wart_block
setblock 31 128 307 minecraft:red_nether_bricks
fill 32 128 283 33 130 283 minecraft:bone_block
setblock 32 128 303 minecraft:nether_wart_block
fill 32 128 304 32 129 304 minecraft:red_nether_bricks
fill 32 128 306 34 128 306 minecraft:red_nether_bricks
setblock 32 128 307 minecraft:nether_wart_block
setblock 32 128 308 minecraft:red_nether_bricks
fill 32 128 317 32 129 317 minecraft:cobbled_deepslate
fill 33 128 284 33 128 285 minecraft:bone_block
fill 33 128 301 33 130 301 minecraft:red_nether_bricks
setblock 33 128 304 minecraft:nether_wart_block
fill 33 128 305 33 131 305 minecraft:bone_block
setblock 33 128 307 minecraft:red_nether_bricks
setblock 33 128 308 minecraft:nether_wart_block
setblock 33 128 317 minecraft:blackstone
setblock 34 128 275 minecraft:amethyst_block
setblock 34 128 300 minecraft:red_nether_bricks
setblock 34 128 301 minecraft:nether_wart_block
fill 34 128 303 35 128 303 minecraft:orange_terracotta
fill 34 128 304 36 128 304 minecraft:red_nether_bricks
setblock 34 128 305 minecraft:nether_wart_block
fill 35 128 299 36 129 300 minecraft:orange_terracotta
setblock 35 128 305 minecraft:red_nether_bricks
setblock 35 128 306 minecraft:nether_wart_block
fill 36 128 275 36 129 275 minecraft:cobbled_deepslate
fill 36 128 298 36 130 298 minecraft:orange_terracotta
setblock 36 128 302 minecraft:orange_terracotta
setblock 36 128 303 minecraft:nether_wart_block
setblock 36 128 317 minecraft:blackstone
setblock 37 128 300 minecraft:nether_wart_block
fill 37 128 301 37 128 303 minecraft:red_nether_bricks
fill 38 128 275 38 129 275 minecraft:cobbled_deepslate
fill 42 128 286 42 129 288 minecraft:cobbled_deepslate
setblock 42 128 289 minecraft:blackstone
setblock 42 128 295 minecraft:blackstone
fill 42 128 296 42 129 296 minecraft:cobbled_deepslate
setblock 42 128 298 minecraft:blackstone
setblock 42 128 303 minecraft:blackstone
setblock 42 128 307 minecraft:blackstone
fill 42 128 308 42 129 308 minecraft:cobbled_deepslate
setblock 42 128 312 minecraft:blackstone
fill 42 128 313 42 129 313 minecraft:cobbled_deepslate
setblock 42 128 315 minecraft:blackstone
setblock 0 129 281 minecraft:magma_block
fill 0 129 290 0 129 292 minecraft:cobbled_deepslate
setblock 0 129 297 minecraft:cobbled_deepslate
setblock 0 129 304 minecraft:cobbled_deepslate
setblock 0 129 307 minecraft:cobbled_deepslate
setblock 0 129 309 minecraft:cobbled_deepslate
fill 2 129 310 2 130 310 minecraft:blackstone
fill 2 129 312 2 130 312 minecraft:blackstone
fill 4 129 310 4 130 310 minecraft:blackstone
fill 4 129 312 4 130 312 minecraft:blackstone
setblock 8 129 275 minecraft:cobbled_deepslate
fill 9 129 282 9 130 284 minecraft:bone_block
fill 10 129 284 10 129 285 minecraft:bone_block
setblock 14 129 317 minecraft:cobbled_deepslate
setblock 18 129 275 minecraft:cobbled_deepslate
setblock 18 129 317 minecraft:cobbled_deepslate
setblock 24 129 275 minecraft:cobbled_deepslate
setblock 27 129 317 minecraft:cobbled_deepslate
fill 32 129 284 33 130 284 minecraft:bone_block
setblock 32 129 303 minecraft:red_nether_bricks
setblock 32 129 305 minecraft:red_nether_bricks
setblock 32 129 306 minecraft:nether_wart_block
setblock 32 129 307 minecraft:red_nether_bricks
fill 33 129 282 33 132 282 minecraft:bone_block
setblock 33 129 303 minecraft:nether_wart_block
fill 33 129 304 33 130 304 minecraft:red_nether_bricks
fill 33 129 306 35 129 306 minecraft:red_nether_bricks
setblock 33 129 307 minecraft:nether_wart_block
setblock 33 129 317 minecraft:cobbled_deepslate
fill 34 129 275 34 130 275 minecraft:cobbled_deepslate
setblock 34 129 299 minecraft:red_nether_bricks
setblock 34 129 300 minecraft:nether_wart_block
fill 34 129 301 34 129 303 minecraft:red_nether_bricks
setblock 34 129 304 minecraft:nether_wart_block
fill 34 129 305 34 130 305 minecraft:red_nether_bricks
fill 35 129 298 35 130 298 minecraft:orange_terracotta
setblock 35 129 301 minecraft:nether_wart_block
fill 35 129 302 35 129 304 minecraft:red_nether_bricks
setblock 35 129 305 minecraft:nether_wart_block
fill 36 129 297 37 129 297 minecraft:red_nether_bricks
setblock 36 129 301 minecraft:orange_terracotta
setblock 36 129 302 minecraft:nether_wart_block
fill 36 129 303 36 130 304 minecraft:red_nether_bricks
setblock 36 129 317 minecraft:cobbled_deepslate
fill 37 129 298 37 129 300 minecraft:orange_terracotta
fill 37 129 301 37 129 302 minecraft:red_nether_bricks
setblock 37 129 303 minecraft:nether_wart_block
setblock 42 129 289 minecraft:cobbled_deepslate
setblock 42 129 295 minecraft:cobbled_deepslate
fill 42 129 297 42 129 298 minecraft:cobbled_deepslate
setblock 42 129 303 minecraft:cobbled_deepslate
setblock 42 129 307 minecraft:cobbled_deepslate
setblock 42 129 312 minecraft:cobbled_deepslate
setblock 42 129 315 minecraft:cobbled_deepslate
fill 0 130 275 0 130 281 minecraft:blackstone
fill 0 130 283 0 159 284 minecraft:blackstone
fill 0 130 286 0 130 316 minecraft:blackstone
fill 1 130 275 2 151 275 minecraft:blackstone
fill 1 130 317 1 219 317 minecraft:blackstone
fill 3 130 317 7 131 317 minecraft:blackstone
fill 4 130 275 19 131 275 minecraft:blackstone
fill 8 130 282 8 131 283 minecraft:bone_block
setblock 8 130 317 minecraft:cobbled_deepslate
fill 9 130 317 38 130 317 minecraft:blackstone
setblock 10 130 282 minecraft:bone_block
setblock 10 130 284 minecraft:bone_block
fill 21 130 275 28 130 275 minecraft:blackstone
setblock 29 130 275 minecraft:cobbled_deepslate
fill 30 130 275 33 130 275 minecraft:blackstone
setblock 32 130 282 minecraft:bone_block
fill 33 130 300 34 130 300 minecraft:red_nether_bricks
setblock 33 130 302 minecraft:nether_wart_block
setblock 33 130 303 minecraft:red_nether_bricks
fill 34 130 282 34 131 283 minecraft:bone_block
fill 34 130 297 34 130 298 minecraft:red_nether_bricks
setblock 34 130 299 minecraft:nether_wart_block
fill 34 130 301 35 130 302 minecraft:red_nether_bricks
setblock 34 130 303 minecraft:nether_wart_block
setblock 34 130 304 minecraft:red_nether_bricks
fill 35 130 275 42 130 275 minecraft:blackstone
fill 35 130 296 37 131 296 minecraft:orange_terracotta
fill 35 130 297 35 132 297 minecraft:red_nether_bricks
fill 35 130 299 37 130 299 minecraft:orange_terracotta
setblock 35 130 300 minecraft:nether_wart_block
setblock 35 130 303 minecraft:red_nether_bricks
setblock 35 130 304 minecraft:nether_wart_block
setblock 35 130 305 minecraft:red_nether_bricks
fill 36 130 295 37 132 295 minecraft:orange_terracotta
fill 36 130 297 37 131 297 minecraft:orange_terracotta
setblock 36 130 300 minecraft:orange_terracotta
setblock 36 130 301 minecraft:nether_wart_block
fill 36 130 302 36 131 302 minecraft:red_nether_bricks
setblock 37 130 298 minecraft:nether_wart_block
fill 37 130 300 38 130 301 minecraft:red_nether_bricks
setblock 37 130 302 minecraft:nether_wart_block
setblock 37 130 303 minecraft:red_nether_bricks
fill 38 130 297 38 130 298 minecraft:red_nether_bricks
setblock 38 130 299 minecraft:nether_wart_block
fill 40 130 317 42 215 317 minecraft:blackstone
fill 42 130 276 42 130 289 minecraft:blackstone
fill 42 130 291 42 130 309 minecraft:blackstone
fill 42 130 311 42 130 316 minecraft:blackstone
fill 0 131 275 0 131 280 minecraft:blackstone
setblock 0 131 281 minecraft:cobbled_deepslate
fill 0 131 282 0 160 282 minecraft:blackstone
fill 0 131 285 0 131 288 minecraft:blackstone
setblock 0 131 289 minecraft:cobbled_deepslate
fill 0 131 290 0 131 307 minecraft:blackstone
setblock 0 131 308 minecraft:amethyst_block
fill 0 131 309 0 131 313 minecraft:blackstone
setblock 0 131 314 minecraft:cobbled_deepslate
fill 0 131 315 0 131 317 minecraft:blackstone
fill 2 131 317 2 219 317 minecraft:blackstone
fill 3 131 275 3 202 275 minecraft:blackstone
fill 8 131 281 9 133 281 minecraft:bone_block
fill 8 131 317 8 219 317 minecraft:blackstone
fill 9 131 282 9 131 283 minecraft:bone_block
setblock 9 131 317 minecraft:magma_block
fill 10 131 317 27 131 317 minecraft:blackstone
fill 16 131 279 16 132 280 minecraft:raw_gold_block
fill 20 131 275 27 158 275 minecraft:blackstone
setblock 28 131 275 minecraft:cobbled_deepslate
setblock 28 131 317 minecraft:cobbled_deepslate
fill 29 131 275 29 171 275 minecraft:blackstone
fill 29 131 317 31 184 317 minecraft:blackstone
setblock 30 131 275 minecraft:cobbled_deepslate
fill 31 131 275 38 131 275 minecraft:blackstone
setblock 32 131 317 minecraft:cobbled_deepslate
fill 33 131 281 34 133 281 minecraft:bone_block
setblock 33 131 283 minecraft:bone_block
fill 33 131 317 39 131 317 minecraft:blackstone
fill 34 131 296 34 131 297 minecraft:red_nether_bricks
setblock 34 131 298 minecraft:nether_wart_block
fill 34 131 299 34 131 301 minecraft:red_nether_bricks
setblock 34 131 302 minecraft:nether_wart_block
setblock 34 131 303 minecraft:red_nether_bricks
setblock 35 131 294 minecraft:red_nether_bricks
setblock 35 131 295 minecraft:orange_terracotta
setblock 35 131 298 minecraft:red_nether_bricks
setblock 35 131 299 minecraft:nether_wart_block
fill 35 131 300 35 131 302 minecraft:red_nether_bricks
setblock 35 131 303 minecraft:nether_wart_block
fill 36 131 293 36 132 294 minecraft:orange_terracotta
fill 36 131 298 36 134 299 minecraft:bone_block
setblock 36 131 300 minecraft:nether_wart_block
fill 36 131 301 36 132 301 minecraft:red_nether_bricks
setblock 36 131 303 minecraft:red_nether_bricks
setblock 37 131 293 minecraft:nether_wart_block
setblock 37 131 294 minecraft:orange_terracotta
fill 37 131 298 37 131 300 minecraft:red_nether_bricks
setblock 37 131 301 minecraft:nether_wart_block
setblock 37 131 302 minecraft:red_nether_bricks
fill 38 131 295 38 131 297 minecraft:red_nether_bricks
setblock 38 131 298 minecraft:nether_wart_block
fill 38 131 299 38 131 300 minecraft:red_nether_bricks
fill 39 131 275 39 132 275 minecraft:cobbled_deepslate
setblock 40 131 275 minecraft:blackstone
setblock 41 131 275 minecraft:cobbled_deepslate
fill 42 131 275 42 131 277 minecraft:blackstone
fill 42 131 278 42 132 278 minecraft:cobbled_deepslate
fill 42 131 279 42 165 280 minecraft:blackstone
setblock 42 131 281 minecraft:crying_obsidian
fill 42 131 282 42 132 282 minecraft:cobbled_deepslate
fill 42 131 283 42 131 289 minecraft:blackstone
fill 42 131 291 42 216 291 minecraft:blackstone
setblock 42 131 292 minecraft:cobbled_deepslate
fill 42 131 293 42 131 303 minecraft:blackstone
setblock 42 131 304 minecraft:cobbled_deepslate
fill 42 131 305 42 144 307 minecraft:blackstone
setblock 42 131 308 minecraft:cobbled_deepslate
fill 42 131 309 42 201 309 minecraft:blackstone
fill 42 131 311 42 137 313 minecraft:blackstone
setblock 42 131 314 minecraft:cobbled_deepslate
fill 42 131 315 42 139 316 minecraft:blackstone
fill 0 132 275 0 215 276 minecraft:blackstone
fill 0 132 277 0 132 278 minecraft:cobbled_deepslate
fill 0 132 279 0 169 281 minecraft:blackstone
fill 0 132 285 0 150 287 minecraft:blackstone
setblock 0 132 288 minecraft:cobbled_deepslate
fill 0 132 289 0 142 304 minecraft:blackstone
setblock 0 132 305 minecraft:cobbled_deepslate
fill 0 132 306 0 137 307 minecraft:blackstone
setblock 0 132 308 minecraft:cobbled_deepslate
fill 0 132 309 0 216 310 minecraft:blackstone
setblock 0 132 311 minecraft:cobbled_deepslate
fill 0 132 312 0 204 314 minecraft:blackstone
setblock 0 132 315 minecraft:cobbled_deepslate
fill 0 132 316 0 215 317 minecraft:blackstone
setblock 3 132 278 minecraft:light[level=12]
setblock 3 132 285 minecraft:light[level=12]
setblock 3 132 292 minecraft:light[level=12]
setblock 3 132 299 minecraft:light[level=12]
setblock 3 132 306 minecraft:light[level=12]
setblock 3 132 313 minecraft:light[level=12]
fill 3 132 317 4 143 317 minecraft:blackstone
fill 4 132 275 13 134 275 minecraft:blackstone
setblock 5 132 317 minecraft:cobbled_deepslate
fill 6 132 317 7 185 317 minecraft:blackstone
fill 7 132 280 7 134 281 minecraft:bone_block
fill 8 132 280 8 134 280 minecraft:bone_block
fill 8 132 282 9 132 282 minecraft:bone_block
fill 9 132 317 17 141 317 minecraft:blackstone
setblock 10 132 278 minecraft:light[level=12]
setblock 10 132 285 minecraft:light[level=12]
setblock 10 132 292 minecraft:light[level=12]
setblock 10 132 299 minecraft:light[level=12]
setblock 10 132 306 minecraft:light[level=12]
setblock 10 132 313 minecraft:light[level=12]
setblock 14 132 275 minecraft:cobbled_deepslate
fill 15 132 275 19 147 275 minecraft:blackstone
setblock 17 132 278 minecraft:light[level=12]
setblock 17 132 285 minecraft:light[level=12]
setblock 17 132 292 minecraft:light[level=12]
setblock 17 132 299 minecraft:light[level=12]
setblock 17 132 306 minecraft:light[level=12]
setblock 17 132 313 minecraft:light[level=12]
setblock 18 132 317 minecraft:cobbled_deepslate
fill 19 132 317 23 181 317 minecraft:blackstone
setblock 24 132 278 minecraft:light[level=12]
setblock 24 132 285 minecraft:light[level=12]
setblock 24 132 292 minecraft:light[level=12]
setblock 24 132 299 minecraft:light[level=12]
setblock 24 132 306 minecraft:light[level=12]
setblock 24 132 313 minecraft:light[level=12]
setblock 24 132 317 minecraft:cobbled_deepslate
fill 25 132 317 28 215 317 minecraft:blackstone
fill 28 132 275 28 219 275 minecraft:blackstone
fill 30 132 275 33 167 275 minecraft:blackstone
setblock 31 132 278 minecraft:light[level=12]
setblock 31 132 285 minecraft:light[level=12]
setblock 31 132 292 minecraft:light[level=12]
setblock 31 132 299 minecraft:light[level=12]
setblock 31 132 306 minecraft:light[level=12]
setblock 31 132 313 minecraft:light[level=12]
fill 32 132 317 36 133 317 minecraft:blackstone
setblock 34 132 275 minecraft:cobbled_deepslate
fill 34 132 280 35 134 280 minecraft:bone_block
fill 34 132 282 34 133 282 minecraft:bone_block
setblock 34 132 293 minecraft:nether_wart_block
fill 34 132 294 34 132 296 minecraft:red_nether_bricks
setblock 34 132 297 minecraft:nether_wart_block
fill 34 132 298 34 132 300 minecraft:red_nether_bricks
fill 35 132 275 37 146 275 minecraft:blackstone
fill 35 132 281 35 134 281 minecraft:bone_block
fill 35 132 291 35 133 293 minecraft:orange_terracotta
setblock 35 132 294 minecraft:nether_wart_block
fill 35 132 295 35 133 296 minecraft:red_nether_bricks
setblock 35 132 298 minecraft:nether_wart_block
fill 35 132 299 35 132 301 minecraft:red_nether_bricks
fill 36 132 291 36 133 292 minecraft:orange_terracotta
setblock 36 132 296 minecraft:orange_terracotta
fill 36 132 297 37 133 297 minecraft:red_nether_bricks
fill 36 132 300 36 133 300 minecraft:red_nether_bricks
fill 37 132 292 37 133 293 minecraft:orange_terracotta
fill 37 132 294 38 133 294 minecraft:red_nether_bricks
setblock 37 132 296 minecraft:nether_wart_block
fill 37 132 298 38 132 299 minecraft:red_nether_bricks
setblock 37 132 300 minecraft:nether_wart_block
setblock 37 132 301 minecraft:red_nether_bricks
setblock 37 132 317 minecraft:cobbled_deepslate
setblock 38 132 275 minecraft:cobbled_deepslate
setblock 38 132 278 minecraft:light[level=12]
setblock 38 132 285 minecraft:light[level=12]
setblock 38 132 292 minecraft:light[level=12]
setblock 38 132 293 minecraft:nether_wart_block
fill 38 132 295 38 132 296 minecraft:red_nether_bricks
setblock 38 132 297 minecraft:nether_wart_block
setblock 38 132 306 minecraft:light[level=12]
setblock 38 132 313 minecraft:light[level=12]
fill 38 132 317 39 216 317 minecraft:blackstone
setblock 40 132 275 minecraft:cobbled_deepslate
fill 41 132 275 42 172 275 minecraft:blackstone
setblock 42 132 276 minecraft:cobbled_deepslate
fill 42 132 277 42 218 277 minecraft:blackstone
fill 42 132 281 42 159 281 minecraft:blackstone
fill 42 132 283 42 147 285 minecraft:blackstone
setblock 42 132 286 minecraft:cobbled_deepslate
fill 42 132 287 42 146 290 minecraft:blackstone
fill 42 132 292 42 216 294 minecraft:blackstone
setblock 42 132 295 minecraft:cobbled_deepslate
fill 42 132 296 42 154 299 minecraft:blackstone
fill 42 132 300 42 132 301 minecraft:cobbled_deepslate
fill 42 132 302 42 219 302 minecraft:blackstone
setblock 42 132 303 minecraft:cobbled_deepslate
fill 42 132 304 42 217 304 minecraft:blackstone
fill 42 132 308 42 202 308 minecraft:blackstone
fill 42 132 310 42 179 310 minecraft:blackstone
fill 42 132 314 42 219 314 minecraft:blackstone
fill 0 133 277 0 154 278 minecraft:blackstone
fill 0 133 288 0 203 288 minecraft:blackstone
fill 0 133 305 0 215 305 minecraft:blackstone
fill 0 133 308 0 219 308 minecraft:blackstone
fill 0 133 311 0 178 311 minecraft:blackstone
fill 0 133 315 0 171 315 minecraft:blackstone
fill 5 133 317 5 219 317 minecraft:blackstone
fill 7 133 279 8 134 279 minecraft:bone_block
setblock 8 133 282 minecraft:bone_block
fill 14 133 275 14 142 275 minecraft:blackstone
fill 18 133 317 18 219 317 minecraft:blackstone
fill 24 133 317 24 157 317 minecraft:blackstone
fill 34 133 275 34 219 275 minecraft:blackstone
fill 34 133 279 35 134 279 minecraft:bone_block
fill 34 133 289 35 135 290 minecraft:orange_terracotta
setblock 34 133 291 minecraft:red_nether_bricks
setblock 34 133 292 minecraft:nether_wart_block
fill 34 133 293 34 133 295 minecraft:red_nether_bricks
setblock 34 133 296 minecraft:nether_wart_block
setblock 34 133 297 minecraft:red_nether_bricks
fill 35 133 294 35 135 294 minecraft:red_nether_bricks
setblock 35 133 297 minecraft:nether_wart_block
fill 35 133 298 35 133 299 minecraft:red_nether_bricks
setblock 36 133 290 minecraft:nether_wart_block
setblock 36 133 293 minecraft:orange_terracotta
setblock 36 133 294 minecraft:nether_wart_block
fill 36 133 295 36 134 296 minecraft:red_nether_bricks
setblock 37 133 290 minecraft:red_nether_bricks
setblock 37 133 291 minecraft:nether_wart_block
setblock 37 133 295 minecraft:nether_wart_block
fill 37 133 296 37 134 296 minecraft:red_nether_bricks
fill 37 133 298 38 133 298 minecraft:red_nether_bricks
setblock 37 133 299 minecraft:nether_wart_block
fill 37 133 317 37 158 317 minecraft:blackstone
fill 38 133 275 40 152 275 minecraft:blackstone
setblock 38 133 292 minecraft:nether_wart_block
fill 38 133 293 38 135 293 minecraft:red_nether_bricks
setblock 38 133 295 minecraft:red_nether_bricks
setblock 38 133 296 minecraft:nether_wart_block
setblock 38 133 297 minecraft:red_nether_bricks
fill 42 133 276 42 153 276 minecraft:blackstone
fill 42 133 278 42 215 278 minecraft:blackstone
fill 42 133 282 42 217 282 minecraft:blackstone
fill 42 133 286 42 217 286 minecraft:blackstone
fill 42 133 295 42 217 295 minecraft:blackstone
fill 42 133 300 42 199 301 minecraft:blackstone
fill 42 133 303 42 219 303 minecraft:blackstone
setblock 3 134 278 minecraft:light[level=12]
setblock 3 134 286 minecraft:light[level=12]
setblock 3 134 294 minecraft:light[level=12]
setblock 3 134 302 minecraft:light[level=12]
setblock 3 134 310 minecraft:light[level=12]
setblock 8 134 281 minecraft:bone_block
setblock 11 134 278 minecraft:light[level=12]
setblock 11 134 286 minecraft:light[level=12]
setblock 11 134 294 minecraft:light[level=12]
setblock 11 134 302 minecraft:light[level=12]
setblock 11 134 310 minecraft:light[level=12]
setblock 19 134 278 minecraft:light[level=12]
setblock 19 134 286 minecraft:light[level=12]
setblock 19 134 294 minecraft:light[level=12]
setblock 19 134 302 minecraft:light[level=12]
setblock 19 134 310 minecraft:light[level=12]
setblock 27 134 278 minecraft:light[level=12]
setblock 27 134 286 minecraft:light[level=12]
setblock 27 134 294 minecraft:light[level=12]
setblock 27 134 302 minecraft:light[level=12]
setblock 27 134 310 minecraft:light[level=12]
fill 32 134 317 33 176 317 minecraft:blackstone
fill 33 134 288 35 135 288 minecraft:orange_terracotta
setblock 33 134 289 minecraft:red_nether_bricks
setblock 33 134 290 minecraft:nether_wart_block
fill 33 134 291 33 136 291 minecraft:red_nether_bricks
setblock 34 134 281 minecraft:bone_block
setblock 34 134 291 minecraft:nether_wart_block
fill 34 134 292 34 134 294 minecraft:red_nether_bricks
setblock 34 134 295 minecraft:nether_wart_block
setblock 34 134 317 minecraft:purple_concrete
setblock 35 134 278 minecraft:light[level=12]
setblock 35 134 286 minecraft:light[level=12]
fill 35 134 291 37 134 291 minecraft:red_nether_bricks
fill 35 134 292 36 134 292 minecraft:orange_terracotta
fill 35 134 293 35 136 293 minecraft:red_nether_bricks
setblock 35 134 295 minecraft:red_nether_bricks
setblock 35 134 296 minecraft:nether_wart_block
setblock 35 134 297 minecraft:red_nether_bricks
setblock 35 134 302 minecraft:light[level=12]
setblock 35 134 310 minecraft:light[level=12]
fill 35 134 317 36 170 317 minecraft:blackstone
setblock 36 134 288 minecraft:red_nether_bricks
fill 36 134 289 36 134 290 minecraft:orange_terracotta
setblock 36 134 293 minecraft:nether_wart_block
fill 36 134 294 36 136 294 minecraft:red_nether_bricks
setblock 36 134 297 minecraft:nether_wart_block
setblock 37 134 289 minecraft:red_nether_bricks
setblock 37 134 290 minecraft:nether_wart_block
fill 37 134 292 37 134 293 minecraft:red_nether_bricks
setblock 37 134 294 minecraft:nether_wart_block
fill 37 134 295 37 135 295 minecraft:red_nether_bricks
setblock 37 134 297 minecraft:red_nether_bricks
setblock 38 134 291 minecraft:nether_wart_block
fill 38 134 292 38 135 292 minecraft:red_nether_bricks
setblock 38 134 294 minecraft:red_nether_bricks
setblock 38 134 295 minecraft:nether_wart_block
setblock 38 134 296 minecraft:red_nether_bricks
setblock 4 135 275 minecraft:amethyst_block
fill 5 135 275 13 176 275 minecraft:blackstone
fill 7 135 277 7 135 279 minecraft:bone_block
fill 26 135 284 26 136 286 minecraft:raw_gold_block
fill 27 135 285 27 136 285 minecraft:raw_gold_block
fill 32 135 286 33 137 287 minecraft:orange_terracotta
setblock 32 135 288 minecraft:nether_wart_block
fill 32 135 289 32 137 289 minecraft:red_nether_bricks
setblock 33 135 289 minecraft:orange_terracotta
fill 33 135 290 33 137 290 minecraft:red_nether_bricks
fill 33 135 292 34 135 292 minecraft:red_nether_bricks
setblock 34 135 286 minecraft:nether_wart_block
setblock 34 135 287 minecraft:red_nether_bricks
fill 34 135 291 34 137 291 minecraft:red_nether_bricks
setblock 34 135 293 minecraft:red_nether_bricks
setblock 34 135 294 minecraft:nether_wart_block
fill 34 135 317 34 217 317 minecraft:blackstone
fill 35 135 277 35 135 279 minecraft:bone_block
setblock 35 135 287 minecraft:nether_wart_block
setblock 35 135 291 minecraft:nether_wart_block
fill 35 135 292 36 137 292 minecraft:bone_block
setblock 35 135 295 minecraft:nether_wart_block
setblock 36 135 288 minecraft:nether_wart_block
fill 36 135 289 36 135 291 minecraft:red_nether_bricks
fill 36 135 293 36 136 293 minecraft:red_nether_bricks
setblock 36 135 295 minecraft:red_nether_bricks
setblock 36 135 296 minecraft:nether_wart_block
setblock 37 135 289 minecraft:nether_wart_block
fill 37 135 290 37 135 292 minecraft:red_nether_bricks
setblock 37 135 293 minecraft:nether_wart_block
setblock 37 135 294 minecraft:red_nether_bricks
setblock 38 135 291 minecraft:red_nether_bricks
setblock 38 135 294 minecraft:nether_wart_block
fill 4 136 275 4 219 275 minecraft:blackstone
fill 6 136 276 7 136 276 minecraft:bone_block
setblock 7 136 277 minecraft:bone_block
fill 31 136 285 31 137 286 minecraft:orange_terracotta
fill 31 136 287 31 138 287 minecraft:red_nether_bricks
fill 32 136 284 32 138 284 minecraft:red_nether_bricks
fill 32 136 285 33 137 285 minecraft:orange_terracotta
fill 32 136 288 32 138 288 minecraft:red_nether_bricks
setblock 33 136 288 minecraft:nether_wart_block
fill 33 136 289 33 138 289 minecraft:red_nether_bricks
setblock 34 136 285 minecraft:nether_wart_block
fill 34 136 286 34 136 287 minecraft:orange_terracotta
fill 34 136 288 36 136 288 minecraft:red_nether_bricks
setblock 34 136 289 minecraft:nether_wart_block
fill 34 136 290 34 138 290 minecraft:red_nether_bricks
setblock 34 136 292 minecraft:red_nether_bricks
setblock 34 136 293 minecraft:nether_wart_block
fill 35 136 276 35 136 277 minecraft:bone_block
setblock 35 136 286 minecraft:nether_wart_block
fill 35 136 287 35 138 287 minecraft:red_nether_bricks
fill 35 136 289 37 136 289 minecraft:red_nether_bricks
setblock 35 136 290 minecraft:nether_wart_block
fill 35 136 291 35 137 291 minecraft:red_nether_bricks
setblock 36 136 276 minecraft:bone_block
setblock 36 136 287 minecraft:nether_wart_block
fill 36 136 290 37 136 290 minecraft:red_nether_bricks
setblock 36 136 291 minecraft:nether_wart_block
setblock 37 136 291 minecraft:red_nether_bricks
setblock 37 136 292 minecraft:nether_wart_block
setblock 37 136 293 minecraft:red_nether_bricks
fill 29 137 283 31 138 284 minecraft:orange_terracotta
fill 30 137 285 30 138 285 minecraft:orange_terracotta
fill 30 137 286 30 138 286 minecraft:red_nether_bricks
setblock 31 137 288 minecraft:red_nether_bricks
fill 32 137 283 32 139 283 minecraft:red_nether_bricks
fill 33 137 284 33 139 284 minecraft:red_nether_bricks
fill 33 137 288 33 139 288 minecraft:red_nether_bricks
fill 34 137 285 34 137 287 minecraft:red_nether_bricks
setblock 34 137 288 minecraft:nether_wart_block
fill 34 137 289 34 138 289 minecraft:red_nether_bricks
fill 35 137 286 35 138 286 minecraft:red_nether_bricks
fill 35 137 288 36 137 288 minecraft:red_nether_bricks
setblock 35 137 289 minecraft:nether_wart_block
fill 35 137 290 35 138 290 minecraft:red_nether_bricks
setblock 36 137 287 minecraft:red_nether_bricks
setblock 36 137 289 minecraft:red_nether_bricks
setblock 36 137 290 minecraft:nether_wart_block
setblock 36 137 291 minecraft:red_nether_bricks
fill 0 138 306 0 140 306 minecraft:blackstone
setblock 0 138 307 minecraft:amethyst_block
setblock 3 138 278 minecraft:light[level=12]
setblock 3 138 285 minecraft:light[level=12]
setblock 3 138 292 minecraft:light[level=12]
setblock 3 138 299 minecraft:light[level=12]
setblock 3 138 306 minecraft:light[level=12]
setblock 3 138 313 minecraft:light[level=12]
setblock 10 138 278 minecraft:light[level=12]
setblock 10 138 285 minecraft:light[level=12]
setblock 10 138 292 minecraft:light[level=12]
setblock 10 138 299 minecraft:light[level=12]
setblock 10 138 306 minecraft:light[level=12]
setblock 10 138 313 minecraft:light[level=12]
setblock 17 138 278 minecraft:light[level=12]
setblock 17 138 285 minecraft:light[level=12]
setblock 17 138 299 minecraft:light[level=12]
setblock 17 138 306 minecraft:light[level=12]
setblock 17 138 313 minecraft:light[level=12]
setblock 24 138 278 minecraft:light[level=12]
setblock 24 138 285 minecraft:light[level=12]
setblock 24 138 292 minecraft:light[level=12]
setblock 24 138 299 minecraft:light[level=12]
setblock 24 138 306 minecraft:light[level=12]
setblock 24 138 313 minecraft:light[level=12]
fill 28 138 282 28 138 284 minecraft:red_nether_bricks
setblock 29 138 282 minecraft:orange_terracotta
setblock 29 138 285 minecraft:red_nether_bricks
setblock 29 138 286 minecraft:nether_wart_block
fill 30 138 282 31 138 282 minecraft:red_nether_bricks
setblock 30 138 287 minecraft:nether_wart_block
setblock 31 138 278 minecraft:light[level=12]
setblock 31 138 285 minecraft:orange_terracotta
fill 31 138 286 31 139 286 minecraft:red_nether_bricks
setblock 31 138 288 minecraft:nether_wart_block
setblock 31 138 292 minecraft:light[level=12]
setblock 31 138 299 minecraft:light[level=12]
setblock 31 138 306 minecraft:light[level=12]
setblock 31 138 313 minecraft:light[level=12]
fill 32 138 285 32 141 286 minecraft:bone_block
fill 32 138 287 33 139 287 minecraft:red_nether_bricks
setblock 32 138 289 minecraft:nether_wart_block
fill 33 138 283 33 139 283 minecraft:red_nether_bricks
fill 33 138 285 34 138 285 minecraft:red_nether_bricks
setblock 33 138 286 minecraft:nether_wart_block
setblock 34 138 284 minecraft:red_nether_bricks
setblock 34 138 286 minecraft:red_nether_bricks
setblock 34 138 287 minecraft:nether_wart_block
fill 34 138 288 34 139 288 minecraft:red_nether_bricks
setblock 35 138 288 minecraft:nether_wart_block
setblock 35 138 289 minecraft:red_nether_bricks
setblock 36 138 288 minecraft:red_nether_bricks
setblock 36 138 289 minecraft:nether_wart_block
setblock 36 138 292 minecraft:bone_block
setblock 38 138 278 minecraft:light[level=12]
setblock 38 138 285 minecraft:light[level=12]
setblock 38 138 292 minecraft:light[level=12]
setblock 38 138 299 minecraft:light[level=12]
setblock 38 138 306 minecraft:light[level=12]
setblock 38 138 313 minecraft:light[level=12]
fill 42 138 311 42 151 311 minecraft:blackstone
setblock 42 138 312 minecraft:crying_obsidian
fill 42 138 313 42 170 313 minecraft:blackstone
fill 0 139 307 0 158 307 minecraft:blackstone
fill 26 139 281 27 140 282 minecraft:orange_terracotta
setblock 26 139 283 minecraft:red_nether_bricks
fill 27 139 283 30 139 283 minecraft:orange_terracotta
fill 27 139 284 27 141 284 minecraft:red_nether_bricks
fill 28 139 281 28 141 281 minecraft:red_nether_bricks
fill 28 139 282 28 140 282 minecraft:orange_terracotta
setblock 28 139 284 minecraft:nether_wart_block
fill 28 139 285 28 141 285 minecraft:red_nether_bricks
setblock 29 139 281 minecraft:nether_wart_block
fill 29 139 282 29 141 282 minecraft:red_nether_bricks
fill 29 139 284 30 139 284 minecraft:orange_terracotta
setblock 29 139 285 minecraft:nether_wart_block
fill 29 139 286 29 140 286 minecraft:red_nether_bricks
setblock 30 139 281 minecraft:red_nether_bricks
setblock 30 139 282 minecraft:nether_wart_block
fill 30 139 285 31 139 285 minecraft:red_nether_bricks
setblock 30 139 286 minecraft:nether_wart_block
setblock 30 139 287 minecraft:red_nether_bricks
setblock 31 139 282 minecraft:red_nether_bricks
setblock 31 139 283 minecraft:nether_wart_block
fill 31 139 284 31 141 284 minecraft:red_nether_bricks
setblock 31 139 287 minecraft:nether_wart_block
setblock 32 139 284 minecraft:nether_wart_block
setblock 32 139 288 minecraft:nether_wart_block
setblock 33 139 285 minecraft:nether_wart_block
fill 33 139 286 33 140 286 minecraft:red_nether_bricks
setblock 34 139 285 minecraft:red_nether_bricks
setblock 34 139 286 minecraft:nether_wart_block
setblock 34 139 287 minecraft:red_nether_bricks
fill 42 139 312 42 192 312 minecraft:blackstone
fill 24 140 281 24 142 281 minecraft:orange_terracotta
setblock 24 140 282 minecraft:red_nether_bricks
setblock 25 140 280 minecraft:nether_wart_block
setblock 25 140 281 minecraft:red_nether_bricks
fill 25 140 282 25 141 282 minecraft:orange_terracotta
setblock 25 140 283 minecraft:red_nether_bricks
fill 26 140 280 28 140 280 minecraft:red_nether_bricks
fill 26 140 283 28 140 283 minecraft:orange_terracotta
setblock 26 140 284 minecraft:red_nether_bricks
fill 28 140 284 28 142 284 minecraft:red_nether_bricks
fill 29 140 281 29 142 281 minecraft:red_nether_bricks
fill 29 140 283 31 140 283 minecraft:red_nether_bricks
setblock 29 140 284 minecraft:nether_wart_block
fill 29 140 285 29 141 285 minecraft:red_nether_bricks
setblock 30 140 281 minecraft:nether_wart_block
fill 30 140 282 30 142 282 minecraft:red_nether_bricks
setblock 30 140 284 minecraft:red_nether_bricks
setblock 30 140 285 minecraft:nether_wart_block
setblock 30 140 286 minecraft:red_nether_bricks
setblock 31 140 282 minecraft:nether_wart_block
setblock 31 140 285 minecraft:red_nether_bricks
setblock 31 140 286 minecraft:nether_wart_block
setblock 31 140 287 minecraft:red_nether_bricks
setblock 32 140 283 minecraft:nether_wart_block
fill 32 140 284 32 141 284 minecraft:red_nether_bricks
setblock 32 140 287 minecraft:nether_wart_block
setblock 33 140 284 minecraft:nether_wart_block
setblock 33 140 285 minecraft:red_nether_bricks
setblock 33 140 287 minecraft:red_nether_bricks
setblock 42 140 315 minecraft:amethyst_block
fill 42 140 316 42 215 316 minecraft:blackstone
setblock 0 141 306 minecraft:purple_concrete
setblock 3 141 278 minecraft:light[level=12]
setblock 3 141 286 minecraft:light[level=12]
setblock 3 141 294 minecraft:light[level=12]
setblock 3 141 302 minecraft:light[level=12]
setblock 3 141 310 minecraft:light[level=12]
setblock 11 141 278 minecraft:light[level=12]
setblock 11 141 286 minecraft:light[level=12]
setblock 11 141 294 minecraft:light[level=12]
setblock 11 141 302 minecraft:light[level=12]
setblock 11 141 310 minecraft:light[level=12]
setblock 19 141 278 minecraft:light[level=12]
setblock 19 141 286 minecraft:light[level=12]
setblock 19 141 294 minecraft:light[level=12]
setblock 19 141 302 minecraft:light[level=12]
setblock 19 141 310 minecraft:light[level=12]
fill 22 141 281 23 142 281 minecraft:orange_terracotta
fill 23 141 280 24 142 280 minecraft:orange_terracotta
fill 23 141 282 24 142 282 minecraft:orange_terracotta
fill 24 141 283 24 143 283 minecraft:red_nether_bricks
fill 25 141 280 25 143 280 minecraft:red_nether_bricks
fill 25 141 281 26 141 281 minecraft:orange_terracotta
setblock 25 141 283 minecraft:nether_wart_block
setblock 26 141 280 minecraft:nether_wart_block
fill 26 141 282 27 141 282 minecraft:orange_terracotta
fill 26 141 283 28 141 283 minecraft:red_nether_bricks
setblock 26 141 284 minecraft:nether_wart_block
setblock 27 141 278 minecraft:light[level=12]
fill 27 141 280 28 141 280 minecraft:red_nether_bricks
setblock 27 141 281 minecraft:nether_wart_block
setblock 27 141 286 minecraft:light[level=12]
setblock 27 141 294 minecraft:light[level=12]
setblock 27 141 302 minecraft:light[level=12]
setblock 27 141 310 minecraft:light[level=12]
setblock 28 141 282 minecraft:nether_wart_block
setblock 29 141 283 minecraft:nether_wart_block
fill 29 141 284 29 142 284 minecraft:red_nether_bricks
setblock 30 141 281 minecraft:red_nether_bricks
fill 30 141 283 31 141 283 minecraft:red_nether_bricks
setblock 30 141 284 minecraft:nether_wart_block
setblock 30 141 285 minecraft:red_nether_bricks
setblock 31 141 282 minecraft:red_nether_bricks
setblock 31 141 285 minecraft:nether_wart_block
setblock 35 141 278 minecraft:light[level=12]
setblock 35 141 286 minecraft:light[level=12]
setblock 35 141 294 minecraft:light[level=12]
setblock 35 141 302 minecraft:light[level=12]
setblock 35 141 310 minecraft:light[level=12]
fill 42 141 315 42 148 315 minecraft:blackstone
fill 0 142 306 0 219 306 minecraft:blackstone
fill 9 142 317 12 154 317 minecraft:blackstone
setblock 13 142 317 minecraft:amethyst_block
fill 14 142 317 17 201 317 minecraft:blackstone
fill 20 142 280 21 143 281 minecraft:orange_terracotta
setblock 21 142 282 minecraft:nether_wart_block
setblock 22 142 279 minecraft:nether_wart_block
setblock 22 142 280 minecraft:orange_terracotta
setblock 22 142 282 minecraft:orange_terracotta
fill 23 142 279 25 142 279 minecraft:red_nether_bricks
setblock 23 142 283 minecraft:red_nether_bricks
setblock 25 142 281 minecraft:orange_terracotta
setblock 25 142 282 minecraft:nether_wart_block
fill 25 142 283 25 142 284 minecraft:red_nether_bricks
setblock 26 142 279 minecraft:nether_wart_block
fill 26 142 280 26 143 281 minecraft:red_nether_bricks
fill 26 142 282 26 145 282 minecraft:bone_block
setblock 26 142 283 minecraft:nether_wart_block
setblock 26 142 284 minecraft:red_nether_bricks
setblock 27 142 280 minecraft:nether_wart_block
fill 27 142 281 27 142 283 minecraft:red_nether_bricks
setblock 27 142 284 minecraft:nether_wart_block
setblock 28 142 280 minecraft:red_nether_bricks
setblock 28 142 281 minecraft:nether_wart_block
fill 28 142 282 28 143 283 minecraft:red_nether_bricks
setblock 29 142 282 minecraft:nether_wart_block
setblock 29 142 283 minecraft:red_nether_bricks
setblock 30 142 283 minecraft:nether_wart_block
setblock 30 142 284 minecraft:red_nether_bricks
fill 0 143 289 0 157 300 minecraft:blackstone
setblock 0 143 301 minecraft:magma_block
fill 0 143 302 0 181 304 minecraft:blackstone
fill 13 143 317 13 216 317 minecraft:blackstone
setblock 14 143 275 minecraft:purple_concrete
setblock 18 143 281 minecraft:red_nether_bricks
fill 19 143 280 19 144 282 minecraft:orange_terracotta
fill 20 143 279 22 143 279 minecraft:red_nether_bricks
fill 20 143 282 21 143 282 minecraft:orange_terracotta
fill 21 143 283 22 144 283 minecraft:red_nether_bricks
fill 22 143 280 22 143 281 minecraft:red_nether_bricks
setblock 22 143 282 minecraft:nether_wart_block
setblock 23 143 279 minecraft:nether_wart_block
fill 23 143 280 23 145 280 minecraft:red_nether_bricks
setblock 23 143 281 minecraft:orange_terracotta
fill 23 143 282 25 143 282 minecraft:red_nether_bricks
setblock 23 143 283 minecraft:nether_wart_block
fill 24 143 279 25 143 279 minecraft:red_nether_bricks
setblock 24 143 280 minecraft:nether_wart_block
fill 24 143 281 24 145 281 minecraft:red_nether_bricks
setblock 25 143 281 minecraft:nether_wart_block
fill 25 143 283 26 144 283 minecraft:red_nether_bricks
fill 27 143 280 27 143 282 minecraft:red_nether_bricks
setblock 27 143 283 minecraft:nether_wart_block
setblock 28 143 281 minecraft:red_nether_bricks
fill 0 144 301 0 170 301 minecraft:blackstone
setblock 3 144 278 minecraft:light[level=12]
setblock 3 144 285 minecraft:light[level=12]
setblock 3 144 292 minecraft:light[level=12]
setblock 3 144 299 minecraft:light[level=12]
setblock 3 144 306 minecraft:light[level=12]
setblock 3 144 313 minecraft:light[level=12]
setblock 3 144 317 minecraft:magma_block
fill 4 144 317 4 193 317 minecraft:blackstone
setblock 10 144 278 minecraft:light[level=12]
setblock 10 144 285 minecraft:light[level=12]
setblock 10 144 292 minecraft:light[level=12]
setblock 10 144 299 minecraft:light[level=12]
setblock 10 144 306 minecraft:light[level=12]
setblock 10 144 313 minecraft:light[level=12]
fill 14 144 275 14 216 275 minecraft:blackstone
fill 15 144 307 15 145 308 minecraft:gold_block
fill 16 144 281 17 146 282 minecraft:orange_terracotta
setblock 17 144 278 minecraft:light[level=12]
setblock 17 144 280 minecraft:nether_wart_block
setblock 17 144 285 minecraft:light[level=12]
setblock 17 144 299 minecraft:light[level=12]
setblock 17 144 306 minecraft:light[level=12]
setblock 17 144 313 minecraft:light[level=12]
fill 18 144 279 18 144 280 minecraft:red_nether_bricks
fill 18 144 281 18 145 281 minecraft:orange_terracotta
fill 18 144 282 18 144 283 minecraft:red_nether_bricks
fill 19 144 279 19 146 279 minecraft:red_nether_bricks
fill 19 144 283 19 146 283 minecraft:red_nether_bricks
setblock 20 144 279 minecraft:nether_wart_block
fill 20 144 280 20 144 282 minecraft:orange_terracotta
setblock 20 144 283 minecraft:nether_wart_block
fill 21 144 279 23 144 279 minecraft:red_nether_bricks
setblock 21 144 280 minecraft:nether_wart_block
setblock 21 144 281 minecraft:orange_terracotta
fill 21 144 282 22 145 282 minecraft:red_nether_bricks
setblock 22 144 280 minecraft:red_nether_bricks
setblock 22 144 281 minecraft:nether_wart_block
setblock 23 144 281 minecraft:red_nether_bricks
setblock 23 144 282 minecraft:nether_wart_block
setblock 23 144 283 minecraft:red_nether_bricks
setblock 24 144 278 minecraft:light[level=12]
setblock 24 144 279 minecraft:nether_wart_block
fill 24 144 280 24 145 280 minecraft:red_nether_bricks
fill 24 144 282 25 144 282 minecraft:red_nether_bricks
setblock 24 144 283 minecraft:nether_wart_block
setblock 24 144 285 minecraft:light[level=12]
setblock 24 144 292 minecraft:light[level=12]
setblock 24 144 299 minecraft:light[level=12]
setblock 24 144 306 minecraft:light[level=12]
setblock 24 144 313 minecraft:light[level=12]
setblock 25 144 280 minecraft:nether_wart_block
fill 25 144 281 25 145 281 minecraft:red_nether_bricks
setblock 26 144 280 minecraft:red_nether_bricks
setblock 26 144 281 minecraft:nether_wart_block
setblock 27 144 281 minecraft:red_nether_bricks
setblock 27 144 282 minecraft:nether_wart_block
setblock 31 144 278 minecraft:light[level=12]
setblock 31 144 285 minecraft:light[level=12]
setblock 31 144 292 minecraft:light[level=12]
setblock 31 144 299 minecraft:light[level=12]
setblock 31 144 306 minecraft:light[level=12]
setblock 31 144 313 minecraft:light[level=12]
setblock 38 144 278 minecraft:light[level=12]
setblock 38 144 285 minecraft:light[level=12]
setblock 38 144 292 minecraft:light[level=12]
setblock 38 144 299 minecraft:light[level=12]
setblock 38 144 306 minecraft:light[level=12]
setblock 38 144 313 minecraft:light[level=12]
fill 3 145 317 3 191 317 minecraft:blackstone
fill 15 145 281 15 146 282 minecraft:orange_terracotta
fill 15 145 283 15 146 283 minecraft:red_nether_bricks
fill 16 145 280 16 146 280 minecraft:red_nether_bricks
setblock 16 145 283 minecraft:orange_terracotta
setblock 17 145 279 minecraft:nether_wart_block
setblock 17 145 280 minecraft:orange_terracotta
setblock 17 145 283 minecraft:nether_wart_block
setblock 18 145 279 minecraft:red_nether_bricks
setblock 18 145 280 minecraft:nether_wart_block
setblock 18 145 282 minecraft:orange_terracotta
setblock 18 145 283 minecraft:red_nether_bricks
fill 19 145 280 21 145 280 minecraft:red_nether_bricks
fill 19 145 281 19 148 281 minecraft:bone_block
fill 19 145 282 19 147 282 minecraft:red_nether_bricks
fill 20 145 279 20 146 279 minecraft:red_nether_bricks
fill 20 145 281 22 145 281 minecraft:red_nether_bricks
setblock 20 145 282 minecraft:nether_wart_block
fill 20 145 283 20 146 283 minecraft:red_nether_bricks
setblock 21 145 279 minecraft:nether_wart_block
setblock 21 145 283 minecraft:nether_wart_block
fill 22 145 279 23 145 279 minecraft:red_nether_bricks
setblock 22 145 280 minecraft:nether_wart_block
setblock 22 145 283 minecraft:red_nether_bricks
setblock 23 145 281 minecraft:nether_wart_block
setblock 23 145 282 minecraft:red_nether_bricks
setblock 24 145 282 minecraft:nether_wart_block
setblock 42 145 305 minecraft:crying_obsidian
fill 42 145 306 42 174 307 minecraft:blackstone
fill 12 146 283 14 148 283 minecraft:orange_terracotta
fill 13 146 282 14 147 282 minecraft:orange_terracotta
fill 13 146 284 13 148 284 minecraft:orange_terracotta
fill 14 146 281 14 147 281 minecraft:red_nether_bricks
setblock 14 146 284 minecraft:red_nether_bricks
setblock 15 146 280 minecraft:nether_wart_block
setblock 15 146 284 minecraft:nether_wart_block
fill 16 146 279 17 147 279 minecraft:red_nether_bricks
fill 16 146 283 16 146 284 minecraft:red_nether_bricks
fill 17 146 280 18 147 280 minecraft:red_nether_bricks
fill 17 146 283 17 148 283 minecraft:red_nether_bricks
setblock 18 146 279 minecraft:nether_wart_block
fill 18 146 281 18 146 282 minecraft:red_nether_bricks
setblock 18 146 283 minecraft:nether_wart_block
setblock 19 146 280 minecraft:nether_wart_block
fill 20 146 280 22 146 280 minecraft:red_nether_bricks
fill 20 146 281 20 148 281 minecraft:bone_block
fill 20 146 282 20 147 282 minecraft:red_nether_bricks
setblock 21 146 279 minecraft:red_nether_bricks
fill 21 146 281 23 146 281 minecraft:red_nether_bricks
setblock 21 146 282 minecraft:nether_wart_block
setblock 22 146 282 minecraft:red_nether_bricks
setblock 23 146 280 minecraft:nether_wart_block
fill 42 146 305 42 219 305 minecraft:blackstone
setblock 11 147 283 minecraft:nether_wart_block
setblock 11 147 284 minecraft:red_nether_bricks
fill 11 147 285 11 149 285 minecraft:orange_terracotta
fill 12 147 282 12 148 282 minecraft:red_nether_bricks
fill 12 147 284 12 148 284 minecraft:orange_terracotta
setblock 12 147 285 minecraft:red_nether_bricks
setblock 13 147 281 minecraft:nether_wart_block
setblock 13 147 285 minecraft:nether_wart_block
fill 14 147 280 15 148 280 minecraft:red_nether_bricks
setblock 14 147 284 minecraft:orange_terracotta
fill 15 147 281 16 147 282 minecraft:red_nether_bricks
setblock 15 147 283 minecraft:orange_terracotta
fill 15 147 284 15 149 284 minecraft:red_nether_bricks
setblock 16 147 280 minecraft:nether_wart_block
setblock 16 147 283 minecraft:red_nether_bricks
setblock 16 147 284 minecraft:nether_wart_block
setblock 17 147 281 minecraft:nether_wart_block
fill 17 147 282 17 149 282 minecraft:red_nether_bricks
setblock 17 147 284 minecraft:red_nether_bricks
setblock 18 147 279 minecraft:red_nether_bricks
setblock 18 147 281 minecraft:red_nether_bricks
setblock 18 147 282 minecraft:nether_wart_block
fill 18 147 283 18 148 283 minecraft:red_nether_bricks
setblock 19 147 279 minecraft:nether_wart_block
setblock 19 147 280 minecraft:red_nether_bricks
setblock 19 147 283 minecraft:nether_wart_block
setblock 20 147 280 minecraft:nether_wart_block
setblock 21 147 280 minecraft:red_nether_bricks
setblock 21 147 281 minecraft:nether_wart_block
fill 35 147 275 35 220 275 minecraft:blackstone
fill 36 147 275 36 148 277 minecraft:amethyst_block
fill 37 147 275 37 148 276 minecraft:amethyst_block
fill 38 147 276 38 148 276 minecraft:amethyst_block
fill 42 147 287 42 207 289 minecraft:blackstone
setblock 42 147 290 minecraft:amethyst_block
setblock 3 148 278 minecraft:light[level=12]
setblock 3 148 286 minecraft:light[level=12]
setblock 3 148 294 minecraft:light[level=12]
setblock 3 148 302 minecraft:light[level=12]
setblock 3 148 310 minecraft:light[level=12]
fill 10 148 283 11 149 283 minecraft:red_nether_bricks
fill 10 148 284 10 149 286 minecraft:orange_terracotta
setblock 11 148 278 minecraft:light[level=12]
setblock 11 148 282 minecraft:nether_wart_block
fill 11 148 284 11 149 284 minecraft:orange_terracotta
fill 11 148 286 11 149 286 minecraft:orange_terracotta
setblock 11 148 294 minecraft:light[level=12]
setblock 11 148 302 minecraft:light[level=12]
setblock 11 148 310 minecraft:light[level=12]
fill 12 148 281 13 149 281 minecraft:red_nether_bricks
fill 12 148 285 12 149 285 minecraft:orange_terracotta
setblock 12 148 286 minecraft:red_nether_bricks
fill 13 148 282 14 149 282 minecraft:red_nether_bricks
fill 13 148 285 13 150 285 minecraft:red_nether_bricks
setblock 14 148 281 minecraft:nether_wart_block
setblock 14 148 284 minecraft:red_nether_bricks
setblock 14 148 285 minecraft:nether_wart_block
fill 15 148 275 16 148 275 minecraft:blackstone
fill 15 148 281 17 148 281 minecraft:red_nether_bricks
setblock 15 148 282 minecraft:nether_wart_block
fill 15 148 283 15 150 283 minecraft:red_nether_bricks
fill 16 148 276 16 149 277 minecraft:amethyst_block
setblock 16 148 280 minecraft:red_nether_bricks
setblock 16 148 282 minecraft:red_nether_bricks
setblock 16 148 283 minecraft:nether_wart_block
setblock 16 148 284 minecraft:red_nether_bricks
fill 17 148 275 17 151 276 minecraft:amethyst_block
setblock 17 148 280 minecraft:nether_wart_block
fill 18 148 275 19 148 275 minecraft:blackstone
setblock 18 148 280 minecraft:red_nether_bricks
setblock 18 148 281 minecraft:nether_wart_block
setblock 18 148 282 minecraft:red_nether_bricks
setblock 19 148 278 minecraft:light[level=12]
setblock 19 148 282 minecraft:nether_wart_block
setblock 19 148 286 minecraft:light[level=12]
setblock 19 148 294 minecraft:light[level=12]
setblock 19 148 302 minecraft:light[level=12]
setblock 19 148 310 minecraft:light[level=12]
setblock 27 148 278 minecraft:light[level=12]
setblock 27 148 286 minecraft:light[level=12]
setblock 27 148 294 minecraft:light[level=12]
setblock 27 148 302 minecraft:light[level=12]
setblock 27 148 310 minecraft:light[level=12]
setblock 35 148 278 minecraft:light[level=12]
setblock 35 148 286 minecraft:light[level=12]
setblock 35 148 294 minecraft:light[level=12]
setblock 35 148 302 minecraft:light[level=12]
setblock 35 148 310 minecraft:light[level=12]
setblock 37 148 277 minecraft:amethyst_block
fill 42 148 283 42 195 284 minecraft:blackstone
setblock 42 148 285 minecraft:crying_obsidian
fill 42 148 290 42 198 290 minecraft:blackstone
setblock 8 149 285 minecraft:red_nether_bricks
setblock 8 149 286 minecraft:nether_wart_block
fill 8 149 287 9 151 288 minecraft:orange_terracotta
fill 9 149 284 9 151 284 minecraft:red_nether_bricks
fill 9 149 285 9 149 286 minecraft:orange_terracotta
fill 10 149 287 11 149 287 minecraft:red_nether_bricks
fill 11 149 282 11 150 282 minecraft:red_nether_bricks
setblock 12 149 282 minecraft:nether_wart_block
fill 12 149 283 12 150 284 minecraft:red_nether_bricks
setblock 12 149 286 minecraft:nether_wart_block
fill 13 149 283 13 152 283 minecraft:bone_block
fill 13 149 284 13 151 284 minecraft:red_nether_bricks
setblock 13 149 286 minecraft:red_nether_bricks
fill 14 149 281 14 150 281 minecraft:red_nether_bricks
setblock 14 149 283 minecraft:red_nether_bricks
setblock 14 149 284 minecraft:nether_wart_block
fill 14 149 285 14 150 285 minecraft:red_nether_bricks
fill 15 149 275 15 219 275 minecraft:blackstone
setblock 15 149 280 minecraft:red_nether_bricks
setblock 15 149 281 minecraft:nether_wart_block
fill 15 149 282 15 150 282 minecraft:red_nether_bricks
fill 16 149 275 16 151 275 minecraft:amethyst_block
fill 16 149 281 17 149 281 minecraft:red_nether_bricks
setblock 16 149 282 minecraft:nether_wart_block
setblock 16 149 283 minecraft:red_nether_bricks
fill 17 149 277 18 150 277 minecraft:amethyst_block
fill 18 149 275 18 150 276 minecraft:amethyst_block
fill 19 149 275 19 219 275 minecraft:blackstone
fill 36 149 275 37 216 275 minecraft:blackstone
fill 42 149 285 42 216 285 minecraft:blackstone
setblock 42 149 315 minecraft:magma_block
setblock 3 150 278 minecraft:light[level=12]
setblock 3 150 285 minecraft:light[level=12]
setblock 3 150 292 minecraft:light[level=12]
setblock 3 150 299 minecraft:light[level=12]
setblock 3 150 306 minecraft:light[level=12]
setblock 3 150 313 minecraft:light[level=12]
fill 7 150 286 7 150 287 minecraft:red_nether_bricks
fill 7 150 288 7 151 289 minecraft:orange_terracotta
setblock 8 150 284 minecraft:red_nether_bricks
setblock 8 150 285 minecraft:nether_wart_block
fill 8 150 286 8 152 286 minecraft:red_nether_bricks
fill 8 150 289 8 151 289 minecraft:orange_terracotta
setblock 9 150 283 minecraft:red_nether_bricks
setblock 9 150 285 minecraft:red_nether_bricks
fill 9 150 286 10 150 286 minecraft:orange_terracotta
setblock 9 150 289 minecraft:red_nether_bricks
setblock 10 150 278 minecraft:light[level=12]
setblock 10 150 283 minecraft:nether_wart_block
fill 10 150 284 10 152 284 minecraft:red_nether_bricks
setblock 10 150 285 minecraft:orange_terracotta
setblock 10 150 287 minecraft:nether_wart_block
fill 10 150 288 10 152 288 minecraft:red_nether_bricks
setblock 10 150 292 minecraft:light[level=12]
setblock 10 150 299 minecraft:light[level=12]
setblock 10 150 306 minecraft:light[level=12]
setblock 10 150 313 minecraft:light[level=12]
setblock 11 150 283 minecraft:red_nether_bricks
setblock 11 150 284 minecraft:nether_wart_block
fill 11 150 285 11 150 287 minecraft:red_nether_bricks
fill 12 150 282 12 151 282 minecraft:red_nether_bricks
setblock 12 150 285 minecraft:nether_wart_block
fill 12 150 286 12 151 287 minecraft:red_nether_bricks
setblock 13 150 281 minecraft:red_nether_bricks
setblock 13 150 282 minecraft:nether_wart_block
setblock 13 150 286 minecraft:nether_wart_block
setblock 14 150 282 minecraft:red_nether_bricks
setblock 14 150 283 minecraft:nether_wart_block
setblock 14 150 284 minecraft:red_nether_bricks
setblock 15 150 284 minecraft:nether_wart_block
setblock 16 150 276 minecraft:amethyst_block
setblock 17 150 278 minecraft:light[level=12]
setblock 17 150 285 minecraft:light[level=12]
setblock 17 150 299 minecraft:light[level=12]
setblock 17 150 306 minecraft:light[level=12]
setblock 17 150 313 minecraft:light[level=12]
setblock 24 150 278 minecraft:light[level=12]
setblock 24 150 285 minecraft:light[level=12]
setblock 24 150 292 minecraft:light[level=12]
setblock 24 150 299 minecraft:light[level=12]
setblock 24 150 306 minecraft:light[level=12]
setblock 24 150 313 minecraft:light[level=12]
schedule function dropper:buildpart/60_3 1t
