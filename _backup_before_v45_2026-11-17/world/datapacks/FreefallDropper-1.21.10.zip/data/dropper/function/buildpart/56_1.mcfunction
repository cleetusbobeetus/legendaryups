fill 405 98 242 406 100 242 minecraft:dirt
fill 406 98 238 406 100 238 minecraft:dirt
fill 406 98 241 406 100 241 minecraft:dirt
fill 406 98 245 406 100 245 minecraft:dirt
fill 409 98 242 409 100 242 minecraft:dirt
setblock 376 99 244 minecraft:mossy_cobblestone
setblock 376 99 254 minecraft:moss_block
fill 376 99 267 376 113 267 minecraft:brown_terracotta
fill 377 99 228 377 107 228 minecraft:brown_terracotta
setblock 379 99 238 minecraft:light[level=12]
setblock 379 99 245 minecraft:light[level=12]
setblock 379 99 252 minecraft:light[level=12]
setblock 379 99 259 minecraft:light[level=12]
setblock 386 99 231 minecraft:light[level=12]
setblock 386 99 238 minecraft:light[level=12]
setblock 386 99 245 minecraft:light[level=12]
setblock 386 99 252 minecraft:light[level=12]
setblock 386 99 259 minecraft:light[level=12]
setblock 386 99 266 minecraft:light[level=12]
setblock 393 99 231 minecraft:light[level=12]
setblock 393 99 238 minecraft:light[level=12]
setblock 393 99 245 minecraft:light[level=12]
setblock 393 99 252 minecraft:light[level=12]
setblock 393 99 259 minecraft:light[level=12]
setblock 393 99 266 minecraft:light[level=12]
fill 395 99 237 395 99 238 minecraft:jungle_leaves[persistent=true]
setblock 399 99 238 minecraft:jungle_leaves[persistent=true]
setblock 399 99 270 minecraft:jungle_leaves[persistent=true]
setblock 400 99 231 minecraft:light[level=12]
fill 400 99 238 400 100 241 minecraft:dirt
setblock 400 99 245 minecraft:light[level=12]
setblock 400 99 252 minecraft:light[level=12]
setblock 400 99 259 minecraft:light[level=12]
setblock 400 99 266 minecraft:light[level=12]
fill 401 99 237 401 100 237 minecraft:dirt
fill 401 99 242 401 100 242 minecraft:dirt
fill 401 99 270 401 133 270 minecraft:brown_terracotta
fill 402 99 243 405 100 243 minecraft:dirt
fill 403 99 236 404 100 236 minecraft:dirt
fill 405 99 244 405 100 244 minecraft:dirt
setblock 407 99 231 minecraft:light[level=12]
setblock 407 99 238 minecraft:light[level=12]
fill 407 99 241 408 100 241 minecraft:dirt
fill 407 99 246 407 100 246 minecraft:dirt
setblock 407 99 252 minecraft:light[level=12]
setblock 407 99 259 minecraft:light[level=12]
setblock 407 99 266 minecraft:light[level=12]
fill 409 99 245 409 100 245 minecraft:dirt
fill 410 99 243 410 100 243 minecraft:dirt
setblock 411 99 270 minecraft:green_concrete
setblock 414 99 238 minecraft:light[level=12]
setblock 414 99 245 minecraft:light[level=12]
setblock 414 99 252 minecraft:light[level=12]
setblock 414 99 259 minecraft:light[level=12]
setblock 418 99 264 minecraft:green_concrete
fill 376 100 244 376 135 244 minecraft:brown_terracotta
fill 376 100 254 376 135 254 minecraft:brown_terracotta
setblock 379 100 239 minecraft:light[level=15]
setblock 379 100 247 minecraft:light[level=15]
setblock 379 100 255 minecraft:light[level=15]
setblock 387 100 231 minecraft:light[level=15]
setblock 387 100 239 minecraft:light[level=15]
setblock 387 100 247 minecraft:light[level=15]
setblock 387 100 255 minecraft:light[level=15]
setblock 387 100 263 minecraft:light[level=15]
fill 393 100 270 393 124 270 minecraft:brown_terracotta
setblock 394 100 270 minecraft:green_concrete
setblock 395 100 231 minecraft:light[level=15]
setblock 395 100 239 minecraft:light[level=15]
setblock 395 100 247 minecraft:light[level=15]
setblock 395 100 255 minecraft:light[level=15]
setblock 395 100 263 minecraft:light[level=15]
setblock 399 100 270 minecraft:moss_block
setblock 400 100 242 minecraft:dirt
setblock 401 100 243 minecraft:dirt
setblock 402 100 236 minecraft:dirt
setblock 403 100 231 minecraft:light[level=15]
setblock 403 100 247 minecraft:light[level=15]
setblock 403 100 255 minecraft:light[level=15]
setblock 403 100 263 minecraft:light[level=15]
setblock 405 100 236 minecraft:dirt
setblock 405 100 245 minecraft:dirt
setblock 406 100 237 minecraft:dirt
setblock 406 100 246 minecraft:dirt
fill 407 100 238 407 100 240 minecraft:dirt
fill 408 100 246 409 100 246 minecraft:dirt
setblock 409 100 241 minecraft:dirt
setblock 410 100 242 minecraft:dirt
fill 410 100 244 410 100 245 minecraft:dirt
setblock 411 100 239 minecraft:light[level=15]
setblock 411 100 247 minecraft:light[level=15]
setblock 411 100 255 minecraft:light[level=15]
setblock 411 100 263 minecraft:light[level=15]
fill 411 100 270 411 133 270 minecraft:brown_terracotta
setblock 418 100 231 minecraft:green_concrete
fill 418 100 264 418 136 264 minecraft:brown_terracotta
fill 377 101 236 377 107 236 minecraft:jungle_leaves[persistent=true]
fill 394 101 270 394 131 270 minecraft:brown_terracotta
fill 399 101 270 399 133 270 minecraft:brown_terracotta
fill 403 101 240 403 103 240 minecraft:jungle_log
fill 407 101 243 407 103 243 minecraft:jungle_log
setblock 408 101 228 minecraft:moss_block
fill 418 101 231 418 131 231 minecraft:brown_terracotta
setblock 418 101 239 minecraft:jungle_leaves[persistent=true]
fill 376 102 236 376 118 236 minecraft:brown_terracotta
setblock 376 102 237 minecraft:mossy_cobblestone
fill 376 102 238 376 118 238 minecraft:brown_terracotta
fill 408 102 228 408 105 228 minecraft:brown_terracotta
fill 410 102 241 414 103 245 minecraft:dirt
fill 415 102 243 416 102 243 minecraft:dirt
fill 418 102 239 418 117 239 minecraft:brown_terracotta
setblock 418 102 259 minecraft:green_concrete
fill 376 103 237 376 118 237 minecraft:brown_terracotta
fill 377 103 242 377 108 242 minecraft:green_wool
setblock 391 103 270 minecraft:jungle_leaves[persistent=true]
setblock 396 103 228 minecraft:green_concrete
fill 405 103 231 409 104 235 minecraft:dirt
fill 407 103 229 407 103 230 minecraft:dirt
fill 418 103 240 418 119 241 minecraft:brown_terracotta
setblock 418 103 242 minecraft:green_concrete
fill 418 103 259 418 112 259 minecraft:brown_terracotta
setblock 382 104 228 minecraft:green_concrete
setblock 390 104 270 minecraft:jungle_leaves[persistent=true]
fill 391 104 270 391 131 270 minecraft:brown_terracotta
fill 396 104 228 396 107 228 minecraft:brown_terracotta
fill 402 104 239 404 106 241 minecraft:jungle_leaves[persistent=true]
fill 403 104 238 404 106 238 minecraft:jungle_leaves[persistent=true]
fill 405 104 239 405 106 240 minecraft:jungle_leaves[persistent=true]
fill 406 104 242 408 106 244 minecraft:jungle_leaves[persistent=true]
fill 407 104 245 408 106 245 minecraft:jungle_leaves[persistent=true]
fill 409 104 243 409 106 244 minecraft:jungle_leaves[persistent=true]
fill 411 104 243 413 110 243 minecraft:jungle_log
fill 412 104 242 412 110 242 minecraft:jungle_log
fill 412 104 244 412 110 244 minecraft:jungle_log
fill 418 104 242 418 135 242 minecraft:brown_terracotta
setblock 379 105 238 minecraft:light[level=12]
setblock 379 105 245 minecraft:light[level=12]
setblock 379 105 252 minecraft:light[level=12]
fill 379 105 259 379 110 259 minecraft:jungle_leaves[persistent=true]
setblock 382 105 228 minecraft:brown_terracotta
fill 383 105 260 383 109 260 minecraft:jungle_leaves[persistent=true]
setblock 386 105 231 minecraft:light[level=12]
setblock 386 105 238 minecraft:light[level=12]
setblock 386 105 245 minecraft:light[level=12]
setblock 386 105 252 minecraft:light[level=12]
setblock 386 105 259 minecraft:light[level=12]
setblock 386 105 266 minecraft:light[level=12]
fill 386 105 267 386 109 267 minecraft:jungle_leaves[persistent=true]
fill 390 105 270 390 115 270 minecraft:brown_terracotta
setblock 393 105 231 minecraft:light[level=12]
setblock 393 105 238 minecraft:light[level=12]
setblock 393 105 245 minecraft:light[level=12]
setblock 393 105 252 minecraft:light[level=12]
setblock 393 105 259 minecraft:light[level=12]
setblock 393 105 266 minecraft:light[level=12]
setblock 395 105 228 minecraft:moss_block
setblock 400 105 231 minecraft:light[level=12]
setblock 400 105 238 minecraft:light[level=12]
setblock 400 105 245 minecraft:light[level=12]
setblock 400 105 252 minecraft:light[level=12]
setblock 400 105 259 minecraft:light[level=12]
setblock 400 105 266 minecraft:light[level=12]
fill 401 105 239 401 105 240 minecraft:jungle_leaves[persistent=true]
setblock 402 105 238 minecraft:jungle_leaves[persistent=true]
setblock 405 105 238 minecraft:jungle_leaves[persistent=true]
setblock 405 105 241 minecraft:jungle_leaves[persistent=true]
setblock 405 105 243 minecraft:jungle_leaves[persistent=true]
fill 406 105 233 408 105 233 minecraft:jungle_log
setblock 406 105 245 minecraft:jungle_leaves[persistent=true]
setblock 407 105 231 minecraft:light[level=12]
fill 407 105 232 407 111 232 minecraft:jungle_log
fill 407 105 234 407 110 234 minecraft:jungle_leaves[persistent=true]
setblock 407 105 238 minecraft:light[level=12]
setblock 407 105 241 minecraft:jungle_leaves[persistent=true]
setblock 407 105 252 minecraft:light[level=12]
setblock 407 105 259 minecraft:light[level=12]
setblock 407 105 266 minecraft:light[level=12]
fill 408 105 235 408 110 235 minecraft:jungle_leaves[persistent=true]
fill 408 105 261 408 109 263 minecraft:jungle_leaves[persistent=true]
setblock 409 105 242 minecraft:jungle_leaves[persistent=true]
setblock 409 105 245 minecraft:jungle_leaves[persistent=true]
fill 409 105 261 409 109 261 minecraft:jungle_leaves[persistent=true]
setblock 414 105 238 minecraft:light[level=12]
setblock 414 105 245 minecraft:light[level=12]
setblock 414 105 252 minecraft:light[level=12]
setblock 414 105 259 minecraft:light[level=12]
fill 376 106 259 378 108 259 minecraft:jungle_leaves[persistent=true]
fill 376 106 260 376 106 261 minecraft:brown_terracotta
fill 377 106 260 382 109 260 minecraft:jungle_leaves[persistent=true]
fill 378 106 228 378 106 229 minecraft:jungle_log
fill 378 106 258 380 108 258 minecraft:jungle_leaves[persistent=true]
fill 379 106 228 379 107 228 minecraft:jungle_log
fill 379 106 257 379 108 257 minecraft:jungle_leaves[persistent=true]
fill 379 106 261 380 108 261 minecraft:jungle_leaves[persistent=true]
fill 379 106 262 379 107 262 minecraft:jungle_log
fill 380 106 259 384 109 259 minecraft:jungle_leaves[persistent=true]
fill 381 106 228 382 106 228 minecraft:jungle_log
fill 381 106 262 382 106 262 minecraft:jungle_log
fill 382 106 229 382 107 229 minecraft:jungle_log
fill 382 106 258 383 109 258 minecraft:jungle_leaves[persistent=true]
fill 382 106 261 384 107 261 minecraft:jungle_leaves[persistent=true]
fill 383 106 228 384 107 228 minecraft:oak_leaves[persistent=true]
fill 384 106 260 384 109 260 minecraft:jungle_leaves[persistent=true]
fill 384 106 267 384 107 267 minecraft:jungle_log
fill 385 106 267 385 108 268 minecraft:jungle_leaves[persistent=true]
fill 386 106 266 388 109 266 minecraft:jungle_leaves[persistent=true]
fill 386 106 268 388 109 269 minecraft:jungle_leaves[persistent=true]
fill 387 106 267 388 109 267 minecraft:jungle_leaves[persistent=true]
setblock 392 106 228 minecraft:jungle_leaves[persistent=true]
fill 395 106 228 395 133 228 minecraft:brown_terracotta
fill 406 106 233 406 107 236 minecraft:jungle_leaves[persistent=true]
fill 407 106 228 411 108 228 minecraft:jungle_leaves[persistent=true]
fill 407 106 233 408 109 233 minecraft:jungle_leaves[persistent=true]
fill 407 106 235 407 108 237 minecraft:jungle_leaves[persistent=true]
fill 407 106 261 407 109 263 minecraft:jungle_leaves[persistent=true]
fill 408 106 234 409 109 234 minecraft:jungle_leaves[persistent=true]
fill 408 106 236 408 109 236 minecraft:jungle_leaves[persistent=true]
fill 408 106 260 409 108 260 minecraft:jungle_leaves[persistent=true]
fill 408 106 264 408 109 264 minecraft:jungle_leaves[persistent=true]
fill 409 106 235 409 109 235 minecraft:jungle_leaves[persistent=true]
fill 409 106 262 409 109 263 minecraft:jungle_leaves[persistent=true]
fill 410 106 233 410 106 234 minecraft:jungle_log
fill 410 106 261 410 109 262 minecraft:jungle_leaves[persistent=true]
fill 411 106 229 411 106 230 minecraft:jungle_log
setblock 411 106 234 minecraft:jungle_log
fill 411 106 263 411 107 264 minecraft:jungle_log
setblock 412 106 229 minecraft:jungle_log
fill 415 106 270 416 107 270 minecraft:jungle_log
fill 416 106 229 417 107 229 minecraft:jungle_log
setblock 416 106 269 minecraft:jungle_log
setblock 417 106 228 minecraft:brown_terracotta
setblock 417 106 230 minecraft:jungle_log
fill 418 106 228 418 110 228 minecraft:oak_leaves[persistent=true]
setblock 376 107 231 minecraft:mossy_cobblestone
fill 376 107 232 376 131 232 minecraft:brown_terracotta
fill 376 107 260 376 108 260 minecraft:jungle_leaves[persistent=true]
fill 376 107 261 376 130 261 minecraft:brown_terracotta
fill 377 107 258 377 109 258 minecraft:jungle_leaves[persistent=true]
setblock 378 107 228 minecraft:jungle_log
fill 378 107 257 378 109 257 minecraft:jungle_leaves[persistent=true]
fill 378 107 261 378 109 261 minecraft:jungle_leaves[persistent=true]
setblock 379 107 239 minecraft:light[level=15]
setblock 379 107 247 minecraft:light[level=15]
setblock 379 107 255 minecraft:light[level=15]
fill 380 107 257 383 108 257 minecraft:jungle_leaves[persistent=true]
setblock 381 107 228 minecraft:jungle_log
fill 381 107 258 381 109 258 minecraft:jungle_leaves[persistent=true]
fill 381 107 261 381 109 261 minecraft:jungle_leaves[persistent=true]
setblock 381 107 262 minecraft:jungle_log
fill 382 107 228 382 108 228 minecraft:oak_leaves[persistent=true]
fill 382 107 262 383 107 262 minecraft:jungle_leaves[persistent=true]
fill 384 107 258 384 109 258 minecraft:jungle_leaves[persistent=true]
fill 385 107 266 385 108 266 minecraft:jungle_leaves[persistent=true]
fill 385 107 269 385 108 269 minecraft:jungle_leaves[persistent=true]
fill 386 107 265 388 108 265 minecraft:jungle_leaves[persistent=true]
setblock 387 107 231 minecraft:light[level=15]
setblock 387 107 239 minecraft:light[level=15]
setblock 387 107 247 minecraft:light[level=15]
setblock 387 107 255 minecraft:light[level=15]
setblock 387 107 263 minecraft:light[level=15]
fill 387 107 270 388 108 270 minecraft:jungle_leaves[persistent=true]
setblock 389 107 268 minecraft:jungle_leaves[persistent=true]
fill 389 107 270 389 117 270 minecraft:brown_terracotta
fill 392 107 228 392 136 228 minecraft:brown_terracotta
setblock 395 107 231 minecraft:light[level=15]
setblock 395 107 239 minecraft:light[level=15]
setblock 395 107 247 minecraft:light[level=15]
setblock 395 107 255 minecraft:light[level=15]
setblock 395 107 263 minecraft:light[level=15]
setblock 403 107 231 minecraft:light[level=15]
setblock 403 107 239 minecraft:light[level=15]
setblock 403 107 247 minecraft:light[level=15]
setblock 403 107 255 minecraft:light[level=15]
setblock 403 107 263 minecraft:light[level=15]
setblock 405 107 234 minecraft:jungle_leaves[persistent=true]
fill 406 107 262 406 107 263 minecraft:jungle_leaves[persistent=true]
setblock 407 107 260 minecraft:jungle_leaves[persistent=true]
fill 408 107 229 410 109 229 minecraft:jungle_leaves[persistent=true]
setblock 408 107 237 minecraft:jungle_leaves[persistent=true]
fill 409 107 233 409 109 233 minecraft:jungle_leaves[persistent=true]
fill 409 107 236 409 109 236 minecraft:jungle_leaves[persistent=true]
fill 409 107 264 409 109 264 minecraft:jungle_leaves[persistent=true]
setblock 410 107 233 minecraft:jungle_log
fill 410 107 234 410 108 235 minecraft:jungle_leaves[persistent=true]
fill 410 107 260 410 108 260 minecraft:jungle_leaves[persistent=true]
fill 410 107 263 410 109 263 minecraft:jungle_leaves[persistent=true]
setblock 410 107 264 minecraft:jungle_log
setblock 411 107 229 minecraft:jungle_log
setblock 411 107 239 minecraft:light[level=15]
setblock 411 107 247 minecraft:light[level=15]
setblock 411 107 255 minecraft:light[level=15]
fill 411 107 262 411 108 262 minecraft:jungle_leaves[persistent=true]
fill 417 107 228 417 109 228 minecraft:oak_leaves[persistent=true]
fill 417 107 270 417 108 270 minecraft:azalea_leaves[persistent=true]
fill 418 107 249 418 126 250 minecraft:brown_terracotta
setblock 418 107 251 minecraft:green_concrete
fill 418 107 252 418 135 253 minecraft:brown_terracotta
setblock 418 107 268 minecraft:moss_block
fill 376 108 228 378 108 228 minecraft:jungle_leaves[persistent=true]
fill 376 108 231 376 135 231 minecraft:brown_terracotta
setblock 376 108 242 minecraft:moss_block
fill 376 108 243 376 117 243 minecraft:brown_terracotta
fill 377 108 261 377 109 261 minecraft:jungle_leaves[persistent=true]
fill 379 108 228 379 135 228 minecraft:brown_terracotta
fill 381 108 228 381 119 228 minecraft:brown_terracotta
fill 381 108 262 382 108 262 minecraft:jungle_leaves[persistent=true]
fill 382 108 261 383 108 261 minecraft:jungle_leaves[persistent=true]
setblock 383 108 228 minecraft:oak_leaves[persistent=true]
fill 384 108 228 384 131 228 minecraft:brown_terracotta
setblock 396 108 228 minecraft:jungle_leaves[persistent=true]
fill 406 108 233 406 111 233 minecraft:jungle_log
fill 406 108 234 406 108 236 minecraft:jungle_leaves[persistent=true]
setblock 406 108 262 minecraft:jungle_leaves[persistent=true]
setblock 410 108 233 minecraft:jungle_leaves[persistent=true]
setblock 411 108 261 minecraft:jungle_leaves[persistent=true]
fill 415 108 270 416 128 270 minecraft:brown_terracotta
fill 417 108 229 418 109 229 minecraft:oak_leaves[persistent=true]
fill 418 108 251 418 111 251 minecraft:brown_terracotta
fill 418 108 268 418 118 268 minecraft:brown_terracotta
setblock 418 108 270 minecraft:azalea_leaves[persistent=true]
fill 376 109 228 376 135 228 minecraft:brown_terracotta
fill 376 109 242 376 135 242 minecraft:brown_terracotta
setblock 376 109 245 minecraft:green_concrete
setblock 376 109 255 minecraft:green_concrete
fill 376 109 259 376 130 260 minecraft:brown_terracotta
setblock 377 109 228 minecraft:jungle_leaves[persistent=true]
fill 377 109 231 379 136 233 minecraft:jungle_log
fill 377 109 259 378 109 259 minecraft:jungle_leaves[persistent=true]
fill 378 109 228 378 115 228 minecraft:brown_terracotta
fill 378 109 258 379 109 258 minecraft:jungle_leaves[persistent=true]
fill 380 109 231 380 123 231 minecraft:jungle_leaves[persistent=true]
fill 380 109 232 383 115 233 minecraft:jungle_log
fill 381 109 231 383 136 231 minecraft:jungle_log
fill 382 109 228 383 120 228 minecraft:brown_terracotta
setblock 382 109 261 minecraft:jungle_leaves[persistent=true]
setblock 385 109 268 minecraft:jungle_leaves[persistent=true]
setblock 387 109 265 minecraft:jungle_leaves[persistent=true]
fill 387 109 270 388 135 270 minecraft:brown_terracotta
fill 396 109 228 396 135 228 minecraft:brown_terracotta
fill 406 109 234 406 109 235 minecraft:jungle_leaves[persistent=true]
fill 407 109 228 407 115 228 minecraft:brown_terracotta
fill 407 109 235 407 109 236 minecraft:jungle_leaves[persistent=true]
fill 408 109 228 410 109 228 minecraft:jungle_leaves[persistent=true]
fill 411 109 228 411 133 228 minecraft:brown_terracotta
fill 417 109 270 418 120 270 minecraft:brown_terracotta
fill 376 110 245 376 133 245 minecraft:brown_terracotta
fill 376 110 255 376 123 255 minecraft:brown_terracotta
fill 377 110 228 377 135 228 minecraft:brown_terracotta
fill 378 110 259 378 110 260 minecraft:jungle_leaves[persistent=true]
setblock 380 110 259 minecraft:jungle_leaves[persistent=true]
setblock 382 110 270 minecraft:green_concrete
fill 383 110 259 384 110 259 minecraft:jungle_leaves[persistent=true]
setblock 392 110 270 minecraft:moss_block
fill 407 110 233 408 111 233 minecraft:jungle_log
fill 408 110 228 408 131 228 minecraft:brown_terracotta
setblock 408 110 261 minecraft:jungle_leaves[persistent=true]
fill 408 110 263 409 110 263 minecraft:jungle_leaves[persistent=true]
setblock 409 110 228 minecraft:jungle_leaves[persistent=true]
fill 410 110 228 410 132 228 minecraft:brown_terracotta
fill 417 110 228 417 135 228 minecraft:brown_terracotta
fill 418 110 229 418 131 229 minecraft:brown_terracotta
setblock 418 110 255 minecraft:mossy_cobblestone
setblock 379 111 238 minecraft:light[level=12]
setblock 379 111 245 minecraft:light[level=12]
setblock 379 111 252 minecraft:light[level=12]
setblock 379 111 259 minecraft:light[level=12]
fill 382 111 270 382 131 270 minecraft:brown_terracotta
setblock 386 111 231 minecraft:light[level=12]
setblock 386 111 238 minecraft:light[level=12]
setblock 386 111 245 minecraft:light[level=12]
setblock 386 111 252 minecraft:light[level=12]
setblock 386 111 259 minecraft:light[level=12]
setblock 386 111 266 minecraft:light[level=12]
fill 392 111 270 392 135 270 minecraft:brown_terracotta
setblock 393 111 231 minecraft:light[level=12]
setblock 393 111 238 minecraft:light[level=12]
setblock 393 111 245 minecraft:light[level=12]
setblock 393 111 252 minecraft:light[level=12]
setblock 393 111 259 minecraft:light[level=12]
setblock 393 111 266 minecraft:light[level=12]
setblock 400 111 231 minecraft:light[level=12]
setblock 400 111 238 minecraft:light[level=12]
setblock 400 111 245 minecraft:light[level=12]
setblock 400 111 252 minecraft:light[level=12]
setblock 400 111 259 minecraft:light[level=12]
setblock 400 111 266 minecraft:light[level=12]
setblock 407 111 231 minecraft:light[level=12]
setblock 407 111 234 minecraft:jungle_log
setblock 407 111 238 minecraft:light[level=12]
setblock 407 111 245 minecraft:light[level=12]
setblock 407 111 252 minecraft:light[level=12]
setblock 407 111 259 minecraft:light[level=12]
setblock 407 111 266 minecraft:light[level=12]
fill 409 111 228 409 131 228 minecraft:brown_terracotta
fill 410 111 241 411 114 245 minecraft:jungle_leaves[persistent=true]
fill 412 111 241 414 114 242 minecraft:jungle_leaves[persistent=true]
setblock 412 111 243 minecraft:jungle_log
fill 412 111 244 414 114 245 minecraft:jungle_leaves[persistent=true]
fill 413 111 243 414 114 243 minecraft:jungle_leaves[persistent=true]
setblock 414 111 238 minecraft:light[level=12]
setblock 414 111 252 minecraft:light[level=12]
setblock 414 111 259 minecraft:light[level=12]
fill 418 111 228 418 131 228 minecraft:brown_terracotta
fill 418 111 255 418 135 255 minecraft:brown_terracotta
fill 418 111 260 418 135 260 minecraft:brown_terracotta
setblock 418 111 261 minecraft:green_concrete
fill 418 111 262 418 135 262 minecraft:brown_terracotta
setblock 376 112 230 minecraft:green_concrete
setblock 380 112 228 minecraft:green_concrete
fill 396 112 270 396 135 270 minecraft:brown_terracotta
setblock 397 112 270 minecraft:moss_block
fill 398 112 270 398 135 270 minecraft:brown_terracotta
fill 405 112 231 406 115 235 minecraft:jungle_leaves[persistent=true]
fill 407 112 231 409 115 232 minecraft:jungle_leaves[persistent=true]
setblock 407 112 233 minecraft:jungle_log
fill 407 112 234 409 115 235 minecraft:jungle_leaves[persistent=true]
fill 408 112 233 409 115 233 minecraft:jungle_leaves[persistent=true]
fill 409 112 242 409 113 244 minecraft:jungle_leaves[persistent=true]
fill 411 112 240 413 113 240 minecraft:jungle_leaves[persistent=true]
fill 411 112 246 413 113 246 minecraft:jungle_leaves[persistent=true]
fill 412 112 243 412 115 243 minecraft:jungle_leaves[persistent=true]
fill 415 112 242 415 113 244 minecraft:jungle_leaves[persistent=true]
setblock 418 112 251 minecraft:moss_block
fill 418 112 261 418 135 261 minecraft:brown_terracotta
fill 376 113 230 376 131 230 minecraft:brown_terracotta
fill 376 113 233 376 135 233 minecraft:brown_terracotta
setblock 376 113 234 minecraft:moss_block
fill 380 113 228 380 131 228 minecraft:brown_terracotta
fill 397 113 270 397 126 270 minecraft:brown_terracotta
fill 404 113 232 404 114 234 minecraft:jungle_leaves[persistent=true]
fill 406 113 230 408 114 230 minecraft:jungle_leaves[persistent=true]
fill 406 113 236 408 114 236 minecraft:jungle_leaves[persistent=true]
fill 407 113 233 407 116 233 minecraft:jungle_leaves[persistent=true]
fill 410 113 232 410 114 234 minecraft:jungle_leaves[persistent=true]
fill 412 113 228 412 132 228 minecraft:brown_terracotta
setblock 413 113 228 minecraft:green_concrete
fill 418 113 251 418 115 251 minecraft:brown_terracotta
setblock 418 113 259 minecraft:green_concrete
setblock 418 113 269 minecraft:jungle_leaves[persistent=true]
fill 376 114 234 376 131 234 minecraft:brown_terracotta
setblock 376 114 267 minecraft:green_concrete
setblock 379 114 239 minecraft:light[level=15]
setblock 379 114 247 minecraft:light[level=15]
setblock 379 114 255 minecraft:light[level=15]
setblock 387 114 231 minecraft:light[level=15]
setblock 387 114 239 minecraft:light[level=15]
setblock 387 114 247 minecraft:light[level=15]
setblock 387 114 255 minecraft:light[level=15]
setblock 387 114 263 minecraft:light[level=15]
setblock 395 114 231 minecraft:light[level=15]
setblock 395 114 239 minecraft:light[level=15]
setblock 395 114 247 minecraft:light[level=15]
setblock 395 114 255 minecraft:light[level=15]
setblock 395 114 263 minecraft:light[level=15]
setblock 403 114 231 minecraft:light[level=15]
setblock 403 114 239 minecraft:light[level=15]
setblock 403 114 247 minecraft:light[level=15]
setblock 403 114 255 minecraft:light[level=15]
setblock 403 114 263 minecraft:light[level=15]
setblock 411 114 239 minecraft:light[level=15]
setblock 411 114 247 minecraft:light[level=15]
setblock 411 114 255 minecraft:light[level=15]
setblock 411 114 263 minecraft:light[level=15]
fill 413 114 228 413 135 228 minecraft:brown_terracotta
fill 418 114 259 418 136 259 minecraft:brown_terracotta
fill 418 114 269 418 118 269 minecraft:brown_terracotta
setblock 376 115 250 minecraft:jungle_leaves[persistent=true]
fill 376 115 267 376 135 267 minecraft:brown_terracotta
fill 383 115 230 383 128 230 minecraft:iron_block
fill 376 116 250 376 120 250 minecraft:brown_terracotta
setblock 378 116 228 minecraft:moss_block
fill 380 116 232 380 123 232 minecraft:green_wool
fill 380 116 233 383 136 233 minecraft:jungle_log
fill 381 116 232 383 136 232 minecraft:jungle_log
fill 382 116 263 382 123 263 minecraft:iron_block
setblock 390 116 270 minecraft:moss_block
setblock 407 116 228 minecraft:green_concrete
setblock 416 116 228 minecraft:green_concrete
setblock 418 116 251 minecraft:mossy_cobblestone
setblock 418 116 254 minecraft:green_concrete
fill 378 117 228 378 135 228 minecraft:brown_terracotta
setblock 379 117 238 minecraft:light[level=12]
setblock 379 117 245 minecraft:light[level=12]
setblock 379 117 252 minecraft:light[level=12]
setblock 379 117 259 minecraft:light[level=12]
setblock 386 117 231 minecraft:light[level=12]
setblock 386 117 238 minecraft:light[level=12]
setblock 386 117 245 minecraft:light[level=12]
setblock 386 117 252 minecraft:light[level=12]
setblock 386 117 259 minecraft:light[level=12]
setblock 386 117 266 minecraft:light[level=12]
fill 390 117 270 390 135 270 minecraft:brown_terracotta
setblock 393 117 231 minecraft:light[level=12]
setblock 393 117 238 minecraft:light[level=12]
setblock 393 117 245 minecraft:light[level=12]
setblock 393 117 252 minecraft:light[level=12]
setblock 393 117 259 minecraft:light[level=12]
setblock 393 117 266 minecraft:light[level=12]
setblock 400 117 231 minecraft:light[level=12]
setblock 400 117 238 minecraft:light[level=12]
setblock 400 117 245 minecraft:light[level=12]
setblock 400 117 252 minecraft:light[level=12]
setblock 400 117 259 minecraft:light[level=12]
setblock 400 117 266 minecraft:light[level=12]
fill 407 117 228 407 119 228 minecraft:brown_terracotta
setblock 407 117 231 minecraft:light[level=12]
setblock 407 117 238 minecraft:light[level=12]
setblock 407 117 245 minecraft:light[level=12]
setblock 407 117 252 minecraft:light[level=12]
setblock 407 117 259 minecraft:light[level=12]
setblock 407 117 266 minecraft:light[level=12]
fill 407 117 270 408 130 270 minecraft:brown_terracotta
setblock 409 117 270 minecraft:jungle_leaves[persistent=true]
setblock 414 117 238 minecraft:light[level=12]
setblock 414 117 245 minecraft:light[level=12]
setblock 414 117 252 minecraft:light[level=12]
setblock 414 117 259 minecraft:light[level=12]
fill 416 117 228 416 126 228 minecraft:brown_terracotta
fill 418 117 251 418 135 251 minecraft:brown_terracotta
fill 418 117 254 418 120 254 minecraft:brown_terracotta
setblock 376 118 243 minecraft:mossy_cobblestone
setblock 376 118 258 minecraft:mossy_cobblestone
fill 380 118 259 380 122 260 minecraft:oak_leaves[persistent=true]
fill 381 118 238 382 122 238 minecraft:jungle_leaves[persistent=true]
fill 381 118 259 382 122 259 minecraft:oak_leaves[persistent=true]
fill 383 118 239 383 122 239 minecraft:jungle_leaves[persistent=true]
setblock 385 118 228 minecraft:green_concrete
fill 386 118 231 387 122 231 minecraft:azalea_leaves[persistent=true]
fill 386 118 265 388 122 265 minecraft:jungle_leaves[persistent=true]
fill 387 118 230 387 122 230 minecraft:azalea_leaves[persistent=true]
setblock 389 118 270 minecraft:mossy_cobblestone
fill 402 118 269 402 128 269 minecraft:jungle_leaves[persistent=true]
setblock 405 118 228 minecraft:green_concrete
fill 409 118 270 409 122 270 minecraft:brown_terracotta
fill 415 118 240 415 119 240 minecraft:azalea_leaves[persistent=true]
fill 416 118 239 417 118 239 minecraft:azalea_leaves[persistent=true]
fill 417 118 237 417 123 238 minecraft:oak_leaves[persistent=true]
fill 418 118 239 418 123 239 minecraft:oak_leaves[persistent=true]
fill 376 119 235 376 121 238 minecraft:oak_leaves[persistent=true]
fill 376 119 243 376 135 243 minecraft:brown_terracotta
fill 376 119 258 376 132 258 minecraft:brown_terracotta
fill 376 119 268 376 135 269 minecraft:brown_terracotta
fill 376 119 270 377 121 270 minecraft:oak_leaves[persistent=true]
fill 377 119 234 377 120 235 minecraft:jungle_log
setblock 378 119 235 minecraft:jungle_log
fill 378 119 269 378 119 270 minecraft:jungle_log
fill 379 119 259 379 120 260 minecraft:oak_leaves[persistent=true]
fill 380 119 258 383 121 258 minecraft:oak_leaves[persistent=true]
fill 380 119 261 381 120 261 minecraft:oak_leaves[persistent=true]
fill 380 119 262 381 120 262 minecraft:jungle_log
fill 381 119 236 382 119 236 minecraft:jungle_log
fill 381 119 239 382 122 239 minecraft:jungle_leaves[persistent=true]
fill 381 119 260 382 122 260 minecraft:oak_leaves[persistent=true]
setblock 382 119 235 minecraft:jungle_log
fill 382 119 240 383 122 240 minecraft:jungle_leaves[persistent=true]
fill 383 119 237 384 121 238 minecraft:jungle_leaves[persistent=true]
fill 383 119 259 383 122 259 minecraft:oak_leaves[persistent=true]
fill 384 119 231 384 120 231 minecraft:jungle_log
fill 384 119 239 384 122 239 minecraft:jungle_leaves[persistent=true]
fill 384 119 265 384 120 266 minecraft:jungle_log
fill 385 119 228 385 132 228 minecraft:brown_terracotta
fill 385 119 230 385 121 231 minecraft:azalea_leaves[persistent=true]
fill 386 119 229 386 122 230 minecraft:azalea_leaves[persistent=true]
fill 386 119 232 387 122 232 minecraft:azalea_leaves[persistent=true]
fill 386 119 263 388 120 264 minecraft:jungle_leaves[persistent=true]
fill 386 119 266 388 121 267 minecraft:jungle_leaves[persistent=true]
fill 387 119 229 388 121 229 minecraft:azalea_leaves[persistent=true]
fill 388 119 230 388 122 231 minecraft:azalea_leaves[persistent=true]
fill 389 119 230 389 122 230 minecraft:azalea_leaves[persistent=true]
fill 389 119 270 389 131 270 minecraft:brown_terracotta
fill 405 119 228 405 131 228 minecraft:brown_terracotta
fill 414 119 238 414 121 240 minecraft:azalea_leaves[persistent=true]
fill 415 119 236 416 120 236 minecraft:jungle_log
fill 415 119 238 415 120 238 minecraft:azalea_leaves[persistent=true]
fill 415 119 239 417 121 239 minecraft:oak_leaves[persistent=true]
fill 416 119 235 416 120 235 minecraft:jungle_log
setblock 416 119 237 minecraft:azalea_leaves[persistent=true]
fill 416 119 238 416 123 238 minecraft:oak_leaves[persistent=true]
fill 416 119 240 417 121 240 minecraft:oak_leaves[persistent=true]
fill 417 119 234 418 120 234 minecraft:jungle_log
fill 417 119 268 418 119 268 minecraft:jungle_log
fill 418 119 235 418 121 238 minecraft:oak_leaves[persistent=true]
fill 418 119 265 418 120 267 minecraft:jungle_log
fill 418 119 269 418 122 269 minecraft:oak_leaves[persistent=true]
fill 376 120 239 376 121 239 minecraft:oak_leaves[persistent=true]
fill 377 120 236 377 121 238 minecraft:oak_leaves[persistent=true]
setblock 378 120 269 minecraft:jungle_log
fill 378 120 270 378 121 270 minecraft:oak_leaves[persistent=true]
fill 379 120 258 379 121 258 minecraft:oak_leaves[persistent=true]
fill 380 120 257 382 121 257 minecraft:oak_leaves[persistent=true]
setblock 381 120 228 minecraft:jungle_leaves[persistent=true]
setblock 381 120 236 minecraft:jungle_log
fill 381 120 237 382 121 237 minecraft:jungle_leaves[persistent=true]
fill 381 120 240 381 122 240 minecraft:jungle_leaves[persistent=true]
fill 382 120 236 383 121 236 minecraft:jungle_leaves[persistent=true]
fill 382 120 241 383 121 241 minecraft:jungle_leaves[persistent=true]
fill 382 120 261 382 122 261 minecraft:oak_leaves[persistent=true]
fill 383 120 260 383 122 260 minecraft:oak_leaves[persistent=true]
fill 384 120 240 384 122 240 minecraft:jungle_leaves[persistent=true]
fill 385 120 229 385 122 229 minecraft:azalea_leaves[persistent=true]
fill 385 120 264 385 120 267 minecraft:jungle_leaves[persistent=true]
fill 387 120 233 387 121 233 minecraft:azalea_leaves[persistent=true]
fill 388 120 232 388 122 232 minecraft:azalea_leaves[persistent=true]
fill 389 120 229 389 121 229 minecraft:azalea_leaves[persistent=true]
fill 389 120 231 389 121 231 minecraft:azalea_leaves[persistent=true]
fill 389 120 265 389 122 265 minecraft:jungle_leaves[persistent=true]
fill 398 120 229 398 130 229 minecraft:jungle_leaves[persistent=true]
setblock 407 120 228 minecraft:jungle_leaves[persistent=true]
fill 413 120 239 413 121 239 minecraft:azalea_leaves[persistent=true]
fill 415 120 237 415 122 237 minecraft:azalea_leaves[persistent=true]
setblock 415 120 240 minecraft:oak_leaves[persistent=true]
fill 415 120 241 415 121 241 minecraft:azalea_leaves[persistent=true]
fill 416 120 237 416 123 237 minecraft:oak_leaves[persistent=true]
fill 417 120 236 417 121 236 minecraft:oak_leaves[persistent=true]
setblock 417 120 268 minecraft:jungle_log
setblock 418 120 233 minecraft:jungle_log
fill 418 120 240 418 122 240 minecraft:oak_leaves[persistent=true]
fill 418 120 241 418 132 241 minecraft:brown_terracotta
fill 418 120 268 418 122 268 minecraft:oak_leaves[persistent=true]
setblock 376 121 250 minecraft:moss_block
setblock 379 121 239 minecraft:light[level=15]
setblock 379 121 247 minecraft:light[level=15]
setblock 379 121 255 minecraft:light[level=15]
setblock 379 121 259 minecraft:oak_leaves[persistent=true]
fill 381 121 228 381 131 228 minecraft:brown_terracotta
fill 381 121 261 381 122 261 minecraft:oak_leaves[persistent=true]
setblock 382 121 228 minecraft:moss_block
fill 383 121 228 383 135 228 minecraft:brown_terracotta
setblock 383 121 261 minecraft:oak_leaves[persistent=true]
fill 385 121 264 385 122 266 minecraft:jungle_leaves[persistent=true]
setblock 386 121 233 minecraft:azalea_leaves[persistent=true]
fill 386 121 263 387 121 264 minecraft:jungle_leaves[persistent=true]
setblock 387 121 239 minecraft:light[level=15]
setblock 387 121 247 minecraft:light[level=15]
setblock 387 121 255 minecraft:light[level=15]
fill 388 121 264 389 122 264 minecraft:jungle_leaves[persistent=true]
fill 389 121 266 389 122 266 minecraft:jungle_leaves[persistent=true]
setblock 395 121 231 minecraft:light[level=15]
setblock 395 121 239 minecraft:light[level=15]
setblock 395 121 247 minecraft:light[level=15]
setblock 395 121 255 minecraft:light[level=15]
setblock 395 121 263 minecraft:light[level=15]
setblock 403 121 231 minecraft:light[level=15]
setblock 403 121 239 minecraft:light[level=15]
setblock 403 121 247 minecraft:light[level=15]
setblock 403 121 255 minecraft:light[level=15]
setblock 403 121 263 minecraft:light[level=15]
fill 407 121 228 407 131 228 minecraft:brown_terracotta
setblock 411 121 239 minecraft:light[level=15]
setblock 411 121 247 minecraft:light[level=15]
setblock 411 121 255 minecraft:light[level=15]
setblock 411 121 263 minecraft:light[level=15]
fill 413 121 270 413 135 270 minecraft:brown_terracotta
setblock 414 121 270 minecraft:green_concrete
setblock 415 121 228 minecraft:green_concrete
setblock 415 121 238 minecraft:oak_leaves[persistent=true]
fill 415 121 240 415 122 240 minecraft:azalea_leaves[persistent=true]
setblock 416 121 236 minecraft:azalea_leaves[persistent=true]
fill 416 121 241 416 122 241 minecraft:azalea_leaves[persistent=true]
fill 417 121 270 417 133 270 minecraft:brown_terracotta
fill 418 121 233 418 135 233 minecraft:brown_terracotta
fill 418 121 234 418 122 234 minecraft:oak_leaves[persistent=true]
setblock 418 121 254 minecraft:moss_block
fill 418 121 265 418 131 267 minecraft:brown_terracotta
fill 418 121 270 418 122 270 minecraft:oak_leaves[persistent=true]
fill 376 122 235 376 131 235 minecraft:brown_terracotta
fill 376 122 236 376 122 238 minecraft:oak_leaves[persistent=true]
fill 376 122 239 376 133 239 minecraft:brown_terracotta
fill 376 122 250 376 135 250 minecraft:brown_terracotta
fill 376 122 270 378 135 270 minecraft:brown_terracotta
fill 377 122 237 377 122 238 minecraft:oak_leaves[persistent=true]
setblock 379 122 270 minecraft:green_concrete
fill 380 122 258 382 122 258 minecraft:oak_leaves[persistent=true]
setblock 381 122 257 minecraft:oak_leaves[persistent=true]
fill 382 122 228 382 133 228 minecraft:brown_terracotta
fill 382 122 237 383 122 237 minecraft:jungle_leaves[persistent=true]
fill 383 122 238 384 122 238 minecraft:jungle_leaves[persistent=true]
setblock 385 122 230 minecraft:azalea_leaves[persistent=true]
fill 386 122 264 387 122 264 minecraft:jungle_leaves[persistent=true]
fill 386 122 266 388 122 266 minecraft:jungle_leaves[persistent=true]
setblock 387 122 229 minecraft:azalea_leaves[persistent=true]
setblock 394 122 228 minecraft:green_concrete
fill 414 122 238 415 122 239 minecraft:azalea_leaves[persistent=true]
fill 414 122 270 414 125 270 minecraft:brown_terracotta
fill 415 122 228 415 132 228 minecraft:brown_terracotta
fill 416 122 239 416 123 240 minecraft:azalea_leaves[persistent=true]
fill 417 122 239 417 122 240 minecraft:oak_leaves[persistent=true]
fill 418 122 235 418 133 236 minecraft:brown_terracotta
fill 418 122 237 418 122 238 minecraft:oak_leaves[persistent=true]
fill 418 122 254 418 135 254 minecraft:brown_terracotta
fill 376 123 236 376 136 236 minecraft:brown_terracotta
setblock 376 123 237 minecraft:oak_leaves[persistent=true]
fill 376 123 238 376 135 238 minecraft:brown_terracotta
setblock 379 123 238 minecraft:light[level=12]
setblock 379 123 245 minecraft:light[level=12]
setblock 379 123 252 minecraft:light[level=12]
setblock 379 123 259 minecraft:light[level=12]
fill 379 123 270 379 135 270 minecraft:brown_terracotta
setblock 381 123 260 minecraft:oak_leaves[persistent=true]
setblock 382 123 258 minecraft:oak_leaves[persistent=true]
setblock 383 123 238 minecraft:jungle_leaves[persistent=true]
setblock 386 123 230 minecraft:azalea_leaves[persistent=true]
setblock 386 123 231 minecraft:light[level=12]
setblock 386 123 238 minecraft:light[level=12]
setblock 386 123 245 minecraft:light[level=12]
setblock 386 123 252 minecraft:light[level=12]
setblock 386 123 259 minecraft:light[level=12]
setblock 386 123 266 minecraft:light[level=12]
setblock 387 123 231 minecraft:azalea_leaves[persistent=true]
setblock 387 123 264 minecraft:jungle_leaves[persistent=true]
setblock 393 123 231 minecraft:light[level=12]
setblock 393 123 238 minecraft:light[level=12]
setblock 393 123 245 minecraft:light[level=12]
setblock 393 123 252 minecraft:light[level=12]
setblock 393 123 259 minecraft:light[level=12]
setblock 393 123 266 minecraft:light[level=12]
fill 394 123 228 394 135 228 minecraft:brown_terracotta
setblock 400 123 231 minecraft:light[level=12]
setblock 400 123 238 minecraft:light[level=12]
setblock 400 123 245 minecraft:light[level=12]
setblock 400 123 252 minecraft:light[level=12]
setblock 400 123 259 minecraft:light[level=12]
setblock 400 123 266 minecraft:light[level=12]
setblock 403 123 228 minecraft:green_concrete
fill 404 123 228 404 135 228 minecraft:brown_terracotta
setblock 407 123 231 minecraft:light[level=12]
setblock 407 123 238 minecraft:light[level=12]
setblock 407 123 245 minecraft:light[level=12]
setblock 407 123 252 minecraft:light[level=12]
setblock 407 123 259 minecraft:light[level=12]
setblock 407 123 266 minecraft:light[level=12]
setblock 409 123 270 minecraft:mossy_cobblestone
setblock 414 123 238 minecraft:light[level=12]
setblock 414 123 245 minecraft:light[level=12]
setblock 414 123 252 minecraft:light[level=12]
setblock 414 123 259 minecraft:light[level=12]
setblock 415 123 238 minecraft:azalea_leaves[persistent=true]
setblock 417 123 240 minecraft:azalea_leaves[persistent=true]
fill 418 123 234 418 135 234 minecraft:brown_terracotta
fill 418 123 237 418 135 238 minecraft:brown_terracotta
fill 418 123 240 418 132 240 minecraft:brown_terracotta
setblock 418 123 248 minecraft:moss_block
fill 418 123 268 418 131 270 minecraft:brown_terracotta
fill 376 124 237 376 135 237 minecraft:brown_terracotta
setblock 376 124 255 minecraft:jungle_leaves[persistent=true]
fill 380 124 231 380 136 232 minecraft:jungle_log
fill 403 124 228 403 135 228 minecraft:brown_terracotta
fill 409 124 270 409 130 270 minecraft:brown_terracotta
fill 418 124 232 418 125 232 minecraft:jungle_leaves[persistent=true]
fill 418 124 239 418 135 239 minecraft:brown_terracotta
fill 418 124 248 418 135 248 minecraft:brown_terracotta
fill 376 125 255 376 135 255 minecraft:brown_terracotta
setblock 386 125 270 minecraft:moss_block
setblock 393 125 270 minecraft:green_concrete
fill 379 126 238 379 136 238 minecraft:jungle_leaves[persistent=true]
fill 386 126 270 386 135 270 minecraft:brown_terracotta
fill 393 126 270 393 136 270 minecraft:brown_terracotta
setblock 414 126 270 minecraft:moss_block
fill 418 126 232 418 129 232 minecraft:brown_terracotta
setblock 397 127 270 minecraft:moss_block
fill 414 127 270 414 132 270 minecraft:brown_terracotta
setblock 416 127 228 minecraft:moss_block
setblock 418 127 249 minecraft:mossy_cobblestone
fill 418 127 250 418 131 250 minecraft:brown_terracotta
setblock 379 128 239 minecraft:light[level=15]
setblock 379 128 247 minecraft:light[level=15]
setblock 379 128 255 minecraft:light[level=15]
setblock 387 128 231 minecraft:light[level=15]
setblock 387 128 239 minecraft:light[level=15]
setblock 387 128 247 minecraft:light[level=15]
setblock 387 128 255 minecraft:light[level=15]
setblock 387 128 263 minecraft:light[level=15]
setblock 395 128 231 minecraft:light[level=15]
setblock 395 128 239 minecraft:light[level=15]
setblock 395 128 247 minecraft:light[level=15]
setblock 395 128 255 minecraft:light[level=15]
setblock 395 128 263 minecraft:light[level=15]
fill 397 128 270 397 135 270 minecraft:brown_terracotta
setblock 403 128 231 minecraft:light[level=15]
setblock 403 128 239 minecraft:light[level=15]
setblock 403 128 247 minecraft:light[level=15]
setblock 403 128 255 minecraft:light[level=15]
setblock 403 128 263 minecraft:light[level=15]
fill 405 128 230 405 136 230 minecraft:moss_block
setblock 411 128 239 minecraft:light[level=15]
setblock 411 128 247 minecraft:light[level=15]
setblock 411 128 255 minecraft:light[level=15]
setblock 411 128 263 minecraft:light[level=15]
fill 416 128 228 416 129 228 minecraft:brown_terracotta
fill 418 128 249 418 133 249 minecraft:brown_terracotta
setblock 376 129 252 minecraft:moss_block
fill 376 129 253 376 135 253 minecraft:brown_terracotta
setblock 379 129 245 minecraft:light[level=12]
setblock 379 129 252 minecraft:light[level=12]
setblock 379 129 259 minecraft:light[level=12]
setblock 386 129 231 minecraft:light[level=12]
setblock 386 129 238 minecraft:light[level=12]
setblock 386 129 245 minecraft:light[level=12]
setblock 386 129 252 minecraft:light[level=12]
setblock 386 129 259 minecraft:light[level=12]
setblock 386 129 266 minecraft:light[level=12]
setblock 393 129 231 minecraft:light[level=12]
setblock 393 129 238 minecraft:light[level=12]
setblock 393 129 245 minecraft:light[level=12]
setblock 393 129 252 minecraft:light[level=12]
setblock 393 129 259 minecraft:light[level=12]
setblock 393 129 266 minecraft:light[level=12]
setblock 400 129 231 minecraft:light[level=12]
setblock 400 129 238 minecraft:light[level=12]
setblock 400 129 245 minecraft:light[level=12]
setblock 400 129 252 minecraft:light[level=12]
setblock 400 129 259 minecraft:light[level=12]
setblock 400 129 266 minecraft:light[level=12]
setblock 407 129 231 minecraft:light[level=12]
setblock 407 129 238 minecraft:light[level=12]
setblock 407 129 245 minecraft:light[level=12]
setblock 407 129 252 minecraft:light[level=12]
setblock 407 129 259 minecraft:light[level=12]
setblock 407 129 266 minecraft:light[level=12]
setblock 414 129 238 minecraft:light[level=12]
setblock 414 129 245 minecraft:light[level=12]
setblock 414 129 252 minecraft:light[level=12]
setblock 414 129 259 minecraft:light[level=12]
fill 415 129 270 415 131 270 minecraft:brown_terracotta
setblock 416 129 270 minecraft:mossy_cobblestone
fill 376 130 252 376 135 252 minecraft:brown_terracotta
setblock 390 130 228 minecraft:moss_block
fill 391 130 228 391 135 228 minecraft:brown_terracotta
setblock 416 130 228 minecraft:mossy_cobblestone
fill 416 130 270 416 137 270 minecraft:brown_terracotta
setblock 418 130 232 minecraft:green_concrete
setblock 376 131 259 minecraft:brown_terracotta
fill 376 131 260 376 135 261 minecraft:azalea_leaves[persistent=true]
fill 377 131 259 377 135 259 minecraft:azalea_leaves[persistent=true]
fill 381 131 239 381 135 240 minecraft:azalea_leaves[persistent=true]
fill 382 131 239 382 136 239 minecraft:azalea_leaves[persistent=true]
fill 386 131 230 386 136 230 minecraft:moss_block
fill 387 131 233 387 135 235 minecraft:oak_leaves[persistent=true]
fill 387 131 263 387 136 263 minecraft:azalea_leaves[persistent=true]
setblock 390 131 228 minecraft:brown_terracotta
fill 407 131 269 407 135 269 minecraft:oak_leaves[persistent=true]
setblock 407 131 270 minecraft:brown_terracotta
fill 408 131 270 409 135 270 minecraft:oak_leaves[persistent=true]
fill 412 131 259 412 135 259 minecraft:oak_leaves[persistent=true]
fill 416 131 228 416 135 228 minecraft:brown_terracotta
setblock 418 131 232 minecraft:brown_terracotta
fill 376 132 230 376 133 230 minecraft:green_terracotta
setblock 376 132 232 minecraft:green_terracotta
fill 376 132 234 376 132 235 minecraft:green_terracotta
fill 376 132 259 376 136 259 minecraft:azalea_leaves[persistent=true]
fill 376 132 262 377 134 262 minecraft:azalea_leaves[persistent=true]
setblock 376 132 264 minecraft:green_terracotta
fill 377 132 260 377 135 261 minecraft:azalea_leaves[persistent=true]
fill 378 132 261 378 135 261 minecraft:azalea_leaves[persistent=true]
fill 378 132 262 378 132 263 minecraft:jungle_log
fill 379 132 239 380 134 239 minecraft:azalea_leaves[persistent=true]
fill 380 132 228 381 132 228 minecraft:jungle_log
fill 380 132 236 381 133 236 minecraft:jungle_log
fill 380 132 238 383 134 238 minecraft:azalea_leaves[persistent=true]
fill 380 132 240 380 135 240 minecraft:azalea_leaves[persistent=true]
fill 381 132 237 382 134 237 minecraft:azalea_leaves[persistent=true]
setblock 381 132 270 minecraft:jungle_log
fill 382 132 240 382 135 240 minecraft:azalea_leaves[persistent=true]
setblock 382 132 270 minecraft:green_terracotta
fill 383 132 264 384 133 264 minecraft:jungle_log
setblock 384 132 228 minecraft:green_terracotta
fill 384 132 233 384 133 233 minecraft:jungle_log
fill 385 132 233 386 135 234 minecraft:oak_leaves[persistent=true]
fill 385 132 262 386 135 264 minecraft:azalea_leaves[persistent=true]
fill 386 132 235 386 135 235 minecraft:oak_leaves[persistent=true]
fill 386 132 261 387 135 261 minecraft:azalea_leaves[persistent=true]
fill 387 132 232 388 135 232 minecraft:oak_leaves[persistent=true]
fill 387 132 262 388 134 262 minecraft:azalea_leaves[persistent=true]
fill 387 132 264 387 135 264 minecraft:azalea_leaves[persistent=true]
fill 388 132 233 388 135 235 minecraft:oak_leaves[persistent=true]
fill 388 132 263 388 134 263 minecraft:azalea_leaves[persistent=true]
fill 389 132 270 389 134 270 minecraft:green_terracotta
setblock 390 132 228 minecraft:green_terracotta
setblock 391 132 270 minecraft:green_terracotta
setblock 394 132 270 minecraft:green_terracotta
setblock 405 132 228 minecraft:green_terracotta
fill 406 132 228 409 134 229 minecraft:jungle_leaves[persistent=true]
fill 406 132 270 407 135 270 minecraft:oak_leaves[persistent=true]
fill 407 132 230 409 134 230 minecraft:jungle_leaves[persistent=true]
fill 407 132 267 408 133 268 minecraft:oak_leaves[persistent=true]
fill 408 132 269 409 135 269 minecraft:oak_leaves[persistent=true]
fill 410 132 230 411 133 230 minecraft:jungle_log
fill 410 132 259 411 134 260 minecraft:oak_leaves[persistent=true]
fill 410 132 268 411 133 268 minecraft:jungle_log
fill 411 132 258 414 134 258 minecraft:oak_leaves[persistent=true]
fill 411 132 261 412 134 261 minecraft:oak_leaves[persistent=true]
fill 412 132 260 413 135 260 minecraft:oak_leaves[persistent=true]
fill 413 132 259 414 134 259 minecraft:oak_leaves[persistent=true]
fill 413 132 262 413 133 262 minecraft:jungle_log
setblock 415 132 270 minecraft:green_terracotta
fill 417 132 230 418 133 230 minecraft:jungle_log
fill 417 132 268 418 133 268 minecraft:jungle_log
fill 418 132 228 418 134 229 minecraft:oak_leaves[persistent=true]
fill 418 132 231 418 133 231 minecraft:jungle_log
setblock 418 132 232 minecraft:green_terracotta
setblock 418 132 250 minecraft:green_terracotta
setblock 418 132 265 minecraft:mossy_cobblestone
fill 418 132 266 418 133 267 minecraft:brown_terracotta
fill 418 132 269 418 134 270 minecraft:azalea_leaves[persistent=true]
fill 376 133 232 376 135 232 minecraft:brown_terracotta
fill 376 133 234 376 135 235 minecraft:brown_terracotta
setblock 376 133 241 minecraft:green_terracotta
fill 376 133 258 376 134 258 minecraft:azalea_leaves[persistent=true]
fill 376 133 264 376 136 264 minecraft:brown_terracotta
fill 377 133 263 378 133 263 minecraft:jungle_log
fill 378 133 259 378 134 260 minecraft:azalea_leaves[persistent=true]
fill 378 133 262 378 134 262 minecraft:azalea_leaves[persistent=true]
fill 379 133 240 379 134 240 minecraft:azalea_leaves[persistent=true]
setblock 380 133 228 minecraft:jungle_log
fill 380 133 237 380 134 237 minecraft:azalea_leaves[persistent=true]
fill 380 133 241 382 134 241 minecraft:azalea_leaves[persistent=true]
setblock 381 133 228 minecraft:jungle_leaves[persistent=true]
fill 381 133 270 381 134 270 minecraft:azalea_leaves[persistent=true]
setblock 382 133 270 minecraft:jungle_log
fill 383 133 239 383 135 240 minecraft:azalea_leaves[persistent=true]
fill 384 133 228 384 135 228 minecraft:brown_terracotta
setblock 384 133 263 minecraft:jungle_log
setblock 385 133 228 minecraft:green_terracotta
fill 385 133 235 385 133 236 minecraft:oak_leaves[persistent=true]
fill 385 133 261 385 135 261 minecraft:azalea_leaves[persistent=true]
fill 385 133 265 387 134 265 minecraft:azalea_leaves[persistent=true]
fill 386 133 232 386 135 232 minecraft:oak_leaves[persistent=true]
fill 386 133 236 387 134 236 minecraft:oak_leaves[persistent=true]
fill 386 133 260 387 134 260 minecraft:azalea_leaves[persistent=true]
fill 388 133 261 388 134 261 minecraft:azalea_leaves[persistent=true]
setblock 388 133 264 minecraft:azalea_leaves[persistent=true]
fill 389 133 233 389 134 234 minecraft:oak_leaves[persistent=true]
fill 390 133 228 390 135 228 minecraft:brown_terracotta
fill 391 133 270 391 135 270 minecraft:brown_terracotta
fill 394 133 270 394 135 270 minecraft:brown_terracotta
fill 405 133 228 405 135 228 minecraft:brown_terracotta
setblock 406 133 230 minecraft:jungle_leaves[persistent=true]
fill 406 133 268 406 134 269 minecraft:oak_leaves[persistent=true]
setblock 408 133 231 minecraft:jungle_leaves[persistent=true]
fill 409 133 267 409 134 268 minecraft:oak_leaves[persistent=true]
fill 410 133 228 410 135 229 minecraft:jungle_leaves[persistent=true]
fill 410 133 258 410 134 258 minecraft:oak_leaves[persistent=true]
setblock 410 133 261 minecraft:oak_leaves[persistent=true]
fill 410 133 269 410 134 270 minecraft:oak_leaves[persistent=true]
fill 411 133 262 412 133 262 minecraft:oak_leaves[persistent=true]
fill 412 133 228 412 134 228 minecraft:green_terracotta
fill 412 133 257 413 134 257 minecraft:oak_leaves[persistent=true]
fill 413 133 261 413 135 261 minecraft:oak_leaves[persistent=true]
setblock 414 133 270 minecraft:green_terracotta
setblock 415 133 228 minecraft:moss_block
fill 415 133 270 415 135 270 minecraft:brown_terracotta
fill 418 133 232 418 135 232 minecraft:brown_terracotta
setblock 418 133 240 minecraft:green_terracotta
setblock 418 133 241 minecraft:green_concrete
fill 418 133 250 418 136 250 minecraft:brown_terracotta
fill 418 133 257 418 135 257 minecraft:brown_terracotta
setblock 418 133 258 minecraft:green_terracotta
fill 418 133 265 418 135 265 minecraft:brown_terracotta
fill 376 134 230 376 135 230 minecraft:brown_terracotta
setblock 376 134 239 minecraft:mossy_cobblestone
fill 376 134 241 376 135 241 minecraft:brown_terracotta
fill 376 134 245 376 134 246 minecraft:green_terracotta
fill 376 134 247 376 135 247 minecraft:brown_terracotta
setblock 376 134 249 minecraft:green_terracotta
setblock 376 134 265 minecraft:green_terracotta
setblock 379 134 260 minecraft:azalea_leaves[persistent=true]
fill 380 134 228 381 134 228 minecraft:brown_terracotta
setblock 380 134 270 minecraft:green_terracotta
setblock 382 134 228 minecraft:green_terracotta
setblock 382 134 270 minecraft:azalea_leaves[persistent=true]
fill 384 134 262 384 134 264 minecraft:azalea_leaves[persistent=true]
fill 385 134 228 385 135 228 minecraft:brown_terracotta
setblock 385 134 232 minecraft:oak_leaves[persistent=true]
setblock 385 134 235 minecraft:oak_leaves[persistent=true]
setblock 395 134 228 minecraft:green_terracotta
setblock 395 134 270 minecraft:green_terracotta
fill 398 134 228 399 134 228 minecraft:brown_terracotta
setblock 399 134 270 minecraft:green_terracotta
setblock 400 134 228 minecraft:green_terracotta
setblock 401 134 270 minecraft:green_terracotta
fill 407 134 268 408 134 268 minecraft:oak_leaves[persistent=true]
setblock 408 134 267 minecraft:oak_leaves[persistent=true]
fill 410 134 268 410 135 268 minecraft:oak_leaves[persistent=true]
fill 411 134 228 411 135 228 minecraft:jungle_leaves[persistent=true]
setblock 411 134 257 minecraft:oak_leaves[persistent=true]
setblock 411 134 270 minecraft:green_terracotta
setblock 412 134 262 minecraft:oak_leaves[persistent=true]
setblock 414 134 228 minecraft:green_terracotta
fill 414 134 260 414 135 260 minecraft:oak_leaves[persistent=true]
setblock 414 134 270 minecraft:brown_terracotta
fill 415 134 228 415 135 228 minecraft:brown_terracotta
setblock 417 134 270 minecraft:azalea_leaves[persistent=true]
fill 418 134 230 418 135 231 minecraft:brown_terracotta
setblock 418 134 235 minecraft:green_terracotta
fill 418 134 236 418 135 236 minecraft:brown_terracotta
fill 418 134 240 418 134 241 minecraft:brown_terracotta
setblock 418 134 249 minecraft:green_terracotta
fill 418 134 258 418 135 258 minecraft:brown_terracotta
setblock 418 134 263 minecraft:green_terracotta
setblock 418 134 266 minecraft:green_terracotta
fill 418 134 267 418 135 268 minecraft:brown_terracotta
setblock 376 135 239 minecraft:brown_terracotta
fill 376 135 245 376 135 246 minecraft:brown_terracotta
setblock 376 135 249 minecraft:brown_terracotta
setblock 376 135 258 minecraft:brown_terracotta
setblock 376 135 262 minecraft:azalea_leaves[persistent=true]
setblock 376 135 265 minecraft:brown_terracotta
setblock 378 135 260 minecraft:azalea_leaves[persistent=true]
setblock 379 135 239 minecraft:light[level=15]
setblock 379 135 245 minecraft:light[level=12]
setblock 379 135 247 minecraft:light[level=15]
setblock 379 135 252 minecraft:light[level=12]
setblock 379 135 255 minecraft:light[level=15]
setblock 379 135 259 minecraft:light[level=12]
setblock 380 135 228 minecraft:moss_block
fill 380 135 238 380 135 239 minecraft:azalea_leaves[persistent=true]
fill 380 135 270 382 135 270 minecraft:brown_terracotta
fill 381 135 228 382 135 228 minecraft:brown_terracotta
fill 381 135 237 381 135 238 minecraft:azalea_leaves[persistent=true]
fill 381 135 241 382 135 241 minecraft:azalea_leaves[persistent=true]
setblock 382 135 238 minecraft:azalea_leaves[persistent=true]
fill 384 135 262 384 135 263 minecraft:azalea_leaves[persistent=true]
setblock 386 135 231 minecraft:light[level=12]
setblock 386 135 238 minecraft:light[level=12]
setblock 386 135 245 minecraft:light[level=12]
setblock 386 135 252 minecraft:light[level=12]
setblock 386 135 259 minecraft:light[level=12]
setblock 386 135 266 minecraft:light[level=12]
setblock 387 135 231 minecraft:light[level=15]
setblock 387 135 239 minecraft:light[level=15]
setblock 387 135 247 minecraft:light[level=15]
setblock 387 135 255 minecraft:light[level=15]
setblock 387 135 262 minecraft:azalea_leaves[persistent=true]
fill 389 135 270 389 136 270 minecraft:brown_terracotta
setblock 393 135 231 minecraft:light[level=12]
setblock 393 135 238 minecraft:light[level=12]
setblock 393 135 245 minecraft:light[level=12]
setblock 393 135 252 minecraft:light[level=12]
setblock 393 135 259 minecraft:light[level=12]
setblock 393 135 266 minecraft:light[level=12]
setblock 395 135 228 minecraft:brown_terracotta
setblock 395 135 231 minecraft:light[level=15]
setblock 395 135 239 minecraft:light[level=15]
setblock 395 135 247 minecraft:light[level=15]
setblock 395 135 255 minecraft:light[level=15]
setblock 395 135 263 minecraft:light[level=15]
setblock 395 135 270 minecraft:brown_terracotta
setblock 398 135 228 minecraft:brown_terracotta
setblock 399 135 228 minecraft:mossy_cobblestone
setblock 399 135 270 minecraft:brown_terracotta
setblock 400 135 228 minecraft:brown_terracotta
setblock 400 135 231 minecraft:light[level=12]
setblock 400 135 238 minecraft:light[level=12]
setblock 400 135 245 minecraft:light[level=12]
setblock 400 135 252 minecraft:light[level=12]
setblock 400 135 259 minecraft:light[level=12]
setblock 400 135 266 minecraft:light[level=12]
fill 401 135 270 401 136 270 minecraft:brown_terracotta
setblock 402 135 228 minecraft:green_concrete
setblock 403 135 231 minecraft:light[level=15]
setblock 403 135 239 minecraft:light[level=15]
setblock 403 135 247 minecraft:light[level=15]
setblock 403 135 255 minecraft:light[level=15]
setblock 403 135 263 minecraft:light[level=15]
fill 406 135 228 409 135 228 minecraft:jungle_leaves[persistent=true]
setblock 406 135 269 minecraft:oak_leaves[persistent=true]
fill 407 135 229 409 135 229 minecraft:jungle_leaves[persistent=true]
setblock 407 135 231 minecraft:light[level=12]
setblock 407 135 238 minecraft:light[level=12]
setblock 407 135 245 minecraft:light[level=12]
setblock 407 135 252 minecraft:light[level=12]
setblock 407 135 259 minecraft:light[level=12]
setblock 407 135 266 minecraft:light[level=12]
fill 408 135 268 409 135 268 minecraft:oak_leaves[persistent=true]
fill 410 135 260 411 135 260 minecraft:oak_leaves[persistent=true]
setblock 410 135 269 minecraft:oak_leaves[persistent=true]
fill 410 135 270 411 135 270 minecraft:brown_terracotta
setblock 411 135 239 minecraft:light[level=15]
setblock 411 135 247 minecraft:light[level=15]
setblock 411 135 255 minecraft:light[level=15]
fill 411 135 258 411 135 259 minecraft:oak_leaves[persistent=true]
setblock 411 135 263 minecraft:light[level=15]
setblock 412 135 228 minecraft:brown_terracotta
fill 412 135 257 412 135 258 minecraft:oak_leaves[persistent=true]
setblock 412 135 261 minecraft:oak_leaves[persistent=true]
setblock 413 135 259 minecraft:oak_leaves[persistent=true]
setblock 414 135 228 minecraft:brown_terracotta
setblock 414 135 238 minecraft:light[level=12]
setblock 414 135 245 minecraft:light[level=12]
setblock 414 135 252 minecraft:light[level=12]
setblock 414 135 259 minecraft:light[level=12]
setblock 414 135 270 minecraft:jungle_leaves[persistent=true]
setblock 417 135 270 minecraft:brown_terracotta
fill 418 135 228 418 135 229 minecraft:brown_terracotta
setblock 418 135 235 minecraft:brown_terracotta
setblock 418 135 240 minecraft:brown_terracotta
setblock 418 135 241 minecraft:mossy_cobblestone
setblock 418 135 249 minecraft:brown_terracotta
setblock 418 135 263 minecraft:brown_terracotta
setblock 418 135 266 minecraft:brown_terracotta
setblock 418 135 269 minecraft:brown_terracotta
setblock 418 135 270 minecraft:azalea_leaves[persistent=true]
fill 376 136 228 376 137 235 minecraft:green_terracotta
fill 376 136 237 376 136 255 minecraft:green_terracotta
setblock 376 136 256 minecraft:brown_terracotta
fill 376 136 257 376 137 258 minecraft:green_terracotta
fill 376 136 260 376 141 263 minecraft:green_terracotta
fill 376 136 265 376 157 267 minecraft:green_terracotta
setblock 376 136 268 minecraft:brown_terracotta
fill 376 136 269 376 184 269 minecraft:green_terracotta
setblock 376 136 270 minecraft:brown_terracotta
fill 377 136 228 379 145 228 minecraft:green_terracotta
fill 377 136 270 386 137 270 minecraft:green_terracotta
setblock 380 136 228 minecraft:brown_terracotta
setblock 381 136 228 minecraft:moss_block
setblock 381 136 239 minecraft:azalea_leaves[persistent=true]
setblock 382 136 228 minecraft:brown_terracotta
fill 383 136 228 391 139 228 minecraft:green_terracotta
fill 385 136 262 385 136 263 minecraft:azalea_leaves[persistent=true]
fill 387 136 233 387 136 234 minecraft:oak_leaves[persistent=true]
setblock 387 136 270 minecraft:brown_terracotta
fill 388 136 270 388 175 270 minecraft:green_terracotta
fill 390 136 270 392 157 270 minecraft:green_terracotta
fill 393 136 228 406 136 228 minecraft:green_terracotta
fill 394 136 270 400 136 270 minecraft:green_terracotta
fill 402 136 270 405 136 270 minecraft:green_terracotta
fill 406 136 270 407 136 270 minecraft:brown_terracotta
fill 407 136 228 410 136 228 minecraft:jungle_leaves[persistent=true]
setblock 408 136 229 minecraft:jungle_leaves[persistent=true]
fill 408 136 270 408 150 270 minecraft:green_terracotta
setblock 409 136 270 minecraft:oak_leaves[persistent=true]
fill 410 136 270 415 137 270 minecraft:green_terracotta
setblock 411 136 228 minecraft:brown_terracotta
setblock 411 136 259 minecraft:oak_leaves[persistent=true]
fill 412 136 228 418 136 228 minecraft:green_terracotta
setblock 413 136 260 minecraft:oak_leaves[persistent=true]
setblock 417 136 240 minecraft:green_wool
fill 417 136 270 418 136 270 minecraft:green_terracotta
fill 418 136 229 418 136 237 minecraft:green_terracotta
setblock 418 136 238 minecraft:brown_terracotta
fill 418 136 239 418 136 246 minecraft:green_terracotta
fill 418 136 248 418 164 249 minecraft:green_terracotta
fill 418 136 251 418 222 251 minecraft:green_terracotta
setblock 418 136 252 minecraft:brown_terracotta
fill 418 136 253 418 136 258 minecraft:green_terracotta
fill 418 136 260 418 169 263 minecraft:green_terracotta
setblock 418 136 265 minecraft:green_terracotta
setblock 418 136 266 minecraft:moss_block
fill 418 136 267 418 139 269 minecraft:green_terracotta
fill 376 137 236 376 137 245 minecraft:green_terracotta
fill 376 137 246 390 137 246 minecraft:brown_terracotta
fill 376 137 247 376 145 252 minecraft:green_terracotta
fill 376 137 253 417 137 253 minecraft:brown_terracotta
fill 376 137 254 376 137 256 minecraft:green_terracotta
fill 376 137 259 376 144 259 minecraft:green_terracotta
fill 376 137 264 376 157 264 minecraft:green_terracotta
fill 376 137 268 376 209 268 minecraft:green_terracotta
setblock 376 137 270 minecraft:green_terracotta
fill 377 137 229 391 138 245 minecraft:brown_terracotta
fill 377 137 247 389 138 252 minecraft:brown_terracotta
fill 377 137 254 417 139 269 minecraft:brown_terracotta
fill 380 137 228 382 143 228 minecraft:green_terracotta
fill 387 137 270 387 153 270 minecraft:green_terracotta
fill 389 137 270 389 143 270 minecraft:green_terracotta
fill 390 137 250 390 138 252 minecraft:brown_terracotta
fill 391 137 251 391 138 252 minecraft:brown_terracotta
fill 392 137 228 402 149 228 minecraft:green_terracotta
fill 392 137 229 417 138 244 minecraft:brown_terracotta
fill 392 137 252 417 138 252 minecraft:brown_terracotta
fill 393 137 270 394 137 270 minecraft:green_terracotta
fill 395 137 245 417 138 245 minecraft:brown_terracotta
fill 395 137 251 417 138 251 minecraft:brown_terracotta
setblock 395 137 270 minecraft:brown_terracotta
fill 396 137 246 418 137 246 minecraft:brown_terracotta
fill 396 137 250 417 138 250 minecraft:brown_terracotta
fill 396 137 270 403 137 270 minecraft:green_terracotta
fill 397 137 247 417 138 249 minecraft:brown_terracotta
setblock 403 137 228 minecraft:brown_terracotta
fill 404 137 228 411 137 228 minecraft:green_terracotta
setblock 404 137 270 minecraft:brown_terracotta
setblock 405 137 270 minecraft:green_terracotta
setblock 406 137 270 minecraft:brown_terracotta
fill 407 137 270 407 157 270 minecraft:green_terracotta
fill 409 137 270 409 157 270 minecraft:green_terracotta
setblock 412 137 228 minecraft:brown_terracotta
fill 413 137 228 417 145 228 minecraft:green_terracotta
fill 417 137 270 417 146 270 minecraft:green_terracotta
setblock 418 137 228 minecraft:brown_terracotta
fill 418 137 229 418 137 235 minecraft:green_terracotta
setblock 418 137 236 minecraft:brown_terracotta
fill 418 137 237 418 156 241 minecraft:green_terracotta
setblock 418 137 242 minecraft:brown_terracotta
fill 418 137 243 418 222 243 minecraft:green_terracotta
setblock 418 137 244 minecraft:brown_terracotta
fill 418 137 245 418 218 245 minecraft:green_terracotta
fill 418 137 247 418 218 247 minecraft:green_terracotta
fill 418 137 250 418 177 250 minecraft:green_terracotta
fill 418 137 252 418 137 256 minecraft:green_terracotta
setblock 418 137 257 minecraft:brown_terracotta
fill 418 137 258 418 170 259 minecraft:green_terracotta
setblock 418 137 264 minecraft:green_terracotta
setblock 418 137 265 minecraft:brown_terracotta
fill 418 137 266 418 158 266 minecraft:green_terracotta
setblock 418 137 270 minecraft:brown_terracotta
fill 376 138 228 376 138 229 minecraft:brown_terracotta
fill 376 138 230 376 142 235 minecraft:green_terracotta
fill 376 138 236 376 138 237 minecraft:brown_terracotta
fill 376 138 238 376 144 246 minecraft:green_terracotta
fill 376 138 253 376 220 253 minecraft:green_terracotta
setblock 376 138 254 minecraft:brown_terracotta
fill 376 138 255 376 149 257 minecraft:green_terracotta
setblock 376 138 258 minecraft:brown_terracotta
setblock 376 138 270 minecraft:brown_terracotta
fill 377 138 246 390 138 246 minecraft:brown_terracotta
fill 377 138 253 417 138 253 minecraft:brown_terracotta
fill 377 138 270 382 139 270 minecraft:green_terracotta
setblock 383 138 270 minecraft:green_concrete
fill 384 138 270 386 182 270 minecraft:green_terracotta
setblock 393 138 270 minecraft:brown_terracotta
fill 394 138 270 399 139 270 minecraft:green_terracotta
fill 396 138 246 417 138 246 minecraft:brown_terracotta
setblock 400 138 270 minecraft:mossy_cobblestone
fill 401 138 270 404 150 270 minecraft:green_terracotta
fill 403 138 228 405 169 228 minecraft:green_terracotta
setblock 405 138 270 minecraft:brown_terracotta
setblock 406 138 228 minecraft:brown_terracotta
fill 406 138 270 406 158 270 minecraft:green_terracotta
fill 407 138 228 412 139 228 minecraft:green_terracotta
fill 410 138 270 410 159 270 minecraft:green_terracotta
setblock 411 138 270 minecraft:brown_terracotta
fill 412 138 270 413 164 270 minecraft:green_terracotta
setblock 414 138 270 minecraft:brown_terracotta
fill 415 138 270 416 144 270 minecraft:green_terracotta
fill 418 138 228 418 144 233 minecraft:green_terracotta
setblock 418 138 234 minecraft:brown_terracotta
fill 418 138 235 418 220 236 minecraft:green_terracotta
setblock 418 138 242 minecraft:jungle_leaves[persistent=true]
fill 418 138 244 418 222 244 minecraft:green_terracotta
fill 418 138 246 418 179 246 minecraft:green_terracotta
fill 418 138 252 418 183 253 minecraft:green_terracotta
setblock 418 138 254 minecraft:brown_terracotta
fill 418 138 255 418 163 257 minecraft:green_terracotta
setblock 418 138 264 minecraft:brown_terracotta
fill 418 138 265 418 156 265 minecraft:green_terracotta
fill 418 138 270 418 170 270 minecraft:green_terracotta
fill 376 139 228 376 144 229 minecraft:green_terracotta
fill 376 139 236 376 144 237 minecraft:green_terracotta
fill 376 139 254 376 158 254 minecraft:green_terracotta
fill 376 139 258 376 145 258 minecraft:green_terracotta
fill 376 139 270 376 145 270 minecraft:green_terracotta
fill 377 139 229 387 139 253 minecraft:brown_terracotta
fill 383 139 270 383 184 270 minecraft:green_terracotta
fill 388 139 229 388 139 244 minecraft:brown_terracotta
fill 388 139 245 388 139 251 minecraft:bone_block
fill 388 139 252 388 152 253 minecraft:brown_terracotta
fill 389 139 229 389 139 243 minecraft:brown_terracotta
fill 389 139 244 389 139 245 minecraft:bone_block
fill 389 139 246 389 139 250 minecraft:shroomlight
fill 389 139 251 389 139 252 minecraft:bone_block
fill 389 139 253 389 152 253 minecraft:brown_terracotta
fill 390 139 229 417 139 242 minecraft:brown_terracotta
fill 390 139 243 390 139 244 minecraft:bone_block
fill 390 139 245 390 139 246 minecraft:shroomlight
fill 390 139 250 390 139 251 minecraft:shroomlight
fill 390 139 252 390 139 253 minecraft:bone_block
fill 391 139 243 396 139 243 minecraft:bone_block
fill 391 139 244 391 139 245 minecraft:shroomlight
fill 391 139 251 391 139 252 minecraft:shroomlight
fill 391 139 253 396 139 253 minecraft:bone_block
fill 392 139 244 395 139 244 minecraft:shroomlight
fill 392 139 252 395 139 252 minecraft:shroomlight
fill 393 139 270 393 223 270 minecraft:green_terracotta
fill 395 139 245 396 139 245 minecraft:shroomlight
fill 395 139 251 396 139 251 minecraft:shroomlight
fill 396 139 244 397 139 244 minecraft:bone_block
fill 396 139 246 397 139 246 minecraft:shroomlight
fill 396 139 250 397 139 250 minecraft:shroomlight
fill 396 139 252 397 139 252 minecraft:bone_block
fill 397 139 243 417 139 243 minecraft:brown_terracotta
fill 397 139 245 398 139 245 minecraft:bone_block
fill 397 139 247 397 139 249 minecraft:shroomlight
fill 397 139 251 398 139 251 minecraft:bone_block
fill 397 139 253 417 139 253 minecraft:brown_terracotta
fill 398 139 244 417 139 244 minecraft:brown_terracotta
fill 398 139 246 398 139 250 minecraft:bone_block
fill 398 139 252 417 139 252 minecraft:brown_terracotta
fill 399 139 245 417 139 251 minecraft:brown_terracotta
fill 400 139 270 400 218 270 minecraft:green_terracotta
fill 405 139 270 405 208 270 minecraft:green_terracotta
fill 406 139 228 406 143 228 minecraft:green_terracotta
fill 411 139 270 411 163 270 minecraft:green_terracotta
fill 414 139 270 414 144 270 minecraft:green_terracotta
fill 418 139 234 418 146 234 minecraft:green_terracotta
fill 418 139 242 418 224 242 minecraft:green_terracotta
fill 418 139 254 418 222 254 minecraft:green_terracotta
fill 418 139 264 418 196 264 minecraft:green_terracotta
fill 377 140 229 377 217 269 minecraft:brown_concrete
setblock 377 140 270 minecraft:moss_block
fill 378 140 229 417 217 229 minecraft:brown_concrete
fill 378 140 230 387 147 268 minecraft:brown_terracotta
fill 378 140 269 417 217 269 minecraft:brown_concrete
fill 378 140 270 382 144 270 minecraft:green_terracotta
fill 383 140 228 384 147 228 minecraft:green_terracotta
setblock 385 140 228 minecraft:green_concrete
fill 386 140 228 389 142 228 minecraft:green_terracotta
fill 388 140 230 388 140 251 minecraft:brown_terracotta
fill 388 140 254 416 147 268 minecraft:brown_terracotta
fill 389 140 230 389 142 245 minecraft:brown_terracotta
fill 389 140 246 389 140 250 minecraft:brown_concrete
fill 389 140 251 389 142 252 minecraft:brown_terracotta
setblock 390 140 228 minecraft:jungle_leaves[persistent=true]
fill 390 140 230 390 142 244 minecraft:brown_terracotta
fill 390 140 245 390 141 245 minecraft:brown_concrete
fill 390 140 251 390 141 251 minecraft:brown_concrete
fill 390 140 252 390 142 253 minecraft:brown_terracotta
fill 391 140 228 391 172 228 minecraft:green_terracotta
fill 391 140 230 416 140 243 minecraft:brown_terracotta
fill 391 140 244 395 140 244 minecraft:brown_concrete
fill 391 140 252 395 140 252 minecraft:brown_concrete
fill 391 140 253 416 140 253 minecraft:brown_terracotta
fill 394 140 270 394 222 270 minecraft:green_terracotta
setblock 395 140 270 minecraft:mossy_cobblestone
fill 396 140 244 416 142 244 minecraft:brown_terracotta
fill 396 140 245 396 141 245 minecraft:brown_concrete
fill 396 140 251 396 141 251 minecraft:brown_concrete
fill 396 140 252 416 142 252 minecraft:brown_terracotta
fill 396 140 270 399 148 270 minecraft:green_terracotta
fill 397 140 245 416 142 245 minecraft:brown_terracotta
fill 397 140 246 397 140 250 minecraft:brown_concrete
fill 397 140 251 416 142 251 minecraft:brown_terracotta
fill 398 140 246 416 140 250 minecraft:brown_terracotta
fill 407 140 228 409 141 228 minecraft:green_terracotta
setblock 410 140 228 minecraft:moss_block
fill 411 140 228 412 184 228 minecraft:green_terracotta
fill 417 140 230 417 217 268 minecraft:brown_concrete
setblock 418 140 267 minecraft:green_concrete
fill 418 140 268 418 170 269 minecraft:green_terracotta
fill 377 141 270 377 144 270 minecraft:green_terracotta
fill 385 141 228 385 210 228 minecraft:green_terracotta
fill 388 141 230 388 141 247 minecraft:brown_terracotta
setblock 388 141 248 minecraft:brown_concrete
fill 388 141 249 388 141 251 minecraft:brown_terracotta
fill 389 141 246 389 141 247 minecraft:brown_concrete
fill 389 141 249 389 141 250 minecraft:brown_concrete
fill 390 141 228 390 222 228 minecraft:green_terracotta
fill 391 141 230 392 141 243 minecraft:brown_terracotta
fill 391 141 244 392 141 244 minecraft:brown_concrete
fill 391 141 252 392 141 252 minecraft:brown_concrete
fill 391 141 253 392 141 253 minecraft:brown_terracotta
fill 393 141 230 416 147 242 minecraft:brown_terracotta
setblock 393 141 243 minecraft:brown_concrete
setblock 393 141 252 minecraft:light[level=12]
setblock 393 141 253 minecraft:brown_concrete
fill 394 141 243 416 141 243 minecraft:brown_terracotta
fill 394 141 244 395 141 244 minecraft:brown_concrete
fill 394 141 252 395 141 252 minecraft:brown_concrete
fill 394 141 253 416 141 253 minecraft:brown_terracotta
fill 395 141 270 395 217 270 minecraft:green_terracotta
fill 397 141 246 397 141 247 minecraft:brown_concrete
fill 397 141 249 397 141 250 minecraft:brown_concrete
fill 398 141 246 416 141 247 minecraft:brown_terracotta
setblock 398 141 248 minecraft:brown_concrete
fill 398 141 249 416 141 250 minecraft:brown_terracotta
fill 399 141 248 416 147 248 minecraft:brown_terracotta
fill 410 141 228 410 170 228 minecraft:green_terracotta
setblock 418 141 267 minecraft:green_terracotta
fill 376 142 260 376 144 262 minecraft:green_terracotta
setblock 376 142 263 minecraft:mossy_cobblestone
fill 388 142 230 388 143 246 minecraft:brown_terracotta
fill 388 142 247 388 142 249 minecraft:bone_block
fill 388 142 250 388 143 251 minecraft:brown_terracotta
setblock 389 142 246 minecraft:bone_block
setblock 389 142 250 minecraft:bone_block
setblock 390 142 245 minecraft:bone_block
setblock 390 142 251 minecraft:bone_block
fill 391 142 230 391 143 243 minecraft:brown_terracotta
setblock 391 142 244 minecraft:bone_block
setblock 391 142 252 minecraft:bone_block
fill 391 142 253 391 143 253 minecraft:brown_terracotta
fill 392 142 230 392 148 242 minecraft:brown_terracotta
fill 392 142 243 394 142 243 minecraft:bone_block
fill 392 142 253 394 142 253 minecraft:bone_block
fill 395 142 243 416 143 243 minecraft:brown_terracotta
setblock 395 142 244 minecraft:bone_block
setblock 395 142 247 minecraft:light[level=15]
setblock 395 142 252 minecraft:bone_block
fill 395 142 253 416 143 253 minecraft:brown_terracotta
setblock 396 142 245 minecraft:bone_block
setblock 396 142 251 minecraft:bone_block
setblock 397 142 246 minecraft:bone_block
setblock 397 142 250 minecraft:bone_block
fill 398 142 246 416 143 246 minecraft:brown_terracotta
fill 398 142 247 398 142 249 minecraft:bone_block
fill 398 142 250 416 143 250 minecraft:brown_terracotta
fill 399 142 247 416 148 247 minecraft:brown_terracotta
fill 399 142 249 416 148 249 minecraft:brown_terracotta
fill 407 142 228 407 144 228 minecraft:green_terracotta
setblock 408 142 228 minecraft:jungle_leaves[persistent=true]
fill 409 142 228 409 144 228 minecraft:green_terracotta
setblock 418 142 267 minecraft:moss_block
fill 376 143 230 376 144 233 minecraft:green_terracotta
setblock 376 143 234 minecraft:jungle_leaves[persistent=true]
fill 376 143 235 376 144 235 minecraft:green_terracotta
fill 376 143 263 376 145 263 minecraft:green_terracotta
setblock 386 143 228 minecraft:green_concrete
fill 387 143 228 389 170 228 minecraft:green_terracotta
fill 388 143 247 388 145 249 minecraft:brown_concrete
fill 389 143 230 389 147 244 minecraft:brown_terracotta
fill 389 143 245 389 143 246 minecraft:brown_concrete
fill 389 143 250 389 143 251 minecraft:brown_concrete
fill 389 143 252 389 147 252 minecraft:brown_terracotta
fill 390 143 230 390 147 243 minecraft:brown_terracotta
fill 390 143 244 391 143 244 minecraft:brown_concrete
fill 390 143 252 391 143 252 minecraft:brown_concrete
fill 390 143 253 390 147 253 minecraft:brown_terracotta
fill 392 143 243 394 145 243 minecraft:brown_concrete
fill 392 143 253 394 145 253 minecraft:brown_concrete
fill 395 143 244 396 143 244 minecraft:brown_concrete
fill 395 143 252 396 143 252 minecraft:brown_concrete
fill 397 143 244 416 147 244 minecraft:brown_terracotta
fill 397 143 245 397 143 246 minecraft:brown_concrete
fill 397 143 250 397 143 251 minecraft:brown_concrete
fill 397 143 252 416 147 252 minecraft:brown_terracotta
fill 398 143 245 416 147 245 minecraft:brown_terracotta
fill 398 143 247 398 145 249 minecraft:brown_concrete
fill 398 143 251 416 147 251 minecraft:brown_terracotta
fill 408 143 228 408 144 228 minecraft:green_terracotta
fill 418 143 267 418 170 267 minecraft:green_terracotta
fill 376 144 234 376 145 234 minecraft:green_terracotta
fill 380 144 228 380 183 228 minecraft:green_terracotta
setblock 381 144 228 minecraft:jungle_leaves[persistent=true]
fill 382 144 228 382 147 228 minecraft:green_terracotta
fill 386 144 228 386 207 228 minecraft:green_terracotta
fill 388 144 230 388 147 245 minecraft:brown_terracotta
fill 388 144 246 388 145 246 minecraft:brown_concrete
fill 388 144 250 388 145 250 minecraft:brown_concrete
fill 388 144 251 388 147 251 minecraft:brown_terracotta
fill 389 144 245 389 145 245 minecraft:brown_concrete
fill 389 144 251 389 145 251 minecraft:brown_concrete
setblock 389 144 270 minecraft:green_concrete
fill 390 144 244 390 145 244 minecraft:brown_concrete
fill 390 144 252 390 145 252 minecraft:brown_concrete
fill 391 144 230 391 150 242 minecraft:brown_terracotta
fill 391 144 243 391 145 243 minecraft:brown_concrete
fill 391 144 253 391 145 253 minecraft:brown_concrete
fill 395 144 243 395 145 243 minecraft:brown_concrete
fill 395 144 253 395 145 253 minecraft:brown_concrete
fill 396 144 243 416 147 243 minecraft:brown_terracotta
fill 396 144 244 396 145 244 minecraft:brown_concrete
fill 396 144 252 396 145 252 minecraft:brown_concrete
fill 396 144 253 416 147 253 minecraft:brown_terracotta
fill 397 144 245 397 145 245 minecraft:brown_concrete
fill 397 144 251 397 145 251 minecraft:brown_concrete
fill 398 144 246 398 145 246 minecraft:brown_concrete
fill 398 144 250 398 145 250 minecraft:brown_concrete
fill 399 144 246 416 150 246 minecraft:brown_terracotta
fill 399 144 250 416 150 250 minecraft:brown_terracotta
setblock 406 144 228 minecraft:moss_block
fill 376 145 228 376 148 228 minecraft:azalea_leaves[persistent=true]
setblock 376 145 229 minecraft:green_terracotta
fill 376 145 230 376 146 230 minecraft:jungle_log
fill 376 145 231 376 157 233 minecraft:green_terracotta
setblock 376 145 235 minecraft:jungle_log
fill 376 145 236 376 146 238 minecraft:azalea_leaves[persistent=true]
fill 376 145 239 376 145 246 minecraft:green_terracotta
fill 376 145 259 376 147 262 minecraft:jungle_leaves[persistent=true]
fill 377 145 270 377 147 270 minecraft:oak_leaves[persistent=true]
fill 378 145 270 378 146 270 minecraft:jungle_log
fill 379 145 270 380 158 270 minecraft:green_terracotta
fill 381 145 228 381 170 228 minecraft:green_terracotta
fill 381 145 270 381 146 270 minecraft:jungle_log
fill 382 145 270 382 170 270 minecraft:green_terracotta
fill 389 145 270 389 218 270 minecraft:green_terracotta
fill 406 145 228 409 147 228 minecraft:jungle_leaves[persistent=true]
fill 414 145 270 415 146 270 minecraft:jungle_log
fill 416 145 270 416 196 270 minecraft:green_terracotta
fill 418 145 228 418 148 228 minecraft:oak_leaves[persistent=true]
fill 418 145 229 418 145 233 minecraft:green_terracotta
fill 376 146 229 376 148 229 minecraft:azalea_leaves[persistent=true]
setblock 376 146 234 minecraft:jungle_log
fill 376 146 235 376 148 235 minecraft:azalea_leaves[persistent=true]
fill 376 146 239 376 148 243 minecraft:green_terracotta
setblock 376 146 244 minecraft:jungle_leaves[persistent=true]
fill 376 146 245 376 184 246 minecraft:green_terracotta
setblock 376 146 247 minecraft:moss_block
fill 376 146 248 376 156 252 minecraft:green_terracotta
fill 376 146 258 376 147 258 minecraft:jungle_leaves[persistent=true]
setblock 376 146 263 minecraft:jungle_leaves[persistent=true]
fill 376 146 270 376 148 270 minecraft:oak_leaves[persistent=true]
fill 377 146 228 377 147 228 minecraft:azalea_leaves[persistent=true]
fill 378 146 228 379 157 228 minecraft:green_terracotta
fill 388 146 246 388 146 250 minecraft:bone_block
setblock 389 146 245 minecraft:bone_block
setblock 389 146 251 minecraft:bone_block
setblock 390 146 244 minecraft:bone_block
setblock 390 146 252 minecraft:bone_block
fill 391 146 243 395 146 243 minecraft:bone_block
fill 391 146 253 395 146 253 minecraft:bone_block
setblock 396 146 244 minecraft:bone_block
setblock 396 146 252 minecraft:bone_block
setblock 397 146 245 minecraft:bone_block
setblock 397 146 251 minecraft:bone_block
fill 398 146 246 398 146 250 minecraft:bone_block
fill 413 146 228 416 157 228 minecraft:green_terracotta
fill 417 146 228 417 147 228 minecraft:oak_leaves[persistent=true]
setblock 418 146 229 minecraft:oak_leaves[persistent=true]
fill 418 146 230 418 149 233 minecraft:green_terracotta
fill 376 147 230 376 196 230 minecraft:green_terracotta
setblock 376 147 234 minecraft:azalea_leaves[persistent=true]
fill 376 147 236 376 147 237 minecraft:azalea_leaves[persistent=true]
fill 376 147 238 376 168 238 minecraft:green_terracotta
fill 376 147 244 376 177 244 minecraft:green_terracotta
fill 376 147 247 376 222 247 minecraft:green_terracotta
fill 376 147 263 376 171 263 minecraft:green_terracotta
fill 378 147 270 378 157 270 minecraft:green_terracotta
fill 381 147 270 381 219 270 minecraft:green_terracotta
fill 388 147 246 388 147 250 minecraft:brown_concrete
setblock 389 147 245 minecraft:brown_concrete
setblock 389 147 251 minecraft:brown_concrete
setblock 390 147 244 minecraft:brown_concrete
setblock 390 147 252 minecraft:brown_concrete
fill 391 147 243 395 147 243 minecraft:brown_concrete
fill 391 147 253 395 147 253 minecraft:brown_concrete
setblock 393 147 245 minecraft:light[level=12]
setblock 393 147 252 minecraft:light[level=12]
setblock 396 147 244 minecraft:brown_concrete
setblock 396 147 252 minecraft:brown_concrete
setblock 397 147 245 minecraft:brown_concrete
setblock 397 147 251 minecraft:brown_concrete
fill 398 147 246 398 147 250 minecraft:brown_concrete
fill 414 147 270 415 169 270 minecraft:green_terracotta
setblock 417 147 270 minecraft:moss_block
fill 418 147 229 418 162 229 minecraft:green_terracotta
setblock 418 147 234 minecraft:moss_block
fill 376 148 234 376 157 234 minecraft:green_terracotta
setblock 376 148 236 minecraft:azalea_leaves[persistent=true]
fill 376 148 237 376 184 237 minecraft:green_terracotta
fill 376 148 258 376 171 258 minecraft:green_terracotta
fill 376 148 259 376 148 261 minecraft:jungle_leaves[persistent=true]
fill 376 148 262 376 170 262 minecraft:green_terracotta
fill 377 148 228 377 158 228 minecraft:green_terracotta
fill 377 148 270 377 157 270 minecraft:green_terracotta
fill 378 148 230 386 154 268 minecraft:brown_terracotta
setblock 382 148 228 minecraft:green_concrete
setblock 383 148 228 minecraft:moss_block
fill 384 148 228 384 210 228 minecraft:green_terracotta
fill 387 148 230 387 148 247 minecraft:brown_terracotta
fill 387 148 248 387 149 248 minecraft:brown_concrete
fill 387 148 249 387 148 268 minecraft:brown_terracotta
fill 388 148 230 388 152 244 minecraft:brown_terracotta
fill 388 148 245 388 148 247 minecraft:brown_concrete
fill 388 148 249 388 148 251 minecraft:brown_concrete
fill 388 148 254 392 148 268 minecraft:brown_terracotta
fill 389 148 230 389 152 243 minecraft:brown_terracotta
fill 389 148 244 389 149 244 minecraft:brown_concrete
fill 389 148 252 389 149 252 minecraft:brown_concrete
fill 390 148 230 390 153 242 minecraft:brown_terracotta
fill 390 148 243 392 148 243 minecraft:brown_concrete
fill 390 148 253 392 148 253 minecraft:brown_concrete
fill 393 148 230 416 154 241 minecraft:brown_terracotta
fill 393 148 242 393 149 242 minecraft:brown_concrete
fill 393 148 254 393 149 254 minecraft:brown_concrete
fill 393 148 255 416 154 268 minecraft:brown_terracotta
fill 394 148 242 416 148 242 minecraft:brown_terracotta
fill 394 148 243 396 148 243 minecraft:brown_concrete
fill 394 148 253 396 148 253 minecraft:brown_concrete
fill 394 148 254 416 148 254 minecraft:brown_terracotta
fill 397 148 243 416 152 243 minecraft:brown_terracotta
fill 397 148 244 397 149 244 minecraft:brown_concrete
fill 397 148 252 397 149 252 minecraft:brown_concrete
fill 397 148 253 416 152 253 minecraft:brown_terracotta
fill 398 148 244 416 152 244 minecraft:brown_terracotta
fill 398 148 245 398 148 247 minecraft:brown_concrete
fill 398 148 249 398 148 251 minecraft:brown_concrete
fill 398 148 252 416 152 252 minecraft:brown_terracotta
fill 399 148 245 416 153 245 minecraft:brown_terracotta
fill 399 148 248 399 149 248 minecraft:brown_concrete
fill 399 148 251 416 153 251 minecraft:brown_terracotta
fill 400 148 248 416 154 248 minecraft:brown_terracotta
fill 406 148 228 406 170 228 minecraft:green_terracotta
fill 407 148 228 408 148 228 minecraft:jungle_leaves[persistent=true]
fill 409 148 228 409 166 228 minecraft:green_terracotta
fill 417 148 228 417 162 228 minecraft:green_terracotta
fill 417 148 270 417 222 270 minecraft:green_terracotta
fill 418 148 234 418 220 234 minecraft:green_terracotta
fill 376 149 228 376 158 229 minecraft:green_terracotta
fill 376 149 235 376 150 236 minecraft:green_terracotta
setblock 376 149 239 minecraft:green_concrete
fill 376 149 240 376 191 243 minecraft:green_terracotta
fill 376 149 259 376 149 261 minecraft:green_terracotta
fill 376 149 270 376 157 270 minecraft:green_terracotta
fill 382 149 228 383 170 228 minecraft:green_terracotta
fill 387 149 230 387 150 246 minecraft:brown_terracotta
setblock 387 149 247 minecraft:brown_concrete
setblock 387 149 249 minecraft:brown_concrete
fill 387 149 250 387 150 268 minecraft:brown_terracotta
fill 388 149 245 388 149 246 minecraft:brown_concrete
fill 388 149 250 388 149 251 minecraft:brown_concrete
fill 388 149 254 391 150 268 minecraft:brown_terracotta
fill 390 149 243 391 149 243 minecraft:brown_concrete
fill 390 149 253 391 149 253 minecraft:brown_concrete
fill 392 149 230 392 155 241 minecraft:brown_terracotta
setblock 392 149 242 minecraft:brown_concrete
setblock 392 149 254 minecraft:brown_concrete
fill 392 149 255 392 155 268 minecraft:brown_terracotta
setblock 394 149 242 minecraft:brown_concrete
setblock 394 149 254 minecraft:brown_concrete
fill 395 149 242 416 150 242 minecraft:brown_terracotta
fill 395 149 243 396 149 243 minecraft:brown_concrete
setblock 395 149 247 minecraft:light[level=15]
fill 395 149 253 396 149 253 minecraft:brown_concrete
fill 395 149 254 416 150 254 minecraft:brown_terracotta
fill 396 149 270 397 188 270 minecraft:green_terracotta
fill 398 149 245 398 149 246 minecraft:brown_concrete
fill 398 149 250 398 149 251 minecraft:brown_concrete
setblock 398 149 270 minecraft:mossy_cobblestone
setblock 399 149 247 minecraft:brown_concrete
setblock 399 149 249 minecraft:brown_concrete
fill 399 149 270 399 179 270 minecraft:green_terracotta
fill 400 149 247 416 155 247 minecraft:brown_terracotta
fill 400 149 249 416 155 249 minecraft:brown_terracotta
fill 407 149 228 408 170 228 minecraft:green_terracotta
fill 418 149 228 418 196 228 minecraft:green_terracotta
fill 376 150 239 376 201 239 minecraft:green_terracotta
setblock 376 150 255 minecraft:jungle_leaves[persistent=true]
fill 376 150 256 376 153 257 minecraft:green_terracotta
fill 376 150 259 376 160 259 minecraft:green_terracotta
setblock 376 150 260 minecraft:mossy_cobblestone
fill 376 150 261 376 169 261 minecraft:green_terracotta
fill 387 150 247 387 150 249 minecraft:bone_block
fill 388 150 245 388 150 246 minecraft:bone_block
fill 388 150 250 388 150 251 minecraft:bone_block
setblock 389 150 244 minecraft:bone_block
setblock 389 150 252 minecraft:bone_block
fill 390 150 243 391 150 243 minecraft:bone_block
fill 390 150 253 391 150 253 minecraft:bone_block
fill 392 150 228 395 169 228 minecraft:green_terracotta
fill 392 150 242 394 150 242 minecraft:bone_block
fill 392 150 254 394 150 254 minecraft:bone_block
fill 395 150 243 396 150 243 minecraft:bone_block
fill 395 150 253 396 150 253 minecraft:bone_block
setblock 396 150 228 minecraft:mossy_cobblestone
fill 397 150 228 402 160 228 minecraft:green_terracotta
setblock 397 150 244 minecraft:bone_block
setblock 397 150 252 minecraft:bone_block
fill 398 150 245 398 150 246 minecraft:bone_block
fill 398 150 250 398 150 251 minecraft:bone_block
fill 398 150 270 398 222 270 minecraft:green_terracotta
fill 399 150 247 399 150 249 minecraft:bone_block
setblock 418 150 230 minecraft:moss_block
fill 418 150 231 418 170 233 minecraft:green_terracotta
fill 376 151 235 376 158 235 minecraft:green_terracotta
setblock 376 151 236 minecraft:moss_block
fill 376 151 255 376 218 255 minecraft:green_terracotta
fill 376 151 260 376 169 260 minecraft:green_terracotta
fill 387 151 230 387 153 245 minecraft:brown_terracotta
fill 387 151 246 387 153 250 minecraft:brown_concrete
fill 387 151 251 387 153 268 minecraft:brown_terracotta
fill 388 151 245 388 153 245 minecraft:brown_concrete
fill 388 151 251 388 153 251 minecraft:brown_concrete
fill 388 151 254 390 153 268 minecraft:brown_terracotta
fill 389 151 244 389 152 244 minecraft:brown_concrete
fill 389 151 252 389 152 252 minecraft:brown_concrete
fill 390 151 243 390 153 243 minecraft:brown_concrete
fill 390 151 253 390 153 253 minecraft:brown_concrete
fill 391 151 230 391 156 241 minecraft:brown_terracotta
fill 391 151 242 395 153 242 minecraft:brown_concrete
fill 391 151 254 395 153 254 minecraft:brown_concrete
fill 391 151 255 391 156 268 minecraft:brown_terracotta
fill 396 151 228 396 157 228 minecraft:green_terracotta
fill 396 151 242 416 153 242 minecraft:brown_terracotta
fill 396 151 243 396 153 243 minecraft:brown_concrete
fill 396 151 253 396 153 253 minecraft:brown_concrete
fill 396 151 254 416 153 254 minecraft:brown_terracotta
fill 397 151 244 397 152 244 minecraft:brown_concrete
fill 397 151 252 397 152 252 minecraft:brown_concrete
fill 398 151 245 398 153 245 minecraft:brown_concrete
fill 398 151 251 398 153 251 minecraft:brown_concrete
fill 399 151 246 399 153 250 minecraft:brown_concrete
fill 400 151 246 416 156 246 minecraft:brown_terracotta
fill 400 151 250 416 156 250 minecraft:brown_terracotta
fill 401 151 270 403 169 270 minecraft:green_terracotta
setblock 404 151 270 minecraft:jungle_leaves[persistent=true]
setblock 408 151 270 minecraft:moss_block
fill 418 151 230 418 196 230 minecraft:green_terracotta
fill 376 152 236 376 155 236 minecraft:green_terracotta
fill 404 152 270 404 161 270 minecraft:green_terracotta
fill 408 152 270 408 156 270 minecraft:green_terracotta
fill 388 153 230 388 157 243 minecraft:brown_terracotta
setblock 388 153 244 minecraft:brown_concrete
setblock 388 153 252 minecraft:brown_concrete
fill 388 153 253 388 157 253 minecraft:brown_terracotta
fill 389 153 230 389 157 242 minecraft:brown_terracotta
setblock 389 153 243 minecraft:brown_concrete
setblock 389 153 253 minecraft:brown_concrete
setblock 393 153 245 minecraft:light[level=12]
setblock 393 153 252 minecraft:light[level=12]
setblock 397 153 243 minecraft:brown_concrete
setblock 397 153 253 minecraft:brown_concrete
fill 398 153 243 416 157 243 minecraft:brown_terracotta
setblock 398 153 244 minecraft:brown_concrete
setblock 398 153 252 minecraft:brown_concrete
fill 398 153 253 416 157 253 minecraft:brown_terracotta
fill 399 153 244 416 157 244 minecraft:brown_terracotta
fill 399 153 252 416 157 252 minecraft:brown_terracotta
setblock 376 154 256 minecraft:mossy_cobblestone
fill 376 154 257 376 174 257 minecraft:green_terracotta
fill 387 154 230 387 157 244 minecraft:brown_terracotta
fill 387 154 245 387 154 251 minecraft:bone_block
fill 387 154 252 387 157 268 minecraft:brown_terracotta
setblock 387 154 270 minecraft:moss_block
setblock 388 154 244 minecraft:bone_block
setblock 388 154 252 minecraft:bone_block
fill 388 154 254 389 157 268 minecraft:brown_terracotta
setblock 389 154 243 minecraft:bone_block
setblock 389 154 253 minecraft:bone_block
fill 390 154 230 390 159 241 minecraft:brown_terracotta
fill 390 154 242 396 154 242 minecraft:bone_block
fill 390 154 254 396 154 254 minecraft:bone_block
fill 390 154 255 390 159 268 minecraft:brown_terracotta
fill 397 154 242 416 157 242 minecraft:brown_terracotta
setblock 397 154 243 minecraft:bone_block
setblock 397 154 253 minecraft:bone_block
fill 397 154 254 416 157 254 minecraft:brown_terracotta
setblock 398 154 244 minecraft:bone_block
setblock 398 154 252 minecraft:bone_block
fill 399 154 245 399 154 251 minecraft:bone_block
fill 400 154 245 416 159 245 minecraft:brown_terracotta
fill 400 154 251 416 159 251 minecraft:brown_terracotta
fill 376 155 256 376 157 256 minecraft:green_terracotta
fill 378 155 230 385 161 268 minecraft:brown_terracotta
fill 386 155 230 386 155 247 minecraft:brown_terracotta
fill 386 155 248 386 157 248 minecraft:brown_concrete
fill 386 155 249 386 155 268 minecraft:brown_terracotta
fill 387 155 245 387 155 247 minecraft:brown_concrete
fill 387 155 249 387 155 251 minecraft:brown_concrete
fill 387 155 270 387 184 270 minecraft:green_terracotta
fill 388 155 244 388 157 244 minecraft:brown_concrete
fill 388 155 252 388 157 252 minecraft:brown_concrete
fill 389 155 243 389 157 243 minecraft:brown_concrete
fill 389 155 253 389 157 253 minecraft:brown_concrete
fill 390 155 242 392 155 242 minecraft:brown_concrete
fill 390 155 254 392 155 254 minecraft:brown_concrete
fill 393 155 230 416 161 240 minecraft:brown_terracotta
fill 393 155 241 393 157 241 minecraft:brown_concrete
fill 393 155 255 393 157 255 minecraft:brown_concrete
fill 393 155 256 416 161 268 minecraft:brown_terracotta
fill 394 155 241 416 155 241 minecraft:brown_terracotta
fill 394 155 242 396 155 242 minecraft:brown_concrete
fill 394 155 254 396 155 254 minecraft:brown_concrete
fill 394 155 255 416 155 255 minecraft:brown_terracotta
fill 397 155 243 397 157 243 minecraft:brown_concrete
fill 397 155 253 397 157 253 minecraft:brown_concrete
fill 398 155 244 398 157 244 minecraft:brown_concrete
fill 398 155 252 398 157 252 minecraft:brown_concrete
fill 399 155 245 399 155 247 minecraft:brown_concrete
fill 399 155 249 399 155 251 minecraft:brown_concrete
fill 400 155 248 400 157 248 minecraft:brown_concrete
fill 401 155 248 416 161 248 minecraft:brown_terracotta
setblock 376 156 236 minecraft:moss_block
fill 386 156 230 386 156 246 minecraft:brown_terracotta
fill 386 156 247 386 157 247 minecraft:brown_concrete
fill 386 156 249 386 157 249 minecraft:brown_concrete
fill 386 156 250 386 156 268 minecraft:brown_terracotta
fill 387 156 245 387 156 246 minecraft:brown_concrete
setblock 387 156 247 minecraft:light[level=15]
fill 387 156 250 387 156 251 minecraft:brown_concrete
fill 390 156 242 391 156 242 minecraft:brown_concrete
fill 390 156 254 391 156 254 minecraft:brown_concrete
fill 392 156 230 392 162 240 minecraft:brown_terracotta
fill 392 156 241 392 157 241 minecraft:brown_concrete
fill 392 156 255 392 157 255 minecraft:brown_concrete
fill 392 156 256 392 162 268 minecraft:brown_terracotta
fill 394 156 241 394 157 241 minecraft:brown_concrete
fill 394 156 255 394 157 255 minecraft:brown_concrete
fill 395 156 241 416 156 241 minecraft:brown_terracotta
fill 395 156 242 396 156 242 minecraft:brown_concrete
setblock 395 156 247 minecraft:light[level=15]
fill 395 156 254 396 156 254 minecraft:brown_concrete
fill 395 156 255 416 156 255 minecraft:brown_terracotta
fill 399 156 245 399 156 246 minecraft:brown_concrete
fill 399 156 250 399 156 251 minecraft:brown_concrete
fill 400 156 247 400 157 247 minecraft:brown_concrete
fill 400 156 249 400 157 249 minecraft:brown_concrete
fill 401 156 247 416 162 247 minecraft:brown_terracotta
fill 401 156 249 416 162 249 minecraft:brown_terracotta
fill 376 157 236 376 172 236 minecraft:green_terracotta
setblock 376 157 248 minecraft:mossy_cobblestone
fill 376 157 249 376 176 252 minecraft:green_terracotta
fill 386 157 230 386 159 245 minecraft:brown_terracotta
setblock 386 157 246 minecraft:brown_concrete
setblock 386 157 250 minecraft:brown_concrete
fill 386 157 251 386 159 268 minecraft:brown_terracotta
setblock 387 157 245 minecraft:brown_concrete
setblock 387 157 251 minecraft:brown_concrete
setblock 390 157 242 minecraft:brown_concrete
setblock 390 157 254 minecraft:brown_concrete
fill 391 157 230 391 163 240 minecraft:brown_terracotta
setblock 391 157 241 minecraft:brown_concrete
setblock 391 157 255 minecraft:brown_concrete
fill 391 157 256 391 163 268 minecraft:brown_terracotta
setblock 395 157 241 minecraft:brown_concrete
setblock 395 157 255 minecraft:brown_concrete
fill 396 157 241 416 159 241 minecraft:brown_terracotta
setblock 396 157 242 minecraft:brown_concrete
setblock 396 157 254 minecraft:brown_concrete
fill 396 157 255 416 159 255 minecraft:brown_terracotta
setblock 399 157 245 minecraft:brown_concrete
setblock 399 157 251 minecraft:brown_concrete
setblock 400 157 246 minecraft:brown_concrete
setblock 400 157 250 minecraft:brown_concrete
fill 401 157 246 416 163 246 minecraft:brown_terracotta
fill 401 157 250 416 163 250 minecraft:brown_terracotta
fill 408 157 270 408 161 270 minecraft:oak_leaves[persistent=true]
fill 418 157 237 418 157 239 minecraft:green_terracotta
setblock 418 157 240 minecraft:moss_block
setblock 418 157 241 minecraft:mossy_cobblestone
setblock 418 157 265 minecraft:moss_block
fill 376 158 231 376 196 231 minecraft:green_terracotta
fill 376 158 232 376 158 234 minecraft:jungle_log
fill 376 158 248 376 203 248 minecraft:green_terracotta
setblock 376 158 256 minecraft:jungle_leaves[persistent=true]
setblock 376 158 264 minecraft:moss_block
fill 376 158 265 376 196 265 minecraft:green_terracotta
fill 376 158 266 376 159 267 minecraft:jungle_log
fill 376 158 270 377 161 270 minecraft:azalea_leaves[persistent=true]
fill 378 158 228 378 159 228 minecraft:jungle_log
setblock 378 158 270 minecraft:jungle_log
fill 379 158 228 379 170 228 minecraft:green_terracotta
fill 386 158 246 386 158 250 minecraft:bone_block
fill 387 158 230 387 162 243 minecraft:brown_terracotta
fill 387 158 244 387 158 245 minecraft:bone_block
fill 387 158 251 387 158 252 minecraft:bone_block
fill 387 158 253 387 162 268 minecraft:brown_terracotta
fill 388 158 230 388 162 242 minecraft:brown_terracotta
setblock 388 158 243 minecraft:bone_block
setblock 388 158 253 minecraft:bone_block
fill 388 158 254 388 162 268 minecraft:brown_terracotta
fill 389 158 230 389 163 241 minecraft:brown_terracotta
fill 389 158 242 390 158 242 minecraft:bone_block
fill 389 158 254 390 158 254 minecraft:bone_block
fill 389 158 255 389 163 268 minecraft:brown_terracotta
setblock 390 158 270 minecraft:moss_block
fill 391 158 241 395 158 241 minecraft:bone_block
fill 391 158 255 395 158 255 minecraft:bone_block
fill 391 158 270 392 175 270 minecraft:green_terracotta
setblock 396 158 228 minecraft:mossy_cobblestone
fill 396 158 242 397 158 242 minecraft:bone_block
fill 396 158 254 397 158 254 minecraft:bone_block
fill 398 158 242 416 162 242 minecraft:brown_terracotta
setblock 398 158 243 minecraft:bone_block
setblock 398 158 253 minecraft:bone_block
fill 398 158 254 416 162 254 minecraft:brown_terracotta
fill 399 158 243 416 162 243 minecraft:brown_terracotta
fill 399 158 244 399 158 245 minecraft:bone_block
fill 399 158 251 399 158 252 minecraft:bone_block
fill 399 158 253 416 162 253 minecraft:brown_terracotta
fill 400 158 244 416 163 244 minecraft:brown_terracotta
fill 400 158 246 400 158 250 minecraft:bone_block
fill 400 158 252 416 163 252 minecraft:brown_terracotta
fill 407 158 270 407 161 270 minecraft:oak_leaves[persistent=true]
fill 409 158 270 409 161 270 minecraft:oak_leaves[persistent=true]
fill 413 158 228 413 219 228 minecraft:green_terracotta
fill 414 158 228 415 159 228 minecraft:jungle_log
fill 416 158 228 416 162 228 minecraft:green_terracotta
setblock 418 158 237 minecraft:green_terracotta
fill 418 158 238 418 161 239 minecraft:azalea_leaves[persistent=true]
fill 418 158 240 418 158 241 minecraft:green_terracotta
setblock 418 158 265 minecraft:green_terracotta
fill 376 159 228 376 160 228 minecraft:oak_leaves[persistent=true]
fill 376 159 229 376 183 229 minecraft:green_terracotta
fill 376 159 232 376 159 233 minecraft:jungle_log
fill 376 159 234 376 159 235 minecraft:jungle_leaves[persistent=true]
setblock 376 159 254 minecraft:jungle_leaves[persistent=true]
fill 376 159 256 376 218 256 minecraft:green_terracotta
fill 376 159 264 376 217 264 minecraft:green_terracotta
setblock 377 159 228 minecraft:jungle_log
fill 378 159 270 378 160 270 minecraft:azalea_leaves[persistent=true]
setblock 379 159 270 minecraft:mossy_cobblestone
fill 380 159 270 380 167 270 minecraft:green_terracotta
fill 386 159 246 386 161 250 minecraft:brown_concrete
fill 387 159 244 387 159 245 minecraft:brown_concrete
fill 387 159 251 387 159 252 minecraft:brown_concrete
fill 388 159 243 388 161 243 minecraft:brown_concrete
fill 388 159 253 388 161 253 minecraft:brown_concrete
fill 389 159 242 390 159 242 minecraft:brown_concrete
fill 389 159 254 390 159 254 minecraft:brown_concrete
setblock 390 159 270 minecraft:green_terracotta
fill 391 159 241 395 161 241 minecraft:brown_concrete
fill 391 159 255 395 161 255 minecraft:brown_concrete
setblock 393 159 245 minecraft:light[level=12]
setblock 393 159 252 minecraft:light[level=12]
fill 396 159 228 396 195 228 minecraft:green_terracotta
fill 396 159 242 397 159 242 minecraft:brown_concrete
fill 396 159 254 397 159 254 minecraft:brown_concrete
fill 398 159 243 398 161 243 minecraft:brown_concrete
fill 398 159 253 398 161 253 minecraft:brown_concrete
fill 399 159 244 399 159 245 minecraft:brown_concrete
fill 399 159 251 399 159 252 minecraft:brown_concrete
fill 400 159 246 400 161 250 minecraft:brown_concrete
fill 406 159 270 406 161 270 minecraft:oak_leaves[persistent=true]
fill 418 159 237 418 160 237 minecraft:azalea_leaves[persistent=true]
fill 418 159 240 418 160 240 minecraft:azalea_leaves[persistent=true]
fill 418 159 241 418 222 241 minecraft:green_terracotta
setblock 418 159 265 minecraft:moss_block
setblock 418 159 266 minecraft:mossy_cobblestone
fill 376 160 232 376 196 232 minecraft:green_terracotta
fill 376 160 233 376 160 234 minecraft:jungle_leaves[persistent=true]
fill 376 160 235 376 178 235 minecraft:green_terracotta
fill 376 160 254 376 183 254 minecraft:green_terracotta
fill 376 160 266 376 188 267 minecraft:green_terracotta
fill 377 160 228 378 163 228 minecraft:green_terracotta
fill 379 160 270 379 170 270 minecraft:green_terracotta
fill 386 160 230 386 163 244 minecraft:brown_terracotta
fill 386 160 245 386 161 245 minecraft:brown_concrete
fill 386 160 251 386 161 251 minecraft:brown_concrete
fill 386 160 252 386 163 268 minecraft:brown_terracotta
fill 387 160 244 387 161 244 minecraft:brown_concrete
fill 387 160 252 387 161 252 minecraft:brown_concrete
fill 389 160 242 389 161 242 minecraft:brown_concrete
fill 389 160 254 389 161 254 minecraft:brown_concrete
fill 390 160 230 390 165 240 minecraft:brown_terracotta
fill 390 160 241 390 161 241 minecraft:brown_concrete
fill 390 160 255 390 161 255 minecraft:brown_concrete
fill 390 160 256 390 165 268 minecraft:brown_terracotta
setblock 390 160 270 minecraft:mossy_cobblestone
fill 396 160 241 396 161 241 minecraft:brown_concrete
fill 396 160 255 396 161 255 minecraft:brown_concrete
fill 397 160 241 416 163 241 minecraft:brown_terracotta
fill 397 160 242 397 161 242 minecraft:brown_concrete
fill 397 160 254 397 161 254 minecraft:brown_concrete
fill 397 160 255 416 163 255 minecraft:brown_terracotta
fill 399 160 244 399 161 244 minecraft:brown_concrete
fill 399 160 252 399 161 252 minecraft:brown_concrete
fill 400 160 245 400 161 245 minecraft:brown_concrete
fill 400 160 251 400 161 251 minecraft:brown_concrete
fill 401 160 245 416 165 245 minecraft:brown_terracotta
fill 401 160 251 416 165 251 minecraft:brown_terracotta
setblock 410 160 270 minecraft:oak_leaves[persistent=true]
fill 414 160 228 415 183 228 minecraft:green_terracotta
fill 418 160 265 418 167 266 minecraft:green_terracotta
fill 376 161 228 376 183 228 minecraft:green_terracotta
fill 376 161 233 376 222 233 minecraft:green_terracotta
setblock 376 161 234 minecraft:jungle_leaves[persistent=true]
setblock 376 161 259 minecraft:green_concrete
fill 378 161 270 378 166 270 minecraft:green_terracotta
fill 390 161 270 390 219 270 minecraft:green_terracotta
fill 397 161 228 397 219 228 minecraft:green_terracotta
setblock 398 161 228 minecraft:green_concrete
fill 399 161 228 402 166 228 minecraft:green_terracotta
fill 410 161 270 410 185 270 minecraft:green_terracotta
fill 418 161 237 418 221 237 minecraft:green_terracotta
fill 418 161 240 418 216 240 minecraft:green_terracotta
fill 376 162 234 376 183 234 minecraft:green_terracotta
fill 376 162 259 376 166 259 minecraft:green_terracotta
fill 376 162 270 377 171 270 minecraft:green_terracotta
fill 378 162 230 384 168 268 minecraft:brown_terracotta
fill 385 162 230 385 162 247 minecraft:brown_terracotta
setblock 385 162 248 minecraft:bone_block
fill 385 162 249 385 162 268 minecraft:brown_terracotta
fill 386 162 245 386 162 247 minecraft:bone_block
fill 386 162 249 386 162 251 minecraft:bone_block
setblock 387 162 244 minecraft:bone_block
setblock 387 162 252 minecraft:bone_block
setblock 388 162 243 minecraft:bone_block
setblock 388 162 253 minecraft:bone_block
setblock 389 162 242 minecraft:bone_block
setblock 389 162 254 minecraft:bone_block
fill 390 162 241 392 162 241 minecraft:bone_block
fill 390 162 255 392 162 255 minecraft:bone_block
fill 393 162 230 416 168 239 minecraft:brown_terracotta
setblock 393 162 240 minecraft:bone_block
setblock 393 162 256 minecraft:bone_block
fill 393 162 257 416 168 268 minecraft:brown_terracotta
fill 394 162 240 416 162 240 minecraft:brown_terracotta
fill 394 162 241 396 162 241 minecraft:bone_block
fill 394 162 255 396 162 255 minecraft:bone_block
fill 394 162 256 416 162 256 minecraft:brown_terracotta
setblock 397 162 242 minecraft:bone_block
setblock 397 162 254 minecraft:bone_block
fill 398 162 228 398 222 228 minecraft:green_terracotta
setblock 398 162 243 minecraft:bone_block
setblock 398 162 253 minecraft:bone_block
setblock 399 162 244 minecraft:bone_block
setblock 399 162 252 minecraft:bone_block
fill 400 162 245 400 162 247 minecraft:bone_block
fill 400 162 249 400 162 251 minecraft:bone_block
setblock 401 162 248 minecraft:bone_block
fill 402 162 248 416 168 248 minecraft:brown_terracotta
setblock 404 162 270 minecraft:mossy_cobblestone
fill 406 162 270 409 187 270 minecraft:green_terracotta
fill 418 162 238 418 174 239 minecraft:green_terracotta
fill 385 163 230 385 163 246 minecraft:brown_terracotta
fill 385 163 247 385 165 249 minecraft:brown_concrete
fill 385 163 250 385 163 268 minecraft:brown_terracotta
fill 386 163 245 386 163 246 minecraft:brown_concrete
fill 386 163 250 386 163 251 minecraft:brown_concrete
fill 387 163 230 387 167 242 minecraft:brown_terracotta
fill 387 163 243 387 163 244 minecraft:brown_concrete
setblock 387 163 247 minecraft:light[level=15]
fill 387 163 252 387 163 253 minecraft:brown_concrete
fill 387 163 254 387 167 268 minecraft:brown_terracotta
fill 388 163 230 388 167 241 minecraft:brown_terracotta
fill 388 163 242 389 163 242 minecraft:brown_concrete
fill 388 163 254 389 163 254 minecraft:brown_concrete
fill 388 163 255 388 167 268 minecraft:brown_terracotta
fill 390 163 241 391 163 241 minecraft:brown_concrete
fill 390 163 255 391 163 255 minecraft:brown_concrete
fill 392 163 230 392 168 239 minecraft:brown_terracotta
fill 392 163 240 394 165 240 minecraft:brown_concrete
fill 392 163 256 394 165 256 minecraft:brown_concrete
fill 392 163 257 392 168 268 minecraft:brown_terracotta
fill 395 163 240 416 163 240 minecraft:brown_terracotta
fill 395 163 241 396 163 241 minecraft:brown_concrete
setblock 395 163 247 minecraft:light[level=15]
fill 395 163 255 396 163 255 minecraft:brown_concrete
fill 395 163 256 416 163 256 minecraft:brown_terracotta
fill 397 163 242 398 163 242 minecraft:brown_concrete
fill 397 163 254 398 163 254 minecraft:brown_concrete
fill 399 163 242 416 167 242 minecraft:brown_terracotta
fill 399 163 243 399 163 244 minecraft:brown_concrete
fill 399 163 252 399 163 253 minecraft:brown_concrete
fill 399 163 254 416 167 254 minecraft:brown_terracotta
fill 400 163 243 416 167 243 minecraft:brown_terracotta
fill 400 163 245 400 163 246 minecraft:brown_concrete
fill 400 163 250 400 163 251 minecraft:brown_concrete
fill 400 163 253 416 167 253 minecraft:brown_terracotta
fill 401 163 247 401 165 249 minecraft:brown_concrete
fill 402 163 247 416 168 247 minecraft:brown_terracotta
fill 402 163 249 416 168 249 minecraft:brown_terracotta
fill 404 163 270 404 196 270 minecraft:green_terracotta
setblock 416 163 228 minecraft:jungle_leaves[persistent=true]
setblock 417 163 228 minecraft:green_concrete
setblock 418 163 229 minecraft:jungle_leaves[persistent=true]
fill 377 164 228 377 183 228 minecraft:green_terracotta
setblock 378 164 228 minecraft:green_concrete
fill 385 164 230 385 165 245 minecraft:brown_terracotta
fill 385 164 246 385 165 246 minecraft:brown_concrete
fill 385 164 250 385 165 250 minecraft:brown_concrete
fill 385 164 251 385 165 268 minecraft:brown_terracotta
fill 386 164 230 386 167 243 minecraft:brown_terracotta
fill 386 164 244 386 165 245 minecraft:brown_concrete
fill 386 164 251 386 165 252 minecraft:brown_concrete
fill 386 164 253 386 167 268 minecraft:brown_terracotta
fill 387 164 243 387 165 243 minecraft:brown_concrete
fill 387 164 253 387 165 253 minecraft:brown_concrete
fill 388 164 242 388 165 242 minecraft:brown_concrete
fill 388 164 254 388 165 254 minecraft:brown_concrete
fill 389 164 230 389 168 240 minecraft:brown_terracotta
fill 389 164 241 390 165 241 minecraft:brown_concrete
fill 389 164 255 390 165 255 minecraft:brown_concrete
fill 389 164 256 389 168 268 minecraft:brown_terracotta
fill 391 164 230 391 170 239 minecraft:brown_terracotta
fill 391 164 240 391 165 240 minecraft:brown_concrete
fill 391 164 256 391 165 256 minecraft:brown_concrete
fill 391 164 257 391 170 268 minecraft:brown_terracotta
fill 395 164 240 395 165 240 minecraft:brown_concrete
fill 395 164 256 395 165 256 minecraft:brown_concrete
fill 396 164 240 416 165 240 minecraft:brown_terracotta
fill 396 164 241 397 165 241 minecraft:brown_concrete
fill 396 164 255 397 165 255 minecraft:brown_concrete
fill 396 164 256 416 165 256 minecraft:brown_terracotta
fill 398 164 241 416 167 241 minecraft:brown_terracotta
fill 398 164 242 398 165 242 minecraft:brown_concrete
fill 398 164 254 398 165 254 minecraft:brown_concrete
fill 398 164 255 416 167 255 minecraft:brown_terracotta
fill 399 164 243 399 165 243 minecraft:brown_concrete
fill 399 164 253 399 165 253 minecraft:brown_concrete
fill 400 164 244 400 165 245 minecraft:brown_concrete
fill 400 164 251 400 165 252 minecraft:brown_concrete
fill 401 164 244 416 168 244 minecraft:brown_terracotta
fill 401 164 246 401 165 246 minecraft:brown_concrete
fill 401 164 250 401 165 250 minecraft:brown_concrete
fill 401 164 252 416 168 252 minecraft:brown_terracotta
fill 402 164 246 416 170 246 minecraft:brown_terracotta
fill 402 164 250 416 170 250 minecraft:brown_terracotta
setblock 411 164 270 minecraft:moss_block
fill 416 164 228 417 185 228 minecraft:green_terracotta
fill 418 164 229 418 196 229 minecraft:green_terracotta
setblock 418 164 255 minecraft:jungle_leaves[persistent=true]
fill 418 164 256 418 178 257 minecraft:green_terracotta
setblock 378 165 228 minecraft:green_terracotta
setblock 393 165 245 minecraft:light[level=12]
setblock 393 165 252 minecraft:light[level=12]
fill 411 165 270 412 222 270 minecraft:green_terracotta
setblock 413 165 270 minecraft:green_concrete
fill 418 165 248 418 216 248 minecraft:green_terracotta
setblock 418 165 249 minecraft:jungle_leaves[persistent=true]
fill 418 165 255 418 174 255 minecraft:green_terracotta
setblock 378 166 228 minecraft:moss_block
fill 385 166 230 385 168 244 minecraft:brown_terracotta
fill 385 166 245 385 166 251 minecraft:bone_block
fill 385 166 252 385 168 268 minecraft:brown_terracotta
setblock 386 166 244 minecraft:bone_block
setblock 386 166 252 minecraft:bone_block
setblock 387 166 243 minecraft:bone_block
setblock 387 166 253 minecraft:bone_block
setblock 388 166 242 minecraft:bone_block
setblock 388 166 254 minecraft:bone_block
setblock 389 166 241 minecraft:bone_block
setblock 389 166 255 minecraft:bone_block
fill 390 166 230 390 172 239 minecraft:brown_terracotta
fill 390 166 240 396 166 240 minecraft:bone_block
fill 390 166 256 396 166 256 minecraft:bone_block
fill 390 166 257 390 172 268 minecraft:brown_terracotta
fill 394 166 241 396 169 241 minecraft:dirt
fill 397 166 240 416 168 240 minecraft:brown_terracotta
setblock 397 166 241 minecraft:bone_block
setblock 397 166 255 minecraft:bone_block
fill 397 166 256 416 168 256 minecraft:brown_terracotta
setblock 398 166 242 minecraft:bone_block
setblock 398 166 254 minecraft:bone_block
setblock 399 166 243 minecraft:bone_block
setblock 399 166 253 minecraft:bone_block
setblock 400 166 244 minecraft:bone_block
setblock 400 166 252 minecraft:bone_block
fill 401 166 245 401 166 251 minecraft:bone_block
fill 402 166 245 416 172 245 minecraft:brown_terracotta
fill 402 166 251 416 172 251 minecraft:brown_terracotta
fill 413 166 270 413 202 270 minecraft:green_terracotta
fill 418 166 249 418 218 249 minecraft:green_terracotta
setblock 376 167 259 minecraft:moss_block
fill 378 167 228 378 175 228 minecraft:green_terracotta
setblock 378 167 270 minecraft:mossy_cobblestone
fill 385 167 245 385 168 251 minecraft:brown_concrete
fill 386 167 244 386 168 244 minecraft:brown_concrete
fill 386 167 252 386 168 252 minecraft:brown_concrete
setblock 387 167 243 minecraft:brown_concrete
setblock 387 167 253 minecraft:brown_concrete
setblock 388 167 242 minecraft:brown_concrete
setblock 388 167 254 minecraft:brown_concrete
fill 389 167 241 389 168 241 minecraft:brown_concrete
fill 389 167 255 389 168 255 minecraft:brown_concrete
fill 390 167 240 396 168 240 minecraft:brown_concrete
fill 390 167 256 396 168 256 minecraft:brown_concrete
fill 393 167 241 393 169 241 minecraft:dirt
fill 397 167 241 397 168 241 minecraft:brown_concrete
fill 397 167 255 397 168 255 minecraft:brown_concrete
setblock 398 167 242 minecraft:brown_concrete
setblock 398 167 254 minecraft:brown_concrete
fill 399 167 228 401 175 228 minecraft:green_terracotta
setblock 399 167 243 minecraft:brown_concrete
setblock 399 167 253 minecraft:brown_concrete
fill 400 167 244 400 168 244 minecraft:brown_concrete
fill 400 167 252 400 168 252 minecraft:brown_concrete
fill 401 167 245 401 168 251 minecraft:brown_concrete
setblock 402 167 228 minecraft:mossy_cobblestone
setblock 409 167 228 minecraft:moss_block
fill 376 168 259 376 170 259 minecraft:green_terracotta
fill 378 168 270 378 170 270 minecraft:green_terracotta
setblock 380 168 270 minecraft:mossy_cobblestone
fill 386 168 230 386 171 242 minecraft:brown_terracotta
fill 386 168 243 386 169 243 minecraft:brown_concrete
fill 386 168 253 386 169 253 minecraft:brown_concrete
fill 386 168 254 386 171 268 minecraft:brown_terracotta
fill 387 168 230 387 171 241 minecraft:brown_terracotta
fill 387 168 242 387 169 242 minecraft:brown_concrete
fill 387 168 254 387 169 254 minecraft:brown_concrete
fill 387 168 255 387 171 268 minecraft:brown_terracotta
fill 388 168 230 388 172 240 minecraft:brown_terracotta
fill 388 168 241 388 169 241 minecraft:brown_concrete
fill 388 168 255 388 169 255 minecraft:brown_concrete
fill 388 168 256 388 172 268 minecraft:brown_terracotta
fill 394 168 242 397 169 242 minecraft:dirt
fill 398 168 241 398 169 241 minecraft:brown_concrete
fill 398 168 255 398 169 255 minecraft:brown_concrete
fill 399 168 241 416 171 241 minecraft:brown_terracotta
fill 399 168 242 399 169 242 minecraft:brown_concrete
fill 399 168 254 399 169 254 minecraft:brown_concrete
fill 399 168 255 416 171 255 minecraft:brown_terracotta
fill 400 168 242 416 171 242 minecraft:brown_terracotta
fill 400 168 243 400 169 243 minecraft:brown_concrete
fill 400 168 253 400 169 253 minecraft:brown_concrete
fill 400 168 254 416 171 254 minecraft:brown_terracotta
fill 401 168 243 416 172 243 minecraft:brown_terracotta
fill 401 168 253 416 172 253 minecraft:brown_terracotta
fill 402 168 228 402 222 228 minecraft:green_terracotta
fill 409 168 228 409 170 228 minecraft:green_terracotta
setblock 418 168 265 minecraft:jungle_leaves[persistent=true]
fill 418 168 266 418 210 266 minecraft:green_terracotta
setblock 376 169 238 minecraft:moss_block
fill 378 169 230 383 175 268 minecraft:brown_terracotta
fill 380 169 270 380 170 270 minecraft:green_terracotta
fill 384 169 230 384 170 246 minecraft:brown_terracotta
fill 384 169 247 384 169 249 minecraft:brown_concrete
fill 384 169 250 384 170 268 minecraft:brown_terracotta
fill 385 169 230 385 172 243 minecraft:brown_terracotta
fill 385 169 244 385 169 246 minecraft:brown_concrete
fill 385 169 250 385 169 252 minecraft:brown_concrete
fill 385 169 253 385 172 268 minecraft:brown_terracotta
fill 389 169 230 389 175 239 minecraft:brown_terracotta
fill 389 169 240 391 169 240 minecraft:brown_concrete
fill 389 169 256 391 169 256 minecraft:brown_concrete
fill 389 169 257 389 175 268 minecraft:brown_terracotta
fill 392 169 230 416 175 238 minecraft:brown_terracotta
fill 392 169 239 394 169 239 minecraft:brown_concrete
fill 392 169 240 392 169 241 minecraft:dirt
fill 392 169 257 394 169 257 minecraft:brown_concrete
fill 392 169 258 416 175 268 minecraft:brown_terracotta
fill 393 169 240 394 169 240 minecraft:dirt
setblock 393 169 242 minecraft:dirt
fill 395 169 239 416 170 239 minecraft:brown_terracotta
fill 395 169 240 397 169 240 minecraft:brown_concrete
fill 395 169 256 397 169 256 minecraft:brown_concrete
fill 395 169 257 416 170 257 minecraft:brown_terracotta
setblock 397 169 241 minecraft:dirt
fill 398 169 240 416 172 240 minecraft:brown_terracotta
setblock 398 169 242 minecraft:dirt
fill 398 169 256 416 172 256 minecraft:brown_terracotta
fill 401 169 244 401 169 246 minecraft:brown_concrete
fill 401 169 250 401 169 252 minecraft:brown_concrete
fill 402 169 244 416 175 244 minecraft:brown_terracotta
fill 402 169 247 402 169 249 minecraft:brown_concrete
fill 402 169 252 416 175 252 minecraft:brown_terracotta
fill 403 169 247 416 175 249 minecraft:brown_terracotta
fill 418 169 265 418 203 265 minecraft:green_terracotta
fill 376 170 238 376 178 238 minecraft:green_terracotta
fill 376 170 260 376 174 261 minecraft:oak_leaves[persistent=true]
fill 384 170 247 384 170 249 minecraft:bone_block
fill 385 170 244 385 170 246 minecraft:bone_block
fill 385 170 250 385 170 252 minecraft:bone_block
setblock 386 170 243 minecraft:bone_block
setblock 386 170 253 minecraft:bone_block
setblock 387 170 242 minecraft:bone_block
setblock 387 170 247 minecraft:light[level=15]
setblock 387 170 254 minecraft:bone_block
setblock 388 170 241 minecraft:bone_block
setblock 388 170 255 minecraft:bone_block
fill 389 170 240 391 170 240 minecraft:bone_block
fill 389 170 256 391 170 256 minecraft:bone_block
fill 392 170 228 392 218 228 minecraft:green_terracotta
fill 392 170 239 394 170 239 minecraft:bone_block
fill 392 170 257 394 170 257 minecraft:bone_block
setblock 393 170 228 minecraft:mossy_cobblestone
fill 394 170 228 395 218 228 minecraft:green_terracotta
fill 395 170 240 397 170 240 minecraft:bone_block
setblock 395 170 247 minecraft:light[level=15]
setblock 395 170 255 minecraft:light[level=15]
fill 395 170 256 397 170 256 minecraft:bone_block
setblock 398 170 241 minecraft:bone_block
setblock 398 170 255 minecraft:bone_block
setblock 399 170 242 minecraft:bone_block
setblock 399 170 254 minecraft:bone_block
setblock 400 170 243 minecraft:bone_block
setblock 400 170 253 minecraft:bone_block
fill 401 170 244 401 170 246 minecraft:bone_block
fill 401 170 250 401 170 252 minecraft:bone_block
fill 401 170 270 402 181 270 minecraft:green_terracotta
fill 402 170 247 402 170 249 minecraft:bone_block
setblock 403 170 228 minecraft:green_terracotta
setblock 403 170 270 minecraft:jungle_leaves[persistent=true]
setblock 404 170 228 minecraft:mossy_cobblestone
fill 405 170 228 405 198 228 minecraft:green_terracotta
fill 414 170 270 414 183 270 minecraft:green_terracotta
setblock 415 170 270 minecraft:moss_block
setblock 418 170 260 minecraft:green_terracotta
fill 418 170 261 418 175 261 minecraft:oak_leaves[persistent=true]
fill 418 170 262 418 170 263 minecraft:green_terracotta
fill 376 171 259 376 175 259 minecraft:oak_leaves[persistent=true]
fill 376 171 262 376 174 262 minecraft:oak_leaves[persistent=true]
fill 378 171 270 379 172 270 minecraft:jungle_log
setblock 379 171 228 minecraft:mossy_cobblestone
setblock 380 171 270 minecraft:mossy_cobblestone
fill 381 171 228 382 171 228 minecraft:jungle_log
setblock 382 171 270 minecraft:green_concrete
fill 383 171 228 383 183 228 minecraft:green_terracotta
fill 384 171 230 384 172 245 minecraft:brown_terracotta
fill 384 171 246 384 173 250 minecraft:brown_concrete
fill 384 171 251 384 172 268 minecraft:brown_terracotta
fill 385 171 244 385 172 245 minecraft:brown_concrete
fill 385 171 251 385 172 252 minecraft:brown_concrete
fill 386 171 243 386 172 243 minecraft:brown_concrete
setblock 386 171 245 minecraft:light[level=12]
setblock 386 171 252 minecraft:light[level=12]
fill 386 171 253 386 172 253 minecraft:brown_concrete
setblock 387 171 228 minecraft:jungle_leaves[persistent=true]
setblock 387 171 242 minecraft:brown_concrete
setblock 387 171 254 minecraft:brown_concrete
fill 388 171 228 389 176 228 minecraft:green_terracotta
fill 388 171 241 388 172 241 minecraft:brown_concrete
fill 388 171 255 388 172 255 minecraft:brown_concrete
fill 389 171 240 390 172 240 minecraft:brown_concrete
fill 389 171 256 390 172 256 minecraft:brown_concrete
fill 391 171 230 391 177 238 minecraft:brown_terracotta
fill 391 171 239 395 173 239 minecraft:brown_concrete
fill 391 171 257 395 173 257 minecraft:brown_concrete
fill 391 171 258 391 177 268 minecraft:brown_terracotta
fill 393 171 228 393 182 228 minecraft:green_terracotta
setblock 393 171 245 minecraft:light[level=12]
setblock 393 171 252 minecraft:light[level=12]
fill 396 171 239 416 172 239 minecraft:brown_terracotta
fill 396 171 240 397 172 240 minecraft:brown_concrete
fill 396 171 256 397 172 256 minecraft:brown_concrete
fill 396 171 257 416 172 257 minecraft:brown_terracotta
fill 398 171 241 398 172 241 minecraft:brown_concrete
fill 398 171 255 398 172 255 minecraft:brown_concrete
setblock 399 171 242 minecraft:brown_concrete
setblock 399 171 254 minecraft:brown_concrete
fill 400 171 243 400 172 243 minecraft:brown_concrete
setblock 400 171 245 minecraft:light[level=12]
setblock 400 171 252 minecraft:light[level=12]
fill 400 171 253 400 172 253 minecraft:brown_concrete
fill 401 171 244 401 172 245 minecraft:brown_concrete
fill 401 171 251 401 172 252 minecraft:brown_concrete
fill 402 171 246 402 173 250 minecraft:brown_concrete
setblock 403 171 228 minecraft:jungle_leaves[persistent=true]
fill 403 171 246 416 177 246 minecraft:brown_terracotta
fill 403 171 250 416 177 250 minecraft:brown_terracotta
fill 403 171 270 403 223 270 minecraft:green_terracotta
fill 404 171 228 404 197 228 minecraft:green_terracotta
fill 406 171 228 410 173 228 minecraft:jungle_leaves[persistent=true]
fill 415 171 270 415 183 270 minecraft:green_terracotta
fill 418 171 231 418 196 231 minecraft:green_terracotta
fill 418 171 232 418 172 233 minecraft:jungle_log
fill 418 171 258 418 174 260 minecraft:oak_leaves[persistent=true]
fill 418 171 262 418 174 262 minecraft:oak_leaves[persistent=true]
fill 418 171 263 418 176 263 minecraft:green_terracotta
fill 418 171 267 418 171 268 minecraft:jungle_log
fill 418 171 269 418 172 270 minecraft:jungle_leaves[persistent=true]
fill 376 172 258 376 174 258 minecraft:oak_leaves[persistent=true]
fill 376 172 263 376 173 263 minecraft:oak_leaves[persistent=true]
fill 376 172 270 376 183 270 minecraft:green_terracotta
setblock 377 172 270 minecraft:oak_leaves[persistent=true]
fill 379 172 228 379 178 228 minecraft:green_terracotta
fill 380 172 270 380 187 270 minecraft:green_terracotta
setblock 381 172 228 minecraft:jungle_log
setblock 382 172 228 minecraft:jungle_leaves[persistent=true]
fill 382 172 270 382 216 270 minecraft:green_terracotta
fill 386 172 230 386 177 241 minecraft:brown_terracotta
fill 386 172 242 386 173 242 minecraft:brown_concrete
fill 386 172 254 386 173 254 minecraft:brown_concrete
fill 386 172 255 386 177 268 minecraft:brown_terracotta
fill 387 172 228 387 223 228 minecraft:green_terracotta
fill 387 172 230 387 177 240 minecraft:brown_terracotta
fill 387 172 241 387 173 241 minecraft:brown_concrete
fill 387 172 255 387 173 255 minecraft:brown_concrete
fill 387 172 256 387 177 268 minecraft:brown_terracotta
fill 399 172 241 399 173 241 minecraft:brown_concrete
fill 399 172 255 399 173 255 minecraft:brown_concrete
fill 400 172 241 416 177 241 minecraft:brown_terracotta
fill 400 172 242 400 173 242 minecraft:brown_concrete
fill 400 172 254 400 173 254 minecraft:brown_concrete
fill 400 172 255 416 177 255 minecraft:brown_terracotta
fill 401 172 242 416 177 242 minecraft:brown_terracotta
fill 401 172 254 416 177 254 minecraft:brown_terracotta
fill 403 172 228 403 173 228 minecraft:green_terracotta
setblock 418 172 267 minecraft:jungle_log
fill 418 172 268 418 173 268 minecraft:jungle_leaves[persistent=true]
setblock 376 173 236 minecraft:green_concrete
fill 377 173 270 377 183 270 minecraft:green_terracotta
setblock 378 173 270 minecraft:oak_leaves[persistent=true]
fill 379 173 270 379 196 270 minecraft:green_terracotta
fill 381 173 228 382 185 228 minecraft:green_terracotta
fill 384 173 230 384 175 244 minecraft:brown_terracotta
setblock 384 173 245 minecraft:brown_concrete
setblock 384 173 251 minecraft:brown_concrete
fill 384 173 252 384 175 268 minecraft:brown_terracotta
fill 385 173 230 385 177 242 minecraft:brown_terracotta
fill 385 173 243 385 173 244 minecraft:brown_concrete
fill 385 173 252 385 173 253 minecraft:brown_concrete
fill 385 173 254 385 177 268 minecraft:brown_terracotta
fill 388 173 230 388 178 239 minecraft:brown_terracotta
fill 388 173 240 389 173 240 minecraft:brown_concrete
fill 388 173 256 389 173 256 minecraft:brown_concrete
fill 388 173 257 388 178 268 minecraft:brown_terracotta
fill 390 173 230 390 178 238 minecraft:brown_terracotta
setblock 390 173 239 minecraft:brown_concrete
setblock 390 173 257 minecraft:brown_concrete
fill 390 173 258 390 178 268 minecraft:brown_terracotta
setblock 391 173 228 minecraft:mossy_cobblestone
fill 395 173 240 396 175 240 minecraft:jungle_leaves[persistent=true]
setblock 396 173 239 minecraft:brown_concrete
setblock 396 173 257 minecraft:brown_concrete
fill 397 173 239 416 175 239 minecraft:brown_terracotta
fill 397 173 240 398 173 240 minecraft:brown_concrete
fill 397 173 256 398 173 256 minecraft:brown_concrete
fill 397 173 257 416 175 257 minecraft:brown_terracotta
fill 399 173 240 416 177 240 minecraft:brown_terracotta
fill 399 173 256 416 177 256 minecraft:brown_terracotta
fill 401 173 243 401 173 244 minecraft:brown_concrete
fill 401 173 252 401 173 253 minecraft:brown_concrete
fill 402 173 243 416 178 243 minecraft:brown_terracotta
setblock 402 173 245 minecraft:brown_concrete
setblock 402 173 251 minecraft:brown_concrete
fill 402 173 253 416 178 253 minecraft:brown_terracotta
fill 403 173 245 416 178 245 minecraft:brown_terracotta
fill 403 173 251 416 178 251 minecraft:brown_terracotta
fill 418 173 232 418 218 233 minecraft:green_terracotta
fill 418 173 267 418 222 267 minecraft:green_terracotta
fill 418 173 269 418 207 270 minecraft:green_terracotta
fill 376 174 236 376 183 236 minecraft:green_terracotta
setblock 376 174 263 minecraft:green_concrete
fill 378 174 270 378 184 270 minecraft:green_terracotta
fill 384 174 245 384 174 251 minecraft:bone_block
fill 385 174 243 385 174 244 minecraft:bone_block
fill 385 174 252 385 174 253 minecraft:bone_block
setblock 386 174 242 minecraft:bone_block
setblock 386 174 254 minecraft:bone_block
setblock 387 174 241 minecraft:bone_block
setblock 387 174 255 minecraft:bone_block
fill 388 174 240 389 174 240 minecraft:bone_block
fill 388 174 256 389 174 256 minecraft:bone_block
fill 390 174 239 396 174 239 minecraft:bone_block
fill 390 174 257 396 174 257 minecraft:bone_block
fill 391 174 228 391 220 228 minecraft:green_terracotta
setblock 394 174 240 minecraft:jungle_leaves[persistent=true]
fill 397 174 240 398 174 240 minecraft:bone_block
fill 397 174 256 398 174 256 minecraft:bone_block
setblock 399 174 241 minecraft:bone_block
setblock 399 174 255 minecraft:bone_block
setblock 400 174 242 minecraft:bone_block
setblock 400 174 254 minecraft:bone_block
fill 401 174 243 401 174 244 minecraft:bone_block
fill 401 174 252 401 174 253 minecraft:bone_block
fill 402 174 245 402 174 251 minecraft:bone_block
setblock 403 174 228 minecraft:mossy_cobblestone
fill 406 174 228 406 184 228 minecraft:green_terracotta
fill 407 174 228 410 174 228 minecraft:jungle_leaves[persistent=true]
fill 418 174 268 418 208 268 minecraft:green_terracotta
setblock 376 175 257 minecraft:mossy_cobblestone
fill 376 175 258 376 220 258 minecraft:green_terracotta
fill 376 175 260 376 184 263 minecraft:green_terracotta
fill 384 175 245 384 175 251 minecraft:brown_concrete
fill 385 175 243 385 175 244 minecraft:brown_concrete
fill 385 175 252 385 175 253 minecraft:brown_concrete
fill 386 175 242 386 177 242 minecraft:brown_concrete
fill 386 175 254 386 177 254 minecraft:brown_concrete
fill 387 175 241 387 177 241 minecraft:brown_concrete
fill 387 175 255 387 177 255 minecraft:brown_concrete
fill 388 175 240 389 175 240 minecraft:brown_concrete
fill 388 175 256 389 175 256 minecraft:brown_concrete
fill 390 175 239 396 175 239 minecraft:brown_concrete
fill 390 175 257 396 175 257 minecraft:brown_concrete
fill 397 175 240 398 175 240 minecraft:brown_concrete
fill 397 175 256 398 175 256 minecraft:brown_concrete
fill 399 175 241 399 177 241 minecraft:brown_concrete
fill 399 175 255 399 177 255 minecraft:brown_concrete
fill 400 175 242 400 177 242 minecraft:brown_concrete
fill 400 175 254 400 177 254 minecraft:brown_concrete
fill 401 175 243 401 175 244 minecraft:brown_concrete
fill 401 175 252 401 175 253 minecraft:brown_concrete
fill 402 175 245 402 175 251 minecraft:brown_concrete
fill 403 175 228 403 216 228 minecraft:green_terracotta
fill 407 175 228 409 175 228 minecraft:jungle_leaves[persistent=true]
fill 410 175 228 410 183 228 minecraft:green_terracotta
fill 418 175 238 418 205 238 minecraft:green_terracotta
setblock 418 175 239 minecraft:mossy_cobblestone
setblock 418 175 255 minecraft:moss_block
fill 418 175 258 418 222 259 minecraft:green_terracotta
setblock 418 175 260 minecraft:oak_leaves[persistent=true]
fill 418 175 262 418 176 262 minecraft:green_terracotta
fill 376 176 257 376 222 257 minecraft:green_terracotta
fill 376 176 259 376 210 259 minecraft:green_terracotta
setblock 378 176 228 minecraft:mossy_cobblestone
fill 378 176 230 382 182 268 minecraft:brown_terracotta
fill 383 176 230 383 177 246 minecraft:brown_terracotta
fill 383 176 247 383 177 249 minecraft:brown_concrete
fill 383 176 250 383 177 268 minecraft:brown_terracotta
fill 384 176 230 384 178 243 minecraft:brown_terracotta
fill 384 176 244 384 177 246 minecraft:brown_concrete
fill 384 176 250 384 177 252 minecraft:brown_concrete
fill 384 176 253 384 178 268 minecraft:brown_terracotta
fill 385 176 243 385 177 243 minecraft:brown_concrete
fill 385 176 253 385 177 253 minecraft:brown_concrete
fill 388 176 240 388 177 240 minecraft:brown_concrete
fill 388 176 256 388 177 256 minecraft:brown_concrete
setblock 388 176 270 minecraft:mossy_cobblestone
fill 389 176 230 389 181 238 minecraft:brown_terracotta
fill 389 176 239 391 177 239 minecraft:brown_concrete
fill 389 176 257 391 177 257 minecraft:brown_concrete
fill 389 176 258 389 181 268 minecraft:brown_terracotta
setblock 391 176 270 minecraft:jungle_leaves[persistent=true]
fill 392 176 230 416 182 237 minecraft:brown_terracotta
fill 392 176 238 394 177 238 minecraft:brown_concrete
fill 392 176 258 394 177 258 minecraft:brown_concrete
fill 392 176 259 416 182 268 minecraft:brown_terracotta
fill 392 176 270 392 209 270 minecraft:green_terracotta
fill 395 176 238 416 177 238 minecraft:brown_terracotta
fill 395 176 239 397 177 239 minecraft:brown_concrete
fill 395 176 257 397 177 257 minecraft:brown_concrete
fill 395 176 258 416 177 258 minecraft:brown_terracotta
fill 398 176 239 416 178 239 minecraft:brown_terracotta
fill 398 176 240 398 177 240 minecraft:brown_concrete
fill 398 176 256 398 177 256 minecraft:brown_concrete
fill 398 176 257 416 178 257 minecraft:brown_terracotta
fill 399 176 228 400 214 228 minecraft:green_terracotta
setblock 401 176 228 minecraft:mossy_cobblestone
fill 401 176 243 401 177 243 minecraft:brown_concrete
fill 401 176 253 401 177 253 minecraft:brown_concrete
fill 402 176 244 402 177 246 minecraft:brown_concrete
fill 402 176 250 402 177 252 minecraft:brown_concrete
fill 403 176 244 416 181 244 minecraft:brown_terracotta
fill 403 176 247 403 177 249 minecraft:brown_concrete
fill 403 176 252 416 181 252 minecraft:brown_terracotta
fill 404 176 247 416 182 249 minecraft:brown_terracotta
fill 407 176 228 409 182 228 minecraft:green_terracotta
fill 418 176 239 418 222 239 minecraft:green_terracotta
fill 418 176 255 418 222 255 minecraft:green_terracotta
fill 418 176 260 418 209 261 minecraft:green_terracotta
fill 376 177 249 376 186 249 minecraft:green_terracotta
schedule function dropper:buildpart/56_2 1t
