setblock 510 175 472 minecraft:terracotta
fill 510 175 473 510 175 476 minecraft:red_terracotta
setblock 510 175 477 minecraft:terracotta
fill 510 175 478 510 178 478 minecraft:red_terracotta
setblock 510 175 481 minecraft:red_terracotta
setblock 510 175 482 minecraft:terracotta
fill 510 175 483 510 178 483 minecraft:red_terracotta
setblock 510 175 486 minecraft:red_terracotta
setblock 510 175 502 minecraft:terracotta
fill 510 175 503 510 178 503 minecraft:red_terracotta
setblock 511 175 465 minecraft:red_terracotta
setblock 511 175 466 minecraft:terracotta
fill 511 175 467 511 175 470 minecraft:red_terracotta
setblock 511 175 471 minecraft:terracotta
fill 511 175 472 511 175 475 minecraft:red_terracotta
setblock 511 175 476 minecraft:terracotta
fill 511 175 477 511 178 477 minecraft:red_terracotta
setblock 511 175 481 minecraft:terracotta
fill 511 175 482 511 178 482 minecraft:red_terracotta
setblock 511 175 486 minecraft:terracotta
fill 511 175 487 511 178 487 minecraft:red_terracotta
setblock 511 175 497 minecraft:red_terracotta
setblock 511 175 501 minecraft:terracotta
fill 511 175 502 511 178 502 minecraft:red_terracotta
setblock 471 176 464 minecraft:red_terracotta
setblock 471 176 465 minecraft:terracotta
fill 471 176 466 471 176 469 minecraft:red_terracotta
setblock 471 176 470 minecraft:terracotta
fill 471 176 471 471 179 471 minecraft:red_terracotta
fill 471 176 473 471 177 473 minecraft:red_terracotta
setblock 471 176 475 minecraft:terracotta
fill 471 176 476 471 176 479 minecraft:red_terracotta
setblock 471 176 480 minecraft:terracotta
fill 471 176 481 471 176 484 minecraft:red_terracotta
setblock 471 176 485 minecraft:terracotta
fill 471 176 486 471 178 487 minecraft:red_terracotta
fill 471 176 497 471 176 499 minecraft:red_terracotta
setblock 471 176 500 minecraft:terracotta
fill 471 176 501 471 179 501 minecraft:red_terracotta
setblock 472 176 464 minecraft:terracotta
fill 472 176 465 472 179 465 minecraft:red_terracotta
setblock 472 176 469 minecraft:terracotta
fill 472 176 475 472 176 478 minecraft:red_terracotta
setblock 472 176 479 minecraft:terracotta
fill 472 176 480 472 179 480 minecraft:red_terracotta
setblock 472 176 499 minecraft:terracotta
fill 472 176 500 472 179 500 minecraft:red_terracotta
setblock 472 176 503 minecraft:red_terracotta
setblock 472 176 504 minecraft:terracotta
fill 473 176 464 473 179 464 minecraft:red_terracotta
setblock 473 176 502 minecraft:red_terracotta
setblock 473 176 503 minecraft:terracotta
fill 473 176 504 476 176 504 minecraft:red_terracotta
setblock 474 176 502 minecraft:terracotta
fill 474 176 503 477 176 503 minecraft:red_terracotta
setblock 477 176 464 minecraft:terracotta
setblock 477 176 504 minecraft:terracotta
fill 478 176 464 478 179 464 minecraft:red_terracotta
setblock 478 176 503 minecraft:terracotta
fill 478 176 504 481 176 504 minecraft:red_terracotta
fill 479 176 503 482 176 503 minecraft:red_terracotta
fill 480 176 464 480 177 464 minecraft:red_terracotta
setblock 482 176 504 minecraft:terracotta
setblock 483 176 503 minecraft:terracotta
fill 483 176 504 486 176 504 minecraft:red_terracotta
fill 484 176 464 486 176 464 minecraft:red_terracotta
fill 484 176 503 487 176 503 minecraft:red_terracotta
fill 485 176 502 488 176 502 minecraft:red_terracotta
setblock 487 176 464 minecraft:terracotta
setblock 487 176 504 minecraft:terracotta
fill 488 176 464 488 179 464 minecraft:red_terracotta
setblock 488 176 503 minecraft:terracotta
fill 488 176 504 491 176 504 minecraft:red_terracotta
setblock 489 176 502 minecraft:terracotta
fill 489 176 503 492 176 503 minecraft:red_terracotta
fill 490 176 502 490 179 502 minecraft:red_terracotta
setblock 491 176 464 minecraft:red_terracotta
setblock 492 176 464 minecraft:terracotta
setblock 492 176 504 minecraft:terracotta
fill 493 176 464 493 179 464 minecraft:red_terracotta
setblock 493 176 502 minecraft:red_terracotta
setblock 493 176 503 minecraft:terracotta
fill 493 176 504 493 179 504 minecraft:red_terracotta
fill 494 176 503 494 179 503 minecraft:red_terracotta
setblock 497 176 504 minecraft:terracotta
setblock 506 176 464 minecraft:red_terracotta
setblock 506 176 504 minecraft:red_terracotta
setblock 507 176 464 minecraft:terracotta
setblock 507 176 504 minecraft:terracotta
fill 508 176 464 508 179 464 minecraft:red_terracotta
fill 508 176 504 508 179 504 minecraft:red_terracotta
fill 509 176 465 510 176 465 minecraft:red_terracotta
setblock 509 176 476 minecraft:red_terracotta
setblock 509 176 477 minecraft:terracotta
fill 509 176 478 509 179 478 minecraft:red_terracotta
setblock 509 176 482 minecraft:terracotta
fill 509 176 483 509 179 483 minecraft:red_terracotta
fill 509 176 503 509 179 503 minecraft:red_terracotta
setblock 510 176 466 minecraft:terracotta
fill 510 176 467 511 178 467 minecraft:red_terracotta
setblock 510 176 471 minecraft:terracotta
fill 510 176 472 510 176 475 minecraft:red_terracotta
setblock 510 176 476 minecraft:terracotta
fill 510 176 477 510 179 477 minecraft:red_terracotta
setblock 510 176 481 minecraft:terracotta
fill 510 176 482 510 179 482 minecraft:red_terracotta
setblock 510 176 485 minecraft:red_terracotta
setblock 510 176 486 minecraft:terracotta
fill 510 176 487 510 179 487 minecraft:red_terracotta
setblock 510 176 501 minecraft:terracotta
fill 510 176 502 510 179 502 minecraft:red_terracotta
setblock 511 176 465 minecraft:terracotta
fill 511 176 466 511 179 466 minecraft:red_terracotta
fill 511 176 468 511 176 469 minecraft:red_terracotta
setblock 511 176 470 minecraft:terracotta
fill 511 176 471 511 176 474 minecraft:red_terracotta
setblock 511 176 475 minecraft:terracotta
fill 511 176 476 511 179 476 minecraft:red_terracotta
setblock 511 176 480 minecraft:terracotta
fill 511 176 481 511 179 481 minecraft:red_terracotta
setblock 511 176 485 minecraft:terracotta
fill 511 176 486 511 179 486 minecraft:red_terracotta
setblock 511 176 489 minecraft:red_terracotta
setblock 511 176 500 minecraft:terracotta
fill 511 176 501 511 179 501 minecraft:red_terracotta
setblock 471 177 464 minecraft:terracotta
fill 471 177 465 471 177 468 minecraft:red_terracotta
setblock 471 177 469 minecraft:terracotta
fill 471 177 470 471 180 470 minecraft:red_terracotta
setblock 471 177 474 minecraft:terracotta
fill 471 177 475 471 177 478 minecraft:red_terracotta
setblock 471 177 479 minecraft:terracotta
fill 471 177 480 471 177 483 minecraft:red_terracotta
setblock 471 177 484 minecraft:terracotta
fill 471 177 485 471 180 485 minecraft:red_terracotta
setblock 471 177 488 minecraft:red_terracotta
fill 471 177 497 471 177 498 minecraft:red_terracotta
setblock 471 177 499 minecraft:terracotta
fill 471 177 500 471 180 500 minecraft:red_terracotta
fill 471 177 502 471 177 503 minecraft:red_terracotta
setblock 471 177 504 minecraft:terracotta
fill 472 177 464 472 180 464 minecraft:red_terracotta
setblock 472 177 468 minecraft:terracotta
fill 472 177 469 472 180 469 minecraft:red_terracotta
fill 472 177 476 472 177 477 minecraft:red_terracotta
setblock 472 177 478 minecraft:terracotta
fill 472 177 479 472 179 479 minecraft:red_terracotta
setblock 472 177 482 minecraft:red_terracotta
setblock 472 177 483 minecraft:terracotta
fill 472 177 484 472 180 484 minecraft:red_terracotta
fill 472 177 499 472 180 499 minecraft:red_terracotta
setblock 472 177 503 minecraft:terracotta
fill 472 177 504 475 177 504 minecraft:red_terracotta
setblock 473 177 502 minecraft:terracotta
fill 473 177 503 476 177 503 minecraft:red_terracotta
fill 474 177 502 474 179 502 minecraft:red_terracotta
setblock 475 177 465 minecraft:terracotta
setblock 476 177 464 minecraft:terracotta
fill 476 177 465 476 180 465 minecraft:red_terracotta
setblock 476 177 504 minecraft:terracotta
fill 477 177 464 477 180 464 minecraft:red_terracotta
setblock 477 177 503 minecraft:terracotta
fill 477 177 504 480 177 504 minecraft:red_terracotta
fill 478 177 503 481 177 503 minecraft:red_terracotta
setblock 481 177 464 minecraft:terracotta
setblock 481 177 504 minecraft:terracotta
fill 482 177 464 485 177 464 minecraft:red_terracotta
setblock 482 177 503 minecraft:terracotta
fill 482 177 504 485 177 504 minecraft:red_terracotta
fill 483 177 503 486 177 503 minecraft:red_terracotta
fill 485 177 502 487 177 502 minecraft:red_terracotta
setblock 486 177 464 minecraft:terracotta
setblock 486 177 504 minecraft:terracotta
fill 487 177 464 487 180 464 minecraft:red_terracotta
setblock 487 177 503 minecraft:terracotta
fill 487 177 504 490 177 504 minecraft:red_terracotta
fill 488 177 467 488 178 467 minecraft:magma_block
setblock 488 177 502 minecraft:terracotta
fill 488 177 503 491 177 503 minecraft:red_terracotta
fill 489 177 502 489 180 502 minecraft:red_terracotta
setblock 491 177 464 minecraft:terracotta
setblock 491 177 504 minecraft:terracotta
fill 492 177 464 492 180 464 minecraft:red_terracotta
setblock 492 177 503 minecraft:terracotta
fill 492 177 504 492 180 504 minecraft:red_terracotta
setblock 493 177 502 minecraft:terracotta
fill 493 177 503 493 180 503 minecraft:red_terracotta
fill 494 177 464 494 178 464 minecraft:red_terracotta
setblock 496 177 504 minecraft:terracotta
fill 497 177 504 497 180 504 minecraft:red_terracotta
setblock 505 177 464 minecraft:red_terracotta
setblock 505 177 504 minecraft:red_terracotta
setblock 506 177 464 minecraft:terracotta
setblock 506 177 504 minecraft:terracotta
fill 507 177 464 507 180 464 minecraft:red_terracotta
fill 507 177 504 507 180 504 minecraft:red_terracotta
fill 508 177 465 509 177 465 minecraft:red_terracotta
fill 508 177 480 508 177 481 minecraft:red_terracotta
setblock 508 177 482 minecraft:terracotta
fill 508 177 503 508 180 503 minecraft:red_terracotta
setblock 509 177 476 minecraft:terracotta
fill 509 177 477 509 180 477 minecraft:red_terracotta
setblock 509 177 481 minecraft:terracotta
fill 509 177 482 509 180 482 minecraft:red_terracotta
setblock 509 177 485 minecraft:red_terracotta
setblock 510 177 464 minecraft:red_terracotta
setblock 510 177 465 minecraft:terracotta
fill 510 177 466 510 180 466 minecraft:red_terracotta
fill 510 177 468 510 177 469 minecraft:red_terracotta
setblock 510 177 470 minecraft:terracotta
fill 510 177 471 510 177 474 minecraft:red_terracotta
setblock 510 177 475 minecraft:terracotta
fill 510 177 476 510 180 476 minecraft:red_terracotta
setblock 510 177 480 minecraft:terracotta
fill 510 177 481 510 180 481 minecraft:red_terracotta
setblock 510 177 485 minecraft:terracotta
fill 510 177 486 510 180 486 minecraft:red_terracotta
fill 510 177 501 510 180 501 minecraft:red_terracotta
setblock 511 177 464 minecraft:terracotta
fill 511 177 465 511 180 465 minecraft:red_terracotta
setblock 511 177 468 minecraft:red_terracotta
setblock 511 177 469 minecraft:terracotta
fill 511 177 470 511 177 473 minecraft:red_terracotta
setblock 511 177 474 minecraft:terracotta
fill 511 177 475 511 180 475 minecraft:red_terracotta
setblock 511 177 479 minecraft:terracotta
fill 511 177 480 511 180 480 minecraft:red_terracotta
setblock 511 177 484 minecraft:terracotta
fill 511 177 485 511 180 485 minecraft:red_terracotta
setblock 511 177 489 minecraft:terracotta
fill 511 177 490 511 180 490 minecraft:red_terracotta
setblock 511 177 499 minecraft:terracotta
fill 511 177 500 511 180 500 minecraft:red_terracotta
setblock 511 177 504 minecraft:terracotta
fill 471 178 464 471 178 467 minecraft:red_terracotta
setblock 471 178 468 minecraft:terracotta
fill 471 178 469 471 181 469 minecraft:red_terracotta
setblock 471 178 473 minecraft:terracotta
fill 471 178 474 471 178 477 minecraft:red_terracotta
setblock 471 178 478 minecraft:terracotta
fill 471 178 479 471 178 482 minecraft:red_terracotta
setblock 471 178 483 minecraft:terracotta
fill 471 178 484 471 181 484 minecraft:red_terracotta
setblock 471 178 488 minecraft:terracotta
fill 471 178 489 471 181 489 minecraft:red_terracotta
setblock 471 178 497 minecraft:red_terracotta
setblock 471 178 498 minecraft:terracotta
fill 471 178 499 471 181 499 minecraft:red_terracotta
setblock 471 178 502 minecraft:red_terracotta
setblock 471 178 503 minecraft:terracotta
fill 471 178 504 474 178 504 minecraft:red_terracotta
setblock 472 178 467 minecraft:terracotta
fill 472 178 468 472 181 468 minecraft:red_terracotta
fill 472 178 470 472 179 470 minecraft:red_terracotta
setblock 472 178 478 minecraft:red_terracotta
setblock 472 178 482 minecraft:terracotta
fill 472 178 483 472 181 483 minecraft:red_terracotta
fill 472 178 485 472 179 485 minecraft:red_terracotta
setblock 472 178 502 minecraft:terracotta
fill 472 178 503 475 178 503 minecraft:red_terracotta
setblock 473 178 466 minecraft:terracotta
fill 473 178 502 473 180 502 minecraft:red_terracotta
setblock 474 178 465 minecraft:terracotta
setblock 475 178 464 minecraft:terracotta
fill 475 178 465 475 181 465 minecraft:red_terracotta
setblock 475 178 504 minecraft:terracotta
fill 476 178 464 476 181 464 minecraft:red_terracotta
setblock 476 178 503 minecraft:terracotta
fill 476 178 504 479 178 504 minecraft:red_terracotta
fill 477 178 503 480 178 503 minecraft:red_terracotta
setblock 480 178 464 minecraft:terracotta
setblock 480 178 504 minecraft:terracotta
fill 481 178 464 484 178 464 minecraft:red_terracotta
setblock 481 178 503 minecraft:terracotta
fill 481 178 504 484 178 504 minecraft:red_terracotta
fill 482 178 503 485 178 503 minecraft:red_terracotta
fill 484 178 502 486 178 502 minecraft:red_terracotta
setblock 485 178 464 minecraft:terracotta
setblock 485 178 504 minecraft:terracotta
fill 486 178 464 486 181 464 minecraft:red_terracotta
setblock 486 178 503 minecraft:terracotta
fill 486 178 504 489 178 504 minecraft:red_terracotta
fill 487 178 465 488 178 465 minecraft:red_terracotta
setblock 487 178 502 minecraft:terracotta
fill 487 178 503 490 178 503 minecraft:red_terracotta
fill 488 178 502 488 181 502 minecraft:red_terracotta
setblock 489 178 465 minecraft:terracotta
setblock 490 178 464 minecraft:terracotta
fill 490 178 465 490 181 465 minecraft:red_terracotta
setblock 490 178 504 minecraft:terracotta
fill 491 178 464 491 181 464 minecraft:red_terracotta
setblock 491 178 503 minecraft:terracotta
fill 491 178 504 491 181 504 minecraft:red_terracotta
setblock 492 178 502 minecraft:terracotta
fill 492 178 503 492 181 503 minecraft:red_terracotta
setblock 493 178 502 minecraft:red_terracotta
setblock 495 178 504 minecraft:terracotta
fill 496 178 504 496 181 504 minecraft:red_terracotta
setblock 504 178 464 minecraft:red_terracotta
setblock 504 178 504 minecraft:red_terracotta
setblock 505 178 464 minecraft:terracotta
setblock 505 178 504 minecraft:terracotta
fill 506 178 464 506 180 465 minecraft:red_terracotta
fill 506 178 504 506 181 504 minecraft:red_terracotta
fill 507 178 465 508 178 465 minecraft:red_terracotta
fill 507 178 503 507 181 503 minecraft:red_terracotta
setblock 508 178 480 minecraft:red_terracotta
setblock 508 178 481 minecraft:terracotta
fill 508 178 482 508 180 483 minecraft:red_terracotta
setblock 509 178 465 minecraft:terracotta
fill 509 178 466 509 181 466 minecraft:red_terracotta
fill 509 178 476 509 181 476 minecraft:red_terracotta
setblock 509 178 480 minecraft:terracotta
fill 509 178 481 509 181 481 minecraft:red_terracotta
setblock 509 178 485 minecraft:terracotta
fill 509 178 486 509 181 486 minecraft:red_terracotta
setblock 510 178 464 minecraft:terracotta
fill 510 178 465 510 181 465 minecraft:red_terracotta
setblock 510 178 468 minecraft:red_terracotta
setblock 510 178 469 minecraft:terracotta
fill 510 178 470 510 178 473 minecraft:red_terracotta
setblock 510 178 474 minecraft:terracotta
fill 510 178 475 510 181 475 minecraft:red_terracotta
setblock 510 178 479 minecraft:terracotta
fill 510 178 480 510 181 480 minecraft:red_terracotta
setblock 510 178 484 minecraft:terracotta
fill 510 178 485 510 181 485 minecraft:red_terracotta
setblock 510 178 488 minecraft:red_terracotta
setblock 510 178 504 minecraft:terracotta
fill 511 178 464 511 181 464 minecraft:red_terracotta
setblock 511 178 468 minecraft:terracotta
fill 511 178 469 511 178 472 minecraft:red_terracotta
setblock 511 178 473 minecraft:terracotta
fill 511 178 474 511 181 474 minecraft:red_terracotta
setblock 511 178 478 minecraft:terracotta
fill 511 178 479 511 181 479 minecraft:red_terracotta
setblock 511 178 483 minecraft:terracotta
fill 511 178 484 511 181 484 minecraft:red_terracotta
setblock 511 178 488 minecraft:terracotta
fill 511 178 489 511 181 489 minecraft:red_terracotta
setblock 511 178 498 minecraft:terracotta
fill 511 178 499 511 181 499 minecraft:red_terracotta
setblock 511 178 503 minecraft:terracotta
fill 511 178 504 511 181 504 minecraft:red_terracotta
fill 471 179 464 471 179 466 minecraft:red_terracotta
setblock 471 179 467 minecraft:terracotta
fill 471 179 468 471 182 468 minecraft:red_terracotta
setblock 471 179 472 minecraft:terracotta
fill 471 179 473 471 179 476 minecraft:red_terracotta
setblock 471 179 477 minecraft:terracotta
fill 471 179 478 471 179 481 minecraft:red_terracotta
setblock 471 179 482 minecraft:terracotta
fill 471 179 483 471 182 483 minecraft:red_terracotta
setblock 471 179 486 minecraft:red_terracotta
setblock 471 179 487 minecraft:terracotta
fill 471 179 488 471 182 488 minecraft:red_terracotta
fill 471 179 490 471 180 490 minecraft:red_terracotta
setblock 471 179 496 minecraft:red_terracotta
setblock 471 179 497 minecraft:terracotta
fill 471 179 498 471 182 498 minecraft:red_terracotta
setblock 471 179 502 minecraft:terracotta
fill 471 179 503 473 179 504 minecraft:red_terracotta
setblock 472 179 466 minecraft:terracotta
fill 472 179 467 472 182 467 minecraft:red_terracotta
setblock 472 179 481 minecraft:terracotta
fill 472 179 482 472 181 482 minecraft:red_terracotta
setblock 472 179 486 minecraft:terracotta
setblock 472 179 501 minecraft:terracotta
fill 472 179 502 472 182 502 minecraft:red_terracotta
setblock 473 179 465 minecraft:terracotta
fill 473 179 466 473 182 466 minecraft:red_terracotta
fill 473 179 482 485 180 483 minecraft:iron_block
setblock 474 179 464 minecraft:terracotta
fill 474 179 465 474 182 465 minecraft:red_terracotta
setblock 474 179 503 minecraft:red_terracotta
setblock 474 179 504 minecraft:terracotta
fill 475 179 464 475 182 464 minecraft:red_terracotta
setblock 475 179 503 minecraft:terracotta
fill 475 179 504 478 179 504 minecraft:red_terracotta
fill 476 179 503 479 179 503 minecraft:red_terracotta
setblock 477 179 465 minecraft:red_terracotta
setblock 479 179 464 minecraft:terracotta
setblock 479 179 504 minecraft:terracotta
fill 480 179 464 483 179 464 minecraft:red_terracotta
setblock 480 179 503 minecraft:terracotta
fill 480 179 504 483 179 504 minecraft:red_terracotta
fill 481 179 503 484 179 503 minecraft:red_terracotta
fill 483 179 502 485 179 502 minecraft:red_terracotta
setblock 484 179 464 minecraft:terracotta
fill 484 179 465 487 179 465 minecraft:red_terracotta
setblock 484 179 504 minecraft:terracotta
fill 485 179 464 485 182 464 minecraft:red_terracotta
setblock 485 179 503 minecraft:terracotta
fill 485 179 504 488 179 504 minecraft:red_terracotta
fill 486 179 482 499 180 482 minecraft:iron_block
setblock 486 179 502 minecraft:terracotta
fill 486 179 503 489 179 503 minecraft:red_terracotta
fill 487 179 483 499 180 483 minecraft:iron_block
fill 487 179 502 487 182 502 minecraft:red_terracotta
setblock 488 179 465 minecraft:terracotta
setblock 489 179 464 minecraft:terracotta
fill 489 179 465 489 182 465 minecraft:red_terracotta
setblock 489 179 504 minecraft:terracotta
fill 490 179 464 490 182 464 minecraft:red_terracotta
setblock 490 179 503 minecraft:terracotta
fill 490 179 504 490 182 504 minecraft:red_terracotta
fill 491 179 465 491 180 465 minecraft:red_terracotta
setblock 491 179 502 minecraft:terracotta
fill 491 179 503 491 182 503 minecraft:red_terracotta
fill 492 179 502 492 180 502 minecraft:red_terracotta
setblock 494 179 464 minecraft:terracotta
setblock 494 179 504 minecraft:terracotta
fill 495 179 464 495 182 464 minecraft:red_terracotta
fill 495 179 504 495 182 504 minecraft:red_terracotta
fill 502 179 464 503 179 464 minecraft:red_terracotta
setblock 503 179 504 minecraft:red_terracotta
setblock 504 179 464 minecraft:terracotta
setblock 504 179 504 minecraft:terracotta
fill 505 179 464 505 181 465 minecraft:red_terracotta
fill 505 179 504 505 182 504 minecraft:red_terracotta
fill 506 179 503 506 182 503 minecraft:red_terracotta
setblock 507 179 465 minecraft:red_terracotta
setblock 507 179 466 minecraft:terracotta
setblock 508 179 465 minecraft:terracotta
fill 508 179 466 508 182 466 minecraft:red_terracotta
setblock 508 179 479 minecraft:red_terracotta
setblock 508 179 480 minecraft:terracotta
fill 508 179 481 508 182 481 minecraft:red_terracotta
setblock 508 179 484 minecraft:red_terracotta
setblock 508 179 485 minecraft:terracotta
setblock 509 179 464 minecraft:terracotta
fill 509 179 465 509 182 465 minecraft:red_terracotta
fill 509 179 467 509 179 468 minecraft:red_terracotta
setblock 509 179 469 minecraft:terracotta
fill 509 179 475 509 182 475 minecraft:red_terracotta
setblock 509 179 479 minecraft:terracotta
fill 509 179 480 509 182 480 minecraft:red_terracotta
setblock 509 179 484 minecraft:terracotta
fill 509 179 485 509 182 485 minecraft:red_terracotta
fill 509 179 487 509 180 487 minecraft:red_terracotta
setblock 509 179 504 minecraft:terracotta
fill 510 179 464 510 182 464 minecraft:red_terracotta
setblock 510 179 467 minecraft:red_terracotta
setblock 510 179 468 minecraft:terracotta
fill 510 179 469 510 179 472 minecraft:red_terracotta
setblock 510 179 473 minecraft:terracotta
fill 510 179 474 510 182 474 minecraft:red_terracotta
setblock 510 179 478 minecraft:terracotta
fill 510 179 479 510 182 479 minecraft:red_terracotta
setblock 510 179 483 minecraft:terracotta
fill 510 179 484 510 182 484 minecraft:red_terracotta
setblock 510 179 488 minecraft:terracotta
fill 510 179 489 510 182 489 minecraft:red_terracotta
setblock 510 179 503 minecraft:terracotta
fill 510 179 504 510 182 504 minecraft:red_terracotta
setblock 511 179 467 minecraft:terracotta
fill 511 179 468 511 179 471 minecraft:red_terracotta
setblock 511 179 472 minecraft:terracotta
fill 511 179 473 511 182 473 minecraft:red_terracotta
setblock 511 179 477 minecraft:terracotta
fill 511 179 478 511 182 478 minecraft:red_terracotta
setblock 511 179 482 minecraft:terracotta
fill 511 179 483 511 182 483 minecraft:red_terracotta
setblock 511 179 487 minecraft:terracotta
fill 511 179 488 511 182 488 minecraft:red_terracotta
setblock 511 179 491 minecraft:red_terracotta
fill 511 179 498 511 180 498 minecraft:red_terracotta
setblock 511 179 502 minecraft:terracotta
fill 511 179 503 511 182 503 minecraft:red_terracotta
fill 471 180 464 471 180 465 minecraft:red_terracotta
setblock 471 180 466 minecraft:terracotta
fill 471 180 467 471 183 467 minecraft:red_terracotta
setblock 471 180 471 minecraft:terracotta
fill 471 180 472 471 180 475 minecraft:red_terracotta
setblock 471 180 476 minecraft:terracotta
fill 471 180 477 471 180 480 minecraft:red_terracotta
setblock 471 180 481 minecraft:terracotta
fill 471 180 482 471 183 482 minecraft:red_terracotta
setblock 471 180 486 minecraft:terracotta
fill 471 180 487 472 182 487 minecraft:red_terracotta
setblock 471 180 491 minecraft:terracotta
fill 471 180 492 471 183 492 minecraft:red_terracotta
setblock 471 180 496 minecraft:terracotta
fill 471 180 497 471 183 497 minecraft:red_terracotta
setblock 471 180 501 minecraft:terracotta
fill 471 180 502 471 181 504 minecraft:red_terracotta
setblock 472 180 465 minecraft:terracotta
fill 472 180 466 472 183 466 minecraft:red_terracotta
setblock 472 180 470 minecraft:terracotta
setblock 472 180 480 minecraft:terracotta
setblock 472 180 481 minecraft:red_terracotta
setblock 472 180 485 minecraft:terracotta
fill 472 180 486 472 183 486 minecraft:red_terracotta
setblock 472 180 500 minecraft:terracotta
fill 472 180 501 472 183 501 minecraft:red_terracotta
fill 472 180 503 472 180 504 minecraft:red_terracotta
setblock 473 180 464 minecraft:terracotta
fill 473 180 465 473 183 465 minecraft:red_terracotta
fill 473 180 467 473 181 467 minecraft:red_terracotta
setblock 473 180 503 minecraft:red_terracotta
setblock 473 180 504 minecraft:terracotta
fill 474 180 464 474 183 464 minecraft:red_terracotta
fill 474 180 466 474 181 466 minecraft:red_terracotta
setblock 474 180 503 minecraft:terracotta
fill 474 180 504 477 180 504 minecraft:red_terracotta
fill 475 180 503 478 180 503 minecraft:red_terracotta
setblock 477 180 465 minecraft:terracotta
setblock 478 180 464 minecraft:terracotta
fill 478 180 465 478 183 465 minecraft:red_terracotta
setblock 478 180 504 minecraft:terracotta
fill 479 180 464 482 180 464 minecraft:red_terracotta
setblock 479 180 503 minecraft:terracotta
fill 479 180 504 482 180 504 minecraft:red_terracotta
fill 480 180 503 483 180 503 minecraft:red_terracotta
setblock 481 180 465 minecraft:red_terracotta
setblock 482 180 465 minecraft:terracotta
fill 482 180 502 484 180 502 minecraft:red_terracotta
setblock 483 180 464 minecraft:terracotta
fill 483 180 465 486 180 465 minecraft:red_terracotta
setblock 483 180 504 minecraft:terracotta
fill 484 180 464 484 183 464 minecraft:red_terracotta
setblock 484 180 503 minecraft:terracotta
fill 484 180 504 487 180 504 minecraft:red_terracotta
setblock 485 180 502 minecraft:terracotta
fill 485 180 503 488 180 503 minecraft:red_terracotta
fill 486 180 502 486 183 502 minecraft:red_terracotta
setblock 487 180 465 minecraft:terracotta
setblock 488 180 464 minecraft:terracotta
fill 488 180 465 488 183 465 minecraft:red_terracotta
setblock 488 180 504 minecraft:terracotta
fill 489 180 464 489 183 464 minecraft:red_terracotta
setblock 489 180 503 minecraft:terracotta
fill 489 180 504 489 183 504 minecraft:red_terracotta
setblock 490 180 502 minecraft:terracotta
fill 490 180 503 490 183 503 minecraft:red_terracotta
fill 491 180 502 491 181 502 minecraft:red_terracotta
setblock 492 180 465 minecraft:terracotta
setblock 493 180 464 minecraft:terracotta
setblock 493 180 504 minecraft:terracotta
fill 494 180 464 494 183 464 minecraft:red_terracotta
setblock 494 180 503 minecraft:terracotta
fill 494 180 504 494 183 504 minecraft:red_terracotta
fill 496 180 464 496 181 464 minecraft:red_terracotta
fill 500 180 464 502 180 464 minecraft:red_terracotta
fill 501 180 504 502 180 504 minecraft:red_terracotta
setblock 503 180 464 minecraft:terracotta
fill 503 180 465 504 182 465 minecraft:red_terracotta
setblock 503 180 504 minecraft:terracotta
fill 504 180 464 504 183 464 minecraft:red_terracotta
fill 504 180 504 504 183 504 minecraft:red_terracotta
setblock 505 180 466 minecraft:red_terracotta
fill 505 180 503 505 183 503 minecraft:red_terracotta
setblock 506 180 466 minecraft:terracotta
setblock 507 180 465 minecraft:terracotta
fill 507 180 466 507 183 466 minecraft:red_terracotta
setblock 508 180 464 minecraft:terracotta
fill 508 180 465 508 183 465 minecraft:red_terracotta
setblock 508 180 479 minecraft:terracotta
fill 508 180 480 508 181 480 minecraft:red_terracotta
setblock 508 180 484 minecraft:terracotta
fill 508 180 485 508 182 486 minecraft:red_terracotta
setblock 508 180 504 minecraft:terracotta
fill 509 180 464 509 183 464 minecraft:red_terracotta
setblock 509 180 467 minecraft:red_terracotta
setblock 509 180 468 minecraft:terracotta
fill 509 180 469 509 180 472 minecraft:red_terracotta
setblock 509 180 473 minecraft:terracotta
fill 509 180 474 509 183 474 minecraft:red_terracotta
setblock 509 180 478 minecraft:terracotta
fill 509 180 479 509 183 479 minecraft:red_terracotta
setblock 509 180 483 minecraft:terracotta
fill 509 180 484 509 183 484 minecraft:red_terracotta
setblock 509 180 488 minecraft:terracotta
setblock 509 180 503 minecraft:terracotta
fill 509 180 504 509 183 504 minecraft:red_terracotta
setblock 510 180 467 minecraft:terracotta
fill 510 180 468 510 180 471 minecraft:red_terracotta
setblock 510 180 472 minecraft:terracotta
fill 510 180 473 510 183 473 minecraft:red_terracotta
setblock 510 180 477 minecraft:terracotta
fill 510 180 478 510 183 478 minecraft:red_terracotta
setblock 510 180 482 minecraft:terracotta
fill 510 180 483 510 183 483 minecraft:red_terracotta
setblock 510 180 487 minecraft:terracotta
fill 510 180 488 510 183 488 minecraft:red_terracotta
fill 510 180 490 510 181 490 minecraft:red_terracotta
setblock 510 180 502 minecraft:terracotta
fill 510 180 503 510 183 503 minecraft:red_terracotta
setblock 511 180 466 minecraft:terracotta
fill 511 180 467 511 180 470 minecraft:red_terracotta
setblock 511 180 471 minecraft:terracotta
fill 511 180 472 511 183 472 minecraft:red_terracotta
setblock 511 180 476 minecraft:terracotta
fill 511 180 477 511 183 477 minecraft:red_terracotta
setblock 511 180 481 minecraft:terracotta
fill 511 180 482 511 183 482 minecraft:red_terracotta
setblock 511 180 486 minecraft:terracotta
fill 511 180 487 511 183 487 minecraft:red_terracotta
setblock 511 180 491 minecraft:terracotta
fill 511 180 492 511 183 492 minecraft:red_terracotta
setblock 511 180 501 minecraft:terracotta
fill 511 180 502 511 183 502 minecraft:red_terracotta
setblock 471 181 464 minecraft:red_terracotta
setblock 471 181 465 minecraft:terracotta
fill 471 181 466 471 184 466 minecraft:red_terracotta
setblock 471 181 470 minecraft:terracotta
fill 471 181 471 471 181 474 minecraft:red_terracotta
setblock 471 181 475 minecraft:terracotta
fill 471 181 476 471 181 479 minecraft:red_terracotta
setblock 471 181 480 minecraft:terracotta
fill 471 181 481 471 183 481 minecraft:red_terracotta
setblock 471 181 485 minecraft:terracotta
fill 471 181 486 471 184 486 minecraft:red_terracotta
setblock 471 181 490 minecraft:terracotta
fill 471 181 491 471 184 491 minecraft:red_terracotta
fill 471 181 493 471 181 494 minecraft:red_terracotta
setblock 471 181 495 minecraft:terracotta
fill 471 181 496 471 183 496 minecraft:red_terracotta
setblock 471 181 500 minecraft:terracotta
fill 471 181 501 471 184 501 minecraft:red_terracotta
setblock 472 181 464 minecraft:terracotta
fill 472 181 465 472 184 465 minecraft:red_terracotta
setblock 472 181 469 minecraft:terracotta
fill 472 181 470 472 184 470 minecraft:red_terracotta
setblock 472 181 484 minecraft:terracotta
fill 472 181 485 472 182 485 minecraft:red_terracotta
fill 472 181 500 472 182 500 minecraft:red_terracotta
setblock 472 181 503 minecraft:red_terracotta
setblock 472 181 504 minecraft:terracotta
fill 473 181 464 473 184 464 minecraft:red_terracotta
setblock 473 181 474 minecraft:light[level=14]
setblock 473 181 482 minecraft:light[level=14]
setblock 473 181 490 minecraft:light[level=14]
setblock 473 181 498 minecraft:light[level=14]
setblock 473 181 503 minecraft:terracotta
fill 473 181 504 476 181 504 minecraft:red_terracotta
fill 474 181 503 477 181 503 minecraft:red_terracotta
setblock 476 181 465 minecraft:terracotta
setblock 477 181 464 minecraft:terracotta
fill 477 181 465 477 184 465 minecraft:red_terracotta
setblock 477 181 504 minecraft:terracotta
fill 478 181 464 481 181 464 minecraft:red_terracotta
setblock 478 181 503 minecraft:terracotta
fill 478 181 504 481 181 504 minecraft:red_terracotta
fill 479 181 465 480 181 465 minecraft:red_terracotta
fill 479 181 503 482 181 503 minecraft:red_terracotta
setblock 481 181 465 minecraft:terracotta
setblock 481 181 466 minecraft:light[level=14]
setblock 481 181 474 minecraft:light[level=14]
setblock 481 181 482 minecraft:light[level=14]
setblock 481 181 490 minecraft:light[level=14]
setblock 481 181 498 minecraft:light[level=14]
setblock 482 181 464 minecraft:terracotta
fill 482 181 465 485 181 465 minecraft:red_terracotta
fill 482 181 502 483 181 502 minecraft:red_terracotta
setblock 482 181 504 minecraft:terracotta
fill 483 181 464 483 184 464 minecraft:red_terracotta
setblock 483 181 503 minecraft:terracotta
fill 483 181 504 486 181 504 minecraft:red_terracotta
setblock 484 181 502 minecraft:terracotta
fill 484 181 503 487 181 503 minecraft:red_terracotta
fill 485 181 502 485 184 502 minecraft:red_terracotta
setblock 486 181 465 minecraft:terracotta
setblock 487 181 464 minecraft:terracotta
fill 487 181 465 487 184 465 minecraft:red_terracotta
setblock 487 181 504 minecraft:terracotta
fill 488 181 464 488 184 464 minecraft:red_terracotta
setblock 488 181 503 minecraft:terracotta
fill 488 181 504 488 184 504 minecraft:red_terracotta
setblock 489 181 466 minecraft:light[level=14]
setblock 489 181 474 minecraft:light[level=14]
setblock 489 181 482 minecraft:light[level=14]
setblock 489 181 490 minecraft:light[level=14]
setblock 489 181 498 minecraft:light[level=14]
setblock 489 181 502 minecraft:terracotta
fill 489 181 503 489 184 503 minecraft:red_terracotta
fill 490 181 502 490 182 502 minecraft:red_terracotta
setblock 491 181 465 minecraft:terracotta
setblock 492 181 464 minecraft:terracotta
fill 492 181 465 492 183 465 minecraft:red_terracotta
setblock 492 181 504 minecraft:terracotta
fill 493 181 464 493 184 464 minecraft:red_terracotta
setblock 493 181 503 minecraft:terracotta
fill 493 181 504 493 184 504 minecraft:red_terracotta
setblock 497 181 464 minecraft:terracotta
setblock 497 181 466 minecraft:light[level=14]
setblock 497 181 474 minecraft:light[level=14]
setblock 497 181 482 minecraft:light[level=14]
setblock 497 181 490 minecraft:light[level=14]
setblock 497 181 498 minecraft:light[level=14]
fill 498 181 464 501 181 464 minecraft:red_terracotta
setblock 501 181 504 minecraft:red_terracotta
setblock 502 181 464 minecraft:terracotta
fill 502 181 465 502 184 465 minecraft:red_terracotta
setblock 502 181 504 minecraft:terracotta
fill 503 181 464 503 184 464 minecraft:red_terracotta
fill 503 181 504 503 184 504 minecraft:red_terracotta
setblock 504 181 466 minecraft:red_terracotta
setblock 505 181 466 minecraft:terracotta
setblock 505 181 474 minecraft:light[level=14]
setblock 505 181 482 minecraft:light[level=14]
setblock 505 181 490 minecraft:light[level=14]
setblock 505 181 498 minecraft:light[level=14]
setblock 506 181 464 minecraft:red_terracotta
setblock 506 181 465 minecraft:terracotta
fill 506 181 466 506 184 466 minecraft:red_terracotta
setblock 507 181 464 minecraft:terracotta
fill 507 181 465 507 184 465 minecraft:red_terracotta
fill 507 181 467 508 181 467 minecraft:red_terracotta
setblock 507 181 504 minecraft:terracotta
fill 508 181 464 508 184 464 minecraft:red_terracotta
setblock 508 181 468 minecraft:terracotta
setblock 508 181 482 minecraft:red_terracotta
setblock 508 181 483 minecraft:terracotta
fill 508 181 484 508 183 484 minecraft:red_terracotta
setblock 508 181 503 minecraft:terracotta
fill 508 181 504 508 184 504 minecraft:red_terracotta
setblock 509 181 467 minecraft:terracotta
fill 509 181 468 509 181 471 minecraft:red_terracotta
setblock 509 181 472 minecraft:terracotta
fill 509 181 473 509 184 473 minecraft:red_terracotta
setblock 509 181 477 minecraft:terracotta
fill 509 181 478 509 182 478 minecraft:red_terracotta
setblock 509 181 482 minecraft:terracotta
fill 509 181 483 509 184 483 minecraft:red_terracotta
setblock 509 181 487 minecraft:terracotta
fill 509 181 488 509 184 488 minecraft:red_terracotta
fill 509 181 503 509 184 503 minecraft:red_terracotta
setblock 510 181 466 minecraft:terracotta
fill 510 181 467 510 181 470 minecraft:red_terracotta
setblock 510 181 471 minecraft:terracotta
fill 510 181 472 510 184 472 minecraft:red_terracotta
setblock 510 181 476 minecraft:terracotta
fill 510 181 477 510 184 477 minecraft:red_terracotta
setblock 510 181 481 minecraft:terracotta
fill 510 181 482 510 184 482 minecraft:red_terracotta
setblock 510 181 486 minecraft:terracotta
fill 510 181 487 510 184 487 minecraft:red_terracotta
setblock 510 181 501 minecraft:terracotta
fill 510 181 502 510 183 502 minecraft:red_terracotta
setblock 511 181 465 minecraft:terracotta
fill 511 181 466 511 181 469 minecraft:red_terracotta
setblock 511 181 470 minecraft:terracotta
fill 511 181 471 511 184 471 minecraft:red_terracotta
setblock 511 181 475 minecraft:terracotta
fill 511 181 476 511 184 476 minecraft:red_terracotta
setblock 511 181 480 minecraft:terracotta
fill 511 181 481 511 184 481 minecraft:red_terracotta
setblock 511 181 485 minecraft:terracotta
fill 511 181 486 511 184 486 minecraft:red_terracotta
setblock 511 181 490 minecraft:terracotta
fill 511 181 491 511 184 491 minecraft:red_terracotta
setblock 511 181 500 minecraft:terracotta
fill 511 181 501 511 183 501 minecraft:red_terracotta
setblock 471 182 464 minecraft:terracotta
fill 471 182 465 471 185 465 minecraft:red_terracotta
setblock 471 182 469 minecraft:terracotta
fill 471 182 470 471 182 473 minecraft:red_terracotta
setblock 471 182 474 minecraft:terracotta
fill 471 182 475 471 182 478 minecraft:red_terracotta
setblock 471 182 479 minecraft:terracotta
fill 471 182 480 471 183 480 minecraft:red_terracotta
setblock 471 182 484 minecraft:terracotta
fill 471 182 485 471 185 485 minecraft:red_terracotta
setblock 471 182 489 minecraft:terracotta
fill 471 182 490 471 185 490 minecraft:red_terracotta
setblock 471 182 493 minecraft:red_terracotta
setblock 471 182 494 minecraft:terracotta
fill 471 182 495 471 184 495 minecraft:red_terracotta
setblock 471 182 499 minecraft:terracotta
fill 471 182 500 471 185 500 minecraft:red_terracotta
fill 471 182 502 471 182 503 minecraft:red_terracotta
setblock 471 182 504 minecraft:terracotta
fill 472 182 464 472 185 464 minecraft:red_terracotta
setblock 472 182 468 minecraft:terracotta
fill 472 182 469 472 185 469 minecraft:red_terracotta
setblock 472 182 484 minecraft:red_terracotta
setblock 472 182 488 minecraft:terracotta
setblock 472 182 503 minecraft:terracotta
fill 472 182 504 475 182 504 minecraft:red_terracotta
setblock 473 182 467 minecraft:terracotta
fill 473 182 503 476 182 503 minecraft:red_terracotta
setblock 474 182 466 minecraft:terracotta
setblock 475 182 465 minecraft:terracotta
setblock 476 182 464 minecraft:terracotta
fill 476 182 465 476 184 465 minecraft:red_terracotta
setblock 476 182 504 minecraft:terracotta
fill 477 182 464 480 182 464 minecraft:red_terracotta
setblock 477 182 503 minecraft:terracotta
fill 477 182 504 480 182 504 minecraft:red_terracotta
fill 478 182 503 481 182 503 minecraft:red_terracotta
setblock 479 182 465 minecraft:red_terracotta
setblock 480 182 465 minecraft:terracotta
setblock 481 182 464 minecraft:terracotta
fill 481 182 465 484 182 465 minecraft:red_terracotta
setblock 481 182 504 minecraft:terracotta
fill 482 182 464 482 185 464 minecraft:red_terracotta
setblock 482 182 502 minecraft:red_terracotta
setblock 482 182 503 minecraft:terracotta
fill 482 182 504 485 182 504 minecraft:red_terracotta
setblock 483 182 502 minecraft:terracotta
fill 483 182 503 486 182 503 minecraft:red_terracotta
fill 484 182 502 484 184 502 minecraft:red_terracotta
setblock 485 182 465 minecraft:terracotta
fill 485 182 466 488 182 466 minecraft:red_terracotta
setblock 486 182 464 minecraft:terracotta
fill 486 182 465 486 185 465 minecraft:red_terracotta
setblock 486 182 504 minecraft:terracotta
fill 487 182 464 487 185 464 minecraft:red_terracotta
setblock 487 182 503 minecraft:terracotta
fill 487 182 504 487 185 504 minecraft:red_terracotta
setblock 488 182 502 minecraft:terracotta
fill 488 182 503 488 185 503 minecraft:red_terracotta
fill 489 182 502 489 183 502 minecraft:red_terracotta
setblock 490 182 465 minecraft:terracotta
setblock 491 182 464 minecraft:terracotta
fill 491 182 465 491 184 465 minecraft:red_terracotta
setblock 491 182 504 minecraft:terracotta
fill 492 182 464 492 185 464 minecraft:red_terracotta
setblock 492 182 503 minecraft:terracotta
fill 492 182 504 492 184 504 minecraft:red_terracotta
setblock 496 182 464 minecraft:terracotta
fill 497 182 464 500 182 464 minecraft:red_terracotta
setblock 501 182 464 minecraft:terracotta
fill 501 182 465 501 185 465 minecraft:red_terracotta
setblock 501 182 504 minecraft:terracotta
fill 502 182 464 502 185 464 minecraft:red_terracotta
fill 502 182 504 502 185 504 minecraft:red_terracotta
setblock 503 182 466 minecraft:red_terracotta
setblock 504 182 466 minecraft:terracotta
setblock 505 182 464 minecraft:red_terracotta
setblock 505 182 465 minecraft:terracotta
fill 505 182 466 505 185 466 minecraft:red_terracotta
setblock 506 182 464 minecraft:terracotta
fill 506 182 465 506 185 465 minecraft:red_terracotta
fill 506 182 467 507 182 467 minecraft:red_terracotta
setblock 506 182 504 minecraft:terracotta
fill 507 182 464 507 185 464 minecraft:red_terracotta
setblock 507 182 503 minecraft:terracotta
fill 507 182 504 507 185 504 minecraft:red_terracotta
setblock 508 182 467 minecraft:terracotta
fill 508 182 468 509 182 470 minecraft:red_terracotta
setblock 508 182 482 minecraft:terracotta
fill 508 182 483 508 183 483 minecraft:red_terracotta
fill 508 182 503 508 184 503 minecraft:red_terracotta
setblock 509 182 466 minecraft:terracotta
fill 509 182 467 511 183 467 minecraft:red_terracotta
setblock 509 182 471 minecraft:terracotta
fill 509 182 472 509 185 472 minecraft:red_terracotta
setblock 509 182 476 minecraft:terracotta
setblock 509 182 477 minecraft:red_terracotta
setblock 509 182 481 minecraft:terracotta
fill 509 182 482 509 184 482 minecraft:red_terracotta
setblock 509 182 486 minecraft:terracotta
fill 509 182 487 509 184 487 minecraft:red_terracotta
fill 509 182 489 509 183 489 minecraft:red_terracotta
setblock 510 182 465 minecraft:terracotta
fill 510 182 466 511 184 466 minecraft:red_terracotta
fill 510 182 468 510 182 469 minecraft:red_terracotta
setblock 510 182 470 minecraft:terracotta
fill 510 182 471 510 185 471 minecraft:red_terracotta
setblock 510 182 475 minecraft:terracotta
fill 510 182 476 510 184 476 minecraft:red_terracotta
setblock 510 182 480 minecraft:terracotta
fill 510 182 481 510 184 481 minecraft:red_terracotta
setblock 510 182 485 minecraft:terracotta
fill 510 182 486 510 185 486 minecraft:red_terracotta
setblock 510 182 490 minecraft:terracotta
fill 510 182 491 510 183 491 minecraft:red_terracotta
setblock 511 182 464 minecraft:terracotta
fill 511 182 465 511 185 465 minecraft:red_terracotta
setblock 511 182 468 minecraft:red_terracotta
setblock 511 182 469 minecraft:terracotta
fill 511 182 470 511 185 470 minecraft:red_terracotta
setblock 511 182 474 minecraft:terracotta
fill 511 182 475 511 185 475 minecraft:red_terracotta
setblock 511 182 479 minecraft:terracotta
fill 511 182 480 511 185 480 minecraft:red_terracotta
setblock 511 182 484 minecraft:terracotta
fill 511 182 485 511 185 485 minecraft:red_terracotta
setblock 511 182 489 minecraft:terracotta
fill 511 182 490 511 185 490 minecraft:red_terracotta
setblock 511 182 493 minecraft:red_terracotta
setblock 511 182 499 minecraft:terracotta
fill 511 182 500 511 183 500 minecraft:red_terracotta
setblock 511 182 504 minecraft:terracotta
fill 471 183 464 471 186 464 minecraft:red_terracotta
setblock 471 183 468 minecraft:terracotta
fill 471 183 469 471 183 472 minecraft:red_terracotta
setblock 471 183 473 minecraft:terracotta
setblock 471 183 474 minecraft:red_terracotta
setblock 471 183 479 minecraft:red_terracotta
setblock 471 183 483 minecraft:terracotta
fill 471 183 484 471 185 484 minecraft:red_terracotta
setblock 471 183 487 minecraft:red_terracotta
setblock 471 183 488 minecraft:terracotta
fill 471 183 489 471 186 489 minecraft:red_terracotta
setblock 471 183 493 minecraft:terracotta
fill 471 183 494 471 185 494 minecraft:red_terracotta
setblock 471 183 498 minecraft:terracotta
fill 471 183 499 471 184 499 minecraft:red_terracotta
setblock 471 183 502 minecraft:red_terracotta
setblock 471 183 503 minecraft:terracotta
fill 471 183 504 474 183 504 minecraft:red_terracotta
setblock 472 183 467 minecraft:terracotta
fill 472 183 468 472 186 468 minecraft:red_terracotta
setblock 472 183 487 minecraft:terracotta
setblock 472 183 502 minecraft:terracotta
fill 472 183 503 475 183 503 minecraft:red_terracotta
setblock 473 183 466 minecraft:terracotta
setblock 473 183 467 minecraft:red_terracotta
setblock 474 183 465 minecraft:terracotta
setblock 475 183 464 minecraft:terracotta
fill 475 183 465 475 185 465 minecraft:red_terracotta
setblock 475 183 504 minecraft:terracotta
fill 476 183 464 479 183 464 minecraft:red_terracotta
setblock 476 183 503 minecraft:terracotta
fill 476 183 504 479 183 504 minecraft:red_terracotta
fill 477 183 503 480 183 503 minecraft:red_terracotta
setblock 479 183 465 minecraft:terracotta
setblock 480 183 464 minecraft:terracotta
fill 480 183 465 483 183 465 minecraft:red_terracotta
setblock 480 183 504 minecraft:terracotta
fill 481 183 464 481 186 464 minecraft:red_terracotta
setblock 481 183 503 minecraft:terracotta
fill 481 183 504 484 183 504 minecraft:red_terracotta
fill 482 183 503 485 183 503 minecraft:red_terracotta
fill 483 183 502 483 184 502 minecraft:red_terracotta
setblock 484 183 465 minecraft:terracotta
fill 484 183 466 487 183 466 minecraft:red_terracotta
setblock 485 183 464 minecraft:terracotta
fill 485 183 465 485 186 465 minecraft:red_terracotta
setblock 485 183 504 minecraft:terracotta
fill 486 183 464 486 186 464 minecraft:red_terracotta
setblock 486 183 503 minecraft:terracotta
fill 486 183 504 486 186 504 minecraft:red_terracotta
setblock 487 183 502 minecraft:terracotta
fill 487 183 503 487 186 503 minecraft:red_terracotta
setblock 488 183 466 minecraft:terracotta
setblock 488 183 502 minecraft:red_terracotta
setblock 489 183 465 minecraft:terracotta
setblock 490 183 464 minecraft:terracotta
fill 490 183 465 490 185 465 minecraft:red_terracotta
setblock 490 183 504 minecraft:terracotta
fill 491 183 464 491 185 464 minecraft:red_terracotta
setblock 491 183 503 minecraft:terracotta
fill 491 183 504 491 185 504 minecraft:red_terracotta
setblock 495 183 464 minecraft:terracotta
fill 496 183 464 499 183 464 minecraft:red_terracotta
setblock 500 183 464 minecraft:terracotta
fill 500 183 465 500 186 465 minecraft:red_terracotta
fill 501 183 464 501 186 464 minecraft:red_terracotta
setblock 501 183 504 minecraft:red_terracotta
setblock 502 183 466 minecraft:red_terracotta
setblock 503 183 465 minecraft:red_terracotta
setblock 503 183 466 minecraft:terracotta
setblock 504 183 465 minecraft:terracotta
fill 504 183 466 504 186 466 minecraft:red_terracotta
setblock 505 183 464 minecraft:terracotta
fill 505 183 465 505 186 465 minecraft:red_terracotta
fill 505 183 467 506 183 467 minecraft:red_terracotta
setblock 505 183 504 minecraft:terracotta
fill 506 183 464 506 186 464 minecraft:red_terracotta
setblock 506 183 503 minecraft:terracotta
fill 506 183 504 506 186 504 minecraft:red_terracotta
setblock 507 183 467 minecraft:terracotta
fill 507 183 503 507 184 503 minecraft:red_terracotta
setblock 508 183 466 minecraft:terracotta
fill 508 183 467 508 183 470 minecraft:red_terracotta
setblock 508 183 485 minecraft:red_terracotta
setblock 508 183 486 minecraft:terracotta
setblock 509 183 465 minecraft:terracotta
fill 509 183 466 509 186 466 minecraft:red_terracotta
fill 509 183 468 509 183 469 minecraft:red_terracotta
setblock 509 183 470 minecraft:terracotta
fill 509 183 471 509 186 471 minecraft:red_terracotta
setblock 509 183 480 minecraft:terracotta
setblock 509 183 481 minecraft:red_terracotta
setblock 509 183 485 minecraft:terracotta
fill 509 183 486 509 184 486 minecraft:red_terracotta
setblock 510 183 464 minecraft:terracotta
fill 510 183 465 510 186 465 minecraft:red_terracotta
setblock 510 183 468 minecraft:red_terracotta
setblock 510 183 469 minecraft:terracotta
fill 510 183 470 510 186 470 minecraft:red_terracotta
setblock 510 183 474 minecraft:terracotta
fill 510 183 475 510 184 475 minecraft:red_terracotta
setblock 510 183 479 minecraft:terracotta
fill 510 183 480 510 184 480 minecraft:red_terracotta
setblock 510 183 484 minecraft:terracotta
fill 510 183 485 510 185 485 minecraft:red_terracotta
setblock 510 183 489 minecraft:terracotta
fill 510 183 490 510 185 490 minecraft:red_terracotta
setblock 510 183 504 minecraft:terracotta
fill 511 183 464 511 186 464 minecraft:red_terracotta
setblock 511 183 468 minecraft:terracotta
fill 511 183 469 511 186 469 minecraft:red_terracotta
setblock 511 183 473 minecraft:terracotta
fill 511 183 474 511 186 474 minecraft:red_terracotta
setblock 511 183 478 minecraft:terracotta
fill 511 183 479 511 185 479 minecraft:red_terracotta
setblock 511 183 483 minecraft:terracotta
fill 511 183 484 511 186 484 minecraft:red_terracotta
setblock 511 183 488 minecraft:terracotta
fill 511 183 489 511 186 489 minecraft:red_terracotta
setblock 511 183 493 minecraft:terracotta
setblock 511 183 503 minecraft:terracotta
fill 511 183 504 511 186 504 minecraft:red_terracotta
setblock 471 184 467 minecraft:terracotta
fill 471 184 468 471 184 471 minecraft:red_terracotta
setblock 471 184 472 minecraft:terracotta
setblock 471 184 473 minecraft:red_terracotta
setblock 471 184 482 minecraft:terracotta
setblock 471 184 483 minecraft:red_terracotta
setblock 471 184 487 minecraft:terracotta
fill 471 184 488 471 187 488 minecraft:red_terracotta
setblock 471 184 492 minecraft:terracotta
fill 471 184 493 471 187 493 minecraft:red_terracotta
setblock 471 184 497 minecraft:terracotta
setblock 471 184 498 minecraft:red_terracotta
setblock 471 184 502 minecraft:terracotta
fill 471 184 503 473 184 504 minecraft:red_terracotta
setblock 472 184 466 minecraft:terracotta
fill 472 184 467 472 186 467 minecraft:red_terracotta
setblock 472 184 502 minecraft:red_terracotta
setblock 473 184 465 minecraft:terracotta
setblock 473 184 466 minecraft:red_terracotta
setblock 474 184 464 minecraft:terracotta
fill 474 184 465 474 185 465 minecraft:red_terracotta
setblock 474 184 503 minecraft:red_terracotta
setblock 474 184 504 minecraft:terracotta
fill 475 184 464 478 184 464 minecraft:red_terracotta
fill 475 184 504 478 184 504 minecraft:red_terracotta
setblock 478 184 465 minecraft:terracotta
fill 478 184 503 479 184 503 minecraft:red_terracotta
setblock 479 184 464 minecraft:terracotta
fill 479 184 465 482 184 465 minecraft:red_terracotta
setblock 479 184 504 minecraft:terracotta
fill 480 184 464 480 187 464 minecraft:red_terracotta
setblock 480 184 503 minecraft:terracotta
fill 480 184 504 483 184 504 minecraft:red_terracotta
fill 481 184 503 484 184 503 minecraft:red_terracotta
setblock 483 184 465 minecraft:terracotta
setblock 484 184 464 minecraft:terracotta
fill 484 184 465 484 184 466 minecraft:red_terracotta
setblock 484 184 504 minecraft:terracotta
fill 485 184 464 485 187 464 minecraft:red_terracotta
fill 485 184 466 486 184 466 minecraft:red_terracotta
setblock 485 184 503 minecraft:terracotta
fill 485 184 504 485 187 504 minecraft:red_terracotta
setblock 486 184 502 minecraft:terracotta
fill 486 184 503 486 186 503 minecraft:red_terracotta
setblock 487 184 466 minecraft:terracotta
setblock 487 184 502 minecraft:red_terracotta
setblock 488 184 465 minecraft:terracotta
setblock 489 184 464 minecraft:terracotta
fill 489 184 465 489 185 465 minecraft:red_terracotta
setblock 489 184 504 minecraft:terracotta
fill 490 184 464 490 186 464 minecraft:red_terracotta
setblock 490 184 503 minecraft:terracotta
fill 490 184 504 490 185 504 minecraft:red_terracotta
setblock 494 184 464 minecraft:terracotta
setblock 495 184 464 minecraft:red_terracotta
fill 497 184 464 498 184 464 minecraft:red_terracotta
setblock 499 184 464 minecraft:terracotta
fill 500 184 464 500 187 464 minecraft:red_terracotta
setblock 502 184 466 minecraft:terracotta
setblock 503 184 465 minecraft:terracotta
fill 503 184 466 503 187 466 minecraft:red_terracotta
setblock 504 184 464 minecraft:terracotta
fill 504 184 465 504 187 465 minecraft:red_terracotta
fill 504 184 467 505 184 467 minecraft:red_terracotta
setblock 504 184 504 minecraft:terracotta
fill 505 184 464 505 187 464 minecraft:red_terracotta
fill 505 184 504 505 187 504 minecraft:red_terracotta
setblock 506 184 467 minecraft:terracotta
setblock 506 184 503 minecraft:red_terracotta
setblock 507 184 466 minecraft:terracotta
fill 507 184 467 510 184 467 minecraft:red_terracotta
setblock 508 184 465 minecraft:terracotta
fill 508 184 466 508 187 466 minecraft:red_terracotta
fill 508 184 468 508 184 469 minecraft:red_terracotta
setblock 508 184 470 minecraft:terracotta
setblock 509 184 464 minecraft:terracotta
fill 509 184 465 509 187 465 minecraft:red_terracotta
setblock 509 184 468 minecraft:red_terracotta
setblock 509 184 469 minecraft:terracotta
fill 509 184 470 509 187 470 minecraft:red_terracotta
setblock 509 184 484 minecraft:terracotta
setblock 509 184 485 minecraft:red_terracotta
setblock 509 184 504 minecraft:terracotta
fill 510 184 464 510 187 464 minecraft:red_terracotta
setblock 510 184 468 minecraft:terracotta
fill 510 184 469 510 187 469 minecraft:red_terracotta
setblock 510 184 473 minecraft:terracotta
fill 510 184 474 510 185 474 minecraft:red_terracotta
setblock 510 184 478 minecraft:terracotta
setblock 510 184 479 minecraft:red_terracotta
setblock 510 184 483 minecraft:terracotta
fill 510 184 484 510 185 484 minecraft:red_terracotta
setblock 510 184 488 minecraft:terracotta
fill 510 184 489 510 185 489 minecraft:red_terracotta
setblock 510 184 503 minecraft:terracotta
fill 510 184 504 510 186 504 minecraft:red_terracotta
setblock 511 184 467 minecraft:terracotta
fill 511 184 468 511 187 468 minecraft:red_terracotta
setblock 511 184 472 minecraft:terracotta
fill 511 184 473 511 187 473 minecraft:red_terracotta
setblock 511 184 477 minecraft:terracotta
fill 511 184 478 511 185 478 minecraft:red_terracotta
setblock 511 184 482 minecraft:terracotta
fill 511 184 483 511 185 483 minecraft:red_terracotta
setblock 511 184 487 minecraft:terracotta
fill 511 184 488 511 186 488 minecraft:red_terracotta
setblock 511 184 492 minecraft:terracotta
setblock 511 184 502 minecraft:terracotta
fill 511 184 503 511 185 503 minecraft:red_terracotta
setblock 471 185 466 minecraft:terracotta
fill 471 185 467 471 185 470 minecraft:red_terracotta
setblock 471 185 471 minecraft:terracotta
fill 471 185 472 471 186 472 minecraft:red_terracotta
setblock 471 185 486 minecraft:terracotta
fill 471 185 487 471 186 487 minecraft:red_terracotta
setblock 471 185 491 minecraft:terracotta
fill 471 185 492 471 188 492 minecraft:red_terracotta
setblock 471 185 501 minecraft:terracotta
fill 471 185 502 471 186 504 minecraft:red_terracotta
setblock 472 185 465 minecraft:terracotta
fill 472 185 466 472 187 466 minecraft:red_terracotta
setblock 472 185 504 minecraft:red_terracotta
setblock 473 185 464 minecraft:terracotta
fill 473 185 465 473 186 465 minecraft:red_terracotta
setblock 473 185 504 minecraft:terracotta
fill 474 185 464 477 185 464 minecraft:red_terracotta
fill 474 185 504 477 185 504 minecraft:red_terracotta
setblock 478 185 464 minecraft:terracotta
setblock 478 185 504 minecraft:terracotta
fill 479 185 464 479 185 465 minecraft:red_terracotta
fill 479 185 504 482 185 504 minecraft:red_terracotta
fill 480 185 465 481 185 465 minecraft:red_terracotta
fill 480 185 503 483 185 503 minecraft:red_terracotta
setblock 482 185 465 minecraft:terracotta
setblock 483 185 464 minecraft:terracotta
fill 483 185 465 484 187 465 minecraft:red_terracotta
setblock 483 185 504 minecraft:terracotta
fill 484 185 464 484 188 464 minecraft:red_terracotta
setblock 484 185 503 minecraft:terracotta
fill 484 185 504 484 188 504 minecraft:red_terracotta
fill 485 185 503 485 186 503 minecraft:red_terracotta
setblock 487 185 465 minecraft:terracotta
setblock 488 185 464 minecraft:terracotta
fill 488 185 465 488 186 465 minecraft:red_terracotta
setblock 488 185 504 minecraft:terracotta
fill 489 185 464 489 187 464 minecraft:red_terracotta
fill 489 185 504 489 186 504 minecraft:red_terracotta
setblock 498 185 464 minecraft:terracotta
fill 499 185 464 499 188 464 minecraft:red_terracotta
setblock 502 185 465 minecraft:terracotta
fill 502 185 466 502 188 466 minecraft:red_terracotta
setblock 503 185 464 minecraft:terracotta
fill 503 185 465 503 188 465 minecraft:red_terracotta
setblock 503 185 504 minecraft:terracotta
fill 504 185 464 504 188 464 minecraft:red_terracotta
setblock 504 185 467 minecraft:red_terracotta
fill 504 185 504 504 187 504 minecraft:red_terracotta
setblock 505 185 467 minecraft:terracotta
setblock 506 185 466 minecraft:terracotta
fill 506 185 467 509 185 467 minecraft:red_terracotta
setblock 507 185 465 minecraft:terracotta
fill 507 185 466 507 188 466 minecraft:red_terracotta
setblock 508 185 464 minecraft:terracotta
fill 508 185 465 508 188 465 minecraft:red_terracotta
setblock 508 185 468 minecraft:red_terracotta
setblock 508 185 469 minecraft:terracotta
fill 508 185 470 508 186 470 minecraft:red_terracotta
setblock 508 185 504 minecraft:terracotta
fill 509 185 464 509 188 464 minecraft:red_terracotta
setblock 509 185 468 minecraft:terracotta
fill 509 185 469 509 188 469 minecraft:red_terracotta
fill 509 185 504 509 187 504 minecraft:red_terracotta
setblock 510 185 466 minecraft:red_terracotta
setblock 510 185 467 minecraft:terracotta
fill 510 185 468 510 188 468 minecraft:red_terracotta
setblock 510 185 472 minecraft:terracotta
fill 510 185 473 510 187 473 minecraft:red_terracotta
fill 510 185 477 510 223 477 minecraft:magma_block
fill 510 185 478 510 224 478 minecraft:shroomlight
fill 510 185 479 510 224 479 minecraft:magma_block
setblock 510 185 483 minecraft:red_terracotta
setblock 510 185 487 minecraft:terracotta
setblock 510 185 488 minecraft:red_terracotta
setblock 511 185 466 minecraft:terracotta
fill 511 185 467 511 188 467 minecraft:red_terracotta
setblock 511 185 471 minecraft:terracotta
fill 511 185 472 511 188 472 minecraft:red_terracotta
setblock 511 185 476 minecraft:terracotta
setblock 511 185 477 minecraft:red_terracotta
setblock 511 185 481 minecraft:terracotta
setblock 511 185 482 minecraft:red_terracotta
setblock 511 185 486 minecraft:terracotta
fill 511 185 487 511 186 487 minecraft:red_terracotta
setblock 511 185 491 minecraft:terracotta
setblock 511 185 492 minecraft:red_terracotta
setblock 471 186 465 minecraft:terracotta
fill 471 186 466 471 186 469 minecraft:red_terracotta
setblock 471 186 470 minecraft:terracotta
fill 471 186 471 471 188 471 minecraft:red_terracotta
setblock 471 186 486 minecraft:red_terracotta
setblock 471 186 490 minecraft:terracotta
fill 471 186 491 471 189 491 minecraft:red_terracotta
setblock 472 186 464 minecraft:terracotta
setblock 472 186 465 minecraft:red_terracotta
setblock 472 186 504 minecraft:terracotta
fill 473 186 464 476 186 464 minecraft:red_terracotta
fill 473 186 504 476 186 504 minecraft:red_terracotta
setblock 477 186 464 minecraft:terracotta
setblock 477 186 504 minecraft:terracotta
fill 478 186 464 479 187 464 minecraft:red_terracotta
fill 478 186 504 481 186 504 minecraft:red_terracotta
setblock 480 186 465 minecraft:red_terracotta
setblock 481 186 465 minecraft:terracotta
fill 481 186 503 482 186 503 minecraft:red_terracotta
setblock 482 186 464 minecraft:terracotta
fill 482 186 465 482 187 465 minecraft:red_terracotta
setblock 482 186 504 minecraft:terracotta
fill 483 186 464 483 189 464 minecraft:red_terracotta
setblock 483 186 503 minecraft:terracotta
fill 483 186 504 483 189 504 minecraft:red_terracotta
fill 484 186 503 484 187 503 minecraft:red_terracotta
setblock 486 186 465 minecraft:terracotta
setblock 487 186 464 minecraft:terracotta
setblock 487 186 465 minecraft:red_terracotta
setblock 487 186 504 minecraft:terracotta
fill 488 186 464 488 187 464 minecraft:red_terracotta
fill 488 186 504 488 187 504 minecraft:red_terracotta
fill 494 186 485 497 224 488 minecraft:terracotta
fill 495 186 484 497 224 484 minecraft:terracotta
fill 496 186 489 496 224 489 minecraft:terracotta
fill 498 186 485 498 224 487 minecraft:terracotta
setblock 501 186 465 minecraft:terracotta
setblock 502 186 464 minecraft:terracotta
fill 502 186 465 502 189 465 minecraft:red_terracotta
fill 503 186 464 503 189 464 minecraft:red_terracotta
setblock 503 186 504 minecraft:red_terracotta
setblock 504 186 467 minecraft:terracotta
setblock 505 186 466 minecraft:terracotta
fill 505 186 467 508 186 467 minecraft:red_terracotta
setblock 506 186 465 minecraft:terracotta
fill 506 186 466 506 189 466 minecraft:red_terracotta
setblock 507 186 464 minecraft:terracotta
fill 507 186 465 507 189 465 minecraft:red_terracotta
setblock 507 186 504 minecraft:terracotta
fill 508 186 464 508 189 464 minecraft:red_terracotta
setblock 508 186 468 minecraft:terracotta
fill 508 186 469 508 187 469 minecraft:red_terracotta
fill 508 186 504 508 187 504 minecraft:red_terracotta
setblock 509 186 467 minecraft:terracotta
fill 509 186 468 509 189 468 minecraft:red_terracotta
setblock 509 186 472 minecraft:terracotta
setblock 510 186 466 minecraft:terracotta
fill 510 186 467 510 189 467 minecraft:red_terracotta
setblock 510 186 471 minecraft:terracotta
fill 510 186 472 510 189 472 minecraft:red_terracotta
setblock 511 186 465 minecraft:terracotta
fill 511 186 466 511 189 466 minecraft:red_terracotta
setblock 511 186 470 minecraft:terracotta
fill 511 186 471 511 189 471 minecraft:red_terracotta
setblock 511 186 475 minecraft:terracotta
setblock 511 186 485 minecraft:terracotta
setblock 511 186 486 minecraft:red_terracotta
setblock 511 186 490 minecraft:terracotta
setblock 511 186 491 minecraft:red_terracotta
setblock 471 187 464 minecraft:terracotta
fill 471 187 465 471 187 468 minecraft:red_terracotta
setblock 471 187 469 minecraft:terracotta
fill 471 187 470 471 190 470 minecraft:red_terracotta
fill 471 187 486 471 202 486 minecraft:magma_block
fill 471 187 487 471 203 487 minecraft:shroomlight
setblock 471 187 489 minecraft:terracotta
fill 471 187 490 471 188 490 minecraft:red_terracotta
setblock 471 187 503 minecraft:red_terracotta
setblock 471 187 504 minecraft:terracotta
fill 472 187 464 475 187 464 minecraft:red_terracotta
fill 472 187 504 473 187 504 minecraft:red_terracotta
setblock 476 187 464 minecraft:terracotta
setblock 477 187 464 minecraft:red_terracotta
fill 477 187 504 480 187 504 minecraft:red_terracotta
setblock 481 187 464 minecraft:terracotta
setblock 481 187 504 minecraft:terracotta
fill 482 187 464 482 190 464 minecraft:red_terracotta
fill 482 187 504 482 190 504 minecraft:red_terracotta
setblock 483 187 503 minecraft:red_terracotta
setblock 485 187 465 minecraft:terracotta
setblock 486 187 464 minecraft:terracotta
setblock 486 187 465 minecraft:red_terracotta
setblock 486 187 504 minecraft:terracotta
fill 487 187 464 487 188 464 minecraft:red_terracotta
setblock 487 187 504 minecraft:red_terracotta
fill 493 187 484 493 188 488 minecraft:brown_terracotta
fill 494 187 484 494 188 484 minecraft:brown_terracotta
fill 494 187 489 495 188 489 minecraft:brown_terracotta
fill 495 187 483 497 188 483 minecraft:brown_terracotta
fill 495 187 490 496 188 490 minecraft:brown_terracotta
fill 497 187 489 498 188 489 minecraft:brown_terracotta
fill 498 187 484 498 188 484 minecraft:brown_terracotta
fill 498 187 488 499 188 488 minecraft:brown_terracotta
fill 499 187 485 499 188 487 minecraft:brown_terracotta
setblock 500 187 465 minecraft:terracotta
setblock 501 187 464 minecraft:terracotta
fill 501 187 465 501 190 465 minecraft:red_terracotta
fill 502 187 464 502 190 464 minecraft:red_terracotta
setblock 504 187 466 minecraft:terracotta
fill 504 187 467 507 187 467 minecraft:red_terracotta
setblock 505 187 465 minecraft:terracotta
fill 505 187 466 505 190 466 minecraft:red_terracotta
setblock 506 187 464 minecraft:terracotta
fill 506 187 465 506 190 465 minecraft:red_terracotta
setblock 506 187 504 minecraft:terracotta
fill 507 187 464 507 190 464 minecraft:red_terracotta
setblock 507 187 504 minecraft:red_terracotta
setblock 508 187 467 minecraft:terracotta
setblock 508 187 468 minecraft:red_terracotta
setblock 509 187 466 minecraft:terracotta
fill 509 187 467 509 189 467 minecraft:red_terracotta
setblock 509 187 471 minecraft:terracotta
setblock 510 187 465 minecraft:terracotta
fill 510 187 466 510 190 466 minecraft:red_terracotta
setblock 510 187 470 minecraft:terracotta
fill 510 187 471 510 190 471 minecraft:red_terracotta
setblock 511 187 464 minecraft:terracotta
fill 511 187 465 511 190 465 minecraft:red_terracotta
setblock 511 187 469 minecraft:terracotta
fill 511 187 470 511 190 470 minecraft:red_terracotta
setblock 511 187 474 minecraft:terracotta
setblock 511 187 489 minecraft:terracotta
fill 471 188 464 471 188 467 minecraft:red_terracotta
setblock 471 188 468 minecraft:terracotta
fill 471 188 469 471 190 469 minecraft:red_terracotta
fill 471 188 488 471 203 488 minecraft:magma_block
setblock 471 188 493 minecraft:terracotta
setblock 472 188 464 minecraft:red_terracotta
fill 478 188 504 479 188 504 minecraft:red_terracotta
setblock 479 188 464 minecraft:red_terracotta
setblock 480 188 464 minecraft:terracotta
setblock 480 188 504 minecraft:terracotta
fill 481 188 464 481 191 464 minecraft:red_terracotta
fill 481 188 504 481 191 504 minecraft:red_terracotta
setblock 485 188 464 minecraft:terracotta
setblock 485 188 504 minecraft:terracotta
setblock 486 188 464 minecraft:red_terracotta
setblock 486 188 504 minecraft:red_terracotta
fill 492 188 484 492 188 489 minecraft:brown_terracotta
fill 493 188 483 494 188 483 minecraft:brown_terracotta
fill 493 188 489 493 188 490 minecraft:brown_terracotta
fill 494 188 482 497 188 482 minecraft:brown_terracotta
setblock 494 188 490 minecraft:brown_terracotta
fill 495 188 491 497 188 491 minecraft:brown_terracotta
fill 497 188 490 499 188 490 minecraft:brown_terracotta
fill 498 188 483 499 188 483 minecraft:brown_terracotta
fill 499 188 484 500 188 484 minecraft:brown_terracotta
setblock 499 188 489 minecraft:brown_terracotta
setblock 500 188 464 minecraft:terracotta
fill 500 188 465 500 191 465 minecraft:red_terracotta
fill 500 188 485 500 188 488 minecraft:brown_terracotta
fill 501 188 464 501 191 464 minecraft:red_terracotta
setblock 503 188 466 minecraft:terracotta
setblock 504 188 465 minecraft:terracotta
fill 504 188 466 504 188 467 minecraft:red_terracotta
setblock 505 188 464 minecraft:terracotta
fill 505 188 465 505 191 465 minecraft:red_terracotta
fill 505 188 467 506 188 467 minecraft:red_terracotta
setblock 505 188 504 minecraft:terracotta
fill 506 188 464 506 191 464 minecraft:red_terracotta
setblock 506 188 504 minecraft:red_terracotta
setblock 508 188 466 minecraft:terracotta
setblock 509 188 465 minecraft:terracotta
setblock 509 188 466 minecraft:red_terracotta
setblock 509 188 470 minecraft:terracotta
setblock 509 188 471 minecraft:red_terracotta
setblock 510 188 464 minecraft:terracotta
fill 510 188 465 510 189 465 minecraft:red_terracotta
setblock 510 188 469 minecraft:terracotta
fill 510 188 470 510 191 470 minecraft:red_terracotta
fill 511 188 464 511 191 464 minecraft:red_terracotta
setblock 511 188 468 minecraft:terracotta
fill 511 188 469 511 191 469 minecraft:red_terracotta
setblock 511 188 473 minecraft:terracotta
setblock 511 188 474 minecraft:red_terracotta
fill 471 189 464 471 189 466 minecraft:red_terracotta
setblock 471 189 467 minecraft:terracotta
fill 471 189 468 471 190 468 minecraft:red_terracotta
setblock 471 189 492 minecraft:terracotta
fill 471 189 493 471 192 493 minecraft:red_terracotta
setblock 473 189 466 minecraft:light[level=14]
setblock 473 189 474 minecraft:light[level=14]
setblock 473 189 482 minecraft:light[level=14]
setblock 473 189 490 minecraft:light[level=14]
setblock 473 189 498 minecraft:light[level=14]
setblock 479 189 504 minecraft:terracotta
fill 480 189 464 480 190 464 minecraft:red_terracotta
fill 480 189 504 480 192 504 minecraft:red_terracotta
setblock 481 189 466 minecraft:light[level=14]
setblock 481 189 474 minecraft:light[level=14]
setblock 481 189 482 minecraft:light[level=14]
setblock 481 189 490 minecraft:light[level=14]
setblock 481 189 498 minecraft:light[level=14]
setblock 484 189 464 minecraft:terracotta
setblock 484 189 504 minecraft:terracotta
setblock 485 189 464 minecraft:red_terracotta
setblock 485 189 504 minecraft:red_terracotta
setblock 489 189 466 minecraft:light[level=14]
setblock 489 189 474 minecraft:light[level=14]
setblock 489 189 482 minecraft:light[level=14]
setblock 489 189 490 minecraft:light[level=14]
setblock 489 189 498 minecraft:light[level=14]
setblock 497 189 466 minecraft:light[level=14]
setblock 497 189 474 minecraft:light[level=14]
setblock 497 189 482 minecraft:light[level=14]
setblock 497 189 490 minecraft:light[level=14]
setblock 497 189 498 minecraft:light[level=14]
setblock 499 189 464 minecraft:terracotta
fill 500 189 464 500 192 464 minecraft:red_terracotta
setblock 502 189 466 minecraft:terracotta
setblock 503 189 465 minecraft:terracotta
fill 503 189 466 504 191 466 minecraft:red_terracotta
setblock 504 189 464 minecraft:terracotta
fill 504 189 465 504 192 465 minecraft:red_terracotta
fill 505 189 464 505 192 464 minecraft:red_terracotta
setblock 505 189 474 minecraft:light[level=14]
setblock 505 189 482 minecraft:light[level=14]
setblock 505 189 490 minecraft:light[level=14]
setblock 505 189 498 minecraft:light[level=14]
setblock 507 189 466 minecraft:terracotta
setblock 508 189 465 minecraft:terracotta
setblock 508 189 466 minecraft:red_terracotta
setblock 509 189 464 minecraft:terracotta
fill 509 189 465 509 190 465 minecraft:red_terracotta
setblock 509 189 469 minecraft:terracotta
setblock 509 189 470 minecraft:red_terracotta
fill 510 189 464 510 192 464 minecraft:red_terracotta
setblock 510 189 468 minecraft:terracotta
fill 510 189 469 510 192 469 minecraft:red_terracotta
setblock 511 189 467 minecraft:terracotta
fill 511 189 468 511 192 468 minecraft:red_terracotta
setblock 511 189 472 minecraft:terracotta
fill 511 189 473 511 192 473 minecraft:red_terracotta
setblock 471 190 466 minecraft:terracotta
setblock 471 190 467 minecraft:red_terracotta
setblock 471 190 491 minecraft:terracotta
fill 471 190 492 471 193 492 minecraft:red_terracotta
fill 471 190 494 471 190 495 minecraft:red_terracotta
fill 479 190 504 479 193 504 minecraft:red_terracotta
setblock 483 190 464 minecraft:terracotta
setblock 483 190 504 minecraft:terracotta
setblock 484 190 464 minecraft:red_terracotta
setblock 484 190 504 minecraft:red_terracotta
fill 499 190 464 499 193 464 minecraft:red_terracotta
setblock 502 190 465 minecraft:terracotta
fill 502 190 466 502 193 466 minecraft:red_terracotta
setblock 503 190 464 minecraft:terracotta
fill 503 190 465 503 193 465 minecraft:red_terracotta
fill 504 190 464 504 193 464 minecraft:red_terracotta
setblock 506 190 466 minecraft:terracotta
setblock 507 190 465 minecraft:terracotta
setblock 507 190 466 minecraft:red_terracotta
setblock 508 190 464 minecraft:terracotta
fill 508 190 465 508 191 465 minecraft:red_terracotta
fill 509 190 464 509 193 464 minecraft:red_terracotta
setblock 510 190 467 minecraft:terracotta
fill 510 190 468 510 193 468 minecraft:red_terracotta
setblock 510 190 472 minecraft:terracotta
setblock 511 190 466 minecraft:terracotta
fill 511 190 467 511 193 467 minecraft:red_terracotta
setblock 511 190 471 minecraft:terracotta
fill 511 190 472 511 193 472 minecraft:red_terracotta
fill 471 191 491 471 194 491 minecraft:red_terracotta
setblock 471 191 494 minecraft:red_terracotta
setblock 471 191 495 minecraft:terracotta
fill 471 191 496 471 193 497 minecraft:red_terracotta
setblock 482 191 464 minecraft:terracotta
setblock 482 191 504 minecraft:terracotta
fill 483 191 504 483 194 504 minecraft:red_terracotta
setblock 501 191 465 minecraft:terracotta
fill 501 191 466 501 194 466 minecraft:red_terracotta
setblock 502 191 464 minecraft:terracotta
fill 502 191 465 502 194 465 minecraft:red_terracotta
fill 503 191 464 503 194 464 minecraft:red_terracotta
setblock 505 191 466 minecraft:terracotta
setblock 506 191 465 minecraft:terracotta
setblock 506 191 466 minecraft:red_terracotta
setblock 507 191 464 minecraft:terracotta
fill 507 191 465 507 193 465 minecraft:red_terracotta
fill 508 191 464 508 194 464 minecraft:red_terracotta
setblock 510 191 467 minecraft:red_terracotta
setblock 510 191 471 minecraft:terracotta
fill 510 191 472 510 194 472 minecraft:red_terracotta
setblock 511 191 465 minecraft:terracotta
fill 511 191 466 511 194 466 minecraft:red_terracotta
setblock 511 191 470 minecraft:terracotta
fill 511 191 471 511 194 471 minecraft:red_terracotta
setblock 511 191 474 minecraft:red_terracotta
setblock 471 192 494 minecraft:terracotta
fill 471 192 495 471 195 495 minecraft:red_terracotta
setblock 471 192 498 minecraft:red_terracotta
fill 477 192 504 478 194 504 minecraft:red_terracotta
setblock 481 192 464 minecraft:terracotta
setblock 481 192 504 minecraft:terracotta
fill 482 192 504 482 195 504 minecraft:red_terracotta
fill 498 192 464 498 194 464 minecraft:red_terracotta
setblock 499 192 465 minecraft:red_terracotta
setblock 500 192 465 minecraft:terracotta
setblock 501 192 464 minecraft:terracotta
fill 501 192 465 501 195 465 minecraft:red_terracotta
fill 502 192 464 502 195 464 minecraft:red_terracotta
setblock 503 192 466 minecraft:red_terracotta
setblock 504 192 466 minecraft:terracotta
setblock 505 192 465 minecraft:terracotta
fill 505 192 466 505 193 466 minecraft:red_terracotta
setblock 506 192 464 minecraft:terracotta
fill 506 192 465 506 195 465 minecraft:red_terracotta
fill 507 192 464 507 195 464 minecraft:red_terracotta
setblock 510 192 470 minecraft:terracotta
fill 510 192 471 510 195 471 minecraft:red_terracotta
fill 511 192 465 511 195 465 minecraft:red_terracotta
setblock 511 192 469 minecraft:terracotta
fill 511 192 470 511 195 470 minecraft:red_terracotta
setblock 511 192 474 minecraft:terracotta
fill 471 193 490 471 195 490 minecraft:red_terracotta
setblock 471 193 493 minecraft:terracotta
fill 471 193 494 472 195 494 minecraft:red_terracotta
setblock 471 193 498 minecraft:terracotta
fill 471 193 499 471 195 500 minecraft:red_terracotta
fill 472 193 493 472 196 493 minecraft:red_terracotta
fill 472 193 495 472 193 496 minecraft:red_terracotta
setblock 472 193 497 minecraft:terracotta
fill 476 193 504 476 196 504 minecraft:red_terracotta
setblock 480 193 464 minecraft:terracotta
setblock 480 193 504 minecraft:terracotta
fill 481 193 464 481 196 464 minecraft:red_terracotta
fill 481 193 504 481 196 504 minecraft:red_terracotta
setblock 499 193 465 minecraft:terracotta
setblock 500 193 464 minecraft:terracotta
fill 500 193 465 500 195 466 minecraft:red_terracotta
fill 501 193 464 501 196 464 minecraft:red_terracotta
fill 502 193 504 504 193 504 minecraft:red_terracotta
setblock 503 193 466 minecraft:terracotta
setblock 504 193 465 minecraft:terracotta
fill 504 193 466 504 195 466 minecraft:red_terracotta
setblock 505 193 464 minecraft:terracotta
fill 505 193 465 505 196 465 minecraft:red_terracotta
fill 506 193 464 506 196 464 minecraft:red_terracotta
setblock 510 193 464 minecraft:terracotta
setblock 510 193 469 minecraft:terracotta
fill 510 193 470 510 195 470 minecraft:red_terracotta
setblock 510 193 473 minecraft:red_terracotta
setblock 511 193 468 minecraft:terracotta
fill 511 193 469 511 196 469 minecraft:red_terracotta
setblock 511 193 473 minecraft:terracotta
fill 511 193 474 511 195 475 minecraft:red_terracotta
fill 511 193 495 511 195 495 minecraft:red_terracotta
setblock 471 194 492 minecraft:terracotta
fill 471 194 493 471 197 493 minecraft:red_terracotta
setblock 471 194 496 minecraft:red_terracotta
setblock 471 194 497 minecraft:terracotta
fill 471 194 498 472 196 498 minecraft:red_terracotta
setblock 471 194 501 minecraft:red_terracotta
setblock 471 194 502 minecraft:terracotta
fill 472 194 492 472 197 492 minecraft:red_terracotta
setblock 472 194 495 minecraft:red_terracotta
setblock 472 194 496 minecraft:terracotta
fill 472 194 497 472 197 497 minecraft:red_terracotta
fill 472 194 499 472 195 499 minecraft:red_terracotta
setblock 474 194 504 minecraft:terracotta
fill 475 194 504 475 197 504 minecraft:red_terracotta
fill 478 194 503 479 194 503 minecraft:red_terracotta
setblock 479 194 464 minecraft:terracotta
setblock 479 194 504 minecraft:terracotta
fill 480 194 464 480 197 464 minecraft:red_terracotta
setblock 480 194 503 minecraft:terracotta
fill 480 194 504 480 197 504 minecraft:red_terracotta
fill 481 194 503 481 197 503 minecraft:red_terracotta
fill 497 194 464 497 195 464 minecraft:red_terracotta
setblock 498 194 465 minecraft:terracotta
setblock 499 194 464 minecraft:terracotta
fill 499 194 465 499 197 465 minecraft:red_terracotta
fill 500 194 464 500 197 464 minecraft:red_terracotta
fill 500 194 504 503 194 504 minecraft:red_terracotta
setblock 502 194 466 minecraft:terracotta
setblock 503 194 465 minecraft:terracotta
fill 503 194 466 503 196 466 minecraft:red_terracotta
setblock 504 194 464 minecraft:terracotta
fill 504 194 465 504 197 465 minecraft:red_terracotta
setblock 504 194 504 minecraft:terracotta
fill 505 194 464 505 197 464 minecraft:red_terracotta
fill 505 194 504 505 197 504 minecraft:red_terracotta
setblock 509 194 464 minecraft:terracotta
fill 510 194 464 510 195 464 minecraft:red_terracotta
setblock 510 194 469 minecraft:red_terracotta
setblock 510 194 473 minecraft:terracotta
setblock 511 194 467 minecraft:terracotta
fill 511 194 468 511 197 468 minecraft:red_terracotta
setblock 511 194 472 minecraft:terracotta
fill 511 194 473 511 197 473 minecraft:red_terracotta
setblock 511 194 476 minecraft:red_terracotta
fill 511 194 493 511 196 494 minecraft:red_terracotta
setblock 511 194 496 minecraft:red_terracotta
setblock 511 194 497 minecraft:terracotta
fill 511 194 498 511 196 499 minecraft:red_terracotta
setblock 471 195 471 minecraft:terracotta
fill 471 195 472 471 197 473 minecraft:red_terracotta
setblock 471 195 491 minecraft:terracotta
fill 471 195 492 471 198 492 minecraft:red_terracotta
setblock 471 195 496 minecraft:terracotta
fill 471 195 497 471 198 497 minecraft:red_terracotta
setblock 471 195 501 minecraft:terracotta
fill 471 195 502 471 196 504 minecraft:red_terracotta
setblock 472 195 495 minecraft:terracotta
fill 472 195 496 473 197 496 minecraft:red_terracotta
setblock 472 195 500 minecraft:terracotta
setblock 472 195 504 minecraft:red_terracotta
setblock 473 195 493 minecraft:red_terracotta
setblock 473 195 494 minecraft:terracotta
fill 473 195 495 473 198 495 minecraft:red_terracotta
fill 473 195 497 473 195 498 minecraft:red_terracotta
setblock 473 195 504 minecraft:terracotta
fill 474 195 504 474 198 504 minecraft:red_terracotta
fill 476 195 503 478 195 503 minecraft:red_terracotta
setblock 477 195 504 minecraft:red_terracotta
setblock 478 195 464 minecraft:terracotta
setblock 478 195 504 minecraft:terracotta
fill 479 195 464 479 198 464 minecraft:red_terracotta
setblock 479 195 503 minecraft:terracotta
fill 479 195 504 479 198 504 minecraft:red_terracotta
fill 480 195 503 480 198 503 minecraft:red_terracotta
fill 482 195 503 482 196 503 minecraft:red_terracotta
setblock 483 195 504 minecraft:terracotta
fill 496 195 464 496 196 464 minecraft:red_terracotta
setblock 498 195 464 minecraft:terracotta
fill 498 195 465 498 198 465 minecraft:red_terracotta
setblock 498 195 504 minecraft:terracotta
fill 499 195 464 499 198 464 minecraft:red_terracotta
fill 499 195 466 499 196 466 minecraft:red_terracotta
fill 499 195 504 502 195 504 minecraft:red_terracotta
setblock 501 195 466 minecraft:terracotta
setblock 502 195 465 minecraft:terracotta
fill 502 195 466 502 197 466 minecraft:red_terracotta
setblock 503 195 464 minecraft:terracotta
fill 503 195 465 503 198 465 minecraft:red_terracotta
setblock 503 195 504 minecraft:terracotta
fill 504 195 464 504 198 464 minecraft:red_terracotta
fill 504 195 504 504 198 504 minecraft:red_terracotta
fill 506 195 504 506 196 504 minecraft:red_terracotta
setblock 508 195 464 minecraft:terracotta
fill 509 195 464 509 197 464 minecraft:red_terracotta
setblock 510 195 472 minecraft:terracotta
fill 510 195 473 510 196 474 minecraft:red_terracotta
setblock 511 195 466 minecraft:terracotta
fill 511 195 467 511 197 467 minecraft:red_terracotta
setblock 511 195 471 minecraft:terracotta
fill 511 195 472 511 198 472 minecraft:red_terracotta
setblock 511 195 476 minecraft:terracotta
setblock 511 195 496 minecraft:terracotta
fill 511 195 497 511 198 497 minecraft:red_terracotta
setblock 511 195 500 minecraft:red_terracotta
setblock 511 195 501 minecraft:terracotta
fill 511 195 502 511 198 502 minecraft:red_terracotta
setblock 471 196 474 minecraft:red_terracotta
setblock 471 196 475 minecraft:terracotta
setblock 471 196 490 minecraft:terracotta
fill 471 196 491 472 197 491 minecraft:red_terracotta
setblock 471 196 494 minecraft:red_terracotta
setblock 471 196 495 minecraft:terracotta
fill 471 196 496 471 199 496 minecraft:red_terracotta
setblock 471 196 499 minecraft:red_terracotta
setblock 471 196 500 minecraft:terracotta
fill 471 196 501 472 198 501 minecraft:red_terracotta
setblock 472 196 494 minecraft:terracotta
fill 472 196 495 472 199 495 minecraft:red_terracotta
setblock 472 196 499 minecraft:terracotta
fill 472 196 500 473 198 500 minecraft:red_terracotta
fill 472 196 502 472 197 502 minecraft:red_terracotta
setblock 472 196 504 minecraft:terracotta
setblock 473 196 493 minecraft:terracotta
fill 473 196 494 473 199 494 minecraft:red_terracotta
setblock 473 196 497 minecraft:red_terracotta
setblock 473 196 498 minecraft:terracotta
fill 473 196 499 473 199 499 minecraft:red_terracotta
fill 473 196 504 473 199 504 minecraft:red_terracotta
fill 474 196 495 474 196 496 minecraft:red_terracotta
setblock 474 196 497 minecraft:terracotta
fill 474 196 503 477 196 503 minecraft:red_terracotta
setblock 477 196 464 minecraft:terracotta
fill 477 196 502 478 196 502 minecraft:red_terracotta
setblock 477 196 504 minecraft:terracotta
fill 478 196 464 478 198 464 minecraft:red_terracotta
setblock 478 196 503 minecraft:terracotta
fill 478 196 504 478 199 504 minecraft:red_terracotta
setblock 479 196 502 minecraft:terracotta
fill 479 196 503 479 199 503 minecraft:red_terracotta
fill 480 196 502 480 199 502 minecraft:red_terracotta
setblock 482 196 504 minecraft:terracotta
fill 483 196 504 483 199 504 minecraft:red_terracotta
fill 495 196 464 495 197 464 minecraft:red_terracotta
setblock 497 196 464 minecraft:terracotta
fill 497 196 465 497 199 465 minecraft:red_terracotta
setblock 497 196 504 minecraft:terracotta
fill 498 196 464 498 199 464 minecraft:red_terracotta
fill 498 196 504 501 196 504 minecraft:red_terracotta
setblock 500 196 465 minecraft:red_terracotta
setblock 500 196 466 minecraft:terracotta
fill 500 196 503 502 196 503 minecraft:red_terracotta
setblock 501 196 465 minecraft:terracotta
fill 501 196 466 501 197 466 minecraft:red_terracotta
setblock 502 196 464 minecraft:terracotta
fill 502 196 465 502 199 465 minecraft:red_terracotta
setblock 502 196 504 minecraft:terracotta
fill 503 196 464 503 199 464 minecraft:red_terracotta
fill 503 196 504 503 199 504 minecraft:red_terracotta
setblock 507 196 464 minecraft:terracotta
setblock 507 196 504 minecraft:terracotta
fill 508 196 464 508 198 464 minecraft:red_terracotta
fill 508 196 504 508 199 504 minecraft:red_terracotta
setblock 510 196 471 minecraft:terracotta
setblock 510 196 472 minecraft:red_terracotta
fill 510 196 504 511 196 504 minecraft:red_terracotta
setblock 511 196 465 minecraft:terracotta
setblock 511 196 466 minecraft:red_terracotta
setblock 511 196 470 minecraft:terracotta
fill 511 196 471 511 199 471 minecraft:red_terracotta
setblock 511 196 474 minecraft:red_terracotta
setblock 511 196 475 minecraft:terracotta
fill 511 196 476 511 198 477 minecraft:red_terracotta
setblock 511 196 495 minecraft:terracotta
fill 511 196 496 511 199 496 minecraft:red_terracotta
setblock 511 196 500 minecraft:terracotta
fill 511 196 501 511 199 501 minecraft:red_terracotta
fill 511 196 503 511 197 503 minecraft:red_terracotta
setblock 471 197 474 minecraft:terracotta
fill 471 197 475 471 198 477 minecraft:red_terracotta
fill 471 197 490 471 199 490 minecraft:red_terracotta
setblock 471 197 494 minecraft:terracotta
fill 471 197 495 471 200 495 minecraft:red_terracotta
setblock 471 197 498 minecraft:red_terracotta
setblock 471 197 499 minecraft:terracotta
fill 471 197 500 471 200 500 minecraft:red_terracotta
fill 471 197 502 471 197 503 minecraft:red_terracotta
setblock 471 197 504 minecraft:terracotta
setblock 472 197 493 minecraft:terracotta
fill 472 197 494 472 200 494 minecraft:red_terracotta
setblock 472 197 498 minecraft:terracotta
fill 472 197 499 472 200 499 minecraft:red_terracotta
setblock 472 197 503 minecraft:terracotta
fill 472 197 504 472 200 504 minecraft:red_terracotta
setblock 473 197 466 minecraft:light[level=14]
setblock 473 197 474 minecraft:light[level=14]
setblock 473 197 482 minecraft:light[level=14]
setblock 473 197 490 minecraft:light[level=14]
fill 473 197 493 473 199 493 minecraft:red_terracotta
setblock 473 197 497 minecraft:terracotta
fill 473 197 498 474 199 498 minecraft:red_terracotta
setblock 473 197 501 minecraft:red_terracotta
fill 473 197 503 476 197 503 minecraft:red_terracotta
setblock 474 197 495 minecraft:red_terracotta
setblock 474 197 496 minecraft:terracotta
fill 474 197 497 474 200 497 minecraft:red_terracotta
fill 475 197 502 477 197 502 minecraft:red_terracotta
setblock 476 197 504 minecraft:terracotta
fill 477 197 464 477 198 464 minecraft:red_terracotta
setblock 477 197 503 minecraft:terracotta
fill 477 197 504 477 200 504 minecraft:red_terracotta
setblock 478 197 502 minecraft:terracotta
fill 478 197 503 478 200 503 minecraft:red_terracotta
fill 479 197 502 479 200 502 minecraft:red_terracotta
setblock 481 197 466 minecraft:light[level=14]
setblock 481 197 474 minecraft:light[level=14]
setblock 481 197 482 minecraft:light[level=14]
setblock 481 197 490 minecraft:light[level=14]
setblock 481 197 498 minecraft:light[level=14]
setblock 481 197 504 minecraft:terracotta
setblock 482 197 503 minecraft:terracotta
fill 482 197 504 482 200 504 minecraft:red_terracotta
setblock 489 197 466 minecraft:light[level=14]
setblock 489 197 474 minecraft:light[level=14]
setblock 489 197 482 minecraft:light[level=14]
setblock 489 197 490 minecraft:light[level=14]
setblock 489 197 498 minecraft:light[level=14]
setblock 496 197 464 minecraft:terracotta
setblock 496 197 504 minecraft:terracotta
fill 497 197 464 497 200 464 minecraft:red_terracotta
setblock 497 197 466 minecraft:light[level=14]
setblock 497 197 474 minecraft:light[level=14]
setblock 497 197 482 minecraft:light[level=14]
setblock 497 197 490 minecraft:light[level=14]
setblock 497 197 498 minecraft:light[level=14]
fill 497 197 504 500 197 504 minecraft:red_terracotta
setblock 499 197 466 minecraft:terracotta
fill 499 197 503 501 197 503 minecraft:red_terracotta
setblock 500 197 465 minecraft:terracotta
fill 500 197 466 500 198 466 minecraft:red_terracotta
setblock 501 197 464 minecraft:terracotta
fill 501 197 465 501 200 465 minecraft:red_terracotta
setblock 501 197 504 minecraft:terracotta
fill 502 197 464 502 200 464 minecraft:red_terracotta
setblock 502 197 503 minecraft:terracotta
fill 502 197 504 502 200 504 minecraft:red_terracotta
fill 503 197 503 503 200 503 minecraft:red_terracotta
setblock 505 197 465 minecraft:terracotta
setblock 505 197 466 minecraft:light[level=14]
setblock 505 197 474 minecraft:light[level=14]
setblock 505 197 482 minecraft:light[level=14]
setblock 505 197 490 minecraft:light[level=14]
setblock 505 197 498 minecraft:light[level=14]
setblock 506 197 464 minecraft:terracotta
setblock 506 197 504 minecraft:terracotta
fill 507 197 464 507 198 464 minecraft:red_terracotta
fill 507 197 504 507 200 504 minecraft:red_terracotta
fill 509 197 504 510 197 504 minecraft:red_terracotta
fill 510 197 496 510 197 499 minecraft:red_terracotta
setblock 510 197 500 minecraft:terracotta
setblock 511 197 469 minecraft:terracotta
fill 511 197 470 511 198 470 minecraft:red_terracotta
setblock 511 197 474 minecraft:terracotta
fill 511 197 475 511 200 475 minecraft:red_terracotta
setblock 511 197 493 minecraft:red_terracotta
setblock 511 197 494 minecraft:terracotta
fill 511 197 495 511 200 495 minecraft:red_terracotta
setblock 511 197 498 minecraft:red_terracotta
setblock 511 197 499 minecraft:terracotta
fill 511 197 500 511 200 500 minecraft:red_terracotta
setblock 511 197 504 minecraft:terracotta
setblock 471 198 473 minecraft:terracotta
fill 471 198 474 471 199 474 minecraft:red_terracotta
setblock 471 198 478 minecraft:terracotta
fill 471 198 491 471 199 491 minecraft:red_terracotta
setblock 471 198 493 minecraft:terracotta
fill 471 198 494 471 201 494 minecraft:red_terracotta
setblock 471 198 498 minecraft:terracotta
fill 471 198 499 471 201 499 minecraft:red_terracotta
setblock 471 198 502 minecraft:red_terracotta
setblock 471 198 503 minecraft:terracotta
fill 471 198 504 471 201 504 minecraft:red_terracotta
setblock 472 198 492 minecraft:terracotta
fill 472 198 493 472 201 493 minecraft:red_terracotta
setblock 472 198 496 minecraft:red_terracotta
setblock 472 198 497 minecraft:terracotta
fill 472 198 498 472 201 498 minecraft:red_terracotta
setblock 472 198 502 minecraft:terracotta
fill 472 198 503 475 198 503 minecraft:red_terracotta
setblock 473 198 496 minecraft:terracotta
fill 473 198 497 473 201 497 minecraft:red_terracotta
setblock 473 198 501 minecraft:terracotta
setblock 474 198 495 minecraft:terracotta
fill 474 198 496 474 200 496 minecraft:red_terracotta
setblock 474 198 499 minecraft:red_terracotta
fill 474 198 502 476 198 502 minecraft:red_terracotta
setblock 475 198 504 minecraft:terracotta
setblock 476 198 503 minecraft:terracotta
fill 476 198 504 476 201 504 minecraft:red_terracotta
setblock 477 198 501 minecraft:red_terracotta
setblock 477 198 502 minecraft:terracotta
fill 477 198 503 477 201 503 minecraft:red_terracotta
setblock 478 198 501 minecraft:terracotta
fill 478 198 502 478 201 502 minecraft:red_terracotta
setblock 480 198 504 minecraft:terracotta
setblock 481 198 503 minecraft:terracotta
fill 481 198 504 481 201 504 minecraft:red_terracotta
setblock 482 198 503 minecraft:red_terracotta
setblock 494 198 464 minecraft:red_terracotta
setblock 495 198 464 minecraft:terracotta
setblock 495 198 504 minecraft:terracotta
fill 496 198 464 496 200 465 minecraft:red_terracotta
fill 496 198 504 499 198 504 minecraft:red_terracotta
fill 497 198 503 500 198 503 minecraft:red_terracotta
setblock 499 198 465 minecraft:terracotta
setblock 499 198 466 minecraft:red_terracotta
setblock 500 198 464 minecraft:terracotta
fill 500 198 465 500 201 465 minecraft:red_terracotta
setblock 500 198 504 minecraft:terracotta
fill 501 198 464 501 201 464 minecraft:red_terracotta
setblock 501 198 503 minecraft:terracotta
fill 501 198 504 501 201 504 minecraft:red_terracotta
fill 502 198 503 502 201 503 minecraft:red_terracotta
setblock 504 198 465 minecraft:terracotta
fill 504 198 503 504 199 503 minecraft:red_terracotta
setblock 505 198 464 minecraft:terracotta
setblock 505 198 504 minecraft:terracotta
fill 506 198 464 506 199 464 minecraft:red_terracotta
fill 506 198 504 506 201 504 minecraft:red_terracotta
setblock 509 198 504 minecraft:red_terracotta
fill 510 198 496 510 198 498 minecraft:red_terracotta
setblock 510 198 499 minecraft:terracotta
fill 510 198 500 510 200 501 minecraft:red_terracotta
setblock 510 198 504 minecraft:terracotta
setblock 511 198 469 minecraft:red_terracotta
setblock 511 198 473 minecraft:terracotta
fill 511 198 474 511 200 474 minecraft:red_terracotta
setblock 511 198 478 minecraft:terracotta
setblock 511 198 493 minecraft:terracotta
fill 511 198 494 511 201 494 minecraft:red_terracotta
setblock 511 198 498 minecraft:terracotta
fill 511 198 499 511 201 499 minecraft:red_terracotta
setblock 511 198 503 minecraft:terracotta
fill 511 198 504 511 201 504 minecraft:red_terracotta
fill 471 199 475 471 199 476 minecraft:red_terracotta
setblock 471 199 477 minecraft:terracotta
fill 471 199 478 471 201 479 minecraft:red_terracotta
setblock 471 199 492 minecraft:terracotta
fill 471 199 493 471 202 493 minecraft:red_terracotta
setblock 471 199 497 minecraft:terracotta
fill 471 199 498 471 202 498 minecraft:red_terracotta
setblock 471 199 501 minecraft:red_terracotta
setblock 471 199 502 minecraft:terracotta
fill 471 199 503 474 199 503 minecraft:red_terracotta
fill 472 199 492 472 200 492 minecraft:red_terracotta
setblock 472 199 496 minecraft:terracotta
fill 472 199 497 472 202 497 minecraft:red_terracotta
setblock 472 199 500 minecraft:red_terracotta
setblock 472 199 501 minecraft:terracotta
fill 472 199 502 475 199 502 minecraft:red_terracotta
setblock 473 199 495 minecraft:terracotta
fill 473 199 496 473 202 496 minecraft:red_terracotta
setblock 473 199 500 minecraft:terracotta
fill 473 199 501 473 202 501 minecraft:red_terracotta
setblock 474 199 495 minecraft:red_terracotta
setblock 474 199 499 minecraft:terracotta
fill 474 199 500 474 200 500 minecraft:red_terracotta
setblock 474 199 504 minecraft:terracotta
setblock 475 199 503 minecraft:terracotta
fill 475 199 504 475 202 504 minecraft:red_terracotta
setblock 476 199 501 minecraft:red_terracotta
setblock 476 199 502 minecraft:terracotta
fill 476 199 503 476 202 503 minecraft:red_terracotta
setblock 477 199 501 minecraft:terracotta
fill 477 199 502 477 202 502 minecraft:red_terracotta
setblock 478 199 501 minecraft:red_terracotta
setblock 479 199 504 minecraft:terracotta
setblock 480 199 503 minecraft:terracotta
fill 480 199 504 480 202 504 minecraft:red_terracotta
fill 481 199 503 481 200 503 minecraft:red_terracotta
setblock 494 199 464 minecraft:terracotta
fill 495 199 464 495 202 464 minecraft:red_terracotta
fill 495 199 504 498 199 504 minecraft:red_terracotta
fill 497 199 503 499 199 503 minecraft:red_terracotta
setblock 498 199 465 minecraft:terracotta
setblock 499 199 464 minecraft:terracotta
fill 499 199 465 499 202 465 minecraft:red_terracotta
setblock 499 199 504 minecraft:terracotta
fill 500 199 464 500 202 464 minecraft:red_terracotta
setblock 500 199 503 minecraft:terracotta
fill 500 199 504 500 202 504 minecraft:red_terracotta
fill 501 199 503 501 202 503 minecraft:red_terracotta
setblock 503 199 465 minecraft:terracotta
setblock 504 199 464 minecraft:terracotta
setblock 504 199 504 minecraft:terracotta
fill 505 199 464 505 200 464 minecraft:red_terracotta
fill 505 199 504 505 202 504 minecraft:red_terracotta
setblock 509 199 504 minecraft:terracotta
setblock 510 199 497 minecraft:red_terracotta
setblock 510 199 498 minecraft:terracotta
fill 510 199 499 510 202 499 minecraft:red_terracotta
setblock 510 199 502 minecraft:red_terracotta
fill 510 199 504 510 202 504 minecraft:red_terracotta
setblock 511 199 472 minecraft:terracotta
fill 511 199 473 511 200 473 minecraft:red_terracotta
setblock 511 199 476 minecraft:red_terracotta
setblock 511 199 477 minecraft:terracotta
fill 511 199 478 511 201 478 minecraft:red_terracotta
setblock 511 199 493 minecraft:red_terracotta
setblock 511 199 497 minecraft:terracotta
fill 511 199 498 511 202 498 minecraft:red_terracotta
setblock 511 199 502 minecraft:terracotta
fill 511 199 503 511 202 503 minecraft:red_terracotta
setblock 471 200 475 minecraft:red_terracotta
setblock 471 200 476 minecraft:terracotta
fill 471 200 477 471 203 477 minecraft:red_terracotta
setblock 471 200 480 minecraft:red_terracotta
setblock 471 200 481 minecraft:terracotta
setblock 471 200 491 minecraft:terracotta
fill 471 200 492 471 203 492 minecraft:red_terracotta
setblock 471 200 496 minecraft:terracotta
fill 471 200 497 471 203 497 minecraft:red_terracotta
setblock 471 200 501 minecraft:terracotta
fill 471 200 502 473 200 503 minecraft:red_terracotta
setblock 472 200 495 minecraft:terracotta
fill 472 200 496 472 203 496 minecraft:red_terracotta
setblock 472 200 500 minecraft:terracotta
fill 472 200 501 472 203 501 minecraft:red_terracotta
setblock 473 200 494 minecraft:terracotta
fill 473 200 495 473 201 495 minecraft:red_terracotta
setblock 473 200 498 minecraft:red_terracotta
setblock 473 200 499 minecraft:terracotta
fill 473 200 500 473 203 500 minecraft:red_terracotta
setblock 473 200 504 minecraft:terracotta
setblock 474 200 498 minecraft:terracotta
fill 474 200 499 474 201 499 minecraft:red_terracotta
setblock 474 200 502 minecraft:red_terracotta
setblock 474 200 503 minecraft:terracotta
fill 474 200 504 474 203 504 minecraft:red_terracotta
setblock 475 200 502 minecraft:terracotta
fill 475 200 503 475 203 503 minecraft:red_terracotta
setblock 476 200 501 minecraft:terracotta
fill 476 200 502 476 203 502 minecraft:red_terracotta
setblock 478 200 504 minecraft:terracotta
setblock 479 200 503 minecraft:terracotta
fill 479 200 504 479 203 504 minecraft:red_terracotta
fill 480 200 503 480 201 503 minecraft:red_terracotta
fill 494 200 464 494 203 464 minecraft:red_terracotta
fill 494 200 504 497 200 504 minecraft:red_terracotta
fill 496 200 503 498 200 503 minecraft:red_terracotta
setblock 497 200 465 minecraft:terracotta
setblock 498 200 464 minecraft:terracotta
fill 498 200 465 498 203 465 minecraft:red_terracotta
setblock 498 200 504 minecraft:terracotta
fill 499 200 464 499 203 464 minecraft:red_terracotta
setblock 499 200 503 minecraft:terracotta
fill 499 200 504 499 203 504 minecraft:red_terracotta
fill 500 200 503 500 203 503 minecraft:red_terracotta
setblock 502 200 465 minecraft:terracotta
setblock 503 200 464 minecraft:terracotta
setblock 503 200 504 minecraft:terracotta
fill 504 200 464 504 202 464 minecraft:red_terracotta
fill 504 200 504 504 203 504 minecraft:red_terracotta
setblock 508 200 504 minecraft:terracotta
fill 509 200 504 509 203 504 minecraft:red_terracotta
setblock 510 200 497 minecraft:terracotta
fill 510 200 498 510 203 498 minecraft:red_terracotta
setblock 510 200 502 minecraft:terracotta
fill 510 200 503 510 203 503 minecraft:red_terracotta
setblock 511 200 476 minecraft:terracotta
fill 511 200 477 511 201 477 minecraft:red_terracotta
setblock 511 200 496 minecraft:terracotta
fill 511 200 497 511 203 497 minecraft:red_terracotta
setblock 511 200 501 minecraft:terracotta
fill 511 200 502 511 203 502 minecraft:red_terracotta
fill 471 201 476 471 202 476 minecraft:red_terracotta
setblock 471 201 480 minecraft:terracotta
fill 471 201 481 471 203 482 minecraft:red_terracotta
fill 471 201 491 471 204 491 minecraft:red_terracotta
setblock 471 201 495 minecraft:terracotta
fill 471 201 496 471 204 496 minecraft:red_terracotta
setblock 471 201 500 minecraft:terracotta
fill 471 201 501 471 202 503 minecraft:red_terracotta
setblock 472 201 494 minecraft:terracotta
fill 472 201 495 472 204 495 minecraft:red_terracotta
setblock 472 201 499 minecraft:terracotta
fill 472 201 500 472 204 500 minecraft:red_terracotta
fill 472 201 502 472 201 503 minecraft:red_terracotta
setblock 472 201 504 minecraft:terracotta
setblock 473 201 498 minecraft:terracotta
fill 473 201 499 473 204 499 minecraft:red_terracotta
setblock 473 201 502 minecraft:red_terracotta
setblock 473 201 503 minecraft:terracotta
fill 473 201 504 473 204 504 minecraft:red_terracotta
setblock 474 201 498 minecraft:red_terracotta
setblock 474 201 502 minecraft:terracotta
fill 474 201 503 474 204 503 minecraft:red_terracotta
fill 475 201 502 475 204 502 minecraft:red_terracotta
setblock 477 201 504 minecraft:terracotta
setblock 478 201 503 minecraft:terracotta
fill 478 201 504 478 204 504 minecraft:red_terracotta
fill 479 201 503 479 203 503 minecraft:red_terracotta
fill 493 201 464 493 204 464 minecraft:red_terracotta
fill 493 201 504 496 201 504 minecraft:red_terracotta
fill 495 201 503 497 201 503 minecraft:red_terracotta
setblock 496 201 464 minecraft:red_terracotta
setblock 496 201 465 minecraft:terracotta
setblock 497 201 464 minecraft:terracotta
fill 497 201 465 497 204 465 minecraft:red_terracotta
setblock 497 201 504 minecraft:terracotta
fill 498 201 464 498 204 464 minecraft:red_terracotta
setblock 498 201 503 minecraft:terracotta
fill 498 201 504 498 204 504 minecraft:red_terracotta
fill 499 201 503 499 204 503 minecraft:red_terracotta
setblock 501 201 465 minecraft:terracotta
setblock 502 201 464 minecraft:terracotta
setblock 502 201 504 minecraft:terracotta
fill 503 201 464 503 204 464 minecraft:red_terracotta
setblock 503 201 503 minecraft:terracotta
fill 503 201 504 503 204 504 minecraft:red_terracotta
setblock 507 201 504 minecraft:terracotta
fill 508 201 504 508 204 504 minecraft:red_terracotta
setblock 510 201 500 minecraft:red_terracotta
setblock 510 201 501 minecraft:terracotta
fill 510 201 502 510 204 502 minecraft:red_terracotta
setblock 511 201 476 minecraft:red_terracotta
setblock 511 201 495 minecraft:terracotta
fill 511 201 496 511 204 496 minecraft:red_terracotta
setblock 511 201 500 minecraft:terracotta
fill 511 201 501 511 204 501 minecraft:red_terracotta
setblock 471 202 478 minecraft:red_terracotta
setblock 471 202 479 minecraft:terracotta
fill 471 202 480 471 205 480 minecraft:red_terracotta
setblock 471 202 483 minecraft:red_terracotta
setblock 471 202 484 minecraft:terracotta
setblock 471 202 494 minecraft:terracotta
fill 471 202 495 471 205 495 minecraft:red_terracotta
setblock 471 202 499 minecraft:terracotta
fill 471 202 500 471 205 500 minecraft:red_terracotta
setblock 471 202 504 minecraft:terracotta
setblock 472 202 493 minecraft:terracotta
fill 472 202 494 472 205 494 minecraft:red_terracotta
setblock 472 202 498 minecraft:terracotta
fill 472 202 499 472 205 499 minecraft:red_terracotta
setblock 472 202 502 minecraft:red_terracotta
setblock 472 202 503 minecraft:terracotta
fill 472 202 504 472 205 504 minecraft:red_terracotta
setblock 473 202 497 minecraft:terracotta
fill 473 202 498 473 205 498 minecraft:red_terracotta
setblock 473 202 502 minecraft:terracotta
fill 473 202 503 473 205 503 minecraft:red_terracotta
fill 474 202 502 474 205 502 minecraft:red_terracotta
setblock 476 202 504 minecraft:terracotta
setblock 477 202 503 minecraft:terracotta
fill 477 202 504 477 205 504 minecraft:red_terracotta
setblock 478 202 502 minecraft:terracotta
fill 478 202 503 478 205 503 minecraft:red_terracotta
setblock 481 202 504 minecraft:terracotta
fill 493 202 504 495 202 504 minecraft:red_terracotta
setblock 495 202 465 minecraft:terracotta
fill 495 202 503 496 202 503 minecraft:red_terracotta
setblock 496 202 464 minecraft:terracotta
fill 496 202 465 496 205 465 minecraft:red_terracotta
setblock 496 202 504 minecraft:terracotta
fill 497 202 464 497 205 464 minecraft:red_terracotta
setblock 497 202 503 minecraft:terracotta
fill 497 202 504 497 205 504 minecraft:red_terracotta
fill 498 202 503 498 205 503 minecraft:red_terracotta
setblock 500 202 465 minecraft:terracotta
setblock 501 202 464 minecraft:terracotta
setblock 501 202 504 minecraft:terracotta
fill 502 202 464 502 205 464 minecraft:red_terracotta
setblock 502 202 503 minecraft:terracotta
fill 502 202 504 502 205 504 minecraft:red_terracotta
setblock 506 202 504 minecraft:terracotta
fill 507 202 504 507 205 504 minecraft:red_terracotta
fill 509 202 503 509 204 503 minecraft:red_terracotta
setblock 510 202 500 minecraft:terracotta
fill 510 202 501 510 205 501 minecraft:red_terracotta
fill 511 202 495 511 205 495 minecraft:red_terracotta
setblock 511 202 499 minecraft:terracotta
fill 511 202 500 511 205 500 minecraft:red_terracotta
setblock 511 202 504 minecraft:terracotta
setblock 471 203 478 minecraft:terracotta
fill 471 203 479 472 205 479 minecraft:red_terracotta
setblock 471 203 483 minecraft:terracotta
fill 471 203 484 471 204 486 minecraft:red_terracotta
setblock 471 203 493 minecraft:terracotta
fill 471 203 494 471 206 494 minecraft:red_terracotta
setblock 471 203 498 minecraft:terracotta
fill 471 203 499 471 206 499 minecraft:red_terracotta
fill 471 203 501 471 203 502 minecraft:red_terracotta
setblock 471 203 503 minecraft:terracotta
fill 471 203 504 471 206 504 minecraft:red_terracotta
fill 472 203 480 472 203 481 minecraft:red_terracotta
setblock 472 203 482 minecraft:terracotta
fill 472 203 483 472 206 483 minecraft:red_terracotta
setblock 472 203 497 minecraft:terracotta
fill 472 203 498 472 206 498 minecraft:red_terracotta
setblock 472 203 502 minecraft:terracotta
fill 472 203 503 472 206 503 minecraft:red_terracotta
setblock 473 203 496 minecraft:terracotta
fill 473 203 497 473 204 497 minecraft:red_terracotta
setblock 473 203 501 minecraft:terracotta
fill 473 203 502 473 206 502 minecraft:red_terracotta
setblock 475 203 504 minecraft:terracotta
setblock 476 203 503 minecraft:terracotta
fill 476 203 504 476 206 504 minecraft:red_terracotta
setblock 477 203 502 minecraft:terracotta
fill 477 203 503 477 206 503 minecraft:red_terracotta
setblock 480 203 504 minecraft:terracotta
fill 492 203 464 492 205 464 minecraft:red_terracotta
fill 492 203 504 494 203 504 minecraft:red_terracotta
fill 494 203 503 495 203 503 minecraft:red_terracotta
setblock 495 203 464 minecraft:terracotta
fill 495 203 465 495 206 465 minecraft:red_terracotta
setblock 495 203 504 minecraft:terracotta
fill 496 203 464 496 206 464 minecraft:red_terracotta
setblock 496 203 503 minecraft:terracotta
fill 496 203 504 496 206 504 minecraft:red_terracotta
fill 497 203 503 497 206 503 minecraft:red_terracotta
setblock 499 203 465 minecraft:terracotta
setblock 500 203 464 minecraft:terracotta
setblock 500 203 504 minecraft:terracotta
fill 501 203 464 501 206 464 minecraft:red_terracotta
setblock 501 203 503 minecraft:terracotta
fill 501 203 504 501 206 504 minecraft:red_terracotta
fill 502 203 503 502 206 503 minecraft:red_terracotta
setblock 505 203 504 minecraft:terracotta
fill 506 203 504 506 206 504 minecraft:red_terracotta
setblock 510 203 499 minecraft:terracotta
fill 510 203 500 510 206 500 minecraft:red_terracotta
setblock 510 203 504 minecraft:terracotta
fill 511 203 464 511 206 464 minecraft:red_terracotta
setblock 511 203 498 minecraft:terracotta
fill 511 203 499 511 206 499 minecraft:red_terracotta
setblock 511 203 503 minecraft:terracotta
fill 511 203 504 511 206 504 minecraft:red_terracotta
setblock 471 204 477 minecraft:terracotta
fill 471 204 478 472 206 478 minecraft:red_terracotta
setblock 471 204 481 minecraft:red_terracotta
setblock 471 204 482 minecraft:terracotta
fill 471 204 483 471 207 483 minecraft:red_terracotta
setblock 471 204 487 minecraft:terracotta
fill 471 204 488 471 205 490 minecraft:red_terracotta
setblock 471 204 492 minecraft:terracotta
fill 471 204 493 471 207 493 minecraft:red_terracotta
setblock 471 204 497 minecraft:terracotta
fill 471 204 498 471 207 498 minecraft:red_terracotta
setblock 471 204 501 minecraft:red_terracotta
setblock 471 204 502 minecraft:terracotta
fill 471 204 503 471 207 503 minecraft:red_terracotta
setblock 472 204 480 minecraft:red_terracotta
setblock 472 204 481 minecraft:terracotta
fill 472 204 482 472 207 482 minecraft:red_terracotta
fill 472 204 484 472 204 485 minecraft:red_terracotta
setblock 472 204 496 minecraft:terracotta
fill 472 204 497 472 207 497 minecraft:red_terracotta
setblock 472 204 501 minecraft:terracotta
fill 472 204 502 472 207 502 minecraft:red_terracotta
setblock 473 204 500 minecraft:terracotta
fill 473 204 501 473 207 501 minecraft:red_terracotta
setblock 474 204 504 minecraft:terracotta
setblock 475 204 503 minecraft:terracotta
fill 475 204 504 475 207 504 minecraft:red_terracotta
setblock 476 204 502 minecraft:terracotta
fill 476 204 503 476 207 503 minecraft:red_terracotta
setblock 479 204 504 minecraft:terracotta
fill 480 204 504 480 207 504 minecraft:red_terracotta
fill 491 204 464 491 206 464 minecraft:red_terracotta
fill 491 204 504 493 204 504 minecraft:red_terracotta
fill 493 204 494 493 205 494 minecraft:orange_concrete
fill 493 204 503 494 204 503 minecraft:red_terracotta
setblock 494 204 464 minecraft:terracotta
fill 494 204 465 494 207 465 minecraft:red_terracotta
setblock 494 204 504 minecraft:terracotta
fill 495 204 464 495 207 464 minecraft:red_terracotta
setblock 495 204 503 minecraft:terracotta
fill 495 204 504 495 207 504 minecraft:red_terracotta
fill 496 204 503 496 207 503 minecraft:red_terracotta
setblock 498 204 465 minecraft:terracotta
setblock 499 204 464 minecraft:terracotta
fill 499 204 465 499 207 465 minecraft:red_terracotta
setblock 499 204 504 minecraft:terracotta
fill 500 204 464 500 207 464 minecraft:red_terracotta
setblock 500 204 503 minecraft:terracotta
fill 500 204 504 500 207 504 minecraft:red_terracotta
fill 501 204 503 501 207 503 minecraft:red_terracotta
setblock 504 204 464 minecraft:terracotta
setblock 504 204 504 minecraft:terracotta
fill 505 204 504 505 207 504 minecraft:red_terracotta
fill 508 204 503 508 205 503 minecraft:red_terracotta
setblock 509 204 504 minecraft:terracotta
fill 510 204 464 510 207 464 minecraft:red_terracotta
setblock 510 204 498 minecraft:terracotta
fill 510 204 499 510 207 499 minecraft:red_terracotta
setblock 510 204 503 minecraft:terracotta
fill 510 204 504 510 207 504 minecraft:red_terracotta
fill 511 204 479 511 204 481 minecraft:red_terracotta
setblock 511 204 497 minecraft:terracotta
fill 511 204 498 511 207 498 minecraft:red_terracotta
setblock 511 204 502 minecraft:terracotta
fill 511 204 503 511 207 503 minecraft:red_terracotta
setblock 471 205 476 minecraft:terracotta
fill 471 205 477 471 208 477 minecraft:red_terracotta
setblock 471 205 481 minecraft:terracotta
fill 471 205 482 471 208 482 minecraft:red_terracotta
fill 471 205 484 471 205 485 minecraft:red_terracotta
setblock 471 205 486 minecraft:terracotta
fill 471 205 487 472 207 487 minecraft:red_terracotta
setblock 471 205 491 minecraft:terracotta
fill 471 205 492 471 208 492 minecraft:red_terracotta
setblock 471 205 496 minecraft:terracotta
fill 471 205 497 471 208 497 minecraft:red_terracotta
setblock 471 205 501 minecraft:terracotta
fill 471 205 502 471 208 502 minecraft:red_terracotta
setblock 472 205 464 minecraft:red_terracotta
setblock 472 205 480 minecraft:terracotta
fill 472 205 481 473 207 481 minecraft:red_terracotta
setblock 472 205 484 minecraft:red_terracotta
setblock 472 205 485 minecraft:terracotta
fill 472 205 486 472 208 486 minecraft:red_terracotta
fill 472 205 488 472 206 488 minecraft:red_terracotta
setblock 472 205 495 minecraft:terracotta
fill 472 205 496 472 208 496 minecraft:red_terracotta
setblock 472 205 500 minecraft:terracotta
fill 472 205 501 472 208 501 minecraft:red_terracotta
setblock 473 205 464 minecraft:terracotta
setblock 473 205 466 minecraft:light[level=14]
setblock 473 205 474 minecraft:light[level=14]
fill 473 205 480 473 208 480 minecraft:red_terracotta
fill 473 205 482 473 205 483 minecraft:red_terracotta
setblock 473 205 484 minecraft:terracotta
setblock 473 205 490 minecraft:light[level=14]
setblock 473 205 499 minecraft:terracotta
fill 473 205 500 473 208 500 minecraft:red_terracotta
setblock 473 205 504 minecraft:terracotta
fill 474 205 464 476 206 464 minecraft:red_terracotta
setblock 474 205 503 minecraft:terracotta
fill 474 205 504 474 208 504 minecraft:red_terracotta
setblock 475 205 502 minecraft:terracotta
fill 475 205 503 475 208 503 minecraft:red_terracotta
fill 476 205 502 476 206 502 minecraft:red_terracotta
setblock 478 205 504 minecraft:terracotta
fill 479 205 504 479 208 504 minecraft:red_terracotta
setblock 481 205 466 minecraft:light[level=14]
setblock 481 205 474 minecraft:light[level=14]
setblock 481 205 482 minecraft:light[level=14]
setblock 481 205 490 minecraft:light[level=14]
setblock 481 205 498 minecraft:light[level=14]
setblock 489 205 466 minecraft:light[level=14]
setblock 489 205 474 minecraft:light[level=14]
setblock 489 205 482 minecraft:light[level=14]
setblock 489 205 490 minecraft:light[level=14]
setblock 489 205 498 minecraft:light[level=14]
fill 490 205 464 490 207 464 minecraft:red_terracotta
fill 490 205 504 492 205 504 minecraft:red_terracotta
setblock 492 205 465 minecraft:terracotta
setblock 493 205 464 minecraft:terracotta
fill 493 205 465 493 208 465 minecraft:red_terracotta
setblock 493 205 503 minecraft:red_terracotta
setblock 493 205 504 minecraft:terracotta
fill 494 205 464 494 208 464 minecraft:red_terracotta
setblock 494 205 503 minecraft:terracotta
fill 494 205 504 494 208 504 minecraft:red_terracotta
fill 495 205 503 495 208 503 minecraft:red_terracotta
setblock 497 205 465 minecraft:terracotta
setblock 497 205 466 minecraft:light[level=14]
setblock 497 205 474 minecraft:light[level=14]
setblock 497 205 482 minecraft:light[level=14]
setblock 497 205 490 minecraft:light[level=14]
setblock 497 205 498 minecraft:light[level=14]
setblock 498 205 464 minecraft:terracotta
fill 498 205 465 498 208 465 minecraft:red_terracotta
setblock 498 205 504 minecraft:terracotta
fill 499 205 464 499 208 464 minecraft:red_terracotta
setblock 499 205 503 minecraft:terracotta
fill 499 205 504 499 208 504 minecraft:red_terracotta
fill 500 205 465 500 206 465 minecraft:red_terracotta
fill 500 205 503 500 208 503 minecraft:red_terracotta
setblock 503 205 464 minecraft:terracotta
setblock 503 205 504 minecraft:terracotta
fill 504 205 464 507 205 464 minecraft:red_terracotta
fill 504 205 504 504 208 504 minecraft:red_terracotta
setblock 505 205 466 minecraft:light[level=14]
setblock 505 205 474 minecraft:light[level=14]
setblock 505 205 482 minecraft:light[level=14]
setblock 505 205 490 minecraft:light[level=14]
setblock 505 205 498 minecraft:light[level=14]
fill 506 205 503 507 206 503 minecraft:red_terracotta
setblock 508 205 464 minecraft:terracotta
setblock 508 205 504 minecraft:terracotta
fill 509 205 464 509 208 464 minecraft:red_terracotta
setblock 509 205 503 minecraft:terracotta
fill 509 205 504 509 208 504 minecraft:red_terracotta
fill 510 205 498 510 208 498 minecraft:red_terracotta
setblock 510 205 502 minecraft:terracotta
fill 510 205 503 510 208 503 minecraft:red_terracotta
setblock 511 205 465 minecraft:red_terracotta
fill 511 205 478 511 205 480 minecraft:red_terracotta
setblock 511 205 481 minecraft:terracotta
fill 511 205 482 511 206 484 minecraft:red_terracotta
fill 511 205 494 511 206 494 minecraft:red_terracotta
setblock 511 205 496 minecraft:terracotta
fill 511 205 497 511 208 497 minecraft:red_terracotta
setblock 511 205 501 minecraft:terracotta
fill 511 205 502 511 208 502 minecraft:red_terracotta
setblock 471 206 464 minecraft:red_terracotta
fill 471 206 476 471 209 476 minecraft:red_terracotta
setblock 471 206 479 minecraft:red_terracotta
setblock 471 206 480 minecraft:terracotta
fill 471 206 481 471 209 481 minecraft:red_terracotta
setblock 471 206 484 minecraft:red_terracotta
setblock 471 206 485 minecraft:terracotta
fill 471 206 486 471 209 486 minecraft:red_terracotta
fill 471 206 488 471 206 489 minecraft:red_terracotta
setblock 471 206 490 minecraft:terracotta
fill 471 206 491 472 208 491 minecraft:red_terracotta
setblock 471 206 495 minecraft:terracotta
fill 471 206 496 471 209 496 minecraft:red_terracotta
setblock 471 206 500 minecraft:terracotta
fill 471 206 501 471 209 501 minecraft:red_terracotta
setblock 472 206 464 minecraft:terracotta
setblock 472 206 479 minecraft:terracotta
fill 472 206 480 472 209 480 minecraft:red_terracotta
setblock 472 206 484 minecraft:terracotta
fill 472 206 485 473 208 485 minecraft:red_terracotta
setblock 472 206 489 minecraft:terracotta
fill 472 206 490 472 209 490 minecraft:red_terracotta
fill 472 206 492 472 206 493 minecraft:red_terracotta
setblock 472 206 494 minecraft:terracotta
fill 472 206 495 472 209 495 minecraft:red_terracotta
setblock 472 206 499 minecraft:terracotta
fill 472 206 500 472 209 500 minecraft:red_terracotta
setblock 472 206 504 minecraft:terracotta
fill 473 206 464 473 209 464 minecraft:red_terracotta
fill 473 206 479 473 209 479 minecraft:red_terracotta
setblock 473 206 482 minecraft:red_terracotta
setblock 473 206 483 minecraft:terracotta
fill 473 206 484 473 209 484 minecraft:red_terracotta
fill 473 206 486 473 206 487 minecraft:red_terracotta
setblock 473 206 498 minecraft:terracotta
fill 473 206 499 473 209 499 minecraft:red_terracotta
setblock 473 206 503 minecraft:terracotta
fill 473 206 504 473 209 504 minecraft:red_terracotta
setblock 474 206 502 minecraft:terracotta
fill 474 206 503 474 209 503 minecraft:red_terracotta
fill 475 206 502 475 209 502 minecraft:red_terracotta
setblock 477 206 464 minecraft:terracotta
setblock 477 206 504 minecraft:terracotta
setblock 478 206 503 minecraft:terracotta
fill 478 206 504 478 209 504 minecraft:red_terracotta
fill 488 206 464 489 208 464 minecraft:red_terracotta
fill 489 206 504 491 206 504 minecraft:red_terracotta
setblock 491 206 465 minecraft:terracotta
setblock 492 206 464 minecraft:terracotta
fill 492 206 465 492 209 465 minecraft:red_terracotta
setblock 492 206 503 minecraft:red_terracotta
setblock 492 206 504 minecraft:terracotta
fill 493 206 464 493 209 464 minecraft:red_terracotta
setblock 493 206 503 minecraft:terracotta
fill 493 206 504 493 209 504 minecraft:red_terracotta
fill 494 206 503 494 209 503 minecraft:red_terracotta
setblock 495 206 466 minecraft:terracotta
setblock 496 206 465 minecraft:terracotta
setblock 497 206 464 minecraft:terracotta
fill 497 206 465 497 209 465 minecraft:red_terracotta
setblock 497 206 504 minecraft:terracotta
fill 498 206 464 498 209 464 minecraft:red_terracotta
setblock 498 206 503 minecraft:terracotta
fill 498 206 504 498 209 504 minecraft:red_terracotta
fill 499 206 503 499 209 503 minecraft:red_terracotta
setblock 502 206 464 minecraft:terracotta
setblock 502 206 504 minecraft:terracotta
fill 503 206 464 506 206 464 minecraft:red_terracotta
setblock 503 206 503 minecraft:terracotta
fill 503 206 504 503 209 504 minecraft:red_terracotta
fill 504 206 503 505 208 503 minecraft:red_terracotta
setblock 507 206 464 minecraft:terracotta
setblock 507 206 504 minecraft:terracotta
fill 508 206 464 508 209 464 minecraft:red_terracotta
setblock 508 206 503 minecraft:terracotta
fill 508 206 504 508 209 504 minecraft:red_terracotta
setblock 509 206 502 minecraft:terracotta
fill 509 206 503 509 209 503 minecraft:red_terracotta
setblock 510 206 501 minecraft:terracotta
fill 510 206 502 510 209 502 minecraft:red_terracotta
setblock 511 206 465 minecraft:terracotta
fill 511 206 466 511 209 466 minecraft:red_terracotta
fill 511 206 478 511 206 479 minecraft:red_terracotta
setblock 511 206 480 minecraft:terracotta
fill 511 206 481 511 209 481 minecraft:red_terracotta
setblock 511 206 485 minecraft:terracotta
fill 511 206 486 511 207 488 minecraft:red_terracotta
fill 511 206 493 511 207 493 minecraft:red_terracotta
setblock 511 206 495 minecraft:terracotta
fill 511 206 496 511 209 496 minecraft:red_terracotta
setblock 511 206 500 minecraft:terracotta
fill 511 206 501 511 209 501 minecraft:red_terracotta
setblock 471 207 464 minecraft:terracotta
fill 471 207 465 471 209 466 minecraft:red_terracotta
setblock 471 207 478 minecraft:red_terracotta
setblock 471 207 479 minecraft:terracotta
fill 471 207 480 471 210 480 minecraft:red_terracotta
setblock 471 207 484 minecraft:terracotta
fill 471 207 485 471 210 485 minecraft:red_terracotta
setblock 471 207 488 minecraft:red_terracotta
setblock 471 207 489 minecraft:terracotta
fill 471 207 490 471 210 490 minecraft:red_terracotta
setblock 471 207 494 minecraft:terracotta
fill 471 207 495 471 210 495 minecraft:red_terracotta
setblock 471 207 499 minecraft:terracotta
fill 471 207 500 471 210 500 minecraft:red_terracotta
setblock 471 207 504 minecraft:terracotta
fill 472 207 464 472 210 464 minecraft:red_terracotta
setblock 472 207 477 minecraft:red_terracotta
setblock 472 207 478 minecraft:terracotta
fill 472 207 479 472 210 479 minecraft:red_terracotta
setblock 472 207 483 minecraft:terracotta
fill 472 207 484 472 210 484 minecraft:red_terracotta
setblock 472 207 488 minecraft:terracotta
fill 472 207 489 473 209 489 minecraft:red_terracotta
setblock 472 207 492 minecraft:red_terracotta
setblock 472 207 493 minecraft:terracotta
fill 472 207 494 472 210 494 minecraft:red_terracotta
setblock 472 207 498 minecraft:terracotta
fill 472 207 499 472 210 499 minecraft:red_terracotta
setblock 472 207 503 minecraft:terracotta
fill 472 207 504 472 210 504 minecraft:red_terracotta
setblock 473 207 482 minecraft:terracotta
fill 473 207 483 474 209 483 minecraft:red_terracotta
setblock 473 207 486 minecraft:red_terracotta
setblock 473 207 487 minecraft:terracotta
fill 473 207 488 473 210 488 minecraft:red_terracotta
fill 473 207 498 473 208 498 minecraft:red_terracotta
setblock 473 207 502 minecraft:terracotta
fill 473 207 503 473 210 503 minecraft:red_terracotta
fill 474 207 464 475 207 464 minecraft:red_terracotta
setblock 474 207 481 minecraft:terracotta
fill 474 207 482 474 210 482 minecraft:red_terracotta
fill 474 207 484 474 207 485 minecraft:red_terracotta
schedule function dropper:buildpart/118_7 1t
