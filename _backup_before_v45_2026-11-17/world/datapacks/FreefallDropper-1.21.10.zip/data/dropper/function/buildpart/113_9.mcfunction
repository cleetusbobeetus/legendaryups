setblock 272 271 504 minecraft:bone_block
fill 273 271 464 273 273 464 minecraft:brown_terracotta
setblock 273 271 468 minecraft:bone_block
fill 273 271 469 273 272 469 minecraft:brown_terracotta
setblock 273 271 473 minecraft:bone_block
fill 273 271 474 273 273 474 minecraft:brown_terracotta
fill 273 271 504 273 273 504 minecraft:brown_terracotta
setblock 274 271 467 minecraft:bone_block
fill 274 271 468 274 273 468 minecraft:brown_terracotta
setblock 274 271 472 minecraft:bone_block
fill 274 271 473 274 273 473 minecraft:brown_terracotta
setblock 274 271 477 minecraft:bone_block
fill 274 271 478 274 273 478 minecraft:brown_terracotta
setblock 274 271 480 minecraft:brown_terracotta
setblock 274 271 496 minecraft:brown_terracotta
setblock 274 271 497 minecraft:bone_block
fill 274 271 498 275 272 498 minecraft:brown_terracotta
fill 274 271 503 274 273 503 minecraft:brown_terracotta
setblock 275 271 466 minecraft:bone_block
fill 275 271 467 275 273 467 minecraft:brown_terracotta
setblock 275 271 471 minecraft:bone_block
fill 275 271 472 275 273 472 minecraft:brown_terracotta
setblock 275 271 476 minecraft:bone_block
fill 275 271 477 275 273 477 minecraft:brown_terracotta
setblock 275 271 481 minecraft:bone_block
setblock 275 271 482 minecraft:brown_terracotta
setblock 275 271 491 minecraft:bone_block
fill 275 271 492 275 272 492 minecraft:brown_terracotta
setblock 275 271 496 minecraft:bone_block
fill 275 271 497 275 273 497 minecraft:brown_terracotta
fill 275 271 499 275 271 500 minecraft:brown_terracotta
setblock 275 271 501 minecraft:bone_block
fill 275 271 502 275 273 502 minecraft:brown_terracotta
setblock 276 271 465 minecraft:bone_block
fill 276 271 466 276 273 466 minecraft:brown_terracotta
setblock 276 271 470 minecraft:bone_block
fill 276 271 471 276 273 471 minecraft:brown_terracotta
setblock 276 271 475 minecraft:bone_block
fill 276 271 476 276 273 476 minecraft:brown_terracotta
setblock 276 271 480 minecraft:bone_block
fill 276 271 481 276 273 481 minecraft:brown_terracotta
setblock 276 271 485 minecraft:bone_block
setblock 276 271 486 minecraft:brown_terracotta
setblock 276 271 490 minecraft:bone_block
fill 276 271 491 276 273 491 minecraft:brown_terracotta
setblock 276 271 495 minecraft:bone_block
fill 276 271 496 276 273 496 minecraft:brown_terracotta
setblock 276 271 499 minecraft:brown_terracotta
setblock 276 271 500 minecraft:bone_block
fill 276 271 501 276 273 501 minecraft:brown_terracotta
setblock 236 272 464 minecraft:bone_block
fill 236 272 465 236 273 465 minecraft:brown_terracotta
setblock 236 272 469 minecraft:bone_block
fill 236 272 470 236 273 470 minecraft:brown_terracotta
setblock 236 272 474 minecraft:bone_block
fill 236 272 475 236 273 475 minecraft:brown_terracotta
setblock 236 272 478 minecraft:brown_terracotta
setblock 236 272 479 minecraft:bone_block
fill 236 272 480 236 273 480 minecraft:brown_terracotta
setblock 236 272 489 minecraft:bone_block
fill 236 272 490 236 272 493 minecraft:brown_terracotta
setblock 236 272 494 minecraft:bone_block
fill 236 272 495 236 273 495 minecraft:brown_terracotta
setblock 236 272 499 minecraft:bone_block
fill 236 272 500 236 273 500 minecraft:brown_terracotta
setblock 236 272 503 minecraft:brown_terracotta
setblock 236 272 504 minecraft:bone_block
fill 237 272 464 237 273 464 minecraft:brown_terracotta
setblock 237 272 468 minecraft:bone_block
setblock 237 272 469 minecraft:brown_terracotta
setblock 237 272 473 minecraft:bone_block
fill 237 272 474 237 273 474 minecraft:brown_terracotta
setblock 237 272 493 minecraft:bone_block
fill 237 272 494 237 273 494 minecraft:brown_terracotta
setblock 237 272 498 minecraft:bone_block
fill 237 272 499 237 273 499 minecraft:brown_terracotta
setblock 237 272 503 minecraft:bone_block
fill 237 272 504 237 273 504 minecraft:brown_terracotta
setblock 238 272 497 minecraft:bone_block
fill 238 272 498 238 273 498 minecraft:brown_terracotta
fill 238 272 503 238 273 503 minecraft:brown_terracotta
setblock 241 272 504 minecraft:bone_block
setblock 242 272 504 minecraft:brown_terracotta
fill 246 272 497 250 273 501 minecraft:soul_soil
setblock 246 272 504 minecraft:bone_block
fill 247 272 504 247 273 504 minecraft:brown_terracotta
fill 248 272 502 248 272 503 minecraft:soul_soil
fill 250 272 503 251 272 503 minecraft:brown_terracotta
setblock 251 272 504 minecraft:bone_block
setblock 252 272 503 minecraft:bone_block
fill 252 272 504 252 273 504 minecraft:brown_terracotta
fill 253 272 503 253 273 503 minecraft:brown_terracotta
setblock 256 272 504 minecraft:bone_block
setblock 271 272 464 minecraft:bone_block
fill 271 272 465 271 273 465 minecraft:brown_terracotta
setblock 271 272 504 minecraft:bone_block
fill 272 272 464 272 273 464 minecraft:brown_terracotta
fill 272 272 504 272 273 504 minecraft:brown_terracotta
setblock 273 272 472 minecraft:bone_block
fill 273 272 473 273 273 473 minecraft:brown_terracotta
setblock 273 272 477 minecraft:bone_block
fill 273 272 503 273 273 503 minecraft:brown_terracotta
setblock 274 272 466 minecraft:bone_block
fill 274 272 467 274 273 467 minecraft:brown_terracotta
setblock 274 272 471 minecraft:bone_block
fill 274 272 472 274 273 472 minecraft:brown_terracotta
setblock 274 272 476 minecraft:bone_block
fill 274 272 477 274 273 477 minecraft:brown_terracotta
setblock 274 272 496 minecraft:bone_block
setblock 274 272 497 minecraft:brown_terracotta
setblock 275 272 465 minecraft:bone_block
fill 275 272 466 275 273 466 minecraft:brown_terracotta
setblock 275 272 470 minecraft:bone_block
fill 275 272 471 275 273 471 minecraft:brown_terracotta
setblock 275 272 475 minecraft:bone_block
fill 275 272 476 275 273 476 minecraft:brown_terracotta
setblock 275 272 480 minecraft:bone_block
fill 275 272 481 275 273 481 minecraft:brown_terracotta
setblock 275 272 495 minecraft:bone_block
fill 275 272 496 275 273 496 minecraft:brown_terracotta
setblock 275 272 499 minecraft:brown_terracotta
setblock 275 272 500 minecraft:bone_block
fill 275 272 501 275 273 501 minecraft:brown_terracotta
setblock 276 272 464 minecraft:bone_block
fill 276 272 465 276 273 465 minecraft:brown_terracotta
setblock 276 272 469 minecraft:bone_block
fill 276 272 470 276 273 470 minecraft:brown_terracotta
setblock 276 272 474 minecraft:bone_block
fill 276 272 475 276 273 475 minecraft:brown_terracotta
setblock 276 272 479 minecraft:bone_block
fill 276 272 480 276 273 480 minecraft:brown_terracotta
setblock 276 272 489 minecraft:bone_block
setblock 276 272 490 minecraft:brown_terracotta
setblock 276 272 494 minecraft:bone_block
fill 276 272 495 276 273 495 minecraft:brown_terracotta
setblock 276 272 499 minecraft:bone_block
fill 276 272 500 276 273 500 minecraft:brown_terracotta
setblock 276 272 504 minecraft:bone_block
setblock 236 273 464 minecraft:brown_terracotta
setblock 236 273 468 minecraft:bone_block
setblock 236 273 469 minecraft:brown_terracotta
setblock 236 273 473 minecraft:bone_block
setblock 236 273 474 minecraft:brown_terracotta
setblock 236 273 478 minecraft:bone_block
setblock 236 273 479 minecraft:brown_terracotta
fill 236 273 490 236 273 492 minecraft:brown_terracotta
setblock 236 273 493 minecraft:bone_block
setblock 236 273 494 minecraft:brown_terracotta
setblock 236 273 498 minecraft:bone_block
setblock 236 273 499 minecraft:brown_terracotta
setblock 236 273 503 minecraft:bone_block
setblock 236 273 504 minecraft:brown_terracotta
setblock 237 273 472 minecraft:bone_block
setblock 237 273 473 minecraft:brown_terracotta
setblock 237 273 492 minecraft:bone_block
setblock 237 273 493 minecraft:brown_terracotta
setblock 237 273 497 minecraft:bone_block
setblock 237 273 498 minecraft:brown_terracotta
setblock 237 273 502 minecraft:bone_block
setblock 237 273 503 minecraft:brown_terracotta
setblock 238 273 496 minecraft:bone_block
setblock 238 273 497 minecraft:brown_terracotta
setblock 240 273 504 minecraft:bone_block
setblock 241 273 504 minecraft:brown_terracotta
setblock 246 273 504 minecraft:brown_terracotta
fill 249 273 503 250 273 503 minecraft:brown_terracotta
setblock 250 273 504 minecraft:bone_block
setblock 251 273 503 minecraft:bone_block
setblock 251 273 504 minecraft:brown_terracotta
setblock 252 273 503 minecraft:brown_terracotta
setblock 255 273 504 minecraft:bone_block
setblock 270 273 464 minecraft:bone_block
setblock 270 273 504 minecraft:bone_block
setblock 271 273 464 minecraft:brown_terracotta
setblock 271 273 504 minecraft:brown_terracotta
setblock 272 273 503 minecraft:brown_terracotta
setblock 273 273 471 minecraft:bone_block
setblock 273 273 472 minecraft:brown_terracotta
setblock 273 273 476 minecraft:bone_block
setblock 273 273 477 minecraft:brown_terracotta
setblock 274 273 465 minecraft:bone_block
setblock 274 273 470 minecraft:bone_block
setblock 274 273 471 minecraft:brown_terracotta
setblock 274 273 475 minecraft:bone_block
setblock 274 273 476 minecraft:brown_terracotta
setblock 275 273 464 minecraft:bone_block
setblock 275 273 465 minecraft:brown_terracotta
setblock 275 273 469 minecraft:bone_block
setblock 275 273 470 minecraft:brown_terracotta
setblock 275 273 474 minecraft:bone_block
setblock 275 273 475 minecraft:brown_terracotta
setblock 275 273 479 minecraft:bone_block
setblock 275 273 480 minecraft:brown_terracotta
setblock 275 273 494 minecraft:bone_block
setblock 275 273 495 minecraft:brown_terracotta
setblock 275 273 498 minecraft:brown_terracotta
setblock 275 273 499 minecraft:bone_block
setblock 275 273 500 minecraft:brown_terracotta
setblock 275 273 504 minecraft:bone_block
setblock 276 273 464 minecraft:brown_terracotta
setblock 276 273 468 minecraft:bone_block
setblock 276 273 469 minecraft:brown_terracotta
setblock 276 273 473 minecraft:bone_block
setblock 276 273 474 minecraft:brown_terracotta
setblock 276 273 478 minecraft:bone_block
setblock 276 273 479 minecraft:brown_terracotta
setblock 276 273 493 minecraft:bone_block
setblock 276 273 494 minecraft:brown_terracotta
setblock 276 273 498 minecraft:bone_block
setblock 276 273 499 minecraft:brown_terracotta
setblock 276 273 503 minecraft:bone_block
setblock 276 273 504 minecraft:brown_terracotta
setblock 238 275 466 minecraft:light[level=12]
setblock 238 275 474 minecraft:light[level=12]
setblock 238 275 482 minecraft:light[level=12]
setblock 238 275 490 minecraft:light[level=12]
setblock 238 275 498 minecraft:light[level=12]
setblock 246 275 466 minecraft:light[level=12]
setblock 246 275 474 minecraft:light[level=12]
setblock 246 275 482 minecraft:light[level=12]
setblock 246 275 490 minecraft:light[level=12]
setblock 246 275 498 minecraft:light[level=12]
setblock 254 275 466 minecraft:light[level=12]
setblock 254 275 474 minecraft:light[level=12]
setblock 254 275 482 minecraft:light[level=12]
setblock 254 275 490 minecraft:light[level=12]
setblock 254 275 498 minecraft:light[level=12]
setblock 262 275 466 minecraft:light[level=12]
setblock 262 275 474 minecraft:light[level=12]
setblock 262 275 482 minecraft:light[level=12]
setblock 262 275 490 minecraft:light[level=12]
setblock 262 275 498 minecraft:light[level=12]
setblock 270 275 466 minecraft:light[level=12]
setblock 270 275 474 minecraft:light[level=12]
setblock 270 275 482 minecraft:light[level=12]
setblock 270 275 490 minecraft:light[level=12]
setblock 270 275 498 minecraft:light[level=12]
fill 236 279 464 237 280 474 minecraft:soul_soil
fill 236 279 475 276 280 475 minecraft:bone_block
fill 236 279 476 237 280 486 minecraft:soul_soil
fill 236 279 487 253 279 487 minecraft:bone_block
fill 236 279 488 237 280 498 minecraft:soul_soil
fill 236 279 499 276 280 499 minecraft:bone_block
fill 236 279 500 237 280 504 minecraft:soul_soil
fill 238 279 464 238 280 474 minecraft:bone_block
fill 238 279 476 238 280 486 minecraft:bone_block
fill 238 279 488 238 280 498 minecraft:bone_block
fill 238 279 500 238 280 504 minecraft:bone_block
fill 239 279 464 240 280 474 minecraft:soul_soil
fill 239 279 476 240 280 486 minecraft:soul_soil
fill 239 279 488 240 280 498 minecraft:soul_soil
fill 239 279 500 240 280 504 minecraft:soul_soil
fill 241 279 464 241 280 474 minecraft:bone_block
fill 241 279 476 241 280 486 minecraft:bone_block
fill 241 279 488 241 280 498 minecraft:bone_block
fill 241 279 500 241 280 504 minecraft:bone_block
fill 242 279 464 243 280 474 minecraft:soul_soil
fill 242 279 476 243 280 486 minecraft:soul_soil
fill 242 279 488 243 280 498 minecraft:soul_soil
fill 242 279 500 243 280 504 minecraft:soul_soil
fill 244 279 464 244 280 474 minecraft:bone_block
fill 244 279 476 244 280 486 minecraft:bone_block
fill 244 279 488 244 280 498 minecraft:bone_block
fill 244 279 500 244 280 504 minecraft:bone_block
fill 245 279 464 246 280 474 minecraft:soul_soil
fill 245 279 476 246 280 486 minecraft:soul_soil
fill 245 279 488 246 280 498 minecraft:soul_soil
fill 245 279 500 246 280 504 minecraft:soul_soil
fill 247 279 464 247 280 474 minecraft:bone_block
fill 247 279 476 247 280 486 minecraft:bone_block
fill 247 279 488 247 280 498 minecraft:bone_block
fill 247 279 500 247 280 504 minecraft:bone_block
fill 248 279 464 249 280 474 minecraft:soul_soil
fill 248 279 476 249 280 486 minecraft:soul_soil
fill 248 279 488 249 280 498 minecraft:soul_soil
fill 248 279 500 249 280 504 minecraft:soul_soil
fill 250 279 464 250 280 474 minecraft:bone_block
fill 250 279 476 250 280 486 minecraft:bone_block
fill 250 279 488 250 280 498 minecraft:bone_block
fill 250 279 500 250 280 504 minecraft:bone_block
fill 251 279 464 252 280 474 minecraft:soul_soil
fill 251 279 476 252 279 486 minecraft:soul_soil
fill 251 279 488 252 280 498 minecraft:soul_soil
fill 251 279 500 252 280 504 minecraft:soul_soil
fill 253 279 464 253 280 474 minecraft:bone_block
fill 253 279 476 253 279 485 minecraft:bone_block
fill 253 279 488 253 279 498 minecraft:bone_block
fill 253 279 500 253 280 504 minecraft:bone_block
fill 254 279 464 255 280 474 minecraft:soul_soil
fill 254 279 476 254 279 484 minecraft:soul_soil
fill 254 279 488 254 279 498 minecraft:soul_soil
fill 254 279 500 255 280 504 minecraft:soul_soil
fill 255 279 476 255 279 483 minecraft:soul_soil
fill 255 279 489 255 279 498 minecraft:soul_soil
fill 256 279 464 256 280 474 minecraft:bone_block
fill 256 279 476 256 279 484 minecraft:bone_block
fill 256 279 488 256 279 498 minecraft:bone_block
fill 256 279 500 256 280 504 minecraft:bone_block
fill 257 279 464 258 280 474 minecraft:soul_soil
fill 257 279 476 258 279 485 minecraft:soul_soil
fill 257 279 487 276 279 487 minecraft:bone_block
fill 257 279 488 258 279 498 minecraft:soul_soil
fill 257 279 500 258 280 504 minecraft:soul_soil
setblock 258 279 486 minecraft:soul_soil
fill 259 279 464 259 280 474 minecraft:bone_block
fill 259 279 476 259 280 486 minecraft:bone_block
fill 259 279 488 259 280 498 minecraft:bone_block
fill 259 279 500 259 280 504 minecraft:bone_block
fill 260 279 464 261 280 474 minecraft:soul_soil
fill 260 279 476 261 280 486 minecraft:soul_soil
fill 260 279 488 261 280 498 minecraft:soul_soil
fill 260 279 500 261 280 504 minecraft:soul_soil
fill 262 279 464 262 280 474 minecraft:bone_block
fill 262 279 476 262 280 486 minecraft:bone_block
fill 262 279 488 262 280 498 minecraft:bone_block
fill 262 279 500 262 280 504 minecraft:bone_block
fill 263 279 464 264 280 474 minecraft:soul_soil
fill 263 279 476 264 280 486 minecraft:soul_soil
fill 263 279 488 264 280 498 minecraft:soul_soil
fill 263 279 500 264 280 504 minecraft:soul_soil
fill 265 279 464 265 280 474 minecraft:bone_block
fill 265 279 476 265 280 486 minecraft:bone_block
fill 265 279 488 265 280 498 minecraft:bone_block
fill 265 279 500 265 280 504 minecraft:bone_block
fill 266 279 464 267 280 474 minecraft:soul_soil
fill 266 279 476 267 280 486 minecraft:soul_soil
fill 266 279 488 267 280 498 minecraft:soul_soil
fill 266 279 500 267 280 504 minecraft:soul_soil
fill 268 279 464 268 280 474 minecraft:bone_block
fill 268 279 476 268 280 486 minecraft:bone_block
fill 268 279 488 268 280 498 minecraft:bone_block
fill 268 279 500 268 280 504 minecraft:bone_block
fill 269 279 464 270 280 474 minecraft:soul_soil
fill 269 279 476 270 280 486 minecraft:soul_soil
fill 269 279 488 270 280 498 minecraft:soul_soil
fill 269 279 500 270 280 504 minecraft:soul_soil
fill 271 279 464 271 280 474 minecraft:bone_block
fill 271 279 476 271 280 486 minecraft:bone_block
fill 271 279 488 271 280 498 minecraft:bone_block
fill 271 279 500 271 280 504 minecraft:bone_block
fill 272 279 464 273 280 474 minecraft:soul_soil
fill 272 279 476 273 280 486 minecraft:soul_soil
fill 272 279 488 273 280 498 minecraft:soul_soil
fill 272 279 500 273 280 504 minecraft:soul_soil
fill 274 279 464 274 280 474 minecraft:bone_block
fill 274 279 476 274 280 486 minecraft:bone_block
fill 274 279 488 274 280 498 minecraft:bone_block
fill 274 279 500 274 280 504 minecraft:bone_block
fill 275 279 464 276 280 474 minecraft:soul_soil
fill 275 279 476 276 280 486 minecraft:soul_soil
fill 275 279 488 276 280 498 minecraft:soul_soil
fill 275 279 500 276 280 504 minecraft:soul_soil
fill 236 280 487 251 280 487 minecraft:bone_block
fill 251 280 476 251 280 486 minecraft:soul_soil
fill 252 280 476 252 280 484 minecraft:soul_soil
fill 252 280 485 252 280 487 minecraft:shroomlight
fill 253 280 476 253 280 483 minecraft:bone_block
fill 253 280 484 253 280 485 minecraft:shroomlight
fill 253 280 487 253 280 488 minecraft:shroomlight
fill 253 280 489 253 280 498 minecraft:bone_block
fill 254 280 476 255 280 482 minecraft:soul_soil
fill 254 280 483 254 280 484 minecraft:shroomlight
fill 254 280 488 254 280 489 minecraft:shroomlight
fill 254 280 490 255 280 498 minecraft:soul_soil
fill 255 280 483 256 280 483 minecraft:shroomlight
fill 255 280 489 256 280 489 minecraft:shroomlight
fill 256 280 476 256 280 482 minecraft:bone_block
fill 256 280 484 257 280 484 minecraft:shroomlight
fill 256 280 488 257 280 488 minecraft:shroomlight
fill 256 280 490 256 280 498 minecraft:bone_block
fill 257 280 476 258 280 483 minecraft:soul_soil
fill 257 280 485 258 280 485 minecraft:shroomlight
fill 257 280 487 258 280 487 minecraft:shroomlight
fill 257 280 489 258 280 498 minecraft:soul_soil
setblock 258 280 484 minecraft:soul_soil
setblock 258 280 486 minecraft:shroomlight
setblock 258 280 488 minecraft:soul_soil
fill 259 280 487 276 280 487 minecraft:bone_block
setblock 238 283 466 minecraft:light[level=12]
setblock 238 283 474 minecraft:light[level=12]
setblock 238 283 482 minecraft:light[level=12]
setblock 238 283 490 minecraft:light[level=12]
setblock 238 283 498 minecraft:light[level=12]
setblock 246 283 466 minecraft:light[level=12]
setblock 246 283 474 minecraft:light[level=12]
setblock 246 283 482 minecraft:light[level=12]
setblock 246 283 490 minecraft:light[level=12]
setblock 246 283 498 minecraft:light[level=12]
setblock 254 283 466 minecraft:light[level=12]
setblock 254 283 474 minecraft:light[level=12]
setblock 254 283 482 minecraft:light[level=12]
setblock 254 283 490 minecraft:light[level=12]
setblock 254 283 498 minecraft:light[level=12]
setblock 262 283 466 minecraft:light[level=12]
setblock 262 283 474 minecraft:light[level=12]
setblock 262 283 482 minecraft:light[level=12]
setblock 262 283 490 minecraft:light[level=12]
setblock 262 283 498 minecraft:light[level=12]
setblock 270 283 466 minecraft:light[level=12]
setblock 270 283 474 minecraft:light[level=12]
setblock 270 283 482 minecraft:light[level=12]
setblock 270 283 490 minecraft:light[level=12]
setblock 270 283 498 minecraft:light[level=12]
fill 236 284 464 236 285 465 minecraft:brown_terracotta
setblock 236 284 481 minecraft:brown_terracotta
setblock 236 284 482 minecraft:bone_block
fill 236 284 483 236 284 486 minecraft:brown_terracotta
setblock 236 284 487 minecraft:bone_block
fill 236 284 488 236 285 490 minecraft:brown_terracotta
fill 236 284 495 236 284 496 minecraft:brown_terracotta
setblock 236 284 497 minecraft:bone_block
fill 236 284 498 236 284 501 minecraft:brown_terracotta
setblock 236 284 502 minecraft:bone_block
fill 236 284 503 238 284 504 minecraft:brown_terracotta
fill 237 284 464 238 284 464 minecraft:brown_terracotta
fill 237 284 499 237 284 500 minecraft:brown_terracotta
setblock 237 284 501 minecraft:bone_block
fill 237 284 502 237 286 502 minecraft:brown_terracotta
setblock 239 284 464 minecraft:bone_block
setblock 239 284 503 minecraft:brown_terracotta
setblock 239 284 504 minecraft:bone_block
fill 240 284 464 243 284 464 minecraft:brown_terracotta
setblock 240 284 503 minecraft:bone_block
fill 240 284 504 243 284 504 minecraft:brown_terracotta
setblock 241 284 502 minecraft:bone_block
fill 241 284 503 244 284 503 minecraft:brown_terracotta
fill 242 284 502 245 284 502 minecraft:brown_terracotta
setblock 243 284 465 minecraft:bone_block
setblock 244 284 464 minecraft:bone_block
fill 244 284 465 247 284 465 minecraft:brown_terracotta
setblock 244 284 504 minecraft:bone_block
fill 245 284 464 248 284 464 minecraft:brown_terracotta
setblock 245 284 503 minecraft:bone_block
fill 245 284 504 248 284 504 minecraft:brown_terracotta
setblock 246 284 502 minecraft:bone_block
fill 246 284 503 249 284 503 minecraft:brown_terracotta
fill 247 284 502 249 284 502 minecraft:brown_terracotta
setblock 248 284 465 minecraft:bone_block
setblock 249 284 464 minecraft:bone_block
fill 249 284 465 251 285 465 minecraft:brown_terracotta
setblock 249 284 504 minecraft:bone_block
fill 250 284 464 253 284 464 minecraft:brown_terracotta
setblock 250 284 503 minecraft:bone_block
fill 250 284 504 253 284 504 minecraft:brown_terracotta
fill 251 284 503 252 284 503 minecraft:brown_terracotta
setblock 254 284 464 minecraft:bone_block
setblock 254 284 504 minecraft:bone_block
fill 255 284 464 258 284 464 minecraft:brown_terracotta
fill 255 284 504 258 284 504 minecraft:brown_terracotta
setblock 259 284 464 minecraft:bone_block
fill 259 284 465 262 284 465 minecraft:brown_terracotta
setblock 259 284 504 minecraft:bone_block
fill 260 284 464 263 284 464 minecraft:brown_terracotta
fill 260 284 504 263 284 504 minecraft:brown_terracotta
setblock 262 284 466 minecraft:bone_block
fill 262 284 503 264 284 503 minecraft:brown_terracotta
setblock 263 284 465 minecraft:bone_block
fill 263 284 466 266 284 466 minecraft:brown_terracotta
setblock 264 284 464 minecraft:bone_block
fill 264 284 465 267 284 465 minecraft:brown_terracotta
setblock 264 284 504 minecraft:bone_block
fill 265 284 464 268 284 464 minecraft:brown_terracotta
setblock 265 284 502 minecraft:brown_terracotta
setblock 265 284 503 minecraft:bone_block
fill 265 284 504 268 284 504 minecraft:brown_terracotta
setblock 266 284 467 minecraft:bone_block
setblock 266 284 502 minecraft:bone_block
fill 266 284 503 269 284 503 minecraft:brown_terracotta
setblock 267 284 466 minecraft:bone_block
fill 267 284 467 269 285 467 minecraft:brown_terracotta
fill 267 284 502 270 284 502 minecraft:brown_terracotta
setblock 268 284 465 minecraft:bone_block
fill 268 284 466 271 284 466 minecraft:brown_terracotta
setblock 269 284 464 minecraft:bone_block
fill 269 284 465 272 284 465 minecraft:brown_terracotta
setblock 269 284 504 minecraft:bone_block
fill 270 284 464 273 284 464 minecraft:brown_terracotta
setblock 270 284 503 minecraft:bone_block
fill 270 284 504 273 284 504 minecraft:brown_terracotta
setblock 271 284 502 minecraft:bone_block
fill 271 284 503 274 284 503 minecraft:brown_terracotta
setblock 272 284 466 minecraft:bone_block
fill 272 284 502 275 284 502 minecraft:brown_terracotta
setblock 273 284 465 minecraft:bone_block
setblock 273 284 466 minecraft:brown_terracotta
setblock 274 284 464 minecraft:bone_block
fill 274 284 465 276 285 465 minecraft:brown_terracotta
setblock 274 284 504 minecraft:bone_block
fill 275 284 464 276 286 464 minecraft:brown_terracotta
fill 275 284 466 276 284 466 minecraft:brown_terracotta
fill 275 284 500 276 284 501 minecraft:brown_terracotta
setblock 275 284 503 minecraft:bone_block
fill 275 284 504 276 286 504 minecraft:brown_terracotta
setblock 276 284 467 minecraft:bone_block
fill 276 284 468 276 287 468 minecraft:brown_terracotta
setblock 276 284 482 minecraft:bone_block
fill 276 284 483 276 285 485 minecraft:brown_terracotta
fill 276 284 498 276 285 499 minecraft:brown_terracotta
setblock 276 284 502 minecraft:bone_block
fill 276 284 503 276 287 503 minecraft:brown_terracotta
setblock 236 285 481 minecraft:bone_block
fill 236 285 482 236 285 485 minecraft:brown_terracotta
setblock 236 285 486 minecraft:bone_block
fill 236 285 487 237 287 487 minecraft:brown_terracotta
setblock 236 285 491 minecraft:bone_block
fill 236 285 492 236 288 492 minecraft:brown_terracotta
setblock 236 285 496 minecraft:bone_block
fill 236 285 497 236 285 500 minecraft:brown_terracotta
setblock 236 285 501 minecraft:bone_block
fill 236 285 502 236 286 504 minecraft:brown_terracotta
setblock 237 285 464 minecraft:brown_terracotta
setblock 237 285 484 minecraft:brown_terracotta
setblock 237 285 485 minecraft:bone_block
fill 237 285 486 237 288 486 minecraft:brown_terracotta
setblock 237 285 500 minecraft:bone_block
setblock 237 285 501 minecraft:brown_terracotta
fill 237 285 503 237 285 504 minecraft:brown_terracotta
setblock 238 285 464 minecraft:bone_block
setblock 238 285 503 minecraft:brown_terracotta
setblock 238 285 504 minecraft:bone_block
fill 239 285 464 242 285 464 minecraft:brown_terracotta
setblock 239 285 503 minecraft:bone_block
fill 239 285 504 242 285 504 minecraft:brown_terracotta
fill 240 285 503 243 285 503 minecraft:brown_terracotta
fill 241 285 502 244 285 502 minecraft:brown_terracotta
setblock 242 285 465 minecraft:bone_block
setblock 243 285 464 minecraft:bone_block
fill 243 285 465 246 285 465 minecraft:brown_terracotta
setblock 243 285 504 minecraft:bone_block
fill 244 285 464 247 285 464 minecraft:brown_terracotta
setblock 244 285 503 minecraft:bone_block
fill 244 285 504 247 285 504 minecraft:brown_terracotta
setblock 245 285 502 minecraft:bone_block
fill 245 285 503 248 285 503 minecraft:brown_terracotta
fill 246 285 502 248 285 502 minecraft:brown_terracotta
setblock 247 285 465 minecraft:bone_block
setblock 248 285 464 minecraft:bone_block
fill 248 285 465 248 288 465 minecraft:brown_terracotta
setblock 248 285 504 minecraft:bone_block
fill 249 285 464 252 285 464 minecraft:brown_terracotta
setblock 249 285 503 minecraft:bone_block
fill 249 285 504 252 285 504 minecraft:brown_terracotta
fill 250 285 503 251 285 503 minecraft:brown_terracotta
setblock 252 285 465 minecraft:bone_block
setblock 253 285 464 minecraft:bone_block
setblock 253 285 504 minecraft:bone_block
fill 254 285 464 257 285 464 minecraft:brown_terracotta
fill 254 285 504 255 285 504 minecraft:brown_terracotta
setblock 257 285 504 minecraft:brown_terracotta
setblock 258 285 464 minecraft:bone_block
fill 258 285 465 261 285 465 minecraft:brown_terracotta
setblock 258 285 504 minecraft:bone_block
fill 259 285 464 262 285 464 minecraft:brown_terracotta
fill 259 285 504 262 285 504 minecraft:brown_terracotta
setblock 261 285 466 minecraft:bone_block
fill 261 285 503 263 285 503 minecraft:brown_terracotta
setblock 262 285 465 minecraft:bone_block
fill 262 285 466 265 285 466 minecraft:brown_terracotta
setblock 263 285 464 minecraft:bone_block
fill 263 285 465 266 285 465 minecraft:brown_terracotta
setblock 263 285 504 minecraft:bone_block
fill 264 285 464 267 285 464 minecraft:brown_terracotta
setblock 264 285 467 minecraft:brown_terracotta
setblock 264 285 503 minecraft:bone_block
fill 264 285 504 267 285 504 minecraft:brown_terracotta
setblock 265 285 467 minecraft:bone_block
setblock 265 285 502 minecraft:bone_block
fill 265 285 503 268 285 503 minecraft:brown_terracotta
setblock 266 285 466 minecraft:bone_block
fill 266 285 467 266 288 467 minecraft:brown_terracotta
fill 266 285 502 269 285 502 minecraft:brown_terracotta
setblock 267 285 465 minecraft:bone_block
fill 267 285 466 270 285 466 minecraft:brown_terracotta
setblock 268 285 464 minecraft:bone_block
fill 268 285 465 271 285 465 minecraft:brown_terracotta
setblock 268 285 504 minecraft:bone_block
fill 269 285 464 272 285 464 minecraft:brown_terracotta
setblock 269 285 503 minecraft:bone_block
fill 269 285 504 272 285 504 minecraft:brown_terracotta
setblock 270 285 502 minecraft:bone_block
fill 270 285 503 273 285 503 minecraft:brown_terracotta
setblock 271 285 466 minecraft:bone_block
fill 271 285 502 272 285 502 minecraft:brown_terracotta
setblock 272 285 465 minecraft:bone_block
fill 272 285 466 272 286 466 minecraft:brown_terracotta
setblock 273 285 464 minecraft:bone_block
fill 273 285 465 273 288 465 minecraft:brown_terracotta
setblock 273 285 504 minecraft:bone_block
fill 274 285 464 274 288 464 minecraft:brown_terracotta
setblock 274 285 503 minecraft:bone_block
fill 274 285 504 274 288 504 minecraft:brown_terracotta
setblock 275 285 466 minecraft:brown_terracotta
setblock 275 285 501 minecraft:brown_terracotta
setblock 275 285 502 minecraft:bone_block
fill 275 285 503 275 287 503 minecraft:brown_terracotta
setblock 276 285 466 minecraft:bone_block
fill 276 285 467 276 288 467 minecraft:brown_terracotta
setblock 276 285 500 minecraft:brown_terracotta
setblock 276 285 501 minecraft:bone_block
fill 276 285 502 276 288 502 minecraft:brown_terracotta
setblock 236 286 464 minecraft:brown_terracotta
setblock 236 286 465 minecraft:bone_block
fill 236 286 482 236 286 484 minecraft:brown_terracotta
setblock 236 286 485 minecraft:bone_block
fill 236 286 486 236 289 486 minecraft:brown_terracotta
fill 236 286 488 236 286 489 minecraft:brown_terracotta
setblock 236 286 490 minecraft:bone_block
fill 236 286 491 236 289 491 minecraft:brown_terracotta
fill 236 286 493 236 287 493 minecraft:brown_terracotta
fill 236 286 497 236 286 499 minecraft:brown_terracotta
setblock 236 286 500 minecraft:bone_block
fill 236 286 501 236 288 501 minecraft:brown_terracotta
setblock 237 286 464 minecraft:bone_block
setblock 237 286 484 minecraft:bone_block
fill 237 286 485 237 289 485 minecraft:brown_terracotta
setblock 237 286 488 minecraft:brown_terracotta
setblock 237 286 503 minecraft:brown_terracotta
setblock 237 286 504 minecraft:bone_block
fill 238 286 464 241 286 464 minecraft:brown_terracotta
setblock 238 286 503 minecraft:bone_block
fill 238 286 504 241 286 504 minecraft:brown_terracotta
fill 239 286 503 242 286 503 minecraft:brown_terracotta
setblock 242 286 464 minecraft:bone_block
fill 242 286 465 245 286 465 minecraft:brown_terracotta
setblock 242 286 504 minecraft:bone_block
fill 243 286 464 246 286 464 minecraft:brown_terracotta
setblock 243 286 502 minecraft:brown_terracotta
setblock 243 286 503 minecraft:bone_block
fill 243 286 504 246 286 504 minecraft:brown_terracotta
setblock 244 286 502 minecraft:bone_block
fill 244 286 503 247 286 503 minecraft:brown_terracotta
fill 245 286 502 246 286 502 minecraft:brown_terracotta
setblock 246 286 465 minecraft:bone_block
setblock 247 286 464 minecraft:bone_block
fill 247 286 465 247 289 465 minecraft:brown_terracotta
setblock 247 286 504 minecraft:bone_block
fill 248 286 464 251 286 464 minecraft:brown_terracotta
setblock 248 286 503 minecraft:bone_block
fill 248 286 504 251 286 504 minecraft:brown_terracotta
fill 249 286 465 250 286 465 minecraft:brown_terracotta
fill 249 286 503 250 286 503 minecraft:brown_terracotta
setblock 251 286 465 minecraft:bone_block
setblock 252 286 464 minecraft:bone_block
setblock 252 286 504 minecraft:bone_block
fill 253 286 464 256 286 464 minecraft:brown_terracotta
setblock 253 286 504 minecraft:brown_terracotta
setblock 257 286 464 minecraft:bone_block
fill 257 286 465 260 286 465 minecraft:brown_terracotta
fill 258 286 464 261 286 464 minecraft:brown_terracotta
fill 258 286 504 261 286 504 minecraft:brown_terracotta
setblock 260 286 466 minecraft:bone_block
setblock 261 286 465 minecraft:bone_block
fill 261 286 466 264 286 466 minecraft:brown_terracotta
fill 261 286 503 262 286 503 minecraft:brown_terracotta
setblock 262 286 464 minecraft:bone_block
fill 262 286 465 265 286 465 minecraft:brown_terracotta
setblock 262 286 504 minecraft:bone_block
fill 263 286 464 266 286 464 minecraft:brown_terracotta
setblock 263 286 467 minecraft:brown_terracotta
setblock 263 286 503 minecraft:bone_block
fill 263 286 504 266 286 504 minecraft:brown_terracotta
setblock 264 286 467 minecraft:bone_block
fill 264 286 503 267 286 503 minecraft:brown_terracotta
setblock 265 286 466 minecraft:bone_block
fill 265 286 467 265 289 467 minecraft:brown_terracotta
fill 265 286 502 268 286 502 minecraft:brown_terracotta
setblock 266 286 465 minecraft:bone_block
fill 266 286 466 269 286 466 minecraft:brown_terracotta
setblock 267 286 464 minecraft:bone_block
fill 267 286 465 270 286 465 minecraft:brown_terracotta
fill 267 286 467 268 286 467 minecraft:brown_terracotta
setblock 267 286 504 minecraft:bone_block
fill 268 286 464 271 286 464 minecraft:brown_terracotta
setblock 268 286 503 minecraft:bone_block
fill 268 286 504 271 286 504 minecraft:brown_terracotta
setblock 269 286 467 minecraft:bone_block
setblock 269 286 502 minecraft:bone_block
fill 269 286 503 272 286 503 minecraft:brown_terracotta
setblock 270 286 466 minecraft:bone_block
setblock 270 286 502 minecraft:brown_terracotta
setblock 271 286 465 minecraft:bone_block
fill 271 286 466 271 288 466 minecraft:brown_terracotta
setblock 272 286 464 minecraft:bone_block
fill 272 286 465 272 289 465 minecraft:brown_terracotta
setblock 272 286 504 minecraft:bone_block
fill 273 286 464 273 289 464 minecraft:brown_terracotta
setblock 273 286 503 minecraft:bone_block
fill 273 286 504 273 289 504 minecraft:brown_terracotta
fill 274 286 465 275 286 465 minecraft:brown_terracotta
fill 274 286 503 274 287 503 minecraft:brown_terracotta
setblock 275 286 466 minecraft:bone_block
setblock 275 286 502 minecraft:brown_terracotta
setblock 276 286 465 minecraft:bone_block
fill 276 286 466 276 289 466 minecraft:brown_terracotta
setblock 276 286 485 minecraft:bone_block
setblock 276 286 486 minecraft:brown_terracotta
setblock 276 286 499 minecraft:brown_terracotta
setblock 276 286 500 minecraft:bone_block
fill 276 286 501 276 288 501 minecraft:brown_terracotta
setblock 236 287 464 minecraft:bone_block
setblock 236 287 465 minecraft:brown_terracotta
fill 236 287 482 236 287 483 minecraft:brown_terracotta
setblock 236 287 484 minecraft:bone_block
fill 236 287 485 236 290 485 minecraft:brown_terracotta
setblock 236 287 488 minecraft:brown_terracotta
setblock 236 287 489 minecraft:bone_block
fill 236 287 490 236 290 490 minecraft:brown_terracotta
setblock 236 287 499 minecraft:bone_block
setblock 236 287 500 minecraft:brown_terracotta
fill 236 287 502 236 287 503 minecraft:brown_terracotta
setblock 236 287 504 minecraft:bone_block
fill 237 287 464 240 287 464 minecraft:brown_terracotta
setblock 237 287 484 minecraft:brown_terracotta
setblock 237 287 488 minecraft:bone_block
fill 237 287 489 237 290 489 minecraft:brown_terracotta
fill 237 287 504 240 287 504 minecraft:brown_terracotta
fill 238 287 503 241 287 503 minecraft:brown_terracotta
setblock 241 287 464 minecraft:bone_block
fill 241 287 465 244 287 465 minecraft:brown_terracotta
setblock 241 287 504 minecraft:bone_block
fill 242 287 464 245 287 464 minecraft:brown_terracotta
setblock 242 287 503 minecraft:bone_block
fill 242 287 504 245 287 504 minecraft:brown_terracotta
fill 243 287 503 246 287 503 minecraft:brown_terracotta
setblock 245 287 465 minecraft:bone_block
setblock 246 287 464 minecraft:bone_block
fill 246 287 465 246 290 465 minecraft:brown_terracotta
setblock 246 287 504 minecraft:bone_block
fill 247 287 464 250 287 464 minecraft:brown_terracotta
setblock 247 287 503 minecraft:bone_block
fill 247 287 504 250 287 504 minecraft:brown_terracotta
setblock 248 287 503 minecraft:brown_terracotta
setblock 249 287 465 minecraft:brown_terracotta
setblock 250 287 465 minecraft:bone_block
setblock 251 287 464 minecraft:bone_block
setblock 251 287 465 minecraft:brown_terracotta
setblock 251 287 504 minecraft:bone_block
fill 252 287 464 255 287 464 minecraft:brown_terracotta
setblock 256 287 464 minecraft:bone_block
fill 257 287 464 259 287 465 minecraft:brown_terracotta
fill 258 287 504 260 287 504 minecraft:brown_terracotta
setblock 260 287 464 minecraft:brown_terracotta
setblock 260 287 465 minecraft:bone_block
fill 260 287 466 263 287 466 minecraft:brown_terracotta
setblock 261 287 464 minecraft:bone_block
fill 261 287 465 264 287 465 minecraft:brown_terracotta
setblock 261 287 504 minecraft:bone_block
fill 262 287 464 265 287 464 minecraft:brown_terracotta
setblock 262 287 503 minecraft:bone_block
fill 262 287 504 265 287 504 minecraft:brown_terracotta
setblock 263 287 467 minecraft:bone_block
fill 263 287 503 266 287 503 minecraft:brown_terracotta
setblock 264 287 466 minecraft:bone_block
fill 264 287 467 264 290 467 minecraft:brown_terracotta
setblock 265 287 465 minecraft:bone_block
fill 265 287 466 268 287 466 minecraft:brown_terracotta
setblock 266 287 464 minecraft:bone_block
fill 266 287 465 269 287 465 minecraft:brown_terracotta
fill 266 287 502 267 287 502 minecraft:brown_terracotta
setblock 266 287 504 minecraft:bone_block
fill 267 287 464 270 287 464 minecraft:brown_terracotta
setblock 267 287 467 minecraft:brown_terracotta
setblock 267 287 503 minecraft:bone_block
fill 267 287 504 270 287 504 minecraft:brown_terracotta
setblock 268 287 467 minecraft:bone_block
setblock 268 287 502 minecraft:bone_block
fill 268 287 503 271 287 503 minecraft:brown_terracotta
setblock 269 287 466 minecraft:bone_block
setblock 270 287 465 minecraft:bone_block
fill 270 287 466 270 289 466 minecraft:brown_terracotta
setblock 271 287 464 minecraft:bone_block
fill 271 287 465 271 290 465 minecraft:brown_terracotta
setblock 271 287 504 minecraft:bone_block
fill 272 287 464 272 290 464 minecraft:brown_terracotta
setblock 272 287 503 minecraft:bone_block
fill 272 287 504 272 290 504 minecraft:brown_terracotta
setblock 273 287 503 minecraft:brown_terracotta
setblock 274 287 465 minecraft:brown_terracotta
setblock 275 287 464 minecraft:brown_terracotta
setblock 275 287 465 minecraft:bone_block
setblock 275 287 466 minecraft:brown_terracotta
setblock 275 287 504 minecraft:brown_terracotta
setblock 276 287 464 minecraft:bone_block
fill 276 287 465 276 290 465 minecraft:brown_terracotta
setblock 276 287 500 minecraft:brown_terracotta
setblock 276 287 504 minecraft:bone_block
fill 236 288 464 239 288 464 minecraft:brown_terracotta
setblock 236 288 483 minecraft:bone_block
fill 236 288 484 236 291 484 minecraft:brown_terracotta
setblock 236 288 487 minecraft:brown_terracotta
setblock 236 288 488 minecraft:bone_block
fill 236 288 489 236 291 489 minecraft:brown_terracotta
setblock 236 288 493 minecraft:bone_block
setblock 236 288 502 minecraft:brown_terracotta
setblock 236 288 503 minecraft:bone_block
fill 236 288 504 239 288 504 minecraft:brown_terracotta
setblock 237 288 487 minecraft:bone_block
fill 237 288 488 237 291 488 minecraft:brown_terracotta
fill 237 288 490 237 289 490 minecraft:brown_terracotta
setblock 240 288 464 minecraft:bone_block
setblock 240 288 503 minecraft:brown_terracotta
setblock 240 288 504 minecraft:bone_block
fill 241 288 464 243 288 465 minecraft:brown_terracotta
setblock 241 288 503 minecraft:bone_block
fill 241 288 504 244 288 504 minecraft:brown_terracotta
fill 242 288 503 245 288 503 minecraft:brown_terracotta
setblock 244 288 464 minecraft:brown_terracotta
setblock 244 288 465 minecraft:bone_block
setblock 245 288 464 minecraft:bone_block
fill 245 288 465 245 291 465 minecraft:brown_terracotta
setblock 245 288 504 minecraft:bone_block
fill 246 288 464 249 288 464 minecraft:brown_terracotta
setblock 246 288 503 minecraft:bone_block
fill 246 288 504 249 288 504 minecraft:brown_terracotta
setblock 249 288 465 minecraft:bone_block
setblock 250 288 464 minecraft:bone_block
fill 251 288 464 254 288 464 minecraft:brown_terracotta
setblock 255 288 464 minecraft:bone_block
fill 256 288 464 259 288 464 minecraft:brown_terracotta
fill 257 288 465 258 288 465 minecraft:brown_terracotta
setblock 259 288 465 minecraft:bone_block
setblock 259 288 504 minecraft:brown_terracotta
setblock 260 288 464 minecraft:bone_block
fill 260 288 465 262 288 466 minecraft:brown_terracotta
setblock 260 288 504 minecraft:bone_block
fill 261 288 464 264 288 464 minecraft:brown_terracotta
fill 261 288 504 264 288 504 minecraft:brown_terracotta
setblock 262 288 467 minecraft:bone_block
fill 262 288 503 265 288 503 minecraft:brown_terracotta
setblock 263 288 465 minecraft:brown_terracotta
setblock 263 288 466 minecraft:bone_block
fill 263 288 467 263 291 467 minecraft:brown_terracotta
setblock 264 288 465 minecraft:bone_block
fill 264 288 466 267 288 466 minecraft:brown_terracotta
setblock 265 288 464 minecraft:bone_block
fill 265 288 465 268 288 465 minecraft:brown_terracotta
setblock 265 288 504 minecraft:bone_block
fill 266 288 464 269 288 464 minecraft:brown_terracotta
setblock 266 288 503 minecraft:bone_block
fill 266 288 504 269 288 504 minecraft:brown_terracotta
setblock 267 288 467 minecraft:bone_block
fill 267 288 503 270 288 503 minecraft:brown_terracotta
setblock 268 288 466 minecraft:bone_block
setblock 269 288 465 minecraft:bone_block
fill 269 288 466 269 290 466 minecraft:brown_terracotta
setblock 270 288 464 minecraft:bone_block
fill 270 288 465 270 291 465 minecraft:brown_terracotta
setblock 270 288 504 minecraft:bone_block
fill 271 288 464 271 291 464 minecraft:brown_terracotta
setblock 271 288 503 minecraft:bone_block
fill 271 288 504 271 291 504 minecraft:brown_terracotta
setblock 272 288 503 minecraft:brown_terracotta
setblock 274 288 465 minecraft:bone_block
setblock 275 288 464 minecraft:bone_block
setblock 275 288 465 minecraft:brown_terracotta
setblock 275 288 504 minecraft:bone_block
fill 276 288 464 276 291 464 minecraft:brown_terracotta
setblock 276 288 503 minecraft:bone_block
fill 276 288 504 276 291 504 minecraft:brown_terracotta
setblock 236 289 483 minecraft:brown_terracotta
setblock 236 289 487 minecraft:bone_block
fill 236 289 488 236 292 488 minecraft:brown_terracotta
setblock 236 289 492 minecraft:bone_block
fill 236 289 493 236 292 493 minecraft:brown_terracotta
fill 236 289 503 236 289 504 minecraft:brown_terracotta
setblock 237 289 486 minecraft:bone_block
fill 237 289 487 237 292 487 minecraft:brown_terracotta
setblock 237 289 491 minecraft:bone_block
fill 237 289 504 238 289 504 minecraft:brown_terracotta
setblock 238 289 464 minecraft:brown_terracotta
setblock 239 289 464 minecraft:bone_block
setblock 239 289 504 minecraft:bone_block
fill 240 289 464 243 289 464 minecraft:brown_terracotta
fill 240 289 504 243 289 504 minecraft:brown_terracotta
setblock 242 289 465 minecraft:brown_terracotta
setblock 243 289 465 minecraft:bone_block
setblock 244 289 464 minecraft:bone_block
fill 244 289 465 244 292 465 minecraft:brown_terracotta
setblock 244 289 504 minecraft:bone_block
fill 245 289 464 248 289 464 minecraft:brown_terracotta
fill 245 289 504 248 289 504 minecraft:brown_terracotta
setblock 248 289 465 minecraft:bone_block
setblock 249 289 464 minecraft:bone_block
fill 250 289 464 253 289 464 minecraft:brown_terracotta
setblock 254 289 464 minecraft:bone_block
fill 255 289 464 258 289 464 minecraft:brown_terracotta
setblock 257 289 465 minecraft:brown_terracotta
setblock 258 289 465 minecraft:bone_block
setblock 259 289 464 minecraft:bone_block
fill 259 289 465 261 289 466 minecraft:brown_terracotta
setblock 259 289 504 minecraft:bone_block
fill 260 289 464 263 289 464 minecraft:brown_terracotta
fill 260 289 504 263 289 504 minecraft:brown_terracotta
setblock 262 289 465 minecraft:brown_terracotta
setblock 262 289 466 minecraft:bone_block
fill 262 289 467 262 292 467 minecraft:brown_terracotta
setblock 263 289 465 minecraft:bone_block
fill 263 289 466 266 289 466 minecraft:brown_terracotta
fill 263 289 503 264 289 503 minecraft:brown_terracotta
setblock 264 289 464 minecraft:bone_block
fill 264 289 465 267 289 465 minecraft:brown_terracotta
setblock 264 289 504 minecraft:bone_block
fill 265 289 464 268 289 464 minecraft:brown_terracotta
setblock 265 289 503 minecraft:bone_block
fill 265 289 504 268 289 504 minecraft:brown_terracotta
setblock 266 289 467 minecraft:bone_block
fill 266 289 503 269 289 503 minecraft:brown_terracotta
setblock 267 289 466 minecraft:bone_block
setblock 267 289 467 minecraft:brown_terracotta
setblock 268 289 465 minecraft:bone_block
fill 268 289 466 268 291 466 minecraft:brown_terracotta
setblock 269 289 464 minecraft:bone_block
fill 269 289 465 269 292 465 minecraft:brown_terracotta
setblock 269 289 504 minecraft:bone_block
fill 270 289 464 270 292 464 minecraft:brown_terracotta
fill 270 289 504 270 292 504 minecraft:brown_terracotta
setblock 273 289 465 minecraft:bone_block
fill 273 289 477 274 290 478 minecraft:soul_soil
setblock 274 289 464 minecraft:bone_block
setblock 274 289 504 minecraft:bone_block
fill 275 289 464 275 292 464 minecraft:brown_terracotta
fill 275 289 504 275 291 504 minecraft:brown_terracotta
setblock 276 289 467 minecraft:bone_block
setblock 276 289 502 minecraft:bone_block
fill 276 289 503 276 290 503 minecraft:brown_terracotta
setblock 236 290 486 minecraft:bone_block
fill 236 290 487 236 293 487 minecraft:brown_terracotta
setblock 236 290 491 minecraft:bone_block
fill 236 290 492 237 292 492 minecraft:brown_terracotta
fill 236 290 494 236 291 494 minecraft:brown_terracotta
setblock 237 290 485 minecraft:bone_block
fill 237 290 486 237 293 486 minecraft:brown_terracotta
setblock 237 290 490 minecraft:bone_block
fill 237 290 491 237 293 491 minecraft:brown_terracotta
setblock 238 290 464 minecraft:bone_block
setblock 238 290 488 minecraft:brown_terracotta
setblock 238 290 504 minecraft:bone_block
fill 239 290 464 242 290 464 minecraft:brown_terracotta
fill 239 290 488 239 291 488 minecraft:soul_soil
fill 239 290 504 242 290 504 minecraft:brown_terracotta
setblock 242 290 465 minecraft:bone_block
setblock 243 290 464 minecraft:bone_block
fill 243 290 465 243 292 465 minecraft:brown_terracotta
setblock 243 290 504 minecraft:bone_block
fill 244 290 464 247 290 464 minecraft:brown_terracotta
fill 244 290 504 246 290 504 minecraft:brown_terracotta
setblock 247 290 465 minecraft:bone_block
setblock 248 290 464 minecraft:bone_block
fill 249 290 464 251 290 464 minecraft:brown_terracotta
fill 254 290 464 257 290 464 minecraft:brown_terracotta
setblock 257 290 465 minecraft:bone_block
setblock 258 290 464 minecraft:bone_block
fill 258 290 465 261 290 465 minecraft:brown_terracotta
fill 259 290 464 262 290 464 minecraft:brown_terracotta
fill 259 290 466 260 290 466 minecraft:brown_terracotta
fill 260 290 504 262 290 504 minecraft:brown_terracotta
setblock 261 290 466 minecraft:bone_block
setblock 262 290 465 minecraft:bone_block
fill 262 290 466 265 290 466 minecraft:brown_terracotta
setblock 263 290 464 minecraft:bone_block
fill 263 290 465 266 290 465 minecraft:brown_terracotta
setblock 263 290 503 minecraft:brown_terracotta
setblock 263 290 504 minecraft:bone_block
fill 264 290 464 267 290 464 minecraft:brown_terracotta
setblock 264 290 503 minecraft:bone_block
fill 264 290 504 267 290 504 minecraft:brown_terracotta
setblock 265 290 467 minecraft:bone_block
fill 265 290 503 267 290 503 minecraft:brown_terracotta
setblock 266 290 466 minecraft:bone_block
setblock 266 290 467 minecraft:brown_terracotta
setblock 267 290 465 minecraft:bone_block
fill 267 290 466 267 293 466 minecraft:brown_terracotta
setblock 268 290 464 minecraft:bone_block
fill 268 290 465 268 293 465 minecraft:brown_terracotta
setblock 268 290 504 minecraft:bone_block
fill 269 290 464 269 293 464 minecraft:brown_terracotta
fill 269 290 504 269 293 504 minecraft:brown_terracotta
setblock 272 290 465 minecraft:bone_block
setblock 273 290 464 minecraft:bone_block
setblock 273 290 504 minecraft:bone_block
fill 274 290 464 274 292 464 minecraft:brown_terracotta
setblock 274 290 504 minecraft:brown_terracotta
setblock 276 290 466 minecraft:bone_block
fill 276 290 467 276 293 467 minecraft:brown_terracotta
fill 276 290 488 276 290 490 minecraft:brown_terracotta
setblock 236 291 485 minecraft:bone_block
fill 236 291 486 236 294 486 minecraft:brown_terracotta
setblock 236 291 490 minecraft:bone_block
fill 236 291 491 236 294 491 minecraft:brown_terracotta
setblock 236 291 495 minecraft:bone_block
fill 237 291 485 237 294 485 minecraft:brown_terracotta
setblock 237 291 489 minecraft:bone_block
fill 237 291 490 238 293 490 minecraft:brown_terracotta
setblock 238 291 466 minecraft:light[level=12]
setblock 238 291 474 minecraft:light[level=12]
setblock 238 291 482 minecraft:light[level=12]
setblock 238 291 487 minecraft:brown_terracotta
setblock 238 291 488 minecraft:bone_block
fill 238 291 489 238 294 489 minecraft:brown_terracotta
setblock 238 291 498 minecraft:light[level=12]
fill 239 291 464 241 291 464 minecraft:brown_terracotta
fill 239 291 504 241 291 504 minecraft:brown_terracotta
setblock 242 291 464 minecraft:bone_block
setblock 242 291 465 minecraft:brown_terracotta
setblock 242 291 504 minecraft:bone_block
fill 243 291 464 246 291 464 minecraft:brown_terracotta
fill 243 291 504 244 291 504 minecraft:brown_terracotta
setblock 246 291 466 minecraft:light[level=12]
setblock 246 291 474 minecraft:light[level=12]
setblock 246 291 482 minecraft:light[level=12]
setblock 246 291 490 minecraft:light[level=12]
setblock 246 291 498 minecraft:light[level=12]
setblock 247 291 464 minecraft:bone_block
fill 248 291 464 249 291 464 minecraft:brown_terracotta
setblock 254 291 466 minecraft:light[level=12]
setblock 254 291 474 minecraft:light[level=12]
setblock 254 291 482 minecraft:light[level=12]
setblock 254 291 490 minecraft:light[level=12]
setblock 254 291 498 minecraft:light[level=12]
fill 255 291 464 256 291 464 minecraft:brown_terracotta
setblock 257 291 464 minecraft:bone_block
fill 257 291 465 260 291 465 minecraft:brown_terracotta
fill 258 291 464 261 291 464 minecraft:brown_terracotta
setblock 259 291 466 minecraft:brown_terracotta
setblock 260 291 466 minecraft:bone_block
fill 260 291 504 261 291 504 minecraft:brown_terracotta
setblock 261 291 465 minecraft:bone_block
fill 261 291 466 261 293 467 minecraft:brown_terracotta
setblock 262 291 464 minecraft:bone_block
fill 262 291 465 264 291 466 minecraft:brown_terracotta
setblock 262 291 474 minecraft:light[level=12]
setblock 262 291 482 minecraft:light[level=12]
setblock 262 291 490 minecraft:light[level=12]
setblock 262 291 498 minecraft:light[level=12]
setblock 262 291 504 minecraft:bone_block
fill 263 291 464 266 291 464 minecraft:brown_terracotta
fill 263 291 504 266 291 504 minecraft:brown_terracotta
setblock 264 291 467 minecraft:bone_block
setblock 265 291 465 minecraft:brown_terracotta
setblock 265 291 466 minecraft:bone_block
setblock 265 291 467 minecraft:brown_terracotta
setblock 266 291 465 minecraft:bone_block
fill 266 291 466 266 294 466 minecraft:brown_terracotta
setblock 267 291 464 minecraft:bone_block
fill 267 291 465 267 294 465 minecraft:brown_terracotta
setblock 267 291 504 minecraft:bone_block
fill 268 291 464 268 294 464 minecraft:brown_terracotta
fill 268 291 504 268 294 504 minecraft:brown_terracotta
setblock 270 291 466 minecraft:light[level=12]
setblock 270 291 474 minecraft:light[level=12]
setblock 270 291 482 minecraft:light[level=12]
setblock 270 291 490 minecraft:light[level=12]
setblock 270 291 498 minecraft:light[level=12]
setblock 272 291 464 minecraft:bone_block
setblock 272 291 504 minecraft:bone_block
fill 273 291 464 273 292 464 minecraft:brown_terracotta
setblock 276 291 465 minecraft:bone_block
fill 276 291 466 276 294 466 minecraft:brown_terracotta
fill 276 291 488 276 291 489 minecraft:brown_terracotta
setblock 276 291 490 minecraft:bone_block
fill 276 291 491 276 293 492 minecraft:brown_terracotta
setblock 236 292 484 minecraft:bone_block
fill 236 292 485 236 295 485 minecraft:brown_terracotta
setblock 236 292 489 minecraft:bone_block
fill 236 292 490 236 295 490 minecraft:brown_terracotta
setblock 236 292 494 minecraft:bone_block
fill 236 292 495 236 294 496 minecraft:brown_terracotta
setblock 237 292 488 minecraft:bone_block
fill 237 292 489 237 295 489 minecraft:brown_terracotta
setblock 237 292 493 minecraft:bone_block
fill 237 292 494 237 295 494 minecraft:brown_terracotta
setblock 238 292 487 minecraft:bone_block
fill 238 292 488 238 295 488 minecraft:brown_terracotta
setblock 238 292 491 minecraft:brown_terracotta
fill 239 292 464 240 292 464 minecraft:brown_terracotta
setblock 240 292 504 minecraft:brown_terracotta
setblock 241 292 464 minecraft:bone_block
setblock 241 292 504 minecraft:bone_block
fill 242 292 464 245 292 464 minecraft:brown_terracotta
fill 242 292 504 243 292 504 minecraft:brown_terracotta
setblock 246 292 464 minecraft:bone_block
setblock 247 292 464 minecraft:brown_terracotta
setblock 255 292 464 minecraft:brown_terracotta
setblock 256 292 464 minecraft:bone_block
fill 256 292 465 259 292 465 minecraft:brown_terracotta
fill 257 292 464 260 292 464 minecraft:brown_terracotta
setblock 258 292 466 minecraft:brown_terracotta
setblock 259 292 466 minecraft:bone_block
setblock 260 292 465 minecraft:bone_block
fill 260 292 466 260 295 466 minecraft:brown_terracotta
setblock 260 292 504 minecraft:brown_terracotta
setblock 261 292 464 minecraft:bone_block
fill 261 292 465 264 292 465 minecraft:brown_terracotta
setblock 261 292 504 minecraft:bone_block
fill 262 292 464 265 292 464 minecraft:brown_terracotta
fill 262 292 466 263 292 466 minecraft:brown_terracotta
fill 262 292 504 265 292 504 minecraft:brown_terracotta
setblock 263 292 467 minecraft:bone_block
setblock 264 292 466 minecraft:bone_block
fill 264 292 467 264 295 467 minecraft:brown_terracotta
setblock 265 292 465 minecraft:bone_block
fill 265 292 466 265 295 466 minecraft:brown_terracotta
setblock 266 292 464 minecraft:bone_block
fill 266 292 465 266 295 465 minecraft:brown_terracotta
setblock 266 292 504 minecraft:bone_block
fill 267 292 464 267 295 464 minecraft:brown_terracotta
fill 267 292 504 267 295 504 minecraft:brown_terracotta
setblock 270 292 465 minecraft:bone_block
setblock 271 292 464 minecraft:bone_block
fill 272 292 464 272 293 464 minecraft:brown_terracotta
setblock 276 292 464 minecraft:bone_block
fill 276 292 465 276 295 465 minecraft:brown_terracotta
setblock 276 292 468 minecraft:brown_terracotta
fill 276 292 487 276 292 488 minecraft:brown_terracotta
setblock 276 292 489 minecraft:bone_block
fill 276 292 490 276 295 490 minecraft:brown_terracotta
setblock 276 292 493 minecraft:brown_terracotta
setblock 276 292 494 minecraft:bone_block
setblock 276 292 504 minecraft:bone_block
fill 236 293 484 236 296 484 minecraft:brown_terracotta
setblock 236 293 488 minecraft:bone_block
fill 236 293 489 236 296 489 minecraft:brown_terracotta
setblock 236 293 492 minecraft:brown_terracotta
setblock 236 293 493 minecraft:bone_block
fill 236 293 494 236 296 494 minecraft:brown_terracotta
setblock 236 293 497 minecraft:brown_terracotta
setblock 237 293 487 minecraft:bone_block
fill 237 293 488 237 296 488 minecraft:brown_terracotta
setblock 237 293 492 minecraft:bone_block
fill 237 293 493 238 295 493 minecraft:brown_terracotta
fill 237 293 495 237 294 495 minecraft:brown_terracotta
setblock 238 293 486 minecraft:bone_block
fill 238 293 487 238 296 487 minecraft:brown_terracotta
setblock 238 293 491 minecraft:bone_block
fill 238 293 492 238 296 492 minecraft:brown_terracotta
setblock 239 293 464 minecraft:brown_terracotta
setblock 239 293 489 minecraft:brown_terracotta
setblock 240 293 464 minecraft:bone_block
fill 241 293 464 244 293 464 minecraft:brown_terracotta
setblock 245 293 464 minecraft:bone_block
fill 246 293 464 246 294 464 minecraft:brown_terracotta
setblock 254 293 464 minecraft:brown_terracotta
setblock 255 293 464 minecraft:bone_block
fill 256 293 464 258 293 465 minecraft:brown_terracotta
setblock 258 293 466 minecraft:bone_block
setblock 259 293 464 minecraft:brown_terracotta
setblock 259 293 465 minecraft:bone_block
fill 259 293 466 259 296 466 minecraft:brown_terracotta
setblock 259 293 504 minecraft:brown_terracotta
setblock 260 293 464 minecraft:bone_block
fill 260 293 465 263 293 465 minecraft:brown_terracotta
fill 260 293 467 260 294 467 minecraft:brown_terracotta
setblock 260 293 504 minecraft:bone_block
fill 261 293 464 264 293 464 minecraft:brown_terracotta
fill 261 293 504 264 293 504 minecraft:brown_terracotta
setblock 262 293 466 minecraft:brown_terracotta
setblock 262 293 467 minecraft:bone_block
setblock 263 293 466 minecraft:bone_block
fill 263 293 467 263 296 467 minecraft:brown_terracotta
setblock 264 293 465 minecraft:bone_block
fill 264 293 466 264 296 466 minecraft:brown_terracotta
setblock 265 293 464 minecraft:bone_block
fill 265 293 465 265 296 465 minecraft:brown_terracotta
setblock 265 293 504 minecraft:bone_block
fill 266 293 464 266 296 464 minecraft:brown_terracotta
fill 266 293 504 266 296 504 minecraft:brown_terracotta
setblock 269 293 465 minecraft:bone_block
setblock 270 293 464 minecraft:bone_block
fill 271 293 464 271 294 464 minecraft:brown_terracotta
setblock 275 293 464 minecraft:bone_block
fill 276 293 464 276 296 464 minecraft:brown_terracotta
setblock 276 293 468 minecraft:bone_block
fill 276 293 469 276 296 469 minecraft:brown_terracotta
setblock 276 293 487 minecraft:brown_terracotta
setblock 276 293 488 minecraft:bone_block
fill 276 293 489 276 296 489 minecraft:brown_terracotta
setblock 276 293 493 minecraft:bone_block
fill 276 293 494 276 293 497 minecraft:brown_terracotta
fill 276 293 504 276 296 504 minecraft:brown_terracotta
setblock 236 294 467 minecraft:bone_block
fill 236 294 468 236 294 471 minecraft:brown_terracotta
fill 236 294 483 236 297 483 minecraft:brown_terracotta
setblock 236 294 487 minecraft:bone_block
fill 236 294 488 236 297 488 minecraft:brown_terracotta
setblock 236 294 492 minecraft:bone_block
fill 236 294 493 236 297 493 minecraft:brown_terracotta
setblock 236 294 497 minecraft:bone_block
fill 236 294 498 236 297 498 minecraft:brown_terracotta
fill 237 294 484 237 295 484 minecraft:brown_terracotta
setblock 237 294 486 minecraft:bone_block
fill 237 294 487 237 297 487 minecraft:brown_terracotta
setblock 237 294 490 minecraft:brown_terracotta
setblock 237 294 491 minecraft:bone_block
fill 237 294 492 237 297 492 minecraft:brown_terracotta
setblock 237 294 496 minecraft:bone_block
setblock 238 294 464 minecraft:brown_terracotta
fill 238 294 486 238 297 486 minecraft:brown_terracotta
setblock 238 294 490 minecraft:bone_block
fill 238 294 491 239 296 491 minecraft:brown_terracotta
setblock 238 294 494 minecraft:brown_terracotta
setblock 239 294 464 minecraft:bone_block
setblock 239 294 488 minecraft:brown_terracotta
setblock 239 294 489 minecraft:bone_block
fill 239 294 490 239 297 490 minecraft:brown_terracotta
fill 239 294 492 239 295 492 minecraft:brown_terracotta
fill 240 294 464 243 294 464 minecraft:brown_terracotta
setblock 244 294 464 minecraft:bone_block
fill 245 294 464 245 296 464 minecraft:brown_terracotta
setblock 254 294 464 minecraft:bone_block
fill 255 294 464 258 294 464 minecraft:brown_terracotta
fill 256 294 465 257 294 465 minecraft:brown_terracotta
setblock 257 294 466 minecraft:bone_block
setblock 258 294 465 minecraft:bone_block
fill 258 294 466 258 297 466 minecraft:brown_terracotta
setblock 259 294 464 minecraft:bone_block
fill 259 294 465 262 294 465 minecraft:brown_terracotta
fill 259 294 467 259 295 467 minecraft:brown_terracotta
setblock 259 294 504 minecraft:bone_block
fill 260 294 464 263 294 464 minecraft:brown_terracotta
fill 260 294 504 263 294 504 minecraft:brown_terracotta
setblock 261 294 466 minecraft:brown_terracotta
setblock 261 294 467 minecraft:bone_block
setblock 262 294 466 minecraft:bone_block
fill 262 294 467 262 297 467 minecraft:brown_terracotta
setblock 263 294 465 minecraft:bone_block
fill 263 294 466 263 297 466 minecraft:brown_terracotta
setblock 264 294 464 minecraft:bone_block
fill 264 294 465 264 297 465 minecraft:brown_terracotta
setblock 264 294 504 minecraft:bone_block
fill 265 294 464 265 297 464 minecraft:brown_terracotta
fill 265 294 504 265 297 504 minecraft:brown_terracotta
setblock 268 294 465 minecraft:bone_block
setblock 269 294 464 minecraft:bone_block
fill 270 294 464 270 296 464 minecraft:brown_terracotta
fill 275 294 464 275 297 464 minecraft:brown_terracotta
fill 275 294 490 275 294 492 minecraft:brown_terracotta
setblock 275 294 493 minecraft:bone_block
setblock 276 294 467 minecraft:bone_block
fill 276 294 468 276 297 468 minecraft:brown_terracotta
fill 276 294 470 276 295 470 minecraft:brown_terracotta
setblock 276 294 486 minecraft:brown_terracotta
setblock 276 294 487 minecraft:bone_block
fill 276 294 488 276 297 488 minecraft:brown_terracotta
setblock 276 294 491 minecraft:brown_terracotta
setblock 276 294 492 minecraft:bone_block
fill 276 294 493 276 294 496 minecraft:brown_terracotta
setblock 276 294 497 minecraft:bone_block
fill 276 294 498 276 294 501 minecraft:brown_terracotta
setblock 276 294 502 minecraft:bone_block
fill 276 294 503 276 297 503 minecraft:brown_terracotta
setblock 236 295 466 minecraft:bone_block
fill 236 295 467 236 295 470 minecraft:brown_terracotta
setblock 236 295 471 minecraft:bone_block
fill 236 295 472 236 295 475 minecraft:brown_terracotta
fill 236 295 482 236 298 482 minecraft:brown_terracotta
setblock 236 295 486 minecraft:bone_block
fill 236 295 487 236 298 487 minecraft:brown_terracotta
setblock 236 295 491 minecraft:bone_block
fill 236 295 492 236 298 492 minecraft:brown_terracotta
setblock 236 295 495 minecraft:brown_terracotta
setblock 236 295 496 minecraft:bone_block
fill 236 295 497 237 297 497 minecraft:brown_terracotta
fill 236 295 499 236 295 500 minecraft:brown_terracotta
setblock 237 295 469 minecraft:brown_terracotta
setblock 237 295 470 minecraft:bone_block
fill 237 295 471 237 297 472 minecraft:brown_terracotta
setblock 237 295 485 minecraft:bone_block
fill 237 295 486 237 298 486 minecraft:brown_terracotta
setblock 237 295 490 minecraft:bone_block
fill 237 295 491 237 298 491 minecraft:brown_terracotta
setblock 237 295 495 minecraft:bone_block
fill 237 295 496 237 298 496 minecraft:brown_terracotta
setblock 238 295 464 minecraft:bone_block
fill 238 295 485 238 298 485 minecraft:brown_terracotta
setblock 238 295 489 minecraft:bone_block
fill 238 295 490 238 298 490 minecraft:brown_terracotta
setblock 238 295 494 minecraft:bone_block
fill 238 295 495 238 298 495 minecraft:brown_terracotta
fill 239 295 464 242 295 464 minecraft:brown_terracotta
setblock 239 295 487 minecraft:brown_terracotta
setblock 239 295 488 minecraft:bone_block
fill 239 295 489 239 298 489 minecraft:brown_terracotta
setblock 239 295 493 minecraft:bone_block
fill 240 295 504 240 297 504 minecraft:brown_terracotta
setblock 241 295 465 minecraft:brown_terracotta
setblock 242 295 465 minecraft:bone_block
setblock 243 295 464 minecraft:bone_block
fill 244 295 464 244 297 464 minecraft:brown_terracotta
setblock 253 295 464 minecraft:bone_block
fill 254 295 464 257 295 464 minecraft:brown_terracotta
fill 255 295 465 256 295 465 minecraft:brown_terracotta
setblock 256 295 466 minecraft:bone_block
setblock 257 295 465 minecraft:bone_block
fill 257 295 466 257 298 466 minecraft:brown_terracotta
setblock 258 295 464 minecraft:bone_block
fill 258 295 465 261 295 465 minecraft:brown_terracotta
fill 258 295 467 258 296 467 minecraft:brown_terracotta
setblock 258 295 504 minecraft:bone_block
fill 259 295 464 262 295 464 minecraft:brown_terracotta
fill 259 295 504 262 295 504 minecraft:brown_terracotta
setblock 260 295 467 minecraft:bone_block
setblock 261 295 466 minecraft:bone_block
fill 261 295 467 261 298 467 minecraft:brown_terracotta
setblock 262 295 465 minecraft:bone_block
fill 262 295 466 262 298 466 minecraft:brown_terracotta
setblock 263 295 464 minecraft:bone_block
fill 263 295 465 263 298 465 minecraft:brown_terracotta
setblock 263 295 504 minecraft:bone_block
fill 264 295 464 264 298 464 minecraft:brown_terracotta
fill 264 295 504 264 298 504 minecraft:brown_terracotta
setblock 266 295 466 minecraft:bone_block
setblock 267 295 465 minecraft:bone_block
setblock 268 295 464 minecraft:bone_block
setblock 268 295 465 minecraft:brown_terracotta
setblock 268 295 504 minecraft:bone_block
fill 269 295 464 269 297 464 minecraft:brown_terracotta
fill 275 295 489 275 295 491 minecraft:brown_terracotta
setblock 275 295 492 minecraft:bone_block
fill 275 295 493 275 295 496 minecraft:brown_terracotta
fill 275 295 504 275 297 504 minecraft:brown_terracotta
setblock 276 295 466 minecraft:bone_block
fill 276 295 467 276 298 467 minecraft:brown_terracotta
setblock 276 295 471 minecraft:bone_block
fill 276 295 472 276 298 472 minecraft:brown_terracotta
setblock 276 295 486 minecraft:bone_block
fill 276 295 487 276 298 487 minecraft:brown_terracotta
setblock 276 295 491 minecraft:bone_block
fill 276 295 492 276 295 495 minecraft:brown_terracotta
setblock 276 295 496 minecraft:bone_block
fill 276 295 497 276 295 500 minecraft:brown_terracotta
setblock 276 295 501 minecraft:bone_block
fill 276 295 502 276 298 502 minecraft:brown_terracotta
setblock 236 296 465 minecraft:bone_block
fill 236 296 466 236 296 469 minecraft:brown_terracotta
setblock 236 296 470 minecraft:bone_block
fill 236 296 471 236 296 474 minecraft:brown_terracotta
setblock 236 296 475 minecraft:bone_block
fill 236 296 476 236 296 479 minecraft:brown_terracotta
setblock 236 296 480 minecraft:bone_block
fill 236 296 481 236 299 481 minecraft:brown_terracotta
setblock 236 296 485 minecraft:bone_block
fill 236 296 486 236 299 486 minecraft:brown_terracotta
setblock 236 296 490 minecraft:bone_block
fill 236 296 491 236 299 491 minecraft:brown_terracotta
setblock 236 296 495 minecraft:bone_block
fill 236 296 496 236 299 496 minecraft:brown_terracotta
setblock 236 296 499 minecraft:brown_terracotta
setblock 236 296 500 minecraft:bone_block
fill 236 296 501 236 299 501 minecraft:brown_terracotta
setblock 237 296 464 minecraft:bone_block
setblock 237 296 468 minecraft:brown_terracotta
setblock 237 296 469 minecraft:bone_block
fill 237 296 470 237 299 470 minecraft:brown_terracotta
setblock 237 296 473 minecraft:brown_terracotta
setblock 237 296 474 minecraft:bone_block
fill 237 296 475 237 298 476 minecraft:brown_terracotta
setblock 237 296 483 minecraft:brown_terracotta
setblock 237 296 484 minecraft:bone_block
fill 237 296 485 237 299 485 minecraft:brown_terracotta
setblock 237 296 489 minecraft:bone_block
fill 237 296 490 237 299 490 minecraft:brown_terracotta
setblock 237 296 493 minecraft:brown_terracotta
setblock 237 296 494 minecraft:bone_block
fill 237 296 495 237 299 495 minecraft:brown_terracotta
setblock 237 296 498 minecraft:brown_terracotta
setblock 237 296 499 minecraft:bone_block
fill 238 296 464 241 296 464 minecraft:brown_terracotta
fill 238 296 471 238 296 472 minecraft:brown_terracotta
setblock 238 296 488 minecraft:bone_block
fill 238 296 489 238 299 489 minecraft:brown_terracotta
setblock 238 296 493 minecraft:bone_block
fill 238 296 494 239 298 494 minecraft:brown_terracotta
fill 238 296 496 238 296 497 minecraft:brown_terracotta
fill 238 296 504 239 298 504 minecraft:brown_terracotta
setblock 239 296 487 minecraft:bone_block
fill 239 296 488 239 299 488 minecraft:brown_terracotta
setblock 239 296 492 minecraft:bone_block
fill 239 296 493 239 299 493 minecraft:brown_terracotta
setblock 241 296 465 minecraft:bone_block
setblock 242 296 464 minecraft:bone_block
fill 243 296 464 243 298 464 minecraft:brown_terracotta
fill 253 296 464 256 296 464 minecraft:brown_terracotta
fill 254 296 465 255 296 465 minecraft:brown_terracotta
setblock 256 296 465 minecraft:bone_block
fill 256 296 466 256 299 466 minecraft:brown_terracotta
setblock 257 296 464 minecraft:bone_block
fill 257 296 465 260 296 465 minecraft:brown_terracotta
fill 257 296 467 257 297 467 minecraft:brown_terracotta
setblock 257 296 504 minecraft:bone_block
fill 258 296 464 261 296 464 minecraft:brown_terracotta
fill 258 296 504 261 296 504 minecraft:brown_terracotta
setblock 259 296 467 minecraft:bone_block
setblock 260 296 466 minecraft:bone_block
fill 260 296 467 260 299 467 minecraft:brown_terracotta
setblock 261 296 465 minecraft:bone_block
fill 261 296 466 261 299 466 minecraft:brown_terracotta
fill 261 296 503 262 296 503 minecraft:brown_terracotta
setblock 262 296 464 minecraft:bone_block
fill 262 296 465 262 299 465 minecraft:brown_terracotta
setblock 262 296 504 minecraft:bone_block
fill 263 296 464 263 299 464 minecraft:brown_terracotta
setblock 263 296 503 minecraft:bone_block
fill 263 296 504 263 299 504 minecraft:brown_terracotta
setblock 265 296 466 minecraft:bone_block
setblock 266 296 465 minecraft:bone_block
setblock 267 296 464 minecraft:bone_block
setblock 267 296 465 minecraft:brown_terracotta
setblock 267 296 504 minecraft:bone_block
fill 268 296 464 268 298 464 minecraft:brown_terracotta
fill 268 296 504 268 299 504 minecraft:brown_terracotta
fill 274 296 504 274 298 504 minecraft:brown_terracotta
fill 275 296 488 275 296 490 minecraft:brown_terracotta
setblock 275 296 491 minecraft:bone_block
fill 275 296 492 275 296 495 minecraft:brown_terracotta
setblock 275 296 496 minecraft:bone_block
fill 275 296 497 276 296 499 minecraft:brown_terracotta
setblock 276 296 465 minecraft:bone_block
fill 276 296 466 276 299 466 minecraft:brown_terracotta
setblock 276 296 470 minecraft:bone_block
fill 276 296 471 276 299 471 minecraft:brown_terracotta
fill 276 296 473 276 296 474 minecraft:brown_terracotta
setblock 276 296 485 minecraft:bone_block
fill 276 296 486 276 299 486 minecraft:brown_terracotta
setblock 276 296 490 minecraft:bone_block
fill 276 296 491 276 296 494 minecraft:brown_terracotta
setblock 276 296 495 minecraft:bone_block
fill 276 296 496 276 299 496 minecraft:brown_terracotta
setblock 276 296 500 minecraft:bone_block
fill 276 296 501 276 299 501 minecraft:brown_terracotta
fill 236 297 465 236 297 468 minecraft:brown_terracotta
setblock 236 297 469 minecraft:bone_block
fill 236 297 470 236 297 473 minecraft:brown_terracotta
setblock 236 297 474 minecraft:bone_block
fill 236 297 475 236 297 478 minecraft:brown_terracotta
setblock 236 297 479 minecraft:bone_block
fill 236 297 480 237 299 480 minecraft:brown_terracotta
setblock 236 297 484 minecraft:bone_block
fill 236 297 485 236 300 485 minecraft:brown_terracotta
setblock 236 297 489 minecraft:bone_block
fill 236 297 490 236 300 490 minecraft:brown_terracotta
setblock 236 297 494 minecraft:bone_block
fill 236 297 495 236 300 495 minecraft:brown_terracotta
setblock 236 297 499 minecraft:bone_block
fill 236 297 500 237 299 500 minecraft:brown_terracotta
fill 236 297 502 236 297 503 minecraft:brown_terracotta
fill 237 297 464 240 297 464 minecraft:brown_terracotta
setblock 237 297 467 minecraft:brown_terracotta
setblock 237 297 468 minecraft:bone_block
fill 237 297 469 238 299 469 minecraft:brown_terracotta
setblock 237 297 473 minecraft:bone_block
fill 237 297 474 238 299 474 minecraft:brown_terracotta
setblock 237 297 477 minecraft:brown_terracotta
setblock 237 297 478 minecraft:bone_block
fill 237 297 479 237 300 479 minecraft:brown_terracotta
fill 237 297 481 237 297 482 minecraft:brown_terracotta
setblock 237 297 483 minecraft:bone_block
fill 237 297 484 238 299 484 minecraft:brown_terracotta
setblock 237 297 488 minecraft:bone_block
fill 237 297 489 237 300 489 minecraft:brown_terracotta
setblock 237 297 493 minecraft:bone_block
fill 237 297 494 237 300 494 minecraft:brown_terracotta
setblock 237 297 498 minecraft:bone_block
fill 237 297 499 237 300 499 minecraft:brown_terracotta
fill 237 297 504 237 300 504 minecraft:brown_terracotta
fill 238 297 470 238 297 471 minecraft:brown_terracotta
setblock 238 297 472 minecraft:bone_block
fill 238 297 473 238 300 473 minecraft:brown_terracotta
fill 238 297 475 238 297 476 minecraft:brown_terracotta
setblock 238 297 487 minecraft:bone_block
fill 238 297 488 238 300 488 minecraft:brown_terracotta
setblock 238 297 491 minecraft:brown_terracotta
setblock 238 297 492 minecraft:bone_block
fill 238 297 493 238 300 493 minecraft:brown_terracotta
setblock 238 297 496 minecraft:brown_terracotta
setblock 238 297 497 minecraft:bone_block
fill 238 297 498 238 300 498 minecraft:brown_terracotta
fill 239 297 487 239 298 487 minecraft:brown_terracotta
setblock 239 297 491 minecraft:bone_block
fill 239 297 492 239 300 492 minecraft:brown_terracotta
setblock 239 297 495 minecraft:brown_terracotta
setblock 240 297 465 minecraft:bone_block
setblock 241 297 464 minecraft:bone_block
setblock 241 297 465 minecraft:brown_terracotta
fill 242 297 464 242 299 464 minecraft:brown_terracotta
fill 252 297 464 255 297 464 minecraft:brown_terracotta
setblock 254 297 465 minecraft:brown_terracotta
setblock 255 297 465 minecraft:bone_block
fill 255 297 466 255 300 466 minecraft:brown_terracotta
setblock 256 297 464 minecraft:bone_block
fill 256 297 465 259 297 465 minecraft:brown_terracotta
setblock 256 297 504 minecraft:bone_block
fill 257 297 464 260 297 464 minecraft:brown_terracotta
fill 257 297 504 260 297 504 minecraft:brown_terracotta
setblock 258 297 467 minecraft:bone_block
setblock 259 297 466 minecraft:bone_block
fill 259 297 467 259 300 467 minecraft:brown_terracotta
fill 259 297 503 261 297 503 minecraft:brown_terracotta
setblock 260 297 465 minecraft:bone_block
fill 260 297 466 260 300 466 minecraft:brown_terracotta
setblock 261 297 464 minecraft:bone_block
fill 261 297 465 261 300 465 minecraft:brown_terracotta
setblock 261 297 504 minecraft:bone_block
fill 262 297 464 262 300 464 minecraft:brown_terracotta
setblock 262 297 503 minecraft:bone_block
fill 262 297 504 262 300 504 minecraft:brown_terracotta
setblock 263 297 467 minecraft:bone_block
fill 263 297 503 263 300 503 minecraft:brown_terracotta
setblock 264 297 466 minecraft:bone_block
setblock 265 297 465 minecraft:bone_block
setblock 265 297 466 minecraft:brown_terracotta
setblock 266 297 464 minecraft:bone_block
fill 266 297 465 266 298 465 minecraft:brown_terracotta
setblock 266 297 504 minecraft:bone_block
fill 267 297 464 267 299 464 minecraft:brown_terracotta
fill 267 297 504 267 300 504 minecraft:brown_terracotta
fill 272 297 504 273 299 504 minecraft:brown_terracotta
fill 274 297 464 274 298 464 minecraft:brown_terracotta
setblock 274 297 491 minecraft:bone_block
fill 274 297 492 274 297 495 minecraft:brown_terracotta
setblock 274 297 496 minecraft:bone_block
setblock 275 297 469 minecraft:brown_terracotta
setblock 275 297 470 minecraft:bone_block
fill 275 297 488 275 297 489 minecraft:brown_terracotta
setblock 275 297 490 minecraft:bone_block
fill 275 297 491 275 297 494 minecraft:brown_terracotta
setblock 275 297 495 minecraft:bone_block
fill 275 297 496 275 297 499 minecraft:brown_terracotta
setblock 275 297 500 minecraft:bone_block
fill 275 297 501 275 300 501 minecraft:brown_terracotta
setblock 276 297 464 minecraft:bone_block
fill 276 297 465 276 300 465 minecraft:brown_terracotta
setblock 276 297 469 minecraft:bone_block
fill 276 297 470 276 300 470 minecraft:brown_terracotta
setblock 276 297 473 minecraft:brown_terracotta
setblock 276 297 474 minecraft:bone_block
fill 276 297 475 276 298 477 minecraft:brown_terracotta
setblock 276 297 484 minecraft:bone_block
fill 276 297 485 276 300 485 minecraft:brown_terracotta
setblock 276 297 489 minecraft:bone_block
fill 276 297 490 276 297 493 minecraft:brown_terracotta
setblock 276 297 494 minecraft:bone_block
fill 276 297 495 276 300 495 minecraft:brown_terracotta
fill 276 297 497 276 297 498 minecraft:brown_terracotta
setblock 276 297 499 minecraft:bone_block
fill 276 297 500 276 300 500 minecraft:brown_terracotta
setblock 276 297 504 minecraft:bone_block
fill 236 298 465 236 298 467 minecraft:brown_terracotta
setblock 236 298 468 minecraft:bone_block
fill 236 298 469 236 298 472 minecraft:brown_terracotta
setblock 236 298 473 minecraft:bone_block
fill 236 298 474 236 298 477 minecraft:brown_terracotta
setblock 236 298 478 minecraft:bone_block
fill 236 298 479 236 300 479 minecraft:brown_terracotta
setblock 236 298 483 minecraft:bone_block
fill 236 298 484 236 300 484 minecraft:brown_terracotta
setblock 236 298 488 minecraft:bone_block
fill 236 298 489 236 300 489 minecraft:brown_terracotta
setblock 236 298 493 minecraft:bone_block
fill 236 298 494 236 300 494 minecraft:brown_terracotta
setblock 236 298 497 minecraft:brown_terracotta
setblock 236 298 498 minecraft:bone_block
fill 236 298 499 236 300 499 minecraft:brown_terracotta
setblock 236 298 502 minecraft:brown_terracotta
setblock 236 298 503 minecraft:bone_block
fill 236 298 504 236 300 504 minecraft:brown_terracotta
fill 237 298 464 239 298 464 minecraft:brown_terracotta
setblock 237 298 467 minecraft:bone_block
fill 237 298 468 237 300 468 minecraft:brown_terracotta
setblock 237 298 471 minecraft:brown_terracotta
setblock 237 298 472 minecraft:bone_block
fill 237 298 473 237 300 473 minecraft:brown_terracotta
setblock 237 298 477 minecraft:bone_block
fill 237 298 478 238 300 478 minecraft:brown_terracotta
setblock 237 298 481 minecraft:brown_terracotta
setblock 237 298 482 minecraft:bone_block
fill 237 298 483 238 300 483 minecraft:brown_terracotta
setblock 237 298 487 minecraft:bone_block
fill 237 298 488 237 300 488 minecraft:brown_terracotta
setblock 237 298 492 minecraft:bone_block
fill 237 298 493 237 300 493 minecraft:brown_terracotta
setblock 237 298 497 minecraft:bone_block
fill 237 298 498 237 300 498 minecraft:brown_terracotta
setblock 237 298 501 minecraft:brown_terracotta
setblock 238 298 470 minecraft:brown_terracotta
setblock 238 298 471 minecraft:bone_block
fill 238 298 472 239 300 472 minecraft:brown_terracotta
setblock 238 298 475 minecraft:brown_terracotta
setblock 238 298 476 minecraft:bone_block
fill 238 298 477 238 300 477 minecraft:brown_terracotta
fill 238 298 479 238 298 480 minecraft:brown_terracotta
setblock 238 298 486 minecraft:bone_block
fill 238 298 487 238 300 487 minecraft:brown_terracotta
setblock 238 298 491 minecraft:bone_block
fill 238 298 492 238 300 492 minecraft:brown_terracotta
setblock 238 298 496 minecraft:bone_block
fill 238 298 497 238 300 497 minecraft:brown_terracotta
fill 239 298 473 239 298 474 minecraft:brown_terracotta
setblock 239 298 475 minecraft:bone_block
setblock 239 298 490 minecraft:bone_block
fill 239 298 491 239 300 491 minecraft:brown_terracotta
setblock 239 298 495 minecraft:bone_block
fill 239 298 496 239 300 496 minecraft:brown_terracotta
setblock 240 298 464 minecraft:bone_block
setblock 240 298 504 minecraft:bone_block
fill 241 298 464 241 300 464 minecraft:brown_terracotta
fill 252 298 464 254 298 464 minecraft:brown_terracotta
setblock 253 298 465 minecraft:brown_terracotta
setblock 254 298 465 minecraft:bone_block
setblock 255 298 464 minecraft:bone_block
fill 255 298 465 258 298 465 minecraft:brown_terracotta
fill 256 298 464 259 298 464 minecraft:brown_terracotta
setblock 256 298 467 minecraft:brown_terracotta
fill 256 298 504 259 298 504 minecraft:brown_terracotta
setblock 257 298 467 minecraft:bone_block
setblock 258 298 466 minecraft:bone_block
fill 258 298 467 258 300 467 minecraft:brown_terracotta
fill 258 298 503 260 298 503 minecraft:brown_terracotta
setblock 259 298 465 minecraft:bone_block
fill 259 298 466 259 300 466 minecraft:brown_terracotta
setblock 260 298 464 minecraft:bone_block
fill 260 298 465 260 300 465 minecraft:brown_terracotta
setblock 260 298 504 minecraft:bone_block
fill 261 298 464 261 300 464 minecraft:brown_terracotta
setblock 261 298 503 minecraft:bone_block
fill 261 298 504 261 300 504 minecraft:brown_terracotta
setblock 262 298 467 minecraft:bone_block
fill 262 298 503 262 300 503 minecraft:brown_terracotta
setblock 263 298 466 minecraft:bone_block
setblock 264 298 465 minecraft:bone_block
setblock 264 298 466 minecraft:brown_terracotta
fill 264 298 503 264 299 503 minecraft:brown_terracotta
setblock 265 298 464 minecraft:bone_block
fill 265 298 465 265 299 465 minecraft:brown_terracotta
setblock 265 298 504 minecraft:bone_block
fill 266 298 464 266 300 464 minecraft:brown_terracotta
fill 266 298 504 266 300 504 minecraft:brown_terracotta
setblock 269 298 504 minecraft:brown_terracotta
setblock 270 298 504 minecraft:bone_block
fill 271 298 504 271 300 504 minecraft:brown_terracotta
setblock 274 298 490 minecraft:bone_block
fill 274 298 491 274 298 494 minecraft:brown_terracotta
setblock 274 298 495 minecraft:bone_block
fill 274 298 496 275 298 498 minecraft:brown_terracotta
setblock 275 298 464 minecraft:bone_block
setblock 275 298 469 minecraft:bone_block
fill 275 298 470 275 298 473 minecraft:brown_terracotta
fill 275 298 487 275 298 488 minecraft:brown_terracotta
setblock 275 298 489 minecraft:bone_block
fill 275 298 490 275 298 493 minecraft:brown_terracotta
setblock 275 298 494 minecraft:bone_block
fill 275 298 495 275 300 495 minecraft:brown_terracotta
setblock 275 298 499 minecraft:bone_block
fill 275 298 500 275 300 500 minecraft:brown_terracotta
fill 275 298 502 275 298 503 minecraft:brown_terracotta
setblock 275 298 504 minecraft:bone_block
fill 276 298 464 276 300 464 minecraft:brown_terracotta
setblock 276 298 468 minecraft:bone_block
fill 276 298 469 276 300 469 minecraft:brown_terracotta
setblock 276 298 473 minecraft:bone_block
fill 276 298 474 276 300 474 minecraft:brown_terracotta
setblock 276 298 478 minecraft:bone_block
fill 276 298 479 276 298 482 minecraft:brown_terracotta
setblock 276 298 483 minecraft:bone_block
fill 276 298 484 276 300 484 minecraft:brown_terracotta
setblock 276 298 488 minecraft:bone_block
fill 276 298 489 276 298 492 minecraft:brown_terracotta
setblock 276 298 493 minecraft:bone_block
fill 276 298 494 276 300 494 minecraft:brown_terracotta
setblock 276 298 497 minecraft:brown_terracotta
setblock 276 298 498 minecraft:bone_block
fill 276 298 499 276 300 499 minecraft:brown_terracotta
setblock 276 298 503 minecraft:bone_block
fill 276 298 504 276 300 504 minecraft:brown_terracotta
fill 236 299 464 236 299 466 minecraft:brown_terracotta
setblock 236 299 467 minecraft:bone_block
fill 236 299 468 236 299 471 minecraft:brown_terracotta
setblock 236 299 472 minecraft:bone_block
fill 236 299 473 236 299 476 minecraft:brown_terracotta
setblock 236 299 477 minecraft:bone_block
fill 236 299 478 236 300 478 minecraft:brown_terracotta
setblock 236 299 482 minecraft:bone_block
fill 236 299 483 236 300 483 minecraft:brown_terracotta
setblock 236 299 487 minecraft:bone_block
fill 236 299 488 236 300 488 minecraft:brown_terracotta
setblock 236 299 492 minecraft:bone_block
fill 236 299 493 236 300 493 minecraft:brown_terracotta
setblock 236 299 497 minecraft:bone_block
fill 236 299 498 236 300 498 minecraft:brown_terracotta
setblock 236 299 502 minecraft:bone_block
fill 236 299 503 236 300 503 minecraft:brown_terracotta
fill 237 299 464 238 299 464 minecraft:brown_terracotta
fill 237 299 467 237 300 467 minecraft:brown_terracotta
setblock 237 299 471 minecraft:bone_block
fill 237 299 472 237 300 472 minecraft:brown_terracotta
setblock 237 299 475 minecraft:brown_terracotta
setblock 237 299 476 minecraft:bone_block
fill 237 299 477 237 300 477 minecraft:brown_terracotta
setblock 237 299 481 minecraft:bone_block
fill 237 299 482 238 300 482 minecraft:brown_terracotta
setblock 237 299 486 minecraft:bone_block
fill 237 299 487 237 300 487 minecraft:brown_terracotta
setblock 237 299 491 minecraft:bone_block
fill 237 299 492 237 300 492 minecraft:brown_terracotta
setblock 237 299 496 minecraft:bone_block
fill 237 299 497 237 300 497 minecraft:brown_terracotta
setblock 237 299 501 minecraft:bone_block
setblock 238 299 466 minecraft:light[level=12]
setblock 238 299 470 minecraft:bone_block
fill 238 299 471 239 299 471 minecraft:brown_terracotta
setblock 238 299 475 minecraft:bone_block
fill 238 299 476 239 300 476 minecraft:brown_terracotta
setblock 238 299 479 minecraft:brown_terracotta
setblock 238 299 480 minecraft:bone_block
fill 238 299 481 238 300 481 minecraft:brown_terracotta
setblock 238 299 485 minecraft:bone_block
fill 238 299 486 238 300 486 minecraft:brown_terracotta
setblock 238 299 490 minecraft:bone_block
fill 238 299 491 238 300 491 minecraft:brown_terracotta
setblock 238 299 494 minecraft:brown_terracotta
setblock 238 299 495 minecraft:bone_block
fill 238 299 496 238 300 496 minecraft:brown_terracotta
setblock 238 299 499 minecraft:brown_terracotta
setblock 238 299 504 minecraft:brown_terracotta
setblock 239 299 464 minecraft:bone_block
setblock 239 299 473 minecraft:brown_terracotta
setblock 239 299 474 minecraft:bone_block
fill 239 299 475 239 300 475 minecraft:brown_terracotta
fill 239 299 477 239 300 477 minecraft:brown_terracotta
setblock 239 299 489 minecraft:bone_block
fill 239 299 490 239 300 490 minecraft:brown_terracotta
setblock 239 299 494 minecraft:bone_block
fill 239 299 495 239 300 495 minecraft:brown_terracotta
setblock 239 299 504 minecraft:bone_block
fill 240 299 464 240 300 464 minecraft:brown_terracotta
setblock 240 299 504 minecraft:brown_terracotta
setblock 246 299 466 minecraft:light[level=12]
setblock 246 299 474 minecraft:light[level=12]
setblock 246 299 482 minecraft:light[level=12]
setblock 246 299 490 minecraft:light[level=12]
setblock 246 299 498 minecraft:light[level=12]
fill 252 299 464 253 299 464 minecraft:brown_terracotta
setblock 253 299 465 minecraft:bone_block
setblock 254 299 464 minecraft:bone_block
fill 254 299 465 257 299 465 minecraft:brown_terracotta
setblock 254 299 466 minecraft:light[level=12]
setblock 254 299 474 minecraft:light[level=12]
setblock 254 299 482 minecraft:light[level=12]
setblock 254 299 490 minecraft:light[level=12]
setblock 254 299 498 minecraft:light[level=12]
fill 255 299 464 258 299 464 minecraft:brown_terracotta
fill 255 299 504 258 299 504 minecraft:brown_terracotta
setblock 257 299 466 minecraft:bone_block
fill 257 299 467 257 300 467 minecraft:brown_terracotta
fill 257 299 503 259 299 503 minecraft:brown_terracotta
setblock 258 299 465 minecraft:bone_block
fill 258 299 466 258 300 466 minecraft:brown_terracotta
setblock 259 299 464 minecraft:bone_block
fill 259 299 465 259 300 465 minecraft:brown_terracotta
setblock 259 299 504 minecraft:bone_block
fill 260 299 464 260 300 464 minecraft:brown_terracotta
setblock 260 299 503 minecraft:bone_block
fill 260 299 504 260 300 504 minecraft:brown_terracotta
setblock 261 299 467 minecraft:bone_block
fill 261 299 503 261 300 503 minecraft:brown_terracotta
setblock 262 299 466 minecraft:bone_block
setblock 262 299 474 minecraft:light[level=12]
setblock 262 299 482 minecraft:light[level=12]
setblock 262 299 490 minecraft:light[level=12]
setblock 262 299 498 minecraft:light[level=12]
setblock 263 299 465 minecraft:bone_block
setblock 263 299 466 minecraft:brown_terracotta
setblock 264 299 464 minecraft:bone_block
setblock 264 299 465 minecraft:brown_terracotta
setblock 264 299 504 minecraft:bone_block
fill 265 299 464 265 300 464 minecraft:brown_terracotta
fill 265 299 504 265 300 504 minecraft:brown_terracotta
setblock 269 299 504 minecraft:bone_block
setblock 270 299 466 minecraft:light[level=12]
setblock 270 299 474 minecraft:light[level=12]
setblock 270 299 482 minecraft:light[level=12]
setblock 270 299 490 minecraft:light[level=12]
setblock 270 299 498 minecraft:light[level=12]
fill 270 299 504 270 300 504 minecraft:brown_terracotta
setblock 274 299 464 minecraft:bone_block
fill 274 299 490 274 299 493 minecraft:brown_terracotta
setblock 274 299 494 minecraft:bone_block
fill 274 299 495 274 299 498 minecraft:brown_terracotta
setblock 274 299 499 minecraft:bone_block
setblock 274 299 503 minecraft:brown_terracotta
setblock 274 299 504 minecraft:bone_block
fill 275 299 464 275 300 464 minecraft:brown_terracotta
fill 275 299 469 275 299 472 minecraft:brown_terracotta
setblock 275 299 473 minecraft:bone_block
fill 275 299 474 275 300 475 minecraft:brown_terracotta
setblock 275 299 487 minecraft:brown_terracotta
setblock 275 299 488 minecraft:bone_block
fill 275 299 489 275 299 492 minecraft:brown_terracotta
setblock 275 299 493 minecraft:bone_block
fill 275 299 494 275 300 494 minecraft:brown_terracotta
fill 275 299 496 275 299 497 minecraft:brown_terracotta
setblock 275 299 498 minecraft:bone_block
fill 275 299 499 275 300 499 minecraft:brown_terracotta
setblock 275 299 502 minecraft:brown_terracotta
setblock 275 299 503 minecraft:bone_block
fill 275 299 504 275 300 504 minecraft:brown_terracotta
setblock 276 299 467 minecraft:bone_block
fill 276 299 468 276 300 468 minecraft:brown_terracotta
setblock 276 299 472 minecraft:bone_block
fill 276 299 473 276 300 473 minecraft:brown_terracotta
fill 276 299 475 276 299 476 minecraft:brown_terracotta
setblock 276 299 477 minecraft:bone_block
fill 276 299 478 276 299 481 minecraft:brown_terracotta
setblock 276 299 482 minecraft:bone_block
fill 276 299 483 276 300 483 minecraft:brown_terracotta
setblock 276 299 487 minecraft:bone_block
fill 276 299 488 276 299 491 minecraft:brown_terracotta
setblock 276 299 492 minecraft:bone_block
fill 276 299 493 276 300 493 minecraft:brown_terracotta
setblock 276 299 497 minecraft:bone_block
fill 276 299 498 276 300 498 minecraft:brown_terracotta
setblock 276 299 502 minecraft:bone_block
fill 276 299 503 276 300 503 minecraft:brown_terracotta
setblock 236 300 465 minecraft:brown_terracotta
setblock 236 300 466 minecraft:bone_block
fill 236 300 467 236 300 470 minecraft:brown_terracotta
setblock 236 300 471 minecraft:bone_block
fill 236 300 472 236 300 475 minecraft:brown_terracotta
setblock 236 300 476 minecraft:bone_block
setblock 236 300 477 minecraft:brown_terracotta
setblock 236 300 480 minecraft:brown_terracotta
setblock 236 300 481 minecraft:bone_block
setblock 236 300 482 minecraft:brown_terracotta
setblock 236 300 486 minecraft:bone_block
setblock 236 300 487 minecraft:brown_terracotta
setblock 236 300 491 minecraft:bone_block
setblock 236 300 492 minecraft:brown_terracotta
setblock 236 300 496 minecraft:bone_block
setblock 236 300 497 minecraft:brown_terracotta
setblock 236 300 500 minecraft:brown_terracotta
setblock 236 300 501 minecraft:bone_block
fill 236 300 502 237 300 502 minecraft:brown_terracotta
setblock 237 300 464 minecraft:brown_terracotta
setblock 237 300 469 minecraft:brown_terracotta
setblock 237 300 470 minecraft:bone_block
fill 237 300 471 238 300 471 minecraft:brown_terracotta
setblock 237 300 474 minecraft:brown_terracotta
setblock 237 300 475 minecraft:bone_block
setblock 237 300 476 minecraft:brown_terracotta
setblock 237 300 480 minecraft:bone_block
setblock 237 300 481 minecraft:brown_terracotta
setblock 237 300 484 minecraft:brown_terracotta
setblock 237 300 485 minecraft:bone_block
setblock 237 300 486 minecraft:brown_terracotta
setblock 237 300 490 minecraft:bone_block
setblock 237 300 491 minecraft:brown_terracotta
setblock 237 300 495 minecraft:bone_block
setblock 237 300 496 minecraft:brown_terracotta
setblock 237 300 500 minecraft:bone_block
setblock 237 300 501 minecraft:brown_terracotta
setblock 238 300 464 minecraft:bone_block
setblock 238 300 469 minecraft:bone_block
setblock 238 300 470 minecraft:brown_terracotta
setblock 238 300 474 minecraft:bone_block
setblock 238 300 475 minecraft:brown_terracotta
setblock 238 300 479 minecraft:bone_block
setblock 238 300 480 minecraft:brown_terracotta
setblock 238 300 484 minecraft:bone_block
setblock 238 300 485 minecraft:brown_terracotta
setblock 238 300 489 minecraft:bone_block
setblock 238 300 490 minecraft:brown_terracotta
setblock 238 300 494 minecraft:bone_block
setblock 238 300 495 minecraft:brown_terracotta
setblock 238 300 499 minecraft:bone_block
setblock 238 300 504 minecraft:bone_block
setblock 239 300 464 minecraft:brown_terracotta
setblock 239 300 473 minecraft:bone_block
setblock 239 300 474 minecraft:brown_terracotta
setblock 239 300 478 minecraft:bone_block
setblock 239 300 493 minecraft:bone_block
setblock 239 300 494 minecraft:brown_terracotta
setblock 239 300 504 minecraft:brown_terracotta
setblock 252 300 464 minecraft:brown_terracotta
setblock 253 300 464 minecraft:bone_block
fill 253 300 465 256 300 465 minecraft:brown_terracotta
fill 254 300 464 257 300 464 minecraft:brown_terracotta
fill 254 300 504 257 300 504 minecraft:brown_terracotta
setblock 256 300 466 minecraft:bone_block
fill 256 300 503 258 300 503 minecraft:brown_terracotta
setblock 257 300 465 minecraft:bone_block
setblock 257 300 466 minecraft:brown_terracotta
setblock 258 300 464 minecraft:bone_block
setblock 258 300 465 minecraft:brown_terracotta
setblock 258 300 504 minecraft:bone_block
setblock 259 300 464 minecraft:brown_terracotta
setblock 259 300 503 minecraft:bone_block
setblock 259 300 504 minecraft:brown_terracotta
setblock 260 300 503 minecraft:brown_terracotta
setblock 261 300 466 minecraft:bone_block
setblock 262 300 465 minecraft:bone_block
setblock 263 300 464 minecraft:bone_block
setblock 263 300 465 minecraft:brown_terracotta
setblock 263 300 504 minecraft:bone_block
setblock 264 300 464 minecraft:brown_terracotta
setblock 264 300 504 minecraft:brown_terracotta
setblock 268 300 504 minecraft:bone_block
setblock 269 300 504 minecraft:brown_terracotta
setblock 272 300 504 minecraft:brown_terracotta
setblock 273 300 504 minecraft:bone_block
fill 274 300 490 274 300 492 minecraft:brown_terracotta
setblock 274 300 493 minecraft:bone_block
fill 274 300 494 274 300 497 minecraft:brown_terracotta
setblock 274 300 498 minecraft:bone_block
fill 274 300 499 274 300 500 minecraft:brown_terracotta
setblock 274 300 503 minecraft:bone_block
setblock 274 300 504 minecraft:brown_terracotta
fill 275 300 469 275 300 471 minecraft:brown_terracotta
setblock 275 300 472 minecraft:bone_block
setblock 275 300 473 minecraft:brown_terracotta
setblock 275 300 476 minecraft:brown_terracotta
setblock 275 300 477 minecraft:bone_block
setblock 275 300 487 minecraft:bone_block
fill 275 300 488 275 300 491 minecraft:brown_terracotta
setblock 275 300 492 minecraft:bone_block
setblock 275 300 493 minecraft:brown_terracotta
setblock 275 300 496 minecraft:brown_terracotta
setblock 275 300 497 minecraft:bone_block
setblock 275 300 498 minecraft:brown_terracotta
setblock 275 300 502 minecraft:bone_block
setblock 275 300 503 minecraft:brown_terracotta
setblock 276 300 466 minecraft:bone_block
setblock 276 300 467 minecraft:brown_terracotta
setblock 276 300 471 minecraft:bone_block
setblock 276 300 472 minecraft:brown_terracotta
setblock 276 300 475 minecraft:brown_terracotta
setblock 276 300 476 minecraft:bone_block
fill 276 300 477 276 300 480 minecraft:brown_terracotta
setblock 276 300 481 minecraft:bone_block
setblock 276 300 482 minecraft:brown_terracotta
setblock 276 300 486 minecraft:bone_block
fill 276 300 487 276 300 490 minecraft:brown_terracotta
setblock 276 300 491 minecraft:bone_block
setblock 276 300 492 minecraft:brown_terracotta
setblock 276 300 496 minecraft:bone_block
setblock 276 300 497 minecraft:brown_terracotta
setblock 276 300 501 minecraft:bone_block
setblock 276 300 502 minecraft:brown_terracotta
