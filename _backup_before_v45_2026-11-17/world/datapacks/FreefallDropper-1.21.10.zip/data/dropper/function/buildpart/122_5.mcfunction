setblock 123 128 547 minecraft:smooth_basalt
fill 123 128 548 123 130 548 minecraft:blackstone
setblock 124 128 511 minecraft:smooth_basalt
setblock 124 128 551 minecraft:smooth_basalt
fill 125 128 511 125 131 511 minecraft:blackstone
fill 125 128 537 126 129 537 minecraft:gold_block
setblock 125 128 550 minecraft:smooth_basalt
fill 125 128 551 125 131 551 minecraft:blackstone
setblock 126 128 549 minecraft:smooth_basalt
fill 126 128 550 126 131 550 minecraft:blackstone
fill 127 128 549 127 129 549 minecraft:blackstone
setblock 129 128 513 minecraft:light[level=12]
setblock 129 128 521 minecraft:light[level=12]
setblock 129 128 529 minecraft:light[level=12]
setblock 129 128 537 minecraft:light[level=12]
setblock 129 128 545 minecraft:light[level=12]
setblock 129 128 551 minecraft:smooth_basalt
fill 130 128 551 130 130 551 minecraft:blackstone
setblock 133 128 527 minecraft:smooth_basalt
setblock 134 128 522 minecraft:blackstone
setblock 134 128 526 minecraft:smooth_basalt
fill 134 128 527 134 131 527 minecraft:blackstone
setblock 134 128 531 minecraft:smooth_basalt
setblock 135 128 520 minecraft:smooth_basalt
fill 135 128 521 135 131 521 minecraft:blackstone
setblock 135 128 525 minecraft:smooth_basalt
fill 135 128 526 135 131 526 minecraft:blackstone
setblock 135 128 530 minecraft:smooth_basalt
fill 135 128 531 135 131 531 minecraft:blackstone
setblock 135 128 535 minecraft:smooth_basalt
setblock 135 128 545 minecraft:smooth_basalt
fill 135 128 546 135 130 546 minecraft:blackstone
setblock 135 128 550 minecraft:smooth_basalt
setblock 95 129 514 minecraft:smooth_basalt
fill 95 129 515 95 132 515 minecraft:blackstone
setblock 95 129 519 minecraft:smooth_basalt
fill 95 129 520 95 132 520 minecraft:blackstone
setblock 95 129 524 minecraft:smooth_basalt
fill 95 129 525 95 132 525 minecraft:blackstone
setblock 95 129 529 minecraft:smooth_basalt
fill 95 129 530 95 132 530 minecraft:blackstone
fill 95 129 546 95 129 548 minecraft:blackstone
setblock 95 129 549 minecraft:smooth_basalt
fill 95 129 550 95 131 551 minecraft:blackstone
setblock 96 129 519 minecraft:blackstone
setblock 96 129 523 minecraft:smooth_basalt
fill 96 129 524 96 132 524 minecraft:blackstone
setblock 96 129 527 minecraft:blackstone
setblock 96 129 528 minecraft:smooth_basalt
fill 96 129 529 97 130 529 minecraft:blackstone
fill 96 129 531 96 130 531 minecraft:blackstone
fill 96 129 551 97 129 551 minecraft:blackstone
setblock 97 129 512 minecraft:smooth_basalt
setblock 97 129 522 minecraft:smooth_basalt
fill 97 129 523 97 130 523 minecraft:blackstone
setblock 97 129 527 minecraft:smooth_basalt
fill 97 129 528 97 131 528 minecraft:blackstone
fill 97 129 550 98 129 550 minecraft:blackstone
setblock 98 129 511 minecraft:smooth_basalt
fill 98 129 512 98 132 512 minecraft:blackstone
setblock 98 129 551 minecraft:smooth_basalt
fill 99 129 511 99 132 511 minecraft:blackstone
setblock 99 129 549 minecraft:blackstone
setblock 99 129 550 minecraft:smooth_basalt
fill 99 129 551 99 132 551 minecraft:blackstone
setblock 100 129 513 minecraft:blackstone
setblock 100 129 549 minecraft:smooth_basalt
fill 100 129 550 100 132 550 minecraft:blackstone
setblock 101 129 513 minecraft:smooth_basalt
fill 101 129 549 101 132 549 minecraft:blackstone
setblock 102 129 512 minecraft:smooth_basalt
fill 102 129 513 102 132 513 minecraft:blackstone
setblock 103 129 511 minecraft:smooth_basalt
fill 103 129 512 103 132 512 minecraft:blackstone
setblock 103 129 551 minecraft:smooth_basalt
fill 104 129 511 104 132 511 minecraft:blackstone
setblock 104 129 548 minecraft:blackstone
setblock 104 129 550 minecraft:smooth_basalt
fill 104 129 551 104 132 551 minecraft:blackstone
setblock 105 129 549 minecraft:smooth_basalt
fill 105 129 550 105 132 550 minecraft:blackstone
fill 106 129 549 106 131 549 minecraft:blackstone
setblock 107 129 512 minecraft:smooth_basalt
setblock 108 129 511 minecraft:smooth_basalt
setblock 108 129 512 minecraft:blackstone
setblock 108 129 551 minecraft:smooth_basalt
fill 109 129 511 109 132 511 minecraft:blackstone
setblock 109 129 549 minecraft:blackstone
setblock 109 129 550 minecraft:smooth_basalt
fill 109 129 551 112 129 551 minecraft:blackstone
setblock 110 129 549 minecraft:smooth_basalt
fill 110 129 550 113 129 550 minecraft:blackstone
fill 111 129 549 114 129 549 minecraft:blackstone
setblock 113 129 511 minecraft:smooth_basalt
setblock 113 129 551 minecraft:smooth_basalt
fill 114 129 511 117 129 511 minecraft:blackstone
setblock 114 129 550 minecraft:smooth_basalt
fill 114 129 551 114 132 551 minecraft:blackstone
setblock 115 129 549 minecraft:smooth_basalt
fill 115 129 550 118 129 550 minecraft:blackstone
fill 116 129 549 119 129 549 minecraft:blackstone
fill 117 129 548 120 129 548 minecraft:blackstone
setblock 118 129 511 minecraft:smooth_basalt
setblock 118 129 551 minecraft:smooth_basalt
fill 119 129 511 119 132 511 minecraft:blackstone
setblock 119 129 550 minecraft:smooth_basalt
fill 119 129 551 119 132 551 minecraft:blackstone
setblock 120 129 549 minecraft:smooth_basalt
fill 120 129 550 120 132 550 minecraft:blackstone
fill 121 129 547 121 129 548 minecraft:smooth_basalt
fill 121 129 549 121 132 549 minecraft:blackstone
fill 122 129 548 122 131 548 minecraft:blackstone
setblock 123 129 511 minecraft:smooth_basalt
setblock 123 129 551 minecraft:smooth_basalt
fill 124 129 511 124 132 511 minecraft:blackstone
setblock 124 129 550 minecraft:smooth_basalt
fill 124 129 551 124 132 551 minecraft:blackstone
setblock 125 129 549 minecraft:smooth_basalt
fill 125 129 550 125 132 550 minecraft:blackstone
fill 126 129 511 126 130 511 minecraft:blackstone
fill 126 129 549 126 130 549 minecraft:blackstone
setblock 128 129 551 minecraft:smooth_basalt
setblock 129 129 550 minecraft:smooth_basalt
fill 129 129 551 129 131 551 minecraft:blackstone
setblock 134 129 525 minecraft:smooth_basalt
fill 134 129 526 134 132 526 minecraft:blackstone
setblock 134 129 529 minecraft:blackstone
setblock 134 129 530 minecraft:smooth_basalt
fill 134 129 531 134 131 532 minecraft:blackstone
fill 135 129 520 135 130 520 minecraft:blackstone
setblock 135 129 524 minecraft:smooth_basalt
fill 135 129 525 135 132 525 minecraft:blackstone
setblock 135 129 529 minecraft:smooth_basalt
fill 135 129 530 135 132 530 minecraft:blackstone
setblock 135 129 533 minecraft:blackstone
setblock 135 129 534 minecraft:smooth_basalt
fill 135 129 535 135 132 535 minecraft:blackstone
setblock 135 129 544 minecraft:smooth_basalt
setblock 135 129 545 minecraft:blackstone
setblock 135 129 549 minecraft:smooth_basalt
fill 135 129 550 135 132 550 minecraft:blackstone
fill 95 130 511 95 130 512 minecraft:blackstone
setblock 95 130 513 minecraft:smooth_basalt
fill 95 130 514 95 133 514 minecraft:blackstone
setblock 95 130 518 minecraft:smooth_basalt
fill 95 130 519 95 133 519 minecraft:blackstone
setblock 95 130 523 minecraft:smooth_basalt
fill 95 130 524 95 133 524 minecraft:blackstone
setblock 95 130 528 minecraft:smooth_basalt
fill 95 130 529 95 133 529 minecraft:blackstone
setblock 95 130 533 minecraft:smooth_basalt
setblock 95 130 547 minecraft:blackstone
setblock 95 130 548 minecraft:smooth_basalt
fill 95 130 549 95 133 549 minecraft:blackstone
setblock 96 130 512 minecraft:smooth_basalt
setblock 96 130 522 minecraft:smooth_basalt
fill 96 130 523 96 132 523 minecraft:blackstone
setblock 96 130 527 minecraft:smooth_basalt
fill 96 130 528 96 133 528 minecraft:blackstone
fill 96 130 550 96 130 551 minecraft:blackstone
setblock 97 130 511 minecraft:smooth_basalt
fill 97 130 512 97 133 512 minecraft:blackstone
setblock 97 130 526 minecraft:smooth_basalt
fill 97 130 527 97 131 527 minecraft:blackstone
setblock 97 130 550 minecraft:blackstone
setblock 97 130 551 minecraft:smooth_basalt
fill 98 130 511 98 133 511 minecraft:blackstone
setblock 98 130 550 minecraft:smooth_basalt
fill 98 130 551 98 133 551 minecraft:blackstone
setblock 99 130 513 minecraft:blackstone
setblock 99 130 549 minecraft:smooth_basalt
fill 99 130 550 99 133 550 minecraft:blackstone
setblock 100 130 513 minecraft:smooth_basalt
fill 100 130 549 100 133 549 minecraft:blackstone
setblock 101 130 512 minecraft:smooth_basalt
fill 101 130 513 101 133 513 minecraft:blackstone
setblock 102 130 511 minecraft:smooth_basalt
fill 102 130 512 102 133 512 minecraft:blackstone
setblock 102 130 551 minecraft:smooth_basalt
fill 103 130 511 103 133 511 minecraft:blackstone
setblock 103 130 550 minecraft:smooth_basalt
fill 103 130 551 103 133 551 minecraft:blackstone
setblock 104 130 549 minecraft:smooth_basalt
fill 104 130 550 104 133 550 minecraft:blackstone
fill 105 130 549 105 132 549 minecraft:blackstone
setblock 106 130 512 minecraft:smooth_basalt
setblock 107 130 511 minecraft:smooth_basalt
fill 107 130 512 107 131 512 minecraft:blackstone
setblock 107 130 551 minecraft:smooth_basalt
fill 108 130 511 108 133 511 minecraft:blackstone
setblock 108 130 550 minecraft:smooth_basalt
fill 108 130 551 111 130 551 minecraft:blackstone
setblock 109 130 549 minecraft:smooth_basalt
fill 109 130 550 112 130 550 minecraft:blackstone
setblock 112 130 511 minecraft:smooth_basalt
setblock 112 130 551 minecraft:smooth_basalt
fill 113 130 511 116 130 511 minecraft:blackstone
setblock 113 130 550 minecraft:smooth_basalt
fill 113 130 551 113 133 551 minecraft:blackstone
setblock 114 130 549 minecraft:smooth_basalt
fill 114 130 550 117 130 550 minecraft:blackstone
fill 115 130 549 118 130 549 minecraft:blackstone
setblock 117 130 511 minecraft:smooth_basalt
setblock 117 130 551 minecraft:smooth_basalt
fill 118 130 511 118 133 511 minecraft:blackstone
fill 118 130 548 119 130 548 minecraft:blackstone
setblock 118 130 550 minecraft:smooth_basalt
fill 118 130 551 118 133 551 minecraft:blackstone
fill 119 130 546 121 132 546 minecraft:smooth_basalt
setblock 119 130 549 minecraft:smooth_basalt
fill 119 130 550 119 133 550 minecraft:blackstone
fill 120 130 545 120 132 545 minecraft:smooth_basalt
fill 120 130 547 120 130 548 minecraft:smooth_basalt
fill 120 130 549 120 133 549 minecraft:blackstone
fill 121 130 548 121 131 548 minecraft:blackstone
setblock 122 130 511 minecraft:smooth_basalt
setblock 122 130 551 minecraft:smooth_basalt
fill 123 130 511 123 133 511 minecraft:blackstone
setblock 123 130 550 minecraft:smooth_basalt
fill 123 130 551 123 133 551 minecraft:blackstone
setblock 124 130 549 minecraft:smooth_basalt
fill 124 130 550 124 133 550 minecraft:blackstone
fill 125 130 549 125 131 549 minecraft:blackstone
setblock 127 130 551 minecraft:smooth_basalt
setblock 128 130 550 minecraft:smooth_basalt
fill 128 130 551 128 132 551 minecraft:blackstone
setblock 134 130 524 minecraft:smooth_basalt
fill 134 130 525 134 133 525 minecraft:blackstone
setblock 134 130 529 minecraft:smooth_basalt
fill 134 130 530 134 133 530 minecraft:blackstone
setblock 135 130 523 minecraft:smooth_basalt
fill 135 130 524 135 133 524 minecraft:blackstone
setblock 135 130 528 minecraft:smooth_basalt
fill 135 130 529 135 133 529 minecraft:blackstone
setblock 135 130 533 minecraft:smooth_basalt
fill 135 130 534 135 133 534 minecraft:blackstone
setblock 135 130 548 minecraft:smooth_basalt
fill 135 130 549 135 131 549 minecraft:blackstone
fill 135 130 551 135 131 551 minecraft:blackstone
setblock 95 131 511 minecraft:blackstone
setblock 95 131 512 minecraft:smooth_basalt
fill 95 131 513 96 133 513 minecraft:blackstone
setblock 95 131 517 minecraft:smooth_basalt
fill 95 131 518 95 134 518 minecraft:blackstone
setblock 95 131 522 minecraft:smooth_basalt
fill 95 131 523 95 134 523 minecraft:blackstone
setblock 95 131 527 minecraft:smooth_basalt
fill 95 131 528 95 134 528 minecraft:blackstone
setblock 95 131 532 minecraft:smooth_basalt
fill 95 131 533 95 134 533 minecraft:blackstone
setblock 95 131 547 minecraft:smooth_basalt
fill 95 131 548 95 134 548 minecraft:blackstone
setblock 96 131 511 minecraft:smooth_basalt
fill 96 131 512 96 134 512 minecraft:blackstone
setblock 96 131 521 minecraft:smooth_basalt
setblock 96 131 522 minecraft:blackstone
setblock 96 131 526 minecraft:smooth_basalt
fill 96 131 527 96 134 527 minecraft:blackstone
fill 96 131 529 96 132 529 minecraft:blackstone
setblock 96 131 531 minecraft:smooth_basalt
setblock 96 131 550 minecraft:blackstone
setblock 96 131 551 minecraft:smooth_basalt
fill 97 131 511 97 134 511 minecraft:blackstone
setblock 97 131 525 minecraft:smooth_basalt
setblock 97 131 526 minecraft:blackstone
setblock 97 131 550 minecraft:smooth_basalt
fill 97 131 551 97 134 551 minecraft:blackstone
fill 98 131 550 98 134 550 minecraft:blackstone
setblock 99 131 513 minecraft:smooth_basalt
fill 99 131 549 99 132 549 minecraft:blackstone
setblock 100 131 512 minecraft:smooth_basalt
fill 100 131 513 100 134 513 minecraft:blackstone
setblock 101 131 511 minecraft:smooth_basalt
fill 101 131 512 101 134 512 minecraft:blackstone
setblock 101 131 551 minecraft:smooth_basalt
fill 102 131 511 102 134 511 minecraft:blackstone
setblock 102 131 550 minecraft:smooth_basalt
fill 102 131 551 102 134 551 minecraft:blackstone
setblock 103 131 549 minecraft:smooth_basalt
fill 103 131 550 103 134 550 minecraft:blackstone
fill 104 131 549 104 132 549 minecraft:blackstone
setblock 105 131 512 minecraft:smooth_basalt
setblock 106 131 511 minecraft:smooth_basalt
fill 106 131 512 106 133 512 minecraft:blackstone
setblock 106 131 551 minecraft:smooth_basalt
fill 107 131 511 107 134 511 minecraft:blackstone
setblock 107 131 550 minecraft:smooth_basalt
fill 107 131 551 110 131 551 minecraft:blackstone
fill 108 131 550 111 131 550 minecraft:blackstone
setblock 111 131 511 minecraft:smooth_basalt
setblock 111 131 551 minecraft:smooth_basalt
fill 112 131 511 115 131 511 minecraft:blackstone
setblock 112 131 550 minecraft:smooth_basalt
fill 112 131 551 112 134 551 minecraft:blackstone
fill 113 131 550 116 131 550 minecraft:blackstone
fill 114 131 549 117 131 549 minecraft:blackstone
setblock 116 131 511 minecraft:smooth_basalt
setblock 116 131 551 minecraft:smooth_basalt
fill 117 131 511 117 134 511 minecraft:blackstone
setblock 117 131 550 minecraft:smooth_basalt
fill 117 131 551 117 134 551 minecraft:blackstone
setblock 118 131 548 minecraft:blackstone
setblock 118 131 549 minecraft:smooth_basalt
fill 118 131 550 118 134 550 minecraft:blackstone
setblock 119 131 548 minecraft:smooth_basalt
fill 119 131 549 119 134 549 minecraft:blackstone
fill 120 131 547 120 132 547 minecraft:smooth_basalt
setblock 120 131 548 minecraft:blackstone
setblock 121 131 511 minecraft:smooth_basalt
setblock 121 131 551 minecraft:smooth_basalt
fill 122 131 511 122 134 511 minecraft:blackstone
setblock 122 131 550 minecraft:smooth_basalt
fill 122 131 551 122 134 551 minecraft:blackstone
setblock 123 131 549 minecraft:smooth_basalt
fill 123 131 550 123 134 550 minecraft:blackstone
setblock 124 131 549 minecraft:blackstone
setblock 126 131 551 minecraft:smooth_basalt
setblock 127 131 550 minecraft:smooth_basalt
fill 127 131 551 127 133 551 minecraft:blackstone
setblock 134 131 524 minecraft:blackstone
setblock 134 131 528 minecraft:smooth_basalt
fill 134 131 529 134 134 529 minecraft:blackstone
setblock 135 131 522 minecraft:smooth_basalt
fill 135 131 523 135 134 523 minecraft:blackstone
setblock 135 131 527 minecraft:smooth_basalt
fill 135 131 528 135 134 528 minecraft:blackstone
setblock 135 131 532 minecraft:smooth_basalt
fill 135 131 533 135 134 533 minecraft:blackstone
setblock 135 131 548 minecraft:blackstone
setblock 95 132 511 minecraft:smooth_basalt
fill 95 132 512 95 135 512 minecraft:blackstone
setblock 95 132 516 minecraft:smooth_basalt
fill 95 132 517 95 135 517 minecraft:blackstone
setblock 95 132 521 minecraft:smooth_basalt
fill 95 132 522 95 135 522 minecraft:blackstone
setblock 95 132 526 minecraft:smooth_basalt
fill 95 132 527 95 135 527 minecraft:blackstone
setblock 95 132 531 minecraft:smooth_basalt
fill 95 132 532 95 135 532 minecraft:blackstone
setblock 95 132 550 minecraft:blackstone
setblock 95 132 551 minecraft:smooth_basalt
fill 96 132 511 96 135 511 minecraft:blackstone
setblock 96 132 514 minecraft:blackstone
setblock 96 132 525 minecraft:smooth_basalt
fill 96 132 526 96 135 526 minecraft:blackstone
setblock 96 132 530 minecraft:smooth_basalt
fill 96 132 531 96 135 531 minecraft:blackstone
setblock 96 132 550 minecraft:smooth_basalt
fill 96 132 551 96 135 551 minecraft:blackstone
fill 97 132 550 97 135 550 minecraft:blackstone
setblock 98 132 513 minecraft:smooth_basalt
setblock 99 132 512 minecraft:smooth_basalt
fill 99 132 513 99 135 513 minecraft:blackstone
setblock 100 132 511 minecraft:smooth_basalt
fill 100 132 512 100 135 512 minecraft:blackstone
setblock 100 132 551 minecraft:smooth_basalt
fill 101 132 511 101 135 511 minecraft:blackstone
setblock 101 132 550 minecraft:smooth_basalt
fill 101 132 551 101 135 551 minecraft:blackstone
setblock 102 132 549 minecraft:smooth_basalt
fill 102 132 550 102 135 550 minecraft:blackstone
setblock 103 132 513 minecraft:smooth_basalt
fill 103 132 549 103 133 549 minecraft:blackstone
setblock 104 132 512 minecraft:smooth_basalt
setblock 105 132 511 minecraft:smooth_basalt
fill 105 132 512 105 135 512 minecraft:blackstone
setblock 105 132 551 minecraft:smooth_basalt
fill 106 132 511 106 135 511 minecraft:blackstone
setblock 106 132 550 minecraft:smooth_basalt
fill 106 132 551 109 132 551 minecraft:blackstone
fill 107 132 550 110 132 550 minecraft:blackstone
setblock 110 132 511 minecraft:smooth_basalt
setblock 110 132 551 minecraft:smooth_basalt
fill 111 132 511 114 132 511 minecraft:blackstone
setblock 111 132 550 minecraft:smooth_basalt
fill 111 132 551 111 135 551 minecraft:blackstone
fill 112 132 550 115 132 550 minecraft:blackstone
setblock 115 132 511 minecraft:smooth_basalt
fill 115 132 549 116 132 549 minecraft:blackstone
setblock 115 132 551 minecraft:smooth_basalt
fill 116 132 511 116 135 511 minecraft:blackstone
setblock 116 132 550 minecraft:smooth_basalt
fill 116 132 551 116 135 551 minecraft:blackstone
setblock 117 132 549 minecraft:smooth_basalt
fill 117 132 550 117 135 550 minecraft:blackstone
fill 118 132 549 118 135 549 minecraft:blackstone
setblock 120 132 511 minecraft:smooth_basalt
setblock 120 132 551 minecraft:smooth_basalt
fill 121 132 511 121 135 511 minecraft:blackstone
setblock 121 132 550 minecraft:smooth_basalt
fill 121 132 551 121 135 551 minecraft:blackstone
setblock 122 132 549 minecraft:smooth_basalt
fill 122 132 550 122 135 550 minecraft:blackstone
setblock 123 132 549 minecraft:blackstone
setblock 125 132 511 minecraft:smooth_basalt
setblock 125 132 551 minecraft:smooth_basalt
setblock 126 132 550 minecraft:smooth_basalt
fill 126 132 551 126 134 551 minecraft:blackstone
setblock 134 132 527 minecraft:smooth_basalt
fill 134 132 528 134 135 528 minecraft:blackstone
setblock 134 132 531 minecraft:blackstone
setblock 134 132 532 minecraft:smooth_basalt
setblock 135 132 511 minecraft:smooth_basalt
setblock 135 132 521 minecraft:smooth_basalt
fill 135 132 522 135 135 522 minecraft:blackstone
setblock 135 132 526 minecraft:smooth_basalt
fill 135 132 527 135 135 527 minecraft:blackstone
setblock 135 132 531 minecraft:smooth_basalt
fill 135 132 532 135 135 532 minecraft:blackstone
setblock 135 132 551 minecraft:smooth_basalt
fill 95 133 511 95 136 511 minecraft:blackstone
setblock 95 133 515 minecraft:smooth_basalt
fill 95 133 516 95 136 516 minecraft:blackstone
setblock 95 133 520 minecraft:smooth_basalt
fill 95 133 521 95 136 521 minecraft:blackstone
setblock 95 133 525 minecraft:smooth_basalt
fill 95 133 526 95 136 526 minecraft:blackstone
setblock 95 133 530 minecraft:smooth_basalt
fill 95 133 531 95 136 531 minecraft:blackstone
setblock 95 133 550 minecraft:smooth_basalt
fill 95 133 551 95 136 551 minecraft:blackstone
setblock 96 133 514 minecraft:smooth_basalt
fill 96 133 515 96 136 515 minecraft:blackstone
setblock 96 133 524 minecraft:smooth_basalt
fill 96 133 525 96 134 525 minecraft:blackstone
setblock 96 133 529 minecraft:smooth_basalt
fill 96 133 530 96 136 530 minecraft:blackstone
fill 96 133 550 96 136 550 minecraft:blackstone
setblock 97 133 513 minecraft:smooth_basalt
setblock 98 133 512 minecraft:smooth_basalt
fill 98 133 513 98 136 513 minecraft:blackstone
setblock 99 133 511 minecraft:smooth_basalt
fill 99 133 512 99 136 512 minecraft:blackstone
setblock 99 133 551 minecraft:smooth_basalt
fill 100 133 511 100 136 511 minecraft:blackstone
setblock 100 133 550 minecraft:smooth_basalt
fill 100 133 551 100 136 551 minecraft:blackstone
setblock 101 133 549 minecraft:smooth_basalt
fill 101 133 550 101 136 550 minecraft:blackstone
setblock 102 133 513 minecraft:smooth_basalt
setblock 102 133 549 minecraft:blackstone
setblock 103 133 512 minecraft:smooth_basalt
setblock 104 133 511 minecraft:smooth_basalt
fill 104 133 512 104 136 512 minecraft:blackstone
setblock 104 133 551 minecraft:smooth_basalt
fill 105 133 511 105 136 511 minecraft:blackstone
setblock 105 133 550 minecraft:smooth_basalt
fill 105 133 551 108 133 551 minecraft:blackstone
fill 106 133 550 109 133 550 minecraft:blackstone
fill 107 133 548 109 134 548 minecraft:gold_block
fill 108 133 547 108 134 547 minecraft:gold_block
fill 108 133 549 108 134 549 minecraft:gold_block
setblock 109 133 511 minecraft:smooth_basalt
setblock 109 133 551 minecraft:smooth_basalt
fill 110 133 511 113 133 511 minecraft:blackstone
setblock 110 133 550 minecraft:smooth_basalt
fill 110 133 551 110 136 551 minecraft:blackstone
fill 111 133 550 114 133 550 minecraft:blackstone
setblock 114 133 511 minecraft:smooth_basalt
setblock 114 133 551 minecraft:smooth_basalt
fill 115 133 511 115 136 511 minecraft:blackstone
setblock 115 133 550 minecraft:smooth_basalt
fill 115 133 551 115 136 551 minecraft:blackstone
setblock 116 133 549 minecraft:smooth_basalt
fill 116 133 550 116 136 550 minecraft:blackstone
fill 117 133 549 117 136 549 minecraft:blackstone
setblock 119 133 511 minecraft:smooth_basalt
setblock 119 133 551 minecraft:smooth_basalt
fill 120 133 511 120 136 511 minecraft:blackstone
fill 120 133 546 120 137 546 minecraft:smooth_basalt
setblock 120 133 550 minecraft:smooth_basalt
fill 120 133 551 120 136 551 minecraft:blackstone
setblock 121 133 549 minecraft:smooth_basalt
fill 121 133 550 121 136 550 minecraft:blackstone
setblock 122 133 549 minecraft:blackstone
setblock 124 133 511 minecraft:smooth_basalt
fill 124 133 538 125 134 539 minecraft:gold_block
setblock 124 133 551 minecraft:smooth_basalt
fill 125 133 551 125 135 551 minecraft:blackstone
setblock 134 133 526 minecraft:smooth_basalt
fill 134 133 527 134 136 527 minecraft:blackstone
setblock 134 133 531 minecraft:smooth_basalt
fill 134 133 532 134 135 533 minecraft:blackstone
fill 135 133 511 135 134 513 minecraft:blackstone
fill 135 133 521 135 136 521 minecraft:blackstone
setblock 135 133 525 minecraft:smooth_basalt
fill 135 133 526 135 136 526 minecraft:blackstone
setblock 135 133 530 minecraft:smooth_basalt
fill 135 133 531 135 136 531 minecraft:blackstone
setblock 135 133 535 minecraft:smooth_basalt
fill 135 133 536 135 136 536 minecraft:blackstone
fill 135 133 551 135 136 551 minecraft:blackstone
setblock 95 134 513 minecraft:blackstone
setblock 95 134 514 minecraft:smooth_basalt
fill 95 134 515 95 137 515 minecraft:blackstone
setblock 95 134 519 minecraft:smooth_basalt
fill 95 134 520 95 137 520 minecraft:blackstone
setblock 95 134 524 minecraft:smooth_basalt
fill 95 134 525 95 137 525 minecraft:blackstone
setblock 95 134 529 minecraft:smooth_basalt
fill 95 134 530 95 137 530 minecraft:blackstone
setblock 95 134 534 minecraft:smooth_basalt
setblock 95 134 549 minecraft:smooth_basalt
fill 95 134 550 95 137 550 minecraft:blackstone
setblock 96 134 513 minecraft:smooth_basalt
fill 96 134 514 97 136 514 minecraft:blackstone
fill 96 134 516 96 135 516 minecraft:blackstone
setblock 96 134 528 minecraft:smooth_basalt
fill 96 134 529 96 137 529 minecraft:blackstone
setblock 96 134 532 minecraft:blackstone
setblock 97 134 512 minecraft:smooth_basalt
fill 97 134 513 97 137 513 minecraft:blackstone
setblock 98 134 511 minecraft:smooth_basalt
fill 98 134 512 98 137 512 minecraft:blackstone
setblock 98 134 551 minecraft:smooth_basalt
fill 99 134 511 99 137 511 minecraft:blackstone
setblock 99 134 550 minecraft:smooth_basalt
fill 99 134 551 99 137 551 minecraft:blackstone
fill 100 134 550 100 137 550 minecraft:blackstone
setblock 101 134 513 minecraft:smooth_basalt
setblock 102 134 512 minecraft:smooth_basalt
fill 102 134 513 102 137 513 minecraft:blackstone
setblock 103 134 511 minecraft:smooth_basalt
fill 103 134 512 103 137 512 minecraft:blackstone
setblock 103 134 551 minecraft:smooth_basalt
fill 104 134 511 104 137 511 minecraft:blackstone
setblock 104 134 550 minecraft:smooth_basalt
fill 104 134 551 107 134 551 minecraft:blackstone
fill 105 134 550 108 134 550 minecraft:blackstone
setblock 108 134 511 minecraft:smooth_basalt
setblock 108 134 551 minecraft:smooth_basalt
fill 109 134 511 112 134 511 minecraft:blackstone
fill 109 134 551 109 137 551 minecraft:blackstone
fill 111 134 550 113 134 550 minecraft:blackstone
setblock 113 134 511 minecraft:smooth_basalt
setblock 113 134 551 minecraft:smooth_basalt
fill 114 134 511 114 137 511 minecraft:blackstone
setblock 114 134 550 minecraft:smooth_basalt
fill 114 134 551 114 137 551 minecraft:blackstone
fill 115 134 550 115 137 550 minecraft:blackstone
fill 116 134 549 116 135 549 minecraft:blackstone
setblock 118 134 511 minecraft:smooth_basalt
setblock 118 134 551 minecraft:smooth_basalt
fill 119 134 511 119 137 511 minecraft:blackstone
setblock 119 134 550 minecraft:smooth_basalt
fill 119 134 551 119 137 551 minecraft:blackstone
setblock 120 134 549 minecraft:smooth_basalt
fill 120 134 550 120 137 550 minecraft:blackstone
setblock 121 134 549 minecraft:blackstone
setblock 123 134 511 minecraft:smooth_basalt
setblock 123 134 551 minecraft:smooth_basalt
fill 124 134 511 124 135 511 minecraft:blackstone
fill 124 134 551 124 137 551 minecraft:blackstone
fill 134 134 511 134 137 511 minecraft:blackstone
fill 134 134 526 134 137 526 minecraft:blackstone
setblock 134 134 530 minecraft:smooth_basalt
fill 134 134 531 134 137 531 minecraft:blackstone
setblock 135 134 514 minecraft:smooth_basalt
fill 135 134 515 135 137 515 minecraft:blackstone
setblock 135 134 524 minecraft:smooth_basalt
fill 135 134 525 135 137 525 minecraft:blackstone
setblock 135 134 529 minecraft:smooth_basalt
fill 135 134 530 135 137 530 minecraft:blackstone
setblock 135 134 534 minecraft:smooth_basalt
fill 135 134 535 135 137 535 minecraft:blackstone
setblock 95 135 513 minecraft:smooth_basalt
fill 95 135 514 95 138 514 minecraft:blackstone
setblock 95 135 518 minecraft:smooth_basalt
fill 95 135 519 95 138 519 minecraft:blackstone
setblock 95 135 523 minecraft:smooth_basalt
fill 95 135 524 95 138 524 minecraft:blackstone
setblock 95 135 528 minecraft:smooth_basalt
fill 95 135 529 95 138 529 minecraft:blackstone
setblock 95 135 533 minecraft:smooth_basalt
fill 95 135 534 95 137 535 minecraft:blackstone
setblock 95 135 548 minecraft:smooth_basalt
fill 95 135 549 95 138 549 minecraft:blackstone
setblock 96 135 512 minecraft:smooth_basalt
fill 96 135 513 96 138 513 minecraft:blackstone
setblock 96 135 517 minecraft:smooth_basalt
setblock 96 135 527 minecraft:smooth_basalt
fill 96 135 528 96 138 528 minecraft:blackstone
setblock 96 135 532 minecraft:smooth_basalt
setblock 97 135 511 minecraft:smooth_basalt
fill 97 135 512 97 138 512 minecraft:blackstone
setblock 97 135 515 minecraft:blackstone
setblock 97 135 551 minecraft:smooth_basalt
fill 98 135 511 98 138 511 minecraft:blackstone
setblock 98 135 550 minecraft:smooth_basalt
fill 98 135 551 98 138 551 minecraft:blackstone
fill 99 135 550 99 138 550 minecraft:blackstone
setblock 100 135 513 minecraft:smooth_basalt
setblock 101 135 512 minecraft:smooth_basalt
fill 101 135 513 101 138 513 minecraft:blackstone
setblock 102 135 511 minecraft:smooth_basalt
fill 102 135 512 102 138 512 minecraft:blackstone
setblock 102 135 551 minecraft:smooth_basalt
fill 103 135 511 103 138 511 minecraft:blackstone
setblock 103 135 550 minecraft:smooth_basalt
fill 103 135 551 106 135 551 minecraft:blackstone
fill 104 135 550 106 135 550 minecraft:blackstone
setblock 107 135 511 minecraft:smooth_basalt
setblock 107 135 551 minecraft:smooth_basalt
fill 108 135 511 111 135 511 minecraft:blackstone
fill 108 135 551 108 138 551 minecraft:blackstone
fill 111 135 550 112 135 550 minecraft:blackstone
setblock 112 135 511 minecraft:smooth_basalt
setblock 112 135 551 minecraft:smooth_basalt
fill 113 135 511 113 138 511 minecraft:blackstone
setblock 113 135 550 minecraft:smooth_basalt
fill 113 135 551 113 138 551 minecraft:blackstone
fill 114 135 550 114 138 550 minecraft:blackstone
setblock 117 135 511 minecraft:smooth_basalt
fill 117 135 512 119 136 512 minecraft:blackstone
setblock 117 135 551 minecraft:smooth_basalt
fill 118 135 511 118 138 511 minecraft:blackstone
setblock 118 135 550 minecraft:smooth_basalt
fill 118 135 551 118 138 551 minecraft:blackstone
setblock 119 135 549 minecraft:smooth_basalt
fill 119 135 550 119 138 550 minecraft:blackstone
setblock 122 135 511 minecraft:smooth_basalt
setblock 122 135 551 minecraft:smooth_basalt
fill 123 135 511 123 138 511 minecraft:blackstone
setblock 123 135 550 minecraft:smooth_basalt
fill 123 135 551 123 138 551 minecraft:blackstone
fill 133 135 511 133 138 511 minecraft:blackstone
setblock 134 135 529 minecraft:smooth_basalt
fill 134 135 530 134 138 530 minecraft:blackstone
setblock 134 135 534 minecraft:smooth_basalt
fill 135 135 511 135 135 512 minecraft:blackstone
setblock 135 135 513 minecraft:smooth_basalt
fill 135 135 514 135 138 514 minecraft:blackstone
fill 135 135 516 135 135 517 minecraft:blackstone
setblock 135 135 518 minecraft:smooth_basalt
fill 135 135 519 135 137 520 minecraft:blackstone
setblock 135 135 523 minecraft:smooth_basalt
fill 135 135 524 135 138 524 minecraft:blackstone
setblock 135 135 528 minecraft:smooth_basalt
fill 135 135 529 135 138 529 minecraft:blackstone
setblock 135 135 533 minecraft:smooth_basalt
fill 135 135 534 135 138 534 minecraft:blackstone
setblock 135 135 537 minecraft:blackstone
setblock 95 136 512 minecraft:smooth_basalt
fill 95 136 513 95 139 513 minecraft:blackstone
setblock 95 136 517 minecraft:smooth_basalt
fill 95 136 518 96 138 518 minecraft:blackstone
setblock 95 136 522 minecraft:smooth_basalt
fill 95 136 523 95 139 523 minecraft:blackstone
setblock 95 136 527 minecraft:smooth_basalt
fill 95 136 528 95 139 528 minecraft:blackstone
setblock 95 136 532 minecraft:smooth_basalt
fill 95 136 533 96 138 533 minecraft:blackstone
setblock 95 136 536 minecraft:blackstone
fill 95 136 548 95 139 548 minecraft:blackstone
setblock 96 136 511 minecraft:smooth_basalt
fill 96 136 512 96 139 512 minecraft:blackstone
setblock 96 136 516 minecraft:smooth_basalt
fill 96 136 517 96 139 517 minecraft:blackstone
fill 96 136 527 96 139 527 minecraft:blackstone
setblock 96 136 531 minecraft:smooth_basalt
fill 96 136 532 96 139 532 minecraft:blackstone
fill 96 136 549 96 137 549 minecraft:blackstone
setblock 96 136 551 minecraft:smooth_basalt
fill 97 136 511 97 139 511 minecraft:blackstone
setblock 97 136 515 minecraft:smooth_basalt
fill 97 136 516 97 139 516 minecraft:blackstone
setblock 97 136 521 minecraft:light[level=12]
setblock 97 136 529 minecraft:light[level=12]
setblock 97 136 537 minecraft:light[level=12]
setblock 97 136 545 minecraft:light[level=12]
setblock 97 136 550 minecraft:smooth_basalt
fill 97 136 551 97 139 551 minecraft:blackstone
fill 98 136 550 98 139 550 minecraft:blackstone
setblock 99 136 513 minecraft:smooth_basalt
setblock 100 136 512 minecraft:smooth_basalt
fill 100 136 513 100 139 513 minecraft:blackstone
setblock 101 136 511 minecraft:smooth_basalt
fill 101 136 512 101 139 512 minecraft:blackstone
setblock 101 136 551 minecraft:smooth_basalt
fill 102 136 511 102 139 511 minecraft:blackstone
setblock 102 136 550 minecraft:smooth_basalt
fill 102 136 551 105 136 551 minecraft:blackstone
fill 103 136 550 105 137 550 minecraft:blackstone
setblock 105 136 512 minecraft:smooth_basalt
setblock 105 136 513 minecraft:light[level=12]
setblock 105 136 521 minecraft:light[level=12]
setblock 105 136 529 minecraft:light[level=12]
setblock 105 136 537 minecraft:light[level=12]
setblock 105 136 545 minecraft:light[level=12]
setblock 106 136 511 minecraft:smooth_basalt
setblock 106 136 551 minecraft:smooth_basalt
fill 107 136 511 110 136 511 minecraft:blackstone
fill 107 136 551 107 139 551 minecraft:blackstone
setblock 111 136 511 minecraft:smooth_basalt
setblock 111 136 550 minecraft:blackstone
setblock 111 136 551 minecraft:smooth_basalt
fill 112 136 511 112 139 511 minecraft:blackstone
setblock 112 136 550 minecraft:smooth_basalt
fill 112 136 551 112 139 551 minecraft:blackstone
setblock 113 136 513 minecraft:light[level=12]
setblock 113 136 521 minecraft:light[level=12]
setblock 113 136 529 minecraft:light[level=12]
setblock 113 136 537 minecraft:light[level=12]
setblock 113 136 545 minecraft:light[level=12]
fill 113 136 550 113 139 550 minecraft:blackstone
setblock 115 136 512 minecraft:smooth_basalt
setblock 116 136 511 minecraft:smooth_basalt
fill 116 136 512 116 139 512 minecraft:blackstone
setblock 116 136 551 minecraft:smooth_basalt
fill 117 136 511 117 139 511 minecraft:blackstone
setblock 117 136 550 minecraft:smooth_basalt
fill 117 136 551 117 139 551 minecraft:blackstone
setblock 118 136 549 minecraft:smooth_basalt
fill 118 136 550 118 139 550 minecraft:blackstone
setblock 120 136 512 minecraft:smooth_basalt
setblock 121 136 511 minecraft:smooth_basalt
setblock 121 136 513 minecraft:light[level=12]
setblock 121 136 521 minecraft:light[level=12]
setblock 121 136 529 minecraft:light[level=12]
setblock 121 136 537 minecraft:light[level=12]
setblock 121 136 545 minecraft:light[level=12]
setblock 121 136 551 minecraft:smooth_basalt
fill 122 136 511 122 139 511 minecraft:blackstone
setblock 122 136 550 minecraft:smooth_basalt
fill 122 136 551 122 139 551 minecraft:blackstone
setblock 129 136 513 minecraft:light[level=12]
setblock 129 136 521 minecraft:light[level=12]
setblock 129 136 529 minecraft:light[level=12]
setblock 129 136 537 minecraft:light[level=12]
setblock 129 136 545 minecraft:light[level=12]
fill 132 136 511 132 139 511 minecraft:blackstone
setblock 134 136 512 minecraft:blackstone
setblock 134 136 513 minecraft:smooth_basalt
setblock 134 136 528 minecraft:smooth_basalt
fill 134 136 529 134 139 529 minecraft:blackstone
setblock 134 136 532 minecraft:blackstone
setblock 134 136 533 minecraft:smooth_basalt
fill 134 136 534 134 138 535 minecraft:blackstone
fill 134 136 551 134 137 551 minecraft:blackstone
setblock 135 136 511 minecraft:blackstone
setblock 135 136 512 minecraft:smooth_basalt
fill 135 136 513 135 139 513 minecraft:blackstone
setblock 135 136 516 minecraft:blackstone
setblock 135 136 517 minecraft:smooth_basalt
fill 135 136 518 135 139 518 minecraft:blackstone
setblock 135 136 522 minecraft:smooth_basalt
fill 135 136 523 135 139 523 minecraft:blackstone
setblock 135 136 527 minecraft:smooth_basalt
fill 135 136 528 135 139 528 minecraft:blackstone
setblock 135 136 532 minecraft:smooth_basalt
fill 135 136 533 135 139 533 minecraft:blackstone
setblock 135 136 537 minecraft:smooth_basalt
fill 135 136 538 135 139 538 minecraft:blackstone
fill 135 136 550 135 137 550 minecraft:blackstone
setblock 95 137 511 minecraft:smooth_basalt
fill 95 137 512 95 140 512 minecraft:blackstone
setblock 95 137 516 minecraft:smooth_basalt
fill 95 137 517 95 140 517 minecraft:blackstone
setblock 95 137 521 minecraft:smooth_basalt
fill 95 137 522 95 140 522 minecraft:blackstone
setblock 95 137 526 minecraft:smooth_basalt
fill 95 137 527 95 140 527 minecraft:blackstone
setblock 95 137 531 minecraft:smooth_basalt
fill 95 137 532 95 140 532 minecraft:blackstone
setblock 95 137 536 minecraft:smooth_basalt
fill 95 137 537 95 140 537 minecraft:blackstone
setblock 95 137 551 minecraft:smooth_basalt
fill 96 137 511 96 140 511 minecraft:blackstone
setblock 96 137 514 minecraft:blackstone
setblock 96 137 515 minecraft:smooth_basalt
fill 96 137 516 96 140 516 minecraft:blackstone
setblock 96 137 519 minecraft:blackstone
setblock 96 137 520 minecraft:smooth_basalt
setblock 96 137 530 minecraft:smooth_basalt
fill 96 137 531 96 140 531 minecraft:blackstone
setblock 96 137 534 minecraft:blackstone
setblock 96 137 535 minecraft:smooth_basalt
setblock 96 137 550 minecraft:smooth_basalt
fill 96 137 551 96 140 551 minecraft:blackstone
setblock 97 137 514 minecraft:smooth_basalt
fill 97 137 515 97 140 515 minecraft:blackstone
fill 97 137 517 97 138 517 minecraft:blackstone
fill 97 137 550 97 140 550 minecraft:blackstone
setblock 98 137 513 minecraft:smooth_basalt
fill 98 137 514 99 139 514 minecraft:blackstone
setblock 99 137 512 minecraft:smooth_basalt
fill 99 137 513 99 140 513 minecraft:blackstone
setblock 100 137 511 minecraft:smooth_basalt
fill 100 137 512 100 140 512 minecraft:blackstone
setblock 100 137 551 minecraft:smooth_basalt
fill 101 137 511 101 140 511 minecraft:blackstone
setblock 101 137 550 minecraft:smooth_basalt
fill 101 137 551 104 137 551 minecraft:blackstone
fill 102 137 550 102 140 550 minecraft:blackstone
setblock 104 137 512 minecraft:smooth_basalt
setblock 105 137 511 minecraft:smooth_basalt
fill 105 137 512 105 140 512 minecraft:blackstone
setblock 105 137 551 minecraft:smooth_basalt
fill 106 137 511 109 137 511 minecraft:blackstone
fill 106 137 551 106 140 551 minecraft:blackstone
setblock 110 137 511 minecraft:smooth_basalt
setblock 110 137 551 minecraft:smooth_basalt
fill 111 137 511 111 140 511 minecraft:blackstone
setblock 111 137 550 minecraft:smooth_basalt
fill 111 137 551 111 140 551 minecraft:blackstone
fill 112 137 550 112 140 550 minecraft:blackstone
setblock 114 137 512 minecraft:smooth_basalt
setblock 115 137 511 minecraft:smooth_basalt
fill 115 137 512 115 140 512 minecraft:blackstone
setblock 115 137 551 minecraft:smooth_basalt
fill 116 137 511 116 140 511 minecraft:blackstone
setblock 116 137 550 minecraft:smooth_basalt
fill 116 137 551 116 140 551 minecraft:blackstone
fill 117 137 512 118 137 512 minecraft:blackstone
setblock 117 137 549 minecraft:smooth_basalt
fill 117 137 550 117 140 550 minecraft:blackstone
setblock 119 137 512 minecraft:smooth_basalt
setblock 120 137 511 minecraft:smooth_basalt
fill 120 137 512 120 140 512 minecraft:blackstone
setblock 120 137 551 minecraft:smooth_basalt
fill 121 137 511 121 140 511 minecraft:blackstone
setblock 121 137 550 minecraft:smooth_basalt
fill 121 137 551 121 140 551 minecraft:blackstone
setblock 124 137 511 minecraft:blackstone
fill 131 137 511 131 140 511 minecraft:blackstone
setblock 133 137 512 minecraft:blackstone
fill 133 137 531 133 137 532 minecraft:blackstone
setblock 134 137 512 minecraft:smooth_basalt
fill 134 137 513 134 137 516 minecraft:blackstone
setblock 134 137 517 minecraft:smooth_basalt
fill 134 137 525 134 138 525 minecraft:blackstone
setblock 134 137 527 minecraft:smooth_basalt
fill 134 137 528 134 140 528 minecraft:blackstone
setblock 134 137 532 minecraft:smooth_basalt
fill 134 137 533 134 140 533 minecraft:blackstone
setblock 134 137 536 minecraft:blackstone
setblock 135 137 511 minecraft:smooth_basalt
fill 135 137 512 135 140 512 minecraft:blackstone
setblock 135 137 516 minecraft:smooth_basalt
fill 135 137 517 135 140 517 minecraft:blackstone
setblock 135 137 521 minecraft:smooth_basalt
fill 135 137 522 135 140 522 minecraft:blackstone
setblock 135 137 526 minecraft:smooth_basalt
fill 135 137 527 135 140 527 minecraft:blackstone
setblock 135 137 531 minecraft:smooth_basalt
fill 135 137 532 135 140 532 minecraft:blackstone
setblock 135 137 536 minecraft:smooth_basalt
fill 135 137 537 135 140 537 minecraft:blackstone
fill 135 137 539 135 138 539 minecraft:blackstone
setblock 135 137 551 minecraft:smooth_basalt
fill 95 138 511 95 141 511 minecraft:blackstone
setblock 95 138 515 minecraft:smooth_basalt
fill 95 138 516 95 141 516 minecraft:blackstone
setblock 95 138 520 minecraft:smooth_basalt
fill 95 138 521 96 140 521 minecraft:blackstone
setblock 95 138 525 minecraft:smooth_basalt
fill 95 138 526 95 141 526 minecraft:blackstone
setblock 95 138 530 minecraft:smooth_basalt
fill 95 138 531 95 141 531 minecraft:blackstone
setblock 95 138 534 minecraft:blackstone
setblock 95 138 535 minecraft:smooth_basalt
fill 95 138 536 96 140 536 minecraft:blackstone
fill 95 138 538 95 138 539 minecraft:blackstone
fill 95 138 547 95 140 547 minecraft:blackstone
setblock 95 138 550 minecraft:smooth_basalt
fill 95 138 551 95 141 551 minecraft:blackstone
setblock 96 138 514 minecraft:smooth_basalt
fill 96 138 515 96 141 515 minecraft:blackstone
setblock 96 138 519 minecraft:smooth_basalt
fill 96 138 520 96 141 520 minecraft:blackstone
setblock 96 138 529 minecraft:smooth_basalt
fill 96 138 530 96 141 530 minecraft:blackstone
setblock 96 138 534 minecraft:smooth_basalt
fill 96 138 535 96 141 535 minecraft:blackstone
fill 96 138 537 96 139 537 minecraft:blackstone
setblock 96 138 549 minecraft:smooth_basalt
fill 96 138 550 96 141 550 minecraft:blackstone
setblock 97 138 513 minecraft:smooth_basalt
fill 97 138 514 97 141 514 minecraft:blackstone
setblock 97 138 518 minecraft:smooth_basalt
setblock 98 138 512 minecraft:smooth_basalt
fill 98 138 513 98 141 513 minecraft:blackstone
fill 98 138 515 98 139 515 minecraft:blackstone
setblock 99 138 511 minecraft:smooth_basalt
fill 99 138 512 99 141 512 minecraft:blackstone
setblock 99 138 551 minecraft:smooth_basalt
fill 100 138 511 100 141 511 minecraft:blackstone
setblock 100 138 550 minecraft:smooth_basalt
fill 100 138 551 103 138 551 minecraft:blackstone
fill 101 138 550 101 141 550 minecraft:blackstone
setblock 102 138 513 minecraft:smooth_basalt
setblock 103 138 512 minecraft:smooth_basalt
fill 103 138 513 103 140 513 minecraft:blackstone
fill 103 138 550 104 138 550 minecraft:blackstone
setblock 104 138 511 minecraft:smooth_basalt
fill 104 138 512 104 141 512 minecraft:blackstone
setblock 104 138 551 minecraft:smooth_basalt
fill 105 138 511 108 138 511 minecraft:blackstone
fill 105 138 551 105 141 551 minecraft:blackstone
fill 106 138 512 106 139 512 minecraft:blackstone
setblock 109 138 511 minecraft:smooth_basalt
setblock 109 138 551 minecraft:smooth_basalt
fill 110 138 511 110 141 511 minecraft:blackstone
setblock 110 138 550 minecraft:smooth_basalt
fill 110 138 551 110 141 551 minecraft:blackstone
fill 111 138 550 111 141 550 minecraft:blackstone
setblock 112 138 512 minecraft:blackstone
setblock 113 138 512 minecraft:smooth_basalt
setblock 114 138 511 minecraft:smooth_basalt
fill 114 138 512 114 141 512 minecraft:blackstone
setblock 114 138 551 minecraft:smooth_basalt
fill 115 138 511 115 141 511 minecraft:blackstone
setblock 115 138 550 minecraft:smooth_basalt
fill 115 138 551 115 141 551 minecraft:blackstone
fill 116 138 544 119 139 548 minecraft:blackstone
fill 116 138 550 116 141 550 minecraft:blackstone
setblock 117 138 512 minecraft:blackstone
setblock 118 138 512 minecraft:smooth_basalt
setblock 118 138 549 minecraft:blackstone
setblock 119 138 511 minecraft:smooth_basalt
fill 119 138 512 119 141 512 minecraft:blackstone
setblock 119 138 551 minecraft:smooth_basalt
fill 120 138 511 120 141 511 minecraft:blackstone
fill 120 138 544 120 139 545 minecraft:blackstone
setblock 120 138 546 minecraft:shroomlight
fill 120 138 547 120 139 548 minecraft:blackstone
setblock 120 138 550 minecraft:smooth_basalt
fill 120 138 551 120 141 551 minecraft:blackstone
fill 121 138 512 121 139 512 minecraft:blackstone
setblock 124 138 511 minecraft:smooth_basalt
fill 130 138 511 130 141 511 minecraft:blackstone
setblock 132 138 512 minecraft:blackstone
setblock 133 138 512 minecraft:smooth_basalt
fill 133 138 530 133 138 531 minecraft:blackstone
setblock 133 138 532 minecraft:smooth_basalt
fill 133 138 533 133 140 534 minecraft:blackstone
setblock 133 138 551 minecraft:blackstone
setblock 134 138 511 minecraft:smooth_basalt
fill 134 138 512 134 138 515 minecraft:blackstone
setblock 134 138 516 minecraft:smooth_basalt
fill 134 138 517 134 138 520 minecraft:blackstone
setblock 134 138 521 minecraft:smooth_basalt
fill 134 138 522 134 139 524 minecraft:blackstone
setblock 134 138 526 minecraft:smooth_basalt
fill 134 138 527 134 141 527 minecraft:blackstone
setblock 134 138 531 minecraft:smooth_basalt
fill 134 138 532 134 141 532 minecraft:blackstone
setblock 134 138 536 minecraft:smooth_basalt
fill 134 138 537 134 141 537 minecraft:blackstone
setblock 134 138 551 minecraft:smooth_basalt
fill 135 138 511 135 141 511 minecraft:blackstone
setblock 135 138 515 minecraft:smooth_basalt
fill 135 138 516 135 141 516 minecraft:blackstone
setblock 135 138 519 minecraft:blackstone
setblock 135 138 520 minecraft:smooth_basalt
fill 135 138 521 135 141 521 minecraft:blackstone
setblock 135 138 525 minecraft:smooth_basalt
fill 135 138 526 135 141 526 minecraft:blackstone
setblock 135 138 530 minecraft:smooth_basalt
fill 135 138 531 135 141 531 minecraft:blackstone
setblock 135 138 535 minecraft:smooth_basalt
fill 135 138 536 135 141 536 minecraft:blackstone
setblock 135 138 540 minecraft:smooth_basalt
setblock 135 138 549 minecraft:blackstone
setblock 135 138 550 minecraft:smooth_basalt
fill 135 138 551 135 141 551 minecraft:blackstone
setblock 95 139 514 minecraft:smooth_basalt
fill 95 139 515 95 142 515 minecraft:blackstone
setblock 95 139 518 minecraft:blackstone
setblock 95 139 519 minecraft:smooth_basalt
fill 95 139 520 95 142 520 minecraft:blackstone
setblock 95 139 524 minecraft:smooth_basalt
fill 95 139 525 95 142 525 minecraft:blackstone
setblock 95 139 529 minecraft:smooth_basalt
fill 95 139 530 95 142 530 minecraft:blackstone
setblock 95 139 533 minecraft:blackstone
setblock 95 139 534 minecraft:smooth_basalt
fill 95 139 535 95 142 535 minecraft:blackstone
setblock 95 139 538 minecraft:blackstone
setblock 95 139 539 minecraft:smooth_basalt
fill 95 139 540 95 140 542 minecraft:blackstone
fill 95 139 545 95 141 546 minecraft:blackstone
setblock 95 139 549 minecraft:smooth_basalt
fill 95 139 550 95 142 550 minecraft:blackstone
setblock 96 139 513 minecraft:smooth_basalt
fill 96 139 514 96 142 514 minecraft:blackstone
setblock 96 139 518 minecraft:smooth_basalt
fill 96 139 519 97 141 519 minecraft:blackstone
setblock 96 139 522 minecraft:blackstone
setblock 96 139 528 minecraft:smooth_basalt
fill 96 139 529 96 141 529 minecraft:blackstone
setblock 96 139 533 minecraft:smooth_basalt
fill 96 139 534 96 142 534 minecraft:blackstone
setblock 96 139 538 minecraft:smooth_basalt
setblock 96 139 548 minecraft:smooth_basalt
fill 96 139 549 96 142 549 minecraft:blackstone
setblock 97 139 512 minecraft:smooth_basalt
fill 97 139 513 97 142 513 minecraft:blackstone
setblock 97 139 517 minecraft:smooth_basalt
fill 97 139 518 97 142 518 minecraft:blackstone
setblock 98 139 511 minecraft:smooth_basalt
fill 98 139 512 98 142 512 minecraft:blackstone
setblock 98 139 516 minecraft:smooth_basalt
setblock 98 139 551 minecraft:smooth_basalt
fill 99 139 511 99 142 511 minecraft:blackstone
setblock 99 139 550 minecraft:smooth_basalt
fill 99 139 551 102 139 551 minecraft:blackstone
setblock 100 139 514 minecraft:smooth_basalt
fill 100 139 550 100 142 550 minecraft:blackstone
setblock 101 139 513 minecraft:smooth_basalt
setblock 102 139 512 minecraft:smooth_basalt
fill 102 139 513 102 141 513 minecraft:blackstone
setblock 103 139 511 minecraft:smooth_basalt
fill 103 139 512 103 142 512 minecraft:blackstone
setblock 103 139 550 minecraft:blackstone
setblock 103 139 551 minecraft:smooth_basalt
fill 104 139 511 107 139 511 minecraft:blackstone
setblock 104 139 550 minecraft:smooth_basalt
fill 104 139 551 104 142 551 minecraft:blackstone
setblock 107 139 512 minecraft:smooth_basalt
setblock 108 139 511 minecraft:smooth_basalt
setblock 108 139 551 minecraft:smooth_basalt
fill 109 139 511 109 142 511 minecraft:blackstone
fill 109 139 551 109 142 551 minecraft:blackstone
fill 110 139 512 111 139 512 minecraft:blackstone
fill 110 139 550 110 142 550 minecraft:blackstone
setblock 112 139 512 minecraft:smooth_basalt
setblock 113 139 511 minecraft:smooth_basalt
fill 113 139 512 113 142 512 minecraft:blackstone
setblock 113 139 551 minecraft:smooth_basalt
fill 114 139 511 114 142 511 minecraft:blackstone
setblock 114 139 550 minecraft:smooth_basalt
fill 114 139 551 114 142 551 minecraft:blackstone
fill 115 139 550 115 142 550 minecraft:blackstone
setblock 117 139 512 minecraft:smooth_basalt
setblock 118 139 511 minecraft:smooth_basalt
fill 118 139 512 118 142 512 minecraft:blackstone
setblock 118 139 551 minecraft:smooth_basalt
fill 119 139 511 119 142 511 minecraft:blackstone
setblock 119 139 550 minecraft:smooth_basalt
fill 119 139 551 119 142 551 minecraft:blackstone
setblock 120 139 546 minecraft:blackstone
setblock 120 139 550 minecraft:blackstone
setblock 123 139 511 minecraft:smooth_basalt
fill 124 139 511 124 141 511 minecraft:blackstone
setblock 128 139 511 minecraft:smooth_basalt
fill 129 139 511 129 142 511 minecraft:blackstone
setblock 131 139 512 minecraft:blackstone
setblock 132 139 512 minecraft:smooth_basalt
setblock 133 139 511 minecraft:smooth_basalt
fill 133 139 512 133 139 515 minecraft:blackstone
setblock 133 139 516 minecraft:smooth_basalt
fill 133 139 517 134 141 517 minecraft:blackstone
fill 133 139 529 133 139 530 minecraft:blackstone
setblock 133 139 531 minecraft:smooth_basalt
fill 133 139 532 133 142 532 minecraft:blackstone
setblock 133 139 535 minecraft:blackstone
setblock 133 139 551 minecraft:smooth_basalt
fill 134 139 511 134 139 514 minecraft:blackstone
setblock 134 139 515 minecraft:smooth_basalt
fill 134 139 516 134 142 516 minecraft:blackstone
fill 134 139 518 134 139 519 minecraft:blackstone
setblock 134 139 520 minecraft:smooth_basalt
fill 134 139 521 134 142 521 minecraft:blackstone
setblock 134 139 525 minecraft:smooth_basalt
fill 134 139 526 134 142 526 minecraft:blackstone
setblock 134 139 530 minecraft:smooth_basalt
fill 134 139 531 134 142 531 minecraft:blackstone
setblock 134 139 534 minecraft:blackstone
setblock 134 139 535 minecraft:smooth_basalt
fill 134 139 536 134 142 536 minecraft:blackstone
fill 134 139 538 134 140 538 minecraft:blackstone
fill 134 139 551 134 142 551 minecraft:blackstone
setblock 135 139 514 minecraft:smooth_basalt
fill 135 139 515 135 142 515 minecraft:blackstone
setblock 135 139 519 minecraft:smooth_basalt
fill 135 139 520 135 142 520 minecraft:blackstone
setblock 135 139 524 minecraft:smooth_basalt
fill 135 139 525 135 142 525 minecraft:blackstone
setblock 135 139 529 minecraft:smooth_basalt
fill 135 139 530 135 142 530 minecraft:blackstone
setblock 135 139 534 minecraft:smooth_basalt
fill 135 139 535 135 142 535 minecraft:blackstone
setblock 135 139 539 minecraft:smooth_basalt
fill 135 139 540 135 141 541 minecraft:blackstone
setblock 135 139 549 minecraft:smooth_basalt
fill 135 139 550 135 142 550 minecraft:blackstone
setblock 95 140 513 minecraft:smooth_basalt
fill 95 140 514 95 143 514 minecraft:blackstone
setblock 95 140 518 minecraft:smooth_basalt
fill 95 140 519 95 143 519 minecraft:blackstone
setblock 95 140 523 minecraft:smooth_basalt
fill 95 140 524 95 143 524 minecraft:blackstone
setblock 95 140 528 minecraft:smooth_basalt
fill 95 140 529 95 143 529 minecraft:blackstone
setblock 95 140 533 minecraft:smooth_basalt
fill 95 140 534 95 143 534 minecraft:blackstone
setblock 95 140 538 minecraft:smooth_basalt
fill 95 140 539 96 142 539 minecraft:blackstone
setblock 95 140 543 minecraft:smooth_basalt
fill 95 140 544 95 143 544 minecraft:blackstone
setblock 95 140 548 minecraft:smooth_basalt
fill 95 140 549 95 143 549 minecraft:blackstone
setblock 96 140 512 minecraft:smooth_basalt
fill 96 140 513 96 143 513 minecraft:blackstone
setblock 96 140 517 minecraft:smooth_basalt
fill 96 140 518 96 143 518 minecraft:blackstone
setblock 96 140 522 minecraft:smooth_basalt
fill 96 140 523 96 143 523 minecraft:blackstone
setblock 96 140 528 minecraft:blackstone
setblock 96 140 532 minecraft:smooth_basalt
fill 96 140 533 96 143 533 minecraft:blackstone
setblock 96 140 537 minecraft:smooth_basalt
fill 96 140 538 96 143 538 minecraft:blackstone
fill 96 140 540 96 141 540 minecraft:blackstone
fill 96 140 548 96 143 548 minecraft:blackstone
setblock 97 140 511 minecraft:smooth_basalt
fill 97 140 512 97 143 512 minecraft:blackstone
setblock 97 140 516 minecraft:smooth_basalt
fill 97 140 517 98 142 517 minecraft:blackstone
fill 97 140 534 97 140 535 minecraft:blackstone
setblock 97 140 551 minecraft:smooth_basalt
fill 98 140 511 98 143 511 minecraft:blackstone
setblock 98 140 514 minecraft:blackstone
setblock 98 140 515 minecraft:smooth_basalt
fill 98 140 516 98 143 516 minecraft:blackstone
setblock 98 140 550 minecraft:smooth_basalt
fill 98 140 551 101 140 551 minecraft:blackstone
setblock 99 140 514 minecraft:smooth_basalt
fill 99 140 550 99 143 550 minecraft:blackstone
setblock 100 140 513 minecraft:smooth_basalt
fill 100 140 514 100 141 514 minecraft:blackstone
setblock 101 140 512 minecraft:smooth_basalt
fill 101 140 513 101 142 513 minecraft:blackstone
setblock 102 140 511 minecraft:smooth_basalt
fill 102 140 512 102 143 512 minecraft:blackstone
setblock 102 140 551 minecraft:smooth_basalt
fill 103 140 511 106 140 511 minecraft:blackstone
setblock 103 140 550 minecraft:smooth_basalt
fill 103 140 551 103 143 551 minecraft:blackstone
setblock 106 140 512 minecraft:smooth_basalt
setblock 107 140 511 minecraft:smooth_basalt
fill 107 140 512 110 140 512 minecraft:blackstone
setblock 107 140 551 minecraft:smooth_basalt
fill 108 140 511 108 143 511 minecraft:blackstone
fill 108 140 551 108 143 551 minecraft:blackstone
fill 110 140 540 111 141 541 minecraft:gold_block
setblock 111 140 512 minecraft:smooth_basalt
setblock 112 140 511 minecraft:smooth_basalt
fill 112 140 512 112 143 512 minecraft:blackstone
setblock 112 140 551 minecraft:smooth_basalt
fill 113 140 511 113 143 511 minecraft:blackstone
setblock 113 140 550 minecraft:smooth_basalt
fill 113 140 551 113 143 551 minecraft:blackstone
setblock 114 140 513 minecraft:blackstone
fill 114 140 550 114 143 550 minecraft:blackstone
setblock 115 140 513 minecraft:smooth_basalt
setblock 116 140 512 minecraft:smooth_basalt
fill 116 140 513 117 141 513 minecraft:blackstone
setblock 117 140 511 minecraft:smooth_basalt
fill 117 140 512 117 143 512 minecraft:blackstone
fill 117 140 545 119 141 547 minecraft:smooth_basalt
setblock 117 140 551 minecraft:smooth_basalt
fill 118 140 511 118 143 511 minecraft:blackstone
setblock 118 140 550 minecraft:smooth_basalt
fill 118 140 551 118 143 551 minecraft:blackstone
setblock 119 140 550 minecraft:blackstone
setblock 121 140 512 minecraft:smooth_basalt
setblock 122 140 511 minecraft:smooth_basalt
setblock 122 140 551 minecraft:smooth_basalt
fill 123 140 511 123 141 511 minecraft:blackstone
setblock 127 140 511 minecraft:smooth_basalt
fill 128 140 511 128 143 511 minecraft:blackstone
setblock 130 140 512 minecraft:blackstone
setblock 131 140 512 minecraft:smooth_basalt
setblock 132 140 511 minecraft:smooth_basalt
fill 132 140 512 134 140 513 minecraft:blackstone
setblock 132 140 551 minecraft:smooth_basalt
fill 133 140 511 134 142 511 minecraft:blackstone
setblock 133 140 514 minecraft:blackstone
setblock 133 140 515 minecraft:smooth_basalt
fill 133 140 516 133 143 516 minecraft:blackstone
fill 133 140 518 133 140 519 minecraft:blackstone
setblock 133 140 520 minecraft:smooth_basalt
setblock 133 140 529 minecraft:blackstone
setblock 133 140 530 minecraft:smooth_basalt
fill 133 140 531 133 143 531 minecraft:blackstone
setblock 133 140 535 minecraft:smooth_basalt
fill 133 140 536 133 142 537 minecraft:blackstone
fill 133 140 551 133 143 551 minecraft:blackstone
setblock 134 140 514 minecraft:smooth_basalt
fill 134 140 515 134 143 515 minecraft:blackstone
setblock 134 140 518 minecraft:blackstone
setblock 134 140 519 minecraft:smooth_basalt
fill 134 140 520 134 143 520 minecraft:blackstone
fill 134 140 522 134 140 523 minecraft:blackstone
setblock 134 140 524 minecraft:smooth_basalt
fill 134 140 525 134 143 525 minecraft:blackstone
setblock 134 140 529 minecraft:smooth_basalt
fill 134 140 530 134 143 530 minecraft:blackstone
setblock 134 140 534 minecraft:smooth_basalt
fill 134 140 535 134 143 535 minecraft:blackstone
setblock 134 140 539 minecraft:smooth_basalt
fill 134 140 540 134 143 540 minecraft:blackstone
setblock 135 140 513 minecraft:smooth_basalt
fill 135 140 514 135 143 514 minecraft:blackstone
setblock 135 140 518 minecraft:smooth_basalt
fill 135 140 519 135 143 519 minecraft:blackstone
setblock 135 140 523 minecraft:smooth_basalt
fill 135 140 524 135 143 524 minecraft:blackstone
setblock 135 140 528 minecraft:smooth_basalt
fill 135 140 529 135 143 529 minecraft:blackstone
setblock 135 140 533 minecraft:smooth_basalt
fill 135 140 534 135 143 534 minecraft:blackstone
setblock 135 140 538 minecraft:smooth_basalt
fill 135 140 539 135 143 539 minecraft:blackstone
setblock 135 140 542 minecraft:blackstone
setblock 135 140 543 minecraft:smooth_basalt
setblock 135 140 548 minecraft:smooth_basalt
fill 135 140 549 135 143 549 minecraft:blackstone
setblock 95 141 512 minecraft:smooth_basalt
fill 95 141 513 95 144 513 minecraft:blackstone
setblock 95 141 517 minecraft:smooth_basalt
fill 95 141 518 95 144 518 minecraft:blackstone
setblock 95 141 521 minecraft:blackstone
setblock 95 141 522 minecraft:smooth_basalt
fill 95 141 523 95 144 523 minecraft:blackstone
setblock 95 141 527 minecraft:smooth_basalt
fill 95 141 528 95 144 528 minecraft:blackstone
setblock 95 141 532 minecraft:smooth_basalt
fill 95 141 533 95 144 533 minecraft:blackstone
setblock 95 141 536 minecraft:blackstone
setblock 95 141 537 minecraft:smooth_basalt
fill 95 141 538 95 144 538 minecraft:blackstone
fill 95 141 540 95 141 541 minecraft:blackstone
setblock 95 141 542 minecraft:smooth_basalt
fill 95 141 543 95 144 543 minecraft:blackstone
setblock 95 141 547 minecraft:smooth_basalt
fill 95 141 548 95 144 548 minecraft:blackstone
setblock 96 141 511 minecraft:smooth_basalt
fill 96 141 512 96 144 512 minecraft:blackstone
setblock 96 141 516 minecraft:smooth_basalt
fill 96 141 517 96 144 517 minecraft:blackstone
setblock 96 141 521 minecraft:smooth_basalt
fill 96 141 522 96 144 522 minecraft:blackstone
setblock 96 141 531 minecraft:smooth_basalt
fill 96 141 532 96 143 532 minecraft:blackstone
setblock 96 141 536 minecraft:smooth_basalt
fill 96 141 537 97 143 537 minecraft:blackstone
setblock 96 141 541 minecraft:smooth_basalt
fill 96 141 542 96 144 542 minecraft:blackstone
fill 96 141 547 96 144 547 minecraft:blackstone
setblock 96 141 551 minecraft:smooth_basalt
fill 97 141 511 97 144 511 minecraft:blackstone
setblock 97 141 515 minecraft:smooth_basalt
fill 97 141 516 97 144 516 minecraft:blackstone
setblock 97 141 520 minecraft:smooth_basalt
setblock 97 141 534 minecraft:blackstone
setblock 97 141 535 minecraft:smooth_basalt
fill 97 141 536 97 142 536 minecraft:blackstone
setblock 97 141 550 minecraft:smooth_basalt
fill 97 141 551 100 141 551 minecraft:blackstone
setblock 98 141 514 minecraft:smooth_basalt
fill 98 141 515 98 143 515 minecraft:blackstone
fill 98 141 550 98 144 550 minecraft:blackstone
setblock 99 141 513 minecraft:smooth_basalt
fill 99 141 514 99 142 514 minecraft:blackstone
setblock 100 141 512 minecraft:smooth_basalt
fill 100 141 513 100 143 513 minecraft:blackstone
setblock 101 141 511 minecraft:smooth_basalt
fill 101 141 512 101 144 512 minecraft:blackstone
setblock 101 141 551 minecraft:smooth_basalt
fill 102 141 511 105 141 511 minecraft:blackstone
setblock 102 141 550 minecraft:smooth_basalt
fill 102 141 551 102 144 551 minecraft:blackstone
setblock 105 141 512 minecraft:smooth_basalt
setblock 106 141 511 minecraft:smooth_basalt
fill 106 141 512 109 141 512 minecraft:blackstone
setblock 106 141 551 minecraft:smooth_basalt
fill 107 141 511 107 144 511 minecraft:blackstone
fill 107 141 551 107 144 551 minecraft:blackstone
setblock 109 141 550 minecraft:blackstone
setblock 110 141 512 minecraft:smooth_basalt
setblock 111 141 511 minecraft:smooth_basalt
fill 111 141 512 111 144 512 minecraft:blackstone
setblock 111 141 551 minecraft:smooth_basalt
fill 112 141 511 112 144 511 minecraft:blackstone
setblock 112 141 550 minecraft:smooth_basalt
fill 112 141 551 112 144 551 minecraft:blackstone
setblock 113 141 513 minecraft:blackstone
fill 113 141 550 113 144 550 minecraft:blackstone
setblock 114 141 513 minecraft:smooth_basalt
setblock 115 141 512 minecraft:smooth_basalt
fill 115 141 513 115 142 513 minecraft:blackstone
setblock 116 141 511 minecraft:smooth_basalt
fill 116 141 512 116 144 512 minecraft:blackstone
setblock 116 141 551 minecraft:smooth_basalt
fill 117 141 511 117 144 511 minecraft:blackstone
setblock 117 141 550 minecraft:smooth_basalt
fill 117 141 551 117 144 551 minecraft:blackstone
setblock 118 141 550 minecraft:blackstone
setblock 120 141 512 minecraft:smooth_basalt
setblock 121 141 511 minecraft:smooth_basalt
setblock 121 141 551 minecraft:smooth_basalt
fill 122 141 511 122 142 511 minecraft:blackstone
fill 127 141 511 127 143 511 minecraft:blackstone
setblock 129 141 512 minecraft:blackstone
setblock 130 141 512 minecraft:smooth_basalt
setblock 131 141 511 minecraft:smooth_basalt
fill 131 141 512 133 141 513 minecraft:blackstone
fill 132 141 511 132 144 511 minecraft:blackstone
setblock 132 141 515 minecraft:smooth_basalt
fill 132 141 551 132 144 551 minecraft:blackstone
setblock 133 141 514 minecraft:smooth_basalt
fill 133 141 515 133 144 515 minecraft:blackstone
setblock 133 141 518 minecraft:blackstone
setblock 133 141 519 minecraft:smooth_basalt
fill 133 141 520 133 142 522 minecraft:blackstone
setblock 133 141 529 minecraft:smooth_basalt
fill 133 141 530 133 142 530 minecraft:blackstone
setblock 133 141 533 minecraft:blackstone
setblock 133 141 534 minecraft:smooth_basalt
fill 133 141 535 133 144 535 minecraft:blackstone
setblock 133 141 538 minecraft:blackstone
setblock 134 141 512 minecraft:blackstone
setblock 134 141 513 minecraft:smooth_basalt
fill 134 141 514 134 144 514 minecraft:blackstone
setblock 134 141 518 minecraft:smooth_basalt
fill 134 141 519 134 144 519 minecraft:blackstone
setblock 134 141 522 minecraft:blackstone
setblock 134 141 523 minecraft:smooth_basalt
fill 134 141 524 134 144 524 minecraft:blackstone
setblock 134 141 528 minecraft:smooth_basalt
fill 134 141 529 134 144 529 minecraft:blackstone
setblock 134 141 533 minecraft:smooth_basalt
fill 134 141 534 134 144 534 minecraft:blackstone
setblock 134 141 538 minecraft:smooth_basalt
fill 134 141 539 134 144 539 minecraft:blackstone
fill 134 141 541 134 142 541 minecraft:blackstone
setblock 135 141 512 minecraft:smooth_basalt
fill 135 141 513 135 144 513 minecraft:blackstone
setblock 135 141 517 minecraft:smooth_basalt
fill 135 141 518 135 144 518 minecraft:blackstone
setblock 135 141 522 minecraft:smooth_basalt
fill 135 141 523 135 144 523 minecraft:blackstone
setblock 135 141 527 minecraft:smooth_basalt
fill 135 141 528 135 144 528 minecraft:blackstone
setblock 135 141 532 minecraft:smooth_basalt
fill 135 141 533 135 144 533 minecraft:blackstone
setblock 135 141 537 minecraft:smooth_basalt
fill 135 141 538 135 144 538 minecraft:blackstone
setblock 135 141 542 minecraft:smooth_basalt
fill 135 141 543 135 142 545 minecraft:blackstone
setblock 135 141 547 minecraft:smooth_basalt
fill 135 141 548 135 144 548 minecraft:blackstone
setblock 95 142 511 minecraft:smooth_basalt
fill 95 142 512 95 145 512 minecraft:blackstone
setblock 95 142 516 minecraft:smooth_basalt
fill 95 142 517 95 145 517 minecraft:blackstone
setblock 95 142 521 minecraft:smooth_basalt
fill 95 142 522 95 145 522 minecraft:blackstone
setblock 95 142 526 minecraft:smooth_basalt
fill 95 142 527 95 144 527 minecraft:blackstone
setblock 95 142 531 minecraft:smooth_basalt
fill 95 142 532 95 145 532 minecraft:blackstone
setblock 95 142 536 minecraft:smooth_basalt
fill 95 142 537 95 145 537 minecraft:blackstone
setblock 95 142 540 minecraft:blackstone
setblock 95 142 541 minecraft:smooth_basalt
fill 95 142 542 95 145 542 minecraft:blackstone
setblock 95 142 545 minecraft:blackstone
setblock 95 142 546 minecraft:smooth_basalt
fill 95 142 547 95 145 547 minecraft:blackstone
setblock 95 142 551 minecraft:smooth_basalt
fill 96 142 511 96 145 511 minecraft:blackstone
setblock 96 142 515 minecraft:smooth_basalt
fill 96 142 516 96 145 516 minecraft:blackstone
setblock 96 142 519 minecraft:blackstone
setblock 96 142 520 minecraft:smooth_basalt
fill 96 142 521 96 145 521 minecraft:blackstone
setblock 96 142 530 minecraft:smooth_basalt
setblock 96 142 531 minecraft:blackstone
setblock 96 142 535 minecraft:smooth_basalt
fill 96 142 536 96 145 536 minecraft:blackstone
setblock 96 142 540 minecraft:smooth_basalt
fill 96 142 541 96 145 541 minecraft:blackstone
fill 96 142 543 96 142 544 minecraft:blackstone
setblock 96 142 545 minecraft:smooth_basalt
fill 96 142 546 96 145 546 minecraft:blackstone
setblock 96 142 550 minecraft:smooth_basalt
fill 96 142 551 99 142 551 minecraft:blackstone
setblock 97 142 514 minecraft:smooth_basalt
fill 97 142 515 97 145 515 minecraft:blackstone
setblock 97 142 519 minecraft:smooth_basalt
fill 97 142 520 97 143 520 minecraft:blackstone
setblock 97 142 538 minecraft:blackstone
fill 97 142 550 97 144 550 minecraft:blackstone
setblock 98 142 513 minecraft:smooth_basalt
fill 98 142 514 98 143 514 minecraft:blackstone
setblock 99 142 512 minecraft:smooth_basalt
fill 99 142 513 99 144 513 minecraft:blackstone
setblock 100 142 511 minecraft:smooth_basalt
fill 100 142 512 100 144 512 minecraft:blackstone
setblock 100 142 551 minecraft:smooth_basalt
fill 101 142 511 104 142 511 minecraft:blackstone
setblock 101 142 550 minecraft:smooth_basalt
fill 101 142 551 101 145 551 minecraft:blackstone
setblock 104 142 512 minecraft:smooth_basalt
setblock 105 142 511 minecraft:smooth_basalt
setblock 105 142 512 minecraft:blackstone
setblock 105 142 551 minecraft:smooth_basalt
fill 106 142 511 106 144 511 minecraft:blackstone
fill 106 142 551 106 144 551 minecraft:blackstone
setblock 108 142 512 minecraft:blackstone
setblock 109 142 512 minecraft:smooth_basalt
setblock 110 142 511 minecraft:smooth_basalt
fill 110 142 512 110 144 512 minecraft:blackstone
setblock 110 142 551 minecraft:smooth_basalt
fill 111 142 511 111 145 511 minecraft:blackstone
setblock 111 142 550 minecraft:smooth_basalt
fill 111 142 551 111 145 551 minecraft:blackstone
fill 112 142 550 112 144 550 minecraft:blackstone
setblock 113 142 513 minecraft:smooth_basalt
setblock 114 142 512 minecraft:smooth_basalt
setblock 114 142 513 minecraft:blackstone
setblock 115 142 511 minecraft:smooth_basalt
fill 115 142 512 115 144 512 minecraft:blackstone
setblock 115 142 551 minecraft:smooth_basalt
fill 116 142 511 116 145 511 minecraft:blackstone
setblock 116 142 513 minecraft:blackstone
setblock 116 142 550 minecraft:smooth_basalt
fill 116 142 551 116 145 551 minecraft:blackstone
fill 117 142 546 119 144 546 minecraft:smooth_basalt
setblock 117 142 550 minecraft:blackstone
fill 118 142 545 118 144 545 minecraft:smooth_basalt
fill 118 142 547 118 144 547 minecraft:smooth_basalt
setblock 119 142 512 minecraft:smooth_basalt
setblock 120 142 511 minecraft:smooth_basalt
setblock 120 142 551 minecraft:smooth_basalt
setblock 121 142 511 minecraft:blackstone
setblock 129 142 512 minecraft:smooth_basalt
setblock 130 142 511 minecraft:smooth_basalt
fill 130 142 512 132 142 513 minecraft:blackstone
fill 131 142 511 131 145 511 minecraft:blackstone
setblock 132 142 514 minecraft:smooth_basalt
fill 132 142 515 132 142 518 minecraft:blackstone
setblock 133 142 512 minecraft:blackstone
setblock 133 142 513 minecraft:smooth_basalt
fill 133 142 514 133 145 514 minecraft:blackstone
setblock 133 142 517 minecraft:blackstone
setblock 133 142 518 minecraft:smooth_basalt
fill 133 142 519 133 145 519 minecraft:blackstone
setblock 133 142 523 minecraft:smooth_basalt
setblock 133 142 529 minecraft:blackstone
setblock 133 142 533 minecraft:smooth_basalt
fill 133 142 534 133 144 534 minecraft:blackstone
setblock 133 142 538 minecraft:smooth_basalt
setblock 134 142 512 minecraft:smooth_basalt
fill 134 142 513 134 145 513 minecraft:blackstone
setblock 134 142 517 minecraft:smooth_basalt
fill 134 142 518 134 145 518 minecraft:blackstone
setblock 134 142 522 minecraft:smooth_basalt
fill 134 142 523 134 145 523 minecraft:blackstone
setblock 134 142 527 minecraft:smooth_basalt
fill 134 142 528 134 145 528 minecraft:blackstone
setblock 134 142 532 minecraft:smooth_basalt
fill 134 142 533 134 145 533 minecraft:blackstone
setblock 134 142 537 minecraft:smooth_basalt
fill 134 142 538 134 145 538 minecraft:blackstone
setblock 135 142 511 minecraft:smooth_basalt
fill 135 142 512 135 145 512 minecraft:blackstone
setblock 135 142 516 minecraft:smooth_basalt
fill 135 142 517 135 145 517 minecraft:blackstone
setblock 135 142 521 minecraft:smooth_basalt
fill 135 142 522 135 145 522 minecraft:blackstone
setblock 135 142 526 minecraft:smooth_basalt
fill 135 142 527 135 145 527 minecraft:blackstone
setblock 135 142 531 minecraft:smooth_basalt
fill 135 142 532 135 145 532 minecraft:blackstone
setblock 135 142 536 minecraft:smooth_basalt
fill 135 142 537 135 145 537 minecraft:blackstone
setblock 135 142 540 minecraft:blackstone
setblock 135 142 541 minecraft:smooth_basalt
fill 135 142 542 135 145 542 minecraft:blackstone
setblock 135 142 546 minecraft:smooth_basalt
fill 135 142 547 135 144 547 minecraft:blackstone
setblock 135 142 551 minecraft:smooth_basalt
fill 95 143 511 95 146 511 minecraft:blackstone
setblock 95 143 515 minecraft:smooth_basalt
fill 95 143 516 95 146 516 minecraft:blackstone
setblock 95 143 520 minecraft:smooth_basalt
fill 95 143 521 95 146 521 minecraft:blackstone
setblock 95 143 525 minecraft:smooth_basalt
fill 95 143 526 95 145 526 minecraft:blackstone
setblock 95 143 530 minecraft:smooth_basalt
fill 95 143 531 95 145 531 minecraft:blackstone
setblock 95 143 535 minecraft:smooth_basalt
fill 95 143 536 95 146 536 minecraft:blackstone
setblock 95 143 539 minecraft:blackstone
setblock 95 143 540 minecraft:smooth_basalt
fill 95 143 541 95 146 541 minecraft:blackstone
setblock 95 143 545 minecraft:smooth_basalt
fill 95 143 546 95 146 546 minecraft:blackstone
setblock 95 143 550 minecraft:smooth_basalt
fill 95 143 551 98 143 551 minecraft:blackstone
setblock 96 143 514 minecraft:smooth_basalt
fill 96 143 515 96 146 515 minecraft:blackstone
setblock 96 143 519 minecraft:smooth_basalt
fill 96 143 520 96 146 520 minecraft:blackstone
setblock 96 143 534 minecraft:smooth_basalt
fill 96 143 535 96 145 535 minecraft:blackstone
setblock 96 143 539 minecraft:smooth_basalt
fill 96 143 540 96 146 540 minecraft:blackstone
setblock 96 143 543 minecraft:blackstone
setblock 96 143 544 minecraft:smooth_basalt
fill 96 143 545 96 146 545 minecraft:blackstone
setblock 96 143 549 minecraft:smooth_basalt
fill 96 143 550 96 145 550 minecraft:blackstone
setblock 97 143 513 minecraft:smooth_basalt
fill 97 143 514 97 145 514 minecraft:blackstone
setblock 97 143 517 minecraft:blackstone
setblock 97 143 518 minecraft:smooth_basalt
fill 97 143 519 97 145 519 minecraft:blackstone
setblock 97 143 538 minecraft:smooth_basalt
setblock 98 143 512 minecraft:smooth_basalt
fill 98 143 513 98 145 513 minecraft:blackstone
setblock 99 143 511 minecraft:smooth_basalt
fill 99 143 512 99 145 512 minecraft:blackstone
setblock 99 143 551 minecraft:smooth_basalt
fill 100 143 511 103 143 511 minecraft:blackstone
fill 100 143 551 100 145 551 minecraft:blackstone
setblock 103 143 512 minecraft:smooth_basalt
setblock 104 143 511 minecraft:smooth_basalt
setblock 104 143 551 minecraft:smooth_basalt
fill 105 143 511 105 144 511 minecraft:blackstone
fill 105 143 551 105 144 551 minecraft:blackstone
setblock 109 143 511 minecraft:smooth_basalt
setblock 109 143 512 minecraft:blackstone
setblock 109 143 551 minecraft:smooth_basalt
fill 110 143 511 110 146 511 minecraft:blackstone
setblock 110 143 550 minecraft:smooth_basalt
fill 110 143 551 110 146 551 minecraft:blackstone
fill 111 143 550 111 144 550 minecraft:blackstone
setblock 113 143 512 minecraft:smooth_basalt
setblock 114 143 511 minecraft:smooth_basalt
fill 114 143 512 114 144 512 minecraft:blackstone
setblock 114 143 551 minecraft:smooth_basalt
fill 115 143 511 115 145 511 minecraft:blackstone
setblock 115 143 550 minecraft:smooth_basalt
fill 115 143 551 115 146 551 minecraft:blackstone
setblock 116 143 550 minecraft:blackstone
setblock 118 143 512 minecraft:smooth_basalt
setblock 119 143 511 minecraft:smooth_basalt
setblock 119 143 551 minecraft:smooth_basalt
setblock 120 143 511 minecraft:blackstone
setblock 129 143 511 minecraft:smooth_basalt
fill 129 143 512 132 143 512 minecraft:blackstone
fill 130 143 511 130 146 511 minecraft:blackstone
fill 130 143 513 131 143 513 minecraft:blackstone
setblock 132 143 513 minecraft:smooth_basalt
fill 132 143 514 132 143 517 minecraft:blackstone
setblock 132 143 518 minecraft:smooth_basalt
fill 132 143 519 132 145 520 minecraft:blackstone
setblock 133 143 511 minecraft:blackstone
setblock 133 143 512 minecraft:smooth_basalt
fill 133 143 513 133 146 513 minecraft:blackstone
setblock 133 143 517 minecraft:smooth_basalt
fill 133 143 518 133 146 518 minecraft:blackstone
fill 133 143 520 133 143 521 minecraft:blackstone
setblock 133 143 522 minecraft:smooth_basalt
fill 133 143 523 133 145 524 minecraft:blackstone
setblock 133 143 532 minecraft:smooth_basalt
fill 133 143 533 133 144 533 minecraft:blackstone
setblock 133 143 536 minecraft:blackstone
setblock 133 143 537 minecraft:smooth_basalt
fill 133 143 538 133 144 539 minecraft:blackstone
setblock 134 143 511 minecraft:smooth_basalt
fill 134 143 512 134 146 512 minecraft:blackstone
setblock 134 143 516 minecraft:smooth_basalt
fill 134 143 517 134 146 517 minecraft:blackstone
setblock 134 143 521 minecraft:smooth_basalt
fill 134 143 522 134 146 522 minecraft:blackstone
setblock 134 143 526 minecraft:smooth_basalt
fill 134 143 527 134 145 527 minecraft:blackstone
setblock 134 143 531 minecraft:smooth_basalt
fill 134 143 532 134 145 532 minecraft:blackstone
setblock 134 143 536 minecraft:smooth_basalt
fill 134 143 537 134 146 537 minecraft:blackstone
setblock 134 143 541 minecraft:smooth_basalt
fill 134 143 542 134 146 542 minecraft:blackstone
setblock 134 143 551 minecraft:smooth_basalt
fill 135 143 511 135 146 511 minecraft:blackstone
setblock 135 143 515 minecraft:smooth_basalt
fill 135 143 516 135 146 516 minecraft:blackstone
setblock 135 143 520 minecraft:smooth_basalt
fill 135 143 521 135 146 521 minecraft:blackstone
setblock 135 143 525 minecraft:smooth_basalt
fill 135 143 526 135 146 526 minecraft:blackstone
setblock 135 143 530 minecraft:smooth_basalt
fill 135 143 531 135 146 531 minecraft:blackstone
setblock 135 143 535 minecraft:smooth_basalt
fill 135 143 536 135 146 536 minecraft:blackstone
setblock 135 143 540 minecraft:smooth_basalt
fill 135 143 541 135 146 541 minecraft:blackstone
fill 135 143 543 135 143 544 minecraft:blackstone
setblock 135 143 545 minecraft:smooth_basalt
fill 135 143 546 135 146 546 minecraft:blackstone
setblock 135 143 550 minecraft:smooth_basalt
fill 135 143 551 135 146 551 minecraft:blackstone
setblock 95 144 514 minecraft:smooth_basalt
fill 95 144 515 95 147 515 minecraft:blackstone
setblock 95 144 519 minecraft:smooth_basalt
fill 95 144 520 95 147 520 minecraft:blackstone
setblock 95 144 524 minecraft:smooth_basalt
fill 95 144 525 95 146 525 minecraft:blackstone
setblock 95 144 529 minecraft:smooth_basalt
setblock 95 144 530 minecraft:blackstone
setblock 95 144 534 minecraft:smooth_basalt
fill 95 144 535 95 147 535 minecraft:blackstone
setblock 95 144 539 minecraft:smooth_basalt
fill 95 144 540 95 147 540 minecraft:blackstone
setblock 95 144 544 minecraft:smooth_basalt
fill 95 144 545 95 147 545 minecraft:blackstone
setblock 95 144 549 minecraft:smooth_basalt
fill 95 144 550 95 146 551 minecraft:blackstone
setblock 96 144 513 minecraft:smooth_basalt
fill 96 144 514 96 147 514 minecraft:blackstone
setblock 96 144 518 minecraft:smooth_basalt
fill 96 144 519 96 147 519 minecraft:blackstone
setblock 96 144 523 minecraft:smooth_basalt
setblock 96 144 534 minecraft:blackstone
setblock 96 144 537 minecraft:blackstone
setblock 96 144 538 minecraft:smooth_basalt
fill 96 144 539 96 147 539 minecraft:blackstone
setblock 96 144 543 minecraft:smooth_basalt
fill 96 144 544 96 147 544 minecraft:blackstone
setblock 96 144 548 minecraft:smooth_basalt
setblock 96 144 549 minecraft:blackstone
fill 96 144 551 97 144 551 minecraft:blackstone
setblock 97 144 512 minecraft:smooth_basalt
fill 97 144 513 97 145 513 minecraft:blackstone
setblock 97 144 517 minecraft:smooth_basalt
fill 97 144 518 97 145 518 minecraft:blackstone
setblock 97 144 521 minecraft:light[level=12]
setblock 97 144 529 minecraft:light[level=12]
setblock 97 144 537 minecraft:light[level=12]
setblock 97 144 545 minecraft:light[level=12]
setblock 98 144 511 minecraft:smooth_basalt
fill 98 144 512 98 146 512 minecraft:blackstone
setblock 98 144 551 minecraft:smooth_basalt
fill 99 144 511 102 144 511 minecraft:blackstone
fill 99 144 551 99 146 551 minecraft:blackstone
setblock 103 144 511 minecraft:smooth_basalt
setblock 103 144 551 minecraft:smooth_basalt
setblock 104 144 511 minecraft:blackstone
setblock 104 144 551 minecraft:blackstone
setblock 105 144 513 minecraft:light[level=12]
setblock 105 144 521 minecraft:light[level=12]
setblock 105 144 529 minecraft:light[level=12]
setblock 105 144 537 minecraft:light[level=12]
setblock 105 144 545 minecraft:light[level=12]
setblock 108 144 511 minecraft:smooth_basalt
setblock 108 144 551 minecraft:smooth_basalt
fill 109 144 511 109 145 511 minecraft:blackstone
fill 109 144 551 109 147 551 minecraft:blackstone
setblock 112 144 512 minecraft:smooth_basalt
setblock 113 144 511 minecraft:smooth_basalt
fill 113 144 512 113 145 512 minecraft:blackstone
setblock 113 144 513 minecraft:light[level=12]
setblock 113 144 521 minecraft:light[level=12]
setblock 113 144 529 minecraft:light[level=12]
setblock 113 144 537 minecraft:light[level=12]
setblock 113 144 545 minecraft:light[level=12]
setblock 113 144 551 minecraft:smooth_basalt
fill 114 144 511 114 146 511 minecraft:blackstone
setblock 114 144 550 minecraft:smooth_basalt
fill 114 144 551 114 146 551 minecraft:blackstone
setblock 115 144 550 minecraft:blackstone
setblock 118 144 511 minecraft:smooth_basalt
setblock 118 144 551 minecraft:smooth_basalt
setblock 119 144 511 minecraft:blackstone
setblock 121 144 513 minecraft:light[level=12]
setblock 121 144 521 minecraft:light[level=12]
setblock 121 144 529 minecraft:light[level=12]
setblock 121 144 537 minecraft:light[level=12]
setblock 121 144 545 minecraft:light[level=12]
setblock 128 144 511 minecraft:smooth_basalt
fill 129 144 511 129 145 512 minecraft:blackstone
setblock 129 144 513 minecraft:light[level=12]
setblock 129 144 521 minecraft:light[level=12]
setblock 129 144 529 minecraft:light[level=12]
setblock 129 144 537 minecraft:light[level=12]
setblock 129 144 545 minecraft:light[level=12]
fill 130 144 512 130 144 513 minecraft:blackstone
setblock 131 144 512 minecraft:blackstone
setblock 131 144 513 minecraft:smooth_basalt
setblock 132 144 512 minecraft:smooth_basalt
fill 132 144 513 132 144 516 minecraft:blackstone
setblock 132 144 517 minecraft:smooth_basalt
fill 132 144 518 132 147 518 minecraft:blackstone
setblock 133 144 511 minecraft:smooth_basalt
fill 133 144 512 133 147 512 minecraft:blackstone
setblock 133 144 516 minecraft:smooth_basalt
fill 133 144 517 133 147 517 minecraft:blackstone
setblock 133 144 520 minecraft:blackstone
setblock 133 144 521 minecraft:smooth_basalt
fill 133 144 522 133 147 522 minecraft:blackstone
setblock 133 144 536 minecraft:smooth_basalt
fill 133 144 537 133 145 537 minecraft:blackstone
setblock 133 144 551 minecraft:smooth_basalt
fill 134 144 511 134 147 511 minecraft:blackstone
setblock 134 144 515 minecraft:smooth_basalt
fill 134 144 516 134 147 516 minecraft:blackstone
setblock 134 144 520 minecraft:smooth_basalt
fill 134 144 521 134 147 521 minecraft:blackstone
setblock 134 144 525 minecraft:smooth_basalt
fill 134 144 526 134 147 526 minecraft:blackstone
setblock 134 144 530 minecraft:smooth_basalt
fill 134 144 531 134 145 531 minecraft:blackstone
setblock 134 144 535 minecraft:smooth_basalt
fill 134 144 536 134 146 536 minecraft:blackstone
setblock 134 144 540 minecraft:smooth_basalt
fill 134 144 541 134 147 541 minecraft:blackstone
fill 134 144 551 134 146 551 minecraft:blackstone
setblock 135 144 514 minecraft:smooth_basalt
fill 135 144 515 135 147 515 minecraft:blackstone
setblock 135 144 519 minecraft:smooth_basalt
fill 135 144 520 135 147 520 minecraft:blackstone
setblock 135 144 524 minecraft:smooth_basalt
fill 135 144 525 135 147 525 minecraft:blackstone
setblock 135 144 529 minecraft:smooth_basalt
fill 135 144 530 135 146 530 minecraft:blackstone
setblock 135 144 534 minecraft:smooth_basalt
fill 135 144 535 135 147 535 minecraft:blackstone
setblock 135 144 539 minecraft:smooth_basalt
fill 135 144 540 135 147 540 minecraft:blackstone
setblock 135 144 543 minecraft:blackstone
setblock 135 144 544 minecraft:smooth_basalt
fill 135 144 545 135 147 545 minecraft:blackstone
setblock 135 144 549 minecraft:smooth_basalt
fill 135 144 550 135 145 550 minecraft:blackstone
setblock 95 145 513 minecraft:smooth_basalt
fill 95 145 514 95 148 514 minecraft:blackstone
setblock 95 145 518 minecraft:smooth_basalt
fill 95 145 519 95 148 519 minecraft:blackstone
setblock 95 145 523 minecraft:smooth_basalt
fill 95 145 524 95 148 524 minecraft:blackstone
setblock 95 145 533 minecraft:smooth_basalt
fill 95 145 534 95 146 534 minecraft:blackstone
setblock 95 145 538 minecraft:smooth_basalt
fill 95 145 539 95 148 539 minecraft:blackstone
setblock 95 145 543 minecraft:smooth_basalt
fill 95 145 544 95 148 544 minecraft:blackstone
setblock 95 145 548 minecraft:smooth_basalt
fill 95 145 549 95 148 549 minecraft:blackstone
setblock 96 145 512 minecraft:smooth_basalt
fill 96 145 513 96 147 513 minecraft:blackstone
setblock 96 145 517 minecraft:smooth_basalt
fill 96 145 518 96 148 518 minecraft:blackstone
setblock 96 145 522 minecraft:smooth_basalt
setblock 96 145 537 minecraft:smooth_basalt
fill 96 145 538 96 146 538 minecraft:blackstone
setblock 96 145 542 minecraft:smooth_basalt
fill 96 145 543 96 148 543 minecraft:blackstone
setblock 96 145 551 minecraft:blackstone
setblock 97 145 511 minecraft:smooth_basalt
fill 97 145 512 97 146 512 minecraft:blackstone
setblock 97 145 516 minecraft:smooth_basalt
fill 97 145 517 97 146 517 minecraft:blackstone
setblock 97 145 551 minecraft:smooth_basalt
fill 98 145 511 101 145 511 minecraft:blackstone
fill 98 145 551 98 146 551 minecraft:blackstone
setblock 102 145 511 minecraft:smooth_basalt
setblock 107 145 551 minecraft:smooth_basalt
setblock 108 145 511 minecraft:blackstone
fill 108 145 551 108 146 551 minecraft:blackstone
setblock 112 145 511 minecraft:smooth_basalt
setblock 112 145 551 minecraft:smooth_basalt
fill 113 145 511 113 146 511 minecraft:blackstone
fill 113 145 551 113 147 551 minecraft:blackstone
setblock 117 145 511 minecraft:smooth_basalt
fill 118 145 546 118 149 546 minecraft:smooth_basalt
setblock 128 145 511 minecraft:blackstone
setblock 130 145 512 minecraft:blackstone
setblock 131 145 512 minecraft:smooth_basalt
fill 131 145 513 132 146 513 minecraft:blackstone
setblock 132 145 511 minecraft:smooth_basalt
fill 132 145 512 132 148 512 minecraft:blackstone
fill 132 145 514 132 145 515 minecraft:blackstone
setblock 132 145 516 minecraft:smooth_basalt
fill 132 145 517 132 148 517 minecraft:blackstone
setblock 132 145 521 minecraft:smooth_basalt
fill 133 145 511 133 148 511 minecraft:blackstone
setblock 133 145 515 minecraft:smooth_basalt
fill 133 145 516 133 148 516 minecraft:blackstone
setblock 133 145 520 minecraft:smooth_basalt
fill 133 145 521 133 148 521 minecraft:blackstone
setblock 133 145 536 minecraft:blackstone
setblock 133 145 538 minecraft:blackstone
setblock 133 145 551 minecraft:blackstone
setblock 134 145 514 minecraft:smooth_basalt
fill 134 145 515 134 148 515 minecraft:blackstone
setblock 134 145 519 minecraft:smooth_basalt
fill 134 145 520 134 148 520 minecraft:blackstone
setblock 134 145 524 minecraft:smooth_basalt
fill 134 145 525 134 148 525 minecraft:blackstone
setblock 134 145 529 minecraft:smooth_basalt
setblock 134 145 530 minecraft:blackstone
setblock 134 145 534 minecraft:smooth_basalt
fill 134 145 535 134 146 535 minecraft:blackstone
setblock 134 145 539 minecraft:smooth_basalt
fill 134 145 540 134 148 540 minecraft:blackstone
setblock 135 145 513 minecraft:smooth_basalt
fill 135 145 514 135 148 514 minecraft:blackstone
setblock 135 145 518 minecraft:smooth_basalt
fill 135 145 519 135 148 519 minecraft:blackstone
setblock 135 145 523 minecraft:smooth_basalt
fill 135 145 524 135 148 524 minecraft:blackstone
setblock 135 145 528 minecraft:smooth_basalt
fill 135 145 529 135 146 529 minecraft:blackstone
setblock 135 145 533 minecraft:smooth_basalt
fill 135 145 534 135 147 534 minecraft:blackstone
setblock 135 145 538 minecraft:smooth_basalt
fill 135 145 539 135 148 539 minecraft:blackstone
setblock 135 145 543 minecraft:smooth_basalt
fill 135 145 544 135 148 544 minecraft:blackstone
setblock 95 146 512 minecraft:smooth_basalt
fill 95 146 513 95 149 513 minecraft:blackstone
setblock 95 146 517 minecraft:smooth_basalt
fill 95 146 518 95 149 518 minecraft:blackstone
setblock 95 146 522 minecraft:smooth_basalt
fill 95 146 523 95 149 523 minecraft:blackstone
setblock 95 146 533 minecraft:blackstone
setblock 95 146 537 minecraft:smooth_basalt
fill 95 146 538 95 149 538 minecraft:blackstone
setblock 95 146 542 minecraft:smooth_basalt
fill 95 146 543 95 149 543 minecraft:blackstone
setblock 95 146 547 minecraft:smooth_basalt
fill 95 146 548 95 149 548 minecraft:blackstone
setblock 96 146 511 minecraft:smooth_basalt
fill 96 146 512 96 147 512 minecraft:blackstone
setblock 96 146 516 minecraft:smooth_basalt
fill 96 146 517 96 148 517 minecraft:blackstone
setblock 96 146 521 minecraft:smooth_basalt
setblock 96 146 537 minecraft:blackstone
setblock 96 146 541 minecraft:smooth_basalt
fill 96 146 542 96 149 542 minecraft:blackstone
setblock 96 146 551 minecraft:smooth_basalt
fill 97 146 511 100 146 511 minecraft:blackstone
setblock 97 146 515 minecraft:smooth_basalt
setblock 97 146 516 minecraft:blackstone
fill 97 146 551 97 147 551 minecraft:blackstone
setblock 111 146 511 minecraft:smooth_basalt
setblock 111 146 551 minecraft:smooth_basalt
setblock 112 146 511 minecraft:blackstone
fill 112 146 551 112 148 551 minecraft:blackstone
fill 129 146 511 129 147 511 minecraft:blackstone
setblock 130 146 512 minecraft:smooth_basalt
setblock 131 146 511 minecraft:smooth_basalt
fill 131 146 512 131 149 512 minecraft:blackstone
fill 132 146 511 132 149 511 minecraft:blackstone
setblock 132 146 515 minecraft:smooth_basalt
fill 132 146 516 132 147 516 minecraft:blackstone
setblock 132 146 519 minecraft:blackstone
setblock 132 146 520 minecraft:smooth_basalt
fill 132 146 521 132 149 521 minecraft:blackstone
setblock 133 146 514 minecraft:smooth_basalt
fill 133 146 515 133 149 515 minecraft:blackstone
setblock 133 146 519 minecraft:smooth_basalt
fill 133 146 520 133 149 520 minecraft:blackstone
setblock 133 146 523 minecraft:blackstone
setblock 133 146 524 minecraft:smooth_basalt
setblock 134 146 513 minecraft:smooth_basalt
fill 134 146 514 134 149 514 minecraft:blackstone
setblock 134 146 518 minecraft:smooth_basalt
fill 134 146 519 134 149 519 minecraft:blackstone
setblock 134 146 523 minecraft:smooth_basalt
fill 134 146 524 134 149 524 minecraft:blackstone
setblock 134 146 534 minecraft:blackstone
setblock 134 146 538 minecraft:smooth_basalt
fill 134 146 539 134 147 539 minecraft:blackstone
setblock 135 146 512 minecraft:smooth_basalt
fill 135 146 513 135 149 513 minecraft:blackstone
setblock 135 146 517 minecraft:smooth_basalt
fill 135 146 518 135 149 518 minecraft:blackstone
setblock 135 146 522 minecraft:smooth_basalt
fill 135 146 523 135 149 523 minecraft:blackstone
setblock 135 146 527 minecraft:smooth_basalt
fill 135 146 528 135 147 528 minecraft:blackstone
setblock 135 146 532 minecraft:smooth_basalt
fill 135 146 533 135 147 533 minecraft:blackstone
setblock 135 146 537 minecraft:smooth_basalt
fill 135 146 538 135 149 538 minecraft:blackstone
setblock 135 146 542 minecraft:smooth_basalt
fill 135 146 543 135 149 543 minecraft:blackstone
setblock 95 147 511 minecraft:smooth_basalt
fill 95 147 512 95 150 512 minecraft:blackstone
setblock 95 147 516 minecraft:smooth_basalt
fill 95 147 517 95 150 517 minecraft:blackstone
setblock 95 147 521 minecraft:smooth_basalt
fill 95 147 522 95 150 522 minecraft:blackstone
setblock 95 147 536 minecraft:smooth_basalt
fill 95 147 537 95 149 537 minecraft:blackstone
setblock 95 147 541 minecraft:smooth_basalt
fill 95 147 542 95 150 542 minecraft:blackstone
setblock 95 147 546 minecraft:smooth_basalt
fill 95 147 547 95 150 547 minecraft:blackstone
setblock 95 147 550 minecraft:blackstone
setblock 95 147 551 minecraft:smooth_basalt
fill 96 147 511 98 147 511 minecraft:blackstone
setblock 96 147 515 minecraft:smooth_basalt
fill 96 147 516 96 148 516 minecraft:blackstone
setblock 96 147 520 minecraft:smooth_basalt
setblock 96 147 521 minecraft:blackstone
setblock 96 147 540 minecraft:smooth_basalt
fill 96 147 541 96 150 541 minecraft:blackstone
setblock 96 147 545 minecraft:smooth_basalt
fill 96 147 551 96 150 551 minecraft:blackstone
setblock 110 147 551 minecraft:smooth_basalt
fill 111 147 551 111 150 551 minecraft:blackstone
setblock 130 147 511 minecraft:smooth_basalt
fill 130 147 512 130 148 512 minecraft:blackstone
fill 131 147 511 131 150 511 minecraft:blackstone
setblock 132 147 513 minecraft:blackstone
setblock 132 147 519 minecraft:smooth_basalt
fill 132 147 520 132 150 520 minecraft:blackstone
setblock 133 147 513 minecraft:smooth_basalt
fill 133 147 514 133 149 514 minecraft:blackstone
setblock 133 147 518 minecraft:smooth_basalt
fill 133 147 519 133 150 519 minecraft:blackstone
setblock 133 147 523 minecraft:smooth_basalt
setblock 133 147 524 minecraft:blackstone
setblock 134 147 512 minecraft:smooth_basalt
fill 134 147 513 134 150 513 minecraft:blackstone
setblock 134 147 517 minecraft:smooth_basalt
fill 134 147 518 134 150 518 minecraft:blackstone
setblock 134 147 522 minecraft:smooth_basalt
fill 134 147 523 134 150 523 minecraft:blackstone
setblock 134 147 537 minecraft:smooth_basalt
setblock 134 147 538 minecraft:blackstone
setblock 134 147 542 minecraft:smooth_basalt
setblock 135 147 511 minecraft:smooth_basalt
fill 135 147 512 135 150 512 minecraft:blackstone
setblock 135 147 516 minecraft:smooth_basalt
fill 135 147 517 135 150 517 minecraft:blackstone
setblock 135 147 521 minecraft:smooth_basalt
fill 135 147 522 135 150 522 minecraft:blackstone
setblock 135 147 526 minecraft:smooth_basalt
fill 135 147 527 135 148 527 minecraft:blackstone
setblock 135 147 536 minecraft:smooth_basalt
fill 135 147 537 135 148 537 minecraft:blackstone
setblock 135 147 541 minecraft:smooth_basalt
fill 135 147 542 135 150 542 minecraft:blackstone
setblock 135 147 546 minecraft:smooth_basalt
fill 95 148 511 97 148 511 minecraft:blackstone
setblock 95 148 515 minecraft:smooth_basalt
fill 95 148 516 95 151 516 minecraft:blackstone
setblock 95 148 520 minecraft:smooth_basalt
fill 95 148 521 95 151 521 minecraft:blackstone
setblock 95 148 536 minecraft:blackstone
setblock 95 148 540 minecraft:smooth_basalt
fill 95 148 541 95 151 541 minecraft:blackstone
setblock 95 148 545 minecraft:smooth_basalt
fill 95 148 546 95 151 546 minecraft:blackstone
setblock 95 148 550 minecraft:smooth_basalt
fill 95 148 551 95 151 551 minecraft:blackstone
setblock 96 148 514 minecraft:smooth_basalt
setblock 96 148 515 minecraft:blackstone
setblock 96 148 519 minecraft:smooth_basalt
setblock 96 148 520 minecraft:blackstone
setblock 96 148 540 minecraft:blackstone
setblock 96 148 544 minecraft:smooth_basalt
fill 96 148 545 96 151 545 minecraft:blackstone
setblock 109 148 551 minecraft:smooth_basalt
fill 110 148 551 110 151 551 minecraft:blackstone
setblock 129 148 511 minecraft:smooth_basalt
fill 130 148 511 130 151 511 minecraft:blackstone
setblock 132 148 518 minecraft:smooth_basalt
fill 132 148 519 132 151 519 minecraft:blackstone
setblock 133 148 512 minecraft:smooth_basalt
setblock 133 148 517 minecraft:smooth_basalt
fill 133 148 518 133 151 518 minecraft:blackstone
setblock 133 148 522 minecraft:smooth_basalt
fill 133 148 523 133 151 523 minecraft:blackstone
setblock 134 148 511 minecraft:smooth_basalt
fill 134 148 512 134 149 512 minecraft:blackstone
setblock 134 148 516 minecraft:smooth_basalt
fill 134 148 517 134 151 517 minecraft:blackstone
setblock 134 148 521 minecraft:smooth_basalt
fill 134 148 522 134 151 522 minecraft:blackstone
setblock 134 148 541 minecraft:smooth_basalt
fill 135 148 511 135 151 511 minecraft:blackstone
setblock 135 148 515 minecraft:smooth_basalt
fill 135 148 516 135 151 516 minecraft:blackstone
setblock 135 148 520 minecraft:smooth_basalt
fill 135 148 521 135 151 521 minecraft:blackstone
setblock 135 148 525 minecraft:smooth_basalt
fill 135 148 526 135 151 526 minecraft:blackstone
setblock 135 148 536 minecraft:blackstone
setblock 135 148 540 minecraft:smooth_basalt
fill 135 148 541 135 151 541 minecraft:blackstone
setblock 135 148 545 minecraft:smooth_basalt
fill 135 148 546 135 151 546 minecraft:blackstone
fill 95 149 511 96 149 511 minecraft:blackstone
setblock 95 149 514 minecraft:smooth_basalt
fill 95 149 515 95 152 515 minecraft:blackstone
setblock 95 149 519 minecraft:smooth_basalt
fill 95 149 520 95 152 520 minecraft:blackstone
setblock 95 149 524 minecraft:smooth_basalt
setblock 95 149 539 minecraft:smooth_basalt
fill 95 149 540 95 152 540 minecraft:blackstone
setblock 95 149 544 minecraft:smooth_basalt
fill 95 149 545 95 152 545 minecraft:blackstone
setblock 95 149 549 minecraft:smooth_basalt
fill 95 149 550 95 152 550 minecraft:blackstone
setblock 96 149 518 minecraft:smooth_basalt
setblock 96 149 543 minecraft:smooth_basalt
fill 96 149 544 96 152 544 minecraft:blackstone
fill 109 149 551 109 152 551 minecraft:blackstone
fill 128 149 520 131 150 524 minecraft:blackstone
fill 129 149 511 129 152 511 minecraft:blackstone
setblock 132 149 512 minecraft:smooth_basalt
setblock 132 149 517 minecraft:smooth_basalt
fill 132 149 518 132 150 518 minecraft:blackstone
fill 132 149 522 132 150 524 minecraft:blackstone
setblock 133 149 511 minecraft:smooth_basalt
fill 133 149 512 133 152 512 minecraft:blackstone
setblock 133 149 516 minecraft:smooth_basalt
fill 133 149 517 133 152 517 minecraft:blackstone
setblock 133 149 521 minecraft:smooth_basalt
fill 133 149 522 133 152 522 minecraft:blackstone
fill 133 149 524 133 150 524 minecraft:blackstone
fill 134 149 511 134 152 511 minecraft:blackstone
setblock 134 149 515 minecraft:smooth_basalt
fill 134 149 516 134 152 516 minecraft:blackstone
setblock 134 149 520 minecraft:smooth_basalt
fill 134 149 521 134 152 521 minecraft:blackstone
setblock 134 149 525 minecraft:smooth_basalt
setblock 135 149 514 minecraft:smooth_basalt
fill 135 149 515 135 152 515 minecraft:blackstone
setblock 135 149 519 minecraft:smooth_basalt
fill 135 149 520 135 152 520 minecraft:blackstone
setblock 135 149 524 minecraft:smooth_basalt
fill 135 149 525 135 152 525 minecraft:blackstone
setblock 135 149 539 minecraft:smooth_basalt
fill 135 149 540 135 152 540 minecraft:blackstone
setblock 135 149 544 minecraft:smooth_basalt
fill 135 149 545 135 152 545 minecraft:blackstone
setblock 95 150 511 minecraft:blackstone
setblock 95 150 513 minecraft:smooth_basalt
fill 95 150 514 95 151 514 minecraft:blackstone
setblock 95 150 518 minecraft:smooth_basalt
fill 95 150 519 95 153 519 minecraft:blackstone
setblock 95 150 523 minecraft:smooth_basalt
fill 95 150 524 95 153 524 minecraft:blackstone
setblock 95 150 538 minecraft:smooth_basalt
fill 95 150 539 95 153 539 minecraft:blackstone
setblock 95 150 543 minecraft:smooth_basalt
fill 95 150 544 95 153 544 minecraft:blackstone
setblock 95 150 548 minecraft:smooth_basalt
fill 95 150 549 95 153 549 minecraft:blackstone
setblock 96 150 542 minecraft:smooth_basalt
fill 96 150 543 96 153 543 minecraft:blackstone
setblock 96 150 546 minecraft:blackstone
fill 108 150 551 108 153 551 minecraft:blackstone
setblock 118 150 546 minecraft:shroomlight
fill 128 150 511 128 153 511 minecraft:blackstone
setblock 131 150 512 minecraft:smooth_basalt
setblock 132 150 511 minecraft:smooth_basalt
fill 132 150 512 132 153 512 minecraft:blackstone
setblock 132 150 521 minecraft:smooth_basalt
fill 133 150 511 133 153 511 minecraft:blackstone
setblock 133 150 515 minecraft:smooth_basalt
fill 133 150 516 133 152 516 minecraft:blackstone
setblock 133 150 520 minecraft:smooth_basalt
fill 133 150 521 133 153 521 minecraft:blackstone
setblock 134 150 514 minecraft:smooth_basalt
fill 134 150 515 134 153 515 minecraft:blackstone
setblock 134 150 519 minecraft:smooth_basalt
fill 134 150 520 134 153 520 minecraft:blackstone
setblock 134 150 524 minecraft:smooth_basalt
fill 134 150 525 134 153 525 minecraft:blackstone
setblock 135 150 513 minecraft:smooth_basalt
fill 135 150 514 135 153 514 minecraft:blackstone
setblock 135 150 518 minecraft:smooth_basalt
fill 135 150 519 135 153 519 minecraft:blackstone
setblock 135 150 523 minecraft:smooth_basalt
fill 135 150 524 135 153 524 minecraft:blackstone
setblock 135 150 539 minecraft:blackstone
setblock 135 150 543 minecraft:smooth_basalt
fill 135 150 544 135 153 544 minecraft:blackstone
setblock 135 150 547 minecraft:blackstone
setblock 95 151 513 minecraft:blackstone
setblock 95 151 517 minecraft:smooth_basalt
fill 95 151 518 95 153 518 minecraft:blackstone
setblock 95 151 522 minecraft:smooth_basalt
fill 95 151 523 95 153 523 minecraft:blackstone
setblock 95 151 538 minecraft:blackstone
setblock 95 151 542 minecraft:smooth_basalt
fill 95 151 543 95 153 543 minecraft:blackstone
setblock 95 151 547 minecraft:smooth_basalt
fill 95 151 548 95 153 548 minecraft:blackstone
fill 96 151 542 96 153 542 minecraft:blackstone
setblock 96 151 546 minecraft:smooth_basalt
fill 96 151 547 96 153 547 minecraft:blackstone
setblock 96 151 551 minecraft:smooth_basalt
setblock 106 151 551 minecraft:smooth_basalt
fill 107 151 551 107 153 551 minecraft:blackstone
setblock 111 151 551 minecraft:smooth_basalt
fill 112 151 551 112 153 551 minecraft:blackstone
fill 129 151 521 131 152 523 minecraft:smooth_basalt
setblock 130 151 512 minecraft:smooth_basalt
setblock 131 151 511 minecraft:smooth_basalt
fill 131 151 512 131 153 512 minecraft:blackstone
setblock 131 151 551 minecraft:smooth_basalt
fill 132 151 511 132 153 511 minecraft:blackstone
setblock 132 151 520 minecraft:smooth_basalt
fill 132 151 521 132 153 522 minecraft:blackstone
fill 132 151 551 133 153 551 minecraft:blackstone
setblock 133 151 519 minecraft:smooth_basalt
fill 133 151 520 133 153 520 minecraft:blackstone
setblock 133 151 524 minecraft:smooth_basalt
setblock 134 151 513 minecraft:smooth_basalt
fill 134 151 514 134 153 514 minecraft:blackstone
setblock 134 151 518 minecraft:smooth_basalt
fill 134 151 519 134 153 519 minecraft:blackstone
setblock 134 151 523 minecraft:smooth_basalt
fill 134 151 524 134 153 524 minecraft:blackstone
setblock 135 151 512 minecraft:smooth_basalt
fill 135 151 513 135 153 513 minecraft:blackstone
setblock 135 151 517 minecraft:smooth_basalt
fill 135 151 518 135 153 518 minecraft:blackstone
setblock 135 151 522 minecraft:smooth_basalt
fill 135 151 523 135 153 523 minecraft:blackstone
setblock 135 151 527 minecraft:smooth_basalt
setblock 135 151 542 minecraft:smooth_basalt
fill 135 151 543 135 153 543 minecraft:blackstone
setblock 135 151 547 minecraft:smooth_basalt
fill 135 151 548 135 153 549 minecraft:blackstone
setblock 95 152 516 minecraft:smooth_basalt
fill 95 152 517 95 153 517 minecraft:blackstone
setblock 95 152 521 minecraft:smooth_basalt
fill 95 152 522 95 153 522 minecraft:blackstone
setblock 95 152 541 minecraft:smooth_basalt
fill 95 152 542 95 153 542 minecraft:blackstone
setblock 95 152 546 minecraft:smooth_basalt
fill 95 152 547 95 153 547 minecraft:blackstone
setblock 95 152 551 minecraft:smooth_basalt
setblock 96 152 545 minecraft:smooth_basalt
fill 96 152 546 96 153 546 minecraft:blackstone
fill 96 152 548 96 153 548 minecraft:blackstone
fill 96 152 551 97 153 551 minecraft:blackstone
setblock 97 152 513 minecraft:light[level=12]
setblock 97 152 521 minecraft:light[level=12]
setblock 97 152 529 minecraft:light[level=12]
setblock 97 152 537 minecraft:light[level=12]
setblock 97 152 545 minecraft:light[level=12]
setblock 104 152 551 minecraft:blackstone
setblock 105 152 513 minecraft:light[level=12]
setblock 105 152 521 minecraft:light[level=12]
setblock 105 152 529 minecraft:light[level=12]
setblock 105 152 537 minecraft:light[level=12]
setblock 105 152 545 minecraft:light[level=12]
setblock 105 152 551 minecraft:smooth_basalt
setblock 106 152 550 minecraft:smooth_basalt
fill 106 152 551 106 153 551 minecraft:blackstone
fill 107 152 550 110 152 550 minecraft:blackstone
setblock 110 152 551 minecraft:smooth_basalt
fill 111 152 551 111 153 551 minecraft:blackstone
setblock 113 152 513 minecraft:light[level=12]
setblock 113 152 521 minecraft:light[level=12]
setblock 113 152 529 minecraft:light[level=12]
setblock 113 152 537 minecraft:light[level=12]
setblock 113 152 545 minecraft:light[level=12]
setblock 121 152 513 minecraft:light[level=12]
setblock 121 152 521 minecraft:light[level=12]
setblock 121 152 529 minecraft:light[level=12]
setblock 121 152 537 minecraft:light[level=12]
setblock 121 152 545 minecraft:light[level=12]
fill 127 152 511 127 153 511 minecraft:blackstone
fill 128 152 551 129 152 551 minecraft:blackstone
setblock 129 152 512 minecraft:smooth_basalt
setblock 129 152 513 minecraft:light[level=12]
setblock 129 152 529 minecraft:light[level=12]
setblock 129 152 537 minecraft:light[level=12]
setblock 129 152 545 minecraft:light[level=12]
setblock 130 152 511 minecraft:smooth_basalt
fill 130 152 512 130 153 512 minecraft:blackstone
setblock 130 152 551 minecraft:smooth_basalt
fill 131 152 511 131 153 511 minecraft:blackstone
fill 131 152 551 131 153 551 minecraft:blackstone
setblock 132 152 519 minecraft:smooth_basalt
fill 132 152 520 132 153 520 minecraft:blackstone
setblock 133 152 518 minecraft:smooth_basalt
fill 133 152 519 133 153 519 minecraft:blackstone
setblock 133 152 523 minecraft:smooth_basalt
fill 133 152 524 133 153 524 minecraft:blackstone
setblock 134 152 517 minecraft:smooth_basalt
fill 134 152 518 134 153 518 minecraft:blackstone
setblock 134 152 522 minecraft:smooth_basalt
fill 134 152 523 134 153 523 minecraft:blackstone
setblock 134 152 526 minecraft:blackstone
fill 134 152 543 134 152 546 minecraft:blackstone
setblock 134 152 551 minecraft:blackstone
setblock 135 152 511 minecraft:smooth_basalt
fill 135 152 512 135 153 512 minecraft:blackstone
setblock 135 152 516 minecraft:smooth_basalt
fill 135 152 517 135 153 517 minecraft:blackstone
setblock 135 152 521 minecraft:smooth_basalt
fill 135 152 522 135 153 522 minecraft:blackstone
setblock 135 152 526 minecraft:smooth_basalt
fill 135 152 527 135 153 527 minecraft:blackstone
setblock 135 152 541 minecraft:smooth_basalt
fill 135 152 542 135 153 542 minecraft:blackstone
setblock 135 152 546 minecraft:smooth_basalt
fill 135 152 547 135 153 547 minecraft:blackstone
setblock 135 152 550 minecraft:blackstone
setblock 135 152 551 minecraft:smooth_basalt
setblock 95 153 520 minecraft:smooth_basalt
setblock 95 153 521 minecraft:blackstone
setblock 95 153 525 minecraft:smooth_basalt
setblock 95 153 540 minecraft:smooth_basalt
setblock 95 153 541 minecraft:blackstone
setblock 95 153 545 minecraft:smooth_basalt
setblock 95 153 546 minecraft:blackstone
setblock 95 153 550 minecraft:smooth_basalt
setblock 95 153 551 minecraft:blackstone
setblock 96 153 544 minecraft:smooth_basalt
setblock 96 153 545 minecraft:blackstone
setblock 96 153 549 minecraft:smooth_basalt
setblock 98 153 551 minecraft:blackstone
setblock 99 153 551 minecraft:smooth_basalt
fill 100 153 551 103 153 551 minecraft:blackstone
setblock 104 153 550 minecraft:blackstone
setblock 104 153 551 minecraft:smooth_basalt
setblock 105 153 550 minecraft:smooth_basalt
setblock 105 153 551 minecraft:blackstone
fill 106 153 550 109 153 550 minecraft:blackstone
fill 107 153 549 109 153 549 minecraft:blackstone
setblock 109 153 551 minecraft:smooth_basalt
setblock 110 153 550 minecraft:smooth_basalt
setblock 110 153 551 minecraft:blackstone
setblock 111 153 550 minecraft:blackstone
setblock 126 153 511 minecraft:blackstone
fill 127 153 551 128 153 551 minecraft:blackstone
setblock 128 153 512 minecraft:smooth_basalt
setblock 129 153 511 minecraft:smooth_basalt
setblock 129 153 512 minecraft:blackstone
fill 129 153 522 131 153 522 minecraft:smooth_basalt
setblock 129 153 550 minecraft:blackstone
setblock 129 153 551 minecraft:smooth_basalt
setblock 130 153 511 minecraft:blackstone
setblock 130 153 521 minecraft:smooth_basalt
setblock 130 153 523 minecraft:smooth_basalt
setblock 130 153 550 minecraft:smooth_basalt
setblock 130 153 551 minecraft:blackstone
fill 131 153 550 132 153 550 minecraft:blackstone
setblock 132 153 523 minecraft:smooth_basalt
setblock 133 153 512 minecraft:smooth_basalt
setblock 133 153 517 minecraft:smooth_basalt
setblock 133 153 518 minecraft:blackstone
setblock 133 153 522 minecraft:smooth_basalt
setblock 133 153 523 minecraft:blackstone
setblock 133 153 525 minecraft:blackstone
setblock 134 153 511 minecraft:smooth_basalt
setblock 134 153 516 minecraft:smooth_basalt
setblock 134 153 517 minecraft:blackstone
setblock 134 153 521 minecraft:smooth_basalt
setblock 134 153 522 minecraft:blackstone
setblock 134 153 526 minecraft:smooth_basalt
fill 134 153 543 134 153 545 minecraft:blackstone
setblock 134 153 546 minecraft:smooth_basalt
fill 134 153 547 134 153 548 minecraft:blackstone
setblock 134 153 551 minecraft:smooth_basalt
setblock 135 153 511 minecraft:blackstone
setblock 135 153 515 minecraft:smooth_basalt
setblock 135 153 516 minecraft:blackstone
setblock 135 153 520 minecraft:smooth_basalt
setblock 135 153 521 minecraft:blackstone
setblock 135 153 525 minecraft:smooth_basalt
setblock 135 153 526 minecraft:blackstone
setblock 135 153 541 minecraft:blackstone
setblock 135 153 545 minecraft:smooth_basalt
setblock 135 153 546 minecraft:blackstone
setblock 135 153 550 minecraft:smooth_basalt
setblock 135 153 551 minecraft:blackstone
fill 120 154 530 126 171 532 minecraft:jungle_log
fill 121 154 529 125 172 529 minecraft:jungle_log
fill 121 154 533 125 172 533 minecraft:jungle_log
fill 122 154 528 124 172 528 minecraft:jungle_log
fill 122 154 534 124 172 534 minecraft:jungle_log
fill 107 158 527 109 158 529 minecraft:redstone_block
fill 107 158 533 109 158 535 minecraft:redstone_block
fill 114 158 526 116 158 528 minecraft:redstone_block
fill 95 159 511 96 160 521 minecraft:black_concrete
fill 95 159 522 135 160 522 minecraft:gilded_blackstone
fill 95 159 523 96 160 533 minecraft:black_concrete
fill 95 159 534 106 159 534 minecraft:gilded_blackstone
fill 95 159 535 96 160 545 minecraft:black_concrete
fill 95 159 546 135 160 546 minecraft:gilded_blackstone
fill 95 159 547 96 160 551 minecraft:black_concrete
fill 97 159 511 97 160 521 minecraft:gold_block
fill 97 159 523 97 160 533 minecraft:gold_block
fill 97 159 535 97 160 545 minecraft:gold_block
fill 97 159 547 97 160 551 minecraft:gold_block
fill 98 159 511 99 160 521 minecraft:black_concrete
fill 98 159 523 99 160 533 minecraft:black_concrete
fill 98 159 535 99 160 545 minecraft:black_concrete
fill 98 159 547 99 160 551 minecraft:black_concrete
fill 100 159 511 100 160 521 minecraft:gold_block
fill 100 159 523 100 160 533 minecraft:gold_block
fill 100 159 535 100 160 545 minecraft:gold_block
fill 100 159 547 100 160 551 minecraft:gold_block
fill 101 159 511 102 160 521 minecraft:black_concrete
fill 101 159 523 102 160 533 minecraft:black_concrete
fill 101 159 535 102 160 545 minecraft:black_concrete
fill 101 159 547 102 160 551 minecraft:black_concrete
fill 103 159 511 103 160 521 minecraft:gold_block
fill 103 159 523 103 160 533 minecraft:gold_block
fill 103 159 535 103 160 545 minecraft:gold_block
fill 103 159 547 103 160 551 minecraft:gold_block
fill 104 159 511 105 160 521 minecraft:black_concrete
fill 104 159 523 105 160 533 minecraft:black_concrete
fill 104 159 535 105 160 545 minecraft:black_concrete
fill 104 159 547 105 160 551 minecraft:black_concrete
fill 106 159 511 106 160 521 minecraft:gold_block
fill 106 159 523 106 159 533 minecraft:gold_block
fill 106 159 535 106 159 545 minecraft:gold_block
fill 106 159 547 106 160 551 minecraft:gold_block
fill 107 159 511 108 160 521 minecraft:black_concrete
fill 107 159 523 108 159 526 minecraft:black_concrete
fill 107 159 530 108 159 532 minecraft:black_concrete
fill 107 159 536 108 159 545 minecraft:black_concrete
fill 107 159 547 108 160 551 minecraft:black_concrete
fill 109 159 511 109 160 521 minecraft:gold_block
fill 109 159 523 109 159 526 minecraft:gold_block
fill 109 159 530 109 159 532 minecraft:gold_block
fill 109 159 536 109 159 545 minecraft:gold_block
fill 109 159 547 109 160 551 minecraft:gold_block
fill 110 159 511 111 160 521 minecraft:black_concrete
fill 110 159 523 110 159 533 minecraft:black_concrete
fill 110 159 534 121 159 534 minecraft:gilded_blackstone
fill 110 159 535 111 159 545 minecraft:black_concrete
fill 110 159 547 111 160 551 minecraft:black_concrete
fill 111 159 523 111 159 529 minecraft:black_concrete
setblock 111 159 533 minecraft:black_concrete
fill 112 159 511 112 160 521 minecraft:gold_block
fill 112 159 523 112 159 529 minecraft:gold_block
setblock 112 159 533 minecraft:gold_block
fill 112 159 535 112 160 545 minecraft:gold_block
fill 112 159 547 112 160 551 minecraft:gold_block
fill 113 159 511 114 160 521 minecraft:black_concrete
fill 113 159 523 113 159 529 minecraft:black_concrete
fill 113 159 533 114 159 533 minecraft:black_concrete
fill 113 159 535 114 160 545 minecraft:black_concrete
fill 113 159 547 114 160 551 minecraft:black_concrete
fill 114 159 523 114 159 525 minecraft:black_concrete
fill 114 159 529 114 159 532 minecraft:black_concrete
fill 115 159 511 115 160 521 minecraft:gold_block
fill 115 159 523 115 159 525 minecraft:gold_block
fill 115 159 529 115 159 533 minecraft:gold_block
fill 115 159 535 115 160 545 minecraft:gold_block
fill 115 159 547 115 160 551 minecraft:gold_block
fill 116 159 511 117 160 521 minecraft:black_concrete
fill 116 159 523 117 159 525 minecraft:black_concrete
fill 116 159 529 117 159 533 minecraft:black_concrete
fill 116 159 535 117 160 545 minecraft:black_concrete
fill 116 159 547 117 160 551 minecraft:black_concrete
fill 117 159 526 117 159 528 minecraft:black_concrete
fill 118 159 511 118 160 521 minecraft:gold_block
fill 118 159 523 118 160 533 minecraft:gold_block
fill 118 159 535 118 160 545 minecraft:gold_block
fill 118 159 547 118 160 551 minecraft:gold_block
fill 119 159 511 120 160 521 minecraft:black_concrete
fill 119 159 523 119 160 533 minecraft:black_concrete
fill 119 159 535 120 160 545 minecraft:black_concrete
fill 119 159 547 120 160 551 minecraft:black_concrete
fill 120 159 523 120 160 529 minecraft:black_concrete
fill 120 159 533 120 160 533 minecraft:black_concrete
fill 121 159 511 121 160 521 minecraft:gold_block
fill 121 159 523 121 160 528 minecraft:gold_block
fill 121 159 535 121 160 545 minecraft:gold_block
fill 121 159 547 121 160 551 minecraft:gold_block
fill 122 159 511 123 160 521 minecraft:black_concrete
fill 122 159 523 123 160 527 minecraft:black_concrete
fill 122 159 535 123 160 545 minecraft:black_concrete
fill 122 159 547 123 160 551 minecraft:black_concrete
fill 124 159 511 124 160 521 minecraft:gold_block
fill 124 159 523 124 160 527 minecraft:gold_block
fill 124 159 535 124 160 545 minecraft:gold_block
fill 124 159 547 124 160 551 minecraft:gold_block
fill 125 159 511 126 160 521 minecraft:black_concrete
fill 125 159 523 126 160 528 minecraft:black_concrete
fill 125 159 534 135 160 534 minecraft:gilded_blackstone
fill 125 159 535 126 160 545 minecraft:black_concrete
fill 125 159 547 126 160 551 minecraft:black_concrete
fill 126 159 529 126 160 529 minecraft:black_concrete
fill 126 159 533 126 160 533 minecraft:black_concrete
fill 127 159 511 127 160 521 minecraft:gold_block
fill 127 159 523 127 160 533 minecraft:gold_block
fill 127 159 535 127 160 545 minecraft:gold_block
fill 127 159 547 127 160 551 minecraft:gold_block
fill 128 159 511 129 160 521 minecraft:black_concrete
fill 128 159 523 129 160 533 minecraft:black_concrete
fill 128 159 535 129 160 545 minecraft:black_concrete
fill 128 159 547 129 160 551 minecraft:black_concrete
fill 130 159 511 130 160 521 minecraft:gold_block
fill 130 159 523 130 160 533 minecraft:gold_block
fill 130 159 535 130 160 545 minecraft:gold_block
fill 130 159 547 130 160 551 minecraft:gold_block
fill 131 159 511 132 160 521 minecraft:black_concrete
fill 131 159 523 132 160 533 minecraft:black_concrete
fill 131 159 535 132 160 545 minecraft:black_concrete
fill 131 159 547 132 160 551 minecraft:black_concrete
fill 133 159 511 133 160 521 minecraft:gold_block
fill 133 159 523 133 160 533 minecraft:gold_block
fill 133 159 535 133 160 545 minecraft:gold_block
fill 133 159 547 133 160 551 minecraft:gold_block
fill 134 159 511 135 160 521 minecraft:black_concrete
fill 134 159 523 135 160 533 minecraft:black_concrete
fill 134 159 535 135 160 545 minecraft:black_concrete
fill 134 159 547 135 160 551 minecraft:black_concrete
fill 95 160 534 105 160 534 minecraft:gilded_blackstone
fill 106 160 523 106 160 525 minecraft:gold_block
fill 106 160 526 106 160 530 minecraft:shroomlight
setblock 106 160 531 minecraft:gold_block
fill 106 160 532 106 160 536 minecraft:shroomlight
fill 106 160 537 106 160 545 minecraft:gold_block
fill 107 160 523 108 160 525 minecraft:black_concrete
fill 107 160 526 110 160 526 minecraft:shroomlight
fill 107 160 527 109 160 529 minecraft:blackstone
fill 107 160 530 109 160 530 minecraft:shroomlight
fill 107 160 531 108 160 531 minecraft:black_concrete
fill 107 160 532 109 160 532 minecraft:shroomlight
fill 107 160 533 109 160 535 minecraft:blackstone
fill 107 160 536 110 160 536 minecraft:shroomlight
fill 107 160 537 108 160 545 minecraft:black_concrete
fill 109 160 523 109 160 525 minecraft:gold_block
setblock 109 160 531 minecraft:gold_block
fill 109 160 537 109 160 545 minecraft:gold_block
fill 110 160 523 111 160 525 minecraft:black_concrete
fill 110 160 527 110 160 529 minecraft:shroomlight
fill 110 160 530 110 160 532 minecraft:ochre_froglight
fill 110 160 533 110 160 535 minecraft:shroomlight
fill 110 160 537 111 160 545 minecraft:black_concrete
fill 111 160 526 111 160 528 minecraft:black_concrete
fill 111 160 529 113 160 529 minecraft:ochre_froglight
fill 111 160 533 113 160 533 minecraft:ochre_froglight
fill 111 160 534 121 160 534 minecraft:gilded_blackstone
fill 111 160 535 111 160 536 minecraft:black_concrete
fill 112 160 523 112 160 528 minecraft:gold_block
fill 113 160 523 114 160 524 minecraft:black_concrete
fill 113 160 525 113 160 528 minecraft:shroomlight
fill 114 160 525 117 160 525 minecraft:shroomlight
fill 114 160 526 116 160 528 minecraft:blackstone
fill 114 160 529 117 160 529 minecraft:shroomlight
fill 114 160 530 114 160 532 minecraft:ochre_froglight
setblock 114 160 533 minecraft:shroomlight
fill 115 160 523 115 160 524 minecraft:gold_block
fill 115 160 530 115 160 533 minecraft:gold_block
fill 116 160 523 117 160 524 minecraft:black_concrete
fill 116 160 530 117 160 533 minecraft:black_concrete
fill 117 160 526 117 160 528 minecraft:shroomlight
fill 95 164 531 95 164 533 minecraft:blackstone
fill 95 164 546 95 164 548 minecraft:blackstone
setblock 95 164 549 minecraft:smooth_basalt
fill 95 164 550 97 164 551 minecraft:blackstone
setblock 98 164 511 minecraft:smooth_basalt
setblock 98 164 550 minecraft:blackstone
setblock 98 164 551 minecraft:smooth_basalt
fill 99 164 511 102 164 511 minecraft:blackstone
setblock 99 164 550 minecraft:smooth_basalt
fill 99 164 551 102 164 551 minecraft:blackstone
fill 100 164 550 103 164 550 minecraft:blackstone
setblock 103 164 511 minecraft:smooth_basalt
setblock 103 164 551 minecraft:smooth_basalt
fill 104 164 511 107 164 511 minecraft:blackstone
setblock 104 164 550 minecraft:smooth_basalt
fill 104 164 551 107 164 551 minecraft:blackstone
fill 105 164 550 106 164 550 minecraft:blackstone
setblock 108 164 511 minecraft:smooth_basalt
setblock 108 164 551 minecraft:smooth_basalt
fill 116 164 511 117 164 511 minecraft:blackstone
setblock 118 164 511 minecraft:smooth_basalt
setblock 118 164 551 minecraft:smooth_basalt
fill 119 164 511 121 164 512 minecraft:blackstone
fill 119 164 551 122 164 551 minecraft:blackstone
setblock 121 164 513 minecraft:smooth_basalt
fill 121 164 550 123 164 550 minecraft:blackstone
setblock 122 164 511 minecraft:blackstone
setblock 122 164 512 minecraft:smooth_basalt
fill 122 164 513 125 164 513 minecraft:blackstone
setblock 123 164 511 minecraft:smooth_basalt
fill 123 164 512 126 164 512 minecraft:blackstone
setblock 123 164 551 minecraft:smooth_basalt
fill 124 164 511 127 164 511 minecraft:blackstone
setblock 124 164 550 minecraft:smooth_basalt
fill 124 164 551 127 164 551 minecraft:blackstone
fill 125 164 550 128 164 550 minecraft:blackstone
setblock 126 164 513 minecraft:smooth_basalt
schedule function dropper:buildpart/122_6 1t
