fill 1 140 326 1 143 326 minecraft:honeycomb_block
setblock 1 140 329 minecraft:honeycomb_block
setblock 1 140 330 minecraft:yellow_terracotta
fill 1 140 331 1 143 331 minecraft:honeycomb_block
setblock 1 140 335 minecraft:yellow_terracotta
fill 1 140 336 1 141 336 minecraft:honeycomb_block
setblock 1 140 340 minecraft:yellow_terracotta
fill 1 140 341 1 143 341 minecraft:honeycomb_block
setblock 1 140 345 minecraft:yellow_terracotta
fill 1 140 346 1 143 346 minecraft:honeycomb_block
setblock 1 140 350 minecraft:yellow_terracotta
fill 1 140 351 1 143 351 minecraft:honeycomb_block
setblock 1 140 354 minecraft:honeycomb_block
setblock 1 140 355 minecraft:yellow_terracotta
fill 1 140 356 1 143 356 minecraft:honeycomb_block
setblock 1 140 360 minecraft:yellow_terracotta
fill 1 140 361 1 143 361 minecraft:honeycomb_block
setblock 2 140 324 minecraft:yellow_terracotta
fill 2 140 325 2 143 325 minecraft:honeycomb_block
setblock 2 140 329 minecraft:yellow_terracotta
setblock 2 140 339 minecraft:yellow_terracotta
fill 2 140 340 2 141 340 minecraft:honeycomb_block
setblock 2 140 343 minecraft:honeycomb_block
setblock 2 140 344 minecraft:yellow_terracotta
fill 2 140 345 2 143 345 minecraft:honeycomb_block
setblock 2 140 349 minecraft:yellow_terracotta
fill 2 140 350 2 143 350 minecraft:honeycomb_block
setblock 2 140 354 minecraft:yellow_terracotta
fill 2 140 355 2 143 355 minecraft:honeycomb_block
setblock 2 140 359 minecraft:yellow_terracotta
fill 2 140 360 2 143 360 minecraft:honeycomb_block
setblock 3 140 323 minecraft:yellow_terracotta
fill 3 140 324 3 143 324 minecraft:honeycomb_block
setblock 3 140 332 minecraft:light[level=12]
setblock 3 140 339 minecraft:light[level=12]
setblock 3 140 343 minecraft:yellow_terracotta
fill 3 140 344 3 141 344 minecraft:honeycomb_block
setblock 3 140 348 minecraft:yellow_terracotta
setblock 3 140 353 minecraft:light[level=12]
setblock 3 140 358 minecraft:yellow_terracotta
fill 3 140 359 3 141 359 minecraft:honeycomb_block
setblock 3 140 363 minecraft:yellow_terracotta
fill 4 140 323 4 143 323 minecraft:honeycomb_block
setblock 4 140 354 minecraft:yellow_terracotta
setblock 4 140 356 minecraft:yellow_terracotta
setblock 4 140 362 minecraft:yellow_terracotta
fill 4 140 363 4 143 363 minecraft:honeycomb_block
setblock 5 140 361 minecraft:yellow_terracotta
fill 5 140 362 5 143 362 minecraft:honeycomb_block
setblock 6 140 361 minecraft:honeycomb_block
setblock 7 140 324 minecraft:yellow_terracotta
setblock 8 140 323 minecraft:yellow_terracotta
setblock 8 140 363 minecraft:yellow_terracotta
fill 9 140 323 9 142 323 minecraft:honeycomb_block
setblock 9 140 362 minecraft:yellow_terracotta
fill 9 140 363 12 140 363 minecraft:honeycomb_block
setblock 10 140 325 minecraft:light[level=12]
setblock 10 140 332 minecraft:light[level=12]
setblock 10 140 339 minecraft:light[level=12]
setblock 10 140 346 minecraft:light[level=12]
setblock 10 140 353 minecraft:light[level=12]
setblock 10 140 360 minecraft:light[level=12]
fill 10 140 362 13 140 362 minecraft:honeycomb_block
setblock 13 140 323 minecraft:yellow_terracotta
setblock 13 140 363 minecraft:yellow_terracotta
fill 14 140 323 17 140 323 minecraft:honeycomb_block
setblock 14 140 362 minecraft:yellow_terracotta
fill 14 140 363 14 143 363 minecraft:honeycomb_block
setblock 15 140 362 minecraft:honeycomb_block
setblock 17 140 324 minecraft:yellow_terracotta
setblock 17 140 325 minecraft:light[level=12]
setblock 17 140 332 minecraft:light[level=12]
setblock 17 140 339 minecraft:light[level=12]
setblock 17 140 346 minecraft:light[level=12]
setblock 17 140 353 minecraft:light[level=12]
setblock 17 140 360 minecraft:light[level=12]
setblock 18 140 323 minecraft:yellow_terracotta
fill 18 140 324 18 143 324 minecraft:honeycomb_block
setblock 18 140 363 minecraft:yellow_terracotta
fill 19 140 323 19 143 323 minecraft:honeycomb_block
setblock 19 140 362 minecraft:yellow_terracotta
fill 19 140 363 19 143 363 minecraft:honeycomb_block
fill 20 140 362 20 142 362 minecraft:honeycomb_block
setblock 21 140 324 minecraft:honeycomb_block
setblock 21 140 325 minecraft:yellow_terracotta
setblock 22 140 324 minecraft:yellow_terracotta
fill 22 140 325 24 140 325 minecraft:honeycomb_block
setblock 23 140 323 minecraft:yellow_terracotta
fill 23 140 324 23 143 324 minecraft:honeycomb_block
setblock 23 140 363 minecraft:yellow_terracotta
fill 24 140 323 24 143 323 minecraft:honeycomb_block
setblock 24 140 332 minecraft:light[level=12]
setblock 24 140 339 minecraft:light[level=12]
setblock 24 140 346 minecraft:light[level=12]
setblock 24 140 353 minecraft:light[level=12]
setblock 24 140 360 minecraft:light[level=12]
setblock 24 140 362 minecraft:yellow_terracotta
fill 24 140 363 24 142 363 minecraft:honeycomb_block
setblock 25 140 362 minecraft:honeycomb_block
setblock 26 140 324 minecraft:honeycomb_block
setblock 27 140 324 minecraft:yellow_terracotta
setblock 28 140 323 minecraft:yellow_terracotta
fill 28 140 324 31 140 324 minecraft:honeycomb_block
setblock 28 140 363 minecraft:yellow_terracotta
fill 29 140 323 32 140 323 minecraft:honeycomb_block
fill 29 140 337 29 141 337 minecraft:yellow_concrete
setblock 29 140 363 minecraft:honeycomb_block
setblock 30 140 363 minecraft:honey_block
fill 31 140 322 31 178 322 minecraft:honeycomb_block
setblock 31 140 325 minecraft:light[level=12]
setblock 31 140 332 minecraft:light[level=12]
setblock 31 140 339 minecraft:light[level=12]
setblock 31 140 346 minecraft:light[level=12]
setblock 31 140 353 minecraft:light[level=12]
setblock 31 140 360 minecraft:light[level=12]
setblock 32 140 324 minecraft:yellow_terracotta
setblock 32 140 363 minecraft:honeycomb_block
setblock 33 140 323 minecraft:yellow_terracotta
fill 33 140 324 33 143 324 minecraft:honeycomb_block
setblock 33 140 363 minecraft:yellow_terracotta
fill 34 140 323 34 143 323 minecraft:honeycomb_block
fill 34 140 363 34 143 363 minecraft:honeycomb_block
setblock 35 140 325 minecraft:honeycomb_block
setblock 36 140 325 minecraft:yellow_terracotta
setblock 37 140 324 minecraft:yellow_terracotta
fill 37 140 325 37 143 325 minecraft:honeycomb_block
setblock 38 140 323 minecraft:yellow_terracotta
fill 38 140 324 38 143 324 minecraft:honeycomb_block
fill 38 140 326 38 141 326 minecraft:honeycomb_block
setblock 38 140 332 minecraft:light[level=12]
setblock 38 140 339 minecraft:light[level=12]
setblock 38 140 346 minecraft:light[level=12]
setblock 38 140 353 minecraft:light[level=12]
setblock 38 140 360 minecraft:light[level=12]
setblock 38 140 363 minecraft:yellow_terracotta
fill 39 140 323 39 143 323 minecraft:honeycomb_block
setblock 39 140 327 minecraft:yellow_terracotta
fill 39 140 328 39 143 328 minecraft:honeycomb_block
fill 39 140 330 39 141 330 minecraft:honeycomb_block
setblock 39 140 341 minecraft:honeycomb_block
setblock 39 140 342 minecraft:yellow_terracotta
fill 39 140 343 39 141 343 minecraft:honeycomb_block
fill 39 140 345 40 140 345 minecraft:honeycomb_block
setblock 39 140 362 minecraft:yellow_terracotta
fill 39 140 363 39 143 363 minecraft:honeycomb_block
setblock 40 140 326 minecraft:yellow_terracotta
fill 40 140 327 40 143 327 minecraft:honeycomb_block
setblock 40 140 331 minecraft:yellow_terracotta
fill 40 140 332 40 143 332 minecraft:honeycomb_block
setblock 40 140 336 minecraft:yellow_terracotta
fill 40 140 337 40 141 337 minecraft:honeycomb_block
setblock 40 140 341 minecraft:yellow_terracotta
fill 40 140 342 40 143 342 minecraft:honeycomb_block
setblock 40 140 346 minecraft:yellow_terracotta
fill 40 140 347 40 143 347 minecraft:honeycomb_block
fill 40 140 349 40 141 349 minecraft:honeycomb_block
setblock 40 140 361 minecraft:yellow_terracotta
fill 40 140 362 40 143 362 minecraft:honeycomb_block
setblock 41 140 325 minecraft:yellow_terracotta
fill 41 140 326 41 143 326 minecraft:honeycomb_block
setblock 41 140 330 minecraft:yellow_terracotta
fill 41 140 331 41 143 331 minecraft:honeycomb_block
setblock 41 140 335 minecraft:yellow_terracotta
fill 41 140 336 41 143 336 minecraft:honeycomb_block
setblock 41 140 340 minecraft:yellow_terracotta
fill 41 140 341 41 143 341 minecraft:honeycomb_block
setblock 41 140 345 minecraft:yellow_terracotta
fill 41 140 346 41 143 346 minecraft:honeycomb_block
setblock 41 140 350 minecraft:yellow_terracotta
fill 41 140 351 41 143 351 minecraft:honeycomb_block
setblock 41 140 355 minecraft:yellow_terracotta
fill 41 140 356 41 143 356 minecraft:honeycomb_block
setblock 41 140 360 minecraft:yellow_terracotta
fill 41 140 361 41 143 361 minecraft:honeycomb_block
setblock 42 140 343 minecraft:yellow_terracotta
setblock 0 141 326 minecraft:yellow_terracotta
fill 0 141 349 0 223 349 minecraft:honeycomb_block
setblock 1 141 324 minecraft:yellow_terracotta
fill 1 141 325 1 144 325 minecraft:honeycomb_block
setblock 1 141 329 minecraft:yellow_terracotta
fill 1 141 330 1 144 330 minecraft:honeycomb_block
setblock 1 141 334 minecraft:yellow_terracotta
setblock 1 141 335 minecraft:honeycomb_block
setblock 1 141 339 minecraft:yellow_terracotta
fill 1 141 340 1 143 340 minecraft:honeycomb_block
setblock 1 141 344 minecraft:yellow_terracotta
fill 1 141 345 1 144 345 minecraft:honeycomb_block
setblock 1 141 349 minecraft:yellow_terracotta
fill 1 141 350 1 144 350 minecraft:honeycomb_block
setblock 1 141 353 minecraft:honeycomb_block
setblock 1 141 354 minecraft:yellow_terracotta
fill 1 141 355 1 144 355 minecraft:honeycomb_block
setblock 1 141 359 minecraft:yellow_terracotta
fill 1 141 360 1 144 360 minecraft:honeycomb_block
setblock 2 141 323 minecraft:yellow_terracotta
fill 2 141 324 2 144 324 minecraft:honeycomb_block
setblock 2 141 328 minecraft:yellow_terracotta
fill 2 141 329 2 142 329 minecraft:honeycomb_block
setblock 2 141 343 minecraft:yellow_terracotta
fill 2 141 344 2 144 344 minecraft:honeycomb_block
setblock 2 141 348 minecraft:yellow_terracotta
fill 2 141 349 2 144 349 minecraft:honeycomb_block
setblock 2 141 353 minecraft:yellow_terracotta
fill 2 141 354 2 144 354 minecraft:honeycomb_block
setblock 2 141 358 minecraft:yellow_terracotta
fill 2 141 359 2 143 359 minecraft:honeycomb_block
setblock 2 141 363 minecraft:yellow_terracotta
fill 3 141 323 3 144 323 minecraft:honeycomb_block
setblock 3 141 347 minecraft:yellow_terracotta
fill 3 141 348 3 142 348 minecraft:honeycomb_block
setblock 3 141 362 minecraft:yellow_terracotta
fill 3 141 363 3 144 363 minecraft:honeycomb_block
setblock 4 141 361 minecraft:yellow_terracotta
fill 4 141 362 4 143 362 minecraft:honeycomb_block
setblock 5 141 361 minecraft:honeycomb_block
setblock 6 141 324 minecraft:yellow_terracotta
setblock 7 141 323 minecraft:yellow_terracotta
setblock 7 141 324 minecraft:honeycomb_block
setblock 7 141 363 minecraft:yellow_terracotta
fill 8 141 323 8 142 323 minecraft:honeycomb_block
setblock 8 141 362 minecraft:yellow_terracotta
fill 8 141 363 11 141 363 minecraft:honeycomb_block
setblock 9 141 362 minecraft:honeycomb_block
setblock 12 141 323 minecraft:yellow_terracotta
setblock 12 141 363 minecraft:yellow_terracotta
fill 13 141 323 16 141 323 minecraft:honeycomb_block
fill 13 141 363 13 143 363 minecraft:honeycomb_block
setblock 17 141 323 minecraft:yellow_terracotta
fill 17 141 324 17 144 324 minecraft:honeycomb_block
setblock 17 141 363 minecraft:yellow_terracotta
fill 18 141 323 18 144 323 minecraft:honeycomb_block
setblock 18 141 362 minecraft:yellow_terracotta
fill 18 141 363 18 144 363 minecraft:honeycomb_block
fill 19 141 362 19 142 362 minecraft:honeycomb_block
setblock 21 141 324 minecraft:yellow_terracotta
fill 21 141 325 23 141 325 minecraft:honeycomb_block
setblock 22 141 323 minecraft:yellow_terracotta
fill 22 141 324 22 144 324 minecraft:honeycomb_block
setblock 22 141 363 minecraft:yellow_terracotta
fill 23 141 323 23 144 323 minecraft:honeycomb_block
setblock 23 141 362 minecraft:yellow_terracotta
fill 23 141 363 23 143 363 minecraft:honeycomb_block
setblock 26 141 324 minecraft:yellow_terracotta
setblock 27 141 323 minecraft:yellow_terracotta
fill 27 141 324 30 141 324 minecraft:honeycomb_block
setblock 27 141 363 minecraft:yellow_terracotta
fill 28 141 323 31 141 323 minecraft:honeycomb_block
setblock 30 141 364 minecraft:orange_terracotta
setblock 31 141 324 minecraft:yellow_terracotta
setblock 32 141 323 minecraft:yellow_terracotta
fill 32 141 324 32 144 324 minecraft:honeycomb_block
fill 33 141 323 33 144 323 minecraft:honeycomb_block
setblock 33 141 363 minecraft:honeycomb_block
setblock 34 141 325 minecraft:honeycomb_block
setblock 35 141 325 minecraft:yellow_terracotta
setblock 36 141 324 minecraft:yellow_terracotta
fill 36 141 325 36 144 325 minecraft:honeycomb_block
setblock 37 141 323 minecraft:yellow_terracotta
fill 37 141 324 37 144 324 minecraft:honeycomb_block
fill 37 141 326 37 142 326 minecraft:honeycomb_block
setblock 37 141 363 minecraft:yellow_terracotta
fill 38 141 323 38 144 323 minecraft:honeycomb_block
setblock 38 141 327 minecraft:yellow_terracotta
setblock 38 141 362 minecraft:yellow_terracotta
fill 38 141 363 38 144 363 minecraft:honeycomb_block
setblock 39 141 326 minecraft:yellow_terracotta
fill 39 141 327 39 144 327 minecraft:honeycomb_block
setblock 39 141 342 minecraft:honeycomb_block
fill 39 141 362 39 144 362 minecraft:honeycomb_block
setblock 40 141 322 minecraft:yellow_concrete
setblock 40 141 325 minecraft:yellow_terracotta
fill 40 141 326 40 144 326 minecraft:honeycomb_block
setblock 40 141 330 minecraft:yellow_terracotta
fill 40 141 331 40 144 331 minecraft:honeycomb_block
setblock 40 141 335 minecraft:yellow_terracotta
setblock 40 141 336 minecraft:honeycomb_block
setblock 40 141 340 minecraft:yellow_terracotta
fill 40 141 341 40 142 341 minecraft:honeycomb_block
setblock 40 141 345 minecraft:yellow_terracotta
fill 40 141 346 40 144 346 minecraft:honeycomb_block
setblock 40 141 360 minecraft:yellow_terracotta
fill 40 141 361 40 144 361 minecraft:honeycomb_block
setblock 41 141 324 minecraft:yellow_terracotta
fill 41 141 325 41 144 325 minecraft:honeycomb_block
setblock 41 141 329 minecraft:yellow_terracotta
fill 41 141 330 41 144 330 minecraft:honeycomb_block
setblock 41 141 334 minecraft:yellow_terracotta
fill 41 141 335 41 143 335 minecraft:honeycomb_block
setblock 41 141 339 minecraft:yellow_terracotta
fill 41 141 340 41 144 340 minecraft:honeycomb_block
setblock 41 141 344 minecraft:yellow_terracotta
fill 41 141 345 41 144 345 minecraft:honeycomb_block
setblock 41 141 349 minecraft:yellow_terracotta
fill 41 141 350 41 144 350 minecraft:honeycomb_block
setblock 41 141 354 minecraft:yellow_terracotta
fill 41 141 355 41 144 355 minecraft:honeycomb_block
setblock 41 141 359 minecraft:yellow_terracotta
fill 41 141 360 41 144 360 minecraft:honeycomb_block
fill 42 141 343 42 282 343 minecraft:honeycomb_block
fill 0 142 326 0 189 326 minecraft:honeycomb_block
setblock 1 142 323 minecraft:yellow_terracotta
fill 1 142 324 1 145 324 minecraft:honeycomb_block
setblock 1 142 328 minecraft:yellow_terracotta
fill 1 142 329 1 145 329 minecraft:honeycomb_block
setblock 1 142 338 minecraft:yellow_terracotta
setblock 1 142 339 minecraft:honeycomb_block
setblock 1 142 343 minecraft:yellow_terracotta
fill 1 142 344 1 145 344 minecraft:honeycomb_block
setblock 1 142 348 minecraft:yellow_terracotta
fill 1 142 349 1 145 349 minecraft:honeycomb_block
setblock 1 142 353 minecraft:yellow_terracotta
fill 1 142 354 1 145 354 minecraft:honeycomb_block
setblock 1 142 358 minecraft:yellow_terracotta
fill 1 142 359 1 145 359 minecraft:honeycomb_block
setblock 1 142 363 minecraft:yellow_terracotta
fill 2 142 323 2 145 323 minecraft:honeycomb_block
setblock 2 142 327 minecraft:yellow_terracotta
fill 2 142 328 2 144 328 minecraft:honeycomb_block
setblock 2 142 342 minecraft:yellow_terracotta
fill 2 142 343 2 143 343 minecraft:honeycomb_block
setblock 2 142 347 minecraft:yellow_terracotta
fill 2 142 348 2 145 348 minecraft:honeycomb_block
setblock 2 142 352 minecraft:yellow_terracotta
fill 2 142 353 2 145 353 minecraft:honeycomb_block
setblock 2 142 357 minecraft:yellow_terracotta
fill 2 142 358 2 143 358 minecraft:honeycomb_block
setblock 2 142 362 minecraft:yellow_terracotta
fill 2 142 363 2 145 363 minecraft:honeycomb_block
setblock 3 142 346 minecraft:yellow_terracotta
setblock 3 142 347 minecraft:honeycomb_block
setblock 3 142 361 minecraft:yellow_terracotta
fill 3 142 362 3 144 362 minecraft:honeycomb_block
setblock 5 142 324 minecraft:yellow_terracotta
setblock 6 142 323 minecraft:yellow_terracotta
setblock 6 142 324 minecraft:honeycomb_block
setblock 6 142 363 minecraft:yellow_terracotta
fill 7 142 323 7 143 323 minecraft:honeycomb_block
setblock 7 142 362 minecraft:yellow_terracotta
fill 7 142 363 10 142 363 minecraft:honeycomb_block
setblock 11 142 363 minecraft:yellow_terracotta
setblock 12 142 363 minecraft:honeycomb_block
fill 13 142 323 15 142 323 minecraft:honeycomb_block
setblock 16 142 323 minecraft:yellow_terracotta
setblock 16 142 363 minecraft:yellow_terracotta
setblock 17 142 322 minecraft:orange_terracotta
fill 17 142 323 17 145 323 minecraft:honeycomb_block
setblock 17 142 362 minecraft:yellow_terracotta
fill 17 142 363 17 145 363 minecraft:honeycomb_block
setblock 18 142 362 minecraft:honeycomb_block
setblock 20 142 324 minecraft:yellow_terracotta
setblock 21 142 323 minecraft:yellow_terracotta
fill 21 142 324 21 142 325 minecraft:honeycomb_block
setblock 21 142 363 minecraft:yellow_terracotta
fill 22 142 323 22 145 323 minecraft:honeycomb_block
setblock 22 142 325 minecraft:honeycomb_block
fill 22 142 363 22 143 363 minecraft:honeycomb_block
fill 23 142 328 24 143 328 minecraft:yellow_concrete
setblock 25 142 324 minecraft:yellow_terracotta
setblock 26 142 323 minecraft:yellow_terracotta
fill 26 142 324 28 142 324 minecraft:honeycomb_block
fill 27 142 323 30 142 323 minecraft:honeycomb_block
setblock 30 142 324 minecraft:yellow_terracotta
fill 30 142 364 30 180 364 minecraft:honeycomb_block
setblock 31 142 323 minecraft:yellow_terracotta
fill 31 142 324 31 144 324 minecraft:honeycomb_block
fill 32 142 323 32 145 323 minecraft:honeycomb_block
setblock 34 142 325 minecraft:yellow_terracotta
setblock 35 142 324 minecraft:yellow_terracotta
fill 35 142 325 35 145 325 minecraft:honeycomb_block
setblock 36 142 323 minecraft:yellow_terracotta
fill 36 142 324 36 145 324 minecraft:honeycomb_block
setblock 36 142 363 minecraft:yellow_terracotta
fill 37 142 323 37 145 323 minecraft:honeycomb_block
setblock 37 142 362 minecraft:yellow_terracotta
fill 37 142 363 37 145 363 minecraft:honeycomb_block
setblock 38 142 326 minecraft:yellow_terracotta
fill 38 142 327 38 145 327 minecraft:honeycomb_block
fill 38 142 362 38 144 362 minecraft:honeycomb_block
setblock 39 142 325 minecraft:yellow_terracotta
fill 39 142 326 39 145 326 minecraft:honeycomb_block
setblock 39 142 330 minecraft:yellow_terracotta
fill 40 142 322 40 204 322 minecraft:honeycomb_block
setblock 40 142 324 minecraft:yellow_terracotta
fill 40 142 325 40 145 325 minecraft:honeycomb_block
setblock 40 142 329 minecraft:yellow_terracotta
fill 40 142 330 40 145 330 minecraft:honeycomb_block
setblock 40 142 339 minecraft:yellow_terracotta
setblock 40 142 340 minecraft:honeycomb_block
setblock 40 142 344 minecraft:yellow_terracotta
fill 40 142 345 40 144 345 minecraft:honeycomb_block
setblock 40 142 349 minecraft:yellow_terracotta
fill 40 142 360 40 143 360 minecraft:honeycomb_block
setblock 41 142 323 minecraft:yellow_terracotta
fill 41 142 324 41 145 324 minecraft:honeycomb_block
setblock 41 142 328 minecraft:yellow_terracotta
fill 41 142 329 41 145 329 minecraft:honeycomb_block
setblock 41 142 333 minecraft:yellow_terracotta
fill 41 142 334 41 144 334 minecraft:honeycomb_block
setblock 41 142 338 minecraft:yellow_terracotta
fill 41 142 339 41 143 339 minecraft:honeycomb_block
setblock 41 142 343 minecraft:yellow_terracotta
fill 41 142 344 41 145 344 minecraft:honeycomb_block
setblock 41 142 348 minecraft:yellow_terracotta
fill 41 142 349 41 145 349 minecraft:honeycomb_block
setblock 41 142 352 minecraft:honeycomb_block
setblock 41 142 353 minecraft:yellow_terracotta
fill 41 142 354 41 145 354 minecraft:honeycomb_block
setblock 41 142 358 minecraft:yellow_terracotta
fill 41 142 359 41 145 359 minecraft:honeycomb_block
setblock 41 142 363 minecraft:yellow_terracotta
setblock 42 142 356 minecraft:yellow_terracotta
fill 1 143 323 1 146 323 minecraft:honeycomb_block
setblock 1 143 327 minecraft:yellow_terracotta
fill 1 143 328 1 146 328 minecraft:honeycomb_block
setblock 1 143 342 minecraft:yellow_terracotta
fill 1 143 343 1 146 343 minecraft:honeycomb_block
setblock 1 143 347 minecraft:yellow_terracotta
fill 1 143 348 1 146 348 minecraft:honeycomb_block
setblock 1 143 352 minecraft:yellow_terracotta
fill 1 143 353 1 146 353 minecraft:honeycomb_block
setblock 1 143 357 minecraft:yellow_terracotta
fill 1 143 358 1 146 358 minecraft:honeycomb_block
setblock 1 143 362 minecraft:yellow_terracotta
fill 1 143 363 1 146 363 minecraft:honeycomb_block
setblock 2 143 326 minecraft:yellow_terracotta
fill 2 143 327 2 145 327 minecraft:honeycomb_block
setblock 2 143 346 minecraft:yellow_terracotta
fill 2 143 347 2 146 347 minecraft:honeycomb_block
setblock 2 143 351 minecraft:yellow_terracotta
fill 2 143 352 2 146 352 minecraft:honeycomb_block
setblock 2 143 356 minecraft:yellow_terracotta
setblock 2 143 357 minecraft:honeycomb_block
setblock 2 143 361 minecraft:yellow_terracotta
fill 2 143 362 2 145 362 minecraft:honeycomb_block
setblock 4 143 324 minecraft:yellow_terracotta
setblock 5 143 323 minecraft:yellow_terracotta
setblock 5 143 324 minecraft:honeycomb_block
setblock 5 143 363 minecraft:yellow_terracotta
fill 6 143 323 6 144 323 minecraft:honeycomb_block
fill 6 143 363 9 143 363 minecraft:honeycomb_block
setblock 13 143 323 minecraft:honey_block
setblock 14 143 323 minecraft:honeycomb_block
setblock 15 143 323 minecraft:yellow_terracotta
setblock 15 143 363 minecraft:yellow_terracotta
fill 16 143 323 16 146 323 minecraft:honeycomb_block
fill 16 143 363 16 144 363 minecraft:honeycomb_block
fill 17 143 322 17 146 322 minecraft:honeycomb_block
setblock 19 143 324 minecraft:yellow_terracotta
setblock 20 143 323 minecraft:yellow_terracotta
fill 20 143 324 21 145 324 minecraft:honeycomb_block
setblock 20 143 363 minecraft:yellow_terracotta
fill 21 143 323 21 146 323 minecraft:honeycomb_block
fill 21 143 363 21 144 363 minecraft:honeycomb_block
setblock 21 143 364 minecraft:yellow_concrete
setblock 24 143 324 minecraft:yellow_terracotta
setblock 25 143 323 minecraft:yellow_terracotta
fill 25 143 324 26 143 324 minecraft:honeycomb_block
fill 26 143 323 29 143 323 minecraft:honeycomb_block
setblock 29 143 363 minecraft:honey_block
setblock 30 143 322 minecraft:yellow_concrete
setblock 30 143 323 minecraft:yellow_terracotta
fill 30 143 324 30 148 324 minecraft:iron_block
fill 31 143 323 31 146 323 minecraft:honeycomb_block
setblock 34 143 324 minecraft:yellow_terracotta
fill 34 143 325 34 146 325 minecraft:honeycomb_block
setblock 35 143 323 minecraft:yellow_terracotta
fill 35 143 324 35 146 324 minecraft:honeycomb_block
setblock 35 143 363 minecraft:yellow_terracotta
fill 36 143 323 36 146 323 minecraft:honeycomb_block
fill 36 143 363 36 146 363 minecraft:honeycomb_block
setblock 37 143 326 minecraft:yellow_terracotta
setblock 37 143 362 minecraft:honeycomb_block
setblock 38 143 325 minecraft:yellow_terracotta
fill 38 143 326 38 146 326 minecraft:honeycomb_block
setblock 39 143 324 minecraft:yellow_terracotta
fill 39 143 325 39 146 325 minecraft:honeycomb_block
setblock 39 143 329 minecraft:yellow_terracotta
fill 39 143 330 39 146 330 minecraft:honeycomb_block
setblock 40 143 323 minecraft:yellow_terracotta
fill 40 143 324 40 146 324 minecraft:honeycomb_block
setblock 40 143 328 minecraft:yellow_terracotta
fill 40 143 329 40 146 329 minecraft:honeycomb_block
setblock 40 143 343 minecraft:yellow_terracotta
fill 40 143 344 40 144 344 minecraft:honeycomb_block
setblock 40 143 348 minecraft:yellow_terracotta
fill 40 143 349 40 146 349 minecraft:honeycomb_block
setblock 40 143 363 minecraft:yellow_terracotta
fill 41 143 323 41 146 323 minecraft:honeycomb_block
setblock 41 143 327 minecraft:yellow_terracotta
fill 41 143 328 41 146 328 minecraft:honeycomb_block
setblock 41 143 332 minecraft:yellow_terracotta
fill 41 143 333 41 146 333 minecraft:honeycomb_block
setblock 41 143 337 minecraft:yellow_terracotta
setblock 41 143 338 minecraft:honeycomb_block
setblock 41 143 342 minecraft:yellow_terracotta
fill 41 143 343 41 145 343 minecraft:honeycomb_block
setblock 41 143 347 minecraft:yellow_terracotta
fill 41 143 348 41 146 348 minecraft:honeycomb_block
setblock 41 143 352 minecraft:yellow_terracotta
fill 41 143 353 41 146 353 minecraft:honeycomb_block
setblock 41 143 357 minecraft:yellow_terracotta
fill 41 143 358 41 145 358 minecraft:honeycomb_block
setblock 41 143 362 minecraft:yellow_terracotta
fill 41 143 363 41 146 363 minecraft:honeycomb_block
setblock 42 143 344 minecraft:yellow_terracotta
setblock 42 143 350 minecraft:yellow_concrete
fill 42 143 356 42 158 356 minecraft:honeycomb_block
setblock 1 144 326 minecraft:yellow_terracotta
fill 1 144 327 1 147 327 minecraft:honeycomb_block
setblock 1 144 331 minecraft:yellow_terracotta
setblock 1 144 341 minecraft:yellow_terracotta
fill 1 144 342 1 145 342 minecraft:honeycomb_block
setblock 1 144 346 minecraft:yellow_terracotta
fill 1 144 347 1 147 347 minecraft:honeycomb_block
setblock 1 144 351 minecraft:yellow_terracotta
fill 1 144 352 1 147 352 minecraft:honeycomb_block
setblock 1 144 356 minecraft:yellow_terracotta
fill 1 144 357 1 147 357 minecraft:honeycomb_block
setblock 1 144 361 minecraft:yellow_terracotta
fill 1 144 362 1 147 362 minecraft:honeycomb_block
setblock 2 144 325 minecraft:yellow_terracotta
fill 2 144 326 2 145 326 minecraft:honeycomb_block
setblock 2 144 345 minecraft:yellow_terracotta
fill 2 144 346 2 146 346 minecraft:honeycomb_block
setblock 2 144 350 minecraft:yellow_terracotta
fill 2 144 351 2 147 351 minecraft:honeycomb_block
setblock 2 144 360 minecraft:yellow_terracotta
setblock 2 144 361 minecraft:honeycomb_block
setblock 3 144 324 minecraft:yellow_terracotta
setblock 3 144 325 minecraft:light[level=15]
setblock 3 144 333 minecraft:light[level=15]
setblock 3 144 341 minecraft:light[level=15]
setblock 3 144 349 minecraft:light[level=15]
setblock 3 144 357 minecraft:light[level=15]
setblock 4 144 323 minecraft:yellow_terracotta
setblock 4 144 324 minecraft:honeycomb_block
setblock 4 144 363 minecraft:yellow_terracotta
setblock 5 144 323 minecraft:honeycomb_block
fill 5 144 363 6 144 363 minecraft:honeycomb_block
setblock 7 144 323 minecraft:honey_block
setblock 10 144 363 minecraft:honey_block
setblock 11 144 325 minecraft:light[level=15]
setblock 11 144 333 minecraft:light[level=15]
setblock 11 144 341 minecraft:light[level=15]
setblock 11 144 349 minecraft:light[level=15]
setblock 11 144 357 minecraft:light[level=15]
setblock 14 144 323 minecraft:yellow_terracotta
fill 15 144 323 15 147 323 minecraft:honeycomb_block
setblock 15 144 363 minecraft:honeycomb_block
setblock 18 144 324 minecraft:yellow_terracotta
setblock 19 144 323 minecraft:yellow_terracotta
fill 19 144 324 19 147 324 minecraft:honeycomb_block
setblock 19 144 325 minecraft:light[level=15]
setblock 19 144 333 minecraft:light[level=15]
setblock 19 144 341 minecraft:light[level=15]
setblock 19 144 349 minecraft:light[level=15]
setblock 19 144 357 minecraft:light[level=15]
setblock 19 144 363 minecraft:yellow_terracotta
fill 20 144 323 20 147 323 minecraft:honeycomb_block
setblock 20 144 363 minecraft:honeycomb_block
fill 21 144 364 21 175 364 minecraft:honeycomb_block
setblock 23 144 324 minecraft:yellow_terracotta
setblock 24 144 323 minecraft:yellow_terracotta
setblock 24 144 324 minecraft:honeycomb_block
fill 25 144 323 28 144 323 minecraft:honeycomb_block
setblock 27 144 325 minecraft:light[level=15]
setblock 27 144 333 minecraft:light[level=15]
setblock 27 144 341 minecraft:light[level=15]
setblock 27 144 349 minecraft:light[level=15]
setblock 27 144 357 minecraft:light[level=15]
setblock 29 144 323 minecraft:yellow_terracotta
fill 30 144 322 30 145 323 minecraft:honeycomb_block
setblock 33 144 324 minecraft:yellow_terracotta
setblock 34 144 323 minecraft:yellow_terracotta
fill 34 144 324 34 147 324 minecraft:honeycomb_block
fill 35 144 323 35 147 323 minecraft:honeycomb_block
setblock 35 144 333 minecraft:light[level=15]
setblock 35 144 341 minecraft:light[level=15]
setblock 35 144 349 minecraft:light[level=15]
setblock 35 144 357 minecraft:light[level=15]
fill 35 144 363 35 147 363 minecraft:honeycomb_block
setblock 37 144 325 minecraft:yellow_terracotta
fill 37 144 326 37 147 326 minecraft:honeycomb_block
setblock 38 144 324 minecraft:yellow_terracotta
fill 38 144 325 38 147 325 minecraft:honeycomb_block
setblock 39 144 323 minecraft:yellow_terracotta
fill 39 144 324 39 147 324 minecraft:honeycomb_block
setblock 39 144 328 minecraft:yellow_terracotta
fill 39 144 329 39 147 329 minecraft:honeycomb_block
setblock 39 144 363 minecraft:yellow_terracotta
fill 40 144 323 40 147 323 minecraft:honeycomb_block
setblock 40 144 327 minecraft:yellow_terracotta
fill 40 144 328 40 147 328 minecraft:honeycomb_block
setblock 40 144 332 minecraft:yellow_terracotta
setblock 40 144 347 minecraft:yellow_terracotta
fill 40 144 348 40 147 348 minecraft:honeycomb_block
setblock 40 144 362 minecraft:yellow_terracotta
fill 40 144 363 40 147 363 minecraft:honeycomb_block
setblock 41 144 326 minecraft:yellow_terracotta
fill 41 144 327 41 147 327 minecraft:honeycomb_block
setblock 41 144 331 minecraft:yellow_terracotta
fill 41 144 332 41 147 332 minecraft:honeycomb_block
setblock 41 144 341 minecraft:yellow_terracotta
setblock 41 144 342 minecraft:honeycomb_block
setblock 41 144 346 minecraft:yellow_terracotta
fill 41 144 347 41 147 347 minecraft:honeycomb_block
setblock 41 144 351 minecraft:yellow_terracotta
fill 41 144 352 41 147 352 minecraft:honeycomb_block
setblock 41 144 356 minecraft:yellow_terracotta
setblock 41 144 357 minecraft:honeycomb_block
setblock 41 144 361 minecraft:yellow_terracotta
fill 41 144 362 41 147 362 minecraft:honeycomb_block
setblock 42 144 338 minecraft:orange_terracotta
fill 42 144 344 42 237 344 minecraft:honeycomb_block
setblock 42 144 348 minecraft:yellow_concrete
fill 42 144 350 42 218 350 minecraft:honeycomb_block
setblock 0 145 343 minecraft:yellow_terracotta
setblock 0 145 354 minecraft:yellow_terracotta
setblock 1 145 325 minecraft:yellow_terracotta
fill 1 145 326 1 148 326 minecraft:honeycomb_block
setblock 1 145 330 minecraft:yellow_terracotta
fill 1 145 331 1 148 331 minecraft:honeycomb_block
setblock 1 145 334 minecraft:honey_block
setblock 1 145 345 minecraft:yellow_terracotta
fill 1 145 346 1 148 346 minecraft:honeycomb_block
setblock 1 145 350 minecraft:yellow_terracotta
fill 1 145 351 1 148 351 minecraft:honeycomb_block
setblock 1 145 355 minecraft:yellow_terracotta
fill 1 145 356 1 148 356 minecraft:honeycomb_block
setblock 1 145 360 minecraft:yellow_terracotta
fill 1 145 361 1 148 361 minecraft:honeycomb_block
setblock 2 145 324 minecraft:yellow_terracotta
fill 2 145 325 2 146 325 minecraft:honeycomb_block
setblock 2 145 345 minecraft:honeycomb_block
setblock 2 145 349 minecraft:yellow_terracotta
fill 2 145 350 2 148 350 minecraft:honeycomb_block
setblock 2 145 354 minecraft:yellow_terracotta
setblock 3 145 322 minecraft:yellow_concrete
setblock 3 145 323 minecraft:yellow_terracotta
setblock 3 145 363 minecraft:yellow_terracotta
setblock 4 145 323 minecraft:honeycomb_block
fill 4 145 363 5 145 363 minecraft:honeycomb_block
setblock 14 145 364 minecraft:yellow_concrete
setblock 16 145 363 minecraft:honey_block
setblock 17 145 324 minecraft:yellow_terracotta
setblock 18 145 323 minecraft:yellow_terracotta
fill 18 145 324 18 148 324 minecraft:honeycomb_block
setblock 18 145 363 minecraft:yellow_terracotta
fill 19 145 323 19 148 323 minecraft:honeycomb_block
setblock 19 145 363 minecraft:honeycomb_block
setblock 22 145 324 minecraft:yellow_terracotta
setblock 23 145 323 minecraft:yellow_terracotta
fill 24 145 323 27 145 323 minecraft:honeycomb_block
setblock 28 145 323 minecraft:yellow_terracotta
fill 29 145 323 29 148 323 minecraft:honeycomb_block
setblock 32 145 324 minecraft:yellow_terracotta
setblock 33 145 323 minecraft:yellow_terracotta
fill 33 145 324 33 148 324 minecraft:honeycomb_block
fill 34 145 323 34 148 323 minecraft:honeycomb_block
fill 34 145 350 36 202 351 minecraft:yellow_terracotta
fill 35 145 352 35 202 352 minecraft:yellow_terracotta
setblock 36 145 325 minecraft:yellow_terracotta
fill 36 145 326 36 148 326 minecraft:honeycomb_block
setblock 37 145 324 minecraft:yellow_terracotta
fill 37 145 325 37 148 325 minecraft:honeycomb_block
setblock 38 145 323 minecraft:yellow_terracotta
fill 38 145 324 38 148 324 minecraft:honeycomb_block
setblock 38 145 363 minecraft:yellow_terracotta
fill 39 145 323 39 148 323 minecraft:honeycomb_block
setblock 39 145 327 minecraft:yellow_terracotta
fill 39 145 328 39 148 328 minecraft:honeycomb_block
setblock 39 145 362 minecraft:yellow_terracotta
fill 39 145 363 39 148 363 minecraft:honeycomb_block
setblock 40 145 326 minecraft:yellow_terracotta
fill 40 145 327 40 148 327 minecraft:honeycomb_block
setblock 40 145 331 minecraft:yellow_terracotta
fill 40 145 332 40 148 332 minecraft:honeycomb_block
setblock 40 145 346 minecraft:yellow_terracotta
setblock 40 145 347 minecraft:honeycomb_block
setblock 40 145 350 minecraft:honeycomb_block
setblock 40 145 362 minecraft:honeycomb_block
setblock 41 145 325 minecraft:yellow_terracotta
fill 41 145 326 41 148 326 minecraft:honeycomb_block
setblock 41 145 330 minecraft:yellow_terracotta
fill 41 145 331 41 148 331 minecraft:honeycomb_block
setblock 41 145 345 minecraft:yellow_terracotta
fill 41 145 346 41 148 346 minecraft:honeycomb_block
setblock 41 145 350 minecraft:yellow_terracotta
fill 41 145 351 41 148 351 minecraft:honeycomb_block
setblock 41 145 355 minecraft:yellow_terracotta
setblock 41 145 360 minecraft:yellow_terracotta
fill 41 145 361 41 148 361 minecraft:honeycomb_block
setblock 42 145 323 minecraft:orange_terracotta
setblock 42 145 333 minecraft:yellow_concrete
fill 42 145 338 42 216 338 minecraft:honeycomb_block
fill 42 145 348 42 174 348 minecraft:honeycomb_block
fill 0 146 343 0 185 343 minecraft:honeycomb_block
fill 0 146 354 0 248 354 minecraft:honeycomb_block
setblock 1 146 324 minecraft:yellow_terracotta
fill 1 146 325 1 149 325 minecraft:honeycomb_block
setblock 1 146 329 minecraft:yellow_terracotta
fill 1 146 330 1 149 330 minecraft:honeycomb_block
setblock 1 146 340 minecraft:honey_block
setblock 1 146 344 minecraft:yellow_terracotta
fill 1 146 345 1 149 345 minecraft:honeycomb_block
setblock 1 146 349 minecraft:yellow_terracotta
fill 1 146 350 1 149 350 minecraft:honeycomb_block
setblock 1 146 354 minecraft:yellow_terracotta
fill 1 146 355 1 149 355 minecraft:honeycomb_block
setblock 1 146 359 minecraft:yellow_terracotta
fill 1 146 360 1 149 360 minecraft:honeycomb_block
setblock 2 146 323 minecraft:yellow_terracotta
setblock 2 146 348 minecraft:yellow_terracotta
fill 2 146 349 2 149 349 minecraft:honeycomb_block
setblock 2 146 353 minecraft:yellow_terracotta
fill 2 146 354 2 149 354 minecraft:honeycomb_block
setblock 2 146 363 minecraft:yellow_terracotta
fill 3 146 322 3 146 323 minecraft:honeycomb_block
setblock 3 146 325 minecraft:light[level=12]
setblock 3 146 332 minecraft:light[level=12]
setblock 3 146 339 minecraft:light[level=12]
setblock 3 146 346 minecraft:light[level=12]
setblock 3 146 353 minecraft:light[level=12]
setblock 3 146 360 minecraft:light[level=12]
fill 3 146 363 4 146 363 minecraft:honeycomb_block
setblock 10 146 325 minecraft:light[level=12]
setblock 10 146 332 minecraft:light[level=12]
setblock 10 146 339 minecraft:light[level=12]
setblock 10 146 346 minecraft:light[level=12]
setblock 10 146 353 minecraft:light[level=12]
setblock 10 146 360 minecraft:light[level=12]
setblock 12 146 364 minecraft:yellow_concrete
setblock 14 146 323 minecraft:honey_block
fill 14 146 364 14 219 364 minecraft:honeycomb_block
setblock 17 146 323 minecraft:yellow_terracotta
setblock 17 146 325 minecraft:light[level=12]
setblock 17 146 332 minecraft:light[level=12]
setblock 17 146 339 minecraft:light[level=12]
setblock 17 146 346 minecraft:light[level=12]
setblock 17 146 353 minecraft:light[level=12]
setblock 17 146 360 minecraft:light[level=12]
fill 18 146 323 18 149 323 minecraft:honeycomb_block
setblock 20 146 324 minecraft:honeycomb_block
setblock 21 146 324 minecraft:yellow_terracotta
setblock 22 146 323 minecraft:yellow_terracotta
setblock 22 146 363 minecraft:honey_block
fill 23 146 323 24 146 323 minecraft:honeycomb_block
setblock 24 146 325 minecraft:light[level=12]
setblock 24 146 332 minecraft:light[level=12]
setblock 24 146 339 minecraft:light[level=12]
setblock 24 146 346 minecraft:light[level=12]
setblock 24 146 353 minecraft:light[level=12]
setblock 24 146 360 minecraft:light[level=12]
fill 28 146 363 28 147 363 minecraft:honey_block
setblock 30 146 322 minecraft:orange_terracotta
fill 30 146 323 30 147 323 minecraft:honeycomb_block
setblock 31 146 325 minecraft:light[level=12]
setblock 31 146 332 minecraft:light[level=12]
setblock 31 146 339 minecraft:light[level=12]
setblock 31 146 346 minecraft:light[level=12]
setblock 31 146 353 minecraft:light[level=12]
setblock 31 146 360 minecraft:light[level=12]
setblock 32 146 323 minecraft:yellow_terracotta
fill 32 146 324 32 149 324 minecraft:honeycomb_block
setblock 33 146 322 minecraft:yellow_concrete
fill 33 146 323 33 149 323 minecraft:honeycomb_block
fill 33 146 351 33 147 351 minecraft:brown_terracotta
fill 34 146 352 34 147 352 minecraft:brown_terracotta
setblock 35 146 325 minecraft:yellow_terracotta
fill 35 146 349 35 147 349 minecraft:brown_terracotta
setblock 36 146 324 minecraft:yellow_terracotta
fill 36 146 325 36 149 325 minecraft:honeycomb_block
fill 36 146 352 36 147 352 minecraft:brown_terracotta
setblock 37 146 323 minecraft:yellow_terracotta
fill 37 146 324 37 149 324 minecraft:honeycomb_block
fill 37 146 351 37 147 351 minecraft:brown_terracotta
setblock 37 146 363 minecraft:yellow_terracotta
fill 38 146 323 38 149 323 minecraft:honeycomb_block
setblock 38 146 327 minecraft:yellow_terracotta
fill 38 146 328 38 149 328 minecraft:honeycomb_block
setblock 38 146 332 minecraft:light[level=12]
setblock 38 146 339 minecraft:light[level=12]
setblock 38 146 346 minecraft:light[level=12]
setblock 38 146 353 minecraft:light[level=12]
setblock 38 146 360 minecraft:light[level=12]
fill 38 146 363 38 149 363 minecraft:honeycomb_block
setblock 39 146 326 minecraft:yellow_terracotta
fill 39 146 327 39 149 327 minecraft:honeycomb_block
setblock 40 146 325 minecraft:yellow_terracotta
fill 40 146 326 40 149 326 minecraft:honeycomb_block
setblock 40 146 330 minecraft:yellow_terracotta
fill 40 146 331 40 149 331 minecraft:honeycomb_block
setblock 40 146 350 minecraft:yellow_terracotta
setblock 41 146 324 minecraft:yellow_terracotta
fill 41 146 325 41 149 325 minecraft:honeycomb_block
setblock 41 146 329 minecraft:yellow_terracotta
fill 41 146 330 41 149 330 minecraft:honeycomb_block
setblock 41 146 340 minecraft:honey_block
setblock 41 146 344 minecraft:yellow_terracotta
fill 41 146 345 41 147 345 minecraft:honeycomb_block
setblock 41 146 349 minecraft:yellow_terracotta
fill 41 146 350 41 149 350 minecraft:honeycomb_block
setblock 41 146 354 minecraft:yellow_terracotta
fill 41 146 355 41 148 356 minecraft:honeycomb_block
setblock 41 146 359 minecraft:yellow_terracotta
fill 41 146 360 41 149 360 minecraft:honeycomb_block
setblock 42 146 323 minecraft:honeycomb_block
fill 42 146 333 42 243 333 minecraft:honeycomb_block
setblock 42 146 351 minecraft:orange_terracotta
fill 0 147 335 0 169 337 minecraft:honeycomb_block
setblock 0 147 338 minecraft:yellow_terracotta
setblock 0 147 344 minecraft:orange_terracotta
fill 1 147 322 1 147 323 minecraft:yellow_terracotta
fill 1 147 324 1 150 324 minecraft:honeycomb_block
setblock 1 147 328 minecraft:yellow_terracotta
fill 1 147 329 1 150 329 minecraft:honeycomb_block
fill 1 147 344 1 148 344 minecraft:honeycomb_block
setblock 1 147 348 minecraft:yellow_terracotta
fill 1 147 349 1 150 349 minecraft:honeycomb_block
setblock 1 147 353 minecraft:yellow_terracotta
fill 1 147 354 1 150 354 minecraft:honeycomb_block
setblock 1 147 358 minecraft:yellow_terracotta
fill 1 147 359 1 150 359 minecraft:honeycomb_block
setblock 1 147 363 minecraft:yellow_terracotta
fill 2 147 323 2 148 323 minecraft:honeycomb_block
setblock 2 147 347 minecraft:yellow_terracotta
fill 2 147 348 2 150 348 minecraft:honeycomb_block
setblock 2 147 352 minecraft:yellow_terracotta
fill 2 147 353 2 150 353 minecraft:honeycomb_block
fill 2 147 363 3 147 363 minecraft:honeycomb_block
fill 3 147 322 3 160 322 minecraft:honeycomb_block
setblock 8 147 323 minecraft:honey_block
setblock 9 147 363 minecraft:honey_block
fill 12 147 364 12 221 364 minecraft:honeycomb_block
setblock 16 147 323 minecraft:yellow_terracotta
setblock 17 147 322 minecraft:yellow_concrete
fill 17 147 323 17 150 323 minecraft:honeycomb_block
setblock 21 147 323 minecraft:yellow_terracotta
fill 22 147 323 23 147 323 minecraft:honeycomb_block
setblock 29 147 364 minecraft:orange_terracotta
fill 30 147 322 30 161 322 minecraft:honeycomb_block
setblock 31 147 323 minecraft:yellow_terracotta
fill 31 147 324 31 150 324 minecraft:honeycomb_block
fill 32 147 323 32 150 323 minecraft:honeycomb_block
fill 33 147 322 33 308 322 minecraft:honeycomb_block
setblock 33 147 325 minecraft:honeycomb_block
setblock 33 147 350 minecraft:brown_terracotta
setblock 33 147 352 minecraft:brown_terracotta
setblock 34 147 325 minecraft:yellow_terracotta
setblock 34 147 349 minecraft:brown_terracotta
fill 34 147 353 36 147 353 minecraft:brown_terracotta
setblock 34 147 363 minecraft:honey_block
setblock 35 147 324 minecraft:yellow_terracotta
fill 35 147 325 35 150 325 minecraft:honeycomb_block
setblock 36 147 323 minecraft:yellow_terracotta
fill 36 147 324 36 150 324 minecraft:honeycomb_block
setblock 36 147 349 minecraft:brown_terracotta
setblock 36 147 363 minecraft:yellow_terracotta
fill 37 147 323 37 150 323 minecraft:honeycomb_block
setblock 37 147 350 minecraft:brown_terracotta
setblock 37 147 352 minecraft:brown_terracotta
fill 37 147 363 37 150 363 minecraft:honeycomb_block
setblock 38 147 326 minecraft:yellow_terracotta
fill 38 147 327 38 150 327 minecraft:honeycomb_block
setblock 39 147 325 minecraft:yellow_terracotta
fill 39 147 326 39 150 326 minecraft:honeycomb_block
setblock 39 147 330 minecraft:yellow_terracotta
setblock 40 147 324 minecraft:yellow_terracotta
fill 40 147 325 40 150 325 minecraft:honeycomb_block
setblock 40 147 329 minecraft:yellow_terracotta
fill 40 147 330 40 150 330 minecraft:honeycomb_block
setblock 40 147 349 minecraft:yellow_terracotta
fill 40 147 350 40 148 352 minecraft:honeycomb_block
fill 41 147 323 42 147 323 minecraft:yellow_terracotta
fill 41 147 324 41 150 324 minecraft:honeycomb_block
setblock 41 147 328 minecraft:yellow_terracotta
fill 41 147 329 41 150 329 minecraft:honeycomb_block
setblock 41 147 333 minecraft:yellow_terracotta
setblock 41 147 334 minecraft:honey_block
setblock 41 147 348 minecraft:yellow_terracotta
fill 41 147 349 41 150 349 minecraft:honeycomb_block
setblock 41 147 353 minecraft:yellow_terracotta
fill 41 147 354 41 150 354 minecraft:honeycomb_block
setblock 41 147 357 minecraft:honeycomb_block
setblock 41 147 358 minecraft:yellow_terracotta
fill 41 147 359 41 150 359 minecraft:honeycomb_block
setblock 41 147 363 minecraft:yellow_terracotta
fill 42 147 351 42 167 351 minecraft:honeycomb_block
fill 0 148 338 0 239 338 minecraft:honeycomb_block
fill 0 148 344 0 166 344 minecraft:honeycomb_block
fill 1 148 322 1 149 323 minecraft:honeycomb_block
setblock 1 148 327 minecraft:yellow_terracotta
fill 1 148 328 1 151 328 minecraft:honeycomb_block
setblock 1 148 333 minecraft:honey_block
setblock 1 148 347 minecraft:yellow_terracotta
fill 1 148 348 1 151 348 minecraft:honeycomb_block
setblock 1 148 352 minecraft:yellow_terracotta
fill 1 148 353 1 151 353 minecraft:honeycomb_block
setblock 1 148 357 minecraft:yellow_terracotta
fill 1 148 358 1 151 358 minecraft:honeycomb_block
setblock 1 148 362 minecraft:yellow_terracotta
fill 1 148 363 2 148 363 minecraft:honeycomb_block
fill 2 148 347 2 150 347 minecraft:honeycomb_block
setblock 2 148 351 minecraft:yellow_terracotta
fill 2 148 352 2 151 352 minecraft:honeycomb_block
setblock 2 148 355 minecraft:honeycomb_block
setblock 10 148 364 minecraft:yellow_concrete
setblock 15 148 323 minecraft:yellow_terracotta
setblock 15 148 363 minecraft:honey_block
fill 16 148 323 16 151 323 minecraft:honeycomb_block
fill 17 148 322 17 308 322 minecraft:honeycomb_block
setblock 20 148 323 minecraft:yellow_terracotta
fill 21 148 323 22 148 323 minecraft:honeycomb_block
setblock 27 148 323 minecraft:honey_block
fill 29 148 364 29 153 364 minecraft:honeycomb_block
setblock 30 148 323 minecraft:yellow_terracotta
fill 31 148 323 31 151 323 minecraft:honeycomb_block
setblock 33 148 325 minecraft:yellow_terracotta
setblock 34 148 324 minecraft:yellow_terracotta
fill 34 148 325 34 151 325 minecraft:honeycomb_block
setblock 34 148 363 minecraft:honeycomb_block
setblock 35 148 323 minecraft:yellow_terracotta
fill 35 148 324 35 151 324 minecraft:honeycomb_block
fill 35 148 326 35 149 326 minecraft:honeycomb_block
setblock 35 148 363 minecraft:yellow_terracotta
fill 36 148 323 36 151 323 minecraft:honeycomb_block
fill 36 148 363 36 151 363 minecraft:honeycomb_block
setblock 37 148 326 minecraft:yellow_terracotta
setblock 38 148 325 minecraft:yellow_terracotta
fill 38 148 326 38 149 326 minecraft:honeycomb_block
setblock 39 148 324 minecraft:yellow_terracotta
fill 39 148 325 39 151 325 minecraft:honeycomb_block
setblock 39 148 329 minecraft:yellow_terracotta
fill 39 148 330 39 150 331 minecraft:honeycomb_block
setblock 40 148 323 minecraft:yellow_terracotta
fill 40 148 324 40 151 324 minecraft:honeycomb_block
setblock 40 148 328 minecraft:yellow_terracotta
fill 40 148 329 40 151 329 minecraft:honeycomb_block
fill 40 148 349 40 151 349 minecraft:honeycomb_block
setblock 40 148 353 minecraft:yellow_terracotta
setblock 40 148 363 minecraft:yellow_terracotta
fill 41 148 323 42 151 323 minecraft:honeycomb_block
setblock 41 148 327 minecraft:yellow_terracotta
fill 41 148 328 41 151 328 minecraft:honeycomb_block
setblock 41 148 332 minecraft:yellow_terracotta
fill 41 148 333 41 151 333 minecraft:honeycomb_block
setblock 41 148 347 minecraft:yellow_terracotta
fill 41 148 348 41 151 348 minecraft:honeycomb_block
setblock 41 148 352 minecraft:yellow_terracotta
fill 41 148 353 41 151 353 minecraft:honeycomb_block
setblock 41 148 357 minecraft:yellow_terracotta
fill 41 148 358 41 151 358 minecraft:honeycomb_block
setblock 41 148 362 minecraft:yellow_terracotta
fill 41 148 363 41 151 363 minecraft:honeycomb_block
setblock 0 149 361 minecraft:yellow_concrete
setblock 1 149 326 minecraft:yellow_terracotta
fill 1 149 327 1 152 327 minecraft:honeycomb_block
setblock 1 149 331 minecraft:yellow_terracotta
fill 1 149 332 1 152 332 minecraft:honeycomb_block
setblock 1 149 339 minecraft:honey_block
setblock 1 149 346 minecraft:yellow_terracotta
fill 1 149 347 1 152 347 minecraft:honeycomb_block
setblock 1 149 351 minecraft:yellow_terracotta
fill 1 149 352 1 152 352 minecraft:honeycomb_block
setblock 1 149 356 minecraft:yellow_terracotta
fill 1 149 357 1 152 357 minecraft:honeycomb_block
setblock 1 149 361 minecraft:yellow_terracotta
fill 1 149 362 1 151 363 minecraft:honeycomb_block
setblock 2 149 350 minecraft:yellow_terracotta
fill 2 149 351 2 152 351 minecraft:honeycomb_block
setblock 2 149 355 minecraft:yellow_terracotta
fill 2 149 356 2 152 356 minecraft:honeycomb_block
setblock 2 149 363 minecraft:honey_block
setblock 8 149 364 minecraft:orange_terracotta
fill 10 149 364 10 152 364 minecraft:honeycomb_block
setblock 14 149 323 minecraft:yellow_terracotta
fill 15 149 323 15 152 323 minecraft:honeycomb_block
setblock 17 149 324 minecraft:honeycomb_block
setblock 19 149 323 minecraft:yellow_terracotta
fill 19 149 358 22 196 360 minecraft:yellow_terracotta
fill 20 149 323 21 150 323 minecraft:honeycomb_block
fill 20 149 361 22 166 361 minecraft:yellow_terracotta
fill 21 149 357 21 202 357 minecraft:yellow_terracotta
setblock 21 149 363 minecraft:honey_block
setblock 29 149 323 minecraft:yellow_terracotta
fill 30 149 323 30 151 324 minecraft:honeycomb_block
setblock 32 149 325 minecraft:yellow_terracotta
setblock 33 149 324 minecraft:yellow_terracotta
fill 33 149 325 33 152 325 minecraft:honeycomb_block
setblock 33 149 363 minecraft:honeycomb_block
setblock 34 149 323 minecraft:yellow_terracotta
fill 34 149 324 34 152 324 minecraft:honeycomb_block
fill 34 149 326 34 150 326 minecraft:honeycomb_block
setblock 34 149 363 minecraft:yellow_terracotta
fill 35 149 323 35 152 323 minecraft:honeycomb_block
fill 35 149 363 35 152 363 minecraft:honeycomb_block
setblock 36 149 326 minecraft:yellow_terracotta
setblock 37 149 325 minecraft:yellow_terracotta
fill 37 149 326 37 151 326 minecraft:honeycomb_block
setblock 38 149 324 minecraft:yellow_terracotta
fill 38 149 325 38 152 325 minecraft:honeycomb_block
setblock 38 149 329 minecraft:yellow_terracotta
fill 38 149 362 38 150 362 minecraft:honeycomb_block
setblock 39 149 323 minecraft:yellow_terracotta
fill 39 149 324 39 152 324 minecraft:honeycomb_block
setblock 39 149 328 minecraft:yellow_terracotta
fill 39 149 329 39 152 329 minecraft:honeycomb_block
setblock 39 149 363 minecraft:yellow_terracotta
fill 40 149 323 40 152 323 minecraft:honeycomb_block
setblock 40 149 327 minecraft:yellow_terracotta
fill 40 149 328 40 152 328 minecraft:honeycomb_block
setblock 40 149 332 minecraft:yellow_terracotta
fill 40 149 333 40 152 333 minecraft:honeycomb_block
fill 40 149 350 40 149 351 minecraft:honeycomb_block
setblock 40 149 352 minecraft:yellow_terracotta
fill 40 149 353 40 149 356 minecraft:honeycomb_block
fill 40 149 363 40 152 363 minecraft:honeycomb_block
setblock 41 149 326 minecraft:yellow_terracotta
fill 41 149 327 41 152 327 minecraft:honeycomb_block
setblock 41 149 331 minecraft:yellow_terracotta
fill 41 149 332 41 152 332 minecraft:honeycomb_block
fill 41 149 334 41 150 334 minecraft:honeycomb_block
setblock 41 149 346 minecraft:yellow_terracotta
fill 41 149 347 41 152 347 minecraft:honeycomb_block
setblock 41 149 351 minecraft:yellow_terracotta
fill 41 149 352 41 152 352 minecraft:honeycomb_block
setblock 41 149 355 minecraft:honeycomb_block
setblock 41 149 356 minecraft:yellow_terracotta
fill 41 149 357 41 152 357 minecraft:honeycomb_block
setblock 41 149 361 minecraft:yellow_terracotta
fill 41 149 362 41 152 362 minecraft:honeycomb_block
setblock 0 150 360 minecraft:orange_terracotta
fill 0 150 361 1 153 361 minecraft:honeycomb_block
fill 1 150 322 1 159 322 minecraft:honeycomb_block
setblock 1 150 325 minecraft:yellow_terracotta
fill 1 150 326 1 151 326 minecraft:honeycomb_block
setblock 1 150 330 minecraft:yellow_terracotta
fill 1 150 331 1 153 331 minecraft:honeycomb_block
setblock 1 150 345 minecraft:yellow_terracotta
fill 1 150 346 1 153 346 minecraft:honeycomb_block
setblock 1 150 350 minecraft:yellow_terracotta
fill 1 150 351 1 153 351 minecraft:honeycomb_block
setblock 1 150 355 minecraft:yellow_terracotta
fill 1 150 356 1 153 356 minecraft:honeycomb_block
setblock 1 150 360 minecraft:yellow_terracotta
setblock 2 150 349 minecraft:yellow_terracotta
fill 2 150 350 2 153 350 minecraft:honeycomb_block
setblock 2 150 354 minecraft:yellow_terracotta
fill 2 150 355 2 153 355 minecraft:honeycomb_block
fill 2 150 357 2 151 357 minecraft:honeycomb_block
setblock 5 150 322 minecraft:orange_terracotta
setblock 8 150 363 minecraft:honey_block
fill 8 150 364 8 280 364 minecraft:honeycomb_block
fill 14 150 323 14 153 323 minecraft:honeycomb_block
setblock 17 150 324 minecraft:yellow_terracotta
setblock 18 150 323 minecraft:yellow_terracotta
fill 18 150 358 18 151 361 minecraft:brown_terracotta
fill 19 150 323 19 153 323 minecraft:honeycomb_block
fill 19 150 357 20 151 357 minecraft:brown_terracotta
fill 19 150 361 19 151 362 minecraft:brown_terracotta
fill 20 150 362 22 151 362 minecraft:brown_terracotta
setblock 20 150 364 minecraft:orange_terracotta
fill 22 150 357 23 151 357 minecraft:brown_terracotta
fill 23 150 358 23 151 361 minecraft:brown_terracotta
setblock 27 150 363 minecraft:honey_block
setblock 28 150 323 minecraft:yellow_terracotta
fill 29 150 323 29 153 323 minecraft:honeycomb_block
setblock 31 150 325 minecraft:yellow_terracotta
setblock 32 150 324 minecraft:yellow_terracotta
fill 32 150 325 32 153 325 minecraft:honeycomb_block
setblock 32 150 363 minecraft:honeycomb_block
setblock 33 150 323 minecraft:yellow_terracotta
fill 33 150 324 33 153 324 minecraft:honeycomb_block
setblock 33 150 363 minecraft:yellow_terracotta
fill 34 150 323 34 153 323 minecraft:honeycomb_block
fill 34 150 363 34 153 363 minecraft:honeycomb_block
setblock 35 150 326 minecraft:yellow_terracotta
setblock 36 150 325 minecraft:yellow_terracotta
fill 36 150 326 36 152 326 minecraft:honeycomb_block
fill 36 150 327 36 154 327 minecraft:brown_terracotta
fill 36 150 362 37 151 362 minecraft:honeycomb_block
setblock 37 150 324 minecraft:yellow_terracotta
fill 37 150 325 37 153 325 minecraft:honeycomb_block
setblock 38 150 323 minecraft:yellow_terracotta
fill 38 150 324 38 153 324 minecraft:honeycomb_block
setblock 38 150 328 minecraft:yellow_terracotta
fill 38 150 329 38 151 329 minecraft:honeycomb_block
setblock 38 150 363 minecraft:yellow_terracotta
fill 39 150 323 39 153 323 minecraft:honeycomb_block
setblock 39 150 327 minecraft:yellow_terracotta
fill 39 150 328 39 153 328 minecraft:honeycomb_block
setblock 39 150 332 minecraft:yellow_terracotta
setblock 39 150 362 minecraft:yellow_terracotta
fill 39 150 363 39 153 363 minecraft:honeycomb_block
setblock 40 150 326 minecraft:yellow_terracotta
fill 40 150 327 40 153 327 minecraft:honeycomb_block
setblock 40 150 331 minecraft:yellow_terracotta
fill 40 150 332 40 153 332 minecraft:honeycomb_block
setblock 40 150 350 minecraft:honeycomb_block
setblock 40 150 351 minecraft:yellow_terracotta
fill 40 150 352 40 150 355 minecraft:honeycomb_block
setblock 40 150 356 minecraft:yellow_terracotta
fill 40 150 357 40 152 358 minecraft:honeycomb_block
setblock 41 150 325 minecraft:yellow_terracotta
fill 41 150 326 41 153 326 minecraft:honeycomb_block
setblock 41 150 330 minecraft:yellow_terracotta
fill 41 150 331 41 153 331 minecraft:honeycomb_block
setblock 41 150 341 minecraft:honey_block
setblock 41 150 350 minecraft:yellow_terracotta
fill 41 150 351 41 153 351 minecraft:honeycomb_block
setblock 41 150 355 minecraft:yellow_terracotta
fill 41 150 356 41 153 356 minecraft:honeycomb_block
setblock 41 150 360 minecraft:yellow_terracotta
fill 41 150 361 41 153 361 minecraft:honeycomb_block
setblock 0 151 323 minecraft:yellow_terracotta
fill 0 151 360 1 154 360 minecraft:honeycomb_block
setblock 1 151 325 minecraft:honeycomb_block
setblock 1 151 329 minecraft:yellow_terracotta
fill 1 151 330 1 154 330 minecraft:honeycomb_block
setblock 1 151 333 minecraft:honeycomb_block
fill 1 151 345 1 152 345 minecraft:honeycomb_block
setblock 1 151 349 minecraft:yellow_terracotta
fill 1 151 350 1 154 350 minecraft:honeycomb_block
setblock 1 151 354 minecraft:yellow_terracotta
fill 1 151 355 1 154 355 minecraft:honeycomb_block
setblock 1 151 359 minecraft:yellow_terracotta
setblock 2 151 348 minecraft:yellow_terracotta
fill 2 151 349 2 154 349 minecraft:honeycomb_block
setblock 2 151 353 minecraft:yellow_terracotta
fill 2 151 354 2 154 354 minecraft:honeycomb_block
setblock 2 151 358 minecraft:yellow_terracotta
setblock 3 151 351 minecraft:honeycomb_block
setblock 3 151 352 minecraft:yellow_terracotta
fill 3 151 353 3 154 353 minecraft:honeycomb_block
fill 5 151 322 5 308 322 minecraft:honeycomb_block
setblock 9 151 323 minecraft:honey_block
fill 13 151 323 13 154 323 minecraft:honeycomb_block
setblock 14 151 363 minecraft:honey_block
setblock 16 151 324 minecraft:yellow_terracotta
setblock 17 151 323 minecraft:yellow_terracotta
setblock 17 151 324 minecraft:honeycomb_block
fill 17 151 358 17 151 361 minecraft:brown_terracotta
fill 18 151 323 18 154 323 minecraft:honeycomb_block
setblock 18 151 357 minecraft:brown_terracotta
setblock 18 151 362 minecraft:brown_terracotta
fill 19 151 356 23 151 356 minecraft:brown_terracotta
fill 19 151 363 22 151 363 minecraft:brown_terracotta
fill 20 151 323 20 152 323 minecraft:honeycomb_block
fill 20 151 364 20 308 364 minecraft:honeycomb_block
setblock 23 151 362 minecraft:brown_terracotta
fill 24 151 357 24 151 361 minecraft:brown_terracotta
setblock 27 151 322 minecraft:yellow_concrete
setblock 27 151 323 minecraft:yellow_terracotta
fill 28 151 323 28 154 323 minecraft:honeycomb_block
fill 29 151 324 29 152 324 minecraft:honeycomb_block
setblock 31 151 324 minecraft:yellow_terracotta
fill 31 151 325 31 154 325 minecraft:honeycomb_block
setblock 31 151 363 minecraft:honeycomb_block
setblock 32 151 323 minecraft:yellow_terracotta
fill 32 151 324 32 154 324 minecraft:honeycomb_block
setblock 32 151 363 minecraft:yellow_terracotta
fill 33 151 323 33 154 323 minecraft:honeycomb_block
setblock 33 151 326 minecraft:honeycomb_block
fill 33 151 363 33 154 363 minecraft:honeycomb_block
setblock 34 151 326 minecraft:yellow_terracotta
fill 34 151 362 35 153 362 minecraft:honeycomb_block
setblock 35 151 325 minecraft:yellow_terracotta
fill 35 151 326 35 153 326 minecraft:honeycomb_block
setblock 36 151 324 minecraft:yellow_terracotta
fill 36 151 325 36 154 325 minecraft:honeycomb_block
setblock 37 151 323 minecraft:yellow_terracotta
fill 37 151 324 37 154 324 minecraft:honeycomb_block
setblock 37 151 363 minecraft:yellow_terracotta
fill 38 151 323 38 154 323 minecraft:honeycomb_block
setblock 38 151 328 minecraft:honeycomb_block
setblock 38 151 362 minecraft:yellow_terracotta
fill 38 151 363 38 154 363 minecraft:honeycomb_block
setblock 39 151 326 minecraft:yellow_terracotta
fill 39 151 327 39 152 327 minecraft:honeycomb_block
setblock 39 151 330 minecraft:honeycomb_block
setblock 39 151 331 minecraft:yellow_terracotta
fill 39 151 332 39 153 332 minecraft:honeycomb_block
fill 39 151 352 39 151 355 minecraft:honeycomb_block
fill 39 151 362 39 154 362 minecraft:honeycomb_block
setblock 40 151 325 minecraft:yellow_terracotta
fill 40 151 326 40 153 326 minecraft:honeycomb_block
setblock 40 151 330 minecraft:yellow_terracotta
fill 40 151 331 40 154 331 minecraft:honeycomb_block
setblock 40 151 350 minecraft:yellow_terracotta
fill 40 151 351 40 151 354 minecraft:honeycomb_block
setblock 40 151 355 minecraft:yellow_terracotta
fill 40 151 356 40 154 356 minecraft:honeycomb_block
setblock 40 151 359 minecraft:honeycomb_block
setblock 40 151 360 minecraft:yellow_terracotta
setblock 41 151 324 minecraft:yellow_terracotta
fill 41 151 325 41 154 325 minecraft:honeycomb_block
setblock 41 151 329 minecraft:yellow_terracotta
fill 41 151 330 41 154 330 minecraft:honeycomb_block
setblock 41 151 334 minecraft:yellow_terracotta
fill 41 151 335 41 154 335 minecraft:honeycomb_block
setblock 41 151 349 minecraft:yellow_terracotta
fill 41 151 350 41 154 350 minecraft:honeycomb_block
setblock 41 151 354 minecraft:yellow_terracotta
fill 41 151 355 41 154 355 minecraft:honeycomb_block
setblock 41 151 359 minecraft:yellow_terracotta
fill 41 151 360 41 154 360 minecraft:honeycomb_block
fill 0 152 323 0 208 323 minecraft:honeycomb_block
setblock 1 152 328 minecraft:yellow_terracotta
fill 1 152 329 1 153 329 minecraft:honeycomb_block
setblock 1 152 333 minecraft:yellow_terracotta
fill 1 152 334 1 155 334 minecraft:honeycomb_block
setblock 1 152 338 minecraft:honey_block
setblock 1 152 348 minecraft:yellow_terracotta
fill 1 152 349 1 155 349 minecraft:honeycomb_block
setblock 1 152 353 minecraft:yellow_terracotta
fill 1 152 354 1 155 354 minecraft:honeycomb_block
setblock 1 152 358 minecraft:yellow_terracotta
fill 1 152 359 1 155 359 minecraft:honeycomb_block
setblock 1 152 362 minecraft:honeycomb_block
setblock 1 152 363 minecraft:yellow_terracotta
fill 2 152 348 2 153 348 minecraft:honeycomb_block
setblock 2 152 352 minecraft:yellow_terracotta
fill 2 152 353 2 155 353 minecraft:honeycomb_block
setblock 2 152 357 minecraft:yellow_terracotta
fill 2 152 358 2 155 358 minecraft:honeycomb_block
setblock 3 152 323 minecraft:honey_block
setblock 3 152 325 minecraft:light[level=15]
setblock 3 152 332 minecraft:light[level=12]
setblock 3 152 333 minecraft:light[level=15]
setblock 3 152 339 minecraft:light[level=12]
setblock 3 152 341 minecraft:light[level=15]
setblock 3 152 346 minecraft:light[level=12]
setblock 3 152 349 minecraft:light[level=15]
setblock 3 152 351 minecraft:yellow_terracotta
fill 3 152 352 3 154 352 minecraft:honeycomb_block
fill 3 152 354 3 153 354 minecraft:honeycomb_block
setblock 3 152 357 minecraft:light[level=15]
setblock 3 152 360 minecraft:light[level=12]
setblock 10 152 325 minecraft:light[level=12]
setblock 10 152 332 minecraft:light[level=12]
setblock 10 152 339 minecraft:light[level=12]
setblock 10 152 346 minecraft:light[level=12]
setblock 10 152 353 minecraft:light[level=12]
setblock 10 152 360 minecraft:light[level=12]
setblock 11 152 325 minecraft:light[level=15]
setblock 11 152 333 minecraft:light[level=15]
setblock 11 152 341 minecraft:light[level=15]
setblock 11 152 349 minecraft:light[level=15]
setblock 11 152 357 minecraft:light[level=15]
fill 12 152 323 12 155 323 minecraft:honeycomb_block
fill 13 152 363 15 152 363 minecraft:honeycomb_block
setblock 16 152 323 minecraft:yellow_terracotta
setblock 16 152 324 minecraft:honeycomb_block
fill 17 152 323 17 154 323 minecraft:honeycomb_block
setblock 17 152 325 minecraft:light[level=12]
setblock 17 152 332 minecraft:light[level=12]
setblock 17 152 339 minecraft:light[level=12]
setblock 17 152 346 minecraft:light[level=12]
setblock 17 152 353 minecraft:light[level=12]
setblock 17 152 360 minecraft:light[level=12]
setblock 19 152 325 minecraft:light[level=15]
fill 19 152 327 19 154 327 minecraft:brown_terracotta
setblock 19 152 333 minecraft:light[level=15]
setblock 19 152 341 minecraft:light[level=15]
setblock 19 152 349 minecraft:light[level=15]
setblock 19 152 357 minecraft:light[level=15]
setblock 20 152 363 minecraft:honey_block
setblock 22 152 323 minecraft:honey_block
setblock 24 152 325 minecraft:light[level=12]
setblock 24 152 332 minecraft:light[level=12]
setblock 24 152 339 minecraft:light[level=12]
setblock 24 152 346 minecraft:light[level=12]
setblock 24 152 353 minecraft:light[level=12]
setblock 24 152 360 minecraft:light[level=12]
fill 27 152 322 27 155 323 minecraft:honeycomb_block
setblock 27 152 325 minecraft:light[level=15]
setblock 27 152 333 minecraft:light[level=15]
setblock 27 152 341 minecraft:light[level=15]
setblock 27 152 349 minecraft:light[level=15]
setblock 27 152 357 minecraft:light[level=15]
setblock 30 152 323 minecraft:honeycomb_block
setblock 30 152 324 minecraft:yellow_terracotta
fill 30 152 325 30 154 325 minecraft:honeycomb_block
setblock 31 152 323 minecraft:yellow_terracotta
fill 31 152 324 31 155 324 minecraft:honeycomb_block
setblock 31 152 332 minecraft:light[level=12]
setblock 31 152 339 minecraft:light[level=12]
setblock 31 152 346 minecraft:light[level=12]
setblock 31 152 353 minecraft:light[level=12]
setblock 31 152 360 minecraft:light[level=12]
setblock 31 152 363 minecraft:yellow_terracotta
fill 32 152 323 32 155 323 minecraft:honeycomb_block
fill 32 152 363 32 155 363 minecraft:honeycomb_block
setblock 33 152 326 minecraft:yellow_terracotta
fill 33 152 362 33 155 362 minecraft:honeycomb_block
setblock 34 152 325 minecraft:yellow_terracotta
fill 34 152 326 34 153 326 minecraft:honeycomb_block
setblock 35 152 324 minecraft:yellow_terracotta
fill 35 152 325 35 155 325 minecraft:honeycomb_block
setblock 35 152 333 minecraft:light[level=15]
setblock 35 152 341 minecraft:light[level=15]
setblock 35 152 349 minecraft:light[level=15]
setblock 35 152 357 minecraft:light[level=15]
setblock 36 152 323 minecraft:yellow_terracotta
fill 36 152 324 36 155 324 minecraft:honeycomb_block
setblock 36 152 362 minecraft:honeycomb_block
setblock 36 152 363 minecraft:yellow_terracotta
setblock 37 152 322 minecraft:yellow_terracotta
fill 37 152 323 37 155 323 minecraft:honeycomb_block
setblock 37 152 362 minecraft:yellow_terracotta
fill 37 152 363 37 155 363 minecraft:honeycomb_block
setblock 38 152 332 minecraft:light[level=12]
setblock 38 152 339 minecraft:light[level=12]
setblock 38 152 346 minecraft:light[level=12]
setblock 38 152 353 minecraft:light[level=12]
setblock 38 152 360 minecraft:light[level=12]
fill 38 152 362 38 155 362 minecraft:honeycomb_block
setblock 39 152 326 minecraft:honeycomb_block
setblock 39 152 330 minecraft:yellow_terracotta
fill 39 152 331 39 153 331 minecraft:honeycomb_block
fill 39 152 352 39 152 354 minecraft:honeycomb_block
setblock 39 152 355 minecraft:yellow_terracotta
fill 39 152 356 39 154 357 minecraft:honeycomb_block
setblock 40 152 324 minecraft:yellow_terracotta
fill 40 152 325 40 153 325 minecraft:honeycomb_block
setblock 40 152 329 minecraft:yellow_terracotta
fill 40 152 330 40 154 330 minecraft:honeycomb_block
setblock 40 152 334 minecraft:yellow_terracotta
setblock 40 152 349 minecraft:yellow_terracotta
fill 40 152 350 40 152 353 minecraft:honeycomb_block
setblock 40 152 354 minecraft:yellow_terracotta
fill 40 152 355 40 155 355 minecraft:honeycomb_block
setblock 40 152 359 minecraft:yellow_terracotta
fill 40 152 360 40 153 362 minecraft:honeycomb_block
setblock 41 152 323 minecraft:yellow_terracotta
fill 41 152 324 41 154 324 minecraft:honeycomb_block
setblock 41 152 328 minecraft:yellow_terracotta
fill 41 152 329 41 155 329 minecraft:honeycomb_block
setblock 41 152 333 minecraft:yellow_terracotta
fill 41 152 334 41 155 334 minecraft:honeycomb_block
setblock 41 152 348 minecraft:yellow_terracotta
fill 41 152 349 41 155 349 minecraft:honeycomb_block
setblock 41 152 353 minecraft:yellow_terracotta
fill 41 152 354 41 155 354 minecraft:honeycomb_block
setblock 41 152 358 minecraft:yellow_terracotta
fill 41 152 359 41 155 359 minecraft:honeycomb_block
setblock 41 152 363 minecraft:yellow_terracotta
fill 42 152 323 42 200 323 minecraft:honeycomb_block
setblock 1 153 328 minecraft:honeycomb_block
setblock 1 153 332 minecraft:yellow_terracotta
fill 1 153 333 1 155 333 minecraft:honeycomb_block
fill 1 153 335 1 154 335 minecraft:honeycomb_block
setblock 1 153 344 minecraft:honey_block
setblock 1 153 347 minecraft:yellow_terracotta
fill 1 153 348 1 156 348 minecraft:honeycomb_block
setblock 1 153 352 minecraft:yellow_terracotta
fill 1 153 353 1 156 353 minecraft:honeycomb_block
setblock 1 153 357 minecraft:yellow_terracotta
fill 1 153 358 1 156 358 minecraft:honeycomb_block
setblock 1 153 362 minecraft:yellow_terracotta
setblock 1 153 363 minecraft:honeycomb_block
setblock 2 153 351 minecraft:yellow_terracotta
fill 2 153 352 2 156 352 minecraft:honeycomb_block
setblock 2 153 356 minecraft:yellow_terracotta
fill 2 153 357 2 156 357 minecraft:honeycomb_block
fill 2 153 359 2 154 359 minecraft:honeycomb_block
fill 3 153 339 3 162 339 minecraft:yellow_terracotta
setblock 3 153 351 minecraft:honeycomb_block
setblock 3 153 355 minecraft:yellow_terracotta
setblock 10 153 364 minecraft:yellow_terracotta
fill 11 153 350 11 154 350 minecraft:black_concrete
fill 12 153 363 14 153 363 minecraft:honeycomb_block
setblock 15 153 323 minecraft:yellow_terracotta
setblock 15 153 363 minecraft:yellow_terracotta
fill 16 153 323 16 155 323 minecraft:honeycomb_block
setblock 26 153 363 minecraft:honey_block
setblock 29 153 324 minecraft:yellow_terracotta
setblock 30 153 323 minecraft:yellow_terracotta
fill 30 153 324 30 156 324 minecraft:honeycomb_block
setblock 30 153 363 minecraft:yellow_terracotta
fill 31 153 323 31 156 323 minecraft:honeycomb_block
fill 31 153 363 31 156 363 minecraft:honeycomb_block
fill 32 153 362 32 156 362 minecraft:honeycomb_block
setblock 33 153 325 minecraft:yellow_terracotta
setblock 33 153 326 minecraft:honeycomb_block
setblock 34 153 324 minecraft:yellow_terracotta
fill 34 153 325 34 155 325 minecraft:honeycomb_block
setblock 35 153 323 minecraft:yellow_terracotta
fill 35 153 324 35 156 324 minecraft:honeycomb_block
fill 35 153 327 35 154 327 minecraft:brown_terracotta
fill 35 153 361 36 153 361 minecraft:honeycomb_block
setblock 35 153 363 minecraft:yellow_terracotta
fill 36 153 323 36 156 323 minecraft:honeycomb_block
fill 36 153 326 36 154 326 minecraft:brown_terracotta
fill 36 153 328 36 154 328 minecraft:brown_terracotta
setblock 36 153 362 minecraft:yellow_terracotta
fill 36 153 363 36 156 363 minecraft:honeycomb_block
fill 37 153 322 37 175 322 minecraft:honeycomb_block
fill 37 153 327 37 154 327 minecraft:brown_terracotta
fill 37 153 362 37 156 362 minecraft:honeycomb_block
setblock 39 153 324 minecraft:yellow_terracotta
setblock 39 153 329 minecraft:yellow_terracotta
setblock 39 153 330 minecraft:honeycomb_block
fill 39 153 352 39 153 353 minecraft:honeycomb_block
setblock 39 153 354 minecraft:yellow_terracotta
fill 39 153 355 39 156 355 minecraft:honeycomb_block
setblock 39 153 358 minecraft:honeycomb_block
setblock 40 153 323 minecraft:yellow_terracotta
setblock 40 153 328 minecraft:yellow_terracotta
fill 40 153 329 40 154 329 minecraft:honeycomb_block
setblock 40 153 333 minecraft:yellow_terracotta
setblock 40 153 334 minecraft:honeycomb_block
fill 40 153 350 40 153 352 minecraft:honeycomb_block
setblock 40 153 353 minecraft:yellow_terracotta
fill 40 153 354 40 156 354 minecraft:honeycomb_block
setblock 40 153 357 minecraft:honeycomb_block
setblock 40 153 358 minecraft:yellow_terracotta
fill 40 153 359 40 156 359 minecraft:honeycomb_block
setblock 40 153 363 minecraft:yellow_terracotta
setblock 41 153 323 minecraft:honeycomb_block
setblock 41 153 327 minecraft:yellow_terracotta
fill 41 153 328 41 155 328 minecraft:honeycomb_block
setblock 41 153 332 minecraft:yellow_terracotta
fill 41 153 333 41 156 333 minecraft:honeycomb_block
setblock 41 153 342 minecraft:honey_block
setblock 41 153 348 minecraft:honeycomb_block
setblock 41 153 352 minecraft:yellow_terracotta
fill 41 153 353 41 156 353 minecraft:honeycomb_block
setblock 41 153 357 minecraft:yellow_terracotta
fill 41 153 358 41 156 358 minecraft:honeycomb_block
setblock 41 153 362 minecraft:yellow_terracotta
fill 41 153 363 41 156 363 minecraft:honeycomb_block
fill 0 154 361 0 161 361 minecraft:honeycomb_block
setblock 1 154 325 minecraft:honey_block
setblock 1 154 331 minecraft:yellow_terracotta
fill 1 154 332 1 155 332 minecraft:honeycomb_block
setblock 1 154 336 minecraft:yellow_terracotta
setblock 1 154 346 minecraft:yellow_terracotta
fill 1 154 347 1 155 347 minecraft:honeycomb_block
setblock 1 154 351 minecraft:yellow_terracotta
fill 1 154 352 1 157 352 minecraft:honeycomb_block
setblock 1 154 356 minecraft:yellow_terracotta
fill 1 154 357 1 157 357 minecraft:honeycomb_block
setblock 1 154 361 minecraft:yellow_terracotta
fill 1 154 362 1 155 362 minecraft:honeycomb_block
setblock 2 154 350 minecraft:yellow_terracotta
fill 2 154 351 2 156 351 minecraft:honeycomb_block
setblock 2 154 355 minecraft:yellow_terracotta
fill 2 154 356 2 157 356 minecraft:honeycomb_block
setblock 3 154 354 minecraft:yellow_terracotta
fill 3 154 355 3 155 355 minecraft:honeycomb_block
setblock 7 154 363 minecraft:honey_block
setblock 10 154 323 minecraft:honey_block
fill 10 154 364 10 171 364 minecraft:honeycomb_block
fill 11 154 363 13 154 363 minecraft:honeycomb_block
setblock 14 154 323 minecraft:yellow_terracotta
setblock 14 154 363 minecraft:yellow_terracotta
fill 15 154 323 15 156 323 minecraft:honeycomb_block
fill 15 154 363 15 155 363 minecraft:honeycomb_block
fill 16 154 326 18 171 328 minecraft:honey_block
setblock 19 154 326 minecraft:brown_terracotta
setblock 19 154 328 minecraft:brown_terracotta
setblock 20 154 327 minecraft:brown_terracotta
fill 26 154 323 26 156 323 minecraft:honeycomb_block
setblock 28 154 324 minecraft:yellow_terracotta
setblock 29 154 323 minecraft:yellow_terracotta
fill 29 154 324 29 157 324 minecraft:honeycomb_block
setblock 29 154 363 minecraft:yellow_terracotta
setblock 29 154 364 minecraft:orange_terracotta
fill 30 154 323 30 157 323 minecraft:honeycomb_block
fill 30 154 363 30 157 363 minecraft:honeycomb_block
fill 31 154 362 31 157 362 minecraft:honeycomb_block
setblock 32 154 325 minecraft:yellow_terracotta
setblock 33 154 324 minecraft:yellow_terracotta
fill 33 154 325 33 156 325 minecraft:honeycomb_block
fill 33 154 361 35 154 361 minecraft:honeycomb_block
setblock 34 154 323 minecraft:yellow_terracotta
fill 34 154 324 34 157 324 minecraft:honeycomb_block
setblock 34 154 362 minecraft:honeycomb_block
setblock 34 154 363 minecraft:yellow_terracotta
fill 35 154 323 35 157 323 minecraft:honeycomb_block
setblock 35 154 362 minecraft:yellow_terracotta
fill 35 154 363 35 157 363 minecraft:honeycomb_block
setblock 36 154 361 minecraft:yellow_terracotta
fill 36 154 362 36 157 362 minecraft:honeycomb_block
fill 37 154 361 37 156 361 minecraft:honeycomb_block
setblock 38 154 324 minecraft:yellow_terracotta
setblock 39 154 323 minecraft:yellow_terracotta
setblock 39 154 353 minecraft:yellow_terracotta
fill 39 154 354 39 155 354 minecraft:honeycomb_block
setblock 39 154 358 minecraft:yellow_terracotta
fill 39 154 359 39 155 359 minecraft:honeycomb_block
setblock 39 154 363 minecraft:yellow_terracotta
setblock 40 154 323 minecraft:honeycomb_block
setblock 40 154 328 minecraft:honeycomb_block
setblock 40 154 332 minecraft:yellow_terracotta
setblock 40 154 333 minecraft:honeycomb_block
fill 40 154 350 40 154 351 minecraft:honeycomb_block
setblock 40 154 352 minecraft:yellow_terracotta
fill 40 154 353 40 156 353 minecraft:honeycomb_block
setblock 40 154 357 minecraft:yellow_terracotta
fill 40 154 358 40 157 358 minecraft:honeycomb_block
fill 40 154 360 40 154 361 minecraft:honeycomb_block
setblock 40 154 362 minecraft:yellow_terracotta
fill 40 154 363 40 157 363 minecraft:honeycomb_block
setblock 41 154 326 minecraft:yellow_terracotta
setblock 41 154 327 minecraft:honeycomb_block
setblock 41 154 331 minecraft:yellow_terracotta
fill 41 154 332 41 156 332 minecraft:honeycomb_block
setblock 41 154 336 minecraft:honey_block
setblock 41 154 351 minecraft:yellow_terracotta
fill 41 154 352 41 157 352 minecraft:honeycomb_block
setblock 41 154 356 minecraft:yellow_terracotta
fill 41 154 357 41 157 357 minecraft:honeycomb_block
setblock 41 154 361 minecraft:yellow_terracotta
fill 41 154 362 41 157 362 minecraft:honeycomb_block
setblock 0 155 331 minecraft:yellow_concrete
fill 0 155 360 0 195 360 minecraft:honeycomb_block
setblock 1 155 331 minecraft:honey_block
setblock 1 155 335 minecraft:yellow_terracotta
fill 1 155 336 1 156 336 minecraft:honeycomb_block
setblock 1 155 350 minecraft:yellow_terracotta
fill 1 155 351 1 158 351 minecraft:honeycomb_block
setblock 1 155 355 minecraft:yellow_terracotta
fill 1 155 356 1 158 356 minecraft:honeycomb_block
setblock 1 155 360 minecraft:yellow_terracotta
fill 1 155 361 1 158 361 minecraft:honeycomb_block
setblock 2 155 350 minecraft:honeycomb_block
setblock 2 155 354 minecraft:yellow_terracotta
fill 2 155 355 2 158 355 minecraft:honeycomb_block
setblock 2 155 359 minecraft:yellow_terracotta
setblock 3 155 354 minecraft:honeycomb_block
setblock 4 155 323 minecraft:honey_block
fill 10 155 363 12 155 363 minecraft:honeycomb_block
setblock 13 155 323 minecraft:yellow_terracotta
setblock 13 155 363 minecraft:yellow_terracotta
fill 14 155 323 14 156 323 minecraft:honeycomb_block
fill 14 155 326 15 170 328 minecraft:honey_block
fill 14 155 363 14 156 363 minecraft:honeycomb_block
fill 15 155 325 19 168 325 minecraft:honey_block
fill 15 155 329 19 170 329 minecraft:honey_block
fill 16 155 324 18 166 324 minecraft:honey_block
fill 16 155 330 18 170 330 minecraft:honey_block
fill 19 155 326 20 170 328 minecraft:honey_block
setblock 23 155 323 minecraft:honey_block
setblock 28 155 323 minecraft:yellow_terracotta
setblock 28 155 324 minecraft:honeycomb_block
setblock 28 155 363 minecraft:yellow_terracotta
fill 29 155 323 29 158 323 minecraft:honeycomb_block
fill 29 155 363 29 158 364 minecraft:honeycomb_block
fill 30 155 362 30 158 362 minecraft:honeycomb_block
setblock 31 155 325 minecraft:yellow_terracotta
setblock 32 155 324 minecraft:yellow_terracotta
fill 32 155 325 32 156 325 minecraft:honeycomb_block
fill 32 155 361 34 155 361 minecraft:honeycomb_block
setblock 33 155 323 minecraft:yellow_terracotta
fill 33 155 324 33 158 324 minecraft:honeycomb_block
setblock 33 155 363 minecraft:yellow_terracotta
fill 34 155 323 34 158 323 minecraft:honeycomb_block
setblock 34 155 362 minecraft:yellow_terracotta
fill 34 155 363 34 158 363 minecraft:honeycomb_block
setblock 35 155 361 minecraft:yellow_terracotta
fill 35 155 362 35 158 362 minecraft:honeycomb_block
fill 36 155 361 36 157 361 minecraft:honeycomb_block
setblock 37 155 324 minecraft:yellow_terracotta
setblock 38 155 323 minecraft:yellow_terracotta
setblock 38 155 363 minecraft:yellow_terracotta
fill 38 155 364 38 164 364 minecraft:honeycomb_block
setblock 39 155 323 minecraft:honeycomb_block
setblock 39 155 356 minecraft:honeycomb_block
setblock 39 155 357 minecraft:yellow_terracotta
fill 39 155 358 39 156 358 minecraft:honeycomb_block
setblock 39 155 362 minecraft:yellow_terracotta
fill 39 155 363 39 158 363 minecraft:honeycomb_block
setblock 39 155 364 minecraft:yellow_terracotta
setblock 40 155 351 minecraft:yellow_terracotta
fill 40 155 352 40 156 352 minecraft:honeycomb_block
setblock 40 155 356 minecraft:yellow_terracotta
fill 40 155 357 40 158 357 minecraft:honeycomb_block
setblock 40 155 360 minecraft:honeycomb_block
setblock 40 155 361 minecraft:yellow_terracotta
setblock 40 155 362 minecraft:honeycomb_block
setblock 41 155 330 minecraft:yellow_terracotta
setblock 41 155 331 minecraft:honeycomb_block
setblock 41 155 335 minecraft:yellow_terracotta
setblock 41 155 350 minecraft:yellow_terracotta
fill 41 155 351 41 157 351 minecraft:honeycomb_block
setblock 41 155 355 minecraft:yellow_terracotta
fill 41 155 356 41 158 356 minecraft:honeycomb_block
setblock 41 155 360 minecraft:yellow_terracotta
fill 41 155 361 41 158 361 minecraft:honeycomb_block
fill 0 156 331 0 308 331 minecraft:honeycomb_block
setblock 1 156 334 minecraft:yellow_terracotta
setblock 1 156 335 minecraft:honeycomb_block
setblock 1 156 337 minecraft:honey_block
setblock 1 156 349 minecraft:yellow_terracotta
fill 1 156 350 1 157 350 minecraft:honeycomb_block
setblock 1 156 354 minecraft:yellow_terracotta
fill 1 156 355 1 159 355 minecraft:honeycomb_block
setblock 1 156 359 minecraft:yellow_terracotta
fill 1 156 360 1 159 360 minecraft:honeycomb_block
setblock 1 156 362 minecraft:honey_block
setblock 2 156 353 minecraft:yellow_terracotta
fill 2 156 354 2 158 354 minecraft:honeycomb_block
setblock 2 156 358 minecraft:yellow_terracotta
fill 9 156 357 10 157 358 minecraft:honey_block
fill 10 156 359 10 157 359 minecraft:honey_block
fill 10 156 363 11 156 363 minecraft:honeycomb_block
setblock 12 156 363 minecraft:yellow_terracotta
setblock 13 156 323 minecraft:honeycomb_block
fill 13 156 326 13 169 328 minecraft:honey_block
fill 13 156 363 13 158 363 minecraft:honeycomb_block
fill 14 156 324 14 166 325 minecraft:honey_block
fill 14 156 329 14 169 330 minecraft:honey_block
fill 15 156 324 15 166 324 minecraft:honey_block
fill 15 156 330 15 169 330 minecraft:honey_block
fill 16 156 323 18 163 323 minecraft:honey_block
fill 16 156 331 18 169 331 minecraft:honey_block
fill 19 156 324 20 165 324 minecraft:honey_block
fill 19 156 330 20 169 330 minecraft:honey_block
setblock 19 156 363 minecraft:honey_block
fill 20 156 325 20 167 325 minecraft:honey_block
fill 20 156 329 20 169 329 minecraft:honey_block
fill 21 156 326 21 169 328 minecraft:honey_block
fill 25 156 363 25 157 363 minecraft:honey_block
fill 27 156 322 27 218 322 minecraft:honeycomb_block
setblock 27 156 323 minecraft:yellow_terracotta
fill 28 156 323 28 159 323 minecraft:honeycomb_block
fill 28 156 363 28 159 363 minecraft:honeycomb_block
setblock 28 156 364 minecraft:orange_terracotta
setblock 31 156 324 minecraft:yellow_terracotta
setblock 32 156 323 minecraft:yellow_terracotta
fill 32 156 324 32 159 324 minecraft:honeycomb_block
fill 32 156 361 33 156 361 minecraft:honeycomb_block
setblock 32 156 363 minecraft:yellow_terracotta
fill 33 156 323 33 159 323 minecraft:honeycomb_block
setblock 33 156 362 minecraft:yellow_terracotta
fill 33 156 363 33 159 363 minecraft:honeycomb_block
setblock 34 156 361 minecraft:yellow_terracotta
fill 34 156 362 34 159 362 minecraft:honeycomb_block
setblock 35 156 322 minecraft:yellow_concrete
fill 35 156 361 35 159 361 minecraft:honeycomb_block
fill 36 156 322 36 233 322 minecraft:honeycomb_block
setblock 36 156 324 minecraft:yellow_terracotta
setblock 36 156 364 minecraft:orange_terracotta
setblock 37 156 323 minecraft:yellow_terracotta
setblock 37 156 363 minecraft:yellow_terracotta
setblock 38 156 323 minecraft:honeycomb_block
setblock 38 156 362 minecraft:yellow_terracotta
fill 38 156 363 38 159 363 minecraft:honeycomb_block
setblock 39 156 356 minecraft:yellow_terracotta
setblock 39 156 357 minecraft:honeycomb_block
fill 39 156 362 39 157 362 minecraft:honeycomb_block
fill 39 156 364 39 306 364 minecraft:honeycomb_block
setblock 40 156 355 minecraft:yellow_terracotta
fill 40 156 356 40 159 356 minecraft:honeycomb_block
setblock 40 156 360 minecraft:yellow_terracotta
fill 40 156 361 40 157 361 minecraft:honeycomb_block
setblock 41 156 324 minecraft:honey_block
setblock 41 156 334 minecraft:yellow_terracotta
setblock 41 156 343 minecraft:honey_block
setblock 41 156 349 minecraft:honey_block
setblock 41 156 350 minecraft:honeycomb_block
setblock 41 156 354 minecraft:yellow_terracotta
fill 41 156 355 41 159 355 minecraft:honeycomb_block
setblock 41 156 359 minecraft:yellow_terracotta
fill 41 156 360 41 159 360 minecraft:honeycomb_block
setblock 42 156 330 minecraft:yellow_terracotta
setblock 1 157 324 minecraft:honey_block
setblock 1 157 343 minecraft:honey_block
setblock 1 157 349 minecraft:honeycomb_block
setblock 1 157 353 minecraft:yellow_terracotta
fill 1 157 354 1 160 354 minecraft:honeycomb_block
setblock 1 157 358 minecraft:yellow_terracotta
fill 1 157 359 1 160 359 minecraft:honeycomb_block
setblock 2 157 352 minecraft:yellow_terracotta
setblock 2 157 353 minecraft:honeycomb_block
setblock 2 157 357 minecraft:yellow_terracotta
setblock 2 157 358 minecraft:honeycomb_block
setblock 6 157 363 minecraft:honey_block
setblock 10 157 363 minecraft:honeycomb_block
setblock 11 157 323 minecraft:honey_block
setblock 11 157 363 minecraft:yellow_terracotta
setblock 12 157 327 minecraft:ochre_froglight
fill 12 157 363 12 160 363 minecraft:honeycomb_block
setblock 13 157 324 minecraft:ochre_froglight
fill 13 157 325 13 168 325 minecraft:honey_block
fill 13 157 329 13 168 329 minecraft:honey_block
setblock 13 157 330 minecraft:ochre_froglight
setblock 14 157 323 minecraft:ochre_froglight
setblock 14 157 331 minecraft:ochre_froglight
fill 15 157 323 15 163 323 minecraft:honey_block
fill 15 157 331 15 168 331 minecraft:honey_block
setblock 17 157 332 minecraft:ochre_froglight
fill 19 157 323 19 163 323 minecraft:honey_block
fill 19 157 331 19 168 331 minecraft:honey_block
setblock 20 157 323 minecraft:ochre_froglight
setblock 20 157 331 minecraft:ochre_froglight
setblock 21 157 324 minecraft:ochre_froglight
fill 21 157 325 21 166 325 minecraft:honey_block
fill 21 157 329 21 168 329 minecraft:honey_block
setblock 21 157 330 minecraft:ochre_froglight
setblock 22 157 327 minecraft:ochre_froglight
setblock 26 157 323 minecraft:yellow_terracotta
fill 27 157 323 27 160 323 minecraft:honeycomb_block
fill 27 157 363 27 160 363 minecraft:honeycomb_block
fill 28 157 364 28 208 364 minecraft:honeycomb_block
fill 29 157 362 29 159 362 minecraft:honeycomb_block
setblock 30 157 324 minecraft:yellow_terracotta
setblock 31 157 323 minecraft:yellow_terracotta
fill 31 157 324 31 160 324 minecraft:honeycomb_block
fill 31 157 361 32 157 361 minecraft:honeycomb_block
setblock 31 157 363 minecraft:yellow_terracotta
fill 32 157 323 32 160 323 minecraft:honeycomb_block
setblock 32 157 362 minecraft:yellow_terracotta
fill 32 157 363 32 160 363 minecraft:honeycomb_block
setblock 33 157 361 minecraft:yellow_terracotta
fill 33 157 362 33 160 362 minecraft:honeycomb_block
fill 34 157 361 34 160 361 minecraft:honeycomb_block
fill 35 157 322 35 303 322 minecraft:honeycomb_block
setblock 35 157 324 minecraft:yellow_terracotta
setblock 36 157 323 minecraft:yellow_terracotta
setblock 36 157 363 minecraft:yellow_terracotta
fill 36 157 364 36 191 364 minecraft:honeycomb_block
setblock 37 157 323 minecraft:honeycomb_block
setblock 37 157 362 minecraft:yellow_terracotta
fill 37 157 363 37 160 363 minecraft:honeycomb_block
fill 38 157 362 38 159 362 minecraft:honeycomb_block
setblock 40 157 354 minecraft:yellow_terracotta
fill 40 157 355 40 158 355 minecraft:honeycomb_block
setblock 40 157 359 minecraft:yellow_terracotta
fill 40 157 360 40 160 360 minecraft:honeycomb_block
setblock 41 157 337 minecraft:honey_block
setblock 41 157 353 minecraft:yellow_terracotta
fill 41 157 354 41 160 354 minecraft:honeycomb_block
setblock 41 157 358 minecraft:yellow_terracotta
fill 41 157 359 41 160 359 minecraft:honeycomb_block
setblock 41 157 363 minecraft:yellow_terracotta
fill 42 157 330 42 218 330 minecraft:honeycomb_block
setblock 1 158 330 minecraft:honey_block
setblock 1 158 349 minecraft:honey_block
setblock 1 158 352 minecraft:yellow_terracotta
fill 1 158 353 1 160 353 minecraft:honeycomb_block
setblock 1 158 357 minecraft:yellow_terracotta
fill 1 158 358 1 161 358 minecraft:honeycomb_block
fill 2 158 339 2 162 339 minecraft:yellow_terracotta
setblock 2 158 356 minecraft:yellow_terracotta
setblock 2 158 357 minecraft:honeycomb_block
setblock 3 158 325 minecraft:light[level=12]
setblock 3 158 332 minecraft:light[level=12]
fill 3 158 338 3 162 338 minecraft:yellow_terracotta
fill 3 158 340 3 162 340 minecraft:yellow_terracotta
setblock 3 158 346 minecraft:light[level=12]
setblock 3 158 353 minecraft:light[level=12]
setblock 3 158 360 minecraft:light[level=12]
fill 4 158 339 4 162 339 minecraft:yellow_terracotta
setblock 5 158 323 minecraft:honey_block
fill 5 158 342 5 163 342 minecraft:brown_terracotta
setblock 9 158 363 minecraft:honeycomb_block
setblock 10 158 322 minecraft:yellow_terracotta
setblock 10 158 325 minecraft:light[level=12]
setblock 10 158 332 minecraft:light[level=12]
setblock 10 158 339 minecraft:light[level=12]
setblock 10 158 346 minecraft:light[level=12]
setblock 10 158 353 minecraft:light[level=12]
setblock 10 158 360 minecraft:light[level=12]
setblock 10 158 363 minecraft:yellow_terracotta
fill 11 158 363 11 161 363 minecraft:honeycomb_block
fill 12 158 325 12 167 329 minecraft:honey_block
fill 13 158 324 13 165 324 minecraft:honey_block
fill 13 158 330 13 167 330 minecraft:honey_block
fill 14 158 323 14 162 323 minecraft:honey_block
fill 14 158 331 14 167 331 minecraft:honey_block
fill 15 158 332 19 167 332 minecraft:honey_block
setblock 17 158 339 minecraft:light[level=12]
setblock 17 158 346 minecraft:light[level=12]
setblock 17 158 353 minecraft:light[level=12]
setblock 17 158 360 minecraft:light[level=12]
fill 20 158 323 20 163 323 minecraft:honey_block
fill 20 158 331 20 167 331 minecraft:honey_block
fill 21 158 324 21 164 324 minecraft:honey_block
fill 21 158 330 21 167 330 minecraft:honey_block
fill 22 158 325 22 166 329 minecraft:honey_block
setblock 24 158 325 minecraft:light[level=12]
setblock 24 158 332 minecraft:light[level=12]
setblock 24 158 339 minecraft:light[level=12]
setblock 24 158 346 minecraft:light[level=12]
setblock 24 158 353 minecraft:light[level=12]
setblock 24 158 360 minecraft:light[level=12]
fill 26 158 323 26 161 323 minecraft:honeycomb_block
fill 28 158 362 28 160 362 minecraft:honeycomb_block
setblock 29 158 324 minecraft:yellow_terracotta
setblock 30 158 323 minecraft:yellow_terracotta
fill 30 158 324 30 161 324 minecraft:honeycomb_block
fill 30 158 361 31 158 361 minecraft:honeycomb_block
setblock 30 158 363 minecraft:yellow_terracotta
fill 31 158 323 31 161 323 minecraft:honeycomb_block
setblock 31 158 325 minecraft:light[level=12]
setblock 31 158 332 minecraft:light[level=12]
setblock 31 158 339 minecraft:light[level=12]
setblock 31 158 346 minecraft:light[level=12]
setblock 31 158 353 minecraft:light[level=12]
setblock 31 158 360 minecraft:light[level=12]
setblock 31 158 362 minecraft:yellow_terracotta
fill 31 158 363 31 161 363 minecraft:honeycomb_block
setblock 32 158 361 minecraft:yellow_terracotta
fill 32 158 362 32 161 362 minecraft:honeycomb_block
fill 33 158 361 33 161 361 minecraft:honeycomb_block
setblock 35 158 323 minecraft:yellow_terracotta
setblock 35 158 363 minecraft:yellow_terracotta
fill 36 158 323 36 159 323 minecraft:honeycomb_block
setblock 36 158 362 minecraft:yellow_terracotta
fill 36 158 363 36 161 363 minecraft:honeycomb_block
fill 37 158 362 37 161 362 minecraft:honeycomb_block
setblock 38 158 325 minecraft:light[level=12]
setblock 38 158 332 minecraft:light[level=12]
setblock 38 158 339 minecraft:light[level=12]
setblock 38 158 346 minecraft:light[level=12]
setblock 38 158 353 minecraft:light[level=12]
setblock 38 158 360 minecraft:light[level=12]
setblock 40 158 358 minecraft:yellow_terracotta
fill 40 158 359 40 161 359 minecraft:honeycomb_block
setblock 40 158 363 minecraft:yellow_terracotta
setblock 41 158 331 minecraft:honey_block
setblock 41 158 352 minecraft:yellow_terracotta
fill 41 158 353 41 159 353 minecraft:honeycomb_block
setblock 41 158 357 minecraft:yellow_terracotta
fill 41 158 358 41 161 358 minecraft:honeycomb_block
setblock 41 158 362 minecraft:yellow_terracotta
fill 41 158 363 41 161 363 minecraft:honeycomb_block
setblock 0 159 355 minecraft:orange_terracotta
setblock 0 159 357 minecraft:orange_terracotta
setblock 1 159 336 minecraft:honey_block
setblock 1 159 352 minecraft:honeycomb_block
setblock 1 159 356 minecraft:yellow_terracotta
fill 1 159 357 1 162 357 minecraft:honeycomb_block
setblock 1 159 361 minecraft:honey_block
setblock 9 159 363 minecraft:yellow_terracotta
fill 10 159 322 10 163 322 minecraft:honeycomb_block
fill 10 159 363 10 162 363 minecraft:honeycomb_block
fill 12 159 324 12 164 324 minecraft:honey_block
fill 12 159 330 12 166 330 minecraft:honey_block
fill 13 159 323 13 162 323 minecraft:honey_block
fill 13 159 331 13 166 331 minecraft:honey_block
fill 14 159 332 14 166 332 minecraft:honey_block
setblock 18 159 363 minecraft:honey_block
fill 20 159 332 20 166 332 minecraft:honey_block
fill 21 159 323 21 162 323 minecraft:honey_block
fill 21 159 331 21 166 331 minecraft:honey_block
fill 22 159 324 22 164 324 minecraft:honey_block
fill 22 159 330 22 166 330 minecraft:honey_block
setblock 24 159 323 minecraft:honey_block
fill 26 159 363 26 161 363 minecraft:honeycomb_block
setblock 29 159 323 minecraft:yellow_terracotta
fill 29 159 324 29 162 324 minecraft:honeycomb_block
setblock 29 159 363 minecraft:yellow_terracotta
fill 29 159 364 29 192 364 minecraft:honeycomb_block
fill 30 159 323 30 162 323 minecraft:honeycomb_block
setblock 30 159 361 minecraft:honeycomb_block
setblock 30 159 362 minecraft:yellow_terracotta
fill 30 159 363 30 162 363 minecraft:honeycomb_block
setblock 31 159 361 minecraft:yellow_terracotta
fill 31 159 362 31 162 362 minecraft:honeycomb_block
fill 32 159 361 32 162 361 minecraft:honeycomb_block
setblock 34 159 323 minecraft:yellow_terracotta
setblock 34 159 363 minecraft:yellow_terracotta
fill 35 159 323 35 162 323 minecraft:honeycomb_block
setblock 35 159 362 minecraft:yellow_terracotta
fill 35 159 363 35 162 363 minecraft:honeycomb_block
fill 36 159 362 36 162 362 minecraft:honeycomb_block
setblock 39 159 363 minecraft:yellow_terracotta
setblock 40 159 357 minecraft:yellow_terracotta
fill 40 159 358 40 162 358 minecraft:honeycomb_block
fill 40 159 363 40 162 363 minecraft:honeycomb_block
setblock 41 159 325 minecraft:honey_block
setblock 41 159 350 minecraft:honey_block
setblock 41 159 356 minecraft:yellow_terracotta
fill 41 159 357 41 162 357 minecraft:honeycomb_block
setblock 41 159 361 minecraft:yellow_terracotta
fill 41 159 362 41 162 362 minecraft:honeycomb_block
setblock 42 159 356 minecraft:orange_terracotta
fill 0 160 355 0 174 355 minecraft:honeycomb_block
fill 0 160 357 0 308 357 minecraft:honeycomb_block
setblock 1 160 322 minecraft:orange_terracotta
setblock 1 160 323 minecraft:honey_block
fill 1 160 338 1 161 338 minecraft:honeycomb_block
setblock 1 160 342 minecraft:honey_block
setblock 1 160 355 minecraft:yellow_terracotta
fill 1 160 356 1 163 356 minecraft:honeycomb_block
setblock 1 160 360 minecraft:yellow_terracotta
fill 2 160 338 2 162 338 minecraft:yellow_terracotta
fill 2 160 340 2 162 340 minecraft:yellow_terracotta
setblock 3 160 325 minecraft:light[level=15]
setblock 3 160 333 minecraft:light[level=15]
setblock 3 160 341 minecraft:light[level=15]
setblock 3 160 349 minecraft:light[level=15]
setblock 3 160 357 minecraft:light[level=15]
fill 4 160 338 4 162 338 minecraft:yellow_terracotta
fill 4 160 340 4 162 340 minecraft:yellow_terracotta
fill 4 160 341 4 161 341 minecraft:flowering_azalea_leaves[persistent=true]
setblock 5 160 363 minecraft:honey_block
fill 6 160 347 7 161 348 minecraft:yellow_concrete
setblock 7 160 363 minecraft:honeycomb_block
setblock 8 160 363 minecraft:yellow_terracotta
fill 9 160 363 9 163 363 minecraft:honeycomb_block
setblock 11 160 325 minecraft:light[level=15]
fill 11 160 326 11 165 328 minecraft:honey_block
setblock 11 160 333 minecraft:light[level=15]
setblock 11 160 341 minecraft:light[level=15]
setblock 11 160 349 minecraft:light[level=15]
setblock 11 160 357 minecraft:light[level=15]
fill 16 160 333 18 165 333 minecraft:honey_block
setblock 19 160 333 minecraft:light[level=15]
setblock 19 160 341 minecraft:light[level=15]
setblock 19 160 349 minecraft:light[level=15]
setblock 19 160 357 minecraft:light[level=15]
fill 23 160 326 23 165 328 minecraft:honey_block
setblock 24 160 363 minecraft:honey_block
fill 25 160 323 25 162 323 minecraft:honeycomb_block
fill 25 160 363 25 162 363 minecraft:honeycomb_block
setblock 27 160 325 minecraft:light[level=15]
setblock 27 160 333 minecraft:light[level=15]
setblock 27 160 341 minecraft:light[level=15]
setblock 27 160 349 minecraft:light[level=15]
setblock 27 160 357 minecraft:light[level=15]
fill 27 160 362 27 161 362 minecraft:honeycomb_block
setblock 28 160 323 minecraft:yellow_terracotta
setblock 28 160 363 minecraft:yellow_terracotta
fill 29 160 323 29 163 323 minecraft:honeycomb_block
setblock 29 160 361 minecraft:honeycomb_block
setblock 29 160 362 minecraft:yellow_terracotta
fill 29 160 363 29 163 363 minecraft:honeycomb_block
setblock 30 160 361 minecraft:yellow_terracotta
fill 30 160 362 30 163 362 minecraft:honeycomb_block
fill 31 160 361 31 163 361 minecraft:honeycomb_block
setblock 32 160 324 minecraft:yellow_terracotta
setblock 33 160 323 minecraft:yellow_terracotta
setblock 33 160 363 minecraft:yellow_terracotta
fill 34 160 323 34 163 323 minecraft:honeycomb_block
setblock 34 160 362 minecraft:yellow_terracotta
fill 34 160 363 34 163 363 minecraft:honeycomb_block
setblock 35 160 325 minecraft:light[level=15]
setblock 35 160 333 minecraft:light[level=15]
setblock 35 160 341 minecraft:light[level=15]
setblock 35 160 349 minecraft:light[level=15]
setblock 35 160 357 minecraft:light[level=15]
setblock 35 160 361 minecraft:yellow_terracotta
fill 35 160 362 35 163 362 minecraft:honeycomb_block
setblock 37 160 323 minecraft:honey_block
setblock 38 160 363 minecraft:yellow_terracotta
fill 39 160 363 39 163 363 minecraft:honeycomb_block
setblock 40 160 357 minecraft:honeycomb_block
setblock 41 160 344 minecraft:honey_block
setblock 41 160 355 minecraft:yellow_terracotta
fill 41 160 356 42 163 356 minecraft:honeycomb_block
setblock 41 160 360 minecraft:yellow_terracotta
fill 41 160 361 41 163 361 minecraft:honeycomb_block
fill 1 161 322 1 204 322 minecraft:honeycomb_block
setblock 1 161 329 minecraft:honey_block
fill 1 161 337 1 162 337 minecraft:honeycomb_block
setblock 1 161 339 minecraft:yellow_terracotta
fill 1 161 340 1 163 341 minecraft:honeycomb_block
setblock 1 161 348 minecraft:honey_block
setblock 1 161 354 minecraft:yellow_terracotta
fill 1 161 355 1 164 355 minecraft:honeycomb_block
setblock 1 161 359 minecraft:yellow_terracotta
fill 1 161 360 1 163 361 minecraft:honeycomb_block
setblock 3 161 322 minecraft:yellow_concrete
fill 4 161 342 4 163 342 minecraft:brown_terracotta
fill 5 161 341 5 163 341 minecraft:brown_terracotta
fill 5 161 343 5 163 343 minecraft:brown_terracotta
fill 6 161 342 6 163 342 minecraft:brown_terracotta
setblock 6 161 363 minecraft:honeycomb_block
fill 7 161 332 7 162 332 minecraft:honey_block
setblock 7 161 363 minecraft:yellow_terracotta
fill 8 161 363 8 164 363 minecraft:honeycomb_block
setblock 11 161 325 minecraft:ochre_froglight
setblock 11 161 329 minecraft:ochre_froglight
setblock 12 161 323 minecraft:honey_block
fill 12 161 331 12 164 331 minecraft:ochre_froglight
setblock 12 161 363 minecraft:yellow_terracotta
fill 13 161 332 13 164 332 minecraft:ochre_froglight
fill 13 161 363 13 164 363 minecraft:honeycomb_block
setblock 15 161 333 minecraft:ochre_froglight
setblock 19 161 333 minecraft:ochre_froglight
fill 21 161 332 21 164 332 minecraft:ochre_froglight
fill 22 161 323 22 162 323 minecraft:ochre_froglight
fill 22 161 331 22 164 331 minecraft:ochre_froglight
setblock 23 161 325 minecraft:ochre_froglight
setblock 23 161 329 minecraft:ochre_froglight
fill 24 161 323 24 163 323 minecraft:honeycomb_block
fill 24 161 363 24 163 363 minecraft:honeycomb_block
fill 26 161 362 26 162 362 minecraft:honeycomb_block
setblock 27 161 323 minecraft:yellow_terracotta
setblock 27 161 363 minecraft:yellow_terracotta
fill 28 161 323 28 163 324 minecraft:honeycomb_block
setblock 28 161 361 minecraft:honeycomb_block
setblock 28 161 362 minecraft:yellow_terracotta
fill 28 161 363 28 164 363 minecraft:honeycomb_block
setblock 29 161 361 minecraft:yellow_terracotta
fill 29 161 362 29 164 362 minecraft:honeycomb_block
fill 30 161 361 30 164 361 minecraft:honeycomb_block
setblock 31 161 324 minecraft:yellow_terracotta
setblock 32 161 323 minecraft:yellow_terracotta
setblock 32 161 363 minecraft:yellow_terracotta
fill 33 161 323 33 164 323 minecraft:honeycomb_block
setblock 33 161 362 minecraft:yellow_terracotta
fill 33 161 363 33 164 363 minecraft:honeycomb_block
setblock 34 161 361 minecraft:yellow_terracotta
fill 34 161 362 34 164 362 minecraft:honeycomb_block
fill 35 161 361 35 164 361 minecraft:honeycomb_block
setblock 37 161 363 minecraft:yellow_terracotta
fill 38 161 363 38 164 363 minecraft:honeycomb_block
setblock 40 161 360 minecraft:yellow_terracotta
setblock 41 161 338 minecraft:honey_block
setblock 41 161 354 minecraft:yellow_terracotta
fill 41 161 355 41 164 355 minecraft:honeycomb_block
setblock 41 161 359 minecraft:yellow_terracotta
fill 41 161 360 41 164 360 minecraft:honeycomb_block
setblock 0 162 361 minecraft:orange_terracotta
setblock 1 162 335 minecraft:honey_block
fill 1 162 336 1 163 336 minecraft:honeycomb_block
setblock 1 162 338 minecraft:yellow_terracotta
fill 1 162 339 1 165 339 minecraft:honeycomb_block
setblock 1 162 342 minecraft:honeycomb_block
setblock 1 162 343 minecraft:yellow_terracotta
setblock 1 162 354 minecraft:honey_block
setblock 1 162 358 minecraft:yellow_terracotta
fill 1 162 359 1 165 359 minecraft:honeycomb_block
fill 3 162 322 3 278 322 minecraft:honeycomb_block
fill 4 162 341 4 163 341 minecraft:brown_terracotta
fill 4 162 343 4 163 343 minecraft:brown_terracotta
fill 4 162 363 5 162 363 minecraft:honeycomb_block
setblock 6 162 323 minecraft:honey_block
fill 6 162 341 6 163 341 minecraft:brown_terracotta
fill 6 162 343 6 163 343 minecraft:brown_terracotta
setblock 6 162 363 minecraft:yellow_terracotta
fill 7 162 363 7 165 363 minecraft:honeycomb_block
fill 8 162 362 10 163 362 minecraft:honeycomb_block
fill 9 162 323 10 162 323 minecraft:honeycomb_block
setblock 11 162 323 minecraft:yellow_terracotta
fill 11 162 325 11 163 325 minecraft:honey_block
fill 11 162 329 11 163 329 minecraft:honey_block
setblock 11 162 363 minecraft:yellow_terracotta
fill 12 162 323 12 165 323 minecraft:honeycomb_block
fill 12 162 363 12 165 363 minecraft:honeycomb_block
setblock 13 162 322 minecraft:yellow_terracotta
fill 15 162 333 15 163 333 minecraft:honey_block
setblock 17 162 363 minecraft:honey_block
fill 19 162 333 19 163 333 minecraft:honey_block
fill 23 162 323 23 164 323 minecraft:honeycomb_block
fill 23 162 325 23 163 325 minecraft:honey_block
fill 23 162 329 23 163 329 minecraft:honey_block
fill 23 162 363 23 164 363 minecraft:honeycomb_block
fill 25 162 362 25 163 362 minecraft:honeycomb_block
setblock 26 162 323 minecraft:yellow_terracotta
fill 26 162 324 27 164 324 minecraft:honeycomb_block
setblock 26 162 363 minecraft:yellow_terracotta
fill 27 162 323 27 165 323 minecraft:honeycomb_block
setblock 27 162 361 minecraft:honeycomb_block
setblock 27 162 362 minecraft:yellow_terracotta
fill 27 162 363 27 165 363 minecraft:honeycomb_block
setblock 28 162 361 minecraft:yellow_terracotta
fill 28 162 362 28 165 362 minecraft:honeycomb_block
fill 29 162 361 29 165 361 minecraft:honeycomb_block
setblock 30 162 322 minecraft:yellow_terracotta
setblock 30 162 324 minecraft:yellow_terracotta
setblock 31 162 323 minecraft:yellow_terracotta
fill 31 162 324 32 164 324 minecraft:honeycomb_block
setblock 31 162 363 minecraft:yellow_terracotta
setblock 31 162 364 minecraft:yellow_concrete
fill 32 162 323 32 165 323 minecraft:honeycomb_block
setblock 32 162 362 minecraft:yellow_terracotta
fill 32 162 363 32 165 363 minecraft:honeycomb_block
setblock 33 162 361 minecraft:yellow_terracotta
fill 33 162 362 33 165 362 minecraft:honeycomb_block
fill 34 162 361 34 165 361 minecraft:honeycomb_block
setblock 36 162 363 minecraft:yellow_terracotta
setblock 37 162 362 minecraft:yellow_terracotta
fill 37 162 363 37 165 363 minecraft:honeycomb_block
fill 38 162 362 38 165 362 minecraft:honeycomb_block
setblock 40 162 359 minecraft:yellow_terracotta
fill 40 162 360 40 164 361 minecraft:honeycomb_block
setblock 41 162 332 minecraft:honey_block
setblock 41 162 351 minecraft:honey_block
fill 41 162 354 41 165 354 minecraft:honeycomb_block
setblock 41 162 358 minecraft:yellow_terracotta
fill 41 162 359 41 165 359 minecraft:honeycomb_block
setblock 41 162 363 minecraft:yellow_terracotta
setblock 0 163 330 minecraft:yellow_terracotta
fill 0 163 361 0 308 361 minecraft:honeycomb_block
setblock 1 163 337 minecraft:yellow_terracotta
fill 1 163 338 2 165 338 minecraft:honeycomb_block
setblock 1 163 342 minecraft:yellow_terracotta
fill 1 163 343 1 164 345 minecraft:honeycomb_block
setblock 1 163 357 minecraft:yellow_terracotta
fill 1 163 358 1 166 358 minecraft:honeycomb_block
setblock 1 163 362 minecraft:yellow_terracotta
fill 2 163 339 2 163 340 minecraft:honeycomb_block
setblock 2 163 341 minecraft:yellow_terracotta
fill 2 163 342 2 165 343 minecraft:honeycomb_block
fill 2 163 363 4 163 363 minecraft:honeycomb_block
setblock 5 163 363 minecraft:yellow_terracotta
fill 6 163 334 6 173 334 minecraft:flowering_azalea_leaves[persistent=true]
setblock 6 163 362 minecraft:yellow_terracotta
fill 6 163 363 6 166 363 minecraft:honeycomb_block
fill 7 163 323 9 163 323 minecraft:honeycomb_block
fill 7 163 362 7 166 362 minecraft:honeycomb_block
setblock 10 163 323 minecraft:yellow_terracotta
setblock 10 163 363 minecraft:yellow_terracotta
fill 11 163 323 11 166 323 minecraft:honeycomb_block
setblock 11 163 362 minecraft:yellow_terracotta
fill 11 163 363 11 166 363 minecraft:honeycomb_block
fill 13 163 322 13 164 323 minecraft:honeycomb_block
setblock 14 163 323 minecraft:honeycomb_block
setblock 14 163 363 minecraft:honeycomb_block
setblock 17 163 364 minecraft:orange_terracotta
fill 21 163 323 22 165 323 minecraft:honeycomb_block
fill 21 163 363 22 165 363 minecraft:honeycomb_block
fill 24 163 362 24 164 362 minecraft:honeycomb_block
setblock 25 163 323 minecraft:yellow_terracotta
fill 25 163 324 25 166 324 minecraft:honeycomb_block
setblock 25 163 363 minecraft:yellow_terracotta
fill 26 163 323 26 166 323 minecraft:honeycomb_block
setblock 26 163 361 minecraft:honeycomb_block
setblock 26 163 362 minecraft:yellow_terracotta
fill 26 163 363 26 166 363 minecraft:honeycomb_block
setblock 26 163 364 minecraft:yellow_terracotta
setblock 27 163 361 minecraft:yellow_terracotta
fill 27 163 362 27 166 362 minecraft:honeycomb_block
fill 28 163 361 28 166 361 minecraft:honeycomb_block
setblock 29 163 324 minecraft:yellow_terracotta
fill 30 163 322 30 172 322 minecraft:honeycomb_block
setblock 30 163 323 minecraft:yellow_terracotta
fill 30 163 324 30 166 324 minecraft:honeycomb_block
fill 30 163 360 31 164 360 minecraft:honeycomb_block
setblock 30 163 363 minecraft:yellow_terracotta
fill 31 163 323 31 166 323 minecraft:honeycomb_block
setblock 31 163 362 minecraft:yellow_terracotta
fill 31 163 363 31 166 364 minecraft:honeycomb_block
setblock 32 163 361 minecraft:yellow_terracotta
fill 32 163 362 32 166 362 minecraft:honeycomb_block
fill 33 163 361 33 166 361 minecraft:honeycomb_block
setblock 35 163 323 minecraft:yellow_terracotta
setblock 35 163 363 minecraft:yellow_terracotta
setblock 36 163 362 minecraft:yellow_terracotta
fill 36 163 363 36 166 363 minecraft:honeycomb_block
fill 37 163 362 37 166 362 minecraft:honeycomb_block
fill 39 163 362 40 163 362 minecraft:honeycomb_block
setblock 40 163 358 minecraft:yellow_terracotta
fill 40 163 359 40 166 359 minecraft:honeycomb_block
setblock 40 163 363 minecraft:yellow_terracotta
setblock 41 163 326 minecraft:honey_block
setblock 41 163 345 minecraft:honey_block
setblock 41 163 357 minecraft:yellow_terracotta
fill 41 163 358 41 166 358 minecraft:honeycomb_block
setblock 41 163 362 minecraft:yellow_terracotta
fill 41 163 363 41 166 363 minecraft:honeycomb_block
fill 0 164 330 0 179 330 minecraft:honeycomb_block
setblock 0 164 347 minecraft:yellow_concrete
setblock 1 164 335 minecraft:honeycomb_block
setblock 1 164 336 minecraft:yellow_terracotta
fill 1 164 337 2 166 337 minecraft:honeycomb_block
setblock 1 164 340 minecraft:honeycomb_block
setblock 1 164 341 minecraft:yellow_terracotta
fill 1 164 342 1 167 342 minecraft:honeycomb_block
setblock 1 164 346 minecraft:yellow_terracotta
fill 1 164 347 1 166 348 minecraft:honeycomb_block
fill 1 164 354 1 165 354 minecraft:honeycomb_block
setblock 1 164 356 minecraft:yellow_terracotta
fill 1 164 357 1 167 357 minecraft:honeycomb_block
setblock 1 164 360 minecraft:honeycomb_block
setblock 1 164 361 minecraft:yellow_terracotta
fill 1 164 362 1 166 363 minecraft:honeycomb_block
setblock 2 164 339 minecraft:honeycomb_block
setblock 2 164 340 minecraft:yellow_terracotta
fill 2 164 341 3 166 341 minecraft:honeycomb_block
setblock 2 164 344 minecraft:honeycomb_block
setblock 2 164 345 minecraft:yellow_terracotta
fill 2 164 363 3 164 363 minecraft:honeycomb_block
setblock 3 164 325 minecraft:light[level=12]
setblock 3 164 332 minecraft:light[level=12]
setblock 3 164 338 minecraft:honeycomb_block
setblock 3 164 339 minecraft:yellow_terracotta
fill 3 164 340 3 167 340 minecraft:honeycomb_block
fill 3 164 342 3 164 343 minecraft:honeycomb_block
setblock 3 164 346 minecraft:light[level=12]
setblock 3 164 353 minecraft:light[level=12]
setblock 3 164 360 minecraft:light[level=12]
setblock 4 164 341 minecraft:flowering_azalea_leaves[persistent=true]
setblock 4 164 362 minecraft:honeycomb_block
setblock 4 164 363 minecraft:yellow_terracotta
fill 5 164 323 8 164 323 minecraft:honeycomb_block
setblock 5 164 362 minecraft:yellow_terracotta
fill 5 164 363 5 167 363 minecraft:honeycomb_block
fill 6 164 362 6 167 362 minecraft:honeycomb_block
fill 8 164 362 9 164 362 minecraft:honeycomb_block
setblock 9 164 323 minecraft:yellow_terracotta
setblock 9 164 363 minecraft:yellow_terracotta
setblock 10 164 322 minecraft:orange_terracotta
fill 10 164 323 10 167 323 minecraft:honeycomb_block
setblock 10 164 325 minecraft:light[level=12]
setblock 10 164 332 minecraft:light[level=12]
setblock 10 164 339 minecraft:light[level=12]
setblock 10 164 346 minecraft:light[level=12]
setblock 10 164 353 minecraft:light[level=12]
setblock 10 164 360 minecraft:light[level=12]
setblock 10 164 362 minecraft:yellow_terracotta
fill 10 164 363 10 167 363 minecraft:honeycomb_block
setblock 11 164 325 minecraft:ochre_froglight
setblock 11 164 329 minecraft:ochre_froglight
fill 11 164 362 11 167 362 minecraft:honeycomb_block
setblock 14 164 323 minecraft:yellow_terracotta
setblock 14 164 363 minecraft:yellow_terracotta
fill 15 164 323 18 164 323 minecraft:honeycomb_block
setblock 15 164 333 minecraft:ochre_froglight
fill 15 164 363 15 167 363 minecraft:honeycomb_block
setblock 17 164 339 minecraft:light[level=12]
setblock 17 164 346 minecraft:light[level=12]
setblock 17 164 353 minecraft:light[level=12]
setblock 17 164 360 minecraft:light[level=12]
fill 17 164 364 17 238 364 minecraft:honeycomb_block
setblock 19 164 323 minecraft:yellow_terracotta
setblock 19 164 333 minecraft:ochre_froglight
setblock 19 164 363 minecraft:yellow_terracotta
fill 20 164 323 20 167 323 minecraft:honeycomb_block
fill 20 164 363 20 167 363 minecraft:honeycomb_block
fill 22 164 362 23 165 362 minecraft:honeycomb_block
setblock 23 164 324 minecraft:yellow_terracotta
setblock 23 164 325 minecraft:ochre_froglight
setblock 23 164 329 minecraft:ochre_froglight
setblock 24 164 323 minecraft:yellow_terracotta
fill 24 164 324 24 167 324 minecraft:honeycomb_block
setblock 24 164 325 minecraft:light[level=12]
setblock 24 164 332 minecraft:light[level=12]
setblock 24 164 339 minecraft:light[level=12]
setblock 24 164 346 minecraft:light[level=12]
setblock 24 164 353 minecraft:light[level=12]
setblock 24 164 360 minecraft:light[level=12]
setblock 24 164 363 minecraft:yellow_terracotta
fill 25 164 323 25 167 323 minecraft:honeycomb_block
setblock 25 164 361 minecraft:honeycomb_block
setblock 25 164 362 minecraft:yellow_terracotta
fill 25 164 363 25 167 363 minecraft:honeycomb_block
setblock 26 164 361 minecraft:yellow_terracotta
fill 26 164 362 26 167 362 minecraft:honeycomb_block
fill 26 164 364 26 249 364 minecraft:honeycomb_block
fill 27 164 361 27 167 361 minecraft:honeycomb_block
setblock 28 164 323 minecraft:honeycomb_block
setblock 28 164 324 minecraft:yellow_terracotta
fill 28 164 360 29 166 360 minecraft:honeycomb_block
setblock 29 164 323 minecraft:yellow_terracotta
fill 29 164 324 29 167 324 minecraft:honeycomb_block
setblock 29 164 363 minecraft:yellow_terracotta
fill 30 164 323 30 167 323 minecraft:honeycomb_block
setblock 30 164 362 minecraft:yellow_terracotta
fill 30 164 363 30 167 363 minecraft:honeycomb_block
setblock 31 164 325 minecraft:light[level=12]
setblock 31 164 332 minecraft:light[level=12]
setblock 31 164 339 minecraft:light[level=12]
setblock 31 164 346 minecraft:light[level=12]
setblock 31 164 353 minecraft:light[level=12]
setblock 31 164 361 minecraft:yellow_terracotta
fill 31 164 362 31 167 362 minecraft:honeycomb_block
fill 32 164 361 32 167 361 minecraft:honeycomb_block
setblock 34 164 323 minecraft:yellow_terracotta
setblock 34 164 363 minecraft:yellow_terracotta
fill 35 164 323 36 166 323 minecraft:honeycomb_block
setblock 35 164 362 minecraft:yellow_terracotta
fill 35 164 363 35 167 363 minecraft:honeycomb_block
fill 36 164 362 36 167 362 minecraft:honeycomb_block
setblock 38 164 323 minecraft:honey_block
setblock 38 164 325 minecraft:light[level=12]
setblock 38 164 332 minecraft:light[level=12]
setblock 38 164 339 minecraft:light[level=12]
setblock 38 164 346 minecraft:light[level=12]
setblock 38 164 353 minecraft:light[level=12]
setblock 38 164 360 minecraft:light[level=12]
setblock 39 164 362 minecraft:honeycomb_block
setblock 39 164 363 minecraft:yellow_terracotta
setblock 40 164 357 minecraft:yellow_terracotta
fill 40 164 358 40 167 358 minecraft:honeycomb_block
setblock 40 164 362 minecraft:yellow_terracotta
fill 40 164 363 40 167 363 minecraft:honeycomb_block
fill 41 164 339 41 164 340 minecraft:honeycomb_block
setblock 41 164 341 minecraft:yellow_terracotta
fill 41 164 342 41 165 344 minecraft:honeycomb_block
setblock 41 164 356 minecraft:yellow_terracotta
fill 41 164 357 41 167 357 minecraft:honeycomb_block
setblock 41 164 361 minecraft:yellow_terracotta
fill 41 164 362 41 167 362 minecraft:honeycomb_block
fill 42 164 356 42 221 356 minecraft:honeycomb_block
fill 0 165 347 0 246 347 minecraft:honeycomb_block
setblock 1 165 328 minecraft:honey_block
setblock 1 165 335 minecraft:yellow_terracotta
fill 1 165 336 2 167 336 minecraft:honeycomb_block
setblock 1 165 340 minecraft:yellow_terracotta
fill 1 165 341 1 168 341 minecraft:honeycomb_block
fill 1 165 343 1 165 344 minecraft:honeycomb_block
setblock 1 165 345 minecraft:yellow_terracotta
fill 1 165 346 2 167 346 minecraft:honeycomb_block
setblock 1 165 349 minecraft:honeycomb_block
setblock 1 165 350 minecraft:yellow_terracotta
fill 1 165 351 1 166 353 minecraft:honeycomb_block
setblock 1 165 355 minecraft:yellow_terracotta
fill 1 165 356 1 168 356 minecraft:honeycomb_block
setblock 1 165 360 minecraft:yellow_terracotta
fill 1 165 361 2 167 361 minecraft:honeycomb_block
setblock 2 165 339 minecraft:yellow_terracotta
fill 2 165 340 2 168 340 minecraft:honeycomb_block
setblock 2 165 344 minecraft:yellow_terracotta
fill 2 165 345 3 167 345 minecraft:honeycomb_block
fill 2 165 347 2 166 347 minecraft:honeycomb_block
setblock 2 165 358 minecraft:honeycomb_block
setblock 2 165 359 minecraft:yellow_terracotta
fill 2 165 360 2 168 360 minecraft:honeycomb_block
fill 2 165 362 2 165 363 minecraft:honeycomb_block
setblock 3 165 323 minecraft:yellow_terracotta
setblock 3 165 337 minecraft:honeycomb_block
setblock 3 165 338 minecraft:yellow_terracotta
fill 3 165 339 4 167 339 minecraft:honeycomb_block
setblock 3 165 342 minecraft:honeycomb_block
setblock 3 165 343 minecraft:yellow_terracotta
fill 3 165 344 3 168 344 minecraft:honeycomb_block
setblock 3 165 362 minecraft:honeycomb_block
setblock 3 165 363 minecraft:yellow_terracotta
fill 4 165 323 7 165 323 minecraft:honeycomb_block
fill 4 165 340 4 165 341 minecraft:honeycomb_block
setblock 4 165 342 minecraft:yellow_terracotta
fill 4 165 343 4 168 343 minecraft:honeycomb_block
setblock 4 165 362 minecraft:yellow_terracotta
fill 4 165 363 4 168 363 minecraft:honeycomb_block
fill 5 165 362 5 168 362 minecraft:honeycomb_block
fill 6 165 356 6 180 356 minecraft:iron_block
setblock 7 165 324 minecraft:yellow_terracotta
setblock 8 165 323 minecraft:yellow_terracotta
fill 8 165 324 11 165 324 minecraft:honeycomb_block
setblock 8 165 362 minecraft:honeycomb_block
setblock 8 165 363 minecraft:yellow_terracotta
fill 9 165 323 9 168 323 minecraft:honeycomb_block
setblock 9 165 362 minecraft:yellow_terracotta
fill 9 165 363 9 168 363 minecraft:honeycomb_block
fill 10 165 322 10 231 322 minecraft:honeycomb_block
fill 10 165 362 10 168 362 minecraft:honeycomb_block
setblock 12 165 324 minecraft:yellow_terracotta
fill 12 165 362 12 166 362 minecraft:honeycomb_block
fill 13 165 322 13 203 322 minecraft:honeycomb_block
setblock 13 165 323 minecraft:yellow_terracotta
setblock 13 165 363 minecraft:yellow_terracotta
fill 14 165 323 17 165 323 minecraft:honeycomb_block
fill 14 165 363 14 168 363 minecraft:honeycomb_block
fill 16 165 363 17 165 363 minecraft:honeycomb_block
setblock 18 165 323 minecraft:yellow_terracotta
setblock 18 165 363 minecraft:yellow_terracotta
fill 19 165 323 19 168 323 minecraft:honeycomb_block
fill 19 165 363 19 168 363 minecraft:honeycomb_block
setblock 21 165 324 minecraft:honeycomb_block
fill 21 165 362 21 167 362 minecraft:honeycomb_block
setblock 22 165 324 minecraft:yellow_terracotta
setblock 23 165 323 minecraft:yellow_terracotta
fill 23 165 324 23 168 324 minecraft:honeycomb_block
setblock 23 165 363 minecraft:yellow_terracotta
fill 24 165 323 24 168 323 minecraft:honeycomb_block
setblock 24 165 361 minecraft:honeycomb_block
setblock 24 165 362 minecraft:yellow_terracotta
fill 24 165 363 24 168 363 minecraft:honeycomb_block
setblock 25 165 325 minecraft:honeycomb_block
setblock 25 165 361 minecraft:yellow_terracotta
fill 25 165 362 25 168 362 minecraft:honeycomb_block
setblock 26 165 322 minecraft:orange_terracotta
setblock 26 165 324 minecraft:honeycomb_block
setblock 26 165 325 minecraft:yellow_terracotta
fill 26 165 361 26 168 361 minecraft:honeycomb_block
setblock 27 165 324 minecraft:yellow_terracotta
fill 27 165 325 29 166 325 minecraft:honeycomb_block
fill 27 165 360 27 168 360 minecraft:honeycomb_block
setblock 28 165 323 minecraft:yellow_terracotta
fill 28 165 324 28 168 324 minecraft:honeycomb_block
setblock 28 165 363 minecraft:yellow_terracotta
fill 29 165 323 29 168 323 minecraft:honeycomb_block
setblock 29 165 362 minecraft:yellow_terracotta
fill 29 165 363 29 168 363 minecraft:honeycomb_block
setblock 30 165 360 minecraft:honeycomb_block
setblock 30 165 361 minecraft:yellow_terracotta
fill 30 165 362 30 168 362 minecraft:honeycomb_block
setblock 31 165 324 minecraft:honeycomb_block
setblock 31 165 360 minecraft:yellow_terracotta
fill 31 165 361 31 168 361 minecraft:honeycomb_block
setblock 32 165 324 minecraft:yellow_terracotta
setblock 33 165 323 minecraft:yellow_terracotta
fill 33 165 324 33 168 324 minecraft:honeycomb_block
setblock 33 165 363 minecraft:yellow_terracotta
fill 34 165 323 34 168 323 minecraft:honeycomb_block
setblock 34 165 362 minecraft:yellow_terracotta
fill 34 165 363 34 168 363 minecraft:honeycomb_block
setblock 35 165 361 minecraft:yellow_terracotta
fill 35 165 362 35 168 362 minecraft:honeycomb_block
fill 36 165 361 36 166 361 minecraft:honeycomb_block
setblock 38 165 363 minecraft:yellow_terracotta
setblock 38 165 364 minecraft:yellow_concrete
setblock 39 165 322 minecraft:yellow_terracotta
setblock 39 165 362 minecraft:yellow_terracotta
fill 39 165 363 39 168 363 minecraft:honeycomb_block
fill 40 165 357 40 168 357 minecraft:honeycomb_block
setblock 40 165 360 minecraft:honeycomb_block
setblock 40 165 361 minecraft:yellow_terracotta
fill 40 165 362 40 168 362 minecraft:honeycomb_block
setblock 41 165 333 minecraft:honey_block
fill 41 165 338 41 165 339 minecraft:honeycomb_block
setblock 41 165 340 minecraft:yellow_terracotta
fill 41 165 341 41 168 341 minecraft:honeycomb_block
setblock 41 165 345 minecraft:yellow_terracotta
fill 41 165 346 41 166 348 minecraft:honeycomb_block
fill 41 165 352 41 166 353 minecraft:honeycomb_block
setblock 41 165 355 minecraft:yellow_terracotta
fill 41 165 356 41 168 356 minecraft:honeycomb_block
setblock 41 165 360 minecraft:yellow_terracotta
fill 41 165 361 41 168 361 minecraft:honeycomb_block
setblock 1 166 323 minecraft:honeycomb_block
setblock 1 166 334 minecraft:yellow_terracotta
fill 1 166 335 2 168 335 minecraft:honeycomb_block
setblock 1 166 338 minecraft:honeycomb_block
setblock 1 166 339 minecraft:yellow_terracotta
fill 1 166 340 1 169 340 minecraft:honeycomb_block
setblock 1 166 343 minecraft:honeycomb_block
setblock 1 166 344 minecraft:yellow_terracotta
fill 1 166 345 1 169 345 minecraft:honeycomb_block
setblock 1 166 349 minecraft:yellow_terracotta
fill 1 166 350 1 169 350 minecraft:honeycomb_block
setblock 1 166 354 minecraft:yellow_terracotta
fill 1 166 355 1 169 355 minecraft:honeycomb_block
setblock 1 166 359 minecraft:yellow_terracotta
fill 1 166 360 1 169 360 minecraft:honeycomb_block
setblock 2 166 323 minecraft:yellow_terracotta
setblock 2 166 338 minecraft:yellow_terracotta
fill 2 166 339 2 169 339 minecraft:honeycomb_block
setblock 2 166 342 minecraft:honeycomb_block
setblock 2 166 343 minecraft:yellow_terracotta
fill 2 166 344 2 169 344 minecraft:honeycomb_block
setblock 2 166 348 minecraft:yellow_terracotta
fill 2 166 349 2 169 349 minecraft:honeycomb_block
setblock 2 166 358 minecraft:yellow_terracotta
fill 2 166 359 2 168 359 minecraft:honeycomb_block
setblock 2 166 362 minecraft:honeycomb_block
setblock 2 166 363 minecraft:yellow_terracotta
fill 3 166 323 6 166 323 minecraft:honeycomb_block
setblock 3 166 337 minecraft:yellow_terracotta
fill 3 166 338 4 168 338 minecraft:honeycomb_block
setblock 3 166 342 minecraft:yellow_terracotta
fill 3 166 343 3 169 343 minecraft:honeycomb_block
setblock 3 166 346 minecraft:honeycomb_block
setblock 3 166 347 minecraft:yellow_terracotta
setblock 3 166 362 minecraft:yellow_terracotta
fill 3 166 363 3 169 363 minecraft:honeycomb_block
setblock 4 166 340 minecraft:honeycomb_block
setblock 4 166 341 minecraft:yellow_terracotta
fill 4 166 342 4 169 342 minecraft:honeycomb_block
fill 4 166 344 4 166 345 minecraft:honeycomb_block
fill 4 166 362 4 169 362 minecraft:honeycomb_block
setblock 5 166 324 minecraft:honeycomb_block
fill 5 166 341 5 169 341 minecraft:honeycomb_block
setblock 6 166 324 minecraft:yellow_terracotta
fill 6 166 361 7 167 361 minecraft:honeycomb_block
setblock 7 166 323 minecraft:yellow_terracotta
fill 7 166 324 10 166 324 minecraft:honeycomb_block
setblock 7 166 363 minecraft:yellow_terracotta
fill 8 166 323 8 169 323 minecraft:honeycomb_block
setblock 8 166 362 minecraft:yellow_terracotta
fill 8 166 363 8 169 363 minecraft:honeycomb_block
fill 9 166 362 9 169 362 minecraft:honeycomb_block
setblock 11 166 324 minecraft:yellow_terracotta
setblock 12 166 323 minecraft:yellow_terracotta
fill 12 166 324 13 168 324 minecraft:honeycomb_block
setblock 12 166 363 minecraft:yellow_terracotta
fill 13 166 323 16 166 323 minecraft:honeycomb_block
fill 13 166 363 13 169 363 minecraft:honeycomb_block
setblock 16 166 363 minecraft:honeycomb_block
setblock 17 166 323 minecraft:yellow_terracotta
setblock 17 166 363 minecraft:yellow_terracotta
fill 18 166 323 18 169 323 minecraft:honeycomb_block
fill 18 166 363 18 169 363 minecraft:honeycomb_block
fill 19 166 324 20 166 324 minecraft:honeycomb_block
fill 20 166 362 20 168 362 minecraft:honeycomb_block
setblock 21 166 323 minecraft:honeycomb_block
setblock 21 166 324 minecraft:yellow_terracotta
setblock 21 166 363 minecraft:honeycomb_block
setblock 22 166 323 minecraft:yellow_terracotta
fill 22 166 324 22 169 324 minecraft:honeycomb_block
setblock 22 166 362 minecraft:honeycomb_block
setblock 22 166 363 minecraft:yellow_terracotta
fill 23 166 323 23 169 323 minecraft:honeycomb_block
fill 23 166 325 24 166 325 minecraft:honeycomb_block
setblock 23 166 361 minecraft:honeycomb_block
setblock 23 166 362 minecraft:yellow_terracotta
fill 23 166 363 23 169 363 minecraft:honeycomb_block
setblock 24 166 361 minecraft:yellow_terracotta
fill 24 166 362 24 169 362 minecraft:honeycomb_block
setblock 25 166 325 minecraft:yellow_terracotta
fill 25 166 361 25 169 361 minecraft:honeycomb_block
fill 26 166 322 26 270 322 minecraft:honeycomb_block
schedule function dropper:buildpart/72_6 1t
