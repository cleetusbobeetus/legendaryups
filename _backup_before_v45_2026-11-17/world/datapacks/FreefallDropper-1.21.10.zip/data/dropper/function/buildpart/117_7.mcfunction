setblock 452 244 504 minecraft:polished_blackstone_bricks
fill 453 244 464 456 244 464 minecraft:blackstone
fill 453 244 501 454 244 501 minecraft:blackstone
setblock 453 244 503 minecraft:polished_blackstone_bricks
fill 453 244 504 456 244 504 minecraft:blackstone
setblock 454 244 502 minecraft:polished_blackstone_bricks
fill 454 244 503 457 244 503 minecraft:blackstone
setblock 455 244 501 minecraft:polished_blackstone_bricks
fill 455 244 502 458 244 502 minecraft:blackstone
setblock 456 244 501 minecraft:blackstone
setblock 457 244 464 minecraft:polished_blackstone_bricks
setblock 457 244 504 minecraft:polished_blackstone_bricks
fill 458 244 464 458 247 464 minecraft:blackstone
setblock 458 244 503 minecraft:polished_blackstone_bricks
fill 458 244 504 461 244 504 minecraft:blackstone
setblock 459 244 502 minecraft:polished_blackstone_bricks
fill 459 244 503 459 247 503 minecraft:blackstone
setblock 462 244 504 minecraft:polished_blackstone_bricks
fill 463 244 504 463 247 504 minecraft:blackstone
fill 464 244 479 464 244 481 minecraft:blackstone
setblock 464 244 482 minecraft:polished_blackstone_bricks
fill 464 244 483 464 247 483 minecraft:blackstone
setblock 464 244 486 minecraft:blackstone
setblock 464 244 502 minecraft:polished_blackstone_bricks
fill 424 245 477 424 245 480 minecraft:blackstone
setblock 424 245 481 minecraft:polished_blackstone_bricks
fill 424 245 482 424 248 482 minecraft:blackstone
setblock 424 245 486 minecraft:polished_blackstone_bricks
setblock 425 245 480 minecraft:polished_blackstone_bricks
fill 425 245 481 425 248 481 minecraft:blackstone
fill 425 245 483 425 246 483 minecraft:blackstone
fill 428 245 464 430 245 464 minecraft:blackstone
fill 429 245 504 430 245 504 minecraft:blackstone
setblock 431 245 464 minecraft:polished_blackstone_bricks
fill 431 245 465 434 245 465 minecraft:blackstone
setblock 431 245 504 minecraft:polished_blackstone_bricks
fill 432 245 464 435 245 464 minecraft:blackstone
setblock 432 245 503 minecraft:polished_blackstone_bricks
fill 432 245 504 435 245 504 minecraft:blackstone
fill 433 245 503 436 245 503 minecraft:blackstone
setblock 435 245 465 minecraft:polished_blackstone_bricks
setblock 436 245 464 minecraft:polished_blackstone_bricks
fill 436 245 465 436 248 465 minecraft:blackstone
setblock 436 245 504 minecraft:polished_blackstone_bricks
fill 437 245 464 440 245 464 minecraft:blackstone
setblock 437 245 503 minecraft:polished_blackstone_bricks
fill 437 245 504 440 245 504 minecraft:blackstone
fill 438 245 503 438 248 503 minecraft:blackstone
setblock 440 245 465 minecraft:polished_blackstone_bricks
setblock 441 245 464 minecraft:polished_blackstone_bricks
setblock 441 245 504 minecraft:polished_blackstone_bricks
fill 442 245 464 442 248 464 minecraft:blackstone
fill 442 245 504 445 245 504 minecraft:blackstone
fill 445 245 503 446 245 503 minecraft:blackstone
setblock 446 245 464 minecraft:polished_blackstone_bricks
setblock 446 245 504 minecraft:polished_blackstone_bricks
fill 447 245 464 450 245 464 minecraft:blackstone
setblock 447 245 503 minecraft:polished_blackstone_bricks
fill 447 245 504 450 245 504 minecraft:blackstone
fill 448 245 503 451 245 503 minecraft:blackstone
fill 449 245 502 452 245 502 minecraft:blackstone
setblock 451 245 464 minecraft:polished_blackstone_bricks
fill 451 245 465 454 245 465 minecraft:blackstone
setblock 451 245 504 minecraft:polished_blackstone_bricks
fill 452 245 464 455 245 464 minecraft:blackstone
setblock 452 245 503 minecraft:polished_blackstone_bricks
fill 452 245 504 455 245 504 minecraft:blackstone
setblock 453 245 501 minecraft:blackstone
setblock 453 245 502 minecraft:polished_blackstone_bricks
fill 453 245 503 456 245 503 minecraft:blackstone
setblock 454 245 501 minecraft:polished_blackstone_bricks
fill 454 245 502 457 245 502 minecraft:blackstone
fill 455 245 501 455 246 501 minecraft:blackstone
setblock 456 245 464 minecraft:polished_blackstone_bricks
setblock 456 245 504 minecraft:polished_blackstone_bricks
fill 457 245 464 457 248 464 minecraft:blackstone
setblock 457 245 503 minecraft:polished_blackstone_bricks
fill 457 245 504 460 245 504 minecraft:blackstone
setblock 458 245 502 minecraft:polished_blackstone_bricks
fill 458 245 503 458 248 503 minecraft:blackstone
fill 460 245 503 460 246 503 minecraft:blackstone
setblock 461 245 504 minecraft:polished_blackstone_bricks
fill 462 245 504 462 248 504 minecraft:blackstone
fill 464 245 479 464 245 480 minecraft:blackstone
setblock 464 245 481 minecraft:polished_blackstone_bricks
fill 464 245 482 464 248 482 minecraft:blackstone
setblock 464 245 486 minecraft:polished_blackstone_bricks
fill 464 245 487 464 248 487 minecraft:blackstone
setblock 464 245 502 minecraft:blackstone
fill 424 246 477 424 246 479 minecraft:blackstone
setblock 424 246 480 minecraft:polished_blackstone_bricks
fill 424 246 481 424 249 481 minecraft:blackstone
setblock 424 246 485 minecraft:polished_blackstone_bricks
fill 424 246 486 424 248 487 minecraft:blackstone
setblock 425 246 479 minecraft:polished_blackstone_bricks
fill 425 246 480 425 249 480 minecraft:blackstone
setblock 425 246 484 minecraft:polished_blackstone_bricks
fill 427 246 464 429 246 464 minecraft:blackstone
fill 428 246 504 429 246 504 minecraft:blackstone
setblock 429 246 465 minecraft:polished_blackstone_bricks
setblock 430 246 464 minecraft:polished_blackstone_bricks
fill 430 246 465 433 246 465 minecraft:blackstone
setblock 430 246 504 minecraft:polished_blackstone_bricks
fill 431 246 464 434 246 464 minecraft:blackstone
setblock 431 246 503 minecraft:polished_blackstone_bricks
fill 431 246 504 434 246 504 minecraft:blackstone
setblock 432 246 466 minecraft:blackstone
fill 432 246 503 435 246 503 minecraft:blackstone
setblock 433 246 466 minecraft:polished_blackstone_bricks
setblock 434 246 465 minecraft:polished_blackstone_bricks
fill 434 246 466 436 247 466 minecraft:blackstone
setblock 435 246 464 minecraft:polished_blackstone_bricks
fill 435 246 465 435 249 465 minecraft:blackstone
setblock 435 246 504 minecraft:polished_blackstone_bricks
fill 436 246 464 439 246 464 minecraft:blackstone
setblock 436 246 503 minecraft:polished_blackstone_bricks
fill 436 246 504 439 246 504 minecraft:blackstone
fill 437 246 503 437 249 503 minecraft:blackstone
setblock 439 246 465 minecraft:polished_blackstone_bricks
setblock 440 246 464 minecraft:polished_blackstone_bricks
fill 440 246 465 440 249 465 minecraft:blackstone
setblock 440 246 504 minecraft:polished_blackstone_bricks
fill 441 246 464 441 249 464 minecraft:blackstone
setblock 441 246 503 minecraft:polished_blackstone_bricks
fill 441 246 504 444 246 504 minecraft:blackstone
setblock 444 246 464 minecraft:blackstone
fill 444 246 503 445 246 503 minecraft:blackstone
setblock 445 246 464 minecraft:polished_blackstone_bricks
setblock 445 246 504 minecraft:polished_blackstone_bricks
fill 446 246 464 449 246 464 minecraft:blackstone
setblock 446 246 503 minecraft:polished_blackstone_bricks
fill 446 246 504 449 246 504 minecraft:blackstone
fill 447 246 503 450 246 503 minecraft:blackstone
fill 448 246 502 451 246 502 minecraft:blackstone
setblock 449 246 465 minecraft:polished_blackstone_bricks
setblock 450 246 464 minecraft:polished_blackstone_bricks
fill 450 246 465 453 246 465 minecraft:blackstone
setblock 450 246 504 minecraft:polished_blackstone_bricks
fill 451 246 464 454 246 464 minecraft:blackstone
setblock 451 246 503 minecraft:polished_blackstone_bricks
fill 451 246 504 454 246 504 minecraft:blackstone
setblock 452 246 501 minecraft:blackstone
setblock 452 246 502 minecraft:polished_blackstone_bricks
fill 452 246 503 455 246 503 minecraft:blackstone
setblock 453 246 501 minecraft:polished_blackstone_bricks
fill 453 246 502 456 246 502 minecraft:blackstone
setblock 454 246 465 minecraft:polished_blackstone_bricks
fill 454 246 501 454 248 501 minecraft:blackstone
setblock 455 246 464 minecraft:polished_blackstone_bricks
fill 455 246 465 455 249 465 minecraft:blackstone
setblock 455 246 504 minecraft:polished_blackstone_bricks
fill 456 246 464 456 249 464 minecraft:blackstone
setblock 456 246 503 minecraft:polished_blackstone_bricks
fill 456 246 504 459 246 504 minecraft:blackstone
setblock 457 246 502 minecraft:polished_blackstone_bricks
fill 457 246 503 457 249 503 minecraft:blackstone
setblock 458 246 502 minecraft:blackstone
setblock 459 246 464 minecraft:blackstone
setblock 460 246 504 minecraft:polished_blackstone_bricks
fill 461 246 504 461 249 504 minecraft:blackstone
fill 463 246 483 463 247 484 minecraft:blackstone
setblock 464 246 479 minecraft:blackstone
setblock 464 246 480 minecraft:polished_blackstone_bricks
fill 464 246 481 464 249 481 minecraft:blackstone
setblock 464 246 484 minecraft:blackstone
setblock 464 246 485 minecraft:polished_blackstone_bricks
fill 464 246 486 464 249 486 minecraft:blackstone
fill 464 246 488 464 247 488 minecraft:blackstone
fill 424 247 477 424 247 478 minecraft:blackstone
setblock 424 247 479 minecraft:polished_blackstone_bricks
fill 424 247 480 424 250 480 minecraft:blackstone
setblock 424 247 484 minecraft:polished_blackstone_bricks
fill 424 247 485 425 249 485 minecraft:blackstone
setblock 424 247 488 minecraft:blackstone
fill 425 247 464 428 247 464 minecraft:blackstone
fill 425 247 479 425 250 479 minecraft:blackstone
setblock 425 247 483 minecraft:polished_blackstone_bricks
fill 425 247 484 425 250 484 minecraft:blackstone
fill 425 247 486 425 248 486 minecraft:blackstone
fill 427 247 504 428 247 504 minecraft:blackstone
setblock 428 247 465 minecraft:polished_blackstone_bricks
fill 428 247 481 428 248 481 minecraft:polished_blackstone_bricks
fill 428 247 483 428 248 483 minecraft:polished_blackstone_bricks
setblock 429 247 464 minecraft:polished_blackstone_bricks
fill 429 247 465 432 247 465 minecraft:blackstone
setblock 429 247 504 minecraft:polished_blackstone_bricks
fill 430 247 464 433 247 464 minecraft:blackstone
fill 430 247 466 431 247 466 minecraft:blackstone
setblock 430 247 503 minecraft:polished_blackstone_bricks
fill 430 247 504 433 247 504 minecraft:blackstone
fill 431 247 503 434 247 503 minecraft:blackstone
setblock 432 247 466 minecraft:polished_blackstone_bricks
setblock 433 247 465 minecraft:polished_blackstone_bricks
fill 433 247 466 433 250 466 minecraft:blackstone
setblock 434 247 464 minecraft:polished_blackstone_bricks
fill 434 247 465 434 250 465 minecraft:blackstone
setblock 434 247 504 minecraft:polished_blackstone_bricks
fill 435 247 464 438 247 464 minecraft:blackstone
setblock 435 247 503 minecraft:polished_blackstone_bricks
fill 435 247 504 438 247 504 minecraft:blackstone
fill 436 247 503 436 250 503 minecraft:blackstone
setblock 437 247 466 minecraft:polished_blackstone_bricks
setblock 438 247 465 minecraft:polished_blackstone_bricks
setblock 439 247 464 minecraft:polished_blackstone_bricks
fill 439 247 465 439 250 465 minecraft:blackstone
setblock 439 247 504 minecraft:polished_blackstone_bricks
fill 440 247 464 440 250 464 minecraft:blackstone
setblock 440 247 503 minecraft:polished_blackstone_bricks
fill 440 247 504 443 247 504 minecraft:blackstone
fill 441 247 465 442 247 465 minecraft:blackstone
fill 441 247 503 444 247 503 minecraft:blackstone
setblock 444 247 464 minecraft:polished_blackstone_bricks
setblock 444 247 504 minecraft:polished_blackstone_bricks
fill 445 247 464 448 247 464 minecraft:blackstone
setblock 445 247 503 minecraft:polished_blackstone_bricks
fill 445 247 504 448 247 504 minecraft:blackstone
fill 446 247 465 447 247 465 minecraft:blackstone
fill 446 247 503 449 247 503 minecraft:blackstone
setblock 448 247 465 minecraft:polished_blackstone_bricks
fill 448 247 502 450 247 502 minecraft:blackstone
setblock 449 247 464 minecraft:polished_blackstone_bricks
fill 449 247 465 452 247 465 minecraft:blackstone
setblock 449 247 504 minecraft:polished_blackstone_bricks
fill 450 247 464 453 247 464 minecraft:blackstone
setblock 450 247 503 minecraft:polished_blackstone_bricks
fill 450 247 504 453 247 504 minecraft:blackstone
setblock 451 247 502 minecraft:polished_blackstone_bricks
fill 451 247 503 454 247 503 minecraft:blackstone
setblock 452 247 501 minecraft:polished_blackstone_bricks
fill 452 247 502 455 247 502 minecraft:blackstone
setblock 453 247 465 minecraft:polished_blackstone_bricks
fill 453 247 501 453 249 501 minecraft:blackstone
setblock 454 247 464 minecraft:polished_blackstone_bricks
fill 454 247 465 454 250 465 minecraft:blackstone
setblock 454 247 504 minecraft:polished_blackstone_bricks
fill 455 247 464 455 250 464 minecraft:blackstone
setblock 455 247 503 minecraft:polished_blackstone_bricks
fill 455 247 504 458 247 504 minecraft:blackstone
fill 456 247 465 456 248 465 minecraft:blackstone
setblock 456 247 502 minecraft:polished_blackstone_bricks
fill 456 247 503 456 250 503 minecraft:blackstone
fill 457 247 502 457 248 502 minecraft:blackstone
setblock 459 247 464 minecraft:polished_blackstone_bricks
setblock 459 247 504 minecraft:polished_blackstone_bricks
setblock 460 247 503 minecraft:polished_blackstone_bricks
fill 460 247 504 460 250 504 minecraft:blackstone
fill 463 247 482 463 249 482 minecraft:blackstone
setblock 463 247 485 minecraft:polished_blackstone_bricks
fill 463 247 486 463 250 486 minecraft:blackstone
setblock 464 247 479 minecraft:polished_blackstone_bricks
fill 464 247 480 464 250 480 minecraft:blackstone
setblock 464 247 484 minecraft:polished_blackstone_bricks
fill 464 247 485 464 250 485 minecraft:blackstone
setblock 464 247 489 minecraft:polished_blackstone_bricks
fill 464 247 490 464 250 490 minecraft:blackstone
setblock 464 247 503 minecraft:blackstone
fill 424 248 464 424 248 467 minecraft:blackstone
fill 424 248 476 424 248 477 minecraft:blackstone
setblock 424 248 478 minecraft:polished_blackstone_bricks
fill 424 248 479 424 251 479 minecraft:blackstone
setblock 424 248 483 minecraft:polished_blackstone_bricks
fill 424 248 484 424 251 484 minecraft:blackstone
setblock 424 248 488 minecraft:polished_blackstone_bricks
fill 424 248 489 424 251 489 minecraft:blackstone
fill 425 248 464 427 248 464 minecraft:blackstone
fill 425 248 476 430 248 476 minecraft:blackstone
fill 425 248 478 430 249 478 minecraft:blackstone
setblock 425 248 482 minecraft:polished_blackstone_bricks
fill 425 248 483 426 250 483 minecraft:blackstone
setblock 425 248 487 minecraft:polished_blackstone_bricks
setblock 426 248 465 minecraft:blackstone
setblock 426 248 466 minecraft:light[level=11]
fill 426 248 474 430 249 475 minecraft:blackstone
fill 426 248 477 430 249 477 minecraft:blackstone
setblock 426 248 481 minecraft:polished_blackstone_bricks
fill 426 248 482 426 251 482 minecraft:blackstone
fill 426 248 484 426 249 484 minecraft:blackstone
setblock 426 248 490 minecraft:light[level=11]
setblock 426 248 498 minecraft:light[level=11]
fill 426 248 504 427 248 504 minecraft:blackstone
setblock 427 248 465 minecraft:polished_blackstone_bricks
setblock 428 248 464 minecraft:polished_blackstone_bricks
fill 428 248 465 431 248 465 minecraft:blackstone
setblock 428 248 504 minecraft:polished_blackstone_bricks
fill 429 248 464 432 248 464 minecraft:blackstone
fill 429 248 466 430 248 466 minecraft:blackstone
setblock 429 248 503 minecraft:polished_blackstone_bricks
fill 429 248 504 432 248 504 minecraft:blackstone
fill 430 248 503 433 248 503 minecraft:blackstone
setblock 431 248 466 minecraft:polished_blackstone_bricks
setblock 432 248 465 minecraft:polished_blackstone_bricks
fill 432 248 466 432 251 466 minecraft:blackstone
setblock 433 248 464 minecraft:polished_blackstone_bricks
fill 433 248 465 433 251 465 minecraft:blackstone
fill 433 248 467 433 249 467 minecraft:blackstone
setblock 433 248 504 minecraft:polished_blackstone_bricks
fill 434 248 464 437 248 464 minecraft:blackstone
fill 434 248 466 435 248 466 minecraft:blackstone
setblock 434 248 474 minecraft:light[level=11]
setblock 434 248 482 minecraft:light[level=11]
setblock 434 248 490 minecraft:light[level=11]
setblock 434 248 498 minecraft:light[level=11]
setblock 434 248 503 minecraft:polished_blackstone_bricks
fill 434 248 504 437 248 504 minecraft:blackstone
fill 435 248 503 435 251 503 minecraft:blackstone
setblock 436 248 466 minecraft:polished_blackstone_bricks
setblock 437 248 465 minecraft:polished_blackstone_bricks
fill 437 248 466 438 250 466 minecraft:blackstone
setblock 438 248 464 minecraft:polished_blackstone_bricks
fill 438 248 465 438 251 465 minecraft:blackstone
setblock 438 248 504 minecraft:polished_blackstone_bricks
fill 439 248 464 439 251 464 minecraft:blackstone
setblock 439 248 503 minecraft:polished_blackstone_bricks
fill 439 248 504 442 248 504 minecraft:blackstone
fill 440 248 503 443 248 503 minecraft:blackstone
setblock 441 248 465 minecraft:blackstone
setblock 442 248 465 minecraft:polished_blackstone_bricks
setblock 442 248 466 minecraft:light[level=11]
setblock 442 248 474 minecraft:light[level=11]
setblock 442 248 482 minecraft:light[level=11]
setblock 442 248 490 minecraft:light[level=11]
setblock 442 248 498 minecraft:light[level=11]
setblock 443 248 464 minecraft:polished_blackstone_bricks
fill 443 248 465 446 248 465 minecraft:blackstone
setblock 443 248 504 minecraft:polished_blackstone_bricks
fill 444 248 464 447 248 464 minecraft:blackstone
setblock 444 248 503 minecraft:polished_blackstone_bricks
fill 444 248 504 447 248 504 minecraft:blackstone
fill 445 248 503 448 248 503 minecraft:blackstone
setblock 447 248 465 minecraft:polished_blackstone_bricks
fill 447 248 502 449 248 502 minecraft:blackstone
setblock 448 248 464 minecraft:polished_blackstone_bricks
fill 448 248 465 451 248 465 minecraft:blackstone
setblock 448 248 504 minecraft:polished_blackstone_bricks
fill 449 248 464 452 248 464 minecraft:blackstone
setblock 449 248 503 minecraft:polished_blackstone_bricks
fill 449 248 504 452 248 504 minecraft:blackstone
setblock 450 248 466 minecraft:light[level=11]
setblock 450 248 474 minecraft:light[level=11]
setblock 450 248 482 minecraft:light[level=11]
setblock 450 248 490 minecraft:light[level=11]
setblock 450 248 498 minecraft:light[level=11]
setblock 450 248 502 minecraft:polished_blackstone_bricks
fill 450 248 503 453 248 503 minecraft:blackstone
setblock 451 248 501 minecraft:polished_blackstone_bricks
fill 451 248 502 454 248 502 minecraft:blackstone
setblock 452 248 465 minecraft:polished_blackstone_bricks
fill 452 248 501 452 250 501 minecraft:blackstone
setblock 453 248 464 minecraft:polished_blackstone_bricks
fill 453 248 465 453 251 465 minecraft:blackstone
setblock 453 248 504 minecraft:polished_blackstone_bricks
fill 454 248 464 454 251 464 minecraft:blackstone
setblock 454 248 503 minecraft:polished_blackstone_bricks
fill 454 248 504 457 248 504 minecraft:blackstone
setblock 455 248 502 minecraft:polished_blackstone_bricks
fill 455 248 503 455 251 503 minecraft:blackstone
fill 456 248 502 456 250 502 minecraft:blackstone
setblock 458 248 464 minecraft:polished_blackstone_bricks
setblock 458 248 466 minecraft:light[level=11]
setblock 458 248 474 minecraft:light[level=11]
setblock 458 248 482 minecraft:light[level=11]
setblock 458 248 490 minecraft:light[level=11]
setblock 458 248 498 minecraft:light[level=11]
setblock 458 248 504 minecraft:polished_blackstone_bricks
fill 459 248 464 459 251 464 minecraft:blackstone
setblock 459 248 503 minecraft:polished_blackstone_bricks
fill 459 248 504 459 251 504 minecraft:blackstone
fill 463 248 481 463 250 481 minecraft:blackstone
setblock 463 248 483 minecraft:blackstone
setblock 463 248 484 minecraft:polished_blackstone_bricks
fill 463 248 485 463 251 485 minecraft:blackstone
fill 463 248 487 463 248 488 minecraft:blackstone
setblock 463 248 504 minecraft:polished_blackstone_bricks
fill 464 248 479 464 251 479 minecraft:blackstone
setblock 464 248 483 minecraft:polished_blackstone_bricks
fill 464 248 484 464 251 484 minecraft:blackstone
setblock 464 248 488 minecraft:polished_blackstone_bricks
fill 464 248 489 464 251 489 minecraft:blackstone
fill 464 248 491 464 249 491 minecraft:blackstone
setblock 464 248 503 minecraft:polished_blackstone_bricks
fill 464 248 504 464 251 504 minecraft:blackstone
fill 424 249 464 424 249 466 minecraft:blackstone
setblock 424 249 467 minecraft:polished_blackstone_bricks
fill 424 249 468 424 250 470 minecraft:blackstone
fill 424 249 475 424 249 476 minecraft:blackstone
setblock 424 249 477 minecraft:polished_blackstone_bricks
fill 424 249 478 424 252 478 minecraft:blackstone
setblock 424 249 482 minecraft:polished_blackstone_bricks
fill 424 249 483 424 252 483 minecraft:blackstone
setblock 424 249 486 minecraft:blackstone
setblock 424 249 487 minecraft:polished_blackstone_bricks
fill 424 249 488 425 251 488 minecraft:blackstone
fill 424 249 490 424 250 490 minecraft:blackstone
fill 425 249 464 425 249 465 minecraft:blackstone
setblock 425 249 466 minecraft:polished_blackstone_bricks
fill 425 249 467 425 252 467 minecraft:blackstone
setblock 425 249 481 minecraft:polished_blackstone_bricks
fill 425 249 482 425 252 482 minecraft:blackstone
setblock 425 249 486 minecraft:polished_blackstone_bricks
fill 425 249 487 425 252 487 minecraft:blackstone
fill 425 249 504 426 249 504 minecraft:blackstone
setblock 426 249 464 minecraft:blackstone
setblock 426 249 465 minecraft:polished_blackstone_bricks
fill 426 249 476 430 249 476 minecraft:blackstone
fill 426 249 481 426 252 481 minecraft:blackstone
setblock 426 249 485 minecraft:polished_blackstone_bricks
fill 426 249 486 426 252 486 minecraft:blackstone
setblock 427 249 464 minecraft:polished_blackstone_bricks
fill 427 249 465 429 249 466 minecraft:blackstone
setblock 427 249 504 minecraft:polished_blackstone_bricks
fill 428 249 464 431 249 464 minecraft:blackstone
setblock 428 249 503 minecraft:polished_blackstone_bricks
fill 428 249 504 431 249 504 minecraft:blackstone
fill 429 249 503 432 249 503 minecraft:blackstone
setblock 430 249 465 minecraft:blackstone
setblock 430 249 466 minecraft:polished_blackstone_bricks
fill 430 249 467 432 250 467 minecraft:blackstone
setblock 431 249 465 minecraft:polished_blackstone_bricks
fill 431 249 466 431 252 466 minecraft:blackstone
setblock 432 249 464 minecraft:polished_blackstone_bricks
fill 432 249 465 432 252 465 minecraft:blackstone
setblock 432 249 504 minecraft:polished_blackstone_bricks
fill 433 249 464 436 249 464 minecraft:blackstone
setblock 433 249 503 minecraft:polished_blackstone_bricks
fill 433 249 504 436 249 504 minecraft:blackstone
setblock 434 249 466 minecraft:blackstone
setblock 434 249 467 minecraft:polished_blackstone_bricks
fill 434 249 503 434 252 503 minecraft:blackstone
setblock 435 249 466 minecraft:polished_blackstone_bricks
fill 435 249 467 435 253 467 minecraft:blackstone
setblock 436 249 465 minecraft:polished_blackstone_bricks
fill 436 249 466 436 252 466 minecraft:blackstone
setblock 437 249 464 minecraft:polished_blackstone_bricks
fill 437 249 465 437 252 465 minecraft:blackstone
setblock 437 249 504 minecraft:polished_blackstone_bricks
fill 438 249 464 438 252 464 minecraft:blackstone
setblock 438 249 503 minecraft:polished_blackstone_bricks
fill 438 249 504 441 249 504 minecraft:blackstone
setblock 439 249 466 minecraft:blackstone
fill 439 249 503 442 249 503 minecraft:blackstone
setblock 441 249 465 minecraft:polished_blackstone_bricks
setblock 442 249 464 minecraft:polished_blackstone_bricks
fill 442 249 465 445 249 465 minecraft:blackstone
setblock 442 249 504 minecraft:polished_blackstone_bricks
fill 443 249 464 446 249 464 minecraft:blackstone
setblock 443 249 503 minecraft:polished_blackstone_bricks
fill 443 249 504 446 249 504 minecraft:blackstone
fill 444 249 503 447 249 503 minecraft:blackstone
setblock 446 249 465 minecraft:polished_blackstone_bricks
fill 446 249 502 448 249 502 minecraft:blackstone
setblock 447 249 464 minecraft:polished_blackstone_bricks
fill 447 249 465 450 249 465 minecraft:blackstone
setblock 447 249 504 minecraft:polished_blackstone_bricks
fill 448 249 464 451 249 464 minecraft:blackstone
fill 448 249 466 449 249 466 minecraft:blackstone
setblock 448 249 503 minecraft:polished_blackstone_bricks
fill 448 249 504 451 249 504 minecraft:blackstone
setblock 449 249 502 minecraft:polished_blackstone_bricks
fill 449 249 503 452 249 503 minecraft:blackstone
setblock 450 249 466 minecraft:polished_blackstone_bricks
fill 450 249 502 453 249 502 minecraft:blackstone
setblock 451 249 465 minecraft:polished_blackstone_bricks
fill 451 249 466 453 250 466 minecraft:blackstone
fill 451 249 501 451 250 501 minecraft:blackstone
setblock 452 249 464 minecraft:polished_blackstone_bricks
fill 452 249 465 452 252 465 minecraft:blackstone
setblock 452 249 504 minecraft:polished_blackstone_bricks
fill 453 249 464 453 252 464 minecraft:blackstone
setblock 453 249 503 minecraft:polished_blackstone_bricks
fill 453 249 504 456 249 504 minecraft:blackstone
setblock 454 249 502 minecraft:polished_blackstone_bricks
fill 454 249 503 454 252 503 minecraft:blackstone
fill 455 249 502 455 251 502 minecraft:blackstone
setblock 456 249 465 minecraft:polished_blackstone_bricks
setblock 457 249 464 minecraft:polished_blackstone_bricks
fill 457 249 465 457 250 465 minecraft:blackstone
setblock 457 249 504 minecraft:polished_blackstone_bricks
fill 458 249 464 458 252 464 minecraft:blackstone
setblock 458 249 503 minecraft:polished_blackstone_bricks
fill 458 249 504 458 252 504 minecraft:blackstone
setblock 459 249 503 minecraft:blackstone
fill 460 249 464 460 250 464 minecraft:blackstone
setblock 462 249 504 minecraft:polished_blackstone_bricks
setblock 463 249 483 minecraft:polished_blackstone_bricks
fill 463 249 484 463 252 484 minecraft:blackstone
setblock 463 249 487 minecraft:blackstone
setblock 463 249 488 minecraft:polished_blackstone_bricks
fill 463 249 489 463 252 489 minecraft:blackstone
fill 463 249 504 463 251 504 minecraft:blackstone
fill 464 249 478 464 252 478 minecraft:blackstone
setblock 464 249 482 minecraft:polished_blackstone_bricks
fill 464 249 483 464 252 483 minecraft:blackstone
setblock 464 249 487 minecraft:polished_blackstone_bricks
fill 464 249 488 464 252 488 minecraft:blackstone
setblock 464 249 492 minecraft:polished_blackstone_bricks
fill 464 249 503 464 250 503 minecraft:blackstone
fill 424 250 464 424 250 465 minecraft:blackstone
setblock 424 250 466 minecraft:polished_blackstone_bricks
fill 424 250 467 424 253 467 minecraft:blackstone
setblock 424 250 471 minecraft:polished_blackstone_bricks
fill 424 250 472 424 250 475 minecraft:blackstone
setblock 424 250 476 minecraft:polished_blackstone_bricks
fill 424 250 477 424 253 477 minecraft:blackstone
setblock 424 250 481 minecraft:polished_blackstone_bricks
fill 424 250 482 424 253 482 minecraft:blackstone
setblock 424 250 485 minecraft:blackstone
setblock 424 250 486 minecraft:polished_blackstone_bricks
fill 424 250 487 424 253 487 minecraft:blackstone
setblock 424 250 491 minecraft:polished_blackstone_bricks
fill 424 250 504 425 250 504 minecraft:blackstone
setblock 425 250 464 minecraft:blackstone
setblock 425 250 465 minecraft:polished_blackstone_bricks
fill 425 250 466 428 250 466 minecraft:blackstone
fill 425 250 468 425 250 469 minecraft:blackstone
setblock 425 250 470 minecraft:polished_blackstone_bricks
fill 425 250 478 425 251 478 minecraft:blackstone
setblock 425 250 480 minecraft:polished_blackstone_bricks
fill 425 250 481 425 253 481 minecraft:blackstone
setblock 425 250 485 minecraft:polished_blackstone_bricks
fill 425 250 486 425 253 486 minecraft:blackstone
setblock 425 250 489 minecraft:blackstone
setblock 426 250 464 minecraft:polished_blackstone_bricks
fill 426 250 465 429 250 465 minecraft:blackstone
fill 426 250 467 426 251 467 minecraft:blackstone
setblock 426 250 480 minecraft:blackstone
setblock 426 250 484 minecraft:polished_blackstone_bricks
fill 426 250 485 426 253 485 minecraft:blackstone
fill 426 250 487 426 251 487 minecraft:blackstone
setblock 426 250 504 minecraft:polished_blackstone_bricks
fill 427 250 464 430 250 464 minecraft:blackstone
fill 427 250 476 429 256 476 minecraft:polished_blackstone_bricks
fill 427 250 504 430 250 504 minecraft:blackstone
setblock 428 250 467 minecraft:polished_blackstone_bricks
fill 428 250 475 428 256 475 minecraft:polished_blackstone_bricks
fill 428 250 477 428 256 477 minecraft:polished_blackstone_bricks
fill 428 250 503 431 250 503 minecraft:blackstone
setblock 429 250 466 minecraft:polished_blackstone_bricks
fill 429 250 467 429 253 467 minecraft:blackstone
setblock 430 250 465 minecraft:polished_blackstone_bricks
fill 430 250 466 430 253 466 minecraft:blackstone
setblock 431 250 464 minecraft:polished_blackstone_bricks
fill 431 250 465 431 253 465 minecraft:blackstone
setblock 431 250 504 minecraft:polished_blackstone_bricks
fill 432 250 464 435 250 464 minecraft:blackstone
setblock 432 250 503 minecraft:polished_blackstone_bricks
fill 432 250 504 435 250 504 minecraft:blackstone
setblock 433 250 467 minecraft:polished_blackstone_bricks
fill 433 250 503 433 253 503 minecraft:blackstone
setblock 434 250 466 minecraft:polished_blackstone_bricks
fill 434 250 467 434 253 467 minecraft:blackstone
setblock 435 250 465 minecraft:polished_blackstone_bricks
fill 435 250 466 435 253 466 minecraft:blackstone
setblock 436 250 464 minecraft:polished_blackstone_bricks
fill 436 250 465 436 253 465 minecraft:blackstone
setblock 436 250 504 minecraft:polished_blackstone_bricks
fill 437 250 464 437 253 464 minecraft:blackstone
setblock 437 250 503 minecraft:polished_blackstone_bricks
fill 437 250 504 440 250 504 minecraft:blackstone
fill 438 250 503 441 250 503 minecraft:blackstone
setblock 439 250 466 minecraft:polished_blackstone_bricks
setblock 440 250 465 minecraft:polished_blackstone_bricks
setblock 441 250 464 minecraft:polished_blackstone_bricks
fill 441 250 465 444 250 465 minecraft:blackstone
setblock 441 250 504 minecraft:polished_blackstone_bricks
fill 442 250 464 445 250 464 minecraft:blackstone
setblock 442 250 503 minecraft:polished_blackstone_bricks
fill 442 250 504 445 250 504 minecraft:blackstone
fill 443 250 503 446 250 503 minecraft:blackstone
setblock 445 250 465 minecraft:polished_blackstone_bricks
setblock 446 250 464 minecraft:polished_blackstone_bricks
fill 446 250 465 448 250 466 minecraft:blackstone
fill 446 250 502 447 250 502 minecraft:blackstone
setblock 446 250 504 minecraft:polished_blackstone_bricks
fill 447 250 464 450 250 464 minecraft:blackstone
setblock 447 250 503 minecraft:polished_blackstone_bricks
fill 447 250 504 450 250 504 minecraft:blackstone
setblock 448 250 502 minecraft:polished_blackstone_bricks
fill 448 250 503 451 250 503 minecraft:blackstone
setblock 449 250 465 minecraft:blackstone
setblock 449 250 466 minecraft:polished_blackstone_bricks
fill 449 250 502 452 250 502 minecraft:blackstone
setblock 450 250 465 minecraft:polished_blackstone_bricks
fill 450 250 466 450 253 466 minecraft:blackstone
setblock 451 250 464 minecraft:polished_blackstone_bricks
fill 451 250 465 451 253 465 minecraft:blackstone
setblock 451 250 504 minecraft:polished_blackstone_bricks
fill 452 250 464 452 253 464 minecraft:blackstone
setblock 452 250 503 minecraft:polished_blackstone_bricks
fill 452 250 504 455 250 504 minecraft:blackstone
setblock 453 250 502 minecraft:polished_blackstone_bricks
fill 453 250 503 453 253 503 minecraft:blackstone
fill 454 250 502 454 251 502 minecraft:blackstone
setblock 455 250 465 minecraft:polished_blackstone_bricks
setblock 456 250 464 minecraft:polished_blackstone_bricks
fill 456 250 465 456 252 465 minecraft:blackstone
setblock 456 250 504 minecraft:polished_blackstone_bricks
fill 457 250 464 457 253 464 minecraft:blackstone
setblock 457 250 503 minecraft:polished_blackstone_bricks
fill 457 250 504 457 253 504 minecraft:blackstone
setblock 458 250 503 minecraft:blackstone
setblock 461 250 464 minecraft:polished_blackstone_bricks
setblock 461 250 504 minecraft:polished_blackstone_bricks
fill 462 250 464 464 251 464 minecraft:blackstone
fill 462 250 485 462 250 487 minecraft:blackstone
setblock 462 250 488 minecraft:cyan_stained_glass
fill 462 250 504 462 251 504 minecraft:blackstone
setblock 463 250 482 minecraft:polished_blackstone_bricks
fill 463 250 483 463 253 483 minecraft:blackstone
setblock 463 250 487 minecraft:polished_blackstone_bricks
fill 463 250 488 463 253 488 minecraft:blackstone
fill 463 250 490 463 251 490 minecraft:blackstone
setblock 464 250 465 minecraft:blackstone
setblock 464 250 466 minecraft:polished_blackstone_bricks
fill 464 250 467 464 253 467 minecraft:blackstone
setblock 464 250 481 minecraft:polished_blackstone_bricks
fill 464 250 482 464 253 482 minecraft:blackstone
setblock 464 250 486 minecraft:polished_blackstone_bricks
fill 464 250 487 464 253 487 minecraft:blackstone
setblock 464 250 491 minecraft:polished_blackstone_bricks
fill 464 250 492 464 252 493 minecraft:blackstone
setblock 424 251 464 minecraft:blackstone
setblock 424 251 465 minecraft:polished_blackstone_bricks
fill 424 251 466 427 251 466 minecraft:blackstone
fill 424 251 468 424 251 469 minecraft:blackstone
setblock 424 251 470 minecraft:polished_blackstone_bricks
fill 424 251 471 424 251 474 minecraft:blackstone
setblock 424 251 475 minecraft:polished_blackstone_bricks
fill 424 251 476 424 254 476 minecraft:blackstone
setblock 424 251 480 minecraft:polished_blackstone_bricks
fill 424 251 481 424 254 481 minecraft:blackstone
setblock 424 251 485 minecraft:polished_blackstone_bricks
fill 424 251 486 424 254 486 minecraft:blackstone
setblock 424 251 490 minecraft:polished_blackstone_bricks
fill 424 251 491 424 253 492 minecraft:blackstone
setblock 424 251 504 minecraft:blackstone
setblock 425 251 464 minecraft:polished_blackstone_bricks
fill 425 251 465 428 251 465 minecraft:blackstone
setblock 425 251 468 minecraft:blackstone
setblock 425 251 469 minecraft:polished_blackstone_bricks
fill 425 251 470 425 251 473 minecraft:blackstone
fill 425 251 477 425 252 477 minecraft:blackstone
setblock 425 251 479 minecraft:polished_blackstone_bricks
fill 425 251 480 425 254 480 minecraft:blackstone
setblock 425 251 483 minecraft:blackstone
setblock 425 251 484 minecraft:polished_blackstone_bricks
fill 425 251 485 425 254 485 minecraft:blackstone
setblock 425 251 489 minecraft:polished_blackstone_bricks
fill 425 251 490 425 254 490 minecraft:blackstone
setblock 425 251 504 minecraft:polished_blackstone_bricks
fill 426 251 464 429 251 464 minecraft:blackstone
setblock 426 251 468 minecraft:polished_blackstone_bricks
fill 426 251 469 426 253 470 minecraft:blackstone
setblock 426 251 483 minecraft:polished_blackstone_bricks
fill 426 251 484 426 253 484 minecraft:blackstone
setblock 426 251 488 minecraft:polished_blackstone_bricks
fill 426 251 504 429 251 504 minecraft:blackstone
setblock 427 251 467 minecraft:polished_blackstone_bricks
setblock 428 251 466 minecraft:polished_blackstone_bricks
fill 428 251 467 428 254 467 minecraft:blackstone
fill 428 251 503 430 251 503 minecraft:blackstone
setblock 429 251 465 minecraft:polished_blackstone_bricks
fill 429 251 466 429 254 466 minecraft:blackstone
setblock 430 251 464 minecraft:polished_blackstone_bricks
fill 430 251 465 430 254 465 minecraft:blackstone
fill 430 251 467 431 251 467 minecraft:blackstone
fill 430 251 468 433 252 469 minecraft:polished_blackstone_bricks
setblock 430 251 504 minecraft:polished_blackstone_bricks
fill 431 251 464 434 251 464 minecraft:blackstone
setblock 431 251 503 minecraft:polished_blackstone_bricks
fill 431 251 504 434 251 504 minecraft:blackstone
setblock 432 251 467 minecraft:polished_blackstone_bricks
fill 432 251 503 432 253 503 minecraft:blackstone
setblock 433 251 466 minecraft:polished_blackstone_bricks
fill 433 251 467 433 254 467 minecraft:blackstone
setblock 434 251 465 minecraft:polished_blackstone_bricks
fill 434 251 466 434 254 466 minecraft:blackstone
setblock 435 251 464 minecraft:polished_blackstone_bricks
fill 435 251 465 435 254 465 minecraft:blackstone
setblock 435 251 504 minecraft:polished_blackstone_bricks
fill 436 251 464 436 254 464 minecraft:blackstone
setblock 436 251 503 minecraft:polished_blackstone_bricks
fill 436 251 504 439 251 504 minecraft:blackstone
setblock 437 251 466 minecraft:blackstone
fill 437 251 503 440 251 503 minecraft:blackstone
setblock 438 251 466 minecraft:polished_blackstone_bricks
setblock 439 251 465 minecraft:polished_blackstone_bricks
fill 439 251 466 439 252 466 minecraft:blackstone
setblock 440 251 464 minecraft:polished_blackstone_bricks
fill 440 251 465 443 251 465 minecraft:blackstone
setblock 440 251 504 minecraft:polished_blackstone_bricks
fill 441 251 464 444 251 464 minecraft:blackstone
setblock 441 251 503 minecraft:polished_blackstone_bricks
fill 441 251 504 444 251 504 minecraft:blackstone
fill 442 251 503 445 251 503 minecraft:blackstone
setblock 444 251 465 minecraft:polished_blackstone_bricks
setblock 445 251 464 minecraft:polished_blackstone_bricks
fill 445 251 465 447 251 466 minecraft:blackstone
setblock 445 251 504 minecraft:polished_blackstone_bricks
fill 446 251 464 449 251 464 minecraft:blackstone
setblock 446 251 502 minecraft:blackstone
setblock 446 251 503 minecraft:polished_blackstone_bricks
fill 446 251 504 449 251 504 minecraft:blackstone
setblock 447 251 502 minecraft:polished_blackstone_bricks
fill 447 251 503 450 251 503 minecraft:blackstone
setblock 448 251 465 minecraft:blackstone
setblock 448 251 466 minecraft:polished_blackstone_bricks
fill 448 251 502 451 251 502 minecraft:blackstone
setblock 449 251 465 minecraft:polished_blackstone_bricks
fill 449 251 466 449 254 466 minecraft:blackstone
setblock 450 251 464 minecraft:polished_blackstone_bricks
fill 450 251 465 450 254 465 minecraft:blackstone
setblock 450 251 504 minecraft:polished_blackstone_bricks
fill 451 251 464 451 254 464 minecraft:blackstone
fill 451 251 466 452 251 466 minecraft:blackstone
setblock 451 251 503 minecraft:polished_blackstone_bricks
fill 451 251 504 454 251 504 minecraft:blackstone
setblock 452 251 502 minecraft:polished_blackstone_bricks
fill 452 251 503 452 254 503 minecraft:blackstone
setblock 453 251 466 minecraft:polished_blackstone_bricks
fill 453 251 502 453 252 502 minecraft:blackstone
setblock 454 251 465 minecraft:polished_blackstone_bricks
setblock 455 251 464 minecraft:polished_blackstone_bricks
fill 455 251 465 455 253 465 minecraft:blackstone
setblock 455 251 504 minecraft:polished_blackstone_bricks
fill 456 251 464 456 254 464 minecraft:blackstone
setblock 456 251 503 minecraft:polished_blackstone_bricks
fill 456 251 504 456 253 504 minecraft:blackstone
setblock 457 251 503 minecraft:blackstone
setblock 460 251 464 minecraft:polished_blackstone_bricks
setblock 460 251 504 minecraft:polished_blackstone_bricks
setblock 461 251 464 minecraft:blackstone
setblock 461 251 504 minecraft:blackstone
fill 462 251 484 462 251 486 minecraft:blackstone
setblock 462 251 487 minecraft:polished_blackstone_bricks
fill 462 251 488 462 254 488 minecraft:blackstone
setblock 463 251 481 minecraft:polished_blackstone_bricks
fill 463 251 482 463 254 482 minecraft:blackstone
setblock 463 251 486 minecraft:polished_blackstone_bricks
fill 463 251 487 463 254 487 minecraft:blackstone
setblock 463 251 491 minecraft:polished_blackstone_bricks
setblock 464 251 465 minecraft:polished_blackstone_bricks
fill 464 251 466 464 254 466 minecraft:blackstone
fill 464 251 468 464 251 469 minecraft:blackstone
fill 464 251 477 464 253 477 minecraft:blackstone
setblock 464 251 480 minecraft:polished_blackstone_bricks
fill 464 251 481 464 254 481 minecraft:blackstone
setblock 464 251 485 minecraft:polished_blackstone_bricks
fill 464 251 486 464 254 486 minecraft:blackstone
setblock 464 251 490 minecraft:polished_blackstone_bricks
fill 464 251 491 464 254 491 minecraft:blackstone
setblock 464 251 494 minecraft:blackstone
setblock 424 252 464 minecraft:polished_blackstone_bricks
fill 424 252 465 426 252 466 minecraft:blackstone
setblock 424 252 468 minecraft:blackstone
setblock 424 252 469 minecraft:polished_blackstone_bricks
fill 424 252 470 424 252 473 minecraft:blackstone
setblock 424 252 474 minecraft:polished_blackstone_bricks
fill 424 252 475 425 254 475 minecraft:blackstone
setblock 424 252 479 minecraft:polished_blackstone_bricks
fill 424 252 480 424 255 480 minecraft:blackstone
setblock 424 252 484 minecraft:polished_blackstone_bricks
fill 424 252 485 424 255 485 minecraft:blackstone
setblock 424 252 488 minecraft:blackstone
setblock 424 252 489 minecraft:polished_blackstone_bricks
fill 424 252 490 424 255 490 minecraft:blackstone
setblock 424 252 504 minecraft:polished_blackstone_bricks
fill 425 252 464 428 252 464 minecraft:blackstone
setblock 425 252 468 minecraft:polished_blackstone_bricks
fill 425 252 469 425 252 472 minecraft:blackstone
setblock 425 252 473 minecraft:polished_blackstone_bricks
fill 425 252 474 425 255 474 minecraft:blackstone
fill 425 252 476 425 253 476 minecraft:blackstone
setblock 425 252 478 minecraft:polished_blackstone_bricks
fill 425 252 479 425 253 479 minecraft:blackstone
setblock 425 252 483 minecraft:polished_blackstone_bricks
fill 425 252 484 425 255 484 minecraft:blackstone
setblock 425 252 488 minecraft:polished_blackstone_bricks
fill 425 252 489 425 255 489 minecraft:blackstone
fill 425 252 504 428 252 504 minecraft:blackstone
setblock 426 252 467 minecraft:polished_blackstone_bricks
fill 426 252 468 427 254 468 minecraft:blackstone
setblock 426 252 471 minecraft:blackstone
setblock 426 252 482 minecraft:polished_blackstone_bricks
fill 426 252 483 426 253 483 minecraft:blackstone
setblock 426 252 487 minecraft:polished_blackstone_bricks
fill 426 252 488 426 254 488 minecraft:blackstone
setblock 427 252 465 minecraft:blackstone
setblock 427 252 466 minecraft:polished_blackstone_bricks
fill 427 252 467 427 255 467 minecraft:blackstone
fill 427 252 469 427 253 469 minecraft:blackstone
setblock 428 252 465 minecraft:polished_blackstone_bricks
fill 428 252 466 428 255 466 minecraft:blackstone
fill 428 252 503 429 252 503 minecraft:blackstone
setblock 429 252 464 minecraft:polished_blackstone_bricks
fill 429 252 465 429 255 465 minecraft:blackstone
fill 429 252 468 429 253 469 minecraft:blackstone
setblock 429 252 504 minecraft:polished_blackstone_bricks
fill 430 252 464 433 252 464 minecraft:blackstone
setblock 430 252 467 minecraft:blackstone
fill 430 252 470 433 253 470 minecraft:blackstone
setblock 430 252 503 minecraft:polished_blackstone_bricks
fill 430 252 504 433 252 504 minecraft:blackstone
setblock 431 252 467 minecraft:polished_blackstone_bricks
fill 431 252 503 431 254 503 minecraft:blackstone
setblock 432 252 466 minecraft:polished_blackstone_bricks
fill 432 252 467 432 255 467 minecraft:blackstone
setblock 433 252 465 minecraft:polished_blackstone_bricks
fill 433 252 466 433 255 466 minecraft:blackstone
setblock 434 252 464 minecraft:polished_blackstone_bricks
fill 434 252 465 434 255 465 minecraft:blackstone
fill 434 252 468 434 253 469 minecraft:blackstone
setblock 434 252 504 minecraft:polished_blackstone_bricks
fill 435 252 464 435 255 464 minecraft:blackstone
setblock 435 252 503 minecraft:polished_blackstone_bricks
fill 435 252 504 438 252 504 minecraft:blackstone
setblock 436 252 503 minecraft:blackstone
setblock 437 252 466 minecraft:polished_blackstone_bricks
setblock 438 252 465 minecraft:polished_blackstone_bricks
fill 438 252 466 438 253 466 minecraft:blackstone
setblock 439 252 464 minecraft:polished_blackstone_bricks
fill 439 252 465 442 252 465 minecraft:blackstone
setblock 439 252 504 minecraft:polished_blackstone_bricks
fill 440 252 464 443 252 464 minecraft:blackstone
fill 440 252 504 443 252 504 minecraft:blackstone
fill 442 252 503 444 252 503 minecraft:blackstone
setblock 443 252 465 minecraft:polished_blackstone_bricks
setblock 444 252 464 minecraft:polished_blackstone_bricks
fill 444 252 465 446 252 466 minecraft:blackstone
setblock 444 252 504 minecraft:polished_blackstone_bricks
fill 445 252 464 448 252 464 minecraft:blackstone
setblock 445 252 503 minecraft:polished_blackstone_bricks
fill 445 252 504 448 252 504 minecraft:blackstone
setblock 446 252 502 minecraft:polished_blackstone_bricks
fill 446 252 503 449 252 503 minecraft:blackstone
setblock 447 252 465 minecraft:blackstone
setblock 447 252 466 minecraft:polished_blackstone_bricks
fill 447 252 502 450 252 502 minecraft:blackstone
setblock 448 252 465 minecraft:polished_blackstone_bricks
fill 448 252 466 448 255 466 minecraft:blackstone
setblock 449 252 464 minecraft:polished_blackstone_bricks
fill 449 252 465 449 255 465 minecraft:blackstone
setblock 449 252 504 minecraft:polished_blackstone_bricks
fill 450 252 464 450 255 464 minecraft:blackstone
setblock 450 252 503 minecraft:polished_blackstone_bricks
fill 450 252 504 453 252 504 minecraft:blackstone
setblock 451 252 466 minecraft:blackstone
setblock 451 252 502 minecraft:polished_blackstone_bricks
fill 451 252 503 451 255 503 minecraft:blackstone
setblock 452 252 466 minecraft:polished_blackstone_bricks
fill 452 252 502 452 253 502 minecraft:blackstone
setblock 453 252 465 minecraft:polished_blackstone_bricks
setblock 453 252 466 minecraft:blackstone
setblock 454 252 464 minecraft:polished_blackstone_bricks
fill 454 252 465 454 253 465 minecraft:blackstone
setblock 454 252 504 minecraft:polished_blackstone_bricks
fill 455 252 464 455 254 464 minecraft:blackstone
setblock 455 252 503 minecraft:polished_blackstone_bricks
fill 455 252 504 455 254 504 minecraft:blackstone
setblock 456 252 503 minecraft:blackstone
setblock 459 252 464 minecraft:polished_blackstone_bricks
setblock 459 252 504 minecraft:polished_blackstone_bricks
fill 462 252 464 463 252 464 minecraft:blackstone
setblock 462 252 485 minecraft:blackstone
setblock 462 252 486 minecraft:polished_blackstone_bricks
fill 462 252 487 462 254 487 minecraft:blackstone
fill 462 252 489 462 253 489 minecraft:blackstone
setblock 463 252 481 minecraft:blackstone
setblock 463 252 485 minecraft:polished_blackstone_bricks
fill 463 252 486 463 255 486 minecraft:blackstone
setblock 463 252 490 minecraft:polished_blackstone_bricks
fill 463 252 491 463 254 492 minecraft:blackstone
setblock 464 252 464 minecraft:polished_blackstone_bricks
fill 464 252 465 464 255 465 minecraft:blackstone
setblock 464 252 468 minecraft:blackstone
setblock 464 252 469 minecraft:polished_blackstone_bricks
fill 464 252 470 464 253 472 minecraft:blackstone
setblock 464 252 479 minecraft:polished_blackstone_bricks
fill 464 252 480 464 255 480 minecraft:blackstone
setblock 464 252 484 minecraft:polished_blackstone_bricks
fill 464 252 485 464 255 485 minecraft:blackstone
setblock 464 252 489 minecraft:polished_blackstone_bricks
fill 464 252 490 464 255 490 minecraft:blackstone
setblock 464 252 494 minecraft:polished_blackstone_bricks
fill 464 252 495 464 255 495 minecraft:blackstone
fill 424 253 464 425 253 466 minecraft:blackstone
setblock 424 253 468 minecraft:polished_blackstone_bricks
fill 424 253 469 424 253 472 minecraft:blackstone
setblock 424 253 473 minecraft:polished_blackstone_bricks
fill 424 253 474 424 256 474 minecraft:blackstone
setblock 424 253 478 minecraft:polished_blackstone_bricks
fill 424 253 479 424 256 479 minecraft:blackstone
setblock 424 253 483 minecraft:polished_blackstone_bricks
fill 424 253 484 424 256 484 minecraft:blackstone
setblock 424 253 488 minecraft:polished_blackstone_bricks
fill 424 253 489 424 256 489 minecraft:blackstone
setblock 424 253 493 minecraft:polished_blackstone_bricks
setblock 425 253 467 minecraft:polished_blackstone_bricks
fill 425 253 468 425 253 471 minecraft:blackstone
setblock 425 253 472 minecraft:polished_blackstone_bricks
fill 425 253 473 425 256 473 minecraft:blackstone
setblock 425 253 477 minecraft:polished_blackstone_bricks
setblock 425 253 478 minecraft:blackstone
setblock 425 253 482 minecraft:polished_blackstone_bricks
fill 425 253 483 425 255 483 minecraft:blackstone
setblock 425 253 487 minecraft:polished_blackstone_bricks
fill 425 253 488 425 256 488 minecraft:blackstone
setblock 425 253 491 minecraft:blackstone
fill 425 253 504 427 253 504 minecraft:blackstone
fill 426 253 464 426 253 465 minecraft:blackstone
setblock 426 253 466 minecraft:polished_blackstone_bricks
fill 426 253 467 426 256 467 minecraft:blackstone
setblock 426 253 471 minecraft:polished_blackstone_bricks
fill 426 253 472 426 256 472 minecraft:blackstone
setblock 426 253 486 minecraft:polished_blackstone_bricks
fill 426 253 487 426 254 487 minecraft:blackstone
setblock 427 253 464 minecraft:blackstone
setblock 427 253 465 minecraft:polished_blackstone_bricks
fill 427 253 466 427 256 466 minecraft:blackstone
setblock 427 253 470 minecraft:polished_blackstone_bricks
setblock 428 253 464 minecraft:polished_blackstone_bricks
fill 428 253 465 428 256 465 minecraft:blackstone
fill 428 253 468 428 253 469 minecraft:blackstone
setblock 428 253 503 minecraft:blackstone
setblock 428 253 504 minecraft:polished_blackstone_bricks
fill 429 253 464 432 253 464 minecraft:blackstone
setblock 429 253 470 minecraft:blackstone
setblock 429 253 503 minecraft:polished_blackstone_bricks
fill 429 253 504 432 253 504 minecraft:blackstone
setblock 430 253 467 minecraft:polished_blackstone_bricks
setblock 430 253 468 minecraft:blackstone
fill 430 253 469 433 273 469 minecraft:polished_blackstone_bricks
fill 430 253 471 433 253 471 minecraft:blackstone
fill 430 253 503 430 254 503 minecraft:blackstone
setblock 431 253 466 minecraft:polished_blackstone_bricks
fill 431 253 467 431 256 467 minecraft:blackstone
fill 431 253 468 433 273 468 minecraft:polished_blackstone_bricks
setblock 432 253 465 minecraft:polished_blackstone_bricks
fill 432 253 466 432 256 466 minecraft:blackstone
setblock 433 253 464 minecraft:polished_blackstone_bricks
fill 433 253 465 433 256 465 minecraft:blackstone
setblock 433 253 504 minecraft:polished_blackstone_bricks
fill 434 253 464 434 256 464 minecraft:blackstone
setblock 434 253 470 minecraft:blackstone
setblock 434 253 503 minecraft:polished_blackstone_bricks
fill 434 253 504 437 253 504 minecraft:blackstone
fill 435 253 468 435 253 469 minecraft:blackstone
setblock 436 253 466 minecraft:polished_blackstone_bricks
setblock 437 253 465 minecraft:polished_blackstone_bricks
setblock 437 253 466 minecraft:blackstone
setblock 438 253 464 minecraft:polished_blackstone_bricks
fill 438 253 465 441 253 465 minecraft:blackstone
setblock 438 253 504 minecraft:polished_blackstone_bricks
fill 439 253 464 442 253 464 minecraft:blackstone
fill 439 253 504 442 253 504 minecraft:blackstone
setblock 442 253 465 minecraft:polished_blackstone_bricks
setblock 443 253 464 minecraft:polished_blackstone_bricks
fill 443 253 465 446 253 465 minecraft:blackstone
setblock 443 253 503 minecraft:blackstone
setblock 443 253 504 minecraft:polished_blackstone_bricks
fill 444 253 464 447 253 464 minecraft:blackstone
fill 444 253 466 445 253 466 minecraft:blackstone
setblock 444 253 503 minecraft:polished_blackstone_bricks
fill 444 253 504 447 253 504 minecraft:blackstone
fill 445 253 503 448 253 503 minecraft:blackstone
setblock 446 253 466 minecraft:polished_blackstone_bricks
setblock 447 253 465 minecraft:polished_blackstone_bricks
fill 447 253 466 447 255 466 minecraft:blackstone
fill 447 253 502 449 253 502 minecraft:blackstone
setblock 448 253 464 minecraft:polished_blackstone_bricks
fill 448 253 465 448 256 465 minecraft:blackstone
setblock 448 253 504 minecraft:polished_blackstone_bricks
fill 449 253 464 449 256 464 minecraft:blackstone
setblock 449 253 503 minecraft:polished_blackstone_bricks
fill 449 253 504 452 253 504 minecraft:blackstone
setblock 450 253 502 minecraft:polished_blackstone_bricks
fill 450 253 503 450 256 503 minecraft:blackstone
setblock 451 253 466 minecraft:polished_blackstone_bricks
setblock 451 253 502 minecraft:blackstone
setblock 452 253 465 minecraft:polished_blackstone_bricks
setblock 452 253 466 minecraft:blackstone
setblock 453 253 464 minecraft:polished_blackstone_bricks
fill 453 253 465 453 254 465 minecraft:blackstone
setblock 453 253 504 minecraft:polished_blackstone_bricks
fill 454 253 464 454 255 464 minecraft:blackstone
setblock 454 253 503 minecraft:polished_blackstone_bricks
fill 454 253 504 454 255 504 minecraft:blackstone
setblock 462 253 486 minecraft:blackstone
setblock 463 253 464 minecraft:polished_blackstone_bricks
setblock 463 253 484 minecraft:polished_blackstone_bricks
fill 463 253 485 463 256 485 minecraft:blackstone
setblock 463 253 489 minecraft:polished_blackstone_bricks
fill 463 253 490 463 256 490 minecraft:blackstone
fill 464 253 464 464 256 464 minecraft:blackstone
setblock 464 253 468 minecraft:polished_blackstone_bricks
fill 464 253 469 464 256 469 minecraft:blackstone
setblock 464 253 473 minecraft:polished_blackstone_bricks
fill 464 253 474 464 254 476 minecraft:blackstone
setblock 464 253 478 minecraft:polished_blackstone_bricks
fill 464 253 479 464 256 479 minecraft:blackstone
setblock 464 253 483 minecraft:polished_blackstone_bricks
fill 464 253 484 464 256 484 minecraft:blackstone
setblock 464 253 488 minecraft:polished_blackstone_bricks
fill 464 253 489 464 256 489 minecraft:blackstone
setblock 464 253 492 minecraft:blackstone
setblock 464 253 493 minecraft:polished_blackstone_bricks
fill 464 253 494 464 256 494 minecraft:blackstone
fill 424 254 464 424 254 466 minecraft:blackstone
setblock 424 254 467 minecraft:polished_blackstone_bricks
fill 424 254 468 424 254 471 minecraft:blackstone
setblock 424 254 472 minecraft:polished_blackstone_bricks
fill 424 254 473 424 257 473 minecraft:blackstone
setblock 424 254 477 minecraft:polished_blackstone_bricks
fill 424 254 478 424 257 478 minecraft:blackstone
setblock 424 254 482 minecraft:polished_blackstone_bricks
fill 424 254 483 424 257 483 minecraft:blackstone
setblock 424 254 487 minecraft:polished_blackstone_bricks
fill 424 254 488 424 257 488 minecraft:blackstone
setblock 424 254 491 minecraft:blackstone
setblock 424 254 492 minecraft:polished_blackstone_bricks
fill 424 254 493 424 257 493 minecraft:blackstone
fill 425 254 464 425 254 465 minecraft:blackstone
setblock 425 254 466 minecraft:polished_blackstone_bricks
fill 425 254 467 425 254 470 minecraft:blackstone
setblock 425 254 471 minecraft:polished_blackstone_bricks
fill 425 254 472 425 257 472 minecraft:blackstone
setblock 425 254 476 minecraft:polished_blackstone_bricks
setblock 425 254 477 minecraft:blackstone
setblock 425 254 481 minecraft:polished_blackstone_bricks
fill 425 254 482 425 255 482 minecraft:blackstone
setblock 425 254 486 minecraft:polished_blackstone_bricks
fill 425 254 487 425 257 487 minecraft:blackstone
setblock 425 254 491 minecraft:polished_blackstone_bricks
fill 425 254 504 426 254 504 minecraft:blackstone
setblock 426 254 464 minecraft:blackstone
setblock 426 254 465 minecraft:polished_blackstone_bricks
fill 426 254 466 426 257 466 minecraft:blackstone
setblock 426 254 469 minecraft:blackstone
setblock 426 254 470 minecraft:polished_blackstone_bricks
fill 426 254 471 427 256 471 minecraft:blackstone
fill 426 254 473 426 255 473 minecraft:blackstone
setblock 426 254 485 minecraft:polished_blackstone_bricks
setblock 426 254 486 minecraft:blackstone
setblock 427 254 464 minecraft:polished_blackstone_bricks
fill 427 254 465 427 257 465 minecraft:blackstone
setblock 427 254 469 minecraft:polished_blackstone_bricks
fill 427 254 470 427 257 470 minecraft:blackstone
setblock 427 254 504 minecraft:polished_blackstone_bricks
fill 428 254 464 431 254 464 minecraft:blackstone
fill 428 254 504 431 254 504 minecraft:blackstone
setblock 429 254 467 minecraft:polished_blackstone_bricks
setblock 430 254 466 minecraft:polished_blackstone_bricks
fill 430 254 467 430 256 467 minecraft:blackstone
fill 430 254 468 430 273 468 minecraft:polished_blackstone_bricks
setblock 431 254 465 minecraft:polished_blackstone_bricks
fill 431 254 466 431 257 466 minecraft:blackstone
setblock 432 254 464 minecraft:polished_blackstone_bricks
fill 432 254 465 432 257 465 minecraft:blackstone
setblock 432 254 504 minecraft:polished_blackstone_bricks
fill 433 254 464 433 257 464 minecraft:blackstone
fill 433 254 504 436 254 504 minecraft:blackstone
setblock 435 254 466 minecraft:polished_blackstone_bricks
setblock 436 254 465 minecraft:polished_blackstone_bricks
setblock 436 254 466 minecraft:blackstone
setblock 437 254 464 minecraft:polished_blackstone_bricks
fill 437 254 465 440 254 465 minecraft:blackstone
setblock 437 254 504 minecraft:polished_blackstone_bricks
fill 438 254 464 441 254 464 minecraft:blackstone
fill 438 254 504 441 254 504 minecraft:blackstone
setblock 441 254 465 minecraft:polished_blackstone_bricks
setblock 442 254 464 minecraft:polished_blackstone_bricks
fill 442 254 465 445 254 465 minecraft:blackstone
setblock 442 254 504 minecraft:polished_blackstone_bricks
fill 443 254 464 446 254 464 minecraft:blackstone
fill 443 254 504 446 254 504 minecraft:blackstone
fill 444 254 503 447 254 503 minecraft:blackstone
setblock 445 254 466 minecraft:polished_blackstone_bricks
setblock 446 254 465 minecraft:polished_blackstone_bricks
fill 446 254 466 446 255 466 minecraft:blackstone
setblock 447 254 464 minecraft:polished_blackstone_bricks
fill 447 254 465 447 257 465 minecraft:blackstone
setblock 447 254 504 minecraft:polished_blackstone_bricks
fill 448 254 464 448 257 464 minecraft:blackstone
setblock 448 254 502 minecraft:blackstone
setblock 448 254 503 minecraft:polished_blackstone_bricks
fill 448 254 504 451 254 504 minecraft:blackstone
setblock 449 254 502 minecraft:polished_blackstone_bricks
fill 449 254 503 449 256 503 minecraft:blackstone
setblock 450 254 466 minecraft:polished_blackstone_bricks
setblock 450 254 502 minecraft:blackstone
setblock 451 254 465 minecraft:polished_blackstone_bricks
setblock 451 254 466 minecraft:blackstone
setblock 452 254 464 minecraft:polished_blackstone_bricks
fill 452 254 465 452 255 465 minecraft:blackstone
setblock 452 254 504 minecraft:polished_blackstone_bricks
fill 453 254 464 453 255 464 minecraft:blackstone
setblock 453 254 503 minecraft:polished_blackstone_bricks
fill 453 254 504 453 255 504 minecraft:blackstone
setblock 462 254 489 minecraft:polished_blackstone_bricks
setblock 463 254 464 minecraft:blackstone
setblock 463 254 483 minecraft:polished_blackstone_bricks
fill 463 254 484 463 256 484 minecraft:blackstone
setblock 463 254 488 minecraft:polished_blackstone_bricks
fill 463 254 489 463 257 489 minecraft:blackstone
setblock 464 254 467 minecraft:polished_blackstone_bricks
fill 464 254 468 464 257 468 minecraft:blackstone
fill 464 254 470 464 254 471 minecraft:blackstone
setblock 464 254 472 minecraft:polished_blackstone_bricks
fill 464 254 473 464 257 473 minecraft:blackstone
setblock 464 254 477 minecraft:polished_blackstone_bricks
fill 464 254 478 464 257 478 minecraft:blackstone
setblock 464 254 482 minecraft:polished_blackstone_bricks
fill 464 254 483 464 257 483 minecraft:blackstone
setblock 464 254 487 minecraft:polished_blackstone_bricks
fill 464 254 488 464 257 488 minecraft:blackstone
setblock 464 254 492 minecraft:polished_blackstone_bricks
fill 464 254 493 464 257 493 minecraft:blackstone
fill 424 255 464 424 255 465 minecraft:blackstone
setblock 424 255 466 minecraft:polished_blackstone_bricks
fill 424 255 467 424 255 470 minecraft:blackstone
setblock 424 255 471 minecraft:polished_blackstone_bricks
fill 424 255 472 424 258 472 minecraft:blackstone
setblock 424 255 475 minecraft:blackstone
setblock 424 255 476 minecraft:polished_blackstone_bricks
fill 424 255 477 424 258 477 minecraft:blackstone
setblock 424 255 481 minecraft:polished_blackstone_bricks
fill 424 255 482 424 258 482 minecraft:blackstone
setblock 424 255 486 minecraft:polished_blackstone_bricks
fill 424 255 487 424 258 487 minecraft:blackstone
setblock 424 255 491 minecraft:polished_blackstone_bricks
fill 424 255 492 424 258 492 minecraft:blackstone
setblock 425 255 464 minecraft:blackstone
setblock 425 255 465 minecraft:polished_blackstone_bricks
fill 425 255 466 425 255 469 minecraft:blackstone
setblock 425 255 470 minecraft:polished_blackstone_bricks
fill 425 255 471 425 258 471 minecraft:blackstone
setblock 425 255 475 minecraft:polished_blackstone_bricks
fill 425 255 476 425 258 476 minecraft:blackstone
setblock 425 255 485 minecraft:polished_blackstone_bricks
fill 425 255 486 425 256 486 minecraft:blackstone
setblock 425 255 490 minecraft:polished_blackstone_bricks
fill 425 255 491 425 258 491 minecraft:blackstone
setblock 426 255 464 minecraft:polished_blackstone_bricks
fill 426 255 465 426 258 465 minecraft:blackstone
setblock 426 255 468 minecraft:blackstone
setblock 426 255 469 minecraft:polished_blackstone_bricks
fill 426 255 470 426 258 470 minecraft:blackstone
setblock 426 255 504 minecraft:polished_blackstone_bricks
fill 427 255 464 430 255 464 minecraft:blackstone
setblock 427 255 468 minecraft:polished_blackstone_bricks
fill 427 255 469 427 258 469 minecraft:blackstone
fill 427 255 504 430 255 504 minecraft:blackstone
setblock 428 255 467 minecraft:polished_blackstone_bricks
setblock 429 255 466 minecraft:polished_blackstone_bricks
fill 429 255 467 429 257 467 minecraft:blackstone
setblock 430 255 465 minecraft:polished_blackstone_bricks
fill 430 255 466 430 258 466 minecraft:blackstone
setblock 431 255 464 minecraft:polished_blackstone_bricks
fill 431 255 465 431 258 465 minecraft:blackstone
setblock 431 255 504 minecraft:polished_blackstone_bricks
fill 432 255 464 432 258 464 minecraft:blackstone
fill 432 255 504 435 255 504 minecraft:blackstone
fill 433 255 467 433 273 467 minecraft:polished_blackstone_bricks
setblock 434 255 466 minecraft:polished_blackstone_bricks
setblock 435 255 465 minecraft:polished_blackstone_bricks
setblock 435 255 466 minecraft:blackstone
setblock 436 255 464 minecraft:polished_blackstone_bricks
fill 436 255 465 439 255 465 minecraft:blackstone
setblock 436 255 504 minecraft:polished_blackstone_bricks
fill 437 255 464 440 255 464 minecraft:blackstone
setblock 437 255 504 minecraft:blackstone
fill 439 255 504 440 255 504 minecraft:blackstone
setblock 440 255 465 minecraft:polished_blackstone_bricks
setblock 441 255 464 minecraft:polished_blackstone_bricks
fill 441 255 465 444 255 465 minecraft:blackstone
setblock 441 255 504 minecraft:polished_blackstone_bricks
fill 442 255 464 445 255 464 minecraft:blackstone
fill 442 255 504 445 255 504 minecraft:blackstone
fill 444 255 503 446 255 503 minecraft:blackstone
setblock 445 255 465 minecraft:polished_blackstone_bricks
setblock 446 255 464 minecraft:polished_blackstone_bricks
fill 446 255 465 446 258 465 minecraft:blackstone
setblock 446 255 504 minecraft:polished_blackstone_bricks
fill 447 255 464 447 258 464 minecraft:blackstone
setblock 447 255 503 minecraft:polished_blackstone_bricks
fill 447 255 504 450 255 504 minecraft:blackstone
fill 448 255 503 448 257 503 minecraft:blackstone
setblock 449 255 466 minecraft:polished_blackstone_bricks
setblock 450 255 465 minecraft:polished_blackstone_bricks
setblock 451 255 464 minecraft:polished_blackstone_bricks
setblock 451 255 465 minecraft:blackstone
setblock 451 255 504 minecraft:polished_blackstone_bricks
fill 452 255 464 452 256 464 minecraft:blackstone
fill 452 255 504 452 256 504 minecraft:blackstone
fill 457 255 483 457 256 483 minecraft:cyan_stained_glass
setblock 463 255 483 minecraft:blackstone
setblock 463 255 487 minecraft:polished_blackstone_bricks
fill 463 255 488 463 258 488 minecraft:blackstone
setblock 463 255 491 minecraft:blackstone
setblock 463 255 492 minecraft:polished_blackstone_bricks
setblock 464 255 466 minecraft:polished_blackstone_bricks
fill 464 255 467 464 258 467 minecraft:blackstone
setblock 464 255 470 minecraft:blackstone
setblock 464 255 471 minecraft:polished_blackstone_bricks
fill 464 255 472 464 258 472 minecraft:blackstone
fill 464 255 474 464 255 475 minecraft:blackstone
setblock 464 255 476 minecraft:polished_blackstone_bricks
fill 464 255 477 464 258 477 minecraft:blackstone
setblock 464 255 481 minecraft:polished_blackstone_bricks
fill 464 255 482 464 258 482 minecraft:blackstone
setblock 464 255 486 minecraft:polished_blackstone_bricks
fill 464 255 487 464 258 487 minecraft:blackstone
setblock 464 255 491 minecraft:polished_blackstone_bricks
fill 464 255 492 464 258 492 minecraft:blackstone
setblock 424 256 464 minecraft:blackstone
setblock 424 256 465 minecraft:polished_blackstone_bricks
fill 424 256 466 424 256 469 minecraft:blackstone
setblock 424 256 470 minecraft:polished_blackstone_bricks
fill 424 256 471 424 259 471 minecraft:blackstone
setblock 424 256 475 minecraft:polished_blackstone_bricks
fill 424 256 476 424 259 476 minecraft:blackstone
setblock 424 256 480 minecraft:polished_blackstone_bricks
fill 424 256 481 424 259 481 minecraft:blackstone
setblock 424 256 485 minecraft:polished_blackstone_bricks
fill 424 256 486 424 259 486 minecraft:blackstone
setblock 424 256 490 minecraft:polished_blackstone_bricks
fill 424 256 491 424 259 491 minecraft:blackstone
setblock 424 256 494 minecraft:blackstone
setblock 425 256 464 minecraft:polished_blackstone_bricks
fill 425 256 465 425 256 468 minecraft:blackstone
setblock 425 256 469 minecraft:polished_blackstone_bricks
fill 425 256 470 425 259 470 minecraft:blackstone
setblock 425 256 474 minecraft:polished_blackstone_bricks
fill 425 256 475 425 259 475 minecraft:blackstone
setblock 425 256 485 minecraft:blackstone
setblock 425 256 489 minecraft:polished_blackstone_bricks
fill 425 256 490 425 259 490 minecraft:blackstone
fill 426 256 464 429 256 464 minecraft:blackstone
setblock 426 256 468 minecraft:polished_blackstone_bricks
fill 426 256 469 426 259 469 minecraft:blackstone
setblock 426 256 473 minecraft:polished_blackstone_bricks
fill 426 256 474 426 259 474 minecraft:blackstone
setblock 426 256 482 minecraft:light[level=11]
setblock 426 256 490 minecraft:light[level=11]
setblock 426 256 498 minecraft:light[level=11]
fill 426 256 504 429 256 504 minecraft:blackstone
setblock 427 256 467 minecraft:polished_blackstone_bricks
fill 427 256 468 427 259 468 minecraft:blackstone
setblock 428 256 466 minecraft:polished_blackstone_bricks
fill 428 256 467 428 258 467 minecraft:blackstone
setblock 429 256 465 minecraft:polished_blackstone_bricks
fill 429 256 466 429 259 466 minecraft:blackstone
setblock 430 256 464 minecraft:polished_blackstone_bricks
fill 430 256 465 430 259 465 minecraft:blackstone
setblock 430 256 504 minecraft:polished_blackstone_bricks
fill 431 256 464 431 259 464 minecraft:blackstone
fill 431 256 504 433 256 504 minecraft:blackstone
fill 432 256 467 432 273 467 minecraft:polished_blackstone_bricks
fill 433 256 466 433 273 466 minecraft:polished_blackstone_bricks
setblock 434 256 465 minecraft:polished_blackstone_bricks
setblock 434 256 466 minecraft:light[level=11]
setblock 434 256 474 minecraft:light[level=11]
setblock 434 256 482 minecraft:light[level=11]
setblock 434 256 490 minecraft:light[level=11]
setblock 434 256 498 minecraft:light[level=11]
setblock 435 256 464 minecraft:polished_blackstone_bricks
fill 435 256 465 436 256 465 minecraft:blackstone
fill 436 256 464 439 256 464 minecraft:blackstone
setblock 440 256 464 minecraft:polished_blackstone_bricks
fill 441 256 464 444 256 464 minecraft:blackstone
fill 441 256 504 444 256 504 minecraft:blackstone
setblock 442 256 466 minecraft:light[level=11]
setblock 442 256 474 minecraft:light[level=11]
setblock 442 256 482 minecraft:light[level=11]
setblock 442 256 490 minecraft:light[level=11]
setblock 442 256 498 minecraft:light[level=11]
setblock 443 256 465 minecraft:blackstone
setblock 444 256 465 minecraft:polished_blackstone_bricks
setblock 445 256 464 minecraft:polished_blackstone_bricks
fill 445 256 465 445 257 465 minecraft:blackstone
setblock 445 256 503 minecraft:blackstone
setblock 445 256 504 minecraft:polished_blackstone_bricks
fill 446 256 464 446 259 464 minecraft:blackstone
setblock 446 256 503 minecraft:polished_blackstone_bricks
fill 446 256 504 449 256 504 minecraft:blackstone
fill 447 256 503 447 257 503 minecraft:blackstone
setblock 449 256 465 minecraft:polished_blackstone_bricks
setblock 450 256 464 minecraft:polished_blackstone_bricks
setblock 450 256 465 minecraft:blackstone
setblock 450 256 466 minecraft:light[level=11]
setblock 450 256 474 minecraft:light[level=11]
setblock 450 256 482 minecraft:light[level=11]
setblock 450 256 490 minecraft:light[level=11]
setblock 450 256 498 minecraft:light[level=11]
setblock 450 256 504 minecraft:polished_blackstone_bricks
fill 451 256 464 451 257 464 minecraft:blackstone
fill 451 256 504 451 257 504 minecraft:blackstone
setblock 458 256 466 minecraft:light[level=11]
setblock 458 256 474 minecraft:light[level=11]
setblock 458 256 482 minecraft:light[level=11]
setblock 458 256 490 minecraft:light[level=11]
setblock 458 256 498 minecraft:light[level=11]
setblock 463 256 486 minecraft:polished_blackstone_bricks
fill 463 256 487 463 259 487 minecraft:blackstone
setblock 463 256 491 minecraft:polished_blackstone_bricks
fill 463 256 492 463 258 493 minecraft:blackstone
setblock 464 256 465 minecraft:polished_blackstone_bricks
fill 464 256 466 464 259 466 minecraft:blackstone
setblock 464 256 470 minecraft:polished_blackstone_bricks
fill 464 256 471 464 259 471 minecraft:blackstone
setblock 464 256 474 minecraft:blackstone
setblock 464 256 475 minecraft:polished_blackstone_bricks
fill 464 256 476 464 259 476 minecraft:blackstone
setblock 464 256 480 minecraft:polished_blackstone_bricks
fill 464 256 481 464 259 481 minecraft:blackstone
setblock 464 256 485 minecraft:polished_blackstone_bricks
fill 464 256 486 464 259 486 minecraft:blackstone
setblock 464 256 490 minecraft:polished_blackstone_bricks
fill 464 256 491 464 259 491 minecraft:blackstone
setblock 464 256 495 minecraft:polished_blackstone_bricks
setblock 424 257 464 minecraft:polished_blackstone_bricks
fill 424 257 465 424 257 468 minecraft:blackstone
setblock 424 257 469 minecraft:polished_blackstone_bricks
fill 424 257 470 424 260 470 minecraft:blackstone
setblock 424 257 474 minecraft:polished_blackstone_bricks
fill 424 257 475 424 260 475 minecraft:blackstone
setblock 424 257 479 minecraft:polished_blackstone_bricks
fill 424 257 480 424 260 480 minecraft:blackstone
setblock 424 257 484 minecraft:polished_blackstone_bricks
fill 424 257 485 424 260 485 minecraft:blackstone
setblock 424 257 489 minecraft:polished_blackstone_bricks
fill 424 257 490 424 260 490 minecraft:blackstone
setblock 424 257 494 minecraft:polished_blackstone_bricks
fill 425 257 464 425 257 467 minecraft:blackstone
setblock 425 257 468 minecraft:polished_blackstone_bricks
fill 425 257 469 425 260 469 minecraft:blackstone
setblock 425 257 473 minecraft:polished_blackstone_bricks
fill 425 257 474 425 260 474 minecraft:blackstone
setblock 425 257 488 minecraft:polished_blackstone_bricks
fill 425 257 489 425 259 489 minecraft:blackstone
fill 426 257 464 428 257 464 minecraft:blackstone
setblock 426 257 467 minecraft:polished_blackstone_bricks
fill 426 257 468 426 260 468 minecraft:blackstone
setblock 426 257 471 minecraft:blackstone
setblock 426 257 472 minecraft:polished_blackstone_bricks
fill 426 257 473 426 260 473 minecraft:blackstone
fill 426 257 475 427 258 478 minecraft:warped_wart_block
setblock 427 257 466 minecraft:polished_blackstone_bricks
fill 427 257 467 427 258 467 minecraft:blackstone
setblock 427 257 471 minecraft:polished_blackstone_bricks
fill 427 257 474 430 260 474 minecraft:warped_wart_block
fill 427 257 504 428 257 504 minecraft:blackstone
setblock 428 257 465 minecraft:polished_blackstone_bricks
fill 428 257 466 428 260 466 minecraft:blackstone
fill 428 257 475 430 260 475 minecraft:warped_wart_block
setblock 428 257 476 minecraft:polished_blackstone_bricks
fill 428 257 477 430 260 478 minecraft:warped_wart_block
setblock 429 257 464 minecraft:polished_blackstone_bricks
fill 429 257 465 429 260 465 minecraft:blackstone
fill 429 257 476 430 260 476 minecraft:warped_wart_block
setblock 429 257 504 minecraft:polished_blackstone_bricks
fill 430 257 464 430 260 464 minecraft:blackstone
fill 430 257 467 431 273 467 minecraft:polished_blackstone_bricks
fill 430 257 504 431 257 504 minecraft:blackstone
fill 432 257 466 432 273 466 minecraft:polished_blackstone_bricks
setblock 433 257 465 minecraft:polished_blackstone_bricks
fill 433 257 496 434 258 497 minecraft:cyan_stained_glass
setblock 434 257 464 minecraft:polished_blackstone_bricks
setblock 434 257 465 minecraft:blackstone
fill 435 257 464 438 257 464 minecraft:blackstone
setblock 439 257 464 minecraft:polished_blackstone_bricks
fill 440 257 464 443 257 464 minecraft:blackstone
fill 442 257 504 443 257 504 minecraft:blackstone
setblock 444 257 464 minecraft:polished_blackstone_bricks
setblock 444 257 465 minecraft:blackstone
setblock 444 257 504 minecraft:polished_blackstone_bricks
fill 445 257 464 445 260 464 minecraft:blackstone
fill 445 257 504 448 257 504 minecraft:blackstone
setblock 446 257 503 minecraft:blackstone
fill 447 257 491 448 258 491 minecraft:cyan_stained_glass
setblock 448 257 465 minecraft:polished_blackstone_bricks
setblock 449 257 464 minecraft:polished_blackstone_bricks
setblock 449 257 504 minecraft:polished_blackstone_bricks
setblock 450 257 464 minecraft:blackstone
fill 450 257 504 450 258 504 minecraft:blackstone
setblock 463 257 469 minecraft:blackstone
setblock 463 257 470 minecraft:polished_blackstone_bricks
fill 463 257 471 463 259 472 minecraft:blackstone
setblock 463 257 485 minecraft:polished_blackstone_bricks
fill 463 257 486 463 260 486 minecraft:blackstone
setblock 463 257 490 minecraft:polished_blackstone_bricks
fill 463 257 491 463 260 491 minecraft:blackstone
setblock 464 257 464 minecraft:polished_blackstone_bricks
fill 464 257 465 464 260 465 minecraft:blackstone
setblock 464 257 469 minecraft:polished_blackstone_bricks
fill 464 257 470 464 260 470 minecraft:blackstone
setblock 464 257 474 minecraft:polished_blackstone_bricks
fill 464 257 475 464 260 475 minecraft:blackstone
setblock 464 257 479 minecraft:polished_blackstone_bricks
fill 464 257 480 464 260 480 minecraft:blackstone
setblock 464 257 484 minecraft:polished_blackstone_bricks
fill 464 257 485 464 260 485 minecraft:blackstone
setblock 464 257 489 minecraft:polished_blackstone_bricks
fill 464 257 490 464 260 490 minecraft:blackstone
setblock 464 257 494 minecraft:polished_blackstone_bricks
fill 464 257 495 464 259 496 minecraft:blackstone
fill 424 258 464 424 258 467 minecraft:blackstone
setblock 424 258 468 minecraft:polished_blackstone_bricks
fill 424 258 469 424 261 469 minecraft:blackstone
setblock 424 258 473 minecraft:polished_blackstone_bricks
fill 424 258 474 424 261 474 minecraft:blackstone
setblock 424 258 478 minecraft:polished_blackstone_bricks
fill 424 258 479 424 261 479 minecraft:blackstone
setblock 424 258 483 minecraft:polished_blackstone_bricks
fill 424 258 484 424 261 484 minecraft:blackstone
setblock 424 258 488 minecraft:polished_blackstone_bricks
fill 424 258 489 424 261 489 minecraft:blackstone
setblock 424 258 493 minecraft:polished_blackstone_bricks
fill 424 258 494 424 260 495 minecraft:blackstone
fill 425 258 464 425 258 466 minecraft:blackstone
setblock 425 258 467 minecraft:polished_blackstone_bricks
fill 425 258 468 425 261 468 minecraft:blackstone
setblock 425 258 472 minecraft:polished_blackstone_bricks
fill 425 258 473 425 261 473 minecraft:blackstone
setblock 425 258 477 minecraft:polished_blackstone_bricks
setblock 425 258 488 minecraft:blackstone
setblock 425 258 492 minecraft:polished_blackstone_bricks
fill 426 258 464 427 258 464 minecraft:blackstone
setblock 426 258 466 minecraft:polished_blackstone_bricks
fill 426 258 467 426 261 467 minecraft:blackstone
setblock 426 258 471 minecraft:polished_blackstone_bricks
fill 426 258 472 426 261 472 minecraft:blackstone
setblock 427 258 465 minecraft:polished_blackstone_bricks
fill 427 258 466 427 261 466 minecraft:blackstone
setblock 427 258 470 minecraft:polished_blackstone_bricks
fill 427 258 471 427 261 471 minecraft:blackstone
fill 427 258 473 429 259 473 minecraft:warped_wart_block
fill 427 258 479 429 259 479 minecraft:warped_wart_block
setblock 427 258 504 minecraft:blackstone
setblock 428 258 464 minecraft:polished_blackstone_bricks
fill 428 258 465 428 261 465 minecraft:blackstone
fill 428 258 476 428 261 476 minecraft:warped_wart_block
setblock 428 258 504 minecraft:polished_blackstone_bricks
fill 429 258 464 429 261 464 minecraft:blackstone
setblock 429 258 504 minecraft:blackstone
fill 431 258 466 431 273 466 minecraft:polished_blackstone_bricks
fill 431 258 475 431 259 477 minecraft:warped_wart_block
setblock 432 258 465 minecraft:polished_blackstone_bricks
setblock 433 258 464 minecraft:polished_blackstone_bricks
setblock 433 258 465 minecraft:blackstone
fill 434 258 464 435 258 464 minecraft:blackstone
fill 441 258 464 442 258 464 minecraft:blackstone
setblock 442 258 504 minecraft:blackstone
setblock 443 258 464 minecraft:polished_blackstone_bricks
setblock 443 258 504 minecraft:polished_blackstone_bricks
fill 444 258 464 444 261 464 minecraft:blackstone
fill 444 258 504 447 258 504 minecraft:blackstone
setblock 448 258 464 minecraft:polished_blackstone_bricks
setblock 448 258 504 minecraft:polished_blackstone_bricks
setblock 449 258 464 minecraft:blackstone
fill 449 258 504 449 261 504 minecraft:blackstone
setblock 463 258 468 minecraft:blackstone
setblock 463 258 469 minecraft:polished_blackstone_bricks
fill 463 258 470 463 261 470 minecraft:blackstone
setblock 463 258 473 minecraft:blackstone
setblock 463 258 474 minecraft:polished_blackstone_bricks
setblock 463 258 485 minecraft:blackstone
setblock 463 258 489 minecraft:polished_blackstone_bricks
fill 463 258 490 463 261 490 minecraft:blackstone
setblock 464 258 468 minecraft:polished_blackstone_bricks
fill 464 258 469 464 261 469 minecraft:blackstone
setblock 464 258 473 minecraft:polished_blackstone_bricks
fill 464 258 474 464 261 474 minecraft:blackstone
setblock 464 258 478 minecraft:polished_blackstone_bricks
fill 464 258 479 464 261 479 minecraft:blackstone
setblock 464 258 483 minecraft:polished_blackstone_bricks
fill 464 258 484 464 261 484 minecraft:blackstone
setblock 464 258 488 minecraft:polished_blackstone_bricks
fill 464 258 489 464 261 489 minecraft:blackstone
setblock 464 258 493 minecraft:polished_blackstone_bricks
fill 464 258 494 464 261 494 minecraft:blackstone
fill 424 259 464 424 259 466 minecraft:blackstone
setblock 424 259 467 minecraft:polished_blackstone_bricks
fill 424 259 468 424 262 468 minecraft:blackstone
setblock 424 259 472 minecraft:polished_blackstone_bricks
fill 424 259 473 424 262 473 minecraft:blackstone
setblock 424 259 477 minecraft:polished_blackstone_bricks
fill 424 259 478 424 262 478 minecraft:blackstone
setblock 424 259 482 minecraft:polished_blackstone_bricks
fill 424 259 483 424 262 483 minecraft:blackstone
setblock 424 259 487 minecraft:polished_blackstone_bricks
fill 424 259 488 424 262 488 minecraft:blackstone
setblock 424 259 492 minecraft:polished_blackstone_bricks
fill 424 259 493 425 261 493 minecraft:blackstone
setblock 424 259 496 minecraft:blackstone
fill 425 259 464 425 259 465 minecraft:blackstone
setblock 425 259 466 minecraft:polished_blackstone_bricks
fill 425 259 467 425 262 467 minecraft:blackstone
setblock 425 259 471 minecraft:polished_blackstone_bricks
fill 425 259 472 425 262 472 minecraft:blackstone
setblock 425 259 476 minecraft:polished_blackstone_bricks
fill 425 259 477 425 262 477 minecraft:blackstone
setblock 425 259 491 minecraft:polished_blackstone_bricks
fill 425 259 492 425 262 492 minecraft:blackstone
setblock 426 259 464 minecraft:blackstone
setblock 426 259 465 minecraft:polished_blackstone_bricks
fill 426 259 466 426 262 466 minecraft:blackstone
setblock 426 259 470 minecraft:polished_blackstone_bricks
fill 426 259 471 426 262 471 minecraft:blackstone
setblock 426 259 475 minecraft:polished_blackstone_bricks
fill 426 259 476 427 259 478 minecraft:warped_wart_block
setblock 427 259 464 minecraft:polished_blackstone_bricks
fill 427 259 465 427 262 465 minecraft:blackstone
setblock 427 259 469 minecraft:polished_blackstone_bricks
fill 427 259 470 427 262 470 minecraft:blackstone
fill 427 259 472 427 260 472 minecraft:blackstone
fill 427 259 475 427 260 475 minecraft:warped_wart_block
setblock 427 259 504 minecraft:polished_blackstone_bricks
fill 428 259 464 428 262 464 minecraft:blackstone
fill 428 259 504 428 262 504 minecraft:blackstone
fill 430 259 466 430 273 466 minecraft:polished_blackstone_bricks
setblock 431 259 465 minecraft:polished_blackstone_bricks
setblock 432 259 464 minecraft:polished_blackstone_bricks
setblock 432 259 465 minecraft:blackstone
fill 433 259 464 434 259 464 minecraft:blackstone
setblock 441 259 464 minecraft:blackstone
setblock 442 259 464 minecraft:polished_blackstone_bricks
setblock 442 259 504 minecraft:polished_blackstone_bricks
fill 443 259 464 443 262 464 minecraft:blackstone
fill 443 259 504 446 259 504 minecraft:blackstone
setblock 447 259 464 minecraft:polished_blackstone_bricks
setblock 447 259 504 minecraft:polished_blackstone_bricks
setblock 448 259 464 minecraft:blackstone
fill 448 259 504 448 262 504 minecraft:blackstone
setblock 463 259 468 minecraft:polished_blackstone_bricks
fill 463 259 469 463 262 469 minecraft:blackstone
setblock 463 259 473 minecraft:polished_blackstone_bricks
fill 463 259 474 463 259 477 minecraft:blackstone
setblock 463 259 488 minecraft:polished_blackstone_bricks
fill 463 259 489 463 262 489 minecraft:blackstone
setblock 463 259 492 minecraft:blackstone
setblock 463 259 493 minecraft:polished_blackstone_bricks
fill 463 259 494 463 262 494 minecraft:blackstone
fill 464 259 464 464 261 464 minecraft:blackstone
setblock 464 259 467 minecraft:polished_blackstone_bricks
fill 464 259 468 464 262 468 minecraft:blackstone
setblock 464 259 472 minecraft:polished_blackstone_bricks
fill 464 259 473 464 262 473 minecraft:blackstone
setblock 464 259 477 minecraft:polished_blackstone_bricks
fill 464 259 478 464 262 478 minecraft:blackstone
setblock 464 259 482 minecraft:polished_blackstone_bricks
fill 464 259 483 464 262 483 minecraft:blackstone
setblock 464 259 487 minecraft:polished_blackstone_bricks
fill 464 259 488 464 262 488 minecraft:blackstone
setblock 464 259 492 minecraft:polished_blackstone_bricks
fill 464 259 493 464 262 493 minecraft:blackstone
setblock 464 259 497 minecraft:polished_blackstone_bricks
fill 424 260 464 424 260 465 minecraft:blackstone
setblock 424 260 466 minecraft:polished_blackstone_bricks
fill 424 260 467 424 263 467 minecraft:blackstone
setblock 424 260 471 minecraft:polished_blackstone_bricks
fill 424 260 472 424 263 472 minecraft:blackstone
setblock 424 260 476 minecraft:polished_blackstone_bricks
fill 424 260 477 424 263 477 minecraft:blackstone
setblock 424 260 481 minecraft:polished_blackstone_bricks
fill 424 260 482 424 263 482 minecraft:blackstone
setblock 424 260 486 minecraft:polished_blackstone_bricks
fill 424 260 487 424 263 487 minecraft:blackstone
setblock 424 260 491 minecraft:polished_blackstone_bricks
fill 424 260 492 424 263 492 minecraft:blackstone
setblock 424 260 496 minecraft:polished_blackstone_bricks
fill 424 260 497 424 262 498 minecraft:blackstone
setblock 425 260 464 minecraft:blackstone
setblock 425 260 465 minecraft:polished_blackstone_bricks
fill 425 260 466 425 263 466 minecraft:blackstone
setblock 425 260 470 minecraft:polished_blackstone_bricks
fill 425 260 471 425 263 471 minecraft:blackstone
setblock 425 260 475 minecraft:polished_blackstone_bricks
fill 425 260 476 426 262 476 minecraft:blackstone
fill 425 260 478 425 261 478 minecraft:blackstone
fill 425 260 488 430 260 488 minecraft:blackstone
setblock 425 260 490 minecraft:polished_blackstone_bricks
fill 425 260 491 425 263 491 minecraft:blackstone
setblock 425 260 494 minecraft:blackstone
setblock 425 260 495 minecraft:polished_blackstone_bricks
setblock 426 260 464 minecraft:polished_blackstone_bricks
fill 426 260 465 426 263 465 minecraft:blackstone
setblock 426 260 469 minecraft:polished_blackstone_bricks
fill 426 260 470 426 263 470 minecraft:blackstone
setblock 426 260 474 minecraft:polished_blackstone_bricks
fill 426 260 475 426 263 475 minecraft:blackstone
fill 426 260 477 427 260 478 minecraft:warped_wart_block
fill 426 260 486 430 261 487 minecraft:blackstone
fill 426 260 489 430 261 490 minecraft:blackstone
setblock 426 260 504 minecraft:polished_blackstone_bricks
fill 427 260 464 427 263 464 minecraft:blackstone
setblock 427 260 468 minecraft:polished_blackstone_bricks
fill 427 260 469 427 262 469 minecraft:blackstone
setblock 427 260 476 minecraft:warped_wart_block
fill 427 260 504 427 263 504 minecraft:blackstone
setblock 429 260 466 minecraft:polished_blackstone_bricks
setblock 430 260 465 minecraft:polished_blackstone_bricks
setblock 431 260 464 minecraft:polished_blackstone_bricks
setblock 431 260 465 minecraft:blackstone
fill 432 260 464 433 260 464 minecraft:blackstone
setblock 441 260 464 minecraft:polished_blackstone_bricks
setblock 441 260 504 minecraft:polished_blackstone_bricks
fill 442 260 464 442 263 464 minecraft:blackstone
fill 442 260 504 445 260 504 minecraft:blackstone
fill 445 260 503 445 261 503 minecraft:blackstone
setblock 446 260 464 minecraft:polished_blackstone_bricks
setblock 446 260 504 minecraft:polished_blackstone_bricks
fill 447 260 464 447 261 464 minecraft:blackstone
fill 447 260 504 447 263 504 minecraft:blackstone
setblock 463 260 467 minecraft:polished_blackstone_bricks
fill 463 260 468 463 263 468 minecraft:blackstone
setblock 463 260 471 minecraft:blackstone
setblock 463 260 472 minecraft:polished_blackstone_bricks
fill 463 260 473 463 260 476 minecraft:blackstone
setblock 463 260 477 minecraft:polished_blackstone_bricks
fill 463 260 478 463 262 479 minecraft:blackstone
fill 463 260 485 463 261 485 minecraft:blackstone
setblock 463 260 487 minecraft:polished_blackstone_bricks
fill 463 260 488 463 263 488 minecraft:blackstone
setblock 463 260 492 minecraft:polished_blackstone_bricks
fill 463 260 493 463 263 493 minecraft:blackstone
fill 463 260 495 464 260 495 minecraft:blackstone
setblock 464 260 466 minecraft:polished_blackstone_bricks
fill 464 260 467 464 263 467 minecraft:blackstone
setblock 464 260 471 minecraft:polished_blackstone_bricks
fill 464 260 472 464 263 472 minecraft:blackstone
setblock 464 260 476 minecraft:polished_blackstone_bricks
fill 464 260 477 464 263 477 minecraft:blackstone
setblock 464 260 481 minecraft:polished_blackstone_bricks
fill 464 260 482 464 263 482 minecraft:blackstone
setblock 464 260 486 minecraft:polished_blackstone_bricks
fill 464 260 487 464 263 487 minecraft:blackstone
setblock 464 260 491 minecraft:polished_blackstone_bricks
fill 464 260 492 464 263 492 minecraft:blackstone
setblock 464 260 496 minecraft:polished_blackstone_bricks
fill 464 260 497 464 262 498 minecraft:blackstone
setblock 424 261 464 minecraft:blackstone
setblock 424 261 465 minecraft:polished_blackstone_bricks
fill 424 261 466 424 264 466 minecraft:blackstone
setblock 424 261 470 minecraft:polished_blackstone_bricks
fill 424 261 471 424 264 471 minecraft:blackstone
setblock 424 261 475 minecraft:polished_blackstone_bricks
fill 424 261 476 424 264 476 minecraft:blackstone
setblock 424 261 480 minecraft:polished_blackstone_bricks
fill 424 261 481 424 264 481 minecraft:blackstone
setblock 424 261 485 minecraft:polished_blackstone_bricks
fill 424 261 486 424 264 486 minecraft:blackstone
setblock 424 261 490 minecraft:polished_blackstone_bricks
fill 424 261 491 424 264 491 minecraft:blackstone
setblock 424 261 494 minecraft:blackstone
setblock 424 261 495 minecraft:polished_blackstone_bricks
fill 424 261 496 425 263 496 minecraft:blackstone
setblock 424 261 499 minecraft:blackstone
setblock 424 261 500 minecraft:polished_blackstone_bricks
fill 424 261 501 424 264 501 minecraft:blackstone
setblock 425 261 464 minecraft:polished_blackstone_bricks
fill 425 261 465 425 264 465 minecraft:blackstone
setblock 425 261 469 minecraft:polished_blackstone_bricks
fill 425 261 470 425 264 470 minecraft:blackstone
setblock 425 261 474 minecraft:polished_blackstone_bricks
fill 425 261 475 425 264 475 minecraft:blackstone
setblock 425 261 479 minecraft:polished_blackstone_bricks
fill 425 261 490 425 263 490 minecraft:blackstone
setblock 425 261 494 minecraft:polished_blackstone_bricks
fill 425 261 495 425 264 495 minecraft:blackstone
fill 425 261 497 425 262 497 minecraft:blackstone
setblock 425 261 504 minecraft:polished_blackstone_bricks
fill 426 261 464 426 264 464 minecraft:blackstone
setblock 426 261 468 minecraft:polished_blackstone_bricks
fill 426 261 469 426 264 469 minecraft:blackstone
setblock 426 261 473 minecraft:polished_blackstone_bricks
fill 426 261 474 426 264 474 minecraft:blackstone
fill 426 261 488 430 261 488 minecraft:blackstone
fill 426 261 504 426 264 504 minecraft:blackstone
setblock 427 261 472 minecraft:polished_blackstone_bricks
fill 427 261 473 427 264 473 minecraft:blackstone
setblock 428 261 466 minecraft:polished_blackstone_bricks
setblock 429 261 465 minecraft:polished_blackstone_bricks
setblock 429 261 504 minecraft:blackstone
setblock 430 261 464 minecraft:polished_blackstone_bricks
fill 430 261 465 430 262 465 minecraft:blackstone
fill 431 261 464 432 263 464 minecraft:blackstone
setblock 440 261 504 minecraft:polished_blackstone_bricks
fill 441 261 464 441 264 464 minecraft:blackstone
fill 441 261 504 444 261 504 minecraft:blackstone
fill 443 261 503 444 262 503 minecraft:blackstone
setblock 445 261 464 minecraft:polished_blackstone_bricks
setblock 445 261 504 minecraft:polished_blackstone_bricks
fill 446 261 464 446 264 464 minecraft:blackstone
setblock 446 261 503 minecraft:polished_blackstone_bricks
fill 446 261 504 446 264 504 minecraft:blackstone
fill 462 261 470 462 261 471 minecraft:blackstone
setblock 462 261 472 minecraft:polished_blackstone_bricks
fill 462 261 473 462 261 476 minecraft:blackstone
fill 463 261 467 463 264 467 minecraft:blackstone
setblock 463 261 471 minecraft:polished_blackstone_bricks
fill 463 261 472 463 261 475 minecraft:blackstone
setblock 463 261 476 minecraft:polished_blackstone_bricks
fill 463 261 477 463 264 477 minecraft:blackstone
setblock 463 261 480 minecraft:blackstone
setblock 463 261 481 minecraft:polished_blackstone_bricks
fill 463 261 482 463 262 484 minecraft:blackstone
setblock 463 261 486 minecraft:polished_blackstone_bricks
fill 463 261 487 463 264 487 minecraft:blackstone
setblock 463 261 491 minecraft:polished_blackstone_bricks
fill 463 261 492 463 264 492 minecraft:blackstone
setblock 463 261 495 minecraft:blackstone
setblock 463 261 496 minecraft:polished_blackstone_bricks
setblock 464 261 465 minecraft:polished_blackstone_bricks
fill 464 261 466 464 264 466 minecraft:blackstone
setblock 464 261 470 minecraft:polished_blackstone_bricks
fill 464 261 471 464 264 471 minecraft:blackstone
setblock 464 261 475 minecraft:polished_blackstone_bricks
fill 464 261 476 464 264 476 minecraft:blackstone
setblock 464 261 480 minecraft:polished_blackstone_bricks
fill 464 261 481 464 264 481 minecraft:blackstone
setblock 464 261 485 minecraft:polished_blackstone_bricks
fill 464 261 486 464 264 486 minecraft:blackstone
setblock 464 261 490 minecraft:polished_blackstone_bricks
fill 464 261 491 464 264 491 minecraft:blackstone
setblock 464 261 495 minecraft:polished_blackstone_bricks
fill 464 261 496 464 264 496 minecraft:blackstone
setblock 464 261 499 minecraft:blackstone
setblock 424 262 464 minecraft:polished_blackstone_bricks
fill 424 262 465 424 265 465 minecraft:blackstone
setblock 424 262 469 minecraft:polished_blackstone_bricks
fill 424 262 470 424 265 470 minecraft:blackstone
setblock 424 262 474 minecraft:polished_blackstone_bricks
fill 424 262 475 424 265 475 minecraft:blackstone
setblock 424 262 479 minecraft:polished_blackstone_bricks
fill 424 262 480 425 264 480 minecraft:blackstone
setblock 424 262 484 minecraft:polished_blackstone_bricks
fill 424 262 485 424 265 485 minecraft:blackstone
setblock 424 262 489 minecraft:polished_blackstone_bricks
fill 424 262 490 424 265 490 minecraft:blackstone
setblock 424 262 493 minecraft:blackstone
setblock 424 262 494 minecraft:polished_blackstone_bricks
fill 424 262 495 424 265 495 minecraft:blackstone
setblock 424 262 499 minecraft:polished_blackstone_bricks
fill 424 262 500 424 265 500 minecraft:blackstone
fill 424 262 502 424 262 503 minecraft:blackstone
setblock 424 262 504 minecraft:polished_blackstone_bricks
fill 425 262 464 425 265 464 minecraft:blackstone
setblock 425 262 468 minecraft:polished_blackstone_bricks
fill 425 262 469 425 265 469 minecraft:blackstone
setblock 425 262 473 minecraft:polished_blackstone_bricks
fill 425 262 474 425 265 474 minecraft:blackstone
setblock 425 262 478 minecraft:polished_blackstone_bricks
fill 425 262 479 425 265 479 minecraft:blackstone
setblock 425 262 493 minecraft:polished_blackstone_bricks
fill 425 262 494 425 265 494 minecraft:blackstone
setblock 425 262 498 minecraft:polished_blackstone_bricks
fill 425 262 499 425 265 499 minecraft:blackstone
fill 425 262 504 425 265 504 minecraft:blackstone
setblock 426 262 467 minecraft:polished_blackstone_bricks
fill 426 262 468 426 265 468 minecraft:blackstone
setblock 426 262 472 minecraft:polished_blackstone_bricks
fill 426 262 473 426 265 473 minecraft:blackstone
setblock 426 262 477 minecraft:polished_blackstone_bricks
setblock 427 262 466 minecraft:polished_blackstone_bricks
setblock 427 262 471 minecraft:polished_blackstone_bricks
fill 427 262 472 427 264 472 minecraft:blackstone
fill 427 262 474 427 263 474 minecraft:blackstone
fill 427 262 488 429 266 488 minecraft:polished_blackstone_bricks
setblock 428 262 465 minecraft:polished_blackstone_bricks
setblock 429 262 464 minecraft:polished_blackstone_bricks
fill 429 262 465 429 264 465 minecraft:blackstone
setblock 429 262 504 minecraft:polished_blackstone_bricks
fill 430 262 464 430 265 464 minecraft:blackstone
fill 430 262 504 430 265 504 minecraft:blackstone
setblock 438 262 504 minecraft:blackstone
setblock 439 262 504 minecraft:polished_blackstone_bricks
fill 440 262 464 440 265 464 minecraft:blackstone
fill 440 262 504 443 262 504 minecraft:blackstone
fill 441 262 503 442 264 503 minecraft:blackstone
setblock 444 262 464 minecraft:polished_blackstone_bricks
setblock 444 262 504 minecraft:polished_blackstone_bricks
fill 445 262 464 445 265 464 minecraft:blackstone
setblock 445 262 503 minecraft:polished_blackstone_bricks
fill 445 262 504 445 265 504 minecraft:blackstone
fill 446 262 503 447 264 503 minecraft:blackstone
setblock 449 262 504 minecraft:polished_blackstone_bricks
fill 462 262 469 462 262 470 minecraft:blackstone
setblock 462 262 471 minecraft:polished_blackstone_bricks
fill 462 262 472 462 262 475 minecraft:blackstone
setblock 462 262 476 minecraft:polished_blackstone_bricks
fill 462 262 477 462 264 478 minecraft:blackstone
setblock 462 262 491 minecraft:polished_blackstone_bricks
fill 462 262 492 462 263 494 minecraft:blackstone
setblock 463 262 464 minecraft:blackstone
fill 463 262 466 463 265 466 minecraft:blackstone
setblock 463 262 470 minecraft:polished_blackstone_bricks
fill 463 262 471 463 262 474 minecraft:blackstone
setblock 463 262 475 minecraft:polished_blackstone_bricks
fill 463 262 476 463 265 476 minecraft:blackstone
setblock 463 262 480 minecraft:polished_blackstone_bricks
fill 463 262 481 463 265 481 minecraft:blackstone
setblock 463 262 485 minecraft:polished_blackstone_bricks
fill 463 262 486 463 265 486 minecraft:blackstone
setblock 463 262 490 minecraft:polished_blackstone_bricks
fill 463 262 491 463 265 491 minecraft:blackstone
setblock 463 262 495 minecraft:polished_blackstone_bricks
fill 463 262 496 463 263 498 minecraft:blackstone
setblock 464 262 464 minecraft:polished_blackstone_bricks
fill 464 262 465 464 265 465 minecraft:blackstone
setblock 464 262 469 minecraft:polished_blackstone_bricks
fill 464 262 470 464 265 470 minecraft:blackstone
setblock 464 262 474 minecraft:polished_blackstone_bricks
fill 464 262 475 464 265 475 minecraft:blackstone
setblock 464 262 479 minecraft:polished_blackstone_bricks
fill 464 262 480 464 265 480 minecraft:blackstone
setblock 464 262 484 minecraft:polished_blackstone_bricks
fill 464 262 485 464 265 485 minecraft:blackstone
setblock 464 262 489 minecraft:polished_blackstone_bricks
fill 464 262 490 464 265 490 minecraft:blackstone
setblock 464 262 494 minecraft:polished_blackstone_bricks
fill 464 262 495 464 265 495 minecraft:blackstone
setblock 464 262 499 minecraft:polished_blackstone_bricks
fill 464 262 500 464 264 501 minecraft:blackstone
fill 424 263 464 424 266 464 minecraft:blackstone
setblock 424 263 468 minecraft:polished_blackstone_bricks
fill 424 263 469 424 266 469 minecraft:blackstone
setblock 424 263 473 minecraft:polished_blackstone_bricks
fill 424 263 474 424 266 474 minecraft:blackstone
setblock 424 263 478 minecraft:polished_blackstone_bricks
fill 424 263 479 424 266 479 minecraft:blackstone
setblock 424 263 483 minecraft:polished_blackstone_bricks
fill 424 263 484 424 266 484 minecraft:blackstone
setblock 424 263 488 minecraft:polished_blackstone_bricks
fill 424 263 489 424 266 489 minecraft:blackstone
setblock 424 263 493 minecraft:polished_blackstone_bricks
fill 424 263 494 424 266 494 minecraft:blackstone
setblock 424 263 497 minecraft:blackstone
setblock 424 263 498 minecraft:polished_blackstone_bricks
fill 424 263 499 424 266 499 minecraft:blackstone
setblock 424 263 502 minecraft:blackstone
setblock 424 263 503 minecraft:polished_blackstone_bricks
fill 424 263 504 424 266 504 minecraft:blackstone
setblock 425 263 467 minecraft:polished_blackstone_bricks
fill 425 263 468 425 266 468 minecraft:blackstone
setblock 425 263 472 minecraft:polished_blackstone_bricks
fill 425 263 473 425 266 473 minecraft:blackstone
setblock 425 263 476 minecraft:blackstone
setblock 425 263 477 minecraft:polished_blackstone_bricks
fill 425 263 478 426 265 478 minecraft:blackstone
setblock 425 263 492 minecraft:polished_blackstone_bricks
fill 425 263 493 425 266 493 minecraft:blackstone
setblock 425 263 497 minecraft:polished_blackstone_bricks
fill 425 263 498 425 266 498 minecraft:blackstone
fill 425 263 500 425 263 501 minecraft:blackstone
setblock 425 263 502 minecraft:polished_blackstone_bricks
setblock 426 263 466 minecraft:polished_blackstone_bricks
fill 426 263 467 426 265 467 minecraft:blackstone
setblock 426 263 471 minecraft:polished_blackstone_bricks
fill 426 263 472 426 266 472 minecraft:blackstone
setblock 426 263 476 minecraft:polished_blackstone_bricks
fill 426 263 477 426 266 477 minecraft:blackstone
setblock 427 263 465 minecraft:polished_blackstone_bricks
setblock 427 263 466 minecraft:blackstone
setblock 427 263 470 minecraft:polished_blackstone_bricks
fill 427 263 471 427 264 471 minecraft:blackstone
setblock 428 263 464 minecraft:polished_blackstone_bricks
fill 428 263 465 428 265 465 minecraft:blackstone
setblock 428 263 504 minecraft:polished_blackstone_bricks
fill 429 263 464 429 266 464 minecraft:blackstone
fill 429 263 504 429 266 504 minecraft:blackstone
fill 431 263 504 431 264 504 minecraft:blackstone
setblock 437 263 504 minecraft:blackstone
setblock 438 263 504 minecraft:polished_blackstone_bricks
fill 439 263 464 439 266 464 minecraft:blackstone
setblock 439 263 503 minecraft:polished_blackstone_bricks
fill 439 263 504 442 263 504 minecraft:blackstone
fill 440 263 503 440 266 503 minecraft:blackstone
fill 442 263 502 444 263 502 minecraft:blackstone
setblock 443 263 464 minecraft:polished_blackstone_bricks
setblock 443 263 503 minecraft:blackstone
setblock 443 263 504 minecraft:polished_blackstone_bricks
fill 444 263 464 444 266 464 minecraft:blackstone
setblock 444 263 503 minecraft:polished_blackstone_bricks
fill 444 263 504 444 266 504 minecraft:blackstone
setblock 445 263 502 minecraft:polished_blackstone_bricks
fill 445 263 503 445 266 503 minecraft:blackstone
setblock 448 263 504 minecraft:polished_blackstone_bricks
fill 449 263 504 449 265 504 minecraft:blackstone
fill 461 263 473 461 263 475 minecraft:blackstone
setblock 462 263 464 minecraft:blackstone
setblock 462 263 469 minecraft:blackstone
setblock 462 263 470 minecraft:polished_blackstone_bricks
fill 462 263 471 462 263 474 minecraft:blackstone
setblock 462 263 475 minecraft:polished_blackstone_bricks
fill 462 263 476 462 266 476 minecraft:blackstone
setblock 462 263 479 minecraft:blackstone
setblock 462 263 480 minecraft:polished_blackstone_bricks
fill 462 263 491 462 265 491 minecraft:blackstone
setblock 462 263 495 minecraft:polished_blackstone_bricks
setblock 463 263 464 minecraft:polished_blackstone_bricks
setblock 463 263 469 minecraft:polished_blackstone_bricks
fill 463 263 470 463 263 473 minecraft:blackstone
setblock 463 263 474 minecraft:polished_blackstone_bricks
fill 463 263 475 463 266 475 minecraft:blackstone
setblock 463 263 478 minecraft:blackstone
setblock 463 263 479 minecraft:polished_blackstone_bricks
fill 463 263 480 463 266 480 minecraft:blackstone
fill 463 263 482 463 263 483 minecraft:blackstone
setblock 463 263 484 minecraft:polished_blackstone_bricks
fill 463 263 485 463 266 485 minecraft:blackstone
setblock 463 263 489 minecraft:polished_blackstone_bricks
fill 463 263 490 463 266 490 minecraft:blackstone
setblock 463 263 494 minecraft:polished_blackstone_bricks
fill 463 263 495 463 266 495 minecraft:blackstone
setblock 463 263 499 minecraft:polished_blackstone_bricks
fill 464 263 464 464 266 464 minecraft:blackstone
setblock 464 263 468 minecraft:polished_blackstone_bricks
fill 464 263 469 464 266 469 minecraft:blackstone
setblock 464 263 473 minecraft:polished_blackstone_bricks
fill 464 263 474 464 266 474 minecraft:blackstone
setblock 464 263 478 minecraft:polished_blackstone_bricks
fill 464 263 479 464 266 479 minecraft:blackstone
setblock 464 263 483 minecraft:polished_blackstone_bricks
fill 464 263 484 464 266 484 minecraft:blackstone
setblock 464 263 488 minecraft:polished_blackstone_bricks
fill 464 263 489 464 266 489 minecraft:blackstone
setblock 464 263 493 minecraft:polished_blackstone_bricks
fill 464 263 494 464 266 494 minecraft:blackstone
setblock 464 263 497 minecraft:blackstone
setblock 464 263 498 minecraft:polished_blackstone_bricks
fill 464 263 499 464 266 499 minecraft:blackstone
setblock 464 263 502 minecraft:blackstone
setblock 464 263 503 minecraft:polished_blackstone_bricks
setblock 424 264 467 minecraft:polished_blackstone_bricks
fill 424 264 468 424 267 468 minecraft:blackstone
setblock 424 264 472 minecraft:polished_blackstone_bricks
fill 424 264 473 424 267 473 minecraft:blackstone
setblock 424 264 477 minecraft:polished_blackstone_bricks
fill 424 264 478 424 267 478 minecraft:blackstone
setblock 424 264 482 minecraft:polished_blackstone_bricks
fill 424 264 483 424 267 483 minecraft:blackstone
setblock 424 264 487 minecraft:polished_blackstone_bricks
fill 424 264 488 424 266 488 minecraft:blackstone
setblock 424 264 492 minecraft:polished_blackstone_bricks
fill 424 264 493 424 267 493 minecraft:blackstone
setblock 424 264 496 minecraft:blackstone
setblock 424 264 497 minecraft:polished_blackstone_bricks
fill 424 264 498 424 267 498 minecraft:blackstone
setblock 424 264 502 minecraft:polished_blackstone_bricks
fill 424 264 503 427 264 503 minecraft:blackstone
setblock 425 264 466 minecraft:polished_blackstone_bricks
fill 425 264 467 425 267 467 minecraft:blackstone
setblock 425 264 471 minecraft:polished_blackstone_bricks
fill 425 264 472 425 267 472 minecraft:blackstone
setblock 425 264 476 minecraft:polished_blackstone_bricks
fill 425 264 477 425 267 477 minecraft:blackstone
setblock 425 264 481 minecraft:polished_blackstone_bricks
setblock 425 264 491 minecraft:polished_blackstone_bricks
fill 425 264 492 425 266 492 minecraft:blackstone
setblock 425 264 496 minecraft:polished_blackstone_bricks
fill 425 264 497 426 266 497 minecraft:blackstone
setblock 425 264 500 minecraft:blackstone
setblock 425 264 501 minecraft:polished_blackstone_bricks
fill 425 264 502 425 267 502 minecraft:blackstone
setblock 426 264 465 minecraft:polished_blackstone_bricks
fill 426 264 466 426 265 466 minecraft:blackstone
setblock 426 264 470 minecraft:polished_blackstone_bricks
fill 426 264 471 426 267 471 minecraft:blackstone
setblock 426 264 475 minecraft:polished_blackstone_bricks
fill 426 264 476 426 267 476 minecraft:blackstone
setblock 426 264 482 minecraft:light[level=11]
setblock 426 264 490 minecraft:light[level=11]
setblock 426 264 495 minecraft:polished_blackstone_bricks
fill 426 264 496 426 266 496 minecraft:blackstone
fill 426 264 498 426 265 498 minecraft:blackstone
setblock 427 264 464 minecraft:polished_blackstone_bricks
fill 427 264 465 427 267 465 minecraft:blackstone
setblock 427 264 474 minecraft:polished_blackstone_bricks
setblock 427 264 504 minecraft:polished_blackstone_bricks
fill 428 264 464 428 267 464 minecraft:blackstone
fill 428 264 504 428 267 504 minecraft:blackstone
setblock 431 264 464 minecraft:blackstone
setblock 432 264 504 minecraft:polished_blackstone_bricks
fill 433 264 504 436 264 504 minecraft:blackstone
setblock 434 264 466 minecraft:light[level=11]
setblock 434 264 474 minecraft:light[level=11]
setblock 434 264 482 minecraft:light[level=11]
setblock 434 264 490 minecraft:light[level=11]
setblock 434 264 498 minecraft:light[level=11]
setblock 437 264 504 minecraft:polished_blackstone_bricks
fill 438 264 464 438 267 464 minecraft:blackstone
setblock 438 264 503 minecraft:polished_blackstone_bricks
fill 438 264 504 441 264 504 minecraft:blackstone
fill 439 264 503 439 267 503 minecraft:blackstone
fill 440 264 502 443 264 502 minecraft:blackstone
setblock 442 264 464 minecraft:polished_blackstone_bricks
setblock 442 264 466 minecraft:light[level=11]
setblock 442 264 474 minecraft:light[level=11]
setblock 442 264 482 minecraft:light[level=11]
setblock 442 264 490 minecraft:light[level=11]
setblock 442 264 498 minecraft:light[level=11]
setblock 442 264 504 minecraft:polished_blackstone_bricks
fill 443 264 464 443 267 464 minecraft:blackstone
fill 443 264 501 443 265 501 minecraft:blackstone
setblock 443 264 503 minecraft:polished_blackstone_bricks
fill 443 264 504 443 267 504 minecraft:blackstone
setblock 444 264 502 minecraft:polished_blackstone_bricks
fill 444 264 503 444 267 503 minecraft:blackstone
fill 445 264 502 446 266 502 minecraft:blackstone
setblock 447 264 504 minecraft:polished_blackstone_bricks
fill 448 264 504 448 267 504 minecraft:blackstone
setblock 450 264 466 minecraft:light[level=11]
setblock 450 264 474 minecraft:light[level=11]
setblock 450 264 482 minecraft:light[level=11]
setblock 450 264 490 minecraft:light[level=11]
setblock 450 264 498 minecraft:light[level=11]
setblock 458 264 466 minecraft:light[level=11]
setblock 458 264 474 minecraft:light[level=11]
setblock 458 264 482 minecraft:light[level=11]
setblock 458 264 490 minecraft:light[level=11]
setblock 458 264 498 minecraft:light[level=11]
setblock 461 264 464 minecraft:blackstone
fill 461 264 472 461 264 474 minecraft:blackstone
setblock 461 264 475 minecraft:polished_blackstone_bricks
fill 461 264 476 461 265 478 minecraft:blackstone
setblock 462 264 464 minecraft:polished_blackstone_bricks
setblock 462 264 468 minecraft:blackstone
setblock 462 264 469 minecraft:polished_blackstone_bricks
fill 462 264 470 462 264 473 minecraft:blackstone
setblock 462 264 474 minecraft:polished_blackstone_bricks
fill 462 264 475 462 267 475 minecraft:blackstone
setblock 462 264 479 minecraft:polished_blackstone_bricks
fill 462 264 480 462 265 482 minecraft:blackstone
fill 462 264 492 462 264 493 minecraft:blackstone
setblock 462 264 494 minecraft:polished_blackstone_bricks
fill 462 264 495 462 265 497 minecraft:blackstone
fill 463 264 464 463 266 465 minecraft:blackstone
setblock 463 264 468 minecraft:polished_blackstone_bricks
fill 463 264 469 463 264 472 minecraft:blackstone
setblock 463 264 473 minecraft:polished_blackstone_bricks
fill 463 264 474 463 267 474 minecraft:blackstone
setblock 463 264 478 minecraft:polished_blackstone_bricks
fill 463 264 479 463 267 479 minecraft:blackstone
setblock 463 264 482 minecraft:blackstone
setblock 463 264 483 minecraft:polished_blackstone_bricks
fill 463 264 484 463 267 484 minecraft:blackstone
setblock 463 264 488 minecraft:polished_blackstone_bricks
fill 463 264 489 463 267 489 minecraft:blackstone
setblock 463 264 493 minecraft:polished_blackstone_bricks
fill 463 264 494 463 267 494 minecraft:blackstone
fill 463 264 496 463 264 497 minecraft:blackstone
setblock 463 264 498 minecraft:polished_blackstone_bricks
fill 463 264 499 463 266 500 minecraft:blackstone
fill 463 264 504 464 266 504 minecraft:blackstone
setblock 464 264 467 minecraft:polished_blackstone_bricks
fill 464 264 468 464 267 468 minecraft:blackstone
setblock 464 264 472 minecraft:polished_blackstone_bricks
fill 464 264 473 464 267 473 minecraft:blackstone
setblock 464 264 477 minecraft:polished_blackstone_bricks
fill 464 264 478 464 267 478 minecraft:blackstone
setblock 464 264 482 minecraft:polished_blackstone_bricks
fill 464 264 483 464 267 483 minecraft:blackstone
setblock 464 264 487 minecraft:polished_blackstone_bricks
fill 464 264 488 464 267 488 minecraft:blackstone
setblock 464 264 492 minecraft:polished_blackstone_bricks
fill 464 264 493 464 267 493 minecraft:blackstone
setblock 464 264 497 minecraft:polished_blackstone_bricks
fill 464 264 498 464 267 498 minecraft:blackstone
setblock 464 264 502 minecraft:polished_blackstone_bricks
fill 464 264 503 464 267 503 minecraft:blackstone
setblock 424 265 466 minecraft:polished_blackstone_bricks
fill 424 265 467 424 268 467 minecraft:blackstone
setblock 424 265 471 minecraft:polished_blackstone_bricks
fill 424 265 472 424 268 472 minecraft:blackstone
setblock 424 265 476 minecraft:polished_blackstone_bricks
fill 424 265 477 424 268 477 minecraft:blackstone
setblock 424 265 480 minecraft:blackstone
setblock 424 265 481 minecraft:polished_blackstone_bricks
fill 424 265 482 424 268 482 minecraft:blackstone
setblock 424 265 486 minecraft:polished_blackstone_bricks
fill 424 265 487 424 266 487 minecraft:blackstone
setblock 424 265 491 minecraft:polished_blackstone_bricks
fill 424 265 492 424 268 492 minecraft:blackstone
setblock 424 265 496 minecraft:polished_blackstone_bricks
fill 424 265 497 424 268 497 minecraft:blackstone
setblock 424 265 501 minecraft:polished_blackstone_bricks
fill 424 265 502 424 267 503 minecraft:blackstone
setblock 425 265 465 minecraft:polished_blackstone_bricks
fill 425 265 466 425 268 466 minecraft:blackstone
setblock 425 265 470 minecraft:polished_blackstone_bricks
fill 425 265 471 425 268 471 minecraft:blackstone
setblock 425 265 475 minecraft:polished_blackstone_bricks
fill 425 265 476 425 268 476 minecraft:blackstone
setblock 425 265 480 minecraft:polished_blackstone_bricks
fill 425 265 481 425 268 481 minecraft:blackstone
setblock 425 265 491 minecraft:blackstone
setblock 425 265 495 minecraft:polished_blackstone_bricks
fill 425 265 496 425 268 496 minecraft:blackstone
setblock 425 265 500 minecraft:polished_blackstone_bricks
fill 425 265 501 425 268 501 minecraft:blackstone
fill 425 265 503 426 265 503 minecraft:blackstone
setblock 426 265 464 minecraft:polished_blackstone_bricks
fill 426 265 465 426 268 465 minecraft:blackstone
setblock 426 265 469 minecraft:polished_blackstone_bricks
fill 426 265 470 426 266 470 minecraft:blackstone
setblock 426 265 474 minecraft:polished_blackstone_bricks
fill 426 265 475 426 268 475 minecraft:blackstone
setblock 426 265 495 minecraft:blackstone
setblock 426 265 499 minecraft:polished_blackstone_bricks
fill 426 265 500 426 268 500 minecraft:blackstone
setblock 426 265 504 minecraft:polished_blackstone_bricks
fill 427 265 464 427 268 464 minecraft:blackstone
setblock 427 265 503 minecraft:polished_blackstone_bricks
fill 427 265 504 427 268 504 minecraft:blackstone
fill 428 265 487 428 266 487 minecraft:polished_blackstone_bricks
fill 428 265 489 428 266 489 minecraft:polished_blackstone_bricks
fill 428 265 503 428 268 503 minecraft:blackstone
setblock 431 265 464 minecraft:polished_blackstone_bricks
setblock 431 265 504 minecraft:polished_blackstone_bricks
fill 432 265 504 435 265 504 minecraft:blackstone
setblock 436 265 503 minecraft:blackstone
setblock 436 265 504 minecraft:polished_blackstone_bricks
setblock 437 265 503 minecraft:polished_blackstone_bricks
fill 437 265 504 440 265 504 minecraft:blackstone
setblock 438 265 502 minecraft:polished_blackstone_bricks
fill 438 265 503 438 268 503 minecraft:blackstone
fill 439 265 502 442 265 502 minecraft:blackstone
setblock 441 265 464 minecraft:polished_blackstone_bricks
fill 441 265 501 442 266 501 minecraft:blackstone
setblock 441 265 503 minecraft:blackstone
setblock 441 265 504 minecraft:polished_blackstone_bricks
fill 442 265 464 442 268 464 minecraft:blackstone
setblock 442 265 503 minecraft:polished_blackstone_bricks
fill 442 265 504 442 268 504 minecraft:blackstone
setblock 443 265 502 minecraft:polished_blackstone_bricks
fill 443 265 503 443 268 503 minecraft:blackstone
setblock 444 265 501 minecraft:polished_blackstone_bricks
fill 444 265 502 444 268 502 minecraft:blackstone
fill 445 265 501 445 266 501 minecraft:blackstone
setblock 446 265 503 minecraft:blackstone
setblock 446 265 504 minecraft:polished_blackstone_bricks
setblock 447 265 503 minecraft:polished_blackstone_bricks
fill 447 265 504 447 268 504 minecraft:blackstone
fill 458 265 495 459 266 495 minecraft:cyan_stained_glass
setblock 460 265 464 minecraft:blackstone
setblock 461 265 464 minecraft:polished_blackstone_bricks
fill 461 265 471 461 265 473 minecraft:blackstone
setblock 461 265 474 minecraft:polished_blackstone_bricks
fill 461 265 475 461 268 475 minecraft:blackstone
setblock 461 265 479 minecraft:polished_blackstone_bricks
setblock 461 265 504 minecraft:polished_blackstone_bricks
fill 462 265 464 462 267 465 minecraft:blackstone
setblock 462 265 468 minecraft:polished_blackstone_bricks
fill 462 265 469 462 265 472 minecraft:blackstone
setblock 462 265 473 minecraft:polished_blackstone_bricks
fill 462 265 474 462 268 474 minecraft:blackstone
setblock 462 265 477 minecraft:blackstone
setblock 462 265 478 minecraft:polished_blackstone_bricks
fill 462 265 479 462 268 479 minecraft:blackstone
setblock 462 265 483 minecraft:polished_blackstone_bricks
setblock 462 265 492 minecraft:blackstone
setblock 462 265 493 minecraft:polished_blackstone_bricks
fill 462 265 494 462 266 494 minecraft:blackstone
setblock 462 265 498 minecraft:polished_blackstone_bricks
fill 462 265 504 462 268 504 minecraft:blackstone
setblock 463 265 467 minecraft:polished_blackstone_bricks
fill 463 265 468 463 265 471 minecraft:blackstone
setblock 463 265 472 minecraft:polished_blackstone_bricks
fill 463 265 473 463 268 473 minecraft:blackstone
setblock 463 265 477 minecraft:polished_blackstone_bricks
fill 463 265 478 463 268 478 minecraft:blackstone
setblock 463 265 482 minecraft:polished_blackstone_bricks
fill 463 265 483 463 268 483 minecraft:blackstone
setblock 463 265 487 minecraft:polished_blackstone_bricks
fill 463 265 488 463 267 488 minecraft:blackstone
setblock 463 265 492 minecraft:polished_blackstone_bricks
fill 463 265 493 463 268 493 minecraft:blackstone
setblock 463 265 496 minecraft:blackstone
setblock 463 265 497 minecraft:polished_blackstone_bricks
fill 463 265 498 463 268 498 minecraft:blackstone
setblock 463 265 501 minecraft:blackstone
setblock 464 265 466 minecraft:polished_blackstone_bricks
fill 464 265 467 464 268 467 minecraft:blackstone
setblock 464 265 471 minecraft:polished_blackstone_bricks
fill 464 265 472 464 268 472 minecraft:blackstone
setblock 464 265 476 minecraft:polished_blackstone_bricks
fill 464 265 477 464 268 477 minecraft:blackstone
setblock 464 265 481 minecraft:polished_blackstone_bricks
fill 464 265 482 464 268 482 minecraft:blackstone
setblock 464 265 486 minecraft:polished_blackstone_bricks
fill 464 265 487 464 268 487 minecraft:blackstone
setblock 464 265 491 minecraft:polished_blackstone_bricks
fill 464 265 492 464 268 492 minecraft:blackstone
setblock 464 265 496 minecraft:polished_blackstone_bricks
fill 464 265 497 464 268 497 minecraft:blackstone
setblock 464 265 500 minecraft:blackstone
setblock 464 265 501 minecraft:polished_blackstone_bricks
fill 464 265 502 464 268 502 minecraft:blackstone
setblock 424 266 465 minecraft:polished_blackstone_bricks
fill 424 266 466 424 269 466 minecraft:blackstone
setblock 424 266 470 minecraft:polished_blackstone_bricks
fill 424 266 471 424 269 471 minecraft:blackstone
setblock 424 266 475 minecraft:polished_blackstone_bricks
fill 424 266 476 424 269 476 minecraft:blackstone
setblock 424 266 480 minecraft:polished_blackstone_bricks
fill 424 266 481 424 269 481 minecraft:blackstone
setblock 424 266 485 minecraft:polished_blackstone_bricks
setblock 424 266 486 minecraft:blackstone
setblock 424 266 490 minecraft:polished_blackstone_bricks
fill 424 266 491 424 267 491 minecraft:blackstone
setblock 424 266 495 minecraft:polished_blackstone_bricks
fill 424 266 496 424 269 496 minecraft:blackstone
setblock 424 266 500 minecraft:polished_blackstone_bricks
fill 424 266 501 424 269 501 minecraft:blackstone
setblock 425 266 464 minecraft:polished_blackstone_bricks
fill 425 266 465 425 269 465 minecraft:blackstone
setblock 425 266 469 minecraft:polished_blackstone_bricks
fill 425 266 470 425 269 470 minecraft:blackstone
setblock 425 266 474 minecraft:polished_blackstone_bricks
fill 425 266 475 425 269 475 minecraft:blackstone
setblock 425 266 478 minecraft:blackstone
setblock 425 266 479 minecraft:polished_blackstone_bricks
fill 425 266 480 425 269 480 minecraft:blackstone
setblock 425 266 494 minecraft:polished_blackstone_bricks
fill 425 266 495 425 268 495 minecraft:blackstone
setblock 425 266 499 minecraft:polished_blackstone_bricks
fill 425 266 500 425 269 500 minecraft:blackstone
setblock 425 266 503 minecraft:blackstone
setblock 425 266 504 minecraft:polished_blackstone_bricks
fill 426 266 464 426 269 464 minecraft:blackstone
setblock 426 266 468 minecraft:polished_blackstone_bricks
setblock 426 266 469 minecraft:blackstone
setblock 426 266 473 minecraft:polished_blackstone_bricks
fill 426 266 474 426 268 474 minecraft:blackstone
setblock 426 266 478 minecraft:polished_blackstone_bricks
setblock 426 266 498 minecraft:polished_blackstone_bricks
fill 426 266 499 426 268 499 minecraft:blackstone
fill 426 266 501 426 267 501 minecraft:blackstone
setblock 426 266 503 minecraft:polished_blackstone_bricks
fill 426 266 504 426 269 504 minecraft:blackstone
fill 427 266 503 427 269 503 minecraft:blackstone
fill 429 266 503 429 267 503 minecraft:blackstone
setblock 430 266 464 minecraft:polished_blackstone_bricks
setblock 430 266 504 minecraft:polished_blackstone_bricks
setblock 431 266 464 minecraft:blackstone
fill 431 266 504 434 266 504 minecraft:blackstone
setblock 435 266 503 minecraft:blackstone
setblock 435 266 504 minecraft:polished_blackstone_bricks
setblock 436 266 503 minecraft:polished_blackstone_bricks
fill 436 266 504 439 266 504 minecraft:blackstone
fill 437 266 464 437 268 464 minecraft:blackstone
setblock 437 266 502 minecraft:polished_blackstone_bricks
fill 437 266 503 437 269 503 minecraft:blackstone
fill 438 266 502 441 266 502 minecraft:blackstone
fill 439 266 501 440 268 501 minecraft:blackstone
setblock 440 266 464 minecraft:polished_blackstone_bricks
setblock 440 266 504 minecraft:polished_blackstone_bricks
fill 441 266 464 441 269 464 minecraft:blackstone
setblock 441 266 503 minecraft:polished_blackstone_bricks
fill 441 266 504 441 269 504 minecraft:blackstone
setblock 442 266 502 minecraft:polished_blackstone_bricks
fill 442 266 503 442 269 503 minecraft:blackstone
setblock 443 266 501 minecraft:polished_blackstone_bricks
fill 443 266 502 443 269 502 minecraft:blackstone
fill 444 266 501 444 268 501 minecraft:blackstone
setblock 445 266 464 minecraft:polished_blackstone_bricks
setblock 445 266 504 minecraft:polished_blackstone_bricks
setblock 446 266 503 minecraft:polished_blackstone_bricks
fill 446 266 504 446 269 504 minecraft:blackstone
fill 447 266 503 447 267 503 minecraft:blackstone
setblock 460 266 464 minecraft:polished_blackstone_bricks
setblock 460 266 504 minecraft:polished_blackstone_bricks
fill 461 266 464 461 269 464 minecraft:blackstone
fill 461 266 471 461 266 472 minecraft:blackstone
setblock 461 266 473 minecraft:polished_blackstone_bricks
fill 461 266 474 461 269 474 minecraft:blackstone
fill 461 266 476 461 266 477 minecraft:blackstone
setblock 461 266 478 minecraft:polished_blackstone_bricks
fill 461 266 479 461 268 480 minecraft:blackstone
fill 461 266 504 461 269 504 minecraft:blackstone
fill 462 266 468 462 266 471 minecraft:blackstone
setblock 462 266 472 minecraft:polished_blackstone_bricks
fill 462 266 473 462 269 473 minecraft:blackstone
setblock 462 266 477 minecraft:polished_blackstone_bricks
fill 462 266 478 462 269 478 minecraft:blackstone
fill 462 266 480 462 266 481 minecraft:blackstone
setblock 462 266 482 minecraft:polished_blackstone_bricks
fill 462 266 483 462 269 483 minecraft:blackstone
setblock 462 266 493 minecraft:blackstone
fill 462 266 495 462 266 496 minecraft:blackstone
setblock 462 266 497 minecraft:polished_blackstone_bricks
fill 462 266 498 462 267 499 minecraft:blackstone
setblock 463 266 466 minecraft:polished_blackstone_bricks
fill 463 266 467 463 266 470 minecraft:blackstone
setblock 463 266 471 minecraft:polished_blackstone_bricks
fill 463 266 472 463 269 472 minecraft:blackstone
setblock 463 266 476 minecraft:polished_blackstone_bricks
fill 463 266 477 463 269 477 minecraft:blackstone
setblock 463 266 481 minecraft:polished_blackstone_bricks
fill 463 266 482 463 269 482 minecraft:blackstone
setblock 463 266 486 minecraft:polished_blackstone_bricks
fill 463 266 487 463 267 487 minecraft:blackstone
setblock 463 266 491 minecraft:polished_blackstone_bricks
fill 463 266 492 463 267 492 minecraft:blackstone
setblock 463 266 496 minecraft:polished_blackstone_bricks
fill 463 266 497 463 269 497 minecraft:blackstone
setblock 463 266 501 minecraft:polished_blackstone_bricks
fill 463 266 502 463 269 502 minecraft:blackstone
setblock 464 266 465 minecraft:polished_blackstone_bricks
fill 464 266 466 464 269 466 minecraft:blackstone
setblock 464 266 470 minecraft:polished_blackstone_bricks
fill 464 266 471 464 269 471 minecraft:blackstone
setblock 464 266 475 minecraft:polished_blackstone_bricks
fill 464 266 476 464 269 476 minecraft:blackstone
setblock 464 266 480 minecraft:polished_blackstone_bricks
fill 464 266 481 464 269 481 minecraft:blackstone
setblock 464 266 485 minecraft:polished_blackstone_bricks
fill 464 266 486 464 269 486 minecraft:blackstone
setblock 464 266 490 minecraft:polished_blackstone_bricks
fill 464 266 491 464 268 491 minecraft:blackstone
setblock 464 266 495 minecraft:polished_blackstone_bricks
fill 464 266 496 464 269 496 minecraft:blackstone
setblock 464 266 500 minecraft:polished_blackstone_bricks
fill 464 266 501 464 269 501 minecraft:blackstone
setblock 424 267 464 minecraft:polished_blackstone_bricks
fill 424 267 465 424 270 465 minecraft:blackstone
setblock 424 267 469 minecraft:polished_blackstone_bricks
fill 424 267 470 424 270 470 minecraft:blackstone
setblock 424 267 474 minecraft:polished_blackstone_bricks
fill 424 267 475 424 270 475 minecraft:blackstone
setblock 424 267 479 minecraft:polished_blackstone_bricks
fill 424 267 480 424 270 480 minecraft:blackstone
setblock 424 267 484 minecraft:polished_blackstone_bricks
setblock 424 267 485 minecraft:blackstone
setblock 424 267 490 minecraft:blackstone
setblock 424 267 494 minecraft:polished_blackstone_bricks
fill 424 267 495 424 270 495 minecraft:blackstone
setblock 424 267 499 minecraft:polished_blackstone_bricks
fill 424 267 500 424 270 500 minecraft:blackstone
setblock 424 267 504 minecraft:polished_blackstone_bricks
fill 425 267 464 425 270 464 minecraft:blackstone
setblock 425 267 468 minecraft:polished_blackstone_bricks
fill 425 267 469 425 268 469 minecraft:blackstone
setblock 425 267 473 minecraft:polished_blackstone_bricks
fill 425 267 474 425 270 474 minecraft:blackstone
setblock 425 267 478 minecraft:polished_blackstone_bricks
fill 425 267 479 430 268 479 minecraft:blackstone
setblock 425 267 494 minecraft:blackstone
setblock 425 267 497 minecraft:blackstone
setblock 425 267 498 minecraft:polished_blackstone_bricks
fill 425 267 499 425 270 499 minecraft:blackstone
setblock 425 267 503 minecraft:polished_blackstone_bricks
fill 425 267 504 425 270 504 minecraft:blackstone
setblock 426 267 472 minecraft:polished_blackstone_bricks
setblock 426 267 473 minecraft:blackstone
setblock 426 267 477 minecraft:polished_blackstone_bricks
fill 426 267 478 430 268 478 minecraft:blackstone
setblock 426 267 497 minecraft:polished_blackstone_bricks
setblock 426 267 498 minecraft:blackstone
fill 426 267 503 426 270 503 minecraft:blackstone
fill 427 267 475 430 268 477 minecraft:blackstone
setblock 429 267 464 minecraft:polished_blackstone_bricks
setblock 429 267 504 minecraft:polished_blackstone_bricks
setblock 430 267 464 minecraft:blackstone
setblock 430 267 503 minecraft:polished_blackstone_bricks
fill 430 267 504 433 267 504 minecraft:blackstone
fill 433 267 503 434 267 503 minecraft:blackstone
setblock 434 267 504 minecraft:polished_blackstone_bricks
setblock 435 267 503 minecraft:polished_blackstone_bricks
fill 435 267 504 438 267 504 minecraft:blackstone
setblock 436 267 502 minecraft:polished_blackstone_bricks
fill 436 267 503 436 270 503 minecraft:blackstone
fill 437 267 502 440 267 502 minecraft:blackstone
fill 438 267 501 438 270 501 minecraft:blackstone
setblock 439 267 464 minecraft:polished_blackstone_bricks
setblock 439 267 504 minecraft:polished_blackstone_bricks
fill 440 267 464 440 270 464 minecraft:blackstone
setblock 440 267 503 minecraft:polished_blackstone_bricks
fill 440 267 504 440 270 504 minecraft:blackstone
setblock 441 267 501 minecraft:blackstone
setblock 441 267 502 minecraft:polished_blackstone_bricks
fill 441 267 503 441 270 503 minecraft:blackstone
setblock 442 267 501 minecraft:polished_blackstone_bricks
fill 442 267 502 442 270 502 minecraft:blackstone
fill 443 267 501 443 269 501 minecraft:blackstone
setblock 444 267 464 minecraft:polished_blackstone_bricks
setblock 444 267 504 minecraft:polished_blackstone_bricks
setblock 445 267 502 minecraft:blackstone
setblock 445 267 503 minecraft:polished_blackstone_bricks
fill 445 267 504 445 270 504 minecraft:blackstone
setblock 446 267 502 minecraft:polished_blackstone_bricks
fill 446 267 503 446 269 503 minecraft:blackstone
setblock 459 267 464 minecraft:polished_blackstone_bricks
setblock 459 267 504 minecraft:polished_blackstone_bricks
fill 460 267 464 460 270 464 minecraft:blackstone
fill 460 267 504 460 270 504 minecraft:blackstone
setblock 461 267 472 minecraft:polished_blackstone_bricks
fill 461 267 473 461 269 473 minecraft:blackstone
setblock 461 267 476 minecraft:blackstone
setblock 461 267 477 minecraft:polished_blackstone_bricks
fill 461 267 478 461 270 478 minecraft:blackstone
setblock 461 267 481 minecraft:blackstone
fill 462 267 469 462 267 470 minecraft:blackstone
setblock 462 267 471 minecraft:polished_blackstone_bricks
fill 462 267 472 462 270 472 minecraft:blackstone
setblock 462 267 476 minecraft:polished_blackstone_bricks
fill 462 267 477 462 270 477 minecraft:blackstone
setblock 462 267 480 minecraft:blackstone
setblock 462 267 481 minecraft:polished_blackstone_bricks
fill 462 267 482 462 270 482 minecraft:blackstone
setblock 462 267 495 minecraft:blackstone
setblock 462 267 496 minecraft:polished_blackstone_bricks
setblock 462 267 497 minecraft:blackstone
fill 462 267 503 463 268 503 minecraft:blackstone
setblock 463 267 464 minecraft:blackstone
setblock 463 267 465 minecraft:polished_blackstone_bricks
fill 463 267 466 463 267 469 minecraft:blackstone
setblock 463 267 470 minecraft:polished_blackstone_bricks
fill 463 267 471 463 270 471 minecraft:blackstone
setblock 463 267 475 minecraft:polished_blackstone_bricks
fill 463 267 476 463 270 476 minecraft:blackstone
setblock 463 267 480 minecraft:polished_blackstone_bricks
fill 463 267 481 463 270 481 minecraft:blackstone
setblock 463 267 485 minecraft:polished_blackstone_bricks
fill 463 267 486 463 268 486 minecraft:blackstone
setblock 463 267 490 minecraft:polished_blackstone_bricks
setblock 463 267 491 minecraft:blackstone
setblock 463 267 495 minecraft:polished_blackstone_bricks
fill 463 267 496 463 269 496 minecraft:blackstone
setblock 463 267 499 minecraft:blackstone
setblock 463 267 500 minecraft:polished_blackstone_bricks
fill 463 267 501 463 270 501 minecraft:blackstone
setblock 463 267 504 minecraft:blackstone
setblock 464 267 464 minecraft:polished_blackstone_bricks
fill 464 267 465 464 270 465 minecraft:blackstone
setblock 464 267 469 minecraft:polished_blackstone_bricks
fill 464 267 470 464 270 470 minecraft:blackstone
setblock 464 267 474 minecraft:polished_blackstone_bricks
fill 464 267 475 464 270 475 minecraft:blackstone
setblock 464 267 479 minecraft:polished_blackstone_bricks
fill 464 267 480 464 270 480 minecraft:blackstone
setblock 464 267 484 minecraft:polished_blackstone_bricks
fill 464 267 485 464 270 485 minecraft:blackstone
setblock 464 267 489 minecraft:polished_blackstone_bricks
fill 464 267 490 464 268 490 minecraft:blackstone
setblock 464 267 494 minecraft:polished_blackstone_bricks
fill 464 267 495 464 270 495 minecraft:blackstone
setblock 464 267 499 minecraft:polished_blackstone_bricks
fill 464 267 500 464 270 500 minecraft:blackstone
setblock 464 267 504 minecraft:polished_blackstone_bricks
fill 424 268 464 424 271 464 minecraft:blackstone
setblock 424 268 468 minecraft:polished_blackstone_bricks
fill 424 268 469 424 271 469 minecraft:blackstone
setblock 424 268 473 minecraft:polished_blackstone_bricks
fill 424 268 474 424 271 474 minecraft:blackstone
setblock 424 268 478 minecraft:polished_blackstone_bricks
fill 424 268 479 424 271 479 minecraft:blackstone
setblock 424 268 483 minecraft:polished_blackstone_bricks
setblock 424 268 484 minecraft:blackstone
setblock 424 268 493 minecraft:polished_blackstone_bricks
fill 424 268 494 424 269 494 minecraft:blackstone
setblock 424 268 498 minecraft:polished_blackstone_bricks
fill 424 268 499 424 271 499 minecraft:blackstone
setblock 424 268 502 minecraft:blackstone
setblock 424 268 503 minecraft:polished_blackstone_bricks
fill 424 268 504 424 271 504 minecraft:blackstone
setblock 425 268 467 minecraft:polished_blackstone_bricks
setblock 425 268 468 minecraft:blackstone
setblock 425 268 472 minecraft:polished_blackstone_bricks
fill 425 268 473 425 269 473 minecraft:blackstone
setblock 425 268 477 minecraft:polished_blackstone_bricks
fill 425 268 478 425 270 478 minecraft:blackstone
setblock 425 268 497 minecraft:polished_blackstone_bricks
fill 425 268 498 425 270 498 minecraft:blackstone
setblock 425 268 502 minecraft:polished_blackstone_bricks
fill 425 268 503 425 271 503 minecraft:blackstone
setblock 426 268 476 minecraft:polished_blackstone_bricks
setblock 426 268 477 minecraft:blackstone
setblock 426 268 501 minecraft:polished_blackstone_bricks
setblock 428 268 464 minecraft:polished_blackstone_bricks
setblock 428 268 504 minecraft:polished_blackstone_bricks
setblock 429 268 464 minecraft:blackstone
setblock 429 268 503 minecraft:polished_blackstone_bricks
fill 429 268 504 432 268 504 minecraft:blackstone
fill 430 268 503 433 268 503 minecraft:blackstone
setblock 433 268 504 minecraft:polished_blackstone_bricks
setblock 434 268 503 minecraft:polished_blackstone_bricks
fill 434 268 504 437 268 504 minecraft:blackstone
fill 435 268 503 435 271 503 minecraft:blackstone
fill 436 268 502 439 268 502 minecraft:blackstone
setblock 438 268 464 minecraft:polished_blackstone_bricks
setblock 438 268 504 minecraft:polished_blackstone_bricks
fill 439 268 464 439 271 464 minecraft:blackstone
setblock 439 268 503 minecraft:polished_blackstone_bricks
fill 439 268 504 439 271 504 minecraft:blackstone
setblock 440 268 502 minecraft:polished_blackstone_bricks
fill 440 268 503 440 271 503 minecraft:blackstone
setblock 441 268 501 minecraft:polished_blackstone_bricks
fill 441 268 502 441 271 502 minecraft:blackstone
fill 442 268 501 442 270 501 minecraft:blackstone
schedule function dropper:buildpart/117_8 1t
