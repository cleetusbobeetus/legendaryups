setblock 403 112 278 minecraft:light[level=15]
setblock 403 112 286 minecraft:light[level=15]
setblock 403 112 294 minecraft:light[level=15]
setblock 403 112 302 minecraft:light[level=15]
setblock 403 112 310 minecraft:light[level=15]
setblock 403 112 315 minecraft:stripped_oak_log
fill 403 112 316 403 115 316 minecraft:red_terracotta
setblock 404 112 313 minecraft:red_terracotta
setblock 404 112 314 minecraft:stripped_oak_log
fill 404 112 315 404 115 315 minecraft:red_terracotta
setblock 405 112 277 minecraft:red_terracotta
setblock 405 112 313 minecraft:stripped_oak_log
fill 405 112 314 405 115 314 minecraft:red_terracotta
setblock 406 112 277 minecraft:stripped_oak_log
fill 406 112 313 406 113 313 minecraft:red_terracotta
setblock 407 112 276 minecraft:stripped_oak_log
fill 407 112 277 407 115 277 minecraft:red_terracotta
setblock 407 112 316 minecraft:stripped_oak_log
fill 408 112 276 408 115 276 minecraft:red_terracotta
setblock 408 112 315 minecraft:stripped_oak_log
fill 408 112 316 408 115 316 minecraft:red_terracotta
setblock 409 112 314 minecraft:stripped_oak_log
fill 409 112 315 409 115 315 minecraft:red_terracotta
fill 410 112 314 410 113 314 minecraft:red_terracotta
setblock 411 112 277 minecraft:stripped_oak_log
setblock 411 112 278 minecraft:light[level=15]
setblock 411 112 286 minecraft:light[level=15]
setblock 411 112 294 minecraft:light[level=15]
setblock 411 112 302 minecraft:light[level=15]
setblock 411 112 310 minecraft:light[level=15]
setblock 412 112 276 minecraft:stripped_oak_log
setblock 412 112 316 minecraft:stripped_oak_log
fill 413 112 276 413 115 276 minecraft:red_terracotta
setblock 413 112 315 minecraft:stripped_oak_log
fill 413 112 316 413 115 316 minecraft:red_terracotta
setblock 414 112 315 minecraft:red_terracotta
setblock 415 112 293 minecraft:stripped_oak_log
fill 415 112 294 415 113 294 minecraft:red_terracotta
setblock 415 112 298 minecraft:stripped_oak_log
setblock 416 112 292 minecraft:stripped_oak_log
fill 416 112 293 416 115 293 minecraft:red_terracotta
setblock 416 112 297 minecraft:stripped_oak_log
fill 416 112 298 416 115 298 minecraft:red_terracotta
setblock 416 112 301 minecraft:red_terracotta
setblock 417 112 291 minecraft:stripped_oak_log
fill 417 112 292 417 115 292 minecraft:red_terracotta
setblock 417 112 296 minecraft:stripped_oak_log
fill 417 112 297 417 115 297 minecraft:red_terracotta
setblock 417 112 301 minecraft:stripped_oak_log
fill 417 112 302 417 115 302 minecraft:red_terracotta
setblock 417 112 316 minecraft:stripped_oak_log
fill 418 112 276 418 115 316 minecraft:orange_terracotta
fill 377 113 276 377 116 276 minecraft:red_terracotta
setblock 377 113 280 minecraft:stripped_oak_log
fill 377 113 281 377 116 281 minecraft:red_terracotta
setblock 377 113 290 minecraft:stripped_oak_log
fill 377 113 291 377 115 291 minecraft:red_terracotta
setblock 377 113 295 minecraft:stripped_oak_log
fill 377 113 296 377 116 296 minecraft:red_terracotta
setblock 377 113 300 minecraft:stripped_oak_log
fill 377 113 316 380 113 316 minecraft:red_terracotta
setblock 378 113 294 minecraft:stripped_oak_log
fill 378 113 295 378 114 295 minecraft:red_terracotta
setblock 379 113 277 minecraft:red_terracotta
setblock 380 113 277 minecraft:stripped_oak_log
setblock 381 113 276 minecraft:stripped_oak_log
fill 381 113 277 381 116 277 minecraft:red_terracotta
setblock 381 113 316 minecraft:stripped_oak_log
fill 382 113 276 382 116 276 minecraft:red_terracotta
fill 382 113 278 383 113 278 minecraft:red_terracotta
setblock 382 113 315 minecraft:stripped_oak_log
fill 382 113 316 382 116 316 minecraft:red_terracotta
fill 383 113 315 383 116 315 minecraft:red_terracotta
setblock 384 113 278 minecraft:stripped_oak_log
setblock 385 113 277 minecraft:stripped_oak_log
fill 385 113 278 385 115 279 minecraft:red_terracotta
fill 385 113 314 387 113 314 minecraft:red_terracotta
setblock 386 113 276 minecraft:stripped_oak_log
fill 386 113 277 386 116 277 minecraft:red_terracotta
setblock 386 113 316 minecraft:stripped_oak_log
fill 387 113 276 387 116 276 minecraft:red_terracotta
setblock 387 113 279 minecraft:red_terracotta
setblock 387 113 315 minecraft:stripped_oak_log
fill 387 113 316 387 116 316 minecraft:red_terracotta
setblock 388 113 279 minecraft:stripped_oak_log
setblock 388 113 314 minecraft:stripped_oak_log
fill 388 113 315 388 116 315 minecraft:red_terracotta
setblock 389 113 278 minecraft:stripped_oak_log
setblock 389 113 279 minecraft:red_terracotta
fill 389 113 314 389 115 314 minecraft:red_terracotta
setblock 390 113 277 minecraft:stripped_oak_log
fill 390 113 278 390 116 278 minecraft:red_terracotta
setblock 391 113 276 minecraft:stripped_oak_log
fill 391 113 277 391 116 277 minecraft:red_terracotta
setblock 391 113 316 minecraft:stripped_oak_log
fill 392 113 276 392 116 276 minecraft:red_terracotta
setblock 392 113 315 minecraft:stripped_oak_log
fill 392 113 316 395 113 316 minecraft:red_terracotta
fill 393 113 278 393 149 278 minecraft:stripped_oak_log
setblock 393 113 314 minecraft:stripped_oak_log
fill 393 113 315 396 113 315 minecraft:red_terracotta
setblock 395 113 277 minecraft:stripped_oak_log
setblock 396 113 276 minecraft:stripped_oak_log
fill 396 113 277 396 114 277 minecraft:red_terracotta
setblock 396 113 316 minecraft:stripped_oak_log
fill 397 113 276 400 113 276 minecraft:red_terracotta
fill 397 113 277 397 149 277 minecraft:stripped_oak_log
setblock 397 113 315 minecraft:stripped_oak_log
fill 397 113 316 397 116 316 minecraft:red_terracotta
fill 398 113 315 398 115 315 minecraft:red_terracotta
setblock 401 113 276 minecraft:stripped_oak_log
fill 401 113 277 401 116 277 minecraft:red_terracotta
setblock 401 113 316 minecraft:stripped_oak_log
fill 402 113 276 402 116 276 minecraft:red_terracotta
setblock 402 113 315 minecraft:stripped_oak_log
fill 402 113 316 402 116 316 minecraft:red_terracotta
setblock 403 113 314 minecraft:stripped_oak_log
fill 403 113 315 403 116 315 minecraft:red_terracotta
fill 404 113 314 404 115 314 minecraft:red_terracotta
setblock 405 113 277 minecraft:stripped_oak_log
setblock 405 113 313 minecraft:red_terracotta
setblock 406 113 276 minecraft:stripped_oak_log
fill 406 113 277 406 116 277 minecraft:red_terracotta
setblock 406 113 316 minecraft:stripped_oak_log
fill 407 113 276 407 116 276 minecraft:red_terracotta
setblock 407 113 315 minecraft:stripped_oak_log
fill 407 113 316 407 116 316 minecraft:red_terracotta
setblock 408 113 314 minecraft:stripped_oak_log
fill 408 113 315 408 116 315 minecraft:red_terracotta
setblock 409 113 277 minecraft:red_terracotta
fill 409 113 314 409 114 314 minecraft:red_terracotta
setblock 410 113 277 minecraft:stripped_oak_log
setblock 411 113 276 minecraft:stripped_oak_log
setblock 411 113 277 minecraft:red_terracotta
setblock 411 113 316 minecraft:stripped_oak_log
fill 412 113 276 412 116 276 minecraft:red_terracotta
setblock 412 113 315 minecraft:stripped_oak_log
fill 412 113 316 412 115 316 minecraft:red_terracotta
setblock 413 113 315 minecraft:red_terracotta
setblock 415 113 297 minecraft:stripped_oak_log
fill 415 113 298 415 114 298 minecraft:red_terracotta
setblock 416 113 291 minecraft:stripped_oak_log
fill 416 113 292 416 114 292 minecraft:red_terracotta
setblock 416 113 296 minecraft:stripped_oak_log
fill 416 113 297 416 116 297 minecraft:red_terracotta
setblock 416 113 316 minecraft:stripped_oak_log
setblock 417 113 290 minecraft:stripped_oak_log
fill 417 113 291 417 115 291 minecraft:red_terracotta
setblock 417 113 295 minecraft:stripped_oak_log
fill 417 113 296 417 116 296 minecraft:red_terracotta
setblock 417 113 300 minecraft:stripped_oak_log
fill 417 113 301 417 116 301 minecraft:red_terracotta
setblock 417 113 316 minecraft:red_terracotta
setblock 377 114 278 minecraft:red_terracotta
setblock 377 114 279 minecraft:stripped_oak_log
fill 377 114 280 377 117 280 minecraft:red_terracotta
fill 377 114 282 377 115 282 minecraft:red_terracotta
setblock 377 114 289 minecraft:stripped_oak_log
fill 377 114 290 377 115 290 minecraft:red_terracotta
setblock 377 114 294 minecraft:stripped_oak_log
fill 377 114 295 377 117 295 minecraft:red_terracotta
setblock 377 114 299 minecraft:stripped_oak_log
fill 377 114 300 377 115 300 minecraft:red_terracotta
setblock 378 114 277 minecraft:red_terracotta
setblock 378 114 278 minecraft:stripped_oak_log
setblock 378 114 293 minecraft:stripped_oak_log
setblock 378 114 294 minecraft:red_terracotta
setblock 379 114 277 minecraft:stripped_oak_log
setblock 379 114 278 minecraft:light[level=12]
setblock 379 114 285 minecraft:light[level=12]
setblock 379 114 292 minecraft:light[level=12]
setblock 379 114 299 minecraft:light[level=12]
setblock 379 114 306 minecraft:light[level=12]
setblock 379 114 316 minecraft:red_terracotta
setblock 380 114 276 minecraft:stripped_oak_log
fill 380 114 277 380 117 277 minecraft:red_terracotta
setblock 380 114 316 minecraft:stripped_oak_log
fill 381 114 276 381 117 276 minecraft:red_terracotta
fill 381 114 278 382 114 278 minecraft:red_terracotta
fill 381 114 316 381 117 316 minecraft:red_terracotta
fill 382 114 315 382 115 315 minecraft:red_terracotta
setblock 383 114 278 minecraft:stripped_oak_log
setblock 384 114 277 minecraft:stripped_oak_log
fill 384 114 278 384 117 278 minecraft:red_terracotta
setblock 385 114 276 minecraft:stripped_oak_log
fill 385 114 277 385 117 277 minecraft:red_terracotta
fill 385 114 314 386 114 314 minecraft:red_terracotta
setblock 385 114 316 minecraft:stripped_oak_log
fill 386 114 276 386 117 276 minecraft:red_terracotta
setblock 386 114 285 minecraft:light[level=12]
setblock 386 114 292 minecraft:light[level=12]
setblock 386 114 299 minecraft:light[level=12]
setblock 386 114 306 minecraft:light[level=12]
setblock 386 114 313 minecraft:light[level=12]
setblock 386 114 315 minecraft:stripped_oak_log
fill 386 114 316 386 117 316 minecraft:red_terracotta
setblock 387 114 279 minecraft:stripped_oak_log
setblock 387 114 314 minecraft:stripped_oak_log
fill 387 114 315 387 117 315 minecraft:red_terracotta
setblock 388 114 278 minecraft:stripped_oak_log
fill 388 114 279 388 115 279 minecraft:red_terracotta
fill 388 114 314 388 115 314 minecraft:red_terracotta
setblock 389 114 277 minecraft:stripped_oak_log
fill 389 114 278 389 117 278 minecraft:red_terracotta
setblock 390 114 276 minecraft:stripped_oak_log
fill 390 114 277 390 117 277 minecraft:red_terracotta
setblock 390 114 316 minecraft:stripped_oak_log
fill 391 114 276 391 117 276 minecraft:red_terracotta
setblock 391 114 315 minecraft:stripped_oak_log
fill 391 114 316 394 114 316 minecraft:red_terracotta
fill 392 114 315 395 114 315 minecraft:red_terracotta
setblock 393 114 285 minecraft:light[level=12]
setblock 393 114 292 minecraft:light[level=12]
setblock 393 114 299 minecraft:light[level=12]
setblock 393 114 306 minecraft:light[level=12]
setblock 393 114 313 minecraft:light[level=12]
setblock 394 114 277 minecraft:stripped_oak_log
setblock 395 114 276 minecraft:stripped_oak_log
fill 395 114 277 395 115 277 minecraft:red_terracotta
setblock 395 114 316 minecraft:stripped_oak_log
fill 396 114 276 399 114 276 minecraft:red_terracotta
setblock 396 114 315 minecraft:stripped_oak_log
fill 396 114 316 396 117 316 minecraft:red_terracotta
fill 397 114 315 397 115 315 minecraft:red_terracotta
setblock 400 114 276 minecraft:stripped_oak_log
setblock 400 114 278 minecraft:light[level=12]
setblock 400 114 285 minecraft:light[level=12]
setblock 400 114 292 minecraft:light[level=12]
setblock 400 114 299 minecraft:light[level=12]
setblock 400 114 306 minecraft:light[level=12]
setblock 400 114 313 minecraft:light[level=12]
setblock 400 114 316 minecraft:stripped_oak_log
fill 401 114 276 401 117 276 minecraft:red_terracotta
setblock 401 114 315 minecraft:stripped_oak_log
fill 401 114 316 401 117 316 minecraft:red_terracotta
setblock 402 114 314 minecraft:stripped_oak_log
fill 402 114 315 402 117 315 minecraft:red_terracotta
fill 403 114 314 403 115 314 minecraft:red_terracotta
setblock 404 114 276 minecraft:red_terracotta
setblock 404 114 277 minecraft:stripped_oak_log
setblock 405 114 276 minecraft:stripped_oak_log
fill 405 114 277 405 117 277 minecraft:red_terracotta
setblock 405 114 316 minecraft:stripped_oak_log
fill 406 114 276 406 117 276 minecraft:red_terracotta
setblock 406 114 315 minecraft:stripped_oak_log
fill 406 114 316 406 117 316 minecraft:red_terracotta
setblock 407 114 278 minecraft:light[level=12]
setblock 407 114 285 minecraft:light[level=12]
setblock 407 114 292 minecraft:light[level=12]
setblock 407 114 299 minecraft:light[level=12]
setblock 407 114 306 minecraft:light[level=12]
setblock 407 114 313 minecraft:light[level=12]
setblock 407 114 314 minecraft:stripped_oak_log
fill 407 114 315 407 117 315 minecraft:red_terracotta
fill 408 114 314 408 115 314 minecraft:red_terracotta
setblock 409 114 277 minecraft:stripped_oak_log
setblock 410 114 276 minecraft:stripped_oak_log
setblock 410 114 277 minecraft:red_terracotta
setblock 410 114 316 minecraft:stripped_oak_log
fill 411 114 276 411 116 276 minecraft:red_terracotta
setblock 411 114 315 minecraft:stripped_oak_log
fill 411 114 316 411 116 316 minecraft:red_terracotta
setblock 412 114 315 minecraft:red_terracotta
setblock 414 114 278 minecraft:light[level=12]
setblock 414 114 285 minecraft:light[level=12]
setblock 414 114 292 minecraft:light[level=12]
setblock 414 114 299 minecraft:light[level=12]
setblock 414 114 306 minecraft:light[level=12]
setblock 414 114 313 minecraft:light[level=12]
setblock 415 114 296 minecraft:stripped_oak_log
setblock 415 114 297 minecraft:red_terracotta
setblock 415 114 316 minecraft:stripped_oak_log
setblock 416 114 295 minecraft:stripped_oak_log
fill 416 114 296 416 117 296 minecraft:red_terracotta
setblock 416 114 300 minecraft:stripped_oak_log
setblock 417 114 290 minecraft:red_terracotta
setblock 417 114 294 minecraft:stripped_oak_log
fill 417 114 295 417 117 295 minecraft:red_terracotta
setblock 417 114 299 minecraft:stripped_oak_log
fill 417 114 300 417 117 300 minecraft:red_terracotta
setblock 377 115 278 minecraft:stripped_oak_log
fill 377 115 279 378 117 279 minecraft:red_terracotta
setblock 377 115 293 minecraft:stripped_oak_log
fill 377 115 294 377 117 294 minecraft:red_terracotta
setblock 377 115 298 minecraft:stripped_oak_log
fill 377 115 299 377 118 299 minecraft:red_terracotta
setblock 378 115 277 minecraft:stripped_oak_log
fill 378 115 278 378 118 278 minecraft:red_terracotta
setblock 379 115 276 minecraft:stripped_oak_log
fill 379 115 277 379 118 277 minecraft:red_terracotta
setblock 379 115 316 minecraft:stripped_oak_log
fill 380 115 276 380 118 276 minecraft:red_terracotta
fill 380 115 316 380 118 316 minecraft:red_terracotta
setblock 381 115 278 minecraft:red_terracotta
setblock 382 115 278 minecraft:stripped_oak_log
setblock 383 115 277 minecraft:stripped_oak_log
fill 383 115 278 383 118 278 minecraft:red_terracotta
setblock 384 115 276 minecraft:stripped_oak_log
fill 384 115 277 384 118 277 minecraft:red_terracotta
fill 384 115 279 384 116 279 minecraft:red_terracotta
setblock 384 115 316 minecraft:stripped_oak_log
fill 385 115 276 385 118 276 minecraft:red_terracotta
setblock 385 115 315 minecraft:stripped_oak_log
fill 385 115 316 385 118 316 minecraft:red_terracotta
setblock 386 115 278 minecraft:red_terracotta
setblock 386 115 279 minecraft:stripped_oak_log
setblock 386 115 314 minecraft:stripped_oak_log
fill 386 115 315 386 118 315 minecraft:red_terracotta
setblock 387 115 278 minecraft:stripped_oak_log
fill 387 115 279 387 116 279 minecraft:red_terracotta
setblock 387 115 314 minecraft:red_terracotta
setblock 388 115 277 minecraft:stripped_oak_log
fill 388 115 278 388 118 278 minecraft:red_terracotta
setblock 389 115 276 minecraft:stripped_oak_log
fill 389 115 277 389 118 277 minecraft:red_terracotta
setblock 389 115 316 minecraft:stripped_oak_log
fill 390 115 276 390 118 276 minecraft:red_terracotta
setblock 390 115 315 minecraft:stripped_oak_log
fill 390 115 316 393 115 316 minecraft:red_terracotta
fill 391 115 315 394 115 315 minecraft:red_terracotta
fill 392 115 278 392 149 278 minecraft:stripped_oak_log
setblock 393 115 277 minecraft:stripped_oak_log
setblock 394 115 276 minecraft:stripped_oak_log
setblock 394 115 277 minecraft:red_terracotta
setblock 394 115 316 minecraft:stripped_oak_log
fill 395 115 276 398 115 276 minecraft:red_terracotta
setblock 395 115 315 minecraft:stripped_oak_log
fill 395 115 316 395 118 316 minecraft:red_terracotta
fill 396 115 277 396 149 277 minecraft:stripped_oak_log
setblock 396 115 315 minecraft:red_terracotta
setblock 399 115 276 minecraft:stripped_oak_log
setblock 399 115 316 minecraft:stripped_oak_log
fill 400 115 276 400 118 276 minecraft:red_terracotta
setblock 400 115 315 minecraft:stripped_oak_log
fill 400 115 316 400 118 316 minecraft:red_terracotta
fill 401 115 315 401 118 315 minecraft:red_terracotta
setblock 402 115 277 minecraft:red_terracotta
setblock 402 115 314 minecraft:red_terracotta
setblock 403 115 277 minecraft:stripped_oak_log
setblock 404 115 276 minecraft:stripped_oak_log
fill 404 115 277 404 118 277 minecraft:red_terracotta
setblock 404 115 316 minecraft:stripped_oak_log
fill 405 115 276 405 118 276 minecraft:red_terracotta
setblock 405 115 315 minecraft:stripped_oak_log
fill 405 115 316 405 118 316 minecraft:red_terracotta
setblock 406 115 314 minecraft:stripped_oak_log
fill 406 115 315 406 118 315 minecraft:red_terracotta
setblock 407 115 314 minecraft:red_terracotta
setblock 408 115 277 minecraft:stripped_oak_log
setblock 409 115 276 minecraft:stripped_oak_log
setblock 409 115 277 minecraft:red_terracotta
setblock 409 115 316 minecraft:stripped_oak_log
fill 410 115 276 410 117 276 minecraft:red_terracotta
setblock 410 115 315 minecraft:stripped_oak_log
fill 410 115 316 410 117 316 minecraft:red_terracotta
setblock 416 115 294 minecraft:stripped_oak_log
fill 416 115 295 416 116 295 minecraft:red_terracotta
setblock 416 115 299 minecraft:stripped_oak_log
fill 416 115 300 416 116 300 minecraft:red_terracotta
setblock 417 115 293 minecraft:stripped_oak_log
fill 417 115 294 417 118 294 minecraft:red_terracotta
setblock 417 115 298 minecraft:stripped_oak_log
fill 417 115 299 417 118 299 minecraft:red_terracotta
fill 376 116 275 376 119 317 minecraft:red_terracotta
fill 377 116 275 418 119 275 minecraft:red_terracotta
setblock 377 116 277 minecraft:stripped_oak_log
fill 377 116 278 377 119 278 minecraft:red_terracotta
setblock 377 116 282 minecraft:stripped_oak_log
setblock 377 116 292 minecraft:stripped_oak_log
setblock 377 116 293 minecraft:red_terracotta
setblock 377 116 297 minecraft:stripped_oak_log
fill 377 116 298 377 119 298 minecraft:red_terracotta
fill 377 116 317 418 119 317 minecraft:red_terracotta
setblock 378 116 276 minecraft:stripped_oak_log
fill 378 116 277 378 119 277 minecraft:red_terracotta
fill 378 116 313 378 117 313 minecraft:brown_terracotta
fill 379 116 276 379 119 276 minecraft:red_terracotta
fill 379 116 312 379 117 312 minecraft:brown_terracotta
fill 379 116 314 379 117 314 minecraft:brown_terracotta
setblock 380 116 278 minecraft:red_terracotta
fill 380 116 313 380 117 313 minecraft:brown_terracotta
setblock 381 116 278 minecraft:stripped_oak_log
setblock 382 116 277 minecraft:stripped_oak_log
fill 382 116 278 382 119 278 minecraft:red_terracotta
setblock 383 116 276 minecraft:stripped_oak_log
fill 383 116 277 383 119 277 minecraft:red_terracotta
setblock 383 116 316 minecraft:stripped_oak_log
fill 384 116 276 384 119 276 minecraft:red_terracotta
setblock 384 116 315 minecraft:stripped_oak_log
fill 384 116 316 384 119 316 minecraft:red_terracotta
setblock 385 116 278 minecraft:red_terracotta
setblock 385 116 279 minecraft:stripped_oak_log
fill 385 116 315 385 119 315 minecraft:red_terracotta
setblock 386 116 278 minecraft:stripped_oak_log
fill 386 116 279 386 118 279 minecraft:red_terracotta
setblock 387 116 277 minecraft:stripped_oak_log
fill 387 116 278 387 119 278 minecraft:red_terracotta
setblock 388 116 276 minecraft:stripped_oak_log
fill 388 116 277 388 119 277 minecraft:red_terracotta
setblock 388 116 316 minecraft:stripped_oak_log
fill 389 116 276 389 119 276 minecraft:red_terracotta
setblock 389 116 315 minecraft:stripped_oak_log
fill 389 116 316 392 116 316 minecraft:red_terracotta
fill 390 116 315 392 116 315 minecraft:red_terracotta
setblock 392 116 277 minecraft:stripped_oak_log
setblock 393 116 276 minecraft:stripped_oak_log
setblock 393 116 277 minecraft:red_terracotta
setblock 393 116 316 minecraft:stripped_oak_log
fill 394 116 276 397 116 276 minecraft:red_terracotta
fill 394 116 277 395 139 277 minecraft:stripped_oak_log
fill 394 116 316 394 119 316 minecraft:red_terracotta
setblock 398 116 276 minecraft:stripped_oak_log
setblock 398 116 316 minecraft:stripped_oak_log
fill 399 116 276 399 119 276 minecraft:red_terracotta
setblock 399 116 315 minecraft:stripped_oak_log
fill 399 116 316 399 119 316 minecraft:red_terracotta
fill 400 116 315 400 117 315 minecraft:red_terracotta
setblock 402 116 277 minecraft:stripped_oak_log
setblock 403 116 276 minecraft:stripped_oak_log
fill 403 116 277 403 119 277 minecraft:red_terracotta
setblock 403 116 316 minecraft:stripped_oak_log
fill 404 116 276 404 119 276 minecraft:red_terracotta
setblock 404 116 315 minecraft:stripped_oak_log
fill 404 116 316 404 119 316 minecraft:red_terracotta
setblock 405 116 314 minecraft:stripped_oak_log
fill 405 116 315 405 118 315 minecraft:red_terracotta
setblock 407 116 277 minecraft:stripped_oak_log
setblock 408 116 276 minecraft:stripped_oak_log
setblock 408 116 277 minecraft:red_terracotta
setblock 408 116 316 minecraft:stripped_oak_log
fill 409 116 276 409 118 276 minecraft:red_terracotta
setblock 409 116 315 minecraft:stripped_oak_log
fill 409 116 316 409 118 316 minecraft:red_terracotta
setblock 416 116 298 minecraft:stripped_oak_log
fill 416 116 299 416 117 299 minecraft:red_terracotta
setblock 417 116 292 minecraft:stripped_oak_log
fill 417 116 293 418 118 293 minecraft:red_terracotta
setblock 417 116 297 minecraft:stripped_oak_log
fill 417 116 298 418 119 298 minecraft:red_terracotta
setblock 417 116 302 minecraft:stripped_oak_log
fill 418 116 276 418 119 292 minecraft:red_terracotta
fill 418 116 294 418 119 297 minecraft:red_terracotta
fill 418 116 299 418 119 316 minecraft:red_terracotta
setblock 377 117 276 minecraft:stripped_oak_log
fill 377 117 277 377 120 277 minecraft:red_terracotta
setblock 377 117 281 minecraft:stripped_oak_log
fill 377 117 282 377 119 283 minecraft:red_terracotta
setblock 377 117 296 minecraft:stripped_oak_log
fill 377 117 297 377 119 297 minecraft:red_terracotta
fill 378 117 276 378 120 276 minecraft:red_terracotta
setblock 378 117 280 minecraft:stripped_oak_log
setblock 380 117 278 minecraft:stripped_oak_log
setblock 381 117 277 minecraft:stripped_oak_log
fill 381 117 278 381 120 278 minecraft:red_terracotta
setblock 382 117 276 minecraft:stripped_oak_log
fill 382 117 277 382 120 277 minecraft:red_terracotta
setblock 382 117 316 minecraft:stripped_oak_log
fill 383 117 276 383 120 276 minecraft:red_terracotta
setblock 383 117 279 minecraft:red_terracotta
setblock 383 117 315 minecraft:stripped_oak_log
fill 383 117 316 383 120 316 minecraft:red_terracotta
setblock 384 117 279 minecraft:stripped_oak_log
fill 384 117 315 384 120 315 minecraft:red_terracotta
setblock 385 117 278 minecraft:stripped_oak_log
fill 385 117 279 385 120 279 minecraft:red_terracotta
setblock 386 117 277 minecraft:stripped_oak_log
fill 386 117 278 386 120 278 minecraft:red_terracotta
setblock 387 117 276 minecraft:stripped_oak_log
fill 387 117 277 387 120 277 minecraft:red_terracotta
setblock 387 117 316 minecraft:stripped_oak_log
fill 388 117 276 388 120 276 minecraft:red_terracotta
setblock 388 117 315 minecraft:stripped_oak_log
fill 388 117 316 391 117 316 minecraft:red_terracotta
fill 389 117 315 390 117 315 minecraft:red_terracotta
setblock 390 117 278 minecraft:stripped_oak_log
setblock 391 117 277 minecraft:stripped_oak_log
setblock 392 117 276 minecraft:stripped_oak_log
setblock 392 117 277 minecraft:red_terracotta
setblock 392 117 316 minecraft:stripped_oak_log
fill 393 117 276 396 117 276 minecraft:red_terracotta
fill 393 117 277 393 140 277 minecraft:stripped_oak_log
fill 393 117 316 393 119 316 minecraft:red_terracotta
setblock 397 117 276 minecraft:stripped_oak_log
setblock 397 117 316 minecraft:stripped_oak_log
fill 398 117 276 398 120 276 minecraft:red_terracotta
fill 398 117 316 398 120 316 minecraft:red_terracotta
setblock 401 117 277 minecraft:stripped_oak_log
setblock 402 117 276 minecraft:stripped_oak_log
fill 402 117 277 402 120 277 minecraft:red_terracotta
setblock 402 117 316 minecraft:stripped_oak_log
fill 403 117 276 403 120 276 minecraft:red_terracotta
setblock 403 117 315 minecraft:stripped_oak_log
fill 403 117 316 403 120 316 minecraft:red_terracotta
fill 404 117 315 404 119 315 minecraft:red_terracotta
setblock 406 117 277 minecraft:stripped_oak_log
setblock 407 117 276 minecraft:stripped_oak_log
setblock 407 117 277 minecraft:red_terracotta
setblock 407 117 316 minecraft:stripped_oak_log
fill 408 117 276 408 119 276 minecraft:red_terracotta
fill 408 117 316 408 118 316 minecraft:red_terracotta
setblock 416 117 297 minecraft:stripped_oak_log
fill 416 117 298 416 118 298 minecraft:red_terracotta
setblock 417 117 296 minecraft:stripped_oak_log
fill 417 117 297 417 120 297 minecraft:red_terracotta
setblock 417 117 301 minecraft:stripped_oak_log
fill 417 117 302 417 120 302 minecraft:red_terracotta
fill 377 118 276 377 121 276 minecraft:red_terracotta
setblock 377 118 279 minecraft:red_terracotta
setblock 377 118 280 minecraft:stripped_oak_log
fill 377 118 281 378 120 281 minecraft:red_terracotta
setblock 377 118 284 minecraft:red_terracotta
setblock 377 118 296 minecraft:red_terracotta
setblock 378 118 279 minecraft:stripped_oak_log
fill 378 118 280 378 121 280 minecraft:red_terracotta
setblock 380 118 277 minecraft:stripped_oak_log
fill 380 118 278 380 121 278 minecraft:red_terracotta
setblock 381 118 276 minecraft:stripped_oak_log
fill 381 118 277 381 121 277 minecraft:red_terracotta
setblock 381 118 316 minecraft:stripped_oak_log
fill 382 118 276 382 121 276 minecraft:red_terracotta
fill 382 118 316 382 121 316 minecraft:red_terracotta
setblock 383 118 279 minecraft:stripped_oak_log
setblock 383 118 315 minecraft:red_terracotta
setblock 384 118 278 minecraft:stripped_oak_log
fill 384 118 279 384 121 279 minecraft:red_terracotta
setblock 385 118 277 minecraft:stripped_oak_log
fill 385 118 278 385 121 278 minecraft:red_terracotta
setblock 386 118 276 minecraft:stripped_oak_log
fill 386 118 277 386 121 277 minecraft:red_terracotta
setblock 386 118 316 minecraft:stripped_oak_log
fill 387 118 276 387 121 276 minecraft:red_terracotta
setblock 387 118 315 minecraft:stripped_oak_log
fill 387 118 316 390 118 316 minecraft:red_terracotta
setblock 388 118 315 minecraft:red_terracotta
setblock 389 118 278 minecraft:stripped_oak_log
setblock 390 118 277 minecraft:stripped_oak_log
setblock 391 118 276 minecraft:stripped_oak_log
fill 391 118 277 391 119 277 minecraft:red_terracotta
setblock 391 118 316 minecraft:stripped_oak_log
fill 392 118 276 395 118 276 minecraft:red_terracotta
fill 392 118 277 392 139 277 minecraft:stripped_oak_log
fill 392 118 316 392 119 316 minecraft:red_terracotta
setblock 396 118 276 minecraft:stripped_oak_log
setblock 396 118 316 minecraft:stripped_oak_log
fill 397 118 276 397 121 276 minecraft:red_terracotta
fill 397 118 316 397 121 316 minecraft:red_terracotta
setblock 401 118 276 minecraft:stripped_oak_log
setblock 401 118 316 minecraft:stripped_oak_log
fill 402 118 276 402 121 276 minecraft:red_terracotta
setblock 402 118 315 minecraft:stripped_oak_log
fill 402 118 316 402 121 316 minecraft:red_terracotta
fill 403 118 315 403 119 315 minecraft:red_terracotta
setblock 405 118 277 minecraft:stripped_oak_log
setblock 406 118 276 minecraft:stripped_oak_log
setblock 406 118 277 minecraft:red_terracotta
setblock 406 118 316 minecraft:stripped_oak_log
fill 407 118 276 407 121 276 minecraft:red_terracotta
fill 407 118 316 407 120 316 minecraft:red_terracotta
setblock 417 118 279 minecraft:red_terracotta
setblock 417 118 295 minecraft:stripped_oak_log
fill 417 118 296 417 121 296 minecraft:red_terracotta
setblock 417 118 300 minecraft:stripped_oak_log
fill 417 118 301 417 121 301 minecraft:red_terracotta
setblock 377 119 279 minecraft:stripped_oak_log
fill 377 119 280 377 122 280 minecraft:red_terracotta
setblock 377 119 284 minecraft:stripped_oak_log
fill 377 119 285 377 122 285 minecraft:red_terracotta
setblock 377 119 299 minecraft:stripped_oak_log
setblock 378 119 278 minecraft:stripped_oak_log
fill 378 119 279 379 121 279 minecraft:red_terracotta
setblock 378 119 282 minecraft:red_terracotta
setblock 378 119 283 minecraft:stripped_oak_log
setblock 379 119 277 minecraft:stripped_oak_log
fill 379 119 278 379 122 278 minecraft:red_terracotta
fill 379 119 280 379 120 280 minecraft:red_terracotta
setblock 380 119 276 minecraft:stripped_oak_log
fill 380 119 277 380 122 277 minecraft:red_terracotta
setblock 380 119 316 minecraft:stripped_oak_log
fill 381 119 276 381 122 276 minecraft:red_terracotta
fill 381 119 316 381 122 316 minecraft:red_terracotta
setblock 382 119 279 minecraft:stripped_oak_log
setblock 383 119 278 minecraft:stripped_oak_log
fill 383 119 279 383 122 279 minecraft:red_terracotta
setblock 384 119 277 minecraft:stripped_oak_log
fill 384 119 278 384 122 278 minecraft:red_terracotta
setblock 385 119 276 minecraft:stripped_oak_log
fill 385 119 277 385 122 277 minecraft:red_terracotta
setblock 385 119 316 minecraft:stripped_oak_log
fill 386 119 276 386 122 276 minecraft:red_terracotta
setblock 386 119 315 minecraft:stripped_oak_log
fill 386 119 316 389 119 316 minecraft:red_terracotta
setblock 387 119 315 minecraft:red_terracotta
setblock 388 119 278 minecraft:stripped_oak_log
setblock 389 119 277 minecraft:stripped_oak_log
setblock 390 119 276 minecraft:stripped_oak_log
fill 390 119 277 390 120 277 minecraft:red_terracotta
setblock 390 119 316 minecraft:stripped_oak_log
fill 391 119 276 394 119 276 minecraft:red_terracotta
fill 391 119 316 391 121 316 minecraft:red_terracotta
setblock 395 119 276 minecraft:stripped_oak_log
setblock 395 119 316 minecraft:stripped_oak_log
fill 396 119 276 396 122 276 minecraft:red_terracotta
fill 396 119 316 396 122 316 minecraft:red_terracotta
setblock 400 119 276 minecraft:stripped_oak_log
setblock 400 119 316 minecraft:stripped_oak_log
fill 401 119 276 401 122 276 minecraft:red_terracotta
fill 401 119 316 401 122 316 minecraft:red_terracotta
setblock 402 119 315 minecraft:red_terracotta
setblock 404 119 277 minecraft:stripped_oak_log
setblock 405 119 276 minecraft:stripped_oak_log
fill 405 119 277 405 120 277 minecraft:red_terracotta
setblock 405 119 316 minecraft:stripped_oak_log
fill 406 119 276 406 122 276 minecraft:red_terracotta
fill 406 119 316 406 121 316 minecraft:red_terracotta
setblock 417 119 278 minecraft:red_terracotta
setblock 417 119 279 minecraft:stripped_oak_log
fill 417 119 280 417 120 282 minecraft:red_terracotta
setblock 417 119 294 minecraft:stripped_oak_log
fill 417 119 295 417 122 295 minecraft:red_terracotta
setblock 417 119 299 minecraft:stripped_oak_log
fill 417 119 300 417 122 300 minecraft:red_terracotta
setblock 417 119 303 minecraft:red_terracotta
setblock 418 119 293 minecraft:red_terracotta
fill 376 120 275 376 123 317 minecraft:yellow_terracotta
fill 377 120 275 418 123 275 minecraft:yellow_terracotta
setblock 377 120 278 minecraft:stripped_oak_log
fill 377 120 279 377 123 279 minecraft:red_terracotta
setblock 377 120 282 minecraft:red_terracotta
setblock 377 120 283 minecraft:stripped_oak_log
fill 377 120 284 378 122 284 minecraft:red_terracotta
fill 377 120 286 377 121 286 minecraft:red_terracotta
setblock 377 120 298 minecraft:stripped_oak_log
fill 377 120 299 377 121 301 minecraft:red_terracotta
fill 377 120 317 418 123 317 minecraft:yellow_terracotta
setblock 378 120 277 minecraft:stripped_oak_log
fill 378 120 278 378 123 278 minecraft:red_terracotta
setblock 378 120 282 minecraft:stripped_oak_log
fill 378 120 283 378 123 283 minecraft:red_terracotta
setblock 379 120 276 minecraft:stripped_oak_log
fill 379 120 277 379 123 277 minecraft:red_terracotta
setblock 379 120 281 minecraft:stripped_oak_log
fill 379 120 282 379 123 282 minecraft:red_terracotta
setblock 379 120 285 minecraft:light[level=12]
setblock 379 120 286 minecraft:light[level=15]
setblock 379 120 292 minecraft:light[level=12]
setblock 379 120 294 minecraft:light[level=15]
setblock 379 120 299 minecraft:light[level=12]
setblock 379 120 302 minecraft:light[level=15]
setblock 379 120 306 minecraft:light[level=12]
setblock 379 120 310 minecraft:light[level=15]
setblock 379 120 313 minecraft:light[level=12]
fill 380 120 276 380 123 276 minecraft:red_terracotta
fill 380 120 316 380 123 316 minecraft:red_terracotta
setblock 381 120 279 minecraft:stripped_oak_log
setblock 382 120 278 minecraft:stripped_oak_log
fill 382 120 279 382 123 279 minecraft:red_terracotta
setblock 383 120 277 minecraft:stripped_oak_log
fill 383 120 278 383 123 278 minecraft:red_terracotta
setblock 384 120 276 minecraft:stripped_oak_log
fill 384 120 277 384 123 277 minecraft:red_terracotta
setblock 384 120 316 minecraft:stripped_oak_log
fill 385 120 276 385 123 276 minecraft:red_terracotta
setblock 385 120 315 minecraft:stripped_oak_log
fill 385 120 316 388 120 316 minecraft:red_terracotta
setblock 386 120 285 minecraft:light[level=12]
setblock 386 120 292 minecraft:light[level=12]
setblock 386 120 299 minecraft:light[level=12]
setblock 386 120 306 minecraft:light[level=12]
setblock 386 120 313 minecraft:light[level=12]
setblock 387 120 278 minecraft:stripped_oak_log
setblock 387 120 286 minecraft:light[level=15]
setblock 387 120 294 minecraft:light[level=15]
setblock 387 120 302 minecraft:light[level=15]
setblock 387 120 310 minecraft:light[level=15]
setblock 388 120 277 minecraft:stripped_oak_log
setblock 388 120 278 minecraft:red_terracotta
setblock 389 120 276 minecraft:stripped_oak_log
fill 389 120 277 389 122 277 minecraft:red_terracotta
setblock 389 120 316 minecraft:stripped_oak_log
fill 390 120 276 393 120 276 minecraft:red_terracotta
fill 390 120 316 390 123 316 minecraft:red_terracotta
setblock 393 120 285 minecraft:light[level=12]
setblock 393 120 292 minecraft:light[level=12]
setblock 393 120 299 minecraft:light[level=12]
setblock 393 120 306 minecraft:light[level=12]
setblock 393 120 313 minecraft:light[level=12]
fill 394 120 276 394 136 276 minecraft:stripped_oak_log
setblock 395 120 276 minecraft:red_terracotta
setblock 395 120 286 minecraft:light[level=15]
setblock 395 120 294 minecraft:light[level=15]
setblock 395 120 302 minecraft:light[level=15]
setblock 395 120 310 minecraft:light[level=15]
setblock 399 120 276 minecraft:stripped_oak_log
setblock 399 120 316 minecraft:stripped_oak_log
fill 400 120 276 400 123 276 minecraft:red_terracotta
setblock 400 120 278 minecraft:light[level=12]
setblock 400 120 285 minecraft:light[level=12]
setblock 400 120 292 minecraft:light[level=12]
setblock 400 120 299 minecraft:light[level=12]
setblock 400 120 306 minecraft:light[level=12]
setblock 400 120 313 minecraft:light[level=12]
fill 400 120 316 400 123 316 minecraft:red_terracotta
fill 401 120 277 401 121 277 minecraft:red_terracotta
setblock 403 120 277 minecraft:stripped_oak_log
setblock 403 120 278 minecraft:light[level=15]
setblock 403 120 286 minecraft:light[level=15]
setblock 403 120 294 minecraft:light[level=15]
setblock 403 120 302 minecraft:light[level=15]
setblock 403 120 310 minecraft:light[level=15]
setblock 404 120 276 minecraft:stripped_oak_log
fill 404 120 277 404 122 277 minecraft:red_terracotta
setblock 404 120 316 minecraft:stripped_oak_log
fill 405 120 276 405 123 276 minecraft:red_terracotta
fill 405 120 316 405 123 316 minecraft:red_terracotta
setblock 407 120 278 minecraft:light[level=12]
setblock 407 120 285 minecraft:light[level=12]
setblock 407 120 292 minecraft:light[level=12]
setblock 407 120 299 minecraft:light[level=12]
setblock 407 120 306 minecraft:light[level=12]
setblock 407 120 313 minecraft:light[level=12]
setblock 411 120 278 minecraft:light[level=15]
setblock 411 120 286 minecraft:light[level=15]
setblock 411 120 294 minecraft:light[level=15]
setblock 411 120 302 minecraft:light[level=15]
setblock 411 120 310 minecraft:light[level=15]
setblock 414 120 278 minecraft:light[level=12]
setblock 414 120 285 minecraft:light[level=12]
setblock 414 120 292 minecraft:light[level=12]
setblock 414 120 299 minecraft:light[level=12]
setblock 414 120 306 minecraft:light[level=12]
setblock 414 120 313 minecraft:light[level=12]
setblock 417 120 277 minecraft:red_terracotta
setblock 417 120 278 minecraft:stripped_oak_log
fill 417 120 279 417 123 279 minecraft:red_terracotta
setblock 417 120 283 minecraft:stripped_oak_log
fill 417 120 284 417 122 285 minecraft:red_terracotta
fill 417 120 294 417 123 294 minecraft:red_terracotta
setblock 417 120 298 minecraft:stripped_oak_log
fill 417 120 299 417 123 299 minecraft:red_terracotta
setblock 417 120 303 minecraft:stripped_oak_log
fill 417 120 304 417 123 304 minecraft:red_terracotta
fill 418 120 276 418 123 316 minecraft:yellow_terracotta
setblock 377 121 277 minecraft:stripped_oak_log
fill 377 121 278 377 124 278 minecraft:red_terracotta
setblock 377 121 281 minecraft:red_terracotta
setblock 377 121 282 minecraft:stripped_oak_log
fill 377 121 283 377 124 283 minecraft:red_terracotta
setblock 377 121 287 minecraft:stripped_oak_log
fill 377 121 288 377 124 288 minecraft:red_terracotta
setblock 377 121 297 minecraft:stripped_oak_log
fill 377 121 298 377 124 298 minecraft:red_terracotta
setblock 377 121 302 minecraft:stripped_oak_log
fill 377 121 303 377 124 303 minecraft:red_terracotta
setblock 378 121 276 minecraft:stripped_oak_log
fill 378 121 277 378 124 277 minecraft:red_terracotta
setblock 378 121 281 minecraft:stripped_oak_log
fill 378 121 282 378 124 282 minecraft:red_terracotta
setblock 378 121 285 minecraft:red_terracotta
fill 379 121 276 379 124 276 minecraft:red_terracotta
setblock 379 121 280 minecraft:stripped_oak_log
fill 379 121 281 380 123 281 minecraft:red_terracotta
fill 379 121 283 379 121 284 minecraft:red_terracotta
fill 379 121 316 379 124 316 minecraft:red_terracotta
setblock 380 121 279 minecraft:stripped_oak_log
fill 380 121 280 380 124 280 minecraft:red_terracotta
setblock 381 121 278 minecraft:stripped_oak_log
fill 381 121 279 381 124 279 minecraft:red_terracotta
setblock 382 121 277 minecraft:stripped_oak_log
fill 382 121 278 382 124 278 minecraft:red_terracotta
setblock 383 121 276 minecraft:stripped_oak_log
fill 383 121 277 383 124 277 minecraft:red_terracotta
setblock 383 121 315 minecraft:red_terracotta
setblock 383 121 316 minecraft:stripped_oak_log
fill 384 121 276 384 124 276 minecraft:red_terracotta
setblock 384 121 315 minecraft:stripped_oak_log
fill 384 121 316 387 121 316 minecraft:red_terracotta
setblock 385 121 279 minecraft:stripped_oak_log
fill 385 121 315 385 124 315 minecraft:red_terracotta
setblock 386 121 278 minecraft:stripped_oak_log
setblock 387 121 277 minecraft:stripped_oak_log
fill 387 121 278 387 122 278 minecraft:red_terracotta
setblock 388 121 276 minecraft:stripped_oak_log
fill 388 121 277 388 124 277 minecraft:red_terracotta
setblock 388 121 316 minecraft:stripped_oak_log
fill 389 121 276 392 121 276 minecraft:red_terracotta
fill 389 121 316 389 124 316 minecraft:red_terracotta
fill 393 121 276 393 136 276 minecraft:stripped_oak_log
setblock 395 121 276 minecraft:stripped_oak_log
setblock 398 121 276 minecraft:stripped_oak_log
setblock 398 121 316 minecraft:stripped_oak_log
fill 399 121 276 399 124 276 minecraft:red_terracotta
fill 399 121 316 399 123 316 minecraft:red_terracotta
setblock 402 121 277 minecraft:stripped_oak_log
setblock 403 121 276 minecraft:stripped_oak_log
fill 403 121 277 403 124 277 minecraft:red_terracotta
setblock 403 121 316 minecraft:stripped_oak_log
fill 404 121 276 404 124 276 minecraft:red_terracotta
fill 404 121 316 404 124 316 minecraft:red_terracotta
fill 416 121 299 416 122 301 minecraft:red_terracotta
setblock 417 121 276 minecraft:red_terracotta
setblock 417 121 277 minecraft:stripped_oak_log
fill 417 121 278 417 124 278 minecraft:red_terracotta
fill 417 121 280 417 121 281 minecraft:red_terracotta
setblock 417 121 282 minecraft:stripped_oak_log
fill 417 121 283 417 124 283 minecraft:red_terracotta
setblock 417 121 286 minecraft:red_terracotta
setblock 417 121 287 minecraft:stripped_oak_log
fill 417 121 288 417 124 288 minecraft:red_terracotta
fill 417 121 293 417 124 293 minecraft:red_terracotta
setblock 417 121 297 minecraft:stripped_oak_log
fill 417 121 298 417 124 298 minecraft:red_terracotta
setblock 417 121 302 minecraft:stripped_oak_log
fill 417 121 303 417 124 303 minecraft:red_terracotta
fill 417 121 305 417 122 305 minecraft:red_terracotta
setblock 377 122 276 minecraft:stripped_oak_log
fill 377 122 277 377 125 277 minecraft:red_terracotta
setblock 377 122 281 minecraft:stripped_oak_log
fill 377 122 282 377 125 282 minecraft:red_terracotta
setblock 377 122 286 minecraft:stripped_oak_log
fill 377 122 287 378 124 287 minecraft:red_terracotta
fill 377 122 289 377 123 289 minecraft:red_terracotta
fill 377 122 297 377 125 297 minecraft:red_terracotta
fill 377 122 299 377 122 300 minecraft:red_terracotta
setblock 377 122 301 minecraft:stripped_oak_log
fill 377 122 302 377 125 302 minecraft:red_terracotta
fill 377 122 304 377 122 305 minecraft:red_terracotta
fill 378 122 276 378 125 276 minecraft:red_terracotta
setblock 378 122 279 minecraft:red_terracotta
setblock 378 122 280 minecraft:stripped_oak_log
fill 378 122 281 378 125 281 minecraft:red_terracotta
setblock 378 122 285 minecraft:stripped_oak_log
fill 378 122 286 378 125 286 minecraft:red_terracotta
fill 378 122 316 378 125 316 minecraft:red_terracotta
setblock 379 122 279 minecraft:stripped_oak_log
fill 379 122 280 379 125 280 minecraft:red_terracotta
setblock 379 122 283 minecraft:red_terracotta
setblock 379 122 284 minecraft:stripped_oak_log
fill 379 122 285 379 125 285 minecraft:red_terracotta
setblock 380 122 278 minecraft:stripped_oak_log
fill 380 122 279 380 125 279 minecraft:red_terracotta
setblock 380 122 282 minecraft:red_terracotta
setblock 380 122 283 minecraft:stripped_oak_log
setblock 381 122 277 minecraft:stripped_oak_log
fill 381 122 278 381 125 278 minecraft:red_terracotta
setblock 382 122 276 minecraft:stripped_oak_log
fill 382 122 277 382 125 277 minecraft:red_terracotta
setblock 382 122 315 minecraft:red_terracotta
setblock 382 122 316 minecraft:stripped_oak_log
fill 383 122 276 383 125 276 minecraft:red_terracotta
setblock 383 122 315 minecraft:stripped_oak_log
fill 383 122 316 386 122 316 minecraft:red_terracotta
setblock 384 122 279 minecraft:stripped_oak_log
fill 384 122 315 384 125 315 minecraft:red_terracotta
setblock 385 122 278 minecraft:stripped_oak_log
setblock 385 122 279 minecraft:red_terracotta
setblock 386 122 277 minecraft:stripped_oak_log
fill 386 122 278 386 124 278 minecraft:red_terracotta
setblock 387 122 276 minecraft:stripped_oak_log
fill 387 122 277 387 125 277 minecraft:red_terracotta
setblock 387 122 316 minecraft:stripped_oak_log
fill 388 122 276 391 122 276 minecraft:red_terracotta
fill 388 122 316 388 125 316 minecraft:red_terracotta
setblock 392 122 276 minecraft:stripped_oak_log
fill 395 122 276 395 123 276 minecraft:red_terracotta
fill 395 122 316 395 123 316 minecraft:red_terracotta
setblock 397 122 276 minecraft:stripped_oak_log
setblock 397 122 316 minecraft:stripped_oak_log
fill 398 122 276 398 125 276 minecraft:red_terracotta
fill 398 122 316 398 123 316 minecraft:red_terracotta
setblock 400 122 277 minecraft:red_terracotta
setblock 401 122 277 minecraft:stripped_oak_log
setblock 402 122 276 minecraft:stripped_oak_log
fill 402 122 277 402 125 277 minecraft:red_terracotta
setblock 402 122 316 minecraft:stripped_oak_log
fill 403 122 276 403 125 276 minecraft:red_terracotta
fill 403 122 316 403 125 316 minecraft:red_terracotta
fill 416 122 279 416 122 281 minecraft:red_terracotta
setblock 416 122 282 minecraft:stripped_oak_log
fill 416 122 283 416 123 285 minecraft:red_terracotta
fill 416 122 298 416 125 298 minecraft:red_terracotta
setblock 416 122 302 minecraft:stripped_oak_log
setblock 417 122 276 minecraft:stripped_oak_log
fill 417 122 277 417 125 277 minecraft:red_terracotta
setblock 417 122 280 minecraft:red_terracotta
setblock 417 122 281 minecraft:stripped_oak_log
fill 417 122 282 417 125 282 minecraft:red_terracotta
setblock 417 122 286 minecraft:stripped_oak_log
fill 417 122 287 417 125 287 minecraft:red_terracotta
fill 417 122 289 417 122 290 minecraft:red_terracotta
setblock 417 122 291 minecraft:stripped_oak_log
fill 417 122 292 417 125 292 minecraft:red_terracotta
setblock 417 122 296 minecraft:stripped_oak_log
fill 417 122 297 417 125 297 minecraft:red_terracotta
setblock 417 122 301 minecraft:stripped_oak_log
fill 417 122 302 417 125 302 minecraft:red_terracotta
setblock 417 122 306 minecraft:stripped_oak_log
fill 377 123 276 377 126 276 minecraft:red_terracotta
setblock 377 123 280 minecraft:stripped_oak_log
fill 377 123 281 377 126 281 minecraft:red_terracotta
setblock 377 123 284 minecraft:red_terracotta
setblock 377 123 285 minecraft:stripped_oak_log
fill 377 123 286 377 126 286 minecraft:red_terracotta
setblock 377 123 290 minecraft:stripped_oak_log
fill 377 123 291 377 126 291 minecraft:red_terracotta
fill 377 123 296 377 126 296 minecraft:red_terracotta
setblock 377 123 299 minecraft:red_terracotta
setblock 377 123 300 minecraft:stripped_oak_log
fill 377 123 301 378 125 301 minecraft:red_terracotta
setblock 377 123 304 minecraft:red_terracotta
setblock 377 123 305 minecraft:stripped_oak_log
fill 377 123 306 377 125 307 minecraft:red_terracotta
setblock 378 123 279 minecraft:stripped_oak_log
fill 378 123 280 378 126 280 minecraft:red_terracotta
setblock 378 123 284 minecraft:stripped_oak_log
fill 378 123 285 378 126 285 minecraft:red_terracotta
setblock 378 123 288 minecraft:red_terracotta
fill 378 123 300 378 126 300 minecraft:red_terracotta
fill 378 123 302 378 123 303 minecraft:red_terracotta
setblock 378 123 304 minecraft:stripped_oak_log
setblock 379 123 278 minecraft:stripped_oak_log
fill 379 123 279 379 126 279 minecraft:red_terracotta
setblock 379 123 283 minecraft:stripped_oak_log
fill 379 123 284 380 125 284 minecraft:red_terracotta
fill 379 123 286 379 124 286 minecraft:red_terracotta
setblock 380 123 277 minecraft:stripped_oak_log
fill 380 123 278 380 126 278 minecraft:red_terracotta
setblock 380 123 282 minecraft:stripped_oak_log
fill 380 123 283 380 126 283 minecraft:red_terracotta
setblock 381 123 276 minecraft:stripped_oak_log
fill 381 123 277 381 126 277 minecraft:red_terracotta
setblock 381 123 315 minecraft:red_terracotta
setblock 381 123 316 minecraft:stripped_oak_log
fill 382 123 276 382 126 276 minecraft:red_terracotta
setblock 382 123 315 minecraft:stripped_oak_log
fill 382 123 316 385 123 316 minecraft:red_terracotta
setblock 383 123 279 minecraft:stripped_oak_log
fill 383 123 315 383 126 315 minecraft:red_terracotta
setblock 384 123 278 minecraft:stripped_oak_log
fill 384 123 279 384 124 279 minecraft:red_terracotta
setblock 385 123 277 minecraft:stripped_oak_log
fill 385 123 278 385 125 278 minecraft:red_terracotta
setblock 386 123 276 minecraft:stripped_oak_log
fill 386 123 277 386 126 277 minecraft:red_terracotta
setblock 386 123 316 minecraft:stripped_oak_log
fill 387 123 276 390 123 276 minecraft:red_terracotta
fill 387 123 316 387 126 316 minecraft:red_terracotta
setblock 391 123 276 minecraft:stripped_oak_log
setblock 392 123 276 minecraft:red_terracotta
fill 394 123 316 394 124 316 minecraft:red_terracotta
setblock 396 123 276 minecraft:stripped_oak_log
setblock 396 123 316 minecraft:stripped_oak_log
fill 397 123 276 397 126 276 minecraft:red_terracotta
fill 397 123 316 397 126 316 minecraft:red_terracotta
setblock 399 123 277 minecraft:red_terracotta
setblock 400 123 277 minecraft:stripped_oak_log
fill 400 123 315 401 123 315 minecraft:red_terracotta
setblock 401 123 276 minecraft:stripped_oak_log
fill 401 123 277 401 125 277 minecraft:red_terracotta
setblock 401 123 316 minecraft:stripped_oak_log
fill 402 123 276 402 126 276 minecraft:red_terracotta
setblock 402 123 315 minecraft:stripped_oak_log
fill 402 123 316 402 126 316 minecraft:red_terracotta
setblock 406 123 276 minecraft:stripped_oak_log
fill 411 123 276 411 124 278 minecraft:iron_bars
setblock 416 123 276 minecraft:stripped_oak_log
fill 416 123 278 416 123 280 minecraft:red_terracotta
setblock 416 123 281 minecraft:stripped_oak_log
fill 416 123 282 416 126 282 minecraft:red_terracotta
setblock 416 123 286 minecraft:stripped_oak_log
fill 416 123 287 416 126 287 minecraft:red_terracotta
fill 416 123 299 416 123 300 minecraft:red_terracotta
setblock 416 123 301 minecraft:stripped_oak_log
fill 416 123 302 416 124 304 minecraft:red_terracotta
fill 417 123 276 417 126 276 minecraft:red_terracotta
setblock 417 123 280 minecraft:stripped_oak_log
fill 417 123 281 417 126 281 minecraft:red_terracotta
setblock 417 123 284 minecraft:red_terracotta
setblock 417 123 285 minecraft:stripped_oak_log
fill 417 123 286 417 126 286 minecraft:red_terracotta
setblock 417 123 289 minecraft:red_terracotta
setblock 417 123 290 minecraft:stripped_oak_log
fill 417 123 291 417 126 291 minecraft:red_terracotta
setblock 417 123 295 minecraft:stripped_oak_log
fill 417 123 296 417 126 296 minecraft:red_terracotta
setblock 417 123 300 minecraft:stripped_oak_log
fill 417 123 301 417 126 301 minecraft:red_terracotta
setblock 417 123 305 minecraft:stripped_oak_log
fill 417 123 306 417 125 307 minecraft:red_terracotta
fill 376 124 275 376 127 317 minecraft:white_terracotta
fill 377 124 275 418 127 275 minecraft:white_terracotta
setblock 377 124 279 minecraft:stripped_oak_log
fill 377 124 280 377 127 280 minecraft:red_terracotta
setblock 377 124 284 minecraft:stripped_oak_log
fill 377 124 285 377 127 285 minecraft:red_terracotta
setblock 377 124 289 minecraft:stripped_oak_log
fill 377 124 290 377 127 290 minecraft:red_terracotta
fill 377 124 292 377 124 293 minecraft:red_terracotta
fill 377 124 295 377 127 295 minecraft:red_terracotta
setblock 377 124 299 minecraft:stripped_oak_log
fill 377 124 300 377 127 300 minecraft:red_terracotta
setblock 377 124 304 minecraft:stripped_oak_log
fill 377 124 305 378 126 305 minecraft:red_terracotta
setblock 377 124 308 minecraft:red_terracotta
setblock 377 124 309 minecraft:stripped_oak_log
fill 377 124 310 377 127 310 minecraft:red_terracotta
fill 377 124 315 377 126 316 minecraft:red_terracotta
fill 377 124 317 418 127 317 minecraft:white_terracotta
setblock 378 124 278 minecraft:stripped_oak_log
fill 378 124 279 378 127 279 minecraft:red_terracotta
setblock 378 124 283 minecraft:stripped_oak_log
fill 378 124 284 378 127 284 minecraft:red_terracotta
setblock 378 124 288 minecraft:stripped_oak_log
fill 378 124 289 378 127 289 minecraft:red_terracotta
setblock 378 124 302 minecraft:red_terracotta
setblock 378 124 303 minecraft:stripped_oak_log
fill 378 124 304 378 127 304 minecraft:red_terracotta
fill 378 124 306 378 124 307 minecraft:red_terracotta
setblock 379 124 277 minecraft:stripped_oak_log
fill 379 124 278 379 127 278 minecraft:red_terracotta
setblock 379 124 281 minecraft:red_terracotta
setblock 379 124 282 minecraft:stripped_oak_log
fill 379 124 283 379 127 283 minecraft:red_terracotta
setblock 379 124 287 minecraft:stripped_oak_log
setblock 380 124 276 minecraft:stripped_oak_log
fill 380 124 277 380 127 277 minecraft:red_terracotta
setblock 380 124 281 minecraft:stripped_oak_log
fill 380 124 282 380 127 282 minecraft:red_terracotta
setblock 380 124 285 minecraft:red_terracotta
setblock 380 124 315 minecraft:red_terracotta
setblock 380 124 316 minecraft:stripped_oak_log
fill 381 124 276 381 127 276 minecraft:red_terracotta
setblock 381 124 281 minecraft:red_terracotta
setblock 381 124 315 minecraft:stripped_oak_log
fill 381 124 316 384 124 316 minecraft:red_terracotta
setblock 382 124 279 minecraft:stripped_oak_log
fill 382 124 315 382 127 315 minecraft:red_terracotta
setblock 383 124 278 minecraft:stripped_oak_log
fill 383 124 279 383 125 279 minecraft:red_terracotta
setblock 384 124 277 minecraft:stripped_oak_log
fill 384 124 278 384 126 278 minecraft:red_terracotta
setblock 385 124 276 minecraft:stripped_oak_log
fill 385 124 277 385 127 277 minecraft:red_terracotta
setblock 385 124 316 minecraft:stripped_oak_log
fill 386 124 276 389 124 276 minecraft:red_terracotta
fill 386 124 316 386 127 316 minecraft:red_terracotta
setblock 390 124 276 minecraft:stripped_oak_log
setblock 390 124 316 minecraft:stripped_oak_log
setblock 391 124 276 minecraft:red_terracotta
fill 393 124 316 393 125 316 minecraft:red_terracotta
setblock 395 124 276 minecraft:stripped_oak_log
setblock 395 124 316 minecraft:stripped_oak_log
fill 396 124 276 396 127 276 minecraft:red_terracotta
fill 396 124 316 396 127 316 minecraft:red_terracotta
fill 398 124 314 400 124 316 minecraft:terracotta
setblock 399 124 277 minecraft:stripped_oak_log
setblock 400 124 276 minecraft:stripped_oak_log
fill 400 124 277 400 125 277 minecraft:red_terracotta
fill 401 124 276 401 127 276 minecraft:red_terracotta
setblock 401 124 315 minecraft:stripped_oak_log
fill 401 124 316 401 127 316 minecraft:red_terracotta
setblock 402 124 315 minecraft:red_terracotta
setblock 405 124 276 minecraft:stripped_oak_log
fill 414 124 296 416 125 296 minecraft:iron_bars
fill 415 124 282 415 125 284 minecraft:red_terracotta
fill 416 124 276 416 127 276 minecraft:red_terracotta
fill 416 124 278 416 124 279 minecraft:red_terracotta
setblock 416 124 280 minecraft:stripped_oak_log
fill 416 124 281 416 127 281 minecraft:red_terracotta
fill 416 124 283 416 124 284 minecraft:red_terracotta
setblock 416 124 285 minecraft:stripped_oak_log
fill 416 124 286 416 127 286 minecraft:red_terracotta
fill 416 124 288 416 124 289 minecraft:red_terracotta
setblock 416 124 290 minecraft:stripped_oak_log
fill 416 124 297 416 126 297 minecraft:red_terracotta
setblock 416 124 299 minecraft:red_terracotta
setblock 416 124 300 minecraft:stripped_oak_log
fill 416 124 301 416 127 301 minecraft:red_terracotta
setblock 416 124 305 minecraft:stripped_oak_log
setblock 417 124 279 minecraft:stripped_oak_log
fill 417 124 280 417 127 280 minecraft:red_terracotta
setblock 417 124 284 minecraft:stripped_oak_log
fill 417 124 285 417 127 285 minecraft:red_terracotta
setblock 417 124 289 minecraft:stripped_oak_log
fill 417 124 290 417 127 290 minecraft:red_terracotta
setblock 417 124 294 minecraft:stripped_oak_log
fill 417 124 295 417 127 295 minecraft:red_terracotta
setblock 417 124 299 minecraft:stripped_oak_log
fill 417 124 300 417 127 300 minecraft:red_terracotta
setblock 417 124 304 minecraft:stripped_oak_log
fill 417 124 305 417 127 305 minecraft:red_terracotta
setblock 417 124 308 minecraft:red_terracotta
setblock 417 124 309 minecraft:stripped_oak_log
fill 418 124 276 418 127 316 minecraft:white_terracotta
setblock 377 125 278 minecraft:stripped_oak_log
fill 377 125 279 377 128 279 minecraft:red_terracotta
setblock 377 125 283 minecraft:stripped_oak_log
fill 377 125 284 377 128 284 minecraft:red_terracotta
setblock 377 125 287 minecraft:red_terracotta
setblock 377 125 288 minecraft:stripped_oak_log
fill 377 125 289 377 128 289 minecraft:red_terracotta
setblock 377 125 292 minecraft:red_terracotta
setblock 377 125 293 minecraft:stripped_oak_log
fill 377 125 294 377 128 294 minecraft:red_terracotta
setblock 377 125 298 minecraft:stripped_oak_log
fill 377 125 299 377 128 299 minecraft:red_terracotta
setblock 377 125 303 minecraft:stripped_oak_log
fill 377 125 304 377 128 304 minecraft:red_terracotta
setblock 377 125 308 minecraft:stripped_oak_log
fill 377 125 309 378 127 309 minecraft:red_terracotta
fill 377 125 311 377 125 312 minecraft:red_terracotta
setblock 377 125 313 minecraft:stripped_oak_log
fill 377 125 314 377 128 314 minecraft:red_terracotta
setblock 378 125 277 minecraft:stripped_oak_log
fill 378 125 278 378 128 278 minecraft:red_terracotta
setblock 378 125 282 minecraft:stripped_oak_log
fill 378 125 283 378 128 283 minecraft:red_terracotta
setblock 378 125 287 minecraft:stripped_oak_log
fill 378 125 288 379 127 288 minecraft:red_terracotta
fill 378 125 290 378 126 290 minecraft:red_terracotta
setblock 378 125 302 minecraft:stripped_oak_log
fill 378 125 303 379 126 303 minecraft:red_terracotta
setblock 378 125 306 minecraft:red_terracotta
setblock 378 125 307 minecraft:stripped_oak_log
fill 378 125 308 378 128 308 minecraft:red_terracotta
fill 378 125 310 378 126 310 minecraft:red_terracotta
setblock 379 125 276 minecraft:stripped_oak_log
fill 379 125 277 379 128 277 minecraft:red_terracotta
setblock 379 125 281 minecraft:stripped_oak_log
fill 379 125 282 379 128 282 minecraft:red_terracotta
setblock 379 125 286 minecraft:stripped_oak_log
fill 379 125 287 379 128 287 minecraft:red_terracotta
fill 379 125 304 379 125 305 minecraft:red_terracotta
setblock 379 125 306 minecraft:stripped_oak_log
setblock 379 125 315 minecraft:red_terracotta
setblock 379 125 316 minecraft:stripped_oak_log
fill 380 125 276 380 128 276 minecraft:red_terracotta
setblock 380 125 280 minecraft:stripped_oak_log
fill 380 125 281 380 128 281 minecraft:red_terracotta
setblock 380 125 285 minecraft:stripped_oak_log
fill 380 125 286 380 128 286 minecraft:red_terracotta
fill 380 125 314 380 125 315 minecraft:stripped_oak_log
fill 380 125 316 383 125 316 minecraft:red_terracotta
setblock 381 125 279 minecraft:stripped_oak_log
fill 381 125 315 381 128 315 minecraft:red_terracotta
setblock 382 125 278 minecraft:stripped_oak_log
fill 382 125 279 382 126 279 minecraft:red_terracotta
setblock 383 125 277 minecraft:stripped_oak_log
fill 383 125 278 383 127 278 minecraft:red_terracotta
setblock 384 125 276 minecraft:stripped_oak_log
fill 384 125 277 384 127 277 minecraft:red_terracotta
setblock 384 125 316 minecraft:stripped_oak_log
fill 385 125 276 388 125 276 minecraft:red_terracotta
setblock 385 125 315 minecraft:stripped_oak_log
fill 385 125 316 385 128 316 minecraft:red_terracotta
setblock 389 125 276 minecraft:stripped_oak_log
setblock 389 125 316 minecraft:stripped_oak_log
setblock 390 125 276 minecraft:red_terracotta
fill 390 125 316 390 126 316 minecraft:red_terracotta
fill 392 125 316 392 126 316 minecraft:red_terracotta
setblock 394 125 316 minecraft:stripped_oak_log
fill 395 125 276 395 126 276 minecraft:red_terracotta
fill 395 125 316 395 128 316 minecraft:red_terracotta
fill 397 125 315 398 126 315 minecraft:red_terracotta
setblock 398 125 316 minecraft:red_terracotta
setblock 399 125 276 minecraft:stripped_oak_log
setblock 399 125 277 minecraft:red_terracotta
fill 399 125 315 399 131 315 minecraft:green_concrete
setblock 399 125 316 minecraft:stripped_oak_log
fill 400 125 276 400 128 276 minecraft:red_terracotta
setblock 400 125 315 minecraft:stripped_oak_log
fill 400 125 316 400 128 316 minecraft:red_terracotta
fill 401 125 315 401 127 315 minecraft:red_terracotta
setblock 404 125 276 minecraft:stripped_oak_log
setblock 404 125 316 minecraft:stripped_oak_log
fill 415 125 276 415 128 276 minecraft:red_terracotta
fill 415 125 281 415 128 281 minecraft:red_terracotta
setblock 415 125 285 minecraft:stripped_oak_log
fill 415 125 286 415 127 287 minecraft:red_terracotta
fill 416 125 277 416 125 278 minecraft:red_terracotta
setblock 416 125 279 minecraft:stripped_oak_log
fill 416 125 280 416 128 280 minecraft:red_terracotta
setblock 416 125 283 minecraft:red_terracotta
setblock 416 125 284 minecraft:stripped_oak_log
fill 416 125 285 416 128 285 minecraft:red_terracotta
setblock 416 125 288 minecraft:red_terracotta
setblock 416 125 289 minecraft:stripped_oak_log
fill 416 125 290 416 126 292 minecraft:red_terracotta
setblock 416 125 299 minecraft:stripped_oak_log
fill 416 125 300 416 127 300 minecraft:red_terracotta
fill 416 125 302 416 125 303 minecraft:red_terracotta
setblock 416 125 304 minecraft:stripped_oak_log
fill 416 125 305 416 126 307 minecraft:red_terracotta
setblock 417 125 278 minecraft:stripped_oak_log
fill 417 125 279 417 128 279 minecraft:red_terracotta
setblock 417 125 283 minecraft:stripped_oak_log
fill 417 125 284 417 128 284 minecraft:red_terracotta
setblock 417 125 288 minecraft:stripped_oak_log
fill 417 125 289 417 128 289 minecraft:red_terracotta
setblock 417 125 293 minecraft:stripped_oak_log
fill 417 125 294 417 128 294 minecraft:red_terracotta
setblock 417 125 298 minecraft:stripped_oak_log
fill 417 125 299 417 128 299 minecraft:red_terracotta
setblock 417 125 303 minecraft:stripped_oak_log
fill 417 125 304 417 128 304 minecraft:red_terracotta
setblock 417 125 308 minecraft:stripped_oak_log
fill 417 125 309 417 127 310 minecraft:red_terracotta
setblock 377 126 277 minecraft:stripped_oak_log
fill 377 126 278 377 129 278 minecraft:red_terracotta
setblock 377 126 282 minecraft:stripped_oak_log
fill 377 126 283 377 129 283 minecraft:red_terracotta
setblock 377 126 287 minecraft:stripped_oak_log
fill 377 126 288 377 129 288 minecraft:red_terracotta
setblock 377 126 292 minecraft:stripped_oak_log
fill 377 126 293 377 129 293 minecraft:red_terracotta
setblock 377 126 297 minecraft:stripped_oak_log
fill 377 126 298 377 128 298 minecraft:red_terracotta
setblock 377 126 301 minecraft:red_terracotta
setblock 377 126 302 minecraft:stripped_oak_log
fill 377 126 303 377 129 303 minecraft:red_terracotta
setblock 377 126 306 minecraft:red_terracotta
setblock 377 126 307 minecraft:stripped_oak_log
fill 377 126 308 377 129 308 minecraft:red_terracotta
setblock 377 126 311 minecraft:red_terracotta
setblock 377 126 312 minecraft:stripped_oak_log
fill 377 126 313 378 128 313 minecraft:red_terracotta
setblock 378 126 276 minecraft:stripped_oak_log
fill 378 126 277 378 129 277 minecraft:red_terracotta
setblock 378 126 281 minecraft:stripped_oak_log
fill 378 126 282 378 129 282 minecraft:red_terracotta
setblock 378 126 286 minecraft:stripped_oak_log
fill 378 126 287 378 129 287 minecraft:red_terracotta
setblock 378 126 291 minecraft:stripped_oak_log
setblock 378 126 301 minecraft:stripped_oak_log
fill 378 126 302 378 128 302 minecraft:red_terracotta
setblock 378 126 306 minecraft:stripped_oak_log
fill 378 126 307 379 128 307 minecraft:red_terracotta
setblock 378 126 311 minecraft:stripped_oak_log
fill 378 126 312 378 129 312 minecraft:red_terracotta
fill 378 126 314 378 126 315 minecraft:red_terracotta
setblock 378 126 316 minecraft:stripped_oak_log
fill 379 126 276 379 129 276 minecraft:red_terracotta
setblock 379 126 280 minecraft:stripped_oak_log
fill 379 126 281 379 129 281 minecraft:red_terracotta
setblock 379 126 284 minecraft:red_terracotta
setblock 379 126 285 minecraft:stripped_oak_log
fill 379 126 286 379 129 286 minecraft:red_terracotta
setblock 379 126 289 minecraft:red_terracotta
setblock 379 126 292 minecraft:light[level=12]
setblock 379 126 299 minecraft:light[level=12]
setblock 379 126 304 minecraft:red_terracotta
setblock 379 126 305 minecraft:stripped_oak_log
fill 379 126 306 379 129 306 minecraft:red_terracotta
fill 379 126 308 379 126 309 minecraft:red_terracotta
setblock 379 126 313 minecraft:light[level=12]
setblock 379 126 315 minecraft:stripped_oak_log
fill 379 126 316 382 126 316 minecraft:red_terracotta
setblock 380 126 279 minecraft:stripped_oak_log
fill 380 126 280 380 128 280 minecraft:red_terracotta
setblock 380 126 284 minecraft:stripped_oak_log
fill 380 126 285 380 128 285 minecraft:red_terracotta
fill 380 126 314 380 134 314 minecraft:stripped_oak_log
fill 380 126 315 380 129 315 minecraft:red_terracotta
setblock 381 126 278 minecraft:stripped_oak_log
fill 381 126 279 381 127 279 minecraft:red_terracotta
setblock 382 126 277 minecraft:stripped_oak_log
fill 382 126 278 382 128 278 minecraft:red_terracotta
setblock 383 126 276 minecraft:stripped_oak_log
fill 383 126 277 383 128 277 minecraft:red_terracotta
setblock 383 126 316 minecraft:stripped_oak_log
fill 384 126 276 387 126 276 minecraft:red_terracotta
setblock 384 126 315 minecraft:stripped_oak_log
fill 384 126 316 384 129 316 minecraft:red_terracotta
setblock 385 126 315 minecraft:red_terracotta
setblock 386 126 278 minecraft:light[level=12]
setblock 386 126 285 minecraft:light[level=12]
setblock 386 126 292 minecraft:light[level=12]
setblock 386 126 299 minecraft:light[level=12]
setblock 386 126 306 minecraft:light[level=12]
setblock 386 126 313 minecraft:light[level=12]
setblock 388 126 276 minecraft:stripped_oak_log
setblock 388 126 316 minecraft:stripped_oak_log
fill 389 126 316 389 127 316 minecraft:red_terracotta
setblock 391 126 316 minecraft:red_terracotta
setblock 393 126 285 minecraft:light[level=12]
setblock 393 126 292 minecraft:light[level=12]
setblock 393 126 299 minecraft:light[level=12]
setblock 393 126 306 minecraft:light[level=12]
setblock 393 126 313 minecraft:light[level=12]
setblock 393 126 316 minecraft:stripped_oak_log
fill 394 126 316 394 129 316 minecraft:red_terracotta
setblock 398 126 276 minecraft:stripped_oak_log
setblock 398 126 316 minecraft:stripped_oak_log
fill 399 126 276 399 128 276 minecraft:red_terracotta
fill 399 126 316 399 129 316 minecraft:red_terracotta
setblock 400 126 278 minecraft:light[level=12]
setblock 400 126 285 minecraft:light[level=12]
setblock 400 126 292 minecraft:light[level=12]
setblock 400 126 299 minecraft:light[level=12]
setblock 400 126 306 minecraft:light[level=12]
setblock 400 126 313 minecraft:light[level=12]
fill 400 126 315 400 127 315 minecraft:red_terracotta
setblock 403 126 276 minecraft:stripped_oak_log
setblock 403 126 316 minecraft:stripped_oak_log
setblock 407 126 278 minecraft:light[level=12]
setblock 407 126 285 minecraft:light[level=12]
setblock 407 126 292 minecraft:light[level=12]
setblock 407 126 299 minecraft:light[level=12]
setblock 407 126 306 minecraft:light[level=12]
setblock 407 126 313 minecraft:light[level=12]
setblock 414 126 278 minecraft:light[level=12]
setblock 414 126 285 minecraft:light[level=12]
setblock 414 126 292 minecraft:light[level=12]
setblock 414 126 299 minecraft:light[level=12]
setblock 414 126 306 minecraft:light[level=12]
setblock 414 126 313 minecraft:light[level=12]
fill 415 126 280 415 127 280 minecraft:red_terracotta
fill 415 126 282 415 126 283 minecraft:red_terracotta
setblock 415 126 284 minecraft:stripped_oak_log
fill 415 126 285 415 129 285 minecraft:red_terracotta
setblock 415 126 288 minecraft:red_terracotta
setblock 416 126 277 minecraft:red_terracotta
setblock 416 126 278 minecraft:stripped_oak_log
fill 416 126 279 416 129 279 minecraft:red_terracotta
setblock 416 126 283 minecraft:stripped_oak_log
fill 416 126 284 416 129 284 minecraft:red_terracotta
setblock 416 126 288 minecraft:stripped_oak_log
fill 416 126 289 416 129 289 minecraft:red_terracotta
setblock 416 126 293 minecraft:stripped_oak_log
setblock 416 126 298 minecraft:stripped_oak_log
fill 416 126 299 416 127 299 minecraft:red_terracotta
setblock 416 126 302 minecraft:red_terracotta
setblock 416 126 303 minecraft:stripped_oak_log
fill 416 126 304 416 129 304 minecraft:red_terracotta
setblock 416 126 308 minecraft:stripped_oak_log
setblock 417 126 277 minecraft:stripped_oak_log
fill 417 126 278 417 129 278 minecraft:red_terracotta
setblock 417 126 282 minecraft:stripped_oak_log
fill 417 126 283 417 129 283 minecraft:red_terracotta
setblock 417 126 287 minecraft:stripped_oak_log
fill 417 126 288 417 129 288 minecraft:red_terracotta
setblock 417 126 292 minecraft:stripped_oak_log
fill 417 126 293 417 129 293 minecraft:red_terracotta
setblock 417 126 297 minecraft:stripped_oak_log
fill 417 126 298 417 129 298 minecraft:red_terracotta
setblock 417 126 302 minecraft:stripped_oak_log
fill 417 126 303 417 129 303 minecraft:red_terracotta
setblock 417 126 306 minecraft:red_terracotta
setblock 417 126 307 minecraft:stripped_oak_log
fill 417 126 308 417 129 308 minecraft:red_terracotta
setblock 417 126 311 minecraft:red_terracotta
setblock 417 126 312 minecraft:stripped_oak_log
setblock 377 127 276 minecraft:stripped_oak_log
fill 377 127 277 377 130 277 minecraft:red_terracotta
setblock 377 127 281 minecraft:stripped_oak_log
fill 377 127 282 377 130 282 minecraft:red_terracotta
setblock 377 127 286 minecraft:stripped_oak_log
fill 377 127 287 377 130 287 minecraft:red_terracotta
setblock 377 127 291 minecraft:stripped_oak_log
fill 377 127 292 377 130 292 minecraft:red_terracotta
setblock 377 127 296 minecraft:stripped_oak_log
setblock 377 127 297 minecraft:red_terracotta
setblock 377 127 301 minecraft:stripped_oak_log
fill 377 127 302 377 130 302 minecraft:red_terracotta
setblock 377 127 305 minecraft:red_terracotta
setblock 377 127 306 minecraft:stripped_oak_log
fill 377 127 307 377 130 307 minecraft:red_terracotta
setblock 377 127 311 minecraft:stripped_oak_log
fill 377 127 312 377 130 312 minecraft:red_terracotta
setblock 377 127 315 minecraft:red_terracotta
setblock 377 127 316 minecraft:stripped_oak_log
fill 378 127 276 378 130 276 minecraft:red_terracotta
setblock 378 127 280 minecraft:stripped_oak_log
fill 378 127 281 378 130 281 minecraft:red_terracotta
setblock 378 127 285 minecraft:stripped_oak_log
fill 378 127 286 378 130 286 minecraft:red_terracotta
setblock 378 127 290 minecraft:stripped_oak_log
fill 378 127 291 378 130 291 minecraft:red_terracotta
setblock 378 127 301 minecraft:red_terracotta
fill 378 127 303 378 128 303 minecraft:red_terracotta
setblock 378 127 305 minecraft:stripped_oak_log
fill 378 127 306 378 130 306 minecraft:red_terracotta
setblock 378 127 310 minecraft:stripped_oak_log
fill 378 127 311 379 129 311 minecraft:red_terracotta
setblock 378 127 314 minecraft:red_terracotta
setblock 378 127 315 minecraft:stripped_oak_log
fill 378 127 316 381 127 316 minecraft:red_terracotta
setblock 379 127 279 minecraft:stripped_oak_log
fill 379 127 280 379 130 280 minecraft:red_terracotta
setblock 379 127 284 minecraft:stripped_oak_log
fill 379 127 285 379 130 285 minecraft:red_terracotta
setblock 379 127 289 minecraft:stripped_oak_log
setblock 379 127 304 minecraft:stripped_oak_log
fill 379 127 305 379 128 305 minecraft:red_terracotta
setblock 379 127 308 minecraft:red_terracotta
setblock 379 127 309 minecraft:stripped_oak_log
fill 379 127 310 379 130 310 minecraft:red_terracotta
fill 379 127 315 379 130 315 minecraft:red_terracotta
setblock 380 127 278 minecraft:stripped_oak_log
setblock 380 127 279 minecraft:red_terracotta
setblock 380 127 283 minecraft:stripped_oak_log
fill 380 127 284 380 128 284 minecraft:red_terracotta
setblock 381 127 277 minecraft:stripped_oak_log
fill 381 127 278 381 128 278 minecraft:red_terracotta
setblock 382 127 276 minecraft:stripped_oak_log
fill 382 127 277 382 129 277 minecraft:red_terracotta
setblock 382 127 316 minecraft:stripped_oak_log
fill 383 127 276 386 127 276 minecraft:red_terracotta
setblock 383 127 315 minecraft:stripped_oak_log
fill 383 127 316 383 130 316 minecraft:red_terracotta
fill 384 127 315 384 128 315 minecraft:red_terracotta
setblock 387 127 276 minecraft:stripped_oak_log
setblock 387 127 316 minecraft:stripped_oak_log
setblock 388 127 316 minecraft:red_terracotta
setblock 392 127 316 minecraft:stripped_oak_log
fill 393 127 316 393 130 316 minecraft:red_terracotta
fill 395 127 276 395 136 276 minecraft:stripped_oak_log
fill 396 127 315 397 127 315 minecraft:red_terracotta
setblock 397 127 276 minecraft:stripped_oak_log
setblock 397 127 316 minecraft:stripped_oak_log
fill 398 127 276 398 128 276 minecraft:red_terracotta
setblock 398 127 315 minecraft:stripped_oak_log
fill 398 127 316 398 130 316 minecraft:red_terracotta
setblock 402 127 276 minecraft:stripped_oak_log
setblock 402 127 316 minecraft:stripped_oak_log
setblock 403 127 316 minecraft:red_terracotta
setblock 415 127 282 minecraft:red_terracotta
setblock 415 127 283 minecraft:stripped_oak_log
fill 415 127 284 415 130 284 minecraft:red_terracotta
setblock 415 127 288 minecraft:stripped_oak_log
fill 415 127 289 415 130 289 minecraft:red_terracotta
setblock 416 127 277 minecraft:stripped_oak_log
fill 416 127 278 416 130 278 minecraft:red_terracotta
setblock 416 127 282 minecraft:stripped_oak_log
fill 416 127 283 416 130 283 minecraft:red_terracotta
setblock 416 127 287 minecraft:stripped_oak_log
fill 416 127 288 416 130 288 minecraft:red_terracotta
fill 416 127 290 416 127 291 minecraft:red_terracotta
setblock 416 127 292 minecraft:stripped_oak_log
fill 416 127 293 416 129 294 minecraft:red_terracotta
setblock 416 127 302 minecraft:stripped_oak_log
fill 416 127 303 416 129 303 minecraft:red_terracotta
fill 416 127 305 416 127 306 minecraft:red_terracotta
setblock 416 127 307 minecraft:stripped_oak_log
fill 416 127 308 416 129 309 minecraft:red_terracotta
setblock 417 127 276 minecraft:stripped_oak_log
fill 417 127 277 417 130 277 minecraft:red_terracotta
setblock 417 127 281 minecraft:stripped_oak_log
fill 417 127 282 417 130 282 minecraft:red_terracotta
setblock 417 127 286 minecraft:stripped_oak_log
fill 417 127 287 417 130 287 minecraft:red_terracotta
setblock 417 127 291 minecraft:stripped_oak_log
fill 417 127 292 417 130 292 minecraft:red_terracotta
setblock 417 127 296 minecraft:stripped_oak_log
fill 417 127 297 417 130 297 minecraft:red_terracotta
setblock 417 127 301 minecraft:stripped_oak_log
fill 417 127 302 417 130 302 minecraft:red_terracotta
setblock 417 127 306 minecraft:stripped_oak_log
fill 417 127 307 417 130 307 minecraft:red_terracotta
setblock 417 127 311 minecraft:stripped_oak_log
fill 417 127 312 417 129 313 minecraft:red_terracotta
fill 376 128 275 376 131 317 minecraft:terracotta
fill 377 128 275 418 131 275 minecraft:terracotta
fill 377 128 276 377 131 276 minecraft:red_terracotta
setblock 377 128 280 minecraft:stripped_oak_log
fill 377 128 281 377 131 281 minecraft:red_terracotta
setblock 377 128 285 minecraft:stripped_oak_log
fill 377 128 286 377 131 286 minecraft:red_terracotta
setblock 377 128 290 minecraft:stripped_oak_log
fill 377 128 291 377 131 291 minecraft:red_terracotta
setblock 377 128 295 minecraft:stripped_oak_log
setblock 377 128 300 minecraft:stripped_oak_log
fill 377 128 301 377 130 301 minecraft:red_terracotta
setblock 377 128 305 minecraft:stripped_oak_log
fill 377 128 306 377 131 306 minecraft:red_terracotta
setblock 377 128 309 minecraft:red_terracotta
setblock 377 128 310 minecraft:stripped_oak_log
fill 377 128 311 377 131 311 minecraft:red_terracotta
setblock 377 128 315 minecraft:stripped_oak_log
fill 377 128 316 380 128 316 minecraft:red_terracotta
fill 377 128 317 418 131 317 minecraft:terracotta
setblock 378 128 279 minecraft:stripped_oak_log
fill 378 128 280 378 131 280 minecraft:red_terracotta
setblock 378 128 284 minecraft:stripped_oak_log
fill 378 128 285 378 131 285 minecraft:red_terracotta
setblock 378 128 288 minecraft:red_terracotta
setblock 378 128 289 minecraft:stripped_oak_log
fill 378 128 290 378 131 290 minecraft:red_terracotta
setblock 378 128 304 minecraft:stripped_oak_log
fill 378 128 305 378 131 305 minecraft:red_terracotta
setblock 378 128 309 minecraft:stripped_oak_log
fill 378 128 310 378 131 310 minecraft:red_terracotta
setblock 378 128 314 minecraft:stripped_oak_log
fill 378 128 315 378 131 315 minecraft:red_terracotta
setblock 379 128 278 minecraft:stripped_oak_log
fill 379 128 279 379 129 279 minecraft:red_terracotta
setblock 379 128 283 minecraft:stripped_oak_log
fill 379 128 284 379 131 284 minecraft:red_terracotta
setblock 379 128 288 minecraft:stripped_oak_log
fill 379 128 289 379 129 289 minecraft:red_terracotta
setblock 379 128 294 minecraft:light[level=15]
setblock 379 128 302 minecraft:light[level=15]
setblock 379 128 308 minecraft:stripped_oak_log
fill 379 128 309 379 131 309 minecraft:red_terracotta
setblock 379 128 312 minecraft:red_terracotta
setblock 380 128 277 minecraft:stripped_oak_log
fill 380 128 278 380 129 278 minecraft:red_terracotta
setblock 380 128 282 minecraft:stripped_oak_log
setblock 380 128 283 minecraft:red_terracotta
setblock 381 128 276 minecraft:stripped_oak_log
fill 381 128 277 381 130 277 minecraft:red_terracotta
setblock 381 128 316 minecraft:stripped_oak_log
fill 382 128 276 385 128 276 minecraft:red_terracotta
setblock 382 128 315 minecraft:stripped_oak_log
fill 382 128 316 382 131 316 minecraft:red_terracotta
fill 383 128 315 383 129 315 minecraft:red_terracotta
setblock 386 128 276 minecraft:stripped_oak_log
setblock 386 128 316 minecraft:stripped_oak_log
setblock 387 128 278 minecraft:light[level=15]
setblock 387 128 286 minecraft:light[level=15]
setblock 387 128 294 minecraft:light[level=15]
setblock 387 128 302 minecraft:light[level=15]
setblock 387 128 310 minecraft:light[level=15]
setblock 387 128 316 minecraft:red_terracotta
fill 392 128 316 392 131 316 minecraft:red_terracotta
setblock 395 128 286 minecraft:light[level=15]
setblock 395 128 294 minecraft:light[level=15]
setblock 395 128 302 minecraft:light[level=15]
setblock 395 128 310 minecraft:light[level=15]
fill 396 128 276 396 136 276 minecraft:stripped_oak_log
setblock 396 128 315 minecraft:red_terracotta
setblock 396 128 316 minecraft:stripped_oak_log
setblock 397 128 276 minecraft:red_terracotta
setblock 397 128 315 minecraft:stripped_oak_log
fill 397 128 316 397 131 316 minecraft:red_terracotta
fill 398 128 315 398 131 315 minecraft:red_terracotta
fill 400 128 315 400 130 315 minecraft:green_concrete
setblock 401 128 316 minecraft:stripped_oak_log
setblock 402 128 316 minecraft:red_terracotta
setblock 403 128 278 minecraft:light[level=15]
setblock 403 128 286 minecraft:light[level=15]
setblock 403 128 294 minecraft:light[level=15]
setblock 403 128 302 minecraft:light[level=15]
setblock 403 128 310 minecraft:light[level=15]
setblock 411 128 278 minecraft:light[level=15]
setblock 411 128 286 minecraft:light[level=15]
setblock 411 128 294 minecraft:light[level=15]
setblock 411 128 302 minecraft:light[level=15]
setblock 411 128 310 minecraft:light[level=15]
setblock 415 128 282 minecraft:stripped_oak_log
fill 415 128 283 415 131 283 minecraft:red_terracotta
setblock 415 128 286 minecraft:red_terracotta
setblock 415 128 287 minecraft:stripped_oak_log
fill 415 128 288 415 131 288 minecraft:red_terracotta
fill 415 128 290 416 128 290 minecraft:red_terracotta
setblock 416 128 276 minecraft:stripped_oak_log
fill 416 128 277 416 129 277 minecraft:red_terracotta
setblock 416 128 281 minecraft:stripped_oak_log
fill 416 128 282 416 131 282 minecraft:red_terracotta
setblock 416 128 286 minecraft:stripped_oak_log
fill 416 128 287 416 131 287 minecraft:red_terracotta
setblock 416 128 291 minecraft:stripped_oak_log
fill 416 128 292 416 131 292 minecraft:red_terracotta
setblock 416 128 301 minecraft:stripped_oak_log
setblock 416 128 302 minecraft:red_terracotta
setblock 416 128 305 minecraft:red_terracotta
setblock 416 128 306 minecraft:stripped_oak_log
fill 416 128 307 416 131 307 minecraft:red_terracotta
fill 417 128 276 417 131 276 minecraft:red_terracotta
setblock 417 128 280 minecraft:stripped_oak_log
fill 417 128 281 417 131 281 minecraft:red_terracotta
setblock 417 128 285 minecraft:stripped_oak_log
fill 417 128 286 417 131 286 minecraft:red_terracotta
setblock 417 128 290 minecraft:stripped_oak_log
fill 417 128 291 417 131 291 minecraft:red_terracotta
setblock 417 128 295 minecraft:stripped_oak_log
fill 417 128 296 417 131 296 minecraft:red_terracotta
setblock 417 128 300 minecraft:stripped_oak_log
fill 417 128 301 417 131 301 minecraft:red_terracotta
setblock 417 128 305 minecraft:stripped_oak_log
fill 417 128 306 417 131 306 minecraft:red_terracotta
setblock 417 128 309 minecraft:red_terracotta
setblock 417 128 310 minecraft:stripped_oak_log
fill 417 128 311 417 131 311 minecraft:red_terracotta
setblock 417 128 314 minecraft:red_terracotta
setblock 417 128 315 minecraft:stripped_oak_log
fill 418 128 276 418 131 316 minecraft:terracotta
setblock 377 129 279 minecraft:stripped_oak_log
fill 377 129 280 377 132 280 minecraft:red_terracotta
setblock 377 129 284 minecraft:stripped_oak_log
fill 377 129 285 377 132 285 minecraft:red_terracotta
setblock 377 129 289 minecraft:stripped_oak_log
fill 377 129 290 377 132 290 minecraft:red_terracotta
setblock 377 129 294 minecraft:stripped_oak_log
setblock 377 129 300 minecraft:red_terracotta
setblock 377 129 304 minecraft:stripped_oak_log
fill 377 129 305 377 132 305 minecraft:red_terracotta
setblock 377 129 309 minecraft:stripped_oak_log
fill 377 129 310 377 132 310 minecraft:red_terracotta
setblock 377 129 313 minecraft:red_terracotta
setblock 377 129 314 minecraft:stripped_oak_log
fill 377 129 315 377 131 316 minecraft:red_terracotta
setblock 378 129 278 minecraft:stripped_oak_log
fill 378 129 279 378 132 279 minecraft:red_terracotta
setblock 378 129 283 minecraft:stripped_oak_log
fill 378 129 284 378 132 284 minecraft:red_terracotta
setblock 378 129 288 minecraft:stripped_oak_log
fill 378 129 289 378 132 289 minecraft:red_terracotta
setblock 378 129 303 minecraft:stripped_oak_log
fill 378 129 304 378 130 304 minecraft:red_terracotta
setblock 378 129 307 minecraft:red_terracotta
setblock 378 129 308 minecraft:stripped_oak_log
fill 378 129 309 378 132 309 minecraft:red_terracotta
setblock 378 129 313 minecraft:stripped_oak_log
fill 378 129 314 378 132 314 minecraft:red_terracotta
fill 378 129 316 379 129 316 minecraft:red_terracotta
setblock 379 129 277 minecraft:stripped_oak_log
setblock 379 129 278 minecraft:red_terracotta
setblock 379 129 282 minecraft:stripped_oak_log
fill 379 129 283 379 131 283 minecraft:red_terracotta
setblock 379 129 287 minecraft:stripped_oak_log
fill 379 129 288 379 130 288 minecraft:red_terracotta
setblock 379 129 307 minecraft:stripped_oak_log
fill 379 129 308 379 131 308 minecraft:red_terracotta
setblock 379 129 312 minecraft:stripped_oak_log
setblock 380 129 276 minecraft:stripped_oak_log
fill 380 129 277 380 130 277 minecraft:red_terracotta
setblock 380 129 316 minecraft:stripped_oak_log
fill 381 129 276 384 129 276 minecraft:red_terracotta
setblock 381 129 315 minecraft:stripped_oak_log
fill 381 129 316 381 132 316 minecraft:red_terracotta
fill 382 129 315 382 132 315 minecraft:red_terracotta
setblock 385 129 316 minecraft:stripped_oak_log
setblock 386 129 316 minecraft:red_terracotta
setblock 395 129 315 minecraft:red_terracotta
setblock 395 129 316 minecraft:stripped_oak_log
setblock 396 129 315 minecraft:stripped_oak_log
fill 396 129 316 396 132 316 minecraft:red_terracotta
fill 397 129 315 397 132 315 minecraft:red_terracotta
setblock 400 129 316 minecraft:stripped_oak_log
setblock 401 129 316 minecraft:red_terracotta
setblock 415 129 276 minecraft:stripped_oak_log
setblock 415 129 281 minecraft:stripped_oak_log
fill 415 129 282 415 131 282 minecraft:red_terracotta
setblock 415 129 286 minecraft:stripped_oak_log
fill 415 129 287 415 132 287 minecraft:red_terracotta
setblock 415 129 290 minecraft:red_terracotta
setblock 415 129 291 minecraft:stripped_oak_log
fill 416 129 276 416 132 276 minecraft:red_terracotta
setblock 416 129 280 minecraft:stripped_oak_log
fill 416 129 281 416 132 281 minecraft:red_terracotta
setblock 416 129 285 minecraft:stripped_oak_log
fill 416 129 286 416 132 286 minecraft:red_terracotta
setblock 416 129 290 minecraft:stripped_oak_log
fill 416 129 291 416 132 291 minecraft:red_terracotta
setblock 416 129 305 minecraft:stripped_oak_log
fill 416 129 306 416 130 306 minecraft:red_terracotta
setblock 416 129 310 minecraft:stripped_oak_log
setblock 417 129 279 minecraft:stripped_oak_log
fill 417 129 280 417 132 280 minecraft:red_terracotta
setblock 417 129 284 minecraft:stripped_oak_log
fill 417 129 285 417 132 285 minecraft:red_terracotta
setblock 417 129 289 minecraft:stripped_oak_log
fill 417 129 290 417 132 290 minecraft:red_terracotta
setblock 417 129 294 minecraft:stripped_oak_log
fill 417 129 295 417 132 295 minecraft:red_terracotta
setblock 417 129 299 minecraft:stripped_oak_log
fill 417 129 300 417 130 300 minecraft:red_terracotta
setblock 417 129 304 minecraft:stripped_oak_log
fill 417 129 305 417 132 305 minecraft:red_terracotta
setblock 417 129 309 minecraft:stripped_oak_log
fill 417 129 310 417 132 310 minecraft:red_terracotta
setblock 417 129 314 minecraft:stripped_oak_log
fill 417 129 315 417 131 316 minecraft:red_terracotta
setblock 377 130 278 minecraft:stripped_oak_log
fill 377 130 279 377 133 279 minecraft:red_terracotta
setblock 377 130 283 minecraft:stripped_oak_log
fill 377 130 284 377 133 284 minecraft:red_terracotta
setblock 377 130 288 minecraft:stripped_oak_log
fill 377 130 289 377 133 289 minecraft:red_terracotta
setblock 377 130 293 minecraft:stripped_oak_log
fill 377 130 294 377 133 294 minecraft:red_terracotta
fill 377 130 300 379 131 300 minecraft:iron_bars
setblock 377 130 303 minecraft:stripped_oak_log
fill 377 130 304 377 133 304 minecraft:red_terracotta
setblock 377 130 308 minecraft:stripped_oak_log
fill 377 130 309 377 133 309 minecraft:red_terracotta
setblock 377 130 313 minecraft:stripped_oak_log
fill 377 130 314 377 133 314 minecraft:red_terracotta
setblock 378 130 277 minecraft:stripped_oak_log
fill 378 130 278 378 132 278 minecraft:red_terracotta
setblock 378 130 282 minecraft:stripped_oak_log
fill 378 130 283 378 133 283 minecraft:red_terracotta
setblock 378 130 287 minecraft:stripped_oak_log
fill 378 130 288 378 133 288 minecraft:red_terracotta
setblock 378 130 307 minecraft:stripped_oak_log
fill 378 130 308 378 133 308 minecraft:red_terracotta
setblock 378 130 311 minecraft:red_terracotta
setblock 378 130 312 minecraft:stripped_oak_log
fill 378 130 313 379 132 313 minecraft:red_terracotta
setblock 378 130 316 minecraft:red_terracotta
setblock 379 130 276 minecraft:stripped_oak_log
fill 379 130 277 379 131 277 minecraft:red_terracotta
setblock 379 130 281 minecraft:stripped_oak_log
setblock 379 130 282 minecraft:red_terracotta
setblock 379 130 286 minecraft:stripped_oak_log
fill 379 130 287 379 131 287 minecraft:red_terracotta
setblock 379 130 307 minecraft:red_terracotta
setblock 379 130 311 minecraft:stripped_oak_log
fill 379 130 312 379 133 312 minecraft:red_terracotta
fill 379 130 314 379 133 314 minecraft:stripped_oak_log
setblock 379 130 316 minecraft:stripped_oak_log
fill 380 130 276 383 130 276 minecraft:red_terracotta
fill 380 130 313 380 135 313 minecraft:stripped_oak_log
setblock 380 130 315 minecraft:stripped_oak_log
fill 380 130 316 380 133 316 minecraft:red_terracotta
fill 381 130 314 381 135 314 minecraft:stripped_oak_log
fill 381 130 315 381 133 315 minecraft:red_terracotta
setblock 384 130 316 minecraft:stripped_oak_log
setblock 385 130 316 minecraft:red_terracotta
setblock 394 130 316 minecraft:stripped_oak_log
setblock 395 130 315 minecraft:stripped_oak_log
fill 395 130 316 395 133 316 minecraft:red_terracotta
fill 396 130 315 396 133 315 minecraft:red_terracotta
setblock 399 130 316 minecraft:stripped_oak_log
fill 400 130 316 400 131 316 minecraft:red_terracotta
fill 415 130 276 415 133 276 minecraft:red_terracotta
setblock 415 130 281 minecraft:red_terracotta
setblock 415 130 285 minecraft:stripped_oak_log
fill 415 130 286 415 133 286 minecraft:red_terracotta
setblock 415 130 290 minecraft:stripped_oak_log
fill 415 130 291 415 133 291 minecraft:red_terracotta
setblock 416 130 279 minecraft:stripped_oak_log
fill 416 130 280 416 133 280 minecraft:red_terracotta
setblock 416 130 284 minecraft:stripped_oak_log
fill 416 130 285 416 133 285 minecraft:red_terracotta
setblock 416 130 289 minecraft:stripped_oak_log
fill 416 130 290 416 133 290 minecraft:red_terracotta
setblock 416 130 293 minecraft:red_terracotta
setblock 416 130 294 minecraft:stripped_oak_log
setblock 416 130 305 minecraft:red_terracotta
setblock 416 130 308 minecraft:red_terracotta
setblock 416 130 309 minecraft:stripped_oak_log
fill 416 130 310 416 133 310 minecraft:red_terracotta
setblock 417 130 278 minecraft:stripped_oak_log
fill 417 130 279 417 133 279 minecraft:red_terracotta
setblock 417 130 283 minecraft:stripped_oak_log
fill 417 130 284 417 133 284 minecraft:red_terracotta
setblock 417 130 288 minecraft:stripped_oak_log
fill 417 130 289 417 133 289 minecraft:red_terracotta
setblock 417 130 293 minecraft:stripped_oak_log
fill 417 130 294 417 133 294 minecraft:red_terracotta
setblock 417 130 298 minecraft:stripped_oak_log
setblock 417 130 299 minecraft:red_terracotta
setblock 417 130 303 minecraft:stripped_oak_log
fill 417 130 304 417 132 304 minecraft:red_terracotta
setblock 417 130 308 minecraft:stripped_oak_log
fill 417 130 309 417 133 309 minecraft:red_terracotta
setblock 417 130 312 minecraft:red_terracotta
setblock 417 130 313 minecraft:stripped_oak_log
fill 417 130 314 417 133 314 minecraft:red_terracotta
setblock 377 131 277 minecraft:stripped_oak_log
fill 377 131 278 377 134 278 minecraft:red_terracotta
setblock 377 131 282 minecraft:stripped_oak_log
fill 377 131 283 377 134 283 minecraft:red_terracotta
setblock 377 131 287 minecraft:stripped_oak_log
fill 377 131 288 377 134 288 minecraft:red_terracotta
setblock 377 131 292 minecraft:stripped_oak_log
fill 377 131 293 377 134 293 minecraft:red_terracotta
setblock 377 131 302 minecraft:stripped_oak_log
fill 377 131 303 377 132 303 minecraft:red_terracotta
setblock 377 131 307 minecraft:stripped_oak_log
fill 377 131 308 377 134 308 minecraft:red_terracotta
setblock 377 131 312 minecraft:stripped_oak_log
fill 377 131 313 377 134 313 minecraft:red_terracotta
setblock 378 131 276 minecraft:stripped_oak_log
fill 378 131 277 378 132 277 minecraft:red_terracotta
setblock 378 131 281 minecraft:stripped_oak_log
fill 378 131 282 378 133 282 minecraft:red_terracotta
setblock 378 131 286 minecraft:stripped_oak_log
fill 378 131 287 378 134 287 minecraft:red_terracotta
setblock 378 131 291 minecraft:stripped_oak_log
setblock 378 131 306 minecraft:stripped_oak_log
fill 378 131 307 378 134 307 minecraft:red_terracotta
setblock 378 131 311 minecraft:stripped_oak_log
fill 378 131 312 378 134 312 minecraft:red_terracotta
setblock 378 131 316 minecraft:stripped_oak_log
fill 379 131 276 382 131 276 minecraft:red_terracotta
setblock 379 131 285 minecraft:stripped_oak_log
setblock 379 131 286 minecraft:red_terracotta
setblock 379 131 310 minecraft:stripped_oak_log
fill 379 131 311 379 134 311 minecraft:red_terracotta
setblock 379 131 315 minecraft:stripped_oak_log
fill 379 131 316 379 134 316 minecraft:red_terracotta
fill 380 131 315 380 134 315 minecraft:red_terracotta
setblock 383 131 316 minecraft:stripped_oak_log
fill 384 131 316 384 134 316 minecraft:red_terracotta
setblock 393 131 316 minecraft:stripped_oak_log
fill 394 131 316 394 134 316 minecraft:red_terracotta
fill 395 131 315 395 134 315 minecraft:red_terracotta
setblock 398 131 316 minecraft:stripped_oak_log
fill 399 131 316 399 134 316 minecraft:red_terracotta
fill 413 131 309 415 131 311 minecraft:terracotta
setblock 415 131 284 minecraft:stripped_oak_log
fill 415 131 285 415 134 285 minecraft:red_terracotta
setblock 415 131 289 minecraft:stripped_oak_log
fill 415 131 290 415 134 290 minecraft:red_terracotta
setblock 416 131 278 minecraft:stripped_oak_log
fill 416 131 279 416 134 279 minecraft:red_terracotta
setblock 416 131 283 minecraft:stripped_oak_log
fill 416 131 284 416 134 284 minecraft:red_terracotta
setblock 416 131 288 minecraft:stripped_oak_log
fill 416 131 289 416 134 289 minecraft:red_terracotta
setblock 416 131 293 minecraft:stripped_oak_log
fill 416 131 294 416 134 294 minecraft:red_terracotta
setblock 416 131 308 minecraft:stripped_oak_log
fill 416 131 309 416 134 309 minecraft:red_terracotta
fill 416 131 311 416 132 311 minecraft:red_terracotta
setblock 417 131 277 minecraft:stripped_oak_log
fill 417 131 278 417 134 278 minecraft:red_terracotta
setblock 417 131 282 minecraft:stripped_oak_log
fill 417 131 283 417 134 283 minecraft:red_terracotta
setblock 417 131 287 minecraft:stripped_oak_log
fill 417 131 288 417 134 288 minecraft:red_terracotta
setblock 417 131 292 minecraft:stripped_oak_log
fill 417 131 293 417 134 293 minecraft:red_terracotta
setblock 417 131 297 minecraft:stripped_oak_log
setblock 417 131 302 minecraft:stripped_oak_log
setblock 417 131 303 minecraft:red_terracotta
setblock 417 131 307 minecraft:stripped_oak_log
fill 417 131 308 417 134 308 minecraft:red_terracotta
setblock 417 131 312 minecraft:stripped_oak_log
fill 417 131 313 417 134 313 minecraft:red_terracotta
fill 376 132 275 376 135 317 minecraft:brown_terracotta
fill 377 132 275 418 135 275 minecraft:brown_terracotta
setblock 377 132 276 minecraft:stripped_oak_log
fill 377 132 277 377 135 277 minecraft:red_terracotta
setblock 377 132 281 minecraft:stripped_oak_log
fill 377 132 282 377 135 282 minecraft:red_terracotta
setblock 377 132 286 minecraft:stripped_oak_log
fill 377 132 287 377 135 287 minecraft:red_terracotta
setblock 377 132 291 minecraft:stripped_oak_log
fill 377 132 292 377 135 292 minecraft:red_terracotta
setblock 377 132 306 minecraft:stripped_oak_log
fill 377 132 307 377 135 307 minecraft:red_terracotta
setblock 377 132 311 minecraft:stripped_oak_log
fill 377 132 312 377 135 312 minecraft:red_terracotta
setblock 377 132 315 minecraft:red_terracotta
setblock 377 132 316 minecraft:stripped_oak_log
fill 377 132 317 418 135 317 minecraft:brown_terracotta
fill 378 132 276 381 132 276 minecraft:red_terracotta
setblock 378 132 280 minecraft:stripped_oak_log
setblock 378 132 281 minecraft:red_terracotta
setblock 378 132 285 minecraft:stripped_oak_log
fill 378 132 286 378 135 286 minecraft:red_terracotta
setblock 378 132 290 minecraft:stripped_oak_log
setblock 378 132 291 minecraft:red_terracotta
fill 378 132 306 378 133 306 minecraft:red_terracotta
setblock 378 132 310 minecraft:stripped_oak_log
fill 378 132 311 378 135 311 minecraft:red_terracotta
setblock 378 132 315 minecraft:stripped_oak_log
fill 378 132 316 378 135 316 minecraft:red_terracotta
setblock 379 132 278 minecraft:light[level=12]
setblock 379 132 285 minecraft:light[level=12]
setblock 379 132 292 minecraft:light[level=12]
setblock 379 132 299 minecraft:light[level=12]
setblock 379 132 306 minecraft:light[level=12]
setblock 379 132 309 minecraft:stripped_oak_log
fill 379 132 310 379 135 310 minecraft:red_terracotta
fill 379 132 315 379 135 315 minecraft:red_terracotta
setblock 382 132 316 minecraft:stripped_oak_log
fill 383 132 316 383 135 316 minecraft:red_terracotta
setblock 386 132 278 minecraft:light[level=12]
setblock 386 132 285 minecraft:light[level=12]
setblock 386 132 292 minecraft:light[level=12]
setblock 386 132 299 minecraft:light[level=12]
setblock 386 132 306 minecraft:light[level=12]
setblock 386 132 313 minecraft:light[level=12]
setblock 391 132 316 minecraft:red_terracotta
setblock 392 132 316 minecraft:stripped_oak_log
setblock 393 132 285 minecraft:light[level=12]
setblock 393 132 292 minecraft:light[level=12]
setblock 393 132 299 minecraft:light[level=12]
setblock 393 132 306 minecraft:light[level=12]
setblock 393 132 313 minecraft:light[level=12]
fill 393 132 316 393 135 316 minecraft:red_terracotta
fill 394 132 315 394 135 315 minecraft:red_terracotta
setblock 397 132 316 minecraft:stripped_oak_log
fill 398 132 316 398 135 316 minecraft:red_terracotta
setblock 400 132 278 minecraft:light[level=12]
setblock 400 132 285 minecraft:light[level=12]
setblock 400 132 292 minecraft:light[level=12]
setblock 400 132 299 minecraft:light[level=12]
setblock 400 132 306 minecraft:light[level=12]
setblock 400 132 313 minecraft:light[level=12]
setblock 407 132 278 minecraft:light[level=12]
setblock 407 132 285 minecraft:light[level=12]
setblock 407 132 292 minecraft:light[level=12]
setblock 407 132 299 minecraft:light[level=12]
setblock 407 132 306 minecraft:light[level=12]
setblock 407 132 313 minecraft:light[level=12]
setblock 414 132 278 minecraft:light[level=12]
setblock 414 132 285 minecraft:light[level=12]
setblock 414 132 292 minecraft:light[level=12]
setblock 414 132 299 minecraft:light[level=12]
setblock 414 132 306 minecraft:light[level=12]
fill 414 132 310 414 138 310 minecraft:green_concrete
setblock 414 132 313 minecraft:light[level=12]
setblock 415 132 283 minecraft:stripped_oak_log
fill 415 132 284 415 135 284 minecraft:red_terracotta
setblock 415 132 288 minecraft:stripped_oak_log
fill 415 132 289 415 135 289 minecraft:red_terracotta
setblock 416 132 282 minecraft:stripped_oak_log
fill 416 132 283 416 135 283 minecraft:red_terracotta
setblock 416 132 287 minecraft:stripped_oak_log
fill 416 132 288 416 135 288 minecraft:red_terracotta
setblock 416 132 292 minecraft:stripped_oak_log
fill 416 132 293 416 135 293 minecraft:red_terracotta
setblock 416 132 308 minecraft:red_terracotta
setblock 416 132 316 minecraft:red_terracotta
setblock 417 132 276 minecraft:stripped_oak_log
fill 417 132 277 417 135 277 minecraft:red_terracotta
setblock 417 132 281 minecraft:stripped_oak_log
fill 417 132 282 417 135 282 minecraft:red_terracotta
setblock 417 132 286 minecraft:stripped_oak_log
fill 417 132 287 417 135 287 minecraft:red_terracotta
setblock 417 132 291 minecraft:stripped_oak_log
fill 417 132 292 417 135 292 minecraft:red_terracotta
setblock 417 132 296 minecraft:stripped_oak_log
setblock 417 132 306 minecraft:stripped_oak_log
fill 417 132 307 417 135 307 minecraft:red_terracotta
setblock 417 132 311 minecraft:stripped_oak_log
fill 417 132 312 417 135 312 minecraft:red_terracotta
setblock 417 132 315 minecraft:red_terracotta
setblock 417 132 316 minecraft:stripped_oak_log
fill 418 132 276 418 135 316 minecraft:brown_terracotta
fill 377 133 276 380 133 276 minecraft:red_terracotta
setblock 377 133 280 minecraft:stripped_oak_log
fill 377 133 281 377 136 281 minecraft:red_terracotta
setblock 377 133 285 minecraft:stripped_oak_log
fill 377 133 286 377 136 286 minecraft:red_terracotta
setblock 377 133 290 minecraft:stripped_oak_log
fill 377 133 291 377 136 291 minecraft:red_terracotta
setblock 377 133 305 minecraft:stripped_oak_log
fill 377 133 306 377 136 306 minecraft:red_terracotta
setblock 377 133 310 minecraft:stripped_oak_log
fill 377 133 311 377 136 311 minecraft:red_terracotta
setblock 377 133 315 minecraft:stripped_oak_log
fill 377 133 316 377 136 316 minecraft:red_terracotta
setblock 378 133 284 minecraft:stripped_oak_log
fill 378 133 285 378 134 285 minecraft:red_terracotta
setblock 378 133 289 minecraft:stripped_oak_log
fill 378 133 290 378 136 290 minecraft:red_terracotta
setblock 378 133 309 minecraft:stripped_oak_log
fill 378 133 310 378 136 310 minecraft:red_terracotta
setblock 378 133 313 minecraft:red_terracotta
setblock 378 133 314 minecraft:stripped_oak_log
fill 378 133 315 378 136 315 minecraft:red_terracotta
setblock 379 133 313 minecraft:stripped_oak_log
fill 381 133 313 381 135 313 minecraft:stripped_oak_log
setblock 381 133 316 minecraft:stripped_oak_log
setblock 382 133 315 minecraft:stripped_oak_log
fill 382 133 316 382 136 316 minecraft:red_terracotta
setblock 390 133 316 minecraft:red_terracotta
setblock 391 133 316 minecraft:stripped_oak_log
fill 392 133 316 392 136 316 minecraft:red_terracotta
fill 393 133 315 393 136 315 minecraft:red_terracotta
setblock 396 133 316 minecraft:stripped_oak_log
setblock 397 133 315 minecraft:stripped_oak_log
fill 397 133 316 397 136 316 minecraft:red_terracotta
fill 407 133 278 407 142 278 minecraft:brown_terracotta
fill 414 133 276 414 134 276 minecraft:red_terracotta
setblock 415 133 283 minecraft:red_terracotta
setblock 415 133 287 minecraft:stripped_oak_log
fill 415 133 288 415 136 288 minecraft:red_terracotta
setblock 415 133 292 minecraft:stripped_oak_log
fill 415 133 313 415 134 315 minecraft:iron_bars
setblock 415 133 316 minecraft:red_terracotta
setblock 416 133 276 minecraft:stripped_oak_log
setblock 416 133 281 minecraft:stripped_oak_log
fill 416 133 282 416 136 282 minecraft:red_terracotta
setblock 416 133 286 minecraft:stripped_oak_log
fill 416 133 287 416 136 287 minecraft:red_terracotta
setblock 416 133 291 minecraft:stripped_oak_log
fill 416 133 292 416 136 292 minecraft:red_terracotta
setblock 416 133 311 minecraft:stripped_oak_log
fill 416 133 312 416 135 313 minecraft:red_terracotta
setblock 416 133 316 minecraft:stripped_oak_log
fill 417 133 276 417 136 276 minecraft:red_terracotta
setblock 417 133 280 minecraft:stripped_oak_log
fill 417 133 281 417 136 281 minecraft:red_terracotta
setblock 417 133 285 minecraft:stripped_oak_log
fill 417 133 286 417 136 286 minecraft:red_terracotta
setblock 417 133 290 minecraft:stripped_oak_log
fill 417 133 291 417 136 291 minecraft:red_terracotta
setblock 417 133 295 minecraft:stripped_oak_log
fill 417 133 296 417 136 296 minecraft:red_terracotta
setblock 417 133 305 minecraft:stripped_oak_log
fill 417 133 306 417 135 306 minecraft:red_terracotta
setblock 417 133 310 minecraft:stripped_oak_log
fill 417 133 311 417 136 311 minecraft:red_terracotta
setblock 417 133 315 minecraft:stripped_oak_log
fill 417 133 316 417 136 316 minecraft:red_terracotta
fill 377 134 276 379 134 276 minecraft:red_terracotta
setblock 377 134 279 minecraft:stripped_oak_log
fill 377 134 280 377 137 280 minecraft:red_terracotta
setblock 377 134 284 minecraft:stripped_oak_log
fill 377 134 285 377 137 285 minecraft:red_terracotta
setblock 377 134 289 minecraft:stripped_oak_log
fill 377 134 290 377 137 290 minecraft:red_terracotta
setblock 377 134 294 minecraft:stripped_oak_log
fill 377 134 305 377 137 305 minecraft:red_terracotta
setblock 377 134 309 minecraft:stripped_oak_log
fill 377 134 310 377 137 310 minecraft:red_terracotta
setblock 377 134 314 minecraft:stripped_oak_log
fill 377 134 315 377 137 315 minecraft:red_terracotta
setblock 378 134 284 minecraft:red_terracotta
setblock 378 134 288 minecraft:stripped_oak_log
fill 378 134 289 378 136 289 minecraft:red_terracotta
setblock 378 134 308 minecraft:stripped_oak_log
fill 378 134 309 378 137 309 minecraft:red_terracotta
setblock 378 134 313 minecraft:stripped_oak_log
fill 378 134 314 379 136 314 minecraft:red_terracotta
setblock 379 134 312 minecraft:stripped_oak_log
fill 379 134 313 379 137 313 minecraft:red_terracotta
setblock 380 134 276 minecraft:stripped_oak_log
setblock 380 134 316 minecraft:stripped_oak_log
setblock 381 134 315 minecraft:stripped_oak_log
fill 381 134 316 381 137 316 minecraft:red_terracotta
fill 382 134 315 382 137 315 minecraft:red_terracotta
setblock 385 134 316 minecraft:stripped_oak_log
fill 386 134 316 389 134 316 minecraft:red_terracotta
setblock 390 134 316 minecraft:stripped_oak_log
setblock 391 134 315 minecraft:stripped_oak_log
fill 391 134 316 391 137 316 minecraft:red_terracotta
fill 392 134 315 392 137 315 minecraft:red_terracotta
setblock 395 134 316 minecraft:stripped_oak_log
setblock 396 134 315 minecraft:stripped_oak_log
fill 396 134 316 396 137 316 minecraft:red_terracotta
fill 397 134 315 397 137 315 minecraft:red_terracotta
fill 413 134 276 413 135 276 minecraft:red_terracotta
setblock 414 134 316 minecraft:red_terracotta
setblock 415 134 276 minecraft:stripped_oak_log
setblock 415 134 286 minecraft:stripped_oak_log
fill 415 134 287 415 137 287 minecraft:red_terracotta
setblock 415 134 291 minecraft:stripped_oak_log
fill 415 134 292 415 137 292 minecraft:red_terracotta
setblock 415 134 316 minecraft:stripped_oak_log
fill 416 134 276 416 137 276 minecraft:red_terracotta
setblock 416 134 280 minecraft:stripped_oak_log
fill 416 134 281 416 137 281 minecraft:red_terracotta
setblock 416 134 285 minecraft:stripped_oak_log
fill 416 134 286 416 137 286 minecraft:red_terracotta
setblock 416 134 290 minecraft:stripped_oak_log
fill 416 134 291 416 137 291 minecraft:red_terracotta
setblock 416 134 310 minecraft:stripped_oak_log
fill 416 134 311 416 137 311 minecraft:red_terracotta
setblock 416 134 314 minecraft:red_terracotta
setblock 416 134 315 minecraft:stripped_oak_log
fill 416 134 316 416 137 316 minecraft:red_terracotta
setblock 417 134 279 minecraft:stripped_oak_log
fill 417 134 280 417 137 280 minecraft:red_terracotta
setblock 417 134 284 minecraft:stripped_oak_log
fill 417 134 285 417 137 285 minecraft:red_terracotta
setblock 417 134 289 minecraft:stripped_oak_log
fill 417 134 290 417 137 290 minecraft:red_terracotta
setblock 417 134 294 minecraft:stripped_oak_log
fill 417 134 295 417 137 295 minecraft:red_terracotta
setblock 417 134 309 minecraft:stripped_oak_log
fill 417 134 310 417 137 310 minecraft:red_terracotta
setblock 417 134 314 minecraft:stripped_oak_log
fill 417 134 315 417 137 315 minecraft:red_terracotta
fill 377 135 276 378 135 276 minecraft:red_terracotta
setblock 377 135 278 minecraft:stripped_oak_log
fill 377 135 279 377 138 279 minecraft:red_terracotta
setblock 377 135 283 minecraft:stripped_oak_log
fill 377 135 284 377 138 284 minecraft:red_terracotta
setblock 377 135 288 minecraft:stripped_oak_log
fill 377 135 289 377 138 289 minecraft:red_terracotta
setblock 377 135 293 minecraft:stripped_oak_log
fill 377 135 294 377 137 295 minecraft:red_terracotta
setblock 377 135 308 minecraft:stripped_oak_log
fill 377 135 309 377 138 309 minecraft:red_terracotta
setblock 377 135 313 minecraft:stripped_oak_log
fill 377 135 314 377 138 314 minecraft:red_terracotta
setblock 378 135 287 minecraft:stripped_oak_log
fill 378 135 288 378 136 288 minecraft:red_terracotta
setblock 378 135 307 minecraft:stripped_oak_log
fill 378 135 308 378 138 308 minecraft:red_terracotta
setblock 378 135 312 minecraft:stripped_oak_log
fill 378 135 313 378 138 313 minecraft:red_terracotta
setblock 379 135 276 minecraft:stripped_oak_log
setblock 379 135 311 minecraft:stripped_oak_log
fill 379 135 312 379 138 312 minecraft:red_terracotta
setblock 379 135 316 minecraft:stripped_oak_log
fill 380 135 276 380 138 276 minecraft:red_terracotta
setblock 380 135 314 minecraft:red_terracotta
setblock 380 135 315 minecraft:stripped_oak_log
fill 380 135 316 380 138 316 minecraft:red_terracotta
fill 381 135 315 381 138 315 minecraft:red_terracotta
fill 383 135 315 383 136 315 minecraft:red_terracotta
setblock 384 135 316 minecraft:stripped_oak_log
fill 385 135 316 388 135 316 minecraft:red_terracotta
setblock 389 135 315 minecraft:red_terracotta
setblock 389 135 316 minecraft:stripped_oak_log
setblock 390 135 315 minecraft:stripped_oak_log
fill 390 135 316 390 138 316 minecraft:red_terracotta
fill 391 135 315 391 138 315 minecraft:red_terracotta
fill 392 135 314 395 135 314 minecraft:red_terracotta
setblock 394 135 316 minecraft:stripped_oak_log
setblock 395 135 315 minecraft:stripped_oak_log
fill 395 135 316 395 138 316 minecraft:red_terracotta
setblock 396 135 314 minecraft:stripped_oak_log
fill 396 135 315 396 138 315 minecraft:red_terracotta
fill 398 135 315 398 136 315 minecraft:red_terracotta
setblock 399 135 316 minecraft:stripped_oak_log
fill 412 135 276 412 136 276 minecraft:red_terracotta
fill 412 135 316 413 135 316 minecraft:red_terracotta
setblock 414 135 276 minecraft:stripped_oak_log
fill 414 135 288 414 135 290 minecraft:red_terracotta
fill 414 135 311 414 137 311 minecraft:green_concrete
setblock 414 135 315 minecraft:red_terracotta
setblock 414 135 316 minecraft:stripped_oak_log
fill 415 135 276 415 137 277 minecraft:red_terracotta
setblock 415 135 285 minecraft:stripped_oak_log
fill 415 135 286 415 138 286 minecraft:red_terracotta
setblock 415 135 290 minecraft:stripped_oak_log
fill 415 135 291 415 138 291 minecraft:red_terracotta
fill 415 135 293 415 136 293 minecraft:red_terracotta
setblock 415 135 315 minecraft:stripped_oak_log
fill 415 135 316 415 138 316 minecraft:red_terracotta
fill 416 135 277 416 135 278 minecraft:red_terracotta
setblock 416 135 279 minecraft:stripped_oak_log
fill 416 135 280 416 138 280 minecraft:red_terracotta
setblock 416 135 284 minecraft:stripped_oak_log
fill 416 135 285 416 138 285 minecraft:red_terracotta
setblock 416 135 289 minecraft:stripped_oak_log
fill 416 135 290 416 138 290 minecraft:red_terracotta
setblock 416 135 294 minecraft:stripped_oak_log
fill 416 135 295 416 138 295 minecraft:red_terracotta
setblock 416 135 309 minecraft:stripped_oak_log
fill 416 135 310 416 138 310 minecraft:red_terracotta
setblock 416 135 314 minecraft:stripped_oak_log
fill 416 135 315 416 138 315 minecraft:red_terracotta
setblock 417 135 278 minecraft:stripped_oak_log
fill 417 135 279 417 138 279 minecraft:red_terracotta
setblock 417 135 283 minecraft:stripped_oak_log
fill 417 135 284 417 138 284 minecraft:red_terracotta
setblock 417 135 288 minecraft:stripped_oak_log
fill 417 135 289 417 138 289 minecraft:red_terracotta
setblock 417 135 293 minecraft:stripped_oak_log
fill 417 135 294 417 138 294 minecraft:red_terracotta
setblock 417 135 297 minecraft:red_terracotta
setblock 417 135 308 minecraft:stripped_oak_log
fill 417 135 309 417 138 309 minecraft:red_terracotta
setblock 417 135 313 minecraft:stripped_oak_log
fill 417 135 314 417 138 314 minecraft:red_terracotta
fill 376 136 275 376 139 317 minecraft:light_gray_terracotta
fill 377 136 275 418 139 275 minecraft:light_gray_terracotta
setblock 377 136 276 minecraft:red_terracotta
setblock 377 136 277 minecraft:stripped_oak_log
fill 377 136 278 377 139 278 minecraft:red_terracotta
setblock 377 136 282 minecraft:stripped_oak_log
fill 377 136 283 377 139 283 minecraft:red_terracotta
setblock 377 136 287 minecraft:stripped_oak_log
fill 377 136 288 377 139 288 minecraft:red_terracotta
setblock 377 136 292 minecraft:stripped_oak_log
fill 377 136 293 377 139 293 minecraft:red_terracotta
setblock 377 136 296 minecraft:red_terracotta
setblock 377 136 307 minecraft:stripped_oak_log
fill 377 136 308 377 139 308 minecraft:red_terracotta
setblock 377 136 312 minecraft:stripped_oak_log
fill 377 136 313 377 139 313 minecraft:red_terracotta
fill 377 136 317 418 139 317 minecraft:light_gray_terracotta
setblock 378 136 276 minecraft:stripped_oak_log
setblock 378 136 291 minecraft:stripped_oak_log
setblock 378 136 307 minecraft:red_terracotta
setblock 378 136 311 minecraft:stripped_oak_log
fill 378 136 312 378 139 312 minecraft:red_terracotta
setblock 378 136 316 minecraft:stripped_oak_log
fill 379 136 276 379 139 276 minecraft:red_terracotta
setblock 379 136 278 minecraft:light[level=15]
setblock 379 136 286 minecraft:light[level=15]
setblock 379 136 294 minecraft:light[level=15]
setblock 379 136 302 minecraft:light[level=15]
setblock 379 136 310 minecraft:stripped_oak_log
fill 379 136 311 379 139 311 minecraft:red_terracotta
setblock 379 136 315 minecraft:stripped_oak_log
fill 379 136 316 379 139 316 minecraft:red_terracotta
setblock 380 136 314 minecraft:stripped_oak_log
fill 380 136 315 380 139 315 minecraft:red_terracotta
setblock 383 136 316 minecraft:stripped_oak_log
setblock 384 136 315 minecraft:stripped_oak_log
fill 384 136 316 387 136 316 minecraft:red_terracotta
fill 385 136 315 388 136 315 minecraft:red_terracotta
setblock 387 136 278 minecraft:light[level=15]
setblock 387 136 286 minecraft:light[level=15]
setblock 387 136 294 minecraft:light[level=15]
setblock 387 136 302 minecraft:light[level=15]
setblock 387 136 310 minecraft:light[level=15]
setblock 388 136 316 minecraft:stripped_oak_log
setblock 389 136 315 minecraft:stripped_oak_log
fill 389 136 316 389 139 316 minecraft:red_terracotta
setblock 390 136 314 minecraft:stripped_oak_log
fill 390 136 315 390 139 315 minecraft:red_terracotta
fill 391 136 314 394 136 314 minecraft:red_terracotta
setblock 393 136 316 minecraft:stripped_oak_log
setblock 394 136 315 minecraft:stripped_oak_log
fill 394 136 316 394 139 316 minecraft:red_terracotta
setblock 395 136 286 minecraft:light[level=15]
setblock 395 136 294 minecraft:light[level=15]
setblock 395 136 302 minecraft:light[level=15]
setblock 395 136 310 minecraft:light[level=15]
setblock 395 136 314 minecraft:stripped_oak_log
fill 395 136 315 395 139 315 minecraft:red_terracotta
fill 396 136 314 396 139 314 minecraft:red_terracotta
setblock 398 136 316 minecraft:stripped_oak_log
fill 399 136 316 399 139 316 minecraft:red_terracotta
setblock 403 136 278 minecraft:light[level=15]
setblock 403 136 286 minecraft:light[level=15]
setblock 403 136 294 minecraft:light[level=15]
setblock 403 136 302 minecraft:light[level=15]
setblock 403 136 310 minecraft:light[level=15]
fill 411 136 276 411 137 276 minecraft:red_terracotta
setblock 411 136 278 minecraft:light[level=15]
setblock 411 136 286 minecraft:light[level=15]
setblock 411 136 294 minecraft:light[level=15]
setblock 411 136 302 minecraft:light[level=15]
setblock 411 136 310 minecraft:light[level=15]
fill 411 136 316 412 136 316 minecraft:red_terracotta
setblock 413 136 276 minecraft:stripped_oak_log
fill 413 136 277 414 138 277 minecraft:red_terracotta
setblock 413 136 315 minecraft:red_terracotta
setblock 413 136 316 minecraft:stripped_oak_log
fill 414 136 276 414 139 276 minecraft:red_terracotta
fill 414 136 288 414 136 289 minecraft:red_terracotta
setblock 414 136 290 minecraft:stripped_oak_log
fill 414 136 291 414 139 291 minecraft:red_terracotta
setblock 414 136 315 minecraft:stripped_oak_log
fill 414 136 316 414 139 316 minecraft:red_terracotta
setblock 415 136 284 minecraft:stripped_oak_log
fill 415 136 285 415 139 285 minecraft:red_terracotta
setblock 415 136 289 minecraft:stripped_oak_log
fill 415 136 290 415 139 290 minecraft:red_terracotta
setblock 415 136 294 minecraft:stripped_oak_log
fill 415 136 315 415 139 315 minecraft:red_terracotta
setblock 416 136 277 minecraft:red_terracotta
setblock 416 136 278 minecraft:stripped_oak_log
fill 416 136 279 416 139 279 minecraft:red_terracotta
setblock 416 136 283 minecraft:stripped_oak_log
fill 416 136 284 416 139 284 minecraft:red_terracotta
setblock 416 136 288 minecraft:stripped_oak_log
fill 416 136 289 416 139 289 minecraft:red_terracotta
setblock 416 136 293 minecraft:stripped_oak_log
fill 416 136 294 416 139 294 minecraft:red_terracotta
fill 416 136 296 416 137 296 minecraft:red_terracotta
fill 416 136 309 416 139 309 minecraft:red_terracotta
setblock 416 136 312 minecraft:red_terracotta
setblock 416 136 313 minecraft:stripped_oak_log
fill 416 136 314 416 139 314 minecraft:red_terracotta
setblock 417 136 277 minecraft:stripped_oak_log
fill 417 136 278 417 139 278 minecraft:red_terracotta
setblock 417 136 282 minecraft:stripped_oak_log
fill 417 136 283 417 139 283 minecraft:red_terracotta
setblock 417 136 287 minecraft:stripped_oak_log
fill 417 136 288 417 139 288 minecraft:red_terracotta
setblock 417 136 292 minecraft:stripped_oak_log
fill 417 136 293 417 139 293 minecraft:red_terracotta
setblock 417 136 297 minecraft:stripped_oak_log
setblock 417 136 307 minecraft:stripped_oak_log
fill 417 136 308 417 139 308 minecraft:red_terracotta
setblock 417 136 312 minecraft:stripped_oak_log
fill 417 136 313 417 139 313 minecraft:red_terracotta
fill 418 136 276 418 139 316 minecraft:light_gray_terracotta
setblock 377 137 276 minecraft:stripped_oak_log
fill 377 137 277 378 139 277 minecraft:red_terracotta
setblock 377 137 281 minecraft:stripped_oak_log
fill 377 137 282 377 140 282 minecraft:red_terracotta
setblock 377 137 286 minecraft:stripped_oak_log
fill 377 137 287 377 140 287 minecraft:red_terracotta
setblock 377 137 291 minecraft:stripped_oak_log
fill 377 137 292 377 140 292 minecraft:red_terracotta
setblock 377 137 296 minecraft:stripped_oak_log
fill 377 137 297 377 140 297 minecraft:red_terracotta
setblock 377 137 306 minecraft:stripped_oak_log
fill 377 137 307 377 140 307 minecraft:red_terracotta
setblock 377 137 311 minecraft:stripped_oak_log
fill 377 137 312 377 140 312 minecraft:red_terracotta
setblock 377 137 316 minecraft:stripped_oak_log
fill 378 137 276 378 140 276 minecraft:red_terracotta
setblock 378 137 290 minecraft:stripped_oak_log
fill 378 137 291 378 138 291 minecraft:red_terracotta
setblock 378 137 310 minecraft:stripped_oak_log
fill 378 137 311 378 140 311 minecraft:red_terracotta
setblock 378 137 314 minecraft:red_terracotta
setblock 378 137 315 minecraft:stripped_oak_log
fill 378 137 316 378 140 316 minecraft:red_terracotta
setblock 379 137 310 minecraft:red_terracotta
setblock 379 137 314 minecraft:stripped_oak_log
fill 379 137 315 379 140 315 minecraft:red_terracotta
fill 380 137 314 381 139 314 minecraft:red_terracotta
setblock 381 137 276 minecraft:red_terracotta
setblock 382 137 316 minecraft:stripped_oak_log
setblock 383 137 315 minecraft:stripped_oak_log
fill 383 137 316 386 137 316 minecraft:red_terracotta
fill 384 137 315 387 137 315 minecraft:red_terracotta
setblock 387 137 316 minecraft:stripped_oak_log
setblock 388 137 314 minecraft:red_terracotta
setblock 388 137 315 minecraft:stripped_oak_log
fill 388 137 316 388 140 316 minecraft:red_terracotta
setblock 389 137 314 minecraft:stripped_oak_log
fill 389 137 315 389 140 315 minecraft:red_terracotta
fill 390 137 314 393 137 314 minecraft:red_terracotta
setblock 391 137 276 minecraft:red_terracotta
setblock 392 137 276 minecraft:stripped_oak_log
fill 392 137 313 394 137 313 minecraft:red_terracotta
setblock 392 137 316 minecraft:stripped_oak_log
fill 393 137 276 396 137 276 minecraft:red_terracotta
setblock 393 137 315 minecraft:stripped_oak_log
fill 393 137 316 393 140 316 minecraft:red_terracotta
setblock 394 137 314 minecraft:stripped_oak_log
fill 394 137 315 394 140 315 minecraft:red_terracotta
fill 395 137 314 395 140 314 minecraft:red_terracotta
fill 397 137 314 397 138 314 minecraft:red_terracotta
setblock 397 137 316 minecraft:stripped_oak_log
setblock 398 137 315 minecraft:stripped_oak_log
fill 398 137 316 398 140 316 minecraft:red_terracotta
fill 400 137 316 400 138 316 minecraft:red_terracotta
fill 409 137 276 410 138 276 minecraft:red_terracotta
fill 409 137 316 411 137 316 minecraft:red_terracotta
setblock 411 137 277 minecraft:stripped_oak_log
fill 411 137 315 412 137 315 minecraft:red_terracotta
setblock 412 137 276 minecraft:stripped_oak_log
fill 412 137 277 412 140 277 minecraft:red_terracotta
setblock 412 137 316 minecraft:stripped_oak_log
fill 413 137 276 413 140 276 minecraft:red_terracotta
setblock 413 137 315 minecraft:stripped_oak_log
fill 413 137 316 413 140 316 minecraft:red_terracotta
setblock 414 137 288 minecraft:red_terracotta
setblock 414 137 289 minecraft:stripped_oak_log
fill 414 137 290 414 140 290 minecraft:red_terracotta
fill 414 137 292 414 138 292 minecraft:red_terracotta
setblock 414 137 314 minecraft:stripped_oak_log
fill 414 137 315 414 140 315 minecraft:red_terracotta
fill 415 137 284 415 139 284 minecraft:red_terracotta
setblock 415 137 288 minecraft:stripped_oak_log
fill 415 137 289 415 140 289 minecraft:red_terracotta
setblock 415 137 293 minecraft:stripped_oak_log
fill 415 137 294 415 140 294 minecraft:red_terracotta
setblock 415 137 312 minecraft:red_terracotta
setblock 415 137 313 minecraft:stripped_oak_log
fill 415 137 314 415 140 314 minecraft:red_terracotta
setblock 416 137 277 minecraft:stripped_oak_log
fill 416 137 278 416 140 278 minecraft:red_terracotta
setblock 416 137 282 minecraft:stripped_oak_log
fill 416 137 283 416 140 283 minecraft:red_terracotta
setblock 416 137 287 minecraft:stripped_oak_log
fill 416 137 288 416 140 288 minecraft:red_terracotta
setblock 416 137 292 minecraft:stripped_oak_log
fill 416 137 293 416 140 293 minecraft:red_terracotta
setblock 416 137 312 minecraft:stripped_oak_log
fill 416 137 313 416 140 313 minecraft:red_terracotta
setblock 417 137 276 minecraft:stripped_oak_log
fill 417 137 277 417 140 277 minecraft:red_terracotta
setblock 417 137 281 minecraft:stripped_oak_log
fill 417 137 282 417 140 282 minecraft:red_terracotta
setblock 417 137 286 minecraft:stripped_oak_log
fill 417 137 287 417 140 287 minecraft:red_terracotta
setblock 417 137 291 minecraft:stripped_oak_log
fill 417 137 292 417 140 292 minecraft:red_terracotta
setblock 417 137 296 minecraft:stripped_oak_log
fill 417 137 297 417 139 298 minecraft:red_terracotta
fill 417 137 307 417 139 307 minecraft:red_terracotta
setblock 417 137 311 minecraft:stripped_oak_log
fill 417 137 312 417 140 312 minecraft:red_terracotta
setblock 417 137 316 minecraft:stripped_oak_log
fill 377 138 276 377 141 276 minecraft:red_terracotta
setblock 377 138 280 minecraft:stripped_oak_log
fill 377 138 281 377 141 281 minecraft:red_terracotta
setblock 377 138 285 minecraft:stripped_oak_log
fill 377 138 286 377 140 286 minecraft:red_terracotta
setblock 377 138 290 minecraft:stripped_oak_log
fill 377 138 291 377 141 291 minecraft:red_terracotta
setblock 377 138 294 minecraft:red_terracotta
setblock 377 138 295 minecraft:stripped_oak_log
fill 377 138 296 377 141 296 minecraft:red_terracotta
fill 377 138 298 377 139 298 minecraft:red_terracotta
setblock 377 138 305 minecraft:stripped_oak_log
fill 377 138 306 377 141 306 minecraft:red_terracotta
setblock 377 138 310 minecraft:stripped_oak_log
fill 377 138 311 377 141 311 minecraft:red_terracotta
setblock 377 138 315 minecraft:stripped_oak_log
fill 377 138 316 377 141 316 minecraft:red_terracotta
fill 378 138 292 378 139 292 minecraft:red_terracotta
setblock 378 138 309 minecraft:stripped_oak_log
fill 378 138 310 378 141 310 minecraft:red_terracotta
setblock 378 138 314 minecraft:stripped_oak_log
fill 378 138 315 378 141 315 minecraft:red_terracotta
setblock 379 138 278 minecraft:light[level=12]
setblock 379 138 285 minecraft:light[level=12]
setblock 379 138 292 minecraft:light[level=12]
setblock 379 138 299 minecraft:light[level=12]
setblock 379 138 306 minecraft:light[level=12]
setblock 379 138 313 minecraft:stripped_oak_log
fill 379 138 314 379 141 314 minecraft:red_terracotta
setblock 381 138 276 minecraft:stripped_oak_log
setblock 381 138 316 minecraft:stripped_oak_log
setblock 382 138 314 minecraft:red_terracotta
setblock 382 138 315 minecraft:stripped_oak_log
fill 382 138 316 385 138 316 minecraft:red_terracotta
fill 383 138 315 386 138 315 minecraft:red_terracotta
setblock 386 138 278 minecraft:light[level=12]
setblock 386 138 285 minecraft:light[level=12]
setblock 386 138 292 minecraft:light[level=12]
setblock 386 138 299 minecraft:light[level=12]
setblock 386 138 306 minecraft:light[level=12]
setblock 386 138 313 minecraft:light[level=12]
fill 386 138 314 387 138 314 minecraft:red_terracotta
setblock 386 138 316 minecraft:stripped_oak_log
setblock 387 138 315 minecraft:stripped_oak_log
fill 387 138 316 387 141 316 minecraft:red_terracotta
setblock 388 138 314 minecraft:stripped_oak_log
fill 388 138 315 388 141 315 minecraft:red_terracotta
fill 389 138 276 390 138 276 minecraft:red_terracotta
fill 389 138 314 392 138 314 minecraft:red_terracotta
setblock 391 138 276 minecraft:stripped_oak_log
fill 391 138 313 393 138 313 minecraft:red_terracotta
setblock 391 138 316 minecraft:stripped_oak_log
fill 392 138 276 395 138 276 minecraft:red_terracotta
setblock 392 138 315 minecraft:stripped_oak_log
fill 392 138 316 392 141 316 minecraft:red_terracotta
setblock 393 138 285 minecraft:light[level=12]
setblock 393 138 292 minecraft:light[level=12]
setblock 393 138 299 minecraft:light[level=12]
setblock 393 138 306 minecraft:light[level=12]
setblock 393 138 314 minecraft:stripped_oak_log
fill 393 138 315 393 141 315 minecraft:red_terracotta
setblock 394 138 313 minecraft:stripped_oak_log
fill 394 138 314 394 141 314 minecraft:red_terracotta
setblock 396 138 276 minecraft:stripped_oak_log
setblock 396 138 316 minecraft:stripped_oak_log
fill 397 138 276 397 141 276 minecraft:red_terracotta
setblock 397 138 315 minecraft:stripped_oak_log
fill 397 138 316 397 141 316 minecraft:red_terracotta
fill 398 138 315 398 141 315 minecraft:red_terracotta
setblock 400 138 278 minecraft:light[level=12]
setblock 400 138 285 minecraft:light[level=12]
setblock 400 138 292 minecraft:light[level=12]
setblock 400 138 299 minecraft:light[level=12]
setblock 400 138 306 minecraft:light[level=12]
setblock 400 138 313 minecraft:light[level=12]
fill 407 138 276 408 140 276 minecraft:red_terracotta
setblock 407 138 285 minecraft:light[level=12]
setblock 407 138 292 minecraft:light[level=12]
setblock 407 138 299 minecraft:light[level=12]
setblock 407 138 306 minecraft:light[level=12]
setblock 407 138 313 minecraft:light[level=12]
fill 407 138 316 410 138 316 minecraft:red_terracotta
setblock 410 138 277 minecraft:stripped_oak_log
fill 410 138 315 411 138 315 minecraft:red_terracotta
setblock 411 138 276 minecraft:stripped_oak_log
fill 411 138 277 411 141 277 minecraft:red_terracotta
setblock 411 138 316 minecraft:stripped_oak_log
fill 412 138 276 412 141 276 minecraft:red_terracotta
setblock 412 138 314 minecraft:red_terracotta
setblock 412 138 315 minecraft:stripped_oak_log
fill 412 138 316 412 141 316 minecraft:red_terracotta
setblock 413 138 278 minecraft:red_terracotta
setblock 413 138 314 minecraft:stripped_oak_log
fill 413 138 315 413 141 315 minecraft:red_terracotta
setblock 414 138 278 minecraft:stripped_oak_log
setblock 414 138 285 minecraft:light[level=12]
setblock 414 138 288 minecraft:stripped_oak_log
fill 414 138 289 414 139 289 minecraft:red_terracotta
setblock 414 138 293 minecraft:stripped_oak_log
setblock 414 138 299 minecraft:light[level=12]
setblock 414 138 306 minecraft:light[level=12]
setblock 414 138 313 minecraft:light[level=12]
fill 414 138 314 414 141 314 minecraft:red_terracotta
setblock 415 138 276 minecraft:red_terracotta
setblock 415 138 277 minecraft:stripped_oak_log
fill 415 138 278 415 140 279 minecraft:red_terracotta
setblock 415 138 287 minecraft:stripped_oak_log
fill 415 138 288 415 141 288 minecraft:red_terracotta
setblock 415 138 292 minecraft:stripped_oak_log
fill 415 138 293 415 141 293 minecraft:red_terracotta
fill 415 138 295 415 139 295 minecraft:red_terracotta
setblock 415 138 312 minecraft:stripped_oak_log
fill 415 138 313 415 141 313 minecraft:red_terracotta
setblock 416 138 276 minecraft:stripped_oak_log
fill 416 138 277 416 141 277 minecraft:red_terracotta
setblock 416 138 281 minecraft:stripped_oak_log
fill 416 138 282 416 141 282 minecraft:red_terracotta
setblock 416 138 286 minecraft:stripped_oak_log
fill 416 138 287 416 141 287 minecraft:red_terracotta
setblock 416 138 291 minecraft:stripped_oak_log
fill 416 138 292 416 141 292 minecraft:red_terracotta
setblock 416 138 296 minecraft:stripped_oak_log
fill 416 138 297 416 141 297 minecraft:red_terracotta
setblock 416 138 311 minecraft:stripped_oak_log
fill 416 138 312 416 141 312 minecraft:red_terracotta
schedule function dropper:buildpart/68_3 1t
