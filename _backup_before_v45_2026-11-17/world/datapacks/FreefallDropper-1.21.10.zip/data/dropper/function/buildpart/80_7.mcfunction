fill 380 239 343 380 239 345 minecraft:gray_wool
setblock 380 239 346 minecraft:light_gray_wool
fill 380 239 347 380 239 349 minecraft:gray_wool
setblock 380 239 350 minecraft:light_gray_wool
fill 380 239 351 380 239 353 minecraft:gray_wool
setblock 380 239 354 minecraft:light_gray_wool
fill 380 239 355 380 239 357 minecraft:gray_wool
setblock 380 239 358 minecraft:light_gray_wool
fill 380 239 359 382 239 359 minecraft:gray_wool
setblock 380 239 362 minecraft:light_gray_wool
fill 380 239 363 382 239 363 minecraft:gray_wool
fill 381 239 323 381 239 324 minecraft:gray_wool
setblock 381 239 325 minecraft:light_gray_wool
fill 381 239 326 381 239 328 minecraft:gray_wool
setblock 381 239 329 minecraft:light_gray_wool
fill 381 239 330 381 239 332 minecraft:gray_wool
setblock 381 239 333 minecraft:light_gray_wool
fill 381 239 334 381 239 336 minecraft:gray_wool
setblock 381 239 337 minecraft:light_gray_wool
fill 381 239 338 381 239 340 minecraft:gray_wool
setblock 381 239 341 minecraft:light_gray_wool
fill 381 239 342 381 239 344 minecraft:gray_wool
setblock 381 239 345 minecraft:light_gray_wool
fill 381 239 346 381 239 348 minecraft:gray_wool
setblock 381 239 349 minecraft:light_gray_wool
fill 381 239 350 381 239 352 minecraft:gray_wool
setblock 381 239 353 minecraft:light_gray_wool
fill 381 239 354 381 239 356 minecraft:gray_wool
setblock 381 239 357 minecraft:light_gray_wool
fill 381 239 358 383 239 358 minecraft:gray_wool
setblock 381 239 361 minecraft:light_gray_wool
fill 381 239 362 383 239 362 minecraft:gray_wool
setblock 382 239 323 minecraft:gray_wool
setblock 382 239 324 minecraft:light_gray_wool
fill 382 239 325 382 239 327 minecraft:gray_wool
setblock 382 239 328 minecraft:light_gray_wool
fill 382 239 329 382 239 331 minecraft:gray_wool
setblock 382 239 332 minecraft:light_gray_wool
fill 382 239 333 382 239 335 minecraft:gray_wool
setblock 382 239 336 minecraft:light_gray_wool
fill 382 239 337 382 239 339 minecraft:gray_wool
setblock 382 239 340 minecraft:light_gray_wool
fill 382 239 341 382 239 343 minecraft:gray_wool
setblock 382 239 344 minecraft:light_gray_wool
fill 382 239 345 382 239 347 minecraft:gray_wool
setblock 382 239 348 minecraft:light_gray_wool
fill 382 239 349 382 239 351 minecraft:gray_wool
setblock 382 239 352 minecraft:light_gray_wool
fill 382 239 353 382 239 355 minecraft:gray_wool
setblock 382 239 356 minecraft:light_gray_wool
fill 382 239 357 384 239 357 minecraft:gray_wool
setblock 382 239 360 minecraft:light_gray_wool
fill 382 239 361 384 239 361 minecraft:gray_wool
setblock 383 239 323 minecraft:light_gray_wool
fill 383 239 324 383 239 326 minecraft:gray_wool
setblock 383 239 327 minecraft:light_gray_wool
fill 383 239 328 383 239 330 minecraft:gray_wool
setblock 383 239 331 minecraft:light_gray_wool
fill 383 239 332 383 239 334 minecraft:gray_wool
setblock 383 239 335 minecraft:light_gray_wool
fill 383 239 336 383 239 338 minecraft:gray_wool
setblock 383 239 339 minecraft:light_gray_wool
fill 383 239 340 383 239 342 minecraft:gray_wool
setblock 383 239 343 minecraft:light_gray_wool
fill 383 239 344 383 239 346 minecraft:gray_wool
setblock 383 239 347 minecraft:light_gray_wool
fill 383 239 348 383 239 350 minecraft:gray_wool
setblock 383 239 351 minecraft:light_gray_wool
fill 383 239 352 383 239 354 minecraft:gray_wool
setblock 383 239 355 minecraft:light_gray_wool
fill 383 239 356 385 239 356 minecraft:gray_wool
setblock 383 239 359 minecraft:light_gray_wool
fill 383 239 360 385 239 360 minecraft:gray_wool
setblock 383 239 363 minecraft:light_gray_wool
fill 384 239 323 384 239 325 minecraft:gray_wool
setblock 384 239 326 minecraft:light_gray_wool
fill 384 239 327 384 239 329 minecraft:gray_wool
setblock 384 239 330 minecraft:light_gray_wool
fill 384 239 331 384 239 333 minecraft:gray_wool
setblock 384 239 334 minecraft:light_gray_wool
fill 384 239 335 384 239 337 minecraft:gray_wool
setblock 384 239 338 minecraft:light_gray_wool
fill 384 239 339 384 239 341 minecraft:gray_wool
setblock 384 239 342 minecraft:light_gray_wool
fill 384 239 343 384 239 345 minecraft:gray_wool
setblock 384 239 346 minecraft:light_gray_wool
fill 384 239 347 384 239 349 minecraft:gray_wool
setblock 384 239 350 minecraft:light_gray_wool
fill 384 239 351 384 239 353 minecraft:gray_wool
setblock 384 239 354 minecraft:light_gray_wool
fill 384 239 355 386 239 355 minecraft:gray_wool
setblock 384 239 358 minecraft:light_gray_wool
fill 384 239 359 386 239 359 minecraft:gray_wool
setblock 384 239 362 minecraft:light_gray_wool
fill 384 239 363 386 239 363 minecraft:gray_wool
fill 385 239 323 385 239 324 minecraft:gray_wool
setblock 385 239 325 minecraft:light_gray_wool
fill 385 239 326 385 239 328 minecraft:gray_wool
setblock 385 239 329 minecraft:light_gray_wool
fill 385 239 330 385 239 332 minecraft:gray_wool
setblock 385 239 333 minecraft:light_gray_wool
fill 385 239 334 385 239 336 minecraft:gray_wool
fill 385 239 337 392 239 337 minecraft:blackstone
fill 385 239 338 385 239 340 minecraft:gray_wool
setblock 385 239 341 minecraft:light_gray_wool
fill 385 239 342 385 239 344 minecraft:gray_wool
setblock 385 239 345 minecraft:light_gray_wool
fill 385 239 346 385 239 348 minecraft:gray_wool
setblock 385 239 349 minecraft:light_gray_wool
fill 385 239 350 385 239 352 minecraft:gray_wool
setblock 385 239 353 minecraft:light_gray_wool
fill 385 239 354 387 239 354 minecraft:gray_wool
setblock 385 239 357 minecraft:light_gray_wool
fill 385 239 358 387 239 358 minecraft:gray_wool
setblock 385 239 361 minecraft:light_gray_wool
fill 385 239 362 387 239 362 minecraft:gray_wool
setblock 386 239 323 minecraft:gray_wool
setblock 386 239 324 minecraft:light_gray_wool
fill 386 239 325 386 239 327 minecraft:gray_wool
setblock 386 239 328 minecraft:light_gray_wool
fill 386 239 329 386 239 331 minecraft:gray_wool
setblock 386 239 332 minecraft:light_gray_wool
fill 386 239 333 386 239 336 minecraft:polished_blackstone
fill 386 239 338 386 239 341 minecraft:polished_blackstone
fill 386 239 342 386 239 343 minecraft:gray_wool
setblock 386 239 344 minecraft:light_gray_wool
fill 386 239 345 386 239 347 minecraft:gray_wool
setblock 386 239 348 minecraft:light_gray_wool
fill 386 239 349 386 239 351 minecraft:gray_wool
setblock 386 239 352 minecraft:light_gray_wool
fill 386 239 353 388 239 353 minecraft:gray_wool
setblock 386 239 356 minecraft:light_gray_wool
fill 386 239 357 388 239 357 minecraft:gray_wool
setblock 386 239 360 minecraft:light_gray_wool
fill 386 239 361 388 239 361 minecraft:gray_wool
setblock 387 239 323 minecraft:light_gray_wool
fill 387 239 324 387 239 326 minecraft:gray_wool
setblock 387 239 327 minecraft:light_gray_wool
fill 387 239 331 387 239 332 minecraft:polished_blackstone
fill 387 239 333 392 239 336 minecraft:blackstone
fill 387 239 338 392 239 341 minecraft:blackstone
fill 387 239 342 387 239 343 minecraft:polished_blackstone
setblock 387 239 347 minecraft:light_gray_wool
fill 387 239 348 387 239 350 minecraft:gray_wool
setblock 387 239 351 minecraft:light_gray_wool
fill 387 239 352 389 239 352 minecraft:gray_wool
setblock 387 239 355 minecraft:light_gray_wool
fill 387 239 356 389 239 356 minecraft:gray_wool
setblock 387 239 359 minecraft:light_gray_wool
fill 387 239 360 389 239 360 minecraft:gray_wool
setblock 387 239 363 minecraft:light_gray_wool
fill 387 239 364 387 246 364 minecraft:black_concrete
fill 388 239 323 388 239 325 minecraft:gray_wool
setblock 388 239 326 minecraft:light_gray_wool
fill 388 239 327 390 239 327 minecraft:gray_wool
fill 388 239 332 404 239 332 minecraft:blackstone
fill 388 239 342 404 239 342 minecraft:blackstone
fill 388 239 347 388 239 349 minecraft:gray_wool
setblock 388 239 350 minecraft:light_gray_wool
fill 388 239 351 390 239 351 minecraft:gray_wool
setblock 388 239 354 minecraft:light_gray_wool
fill 388 239 355 390 239 355 minecraft:gray_wool
setblock 388 239 358 minecraft:light_gray_wool
fill 388 239 359 390 239 359 minecraft:gray_wool
setblock 388 239 362 minecraft:light_gray_wool
fill 388 239 363 390 239 363 minecraft:gray_wool
fill 389 239 323 389 239 324 minecraft:gray_wool
setblock 389 239 325 minecraft:light_gray_wool
fill 389 239 326 391 239 326 minecraft:gray_wool
fill 389 239 347 389 239 348 minecraft:gray_wool
setblock 389 239 349 minecraft:light_gray_wool
fill 389 239 350 391 239 350 minecraft:gray_wool
setblock 389 239 353 minecraft:light_gray_wool
fill 389 239 354 391 239 354 minecraft:gray_wool
setblock 389 239 357 minecraft:light_gray_wool
fill 389 239 358 391 239 358 minecraft:gray_wool
setblock 389 239 361 minecraft:light_gray_wool
fill 389 239 362 391 239 362 minecraft:gray_wool
setblock 390 239 323 minecraft:gray_wool
setblock 390 239 324 minecraft:light_gray_wool
fill 390 239 325 392 239 325 minecraft:gray_wool
fill 390 239 328 391 239 328 minecraft:polished_blackstone
fill 390 239 346 391 239 346 minecraft:polished_blackstone
setblock 390 239 347 minecraft:gray_wool
setblock 390 239 348 minecraft:light_gray_wool
fill 390 239 349 392 239 349 minecraft:gray_wool
setblock 390 239 352 minecraft:light_gray_wool
fill 390 239 353 392 239 353 minecraft:gray_wool
setblock 390 239 356 minecraft:light_gray_wool
fill 390 239 357 392 239 357 minecraft:gray_wool
setblock 390 239 360 minecraft:light_gray_wool
fill 390 239 361 392 239 361 minecraft:gray_wool
setblock 391 239 323 minecraft:light_gray_wool
fill 391 239 324 393 239 324 minecraft:gray_wool
setblock 391 239 327 minecraft:light_gray_wool
setblock 391 239 347 minecraft:light_gray_wool
fill 391 239 348 393 239 348 minecraft:gray_wool
setblock 391 239 351 minecraft:light_gray_wool
fill 391 239 352 393 239 352 minecraft:gray_wool
setblock 391 239 355 minecraft:light_gray_wool
fill 391 239 356 393 239 356 minecraft:gray_wool
setblock 391 239 359 minecraft:light_gray_wool
fill 391 239 360 393 239 360 minecraft:gray_wool
setblock 391 239 363 minecraft:light_gray_wool
fill 392 239 323 394 239 323 minecraft:gray_wool
setblock 392 239 326 minecraft:light_gray_wool
fill 392 239 327 395 239 327 minecraft:polished_blackstone
fill 392 239 328 400 239 328 minecraft:blackstone
fill 392 239 346 400 239 346 minecraft:blackstone
fill 392 239 347 395 239 347 minecraft:polished_blackstone
setblock 392 239 350 minecraft:light_gray_wool
fill 392 239 351 394 239 351 minecraft:gray_wool
setblock 392 239 354 minecraft:light_gray_wool
fill 392 239 355 394 239 355 minecraft:gray_wool
setblock 392 239 358 minecraft:light_gray_wool
fill 392 239 359 394 239 359 minecraft:gray_wool
setblock 392 239 362 minecraft:light_gray_wool
fill 392 239 363 394 239 363 minecraft:gray_wool
setblock 393 239 325 minecraft:light_gray_wool
fill 393 239 326 395 239 326 minecraft:gray_wool
fill 393 239 333 393 239 334 minecraft:blackstone
setblock 393 239 335 minecraft:sea_lantern
fill 393 239 336 393 239 338 minecraft:pearlescent_froglight
setblock 393 239 339 minecraft:sea_lantern
fill 393 239 340 393 239 341 minecraft:blackstone
setblock 393 239 349 minecraft:light_gray_wool
fill 393 239 350 395 239 350 minecraft:gray_wool
setblock 393 239 353 minecraft:light_gray_wool
fill 393 239 354 395 239 354 minecraft:gray_wool
setblock 393 239 357 minecraft:light_gray_wool
fill 393 239 358 395 239 358 minecraft:gray_wool
setblock 393 239 361 minecraft:light_gray_wool
fill 393 239 362 395 239 362 minecraft:gray_wool
setblock 394 239 324 minecraft:light_gray_wool
fill 394 239 325 396 239 325 minecraft:gray_wool
fill 394 239 333 405 239 333 minecraft:blackstone
setblock 394 239 334 minecraft:sea_lantern
setblock 394 239 335 minecraft:pearlescent_froglight
setblock 394 239 339 minecraft:pearlescent_froglight
setblock 394 239 340 minecraft:sea_lantern
fill 394 239 341 405 239 341 minecraft:blackstone
setblock 394 239 348 minecraft:light_gray_wool
fill 394 239 349 396 239 349 minecraft:gray_wool
setblock 394 239 352 minecraft:light_gray_wool
fill 394 239 353 396 239 353 minecraft:gray_wool
setblock 394 239 356 minecraft:light_gray_wool
fill 394 239 357 396 239 357 minecraft:gray_wool
setblock 394 239 360 minecraft:light_gray_wool
fill 394 239 361 396 239 361 minecraft:gray_wool
setblock 395 239 323 minecraft:light_gray_wool
fill 395 239 324 397 239 324 minecraft:gray_wool
fill 395 239 334 397 239 334 minecraft:pearlescent_froglight
fill 395 239 340 397 239 340 minecraft:pearlescent_froglight
setblock 395 239 348 minecraft:gray_wool
setblock 395 239 351 minecraft:light_gray_wool
fill 395 239 352 397 239 352 minecraft:gray_wool
setblock 395 239 355 minecraft:light_gray_wool
fill 395 239 356 397 239 356 minecraft:gray_wool
setblock 395 239 359 minecraft:light_gray_wool
fill 395 239 360 397 239 360 minecraft:gray_wool
setblock 395 239 363 minecraft:light_gray_wool
fill 396 239 323 398 239 323 minecraft:gray_wool
setblock 396 239 327 minecraft:blackstone
setblock 396 239 347 minecraft:blackstone
setblock 396 239 350 minecraft:light_gray_wool
fill 396 239 351 398 239 351 minecraft:gray_wool
setblock 396 239 354 minecraft:light_gray_wool
fill 396 239 355 398 239 355 minecraft:gray_wool
setblock 396 239 358 minecraft:light_gray_wool
fill 396 239 359 398 239 359 minecraft:gray_wool
setblock 396 239 362 minecraft:light_gray_wool
fill 396 239 363 398 239 363 minecraft:gray_wool
setblock 397 239 325 minecraft:light_gray_wool
fill 397 239 326 399 239 326 minecraft:gray_wool
fill 397 239 327 400 239 327 minecraft:polished_blackstone
fill 397 239 347 400 239 347 minecraft:polished_blackstone
setblock 397 239 348 minecraft:gray_wool
setblock 397 239 349 minecraft:light_gray_wool
fill 397 239 350 399 239 350 minecraft:gray_wool
setblock 397 239 353 minecraft:light_gray_wool
fill 397 239 354 399 239 354 minecraft:gray_wool
setblock 397 239 357 minecraft:light_gray_wool
fill 397 239 358 399 239 358 minecraft:gray_wool
setblock 397 239 361 minecraft:light_gray_wool
fill 397 239 362 399 239 362 minecraft:gray_wool
setblock 398 239 324 minecraft:light_gray_wool
fill 398 239 325 400 239 325 minecraft:gray_wool
setblock 398 239 334 minecraft:sea_lantern
setblock 398 239 335 minecraft:pearlescent_froglight
setblock 398 239 339 minecraft:pearlescent_froglight
setblock 398 239 340 minecraft:sea_lantern
setblock 398 239 348 minecraft:light_gray_wool
fill 398 239 349 400 239 349 minecraft:gray_wool
setblock 398 239 352 minecraft:light_gray_wool
fill 398 239 353 400 239 353 minecraft:gray_wool
setblock 398 239 356 minecraft:light_gray_wool
fill 398 239 357 400 239 357 minecraft:gray_wool
setblock 398 239 360 minecraft:light_gray_wool
fill 398 239 361 400 239 361 minecraft:gray_wool
setblock 399 239 323 minecraft:light_gray_wool
fill 399 239 324 401 239 324 minecraft:gray_wool
fill 399 239 334 405 239 334 minecraft:blackstone
setblock 399 239 335 minecraft:sea_lantern
fill 399 239 336 399 239 338 minecraft:pearlescent_froglight
setblock 399 239 339 minecraft:sea_lantern
fill 399 239 340 405 239 340 minecraft:blackstone
fill 399 239 348 401 239 348 minecraft:gray_wool
setblock 399 239 351 minecraft:light_gray_wool
fill 399 239 352 401 239 352 minecraft:gray_wool
setblock 399 239 355 minecraft:light_gray_wool
fill 399 239 356 401 239 356 minecraft:gray_wool
setblock 399 239 359 minecraft:light_gray_wool
fill 399 239 360 401 239 360 minecraft:gray_wool
setblock 399 239 363 minecraft:light_gray_wool
fill 400 239 323 402 239 323 minecraft:gray_wool
setblock 400 239 326 minecraft:light_gray_wool
fill 400 239 335 405 239 339 minecraft:blackstone
setblock 400 239 350 minecraft:light_gray_wool
fill 400 239 351 402 239 351 minecraft:gray_wool
setblock 400 239 354 minecraft:light_gray_wool
fill 400 239 355 402 239 355 minecraft:gray_wool
setblock 400 239 358 minecraft:light_gray_wool
fill 400 239 359 402 239 359 minecraft:gray_wool
setblock 400 239 362 minecraft:light_gray_wool
fill 400 239 363 402 239 363 minecraft:gray_wool
setblock 401 239 325 minecraft:light_gray_wool
fill 401 239 326 402 239 327 minecraft:gray_wool
fill 401 239 328 402 239 328 minecraft:polished_blackstone
fill 401 239 346 402 239 346 minecraft:polished_blackstone
fill 401 239 347 402 239 347 minecraft:gray_wool
setblock 401 239 349 minecraft:light_gray_wool
fill 401 239 350 403 239 350 minecraft:gray_wool
setblock 401 239 353 minecraft:light_gray_wool
fill 401 239 354 403 239 354 minecraft:gray_wool
setblock 401 239 357 minecraft:light_gray_wool
fill 401 239 358 403 239 358 minecraft:gray_wool
setblock 401 239 361 minecraft:light_gray_wool
fill 401 239 362 403 239 362 minecraft:gray_wool
setblock 402 239 324 minecraft:light_gray_wool
fill 402 239 325 404 239 325 minecraft:gray_wool
setblock 402 239 348 minecraft:light_gray_wool
fill 402 239 349 404 239 349 minecraft:gray_wool
setblock 402 239 352 minecraft:light_gray_wool
fill 402 239 353 404 239 353 minecraft:gray_wool
setblock 402 239 356 minecraft:light_gray_wool
fill 402 239 357 404 239 357 minecraft:gray_wool
setblock 402 239 360 minecraft:light_gray_wool
fill 402 239 361 404 239 361 minecraft:gray_wool
setblock 403 239 323 minecraft:light_gray_wool
fill 403 239 324 405 239 324 minecraft:gray_wool
setblock 403 239 326 minecraft:gray_wool
setblock 403 239 327 minecraft:light_gray_wool
setblock 403 239 347 minecraft:light_gray_wool
fill 403 239 348 405 239 348 minecraft:gray_wool
setblock 403 239 351 minecraft:light_gray_wool
fill 403 239 352 405 239 352 minecraft:gray_wool
setblock 403 239 355 minecraft:light_gray_wool
fill 403 239 356 405 239 356 minecraft:gray_wool
setblock 403 239 359 minecraft:light_gray_wool
fill 403 239 360 405 239 360 minecraft:gray_wool
setblock 403 239 363 minecraft:light_gray_wool
fill 404 239 323 406 239 323 minecraft:gray_wool
setblock 404 239 326 minecraft:light_gray_wool
fill 404 239 327 406 239 327 minecraft:gray_wool
fill 404 239 347 406 239 347 minecraft:gray_wool
setblock 404 239 350 minecraft:light_gray_wool
fill 404 239 351 406 239 351 minecraft:gray_wool
setblock 404 239 354 minecraft:light_gray_wool
fill 404 239 355 406 239 355 minecraft:gray_wool
setblock 404 239 358 minecraft:light_gray_wool
fill 404 239 359 406 239 359 minecraft:gray_wool
setblock 404 239 362 minecraft:light_gray_wool
fill 404 239 363 406 239 363 minecraft:gray_wool
setblock 405 239 325 minecraft:light_gray_wool
fill 405 239 326 407 239 326 minecraft:gray_wool
fill 405 239 331 405 239 332 minecraft:polished_blackstone
fill 405 239 342 405 239 343 minecraft:polished_blackstone
setblock 405 239 349 minecraft:light_gray_wool
fill 405 239 350 407 239 350 minecraft:gray_wool
setblock 405 239 353 minecraft:light_gray_wool
fill 405 239 354 407 239 354 minecraft:gray_wool
setblock 405 239 357 minecraft:light_gray_wool
fill 405 239 358 407 239 358 minecraft:gray_wool
setblock 405 239 361 minecraft:light_gray_wool
fill 405 239 362 407 239 362 minecraft:gray_wool
setblock 406 239 324 minecraft:light_gray_wool
fill 406 239 325 408 239 325 minecraft:gray_wool
setblock 406 239 328 minecraft:light_gray_wool
fill 406 239 329 406 239 331 minecraft:gray_wool
setblock 406 239 332 minecraft:light_gray_wool
fill 406 239 333 406 239 336 minecraft:polished_blackstone
setblock 406 239 337 minecraft:blackstone
fill 406 239 338 406 239 341 minecraft:polished_blackstone
fill 406 239 342 406 239 343 minecraft:gray_wool
setblock 406 239 344 minecraft:light_gray_wool
fill 406 239 345 407 239 346 minecraft:gray_wool
setblock 406 239 348 minecraft:light_gray_wool
fill 406 239 349 408 239 349 minecraft:gray_wool
setblock 406 239 352 minecraft:light_gray_wool
fill 406 239 353 408 239 353 minecraft:gray_wool
setblock 406 239 356 minecraft:light_gray_wool
fill 406 239 357 408 239 357 minecraft:gray_wool
setblock 406 239 360 minecraft:light_gray_wool
fill 406 239 361 408 239 361 minecraft:gray_wool
setblock 407 239 323 minecraft:light_gray_wool
fill 407 239 324 409 239 324 minecraft:gray_wool
setblock 407 239 327 minecraft:light_gray_wool
fill 407 239 328 407 239 330 minecraft:gray_wool
setblock 407 239 331 minecraft:light_gray_wool
fill 407 239 332 407 239 334 minecraft:gray_wool
setblock 407 239 335 minecraft:light_gray_wool
fill 407 239 336 409 239 336 minecraft:gray_wool
setblock 407 239 338 minecraft:gray_wool
setblock 407 239 339 minecraft:light_gray_wool
fill 407 239 340 407 239 342 minecraft:gray_wool
setblock 407 239 343 minecraft:light_gray_wool
fill 407 239 344 409 239 344 minecraft:gray_wool
setblock 407 239 347 minecraft:light_gray_wool
fill 407 239 348 409 239 348 minecraft:gray_wool
setblock 407 239 351 minecraft:light_gray_wool
fill 407 239 352 409 239 352 minecraft:gray_wool
setblock 407 239 355 minecraft:light_gray_wool
fill 407 239 356 409 239 356 minecraft:gray_wool
setblock 407 239 359 minecraft:light_gray_wool
fill 407 239 360 409 239 360 minecraft:gray_wool
setblock 407 239 363 minecraft:light_gray_wool
setblock 407 239 364 minecraft:light_blue_stained_glass
fill 408 239 323 410 239 323 minecraft:gray_wool
setblock 408 239 326 minecraft:light_gray_wool
fill 408 239 327 408 239 329 minecraft:gray_wool
setblock 408 239 330 minecraft:light_gray_wool
fill 408 239 331 408 239 333 minecraft:gray_wool
setblock 408 239 334 minecraft:light_gray_wool
fill 408 239 335 410 239 335 minecraft:gray_wool
setblock 408 239 337 minecraft:gray_wool
setblock 408 239 338 minecraft:light_gray_wool
fill 408 239 339 408 239 341 minecraft:gray_wool
setblock 408 239 342 minecraft:light_gray_wool
fill 408 239 343 410 239 343 minecraft:gray_wool
setblock 408 239 345 minecraft:gray_wool
setblock 408 239 346 minecraft:light_gray_wool
fill 408 239 347 410 239 347 minecraft:gray_wool
setblock 408 239 350 minecraft:light_gray_wool
fill 408 239 351 410 239 351 minecraft:gray_wool
setblock 408 239 354 minecraft:light_gray_wool
fill 408 239 355 410 239 355 minecraft:gray_wool
setblock 408 239 358 minecraft:light_gray_wool
fill 408 239 359 410 239 359 minecraft:gray_wool
setblock 408 239 362 minecraft:light_gray_wool
fill 408 239 363 410 239 363 minecraft:gray_wool
setblock 409 239 325 minecraft:light_gray_wool
fill 409 239 326 409 239 328 minecraft:gray_wool
setblock 409 239 329 minecraft:light_gray_wool
fill 409 239 330 409 239 332 minecraft:gray_wool
setblock 409 239 333 minecraft:light_gray_wool
fill 409 239 334 411 239 334 minecraft:gray_wool
setblock 409 239 337 minecraft:light_gray_wool
fill 409 239 338 409 239 340 minecraft:gray_wool
setblock 409 239 341 minecraft:light_gray_wool
fill 409 239 342 411 239 342 minecraft:gray_wool
setblock 409 239 345 minecraft:light_gray_wool
fill 409 239 346 411 239 346 minecraft:gray_wool
setblock 409 239 349 minecraft:light_gray_wool
fill 409 239 350 411 239 350 minecraft:gray_wool
setblock 409 239 353 minecraft:light_gray_wool
fill 409 239 354 411 239 354 minecraft:gray_wool
setblock 409 239 357 minecraft:light_gray_wool
fill 409 239 358 411 239 358 minecraft:gray_wool
setblock 409 239 361 minecraft:light_gray_wool
fill 409 239 362 411 239 362 minecraft:gray_wool
setblock 410 239 324 minecraft:light_gray_wool
fill 410 239 325 410 239 327 minecraft:gray_wool
setblock 410 239 328 minecraft:light_gray_wool
fill 410 239 329 410 239 331 minecraft:gray_wool
setblock 410 239 332 minecraft:light_gray_wool
fill 410 239 333 412 239 333 minecraft:gray_wool
setblock 410 239 336 minecraft:light_gray_wool
fill 410 239 337 410 239 339 minecraft:gray_wool
setblock 410 239 340 minecraft:light_gray_wool
fill 410 239 341 412 239 341 minecraft:gray_wool
setblock 410 239 344 minecraft:light_gray_wool
fill 410 239 345 412 239 345 minecraft:gray_wool
setblock 410 239 348 minecraft:light_gray_wool
fill 410 239 349 412 239 349 minecraft:gray_wool
setblock 410 239 352 minecraft:light_gray_wool
fill 410 239 353 412 239 353 minecraft:gray_wool
setblock 410 239 356 minecraft:light_gray_wool
fill 410 239 357 412 239 357 minecraft:gray_wool
setblock 410 239 360 minecraft:light_gray_wool
fill 410 239 361 412 239 361 minecraft:gray_wool
setblock 411 239 323 minecraft:light_gray_wool
fill 411 239 324 411 239 326 minecraft:gray_wool
setblock 411 239 327 minecraft:light_gray_wool
fill 411 239 328 411 239 330 minecraft:gray_wool
setblock 411 239 331 minecraft:light_gray_wool
fill 411 239 332 413 239 332 minecraft:gray_wool
setblock 411 239 335 minecraft:light_gray_wool
fill 411 239 336 411 239 338 minecraft:gray_wool
setblock 411 239 339 minecraft:light_gray_wool
fill 411 239 340 413 239 340 minecraft:gray_wool
setblock 411 239 343 minecraft:light_gray_wool
fill 411 239 344 413 239 344 minecraft:gray_wool
setblock 411 239 347 minecraft:light_gray_wool
fill 411 239 348 413 239 348 minecraft:gray_wool
setblock 411 239 351 minecraft:light_gray_wool
fill 411 239 352 413 239 352 minecraft:gray_wool
setblock 411 239 355 minecraft:light_gray_wool
fill 411 239 356 413 239 356 minecraft:gray_wool
setblock 411 239 359 minecraft:light_gray_wool
fill 411 239 360 413 239 360 minecraft:gray_wool
setblock 411 239 363 minecraft:light_gray_wool
fill 412 239 323 412 239 325 minecraft:gray_wool
setblock 412 239 326 minecraft:light_gray_wool
fill 412 239 327 412 239 329 minecraft:gray_wool
setblock 412 239 330 minecraft:light_gray_wool
fill 412 239 331 414 239 331 minecraft:gray_wool
setblock 412 239 334 minecraft:light_gray_wool
fill 412 239 335 412 239 337 minecraft:gray_wool
setblock 412 239 338 minecraft:light_gray_wool
fill 412 239 339 414 239 339 minecraft:gray_wool
setblock 412 239 342 minecraft:light_gray_wool
fill 412 239 343 414 239 343 minecraft:gray_wool
setblock 412 239 346 minecraft:light_gray_wool
fill 412 239 347 414 239 347 minecraft:gray_wool
setblock 412 239 350 minecraft:light_gray_wool
fill 412 239 351 414 239 351 minecraft:gray_wool
setblock 412 239 354 minecraft:light_gray_wool
fill 412 239 355 414 239 355 minecraft:gray_wool
setblock 412 239 358 minecraft:light_gray_wool
fill 412 239 359 414 239 359 minecraft:gray_wool
setblock 412 239 362 minecraft:light_gray_wool
fill 412 239 363 414 239 363 minecraft:gray_wool
fill 413 239 323 413 239 324 minecraft:gray_wool
setblock 413 239 325 minecraft:light_gray_wool
fill 413 239 326 413 239 328 minecraft:gray_wool
setblock 413 239 329 minecraft:light_gray_wool
fill 413 239 330 415 239 330 minecraft:gray_wool
setblock 413 239 333 minecraft:light_gray_wool
fill 413 239 334 413 239 336 minecraft:gray_wool
setblock 413 239 337 minecraft:light_gray_wool
fill 413 239 338 415 239 338 minecraft:gray_wool
setblock 413 239 341 minecraft:light_gray_wool
fill 413 239 342 415 239 342 minecraft:gray_wool
setblock 413 239 345 minecraft:light_gray_wool
fill 413 239 346 415 239 346 minecraft:gray_wool
setblock 413 239 349 minecraft:light_gray_wool
fill 413 239 350 415 239 350 minecraft:gray_wool
setblock 413 239 353 minecraft:light_gray_wool
fill 413 239 354 415 239 354 minecraft:gray_wool
setblock 413 239 357 minecraft:light_gray_wool
fill 413 239 358 415 239 358 minecraft:gray_wool
setblock 413 239 361 minecraft:light_gray_wool
fill 413 239 362 415 239 362 minecraft:gray_wool
setblock 414 239 323 minecraft:gray_wool
setblock 414 239 324 minecraft:light_gray_wool
fill 414 239 325 414 239 327 minecraft:gray_wool
setblock 414 239 328 minecraft:light_gray_wool
fill 414 239 329 416 239 329 minecraft:gray_wool
setblock 414 239 332 minecraft:light_gray_wool
fill 414 239 333 414 239 335 minecraft:gray_wool
setblock 414 239 336 minecraft:light_gray_wool
fill 414 239 337 416 239 337 minecraft:gray_wool
setblock 414 239 340 minecraft:light_gray_wool
fill 414 239 341 416 239 341 minecraft:gray_wool
setblock 414 239 344 minecraft:light_gray_wool
fill 414 239 345 416 239 345 minecraft:gray_wool
setblock 414 239 348 minecraft:light_gray_wool
fill 414 239 349 416 239 349 minecraft:gray_wool
setblock 414 239 352 minecraft:light_gray_wool
fill 414 239 353 416 239 353 minecraft:gray_wool
setblock 414 239 356 minecraft:light_gray_wool
fill 414 239 357 416 239 357 minecraft:gray_wool
setblock 414 239 360 minecraft:light_gray_wool
fill 414 239 361 416 239 361 minecraft:gray_wool
setblock 415 239 323 minecraft:light_gray_wool
fill 415 239 324 415 239 326 minecraft:gray_wool
setblock 415 239 327 minecraft:light_gray_wool
fill 415 239 328 417 239 328 minecraft:gray_wool
setblock 415 239 331 minecraft:light_gray_wool
fill 415 239 332 415 239 334 minecraft:gray_wool
setblock 415 239 335 minecraft:light_gray_wool
fill 415 239 336 417 239 336 minecraft:gray_wool
setblock 415 239 339 minecraft:light_gray_wool
fill 415 239 340 417 239 340 minecraft:gray_wool
setblock 415 239 343 minecraft:light_gray_wool
fill 415 239 344 417 239 344 minecraft:gray_wool
setblock 415 239 347 minecraft:light_gray_wool
fill 415 239 348 417 239 348 minecraft:gray_wool
setblock 415 239 351 minecraft:light_gray_wool
fill 415 239 352 417 239 352 minecraft:gray_wool
setblock 415 239 355 minecraft:light_gray_wool
fill 415 239 356 417 239 356 minecraft:gray_wool
setblock 415 239 359 minecraft:light_gray_wool
fill 415 239 360 417 239 360 minecraft:gray_wool
setblock 415 239 363 minecraft:light_gray_wool
fill 416 239 323 416 239 325 minecraft:gray_wool
setblock 416 239 326 minecraft:light_gray_wool
fill 416 239 327 417 239 327 minecraft:gray_wool
setblock 416 239 330 minecraft:light_gray_wool
fill 416 239 331 416 239 333 minecraft:gray_wool
setblock 416 239 334 minecraft:light_gray_wool
fill 416 239 335 417 239 335 minecraft:gray_wool
setblock 416 239 338 minecraft:light_gray_wool
fill 416 239 339 417 239 339 minecraft:gray_wool
setblock 416 239 342 minecraft:light_gray_wool
fill 416 239 343 417 239 343 minecraft:gray_wool
setblock 416 239 346 minecraft:light_gray_wool
fill 416 239 347 417 239 347 minecraft:gray_wool
setblock 416 239 350 minecraft:light_gray_wool
fill 416 239 351 417 239 351 minecraft:gray_wool
setblock 416 239 354 minecraft:light_gray_wool
fill 416 239 355 417 239 355 minecraft:gray_wool
setblock 416 239 358 minecraft:light_gray_wool
fill 416 239 359 417 239 359 minecraft:gray_wool
setblock 416 239 362 minecraft:light_gray_wool
fill 416 239 363 417 239 363 minecraft:gray_wool
fill 417 239 323 417 239 324 minecraft:gray_wool
setblock 417 239 325 minecraft:light_gray_wool
setblock 417 239 326 minecraft:gray_wool
setblock 417 239 329 minecraft:light_gray_wool
fill 417 239 330 417 239 332 minecraft:gray_wool
setblock 417 239 333 minecraft:light_gray_wool
setblock 417 239 334 minecraft:gray_wool
setblock 417 239 337 minecraft:light_gray_wool
setblock 417 239 338 minecraft:gray_wool
setblock 417 239 341 minecraft:light_gray_wool
setblock 417 239 342 minecraft:gray_wool
setblock 417 239 345 minecraft:light_gray_wool
setblock 417 239 346 minecraft:gray_wool
setblock 417 239 349 minecraft:light_gray_wool
setblock 417 239 350 minecraft:gray_wool
setblock 417 239 353 minecraft:light_gray_wool
setblock 417 239 354 minecraft:gray_wool
setblock 417 239 357 minecraft:light_gray_wool
setblock 417 239 358 minecraft:gray_wool
setblock 417 239 361 minecraft:light_gray_wool
setblock 417 239 362 minecraft:gray_wool
fill 384 240 338 384 241 338 minecraft:cobblestone
fill 385 240 337 385 241 337 minecraft:blackstone
fill 386 240 330 386 241 331 minecraft:cobblestone
fill 386 240 335 386 241 336 minecraft:blackstone
fill 386 240 340 386 241 341 minecraft:blackstone
fill 386 240 345 386 241 346 minecraft:cobblestone
fill 387 240 328 389 245 329 minecraft:polished_blackstone
fill 387 240 330 391 240 344 minecraft:dark_oak_planks
fill 387 240 345 389 245 346 minecraft:polished_blackstone
fill 390 240 329 390 245 329 minecraft:polished_blackstone
fill 390 240 345 390 245 345 minecraft:polished_blackstone
fill 390 240 346 390 241 346 minecraft:blackstone
fill 391 240 328 391 241 328 minecraft:blackstone
fill 392 240 327 392 241 327 minecraft:blackstone
fill 392 240 330 405 240 332 minecraft:dark_oak_planks
fill 392 240 343 405 240 344 minecraft:dark_oak_planks
setblock 393 240 322 minecraft:light_blue_stained_glass
fill 393 240 326 393 241 327 minecraft:cobblestone
fill 393 240 349 393 241 350 minecraft:cobblestone
fill 394 240 322 394 243 322 minecraft:black_concrete
fill 394 240 347 395 241 347 minecraft:blackstone
fill 397 240 327 398 241 327 minecraft:blackstone
setblock 397 240 364 minecraft:light_blue_stained_glass
fill 399 240 347 400 241 347 minecraft:blackstone
fill 400 240 326 400 241 327 minecraft:cobblestone
fill 400 240 349 400 241 350 minecraft:cobblestone
fill 401 240 346 401 241 346 minecraft:blackstone
fill 402 240 328 402 241 328 minecraft:blackstone
fill 402 240 329 405 245 329 minecraft:polished_blackstone
fill 402 240 333 405 240 342 minecraft:dark_oak_planks
fill 402 240 345 405 245 345 minecraft:polished_blackstone
fill 406 240 333 406 241 334 minecraft:blackstone
fill 406 240 338 406 241 339 minecraft:blackstone
fill 407 240 330 407 241 331 minecraft:cobblestone
fill 407 240 345 407 241 346 minecraft:cobblestone
fill 407 240 364 407 247 364 minecraft:black_concrete
fill 409 240 337 409 241 338 minecraft:cobblestone
fill 387 241 330 387 241 344 minecraft:dark_oak_planks
fill 388 241 330 405 241 330 minecraft:dark_oak_planks
fill 388 241 331 389 245 331 minecraft:polished_blackstone
fill 388 241 343 389 245 343 minecraft:polished_blackstone
fill 388 241 344 405 241 344 minecraft:dark_oak_planks
fill 393 241 322 393 246 322 minecraft:black_concrete
setblock 397 241 322 minecraft:light_blue_stained_glass
fill 397 241 364 397 247 364 minecraft:black_concrete
fill 403 241 331 404 245 331 minecraft:polished_blackstone
fill 403 241 343 404 245 343 minecraft:polished_blackstone
fill 405 241 331 405 241 343 minecraft:dark_oak_planks
fill 410 241 364 411 244 364 minecraft:black_concrete
setblock 412 241 364 minecraft:light_blue_stained_glass
fill 413 241 364 414 243 364 minecraft:black_concrete
setblock 376 242 326 minecraft:light_blue_stained_glass
fill 376 242 327 376 246 327 minecraft:black_concrete
setblock 379 242 325 minecraft:light[level=12]
setblock 379 242 332 minecraft:light[level=12]
setblock 379 242 339 minecraft:light[level=12]
setblock 379 242 346 minecraft:light[level=12]
setblock 379 242 353 minecraft:light[level=12]
setblock 379 242 360 minecraft:light[level=12]
setblock 386 242 325 minecraft:light[level=12]
setblock 386 242 332 minecraft:light[level=12]
setblock 386 242 339 minecraft:light[level=12]
setblock 386 242 346 minecraft:light[level=12]
setblock 386 242 353 minecraft:light[level=12]
setblock 386 242 360 minecraft:light[level=12]
fill 387 242 330 387 247 330 minecraft:dark_oak_planks
setblock 387 242 331 minecraft:ochre_froglight
fill 387 242 332 387 247 333 minecraft:dark_oak_planks
setblock 387 242 334 minecraft:ochre_froglight
fill 387 242 335 387 247 336 minecraft:dark_oak_planks
setblock 387 242 337 minecraft:ochre_froglight
fill 387 242 338 387 247 339 minecraft:dark_oak_planks
setblock 387 242 340 minecraft:ochre_froglight
fill 387 242 341 387 247 342 minecraft:dark_oak_planks
setblock 387 242 343 minecraft:ochre_froglight
fill 387 242 344 388 247 344 minecraft:dark_oak_planks
setblock 388 242 330 minecraft:ochre_froglight
fill 389 242 330 390 247 330 minecraft:dark_oak_planks
setblock 389 242 344 minecraft:ochre_froglight
fill 390 242 344 391 247 344 minecraft:dark_oak_planks
setblock 391 242 330 minecraft:ochre_froglight
fill 392 242 330 393 247 330 minecraft:dark_oak_planks
setblock 392 242 344 minecraft:ochre_froglight
setblock 393 242 325 minecraft:light[level=12]
setblock 393 242 332 minecraft:light[level=12]
fill 393 242 344 394 247 344 minecraft:dark_oak_planks
setblock 393 242 346 minecraft:light[level=12]
setblock 393 242 353 minecraft:light[level=12]
setblock 393 242 360 minecraft:light[level=12]
setblock 394 242 330 minecraft:ochre_froglight
fill 395 242 330 396 247 330 minecraft:dark_oak_planks
setblock 395 242 344 minecraft:ochre_froglight
fill 396 242 344 397 247 344 minecraft:dark_oak_planks
setblock 397 242 322 minecraft:black_concrete
setblock 397 242 330 minecraft:ochre_froglight
fill 398 242 330 399 247 330 minecraft:dark_oak_planks
setblock 398 242 344 minecraft:ochre_froglight
fill 399 242 344 400 247 344 minecraft:dark_oak_planks
setblock 400 242 325 minecraft:light[level=12]
setblock 400 242 330 minecraft:ochre_froglight
setblock 400 242 332 minecraft:light[level=12]
setblock 400 242 346 minecraft:light[level=12]
setblock 400 242 353 minecraft:light[level=12]
setblock 400 242 360 minecraft:light[level=12]
fill 401 242 330 402 247 330 minecraft:dark_oak_planks
setblock 401 242 344 minecraft:ochre_froglight
fill 402 242 344 403 247 344 minecraft:dark_oak_planks
setblock 403 242 330 minecraft:ochre_froglight
fill 404 242 330 405 247 330 minecraft:dark_oak_planks
setblock 404 242 344 minecraft:ochre_froglight
setblock 405 242 331 minecraft:ochre_froglight
fill 405 242 332 405 247 333 minecraft:dark_oak_planks
setblock 405 242 334 minecraft:ochre_froglight
fill 405 242 335 405 247 336 minecraft:dark_oak_planks
setblock 405 242 337 minecraft:ochre_froglight
fill 405 242 338 405 247 339 minecraft:dark_oak_planks
setblock 405 242 340 minecraft:ochre_froglight
fill 405 242 341 405 247 342 minecraft:dark_oak_planks
setblock 405 242 343 minecraft:ochre_froglight
fill 405 242 344 405 247 344 minecraft:dark_oak_planks
setblock 407 242 325 minecraft:light[level=12]
setblock 407 242 332 minecraft:light[level=12]
setblock 407 242 339 minecraft:light[level=12]
setblock 407 242 346 minecraft:light[level=12]
setblock 407 242 353 minecraft:light[level=12]
setblock 407 242 360 minecraft:light[level=12]
fill 412 242 364 412 246 364 minecraft:black_concrete
setblock 414 242 325 minecraft:light[level=12]
setblock 414 242 332 minecraft:light[level=12]
setblock 414 242 339 minecraft:light[level=12]
setblock 414 242 346 minecraft:light[level=12]
setblock 414 242 353 minecraft:light[level=12]
setblock 414 242 360 minecraft:light[level=12]
fill 376 243 326 376 246 326 minecraft:black_concrete
fill 376 243 334 378 243 334 minecraft:gray_concrete
fill 376 243 340 378 243 340 minecraft:gray_concrete
fill 376 243 342 376 244 345 minecraft:black_concrete
fill 376 243 346 377 243 346 minecraft:gray_concrete
fill 376 243 347 376 246 347 minecraft:black_concrete
fill 376 243 353 378 243 353 minecraft:gray_concrete
setblock 376 243 362 minecraft:gray_concrete
fill 377 243 323 377 243 326 minecraft:gray_concrete
setblock 377 243 327 minecraft:polished_deepslate
fill 377 243 328 377 243 331 minecraft:gray_concrete
setblock 377 243 332 minecraft:polished_deepslate
fill 377 243 333 379 243 333 minecraft:gray_concrete
fill 377 243 335 377 243 336 minecraft:gray_concrete
setblock 377 243 337 minecraft:polished_deepslate
fill 377 243 338 378 244 339 minecraft:gray_concrete
setblock 377 243 341 minecraft:gray_concrete
setblock 377 243 342 minecraft:polished_deepslate
fill 377 243 343 378 243 345 minecraft:gray_concrete
setblock 377 243 347 minecraft:polished_deepslate
fill 377 243 348 377 243 351 minecraft:gray_concrete
setblock 377 243 352 minecraft:polished_deepslate
fill 377 243 354 377 243 356 minecraft:gray_concrete
setblock 377 243 357 minecraft:polished_deepslate
setblock 377 243 363 minecraft:gray_concrete
fill 378 243 323 378 243 325 minecraft:gray_concrete
setblock 378 243 326 minecraft:polished_deepslate
fill 378 243 327 378 243 330 minecraft:gray_concrete
setblock 378 243 331 minecraft:polished_deepslate
fill 378 243 332 379 245 332 minecraft:gray_concrete
setblock 378 243 335 minecraft:gray_concrete
setblock 378 243 336 minecraft:polished_deepslate
fill 378 243 337 378 245 337 minecraft:gray_concrete
setblock 378 243 341 minecraft:polished_deepslate
fill 378 243 342 378 244 342 minecraft:gray_concrete
setblock 378 243 346 minecraft:polished_deepslate
fill 378 243 347 378 243 350 minecraft:gray_concrete
setblock 378 243 351 minecraft:polished_deepslate
fill 378 243 352 378 246 352 minecraft:gray_concrete
fill 378 243 354 378 244 354 minecraft:gray_concrete
fill 378 243 364 379 243 364 minecraft:gray_concrete
fill 379 243 323 379 243 324 minecraft:gray_concrete
setblock 379 243 325 minecraft:polished_deepslate
fill 379 243 326 379 243 329 minecraft:gray_concrete
setblock 379 243 330 minecraft:polished_deepslate
fill 379 243 331 379 246 331 minecraft:gray_concrete
fill 379 243 343 379 243 344 minecraft:gray_concrete
setblock 379 243 345 minecraft:polished_deepslate
fill 379 243 346 379 243 349 minecraft:gray_concrete
setblock 379 243 350 minecraft:polished_deepslate
setblock 379 243 351 minecraft:gray_concrete
setblock 380 243 323 minecraft:gray_concrete
setblock 380 243 324 minecraft:polished_deepslate
setblock 381 243 323 minecraft:polished_deepslate
fill 381 243 324 383 243 324 minecraft:gray_concrete
fill 381 243 364 383 243 364 minecraft:black_concrete
fill 382 243 323 385 243 323 minecraft:gray_concrete
setblock 383 243 322 minecraft:light_blue_stained_glass
setblock 384 243 364 minecraft:gray_concrete
fill 385 243 324 386 244 325 minecraft:polished_deepslate
fill 385 243 364 385 246 364 minecraft:black_concrete
setblock 386 243 323 minecraft:polished_deepslate
fill 387 243 323 389 243 324 minecraft:gray_concrete
fill 387 243 325 387 244 325 minecraft:polished_deepslate
fill 387 243 331 387 245 331 minecraft:dark_oak_planks
fill 387 243 334 387 245 334 minecraft:dark_oak_planks
fill 387 243 337 387 245 337 minecraft:dark_oak_planks
fill 387 243 340 387 245 340 minecraft:dark_oak_planks
fill 387 243 343 387 245 343 minecraft:dark_oak_planks
fill 388 243 330 388 245 330 minecraft:dark_oak_planks
setblock 388 243 364 minecraft:gray_concrete
fill 389 243 344 389 245 344 minecraft:dark_oak_planks
fill 390 243 322 390 243 323 minecraft:gray_concrete
setblock 390 243 324 minecraft:polished_deepslate
fill 390 243 325 393 243 325 minecraft:gray_concrete
setblock 391 243 323 minecraft:polished_deepslate
fill 391 243 324 394 243 324 minecraft:gray_concrete
fill 391 243 330 391 245 330 minecraft:dark_oak_planks
setblock 391 243 363 minecraft:polished_deepslate
fill 392 243 323 395 243 323 minecraft:gray_concrete
setblock 392 243 326 minecraft:gray_concrete
fill 392 243 344 392 245 344 minecraft:dark_oak_planks
fill 392 243 363 395 243 363 minecraft:gray_concrete
setblock 393 243 326 minecraft:polished_deepslate
setblock 394 243 325 minecraft:polished_deepslate
fill 394 243 326 397 243 326 minecraft:gray_concrete
fill 394 243 330 394 245 330 minecraft:dark_oak_planks
fill 394 243 362 396 243 362 minecraft:gray_concrete
setblock 395 243 324 minecraft:polished_deepslate
fill 395 243 325 398 243 325 minecraft:gray_concrete
fill 395 243 344 395 245 344 minecraft:dark_oak_planks
setblock 396 243 323 minecraft:polished_deepslate
fill 396 243 324 399 243 324 minecraft:gray_concrete
setblock 396 243 363 minecraft:polished_deepslate
fill 397 243 322 397 243 323 minecraft:gray_concrete
fill 397 243 330 397 245 330 minecraft:dark_oak_planks
setblock 397 243 362 minecraft:polished_deepslate
fill 397 243 363 400 243 363 minecraft:gray_concrete
fill 398 243 323 400 243 323 minecraft:gray_concrete
setblock 398 243 326 minecraft:polished_deepslate
fill 398 243 344 398 245 344 minecraft:dark_oak_planks
fill 398 243 362 400 243 362 minecraft:gray_concrete
setblock 399 243 325 minecraft:polished_deepslate
setblock 399 243 326 minecraft:gray_concrete
setblock 400 243 324 minecraft:polished_deepslate
fill 400 243 325 401 243 325 minecraft:gray_concrete
fill 400 243 330 400 245 330 minecraft:dark_oak_planks
setblock 401 243 323 minecraft:polished_deepslate
fill 401 243 324 403 243 324 minecraft:gray_concrete
fill 401 243 344 401 245 344 minecraft:dark_oak_planks
setblock 401 243 363 minecraft:polished_deepslate
fill 402 243 323 405 243 323 minecraft:gray_concrete
fill 402 243 363 405 243 363 minecraft:gray_concrete
fill 403 243 330 403 245 330 minecraft:dark_oak_planks
fill 404 243 344 404 245 344 minecraft:dark_oak_planks
fill 405 243 331 405 245 331 minecraft:dark_oak_planks
fill 405 243 334 405 245 334 minecraft:dark_oak_planks
fill 405 243 337 405 245 337 minecraft:dark_oak_planks
fill 405 243 340 405 245 340 minecraft:dark_oak_planks
fill 405 243 343 405 245 343 minecraft:dark_oak_planks
setblock 406 243 323 minecraft:polished_deepslate
fill 409 243 363 410 243 363 minecraft:gray_concrete
setblock 410 243 323 minecraft:gray_concrete
setblock 411 243 323 minecraft:polished_deepslate
setblock 411 243 363 minecraft:polished_deepslate
fill 412 243 323 415 243 323 minecraft:gray_concrete
fill 412 243 363 415 243 363 minecraft:gray_concrete
setblock 413 243 336 minecraft:gray_wool
setblock 414 243 324 minecraft:gray_concrete
fill 414 243 346 414 243 349 minecraft:gray_concrete
setblock 414 243 350 minecraft:polished_deepslate
fill 414 243 351 416 243 352 minecraft:gray_concrete
setblock 415 243 324 minecraft:polished_deepslate
setblock 415 243 343 minecraft:gray_concrete
setblock 415 243 344 minecraft:polished_deepslate
fill 415 243 345 415 243 348 minecraft:gray_concrete
setblock 415 243 349 minecraft:polished_deepslate
fill 415 243 350 417 244 350 minecraft:gray_concrete
setblock 415 243 353 minecraft:gray_concrete
setblock 415 243 354 minecraft:polished_deepslate
fill 415 243 355 417 244 355 minecraft:gray_concrete
setblock 416 243 323 minecraft:polished_deepslate
fill 416 243 324 416 243 327 minecraft:gray_concrete
setblock 416 243 328 minecraft:polished_deepslate
fill 416 243 329 416 243 332 minecraft:gray_concrete
setblock 416 243 333 minecraft:polished_deepslate
fill 416 243 340 416 243 342 minecraft:gray_concrete
setblock 416 243 343 minecraft:polished_deepslate
fill 416 243 344 416 243 347 minecraft:gray_concrete
setblock 416 243 348 minecraft:polished_deepslate
fill 416 243 349 417 245 349 minecraft:gray_concrete
setblock 416 243 353 minecraft:polished_deepslate
fill 416 243 354 417 245 354 minecraft:gray_concrete
fill 416 243 356 416 243 357 minecraft:gray_concrete
setblock 416 243 358 minecraft:polished_deepslate
fill 416 243 359 417 243 359 minecraft:gray_concrete
setblock 416 243 363 minecraft:polished_deepslate
fill 417 243 323 417 243 326 minecraft:gray_concrete
setblock 417 243 327 minecraft:polished_deepslate
fill 417 243 328 417 243 331 minecraft:gray_concrete
setblock 417 243 332 minecraft:polished_deepslate
fill 417 243 333 417 243 336 minecraft:gray_concrete
setblock 417 243 337 minecraft:polished_deepslate
fill 417 243 338 417 243 341 minecraft:gray_concrete
setblock 417 243 342 minecraft:polished_deepslate
fill 417 243 343 417 243 346 minecraft:gray_concrete
setblock 417 243 347 minecraft:polished_deepslate
fill 417 243 348 417 246 348 minecraft:gray_concrete
fill 417 243 351 418 243 351 minecraft:gray_concrete
setblock 417 243 352 minecraft:polished_deepslate
fill 417 243 353 417 246 353 minecraft:gray_concrete
setblock 417 243 356 minecraft:gray_concrete
setblock 417 243 357 minecraft:polished_deepslate
fill 417 243 358 417 246 358 minecraft:gray_concrete
fill 417 243 360 417 243 361 minecraft:gray_concrete
setblock 417 243 362 minecraft:polished_deepslate
fill 417 243 363 417 244 363 minecraft:gray_concrete
setblock 418 243 337 minecraft:gray_concrete
fill 418 243 338 418 246 340 minecraft:black_concrete
setblock 418 243 341 minecraft:gray_concrete
setblock 418 243 347 minecraft:gray_concrete
fill 418 243 348 418 246 349 minecraft:black_concrete
fill 376 244 333 378 244 333 minecraft:gray_concrete
fill 376 244 334 376 245 334 minecraft:black_concrete
setblock 376 244 336 minecraft:light_blue_stained_glass
fill 376 244 337 376 246 337 minecraft:black_concrete
setblock 376 244 338 minecraft:gray_concrete
fill 376 244 340 376 247 340 minecraft:black_concrete
setblock 376 244 346 minecraft:gray_concrete
fill 376 244 349 378 244 349 minecraft:gray_concrete
fill 376 244 353 376 246 353 minecraft:black_concrete
fill 376 244 356 376 246 356 minecraft:black_concrete
setblock 376 244 357 minecraft:light_blue_stained_glass
fill 376 244 362 376 246 362 minecraft:black_concrete
fill 377 244 323 377 244 325 minecraft:gray_concrete
setblock 377 244 326 minecraft:polished_deepslate
fill 377 244 327 377 244 330 minecraft:gray_concrete
setblock 377 244 331 minecraft:polished_deepslate
fill 377 244 332 377 247 332 minecraft:gray_concrete
fill 377 244 334 377 244 335 minecraft:gray_concrete
setblock 377 244 336 minecraft:polished_deepslate
fill 377 244 337 377 247 337 minecraft:gray_concrete
setblock 377 244 340 minecraft:gray_concrete
setblock 377 244 341 minecraft:polished_deepslate
fill 377 244 342 377 244 345 minecraft:gray_concrete
setblock 377 244 346 minecraft:polished_deepslate
fill 377 244 347 379 244 348 minecraft:gray_concrete
setblock 377 244 350 minecraft:gray_concrete
setblock 377 244 351 minecraft:polished_deepslate
fill 377 244 352 377 244 355 minecraft:gray_concrete
setblock 377 244 356 minecraft:polished_deepslate
setblock 377 244 357 minecraft:gray_concrete
fill 378 244 323 378 244 324 minecraft:gray_concrete
setblock 378 244 325 minecraft:polished_deepslate
fill 378 244 326 378 244 329 minecraft:gray_concrete
setblock 378 244 330 minecraft:polished_deepslate
fill 378 244 331 378 247 331 minecraft:gray_concrete
setblock 378 244 334 minecraft:gray_concrete
setblock 378 244 335 minecraft:polished_deepslate
fill 378 244 336 378 247 336 minecraft:gray_concrete
setblock 378 244 340 minecraft:polished_deepslate
setblock 378 244 341 minecraft:gray_concrete
fill 378 244 343 378 244 344 minecraft:gray_concrete
setblock 378 244 345 minecraft:polished_deepslate
fill 378 244 346 378 246 346 minecraft:gray_concrete
setblock 378 244 350 minecraft:polished_deepslate
fill 378 244 351 378 247 351 minecraft:gray_concrete
fill 378 244 353 378 245 353 minecraft:gray_concrete
fill 378 244 364 379 244 364 minecraft:black_concrete
setblock 379 244 323 minecraft:gray_concrete
setblock 379 244 324 minecraft:polished_deepslate
fill 379 244 327 379 244 328 minecraft:gray_concrete
setblock 379 244 329 minecraft:polished_deepslate
fill 379 244 330 379 246 330 minecraft:gray_concrete
setblock 379 244 349 minecraft:polished_deepslate
setblock 380 244 323 minecraft:polished_deepslate
setblock 380 244 324 minecraft:gray_concrete
setblock 380 244 364 minecraft:gray_concrete
fill 381 244 323 384 244 323 minecraft:gray_concrete
fill 381 244 364 382 246 364 minecraft:black_concrete
fill 383 244 322 383 246 322 minecraft:black_concrete
setblock 383 244 364 minecraft:gray_concrete
setblock 384 244 322 minecraft:gray_concrete
fill 384 244 353 386 245 354 minecraft:light_gray_wool
fill 384 244 364 384 246 364 minecraft:black_concrete
fill 385 244 322 385 246 322 minecraft:black_concrete
setblock 385 244 323 minecraft:polished_deepslate
fill 386 244 322 386 244 323 minecraft:gray_concrete
fill 387 244 322 387 247 322 minecraft:black_concrete
fill 387 244 323 389 244 323 minecraft:gray_concrete
setblock 387 244 324 minecraft:polished_deepslate
fill 388 244 322 389 244 322 minecraft:gray_concrete
setblock 388 244 324 minecraft:gray_concrete
fill 388 244 364 388 246 364 minecraft:black_concrete
setblock 389 244 324 minecraft:polished_deepslate
fill 389 244 333 389 245 333 minecraft:white_wool
fill 390 244 322 390 246 322 minecraft:black_concrete
setblock 390 244 323 minecraft:polished_deepslate
fill 390 244 324 392 244 325 minecraft:gray_concrete
fill 391 244 323 394 244 323 minecraft:gray_concrete
fill 392 244 363 394 244 363 minecraft:gray_concrete
setblock 393 244 324 minecraft:gray_concrete
setblock 393 244 325 minecraft:polished_deepslate
fill 393 244 326 396 244 326 minecraft:gray_concrete
setblock 394 244 322 minecraft:gray_concrete
setblock 394 244 324 minecraft:polished_deepslate
fill 394 244 325 397 244 325 minecraft:gray_concrete
setblock 395 244 323 minecraft:polished_deepslate
fill 395 244 324 398 244 324 minecraft:gray_concrete
setblock 395 244 362 minecraft:gray_concrete
setblock 395 244 363 minecraft:polished_deepslate
fill 396 244 323 399 244 323 minecraft:gray_concrete
setblock 396 244 362 minecraft:polished_deepslate
fill 396 244 363 399 244 363 minecraft:gray_concrete
fill 397 244 322 397 247 322 minecraft:black_concrete
setblock 397 244 326 minecraft:polished_deepslate
fill 397 244 362 399 244 362 minecraft:gray_concrete
setblock 398 244 325 minecraft:polished_deepslate
setblock 399 244 324 minecraft:polished_deepslate
setblock 399 244 325 minecraft:gray_concrete
setblock 400 244 323 minecraft:polished_deepslate
fill 400 244 324 401 244 324 minecraft:gray_concrete
setblock 400 244 363 minecraft:polished_deepslate
fill 401 244 323 403 244 323 minecraft:gray_concrete
fill 401 244 363 403 244 363 minecraft:gray_concrete
setblock 402 244 364 minecraft:gray_concrete
setblock 406 244 364 minecraft:light_blue_stained_glass
setblock 408 244 364 minecraft:gray_concrete
setblock 410 244 322 minecraft:gray_concrete
fill 411 244 322 411 246 322 minecraft:black_concrete
fill 411 244 363 414 244 363 minecraft:gray_concrete
fill 412 244 322 412 244 323 minecraft:gray_concrete
fill 413 244 322 415 246 322 minecraft:black_concrete
fill 413 244 323 414 244 323 minecraft:gray_concrete
fill 413 244 328 415 269 330 minecraft:polished_deepslate
setblock 413 244 364 minecraft:gray_concrete
fill 414 244 331 414 271 331 minecraft:polished_deepslate
fill 414 244 347 414 244 348 minecraft:gray_concrete
setblock 414 244 349 minecraft:polished_deepslate
fill 414 244 350 414 245 352 minecraft:gray_concrete
fill 414 244 364 414 246 364 minecraft:black_concrete
setblock 415 244 323 minecraft:polished_deepslate
fill 415 244 344 415 244 347 minecraft:gray_concrete
setblock 415 244 348 minecraft:polished_deepslate
fill 415 244 349 415 247 349 minecraft:gray_concrete
fill 415 244 351 415 244 352 minecraft:gray_concrete
setblock 415 244 353 minecraft:polished_deepslate
fill 415 244 354 415 247 354 minecraft:gray_concrete
setblock 415 244 363 minecraft:polished_deepslate
fill 416 244 322 416 244 323 minecraft:gray_concrete
fill 416 244 325 416 244 326 minecraft:gray_concrete
setblock 416 244 327 minecraft:polished_deepslate
fill 416 244 328 416 244 331 minecraft:gray_concrete
setblock 416 244 332 minecraft:polished_deepslate
fill 416 244 333 417 246 333 minecraft:gray_concrete
setblock 416 244 341 minecraft:gray_concrete
setblock 416 244 342 minecraft:polished_deepslate
fill 416 244 343 416 244 346 minecraft:gray_concrete
setblock 416 244 347 minecraft:polished_deepslate
fill 416 244 348 416 247 348 minecraft:gray_concrete
setblock 416 244 351 minecraft:gray_concrete
setblock 416 244 352 minecraft:polished_deepslate
fill 416 244 353 416 247 353 minecraft:gray_concrete
setblock 416 244 356 minecraft:gray_concrete
setblock 416 244 357 minecraft:polished_deepslate
setblock 416 244 358 minecraft:gray_concrete
setblock 416 244 363 minecraft:gray_concrete
fill 417 244 323 417 244 325 minecraft:gray_concrete
setblock 417 244 326 minecraft:polished_deepslate
fill 417 244 327 417 244 330 minecraft:gray_concrete
setblock 417 244 331 minecraft:polished_deepslate
fill 417 244 332 417 247 332 minecraft:gray_concrete
fill 417 244 334 418 244 335 minecraft:gray_concrete
setblock 417 244 336 minecraft:polished_deepslate
fill 417 244 337 417 244 340 minecraft:gray_concrete
setblock 417 244 341 minecraft:polished_deepslate
fill 417 244 342 417 244 345 minecraft:gray_concrete
setblock 417 244 346 minecraft:polished_deepslate
fill 417 244 347 417 247 347 minecraft:gray_concrete
setblock 417 244 351 minecraft:polished_deepslate
fill 417 244 352 417 247 352 minecraft:gray_concrete
setblock 417 244 356 minecraft:polished_deepslate
fill 417 244 357 417 247 357 minecraft:gray_concrete
fill 417 244 359 417 244 360 minecraft:gray_concrete
setblock 417 244 361 minecraft:polished_deepslate
setblock 417 244 362 minecraft:gray_concrete
fill 418 244 323 418 245 323 minecraft:gray_concrete
fill 418 244 337 418 246 337 minecraft:black_concrete
fill 418 244 341 418 246 341 minecraft:black_concrete
setblock 418 244 345 minecraft:light_blue_stained_glass
fill 418 244 347 418 246 347 minecraft:black_concrete
fill 418 244 351 418 246 353 minecraft:black_concrete
setblock 418 244 354 minecraft:gray_concrete
fill 418 244 355 418 246 355 minecraft:black_concrete
setblock 418 244 358 minecraft:gray_concrete
fill 418 244 359 418 246 359 minecraft:black_concrete
setblock 376 245 322 minecraft:gray_concrete
fill 376 245 328 378 245 328 minecraft:gray_concrete
setblock 376 245 333 minecraft:black_concrete
fill 376 245 336 376 246 336 minecraft:black_concrete
fill 376 245 338 376 246 338 minecraft:black_concrete
fill 376 245 342 376 246 344 minecraft:black_concrete
setblock 376 245 345 minecraft:gray_concrete
fill 376 245 346 376 246 346 minecraft:black_concrete
fill 376 245 349 376 246 349 minecraft:black_concrete
setblock 376 245 350 minecraft:gray_concrete
fill 376 245 357 376 246 357 minecraft:black_concrete
fill 377 245 323 377 245 324 minecraft:gray_concrete
setblock 377 245 325 minecraft:polished_deepslate
fill 377 245 326 378 246 327 minecraft:gray_concrete
setblock 377 245 329 minecraft:gray_concrete
setblock 377 245 330 minecraft:polished_deepslate
fill 377 245 331 377 248 331 minecraft:gray_concrete
fill 377 245 333 377 245 334 minecraft:gray_concrete
setblock 377 245 335 minecraft:polished_deepslate
fill 377 245 336 377 248 336 minecraft:gray_concrete
fill 377 245 338 377 245 339 minecraft:gray_concrete
setblock 377 245 340 minecraft:polished_deepslate
fill 377 245 341 377 245 344 minecraft:gray_concrete
setblock 377 245 345 minecraft:polished_deepslate
fill 377 245 346 377 245 349 minecraft:gray_concrete
setblock 377 245 350 minecraft:polished_deepslate
fill 377 245 351 377 245 354 minecraft:gray_concrete
setblock 377 245 355 minecraft:polished_deepslate
fill 377 245 356 377 248 356 minecraft:gray_concrete
setblock 378 245 323 minecraft:gray_concrete
setblock 378 245 325 minecraft:gray_concrete
setblock 378 245 329 minecraft:polished_deepslate
fill 378 245 330 378 248 330 minecraft:gray_concrete
setblock 378 245 333 minecraft:gray_concrete
setblock 378 245 334 minecraft:polished_deepslate
fill 378 245 335 378 248 335 minecraft:gray_concrete
setblock 378 245 343 minecraft:gray_concrete
setblock 378 245 344 minecraft:polished_deepslate
setblock 378 245 345 minecraft:gray_concrete
fill 378 245 347 378 245 348 minecraft:gray_concrete
setblock 378 245 349 minecraft:polished_deepslate
fill 378 245 350 378 247 350 minecraft:gray_concrete
fill 378 245 364 378 246 364 minecraft:black_concrete
setblock 379 245 323 minecraft:polished_deepslate
setblock 379 245 328 minecraft:polished_deepslate
fill 379 245 329 379 246 329 minecraft:gray_concrete
setblock 379 245 364 minecraft:gray_concrete
fill 380 245 322 380 246 322 minecraft:black_concrete
setblock 380 245 323 minecraft:gray_concrete
fill 380 245 364 380 246 364 minecraft:black_concrete
setblock 381 245 322 minecraft:gray_concrete
fill 383 245 364 383 246 364 minecraft:black_concrete
fill 384 245 322 384 246 322 minecraft:black_concrete
fill 386 245 322 386 247 322 minecraft:black_concrete
fill 387 245 323 388 245 323 minecraft:gray_concrete
fill 388 245 322 389 246 322 minecraft:black_concrete
setblock 389 245 323 minecraft:polished_deepslate
fill 389 245 324 392 245 324 minecraft:gray_concrete
setblock 389 245 364 minecraft:gray_concrete
fill 390 245 323 393 245 323 minecraft:gray_concrete
setblock 391 245 325 minecraft:gray_concrete
setblock 392 245 325 minecraft:polished_deepslate
fill 392 245 363 392 245 364 minecraft:gray_concrete
setblock 393 245 324 minecraft:polished_deepslate
fill 393 245 325 396 245 325 minecraft:gray_concrete
setblock 393 245 363 minecraft:gray_concrete
fill 394 245 322 394 246 322 minecraft:black_concrete
setblock 394 245 323 minecraft:polished_deepslate
fill 394 245 324 397 245 324 minecraft:gray_concrete
setblock 394 245 326 minecraft:gray_concrete
setblock 394 245 363 minecraft:polished_deepslate
fill 395 245 322 395 245 323 minecraft:gray_concrete
fill 395 245 363 398 245 363 minecraft:gray_concrete
fill 396 245 323 398 245 323 minecraft:gray_concrete
setblock 396 245 362 minecraft:gray_concrete
setblock 397 245 325 minecraft:polished_deepslate
setblock 398 245 324 minecraft:polished_deepslate
setblock 398 245 325 minecraft:gray_concrete
setblock 398 245 364 minecraft:gray_concrete
setblock 399 245 323 minecraft:polished_deepslate
fill 399 245 324 400 245 324 minecraft:gray_concrete
setblock 399 245 363 minecraft:polished_deepslate
fill 400 245 323 401 245 323 minecraft:gray_concrete
fill 400 245 363 401 245 363 minecraft:gray_concrete
fill 402 245 364 402 246 364 minecraft:black_concrete
setblock 406 245 364 minecraft:gray_concrete
setblock 408 245 322 minecraft:gray_concrete
fill 408 245 364 408 246 364 minecraft:black_concrete
fill 410 245 322 410 246 322 minecraft:black_concrete
setblock 410 245 364 minecraft:gray_concrete
fill 411 245 364 411 246 364 minecraft:black_concrete
setblock 412 245 322 minecraft:black_concrete
fill 412 245 328 412 246 330 minecraft:black_concrete
fill 412 245 363 413 245 363 minecraft:gray_concrete
setblock 413 245 323 minecraft:gray_concrete
fill 413 245 327 415 246 327 minecraft:black_concrete
fill 413 245 331 413 246 331 minecraft:black_concrete
fill 413 245 364 413 246 364 minecraft:black_concrete
setblock 414 245 323 minecraft:polished_deepslate
setblock 414 245 348 minecraft:polished_deepslate
fill 414 245 349 414 247 349 minecraft:gray_concrete
setblock 414 245 353 minecraft:polished_deepslate
setblock 414 245 363 minecraft:polished_deepslate
fill 415 245 323 417 245 323 minecraft:gray_concrete
fill 415 245 331 415 246 331 minecraft:black_concrete
fill 415 245 345 415 245 346 minecraft:gray_concrete
setblock 415 245 347 minecraft:polished_deepslate
fill 415 245 348 415 248 348 minecraft:gray_concrete
fill 415 245 350 415 245 351 minecraft:gray_concrete
setblock 415 245 352 minecraft:polished_deepslate
fill 415 245 353 415 248 353 minecraft:gray_concrete
fill 415 245 355 416 245 355 minecraft:gray_concrete
setblock 415 245 363 minecraft:gray_concrete
fill 416 245 322 416 246 322 minecraft:black_concrete
setblock 416 245 326 minecraft:polished_deepslate
fill 416 245 327 416 245 330 minecraft:gray_concrete
setblock 416 245 331 minecraft:polished_deepslate
fill 416 245 332 416 248 332 minecraft:gray_concrete
fill 416 245 334 417 245 334 minecraft:gray_concrete
setblock 416 245 341 minecraft:polished_deepslate
fill 416 245 342 416 245 345 minecraft:gray_concrete
setblock 416 245 346 minecraft:polished_deepslate
fill 416 245 347 416 248 347 minecraft:gray_concrete
setblock 416 245 350 minecraft:gray_concrete
setblock 416 245 351 minecraft:polished_deepslate
fill 416 245 352 416 248 352 minecraft:gray_concrete
setblock 416 245 356 minecraft:polished_deepslate
fill 416 245 357 416 248 357 minecraft:gray_concrete
fill 416 245 364 416 246 364 minecraft:black_concrete
setblock 417 245 324 minecraft:gray_concrete
setblock 417 245 325 minecraft:polished_deepslate
fill 417 245 326 417 245 329 minecraft:gray_concrete
setblock 417 245 330 minecraft:polished_deepslate
fill 417 245 331 417 248 331 minecraft:gray_concrete
setblock 417 245 335 minecraft:polished_deepslate
fill 417 245 336 417 245 339 minecraft:gray_concrete
setblock 417 245 340 minecraft:polished_deepslate
fill 417 245 341 417 245 344 minecraft:gray_concrete
setblock 417 245 345 minecraft:polished_deepslate
fill 417 245 346 417 248 346 minecraft:gray_concrete
setblock 417 245 350 minecraft:polished_deepslate
fill 417 245 351 417 248 351 minecraft:gray_concrete
setblock 417 245 355 minecraft:polished_deepslate
fill 417 245 356 417 248 356 minecraft:gray_concrete
setblock 417 245 359 minecraft:gray_concrete
setblock 417 245 360 minecraft:polished_deepslate
setblock 417 245 364 minecraft:gray_concrete
setblock 418 245 322 minecraft:gray_concrete
fill 418 245 334 418 246 335 minecraft:black_concrete
fill 418 245 345 418 246 345 minecraft:black_concrete
fill 418 245 354 418 246 354 minecraft:black_concrete
fill 418 245 358 418 246 358 minecraft:black_concrete
fill 418 245 364 418 247 364 minecraft:black_concrete
setblock 376 246 322 minecraft:black_concrete
setblock 376 246 328 minecraft:black_concrete
fill 376 246 333 376 246 334 minecraft:light_blue_stained_glass
setblock 376 246 345 minecraft:black_concrete
setblock 376 246 350 minecraft:black_concrete
setblock 377 246 323 minecraft:gray_concrete
setblock 377 246 324 minecraft:polished_deepslate
fill 377 246 325 377 249 325 minecraft:gray_concrete
setblock 377 246 328 minecraft:gray_concrete
setblock 377 246 329 minecraft:polished_deepslate
fill 377 246 330 377 249 330 minecraft:gray_concrete
setblock 377 246 333 minecraft:gray_concrete
setblock 377 246 334 minecraft:polished_deepslate
fill 377 246 335 377 249 335 minecraft:gray_concrete
setblock 377 246 338 minecraft:gray_concrete
setblock 377 246 339 minecraft:polished_deepslate
fill 377 246 340 377 246 343 minecraft:gray_concrete
setblock 377 246 344 minecraft:polished_deepslate
fill 377 246 345 377 246 348 minecraft:gray_concrete
setblock 377 246 349 minecraft:polished_deepslate
fill 377 246 350 377 246 353 minecraft:gray_concrete
setblock 377 246 354 minecraft:polished_deepslate
fill 377 246 355 377 249 355 minecraft:gray_concrete
setblock 378 246 328 minecraft:polished_deepslate
fill 378 246 329 378 249 329 minecraft:gray_concrete
setblock 378 246 332 minecraft:gray_concrete
setblock 378 246 333 minecraft:polished_deepslate
fill 378 246 334 378 249 334 minecraft:gray_concrete
setblock 378 246 347 minecraft:gray_concrete
setblock 378 246 348 minecraft:polished_deepslate
fill 378 246 349 378 247 349 minecraft:gray_concrete
setblock 379 246 325 minecraft:light[level=13]
setblock 379 246 333 minecraft:light[level=13]
setblock 379 246 341 minecraft:light[level=13]
setblock 379 246 349 minecraft:light[level=13]
setblock 379 246 357 minecraft:light[level=13]
setblock 379 246 364 minecraft:black_concrete
setblock 381 246 322 minecraft:black_concrete
setblock 387 246 325 minecraft:light[level=13]
setblock 387 246 331 minecraft:ochre_froglight
setblock 387 246 334 minecraft:ochre_froglight
setblock 387 246 337 minecraft:ochre_froglight
setblock 387 246 340 minecraft:ochre_froglight
setblock 387 246 343 minecraft:ochre_froglight
setblock 387 246 349 minecraft:light[level=13]
setblock 387 246 357 minecraft:light[level=13]
setblock 388 246 323 minecraft:polished_deepslate
fill 388 246 329 388 250 329 minecraft:purple_terracotta
setblock 388 246 330 minecraft:ochre_froglight
fill 388 246 345 388 250 345 minecraft:purple_terracotta
fill 389 246 323 391 246 324 minecraft:gray_concrete
setblock 389 246 344 minecraft:ochre_froglight
fill 389 246 364 389 247 364 minecraft:black_concrete
setblock 391 246 325 minecraft:polished_deepslate
setblock 391 246 330 minecraft:ochre_froglight
setblock 392 246 323 minecraft:gray_concrete
setblock 392 246 324 minecraft:polished_deepslate
fill 392 246 325 395 246 325 minecraft:gray_concrete
setblock 392 246 344 minecraft:ochre_froglight
setblock 392 246 363 minecraft:gray_concrete
setblock 392 246 364 minecraft:black_concrete
setblock 393 246 323 minecraft:polished_deepslate
fill 393 246 324 396 246 324 minecraft:gray_concrete
setblock 393 246 363 minecraft:polished_deepslate
fill 394 246 323 397 246 323 minecraft:gray_concrete
setblock 394 246 330 minecraft:ochre_froglight
fill 394 246 363 397 246 363 minecraft:gray_concrete
setblock 395 246 322 minecraft:black_concrete
setblock 395 246 344 minecraft:ochre_froglight
setblock 395 246 349 minecraft:light[level=13]
setblock 395 246 357 minecraft:light[level=13]
setblock 396 246 325 minecraft:polished_deepslate
setblock 397 246 324 minecraft:polished_deepslate
setblock 397 246 330 minecraft:ochre_froglight
setblock 398 246 323 minecraft:polished_deepslate
setblock 398 246 324 minecraft:gray_concrete
setblock 398 246 344 minecraft:ochre_froglight
setblock 398 246 363 minecraft:polished_deepslate
fill 398 246 364 398 247 364 minecraft:black_concrete
fill 399 246 323 400 246 323 minecraft:gray_concrete
fill 399 246 363 400 246 363 minecraft:gray_concrete
setblock 400 246 330 minecraft:ochre_froglight
setblock 401 246 344 minecraft:ochre_froglight
setblock 402 246 322 minecraft:light_blue_stained_glass
setblock 403 246 325 minecraft:light[level=13]
setblock 403 246 330 minecraft:ochre_froglight
setblock 403 246 333 minecraft:light[level=13]
setblock 403 246 341 minecraft:light[level=13]
setblock 403 246 349 minecraft:light[level=13]
setblock 403 246 357 minecraft:light[level=13]
fill 404 246 329 404 250 329 minecraft:purple_terracotta
setblock 404 246 344 minecraft:ochre_froglight
fill 404 246 345 404 250 345 minecraft:purple_terracotta
setblock 405 246 331 minecraft:ochre_froglight
setblock 405 246 334 minecraft:ochre_froglight
setblock 405 246 337 minecraft:ochre_froglight
setblock 405 246 340 minecraft:ochre_froglight
setblock 405 246 343 minecraft:ochre_froglight
setblock 406 246 364 minecraft:black_concrete
setblock 408 246 322 minecraft:black_concrete
setblock 410 246 364 minecraft:black_concrete
setblock 411 246 325 minecraft:light[level=13]
fill 411 246 328 411 246 330 minecraft:black_concrete
setblock 411 246 333 minecraft:light[level=13]
setblock 411 246 341 minecraft:light[level=13]
setblock 411 246 349 minecraft:light[level=13]
setblock 411 246 357 minecraft:light[level=13]
setblock 412 246 322 minecraft:light_blue_stained_glass
setblock 412 246 327 minecraft:black_concrete
setblock 412 246 331 minecraft:black_concrete
fill 413 246 326 415 246 326 minecraft:black_concrete
fill 413 246 332 415 246 332 minecraft:black_concrete
fill 414 246 350 414 246 351 minecraft:gray_concrete
setblock 414 246 352 minecraft:polished_deepslate
fill 414 246 353 414 249 353 minecraft:gray_concrete
setblock 415 246 345 minecraft:gray_concrete
setblock 415 246 346 minecraft:polished_deepslate
fill 415 246 347 415 249 347 minecraft:gray_concrete
setblock 415 246 350 minecraft:gray_concrete
setblock 415 246 351 minecraft:polished_deepslate
fill 415 246 352 415 249 352 minecraft:gray_concrete
setblock 415 246 355 minecraft:gray_concrete
fill 416 246 327 416 246 329 minecraft:gray_concrete
setblock 416 246 330 minecraft:polished_deepslate
fill 416 246 331 416 249 331 minecraft:gray_concrete
setblock 416 246 334 minecraft:gray_concrete
setblock 416 246 335 minecraft:polished_deepslate
fill 416 246 342 416 246 344 minecraft:gray_concrete
setblock 416 246 345 minecraft:polished_deepslate
fill 416 246 346 416 249 346 minecraft:gray_concrete
setblock 416 246 349 minecraft:gray_concrete
setblock 416 246 350 minecraft:polished_deepslate
fill 416 246 351 416 249 351 minecraft:gray_concrete
setblock 416 246 354 minecraft:gray_concrete
setblock 416 246 355 minecraft:polished_deepslate
fill 416 246 356 416 249 356 minecraft:gray_concrete
fill 417 246 325 417 246 328 minecraft:gray_concrete
setblock 417 246 329 minecraft:polished_deepslate
fill 417 246 330 417 249 330 minecraft:gray_concrete
setblock 417 246 334 minecraft:polished_deepslate
fill 417 246 335 417 246 338 minecraft:gray_concrete
setblock 417 246 339 minecraft:polished_deepslate
fill 417 246 340 417 246 343 minecraft:gray_concrete
setblock 417 246 344 minecraft:polished_deepslate
fill 417 246 345 417 249 345 minecraft:gray_concrete
setblock 417 246 349 minecraft:polished_deepslate
fill 417 246 350 417 249 350 minecraft:gray_concrete
setblock 417 246 354 minecraft:polished_deepslate
fill 417 246 355 417 249 355 minecraft:gray_concrete
setblock 417 246 359 minecraft:polished_deepslate
setblock 417 246 364 minecraft:black_concrete
fill 418 246 322 418 246 323 minecraft:black_concrete
fill 376 247 322 376 308 324 minecraft:gray_concrete
fill 376 247 326 376 247 339 minecraft:gray_concrete
fill 376 247 341 376 247 353 minecraft:gray_concrete
fill 376 247 355 376 308 357 minecraft:gray_concrete
fill 376 247 359 376 308 359 minecraft:gray_concrete
setblock 376 247 360 minecraft:black_concrete
fill 376 247 361 376 254 364 minecraft:gray_concrete
fill 377 247 322 381 247 322 minecraft:gray_concrete
fill 377 247 324 377 248 324 minecraft:gray_concrete
fill 377 247 326 377 247 327 minecraft:gray_concrete
setblock 377 247 328 minecraft:polished_deepslate
fill 377 247 329 377 250 329 minecraft:gray_concrete
setblock 377 247 333 minecraft:polished_deepslate
fill 377 247 334 377 250 334 minecraft:gray_concrete
setblock 377 247 338 minecraft:polished_deepslate
fill 377 247 339 377 247 342 minecraft:gray_concrete
setblock 377 247 343 minecraft:polished_deepslate
fill 377 247 344 377 247 347 minecraft:gray_concrete
setblock 377 247 348 minecraft:polished_deepslate
fill 377 247 349 377 247 352 minecraft:gray_concrete
setblock 377 247 353 minecraft:polished_deepslate
fill 377 247 354 377 250 354 minecraft:gray_concrete
fill 377 247 364 388 247 364 minecraft:gray_concrete
setblock 378 247 326 minecraft:gray_concrete
setblock 378 247 327 minecraft:polished_deepslate
fill 378 247 328 378 250 328 minecraft:gray_concrete
setblock 378 247 332 minecraft:polished_deepslate
fill 378 247 333 378 250 333 minecraft:gray_concrete
fill 383 247 322 385 303 322 minecraft:gray_concrete
fill 387 247 331 405 247 331 minecraft:dark_oak_planks
fill 387 247 334 391 247 334 minecraft:dark_oak_planks
fill 387 247 337 391 247 337 minecraft:dark_oak_planks
fill 387 247 340 391 247 340 minecraft:dark_oak_planks
fill 387 247 343 405 247 343 minecraft:dark_oak_planks
fill 388 247 322 390 248 323 minecraft:gray_concrete
setblock 388 247 330 minecraft:dark_oak_planks
fill 388 247 332 391 247 333 minecraft:dark_oak_planks
fill 388 247 335 391 247 336 minecraft:dark_oak_planks
fill 388 247 338 391 247 339 minecraft:dark_oak_planks
fill 388 247 341 391 247 342 minecraft:dark_oak_planks
fill 389 247 329 389 250 329 minecraft:purple_terracotta
setblock 389 247 344 minecraft:dark_oak_planks
fill 389 247 345 389 250 345 minecraft:purple_terracotta
setblock 390 247 324 minecraft:gray_concrete
fill 390 247 364 390 281 364 minecraft:gray_concrete
setblock 391 247 323 minecraft:gray_concrete
setblock 391 247 324 minecraft:polished_deepslate
setblock 391 247 330 minecraft:dark_oak_planks
setblock 391 247 363 minecraft:gray_concrete
fill 392 247 322 396 247 322 minecraft:gray_concrete
setblock 392 247 323 minecraft:polished_deepslate
fill 392 247 324 394 247 325 minecraft:gray_concrete
fill 392 247 332 404 247 332 minecraft:dark_oak_planks
setblock 392 247 344 minecraft:dark_oak_planks
setblock 392 247 363 minecraft:polished_deepslate
fill 392 247 364 394 247 364 minecraft:gray_concrete
fill 393 247 323 396 247 323 minecraft:gray_concrete
fill 393 247 363 396 247 363 minecraft:gray_concrete
setblock 394 247 330 minecraft:dark_oak_planks
setblock 395 247 324 minecraft:gray_concrete
setblock 395 247 325 minecraft:polished_deepslate
setblock 395 247 344 minecraft:dark_oak_planks
setblock 396 247 324 minecraft:polished_deepslate
fill 396 247 364 396 274 364 minecraft:gray_concrete
setblock 397 247 323 minecraft:polished_deepslate
setblock 397 247 324 minecraft:gray_concrete
setblock 397 247 330 minecraft:dark_oak_planks
setblock 397 247 363 minecraft:yellow_concrete
fill 398 247 322 399 247 323 minecraft:gray_concrete
setblock 398 247 344 minecraft:dark_oak_planks
fill 398 247 363 399 247 363 minecraft:gray_concrete
fill 399 247 364 400 247 364 minecraft:gray_concrete
fill 400 247 322 418 247 322 minecraft:gray_concrete
setblock 400 247 330 minecraft:dark_oak_planks
setblock 401 247 344 minecraft:dark_oak_planks
fill 402 247 333 404 247 342 minecraft:dark_oak_planks
fill 402 247 364 406 248 364 minecraft:gray_concrete
fill 403 247 329 403 250 329 minecraft:purple_terracotta
setblock 403 247 330 minecraft:dark_oak_planks
fill 403 247 345 403 250 345 minecraft:purple_terracotta
setblock 404 247 344 minecraft:dark_oak_planks
setblock 405 247 334 minecraft:dark_oak_planks
setblock 405 247 337 minecraft:dark_oak_planks
setblock 405 247 340 minecraft:dark_oak_planks
fill 408 247 364 414 268 364 minecraft:gray_concrete
setblock 414 247 350 minecraft:gray_concrete
setblock 414 247 351 minecraft:polished_deepslate
fill 414 247 352 414 250 352 minecraft:gray_concrete
setblock 415 247 346 minecraft:gray_concrete
setblock 415 247 350 minecraft:polished_deepslate
fill 415 247 351 415 250 351 minecraft:gray_concrete
setblock 415 247 355 minecraft:polished_deepslate
setblock 416 247 328 minecraft:gray_concrete
setblock 416 247 329 minecraft:polished_deepslate
fill 416 247 330 416 250 330 minecraft:gray_concrete
setblock 416 247 333 minecraft:gray_concrete
setblock 416 247 334 minecraft:polished_deepslate
fill 416 247 335 418 247 336 minecraft:gray_concrete
setblock 416 247 343 minecraft:gray_concrete
setblock 416 247 344 minecraft:polished_deepslate
fill 416 247 345 416 250 345 minecraft:gray_concrete
setblock 416 247 349 minecraft:polished_deepslate
fill 416 247 350 416 250 350 minecraft:gray_concrete
setblock 416 247 354 minecraft:polished_deepslate
fill 416 247 355 416 250 355 minecraft:gray_concrete
fill 416 247 364 416 308 364 minecraft:gray_concrete
fill 417 247 326 418 247 327 minecraft:gray_concrete
setblock 417 247 328 minecraft:polished_deepslate
fill 417 247 329 418 250 329 minecraft:gray_concrete
setblock 417 247 333 minecraft:polished_deepslate
fill 417 247 334 418 248 334 minecraft:gray_concrete
fill 417 247 337 418 247 337 minecraft:gray_concrete
setblock 417 247 338 minecraft:polished_deepslate
fill 417 247 339 417 247 342 minecraft:gray_concrete
setblock 417 247 343 minecraft:polished_deepslate
fill 417 247 344 418 250 344 minecraft:gray_concrete
setblock 417 247 348 minecraft:polished_deepslate
fill 417 247 349 418 250 349 minecraft:gray_concrete
setblock 417 247 353 minecraft:polished_deepslate
fill 417 247 354 418 248 354 minecraft:gray_concrete
setblock 417 247 358 minecraft:polished_deepslate
fill 417 247 359 418 250 359 minecraft:gray_concrete
setblock 417 247 364 minecraft:light_blue_stained_glass
fill 418 247 323 418 269 325 minecraft:gray_concrete
fill 418 247 328 418 308 328 minecraft:gray_concrete
fill 418 247 330 418 256 333 minecraft:gray_concrete
fill 418 247 338 418 247 339 minecraft:black_concrete
fill 418 247 340 418 262 340 minecraft:gray_concrete
setblock 418 247 341 minecraft:light_blue_stained_glass
fill 418 247 342 418 253 343 minecraft:gray_concrete
fill 418 247 345 418 248 348 minecraft:gray_concrete
fill 418 247 351 418 247 352 minecraft:black_concrete
setblock 418 247 353 minecraft:gray_concrete
fill 418 247 355 418 248 358 minecraft:gray_concrete
fill 418 247 360 418 248 363 minecraft:gray_concrete
fill 376 248 325 376 248 332 minecraft:gray_concrete
setblock 376 248 333 minecraft:black_concrete
fill 376 248 334 376 266 340 minecraft:gray_concrete
setblock 376 248 341 minecraft:black_concrete
fill 376 248 342 376 248 343 minecraft:gray_concrete
setblock 376 248 344 minecraft:black_concrete
fill 376 248 345 376 248 354 minecraft:gray_concrete
fill 376 248 358 376 264 358 minecraft:gray_concrete
fill 376 248 360 376 300 360 minecraft:gray_concrete
fill 377 248 322 378 294 322 minecraft:gray_concrete
setblock 377 248 326 minecraft:gray_concrete
setblock 377 248 327 minecraft:polished_deepslate
fill 377 248 328 377 251 328 minecraft:gray_concrete
setblock 377 248 332 minecraft:polished_deepslate
fill 377 248 333 377 251 333 minecraft:gray_concrete
setblock 377 248 337 minecraft:polished_deepslate
fill 377 248 338 377 248 341 minecraft:gray_concrete
setblock 377 248 342 minecraft:polished_deepslate
fill 377 248 343 377 248 346 minecraft:gray_concrete
setblock 377 248 347 minecraft:polished_deepslate
fill 377 248 348 377 248 351 minecraft:gray_concrete
setblock 377 248 352 minecraft:polished_deepslate
fill 377 248 353 377 251 353 minecraft:gray_concrete
fill 377 248 364 377 251 364 minecraft:gray_concrete
fill 378 248 327 378 249 327 minecraft:gray_concrete
setblock 378 248 331 minecraft:polished_deepslate
fill 378 248 332 378 251 332 minecraft:gray_concrete
setblock 378 248 336 minecraft:polished_deepslate
fill 378 248 337 378 251 337 minecraft:gray_concrete
setblock 378 248 364 minecraft:black_concrete
fill 379 248 322 379 249 322 minecraft:black_concrete
setblock 379 248 325 minecraft:light[level=12]
setblock 379 248 332 minecraft:light[level=12]
setblock 379 248 339 minecraft:light[level=12]
setblock 379 248 346 minecraft:light[level=12]
setblock 379 248 353 minecraft:light[level=12]
setblock 379 248 360 minecraft:light[level=12]
fill 379 248 364 380 248 364 minecraft:gray_concrete
fill 380 248 322 382 248 322 minecraft:gray_concrete
setblock 381 248 364 minecraft:black_concrete
fill 382 248 364 389 267 364 minecraft:gray_concrete
fill 386 248 322 387 252 322 minecraft:gray_concrete
setblock 386 248 325 minecraft:light[level=12]
setblock 386 248 332 minecraft:light[level=12]
setblock 386 248 339 minecraft:light[level=12]
setblock 386 248 346 minecraft:light[level=12]
setblock 386 248 353 minecraft:light[level=12]
setblock 386 248 360 minecraft:light[level=12]
fill 387 248 329 387 250 329 minecraft:purple_terracotta
fill 387 248 330 391 248 344 minecraft:deepslate_tiles
fill 387 248 345 387 250 345 minecraft:purple_terracotta
fill 388 248 328 388 250 328 minecraft:purple_terracotta
fill 388 248 346 388 250 346 minecraft:purple_terracotta
setblock 390 248 324 minecraft:polished_deepslate
fill 391 248 322 391 261 322 minecraft:gray_concrete
setblock 391 248 323 minecraft:polished_deepslate
fill 391 248 324 394 248 324 minecraft:gray_concrete
setblock 391 248 363 minecraft:polished_deepslate
fill 391 248 364 391 308 364 minecraft:gray_concrete
setblock 392 248 322 minecraft:black_concrete
fill 392 248 323 395 248 323 minecraft:gray_concrete
fill 392 248 330 405 248 332 minecraft:deepslate_tiles
fill 392 248 343 405 248 344 minecraft:deepslate_tiles
fill 392 248 363 395 248 363 minecraft:gray_concrete
setblock 392 248 364 minecraft:black_concrete
fill 393 248 322 408 248 322 minecraft:gray_concrete
setblock 393 248 325 minecraft:light[level=12]
setblock 393 248 346 minecraft:light[level=12]
setblock 393 248 353 minecraft:light[level=12]
setblock 393 248 360 minecraft:light[level=12]
fill 393 248 364 395 248 364 minecraft:gray_concrete
setblock 395 248 324 minecraft:polished_deepslate
setblock 396 248 323 minecraft:polished_deepslate
setblock 396 248 324 minecraft:gray_concrete
setblock 396 248 363 minecraft:yellow_concrete
fill 397 248 323 398 248 323 minecraft:gray_concrete
fill 397 248 363 398 248 364 minecraft:gray_concrete
fill 399 248 364 399 308 364 minecraft:gray_concrete
setblock 400 248 325 minecraft:light[level=12]
setblock 400 248 346 minecraft:light[level=12]
setblock 400 248 353 minecraft:light[level=12]
setblock 400 248 360 minecraft:light[level=12]
setblock 400 248 364 minecraft:black_concrete
setblock 401 248 364 minecraft:gray_concrete
fill 402 248 333 405 248 342 minecraft:deepslate_tiles
fill 404 248 328 404 250 328 minecraft:purple_terracotta
fill 404 248 346 404 250 346 minecraft:purple_terracotta
fill 405 248 329 405 250 329 minecraft:purple_terracotta
fill 405 248 345 405 250 345 minecraft:purple_terracotta
setblock 407 248 325 minecraft:light[level=12]
setblock 407 248 332 minecraft:light[level=12]
setblock 407 248 339 minecraft:light[level=12]
setblock 407 248 346 minecraft:light[level=12]
setblock 407 248 353 minecraft:light[level=12]
setblock 407 248 360 minecraft:light[level=12]
fill 407 248 364 407 308 364 minecraft:gray_concrete
fill 409 248 322 409 249 322 minecraft:black_concrete
fill 410 248 322 414 248 322 minecraft:gray_concrete
setblock 414 248 325 minecraft:light[level=12]
setblock 414 248 332 minecraft:light[level=12]
setblock 414 248 339 minecraft:light[level=12]
setblock 414 248 346 minecraft:light[level=12]
setblock 414 248 350 minecraft:polished_deepslate
fill 414 248 351 414 251 351 minecraft:gray_concrete
setblock 414 248 360 minecraft:light[level=12]
setblock 415 248 322 minecraft:black_concrete
setblock 415 248 349 minecraft:polished_deepslate
fill 415 248 350 415 251 350 minecraft:gray_concrete
setblock 415 248 354 minecraft:polished_deepslate
fill 415 248 355 415 250 356 minecraft:gray_concrete
fill 415 248 364 415 288 364 minecraft:gray_concrete
fill 416 248 322 417 286 322 minecraft:gray_concrete
fill 416 248 329 416 251 329 minecraft:gray_concrete
setblock 416 248 333 minecraft:polished_deepslate
fill 416 248 334 416 248 337 minecraft:gray_concrete
fill 416 248 344 416 251 344 minecraft:gray_concrete
setblock 416 248 348 minecraft:polished_deepslate
fill 416 248 349 416 251 349 minecraft:gray_concrete
setblock 416 248 353 minecraft:polished_deepslate
fill 416 248 354 416 251 354 minecraft:gray_concrete
fill 417 248 326 418 248 326 minecraft:gray_concrete
setblock 417 248 327 minecraft:polished_deepslate
fill 417 248 328 417 251 328 minecraft:gray_concrete
setblock 417 248 332 minecraft:polished_deepslate
fill 417 248 333 417 251 333 minecraft:gray_concrete
fill 417 248 335 417 248 336 minecraft:gray_concrete
setblock 417 248 337 minecraft:polished_deepslate
fill 417 248 338 417 248 341 minecraft:gray_concrete
setblock 417 248 342 minecraft:polished_deepslate
fill 417 248 343 417 251 343 minecraft:gray_concrete
setblock 417 248 347 minecraft:polished_deepslate
fill 417 248 348 417 251 348 minecraft:gray_concrete
setblock 417 248 352 minecraft:polished_deepslate
fill 417 248 353 417 251 353 minecraft:gray_concrete
setblock 417 248 357 minecraft:polished_deepslate
fill 417 248 358 417 251 358 minecraft:gray_concrete
fill 417 248 364 418 248 364 minecraft:gray_concrete
setblock 418 248 322 minecraft:black_concrete
fill 418 248 327 418 308 327 minecraft:gray_concrete
setblock 418 248 335 minecraft:black_concrete
fill 418 248 336 418 255 339 minecraft:gray_concrete
setblock 418 248 341 minecraft:gray_concrete
fill 418 248 350 418 248 352 minecraft:gray_concrete
setblock 418 248 353 minecraft:light_blue_stained_glass
fill 376 249 325 376 251 326 minecraft:gray_concrete
fill 376 249 327 376 249 328 minecraft:black_concrete
fill 376 249 329 376 258 333 minecraft:gray_concrete
fill 376 249 341 376 257 342 minecraft:gray_concrete
setblock 376 249 343 minecraft:black_concrete
fill 376 249 344 376 255 348 minecraft:gray_concrete
setblock 376 249 349 minecraft:black_concrete
fill 376 249 350 376 261 354 minecraft:gray_concrete
setblock 377 249 326 minecraft:polished_deepslate
fill 377 249 327 377 252 327 minecraft:gray_concrete
setblock 377 249 331 minecraft:polished_deepslate
fill 377 249 332 377 252 332 minecraft:gray_concrete
setblock 377 249 336 minecraft:polished_deepslate
fill 377 249 337 377 249 340 minecraft:gray_concrete
setblock 377 249 341 minecraft:polished_deepslate
fill 377 249 342 377 249 345 minecraft:gray_concrete
setblock 377 249 346 minecraft:polished_deepslate
fill 377 249 347 377 249 350 minecraft:gray_concrete
setblock 377 249 351 minecraft:polished_deepslate
fill 377 249 352 377 252 352 minecraft:gray_concrete
setblock 377 249 356 minecraft:polished_deepslate
setblock 378 249 330 minecraft:polished_deepslate
fill 378 249 331 378 252 331 minecraft:gray_concrete
setblock 378 249 335 minecraft:polished_deepslate
fill 378 249 336 378 252 336 minecraft:gray_concrete
fill 378 249 364 378 308 364 minecraft:gray_concrete
fill 379 249 364 380 249 364 minecraft:black_concrete
fill 380 249 322 380 260 322 minecraft:gray_concrete
setblock 381 249 322 minecraft:black_concrete
fill 381 249 364 381 308 364 minecraft:gray_concrete
fill 382 249 322 382 308 322 minecraft:gray_concrete
fill 387 249 323 389 249 323 minecraft:gray_concrete
fill 387 249 328 387 250 328 minecraft:purple_terracotta
fill 387 249 330 389 250 330 minecraft:purple_terracotta
fill 387 249 344 389 250 344 minecraft:purple_terracotta
fill 387 249 346 387 250 346 minecraft:purple_terracotta
fill 388 249 322 390 308 322 minecraft:gray_concrete
fill 388 249 331 391 249 343 minecraft:deepslate_tiles
setblock 389 249 324 minecraft:polished_deepslate
fill 389 249 328 389 250 328 minecraft:purple_terracotta
fill 389 249 346 389 250 346 minecraft:purple_terracotta
setblock 390 249 323 minecraft:polished_deepslate
fill 390 249 324 393 249 324 minecraft:gray_concrete
fill 390 249 329 390 250 329 minecraft:purple_terracotta
fill 390 249 345 390 250 345 minecraft:purple_terracotta
setblock 390 249 363 minecraft:polished_deepslate
fill 391 249 323 394 249 323 minecraft:gray_concrete
fill 391 249 363 394 249 363 minecraft:gray_concrete
fill 392 249 322 394 257 322 minecraft:gray_concrete
fill 392 249 331 404 249 332 minecraft:deepslate_tiles
fill 392 249 343 404 249 343 minecraft:deepslate_tiles
fill 392 249 362 395 249 362 minecraft:gray_concrete
fill 392 249 364 393 261 364 minecraft:gray_concrete
setblock 394 249 324 minecraft:polished_deepslate
fill 394 249 329 394 250 330 minecraft:white_wool
setblock 394 249 364 minecraft:black_concrete
setblock 395 249 322 minecraft:black_concrete
setblock 395 249 323 minecraft:polished_deepslate
fill 395 249 324 395 250 324 minecraft:gray_concrete
setblock 395 249 363 minecraft:polished_deepslate
fill 395 249 364 395 281 364 minecraft:gray_concrete
fill 396 249 322 397 251 323 minecraft:gray_concrete
fill 396 249 363 396 252 363 minecraft:gray_concrete
setblock 397 249 363 minecraft:yellow_concrete
fill 397 249 364 398 269 364 minecraft:gray_concrete
fill 398 249 322 408 261 322 minecraft:gray_concrete
setblock 398 249 363 minecraft:gray_concrete
fill 400 249 364 400 269 364 minecraft:gray_concrete
setblock 401 249 364 minecraft:black_concrete
fill 402 249 329 402 250 329 minecraft:purple_terracotta
fill 402 249 333 404 249 342 minecraft:deepslate_tiles
fill 402 249 345 402 250 345 minecraft:purple_terracotta
fill 402 249 364 405 253 364 minecraft:gray_concrete
fill 403 249 328 403 250 328 minecraft:purple_terracotta
fill 403 249 330 405 250 330 minecraft:purple_terracotta
fill 403 249 344 405 250 344 minecraft:purple_terracotta
fill 403 249 346 403 250 346 minecraft:purple_terracotta
fill 405 249 328 405 250 328 minecraft:purple_terracotta
fill 405 249 346 405 250 346 minecraft:purple_terracotta
fill 406 249 344 407 249 345 minecraft:gray_wool
setblock 406 249 364 minecraft:black_concrete
fill 410 249 322 410 308 322 minecraft:gray_concrete
setblock 411 249 322 minecraft:black_concrete
fill 412 249 322 415 289 322 minecraft:gray_concrete
setblock 414 249 350 minecraft:gray_concrete
setblock 414 249 354 minecraft:polished_deepslate
setblock 415 249 333 minecraft:polished_deepslate
setblock 415 249 348 minecraft:polished_deepslate
fill 415 249 349 415 252 349 minecraft:gray_concrete
setblock 415 249 353 minecraft:polished_deepslate
fill 415 249 354 415 252 354 minecraft:gray_concrete
setblock 416 249 332 minecraft:polished_deepslate
fill 416 249 333 416 249 336 minecraft:gray_concrete
setblock 416 249 337 minecraft:polished_deepslate
fill 416 249 338 417 250 339 minecraft:gray_concrete
setblock 416 249 347 minecraft:polished_deepslate
fill 416 249 348 416 252 348 minecraft:gray_concrete
setblock 416 249 352 minecraft:polished_deepslate
fill 416 249 353 416 252 353 minecraft:gray_concrete
setblock 416 249 357 minecraft:polished_deepslate
fill 416 249 358 416 252 358 minecraft:gray_concrete
fill 417 249 327 417 251 327 minecraft:gray_concrete
setblock 417 249 331 minecraft:polished_deepslate
fill 417 249 332 417 252 332 minecraft:gray_concrete
fill 417 249 334 417 249 335 minecraft:gray_concrete
setblock 417 249 336 minecraft:polished_deepslate
fill 417 249 337 417 252 337 minecraft:gray_concrete
setblock 417 249 340 minecraft:gray_concrete
setblock 417 249 341 minecraft:polished_deepslate
fill 417 249 342 417 252 342 minecraft:gray_concrete
setblock 417 249 346 minecraft:polished_deepslate
fill 417 249 347 418 252 347 minecraft:gray_concrete
setblock 417 249 351 minecraft:polished_deepslate
fill 417 249 352 418 252 352 minecraft:gray_concrete
fill 417 249 354 417 250 354 minecraft:gray_concrete
setblock 417 249 356 minecraft:polished_deepslate
fill 417 249 357 417 252 357 minecraft:gray_concrete
setblock 417 249 364 minecraft:black_concrete
fill 418 249 322 418 308 322 minecraft:gray_concrete
fill 418 249 326 418 308 326 minecraft:gray_concrete
setblock 418 249 334 minecraft:black_concrete
fill 418 249 335 418 252 335 minecraft:gray_concrete
setblock 418 249 341 minecraft:black_concrete
fill 418 249 345 418 308 345 minecraft:gray_concrete
setblock 418 249 346 minecraft:black_concrete
fill 418 249 348 418 308 348 minecraft:gray_concrete
fill 418 249 350 418 270 350 minecraft:gray_concrete
setblock 418 249 351 minecraft:black_concrete
fill 418 249 353 418 308 353 minecraft:gray_concrete
setblock 418 249 354 minecraft:black_concrete
fill 418 249 355 418 308 356 minecraft:gray_concrete
setblock 418 249 357 minecraft:black_concrete
fill 418 249 358 418 268 358 minecraft:gray_concrete
setblock 418 249 360 minecraft:black_concrete
fill 418 249 361 418 308 361 minecraft:gray_concrete
setblock 418 249 362 minecraft:black_concrete
fill 418 249 363 418 290 364 minecraft:gray_concrete
fill 376 250 327 376 308 328 minecraft:gray_concrete
fill 376 250 343 377 250 343 minecraft:gray_concrete
fill 376 250 349 377 250 349 minecraft:gray_concrete
setblock 377 250 325 minecraft:polished_deepslate
fill 377 250 326 377 253 326 minecraft:gray_concrete
setblock 377 250 330 minecraft:polished_deepslate
fill 377 250 331 377 253 331 minecraft:gray_concrete
setblock 377 250 335 minecraft:polished_deepslate
fill 377 250 336 377 250 339 minecraft:gray_concrete
setblock 377 250 340 minecraft:polished_deepslate
fill 377 250 341 377 252 342 minecraft:gray_concrete
fill 377 250 347 377 250 348 minecraft:gray_concrete
setblock 377 250 350 minecraft:polished_deepslate
fill 377 250 351 377 252 351 minecraft:gray_concrete
setblock 377 250 355 minecraft:polished_deepslate
fill 377 250 356 377 252 357 minecraft:gray_concrete
setblock 378 250 329 minecraft:polished_deepslate
fill 378 250 330 378 253 330 minecraft:gray_concrete
setblock 378 250 334 minecraft:polished_deepslate
fill 378 250 335 378 253 335 minecraft:gray_concrete
setblock 378 250 338 minecraft:gray_concrete
fill 379 250 322 379 308 322 minecraft:gray_concrete
setblock 379 250 332 minecraft:gray_concrete
setblock 379 250 333 minecraft:polished_deepslate
fill 379 250 364 380 275 364 minecraft:gray_concrete
fill 381 250 322 381 308 322 minecraft:gray_concrete
fill 386 250 323 388 250 323 minecraft:gray_concrete
setblock 386 250 329 minecraft:purple_terracotta
setblock 386 250 345 minecraft:purple_terracotta
fill 387 250 331 389 250 331 minecraft:purple_terracotta
fill 387 250 343 389 250 343 minecraft:purple_terracotta
setblock 388 250 327 minecraft:purple_terracotta
setblock 388 250 347 minecraft:purple_terracotta
setblock 388 250 363 minecraft:gray_concrete
setblock 389 250 323 minecraft:polished_deepslate
fill 389 250 324 392 250 324 minecraft:gray_concrete
fill 389 250 332 391 250 342 minecraft:deepslate_tiles
setblock 389 250 363 minecraft:polished_deepslate
fill 390 250 323 393 250 323 minecraft:gray_concrete
setblock 390 250 328 minecraft:purple_terracotta
setblock 390 250 330 minecraft:purple_terracotta
setblock 390 250 344 minecraft:purple_terracotta
setblock 390 250 346 minecraft:purple_terracotta
fill 390 250 363 393 250 363 minecraft:gray_concrete
fill 391 250 362 394 250 362 minecraft:gray_concrete
fill 392 250 332 403 250 332 minecraft:deepslate_tiles
setblock 393 250 324 minecraft:polished_deepslate
setblock 394 250 323 minecraft:polished_deepslate
fill 394 250 324 394 253 324 minecraft:gray_concrete
setblock 394 250 363 minecraft:polished_deepslate
fill 394 250 364 394 308 364 minecraft:gray_concrete
fill 395 250 322 395 253 323 minecraft:gray_concrete
setblock 395 250 362 minecraft:polished_deepslate
fill 395 250 363 395 253 363 minecraft:gray_concrete
fill 396 250 362 396 253 362 minecraft:gray_concrete
fill 397 250 363 397 251 363 minecraft:gray_concrete
setblock 398 250 363 minecraft:ochre_froglight
setblock 399 250 363 minecraft:polished_deepslate
fill 401 250 364 401 308 364 minecraft:gray_concrete
setblock 402 250 328 minecraft:purple_terracotta
setblock 402 250 330 minecraft:purple_terracotta
fill 402 250 333 403 250 342 minecraft:deepslate_tiles
setblock 402 250 344 minecraft:purple_terracotta
setblock 402 250 346 minecraft:purple_terracotta
fill 403 250 331 405 250 331 minecraft:purple_terracotta
fill 403 250 343 405 250 343 minecraft:purple_terracotta
setblock 404 250 327 minecraft:purple_terracotta
setblock 404 250 347 minecraft:purple_terracotta
setblock 406 250 329 minecraft:purple_terracotta
fill 406 250 344 407 250 344 minecraft:gray_wool
setblock 406 250 345 minecraft:purple_terracotta
fill 406 250 364 406 295 364 minecraft:gray_concrete
setblock 407 250 345 minecraft:gray_wool
fill 409 250 322 409 308 322 minecraft:gray_concrete
setblock 409 250 363 minecraft:polished_deepslate
fill 410 250 363 413 250 363 minecraft:gray_concrete
fill 411 250 322 411 308 322 minecraft:gray_concrete
setblock 414 250 353 minecraft:polished_deepslate
fill 414 250 354 414 252 355 minecraft:gray_concrete
setblock 415 250 332 minecraft:polished_deepslate
fill 415 250 333 415 250 336 minecraft:gray_concrete
fill 415 250 348 415 251 348 minecraft:gray_concrete
setblock 415 250 352 minecraft:polished_deepslate
fill 415 250 353 415 253 353 minecraft:gray_concrete
setblock 415 250 357 minecraft:polished_deepslate
setblock 416 250 331 minecraft:polished_deepslate
fill 416 250 332 416 250 335 minecraft:gray_concrete
setblock 416 250 336 minecraft:polished_deepslate
fill 416 250 337 416 253 337 minecraft:gray_concrete
setblock 416 250 340 minecraft:gray_concrete
setblock 416 250 341 minecraft:polished_deepslate
fill 416 250 342 416 253 342 minecraft:gray_concrete
setblock 416 250 346 minecraft:polished_deepslate
fill 416 250 347 416 253 347 minecraft:gray_concrete
setblock 416 250 351 minecraft:polished_deepslate
fill 416 250 352 416 253 352 minecraft:gray_concrete
setblock 416 250 356 minecraft:polished_deepslate
fill 416 250 357 416 253 357 minecraft:gray_concrete
setblock 417 250 330 minecraft:polished_deepslate
fill 417 250 331 417 253 331 minecraft:gray_concrete
fill 417 250 334 418 250 334 minecraft:gray_concrete
setblock 417 250 335 minecraft:polished_deepslate
fill 417 250 336 417 253 336 minecraft:gray_concrete
setblock 417 250 340 minecraft:polished_deepslate
fill 417 250 341 418 253 341 minecraft:gray_concrete
setblock 417 250 345 minecraft:polished_deepslate
fill 417 250 346 418 253 346 minecraft:gray_concrete
setblock 417 250 350 minecraft:polished_deepslate
fill 417 250 351 418 253 351 minecraft:gray_concrete
setblock 417 250 355 minecraft:polished_deepslate
fill 417 250 356 417 253 356 minecraft:gray_concrete
fill 417 250 364 417 260 364 minecraft:gray_concrete
fill 418 250 354 418 308 354 minecraft:gray_concrete
fill 418 250 357 418 251 357 minecraft:gray_concrete
fill 418 250 360 418 308 360 minecraft:gray_concrete
fill 418 250 362 418 308 362 minecraft:gray_concrete
fill 376 251 343 376 308 343 minecraft:gray_concrete
fill 376 251 349 376 308 349 minecraft:gray_concrete
fill 377 251 325 377 254 325 minecraft:gray_concrete
setblock 377 251 329 minecraft:polished_deepslate
fill 377 251 330 377 254 330 minecraft:gray_concrete
setblock 377 251 334 minecraft:polished_deepslate
fill 377 251 335 377 251 338 minecraft:gray_concrete
setblock 377 251 339 minecraft:polished_deepslate
fill 377 251 340 377 254 340 minecraft:gray_concrete
setblock 377 251 349 minecraft:polished_deepslate
fill 377 251 350 377 252 350 minecraft:gray_concrete
setblock 377 251 354 minecraft:polished_deepslate
fill 377 251 355 377 254 355 minecraft:gray_concrete
setblock 377 251 358 minecraft:gray_concrete
setblock 378 251 328 minecraft:polished_deepslate
fill 378 251 329 378 254 329 minecraft:gray_concrete
setblock 378 251 333 minecraft:polished_deepslate
fill 378 251 334 379 253 334 minecraft:gray_concrete
setblock 378 251 338 minecraft:polished_deepslate
setblock 379 251 332 minecraft:polished_deepslate
fill 379 251 333 379 254 333 minecraft:gray_concrete
fill 385 251 323 387 251 323 minecraft:gray_concrete
setblock 387 251 363 minecraft:gray_concrete
setblock 388 251 323 minecraft:polished_deepslate
fill 388 251 324 391 251 324 minecraft:gray_concrete
setblock 388 251 363 minecraft:polished_deepslate
fill 389 251 323 392 251 323 minecraft:gray_concrete
fill 389 251 332 389 252 332 minecraft:light_blue_stained_glass
setblock 389 251 362 minecraft:polished_deepslate
fill 389 251 363 392 251 363 minecraft:gray_concrete
fill 390 251 333 391 251 341 minecraft:deepslate_tiles
fill 390 251 362 393 251 362 minecraft:gray_concrete
fill 391 251 361 394 251 361 minecraft:gray_concrete
setblock 392 251 324 minecraft:polished_deepslate
setblock 393 251 323 minecraft:polished_deepslate
fill 393 251 324 393 254 324 minecraft:gray_concrete
setblock 393 251 363 minecraft:polished_deepslate
fill 394 251 323 394 254 323 minecraft:gray_concrete
setblock 394 251 362 minecraft:polished_deepslate
fill 394 251 363 394 254 363 minecraft:gray_concrete
fill 395 251 362 395 254 362 minecraft:gray_concrete
fill 397 251 362 397 252 362 minecraft:gray_concrete
setblock 398 251 363 minecraft:polished_deepslate
setblock 399 251 363 minecraft:yellow_concrete
fill 402 251 333 402 251 341 minecraft:deepslate_tiles
setblock 407 251 363 minecraft:gray_concrete
setblock 408 251 363 minecraft:polished_deepslate
fill 409 251 363 412 251 363 minecraft:gray_concrete
setblock 413 251 363 minecraft:polished_deepslate
setblock 414 251 352 minecraft:polished_deepslate
fill 414 251 353 414 252 353 minecraft:gray_concrete
fill 414 251 363 414 254 363 minecraft:gray_concrete
setblock 415 251 331 minecraft:polished_deepslate
fill 415 251 332 415 251 335 minecraft:gray_concrete
setblock 415 251 336 minecraft:polished_deepslate
fill 415 251 337 415 253 338 minecraft:gray_concrete
setblock 415 251 351 minecraft:polished_deepslate
fill 415 251 352 415 253 352 minecraft:gray_concrete
setblock 415 251 355 minecraft:gray_concrete
setblock 415 251 356 minecraft:polished_deepslate
fill 415 251 357 415 254 357 minecraft:gray_concrete
setblock 416 251 330 minecraft:polished_deepslate
fill 416 251 331 416 251 334 minecraft:gray_concrete
setblock 416 251 335 minecraft:polished_deepslate
fill 416 251 336 416 254 336 minecraft:gray_concrete
fill 416 251 338 416 251 339 minecraft:gray_concrete
setblock 416 251 340 minecraft:polished_deepslate
fill 416 251 341 416 254 341 minecraft:gray_concrete
fill 416 251 343 416 252 343 minecraft:gray_concrete
setblock 416 251 345 minecraft:polished_deepslate
fill 416 251 346 416 253 346 minecraft:gray_concrete
setblock 416 251 350 minecraft:polished_deepslate
fill 416 251 351 416 254 351 minecraft:gray_concrete
setblock 416 251 355 minecraft:polished_deepslate
fill 416 251 356 416 254 356 minecraft:gray_concrete
setblock 417 251 329 minecraft:polished_deepslate
fill 417 251 330 417 254 330 minecraft:gray_concrete
setblock 417 251 334 minecraft:polished_deepslate
fill 417 251 335 417 254 335 minecraft:gray_concrete
setblock 417 251 338 minecraft:gray_concrete
setblock 417 251 339 minecraft:polished_deepslate
fill 417 251 340 417 254 340 minecraft:gray_concrete
setblock 417 251 344 minecraft:polished_deepslate
fill 417 251 345 417 254 345 minecraft:gray_concrete
setblock 417 251 349 minecraft:polished_deepslate
fill 417 251 350 417 254 350 minecraft:gray_concrete
setblock 417 251 354 minecraft:polished_deepslate
fill 417 251 355 417 254 355 minecraft:gray_concrete
setblock 417 251 359 minecraft:polished_deepslate
fill 417 251 360 417 254 360 minecraft:gray_concrete
fill 418 251 329 418 267 329 minecraft:gray_concrete
fill 418 251 334 418 284 334 minecraft:gray_concrete
fill 418 251 344 418 308 344 minecraft:gray_concrete
fill 418 251 349 418 300 349 minecraft:gray_concrete
fill 418 251 359 418 308 359 minecraft:gray_concrete
fill 376 252 325 376 308 325 minecraft:gray_concrete
setblock 376 252 326 minecraft:light_blue_stained_glass
setblock 377 252 328 minecraft:polished_deepslate
fill 377 252 329 377 255 329 minecraft:gray_concrete
setblock 377 252 333 minecraft:polished_deepslate
fill 377 252 334 377 252 337 minecraft:gray_concrete
setblock 377 252 338 minecraft:polished_deepslate
fill 377 252 339 378 254 339 minecraft:gray_concrete
setblock 377 252 343 minecraft:polished_deepslate
setblock 377 252 353 minecraft:polished_deepslate
fill 377 252 354 377 254 354 minecraft:gray_concrete
setblock 377 252 358 minecraft:polished_deepslate
fill 377 252 359 377 255 359 minecraft:gray_concrete
setblock 377 252 364 minecraft:light_blue_stained_glass
setblock 378 252 328 minecraft:gray_concrete
setblock 378 252 332 minecraft:polished_deepslate
fill 378 252 333 378 255 333 minecraft:gray_concrete
setblock 378 252 337 minecraft:polished_deepslate
fill 378 252 338 378 255 338 minecraft:gray_concrete
fill 379 252 332 379 253 332 minecraft:gray_concrete
setblock 379 252 335 minecraft:gray_concrete
fill 384 252 323 386 252 323 minecraft:gray_concrete
setblock 386 252 363 minecraft:gray_concrete
setblock 387 252 323 minecraft:polished_deepslate
fill 387 252 324 390 252 324 minecraft:gray_concrete
setblock 387 252 362 minecraft:gray_concrete
setblock 387 252 363 minecraft:polished_deepslate
fill 388 252 323 391 252 323 minecraft:gray_concrete
setblock 388 252 362 minecraft:polished_deepslate
fill 388 252 363 391 252 363 minecraft:gray_concrete
setblock 389 252 361 minecraft:polished_deepslate
fill 389 252 362 392 252 362 minecraft:gray_concrete
fill 390 252 361 393 252 361 minecraft:gray_concrete
setblock 391 252 324 minecraft:polished_deepslate
fill 391 252 334 391 252 340 minecraft:deepslate_tiles
setblock 392 252 323 minecraft:polished_deepslate
fill 392 252 324 392 255 324 minecraft:gray_concrete
setblock 392 252 363 minecraft:polished_deepslate
fill 393 252 323 393 255 323 minecraft:gray_concrete
setblock 393 252 362 minecraft:polished_deepslate
fill 393 252 363 393 255 363 minecraft:gray_concrete
setblock 394 252 361 minecraft:polished_deepslate
fill 394 252 362 394 255 362 minecraft:gray_concrete
fill 395 252 361 396 254 361 minecraft:gray_concrete
fill 396 252 322 396 252 323 minecraft:gray_concrete
fill 397 252 322 397 308 322 minecraft:gray_concrete
setblock 397 252 323 minecraft:polished_deepslate
setblock 397 252 363 minecraft:polished_deepslate
setblock 398 252 362 minecraft:polished_deepslate
setblock 398 252 363 minecraft:yellow_concrete
fill 399 252 363 401 252 363 minecraft:gray_concrete
fill 404 252 363 406 252 363 minecraft:gray_concrete
setblock 407 252 362 minecraft:gray_concrete
setblock 407 252 363 minecraft:polished_deepslate
setblock 408 252 362 minecraft:polished_deepslate
fill 408 252 363 411 252 363 minecraft:gray_concrete
fill 409 252 362 412 252 362 minecraft:gray_concrete
setblock 412 252 363 minecraft:polished_deepslate
fill 413 252 363 413 255 363 minecraft:gray_concrete
setblock 414 252 352 minecraft:gray_concrete
fill 415 252 331 415 252 334 minecraft:gray_concrete
setblock 415 252 335 minecraft:polished_deepslate
fill 415 252 336 415 255 336 minecraft:gray_concrete
setblock 415 252 339 minecraft:gray_concrete
setblock 415 252 340 minecraft:polished_deepslate
setblock 415 252 350 minecraft:polished_deepslate
fill 415 252 351 415 253 351 minecraft:gray_concrete
setblock 415 252 355 minecraft:polished_deepslate
fill 415 252 356 415 254 356 minecraft:gray_concrete
fill 416 252 329 416 267 329 minecraft:polished_deepslate
fill 416 252 330 416 252 333 minecraft:gray_concrete
setblock 416 252 334 minecraft:polished_deepslate
fill 416 252 335 416 255 335 minecraft:gray_concrete
setblock 416 252 338 minecraft:gray_concrete
setblock 416 252 339 minecraft:polished_deepslate
fill 416 252 340 416 255 340 minecraft:gray_concrete
setblock 416 252 344 minecraft:polished_deepslate
fill 416 252 345 416 253 345 minecraft:gray_concrete
setblock 416 252 349 minecraft:polished_deepslate
fill 416 252 350 416 254 350 minecraft:gray_concrete
setblock 416 252 354 minecraft:polished_deepslate
fill 416 252 355 416 255 355 minecraft:gray_concrete
setblock 416 252 359 minecraft:polished_deepslate
setblock 417 252 328 minecraft:polished_deepslate
fill 417 252 329 417 255 329 minecraft:gray_concrete
setblock 417 252 333 minecraft:polished_deepslate
fill 417 252 334 417 255 334 minecraft:gray_concrete
setblock 417 252 338 minecraft:polished_deepslate
fill 417 252 339 417 255 339 minecraft:gray_concrete
setblock 417 252 343 minecraft:polished_deepslate
fill 417 252 344 417 255 344 minecraft:gray_concrete
setblock 417 252 348 minecraft:polished_deepslate
fill 417 252 349 417 255 349 minecraft:gray_concrete
setblock 417 252 353 minecraft:polished_deepslate
fill 417 252 354 417 255 354 minecraft:gray_concrete
setblock 417 252 358 minecraft:polished_deepslate
fill 417 252 359 417 255 359 minecraft:gray_concrete
setblock 418 252 357 minecraft:light_blue_stained_glass
fill 376 253 326 376 308 326 minecraft:gray_concrete
setblock 377 253 327 minecraft:polished_deepslate
fill 377 253 328 377 256 328 minecraft:gray_concrete
setblock 377 253 332 minecraft:polished_deepslate
fill 377 253 333 377 253 336 minecraft:gray_concrete
setblock 377 253 337 minecraft:polished_deepslate
fill 377 253 338 377 256 338 minecraft:gray_concrete
setblock 377 253 341 minecraft:gray_concrete
setblock 377 253 342 minecraft:polished_deepslate
fill 377 253 343 377 254 343 minecraft:gray_concrete
setblock 377 253 352 minecraft:polished_deepslate
fill 377 253 353 377 254 353 minecraft:gray_concrete
setblock 377 253 356 minecraft:gray_concrete
setblock 377 253 357 minecraft:polished_deepslate
fill 377 253 358 377 256 358 minecraft:gray_concrete
fill 377 253 360 377 254 360 minecraft:gray_concrete
fill 377 253 364 377 308 364 minecraft:gray_concrete
setblock 378 253 331 minecraft:polished_deepslate
fill 378 253 332 378 256 332 minecraft:gray_concrete
setblock 378 253 336 minecraft:polished_deepslate
fill 378 253 337 378 256 337 minecraft:gray_concrete
setblock 379 253 335 minecraft:polished_deepslate
fill 383 253 323 385 253 323 minecraft:gray_concrete
fill 384 253 363 385 253 363 minecraft:gray_concrete
setblock 386 253 322 minecraft:light_blue_stained_glass
setblock 386 253 323 minecraft:polished_deepslate
fill 386 253 324 389 253 324 minecraft:gray_concrete
setblock 386 253 362 minecraft:gray_concrete
setblock 386 253 363 minecraft:polished_deepslate
fill 387 253 322 387 256 323 minecraft:gray_concrete
setblock 387 253 362 minecraft:polished_deepslate
fill 387 253 363 390 253 363 minecraft:gray_concrete
fill 388 253 323 390 253 323 minecraft:gray_concrete
setblock 388 253 361 minecraft:polished_deepslate
fill 388 253 362 391 253 362 minecraft:gray_concrete
fill 389 253 331 389 261 332 minecraft:black_concrete
fill 389 253 361 392 253 361 minecraft:gray_concrete
setblock 390 253 324 minecraft:polished_deepslate
setblock 390 253 325 minecraft:gray_concrete
fill 390 253 360 393 253 360 minecraft:gray_concrete
setblock 391 253 323 minecraft:polished_deepslate
fill 391 253 324 391 256 324 minecraft:gray_concrete
setblock 391 253 363 minecraft:polished_deepslate
fill 392 253 323 392 256 323 minecraft:gray_concrete
setblock 392 253 362 minecraft:polished_deepslate
fill 392 253 363 392 256 363 minecraft:gray_concrete
setblock 393 253 361 minecraft:polished_deepslate
fill 393 253 362 393 256 362 minecraft:gray_concrete
setblock 394 253 360 minecraft:polished_deepslate
fill 394 253 361 394 256 361 minecraft:gray_concrete
fill 396 253 322 396 308 322 minecraft:gray_concrete
setblock 396 253 323 minecraft:polished_deepslate
setblock 396 253 363 minecraft:polished_deepslate
setblock 397 253 362 minecraft:polished_deepslate
setblock 397 253 363 minecraft:yellow_concrete
fill 398 253 362 399 254 363 minecraft:gray_concrete
setblock 400 253 363 minecraft:gray_concrete
setblock 401 253 363 minecraft:polished_deepslate
fill 402 253 363 405 253 363 minecraft:gray_concrete
fill 405 253 362 406 253 362 minecraft:gray_concrete
setblock 406 253 363 minecraft:polished_deepslate
setblock 407 253 362 minecraft:polished_deepslate
fill 407 253 363 410 253 363 minecraft:gray_concrete
setblock 408 253 361 minecraft:polished_deepslate
fill 408 253 362 411 253 362 minecraft:gray_concrete
fill 409 253 361 411 254 361 minecraft:gray_concrete
setblock 411 253 363 minecraft:polished_deepslate
setblock 412 253 362 minecraft:polished_deepslate
fill 412 253 363 412 256 363 minecraft:gray_concrete
fill 413 253 362 413 256 362 minecraft:gray_concrete
setblock 414 253 334 minecraft:gray_concrete
setblock 414 253 335 minecraft:polished_deepslate
fill 414 253 336 414 254 338 minecraft:gray_concrete
setblock 414 253 355 minecraft:polished_deepslate
fill 415 253 332 415 253 333 minecraft:gray_concrete
setblock 415 253 334 minecraft:polished_deepslate
fill 415 253 335 415 256 335 minecraft:gray_concrete
setblock 415 253 339 minecraft:polished_deepslate
fill 415 253 340 415 255 341 minecraft:gray_concrete
setblock 415 253 354 minecraft:polished_deepslate
fill 415 253 355 415 254 355 minecraft:gray_concrete
setblock 415 253 358 minecraft:gray_concrete
setblock 415 253 363 minecraft:gray_concrete
fill 416 253 330 416 253 332 minecraft:gray_concrete
setblock 416 253 333 minecraft:polished_deepslate
fill 416 253 334 416 256 334 minecraft:gray_concrete
setblock 416 253 338 minecraft:polished_deepslate
fill 416 253 339 416 256 339 minecraft:gray_concrete
setblock 416 253 343 minecraft:polished_deepslate
fill 416 253 344 416 255 344 minecraft:gray_concrete
setblock 416 253 348 minecraft:polished_deepslate
setblock 416 253 349 minecraft:gray_concrete
setblock 416 253 353 minecraft:polished_deepslate
fill 416 253 354 416 255 354 minecraft:gray_concrete
setblock 416 253 358 minecraft:polished_deepslate
fill 416 253 359 416 255 359 minecraft:gray_concrete
fill 417 253 328 417 254 328 minecraft:gray_concrete
setblock 417 253 332 minecraft:polished_deepslate
fill 417 253 333 417 256 333 minecraft:gray_concrete
setblock 417 253 337 minecraft:polished_deepslate
fill 417 253 338 417 256 338 minecraft:gray_concrete
setblock 417 253 342 minecraft:polished_deepslate
fill 417 253 343 417 256 343 minecraft:gray_concrete
setblock 417 253 347 minecraft:polished_deepslate
fill 417 253 348 417 255 348 minecraft:gray_concrete
setblock 417 253 352 minecraft:polished_deepslate
fill 417 253 353 417 256 353 minecraft:gray_concrete
setblock 417 253 357 minecraft:polished_deepslate
fill 417 253 358 417 256 358 minecraft:gray_concrete
setblock 417 253 361 minecraft:gray_concrete
setblock 418 253 335 minecraft:light_blue_stained_glass
fill 418 253 347 418 308 347 minecraft:gray_concrete
fill 418 253 352 418 308 352 minecraft:gray_concrete
fill 418 253 357 418 308 357 minecraft:gray_concrete
setblock 377 254 326 minecraft:polished_deepslate
fill 377 254 327 377 256 327 minecraft:gray_concrete
setblock 377 254 331 minecraft:polished_deepslate
fill 377 254 332 377 254 335 minecraft:gray_concrete
setblock 377 254 336 minecraft:polished_deepslate
fill 377 254 337 377 257 337 minecraft:gray_concrete
setblock 377 254 341 minecraft:polished_deepslate
fill 377 254 342 377 257 342 minecraft:gray_concrete
setblock 377 254 356 minecraft:polished_deepslate
fill 377 254 357 377 256 357 minecraft:gray_concrete
setblock 378 254 330 minecraft:polished_deepslate
fill 378 254 331 378 255 331 minecraft:gray_concrete
setblock 378 254 334 minecraft:gray_concrete
setblock 378 254 335 minecraft:polished_deepslate
fill 378 254 336 378 257 336 minecraft:gray_concrete
setblock 379 254 325 minecraft:light[level=13]
setblock 379 254 332 minecraft:light[level=12]
setblock 379 254 334 minecraft:polished_deepslate
setblock 379 254 335 minecraft:gray_concrete
setblock 379 254 339 minecraft:light[level=12]
setblock 379 254 341 minecraft:light[level=13]
setblock 379 254 346 minecraft:light[level=12]
setblock 379 254 349 minecraft:light[level=13]
setblock 379 254 353 minecraft:light[level=12]
setblock 379 254 357 minecraft:light[level=13]
setblock 379 254 360 minecraft:light[level=12]
fill 382 254 323 384 254 323 minecraft:gray_concrete
fill 383 254 363 384 254 363 minecraft:gray_concrete
setblock 385 254 323 minecraft:polished_deepslate
fill 385 254 324 388 254 324 minecraft:gray_concrete
setblock 385 254 362 minecraft:gray_concrete
setblock 385 254 363 minecraft:polished_deepslate
fill 386 254 322 386 255 323 minecraft:gray_concrete
setblock 386 254 325 minecraft:light[level=12]
setblock 386 254 332 minecraft:light[level=12]
setblock 386 254 339 minecraft:light[level=12]
setblock 386 254 346 minecraft:light[level=12]
setblock 386 254 353 minecraft:light[level=12]
setblock 386 254 360 minecraft:light[level=12]
setblock 386 254 362 minecraft:polished_deepslate
fill 386 254 363 389 254 363 minecraft:gray_concrete
setblock 387 254 325 minecraft:light[level=13]
setblock 387 254 333 minecraft:light[level=13]
setblock 387 254 341 minecraft:light[level=13]
setblock 387 254 349 minecraft:light[level=13]
setblock 387 254 357 minecraft:light[level=13]
setblock 387 254 361 minecraft:polished_deepslate
fill 387 254 362 390 254 362 minecraft:gray_concrete
fill 388 254 323 389 254 323 minecraft:gray_concrete
fill 388 254 361 391 254 361 minecraft:gray_concrete
setblock 389 254 324 minecraft:polished_deepslate
setblock 389 254 325 minecraft:gray_concrete
fill 389 254 360 392 254 360 minecraft:gray_concrete
setblock 390 254 323 minecraft:polished_deepslate
fill 390 254 324 390 257 324 minecraft:gray_concrete
setblock 390 254 363 minecraft:polished_deepslate
fill 391 254 323 391 257 323 minecraft:gray_concrete
setblock 391 254 362 minecraft:polished_deepslate
fill 391 254 363 391 257 363 minecraft:gray_concrete
setblock 392 254 361 minecraft:polished_deepslate
fill 392 254 362 392 257 362 minecraft:gray_concrete
setblock 393 254 325 minecraft:light[level=12]
setblock 393 254 332 minecraft:light[level=12]
setblock 393 254 346 minecraft:light[level=12]
setblock 393 254 353 minecraft:light[level=12]
setblock 393 254 360 minecraft:polished_deepslate
fill 393 254 361 393 257 361 minecraft:gray_concrete
fill 394 254 360 394 256 360 minecraft:gray_concrete
fill 395 254 322 395 308 322 minecraft:gray_concrete
setblock 395 254 323 minecraft:polished_deepslate
setblock 395 254 325 minecraft:light[level=13]
setblock 395 254 349 minecraft:light[level=13]
setblock 395 254 357 minecraft:light[level=13]
setblock 395 254 363 minecraft:polished_deepslate
fill 396 254 323 396 255 323 minecraft:gray_concrete
setblock 396 254 362 minecraft:polished_deepslate
setblock 396 254 363 minecraft:yellow_concrete
setblock 397 254 361 minecraft:polished_deepslate
fill 397 254 362 397 254 363 minecraft:gray_concrete
setblock 400 254 325 minecraft:light[level=12]
setblock 400 254 332 minecraft:light[level=12]
setblock 400 254 346 minecraft:light[level=12]
setblock 400 254 353 minecraft:light[level=12]
setblock 400 254 360 minecraft:light[level=12]
setblock 400 254 362 minecraft:gray_concrete
setblock 400 254 363 minecraft:polished_deepslate
fill 401 254 363 404 254 363 minecraft:gray_concrete
fill 402 254 362 405 254 362 minecraft:gray_concrete
fill 402 254 364 404 308 364 minecraft:gray_concrete
setblock 403 254 325 minecraft:light[level=13]
setblock 403 254 333 minecraft:light[level=13]
setblock 403 254 341 minecraft:light[level=13]
setblock 403 254 349 minecraft:light[level=13]
setblock 403 254 357 minecraft:light[level=13]
setblock 405 254 363 minecraft:polished_deepslate
setblock 405 254 364 minecraft:light_blue_stained_glass
setblock 406 254 361 minecraft:gray_concrete
setblock 406 254 362 minecraft:polished_deepslate
fill 406 254 363 409 254 363 minecraft:gray_concrete
setblock 407 254 325 minecraft:light[level=12]
setblock 407 254 332 minecraft:light[level=12]
setblock 407 254 339 minecraft:light[level=12]
setblock 407 254 346 minecraft:light[level=12]
setblock 407 254 353 minecraft:light[level=12]
setblock 407 254 360 minecraft:light[level=12]
setblock 407 254 361 minecraft:polished_deepslate
fill 407 254 362 410 254 362 minecraft:gray_concrete
fill 408 254 361 408 257 361 minecraft:gray_concrete
setblock 409 254 323 minecraft:gray_concrete
setblock 410 254 323 minecraft:polished_deepslate
setblock 410 254 363 minecraft:polished_deepslate
fill 411 254 323 412 255 323 minecraft:gray_concrete
setblock 411 254 325 minecraft:light[level=13]
setblock 411 254 333 minecraft:light[level=13]
setblock 411 254 341 minecraft:light[level=13]
setblock 411 254 349 minecraft:light[level=13]
setblock 411 254 357 minecraft:light[level=13]
setblock 411 254 362 minecraft:polished_deepslate
fill 411 254 363 411 257 363 minecraft:gray_concrete
setblock 412 254 361 minecraft:polished_deepslate
fill 412 254 362 412 257 362 minecraft:gray_concrete
setblock 414 254 325 minecraft:light[level=12]
setblock 414 254 332 minecraft:light[level=12]
setblock 414 254 334 minecraft:polished_deepslate
fill 414 254 335 414 255 335 minecraft:gray_concrete
setblock 414 254 339 minecraft:polished_deepslate
setblock 414 254 346 minecraft:light[level=12]
setblock 414 254 353 minecraft:light[level=12]
setblock 414 254 360 minecraft:light[level=12]
setblock 415 254 332 minecraft:gray_concrete
setblock 415 254 333 minecraft:polished_deepslate
fill 415 254 334 415 256 334 minecraft:gray_concrete
setblock 415 254 337 minecraft:gray_concrete
setblock 415 254 338 minecraft:polished_deepslate
fill 415 254 339 415 257 339 minecraft:gray_concrete
setblock 415 254 353 minecraft:polished_deepslate
setblock 415 254 354 minecraft:gray_concrete
setblock 415 254 363 minecraft:polished_deepslate
fill 416 254 330 416 254 331 minecraft:gray_concrete
setblock 416 254 332 minecraft:polished_deepslate
fill 416 254 333 416 257 333 minecraft:gray_concrete
setblock 416 254 337 minecraft:polished_deepslate
fill 416 254 338 416 257 338 minecraft:gray_concrete
setblock 416 254 342 minecraft:polished_deepslate
fill 416 254 343 416 257 343 minecraft:gray_concrete
setblock 416 254 352 minecraft:polished_deepslate
fill 416 254 353 416 255 353 minecraft:gray_concrete
setblock 416 254 357 minecraft:polished_deepslate
fill 416 254 358 416 255 358 minecraft:gray_concrete
setblock 417 254 331 minecraft:polished_deepslate
fill 417 254 332 417 257 332 minecraft:gray_concrete
setblock 417 254 336 minecraft:polished_deepslate
fill 417 254 337 417 257 337 minecraft:gray_concrete
setblock 417 254 341 minecraft:polished_deepslate
fill 417 254 342 418 257 342 minecraft:gray_concrete
setblock 417 254 346 minecraft:polished_deepslate
fill 417 254 347 417 255 347 minecraft:gray_concrete
setblock 417 254 351 minecraft:polished_deepslate
fill 417 254 352 417 255 352 minecraft:gray_concrete
setblock 417 254 356 minecraft:polished_deepslate
fill 417 254 357 417 257 357 minecraft:gray_concrete
setblock 417 254 361 minecraft:polished_deepslate
fill 418 254 335 418 308 335 minecraft:gray_concrete
fill 418 254 341 418 267 341 minecraft:gray_concrete
setblock 418 254 343 minecraft:light_blue_stained_glass
fill 418 254 346 418 307 346 minecraft:gray_concrete
fill 418 254 351 418 308 351 minecraft:gray_concrete
setblock 376 255 361 minecraft:light_blue_stained_glass
fill 376 255 362 376 265 364 minecraft:gray_concrete
setblock 377 255 326 minecraft:gray_concrete
setblock 377 255 330 minecraft:polished_deepslate
fill 377 255 331 377 255 334 minecraft:gray_concrete
setblock 377 255 335 minecraft:polished_deepslate
fill 377 255 336 377 258 336 minecraft:gray_concrete
setblock 377 255 339 minecraft:gray_concrete
setblock 377 255 340 minecraft:polished_deepslate
fill 377 255 341 377 258 341 minecraft:gray_concrete
setblock 377 255 355 minecraft:polished_deepslate
setblock 377 255 356 minecraft:gray_concrete
setblock 377 255 360 minecraft:polished_deepslate
fill 377 255 361 377 257 361 minecraft:gray_concrete
setblock 378 255 330 minecraft:gray_concrete
setblock 378 255 334 minecraft:polished_deepslate
fill 378 255 335 378 257 335 minecraft:gray_concrete
setblock 378 255 339 minecraft:polished_deepslate
fill 381 255 323 383 255 323 minecraft:gray_concrete
fill 382 255 363 383 255 363 minecraft:gray_concrete
setblock 384 255 323 minecraft:polished_deepslate
setblock 384 255 362 minecraft:gray_concrete
setblock 384 255 363 minecraft:polished_deepslate
fill 385 255 323 385 257 324 minecraft:gray_concrete
setblock 385 255 362 minecraft:polished_deepslate
fill 385 255 363 388 255 363 minecraft:gray_concrete
fill 386 255 324 387 255 324 minecraft:gray_concrete
setblock 386 255 361 minecraft:polished_deepslate
fill 386 255 362 389 255 362 minecraft:gray_concrete
fill 387 255 361 390 255 361 minecraft:gray_concrete
setblock 388 255 323 minecraft:gray_concrete
setblock 388 255 324 minecraft:polished_deepslate
fill 388 255 360 391 255 360 minecraft:gray_concrete
setblock 389 255 323 minecraft:polished_deepslate
fill 389 255 324 389 258 324 minecraft:gray_concrete
setblock 389 255 363 minecraft:polished_deepslate
fill 390 255 323 390 258 323 minecraft:gray_concrete
fill 390 255 331 390 261 332 minecraft:black_concrete
setblock 390 255 362 minecraft:polished_deepslate
fill 390 255 363 390 258 363 minecraft:gray_concrete
setblock 391 255 361 minecraft:polished_deepslate
fill 391 255 362 391 258 362 minecraft:gray_concrete
setblock 392 255 360 minecraft:polished_deepslate
fill 392 255 361 392 258 361 minecraft:gray_concrete
setblock 393 255 324 minecraft:polished_deepslate
fill 393 255 360 393 257 360 minecraft:gray_concrete
setblock 394 255 323 minecraft:polished_deepslate
setblock 394 255 363 minecraft:polished_deepslate
fill 395 255 323 395 256 323 minecraft:gray_concrete
setblock 395 255 361 minecraft:gray_concrete
setblock 395 255 362 minecraft:polished_deepslate
fill 395 255 363 396 257 363 minecraft:gray_concrete
setblock 396 255 361 minecraft:polished_deepslate
fill 396 255 362 399 255 362 minecraft:gray_concrete
fill 397 255 361 397 256 361 minecraft:gray_concrete
setblock 397 255 363 minecraft:ochre_froglight
setblock 398 255 363 minecraft:gray_concrete
setblock 399 255 363 minecraft:polished_deepslate
setblock 400 255 362 minecraft:polished_deepslate
fill 400 255 363 403 255 363 minecraft:gray_concrete
fill 401 255 362 404 255 362 minecraft:gray_concrete
setblock 404 255 363 minecraft:polished_deepslate
setblock 405 255 361 minecraft:gray_concrete
schedule function dropper:buildpart/80_8 1t
