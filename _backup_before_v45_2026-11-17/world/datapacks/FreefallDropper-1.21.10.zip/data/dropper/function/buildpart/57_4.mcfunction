setblock 427 278 245 minecraft:blue_stained_glass
setblock 427 278 246 minecraft:black_stained_glass
fill 427 278 247 427 278 248 minecraft:blue_stained_glass
setblock 427 278 249 minecraft:black_stained_glass
fill 427 278 250 427 278 251 minecraft:blue_stained_glass
setblock 427 278 252 minecraft:black_stained_glass
setblock 427 278 253 minecraft:blue_stained_glass
fill 428 278 243 428 278 244 minecraft:white_concrete
fill 428 278 247 429 278 249 minecraft:white_concrete
fill 428 278 252 430 278 254 minecraft:white_concrete
fill 428 278 270 428 308 270 minecraft:black_concrete
fill 429 278 241 432 278 242 minecraft:white_concrete
fill 429 278 244 430 278 246 minecraft:white_concrete
fill 429 278 255 430 278 257 minecraft:white_concrete
setblock 430 278 240 minecraft:white_concrete
fill 430 278 248 430 278 249 minecraft:white_concrete
setblock 430 278 251 minecraft:white_concrete
fill 430 278 258 433 278 259 minecraft:white_concrete
setblock 430 278 270 minecraft:pearlescent_froglight
fill 431 278 238 434 278 238 minecraft:white_concrete
fill 431 278 254 431 278 255 minecraft:white_concrete
fill 431 278 260 435 278 260 minecraft:white_concrete
setblock 432 278 237 minecraft:white_concrete
setblock 432 278 257 minecraft:white_concrete
fill 432 278 261 434 278 261 minecraft:white_concrete
fill 432 278 270 433 283 270 minecraft:black_concrete
fill 433 278 236 439 278 236 minecraft:white_concrete
fill 433 278 239 434 278 239 minecraft:white_concrete
fill 433 278 262 434 278 262 minecraft:white_concrete
fill 434 278 235 435 278 235 minecraft:white_concrete
setblock 434 278 259 minecraft:white_concrete
fill 435 278 237 437 278 237 minecraft:white_concrete
fill 436 278 263 437 278 264 minecraft:white_concrete
fill 437 278 247 437 278 251 minecraft:light_blue_stained_glass
fill 437 278 261 437 278 262 minecraft:white_concrete
fill 438 278 233 442 278 235 minecraft:white_concrete
fill 438 278 245 438 278 246 minecraft:light_blue_stained_glass
fill 438 278 252 438 278 253 minecraft:light_blue_stained_glass
setblock 438 278 262 minecraft:white_concrete
fill 438 278 265 444 278 265 minecraft:white_concrete
fill 439 278 244 439 278 245 minecraft:light_blue_stained_glass
fill 439 278 253 439 278 254 minecraft:light_blue_stained_glass
setblock 440 278 232 minecraft:blue_stained_glass
fill 440 278 243 440 278 244 minecraft:light_blue_stained_glass
fill 440 278 254 440 278 255 minecraft:light_blue_stained_glass
fill 440 278 263 441 278 264 minecraft:white_concrete
setblock 440 278 267 minecraft:blue_stained_glass
setblock 441 278 232 minecraft:black_stained_glass
setblock 441 278 243 minecraft:light_blue_stained_glass
setblock 441 278 255 minecraft:light_blue_stained_glass
setblock 441 278 267 minecraft:black_stained_glass
fill 442 278 232 443 278 232 minecraft:blue_stained_glass
fill 442 278 242 446 278 242 minecraft:light_blue_stained_glass
fill 442 278 256 446 278 256 minecraft:light_blue_stained_glass
fill 442 278 264 444 278 264 minecraft:white_concrete
fill 442 278 266 444 278 266 minecraft:white_concrete
fill 442 278 267 443 278 267 minecraft:blue_stained_glass
fill 443 278 263 444 278 263 minecraft:white_concrete
setblock 444 278 232 minecraft:black_stained_glass
setblock 444 278 267 minecraft:black_stained_glass
fill 445 278 232 446 278 232 minecraft:blue_stained_glass
fill 445 278 233 445 278 235 minecraft:white_concrete
fill 445 278 267 446 278 267 minecraft:blue_stained_glass
setblock 446 278 233 minecraft:white_concrete
fill 446 278 263 450 278 264 minecraft:white_concrete
fill 446 278 270 446 308 270 minecraft:black_concrete
setblock 447 278 232 minecraft:black_stained_glass
fill 447 278 243 448 278 243 minecraft:light_blue_stained_glass
fill 447 278 255 448 278 255 minecraft:light_blue_stained_glass
fill 447 278 265 450 278 265 minecraft:white_concrete
setblock 447 278 267 minecraft:black_stained_glass
setblock 448 278 232 minecraft:blue_stained_glass
fill 448 278 233 449 278 235 minecraft:white_concrete
fill 448 278 244 449 278 244 minecraft:light_blue_stained_glass
fill 448 278 254 449 278 254 minecraft:light_blue_stained_glass
setblock 448 278 267 minecraft:blue_stained_glass
fill 449 278 245 450 278 245 minecraft:light_blue_stained_glass
fill 449 278 253 450 278 253 minecraft:light_blue_stained_glass
fill 449 278 262 450 278 262 minecraft:white_concrete
setblock 450 278 246 minecraft:light_blue_stained_glass
setblock 450 278 252 minecraft:light_blue_stained_glass
fill 451 278 234 452 278 237 minecraft:white_concrete
fill 451 278 247 451 278 251 minecraft:light_blue_stained_glass
fill 451 278 261 453 278 261 minecraft:white_concrete
fill 451 278 264 452 278 264 minecraft:white_concrete
fill 453 278 238 455 278 238 minecraft:white_concrete
fill 453 278 262 454 278 263 minecraft:white_concrete
fill 454 278 237 456 278 237 minecraft:white_concrete
fill 454 278 239 455 278 239 minecraft:white_concrete
fill 454 278 259 456 278 260 minecraft:white_concrete
setblock 455 278 236 minecraft:white_concrete
setblock 455 278 258 minecraft:white_concrete
setblock 455 278 262 minecraft:white_concrete
fill 456 278 240 456 278 242 minecraft:white_concrete
fill 456 278 256 459 278 257 minecraft:white_concrete
fill 457 278 238 457 278 240 minecraft:white_concrete
fill 457 278 243 460 278 244 minecraft:white_concrete
setblock 457 278 260 minecraft:white_concrete
fill 458 278 239 458 278 240 minecraft:white_concrete
fill 458 278 245 460 278 247 minecraft:white_concrete
fill 458 278 249 460 278 253 minecraft:white_concrete
fill 459 278 241 459 278 242 minecraft:white_concrete
fill 459 278 254 460 278 255 minecraft:white_concrete
setblock 461 278 247 minecraft:white_concrete
fill 461 278 249 461 278 251 minecraft:white_concrete
setblock 462 278 245 minecraft:blue_stained_glass
setblock 462 278 246 minecraft:black_stained_glass
fill 462 278 247 462 278 248 minecraft:blue_stained_glass
setblock 462 278 249 minecraft:black_stained_glass
fill 462 278 250 462 278 251 minecraft:blue_stained_glass
setblock 462 278 252 minecraft:black_stained_glass
setblock 462 278 253 minecraft:blue_stained_glass
setblock 465 278 255 minecraft:sea_lantern
setblock 465 278 259 minecraft:sea_lantern
fill 465 278 263 465 308 263 minecraft:black_concrete
setblock 423 279 233 minecraft:blue_concrete
setblock 423 279 257 minecraft:white_concrete
setblock 423 279 262 minecraft:pearlescent_froglight
fill 424 279 229 424 279 236 minecraft:light_blue_stained_glass
setblock 424 279 237 minecraft:sea_lantern
fill 424 279 238 424 279 247 minecraft:light_blue_stained_glass
setblock 424 279 248 minecraft:sea_lantern
fill 424 279 249 424 279 258 minecraft:light_blue_stained_glass
setblock 424 279 259 minecraft:sea_lantern
fill 424 279 260 424 279 269 minecraft:light_blue_stained_glass
fill 425 279 229 425 279 234 minecraft:light_blue_stained_glass
setblock 425 279 235 minecraft:sea_lantern
fill 425 279 236 425 279 245 minecraft:light_blue_stained_glass
setblock 425 279 246 minecraft:sea_lantern
fill 425 279 247 425 279 256 minecraft:light_blue_stained_glass
setblock 425 279 257 minecraft:sea_lantern
fill 425 279 258 425 279 267 minecraft:light_blue_stained_glass
setblock 425 279 268 minecraft:sea_lantern
fill 425 279 269 429 279 269 minecraft:light_blue_stained_glass
fill 426 279 228 426 308 228 minecraft:black_concrete
fill 426 279 229 426 279 232 minecraft:light_blue_stained_glass
setblock 426 279 233 minecraft:sea_lantern
fill 426 279 234 426 279 243 minecraft:light_blue_stained_glass
setblock 426 279 244 minecraft:sea_lantern
fill 426 279 245 426 279 254 minecraft:light_blue_stained_glass
setblock 426 279 255 minecraft:sea_lantern
fill 426 279 256 426 279 265 minecraft:light_blue_stained_glass
setblock 426 279 266 minecraft:sea_lantern
fill 426 279 267 430 279 268 minecraft:light_blue_stained_glass
fill 427 279 229 427 279 230 minecraft:light_blue_stained_glass
setblock 427 279 231 minecraft:sea_lantern
fill 427 279 232 427 279 241 minecraft:light_blue_stained_glass
setblock 427 279 242 minecraft:sea_lantern
fill 427 279 243 427 279 252 minecraft:light_blue_stained_glass
setblock 427 279 253 minecraft:sea_lantern
fill 427 279 254 427 279 263 minecraft:light_blue_stained_glass
setblock 427 279 264 minecraft:sea_lantern
fill 427 279 265 431 279 266 minecraft:light_blue_stained_glass
setblock 428 279 229 minecraft:sea_lantern
fill 428 279 230 428 279 239 minecraft:light_blue_stained_glass
setblock 428 279 240 minecraft:sea_lantern
fill 428 279 241 428 279 250 minecraft:light_blue_stained_glass
setblock 428 279 251 minecraft:sea_lantern
fill 428 279 252 428 279 261 minecraft:light_blue_stained_glass
setblock 428 279 262 minecraft:sea_lantern
fill 428 279 263 432 279 264 minecraft:light_blue_stained_glass
fill 429 279 229 429 279 237 minecraft:light_blue_stained_glass
setblock 429 279 238 minecraft:sea_lantern
fill 429 279 239 429 279 248 minecraft:light_blue_stained_glass
setblock 429 279 249 minecraft:sea_lantern
fill 429 279 250 429 279 259 minecraft:light_blue_stained_glass
setblock 429 279 260 minecraft:sea_lantern
fill 429 279 261 433 279 262 minecraft:light_blue_stained_glass
fill 430 279 229 430 279 235 minecraft:light_blue_stained_glass
setblock 430 279 236 minecraft:sea_lantern
fill 430 279 237 430 279 246 minecraft:light_blue_stained_glass
setblock 430 279 247 minecraft:sea_lantern
fill 430 279 248 430 279 257 minecraft:light_blue_stained_glass
setblock 430 279 258 minecraft:sea_lantern
fill 430 279 259 434 279 260 minecraft:light_blue_stained_glass
setblock 430 279 269 minecraft:sea_lantern
fill 430 279 270 430 302 270 minecraft:black_concrete
fill 431 279 229 431 279 233 minecraft:light_blue_stained_glass
setblock 431 279 234 minecraft:sea_lantern
fill 431 279 235 431 279 244 minecraft:light_blue_stained_glass
setblock 431 279 245 minecraft:sea_lantern
fill 431 279 246 431 279 255 minecraft:light_blue_stained_glass
setblock 431 279 256 minecraft:sea_lantern
fill 431 279 257 435 279 258 minecraft:light_blue_stained_glass
setblock 431 279 267 minecraft:sea_lantern
fill 431 279 268 435 279 269 minecraft:light_blue_stained_glass
fill 432 279 229 432 279 231 minecraft:light_blue_stained_glass
setblock 432 279 232 minecraft:sea_lantern
fill 432 279 233 432 279 242 minecraft:light_blue_stained_glass
setblock 432 279 243 minecraft:sea_lantern
fill 432 279 244 432 279 253 minecraft:light_blue_stained_glass
setblock 432 279 254 minecraft:sea_lantern
fill 432 279 255 436 279 256 minecraft:light_blue_stained_glass
setblock 432 279 265 minecraft:sea_lantern
fill 432 279 266 436 279 267 minecraft:light_blue_stained_glass
fill 433 279 229 438 279 229 minecraft:light_blue_stained_glass
setblock 433 279 230 minecraft:sea_lantern
fill 433 279 231 433 279 240 minecraft:light_blue_stained_glass
setblock 433 279 241 minecraft:sea_lantern
fill 433 279 242 433 279 251 minecraft:light_blue_stained_glass
setblock 433 279 252 minecraft:sea_lantern
fill 433 279 253 437 279 254 minecraft:light_blue_stained_glass
setblock 433 279 263 minecraft:sea_lantern
fill 433 279 264 437 279 265 minecraft:light_blue_stained_glass
fill 434 279 230 434 279 238 minecraft:light_blue_stained_glass
setblock 434 279 239 minecraft:sea_lantern
fill 434 279 240 434 279 249 minecraft:light_blue_stained_glass
setblock 434 279 250 minecraft:sea_lantern
fill 434 279 251 436 279 252 minecraft:light_blue_stained_glass
setblock 434 279 261 minecraft:sea_lantern
fill 434 279 262 438 279 263 minecraft:light_blue_stained_glass
fill 435 279 230 435 279 236 minecraft:light_blue_stained_glass
setblock 435 279 237 minecraft:sea_lantern
fill 435 279 238 435 279 247 minecraft:light_blue_stained_glass
setblock 435 279 248 minecraft:sea_lantern
fill 435 279 249 436 279 250 minecraft:light_blue_stained_glass
setblock 435 279 259 minecraft:sea_lantern
fill 435 279 260 439 279 261 minecraft:light_blue_stained_glass
fill 436 279 230 436 279 234 minecraft:light_blue_stained_glass
setblock 436 279 235 minecraft:sea_lantern
fill 436 279 236 436 279 245 minecraft:light_blue_stained_glass
setblock 436 279 246 minecraft:sea_lantern
fill 436 279 247 436 279 248 minecraft:light_blue_stained_glass
setblock 436 279 257 minecraft:sea_lantern
fill 436 279 258 440 279 259 minecraft:light_blue_stained_glass
setblock 436 279 268 minecraft:sea_lantern
fill 436 279 269 440 279 269 minecraft:light_blue_stained_glass
setblock 437 279 228 minecraft:white_concrete
fill 437 279 230 437 279 232 minecraft:light_blue_stained_glass
setblock 437 279 233 minecraft:sea_lantern
fill 437 279 234 437 279 243 minecraft:light_blue_stained_glass
setblock 437 279 244 minecraft:sea_lantern
fill 437 279 245 437 279 249 minecraft:lime_concrete
fill 437 279 250 437 279 251 minecraft:smooth_quartz
setblock 437 279 252 minecraft:light_blue_stained_glass
setblock 437 279 255 minecraft:sea_lantern
fill 437 279 256 441 279 257 minecraft:light_blue_stained_glass
setblock 437 279 266 minecraft:sea_lantern
fill 437 279 267 441 279 268 minecraft:light_blue_stained_glass
fill 438 279 230 443 279 230 minecraft:light_blue_stained_glass
setblock 438 279 231 minecraft:sea_lantern
fill 438 279 232 438 279 241 minecraft:light_blue_stained_glass
setblock 438 279 242 minecraft:sea_lantern
fill 438 279 243 438 279 245 minecraft:lime_concrete
fill 438 279 246 438 279 248 minecraft:sea_lantern
fill 438 279 249 438 279 251 minecraft:lime_concrete
fill 438 279 252 439 279 253 minecraft:smooth_quartz
fill 438 279 254 438 279 255 minecraft:light_blue_stained_glass
setblock 438 279 264 minecraft:sea_lantern
fill 438 279 265 442 279 266 minecraft:light_blue_stained_glass
setblock 439 279 229 minecraft:sea_lantern
fill 439 279 231 439 279 239 minecraft:light_blue_stained_glass
setblock 439 279 240 minecraft:sea_lantern
fill 439 279 241 439 279 242 minecraft:light_blue_stained_glass
fill 439 279 243 440 279 243 minecraft:lime_concrete
fill 439 279 244 439 279 246 minecraft:sea_lantern
fill 439 279 248 439 279 250 minecraft:sea_lantern
fill 439 279 251 440 279 251 minecraft:lime_concrete
fill 439 279 254 441 279 254 minecraft:smooth_quartz
setblock 439 279 255 minecraft:light_blue_stained_glass
setblock 439 279 262 minecraft:sea_lantern
fill 439 279 263 443 279 264 minecraft:light_blue_stained_glass
fill 440 279 229 449 279 229 minecraft:light_blue_stained_glass
fill 440 279 231 440 279 237 minecraft:light_blue_stained_glass
setblock 440 279 238 minecraft:sea_lantern
fill 440 279 239 443 279 241 minecraft:light_blue_stained_glass
fill 440 279 242 444 279 242 minecraft:lime_concrete
fill 440 279 244 441 279 244 minecraft:sea_lantern
fill 440 279 250 441 279 250 minecraft:sea_lantern
fill 440 279 252 444 279 252 minecraft:lime_concrete
setblock 440 279 253 minecraft:smooth_quartz
fill 440 279 255 448 279 255 minecraft:smooth_quartz
setblock 440 279 260 minecraft:sea_lantern
fill 440 279 261 444 279 262 minecraft:light_blue_stained_glass
fill 441 279 231 441 279 235 minecraft:light_blue_stained_glass
setblock 441 279 236 minecraft:sea_lantern
fill 441 279 237 445 279 238 minecraft:light_blue_stained_glass
fill 441 279 243 443 279 243 minecraft:sea_lantern
fill 441 279 251 443 279 251 minecraft:sea_lantern
fill 441 279 253 443 279 253 minecraft:light_gray_concrete
setblock 441 279 258 minecraft:sea_lantern
fill 441 279 259 445 279 260 minecraft:light_blue_stained_glass
setblock 441 279 269 minecraft:sea_lantern
fill 442 279 231 442 279 233 minecraft:light_blue_stained_glass
setblock 442 279 234 minecraft:sea_lantern
fill 442 279 235 446 279 236 minecraft:light_blue_stained_glass
fill 442 279 254 446 279 254 minecraft:light_gray_concrete
fill 442 279 256 446 279 256 minecraft:smooth_quartz
fill 442 279 257 446 279 258 minecraft:light_blue_stained_glass
setblock 442 279 267 minecraft:sea_lantern
fill 442 279 268 446 279 269 minecraft:light_blue_stained_glass
fill 443 279 231 448 279 231 minecraft:light_blue_stained_glass
setblock 443 279 232 minecraft:sea_lantern
fill 443 279 233 447 279 234 minecraft:light_blue_stained_glass
fill 443 279 244 445 279 244 minecraft:sea_lantern
fill 443 279 250 445 279 250 minecraft:sea_lantern
setblock 443 279 265 minecraft:sea_lantern
fill 443 279 266 447 279 267 minecraft:light_blue_stained_glass
setblock 444 279 230 minecraft:sea_lantern
setblock 444 279 232 minecraft:light_blue_stained_glass
fill 444 279 239 444 279 240 minecraft:light_blue_stained_glass
setblock 444 279 241 minecraft:sea_lantern
fill 444 279 243 446 279 243 minecraft:lime_concrete
fill 444 279 251 446 279 251 minecraft:lime_concrete
setblock 444 279 253 minecraft:smooth_quartz
setblock 444 279 263 minecraft:sea_lantern
fill 444 279 264 448 279 265 minecraft:light_blue_stained_glass
fill 445 279 230 454 279 230 minecraft:light_blue_stained_glass
fill 445 279 232 445 280 232 minecraft:iron_bars
setblock 445 279 239 minecraft:sea_lantern
fill 445 279 240 449 279 241 minecraft:light_blue_stained_glass
fill 445 279 242 446 279 242 minecraft:smooth_quartz
fill 445 279 245 445 279 246 minecraft:sea_lantern
fill 445 279 248 445 279 249 minecraft:sea_lantern
fill 445 279 252 446 279 252 minecraft:smooth_quartz
fill 445 279 253 447 279 253 minecraft:light_gray_concrete
setblock 445 279 261 minecraft:sea_lantern
fill 445 279 262 449 279 263 minecraft:light_blue_stained_glass
fill 446 279 232 453 279 232 minecraft:light_blue_stained_glass
setblock 446 279 237 minecraft:sea_lantern
fill 446 279 238 450 279 239 minecraft:light_blue_stained_glass
fill 446 279 244 446 279 245 minecraft:lime_concrete
fill 446 279 246 446 279 248 minecraft:sea_lantern
fill 446 279 249 446 279 250 minecraft:lime_concrete
setblock 446 279 259 minecraft:sea_lantern
fill 446 279 260 450 279 261 minecraft:light_blue_stained_glass
setblock 447 279 235 minecraft:sea_lantern
fill 447 279 236 451 279 237 minecraft:light_blue_stained_glass
fill 447 279 242 448 279 242 minecraft:light_blue_stained_glass
fill 447 279 243 448 279 244 minecraft:smooth_quartz
fill 447 279 245 447 279 249 minecraft:lime_concrete
fill 447 279 250 447 279 251 minecraft:smooth_quartz
fill 447 279 252 448 279 252 minecraft:light_gray_concrete
fill 447 279 254 449 279 254 minecraft:smooth_quartz
fill 447 279 256 452 279 256 minecraft:light_blue_stained_glass
setblock 447 279 257 minecraft:sea_lantern
fill 447 279 258 451 279 259 minecraft:light_blue_stained_glass
setblock 447 279 268 minecraft:sea_lantern
fill 447 279 269 451 279 269 minecraft:light_blue_stained_glass
setblock 448 279 228 minecraft:pearlescent_froglight
setblock 448 279 233 minecraft:sea_lantern
fill 448 279 234 452 279 235 minecraft:light_blue_stained_glass
fill 448 279 245 450 279 245 minecraft:smooth_quartz
fill 448 279 246 448 279 248 minecraft:light_gray_concrete
setblock 448 279 249 minecraft:smooth_quartz
fill 448 279 250 449 279 251 minecraft:light_gray_concrete
fill 448 279 253 450 279 253 minecraft:smooth_quartz
fill 448 279 257 457 279 257 minecraft:light_blue_stained_glass
setblock 448 279 266 minecraft:sea_lantern
fill 448 279 267 452 279 268 minecraft:light_blue_stained_glass
setblock 449 279 231 minecraft:sea_lantern
fill 449 279 233 458 279 233 minecraft:light_blue_stained_glass
setblock 449 279 242 minecraft:sea_lantern
fill 449 279 243 453 279 243 minecraft:light_blue_stained_glass
setblock 449 279 244 minecraft:smooth_quartz
fill 449 279 246 450 279 246 minecraft:smooth_quartz
fill 449 279 247 449 279 249 minecraft:light_gray_concrete
fill 449 279 252 450 279 252 minecraft:smooth_quartz
fill 449 279 255 458 279 255 minecraft:light_blue_stained_glass
setblock 449 279 264 minecraft:sea_lantern
fill 449 279 265 453 279 266 minecraft:light_blue_stained_glass
setblock 450 279 229 minecraft:sea_lantern
fill 450 279 231 459 279 231 minecraft:light_blue_stained_glass
setblock 450 279 240 minecraft:sea_lantern
fill 450 279 241 454 279 242 minecraft:light_blue_stained_glass
fill 450 279 244 458 279 244 minecraft:light_blue_stained_glass
fill 450 279 247 451 279 251 minecraft:smooth_quartz
fill 450 279 254 453 279 254 minecraft:light_blue_stained_glass
setblock 450 279 262 minecraft:sea_lantern
fill 450 279 263 454 279 264 minecraft:light_blue_stained_glass
fill 451 279 229 460 279 229 minecraft:light_blue_stained_glass
setblock 451 279 238 minecraft:sea_lantern
fill 451 279 239 455 279 240 minecraft:light_blue_stained_glass
fill 451 279 245 452 279 246 minecraft:light_blue_stained_glass
fill 451 279 252 454 279 253 minecraft:light_blue_stained_glass
setblock 451 279 260 minecraft:sea_lantern
fill 451 279 261 455 279 262 minecraft:light_blue_stained_glass
setblock 452 279 236 minecraft:sea_lantern
fill 452 279 237 456 279 238 minecraft:light_blue_stained_glass
setblock 452 279 247 minecraft:sea_lantern
fill 452 279 248 455 279 251 minecraft:light_blue_stained_glass
setblock 452 279 258 minecraft:sea_lantern
fill 452 279 259 456 279 260 minecraft:light_blue_stained_glass
setblock 452 279 269 minecraft:sea_lantern
setblock 453 279 234 minecraft:sea_lantern
fill 453 279 235 457 279 236 minecraft:light_blue_stained_glass
setblock 453 279 245 minecraft:sea_lantern
fill 453 279 246 457 279 247 minecraft:light_blue_stained_glass
setblock 453 279 256 minecraft:sea_lantern
fill 453 279 258 462 279 258 minecraft:light_blue_stained_glass
setblock 453 279 267 minecraft:sea_lantern
fill 453 279 268 457 279 269 minecraft:light_blue_stained_glass
setblock 454 279 232 minecraft:sea_lantern
fill 454 279 234 463 279 234 minecraft:light_blue_stained_glass
setblock 454 279 243 minecraft:sea_lantern
fill 454 279 245 463 279 245 minecraft:light_blue_stained_glass
setblock 454 279 254 minecraft:sea_lantern
fill 454 279 256 463 279 256 minecraft:light_blue_stained_glass
setblock 454 279 265 minecraft:sea_lantern
fill 454 279 266 458 279 267 minecraft:light_blue_stained_glass
setblock 455 279 230 minecraft:sea_lantern
fill 455 279 232 464 279 232 minecraft:light_blue_stained_glass
setblock 455 279 241 minecraft:sea_lantern
fill 455 279 242 459 279 243 minecraft:light_blue_stained_glass
setblock 455 279 252 minecraft:sea_lantern
fill 455 279 253 459 279 254 minecraft:light_blue_stained_glass
setblock 455 279 263 minecraft:sea_lantern
fill 455 279 264 459 279 265 minecraft:light_blue_stained_glass
fill 456 279 230 464 279 230 minecraft:light_blue_stained_glass
setblock 456 279 239 minecraft:sea_lantern
fill 456 279 240 460 279 241 minecraft:light_blue_stained_glass
fill 456 279 248 456 279 249 minecraft:light_blue_stained_glass
setblock 456 279 250 minecraft:sea_lantern
fill 456 279 251 460 279 252 minecraft:light_blue_stained_glass
setblock 456 279 261 minecraft:sea_lantern
fill 456 279 262 460 279 263 minecraft:light_blue_stained_glass
setblock 457 279 237 minecraft:sea_lantern
fill 457 279 238 461 279 239 minecraft:light_blue_stained_glass
setblock 457 279 248 minecraft:sea_lantern
fill 457 279 249 461 279 250 minecraft:light_blue_stained_glass
setblock 457 279 259 minecraft:sea_lantern
fill 457 279 260 461 279 261 minecraft:light_blue_stained_glass
setblock 458 279 235 minecraft:sea_lantern
fill 458 279 236 462 279 237 minecraft:light_blue_stained_glass
setblock 458 279 246 minecraft:sea_lantern
fill 458 279 247 462 279 248 minecraft:light_blue_stained_glass
setblock 458 279 257 minecraft:sea_lantern
fill 458 279 259 464 279 259 minecraft:light_blue_stained_glass
setblock 458 279 268 minecraft:sea_lantern
fill 458 279 269 462 279 269 minecraft:light_blue_stained_glass
setblock 459 279 233 minecraft:sea_lantern
fill 459 279 235 464 279 235 minecraft:light_blue_stained_glass
setblock 459 279 244 minecraft:sea_lantern
fill 459 279 246 464 279 246 minecraft:light_blue_stained_glass
setblock 459 279 255 minecraft:sea_lantern
fill 459 279 257 464 279 257 minecraft:light_blue_stained_glass
setblock 459 279 266 minecraft:sea_lantern
fill 459 279 267 463 279 268 minecraft:light_blue_stained_glass
setblock 460 279 231 minecraft:sea_lantern
fill 460 279 233 464 279 233 minecraft:light_blue_stained_glass
setblock 460 279 242 minecraft:sea_lantern
fill 460 279 243 464 279 244 minecraft:light_blue_stained_glass
setblock 460 279 253 minecraft:sea_lantern
fill 460 279 254 464 279 255 minecraft:light_blue_stained_glass
setblock 460 279 264 minecraft:sea_lantern
fill 460 279 265 464 279 266 minecraft:light_blue_stained_glass
setblock 461 279 229 minecraft:sea_lantern
fill 461 279 231 464 279 231 minecraft:light_blue_stained_glass
setblock 461 279 240 minecraft:sea_lantern
fill 461 279 241 464 279 242 minecraft:light_blue_stained_glass
setblock 461 279 251 minecraft:sea_lantern
fill 461 279 252 464 279 253 minecraft:light_blue_stained_glass
setblock 461 279 262 minecraft:sea_lantern
fill 461 279 263 464 279 264 minecraft:light_blue_stained_glass
fill 462 279 229 464 279 229 minecraft:light_blue_stained_glass
setblock 462 279 238 minecraft:sea_lantern
fill 462 279 239 464 279 240 minecraft:light_blue_stained_glass
setblock 462 279 249 minecraft:sea_lantern
fill 462 279 250 464 279 251 minecraft:light_blue_stained_glass
setblock 462 279 260 minecraft:sea_lantern
fill 462 279 261 464 279 262 minecraft:light_blue_stained_glass
setblock 463 279 236 minecraft:sea_lantern
fill 463 279 237 464 279 238 minecraft:light_blue_stained_glass
setblock 463 279 247 minecraft:sea_lantern
fill 463 279 248 464 279 249 minecraft:light_blue_stained_glass
setblock 463 279 258 minecraft:sea_lantern
fill 463 279 260 464 279 260 minecraft:light_blue_stained_glass
setblock 463 279 269 minecraft:sea_lantern
setblock 464 279 234 minecraft:sea_lantern
setblock 464 279 236 minecraft:light_blue_stained_glass
setblock 464 279 245 minecraft:sea_lantern
setblock 464 279 247 minecraft:light_blue_stained_glass
setblock 464 279 256 minecraft:sea_lantern
setblock 464 279 258 minecraft:light_blue_stained_glass
setblock 464 279 267 minecraft:sea_lantern
fill 464 279 268 464 279 269 minecraft:light_blue_stained_glass
setblock 465 279 253 minecraft:sea_lantern
fill 465 279 255 465 308 255 minecraft:black_concrete
fill 465 279 259 465 308 259 minecraft:black_concrete
fill 423 280 233 423 308 233 minecraft:black_concrete
fill 423 280 257 423 308 257 minecraft:black_concrete
fill 423 280 262 423 308 262 minecraft:black_concrete
setblock 431 280 270 minecraft:magenta_terracotta
fill 437 280 228 437 295 228 minecraft:black_concrete
fill 448 280 228 448 286 228 minecraft:black_concrete
fill 465 280 253 465 301 253 minecraft:black_concrete
setblock 423 281 247 minecraft:ochre_froglight
setblock 423 281 266 minecraft:ochre_froglight
fill 431 281 270 431 285 270 minecraft:black_concrete
setblock 434 281 270 minecraft:white_concrete
setblock 461 281 270 minecraft:pearlescent_froglight
setblock 423 282 236 minecraft:pearlescent_froglight
fill 423 282 247 423 293 247 minecraft:black_concrete
setblock 423 282 263 minecraft:ochre_froglight
fill 423 282 266 423 308 266 minecraft:black_concrete
setblock 425 282 270 minecraft:sea_lantern
setblock 426 282 231 minecraft:light[level=15]
setblock 426 282 238 minecraft:light[level=12]
setblock 426 282 239 minecraft:light[level=15]
setblock 426 282 245 minecraft:light[level=12]
setblock 426 282 247 minecraft:light[level=15]
setblock 426 282 252 minecraft:light[level=12]
setblock 426 282 255 minecraft:light[level=15]
setblock 426 282 259 minecraft:light[level=12]
setblock 426 282 263 minecraft:light[level=15]
setblock 426 282 266 minecraft:light[level=12]
setblock 433 282 231 minecraft:light[level=12]
setblock 433 282 238 minecraft:light[level=12]
setblock 433 282 245 minecraft:light[level=12]
setblock 433 282 252 minecraft:light[level=12]
setblock 433 282 259 minecraft:light[level=12]
setblock 433 282 266 minecraft:light[level=12]
setblock 434 282 231 minecraft:light[level=15]
setblock 434 282 239 minecraft:light[level=15]
setblock 434 282 247 minecraft:light[level=15]
setblock 434 282 255 minecraft:light[level=15]
setblock 434 282 263 minecraft:light[level=15]
fill 434 282 270 434 308 270 minecraft:black_concrete
setblock 440 282 231 minecraft:light[level=12]
setblock 440 282 238 minecraft:light[level=12]
setblock 440 282 245 minecraft:light[level=12]
setblock 440 282 252 minecraft:light[level=12]
setblock 440 282 259 minecraft:light[level=12]
setblock 440 282 266 minecraft:light[level=12]
setblock 442 282 231 minecraft:light[level=15]
setblock 442 282 239 minecraft:light[level=15]
setblock 442 282 255 minecraft:light[level=15]
setblock 442 282 263 minecraft:light[level=15]
setblock 447 282 231 minecraft:light[level=12]
setblock 447 282 238 minecraft:light[level=12]
setblock 447 282 245 minecraft:light[level=12]
setblock 447 282 252 minecraft:light[level=12]
setblock 447 282 259 minecraft:light[level=12]
setblock 447 282 266 minecraft:light[level=12]
setblock 450 282 231 minecraft:light[level=15]
setblock 450 282 239 minecraft:light[level=15]
setblock 450 282 247 minecraft:light[level=15]
setblock 450 282 255 minecraft:light[level=15]
setblock 450 282 263 minecraft:light[level=15]
setblock 454 282 231 minecraft:light[level=12]
setblock 454 282 238 minecraft:light[level=12]
setblock 454 282 245 minecraft:light[level=12]
setblock 454 282 252 minecraft:light[level=12]
setblock 454 282 259 minecraft:light[level=12]
setblock 454 282 266 minecraft:light[level=12]
setblock 458 282 231 minecraft:light[level=15]
setblock 458 282 239 minecraft:light[level=15]
setblock 458 282 247 minecraft:light[level=15]
setblock 458 282 255 minecraft:light[level=15]
setblock 458 282 263 minecraft:light[level=15]
setblock 460 282 228 minecraft:purple_concrete
setblock 461 282 231 minecraft:light[level=12]
setblock 461 282 238 minecraft:light[level=12]
setblock 461 282 245 minecraft:light[level=12]
setblock 461 282 252 minecraft:light[level=12]
setblock 461 282 259 minecraft:light[level=12]
setblock 461 282 266 minecraft:light[level=12]
setblock 461 282 270 minecraft:sea_lantern
setblock 465 282 240 minecraft:white_concrete
setblock 465 282 269 minecraft:purple_concrete
fill 423 283 236 423 294 236 minecraft:black_concrete
setblock 423 283 237 minecraft:pearlescent_froglight
fill 423 283 263 423 302 263 minecraft:black_concrete
fill 425 283 270 425 308 270 minecraft:black_concrete
setblock 436 283 270 minecraft:purple_concrete
fill 460 283 228 460 308 228 minecraft:black_concrete
fill 461 283 270 461 308 270 minecraft:black_concrete
fill 465 283 240 465 307 240 minecraft:black_concrete
fill 465 283 269 465 292 269 minecraft:black_concrete
fill 423 284 237 423 301 237 minecraft:black_concrete
setblock 432 284 270 minecraft:white_concrete
fill 433 284 270 433 305 270 minecraft:black_concrete
fill 436 284 270 436 308 270 minecraft:black_concrete
setblock 452 284 270 minecraft:pearlescent_froglight
setblock 465 284 242 minecraft:white_concrete
setblock 465 284 245 minecraft:sea_lantern
setblock 432 285 270 minecraft:black_concrete
setblock 438 285 270 minecraft:ochre_froglight
setblock 444 285 270 minecraft:sea_lantern
fill 452 285 270 452 308 270 minecraft:black_concrete
setblock 465 285 233 minecraft:pearlescent_froglight
fill 465 285 242 465 308 242 minecraft:black_concrete
fill 465 285 245 465 308 245 minecraft:black_concrete
setblock 423 286 268 minecraft:blue_concrete
setblock 431 286 270 minecraft:sea_lantern
setblock 432 286 270 minecraft:white_concrete
fill 438 286 270 438 308 270 minecraft:black_concrete
fill 444 286 270 444 287 270 minecraft:black_concrete
fill 465 286 233 465 293 233 minecraft:black_concrete
setblock 465 286 246 minecraft:purple_terracotta
fill 423 287 268 423 296 268 minecraft:black_concrete
setblock 427 287 228 minecraft:pearlescent_froglight
fill 431 287 270 432 288 270 minecraft:black_concrete
setblock 433 287 228 minecraft:pearlescent_froglight
setblock 448 287 228 minecraft:ochre_froglight
fill 461 287 256 462 288 256 minecraft:gray_concrete
fill 465 287 246 465 308 246 minecraft:black_concrete
setblock 423 288 249 minecraft:ochre_froglight
setblock 426 288 231 minecraft:light[level=12]
setblock 426 288 238 minecraft:light[level=12]
setblock 426 288 245 minecraft:light[level=12]
setblock 426 288 252 minecraft:light[level=12]
setblock 426 288 259 minecraft:light[level=12]
setblock 426 288 266 minecraft:light[level=12]
fill 427 288 228 427 308 228 minecraft:black_concrete
setblock 427 288 270 minecraft:white_concrete
fill 433 288 228 433 307 228 minecraft:black_concrete
setblock 433 288 231 minecraft:light[level=12]
setblock 433 288 238 minecraft:light[level=12]
setblock 433 288 245 minecraft:light[level=12]
setblock 433 288 252 minecraft:light[level=12]
setblock 433 288 259 minecraft:light[level=12]
setblock 433 288 266 minecraft:light[level=12]
fill 437 288 239 437 289 239 minecraft:pearlescent_froglight
setblock 440 288 231 minecraft:light[level=12]
setblock 440 288 238 minecraft:light[level=12]
setblock 440 288 245 minecraft:light[level=12]
setblock 440 288 252 minecraft:light[level=12]
setblock 440 288 259 minecraft:light[level=12]
setblock 440 288 266 minecraft:light[level=12]
setblock 444 288 270 minecraft:sea_lantern
setblock 447 288 231 minecraft:light[level=12]
setblock 447 288 238 minecraft:light[level=12]
setblock 447 288 245 minecraft:light[level=12]
setblock 447 288 252 minecraft:light[level=12]
setblock 447 288 259 minecraft:light[level=12]
setblock 447 288 266 minecraft:light[level=12]
fill 448 288 228 448 308 228 minecraft:black_concrete
fill 450 288 257 450 289 257 minecraft:gray_concrete
setblock 454 288 231 minecraft:light[level=12]
setblock 454 288 238 minecraft:light[level=12]
setblock 454 288 245 minecraft:light[level=12]
setblock 454 288 252 minecraft:light[level=12]
setblock 454 288 259 minecraft:light[level=12]
setblock 454 288 266 minecraft:light[level=12]
setblock 461 288 231 minecraft:light[level=12]
setblock 461 288 238 minecraft:light[level=12]
setblock 461 288 245 minecraft:light[level=12]
setblock 461 288 252 minecraft:light[level=12]
setblock 461 288 259 minecraft:light[level=12]
setblock 461 288 266 minecraft:light[level=12]
fill 423 289 249 423 308 249 minecraft:black_concrete
setblock 426 289 231 minecraft:light[level=15]
setblock 426 289 239 minecraft:light[level=15]
setblock 426 289 247 minecraft:light[level=15]
setblock 426 289 255 minecraft:light[level=15]
setblock 426 289 263 minecraft:light[level=15]
fill 427 289 270 427 308 270 minecraft:black_concrete
fill 431 289 270 431 308 270 minecraft:black_concrete
setblock 432 289 270 minecraft:pearlescent_froglight
setblock 434 289 231 minecraft:light[level=15]
setblock 434 289 239 minecraft:light[level=15]
setblock 434 289 247 minecraft:light[level=15]
setblock 434 289 255 minecraft:light[level=15]
setblock 434 289 263 minecraft:light[level=15]
setblock 440 289 228 minecraft:purple_concrete
setblock 442 289 231 minecraft:light[level=15]
setblock 442 289 239 minecraft:light[level=15]
setblock 442 289 255 minecraft:light[level=15]
setblock 442 289 263 minecraft:light[level=15]
fill 444 289 270 444 290 270 minecraft:black_concrete
setblock 450 289 231 minecraft:light[level=15]
setblock 450 289 239 minecraft:light[level=15]
setblock 450 289 247 minecraft:light[level=15]
setblock 450 289 255 minecraft:light[level=15]
setblock 450 289 263 minecraft:light[level=15]
setblock 458 289 231 minecraft:light[level=15]
setblock 458 289 239 minecraft:light[level=15]
setblock 458 289 247 minecraft:light[level=15]
setblock 458 289 255 minecraft:light[level=15]
setblock 458 289 263 minecraft:light[level=15]
setblock 423 290 229 minecraft:ochre_froglight
setblock 423 290 253 minecraft:pearlescent_froglight
fill 432 290 270 432 308 270 minecraft:black_concrete
fill 437 290 239 437 296 239 minecraft:gray_concrete
fill 440 290 228 440 308 228 minecraft:black_concrete
setblock 454 290 270 minecraft:purple_terracotta
fill 423 291 229 423 302 229 minecraft:black_concrete
setblock 423 291 240 minecraft:pearlescent_froglight
fill 423 291 253 423 308 253 minecraft:black_concrete
fill 436 291 239 436 296 240 minecraft:gray_concrete
fill 437 291 240 437 296 240 minecraft:gray_concrete
setblock 440 291 270 minecraft:magenta_terracotta
setblock 444 291 270 minecraft:pearlescent_froglight
fill 454 291 270 454 308 270 minecraft:black_concrete
setblock 465 291 235 minecraft:white_concrete
fill 423 292 240 423 302 240 minecraft:black_concrete
fill 436 292 238 437 296 238 minecraft:gray_concrete
fill 438 292 239 438 296 239 minecraft:gray_concrete
setblock 439 292 228 minecraft:blue_concrete
setblock 440 292 270 minecraft:pearlescent_froglight
fill 444 292 270 444 308 270 minecraft:black_concrete
setblock 455 292 228 minecraft:white_concrete
fill 465 292 235 465 308 235 minecraft:black_concrete
setblock 423 293 256 minecraft:ochre_froglight
setblock 425 293 228 minecraft:pearlescent_froglight
setblock 434 293 228 minecraft:pearlescent_froglight
fill 435 293 239 435 296 240 minecraft:gray_concrete
fill 436 293 241 437 296 241 minecraft:gray_concrete
setblock 438 293 228 minecraft:ochre_froglight
fill 438 293 240 438 296 240 minecraft:gray_concrete
fill 439 293 228 439 308 228 minecraft:black_concrete
fill 440 293 270 440 308 270 minecraft:black_concrete
setblock 450 293 270 minecraft:sea_lantern
fill 455 293 228 455 308 228 minecraft:black_concrete
setblock 465 293 244 minecraft:purple_concrete
setblock 465 293 269 minecraft:purple_terracotta
setblock 423 294 247 minecraft:sea_lantern
fill 423 294 256 423 308 256 minecraft:black_concrete
fill 425 294 228 425 308 228 minecraft:black_concrete
setblock 426 294 231 minecraft:light[level=12]
setblock 426 294 238 minecraft:light[level=12]
setblock 426 294 245 minecraft:light[level=12]
setblock 426 294 252 minecraft:light[level=12]
setblock 426 294 259 minecraft:light[level=12]
setblock 426 294 266 minecraft:light[level=12]
setblock 433 294 231 minecraft:light[level=12]
setblock 433 294 238 minecraft:light[level=12]
setblock 433 294 245 minecraft:light[level=12]
setblock 433 294 252 minecraft:light[level=12]
setblock 433 294 259 minecraft:light[level=12]
setblock 433 294 266 minecraft:light[level=12]
fill 434 294 228 434 308 228 minecraft:black_concrete
fill 435 294 238 435 296 238 minecraft:gray_concrete
fill 435 294 241 435 296 241 minecraft:gray_concrete
fill 437 294 237 437 296 237 minecraft:gray_concrete
fill 438 294 228 438 308 228 minecraft:black_concrete
fill 438 294 238 438 296 238 minecraft:gray_concrete
fill 438 294 241 438 296 241 minecraft:gray_concrete
setblock 440 294 231 minecraft:light[level=12]
setblock 440 294 238 minecraft:light[level=12]
setblock 440 294 245 minecraft:light[level=12]
setblock 440 294 252 minecraft:light[level=12]
setblock 440 294 259 minecraft:light[level=12]
setblock 440 294 266 minecraft:light[level=12]
setblock 447 294 231 minecraft:light[level=12]
setblock 447 294 238 minecraft:light[level=12]
setblock 447 294 245 minecraft:light[level=12]
setblock 447 294 252 minecraft:light[level=12]
setblock 447 294 259 minecraft:light[level=12]
setblock 447 294 266 minecraft:light[level=12]
fill 450 294 270 450 308 270 minecraft:black_concrete
setblock 453 294 270 minecraft:white_concrete
setblock 454 294 231 minecraft:light[level=12]
setblock 454 294 238 minecraft:light[level=12]
setblock 454 294 245 minecraft:light[level=12]
setblock 454 294 252 minecraft:light[level=12]
setblock 454 294 259 minecraft:light[level=12]
setblock 454 294 266 minecraft:light[level=12]
setblock 457 294 228 minecraft:white_concrete
setblock 461 294 231 minecraft:light[level=12]
setblock 461 294 238 minecraft:light[level=12]
setblock 461 294 245 minecraft:light[level=12]
setblock 461 294 252 minecraft:light[level=12]
setblock 461 294 259 minecraft:light[level=12]
setblock 461 294 266 minecraft:light[level=12]
setblock 465 294 233 minecraft:pearlescent_froglight
fill 465 294 244 465 308 244 minecraft:black_concrete
setblock 465 294 267 minecraft:sea_lantern
fill 465 294 269 465 304 269 minecraft:black_concrete
setblock 423 295 236 minecraft:white_concrete
fill 423 295 247 423 308 247 minecraft:black_concrete
fill 434 295 239 434 296 240 minecraft:gray_concrete
fill 435 295 237 436 296 237 minecraft:gray_concrete
fill 436 295 242 437 296 242 minecraft:gray_concrete
fill 438 295 237 438 296 237 minecraft:gray_concrete
fill 439 295 238 439 296 240 minecraft:gray_concrete
fill 453 295 270 453 308 270 minecraft:black_concrete
fill 457 295 228 457 308 228 minecraft:black_concrete
fill 465 295 233 465 303 233 minecraft:black_concrete
setblock 465 295 260 minecraft:blue_concrete
fill 465 295 267 465 308 267 minecraft:black_concrete
fill 423 296 236 423 302 236 minecraft:black_concrete
setblock 423 296 246 minecraft:pearlescent_froglight
setblock 426 296 231 minecraft:light[level=15]
setblock 426 296 239 minecraft:light[level=15]
setblock 426 296 247 minecraft:light[level=15]
setblock 426 296 255 minecraft:light[level=15]
setblock 426 296 263 minecraft:light[level=15]
setblock 434 296 231 minecraft:light[level=15]
setblock 434 296 238 minecraft:gray_concrete
setblock 434 296 241 minecraft:gray_concrete
setblock 434 296 247 minecraft:light[level=15]
setblock 434 296 255 minecraft:light[level=15]
setblock 434 296 263 minecraft:light[level=15]
setblock 435 296 242 minecraft:gray_concrete
fill 435 296 251 435 297 251 minecraft:gray_concrete
setblock 435 296 270 minecraft:ochre_froglight
setblock 437 296 228 minecraft:sea_lantern
setblock 438 296 242 minecraft:gray_concrete
setblock 439 296 241 minecraft:gray_concrete
setblock 442 296 231 minecraft:light[level=15]
setblock 442 296 239 minecraft:light[level=15]
setblock 442 296 255 minecraft:light[level=15]
setblock 442 296 263 minecraft:light[level=15]
setblock 443 296 228 minecraft:sea_lantern
setblock 450 296 231 minecraft:light[level=15]
setblock 450 296 239 minecraft:light[level=15]
setblock 450 296 247 minecraft:light[level=15]
setblock 450 296 255 minecraft:light[level=15]
setblock 450 296 263 minecraft:light[level=15]
setblock 458 296 231 minecraft:light[level=15]
setblock 458 296 239 minecraft:light[level=15]
setblock 458 296 247 minecraft:light[level=15]
setblock 458 296 255 minecraft:light[level=15]
setblock 458 296 263 minecraft:light[level=15]
setblock 465 296 243 minecraft:ochre_froglight
fill 465 296 260 465 300 260 minecraft:black_concrete
setblock 423 297 235 minecraft:white_concrete
fill 423 297 246 423 308 246 minecraft:black_concrete
setblock 423 297 264 minecraft:sea_lantern
setblock 423 297 268 minecraft:sea_lantern
fill 435 297 270 435 308 270 minecraft:black_concrete
fill 436 297 239 437 298 240 minecraft:pearlescent_froglight
fill 437 297 228 437 308 228 minecraft:black_concrete
fill 443 297 228 443 308 228 minecraft:black_concrete
setblock 445 297 228 minecraft:ochre_froglight
fill 465 297 243 465 308 243 minecraft:black_concrete
fill 423 298 235 423 308 235 minecraft:black_concrete
fill 423 298 264 423 308 264 minecraft:black_concrete
fill 423 298 268 423 299 268 minecraft:black_concrete
setblock 437 298 270 minecraft:magenta_terracotta
setblock 439 298 270 minecraft:sea_lantern
fill 445 298 228 445 308 228 minecraft:black_concrete
setblock 445 298 270 minecraft:ochre_froglight
setblock 454 298 228 minecraft:pearlescent_froglight
fill 436 299 239 437 299 239 minecraft:pearlescent_froglight
fill 437 299 270 437 308 270 minecraft:black_concrete
fill 439 299 270 439 308 270 minecraft:black_concrete
setblock 442 299 270 minecraft:purple_concrete
fill 445 299 270 445 308 270 minecraft:black_concrete
fill 454 299 228 454 308 228 minecraft:black_concrete
setblock 457 299 270 minecraft:ochre_froglight
setblock 423 300 244 minecraft:sea_lantern
setblock 423 300 268 minecraft:white_concrete
setblock 426 300 231 minecraft:light[level=12]
setblock 426 300 238 minecraft:light[level=12]
setblock 426 300 245 minecraft:light[level=12]
setblock 426 300 252 minecraft:light[level=12]
setblock 426 300 259 minecraft:light[level=12]
setblock 426 300 266 minecraft:light[level=12]
setblock 433 300 231 minecraft:light[level=12]
setblock 433 300 238 minecraft:light[level=12]
setblock 433 300 245 minecraft:light[level=12]
setblock 433 300 252 minecraft:light[level=12]
setblock 433 300 259 minecraft:light[level=12]
setblock 433 300 266 minecraft:light[level=12]
setblock 435 300 228 minecraft:white_concrete
setblock 437 300 239 minecraft:pearlescent_froglight
setblock 440 300 231 minecraft:light[level=12]
setblock 440 300 238 minecraft:light[level=12]
setblock 440 300 245 minecraft:light[level=12]
setblock 440 300 252 minecraft:light[level=12]
setblock 440 300 259 minecraft:light[level=12]
setblock 440 300 266 minecraft:light[level=12]
fill 442 300 270 442 308 270 minecraft:black_concrete
setblock 447 300 231 minecraft:light[level=12]
setblock 447 300 238 minecraft:light[level=12]
setblock 447 300 245 minecraft:light[level=12]
setblock 447 300 252 minecraft:light[level=12]
setblock 447 300 259 minecraft:light[level=12]
setblock 447 300 266 minecraft:light[level=12]
setblock 454 300 231 minecraft:light[level=12]
setblock 454 300 238 minecraft:light[level=12]
setblock 454 300 245 minecraft:light[level=12]
setblock 454 300 252 minecraft:light[level=12]
setblock 454 300 259 minecraft:light[level=12]
setblock 454 300 266 minecraft:light[level=12]
fill 457 300 270 457 301 270 minecraft:black_concrete
setblock 461 300 231 minecraft:light[level=12]
setblock 461 300 238 minecraft:light[level=12]
setblock 461 300 245 minecraft:light[level=12]
setblock 461 300 252 minecraft:light[level=12]
setblock 461 300 259 minecraft:light[level=12]
setblock 461 300 266 minecraft:light[level=12]
setblock 465 300 232 minecraft:magenta_terracotta
setblock 465 300 249 minecraft:pearlescent_froglight
fill 423 301 244 423 308 244 minecraft:black_concrete
setblock 423 301 265 minecraft:pearlescent_froglight
fill 423 301 268 423 308 268 minecraft:black_concrete
fill 435 301 228 435 308 228 minecraft:black_concrete
fill 465 301 232 465 308 232 minecraft:black_concrete
fill 465 301 249 465 308 249 minecraft:black_concrete
setblock 465 301 260 minecraft:white_concrete
setblock 423 302 237 minecraft:white_concrete
fill 423 302 265 423 308 265 minecraft:black_concrete
setblock 457 302 270 minecraft:ochre_froglight
setblock 458 302 228 minecraft:white_concrete
setblock 465 302 253 minecraft:sea_lantern
setblock 465 302 258 minecraft:blue_concrete
fill 465 302 260 465 308 260 minecraft:black_concrete
setblock 423 303 229 minecraft:magenta_terracotta
setblock 423 303 236 minecraft:ochre_froglight
fill 423 303 237 423 308 237 minecraft:black_concrete
setblock 423 303 240 minecraft:white_concrete
setblock 423 303 263 minecraft:purple_concrete
setblock 426 303 231 minecraft:light[level=15]
setblock 426 303 239 minecraft:light[level=15]
setblock 426 303 247 minecraft:light[level=15]
setblock 426 303 255 minecraft:light[level=15]
setblock 426 303 263 minecraft:light[level=15]
setblock 430 303 270 minecraft:white_concrete
setblock 434 303 231 minecraft:light[level=15]
setblock 434 303 239 minecraft:light[level=15]
setblock 434 303 247 minecraft:light[level=15]
setblock 434 303 255 minecraft:light[level=15]
setblock 434 303 263 minecraft:light[level=15]
setblock 442 303 231 minecraft:light[level=15]
setblock 442 303 239 minecraft:light[level=15]
setblock 442 303 247 minecraft:light[level=15]
setblock 442 303 255 minecraft:light[level=15]
setblock 442 303 263 minecraft:light[level=15]
setblock 450 303 231 minecraft:light[level=15]
setblock 450 303 239 minecraft:light[level=15]
setblock 450 303 247 minecraft:light[level=15]
setblock 450 303 255 minecraft:light[level=15]
setblock 450 303 263 minecraft:light[level=15]
fill 457 303 270 457 304 270 minecraft:black_concrete
fill 458 303 228 458 308 228 minecraft:black_concrete
setblock 458 303 231 minecraft:light[level=15]
setblock 458 303 239 minecraft:light[level=15]
setblock 458 303 247 minecraft:light[level=15]
setblock 458 303 255 minecraft:light[level=15]
setblock 458 303 263 minecraft:light[level=15]
fill 465 303 253 465 308 253 minecraft:black_concrete
fill 465 303 258 465 308 258 minecraft:black_concrete
fill 423 304 229 423 308 229 minecraft:black_concrete
fill 423 304 236 423 308 236 minecraft:black_concrete
fill 423 304 240 423 306 240 minecraft:black_concrete
fill 423 304 263 423 308 263 minecraft:black_concrete
fill 430 304 270 430 308 270 minecraft:black_concrete
setblock 444 304 228 minecraft:purple_concrete
setblock 465 304 233 minecraft:sea_lantern
setblock 465 304 241 minecraft:sea_lantern
fill 423 305 251 423 308 251 minecraft:black_concrete
setblock 423 305 252 minecraft:sea_lantern
setblock 444 305 228 minecraft:ochre_froglight
setblock 457 305 270 minecraft:pearlescent_froglight
fill 465 305 233 465 308 233 minecraft:black_concrete
fill 465 305 241 465 308 241 minecraft:black_concrete
setblock 465 305 269 minecraft:pearlescent_froglight
fill 423 306 252 423 308 252 minecraft:black_concrete
setblock 433 306 270 minecraft:ochre_froglight
fill 444 306 228 444 308 228 minecraft:black_concrete
fill 457 306 270 457 308 270 minecraft:black_concrete
setblock 465 306 238 minecraft:ochre_froglight
setblock 465 306 248 minecraft:purple_concrete
fill 465 306 269 465 308 269 minecraft:black_concrete
setblock 423 307 240 minecraft:white_concrete
setblock 423 307 248 minecraft:purple_concrete
fill 433 307 270 433 308 270 minecraft:black_concrete
fill 465 307 238 465 308 238 minecraft:black_concrete
fill 465 307 248 465 308 248 minecraft:black_concrete
setblock 423 308 240 minecraft:black_concrete
setblock 423 308 248 minecraft:black_concrete
setblock 433 308 228 minecraft:ochre_froglight
setblock 436 308 228 minecraft:white_concrete
setblock 458 308 270 minecraft:purple_concrete
setblock 465 308 240 minecraft:magenta_terracotta
setblock 465 308 268 minecraft:pearlescent_froglight
