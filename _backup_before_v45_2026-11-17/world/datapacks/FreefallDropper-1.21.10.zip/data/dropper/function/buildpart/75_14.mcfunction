setblock 143 299 345 minecraft:dark_prismarine
fill 143 299 346 143 300 346 minecraft:blue_terracotta
setblock 143 299 349 minecraft:blue_terracotta
setblock 143 299 361 minecraft:blue_terracotta
setblock 144 299 325 minecraft:light[level=12]
fill 144 299 327 144 300 327 minecraft:dark_prismarine
fill 144 299 329 144 300 329 minecraft:dark_prismarine
fill 144 299 331 144 300 331 minecraft:dark_prismarine
fill 144 299 333 144 300 333 minecraft:dark_prismarine
fill 144 299 335 144 300 335 minecraft:dark_prismarine
fill 144 299 337 144 300 337 minecraft:dark_prismarine
fill 144 299 339 144 300 339 minecraft:dark_prismarine
setblock 144 299 344 minecraft:dark_prismarine
fill 144 299 345 144 300 345 minecraft:blue_terracotta
fill 144 299 347 144 300 347 minecraft:blue_terracotta
setblock 144 299 353 minecraft:light[level=12]
setblock 144 299 360 minecraft:light[level=12]
setblock 145 299 322 minecraft:light_blue_wool
setblock 145 299 323 minecraft:dark_prismarine
fill 145 299 328 145 300 328 minecraft:dark_prismarine
fill 145 299 330 145 300 330 minecraft:dark_prismarine
fill 145 299 332 145 300 332 minecraft:dark_prismarine
fill 145 299 334 145 300 334 minecraft:dark_prismarine
fill 145 299 336 145 300 336 minecraft:dark_prismarine
fill 145 299 338 145 300 338 minecraft:dark_prismarine
setblock 145 299 363 minecraft:dark_prismarine
fill 146 299 323 146 300 323 minecraft:blue_terracotta
fill 146 299 327 146 300 327 minecraft:dark_prismarine
fill 146 299 329 146 300 329 minecraft:dark_prismarine
fill 146 299 331 146 300 331 minecraft:dark_prismarine
fill 146 299 333 146 300 333 minecraft:dark_prismarine
fill 146 299 335 146 300 335 minecraft:dark_prismarine
fill 146 299 337 146 300 337 minecraft:dark_prismarine
fill 146 299 339 146 300 339 minecraft:dark_prismarine
setblock 146 299 362 minecraft:dark_prismarine
fill 146 299 363 146 300 363 minecraft:blue_terracotta
fill 147 299 328 147 300 328 minecraft:dark_prismarine
fill 147 299 330 147 300 330 minecraft:dark_prismarine
fill 147 299 332 147 300 332 minecraft:dark_prismarine
fill 147 299 334 147 300 334 minecraft:dark_prismarine
fill 147 299 336 147 300 336 minecraft:dark_prismarine
fill 147 299 338 147 300 338 minecraft:dark_prismarine
fill 147 299 362 147 300 362 minecraft:blue_terracotta
setblock 149 299 324 minecraft:dark_prismarine
setblock 150 299 323 minecraft:dark_prismarine
fill 150 299 324 150 300 324 minecraft:blue_terracotta
setblock 150 299 363 minecraft:dark_prismarine
fill 151 299 323 151 300 323 minecraft:blue_terracotta
setblock 151 299 325 minecraft:light[level=12]
setblock 151 299 332 minecraft:light[level=12]
setblock 151 299 339 minecraft:light[level=12]
setblock 151 299 346 minecraft:light[level=12]
setblock 151 299 353 minecraft:light[level=12]
setblock 151 299 360 minecraft:light[level=12]
setblock 151 299 362 minecraft:dark_prismarine
fill 151 299 363 151 300 363 minecraft:blue_terracotta
setblock 155 299 323 minecraft:dark_prismarine
setblock 155 299 346 minecraft:purple_concrete
fill 156 299 323 159 299 323 minecraft:blue_terracotta
setblock 158 299 325 minecraft:light[level=12]
setblock 158 299 339 minecraft:light[level=12]
setblock 158 299 346 minecraft:light[level=12]
setblock 158 299 353 minecraft:light[level=12]
setblock 158 299 360 minecraft:light[level=12]
setblock 160 299 323 minecraft:dark_prismarine
fill 161 299 323 164 299 323 minecraft:blue_terracotta
setblock 161 299 363 minecraft:purple_concrete
fill 162 299 324 163 299 324 minecraft:blue_terracotta
fill 163 299 363 164 299 363 minecraft:blue_terracotta
setblock 164 299 324 minecraft:dark_prismarine
setblock 165 299 323 minecraft:dark_prismarine
fill 165 299 324 165 300 324 minecraft:blue_terracotta
setblock 165 299 332 minecraft:light[level=12]
setblock 165 299 339 minecraft:light[level=12]
setblock 165 299 346 minecraft:light[level=12]
setblock 165 299 353 minecraft:light[level=12]
setblock 165 299 360 minecraft:light[level=12]
setblock 165 299 363 minecraft:dark_prismarine
fill 166 299 323 166 300 323 minecraft:blue_terracotta
setblock 166 299 362 minecraft:dark_prismarine
fill 166 299 363 166 300 363 minecraft:blue_terracotta
fill 167 299 362 167 300 362 minecraft:blue_terracotta
setblock 168 299 325 minecraft:dark_prismarine
setblock 169 299 324 minecraft:dark_prismarine
fill 169 299 325 169 300 325 minecraft:blue_terracotta
setblock 170 299 323 minecraft:dark_prismarine
fill 170 299 324 170 300 324 minecraft:blue_terracotta
setblock 170 299 363 minecraft:dark_prismarine
fill 171 299 323 171 300 323 minecraft:blue_terracotta
setblock 171 299 362 minecraft:dark_prismarine
fill 171 299 363 171 300 363 minecraft:blue_terracotta
setblock 172 299 332 minecraft:light[level=12]
setblock 172 299 339 minecraft:light[level=12]
setblock 172 299 346 minecraft:light[level=12]
setblock 172 299 353 minecraft:light[level=12]
setblock 172 299 360 minecraft:light[level=12]
fill 172 299 362 172 300 362 minecraft:blue_terracotta
setblock 173 299 325 minecraft:dark_prismarine
fill 173 299 353 173 300 353 minecraft:dark_prismarine
setblock 174 299 324 minecraft:dark_prismarine
setblock 174 299 325 minecraft:blue_terracotta
setblock 175 299 323 minecraft:dark_prismarine
fill 175 299 324 175 300 324 minecraft:blue_terracotta
fill 175 299 351 175 300 351 minecraft:dark_prismarine
setblock 175 299 363 minecraft:dark_prismarine
fill 176 299 323 176 300 323 minecraft:blue_terracotta
fill 176 299 354 176 300 354 minecraft:dark_prismarine
setblock 176 299 362 minecraft:dark_prismarine
fill 176 299 363 176 300 363 minecraft:blue_terracotta
setblock 177 299 362 minecraft:blue_terracotta
setblock 179 299 325 minecraft:light[level=12]
setblock 179 299 332 minecraft:light[level=12]
setblock 179 299 339 minecraft:light[level=12]
setblock 179 299 346 minecraft:light[level=12]
setblock 179 299 353 minecraft:light[level=12]
setblock 179 299 360 minecraft:light[level=12]
setblock 180 299 323 minecraft:dark_prismarine
setblock 180 299 363 minecraft:dark_prismarine
fill 181 299 323 181 300 323 minecraft:blue_terracotta
setblock 181 299 362 minecraft:dark_prismarine
fill 181 299 363 181 300 363 minecraft:blue_terracotta
setblock 182 299 346 minecraft:dark_prismarine
setblock 182 299 348 minecraft:purple_concrete
setblock 182 299 361 minecraft:dark_prismarine
fill 182 299 362 182 300 362 minecraft:blue_terracotta
fill 141 300 335 141 308 335 minecraft:blue_concrete
fill 142 300 322 142 308 322 minecraft:blue_concrete
fill 142 300 323 143 300 323 minecraft:blue_terracotta
setblock 142 300 325 minecraft:purple_concrete
setblock 142 300 338 minecraft:dark_prismarine
setblock 142 300 340 minecraft:dark_prismarine
setblock 142 300 341 minecraft:blue_terracotta
setblock 142 300 345 minecraft:dark_prismarine
setblock 142 300 346 minecraft:blue_terracotta
setblock 142 300 350 minecraft:dark_prismarine
setblock 142 300 351 minecraft:blue_terracotta
setblock 142 300 353 minecraft:blue_terracotta
setblock 142 300 359 minecraft:blue_terracotta
setblock 142 300 360 minecraft:dark_prismarine
setblock 142 300 361 minecraft:blue_terracotta
setblock 143 300 343 minecraft:blue_terracotta
setblock 143 300 344 minecraft:dark_prismarine
setblock 143 300 345 minecraft:blue_terracotta
setblock 143 300 349 minecraft:dark_prismarine
setblock 143 300 350 minecraft:blue_terracotta
setblock 144 300 323 minecraft:dark_prismarine
setblock 144 300 343 minecraft:dark_prismarine
setblock 144 300 344 minecraft:blue_terracotta
setblock 144 300 348 minecraft:dark_prismarine
setblock 144 300 363 minecraft:dark_prismarine
fill 145 300 322 145 308 322 minecraft:blue_concrete
setblock 145 300 323 minecraft:blue_terracotta
setblock 145 300 362 minecraft:dark_prismarine
setblock 145 300 363 minecraft:blue_terracotta
setblock 146 300 362 minecraft:blue_terracotta
setblock 148 300 324 minecraft:dark_prismarine
setblock 149 300 323 minecraft:dark_prismarine
setblock 149 300 324 minecraft:blue_terracotta
setblock 149 300 363 minecraft:dark_prismarine
setblock 150 300 323 minecraft:blue_terracotta
setblock 150 300 363 minecraft:blue_terracotta
setblock 154 300 323 minecraft:dark_prismarine
fill 155 300 323 158 300 323 minecraft:blue_terracotta
setblock 159 300 323 minecraft:dark_prismarine
fill 160 300 323 163 300 323 minecraft:blue_terracotta
setblock 162 300 324 minecraft:blue_terracotta
setblock 163 300 324 minecraft:dark_prismarine
setblock 163 300 363 minecraft:blue_terracotta
setblock 164 300 323 minecraft:dark_prismarine
fill 164 300 324 164 300 325 minecraft:blue_terracotta
setblock 164 300 363 minecraft:dark_prismarine
setblock 165 300 323 minecraft:blue_terracotta
setblock 165 300 363 minecraft:blue_terracotta
setblock 166 300 362 minecraft:blue_terracotta
setblock 167 300 325 minecraft:dark_prismarine
setblock 168 300 324 minecraft:dark_prismarine
setblock 168 300 325 minecraft:blue_terracotta
setblock 169 300 323 minecraft:dark_prismarine
setblock 169 300 324 minecraft:blue_terracotta
setblock 169 300 363 minecraft:dark_prismarine
setblock 170 300 323 minecraft:blue_terracotta
setblock 170 300 362 minecraft:dark_prismarine
setblock 170 300 363 minecraft:blue_terracotta
setblock 171 300 362 minecraft:blue_terracotta
setblock 172 300 325 minecraft:dark_prismarine
setblock 173 300 324 minecraft:dark_prismarine
setblock 173 300 325 minecraft:blue_terracotta
setblock 174 300 323 minecraft:dark_prismarine
setblock 174 300 324 minecraft:blue_terracotta
setblock 174 300 363 minecraft:dark_prismarine
setblock 175 300 323 minecraft:blue_terracotta
setblock 175 300 362 minecraft:dark_prismarine
setblock 175 300 363 minecraft:blue_terracotta
setblock 179 300 323 minecraft:dark_prismarine
setblock 179 300 363 minecraft:dark_prismarine
setblock 180 300 323 minecraft:blue_terracotta
setblock 180 300 363 minecraft:blue_terracotta
setblock 182 300 325 minecraft:dark_prismarine
setblock 182 300 326 minecraft:blue_terracotta
setblock 182 300 342 minecraft:purple_concrete
setblock 182 300 345 minecraft:dark_prismarine
fill 182 300 346 182 300 348 minecraft:blue_terracotta
setblock 182 300 360 minecraft:dark_prismarine
setblock 182 300 361 minecraft:blue_terracotta
setblock 144 301 325 minecraft:light[level=13]
setblock 144 301 333 minecraft:light[level=13]
setblock 144 301 341 minecraft:light[level=13]
setblock 144 301 349 minecraft:light[level=13]
setblock 144 301 357 minecraft:light[level=13]
setblock 152 301 325 minecraft:light[level=13]
setblock 152 301 333 minecraft:light[level=13]
setblock 152 301 341 minecraft:light[level=13]
setblock 152 301 349 minecraft:light[level=13]
setblock 152 301 357 minecraft:light[level=13]
setblock 153 301 322 minecraft:cyan_concrete
setblock 160 301 325 minecraft:light[level=13]
setblock 160 301 333 minecraft:light[level=13]
setblock 160 301 341 minecraft:light[level=13]
setblock 160 301 349 minecraft:light[level=13]
setblock 160 301 357 minecraft:light[level=13]
setblock 168 301 325 minecraft:light[level=13]
setblock 168 301 333 minecraft:light[level=13]
setblock 168 301 341 minecraft:light[level=13]
setblock 168 301 349 minecraft:light[level=13]
setblock 168 301 357 minecraft:light[level=13]
setblock 176 301 325 minecraft:light[level=13]
setblock 176 301 333 minecraft:light[level=13]
setblock 176 301 341 minecraft:light[level=13]
setblock 176 301 349 minecraft:light[level=13]
setblock 176 301 357 minecraft:light[level=13]
fill 153 302 322 153 308 322 minecraft:blue_concrete
setblock 141 304 326 minecraft:cyan_concrete
fill 141 304 327 141 308 327 minecraft:blue_concrete
fill 141 305 326 141 308 326 minecraft:blue_concrete
fill 158 307 364 158 308 364 minecraft:blue_concrete
setblock 159 307 364 minecraft:light_blue_wool
fill 160 307 364 160 308 364 minecraft:blue_concrete
setblock 182 307 364 minecraft:light_blue_wool
setblock 141 308 344 minecraft:cyan_concrete
setblock 159 308 364 minecraft:blue_concrete
setblock 182 308 364 minecraft:blue_concrete
setblock 183 308 342 minecraft:light_blue_wool
