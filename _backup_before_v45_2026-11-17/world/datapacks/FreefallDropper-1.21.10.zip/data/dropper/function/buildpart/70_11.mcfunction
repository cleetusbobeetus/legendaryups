setblock 504 263 277 minecraft:cobbled_deepslate
setblock 505 263 276 minecraft:cobbled_deepslate
setblock 505 263 316 minecraft:cobbled_deepslate
fill 506 263 276 506 266 276 minecraft:deepslate_tiles
setblock 506 263 315 minecraft:cobbled_deepslate
fill 506 263 316 506 266 316 minecraft:deepslate_tiles
fill 507 263 315 507 265 315 minecraft:deepslate_tiles
fill 510 263 293 510 263 295 minecraft:deepslate_tiles
setblock 510 263 296 minecraft:cobbled_deepslate
fill 510 263 297 510 264 299 minecraft:deepslate_tiles
setblock 510 263 316 minecraft:cobbled_deepslate
setblock 511 263 290 minecraft:cobbled_deepslate
fill 511 263 291 511 266 291 minecraft:deepslate_tiles
setblock 511 263 295 minecraft:cobbled_deepslate
fill 511 263 296 511 266 296 minecraft:deepslate_tiles
setblock 511 263 300 minecraft:cobbled_deepslate
fill 511 263 301 511 265 302 minecraft:deepslate_tiles
setblock 511 263 315 minecraft:cobbled_deepslate
fill 511 263 316 511 266 316 minecraft:deepslate_tiles
fill 470 264 305 470 308 305 minecraft:deepslate_tiles
fill 471 264 276 471 265 277 minecraft:deepslate_tiles
fill 471 264 287 471 264 288 minecraft:deepslate_tiles
setblock 471 264 289 minecraft:cobbled_deepslate
fill 471 264 290 471 267 290 minecraft:deepslate_tiles
setblock 471 264 294 minecraft:cobbled_deepslate
fill 471 264 295 471 267 295 minecraft:deepslate_tiles
setblock 471 264 299 minecraft:cobbled_deepslate
fill 471 264 300 471 266 301 minecraft:deepslate_tiles
fill 472 264 276 473 264 276 minecraft:deepslate_tiles
setblock 472 264 293 minecraft:cobbled_deepslate
fill 472 264 294 473 266 294 minecraft:deepslate_tiles
setblock 472 264 298 minecraft:cobbled_deepslate
fill 472 264 299 472 267 299 minecraft:deepslate_tiles
fill 473 264 293 473 267 293 minecraft:deepslate_tiles
fill 473 264 295 473 264 296 minecraft:deepslate_tiles
setblock 473 264 316 minecraft:deepslate_tiles
setblock 474 264 276 minecraft:cobbled_deepslate
fill 474 264 277 477 264 277 minecraft:deepslate_tiles
setblock 474 264 316 minecraft:cobbled_deepslate
fill 475 264 276 478 264 276 minecraft:deepslate_tiles
fill 475 264 316 475 267 316 minecraft:deepslate_tiles
fill 476 264 315 476 267 315 minecraft:deepslate_tiles
setblock 477 264 278 minecraft:cobbled_deepslate
setblock 478 264 277 minecraft:cobbled_deepslate
fill 478 264 278 481 264 278 minecraft:deepslate_tiles
setblock 479 264 276 minecraft:cobbled_deepslate
fill 479 264 277 479 267 277 minecraft:deepslate_tiles
setblock 479 264 316 minecraft:cobbled_deepslate
fill 480 264 276 480 267 276 minecraft:deepslate_tiles
setblock 480 264 279 minecraft:deepslate_tiles
setblock 480 264 314 minecraft:deepslate_tiles
setblock 480 264 315 minecraft:cobbled_deepslate
fill 480 264 316 480 267 316 minecraft:deepslate_tiles
setblock 481 264 279 minecraft:cobbled_deepslate
setblock 481 264 314 minecraft:cobbled_deepslate
fill 481 264 315 481 267 315 minecraft:deepslate_tiles
setblock 482 264 278 minecraft:cobbled_deepslate
fill 482 264 314 482 266 314 minecraft:deepslate_tiles
setblock 483 264 277 minecraft:cobbled_deepslate
fill 483 264 278 483 267 278 minecraft:deepslate_tiles
setblock 484 264 276 minecraft:cobbled_deepslate
fill 484 264 277 484 267 277 minecraft:deepslate_tiles
setblock 484 264 316 minecraft:cobbled_deepslate
fill 485 264 276 485 267 276 minecraft:deepslate_tiles
setblock 485 264 315 minecraft:cobbled_deepslate
fill 485 264 316 485 267 316 minecraft:deepslate_tiles
setblock 486 264 278 minecraft:deepslate_tiles
fill 486 264 315 489 264 315 minecraft:deepslate_tiles
setblock 487 264 277 minecraft:deepslate_tiles
setblock 488 264 277 minecraft:cobbled_deepslate
setblock 489 264 276 minecraft:cobbled_deepslate
fill 489 264 277 489 267 277 minecraft:deepslate_tiles
setblock 489 264 316 minecraft:cobbled_deepslate
fill 490 264 276 493 264 276 minecraft:deepslate_tiles
setblock 490 264 315 minecraft:cobbled_deepslate
fill 490 264 316 490 267 316 minecraft:deepslate_tiles
fill 491 264 277 492 264 277 minecraft:deepslate_tiles
fill 491 264 315 491 267 315 minecraft:deepslate_tiles
setblock 493 264 277 minecraft:cobbled_deepslate
setblock 494 264 276 minecraft:cobbled_deepslate
fill 494 264 277 494 267 277 minecraft:deepslate_tiles
fill 494 264 314 494 265 314 minecraft:deepslate_tiles
setblock 494 264 316 minecraft:cobbled_deepslate
fill 495 264 276 495 267 276 minecraft:deepslate_tiles
setblock 495 264 315 minecraft:cobbled_deepslate
fill 495 264 316 495 267 316 minecraft:deepslate_tiles
setblock 496 264 314 minecraft:cobbled_deepslate
fill 496 264 315 496 267 315 minecraft:deepslate_tiles
fill 497 264 314 497 267 314 minecraft:deepslate_tiles
setblock 498 264 277 minecraft:cobbled_deepslate
fill 498 264 313 498 266 313 minecraft:deepslate_tiles
setblock 499 264 276 minecraft:cobbled_deepslate
fill 499 264 277 499 267 277 minecraft:deepslate_tiles
setblock 499 264 316 minecraft:cobbled_deepslate
fill 500 264 276 500 267 276 minecraft:deepslate_tiles
setblock 500 264 315 minecraft:cobbled_deepslate
fill 500 264 316 500 267 316 minecraft:deepslate_tiles
fill 501 264 277 502 264 277 minecraft:deepslate_tiles
setblock 501 264 314 minecraft:cobbled_deepslate
fill 501 264 315 501 267 315 minecraft:deepslate_tiles
setblock 502 264 313 minecraft:cobbled_deepslate
fill 502 264 314 502 267 314 minecraft:deepslate_tiles
setblock 503 264 277 minecraft:cobbled_deepslate
setblock 503 264 313 minecraft:deepslate_tiles
setblock 504 264 276 minecraft:cobbled_deepslate
fill 504 264 277 504 267 277 minecraft:deepslate_tiles
setblock 504 264 316 minecraft:cobbled_deepslate
fill 505 264 276 505 267 276 minecraft:deepslate_tiles
setblock 505 264 315 minecraft:cobbled_deepslate
fill 505 264 316 505 267 316 minecraft:deepslate_tiles
setblock 506 264 314 minecraft:cobbled_deepslate
fill 506 264 315 506 266 315 minecraft:deepslate_tiles
setblock 508 264 276 minecraft:deepslate_tiles
setblock 509 264 316 minecraft:cobbled_deepslate
fill 510 264 293 510 264 294 minecraft:deepslate_tiles
setblock 510 264 295 minecraft:cobbled_deepslate
fill 510 264 296 510 267 296 minecraft:deepslate_tiles
setblock 510 264 300 minecraft:cobbled_deepslate
fill 510 264 316 510 267 316 minecraft:deepslate_tiles
fill 511 264 290 511 267 290 minecraft:deepslate_tiles
setblock 511 264 294 minecraft:cobbled_deepslate
fill 511 264 295 511 267 295 minecraft:deepslate_tiles
setblock 511 264 298 minecraft:deepslate_tiles
setblock 511 264 299 minecraft:cobbled_deepslate
fill 511 264 300 511 267 300 minecraft:deepslate_tiles
setblock 511 264 303 minecraft:deepslate_tiles
setblock 511 264 314 minecraft:cobbled_deepslate
fill 511 264 315 511 266 315 minecraft:deepslate_tiles
setblock 471 265 278 minecraft:cobbled_deepslate
fill 471 265 279 471 267 280 minecraft:deepslate_tiles
setblock 471 265 287 minecraft:deepslate_tiles
setblock 471 265 288 minecraft:cobbled_deepslate
fill 471 265 289 471 268 289 minecraft:deepslate_tiles
setblock 471 265 293 minecraft:cobbled_deepslate
fill 471 265 294 471 268 294 minecraft:deepslate_tiles
setblock 471 265 298 minecraft:cobbled_deepslate
fill 471 265 299 471 268 299 minecraft:deepslate_tiles
setblock 471 265 302 minecraft:deepslate_tiles
setblock 472 265 276 minecraft:deepslate_tiles
setblock 472 265 292 minecraft:cobbled_deepslate
fill 472 265 293 472 268 293 minecraft:deepslate_tiles
setblock 472 265 297 minecraft:cobbled_deepslate
fill 472 265 298 472 268 298 minecraft:deepslate_tiles
setblock 472 265 316 minecraft:deepslate_tiles
setblock 473 265 276 minecraft:cobbled_deepslate
fill 473 265 277 476 265 277 minecraft:deepslate_tiles
setblock 473 265 278 minecraft:light[level=12]
setblock 473 265 285 minecraft:light[level=12]
setblock 473 265 292 minecraft:light[level=12]
setblock 473 265 295 minecraft:deepslate_tiles
setblock 473 265 296 minecraft:cobbled_deepslate
fill 473 265 297 473 268 297 minecraft:deepslate_tiles
setblock 473 265 299 minecraft:light[level=12]
setblock 473 265 306 minecraft:light[level=12]
setblock 473 265 313 minecraft:light[level=12]
setblock 473 265 316 minecraft:cobbled_deepslate
fill 474 265 276 477 265 276 minecraft:deepslate_tiles
fill 474 265 316 474 268 316 minecraft:deepslate_tiles
setblock 475 265 278 minecraft:deepslate_tiles
fill 475 265 315 475 267 315 minecraft:deepslate_tiles
setblock 476 265 278 minecraft:cobbled_deepslate
setblock 477 265 277 minecraft:cobbled_deepslate
fill 477 265 278 480 265 278 minecraft:deepslate_tiles
setblock 478 265 276 minecraft:cobbled_deepslate
fill 478 265 277 478 268 277 minecraft:deepslate_tiles
fill 478 265 279 479 265 279 minecraft:deepslate_tiles
setblock 478 265 316 minecraft:cobbled_deepslate
fill 479 265 276 479 268 276 minecraft:deepslate_tiles
setblock 479 265 314 minecraft:deepslate_tiles
setblock 479 265 315 minecraft:cobbled_deepslate
fill 479 265 316 479 268 316 minecraft:deepslate_tiles
setblock 480 265 279 minecraft:cobbled_deepslate
setblock 480 265 285 minecraft:light[level=12]
setblock 480 265 292 minecraft:light[level=12]
setblock 480 265 299 minecraft:light[level=12]
setblock 480 265 306 minecraft:light[level=12]
setblock 480 265 313 minecraft:light[level=12]
setblock 480 265 314 minecraft:cobbled_deepslate
fill 480 265 315 480 268 315 minecraft:deepslate_tiles
setblock 481 265 278 minecraft:cobbled_deepslate
fill 481 265 279 483 266 279 minecraft:deepslate_tiles
fill 481 265 314 481 266 314 minecraft:deepslate_tiles
setblock 482 265 277 minecraft:cobbled_deepslate
fill 482 265 278 482 268 278 minecraft:deepslate_tiles
setblock 483 265 276 minecraft:cobbled_deepslate
fill 483 265 277 483 268 277 minecraft:deepslate_tiles
setblock 483 265 316 minecraft:cobbled_deepslate
fill 484 265 276 484 268 276 minecraft:deepslate_tiles
setblock 484 265 315 minecraft:cobbled_deepslate
fill 484 265 316 484 268 316 minecraft:deepslate_tiles
fill 485 265 315 488 265 315 minecraft:deepslate_tiles
setblock 486 265 278 minecraft:cobbled_deepslate
setblock 487 265 277 minecraft:cobbled_deepslate
setblock 487 265 278 minecraft:light[level=12]
setblock 487 265 285 minecraft:light[level=12]
setblock 487 265 292 minecraft:light[level=12]
setblock 487 265 299 minecraft:light[level=12]
setblock 487 265 306 minecraft:light[level=12]
setblock 487 265 313 minecraft:light[level=12]
setblock 488 265 276 minecraft:cobbled_deepslate
fill 488 265 277 488 268 277 minecraft:deepslate_tiles
setblock 488 265 316 minecraft:cobbled_deepslate
fill 489 265 276 492 265 276 minecraft:deepslate_tiles
setblock 489 265 315 minecraft:cobbled_deepslate
fill 489 265 316 489 268 316 minecraft:deepslate_tiles
fill 490 265 315 490 268 315 minecraft:deepslate_tiles
setblock 491 265 277 minecraft:deepslate_tiles
setblock 492 265 277 minecraft:cobbled_deepslate
setblock 493 265 276 minecraft:cobbled_deepslate
fill 493 265 277 493 268 277 minecraft:deepslate_tiles
fill 493 265 314 493 266 314 minecraft:deepslate_tiles
setblock 493 265 316 minecraft:cobbled_deepslate
fill 494 265 276 494 268 276 minecraft:deepslate_tiles
setblock 494 265 278 minecraft:light[level=12]
setblock 494 265 285 minecraft:light[level=12]
setblock 494 265 292 minecraft:light[level=12]
setblock 494 265 299 minecraft:light[level=12]
setblock 494 265 306 minecraft:light[level=12]
setblock 494 265 313 minecraft:light[level=12]
setblock 494 265 315 minecraft:cobbled_deepslate
fill 494 265 316 494 268 316 minecraft:deepslate_tiles
setblock 495 265 314 minecraft:cobbled_deepslate
fill 495 265 315 495 268 315 minecraft:deepslate_tiles
fill 496 265 314 496 268 314 minecraft:deepslate_tiles
setblock 497 265 276 minecraft:deepslate_tiles
setblock 497 265 277 minecraft:cobbled_deepslate
fill 497 265 278 500 265 278 minecraft:deepslate_tiles
fill 497 265 313 497 266 313 minecraft:deepslate_tiles
setblock 498 265 276 minecraft:cobbled_deepslate
fill 498 265 277 498 268 277 minecraft:deepslate_tiles
setblock 498 265 316 minecraft:cobbled_deepslate
fill 499 265 276 499 268 276 minecraft:deepslate_tiles
setblock 499 265 315 minecraft:cobbled_deepslate
fill 499 265 316 499 268 316 minecraft:deepslate_tiles
setblock 500 265 314 minecraft:cobbled_deepslate
fill 500 265 315 500 268 315 minecraft:deepslate_tiles
setblock 501 265 277 minecraft:deepslate_tiles
setblock 501 265 278 minecraft:light[level=12]
setblock 501 265 285 minecraft:light[level=12]
setblock 501 265 292 minecraft:light[level=12]
setblock 501 265 299 minecraft:light[level=12]
setblock 501 265 306 minecraft:light[level=12]
setblock 501 265 313 minecraft:cobbled_deepslate
fill 501 265 314 501 268 314 minecraft:deepslate_tiles
setblock 502 265 277 minecraft:cobbled_deepslate
setblock 502 265 313 minecraft:deepslate_tiles
setblock 503 265 276 minecraft:cobbled_deepslate
fill 503 265 277 503 268 277 minecraft:deepslate_tiles
setblock 503 265 316 minecraft:cobbled_deepslate
fill 504 265 276 504 268 276 minecraft:deepslate_tiles
setblock 504 265 315 minecraft:cobbled_deepslate
fill 504 265 316 504 268 316 minecraft:deepslate_tiles
setblock 505 265 314 minecraft:cobbled_deepslate
fill 505 265 315 505 267 315 minecraft:deepslate_tiles
setblock 508 265 276 minecraft:cobbled_deepslate
setblock 508 265 278 minecraft:light[level=12]
setblock 508 265 285 minecraft:light[level=12]
setblock 508 265 292 minecraft:light[level=12]
setblock 508 265 299 minecraft:light[level=12]
setblock 508 265 306 minecraft:light[level=12]
setblock 508 265 313 minecraft:light[level=12]
setblock 508 265 316 minecraft:cobbled_deepslate
fill 509 265 296 509 266 297 minecraft:deepslate_tiles
fill 509 265 316 509 267 316 minecraft:deepslate_tiles
setblock 510 265 293 minecraft:deepslate_tiles
setblock 510 265 294 minecraft:cobbled_deepslate
fill 510 265 295 510 268 295 minecraft:deepslate_tiles
fill 510 265 297 510 265 298 minecraft:deepslate_tiles
setblock 510 265 299 minecraft:cobbled_deepslate
fill 510 265 300 510 267 301 minecraft:deepslate_tiles
setblock 511 265 293 minecraft:cobbled_deepslate
fill 511 265 294 511 268 294 minecraft:deepslate_tiles
setblock 511 265 298 minecraft:cobbled_deepslate
fill 511 265 299 511 268 299 minecraft:deepslate_tiles
setblock 511 265 303 minecraft:cobbled_deepslate
fill 511 265 304 511 268 304 minecraft:deepslate_tiles
setblock 511 265 313 minecraft:cobbled_deepslate
setblock 511 265 314 minecraft:deepslate_tiles
setblock 471 266 276 minecraft:deepslate_tiles
setblock 471 266 277 minecraft:cobbled_deepslate
fill 471 266 278 472 268 278 minecraft:deepslate_tiles
setblock 471 266 281 minecraft:deepslate_tiles
setblock 471 266 282 minecraft:cobbled_deepslate
fill 471 266 283 471 266 286 minecraft:deepslate_tiles
setblock 471 266 287 minecraft:cobbled_deepslate
fill 471 266 288 471 269 288 minecraft:deepslate_tiles
setblock 471 266 292 minecraft:cobbled_deepslate
fill 471 266 293 471 269 293 minecraft:deepslate_tiles
setblock 471 266 297 minecraft:cobbled_deepslate
fill 471 266 298 471 269 298 minecraft:deepslate_tiles
setblock 471 266 302 minecraft:cobbled_deepslate
setblock 471 266 316 minecraft:deepslate_tiles
setblock 472 266 276 minecraft:cobbled_deepslate
fill 472 266 277 475 266 277 minecraft:deepslate_tiles
fill 472 266 279 472 267 279 minecraft:deepslate_tiles
setblock 472 266 291 minecraft:cobbled_deepslate
fill 472 266 292 472 268 292 minecraft:deepslate_tiles
setblock 472 266 296 minecraft:cobbled_deepslate
fill 472 266 297 472 269 297 minecraft:deepslate_tiles
setblock 472 266 300 minecraft:deepslate_tiles
setblock 472 266 316 minecraft:cobbled_deepslate
fill 473 266 276 476 266 276 minecraft:deepslate_tiles
setblock 473 266 295 minecraft:cobbled_deepslate
fill 473 266 296 473 268 296 minecraft:deepslate_tiles
fill 473 266 298 473 267 298 minecraft:deepslate_tiles
fill 473 266 316 473 269 316 minecraft:deepslate_tiles
setblock 474 266 278 minecraft:deepslate_tiles
setblock 475 266 278 minecraft:cobbled_deepslate
setblock 476 266 277 minecraft:cobbled_deepslate
fill 476 266 278 479 266 278 minecraft:deepslate_tiles
setblock 477 266 276 minecraft:cobbled_deepslate
fill 477 266 277 477 269 277 minecraft:deepslate_tiles
fill 477 266 279 478 266 279 minecraft:deepslate_tiles
setblock 477 266 316 minecraft:cobbled_deepslate
fill 478 266 276 478 269 276 minecraft:deepslate_tiles
setblock 478 266 315 minecraft:cobbled_deepslate
fill 478 266 316 478 269 316 minecraft:deepslate_tiles
setblock 479 266 279 minecraft:cobbled_deepslate
fill 479 266 315 479 269 315 minecraft:deepslate_tiles
setblock 480 266 278 minecraft:cobbled_deepslate
fill 480 266 279 480 269 279 minecraft:deepslate_tiles
setblock 480 266 314 minecraft:deepslate_tiles
setblock 481 266 277 minecraft:cobbled_deepslate
fill 481 266 278 481 269 278 minecraft:deepslate_tiles
setblock 482 266 276 minecraft:cobbled_deepslate
fill 482 266 277 482 269 277 minecraft:deepslate_tiles
setblock 482 266 316 minecraft:cobbled_deepslate
fill 483 266 276 483 269 276 minecraft:deepslate_tiles
setblock 483 266 315 minecraft:cobbled_deepslate
fill 483 266 316 483 269 316 minecraft:deepslate_tiles
setblock 484 266 278 minecraft:deepslate_tiles
fill 484 266 315 487 266 315 minecraft:deepslate_tiles
setblock 485 266 278 minecraft:cobbled_deepslate
setblock 486 266 277 minecraft:cobbled_deepslate
fill 486 266 278 487 266 278 minecraft:deepslate_tiles
setblock 487 266 276 minecraft:cobbled_deepslate
fill 487 266 277 487 269 277 minecraft:deepslate_tiles
setblock 487 266 316 minecraft:cobbled_deepslate
fill 488 266 276 491 266 276 minecraft:deepslate_tiles
setblock 488 266 315 minecraft:cobbled_deepslate
fill 488 266 316 488 269 316 minecraft:deepslate_tiles
fill 489 266 315 489 268 315 minecraft:deepslate_tiles
setblock 491 266 277 minecraft:cobbled_deepslate
setblock 492 266 276 minecraft:cobbled_deepslate
fill 492 266 277 492 269 277 minecraft:deepslate_tiles
setblock 492 266 316 minecraft:cobbled_deepslate
fill 493 266 276 493 269 276 minecraft:deepslate_tiles
setblock 493 266 315 minecraft:cobbled_deepslate
fill 493 266 316 493 269 316 minecraft:deepslate_tiles
setblock 494 266 314 minecraft:cobbled_deepslate
fill 494 266 315 494 269 315 minecraft:deepslate_tiles
setblock 495 266 277 minecraft:deepslate_tiles
setblock 495 266 278 minecraft:cobbled_deepslate
fill 495 266 314 495 269 314 minecraft:deepslate_tiles
setblock 496 266 277 minecraft:cobbled_deepslate
fill 496 266 278 499 266 278 minecraft:deepslate_tiles
setblock 497 266 276 minecraft:cobbled_deepslate
fill 497 266 277 497 269 277 minecraft:deepslate_tiles
setblock 497 266 316 minecraft:cobbled_deepslate
fill 498 266 276 498 269 276 minecraft:deepslate_tiles
setblock 498 266 315 minecraft:cobbled_deepslate
fill 498 266 316 498 269 316 minecraft:deepslate_tiles
setblock 499 266 314 minecraft:cobbled_deepslate
fill 499 266 315 499 269 315 minecraft:deepslate_tiles
setblock 500 266 278 minecraft:cobbled_deepslate
setblock 500 266 313 minecraft:cobbled_deepslate
fill 500 266 314 500 269 314 minecraft:deepslate_tiles
setblock 501 266 277 minecraft:cobbled_deepslate
fill 501 266 278 501 267 278 minecraft:deepslate_tiles
setblock 501 266 313 minecraft:deepslate_tiles
setblock 502 266 276 minecraft:cobbled_deepslate
fill 502 266 277 502 269 277 minecraft:deepslate_tiles
setblock 502 266 316 minecraft:cobbled_deepslate
fill 503 266 276 503 269 276 minecraft:deepslate_tiles
setblock 503 266 315 minecraft:cobbled_deepslate
fill 503 266 316 503 269 316 minecraft:deepslate_tiles
fill 504 266 312 504 267 312 minecraft:black_concrete
setblock 504 266 314 minecraft:cobbled_deepslate
fill 504 266 315 504 268 315 minecraft:deepslate_tiles
fill 505 266 311 505 267 311 minecraft:black_concrete
fill 505 266 313 505 267 313 minecraft:black_concrete
fill 506 266 312 506 267 312 minecraft:black_concrete
setblock 507 266 276 minecraft:cobbled_deepslate
setblock 507 266 316 minecraft:cobbled_deepslate
fill 508 266 276 511 266 276 minecraft:deepslate_tiles
fill 508 266 316 508 267 316 minecraft:deepslate_tiles
setblock 509 266 298 minecraft:deepslate_tiles
setblock 509 266 299 minecraft:cobbled_deepslate
setblock 510 266 293 minecraft:cobbled_deepslate
fill 510 266 294 510 269 294 minecraft:deepslate_tiles
setblock 510 266 297 minecraft:deepslate_tiles
setblock 510 266 298 minecraft:cobbled_deepslate
fill 510 266 299 510 269 299 minecraft:deepslate_tiles
setblock 510 266 302 minecraft:deepslate_tiles
setblock 511 266 277 minecraft:cobbled_deepslate
setblock 511 266 292 minecraft:cobbled_deepslate
fill 511 266 293 511 269 293 minecraft:deepslate_tiles
setblock 511 266 297 minecraft:cobbled_deepslate
fill 511 266 298 511 269 298 minecraft:deepslate_tiles
setblock 511 266 301 minecraft:deepslate_tiles
setblock 511 266 302 minecraft:cobbled_deepslate
fill 511 266 303 511 269 303 minecraft:deepslate_tiles
fill 511 266 305 511 267 305 minecraft:deepslate_tiles
setblock 471 267 276 minecraft:cobbled_deepslate
fill 471 267 277 474 267 277 minecraft:deepslate_tiles
setblock 471 267 281 minecraft:cobbled_deepslate
fill 471 267 282 471 267 285 minecraft:deepslate_tiles
setblock 471 267 286 minecraft:cobbled_deepslate
fill 471 267 287 471 270 287 minecraft:deepslate_tiles
setblock 471 267 291 minecraft:cobbled_deepslate
fill 471 267 292 471 270 292 minecraft:deepslate_tiles
setblock 471 267 296 minecraft:cobbled_deepslate
fill 471 267 297 471 270 297 minecraft:deepslate_tiles
setblock 471 267 300 minecraft:deepslate_tiles
setblock 471 267 301 minecraft:cobbled_deepslate
fill 471 267 302 471 269 303 minecraft:deepslate_tiles
fill 472 267 276 475 267 276 minecraft:deepslate_tiles
setblock 472 267 280 minecraft:cobbled_deepslate
fill 472 267 281 472 269 282 minecraft:deepslate_tiles
setblock 472 267 290 minecraft:cobbled_deepslate
fill 472 267 291 472 268 291 minecraft:deepslate_tiles
setblock 472 267 294 minecraft:deepslate_tiles
setblock 472 267 295 minecraft:cobbled_deepslate
fill 472 267 296 472 270 296 minecraft:deepslate_tiles
setblock 472 267 300 minecraft:cobbled_deepslate
fill 472 267 301 472 270 301 minecraft:deepslate_tiles
fill 472 267 316 472 268 316 minecraft:deepslate_tiles
setblock 473 267 278 minecraft:deepslate_tiles
setblock 473 267 279 minecraft:cobbled_deepslate
setblock 473 267 294 minecraft:cobbled_deepslate
fill 473 267 295 473 268 295 minecraft:deepslate_tiles
setblock 474 267 278 minecraft:cobbled_deepslate
setblock 475 267 277 minecraft:cobbled_deepslate
fill 475 267 278 478 267 278 minecraft:deepslate_tiles
setblock 476 267 276 minecraft:cobbled_deepslate
fill 476 267 277 476 270 277 minecraft:deepslate_tiles
fill 476 267 279 477 267 279 minecraft:deepslate_tiles
setblock 476 267 316 minecraft:cobbled_deepslate
fill 477 267 276 477 270 276 minecraft:deepslate_tiles
setblock 477 267 315 minecraft:cobbled_deepslate
fill 477 267 316 477 270 316 minecraft:deepslate_tiles
setblock 478 267 279 minecraft:cobbled_deepslate
fill 478 267 315 478 270 315 minecraft:deepslate_tiles
setblock 479 267 278 minecraft:cobbled_deepslate
fill 479 267 279 479 270 279 minecraft:deepslate_tiles
setblock 480 267 277 minecraft:cobbled_deepslate
fill 480 267 278 480 270 278 minecraft:deepslate_tiles
setblock 481 267 276 minecraft:cobbled_deepslate
fill 481 267 277 481 270 277 minecraft:deepslate_tiles
fill 481 267 279 482 267 279 minecraft:deepslate_tiles
setblock 481 267 316 minecraft:cobbled_deepslate
fill 482 267 276 482 270 276 minecraft:deepslate_tiles
setblock 482 267 315 minecraft:cobbled_deepslate
fill 482 267 316 482 270 316 minecraft:deepslate_tiles
setblock 483 267 279 minecraft:cobbled_deepslate
fill 483 267 315 486 267 315 minecraft:deepslate_tiles
setblock 484 267 278 minecraft:cobbled_deepslate
setblock 485 267 277 minecraft:cobbled_deepslate
fill 485 267 278 486 268 278 minecraft:deepslate_tiles
setblock 486 267 276 minecraft:cobbled_deepslate
fill 486 267 277 486 270 277 minecraft:deepslate_tiles
setblock 486 267 316 minecraft:cobbled_deepslate
fill 487 267 276 490 267 276 minecraft:deepslate_tiles
setblock 487 267 315 minecraft:cobbled_deepslate
fill 487 267 316 487 270 316 minecraft:deepslate_tiles
setblock 488 267 315 minecraft:deepslate_tiles
setblock 490 267 277 minecraft:cobbled_deepslate
setblock 491 267 276 minecraft:cobbled_deepslate
fill 491 267 277 491 270 277 minecraft:deepslate_tiles
setblock 491 267 316 minecraft:cobbled_deepslate
fill 492 267 276 492 270 276 minecraft:deepslate_tiles
setblock 492 267 315 minecraft:cobbled_deepslate
fill 492 267 316 492 270 316 minecraft:deepslate_tiles
fill 493 267 315 493 270 315 minecraft:deepslate_tiles
setblock 494 267 278 minecraft:cobbled_deepslate
fill 494 267 314 494 268 314 minecraft:deepslate_tiles
setblock 495 267 277 minecraft:cobbled_deepslate
fill 495 267 278 498 267 278 minecraft:deepslate_tiles
setblock 496 267 276 minecraft:cobbled_deepslate
fill 496 267 277 496 270 277 minecraft:deepslate_tiles
setblock 496 267 316 minecraft:cobbled_deepslate
fill 497 267 276 497 270 276 minecraft:deepslate_tiles
setblock 497 267 315 minecraft:cobbled_deepslate
fill 497 267 316 497 270 316 minecraft:deepslate_tiles
setblock 498 267 314 minecraft:cobbled_deepslate
fill 498 267 315 498 270 315 minecraft:deepslate_tiles
setblock 499 267 278 minecraft:cobbled_deepslate
setblock 499 267 313 minecraft:cobbled_deepslate
fill 499 267 314 499 269 314 minecraft:deepslate_tiles
setblock 500 267 277 minecraft:cobbled_deepslate
fill 500 267 278 500 268 278 minecraft:deepslate_tiles
setblock 501 267 276 minecraft:cobbled_deepslate
fill 501 267 277 501 270 277 minecraft:deepslate_tiles
setblock 501 267 316 minecraft:cobbled_deepslate
fill 502 267 276 502 270 276 minecraft:deepslate_tiles
setblock 502 267 315 minecraft:cobbled_deepslate
fill 502 267 316 502 270 316 minecraft:deepslate_tiles
setblock 503 267 314 minecraft:cobbled_deepslate
fill 503 267 315 503 268 315 minecraft:deepslate_tiles
setblock 506 267 276 minecraft:cobbled_deepslate
setblock 506 267 316 minecraft:cobbled_deepslate
fill 507 267 276 510 267 276 minecraft:deepslate_tiles
fill 507 267 316 507 268 316 minecraft:deepslate_tiles
setblock 509 267 297 minecraft:deepslate_tiles
setblock 509 267 298 minecraft:cobbled_deepslate
fill 509 267 299 509 268 299 minecraft:deepslate_tiles
setblock 510 267 293 minecraft:deepslate_tiles
setblock 510 267 297 minecraft:cobbled_deepslate
fill 510 267 298 510 270 298 minecraft:deepslate_tiles
setblock 510 267 302 minecraft:cobbled_deepslate
setblock 511 267 276 minecraft:cobbled_deepslate
fill 511 267 277 511 269 278 minecraft:deepslate_tiles
setblock 511 267 291 minecraft:cobbled_deepslate
fill 511 267 292 511 270 292 minecraft:deepslate_tiles
setblock 511 267 296 minecraft:cobbled_deepslate
fill 511 267 297 511 270 297 minecraft:deepslate_tiles
setblock 511 267 301 minecraft:cobbled_deepslate
fill 511 267 302 511 270 302 minecraft:deepslate_tiles
setblock 511 267 316 minecraft:cobbled_deepslate
fill 471 268 276 473 268 277 minecraft:deepslate_tiles
setblock 471 268 279 minecraft:deepslate_tiles
setblock 471 268 280 minecraft:cobbled_deepslate
fill 471 268 281 471 268 284 minecraft:deepslate_tiles
setblock 471 268 285 minecraft:cobbled_deepslate
fill 471 268 286 471 271 286 minecraft:deepslate_tiles
setblock 471 268 290 minecraft:cobbled_deepslate
fill 471 268 291 471 271 291 minecraft:deepslate_tiles
setblock 471 268 295 minecraft:cobbled_deepslate
fill 471 268 296 471 271 296 minecraft:deepslate_tiles
setblock 471 268 300 minecraft:cobbled_deepslate
fill 471 268 301 471 271 301 minecraft:deepslate_tiles
setblock 472 268 279 minecraft:cobbled_deepslate
fill 472 268 280 473 270 280 minecraft:deepslate_tiles
setblock 472 268 283 minecraft:deepslate_tiles
setblock 472 268 294 minecraft:cobbled_deepslate
fill 472 268 295 472 270 295 minecraft:deepslate_tiles
setblock 472 268 299 minecraft:cobbled_deepslate
fill 472 268 300 472 271 300 minecraft:deepslate_tiles
setblock 473 268 278 minecraft:cobbled_deepslate
fill 473 268 279 473 271 279 minecraft:deepslate_tiles
setblock 473 268 298 minecraft:cobbled_deepslate
setblock 474 268 276 minecraft:deepslate_tiles
setblock 474 268 277 minecraft:cobbled_deepslate
fill 474 268 278 477 268 278 minecraft:deepslate_tiles
setblock 475 268 276 minecraft:cobbled_deepslate
fill 475 268 277 475 271 277 minecraft:deepslate_tiles
fill 475 268 279 476 268 279 minecraft:deepslate_tiles
setblock 475 268 316 minecraft:cobbled_deepslate
fill 476 268 276 476 271 276 minecraft:deepslate_tiles
setblock 476 268 315 minecraft:cobbled_deepslate
fill 476 268 316 476 271 316 minecraft:deepslate_tiles
setblock 477 268 279 minecraft:cobbled_deepslate
fill 477 268 315 477 270 315 minecraft:deepslate_tiles
setblock 478 268 278 minecraft:cobbled_deepslate
fill 478 268 279 478 271 279 minecraft:deepslate_tiles
setblock 479 268 277 minecraft:cobbled_deepslate
fill 479 268 278 479 271 278 minecraft:deepslate_tiles
setblock 480 268 276 minecraft:cobbled_deepslate
fill 480 268 277 480 271 277 minecraft:deepslate_tiles
setblock 480 268 316 minecraft:cobbled_deepslate
fill 481 268 276 481 271 276 minecraft:deepslate_tiles
setblock 481 268 279 minecraft:deepslate_tiles
setblock 481 268 315 minecraft:cobbled_deepslate
fill 481 268 316 481 271 316 minecraft:deepslate_tiles
setblock 482 268 279 minecraft:cobbled_deepslate
fill 482 268 315 485 268 315 minecraft:deepslate_tiles
setblock 483 268 278 minecraft:cobbled_deepslate
setblock 484 268 277 minecraft:cobbled_deepslate
fill 484 268 278 484 270 278 minecraft:deepslate_tiles
setblock 485 268 276 minecraft:cobbled_deepslate
fill 485 268 277 485 271 277 minecraft:deepslate_tiles
setblock 485 268 316 minecraft:cobbled_deepslate
fill 486 268 276 489 268 276 minecraft:deepslate_tiles
setblock 486 268 315 minecraft:cobbled_deepslate
fill 486 268 316 486 271 316 minecraft:deepslate_tiles
setblock 489 268 277 minecraft:cobbled_deepslate
setblock 490 268 276 minecraft:cobbled_deepslate
fill 490 268 277 490 271 277 minecraft:deepslate_tiles
setblock 490 268 316 minecraft:cobbled_deepslate
fill 491 268 276 491 271 276 minecraft:deepslate_tiles
setblock 491 268 315 minecraft:cobbled_deepslate
fill 491 268 316 491 271 316 minecraft:deepslate_tiles
fill 492 268 315 492 270 315 minecraft:deepslate_tiles
setblock 494 268 277 minecraft:cobbled_deepslate
fill 494 268 278 497 268 278 minecraft:deepslate_tiles
setblock 495 268 276 minecraft:cobbled_deepslate
fill 495 268 277 495 271 277 minecraft:deepslate_tiles
setblock 495 268 316 minecraft:cobbled_deepslate
fill 496 268 276 496 271 276 minecraft:deepslate_tiles
setblock 496 268 315 minecraft:cobbled_deepslate
fill 496 268 316 496 271 316 minecraft:deepslate_tiles
setblock 497 268 314 minecraft:cobbled_deepslate
fill 497 268 315 497 271 315 minecraft:deepslate_tiles
setblock 498 268 278 minecraft:cobbled_deepslate
fill 498 268 314 498 269 314 minecraft:deepslate_tiles
setblock 499 268 277 minecraft:cobbled_deepslate
fill 499 268 278 499 269 278 minecraft:deepslate_tiles
setblock 500 268 276 minecraft:cobbled_deepslate
fill 500 268 277 500 271 277 minecraft:deepslate_tiles
setblock 500 268 316 minecraft:cobbled_deepslate
fill 501 268 276 501 271 276 minecraft:deepslate_tiles
setblock 501 268 315 minecraft:cobbled_deepslate
fill 501 268 316 501 271 316 minecraft:deepslate_tiles
fill 502 268 315 502 269 315 minecraft:deepslate_tiles
setblock 505 268 276 minecraft:cobbled_deepslate
setblock 505 268 316 minecraft:cobbled_deepslate
setblock 506 268 276 minecraft:deepslate_tiles
setblock 506 268 316 minecraft:deepslate_tiles
setblock 509 268 298 minecraft:deepslate_tiles
setblock 510 268 296 minecraft:cobbled_deepslate
fill 510 268 297 510 271 297 minecraft:deepslate_tiles
setblock 510 268 300 minecraft:deepslate_tiles
setblock 510 268 301 minecraft:cobbled_deepslate
fill 510 268 302 510 270 303 minecraft:deepslate_tiles
fill 511 268 276 511 270 276 minecraft:deepslate_tiles
setblock 511 268 279 minecraft:deepslate_tiles
setblock 511 268 280 minecraft:cobbled_deepslate
setblock 511 268 290 minecraft:cobbled_deepslate
fill 511 268 291 511 270 291 minecraft:deepslate_tiles
setblock 511 268 295 minecraft:cobbled_deepslate
fill 511 268 296 511 271 296 minecraft:deepslate_tiles
setblock 511 268 300 minecraft:cobbled_deepslate
fill 511 268 301 511 271 301 minecraft:deepslate_tiles
setblock 511 268 305 minecraft:cobbled_deepslate
fill 512 268 282 512 296 283 minecraft:deepslate_tiles
setblock 512 268 284 minecraft:white_wool
fill 512 268 285 512 308 285 minecraft:deepslate_tiles
setblock 512 268 293 minecraft:redstone_block
fill 512 268 294 512 291 295 minecraft:deepslate_tiles
setblock 470 269 314 minecraft:redstone_block
fill 471 269 276 471 269 278 minecraft:deepslate_tiles
setblock 471 269 279 minecraft:cobbled_deepslate
fill 471 269 280 471 269 283 minecraft:deepslate_tiles
setblock 471 269 284 minecraft:cobbled_deepslate
fill 471 269 285 471 272 285 minecraft:deepslate_tiles
setblock 471 269 289 minecraft:cobbled_deepslate
fill 471 269 290 471 272 290 minecraft:deepslate_tiles
setblock 471 269 294 minecraft:cobbled_deepslate
fill 471 269 295 471 272 295 minecraft:deepslate_tiles
setblock 471 269 299 minecraft:cobbled_deepslate
fill 471 269 300 471 272 300 minecraft:deepslate_tiles
fill 472 269 276 472 269 277 minecraft:deepslate_tiles
setblock 472 269 278 minecraft:cobbled_deepslate
fill 472 269 279 472 272 279 minecraft:deepslate_tiles
setblock 472 269 283 minecraft:cobbled_deepslate
fill 472 269 284 472 272 284 minecraft:deepslate_tiles
setblock 472 269 293 minecraft:cobbled_deepslate
fill 472 269 294 472 270 294 minecraft:deepslate_tiles
setblock 472 269 298 minecraft:cobbled_deepslate
fill 472 269 299 472 272 299 minecraft:deepslate_tiles
setblock 473 269 276 minecraft:deepslate_tiles
setblock 473 269 277 minecraft:cobbled_deepslate
fill 473 269 278 476 269 278 minecraft:deepslate_tiles
setblock 473 269 281 minecraft:deepslate_tiles
setblock 473 269 282 minecraft:cobbled_deepslate
setblock 473 269 286 minecraft:light[level=13]
setblock 473 269 294 minecraft:light[level=13]
setblock 473 269 297 minecraft:cobbled_deepslate
setblock 473 269 302 minecraft:light[level=13]
setblock 473 269 310 minecraft:light[level=13]
setblock 474 269 276 minecraft:cobbled_deepslate
fill 474 269 277 474 272 277 minecraft:deepslate_tiles
setblock 474 269 316 minecraft:cobbled_deepslate
fill 475 269 276 475 272 276 minecraft:deepslate_tiles
setblock 475 269 279 minecraft:deepslate_tiles
fill 475 269 316 475 272 316 minecraft:deepslate_tiles
setblock 475 269 317 minecraft:redstone_block
setblock 476 269 279 minecraft:cobbled_deepslate
setblock 476 269 315 minecraft:deepslate_tiles
setblock 477 269 278 minecraft:cobbled_deepslate
fill 477 269 279 477 272 279 minecraft:deepslate_tiles
setblock 478 269 277 minecraft:cobbled_deepslate
fill 478 269 278 478 272 278 minecraft:deepslate_tiles
setblock 479 269 276 minecraft:cobbled_deepslate
fill 479 269 277 479 272 277 minecraft:deepslate_tiles
setblock 479 269 316 minecraft:cobbled_deepslate
fill 480 269 276 480 272 276 minecraft:deepslate_tiles
setblock 480 269 315 minecraft:cobbled_deepslate
fill 480 269 316 480 272 316 minecraft:deepslate_tiles
setblock 481 269 279 minecraft:cobbled_deepslate
setblock 481 269 286 minecraft:light[level=13]
setblock 481 269 294 minecraft:light[level=13]
setblock 481 269 302 minecraft:light[level=13]
setblock 481 269 310 minecraft:light[level=13]
fill 481 269 315 483 269 315 minecraft:deepslate_tiles
setblock 482 269 278 minecraft:cobbled_deepslate
setblock 482 269 279 minecraft:deepslate_tiles
setblock 483 269 277 minecraft:cobbled_deepslate
fill 483 269 278 483 270 278 minecraft:deepslate_tiles
setblock 484 269 276 minecraft:cobbled_deepslate
fill 484 269 277 484 272 277 minecraft:deepslate_tiles
setblock 484 269 316 minecraft:cobbled_deepslate
fill 485 269 276 488 269 276 minecraft:deepslate_tiles
setblock 485 269 278 minecraft:deepslate_tiles
fill 485 269 316 485 271 316 minecraft:deepslate_tiles
setblock 488 269 277 minecraft:cobbled_deepslate
setblock 489 269 276 minecraft:cobbled_deepslate
fill 489 269 277 489 270 277 minecraft:deepslate_tiles
setblock 489 269 278 minecraft:light[level=13]
setblock 489 269 286 minecraft:light[level=13]
setblock 489 269 294 minecraft:light[level=13]
setblock 489 269 302 minecraft:light[level=13]
setblock 489 269 310 minecraft:light[level=13]
setblock 489 269 316 minecraft:cobbled_deepslate
fill 490 269 276 490 272 276 minecraft:deepslate_tiles
fill 490 269 316 490 272 316 minecraft:deepslate_tiles
setblock 491 269 315 minecraft:deepslate_tiles
setblock 493 269 277 minecraft:cobbled_deepslate
setblock 494 269 276 minecraft:cobbled_deepslate
fill 494 269 277 494 269 278 minecraft:deepslate_tiles
setblock 494 269 316 minecraft:cobbled_deepslate
fill 495 269 276 495 272 276 minecraft:deepslate_tiles
fill 495 269 278 496 269 278 minecraft:deepslate_tiles
setblock 495 269 315 minecraft:cobbled_deepslate
fill 495 269 316 495 272 316 minecraft:deepslate_tiles
setblock 496 269 314 minecraft:cobbled_deepslate
fill 496 269 315 496 272 315 minecraft:deepslate_tiles
setblock 497 269 278 minecraft:cobbled_deepslate
setblock 497 269 286 minecraft:light[level=13]
setblock 497 269 294 minecraft:light[level=13]
setblock 497 269 302 minecraft:light[level=13]
setblock 497 269 310 minecraft:light[level=13]
setblock 497 269 314 minecraft:deepslate_tiles
setblock 498 269 277 minecraft:cobbled_deepslate
setblock 498 269 278 minecraft:deepslate_tiles
setblock 499 269 276 minecraft:cobbled_deepslate
fill 499 269 277 499 271 277 minecraft:deepslate_tiles
setblock 499 269 316 minecraft:cobbled_deepslate
fill 500 269 276 500 272 276 minecraft:deepslate_tiles
setblock 500 269 315 minecraft:cobbled_deepslate
fill 500 269 316 500 272 316 minecraft:deepslate_tiles
fill 501 269 315 501 270 315 minecraft:deepslate_tiles
setblock 504 269 276 minecraft:cobbled_deepslate
setblock 504 269 316 minecraft:cobbled_deepslate
setblock 505 269 276 minecraft:deepslate_tiles
setblock 505 269 278 minecraft:light[level=13]
setblock 505 269 286 minecraft:light[level=13]
setblock 505 269 294 minecraft:light[level=13]
setblock 505 269 302 minecraft:light[level=13]
setblock 505 269 310 minecraft:light[level=13]
setblock 505 269 316 minecraft:deepslate_tiles
setblock 510 269 295 minecraft:cobbled_deepslate
fill 510 269 296 510 271 296 minecraft:deepslate_tiles
setblock 510 269 300 minecraft:cobbled_deepslate
fill 510 269 301 510 272 301 minecraft:deepslate_tiles
setblock 511 269 279 minecraft:cobbled_deepslate
fill 511 269 280 511 271 281 minecraft:deepslate_tiles
setblock 511 269 294 minecraft:cobbled_deepslate
fill 511 269 295 511 272 295 minecraft:deepslate_tiles
setblock 511 269 299 minecraft:cobbled_deepslate
fill 511 269 300 511 272 300 minecraft:deepslate_tiles
setblock 511 269 304 minecraft:cobbled_deepslate
fill 511 269 305 511 272 305 minecraft:deepslate_tiles
fill 512 269 284 512 308 284 minecraft:deepslate_tiles
fill 512 269 293 512 308 293 minecraft:deepslate_tiles
fill 470 270 314 470 308 314 minecraft:deepslate_tiles
fill 471 270 276 471 270 277 minecraft:deepslate_tiles
setblock 471 270 278 minecraft:cobbled_deepslate
fill 471 270 279 471 270 282 minecraft:deepslate_tiles
setblock 471 270 283 minecraft:cobbled_deepslate
fill 471 270 284 471 272 284 minecraft:deepslate_tiles
setblock 471 270 288 minecraft:cobbled_deepslate
fill 471 270 289 471 272 289 minecraft:deepslate_tiles
setblock 471 270 293 minecraft:cobbled_deepslate
fill 471 270 294 471 272 294 minecraft:deepslate_tiles
setblock 471 270 298 minecraft:cobbled_deepslate
fill 471 270 299 471 272 299 minecraft:deepslate_tiles
setblock 471 270 302 minecraft:deepslate_tiles
setblock 471 270 303 minecraft:cobbled_deepslate
setblock 472 270 276 minecraft:deepslate_tiles
setblock 472 270 277 minecraft:cobbled_deepslate
fill 472 270 278 475 270 278 minecraft:deepslate_tiles
setblock 472 270 281 minecraft:deepslate_tiles
setblock 472 270 282 minecraft:cobbled_deepslate
fill 472 270 283 472 272 283 minecraft:deepslate_tiles
fill 472 270 285 472 271 285 minecraft:deepslate_tiles
setblock 472 270 297 minecraft:cobbled_deepslate
fill 472 270 298 472 272 298 minecraft:deepslate_tiles
setblock 473 270 276 minecraft:cobbled_deepslate
fill 473 270 277 473 272 277 minecraft:deepslate_tiles
setblock 473 270 281 minecraft:cobbled_deepslate
fill 473 270 282 473 272 282 minecraft:deepslate_tiles
setblock 473 270 316 minecraft:cobbled_deepslate
fill 474 270 276 474 272 276 minecraft:deepslate_tiles
setblock 474 270 279 minecraft:deepslate_tiles
fill 474 270 316 474 272 316 minecraft:deepslate_tiles
setblock 475 270 279 minecraft:cobbled_deepslate
fill 475 270 317 475 308 317 minecraft:deepslate_tiles
setblock 476 270 275 minecraft:white_wool
setblock 476 270 278 minecraft:cobbled_deepslate
fill 476 270 279 476 272 279 minecraft:deepslate_tiles
setblock 477 270 277 minecraft:cobbled_deepslate
fill 477 270 278 477 272 278 minecraft:deepslate_tiles
setblock 478 270 276 minecraft:cobbled_deepslate
fill 478 270 277 478 272 277 minecraft:deepslate_tiles
setblock 478 270 316 minecraft:cobbled_deepslate
fill 479 270 276 479 272 276 minecraft:deepslate_tiles
setblock 479 270 315 minecraft:cobbled_deepslate
fill 479 270 316 479 272 316 minecraft:deepslate_tiles
setblock 480 270 279 minecraft:cobbled_deepslate
setblock 480 270 315 minecraft:deepslate_tiles
setblock 481 270 278 minecraft:cobbled_deepslate
setblock 481 270 279 minecraft:deepslate_tiles
setblock 482 270 277 minecraft:cobbled_deepslate
fill 482 270 278 482 271 278 minecraft:deepslate_tiles
setblock 483 270 276 minecraft:cobbled_deepslate
fill 483 270 277 483 272 277 minecraft:deepslate_tiles
setblock 483 270 316 minecraft:cobbled_deepslate
fill 484 270 276 487 270 276 minecraft:deepslate_tiles
fill 484 270 316 484 271 316 minecraft:deepslate_tiles
setblock 487 270 277 minecraft:cobbled_deepslate
setblock 488 270 276 minecraft:cobbled_deepslate
setblock 488 270 277 minecraft:deepslate_tiles
setblock 488 270 316 minecraft:cobbled_deepslate
fill 489 270 276 489 272 276 minecraft:deepslate_tiles
fill 489 270 316 489 272 316 minecraft:deepslate_tiles
setblock 492 270 277 minecraft:cobbled_deepslate
setblock 493 270 276 minecraft:cobbled_deepslate
fill 493 270 277 494 272 277 minecraft:deepslate_tiles
setblock 493 270 316 minecraft:cobbled_deepslate
fill 494 270 276 494 272 276 minecraft:deepslate_tiles
setblock 494 270 315 minecraft:cobbled_deepslate
fill 494 270 316 494 272 316 minecraft:deepslate_tiles
setblock 495 270 278 minecraft:deepslate_tiles
fill 495 270 315 495 272 315 minecraft:deepslate_tiles
fill 496 270 275 499 296 275 minecraft:deepslate_tiles
setblock 496 270 278 minecraft:cobbled_deepslate
setblock 497 270 277 minecraft:cobbled_deepslate
setblock 497 270 278 minecraft:deepslate_tiles
setblock 498 270 276 minecraft:cobbled_deepslate
fill 498 270 277 498 272 277 minecraft:deepslate_tiles
setblock 498 270 316 minecraft:cobbled_deepslate
fill 499 270 276 499 272 276 minecraft:deepslate_tiles
setblock 499 270 315 minecraft:cobbled_deepslate
fill 499 270 316 499 272 316 minecraft:deepslate_tiles
setblock 500 270 275 minecraft:redstone_block
setblock 500 270 315 minecraft:deepslate_tiles
setblock 503 270 276 minecraft:cobbled_deepslate
setblock 503 270 316 minecraft:cobbled_deepslate
setblock 510 270 295 minecraft:deepslate_tiles
setblock 510 270 299 minecraft:cobbled_deepslate
fill 510 270 300 510 272 300 minecraft:deepslate_tiles
setblock 511 270 277 minecraft:deepslate_tiles
setblock 511 270 278 minecraft:cobbled_deepslate
fill 511 270 279 511 272 279 minecraft:deepslate_tiles
setblock 511 270 282 minecraft:deepslate_tiles
setblock 511 270 283 minecraft:cobbled_deepslate
setblock 511 270 293 minecraft:cobbled_deepslate
fill 511 270 294 511 272 294 minecraft:deepslate_tiles
setblock 511 270 298 minecraft:cobbled_deepslate
fill 511 270 299 511 272 299 minecraft:deepslate_tiles
setblock 511 270 303 minecraft:cobbled_deepslate
fill 511 270 304 511 272 304 minecraft:deepslate_tiles
setblock 512 270 292 minecraft:redstone_block
setblock 471 271 276 minecraft:deepslate_tiles
setblock 471 271 277 minecraft:cobbled_deepslate
fill 471 271 278 471 271 281 minecraft:deepslate_tiles
setblock 471 271 282 minecraft:cobbled_deepslate
fill 471 271 283 471 272 283 minecraft:deepslate_tiles
setblock 471 271 287 minecraft:cobbled_deepslate
fill 471 271 288 471 272 288 minecraft:deepslate_tiles
setblock 471 271 292 minecraft:cobbled_deepslate
fill 471 271 293 471 272 293 minecraft:deepslate_tiles
setblock 471 271 297 minecraft:cobbled_deepslate
fill 471 271 298 471 272 298 minecraft:deepslate_tiles
setblock 471 271 302 minecraft:cobbled_deepslate
fill 471 271 303 471 272 303 minecraft:deepslate_tiles
setblock 472 271 276 minecraft:cobbled_deepslate
fill 472 271 277 472 272 278 minecraft:deepslate_tiles
setblock 472 271 280 minecraft:deepslate_tiles
setblock 472 271 281 minecraft:cobbled_deepslate
fill 472 271 282 472 272 282 minecraft:deepslate_tiles
setblock 472 271 296 minecraft:cobbled_deepslate
setblock 472 271 297 minecraft:deepslate_tiles
setblock 472 271 301 minecraft:cobbled_deepslate
fill 473 271 276 473 272 276 minecraft:deepslate_tiles
fill 473 271 278 474 271 278 minecraft:deepslate_tiles
setblock 473 271 280 minecraft:cobbled_deepslate
fill 473 271 281 473 272 281 minecraft:deepslate_tiles
fill 473 271 283 473 272 283 minecraft:deepslate_tiles
setblock 473 271 285 minecraft:light[level=12]
setblock 473 271 292 minecraft:light[level=12]
setblock 473 271 299 minecraft:light[level=12]
setblock 473 271 306 minecraft:light[level=12]
setblock 473 271 313 minecraft:light[level=12]
setblock 474 271 279 minecraft:cobbled_deepslate
fill 474 271 280 474 272 280 minecraft:deepslate_tiles
setblock 475 271 278 minecraft:cobbled_deepslate
fill 475 271 279 475 272 279 minecraft:deepslate_tiles
fill 476 271 275 476 276 275 minecraft:deepslate_tiles
setblock 476 271 277 minecraft:cobbled_deepslate
fill 476 271 278 476 272 278 minecraft:deepslate_tiles
setblock 477 271 276 minecraft:cobbled_deepslate
fill 477 271 277 477 272 277 minecraft:deepslate_tiles
setblock 477 271 316 minecraft:cobbled_deepslate
fill 478 271 276 478 272 276 minecraft:deepslate_tiles
fill 478 271 316 478 272 316 minecraft:deepslate_tiles
setblock 479 271 279 minecraft:cobbled_deepslate
setblock 480 271 278 minecraft:cobbled_deepslate
setblock 480 271 279 minecraft:deepslate_tiles
setblock 480 271 285 minecraft:light[level=12]
setblock 480 271 292 minecraft:light[level=12]
setblock 480 271 299 minecraft:light[level=12]
setblock 480 271 306 minecraft:light[level=12]
setblock 480 271 313 minecraft:light[level=12]
setblock 481 271 277 minecraft:cobbled_deepslate
fill 481 271 278 481 272 278 minecraft:deepslate_tiles
setblock 482 271 276 minecraft:cobbled_deepslate
fill 482 271 277 482 272 277 minecraft:deepslate_tiles
setblock 482 271 316 minecraft:cobbled_deepslate
fill 483 271 276 486 271 276 minecraft:deepslate_tiles
setblock 483 271 316 minecraft:deepslate_tiles
setblock 486 271 277 minecraft:cobbled_deepslate
setblock 487 271 276 minecraft:cobbled_deepslate
setblock 487 271 278 minecraft:light[level=12]
setblock 487 271 285 minecraft:light[level=12]
setblock 487 271 292 minecraft:light[level=12]
setblock 487 271 299 minecraft:light[level=12]
setblock 487 271 306 minecraft:light[level=12]
setblock 487 271 313 minecraft:light[level=12]
setblock 487 271 316 minecraft:cobbled_deepslate
fill 488 271 276 488 272 276 minecraft:deepslate_tiles
setblock 488 271 316 minecraft:deepslate_tiles
setblock 491 271 277 minecraft:cobbled_deepslate
setblock 492 271 276 minecraft:cobbled_deepslate
fill 492 271 277 492 272 277 minecraft:deepslate_tiles
setblock 492 271 316 minecraft:cobbled_deepslate
fill 493 271 276 493 272 276 minecraft:deepslate_tiles
setblock 493 271 315 minecraft:cobbled_deepslate
fill 493 271 316 493 272 316 minecraft:deepslate_tiles
setblock 494 271 278 minecraft:light[level=12]
setblock 494 271 285 minecraft:light[level=12]
setblock 494 271 292 minecraft:light[level=12]
setblock 494 271 299 minecraft:light[level=12]
setblock 494 271 306 minecraft:light[level=12]
setblock 494 271 313 minecraft:light[level=12]
fill 494 271 315 494 272 315 minecraft:deepslate_tiles
setblock 496 271 277 minecraft:cobbled_deepslate
setblock 497 271 276 minecraft:cobbled_deepslate
fill 497 271 277 497 272 277 minecraft:deepslate_tiles
setblock 497 271 316 minecraft:cobbled_deepslate
fill 498 271 276 498 272 276 minecraft:deepslate_tiles
setblock 498 271 315 minecraft:cobbled_deepslate
fill 498 271 316 498 272 316 minecraft:deepslate_tiles
setblock 499 271 315 minecraft:deepslate_tiles
fill 500 271 275 500 308 275 minecraft:deepslate_tiles
setblock 501 271 278 minecraft:light[level=12]
setblock 501 271 285 minecraft:light[level=12]
setblock 501 271 292 minecraft:light[level=12]
setblock 501 271 299 minecraft:light[level=12]
setblock 501 271 306 minecraft:light[level=12]
setblock 501 271 313 minecraft:light[level=12]
setblock 502 271 276 minecraft:cobbled_deepslate
setblock 502 271 316 minecraft:cobbled_deepslate
setblock 508 271 278 minecraft:light[level=12]
setblock 508 271 285 minecraft:light[level=12]
setblock 508 271 292 minecraft:light[level=12]
setblock 508 271 299 minecraft:light[level=12]
setblock 508 271 306 minecraft:light[level=12]
setblock 508 271 313 minecraft:light[level=12]
setblock 510 271 298 minecraft:cobbled_deepslate
fill 510 271 299 510 272 299 minecraft:deepslate_tiles
setblock 510 271 302 minecraft:deepslate_tiles
setblock 510 271 303 minecraft:cobbled_deepslate
setblock 511 271 277 minecraft:cobbled_deepslate
fill 511 271 278 511 272 278 minecraft:deepslate_tiles
setblock 511 271 282 minecraft:cobbled_deepslate
fill 511 271 283 511 272 284 minecraft:deepslate_tiles
setblock 511 271 292 minecraft:cobbled_deepslate
fill 511 271 293 511 272 293 minecraft:deepslate_tiles
setblock 511 271 297 minecraft:cobbled_deepslate
fill 511 271 298 511 272 298 minecraft:deepslate_tiles
setblock 511 271 302 minecraft:cobbled_deepslate
fill 511 271 303 511 272 303 minecraft:deepslate_tiles
setblock 511 271 306 minecraft:deepslate_tiles
fill 512 271 292 512 281 292 minecraft:deepslate_tiles
setblock 471 272 276 minecraft:cobbled_deepslate
fill 471 272 277 471 272 280 minecraft:deepslate_tiles
setblock 471 272 281 minecraft:cobbled_deepslate
setblock 471 272 282 minecraft:deepslate_tiles
setblock 471 272 286 minecraft:cobbled_deepslate
setblock 471 272 287 minecraft:deepslate_tiles
setblock 471 272 296 minecraft:cobbled_deepslate
setblock 471 272 297 minecraft:deepslate_tiles
setblock 471 272 301 minecraft:cobbled_deepslate
setblock 471 272 302 minecraft:deepslate_tiles
setblock 471 272 304 minecraft:deepslate_tiles
setblock 472 272 276 minecraft:deepslate_tiles
setblock 472 272 280 minecraft:cobbled_deepslate
setblock 472 272 281 minecraft:deepslate_tiles
setblock 472 272 285 minecraft:cobbled_deepslate
setblock 472 272 286 minecraft:deepslate_tiles
setblock 472 272 300 minecraft:cobbled_deepslate
setblock 472 272 301 minecraft:deepslate_tiles
setblock 473 272 278 minecraft:deepslate_tiles
setblock 473 272 279 minecraft:cobbled_deepslate
setblock 473 272 280 minecraft:deepslate_tiles
setblock 473 272 284 minecraft:cobbled_deepslate
setblock 474 272 278 minecraft:cobbled_deepslate
setblock 474 272 279 minecraft:deepslate_tiles
setblock 474 272 281 minecraft:deepslate_tiles
setblock 475 272 277 minecraft:cobbled_deepslate
setblock 475 272 278 minecraft:deepslate_tiles
setblock 476 272 276 minecraft:cobbled_deepslate
setblock 476 272 277 minecraft:deepslate_tiles
setblock 476 272 316 minecraft:cobbled_deepslate
setblock 477 272 276 minecraft:deepslate_tiles
setblock 477 272 316 minecraft:deepslate_tiles
setblock 478 272 279 minecraft:cobbled_deepslate
setblock 479 272 278 minecraft:cobbled_deepslate
setblock 480 272 277 minecraft:cobbled_deepslate
setblock 480 272 278 minecraft:deepslate_tiles
setblock 481 272 276 minecraft:cobbled_deepslate
setblock 481 272 277 minecraft:deepslate_tiles
setblock 481 272 316 minecraft:cobbled_deepslate
fill 482 272 276 485 272 276 minecraft:deepslate_tiles
setblock 482 272 316 minecraft:deepslate_tiles
setblock 486 272 276 minecraft:cobbled_deepslate
setblock 487 272 276 minecraft:deepslate_tiles
setblock 491 272 276 minecraft:cobbled_deepslate
setblock 491 272 277 minecraft:deepslate_tiles
setblock 491 272 316 minecraft:cobbled_deepslate
setblock 492 272 276 minecraft:deepslate_tiles
setblock 492 272 316 minecraft:deepslate_tiles
setblock 493 272 315 minecraft:deepslate_tiles
setblock 495 272 277 minecraft:cobbled_deepslate
setblock 496 272 276 minecraft:cobbled_deepslate
setblock 496 272 277 minecraft:deepslate_tiles
setblock 496 272 316 minecraft:cobbled_deepslate
setblock 497 272 276 minecraft:deepslate_tiles
setblock 497 272 315 minecraft:cobbled_deepslate
setblock 497 272 316 minecraft:deepslate_tiles
setblock 498 272 315 minecraft:deepslate_tiles
setblock 510 272 297 minecraft:cobbled_deepslate
setblock 510 272 298 minecraft:deepslate_tiles
setblock 510 272 302 minecraft:cobbled_deepslate
setblock 510 272 303 minecraft:deepslate_tiles
setblock 511 272 277 minecraft:deepslate_tiles
setblock 511 272 280 minecraft:deepslate_tiles
setblock 511 272 281 minecraft:cobbled_deepslate
setblock 511 272 282 minecraft:deepslate_tiles
setblock 511 272 285 minecraft:deepslate_tiles
setblock 511 272 286 minecraft:cobbled_deepslate
setblock 511 272 292 minecraft:deepslate_tiles
setblock 511 272 296 minecraft:cobbled_deepslate
setblock 511 272 297 minecraft:deepslate_tiles
setblock 511 272 301 minecraft:cobbled_deepslate
setblock 511 272 302 minecraft:deepslate_tiles
setblock 511 272 306 minecraft:cobbled_deepslate
setblock 470 273 310 minecraft:white_wool
fill 470 273 311 470 308 311 minecraft:deepslate_tiles
setblock 478 273 317 minecraft:redstone_block
fill 470 274 310 470 308 310 minecraft:deepslate_tiles
fill 477 274 290 477 277 291 minecraft:white_terracotta
fill 478 274 290 478 277 290 minecraft:white_terracotta
fill 478 274 317 478 308 317 minecraft:deepslate_tiles
fill 470 275 292 470 276 295 minecraft:deepslate_tiles
setblock 470 275 296 minecraft:white_wool
fill 476 275 290 476 276 290 minecraft:white_terracotta
fill 477 275 289 477 276 289 minecraft:white_terracotta
fill 478 275 291 478 276 291 minecraft:white_terracotta
fill 470 276 296 470 308 296 minecraft:deepslate_tiles
setblock 470 276 315 minecraft:redstone_block
fill 470 276 316 470 308 316 minecraft:deepslate_tiles
fill 470 277 292 470 308 293 minecraft:deepslate_tiles
setblock 470 277 294 minecraft:white_wool
setblock 470 277 295 minecraft:deepslate_tiles
fill 470 277 315 470 308 315 minecraft:deepslate_tiles
setblock 473 277 278 minecraft:light[level=13]
setblock 473 277 285 minecraft:light[level=12]
setblock 473 277 286 minecraft:light[level=13]
setblock 473 277 292 minecraft:light[level=12]
setblock 473 277 294 minecraft:light[level=13]
setblock 473 277 299 minecraft:light[level=12]
setblock 473 277 302 minecraft:light[level=13]
setblock 473 277 306 minecraft:light[level=12]
setblock 473 277 310 minecraft:light[level=13]
setblock 473 277 313 minecraft:light[level=12]
setblock 476 277 275 minecraft:white_wool
setblock 480 277 278 minecraft:light[level=12]
setblock 480 277 285 minecraft:light[level=12]
setblock 480 277 292 minecraft:light[level=12]
setblock 480 277 299 minecraft:light[level=12]
setblock 480 277 306 minecraft:light[level=12]
setblock 480 277 313 minecraft:light[level=12]
setblock 481 277 278 minecraft:light[level=13]
setblock 481 277 286 minecraft:light[level=13]
setblock 481 277 294 minecraft:light[level=13]
setblock 481 277 302 minecraft:light[level=13]
setblock 481 277 310 minecraft:light[level=13]
setblock 487 277 278 minecraft:light[level=12]
setblock 487 277 285 minecraft:light[level=12]
setblock 487 277 292 minecraft:light[level=12]
setblock 487 277 299 minecraft:light[level=12]
setblock 487 277 306 minecraft:light[level=12]
setblock 487 277 313 minecraft:light[level=12]
setblock 489 277 278 minecraft:light[level=13]
setblock 489 277 286 minecraft:light[level=13]
setblock 489 277 302 minecraft:light[level=13]
setblock 489 277 310 minecraft:light[level=13]
setblock 494 277 278 minecraft:light[level=12]
setblock 494 277 285 minecraft:light[level=12]
setblock 494 277 299 minecraft:light[level=12]
setblock 494 277 306 minecraft:light[level=12]
setblock 494 277 313 minecraft:light[level=12]
setblock 497 277 278 minecraft:light[level=13]
setblock 497 277 286 minecraft:light[level=13]
setblock 497 277 294 minecraft:light[level=13]
setblock 497 277 302 minecraft:light[level=13]
setblock 497 277 310 minecraft:light[level=13]
setblock 501 277 278 minecraft:light[level=12]
setblock 501 277 285 minecraft:light[level=12]
setblock 501 277 292 minecraft:light[level=12]
setblock 501 277 299 minecraft:light[level=12]
setblock 501 277 306 minecraft:light[level=12]
setblock 501 277 313 minecraft:light[level=12]
setblock 505 277 278 minecraft:light[level=13]
setblock 505 277 286 minecraft:light[level=13]
setblock 505 277 294 minecraft:light[level=13]
setblock 505 277 302 minecraft:light[level=13]
setblock 505 277 310 minecraft:light[level=13]
setblock 508 277 278 minecraft:light[level=12]
setblock 508 277 285 minecraft:light[level=12]
setblock 508 277 292 minecraft:light[level=12]
setblock 508 277 299 minecraft:light[level=12]
setblock 508 277 306 minecraft:light[level=12]
setblock 508 277 313 minecraft:light[level=12]
setblock 512 277 290 minecraft:redstone_block
setblock 470 278 286 minecraft:white_wool
fill 470 278 287 470 308 287 minecraft:deepslate_tiles
fill 470 278 294 470 308 294 minecraft:deepslate_tiles
setblock 470 278 295 minecraft:white_wool
fill 471 278 276 488 278 316 minecraft:black_stained_glass
fill 476 278 275 476 308 275 minecraft:deepslate_tiles
fill 489 278 276 489 278 293 minecraft:black_stained_glass
fill 489 278 295 489 278 316 minecraft:black_stained_glass
fill 490 278 276 491 278 291 minecraft:black_stained_glass
fill 490 278 297 491 278 316 minecraft:black_stained_glass
fill 492 278 276 511 278 290 minecraft:black_stained_glass
fill 492 278 298 511 278 316 minecraft:black_stained_glass
fill 493 278 291 511 278 291 minecraft:black_stained_glass
fill 493 278 297 511 278 297 minecraft:black_stained_glass
fill 495 278 292 511 278 293 minecraft:black_stained_glass
fill 495 278 295 511 278 296 minecraft:black_stained_glass
fill 496 278 294 511 278 294 minecraft:black_stained_glass
fill 512 278 290 512 308 290 minecraft:deepslate_tiles
fill 470 279 286 470 291 286 minecraft:deepslate_tiles
fill 470 279 295 470 308 295 minecraft:deepslate_tiles
fill 471 279 276 476 279 276 minecraft:black_stained_glass
fill 471 279 277 471 279 278 minecraft:white_wool
fill 471 279 279 471 279 282 minecraft:black_stained_glass
setblock 471 279 283 minecraft:white_wool
fill 471 279 284 471 279 288 minecraft:black_stained_glass
fill 471 279 289 472 279 289 minecraft:white_wool
fill 471 279 290 472 279 291 minecraft:black_stained_glass
fill 471 279 292 471 279 297 minecraft:white_wool
fill 471 279 298 472 279 298 minecraft:black_stained_glass
fill 471 279 299 472 279 299 minecraft:white_wool
fill 471 279 300 471 279 305 minecraft:black_stained_glass
setblock 471 279 306 minecraft:white_wool
fill 471 279 307 471 279 309 minecraft:black_stained_glass
fill 471 279 310 471 279 311 minecraft:white_wool
fill 471 279 312 472 279 315 minecraft:black_stained_glass
setblock 471 279 316 minecraft:white_wool
fill 472 279 277 483 279 277 minecraft:black_stained_glass
fill 472 279 278 473 279 278 minecraft:white_wool
fill 472 279 279 472 279 280 minecraft:black_stained_glass
setblock 472 279 281 minecraft:white_wool
fill 472 279 282 472 279 287 minecraft:black_stained_glass
setblock 472 279 288 minecraft:white_wool
fill 472 279 292 473 279 297 minecraft:black_stained_glass
fill 472 279 300 474 279 300 minecraft:black_stained_glass
setblock 472 279 301 minecraft:white_wool
fill 472 279 302 472 279 307 minecraft:black_stained_glass
setblock 472 279 308 minecraft:white_wool
setblock 472 279 309 minecraft:black_stained_glass
fill 472 279 310 473 279 310 minecraft:white_wool
fill 472 279 311 478 279 311 minecraft:black_stained_glass
fill 472 279 316 480 279 316 minecraft:black_stained_glass
fill 473 279 279 474 279 280 minecraft:white_wool
fill 473 279 281 473 279 285 minecraft:black_stained_glass
setblock 473 279 286 minecraft:white_wool
fill 473 279 287 474 279 289 minecraft:black_stained_glass
fill 473 279 290 476 279 290 minecraft:white_wool
fill 473 279 291 477 279 291 minecraft:black_stained_glass
fill 473 279 298 476 279 298 minecraft:white_wool
fill 473 279 299 480 279 299 minecraft:black_stained_glass
fill 473 279 301 474 279 302 minecraft:black_stained_glass
setblock 473 279 303 minecraft:white_wool
fill 473 279 304 473 279 308 minecraft:black_stained_glass
fill 473 279 309 474 279 309 minecraft:white_wool
fill 473 279 312 479 279 313 minecraft:black_stained_glass
setblock 473 279 314 minecraft:white_wool
fill 473 279 315 478 279 315 minecraft:black_stained_glass
fill 474 279 278 478 279 278 minecraft:black_stained_glass
fill 474 279 281 474 279 283 minecraft:black_stained_glass
setblock 474 279 284 minecraft:white_wool
fill 474 279 285 475 279 286 minecraft:black_stained_glass
fill 474 279 292 474 279 297 minecraft:white_wool
fill 474 279 303 475 279 304 minecraft:black_stained_glass
setblock 474 279 305 minecraft:white_wool
fill 474 279 306 474 279 307 minecraft:black_stained_glass
fill 474 279 308 476 279 308 minecraft:white_wool
fill 474 279 310 477 279 310 minecraft:black_stained_glass
fill 474 279 314 477 279 314 minecraft:black_stained_glass
fill 475 279 279 477 279 279 minecraft:black_stained_glass
fill 475 279 280 475 279 282 minecraft:white_wool
fill 475 279 283 477 279 284 minecraft:black_stained_glass
fill 475 279 287 478 279 287 minecraft:black_stained_glass
fill 475 279 288 475 279 289 minecraft:white_wool
fill 475 279 292 476 279 297 minecraft:black_stained_glass
fill 475 279 300 475 279 301 minecraft:white_wool
fill 475 279 302 478 279 302 minecraft:black_stained_glass
fill 475 279 305 476 279 306 minecraft:black_stained_glass
fill 475 279 307 476 279 307 minecraft:white_wool
fill 475 279 309 476 279 309 minecraft:black_stained_glass
setblock 476 279 280 minecraft:black_stained_glass
setblock 476 279 281 minecraft:white_wool
setblock 476 279 282 minecraft:black_stained_glass
fill 476 279 285 480 279 285 minecraft:black_stained_glass
setblock 476 279 286 minecraft:white_wool
fill 476 279 288 477 279 289 minecraft:black_stained_glass
fill 476 279 300 477 279 301 minecraft:black_stained_glass
setblock 476 279 303 minecraft:white_wool
fill 476 279 304 478 279 304 minecraft:black_stained_glass
setblock 477 279 276 minecraft:white_wool
setblock 477 279 280 minecraft:white_wool
fill 477 279 281 479 279 281 minecraft:black_stained_glass
setblock 477 279 282 minecraft:white_wool
fill 477 279 286 481 279 286 minecraft:black_stained_glass
fill 477 279 290 480 279 290 minecraft:black_stained_glass
fill 477 279 292 477 279 297 minecraft:white_wool
fill 477 279 298 486 279 298 minecraft:black_stained_glass
fill 477 279 303 480 279 303 minecraft:black_stained_glass
setblock 477 279 305 minecraft:black_stained_glass
fill 477 279 306 478 279 306 minecraft:white_wool
fill 477 279 307 478 279 308 minecraft:black_stained_glass
setblock 477 279 309 minecraft:white_wool
fill 478 279 276 481 279 276 minecraft:black_stained_glass
setblock 478 279 279 minecraft:white_wool
fill 478 279 280 484 279 280 minecraft:black_stained_glass
setblock 478 279 282 minecraft:black_stained_glass
setblock 478 279 283 minecraft:white_wool
setblock 478 279 284 minecraft:black_stained_glass
fill 478 279 288 481 279 288 minecraft:black_stained_glass
setblock 478 279 289 minecraft:white_wool
fill 478 279 291 480 279 291 minecraft:white_wool
fill 478 279 292 479 279 296 minecraft:black_stained_glass
fill 478 279 297 480 279 297 minecraft:white_wool
setblock 478 279 300 minecraft:white_wool
fill 478 279 301 481 279 301 minecraft:black_stained_glass
setblock 478 279 305 minecraft:white_wool
fill 478 279 309 480 279 309 minecraft:black_stained_glass
setblock 478 279 310 minecraft:white_wool
setblock 478 279 314 minecraft:white_wool
setblock 479 279 278 minecraft:white_wool
fill 479 279 279 482 279 279 minecraft:black_stained_glass
setblock 479 279 282 minecraft:white_wool
fill 479 279 283 486 279 283 minecraft:black_stained_glass
fill 479 279 284 481 279 284 minecraft:white_wool
setblock 479 279 287 minecraft:white_wool
fill 479 279 289 484 279 289 minecraft:black_stained_glass
fill 479 279 300 484 279 300 minecraft:black_stained_glass
setblock 479 279 302 minecraft:white_wool
fill 479 279 304 480 279 304 minecraft:white_wool
fill 479 279 305 480 279 306 minecraft:black_stained_glass
setblock 479 279 307 minecraft:white_wool
setblock 479 279 308 minecraft:black_stained_glass
fill 479 279 310 482 279 310 minecraft:black_stained_glass
setblock 479 279 311 minecraft:white_wool
fill 479 279 314 481 279 314 minecraft:black_stained_glass
setblock 479 279 315 minecraft:white_wool
fill 480 279 278 483 279 278 minecraft:black_stained_glass
setblock 480 279 281 minecraft:white_wool
fill 480 279 282 483 279 282 minecraft:black_stained_glass
fill 480 279 287 482 279 287 minecraft:black_stained_glass
fill 480 279 292 482 279 292 minecraft:black_stained_glass
fill 480 279 293 480 279 296 minecraft:white_wool
fill 480 279 302 481 279 302 minecraft:black_stained_glass
fill 480 279 307 485 279 307 minecraft:black_stained_glass
setblock 480 279 308 minecraft:white_wool
fill 480 279 311 483 279 311 minecraft:black_stained_glass
setblock 480 279 312 minecraft:white_wool
fill 480 279 313 481 279 313 minecraft:black_stained_glass
fill 480 279 315 481 279 315 minecraft:black_stained_glass
fill 481 279 281 485 279 281 minecraft:black_stained_glass
setblock 481 279 285 minecraft:white_wool
setblock 481 279 290 minecraft:white_wool
fill 481 279 291 486 279 291 minecraft:black_stained_glass
fill 481 279 293 482 279 297 minecraft:black_stained_glass
setblock 481 279 299 minecraft:white_wool
setblock 481 279 303 minecraft:white_wool
fill 481 279 304 486 279 304 minecraft:black_stained_glass
setblock 481 279 305 minecraft:white_wool
setblock 481 279 306 minecraft:black_stained_glass
fill 481 279 308 484 279 308 minecraft:black_stained_glass
setblock 481 279 309 minecraft:white_wool
fill 481 279 312 482 279 312 minecraft:black_stained_glass
fill 481 279 316 482 279 316 minecraft:white_wool
fill 482 279 276 483 279 276 minecraft:white_wool
fill 482 279 284 484 279 285 minecraft:black_stained_glass
setblock 482 279 286 minecraft:white_wool
setblock 482 279 288 minecraft:white_wool
fill 482 279 290 483 279 290 minecraft:black_stained_glass
fill 482 279 299 483 279 299 minecraft:black_stained_glass
fill 482 279 301 482 279 302 minecraft:white_wool
fill 482 279 303 488 279 303 minecraft:black_stained_glass
fill 482 279 305 485 279 305 minecraft:black_stained_glass
setblock 482 279 306 minecraft:white_wool
fill 482 279 309 484 279 309 minecraft:black_stained_glass
fill 482 279 313 482 279 315 minecraft:white_wool
setblock 483 279 279 minecraft:white_wool
fill 483 279 286 487 279 286 minecraft:black_stained_glass
setblock 483 279 287 minecraft:white_wool
fill 483 279 288 485 279 288 minecraft:black_stained_glass
fill 483 279 292 483 279 296 minecraft:white_wool
fill 483 279 297 488 279 297 minecraft:black_stained_glass
setblock 483 279 301 minecraft:white_wool
fill 483 279 302 486 279 302 minecraft:black_stained_glass
fill 483 279 306 485 279 306 minecraft:black_stained_glass
fill 483 279 310 484 279 310 minecraft:white_wool
fill 483 279 312 483 279 314 minecraft:white_wool
fill 483 279 315 486 279 316 minecraft:black_stained_glass
fill 484 279 276 491 279 276 minecraft:black_stained_glass
fill 484 279 277 484 279 278 minecraft:white_wool
setblock 484 279 279 minecraft:black_stained_glass
setblock 484 279 282 minecraft:white_wool
fill 484 279 287 486 279 287 minecraft:black_stained_glass
setblock 484 279 290 minecraft:white_wool
setblock 484 279 292 minecraft:white_wool
fill 484 279 293 485 279 295 minecraft:black_stained_glass
setblock 484 279 296 minecraft:white_wool
setblock 484 279 299 minecraft:white_wool
fill 484 279 301 485 279 301 minecraft:black_stained_glass
fill 484 279 311 485 279 311 minecraft:white_wool
fill 484 279 312 486 279 313 minecraft:black_stained_glass
setblock 484 279 314 minecraft:white_wool
fill 485 279 277 487 279 277 minecraft:black_stained_glass
fill 485 279 278 485 279 280 minecraft:white_wool
setblock 485 279 282 minecraft:black_stained_glass
setblock 485 279 284 minecraft:black_stained_glass
setblock 485 279 285 minecraft:white_wool
fill 485 279 289 486 279 289 minecraft:white_wool
fill 485 279 290 486 279 290 minecraft:black_stained_glass
fill 485 279 292 488 279 292 minecraft:black_stained_glass
setblock 485 279 296 minecraft:black_stained_glass
setblock 485 279 299 minecraft:black_stained_glass
setblock 485 279 300 minecraft:white_wool
fill 485 279 308 485 279 309 minecraft:white_wool
fill 485 279 310 491 279 310 minecraft:black_stained_glass
fill 485 279 314 491 279 314 minecraft:black_stained_glass
fill 486 279 278 487 279 280 minecraft:black_stained_glass
fill 486 279 281 486 279 282 minecraft:white_wool
fill 486 279 284 487 279 284 minecraft:white_wool
fill 486 279 285 491 279 285 minecraft:black_stained_glass
setblock 486 279 288 minecraft:white_wool
fill 486 279 293 486 279 296 minecraft:white_wool
setblock 486 279 299 minecraft:white_wool
fill 486 279 300 488 279 300 minecraft:black_stained_glass
setblock 486 279 301 minecraft:white_wool
fill 486 279 305 486 279 307 minecraft:white_wool
fill 486 279 308 486 279 309 minecraft:black_stained_glass
fill 486 279 311 491 279 311 minecraft:black_stained_glass
fill 487 279 281 491 279 282 minecraft:black_stained_glass
setblock 487 279 283 minecraft:white_wool
setblock 487 279 287 minecraft:white_wool
fill 487 279 288 488 279 289 minecraft:black_stained_glass
fill 487 279 290 487 279 291 minecraft:white_wool
fill 487 279 293 487 279 296 minecraft:black_stained_glass
setblock 487 279 298 minecraft:white_wool
setblock 487 279 299 minecraft:black_stained_glass
fill 487 279 301 491 279 301 minecraft:black_stained_glass
fill 487 279 302 488 279 302 minecraft:white_wool
fill 487 279 304 487 279 305 minecraft:white_wool
fill 487 279 306 487 279 308 minecraft:black_stained_glass
fill 487 279 309 488 279 309 minecraft:white_wool
fill 487 279 312 488 279 312 minecraft:white_wool
fill 487 279 313 491 279 313 minecraft:black_stained_glass
setblock 487 279 315 minecraft:white_wool
fill 487 279 316 491 279 316 minecraft:black_stained_glass
fill 488 279 277 490 279 277 minecraft:white_wool
fill 488 279 278 491 279 279 minecraft:black_stained_glass
fill 488 279 280 490 279 280 minecraft:white_wool
fill 488 279 283 488 279 284 minecraft:black_stained_glass
fill 488 279 286 490 279 286 minecraft:white_wool
fill 488 279 287 491 279 287 minecraft:black_stained_glass
setblock 488 279 290 minecraft:white_wool
setblock 488 279 291 minecraft:black_stained_glass
fill 488 279 293 488 279 295 minecraft:redstone_block
setblock 488 279 296 minecraft:black_stained_glass
fill 488 279 298 489 279 298 minecraft:black_stained_glass
setblock 488 279 299 minecraft:white_wool
fill 488 279 304 491 279 305 minecraft:black_stained_glass
setblock 488 279 306 minecraft:white_wool
fill 488 279 307 491 279 308 minecraft:black_stained_glass
fill 488 279 315 491 279 315 minecraft:black_stained_glass
fill 489 279 283 490 279 283 minecraft:white_wool
fill 489 279 284 491 279 284 minecraft:black_stained_glass
setblock 489 279 288 minecraft:white_wool
fill 489 279 289 489 279 290 minecraft:black_stained_glass
fill 489 279 291 489 279 293 minecraft:redstone_block
fill 489 279 295 489 279 297 minecraft:redstone_block
fill 489 279 299 491 279 299 minecraft:black_stained_glass
setblock 489 279 300 minecraft:white_wool
fill 489 279 302 491 279 302 minecraft:black_stained_glass
setblock 489 279 303 minecraft:white_wool
fill 489 279 306 491 279 306 minecraft:black_stained_glass
fill 489 279 309 491 279 309 minecraft:black_stained_glass
fill 489 279 312 491 279 312 minecraft:black_stained_glass
fill 490 279 288 491 279 288 minecraft:black_stained_glass
fill 490 279 289 490 279 290 minecraft:white_wool
fill 490 279 291 491 279 291 minecraft:redstone_block
fill 490 279 297 491 279 297 minecraft:redstone_block
setblock 490 279 298 minecraft:white_wool
fill 490 279 300 491 279 300 minecraft:black_stained_glass
fill 490 279 303 491 279 303 minecraft:black_stained_glass
setblock 491 279 277 minecraft:black_stained_glass
setblock 491 279 280 minecraft:black_stained_glass
setblock 491 279 283 minecraft:black_stained_glass
setblock 491 279 286 minecraft:black_stained_glass
setblock 491 279 289 minecraft:black_stained_glass
fill 491 279 290 493 279 290 minecraft:redstone_block
fill 491 279 298 493 279 298 minecraft:redstone_block
fill 492 279 276 492 279 289 minecraft:white_wool
fill 492 279 299 492 279 316 minecraft:white_wool
fill 493 279 276 500 279 276 minecraft:black_stained_glass
fill 493 279 277 495 279 277 minecraft:white_wool
fill 493 279 278 497 279 279 minecraft:black_stained_glass
fill 493 279 280 495 279 280 minecraft:white_wool
fill 493 279 281 496 279 282 minecraft:black_stained_glass
fill 493 279 283 494 279 283 minecraft:white_wool
fill 493 279 284 496 279 285 minecraft:black_stained_glass
fill 493 279 286 494 279 286 minecraft:white_wool
fill 493 279 287 494 279 288 minecraft:black_stained_glass
setblock 493 279 289 minecraft:white_wool
fill 493 279 291 495 279 291 minecraft:redstone_block
fill 493 279 297 495 279 297 minecraft:redstone_block
fill 493 279 299 494 279 316 minecraft:black_stained_glass
fill 494 279 289 497 279 289 minecraft:black_stained_glass
fill 494 279 290 495 279 290 minecraft:white_wool
setblock 494 279 298 minecraft:white_wool
fill 495 279 283 496 279 283 minecraft:black_stained_glass
fill 495 279 286 495 279 287 minecraft:black_stained_glass
setblock 495 279 288 minecraft:white_wool
fill 495 279 292 495 279 293 minecraft:redstone_block
fill 495 279 295 495 279 296 minecraft:redstone_block
fill 495 279 298 496 279 299 minecraft:black_stained_glass
fill 495 279 300 496 279 300 minecraft:white_wool
fill 495 279 301 495 279 316 minecraft:black_stained_glass
fill 496 279 277 499 279 277 minecraft:black_stained_glass
fill 496 279 280 498 279 280 minecraft:black_stained_glass
fill 496 279 286 496 279 287 minecraft:white_wool
setblock 496 279 288 minecraft:black_stained_glass
setblock 496 279 290 minecraft:black_stained_glass
setblock 496 279 291 minecraft:white_wool
fill 496 279 292 499 279 292 minecraft:black_stained_glass
fill 496 279 293 496 279 295 minecraft:redstone_block
setblock 496 279 296 minecraft:white_wool
fill 496 279 297 501 279 297 minecraft:black_stained_glass
fill 496 279 301 500 279 301 minecraft:black_stained_glass
fill 496 279 302 496 279 303 minecraft:white_wool
fill 496 279 304 496 279 316 minecraft:black_stained_glass
fill 497 279 281 498 279 281 minecraft:white_wool
setblock 497 279 282 minecraft:black_stained_glass
fill 497 279 283 497 279 284 minecraft:white_wool
fill 497 279 285 497 279 287 minecraft:black_stained_glass
setblock 497 279 288 minecraft:white_wool
setblock 497 279 290 minecraft:white_wool
fill 497 279 291 498 279 291 minecraft:black_stained_glass
fill 497 279 293 498 279 296 minecraft:black_stained_glass
fill 497 279 298 498 279 299 minecraft:white_wool
fill 497 279 300 499 279 300 minecraft:black_stained_glass
fill 497 279 302 497 279 303 minecraft:black_stained_glass
fill 497 279 304 497 279 306 minecraft:white_wool
fill 497 279 307 497 279 308 minecraft:black_stained_glass
setblock 497 279 309 minecraft:white_wool
fill 497 279 310 499 279 311 minecraft:black_stained_glass
fill 497 279 312 498 279 312 minecraft:white_wool
fill 497 279 313 497 279 316 minecraft:black_stained_glass
setblock 498 279 278 minecraft:white_wool
setblock 498 279 279 minecraft:black_stained_glass
fill 498 279 282 499 279 282 minecraft:white_wool
fill 498 279 283 503 279 284 minecraft:black_stained_glass
setblock 498 279 285 minecraft:white_wool
fill 498 279 286 499 279 288 minecraft:black_stained_glass
setblock 498 279 289 minecraft:white_wool
fill 498 279 290 501 279 290 minecraft:black_stained_glass
setblock 498 279 302 minecraft:white_wool
fill 498 279 303 498 279 305 minecraft:black_stained_glass
fill 498 279 306 498 279 307 minecraft:white_wool
fill 498 279 308 498 279 309 minecraft:black_stained_glass
fill 498 279 313 500 279 314 minecraft:black_stained_glass
setblock 498 279 315 minecraft:white_wool
fill 498 279 316 501 279 316 minecraft:black_stained_glass
setblock 499 279 278 minecraft:black_stained_glass
fill 499 279 279 499 279 280 minecraft:white_wool
fill 499 279 281 502 279 281 minecraft:black_stained_glass
fill 499 279 285 502 279 285 minecraft:black_stained_glass
fill 499 279 289 507 279 289 minecraft:black_stained_glass
setblock 499 279 291 minecraft:white_wool
fill 499 279 293 511 279 295 minecraft:black_stained_glass
fill 499 279 296 502 279 296 minecraft:white_wool
fill 499 279 298 500 279 299 minecraft:black_stained_glass
fill 499 279 302 501 279 304 minecraft:black_stained_glass
setblock 499 279 305 minecraft:white_wool
fill 499 279 306 502 279 307 minecraft:black_stained_glass
fill 499 279 308 499 279 309 minecraft:white_wool
fill 499 279 312 500 279 312 minecraft:black_stained_glass
fill 499 279 315 501 279 315 minecraft:black_stained_glass
fill 500 279 277 500 279 279 minecraft:white_wool
fill 500 279 280 505 279 280 minecraft:black_stained_glass
fill 500 279 282 503 279 282 minecraft:black_stained_glass
fill 500 279 286 501 279 286 minecraft:black_stained_glass
fill 500 279 287 501 279 287 minecraft:white_wool
setblock 500 279 288 minecraft:black_stained_glass
fill 500 279 291 501 279 291 minecraft:black_stained_glass
fill 500 279 292 501 279 292 minecraft:white_wool
setblock 500 279 300 minecraft:white_wool
fill 500 279 305 503 279 305 minecraft:black_stained_glass
setblock 500 279 308 minecraft:white_wool
fill 500 279 309 503 279 309 minecraft:black_stained_glass
fill 500 279 310 500 279 311 minecraft:white_wool
setblock 501 279 276 minecraft:white_wool
fill 501 279 277 503 279 279 minecraft:black_stained_glass
setblock 501 279 288 minecraft:white_wool
fill 501 279 298 507 279 298 minecraft:black_stained_glass
setblock 501 279 299 minecraft:white_wool
fill 501 279 300 503 279 300 minecraft:black_stained_glass
setblock 501 279 301 minecraft:white_wool
fill 501 279 308 504 279 308 minecraft:black_stained_glass
fill 501 279 310 501 279 311 minecraft:black_stained_glass
fill 501 279 312 501 279 314 minecraft:white_wool
fill 502 279 276 505 279 276 minecraft:black_stained_glass
fill 502 279 286 503 279 286 minecraft:white_wool
fill 502 279 287 503 279 288 minecraft:black_stained_glass
fill 502 279 290 502 279 291 minecraft:white_wool
fill 502 279 292 511 279 292 minecraft:black_stained_glass
setblock 502 279 297 minecraft:white_wool
fill 502 279 299 511 279 299 minecraft:black_stained_glass
setblock 502 279 301 minecraft:black_stained_glass
setblock 502 279 302 minecraft:white_wool
fill 502 279 303 502 279 304 minecraft:black_stained_glass
setblock 502 279 310 minecraft:white_wool
fill 502 279 311 502 279 313 minecraft:black_stained_glass
fill 502 279 314 502 279 316 minecraft:white_wool
setblock 503 279 281 minecraft:white_wool
setblock 503 279 285 minecraft:white_wool
fill 503 279 290 503 279 291 minecraft:black_stained_glass
fill 503 279 296 503 279 297 minecraft:black_stained_glass
setblock 503 279 301 minecraft:white_wool
fill 503 279 302 505 279 302 minecraft:black_stained_glass
setblock 503 279 303 minecraft:white_wool
setblock 503 279 304 minecraft:black_stained_glass
setblock 503 279 306 minecraft:white_wool
fill 503 279 307 505 279 307 minecraft:black_stained_glass
fill 503 279 310 504 279 312 minecraft:black_stained_glass
setblock 503 279 313 minecraft:white_wool
fill 503 279 314 505 279 315 minecraft:black_stained_glass
fill 503 279 316 504 279 316 minecraft:white_wool
fill 504 279 277 511 279 277 minecraft:black_stained_glass
setblock 504 279 278 minecraft:white_wool
setblock 504 279 279 minecraft:black_stained_glass
fill 504 279 281 506 279 281 minecraft:black_stained_glass
setblock 504 279 282 minecraft:white_wool
setblock 504 279 283 minecraft:black_stained_glass
fill 504 279 284 505 279 284 minecraft:white_wool
fill 504 279 285 505 279 286 minecraft:black_stained_glass
setblock 504 279 287 minecraft:white_wool
fill 504 279 288 511 279 288 minecraft:black_stained_glass
setblock 504 279 290 minecraft:black_stained_glass
fill 504 279 291 506 279 291 minecraft:white_wool
fill 504 279 296 511 279 296 minecraft:black_stained_glass
fill 504 279 297 506 279 297 minecraft:white_wool
setblock 504 279 300 minecraft:white_wool
fill 504 279 301 509 279 301 minecraft:black_stained_glass
fill 504 279 303 508 279 303 minecraft:black_stained_glass
fill 504 279 304 504 279 305 minecraft:white_wool
fill 504 279 306 506 279 306 minecraft:black_stained_glass
setblock 504 279 309 minecraft:white_wool
fill 504 279 313 511 279 313 minecraft:black_stained_glass
fill 505 279 278 510 279 278 minecraft:black_stained_glass
setblock 505 279 279 minecraft:white_wool
fill 505 279 282 506 279 282 minecraft:black_stained_glass
fill 505 279 283 506 279 283 minecraft:white_wool
fill 505 279 287 506 279 287 minecraft:black_stained_glass
setblock 505 279 290 minecraft:white_wool
fill 505 279 300 506 279 300 minecraft:black_stained_glass
setblock 505 279 304 minecraft:white_wool
setblock 505 279 305 minecraft:black_stained_glass
setblock 505 279 308 minecraft:white_wool
fill 505 279 309 505 279 311 minecraft:black_stained_glass
setblock 505 279 312 minecraft:white_wool
fill 505 279 316 511 279 316 minecraft:black_stained_glass
setblock 506 279 276 minecraft:white_wool
fill 506 279 279 508 279 279 minecraft:black_stained_glass
setblock 506 279 280 minecraft:white_wool
fill 506 279 284 508 279 284 minecraft:black_stained_glass
setblock 506 279 285 minecraft:white_wool
fill 506 279 286 509 279 286 minecraft:black_stained_glass
fill 506 279 290 507 279 290 minecraft:black_stained_glass
setblock 506 279 302 minecraft:white_wool
fill 506 279 304 511 279 304 minecraft:black_stained_glass
setblock 506 279 305 minecraft:white_wool
setblock 506 279 307 minecraft:white_wool
fill 506 279 308 506 279 310 minecraft:black_stained_glass
setblock 506 279 311 minecraft:white_wool
fill 506 279 312 511 279 312 minecraft:black_stained_glass
setblock 506 279 314 minecraft:black_stained_glass
setblock 506 279 315 minecraft:white_wool
fill 507 279 276 511 279 276 minecraft:black_stained_glass
fill 507 279 280 508 279 280 minecraft:black_stained_glass
fill 507 279 281 508 279 282 minecraft:white_wool
fill 507 279 283 511 279 283 minecraft:black_stained_glass
fill 507 279 285 511 279 285 minecraft:black_stained_glass
setblock 507 279 287 minecraft:white_wool
fill 507 279 291 511 279 291 minecraft:black_stained_glass
setblock 507 279 297 minecraft:black_stained_glass
setblock 507 279 300 minecraft:white_wool
fill 507 279 302 511 279 302 minecraft:black_stained_glass
setblock 507 279 305 minecraft:black_stained_glass
setblock 507 279 306 minecraft:white_wool
fill 507 279 307 507 279 309 minecraft:black_stained_glass
setblock 507 279 310 minecraft:white_wool
fill 507 279 311 511 279 311 minecraft:black_stained_glass
setblock 507 279 314 minecraft:white_wool
fill 507 279 315 510 279 315 minecraft:black_stained_glass
fill 508 279 287 511 279 287 minecraft:black_stained_glass
fill 508 279 289 508 279 290 minecraft:white_wool
fill 508 279 297 508 279 298 minecraft:white_wool
fill 508 279 300 511 279 300 minecraft:black_stained_glass
setblock 508 279 305 minecraft:white_wool
fill 508 279 306 511 279 306 minecraft:black_stained_glass
fill 508 279 307 510 279 307 minecraft:white_wool
setblock 508 279 308 minecraft:black_stained_glass
setblock 508 279 309 minecraft:white_wool
fill 508 279 310 510 279 310 minecraft:black_stained_glass
fill 508 279 314 511 279 314 minecraft:black_stained_glass
fill 509 279 279 509 279 281 minecraft:white_wool
fill 509 279 282 511 279 282 minecraft:black_stained_glass
setblock 509 279 284 minecraft:white_wool
fill 509 279 289 510 279 289 minecraft:black_stained_glass
fill 509 279 290 511 279 290 minecraft:white_wool
fill 509 279 297 510 279 297 minecraft:black_stained_glass
fill 509 279 298 511 279 298 minecraft:white_wool
setblock 509 279 303 minecraft:white_wool
fill 509 279 305 511 279 305 minecraft:black_stained_glass
fill 509 279 308 510 279 308 minecraft:white_wool
setblock 509 279 309 minecraft:black_stained_glass
fill 510 279 279 510 279 280 minecraft:white_wool
fill 510 279 281 511 279 281 minecraft:black_stained_glass
fill 510 279 284 511 279 284 minecraft:black_stained_glass
setblock 510 279 286 minecraft:white_wool
setblock 510 279 301 minecraft:white_wool
fill 510 279 303 511 279 303 minecraft:black_stained_glass
fill 510 279 309 511 279 309 minecraft:white_wool
setblock 511 279 275 minecraft:redstone_block
fill 511 279 278 511 279 279 minecraft:white_wool
setblock 511 279 280 minecraft:black_stained_glass
setblock 511 279 286 minecraft:black_stained_glass
setblock 511 279 289 minecraft:white_wool
setblock 511 279 297 minecraft:white_wool
setblock 511 279 301 minecraft:black_stained_glass
fill 511 279 307 511 279 308 minecraft:black_stained_glass
setblock 511 279 310 minecraft:white_wool
setblock 511 279 315 minecraft:white_wool
fill 477 280 290 477 281 290 minecraft:white_wool
fill 484 280 317 485 308 317 minecraft:deepslate_tiles
setblock 486 280 317 minecraft:white_wool
fill 487 280 317 487 308 317 minecraft:deepslate_tiles
fill 511 280 275 511 308 275 minecraft:deepslate_tiles
fill 486 281 317 486 308 317 minecraft:deepslate_tiles
setblock 512 282 292 minecraft:redstone_block
fill 471 283 276 471 283 279 minecraft:deepslate_tiles
setblock 471 283 280 minecraft:cobbled_deepslate
fill 471 283 281 471 283 284 minecraft:deepslate_tiles
setblock 471 283 285 minecraft:cobbled_deepslate
fill 471 283 286 471 283 289 minecraft:deepslate_tiles
setblock 471 283 290 minecraft:cobbled_deepslate
fill 471 283 291 471 283 294 minecraft:deepslate_tiles
setblock 471 283 295 minecraft:cobbled_deepslate
fill 471 283 296 471 283 297 minecraft:deepslate_tiles
fill 471 283 301 471 283 304 minecraft:deepslate_tiles
setblock 471 283 305 minecraft:cobbled_deepslate
fill 471 283 306 471 283 309 minecraft:deepslate_tiles
setblock 471 283 310 minecraft:cobbled_deepslate
fill 471 283 311 471 283 314 minecraft:deepslate_tiles
setblock 471 283 315 minecraft:cobbled_deepslate
fill 471 283 316 474 283 316 minecraft:deepslate_tiles
fill 472 283 276 472 283 278 minecraft:deepslate_tiles
setblock 472 283 279 minecraft:cobbled_deepslate
fill 472 283 280 472 283 283 minecraft:deepslate_tiles
setblock 472 283 284 minecraft:cobbled_deepslate
fill 472 283 285 472 283 288 minecraft:deepslate_tiles
setblock 472 283 289 minecraft:cobbled_deepslate
fill 472 283 290 472 283 293 minecraft:deepslate_tiles
fill 472 283 305 472 283 308 minecraft:deepslate_tiles
setblock 472 283 309 minecraft:cobbled_deepslate
fill 472 283 310 472 283 313 minecraft:deepslate_tiles
setblock 472 283 314 minecraft:cobbled_deepslate
fill 472 283 315 475 283 315 minecraft:deepslate_tiles
fill 473 283 276 473 283 277 minecraft:deepslate_tiles
setblock 473 283 278 minecraft:light[level=12]
fill 473 283 281 473 283 282 minecraft:deepslate_tiles
setblock 473 283 283 minecraft:cobbled_deepslate
fill 473 283 284 473 283 287 minecraft:deepslate_tiles
setblock 473 283 288 minecraft:cobbled_deepslate
fill 473 283 289 473 283 290 minecraft:deepslate_tiles
setblock 473 283 292 minecraft:light[level=12]
setblock 473 283 299 minecraft:light[level=12]
setblock 473 283 306 minecraft:light[level=12]
fill 473 283 309 473 283 312 minecraft:deepslate_tiles
setblock 473 283 313 minecraft:cobbled_deepslate
setblock 474 283 276 minecraft:deepslate_tiles
setblock 474 283 277 minecraft:cobbled_deepslate
setblock 475 283 276 minecraft:cobbled_deepslate
setblock 475 283 316 minecraft:cobbled_deepslate
fill 476 283 276 477 283 276 minecraft:deepslate_tiles
setblock 476 283 315 minecraft:cobbled_deepslate
fill 476 283 316 479 283 316 minecraft:deepslate_tiles
setblock 480 283 278 minecraft:light[level=12]
setblock 480 283 285 minecraft:light[level=12]
setblock 480 283 292 minecraft:light[level=12]
setblock 480 283 299 minecraft:light[level=12]
setblock 480 283 306 minecraft:light[level=12]
setblock 480 283 313 minecraft:light[level=12]
setblock 480 283 316 minecraft:cobbled_deepslate
fill 481 283 316 484 283 316 minecraft:deepslate_tiles
fill 483 283 315 485 283 315 minecraft:deepslate_tiles
fill 485 283 314 486 283 314 minecraft:deepslate_tiles
setblock 485 283 316 minecraft:cobbled_deepslate
setblock 486 283 315 minecraft:cobbled_deepslate
fill 486 283 316 489 283 316 minecraft:deepslate_tiles
fill 487 283 276 489 283 276 minecraft:deepslate_tiles
setblock 487 283 278 minecraft:light[level=12]
setblock 487 283 285 minecraft:light[level=12]
setblock 487 283 292 minecraft:light[level=12]
setblock 487 283 299 minecraft:light[level=12]
setblock 487 283 306 minecraft:light[level=12]
setblock 487 283 313 minecraft:light[level=12]
setblock 487 283 314 minecraft:cobbled_deepslate
fill 487 283 315 490 283 315 minecraft:deepslate_tiles
setblock 488 283 275 minecraft:white_wool
setblock 488 283 313 minecraft:cobbled_deepslate
fill 488 283 314 491 283 314 minecraft:deepslate_tiles
fill 489 283 313 491 283 313 minecraft:deepslate_tiles
setblock 490 283 276 minecraft:cobbled_deepslate
setblock 490 283 316 minecraft:cobbled_deepslate
setblock 491 283 276 minecraft:deepslate_tiles
fill 491 283 284 493 283 284 minecraft:white_wool
setblock 491 283 315 minecraft:cobbled_deepslate
fill 491 283 316 494 283 316 minecraft:deepslate_tiles
setblock 492 283 285 minecraft:white_wool
setblock 492 283 314 minecraft:cobbled_deepslate
fill 492 283 315 494 283 315 minecraft:deepslate_tiles
setblock 493 283 314 minecraft:deepslate_tiles
setblock 494 283 278 minecraft:light[level=12]
setblock 494 283 285 minecraft:light[level=12]
setblock 494 283 292 minecraft:light[level=12]
setblock 494 283 299 minecraft:light[level=12]
setblock 494 283 306 minecraft:light[level=12]
setblock 494 283 313 minecraft:light[level=12]
setblock 495 283 316 minecraft:cobbled_deepslate
setblock 501 283 278 minecraft:light[level=12]
setblock 501 283 285 minecraft:light[level=12]
setblock 501 283 292 minecraft:light[level=12]
setblock 501 283 299 minecraft:light[level=12]
setblock 501 283 306 minecraft:light[level=12]
setblock 501 283 313 minecraft:light[level=12]
fill 508 283 276 509 283 276 minecraft:deepslate_tiles
setblock 508 283 278 minecraft:light[level=12]
fill 508 283 284 508 283 287 minecraft:deepslate_tiles
setblock 508 283 288 minecraft:cobbled_deepslate
fill 508 283 289 509 283 291 minecraft:deepslate_tiles
setblock 508 283 292 minecraft:light[level=12]
setblock 508 283 299 minecraft:light[level=12]
setblock 508 283 306 minecraft:light[level=12]
setblock 508 283 313 minecraft:light[level=12]
fill 508 283 316 509 283 316 minecraft:deepslate_tiles
setblock 509 283 281 minecraft:deepslate_tiles
setblock 509 283 282 minecraft:cobbled_deepslate
fill 509 283 283 509 283 286 minecraft:deepslate_tiles
setblock 509 283 287 minecraft:cobbled_deepslate
fill 509 283 288 511 284 288 minecraft:deepslate_tiles
setblock 509 283 292 minecraft:cobbled_deepslate
fill 509 283 293 511 283 294 minecraft:deepslate_tiles
fill 509 283 308 511 283 309 minecraft:deepslate_tiles
setblock 510 283 276 minecraft:cobbled_deepslate
fill 510 283 277 510 283 280 minecraft:deepslate_tiles
setblock 510 283 281 minecraft:cobbled_deepslate
fill 510 283 282 510 283 285 minecraft:deepslate_tiles
setblock 510 283 286 minecraft:cobbled_deepslate
fill 510 283 287 511 285 287 minecraft:deepslate_tiles
fill 510 283 289 510 283 290 minecraft:deepslate_tiles
setblock 510 283 291 minecraft:cobbled_deepslate
fill 510 283 292 512 285 292 minecraft:deepslate_tiles
setblock 510 283 295 minecraft:deepslate_tiles
setblock 510 283 296 minecraft:cobbled_deepslate
fill 510 283 297 511 283 299 minecraft:deepslate_tiles
setblock 510 283 301 minecraft:cobbled_deepslate
fill 510 283 302 510 283 305 minecraft:deepslate_tiles
setblock 510 283 306 minecraft:cobbled_deepslate
fill 510 283 307 511 285 307 minecraft:deepslate_tiles
setblock 510 283 310 minecraft:deepslate_tiles
setblock 510 283 311 minecraft:cobbled_deepslate
fill 510 283 312 511 283 314 minecraft:deepslate_tiles
setblock 510 283 316 minecraft:cobbled_deepslate
fill 511 283 276 511 283 279 minecraft:deepslate_tiles
setblock 511 283 280 minecraft:cobbled_deepslate
fill 511 283 281 511 283 284 minecraft:deepslate_tiles
setblock 511 283 285 minecraft:cobbled_deepslate
fill 511 283 286 511 286 286 minecraft:deepslate_tiles
setblock 511 283 289 minecraft:deepslate_tiles
setblock 511 283 290 minecraft:cobbled_deepslate
fill 511 283 291 511 286 291 minecraft:deepslate_tiles
setblock 511 283 295 minecraft:cobbled_deepslate
fill 511 283 296 511 286 296 minecraft:deepslate_tiles
setblock 511 283 300 minecraft:cobbled_deepslate
fill 511 283 301 511 283 304 minecraft:deepslate_tiles
setblock 511 283 305 minecraft:cobbled_deepslate
fill 511 283 306 511 286 306 minecraft:deepslate_tiles
setblock 511 283 310 minecraft:cobbled_deepslate
fill 511 283 311 512 286 311 minecraft:deepslate_tiles
setblock 511 283 315 minecraft:cobbled_deepslate
fill 511 283 316 511 286 316 minecraft:deepslate_tiles
fill 512 283 308 512 308 308 minecraft:deepslate_tiles
setblock 512 283 309 minecraft:white_wool
fill 512 283 310 512 308 310 minecraft:deepslate_tiles
fill 471 284 276 471 284 278 minecraft:deepslate_tiles
setblock 471 284 279 minecraft:cobbled_deepslate
fill 471 284 280 471 284 283 minecraft:deepslate_tiles
setblock 471 284 284 minecraft:cobbled_deepslate
fill 471 284 285 471 284 288 minecraft:deepslate_tiles
setblock 471 284 289 minecraft:cobbled_deepslate
fill 471 284 290 471 284 293 minecraft:deepslate_tiles
setblock 471 284 294 minecraft:cobbled_deepslate
fill 471 284 295 471 284 296 minecraft:deepslate_tiles
setblock 471 284 303 minecraft:deepslate_tiles
setblock 471 284 304 minecraft:cobbled_deepslate
fill 471 284 305 471 284 308 minecraft:deepslate_tiles
setblock 471 284 309 minecraft:cobbled_deepslate
fill 471 284 310 471 284 313 minecraft:deepslate_tiles
setblock 471 284 314 minecraft:cobbled_deepslate
fill 471 284 315 473 284 316 minecraft:deepslate_tiles
fill 472 284 276 472 284 277 minecraft:deepslate_tiles
setblock 472 284 278 minecraft:cobbled_deepslate
fill 472 284 279 472 284 282 minecraft:deepslate_tiles
setblock 472 284 283 minecraft:cobbled_deepslate
fill 472 284 284 472 284 287 minecraft:deepslate_tiles
setblock 472 284 288 minecraft:cobbled_deepslate
fill 472 284 289 472 284 292 minecraft:deepslate_tiles
setblock 472 284 293 minecraft:cobbled_deepslate
fill 472 284 306 472 284 307 minecraft:deepslate_tiles
setblock 472 284 308 minecraft:cobbled_deepslate
fill 472 284 309 472 284 312 minecraft:deepslate_tiles
setblock 472 284 313 minecraft:cobbled_deepslate
fill 472 284 314 472 287 314 minecraft:deepslate_tiles
setblock 473 284 276 minecraft:deepslate_tiles
setblock 473 284 277 minecraft:cobbled_deepslate
fill 473 284 284 473 284 286 minecraft:deepslate_tiles
setblock 473 284 287 minecraft:cobbled_deepslate
fill 473 284 288 473 284 289 minecraft:deepslate_tiles
setblock 473 284 311 minecraft:deepslate_tiles
setblock 473 284 312 minecraft:cobbled_deepslate
setblock 474 284 276 minecraft:cobbled_deepslate
setblock 474 284 315 minecraft:deepslate_tiles
setblock 474 284 316 minecraft:cobbled_deepslate
fill 475 284 276 476 284 276 minecraft:deepslate_tiles
setblock 475 284 315 minecraft:cobbled_deepslate
fill 475 284 316 478 284 316 minecraft:deepslate_tiles
setblock 479 284 316 minecraft:cobbled_deepslate
fill 480 284 316 483 284 316 minecraft:deepslate_tiles
fill 482 284 315 484 284 315 minecraft:deepslate_tiles
setblock 484 284 316 minecraft:cobbled_deepslate
setblock 485 284 314 minecraft:deepslate_tiles
setblock 485 284 315 minecraft:cobbled_deepslate
fill 485 284 316 488 284 316 minecraft:deepslate_tiles
setblock 486 284 314 minecraft:cobbled_deepslate
fill 486 284 315 489 284 315 minecraft:deepslate_tiles
fill 487 284 276 488 284 276 minecraft:deepslate_tiles
setblock 487 284 313 minecraft:cobbled_deepslate
fill 487 284 314 490 284 314 minecraft:deepslate_tiles
fill 488 284 275 488 308 275 minecraft:deepslate_tiles
fill 488 284 313 490 285 313 minecraft:deepslate_tiles
setblock 489 284 276 minecraft:cobbled_deepslate
setblock 489 284 316 minecraft:cobbled_deepslate
setblock 490 284 276 minecraft:deepslate_tiles
setblock 490 284 315 minecraft:cobbled_deepslate
fill 490 284 316 493 284 316 minecraft:deepslate_tiles
setblock 491 284 314 minecraft:cobbled_deepslate
fill 491 284 315 493 285 315 minecraft:deepslate_tiles
fill 492 284 314 492 285 314 minecraft:deepslate_tiles
setblock 494 284 316 minecraft:cobbled_deepslate
setblock 495 284 316 minecraft:deepslate_tiles
fill 507 284 276 508 284 276 minecraft:deepslate_tiles
fill 508 284 285 508 284 286 minecraft:deepslate_tiles
setblock 508 284 287 minecraft:cobbled_deepslate
fill 508 284 288 508 284 291 minecraft:deepslate_tiles
setblock 508 284 292 minecraft:cobbled_deepslate
setblock 508 284 316 minecraft:deepslate_tiles
setblock 509 284 276 minecraft:cobbled_deepslate
fill 509 284 282 509 284 285 minecraft:deepslate_tiles
setblock 509 284 286 minecraft:cobbled_deepslate
fill 509 284 287 509 287 287 minecraft:deepslate_tiles
fill 509 284 289 509 284 290 minecraft:deepslate_tiles
setblock 509 284 291 minecraft:cobbled_deepslate
fill 509 284 292 509 285 294 minecraft:deepslate_tiles
setblock 509 284 316 minecraft:cobbled_deepslate
fill 510 284 276 511 286 276 minecraft:deepslate_tiles
fill 510 284 278 510 284 279 minecraft:deepslate_tiles
setblock 510 284 280 minecraft:cobbled_deepslate
fill 510 284 281 510 284 284 minecraft:deepslate_tiles
setblock 510 284 285 minecraft:cobbled_deepslate
fill 510 284 286 510 287 286 minecraft:deepslate_tiles
setblock 510 284 289 minecraft:deepslate_tiles
setblock 510 284 290 minecraft:cobbled_deepslate
fill 510 284 291 510 287 291 minecraft:deepslate_tiles
fill 510 284 293 510 284 294 minecraft:deepslate_tiles
setblock 510 284 295 minecraft:cobbled_deepslate
fill 510 284 296 510 284 297 minecraft:deepslate_tiles
setblock 510 284 304 minecraft:deepslate_tiles
setblock 510 284 305 minecraft:cobbled_deepslate
setblock 510 284 306 minecraft:deepslate_tiles
fill 510 284 308 510 284 309 minecraft:deepslate_tiles
setblock 510 284 310 minecraft:cobbled_deepslate
fill 510 284 311 510 284 314 minecraft:deepslate_tiles
fill 510 284 316 510 287 316 minecraft:deepslate_tiles
fill 511 284 277 511 284 278 minecraft:deepslate_tiles
setblock 511 284 279 minecraft:cobbled_deepslate
fill 511 284 280 511 284 283 minecraft:deepslate_tiles
setblock 511 284 284 minecraft:cobbled_deepslate
fill 511 284 285 511 287 285 minecraft:deepslate_tiles
setblock 511 284 289 minecraft:cobbled_deepslate
fill 511 284 290 511 287 290 minecraft:deepslate_tiles
setblock 511 284 293 minecraft:deepslate_tiles
setblock 511 284 294 minecraft:cobbled_deepslate
fill 511 284 295 511 287 295 minecraft:deepslate_tiles
fill 511 284 297 511 284 298 minecraft:deepslate_tiles
setblock 511 284 299 minecraft:cobbled_deepslate
fill 511 284 300 511 284 303 minecraft:deepslate_tiles
setblock 511 284 304 minecraft:cobbled_deepslate
fill 511 284 305 511 285 305 minecraft:deepslate_tiles
setblock 511 284 308 minecraft:deepslate_tiles
setblock 511 284 309 minecraft:cobbled_deepslate
fill 511 284 310 511 287 310 minecraft:deepslate_tiles
fill 511 284 312 511 284 313 minecraft:deepslate_tiles
setblock 511 284 314 minecraft:cobbled_deepslate
fill 511 284 315 511 287 315 minecraft:deepslate_tiles
fill 512 284 309 512 308 309 minecraft:deepslate_tiles
fill 471 285 276 471 285 277 minecraft:deepslate_tiles
setblock 471 285 278 minecraft:cobbled_deepslate
fill 471 285 279 471 285 282 minecraft:deepslate_tiles
setblock 471 285 283 minecraft:cobbled_deepslate
fill 471 285 284 471 285 287 minecraft:deepslate_tiles
setblock 471 285 288 minecraft:cobbled_deepslate
fill 471 285 289 471 285 292 minecraft:deepslate_tiles
setblock 471 285 293 minecraft:cobbled_deepslate
fill 471 285 294 471 286 295 minecraft:deepslate_tiles
fill 471 285 305 471 285 307 minecraft:deepslate_tiles
setblock 471 285 308 minecraft:cobbled_deepslate
fill 471 285 309 471 285 312 minecraft:deepslate_tiles
setblock 471 285 313 minecraft:cobbled_deepslate
fill 471 285 314 471 286 316 minecraft:deepslate_tiles
setblock 472 285 276 minecraft:deepslate_tiles
setblock 472 285 277 minecraft:cobbled_deepslate
fill 472 285 278 472 285 281 minecraft:deepslate_tiles
setblock 472 285 282 minecraft:cobbled_deepslate
fill 472 285 283 472 285 286 minecraft:deepslate_tiles
setblock 472 285 287 minecraft:cobbled_deepslate
fill 472 285 288 472 285 291 minecraft:deepslate_tiles
setblock 472 285 292 minecraft:cobbled_deepslate
fill 472 285 308 472 285 311 minecraft:deepslate_tiles
setblock 472 285 312 minecraft:cobbled_deepslate
fill 472 285 313 472 288 313 minecraft:deepslate_tiles
fill 472 285 315 472 285 316 minecraft:deepslate_tiles
setblock 473 285 276 minecraft:cobbled_deepslate
setblock 473 285 278 minecraft:light[level=13]
setblock 473 285 286 minecraft:light[level=13]
setblock 473 285 294 minecraft:light[level=13]
setblock 473 285 302 minecraft:light[level=13]
setblock 473 285 310 minecraft:light[level=13]
setblock 473 285 315 minecraft:deepslate_tiles
setblock 473 285 316 minecraft:cobbled_deepslate
fill 474 285 276 475 285 276 minecraft:deepslate_tiles
setblock 474 285 315 minecraft:cobbled_deepslate
fill 474 285 316 477 285 316 minecraft:deepslate_tiles
setblock 475 285 279 minecraft:white_wool
fill 475 285 315 475 286 315 minecraft:deepslate_tiles
setblock 476 285 278 minecraft:white_wool
setblock 477 285 277 minecraft:white_wool
setblock 478 285 276 minecraft:white_wool
setblock 478 285 316 minecraft:cobbled_deepslate
fill 479 285 316 482 285 316 minecraft:deepslate_tiles
setblock 481 285 278 minecraft:light[level=13]
setblock 481 285 286 minecraft:light[level=13]
setblock 481 285 294 minecraft:light[level=13]
setblock 481 285 302 minecraft:light[level=13]
setblock 481 285 310 minecraft:light[level=13]
fill 482 285 315 483 285 315 minecraft:deepslate_tiles
setblock 483 285 316 minecraft:cobbled_deepslate
setblock 484 285 314 minecraft:deepslate_tiles
setblock 484 285 315 minecraft:cobbled_deepslate
fill 484 285 316 487 285 316 minecraft:deepslate_tiles
setblock 485 285 314 minecraft:cobbled_deepslate
fill 485 285 315 488 285 315 minecraft:deepslate_tiles
fill 486 285 314 489 285 314 minecraft:deepslate_tiles
fill 487 285 313 487 288 313 minecraft:deepslate_tiles
setblock 488 285 316 minecraft:cobbled_deepslate
setblock 489 285 278 minecraft:light[level=13]
setblock 489 285 286 minecraft:light[level=13]
setblock 489 285 294 minecraft:light[level=13]
setblock 489 285 302 minecraft:light[level=13]
setblock 489 285 310 minecraft:light[level=13]
setblock 489 285 315 minecraft:cobbled_deepslate
fill 489 285 316 492 285 316 minecraft:deepslate_tiles
setblock 490 285 314 minecraft:cobbled_deepslate
fill 490 285 315 490 288 315 minecraft:deepslate_tiles
fill 491 285 314 491 286 314 minecraft:deepslate_tiles
setblock 493 285 316 minecraft:cobbled_deepslate
setblock 494 285 316 minecraft:deepslate_tiles
setblock 497 285 278 minecraft:light[level=13]
setblock 497 285 286 minecraft:light[level=13]
setblock 497 285 294 minecraft:light[level=13]
setblock 497 285 302 minecraft:light[level=13]
setblock 497 285 310 minecraft:light[level=13]
setblock 505 285 278 minecraft:light[level=13]
setblock 505 285 286 minecraft:light[level=13]
setblock 505 285 294 minecraft:light[level=13]
setblock 505 285 302 minecraft:light[level=13]
setblock 505 285 310 minecraft:light[level=13]
setblock 507 285 276 minecraft:deepslate_tiles
setblock 507 285 316 minecraft:deepslate_tiles
setblock 508 285 276 minecraft:cobbled_deepslate
setblock 508 285 286 minecraft:cobbled_deepslate
fill 508 285 287 508 285 290 minecraft:deepslate_tiles
setblock 508 285 291 minecraft:cobbled_deepslate
fill 508 285 292 508 287 292 minecraft:deepslate_tiles
setblock 508 285 316 minecraft:cobbled_deepslate
fill 509 285 276 509 288 276 minecraft:deepslate_tiles
fill 509 285 283 509 285 284 minecraft:deepslate_tiles
setblock 509 285 285 minecraft:cobbled_deepslate
fill 509 285 286 509 288 286 minecraft:deepslate_tiles
fill 509 285 288 509 285 289 minecraft:deepslate_tiles
setblock 509 285 290 minecraft:cobbled_deepslate
fill 509 285 291 509 288 291 minecraft:deepslate_tiles
fill 509 285 316 509 288 316 minecraft:deepslate_tiles
setblock 510 285 279 minecraft:cobbled_deepslate
fill 510 285 280 510 285 283 minecraft:deepslate_tiles
setblock 510 285 284 minecraft:cobbled_deepslate
fill 510 285 285 510 288 285 minecraft:deepslate_tiles
setblock 510 285 288 minecraft:deepslate_tiles
setblock 510 285 289 minecraft:cobbled_deepslate
fill 510 285 290 510 288 290 minecraft:deepslate_tiles
setblock 510 285 293 minecraft:deepslate_tiles
setblock 510 285 294 minecraft:cobbled_deepslate
fill 510 285 295 510 287 296 minecraft:deepslate_tiles
setblock 510 285 308 minecraft:deepslate_tiles
setblock 510 285 309 minecraft:cobbled_deepslate
fill 510 285 310 510 285 313 minecraft:deepslate_tiles
setblock 510 285 314 minecraft:cobbled_deepslate
setblock 511 285 277 minecraft:deepslate_tiles
setblock 511 285 278 minecraft:cobbled_deepslate
fill 511 285 279 511 285 282 minecraft:deepslate_tiles
setblock 511 285 283 minecraft:cobbled_deepslate
fill 511 285 284 511 288 284 minecraft:deepslate_tiles
setblock 511 285 288 minecraft:cobbled_deepslate
fill 511 285 289 511 288 289 minecraft:deepslate_tiles
setblock 511 285 293 minecraft:cobbled_deepslate
fill 511 285 294 511 288 294 minecraft:deepslate_tiles
setblock 511 285 297 minecraft:deepslate_tiles
setblock 511 285 298 minecraft:cobbled_deepslate
setblock 511 285 299 minecraft:deepslate_tiles
setblock 511 285 303 minecraft:cobbled_deepslate
setblock 511 285 304 minecraft:deepslate_tiles
setblock 511 285 308 minecraft:cobbled_deepslate
fill 511 285 309 511 288 309 minecraft:deepslate_tiles
setblock 511 285 312 minecraft:deepslate_tiles
setblock 511 285 313 minecraft:cobbled_deepslate
fill 511 285 314 511 288 314 minecraft:deepslate_tiles
setblock 471 286 276 minecraft:deepslate_tiles
setblock 471 286 277 minecraft:cobbled_deepslate
fill 471 286 278 471 286 281 minecraft:deepslate_tiles
setblock 471 286 282 minecraft:cobbled_deepslate
setblock 471 286 283 minecraft:white_wool
fill 471 286 284 471 286 286 minecraft:deepslate_tiles
setblock 471 286 287 minecraft:cobbled_deepslate
fill 471 286 288 471 286 291 minecraft:deepslate_tiles
setblock 471 286 292 minecraft:cobbled_deepslate
fill 471 286 293 471 289 293 minecraft:deepslate_tiles
setblock 471 286 306 minecraft:deepslate_tiles
setblock 471 286 307 minecraft:cobbled_deepslate
fill 471 286 308 471 286 311 minecraft:deepslate_tiles
setblock 471 286 312 minecraft:cobbled_deepslate
fill 471 286 313 471 289 313 minecraft:deepslate_tiles
setblock 472 286 276 minecraft:cobbled_deepslate
setblock 472 286 282 minecraft:white_wool
fill 472 286 284 472 286 285 minecraft:deepslate_tiles
setblock 472 286 286 minecraft:cobbled_deepslate
fill 472 286 287 472 286 290 minecraft:deepslate_tiles
setblock 472 286 291 minecraft:cobbled_deepslate
fill 472 286 309 472 286 310 minecraft:deepslate_tiles
setblock 472 286 311 minecraft:cobbled_deepslate
fill 472 286 312 472 289 312 minecraft:deepslate_tiles
setblock 472 286 315 minecraft:deepslate_tiles
setblock 472 286 316 minecraft:cobbled_deepslate
fill 473 286 276 474 288 276 minecraft:deepslate_tiles
setblock 473 286 281 minecraft:white_wool
setblock 473 286 315 minecraft:cobbled_deepslate
fill 473 286 316 476 286 316 minecraft:deepslate_tiles
setblock 474 286 280 minecraft:white_wool
fill 474 286 315 474 289 315 minecraft:deepslate_tiles
setblock 477 286 316 minecraft:cobbled_deepslate
fill 478 286 316 481 286 316 minecraft:deepslate_tiles
fill 481 286 315 482 286 315 minecraft:deepslate_tiles
setblock 482 286 316 minecraft:cobbled_deepslate
setblock 483 286 315 minecraft:cobbled_deepslate
fill 483 286 316 486 286 316 minecraft:deepslate_tiles
setblock 484 286 314 minecraft:cobbled_deepslate
fill 484 286 315 487 286 315 minecraft:deepslate_tiles
fill 485 286 314 488 286 314 minecraft:deepslate_tiles
setblock 487 286 316 minecraft:cobbled_deepslate
fill 488 286 313 489 286 313 minecraft:deepslate_tiles
setblock 488 286 315 minecraft:cobbled_deepslate
fill 488 286 316 491 286 316 minecraft:deepslate_tiles
setblock 489 286 275 minecraft:white_wool
setblock 489 286 314 minecraft:cobbled_deepslate
fill 489 286 315 489 289 315 minecraft:deepslate_tiles
fill 490 286 314 490 289 314 minecraft:deepslate_tiles
fill 491 286 315 492 286 315 minecraft:deepslate_tiles
setblock 492 286 316 minecraft:cobbled_deepslate
fill 493 286 316 493 289 316 minecraft:deepslate_tiles
setblock 506 286 316 minecraft:deepslate_tiles
setblock 507 286 276 minecraft:cobbled_deepslate
setblock 507 286 316 minecraft:cobbled_deepslate
fill 508 286 276 508 289 276 minecraft:deepslate_tiles
fill 508 286 287 508 286 289 minecraft:deepslate_tiles
setblock 508 286 290 minecraft:cobbled_deepslate
fill 508 286 291 508 289 291 minecraft:deepslate_tiles
fill 508 286 316 508 289 316 minecraft:deepslate_tiles
setblock 509 286 284 minecraft:cobbled_deepslate
fill 509 286 285 509 288 285 minecraft:deepslate_tiles
setblock 509 286 288 minecraft:deepslate_tiles
setblock 509 286 289 minecraft:cobbled_deepslate
fill 509 286 290 509 289 290 minecraft:deepslate_tiles
fill 509 286 292 509 286 293 minecraft:deepslate_tiles
setblock 509 286 294 minecraft:cobbled_deepslate
fill 510 286 280 510 286 282 minecraft:deepslate_tiles
setblock 510 286 283 minecraft:cobbled_deepslate
fill 510 286 284 510 289 284 minecraft:deepslate_tiles
setblock 510 286 287 minecraft:deepslate_tiles
setblock 510 286 288 minecraft:cobbled_deepslate
fill 510 286 289 510 289 289 minecraft:deepslate_tiles
setblock 510 286 292 minecraft:deepslate_tiles
setblock 510 286 293 minecraft:cobbled_deepslate
fill 510 286 294 510 289 294 minecraft:deepslate_tiles
fill 510 286 309 510 286 312 minecraft:deepslate_tiles
setblock 510 286 313 minecraft:cobbled_deepslate
fill 510 286 314 510 289 314 minecraft:deepslate_tiles
setblock 511 286 277 minecraft:cobbled_deepslate
fill 511 286 278 511 286 281 minecraft:deepslate_tiles
setblock 511 286 282 minecraft:cobbled_deepslate
fill 511 286 283 511 289 283 minecraft:deepslate_tiles
setblock 511 286 287 minecraft:cobbled_deepslate
fill 511 286 288 511 289 288 minecraft:deepslate_tiles
setblock 511 286 292 minecraft:cobbled_deepslate
fill 511 286 293 511 289 293 minecraft:deepslate_tiles
setblock 511 286 297 minecraft:cobbled_deepslate
setblock 511 286 298 minecraft:deepslate_tiles
setblock 511 286 307 minecraft:cobbled_deepslate
fill 511 286 308 511 287 308 minecraft:deepslate_tiles
setblock 511 286 312 minecraft:cobbled_deepslate
fill 511 286 313 511 289 313 minecraft:deepslate_tiles
fill 512 286 292 512 308 292 minecraft:deepslate_tiles
setblock 471 287 276 minecraft:cobbled_deepslate
fill 471 287 277 471 287 280 minecraft:deepslate_tiles
setblock 471 287 281 minecraft:cobbled_deepslate
fill 471 287 282 471 287 285 minecraft:deepslate_tiles
setblock 471 287 286 minecraft:cobbled_deepslate
fill 471 287 287 471 287 290 minecraft:deepslate_tiles
setblock 471 287 291 minecraft:cobbled_deepslate
fill 471 287 292 471 290 292 minecraft:deepslate_tiles
fill 471 287 294 471 288 294 minecraft:deepslate_tiles
fill 471 287 307 471 287 310 minecraft:deepslate_tiles
setblock 471 287 311 minecraft:cobbled_deepslate
fill 471 287 312 471 290 312 minecraft:deepslate_tiles
fill 471 287 314 471 287 315 minecraft:deepslate_tiles
setblock 471 287 316 minecraft:cobbled_deepslate
fill 472 287 276 472 290 276 minecraft:deepslate_tiles
fill 472 287 288 472 287 289 minecraft:deepslate_tiles
setblock 472 287 290 minecraft:cobbled_deepslate
setblock 472 287 310 minecraft:cobbled_deepslate
fill 472 287 311 472 290 311 minecraft:deepslate_tiles
setblock 472 287 315 minecraft:cobbled_deepslate
fill 472 287 316 475 287 316 minecraft:deepslate_tiles
fill 473 287 315 473 290 315 minecraft:deepslate_tiles
fill 476 287 285 476 297 285 minecraft:white_wool
setblock 476 287 316 minecraft:cobbled_deepslate
fill 477 287 316 480 287 316 minecraft:deepslate_tiles
fill 479 287 275 479 308 275 minecraft:deepslate_tiles
setblock 480 287 275 minecraft:white_wool
setblock 481 287 315 minecraft:deepslate_tiles
setblock 481 287 316 minecraft:cobbled_deepslate
setblock 482 287 315 minecraft:cobbled_deepslate
fill 482 287 316 485 287 316 minecraft:deepslate_tiles
setblock 483 287 314 minecraft:cobbled_deepslate
fill 483 287 315 486 287 315 minecraft:deepslate_tiles
fill 484 287 314 487 287 314 minecraft:deepslate_tiles
setblock 486 287 316 minecraft:cobbled_deepslate
setblock 487 287 315 minecraft:cobbled_deepslate
fill 487 287 316 490 287 316 minecraft:deepslate_tiles
setblock 488 287 313 minecraft:deepslate_tiles
setblock 488 287 314 minecraft:cobbled_deepslate
fill 488 287 315 488 290 315 minecraft:deepslate_tiles
fill 489 287 275 489 308 275 minecraft:deepslate_tiles
fill 489 287 314 489 290 314 minecraft:deepslate_tiles
setblock 491 287 315 minecraft:deepslate_tiles
setblock 491 287 316 minecraft:cobbled_deepslate
setblock 492 287 315 minecraft:cobbled_deepslate
fill 492 287 316 492 290 316 minecraft:deepslate_tiles
setblock 506 287 276 minecraft:cobbled_deepslate
setblock 506 287 316 minecraft:cobbled_deepslate
fill 507 287 276 507 290 276 minecraft:deepslate_tiles
fill 507 287 316 507 290 316 minecraft:deepslate_tiles
setblock 508 287 288 minecraft:deepslate_tiles
setblock 508 287 289 minecraft:cobbled_deepslate
fill 508 287 290 508 289 290 minecraft:deepslate_tiles
setblock 509 287 288 minecraft:cobbled_deepslate
fill 509 287 289 509 290 289 minecraft:deepslate_tiles
setblock 509 287 292 minecraft:deepslate_tiles
setblock 509 287 293 minecraft:cobbled_deepslate
fill 509 287 294 509 290 294 minecraft:deepslate_tiles
setblock 510 287 276 minecraft:deepslate_tiles
setblock 510 287 281 minecraft:deepslate_tiles
setblock 510 287 282 minecraft:cobbled_deepslate
fill 510 287 283 510 289 283 minecraft:deepslate_tiles
setblock 510 287 287 minecraft:cobbled_deepslate
fill 510 287 288 510 290 288 minecraft:deepslate_tiles
setblock 510 287 292 minecraft:cobbled_deepslate
fill 510 287 293 510 290 293 minecraft:deepslate_tiles
setblock 510 287 311 minecraft:deepslate_tiles
setblock 510 287 312 minecraft:cobbled_deepslate
fill 510 287 313 510 290 313 minecraft:deepslate_tiles
setblock 511 287 276 minecraft:cobbled_deepslate
fill 511 287 277 511 287 280 minecraft:deepslate_tiles
setblock 511 287 281 minecraft:cobbled_deepslate
fill 511 287 282 511 290 282 minecraft:deepslate_tiles
setblock 511 287 286 minecraft:cobbled_deepslate
fill 511 287 287 511 290 287 minecraft:deepslate_tiles
setblock 511 287 291 minecraft:cobbled_deepslate
fill 511 287 292 511 290 292 minecraft:deepslate_tiles
setblock 511 287 296 minecraft:cobbled_deepslate
fill 511 287 297 511 290 297 minecraft:deepslate_tiles
setblock 511 287 311 minecraft:cobbled_deepslate
fill 511 287 312 511 290 312 minecraft:deepslate_tiles
setblock 511 287 316 minecraft:cobbled_deepslate
fill 512 287 311 512 308 311 minecraft:deepslate_tiles
fill 471 288 276 471 288 279 minecraft:deepslate_tiles
setblock 471 288 280 minecraft:cobbled_deepslate
fill 471 288 281 471 288 284 minecraft:deepslate_tiles
setblock 471 288 285 minecraft:cobbled_deepslate
fill 471 288 286 471 288 289 minecraft:deepslate_tiles
setblock 471 288 290 minecraft:cobbled_deepslate
fill 471 288 291 471 291 291 minecraft:deepslate_tiles
fill 471 288 308 471 288 309 minecraft:deepslate_tiles
setblock 471 288 310 minecraft:cobbled_deepslate
fill 471 288 311 471 291 311 minecraft:deepslate_tiles
setblock 471 288 314 minecraft:deepslate_tiles
setblock 471 288 315 minecraft:cobbled_deepslate
fill 471 288 316 474 288 316 minecraft:deepslate_tiles
setblock 472 288 314 minecraft:cobbled_deepslate
fill 472 288 315 472 291 315 minecraft:deepslate_tiles
setblock 475 288 315 minecraft:deepslate_tiles
setblock 475 288 316 minecraft:cobbled_deepslate
fill 476 288 316 479 288 316 minecraft:deepslate_tiles
fill 479 288 315 480 288 315 minecraft:deepslate_tiles
fill 480 288 275 480 308 275 minecraft:deepslate_tiles
setblock 480 288 316 minecraft:cobbled_deepslate
setblock 481 288 315 minecraft:cobbled_deepslate
fill 481 288 316 484 288 316 minecraft:deepslate_tiles
fill 482 288 315 485 288 315 minecraft:deepslate_tiles
fill 483 288 314 486 288 314 minecraft:deepslate_tiles
setblock 485 288 316 minecraft:cobbled_deepslate
fill 486 288 276 487 290 276 minecraft:deepslate_tiles
fill 486 288 313 486 289 313 minecraft:deepslate_tiles
setblock 486 288 315 minecraft:cobbled_deepslate
fill 486 288 316 489 288 316 minecraft:deepslate_tiles
setblock 487 288 314 minecraft:cobbled_deepslate
fill 487 288 315 487 291 315 minecraft:deepslate_tiles
fill 488 288 314 488 291 314 minecraft:deepslate_tiles
setblock 490 288 316 minecraft:cobbled_deepslate
setblock 491 288 315 minecraft:cobbled_deepslate
fill 491 288 316 491 291 316 minecraft:deepslate_tiles
setblock 504 288 316 minecraft:deepslate_tiles
setblock 505 288 276 minecraft:cobbled_deepslate
setblock 505 288 316 minecraft:cobbled_deepslate
fill 506 288 276 506 291 276 minecraft:deepslate_tiles
fill 506 288 316 506 291 316 minecraft:deepslate_tiles
setblock 508 288 289 minecraft:deepslate_tiles
fill 508 288 315 510 288 315 minecraft:deepslate_tiles
setblock 509 288 287 minecraft:cobbled_deepslate
fill 509 288 288 509 291 288 minecraft:deepslate_tiles
setblock 509 288 292 minecraft:cobbled_deepslate
fill 509 288 293 509 291 293 minecraft:deepslate_tiles
setblock 510 288 276 minecraft:cobbled_deepslate
setblock 510 288 282 minecraft:deepslate_tiles
setblock 510 288 286 minecraft:cobbled_deepslate
fill 510 288 287 510 291 287 minecraft:deepslate_tiles
setblock 510 288 291 minecraft:cobbled_deepslate
fill 510 288 292 510 291 292 minecraft:deepslate_tiles
setblock 510 288 295 minecraft:deepslate_tiles
setblock 510 288 296 minecraft:cobbled_deepslate
setblock 510 288 312 minecraft:deepslate_tiles
setblock 510 288 316 minecraft:cobbled_deepslate
fill 511 288 276 511 288 279 minecraft:deepslate_tiles
setblock 511 288 280 minecraft:cobbled_deepslate
fill 511 288 281 511 291 281 minecraft:deepslate_tiles
setblock 511 288 285 minecraft:cobbled_deepslate
fill 511 288 286 511 291 286 minecraft:deepslate_tiles
setblock 511 288 290 minecraft:cobbled_deepslate
fill 511 288 291 511 291 291 minecraft:deepslate_tiles
setblock 511 288 295 minecraft:cobbled_deepslate
fill 511 288 296 511 291 296 minecraft:deepslate_tiles
setblock 511 288 310 minecraft:cobbled_deepslate
fill 511 288 311 511 291 311 minecraft:deepslate_tiles
setblock 511 288 315 minecraft:cobbled_deepslate
fill 511 288 316 511 291 316 minecraft:deepslate_tiles
fill 471 289 276 471 289 278 minecraft:deepslate_tiles
setblock 471 289 279 minecraft:cobbled_deepslate
fill 471 289 280 471 292 280 minecraft:deepslate_tiles
setblock 471 289 284 minecraft:cobbled_deepslate
fill 471 289 285 471 289 288 minecraft:deepslate_tiles
setblock 471 289 289 minecraft:cobbled_deepslate
fill 471 289 290 471 292 290 minecraft:deepslate_tiles
setblock 471 289 294 minecraft:cobbled_deepslate
setblock 471 289 308 minecraft:deepslate_tiles
setblock 471 289 309 minecraft:cobbled_deepslate
fill 471 289 310 471 292 310 minecraft:deepslate_tiles
setblock 471 289 314 minecraft:cobbled_deepslate
fill 471 289 315 471 291 316 minecraft:deepslate_tiles
setblock 472 289 313 minecraft:cobbled_deepslate
fill 472 289 314 472 292 314 minecraft:deepslate_tiles
fill 472 289 316 473 289 316 minecraft:deepslate_tiles
setblock 473 289 276 minecraft:deepslate_tiles
setblock 473 289 278 minecraft:light[level=12]
setblock 473 289 285 minecraft:light[level=12]
setblock 473 289 292 minecraft:light[level=12]
setblock 473 289 299 minecraft:light[level=12]
setblock 473 289 306 minecraft:light[level=12]
setblock 473 289 313 minecraft:light[level=12]
setblock 474 289 276 minecraft:cobbled_deepslate
setblock 474 289 316 minecraft:cobbled_deepslate
setblock 475 289 315 minecraft:cobbled_deepslate
fill 475 289 316 478 289 316 minecraft:deepslate_tiles
fill 476 289 315 479 289 315 minecraft:deepslate_tiles
setblock 479 289 316 minecraft:cobbled_deepslate
setblock 480 289 278 minecraft:light[level=12]
setblock 480 289 285 minecraft:light[level=12]
setblock 480 289 292 minecraft:light[level=12]
setblock 480 289 299 minecraft:light[level=12]
setblock 480 289 306 minecraft:light[level=12]
setblock 480 289 313 minecraft:light[level=12]
setblock 480 289 315 minecraft:cobbled_deepslate
fill 480 289 316 483 289 316 minecraft:deepslate_tiles
fill 481 289 315 484 289 315 minecraft:deepslate_tiles
fill 482 289 314 485 289 314 minecraft:deepslate_tiles
setblock 483 289 276 minecraft:deepslate_tiles
setblock 484 289 276 minecraft:cobbled_deepslate
setblock 484 289 316 minecraft:cobbled_deepslate
fill 485 289 276 485 292 276 minecraft:deepslate_tiles
fill 485 289 313 485 290 313 minecraft:deepslate_tiles
setblock 485 289 315 minecraft:cobbled_deepslate
fill 485 289 316 488 289 316 minecraft:deepslate_tiles
setblock 486 289 314 minecraft:cobbled_deepslate
fill 486 289 315 486 292 315 minecraft:deepslate_tiles
setblock 487 289 278 minecraft:light[level=12]
setblock 487 289 285 minecraft:light[level=12]
setblock 487 289 292 minecraft:light[level=12]
setblock 487 289 299 minecraft:light[level=12]
setblock 487 289 306 minecraft:light[level=12]
setblock 487 289 313 minecraft:cobbled_deepslate
fill 487 289 314 487 292 314 minecraft:deepslate_tiles
setblock 488 289 276 minecraft:deepslate_tiles
setblock 489 289 316 minecraft:cobbled_deepslate
setblock 490 289 315 minecraft:cobbled_deepslate
fill 490 289 316 490 292 316 minecraft:deepslate_tiles
fill 491 289 315 491 292 315 minecraft:deepslate_tiles
setblock 494 289 278 minecraft:light[level=12]
setblock 494 289 285 minecraft:light[level=12]
setblock 494 289 292 minecraft:light[level=12]
setblock 494 289 299 minecraft:light[level=12]
setblock 494 289 306 minecraft:light[level=12]
setblock 494 289 313 minecraft:light[level=12]
setblock 501 289 278 minecraft:light[level=12]
setblock 501 289 285 minecraft:light[level=12]
setblock 501 289 292 minecraft:light[level=12]
setblock 501 289 299 minecraft:light[level=12]
setblock 501 289 306 minecraft:light[level=12]
setblock 501 289 313 minecraft:light[level=12]
setblock 503 289 316 minecraft:deepslate_tiles
setblock 504 289 276 minecraft:cobbled_deepslate
setblock 504 289 316 minecraft:cobbled_deepslate
fill 505 289 276 505 292 276 minecraft:deepslate_tiles
fill 505 289 316 505 292 316 minecraft:deepslate_tiles
fill 506 289 315 509 289 315 minecraft:deepslate_tiles
setblock 507 289 277 minecraft:deepslate_tiles
setblock 508 289 277 minecraft:cobbled_deepslate
setblock 508 289 278 minecraft:light[level=12]
setblock 508 289 285 minecraft:light[level=12]
setblock 508 289 292 minecraft:cobbled_deepslate
setblock 508 289 299 minecraft:light[level=12]
setblock 508 289 306 minecraft:light[level=12]
setblock 508 289 313 minecraft:light[level=12]
setblock 509 289 276 minecraft:cobbled_deepslate
fill 509 289 277 511 290 277 minecraft:deepslate_tiles
setblock 509 289 286 minecraft:cobbled_deepslate
fill 509 289 287 509 290 287 minecraft:deepslate_tiles
setblock 509 289 291 minecraft:cobbled_deepslate
fill 509 289 292 509 292 292 minecraft:deepslate_tiles
setblock 509 289 316 minecraft:cobbled_deepslate
fill 510 289 276 511 291 276 minecraft:deepslate_tiles
setblock 510 289 285 minecraft:cobbled_deepslate
fill 510 289 286 510 292 286 minecraft:deepslate_tiles
setblock 510 289 290 minecraft:cobbled_deepslate
fill 510 289 291 510 292 291 minecraft:deepslate_tiles
setblock 510 289 295 minecraft:cobbled_deepslate
fill 510 289 296 510 292 296 minecraft:deepslate_tiles
setblock 510 289 315 minecraft:cobbled_deepslate
fill 510 289 316 510 292 316 minecraft:deepslate_tiles
setblock 511 289 278 minecraft:deepslate_tiles
setblock 511 289 279 minecraft:cobbled_deepslate
fill 511 289 280 511 292 280 minecraft:deepslate_tiles
setblock 511 289 284 minecraft:cobbled_deepslate
fill 511 289 285 511 292 285 minecraft:deepslate_tiles
setblock 511 289 289 minecraft:cobbled_deepslate
fill 511 289 290 511 292 290 minecraft:deepslate_tiles
setblock 511 289 294 minecraft:cobbled_deepslate
fill 511 289 295 511 292 295 minecraft:deepslate_tiles
setblock 511 289 310 minecraft:deepslate_tiles
setblock 511 289 314 minecraft:cobbled_deepslate
fill 511 289 315 511 292 315 minecraft:deepslate_tiles
fill 471 290 276 471 290 277 minecraft:deepslate_tiles
setblock 471 290 278 minecraft:cobbled_deepslate
fill 471 290 279 471 293 279 minecraft:deepslate_tiles
setblock 471 290 287 minecraft:deepslate_tiles
setblock 471 290 288 minecraft:cobbled_deepslate
fill 471 290 289 471 291 289 minecraft:deepslate_tiles
setblock 471 290 293 minecraft:cobbled_deepslate
fill 471 290 294 471 292 295 minecraft:deepslate_tiles
fill 471 290 309 471 293 309 minecraft:deepslate_tiles
setblock 471 290 313 minecraft:cobbled_deepslate
fill 471 290 314 471 293 314 minecraft:deepslate_tiles
setblock 472 290 312 minecraft:cobbled_deepslate
fill 472 290 313 472 293 313 minecraft:deepslate_tiles
setblock 472 290 316 minecraft:deepslate_tiles
setblock 473 290 276 minecraft:cobbled_deepslate
setblock 473 290 316 minecraft:cobbled_deepslate
fill 474 290 276 475 292 276 minecraft:deepslate_tiles
setblock 474 290 315 minecraft:cobbled_deepslate
fill 474 290 316 477 290 316 minecraft:deepslate_tiles
fill 475 290 315 478 290 315 minecraft:deepslate_tiles
setblock 478 290 316 minecraft:cobbled_deepslate
setblock 479 290 315 minecraft:cobbled_deepslate
fill 479 290 316 482 290 316 minecraft:deepslate_tiles
fill 480 290 315 483 290 315 minecraft:deepslate_tiles
fill 481 290 276 482 290 276 minecraft:deepslate_tiles
fill 481 290 314 484 290 314 minecraft:deepslate_tiles
setblock 483 290 276 minecraft:cobbled_deepslate
setblock 483 290 316 minecraft:cobbled_deepslate
fill 484 290 276 484 293 276 minecraft:deepslate_tiles
fill 484 290 313 484 291 313 minecraft:deepslate_tiles
setblock 484 290 315 minecraft:cobbled_deepslate
fill 484 290 316 487 290 316 minecraft:deepslate_tiles
setblock 485 290 314 minecraft:cobbled_deepslate
fill 485 290 315 485 293 315 minecraft:deepslate_tiles
setblock 486 290 313 minecraft:cobbled_deepslate
fill 486 290 314 486 293 314 minecraft:deepslate_tiles
fill 487 290 313 487 291 313 minecraft:deepslate_tiles
setblock 488 290 276 minecraft:cobbled_deepslate
setblock 488 290 316 minecraft:cobbled_deepslate
fill 489 290 276 489 293 276 minecraft:deepslate_tiles
setblock 489 290 315 minecraft:cobbled_deepslate
fill 489 290 316 489 293 316 minecraft:deepslate_tiles
fill 490 290 315 490 293 315 minecraft:deepslate_tiles
setblock 493 290 316 minecraft:cobbled_deepslate
setblock 502 290 276 minecraft:deepslate_tiles
setblock 502 290 316 minecraft:deepslate_tiles
setblock 503 290 276 minecraft:cobbled_deepslate
setblock 503 290 316 minecraft:cobbled_deepslate
fill 504 290 276 504 293 276 minecraft:deepslate_tiles
fill 504 290 316 504 293 316 minecraft:deepslate_tiles
fill 505 290 277 506 290 277 minecraft:deepslate_tiles
fill 505 290 315 508 290 315 minecraft:deepslate_tiles
setblock 507 290 277 minecraft:cobbled_deepslate
setblock 508 290 276 minecraft:cobbled_deepslate
fill 508 290 277 508 293 277 minecraft:deepslate_tiles
setblock 508 290 291 minecraft:cobbled_deepslate
fill 508 290 292 508 291 292 minecraft:deepslate_tiles
setblock 508 290 316 minecraft:cobbled_deepslate
fill 509 290 276 509 293 276 minecraft:deepslate_tiles
setblock 509 290 290 minecraft:cobbled_deepslate
fill 509 290 291 509 293 291 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_12 1t
