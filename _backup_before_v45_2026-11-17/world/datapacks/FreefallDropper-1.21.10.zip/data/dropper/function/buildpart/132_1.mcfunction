fill 42 166 558 42 166 561 minecraft:sea_lantern
fill 42 166 568 42 166 571 minecraft:sea_lantern
fill 42 166 578 42 166 581 minecraft:sea_lantern
fill 42 166 588 42 166 591 minecraft:sea_lantern
setblock 42 166 598 minecraft:sea_lantern
fill 0 167 563 0 174 566 minecraft:cyan_concrete
fill 0 167 573 0 174 576 minecraft:cyan_concrete
fill 0 167 583 0 174 586 minecraft:cyan_concrete
fill 0 167 593 0 174 596 minecraft:cyan_concrete
fill 3 167 557 6 174 557 minecraft:cyan_concrete
fill 4 167 599 7 174 599 minecraft:cyan_concrete
fill 13 167 557 16 174 557 minecraft:cyan_concrete
fill 14 167 599 17 174 599 minecraft:cyan_concrete
fill 23 167 557 26 174 557 minecraft:cyan_concrete
fill 24 167 599 27 174 599 minecraft:cyan_concrete
fill 33 167 557 36 174 557 minecraft:cyan_concrete
fill 34 167 599 37 174 599 minecraft:cyan_concrete
fill 42 167 558 42 174 561 minecraft:cyan_concrete
fill 42 167 568 42 174 571 minecraft:cyan_concrete
fill 42 167 578 42 174 581 minecraft:cyan_concrete
fill 42 167 588 42 174 591 minecraft:cyan_concrete
fill 42 167 598 42 174 598 minecraft:cyan_concrete
setblock 1 168 560 minecraft:black_concrete
setblock 1 168 570 minecraft:black_concrete
setblock 1 168 580 minecraft:black_concrete
setblock 1 168 590 minecraft:black_concrete
setblock 3 168 598 minecraft:black_concrete
setblock 7 168 558 minecraft:black_concrete
setblock 13 168 598 minecraft:black_concrete
setblock 17 168 558 minecraft:black_concrete
setblock 23 168 598 minecraft:black_concrete
setblock 27 168 558 minecraft:black_concrete
setblock 33 168 598 minecraft:black_concrete
setblock 37 168 558 minecraft:black_concrete
setblock 41 168 564 minecraft:black_concrete
setblock 41 168 574 minecraft:black_concrete
setblock 41 168 584 minecraft:black_concrete
setblock 41 168 594 minecraft:black_concrete
fill 1 171 562 1 171 565 minecraft:black_concrete
fill 1 171 572 1 171 575 minecraft:black_concrete
fill 1 171 582 1 171 585 minecraft:black_concrete
fill 1 171 592 1 171 595 minecraft:black_concrete
fill 2 171 558 5 171 558 minecraft:black_concrete
fill 5 171 598 8 171 598 minecraft:black_concrete
fill 12 171 558 15 171 558 minecraft:black_concrete
fill 15 171 598 18 171 598 minecraft:black_concrete
fill 22 171 558 25 171 558 minecraft:black_concrete
fill 25 171 598 28 171 598 minecraft:black_concrete
fill 32 171 558 35 171 558 minecraft:black_concrete
fill 35 171 598 38 171 598 minecraft:black_concrete
fill 41 171 559 41 171 562 minecraft:black_concrete
fill 41 171 569 41 171 572 minecraft:black_concrete
fill 41 171 579 41 171 582 minecraft:black_concrete
fill 41 171 589 41 171 592 minecraft:black_concrete
setblock 1 174 560 minecraft:black_concrete
setblock 1 174 570 minecraft:black_concrete
setblock 1 174 580 minecraft:black_concrete
setblock 1 174 590 minecraft:black_concrete
setblock 3 174 560 minecraft:light[level=14]
setblock 3 174 568 minecraft:light[level=14]
setblock 3 174 576 minecraft:light[level=14]
setblock 3 174 584 minecraft:light[level=14]
setblock 3 174 592 minecraft:light[level=14]
setblock 3 174 598 minecraft:black_concrete
setblock 7 174 558 minecraft:black_concrete
setblock 11 174 560 minecraft:light[level=14]
setblock 11 174 568 minecraft:light[level=14]
setblock 11 174 576 minecraft:light[level=14]
setblock 11 174 584 minecraft:light[level=14]
setblock 11 174 592 minecraft:light[level=14]
setblock 13 174 598 minecraft:black_concrete
setblock 17 174 558 minecraft:black_concrete
setblock 19 174 560 minecraft:light[level=14]
setblock 19 174 568 minecraft:light[level=14]
setblock 19 174 576 minecraft:light[level=14]
setblock 19 174 584 minecraft:light[level=14]
setblock 19 174 592 minecraft:light[level=14]
setblock 23 174 598 minecraft:black_concrete
setblock 27 174 558 minecraft:black_concrete
setblock 27 174 560 minecraft:light[level=14]
setblock 27 174 568 minecraft:light[level=14]
setblock 27 174 576 minecraft:light[level=14]
setblock 27 174 584 minecraft:light[level=14]
setblock 27 174 592 minecraft:light[level=14]
setblock 33 174 598 minecraft:black_concrete
setblock 35 174 560 minecraft:light[level=14]
setblock 35 174 568 minecraft:light[level=14]
setblock 35 174 576 minecraft:light[level=14]
setblock 35 174 584 minecraft:light[level=14]
setblock 35 174 592 minecraft:light[level=14]
setblock 37 174 558 minecraft:black_concrete
setblock 41 174 564 minecraft:black_concrete
setblock 41 174 574 minecraft:black_concrete
setblock 41 174 584 minecraft:black_concrete
setblock 41 174 594 minecraft:black_concrete
fill 0 175 563 0 175 566 minecraft:sea_lantern
fill 0 175 573 0 175 576 minecraft:sea_lantern
fill 0 175 583 0 175 586 minecraft:sea_lantern
fill 0 175 593 0 175 596 minecraft:sea_lantern
fill 3 175 557 6 175 557 minecraft:sea_lantern
fill 4 175 599 7 175 599 minecraft:sea_lantern
fill 13 175 557 16 175 557 minecraft:sea_lantern
fill 14 175 599 17 175 599 minecraft:sea_lantern
fill 23 175 557 26 175 557 minecraft:sea_lantern
fill 24 175 599 27 175 599 minecraft:sea_lantern
fill 33 175 557 36 175 557 minecraft:sea_lantern
fill 34 175 599 37 175 599 minecraft:sea_lantern
fill 42 175 558 42 175 561 minecraft:sea_lantern
fill 42 175 568 42 175 571 minecraft:sea_lantern
fill 42 175 578 42 175 581 minecraft:sea_lantern
fill 42 175 588 42 175 591 minecraft:sea_lantern
setblock 42 175 598 minecraft:sea_lantern
fill 0 176 563 0 183 566 minecraft:cyan_concrete
fill 0 176 573 0 183 576 minecraft:cyan_concrete
fill 0 176 583 0 183 586 minecraft:cyan_concrete
fill 0 176 593 0 183 596 minecraft:cyan_concrete
fill 3 176 557 6 183 557 minecraft:cyan_concrete
fill 4 176 599 7 183 599 minecraft:cyan_concrete
fill 13 176 557 16 183 557 minecraft:cyan_concrete
fill 14 176 599 17 183 599 minecraft:cyan_concrete
fill 23 176 557 26 183 557 minecraft:cyan_concrete
fill 24 176 599 27 183 599 minecraft:cyan_concrete
fill 33 176 557 36 183 557 minecraft:cyan_concrete
fill 34 176 599 37 183 599 minecraft:cyan_concrete
fill 42 176 558 42 183 561 minecraft:cyan_concrete
fill 42 176 568 42 183 571 minecraft:cyan_concrete
fill 42 176 578 42 183 581 minecraft:cyan_concrete
fill 42 176 588 42 183 591 minecraft:cyan_concrete
fill 42 176 598 42 183 598 minecraft:cyan_concrete
setblock 1 180 560 minecraft:black_concrete
fill 1 180 562 1 180 565 minecraft:black_concrete
setblock 1 180 570 minecraft:black_concrete
fill 1 180 572 1 180 575 minecraft:black_concrete
setblock 1 180 580 minecraft:black_concrete
fill 1 180 582 1 180 585 minecraft:black_concrete
setblock 1 180 590 minecraft:black_concrete
fill 1 180 592 1 180 595 minecraft:black_concrete
fill 2 180 558 5 180 558 minecraft:black_concrete
setblock 3 180 598 minecraft:black_concrete
fill 5 180 598 8 180 598 minecraft:black_concrete
setblock 7 180 558 minecraft:black_concrete
fill 12 180 558 15 180 558 minecraft:black_concrete
setblock 13 180 598 minecraft:black_concrete
fill 15 180 598 18 180 598 minecraft:black_concrete
setblock 17 180 558 minecraft:black_concrete
fill 22 180 558 25 180 558 minecraft:black_concrete
setblock 23 180 598 minecraft:black_concrete
fill 25 180 598 28 180 598 minecraft:black_concrete
setblock 27 180 558 minecraft:black_concrete
fill 32 180 558 35 180 558 minecraft:black_concrete
setblock 33 180 598 minecraft:black_concrete
fill 35 180 598 38 180 598 minecraft:black_concrete
setblock 37 180 558 minecraft:black_concrete
fill 41 180 559 41 180 562 minecraft:black_concrete
setblock 41 180 564 minecraft:black_concrete
fill 41 180 569 41 180 572 minecraft:black_concrete
setblock 41 180 574 minecraft:black_concrete
fill 41 180 579 41 180 582 minecraft:black_concrete
setblock 41 180 584 minecraft:black_concrete
fill 41 180 589 41 180 592 minecraft:black_concrete
setblock 41 180 594 minecraft:black_concrete
setblock 3 182 560 minecraft:light[level=14]
setblock 3 182 568 minecraft:light[level=14]
setblock 3 182 576 minecraft:light[level=14]
setblock 3 182 584 minecraft:light[level=14]
setblock 3 182 592 minecraft:light[level=14]
setblock 11 182 560 minecraft:light[level=14]
setblock 11 182 568 minecraft:light[level=14]
setblock 11 182 576 minecraft:light[level=14]
setblock 11 182 584 minecraft:light[level=14]
setblock 11 182 592 minecraft:light[level=14]
setblock 19 182 560 minecraft:light[level=14]
setblock 19 182 568 minecraft:light[level=14]
setblock 19 182 576 minecraft:light[level=14]
setblock 19 182 584 minecraft:light[level=14]
setblock 19 182 592 minecraft:light[level=14]
setblock 27 182 560 minecraft:light[level=14]
setblock 27 182 568 minecraft:light[level=14]
setblock 27 182 576 minecraft:light[level=14]
setblock 27 182 584 minecraft:light[level=14]
setblock 27 182 592 minecraft:light[level=14]
setblock 35 182 560 minecraft:light[level=14]
setblock 35 182 568 minecraft:light[level=14]
setblock 35 182 576 minecraft:light[level=14]
setblock 35 182 584 minecraft:light[level=14]
setblock 35 182 592 minecraft:light[level=14]
fill 0 184 563 0 184 566 minecraft:sea_lantern
fill 0 184 573 0 184 576 minecraft:sea_lantern
fill 0 184 583 0 184 586 minecraft:sea_lantern
fill 0 184 593 0 184 596 minecraft:sea_lantern
fill 3 184 557 6 184 557 minecraft:sea_lantern
fill 4 184 599 7 184 599 minecraft:sea_lantern
fill 13 184 557 16 184 557 minecraft:sea_lantern
fill 14 184 599 17 184 599 minecraft:sea_lantern
fill 23 184 557 26 184 557 minecraft:sea_lantern
fill 24 184 599 27 184 599 minecraft:sea_lantern
fill 33 184 557 36 184 557 minecraft:sea_lantern
fill 34 184 599 37 184 599 minecraft:sea_lantern
fill 42 184 558 42 184 561 minecraft:sea_lantern
fill 42 184 568 42 184 571 minecraft:sea_lantern
fill 42 184 578 42 184 581 minecraft:sea_lantern
fill 42 184 588 42 184 591 minecraft:sea_lantern
setblock 42 184 598 minecraft:sea_lantern
fill 0 185 563 0 201 566 minecraft:cyan_concrete
fill 0 185 573 0 201 576 minecraft:cyan_concrete
fill 0 185 583 0 201 586 minecraft:cyan_concrete
fill 0 185 593 0 201 596 minecraft:cyan_concrete
fill 3 185 557 6 201 557 minecraft:cyan_concrete
fill 4 185 599 7 201 599 minecraft:cyan_concrete
fill 13 185 557 16 201 557 minecraft:cyan_concrete
fill 14 185 599 17 201 599 minecraft:cyan_concrete
fill 23 185 557 26 201 557 minecraft:cyan_concrete
fill 24 185 599 27 201 599 minecraft:cyan_concrete
fill 33 185 557 36 201 557 minecraft:cyan_concrete
fill 34 185 599 37 201 599 minecraft:cyan_concrete
fill 42 185 558 42 201 561 minecraft:cyan_concrete
fill 42 185 568 42 201 571 minecraft:cyan_concrete
fill 42 185 578 42 201 581 minecraft:cyan_concrete
fill 42 185 588 42 201 591 minecraft:cyan_concrete
fill 42 185 598 42 201 598 minecraft:cyan_concrete
setblock 1 186 560 minecraft:black_concrete
setblock 1 186 570 minecraft:black_concrete
setblock 1 186 580 minecraft:black_concrete
setblock 1 186 590 minecraft:black_concrete
setblock 3 186 598 minecraft:black_concrete
setblock 7 186 558 minecraft:black_concrete
setblock 13 186 598 minecraft:black_concrete
setblock 17 186 558 minecraft:black_concrete
setblock 23 186 598 minecraft:black_concrete
setblock 27 186 558 minecraft:black_concrete
setblock 33 186 598 minecraft:black_concrete
setblock 37 186 558 minecraft:black_concrete
setblock 41 186 564 minecraft:black_concrete
setblock 41 186 574 minecraft:black_concrete
setblock 41 186 584 minecraft:black_concrete
setblock 41 186 594 minecraft:black_concrete
fill 1 189 562 1 189 565 minecraft:black_concrete
fill 1 189 572 1 189 575 minecraft:black_concrete
fill 1 189 582 1 189 585 minecraft:black_concrete
fill 1 189 592 1 189 595 minecraft:black_concrete
fill 2 189 558 5 189 558 minecraft:black_concrete
fill 5 189 598 8 189 598 minecraft:black_concrete
fill 12 189 558 15 189 558 minecraft:black_concrete
fill 15 189 598 18 189 598 minecraft:black_concrete
fill 22 189 558 25 189 558 minecraft:black_concrete
fill 25 189 598 28 189 598 minecraft:black_concrete
fill 32 189 558 35 189 558 minecraft:black_concrete
fill 35 189 598 38 189 598 minecraft:black_concrete
fill 41 189 559 41 189 562 minecraft:black_concrete
fill 41 189 569 41 189 572 minecraft:black_concrete
fill 41 189 579 41 189 582 minecraft:black_concrete
fill 41 189 589 41 189 592 minecraft:black_concrete
setblock 3 190 560 minecraft:light[level=14]
setblock 3 190 568 minecraft:light[level=14]
setblock 3 190 576 minecraft:light[level=14]
setblock 3 190 584 minecraft:light[level=14]
setblock 3 190 592 minecraft:light[level=14]
setblock 11 190 560 minecraft:light[level=14]
setblock 11 190 568 minecraft:light[level=14]
setblock 11 190 576 minecraft:light[level=14]
setblock 11 190 584 minecraft:light[level=14]
setblock 11 190 592 minecraft:light[level=14]
setblock 19 190 560 minecraft:light[level=14]
setblock 19 190 568 minecraft:light[level=14]
setblock 19 190 576 minecraft:light[level=14]
setblock 19 190 584 minecraft:light[level=14]
setblock 19 190 592 minecraft:light[level=14]
setblock 27 190 560 minecraft:light[level=14]
setblock 27 190 568 minecraft:light[level=14]
setblock 27 190 576 minecraft:light[level=14]
setblock 27 190 584 minecraft:light[level=14]
setblock 27 190 592 minecraft:light[level=14]
setblock 35 190 560 minecraft:light[level=14]
setblock 35 190 568 minecraft:light[level=14]
setblock 35 190 576 minecraft:light[level=14]
setblock 35 190 584 minecraft:light[level=14]
setblock 35 190 592 minecraft:light[level=14]
fill 19 194 572 21 194 574 minecraft:redstone_block
fill 19 194 578 21 194 580 minecraft:redstone_block
fill 24 194 570 26 194 572 minecraft:redstone_block
fill 26 194 579 28 194 581 minecraft:redstone_block
fill 28 194 574 30 194 576 minecraft:redstone_block
fill 16 195 568 17 195 584 minecraft:cyan_concrete
fill 18 195 568 32 195 569 minecraft:cyan_concrete
fill 18 195 570 18 195 582 minecraft:black_concrete
fill 18 195 583 32 195 584 minecraft:cyan_concrete
fill 19 195 570 23 195 571 minecraft:black_concrete
fill 19 195 575 22 195 577 minecraft:black_concrete
fill 19 195 581 25 195 582 minecraft:black_concrete
fill 22 195 572 23 195 574 minecraft:black_concrete
fill 22 195 578 25 195 580 minecraft:black_concrete
fill 24 195 573 27 195 574 minecraft:black_concrete
fill 26 195 575 27 195 578 minecraft:black_concrete
fill 26 195 582 30 195 582 minecraft:black_concrete
fill 27 195 570 30 195 572 minecraft:black_concrete
fill 28 195 573 30 195 573 minecraft:black_concrete
fill 28 195 577 30 195 578 minecraft:black_concrete
fill 29 195 579 30 195 581 minecraft:black_concrete
fill 31 195 570 32 195 582 minecraft:cyan_concrete
fill 1 196 558 15 196 598 minecraft:black_concrete
fill 16 196 558 41 196 567 minecraft:black_concrete
setblock 16 196 568 minecraft:cyan_concrete
setblock 16 196 569 minecraft:sea_lantern
fill 16 196 570 16 196 572 minecraft:cyan_concrete
setblock 16 196 573 minecraft:sea_lantern
fill 16 196 574 16 196 576 minecraft:cyan_concrete
setblock 16 196 577 minecraft:sea_lantern
fill 16 196 578 16 196 580 minecraft:cyan_concrete
setblock 16 196 581 minecraft:sea_lantern
fill 16 196 582 16 196 584 minecraft:cyan_concrete
fill 16 196 585 41 196 598 minecraft:black_concrete
setblock 17 196 568 minecraft:sea_lantern
fill 17 196 569 17 196 571 minecraft:cyan_concrete
fill 17 196 572 18 196 572 minecraft:sea_lantern
fill 17 196 573 17 196 575 minecraft:cyan_concrete
setblock 17 196 576 minecraft:sea_lantern
fill 17 196 577 17 196 579 minecraft:cyan_concrete
fill 17 196 580 18 196 580 minecraft:sea_lantern
fill 17 196 581 17 196 583 minecraft:cyan_concrete
setblock 17 196 584 minecraft:sea_lantern
fill 18 196 568 19 196 569 minecraft:cyan_concrete
fill 18 196 570 22 196 570 minecraft:black_concrete
fill 18 196 571 23 196 571 minecraft:sea_lantern
fill 18 196 573 18 196 575 minecraft:sea_lantern
fill 18 196 576 21 196 576 minecraft:black_concrete
fill 18 196 577 18 196 579 minecraft:sea_lantern
fill 18 196 581 22 196 581 minecraft:sea_lantern
fill 18 196 582 24 196 582 minecraft:black_concrete
setblock 18 196 583 minecraft:sea_lantern
fill 18 196 584 20 196 584 minecraft:cyan_concrete
fill 19 196 572 21 196 574 minecraft:black_concrete
fill 19 196 575 22 196 575 minecraft:sea_lantern
fill 19 196 577 22 196 577 minecraft:sea_lantern
fill 19 196 578 21 196 580 minecraft:black_concrete
fill 19 196 583 21 196 583 minecraft:cyan_concrete
setblock 20 196 568 minecraft:cyan_concrete
setblock 20 196 569 minecraft:sea_lantern
setblock 21 196 568 minecraft:sea_lantern
fill 21 196 569 22 196 569 minecraft:cyan_concrete
setblock 21 196 584 minecraft:sea_lantern
fill 22 196 568 24 196 568 minecraft:cyan_concrete
fill 22 196 572 23 196 574 minecraft:sea_lantern
setblock 22 196 576 minecraft:sea_lantern
fill 22 196 578 22 196 580 minecraft:sea_lantern
setblock 22 196 583 minecraft:sea_lantern
fill 22 196 584 24 196 584 minecraft:cyan_concrete
fill 23 196 569 23 196 570 minecraft:sea_lantern
fill 23 196 578 29 196 578 minecraft:sea_lantern
fill 23 196 579 24 196 581 minecraft:black_concrete
fill 23 196 583 25 196 583 minecraft:cyan_concrete
fill 24 196 569 28 196 569 minecraft:sea_lantern
fill 24 196 570 26 196 572 minecraft:black_concrete
fill 24 196 573 27 196 574 minecraft:sea_lantern
setblock 25 196 568 minecraft:sea_lantern
fill 25 196 579 25 196 582 minecraft:sea_lantern
setblock 25 196 584 minecraft:sea_lantern
fill 26 196 568 28 196 568 minecraft:cyan_concrete
fill 26 196 575 27 196 577 minecraft:sea_lantern
fill 26 196 579 28 196 581 minecraft:black_concrete
fill 26 196 582 26 196 583 minecraft:sea_lantern
fill 26 196 584 28 196 584 minecraft:cyan_concrete
fill 27 196 570 27 196 572 minecraft:sea_lantern
fill 27 196 582 29 196 582 minecraft:sea_lantern
fill 27 196 583 29 196 583 minecraft:cyan_concrete
fill 28 196 570 30 196 572 minecraft:black_concrete
fill 28 196 573 32 196 573 minecraft:sea_lantern
fill 28 196 574 30 196 576 minecraft:black_concrete
fill 28 196 577 32 196 577 minecraft:sea_lantern
setblock 29 196 568 minecraft:sea_lantern
fill 29 196 569 31 196 569 minecraft:cyan_concrete
fill 29 196 579 29 196 581 minecraft:sea_lantern
setblock 29 196 584 minecraft:sea_lantern
fill 30 196 568 32 196 568 minecraft:cyan_concrete
fill 30 196 578 30 196 582 minecraft:black_concrete
setblock 30 196 583 minecraft:sea_lantern
fill 30 196 584 32 196 584 minecraft:cyan_concrete
setblock 31 196 570 minecraft:sea_lantern
fill 31 196 571 32 196 572 minecraft:cyan_concrete
fill 31 196 574 31 196 576 minecraft:sea_lantern
setblock 31 196 578 minecraft:sea_lantern
fill 31 196 579 31 196 581 minecraft:cyan_concrete
setblock 31 196 582 minecraft:sea_lantern
fill 31 196 583 32 200 583 minecraft:cyan_concrete
setblock 32 196 569 minecraft:sea_lantern
setblock 32 196 570 minecraft:cyan_concrete
fill 32 196 574 32 196 576 minecraft:cyan_concrete
fill 32 196 578 32 196 580 minecraft:cyan_concrete
setblock 32 196 581 minecraft:sea_lantern
setblock 32 196 582 minecraft:cyan_concrete
fill 33 196 568 41 196 584 minecraft:black_concrete
fill 10 197 576 12 211 576 minecraft:pink_concrete
fill 11 197 575 11 211 575 minecraft:pink_concrete
fill 11 197 577 11 211 577 minecraft:pink_concrete
fill 14 197 566 15 211 567 minecraft:light_blue_concrete
fill 14 197 585 15 211 586 minecraft:light_blue_concrete
fill 16 197 569 18 200 569 minecraft:cyan_concrete
fill 16 197 583 18 200 583 minecraft:cyan_concrete
fill 17 197 568 17 200 568 minecraft:cyan_concrete
fill 17 197 570 17 200 570 minecraft:cyan_concrete
fill 17 197 582 17 200 582 minecraft:cyan_concrete
fill 17 197 584 17 200 584 minecraft:cyan_concrete
fill 23 197 563 25 211 563 minecraft:pink_concrete
fill 23 197 589 25 211 589 minecraft:pink_concrete
fill 24 197 562 24 211 562 minecraft:pink_concrete
fill 24 197 564 24 211 564 minecraft:pink_concrete
fill 24 197 588 24 211 588 minecraft:pink_concrete
fill 24 197 590 24 211 590 minecraft:pink_concrete
fill 30 197 569 32 200 569 minecraft:cyan_concrete
fill 30 197 583 30 200 583 minecraft:cyan_concrete
fill 31 197 568 31 200 568 minecraft:cyan_concrete
fill 31 197 570 31 200 570 minecraft:cyan_concrete
fill 31 197 582 31 200 582 minecraft:cyan_concrete
fill 31 197 584 31 200 584 minecraft:cyan_concrete
fill 33 197 566 34 211 567 minecraft:light_blue_concrete
fill 33 197 585 34 211 586 minecraft:light_blue_concrete
fill 36 197 576 38 211 576 minecraft:pink_concrete
fill 37 197 575 37 211 575 minecraft:pink_concrete
fill 37 197 577 37 211 577 minecraft:pink_concrete
setblock 3 198 560 minecraft:light[level=14]
setblock 3 198 568 minecraft:light[level=14]
setblock 3 198 576 minecraft:light[level=14]
setblock 3 198 584 minecraft:light[level=14]
setblock 3 198 592 minecraft:light[level=14]
setblock 11 198 560 minecraft:light[level=14]
setblock 11 198 568 minecraft:light[level=14]
setblock 11 198 584 minecraft:light[level=14]
setblock 11 198 592 minecraft:light[level=14]
fill 18 198 575 19 199 577 minecraft:magenta_concrete
setblock 19 198 560 minecraft:light[level=14]
setblock 19 198 568 minecraft:light[level=14]
fill 19 198 573 19 199 574 minecraft:magenta_concrete
fill 19 198 578 19 199 579 minecraft:magenta_concrete
setblock 19 198 584 minecraft:light[level=14]
setblock 19 198 592 minecraft:light[level=14]
fill 20 198 572 20 199 573 minecraft:magenta_concrete
fill 20 198 579 20 199 580 minecraft:magenta_concrete
fill 21 198 571 21 199 572 minecraft:magenta_concrete
fill 21 198 580 21 199 581 minecraft:magenta_concrete
fill 22 198 571 27 199 571 minecraft:magenta_concrete
fill 22 198 581 27 199 581 minecraft:magenta_concrete
fill 23 198 570 25 199 570 minecraft:magenta_concrete
fill 23 198 582 25 199 582 minecraft:magenta_concrete
setblock 27 198 560 minecraft:light[level=14]
setblock 27 198 568 minecraft:light[level=14]
fill 27 198 572 28 199 572 minecraft:magenta_concrete
setblock 27 198 576 minecraft:light[level=14]
fill 27 198 580 28 199 580 minecraft:magenta_concrete
setblock 27 198 584 minecraft:light[level=14]
setblock 27 198 592 minecraft:light[level=14]
fill 28 198 573 29 199 573 minecraft:magenta_concrete
fill 28 198 579 29 199 579 minecraft:magenta_concrete
fill 29 198 574 29 199 578 minecraft:magenta_concrete
fill 30 198 575 30 199 577 minecraft:magenta_concrete
setblock 35 198 560 minecraft:light[level=14]
setblock 35 198 568 minecraft:light[level=14]
setblock 35 198 576 minecraft:light[level=14]
setblock 35 198 584 minecraft:light[level=14]
setblock 35 198 592 minecraft:light[level=14]
fill 1 200 559 1 236 559 minecraft:gray_concrete
fill 1 200 569 1 236 569 minecraft:gray_concrete
fill 1 200 579 1 236 579 minecraft:gray_concrete
fill 1 200 589 1 236 589 minecraft:gray_concrete
fill 2 200 598 2 236 598 minecraft:gray_concrete
fill 8 200 558 8 236 558 minecraft:gray_concrete
fill 12 200 598 12 236 598 minecraft:gray_concrete
fill 18 200 558 18 236 558 minecraft:gray_concrete
fill 22 200 598 22 236 598 minecraft:gray_concrete
fill 28 200 558 28 236 558 minecraft:gray_concrete
fill 32 200 598 32 236 598 minecraft:gray_concrete
fill 38 200 558 38 236 558 minecraft:gray_concrete
fill 38 200 586 40 200 586 minecraft:gray_concrete
fill 41 200 565 41 236 565 minecraft:gray_concrete
fill 41 200 575 41 236 575 minecraft:gray_concrete
fill 41 200 585 41 236 585 minecraft:gray_concrete
fill 41 200 595 41 236 595 minecraft:gray_concrete
fill 0 202 563 0 202 566 minecraft:sea_lantern
fill 0 202 573 0 202 576 minecraft:sea_lantern
fill 0 202 583 0 202 586 minecraft:sea_lantern
fill 0 202 593 0 202 596 minecraft:sea_lantern
fill 3 202 557 6 202 557 minecraft:sea_lantern
fill 4 202 599 7 202 599 minecraft:sea_lantern
fill 13 202 557 16 202 557 minecraft:sea_lantern
fill 14 202 599 17 202 599 minecraft:sea_lantern
fill 16 202 575 17 203 577 minecraft:cyan_concrete
fill 17 202 572 17 203 574 minecraft:cyan_concrete
fill 17 202 578 17 203 580 minecraft:cyan_concrete
fill 18 202 571 18 203 572 minecraft:cyan_concrete
fill 18 202 580 18 203 581 minecraft:cyan_concrete
fill 19 202 570 19 203 571 minecraft:cyan_concrete
fill 19 202 581 19 203 582 minecraft:cyan_concrete
fill 20 202 569 20 203 570 minecraft:cyan_concrete
fill 20 202 582 20 203 583 minecraft:cyan_concrete
fill 21 202 569 28 203 569 minecraft:cyan_concrete
fill 21 202 583 28 203 583 minecraft:cyan_concrete
fill 23 202 557 26 202 557 minecraft:sea_lantern
fill 23 202 568 25 203 568 minecraft:cyan_concrete
fill 23 202 584 25 203 584 minecraft:cyan_concrete
fill 24 202 599 27 202 599 minecraft:sea_lantern
fill 28 202 570 29 203 570 minecraft:cyan_concrete
fill 28 202 582 29 203 582 minecraft:cyan_concrete
fill 29 202 571 30 203 571 minecraft:cyan_concrete
fill 29 202 581 30 203 581 minecraft:cyan_concrete
fill 30 202 572 31 203 572 minecraft:cyan_concrete
fill 30 202 580 31 203 580 minecraft:cyan_concrete
fill 31 202 573 31 203 579 minecraft:cyan_concrete
fill 32 202 575 32 203 577 minecraft:cyan_concrete
fill 33 202 557 36 202 557 minecraft:sea_lantern
fill 34 202 599 37 202 599 minecraft:sea_lantern
fill 42 202 558 42 202 561 minecraft:sea_lantern
fill 42 202 568 42 202 571 minecraft:sea_lantern
fill 42 202 578 42 202 581 minecraft:sea_lantern
fill 42 202 588 42 202 591 minecraft:sea_lantern
setblock 42 202 598 minecraft:sea_lantern
fill 0 203 563 0 210 566 minecraft:cyan_concrete
fill 0 203 573 0 210 576 minecraft:cyan_concrete
fill 0 203 583 0 210 586 minecraft:cyan_concrete
fill 0 203 593 0 210 596 minecraft:cyan_concrete
fill 3 203 557 6 210 557 minecraft:cyan_concrete
fill 4 203 599 7 210 599 minecraft:cyan_concrete
fill 13 203 557 16 210 557 minecraft:cyan_concrete
fill 14 203 599 17 210 599 minecraft:cyan_concrete
fill 23 203 557 26 210 557 minecraft:cyan_concrete
fill 24 203 599 27 210 599 minecraft:cyan_concrete
fill 33 203 557 36 210 557 minecraft:cyan_concrete
fill 34 203 599 37 210 599 minecraft:cyan_concrete
fill 42 203 558 42 210 561 minecraft:cyan_concrete
fill 42 203 568 42 210 571 minecraft:cyan_concrete
fill 42 203 578 42 210 581 minecraft:cyan_concrete
fill 42 203 588 42 210 591 minecraft:cyan_concrete
fill 42 203 598 42 210 598 minecraft:cyan_concrete
setblock 1 204 560 minecraft:black_concrete
setblock 1 204 570 minecraft:black_concrete
setblock 1 204 580 minecraft:black_concrete
setblock 1 204 590 minecraft:black_concrete
setblock 3 204 598 minecraft:black_concrete
setblock 7 204 558 minecraft:black_concrete
setblock 13 204 598 minecraft:black_concrete
setblock 17 204 558 minecraft:black_concrete
setblock 23 204 598 minecraft:black_concrete
setblock 27 204 558 minecraft:black_concrete
setblock 33 204 598 minecraft:black_concrete
setblock 37 204 558 minecraft:black_concrete
setblock 41 204 564 minecraft:black_concrete
setblock 41 204 574 minecraft:black_concrete
setblock 41 204 584 minecraft:black_concrete
setblock 41 204 594 minecraft:black_concrete
setblock 3 206 560 minecraft:light[level=14]
setblock 3 206 568 minecraft:light[level=14]
setblock 3 206 576 minecraft:light[level=14]
setblock 3 206 584 minecraft:light[level=14]
setblock 3 206 592 minecraft:light[level=14]
setblock 11 206 560 minecraft:light[level=14]
setblock 11 206 568 minecraft:light[level=14]
setblock 11 206 584 minecraft:light[level=14]
setblock 11 206 592 minecraft:light[level=14]
fill 14 206 575 15 207 577 minecraft:lime_concrete
fill 15 206 572 15 207 574 minecraft:lime_concrete
fill 15 206 578 15 207 580 minecraft:lime_concrete
fill 16 206 570 16 207 572 minecraft:lime_concrete
fill 16 206 580 16 207 582 minecraft:lime_concrete
fill 17 206 569 17 207 570 minecraft:lime_concrete
fill 17 206 582 17 207 583 minecraft:lime_concrete
fill 18 206 568 18 207 569 minecraft:lime_concrete
fill 18 206 583 18 207 584 minecraft:lime_concrete
setblock 19 206 560 minecraft:light[level=14]
fill 19 206 568 20 207 568 minecraft:lime_concrete
setblock 19 206 576 minecraft:light[level=14]
fill 19 206 584 20 207 584 minecraft:lime_concrete
setblock 19 206 592 minecraft:light[level=14]
fill 20 206 567 28 207 567 minecraft:lime_concrete
fill 20 206 585 28 207 585 minecraft:lime_concrete
fill 23 206 566 25 207 566 minecraft:lime_concrete
fill 23 206 586 25 207 586 minecraft:lime_concrete
setblock 27 206 560 minecraft:light[level=14]
setblock 27 206 568 minecraft:light[level=14]
setblock 27 206 576 minecraft:light[level=14]
setblock 27 206 584 minecraft:light[level=14]
setblock 27 206 592 minecraft:light[level=14]
fill 28 206 568 30 207 568 minecraft:lime_concrete
fill 28 206 584 30 207 584 minecraft:lime_concrete
fill 30 206 569 31 207 569 minecraft:lime_concrete
fill 30 206 583 31 207 583 minecraft:lime_concrete
fill 31 206 570 32 207 570 minecraft:lime_concrete
fill 31 206 582 32 207 582 minecraft:lime_concrete
fill 32 206 571 32 207 572 minecraft:lime_concrete
fill 32 206 580 32 207 581 minecraft:lime_concrete
fill 33 206 572 33 207 580 minecraft:lime_concrete
fill 34 206 575 34 207 577 minecraft:lime_concrete
setblock 35 206 560 minecraft:light[level=14]
setblock 35 206 568 minecraft:light[level=14]
setblock 35 206 576 minecraft:light[level=14]
setblock 35 206 584 minecraft:light[level=14]
setblock 35 206 592 minecraft:light[level=14]
fill 1 207 562 1 207 565 minecraft:black_concrete
fill 1 207 572 1 207 575 minecraft:black_concrete
fill 1 207 582 1 207 585 minecraft:black_concrete
fill 1 207 592 1 207 595 minecraft:black_concrete
fill 2 207 558 5 207 558 minecraft:black_concrete
fill 5 207 598 8 207 598 minecraft:black_concrete
fill 12 207 558 15 207 558 minecraft:black_concrete
fill 15 207 598 18 207 598 minecraft:black_concrete
fill 22 207 558 25 207 558 minecraft:black_concrete
fill 25 207 598 28 207 598 minecraft:black_concrete
fill 32 207 558 35 207 558 minecraft:black_concrete
fill 35 207 598 38 207 598 minecraft:black_concrete
fill 41 207 559 41 207 562 minecraft:black_concrete
fill 41 207 569 41 207 572 minecraft:black_concrete
fill 41 207 579 41 207 582 minecraft:black_concrete
fill 41 207 589 41 207 592 minecraft:black_concrete
setblock 1 210 560 minecraft:black_concrete
setblock 1 210 570 minecraft:black_concrete
setblock 1 210 580 minecraft:black_concrete
setblock 1 210 590 minecraft:black_concrete
setblock 3 210 598 minecraft:black_concrete
setblock 7 210 558 minecraft:black_concrete
setblock 13 210 598 minecraft:black_concrete
setblock 17 210 558 minecraft:black_concrete
setblock 23 210 598 minecraft:black_concrete
setblock 27 210 558 minecraft:black_concrete
setblock 33 210 598 minecraft:black_concrete
setblock 37 210 558 minecraft:black_concrete
setblock 41 210 564 minecraft:black_concrete
setblock 41 210 574 minecraft:black_concrete
setblock 41 210 584 minecraft:black_concrete
setblock 41 210 594 minecraft:black_concrete
fill 0 211 563 0 211 566 minecraft:sea_lantern
fill 0 211 573 0 211 576 minecraft:sea_lantern
fill 0 211 583 0 211 586 minecraft:sea_lantern
fill 0 211 593 0 211 596 minecraft:sea_lantern
fill 3 211 557 6 211 557 minecraft:sea_lantern
fill 4 211 599 7 211 599 minecraft:sea_lantern
fill 13 211 557 16 211 557 minecraft:sea_lantern
fill 14 211 599 17 211 599 minecraft:sea_lantern
fill 23 211 557 26 211 557 minecraft:sea_lantern
fill 24 211 599 27 211 599 minecraft:sea_lantern
fill 33 211 557 36 211 557 minecraft:sea_lantern
fill 34 211 599 37 211 599 minecraft:sea_lantern
fill 42 211 558 42 211 561 minecraft:sea_lantern
fill 42 211 568 42 211 571 minecraft:sea_lantern
fill 42 211 578 42 211 581 minecraft:sea_lantern
fill 42 211 588 42 211 591 minecraft:sea_lantern
setblock 42 211 598 minecraft:sea_lantern
fill 0 212 563 0 219 566 minecraft:cyan_concrete
fill 0 212 573 0 218 576 minecraft:cyan_concrete
fill 0 212 583 0 218 586 minecraft:cyan_concrete
fill 0 212 593 0 219 596 minecraft:cyan_concrete
fill 3 212 557 6 218 557 minecraft:cyan_concrete
fill 4 212 599 7 219 599 minecraft:cyan_concrete
fill 10 212 576 12 212 576 minecraft:glowstone
setblock 11 212 575 minecraft:glowstone
setblock 11 212 577 minecraft:glowstone
fill 13 212 557 16 219 557 minecraft:cyan_concrete
fill 14 212 566 15 212 567 minecraft:glowstone
fill 14 212 585 15 212 586 minecraft:glowstone
fill 14 212 599 17 219 599 minecraft:cyan_concrete
setblock 15 212 568 minecraft:glowstone
setblock 15 212 584 minecraft:glowstone
setblock 16 212 567 minecraft:glowstone
setblock 16 212 585 minecraft:glowstone
fill 23 212 557 26 219 557 minecraft:cyan_concrete
fill 23 212 563 25 212 563 minecraft:glowstone
fill 23 212 589 25 212 589 minecraft:glowstone
setblock 24 212 562 minecraft:glowstone
setblock 24 212 564 minecraft:glowstone
setblock 24 212 588 minecraft:glowstone
setblock 24 212 590 minecraft:glowstone
fill 24 212 599 27 218 599 minecraft:cyan_concrete
fill 32 212 567 34 212 567 minecraft:glowstone
fill 32 212 585 34 212 585 minecraft:glowstone
fill 33 212 557 36 219 557 minecraft:cyan_concrete
fill 33 212 566 34 212 566 minecraft:glowstone
setblock 33 212 568 minecraft:glowstone
setblock 33 212 584 minecraft:glowstone
fill 33 212 586 34 212 586 minecraft:glowstone
fill 34 212 599 37 219 599 minecraft:cyan_concrete
fill 36 212 576 38 212 576 minecraft:glowstone
setblock 37 212 575 minecraft:glowstone
setblock 37 212 577 minecraft:glowstone
fill 42 212 558 42 219 561 minecraft:cyan_concrete
fill 42 212 568 42 219 571 minecraft:cyan_concrete
fill 42 212 578 42 219 581 minecraft:cyan_concrete
fill 42 212 588 42 218 591 minecraft:cyan_concrete
fill 42 212 598 42 219 598 minecraft:cyan_concrete
fill 1 213 593 3 214 593 minecraft:gray_concrete
setblock 3 214 560 minecraft:light[level=14]
setblock 3 214 568 minecraft:light[level=14]
setblock 3 214 576 minecraft:light[level=14]
setblock 3 214 584 minecraft:light[level=14]
setblock 3 214 592 minecraft:light[level=14]
setblock 11 214 560 minecraft:light[level=14]
setblock 11 214 568 minecraft:light[level=14]
setblock 11 214 576 minecraft:light[level=14]
setblock 11 214 584 minecraft:light[level=14]
setblock 11 214 592 minecraft:light[level=14]
setblock 19 214 560 minecraft:light[level=14]
setblock 19 214 568 minecraft:light[level=14]
setblock 19 214 576 minecraft:light[level=14]
setblock 19 214 584 minecraft:light[level=14]
setblock 19 214 592 minecraft:light[level=14]
setblock 27 214 560 minecraft:light[level=14]
setblock 27 214 568 minecraft:light[level=14]
setblock 27 214 576 minecraft:light[level=14]
setblock 27 214 584 minecraft:light[level=14]
setblock 27 214 592 minecraft:light[level=14]
fill 33 214 595 33 215 597 minecraft:gray_concrete
setblock 35 214 560 minecraft:light[level=14]
setblock 35 214 568 minecraft:light[level=14]
setblock 35 214 576 minecraft:light[level=14]
setblock 35 214 584 minecraft:light[level=14]
setblock 35 214 592 minecraft:light[level=14]
setblock 1 216 560 minecraft:black_concrete
fill 1 216 562 1 216 565 minecraft:black_concrete
setblock 1 216 570 minecraft:black_concrete
fill 1 216 572 1 216 575 minecraft:black_concrete
setblock 1 216 580 minecraft:black_concrete
fill 1 216 582 1 216 585 minecraft:black_concrete
setblock 1 216 590 minecraft:black_concrete
fill 1 216 592 1 216 595 minecraft:black_concrete
fill 2 216 558 5 216 558 minecraft:black_concrete
setblock 3 216 598 minecraft:black_concrete
fill 5 216 598 8 216 598 minecraft:black_concrete
setblock 7 216 558 minecraft:black_concrete
fill 12 216 558 15 216 558 minecraft:black_concrete
setblock 13 216 598 minecraft:black_concrete
fill 15 216 598 18 216 598 minecraft:black_concrete
setblock 17 216 558 minecraft:black_concrete
fill 22 216 558 25 216 558 minecraft:black_concrete
setblock 23 216 598 minecraft:black_concrete
fill 24 216 559 24 217 560 minecraft:gray_concrete
fill 25 216 598 28 216 598 minecraft:black_concrete
setblock 27 216 558 minecraft:black_concrete
fill 32 216 558 35 216 558 minecraft:black_concrete
setblock 33 216 598 minecraft:black_concrete
fill 35 216 598 38 216 598 minecraft:black_concrete
setblock 37 216 558 minecraft:black_concrete
fill 41 216 559 41 216 562 minecraft:black_concrete
setblock 41 216 564 minecraft:black_concrete
fill 41 216 569 41 216 572 minecraft:black_concrete
setblock 41 216 574 minecraft:black_concrete
fill 41 216 579 41 216 582 minecraft:black_concrete
setblock 41 216 584 minecraft:black_concrete
fill 41 216 589 41 216 592 minecraft:black_concrete
setblock 41 216 594 minecraft:black_concrete
setblock 24 217 558 minecraft:gray_concrete
setblock 0 219 568 minecraft:black_concrete
fill 0 219 571 0 221 571 minecraft:black_concrete
fill 0 219 572 0 222 572 minecraft:cyan_concrete
setblock 0 219 573 minecraft:black_concrete
fill 0 219 574 0 219 580 minecraft:cyan_concrete
fill 0 219 581 0 220 581 minecraft:black_concrete
setblock 0 219 582 minecraft:cyan_concrete
setblock 0 219 583 minecraft:black_concrete
fill 0 219 584 0 219 586 minecraft:cyan_concrete
setblock 1 219 557 minecraft:black_concrete
setblock 3 219 557 minecraft:black_concrete
fill 4 219 557 6 219 557 minecraft:cyan_concrete
setblock 22 219 599 minecraft:black_concrete
fill 24 219 599 25 219 599 minecraft:cyan_concrete
setblock 26 219 599 minecraft:black_concrete
setblock 27 219 599 minecraft:cyan_concrete
fill 28 219 599 28 220 599 minecraft:black_concrete
fill 29 219 599 33 220 599 minecraft:cyan_concrete
setblock 42 219 588 minecraft:cyan_concrete
fill 42 219 589 42 219 590 minecraft:black_concrete
setblock 42 219 591 minecraft:cyan_concrete
setblock 42 219 594 minecraft:black_concrete
fill 0 220 563 0 220 566 minecraft:sea_lantern
fill 0 220 568 0 222 568 minecraft:cyan_concrete
fill 0 220 573 0 220 576 minecraft:sea_lantern
fill 0 220 577 0 220 580 minecraft:cyan_concrete
fill 0 220 582 0 221 582 minecraft:black_concrete
fill 0 220 583 0 220 586 minecraft:sea_lantern
fill 0 220 593 0 220 596 minecraft:sea_lantern
setblock 1 220 557 minecraft:cyan_concrete
fill 3 220 557 6 220 557 minecraft:sea_lantern
fill 4 220 599 7 220 599 minecraft:sea_lantern
fill 13 220 557 16 220 557 minecraft:sea_lantern
fill 14 220 599 17 220 599 minecraft:sea_lantern
fill 18 220 557 20 222 557 minecraft:cyan_concrete
fill 18 220 599 19 222 599 minecraft:cyan_concrete
fill 20 220 599 21 220 599 minecraft:black_concrete
setblock 21 220 557 minecraft:black_concrete
fill 22 220 557 22 222 557 minecraft:cyan_concrete
fill 22 220 599 22 222 599 minecraft:cyan_concrete
fill 23 220 557 26 220 557 minecraft:sea_lantern
fill 24 220 599 27 220 599 minecraft:sea_lantern
fill 33 220 557 36 220 557 minecraft:sea_lantern
fill 34 220 599 37 220 599 minecraft:sea_lantern
setblock 41 220 557 minecraft:black_concrete
fill 42 220 557 42 224 557 minecraft:cyan_concrete
fill 42 220 558 42 220 561 minecraft:sea_lantern
setblock 42 220 563 minecraft:black_concrete
fill 42 220 564 42 222 564 minecraft:cyan_concrete
setblock 42 220 565 minecraft:black_concrete
fill 42 220 566 42 222 566 minecraft:cyan_concrete
fill 42 220 568 42 220 571 minecraft:sea_lantern
fill 42 220 578 42 220 581 minecraft:sea_lantern
fill 42 220 586 42 222 586 minecraft:cyan_concrete
setblock 42 220 587 minecraft:black_concrete
fill 42 220 588 42 220 591 minecraft:sea_lantern
fill 42 220 592 42 222 592 minecraft:cyan_concrete
setblock 42 220 593 minecraft:black_concrete
fill 42 220 594 42 222 594 minecraft:cyan_concrete
setblock 42 220 598 minecraft:sea_lantern
fill 0 221 557 0 222 559 minecraft:cyan_concrete
fill 0 221 560 0 221 561 minecraft:black_concrete
fill 0 221 563 0 222 566 minecraft:cyan_concrete
fill 0 221 573 0 222 577 minecraft:cyan_concrete
setblock 0 221 578 minecraft:black_concrete
fill 0 221 579 0 222 581 minecraft:cyan_concrete
fill 0 221 583 0 222 586 minecraft:cyan_concrete
setblock 0 221 587 minecraft:black_concrete
fill 0 221 588 0 222 588 minecraft:cyan_concrete
fill 0 221 590 0 222 591 minecraft:cyan_concrete
setblock 0 221 592 minecraft:black_concrete
fill 0 221 593 0 222 596 minecraft:cyan_concrete
setblock 1 221 557 minecraft:black_concrete
fill 1 221 599 1 222 599 minecraft:cyan_concrete
setblock 2 221 599 minecraft:black_concrete
fill 3 221 557 11 222 557 minecraft:cyan_concrete
fill 3 221 599 7 222 599 minecraft:cyan_concrete
fill 9 221 599 11 222 599 minecraft:cyan_concrete
fill 12 221 557 13 221 557 minecraft:black_concrete
setblock 12 221 599 minecraft:black_concrete
fill 14 221 557 16 222 557 minecraft:cyan_concrete
fill 14 221 599 17 222 599 minecraft:cyan_concrete
fill 20 221 599 21 222 599 minecraft:cyan_concrete
fill 21 221 557 21 222 557 minecraft:cyan_concrete
fill 23 221 557 26 222 557 minecraft:cyan_concrete
setblock 24 221 599 minecraft:black_concrete
fill 25 221 599 30 222 599 minecraft:cyan_concrete
setblock 27 221 557 minecraft:black_concrete
setblock 31 221 599 minecraft:black_concrete
fill 32 221 599 37 222 599 minecraft:cyan_concrete
fill 33 221 557 36 222 557 minecraft:cyan_concrete
fill 41 221 557 41 222 557 minecraft:cyan_concrete
fill 42 221 558 42 222 561 minecraft:cyan_concrete
fill 42 221 563 42 222 563 minecraft:cyan_concrete
fill 42 221 565 42 222 565 minecraft:cyan_concrete
fill 42 221 568 42 222 571 minecraft:cyan_concrete
setblock 42 221 572 minecraft:black_concrete
fill 42 221 573 42 222 573 minecraft:cyan_concrete
fill 42 221 578 42 222 581 minecraft:cyan_concrete
setblock 42 221 582 minecraft:black_concrete
fill 42 221 587 42 222 591 minecraft:cyan_concrete
fill 42 221 593 42 222 593 minecraft:cyan_concrete
fill 42 221 598 42 222 598 minecraft:cyan_concrete
fill 0 222 560 0 222 561 minecraft:cyan_concrete
setblock 0 222 571 minecraft:cyan_concrete
setblock 0 222 578 minecraft:cyan_concrete
fill 0 222 582 0 223 582 minecraft:cyan_concrete
setblock 0 222 587 minecraft:cyan_concrete
setblock 0 222 592 minecraft:cyan_concrete
fill 1 222 557 1 223 557 minecraft:cyan_concrete
setblock 1 222 560 minecraft:black_concrete
setblock 1 222 570 minecraft:black_concrete
setblock 1 222 580 minecraft:black_concrete
setblock 1 222 590 minecraft:black_concrete
setblock 2 222 599 minecraft:cyan_concrete
setblock 3 222 560 minecraft:light[level=14]
setblock 3 222 568 minecraft:light[level=14]
setblock 3 222 576 minecraft:light[level=14]
setblock 3 222 584 minecraft:light[level=14]
setblock 3 222 592 minecraft:light[level=14]
setblock 3 222 598 minecraft:black_concrete
setblock 7 222 558 minecraft:black_concrete
setblock 11 222 560 minecraft:light[level=14]
setblock 11 222 568 minecraft:light[level=14]
setblock 11 222 576 minecraft:light[level=14]
setblock 11 222 584 minecraft:light[level=14]
setblock 11 222 592 minecraft:light[level=14]
fill 12 222 557 13 222 557 minecraft:cyan_concrete
setblock 12 222 599 minecraft:cyan_concrete
setblock 13 222 598 minecraft:black_concrete
setblock 17 222 558 minecraft:black_concrete
setblock 19 222 560 minecraft:light[level=14]
setblock 19 222 568 minecraft:light[level=14]
setblock 19 222 576 minecraft:light[level=14]
setblock 19 222 584 minecraft:light[level=14]
setblock 19 222 592 minecraft:light[level=14]
setblock 23 222 598 minecraft:black_concrete
fill 24 222 599 24 223 599 minecraft:cyan_concrete
setblock 27 222 557 minecraft:cyan_concrete
setblock 27 222 558 minecraft:black_concrete
setblock 27 222 560 minecraft:light[level=14]
setblock 27 222 568 minecraft:light[level=14]
setblock 27 222 576 minecraft:light[level=14]
setblock 27 222 584 minecraft:light[level=14]
setblock 27 222 592 minecraft:light[level=14]
setblock 31 222 599 minecraft:cyan_concrete
setblock 33 222 598 minecraft:black_concrete
setblock 35 222 560 minecraft:light[level=14]
setblock 35 222 568 minecraft:light[level=14]
setblock 35 222 576 minecraft:light[level=14]
setblock 35 222 584 minecraft:light[level=14]
setblock 35 222 592 minecraft:light[level=14]
setblock 37 222 558 minecraft:black_concrete
setblock 41 222 564 minecraft:black_concrete
setblock 41 222 574 minecraft:black_concrete
setblock 41 222 584 minecraft:black_concrete
setblock 41 222 594 minecraft:black_concrete
setblock 42 222 572 minecraft:cyan_concrete
setblock 42 222 582 minecraft:cyan_concrete
setblock 0 223 557 minecraft:black_concrete
setblock 0 223 558 minecraft:cyan_concrete
fill 0 223 559 0 224 564 minecraft:black_concrete
setblock 0 223 565 minecraft:cyan_concrete
fill 0 223 566 0 228 566 minecraft:black_concrete
fill 0 223 568 0 223 573 minecraft:black_concrete
setblock 0 223 574 minecraft:cyan_concrete
fill 0 223 575 0 224 581 minecraft:black_concrete
fill 0 223 583 0 223 584 minecraft:black_concrete
setblock 0 223 585 minecraft:cyan_concrete
fill 0 223 586 0 228 588 minecraft:black_concrete
setblock 0 223 590 minecraft:cyan_concrete
fill 0 223 591 0 307 592 minecraft:black_concrete
setblock 0 223 593 minecraft:cyan_concrete
fill 0 223 594 0 228 595 minecraft:black_concrete
setblock 0 223 596 minecraft:cyan_concrete
fill 0 223 597 0 224 599 minecraft:black_concrete
fill 1 223 599 13 223 599 minecraft:black_concrete
fill 2 223 557 30 223 557 minecraft:black_concrete
setblock 14 223 599 minecraft:cyan_concrete
setblock 15 223 599 minecraft:black_concrete
setblock 16 223 599 minecraft:cyan_concrete
fill 17 223 599 18 228 599 minecraft:black_concrete
setblock 19 223 599 minecraft:cyan_concrete
fill 20 223 599 23 307 599 minecraft:black_concrete
fill 25 223 599 35 223 599 minecraft:black_concrete
fill 31 223 557 31 224 557 minecraft:cyan_concrete
fill 32 223 557 41 223 557 minecraft:black_concrete
setblock 36 223 599 minecraft:cyan_concrete
fill 37 223 599 42 224 599 minecraft:black_concrete
fill 42 223 558 42 224 558 minecraft:cyan_concrete
fill 42 223 559 42 223 574 minecraft:black_concrete
fill 42 223 575 42 224 575 minecraft:cyan_concrete
fill 42 223 576 42 223 598 minecraft:black_concrete
setblock 0 224 557 minecraft:cyan_concrete
fill 0 224 558 0 307 558 minecraft:black_concrete
fill 0 224 565 0 228 565 minecraft:black_concrete
fill 0 224 567 0 224 568 minecraft:black_concrete
setblock 0 224 569 minecraft:cyan_concrete
fill 0 224 570 0 307 571 minecraft:black_concrete
setblock 0 224 572 minecraft:cyan_concrete
fill 0 224 573 0 224 574 minecraft:black_concrete
fill 0 224 582 0 224 583 minecraft:black_concrete
setblock 0 224 584 minecraft:cyan_concrete
fill 0 224 585 0 228 585 minecraft:black_concrete
fill 0 224 589 0 307 590 minecraft:black_concrete
fill 0 224 593 0 228 593 minecraft:black_concrete
fill 0 224 596 0 228 596 minecraft:black_concrete
fill 1 224 557 12 224 557 minecraft:black_concrete
fill 1 224 599 5 228 599 minecraft:black_concrete
setblock 6 224 599 minecraft:cyan_concrete
fill 7 224 599 14 228 599 minecraft:black_concrete
setblock 13 224 557 minecraft:cyan_concrete
fill 14 224 557 18 228 557 minecraft:black_concrete
setblock 15 224 599 minecraft:cyan_concrete
fill 16 224 599 16 228 599 minecraft:black_concrete
setblock 19 224 557 minecraft:cyan_concrete
fill 19 224 599 19 307 599 minecraft:black_concrete
fill 20 224 557 24 224 557 minecraft:black_concrete
fill 24 224 599 27 228 599 minecraft:black_concrete
fill 25 224 557 25 225 557 minecraft:cyan_concrete
fill 26 224 557 30 228 557 minecraft:black_concrete
setblock 28 224 599 minecraft:cyan_concrete
fill 29 224 599 36 224 599 minecraft:black_concrete
fill 32 224 557 39 224 557 minecraft:black_concrete
fill 40 224 557 41 224 557 minecraft:cyan_concrete
fill 42 224 559 42 228 563 minecraft:black_concrete
fill 42 224 564 42 224 565 minecraft:cyan_concrete
fill 42 224 566 42 307 566 minecraft:black_concrete
fill 42 224 567 42 225 567 minecraft:cyan_concrete
fill 42 224 568 42 228 569 minecraft:black_concrete
setblock 42 224 570 minecraft:cyan_concrete
fill 42 224 571 42 228 573 minecraft:black_concrete
setblock 42 224 574 minecraft:cyan_concrete
fill 42 224 576 42 228 584 minecraft:black_concrete
setblock 42 224 585 minecraft:cyan_concrete
fill 42 224 586 42 307 587 minecraft:black_concrete
fill 42 224 588 42 225 588 minecraft:cyan_concrete
fill 42 224 589 42 224 598 minecraft:black_concrete
fill 0 225 557 11 228 557 minecraft:black_concrete
fill 0 225 559 0 307 560 minecraft:black_concrete
setblock 0 225 561 minecraft:cyan_concrete
fill 0 225 562 1 225 563 minecraft:black_concrete
setblock 0 225 564 minecraft:cyan_concrete
setblock 0 225 567 minecraft:cyan_concrete
fill 0 225 568 0 307 569 minecraft:black_concrete
fill 0 225 572 1 225 572 minecraft:black_concrete
fill 0 225 573 0 225 574 minecraft:cyan_concrete
fill 0 225 575 0 228 576 minecraft:black_concrete
setblock 0 225 577 minecraft:cyan_concrete
fill 0 225 578 0 307 581 minecraft:black_concrete
setblock 0 225 582 minecraft:cyan_concrete
fill 0 225 583 1 225 584 minecraft:black_concrete
setblock 0 225 597 minecraft:cyan_concrete
fill 0 225 598 0 307 598 minecraft:black_concrete
setblock 0 225 599 minecraft:cyan_concrete
fill 1 225 564 1 225 565 minecraft:black_concrete
fill 1 225 573 1 225 575 minecraft:black_concrete
setblock 1 225 582 minecraft:black_concrete
setblock 1 225 585 minecraft:black_concrete
fill 1 225 592 1 225 595 minecraft:black_concrete
fill 2 225 558 5 225 558 minecraft:black_concrete
fill 5 225 598 8 225 598 minecraft:black_concrete
fill 6 225 599 6 228 599 minecraft:black_concrete
setblock 12 225 557 minecraft:cyan_concrete
fill 12 225 558 15 225 558 minecraft:black_concrete
fill 13 225 557 13 228 557 minecraft:black_concrete
fill 15 225 598 15 225 599 minecraft:black_concrete
fill 16 225 598 18 225 598 minecraft:black_concrete
fill 19 225 557 20 307 557 minecraft:black_concrete
setblock 21 225 557 minecraft:cyan_concrete
fill 22 225 557 24 225 558 minecraft:black_concrete
setblock 25 225 558 minecraft:black_concrete
fill 25 225 598 28 225 598 minecraft:black_concrete
fill 28 225 599 28 307 599 minecraft:black_concrete
setblock 29 225 599 minecraft:cyan_concrete
fill 30 225 599 31 307 599 minecraft:black_concrete
fill 31 225 557 32 307 557 minecraft:black_concrete
fill 32 225 558 35 225 558 minecraft:black_concrete
setblock 32 225 599 minecraft:cyan_concrete
setblock 33 225 557 minecraft:cyan_concrete
fill 33 225 599 41 228 599 minecraft:black_concrete
fill 34 225 557 35 228 557 minecraft:black_concrete
fill 35 225 598 38 225 598 minecraft:black_concrete
setblock 36 225 557 minecraft:cyan_concrete
fill 37 225 557 38 307 557 minecraft:black_concrete
setblock 39 225 557 minecraft:cyan_concrete
fill 40 225 557 42 307 557 minecraft:black_concrete
fill 41 225 559 41 225 562 minecraft:black_concrete
fill 41 225 569 41 225 572 minecraft:black_concrete
fill 41 225 579 41 225 582 minecraft:black_concrete
fill 41 225 589 41 225 592 minecraft:black_concrete
fill 42 225 558 42 228 558 minecraft:black_concrete
fill 42 225 564 42 307 564 minecraft:black_concrete
setblock 42 225 565 minecraft:cyan_concrete
fill 42 225 570 42 228 570 minecraft:black_concrete
fill 42 225 574 42 307 575 minecraft:black_concrete
fill 42 225 585 42 307 585 minecraft:black_concrete
setblock 42 225 589 minecraft:cyan_concrete
fill 42 225 590 42 228 591 minecraft:black_concrete
setblock 42 225 592 minecraft:cyan_concrete
fill 42 225 593 42 307 593 minecraft:black_concrete
setblock 42 225 594 minecraft:cyan_concrete
fill 42 225 595 42 228 598 minecraft:black_concrete
setblock 42 225 599 minecraft:cyan_concrete
fill 0 226 561 0 228 564 minecraft:black_concrete
fill 0 226 567 0 307 567 minecraft:black_concrete
fill 0 226 572 0 228 574 minecraft:black_concrete
fill 0 226 577 0 307 577 minecraft:black_concrete
fill 0 226 582 0 228 584 minecraft:black_concrete
fill 0 226 597 0 307 597 minecraft:black_concrete
fill 0 226 599 0 307 599 minecraft:black_concrete
fill 4 226 575 4 227 575 minecraft:black_concrete
fill 4 226 580 4 227 580 minecraft:black_concrete
fill 8 226 561 8 227 561 minecraft:black_concrete
fill 12 226 557 12 307 557 minecraft:black_concrete
fill 15 226 599 15 228 599 minecraft:black_concrete
fill 21 226 557 25 228 557 minecraft:black_concrete
fill 27 226 561 27 227 561 minecraft:black_concrete
fill 29 226 599 29 307 599 minecraft:black_concrete
fill 32 226 599 32 307 599 minecraft:black_concrete
fill 33 226 557 33 228 557 minecraft:black_concrete
fill 36 226 557 36 228 557 minecraft:black_concrete
fill 37 226 580 37 227 580 minecraft:black_concrete
fill 37 226 587 37 227 587 minecraft:black_concrete
fill 38 226 561 38 227 561 minecraft:black_concrete
fill 39 226 557 39 307 557 minecraft:black_concrete
fill 42 226 565 42 307 565 minecraft:black_concrete
fill 42 226 567 42 307 567 minecraft:black_concrete
fill 42 226 588 42 228 589 minecraft:black_concrete
fill 42 226 592 42 307 592 minecraft:black_concrete
fill 42 226 594 42 307 594 minecraft:black_concrete
fill 42 226 599 42 307 599 minecraft:black_concrete
fill 3 227 575 3 228 575 minecraft:black_concrete
fill 3 227 580 3 228 580 minecraft:black_concrete
fill 8 227 560 8 228 560 minecraft:black_concrete
fill 27 227 560 27 228 560 minecraft:black_concrete
fill 38 227 560 38 228 560 minecraft:black_concrete
fill 38 227 580 38 228 580 minecraft:black_concrete
fill 38 227 587 38 228 587 minecraft:black_concrete
setblock 1 228 560 minecraft:black_concrete
setblock 1 228 570 minecraft:black_concrete
fill 1 228 580 2 229 580 minecraft:black_concrete
setblock 1 228 590 minecraft:black_concrete
fill 2 228 575 2 229 575 minecraft:black_concrete
setblock 3 228 598 minecraft:black_concrete
setblock 7 228 558 minecraft:black_concrete
fill 8 228 559 8 229 559 minecraft:black_concrete
setblock 13 228 598 minecraft:black_concrete
setblock 17 228 558 minecraft:black_concrete
setblock 23 228 598 minecraft:black_concrete
fill 27 228 558 27 229 559 minecraft:black_concrete
setblock 33 228 598 minecraft:black_concrete
setblock 37 228 558 minecraft:black_concrete
fill 38 228 559 38 229 559 minecraft:black_concrete
fill 39 228 580 39 229 580 minecraft:black_concrete
fill 39 228 587 39 229 587 minecraft:black_concrete
setblock 41 228 564 minecraft:black_concrete
setblock 41 228 574 minecraft:black_concrete
setblock 41 228 584 minecraft:black_concrete
setblock 41 228 594 minecraft:black_concrete
fill 0 229 557 2 307 557 minecraft:black_concrete
fill 0 229 561 0 307 562 minecraft:black_concrete
fill 0 229 563 0 229 566 minecraft:sea_lantern
fill 0 229 572 0 307 572 minecraft:black_concrete
fill 0 229 573 0 229 576 minecraft:sea_lantern
fill 0 229 582 0 307 582 minecraft:black_concrete
fill 0 229 583 0 229 586 minecraft:sea_lantern
fill 0 229 587 0 307 588 minecraft:black_concrete
fill 0 229 593 0 229 596 minecraft:sea_lantern
fill 1 229 575 1 231 575 minecraft:black_concrete
fill 1 229 599 3 307 599 minecraft:black_concrete
fill 3 229 557 6 229 557 minecraft:sea_lantern
fill 4 229 561 4 231 561 minecraft:black_concrete
fill 4 229 599 7 229 599 minecraft:sea_lantern
fill 7 229 557 11 307 557 minecraft:black_concrete
fill 8 229 599 13 307 599 minecraft:black_concrete
fill 12 229 594 12 230 594 minecraft:black_concrete
fill 13 229 557 16 229 557 minecraft:sea_lantern
fill 14 229 599 17 229 599 minecraft:sea_lantern
fill 16 229 595 16 229 597 minecraft:gray_concrete
fill 17 229 557 18 307 557 minecraft:black_concrete
fill 18 229 599 18 307 599 minecraft:black_concrete
fill 21 229 557 22 307 557 minecraft:black_concrete
fill 23 229 557 26 229 557 minecraft:sea_lantern
fill 24 229 599 27 229 599 minecraft:sea_lantern
fill 27 229 557 30 307 557 minecraft:black_concrete
setblock 32 229 561 minecraft:black_concrete
fill 32 229 594 32 230 594 minecraft:black_concrete
fill 33 229 557 36 229 557 minecraft:sea_lantern
fill 33 229 599 33 307 599 minecraft:black_concrete
fill 34 229 599 37 229 599 minecraft:sea_lantern
fill 37 229 562 37 230 562 minecraft:black_concrete
fill 37 229 570 37 230 570 minecraft:black_concrete
fill 37 229 591 37 230 591 minecraft:black_concrete
fill 38 229 599 41 307 599 minecraft:black_concrete
fill 40 229 580 40 231 580 minecraft:black_concrete
fill 40 229 587 40 231 587 minecraft:black_concrete
fill 42 229 558 42 229 561 minecraft:sea_lantern
fill 42 229 562 42 307 563 minecraft:black_concrete
fill 42 229 568 42 229 571 minecraft:sea_lantern
fill 42 229 572 42 307 573 minecraft:black_concrete
fill 42 229 576 42 307 577 minecraft:black_concrete
fill 42 229 578 42 229 581 minecraft:sea_lantern
fill 42 229 582 42 307 584 minecraft:black_concrete
fill 42 229 588 42 229 591 minecraft:sea_lantern
fill 42 229 595 42 307 597 minecraft:black_concrete
setblock 42 229 598 minecraft:sea_lantern
fill 0 230 563 0 246 566 minecraft:black_concrete
fill 0 230 573 0 246 576 minecraft:black_concrete
fill 0 230 583 0 246 586 minecraft:black_concrete
fill 0 230 593 0 246 596 minecraft:black_concrete
fill 1 230 580 1 231 580 minecraft:black_concrete
fill 3 230 557 6 246 557 minecraft:black_concrete
setblock 3 230 560 minecraft:light[level=14]
fill 3 230 561 3 231 561 minecraft:black_concrete
setblock 3 230 568 minecraft:light[level=14]
setblock 3 230 576 minecraft:light[level=14]
setblock 3 230 584 minecraft:light[level=14]
setblock 3 230 592 minecraft:light[level=14]
setblock 4 230 565 minecraft:sea_lantern
setblock 4 230 571 minecraft:sea_lantern
setblock 4 230 577 minecraft:sea_lantern
setblock 4 230 583 minecraft:sea_lantern
setblock 4 230 589 minecraft:sea_lantern
setblock 4 230 595 minecraft:sea_lantern
fill 4 230 599 7 246 599 minecraft:black_concrete
setblock 8 230 561 minecraft:sea_lantern
setblock 10 230 595 minecraft:sea_lantern
setblock 11 230 560 minecraft:light[level=14]
setblock 11 230 568 minecraft:light[level=14]
setblock 11 230 576 minecraft:light[level=14]
setblock 11 230 584 minecraft:light[level=14]
setblock 11 230 592 minecraft:light[level=14]
fill 12 230 595 12 231 595 minecraft:black_concrete
fill 13 230 557 16 246 557 minecraft:black_concrete
setblock 14 230 561 minecraft:sea_lantern
fill 14 230 599 17 246 599 minecraft:black_concrete
setblock 16 230 595 minecraft:sea_lantern
fill 16 230 596 16 230 597 minecraft:gray_concrete
setblock 19 230 560 minecraft:light[level=14]
setblock 19 230 568 minecraft:light[level=14]
setblock 19 230 576 minecraft:light[level=14]
setblock 19 230 584 minecraft:light[level=14]
setblock 19 230 592 minecraft:light[level=14]
setblock 20 230 561 minecraft:sea_lantern
setblock 22 230 595 minecraft:sea_lantern
fill 23 230 557 26 246 557 minecraft:black_concrete
fill 24 230 599 27 246 599 minecraft:black_concrete
setblock 26 230 561 minecraft:sea_lantern
fill 27 230 558 27 231 558 minecraft:black_concrete
setblock 27 230 560 minecraft:light[level=14]
setblock 27 230 568 minecraft:light[level=14]
setblock 27 230 576 minecraft:light[level=14]
setblock 27 230 584 minecraft:light[level=14]
setblock 27 230 592 minecraft:light[level=14]
setblock 28 230 595 minecraft:sea_lantern
fill 32 230 560 32 231 560 minecraft:black_concrete
setblock 32 230 561 minecraft:sea_lantern
fill 32 230 595 32 231 595 minecraft:black_concrete
fill 33 230 557 36 246 557 minecraft:black_concrete
setblock 34 230 595 minecraft:sea_lantern
fill 34 230 599 37 246 599 minecraft:black_concrete
setblock 35 230 560 minecraft:light[level=14]
setblock 35 230 568 minecraft:light[level=14]
setblock 35 230 576 minecraft:light[level=14]
setblock 35 230 584 minecraft:light[level=14]
setblock 35 230 592 minecraft:light[level=14]
setblock 38 230 561 minecraft:sea_lantern
fill 38 230 562 38 231 562 minecraft:black_concrete
setblock 38 230 567 minecraft:sea_lantern
fill 38 230 570 38 231 570 minecraft:black_concrete
setblock 38 230 573 minecraft:sea_lantern
setblock 38 230 579 minecraft:sea_lantern
setblock 38 230 585 minecraft:sea_lantern
setblock 38 230 591 minecraft:sea_lantern
fill 42 230 558 42 246 561 minecraft:black_concrete
fill 42 230 568 42 246 571 minecraft:black_concrete
fill 42 230 578 42 246 581 minecraft:black_concrete
fill 42 230 588 42 246 591 minecraft:black_concrete
fill 42 230 598 42 246 598 minecraft:black_concrete
fill 1 231 558 7 231 558 minecraft:black_concrete
fill 1 231 560 2 231 568 minecraft:black_concrete
fill 1 231 570 4 231 574 minecraft:black_concrete
fill 1 231 576 4 231 578 minecraft:black_concrete
fill 1 231 581 4 231 588 minecraft:black_concrete
fill 1 231 590 1 231 598 minecraft:black_concrete
fill 2 231 559 41 231 559 minecraft:black_concrete
fill 2 231 569 4 231 569 minecraft:black_concrete
fill 2 231 575 4 231 575 minecraft:black_concrete
fill 2 231 579 4 231 580 minecraft:black_concrete
fill 2 231 589 4 231 597 minecraft:black_concrete
fill 3 231 560 31 231 560 minecraft:black_concrete
fill 3 231 562 4 231 568 minecraft:black_concrete
fill 3 231 598 11 231 598 minecraft:black_concrete
fill 5 231 561 41 231 561 minecraft:black_concrete
fill 5 231 595 11 231 597 minecraft:black_concrete
fill 9 231 558 17 231 558 minecraft:black_concrete
fill 12 231 596 41 231 597 minecraft:black_concrete
fill 13 231 595 31 231 595 minecraft:black_concrete
fill 13 231 598 21 231 598 minecraft:black_concrete
fill 19 231 558 26 231 558 minecraft:black_concrete
fill 23 231 598 31 231 598 minecraft:black_concrete
fill 29 231 558 37 231 558 minecraft:black_concrete
fill 33 231 560 41 231 560 minecraft:black_concrete
fill 33 231 595 40 231 595 minecraft:black_concrete
fill 33 231 598 41 231 598 minecraft:black_concrete
fill 38 231 563 40 231 569 minecraft:black_concrete
fill 38 231 571 39 231 594 minecraft:black_concrete
fill 39 231 558 41 231 558 minecraft:black_concrete
fill 39 231 562 41 231 562 minecraft:black_concrete
fill 39 231 570 41 231 570 minecraft:black_concrete
fill 40 231 571 40 231 579 minecraft:black_concrete
fill 40 231 581 40 231 586 minecraft:black_concrete
fill 40 231 588 41 231 594 minecraft:black_concrete
fill 41 231 563 41 231 564 minecraft:black_concrete
fill 41 231 566 41 231 569 minecraft:black_concrete
fill 41 231 571 41 231 574 minecraft:black_concrete
fill 41 231 576 41 231 584 minecraft:black_concrete
fill 41 231 586 41 231 587 minecraft:black_concrete
fill 1 232 561 2 232 561 minecraft:black_concrete
fill 4 232 561 4 232 595 minecraft:cyan_concrete
fill 5 232 561 38 232 561 minecraft:cyan_concrete
fill 5 232 595 38 232 595 minecraft:cyan_concrete
fill 12 232 596 12 232 597 minecraft:black_concrete
fill 32 232 558 32 232 559 minecraft:black_concrete
fill 32 232 596 32 232 597 minecraft:black_concrete
fill 38 232 562 38 232 594 minecraft:cyan_concrete
fill 39 232 562 40 232 562 minecraft:black_concrete
fill 39 232 570 40 232 570 minecraft:black_concrete
fill 39 232 591 40 232 591 minecraft:black_concrete
fill 1 233 561 1 234 561 minecraft:black_concrete
setblock 4 233 565 minecraft:sea_lantern
setblock 4 233 571 minecraft:sea_lantern
setblock 4 233 577 minecraft:sea_lantern
setblock 4 233 583 minecraft:sea_lantern
setblock 4 233 589 minecraft:sea_lantern
setblock 4 233 595 minecraft:sea_lantern
setblock 8 233 561 minecraft:sea_lantern
setblock 10 233 595 minecraft:sea_lantern
fill 12 233 597 12 234 597 minecraft:black_concrete
setblock 14 233 561 minecraft:sea_lantern
setblock 16 233 595 minecraft:sea_lantern
setblock 20 233 561 minecraft:sea_lantern
setblock 22 233 595 minecraft:sea_lantern
setblock 26 233 561 minecraft:sea_lantern
setblock 28 233 595 minecraft:sea_lantern
fill 32 233 558 32 234 558 minecraft:black_concrete
setblock 32 233 561 minecraft:sea_lantern
fill 32 233 597 32 234 597 minecraft:black_concrete
setblock 34 233 595 minecraft:sea_lantern
setblock 38 233 561 minecraft:sea_lantern
setblock 38 233 567 minecraft:sea_lantern
setblock 38 233 573 minecraft:sea_lantern
setblock 38 233 579 minecraft:sea_lantern
setblock 38 233 585 minecraft:sea_lantern
setblock 38 233 591 minecraft:sea_lantern
fill 40 233 562 40 234 562 minecraft:black_concrete
fill 40 233 570 40 234 570 minecraft:black_concrete
fill 40 233 591 40 234 591 minecraft:black_concrete
fill 1 234 558 7 234 558 minecraft:black_concrete
fill 1 234 560 41 234 560 minecraft:black_concrete
fill 1 234 562 4 234 568 minecraft:black_concrete
fill 1 234 570 4 234 578 minecraft:black_concrete
fill 1 234 580 4 234 588 minecraft:black_concrete
fill 1 234 590 1 234 598 minecraft:black_concrete
fill 2 234 559 41 234 559 minecraft:black_concrete
fill 2 234 561 41 234 561 minecraft:black_concrete
fill 2 234 569 4 234 569 minecraft:black_concrete
fill 2 234 579 4 234 579 minecraft:black_concrete
fill 2 234 589 4 234 597 minecraft:black_concrete
fill 3 234 598 11 234 598 minecraft:black_concrete
fill 5 234 595 11 234 597 minecraft:black_concrete
fill 9 234 558 17 234 558 minecraft:black_concrete
fill 12 234 595 40 234 596 minecraft:black_concrete
fill 13 234 597 21 234 598 minecraft:black_concrete
fill 19 234 558 27 234 558 minecraft:black_concrete
fill 22 234 597 31 234 597 minecraft:black_concrete
fill 23 234 598 31 234 598 minecraft:black_concrete
fill 29 234 558 31 234 558 minecraft:black_concrete
fill 33 234 558 37 234 558 minecraft:black_concrete
fill 33 234 597 41 234 598 minecraft:black_concrete
fill 38 234 562 39 234 594 minecraft:black_concrete
fill 39 234 558 41 234 558 minecraft:black_concrete
fill 40 234 563 40 234 569 minecraft:black_concrete
fill 40 234 571 40 234 590 minecraft:black_concrete
fill 40 234 592 41 234 594 minecraft:black_concrete
fill 41 234 562 41 234 564 minecraft:black_concrete
fill 41 234 566 41 234 574 minecraft:black_concrete
fill 41 234 576 41 234 584 minecraft:black_concrete
fill 41 234 586 41 234 591 minecraft:black_concrete
setblock 41 234 596 minecraft:black_concrete
fill 4 235 561 4 235 595 minecraft:cyan_concrete
fill 5 235 561 38 235 561 minecraft:cyan_concrete
fill 5 235 595 38 235 595 minecraft:cyan_concrete
fill 14 235 558 14 236 560 minecraft:gray_concrete
fill 38 235 562 38 235 594 minecraft:cyan_concrete
setblock 3 238 560 minecraft:light[level=14]
setblock 3 238 568 minecraft:light[level=14]
setblock 3 238 576 minecraft:light[level=14]
setblock 3 238 584 minecraft:light[level=14]
setblock 3 238 592 minecraft:light[level=14]
setblock 11 238 560 minecraft:light[level=14]
setblock 11 238 568 minecraft:light[level=14]
setblock 11 238 576 minecraft:light[level=14]
setblock 11 238 584 minecraft:light[level=14]
setblock 11 238 592 minecraft:light[level=14]
setblock 19 238 560 minecraft:light[level=14]
setblock 19 238 568 minecraft:light[level=14]
setblock 19 238 576 minecraft:light[level=14]
setblock 19 238 584 minecraft:light[level=14]
setblock 19 238 592 minecraft:light[level=14]
setblock 27 238 560 minecraft:light[level=14]
setblock 27 238 568 minecraft:light[level=14]
setblock 27 238 576 minecraft:light[level=14]
setblock 27 238 584 minecraft:light[level=14]
setblock 27 238 592 minecraft:light[level=14]
setblock 35 238 560 minecraft:light[level=14]
setblock 35 238 568 minecraft:light[level=14]
setblock 35 238 576 minecraft:light[level=14]
setblock 35 238 584 minecraft:light[level=14]
setblock 35 238 592 minecraft:light[level=14]
fill 16 241 573 18 241 575 minecraft:redstone_block
fill 20 241 569 22 241 571 minecraft:redstone_block
fill 25 241 571 27 241 573 minecraft:redstone_block
fill 25 241 577 27 241 579 minecraft:redstone_block
fill 11 242 564 12 242 586 minecraft:magenta_concrete
fill 13 242 564 33 242 565 minecraft:magenta_concrete
fill 13 242 566 15 242 584 minecraft:black_concrete
fill 13 242 585 33 242 586 minecraft:magenta_concrete
fill 16 242 566 19 242 572 minecraft:black_concrete
fill 16 242 576 20 242 584 minecraft:black_concrete
fill 19 242 573 20 242 575 minecraft:black_concrete
fill 20 242 566 31 242 568 minecraft:black_concrete
fill 20 242 572 24 242 572 minecraft:black_concrete
fill 21 242 573 24 242 573 minecraft:black_concrete
fill 21 242 577 24 242 584 minecraft:black_concrete
fill 23 242 569 24 242 571 minecraft:black_concrete
fill 24 242 574 31 242 576 minecraft:black_concrete
fill 25 242 569 31 242 570 minecraft:black_concrete
fill 25 242 580 31 242 584 minecraft:black_concrete
fill 28 242 571 31 242 573 minecraft:black_concrete
fill 28 242 577 31 242 579 minecraft:black_concrete
fill 32 242 566 33 242 584 minecraft:magenta_concrete
fill 1 243 558 10 243 598 minecraft:black_concrete
fill 11 243 558 41 243 563 minecraft:black_concrete
fill 11 243 564 11 243 565 minecraft:magenta_concrete
setblock 11 243 566 minecraft:sea_lantern
fill 11 243 567 11 243 569 minecraft:magenta_concrete
setblock 11 243 570 minecraft:sea_lantern
fill 11 243 571 11 243 573 minecraft:magenta_concrete
setblock 11 243 574 minecraft:sea_lantern
fill 11 243 575 11 243 577 minecraft:magenta_concrete
setblock 11 243 578 minecraft:sea_lantern
fill 11 243 579 11 243 581 minecraft:magenta_concrete
setblock 11 243 582 minecraft:sea_lantern
fill 11 243 583 11 243 585 minecraft:magenta_concrete
setblock 11 243 586 minecraft:sea_lantern
fill 11 243 587 41 243 598 minecraft:black_concrete
fill 12 243 564 12 247 564 minecraft:magenta_concrete
setblock 12 243 565 minecraft:sea_lantern
fill 12 243 566 12 243 568 minecraft:magenta_concrete
setblock 12 243 569 minecraft:sea_lantern
fill 12 243 570 12 243 572 minecraft:magenta_concrete
setblock 12 243 573 minecraft:sea_lantern
fill 12 243 574 12 243 576 minecraft:magenta_concrete
setblock 12 243 577 minecraft:sea_lantern
fill 12 243 578 12 243 580 minecraft:magenta_concrete
setblock 12 243 581 minecraft:sea_lantern
fill 12 243 582 12 243 584 minecraft:magenta_concrete
setblock 12 243 585 minecraft:sea_lantern
fill 12 243 586 14 243 586 minecraft:magenta_concrete
setblock 13 243 564 minecraft:sea_lantern
fill 13 243 565 15 243 565 minecraft:magenta_concrete
fill 13 243 566 14 243 584 minecraft:black_concrete
fill 13 243 585 15 243 585 minecraft:magenta_concrete
fill 14 243 564 16 243 564 minecraft:magenta_concrete
fill 15 243 566 18 243 571 minecraft:black_concrete
fill 15 243 572 15 243 576 minecraft:sea_lantern
fill 15 243 577 19 243 584 minecraft:black_concrete
setblock 15 243 586 minecraft:sea_lantern
setblock 16 243 565 minecraft:sea_lantern
fill 16 243 572 24 243 572 minecraft:sea_lantern
fill 16 243 573 18 243 575 minecraft:black_concrete
fill 16 243 576 19 243 576 minecraft:sea_lantern
setblock 16 243 585 minecraft:sea_lantern
fill 16 243 586 18 243 586 minecraft:magenta_concrete
setblock 17 243 564 minecraft:sea_lantern
fill 17 243 565 19 243 565 minecraft:magenta_concrete
fill 17 243 585 19 243 585 minecraft:magenta_concrete
fill 18 243 564 20 243 564 minecraft:magenta_concrete
fill 19 243 566 31 243 567 minecraft:black_concrete
fill 19 243 568 19 243 571 minecraft:sea_lantern
fill 19 243 573 19 243 575 minecraft:sea_lantern
setblock 19 243 586 minecraft:sea_lantern
setblock 20 243 565 minecraft:sea_lantern
fill 20 243 568 23 243 568 minecraft:sea_lantern
fill 20 243 569 22 243 571 minecraft:black_concrete
setblock 20 243 573 minecraft:sea_lantern
fill 20 243 574 20 243 576 minecraft:ochre_froglight
setblock 20 243 577 minecraft:sea_lantern
fill 20 243 578 23 243 584 minecraft:black_concrete
setblock 20 243 585 minecraft:sea_lantern
fill 20 243 586 22 243 586 minecraft:magenta_concrete
setblock 21 243 564 minecraft:sea_lantern
fill 21 243 565 23 243 565 minecraft:magenta_concrete
fill 21 243 573 23 243 573 minecraft:ochre_froglight
fill 21 243 577 23 243 577 minecraft:ochre_froglight
fill 21 243 585 23 243 585 minecraft:magenta_concrete
fill 22 243 564 24 243 564 minecraft:magenta_concrete
fill 23 243 569 23 243 571 minecraft:sea_lantern
setblock 23 243 586 minecraft:sea_lantern
setblock 24 243 565 minecraft:sea_lantern
fill 24 243 568 31 243 569 minecraft:black_concrete
fill 24 243 570 24 243 571 minecraft:sea_lantern
setblock 24 243 573 minecraft:sea_lantern
fill 24 243 574 24 243 576 minecraft:ochre_froglight
fill 24 243 577 24 243 580 minecraft:sea_lantern
fill 24 243 581 31 243 584 minecraft:black_concrete
setblock 24 243 585 minecraft:sea_lantern
fill 24 243 586 26 243 586 minecraft:magenta_concrete
setblock 25 243 564 minecraft:sea_lantern
fill 25 243 565 27 243 565 minecraft:magenta_concrete
fill 25 243 570 28 243 570 minecraft:sea_lantern
fill 25 243 571 27 243 573 minecraft:black_concrete
fill 25 243 574 28 243 574 minecraft:sea_lantern
fill 25 243 575 31 243 575 minecraft:black_concrete
fill 25 243 576 28 243 576 minecraft:sea_lantern
fill 25 243 577 27 243 579 minecraft:black_concrete
fill 25 243 580 28 243 580 minecraft:sea_lantern
fill 25 243 585 27 243 585 minecraft:magenta_concrete
fill 26 243 564 28 243 564 minecraft:magenta_concrete
setblock 27 243 586 minecraft:sea_lantern
setblock 28 243 565 minecraft:sea_lantern
fill 28 243 571 28 243 573 minecraft:sea_lantern
fill 28 243 577 28 243 579 minecraft:sea_lantern
setblock 28 243 585 minecraft:sea_lantern
fill 28 243 586 30 243 586 minecraft:magenta_concrete
setblock 29 243 564 minecraft:sea_lantern
fill 29 243 565 31 243 565 minecraft:magenta_concrete
fill 29 243 570 31 243 574 minecraft:black_concrete
fill 29 243 576 31 243 580 minecraft:black_concrete
fill 29 243 585 31 243 585 minecraft:magenta_concrete
fill 30 243 564 32 243 564 minecraft:magenta_concrete
setblock 31 243 586 minecraft:sea_lantern
setblock 32 243 565 minecraft:sea_lantern
fill 32 243 566 32 243 568 minecraft:magenta_concrete
setblock 32 243 569 minecraft:sea_lantern
fill 32 243 570 32 243 572 minecraft:magenta_concrete
setblock 32 243 573 minecraft:sea_lantern
fill 32 243 574 32 243 576 minecraft:magenta_concrete
setblock 32 243 577 minecraft:sea_lantern
fill 32 243 578 32 243 580 minecraft:magenta_concrete
setblock 32 243 581 minecraft:sea_lantern
fill 32 243 582 32 243 584 minecraft:magenta_concrete
setblock 32 243 585 minecraft:sea_lantern
fill 32 243 586 33 243 586 minecraft:magenta_concrete
setblock 33 243 564 minecraft:sea_lantern
fill 33 243 565 33 243 567 minecraft:magenta_concrete
setblock 33 243 568 minecraft:sea_lantern
fill 33 243 569 33 243 571 minecraft:magenta_concrete
setblock 33 243 572 minecraft:sea_lantern
fill 33 243 573 33 243 575 minecraft:magenta_concrete
setblock 33 243 576 minecraft:sea_lantern
fill 33 243 577 33 243 579 minecraft:magenta_concrete
setblock 33 243 580 minecraft:sea_lantern
fill 33 243 581 33 243 583 minecraft:magenta_concrete
setblock 33 243 584 minecraft:sea_lantern
fill 33 243 585 33 247 585 minecraft:magenta_concrete
fill 34 243 564 41 243 586 minecraft:black_concrete
fill 11 244 565 13 247 565 minecraft:magenta_concrete
fill 11 244 585 13 247 585 minecraft:magenta_concrete
fill 12 244 566 12 247 566 minecraft:magenta_concrete
fill 12 244 584 12 247 584 minecraft:magenta_concrete
fill 12 244 586 12 247 586 minecraft:magenta_concrete
fill 13 244 566 13 245 566 minecraft:bone_block
fill 13 244 575 13 250 575 minecraft:bone_block
fill 13 244 584 13 245 584 minecraft:bone_block
fill 16 244 566 16 245 566 minecraft:bone_block
fill 16 244 575 16 250 575 minecraft:bone_block
fill 16 244 584 16 245 584 minecraft:bone_block
fill 19 244 566 19 245 566 minecraft:bone_block
fill 19 244 575 19 250 575 minecraft:bone_block
fill 19 244 584 19 245 584 minecraft:bone_block
fill 22 244 566 22 245 566 minecraft:bone_block
fill 22 244 584 22 245 584 minecraft:bone_block
fill 25 244 566 25 245 566 minecraft:bone_block
fill 25 244 575 25 250 575 minecraft:bone_block
fill 25 244 584 25 245 584 minecraft:bone_block
fill 28 244 566 28 245 566 minecraft:bone_block
fill 28 244 575 28 250 575 minecraft:bone_block
fill 28 244 584 28 245 584 minecraft:bone_block
fill 31 244 565 33 247 565 minecraft:magenta_concrete
fill 31 244 566 31 245 566 minecraft:bone_block
fill 31 244 575 31 250 575 minecraft:bone_block
fill 31 244 584 31 245 584 minecraft:bone_block
fill 31 244 585 32 247 585 minecraft:magenta_concrete
fill 32 244 564 32 247 564 minecraft:magenta_concrete
fill 32 244 566 32 247 566 minecraft:magenta_concrete
fill 32 244 584 32 247 584 minecraft:magenta_concrete
fill 32 244 586 32 247 586 minecraft:magenta_concrete
setblock 3 246 560 minecraft:light[level=14]
setblock 3 246 568 minecraft:light[level=14]
setblock 3 246 576 minecraft:light[level=14]
setblock 3 246 584 minecraft:light[level=14]
setblock 3 246 592 minecraft:light[level=14]
setblock 11 246 560 minecraft:light[level=14]
setblock 11 246 568 minecraft:light[level=14]
setblock 11 246 576 minecraft:light[level=14]
setblock 11 246 584 minecraft:light[level=14]
setblock 11 246 592 minecraft:light[level=14]
fill 13 246 567 13 247 567 minecraft:bone_block
fill 13 246 583 13 247 583 minecraft:bone_block
fill 16 246 567 16 247 567 minecraft:bone_block
fill 16 246 583 16 247 583 minecraft:bone_block
setblock 19 246 560 minecraft:light[level=14]
fill 19 246 567 19 247 567 minecraft:bone_block
setblock 19 246 568 minecraft:light[level=14]
setblock 19 246 576 minecraft:light[level=14]
fill 19 246 583 19 247 583 minecraft:bone_block
setblock 19 246 584 minecraft:light[level=14]
setblock 19 246 592 minecraft:light[level=14]
fill 22 246 567 22 247 567 minecraft:bone_block
fill 22 246 583 22 247 583 minecraft:bone_block
fill 25 246 567 25 247 567 minecraft:bone_block
fill 25 246 583 25 247 583 minecraft:bone_block
setblock 27 246 560 minecraft:light[level=14]
setblock 27 246 568 minecraft:light[level=14]
setblock 27 246 576 minecraft:light[level=14]
setblock 27 246 584 minecraft:light[level=14]
setblock 27 246 592 minecraft:light[level=14]
fill 28 246 567 28 247 567 minecraft:bone_block
fill 28 246 583 28 247 583 minecraft:bone_block
fill 31 246 567 31 247 567 minecraft:bone_block
fill 31 246 583 31 247 583 minecraft:bone_block
setblock 35 246 560 minecraft:light[level=14]
setblock 35 246 568 minecraft:light[level=14]
setblock 35 246 576 minecraft:light[level=14]
setblock 35 246 584 minecraft:light[level=14]
setblock 35 246 592 minecraft:light[level=14]
fill 0 247 563 0 247 566 minecraft:sea_lantern
fill 0 247 573 0 247 576 minecraft:sea_lantern
fill 0 247 583 0 247 586 minecraft:sea_lantern
fill 0 247 593 0 247 596 minecraft:sea_lantern
fill 1 247 559 1 273 559 minecraft:gray_concrete
fill 1 247 569 1 273 569 minecraft:gray_concrete
fill 1 247 579 1 273 579 minecraft:gray_concrete
fill 1 247 589 1 273 589 minecraft:gray_concrete
fill 2 247 598 2 273 598 minecraft:gray_concrete
fill 3 247 557 6 247 557 minecraft:sea_lantern
fill 4 247 599 7 247 599 minecraft:sea_lantern
fill 8 247 558 8 273 558 minecraft:gray_concrete
fill 12 247 598 12 273 598 minecraft:gray_concrete
fill 13 247 557 16 247 557 minecraft:sea_lantern
fill 14 247 599 17 247 599 minecraft:sea_lantern
fill 18 247 558 18 273 558 minecraft:gray_concrete
fill 21 247 595 21 248 597 minecraft:gray_concrete
fill 22 247 598 22 273 598 minecraft:gray_concrete
fill 23 247 557 26 247 557 minecraft:sea_lantern
fill 24 247 599 27 247 599 minecraft:sea_lantern
fill 28 247 558 28 273 558 minecraft:gray_concrete
fill 32 247 598 32 273 598 minecraft:gray_concrete
fill 33 247 557 36 247 557 minecraft:sea_lantern
fill 34 247 599 37 247 599 minecraft:sea_lantern
fill 38 247 558 38 273 558 minecraft:gray_concrete
fill 41 247 565 41 273 565 minecraft:gray_concrete
fill 41 247 575 41 273 575 minecraft:gray_concrete
fill 41 247 585 41 273 585 minecraft:gray_concrete
fill 41 247 595 41 273 595 minecraft:gray_concrete
fill 42 247 558 42 247 561 minecraft:sea_lantern
fill 42 247 568 42 247 571 minecraft:sea_lantern
fill 42 247 578 42 247 581 minecraft:sea_lantern
fill 42 247 588 42 247 591 minecraft:sea_lantern
setblock 42 247 598 minecraft:sea_lantern
fill 0 248 563 0 255 566 minecraft:black_concrete
fill 0 248 573 0 255 576 minecraft:black_concrete
fill 0 248 583 0 255 586 minecraft:black_concrete
fill 0 248 593 0 255 596 minecraft:black_concrete
fill 3 248 557 6 255 557 minecraft:black_concrete
fill 4 248 599 7 255 599 minecraft:black_concrete
fill 8 248 574 11 254 574 minecraft:bone_block
fill 8 248 576 9 255 577 minecraft:bone_block
fill 9 248 575 10 255 575 minecraft:bone_block
fill 10 248 573 10 254 573 minecraft:bone_block
fill 13 248 557 16 255 557 minecraft:black_concrete
fill 13 248 568 13 249 568 minecraft:bone_block
fill 13 248 582 13 249 582 minecraft:bone_block
fill 14 248 599 17 255 599 minecraft:black_concrete
fill 16 248 568 16 249 568 minecraft:bone_block
fill 16 248 582 16 249 582 minecraft:bone_block
fill 19 248 568 19 249 568 minecraft:bone_block
fill 19 248 582 19 249 582 minecraft:bone_block
fill 22 248 568 22 249 568 minecraft:bone_block
fill 22 248 582 22 249 582 minecraft:bone_block
fill 23 248 557 26 255 557 minecraft:black_concrete
fill 24 248 599 27 255 599 minecraft:black_concrete
fill 25 248 568 25 249 568 minecraft:bone_block
fill 25 248 582 25 249 582 minecraft:bone_block
fill 28 248 568 28 249 568 minecraft:bone_block
fill 28 248 582 28 249 582 minecraft:bone_block
fill 31 248 568 31 249 568 minecraft:bone_block
fill 31 248 582 31 249 582 minecraft:bone_block
fill 33 248 557 36 255 557 minecraft:black_concrete
fill 34 248 599 37 255 599 minecraft:black_concrete
fill 42 248 558 42 255 561 minecraft:black_concrete
fill 42 248 568 42 255 571 minecraft:black_concrete
fill 42 248 578 42 255 581 minecraft:black_concrete
fill 42 248 588 42 255 591 minecraft:black_concrete
fill 42 248 598 42 255 598 minecraft:black_concrete
fill 6 249 575 7 253 576 minecraft:bone_block
fill 7 249 574 7 254 574 minecraft:bone_block
fill 7 249 577 7 254 577 minecraft:bone_block
fill 8 249 573 9 254 573 minecraft:bone_block
fill 8 249 575 8 255 575 minecraft:bone_block
fill 9 249 572 10 253 572 minecraft:bone_block
fill 9 249 578 10 253 578 minecraft:bone_block
fill 10 249 576 11 253 577 minecraft:bone_block
fill 11 249 573 11 254 573 minecraft:bone_block
fill 11 249 575 11 255 575 minecraft:bone_block
fill 13 249 569 13 251 569 minecraft:bone_block
fill 13 249 581 13 251 581 minecraft:bone_block
fill 16 249 569 16 251 569 minecraft:bone_block
fill 16 249 581 16 251 581 minecraft:bone_block
fill 19 249 569 19 251 569 minecraft:bone_block
fill 19 249 581 19 251 581 minecraft:bone_block
fill 22 249 569 22 251 569 minecraft:bone_block
fill 22 249 581 22 251 581 minecraft:bone_block
fill 25 249 569 25 251 569 minecraft:bone_block
fill 25 249 581 25 251 581 minecraft:bone_block
fill 28 249 569 28 251 569 minecraft:bone_block
fill 28 249 581 28 251 581 minecraft:bone_block
fill 31 249 569 31 251 569 minecraft:bone_block
fill 31 249 581 31 251 581 minecraft:bone_block
fill 5 250 575 5 251 576 minecraft:bone_block
fill 6 250 574 6 254 574 minecraft:bone_block
fill 6 250 577 6 252 577 minecraft:bone_block
fill 7 250 573 7 254 573 minecraft:bone_block
fill 8 250 572 8 253 572 minecraft:bone_block
fill 8 250 578 8 254 578 minecraft:bone_block
fill 9 250 571 9 251 571 minecraft:bone_block
fill 11 250 572 11 251 572 minecraft:bone_block
fill 11 250 578 11 253 578 minecraft:bone_block
fill 12 250 574 12 253 577 minecraft:bone_block
fill 13 250 574 13 253 574 minecraft:bone_block
fill 13 250 576 13 253 576 minecraft:bone_block
fill 16 250 574 16 253 574 minecraft:bone_block
fill 16 250 576 16 253 576 minecraft:bone_block
fill 19 250 574 19 253 574 minecraft:bone_block
fill 19 250 576 19 253 576 minecraft:bone_block
fill 22 250 574 22 253 574 minecraft:bone_block
fill 25 250 574 25 253 574 minecraft:bone_block
fill 25 250 576 25 253 576 minecraft:bone_block
fill 28 250 574 28 253 574 minecraft:bone_block
fill 28 250 576 28 253 576 minecraft:bone_block
fill 31 250 574 31 253 574 minecraft:bone_block
fill 31 250 576 31 253 576 minecraft:bone_block
fill 6 251 573 6 253 573 minecraft:bone_block
fill 7 251 572 7 253 572 minecraft:bone_block
fill 8 251 571 8 252 571 minecraft:bone_block
fill 12 251 578 12 252 578 minecraft:bone_block
fill 13 251 570 13 252 570 minecraft:bone_block
fill 13 251 580 13 252 580 minecraft:bone_block
fill 16 251 570 16 252 570 minecraft:bone_block
fill 16 251 580 16 252 580 minecraft:bone_block
fill 19 251 570 19 252 570 minecraft:bone_block
fill 19 251 580 19 252 580 minecraft:bone_block
fill 22 251 570 22 252 570 minecraft:bone_block
fill 22 251 580 22 252 580 minecraft:bone_block
fill 25 251 570 25 252 570 minecraft:bone_block
fill 25 251 580 25 252 580 minecraft:bone_block
fill 28 251 570 28 252 570 minecraft:bone_block
fill 28 251 580 28 252 580 minecraft:bone_block
fill 31 251 570 31 252 570 minecraft:bone_block
fill 31 251 580 31 252 580 minecraft:bone_block
setblock 1 252 560 minecraft:black_concrete
fill 1 252 562 1 252 565 minecraft:black_concrete
setblock 1 252 570 minecraft:black_concrete
fill 1 252 572 1 252 575 minecraft:black_concrete
setblock 1 252 580 minecraft:black_concrete
fill 1 252 582 1 252 585 minecraft:black_concrete
setblock 1 252 590 minecraft:black_concrete
fill 1 252 592 1 252 595 minecraft:black_concrete
fill 2 252 558 5 252 558 minecraft:black_concrete
setblock 3 252 598 minecraft:black_concrete
setblock 5 252 575 minecraft:bone_block
fill 5 252 598 8 252 598 minecraft:black_concrete
setblock 6 252 572 minecraft:bone_block
setblock 7 252 558 minecraft:black_concrete
fill 12 252 558 15 252 558 minecraft:black_concrete
fill 12 252 573 12 253 573 minecraft:bone_block
fill 13 252 571 13 253 571 minecraft:bone_block
fill 13 252 575 13 254 575 minecraft:bone_block
fill 13 252 579 13 253 579 minecraft:bone_block
setblock 13 252 598 minecraft:black_concrete
fill 15 252 598 18 252 598 minecraft:black_concrete
fill 16 252 571 16 253 571 minecraft:bone_block
fill 16 252 579 16 253 579 minecraft:bone_block
setblock 17 252 558 minecraft:black_concrete
fill 19 252 571 19 253 571 minecraft:bone_block
fill 19 252 579 19 253 579 minecraft:bone_block
fill 22 252 558 25 252 558 minecraft:black_concrete
fill 22 252 571 22 253 571 minecraft:bone_block
fill 22 252 579 22 253 579 minecraft:bone_block
setblock 23 252 598 minecraft:black_concrete
fill 25 252 571 25 253 571 minecraft:bone_block
fill 25 252 579 25 253 579 minecraft:bone_block
fill 25 252 598 28 252 598 minecraft:black_concrete
setblock 27 252 558 minecraft:black_concrete
fill 28 252 571 28 253 571 minecraft:bone_block
fill 28 252 579 28 253 579 minecraft:bone_block
fill 31 252 571 31 253 571 minecraft:bone_block
fill 31 252 579 31 253 579 minecraft:bone_block
fill 32 252 558 35 252 558 minecraft:black_concrete
setblock 33 252 598 minecraft:black_concrete
fill 35 252 598 38 252 598 minecraft:black_concrete
setblock 37 252 558 minecraft:black_concrete
fill 41 252 559 41 252 562 minecraft:black_concrete
setblock 41 252 564 minecraft:black_concrete
fill 41 252 569 41 252 572 minecraft:black_concrete
setblock 41 252 574 minecraft:black_concrete
fill 41 252 579 41 252 582 minecraft:black_concrete
setblock 41 252 584 minecraft:black_concrete
fill 41 252 589 41 252 592 minecraft:black_concrete
setblock 41 252 594 minecraft:black_concrete
fill 13 253 572 13 253 573 minecraft:bone_block
fill 13 253 577 13 253 578 minecraft:bone_block
fill 14 253 575 21 254 575 minecraft:bone_block
fill 16 253 572 16 253 573 minecraft:bone_block
fill 16 253 577 16 253 578 minecraft:bone_block
fill 19 253 572 19 253 573 minecraft:bone_block
fill 19 253 577 19 253 578 minecraft:bone_block
fill 22 253 572 22 253 573 minecraft:bone_block
setblock 22 253 578 minecraft:bone_block
fill 24 253 575 33 254 575 minecraft:bone_block
fill 25 253 572 25 253 573 minecraft:bone_block
fill 25 253 577 25 253 578 minecraft:bone_block
fill 28 253 572 28 253 573 minecraft:bone_block
fill 28 253 577 28 253 578 minecraft:bone_block
fill 31 253 572 31 253 573 minecraft:bone_block
fill 31 253 577 31 253 578 minecraft:bone_block
setblock 3 254 560 minecraft:light[level=14]
setblock 3 254 568 minecraft:light[level=14]
setblock 3 254 576 minecraft:light[level=14]
setblock 3 254 584 minecraft:light[level=14]
setblock 3 254 592 minecraft:light[level=14]
fill 7 254 575 7 254 576 minecraft:bone_block
setblock 9 254 578 minecraft:bone_block
fill 10 254 576 10 254 577 minecraft:bone_block
setblock 11 254 560 minecraft:light[level=14]
setblock 11 254 568 minecraft:light[level=14]
setblock 11 254 576 minecraft:bone_block
setblock 11 254 584 minecraft:light[level=14]
setblock 11 254 592 minecraft:light[level=14]
fill 12 254 574 12 254 575 minecraft:bone_block
setblock 19 254 560 minecraft:light[level=14]
setblock 19 254 568 minecraft:light[level=14]
setblock 19 254 576 minecraft:light[level=14]
setblock 19 254 584 minecraft:light[level=14]
setblock 19 254 592 minecraft:light[level=14]
setblock 27 254 560 minecraft:light[level=14]
setblock 27 254 568 minecraft:light[level=14]
setblock 27 254 576 minecraft:light[level=14]
setblock 27 254 584 minecraft:light[level=14]
setblock 27 254 592 minecraft:light[level=14]
setblock 35 254 560 minecraft:light[level=14]
setblock 35 254 568 minecraft:light[level=14]
setblock 35 254 576 minecraft:light[level=14]
setblock 35 254 584 minecraft:light[level=14]
setblock 35 254 592 minecraft:light[level=14]
fill 9 255 574 11 255 574 minecraft:bone_block
fill 0 256 563 0 256 566 minecraft:sea_lantern
fill 0 256 573 0 256 576 minecraft:sea_lantern
fill 0 256 583 0 256 586 minecraft:sea_lantern
fill 0 256 593 0 256 596 minecraft:sea_lantern
fill 3 256 557 6 256 557 minecraft:sea_lantern
fill 4 256 599 7 256 599 minecraft:sea_lantern
fill 13 256 557 16 256 557 minecraft:sea_lantern
fill 14 256 599 17 256 599 minecraft:sea_lantern
fill 23 256 557 26 256 557 minecraft:sea_lantern
fill 24 256 599 27 256 599 minecraft:sea_lantern
fill 33 256 557 36 256 557 minecraft:sea_lantern
fill 34 256 599 37 256 599 minecraft:sea_lantern
fill 42 256 558 42 256 561 minecraft:sea_lantern
fill 42 256 568 42 256 571 minecraft:sea_lantern
fill 42 256 578 42 256 581 minecraft:sea_lantern
fill 42 256 588 42 256 591 minecraft:sea_lantern
setblock 42 256 598 minecraft:sea_lantern
fill 0 257 563 0 264 566 minecraft:black_concrete
fill 0 257 573 0 264 576 minecraft:black_concrete
fill 0 257 583 0 264 586 minecraft:black_concrete
fill 0 257 593 0 264 596 minecraft:black_concrete
fill 3 257 557 6 264 557 minecraft:black_concrete
fill 4 257 599 7 264 599 minecraft:black_concrete
fill 13 257 557 16 264 557 minecraft:black_concrete
fill 14 257 599 17 264 599 minecraft:black_concrete
fill 23 257 557 26 264 557 minecraft:black_concrete
fill 24 257 599 27 264 599 minecraft:black_concrete
fill 33 257 557 36 264 557 minecraft:black_concrete
fill 34 257 599 37 264 599 minecraft:black_concrete
fill 42 257 558 42 264 561 minecraft:black_concrete
fill 42 257 568 42 264 571 minecraft:black_concrete
fill 42 257 578 42 264 581 minecraft:black_concrete
fill 42 257 588 42 264 591 minecraft:black_concrete
fill 42 257 598 42 264 598 minecraft:black_concrete
setblock 1 258 560 minecraft:black_concrete
setblock 1 258 570 minecraft:black_concrete
setblock 1 258 580 minecraft:black_concrete
setblock 1 258 590 minecraft:black_concrete
setblock 3 258 598 minecraft:black_concrete
setblock 7 258 558 minecraft:black_concrete
setblock 13 258 598 minecraft:black_concrete
setblock 17 258 558 minecraft:black_concrete
setblock 23 258 598 minecraft:black_concrete
setblock 27 258 558 minecraft:black_concrete
setblock 33 258 598 minecraft:black_concrete
setblock 37 258 558 minecraft:black_concrete
setblock 41 258 564 minecraft:black_concrete
setblock 41 258 574 minecraft:black_concrete
setblock 41 258 584 minecraft:black_concrete
setblock 41 258 594 minecraft:black_concrete
fill 1 261 562 1 261 565 minecraft:black_concrete
fill 1 261 572 1 261 575 minecraft:black_concrete
fill 1 261 582 1 261 585 minecraft:black_concrete
fill 1 261 592 1 261 595 minecraft:black_concrete
fill 2 261 558 5 261 558 minecraft:black_concrete
fill 5 261 598 8 261 598 minecraft:black_concrete
fill 12 261 558 15 261 558 minecraft:black_concrete
fill 15 261 598 18 261 598 minecraft:black_concrete
fill 22 261 558 25 261 558 minecraft:black_concrete
fill 25 261 598 28 261 598 minecraft:black_concrete
fill 32 261 558 35 261 558 minecraft:black_concrete
fill 35 261 598 38 261 598 minecraft:black_concrete
fill 41 261 559 41 261 562 minecraft:black_concrete
fill 41 261 569 41 261 572 minecraft:black_concrete
fill 41 261 579 41 261 582 minecraft:black_concrete
fill 41 261 589 41 261 592 minecraft:black_concrete
setblock 3 262 560 minecraft:light[level=14]
setblock 3 262 568 minecraft:light[level=14]
setblock 3 262 576 minecraft:light[level=14]
setblock 3 262 584 minecraft:light[level=14]
setblock 3 262 592 minecraft:light[level=14]
setblock 11 262 560 minecraft:light[level=14]
setblock 11 262 568 minecraft:light[level=14]
setblock 11 262 576 minecraft:light[level=14]
setblock 11 262 584 minecraft:light[level=14]
setblock 11 262 592 minecraft:light[level=14]
setblock 19 262 560 minecraft:light[level=14]
setblock 19 262 568 minecraft:light[level=14]
setblock 19 262 576 minecraft:light[level=14]
setblock 19 262 584 minecraft:light[level=14]
setblock 19 262 592 minecraft:light[level=14]
setblock 27 262 560 minecraft:light[level=14]
setblock 27 262 568 minecraft:light[level=14]
setblock 27 262 576 minecraft:light[level=14]
setblock 27 262 584 minecraft:light[level=14]
setblock 27 262 592 minecraft:light[level=14]
setblock 35 262 560 minecraft:light[level=14]
setblock 35 262 568 minecraft:light[level=14]
setblock 35 262 576 minecraft:light[level=14]
setblock 35 262 584 minecraft:light[level=14]
setblock 35 262 592 minecraft:light[level=14]
setblock 1 264 560 minecraft:black_concrete
setblock 1 264 570 minecraft:black_concrete
setblock 1 264 580 minecraft:black_concrete
setblock 1 264 590 minecraft:black_concrete
setblock 3 264 598 minecraft:black_concrete
setblock 7 264 558 minecraft:black_concrete
setblock 13 264 598 minecraft:black_concrete
setblock 17 264 558 minecraft:black_concrete
setblock 23 264 598 minecraft:black_concrete
setblock 27 264 558 minecraft:black_concrete
setblock 33 264 598 minecraft:black_concrete
setblock 37 264 558 minecraft:black_concrete
setblock 41 264 564 minecraft:black_concrete
setblock 41 264 574 minecraft:black_concrete
setblock 41 264 584 minecraft:black_concrete
setblock 41 264 594 minecraft:black_concrete
fill 0 265 563 0 265 566 minecraft:sea_lantern
fill 0 265 573 0 265 576 minecraft:sea_lantern
fill 0 265 583 0 265 586 minecraft:sea_lantern
fill 0 265 593 0 265 596 minecraft:sea_lantern
fill 3 265 557 6 265 557 minecraft:sea_lantern
fill 4 265 599 7 265 599 minecraft:sea_lantern
fill 13 265 557 16 265 557 minecraft:sea_lantern
fill 14 265 599 17 265 599 minecraft:sea_lantern
fill 23 265 557 26 265 557 minecraft:sea_lantern
fill 24 265 599 27 265 599 minecraft:sea_lantern
fill 33 265 557 36 265 557 minecraft:sea_lantern
fill 34 265 599 37 265 599 minecraft:sea_lantern
fill 42 265 558 42 265 561 minecraft:sea_lantern
fill 42 265 568 42 265 571 minecraft:sea_lantern
fill 42 265 578 42 265 581 minecraft:sea_lantern
fill 42 265 588 42 265 591 minecraft:sea_lantern
setblock 42 265 598 minecraft:sea_lantern
fill 0 266 563 0 291 566 minecraft:black_concrete
fill 0 266 573 0 291 576 minecraft:black_concrete
fill 0 266 583 0 291 586 minecraft:black_concrete
fill 0 266 593 0 291 596 minecraft:black_concrete
fill 3 266 557 6 291 557 minecraft:black_concrete
fill 4 266 599 7 291 599 minecraft:black_concrete
fill 13 266 557 16 291 557 minecraft:black_concrete
fill 14 266 599 17 291 599 minecraft:black_concrete
fill 23 266 557 26 291 557 minecraft:black_concrete
fill 24 266 599 27 291 599 minecraft:black_concrete
fill 33 266 557 36 291 557 minecraft:black_concrete
fill 34 266 599 37 291 599 minecraft:black_concrete
fill 42 266 558 42 291 561 minecraft:black_concrete
fill 42 266 568 42 291 571 minecraft:black_concrete
fill 42 266 578 42 291 581 minecraft:black_concrete
fill 42 266 588 42 291 591 minecraft:black_concrete
fill 42 266 598 42 291 598 minecraft:black_concrete
setblock 1 270 560 minecraft:black_concrete
fill 1 270 562 1 270 565 minecraft:black_concrete
setblock 1 270 570 minecraft:black_concrete
fill 1 270 572 1 270 575 minecraft:black_concrete
setblock 1 270 580 minecraft:black_concrete
fill 1 270 582 1 270 585 minecraft:black_concrete
setblock 1 270 590 minecraft:black_concrete
fill 1 270 592 1 270 595 minecraft:black_concrete
fill 2 270 558 5 270 558 minecraft:black_concrete
setblock 3 270 560 minecraft:light[level=14]
setblock 3 270 568 minecraft:light[level=14]
setblock 3 270 576 minecraft:light[level=14]
setblock 3 270 584 minecraft:light[level=14]
setblock 3 270 592 minecraft:light[level=14]
setblock 3 270 598 minecraft:black_concrete
fill 5 270 598 8 270 598 minecraft:black_concrete
setblock 7 270 558 minecraft:black_concrete
setblock 11 270 560 minecraft:light[level=14]
setblock 11 270 568 minecraft:light[level=14]
setblock 11 270 576 minecraft:light[level=14]
setblock 11 270 584 minecraft:light[level=14]
setblock 11 270 592 minecraft:light[level=14]
fill 12 270 558 15 270 558 minecraft:black_concrete
setblock 13 270 598 minecraft:black_concrete
fill 15 270 598 18 270 598 minecraft:black_concrete
setblock 17 270 558 minecraft:black_concrete
setblock 19 270 560 minecraft:light[level=14]
setblock 19 270 568 minecraft:light[level=14]
setblock 19 270 576 minecraft:light[level=14]
setblock 19 270 584 minecraft:light[level=14]
setblock 19 270 592 minecraft:light[level=14]
fill 22 270 558 25 270 558 minecraft:black_concrete
setblock 23 270 598 minecraft:black_concrete
fill 25 270 598 28 270 598 minecraft:black_concrete
setblock 27 270 558 minecraft:black_concrete
setblock 27 270 560 minecraft:light[level=14]
setblock 27 270 568 minecraft:light[level=14]
setblock 27 270 576 minecraft:light[level=14]
setblock 27 270 584 minecraft:light[level=14]
setblock 27 270 592 minecraft:light[level=14]
fill 32 270 558 35 270 558 minecraft:black_concrete
setblock 33 270 598 minecraft:black_concrete
setblock 35 270 560 minecraft:light[level=14]
setblock 35 270 568 minecraft:light[level=14]
setblock 35 270 576 minecraft:light[level=14]
setblock 35 270 584 minecraft:light[level=14]
setblock 35 270 592 minecraft:light[level=14]
fill 35 270 598 38 270 598 minecraft:black_concrete
setblock 37 270 558 minecraft:black_concrete
fill 41 270 559 41 270 562 minecraft:black_concrete
setblock 41 270 564 minecraft:black_concrete
fill 41 270 569 41 270 572 minecraft:black_concrete
setblock 41 270 574 minecraft:black_concrete
fill 41 270 579 41 270 582 minecraft:black_concrete
setblock 41 270 584 minecraft:black_concrete
fill 41 270 589 41 270 592 minecraft:black_concrete
setblock 41 270 594 minecraft:black_concrete
setblock 3 278 560 minecraft:light[level=14]
setblock 3 278 568 minecraft:light[level=14]
setblock 3 278 576 minecraft:light[level=14]
setblock 3 278 584 minecraft:light[level=14]
setblock 3 278 592 minecraft:light[level=14]
setblock 11 278 560 minecraft:light[level=14]
setblock 11 278 568 minecraft:light[level=14]
setblock 11 278 576 minecraft:light[level=14]
setblock 11 278 584 minecraft:light[level=14]
setblock 11 278 592 minecraft:light[level=14]
setblock 19 278 560 minecraft:light[level=14]
setblock 19 278 568 minecraft:light[level=14]
setblock 19 278 576 minecraft:light[level=14]
setblock 19 278 584 minecraft:light[level=14]
setblock 19 278 592 minecraft:light[level=14]
setblock 27 278 560 minecraft:light[level=14]
setblock 27 278 568 minecraft:light[level=14]
setblock 27 278 576 minecraft:light[level=14]
setblock 27 278 584 minecraft:light[level=14]
setblock 27 278 592 minecraft:light[level=14]
setblock 35 278 560 minecraft:light[level=14]
setblock 35 278 568 minecraft:light[level=14]
setblock 35 278 576 minecraft:light[level=14]
setblock 35 278 584 minecraft:light[level=14]
setblock 35 278 592 minecraft:light[level=14]
fill 8 279 562 9 279 592 minecraft:cyan_concrete
fill 10 279 562 38 279 563 minecraft:cyan_concrete
fill 10 279 564 20 279 590 minecraft:black_concrete
fill 10 279 591 38 279 592 minecraft:cyan_concrete
fill 21 279 564 21 279 576 minecraft:black_concrete
fill 21 279 578 21 279 590 minecraft:black_concrete
fill 22 279 564 22 279 575 minecraft:black_concrete
fill 22 279 579 22 279 590 minecraft:black_concrete
fill 23 279 564 36 279 574 minecraft:black_concrete
fill 23 279 580 36 279 590 minecraft:black_concrete
fill 24 279 575 36 279 575 minecraft:black_concrete
fill 24 279 579 36 279 579 minecraft:black_concrete
fill 25 279 576 36 279 576 minecraft:black_concrete
fill 25 279 578 36 279 578 minecraft:black_concrete
fill 26 279 577 36 279 577 minecraft:black_concrete
fill 37 279 564 38 279 590 minecraft:cyan_concrete
fill 1 280 558 7 280 598 minecraft:black_concrete
fill 8 280 558 41 280 561 minecraft:black_concrete
fill 8 280 562 8 280 564 minecraft:cyan_concrete
setblock 8 280 565 minecraft:sea_lantern
fill 8 280 566 8 280 568 minecraft:cyan_concrete
setblock 8 280 569 minecraft:sea_lantern
fill 8 280 570 8 280 572 minecraft:cyan_concrete
setblock 8 280 573 minecraft:sea_lantern
fill 8 280 574 8 280 576 minecraft:cyan_concrete
setblock 8 280 577 minecraft:sea_lantern
fill 8 280 578 8 280 580 minecraft:cyan_concrete
setblock 8 280 581 minecraft:sea_lantern
fill 8 280 582 8 280 584 minecraft:cyan_concrete
setblock 8 280 585 minecraft:sea_lantern
fill 8 280 586 8 280 588 minecraft:cyan_concrete
setblock 8 280 589 minecraft:sea_lantern
fill 8 280 590 8 280 592 minecraft:cyan_concrete
fill 8 280 593 41 280 598 minecraft:black_concrete
fill 9 280 562 9 284 563 minecraft:cyan_concrete
setblock 9 280 564 minecraft:sea_lantern
fill 9 280 565 9 280 567 minecraft:cyan_concrete
setblock 9 280 568 minecraft:sea_lantern
fill 9 280 569 9 280 571 minecraft:cyan_concrete
setblock 9 280 572 minecraft:sea_lantern
fill 9 280 573 9 280 575 minecraft:cyan_concrete
setblock 9 280 576 minecraft:sea_lantern
fill 9 280 577 9 280 579 minecraft:cyan_concrete
setblock 9 280 580 minecraft:sea_lantern
fill 9 280 581 9 280 583 minecraft:cyan_concrete
setblock 9 280 584 minecraft:sea_lantern
fill 9 280 585 9 280 587 minecraft:cyan_concrete
setblock 9 280 588 minecraft:sea_lantern
fill 9 280 589 9 280 591 minecraft:cyan_concrete
setblock 9 280 592 minecraft:sea_lantern
setblock 10 280 562 minecraft:cyan_concrete
setblock 10 280 563 minecraft:sea_lantern
fill 10 280 564 19 280 590 minecraft:black_concrete
setblock 10 280 591 minecraft:sea_lantern
fill 10 280 592 12 280 592 minecraft:cyan_concrete
setblock 11 280 562 minecraft:sea_lantern
fill 11 280 563 13 280 563 minecraft:cyan_concrete
fill 11 280 591 13 280 591 minecraft:cyan_concrete
fill 12 280 562 14 280 562 minecraft:cyan_concrete
setblock 13 280 592 minecraft:sea_lantern
setblock 14 280 563 minecraft:sea_lantern
setblock 14 280 591 minecraft:sea_lantern
fill 14 280 592 16 280 592 minecraft:cyan_concrete
setblock 15 280 562 minecraft:sea_lantern
fill 15 280 563 17 280 563 minecraft:cyan_concrete
fill 15 280 591 17 280 591 minecraft:cyan_concrete
fill 16 280 562 18 280 562 minecraft:cyan_concrete
setblock 17 280 592 minecraft:sea_lantern
setblock 18 280 563 minecraft:sea_lantern
setblock 18 280 591 minecraft:sea_lantern
fill 18 280 592 20 280 592 minecraft:cyan_concrete
setblock 19 280 562 minecraft:sea_lantern
fill 19 280 563 21 280 563 minecraft:cyan_concrete
fill 19 280 591 21 280 591 minecraft:cyan_concrete
fill 20 280 562 22 280 562 minecraft:cyan_concrete
fill 20 280 564 20 280 575 minecraft:black_concrete
fill 20 280 576 20 280 578 minecraft:sea_lantern
fill 20 280 579 20 280 590 minecraft:black_concrete
fill 21 280 564 21 280 574 minecraft:black_concrete
fill 21 280 575 21 280 576 minecraft:sea_lantern
fill 21 280 578 21 280 579 minecraft:sea_lantern
fill 21 280 580 21 280 590 minecraft:black_concrete
setblock 21 280 592 minecraft:sea_lantern
setblock 22 280 563 minecraft:sea_lantern
fill 22 280 564 36 280 573 minecraft:black_concrete
fill 22 280 574 22 280 575 minecraft:sea_lantern
fill 22 280 579 22 280 580 minecraft:sea_lantern
fill 22 280 581 36 280 590 minecraft:black_concrete
setblock 22 280 591 minecraft:sea_lantern
fill 22 280 592 24 280 592 minecraft:cyan_concrete
setblock 23 280 562 minecraft:sea_lantern
fill 23 280 563 25 280 563 minecraft:cyan_concrete
fill 23 280 574 24 280 574 minecraft:sea_lantern
fill 23 280 580 24 280 580 minecraft:sea_lantern
fill 23 280 591 25 280 591 minecraft:cyan_concrete
fill 24 280 562 26 280 562 minecraft:cyan_concrete
fill 24 280 575 25 280 575 minecraft:sea_lantern
fill 24 280 579 25 280 579 minecraft:sea_lantern
fill 25 280 574 36 280 574 minecraft:black_concrete
fill 25 280 576 26 280 576 minecraft:sea_lantern
fill 25 280 578 26 280 578 minecraft:sea_lantern
fill 25 280 580 36 280 580 minecraft:black_concrete
setblock 25 280 592 minecraft:sea_lantern
setblock 26 280 563 minecraft:sea_lantern
fill 26 280 575 36 280 575 minecraft:black_concrete
setblock 26 280 577 minecraft:sea_lantern
fill 26 280 579 36 280 579 minecraft:black_concrete
setblock 26 280 591 minecraft:sea_lantern
fill 26 280 592 28 280 592 minecraft:cyan_concrete
setblock 27 280 562 minecraft:sea_lantern
fill 27 280 563 29 280 563 minecraft:cyan_concrete
fill 27 280 576 36 280 578 minecraft:black_concrete
fill 27 280 591 29 280 591 minecraft:cyan_concrete
fill 28 280 562 30 280 562 minecraft:cyan_concrete
setblock 29 280 592 minecraft:sea_lantern
setblock 30 280 563 minecraft:sea_lantern
setblock 30 280 591 minecraft:sea_lantern
fill 30 280 592 32 280 592 minecraft:cyan_concrete
setblock 31 280 562 minecraft:sea_lantern
fill 31 280 563 33 280 563 minecraft:cyan_concrete
fill 31 280 591 33 280 591 minecraft:cyan_concrete
fill 32 280 562 34 280 562 minecraft:cyan_concrete
setblock 33 280 592 minecraft:sea_lantern
setblock 34 280 563 minecraft:sea_lantern
setblock 34 280 591 minecraft:sea_lantern
fill 34 280 592 36 280 592 minecraft:cyan_concrete
setblock 35 280 562 minecraft:sea_lantern
fill 35 280 563 37 280 563 minecraft:cyan_concrete
fill 35 280 591 37 280 591 minecraft:cyan_concrete
fill 36 280 562 38 280 562 minecraft:cyan_concrete
setblock 37 280 564 minecraft:sea_lantern
fill 37 280 565 37 280 567 minecraft:cyan_concrete
setblock 37 280 568 minecraft:sea_lantern
fill 37 280 569 37 280 571 minecraft:cyan_concrete
setblock 37 280 572 minecraft:sea_lantern
fill 37 280 573 37 280 575 minecraft:cyan_concrete
setblock 37 280 576 minecraft:sea_lantern
fill 37 280 577 37 280 579 minecraft:cyan_concrete
setblock 37 280 580 minecraft:sea_lantern
fill 37 280 581 37 280 583 minecraft:cyan_concrete
setblock 37 280 584 minecraft:sea_lantern
fill 37 280 585 37 280 587 minecraft:cyan_concrete
setblock 37 280 588 minecraft:sea_lantern
fill 37 280 589 38 280 590 minecraft:cyan_concrete
setblock 37 280 592 minecraft:sea_lantern
setblock 38 280 563 minecraft:sea_lantern
fill 38 280 564 38 280 566 minecraft:cyan_concrete
setblock 38 280 567 minecraft:sea_lantern
fill 38 280 568 38 280 570 minecraft:cyan_concrete
setblock 38 280 571 minecraft:sea_lantern
fill 38 280 572 38 280 574 minecraft:cyan_concrete
setblock 38 280 575 minecraft:sea_lantern
fill 38 280 576 38 280 578 minecraft:cyan_concrete
setblock 38 280 579 minecraft:sea_lantern
fill 38 280 580 38 280 582 minecraft:cyan_concrete
setblock 38 280 583 minecraft:sea_lantern
fill 38 280 584 38 280 586 minecraft:cyan_concrete
setblock 38 280 587 minecraft:sea_lantern
setblock 38 280 588 minecraft:cyan_concrete
setblock 38 280 591 minecraft:sea_lantern
setblock 38 280 592 minecraft:cyan_concrete
fill 39 280 562 41 280 592 minecraft:black_concrete
fill 8 281 563 8 284 563 minecraft:cyan_concrete
fill 8 281 591 10 284 591 minecraft:cyan_concrete
fill 9 281 564 9 284 564 minecraft:cyan_concrete
fill 9 281 590 9 284 590 minecraft:cyan_concrete
fill 9 281 592 9 284 592 minecraft:cyan_concrete
fill 10 281 563 10 284 563 minecraft:cyan_concrete
fill 36 281 563 38 284 563 minecraft:cyan_concrete
fill 36 281 591 38 284 591 minecraft:cyan_concrete
fill 37 281 562 37 284 562 minecraft:cyan_concrete
fill 37 281 564 37 284 564 minecraft:cyan_concrete
fill 37 281 590 37 284 590 minecraft:cyan_concrete
fill 37 281 592 37 284 592 minecraft:cyan_concrete
fill 1 284 559 1 300 559 minecraft:gray_concrete
fill 1 284 569 1 300 569 minecraft:gray_concrete
fill 1 284 579 1 300 579 minecraft:gray_concrete
fill 1 284 589 1 300 589 minecraft:gray_concrete
fill 2 284 576 3 284 580 minecraft:black_concrete
fill 2 284 598 2 300 598 minecraft:gray_concrete
fill 3 284 572 3 284 575 minecraft:black_concrete
fill 3 284 581 3 284 584 minecraft:black_concrete
fill 4 284 570 4 284 572 minecraft:black_concrete
fill 4 284 584 4 284 586 minecraft:black_concrete
fill 5 284 568 5 284 570 minecraft:black_concrete
fill 5 284 586 5 284 588 minecraft:black_concrete
fill 6 284 567 6 284 568 minecraft:black_concrete
fill 6 284 588 6 284 589 minecraft:black_concrete
fill 7 284 565 7 284 566 minecraft:black_concrete
fill 7 284 590 7 284 591 minecraft:black_concrete
fill 8 284 558 8 300 558 minecraft:gray_concrete
fill 8 284 564 8 284 565 minecraft:black_concrete
setblock 8 284 592 minecraft:black_concrete
fill 10 284 593 11 284 593 minecraft:black_concrete
fill 11 284 562 11 284 563 minecraft:black_concrete
fill 11 284 594 13 284 594 minecraft:black_concrete
fill 12 284 562 13 284 562 minecraft:black_concrete
fill 12 284 598 12 300 598 minecraft:gray_concrete
fill 13 284 561 15 284 561 minecraft:black_concrete
fill 13 284 595 15 284 595 minecraft:black_concrete
fill 15 284 560 27 284 560 minecraft:black_concrete
fill 15 284 596 27 284 596 minecraft:black_concrete
fill 18 284 558 18 300 558 minecraft:gray_concrete
fill 19 284 559 23 284 559 minecraft:black_concrete
fill 19 284 597 23 284 597 minecraft:black_concrete
fill 22 284 598 22 300 598 minecraft:gray_concrete
fill 27 284 561 29 284 561 minecraft:black_concrete
fill 27 284 595 29 284 595 minecraft:black_concrete
fill 28 284 558 28 300 558 minecraft:gray_concrete
fill 29 284 562 31 284 562 minecraft:black_concrete
fill 29 284 594 31 284 594 minecraft:black_concrete
fill 31 284 563 32 284 563 minecraft:black_concrete
fill 31 284 593 32 284 593 minecraft:black_concrete
fill 32 284 598 32 300 598 minecraft:gray_concrete
fill 33 284 564 34 284 564 minecraft:black_concrete
fill 33 284 592 34 284 592 minecraft:black_concrete
fill 34 284 565 35 284 565 minecraft:black_concrete
fill 34 284 591 35 284 591 minecraft:black_concrete
setblock 35 284 566 minecraft:black_concrete
setblock 35 284 590 minecraft:black_concrete
fill 36 284 567 36 284 568 minecraft:black_concrete
fill 36 284 588 36 284 589 minecraft:black_concrete
fill 37 284 568 37 284 570 minecraft:black_concrete
fill 37 284 586 37 284 588 minecraft:black_concrete
fill 38 284 558 38 300 558 minecraft:gray_concrete
fill 38 284 570 38 284 572 minecraft:black_concrete
fill 38 284 584 38 284 586 minecraft:black_concrete
fill 39 284 572 39 284 584 minecraft:black_concrete
fill 40 284 576 40 284 580 minecraft:black_concrete
fill 41 284 565 41 300 565 minecraft:gray_concrete
fill 41 284 575 41 300 575 minecraft:gray_concrete
fill 41 284 585 41 300 585 minecraft:gray_concrete
fill 41 284 595 41 300 595 minecraft:gray_concrete
fill 22 285 559 25 285 559 minecraft:sea_lantern
fill 26 285 560 28 285 560 minecraft:sea_lantern
fill 29 285 561 30 285 561 minecraft:sea_lantern
fill 31 285 562 32 285 562 minecraft:sea_lantern
setblock 33 285 563 minecraft:sea_lantern
setblock 34 285 564 minecraft:sea_lantern
setblock 35 285 565 minecraft:sea_lantern
setblock 36 285 566 minecraft:sea_lantern
fill 37 285 567 37 285 568 minecraft:sea_lantern
fill 38 285 569 38 285 570 minecraft:sea_lantern
fill 39 285 571 39 285 573 minecraft:sea_lantern
fill 40 285 574 40 285 580 minecraft:sea_lantern
fill 1 286 584 3 287 584 minecraft:gray_concrete
setblock 3 286 560 minecraft:light[level=14]
setblock 3 286 568 minecraft:light[level=14]
setblock 3 286 576 minecraft:light[level=14]
setblock 3 286 592 minecraft:light[level=14]
setblock 11 286 560 minecraft:light[level=14]
setblock 11 286 568 minecraft:light[level=14]
setblock 11 286 576 minecraft:light[level=14]
setblock 11 286 584 minecraft:light[level=14]
setblock 11 286 592 minecraft:light[level=14]
setblock 19 286 560 minecraft:light[level=14]
setblock 19 286 568 minecraft:light[level=14]
setblock 19 286 576 minecraft:light[level=14]
setblock 19 286 584 minecraft:light[level=14]
setblock 19 286 592 minecraft:light[level=14]
setblock 27 286 560 minecraft:light[level=14]
setblock 27 286 568 minecraft:light[level=14]
setblock 27 286 576 minecraft:light[level=14]
setblock 27 286 584 minecraft:light[level=14]
setblock 27 286 592 minecraft:light[level=14]
setblock 35 286 560 minecraft:light[level=14]
setblock 35 286 568 minecraft:light[level=14]
setblock 35 286 576 minecraft:light[level=14]
setblock 35 286 584 minecraft:light[level=14]
setblock 35 286 592 minecraft:light[level=14]
setblock 1 288 560 minecraft:black_concrete
fill 1 288 562 1 288 565 minecraft:black_concrete
setblock 1 288 570 minecraft:black_concrete
fill 1 288 572 1 288 575 minecraft:black_concrete
setblock 1 288 580 minecraft:black_concrete
fill 1 288 582 1 288 585 minecraft:black_concrete
setblock 1 288 590 minecraft:black_concrete
fill 1 288 592 1 288 595 minecraft:black_concrete
fill 2 288 558 5 288 558 minecraft:black_concrete
setblock 3 288 598 minecraft:black_concrete
fill 5 288 598 8 288 598 minecraft:black_concrete
setblock 7 288 558 minecraft:black_concrete
fill 12 288 558 15 288 558 minecraft:black_concrete
setblock 13 288 598 minecraft:black_concrete
fill 15 288 598 18 288 598 minecraft:black_concrete
setblock 17 288 558 minecraft:black_concrete
fill 22 288 558 25 288 558 minecraft:black_concrete
setblock 23 288 598 minecraft:black_concrete
fill 25 288 598 28 288 598 minecraft:black_concrete
setblock 27 288 558 minecraft:black_concrete
fill 32 288 558 35 288 558 minecraft:black_concrete
setblock 33 288 598 minecraft:black_concrete
fill 35 288 598 38 288 598 minecraft:black_concrete
setblock 37 288 558 minecraft:black_concrete
fill 41 288 559 41 288 562 minecraft:black_concrete
setblock 41 288 564 minecraft:black_concrete
fill 41 288 569 41 288 572 minecraft:black_concrete
setblock 41 288 574 minecraft:black_concrete
fill 41 288 579 41 288 582 minecraft:black_concrete
setblock 41 288 584 minecraft:black_concrete
fill 41 288 589 41 288 592 minecraft:black_concrete
setblock 41 288 594 minecraft:black_concrete
fill 0 292 563 0 292 566 minecraft:sea_lantern
fill 0 292 573 0 292 576 minecraft:sea_lantern
fill 0 292 583 0 292 586 minecraft:sea_lantern
fill 0 292 593 0 292 596 minecraft:sea_lantern
fill 3 292 557 6 292 557 minecraft:sea_lantern
fill 4 292 599 7 292 599 minecraft:sea_lantern
fill 13 292 557 16 292 557 minecraft:sea_lantern
fill 14 292 599 17 292 599 minecraft:sea_lantern
fill 23 292 557 26 292 557 minecraft:sea_lantern
fill 24 292 599 27 292 599 minecraft:sea_lantern
fill 33 292 557 36 292 557 minecraft:sea_lantern
fill 34 292 599 37 292 599 minecraft:sea_lantern
fill 42 292 558 42 292 561 minecraft:sea_lantern
fill 42 292 568 42 292 571 minecraft:sea_lantern
fill 42 292 578 42 292 581 minecraft:sea_lantern
fill 42 292 588 42 292 591 minecraft:sea_lantern
setblock 42 292 598 minecraft:sea_lantern
fill 0 293 563 0 307 566 minecraft:black_concrete
fill 0 293 573 0 307 576 minecraft:black_concrete
fill 0 293 583 0 307 586 minecraft:black_concrete
fill 0 293 593 0 307 596 minecraft:black_concrete
fill 3 293 557 6 307 557 minecraft:black_concrete
fill 4 293 599 7 307 599 minecraft:black_concrete
fill 13 293 557 16 307 557 minecraft:black_concrete
fill 14 293 599 17 307 599 minecraft:black_concrete
fill 23 293 557 26 307 557 minecraft:black_concrete
fill 24 293 599 27 307 599 minecraft:black_concrete
fill 33 293 557 36 307 557 minecraft:black_concrete
fill 34 293 599 37 307 599 minecraft:black_concrete
fill 38 293 588 40 294 588 minecraft:gray_concrete
fill 42 293 558 42 307 561 minecraft:black_concrete
fill 42 293 568 42 307 571 minecraft:black_concrete
fill 42 293 578 42 307 581 minecraft:black_concrete
fill 42 293 588 42 307 591 minecraft:black_concrete
fill 42 293 598 42 307 598 minecraft:black_concrete
setblock 1 294 560 minecraft:black_concrete
setblock 1 294 570 minecraft:black_concrete
setblock 1 294 580 minecraft:black_concrete
setblock 1 294 590 minecraft:black_concrete
setblock 3 294 560 minecraft:light[level=14]
setblock 3 294 568 minecraft:light[level=14]
setblock 3 294 576 minecraft:light[level=14]
setblock 3 294 584 minecraft:light[level=14]
setblock 3 294 592 minecraft:light[level=14]
setblock 3 294 598 minecraft:black_concrete
setblock 7 294 558 minecraft:black_concrete
setblock 11 294 560 minecraft:light[level=14]
setblock 11 294 568 minecraft:light[level=14]
setblock 11 294 576 minecraft:light[level=14]
setblock 11 294 584 minecraft:light[level=14]
setblock 11 294 592 minecraft:light[level=14]
setblock 13 294 598 minecraft:black_concrete
setblock 17 294 558 minecraft:black_concrete
setblock 19 294 560 minecraft:light[level=14]
setblock 19 294 568 minecraft:light[level=14]
setblock 19 294 576 minecraft:light[level=14]
setblock 19 294 584 minecraft:light[level=14]
setblock 19 294 592 minecraft:light[level=14]
setblock 23 294 598 minecraft:black_concrete
setblock 27 294 558 minecraft:black_concrete
setblock 27 294 560 minecraft:light[level=14]
setblock 27 294 568 minecraft:light[level=14]
setblock 27 294 576 minecraft:light[level=14]
setblock 27 294 584 minecraft:light[level=14]
setblock 27 294 592 minecraft:light[level=14]
setblock 33 294 598 minecraft:black_concrete
setblock 35 294 560 minecraft:light[level=14]
setblock 35 294 568 minecraft:light[level=14]
setblock 35 294 576 minecraft:light[level=14]
setblock 35 294 584 minecraft:light[level=14]
setblock 35 294 592 minecraft:light[level=14]
setblock 37 294 558 minecraft:black_concrete
setblock 41 294 564 minecraft:black_concrete
setblock 41 294 574 minecraft:black_concrete
setblock 41 294 584 minecraft:black_concrete
setblock 41 294 594 minecraft:black_concrete
fill 1 297 562 1 297 565 minecraft:black_concrete
fill 1 297 572 1 297 575 minecraft:black_concrete
fill 1 297 582 1 297 585 minecraft:black_concrete
fill 1 297 592 1 297 595 minecraft:black_concrete
fill 2 297 558 5 297 558 minecraft:black_concrete
fill 5 297 598 8 297 598 minecraft:black_concrete
fill 12 297 558 15 297 558 minecraft:black_concrete
fill 15 297 598 18 297 598 minecraft:black_concrete
fill 22 297 558 25 297 558 minecraft:black_concrete
fill 25 297 598 28 297 598 minecraft:black_concrete
fill 32 297 558 35 297 558 minecraft:black_concrete
fill 35 297 598 38 297 598 minecraft:black_concrete
fill 41 297 559 41 297 562 minecraft:black_concrete
fill 41 297 569 41 297 572 minecraft:black_concrete
fill 41 297 579 41 297 582 minecraft:black_concrete
fill 41 297 589 41 297 592 minecraft:black_concrete
setblock 1 300 560 minecraft:black_concrete
setblock 1 300 570 minecraft:black_concrete
setblock 1 300 580 minecraft:black_concrete
setblock 1 300 590 minecraft:black_concrete
setblock 3 300 598 minecraft:black_concrete
setblock 7 300 558 minecraft:black_concrete
setblock 13 300 598 minecraft:black_concrete
setblock 17 300 558 minecraft:black_concrete
setblock 23 300 598 minecraft:black_concrete
setblock 27 300 558 minecraft:black_concrete
setblock 33 300 598 minecraft:black_concrete
setblock 37 300 558 minecraft:black_concrete
setblock 41 300 564 minecraft:black_concrete
setblock 41 300 574 minecraft:black_concrete
setblock 41 300 584 minecraft:black_concrete
setblock 41 300 594 minecraft:black_concrete
setblock 3 302 560 minecraft:light[level=14]
setblock 3 302 568 minecraft:light[level=14]
setblock 3 302 576 minecraft:light[level=14]
setblock 3 302 584 minecraft:light[level=14]
setblock 3 302 592 minecraft:light[level=14]
setblock 11 302 560 minecraft:light[level=14]
setblock 11 302 568 minecraft:light[level=14]
setblock 11 302 576 minecraft:light[level=14]
setblock 11 302 584 minecraft:light[level=14]
setblock 11 302 592 minecraft:light[level=14]
setblock 19 302 560 minecraft:light[level=14]
setblock 19 302 568 minecraft:light[level=14]
setblock 19 302 576 minecraft:light[level=14]
setblock 19 302 584 minecraft:light[level=14]
setblock 19 302 592 minecraft:light[level=14]
setblock 27 302 560 minecraft:light[level=14]
setblock 27 302 568 minecraft:light[level=14]
setblock 27 302 576 minecraft:light[level=14]
setblock 27 302 584 minecraft:light[level=14]
setblock 27 302 592 minecraft:light[level=14]
setblock 35 302 560 minecraft:light[level=14]
setblock 35 302 568 minecraft:light[level=14]
setblock 35 302 576 minecraft:light[level=14]
setblock 35 302 584 minecraft:light[level=14]
setblock 35 302 592 minecraft:light[level=14]
