setblock 430 192 304 minecraft:black_concrete
fill 430 192 305 430 192 307 minecraft:gray_concrete
setblock 430 192 308 minecraft:black_concrete
fill 430 192 309 432 192 309 minecraft:gray_concrete
setblock 430 192 312 minecraft:black_concrete
fill 430 192 313 432 192 313 minecraft:gray_concrete
setblock 430 192 316 minecraft:black_concrete
fill 431 192 276 431 192 278 minecraft:gray_concrete
setblock 431 192 279 minecraft:black_concrete
fill 431 192 280 431 192 282 minecraft:gray_concrete
setblock 431 192 283 minecraft:black_concrete
fill 431 192 284 431 192 286 minecraft:gray_concrete
setblock 431 192 287 minecraft:black_concrete
fill 431 192 288 431 192 290 minecraft:gray_concrete
setblock 431 192 291 minecraft:black_concrete
fill 431 192 292 431 192 294 minecraft:gray_concrete
setblock 431 192 295 minecraft:black_concrete
fill 431 192 296 431 192 298 minecraft:gray_concrete
setblock 431 192 299 minecraft:black_concrete
fill 431 192 300 431 192 302 minecraft:gray_concrete
setblock 431 192 303 minecraft:black_concrete
fill 431 192 304 431 192 306 minecraft:gray_concrete
setblock 431 192 307 minecraft:black_concrete
fill 431 192 308 433 192 308 minecraft:gray_concrete
setblock 431 192 311 minecraft:black_concrete
fill 431 192 312 433 192 312 minecraft:gray_concrete
setblock 431 192 315 minecraft:black_concrete
fill 431 192 316 433 192 316 minecraft:gray_concrete
fill 432 192 276 432 192 277 minecraft:gray_concrete
setblock 432 192 278 minecraft:black_concrete
fill 432 192 279 432 192 281 minecraft:gray_concrete
setblock 432 192 282 minecraft:black_concrete
fill 432 192 283 432 192 285 minecraft:gray_concrete
setblock 432 192 286 minecraft:black_concrete
fill 432 192 287 432 192 289 minecraft:gray_concrete
setblock 432 192 290 minecraft:black_concrete
fill 432 192 291 432 192 293 minecraft:gray_concrete
setblock 432 192 294 minecraft:black_concrete
fill 432 192 295 432 192 297 minecraft:gray_concrete
setblock 432 192 298 minecraft:black_concrete
fill 432 192 299 432 192 301 minecraft:gray_concrete
setblock 432 192 302 minecraft:black_concrete
fill 432 192 303 432 192 305 minecraft:gray_concrete
setblock 432 192 306 minecraft:black_concrete
fill 432 192 307 434 192 307 minecraft:gray_concrete
setblock 432 192 310 minecraft:black_concrete
fill 432 192 311 434 192 311 minecraft:gray_concrete
setblock 432 192 314 minecraft:black_concrete
fill 432 192 315 434 192 315 minecraft:gray_concrete
setblock 433 192 276 minecraft:gray_concrete
setblock 433 192 277 minecraft:black_concrete
fill 433 192 278 433 192 280 minecraft:gray_concrete
setblock 433 192 281 minecraft:black_concrete
fill 433 192 282 433 192 284 minecraft:gray_concrete
setblock 433 192 285 minecraft:black_concrete
fill 433 192 286 433 192 288 minecraft:gray_concrete
setblock 433 192 289 minecraft:black_concrete
fill 433 192 290 433 192 292 minecraft:gray_concrete
setblock 433 192 293 minecraft:black_concrete
fill 433 192 294 433 192 296 minecraft:gray_concrete
setblock 433 192 297 minecraft:black_concrete
fill 433 192 298 433 192 300 minecraft:gray_concrete
setblock 433 192 301 minecraft:black_concrete
fill 433 192 302 433 192 304 minecraft:gray_concrete
setblock 433 192 305 minecraft:black_concrete
fill 433 192 306 435 192 306 minecraft:gray_concrete
setblock 433 192 309 minecraft:black_concrete
fill 433 192 310 435 192 310 minecraft:gray_concrete
setblock 433 192 313 minecraft:black_concrete
fill 433 192 314 435 192 314 minecraft:gray_concrete
setblock 434 192 276 minecraft:black_concrete
fill 434 192 277 434 192 279 minecraft:gray_concrete
setblock 434 192 280 minecraft:black_concrete
fill 434 192 281 434 192 283 minecraft:gray_concrete
setblock 434 192 284 minecraft:black_concrete
fill 434 192 285 434 192 287 minecraft:gray_concrete
fill 434 192 288 437 192 288 minecraft:black_concrete
fill 434 192 289 434 192 291 minecraft:gray_concrete
fill 434 192 292 436 192 292 minecraft:black_concrete
fill 434 192 293 434 192 295 minecraft:gray_concrete
fill 434 192 296 437 192 296 minecraft:black_concrete
fill 434 192 297 434 192 299 minecraft:gray_concrete
setblock 434 192 300 minecraft:black_concrete
fill 434 192 301 434 192 303 minecraft:gray_concrete
setblock 434 192 304 minecraft:black_concrete
fill 434 192 305 436 192 305 minecraft:gray_concrete
setblock 434 192 308 minecraft:black_concrete
fill 434 192 309 436 192 309 minecraft:gray_concrete
setblock 434 192 312 minecraft:black_concrete
fill 434 192 313 436 192 313 minecraft:gray_concrete
setblock 434 192 316 minecraft:black_concrete
fill 435 192 276 435 192 278 minecraft:gray_concrete
setblock 435 192 279 minecraft:black_concrete
fill 435 192 280 435 192 282 minecraft:gray_concrete
setblock 435 192 283 minecraft:black_concrete
fill 435 192 284 435 192 286 minecraft:gray_concrete
fill 435 192 287 436 192 287 minecraft:black_concrete
fill 435 192 289 435 192 291 minecraft:black_concrete
fill 435 192 293 435 192 295 minecraft:black_concrete
fill 435 192 297 435 192 298 minecraft:gray_concrete
setblock 435 192 299 minecraft:black_concrete
fill 435 192 300 435 192 302 minecraft:gray_concrete
setblock 435 192 303 minecraft:black_concrete
fill 435 192 304 437 192 304 minecraft:gray_concrete
setblock 435 192 307 minecraft:black_concrete
fill 435 192 308 437 192 308 minecraft:gray_concrete
setblock 435 192 311 minecraft:black_concrete
fill 435 192 312 437 192 312 minecraft:gray_concrete
setblock 435 192 315 minecraft:black_concrete
fill 435 192 316 437 192 316 minecraft:gray_concrete
fill 436 192 276 436 192 277 minecraft:gray_concrete
setblock 436 192 278 minecraft:black_concrete
fill 436 192 279 436 192 281 minecraft:gray_concrete
setblock 436 192 282 minecraft:black_concrete
fill 436 192 283 436 192 285 minecraft:gray_concrete
fill 436 192 286 439 192 286 minecraft:black_concrete
setblock 436 192 289 minecraft:gray_concrete
fill 436 192 290 436 192 291 minecraft:black_concrete
fill 436 192 293 436 192 294 minecraft:black_concrete
setblock 436 192 295 minecraft:gray_concrete
fill 436 192 297 436 192 298 minecraft:black_concrete
fill 436 192 299 436 192 301 minecraft:gray_concrete
setblock 436 192 302 minecraft:black_concrete
fill 436 192 303 438 192 303 minecraft:gray_concrete
setblock 436 192 306 minecraft:black_concrete
fill 436 192 307 438 192 307 minecraft:gray_concrete
setblock 436 192 310 minecraft:black_concrete
fill 436 192 311 438 192 311 minecraft:gray_concrete
setblock 436 192 314 minecraft:black_concrete
fill 436 192 315 438 192 315 minecraft:gray_concrete
setblock 437 192 276 minecraft:gray_concrete
setblock 437 192 277 minecraft:black_concrete
fill 437 192 278 437 192 280 minecraft:gray_concrete
setblock 437 192 281 minecraft:black_concrete
fill 437 192 282 437 192 284 minecraft:gray_concrete
fill 437 192 285 440 192 285 minecraft:black_concrete
setblock 437 192 287 minecraft:gray_concrete
fill 437 192 289 438 192 290 minecraft:black_concrete
fill 437 192 291 437 192 293 minecraft:gray_concrete
fill 437 192 294 438 192 295 minecraft:black_concrete
setblock 437 192 297 minecraft:gray_concrete
fill 437 192 298 439 192 299 minecraft:black_concrete
setblock 437 192 300 minecraft:gray_concrete
setblock 437 192 301 minecraft:black_concrete
fill 437 192 302 439 192 302 minecraft:gray_concrete
setblock 437 192 305 minecraft:black_concrete
fill 437 192 306 439 192 306 minecraft:gray_concrete
setblock 437 192 309 minecraft:black_concrete
fill 437 192 310 439 192 310 minecraft:gray_concrete
setblock 437 192 313 minecraft:black_concrete
fill 437 192 314 439 192 314 minecraft:gray_concrete
setblock 438 192 276 minecraft:black_concrete
fill 438 192 277 438 192 279 minecraft:gray_concrete
setblock 438 192 280 minecraft:black_concrete
fill 438 192 281 438 192 283 minecraft:gray_concrete
fill 438 192 284 439 192 284 minecraft:black_concrete
setblock 438 192 287 minecraft:black_concrete
setblock 438 192 288 minecraft:gray_concrete
fill 438 192 291 440 192 293 minecraft:black_concrete
setblock 438 192 296 minecraft:gray_concrete
setblock 438 192 297 minecraft:black_concrete
fill 438 192 300 439 192 300 minecraft:black_concrete
setblock 438 192 301 minecraft:gray_concrete
setblock 438 192 304 minecraft:black_concrete
fill 438 192 305 440 192 305 minecraft:gray_concrete
setblock 438 192 308 minecraft:black_concrete
fill 438 192 309 440 192 309 minecraft:gray_concrete
setblock 438 192 312 minecraft:black_concrete
fill 438 192 313 440 192 313 minecraft:gray_concrete
setblock 438 192 316 minecraft:black_concrete
fill 439 192 276 439 192 278 minecraft:gray_concrete
setblock 439 192 279 minecraft:black_concrete
fill 439 192 280 439 192 282 minecraft:gray_concrete
fill 439 192 283 441 192 283 minecraft:black_concrete
setblock 439 192 287 minecraft:gray_concrete
fill 439 192 288 439 192 289 minecraft:black_concrete
setblock 439 192 290 minecraft:gray_concrete
setblock 439 192 294 minecraft:gray_concrete
fill 439 192 295 439 192 296 minecraft:black_concrete
setblock 439 192 297 minecraft:gray_concrete
fill 439 192 301 441 192 301 minecraft:black_concrete
setblock 439 192 303 minecraft:black_concrete
fill 439 192 304 441 192 304 minecraft:gray_concrete
setblock 439 192 307 minecraft:black_concrete
fill 439 192 308 441 192 308 minecraft:gray_concrete
setblock 439 192 311 minecraft:black_concrete
fill 439 192 312 441 192 312 minecraft:gray_concrete
setblock 439 192 315 minecraft:black_concrete
fill 439 192 316 441 192 316 minecraft:gray_concrete
fill 440 192 276 440 192 277 minecraft:gray_concrete
setblock 440 192 278 minecraft:black_concrete
fill 440 192 279 440 192 281 minecraft:gray_concrete
setblock 440 192 282 minecraft:black_concrete
setblock 440 192 284 minecraft:gray_concrete
setblock 440 192 286 minecraft:gray_concrete
setblock 440 192 287 minecraft:black_concrete
setblock 440 192 288 minecraft:gray_concrete
fill 440 192 289 440 192 290 minecraft:black_concrete
fill 440 192 294 440 192 295 minecraft:black_concrete
setblock 440 192 296 minecraft:gray_concrete
setblock 440 192 297 minecraft:black_concrete
setblock 440 192 298 minecraft:gray_concrete
setblock 440 192 299 minecraft:black_concrete
setblock 440 192 300 minecraft:gray_concrete
setblock 440 192 302 minecraft:black_concrete
fill 440 192 303 442 192 303 minecraft:gray_concrete
setblock 440 192 306 minecraft:black_concrete
fill 440 192 307 442 192 307 minecraft:gray_concrete
setblock 440 192 310 minecraft:black_concrete
fill 440 192 311 442 192 311 minecraft:gray_concrete
setblock 440 192 314 minecraft:black_concrete
fill 440 192 315 442 192 315 minecraft:gray_concrete
setblock 441 192 276 minecraft:gray_concrete
setblock 441 192 277 minecraft:black_concrete
fill 441 192 278 441 192 280 minecraft:gray_concrete
setblock 441 192 281 minecraft:black_concrete
fill 441 192 284 443 192 284 minecraft:black_concrete
setblock 441 192 285 minecraft:gray_concrete
fill 441 192 286 442 192 286 minecraft:black_concrete
setblock 441 192 287 minecraft:gray_concrete
fill 441 192 288 441 192 289 minecraft:black_concrete
setblock 441 192 290 minecraft:red_concrete
fill 441 192 291 441 192 293 minecraft:white_concrete
setblock 441 192 294 minecraft:red_concrete
fill 441 192 295 441 192 296 minecraft:black_concrete
setblock 441 192 297 minecraft:gray_concrete
fill 441 192 298 442 192 298 minecraft:black_concrete
setblock 441 192 299 minecraft:gray_concrete
fill 441 192 300 443 192 300 minecraft:black_concrete
setblock 441 192 305 minecraft:black_concrete
fill 441 192 306 443 192 306 minecraft:gray_concrete
setblock 441 192 309 minecraft:black_concrete
fill 441 192 310 443 192 310 minecraft:gray_concrete
setblock 441 192 313 minecraft:black_concrete
fill 441 192 314 443 192 314 minecraft:gray_concrete
setblock 442 192 276 minecraft:black_concrete
fill 442 192 277 442 192 279 minecraft:gray_concrete
setblock 442 192 280 minecraft:black_concrete
fill 442 192 281 444 192 281 minecraft:gray_concrete
setblock 442 192 283 minecraft:gray_concrete
fill 442 192 285 448 192 285 minecraft:black_concrete
fill 442 192 287 442 192 288 minecraft:black_concrete
fill 442 192 289 442 192 291 minecraft:white_concrete
fill 442 192 293 442 192 295 minecraft:white_concrete
fill 442 192 296 442 192 297 minecraft:black_concrete
fill 442 192 299 448 192 299 minecraft:black_concrete
setblock 442 192 301 minecraft:gray_concrete
setblock 442 192 304 minecraft:black_concrete
fill 442 192 305 444 192 305 minecraft:gray_concrete
setblock 442 192 308 minecraft:black_concrete
fill 442 192 309 444 192 309 minecraft:gray_concrete
setblock 442 192 312 minecraft:black_concrete
fill 442 192 313 444 192 313 minecraft:gray_concrete
setblock 442 192 316 minecraft:black_concrete
fill 443 192 276 443 192 278 minecraft:gray_concrete
setblock 443 192 279 minecraft:black_concrete
fill 443 192 280 445 192 280 minecraft:gray_concrete
fill 443 192 283 447 192 283 minecraft:black_concrete
setblock 443 192 286 minecraft:gray_concrete
fill 443 192 287 448 192 287 minecraft:black_concrete
setblock 443 192 288 minecraft:red_concrete
fill 443 192 289 444 192 289 minecraft:white_concrete
fill 443 192 295 444 192 295 minecraft:white_concrete
setblock 443 192 296 minecraft:red_concrete
fill 443 192 297 448 192 297 minecraft:black_concrete
setblock 443 192 298 minecraft:gray_concrete
fill 443 192 301 447 192 301 minecraft:black_concrete
setblock 443 192 303 minecraft:black_concrete
fill 443 192 304 445 192 304 minecraft:gray_concrete
setblock 443 192 307 minecraft:black_concrete
fill 443 192 308 445 192 308 minecraft:gray_concrete
setblock 443 192 311 minecraft:black_concrete
fill 443 192 312 445 192 312 minecraft:gray_concrete
setblock 443 192 315 minecraft:black_concrete
fill 443 192 316 445 192 316 minecraft:gray_concrete
fill 444 192 276 444 192 277 minecraft:gray_concrete
setblock 444 192 278 minecraft:black_concrete
fill 444 192 279 446 192 279 minecraft:gray_concrete
fill 444 192 284 446 192 284 minecraft:gray_concrete
fill 444 192 286 446 192 286 minecraft:black_concrete
fill 444 192 288 446 192 288 minecraft:white_concrete
fill 444 192 296 446 192 296 minecraft:white_concrete
fill 444 192 298 446 192 298 minecraft:black_concrete
fill 444 192 300 446 192 300 minecraft:gray_concrete
setblock 444 192 303 minecraft:gray_concrete
setblock 444 192 306 minecraft:black_concrete
fill 444 192 307 446 192 307 minecraft:gray_concrete
setblock 444 192 310 minecraft:black_concrete
fill 444 192 311 446 192 311 minecraft:gray_concrete
setblock 444 192 314 minecraft:black_concrete
fill 444 192 315 446 192 315 minecraft:gray_concrete
setblock 445 192 276 minecraft:gray_concrete
setblock 445 192 277 minecraft:black_concrete
fill 445 192 278 447 192 278 minecraft:gray_concrete
setblock 445 192 305 minecraft:black_concrete
fill 445 192 306 447 192 306 minecraft:gray_concrete
setblock 445 192 309 minecraft:black_concrete
fill 445 192 310 447 192 310 minecraft:gray_concrete
setblock 445 192 313 minecraft:black_concrete
fill 445 192 314 447 192 314 minecraft:gray_concrete
setblock 446 192 276 minecraft:black_concrete
fill 446 192 277 448 192 277 minecraft:gray_concrete
setblock 446 192 280 minecraft:black_concrete
fill 446 192 281 448 192 281 minecraft:gray_concrete
fill 446 192 289 448 192 289 minecraft:white_concrete
fill 446 192 295 448 192 295 minecraft:white_concrete
setblock 446 192 303 minecraft:gray_concrete
setblock 446 192 304 minecraft:black_concrete
fill 446 192 305 448 192 305 minecraft:gray_concrete
setblock 446 192 308 minecraft:black_concrete
fill 446 192 309 448 192 309 minecraft:gray_concrete
setblock 446 192 312 minecraft:black_concrete
fill 446 192 313 448 192 313 minecraft:gray_concrete
setblock 446 192 316 minecraft:black_concrete
fill 447 192 276 449 192 276 minecraft:gray_concrete
setblock 447 192 279 minecraft:black_concrete
fill 447 192 280 449 192 280 minecraft:gray_concrete
fill 447 192 284 449 192 284 minecraft:black_concrete
setblock 447 192 286 minecraft:gray_concrete
setblock 447 192 288 minecraft:red_concrete
setblock 447 192 296 minecraft:red_concrete
setblock 447 192 298 minecraft:gray_concrete
fill 447 192 300 449 192 300 minecraft:black_concrete
setblock 447 192 303 minecraft:black_concrete
fill 447 192 304 449 192 304 minecraft:gray_concrete
setblock 447 192 307 minecraft:black_concrete
fill 447 192 308 449 192 308 minecraft:gray_concrete
setblock 447 192 311 minecraft:black_concrete
fill 447 192 312 449 192 312 minecraft:gray_concrete
setblock 447 192 315 minecraft:black_concrete
fill 447 192 316 449 192 316 minecraft:gray_concrete
setblock 448 192 278 minecraft:black_concrete
fill 448 192 279 450 192 279 minecraft:gray_concrete
setblock 448 192 283 minecraft:gray_concrete
fill 448 192 286 449 192 286 minecraft:black_concrete
fill 448 192 288 449 192 288 minecraft:black_concrete
fill 448 192 290 448 192 291 minecraft:white_concrete
fill 448 192 293 448 192 294 minecraft:white_concrete
fill 448 192 296 449 192 296 minecraft:black_concrete
fill 448 192 298 449 192 298 minecraft:black_concrete
setblock 448 192 301 minecraft:gray_concrete
fill 448 192 303 450 192 303 minecraft:gray_concrete
setblock 448 192 306 minecraft:black_concrete
fill 448 192 307 450 192 307 minecraft:gray_concrete
setblock 448 192 310 minecraft:black_concrete
fill 448 192 311 450 192 311 minecraft:gray_concrete
setblock 448 192 314 minecraft:black_concrete
fill 448 192 315 450 192 315 minecraft:gray_concrete
setblock 449 192 277 minecraft:black_concrete
fill 449 192 278 451 192 278 minecraft:gray_concrete
setblock 449 192 281 minecraft:black_concrete
fill 449 192 283 451 192 283 minecraft:black_concrete
setblock 449 192 285 minecraft:gray_concrete
setblock 449 192 287 minecraft:gray_concrete
fill 449 192 289 453 192 289 minecraft:black_concrete
setblock 449 192 290 minecraft:red_concrete
fill 449 192 291 449 192 293 minecraft:white_concrete
setblock 449 192 294 minecraft:red_concrete
fill 449 192 295 453 192 295 minecraft:black_concrete
setblock 449 192 297 minecraft:gray_concrete
setblock 449 192 299 minecraft:gray_concrete
fill 449 192 301 451 192 301 minecraft:black_concrete
setblock 449 192 305 minecraft:black_concrete
fill 449 192 306 451 192 306 minecraft:gray_concrete
setblock 449 192 309 minecraft:black_concrete
fill 449 192 310 451 192 310 minecraft:gray_concrete
setblock 449 192 313 minecraft:black_concrete
fill 449 192 314 451 192 314 minecraft:gray_concrete
setblock 450 192 276 minecraft:black_concrete
fill 450 192 277 452 192 277 minecraft:gray_concrete
setblock 450 192 280 minecraft:black_concrete
fill 450 192 281 451 192 282 minecraft:gray_concrete
setblock 450 192 284 minecraft:gray_concrete
fill 450 192 285 453 192 285 minecraft:black_concrete
setblock 450 192 286 minecraft:gray_concrete
setblock 450 192 287 minecraft:black_concrete
setblock 450 192 288 minecraft:gray_concrete
fill 450 192 290 450 192 294 minecraft:black_concrete
setblock 450 192 296 minecraft:gray_concrete
setblock 450 192 297 minecraft:black_concrete
setblock 450 192 298 minecraft:gray_concrete
fill 450 192 299 453 192 299 minecraft:black_concrete
setblock 450 192 300 minecraft:gray_concrete
fill 450 192 302 451 192 302 minecraft:gray_concrete
setblock 450 192 304 minecraft:black_concrete
fill 450 192 305 452 192 305 minecraft:gray_concrete
setblock 450 192 308 minecraft:black_concrete
fill 450 192 309 452 192 309 minecraft:gray_concrete
setblock 450 192 312 minecraft:black_concrete
fill 450 192 313 452 192 313 minecraft:gray_concrete
setblock 450 192 316 minecraft:black_concrete
fill 451 192 276 453 192 276 minecraft:gray_concrete
setblock 451 192 279 minecraft:black_concrete
fill 451 192 280 453 192 280 minecraft:gray_concrete
fill 451 192 284 452 192 284 minecraft:black_concrete
fill 451 192 286 454 192 286 minecraft:black_concrete
setblock 451 192 287 minecraft:gray_concrete
setblock 451 192 288 minecraft:black_concrete
setblock 451 192 290 minecraft:gray_concrete
fill 451 192 291 452 192 293 minecraft:black_concrete
setblock 451 192 294 minecraft:gray_concrete
setblock 451 192 296 minecraft:black_concrete
setblock 451 192 297 minecraft:gray_concrete
fill 451 192 298 454 192 298 minecraft:black_concrete
fill 451 192 300 452 192 300 minecraft:black_concrete
setblock 451 192 303 minecraft:black_concrete
fill 451 192 304 453 192 304 minecraft:gray_concrete
setblock 451 192 307 minecraft:black_concrete
fill 451 192 308 453 192 308 minecraft:gray_concrete
setblock 451 192 311 minecraft:black_concrete
fill 451 192 312 453 192 312 minecraft:gray_concrete
setblock 451 192 315 minecraft:black_concrete
fill 451 192 316 453 192 316 minecraft:gray_concrete
setblock 452 192 278 minecraft:black_concrete
fill 452 192 279 454 192 279 minecraft:gray_concrete
setblock 452 192 281 minecraft:gray_concrete
setblock 452 192 282 minecraft:black_concrete
fill 452 192 283 454 192 283 minecraft:gray_concrete
setblock 452 192 287 minecraft:black_concrete
setblock 452 192 288 minecraft:gray_concrete
fill 452 192 290 456 192 290 minecraft:black_concrete
fill 452 192 294 456 192 294 minecraft:black_concrete
setblock 452 192 296 minecraft:gray_concrete
setblock 452 192 297 minecraft:black_concrete
setblock 452 192 301 minecraft:gray_concrete
setblock 452 192 302 minecraft:black_concrete
fill 452 192 303 454 192 303 minecraft:gray_concrete
setblock 452 192 306 minecraft:black_concrete
fill 452 192 307 454 192 307 minecraft:gray_concrete
setblock 452 192 310 minecraft:black_concrete
fill 452 192 311 454 192 311 minecraft:gray_concrete
setblock 452 192 314 minecraft:black_concrete
fill 452 192 315 454 192 315 minecraft:gray_concrete
setblock 453 192 277 minecraft:black_concrete
fill 453 192 278 455 192 278 minecraft:gray_concrete
setblock 453 192 281 minecraft:black_concrete
fill 453 192 282 455 192 282 minecraft:gray_concrete
setblock 453 192 284 minecraft:gray_concrete
setblock 453 192 287 minecraft:gray_concrete
fill 453 192 288 455 192 288 minecraft:black_concrete
fill 453 192 291 453 192 293 minecraft:gray_concrete
fill 453 192 296 455 192 296 minecraft:black_concrete
setblock 453 192 297 minecraft:gray_concrete
setblock 453 192 300 minecraft:gray_concrete
setblock 453 192 301 minecraft:black_concrete
fill 453 192 302 455 192 302 minecraft:gray_concrete
setblock 453 192 305 minecraft:black_concrete
fill 453 192 306 455 192 306 minecraft:gray_concrete
setblock 453 192 309 minecraft:black_concrete
fill 453 192 310 455 192 310 minecraft:gray_concrete
setblock 453 192 313 minecraft:black_concrete
fill 453 192 314 455 192 314 minecraft:gray_concrete
setblock 454 192 276 minecraft:black_concrete
fill 454 192 277 456 192 277 minecraft:gray_concrete
setblock 454 192 280 minecraft:black_concrete
fill 454 192 281 456 192 281 minecraft:gray_concrete
setblock 454 192 284 minecraft:black_concrete
fill 454 192 285 456 192 285 minecraft:gray_concrete
fill 454 192 287 455 192 287 minecraft:black_concrete
setblock 454 192 289 minecraft:gray_concrete
fill 454 192 291 455 192 293 minecraft:black_concrete
setblock 454 192 295 minecraft:gray_concrete
setblock 454 192 297 minecraft:black_concrete
setblock 454 192 299 minecraft:gray_concrete
setblock 454 192 300 minecraft:black_concrete
fill 454 192 301 456 192 301 minecraft:gray_concrete
setblock 454 192 304 minecraft:black_concrete
fill 454 192 305 456 192 305 minecraft:gray_concrete
setblock 454 192 308 minecraft:black_concrete
fill 454 192 309 456 192 309 minecraft:gray_concrete
setblock 454 192 312 minecraft:black_concrete
fill 454 192 313 456 192 313 minecraft:gray_concrete
setblock 454 192 316 minecraft:black_concrete
fill 455 192 276 457 192 276 minecraft:gray_concrete
setblock 455 192 279 minecraft:black_concrete
fill 455 192 280 457 192 280 minecraft:gray_concrete
setblock 455 192 283 minecraft:black_concrete
fill 455 192 284 457 192 284 minecraft:gray_concrete
setblock 455 192 286 minecraft:gray_concrete
setblock 455 192 289 minecraft:black_concrete
setblock 455 192 295 minecraft:black_concrete
fill 455 192 297 455 192 298 minecraft:gray_concrete
setblock 455 192 299 minecraft:black_concrete
fill 455 192 300 457 192 300 minecraft:gray_concrete
setblock 455 192 303 minecraft:black_concrete
fill 455 192 304 457 192 304 minecraft:gray_concrete
setblock 455 192 307 minecraft:black_concrete
fill 455 192 308 457 192 308 minecraft:gray_concrete
setblock 455 192 311 minecraft:black_concrete
fill 455 192 312 457 192 312 minecraft:gray_concrete
setblock 455 192 315 minecraft:black_concrete
fill 455 192 316 457 192 316 minecraft:gray_concrete
setblock 456 192 278 minecraft:black_concrete
fill 456 192 279 458 192 279 minecraft:gray_concrete
setblock 456 192 282 minecraft:black_concrete
fill 456 192 283 458 192 283 minecraft:gray_concrete
setblock 456 192 286 minecraft:black_concrete
fill 456 192 287 456 192 289 minecraft:gray_concrete
fill 456 192 291 458 192 291 minecraft:gray_concrete
setblock 456 192 292 minecraft:black_concrete
setblock 456 192 293 minecraft:gray_concrete
fill 456 192 295 456 192 297 minecraft:gray_concrete
setblock 456 192 298 minecraft:black_concrete
fill 456 192 299 458 192 299 minecraft:gray_concrete
setblock 456 192 302 minecraft:black_concrete
fill 456 192 303 458 192 303 minecraft:gray_concrete
setblock 456 192 306 minecraft:black_concrete
fill 456 192 307 458 192 307 minecraft:gray_concrete
setblock 456 192 310 minecraft:black_concrete
fill 456 192 311 458 192 311 minecraft:gray_concrete
setblock 456 192 314 minecraft:black_concrete
fill 456 192 315 458 192 315 minecraft:gray_concrete
setblock 457 192 277 minecraft:black_concrete
fill 457 192 278 459 192 278 minecraft:gray_concrete
setblock 457 192 281 minecraft:black_concrete
fill 457 192 282 459 192 282 minecraft:gray_concrete
setblock 457 192 285 minecraft:black_concrete
fill 457 192 286 457 192 288 minecraft:gray_concrete
setblock 457 192 289 minecraft:black_concrete
fill 457 192 290 459 192 290 minecraft:gray_concrete
setblock 457 192 292 minecraft:gray_concrete
setblock 457 192 293 minecraft:black_concrete
fill 457 192 294 457 192 296 minecraft:gray_concrete
setblock 457 192 297 minecraft:black_concrete
fill 457 192 298 459 192 298 minecraft:gray_concrete
setblock 457 192 301 minecraft:black_concrete
fill 457 192 302 459 192 302 minecraft:gray_concrete
setblock 457 192 305 minecraft:black_concrete
fill 457 192 306 459 192 306 minecraft:gray_concrete
setblock 457 192 309 minecraft:black_concrete
fill 457 192 310 459 192 310 minecraft:gray_concrete
setblock 457 192 313 minecraft:black_concrete
fill 457 192 314 459 192 314 minecraft:gray_concrete
setblock 458 192 276 minecraft:black_concrete
fill 458 192 277 460 192 277 minecraft:gray_concrete
setblock 458 192 280 minecraft:black_concrete
fill 458 192 281 460 192 281 minecraft:gray_concrete
setblock 458 192 284 minecraft:black_concrete
fill 458 192 285 458 192 287 minecraft:gray_concrete
setblock 458 192 288 minecraft:black_concrete
fill 458 192 289 460 192 289 minecraft:gray_concrete
setblock 458 192 292 minecraft:black_concrete
fill 458 192 293 458 192 295 minecraft:gray_concrete
setblock 458 192 296 minecraft:black_concrete
fill 458 192 297 460 192 297 minecraft:gray_concrete
setblock 458 192 300 minecraft:black_concrete
fill 458 192 301 460 192 301 minecraft:gray_concrete
setblock 458 192 304 minecraft:black_concrete
fill 458 192 305 460 192 305 minecraft:gray_concrete
setblock 458 192 308 minecraft:black_concrete
fill 458 192 309 460 192 309 minecraft:gray_concrete
setblock 458 192 312 minecraft:black_concrete
fill 458 192 313 460 192 313 minecraft:gray_concrete
setblock 458 192 316 minecraft:black_concrete
fill 459 192 276 461 192 276 minecraft:gray_concrete
setblock 459 192 279 minecraft:black_concrete
fill 459 192 280 461 192 280 minecraft:gray_concrete
setblock 459 192 283 minecraft:black_concrete
fill 459 192 284 459 192 286 minecraft:gray_concrete
setblock 459 192 287 minecraft:black_concrete
fill 459 192 288 461 192 288 minecraft:gray_concrete
setblock 459 192 291 minecraft:black_concrete
fill 459 192 292 459 192 294 minecraft:gray_concrete
setblock 459 192 295 minecraft:black_concrete
fill 459 192 296 461 192 296 minecraft:gray_concrete
setblock 459 192 299 minecraft:black_concrete
fill 459 192 300 461 192 300 minecraft:gray_concrete
setblock 459 192 303 minecraft:black_concrete
fill 459 192 304 461 192 304 minecraft:gray_concrete
setblock 459 192 307 minecraft:black_concrete
fill 459 192 308 461 192 308 minecraft:gray_concrete
setblock 459 192 311 minecraft:black_concrete
fill 459 192 312 461 192 312 minecraft:gray_concrete
setblock 459 192 315 minecraft:black_concrete
fill 459 192 316 461 192 316 minecraft:gray_concrete
setblock 460 192 278 minecraft:black_concrete
fill 460 192 279 462 192 279 minecraft:gray_concrete
setblock 460 192 282 minecraft:black_concrete
fill 460 192 283 460 192 285 minecraft:gray_concrete
setblock 460 192 286 minecraft:black_concrete
fill 460 192 287 462 192 287 minecraft:gray_concrete
setblock 460 192 290 minecraft:black_concrete
fill 460 192 291 460 192 293 minecraft:gray_concrete
setblock 460 192 294 minecraft:black_concrete
fill 460 192 295 462 192 295 minecraft:gray_concrete
setblock 460 192 298 minecraft:black_concrete
fill 460 192 299 462 192 299 minecraft:gray_concrete
setblock 460 192 302 minecraft:black_concrete
fill 460 192 303 462 192 303 minecraft:gray_concrete
setblock 460 192 306 minecraft:black_concrete
fill 460 192 307 462 192 307 minecraft:gray_concrete
setblock 460 192 310 minecraft:black_concrete
fill 460 192 311 462 192 311 minecraft:gray_concrete
setblock 460 192 314 minecraft:black_concrete
fill 460 192 315 462 192 315 minecraft:gray_concrete
setblock 461 192 277 minecraft:black_concrete
fill 461 192 278 463 192 278 minecraft:gray_concrete
setblock 461 192 281 minecraft:black_concrete
fill 461 192 282 461 192 284 minecraft:gray_concrete
setblock 461 192 285 minecraft:black_concrete
fill 461 192 286 463 192 286 minecraft:gray_concrete
setblock 461 192 289 minecraft:black_concrete
fill 461 192 290 461 192 292 minecraft:gray_concrete
setblock 461 192 293 minecraft:black_concrete
fill 461 192 294 463 192 294 minecraft:gray_concrete
setblock 461 192 297 minecraft:black_concrete
fill 461 192 298 463 192 298 minecraft:gray_concrete
setblock 461 192 301 minecraft:black_concrete
fill 461 192 302 463 192 302 minecraft:gray_concrete
setblock 461 192 305 minecraft:black_concrete
fill 461 192 306 463 192 306 minecraft:gray_concrete
setblock 461 192 309 minecraft:black_concrete
fill 461 192 310 463 192 310 minecraft:gray_concrete
setblock 461 192 313 minecraft:black_concrete
fill 461 192 314 463 192 314 minecraft:gray_concrete
setblock 462 192 276 minecraft:black_concrete
fill 462 192 277 464 192 277 minecraft:gray_concrete
setblock 462 192 280 minecraft:black_concrete
fill 462 192 281 462 192 283 minecraft:gray_concrete
setblock 462 192 284 minecraft:black_concrete
fill 462 192 285 464 192 285 minecraft:gray_concrete
setblock 462 192 288 minecraft:black_concrete
fill 462 192 289 462 192 291 minecraft:gray_concrete
setblock 462 192 292 minecraft:black_concrete
fill 462 192 293 464 192 293 minecraft:gray_concrete
setblock 462 192 296 minecraft:black_concrete
fill 462 192 297 464 192 297 minecraft:gray_concrete
setblock 462 192 300 minecraft:black_concrete
fill 462 192 301 464 192 301 minecraft:gray_concrete
setblock 462 192 304 minecraft:black_concrete
fill 462 192 305 464 192 305 minecraft:gray_concrete
setblock 462 192 308 minecraft:black_concrete
fill 462 192 309 464 192 309 minecraft:gray_concrete
setblock 462 192 312 minecraft:black_concrete
fill 462 192 313 464 192 313 minecraft:gray_concrete
setblock 462 192 316 minecraft:black_concrete
fill 463 192 276 464 192 276 minecraft:gray_concrete
setblock 463 192 279 minecraft:black_concrete
fill 463 192 280 463 192 282 minecraft:gray_concrete
setblock 463 192 283 minecraft:black_concrete
fill 463 192 284 464 192 284 minecraft:gray_concrete
setblock 463 192 287 minecraft:black_concrete
fill 463 192 288 463 192 290 minecraft:gray_concrete
setblock 463 192 291 minecraft:black_concrete
fill 463 192 292 464 192 292 minecraft:gray_concrete
setblock 463 192 295 minecraft:black_concrete
fill 463 192 296 464 192 296 minecraft:gray_concrete
setblock 463 192 299 minecraft:black_concrete
fill 463 192 300 464 192 300 minecraft:gray_concrete
setblock 463 192 303 minecraft:black_concrete
fill 463 192 304 464 192 304 minecraft:gray_concrete
setblock 463 192 307 minecraft:black_concrete
fill 463 192 308 464 192 308 minecraft:gray_concrete
setblock 463 192 311 minecraft:black_concrete
fill 463 192 312 464 192 312 minecraft:gray_concrete
setblock 463 192 315 minecraft:black_concrete
fill 463 192 316 464 192 316 minecraft:gray_concrete
setblock 464 192 278 minecraft:black_concrete
fill 464 192 279 464 192 281 minecraft:gray_concrete
setblock 464 192 282 minecraft:black_concrete
setblock 464 192 283 minecraft:gray_concrete
setblock 464 192 286 minecraft:black_concrete
fill 464 192 287 464 192 289 minecraft:gray_concrete
setblock 464 192 290 minecraft:black_concrete
setblock 464 192 291 minecraft:gray_concrete
setblock 464 192 294 minecraft:black_concrete
setblock 464 192 295 minecraft:gray_concrete
setblock 464 192 298 minecraft:black_concrete
setblock 464 192 299 minecraft:gray_concrete
setblock 464 192 302 minecraft:black_concrete
setblock 464 192 303 minecraft:gray_concrete
setblock 464 192 306 minecraft:black_concrete
setblock 464 192 307 minecraft:gray_concrete
setblock 464 192 310 minecraft:black_concrete
setblock 464 192 311 minecraft:gray_concrete
setblock 464 192 314 minecraft:black_concrete
setblock 464 192 315 minecraft:gray_concrete
fill 431 193 292 433 207 292 minecraft:pink_concrete
fill 432 193 291 432 207 291 minecraft:pink_concrete
fill 432 193 293 432 207 293 minecraft:pink_concrete
fill 435 193 282 436 207 283 minecraft:light_blue_concrete
fill 435 193 301 436 207 302 minecraft:light_blue_concrete
fill 444 193 279 446 207 279 minecraft:pink_concrete
fill 444 193 305 446 207 305 minecraft:pink_concrete
fill 445 193 278 445 207 278 minecraft:pink_concrete
fill 445 193 280 445 207 280 minecraft:pink_concrete
fill 445 193 304 445 207 304 minecraft:pink_concrete
fill 445 193 306 445 207 306 minecraft:pink_concrete
fill 451 193 300 452 194 300 minecraft:iron_block
fill 454 193 282 455 207 283 minecraft:light_blue_concrete
fill 454 193 299 455 194 299 minecraft:iron_block
fill 454 193 301 455 207 302 minecraft:light_blue_concrete
fill 457 193 292 459 207 292 minecraft:pink_concrete
fill 457 193 298 458 194 298 minecraft:iron_block
fill 458 193 291 458 207 291 minecraft:pink_concrete
fill 458 193 293 458 207 293 minecraft:pink_concrete
fill 438 194 289 438 195 295 minecraft:magenta_concrete
fill 439 194 288 439 195 289 minecraft:magenta_concrete
fill 439 194 295 439 195 296 minecraft:magenta_concrete
fill 440 194 287 440 195 288 minecraft:magenta_concrete
fill 440 194 296 440 195 297 minecraft:magenta_concrete
fill 441 194 286 441 195 287 minecraft:magenta_concrete
fill 441 194 297 441 195 298 minecraft:magenta_concrete
fill 442 194 285 442 195 286 minecraft:magenta_concrete
fill 442 194 298 442 195 299 minecraft:magenta_concrete
fill 443 194 285 448 195 285 minecraft:magenta_concrete
fill 443 194 299 448 195 299 minecraft:magenta_concrete
fill 448 194 286 449 195 286 minecraft:magenta_concrete
fill 448 194 298 449 195 298 minecraft:magenta_concrete
fill 449 194 287 450 195 287 minecraft:magenta_concrete
fill 449 194 297 450 195 297 minecraft:magenta_concrete
fill 450 194 288 451 195 288 minecraft:magenta_concrete
fill 450 194 296 451 195 296 minecraft:magenta_concrete
fill 451 194 289 452 195 289 minecraft:magenta_concrete
fill 451 194 295 452 195 295 minecraft:magenta_concrete
fill 452 194 290 452 195 294 minecraft:magenta_concrete
fill 424 196 277 424 264 277 minecraft:iron_block
fill 424 196 287 424 264 287 minecraft:iron_block
fill 424 196 297 424 264 297 minecraft:iron_block
fill 424 196 307 424 264 307 minecraft:iron_block
fill 425 196 316 425 264 316 minecraft:iron_block
setblock 426 196 278 minecraft:light[level=15]
setblock 426 196 285 minecraft:light[level=12]
setblock 426 196 286 minecraft:light[level=15]
setblock 426 196 292 minecraft:light[level=12]
setblock 426 196 294 minecraft:light[level=15]
setblock 426 196 299 minecraft:light[level=12]
setblock 426 196 302 minecraft:light[level=15]
setblock 426 196 306 minecraft:light[level=12]
setblock 426 196 310 minecraft:light[level=15]
setblock 426 196 313 minecraft:light[level=12]
fill 429 196 277 433 200 277 minecraft:purple_wool
fill 431 196 276 431 264 276 minecraft:iron_block
setblock 433 196 278 minecraft:light[level=12]
setblock 433 196 285 minecraft:light[level=12]
setblock 433 196 299 minecraft:light[level=12]
setblock 433 196 306 minecraft:light[level=12]
setblock 433 196 313 minecraft:light[level=12]
setblock 434 196 278 minecraft:light[level=15]
setblock 434 196 286 minecraft:light[level=15]
setblock 434 196 294 minecraft:light[level=15]
setblock 434 196 302 minecraft:light[level=15]
setblock 434 196 310 minecraft:light[level=15]
fill 435 196 316 435 264 316 minecraft:iron_block
setblock 440 196 278 minecraft:light[level=12]
setblock 440 196 285 minecraft:light[level=12]
setblock 440 196 292 minecraft:light[level=12]
setblock 440 196 299 minecraft:light[level=12]
setblock 440 196 306 minecraft:light[level=12]
setblock 440 196 313 minecraft:light[level=12]
fill 441 196 276 441 264 276 minecraft:iron_block
setblock 442 196 278 minecraft:light[level=15]
setblock 442 196 286 minecraft:light[level=15]
setblock 442 196 294 minecraft:light[level=15]
setblock 442 196 302 minecraft:light[level=15]
setblock 442 196 310 minecraft:light[level=15]
fill 445 196 316 445 264 316 minecraft:iron_block
setblock 447 196 278 minecraft:light[level=12]
setblock 447 196 285 minecraft:light[level=12]
setblock 447 196 292 minecraft:light[level=12]
setblock 447 196 299 minecraft:light[level=12]
setblock 447 196 306 minecraft:light[level=12]
setblock 447 196 313 minecraft:light[level=12]
setblock 450 196 278 minecraft:light[level=15]
setblock 450 196 286 minecraft:light[level=15]
setblock 450 196 294 minecraft:light[level=15]
setblock 450 196 302 minecraft:light[level=15]
setblock 450 196 310 minecraft:light[level=15]
fill 451 196 276 451 264 276 minecraft:iron_block
setblock 454 196 278 minecraft:light[level=12]
setblock 454 196 285 minecraft:light[level=12]
setblock 454 196 292 minecraft:light[level=12]
setblock 454 196 299 minecraft:light[level=12]
setblock 454 196 306 minecraft:light[level=12]
setblock 454 196 313 minecraft:light[level=12]
fill 455 196 316 455 264 316 minecraft:iron_block
setblock 458 196 278 minecraft:light[level=15]
setblock 458 196 286 minecraft:light[level=15]
setblock 458 196 294 minecraft:light[level=15]
setblock 458 196 302 minecraft:light[level=15]
setblock 458 196 310 minecraft:black_concrete
fill 458 196 311 461 208 311 minecraft:gray_concrete
fill 458 196 312 458 196 313 minecraft:black_concrete
fill 459 196 309 461 196 309 minecraft:black_concrete
fill 459 196 310 461 208 310 minecraft:gray_concrete
fill 459 196 312 461 208 312 minecraft:gray_concrete
fill 459 196 313 462 196 314 minecraft:black_concrete
fill 461 196 276 461 264 276 minecraft:iron_block
setblock 461 196 278 minecraft:light[level=12]
setblock 461 196 285 minecraft:light[level=12]
setblock 461 196 292 minecraft:light[level=12]
setblock 461 196 299 minecraft:light[level=12]
setblock 461 196 306 minecraft:light[level=12]
fill 462 196 310 462 196 312 minecraft:black_concrete
fill 464 196 283 464 264 283 minecraft:iron_block
fill 464 196 293 464 264 293 minecraft:iron_block
fill 464 196 303 464 264 303 minecraft:iron_block
fill 464 196 313 464 264 313 minecraft:iron_block
fill 426 197 294 427 198 298 minecraft:gray_concrete
fill 427 197 290 427 198 293 minecraft:gray_concrete
fill 427 197 299 427 198 302 minecraft:gray_concrete
fill 428 197 288 428 198 290 minecraft:gray_concrete
fill 428 197 302 428 198 304 minecraft:gray_concrete
fill 429 197 286 429 198 288 minecraft:gray_concrete
fill 429 197 304 429 198 306 minecraft:gray_concrete
fill 430 197 285 430 198 286 minecraft:gray_concrete
fill 430 197 306 430 198 307 minecraft:gray_concrete
fill 431 197 284 431 198 285 minecraft:gray_concrete
fill 431 197 307 431 198 308 minecraft:gray_concrete
fill 432 197 283 432 198 284 minecraft:gray_concrete
fill 432 197 308 432 198 309 minecraft:gray_concrete
fill 433 197 282 433 198 283 minecraft:gray_concrete
fill 433 197 309 433 198 310 minecraft:gray_concrete
fill 434 197 281 434 198 282 minecraft:gray_concrete
fill 434 197 310 434 198 311 minecraft:gray_concrete
fill 435 197 281 436 198 281 minecraft:gray_concrete
fill 435 197 311 436 198 311 minecraft:gray_concrete
fill 436 197 280 438 198 280 minecraft:gray_concrete
fill 436 197 312 438 198 312 minecraft:gray_concrete
fill 438 197 279 443 198 279 minecraft:gray_concrete
fill 438 197 313 450 198 313 minecraft:gray_concrete
fill 442 197 278 444 198 278 minecraft:gray_concrete
fill 442 197 314 446 198 314 minecraft:gray_concrete
fill 446 197 278 446 198 278 minecraft:gray_concrete
fill 447 197 279 450 198 279 minecraft:gray_concrete
fill 450 197 280 452 198 280 minecraft:gray_concrete
fill 450 197 312 452 198 312 minecraft:gray_concrete
fill 452 197 281 454 198 281 minecraft:gray_concrete
fill 452 197 311 454 198 311 minecraft:gray_concrete
fill 454 197 310 455 198 310 minecraft:gray_concrete
fill 455 197 309 456 198 309 minecraft:gray_concrete
fill 456 197 283 456 198 284 minecraft:gray_concrete
fill 456 197 308 457 198 308 minecraft:gray_concrete
fill 457 197 284 457 198 285 minecraft:gray_concrete
fill 457 197 307 458 198 307 minecraft:gray_concrete
fill 458 197 285 458 198 286 minecraft:gray_concrete
fill 458 197 306 459 198 306 minecraft:gray_concrete
fill 459 197 286 459 198 288 minecraft:gray_concrete
fill 459 197 304 459 198 305 minecraft:gray_concrete
fill 459 197 313 461 203 313 minecraft:gray_concrete
fill 460 197 288 460 198 290 minecraft:gray_concrete
fill 460 197 302 460 198 304 minecraft:gray_concrete
fill 461 197 290 461 198 302 minecraft:gray_concrete
fill 462 197 294 462 198 298 minecraft:gray_concrete
fill 462 197 312 462 203 312 minecraft:gray_concrete
setblock 424 198 278 minecraft:gray_concrete
fill 424 198 280 424 198 283 minecraft:gray_concrete
setblock 424 198 288 minecraft:gray_concrete
fill 424 198 290 424 198 293 minecraft:gray_concrete
setblock 424 198 298 minecraft:gray_concrete
fill 424 198 300 424 198 303 minecraft:gray_concrete
setblock 424 198 308 minecraft:gray_concrete
fill 424 198 310 424 198 313 minecraft:gray_concrete
fill 425 198 276 428 198 276 minecraft:gray_concrete
setblock 426 198 316 minecraft:gray_concrete
fill 428 198 316 431 198 316 minecraft:gray_concrete
setblock 430 198 276 minecraft:gray_concrete
fill 435 198 276 438 198 276 minecraft:gray_concrete
fill 436 198 289 436 199 295 minecraft:cyan_concrete
setblock 436 198 316 minecraft:gray_concrete
fill 437 198 287 437 199 289 minecraft:cyan_concrete
fill 437 198 295 437 199 297 minecraft:cyan_concrete
fill 438 198 286 438 199 287 minecraft:cyan_concrete
fill 438 198 297 438 199 298 minecraft:cyan_concrete
fill 438 198 316 441 198 316 minecraft:gray_concrete
fill 439 198 285 439 199 286 minecraft:cyan_concrete
fill 439 198 298 439 199 299 minecraft:cyan_concrete
setblock 440 198 276 minecraft:gray_concrete
fill 440 198 284 440 199 285 minecraft:cyan_concrete
fill 440 198 299 440 199 300 minecraft:cyan_concrete
fill 441 198 284 442 199 284 minecraft:cyan_concrete
fill 441 198 300 442 199 300 minecraft:cyan_concrete
fill 442 198 283 448 199 283 minecraft:cyan_concrete
fill 442 198 301 448 199 301 minecraft:cyan_concrete
fill 445 198 276 448 198 276 minecraft:gray_concrete
setblock 446 198 316 minecraft:gray_concrete
fill 448 198 284 450 199 284 minecraft:cyan_concrete
fill 448 198 300 450 199 300 minecraft:cyan_concrete
fill 448 198 316 451 198 316 minecraft:gray_concrete
setblock 450 198 276 minecraft:gray_concrete
fill 450 198 285 451 199 285 minecraft:cyan_concrete
fill 450 198 299 451 199 299 minecraft:cyan_concrete
fill 451 198 286 452 199 286 minecraft:cyan_concrete
fill 451 198 298 452 199 298 minecraft:cyan_concrete
fill 452 198 287 453 199 287 minecraft:cyan_concrete
fill 452 198 297 453 199 297 minecraft:cyan_concrete
fill 453 198 288 453 199 289 minecraft:cyan_concrete
fill 453 198 295 453 199 296 minecraft:cyan_concrete
fill 454 198 289 454 199 295 minecraft:cyan_concrete
fill 455 198 276 458 198 276 minecraft:gray_concrete
setblock 456 198 316 minecraft:gray_concrete
fill 458 198 316 461 198 316 minecraft:gray_concrete
setblock 460 198 276 minecraft:gray_concrete
fill 464 198 277 464 198 280 minecraft:gray_concrete
setblock 464 198 282 minecraft:gray_concrete
fill 464 198 287 464 198 290 minecraft:gray_concrete
setblock 464 198 292 minecraft:gray_concrete
fill 464 198 297 464 198 300 minecraft:gray_concrete
setblock 464 198 302 minecraft:gray_concrete
fill 464 198 307 464 198 310 minecraft:gray_concrete
setblock 464 198 312 minecraft:gray_concrete
fill 446 199 278 448 199 278 minecraft:sea_lantern
fill 449 199 279 451 199 279 minecraft:sea_lantern
fill 452 199 280 453 199 280 minecraft:sea_lantern
fill 428 201 277 434 202 277 minecraft:iron_block
fill 423 202 281 423 202 284 minecraft:sea_lantern
fill 423 202 291 423 202 294 minecraft:sea_lantern
fill 423 202 301 423 202 304 minecraft:sea_lantern
fill 423 202 311 423 202 314 minecraft:sea_lantern
fill 426 202 275 429 202 275 minecraft:sea_lantern
setblock 426 202 278 minecraft:light[level=12]
setblock 426 202 285 minecraft:light[level=12]
setblock 426 202 292 minecraft:light[level=12]
setblock 426 202 299 minecraft:light[level=12]
setblock 426 202 306 minecraft:light[level=12]
setblock 426 202 313 minecraft:light[level=12]
fill 427 202 317 430 202 317 minecraft:sea_lantern
setblock 433 202 278 minecraft:light[level=12]
setblock 433 202 285 minecraft:light[level=12]
setblock 433 202 299 minecraft:light[level=12]
setblock 433 202 306 minecraft:light[level=12]
setblock 433 202 313 minecraft:light[level=12]
fill 434 202 289 434 203 295 minecraft:lime_concrete
fill 435 202 287 435 203 289 minecraft:lime_concrete
fill 435 202 295 435 203 297 minecraft:lime_concrete
fill 436 202 275 439 202 275 minecraft:sea_lantern
fill 436 202 285 436 203 286 minecraft:lime_concrete
fill 436 202 298 436 203 299 minecraft:lime_concrete
fill 437 202 284 437 203 285 minecraft:lime_concrete
fill 437 202 299 437 203 300 minecraft:lime_concrete
fill 437 202 317 440 202 317 minecraft:sea_lantern
fill 438 202 283 438 203 284 minecraft:lime_concrete
fill 438 202 300 438 203 301 minecraft:lime_concrete
fill 439 202 283 439 203 283 minecraft:lime_concrete
fill 439 202 301 439 203 301 minecraft:lime_concrete
setblock 440 202 278 minecraft:light[level=12]
fill 440 202 282 442 203 282 minecraft:lime_concrete
setblock 440 202 285 minecraft:light[level=12]
setblock 440 202 292 minecraft:light[level=12]
setblock 440 202 299 minecraft:light[level=12]
fill 440 202 302 442 203 302 minecraft:lime_concrete
setblock 440 202 306 minecraft:light[level=12]
setblock 440 202 313 minecraft:light[level=12]
fill 442 202 281 448 203 281 minecraft:lime_concrete
fill 442 202 303 448 203 303 minecraft:lime_concrete
fill 446 202 275 449 202 275 minecraft:sea_lantern
setblock 447 202 278 minecraft:light[level=12]
setblock 447 202 285 minecraft:light[level=12]
setblock 447 202 292 minecraft:light[level=12]
setblock 447 202 299 minecraft:light[level=12]
setblock 447 202 306 minecraft:light[level=12]
setblock 447 202 313 minecraft:light[level=12]
fill 447 202 317 450 202 317 minecraft:sea_lantern
fill 448 202 282 450 203 282 minecraft:lime_concrete
fill 448 202 302 450 203 302 minecraft:lime_concrete
fill 451 202 283 452 203 283 minecraft:lime_concrete
fill 451 202 301 452 203 301 minecraft:lime_concrete
fill 452 202 284 453 203 284 minecraft:lime_concrete
fill 452 202 300 453 203 300 minecraft:lime_concrete
fill 453 202 285 454 203 285 minecraft:lime_concrete
fill 453 202 299 454 203 299 minecraft:lime_concrete
setblock 454 202 278 minecraft:light[level=12]
fill 454 202 286 454 203 286 minecraft:lime_concrete
setblock 454 202 292 minecraft:light[level=12]
fill 454 202 298 454 203 298 minecraft:lime_concrete
setblock 454 202 306 minecraft:light[level=12]
setblock 454 202 313 minecraft:light[level=12]
fill 455 202 287 455 203 289 minecraft:lime_concrete
fill 455 202 295 455 203 297 minecraft:lime_concrete
fill 456 202 275 459 202 275 minecraft:sea_lantern
fill 456 202 289 456 203 295 minecraft:lime_concrete
fill 457 202 317 460 202 317 minecraft:sea_lantern
setblock 461 202 278 minecraft:light[level=12]
setblock 461 202 285 minecraft:light[level=12]
setblock 461 202 292 minecraft:light[level=12]
setblock 461 202 299 minecraft:light[level=12]
setblock 461 202 306 minecraft:light[level=12]
fill 465 202 276 465 202 279 minecraft:sea_lantern
fill 465 202 286 465 202 289 minecraft:sea_lantern
fill 465 202 296 465 202 299 minecraft:sea_lantern
fill 465 202 306 465 202 309 minecraft:sea_lantern
setblock 465 202 316 minecraft:sea_lantern
fill 423 203 281 423 210 284 minecraft:black_concrete
fill 423 203 291 423 210 294 minecraft:black_concrete
fill 423 203 301 423 210 304 minecraft:black_concrete
fill 423 203 311 423 210 314 minecraft:black_concrete
fill 426 203 275 429 210 275 minecraft:black_concrete
fill 427 203 282 427 204 282 minecraft:black_concrete
fill 427 203 312 427 204 312 minecraft:black_concrete
fill 427 203 317 430 210 317 minecraft:black_concrete
fill 431 203 312 431 204 312 minecraft:black_concrete
fill 435 203 279 435 204 279 minecraft:black_concrete
fill 436 203 275 439 210 275 minecraft:black_concrete
fill 437 203 317 440 210 317 minecraft:black_concrete
fill 446 203 275 449 210 275 minecraft:black_concrete
fill 447 203 317 450 210 317 minecraft:black_concrete
fill 449 203 312 449 204 312 minecraft:black_concrete
fill 454 203 312 454 204 312 minecraft:black_concrete
fill 456 203 275 459 210 275 minecraft:black_concrete
fill 457 203 317 460 210 317 minecraft:black_concrete
fill 465 203 276 465 210 279 minecraft:black_concrete
fill 465 203 286 465 210 289 minecraft:black_concrete
fill 465 203 296 465 210 299 minecraft:black_concrete
fill 465 203 306 465 210 309 minecraft:black_concrete
fill 465 203 316 465 210 316 minecraft:black_concrete
setblock 424 204 278 minecraft:gray_concrete
setblock 424 204 288 minecraft:gray_concrete
setblock 424 204 298 minecraft:gray_concrete
setblock 424 204 308 minecraft:gray_concrete
setblock 426 204 278 minecraft:light[level=15]
fill 426 204 282 426 205 282 minecraft:black_concrete
setblock 426 204 286 minecraft:light[level=15]
setblock 426 204 294 minecraft:light[level=15]
setblock 426 204 302 minecraft:light[level=15]
setblock 426 204 310 minecraft:light[level=15]
fill 426 204 312 426 205 312 minecraft:black_concrete
setblock 426 204 316 minecraft:gray_concrete
setblock 430 204 276 minecraft:gray_concrete
fill 431 204 313 431 205 313 minecraft:black_concrete
setblock 434 204 278 minecraft:light[level=15]
setblock 434 204 286 minecraft:light[level=15]
setblock 434 204 294 minecraft:light[level=15]
setblock 434 204 302 minecraft:light[level=15]
setblock 434 204 310 minecraft:light[level=15]
fill 435 204 278 435 205 278 minecraft:black_concrete
setblock 436 204 316 minecraft:gray_concrete
setblock 440 204 276 minecraft:gray_concrete
setblock 442 204 278 minecraft:light[level=15]
setblock 442 204 286 minecraft:light[level=15]
setblock 442 204 294 minecraft:light[level=15]
setblock 442 204 302 minecraft:light[level=15]
setblock 442 204 310 minecraft:light[level=15]
setblock 446 204 316 minecraft:gray_concrete
fill 449 204 313 449 205 313 minecraft:black_concrete
setblock 450 204 276 minecraft:gray_concrete
setblock 450 204 278 minecraft:light[level=15]
setblock 450 204 286 minecraft:light[level=15]
setblock 450 204 294 minecraft:light[level=15]
setblock 450 204 302 minecraft:light[level=15]
setblock 450 204 310 minecraft:light[level=15]
fill 454 204 313 454 205 313 minecraft:black_concrete
setblock 456 204 316 minecraft:gray_concrete
setblock 458 204 278 minecraft:light[level=15]
setblock 458 204 286 minecraft:light[level=15]
setblock 458 204 294 minecraft:light[level=15]
setblock 458 204 302 minecraft:light[level=15]
setblock 458 204 310 minecraft:black_concrete
fill 458 204 312 458 204 313 minecraft:black_concrete
fill 459 204 309 461 204 309 minecraft:black_concrete
fill 459 204 313 462 204 314 minecraft:black_concrete
setblock 460 204 276 minecraft:gray_concrete
fill 462 204 310 462 204 312 minecraft:black_concrete
setblock 464 204 282 minecraft:gray_concrete
setblock 464 204 292 minecraft:gray_concrete
setblock 464 204 302 minecraft:gray_concrete
setblock 464 204 312 minecraft:gray_concrete
fill 425 205 282 425 206 282 minecraft:black_concrete
fill 425 205 312 425 206 312 minecraft:black_concrete
fill 431 205 314 431 206 314 minecraft:black_concrete
fill 435 205 277 435 206 277 minecraft:black_concrete
fill 449 205 314 449 206 314 minecraft:black_concrete
fill 454 205 314 454 206 314 minecraft:black_concrete
fill 455 205 303 456 206 304 minecraft:yellow_concrete
fill 457 205 304 457 206 304 minecraft:yellow_concrete
fill 459 205 313 461 208 313 minecraft:gray_concrete
fill 462 205 312 462 211 312 minecraft:gray_concrete
setblock 424 206 282 minecraft:black_concrete
setblock 424 206 312 minecraft:black_concrete
fill 426 206 292 427 206 300 minecraft:gray_concrete
fill 427 206 289 428 206 291 minecraft:gray_concrete
fill 427 206 301 428 206 303 minecraft:gray_concrete
fill 428 206 287 429 207 288 minecraft:gray_concrete
fill 428 206 304 429 207 305 minecraft:gray_concrete
fill 429 206 286 430 207 286 minecraft:gray_concrete
fill 429 206 289 429 207 289 minecraft:gray_concrete
fill 429 206 303 429 207 303 minecraft:gray_concrete
fill 429 206 306 430 207 306 minecraft:gray_concrete
fill 430 206 284 431 207 285 minecraft:gray_concrete
fill 430 206 287 430 207 287 minecraft:gray_concrete
fill 430 206 305 430 207 305 minecraft:gray_concrete
fill 430 206 307 431 207 308 minecraft:gray_concrete
fill 431 206 283 433 207 283 minecraft:gray_concrete
fill 431 206 309 433 207 309 minecraft:gray_concrete
fill 431 206 315 431 207 315 minecraft:black_concrete
fill 432 206 282 434 207 282 minecraft:gray_concrete
fill 432 206 284 432 207 284 minecraft:gray_concrete
fill 432 206 308 432 207 308 minecraft:gray_concrete
fill 432 206 310 435 207 310 minecraft:gray_concrete
fill 434 206 281 437 207 281 minecraft:gray_concrete
fill 434 206 311 437 207 311 minecraft:gray_concrete
setblock 435 206 276 minecraft:black_concrete
fill 435 206 280 439 207 280 minecraft:gray_concrete
fill 435 206 312 439 207 312 minecraft:gray_concrete
fill 437 206 279 443 206 279 minecraft:gray_concrete
fill 437 206 313 451 206 313 minecraft:gray_concrete
fill 440 206 278 444 207 278 minecraft:gray_concrete
fill 440 206 314 448 207 314 minecraft:gray_concrete
fill 446 206 278 448 207 278 minecraft:gray_concrete
fill 447 206 279 451 206 279 minecraft:gray_concrete
fill 449 206 280 453 207 280 minecraft:gray_concrete
fill 449 206 312 453 207 312 minecraft:gray_concrete
fill 449 206 315 449 207 315 minecraft:black_concrete
fill 451 206 281 454 207 281 minecraft:gray_concrete
fill 451 206 311 454 207 311 minecraft:gray_concrete
fill 453 206 282 453 207 282 minecraft:gray_concrete
fill 453 206 310 456 207 310 minecraft:gray_concrete
fill 454 206 315 454 207 315 minecraft:black_concrete
fill 455 206 309 457 207 309 minecraft:gray_concrete
fill 456 206 282 456 207 284 minecraft:gray_concrete
fill 456 206 308 458 207 308 minecraft:gray_concrete
fill 457 206 283 457 207 285 minecraft:gray_concrete
fill 457 206 307 458 207 307 minecraft:gray_concrete
fill 458 206 284 458 207 287 minecraft:gray_concrete
fill 458 206 305 459 207 306 minecraft:gray_concrete
fill 459 206 286 459 207 289 minecraft:gray_concrete
fill 459 206 303 460 207 304 minecraft:gray_concrete
fill 460 206 287 460 207 291 minecraft:gray_concrete
fill 460 206 301 461 207 302 minecraft:gray_concrete
fill 460 206 305 460 207 305 minecraft:gray_concrete
fill 461 206 289 461 206 300 minecraft:gray_concrete
setblock 461 206 303 minecraft:gray_concrete
fill 462 206 292 462 207 300 minecraft:gray_concrete
fill 424 207 280 424 207 283 minecraft:gray_concrete
fill 424 207 290 424 207 293 minecraft:gray_concrete
fill 424 207 300 424 207 303 minecraft:gray_concrete
fill 424 207 310 424 207 313 minecraft:gray_concrete
fill 425 207 276 428 207 276 minecraft:gray_concrete
fill 426 207 292 426 207 300 minecraft:gray_concrete
setblock 427 207 283 minecraft:sea_lantern
setblock 427 207 289 minecraft:sea_lantern
fill 427 207 290 427 207 294 minecraft:gray_concrete
setblock 427 207 295 minecraft:sea_lantern
fill 427 207 296 427 207 300 minecraft:gray_concrete
setblock 427 207 301 minecraft:sea_lantern
fill 427 207 302 428 207 303 minecraft:gray_concrete
setblock 427 207 307 minecraft:sea_lantern
setblock 427 207 313 minecraft:sea_lantern
fill 428 207 289 428 207 291 minecraft:gray_concrete
setblock 428 207 301 minecraft:gray_concrete
fill 428 207 316 431 207 316 minecraft:gray_concrete
setblock 431 207 279 minecraft:sea_lantern
setblock 433 207 313 minecraft:sea_lantern
fill 434 207 295 435 208 295 minecraft:yellow_concrete
fill 435 207 276 438 207 276 minecraft:gray_concrete
setblock 437 207 279 minecraft:sea_lantern
fill 437 207 313 438 208 313 minecraft:gray_concrete
fill 438 207 279 442 207 279 minecraft:gray_concrete
fill 438 207 316 441 207 316 minecraft:gray_concrete
fill 439 207 313 439 208 313 minecraft:sea_lantern
fill 440 207 313 444 207 313 minecraft:gray_concrete
setblock 443 207 279 minecraft:sea_lantern
fill 445 207 276 448 207 276 minecraft:gray_concrete
setblock 445 207 313 minecraft:sea_lantern
fill 446 207 313 450 207 313 minecraft:gray_concrete
fill 447 207 279 448 208 279 minecraft:gray_concrete
fill 448 207 316 451 207 316 minecraft:gray_concrete
setblock 449 207 279 minecraft:sea_lantern
fill 450 207 279 451 208 279 minecraft:gray_concrete
fill 451 207 313 451 208 313 minecraft:sea_lantern
fill 455 207 276 458 207 276 minecraft:gray_concrete
setblock 455 207 279 minecraft:sea_lantern
setblock 457 207 313 minecraft:sea_lantern
fill 458 207 316 461 207 316 minecraft:gray_concrete
setblock 461 207 279 minecraft:sea_lantern
setblock 461 207 285 minecraft:sea_lantern
fill 461 207 289 461 208 290 minecraft:gray_concrete
setblock 461 207 291 minecraft:sea_lantern
fill 461 207 292 461 207 296 minecraft:gray_concrete
setblock 461 207 297 minecraft:sea_lantern
fill 461 207 298 461 207 300 minecraft:gray_concrete
setblock 461 207 303 minecraft:sea_lantern
setblock 461 207 309 minecraft:sea_lantern
fill 464 207 277 464 207 280 minecraft:gray_concrete
fill 464 207 287 464 207 290 minecraft:gray_concrete
fill 464 207 297 464 207 300 minecraft:gray_concrete
fill 464 207 307 464 207 310 minecraft:gray_concrete
setblock 424 208 276 minecraft:gray_concrete
fill 424 208 278 424 208 279 minecraft:gray_concrete
fill 424 208 281 424 208 282 minecraft:gray_concrete
fill 424 208 284 424 208 285 minecraft:gray_concrete
setblock 424 208 288 minecraft:gray_concrete
fill 424 208 290 424 208 291 minecraft:gray_concrete
fill 424 208 293 424 208 294 minecraft:gray_concrete
fill 424 208 296 425 208 296 minecraft:gray_concrete
fill 424 208 299 424 208 300 minecraft:gray_concrete
fill 424 208 302 424 208 303 minecraft:gray_concrete
fill 424 208 305 424 208 306 minecraft:gray_concrete
fill 424 208 308 424 208 309 minecraft:gray_concrete
fill 424 208 311 424 208 312 minecraft:gray_concrete
fill 424 208 314 424 208 315 minecraft:gray_concrete
fill 425 208 277 425 208 278 minecraft:gray_concrete
fill 425 208 280 425 208 281 minecraft:gray_concrete
fill 425 208 283 425 208 284 minecraft:gray_concrete
fill 425 208 286 425 208 287 minecraft:gray_concrete
fill 425 208 289 425 208 290 minecraft:gray_concrete
fill 425 208 292 425 208 293 minecraft:gray_concrete
fill 425 208 295 426 208 295 minecraft:gray_concrete
fill 425 208 298 425 208 299 minecraft:gray_concrete
fill 425 208 301 425 208 302 minecraft:gray_concrete
fill 425 208 304 425 208 305 minecraft:gray_concrete
fill 425 208 307 425 208 308 minecraft:gray_concrete
fill 425 208 310 425 208 311 minecraft:gray_concrete
fill 425 208 313 425 208 314 minecraft:gray_concrete
fill 426 208 276 426 208 277 minecraft:gray_concrete
setblock 426 208 278 minecraft:light[level=12]
fill 426 208 279 426 208 280 minecraft:gray_concrete
fill 426 208 282 426 208 283 minecraft:gray_concrete
fill 426 208 285 426 208 286 minecraft:gray_concrete
fill 426 208 288 426 208 289 minecraft:gray_concrete
fill 426 208 291 426 208 292 minecraft:gray_concrete
fill 426 208 294 427 208 294 minecraft:gray_concrete
fill 426 208 297 426 208 298 minecraft:gray_concrete
setblock 426 208 299 minecraft:light[level=12]
fill 426 208 300 426 208 301 minecraft:gray_concrete
fill 426 208 303 426 208 304 minecraft:gray_concrete
fill 426 208 306 426 208 307 minecraft:gray_concrete
fill 426 208 309 426 208 310 minecraft:gray_concrete
fill 426 208 312 426 208 313 minecraft:gray_concrete
fill 426 208 315 426 208 316 minecraft:gray_concrete
setblock 427 208 276 minecraft:gray_concrete
fill 427 208 278 427 208 279 minecraft:gray_concrete
fill 427 208 281 427 208 282 minecraft:gray_concrete
fill 427 208 284 427 208 285 minecraft:gray_concrete
fill 427 208 287 427 208 288 minecraft:gray_concrete
fill 427 208 290 427 208 291 minecraft:gray_concrete
fill 427 208 293 427 210 293 minecraft:gray_concrete
fill 427 208 296 427 208 297 minecraft:gray_concrete
fill 427 208 299 427 208 300 minecraft:gray_concrete
fill 427 208 302 427 208 303 minecraft:gray_concrete
fill 427 208 305 427 208 306 minecraft:gray_concrete
fill 427 208 308 427 208 309 minecraft:gray_concrete
fill 427 208 311 427 208 312 minecraft:gray_concrete
fill 427 208 314 427 208 315 minecraft:gray_concrete
fill 428 208 277 428 208 278 minecraft:gray_concrete
fill 428 208 304 428 208 305 minecraft:sea_lantern
fill 428 208 313 428 208 314 minecraft:gray_concrete
fill 428 208 316 429 208 316 minecraft:gray_concrete
fill 429 208 276 429 208 277 minecraft:gray_concrete
fill 429 208 279 430 208 279 minecraft:gray_concrete
setblock 429 208 306 minecraft:sea_lantern
setblock 429 208 313 minecraft:gray_concrete
fill 429 208 315 430 208 315 minecraft:gray_concrete
setblock 430 208 276 minecraft:gray_concrete
fill 430 208 278 431 208 278 minecraft:gray_concrete
fill 430 208 307 430 208 308 minecraft:sea_lantern
fill 430 208 314 431 208 314 minecraft:gray_concrete
fill 431 208 277 432 208 277 minecraft:gray_concrete
fill 431 208 292 433 208 292 minecraft:glowstone
fill 431 208 308 431 208 309 minecraft:sea_lantern
fill 431 208 313 432 208 313 minecraft:gray_concrete
fill 431 208 316 432 208 316 minecraft:gray_concrete
fill 432 208 276 433 208 276 minecraft:gray_concrete
fill 432 208 279 433 208 279 minecraft:gray_concrete
setblock 432 208 291 minecraft:glowstone
setblock 432 208 293 minecraft:glowstone
fill 432 208 309 432 208 310 minecraft:sea_lantern
fill 432 208 315 433 208 315 minecraft:gray_concrete
fill 433 208 278 434 208 278 minecraft:gray_concrete
setblock 433 208 285 minecraft:light[level=12]
setblock 433 208 299 minecraft:light[level=12]
setblock 433 208 306 minecraft:light[level=12]
setblock 433 208 310 minecraft:sea_lantern
setblock 433 208 313 minecraft:light[level=12]
fill 433 208 314 434 208 314 minecraft:gray_concrete
fill 434 208 277 435 208 277 minecraft:gray_concrete
setblock 434 208 311 minecraft:sea_lantern
fill 434 208 313 435 208 313 minecraft:gray_concrete
setblock 434 208 316 minecraft:gray_concrete
fill 435 208 276 436 208 276 minecraft:gray_concrete
fill 435 208 279 436 208 279 minecraft:gray_concrete
fill 435 208 282 436 208 283 minecraft:glowstone
fill 435 208 301 436 208 302 minecraft:glowstone
fill 435 208 312 436 208 312 minecraft:sea_lantern
fill 435 208 315 436 208 315 minecraft:gray_concrete
fill 436 208 278 437 208 278 minecraft:gray_concrete
setblock 436 208 284 minecraft:glowstone
setblock 436 208 300 minecraft:glowstone
fill 436 208 314 437 208 314 minecraft:gray_concrete
fill 437 208 277 438 208 277 minecraft:gray_concrete
setblock 437 208 283 minecraft:glowstone
setblock 437 208 301 minecraft:glowstone
fill 437 208 316 438 208 316 minecraft:gray_concrete
fill 438 208 276 439 208 276 minecraft:gray_concrete
fill 438 208 279 439 208 279 minecraft:gray_concrete
fill 438 208 315 439 208 315 minecraft:gray_concrete
fill 439 208 278 440 208 278 minecraft:gray_concrete
fill 439 208 314 440 208 314 minecraft:gray_concrete
fill 440 208 277 441 208 277 minecraft:gray_concrete
setblock 440 208 285 minecraft:light[level=12]
setblock 440 208 292 minecraft:light[level=12]
setblock 440 208 299 minecraft:light[level=12]
setblock 440 208 306 minecraft:light[level=12]
fill 440 208 313 441 208 313 minecraft:gray_concrete
fill 440 208 316 441 208 316 minecraft:gray_concrete
fill 441 208 279 442 208 279 minecraft:gray_concrete
setblock 441 208 314 minecraft:sea_lantern
fill 441 208 315 442 208 315 minecraft:gray_concrete
setblock 442 208 276 minecraft:gray_concrete
fill 442 208 278 443 208 278 minecraft:gray_concrete
fill 442 208 314 443 208 314 minecraft:gray_concrete
fill 443 208 277 444 208 277 minecraft:gray_concrete
fill 443 208 313 444 208 313 minecraft:gray_concrete
fill 443 208 316 444 208 316 minecraft:gray_concrete
fill 444 208 276 445 208 276 minecraft:gray_concrete
fill 444 208 279 446 208 279 minecraft:glowstone
fill 444 208 305 446 208 305 minecraft:glowstone
setblock 444 208 314 minecraft:sea_lantern
fill 444 208 315 445 208 315 minecraft:gray_concrete
setblock 445 208 278 minecraft:glowstone
setblock 445 208 280 minecraft:glowstone
setblock 445 208 304 minecraft:glowstone
setblock 445 208 306 minecraft:glowstone
fill 445 208 314 446 208 314 minecraft:gray_concrete
fill 446 208 277 446 208 278 minecraft:gray_concrete
fill 446 208 313 447 208 313 minecraft:gray_concrete
fill 446 208 316 447 208 316 minecraft:gray_concrete
fill 447 208 276 447 208 277 minecraft:gray_concrete
setblock 447 208 278 minecraft:light[level=12]
setblock 447 208 285 minecraft:light[level=12]
setblock 447 208 292 minecraft:light[level=12]
setblock 447 208 299 minecraft:light[level=12]
setblock 447 208 306 minecraft:light[level=12]
setblock 447 208 314 minecraft:sea_lantern
fill 447 208 315 448 208 315 minecraft:gray_concrete
setblock 448 208 276 minecraft:gray_concrete
fill 448 208 278 449 208 278 minecraft:gray_concrete
fill 448 208 314 449 208 314 minecraft:gray_concrete
fill 449 208 277 450 208 277 minecraft:gray_concrete
fill 449 208 313 450 208 313 minecraft:gray_concrete
fill 449 208 316 450 208 316 minecraft:gray_concrete
setblock 450 208 276 minecraft:gray_concrete
fill 450 208 315 451 208 315 minecraft:gray_concrete
fill 451 208 278 452 208 278 minecraft:gray_concrete
fill 451 208 299 464 208 299 minecraft:gray_concrete
fill 451 208 314 452 208 314 minecraft:gray_concrete
fill 452 208 277 453 208 277 minecraft:gray_concrete
fill 452 208 281 464 208 281 minecraft:gray_concrete
fill 452 208 312 453 208 312 minecraft:sea_lantern
fill 452 208 313 453 208 313 minecraft:gray_concrete
fill 452 208 316 453 208 316 minecraft:gray_concrete
fill 453 208 276 454 208 276 minecraft:gray_concrete
fill 453 208 279 454 208 279 minecraft:gray_concrete
fill 453 208 283 455 208 283 minecraft:glowstone
fill 453 208 301 455 208 301 minecraft:glowstone
fill 453 208 315 454 208 315 minecraft:gray_concrete
fill 454 208 278 455 208 278 minecraft:gray_concrete
fill 454 208 282 455 208 282 minecraft:glowstone
setblock 454 208 284 minecraft:glowstone
setblock 454 208 285 minecraft:light[level=12]
fill 454 208 287 464 208 287 minecraft:gray_concrete
setblock 454 208 292 minecraft:light[level=12]
setblock 454 208 300 minecraft:glowstone
fill 454 208 302 455 208 302 minecraft:glowstone
setblock 454 208 306 minecraft:light[level=12]
setblock 454 208 311 minecraft:sea_lantern
setblock 454 208 313 minecraft:light[level=12]
fill 454 208 314 455 208 314 minecraft:gray_concrete
fill 455 208 277 456 208 277 minecraft:gray_concrete
fill 455 208 310 456 208 310 minecraft:sea_lantern
fill 455 208 313 456 208 313 minecraft:gray_concrete
fill 456 208 276 457 208 276 minecraft:gray_concrete
fill 456 208 279 457 208 279 minecraft:gray_concrete
setblock 456 208 309 minecraft:sea_lantern
fill 456 208 315 456 208 316 minecraft:gray_concrete
fill 457 208 278 458 208 278 minecraft:gray_concrete
fill 457 208 292 459 208 292 minecraft:glowstone
fill 457 208 314 457 208 315 minecraft:gray_concrete
fill 458 208 277 459 208 277 minecraft:gray_concrete
setblock 458 208 291 minecraft:glowstone
setblock 458 208 293 minecraft:glowstone
fill 458 208 313 458 208 314 minecraft:gray_concrete
fill 458 208 316 459 208 316 minecraft:gray_concrete
fill 459 208 276 460 208 276 minecraft:gray_concrete
fill 459 208 279 460 208 279 minecraft:gray_concrete
fill 459 208 293 463 209 293 minecraft:gray_concrete
fill 459 208 315 460 208 315 minecraft:gray_concrete
fill 460 208 278 461 208 278 minecraft:gray_concrete
fill 460 208 314 461 208 314 minecraft:gray_concrete
fill 461 208 277 462 208 277 minecraft:gray_concrete
fill 461 208 280 462 208 280 minecraft:gray_concrete
fill 461 208 283 461 208 284 minecraft:gray_concrete
setblock 461 208 285 minecraft:light[level=12]
fill 461 208 286 462 208 286 minecraft:gray_concrete
fill 461 208 292 462 208 292 minecraft:gray_concrete
fill 461 208 295 461 208 296 minecraft:gray_concrete
fill 461 208 298 462 208 298 minecraft:gray_concrete
fill 461 208 301 461 208 302 minecraft:gray_concrete
fill 461 208 304 461 208 305 minecraft:gray_concrete
setblock 461 208 306 minecraft:light[level=12]
fill 461 208 307 461 208 308 minecraft:gray_concrete
fill 461 208 316 462 208 316 minecraft:gray_concrete
fill 462 208 276 463 208 276 minecraft:gray_concrete
fill 462 208 279 463 208 279 minecraft:gray_concrete
fill 462 208 282 462 208 283 minecraft:gray_concrete
fill 462 208 285 463 208 285 minecraft:gray_concrete
fill 462 208 288 462 208 289 minecraft:gray_concrete
fill 462 208 291 463 208 291 minecraft:gray_concrete
fill 462 208 294 462 208 295 minecraft:gray_concrete
fill 462 208 297 463 208 297 minecraft:gray_concrete
fill 462 208 300 462 208 301 minecraft:gray_concrete
fill 462 208 303 462 208 304 minecraft:gray_concrete
fill 462 208 306 462 208 307 minecraft:gray_concrete
fill 462 208 309 462 208 310 minecraft:gray_concrete
setblock 462 208 313 minecraft:gray_concrete
fill 462 208 315 463 208 315 minecraft:gray_concrete
fill 463 208 278 464 208 278 minecraft:gray_concrete
setblock 463 208 282 minecraft:gray_concrete
fill 463 208 284 464 208 284 minecraft:gray_concrete
setblock 463 208 288 minecraft:gray_concrete
fill 463 208 290 464 208 290 minecraft:gray_concrete
setblock 463 208 294 minecraft:gray_concrete
fill 463 208 296 464 208 296 minecraft:gray_concrete
setblock 463 208 300 minecraft:gray_concrete
fill 463 208 302 463 208 303 minecraft:gray_concrete
fill 463 208 305 463 208 306 minecraft:gray_concrete
fill 463 208 308 463 208 309 minecraft:gray_concrete
fill 463 208 311 463 208 312 minecraft:gray_concrete
fill 463 208 314 464 208 314 minecraft:gray_concrete
setblock 464 208 277 minecraft:gray_concrete
setblock 464 208 280 minecraft:gray_concrete
setblock 464 208 286 minecraft:gray_concrete
setblock 464 208 289 minecraft:gray_concrete
setblock 464 208 292 minecraft:gray_concrete
setblock 464 208 295 minecraft:gray_concrete
setblock 464 208 298 minecraft:gray_concrete
fill 464 208 301 464 208 302 minecraft:gray_concrete
fill 464 208 304 464 208 305 minecraft:gray_concrete
fill 464 208 307 464 208 308 minecraft:gray_concrete
fill 464 208 310 464 208 311 minecraft:gray_concrete
setblock 464 208 316 minecraft:gray_concrete
fill 424 209 281 458 209 281 minecraft:gray_concrete
fill 424 209 293 426 210 293 minecraft:gray_concrete
fill 424 209 299 456 209 299 minecraft:gray_concrete
fill 424 209 305 463 210 305 minecraft:gray_concrete
fill 424 209 311 427 210 311 minecraft:gray_concrete
fill 425 209 287 460 209 287 minecraft:gray_concrete
fill 427 209 279 427 209 280 minecraft:magenta_concrete
fill 427 209 282 427 209 286 minecraft:magenta_concrete
fill 427 209 288 427 209 292 minecraft:magenta_concrete
fill 427 209 294 427 209 298 minecraft:magenta_concrete
fill 427 209 300 427 209 304 minecraft:magenta_concrete
fill 427 209 306 427 209 310 minecraft:magenta_concrete
fill 427 209 312 427 209 313 minecraft:magenta_concrete
fill 428 209 279 461 209 279 minecraft:magenta_concrete
fill 428 209 293 441 209 293 minecraft:gray_concrete
fill 428 209 313 461 209 313 minecraft:magenta_concrete
fill 433 209 300 433 210 300 minecraft:magenta_concrete
fill 449 209 293 458 209 293 minecraft:gray_concrete
fill 458 209 311 460 209 311 minecraft:gray_concrete
fill 459 209 310 460 209 310 minecraft:gray_concrete
fill 459 209 312 460 209 312 minecraft:gray_concrete
fill 461 209 280 461 209 292 minecraft:magenta_concrete
fill 461 209 294 461 209 304 minecraft:magenta_concrete
fill 461 209 306 461 209 312 minecraft:magenta_concrete
setblock 424 210 278 minecraft:gray_concrete
fill 424 210 281 426 210 281 minecraft:gray_concrete
setblock 424 210 288 minecraft:gray_concrete
fill 424 210 298 424 210 299 minecraft:gray_concrete
setblock 424 210 308 minecraft:gray_concrete
fill 425 210 287 426 210 287 minecraft:gray_concrete
fill 425 210 299 426 210 299 minecraft:gray_concrete
setblock 426 210 316 minecraft:gray_concrete
fill 428 210 311 458 210 311 minecraft:gray_concrete
setblock 430 210 276 minecraft:gray_concrete
setblock 436 210 316 minecraft:gray_concrete
setblock 440 210 276 minecraft:gray_concrete
setblock 446 210 316 minecraft:gray_concrete
setblock 450 210 276 minecraft:gray_concrete
setblock 456 210 316 minecraft:gray_concrete
fill 458 210 313 459 210 315 minecraft:iron_block
fill 459 210 308 459 211 312 minecraft:iron_block
setblock 460 210 276 minecraft:gray_concrete
fill 460 210 310 461 211 313 minecraft:gray_concrete
fill 462 210 311 463 210 311 minecraft:gray_concrete
setblock 464 210 282 minecraft:gray_concrete
setblock 464 210 292 minecraft:gray_concrete
setblock 464 210 302 minecraft:gray_concrete
setblock 464 210 312 minecraft:gray_concrete
fill 423 211 281 423 211 284 minecraft:sea_lantern
fill 423 211 291 423 211 294 minecraft:sea_lantern
fill 423 211 301 423 211 304 minecraft:sea_lantern
fill 423 211 311 423 211 314 minecraft:sea_lantern
fill 426 211 275 429 211 275 minecraft:sea_lantern
fill 427 211 317 430 211 317 minecraft:sea_lantern
fill 429 211 276 429 212 278 minecraft:iron_block
fill 435 211 276 435 212 279 minecraft:iron_block
fill 436 211 275 439 211 275 minecraft:sea_lantern
fill 437 211 317 440 211 317 minecraft:sea_lantern
fill 441 211 277 441 211 316 minecraft:iron_block
fill 446 211 275 449 211 275 minecraft:sea_lantern
fill 447 211 276 447 212 278 minecraft:iron_block
fill 447 211 317 450 211 317 minecraft:sea_lantern
fill 453 211 276 453 212 312 minecraft:iron_block
fill 456 211 275 459 211 275 minecraft:sea_lantern
fill 457 211 317 460 211 317 minecraft:sea_lantern
fill 458 211 311 458 264 311 minecraft:gray_concrete
fill 458 211 313 458 211 315 minecraft:iron_block
fill 459 211 276 459 211 307 minecraft:iron_block
fill 459 211 313 459 211 314 minecraft:iron_block
fill 465 211 276 465 211 279 minecraft:sea_lantern
fill 465 211 286 465 211 289 minecraft:sea_lantern
fill 465 211 296 465 211 299 minecraft:sea_lantern
fill 465 211 306 465 211 309 minecraft:sea_lantern
setblock 465 211 316 minecraft:sea_lantern
fill 423 212 281 423 219 284 minecraft:black_concrete
fill 423 212 291 423 219 294 minecraft:black_concrete
fill 423 212 301 423 219 304 minecraft:black_concrete
fill 423 212 311 423 219 314 minecraft:black_concrete
fill 426 212 275 429 219 275 minecraft:black_concrete
setblock 426 212 278 minecraft:light[level=15]
setblock 426 212 286 minecraft:light[level=15]
setblock 426 212 294 minecraft:light[level=15]
setblock 426 212 302 minecraft:light[level=15]
setblock 426 212 310 minecraft:light[level=15]
fill 427 212 317 430 219 317 minecraft:black_concrete
fill 429 212 279 429 212 308 minecraft:iron_block
setblock 434 212 278 minecraft:light[level=15]
setblock 434 212 286 minecraft:light[level=15]
setblock 434 212 294 minecraft:light[level=15]
setblock 434 212 302 minecraft:light[level=15]
setblock 434 212 310 minecraft:light[level=15]
fill 435 212 280 435 212 315 minecraft:iron_block
fill 436 212 275 439 219 275 minecraft:black_concrete
fill 437 212 317 440 219 317 minecraft:black_concrete
fill 441 212 277 441 212 280 minecraft:iron_block
setblock 442 212 278 minecraft:light[level=15]
setblock 442 212 286 minecraft:light[level=15]
setblock 442 212 294 minecraft:light[level=15]
setblock 442 212 302 minecraft:light[level=15]
setblock 442 212 310 minecraft:light[level=15]
fill 446 212 275 449 219 275 minecraft:black_concrete
fill 447 212 279 447 212 289 minecraft:iron_block
fill 447 212 295 447 212 310 minecraft:iron_block
fill 447 212 317 450 219 317 minecraft:black_concrete
setblock 450 212 278 minecraft:light[level=15]
setblock 450 212 286 minecraft:light[level=15]
setblock 450 212 294 minecraft:light[level=15]
setblock 450 212 302 minecraft:light[level=15]
setblock 450 212 310 minecraft:light[level=15]
fill 453 212 313 453 212 315 minecraft:iron_block
fill 456 212 275 459 219 275 minecraft:black_concrete
fill 457 212 317 460 219 317 minecraft:black_concrete
setblock 458 212 278 minecraft:light[level=15]
setblock 458 212 286 minecraft:light[level=15]
setblock 458 212 294 minecraft:light[level=15]
setblock 458 212 302 minecraft:light[level=15]
setblock 458 212 310 minecraft:black_concrete
fill 458 212 312 458 212 313 minecraft:black_concrete
fill 459 212 276 459 212 279 minecraft:iron_block
fill 459 212 309 461 212 309 minecraft:black_concrete
fill 459 212 310 461 264 312 minecraft:gray_concrete
fill 459 212 313 462 212 314 minecraft:black_concrete
fill 462 212 310 462 212 312 minecraft:black_concrete
fill 465 212 276 465 219 279 minecraft:black_concrete
fill 465 212 286 465 219 289 minecraft:black_concrete
fill 465 212 296 465 219 299 minecraft:black_concrete
fill 465 212 306 465 219 309 minecraft:black_concrete
fill 465 212 316 465 219 316 minecraft:black_concrete
fill 429 213 303 429 213 316 minecraft:iron_block
fill 435 213 310 435 213 315 minecraft:iron_block
fill 447 213 305 447 213 316 minecraft:iron_block
fill 459 213 313 461 219 313 minecraft:gray_concrete
fill 462 213 312 462 219 312 minecraft:gray_concrete
setblock 426 214 278 minecraft:light[level=12]
setblock 426 214 285 minecraft:light[level=12]
setblock 426 214 292 minecraft:light[level=12]
setblock 426 214 299 minecraft:light[level=12]
setblock 426 214 306 minecraft:light[level=12]
setblock 426 214 313 minecraft:light[level=12]
setblock 433 214 278 minecraft:light[level=12]
setblock 433 214 285 minecraft:light[level=12]
setblock 433 214 292 minecraft:light[level=12]
setblock 433 214 299 minecraft:light[level=12]
setblock 433 214 306 minecraft:light[level=12]
setblock 433 214 313 minecraft:light[level=12]
setblock 440 214 278 minecraft:light[level=12]
setblock 440 214 285 minecraft:light[level=12]
setblock 440 214 292 minecraft:light[level=12]
setblock 440 214 299 minecraft:light[level=12]
setblock 440 214 306 minecraft:light[level=12]
setblock 440 214 313 minecraft:light[level=12]
setblock 447 214 278 minecraft:light[level=12]
setblock 447 214 285 minecraft:light[level=12]
setblock 447 214 292 minecraft:light[level=12]
setblock 447 214 299 minecraft:light[level=12]
setblock 447 214 306 minecraft:light[level=12]
setblock 447 214 313 minecraft:light[level=12]
setblock 454 214 278 minecraft:light[level=12]
setblock 454 214 285 minecraft:light[level=12]
setblock 454 214 292 minecraft:light[level=12]
setblock 454 214 299 minecraft:light[level=12]
setblock 454 214 306 minecraft:light[level=12]
setblock 454 214 313 minecraft:light[level=12]
setblock 461 214 278 minecraft:light[level=12]
setblock 461 214 285 minecraft:light[level=12]
setblock 461 214 292 minecraft:light[level=12]
setblock 461 214 299 minecraft:light[level=12]
setblock 461 214 306 minecraft:light[level=12]
fill 462 214 305 463 214 305 minecraft:lime_stained_glass
fill 433 215 285 433 216 285 minecraft:lime_concrete
setblock 424 216 278 minecraft:gray_concrete
fill 424 216 280 424 216 283 minecraft:gray_concrete
setblock 424 216 288 minecraft:gray_concrete
fill 424 216 290 424 216 293 minecraft:gray_concrete
setblock 424 216 298 minecraft:gray_concrete
fill 424 216 300 424 216 303 minecraft:gray_concrete
setblock 424 216 308 minecraft:gray_concrete
fill 424 216 310 424 216 313 minecraft:gray_concrete
fill 425 216 276 428 216 276 minecraft:gray_concrete
setblock 426 216 316 minecraft:gray_concrete
fill 428 216 316 431 216 316 minecraft:gray_concrete
setblock 430 216 276 minecraft:gray_concrete
fill 435 216 276 438 216 276 minecraft:gray_concrete
setblock 436 216 316 minecraft:gray_concrete
fill 438 216 316 441 216 316 minecraft:gray_concrete
setblock 440 216 276 minecraft:gray_concrete
fill 445 216 276 448 216 276 minecraft:gray_concrete
setblock 446 216 316 minecraft:gray_concrete
fill 448 216 316 451 216 316 minecraft:gray_concrete
setblock 450 216 276 minecraft:gray_concrete
fill 455 216 276 458 216 276 minecraft:gray_concrete
setblock 456 216 316 minecraft:gray_concrete
fill 458 216 316 461 216 316 minecraft:gray_concrete
setblock 460 216 276 minecraft:gray_concrete
fill 464 216 277 464 216 280 minecraft:gray_concrete
setblock 464 216 282 minecraft:gray_concrete
fill 464 216 287 464 216 290 minecraft:gray_concrete
setblock 464 216 292 minecraft:gray_concrete
fill 464 216 297 464 216 300 minecraft:gray_concrete
setblock 464 216 302 minecraft:gray_concrete
fill 464 216 307 464 216 310 minecraft:gray_concrete
setblock 464 216 312 minecraft:gray_concrete
fill 431 217 313 431 218 315 minecraft:iron_block
fill 462 219 286 463 219 286 minecraft:lime_stained_glass
fill 423 220 281 423 220 284 minecraft:sea_lantern
fill 423 220 291 423 220 294 minecraft:sea_lantern
fill 423 220 301 423 220 304 minecraft:sea_lantern
fill 423 220 311 423 220 314 minecraft:sea_lantern
fill 426 220 275 429 220 275 minecraft:sea_lantern
setblock 426 220 278 minecraft:light[level=15]
setblock 426 220 285 minecraft:light[level=12]
setblock 426 220 286 minecraft:light[level=15]
setblock 426 220 292 minecraft:light[level=12]
setblock 426 220 294 minecraft:light[level=15]
setblock 426 220 299 minecraft:light[level=12]
setblock 426 220 302 minecraft:light[level=15]
setblock 426 220 306 minecraft:light[level=12]
setblock 426 220 310 minecraft:light[level=15]
setblock 426 220 313 minecraft:light[level=12]
fill 427 220 317 430 220 317 minecraft:sea_lantern
setblock 433 220 278 minecraft:light[level=12]
setblock 433 220 285 minecraft:light[level=12]
setblock 433 220 292 minecraft:light[level=12]
setblock 433 220 299 minecraft:light[level=12]
setblock 433 220 306 minecraft:light[level=12]
setblock 433 220 313 minecraft:light[level=12]
setblock 434 220 278 minecraft:light[level=15]
setblock 434 220 286 minecraft:light[level=15]
setblock 434 220 294 minecraft:light[level=15]
setblock 434 220 302 minecraft:light[level=15]
setblock 434 220 310 minecraft:light[level=15]
fill 436 220 275 439 220 275 minecraft:sea_lantern
fill 437 220 317 440 220 317 minecraft:sea_lantern
setblock 440 220 278 minecraft:light[level=12]
setblock 440 220 285 minecraft:light[level=12]
setblock 440 220 292 minecraft:light[level=12]
setblock 440 220 299 minecraft:light[level=12]
setblock 440 220 306 minecraft:light[level=12]
setblock 440 220 313 minecraft:light[level=12]
setblock 442 220 278 minecraft:light[level=15]
setblock 442 220 286 minecraft:light[level=15]
setblock 442 220 294 minecraft:light[level=15]
setblock 442 220 302 minecraft:light[level=15]
setblock 442 220 310 minecraft:light[level=15]
fill 446 220 275 449 220 275 minecraft:sea_lantern
setblock 447 220 278 minecraft:light[level=12]
setblock 447 220 285 minecraft:light[level=12]
setblock 447 220 292 minecraft:light[level=12]
setblock 447 220 299 minecraft:light[level=12]
setblock 447 220 306 minecraft:light[level=12]
setblock 447 220 313 minecraft:light[level=12]
fill 447 220 317 450 220 317 minecraft:sea_lantern
setblock 450 220 278 minecraft:light[level=15]
setblock 450 220 286 minecraft:light[level=15]
setblock 450 220 294 minecraft:light[level=15]
setblock 450 220 302 minecraft:light[level=15]
setblock 450 220 310 minecraft:light[level=15]
setblock 454 220 278 minecraft:light[level=12]
setblock 454 220 285 minecraft:light[level=12]
setblock 454 220 292 minecraft:light[level=12]
setblock 454 220 299 minecraft:light[level=12]
setblock 454 220 306 minecraft:light[level=12]
setblock 454 220 313 minecraft:light[level=12]
fill 456 220 275 459 220 275 minecraft:sea_lantern
fill 457 220 317 460 220 317 minecraft:sea_lantern
setblock 458 220 278 minecraft:light[level=15]
setblock 458 220 286 minecraft:light[level=15]
setblock 458 220 294 minecraft:light[level=15]
setblock 458 220 302 minecraft:light[level=15]
setblock 458 220 310 minecraft:black_concrete
fill 458 220 312 458 220 313 minecraft:black_concrete
fill 459 220 309 461 220 309 minecraft:black_concrete
fill 459 220 313 462 220 314 minecraft:black_concrete
setblock 461 220 278 minecraft:light[level=12]
setblock 461 220 285 minecraft:light[level=12]
setblock 461 220 292 minecraft:light[level=12]
setblock 461 220 299 minecraft:light[level=12]
setblock 461 220 306 minecraft:light[level=12]
fill 462 220 310 462 220 312 minecraft:black_concrete
fill 465 220 276 465 220 279 minecraft:sea_lantern
fill 465 220 286 465 220 289 minecraft:sea_lantern
fill 465 220 296 465 220 299 minecraft:sea_lantern
fill 465 220 306 465 220 309 minecraft:sea_lantern
setblock 465 220 316 minecraft:sea_lantern
fill 423 221 281 423 228 284 minecraft:black_concrete
fill 423 221 291 423 228 294 minecraft:black_concrete
fill 423 221 301 423 228 304 minecraft:black_concrete
fill 423 221 311 423 228 314 minecraft:black_concrete
fill 426 221 275 429 228 275 minecraft:black_concrete
fill 427 221 317 430 228 317 minecraft:black_concrete
fill 436 221 275 439 228 275 minecraft:black_concrete
fill 437 221 317 440 228 317 minecraft:black_concrete
fill 446 221 275 449 228 275 minecraft:black_concrete
fill 447 221 317 450 228 317 minecraft:black_concrete
fill 456 221 275 459 228 275 minecraft:black_concrete
fill 457 221 317 460 228 317 minecraft:black_concrete
fill 459 221 313 461 227 313 minecraft:gray_concrete
fill 462 221 312 462 227 312 minecraft:gray_concrete
fill 465 221 276 465 228 279 minecraft:black_concrete
fill 465 221 286 465 228 289 minecraft:black_concrete
fill 465 221 296 465 228 299 minecraft:black_concrete
fill 465 221 306 465 228 309 minecraft:black_concrete
fill 465 221 316 465 228 316 minecraft:black_concrete
setblock 424 222 278 minecraft:gray_concrete
setblock 424 222 288 minecraft:gray_concrete
setblock 424 222 298 minecraft:gray_concrete
setblock 424 222 308 minecraft:gray_concrete
setblock 426 222 316 minecraft:gray_concrete
setblock 430 222 276 minecraft:gray_concrete
setblock 436 222 316 minecraft:gray_concrete
setblock 440 222 276 minecraft:gray_concrete
setblock 446 222 316 minecraft:gray_concrete
setblock 450 222 276 minecraft:gray_concrete
setblock 456 222 316 minecraft:gray_concrete
setblock 460 222 276 minecraft:gray_concrete
setblock 464 222 282 minecraft:gray_concrete
setblock 464 222 292 minecraft:gray_concrete
setblock 464 222 302 minecraft:gray_concrete
setblock 464 222 312 minecraft:gray_concrete
fill 459 224 300 459 225 301 minecraft:yellow_concrete
fill 424 225 280 424 225 283 minecraft:gray_concrete
fill 424 225 290 424 225 293 minecraft:gray_concrete
fill 424 225 300 424 225 303 minecraft:gray_concrete
fill 424 225 310 424 225 313 minecraft:gray_concrete
fill 425 225 276 428 225 276 minecraft:gray_concrete
fill 428 225 316 431 225 316 minecraft:gray_concrete
fill 435 225 276 438 225 276 minecraft:gray_concrete
fill 438 225 316 441 225 316 minecraft:gray_concrete
fill 445 225 276 448 225 276 minecraft:gray_concrete
fill 448 225 316 451 225 316 minecraft:gray_concrete
fill 455 225 276 458 225 276 minecraft:gray_concrete
fill 458 225 316 461 225 316 minecraft:gray_concrete
fill 464 225 277 464 225 280 minecraft:gray_concrete
fill 464 225 287 464 225 290 minecraft:gray_concrete
fill 464 225 297 464 225 300 minecraft:gray_concrete
fill 464 225 307 464 225 310 minecraft:gray_concrete
setblock 426 226 278 minecraft:light[level=12]
setblock 426 226 285 minecraft:light[level=12]
setblock 426 226 292 minecraft:light[level=12]
setblock 426 226 299 minecraft:light[level=12]
setblock 426 226 306 minecraft:light[level=12]
setblock 426 226 313 minecraft:light[level=12]
setblock 433 226 278 minecraft:light[level=12]
setblock 433 226 285 minecraft:light[level=12]
setblock 433 226 292 minecraft:light[level=12]
setblock 433 226 299 minecraft:light[level=12]
setblock 433 226 306 minecraft:light[level=12]
setblock 433 226 313 minecraft:light[level=12]
setblock 440 226 278 minecraft:light[level=12]
setblock 440 226 285 minecraft:light[level=12]
setblock 440 226 292 minecraft:light[level=12]
setblock 440 226 299 minecraft:light[level=12]
setblock 440 226 306 minecraft:light[level=12]
setblock 440 226 313 minecraft:light[level=12]
setblock 447 226 278 minecraft:light[level=12]
setblock 447 226 285 minecraft:light[level=12]
setblock 447 226 292 minecraft:light[level=12]
setblock 447 226 299 minecraft:light[level=12]
setblock 447 226 306 minecraft:light[level=12]
setblock 447 226 313 minecraft:light[level=12]
setblock 454 226 278 minecraft:light[level=12]
setblock 454 226 285 minecraft:light[level=12]
setblock 454 226 292 minecraft:light[level=12]
setblock 454 226 299 minecraft:light[level=12]
setblock 454 226 306 minecraft:light[level=12]
setblock 454 226 313 minecraft:light[level=12]
setblock 461 226 278 minecraft:light[level=12]
setblock 461 226 285 minecraft:light[level=12]
setblock 461 226 292 minecraft:light[level=12]
setblock 461 226 299 minecraft:light[level=12]
setblock 461 226 306 minecraft:light[level=12]
setblock 424 228 278 minecraft:gray_concrete
setblock 424 228 288 minecraft:gray_concrete
setblock 424 228 298 minecraft:gray_concrete
setblock 424 228 308 minecraft:gray_concrete
setblock 426 228 278 minecraft:light[level=15]
setblock 426 228 286 minecraft:light[level=15]
setblock 426 228 294 minecraft:light[level=15]
setblock 426 228 302 minecraft:light[level=15]
setblock 426 228 310 minecraft:light[level=15]
setblock 426 228 316 minecraft:gray_concrete
setblock 430 228 276 minecraft:gray_concrete
setblock 434 228 278 minecraft:light[level=15]
setblock 434 228 286 minecraft:light[level=15]
setblock 434 228 294 minecraft:light[level=15]
setblock 434 228 302 minecraft:light[level=15]
setblock 434 228 310 minecraft:light[level=15]
setblock 436 228 316 minecraft:gray_concrete
setblock 440 228 276 minecraft:gray_concrete
setblock 442 228 278 minecraft:light[level=15]
setblock 442 228 286 minecraft:light[level=15]
setblock 442 228 294 minecraft:light[level=15]
setblock 442 228 302 minecraft:light[level=15]
setblock 442 228 310 minecraft:light[level=15]
setblock 446 228 316 minecraft:gray_concrete
setblock 450 228 276 minecraft:gray_concrete
setblock 450 228 278 minecraft:light[level=15]
setblock 450 228 286 minecraft:light[level=15]
setblock 450 228 294 minecraft:light[level=15]
setblock 450 228 302 minecraft:light[level=15]
setblock 450 228 310 minecraft:light[level=15]
setblock 456 228 316 minecraft:gray_concrete
setblock 458 228 278 minecraft:light[level=15]
setblock 458 228 286 minecraft:light[level=15]
setblock 458 228 294 minecraft:light[level=15]
setblock 458 228 302 minecraft:light[level=15]
setblock 458 228 310 minecraft:black_concrete
fill 458 228 312 458 228 313 minecraft:black_concrete
fill 459 228 309 461 228 309 minecraft:black_concrete
fill 459 228 313 462 228 314 minecraft:black_concrete
setblock 460 228 276 minecraft:gray_concrete
fill 462 228 310 462 228 312 minecraft:black_concrete
setblock 464 228 282 minecraft:gray_concrete
setblock 464 228 292 minecraft:gray_concrete
setblock 464 228 302 minecraft:gray_concrete
setblock 464 228 312 minecraft:gray_concrete
fill 423 229 281 423 229 284 minecraft:sea_lantern
fill 423 229 291 423 229 294 minecraft:sea_lantern
fill 423 229 301 423 229 304 minecraft:sea_lantern
fill 423 229 311 423 229 314 minecraft:sea_lantern
fill 426 229 275 429 229 275 minecraft:sea_lantern
fill 427 229 317 430 229 317 minecraft:sea_lantern
fill 436 229 275 439 229 275 minecraft:sea_lantern
fill 437 229 317 440 229 317 minecraft:sea_lantern
fill 446 229 275 449 229 275 minecraft:sea_lantern
fill 447 229 317 450 229 317 minecraft:sea_lantern
fill 456 229 275 459 229 275 minecraft:sea_lantern
fill 457 229 317 460 229 317 minecraft:sea_lantern
fill 459 229 313 461 235 313 minecraft:gray_concrete
fill 462 229 312 462 235 312 minecraft:gray_concrete
fill 465 229 276 465 229 279 minecraft:sea_lantern
fill 465 229 286 465 229 289 minecraft:sea_lantern
fill 465 229 296 465 229 299 minecraft:sea_lantern
fill 465 229 306 465 229 309 minecraft:sea_lantern
setblock 465 229 316 minecraft:sea_lantern
fill 423 230 281 423 237 284 minecraft:black_concrete
fill 423 230 291 423 237 294 minecraft:black_concrete
fill 423 230 301 423 237 304 minecraft:black_concrete
fill 423 230 311 423 237 314 minecraft:black_concrete
fill 426 230 275 429 237 275 minecraft:black_concrete
fill 427 230 317 430 237 317 minecraft:black_concrete
fill 436 230 275 439 237 275 minecraft:black_concrete
fill 437 230 317 440 237 317 minecraft:black_concrete
fill 441 230 288 441 231 288 minecraft:light_blue_concrete
fill 446 230 275 449 237 275 minecraft:black_concrete
fill 447 230 317 450 237 317 minecraft:black_concrete
fill 456 230 275 459 237 275 minecraft:black_concrete
fill 457 230 317 460 237 317 minecraft:black_concrete
fill 465 230 276 465 237 279 minecraft:black_concrete
fill 465 230 286 465 237 289 minecraft:black_concrete
fill 465 230 296 465 237 299 minecraft:black_concrete
fill 465 230 306 465 237 309 minecraft:black_concrete
fill 465 230 316 465 237 316 minecraft:black_concrete
setblock 426 232 278 minecraft:light[level=12]
setblock 426 232 285 minecraft:light[level=12]
setblock 426 232 292 minecraft:light[level=12]
setblock 426 232 299 minecraft:light[level=12]
setblock 426 232 306 minecraft:light[level=12]
setblock 426 232 313 minecraft:light[level=12]
setblock 433 232 278 minecraft:light[level=12]
setblock 433 232 285 minecraft:light[level=12]
setblock 433 232 292 minecraft:light[level=12]
setblock 433 232 299 minecraft:light[level=12]
setblock 433 232 306 minecraft:light[level=12]
setblock 433 232 313 minecraft:light[level=12]
fill 438 232 313 440 232 315 minecraft:black_concrete
setblock 440 232 278 minecraft:light[level=12]
setblock 440 232 285 minecraft:light[level=12]
setblock 440 232 292 minecraft:light[level=12]
setblock 440 232 299 minecraft:light[level=12]
setblock 440 232 306 minecraft:light[level=12]
setblock 447 232 278 minecraft:light[level=12]
setblock 447 232 285 minecraft:light[level=12]
setblock 447 232 292 minecraft:light[level=12]
setblock 447 232 299 minecraft:light[level=12]
setblock 447 232 306 minecraft:light[level=12]
setblock 447 232 313 minecraft:light[level=12]
setblock 454 232 278 minecraft:light[level=12]
setblock 454 232 285 minecraft:light[level=12]
setblock 454 232 292 minecraft:light[level=12]
setblock 454 232 299 minecraft:light[level=12]
setblock 454 232 306 minecraft:light[level=12]
setblock 454 232 313 minecraft:light[level=12]
setblock 461 232 278 minecraft:light[level=12]
setblock 461 232 285 minecraft:light[level=12]
setblock 461 232 292 minecraft:light[level=12]
setblock 461 232 299 minecraft:light[level=12]
setblock 461 232 306 minecraft:light[level=12]
fill 438 233 313 438 233 315 minecraft:black_concrete
fill 439 233 313 440 233 313 minecraft:black_concrete
fill 439 233 314 439 235 314 minecraft:gray_concrete
fill 439 233 315 440 233 315 minecraft:black_concrete
setblock 440 233 314 minecraft:black_concrete
setblock 424 234 278 minecraft:gray_concrete
fill 424 234 280 424 234 283 minecraft:gray_concrete
setblock 424 234 288 minecraft:gray_concrete
fill 424 234 290 424 234 293 minecraft:gray_concrete
setblock 424 234 298 minecraft:gray_concrete
fill 424 234 300 424 234 303 minecraft:gray_concrete
setblock 424 234 308 minecraft:gray_concrete
fill 424 234 310 424 234 313 minecraft:gray_concrete
fill 425 234 276 428 234 276 minecraft:gray_concrete
setblock 426 234 316 minecraft:gray_concrete
fill 428 234 290 428 235 291 minecraft:light_blue_concrete
fill 428 234 316 431 234 316 minecraft:gray_concrete
setblock 430 234 276 minecraft:gray_concrete
fill 435 234 276 438 234 276 minecraft:gray_concrete
setblock 436 234 316 minecraft:gray_concrete
fill 438 234 313 438 236 313 minecraft:black_concrete
setblock 438 234 314 minecraft:gray_concrete
fill 438 234 315 438 236 315 minecraft:black_concrete
fill 438 234 316 441 234 316 minecraft:gray_concrete
setblock 439 234 313 minecraft:gray_concrete
setblock 439 234 315 minecraft:gray_concrete
setblock 440 234 276 minecraft:gray_concrete
fill 440 234 313 440 236 313 minecraft:black_concrete
setblock 440 234 314 minecraft:gray_concrete
fill 440 234 315 440 236 315 minecraft:black_concrete
fill 445 234 276 448 234 276 minecraft:gray_concrete
setblock 446 234 316 minecraft:gray_concrete
fill 448 234 316 451 234 316 minecraft:gray_concrete
setblock 450 234 276 minecraft:gray_concrete
fill 455 234 276 458 234 276 minecraft:gray_concrete
setblock 456 234 316 minecraft:gray_concrete
fill 458 234 316 461 234 316 minecraft:gray_concrete
setblock 460 234 276 minecraft:gray_concrete
fill 464 234 277 464 234 280 minecraft:gray_concrete
setblock 464 234 282 minecraft:gray_concrete
fill 464 234 287 464 234 290 minecraft:gray_concrete
setblock 464 234 292 minecraft:gray_concrete
fill 464 234 297 464 234 300 minecraft:gray_concrete
setblock 464 234 302 minecraft:gray_concrete
fill 464 234 307 464 234 310 minecraft:gray_concrete
setblock 464 234 312 minecraft:gray_concrete
fill 438 235 314 438 236 314 minecraft:black_concrete
fill 439 235 313 439 236 313 minecraft:black_concrete
fill 439 235 315 439 236 315 minecraft:black_concrete
fill 440 235 314 440 236 314 minecraft:black_concrete
setblock 426 236 278 minecraft:light[level=15]
setblock 426 236 286 minecraft:light[level=15]
setblock 426 236 294 minecraft:light[level=15]
setblock 426 236 302 minecraft:light[level=15]
setblock 426 236 310 minecraft:light[level=15]
setblock 434 236 278 minecraft:light[level=15]
setblock 434 236 286 minecraft:light[level=15]
setblock 434 236 294 minecraft:light[level=15]
setblock 434 236 302 minecraft:light[level=15]
setblock 434 236 310 minecraft:light[level=15]
setblock 439 236 314 minecraft:black_concrete
setblock 442 236 278 minecraft:light[level=15]
setblock 442 236 286 minecraft:light[level=15]
setblock 442 236 294 minecraft:light[level=15]
setblock 442 236 302 minecraft:light[level=15]
setblock 442 236 310 minecraft:light[level=15]
setblock 450 236 278 minecraft:light[level=15]
setblock 450 236 286 minecraft:light[level=15]
setblock 450 236 294 minecraft:light[level=15]
setblock 450 236 302 minecraft:light[level=15]
setblock 450 236 310 minecraft:light[level=15]
setblock 458 236 278 minecraft:light[level=15]
setblock 458 236 286 minecraft:light[level=15]
setblock 458 236 294 minecraft:light[level=15]
setblock 458 236 302 minecraft:light[level=15]
setblock 458 236 310 minecraft:black_concrete
fill 458 236 312 458 236 313 minecraft:black_concrete
fill 459 236 309 461 236 309 minecraft:black_concrete
fill 459 236 313 462 236 314 minecraft:black_concrete
fill 462 236 310 462 236 312 minecraft:black_concrete
fill 459 237 313 461 243 313 minecraft:gray_concrete
fill 462 237 312 462 243 312 minecraft:gray_concrete
fill 423 238 281 423 238 284 minecraft:sea_lantern
fill 423 238 291 423 238 294 minecraft:sea_lantern
fill 423 238 301 423 238 304 minecraft:sea_lantern
fill 423 238 311 423 238 314 minecraft:sea_lantern
fill 426 238 275 429 238 275 minecraft:sea_lantern
setblock 426 238 278 minecraft:light[level=12]
setblock 426 238 285 minecraft:light[level=12]
setblock 426 238 292 minecraft:light[level=12]
setblock 426 238 299 minecraft:light[level=12]
setblock 426 238 306 minecraft:light[level=12]
setblock 426 238 313 minecraft:light[level=12]
fill 427 238 317 430 238 317 minecraft:sea_lantern
setblock 433 238 278 minecraft:light[level=12]
setblock 433 238 285 minecraft:light[level=12]
setblock 433 238 292 minecraft:light[level=12]
setblock 433 238 299 minecraft:light[level=12]
setblock 433 238 306 minecraft:light[level=12]
setblock 433 238 313 minecraft:light[level=12]
fill 436 238 275 439 238 275 minecraft:sea_lantern
fill 437 238 301 438 239 302 minecraft:light_blue_concrete
fill 437 238 317 440 238 317 minecraft:sea_lantern
setblock 440 238 278 minecraft:light[level=12]
setblock 440 238 285 minecraft:light[level=12]
setblock 440 238 292 minecraft:light[level=12]
setblock 440 238 299 minecraft:light[level=12]
setblock 440 238 306 minecraft:light[level=12]
setblock 440 238 313 minecraft:light[level=12]
fill 446 238 275 449 238 275 minecraft:sea_lantern
setblock 447 238 278 minecraft:light[level=12]
setblock 447 238 285 minecraft:light[level=12]
setblock 447 238 292 minecraft:light[level=12]
setblock 447 238 299 minecraft:light[level=12]
setblock 447 238 306 minecraft:light[level=12]
setblock 447 238 313 minecraft:light[level=12]
fill 447 238 317 450 238 317 minecraft:sea_lantern
setblock 454 238 278 minecraft:light[level=12]
setblock 454 238 285 minecraft:light[level=12]
setblock 454 238 292 minecraft:light[level=12]
setblock 454 238 299 minecraft:light[level=12]
setblock 454 238 306 minecraft:light[level=12]
setblock 454 238 313 minecraft:light[level=12]
fill 456 238 275 459 238 275 minecraft:sea_lantern
fill 457 238 317 460 238 317 minecraft:sea_lantern
setblock 461 238 278 minecraft:light[level=12]
setblock 461 238 285 minecraft:light[level=12]
setblock 461 238 292 minecraft:light[level=12]
setblock 461 238 299 minecraft:light[level=12]
setblock 461 238 306 minecraft:light[level=12]
fill 465 238 276 465 238 279 minecraft:sea_lantern
fill 465 238 286 465 238 289 minecraft:sea_lantern
fill 465 238 296 465 238 299 minecraft:sea_lantern
fill 465 238 306 465 238 309 minecraft:sea_lantern
setblock 465 238 316 minecraft:sea_lantern
fill 423 239 281 423 246 284 minecraft:black_concrete
fill 423 239 291 423 246 294 minecraft:black_concrete
fill 423 239 301 423 246 304 minecraft:black_concrete
fill 423 239 311 423 246 314 minecraft:black_concrete
fill 426 239 275 429 246 275 minecraft:black_concrete
fill 427 239 317 430 246 317 minecraft:black_concrete
fill 436 239 275 439 246 275 minecraft:black_concrete
fill 437 239 317 440 246 317 minecraft:black_concrete
fill 446 239 275 449 246 275 minecraft:black_concrete
fill 447 239 317 450 246 317 minecraft:black_concrete
fill 456 239 275 459 246 275 minecraft:black_concrete
fill 457 239 317 460 246 317 minecraft:black_concrete
fill 465 239 276 465 246 279 minecraft:black_concrete
fill 465 239 286 465 246 289 minecraft:black_concrete
fill 465 239 296 465 246 299 minecraft:black_concrete
fill 465 239 306 465 246 309 minecraft:black_concrete
fill 465 239 316 465 246 316 minecraft:black_concrete
setblock 424 240 278 minecraft:gray_concrete
setblock 424 240 288 minecraft:gray_concrete
setblock 424 240 298 minecraft:gray_concrete
setblock 424 240 308 minecraft:gray_concrete
setblock 426 240 316 minecraft:gray_concrete
setblock 430 240 276 minecraft:gray_concrete
setblock 436 240 316 minecraft:gray_concrete
setblock 440 240 276 minecraft:gray_concrete
setblock 446 240 316 minecraft:gray_concrete
setblock 450 240 276 minecraft:gray_concrete
setblock 456 240 316 minecraft:gray_concrete
setblock 460 240 276 minecraft:gray_concrete
setblock 464 240 282 minecraft:gray_concrete
setblock 464 240 292 minecraft:gray_concrete
setblock 464 240 302 minecraft:gray_concrete
setblock 464 240 312 minecraft:gray_concrete
fill 458 241 276 458 242 278 minecraft:iron_block
fill 436 242 288 438 243 288 minecraft:lime_concrete
fill 437 242 289 437 243 289 minecraft:lime_concrete
fill 424 243 280 424 243 283 minecraft:gray_concrete
fill 424 243 290 424 243 293 minecraft:gray_concrete
fill 424 243 300 424 243 303 minecraft:gray_concrete
fill 424 243 310 424 243 313 minecraft:gray_concrete
fill 425 243 276 428 243 276 minecraft:gray_concrete
fill 428 243 316 431 243 316 minecraft:gray_concrete
fill 432 243 295 432 244 295 minecraft:lime_concrete
fill 435 243 276 438 243 276 minecraft:gray_concrete
fill 438 243 316 441 243 316 minecraft:gray_concrete
fill 445 243 276 448 243 276 minecraft:gray_concrete
fill 448 243 316 451 243 316 minecraft:gray_concrete
fill 455 243 276 458 243 276 minecraft:gray_concrete
fill 458 243 316 461 243 316 minecraft:gray_concrete
fill 464 243 277 464 243 280 minecraft:gray_concrete
fill 464 243 287 464 243 290 minecraft:gray_concrete
fill 464 243 297 464 243 300 minecraft:gray_concrete
fill 464 243 307 464 243 310 minecraft:gray_concrete
setblock 426 244 278 minecraft:light[level=15]
setblock 426 244 285 minecraft:light[level=12]
setblock 426 244 286 minecraft:light[level=15]
setblock 426 244 292 minecraft:light[level=12]
setblock 426 244 294 minecraft:light[level=15]
setblock 426 244 299 minecraft:light[level=12]
setblock 426 244 302 minecraft:light[level=15]
setblock 426 244 306 minecraft:light[level=12]
setblock 426 244 310 minecraft:light[level=15]
setblock 426 244 313 minecraft:light[level=12]
setblock 433 244 278 minecraft:light[level=12]
setblock 433 244 285 minecraft:light[level=12]
setblock 433 244 292 minecraft:light[level=12]
setblock 433 244 299 minecraft:light[level=12]
setblock 433 244 306 minecraft:light[level=12]
setblock 433 244 313 minecraft:light[level=12]
setblock 434 244 278 minecraft:light[level=15]
setblock 434 244 286 minecraft:light[level=15]
setblock 434 244 294 minecraft:light[level=15]
setblock 434 244 302 minecraft:light[level=15]
setblock 434 244 310 minecraft:light[level=15]
setblock 440 244 278 minecraft:light[level=12]
setblock 440 244 285 minecraft:light[level=12]
setblock 440 244 292 minecraft:light[level=12]
setblock 440 244 299 minecraft:light[level=12]
setblock 440 244 306 minecraft:light[level=12]
setblock 440 244 313 minecraft:light[level=12]
setblock 442 244 278 minecraft:light[level=15]
setblock 442 244 286 minecraft:light[level=15]
setblock 442 244 294 minecraft:light[level=15]
setblock 442 244 302 minecraft:light[level=15]
setblock 442 244 310 minecraft:light[level=15]
setblock 447 244 278 minecraft:light[level=12]
setblock 447 244 285 minecraft:light[level=12]
setblock 447 244 292 minecraft:light[level=12]
setblock 447 244 299 minecraft:light[level=12]
setblock 447 244 306 minecraft:light[level=12]
setblock 447 244 313 minecraft:light[level=12]
setblock 450 244 278 minecraft:light[level=15]
setblock 450 244 286 minecraft:light[level=15]
setblock 450 244 294 minecraft:light[level=15]
setblock 450 244 302 minecraft:light[level=15]
setblock 450 244 310 minecraft:light[level=15]
setblock 454 244 278 minecraft:light[level=12]
setblock 454 244 285 minecraft:light[level=12]
setblock 454 244 292 minecraft:light[level=12]
setblock 454 244 299 minecraft:light[level=12]
setblock 454 244 306 minecraft:light[level=12]
setblock 454 244 313 minecraft:light[level=12]
setblock 458 244 278 minecraft:light[level=15]
setblock 458 244 286 minecraft:light[level=15]
setblock 458 244 294 minecraft:light[level=15]
setblock 458 244 302 minecraft:light[level=15]
setblock 458 244 310 minecraft:black_concrete
fill 458 244 312 458 244 313 minecraft:black_concrete
fill 459 244 309 461 244 309 minecraft:black_concrete
fill 459 244 313 462 244 314 minecraft:black_concrete
setblock 461 244 278 minecraft:light[level=12]
setblock 461 244 285 minecraft:light[level=12]
setblock 461 244 292 minecraft:light[level=12]
setblock 461 244 299 minecraft:light[level=12]
setblock 461 244 306 minecraft:light[level=12]
fill 462 244 310 462 244 312 minecraft:black_concrete
fill 431 245 287 432 246 287 minecraft:magenta_concrete
fill 459 245 313 461 251 313 minecraft:gray_concrete
fill 462 245 312 462 251 312 minecraft:gray_concrete
setblock 424 246 278 minecraft:gray_concrete
setblock 424 246 288 minecraft:gray_concrete
setblock 424 246 298 minecraft:gray_concrete
setblock 424 246 308 minecraft:gray_concrete
setblock 426 246 316 minecraft:gray_concrete
setblock 430 246 276 minecraft:gray_concrete
setblock 436 246 316 minecraft:gray_concrete
setblock 440 246 276 minecraft:gray_concrete
setblock 446 246 316 minecraft:gray_concrete
setblock 450 246 276 minecraft:gray_concrete
setblock 456 246 316 minecraft:gray_concrete
setblock 460 246 276 minecraft:gray_concrete
setblock 464 246 282 minecraft:gray_concrete
setblock 464 246 292 minecraft:gray_concrete
setblock 464 246 302 minecraft:gray_concrete
setblock 464 246 312 minecraft:gray_concrete
fill 423 247 281 423 247 284 minecraft:sea_lantern
fill 423 247 291 423 247 294 minecraft:sea_lantern
fill 423 247 301 423 247 304 minecraft:sea_lantern
fill 423 247 311 423 247 314 minecraft:sea_lantern
fill 426 247 275 429 247 275 minecraft:sea_lantern
fill 427 247 317 430 247 317 minecraft:sea_lantern
fill 436 247 275 439 247 275 minecraft:sea_lantern
fill 437 247 317 440 247 317 minecraft:sea_lantern
fill 446 247 275 449 247 275 minecraft:sea_lantern
fill 447 247 317 450 247 317 minecraft:sea_lantern
fill 456 247 275 459 247 275 minecraft:sea_lantern
fill 457 247 317 460 247 317 minecraft:sea_lantern
fill 465 247 276 465 247 279 minecraft:sea_lantern
fill 465 247 286 465 247 289 minecraft:sea_lantern
fill 465 247 296 465 247 299 minecraft:sea_lantern
fill 465 247 306 465 247 309 minecraft:sea_lantern
setblock 465 247 316 minecraft:sea_lantern
fill 423 248 281 423 255 284 minecraft:black_concrete
fill 423 248 291 423 255 294 minecraft:black_concrete
fill 423 248 301 423 255 304 minecraft:black_concrete
fill 423 248 311 423 255 314 minecraft:black_concrete
fill 426 248 275 429 255 275 minecraft:black_concrete
fill 427 248 317 430 255 317 minecraft:black_concrete
fill 436 248 275 439 255 275 minecraft:black_concrete
fill 437 248 317 440 255 317 minecraft:black_concrete
fill 446 248 275 449 255 275 minecraft:black_concrete
fill 447 248 317 450 255 317 minecraft:black_concrete
fill 456 248 275 459 255 275 minecraft:black_concrete
fill 457 248 317 460 255 317 minecraft:black_concrete
fill 465 248 276 465 255 279 minecraft:black_concrete
fill 465 248 286 465 255 289 minecraft:black_concrete
fill 465 248 296 465 255 299 minecraft:black_concrete
fill 465 248 306 465 255 309 minecraft:black_concrete
fill 465 248 316 465 255 316 minecraft:black_concrete
setblock 426 250 278 minecraft:light[level=12]
setblock 426 250 285 minecraft:light[level=12]
setblock 426 250 292 minecraft:light[level=12]
setblock 426 250 299 minecraft:light[level=12]
setblock 426 250 306 minecraft:light[level=12]
setblock 426 250 313 minecraft:light[level=12]
setblock 433 250 278 minecraft:light[level=12]
setblock 433 250 285 minecraft:light[level=12]
setblock 433 250 292 minecraft:light[level=12]
setblock 433 250 299 minecraft:light[level=12]
setblock 433 250 306 minecraft:light[level=12]
setblock 433 250 313 minecraft:light[level=12]
setblock 440 250 278 minecraft:light[level=12]
setblock 440 250 285 minecraft:light[level=12]
setblock 440 250 292 minecraft:light[level=12]
setblock 440 250 299 minecraft:light[level=12]
setblock 440 250 306 minecraft:light[level=12]
setblock 440 250 313 minecraft:light[level=12]
setblock 447 250 278 minecraft:light[level=12]
setblock 447 250 285 minecraft:light[level=12]
setblock 447 250 292 minecraft:light[level=12]
setblock 447 250 299 minecraft:light[level=12]
setblock 447 250 306 minecraft:light[level=12]
setblock 447 250 313 minecraft:light[level=12]
setblock 454 250 278 minecraft:light[level=12]
setblock 454 250 285 minecraft:light[level=12]
setblock 454 250 292 minecraft:light[level=12]
setblock 454 250 299 minecraft:light[level=12]
setblock 454 250 306 minecraft:light[level=12]
setblock 454 250 313 minecraft:light[level=12]
setblock 461 250 278 minecraft:light[level=12]
setblock 461 250 285 minecraft:light[level=12]
setblock 461 250 292 minecraft:light[level=12]
setblock 461 250 299 minecraft:light[level=12]
setblock 461 250 306 minecraft:light[level=12]
setblock 424 252 278 minecraft:gray_concrete
fill 424 252 280 424 252 283 minecraft:gray_concrete
setblock 424 252 288 minecraft:gray_concrete
fill 424 252 290 424 252 293 minecraft:gray_concrete
setblock 424 252 298 minecraft:gray_concrete
fill 424 252 300 424 252 303 minecraft:gray_concrete
setblock 424 252 308 minecraft:gray_concrete
fill 424 252 310 424 252 313 minecraft:gray_concrete
fill 425 252 276 428 252 276 minecraft:gray_concrete
setblock 426 252 278 minecraft:light[level=15]
setblock 426 252 286 minecraft:light[level=15]
setblock 426 252 294 minecraft:light[level=15]
setblock 426 252 302 minecraft:light[level=15]
setblock 426 252 310 minecraft:light[level=15]
setblock 426 252 316 minecraft:gray_concrete
fill 428 252 316 431 252 316 minecraft:gray_concrete
setblock 430 252 276 minecraft:gray_concrete
setblock 434 252 278 minecraft:light[level=15]
setblock 434 252 286 minecraft:light[level=15]
setblock 434 252 294 minecraft:light[level=15]
setblock 434 252 302 minecraft:light[level=15]
setblock 434 252 310 minecraft:light[level=15]
fill 435 252 276 438 252 276 minecraft:gray_concrete
setblock 436 252 316 minecraft:gray_concrete
fill 438 252 316 441 252 316 minecraft:gray_concrete
setblock 440 252 276 minecraft:gray_concrete
setblock 442 252 278 minecraft:light[level=15]
setblock 442 252 286 minecraft:light[level=15]
setblock 442 252 302 minecraft:light[level=15]
setblock 442 252 310 minecraft:light[level=15]
fill 445 252 276 448 252 276 minecraft:gray_concrete
setblock 446 252 316 minecraft:gray_concrete
fill 448 252 316 451 252 316 minecraft:gray_concrete
setblock 450 252 276 minecraft:gray_concrete
setblock 450 252 278 minecraft:light[level=15]
setblock 450 252 286 minecraft:light[level=15]
setblock 450 252 294 minecraft:light[level=15]
setblock 450 252 302 minecraft:light[level=15]
setblock 450 252 310 minecraft:light[level=15]
fill 455 252 276 458 252 276 minecraft:gray_concrete
setblock 456 252 316 minecraft:gray_concrete
setblock 458 252 278 minecraft:light[level=15]
setblock 458 252 286 minecraft:light[level=15]
setblock 458 252 294 minecraft:light[level=15]
setblock 458 252 302 minecraft:light[level=15]
setblock 458 252 310 minecraft:black_concrete
fill 458 252 312 458 252 313 minecraft:black_concrete
fill 458 252 316 461 252 316 minecraft:gray_concrete
fill 459 252 309 461 252 309 minecraft:black_concrete
fill 459 252 313 462 252 314 minecraft:black_concrete
setblock 460 252 276 minecraft:gray_concrete
fill 462 252 310 462 252 312 minecraft:black_concrete
fill 464 252 277 464 252 280 minecraft:gray_concrete
setblock 464 252 282 minecraft:gray_concrete
fill 464 252 287 464 252 290 minecraft:gray_concrete
setblock 464 252 292 minecraft:gray_concrete
fill 464 252 297 464 252 300 minecraft:gray_concrete
setblock 464 252 302 minecraft:gray_concrete
fill 464 252 307 464 252 310 minecraft:gray_concrete
setblock 464 252 312 minecraft:gray_concrete
fill 432 253 291 433 254 292 minecraft:magenta_concrete
fill 459 253 313 461 259 313 minecraft:gray_concrete
fill 462 253 312 462 259 312 minecraft:gray_concrete
fill 423 256 281 423 256 284 minecraft:sea_lantern
fill 423 256 291 423 256 294 minecraft:sea_lantern
fill 423 256 301 423 256 304 minecraft:sea_lantern
fill 423 256 311 423 256 314 minecraft:sea_lantern
fill 426 256 275 429 256 275 minecraft:sea_lantern
setblock 426 256 278 minecraft:light[level=12]
setblock 426 256 285 minecraft:light[level=12]
setblock 426 256 292 minecraft:light[level=12]
fill 426 256 294 427 257 298 minecraft:gray_concrete
setblock 426 256 299 minecraft:light[level=12]
setblock 426 256 306 minecraft:light[level=12]
setblock 426 256 313 minecraft:light[level=12]
fill 427 256 290 427 257 293 minecraft:gray_concrete
fill 427 256 299 427 257 302 minecraft:gray_concrete
fill 427 256 317 430 256 317 minecraft:sea_lantern
fill 428 256 288 428 257 290 minecraft:gray_concrete
fill 428 256 302 428 257 304 minecraft:gray_concrete
fill 429 256 286 429 257 288 minecraft:gray_concrete
fill 429 256 304 429 257 306 minecraft:gray_concrete
fill 430 256 285 430 257 286 minecraft:gray_concrete
fill 430 256 306 430 257 307 minecraft:gray_concrete
fill 431 256 284 431 257 285 minecraft:gray_concrete
fill 431 256 294 431 257 294 minecraft:light_blue_concrete
fill 431 256 307 431 257 308 minecraft:gray_concrete
fill 432 256 283 432 257 284 minecraft:gray_concrete
fill 432 256 308 432 257 309 minecraft:gray_concrete
setblock 433 256 278 minecraft:light[level=12]
fill 433 256 282 433 257 283 minecraft:gray_concrete
setblock 433 256 285 minecraft:light[level=12]
setblock 433 256 292 minecraft:light[level=12]
setblock 433 256 299 minecraft:light[level=12]
setblock 433 256 306 minecraft:light[level=12]
fill 433 256 309 433 257 310 minecraft:gray_concrete
setblock 433 256 313 minecraft:light[level=12]
fill 434 256 281 434 257 282 minecraft:gray_concrete
fill 434 256 310 434 257 311 minecraft:gray_concrete
fill 435 256 281 436 258 281 minecraft:gray_concrete
fill 435 256 311 436 257 311 minecraft:gray_concrete
fill 436 256 275 439 256 275 minecraft:sea_lantern
fill 436 256 280 438 258 280 minecraft:gray_concrete
fill 436 256 312 438 257 312 minecraft:gray_concrete
fill 437 256 317 440 256 317 minecraft:sea_lantern
fill 438 256 279 450 257 279 minecraft:gray_concrete
fill 438 256 313 450 257 313 minecraft:gray_concrete
setblock 440 256 278 minecraft:light[level=12]
setblock 440 256 285 minecraft:light[level=12]
setblock 440 256 292 minecraft:light[level=12]
setblock 440 256 299 minecraft:light[level=12]
setblock 440 256 306 minecraft:light[level=12]
fill 442 256 278 446 257 278 minecraft:gray_concrete
fill 442 256 314 446 257 314 minecraft:gray_concrete
fill 446 256 275 449 256 275 minecraft:sea_lantern
setblock 447 256 278 minecraft:light[level=12]
setblock 447 256 285 minecraft:light[level=12]
setblock 447 256 292 minecraft:light[level=12]
setblock 447 256 299 minecraft:light[level=12]
setblock 447 256 306 minecraft:light[level=12]
fill 447 256 317 450 256 317 minecraft:sea_lantern
fill 450 256 280 452 257 280 minecraft:gray_concrete
fill 450 256 312 452 257 312 minecraft:gray_concrete
fill 452 256 281 464 257 281 minecraft:gray_concrete
fill 452 256 311 454 257 311 minecraft:gray_concrete
setblock 454 256 278 minecraft:light[level=12]
fill 454 256 282 455 257 282 minecraft:gray_concrete
setblock 454 256 285 minecraft:light[level=12]
setblock 454 256 292 minecraft:light[level=12]
setblock 454 256 299 minecraft:light[level=12]
setblock 454 256 306 minecraft:light[level=12]
fill 454 256 310 455 257 310 minecraft:gray_concrete
setblock 454 256 313 minecraft:light[level=12]
fill 455 256 283 456 257 283 minecraft:gray_concrete
fill 455 256 309 456 257 309 minecraft:gray_concrete
fill 456 256 275 459 256 275 minecraft:sea_lantern
fill 456 256 284 457 257 284 minecraft:gray_concrete
fill 456 256 308 457 257 308 minecraft:gray_concrete
fill 457 256 285 458 257 285 minecraft:gray_concrete
fill 457 256 307 458 257 307 minecraft:gray_concrete
fill 457 256 317 460 256 317 minecraft:sea_lantern
fill 458 256 286 459 257 286 minecraft:gray_concrete
fill 458 256 306 459 257 306 minecraft:gray_concrete
fill 459 256 287 459 257 288 minecraft:gray_concrete
fill 459 256 304 459 257 305 minecraft:gray_concrete
fill 460 256 288 460 257 290 minecraft:gray_concrete
fill 460 256 302 460 257 304 minecraft:gray_concrete
setblock 461 256 278 minecraft:light[level=12]
fill 461 256 282 463 257 282 minecraft:gray_concrete
setblock 461 256 285 minecraft:light[level=12]
fill 461 256 290 461 257 302 minecraft:gray_concrete
fill 461 256 303 463 256 305 minecraft:black_concrete
setblock 461 256 306 minecraft:light[level=12]
fill 462 256 294 462 257 298 minecraft:gray_concrete
fill 465 256 276 465 256 279 minecraft:sea_lantern
fill 465 256 286 465 256 289 minecraft:sea_lantern
fill 465 256 296 465 256 299 minecraft:sea_lantern
fill 465 256 306 465 256 309 minecraft:sea_lantern
setblock 465 256 316 minecraft:sea_lantern
fill 423 257 281 423 282 284 minecraft:black_concrete
fill 423 257 291 423 282 294 minecraft:black_concrete
fill 423 257 301 423 282 304 minecraft:black_concrete
fill 423 257 311 423 282 314 minecraft:black_concrete
fill 426 257 275 429 282 275 minecraft:black_concrete
fill 427 257 317 430 282 317 minecraft:black_concrete
fill 436 257 275 439 282 275 minecraft:black_concrete
fill 437 257 281 451 258 281 minecraft:gray_concrete
fill 437 257 317 440 282 317 minecraft:black_concrete
fill 446 257 275 449 282 275 minecraft:black_concrete
fill 447 257 282 453 257 282 minecraft:gray_concrete
fill 447 257 317 450 282 317 minecraft:black_concrete
fill 456 257 275 459 282 275 minecraft:black_concrete
fill 456 257 282 460 257 282 minecraft:gray_concrete
fill 457 257 317 460 282 317 minecraft:black_concrete
fill 461 257 303 461 257 305 minecraft:black_concrete
fill 462 257 303 463 257 303 minecraft:black_concrete
fill 462 257 304 462 259 304 minecraft:gray_concrete
fill 462 257 305 463 257 305 minecraft:black_concrete
setblock 463 257 304 minecraft:black_concrete
fill 465 257 276 465 282 279 minecraft:black_concrete
fill 465 257 286 465 282 289 minecraft:black_concrete
fill 465 257 296 465 282 299 minecraft:black_concrete
fill 465 257 306 465 282 309 minecraft:black_concrete
fill 465 257 316 465 282 316 minecraft:black_concrete
setblock 424 258 278 minecraft:gray_concrete
fill 424 258 280 434 258 281 minecraft:gray_concrete
setblock 424 258 288 minecraft:gray_concrete
setblock 424 258 298 minecraft:gray_concrete
setblock 424 258 308 minecraft:gray_concrete
fill 426 258 292 426 258 298 minecraft:sea_lantern
setblock 426 258 316 minecraft:gray_concrete
fill 427 258 289 427 258 291 minecraft:sea_lantern
fill 428 258 287 428 258 288 minecraft:sea_lantern
setblock 429 258 286 minecraft:sea_lantern
setblock 430 258 276 minecraft:gray_concrete
fill 430 258 284 430 258 285 minecraft:sea_lantern
fill 431 258 283 431 258 284 minecraft:sea_lantern
fill 432 258 282 432 258 283 minecraft:sea_lantern
setblock 433 258 282 minecraft:sea_lantern
setblock 435 258 280 minecraft:gray_concrete
setblock 436 258 316 minecraft:gray_concrete
fill 437 258 279 439 258 279 minecraft:sea_lantern
setblock 440 258 276 minecraft:gray_concrete
fill 440 258 278 448 258 278 minecraft:sea_lantern
setblock 446 258 316 minecraft:gray_concrete
fill 449 258 279 451 258 279 minecraft:sea_lantern
setblock 450 258 276 minecraft:gray_concrete
fill 452 258 280 453 258 280 minecraft:sea_lantern
fill 452 258 281 453 258 281 minecraft:gray_concrete
fill 454 258 281 463 258 281 minecraft:magenta_concrete
fill 455 258 282 456 258 282 minecraft:sea_lantern
fill 456 258 283 457 258 283 minecraft:sea_lantern
setblock 456 258 316 minecraft:gray_concrete
fill 457 258 284 458 258 284 minecraft:sea_lantern
setblock 458 258 285 minecraft:sea_lantern
setblock 459 258 286 minecraft:sea_lantern
setblock 460 258 276 minecraft:gray_concrete
fill 460 258 287 460 258 288 minecraft:sea_lantern
fill 461 258 289 461 258 291 minecraft:sea_lantern
fill 461 258 301 461 258 302 minecraft:sea_lantern
fill 461 258 303 461 260 303 minecraft:black_concrete
setblock 461 258 304 minecraft:gray_concrete
fill 461 258 305 461 260 305 minecraft:black_concrete
fill 462 258 292 462 258 300 minecraft:sea_lantern
setblock 462 258 303 minecraft:gray_concrete
setblock 462 258 305 minecraft:gray_concrete
fill 463 258 303 463 260 303 minecraft:black_concrete
setblock 463 258 304 minecraft:gray_concrete
fill 463 258 305 463 260 305 minecraft:black_concrete
setblock 464 258 282 minecraft:gray_concrete
setblock 464 258 292 minecraft:gray_concrete
setblock 464 258 302 minecraft:gray_concrete
setblock 464 258 312 minecraft:gray_concrete
fill 424 259 280 425 259 281 minecraft:gray_concrete
fill 426 259 281 433 259 281 minecraft:gray_concrete
fill 434 259 281 452 259 281 minecraft:magenta_concrete
fill 461 259 304 461 260 304 minecraft:black_concrete
fill 462 259 303 462 260 303 minecraft:black_concrete
fill 462 259 305 462 260 305 minecraft:black_concrete
fill 463 259 304 463 260 304 minecraft:black_concrete
fill 424 260 281 432 260 281 minecraft:magenta_concrete
setblock 426 260 278 minecraft:light[level=15]
setblock 426 260 286 minecraft:light[level=15]
schedule function dropper:buildpart/69_3 1t
