setblock 453 186 477 minecraft:ochre_froglight
fill 453 186 478 453 191 479 minecraft:dark_oak_planks
setblock 453 186 480 minecraft:ochre_froglight
fill 453 186 481 453 191 482 minecraft:dark_oak_planks
setblock 453 186 483 minecraft:ochre_froglight
fill 453 186 484 453 191 485 minecraft:dark_oak_planks
setblock 453 186 486 minecraft:ochre_froglight
fill 453 186 487 453 191 488 minecraft:dark_oak_planks
setblock 453 186 489 minecraft:ochre_froglight
fill 453 186 490 453 191 490 minecraft:dark_oak_planks
setblock 424 187 464 minecraft:polished_blackstone_bricks
fill 424 187 465 424 187 468 minecraft:blackstone
setblock 424 187 469 minecraft:polished_blackstone_bricks
fill 424 187 470 424 187 473 minecraft:blackstone
setblock 424 187 474 minecraft:polished_blackstone_bricks
fill 424 187 475 424 187 478 minecraft:blackstone
setblock 424 187 479 minecraft:polished_blackstone_bricks
fill 424 187 480 424 187 483 minecraft:blackstone
setblock 424 187 484 minecraft:polished_blackstone_bricks
fill 424 187 485 424 187 488 minecraft:blackstone
setblock 424 187 489 minecraft:polished_blackstone_bricks
fill 424 187 490 424 190 490 minecraft:blackstone
setblock 424 187 499 minecraft:polished_blackstone_bricks
fill 424 187 500 424 187 503 minecraft:blackstone
setblock 424 187 504 minecraft:polished_blackstone_bricks
fill 425 187 464 425 187 467 minecraft:blackstone
setblock 425 187 468 minecraft:polished_blackstone_bricks
fill 425 187 469 425 187 472 minecraft:blackstone
setblock 425 187 473 minecraft:polished_blackstone_bricks
fill 425 187 474 425 187 477 minecraft:blackstone
setblock 425 187 478 minecraft:polished_blackstone_bricks
fill 425 187 479 425 187 482 minecraft:blackstone
setblock 425 187 483 minecraft:polished_blackstone_bricks
fill 425 187 484 425 187 487 minecraft:blackstone
setblock 425 187 502 minecraft:blackstone
setblock 425 187 503 minecraft:polished_blackstone_bricks
fill 425 187 504 428 187 504 minecraft:blackstone
fill 426 187 464 426 187 466 minecraft:blackstone
setblock 426 187 467 minecraft:polished_blackstone_bricks
fill 426 187 478 426 187 481 minecraft:blackstone
setblock 426 187 482 minecraft:polished_blackstone_bricks
fill 426 187 483 426 189 484 minecraft:blackstone
fill 426 187 503 429 187 503 minecraft:blackstone
fill 427 187 464 427 187 465 minecraft:blackstone
setblock 427 187 466 minecraft:polished_blackstone_bricks
setblock 428 187 464 minecraft:blackstone
setblock 428 187 465 minecraft:polished_blackstone_bricks
fill 428 187 466 428 190 466 minecraft:blackstone
setblock 429 187 464 minecraft:polished_blackstone_bricks
fill 429 187 465 432 187 465 minecraft:blackstone
setblock 429 187 504 minecraft:polished_blackstone_bricks
fill 430 187 464 433 187 464 minecraft:blackstone
setblock 430 187 503 minecraft:polished_blackstone_bricks
fill 430 187 504 433 187 504 minecraft:blackstone
fill 431 187 503 431 190 503 minecraft:blackstone
setblock 433 187 465 minecraft:polished_blackstone_bricks
setblock 434 187 464 minecraft:polished_blackstone_bricks
setblock 434 187 504 minecraft:polished_blackstone_bricks
fill 435 187 464 438 187 464 minecraft:blackstone
fill 435 187 477 435 189 477 minecraft:dark_oak_planks
fill 435 187 480 435 189 480 minecraft:dark_oak_planks
fill 435 187 483 435 189 483 minecraft:dark_oak_planks
fill 435 187 486 435 189 486 minecraft:dark_oak_planks
fill 435 187 489 435 189 489 minecraft:dark_oak_planks
fill 435 187 504 438 187 504 minecraft:blackstone
fill 436 187 476 436 189 476 minecraft:dark_oak_planks
fill 437 187 490 437 189 490 minecraft:dark_oak_planks
fill 437 187 503 439 187 503 minecraft:blackstone
setblock 439 187 464 minecraft:polished_blackstone_bricks
fill 439 187 476 439 189 476 minecraft:dark_oak_planks
setblock 439 187 504 minecraft:polished_blackstone_bricks
fill 440 187 464 442 187 465 minecraft:blackstone
fill 440 187 490 440 189 490 minecraft:dark_oak_planks
setblock 440 187 503 minecraft:polished_blackstone_bricks
fill 440 187 504 443 187 504 minecraft:blackstone
setblock 441 187 502 minecraft:polished_blackstone_bricks
fill 441 187 503 444 187 503 minecraft:blackstone
fill 442 187 476 442 189 476 minecraft:dark_oak_planks
fill 442 187 502 445 187 502 minecraft:blackstone
setblock 443 187 464 minecraft:blackstone
setblock 443 187 465 minecraft:polished_blackstone_bricks
fill 443 187 490 443 189 490 minecraft:dark_oak_planks
setblock 444 187 464 minecraft:polished_blackstone_bricks
fill 444 187 465 447 187 465 minecraft:blackstone
setblock 444 187 504 minecraft:polished_blackstone_bricks
fill 445 187 464 448 187 464 minecraft:blackstone
fill 445 187 476 445 189 476 minecraft:dark_oak_planks
setblock 445 187 503 minecraft:polished_blackstone_bricks
fill 445 187 504 448 187 504 minecraft:blackstone
fill 446 187 490 446 189 490 minecraft:dark_oak_planks
setblock 446 187 502 minecraft:polished_blackstone_bricks
fill 446 187 503 449 187 503 minecraft:blackstone
fill 447 187 502 449 188 502 minecraft:blackstone
setblock 448 187 465 minecraft:polished_blackstone_bricks
fill 448 187 476 448 189 476 minecraft:dark_oak_planks
setblock 449 187 464 minecraft:polished_blackstone_bricks
fill 449 187 490 449 189 490 minecraft:dark_oak_planks
setblock 449 187 504 minecraft:polished_blackstone_bricks
fill 450 187 464 451 189 464 minecraft:blackstone
setblock 450 187 503 minecraft:polished_blackstone_bricks
fill 450 187 504 453 187 504 minecraft:blackstone
fill 451 187 476 451 189 476 minecraft:dark_oak_planks
fill 451 187 503 452 187 503 minecraft:blackstone
fill 452 187 490 452 189 490 minecraft:dark_oak_planks
fill 453 187 477 453 189 477 minecraft:dark_oak_planks
fill 453 187 480 453 189 480 minecraft:dark_oak_planks
fill 453 187 483 453 189 483 minecraft:dark_oak_planks
fill 453 187 486 453 189 486 minecraft:dark_oak_planks
fill 453 187 489 453 189 489 minecraft:dark_oak_planks
setblock 454 187 504 minecraft:polished_blackstone_bricks
fill 460 187 504 463 187 504 minecraft:blackstone
fill 461 187 464 463 187 464 minecraft:blackstone
setblock 462 187 480 minecraft:blackstone
setblock 462 187 481 minecraft:polished_blackstone_bricks
fill 462 187 482 462 187 485 minecraft:blackstone
setblock 462 187 486 minecraft:polished_blackstone_bricks
fill 462 187 487 464 188 487 minecraft:blackstone
fill 463 187 476 463 187 479 minecraft:blackstone
setblock 463 187 480 minecraft:polished_blackstone_bricks
fill 463 187 481 463 187 484 minecraft:blackstone
setblock 463 187 485 minecraft:polished_blackstone_bricks
fill 463 187 486 464 189 486 minecraft:blackstone
fill 463 187 488 463 187 489 minecraft:blackstone
setblock 463 187 490 minecraft:polished_blackstone_bricks
setblock 464 187 464 minecraft:polished_blackstone_bricks
fill 464 187 465 464 187 468 minecraft:blackstone
setblock 464 187 469 minecraft:polished_blackstone_bricks
fill 464 187 470 464 187 473 minecraft:blackstone
setblock 464 187 474 minecraft:polished_blackstone_bricks
fill 464 187 475 464 187 478 minecraft:blackstone
setblock 464 187 479 minecraft:polished_blackstone_bricks
fill 464 187 480 464 187 483 minecraft:blackstone
setblock 464 187 484 minecraft:polished_blackstone_bricks
fill 464 187 485 464 190 485 minecraft:blackstone
setblock 464 187 488 minecraft:blackstone
setblock 464 187 489 minecraft:polished_blackstone_bricks
fill 464 187 490 464 187 493 minecraft:blackstone
setblock 464 187 498 minecraft:blackstone
setblock 464 187 499 minecraft:polished_blackstone_bricks
fill 464 187 500 464 187 503 minecraft:blackstone
setblock 464 187 504 minecraft:polished_blackstone_bricks
fill 424 188 464 424 188 467 minecraft:blackstone
setblock 424 188 468 minecraft:polished_blackstone_bricks
fill 424 188 469 424 188 472 minecraft:blackstone
setblock 424 188 473 minecraft:polished_blackstone_bricks
fill 424 188 474 424 188 477 minecraft:blackstone
setblock 424 188 478 minecraft:polished_blackstone_bricks
fill 424 188 479 424 188 482 minecraft:blackstone
setblock 424 188 483 minecraft:polished_blackstone_bricks
fill 424 188 484 424 188 487 minecraft:blackstone
setblock 424 188 488 minecraft:polished_blackstone_bricks
fill 424 188 489 424 191 489 minecraft:blackstone
fill 424 188 491 424 189 491 minecraft:blackstone
fill 424 188 499 424 188 502 minecraft:blackstone
setblock 424 188 503 minecraft:polished_blackstone_bricks
fill 424 188 504 427 188 504 minecraft:blackstone
fill 425 188 464 425 188 466 minecraft:blackstone
setblock 425 188 467 minecraft:polished_blackstone_bricks
fill 425 188 468 425 188 471 minecraft:blackstone
setblock 425 188 472 minecraft:polished_blackstone_bricks
fill 425 188 473 425 188 476 minecraft:blackstone
setblock 425 188 477 minecraft:polished_blackstone_bricks
fill 425 188 478 425 188 481 minecraft:blackstone
setblock 425 188 482 minecraft:polished_blackstone_bricks
fill 425 188 483 425 188 486 minecraft:blackstone
setblock 425 188 487 minecraft:polished_blackstone_bricks
fill 425 188 488 425 191 488 minecraft:blackstone
setblock 425 188 502 minecraft:polished_blackstone_bricks
fill 425 188 503 428 188 503 minecraft:blackstone
fill 426 188 464 426 188 465 minecraft:blackstone
setblock 426 188 466 minecraft:polished_blackstone_bricks
fill 426 188 467 426 189 469 minecraft:blackstone
fill 426 188 479 426 188 480 minecraft:blackstone
setblock 426 188 481 minecraft:polished_blackstone_bricks
fill 426 188 482 426 190 482 minecraft:blackstone
setblock 426 188 485 minecraft:blackstone
setblock 427 188 464 minecraft:blackstone
setblock 427 188 465 minecraft:polished_blackstone_bricks
fill 427 188 466 427 191 466 minecraft:blackstone
setblock 428 188 464 minecraft:polished_blackstone_bricks
fill 428 188 465 431 188 465 minecraft:blackstone
setblock 428 188 504 minecraft:polished_blackstone_bricks
fill 429 188 464 432 188 464 minecraft:blackstone
fill 429 188 466 429 189 466 minecraft:blackstone
setblock 429 188 503 minecraft:polished_blackstone_bricks
fill 429 188 504 432 188 504 minecraft:blackstone
fill 430 188 503 430 191 503 minecraft:blackstone
setblock 432 188 465 minecraft:polished_blackstone_bricks
setblock 433 188 464 minecraft:polished_blackstone_bricks
fill 433 188 465 435 189 465 minecraft:blackstone
setblock 433 188 504 minecraft:polished_blackstone_bricks
fill 434 188 464 437 188 464 minecraft:blackstone
fill 434 188 504 437 188 504 minecraft:blackstone
fill 436 188 503 438 188 503 minecraft:blackstone
setblock 437 188 465 minecraft:polished_blackstone_bricks
setblock 438 188 464 minecraft:polished_blackstone_bricks
fill 438 188 465 441 188 465 minecraft:blackstone
setblock 438 188 504 minecraft:polished_blackstone_bricks
fill 439 188 464 442 188 464 minecraft:blackstone
setblock 439 188 503 minecraft:polished_blackstone_bricks
fill 439 188 504 442 188 504 minecraft:blackstone
setblock 440 188 502 minecraft:polished_blackstone_bricks
fill 440 188 503 443 188 503 minecraft:blackstone
fill 441 188 502 444 188 502 minecraft:blackstone
setblock 442 188 465 minecraft:polished_blackstone_bricks
setblock 443 188 464 minecraft:polished_blackstone_bricks
fill 443 188 465 446 188 465 minecraft:blackstone
setblock 443 188 504 minecraft:polished_blackstone_bricks
fill 444 188 464 447 188 464 minecraft:blackstone
setblock 444 188 503 minecraft:polished_blackstone_bricks
fill 444 188 504 447 188 504 minecraft:blackstone
setblock 445 188 502 minecraft:polished_blackstone_bricks
fill 445 188 503 448 188 503 minecraft:blackstone
fill 446 188 502 446 191 502 minecraft:blackstone
setblock 447 188 465 minecraft:polished_blackstone_bricks
setblock 448 188 464 minecraft:polished_blackstone_bricks
fill 448 188 465 448 191 465 minecraft:blackstone
setblock 448 188 504 minecraft:polished_blackstone_bricks
fill 449 188 464 449 191 464 minecraft:blackstone
setblock 449 188 503 minecraft:polished_blackstone_bricks
fill 449 188 504 452 188 504 minecraft:blackstone
fill 450 188 503 451 189 503 minecraft:blackstone
setblock 453 188 504 minecraft:polished_blackstone_bricks
fill 454 188 504 454 191 504 minecraft:blackstone
setblock 458 188 504 minecraft:polished_blackstone_bricks
fill 459 188 504 462 188 504 minecraft:blackstone
fill 460 188 464 462 188 464 minecraft:blackstone
setblock 462 188 479 minecraft:blackstone
setblock 462 188 480 minecraft:polished_blackstone_bricks
fill 462 188 481 462 188 484 minecraft:blackstone
setblock 462 188 485 minecraft:polished_blackstone_bricks
fill 462 188 486 462 191 486 minecraft:blackstone
fill 462 188 488 463 188 488 minecraft:blackstone
setblock 463 188 464 minecraft:polished_blackstone_bricks
fill 463 188 465 464 188 467 minecraft:blackstone
fill 463 188 475 463 188 478 minecraft:blackstone
setblock 463 188 479 minecraft:polished_blackstone_bricks
fill 463 188 480 463 188 483 minecraft:blackstone
setblock 463 188 484 minecraft:polished_blackstone_bricks
fill 463 188 485 463 191 485 minecraft:blackstone
setblock 463 188 489 minecraft:polished_blackstone_bricks
fill 463 188 490 464 189 491 minecraft:blackstone
setblock 463 188 503 minecraft:blackstone
setblock 463 188 504 minecraft:polished_blackstone_bricks
fill 464 188 464 464 191 464 minecraft:blackstone
setblock 464 188 468 minecraft:polished_blackstone_bricks
fill 464 188 469 464 188 472 minecraft:blackstone
setblock 464 188 473 minecraft:polished_blackstone_bricks
fill 464 188 474 464 188 477 minecraft:blackstone
setblock 464 188 478 minecraft:polished_blackstone_bricks
fill 464 188 479 464 188 482 minecraft:blackstone
setblock 464 188 483 minecraft:polished_blackstone_bricks
fill 464 188 484 464 191 484 minecraft:blackstone
setblock 464 188 488 minecraft:polished_blackstone_bricks
fill 464 188 489 464 191 489 minecraft:blackstone
setblock 464 188 492 minecraft:blackstone
setblock 464 188 493 minecraft:polished_blackstone_bricks
fill 464 188 494 464 190 495 minecraft:blackstone
setblock 464 188 498 minecraft:polished_blackstone_bricks
fill 464 188 499 464 188 502 minecraft:blackstone
setblock 464 188 503 minecraft:polished_blackstone_bricks
fill 464 188 504 464 191 504 minecraft:blackstone
fill 424 189 464 424 189 466 minecraft:blackstone
setblock 424 189 467 minecraft:polished_blackstone_bricks
fill 424 189 468 424 189 471 minecraft:blackstone
setblock 424 189 472 minecraft:polished_blackstone_bricks
fill 424 189 473 424 189 476 minecraft:blackstone
setblock 424 189 477 minecraft:polished_blackstone_bricks
fill 424 189 478 424 189 481 minecraft:blackstone
setblock 424 189 482 minecraft:polished_blackstone_bricks
fill 424 189 483 424 189 486 minecraft:blackstone
setblock 424 189 487 minecraft:polished_blackstone_bricks
fill 424 189 488 424 192 488 minecraft:blackstone
setblock 424 189 492 minecraft:polished_blackstone_bricks
fill 424 189 499 424 189 501 minecraft:blackstone
setblock 424 189 502 minecraft:polished_blackstone_bricks
fill 424 189 503 426 189 504 minecraft:blackstone
fill 425 189 464 425 189 465 minecraft:blackstone
setblock 425 189 466 minecraft:polished_blackstone_bricks
fill 425 189 467 425 189 470 minecraft:blackstone
setblock 425 189 471 minecraft:polished_blackstone_bricks
fill 425 189 472 425 189 475 minecraft:blackstone
setblock 425 189 476 minecraft:polished_blackstone_bricks
fill 425 189 477 425 189 480 minecraft:blackstone
setblock 425 189 481 minecraft:polished_blackstone_bricks
fill 425 189 482 425 189 485 minecraft:blackstone
setblock 425 189 486 minecraft:polished_blackstone_bricks
fill 425 189 487 425 192 487 minecraft:blackstone
fill 425 189 489 425 190 489 minecraft:blackstone
setblock 425 189 501 minecraft:polished_blackstone_bricks
fill 425 189 502 425 192 502 minecraft:blackstone
setblock 426 189 464 minecraft:blackstone
setblock 426 189 465 minecraft:polished_blackstone_bricks
fill 426 189 466 426 192 466 minecraft:blackstone
setblock 426 189 470 minecraft:polished_blackstone_bricks
setblock 426 189 480 minecraft:polished_blackstone_bricks
fill 426 189 481 426 190 481 minecraft:blackstone
setblock 426 189 485 minecraft:polished_blackstone_bricks
setblock 427 189 464 minecraft:polished_blackstone_bricks
fill 427 189 465 430 189 465 minecraft:blackstone
setblock 427 189 503 minecraft:blackstone
setblock 427 189 504 minecraft:polished_blackstone_bricks
fill 428 189 464 431 189 464 minecraft:blackstone
setblock 428 189 503 minecraft:polished_blackstone_bricks
fill 428 189 504 431 189 504 minecraft:blackstone
fill 429 189 503 429 192 503 minecraft:blackstone
setblock 430 189 466 minecraft:polished_blackstone_bricks
setblock 431 189 465 minecraft:polished_blackstone_bricks
setblock 432 189 464 minecraft:polished_blackstone_bricks
fill 432 189 465 432 192 465 minecraft:blackstone
setblock 432 189 504 minecraft:polished_blackstone_bricks
fill 433 189 464 436 189 464 minecraft:blackstone
fill 433 189 504 436 189 504 minecraft:blackstone
fill 435 189 503 437 189 503 minecraft:blackstone
setblock 436 189 465 minecraft:polished_blackstone_bricks
setblock 437 189 464 minecraft:polished_blackstone_bricks
fill 437 189 465 440 189 465 minecraft:blackstone
setblock 437 189 504 minecraft:polished_blackstone_bricks
fill 438 189 464 441 189 464 minecraft:blackstone
setblock 438 189 503 minecraft:polished_blackstone_bricks
fill 438 189 504 441 189 504 minecraft:blackstone
fill 439 189 503 442 189 503 minecraft:blackstone
fill 440 189 502 443 189 502 minecraft:blackstone
setblock 441 189 465 minecraft:polished_blackstone_bricks
setblock 442 189 464 minecraft:polished_blackstone_bricks
fill 442 189 465 444 189 466 minecraft:blackstone
setblock 442 189 504 minecraft:polished_blackstone_bricks
fill 443 189 464 446 189 464 minecraft:blackstone
setblock 443 189 503 minecraft:polished_blackstone_bricks
fill 443 189 504 446 189 504 minecraft:blackstone
setblock 444 189 502 minecraft:polished_blackstone_bricks
fill 444 189 503 447 189 503 minecraft:blackstone
setblock 445 189 465 minecraft:blackstone
fill 445 189 502 445 192 502 minecraft:blackstone
setblock 446 189 465 minecraft:polished_blackstone_bricks
setblock 447 189 464 minecraft:polished_blackstone_bricks
fill 447 189 465 447 192 465 minecraft:blackstone
fill 447 189 502 448 189 502 minecraft:blackstone
setblock 447 189 504 minecraft:polished_blackstone_bricks
fill 448 189 464 448 192 464 minecraft:blackstone
setblock 448 189 503 minecraft:polished_blackstone_bricks
fill 448 189 504 451 189 504 minecraft:blackstone
fill 449 189 503 449 192 503 minecraft:blackstone
setblock 452 189 504 minecraft:polished_blackstone_bricks
fill 453 189 504 453 191 504 minecraft:blackstone
fill 455 189 504 455 190 504 minecraft:blackstone
setblock 457 189 504 minecraft:polished_blackstone_bricks
fill 458 189 464 461 189 464 minecraft:blackstone
fill 458 189 504 461 189 504 minecraft:blackstone
setblock 461 189 465 minecraft:polished_blackstone_bricks
fill 461 189 482 461 189 484 minecraft:blackstone
setblock 461 189 485 minecraft:polished_blackstone_bricks
fill 461 189 486 461 192 486 minecraft:blackstone
setblock 462 189 464 minecraft:polished_blackstone_bricks
fill 462 189 465 464 190 465 minecraft:blackstone
setblock 462 189 479 minecraft:polished_blackstone_bricks
fill 462 189 480 462 189 483 minecraft:blackstone
setblock 462 189 484 minecraft:polished_blackstone_bricks
fill 462 189 485 462 192 485 minecraft:blackstone
fill 462 189 487 462 189 488 minecraft:blackstone
setblock 462 189 489 minecraft:polished_blackstone_bricks
setblock 462 189 503 minecraft:blackstone
setblock 462 189 504 minecraft:polished_blackstone_bricks
fill 463 189 464 463 192 464 minecraft:blackstone
fill 463 189 466 463 189 467 minecraft:blackstone
setblock 463 189 468 minecraft:polished_blackstone_bricks
fill 463 189 469 463 189 472 minecraft:blackstone
setblock 463 189 473 minecraft:polished_blackstone_bricks
fill 463 189 474 463 189 477 minecraft:blackstone
setblock 463 189 478 minecraft:polished_blackstone_bricks
fill 463 189 479 463 189 482 minecraft:blackstone
setblock 463 189 483 minecraft:polished_blackstone_bricks
fill 463 189 484 463 192 484 minecraft:blackstone
setblock 463 189 487 minecraft:blackstone
setblock 463 189 488 minecraft:polished_blackstone_bricks
fill 463 189 489 463 192 489 minecraft:blackstone
setblock 463 189 492 minecraft:blackstone
setblock 463 189 503 minecraft:polished_blackstone_bricks
fill 463 189 504 463 192 504 minecraft:blackstone
setblock 464 189 466 minecraft:blackstone
setblock 464 189 467 minecraft:polished_blackstone_bricks
fill 464 189 468 464 189 471 minecraft:blackstone
setblock 464 189 472 minecraft:polished_blackstone_bricks
fill 464 189 473 464 189 476 minecraft:blackstone
setblock 464 189 477 minecraft:polished_blackstone_bricks
fill 464 189 478 464 189 481 minecraft:blackstone
setblock 464 189 482 minecraft:polished_blackstone_bricks
fill 464 189 483 464 192 483 minecraft:blackstone
setblock 464 189 487 minecraft:polished_blackstone_bricks
fill 464 189 488 464 192 488 minecraft:blackstone
setblock 464 189 492 minecraft:polished_blackstone_bricks
fill 464 189 493 464 192 493 minecraft:blackstone
setblock 464 189 496 minecraft:blackstone
setblock 464 189 497 minecraft:polished_blackstone_bricks
fill 464 189 498 464 189 501 minecraft:blackstone
setblock 464 189 502 minecraft:polished_blackstone_bricks
fill 464 189 503 464 192 503 minecraft:blackstone
fill 424 190 464 424 190 465 minecraft:blackstone
setblock 424 190 466 minecraft:polished_blackstone_bricks
fill 424 190 467 424 190 470 minecraft:blackstone
setblock 424 190 471 minecraft:polished_blackstone_bricks
fill 424 190 472 424 190 475 minecraft:blackstone
setblock 424 190 476 minecraft:polished_blackstone_bricks
fill 424 190 477 424 190 480 minecraft:blackstone
setblock 424 190 481 minecraft:polished_blackstone_bricks
fill 424 190 482 424 190 485 minecraft:blackstone
setblock 424 190 486 minecraft:polished_blackstone_bricks
fill 424 190 487 424 193 487 minecraft:blackstone
setblock 424 190 491 minecraft:polished_blackstone_bricks
fill 424 190 492 424 192 493 minecraft:blackstone
fill 424 190 498 424 190 500 minecraft:blackstone
setblock 424 190 501 minecraft:polished_blackstone_bricks
fill 424 190 502 424 191 504 minecraft:blackstone
setblock 425 190 464 minecraft:blackstone
setblock 425 190 465 minecraft:polished_blackstone_bricks
fill 425 190 466 425 190 469 minecraft:blackstone
setblock 425 190 470 minecraft:polished_blackstone_bricks
fill 425 190 471 425 190 474 minecraft:blackstone
setblock 425 190 475 minecraft:polished_blackstone_bricks
fill 425 190 476 425 190 479 minecraft:blackstone
setblock 425 190 480 minecraft:polished_blackstone_bricks
fill 425 190 481 425 190 484 minecraft:blackstone
setblock 425 190 485 minecraft:polished_blackstone_bricks
fill 425 190 486 426 191 486 minecraft:blackstone
setblock 425 190 490 minecraft:polished_blackstone_bricks
setblock 425 190 501 minecraft:blackstone
fill 425 190 503 425 190 504 minecraft:blackstone
setblock 426 190 464 minecraft:polished_blackstone_bricks
fill 426 190 465 429 190 465 minecraft:blackstone
fill 426 190 467 426 190 468 minecraft:blackstone
setblock 426 190 469 minecraft:polished_blackstone_bricks
fill 426 190 470 426 192 471 minecraft:blackstone
setblock 426 190 483 minecraft:blackstone
setblock 426 190 484 minecraft:polished_blackstone_bricks
fill 426 190 485 426 191 485 minecraft:blackstone
setblock 426 190 503 minecraft:blackstone
setblock 426 190 504 minecraft:polished_blackstone_bricks
fill 427 190 464 430 190 464 minecraft:blackstone
setblock 427 190 467 minecraft:blackstone
setblock 427 190 503 minecraft:polished_blackstone_bricks
fill 427 190 504 430 190 504 minecraft:blackstone
fill 428 190 503 428 192 503 minecraft:blackstone
setblock 429 190 466 minecraft:polished_blackstone_bricks
setblock 430 190 465 minecraft:polished_blackstone_bricks
fill 430 190 466 431 192 466 minecraft:blackstone
setblock 431 190 464 minecraft:polished_blackstone_bricks
fill 431 190 465 431 193 465 minecraft:blackstone
setblock 431 190 504 minecraft:polished_blackstone_bricks
fill 432 190 464 435 190 464 minecraft:blackstone
fill 432 190 504 435 190 504 minecraft:blackstone
fill 433 190 465 434 190 465 minecraft:blackstone
setblock 435 190 465 minecraft:polished_blackstone_bricks
setblock 435 190 477 minecraft:ochre_froglight
setblock 435 190 480 minecraft:ochre_froglight
setblock 435 190 483 minecraft:ochre_froglight
setblock 435 190 486 minecraft:ochre_froglight
setblock 435 190 489 minecraft:ochre_froglight
fill 435 190 503 436 190 503 minecraft:blackstone
setblock 436 190 464 minecraft:polished_blackstone_bricks
fill 436 190 465 439 190 465 minecraft:blackstone
setblock 436 190 476 minecraft:ochre_froglight
setblock 436 190 504 minecraft:polished_blackstone_bricks
fill 437 190 464 440 190 464 minecraft:blackstone
setblock 437 190 490 minecraft:ochre_froglight
setblock 437 190 503 minecraft:polished_blackstone_bricks
fill 437 190 504 440 190 504 minecraft:blackstone
fill 438 190 503 441 190 503 minecraft:blackstone
setblock 439 190 466 minecraft:polished_blackstone_bricks
setblock 439 190 476 minecraft:ochre_froglight
fill 439 190 502 442 190 502 minecraft:blackstone
setblock 440 190 465 minecraft:polished_blackstone_bricks
fill 440 190 466 443 190 466 minecraft:blackstone
setblock 440 190 490 minecraft:ochre_froglight
setblock 441 190 464 minecraft:polished_blackstone_bricks
fill 441 190 465 444 190 465 minecraft:blackstone
setblock 441 190 504 minecraft:polished_blackstone_bricks
fill 442 190 464 445 190 464 minecraft:blackstone
setblock 442 190 476 minecraft:ochre_froglight
setblock 442 190 503 minecraft:polished_blackstone_bricks
fill 442 190 504 445 190 504 minecraft:blackstone
setblock 443 190 490 minecraft:ochre_froglight
setblock 443 190 502 minecraft:polished_blackstone_bricks
fill 443 190 503 446 190 503 minecraft:blackstone
setblock 444 190 466 minecraft:polished_blackstone_bricks
fill 444 190 502 444 193 502 minecraft:blackstone
setblock 445 190 465 minecraft:polished_blackstone_bricks
fill 445 190 466 445 193 466 minecraft:blackstone
setblock 445 190 476 minecraft:ochre_froglight
setblock 446 190 464 minecraft:polished_blackstone_bricks
fill 446 190 465 446 193 465 minecraft:blackstone
setblock 446 190 490 minecraft:ochre_froglight
setblock 446 190 504 minecraft:polished_blackstone_bricks
fill 447 190 464 447 193 464 minecraft:blackstone
setblock 447 190 502 minecraft:blackstone
setblock 447 190 503 minecraft:polished_blackstone_bricks
fill 447 190 504 450 190 504 minecraft:blackstone
setblock 448 190 476 minecraft:ochre_froglight
setblock 448 190 502 minecraft:polished_blackstone_bricks
fill 448 190 503 448 193 503 minecraft:blackstone
setblock 449 190 490 minecraft:ochre_froglight
setblock 450 190 464 minecraft:blackstone
fill 450 190 503 450 191 503 minecraft:blackstone
setblock 451 190 464 minecraft:polished_blackstone_bricks
setblock 451 190 476 minecraft:ochre_froglight
setblock 451 190 504 minecraft:polished_blackstone_bricks
fill 452 190 464 452 192 464 minecraft:blackstone
setblock 452 190 490 minecraft:ochre_froglight
fill 452 190 504 452 192 504 minecraft:blackstone
setblock 453 190 477 minecraft:ochre_froglight
setblock 453 190 480 minecraft:ochre_froglight
setblock 453 190 483 minecraft:ochre_froglight
setblock 453 190 486 minecraft:ochre_froglight
setblock 453 190 489 minecraft:ochre_froglight
setblock 456 190 504 minecraft:polished_blackstone_bricks
fill 457 190 464 460 190 464 minecraft:blackstone
fill 457 190 504 460 190 504 minecraft:blackstone
setblock 460 190 465 minecraft:polished_blackstone_bricks
setblock 461 190 464 minecraft:polished_blackstone_bricks
fill 461 190 465 461 193 465 minecraft:blackstone
fill 461 190 482 461 190 483 minecraft:blackstone
setblock 461 190 484 minecraft:polished_blackstone_bricks
fill 461 190 485 461 193 485 minecraft:blackstone
fill 461 190 487 461 190 488 minecraft:blackstone
setblock 461 190 504 minecraft:polished_blackstone_bricks
fill 462 190 464 462 193 464 minecraft:blackstone
fill 462 190 466 463 190 466 minecraft:blackstone
setblock 462 190 478 minecraft:polished_blackstone_bricks
fill 462 190 479 462 190 482 minecraft:blackstone
setblock 462 190 483 minecraft:polished_blackstone_bricks
fill 462 190 484 462 193 484 minecraft:blackstone
setblock 462 190 487 minecraft:blackstone
setblock 462 190 488 minecraft:polished_blackstone_bricks
fill 462 190 489 462 192 490 minecraft:blackstone
setblock 462 190 503 minecraft:polished_blackstone_bricks
fill 462 190 504 462 193 504 minecraft:blackstone
setblock 463 190 467 minecraft:polished_blackstone_bricks
fill 463 190 468 463 190 471 minecraft:blackstone
setblock 463 190 472 minecraft:polished_blackstone_bricks
fill 463 190 473 463 190 476 minecraft:blackstone
setblock 463 190 477 minecraft:polished_blackstone_bricks
fill 463 190 478 463 190 481 minecraft:blackstone
setblock 463 190 482 minecraft:polished_blackstone_bricks
fill 463 190 483 463 193 483 minecraft:blackstone
setblock 463 190 486 minecraft:blackstone
setblock 463 190 487 minecraft:polished_blackstone_bricks
fill 463 190 488 463 193 488 minecraft:blackstone
fill 463 190 490 463 190 491 minecraft:blackstone
setblock 463 190 492 minecraft:polished_blackstone_bricks
fill 463 190 493 463 193 493 minecraft:blackstone
setblock 463 190 502 minecraft:polished_blackstone_bricks
fill 463 190 503 463 192 503 minecraft:blackstone
setblock 464 190 466 minecraft:polished_blackstone_bricks
fill 464 190 467 464 190 470 minecraft:blackstone
setblock 464 190 471 minecraft:polished_blackstone_bricks
fill 464 190 472 464 190 475 minecraft:blackstone
setblock 464 190 476 minecraft:polished_blackstone_bricks
fill 464 190 477 464 190 480 minecraft:blackstone
setblock 464 190 481 minecraft:polished_blackstone_bricks
fill 464 190 482 464 193 482 minecraft:blackstone
setblock 464 190 486 minecraft:polished_blackstone_bricks
fill 464 190 487 464 193 487 minecraft:blackstone
setblock 464 190 490 minecraft:blackstone
setblock 464 190 491 minecraft:polished_blackstone_bricks
fill 464 190 492 464 193 492 minecraft:blackstone
setblock 464 190 496 minecraft:polished_blackstone_bricks
fill 464 190 497 464 190 500 minecraft:blackstone
setblock 464 190 501 minecraft:polished_blackstone_bricks
fill 464 190 502 464 193 502 minecraft:blackstone
setblock 424 191 464 minecraft:blackstone
setblock 424 191 465 minecraft:polished_blackstone_bricks
fill 424 191 466 424 191 469 minecraft:blackstone
setblock 424 191 470 minecraft:polished_blackstone_bricks
fill 424 191 471 424 191 474 minecraft:blackstone
setblock 424 191 475 minecraft:polished_blackstone_bricks
fill 424 191 476 424 191 479 minecraft:blackstone
setblock 424 191 480 minecraft:polished_blackstone_bricks
fill 424 191 481 424 191 484 minecraft:blackstone
setblock 424 191 485 minecraft:polished_blackstone_bricks
fill 424 191 486 424 194 486 minecraft:blackstone
setblock 424 191 490 minecraft:polished_blackstone_bricks
fill 424 191 491 425 193 491 minecraft:blackstone
setblock 424 191 494 minecraft:blackstone
setblock 424 191 495 minecraft:polished_blackstone_bricks
fill 424 191 498 424 191 499 minecraft:blackstone
setblock 424 191 500 minecraft:polished_blackstone_bricks
fill 424 191 501 424 194 501 minecraft:blackstone
setblock 425 191 464 minecraft:polished_blackstone_bricks
fill 425 191 465 425 191 468 minecraft:blackstone
setblock 425 191 469 minecraft:polished_blackstone_bricks
fill 425 191 470 425 191 473 minecraft:blackstone
setblock 425 191 474 minecraft:polished_blackstone_bricks
fill 425 191 475 425 191 478 minecraft:blackstone
setblock 425 191 479 minecraft:polished_blackstone_bricks
fill 425 191 480 425 191 483 minecraft:blackstone
setblock 425 191 484 minecraft:polished_blackstone_bricks
fill 425 191 485 425 194 485 minecraft:blackstone
setblock 425 191 489 minecraft:polished_blackstone_bricks
fill 425 191 490 425 194 490 minecraft:blackstone
setblock 425 191 503 minecraft:blackstone
setblock 425 191 504 minecraft:polished_blackstone_bricks
fill 426 191 464 428 191 465 minecraft:blackstone
setblock 426 191 467 minecraft:blackstone
setblock 426 191 468 minecraft:polished_blackstone_bricks
fill 426 191 469 426 194 469 minecraft:blackstone
setblock 426 191 483 minecraft:polished_blackstone_bricks
setblock 426 191 484 minecraft:blackstone
setblock 426 191 503 minecraft:polished_blackstone_bricks
fill 426 191 504 429 191 504 minecraft:blackstone
setblock 427 191 467 minecraft:polished_blackstone_bricks
fill 427 191 468 427 193 468 minecraft:blackstone
fill 427 191 503 427 193 503 minecraft:blackstone
setblock 428 191 466 minecraft:polished_blackstone_bricks
setblock 429 191 464 minecraft:blackstone
setblock 429 191 465 minecraft:polished_blackstone_bricks
fill 429 191 466 429 194 466 minecraft:blackstone
setblock 430 191 464 minecraft:polished_blackstone_bricks
fill 430 191 465 430 194 465 minecraft:blackstone
setblock 430 191 504 minecraft:polished_blackstone_bricks
fill 431 191 464 434 191 464 minecraft:blackstone
fill 431 191 504 434 191 504 minecraft:blackstone
setblock 433 191 465 minecraft:blackstone
setblock 434 191 465 minecraft:polished_blackstone_bricks
fill 434 191 503 435 191 503 minecraft:blackstone
setblock 435 191 464 minecraft:polished_blackstone_bricks
fill 435 191 465 438 191 465 minecraft:blackstone
fill 435 191 477 453 191 477 minecraft:dark_oak_planks
fill 435 191 480 440 191 480 minecraft:dark_oak_planks
fill 435 191 483 440 191 483 minecraft:dark_oak_planks
fill 435 191 486 440 191 486 minecraft:dark_oak_planks
fill 435 191 489 453 191 489 minecraft:dark_oak_planks
setblock 435 191 504 minecraft:polished_blackstone_bricks
fill 436 191 464 439 191 464 minecraft:blackstone
setblock 436 191 476 minecraft:dark_oak_planks
fill 436 191 478 452 191 479 minecraft:dark_oak_planks
fill 436 191 481 440 191 482 minecraft:dark_oak_planks
fill 436 191 484 440 191 485 minecraft:dark_oak_planks
fill 436 191 487 440 191 488 minecraft:dark_oak_planks
setblock 436 191 503 minecraft:polished_blackstone_bricks
fill 436 191 504 439 191 504 minecraft:blackstone
setblock 437 191 466 minecraft:blackstone
setblock 437 191 490 minecraft:dark_oak_planks
fill 437 191 503 440 191 503 minecraft:blackstone
setblock 438 191 466 minecraft:polished_blackstone_bricks
setblock 439 191 465 minecraft:polished_blackstone_bricks
fill 439 191 466 442 191 466 minecraft:blackstone
setblock 439 191 476 minecraft:dark_oak_planks
fill 439 191 502 441 191 502 minecraft:blackstone
setblock 440 191 464 minecraft:polished_blackstone_bricks
fill 440 191 465 443 191 465 minecraft:blackstone
setblock 440 191 490 minecraft:dark_oak_planks
setblock 440 191 504 minecraft:polished_blackstone_bricks
fill 441 191 464 444 191 464 minecraft:blackstone
fill 441 191 488 452 191 488 minecraft:dark_oak_planks
setblock 441 191 503 minecraft:polished_blackstone_bricks
fill 441 191 504 444 191 504 minecraft:blackstone
setblock 442 191 476 minecraft:dark_oak_planks
setblock 442 191 502 minecraft:polished_blackstone_bricks
fill 442 191 503 445 191 503 minecraft:blackstone
setblock 443 191 466 minecraft:polished_blackstone_bricks
setblock 443 191 490 minecraft:dark_oak_planks
fill 443 191 502 443 194 502 minecraft:blackstone
setblock 444 191 465 minecraft:polished_blackstone_bricks
fill 444 191 466 444 194 466 minecraft:blackstone
setblock 445 191 464 minecraft:polished_blackstone_bricks
fill 445 191 465 445 194 465 minecraft:blackstone
setblock 445 191 476 minecraft:dark_oak_planks
setblock 445 191 504 minecraft:polished_blackstone_bricks
fill 446 191 464 446 194 464 minecraft:blackstone
setblock 446 191 466 minecraft:blackstone
setblock 446 191 490 minecraft:dark_oak_planks
setblock 446 191 503 minecraft:polished_blackstone_bricks
fill 446 191 504 449 191 504 minecraft:blackstone
setblock 447 191 502 minecraft:polished_blackstone_bricks
fill 447 191 503 447 193 503 minecraft:blackstone
setblock 448 191 476 minecraft:dark_oak_planks
fill 449 191 480 452 191 487 minecraft:dark_oak_planks
setblock 449 191 490 minecraft:dark_oak_planks
setblock 450 191 464 minecraft:polished_blackstone_bricks
setblock 450 191 504 minecraft:polished_blackstone_bricks
fill 451 191 464 451 193 464 minecraft:blackstone
setblock 451 191 476 minecraft:dark_oak_planks
fill 451 191 504 451 193 504 minecraft:blackstone
setblock 452 191 490 minecraft:dark_oak_planks
setblock 453 191 480 minecraft:dark_oak_planks
setblock 453 191 483 minecraft:dark_oak_planks
setblock 453 191 486 minecraft:dark_oak_planks
setblock 455 191 464 minecraft:polished_blackstone_bricks
setblock 455 191 504 minecraft:polished_blackstone_bricks
fill 456 191 464 459 191 464 minecraft:blackstone
fill 456 191 504 459 191 504 minecraft:blackstone
setblock 458 191 465 minecraft:blackstone
setblock 459 191 465 minecraft:polished_blackstone_bricks
setblock 460 191 464 minecraft:polished_blackstone_bricks
fill 460 191 465 460 194 465 minecraft:blackstone
setblock 460 191 504 minecraft:polished_blackstone_bricks
fill 461 191 464 461 194 464 minecraft:blackstone
fill 461 191 466 462 191 466 minecraft:blackstone
fill 461 191 481 461 191 482 minecraft:blackstone
setblock 461 191 483 minecraft:polished_blackstone_bricks
fill 461 191 484 461 194 484 minecraft:blackstone
setblock 461 191 487 minecraft:blackstone
setblock 461 191 488 minecraft:polished_blackstone_bricks
fill 461 191 489 461 194 489 minecraft:blackstone
setblock 461 191 503 minecraft:polished_blackstone_bricks
fill 461 191 504 461 194 504 minecraft:blackstone
fill 462 191 465 463 191 465 minecraft:blackstone
setblock 462 191 467 minecraft:polished_blackstone_bricks
fill 462 191 468 463 191 470 minecraft:blackstone
setblock 462 191 477 minecraft:polished_blackstone_bricks
fill 462 191 478 462 191 481 minecraft:blackstone
setblock 462 191 482 minecraft:polished_blackstone_bricks
fill 462 191 483 462 194 483 minecraft:blackstone
setblock 462 191 487 minecraft:polished_blackstone_bricks
fill 462 191 488 462 194 488 minecraft:blackstone
setblock 462 191 491 minecraft:blackstone
fill 462 191 503 462 192 503 minecraft:blackstone
setblock 463 191 466 minecraft:polished_blackstone_bricks
fill 463 191 467 464 193 467 minecraft:blackstone
setblock 463 191 471 minecraft:polished_blackstone_bricks
fill 463 191 472 463 191 475 minecraft:blackstone
setblock 463 191 476 minecraft:polished_blackstone_bricks
fill 463 191 477 463 191 480 minecraft:blackstone
setblock 463 191 481 minecraft:polished_blackstone_bricks
fill 463 191 482 463 194 482 minecraft:blackstone
setblock 463 191 486 minecraft:polished_blackstone_bricks
fill 463 191 487 463 194 487 minecraft:blackstone
setblock 463 191 490 minecraft:blackstone
setblock 463 191 491 minecraft:polished_blackstone_bricks
fill 463 191 492 463 194 492 minecraft:blackstone
fill 463 191 494 464 191 494 minecraft:blackstone
setblock 464 191 465 minecraft:polished_blackstone_bricks
fill 464 191 466 464 194 466 minecraft:blackstone
fill 464 191 468 464 191 469 minecraft:blackstone
setblock 464 191 470 minecraft:polished_blackstone_bricks
fill 464 191 471 464 191 474 minecraft:blackstone
setblock 464 191 475 minecraft:polished_blackstone_bricks
fill 464 191 476 464 191 479 minecraft:blackstone
setblock 464 191 480 minecraft:polished_blackstone_bricks
fill 464 191 481 464 194 481 minecraft:blackstone
setblock 464 191 485 minecraft:polished_blackstone_bricks
fill 464 191 486 464 194 486 minecraft:blackstone
setblock 464 191 490 minecraft:polished_blackstone_bricks
fill 464 191 491 464 194 491 minecraft:blackstone
setblock 464 191 495 minecraft:polished_blackstone_bricks
fill 464 191 496 464 191 499 minecraft:blackstone
setblock 464 191 500 minecraft:polished_blackstone_bricks
fill 464 191 501 464 193 501 minecraft:blackstone
setblock 424 192 464 minecraft:polished_blackstone_bricks
fill 424 192 465 424 192 468 minecraft:blackstone
setblock 424 192 469 minecraft:polished_blackstone_bricks
fill 424 192 470 424 192 473 minecraft:blackstone
setblock 424 192 474 minecraft:polished_blackstone_bricks
fill 424 192 475 424 192 478 minecraft:blackstone
setblock 424 192 479 minecraft:polished_blackstone_bricks
fill 424 192 480 424 192 483 minecraft:blackstone
setblock 424 192 484 minecraft:polished_blackstone_bricks
fill 424 192 485 424 195 485 minecraft:blackstone
setblock 424 192 489 minecraft:polished_blackstone_bricks
fill 424 192 490 424 195 490 minecraft:blackstone
setblock 424 192 494 minecraft:polished_blackstone_bricks
fill 424 192 495 424 192 498 minecraft:blackstone
setblock 424 192 499 minecraft:polished_blackstone_bricks
fill 424 192 500 424 194 500 minecraft:blackstone
fill 424 192 502 424 192 503 minecraft:blackstone
setblock 424 192 504 minecraft:polished_blackstone_bricks
fill 425 192 464 425 192 467 minecraft:blackstone
setblock 425 192 468 minecraft:polished_blackstone_bricks
fill 425 192 469 425 192 472 minecraft:blackstone
setblock 425 192 473 minecraft:polished_blackstone_bricks
fill 425 192 474 425 192 477 minecraft:blackstone
setblock 425 192 478 minecraft:polished_blackstone_bricks
fill 425 192 479 425 192 482 minecraft:blackstone
setblock 425 192 483 minecraft:polished_blackstone_bricks
fill 425 192 484 425 194 484 minecraft:blackstone
fill 425 192 486 425 193 486 minecraft:blackstone
setblock 425 192 488 minecraft:polished_blackstone_bricks
fill 425 192 489 425 195 489 minecraft:blackstone
setblock 425 192 503 minecraft:polished_blackstone_bricks
fill 425 192 504 428 192 504 minecraft:blackstone
fill 426 192 464 427 192 465 minecraft:blackstone
setblock 426 192 467 minecraft:polished_blackstone_bricks
fill 426 192 468 426 195 468 minecraft:blackstone
setblock 426 192 472 minecraft:polished_blackstone_bricks
setblock 426 192 474 minecraft:light[level=11]
setblock 426 192 482 minecraft:light[level=11]
setblock 426 192 490 minecraft:light[level=11]
setblock 426 192 498 minecraft:light[level=11]
fill 426 192 503 426 193 503 minecraft:blackstone
setblock 427 192 466 minecraft:polished_blackstone_bricks
fill 427 192 467 427 194 467 minecraft:blackstone
setblock 428 192 464 minecraft:blackstone
setblock 428 192 465 minecraft:polished_blackstone_bricks
fill 428 192 466 428 195 466 minecraft:blackstone
setblock 429 192 464 minecraft:polished_blackstone_bricks
fill 429 192 465 429 195 465 minecraft:blackstone
setblock 429 192 504 minecraft:polished_blackstone_bricks
fill 430 192 464 433 192 464 minecraft:blackstone
fill 430 192 504 433 192 504 minecraft:blackstone
setblock 432 192 466 minecraft:polished_blackstone_bricks
setblock 433 192 465 minecraft:polished_blackstone_bricks
setblock 434 192 464 minecraft:polished_blackstone_bricks
fill 434 192 465 437 192 465 minecraft:blackstone
setblock 434 192 466 minecraft:light[level=11]
setblock 434 192 474 minecraft:light[level=11]
setblock 434 192 482 minecraft:light[level=11]
setblock 434 192 490 minecraft:light[level=11]
setblock 434 192 498 minecraft:light[level=11]
setblock 434 192 503 minecraft:blackstone
setblock 434 192 504 minecraft:polished_blackstone_bricks
fill 435 192 464 438 192 464 minecraft:blackstone
fill 435 192 476 440 192 490 minecraft:deepslate_tiles
setblock 435 192 503 minecraft:polished_blackstone_bricks
fill 435 192 504 438 192 504 minecraft:blackstone
setblock 436 192 466 minecraft:blackstone
fill 436 192 503 439 192 503 minecraft:blackstone
setblock 437 192 466 minecraft:polished_blackstone_bricks
setblock 438 192 465 minecraft:polished_blackstone_bricks
fill 438 192 466 441 192 466 minecraft:blackstone
fill 438 192 502 440 192 502 minecraft:blackstone
setblock 439 192 464 minecraft:polished_blackstone_bricks
fill 439 192 465 442 192 465 minecraft:blackstone
setblock 439 192 504 minecraft:polished_blackstone_bricks
fill 440 192 464 443 192 464 minecraft:blackstone
setblock 440 192 503 minecraft:polished_blackstone_bricks
fill 440 192 504 443 192 504 minecraft:blackstone
fill 441 192 476 453 192 479 minecraft:deepslate_tiles
fill 441 192 488 453 192 490 minecraft:deepslate_tiles
fill 441 192 491 442 193 492 minecraft:light_blue_stained_glass
setblock 441 192 502 minecraft:polished_blackstone_bricks
fill 441 192 503 444 192 503 minecraft:blackstone
setblock 442 192 466 minecraft:polished_blackstone_bricks
setblock 442 192 474 minecraft:light[level=11]
setblock 442 192 498 minecraft:light[level=11]
fill 442 192 502 442 195 502 minecraft:blackstone
setblock 443 192 465 minecraft:polished_blackstone_bricks
fill 443 192 466 443 195 466 minecraft:blackstone
setblock 444 192 464 minecraft:polished_blackstone_bricks
fill 444 192 465 444 195 465 minecraft:blackstone
setblock 444 192 504 minecraft:polished_blackstone_bricks
fill 445 192 464 445 195 464 minecraft:blackstone
setblock 445 192 503 minecraft:polished_blackstone_bricks
fill 445 192 504 448 192 504 minecraft:blackstone
setblock 446 192 502 minecraft:polished_blackstone_bricks
fill 446 192 503 446 194 503 minecraft:blackstone
setblock 448 192 465 minecraft:polished_blackstone_bricks
setblock 449 192 464 minecraft:polished_blackstone_bricks
fill 449 192 480 453 192 487 minecraft:deepslate_tiles
setblock 449 192 504 minecraft:polished_blackstone_bricks
fill 450 192 464 450 193 464 minecraft:blackstone
setblock 450 192 466 minecraft:light[level=11]
setblock 450 192 474 minecraft:light[level=11]
setblock 450 192 498 minecraft:light[level=11]
fill 450 192 504 450 193 504 minecraft:blackstone
setblock 454 192 464 minecraft:polished_blackstone_bricks
fill 455 192 464 458 192 464 minecraft:blackstone
fill 456 192 504 458 192 504 minecraft:blackstone
setblock 458 192 465 minecraft:polished_blackstone_bricks
setblock 458 192 466 minecraft:light[level=11]
setblock 458 192 474 minecraft:light[level=11]
setblock 458 192 482 minecraft:light[level=11]
setblock 458 192 490 minecraft:light[level=11]
setblock 458 192 498 minecraft:light[level=11]
setblock 459 192 464 minecraft:polished_blackstone_bricks
fill 459 192 465 459 195 465 minecraft:blackstone
setblock 459 192 504 minecraft:polished_blackstone_bricks
fill 460 192 464 460 195 464 minecraft:blackstone
fill 460 192 466 461 192 466 minecraft:blackstone
fill 460 192 504 460 195 504 minecraft:blackstone
setblock 461 192 481 minecraft:blackstone
setblock 461 192 482 minecraft:polished_blackstone_bricks
fill 461 192 483 461 194 483 minecraft:blackstone
setblock 461 192 487 minecraft:polished_blackstone_bricks
fill 461 192 488 461 195 488 minecraft:blackstone
fill 461 192 490 461 193 490 minecraft:blackstone
setblock 462 192 465 minecraft:blackstone
setblock 462 192 466 minecraft:polished_blackstone_bricks
fill 462 192 467 462 192 470 minecraft:blackstone
setblock 462 192 471 minecraft:polished_blackstone_bricks
fill 462 192 472 463 192 474 minecraft:blackstone
setblock 462 192 476 minecraft:polished_blackstone_bricks
fill 462 192 477 462 192 480 minecraft:blackstone
setblock 462 192 481 minecraft:polished_blackstone_bricks
fill 462 192 482 462 195 482 minecraft:blackstone
setblock 462 192 486 minecraft:polished_blackstone_bricks
fill 462 192 487 462 195 487 minecraft:blackstone
setblock 462 192 491 minecraft:polished_blackstone_bricks
fill 462 192 492 462 195 492 minecraft:blackstone
setblock 463 192 465 minecraft:polished_blackstone_bricks
fill 463 192 466 463 195 466 minecraft:blackstone
fill 463 192 468 463 192 469 minecraft:blackstone
setblock 463 192 470 minecraft:polished_blackstone_bricks
fill 463 192 471 464 194 471 minecraft:blackstone
setblock 463 192 475 minecraft:polished_blackstone_bricks
fill 463 192 476 463 192 479 minecraft:blackstone
setblock 463 192 480 minecraft:polished_blackstone_bricks
fill 463 192 481 463 195 481 minecraft:blackstone
setblock 463 192 485 minecraft:polished_blackstone_bricks
fill 463 192 486 463 195 486 minecraft:blackstone
setblock 463 192 490 minecraft:polished_blackstone_bricks
fill 463 192 491 463 195 491 minecraft:blackstone
setblock 463 192 494 minecraft:blackstone
setblock 464 192 464 minecraft:polished_blackstone_bricks
fill 464 192 465 464 195 465 minecraft:blackstone
setblock 464 192 468 minecraft:blackstone
setblock 464 192 469 minecraft:polished_blackstone_bricks
fill 464 192 470 464 195 470 minecraft:blackstone
fill 464 192 472 464 192 473 minecraft:blackstone
setblock 464 192 474 minecraft:polished_blackstone_bricks
fill 464 192 475 464 192 478 minecraft:blackstone
setblock 464 192 479 minecraft:polished_blackstone_bricks
fill 464 192 480 464 195 480 minecraft:blackstone
setblock 464 192 484 minecraft:polished_blackstone_bricks
fill 464 192 485 464 195 485 minecraft:blackstone
setblock 464 192 489 minecraft:polished_blackstone_bricks
fill 464 192 490 464 195 490 minecraft:blackstone
setblock 464 192 494 minecraft:polished_blackstone_bricks
fill 464 192 495 464 192 498 minecraft:blackstone
setblock 464 192 499 minecraft:polished_blackstone_bricks
fill 464 192 500 464 193 500 minecraft:blackstone
setblock 464 192 504 minecraft:polished_blackstone_bricks
fill 424 193 464 424 193 467 minecraft:blackstone
setblock 424 193 468 minecraft:polished_blackstone_bricks
fill 424 193 469 424 193 472 minecraft:blackstone
setblock 424 193 473 minecraft:polished_blackstone_bricks
fill 424 193 474 424 193 477 minecraft:blackstone
setblock 424 193 478 minecraft:polished_blackstone_bricks
fill 424 193 479 424 193 482 minecraft:blackstone
setblock 424 193 483 minecraft:polished_blackstone_bricks
fill 424 193 484 424 196 484 minecraft:blackstone
setblock 424 193 488 minecraft:polished_blackstone_bricks
fill 424 193 489 424 196 489 minecraft:blackstone
setblock 424 193 492 minecraft:blackstone
setblock 424 193 493 minecraft:polished_blackstone_bricks
fill 424 193 494 424 193 497 minecraft:blackstone
setblock 424 193 498 minecraft:polished_blackstone_bricks
fill 424 193 499 424 194 499 minecraft:blackstone
setblock 424 193 502 minecraft:blackstone
setblock 424 193 503 minecraft:polished_blackstone_bricks
fill 424 193 504 427 193 504 minecraft:blackstone
fill 425 193 464 425 193 466 minecraft:blackstone
setblock 425 193 467 minecraft:polished_blackstone_bricks
fill 425 193 468 425 193 471 minecraft:blackstone
setblock 425 193 472 minecraft:polished_blackstone_bricks
fill 425 193 473 425 193 476 minecraft:blackstone
setblock 425 193 477 minecraft:polished_blackstone_bricks
fill 425 193 478 425 193 481 minecraft:blackstone
setblock 425 193 482 minecraft:polished_blackstone_bricks
fill 425 193 483 425 194 483 minecraft:blackstone
setblock 425 193 487 minecraft:polished_blackstone_bricks
fill 425 193 488 425 195 488 minecraft:blackstone
setblock 425 193 502 minecraft:polished_blackstone_bricks
fill 425 193 503 425 194 503 minecraft:blackstone
fill 426 193 464 426 193 465 minecraft:blackstone
setblock 426 193 466 minecraft:polished_blackstone_bricks
fill 426 193 467 426 196 467 minecraft:blackstone
setblock 426 193 470 minecraft:blackstone
setblock 426 193 471 minecraft:polished_blackstone_bricks
setblock 426 193 472 minecraft:blackstone
setblock 427 193 464 minecraft:blackstone
setblock 427 193 465 minecraft:polished_blackstone_bricks
fill 427 193 466 427 196 466 minecraft:blackstone
setblock 428 193 464 minecraft:polished_blackstone_bricks
fill 428 193 465 428 196 465 minecraft:blackstone
setblock 428 193 504 minecraft:polished_blackstone_bricks
fill 429 193 464 432 193 464 minecraft:blackstone
fill 429 193 504 432 193 504 minecraft:blackstone
setblock 430 193 466 minecraft:blackstone
setblock 431 193 466 minecraft:polished_blackstone_bricks
setblock 432 193 465 minecraft:polished_blackstone_bricks
setblock 433 193 464 minecraft:polished_blackstone_bricks
fill 433 193 465 436 193 465 minecraft:blackstone
setblock 433 193 504 minecraft:polished_blackstone_bricks
fill 434 193 464 437 193 464 minecraft:blackstone
fill 434 193 504 437 193 504 minecraft:blackstone
setblock 435 193 466 minecraft:blackstone
fill 435 193 503 438 193 503 minecraft:blackstone
setblock 436 193 466 minecraft:polished_blackstone_bricks
fill 436 193 477 440 193 489 minecraft:deepslate_tiles
setblock 437 193 465 minecraft:polished_blackstone_bricks
fill 437 193 466 440 193 466 minecraft:blackstone
setblock 438 193 464 minecraft:polished_blackstone_bricks
fill 438 193 465 441 193 465 minecraft:blackstone
fill 438 193 502 439 193 502 minecraft:blackstone
setblock 438 193 504 minecraft:polished_blackstone_bricks
fill 439 193 464 442 193 464 minecraft:blackstone
setblock 439 193 503 minecraft:polished_blackstone_bricks
fill 439 193 504 442 193 504 minecraft:blackstone
setblock 440 193 502 minecraft:polished_blackstone_bricks
fill 440 193 503 443 193 503 minecraft:blackstone
setblock 441 193 466 minecraft:polished_blackstone_bricks
fill 441 193 477 452 193 479 minecraft:deepslate_tiles
fill 441 193 488 452 193 489 minecraft:deepslate_tiles
fill 441 193 502 441 195 502 minecraft:blackstone
setblock 442 193 465 minecraft:polished_blackstone_bricks
fill 442 193 466 442 195 466 minecraft:blackstone
setblock 443 193 464 minecraft:polished_blackstone_bricks
fill 443 193 465 443 196 465 minecraft:blackstone
setblock 443 193 504 minecraft:polished_blackstone_bricks
fill 444 193 464 444 196 464 minecraft:blackstone
setblock 444 193 503 minecraft:polished_blackstone_bricks
fill 444 193 504 447 193 504 minecraft:blackstone
setblock 445 193 502 minecraft:polished_blackstone_bricks
fill 445 193 503 445 195 503 minecraft:blackstone
setblock 447 193 465 minecraft:polished_blackstone_bricks
setblock 448 193 464 minecraft:polished_blackstone_bricks
setblock 448 193 465 minecraft:blackstone
setblock 448 193 504 minecraft:polished_blackstone_bricks
fill 449 193 464 449 194 464 minecraft:blackstone
fill 449 193 480 452 193 487 minecraft:deepslate_tiles
fill 449 193 504 449 194 504 minecraft:blackstone
fill 454 193 464 457 193 464 minecraft:blackstone
setblock 457 193 465 minecraft:polished_blackstone_bricks
setblock 457 193 504 minecraft:blackstone
setblock 458 193 464 minecraft:polished_blackstone_bricks
fill 458 193 465 458 196 465 minecraft:blackstone
setblock 458 193 504 minecraft:polished_blackstone_bricks
fill 459 193 464 459 196 464 minecraft:blackstone
fill 459 193 466 460 193 466 minecraft:blackstone
fill 459 193 504 459 195 504 minecraft:blackstone
setblock 461 193 466 minecraft:polished_blackstone_bricks
setblock 461 193 482 minecraft:blackstone
setblock 461 193 486 minecraft:polished_blackstone_bricks
fill 461 193 487 461 195 487 minecraft:blackstone
setblock 462 193 465 minecraft:polished_blackstone_bricks
fill 462 193 466 462 193 469 minecraft:blackstone
setblock 462 193 470 minecraft:polished_blackstone_bricks
fill 462 193 471 462 193 474 minecraft:blackstone
setblock 462 193 475 minecraft:polished_blackstone_bricks
fill 462 193 476 462 193 479 minecraft:blackstone
setblock 462 193 480 minecraft:polished_blackstone_bricks
fill 462 193 481 462 195 481 minecraft:blackstone
setblock 462 193 485 minecraft:polished_blackstone_bricks
fill 462 193 486 462 196 486 minecraft:blackstone
setblock 462 193 489 minecraft:blackstone
setblock 462 193 490 minecraft:polished_blackstone_bricks
fill 462 193 491 462 196 491 minecraft:blackstone
setblock 463 193 464 minecraft:polished_blackstone_bricks
fill 463 193 465 463 196 465 minecraft:blackstone
setblock 463 193 468 minecraft:blackstone
setblock 463 193 469 minecraft:polished_blackstone_bricks
fill 463 193 470 463 196 470 minecraft:blackstone
fill 463 193 472 463 193 473 minecraft:blackstone
setblock 463 193 474 minecraft:polished_blackstone_bricks
fill 463 193 475 463 193 478 minecraft:blackstone
setblock 463 193 479 minecraft:polished_blackstone_bricks
fill 463 193 480 463 196 480 minecraft:blackstone
setblock 463 193 484 minecraft:polished_blackstone_bricks
fill 463 193 485 463 196 485 minecraft:blackstone
setblock 463 193 489 minecraft:polished_blackstone_bricks
fill 463 193 490 463 196 490 minecraft:blackstone
setblock 463 193 494 minecraft:polished_blackstone_bricks
setblock 463 193 504 minecraft:polished_blackstone_bricks
fill 464 193 464 464 196 464 minecraft:blackstone
setblock 464 193 468 minecraft:polished_blackstone_bricks
fill 464 193 469 464 196 469 minecraft:blackstone
setblock 464 193 472 minecraft:blackstone
setblock 464 193 473 minecraft:polished_blackstone_bricks
fill 464 193 474 464 193 477 minecraft:blackstone
setblock 464 193 478 minecraft:polished_blackstone_bricks
fill 464 193 479 464 196 479 minecraft:blackstone
setblock 464 193 483 minecraft:polished_blackstone_bricks
fill 464 193 484 464 196 484 minecraft:blackstone
setblock 464 193 488 minecraft:polished_blackstone_bricks
fill 464 193 489 464 196 489 minecraft:blackstone
setblock 464 193 493 minecraft:polished_blackstone_bricks
fill 464 193 494 464 193 497 minecraft:blackstone
setblock 464 193 498 minecraft:polished_blackstone_bricks
setblock 464 193 499 minecraft:blackstone
setblock 464 193 503 minecraft:polished_blackstone_bricks
fill 464 193 504 464 195 504 minecraft:blackstone
fill 424 194 464 424 194 466 minecraft:blackstone
setblock 424 194 467 minecraft:polished_blackstone_bricks
fill 424 194 468 424 194 471 minecraft:blackstone
setblock 424 194 472 minecraft:polished_blackstone_bricks
fill 424 194 473 424 194 476 minecraft:blackstone
setblock 424 194 477 minecraft:polished_blackstone_bricks
fill 424 194 478 424 194 481 minecraft:blackstone
setblock 424 194 482 minecraft:polished_blackstone_bricks
fill 424 194 483 424 196 483 minecraft:blackstone
setblock 424 194 487 minecraft:polished_blackstone_bricks
fill 424 194 488 424 197 488 minecraft:blackstone
setblock 424 194 491 minecraft:blackstone
setblock 424 194 492 minecraft:polished_blackstone_bricks
fill 424 194 493 424 194 496 minecraft:blackstone
setblock 424 194 502 minecraft:polished_blackstone_bricks
fill 424 194 503 424 196 504 minecraft:blackstone
fill 425 194 464 425 194 465 minecraft:blackstone
setblock 425 194 466 minecraft:polished_blackstone_bricks
fill 425 194 467 425 194 470 minecraft:blackstone
setblock 425 194 471 minecraft:polished_blackstone_bricks
fill 425 194 472 425 194 475 minecraft:blackstone
setblock 425 194 486 minecraft:polished_blackstone_bricks
fill 425 194 487 425 195 487 minecraft:blackstone
setblock 425 194 491 minecraft:polished_blackstone_bricks
fill 425 194 504 426 194 504 minecraft:blackstone
setblock 426 194 464 minecraft:blackstone
setblock 426 194 465 minecraft:polished_blackstone_bricks
fill 426 194 466 426 196 466 minecraft:blackstone
setblock 426 194 470 minecraft:polished_blackstone_bricks
fill 426 194 471 426 195 471 minecraft:blackstone
setblock 427 194 464 minecraft:polished_blackstone_bricks
fill 427 194 465 427 197 465 minecraft:blackstone
setblock 427 194 504 minecraft:polished_blackstone_bricks
fill 428 194 464 431 194 464 minecraft:blackstone
fill 428 194 504 431 194 504 minecraft:blackstone
setblock 430 194 466 minecraft:polished_blackstone_bricks
setblock 431 194 465 minecraft:polished_blackstone_bricks
setblock 432 194 464 minecraft:polished_blackstone_bricks
fill 432 194 465 435 194 465 minecraft:blackstone
setblock 432 194 504 minecraft:polished_blackstone_bricks
fill 433 194 464 436 194 464 minecraft:blackstone
fill 433 194 504 436 194 504 minecraft:blackstone
setblock 435 194 466 minecraft:polished_blackstone_bricks
fill 435 194 503 437 194 503 minecraft:blackstone
setblock 436 194 465 minecraft:polished_blackstone_bricks
fill 436 194 466 439 194 466 minecraft:blackstone
setblock 437 194 464 minecraft:polished_blackstone_bricks
fill 437 194 465 440 194 465 minecraft:blackstone
fill 437 194 478 440 194 488 minecraft:deepslate_tiles
setblock 437 194 504 minecraft:polished_blackstone_bricks
fill 438 194 464 441 194 464 minecraft:blackstone
setblock 438 194 503 minecraft:polished_blackstone_bricks
fill 438 194 504 441 194 504 minecraft:blackstone
setblock 439 194 502 minecraft:polished_blackstone_bricks
fill 439 194 503 442 194 503 minecraft:blackstone
setblock 440 194 466 minecraft:polished_blackstone_bricks
fill 440 194 495 440 195 496 minecraft:cyan_stained_glass
fill 440 194 502 440 195 502 minecraft:blackstone
setblock 441 194 465 minecraft:polished_blackstone_bricks
fill 441 194 466 441 196 466 minecraft:blackstone
fill 441 194 478 451 194 479 minecraft:deepslate_tiles
fill 441 194 488 451 194 488 minecraft:deepslate_tiles
setblock 442 194 464 minecraft:polished_blackstone_bricks
fill 442 194 465 442 197 465 minecraft:blackstone
setblock 442 194 504 minecraft:polished_blackstone_bricks
fill 443 194 464 443 197 464 minecraft:blackstone
setblock 443 194 503 minecraft:polished_blackstone_bricks
fill 443 194 504 446 194 504 minecraft:blackstone
setblock 444 194 502 minecraft:polished_blackstone_bricks
fill 444 194 503 444 195 503 minecraft:blackstone
setblock 446 194 465 minecraft:polished_blackstone_bricks
setblock 447 194 464 minecraft:polished_blackstone_bricks
setblock 447 194 465 minecraft:blackstone
setblock 447 194 504 minecraft:polished_blackstone_bricks
setblock 448 194 464 minecraft:blackstone
setblock 448 194 504 minecraft:blackstone
fill 449 194 480 451 194 487 minecraft:deepslate_tiles
fill 455 194 464 456 194 464 minecraft:blackstone
setblock 457 194 464 minecraft:polished_blackstone_bricks
fill 457 194 465 457 196 465 minecraft:blackstone
fill 458 194 464 458 197 464 minecraft:blackstone
fill 458 194 504 458 195 504 minecraft:blackstone
setblock 459 194 466 minecraft:blackstone
setblock 460 194 466 minecraft:polished_blackstone_bricks
setblock 461 194 465 minecraft:polished_blackstone_bricks
fill 461 194 466 461 194 469 minecraft:blackstone
setblock 461 194 470 minecraft:polished_blackstone_bricks
setblock 461 194 485 minecraft:polished_blackstone_bricks
fill 461 194 486 461 195 486 minecraft:blackstone
setblock 461 194 490 minecraft:polished_blackstone_bricks
setblock 462 194 464 minecraft:polished_blackstone_bricks
fill 462 194 465 462 194 468 minecraft:blackstone
setblock 462 194 469 minecraft:polished_blackstone_bricks
fill 462 194 470 462 194 473 minecraft:blackstone
setblock 462 194 474 minecraft:polished_blackstone_bricks
fill 462 194 475 462 194 478 minecraft:blackstone
setblock 462 194 479 minecraft:polished_blackstone_bricks
fill 462 194 480 462 195 480 minecraft:blackstone
setblock 462 194 484 minecraft:polished_blackstone_bricks
fill 462 194 485 462 196 485 minecraft:blackstone
setblock 462 194 489 minecraft:polished_blackstone_bricks
fill 462 194 490 462 197 490 minecraft:blackstone
setblock 462 194 504 minecraft:polished_blackstone_bricks
fill 463 194 464 463 197 464 minecraft:blackstone
setblock 463 194 467 minecraft:blackstone
setblock 463 194 468 minecraft:polished_blackstone_bricks
fill 463 194 469 463 197 469 minecraft:blackstone
setblock 463 194 472 minecraft:blackstone
setblock 463 194 473 minecraft:polished_blackstone_bricks
fill 463 194 474 463 194 477 minecraft:blackstone
setblock 463 194 478 minecraft:polished_blackstone_bricks
fill 463 194 479 463 197 479 minecraft:blackstone
setblock 463 194 483 minecraft:polished_blackstone_bricks
fill 463 194 484 463 197 484 minecraft:blackstone
setblock 463 194 488 minecraft:polished_blackstone_bricks
fill 463 194 489 463 197 489 minecraft:blackstone
setblock 463 194 493 minecraft:polished_blackstone_bricks
fill 463 194 494 464 196 494 minecraft:blackstone
fill 463 194 504 463 195 504 minecraft:blackstone
setblock 464 194 467 minecraft:polished_blackstone_bricks
fill 464 194 468 464 197 468 minecraft:blackstone
setblock 464 194 472 minecraft:polished_blackstone_bricks
fill 464 194 473 464 194 476 minecraft:blackstone
setblock 464 194 477 minecraft:polished_blackstone_bricks
fill 464 194 478 464 197 478 minecraft:blackstone
setblock 464 194 482 minecraft:polished_blackstone_bricks
fill 464 194 483 464 197 483 minecraft:blackstone
setblock 464 194 487 minecraft:polished_blackstone_bricks
fill 464 194 488 464 197 488 minecraft:blackstone
setblock 464 194 492 minecraft:polished_blackstone_bricks
fill 464 194 493 464 197 493 minecraft:blackstone
fill 464 194 495 464 194 496 minecraft:blackstone
setblock 464 194 497 minecraft:polished_blackstone_bricks
setblock 464 194 502 minecraft:polished_blackstone_bricks
fill 464 194 503 464 195 503 minecraft:blackstone
fill 424 195 464 424 195 465 minecraft:blackstone
setblock 424 195 466 minecraft:polished_blackstone_bricks
fill 424 195 467 424 195 470 minecraft:blackstone
setblock 424 195 471 minecraft:polished_blackstone_bricks
fill 424 195 472 424 195 475 minecraft:blackstone
setblock 424 195 476 minecraft:polished_blackstone_bricks
fill 424 195 477 424 195 480 minecraft:blackstone
setblock 424 195 481 minecraft:polished_blackstone_bricks
fill 424 195 482 424 196 482 minecraft:blackstone
setblock 424 195 486 minecraft:polished_blackstone_bricks
fill 424 195 487 424 197 487 minecraft:blackstone
setblock 424 195 491 minecraft:polished_blackstone_bricks
fill 424 195 492 424 195 495 minecraft:blackstone
setblock 424 195 496 minecraft:polished_blackstone_bricks
setblock 424 195 501 minecraft:polished_blackstone_bricks
setblock 424 195 502 minecraft:blackstone
setblock 425 195 464 minecraft:blackstone
setblock 425 195 465 minecraft:polished_blackstone_bricks
fill 425 195 466 425 195 469 minecraft:blackstone
setblock 425 195 470 minecraft:polished_blackstone_bricks
fill 425 195 471 425 195 474 minecraft:blackstone
setblock 425 195 486 minecraft:blackstone
setblock 425 195 490 minecraft:polished_blackstone_bricks
setblock 425 195 504 minecraft:blackstone
setblock 426 195 464 minecraft:polished_blackstone_bricks
fill 426 195 465 426 198 465 minecraft:blackstone
setblock 426 195 469 minecraft:polished_blackstone_bricks
fill 426 195 470 426 196 470 minecraft:blackstone
setblock 426 195 504 minecraft:polished_blackstone_bricks
fill 427 195 464 430 195 464 minecraft:blackstone
fill 427 195 504 430 195 504 minecraft:blackstone
setblock 429 195 466 minecraft:polished_blackstone_bricks
setblock 430 195 465 minecraft:polished_blackstone_bricks
setblock 431 195 464 minecraft:polished_blackstone_bricks
fill 431 195 465 434 195 465 minecraft:blackstone
setblock 431 195 504 minecraft:polished_blackstone_bricks
fill 432 195 464 435 195 464 minecraft:blackstone
fill 432 195 504 435 195 504 minecraft:blackstone
setblock 435 195 465 minecraft:polished_blackstone_bricks
setblock 436 195 464 minecraft:polished_blackstone_bricks
fill 436 195 465 438 195 466 minecraft:blackstone
setblock 436 195 503 minecraft:blackstone
setblock 436 195 504 minecraft:polished_blackstone_bricks
fill 437 195 464 440 195 464 minecraft:blackstone
setblock 437 195 503 minecraft:polished_blackstone_bricks
fill 437 195 504 440 195 504 minecraft:blackstone
fill 438 195 479 440 195 487 minecraft:deepslate_tiles
fill 438 195 503 441 195 503 minecraft:blackstone
setblock 439 195 465 minecraft:blackstone
setblock 439 195 466 minecraft:polished_blackstone_bricks
setblock 440 195 465 minecraft:polished_blackstone_bricks
fill 440 195 466 440 196 466 minecraft:blackstone
setblock 441 195 464 minecraft:polished_blackstone_bricks
fill 441 195 465 441 197 465 minecraft:blackstone
fill 441 195 479 450 195 479 minecraft:deepslate_tiles
setblock 441 195 504 minecraft:polished_blackstone_bricks
fill 442 195 464 442 198 464 minecraft:blackstone
setblock 442 195 503 minecraft:polished_blackstone_bricks
fill 442 195 504 445 195 504 minecraft:blackstone
fill 443 195 503 443 196 503 minecraft:blackstone
setblock 445 195 465 minecraft:polished_blackstone_bricks
setblock 446 195 464 minecraft:polished_blackstone_bricks
setblock 446 195 504 minecraft:polished_blackstone_bricks
setblock 447 195 464 minecraft:blackstone
setblock 447 195 504 minecraft:blackstone
fill 449 195 480 450 195 487 minecraft:deepslate_tiles
setblock 455 195 464 minecraft:blackstone
setblock 456 195 464 minecraft:polished_blackstone_bricks
fill 457 195 464 457 198 464 minecraft:blackstone
setblock 459 195 466 minecraft:polished_blackstone_bricks
setblock 460 195 465 minecraft:polished_blackstone_bricks
fill 460 195 466 462 196 466 minecraft:blackstone
setblock 461 195 464 minecraft:polished_blackstone_bricks
fill 461 195 465 462 197 465 minecraft:blackstone
fill 461 195 467 461 195 468 minecraft:blackstone
setblock 461 195 469 minecraft:polished_blackstone_bricks
fill 461 195 470 462 196 471 minecraft:blackstone
setblock 461 195 484 minecraft:polished_blackstone_bricks
setblock 461 195 485 minecraft:blackstone
setblock 461 195 489 minecraft:polished_blackstone_bricks
setblock 461 195 490 minecraft:blackstone
setblock 461 195 504 minecraft:polished_blackstone_bricks
fill 462 195 464 462 198 464 minecraft:blackstone
setblock 462 195 467 minecraft:blackstone
setblock 462 195 468 minecraft:polished_blackstone_bricks
fill 462 195 469 462 198 469 minecraft:blackstone
setblock 462 195 472 minecraft:blackstone
setblock 462 195 473 minecraft:polished_blackstone_bricks
fill 462 195 474 463 195 476 minecraft:blackstone
setblock 462 195 483 minecraft:polished_blackstone_bricks
fill 462 195 484 462 196 484 minecraft:blackstone
setblock 462 195 488 minecraft:polished_blackstone_bricks
fill 462 195 489 462 197 489 minecraft:blackstone
fill 462 195 504 462 196 504 minecraft:blackstone
setblock 463 195 467 minecraft:polished_blackstone_bricks
fill 463 195 468 463 198 468 minecraft:blackstone
setblock 463 195 471 minecraft:blackstone
setblock 463 195 472 minecraft:polished_blackstone_bricks
fill 463 195 473 464 197 473 minecraft:blackstone
setblock 463 195 477 minecraft:polished_blackstone_bricks
fill 463 195 478 463 197 478 minecraft:blackstone
setblock 463 195 482 minecraft:polished_blackstone_bricks
fill 463 195 483 463 197 483 minecraft:blackstone
setblock 463 195 487 minecraft:polished_blackstone_bricks
fill 463 195 488 463 198 488 minecraft:blackstone
setblock 463 195 492 minecraft:polished_blackstone_bricks
fill 463 195 493 463 197 493 minecraft:blackstone
setblock 464 195 466 minecraft:polished_blackstone_bricks
fill 464 195 467 464 198 467 minecraft:blackstone
setblock 464 195 471 minecraft:polished_blackstone_bricks
fill 464 195 472 464 198 472 minecraft:blackstone
fill 464 195 474 464 195 475 minecraft:blackstone
setblock 464 195 476 minecraft:polished_blackstone_bricks
fill 464 195 477 464 198 477 minecraft:blackstone
setblock 464 195 481 minecraft:polished_blackstone_bricks
fill 464 195 482 464 198 482 minecraft:blackstone
setblock 464 195 486 minecraft:polished_blackstone_bricks
fill 464 195 487 464 198 487 minecraft:blackstone
setblock 464 195 491 minecraft:polished_blackstone_bricks
fill 464 195 492 464 198 492 minecraft:blackstone
setblock 464 195 495 minecraft:blackstone
setblock 464 195 496 minecraft:polished_blackstone_bricks
setblock 424 196 464 minecraft:blackstone
setblock 424 196 465 minecraft:polished_blackstone_bricks
fill 424 196 466 424 196 469 minecraft:blackstone
setblock 424 196 470 minecraft:polished_blackstone_bricks
fill 424 196 471 424 196 474 minecraft:blackstone
setblock 424 196 475 minecraft:polished_blackstone_bricks
fill 424 196 476 424 196 478 minecraft:blackstone
setblock 424 196 485 minecraft:polished_blackstone_bricks
fill 424 196 486 424 197 486 minecraft:blackstone
setblock 424 196 490 minecraft:polished_blackstone_bricks
fill 424 196 491 424 196 494 minecraft:blackstone
setblock 424 196 495 minecraft:polished_blackstone_bricks
setblock 425 196 464 minecraft:polished_blackstone_bricks
fill 425 196 465 425 196 468 minecraft:blackstone
setblock 425 196 469 minecraft:polished_blackstone_bricks
fill 425 196 470 425 196 473 minecraft:blackstone
setblock 425 196 474 minecraft:polished_blackstone_bricks
setblock 425 196 504 minecraft:polished_blackstone_bricks
fill 426 196 464 429 196 464 minecraft:blackstone
setblock 426 196 468 minecraft:polished_blackstone_bricks
fill 426 196 469 426 197 469 minecraft:blackstone
fill 426 196 504 427 196 504 minecraft:blackstone
setblock 429 196 465 minecraft:polished_blackstone_bricks
setblock 430 196 464 minecraft:polished_blackstone_bricks
fill 430 196 465 433 196 465 minecraft:blackstone
fill 431 196 464 434 196 464 minecraft:blackstone
fill 432 196 504 434 196 504 minecraft:blackstone
setblock 434 196 465 minecraft:polished_blackstone_bricks
setblock 435 196 464 minecraft:polished_blackstone_bricks
fill 435 196 465 438 196 465 minecraft:blackstone
setblock 435 196 504 minecraft:polished_blackstone_bricks
fill 436 196 464 439 196 464 minecraft:blackstone
setblock 436 196 503 minecraft:polished_blackstone_bricks
fill 436 196 504 439 196 504 minecraft:blackstone
setblock 437 196 466 minecraft:blackstone
fill 437 196 503 440 196 503 minecraft:blackstone
setblock 438 196 466 minecraft:polished_blackstone_bricks
setblock 439 196 465 minecraft:polished_blackstone_bricks
setblock 439 196 466 minecraft:blackstone
fill 439 196 480 440 196 486 minecraft:deepslate_tiles
setblock 440 196 464 minecraft:polished_blackstone_bricks
fill 440 196 465 440 198 465 minecraft:blackstone
setblock 440 196 504 minecraft:polished_blackstone_bricks
fill 441 196 464 441 199 464 minecraft:blackstone
setblock 441 196 503 minecraft:polished_blackstone_bricks
fill 441 196 504 444 196 504 minecraft:blackstone
fill 442 196 503 442 197 503 minecraft:blackstone
setblock 444 196 465 minecraft:polished_blackstone_bricks
setblock 445 196 464 minecraft:polished_blackstone_bricks
setblock 445 196 504 minecraft:polished_blackstone_bricks
setblock 446 196 464 minecraft:blackstone
setblock 446 196 504 minecraft:blackstone
fill 449 196 480 449 196 486 minecraft:deepslate_tiles
fill 456 196 464 456 197 464 minecraft:blackstone
setblock 459 196 465 minecraft:polished_blackstone_bricks
fill 459 196 466 459 197 466 minecraft:blackstone
setblock 460 196 464 minecraft:polished_blackstone_bricks
fill 460 196 465 460 199 465 minecraft:blackstone
setblock 460 196 504 minecraft:polished_blackstone_bricks
fill 461 196 464 461 199 464 minecraft:blackstone
setblock 461 196 468 minecraft:polished_blackstone_bricks
fill 461 196 469 461 197 469 minecraft:blackstone
setblock 461 196 488 minecraft:polished_blackstone_bricks
setblock 461 196 504 minecraft:blackstone
setblock 462 196 467 minecraft:polished_blackstone_bricks
fill 462 196 468 462 199 468 minecraft:blackstone
setblock 462 196 472 minecraft:polished_blackstone_bricks
fill 462 196 473 462 197 475 minecraft:blackstone
setblock 462 196 483 minecraft:blackstone
setblock 462 196 487 minecraft:polished_blackstone_bricks
fill 462 196 488 462 197 488 minecraft:blackstone
setblock 462 196 492 minecraft:polished_blackstone_bricks
setblock 463 196 466 minecraft:polished_blackstone_bricks
fill 463 196 467 463 199 467 minecraft:blackstone
setblock 463 196 471 minecraft:polished_blackstone_bricks
fill 463 196 472 463 199 472 minecraft:blackstone
fill 463 196 474 463 196 475 minecraft:blackstone
setblock 463 196 476 minecraft:polished_blackstone_bricks
fill 463 196 477 463 199 477 minecraft:blackstone
setblock 463 196 481 minecraft:polished_blackstone_bricks
fill 463 196 482 463 197 482 minecraft:blackstone
setblock 463 196 486 minecraft:polished_blackstone_bricks
fill 463 196 487 463 198 487 minecraft:blackstone
setblock 463 196 491 minecraft:polished_blackstone_bricks
fill 463 196 492 463 198 492 minecraft:blackstone
setblock 464 196 465 minecraft:polished_blackstone_bricks
fill 464 196 466 464 199 466 minecraft:blackstone
setblock 464 196 470 minecraft:polished_blackstone_bricks
fill 464 196 471 464 199 471 minecraft:blackstone
setblock 464 196 474 minecraft:blackstone
setblock 464 196 475 minecraft:polished_blackstone_bricks
fill 464 196 476 464 199 476 minecraft:blackstone
setblock 464 196 480 minecraft:polished_blackstone_bricks
fill 464 196 481 464 198 481 minecraft:blackstone
setblock 464 196 485 minecraft:polished_blackstone_bricks
fill 464 196 486 464 198 486 minecraft:blackstone
setblock 464 196 490 minecraft:polished_blackstone_bricks
fill 464 196 491 464 199 491 minecraft:blackstone
setblock 464 196 495 minecraft:polished_blackstone_bricks
setblock 424 197 464 minecraft:polished_blackstone_bricks
fill 424 197 465 424 197 468 minecraft:blackstone
setblock 424 197 469 minecraft:polished_blackstone_bricks
fill 424 197 470 424 197 473 minecraft:blackstone
setblock 424 197 474 minecraft:polished_blackstone_bricks
fill 424 197 475 424 197 477 minecraft:blackstone
setblock 424 197 489 minecraft:polished_blackstone_bricks
fill 424 197 490 424 197 493 minecraft:blackstone
setblock 424 197 494 minecraft:polished_blackstone_bricks
setblock 424 197 495 minecraft:blackstone
setblock 424 197 504 minecraft:polished_blackstone_bricks
fill 425 197 464 425 197 467 minecraft:blackstone
setblock 425 197 468 minecraft:polished_blackstone_bricks
fill 425 197 469 425 197 472 minecraft:blackstone
setblock 425 197 473 minecraft:polished_blackstone_bricks
setblock 425 197 504 minecraft:blackstone
fill 426 197 464 428 197 464 minecraft:blackstone
setblock 426 197 467 minecraft:polished_blackstone_bricks
setblock 426 197 468 minecraft:blackstone
setblock 428 197 465 minecraft:polished_blackstone_bricks
setblock 429 197 464 minecraft:polished_blackstone_bricks
fill 430 197 464 433 197 464 minecraft:blackstone
setblock 433 197 504 minecraft:blackstone
setblock 434 197 464 minecraft:polished_blackstone_bricks
fill 434 197 465 437 197 465 minecraft:blackstone
setblock 434 197 504 minecraft:polished_blackstone_bricks
fill 435 197 464 438 197 464 minecraft:blackstone
fill 435 197 504 438 197 504 minecraft:blackstone
fill 437 197 503 439 197 503 minecraft:blackstone
setblock 438 197 465 minecraft:polished_blackstone_bricks
setblock 439 197 464 minecraft:polished_blackstone_bricks
fill 439 197 465 439 198 465 minecraft:blackstone
setblock 439 197 504 minecraft:polished_blackstone_bricks
fill 440 197 464 440 200 464 minecraft:blackstone
fill 440 197 481 440 197 485 minecraft:deepslate_tiles
setblock 440 197 503 minecraft:polished_blackstone_bricks
fill 440 197 504 443 197 504 minecraft:blackstone
setblock 441 197 503 minecraft:blackstone
setblock 444 197 464 minecraft:polished_blackstone_bricks
setblock 444 197 504 minecraft:polished_blackstone_bricks
setblock 458 197 465 minecraft:polished_blackstone_bricks
setblock 459 197 464 minecraft:polished_blackstone_bricks
fill 459 197 465 459 200 465 minecraft:blackstone
fill 460 197 464 460 200 464 minecraft:blackstone
fill 460 197 466 461 197 466 minecraft:blackstone
fill 461 197 470 461 197 471 minecraft:blackstone
setblock 462 197 466 minecraft:polished_blackstone_bricks
fill 462 197 467 462 199 467 minecraft:blackstone
setblock 462 197 470 minecraft:blackstone
setblock 462 197 471 minecraft:polished_blackstone_bricks
fill 462 197 472 462 200 472 minecraft:blackstone
setblock 462 197 486 minecraft:polished_blackstone_bricks
setblock 462 197 487 minecraft:blackstone
setblock 462 197 491 minecraft:polished_blackstone_bricks
setblock 463 197 465 minecraft:polished_blackstone_bricks
fill 463 197 466 463 200 466 minecraft:blackstone
setblock 463 197 470 minecraft:polished_blackstone_bricks
fill 463 197 471 463 200 471 minecraft:blackstone
setblock 463 197 474 minecraft:blackstone
setblock 463 197 475 minecraft:polished_blackstone_bricks
fill 463 197 476 463 200 476 minecraft:blackstone
setblock 463 197 485 minecraft:polished_blackstone_bricks
fill 463 197 486 463 198 486 minecraft:blackstone
setblock 463 197 490 minecraft:polished_blackstone_bricks
fill 463 197 491 463 198 491 minecraft:blackstone
setblock 464 197 464 minecraft:polished_blackstone_bricks
fill 464 197 465 464 200 465 minecraft:blackstone
setblock 464 197 469 minecraft:polished_blackstone_bricks
fill 464 197 470 464 200 470 minecraft:blackstone
setblock 464 197 474 minecraft:polished_blackstone_bricks
fill 464 197 475 464 200 475 minecraft:blackstone
setblock 464 197 479 minecraft:polished_blackstone_bricks
fill 464 197 480 464 198 480 minecraft:blackstone
setblock 464 197 484 minecraft:polished_blackstone_bricks
fill 464 197 485 464 198 485 minecraft:blackstone
setblock 464 197 489 minecraft:polished_blackstone_bricks
fill 464 197 490 464 200 490 minecraft:blackstone
setblock 464 197 494 minecraft:polished_blackstone_bricks
setblock 464 197 495 minecraft:blackstone
fill 424 198 464 424 198 467 minecraft:blackstone
setblock 424 198 468 minecraft:polished_blackstone_bricks
fill 424 198 469 424 198 472 minecraft:blackstone
setblock 424 198 473 minecraft:polished_blackstone_bricks
fill 424 198 474 424 198 476 minecraft:blackstone
fill 424 198 489 424 198 492 minecraft:blackstone
setblock 424 198 493 minecraft:polished_blackstone_bricks
fill 424 198 494 424 199 494 minecraft:blackstone
fill 425 198 464 425 198 466 minecraft:blackstone
setblock 425 198 467 minecraft:polished_blackstone_bricks
fill 425 198 468 425 198 471 minecraft:blackstone
setblock 425 198 472 minecraft:polished_blackstone_bricks
fill 426 198 464 427 198 464 minecraft:blackstone
setblock 428 198 464 minecraft:polished_blackstone_bricks
fill 429 198 464 432 198 464 minecraft:blackstone
setblock 433 198 464 minecraft:polished_blackstone_bricks
fill 434 198 464 437 198 464 minecraft:blackstone
fill 434 198 504 437 198 504 minecraft:blackstone
setblock 436 198 465 minecraft:blackstone
setblock 437 198 465 minecraft:polished_blackstone_bricks
fill 437 198 503 438 198 503 minecraft:blackstone
setblock 438 198 464 minecraft:polished_blackstone_bricks
setblock 438 198 465 minecraft:blackstone
setblock 438 198 504 minecraft:polished_blackstone_bricks
fill 439 198 464 439 201 464 minecraft:blackstone
setblock 439 198 503 minecraft:polished_blackstone_bricks
fill 439 198 504 442 198 504 minecraft:blackstone
setblock 440 198 503 minecraft:blackstone
setblock 443 198 464 minecraft:polished_blackstone_bricks
setblock 443 198 504 minecraft:polished_blackstone_bricks
fill 449 198 489 453 230 491 minecraft:polished_blackstone_bricks
fill 450 198 488 452 230 488 minecraft:polished_blackstone_bricks
fill 450 198 492 452 230 492 minecraft:polished_blackstone_bricks
setblock 458 198 464 minecraft:polished_blackstone_bricks
setblock 458 198 465 minecraft:blackstone
fill 459 198 464 459 201 464 minecraft:blackstone
setblock 461 198 465 minecraft:blackstone
setblock 461 198 466 minecraft:polished_blackstone_bricks
setblock 461 198 470 minecraft:blackstone
setblock 461 198 471 minecraft:polished_blackstone_bricks
setblock 462 198 465 minecraft:polished_blackstone_bricks
setblock 462 198 466 minecraft:blackstone
setblock 462 198 470 minecraft:polished_blackstone_bricks
fill 462 198 471 462 201 471 minecraft:blackstone
fill 462 198 473 462 198 474 minecraft:blackstone
setblock 462 198 475 minecraft:polished_blackstone_bricks
setblock 463 198 464 minecraft:polished_blackstone_bricks
fill 463 198 465 463 199 465 minecraft:blackstone
setblock 463 198 469 minecraft:polished_blackstone_bricks
fill 463 198 470 463 201 470 minecraft:blackstone
setblock 463 198 473 minecraft:blackstone
setblock 463 198 474 minecraft:polished_blackstone_bricks
fill 463 198 475 463 201 475 minecraft:blackstone
setblock 463 198 489 minecraft:polished_blackstone_bricks
setblock 463 198 490 minecraft:blackstone
fill 464 198 464 464 200 464 minecraft:blackstone
setblock 464 198 468 minecraft:polished_blackstone_bricks
fill 464 198 469 464 201 469 minecraft:blackstone
setblock 464 198 473 minecraft:polished_blackstone_bricks
fill 464 198 474 464 201 474 minecraft:blackstone
setblock 464 198 478 minecraft:polished_blackstone_bricks
fill 464 198 479 464 199 479 minecraft:blackstone
setblock 464 198 483 minecraft:polished_blackstone_bricks
setblock 464 198 484 minecraft:blackstone
setblock 464 198 488 minecraft:polished_blackstone_bricks
fill 464 198 489 464 199 489 minecraft:blackstone
setblock 464 198 493 minecraft:polished_blackstone_bricks
fill 464 198 494 464 199 494 minecraft:blackstone
fill 424 199 464 424 199 466 minecraft:blackstone
setblock 424 199 467 minecraft:polished_blackstone_bricks
fill 424 199 468 424 199 471 minecraft:blackstone
setblock 424 199 472 minecraft:polished_blackstone_bricks
fill 424 199 473 424 200 475 minecraft:blackstone
setblock 424 199 491 minecraft:blackstone
setblock 424 199 492 minecraft:polished_blackstone_bricks
setblock 424 199 493 minecraft:blackstone
fill 425 199 464 426 199 464 minecraft:blackstone
setblock 425 199 466 minecraft:polished_blackstone_bricks
fill 425 199 467 425 199 470 minecraft:blackstone
setblock 425 199 471 minecraft:polished_blackstone_bricks
setblock 425 199 472 minecraft:blackstone
setblock 427 199 464 minecraft:polished_blackstone_bricks
fill 433 199 464 436 199 464 minecraft:blackstone
fill 434 199 504 436 199 504 minecraft:blackstone
setblock 437 199 464 minecraft:polished_blackstone_bricks
setblock 437 199 504 minecraft:polished_blackstone_bricks
fill 438 199 464 438 202 464 minecraft:blackstone
setblock 438 199 503 minecraft:polished_blackstone_bricks
fill 438 199 504 441 199 504 minecraft:blackstone
setblock 442 199 504 minecraft:polished_blackstone_bricks
fill 448 199 489 448 200 491 minecraft:blackstone
fill 449 199 487 449 200 488 minecraft:blackstone
fill 449 199 492 449 200 492 minecraft:blackstone
fill 450 199 487 453 200 487 minecraft:blackstone
fill 450 199 493 452 200 493 minecraft:blackstone
fill 453 199 488 454 200 488 minecraft:blackstone
fill 453 199 492 453 200 492 minecraft:blackstone
fill 454 199 489 454 200 491 minecraft:blackstone
setblock 457 199 464 minecraft:polished_blackstone_bricks
fill 458 199 464 458 202 464 minecraft:blackstone
setblock 461 199 465 minecraft:polished_blackstone_bricks
setblock 462 199 464 minecraft:polished_blackstone_bricks
setblock 462 199 465 minecraft:blackstone
setblock 462 199 469 minecraft:polished_blackstone_bricks
fill 462 199 470 462 202 470 minecraft:blackstone
setblock 462 199 473 minecraft:blackstone
setblock 462 199 474 minecraft:polished_blackstone_bricks
fill 462 199 475 462 202 475 minecraft:blackstone
fill 463 199 464 463 201 464 minecraft:blackstone
setblock 463 199 468 minecraft:polished_blackstone_bricks
fill 463 199 469 463 202 469 minecraft:blackstone
setblock 463 199 473 minecraft:polished_blackstone_bricks
fill 463 199 474 463 202 474 minecraft:blackstone
setblock 464 199 467 minecraft:polished_blackstone_bricks
fill 464 199 468 464 202 468 minecraft:blackstone
setblock 464 199 472 minecraft:polished_blackstone_bricks
fill 464 199 473 464 202 473 minecraft:blackstone
setblock 464 199 477 minecraft:polished_blackstone_bricks
fill 464 199 478 464 202 478 minecraft:blackstone
setblock 464 199 487 minecraft:polished_blackstone_bricks
setblock 464 199 488 minecraft:blackstone
setblock 464 199 492 minecraft:polished_blackstone_bricks
fill 464 199 493 464 200 493 minecraft:blackstone
fill 424 200 464 424 200 465 minecraft:blackstone
setblock 424 200 466 minecraft:polished_blackstone_bricks
fill 424 200 467 424 200 470 minecraft:blackstone
setblock 424 200 471 minecraft:polished_blackstone_bricks
fill 424 200 472 424 203 472 minecraft:blackstone
setblock 425 200 464 minecraft:blackstone
fill 425 200 468 425 200 469 minecraft:blackstone
setblock 425 200 470 minecraft:polished_blackstone_bricks
setblock 425 200 471 minecraft:blackstone
setblock 426 200 466 minecraft:light[level=11]
setblock 426 200 474 minecraft:light[level=11]
setblock 426 200 482 minecraft:light[level=11]
setblock 426 200 490 minecraft:light[level=11]
setblock 426 200 498 minecraft:light[level=11]
fill 434 200 464 435 200 464 minecraft:blackstone
setblock 434 200 466 minecraft:light[level=11]
setblock 434 200 474 minecraft:light[level=11]
setblock 434 200 482 minecraft:light[level=11]
setblock 434 200 490 minecraft:light[level=11]
setblock 434 200 498 minecraft:light[level=11]
fill 434 200 504 435 200 504 minecraft:blackstone
setblock 436 200 464 minecraft:polished_blackstone_bricks
setblock 436 200 504 minecraft:polished_blackstone_bricks
fill 437 200 464 437 203 464 minecraft:blackstone
fill 437 200 504 440 200 504 minecraft:blackstone
setblock 441 200 504 minecraft:polished_blackstone_bricks
setblock 442 200 466 minecraft:light[level=11]
setblock 442 200 474 minecraft:light[level=11]
setblock 442 200 482 minecraft:light[level=11]
setblock 442 200 490 minecraft:light[level=11]
setblock 442 200 498 minecraft:light[level=11]
fill 447 200 488 447 200 491 minecraft:blackstone
fill 448 200 487 448 200 488 minecraft:blackstone
fill 448 200 492 448 200 493 minecraft:blackstone
fill 449 200 486 453 200 486 minecraft:blackstone
setblock 449 200 493 minecraft:blackstone
setblock 450 200 466 minecraft:light[level=11]
setblock 450 200 474 minecraft:light[level=11]
setblock 450 200 482 minecraft:light[level=11]
fill 450 200 494 452 200 494 minecraft:blackstone
setblock 450 200 498 minecraft:light[level=11]
fill 453 200 493 454 200 493 minecraft:blackstone
setblock 454 200 487 minecraft:blackstone
setblock 454 200 492 minecraft:blackstone
fill 455 200 488 455 200 491 minecraft:blackstone
fill 457 200 464 457 203 464 minecraft:blackstone
setblock 458 200 466 minecraft:light[level=11]
setblock 458 200 474 minecraft:light[level=11]
setblock 458 200 482 minecraft:light[level=11]
setblock 458 200 490 minecraft:light[level=11]
setblock 458 200 498 minecraft:light[level=11]
setblock 460 200 465 minecraft:polished_blackstone_bricks
setblock 461 200 464 minecraft:polished_blackstone_bricks
setblock 461 200 465 minecraft:blackstone
fill 462 200 464 462 203 464 minecraft:blackstone
setblock 462 200 468 minecraft:polished_blackstone_bricks
fill 462 200 469 462 202 469 minecraft:blackstone
setblock 462 200 473 minecraft:polished_blackstone_bricks
fill 462 200 474 462 203 474 minecraft:blackstone
setblock 463 200 467 minecraft:polished_blackstone_bricks
fill 463 200 468 463 203 468 minecraft:blackstone
setblock 463 200 472 minecraft:polished_blackstone_bricks
fill 463 200 473 463 203 473 minecraft:blackstone
setblock 463 200 477 minecraft:polished_blackstone_bricks
setblock 464 200 466 minecraft:polished_blackstone_bricks
fill 464 200 467 464 203 467 minecraft:blackstone
setblock 464 200 471 minecraft:polished_blackstone_bricks
fill 464 200 472 464 203 472 minecraft:blackstone
setblock 464 200 476 minecraft:polished_blackstone_bricks
fill 464 200 477 464 203 477 minecraft:blackstone
setblock 464 200 491 minecraft:polished_blackstone_bricks
setblock 464 200 492 minecraft:blackstone
setblock 424 201 464 minecraft:blackstone
setblock 424 201 465 minecraft:polished_blackstone_bricks
fill 424 201 466 424 201 469 minecraft:blackstone
setblock 424 201 470 minecraft:polished_blackstone_bricks
fill 424 201 471 424 204 471 minecraft:blackstone
fill 424 201 473 424 201 474 minecraft:blackstone
setblock 424 201 475 minecraft:polished_blackstone_bricks
setblock 424 201 494 minecraft:blackstone
setblock 424 201 495 minecraft:polished_blackstone_bricks
fill 433 201 504 434 201 504 minecraft:blackstone
setblock 434 201 464 minecraft:blackstone
setblock 435 201 464 minecraft:polished_blackstone_bricks
setblock 435 201 504 minecraft:polished_blackstone_bricks
fill 436 201 464 436 204 464 minecraft:blackstone
fill 436 201 504 439 201 504 minecraft:blackstone
fill 437 201 503 438 203 503 minecraft:blackstone
setblock 440 201 504 minecraft:polished_blackstone_bricks
setblock 441 201 504 minecraft:blackstone
setblock 460 201 464 minecraft:polished_blackstone_bricks
fill 461 201 464 461 204 464 minecraft:blackstone
setblock 462 201 472 minecraft:polished_blackstone_bricks
fill 462 201 473 462 204 473 minecraft:blackstone
fill 463 201 467 463 202 467 minecraft:blackstone
setblock 463 201 471 minecraft:polished_blackstone_bricks
fill 463 201 472 463 204 472 minecraft:blackstone
setblock 463 201 476 minecraft:polished_blackstone_bricks
fill 463 201 477 463 204 477 minecraft:blackstone
setblock 464 201 465 minecraft:polished_blackstone_bricks
fill 464 201 466 464 204 466 minecraft:blackstone
setblock 464 201 470 minecraft:polished_blackstone_bricks
fill 464 201 471 464 204 471 minecraft:blackstone
setblock 464 201 475 minecraft:polished_blackstone_bricks
fill 464 201 476 464 204 476 minecraft:blackstone
fill 424 202 465 424 202 468 minecraft:blackstone
setblock 424 202 469 minecraft:polished_blackstone_bricks
fill 424 202 470 424 205 470 minecraft:blackstone
setblock 424 202 473 minecraft:blackstone
setblock 424 202 474 minecraft:polished_blackstone_bricks
fill 424 202 475 424 205 475 minecraft:blackstone
setblock 424 202 494 minecraft:polished_blackstone_bricks
fill 424 202 495 424 203 497 minecraft:blackstone
fill 432 202 504 433 202 504 minecraft:blackstone
setblock 434 202 464 minecraft:polished_blackstone_bricks
setblock 434 202 504 minecraft:polished_blackstone_bricks
fill 435 202 464 435 205 464 minecraft:blackstone
setblock 435 202 503 minecraft:polished_blackstone_bricks
fill 435 202 504 438 202 504 minecraft:blackstone
fill 436 202 503 436 205 503 minecraft:blackstone
setblock 439 202 504 minecraft:polished_blackstone_bricks
fill 440 202 504 440 205 504 minecraft:blackstone
fill 456 202 464 456 204 464 minecraft:blackstone
setblock 459 202 464 minecraft:polished_blackstone_bricks
fill 460 202 464 460 205 464 minecraft:blackstone
setblock 462 202 471 minecraft:polished_blackstone_bricks
fill 462 202 472 462 205 472 minecraft:blackstone
setblock 462 202 476 minecraft:polished_blackstone_bricks
setblock 463 202 470 minecraft:polished_blackstone_bricks
fill 463 202 471 463 205 471 minecraft:blackstone
setblock 463 202 475 minecraft:polished_blackstone_bricks
fill 463 202 476 463 205 476 minecraft:blackstone
setblock 464 202 465 minecraft:blackstone
setblock 464 202 469 minecraft:polished_blackstone_bricks
fill 464 202 470 464 205 470 minecraft:blackstone
setblock 464 202 474 minecraft:polished_blackstone_bricks
fill 464 202 475 464 205 475 minecraft:blackstone
fill 424 203 465 424 203 467 minecraft:blackstone
setblock 424 203 468 minecraft:polished_blackstone_bricks
fill 424 203 469 424 206 469 minecraft:blackstone
setblock 424 203 473 minecraft:polished_blackstone_bricks
fill 424 203 474 424 206 474 minecraft:blackstone
fill 424 203 476 424 204 476 minecraft:blackstone
setblock 424 203 493 minecraft:polished_blackstone_bricks
fill 424 203 494 424 206 494 minecraft:blackstone
setblock 424 203 498 minecraft:polished_blackstone_bricks
fill 424 203 499 424 206 499 minecraft:blackstone
fill 430 203 504 432 203 504 minecraft:blackstone
setblock 433 203 464 minecraft:polished_blackstone_bricks
setblock 433 203 503 minecraft:blackstone
setblock 433 203 504 minecraft:polished_blackstone_bricks
fill 434 203 464 434 206 464 minecraft:blackstone
setblock 434 203 503 minecraft:polished_blackstone_bricks
fill 434 203 504 437 203 504 minecraft:blackstone
fill 435 203 503 435 206 503 minecraft:blackstone
setblock 438 203 464 minecraft:polished_blackstone_bricks
setblock 438 203 504 minecraft:polished_blackstone_bricks
setblock 439 203 503 minecraft:polished_blackstone_bricks
fill 439 203 504 439 206 504 minecraft:blackstone
setblock 458 203 464 minecraft:polished_blackstone_bricks
fill 459 203 464 459 206 464 minecraft:blackstone
fill 461 203 472 461 203 473 minecraft:blackstone
setblock 462 203 470 minecraft:polished_blackstone_bricks
fill 462 203 471 462 206 471 minecraft:blackstone
setblock 462 203 475 minecraft:polished_blackstone_bricks
fill 462 203 476 462 206 476 minecraft:blackstone
setblock 463 203 469 minecraft:polished_blackstone_bricks
fill 463 203 470 463 206 470 minecraft:blackstone
setblock 463 203 474 minecraft:polished_blackstone_bricks
fill 463 203 475 463 206 475 minecraft:blackstone
setblock 464 203 468 minecraft:polished_blackstone_bricks
fill 464 203 469 464 206 469 minecraft:blackstone
setblock 464 203 473 minecraft:polished_blackstone_bricks
fill 464 203 474 464 206 474 minecraft:blackstone
setblock 464 203 478 minecraft:polished_blackstone_bricks
fill 464 203 479 464 206 479 minecraft:blackstone
setblock 424 204 466 minecraft:blackstone
setblock 424 204 467 minecraft:polished_blackstone_bricks
fill 424 204 468 424 206 468 minecraft:blackstone
setblock 424 204 472 minecraft:polished_blackstone_bricks
fill 424 204 473 424 207 473 minecraft:blackstone
fill 424 204 493 424 207 493 minecraft:blackstone
fill 424 204 495 424 204 496 minecraft:blackstone
setblock 424 204 497 minecraft:polished_blackstone_bricks
fill 424 204 498 424 207 498 minecraft:blackstone
fill 424 204 500 424 204 501 minecraft:blackstone
setblock 424 204 502 minecraft:polished_blackstone_bricks
fill 429 204 504 431 204 504 minecraft:blackstone
fill 431 204 503 432 204 503 minecraft:blackstone
setblock 432 204 464 minecraft:polished_blackstone_bricks
setblock 432 204 504 minecraft:polished_blackstone_bricks
fill 433 204 464 433 207 464 minecraft:blackstone
setblock 433 204 502 minecraft:blackstone
setblock 433 204 503 minecraft:polished_blackstone_bricks
fill 433 204 504 436 204 504 minecraft:blackstone
setblock 434 204 502 minecraft:polished_blackstone_bricks
fill 434 204 503 434 207 503 minecraft:blackstone
fill 435 204 502 438 204 502 minecraft:blackstone
setblock 437 204 464 minecraft:polished_blackstone_bricks
setblock 437 204 503 minecraft:blackstone
setblock 437 204 504 minecraft:polished_blackstone_bricks
setblock 438 204 503 minecraft:polished_blackstone_bricks
fill 438 204 504 438 207 504 minecraft:blackstone
fill 439 204 503 439 207 503 minecraft:blackstone
setblock 441 204 504 minecraft:blackstone
fill 455 204 464 455 205 464 minecraft:blackstone
setblock 457 204 464 minecraft:polished_blackstone_bricks
fill 458 204 464 458 206 465 minecraft:blackstone
fill 461 204 473 461 204 474 minecraft:blackstone
setblock 462 204 464 minecraft:polished_blackstone_bricks
fill 462 204 470 462 205 470 minecraft:blackstone
setblock 462 204 474 minecraft:polished_blackstone_bricks
fill 462 204 475 462 207 475 minecraft:blackstone
fill 462 204 477 462 205 477 minecraft:blackstone
setblock 463 204 468 minecraft:polished_blackstone_bricks
fill 463 204 469 463 206 469 minecraft:blackstone
setblock 463 204 473 minecraft:polished_blackstone_bricks
fill 463 204 474 463 207 474 minecraft:blackstone
setblock 463 204 478 minecraft:polished_blackstone_bricks
setblock 464 204 467 minecraft:polished_blackstone_bricks
fill 464 204 468 464 207 468 minecraft:blackstone
setblock 464 204 472 minecraft:polished_blackstone_bricks
fill 464 204 473 464 207 473 minecraft:blackstone
setblock 464 204 477 minecraft:polished_blackstone_bricks
fill 464 204 478 464 207 478 minecraft:blackstone
setblock 424 205 467 minecraft:blackstone
setblock 424 205 471 minecraft:polished_blackstone_bricks
fill 424 205 472 424 208 472 minecraft:blackstone
setblock 424 205 476 minecraft:polished_blackstone_bricks
fill 424 205 477 424 208 477 minecraft:blackstone
setblock 424 205 495 minecraft:blackstone
setblock 424 205 496 minecraft:polished_blackstone_bricks
fill 424 205 497 425 207 497 minecraft:blackstone
setblock 424 205 500 minecraft:blackstone
setblock 424 205 501 minecraft:polished_blackstone_bricks
fill 424 205 502 424 206 504 minecraft:blackstone
fill 425 205 498 425 205 499 minecraft:blackstone
setblock 425 205 504 minecraft:blackstone
setblock 426 205 504 minecraft:polished_blackstone_bricks
fill 427 205 504 430 205 504 minecraft:blackstone
fill 429 205 503 431 205 503 minecraft:blackstone
setblock 430 205 464 minecraft:blackstone
setblock 431 205 464 minecraft:polished_blackstone_bricks
setblock 431 205 504 minecraft:polished_blackstone_bricks
fill 432 205 464 432 208 464 minecraft:blackstone
setblock 432 205 502 minecraft:blackstone
setblock 432 205 503 minecraft:polished_blackstone_bricks
fill 432 205 504 435 205 504 minecraft:blackstone
setblock 433 205 502 minecraft:polished_blackstone_bricks
fill 433 205 503 433 208 503 minecraft:blackstone
setblock 434 205 501 minecraft:polished_blackstone_bricks
fill 434 205 502 437 205 502 minecraft:blackstone
fill 435 205 501 436 207 501 minecraft:blackstone
setblock 436 205 464 minecraft:polished_blackstone_bricks
setblock 436 205 504 minecraft:polished_blackstone_bricks
fill 437 205 464 437 207 464 minecraft:blackstone
setblock 437 205 503 minecraft:polished_blackstone_bricks
fill 437 205 504 437 208 504 minecraft:blackstone
setblock 438 205 502 minecraft:polished_blackstone_bricks
fill 438 205 503 438 208 503 minecraft:blackstone
setblock 441 205 504 minecraft:polished_blackstone_bricks
fill 454 205 464 454 206 464 minecraft:blackstone
fill 454 205 504 455 205 504 minecraft:blackstone
setblock 456 205 464 minecraft:polished_blackstone_bricks
fill 456 205 465 457 207 465 minecraft:blackstone
setblock 456 205 504 minecraft:polished_blackstone_bricks
fill 457 205 464 457 208 464 minecraft:blackstone
fill 457 205 504 459 206 504 minecraft:blackstone
setblock 459 205 465 minecraft:blackstone
setblock 461 205 464 minecraft:polished_blackstone_bricks
setblock 461 205 473 minecraft:blackstone
setblock 461 205 474 minecraft:polished_blackstone_bricks
setblock 461 205 475 minecraft:blackstone
fill 462 205 464 463 207 464 minecraft:blackstone
setblock 462 205 473 minecraft:polished_blackstone_bricks
fill 462 205 474 462 207 474 minecraft:blackstone
setblock 463 205 468 minecraft:blackstone
setblock 463 205 472 minecraft:polished_blackstone_bricks
fill 463 205 473 463 208 473 minecraft:blackstone
setblock 463 205 477 minecraft:polished_blackstone_bricks
fill 463 205 478 463 208 478 minecraft:blackstone
setblock 464 205 465 minecraft:blackstone
setblock 464 205 466 minecraft:polished_blackstone_bricks
fill 464 205 467 464 208 467 minecraft:blackstone
setblock 464 205 471 minecraft:polished_blackstone_bricks
fill 464 205 472 464 208 472 minecraft:blackstone
setblock 464 205 476 minecraft:polished_blackstone_bricks
fill 464 205 477 464 208 477 minecraft:blackstone
setblock 464 205 480 minecraft:blackstone
setblock 464 205 495 minecraft:blackstone
setblock 464 205 496 minecraft:polished_blackstone_bricks
fill 464 205 497 464 207 498 minecraft:blackstone
setblock 424 206 470 minecraft:polished_blackstone_bricks
fill 424 206 471 424 207 471 minecraft:blackstone
setblock 424 206 475 minecraft:polished_blackstone_bricks
fill 424 206 476 424 209 476 minecraft:blackstone
setblock 424 206 495 minecraft:polished_blackstone_bricks
fill 424 206 496 425 208 496 minecraft:blackstone
setblock 424 206 500 minecraft:polished_blackstone_bricks
fill 424 206 501 425 208 501 minecraft:blackstone
setblock 425 206 498 minecraft:blackstone
setblock 425 206 499 minecraft:polished_blackstone_bricks
fill 425 206 500 425 209 500 minecraft:blackstone
setblock 425 206 504 minecraft:polished_blackstone_bricks
fill 426 206 504 429 206 504 minecraft:blackstone
fill 428 206 503 430 206 503 minecraft:blackstone
setblock 429 206 464 minecraft:blackstone
setblock 430 206 464 minecraft:polished_blackstone_bricks
fill 430 206 502 431 206 502 minecraft:blackstone
setblock 430 206 504 minecraft:polished_blackstone_bricks
fill 431 206 464 431 209 464 minecraft:blackstone
setblock 431 206 503 minecraft:polished_blackstone_bricks
fill 431 206 504 434 206 504 minecraft:blackstone
setblock 432 206 501 minecraft:blackstone
setblock 432 206 502 minecraft:polished_blackstone_bricks
fill 432 206 503 432 209 503 minecraft:blackstone
setblock 433 206 501 minecraft:polished_blackstone_bricks
fill 433 206 502 436 206 502 minecraft:blackstone
fill 434 206 501 434 209 501 minecraft:blackstone
setblock 435 206 464 minecraft:polished_blackstone_bricks
setblock 435 206 504 minecraft:polished_blackstone_bricks
fill 436 206 464 436 209 464 minecraft:blackstone
setblock 436 206 503 minecraft:polished_blackstone_bricks
fill 436 206 504 436 209 504 minecraft:blackstone
setblock 437 206 501 minecraft:blackstone
setblock 437 206 502 minecraft:polished_blackstone_bricks
fill 437 206 503 437 209 503 minecraft:blackstone
fill 438 206 502 438 209 502 minecraft:blackstone
setblock 440 206 503 minecraft:blackstone
setblock 440 206 504 minecraft:polished_blackstone_bricks
fill 441 206 504 441 208 504 minecraft:blackstone
fill 453 206 464 453 207 464 minecraft:blackstone
fill 453 206 504 454 206 504 minecraft:blackstone
setblock 455 206 464 minecraft:polished_blackstone_bricks
fill 455 206 465 455 209 465 minecraft:blackstone
setblock 455 206 504 minecraft:polished_blackstone_bricks
fill 456 206 464 456 209 464 minecraft:blackstone
fill 456 206 504 456 209 504 minecraft:blackstone
setblock 459 206 465 minecraft:polished_blackstone_bricks
setblock 460 206 464 minecraft:polished_blackstone_bricks
setblock 460 206 504 minecraft:polished_blackstone_bricks
fill 461 206 464 461 209 464 minecraft:blackstone
setblock 462 206 472 minecraft:polished_blackstone_bricks
fill 462 206 473 462 207 473 minecraft:blackstone
setblock 462 206 477 minecraft:polished_blackstone_bricks
setblock 463 206 471 minecraft:polished_blackstone_bricks
fill 463 206 472 463 208 472 minecraft:blackstone
setblock 463 206 476 minecraft:polished_blackstone_bricks
fill 463 206 477 463 209 477 minecraft:blackstone
fill 463 206 479 463 207 479 minecraft:blackstone
setblock 464 206 465 minecraft:polished_blackstone_bricks
fill 464 206 466 464 208 466 minecraft:blackstone
setblock 464 206 470 minecraft:polished_blackstone_bricks
fill 464 206 471 464 209 471 minecraft:blackstone
setblock 464 206 475 minecraft:polished_blackstone_bricks
fill 464 206 476 464 209 476 minecraft:blackstone
setblock 464 206 480 minecraft:polished_blackstone_bricks
setblock 464 206 495 minecraft:polished_blackstone_bricks
fill 464 206 496 464 208 496 minecraft:blackstone
setblock 464 206 499 minecraft:blackstone
setblock 464 206 500 minecraft:polished_blackstone_bricks
fill 464 206 501 464 209 501 minecraft:blackstone
setblock 424 207 470 minecraft:blackstone
setblock 424 207 474 minecraft:polished_blackstone_bricks
fill 424 207 475 424 209 475 minecraft:blackstone
setblock 424 207 478 minecraft:blackstone
setblock 424 207 494 minecraft:polished_blackstone_bricks
fill 424 207 495 424 210 495 minecraft:blackstone
setblock 424 207 499 minecraft:polished_blackstone_bricks
fill 424 207 500 424 210 500 minecraft:blackstone
fill 424 207 502 424 207 503 minecraft:blackstone
setblock 424 207 504 minecraft:polished_blackstone_bricks
setblock 425 207 498 minecraft:polished_blackstone_bricks
fill 425 207 499 425 210 499 minecraft:blackstone
setblock 425 207 502 minecraft:blackstone
setblock 425 207 503 minecraft:polished_blackstone_bricks
fill 425 207 504 428 207 504 minecraft:blackstone
fill 426 207 503 429 207 503 minecraft:blackstone
setblock 428 207 464 minecraft:blackstone
fill 428 207 502 430 207 502 minecraft:blackstone
setblock 429 207 464 minecraft:polished_blackstone_bricks
setblock 429 207 504 minecraft:polished_blackstone_bricks
fill 430 207 464 430 210 464 minecraft:blackstone
setblock 430 207 503 minecraft:polished_blackstone_bricks
fill 430 207 504 433 207 504 minecraft:blackstone
setblock 431 207 501 minecraft:blackstone
setblock 431 207 502 minecraft:polished_blackstone_bricks
fill 431 207 503 431 210 503 minecraft:blackstone
setblock 432 207 501 minecraft:polished_blackstone_bricks
fill 432 207 502 435 207 502 minecraft:blackstone
setblock 433 207 500 minecraft:polished_blackstone_bricks
fill 433 207 501 433 210 501 minecraft:blackstone
setblock 434 207 464 minecraft:polished_blackstone_bricks
fill 434 207 500 435 208 500 minecraft:blackstone
setblock 434 207 504 minecraft:polished_blackstone_bricks
fill 435 207 464 435 210 464 minecraft:blackstone
setblock 435 207 503 minecraft:polished_blackstone_bricks
fill 435 207 504 435 210 504 minecraft:blackstone
setblock 436 207 502 minecraft:polished_blackstone_bricks
fill 436 207 503 436 210 503 minecraft:blackstone
setblock 437 207 501 minecraft:polished_blackstone_bricks
fill 437 207 502 437 210 502 minecraft:blackstone
setblock 439 207 502 minecraft:blackstone
setblock 439 207 504 minecraft:polished_blackstone_bricks
setblock 440 207 503 minecraft:polished_blackstone_bricks
fill 440 207 504 440 210 504 minecraft:blackstone
fill 451 207 504 453 207 504 minecraft:blackstone
fill 452 207 464 452 208 464 minecraft:blackstone
setblock 454 207 464 minecraft:polished_blackstone_bricks
fill 454 207 465 454 210 465 minecraft:blackstone
setblock 454 207 503 minecraft:blackstone
setblock 454 207 504 minecraft:polished_blackstone_bricks
fill 455 207 464 455 210 464 minecraft:blackstone
setblock 455 207 503 minecraft:polished_blackstone_bricks
fill 455 207 504 455 210 504 minecraft:blackstone
fill 456 207 503 457 209 503 minecraft:blackstone
fill 457 207 504 458 207 504 minecraft:blackstone
setblock 458 207 464 minecraft:blackstone
setblock 458 207 465 minecraft:polished_blackstone_bricks
setblock 459 207 464 minecraft:polished_blackstone_bricks
setblock 459 207 504 minecraft:polished_blackstone_bricks
fill 460 207 464 460 210 464 minecraft:blackstone
fill 460 207 504 461 209 504 minecraft:blackstone
setblock 462 207 472 minecraft:blackstone
setblock 462 207 476 minecraft:polished_blackstone_bricks
setblock 462 207 477 minecraft:blackstone
setblock 463 207 470 minecraft:polished_blackstone_bricks
fill 463 207 471 463 208 471 minecraft:blackstone
setblock 463 207 475 minecraft:polished_blackstone_bricks
fill 463 207 476 463 209 476 minecraft:blackstone
setblock 464 207 464 minecraft:polished_blackstone_bricks
fill 464 207 465 464 208 465 minecraft:blackstone
setblock 464 207 469 minecraft:polished_blackstone_bricks
fill 464 207 470 464 209 470 minecraft:blackstone
setblock 464 207 474 minecraft:polished_blackstone_bricks
fill 464 207 475 464 210 475 minecraft:blackstone
setblock 464 207 479 minecraft:polished_blackstone_bricks
fill 464 207 480 464 210 480 minecraft:blackstone
setblock 464 207 499 minecraft:polished_blackstone_bricks
fill 464 207 500 464 210 500 minecraft:blackstone
fill 464 207 502 464 208 502 minecraft:blackstone
setblock 424 208 473 minecraft:polished_blackstone_bricks
setblock 424 208 474 minecraft:blackstone
setblock 424 208 478 minecraft:polished_blackstone_bricks
fill 424 208 494 424 209 494 minecraft:blackstone
setblock 424 208 497 minecraft:blackstone
setblock 424 208 498 minecraft:polished_blackstone_bricks
fill 424 208 499 424 211 499 minecraft:blackstone
setblock 424 208 502 minecraft:blackstone
setblock 424 208 503 minecraft:polished_blackstone_bricks
fill 424 208 504 427 208 504 minecraft:blackstone
setblock 425 208 497 minecraft:polished_blackstone_bricks
fill 425 208 498 426 209 498 minecraft:blackstone
setblock 425 208 502 minecraft:polished_blackstone_bricks
fill 425 208 503 428 208 503 minecraft:blackstone
setblock 426 208 466 minecraft:light[level=11]
setblock 426 208 474 minecraft:light[level=11]
setblock 426 208 482 minecraft:light[level=11]
setblock 426 208 490 minecraft:light[level=11]
fill 426 208 499 426 208 500 minecraft:blackstone
setblock 427 208 464 minecraft:blackstone
fill 427 208 502 429 208 502 minecraft:blackstone
setblock 428 208 464 minecraft:polished_blackstone_bricks
setblock 428 208 504 minecraft:polished_blackstone_bricks
fill 429 208 464 429 211 464 minecraft:blackstone
setblock 429 208 503 minecraft:polished_blackstone_bricks
fill 429 208 504 432 208 504 minecraft:blackstone
setblock 430 208 501 minecraft:blackstone
setblock 430 208 502 minecraft:polished_blackstone_bricks
fill 430 208 503 430 211 503 minecraft:blackstone
setblock 431 208 501 minecraft:polished_blackstone_bricks
fill 431 208 502 434 208 502 minecraft:blackstone
setblock 432 208 500 minecraft:polished_blackstone_bricks
fill 432 208 501 432 211 501 minecraft:blackstone
setblock 433 208 464 minecraft:polished_blackstone_bricks
fill 433 208 500 433 209 500 minecraft:blackstone
setblock 433 208 504 minecraft:polished_blackstone_bricks
fill 434 208 464 434 211 464 minecraft:blackstone
setblock 434 208 466 minecraft:light[level=11]
setblock 434 208 474 minecraft:light[level=11]
setblock 434 208 482 minecraft:light[level=11]
setblock 434 208 490 minecraft:light[level=11]
setblock 434 208 498 minecraft:light[level=11]
setblock 434 208 503 minecraft:polished_blackstone_bricks
fill 434 208 504 434 211 504 minecraft:blackstone
setblock 435 208 501 minecraft:blackstone
setblock 435 208 502 minecraft:polished_blackstone_bricks
fill 435 208 503 435 211 503 minecraft:blackstone
setblock 436 208 501 minecraft:polished_blackstone_bricks
fill 436 208 502 436 211 502 minecraft:blackstone
setblock 437 208 501 minecraft:blackstone
setblock 438 208 504 minecraft:polished_blackstone_bricks
setblock 439 208 503 minecraft:polished_blackstone_bricks
fill 439 208 504 439 211 504 minecraft:blackstone
setblock 442 208 466 minecraft:light[level=11]
setblock 442 208 474 minecraft:light[level=11]
setblock 442 208 482 minecraft:light[level=11]
setblock 442 208 490 minecraft:light[level=11]
setblock 442 208 498 minecraft:light[level=11]
setblock 450 208 466 minecraft:light[level=11]
setblock 450 208 474 minecraft:light[level=11]
setblock 450 208 482 minecraft:light[level=11]
setblock 450 208 498 minecraft:light[level=11]
fill 450 208 504 452 208 504 minecraft:blackstone
fill 451 208 464 451 209 464 minecraft:blackstone
fill 452 208 503 453 208 503 minecraft:blackstone
setblock 453 208 464 minecraft:polished_blackstone_bricks
setblock 453 208 504 minecraft:polished_blackstone_bricks
fill 454 208 464 454 211 464 minecraft:blackstone
setblock 454 208 503 minecraft:polished_blackstone_bricks
fill 454 208 504 454 211 504 minecraft:blackstone
fill 455 208 503 455 211 503 minecraft:blackstone
setblock 456 208 465 minecraft:blackstone
setblock 457 208 465 minecraft:polished_blackstone_bricks
setblock 457 208 504 minecraft:blackstone
setblock 458 208 464 minecraft:polished_blackstone_bricks
setblock 458 208 465 minecraft:blackstone
setblock 458 208 466 minecraft:light[level=11]
setblock 458 208 474 minecraft:light[level=11]
setblock 458 208 482 minecraft:light[level=11]
setblock 458 208 490 minecraft:light[level=11]
setblock 458 208 498 minecraft:light[level=11]
setblock 458 208 504 minecraft:polished_blackstone_bricks
fill 459 208 464 459 211 464 minecraft:blackstone
fill 459 208 504 459 211 504 minecraft:blackstone
setblock 462 208 464 minecraft:blackstone
setblock 462 208 475 minecraft:polished_blackstone_bricks
setblock 462 208 476 minecraft:blackstone
setblock 462 208 504 minecraft:blackstone
setblock 463 208 464 minecraft:polished_blackstone_bricks
setblock 463 208 474 minecraft:polished_blackstone_bricks
fill 463 208 475 463 209 475 minecraft:blackstone
setblock 463 208 479 minecraft:polished_blackstone_bricks
fill 464 208 464 464 211 464 minecraft:blackstone
setblock 464 208 468 minecraft:polished_blackstone_bricks
fill 464 208 469 464 209 469 minecraft:blackstone
setblock 464 208 473 minecraft:polished_blackstone_bricks
fill 464 208 474 464 211 474 minecraft:blackstone
setblock 464 208 478 minecraft:polished_blackstone_bricks
fill 464 208 479 464 211 479 minecraft:blackstone
fill 464 208 481 464 209 481 minecraft:blackstone
setblock 464 208 497 minecraft:blackstone
setblock 464 208 498 minecraft:polished_blackstone_bricks
fill 464 208 499 464 211 499 minecraft:blackstone
setblock 464 208 503 minecraft:polished_blackstone_bricks
fill 464 208 504 464 211 504 minecraft:blackstone
setblock 424 209 477 minecraft:polished_blackstone_bricks
setblock 424 209 478 minecraft:blackstone
setblock 424 209 496 minecraft:blackstone
setblock 424 209 497 minecraft:polished_blackstone_bricks
fill 424 209 498 424 212 498 minecraft:blackstone
setblock 424 209 501 minecraft:blackstone
setblock 424 209 502 minecraft:polished_blackstone_bricks
fill 424 209 503 426 209 504 minecraft:blackstone
setblock 425 209 496 minecraft:polished_blackstone_bricks
fill 425 209 497 425 211 497 minecraft:blackstone
setblock 425 209 501 minecraft:polished_blackstone_bricks
fill 425 209 502 425 212 502 minecraft:blackstone
setblock 426 209 499 minecraft:blackstone
setblock 426 209 500 minecraft:polished_blackstone_bricks
fill 426 209 501 426 212 501 minecraft:blackstone
setblock 427 209 464 minecraft:polished_blackstone_bricks
fill 427 209 502 427 209 503 minecraft:blackstone
setblock 427 209 504 minecraft:polished_blackstone_bricks
fill 428 209 464 428 212 464 minecraft:blackstone
setblock 428 209 502 minecraft:blackstone
setblock 428 209 503 minecraft:polished_blackstone_bricks
fill 428 209 504 431 209 504 minecraft:blackstone
setblock 429 209 501 minecraft:blackstone
setblock 429 209 502 minecraft:polished_blackstone_bricks
fill 429 209 503 429 212 503 minecraft:blackstone
setblock 430 209 501 minecraft:polished_blackstone_bricks
fill 430 209 502 433 209 502 minecraft:blackstone
fill 431 209 501 431 212 501 minecraft:blackstone
setblock 432 209 464 minecraft:polished_blackstone_bricks
setblock 432 209 500 minecraft:blackstone
setblock 432 209 504 minecraft:polished_blackstone_bricks
fill 433 209 464 433 212 464 minecraft:blackstone
setblock 433 209 503 minecraft:polished_blackstone_bricks
fill 433 209 504 433 212 504 minecraft:blackstone
setblock 434 209 500 minecraft:blackstone
setblock 434 209 502 minecraft:polished_blackstone_bricks
fill 434 209 503 434 212 503 minecraft:blackstone
setblock 435 209 501 minecraft:polished_blackstone_bricks
fill 435 209 502 435 212 502 minecraft:blackstone
fill 436 209 501 436 210 501 minecraft:blackstone
setblock 437 209 504 minecraft:polished_blackstone_bricks
setblock 438 209 503 minecraft:polished_blackstone_bricks
fill 438 209 504 438 212 504 minecraft:blackstone
setblock 439 209 503 minecraft:blackstone
fill 449 209 504 451 209 504 minecraft:blackstone
fill 450 209 464 450 210 464 minecraft:blackstone
fill 451 209 503 452 209 503 minecraft:blackstone
setblock 452 209 464 minecraft:polished_blackstone_bricks
setblock 452 209 504 minecraft:polished_blackstone_bricks
fill 453 209 464 453 211 465 minecraft:blackstone
setblock 453 209 503 minecraft:polished_blackstone_bricks
fill 453 209 504 453 212 504 minecraft:blackstone
fill 454 209 503 454 212 503 minecraft:blackstone
setblock 456 209 465 minecraft:polished_blackstone_bricks
setblock 457 209 464 minecraft:polished_blackstone_bricks
setblock 457 209 465 minecraft:blackstone
setblock 457 209 504 minecraft:polished_blackstone_bricks
fill 458 209 464 458 212 464 minecraft:blackstone
fill 458 209 504 458 212 504 minecraft:blackstone
setblock 462 209 464 minecraft:polished_blackstone_bricks
setblock 462 209 504 minecraft:polished_blackstone_bricks
fill 463 209 464 463 212 464 minecraft:blackstone
setblock 463 209 473 minecraft:polished_blackstone_bricks
setblock 463 209 474 minecraft:blackstone
setblock 463 209 478 minecraft:polished_blackstone_bricks
fill 463 209 504 463 212 504 minecraft:blackstone
setblock 464 209 472 minecraft:polished_blackstone_bricks
fill 464 209 473 464 210 473 minecraft:blackstone
setblock 464 209 477 minecraft:polished_blackstone_bricks
fill 464 209 478 464 212 478 minecraft:blackstone
setblock 464 209 497 minecraft:polished_blackstone_bricks
fill 464 209 498 464 210 498 minecraft:blackstone
setblock 464 209 502 minecraft:polished_blackstone_bricks
fill 464 209 503 464 212 503 minecraft:blackstone
setblock 424 210 496 minecraft:polished_blackstone_bricks
fill 424 210 497 424 213 497 minecraft:blackstone
setblock 424 210 501 minecraft:polished_blackstone_bricks
fill 424 210 502 424 211 504 minecraft:blackstone
fill 425 210 498 425 211 498 minecraft:blackstone
setblock 425 210 500 minecraft:polished_blackstone_bricks
fill 425 210 501 425 213 501 minecraft:blackstone
fill 425 210 503 425 210 504 minecraft:blackstone
setblock 426 210 499 minecraft:polished_blackstone_bricks
fill 426 210 500 426 213 500 minecraft:blackstone
fill 426 210 502 426 210 503 minecraft:blackstone
setblock 426 210 504 minecraft:polished_blackstone_bricks
fill 427 210 464 427 213 464 minecraft:blackstone
setblock 427 210 502 minecraft:blackstone
setblock 427 210 503 minecraft:polished_blackstone_bricks
fill 427 210 504 430 210 504 minecraft:blackstone
setblock 428 210 502 minecraft:polished_blackstone_bricks
fill 428 210 503 428 213 503 minecraft:blackstone
setblock 429 210 501 minecraft:polished_blackstone_bricks
fill 429 210 502 432 210 502 minecraft:blackstone
fill 430 210 501 430 213 501 minecraft:blackstone
setblock 431 210 464 minecraft:polished_blackstone_bricks
setblock 431 210 504 minecraft:polished_blackstone_bricks
fill 432 210 464 432 213 464 minecraft:blackstone
setblock 432 210 503 minecraft:polished_blackstone_bricks
fill 432 210 504 432 213 504 minecraft:blackstone
setblock 433 210 502 minecraft:polished_blackstone_bricks
fill 433 210 503 433 213 503 minecraft:blackstone
setblock 434 210 501 minecraft:polished_blackstone_bricks
fill 434 210 502 434 213 502 minecraft:blackstone
fill 435 210 501 435 211 501 minecraft:blackstone
setblock 436 210 504 minecraft:polished_blackstone_bricks
setblock 437 210 503 minecraft:polished_blackstone_bricks
fill 437 210 504 437 213 504 minecraft:blackstone
fill 438 210 503 438 211 503 minecraft:blackstone
fill 448 210 504 450 210 504 minecraft:blackstone
setblock 451 210 464 minecraft:polished_blackstone_bricks
setblock 451 210 503 minecraft:blackstone
setblock 451 210 504 minecraft:polished_blackstone_bricks
fill 452 210 464 452 213 464 minecraft:blackstone
setblock 452 210 503 minecraft:polished_blackstone_bricks
fill 452 210 504 452 213 504 minecraft:blackstone
fill 453 210 503 453 213 503 minecraft:blackstone
setblock 455 210 465 minecraft:polished_blackstone_bricks
setblock 456 210 464 minecraft:polished_blackstone_bricks
setblock 456 210 465 minecraft:blackstone
setblock 456 210 503 minecraft:blackstone
setblock 456 210 504 minecraft:polished_blackstone_bricks
fill 457 210 464 457 213 464 minecraft:blackstone
setblock 457 210 503 minecraft:polished_blackstone_bricks
fill 457 210 504 457 213 504 minecraft:blackstone
setblock 460 210 504 minecraft:blackstone
setblock 461 210 464 minecraft:polished_blackstone_bricks
setblock 461 210 504 minecraft:polished_blackstone_bricks
fill 462 210 464 462 213 464 minecraft:blackstone
fill 462 210 504 462 213 504 minecraft:blackstone
setblock 464 210 471 minecraft:polished_blackstone_bricks
setblock 464 210 472 minecraft:blackstone
setblock 464 210 476 minecraft:polished_blackstone_bricks
fill 464 210 477 464 212 477 minecraft:blackstone
setblock 464 210 501 minecraft:polished_blackstone_bricks
fill 464 210 502 464 213 502 minecraft:blackstone
fill 424 211 496 424 212 496 minecraft:blackstone
setblock 424 211 500 minecraft:polished_blackstone_bricks
fill 424 211 501 424 214 501 minecraft:blackstone
setblock 425 211 499 minecraft:polished_blackstone_bricks
fill 425 211 500 425 214 500 minecraft:blackstone
setblock 425 211 503 minecraft:blackstone
setblock 425 211 504 minecraft:polished_blackstone_bricks
setblock 426 211 499 minecraft:blackstone
setblock 426 211 502 minecraft:blackstone
setblock 426 211 503 minecraft:polished_blackstone_bricks
fill 426 211 504 429 211 504 minecraft:blackstone
setblock 427 211 502 minecraft:polished_blackstone_bricks
fill 427 211 503 427 214 503 minecraft:blackstone
fill 428 211 502 431 211 502 minecraft:blackstone
fill 429 211 501 429 213 501 minecraft:blackstone
setblock 430 211 464 minecraft:polished_blackstone_bricks
setblock 430 211 504 minecraft:polished_blackstone_bricks
fill 431 211 464 431 214 464 minecraft:blackstone
setblock 431 211 503 minecraft:polished_blackstone_bricks
fill 431 211 504 431 214 504 minecraft:blackstone
setblock 432 211 502 minecraft:polished_blackstone_bricks
fill 432 211 503 432 214 503 minecraft:blackstone
setblock 433 211 501 minecraft:polished_blackstone_bricks
fill 433 211 502 433 214 502 minecraft:blackstone
setblock 434 211 501 minecraft:blackstone
setblock 435 211 464 minecraft:polished_blackstone_bricks
setblock 435 211 504 minecraft:polished_blackstone_bricks
setblock 436 211 503 minecraft:polished_blackstone_bricks
fill 436 211 504 436 214 504 minecraft:blackstone
fill 437 211 503 437 212 503 minecraft:blackstone
fill 448 211 504 449 211 504 minecraft:blackstone
setblock 449 211 464 minecraft:blackstone
setblock 450 211 464 minecraft:polished_blackstone_bricks
setblock 450 211 503 minecraft:blackstone
setblock 450 211 504 minecraft:polished_blackstone_bricks
fill 451 211 464 451 214 464 minecraft:blackstone
setblock 451 211 503 minecraft:polished_blackstone_bricks
fill 451 211 504 451 214 504 minecraft:blackstone
fill 452 211 503 452 214 503 minecraft:blackstone
setblock 454 211 465 minecraft:polished_blackstone_bricks
setblock 455 211 464 minecraft:polished_blackstone_bricks
fill 455 211 465 455 212 465 minecraft:blackstone
setblock 455 211 504 minecraft:polished_blackstone_bricks
fill 456 211 464 456 214 464 minecraft:blackstone
setblock 456 211 503 minecraft:polished_blackstone_bricks
fill 456 211 504 456 214 504 minecraft:blackstone
setblock 460 211 464 minecraft:polished_blackstone_bricks
setblock 460 211 504 minecraft:polished_blackstone_bricks
fill 461 211 464 461 214 464 minecraft:blackstone
fill 461 211 504 461 214 504 minecraft:blackstone
setblock 464 211 475 minecraft:polished_blackstone_bricks
setblock 464 211 476 minecraft:blackstone
setblock 464 211 480 minecraft:polished_blackstone_bricks
setblock 464 211 500 minecraft:polished_blackstone_bricks
fill 464 211 501 464 214 501 minecraft:blackstone
setblock 423 212 471 minecraft:soul_soil
fill 423 212 478 423 215 479 minecraft:blackstone
setblock 423 212 480 minecraft:soul_soil
fill 423 212 481 423 213 481 minecraft:blackstone
fill 423 212 498 423 213 503 minecraft:blackstone
fill 423 212 504 423 213 504 minecraft:soul_soil
fill 423 212 505 423 215 505 minecraft:blackstone
setblock 424 212 499 minecraft:polished_blackstone_bricks
fill 424 212 500 424 215 500 minecraft:blackstone
fill 424 212 502 424 212 503 minecraft:blackstone
setblock 424 212 504 minecraft:polished_blackstone_bricks
setblock 425 212 498 minecraft:polished_blackstone_bricks
fill 425 212 499 425 215 499 minecraft:blackstone
setblock 425 212 503 minecraft:polished_blackstone_bricks
fill 425 212 504 427 213 505 minecraft:blackstone
fill 426 212 464 426 214 464 minecraft:blackstone
setblock 426 212 502 minecraft:polished_blackstone_bricks
fill 426 212 503 426 215 503 minecraft:blackstone
fill 427 212 502 430 212 502 minecraft:blackstone
setblock 428 212 504 minecraft:blackstone
setblock 428 212 505 minecraft:soul_soil
setblock 429 212 464 minecraft:polished_blackstone_bricks
setblock 429 212 504 minecraft:polished_blackstone_bricks
fill 429 212 505 429 215 505 minecraft:blackstone
fill 430 212 464 430 215 464 minecraft:blackstone
setblock 430 212 503 minecraft:polished_blackstone_bricks
fill 430 212 504 430 215 504 minecraft:blackstone
setblock 430 212 505 minecraft:soul_soil
setblock 431 212 502 minecraft:polished_blackstone_bricks
fill 431 212 503 431 215 503 minecraft:blackstone
fill 431 212 505 431 215 505 minecraft:blackstone
fill 432 212 463 433 212 463 minecraft:blackstone
setblock 432 212 501 minecraft:polished_blackstone_bricks
fill 432 212 502 432 215 502 minecraft:blackstone
setblock 433 212 501 minecraft:blackstone
setblock 434 212 463 minecraft:soul_soil
setblock 434 212 464 minecraft:polished_blackstone_bricks
setblock 434 212 504 minecraft:polished_blackstone_bricks
setblock 435 212 503 minecraft:polished_blackstone_bricks
fill 435 212 504 435 215 504 minecraft:blackstone
fill 436 212 503 436 214 503 minecraft:blackstone
fill 438 212 463 438 215 463 minecraft:blackstone
setblock 439 212 463 minecraft:soul_soil
fill 440 212 463 449 212 463 minecraft:blackstone
setblock 448 212 504 minecraft:blackstone
setblock 449 212 464 minecraft:polished_blackstone_bricks
setblock 449 212 504 minecraft:polished_blackstone_bricks
fill 450 212 464 450 215 464 minecraft:blackstone
setblock 450 212 503 minecraft:polished_blackstone_bricks
fill 450 212 504 450 215 504 minecraft:blackstone
fill 451 212 503 451 215 503 minecraft:blackstone
setblock 452 212 465 minecraft:blackstone
setblock 453 212 464 minecraft:blackstone
setblock 453 212 465 minecraft:polished_blackstone_bricks
setblock 454 212 464 minecraft:polished_blackstone_bricks
fill 454 212 465 454 215 465 minecraft:blackstone
setblock 454 212 504 minecraft:polished_blackstone_bricks
fill 455 212 463 455 215 464 minecraft:blackstone
setblock 455 212 503 minecraft:polished_blackstone_bricks
fill 455 212 504 455 215 504 minecraft:blackstone
fill 456 212 463 457 212 463 minecraft:soul_soil
setblock 458 212 505 minecraft:soul_soil
setblock 459 212 464 minecraft:polished_blackstone_bricks
setblock 459 212 504 minecraft:polished_blackstone_bricks
fill 459 212 505 459 213 505 minecraft:blackstone
fill 460 212 464 460 215 464 minecraft:blackstone
fill 460 212 504 460 215 504 minecraft:blackstone
setblock 463 212 463 minecraft:soul_soil
setblock 464 212 464 minecraft:polished_blackstone_bricks
setblock 464 212 479 minecraft:polished_blackstone_bricks
setblock 464 212 499 minecraft:polished_blackstone_bricks
fill 464 212 500 465 212 500 minecraft:blackstone
setblock 464 212 504 minecraft:polished_blackstone_bricks
fill 465 212 479 465 213 479 minecraft:soul_soil
fill 465 212 499 465 213 499 minecraft:soul_soil
fill 465 212 501 465 215 501 minecraft:blackstone
fill 423 213 463 423 213 464 minecraft:soul_soil
fill 423 213 465 423 215 469 minecraft:blackstone
fill 423 213 471 423 215 471 minecraft:blackstone
fill 423 213 480 423 215 480 minecraft:blackstone
setblock 423 213 484 minecraft:soul_soil
fill 423 213 485 423 215 487 minecraft:blackstone
setblock 423 213 488 minecraft:soul_soil
fill 423 213 489 423 215 490 minecraft:blackstone
fill 423 213 492 423 215 492 minecraft:blackstone
setblock 423 213 493 minecraft:soul_soil
setblock 423 213 497 minecraft:soul_soil
setblock 424 213 498 minecraft:polished_blackstone_bricks
fill 424 213 499 424 216 499 minecraft:blackstone
setblock 424 213 502 minecraft:blackstone
setblock 424 213 503 minecraft:polished_blackstone_bricks
fill 424 213 504 424 216 504 minecraft:blackstone
fill 425 213 464 425 215 464 minecraft:blackstone
fill 425 213 498 425 216 498 minecraft:blackstone
setblock 425 213 502 minecraft:polished_blackstone_bricks
fill 425 213 503 425 216 503 minecraft:blackstone
setblock 426 213 501 minecraft:polished_blackstone_bricks
fill 426 213 502 429 213 502 minecraft:blackstone
setblock 428 213 464 minecraft:polished_blackstone_bricks
setblock 428 213 504 minecraft:polished_blackstone_bricks
fill 428 213 505 428 215 505 minecraft:blackstone
fill 429 213 464 429 216 464 minecraft:blackstone
setblock 429 213 503 minecraft:polished_blackstone_bricks
fill 429 213 504 429 216 504 minecraft:blackstone
setblock 430 213 502 minecraft:polished_blackstone_bricks
fill 430 213 503 430 216 503 minecraft:blackstone
fill 430 213 505 430 215 505 minecraft:blackstone
setblock 431 213 501 minecraft:polished_blackstone_bricks
fill 431 213 502 431 216 502 minecraft:blackstone
fill 432 213 463 432 215 463 minecraft:blackstone
setblock 432 213 501 minecraft:blackstone
fill 433 213 463 433 214 463 minecraft:soul_soil
setblock 433 213 464 minecraft:polished_blackstone_bricks
setblock 433 213 504 minecraft:polished_blackstone_bricks
fill 434 213 463 434 215 463 minecraft:blackstone
setblock 434 213 503 minecraft:polished_blackstone_bricks
fill 434 213 504 434 216 504 minecraft:blackstone
setblock 435 213 502 minecraft:polished_blackstone_bricks
fill 435 213 503 435 216 503 minecraft:blackstone
setblock 438 213 504 minecraft:polished_blackstone_bricks
fill 439 213 463 442 215 463 minecraft:blackstone
setblock 443 213 463 minecraft:soul_soil
fill 444 213 463 449 215 463 minecraft:blackstone
setblock 447 213 504 minecraft:blackstone
setblock 448 213 464 minecraft:polished_blackstone_bricks
setblock 448 213 504 minecraft:polished_blackstone_bricks
fill 449 213 464 449 216 464 minecraft:blackstone
fill 449 213 504 449 216 504 minecraft:blackstone
fill 450 213 503 450 216 503 minecraft:blackstone
setblock 451 213 465 minecraft:blackstone
setblock 452 213 465 minecraft:polished_blackstone_bricks
setblock 453 213 464 minecraft:polished_blackstone_bricks
fill 453 213 465 453 216 465 minecraft:blackstone
setblock 453 213 504 minecraft:polished_blackstone_bricks
fill 454 213 464 454 216 464 minecraft:blackstone
schedule function dropper:buildpart/117_6 1t
