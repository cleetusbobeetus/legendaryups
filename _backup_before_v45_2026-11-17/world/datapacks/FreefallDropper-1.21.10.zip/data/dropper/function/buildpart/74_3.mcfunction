setblock 133 131 341 minecraft:stripped_spruce_log
fill 133 131 342 133 134 342 minecraft:stone
setblock 133 131 345 minecraft:stone
setblock 133 131 346 minecraft:stripped_spruce_log
fill 133 131 347 133 132 347 minecraft:stone
fill 133 131 362 133 133 362 minecraft:stone
setblock 134 131 325 minecraft:stripped_spruce_log
fill 134 131 326 134 134 326 minecraft:stone
setblock 134 131 330 minecraft:stripped_spruce_log
fill 134 131 331 134 132 331 minecraft:stone
setblock 134 131 335 minecraft:stripped_spruce_log
fill 134 131 336 134 134 336 minecraft:stone
setblock 134 131 340 minecraft:stripped_spruce_log
fill 134 131 341 134 134 341 minecraft:stone
setblock 134 131 345 minecraft:stripped_spruce_log
fill 134 131 346 134 134 346 minecraft:stone
setblock 134 131 360 minecraft:stripped_spruce_log
fill 134 131 361 134 132 361 minecraft:stone
setblock 135 131 324 minecraft:stripped_spruce_log
fill 135 131 325 135 134 325 minecraft:stone
setblock 135 131 329 minecraft:stripped_spruce_log
fill 135 131 330 135 134 330 minecraft:stone
setblock 135 131 334 minecraft:stripped_spruce_log
fill 135 131 335 135 134 335 minecraft:stone
setblock 135 131 339 minecraft:stripped_spruce_log
fill 135 131 340 135 134 340 minecraft:stone
setblock 135 131 344 minecraft:stripped_spruce_log
fill 135 131 345 135 134 345 minecraft:stone
setblock 135 131 349 minecraft:stripped_spruce_log
setblock 135 131 350 minecraft:stone
setblock 135 131 359 minecraft:stripped_spruce_log
fill 135 131 360 135 133 360 minecraft:stone
fill 136 131 333 136 140 333 minecraft:deepslate
fill 136 131 345 136 186 345 minecraft:deepslate
fill 136 131 349 136 137 349 minecraft:deepslate
fill 136 131 352 136 152 352 minecraft:deepslate
setblock 136 131 353 minecraft:raw_iron_block
fill 136 131 354 136 173 354 minecraft:deepslate
fill 94 132 325 94 188 325 minecraft:deepslate
setblock 94 132 326 minecraft:raw_gold_block
fill 94 132 327 94 143 331 minecraft:deepslate
fill 94 132 339 94 178 339 minecraft:deepslate
setblock 95 132 323 minecraft:stripped_spruce_log
fill 95 132 324 95 132 327 minecraft:stone
setblock 95 132 328 minecraft:stripped_spruce_log
fill 95 132 329 95 132 332 minecraft:stone
setblock 95 132 333 minecraft:stripped_spruce_log
fill 95 132 334 95 133 334 minecraft:stone
setblock 95 132 338 minecraft:stripped_spruce_log
fill 95 132 339 95 134 339 minecraft:stone
setblock 95 132 343 minecraft:stripped_spruce_log
fill 95 132 344 95 135 344 minecraft:stone
fill 95 132 346 95 133 346 minecraft:stone
fill 95 132 357 96 132 357 minecraft:raw_gold_block
setblock 95 132 358 minecraft:stripped_spruce_log
fill 95 132 359 95 133 359 minecraft:stone
setblock 95 132 363 minecraft:stripped_spruce_log
fill 96 132 323 99 132 323 minecraft:stone
fill 96 132 324 96 135 324 minecraft:spruce_log
fill 96 132 325 96 132 326 minecraft:stone
setblock 96 132 327 minecraft:stripped_spruce_log
setblock 96 132 337 minecraft:stripped_spruce_log
setblock 96 132 338 minecraft:stone
setblock 96 132 342 minecraft:stripped_spruce_log
fill 96 132 343 96 135 343 minecraft:spruce_log
fill 96 132 358 97 132 358 minecraft:raw_gold_block
fill 96 132 362 96 135 362 minecraft:spruce_log
fill 96 132 363 99 132 363 minecraft:stone
fill 97 132 362 100 132 362 minecraft:stone
setblock 99 132 324 minecraft:stripped_spruce_log
setblock 100 132 323 minecraft:stripped_spruce_log
fill 100 132 324 103 132 324 minecraft:stone
setblock 100 132 363 minecraft:stripped_spruce_log
fill 100 132 364 106 135 364 minecraft:deepslate
fill 101 132 323 104 132 323 minecraft:stone
setblock 101 132 362 minecraft:stripped_spruce_log
fill 101 132 363 104 132 363 minecraft:stone
fill 102 132 362 105 132 362 minecraft:stone
fill 103 132 361 103 133 361 minecraft:stone
setblock 104 132 324 minecraft:stripped_spruce_log
setblock 105 132 323 minecraft:stripped_spruce_log
fill 105 132 324 105 135 324 minecraft:stone
setblock 105 132 363 minecraft:stripped_spruce_log
fill 106 132 322 106 182 322 minecraft:deepslate
fill 106 132 323 106 135 323 minecraft:stone
fill 106 132 325 107 132 325 minecraft:stone
fill 106 132 360 107 132 360 minecraft:stone
setblock 106 132 362 minecraft:stripped_spruce_log
fill 106 132 363 109 132 363 minecraft:stone
setblock 107 132 361 minecraft:stripped_spruce_log
fill 107 132 362 110 132 362 minecraft:stone
setblock 107 132 364 minecraft:raw_gold_block
setblock 108 132 325 minecraft:stripped_spruce_log
setblock 108 132 360 minecraft:stripped_spruce_log
fill 108 132 361 108 135 361 minecraft:stone
fill 108 132 364 109 160 364 minecraft:deepslate
setblock 109 132 324 minecraft:stripped_spruce_log
fill 109 132 325 109 135 325 minecraft:stone
fill 109 132 360 109 134 360 minecraft:stone
setblock 110 132 323 minecraft:stripped_spruce_log
fill 110 132 324 110 135 324 minecraft:stone
setblock 110 132 363 minecraft:stripped_spruce_log
fill 111 132 323 111 135 323 minecraft:stone
setblock 111 132 362 minecraft:stripped_spruce_log
fill 111 132 363 111 135 363 minecraft:stone
setblock 112 132 361 minecraft:stripped_spruce_log
fill 112 132 362 112 135 362 minecraft:stone
setblock 113 132 324 minecraft:stone
setblock 113 132 360 minecraft:stripped_spruce_log
fill 113 132 361 113 134 361 minecraft:stone
fill 113 132 364 113 186 364 minecraft:deepslate
setblock 114 132 324 minecraft:stripped_spruce_log
setblock 114 132 329 minecraft:raw_gold_block
setblock 114 132 360 minecraft:stone
setblock 115 132 323 minecraft:stripped_spruce_log
fill 115 132 324 115 135 324 minecraft:spruce_log
fill 115 132 362 115 135 362 minecraft:spruce_log
setblock 115 132 363 minecraft:stripped_spruce_log
fill 116 132 323 116 134 323 minecraft:stone
setblock 116 132 362 minecraft:stripped_spruce_log
fill 116 132 363 116 135 363 minecraft:stone
fill 117 132 362 117 133 362 minecraft:stone
setblock 120 132 362 minecraft:stone
setblock 120 132 363 minecraft:stripped_spruce_log
setblock 121 132 362 minecraft:stripped_spruce_log
fill 121 132 363 124 132 363 minecraft:stone
fill 122 132 362 125 132 362 minecraft:stone
fill 123 132 323 124 132 323 minecraft:stone
setblock 125 132 323 minecraft:stripped_spruce_log
setblock 125 132 363 minecraft:stripped_spruce_log
setblock 126 132 322 minecraft:raw_iron_block
fill 126 132 323 126 135 323 minecraft:stone
setblock 126 132 362 minecraft:stripped_spruce_log
fill 126 132 363 126 135 363 minecraft:stone
fill 127 132 324 128 132 324 minecraft:stone
fill 127 132 362 127 135 362 minecraft:stone
setblock 128 132 361 minecraft:stone
setblock 129 132 324 minecraft:stripped_spruce_log
setblock 130 132 323 minecraft:stripped_spruce_log
fill 130 132 324 130 135 324 minecraft:stone
setblock 130 132 363 minecraft:stripped_spruce_log
fill 131 132 323 131 135 323 minecraft:stone
setblock 131 132 342 minecraft:stripped_spruce_log
setblock 131 132 343 minecraft:stone
setblock 131 132 361 minecraft:stone
setblock 131 132 362 minecraft:stripped_spruce_log
fill 131 132 363 131 135 363 minecraft:stone
setblock 132 132 336 minecraft:stripped_spruce_log
setblock 132 132 337 minecraft:stone
setblock 132 132 341 minecraft:stripped_spruce_log
fill 132 132 342 132 134 342 minecraft:stone
fill 132 132 362 132 134 362 minecraft:stone
setblock 133 132 324 minecraft:stone
setblock 133 132 335 minecraft:stripped_spruce_log
fill 133 132 336 133 133 336 minecraft:stone
setblock 133 132 340 minecraft:stripped_spruce_log
fill 133 132 341 133 135 341 minecraft:stone
setblock 133 132 345 minecraft:stripped_spruce_log
fill 133 132 346 133 134 346 minecraft:stone
setblock 134 132 323 minecraft:stone
fill 134 132 324 134 135 324 minecraft:spruce_log
fill 134 132 325 134 135 325 minecraft:stone
setblock 134 132 329 minecraft:stripped_spruce_log
setblock 134 132 330 minecraft:stone
setblock 134 132 334 minecraft:stripped_spruce_log
fill 134 132 335 134 134 335 minecraft:stone
setblock 134 132 339 minecraft:stripped_spruce_log
fill 134 132 340 134 135 340 minecraft:stone
fill 134 132 343 134 135 343 minecraft:spruce_log
setblock 134 132 344 minecraft:stripped_spruce_log
fill 134 132 345 134 135 345 minecraft:stone
setblock 134 132 360 minecraft:stone
fill 134 132 362 134 135 362 minecraft:spruce_log
setblock 135 132 323 minecraft:stripped_spruce_log
fill 135 132 324 135 135 324 minecraft:stone
setblock 135 132 328 minecraft:stripped_spruce_log
fill 135 132 329 135 135 329 minecraft:stone
setblock 135 132 333 minecraft:stripped_spruce_log
fill 135 132 334 135 135 334 minecraft:stone
setblock 135 132 338 minecraft:stripped_spruce_log
fill 135 132 339 135 135 339 minecraft:stone
setblock 135 132 343 minecraft:stripped_spruce_log
fill 135 132 344 135 135 344 minecraft:stone
setblock 135 132 348 minecraft:stripped_spruce_log
fill 135 132 349 135 133 349 minecraft:stone
setblock 135 132 358 minecraft:stripped_spruce_log
setblock 135 132 359 minecraft:stone
setblock 135 132 363 minecraft:stripped_spruce_log
fill 136 132 353 136 186 353 minecraft:deepslate
fill 94 133 326 94 156 326 minecraft:deepslate
fill 95 133 323 95 133 326 minecraft:stone
setblock 95 133 327 minecraft:stripped_spruce_log
fill 95 133 328 95 133 331 minecraft:stone
setblock 95 133 332 minecraft:stripped_spruce_log
setblock 95 133 333 minecraft:stone
setblock 95 133 337 minecraft:stripped_spruce_log
fill 95 133 338 95 134 338 minecraft:stone
setblock 95 133 342 minecraft:stripped_spruce_log
fill 95 133 343 95 135 343 minecraft:stone
fill 95 133 357 95 133 358 minecraft:raw_gold_block
setblock 95 133 362 minecraft:stripped_spruce_log
fill 95 133 363 98 133 363 minecraft:stone
fill 96 133 323 98 133 323 minecraft:stone
setblock 96 133 325 minecraft:stone
setblock 96 133 326 minecraft:stripped_spruce_log
setblock 96 133 327 minecraft:stone
setblock 96 133 358 minecraft:raw_gold_block
setblock 97 133 325 minecraft:light[level=12]
setblock 97 133 332 minecraft:light[level=12]
setblock 97 133 339 minecraft:light[level=12]
setblock 97 133 346 minecraft:light[level=12]
setblock 97 133 353 minecraft:light[level=12]
setblock 97 133 360 minecraft:light[level=12]
fill 97 133 362 99 133 362 minecraft:stone
setblock 98 133 324 minecraft:stripped_spruce_log
setblock 99 133 323 minecraft:stripped_spruce_log
fill 99 133 324 102 133 324 minecraft:stone
setblock 99 133 363 minecraft:stripped_spruce_log
fill 100 133 323 103 133 323 minecraft:stone
setblock 100 133 362 minecraft:stripped_spruce_log
fill 100 133 363 103 133 363 minecraft:stone
fill 101 133 362 104 133 362 minecraft:stone
setblock 103 133 324 minecraft:stripped_spruce_log
setblock 104 133 323 minecraft:stripped_spruce_log
fill 104 133 324 104 136 324 minecraft:stone
setblock 104 133 325 minecraft:light[level=12]
setblock 104 133 332 minecraft:light[level=12]
setblock 104 133 339 minecraft:light[level=12]
setblock 104 133 346 minecraft:light[level=12]
setblock 104 133 353 minecraft:light[level=12]
setblock 104 133 360 minecraft:light[level=12]
setblock 104 133 363 minecraft:stripped_spruce_log
fill 105 133 323 105 136 323 minecraft:stone
fill 105 133 325 106 133 325 minecraft:stone
setblock 105 133 362 minecraft:stripped_spruce_log
fill 105 133 363 108 133 363 minecraft:stone
setblock 106 133 360 minecraft:stone
setblock 106 133 361 minecraft:stripped_spruce_log
fill 106 133 362 109 133 362 minecraft:stone
setblock 107 133 325 minecraft:stripped_spruce_log
setblock 107 133 360 minecraft:stripped_spruce_log
fill 107 133 361 107 136 361 minecraft:stone
fill 107 133 364 107 163 364 minecraft:deepslate
setblock 108 133 324 minecraft:stripped_spruce_log
fill 108 133 325 108 136 325 minecraft:stone
fill 108 133 360 108 134 360 minecraft:stone
setblock 109 133 323 minecraft:stripped_spruce_log
fill 109 133 324 109 136 324 minecraft:stone
setblock 109 133 363 minecraft:stripped_spruce_log
fill 110 133 323 110 136 323 minecraft:stone
setblock 110 133 362 minecraft:stripped_spruce_log
fill 110 133 363 110 136 363 minecraft:stone
setblock 111 133 325 minecraft:light[level=12]
setblock 111 133 332 minecraft:light[level=12]
setblock 111 133 339 minecraft:light[level=12]
setblock 111 133 346 minecraft:light[level=12]
setblock 111 133 353 minecraft:light[level=12]
setblock 111 133 361 minecraft:stripped_spruce_log
fill 111 133 362 111 136 362 minecraft:stone
setblock 112 133 360 minecraft:stripped_spruce_log
fill 112 133 361 112 135 361 minecraft:stone
setblock 113 133 324 minecraft:stripped_spruce_log
fill 113 133 325 115 134 325 minecraft:raw_gold_block
setblock 114 133 323 minecraft:stripped_spruce_log
setblock 114 133 324 minecraft:stone
fill 114 133 326 114 133 328 minecraft:raw_gold_block
setblock 114 133 363 minecraft:stripped_spruce_log
fill 115 133 323 115 135 323 minecraft:stone
fill 115 133 363 115 136 363 minecraft:stone
fill 116 133 362 116 134 362 minecraft:stone
setblock 117 133 323 minecraft:stone
setblock 118 133 325 minecraft:light[level=12]
setblock 118 133 332 minecraft:light[level=12]
setblock 118 133 346 minecraft:light[level=12]
setblock 118 133 353 minecraft:light[level=12]
setblock 118 133 360 minecraft:light[level=12]
setblock 119 133 363 minecraft:stripped_spruce_log
fill 120 133 363 123 133 363 minecraft:stone
setblock 122 133 364 minecraft:diamond_block
setblock 123 133 323 minecraft:stone
fill 123 133 362 124 133 362 minecraft:stone
setblock 124 133 323 minecraft:stripped_spruce_log
setblock 124 133 363 minecraft:stripped_spruce_log
fill 125 133 323 125 136 323 minecraft:stone
setblock 125 133 325 minecraft:light[level=12]
setblock 125 133 332 minecraft:light[level=12]
setblock 125 133 339 minecraft:light[level=12]
setblock 125 133 346 minecraft:light[level=12]
setblock 125 133 353 minecraft:light[level=12]
setblock 125 133 360 minecraft:light[level=12]
setblock 125 133 362 minecraft:stripped_spruce_log
fill 125 133 363 125 136 363 minecraft:stone
fill 126 133 322 126 184 322 minecraft:deepslate
fill 126 133 324 127 133 324 minecraft:stone
fill 126 133 362 126 135 362 minecraft:stone
setblock 128 133 324 minecraft:stripped_spruce_log
setblock 129 133 323 minecraft:stripped_spruce_log
fill 129 133 324 129 136 324 minecraft:stone
setblock 129 133 363 minecraft:stripped_spruce_log
fill 130 133 323 130 136 323 minecraft:stone
setblock 130 133 362 minecraft:stripped_spruce_log
fill 130 133 363 130 136 363 minecraft:stone
setblock 131 133 325 minecraft:stone
setblock 131 133 341 minecraft:stripped_spruce_log
setblock 131 133 342 minecraft:stone
fill 131 133 343 131 145 343 minecraft:stripped_spruce_log
fill 131 133 362 131 134 362 minecraft:stone
setblock 132 133 325 minecraft:light[level=12]
fill 132 133 327 132 143 327 minecraft:cobbled_deepslate
setblock 132 133 332 minecraft:light[level=12]
setblock 132 133 340 minecraft:stripped_spruce_log
fill 132 133 341 132 134 341 minecraft:stone
setblock 132 133 344 minecraft:stone
setblock 132 133 345 minecraft:stripped_spruce_log
setblock 132 133 346 minecraft:light[level=12]
setblock 132 133 353 minecraft:light[level=12]
setblock 132 133 360 minecraft:light[level=12]
setblock 133 133 324 minecraft:stripped_spruce_log
setblock 133 133 339 minecraft:stripped_spruce_log
fill 133 133 340 133 135 340 minecraft:stone
setblock 133 133 344 minecraft:stripped_spruce_log
fill 133 133 345 133 135 345 minecraft:stone
setblock 134 133 323 minecraft:stripped_spruce_log
setblock 134 133 327 minecraft:stone
setblock 134 133 328 minecraft:stripped_spruce_log
setblock 134 133 333 minecraft:stripped_spruce_log
setblock 134 133 334 minecraft:stone
setblock 134 133 338 minecraft:stripped_spruce_log
fill 134 133 339 134 135 339 minecraft:stone
fill 134 133 344 134 136 344 minecraft:stone
setblock 134 133 348 minecraft:stripped_spruce_log
setblock 134 133 363 minecraft:stripped_spruce_log
fill 135 133 323 135 136 323 minecraft:stone
setblock 135 133 327 minecraft:stripped_spruce_log
fill 135 133 328 135 136 328 minecraft:stone
setblock 135 133 332 minecraft:stripped_spruce_log
fill 135 133 333 135 135 333 minecraft:stone
setblock 135 133 337 minecraft:stripped_spruce_log
fill 135 133 338 135 136 338 minecraft:stone
setblock 135 133 342 minecraft:stripped_spruce_log
fill 135 133 343 135 136 343 minecraft:stone
setblock 135 133 347 minecraft:stripped_spruce_log
fill 135 133 348 135 135 348 minecraft:stone
setblock 135 133 362 minecraft:stripped_spruce_log
fill 135 133 363 135 135 363 minecraft:stone
fill 95 134 323 95 134 325 minecraft:stone
setblock 95 134 326 minecraft:stripped_spruce_log
fill 95 134 327 95 134 330 minecraft:stone
setblock 95 134 331 minecraft:stripped_spruce_log
setblock 95 134 336 minecraft:stripped_spruce_log
setblock 95 134 337 minecraft:stone
setblock 95 134 341 minecraft:stripped_spruce_log
fill 95 134 342 95 135 342 minecraft:stone
setblock 95 134 361 minecraft:stripped_spruce_log
fill 95 134 362 95 136 363 minecraft:stone
fill 96 134 323 97 134 323 minecraft:stone
setblock 96 134 325 minecraft:stripped_spruce_log
fill 96 134 326 96 135 326 minecraft:stone
fill 96 134 363 97 134 363 minecraft:stone
setblock 97 134 324 minecraft:stripped_spruce_log
setblock 98 134 323 minecraft:stripped_spruce_log
fill 98 134 324 101 134 324 minecraft:stone
setblock 98 134 363 minecraft:stripped_spruce_log
fill 99 134 323 102 134 323 minecraft:stone
setblock 99 134 362 minecraft:stripped_spruce_log
fill 99 134 363 102 134 363 minecraft:stone
fill 100 134 362 103 134 362 minecraft:stone
setblock 102 134 324 minecraft:stripped_spruce_log
setblock 103 134 323 minecraft:stripped_spruce_log
fill 103 134 324 103 137 324 minecraft:stone
setblock 103 134 363 minecraft:stripped_spruce_log
fill 104 134 323 104 137 323 minecraft:stone
setblock 104 134 362 minecraft:stripped_spruce_log
fill 104 134 363 107 134 363 minecraft:stone
setblock 105 134 325 minecraft:stone
setblock 105 134 361 minecraft:stripped_spruce_log
fill 105 134 362 108 134 362 minecraft:stone
setblock 106 134 325 minecraft:stripped_spruce_log
fill 106 134 361 106 137 361 minecraft:stone
setblock 107 134 324 minecraft:stripped_spruce_log
fill 107 134 325 107 137 325 minecraft:stone
setblock 107 134 360 minecraft:stone
setblock 108 134 323 minecraft:stripped_spruce_log
fill 108 134 324 108 137 324 minecraft:stone
setblock 108 134 363 minecraft:stripped_spruce_log
fill 109 134 323 109 137 323 minecraft:stone
setblock 109 134 362 minecraft:stripped_spruce_log
fill 109 134 363 109 137 363 minecraft:stone
setblock 110 134 361 minecraft:stripped_spruce_log
fill 110 134 362 110 137 362 minecraft:stone
fill 111 134 361 111 135 361 minecraft:stone
setblock 112 134 324 minecraft:stripped_spruce_log
setblock 113 134 323 minecraft:stripped_spruce_log
setblock 113 134 324 minecraft:stone
setblock 113 134 363 minecraft:stripped_spruce_log
fill 114 134 323 114 136 323 minecraft:stone
fill 114 134 324 114 135 324 minecraft:raw_gold_block
fill 114 134 326 114 134 327 minecraft:raw_gold_block
setblock 114 134 362 minecraft:stripped_spruce_log
fill 114 134 363 114 137 363 minecraft:stone
setblock 118 134 363 minecraft:stripped_spruce_log
fill 119 134 363 122 134 363 minecraft:stone
setblock 122 134 323 minecraft:stone
fill 122 134 364 122 182 364 minecraft:deepslate
setblock 123 134 323 minecraft:stripped_spruce_log
setblock 123 134 363 minecraft:stripped_spruce_log
fill 124 134 323 124 137 323 minecraft:stone
fill 124 134 363 124 137 363 minecraft:stone
setblock 125 134 362 minecraft:stone
setblock 126 134 324 minecraft:stone
setblock 127 134 324 minecraft:stripped_spruce_log
setblock 128 134 323 minecraft:stripped_spruce_log
fill 128 134 324 128 137 324 minecraft:stone
fill 128 134 360 130 135 361 minecraft:raw_gold_block
setblock 128 134 363 minecraft:stripped_spruce_log
fill 129 134 323 129 137 323 minecraft:stone
fill 129 134 358 129 135 359 minecraft:raw_gold_block
setblock 129 134 362 minecraft:stripped_spruce_log
fill 129 134 363 129 137 363 minecraft:stone
setblock 130 134 325 minecraft:stone
fill 130 134 362 130 135 362 minecraft:stone
setblock 131 134 325 minecraft:stripped_spruce_log
fill 131 134 342 131 145 342 minecraft:stripped_spruce_log
setblock 132 134 324 minecraft:stripped_spruce_log
setblock 132 134 340 minecraft:stone
setblock 132 134 344 minecraft:stripped_spruce_log
setblock 133 134 323 minecraft:stripped_spruce_log
fill 133 134 324 133 137 324 minecraft:stone
setblock 133 134 338 minecraft:stripped_spruce_log
setblock 133 134 339 minecraft:stone
setblock 133 134 343 minecraft:stripped_spruce_log
fill 133 134 344 133 135 344 minecraft:stone
setblock 133 134 363 minecraft:stripped_spruce_log
fill 134 134 323 134 137 323 minecraft:stone
setblock 134 134 327 minecraft:stripped_spruce_log
setblock 134 134 328 minecraft:stone
setblock 134 134 337 minecraft:stripped_spruce_log
fill 134 134 338 134 135 338 minecraft:stone
setblock 134 134 342 minecraft:stripped_spruce_log
setblock 134 134 347 minecraft:stripped_spruce_log
fill 134 134 363 134 135 363 minecraft:stone
setblock 135 134 326 minecraft:stripped_spruce_log
fill 135 134 327 135 137 327 minecraft:stone
setblock 135 134 331 minecraft:stripped_spruce_log
fill 135 134 332 135 135 332 minecraft:stone
setblock 135 134 336 minecraft:stripped_spruce_log
fill 135 134 337 135 135 337 minecraft:stone
setblock 135 134 341 minecraft:stripped_spruce_log
fill 135 134 342 135 137 342 minecraft:stone
setblock 135 134 346 minecraft:stripped_spruce_log
fill 135 134 347 135 136 347 minecraft:stone
setblock 135 134 362 minecraft:stone
setblock 136 134 336 minecraft:raw_iron_block
setblock 95 135 322 minecraft:gold_block
fill 95 135 323 95 135 324 minecraft:stone
setblock 95 135 325 minecraft:stripped_spruce_log
fill 95 135 326 95 135 329 minecraft:stone
setblock 95 135 341 minecraft:stone
setblock 95 135 361 minecraft:stone
fill 96 135 322 100 135 322 minecraft:deepslate
setblock 96 135 323 minecraft:stone
fill 96 135 325 96 137 325 minecraft:stone
setblock 96 135 363 minecraft:stone
setblock 97 135 323 minecraft:stripped_spruce_log
fill 97 135 324 100 135 324 minecraft:stone
setblock 97 135 363 minecraft:stripped_spruce_log
fill 98 135 323 101 135 323 minecraft:stone
fill 98 135 363 101 135 363 minecraft:stone
fill 100 135 362 102 135 362 minecraft:stone
setblock 101 135 324 minecraft:stripped_spruce_log
setblock 102 135 323 minecraft:stripped_spruce_log
fill 102 135 324 102 137 324 minecraft:stone
setblock 102 135 363 minecraft:stripped_spruce_log
fill 103 135 322 103 165 322 minecraft:deepslate
fill 103 135 323 103 137 323 minecraft:stone
setblock 103 135 362 minecraft:stripped_spruce_log
fill 103 135 363 106 135 363 minecraft:stone
setblock 104 135 322 minecraft:gold_block
setblock 104 135 325 minecraft:stone
setblock 104 135 361 minecraft:stripped_spruce_log
fill 104 135 362 107 135 362 minecraft:stone
fill 105 135 322 105 186 322 minecraft:deepslate
setblock 105 135 325 minecraft:stripped_spruce_log
fill 105 135 361 105 137 361 minecraft:stone
setblock 106 135 324 minecraft:stripped_spruce_log
fill 106 135 325 106 138 325 minecraft:stone
setblock 107 135 323 minecraft:stripped_spruce_log
fill 107 135 324 107 137 324 minecraft:stone
setblock 107 135 363 minecraft:stripped_spruce_log
fill 108 135 323 108 137 323 minecraft:stone
setblock 108 135 362 minecraft:stripped_spruce_log
fill 108 135 363 108 137 363 minecraft:stone
setblock 109 135 361 minecraft:stripped_spruce_log
fill 109 135 362 109 137 362 minecraft:stone
fill 110 135 361 110 136 361 minecraft:stone
setblock 111 135 324 minecraft:stripped_spruce_log
setblock 112 135 323 minecraft:stripped_spruce_log
setblock 112 135 324 minecraft:stone
setblock 112 135 363 minecraft:stripped_spruce_log
fill 113 135 323 113 137 323 minecraft:stone
setblock 113 135 324 minecraft:raw_gold_block
setblock 113 135 362 minecraft:stripped_spruce_log
fill 113 135 363 113 137 363 minecraft:stone
setblock 114 135 325 minecraft:raw_gold_block
setblock 114 135 362 minecraft:stone
setblock 117 135 363 minecraft:stripped_spruce_log
fill 118 135 363 121 135 363 minecraft:stone
setblock 122 135 323 minecraft:stripped_spruce_log
setblock 122 135 363 minecraft:stripped_spruce_log
fill 123 135 323 123 137 323 minecraft:stone
fill 123 135 363 123 137 363 minecraft:stone
setblock 125 135 324 minecraft:stone
setblock 126 135 324 minecraft:stripped_spruce_log
setblock 127 135 323 minecraft:stripped_spruce_log
fill 127 135 324 127 137 324 minecraft:stone
setblock 127 135 363 minecraft:stripped_spruce_log
fill 127 135 364 128 157 364 minecraft:deepslate
fill 128 135 323 128 137 323 minecraft:stone
setblock 128 135 362 minecraft:stripped_spruce_log
fill 128 135 363 128 137 363 minecraft:stone
setblock 129 135 325 minecraft:stone
setblock 129 135 357 minecraft:raw_gold_block
setblock 129 135 362 minecraft:stone
setblock 129 135 364 minecraft:raw_iron_block
setblock 130 135 325 minecraft:stripped_spruce_log
fill 130 135 364 130 186 364 minecraft:deepslate
setblock 131 135 324 minecraft:stripped_spruce_log
setblock 132 135 323 minecraft:stripped_spruce_log
fill 132 135 324 132 137 324 minecraft:stone
setblock 132 135 363 minecraft:stripped_spruce_log
fill 133 135 323 133 137 323 minecraft:stone
setblock 133 135 342 minecraft:stripped_spruce_log
setblock 133 135 343 minecraft:stone
fill 133 135 363 133 136 363 minecraft:stone
setblock 134 135 326 minecraft:stripped_spruce_log
fill 134 135 327 134 136 327 minecraft:stone
setblock 134 135 341 minecraft:stripped_spruce_log
fill 134 135 342 134 136 342 minecraft:stone
setblock 134 135 346 minecraft:stripped_spruce_log
setblock 135 135 325 minecraft:stripped_spruce_log
fill 135 135 326 135 137 326 minecraft:stone
setblock 135 135 330 minecraft:stripped_spruce_log
setblock 135 135 331 minecraft:stone
setblock 135 135 335 minecraft:stripped_spruce_log
setblock 135 135 336 minecraft:stone
setblock 135 135 340 minecraft:stripped_spruce_log
fill 135 135 341 135 137 341 minecraft:stone
setblock 135 135 345 minecraft:stripped_spruce_log
fill 135 135 346 135 137 346 minecraft:stone
fill 136 135 336 136 186 336 minecraft:deepslate
fill 95 136 322 97 150 322 minecraft:deepslate
setblock 95 136 323 minecraft:stone
setblock 95 136 324 minecraft:stripped_spruce_log
fill 95 136 325 95 136 328 minecraft:stone
setblock 95 136 329 minecraft:stripped_spruce_log
setblock 96 136 323 minecraft:stripped_spruce_log
setblock 96 136 324 minecraft:glowstone
setblock 96 136 343 minecraft:glowstone
setblock 96 136 362 minecraft:glowstone
setblock 96 136 363 minecraft:stripped_spruce_log
fill 97 136 323 99 136 324 minecraft:stone
fill 97 136 363 100 136 363 minecraft:stone
setblock 98 136 322 minecraft:raw_iron_block
setblock 99 136 322 minecraft:diamond_block
fill 100 136 322 100 144 322 minecraft:deepslate
setblock 100 136 323 minecraft:stone
setblock 100 136 324 minecraft:stripped_spruce_log
fill 100 136 364 104 140 364 minecraft:deepslate
setblock 101 136 323 minecraft:stripped_spruce_log
fill 101 136 324 101 137 324 minecraft:stone
setblock 101 136 362 minecraft:stone
setblock 101 136 363 minecraft:stripped_spruce_log
fill 102 136 323 102 137 323 minecraft:stone
setblock 102 136 362 minecraft:stripped_spruce_log
fill 102 136 363 105 136 363 minecraft:stone
fill 103 136 362 106 136 362 minecraft:stone
fill 104 136 322 104 158 322 minecraft:deepslate
setblock 104 136 325 minecraft:stripped_spruce_log
setblock 105 136 324 minecraft:stripped_spruce_log
fill 105 136 325 105 139 325 minecraft:stone
setblock 105 136 364 minecraft:raw_gold_block
setblock 106 136 323 minecraft:stripped_spruce_log
fill 106 136 324 106 137 324 minecraft:stone
setblock 106 136 363 minecraft:stripped_spruce_log
fill 106 136 364 106 146 364 minecraft:deepslate
fill 107 136 323 107 137 323 minecraft:stone
setblock 107 136 362 minecraft:stripped_spruce_log
fill 107 136 363 107 137 363 minecraft:stone
setblock 108 136 361 minecraft:stripped_spruce_log
fill 108 136 362 108 137 362 minecraft:stone
fill 109 136 360 109 143 360 minecraft:cobbled_deepslate
setblock 109 136 361 minecraft:stone
setblock 110 136 324 minecraft:stripped_spruce_log
setblock 111 136 323 minecraft:stripped_spruce_log
fill 111 136 324 111 137 324 minecraft:stone
setblock 111 136 363 minecraft:stripped_spruce_log
fill 112 136 323 112 137 323 minecraft:stone
setblock 112 136 362 minecraft:stripped_spruce_log
fill 112 136 363 112 137 363 minecraft:stone
setblock 113 136 362 minecraft:stone
setblock 115 136 324 minecraft:glowstone
setblock 115 136 362 minecraft:glowstone
setblock 116 136 363 minecraft:stripped_spruce_log
fill 122 136 323 122 137 323 minecraft:stone
setblock 122 136 363 minecraft:stone
setblock 125 136 324 minecraft:stripped_spruce_log
setblock 126 136 323 minecraft:stripped_spruce_log
fill 126 136 324 126 137 324 minecraft:stone
setblock 126 136 363 minecraft:stripped_spruce_log
fill 127 136 323 127 137 323 minecraft:stone
fill 127 136 363 127 137 363 minecraft:stone
fill 129 136 361 129 136 362 minecraft:raw_gold_block
fill 129 136 364 129 186 364 minecraft:deepslate
setblock 130 136 324 minecraft:stripped_spruce_log
fill 130 136 360 130 144 360 minecraft:iron_bars
setblock 131 136 323 minecraft:stripped_spruce_log
fill 131 136 324 131 137 324 minecraft:stone
setblock 131 136 363 minecraft:stripped_spruce_log
fill 132 136 323 132 137 323 minecraft:stone
setblock 132 136 363 minecraft:stone
setblock 134 136 324 minecraft:glowstone
setblock 134 136 325 minecraft:stripped_spruce_log
fill 134 136 326 134 137 326 minecraft:stone
setblock 134 136 341 minecraft:stone
setblock 134 136 343 minecraft:glowstone
setblock 134 136 345 minecraft:stripped_spruce_log
setblock 134 136 362 minecraft:glowstone
setblock 135 136 324 minecraft:stripped_spruce_log
fill 135 136 325 135 137 325 minecraft:stone
setblock 135 136 329 minecraft:stripped_spruce_log
fill 135 136 330 135 137 330 minecraft:stone
setblock 135 136 339 minecraft:stripped_spruce_log
setblock 135 136 340 minecraft:stone
setblock 135 136 344 minecraft:stripped_spruce_log
fill 135 136 345 135 137 345 minecraft:stone
setblock 95 137 323 minecraft:stripped_spruce_log
fill 95 137 324 95 137 327 minecraft:stone
setblock 95 137 328 minecraft:stripped_spruce_log
setblock 95 137 329 minecraft:stone
setblock 95 137 363 minecraft:stripped_spruce_log
fill 96 137 323 99 137 323 minecraft:stone
fill 96 137 324 96 138 324 minecraft:spruce_log
fill 96 137 343 96 138 343 minecraft:spruce_log
fill 96 137 362 96 138 362 minecraft:spruce_log
fill 96 137 363 99 137 363 minecraft:stone
fill 97 137 324 98 137 324 minecraft:stone
fill 98 137 322 99 186 322 minecraft:deepslate
setblock 99 137 324 minecraft:stripped_spruce_log
setblock 100 137 323 minecraft:stripped_spruce_log
setblock 100 137 324 minecraft:stone
setblock 100 137 363 minecraft:stripped_spruce_log
setblock 101 137 323 minecraft:stone
fill 101 137 363 104 137 363 minecraft:stone
fill 102 137 362 105 137 362 minecraft:stone
setblock 104 137 324 minecraft:stripped_spruce_log
fill 104 137 325 104 140 325 minecraft:stone
setblock 105 137 323 minecraft:stripped_spruce_log
setblock 105 137 324 minecraft:stone
setblock 105 137 363 minecraft:stripped_spruce_log
fill 105 137 364 105 183 364 minecraft:deepslate
setblock 106 137 323 minecraft:stone
setblock 106 137 362 minecraft:stripped_spruce_log
setblock 106 137 363 minecraft:stone
setblock 107 137 361 minecraft:stripped_spruce_log
setblock 107 137 362 minecraft:stone
setblock 108 137 361 minecraft:stone
setblock 109 137 324 minecraft:stripped_spruce_log
setblock 110 137 323 minecraft:stripped_spruce_log
setblock 110 137 324 minecraft:stone
setblock 110 137 363 minecraft:stripped_spruce_log
setblock 111 137 323 minecraft:stone
setblock 111 137 362 minecraft:stripped_spruce_log
setblock 111 137 363 minecraft:stone
setblock 112 137 362 minecraft:stone
fill 115 137 324 115 138 324 minecraft:spruce_log
fill 115 137 362 115 138 362 minecraft:spruce_log
setblock 125 137 323 minecraft:stripped_spruce_log
setblock 125 137 324 minecraft:stone
setblock 125 137 363 minecraft:stripped_spruce_log
setblock 126 137 323 minecraft:stone
setblock 126 137 363 minecraft:stone
setblock 129 137 324 minecraft:stripped_spruce_log
setblock 130 137 323 minecraft:stripped_spruce_log
setblock 130 137 324 minecraft:stone
setblock 130 137 363 minecraft:stripped_spruce_log
setblock 131 137 323 minecraft:stone
setblock 131 137 363 minecraft:stone
setblock 132 137 364 minecraft:raw_iron_block
fill 134 137 324 134 138 324 minecraft:spruce_log
setblock 134 137 325 minecraft:stone
fill 134 137 343 134 138 343 minecraft:spruce_log
fill 134 137 362 134 138 362 minecraft:spruce_log
setblock 135 137 323 minecraft:stripped_spruce_log
setblock 135 137 324 minecraft:stone
setblock 135 137 328 minecraft:stripped_spruce_log
setblock 135 137 329 minecraft:stone
setblock 135 137 343 minecraft:stripped_spruce_log
setblock 135 137 344 minecraft:stone
setblock 94 138 344 minecraft:diamond_block
fill 95 138 323 95 138 363 minecraft:spruce_planks
fill 96 138 323 135 138 323 minecraft:spruce_planks
fill 96 138 325 96 138 342 minecraft:spruce_planks
fill 96 138 344 96 138 361 minecraft:spruce_planks
fill 96 138 363 135 138 363 minecraft:spruce_planks
fill 97 138 324 114 138 324 minecraft:spruce_planks
fill 97 138 362 114 138 362 minecraft:spruce_planks
fill 116 138 324 133 138 324 minecraft:spruce_planks
fill 116 138 362 133 138 362 minecraft:spruce_planks
setblock 123 138 364 minecraft:gold_block
fill 124 138 364 125 143 364 minecraft:deepslate
fill 132 138 337 133 139 337 minecraft:iron_bars
fill 132 138 364 132 176 364 minecraft:deepslate
fill 134 138 325 135 138 342 minecraft:spruce_planks
fill 134 138 344 135 138 361 minecraft:spruce_planks
setblock 135 138 324 minecraft:spruce_planks
setblock 135 138 343 minecraft:spruce_planks
setblock 135 138 362 minecraft:spruce_planks
fill 136 138 327 136 146 329 minecraft:deepslate
setblock 136 138 330 minecraft:gold_block
setblock 136 138 349 minecraft:diamond_block
fill 136 138 362 136 163 362 minecraft:deepslate
setblock 136 138 363 minecraft:gold_block
fill 94 139 344 94 154 344 minecraft:deepslate
fill 95 139 323 95 139 325 minecraft:stone
setblock 95 139 326 minecraft:stripped_spruce_log
fill 95 139 327 95 140 329 minecraft:stone
fill 96 139 323 96 139 324 minecraft:stone
setblock 96 139 325 minecraft:stripped_spruce_log
setblock 97 139 323 minecraft:stone
setblock 97 139 324 minecraft:stripped_spruce_log
setblock 97 139 325 minecraft:light[level=15]
setblock 97 139 332 minecraft:light[level=12]
setblock 97 139 333 minecraft:light[level=15]
setblock 97 139 339 minecraft:light[level=12]
setblock 97 139 341 minecraft:light[level=15]
setblock 97 139 346 minecraft:light[level=12]
setblock 97 139 349 minecraft:light[level=15]
setblock 97 139 353 minecraft:light[level=12]
setblock 97 139 357 minecraft:light[level=15]
setblock 97 139 360 minecraft:light[level=12]
setblock 98 139 323 minecraft:stripped_spruce_log
fill 98 139 324 101 139 324 minecraft:stone
setblock 98 139 363 minecraft:stripped_spruce_log
fill 99 139 323 102 139 323 minecraft:stone
fill 99 139 363 102 139 363 minecraft:stone
setblock 102 139 324 minecraft:stripped_spruce_log
fill 102 139 362 103 139 362 minecraft:stone
setblock 103 139 323 minecraft:stripped_spruce_log
fill 103 139 324 103 141 325 minecraft:stone
setblock 103 139 363 minecraft:stripped_spruce_log
fill 104 139 323 106 139 324 minecraft:stone
setblock 104 139 332 minecraft:light[level=12]
setblock 104 139 339 minecraft:light[level=12]
setblock 104 139 346 minecraft:light[level=12]
setblock 104 139 353 minecraft:light[level=12]
setblock 104 139 360 minecraft:light[level=12]
setblock 104 139 362 minecraft:stripped_spruce_log
fill 104 139 363 107 139 363 minecraft:stone
setblock 105 139 333 minecraft:light[level=15]
setblock 105 139 341 minecraft:light[level=15]
setblock 105 139 349 minecraft:light[level=15]
setblock 105 139 357 minecraft:light[level=15]
fill 105 139 362 108 139 362 minecraft:stone
setblock 106 139 325 minecraft:stripped_spruce_log
setblock 107 139 323 minecraft:stone
setblock 107 139 324 minecraft:stripped_spruce_log
setblock 108 139 323 minecraft:stripped_spruce_log
fill 108 139 324 109 140 324 minecraft:stone
setblock 108 139 363 minecraft:stripped_spruce_log
fill 109 139 323 111 140 323 minecraft:stone
setblock 109 139 362 minecraft:stripped_spruce_log
fill 109 139 363 112 139 363 minecraft:stone
setblock 111 139 325 minecraft:light[level=12]
setblock 111 139 332 minecraft:light[level=12]
setblock 111 139 339 minecraft:light[level=12]
setblock 111 139 346 minecraft:light[level=12]
setblock 111 139 353 minecraft:light[level=12]
setblock 111 139 360 minecraft:light[level=12]
fill 112 139 322 112 186 322 minecraft:deepslate
setblock 113 139 322 minecraft:diamond_block
setblock 113 139 325 minecraft:light[level=15]
setblock 113 139 333 minecraft:light[level=15]
setblock 113 139 341 minecraft:light[level=15]
setblock 113 139 349 minecraft:light[level=15]
setblock 113 139 357 minecraft:light[level=15]
setblock 118 139 325 minecraft:light[level=12]
setblock 118 139 332 minecraft:light[level=12]
setblock 118 139 339 minecraft:light[level=12]
setblock 118 139 346 minecraft:light[level=12]
setblock 118 139 353 minecraft:light[level=12]
setblock 118 139 360 minecraft:light[level=12]
setblock 121 139 325 minecraft:light[level=15]
setblock 121 139 333 minecraft:light[level=15]
setblock 121 139 341 minecraft:light[level=15]
setblock 121 139 349 minecraft:light[level=15]
setblock 121 139 357 minecraft:light[level=15]
setblock 122 139 323 minecraft:stone
setblock 123 139 323 minecraft:stripped_spruce_log
fill 123 139 364 123 172 364 minecraft:deepslate
fill 124 139 323 126 139 324 minecraft:stone
setblock 125 139 325 minecraft:light[level=12]
setblock 125 139 332 minecraft:light[level=12]
setblock 125 139 339 minecraft:light[level=12]
setblock 125 139 346 minecraft:light[level=12]
setblock 125 139 353 minecraft:light[level=12]
setblock 125 139 360 minecraft:light[level=12]
fill 125 139 363 127 139 363 minecraft:stone
setblock 127 139 323 minecraft:stone
setblock 127 139 324 minecraft:stripped_spruce_log
fill 127 139 325 128 141 325 minecraft:stone
setblock 128 139 323 minecraft:stripped_spruce_log
fill 128 139 324 131 139 324 minecraft:stone
fill 129 139 323 132 139 323 minecraft:stone
setblock 129 139 325 minecraft:light[level=15]
setblock 129 139 341 minecraft:light[level=15]
setblock 129 139 349 minecraft:light[level=15]
setblock 129 139 357 minecraft:light[level=15]
fill 131 139 327 131 143 327 minecraft:cobbled_deepslate
setblock 132 139 324 minecraft:stripped_spruce_log
setblock 132 139 325 minecraft:light[level=12]
fill 132 139 326 132 141 326 minecraft:cobbled_deepslate
fill 132 139 328 132 143 328 minecraft:cobbled_deepslate
setblock 132 139 332 minecraft:light[level=12]
setblock 132 139 339 minecraft:light[level=12]
setblock 132 139 346 minecraft:light[level=12]
setblock 132 139 353 minecraft:light[level=12]
setblock 132 139 360 minecraft:light[level=12]
setblock 133 139 323 minecraft:stripped_spruce_log
setblock 133 139 324 minecraft:stone
fill 133 139 327 133 143 327 minecraft:cobbled_deepslate
fill 134 139 323 135 141 323 minecraft:stone
fill 134 139 325 134 139 326 minecraft:stone
setblock 134 139 327 minecraft:stripped_spruce_log
setblock 134 139 337 minecraft:iron_bars
fill 135 139 324 135 139 325 minecraft:stone
setblock 135 139 326 minecraft:stripped_spruce_log
fill 135 139 327 135 139 330 minecraft:stone
fill 136 139 330 136 184 330 minecraft:deepslate
fill 136 139 349 136 174 349 minecraft:deepslate
setblock 136 139 351 minecraft:diamond_block
fill 136 139 363 136 164 363 minecraft:deepslate
setblock 94 140 343 minecraft:raw_iron_block
fill 95 140 323 95 140 324 minecraft:stone
setblock 95 140 325 minecraft:stripped_spruce_log
fill 95 140 326 96 142 326 minecraft:stone
fill 95 140 355 100 141 355 minecraft:stripped_spruce_log
setblock 96 140 323 minecraft:stone
setblock 96 140 324 minecraft:stripped_spruce_log
fill 96 140 325 96 143 325 minecraft:stone
setblock 97 140 323 minecraft:stripped_spruce_log
fill 97 140 324 100 140 324 minecraft:stone
fill 98 140 323 101 140 323 minecraft:stone
fill 98 140 363 101 140 363 minecraft:stone
setblock 101 140 324 minecraft:stripped_spruce_log
fill 101 140 362 102 140 362 minecraft:stone
setblock 102 140 323 minecraft:stripped_spruce_log
fill 102 140 324 102 142 325 minecraft:stone
setblock 102 140 363 minecraft:stripped_spruce_log
fill 103 140 323 106 140 323 minecraft:stone
setblock 103 140 362 minecraft:stripped_spruce_log
fill 103 140 363 106 140 363 minecraft:stone
fill 104 140 324 105 140 324 minecraft:stone
fill 104 140 362 107 140 362 minecraft:stone
setblock 105 140 325 minecraft:stripped_spruce_log
setblock 106 140 324 minecraft:stripped_spruce_log
setblock 106 140 325 minecraft:stone
setblock 107 140 323 minecraft:stripped_spruce_log
fill 107 140 324 107 143 324 minecraft:stone
setblock 107 140 363 minecraft:stripped_spruce_log
fill 108 140 323 108 143 323 minecraft:stone
setblock 108 140 362 minecraft:stripped_spruce_log
fill 108 140 363 111 140 363 minecraft:stone
fill 113 140 322 113 186 322 minecraft:deepslate
setblock 117 140 364 minecraft:raw_iron_block
setblock 121 140 323 minecraft:stone
setblock 122 140 323 minecraft:stripped_spruce_log
fill 123 140 323 125 140 324 minecraft:stone
setblock 126 140 323 minecraft:stone
setblock 126 140 324 minecraft:stripped_spruce_log
fill 126 140 325 126 143 325 minecraft:stone
fill 126 140 333 127 141 333 minecraft:stripped_spruce_log
setblock 127 140 323 minecraft:stripped_spruce_log
fill 127 140 324 130 140 324 minecraft:stone
fill 128 140 323 131 140 323 minecraft:stone
fill 130 140 333 134 140 333 minecraft:stripped_spruce_log
setblock 131 140 324 minecraft:stripped_spruce_log
setblock 132 140 323 minecraft:stripped_spruce_log
fill 132 140 324 132 143 324 minecraft:stone
fill 133 140 323 133 143 323 minecraft:stone
setblock 134 140 325 minecraft:stone
setblock 134 140 326 minecraft:stripped_spruce_log
fill 134 140 327 135 141 328 minecraft:stone
setblock 135 140 324 minecraft:stone
setblock 135 140 325 minecraft:stripped_spruce_log
fill 135 140 326 135 143 326 minecraft:stone
setblock 135 140 329 minecraft:stone
setblock 135 140 330 minecraft:stripped_spruce_log
fill 135 140 331 135 143 331 minecraft:stone
setblock 136 140 332 minecraft:gold_block
fill 136 140 351 136 186 351 minecraft:deepslate
fill 94 141 343 94 151 343 minecraft:deepslate
fill 94 141 346 94 151 351 minecraft:deepslate
setblock 94 141 352 minecraft:raw_gold_block
fill 94 141 353 94 146 354 minecraft:deepslate
setblock 94 141 355 minecraft:diamond_block
fill 94 141 356 94 141 360 minecraft:deepslate
setblock 95 141 323 minecraft:stone
setblock 95 141 324 minecraft:stripped_spruce_log
fill 95 141 325 95 144 325 minecraft:stone
fill 95 141 327 95 141 328 minecraft:stone
setblock 95 141 329 minecraft:stripped_spruce_log
fill 95 141 330 95 144 330 minecraft:stone
fill 95 141 333 125 141 333 minecraft:stripped_spruce_log
fill 95 141 340 115 141 340 minecraft:stripped_spruce_log
fill 95 141 347 135 141 347 minecraft:stripped_spruce_log
fill 95 141 354 114 141 354 minecraft:stripped_spruce_log
setblock 95 141 356 minecraft:stripped_spruce_log
fill 95 141 361 99 141 361 minecraft:stripped_spruce_log
setblock 96 141 323 minecraft:stripped_spruce_log
fill 96 141 324 99 141 324 minecraft:stone
setblock 96 141 327 minecraft:stone
fill 97 141 323 100 141 323 minecraft:stone
fill 97 141 326 100 142 326 minecraft:stripped_spruce_log
fill 97 141 363 100 141 363 minecraft:stone
setblock 100 141 324 minecraft:stripped_spruce_log
setblock 100 141 364 minecraft:gold_block
setblock 101 141 323 minecraft:stripped_spruce_log
fill 101 141 324 101 143 325 minecraft:stone
fill 101 141 355 108 141 355 minecraft:stripped_spruce_log
setblock 101 141 362 minecraft:stone
setblock 101 141 363 minecraft:stripped_spruce_log
fill 101 141 364 104 143 364 minecraft:deepslate
fill 102 141 323 105 141 323 minecraft:stone
setblock 102 141 362 minecraft:stripped_spruce_log
fill 102 141 363 105 141 363 minecraft:stone
fill 103 141 362 106 141 362 minecraft:stone
setblock 104 141 324 minecraft:stone
setblock 104 141 325 minecraft:stripped_spruce_log
setblock 105 141 324 minecraft:stripped_spruce_log
fill 105 141 325 105 143 325 minecraft:stone
setblock 106 141 323 minecraft:stripped_spruce_log
fill 106 141 324 106 144 324 minecraft:stone
setblock 106 141 363 minecraft:stripped_spruce_log
fill 107 141 323 107 144 323 minecraft:stone
setblock 107 141 362 minecraft:stripped_spruce_log
fill 107 141 363 110 141 363 minecraft:stone
fill 108 141 324 108 142 324 minecraft:stone
fill 108 141 360 108 143 360 minecraft:cobbled_deepslate
setblock 108 141 362 minecraft:stone
fill 109 141 323 110 141 323 minecraft:stone
fill 109 141 359 109 143 359 minecraft:cobbled_deepslate
setblock 109 141 361 minecraft:cobbled_deepslate
fill 110 141 360 110 143 360 minecraft:cobbled_deepslate
setblock 116 141 322 minecraft:raw_iron_block
fill 117 141 322 118 163 322 minecraft:deepslate
fill 117 141 364 117 162 364 minecraft:deepslate
setblock 121 141 323 minecraft:stripped_spruce_log
setblock 122 141 322 minecraft:gold_block
fill 122 141 323 124 141 324 minecraft:stone
fill 122 141 340 135 141 340 minecraft:stripped_spruce_log
setblock 125 141 323 minecraft:stone
setblock 125 141 324 minecraft:stripped_spruce_log
fill 125 141 325 125 144 325 minecraft:stone
setblock 126 141 323 minecraft:stripped_spruce_log
fill 126 141 324 129 141 324 minecraft:stone
fill 127 141 323 130 141 323 minecraft:stone
setblock 129 141 325 minecraft:stripped_spruce_log
setblock 130 141 324 minecraft:stripped_spruce_log
fill 130 141 333 132 141 333 minecraft:stripped_spruce_log
setblock 131 141 323 minecraft:stripped_spruce_log
fill 131 141 324 131 144 324 minecraft:stone
fill 132 141 323 132 144 323 minecraft:stone
setblock 134 141 325 minecraft:stripped_spruce_log
fill 134 141 326 134 144 326 minecraft:stone
setblock 134 141 329 minecraft:stone
setblock 135 141 324 minecraft:stripped_spruce_log
fill 135 141 325 135 144 325 minecraft:stone
setblock 135 141 329 minecraft:stripped_spruce_log
fill 135 141 330 135 144 330 minecraft:stone
fill 135 141 332 135 142 332 minecraft:stone
fill 136 141 332 136 186 332 minecraft:deepslate
setblock 136 141 333 minecraft:gold_block
fill 94 142 352 94 182 352 minecraft:deepslate
setblock 94 142 355 minecraft:gold_block
fill 94 142 356 94 144 356 minecraft:deepslate
setblock 94 142 357 minecraft:gold_block
fill 94 142 358 94 153 360 minecraft:deepslate
setblock 95 142 323 minecraft:stripped_spruce_log
fill 95 142 324 98 142 324 minecraft:stone
setblock 95 142 327 minecraft:stone
setblock 95 142 328 minecraft:stripped_spruce_log
fill 95 142 329 95 145 329 minecraft:stone
fill 95 142 331 95 143 331 minecraft:stone
fill 95 142 333 97 142 333 minecraft:stripped_spruce_log
fill 95 142 340 100 142 340 minecraft:stripped_spruce_log
fill 95 142 347 109 142 347 minecraft:stripped_spruce_log
fill 95 142 354 97 142 354 minecraft:stripped_spruce_log
fill 95 142 355 97 142 355 minecraft:stripped_dark_oak_log
fill 95 142 361 97 142 361 minecraft:stripped_spruce_log
fill 96 142 323 99 142 323 minecraft:stone
setblock 96 142 327 minecraft:stripped_spruce_log
fill 96 142 328 96 145 328 minecraft:stone
fill 97 142 363 99 142 363 minecraft:stone
fill 98 142 350 98 142 362 minecraft:iron_bars
setblock 99 142 324 minecraft:stripped_spruce_log
fill 99 142 354 134 142 354 minecraft:stripped_spruce_log
fill 99 142 355 101 142 355 minecraft:stripped_dark_oak_log
fill 99 142 361 134 142 361 minecraft:stripped_spruce_log
setblock 100 142 323 minecraft:stripped_spruce_log
fill 100 142 324 100 144 325 minecraft:stone
setblock 100 142 362 minecraft:stone
setblock 100 142 363 minecraft:stripped_spruce_log
fill 100 142 364 100 155 364 minecraft:deepslate
fill 101 142 323 104 142 323 minecraft:stone
fill 101 142 326 133 142 326 minecraft:stripped_spruce_log
setblock 101 142 362 minecraft:stripped_spruce_log
fill 101 142 363 104 142 363 minecraft:stone
fill 102 142 362 105 142 362 minecraft:stone
setblock 103 142 324 minecraft:stone
setblock 103 142 325 minecraft:stripped_spruce_log
fill 103 142 328 103 142 330 minecraft:stripped_dark_oak_log
fill 103 142 355 110 142 355 minecraft:stripped_spruce_log
setblock 104 142 324 minecraft:stripped_spruce_log
fill 104 142 325 104 144 325 minecraft:stone
fill 104 142 327 104 143 328 minecraft:stripped_dark_oak_log
fill 104 142 330 104 142 331 minecraft:stripped_dark_oak_log
setblock 105 142 323 minecraft:stripped_spruce_log
fill 105 142 324 105 145 324 minecraft:stone
fill 105 142 327 106 142 327 minecraft:stripped_dark_oak_log
fill 105 142 331 106 142 331 minecraft:stripped_dark_oak_log
setblock 105 142 363 minecraft:stripped_spruce_log
fill 106 142 323 106 145 323 minecraft:stone
setblock 106 142 362 minecraft:stripped_spruce_log
fill 106 142 363 109 142 363 minecraft:stone
fill 107 142 328 107 143 330 minecraft:stripped_dark_oak_log
fill 107 142 362 107 144 362 minecraft:stone
setblock 109 142 323 minecraft:stone
setblock 110 142 323 minecraft:stripped_spruce_log
setblock 110 142 363 minecraft:stripped_spruce_log
fill 112 142 353 127 142 353 minecraft:stripped_spruce_log
fill 116 142 322 116 184 322 minecraft:deepslate
setblock 120 142 323 minecraft:stripped_spruce_log
fill 121 142 323 124 142 323 minecraft:stone
fill 122 142 322 122 165 322 minecraft:deepslate
fill 122 142 324 123 142 324 minecraft:stone
setblock 124 142 324 minecraft:stripped_spruce_log
fill 124 142 325 124 145 325 minecraft:stone
setblock 125 142 323 minecraft:stripped_spruce_log
fill 125 142 324 128 142 324 minecraft:stone
fill 125 142 331 126 142 332 minecraft:stripped_dark_oak_log
fill 126 142 323 129 142 323 minecraft:stone
fill 126 142 329 127 142 330 minecraft:stripped_dark_oak_log
fill 126 142 333 127 142 334 minecraft:stripped_dark_oak_log
setblock 127 142 325 minecraft:stone
fill 127 142 343 128 142 343 minecraft:stripped_dark_oak_log
setblock 128 142 325 minecraft:stripped_spruce_log
fill 128 142 328 129 142 329 minecraft:stripped_dark_oak_log
fill 128 142 334 130 142 334 minecraft:stripped_dark_oak_log
fill 128 142 341 128 142 342 minecraft:stripped_dark_oak_log
fill 128 142 344 129 142 345 minecraft:stripped_dark_oak_log
setblock 129 142 324 minecraft:stripped_spruce_log
fill 129 142 325 129 143 325 minecraft:stone
fill 129 142 340 129 142 341 minecraft:stripped_dark_oak_log
setblock 130 142 322 minecraft:diamond_block
setblock 130 142 323 minecraft:stripped_spruce_log
fill 130 142 324 130 145 324 minecraft:stone
fill 130 142 329 131 142 330 minecraft:stripped_dark_oak_log
fill 130 142 333 131 142 333 minecraft:stripped_dark_oak_log
fill 130 142 340 132 142 340 minecraft:stripped_dark_oak_log
fill 130 142 345 132 142 345 minecraft:stripped_dark_oak_log
fill 131 142 323 131 145 323 minecraft:stone
fill 131 142 328 131 143 328 minecraft:cobbled_deepslate
fill 131 142 331 131 143 332 minecraft:stripped_dark_oak_log
fill 131 142 341 132 143 341 minecraft:stripped_dark_oak_log
fill 132 142 342 133 142 344 minecraft:stripped_dark_oak_log
setblock 133 142 324 minecraft:stone
fill 133 142 328 133 143 328 minecraft:cobbled_deepslate
setblock 134 142 323 minecraft:stone
setblock 134 142 324 minecraft:stripped_spruce_log
fill 134 142 325 134 145 325 minecraft:stone
fill 134 142 327 134 142 328 minecraft:stone
setblock 134 142 329 minecraft:stripped_spruce_log
fill 134 142 330 134 144 331 minecraft:stone
setblock 135 142 323 minecraft:stripped_spruce_log
fill 135 142 324 135 145 324 minecraft:stone
setblock 135 142 327 minecraft:stone
setblock 135 142 328 minecraft:stripped_spruce_log
fill 135 142 329 135 145 329 minecraft:stone
setblock 135 142 333 minecraft:stripped_spruce_log
fill 136 142 333 136 154 333 minecraft:deepslate
setblock 136 142 355 minecraft:raw_iron_block
fill 136 142 356 136 183 357 minecraft:deepslate
fill 94 143 355 94 186 355 minecraft:deepslate
fill 94 143 357 94 170 357 minecraft:deepslate
fill 95 143 323 97 143 324 minecraft:stone
setblock 95 143 326 minecraft:stone
setblock 95 143 327 minecraft:stripped_spruce_log
fill 95 143 328 95 145 328 minecraft:stone
setblock 95 143 332 minecraft:stripped_spruce_log
fill 95 143 349 95 143 351 minecraft:stone
setblock 95 143 352 minecraft:stripped_spruce_log
fill 95 143 353 95 145 353 minecraft:stone
setblock 96 143 326 minecraft:stripped_spruce_log
fill 96 143 327 96 145 327 minecraft:stone
fill 96 143 329 96 143 330 minecraft:stone
fill 96 143 363 98 143 363 minecraft:stone
setblock 98 143 323 minecraft:stone
setblock 98 143 324 minecraft:stripped_spruce_log
fill 98 143 325 98 143 355 minecraft:iron_bars
setblock 99 143 323 minecraft:stripped_spruce_log
fill 99 143 324 99 145 325 minecraft:stone
setblock 99 143 362 minecraft:stone
setblock 99 143 363 minecraft:stripped_spruce_log
fill 100 143 323 103 143 323 minecraft:stone
setblock 100 143 362 minecraft:stripped_spruce_log
fill 100 143 363 103 143 363 minecraft:stone
fill 101 143 362 104 143 362 minecraft:stone
setblock 102 143 324 minecraft:stone
setblock 102 143 325 minecraft:stripped_spruce_log
setblock 103 143 324 minecraft:stripped_spruce_log
fill 103 143 325 103 145 325 minecraft:stone
setblock 103 143 329 minecraft:stripped_dark_oak_log
setblock 104 143 323 minecraft:stripped_spruce_log
fill 104 143 324 104 145 324 minecraft:stone
fill 104 143 329 104 145 329 minecraft:stripped_spruce_log
fill 104 143 330 104 144 330 minecraft:stripped_dark_oak_log
setblock 104 143 363 minecraft:stripped_spruce_log
fill 105 143 323 105 145 323 minecraft:stone
fill 105 143 326 105 143 361 minecraft:iron_bars
setblock 105 143 362 minecraft:stripped_spruce_log
fill 105 143 363 108 143 363 minecraft:stone
setblock 106 143 327 minecraft:stripped_dark_oak_log
fill 106 143 328 106 145 330 minecraft:stripped_spruce_log
setblock 106 143 331 minecraft:stripped_dark_oak_log
fill 106 143 354 111 143 354 minecraft:stripped_dark_oak_log
fill 106 143 362 106 145 362 minecraft:stone
setblock 108 143 359 minecraft:cobbled_deepslate
fill 108 143 361 110 143 361 minecraft:cobbled_deepslate
setblock 109 143 323 minecraft:stripped_spruce_log
setblock 109 143 363 minecraft:stripped_spruce_log
setblock 110 143 359 minecraft:cobbled_deepslate
fill 112 143 323 112 143 363 minecraft:iron_bars
fill 113 143 354 114 143 354 minecraft:stripped_dark_oak_log
fill 115 143 354 118 143 354 minecraft:stripped_spruce_log
setblock 118 143 353 minecraft:stripped_spruce_log
setblock 119 143 323 minecraft:stripped_spruce_log
fill 119 143 324 119 143 333 minecraft:iron_bars
fill 119 143 341 119 143 363 minecraft:iron_bars
fill 120 143 323 123 143 323 minecraft:stone
fill 120 143 353 125 143 354 minecraft:stripped_spruce_log
fill 121 143 324 122 143 324 minecraft:stone
setblock 123 143 324 minecraft:stripped_spruce_log
fill 123 143 325 123 145 325 minecraft:stone
setblock 124 143 323 minecraft:stripped_spruce_log
fill 124 143 324 127 143 324 minecraft:stone
setblock 124 143 363 minecraft:stripped_spruce_log
fill 125 143 323 128 143 323 minecraft:stone
fill 126 143 326 126 144 327 minecraft:iron_bars
fill 126 143 330 126 143 333 minecraft:stripped_dark_oak_log
fill 126 143 352 135 143 353 minecraft:stripped_spruce_log
setblock 127 143 325 minecraft:stripped_spruce_log
fill 127 143 329 127 143 330 minecraft:stripped_dark_oak_log
fill 127 143 333 127 143 334 minecraft:stripped_dark_oak_log
setblock 128 143 324 minecraft:stripped_spruce_log
fill 128 143 325 128 144 325 minecraft:stone
fill 128 143 329 130 143 329 minecraft:stripped_dark_oak_log
fill 128 143 334 129 143 334 minecraft:stripped_dark_oak_log
fill 128 143 342 128 143 344 minecraft:stripped_dark_oak_log
fill 128 143 354 134 143 354 minecraft:stripped_spruce_log
setblock 129 143 323 minecraft:stripped_spruce_log
fill 129 143 324 129 145 324 minecraft:stone
fill 129 143 341 129 144 341 minecraft:stripped_dark_oak_log
fill 129 143 344 129 143 345 minecraft:stripped_dark_oak_log
fill 130 143 322 130 152 322 minecraft:deepslate
fill 130 143 323 130 145 323 minecraft:stone
fill 130 143 330 131 143 330 minecraft:stripped_dark_oak_log
fill 130 143 333 130 144 333 minecraft:stripped_dark_oak_log
setblock 130 143 340 minecraft:stripped_dark_oak_log
fill 130 143 345 131 143 345 minecraft:stripped_dark_oak_log
fill 131 143 326 133 143 326 minecraft:cobbled_deepslate
fill 132 143 342 132 143 344 minecraft:stripped_dark_oak_log
setblock 133 143 324 minecraft:stripped_spruce_log
fill 133 143 325 133 144 325 minecraft:iron_bars
setblock 134 143 323 minecraft:stripped_spruce_log
fill 134 143 324 134 145 324 minecraft:stone
setblock 134 143 327 minecraft:stone
setblock 134 143 328 minecraft:stripped_spruce_log
fill 134 143 329 134 145 329 minecraft:stone
setblock 134 143 332 minecraft:stone
fill 135 143 323 135 145 323 minecraft:stone
setblock 135 143 327 minecraft:stripped_spruce_log
fill 135 143 328 135 145 328 minecraft:stone
setblock 135 143 332 minecraft:stripped_spruce_log
fill 135 143 333 135 145 334 minecraft:stone
fill 136 143 355 136 148 355 minecraft:deepslate
setblock 94 144 327 minecraft:gold_block
fill 94 144 328 94 145 331 minecraft:deepslate
setblock 94 144 335 minecraft:raw_iron_block
fill 95 144 323 96 144 324 minecraft:stone
setblock 95 144 326 minecraft:stripped_spruce_log
fill 95 144 327 95 145 327 minecraft:stone
setblock 95 144 331 minecraft:stripped_spruce_log
fill 95 144 332 95 145 333 minecraft:stone
fill 95 144 348 95 144 350 minecraft:stone
setblock 95 144 351 minecraft:stripped_spruce_log
fill 95 144 352 96 145 352 minecraft:stone
fill 95 144 354 95 144 355 minecraft:stone
setblock 95 144 356 minecraft:stripped_spruce_log
fill 95 144 363 97 144 363 minecraft:stone
setblock 96 144 325 minecraft:stripped_spruce_log
fill 96 144 326 96 145 326 minecraft:stone
setblock 96 144 329 minecraft:stone
setblock 96 144 330 minecraft:stripped_spruce_log
fill 96 144 331 96 145 331 minecraft:stone
setblock 97 144 323 minecraft:stone
setblock 97 144 324 minecraft:stripped_spruce_log
setblock 98 144 323 minecraft:stripped_spruce_log
fill 98 144 324 98 145 324 minecraft:stone
setblock 98 144 325 minecraft:iron_bars
setblock 98 144 363 minecraft:stripped_spruce_log
fill 99 144 323 102 144 323 minecraft:stone
setblock 99 144 362 minecraft:stripped_spruce_log
fill 99 144 363 102 144 363 minecraft:stone
fill 100 144 362 103 144 362 minecraft:stone
setblock 101 144 324 minecraft:stone
setblock 101 144 325 minecraft:stripped_spruce_log
fill 101 144 364 102 182 364 minecraft:deepslate
setblock 102 144 324 minecraft:stripped_spruce_log
fill 102 144 325 102 145 325 minecraft:stone
fill 102 144 361 103 145 361 minecraft:stone
setblock 103 144 323 minecraft:stripped_spruce_log
fill 103 144 324 103 145 324 minecraft:stone
setblock 103 144 363 minecraft:stripped_spruce_log
setblock 103 144 364 minecraft:diamond_block
fill 104 144 323 104 145 323 minecraft:stone
setblock 104 144 328 minecraft:stripped_dark_oak_log
setblock 104 144 362 minecraft:stripped_spruce_log
fill 104 144 363 107 144 363 minecraft:stone
fill 104 144 364 104 174 364 minecraft:deepslate
fill 105 144 325 105 144 328 minecraft:iron_bars
fill 105 144 329 105 145 330 minecraft:stripped_spruce_log
fill 105 144 362 105 145 362 minecraft:stone
setblock 107 144 324 minecraft:stripped_spruce_log
setblock 108 144 323 minecraft:stripped_spruce_log
setblock 108 144 363 minecraft:stripped_spruce_log
setblock 109 144 363 minecraft:stone
fill 112 144 323 112 144 330 minecraft:iron_bars
fill 119 144 323 122 144 323 minecraft:stone
fill 119 144 324 119 144 331 minecraft:iron_bars
fill 119 144 353 125 144 353 minecraft:stripped_dark_oak_log
fill 120 144 324 121 144 324 minecraft:stone
setblock 122 144 324 minecraft:stripped_spruce_log
fill 122 144 325 122 145 325 minecraft:stone
setblock 123 144 323 minecraft:stripped_spruce_log
fill 123 144 324 126 144 324 minecraft:stone
setblock 123 144 363 minecraft:stripped_spruce_log
fill 124 144 323 127 144 323 minecraft:stone
fill 124 144 363 124 145 363 minecraft:stone
setblock 124 144 364 minecraft:gold_block
fill 125 144 364 125 186 364 minecraft:deepslate
setblock 126 144 325 minecraft:stripped_spruce_log
fill 126 144 328 126 144 362 minecraft:iron_bars
setblock 127 144 324 minecraft:stripped_spruce_log
fill 127 144 325 127 145 325 minecraft:stone
setblock 127 144 330 minecraft:stripped_dark_oak_log
setblock 127 144 333 minecraft:stripped_dark_oak_log
fill 127 144 353 128 144 353 minecraft:stripped_dark_oak_log
setblock 128 144 323 minecraft:stripped_spruce_log
fill 128 144 324 128 145 324 minecraft:stone
setblock 128 144 329 minecraft:stripped_dark_oak_log
fill 129 144 323 129 145 323 minecraft:stone
setblock 129 144 344 minecraft:stripped_dark_oak_log
fill 129 144 353 132 144 353 minecraft:stripped_spruce_log
setblock 130 144 330 minecraft:stripped_dark_oak_log
setblock 131 144 341 minecraft:stripped_dark_oak_log
fill 131 144 352 132 144 352 minecraft:stripped_spruce_log
setblock 132 144 324 minecraft:stripped_spruce_log
fill 132 144 342 132 144 343 minecraft:stripped_dark_oak_log
setblock 133 144 323 minecraft:stripped_spruce_log
setblock 133 144 324 minecraft:stone
fill 133 144 326 133 144 327 minecraft:iron_bars
setblock 133 144 328 minecraft:stripped_spruce_log
fill 133 144 329 133 145 330 minecraft:stone
fill 133 144 331 133 144 356 minecraft:iron_bars
fill 134 144 323 134 145 323 minecraft:stone
setblock 134 144 327 minecraft:stripped_spruce_log
fill 134 144 328 134 145 328 minecraft:stone
setblock 134 144 332 minecraft:stripped_spruce_log
fill 134 144 333 134 145 333 minecraft:stone
fill 134 144 352 135 144 353 minecraft:stripped_spruce_log
setblock 135 144 326 minecraft:stripped_spruce_log
fill 135 144 327 135 145 327 minecraft:stone
setblock 135 144 331 minecraft:stripped_spruce_log
fill 135 144 332 135 145 332 minecraft:stone
setblock 135 144 335 minecraft:stone
fill 135 144 349 135 144 350 minecraft:stone
fill 94 145 327 94 186 327 minecraft:deepslate
fill 94 145 335 94 184 335 minecraft:deepslate
setblock 94 145 356 minecraft:raw_iron_block
fill 95 145 323 95 145 324 minecraft:stone
setblock 95 145 325 minecraft:stripped_spruce_log
setblock 95 145 326 minecraft:stone
setblock 95 145 330 minecraft:stripped_spruce_log
setblock 95 145 331 minecraft:stone
setblock 95 145 334 minecraft:stone
fill 95 145 348 95 145 349 minecraft:stone
setblock 95 145 350 minecraft:stripped_spruce_log
fill 95 145 351 96 145 351 minecraft:stone
setblock 95 145 354 minecraft:stone
setblock 95 145 355 minecraft:stripped_spruce_log
fill 95 145 356 95 145 359 minecraft:stone
setblock 95 145 360 minecraft:stripped_spruce_log
fill 95 145 361 95 145 363 minecraft:stone
setblock 96 145 323 minecraft:stone
setblock 96 145 324 minecraft:stripped_spruce_log
setblock 96 145 325 minecraft:stone
setblock 96 145 329 minecraft:stripped_spruce_log
setblock 96 145 330 minecraft:stone
setblock 96 145 332 minecraft:stone
setblock 96 145 350 minecraft:stone
setblock 96 145 353 minecraft:stone
setblock 96 145 354 minecraft:stripped_spruce_log
fill 96 145 355 96 145 356 minecraft:stone
setblock 96 145 363 minecraft:stone
setblock 97 145 323 minecraft:stripped_spruce_log
setblock 97 145 324 minecraft:stone
setblock 97 145 325 minecraft:light[level=12]
setblock 97 145 328 minecraft:stripped_spruce_log
setblock 97 145 332 minecraft:light[level=12]
setblock 97 145 339 minecraft:light[level=12]
setblock 97 145 346 minecraft:light[level=12]
setblock 97 145 353 minecraft:light[level=12]
setblock 97 145 360 minecraft:light[level=12]
setblock 97 145 363 minecraft:stripped_spruce_log
fill 98 145 323 101 145 323 minecraft:stone
setblock 98 145 362 minecraft:stripped_spruce_log
fill 98 145 363 101 145 363 minecraft:stone
fill 99 145 362 102 145 362 minecraft:stone
setblock 100 145 322 minecraft:raw_gold_block
setblock 100 145 324 minecraft:stone
setblock 100 145 325 minecraft:stripped_spruce_log
setblock 101 145 324 minecraft:stripped_spruce_log
setblock 101 145 325 minecraft:stone
setblock 101 145 361 minecraft:stone
setblock 102 145 323 minecraft:stripped_spruce_log
setblock 102 145 324 minecraft:stone
setblock 102 145 363 minecraft:stripped_spruce_log
setblock 103 145 323 minecraft:stone
setblock 103 145 362 minecraft:stripped_spruce_log
fill 103 145 363 106 145 363 minecraft:stone
fill 103 145 364 103 179 364 minecraft:deepslate
setblock 104 145 325 minecraft:light[level=12]
setblock 104 145 332 minecraft:light[level=12]
setblock 104 145 339 minecraft:light[level=12]
setblock 104 145 346 minecraft:light[level=12]
setblock 104 145 353 minecraft:light[level=12]
setblock 104 145 360 minecraft:light[level=12]
setblock 104 145 361 minecraft:stripped_spruce_log
setblock 104 145 362 minecraft:stone
setblock 105 145 328 minecraft:stripped_spruce_log
setblock 106 145 324 minecraft:stripped_spruce_log
setblock 107 145 323 minecraft:stripped_spruce_log
setblock 107 145 363 minecraft:stripped_spruce_log
setblock 108 145 363 minecraft:stone
setblock 111 145 325 minecraft:light[level=12]
setblock 111 145 332 minecraft:light[level=12]
setblock 111 145 339 minecraft:light[level=12]
setblock 111 145 346 minecraft:light[level=12]
setblock 111 145 353 minecraft:light[level=12]
setblock 111 145 360 minecraft:light[level=12]
setblock 118 145 325 minecraft:light[level=12]
setblock 118 145 332 minecraft:light[level=12]
setblock 118 145 339 minecraft:light[level=12]
setblock 118 145 346 minecraft:light[level=12]
setblock 118 145 353 minecraft:light[level=12]
setblock 118 145 360 minecraft:light[level=12]
fill 119 145 323 121 145 323 minecraft:stone
setblock 120 145 324 minecraft:stone
setblock 121 145 324 minecraft:stripped_spruce_log
setblock 122 145 323 minecraft:stripped_spruce_log
fill 122 145 324 125 145 324 minecraft:stone
setblock 122 145 363 minecraft:stripped_spruce_log
fill 123 145 322 123 180 322 minecraft:deepslate
fill 123 145 323 126 145 323 minecraft:stone
setblock 123 145 363 minecraft:stone
setblock 124 145 322 minecraft:raw_gold_block
setblock 124 145 364 minecraft:deepslate
fill 125 145 322 125 182 322 minecraft:deepslate
setblock 125 145 325 minecraft:stripped_spruce_log
setblock 125 145 332 minecraft:light[level=12]
setblock 125 145 339 minecraft:light[level=12]
setblock 125 145 346 minecraft:light[level=12]
setblock 125 145 353 minecraft:light[level=12]
setblock 125 145 360 minecraft:light[level=12]
setblock 126 145 324 minecraft:stripped_spruce_log
setblock 126 145 325 minecraft:stone
setblock 127 145 323 minecraft:stripped_spruce_log
setblock 127 145 324 minecraft:stone
setblock 128 145 323 minecraft:stone
fill 130 145 353 132 145 353 minecraft:stripped_dark_oak_log
setblock 131 145 324 minecraft:stripped_spruce_log
setblock 132 145 323 minecraft:stripped_spruce_log
setblock 132 145 325 minecraft:light[level=12]
setblock 132 145 332 minecraft:light[level=12]
setblock 132 145 339 minecraft:light[level=12]
setblock 132 145 346 minecraft:light[level=12]
setblock 132 145 360 minecraft:light[level=12]
setblock 133 145 323 minecraft:stone
setblock 133 145 328 minecraft:stone
setblock 133 145 331 minecraft:stone
fill 133 145 351 133 145 363 minecraft:iron_bars
setblock 134 145 326 minecraft:stripped_spruce_log
setblock 134 145 327 minecraft:stone
setblock 134 145 330 minecraft:stone
setblock 134 145 331 minecraft:stripped_spruce_log
setblock 134 145 332 minecraft:stone
setblock 134 145 334 minecraft:stone
setblock 134 145 352 minecraft:stripped_dark_oak_log
setblock 135 145 325 minecraft:stripped_spruce_log
setblock 135 145 326 minecraft:stone
setblock 135 145 330 minecraft:stripped_spruce_log
setblock 135 145 331 minecraft:stone
setblock 135 145 335 minecraft:stripped_spruce_log
setblock 135 145 336 minecraft:stone
setblock 135 145 349 minecraft:stone
setblock 135 145 350 minecraft:stripped_spruce_log
fill 135 145 351 135 145 353 minecraft:stone
fill 94 146 328 94 186 329 minecraft:deepslate
setblock 94 146 330 minecraft:raw_iron_block
fill 94 146 331 94 170 331 minecraft:deepslate
fill 94 146 356 94 150 356 minecraft:deepslate
fill 100 146 322 100 173 322 minecraft:deepslate
fill 124 146 322 124 186 322 minecraft:deepslate
setblock 124 146 364 minecraft:raw_iron_block
fill 94 147 330 94 162 330 minecraft:deepslate
fill 94 147 353 94 186 353 minecraft:deepslate
setblock 94 147 354 minecraft:raw_iron_block
setblock 97 147 325 minecraft:light[level=15]
setblock 97 147 333 minecraft:light[level=15]
setblock 97 147 341 minecraft:light[level=15]
setblock 97 147 349 minecraft:light[level=15]
setblock 97 147 357 minecraft:light[level=15]
setblock 105 147 325 minecraft:light[level=15]
setblock 105 147 333 minecraft:light[level=15]
setblock 105 147 341 minecraft:light[level=15]
setblock 105 147 349 minecraft:light[level=15]
setblock 105 147 357 minecraft:light[level=15]
setblock 106 147 364 minecraft:gold_block
setblock 113 147 325 minecraft:light[level=15]
setblock 113 147 333 minecraft:light[level=15]
setblock 113 147 341 minecraft:light[level=15]
setblock 113 147 349 minecraft:light[level=15]
setblock 113 147 357 minecraft:light[level=15]
setblock 121 147 325 minecraft:light[level=15]
setblock 121 147 333 minecraft:light[level=15]
setblock 121 147 341 minecraft:light[level=15]
setblock 121 147 349 minecraft:light[level=15]
setblock 121 147 357 minecraft:light[level=15]
fill 124 147 364 124 157 364 minecraft:deepslate
setblock 129 147 325 minecraft:light[level=15]
setblock 129 147 333 minecraft:light[level=15]
setblock 129 147 341 minecraft:light[level=15]
setblock 129 147 349 minecraft:light[level=15]
setblock 129 147 357 minecraft:light[level=15]
fill 136 147 327 136 154 328 minecraft:deepslate
setblock 136 147 329 minecraft:gold_block
fill 136 147 358 136 175 359 minecraft:deepslate
setblock 136 147 360 minecraft:raw_gold_block
fill 94 148 354 94 149 354 minecraft:deepslate
fill 96 148 324 96 151 324 minecraft:spruce_log
fill 96 148 343 96 151 343 minecraft:spruce_log
fill 96 148 362 96 151 362 minecraft:spruce_log
setblock 102 148 322 minecraft:diamond_block
fill 106 148 364 106 171 364 minecraft:deepslate
fill 115 148 324 115 151 324 minecraft:spruce_log
fill 115 148 362 115 151 362 minecraft:spruce_log
fill 134 148 324 134 151 324 minecraft:spruce_log
fill 134 148 343 134 151 343 minecraft:spruce_log
fill 134 148 362 134 151 362 minecraft:spruce_log
fill 136 148 329 136 167 329 minecraft:deepslate
fill 136 148 360 136 182 360 minecraft:deepslate
fill 102 149 322 102 160 322 minecraft:deepslate
fill 107 149 322 108 163 322 minecraft:deepslate
setblock 109 149 322 minecraft:diamond_block
fill 110 149 322 110 186 322 minecraft:deepslate
setblock 136 149 355 minecraft:raw_iron_block
setblock 94 150 345 minecraft:raw_gold_block
setblock 94 150 354 minecraft:diamond_block
fill 109 150 322 109 184 322 minecraft:deepslate
fill 136 150 355 136 186 355 minecraft:deepslate
fill 94 151 345 94 186 345 minecraft:deepslate
fill 94 151 354 94 174 354 minecraft:deepslate
setblock 94 151 356 minecraft:gold_block
fill 95 151 322 96 172 322 minecraft:deepslate
setblock 97 151 322 minecraft:raw_iron_block
setblock 97 151 325 minecraft:light[level=12]
setblock 97 151 332 minecraft:light[level=12]
setblock 97 151 339 minecraft:light[level=12]
setblock 97 151 346 minecraft:light[level=12]
setblock 97 151 353 minecraft:light[level=12]
setblock 97 151 360 minecraft:light[level=12]
setblock 104 151 325 minecraft:light[level=12]
setblock 104 151 332 minecraft:light[level=12]
setblock 104 151 339 minecraft:light[level=12]
setblock 104 151 346 minecraft:light[level=12]
setblock 104 151 353 minecraft:light[level=12]
setblock 104 151 360 minecraft:light[level=12]
setblock 111 151 325 minecraft:light[level=12]
setblock 111 151 332 minecraft:light[level=12]
setblock 111 151 339 minecraft:light[level=12]
setblock 111 151 346 minecraft:light[level=12]
setblock 111 151 353 minecraft:light[level=12]
setblock 111 151 360 minecraft:light[level=12]
fill 112 151 332 112 152 346 minecraft:iron_block
fill 113 151 332 126 152 332 minecraft:iron_block
fill 113 151 333 116 151 345 minecraft:spruce_planks
fill 113 151 346 126 152 346 minecraft:iron_block
fill 117 151 333 117 151 337 minecraft:spruce_planks
fill 117 151 341 117 151 345 minecraft:spruce_planks
setblock 118 151 325 minecraft:light[level=12]
fill 118 151 333 125 151 336 minecraft:spruce_planks
fill 118 151 342 125 151 345 minecraft:spruce_planks
setblock 118 151 353 minecraft:light[level=12]
setblock 118 151 360 minecraft:light[level=12]
fill 121 151 337 125 151 337 minecraft:spruce_planks
fill 121 151 341 125 151 341 minecraft:spruce_planks
fill 122 151 338 125 151 340 minecraft:spruce_planks
setblock 125 151 325 minecraft:light[level=12]
setblock 125 151 353 minecraft:light[level=12]
setblock 125 151 360 minecraft:light[level=12]
fill 126 151 333 126 152 345 minecraft:iron_block
setblock 132 151 325 minecraft:light[level=12]
setblock 132 151 332 minecraft:light[level=12]
setblock 132 151 339 minecraft:light[level=12]
setblock 132 151 346 minecraft:light[level=12]
setblock 132 151 353 minecraft:light[level=12]
setblock 132 151 360 minecraft:light[level=12]
fill 134 151 322 134 163 322 minecraft:deepslate
setblock 135 151 322 minecraft:gold_block
fill 136 151 322 136 182 322 minecraft:deepslate
setblock 136 151 334 minecraft:deepslate
setblock 136 151 335 minecraft:raw_gold_block
setblock 94 152 343 minecraft:raw_iron_block
fill 94 152 346 100 152 348 minecraft:deepslate
setblock 94 152 349 minecraft:raw_gold_block
fill 94 152 350 100 152 351 minecraft:deepslate
fill 94 152 356 100 152 356 minecraft:deepslate
fill 95 152 323 95 152 345 minecraft:deepslate
fill 95 152 349 100 152 349 minecraft:deepslate
fill 95 152 352 100 152 355 minecraft:deepslate
fill 95 152 357 95 152 363 minecraft:deepslate
setblock 95 152 364 minecraft:raw_gold_block
fill 96 152 323 100 152 323 minecraft:deepslate
setblock 96 152 324 minecraft:glowstone
fill 96 152 325 100 152 342 minecraft:deepslate
setblock 96 152 343 minecraft:glowstone
fill 96 152 344 100 152 345 minecraft:deepslate
fill 96 152 357 100 152 361 minecraft:deepslate
setblock 96 152 362 minecraft:glowstone
fill 96 152 363 97 152 364 minecraft:deepslate
fill 97 152 322 97 184 322 minecraft:deepslate
fill 97 152 324 100 152 324 minecraft:deepslate
fill 97 152 343 100 152 343 minecraft:deepslate
fill 97 152 362 100 152 362 minecraft:deepslate
fill 98 152 363 100 152 363 minecraft:deepslate
fill 101 152 323 101 152 363 minecraft:raw_gold_block
fill 102 152 323 107 152 363 minecraft:deepslate
fill 108 152 323 108 152 363 minecraft:raw_gold_block
fill 109 152 323 111 152 363 minecraft:deepslate
fill 112 152 323 114 152 331 minecraft:deepslate
fill 112 152 347 114 152 363 minecraft:deepslate
fill 113 152 333 115 152 345 minecraft:spruce_planks
setblock 115 152 323 minecraft:raw_gold_block
setblock 115 152 324 minecraft:glowstone
fill 115 152 325 115 152 331 minecraft:raw_gold_block
fill 115 152 347 115 152 361 minecraft:raw_gold_block
setblock 115 152 362 minecraft:glowstone
setblock 115 152 363 minecraft:raw_gold_block
fill 116 152 323 121 152 331 minecraft:deepslate
fill 116 152 333 116 152 336 minecraft:spruce_planks
fill 116 152 337 116 152 341 minecraft:glowstone
fill 116 152 342 116 152 345 minecraft:spruce_planks
fill 116 152 347 121 152 363 minecraft:deepslate
fill 117 152 333 125 152 335 minecraft:spruce_planks
fill 117 152 336 117 152 337 minecraft:glowstone
fill 117 152 341 117 152 342 minecraft:glowstone
fill 117 152 343 125 152 345 minecraft:spruce_planks
fill 118 152 336 121 152 336 minecraft:glowstone
fill 118 152 342 121 152 342 minecraft:glowstone
fill 121 152 337 122 152 337 minecraft:glowstone
fill 121 152 341 122 152 341 minecraft:glowstone
fill 122 152 323 122 152 331 minecraft:raw_gold_block
fill 122 152 336 125 152 336 minecraft:spruce_planks
fill 122 152 338 122 152 340 minecraft:glowstone
fill 122 152 342 125 152 342 minecraft:spruce_planks
fill 122 152 347 122 152 363 minecraft:raw_gold_block
fill 123 152 323 128 152 331 minecraft:deepslate
fill 123 152 337 125 152 341 minecraft:spruce_planks
fill 123 152 347 128 152 363 minecraft:deepslate
fill 127 152 332 128 152 346 minecraft:deepslate
fill 129 152 323 129 152 363 minecraft:raw_gold_block
fill 130 152 323 133 152 363 minecraft:deepslate
fill 134 152 323 135 152 323 minecraft:deepslate
setblock 134 152 324 minecraft:glowstone
fill 134 152 325 135 152 342 minecraft:deepslate
setblock 134 152 343 minecraft:glowstone
fill 134 152 344 135 152 361 minecraft:deepslate
setblock 134 152 362 minecraft:glowstone
fill 134 152 363 135 152 363 minecraft:deepslate
setblock 135 152 322 minecraft:deepslate
setblock 135 152 324 minecraft:deepslate
setblock 135 152 343 minecraft:deepslate
setblock 135 152 362 minecraft:deepslate
setblock 136 152 334 minecraft:diamond_block
setblock 136 152 335 minecraft:deepslate
fill 94 153 343 94 186 343 minecraft:deepslate
fill 94 153 346 94 173 351 minecraft:deepslate
fill 94 153 356 94 186 356 minecraft:deepslate
fill 95 153 364 97 182 364 minecraft:deepslate
fill 96 153 324 96 154 324 minecraft:spruce_log
fill 96 153 343 96 154 343 minecraft:spruce_log
fill 96 153 362 96 154 362 minecraft:spruce_log
fill 110 153 364 110 186 364 minecraft:deepslate
setblock 111 153 364 minecraft:raw_gold_block
fill 112 153 332 112 172 332 minecraft:iron_bars
fill 112 153 346 112 172 346 minecraft:iron_bars
fill 112 153 364 112 176 364 minecraft:deepslate
fill 115 153 324 115 154 324 minecraft:spruce_log
fill 115 153 362 115 154 362 minecraft:spruce_log
fill 126 153 332 126 172 332 minecraft:iron_bars
fill 126 153 346 126 172 346 minecraft:iron_bars
setblock 130 153 322 minecraft:diamond_block
fill 134 153 324 134 154 324 minecraft:spruce_log
fill 134 153 343 134 154 343 minecraft:spruce_log
fill 134 153 362 134 154 362 minecraft:spruce_log
setblock 135 153 322 minecraft:raw_gold_block
fill 136 153 334 136 187 334 minecraft:deepslate
setblock 136 153 335 minecraft:gold_block
setblock 136 153 352 minecraft:raw_iron_block
setblock 94 154 332 minecraft:raw_gold_block
fill 94 154 358 94 186 359 minecraft:deepslate
setblock 94 154 360 minecraft:diamond_block
fill 95 154 323 95 154 363 minecraft:spruce_planks
fill 96 154 323 135 154 323 minecraft:spruce_planks
fill 96 154 325 96 154 342 minecraft:spruce_planks
fill 96 154 344 96 154 361 minecraft:spruce_planks
fill 96 154 363 135 154 363 minecraft:spruce_planks
fill 97 154 324 114 154 324 minecraft:spruce_planks
fill 97 154 362 114 154 362 minecraft:spruce_planks
fill 111 154 364 111 169 364 minecraft:deepslate
fill 116 154 324 133 154 324 minecraft:spruce_planks
fill 116 154 362 133 154 362 minecraft:spruce_planks
setblock 130 154 322 minecraft:deepslate
fill 134 154 325 135 154 342 minecraft:spruce_planks
fill 134 154 344 135 154 361 minecraft:spruce_planks
fill 135 154 322 135 183 322 minecraft:deepslate
setblock 135 154 324 minecraft:spruce_planks
setblock 135 154 343 minecraft:spruce_planks
setblock 135 154 362 minecraft:spruce_planks
setblock 136 154 323 minecraft:raw_iron_block
setblock 136 154 326 minecraft:diamond_block
fill 136 154 335 136 186 335 minecraft:deepslate
setblock 136 154 350 minecraft:diamond_block
fill 136 154 352 136 165 352 minecraft:deepslate
fill 94 155 332 94 186 332 minecraft:deepslate
setblock 94 155 344 minecraft:diamond_block
fill 94 155 360 94 182 360 minecraft:deepslate
setblock 97 155 325 minecraft:light[level=15]
setblock 97 155 333 minecraft:light[level=15]
setblock 97 155 341 minecraft:light[level=15]
setblock 97 155 349 minecraft:light[level=15]
setblock 97 155 357 minecraft:light[level=15]
setblock 105 155 325 minecraft:light[level=15]
setblock 105 155 333 minecraft:light[level=15]
setblock 105 155 341 minecraft:light[level=15]
setblock 105 155 349 minecraft:light[level=15]
setblock 105 155 357 minecraft:light[level=15]
setblock 113 155 325 minecraft:light[level=15]
setblock 113 155 333 minecraft:light[level=15]
setblock 113 155 341 minecraft:light[level=15]
setblock 113 155 349 minecraft:light[level=15]
setblock 113 155 357 minecraft:light[level=15]
setblock 121 155 325 minecraft:light[level=15]
setblock 121 155 333 minecraft:light[level=15]
setblock 121 155 341 minecraft:light[level=15]
setblock 121 155 349 minecraft:light[level=15]
setblock 121 155 357 minecraft:light[level=15]
setblock 129 155 325 minecraft:light[level=15]
setblock 129 155 333 minecraft:light[level=15]
setblock 129 155 341 minecraft:light[level=15]
setblock 129 155 349 minecraft:light[level=15]
setblock 129 155 357 minecraft:light[level=15]
setblock 130 155 322 minecraft:raw_iron_block
fill 136 155 323 136 183 323 minecraft:deepslate
fill 136 155 326 136 186 326 minecraft:deepslate
setblock 136 155 327 minecraft:raw_iron_block
fill 136 155 328 136 183 328 minecraft:deepslate
setblock 136 155 333 minecraft:raw_iron_block
fill 136 155 343 136 183 343 minecraft:deepslate
setblock 136 155 344 minecraft:raw_gold_block
fill 136 155 350 136 182 350 minecraft:deepslate
fill 94 156 344 94 159 344 minecraft:deepslate
setblock 95 156 323 minecraft:stone
setblock 95 156 324 minecraft:stripped_spruce_log
fill 95 156 325 95 159 325 minecraft:stone
fill 95 156 331 95 156 333 minecraft:stone
setblock 95 156 334 minecraft:stripped_spruce_log
fill 95 156 335 95 156 338 minecraft:stone
setblock 95 156 339 minecraft:stripped_spruce_log
fill 95 156 340 95 156 343 minecraft:stone
setblock 95 156 344 minecraft:stripped_spruce_log
fill 95 156 345 95 156 348 minecraft:stone
setblock 95 156 349 minecraft:stripped_spruce_log
fill 95 156 350 95 156 353 minecraft:stone
setblock 95 156 354 minecraft:stripped_spruce_log
fill 95 156 355 95 156 358 minecraft:stone
setblock 95 156 359 minecraft:stripped_spruce_log
fill 95 156 360 95 156 363 minecraft:stone
setblock 96 156 323 minecraft:stripped_spruce_log
fill 96 156 334 96 156 337 minecraft:stone
setblock 96 156 338 minecraft:stripped_spruce_log
fill 96 156 339 96 156 342 minecraft:stone
setblock 96 156 343 minecraft:stripped_spruce_log
fill 96 156 350 96 156 352 minecraft:stone
setblock 96 156 353 minecraft:stripped_spruce_log
fill 96 156 354 96 156 357 minecraft:stone
setblock 96 156 358 minecraft:stripped_spruce_log
fill 96 156 359 96 156 362 minecraft:stone
setblock 96 156 363 minecraft:stripped_spruce_log
fill 97 156 323 99 157 323 minecraft:stone
fill 97 156 353 97 156 356 minecraft:stone
setblock 97 156 357 minecraft:stripped_spruce_log
fill 97 156 358 97 156 361 minecraft:stone
setblock 97 156 362 minecraft:stripped_spruce_log
fill 97 156 363 100 156 363 minecraft:stone
setblock 98 156 356 minecraft:stripped_spruce_log
fill 98 156 357 98 156 360 minecraft:stone
setblock 98 156 361 minecraft:stripped_spruce_log
fill 98 156 362 101 156 362 minecraft:stone
setblock 99 156 360 minecraft:stripped_spruce_log
fill 99 156 361 101 157 361 minecraft:stone
setblock 100 156 364 minecraft:raw_gold_block
setblock 101 156 363 minecraft:stripped_spruce_log
fill 102 156 327 104 156 327 minecraft:cobbled_deepslate
setblock 102 156 362 minecraft:stripped_spruce_log
fill 102 156 363 103 158 363 minecraft:stone
setblock 103 156 326 minecraft:cobbled_deepslate
setblock 103 156 328 minecraft:cobbled_deepslate
fill 113 156 363 115 156 363 minecraft:stone
setblock 115 156 323 minecraft:stone
fill 115 156 324 117 156 325 minecraft:cobbled_deepslate
setblock 116 156 323 minecraft:stripped_spruce_log
setblock 116 156 362 minecraft:stone
setblock 116 156 363 minecraft:stripped_spruce_log
fill 117 156 323 120 156 323 minecraft:stone
setblock 117 156 362 minecraft:stripped_spruce_log
fill 117 156 363 120 156 363 minecraft:stone
fill 118 156 362 118 159 362 minecraft:stone
setblock 121 156 323 minecraft:stripped_spruce_log
setblock 121 156 363 minecraft:stripped_spruce_log
fill 122 156 323 123 158 323 minecraft:stone
fill 122 156 363 122 159 363 minecraft:stone
fill 124 156 335 126 213 337 minecraft:stripped_spruce_log
fill 129 156 323 130 156 323 minecraft:stone
fill 129 156 363 130 156 363 minecraft:stone
fill 130 156 322 130 186 322 minecraft:deepslate
fill 130 156 346 130 160 346 minecraft:stripped_spruce_log
setblock 131 156 323 minecraft:stripped_spruce_log
setblock 131 156 362 minecraft:stone
setblock 131 156 363 minecraft:stripped_spruce_log
fill 132 156 323 135 156 323 minecraft:stone
setblock 132 156 362 minecraft:stripped_spruce_log
fill 132 156 363 135 156 363 minecraft:stone
fill 133 156 359 133 156 360 minecraft:stone
setblock 133 156 361 minecraft:stripped_spruce_log
fill 133 156 362 135 157 362 minecraft:stone
setblock 134 156 324 minecraft:stone
setblock 134 156 326 minecraft:raw_gold_block
fill 134 156 332 134 156 334 minecraft:stone
setblock 134 156 335 minecraft:stripped_spruce_log
fill 134 156 336 134 156 339 minecraft:stone
setblock 134 156 355 minecraft:stripped_spruce_log
fill 134 156 356 134 156 359 minecraft:stone
setblock 134 156 360 minecraft:stripped_spruce_log
fill 134 156 361 135 158 361 minecraft:stone
setblock 135 156 324 minecraft:stripped_spruce_log
fill 135 156 325 135 156 328 minecraft:stone
setblock 135 156 329 minecraft:stripped_spruce_log
fill 135 156 330 135 156 333 minecraft:stone
setblock 135 156 334 minecraft:stripped_spruce_log
fill 135 156 335 135 156 338 minecraft:stone
setblock 135 156 339 minecraft:stripped_spruce_log
fill 135 156 340 135 156 343 minecraft:stone
fill 135 156 351 135 156 353 minecraft:stone
setblock 135 156 354 minecraft:stripped_spruce_log
fill 135 156 355 135 156 358 minecraft:stone
setblock 135 156 359 minecraft:stripped_spruce_log
fill 135 156 360 135 159 360 minecraft:stone
fill 136 156 327 136 186 327 minecraft:deepslate
fill 136 156 333 136 186 333 minecraft:deepslate
setblock 136 156 344 minecraft:deepslate
setblock 94 157 326 minecraft:gold_block
setblock 95 157 323 minecraft:stripped_spruce_log
fill 95 157 324 95 160 324 minecraft:stone
fill 95 157 326 95 158 326 minecraft:stone
fill 95 157 330 95 157 332 minecraft:stone
setblock 95 157 333 minecraft:stripped_spruce_log
fill 95 157 334 95 157 337 minecraft:stone
setblock 95 157 338 minecraft:stripped_spruce_log
fill 95 157 339 95 157 342 minecraft:stone
setblock 95 157 343 minecraft:stripped_spruce_log
fill 95 157 344 95 157 347 minecraft:stone
setblock 95 157 348 minecraft:stripped_spruce_log
fill 95 157 349 95 157 352 minecraft:stone
setblock 95 157 353 minecraft:stripped_spruce_log
fill 95 157 354 95 157 357 minecraft:stone
setblock 95 157 358 minecraft:stripped_spruce_log
fill 95 157 359 95 157 362 minecraft:stone
setblock 95 157 363 minecraft:stripped_spruce_log
fill 96 157 323 96 160 323 minecraft:stone
fill 96 157 334 96 157 336 minecraft:stone
setblock 96 157 337 minecraft:stripped_spruce_log
fill 96 157 338 96 157 341 minecraft:stone
setblock 96 157 342 minecraft:stripped_spruce_log
fill 96 157 343 96 157 346 minecraft:stone
setblock 96 157 347 minecraft:stripped_spruce_log
fill 96 157 348 96 157 351 minecraft:stone
setblock 96 157 352 minecraft:stripped_spruce_log
fill 96 157 353 96 157 356 minecraft:stone
setblock 96 157 357 minecraft:stripped_spruce_log
fill 96 157 358 96 157 361 minecraft:stone
setblock 96 157 362 minecraft:stripped_spruce_log
fill 96 157 363 99 157 363 minecraft:stone
setblock 97 157 325 minecraft:light[level=12]
setblock 97 157 332 minecraft:light[level=12]
fill 97 157 338 97 157 340 minecraft:stone
setblock 97 157 346 minecraft:light[level=12]
fill 97 157 352 97 157 355 minecraft:stone
setblock 97 157 356 minecraft:stripped_spruce_log
fill 97 157 357 97 157 360 minecraft:stone
setblock 97 157 361 minecraft:stripped_spruce_log
fill 97 157 362 100 157 362 minecraft:stone
fill 98 157 356 98 157 359 minecraft:stone
setblock 98 157 360 minecraft:stripped_spruce_log
fill 98 157 361 98 160 361 minecraft:stone
fill 99 157 360 99 159 360 minecraft:stone
setblock 100 157 363 minecraft:stripped_spruce_log
fill 100 157 364 100 186 364 minecraft:deepslate
setblock 101 157 362 minecraft:stripped_spruce_log
fill 101 157 363 101 160 363 minecraft:stone
fill 102 157 362 102 160 362 minecraft:stone
setblock 104 157 325 minecraft:light[level=12]
setblock 104 157 332 minecraft:light[level=12]
setblock 104 157 339 minecraft:light[level=12]
setblock 104 157 346 minecraft:light[level=12]
setblock 104 157 353 minecraft:light[level=12]
setblock 104 157 360 minecraft:light[level=12]
setblock 104 157 363 minecraft:stone
setblock 111 157 325 minecraft:light[level=12]
setblock 111 157 332 minecraft:light[level=12]
setblock 111 157 339 minecraft:light[level=12]
setblock 111 157 346 minecraft:light[level=12]
setblock 111 157 353 minecraft:light[level=12]
setblock 111 157 360 minecraft:light[level=12]
fill 111 157 363 114 157 363 minecraft:stone
fill 113 157 323 114 157 323 minecraft:stone
fill 113 157 362 115 157 362 minecraft:stone
fill 114 157 364 114 182 364 minecraft:deepslate
setblock 115 157 323 minecraft:stripped_spruce_log
fill 115 157 324 116 157 325 minecraft:cobbled_deepslate
setblock 115 157 363 minecraft:stripped_spruce_log
setblock 115 157 364 minecraft:diamond_block
fill 116 157 323 119 157 323 minecraft:stone
setblock 116 157 362 minecraft:stripped_spruce_log
fill 116 157 363 119 157 363 minecraft:stone
fill 116 157 364 116 183 364 minecraft:deepslate
fill 117 157 324 118 157 324 minecraft:stone
setblock 117 157 325 minecraft:cobbled_deepslate
fill 117 157 362 117 160 362 minecraft:stone
setblock 118 157 325 minecraft:light[level=12]
setblock 118 157 332 minecraft:light[level=12]
setblock 118 157 339 minecraft:light[level=12]
setblock 118 157 346 minecraft:light[level=12]
setblock 118 157 353 minecraft:light[level=12]
setblock 118 157 360 minecraft:light[level=12]
setblock 119 157 324 minecraft:stripped_spruce_log
fill 119 157 362 120 157 362 minecraft:stone
setblock 120 157 323 minecraft:stripped_spruce_log
setblock 120 157 363 minecraft:stripped_spruce_log
fill 121 157 323 121 160 323 minecraft:stone
fill 121 157 363 121 160 363 minecraft:stone
fill 123 157 335 123 158 337 minecraft:cobbled_deepslate
fill 123 157 363 124 157 363 minecraft:stone
setblock 124 157 323 minecraft:stone
fill 124 157 334 126 158 334 minecraft:cobbled_deepslate
fill 124 157 338 126 158 338 minecraft:cobbled_deepslate
setblock 125 157 323 minecraft:stripped_spruce_log
setblock 125 157 325 minecraft:light[level=12]
setblock 125 157 332 minecraft:light[level=12]
setblock 125 157 339 minecraft:light[level=12]
setblock 125 157 346 minecraft:light[level=12]
setblock 125 157 353 minecraft:light[level=12]
setblock 125 157 360 minecraft:light[level=12]
setblock 125 157 363 minecraft:stripped_spruce_log
fill 126 157 323 129 157 323 minecraft:stone
fill 126 157 363 129 157 363 minecraft:stone
fill 127 157 322 127 182 322 minecraft:deepslate
fill 127 157 335 127 158 337 minecraft:cobbled_deepslate
setblock 128 157 322 minecraft:raw_gold_block
fill 129 157 322 129 186 322 minecraft:deepslate
fill 129 157 346 129 160 346 minecraft:stripped_spruce_log
setblock 130 157 323 minecraft:stripped_spruce_log
fill 130 157 345 130 160 345 minecraft:stripped_spruce_log
fill 130 157 347 130 160 347 minecraft:stripped_spruce_log
setblock 130 157 362 minecraft:stone
setblock 130 157 363 minecraft:stripped_spruce_log
fill 131 157 323 134 157 323 minecraft:stone
fill 131 157 346 131 160 346 minecraft:stripped_spruce_log
setblock 131 157 362 minecraft:stripped_spruce_log
fill 131 157 363 134 157 363 minecraft:stone
fill 132 157 324 133 157 324 minecraft:stone
setblock 132 157 325 minecraft:light[level=12]
fill 132 157 326 133 159 326 minecraft:raw_gold_block
setblock 132 157 332 minecraft:light[level=12]
setblock 132 157 339 minecraft:light[level=12]
setblock 132 157 346 minecraft:light[level=12]
setblock 132 157 353 minecraft:light[level=12]
setblock 132 157 360 minecraft:light[level=12]
setblock 132 157 361 minecraft:stripped_spruce_log
fill 132 157 362 132 160 362 minecraft:stone
fill 133 157 325 133 158 325 minecraft:raw_gold_block
fill 133 157 327 134 157 327 minecraft:raw_gold_block
fill 133 157 357 133 157 359 minecraft:stone
setblock 133 157 360 minecraft:stripped_spruce_log
fill 133 157 361 133 160 361 minecraft:stone
setblock 134 157 324 minecraft:stripped_spruce_log
fill 134 157 325 135 158 326 minecraft:stone
fill 134 157 331 134 157 333 minecraft:stone
setblock 134 157 334 minecraft:stripped_spruce_log
fill 134 157 335 134 157 338 minecraft:stone
setblock 134 157 339 minecraft:stripped_spruce_log
fill 134 157 340 135 158 341 minecraft:stone
setblock 134 157 354 minecraft:stripped_spruce_log
fill 134 157 355 134 157 358 minecraft:stone
setblock 134 157 359 minecraft:stripped_spruce_log
fill 134 157 360 134 160 360 minecraft:stone
setblock 135 157 323 minecraft:stripped_spruce_log
fill 135 157 324 135 160 324 minecraft:stone
setblock 135 157 327 minecraft:stone
setblock 135 157 328 minecraft:stripped_spruce_log
fill 135 157 329 135 157 332 minecraft:stone
setblock 135 157 333 minecraft:stripped_spruce_log
fill 135 157 334 135 157 337 minecraft:stone
setblock 135 157 338 minecraft:stripped_spruce_log
fill 135 157 339 135 160 339 minecraft:stone
setblock 135 157 342 minecraft:stone
setblock 135 157 343 minecraft:stripped_spruce_log
fill 135 157 344 135 159 345 minecraft:stone
fill 135 157 350 135 157 352 minecraft:stone
setblock 135 157 353 minecraft:stripped_spruce_log
fill 135 157 354 135 157 357 minecraft:stone
setblock 135 157 358 minecraft:stripped_spruce_log
fill 135 157 359 135 160 359 minecraft:stone
setblock 135 157 363 minecraft:stripped_spruce_log
setblock 136 157 344 minecraft:gold_block
fill 94 158 326 94 166 326 minecraft:deepslate
fill 95 158 323 95 161 323 minecraft:stone
setblock 95 158 327 minecraft:stripped_spruce_log
fill 95 158 328 95 158 331 minecraft:stone
setblock 95 158 332 minecraft:stripped_spruce_log
fill 95 158 333 95 158 336 minecraft:stone
setblock 95 158 337 minecraft:stripped_spruce_log
fill 95 158 338 95 158 341 minecraft:stone
setblock 95 158 342 minecraft:stripped_spruce_log
fill 95 158 343 95 158 346 minecraft:stone
setblock 95 158 347 minecraft:stripped_spruce_log
fill 95 158 348 95 158 351 minecraft:stone
setblock 95 158 352 minecraft:stripped_spruce_log
fill 95 158 353 95 158 356 minecraft:stone
setblock 95 158 357 minecraft:stripped_spruce_log
fill 95 158 358 95 158 361 minecraft:stone
setblock 95 158 362 minecraft:stripped_spruce_log
fill 95 158 363 98 158 363 minecraft:stone
fill 96 158 334 96 158 335 minecraft:stone
setblock 96 158 336 minecraft:stripped_spruce_log
fill 96 158 337 96 158 340 minecraft:stone
setblock 96 158 341 minecraft:stripped_spruce_log
fill 96 158 342 96 158 345 minecraft:stone
setblock 96 158 346 minecraft:stripped_spruce_log
fill 96 158 347 96 158 350 minecraft:stone
setblock 96 158 351 minecraft:stripped_spruce_log
fill 96 158 352 96 158 355 minecraft:stone
setblock 96 158 356 minecraft:stripped_spruce_log
fill 96 158 357 96 158 360 minecraft:stone
setblock 96 158 361 minecraft:stripped_spruce_log
fill 96 158 362 99 158 362 minecraft:stone
fill 97 158 323 98 158 323 minecraft:stone
fill 97 158 337 97 158 339 minecraft:stone
setblock 97 158 340 minecraft:stripped_spruce_log
fill 97 158 341 97 159 343 minecraft:stone
fill 97 158 352 97 158 354 minecraft:stone
setblock 97 158 355 minecraft:stripped_spruce_log
fill 97 158 356 97 158 359 minecraft:stone
setblock 97 158 360 minecraft:stripped_spruce_log
fill 97 158 361 97 161 361 minecraft:stone
fill 98 158 356 98 158 358 minecraft:stone
setblock 98 158 359 minecraft:stripped_spruce_log
fill 98 158 360 98 160 360 minecraft:stone
setblock 99 158 323 minecraft:stripped_spruce_log
fill 99 158 361 100 158 361 minecraft:stone
setblock 99 158 363 minecraft:stripped_spruce_log
fill 100 158 323 100 161 323 minecraft:stone
setblock 100 158 362 minecraft:stripped_spruce_log
fill 100 158 363 100 161 363 minecraft:stone
setblock 101 158 361 minecraft:stripped_spruce_log
fill 101 158 362 101 161 362 minecraft:stone
fill 103 158 362 103 159 362 minecraft:stone
setblock 104 158 363 minecraft:stripped_spruce_log
fill 105 158 363 106 160 363 minecraft:stone
setblock 108 158 363 minecraft:stone
setblock 109 158 363 minecraft:stripped_spruce_log
fill 110 158 363 113 158 363 minecraft:stone
fill 111 158 323 113 158 323 minecraft:stone
fill 111 158 362 114 158 362 minecraft:stone
setblock 114 158 323 minecraft:stripped_spruce_log
fill 114 158 324 117 158 324 minecraft:stone
setblock 114 158 363 minecraft:stripped_spruce_log
fill 115 158 323 118 158 323 minecraft:stone
setblock 115 158 362 minecraft:stripped_spruce_log
fill 115 158 363 118 158 363 minecraft:stone
fill 115 158 364 115 183 364 minecraft:deepslate
fill 116 158 362 116 161 362 minecraft:stone
setblock 118 158 324 minecraft:stripped_spruce_log
setblock 119 158 323 minecraft:stripped_spruce_log
fill 119 158 324 120 160 324 minecraft:stone
setblock 119 158 362 minecraft:stone
setblock 119 158 363 minecraft:stripped_spruce_log
fill 120 158 323 120 161 323 minecraft:stone
setblock 120 158 362 minecraft:stripped_spruce_log
fill 120 158 363 120 161 363 minecraft:stone
fill 121 158 362 121 161 362 minecraft:stone
setblock 122 158 336 minecraft:cobbled_deepslate
setblock 123 158 334 minecraft:cobbled_deepslate
setblock 123 158 338 minecraft:cobbled_deepslate
setblock 123 158 363 minecraft:stone
setblock 124 158 323 minecraft:stripped_spruce_log
fill 124 158 339 126 158 339 minecraft:cobbled_deepslate
setblock 124 158 363 minecraft:stripped_spruce_log
setblock 124 158 364 minecraft:raw_gold_block
fill 125 158 323 128 158 323 minecraft:stone
setblock 125 158 333 minecraft:cobbled_deepslate
fill 125 158 363 128 158 363 minecraft:stone
setblock 127 158 334 minecraft:cobbled_deepslate
setblock 127 158 338 minecraft:cobbled_deepslate
setblock 127 158 364 minecraft:gold_block
fill 128 158 322 128 184 322 minecraft:deepslate
fill 128 158 335 128 158 337 minecraft:cobbled_deepslate
fill 128 158 362 129 158 362 minecraft:stone
fill 128 158 364 128 186 364 minecraft:deepslate
setblock 129 158 323 minecraft:stripped_spruce_log
setblock 129 158 363 minecraft:stripped_spruce_log
fill 130 158 323 132 158 324 minecraft:stone
setblock 130 158 362 minecraft:stripped_spruce_log
fill 130 158 363 133 158 363 minecraft:stone
fill 131 158 326 131 159 326 minecraft:raw_gold_block
setblock 131 158 361 minecraft:stripped_spruce_log
fill 131 158 362 131 161 362 minecraft:stone
setblock 132 158 325 minecraft:raw_gold_block
fill 132 158 327 133 158 327 minecraft:raw_gold_block
fill 132 158 361 132 161 361 minecraft:stone
setblock 133 158 323 minecraft:stone
setblock 133 158 324 minecraft:stripped_spruce_log
fill 133 158 357 133 158 358 minecraft:stone
setblock 133 158 359 minecraft:stripped_spruce_log
fill 133 158 360 133 161 360 minecraft:stone
fill 133 158 362 134 158 362 minecraft:stone
setblock 134 158 323 minecraft:stripped_spruce_log
fill 134 158 324 134 161 324 minecraft:stone
setblock 134 158 327 minecraft:stone
setblock 134 158 328 minecraft:stripped_spruce_log
fill 134 158 331 134 158 332 minecraft:stone
setblock 134 158 333 minecraft:stripped_spruce_log
fill 134 158 334 134 158 337 minecraft:stone
setblock 134 158 338 minecraft:stripped_spruce_log
fill 134 158 339 134 161 339 minecraft:stone
setblock 134 158 342 minecraft:stone
setblock 134 158 343 minecraft:stripped_spruce_log
fill 134 158 354 134 158 357 minecraft:stone
setblock 134 158 358 minecraft:stripped_spruce_log
fill 134 158 359 134 161 359 minecraft:stone
setblock 134 158 363 minecraft:stripped_spruce_log
fill 135 158 323 135 161 323 minecraft:stone
setblock 135 158 327 minecraft:stripped_spruce_log
fill 135 158 328 135 158 331 minecraft:stone
setblock 135 158 332 minecraft:stripped_spruce_log
fill 135 158 333 135 158 336 minecraft:stone
setblock 135 158 337 minecraft:stripped_spruce_log
fill 135 158 338 135 161 338 minecraft:stone
setblock 135 158 342 minecraft:stripped_spruce_log
fill 135 158 343 135 161 343 minecraft:stone
setblock 135 158 346 minecraft:stone
setblock 135 158 347 minecraft:stripped_spruce_log
fill 135 158 348 135 158 351 minecraft:stone
setblock 135 158 352 minecraft:stripped_spruce_log
fill 135 158 353 135 158 356 minecraft:stone
setblock 135 158 357 minecraft:stripped_spruce_log
fill 135 158 358 135 161 358 minecraft:stone
setblock 135 158 362 minecraft:stripped_spruce_log
fill 135 158 363 135 161 363 minecraft:stone
fill 136 158 344 136 186 344 minecraft:deepslate
setblock 95 159 326 minecraft:stripped_spruce_log
fill 95 159 327 95 159 330 minecraft:stone
setblock 95 159 331 minecraft:stripped_spruce_log
fill 95 159 332 95 159 335 minecraft:stone
setblock 95 159 336 minecraft:stripped_spruce_log
fill 95 159 337 95 159 340 minecraft:stone
setblock 95 159 341 minecraft:stripped_spruce_log
fill 95 159 342 95 159 345 minecraft:stone
setblock 95 159 346 minecraft:stripped_spruce_log
fill 95 159 347 95 159 350 minecraft:stone
setblock 95 159 351 minecraft:stripped_spruce_log
fill 95 159 352 95 159 355 minecraft:stone
setblock 95 159 356 minecraft:stripped_spruce_log
fill 95 159 357 95 159 360 minecraft:stone
setblock 95 159 361 minecraft:stripped_spruce_log
fill 95 159 362 97 159 363 minecraft:stone
setblock 96 159 324 minecraft:stone
setblock 96 159 334 minecraft:stone
setblock 96 159 335 minecraft:stripped_spruce_log
fill 96 159 336 96 159 339 minecraft:stone
setblock 96 159 340 minecraft:stripped_spruce_log
fill 96 159 341 96 159 344 minecraft:stone
setblock 96 159 345 minecraft:stripped_spruce_log
fill 96 159 346 96 159 349 minecraft:stone
setblock 96 159 350 minecraft:stripped_spruce_log
fill 96 159 351 96 159 354 minecraft:stone
setblock 96 159 355 minecraft:stripped_spruce_log
fill 96 159 356 96 159 359 minecraft:stone
setblock 96 159 360 minecraft:stripped_spruce_log
fill 96 159 361 96 162 361 minecraft:stone
setblock 97 159 323 minecraft:stone
fill 97 159 337 97 159 338 minecraft:stone
setblock 97 159 339 minecraft:stripped_spruce_log
fill 97 159 340 97 162 340 minecraft:stone
setblock 97 159 344 minecraft:stripped_spruce_log
fill 97 159 345 97 161 346 minecraft:stone
fill 97 159 352 97 159 353 minecraft:stone
setblock 97 159 354 minecraft:stripped_spruce_log
fill 97 159 355 97 159 358 minecraft:stone
setblock 97 159 359 minecraft:stripped_spruce_log
fill 97 159 360 97 162 360 minecraft:stone
setblock 98 159 323 minecraft:stripped_spruce_log
setblock 98 159 357 minecraft:stone
setblock 98 159 358 minecraft:stripped_spruce_log
fill 98 159 359 98 160 359 minecraft:stone
setblock 98 159 362 minecraft:stone
setblock 98 159 363 minecraft:stripped_spruce_log
fill 99 159 323 99 162 323 minecraft:stone
setblock 99 159 361 minecraft:stone
setblock 99 159 362 minecraft:stripped_spruce_log
fill 99 159 363 99 162 363 minecraft:stone
setblock 100 159 361 minecraft:stripped_spruce_log
fill 100 159 362 100 162 362 minecraft:stone
setblock 101 159 361 minecraft:stone
setblock 102 159 363 minecraft:stone
setblock 103 159 363 minecraft:stripped_spruce_log
setblock 104 159 322 minecraft:gold_block
fill 104 159 363 104 162 363 minecraft:stone
setblock 107 159 363 minecraft:stone
setblock 108 159 363 minecraft:stripped_spruce_log
fill 109 159 363 112 159 363 minecraft:stone
fill 110 159 323 112 159 323 minecraft:stone
fill 110 159 362 113 159 362 minecraft:stone
setblock 113 159 323 minecraft:stripped_spruce_log
fill 113 159 324 116 159 324 minecraft:stone
setblock 113 159 363 minecraft:stripped_spruce_log
fill 114 159 323 117 159 323 minecraft:stone
setblock 114 159 361 minecraft:stone
setblock 114 159 362 minecraft:stripped_spruce_log
fill 114 159 363 117 159 363 minecraft:stone
setblock 115 159 361 minecraft:stripped_spruce_log
fill 115 159 362 115 162 362 minecraft:stone
fill 116 159 361 117 159 361 minecraft:stone
setblock 117 159 324 minecraft:stripped_spruce_log
setblock 118 159 323 minecraft:stripped_spruce_log
fill 118 159 324 118 162 324 minecraft:stone
setblock 118 159 363 minecraft:stripped_spruce_log
fill 119 159 323 119 162 323 minecraft:stone
setblock 119 159 362 minecraft:stripped_spruce_log
fill 119 159 363 119 162 363 minecraft:stone
fill 120 159 362 120 162 362 minecraft:stone
setblock 121 159 324 minecraft:stone
setblock 122 159 323 minecraft:stone
setblock 122 159 324 minecraft:stripped_spruce_log
fill 122 159 362 122 160 362 minecraft:stone
setblock 123 159 323 minecraft:stripped_spruce_log
setblock 123 159 363 minecraft:stripped_spruce_log
fill 124 159 323 127 159 323 minecraft:stone
fill 124 159 363 127 159 363 minecraft:stone
fill 124 159 364 124 187 364 minecraft:deepslate
fill 126 159 362 128 159 362 minecraft:stone
fill 127 159 364 127 186 364 minecraft:deepslate
setblock 128 159 323 minecraft:stripped_spruce_log
fill 128 159 324 131 159 324 minecraft:stone
setblock 128 159 363 minecraft:stripped_spruce_log
fill 129 159 323 132 159 323 minecraft:stone
fill 129 159 326 130 160 326 minecraft:raw_gold_block
setblock 129 159 362 minecraft:stripped_spruce_log
fill 129 159 363 132 159 363 minecraft:stone
setblock 130 159 361 minecraft:stripped_spruce_log
fill 130 159 362 130 162 362 minecraft:stone
fill 131 159 361 131 162 361 minecraft:stone
setblock 132 159 324 minecraft:stripped_spruce_log
fill 132 159 360 132 162 360 minecraft:stone
setblock 133 159 323 minecraft:stripped_spruce_log
fill 133 159 324 133 161 325 minecraft:stone
fill 133 159 339 133 161 339 minecraft:stone
fill 133 159 356 133 159 357 minecraft:stone
setblock 133 159 358 minecraft:stripped_spruce_log
fill 133 159 359 133 162 359 minecraft:stone
setblock 133 159 362 minecraft:stone
setblock 133 159 363 minecraft:stripped_spruce_log
fill 134 159 323 134 162 323 minecraft:stone
fill 134 159 325 134 159 326 minecraft:stone
setblock 134 159 327 minecraft:stripped_spruce_log
fill 134 159 328 134 159 331 minecraft:stone
setblock 134 159 332 minecraft:stripped_spruce_log
fill 134 159 333 134 159 336 minecraft:stone
setblock 134 159 337 minecraft:stripped_spruce_log
fill 134 159 338 134 162 338 minecraft:stone
fill 134 159 340 134 159 341 minecraft:stone
setblock 134 159 342 minecraft:stripped_spruce_log
fill 134 159 343 134 161 344 minecraft:stone
fill 134 159 353 134 159 356 minecraft:stone
setblock 134 159 357 minecraft:stripped_spruce_log
fill 134 159 358 134 162 358 minecraft:stone
setblock 134 159 361 minecraft:stone
setblock 134 159 362 minecraft:stripped_spruce_log
fill 134 159 363 134 162 363 minecraft:stone
setblock 135 159 325 minecraft:stone
setblock 135 159 326 minecraft:stripped_spruce_log
fill 135 159 327 135 159 330 minecraft:stone
setblock 135 159 331 minecraft:stripped_spruce_log
fill 135 159 332 135 159 335 minecraft:stone
setblock 135 159 336 minecraft:stripped_spruce_log
fill 135 159 337 135 162 337 minecraft:stone
setblock 135 159 340 minecraft:stone
setblock 135 159 341 minecraft:stripped_spruce_log
fill 135 159 342 135 162 342 minecraft:stone
setblock 135 159 346 minecraft:stripped_spruce_log
fill 135 159 347 135 159 350 minecraft:stone
setblock 135 159 351 minecraft:stripped_spruce_log
fill 135 159 352 135 159 355 minecraft:stone
setblock 135 159 356 minecraft:stripped_spruce_log
fill 135 159 357 135 162 357 minecraft:stone
setblock 135 159 361 minecraft:stripped_spruce_log
fill 135 159 362 135 162 362 minecraft:stone
setblock 94 160 344 minecraft:diamond_block
setblock 95 160 325 minecraft:stripped_spruce_log
fill 95 160 326 95 160 329 minecraft:stone
setblock 95 160 330 minecraft:stripped_spruce_log
fill 95 160 331 95 160 334 minecraft:stone
setblock 95 160 335 minecraft:stripped_spruce_log
fill 95 160 336 95 160 339 minecraft:stone
setblock 95 160 340 minecraft:stripped_spruce_log
fill 95 160 341 95 160 344 minecraft:stone
setblock 95 160 345 minecraft:stripped_spruce_log
fill 95 160 346 95 160 349 minecraft:stone
setblock 95 160 350 minecraft:stripped_spruce_log
fill 95 160 351 95 160 354 minecraft:stone
setblock 95 160 355 minecraft:stripped_spruce_log
fill 95 160 356 95 160 359 minecraft:stone
setblock 95 160 360 minecraft:stripped_spruce_log
fill 95 160 361 95 161 363 minecraft:stone
setblock 96 160 324 minecraft:stripped_spruce_log
fill 96 160 335 96 160 338 minecraft:stone
setblock 96 160 339 minecraft:stripped_spruce_log
fill 96 160 340 96 160 343 minecraft:stone
setblock 96 160 344 minecraft:stripped_spruce_log
fill 96 160 345 96 160 348 minecraft:stone
setblock 96 160 349 minecraft:stripped_spruce_log
fill 96 160 350 96 160 353 minecraft:stone
setblock 96 160 354 minecraft:stripped_spruce_log
fill 96 160 355 96 160 358 minecraft:stone
setblock 96 160 359 minecraft:stripped_spruce_log
fill 96 160 360 96 163 360 minecraft:stone
fill 96 160 362 96 160 363 minecraft:stone
setblock 97 160 323 minecraft:stripped_spruce_log
fill 97 160 324 97 161 324 minecraft:stone
setblock 97 160 338 minecraft:stripped_spruce_log
fill 97 160 339 97 162 339 minecraft:stone
fill 97 160 341 97 160 342 minecraft:stone
setblock 97 160 343 minecraft:stripped_spruce_log
fill 97 160 344 97 163 344 minecraft:stone
setblock 97 160 347 minecraft:stone
setblock 97 160 353 minecraft:stripped_spruce_log
fill 97 160 354 97 160 357 minecraft:stone
setblock 97 160 358 minecraft:stripped_spruce_log
fill 97 160 359 97 162 359 minecraft:stone
setblock 97 160 362 minecraft:stone
setblock 97 160 363 minecraft:stripped_spruce_log
fill 98 160 323 98 163 323 minecraft:stone
setblock 98 160 362 minecraft:stripped_spruce_log
fill 98 160 363 98 163 363 minecraft:stone
setblock 99 160 361 minecraft:stripped_spruce_log
fill 99 160 362 99 163 362 minecraft:stone
setblock 100 160 361 minecraft:stone
setblock 102 160 363 minecraft:stripped_spruce_log
setblock 103 160 362 minecraft:stripped_spruce_log
fill 103 160 363 103 163 363 minecraft:stone
fill 104 160 322 104 182 322 minecraft:deepslate
setblock 107 160 363 minecraft:stripped_spruce_log
fill 108 160 363 111 160 363 minecraft:stone
fill 109 160 323 111 160 323 minecraft:stone
fill 109 160 362 112 160 362 minecraft:stone
setblock 111 160 324 minecraft:stripped_spruce_log
setblock 112 160 323 minecraft:stripped_spruce_log
fill 112 160 324 115 160 324 minecraft:stone
setblock 112 160 363 minecraft:stripped_spruce_log
fill 113 160 323 116 160 323 minecraft:stone
setblock 113 160 361 minecraft:stone
setblock 113 160 362 minecraft:stripped_spruce_log
fill 113 160 363 116 160 363 minecraft:stone
setblock 114 160 361 minecraft:stripped_spruce_log
fill 114 160 362 114 163 362 minecraft:stone
setblock 115 160 325 minecraft:stripped_spruce_log
fill 115 160 361 116 160 361 minecraft:stone
setblock 116 160 324 minecraft:stripped_spruce_log
fill 116 160 325 117 162 325 minecraft:stone
setblock 117 160 323 minecraft:stripped_spruce_log
fill 117 160 324 117 163 324 minecraft:stone
setblock 117 160 363 minecraft:stripped_spruce_log
fill 118 160 323 118 163 323 minecraft:stone
setblock 118 160 362 minecraft:stripped_spruce_log
fill 118 160 363 118 163 363 minecraft:stone
fill 119 160 362 119 162 362 minecraft:stone
setblock 121 160 324 minecraft:stripped_spruce_log
setblock 122 160 323 minecraft:stripped_spruce_log
fill 122 160 324 125 160 324 minecraft:stone
setblock 122 160 363 minecraft:stripped_spruce_log
fill 123 160 323 126 160 323 minecraft:stone
fill 123 160 363 126 160 363 minecraft:stone
fill 125 160 362 127 160 362 minecraft:stone
setblock 126 160 324 minecraft:stripped_spruce_log
setblock 127 160 323 minecraft:stripped_spruce_log
fill 127 160 324 130 160 324 minecraft:stone
setblock 127 160 363 minecraft:stripped_spruce_log
fill 128 160 323 131 160 323 minecraft:stone
setblock 128 160 326 minecraft:raw_gold_block
setblock 128 160 362 minecraft:stripped_spruce_log
fill 128 160 363 131 160 363 minecraft:stone
setblock 129 160 345 minecraft:stripped_spruce_log
setblock 129 160 347 minecraft:stripped_spruce_log
setblock 129 160 361 minecraft:stripped_spruce_log
fill 129 160 362 129 163 362 minecraft:stone
fill 130 160 361 130 163 361 minecraft:stone
setblock 131 160 324 minecraft:stripped_spruce_log
fill 131 160 325 132 162 325 minecraft:stone
setblock 131 160 345 minecraft:stripped_spruce_log
setblock 131 160 347 minecraft:stripped_spruce_log
setblock 132 160 323 minecraft:stripped_spruce_log
fill 132 160 324 132 163 324 minecraft:stone
fill 132 160 359 132 161 359 minecraft:stone
setblock 132 160 363 minecraft:stripped_spruce_log
fill 133 160 323 133 163 323 minecraft:stone
setblock 133 160 338 minecraft:stone
fill 133 160 340 133 160 341 minecraft:stone
setblock 133 160 356 minecraft:stone
setblock 133 160 357 minecraft:stripped_spruce_log
fill 133 160 358 133 163 358 minecraft:stone
setblock 133 160 362 minecraft:stripped_spruce_log
fill 133 160 363 133 163 363 minecraft:stone
setblock 134 160 325 minecraft:stone
setblock 134 160 326 minecraft:stripped_spruce_log
fill 134 160 327 134 160 330 minecraft:stone
fill 134 160 332 134 160 335 minecraft:stone
setblock 134 160 336 minecraft:stripped_spruce_log
fill 134 160 337 134 162 337 minecraft:stone
setblock 134 160 340 minecraft:stone
setblock 134 160 341 minecraft:stripped_spruce_log
fill 134 160 342 134 163 342 minecraft:stone
setblock 134 160 345 minecraft:stone
setblock 134 160 346 minecraft:stripped_spruce_log
fill 134 160 353 134 160 355 minecraft:stone
setblock 134 160 356 minecraft:stripped_spruce_log
fill 134 160 357 134 163 357 minecraft:stone
setblock 134 160 361 minecraft:stripped_spruce_log
fill 134 160 362 134 163 362 minecraft:stone
setblock 135 160 325 minecraft:stripped_spruce_log
fill 135 160 326 135 160 329 minecraft:stone
setblock 135 160 330 minecraft:stripped_spruce_log
fill 135 160 331 135 160 334 minecraft:stone
setblock 135 160 335 minecraft:stripped_spruce_log
fill 135 160 336 135 163 336 minecraft:stone
setblock 135 160 340 minecraft:stripped_spruce_log
fill 135 160 341 135 163 341 minecraft:stone
setblock 135 160 344 minecraft:stone
setblock 135 160 345 minecraft:stripped_spruce_log
fill 135 160 346 135 160 349 minecraft:stone
setblock 135 160 350 minecraft:stripped_spruce_log
fill 135 160 351 135 160 354 minecraft:stone
setblock 135 160 355 minecraft:stripped_spruce_log
fill 135 160 356 135 163 356 minecraft:stone
setblock 135 160 360 minecraft:stripped_spruce_log
fill 135 160 361 135 163 361 minecraft:stone
fill 94 161 344 94 186 344 minecraft:deepslate
setblock 95 161 324 minecraft:stripped_spruce_log
fill 95 161 325 95 161 328 minecraft:stone
setblock 95 161 329 minecraft:stripped_spruce_log
fill 95 161 332 95 161 333 minecraft:stone
setblock 95 161 334 minecraft:stripped_spruce_log
fill 95 161 335 95 161 338 minecraft:stone
setblock 95 161 339 minecraft:stripped_spruce_log
fill 95 161 340 95 161 343 minecraft:stone
setblock 95 161 344 minecraft:stripped_spruce_log
fill 95 161 345 95 161 348 minecraft:stone
setblock 95 161 349 minecraft:stripped_spruce_log
fill 95 161 350 95 161 353 minecraft:stone
setblock 95 161 354 minecraft:stripped_spruce_log
fill 95 161 355 95 161 358 minecraft:stone
setblock 95 161 359 minecraft:stripped_spruce_log
fill 95 161 360 95 164 360 minecraft:stone
setblock 96 161 323 minecraft:stripped_spruce_log
fill 96 161 324 96 161 325 minecraft:stone
fill 96 161 336 96 161 337 minecraft:stone
setblock 96 161 338 minecraft:stripped_spruce_log
fill 96 161 339 96 161 342 minecraft:stone
setblock 96 161 343 minecraft:stripped_spruce_log
fill 96 161 344 96 161 347 minecraft:stone
setblock 96 161 348 minecraft:stripped_spruce_log
fill 96 161 349 96 161 352 minecraft:stone
setblock 96 161 353 minecraft:stripped_spruce_log
fill 96 161 354 96 161 357 minecraft:stone
setblock 96 161 358 minecraft:stripped_spruce_log
fill 96 161 359 96 164 359 minecraft:stone
setblock 96 161 362 minecraft:stone
setblock 96 161 363 minecraft:stripped_spruce_log
fill 97 161 323 97 164 323 minecraft:stone
setblock 97 161 338 minecraft:stone
setblock 97 161 341 minecraft:stone
setblock 97 161 342 minecraft:stripped_spruce_log
fill 97 161 343 97 164 343 minecraft:stone
setblock 97 161 347 minecraft:stripped_spruce_log
fill 97 161 348 97 162 348 minecraft:stone
fill 97 161 355 97 161 356 minecraft:stone
setblock 97 161 357 minecraft:stripped_spruce_log
fill 97 161 358 97 162 358 minecraft:stone
setblock 97 161 362 minecraft:stripped_spruce_log
fill 97 161 363 97 164 363 minecraft:stone
fill 98 161 328 99 162 328 minecraft:cobbled_deepslate
setblock 98 161 361 minecraft:stripped_spruce_log
fill 98 161 362 98 164 362 minecraft:stone
setblock 99 161 361 minecraft:stone
setblock 101 161 363 minecraft:stripped_spruce_log
setblock 102 161 322 minecraft:diamond_block
setblock 102 161 362 minecraft:stripped_spruce_log
fill 102 161 363 102 163 363 minecraft:stone
setblock 105 161 363 minecraft:stone
setblock 106 161 363 minecraft:stripped_spruce_log
fill 107 161 323 110 161 323 minecraft:stone
fill 107 161 357 107 162 357 minecraft:cobbled_deepslate
fill 107 161 363 110 161 363 minecraft:stone
setblock 108 161 364 minecraft:raw_gold_block
fill 109 161 328 109 162 328 minecraft:cobbled_deepslate
fill 109 161 362 111 161 362 minecraft:stone
fill 109 161 364 109 186 364 minecraft:deepslate
setblock 110 161 324 minecraft:stripped_spruce_log
setblock 111 161 323 minecraft:stripped_spruce_log
fill 111 161 324 114 161 324 minecraft:stone
setblock 111 161 363 minecraft:stripped_spruce_log
fill 112 161 323 115 161 323 minecraft:stone
setblock 112 161 362 minecraft:stripped_spruce_log
fill 112 161 363 115 161 363 minecraft:stone
setblock 113 161 361 minecraft:stripped_spruce_log
fill 113 161 362 113 164 362 minecraft:stone
setblock 114 161 325 minecraft:stripped_spruce_log
fill 114 161 361 115 161 361 minecraft:stone
setblock 115 161 324 minecraft:stripped_spruce_log
fill 115 161 325 115 164 325 minecraft:stone
setblock 116 161 323 minecraft:stripped_spruce_log
fill 116 161 324 116 164 324 minecraft:stone
setblock 116 161 363 minecraft:stripped_spruce_log
fill 117 161 323 117 164 323 minecraft:stone
setblock 117 161 362 minecraft:stripped_spruce_log
fill 117 161 363 117 164 363 minecraft:stone
setblock 118 161 325 minecraft:stone
fill 118 161 362 118 163 362 minecraft:stone
setblock 119 161 324 minecraft:stone
setblock 120 161 324 minecraft:stripped_spruce_log
fill 120 161 357 120 162 357 minecraft:cobbled_deepslate
setblock 121 161 323 minecraft:stripped_spruce_log
fill 121 161 324 124 161 324 minecraft:stone
setblock 121 161 363 minecraft:stripped_spruce_log
fill 122 161 323 125 161 323 minecraft:stone
fill 122 161 363 125 161 363 minecraft:stone
fill 124 161 362 126 161 362 minecraft:stone
setblock 125 161 324 minecraft:stripped_spruce_log
setblock 126 161 323 minecraft:stripped_spruce_log
fill 126 161 324 129 161 324 minecraft:stone
setblock 126 161 363 minecraft:stripped_spruce_log
schedule function dropper:buildpart/74_4 1t
