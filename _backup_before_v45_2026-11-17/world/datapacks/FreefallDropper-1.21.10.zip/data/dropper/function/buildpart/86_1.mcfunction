fill 99 146 381 99 146 382 minecraft:orange_concrete
fill 99 146 384 99 146 385 minecraft:orange_concrete
fill 99 146 387 99 146 388 minecraft:orange_concrete
fill 99 146 390 99 146 391 minecraft:orange_concrete
fill 99 146 393 99 146 394 minecraft:orange_concrete
fill 99 146 396 99 146 397 minecraft:orange_concrete
fill 99 146 399 99 146 400 minecraft:orange_concrete
fill 99 146 402 99 146 403 minecraft:orange_concrete
fill 99 146 405 99 146 406 minecraft:orange_concrete
fill 99 146 408 99 146 409 minecraft:orange_concrete
fill 100 146 370 101 146 370 minecraft:netherite_block
fill 100 146 372 101 146 373 minecraft:black_concrete
fill 100 146 375 101 146 376 minecraft:netherite_block
fill 100 146 378 101 146 379 minecraft:black_concrete
fill 100 146 381 101 146 382 minecraft:netherite_block
fill 100 146 384 101 146 385 minecraft:black_concrete
fill 100 146 387 101 146 388 minecraft:netherite_block
fill 100 146 390 101 146 391 minecraft:black_concrete
fill 100 146 393 101 146 394 minecraft:netherite_block
fill 100 146 396 101 146 397 minecraft:black_concrete
fill 100 146 399 101 146 400 minecraft:netherite_block
fill 100 146 402 101 146 403 minecraft:black_concrete
fill 100 146 405 101 146 406 minecraft:netherite_block
fill 100 146 408 101 146 409 minecraft:black_concrete
setblock 102 146 370 minecraft:orange_concrete
fill 102 146 372 102 146 373 minecraft:orange_concrete
fill 102 146 375 102 146 376 minecraft:orange_concrete
fill 102 146 378 102 146 379 minecraft:orange_concrete
fill 102 146 381 102 146 382 minecraft:orange_concrete
fill 102 146 384 102 146 385 minecraft:orange_concrete
fill 102 146 387 102 146 388 minecraft:orange_concrete
fill 102 146 390 102 146 391 minecraft:orange_concrete
fill 102 146 393 102 146 394 minecraft:orange_concrete
fill 102 146 396 102 146 397 minecraft:orange_concrete
fill 102 146 399 102 146 400 minecraft:orange_concrete
fill 102 146 402 102 146 403 minecraft:orange_concrete
fill 102 146 405 102 146 406 minecraft:orange_concrete
fill 102 146 408 102 146 409 minecraft:orange_concrete
fill 103 146 370 104 146 370 minecraft:black_concrete
fill 103 146 372 104 146 373 minecraft:netherite_block
fill 103 146 375 104 146 376 minecraft:black_concrete
fill 103 146 378 104 146 379 minecraft:netherite_block
fill 103 146 381 104 146 382 minecraft:black_concrete
fill 103 146 384 104 146 385 minecraft:netherite_block
fill 103 146 387 104 146 388 minecraft:black_concrete
fill 103 146 390 104 146 391 minecraft:netherite_block
fill 103 146 393 104 146 394 minecraft:black_concrete
fill 103 146 396 104 146 397 minecraft:netherite_block
fill 103 146 399 104 146 400 minecraft:black_concrete
fill 103 146 402 104 146 403 minecraft:netherite_block
fill 103 146 405 104 146 406 minecraft:black_concrete
fill 103 146 408 104 146 409 minecraft:netherite_block
setblock 105 146 370 minecraft:orange_concrete
fill 105 146 372 105 146 373 minecraft:orange_concrete
fill 105 146 375 105 146 376 minecraft:orange_concrete
fill 105 146 378 105 146 379 minecraft:orange_concrete
fill 105 146 381 105 146 382 minecraft:orange_concrete
fill 105 146 384 105 146 385 minecraft:orange_concrete
fill 105 146 387 105 146 388 minecraft:orange_concrete
fill 105 146 390 105 146 391 minecraft:orange_concrete
fill 105 146 393 105 146 394 minecraft:orange_concrete
fill 105 146 396 105 146 397 minecraft:orange_concrete
fill 105 146 399 105 146 400 minecraft:orange_concrete
fill 105 146 402 105 146 403 minecraft:orange_concrete
fill 105 146 405 105 146 406 minecraft:orange_concrete
fill 105 146 408 105 146 409 minecraft:orange_concrete
fill 106 146 370 107 146 370 minecraft:netherite_block
fill 106 146 372 107 146 373 minecraft:black_concrete
fill 106 146 375 107 146 376 minecraft:netherite_block
fill 106 146 378 107 146 379 minecraft:black_concrete
fill 106 146 381 107 146 382 minecraft:netherite_block
fill 106 146 384 107 146 385 minecraft:black_concrete
fill 106 146 387 107 146 388 minecraft:netherite_block
fill 106 146 390 107 146 391 minecraft:black_concrete
fill 106 146 393 107 146 394 minecraft:netherite_block
fill 106 146 396 107 146 397 minecraft:black_concrete
fill 106 146 399 107 146 400 minecraft:netherite_block
fill 106 146 402 107 146 403 minecraft:black_concrete
fill 106 146 405 107 146 406 minecraft:netherite_block
fill 106 146 408 107 146 409 minecraft:black_concrete
setblock 108 146 370 minecraft:orange_concrete
fill 108 146 372 108 146 373 minecraft:orange_concrete
fill 108 146 375 108 146 376 minecraft:orange_concrete
fill 108 146 378 108 146 379 minecraft:orange_concrete
fill 108 146 381 108 146 382 minecraft:orange_concrete
fill 108 146 384 108 146 385 minecraft:orange_concrete
fill 108 146 387 108 146 388 minecraft:orange_concrete
fill 108 146 390 108 146 391 minecraft:orange_concrete
setblock 108 146 393 minecraft:shroomlight
fill 108 146 394 108 146 396 minecraft:ochre_froglight
setblock 108 146 397 minecraft:shroomlight
fill 108 146 399 108 146 400 minecraft:orange_concrete
fill 108 146 402 108 146 403 minecraft:orange_concrete
fill 108 146 405 108 146 406 minecraft:orange_concrete
fill 108 146 408 108 146 409 minecraft:orange_concrete
fill 109 146 370 110 146 370 minecraft:black_concrete
fill 109 146 372 110 146 373 minecraft:netherite_block
fill 109 146 375 110 146 376 minecraft:black_concrete
fill 109 146 378 110 146 379 minecraft:netherite_block
fill 109 146 381 110 146 382 minecraft:black_concrete
fill 109 146 384 110 146 385 minecraft:netherite_block
fill 109 146 387 110 146 388 minecraft:black_concrete
fill 109 146 390 110 146 391 minecraft:netherite_block
setblock 109 146 392 minecraft:shroomlight
setblock 109 146 393 minecraft:ochre_froglight
setblock 109 146 397 minecraft:ochre_froglight
setblock 109 146 398 minecraft:shroomlight
fill 109 146 399 110 146 400 minecraft:black_concrete
fill 109 146 402 110 146 403 minecraft:netherite_block
fill 109 146 405 110 146 406 minecraft:black_concrete
fill 109 146 408 110 146 409 minecraft:netherite_block
fill 110 146 392 112 146 392 minecraft:ochre_froglight
fill 110 146 398 112 146 398 minecraft:ochre_froglight
setblock 111 146 370 minecraft:orange_concrete
fill 111 146 372 111 146 373 minecraft:orange_concrete
fill 111 146 375 111 146 376 minecraft:orange_concrete
fill 111 146 378 111 146 379 minecraft:orange_concrete
fill 111 146 381 111 146 382 minecraft:orange_concrete
fill 111 146 384 111 146 385 minecraft:orange_concrete
fill 111 146 387 111 146 388 minecraft:orange_concrete
fill 111 146 390 111 146 391 minecraft:orange_concrete
fill 111 146 399 111 146 400 minecraft:orange_concrete
fill 111 146 402 111 146 403 minecraft:orange_concrete
fill 111 146 405 111 146 406 minecraft:orange_concrete
fill 111 146 408 111 146 409 minecraft:orange_concrete
fill 112 146 370 113 146 370 minecraft:netherite_block
fill 112 146 372 113 146 373 minecraft:black_concrete
fill 112 146 375 113 146 376 minecraft:netherite_block
fill 112 146 378 113 146 379 minecraft:black_concrete
fill 112 146 381 113 146 382 minecraft:netherite_block
fill 112 146 384 113 146 385 minecraft:black_concrete
fill 112 146 387 113 146 388 minecraft:netherite_block
fill 112 146 390 113 146 391 minecraft:black_concrete
fill 112 146 399 113 146 400 minecraft:netherite_block
fill 112 146 402 113 146 403 minecraft:black_concrete
fill 112 146 405 113 146 406 minecraft:netherite_block
fill 112 146 408 113 146 409 minecraft:black_concrete
setblock 113 146 392 minecraft:shroomlight
setblock 113 146 393 minecraft:ochre_froglight
setblock 113 146 397 minecraft:ochre_froglight
setblock 113 146 398 minecraft:shroomlight
setblock 114 146 370 minecraft:orange_concrete
fill 114 146 372 114 146 373 minecraft:orange_concrete
fill 114 146 375 114 146 376 minecraft:orange_concrete
fill 114 146 378 114 146 379 minecraft:orange_concrete
fill 114 146 381 114 146 382 minecraft:orange_concrete
fill 114 146 384 114 146 385 minecraft:orange_concrete
fill 114 146 387 114 146 388 minecraft:orange_concrete
fill 114 146 390 114 146 392 minecraft:orange_concrete
setblock 114 146 393 minecraft:shroomlight
fill 114 146 394 114 146 396 minecraft:ochre_froglight
setblock 114 146 397 minecraft:shroomlight
fill 114 146 398 114 146 400 minecraft:orange_concrete
fill 114 146 402 114 146 403 minecraft:orange_concrete
fill 114 146 405 114 146 406 minecraft:orange_concrete
fill 114 146 408 114 146 409 minecraft:orange_concrete
fill 115 146 370 116 146 370 minecraft:black_concrete
fill 115 146 372 116 146 373 minecraft:netherite_block
fill 115 146 375 116 146 376 minecraft:black_concrete
fill 115 146 378 116 146 379 minecraft:netherite_block
fill 115 146 381 116 146 382 minecraft:black_concrete
fill 115 146 384 116 146 385 minecraft:netherite_block
fill 115 146 387 116 146 388 minecraft:black_concrete
fill 115 146 390 116 146 391 minecraft:netherite_block
fill 115 146 392 135 146 392 minecraft:orange_concrete
fill 115 146 393 116 146 394 minecraft:black_concrete
fill 115 146 395 135 146 395 minecraft:orange_concrete
fill 115 146 396 116 146 397 minecraft:netherite_block
fill 115 146 398 135 146 398 minecraft:orange_concrete
fill 115 146 399 116 146 400 minecraft:black_concrete
fill 115 146 402 116 146 403 minecraft:netherite_block
fill 115 146 405 116 146 406 minecraft:black_concrete
fill 115 146 408 116 146 409 minecraft:netherite_block
setblock 117 146 370 minecraft:orange_concrete
fill 117 146 372 117 146 373 minecraft:orange_concrete
fill 117 146 375 117 146 376 minecraft:orange_concrete
fill 117 146 378 117 146 379 minecraft:orange_concrete
fill 117 146 381 117 146 382 minecraft:orange_concrete
fill 117 146 384 117 146 385 minecraft:orange_concrete
fill 117 146 387 117 146 388 minecraft:orange_concrete
fill 117 146 390 117 146 391 minecraft:orange_concrete
fill 117 146 393 117 146 394 minecraft:orange_concrete
fill 117 146 396 117 146 397 minecraft:orange_concrete
fill 117 146 399 117 146 400 minecraft:orange_concrete
fill 117 146 402 117 146 403 minecraft:orange_concrete
fill 117 146 405 117 146 406 minecraft:orange_concrete
fill 117 146 408 117 146 409 minecraft:orange_concrete
fill 118 146 370 119 146 370 minecraft:netherite_block
fill 118 146 372 119 146 373 minecraft:black_concrete
fill 118 146 375 119 146 376 minecraft:netherite_block
fill 118 146 378 119 146 379 minecraft:black_concrete
fill 118 146 381 119 146 382 minecraft:netherite_block
fill 118 146 384 119 146 385 minecraft:black_concrete
fill 118 146 387 119 146 388 minecraft:netherite_block
fill 118 146 390 119 146 391 minecraft:black_concrete
fill 118 146 393 119 146 394 minecraft:netherite_block
fill 118 146 396 119 146 397 minecraft:black_concrete
fill 118 146 399 119 146 400 minecraft:netherite_block
fill 118 146 402 119 146 403 minecraft:black_concrete
fill 118 146 405 119 146 406 minecraft:netherite_block
fill 118 146 408 119 146 409 minecraft:black_concrete
setblock 120 146 370 minecraft:orange_concrete
fill 120 146 372 120 146 373 minecraft:orange_concrete
fill 120 146 375 120 146 376 minecraft:orange_concrete
fill 120 146 378 120 146 379 minecraft:orange_concrete
fill 120 146 381 120 146 382 minecraft:orange_concrete
fill 120 146 384 120 146 385 minecraft:orange_concrete
fill 120 146 387 120 146 388 minecraft:orange_concrete
fill 120 146 390 120 146 391 minecraft:orange_concrete
fill 120 146 393 120 146 394 minecraft:orange_concrete
fill 120 146 396 120 146 397 minecraft:orange_concrete
fill 120 146 399 120 146 400 minecraft:orange_concrete
fill 120 146 402 120 146 403 minecraft:orange_concrete
fill 120 146 405 120 146 406 minecraft:orange_concrete
fill 120 146 408 120 146 409 minecraft:orange_concrete
fill 121 146 370 122 146 370 minecraft:black_concrete
fill 121 146 372 122 146 373 minecraft:netherite_block
fill 121 146 375 122 146 376 minecraft:black_concrete
fill 121 146 378 122 146 379 minecraft:netherite_block
fill 121 146 381 122 146 382 minecraft:black_concrete
fill 121 146 384 122 146 385 minecraft:netherite_block
fill 121 146 387 122 146 388 minecraft:black_concrete
fill 121 146 390 122 146 391 minecraft:netherite_block
fill 121 146 393 122 146 394 minecraft:black_concrete
fill 121 146 396 122 146 397 minecraft:netherite_block
fill 121 146 399 122 146 400 minecraft:black_concrete
fill 121 146 402 122 146 403 minecraft:netherite_block
fill 121 146 405 122 146 406 minecraft:black_concrete
fill 121 146 408 122 146 409 minecraft:netherite_block
setblock 123 146 370 minecraft:orange_concrete
fill 123 146 372 123 146 373 minecraft:orange_concrete
fill 123 146 375 123 146 376 minecraft:orange_concrete
fill 123 146 378 123 146 379 minecraft:orange_concrete
fill 123 146 381 123 146 382 minecraft:orange_concrete
fill 123 146 384 123 146 385 minecraft:orange_concrete
fill 123 146 387 123 146 388 minecraft:orange_concrete
fill 123 146 390 123 146 391 minecraft:orange_concrete
fill 123 146 393 123 146 394 minecraft:orange_concrete
fill 123 146 396 123 146 397 minecraft:orange_concrete
fill 123 146 399 123 146 400 minecraft:orange_concrete
fill 123 146 402 123 146 403 minecraft:orange_concrete
fill 123 146 405 123 146 406 minecraft:orange_concrete
fill 123 146 408 123 146 409 minecraft:orange_concrete
fill 124 146 370 125 146 370 minecraft:netherite_block
fill 124 146 372 125 146 373 minecraft:black_concrete
fill 124 146 375 125 146 376 minecraft:netherite_block
fill 124 146 378 125 146 379 minecraft:black_concrete
fill 124 146 381 125 146 382 minecraft:netherite_block
fill 124 146 384 125 146 385 minecraft:black_concrete
fill 124 146 387 125 146 388 minecraft:netherite_block
fill 124 146 390 125 146 391 minecraft:black_concrete
fill 124 146 393 125 146 394 minecraft:netherite_block
fill 124 146 396 125 146 397 minecraft:black_concrete
fill 124 146 399 125 146 400 minecraft:netherite_block
fill 124 146 402 125 146 403 minecraft:black_concrete
fill 124 146 405 125 146 406 minecraft:netherite_block
fill 124 146 408 125 146 409 minecraft:black_concrete
setblock 126 146 370 minecraft:orange_concrete
fill 126 146 372 126 146 373 minecraft:orange_concrete
fill 126 146 375 126 146 376 minecraft:orange_concrete
fill 126 146 378 126 146 379 minecraft:orange_concrete
fill 126 146 381 126 146 382 minecraft:orange_concrete
fill 126 146 384 126 146 385 minecraft:orange_concrete
fill 126 146 387 126 146 388 minecraft:orange_concrete
fill 126 146 390 126 146 391 minecraft:orange_concrete
fill 126 146 393 126 146 394 minecraft:orange_concrete
fill 126 146 396 126 146 397 minecraft:orange_concrete
fill 126 146 399 126 146 400 minecraft:orange_concrete
fill 126 146 402 126 146 403 minecraft:orange_concrete
fill 126 146 405 126 146 406 minecraft:orange_concrete
fill 126 146 408 126 146 409 minecraft:orange_concrete
fill 127 146 370 128 146 370 minecraft:black_concrete
fill 127 146 372 128 146 373 minecraft:netherite_block
fill 127 146 375 128 146 376 minecraft:black_concrete
fill 127 146 378 128 146 379 minecraft:netherite_block
fill 127 146 381 128 146 382 minecraft:black_concrete
fill 127 146 384 128 146 385 minecraft:netherite_block
fill 127 146 387 128 146 388 minecraft:black_concrete
fill 127 146 390 128 146 391 minecraft:netherite_block
fill 127 146 393 128 146 394 minecraft:black_concrete
fill 127 146 396 128 146 397 minecraft:netherite_block
fill 127 146 399 128 146 400 minecraft:black_concrete
fill 127 146 402 128 146 403 minecraft:netherite_block
fill 127 146 405 128 146 406 minecraft:black_concrete
fill 127 146 408 128 146 409 minecraft:netherite_block
setblock 129 146 370 minecraft:orange_concrete
fill 129 146 372 129 146 373 minecraft:orange_concrete
fill 129 146 375 129 146 376 minecraft:orange_concrete
fill 129 146 378 129 146 379 minecraft:orange_concrete
fill 129 146 381 129 146 382 minecraft:orange_concrete
fill 129 146 384 129 146 385 minecraft:orange_concrete
fill 129 146 387 129 146 388 minecraft:orange_concrete
fill 129 146 390 129 146 391 minecraft:orange_concrete
fill 129 146 393 129 146 394 minecraft:orange_concrete
fill 129 146 396 129 146 397 minecraft:orange_concrete
fill 129 146 399 129 146 400 minecraft:orange_concrete
fill 129 146 402 129 146 403 minecraft:orange_concrete
fill 129 146 405 129 146 406 minecraft:orange_concrete
fill 129 146 408 129 146 409 minecraft:orange_concrete
fill 130 146 370 131 146 370 minecraft:netherite_block
fill 130 146 372 131 146 373 minecraft:black_concrete
fill 130 146 375 131 146 376 minecraft:netherite_block
fill 130 146 378 131 146 379 minecraft:black_concrete
fill 130 146 381 131 146 382 minecraft:netherite_block
fill 130 146 384 131 146 385 minecraft:black_concrete
fill 130 146 387 131 146 388 minecraft:netherite_block
fill 130 146 390 131 146 391 minecraft:black_concrete
fill 130 146 393 131 146 394 minecraft:netherite_block
fill 130 146 396 131 146 397 minecraft:black_concrete
fill 130 146 399 131 146 400 minecraft:netherite_block
fill 130 146 402 131 146 403 minecraft:black_concrete
fill 130 146 405 131 146 406 minecraft:netherite_block
fill 130 146 408 131 146 409 minecraft:black_concrete
setblock 132 146 370 minecraft:orange_concrete
fill 132 146 372 132 146 373 minecraft:orange_concrete
fill 132 146 375 132 146 376 minecraft:orange_concrete
fill 132 146 378 132 146 379 minecraft:orange_concrete
fill 132 146 381 132 146 382 minecraft:orange_concrete
fill 132 146 384 132 146 385 minecraft:orange_concrete
fill 132 146 387 132 146 388 minecraft:orange_concrete
fill 132 146 390 132 146 391 minecraft:orange_concrete
fill 132 146 393 132 146 394 minecraft:orange_concrete
fill 132 146 396 132 146 397 minecraft:orange_concrete
fill 132 146 399 132 146 400 minecraft:orange_concrete
fill 132 146 402 132 146 403 minecraft:orange_concrete
fill 132 146 405 132 146 406 minecraft:orange_concrete
fill 132 146 408 132 146 409 minecraft:orange_concrete
fill 133 146 370 134 146 370 minecraft:black_concrete
fill 133 146 372 134 146 373 minecraft:netherite_block
fill 133 146 375 134 146 376 minecraft:black_concrete
fill 133 146 378 134 146 379 minecraft:netherite_block
fill 133 146 381 134 146 382 minecraft:black_concrete
fill 133 146 384 134 146 385 minecraft:netherite_block
fill 133 146 387 134 146 388 minecraft:black_concrete
fill 133 146 390 134 146 391 minecraft:netherite_block
fill 133 146 393 134 146 394 minecraft:black_concrete
fill 133 146 396 134 146 397 minecraft:netherite_block
fill 133 146 399 134 146 400 minecraft:black_concrete
fill 133 146 402 134 146 403 minecraft:netherite_block
fill 133 146 405 134 146 406 minecraft:black_concrete
fill 133 146 408 134 146 409 minecraft:netherite_block
setblock 135 146 370 minecraft:orange_concrete
fill 135 146 372 135 146 373 minecraft:orange_concrete
fill 135 146 375 135 146 376 minecraft:orange_concrete
fill 135 146 378 135 146 379 minecraft:orange_concrete
fill 135 146 381 135 146 382 minecraft:orange_concrete
fill 135 146 384 135 146 385 minecraft:orange_concrete
fill 135 146 387 135 146 388 minecraft:orange_concrete
fill 135 146 390 135 146 391 minecraft:orange_concrete
fill 135 146 393 135 146 394 minecraft:orange_concrete
fill 135 146 396 135 146 397 minecraft:orange_concrete
fill 135 146 399 135 146 400 minecraft:orange_concrete
fill 135 146 402 135 146 403 minecraft:orange_concrete
fill 135 146 405 135 146 406 minecraft:orange_concrete
fill 135 146 408 135 146 409 minecraft:orange_concrete
fill 98 147 386 106 155 404 minecraft:smooth_stone
fill 107 147 386 107 155 404 minecraft:oak_planks
fill 116 147 386 116 155 404 minecraft:oak_planks
fill 117 147 386 124 155 404 minecraft:smooth_stone
fill 94 150 375 94 151 378 minecraft:shroomlight
fill 94 150 387 94 151 390 minecraft:shroomlight
fill 94 150 399 94 151 402 minecraft:shroomlight
fill 94 150 411 97 151 411 minecraft:shroomlight
fill 95 150 370 97 211 370 minecraft:polished_blackstone_bricks
fill 95 150 380 95 211 382 minecraft:polished_blackstone_bricks
fill 95 150 392 95 211 394 minecraft:polished_blackstone_bricks
fill 95 150 404 95 211 406 minecraft:polished_blackstone_bricks
fill 101 150 369 104 151 369 minecraft:shroomlight
fill 101 150 410 103 211 410 minecraft:polished_blackstone_bricks
fill 106 150 411 109 151 411 minecraft:shroomlight
fill 107 150 370 109 211 370 minecraft:polished_blackstone_bricks
fill 113 150 369 116 151 369 minecraft:shroomlight
fill 113 150 410 115 211 410 minecraft:polished_blackstone_bricks
fill 118 150 411 121 151 411 minecraft:shroomlight
fill 119 150 370 121 211 370 minecraft:polished_blackstone_bricks
fill 125 150 369 128 151 369 minecraft:shroomlight
fill 125 150 410 127 211 410 minecraft:polished_blackstone_bricks
fill 130 150 411 133 151 411 minecraft:shroomlight
fill 131 150 370 133 211 370 minecraft:polished_blackstone_bricks
fill 135 150 378 135 211 380 minecraft:polished_blackstone_bricks
fill 135 150 390 135 211 392 minecraft:polished_blackstone_bricks
fill 135 150 402 135 211 404 minecraft:polished_blackstone_bricks
fill 136 150 370 136 151 373 minecraft:shroomlight
fill 136 150 382 136 151 385 minecraft:shroomlight
fill 136 150 394 136 151 397 minecraft:shroomlight
fill 136 150 406 136 151 409 minecraft:shroomlight
setblock 97 151 372 minecraft:light[level=14]
setblock 97 151 380 minecraft:light[level=14]
setblock 97 151 388 minecraft:light[level=14]
setblock 97 151 396 minecraft:light[level=14]
setblock 97 151 404 minecraft:light[level=14]
setblock 105 151 372 minecraft:light[level=14]
setblock 105 151 380 minecraft:light[level=14]
setblock 113 151 372 minecraft:light[level=14]
setblock 113 151 380 minecraft:light[level=14]
setblock 113 151 388 minecraft:light[level=14]
setblock 113 151 396 minecraft:light[level=14]
setblock 113 151 404 minecraft:light[level=14]
setblock 121 151 372 minecraft:light[level=14]
setblock 121 151 380 minecraft:light[level=14]
setblock 129 151 372 minecraft:light[level=14]
setblock 129 151 380 minecraft:light[level=14]
setblock 129 151 388 minecraft:light[level=14]
setblock 129 151 396 minecraft:light[level=14]
setblock 129 151 404 minecraft:light[level=14]
fill 94 152 375 94 165 375 minecraft:polished_blackstone
fill 94 152 376 94 152 377 minecraft:shroomlight
fill 94 152 378 94 165 378 minecraft:polished_blackstone
fill 94 152 387 94 165 387 minecraft:polished_blackstone
fill 94 152 388 94 152 389 minecraft:shroomlight
fill 94 152 390 94 165 390 minecraft:polished_blackstone
fill 94 152 399 94 165 399 minecraft:polished_blackstone
fill 94 152 400 94 152 401 minecraft:shroomlight
fill 94 152 402 94 165 402 minecraft:polished_blackstone
fill 94 152 411 94 165 411 minecraft:polished_blackstone
fill 95 152 411 96 152 411 minecraft:shroomlight
fill 97 152 411 97 165 411 minecraft:polished_blackstone
fill 101 152 369 101 165 369 minecraft:polished_blackstone
fill 102 152 369 103 152 369 minecraft:shroomlight
fill 104 152 369 104 165 369 minecraft:polished_blackstone
fill 106 152 411 106 165 411 minecraft:polished_blackstone
fill 107 152 411 108 152 411 minecraft:shroomlight
fill 109 152 411 109 165 411 minecraft:polished_blackstone
fill 113 152 369 113 165 369 minecraft:polished_blackstone
fill 114 152 369 115 152 369 minecraft:shroomlight
fill 116 152 369 116 165 369 minecraft:polished_blackstone
fill 118 152 411 118 165 411 minecraft:polished_blackstone
fill 119 152 411 120 152 411 minecraft:shroomlight
fill 121 152 411 121 165 411 minecraft:polished_blackstone
fill 125 152 369 125 165 369 minecraft:polished_blackstone
fill 126 152 369 127 152 369 minecraft:shroomlight
fill 128 152 369 128 165 369 minecraft:polished_blackstone
fill 130 152 411 130 165 411 minecraft:polished_blackstone
fill 131 152 411 132 152 411 minecraft:shroomlight
fill 133 152 411 133 165 411 minecraft:polished_blackstone
fill 136 152 370 136 165 370 minecraft:polished_blackstone
fill 136 152 371 136 152 372 minecraft:shroomlight
fill 136 152 373 136 165 373 minecraft:polished_blackstone
fill 136 152 382 136 165 382 minecraft:polished_blackstone
fill 136 152 383 136 152 384 minecraft:shroomlight
fill 136 152 385 136 165 385 minecraft:polished_blackstone
fill 136 152 394 136 165 394 minecraft:polished_blackstone
fill 136 152 395 136 152 396 minecraft:shroomlight
fill 136 152 397 136 165 397 minecraft:polished_blackstone
fill 136 152 406 136 165 406 minecraft:polished_blackstone
fill 136 152 407 136 152 408 minecraft:shroomlight
fill 136 152 409 136 165 409 minecraft:polished_blackstone
fill 94 153 376 94 165 377 minecraft:polished_blackstone
fill 94 153 388 94 165 389 minecraft:polished_blackstone
fill 94 153 400 94 165 401 minecraft:polished_blackstone
fill 95 153 411 96 165 411 minecraft:polished_blackstone
fill 102 153 369 103 165 369 minecraft:polished_blackstone
fill 107 153 411 108 165 411 minecraft:polished_blackstone
fill 114 153 369 115 165 369 minecraft:polished_blackstone
fill 119 153 411 120 165 411 minecraft:polished_blackstone
fill 126 153 369 127 165 369 minecraft:polished_blackstone
fill 131 153 411 132 165 411 minecraft:polished_blackstone
fill 136 153 371 136 165 372 minecraft:polished_blackstone
fill 136 153 383 136 165 384 minecraft:polished_blackstone
fill 136 153 395 136 165 396 minecraft:polished_blackstone
fill 136 153 407 136 165 408 minecraft:polished_blackstone
fill 98 155 381 99 156 382 minecraft:orange_concrete
setblock 101 156 387 minecraft:shroomlight
fill 96 157 387 96 160 387 minecraft:netherite_block
fill 97 157 385 97 160 386 minecraft:netherite_block
fill 97 157 388 97 160 389 minecraft:netherite_block
fill 98 157 385 98 160 385 minecraft:netherite_block
fill 98 157 389 98 160 389 minecraft:netherite_block
fill 99 157 384 99 160 384 minecraft:netherite_block
fill 99 157 390 99 160 390 minecraft:netherite_block
fill 100 157 385 101 160 385 minecraft:netherite_block
fill 100 157 389 101 160 389 minecraft:netherite_block
fill 101 157 386 101 160 386 minecraft:netherite_block
fill 101 157 388 101 160 388 minecraft:netherite_block
fill 102 157 387 102 160 387 minecraft:netherite_block
fill 97 158 387 101 159 387 minecraft:magma_block
fill 98 158 386 100 159 386 minecraft:magma_block
fill 98 158 388 100 159 388 minecraft:magma_block
fill 98 158 393 110 159 394 minecraft:iron_block
fill 99 158 385 99 159 385 minecraft:magma_block
fill 99 158 389 99 159 389 minecraft:magma_block
fill 111 158 393 124 159 393 minecraft:iron_block
fill 113 158 394 124 159 394 minecraft:iron_block
fill 123 158 408 123 169 408 minecraft:netherite_block
setblock 97 159 372 minecraft:light[level=14]
setblock 97 159 380 minecraft:light[level=14]
setblock 97 159 396 minecraft:light[level=14]
setblock 97 159 404 minecraft:light[level=14]
setblock 105 159 372 minecraft:light[level=14]
setblock 105 159 380 minecraft:light[level=14]
setblock 105 159 388 minecraft:light[level=14]
setblock 105 159 396 minecraft:light[level=14]
setblock 105 159 404 minecraft:light[level=14]
setblock 113 159 372 minecraft:light[level=14]
setblock 113 159 380 minecraft:light[level=14]
setblock 113 159 388 minecraft:light[level=14]
setblock 113 159 396 minecraft:light[level=14]
setblock 113 159 404 minecraft:light[level=14]
setblock 121 159 372 minecraft:light[level=14]
setblock 121 159 380 minecraft:light[level=14]
setblock 121 159 388 minecraft:light[level=14]
setblock 121 159 396 minecraft:light[level=14]
setblock 121 159 404 minecraft:light[level=14]
setblock 129 159 372 minecraft:light[level=14]
setblock 129 159 380 minecraft:light[level=14]
setblock 129 159 388 minecraft:light[level=14]
setblock 129 159 396 minecraft:light[level=14]
setblock 129 159 404 minecraft:light[level=14]
fill 96 160 379 96 165 381 minecraft:polished_blackstone_bricks
fill 96 160 391 96 165 393 minecraft:polished_blackstone_bricks
fill 96 160 403 96 165 405 minecraft:polished_blackstone_bricks
fill 102 160 409 104 165 409 minecraft:polished_blackstone_bricks
fill 106 160 371 108 165 371 minecraft:polished_blackstone_bricks
fill 114 160 409 116 165 409 minecraft:polished_blackstone_bricks
fill 118 160 371 120 165 371 minecraft:polished_blackstone_bricks
fill 126 160 409 128 165 409 minecraft:polished_blackstone_bricks
fill 130 160 371 132 165 371 minecraft:polished_blackstone_bricks
fill 134 160 379 134 165 381 minecraft:polished_blackstone_bricks
fill 134 160 391 134 165 393 minecraft:polished_blackstone_bricks
fill 134 160 403 134 165 405 minecraft:polished_blackstone_bricks
fill 95 165 373 95 165 378 minecraft:blackstone
fill 95 165 385 95 165 390 minecraft:blackstone
fill 95 165 397 95 165 402 minecraft:blackstone
fill 95 165 409 95 165 410 minecraft:blackstone
fill 96 165 410 99 165 410 minecraft:blackstone
fill 99 165 370 104 165 370 minecraft:blackstone
fill 106 165 410 111 165 410 minecraft:blackstone
fill 111 165 370 116 165 370 minecraft:blackstone
fill 118 165 410 123 165 410 minecraft:blackstone
fill 123 165 370 128 165 370 minecraft:blackstone
fill 130 165 410 135 165 410 minecraft:blackstone
fill 135 165 370 135 165 375 minecraft:blackstone
fill 135 165 382 135 165 387 minecraft:blackstone
fill 135 165 394 135 165 399 minecraft:blackstone
fill 135 165 406 135 165 409 minecraft:blackstone
fill 94 166 375 94 171 378 minecraft:shroomlight
fill 94 166 387 94 171 390 minecraft:shroomlight
fill 94 166 399 94 171 402 minecraft:shroomlight
fill 94 166 411 97 171 411 minecraft:shroomlight
fill 101 166 369 104 171 369 minecraft:shroomlight
fill 106 166 411 109 171 411 minecraft:shroomlight
fill 113 166 369 116 171 369 minecraft:shroomlight
fill 118 166 411 121 171 411 minecraft:shroomlight
fill 125 166 369 128 171 369 minecraft:shroomlight
fill 130 166 411 133 171 411 minecraft:shroomlight
fill 136 166 370 136 171 373 minecraft:shroomlight
fill 136 166 382 136 171 385 minecraft:shroomlight
fill 136 166 394 136 171 397 minecraft:shroomlight
fill 136 166 406 136 171 409 minecraft:shroomlight
setblock 97 167 372 minecraft:light[level=14]
setblock 97 167 380 minecraft:light[level=14]
setblock 97 167 388 minecraft:light[level=14]
setblock 97 167 396 minecraft:light[level=14]
setblock 97 167 404 minecraft:light[level=14]
setblock 105 167 372 minecraft:light[level=14]
setblock 105 167 380 minecraft:light[level=14]
setblock 105 167 388 minecraft:light[level=14]
setblock 105 167 396 minecraft:light[level=14]
setblock 105 167 404 minecraft:light[level=14]
setblock 113 167 372 minecraft:light[level=14]
setblock 113 167 380 minecraft:light[level=14]
setblock 113 167 388 minecraft:light[level=14]
setblock 113 167 396 minecraft:light[level=14]
setblock 113 167 404 minecraft:light[level=14]
setblock 121 167 372 minecraft:light[level=14]
setblock 121 167 380 minecraft:light[level=14]
setblock 121 167 388 minecraft:light[level=14]
setblock 121 167 396 minecraft:light[level=14]
setblock 121 167 404 minecraft:light[level=14]
setblock 129 167 372 minecraft:light[level=14]
setblock 129 167 380 minecraft:light[level=14]
setblock 129 167 388 minecraft:light[level=14]
setblock 129 167 396 minecraft:light[level=14]
setblock 129 167 404 minecraft:light[level=14]
fill 101 171 397 101 180 397 minecraft:netherite_block
fill 108 171 404 108 172 406 minecraft:magma_block
fill 109 171 405 109 172 406 minecraft:magma_block
fill 94 172 375 94 185 375 minecraft:polished_blackstone
fill 94 172 376 94 172 377 minecraft:shroomlight
fill 94 172 378 94 185 378 minecraft:polished_blackstone
fill 94 172 387 94 185 387 minecraft:polished_blackstone
fill 94 172 388 94 172 389 minecraft:shroomlight
fill 94 172 390 94 185 390 minecraft:polished_blackstone
fill 94 172 399 94 185 399 minecraft:polished_blackstone
fill 94 172 400 94 172 401 minecraft:shroomlight
fill 94 172 402 94 185 402 minecraft:polished_blackstone
fill 94 172 411 94 185 411 minecraft:polished_blackstone
fill 95 172 411 96 172 411 minecraft:shroomlight
fill 97 172 411 97 185 411 minecraft:polished_blackstone
fill 101 172 369 101 185 369 minecraft:polished_blackstone
fill 102 172 369 103 172 369 minecraft:shroomlight
fill 104 172 369 104 185 369 minecraft:polished_blackstone
fill 106 172 411 106 185 411 minecraft:polished_blackstone
fill 107 172 411 108 172 411 minecraft:shroomlight
fill 109 172 411 109 185 411 minecraft:polished_blackstone
fill 113 172 369 113 185 369 minecraft:polished_blackstone
fill 114 172 369 115 172 369 minecraft:shroomlight
fill 116 172 369 116 185 369 minecraft:polished_blackstone
fill 118 172 411 118 185 411 minecraft:polished_blackstone
fill 119 172 411 120 172 411 minecraft:shroomlight
fill 121 172 411 121 185 411 minecraft:polished_blackstone
fill 124 172 393 125 173 393 minecraft:orange_concrete
fill 125 172 369 125 185 369 minecraft:polished_blackstone
fill 126 172 369 127 172 369 minecraft:shroomlight
fill 128 172 369 128 185 369 minecraft:polished_blackstone
fill 130 172 411 130 185 411 minecraft:polished_blackstone
fill 131 172 411 132 172 411 minecraft:shroomlight
fill 133 172 411 133 185 411 minecraft:polished_blackstone
fill 136 172 370 136 185 370 minecraft:polished_blackstone
fill 136 172 371 136 172 372 minecraft:shroomlight
fill 136 172 373 136 185 373 minecraft:polished_blackstone
fill 136 172 382 136 185 382 minecraft:polished_blackstone
fill 136 172 383 136 172 384 minecraft:shroomlight
fill 136 172 385 136 185 385 minecraft:polished_blackstone
fill 136 172 394 136 185 394 minecraft:polished_blackstone
fill 136 172 395 136 172 396 minecraft:shroomlight
fill 136 172 397 136 185 397 minecraft:polished_blackstone
fill 136 172 406 136 185 406 minecraft:polished_blackstone
fill 136 172 407 136 172 408 minecraft:shroomlight
fill 136 172 409 136 185 409 minecraft:polished_blackstone
fill 94 173 376 94 185 377 minecraft:polished_blackstone
fill 94 173 388 94 185 389 minecraft:polished_blackstone
fill 94 173 400 94 185 401 minecraft:polished_blackstone
fill 95 173 411 96 185 411 minecraft:polished_blackstone
fill 102 173 369 103 185 369 minecraft:polished_blackstone
fill 107 173 411 108 185 411 minecraft:polished_blackstone
fill 114 173 369 115 185 369 minecraft:polished_blackstone
fill 119 173 411 120 185 411 minecraft:polished_blackstone
fill 126 173 369 127 185 369 minecraft:polished_blackstone
fill 127 173 388 129 174 388 minecraft:magma_block
fill 128 173 387 128 174 387 minecraft:magma_block
fill 128 173 389 128 174 389 minecraft:magma_block
fill 131 173 411 132 185 411 minecraft:polished_blackstone
fill 136 173 371 136 185 372 minecraft:polished_blackstone
fill 136 173 383 136 185 384 minecraft:polished_blackstone
fill 136 173 395 136 185 396 minecraft:polished_blackstone
fill 136 173 407 136 185 408 minecraft:polished_blackstone
fill 129 174 393 131 175 393 minecraft:orange_concrete
fill 130 174 394 131 175 394 minecraft:orange_concrete
setblock 97 175 372 minecraft:light[level=14]
setblock 97 175 380 minecraft:light[level=14]
setblock 97 175 388 minecraft:light[level=14]
setblock 97 175 396 minecraft:light[level=14]
setblock 97 175 404 minecraft:light[level=14]
setblock 105 175 372 minecraft:light[level=14]
setblock 105 175 380 minecraft:light[level=14]
setblock 105 175 388 minecraft:light[level=14]
setblock 105 175 396 minecraft:light[level=14]
setblock 105 175 404 minecraft:light[level=14]
setblock 113 175 372 minecraft:light[level=14]
setblock 113 175 380 minecraft:light[level=14]
setblock 113 175 388 minecraft:light[level=14]
setblock 113 175 396 minecraft:light[level=14]
setblock 113 175 404 minecraft:light[level=14]
setblock 121 175 372 minecraft:light[level=14]
setblock 121 175 380 minecraft:light[level=14]
setblock 121 175 388 minecraft:light[level=14]
setblock 121 175 396 minecraft:light[level=14]
setblock 121 175 404 minecraft:light[level=14]
setblock 129 175 372 minecraft:light[level=14]
setblock 129 175 380 minecraft:light[level=14]
setblock 129 175 388 minecraft:light[level=14]
setblock 129 175 396 minecraft:light[level=14]
setblock 129 175 404 minecraft:light[level=14]
fill 133 176 391 134 177 392 minecraft:magma_block
fill 96 180 379 96 185 381 minecraft:polished_blackstone_bricks
fill 96 180 391 96 185 393 minecraft:polished_blackstone_bricks
fill 96 180 403 96 185 405 minecraft:polished_blackstone_bricks
fill 102 180 409 104 185 409 minecraft:polished_blackstone_bricks
fill 106 180 371 108 185 371 minecraft:polished_blackstone_bricks
fill 114 180 409 116 185 409 minecraft:polished_blackstone_bricks
fill 118 180 371 120 185 371 minecraft:polished_blackstone_bricks
fill 126 180 409 128 185 409 minecraft:polished_blackstone_bricks
fill 130 180 371 132 185 371 minecraft:polished_blackstone_bricks
fill 134 180 379 134 185 381 minecraft:polished_blackstone_bricks
fill 134 180 391 134 185 393 minecraft:polished_blackstone_bricks
fill 134 180 403 134 185 405 minecraft:polished_blackstone_bricks
setblock 97 183 372 minecraft:light[level=14]
setblock 97 183 380 minecraft:light[level=14]
setblock 97 183 388 minecraft:light[level=14]
setblock 97 183 396 minecraft:light[level=14]
setblock 97 183 404 minecraft:light[level=14]
setblock 105 183 372 minecraft:light[level=14]
setblock 105 183 380 minecraft:light[level=14]
setblock 105 183 388 minecraft:light[level=14]
setblock 105 183 396 minecraft:light[level=14]
setblock 105 183 404 minecraft:light[level=14]
setblock 113 183 372 minecraft:light[level=14]
setblock 113 183 380 minecraft:light[level=14]
setblock 113 183 388 minecraft:light[level=14]
setblock 113 183 396 minecraft:light[level=14]
setblock 113 183 404 minecraft:light[level=14]
setblock 121 183 372 minecraft:light[level=14]
setblock 121 183 380 minecraft:light[level=14]
setblock 121 183 388 minecraft:light[level=14]
setblock 121 183 396 minecraft:light[level=14]
setblock 121 183 404 minecraft:light[level=14]
setblock 129 183 372 minecraft:light[level=14]
setblock 129 183 380 minecraft:light[level=14]
setblock 129 183 388 minecraft:light[level=14]
setblock 129 183 396 minecraft:light[level=14]
setblock 129 183 404 minecraft:light[level=14]
fill 95 185 373 95 185 378 minecraft:blackstone
fill 95 185 385 95 185 390 minecraft:blackstone
fill 95 185 397 95 185 402 minecraft:blackstone
fill 95 185 409 95 185 410 minecraft:blackstone
fill 96 185 410 99 185 410 minecraft:blackstone
fill 99 185 370 104 185 370 minecraft:blackstone
fill 99 185 389 99 193 389 minecraft:netherite_block
fill 106 185 410 111 185 410 minecraft:blackstone
fill 111 185 370 116 185 370 minecraft:blackstone
fill 118 185 410 123 185 410 minecraft:blackstone
fill 123 185 370 128 185 370 minecraft:blackstone
fill 130 185 410 135 185 410 minecraft:blackstone
fill 135 185 370 135 185 375 minecraft:blackstone
fill 135 185 382 135 185 387 minecraft:blackstone
fill 135 185 394 135 185 399 minecraft:blackstone
fill 135 185 406 135 185 409 minecraft:blackstone
fill 94 186 375 94 191 378 minecraft:shroomlight
fill 94 186 387 94 191 390 minecraft:shroomlight
fill 94 186 399 94 191 402 minecraft:shroomlight
fill 94 186 411 97 191 411 minecraft:shroomlight
fill 101 186 369 104 191 369 minecraft:shroomlight
fill 106 186 411 109 191 411 minecraft:shroomlight
fill 113 186 369 116 191 369 minecraft:shroomlight
fill 118 186 411 121 191 411 minecraft:shroomlight
fill 125 186 369 128 191 369 minecraft:shroomlight
fill 130 186 411 133 191 411 minecraft:shroomlight
fill 136 186 370 136 191 373 minecraft:shroomlight
fill 136 186 382 136 191 385 minecraft:shroomlight
fill 136 186 394 136 191 397 minecraft:shroomlight
fill 136 186 406 136 191 409 minecraft:shroomlight
setblock 97 191 372 minecraft:light[level=14]
setblock 97 191 380 minecraft:light[level=14]
setblock 97 191 388 minecraft:light[level=14]
setblock 97 191 396 minecraft:light[level=14]
setblock 97 191 404 minecraft:light[level=14]
setblock 105 191 372 minecraft:light[level=14]
setblock 105 191 380 minecraft:light[level=14]
setblock 105 191 388 minecraft:light[level=14]
setblock 105 191 396 minecraft:light[level=14]
setblock 105 191 404 minecraft:light[level=14]
setblock 113 191 372 minecraft:light[level=14]
setblock 113 191 380 minecraft:light[level=14]
setblock 113 191 388 minecraft:light[level=14]
setblock 113 191 396 minecraft:light[level=14]
setblock 113 191 404 minecraft:light[level=14]
setblock 121 191 372 minecraft:light[level=14]
setblock 121 191 380 minecraft:light[level=14]
setblock 121 191 388 minecraft:light[level=14]
setblock 121 191 396 minecraft:light[level=14]
setblock 121 191 404 minecraft:light[level=14]
setblock 129 191 372 minecraft:light[level=14]
setblock 129 191 380 minecraft:light[level=14]
setblock 129 191 388 minecraft:light[level=14]
setblock 129 191 396 minecraft:light[level=14]
setblock 129 191 404 minecraft:light[level=14]
fill 94 192 375 94 196 375 minecraft:polished_blackstone
fill 94 192 376 94 192 377 minecraft:shroomlight
fill 94 192 378 94 196 378 minecraft:polished_blackstone
fill 94 192 387 94 197 387 minecraft:polished_blackstone
fill 94 192 388 94 192 389 minecraft:shroomlight
fill 94 192 390 94 196 390 minecraft:polished_blackstone
fill 94 192 399 94 196 399 minecraft:polished_blackstone
fill 94 192 400 94 192 401 minecraft:shroomlight
fill 94 192 402 94 196 402 minecraft:polished_blackstone
fill 94 192 411 94 193 411 minecraft:polished_blackstone
fill 95 192 411 96 192 411 minecraft:shroomlight
fill 97 192 411 97 196 411 minecraft:polished_blackstone
fill 101 192 369 101 196 369 minecraft:polished_blackstone
fill 102 192 369 103 192 369 minecraft:shroomlight
fill 104 192 369 104 196 369 minecraft:polished_blackstone
fill 106 192 411 106 196 411 minecraft:polished_blackstone
fill 107 192 411 108 192 411 minecraft:shroomlight
fill 109 192 411 109 196 411 minecraft:polished_blackstone
fill 113 192 369 113 196 369 minecraft:polished_blackstone
fill 114 192 369 115 192 369 minecraft:shroomlight
setblock 116 192 369 minecraft:polished_blackstone
fill 118 192 411 118 196 411 minecraft:polished_blackstone
fill 119 192 411 120 192 411 minecraft:shroomlight
fill 121 192 411 121 194 411 minecraft:polished_blackstone
fill 125 192 369 125 196 369 minecraft:polished_blackstone
fill 126 192 369 127 192 369 minecraft:shroomlight
fill 128 192 369 128 194 369 minecraft:polished_blackstone
fill 130 192 411 130 196 411 minecraft:polished_blackstone
fill 131 192 411 132 192 411 minecraft:shroomlight
setblock 133 192 411 minecraft:polished_blackstone
fill 136 192 370 136 196 370 minecraft:polished_blackstone
fill 136 192 371 136 192 372 minecraft:shroomlight
setblock 136 192 373 minecraft:polished_blackstone
fill 136 192 382 136 196 382 minecraft:polished_blackstone
fill 136 192 383 136 192 384 minecraft:shroomlight
fill 136 192 385 136 196 385 minecraft:polished_blackstone
fill 136 192 394 136 193 394 minecraft:polished_blackstone
fill 136 192 395 136 192 396 minecraft:shroomlight
fill 136 192 397 136 196 397 minecraft:polished_blackstone
fill 136 192 406 136 196 406 minecraft:polished_blackstone
fill 136 192 407 136 192 408 minecraft:shroomlight
fill 136 192 409 136 194 409 minecraft:polished_blackstone
setblock 94 193 369 minecraft:polished_blackstone
setblock 94 193 370 minecraft:blackstone
fill 94 193 371 94 193 372 minecraft:polished_blackstone
setblock 94 193 373 minecraft:blackstone
fill 94 193 376 94 196 377 minecraft:polished_blackstone
fill 94 193 379 94 194 383 minecraft:polished_blackstone
fill 94 193 384 94 193 385 minecraft:blackstone
fill 94 193 386 94 196 386 minecraft:polished_blackstone
fill 94 193 388 94 196 389 minecraft:polished_blackstone
fill 94 193 400 94 196 401 minecraft:polished_blackstone
fill 95 193 411 96 196 411 minecraft:polished_blackstone
fill 99 193 411 100 193 411 minecraft:blackstone
fill 101 193 411 104 196 411 minecraft:polished_blackstone
fill 102 193 369 103 193 369 minecraft:polished_blackstone
setblock 105 193 369 minecraft:blackstone
fill 105 193 411 105 194 411 minecraft:blackstone
fill 106 193 369 109 193 369 minecraft:polished_blackstone
fill 107 193 411 108 196 411 minecraft:polished_blackstone
fill 114 193 369 116 193 369 minecraft:blackstone
fill 118 193 369 119 196 369 minecraft:polished_blackstone
fill 119 193 411 120 194 411 minecraft:polished_blackstone
setblock 120 193 369 minecraft:blackstone
fill 126 193 369 127 193 369 minecraft:polished_blackstone
fill 131 193 411 132 194 411 minecraft:polished_blackstone
setblock 133 193 411 minecraft:blackstone
fill 136 193 371 136 196 372 minecraft:polished_blackstone
setblock 136 193 373 minecraft:blackstone
fill 136 193 383 136 193 384 minecraft:polished_blackstone
fill 136 193 395 136 193 396 minecraft:polished_blackstone
fill 136 193 401 136 196 401 minecraft:polished_blackstone
setblock 136 193 402 minecraft:blackstone
fill 136 193 403 136 196 404 minecraft:polished_blackstone
fill 136 193 407 136 193 408 minecraft:polished_blackstone
setblock 94 194 369 minecraft:blackstone
fill 94 194 370 94 196 371 minecraft:polished_blackstone
setblock 94 194 372 minecraft:blackstone
fill 94 194 373 94 196 373 minecraft:polished_blackstone
setblock 94 194 374 minecraft:blackstone
fill 94 194 384 94 196 385 minecraft:polished_blackstone
setblock 94 194 411 minecraft:blackstone
fill 99 194 411 100 194 411 minecraft:polished_blackstone
fill 102 194 369 102 196 369 minecraft:polished_blackstone
setblock 103 194 369 minecraft:blackstone
fill 105 194 369 106 196 369 minecraft:polished_blackstone
fill 107 194 369 107 195 369 minecraft:blackstone
fill 108 194 369 109 194 369 minecraft:polished_blackstone
fill 110 194 411 111 196 411 minecraft:polished_blackstone
setblock 112 194 411 minecraft:blackstone
fill 113 194 411 113 196 411 minecraft:polished_blackstone
fill 114 194 369 116 196 369 minecraft:polished_blackstone
setblock 114 194 411 minecraft:blackstone
fill 120 194 369 120 196 369 minecraft:polished_blackstone
fill 122 194 369 122 196 369 minecraft:polished_blackstone
setblock 122 194 411 minecraft:blackstone
setblock 123 194 369 minecraft:blackstone
fill 123 194 411 125 196 411 minecraft:polished_blackstone
fill 124 194 369 124 196 369 minecraft:polished_blackstone
fill 125 194 389 126 195 390 minecraft:magma_block
fill 126 194 369 126 196 369 minecraft:polished_blackstone
setblock 126 194 411 minecraft:blackstone
setblock 127 194 369 minecraft:blackstone
fill 133 194 411 133 196 411 minecraft:polished_blackstone
fill 136 194 373 136 197 373 minecraft:polished_blackstone
setblock 136 194 378 minecraft:blackstone
fill 136 194 383 136 195 383 minecraft:blackstone
fill 136 194 384 136 196 384 minecraft:polished_blackstone
fill 136 194 394 136 194 395 minecraft:blackstone
fill 136 194 396 136 196 396 minecraft:polished_blackstone
fill 136 194 402 136 196 402 minecraft:polished_blackstone
fill 136 194 407 136 196 407 minecraft:polished_blackstone
setblock 136 194 408 minecraft:blackstone
fill 94 195 369 94 196 369 minecraft:polished_blackstone
fill 94 195 372 94 196 372 minecraft:polished_blackstone
fill 94 195 374 94 196 374 minecraft:polished_blackstone
fill 94 195 379 94 196 380 minecraft:polished_blackstone
setblock 94 195 381 minecraft:blackstone
fill 94 195 382 94 196 383 minecraft:polished_blackstone
fill 94 195 395 94 196 396 minecraft:polished_blackstone
setblock 94 195 397 minecraft:blackstone
fill 94 195 398 94 196 398 minecraft:polished_blackstone
setblock 94 195 403 minecraft:blackstone
fill 94 195 404 94 196 404 minecraft:polished_blackstone
fill 94 195 411 94 196 411 minecraft:polished_blackstone
fill 96 195 369 96 196 369 minecraft:polished_blackstone
setblock 97 195 369 minecraft:blackstone
fill 98 195 369 100 196 369 minecraft:polished_blackstone
setblock 99 195 411 minecraft:blackstone
fill 100 195 411 100 196 411 minecraft:polished_blackstone
fill 103 195 369 103 196 369 minecraft:polished_blackstone
fill 105 195 411 105 196 411 minecraft:polished_blackstone
fill 108 195 369 108 196 369 minecraft:polished_blackstone
setblock 109 195 369 minecraft:blackstone
fill 112 195 411 112 196 411 minecraft:polished_blackstone
fill 114 195 411 114 196 411 minecraft:polished_blackstone
setblock 119 195 411 minecraft:blackstone
fill 120 195 411 120 196 411 minecraft:polished_blackstone
setblock 121 195 369 minecraft:blackstone
setblock 121 195 411 minecraft:blackstone
fill 122 195 411 122 196 411 minecraft:polished_blackstone
fill 123 195 369 123 196 369 minecraft:polished_blackstone
fill 126 195 411 126 196 411 minecraft:polished_blackstone
fill 127 195 369 127 196 369 minecraft:polished_blackstone
fill 128 195 369 129 195 369 minecraft:blackstone
fill 130 195 369 130 196 369 minecraft:polished_blackstone
setblock 131 195 369 minecraft:blackstone
setblock 131 195 411 minecraft:blackstone
fill 132 195 369 134 196 369 minecraft:polished_blackstone
fill 132 195 411 132 196 411 minecraft:polished_blackstone
fill 136 195 376 136 196 376 minecraft:polished_blackstone
setblock 136 195 377 minecraft:blackstone
fill 136 195 378 136 196 378 minecraft:polished_blackstone
fill 136 195 394 136 196 395 minecraft:polished_blackstone
fill 136 195 408 136 196 408 minecraft:polished_blackstone
setblock 136 195 409 minecraft:blackstone
setblock 94 196 381 minecraft:polished_blackstone
setblock 94 196 397 minecraft:polished_blackstone
setblock 94 196 403 minecraft:polished_blackstone
fill 97 196 369 97 197 369 minecraft:polished_blackstone
setblock 99 196 411 minecraft:polished_blackstone
setblock 107 196 369 minecraft:polished_blackstone
setblock 109 196 369 minecraft:polished_blackstone
fill 119 196 411 119 198 411 minecraft:polished_blackstone
setblock 121 196 369 minecraft:polished_blackstone
setblock 121 196 411 minecraft:polished_blackstone
fill 128 196 369 129 196 369 minecraft:polished_blackstone
setblock 131 196 369 minecraft:polished_blackstone
setblock 131 196 411 minecraft:polished_blackstone
setblock 136 196 377 minecraft:polished_blackstone
setblock 136 196 383 minecraft:polished_blackstone
setblock 136 196 409 minecraft:polished_blackstone
fill 94 197 369 96 198 369 minecraft:blackstone
setblock 94 197 370 minecraft:polished_blackstone
fill 94 197 371 94 197 386 minecraft:blackstone
fill 94 197 388 94 197 391 minecraft:blackstone
setblock 94 197 392 minecraft:polished_blackstone
fill 94 197 393 94 307 393 minecraft:blackstone
fill 94 197 395 94 197 406 minecraft:blackstone
setblock 94 197 407 minecraft:polished_blackstone
fill 94 197 408 94 205 411 minecraft:blackstone
fill 95 197 411 107 197 411 minecraft:blackstone
fill 98 197 369 109 198 369 minecraft:blackstone
setblock 108 197 411 minecraft:polished_blackstone
fill 109 197 411 109 205 411 minecraft:blackstone
setblock 110 197 411 minecraft:polished_blackstone
fill 111 197 369 113 198 369 minecraft:blackstone
fill 111 197 411 118 197 411 minecraft:blackstone
setblock 114 197 369 minecraft:polished_blackstone
setblock 115 197 369 minecraft:blackstone
setblock 116 197 369 minecraft:polished_blackstone
fill 117 197 369 135 197 369 minecraft:blackstone
fill 120 197 411 126 198 411 minecraft:blackstone
setblock 127 197 411 minecraft:polished_blackstone
fill 128 197 411 135 198 411 minecraft:blackstone
setblock 136 197 369 minecraft:polished_blackstone
fill 136 197 370 136 205 372 minecraft:blackstone
setblock 136 197 374 minecraft:polished_blackstone
fill 136 197 375 136 198 378 minecraft:blackstone
setblock 136 197 379 minecraft:polished_blackstone
fill 136 197 380 136 197 389 minecraft:blackstone
setblock 136 197 390 minecraft:polished_blackstone
fill 136 197 391 136 307 391 minecraft:blackstone
setblock 136 197 392 minecraft:polished_blackstone
fill 136 197 393 136 197 404 minecraft:blackstone
fill 136 197 406 136 197 410 minecraft:blackstone
setblock 136 197 411 minecraft:polished_blackstone
fill 94 198 370 94 198 381 minecraft:blackstone
setblock 94 198 382 minecraft:polished_blackstone
fill 94 198 383 94 198 390 minecraft:blackstone
setblock 94 198 391 minecraft:polished_blackstone
fill 94 198 392 94 307 392 minecraft:blackstone
fill 94 198 394 94 198 398 minecraft:blackstone
fill 94 198 399 94 199 400 minecraft:polished_blackstone
fill 94 198 401 94 205 401 minecraft:blackstone
setblock 94 198 402 minecraft:polished_blackstone
fill 94 198 403 94 307 407 minecraft:blackstone
fill 95 198 411 97 198 411 minecraft:blackstone
fill 97 198 369 97 307 369 minecraft:blackstone
setblock 98 198 411 minecraft:polished_blackstone
fill 99 198 411 106 198 411 minecraft:blackstone
setblock 107 198 411 minecraft:polished_blackstone
fill 108 198 411 108 205 411 minecraft:blackstone
setblock 110 198 369 minecraft:blackstone
fill 110 198 411 111 307 411 minecraft:blackstone
setblock 112 198 411 minecraft:polished_blackstone
fill 113 198 411 115 198 411 minecraft:blackstone
fill 114 198 369 114 205 369 minecraft:blackstone
setblock 115 198 369 minecraft:polished_blackstone
fill 116 198 369 118 205 369 minecraft:blackstone
setblock 116 198 411 minecraft:polished_blackstone
fill 117 198 411 118 205 411 minecraft:blackstone
setblock 119 198 369 minecraft:polished_blackstone
fill 120 198 369 133 198 369 minecraft:blackstone
fill 127 198 411 127 307 411 minecraft:blackstone
setblock 134 198 369 minecraft:polished_blackstone
fill 135 198 369 136 198 369 minecraft:blackstone
fill 136 198 373 136 205 374 minecraft:blackstone
fill 136 198 379 136 198 386 minecraft:blackstone
setblock 136 198 387 minecraft:polished_blackstone
fill 136 198 388 136 307 390 minecraft:blackstone
fill 136 198 392 136 307 393 minecraft:blackstone
setblock 136 198 394 minecraft:polished_blackstone
fill 136 198 395 136 198 405 minecraft:blackstone
fill 136 198 406 136 199 406 minecraft:polished_blackstone
fill 136 198 407 136 198 411 minecraft:blackstone
fill 94 199 369 94 307 374 minecraft:blackstone
fill 94 199 375 94 199 376 minecraft:polished_blackstone
fill 94 199 377 94 205 382 minecraft:blackstone
setblock 94 199 383 minecraft:polished_blackstone
fill 94 199 384 94 307 384 minecraft:blackstone
fill 94 199 385 94 199 386 minecraft:polished_blackstone
fill 94 199 387 94 205 391 minecraft:blackstone
setblock 94 199 394 minecraft:polished_blackstone
fill 94 199 395 94 307 398 minecraft:blackstone
fill 94 199 402 94 205 402 minecraft:blackstone
setblock 95 199 369 minecraft:polished_blackstone
setblock 95 199 411 minecraft:polished_blackstone
fill 96 199 369 96 307 369 minecraft:blackstone
fill 96 199 411 98 205 411 minecraft:blackstone
setblock 97 199 372 minecraft:light[level=14]
setblock 97 199 380 minecraft:light[level=14]
setblock 97 199 388 minecraft:light[level=14]
setblock 97 199 396 minecraft:light[level=14]
setblock 97 199 404 minecraft:light[level=14]
fill 98 199 369 99 307 369 minecraft:blackstone
setblock 99 199 411 minecraft:polished_blackstone
setblock 100 199 369 minecraft:polished_blackstone
fill 100 199 411 107 205 411 minecraft:blackstone
fill 101 199 369 103 205 369 minecraft:blackstone
setblock 104 199 369 minecraft:polished_blackstone
fill 105 199 369 105 307 369 minecraft:blackstone
setblock 105 199 372 minecraft:light[level=14]
setblock 105 199 380 minecraft:light[level=14]
setblock 105 199 388 minecraft:light[level=14]
setblock 105 199 396 minecraft:light[level=14]
setblock 105 199 404 minecraft:light[level=14]
setblock 106 199 369 minecraft:polished_blackstone
fill 107 199 369 109 307 369 minecraft:blackstone
fill 110 199 369 111 199 369 minecraft:polished_blackstone
fill 112 199 369 113 205 369 minecraft:blackstone
fill 112 199 411 112 307 411 minecraft:blackstone
setblock 113 199 372 minecraft:light[level=14]
setblock 113 199 380 minecraft:light[level=14]
setblock 113 199 388 minecraft:light[level=14]
setblock 113 199 396 minecraft:light[level=14]
setblock 113 199 404 minecraft:light[level=14]
setblock 113 199 411 minecraft:polished_blackstone
fill 114 199 411 116 307 411 minecraft:blackstone
fill 115 199 369 115 205 369 minecraft:blackstone
fill 119 199 369 123 307 369 minecraft:blackstone
fill 119 199 411 123 205 411 minecraft:blackstone
setblock 121 199 372 minecraft:light[level=14]
setblock 121 199 380 minecraft:light[level=14]
setblock 121 199 388 minecraft:light[level=14]
setblock 121 199 396 minecraft:light[level=14]
setblock 121 199 404 minecraft:light[level=14]
fill 124 199 369 125 199 369 minecraft:polished_blackstone
setblock 124 199 411 minecraft:polished_blackstone
fill 125 199 411 126 307 411 minecraft:blackstone
fill 126 199 369 135 205 369 minecraft:blackstone
fill 128 199 411 128 307 411 minecraft:blackstone
setblock 129 199 372 minecraft:light[level=14]
setblock 129 199 380 minecraft:light[level=14]
setblock 129 199 388 minecraft:light[level=14]
setblock 129 199 396 minecraft:light[level=14]
setblock 129 199 404 minecraft:light[level=14]
setblock 129 199 411 minecraft:polished_blackstone
fill 130 199 411 134 205 411 minecraft:blackstone
setblock 135 199 411 minecraft:polished_blackstone
setblock 136 199 369 minecraft:polished_blackstone
fill 136 199 375 136 307 376 minecraft:blackstone
setblock 136 199 377 minecraft:polished_blackstone
fill 136 199 378 136 307 378 minecraft:blackstone
setblock 136 199 379 minecraft:polished_blackstone
fill 136 199 380 136 205 383 minecraft:blackstone
setblock 136 199 384 minecraft:polished_blackstone
fill 136 199 385 136 205 387 minecraft:blackstone
fill 136 199 394 136 205 399 minecraft:blackstone
setblock 136 199 400 minecraft:polished_blackstone
fill 136 199 401 136 307 405 minecraft:blackstone
fill 136 199 407 136 205 407 minecraft:blackstone
setblock 136 199 408 minecraft:polished_blackstone
fill 136 199 409 136 205 411 minecraft:blackstone
fill 94 200 375 94 205 376 minecraft:blackstone
fill 94 200 383 94 307 383 minecraft:blackstone
fill 94 200 385 94 307 386 minecraft:blackstone
fill 94 200 394 94 307 394 minecraft:blackstone
fill 94 200 399 94 205 400 minecraft:blackstone
fill 95 200 369 95 307 369 minecraft:blackstone
fill 95 200 411 95 205 411 minecraft:blackstone
fill 96 200 379 96 205 381 minecraft:polished_blackstone_bricks
fill 96 200 391 96 205 393 minecraft:polished_blackstone_bricks
fill 96 200 403 96 205 405 minecraft:polished_blackstone_bricks
fill 99 200 411 99 307 411 minecraft:blackstone
fill 100 200 369 100 307 369 minecraft:blackstone
fill 102 200 409 104 205 409 minecraft:polished_blackstone_bricks
fill 104 200 369 104 205 369 minecraft:blackstone
fill 106 200 369 106 307 369 minecraft:blackstone
fill 106 200 371 108 205 371 minecraft:polished_blackstone_bricks
fill 110 200 369 111 307 369 minecraft:blackstone
fill 113 200 411 113 307 411 minecraft:blackstone
fill 114 200 409 116 205 409 minecraft:polished_blackstone_bricks
fill 118 200 371 120 205 371 minecraft:polished_blackstone_bricks
fill 124 200 369 125 205 369 minecraft:blackstone
fill 124 200 411 124 307 411 minecraft:blackstone
fill 126 200 409 128 205 409 minecraft:polished_blackstone_bricks
fill 129 200 411 129 307 411 minecraft:blackstone
fill 130 200 371 132 205 371 minecraft:polished_blackstone_bricks
fill 134 200 379 134 205 381 minecraft:polished_blackstone_bricks
fill 134 200 391 134 205 393 minecraft:polished_blackstone_bricks
fill 134 200 403 134 205 405 minecraft:polished_blackstone_bricks
fill 135 200 411 135 307 411 minecraft:blackstone
fill 136 200 369 136 307 369 minecraft:blackstone
fill 136 200 377 136 307 377 minecraft:blackstone
fill 136 200 379 136 307 379 minecraft:blackstone
fill 136 200 384 136 205 384 minecraft:blackstone
fill 136 200 400 136 307 400 minecraft:blackstone
fill 136 200 406 136 205 406 minecraft:blackstone
fill 136 200 408 136 205 408 minecraft:blackstone
fill 95 205 373 95 205 378 minecraft:blackstone
fill 95 205 385 95 205 390 minecraft:blackstone
fill 95 205 397 95 205 402 minecraft:blackstone
fill 95 205 409 95 205 410 minecraft:blackstone
fill 96 205 410 99 205 410 minecraft:blackstone
fill 99 205 370 104 205 370 minecraft:blackstone
fill 106 205 410 111 205 410 minecraft:blackstone
fill 111 205 370 116 205 370 minecraft:blackstone
fill 118 205 410 123 205 410 minecraft:blackstone
fill 122 205 403 133 205 403 minecraft:polished_blackstone_bricks
fill 123 205 370 128 205 370 minecraft:blackstone
fill 130 205 410 135 205 410 minecraft:blackstone
fill 135 205 370 135 205 375 minecraft:blackstone
fill 135 205 382 135 205 387 minecraft:blackstone
fill 135 205 394 135 205 399 minecraft:blackstone
fill 135 205 406 135 205 409 minecraft:blackstone
fill 94 206 375 94 211 378 minecraft:shroomlight
fill 94 206 379 94 307 382 minecraft:blackstone
fill 94 206 387 94 211 390 minecraft:shroomlight
fill 94 206 391 94 307 391 minecraft:blackstone
fill 94 206 399 94 211 402 minecraft:shroomlight
fill 94 206 408 94 307 410 minecraft:blackstone
fill 94 206 411 97 211 411 minecraft:shroomlight
fill 95 206 375 135 206 375 minecraft:polished_blackstone_bricks
fill 95 206 389 110 206 389 minecraft:polished_blackstone_bricks
fill 95 206 396 134 207 396 minecraft:polished_blackstone_bricks
fill 95 206 403 127 206 403 minecraft:polished_blackstone_bricks
fill 96 206 382 134 206 382 minecraft:polished_blackstone_bricks
fill 98 206 411 98 307 411 minecraft:blackstone
fill 100 206 411 105 307 411 minecraft:blackstone
fill 101 206 369 104 211 369 minecraft:shroomlight
fill 106 206 411 109 211 411 minecraft:shroomlight
fill 112 206 369 112 307 369 minecraft:blackstone
fill 113 206 369 116 211 369 minecraft:shroomlight
fill 114 206 389 135 206 389 minecraft:polished_blackstone_bricks
fill 117 206 369 118 307 369 minecraft:blackstone
fill 117 206 411 117 307 411 minecraft:blackstone
fill 118 206 411 121 211 411 minecraft:shroomlight
fill 122 206 411 123 307 411 minecraft:blackstone
fill 124 206 369 124 307 369 minecraft:blackstone
fill 125 206 369 128 211 369 minecraft:shroomlight
fill 129 206 369 135 307 369 minecraft:blackstone
fill 130 206 411 133 211 411 minecraft:shroomlight
fill 134 206 411 134 307 411 minecraft:blackstone
fill 136 206 370 136 211 373 minecraft:shroomlight
fill 136 206 374 136 307 374 minecraft:blackstone
fill 136 206 380 136 307 381 minecraft:blackstone
fill 136 206 382 136 211 385 minecraft:shroomlight
fill 136 206 386 136 307 387 minecraft:blackstone
fill 136 206 394 136 211 397 minecraft:shroomlight
fill 136 206 398 136 307 399 minecraft:blackstone
fill 136 206 406 136 211 409 minecraft:shroomlight
fill 136 206 410 136 307 411 minecraft:blackstone
fill 95 207 375 111 207 375 minecraft:polished_blackstone_bricks
fill 95 207 389 100 207 389 minecraft:polished_blackstone_bricks
fill 95 207 403 97 207 403 minecraft:polished_blackstone_bricks
fill 96 207 382 99 207 382 minecraft:polished_blackstone_bricks
setblock 97 207 372 minecraft:light[level=14]
setblock 97 207 380 minecraft:light[level=14]
setblock 97 207 388 minecraft:light[level=14]
setblock 97 207 404 minecraft:light[level=14]
setblock 105 207 372 minecraft:light[level=14]
setblock 105 207 380 minecraft:light[level=14]
setblock 105 207 388 minecraft:light[level=14]
setblock 105 207 404 minecraft:light[level=14]
fill 107 207 405 107 208 409 minecraft:netherite_block
setblock 113 207 372 minecraft:light[level=14]
setblock 113 207 380 minecraft:light[level=14]
setblock 113 207 388 minecraft:light[level=14]
setblock 113 207 404 minecraft:light[level=14]
setblock 121 207 372 minecraft:light[level=14]
setblock 121 207 380 minecraft:light[level=14]
setblock 121 207 388 minecraft:light[level=14]
setblock 121 207 404 minecraft:light[level=14]
setblock 129 207 372 minecraft:light[level=14]
setblock 129 207 380 minecraft:light[level=14]
setblock 129 207 388 minecraft:light[level=14]
setblock 129 207 404 minecraft:light[level=14]
fill 100 208 370 100 208 410 minecraft:netherite_block
fill 107 208 371 107 208 404 minecraft:netherite_block
fill 114 208 370 114 209 388 minecraft:netherite_block
fill 114 208 395 114 208 409 minecraft:netherite_block
fill 121 208 371 121 209 372 minecraft:netherite_block
fill 128 208 370 128 209 372 minecraft:netherite_block
fill 100 209 370 100 209 376 minecraft:netherite_block
fill 107 209 371 107 209 373 minecraft:netherite_block
fill 114 209 395 114 209 398 minecraft:netherite_block
fill 121 209 373 121 209 406 minecraft:netherite_block
fill 128 209 373 128 209 404 minecraft:netherite_block
fill 121 210 400 121 210 410 minecraft:netherite_block
fill 128 210 399 128 210 410 minecraft:netherite_block
fill 94 212 375 94 225 378 minecraft:blackstone
fill 94 212 387 94 225 390 minecraft:blackstone
fill 94 212 399 94 225 402 minecraft:blackstone
fill 94 212 411 97 225 411 minecraft:blackstone
fill 101 212 369 104 225 369 minecraft:blackstone
fill 106 212 411 109 225 411 minecraft:blackstone
fill 113 212 369 116 225 369 minecraft:blackstone
fill 118 212 411 121 225 411 minecraft:blackstone
fill 125 212 369 128 225 369 minecraft:blackstone
fill 130 212 411 133 225 411 minecraft:blackstone
fill 136 212 370 136 225 373 minecraft:blackstone
fill 136 212 382 136 225 385 minecraft:blackstone
fill 136 212 394 136 225 397 minecraft:blackstone
fill 136 212 406 136 225 409 minecraft:blackstone
setblock 97 215 372 minecraft:light[level=14]
setblock 97 215 380 minecraft:light[level=14]
setblock 97 215 388 minecraft:light[level=14]
setblock 97 215 396 minecraft:light[level=14]
setblock 97 215 404 minecraft:light[level=14]
setblock 105 215 372 minecraft:light[level=14]
setblock 105 215 380 minecraft:light[level=14]
setblock 105 215 388 minecraft:light[level=14]
setblock 105 215 396 minecraft:light[level=14]
setblock 105 215 404 minecraft:light[level=14]
setblock 113 215 372 minecraft:light[level=14]
setblock 113 215 380 minecraft:light[level=14]
setblock 113 215 388 minecraft:light[level=14]
setblock 113 215 396 minecraft:light[level=14]
setblock 113 215 404 minecraft:light[level=14]
setblock 121 215 372 minecraft:light[level=14]
setblock 121 215 380 minecraft:light[level=14]
setblock 121 215 388 minecraft:light[level=14]
setblock 121 215 396 minecraft:light[level=14]
setblock 121 215 404 minecraft:light[level=14]
setblock 129 215 372 minecraft:light[level=14]
setblock 129 215 380 minecraft:light[level=14]
setblock 129 215 388 minecraft:light[level=14]
setblock 129 215 396 minecraft:light[level=14]
setblock 129 215 404 minecraft:light[level=14]
fill 102 217 392 109 217 392 minecraft:gray_concrete
fill 103 217 388 109 217 391 minecraft:gray_concrete
fill 103 217 393 109 217 396 minecraft:gray_concrete
fill 104 217 386 120 217 387 minecraft:gray_concrete
fill 104 217 397 120 217 398 minecraft:gray_concrete
fill 105 217 385 119 217 385 minecraft:gray_concrete
fill 105 217 399 119 217 399 minecraft:gray_concrete
fill 106 217 384 118 217 384 minecraft:gray_concrete
fill 106 217 400 118 217 400 minecraft:gray_concrete
fill 108 217 383 116 217 383 minecraft:gray_concrete
fill 108 217 401 116 217 401 minecraft:gray_concrete
fill 110 217 388 110 217 390 minecraft:gray_concrete
fill 110 217 394 110 217 396 minecraft:gray_concrete
fill 111 217 388 121 217 389 minecraft:gray_concrete
fill 111 217 395 121 217 396 minecraft:gray_concrete
setblock 112 217 382 minecraft:gray_concrete
setblock 112 217 402 minecraft:gray_concrete
fill 114 217 390 121 217 390 minecraft:gray_concrete
fill 114 217 394 121 217 394 minecraft:gray_concrete
fill 115 217 391 121 217 393 minecraft:gray_concrete
setblock 122 217 392 minecraft:gray_concrete
fill 95 218 370 101 218 410 minecraft:polished_blackstone
fill 102 218 370 102 218 391 minecraft:polished_blackstone
fill 102 218 392 108 218 392 minecraft:iron_block
fill 102 218 393 102 218 410 minecraft:polished_blackstone
fill 103 218 370 103 218 387 minecraft:polished_blackstone
fill 103 218 388 103 218 391 minecraft:black_concrete
fill 103 218 393 103 218 396 minecraft:black_concrete
fill 103 218 397 103 218 410 minecraft:polished_blackstone
fill 104 218 370 104 218 385 minecraft:polished_blackstone
setblock 104 218 386 minecraft:iron_block
setblock 104 218 387 minecraft:black_concrete
fill 104 218 388 108 218 391 minecraft:iron_block
fill 104 218 393 108 218 396 minecraft:iron_block
setblock 104 218 397 minecraft:black_concrete
setblock 104 218 398 minecraft:iron_block
fill 104 218 399 104 218 410 minecraft:polished_blackstone
fill 105 218 370 105 218 384 minecraft:polished_blackstone
fill 105 218 385 105 218 386 minecraft:black_concrete
fill 105 218 387 119 218 387 minecraft:iron_block
fill 105 218 397 119 218 397 minecraft:iron_block
fill 105 218 398 105 218 399 minecraft:black_concrete
fill 105 218 400 105 218 410 minecraft:polished_blackstone
fill 106 218 370 107 218 383 minecraft:polished_blackstone
setblock 106 218 384 minecraft:iron_block
setblock 106 218 385 minecraft:black_concrete
fill 106 218 386 118 218 386 minecraft:iron_block
fill 106 218 398 118 218 398 minecraft:iron_block
setblock 106 218 399 minecraft:black_concrete
setblock 106 218 400 minecraft:iron_block
fill 106 218 401 107 218 410 minecraft:polished_blackstone
setblock 107 218 384 minecraft:black_concrete
fill 107 218 385 117 218 385 minecraft:iron_block
fill 107 218 399 117 218 399 minecraft:iron_block
setblock 107 218 400 minecraft:black_concrete
fill 108 218 370 111 218 382 minecraft:polished_blackstone
fill 108 218 383 111 218 383 minecraft:black_concrete
fill 108 218 384 116 218 384 minecraft:iron_block
fill 108 218 400 116 218 400 minecraft:iron_block
fill 108 218 401 111 218 401 minecraft:black_concrete
fill 108 218 402 111 218 410 minecraft:polished_blackstone
fill 109 218 388 109 218 389 minecraft:iron_block
fill 109 218 390 109 218 394 minecraft:shroomlight
fill 109 218 395 109 218 396 minecraft:iron_block
fill 110 218 388 120 218 388 minecraft:iron_block
fill 110 218 389 110 218 390 minecraft:shroomlight
fill 110 218 394 110 218 395 minecraft:shroomlight
fill 110 218 396 120 218 396 minecraft:iron_block
fill 111 218 389 114 218 389 minecraft:shroomlight
fill 111 218 395 114 218 395 minecraft:shroomlight
fill 112 218 370 135 218 381 minecraft:polished_blackstone
fill 112 218 382 112 218 383 minecraft:iron_block
fill 112 218 401 112 218 402 minecraft:iron_block
fill 112 218 403 135 218 410 minecraft:polished_blackstone
fill 113 218 382 135 218 382 minecraft:polished_blackstone
fill 113 218 383 116 218 383 minecraft:black_concrete
fill 113 218 401 116 218 401 minecraft:black_concrete
fill 113 218 402 135 218 402 minecraft:polished_blackstone
fill 114 218 390 115 218 390 minecraft:shroomlight
fill 114 218 394 115 218 394 minecraft:shroomlight
fill 115 218 389 120 218 389 minecraft:iron_block
fill 115 218 391 115 218 393 minecraft:shroomlight
fill 115 218 395 120 218 395 minecraft:iron_block
fill 116 218 390 120 218 394 minecraft:iron_block
fill 117 218 383 135 218 383 minecraft:polished_blackstone
setblock 117 218 384 minecraft:black_concrete
setblock 117 218 400 minecraft:black_concrete
fill 117 218 401 135 218 401 minecraft:polished_blackstone
setblock 118 218 384 minecraft:iron_block
fill 118 218 385 119 218 385 minecraft:black_concrete
fill 118 218 399 119 218 399 minecraft:black_concrete
setblock 118 218 400 minecraft:iron_block
fill 119 218 384 135 218 384 minecraft:polished_blackstone
setblock 119 218 386 minecraft:black_concrete
setblock 119 218 398 minecraft:black_concrete
fill 119 218 400 135 218 400 minecraft:polished_blackstone
fill 120 218 385 135 218 385 minecraft:polished_blackstone
setblock 120 218 386 minecraft:iron_block
setblock 120 218 387 minecraft:black_concrete
setblock 120 218 397 minecraft:black_concrete
setblock 120 218 398 minecraft:iron_block
fill 120 218 399 135 218 399 minecraft:polished_blackstone
fill 121 218 386 135 218 387 minecraft:polished_blackstone
fill 121 218 388 121 218 391 minecraft:black_concrete
fill 121 218 392 122 218 392 minecraft:iron_block
fill 121 218 393 121 218 396 minecraft:black_concrete
fill 121 218 397 135 218 398 minecraft:polished_blackstone
fill 122 218 388 135 218 391 minecraft:polished_blackstone
fill 122 218 393 135 218 396 minecraft:polished_blackstone
fill 123 218 392 135 218 392 minecraft:polished_blackstone
fill 95 222 370 97 267 370 minecraft:polished_blackstone_bricks
fill 95 222 380 95 267 382 minecraft:polished_blackstone_bricks
fill 95 222 392 95 267 394 minecraft:polished_blackstone_bricks
fill 95 222 404 95 267 406 minecraft:polished_blackstone_bricks
fill 96 222 379 96 225 381 minecraft:polished_blackstone_bricks
fill 96 222 391 96 225 393 minecraft:polished_blackstone_bricks
fill 96 222 403 96 225 405 minecraft:polished_blackstone_bricks
fill 101 222 410 103 267 410 minecraft:polished_blackstone_bricks
fill 102 222 409 104 225 409 minecraft:polished_blackstone_bricks
fill 106 222 371 108 225 371 minecraft:polished_blackstone_bricks
fill 107 222 370 109 267 370 minecraft:polished_blackstone_bricks
fill 113 222 410 115 267 410 minecraft:polished_blackstone_bricks
fill 114 222 409 116 225 409 minecraft:polished_blackstone_bricks
fill 118 222 371 120 225 371 minecraft:polished_blackstone_bricks
fill 119 222 370 121 267 370 minecraft:polished_blackstone_bricks
fill 125 222 410 127 267 410 minecraft:polished_blackstone_bricks
fill 126 222 409 128 225 409 minecraft:polished_blackstone_bricks
fill 130 222 371 132 225 371 minecraft:polished_blackstone_bricks
fill 131 222 370 133 267 370 minecraft:polished_blackstone_bricks
fill 134 222 379 134 225 381 minecraft:polished_blackstone_bricks
fill 134 222 391 134 225 393 minecraft:polished_blackstone_bricks
fill 134 222 403 134 225 405 minecraft:polished_blackstone_bricks
fill 135 222 378 135 267 380 minecraft:polished_blackstone_bricks
fill 135 222 390 135 267 392 minecraft:polished_blackstone_bricks
fill 135 222 402 135 267 404 minecraft:polished_blackstone_bricks
setblock 97 223 372 minecraft:light[level=14]
setblock 97 223 380 minecraft:light[level=14]
setblock 97 223 388 minecraft:light[level=14]
setblock 97 223 396 minecraft:light[level=14]
setblock 97 223 404 minecraft:light[level=14]
setblock 105 223 372 minecraft:light[level=14]
setblock 105 223 380 minecraft:light[level=14]
setblock 105 223 388 minecraft:light[level=14]
setblock 105 223 396 minecraft:light[level=14]
setblock 105 223 404 minecraft:light[level=14]
setblock 113 223 372 minecraft:light[level=14]
setblock 113 223 380 minecraft:light[level=14]
setblock 113 223 388 minecraft:light[level=14]
setblock 113 223 396 minecraft:light[level=14]
setblock 113 223 404 minecraft:light[level=14]
fill 114 223 398 115 224 399 minecraft:magma_block
fill 115 223 397 115 224 397 minecraft:magma_block
setblock 121 223 372 minecraft:light[level=14]
setblock 121 223 380 minecraft:light[level=14]
setblock 121 223 388 minecraft:light[level=14]
setblock 121 223 396 minecraft:light[level=14]
setblock 121 223 404 minecraft:light[level=14]
fill 123 223 405 123 224 406 minecraft:orange_concrete
setblock 129 223 372 minecraft:light[level=14]
setblock 129 223 380 minecraft:light[level=14]
setblock 129 223 388 minecraft:light[level=14]
setblock 129 223 396 minecraft:light[level=14]
setblock 129 223 404 minecraft:light[level=14]
fill 95 225 373 95 225 378 minecraft:blackstone
fill 95 225 385 95 225 390 minecraft:blackstone
fill 95 225 397 95 225 402 minecraft:blackstone
fill 95 225 409 95 225 410 minecraft:blackstone
fill 96 225 410 99 225 410 minecraft:blackstone
fill 99 225 370 104 225 370 minecraft:blackstone
fill 106 225 410 111 225 410 minecraft:blackstone
fill 111 225 370 116 225 370 minecraft:blackstone
fill 118 225 410 123 225 410 minecraft:blackstone
fill 123 225 370 128 225 370 minecraft:blackstone
fill 130 225 410 135 225 410 minecraft:blackstone
fill 135 225 370 135 225 375 minecraft:blackstone
fill 135 225 382 135 225 387 minecraft:blackstone
fill 135 225 394 135 225 399 minecraft:blackstone
fill 135 225 406 135 225 409 minecraft:blackstone
fill 94 226 375 94 231 378 minecraft:shroomlight
fill 94 226 387 94 231 390 minecraft:shroomlight
fill 94 226 399 94 231 402 minecraft:shroomlight
fill 94 226 411 97 231 411 minecraft:shroomlight
fill 101 226 369 104 231 369 minecraft:shroomlight
fill 106 226 411 109 231 411 minecraft:shroomlight
fill 113 226 369 116 231 369 minecraft:shroomlight
fill 118 226 411 121 231 411 minecraft:shroomlight
fill 125 226 369 128 231 369 minecraft:shroomlight
fill 130 226 411 133 231 411 minecraft:shroomlight
fill 136 226 370 136 231 373 minecraft:shroomlight
fill 136 226 382 136 231 385 minecraft:shroomlight
fill 136 226 394 136 231 397 minecraft:shroomlight
fill 136 226 406 136 231 409 minecraft:shroomlight
setblock 97 231 372 minecraft:light[level=14]
setblock 97 231 380 minecraft:light[level=14]
setblock 97 231 388 minecraft:light[level=14]
setblock 97 231 396 minecraft:light[level=14]
setblock 97 231 404 minecraft:light[level=14]
setblock 105 231 372 minecraft:light[level=14]
setblock 105 231 380 minecraft:light[level=14]
setblock 105 231 388 minecraft:light[level=14]
setblock 105 231 396 minecraft:light[level=14]
setblock 105 231 404 minecraft:light[level=14]
setblock 113 231 372 minecraft:light[level=14]
setblock 113 231 380 minecraft:light[level=14]
setblock 113 231 388 minecraft:light[level=14]
setblock 113 231 396 minecraft:light[level=14]
setblock 113 231 404 minecraft:light[level=14]
setblock 121 231 372 minecraft:light[level=14]
setblock 121 231 380 minecraft:light[level=14]
setblock 121 231 388 minecraft:light[level=14]
setblock 121 231 396 minecraft:light[level=14]
setblock 121 231 404 minecraft:light[level=14]
setblock 129 231 372 minecraft:light[level=14]
setblock 129 231 380 minecraft:light[level=14]
setblock 129 231 388 minecraft:light[level=14]
setblock 129 231 396 minecraft:light[level=14]
setblock 129 231 404 minecraft:light[level=14]
fill 94 232 375 94 245 375 minecraft:blackstone
fill 94 232 376 94 232 377 minecraft:shroomlight
fill 94 232 378 94 245 378 minecraft:blackstone
fill 94 232 387 94 245 387 minecraft:blackstone
fill 94 232 388 94 232 389 minecraft:shroomlight
fill 94 232 390 94 245 390 minecraft:blackstone
fill 94 232 399 94 245 399 minecraft:blackstone
fill 94 232 400 94 232 401 minecraft:shroomlight
fill 94 232 402 94 245 402 minecraft:blackstone
fill 94 232 411 94 245 411 minecraft:blackstone
fill 95 232 411 96 232 411 minecraft:shroomlight
fill 97 232 411 97 245 411 minecraft:blackstone
fill 101 232 369 101 245 369 minecraft:blackstone
fill 102 232 369 103 232 369 minecraft:shroomlight
fill 104 232 369 104 245 369 minecraft:blackstone
fill 106 232 411 106 245 411 minecraft:blackstone
fill 107 232 411 108 232 411 minecraft:shroomlight
fill 109 232 411 109 245 411 minecraft:blackstone
fill 113 232 369 113 245 369 minecraft:blackstone
fill 114 232 369 115 232 369 minecraft:shroomlight
fill 116 232 369 116 245 369 minecraft:blackstone
fill 118 232 411 118 245 411 minecraft:blackstone
fill 119 232 411 120 232 411 minecraft:shroomlight
fill 121 232 411 121 245 411 minecraft:blackstone
fill 125 232 369 125 245 369 minecraft:blackstone
fill 126 232 369 127 232 369 minecraft:shroomlight
fill 128 232 369 128 245 369 minecraft:blackstone
fill 130 232 411 130 245 411 minecraft:blackstone
fill 131 232 411 132 232 411 minecraft:shroomlight
fill 133 232 411 133 245 411 minecraft:blackstone
fill 136 232 370 136 245 370 minecraft:blackstone
fill 136 232 371 136 232 372 minecraft:shroomlight
fill 136 232 373 136 245 373 minecraft:blackstone
fill 136 232 382 136 245 382 minecraft:blackstone
fill 136 232 383 136 232 384 minecraft:shroomlight
fill 136 232 385 136 245 385 minecraft:blackstone
fill 136 232 394 136 245 394 minecraft:blackstone
fill 136 232 395 136 232 396 minecraft:shroomlight
fill 136 232 397 136 245 397 minecraft:blackstone
fill 136 232 406 136 245 406 minecraft:blackstone
fill 136 232 407 136 232 408 minecraft:shroomlight
fill 136 232 409 136 245 409 minecraft:blackstone
fill 94 233 376 94 245 377 minecraft:blackstone
fill 94 233 388 94 245 389 minecraft:blackstone
fill 94 233 400 94 245 401 minecraft:blackstone
fill 95 233 411 96 245 411 minecraft:blackstone
fill 102 233 369 103 245 369 minecraft:blackstone
fill 107 233 411 108 245 411 minecraft:blackstone
fill 114 233 369 115 245 369 minecraft:blackstone
fill 119 233 411 120 245 411 minecraft:blackstone
fill 126 233 369 127 245 369 minecraft:blackstone
fill 131 233 383 132 234 384 minecraft:orange_concrete
fill 131 233 411 132 245 411 minecraft:blackstone
fill 136 233 371 136 245 372 minecraft:blackstone
fill 136 233 383 136 245 384 minecraft:blackstone
fill 136 233 395 136 245 396 minecraft:blackstone
fill 136 233 407 136 245 408 minecraft:blackstone
fill 121 234 396 122 235 397 minecraft:magma_block
fill 108 237 382 109 267 384 minecraft:polished_blackstone_bricks
fill 110 237 383 110 262 383 minecraft:polished_blackstone_bricks
fill 107 238 383 107 239 383 minecraft:blackstone
fill 109 238 381 109 239 381 minecraft:blackstone
fill 110 238 382 110 239 382 minecraft:blackstone
fill 110 238 384 110 239 384 minecraft:blackstone
setblock 97 239 372 minecraft:light[level=14]
setblock 97 239 380 minecraft:light[level=14]
setblock 97 239 388 minecraft:light[level=14]
setblock 97 239 396 minecraft:light[level=14]
setblock 97 239 404 minecraft:light[level=14]
setblock 105 239 372 minecraft:light[level=14]
setblock 105 239 380 minecraft:light[level=14]
setblock 105 239 388 minecraft:light[level=14]
setblock 105 239 396 minecraft:light[level=14]
setblock 105 239 404 minecraft:light[level=14]
setblock 107 239 382 minecraft:blackstone
setblock 107 239 384 minecraft:blackstone
setblock 108 239 381 minecraft:blackstone
fill 108 239 385 110 239 385 minecraft:blackstone
setblock 110 239 381 minecraft:blackstone
fill 111 239 382 111 239 384 minecraft:blackstone
setblock 113 239 372 minecraft:light[level=14]
setblock 113 239 380 minecraft:light[level=14]
setblock 113 239 388 minecraft:light[level=14]
setblock 113 239 396 minecraft:light[level=14]
setblock 113 239 404 minecraft:light[level=14]
setblock 121 239 372 minecraft:light[level=14]
setblock 121 239 380 minecraft:light[level=14]
setblock 121 239 388 minecraft:light[level=14]
setblock 121 239 396 minecraft:light[level=14]
setblock 121 239 404 minecraft:light[level=14]
fill 122 239 395 122 240 396 minecraft:orange_concrete
setblock 129 239 372 minecraft:light[level=14]
setblock 129 239 380 minecraft:light[level=14]
setblock 129 239 388 minecraft:light[level=14]
setblock 129 239 396 minecraft:light[level=14]
setblock 129 239 404 minecraft:light[level=14]
fill 96 240 379 96 245 381 minecraft:polished_blackstone_bricks
fill 96 240 391 96 245 393 minecraft:polished_blackstone_bricks
fill 96 240 403 96 245 405 minecraft:polished_blackstone_bricks
fill 102 240 409 104 245 409 minecraft:polished_blackstone_bricks
fill 106 240 371 108 245 371 minecraft:polished_blackstone_bricks
fill 114 240 409 116 245 409 minecraft:polished_blackstone_bricks
fill 118 240 371 120 245 371 minecraft:polished_blackstone_bricks
fill 126 240 409 128 245 409 minecraft:polished_blackstone_bricks
fill 130 240 371 132 245 371 minecraft:polished_blackstone_bricks
fill 134 240 379 134 245 381 minecraft:polished_blackstone_bricks
fill 134 240 391 134 245 393 minecraft:polished_blackstone_bricks
fill 134 240 403 134 245 405 minecraft:polished_blackstone_bricks
fill 95 245 373 95 245 378 minecraft:blackstone
fill 95 245 385 95 245 390 minecraft:blackstone
fill 95 245 397 95 245 402 minecraft:blackstone
fill 95 245 409 95 245 410 minecraft:blackstone
fill 96 245 410 99 245 410 minecraft:blackstone
fill 99 245 370 104 245 370 minecraft:blackstone
fill 106 245 410 111 245 410 minecraft:blackstone
fill 111 245 370 116 245 370 minecraft:blackstone
fill 118 245 410 123 245 410 minecraft:blackstone
fill 123 245 370 128 245 370 minecraft:blackstone
fill 130 245 410 135 245 410 minecraft:blackstone
fill 135 245 370 135 245 375 minecraft:blackstone
fill 135 245 382 135 245 387 minecraft:blackstone
fill 135 245 394 135 245 399 minecraft:blackstone
fill 135 245 406 135 245 409 minecraft:blackstone
fill 94 246 375 94 251 378 minecraft:shroomlight
fill 94 246 387 94 251 390 minecraft:shroomlight
fill 94 246 399 94 251 402 minecraft:shroomlight
fill 94 246 411 97 251 411 minecraft:shroomlight
fill 101 246 369 104 251 369 minecraft:shroomlight
fill 106 246 411 109 251 411 minecraft:shroomlight
fill 113 246 369 116 251 369 minecraft:shroomlight
fill 118 246 411 121 251 411 minecraft:shroomlight
fill 125 246 369 128 251 369 minecraft:shroomlight
fill 130 246 411 133 251 411 minecraft:shroomlight
fill 136 246 370 136 251 373 minecraft:shroomlight
fill 136 246 382 136 251 385 minecraft:shroomlight
fill 136 246 394 136 251 397 minecraft:shroomlight
fill 136 246 406 136 251 409 minecraft:shroomlight
setblock 97 247 372 minecraft:light[level=14]
setblock 97 247 380 minecraft:light[level=14]
setblock 97 247 388 minecraft:light[level=14]
setblock 97 247 396 minecraft:light[level=14]
setblock 97 247 404 minecraft:light[level=14]
setblock 105 247 372 minecraft:light[level=14]
setblock 105 247 380 minecraft:light[level=14]
setblock 105 247 388 minecraft:light[level=14]
setblock 105 247 396 minecraft:light[level=14]
setblock 105 247 404 minecraft:light[level=14]
setblock 113 247 372 minecraft:light[level=14]
setblock 113 247 380 minecraft:light[level=14]
setblock 113 247 396 minecraft:light[level=14]
setblock 113 247 404 minecraft:light[level=14]
setblock 121 247 372 minecraft:light[level=14]
setblock 121 247 380 minecraft:light[level=14]
setblock 121 247 388 minecraft:light[level=14]
setblock 121 247 396 minecraft:light[level=14]
setblock 121 247 404 minecraft:light[level=14]
setblock 129 247 372 minecraft:light[level=14]
setblock 129 247 380 minecraft:light[level=14]
setblock 129 247 388 minecraft:light[level=14]
setblock 129 247 396 minecraft:light[level=14]
setblock 129 247 404 minecraft:light[level=14]
fill 99 249 373 99 258 373 minecraft:netherite_block
fill 129 251 402 129 260 402 minecraft:netherite_block
fill 94 252 375 94 265 375 minecraft:blackstone
fill 94 252 376 94 252 377 minecraft:shroomlight
fill 94 252 378 94 265 378 minecraft:blackstone
fill 94 252 387 94 265 387 minecraft:blackstone
fill 94 252 388 94 252 389 minecraft:shroomlight
fill 94 252 390 94 265 390 minecraft:blackstone
fill 94 252 399 94 265 399 minecraft:blackstone
fill 94 252 400 94 252 401 minecraft:shroomlight
fill 94 252 402 94 265 402 minecraft:blackstone
fill 94 252 411 94 265 411 minecraft:blackstone
fill 95 252 411 96 252 411 minecraft:shroomlight
fill 97 252 411 97 265 411 minecraft:blackstone
fill 101 252 369 101 265 369 minecraft:blackstone
fill 102 252 369 103 252 369 minecraft:shroomlight
fill 104 252 369 104 265 369 minecraft:blackstone
fill 106 252 411 106 265 411 minecraft:blackstone
fill 107 252 411 108 252 411 minecraft:shroomlight
fill 109 252 411 109 265 411 minecraft:blackstone
fill 113 252 369 113 265 369 minecraft:blackstone
fill 114 252 369 115 252 369 minecraft:shroomlight
fill 116 252 369 116 265 369 minecraft:blackstone
fill 118 252 411 118 265 411 minecraft:blackstone
fill 119 252 411 120 252 411 minecraft:shroomlight
fill 121 252 411 121 265 411 minecraft:blackstone
fill 125 252 369 125 265 369 minecraft:blackstone
fill 126 252 369 127 252 369 minecraft:shroomlight
fill 128 252 369 128 265 369 minecraft:blackstone
fill 130 252 411 130 265 411 minecraft:blackstone
fill 131 252 411 132 252 411 minecraft:shroomlight
fill 133 252 411 133 265 411 minecraft:blackstone
fill 136 252 370 136 265 370 minecraft:blackstone
fill 136 252 371 136 252 372 minecraft:shroomlight
fill 136 252 373 136 265 373 minecraft:blackstone
fill 136 252 382 136 265 382 minecraft:blackstone
fill 136 252 383 136 252 384 minecraft:shroomlight
fill 136 252 385 136 265 385 minecraft:blackstone
fill 136 252 394 136 265 394 minecraft:blackstone
fill 136 252 395 136 252 396 minecraft:shroomlight
fill 136 252 397 136 265 397 minecraft:blackstone
fill 136 252 406 136 265 406 minecraft:blackstone
fill 136 252 407 136 252 408 minecraft:shroomlight
fill 136 252 409 136 265 409 minecraft:blackstone
fill 94 253 376 94 265 377 minecraft:blackstone
fill 94 253 388 94 265 389 minecraft:blackstone
fill 94 253 400 94 265 401 minecraft:blackstone
fill 95 253 411 96 265 411 minecraft:blackstone
fill 102 253 369 103 265 369 minecraft:blackstone
fill 107 253 411 108 265 411 minecraft:blackstone
fill 114 253 369 115 265 369 minecraft:blackstone
fill 119 253 411 120 265 411 minecraft:blackstone
fill 126 253 369 127 265 369 minecraft:blackstone
fill 131 253 411 132 265 411 minecraft:blackstone
fill 136 253 371 136 265 372 minecraft:blackstone
fill 136 253 383 136 265 384 minecraft:blackstone
fill 136 253 395 136 265 396 minecraft:blackstone
fill 136 253 407 136 265 408 minecraft:blackstone
setblock 97 255 372 minecraft:light[level=14]
setblock 97 255 380 minecraft:light[level=14]
setblock 97 255 388 minecraft:light[level=14]
setblock 97 255 396 minecraft:light[level=14]
setblock 97 255 404 minecraft:light[level=14]
setblock 105 255 372 minecraft:light[level=14]
setblock 105 255 380 minecraft:light[level=14]
setblock 105 255 388 minecraft:light[level=14]
setblock 105 255 396 minecraft:light[level=14]
setblock 105 255 404 minecraft:light[level=14]
setblock 113 255 372 minecraft:light[level=14]
setblock 113 255 380 minecraft:light[level=14]
setblock 113 255 396 minecraft:light[level=14]
setblock 113 255 404 minecraft:light[level=14]
setblock 121 255 372 minecraft:light[level=14]
setblock 121 255 380 minecraft:light[level=14]
setblock 121 255 388 minecraft:light[level=14]
setblock 121 255 396 minecraft:light[level=14]
setblock 121 255 404 minecraft:light[level=14]
setblock 129 255 372 minecraft:light[level=14]
setblock 129 255 380 minecraft:light[level=14]
setblock 129 255 388 minecraft:light[level=14]
setblock 129 255 396 minecraft:light[level=14]
setblock 129 255 404 minecraft:light[level=14]
fill 121 259 371 135 259 371 minecraft:polished_blackstone_bricks
fill 95 260 371 126 260 371 minecraft:polished_blackstone_bricks
fill 95 260 378 97 261 378 minecraft:polished_blackstone_bricks
fill 95 260 385 98 261 385 minecraft:polished_blackstone_bricks
fill 95 260 399 135 260 399 minecraft:polished_blackstone_bricks
fill 96 260 379 96 265 381 minecraft:polished_blackstone_bricks
fill 96 260 391 96 265 393 minecraft:polished_blackstone_bricks
fill 96 260 403 96 261 406 minecraft:polished_blackstone_bricks
fill 97 260 392 101 261 392 minecraft:polished_blackstone_bricks
fill 97 260 406 100 261 406 minecraft:polished_blackstone_bricks
fill 102 260 409 104 265 409 minecraft:polished_blackstone_bricks
fill 114 260 409 116 265 409 minecraft:polished_blackstone_bricks
fill 126 260 409 128 265 409 minecraft:polished_blackstone_bricks
fill 130 260 371 132 265 371 minecraft:polished_blackstone_bricks
fill 134 260 379 134 265 381 minecraft:polished_blackstone_bricks
fill 134 260 391 134 265 393 minecraft:polished_blackstone_bricks
fill 134 260 403 134 265 405 minecraft:polished_blackstone_bricks
fill 95 261 371 97 261 371 minecraft:polished_blackstone_bricks
fill 95 261 399 100 261 399 minecraft:polished_blackstone_bricks
fill 96 261 409 96 262 409 minecraft:netherite_block
fill 98 261 378 129 261 378 minecraft:polished_blackstone_bricks
fill 99 261 385 134 261 385 minecraft:polished_blackstone_bricks
fill 101 261 406 102 261 406 minecraft:polished_blackstone_bricks
fill 102 261 392 133 261 392 minecraft:polished_blackstone_bricks
fill 103 261 400 103 261 408 minecraft:netherite_block
fill 104 261 406 135 261 406 minecraft:polished_blackstone_bricks
fill 106 261 371 108 265 371 minecraft:polished_blackstone_bricks
fill 118 261 371 120 265 371 minecraft:polished_blackstone_bricks
fill 96 262 371 96 262 378 minecraft:netherite_block
fill 96 262 382 96 262 390 minecraft:netherite_block
fill 96 262 394 96 262 402 minecraft:netherite_block
fill 96 262 403 96 265 405 minecraft:polished_blackstone_bricks
fill 96 262 406 96 262 408 minecraft:netherite_block
fill 103 262 370 103 262 405 minecraft:netherite_block
fill 110 262 370 110 263 372 minecraft:netherite_block
fill 117 262 370 117 263 377 minecraft:netherite_block
fill 123 262 378 134 262 378 minecraft:polished_blackstone_bricks
fill 124 262 370 124 263 372 minecraft:netherite_block
fill 131 262 372 131 262 377 minecraft:netherite_block
fill 131 262 379 131 262 384 minecraft:netherite_block
fill 131 262 385 134 262 385 minecraft:polished_blackstone_bricks
fill 131 262 386 131 262 410 minecraft:netherite_block
fill 96 263 371 96 263 373 minecraft:netherite_block
setblock 97 263 372 minecraft:light[level=14]
setblock 97 263 380 minecraft:light[level=14]
setblock 97 263 388 minecraft:light[level=14]
setblock 97 263 396 minecraft:light[level=14]
setblock 97 263 404 minecraft:light[level=14]
fill 103 263 370 103 263 372 minecraft:netherite_block
setblock 105 263 372 minecraft:light[level=14]
setblock 105 263 380 minecraft:light[level=14]
setblock 105 263 388 minecraft:light[level=14]
setblock 105 263 396 minecraft:light[level=14]
setblock 105 263 404 minecraft:light[level=14]
fill 110 263 373 110 263 404 minecraft:netherite_block
setblock 113 263 372 minecraft:light[level=14]
setblock 113 263 380 minecraft:light[level=14]
setblock 113 263 396 minecraft:light[level=14]
setblock 113 263 404 minecraft:light[level=14]
fill 117 263 378 117 263 410 minecraft:netherite_block
setblock 121 263 372 minecraft:light[level=14]
setblock 121 263 380 minecraft:light[level=14]
setblock 121 263 388 minecraft:light[level=14]
setblock 121 263 396 minecraft:light[level=14]
setblock 121 263 404 minecraft:light[level=14]
fill 124 263 373 124 263 402 minecraft:netherite_block
setblock 129 263 372 minecraft:light[level=14]
setblock 129 263 380 minecraft:light[level=14]
setblock 129 263 388 minecraft:light[level=14]
setblock 129 263 396 minecraft:light[level=14]
setblock 129 263 404 minecraft:light[level=14]
fill 131 263 372 131 263 376 minecraft:netherite_block
fill 107 264 381 107 264 384 minecraft:orange_concrete
fill 108 264 381 110 265 381 minecraft:orange_concrete
fill 108 264 385 110 264 385 minecraft:orange_concrete
fill 110 264 382 111 264 382 minecraft:orange_concrete
fill 110 264 383 110 267 383 minecraft:polished_blackstone_bricks
fill 110 264 384 111 264 384 minecraft:orange_concrete
fill 110 264 399 110 264 410 minecraft:netherite_block
fill 111 264 383 111 265 383 minecraft:orange_concrete
fill 124 264 397 124 264 410 minecraft:netherite_block
fill 95 265 373 95 265 378 minecraft:blackstone
fill 95 265 385 95 265 390 minecraft:blackstone
fill 95 265 397 95 265 402 minecraft:blackstone
fill 95 265 409 95 265 410 minecraft:blackstone
fill 96 265 410 99 265 410 minecraft:blackstone
fill 99 265 370 104 265 370 minecraft:blackstone
fill 106 265 410 111 265 410 minecraft:blackstone
fill 107 265 382 107 265 384 minecraft:orange_concrete
fill 108 265 385 109 265 385 minecraft:orange_concrete
fill 110 265 382 110 266 382 minecraft:orange_concrete
fill 110 265 384 110 266 384 minecraft:orange_concrete
fill 111 265 370 116 265 370 minecraft:blackstone
fill 118 265 410 123 265 410 minecraft:blackstone
fill 123 265 370 128 265 370 minecraft:blackstone
fill 130 265 410 135 265 410 minecraft:blackstone
fill 135 265 370 135 265 375 minecraft:blackstone
fill 135 265 382 135 265 387 minecraft:blackstone
fill 135 265 394 135 265 399 minecraft:blackstone
fill 135 265 406 135 265 409 minecraft:blackstone
fill 94 266 375 94 267 378 minecraft:shroomlight
fill 94 266 387 94 267 390 minecraft:shroomlight
fill 94 266 399 94 267 402 minecraft:shroomlight
fill 94 266 411 97 267 411 minecraft:shroomlight
fill 101 266 369 104 267 369 minecraft:shroomlight
fill 106 266 411 109 267 411 minecraft:shroomlight
setblock 107 266 383 minecraft:orange_concrete
fill 113 266 369 116 267 369 minecraft:shroomlight
fill 118 266 411 121 267 411 minecraft:shroomlight
fill 125 266 369 128 267 369 minecraft:shroomlight
fill 130 266 411 133 267 411 minecraft:shroomlight
fill 136 266 370 136 267 373 minecraft:shroomlight
fill 136 266 382 136 267 385 minecraft:shroomlight
fill 136 266 394 136 267 397 minecraft:shroomlight
fill 136 266 406 136 267 409 minecraft:shroomlight
fill 94 268 375 94 285 378 minecraft:blackstone
fill 94 268 387 94 285 390 minecraft:blackstone
fill 94 268 399 94 285 402 minecraft:blackstone
fill 94 268 411 97 285 411 minecraft:blackstone
fill 101 268 369 104 285 369 minecraft:blackstone
fill 106 268 411 109 285 411 minecraft:blackstone
fill 113 268 369 116 285 369 minecraft:blackstone
fill 118 268 411 121 285 411 minecraft:blackstone
fill 125 268 369 128 285 369 minecraft:blackstone
fill 130 268 411 133 285 411 minecraft:blackstone
fill 136 268 370 136 285 373 minecraft:blackstone
fill 136 268 382 136 285 385 minecraft:blackstone
fill 136 268 394 136 285 397 minecraft:blackstone
fill 136 268 406 136 285 409 minecraft:blackstone
setblock 97 271 372 minecraft:light[level=14]
setblock 97 271 380 minecraft:light[level=14]
setblock 97 271 388 minecraft:light[level=14]
setblock 97 271 396 minecraft:light[level=14]
setblock 97 271 404 minecraft:light[level=14]
setblock 105 271 372 minecraft:light[level=14]
setblock 105 271 380 minecraft:light[level=14]
setblock 105 271 388 minecraft:light[level=14]
setblock 105 271 396 minecraft:light[level=14]
setblock 105 271 404 minecraft:light[level=14]
setblock 113 271 372 minecraft:light[level=14]
setblock 113 271 380 minecraft:light[level=14]
setblock 113 271 396 minecraft:light[level=14]
setblock 113 271 404 minecraft:light[level=14]
setblock 121 271 372 minecraft:light[level=14]
setblock 121 271 380 minecraft:light[level=14]
setblock 121 271 388 minecraft:light[level=14]
setblock 121 271 396 minecraft:light[level=14]
setblock 121 271 404 minecraft:light[level=14]
setblock 129 271 372 minecraft:light[level=14]
setblock 129 271 380 minecraft:light[level=14]
setblock 129 271 388 minecraft:light[level=14]
setblock 129 271 396 minecraft:light[level=14]
setblock 129 271 404 minecraft:light[level=14]
fill 95 273 376 110 273 404 minecraft:basalt
fill 96 273 374 134 273 375 minecraft:basalt
fill 96 273 405 134 273 406 minecraft:basalt
fill 97 273 373 133 273 373 minecraft:basalt
fill 97 273 407 133 273 407 minecraft:basalt
fill 98 273 372 132 273 372 minecraft:basalt
fill 98 273 408 132 273 408 minecraft:basalt
fill 99 273 371 131 273 371 minecraft:basalt
fill 99 273 409 131 273 409 minecraft:basalt
fill 101 273 370 129 274 370 minecraft:basalt
fill 101 273 410 129 274 410 minecraft:basalt
fill 111 273 376 111 273 387 minecraft:basalt
fill 111 273 389 111 273 404 minecraft:basalt
fill 112 273 376 113 273 385 minecraft:basalt
fill 112 273 391 113 273 404 minecraft:basalt
fill 114 273 376 135 273 384 minecraft:basalt
fill 114 273 392 135 273 404 minecraft:basalt
fill 115 273 385 135 273 385 minecraft:basalt
fill 115 273 391 135 273 391 minecraft:basalt
fill 117 273 386 135 273 387 minecraft:basalt
fill 117 273 389 135 273 390 minecraft:basalt
fill 118 273 388 135 273 388 minecraft:basalt
fill 95 274 376 95 274 404 minecraft:basalt
setblock 96 274 375 minecraft:basalt
fill 96 274 376 110 274 404 minecraft:blackstone
setblock 96 274 405 minecraft:basalt
setblock 97 274 374 minecraft:basalt
fill 97 274 375 133 274 375 minecraft:blackstone
fill 97 274 405 133 274 405 minecraft:blackstone
setblock 97 274 406 minecraft:basalt
fill 98 274 373 98 275 373 minecraft:basalt
fill 98 274 374 132 274 374 minecraft:blackstone
fill 98 274 406 132 274 406 minecraft:blackstone
fill 98 274 407 98 275 407 minecraft:basalt
setblock 99 274 372 minecraft:basalt
fill 99 274 373 131 274 373 minecraft:blackstone
fill 99 274 407 131 274 407 minecraft:blackstone
setblock 99 274 408 minecraft:basalt
setblock 100 274 371 minecraft:basalt
fill 100 274 372 130 274 372 minecraft:blackstone
fill 100 274 408 130 274 408 minecraft:blackstone
setblock 100 274 409 minecraft:basalt
fill 101 274 371 129 274 371 minecraft:blackstone
fill 101 274 409 129 274 409 minecraft:blackstone
fill 111 274 376 111 277 387 minecraft:blackstone
fill 111 274 389 111 277 404 minecraft:blackstone
fill 112 274 376 113 277 385 minecraft:blackstone
fill 112 274 391 113 277 404 minecraft:blackstone
fill 114 274 376 134 274 384 minecraft:blackstone
fill 114 274 392 134 274 404 minecraft:blackstone
fill 115 274 385 134 277 385 minecraft:blackstone
fill 115 274 391 134 277 391 minecraft:blackstone
fill 117 274 386 134 277 387 minecraft:blackstone
fill 117 274 389 134 277 390 minecraft:blackstone
fill 118 274 388 134 278 388 minecraft:blackstone
setblock 130 274 371 minecraft:basalt
setblock 130 274 409 minecraft:basalt
setblock 131 274 372 minecraft:basalt
setblock 131 274 408 minecraft:basalt
fill 132 274 373 132 275 373 minecraft:basalt
fill 132 274 407 132 275 407 minecraft:basalt
setblock 133 274 374 minecraft:basalt
setblock 133 274 406 minecraft:basalt
setblock 134 274 375 minecraft:basalt
setblock 134 274 405 minecraft:basalt
fill 135 274 376 135 274 404 minecraft:basalt
fill 95 275 377 95 275 403 minecraft:basalt
fill 96 275 376 96 276 376 minecraft:basalt
fill 96 275 377 110 275 403 minecraft:blackstone
fill 96 275 404 96 276 404 minecraft:basalt
fill 97 275 375 97 276 375 minecraft:basalt
fill 97 275 376 110 276 376 minecraft:blackstone
fill 97 275 404 110 276 404 minecraft:blackstone
fill 97 275 405 97 276 405 minecraft:basalt
fill 98 275 374 98 276 374 minecraft:basalt
fill 98 275 375 132 276 375 minecraft:blackstone
fill 98 275 405 132 276 405 minecraft:blackstone
fill 98 275 406 98 276 406 minecraft:basalt
fill 99 275 373 99 276 373 minecraft:basalt
fill 99 275 374 131 276 374 minecraft:blackstone
fill 99 275 406 131 276 406 minecraft:blackstone
fill 99 275 407 99 276 407 minecraft:basalt
fill 100 275 372 100 276 372 minecraft:basalt
fill 100 275 373 130 276 373 minecraft:blackstone
fill 100 275 407 130 276 407 minecraft:blackstone
fill 100 275 408 100 276 408 minecraft:basalt
fill 101 275 371 101 276 371 minecraft:basalt
fill 101 275 372 129 276 372 minecraft:blackstone
fill 101 275 408 129 276 408 minecraft:blackstone
fill 101 275 409 101 276 409 minecraft:basalt
fill 102 275 370 128 275 370 minecraft:basalt
fill 102 275 371 128 275 371 minecraft:blackstone
fill 102 275 409 128 275 409 minecraft:blackstone
fill 102 275 410 128 275 410 minecraft:basalt
fill 114 275 376 133 276 384 minecraft:blackstone
fill 114 275 392 133 276 404 minecraft:blackstone
fill 129 275 371 129 276 371 minecraft:basalt
fill 129 275 409 129 276 409 minecraft:basalt
fill 130 275 372 130 276 372 minecraft:basalt
fill 130 275 408 130 276 408 minecraft:basalt
fill 131 275 373 131 276 373 minecraft:basalt
fill 131 275 407 131 276 407 minecraft:basalt
fill 132 275 374 132 276 374 minecraft:basalt
fill 132 275 406 132 276 406 minecraft:basalt
fill 133 275 375 133 276 375 minecraft:basalt
fill 133 275 405 133 276 405 minecraft:basalt
fill 134 275 376 134 276 376 minecraft:basalt
fill 134 275 377 134 275 384 minecraft:blackstone
fill 134 275 392 134 275 403 minecraft:blackstone
fill 134 275 404 134 276 404 minecraft:basalt
fill 135 275 377 135 275 403 minecraft:basalt
fill 95 276 378 95 276 402 minecraft:basalt
fill 96 276 377 96 277 377 minecraft:basalt
fill 96 276 378 110 276 402 minecraft:blackstone
fill 96 276 403 96 277 403 minecraft:basalt
fill 97 276 377 110 277 377 minecraft:blackstone
fill 97 276 403 110 277 403 minecraft:blackstone
fill 102 276 371 102 277 371 minecraft:basalt
fill 102 276 409 102 277 409 minecraft:basalt
fill 103 276 370 127 276 370 minecraft:basalt
fill 103 276 371 127 276 371 minecraft:blackstone
fill 103 276 409 127 276 409 minecraft:blackstone
fill 103 276 410 127 276 410 minecraft:basalt
fill 128 276 371 128 277 371 minecraft:basalt
fill 128 276 409 128 277 409 minecraft:basalt
fill 134 276 377 134 277 377 minecraft:basalt
fill 134 276 378 134 276 384 minecraft:blackstone
fill 134 276 392 134 276 402 minecraft:blackstone
fill 134 276 403 134 277 403 minecraft:basalt
fill 135 276 378 135 276 402 minecraft:basalt
fill 95 277 379 95 277 401 minecraft:basalt
fill 96 277 378 96 278 378 minecraft:basalt
fill 96 277 379 110 277 401 minecraft:blackstone
fill 96 277 402 96 278 402 minecraft:basalt
setblock 97 277 376 minecraft:basalt
fill 97 277 378 110 278 378 minecraft:blackstone
fill 97 277 402 110 278 402 minecraft:blackstone
setblock 97 277 404 minecraft:basalt
setblock 98 277 375 minecraft:basalt
fill 98 277 376 110 277 376 minecraft:blackstone
fill 98 277 404 110 277 404 minecraft:blackstone
setblock 98 277 405 minecraft:basalt
fill 99 277 374 99 278 374 minecraft:basalt
fill 99 277 375 131 277 375 minecraft:blackstone
fill 99 277 405 131 277 405 minecraft:blackstone
fill 99 277 406 99 278 406 minecraft:basalt
setblock 100 277 373 minecraft:basalt
fill 100 277 374 130 277 374 minecraft:blackstone
fill 100 277 406 130 277 406 minecraft:blackstone
setblock 100 277 407 minecraft:basalt
setblock 101 277 372 minecraft:basalt
fill 101 277 373 129 277 373 minecraft:blackstone
fill 101 277 407 129 277 407 minecraft:blackstone
setblock 101 277 408 minecraft:basalt
fill 102 277 372 128 277 372 minecraft:blackstone
fill 102 277 408 128 277 408 minecraft:blackstone
fill 103 277 371 103 278 371 minecraft:basalt
fill 103 277 409 103 278 409 minecraft:basalt
fill 104 277 370 126 277 370 minecraft:basalt
fill 104 277 371 126 277 371 minecraft:blackstone
fill 104 277 409 126 277 409 minecraft:blackstone
fill 104 277 410 126 277 410 minecraft:basalt
fill 114 277 376 132 277 384 minecraft:blackstone
fill 114 277 392 132 277 404 minecraft:blackstone
fill 127 277 371 127 278 371 minecraft:basalt
fill 127 277 409 127 278 409 minecraft:basalt
setblock 129 277 372 minecraft:basalt
setblock 129 277 408 minecraft:basalt
setblock 130 277 373 minecraft:basalt
setblock 130 277 407 minecraft:basalt
fill 131 277 374 131 278 374 minecraft:basalt
fill 131 277 406 131 278 406 minecraft:basalt
setblock 132 277 375 minecraft:basalt
setblock 132 277 405 minecraft:basalt
setblock 133 277 376 minecraft:basalt
fill 133 277 377 133 277 384 minecraft:blackstone
fill 133 277 392 133 277 403 minecraft:blackstone
setblock 133 277 404 minecraft:basalt
fill 134 277 378 134 278 378 minecraft:basalt
fill 134 277 379 134 277 384 minecraft:blackstone
fill 134 277 392 134 277 401 minecraft:blackstone
fill 134 277 402 134 278 402 minecraft:basalt
fill 135 277 379 135 277 401 minecraft:basalt
fill 95 278 380 95 278 400 minecraft:basalt
fill 96 278 379 96 279 379 minecraft:basalt
fill 96 278 380 110 278 400 minecraft:blackstone
fill 96 278 401 96 279 401 minecraft:basalt
setblock 97 278 377 minecraft:basalt
fill 97 278 379 133 279 379 minecraft:blackstone
fill 97 278 401 133 279 401 minecraft:blackstone
setblock 97 278 403 minecraft:basalt
fill 98 278 376 98 279 376 minecraft:basalt
fill 98 278 377 132 278 377 minecraft:blackstone
fill 98 278 403 132 278 403 minecraft:blackstone
fill 98 278 404 98 279 404 minecraft:basalt
fill 99 278 375 99 279 375 minecraft:basalt
fill 99 278 376 131 279 376 minecraft:blackstone
fill 99 278 404 131 279 404 minecraft:blackstone
fill 99 278 405 99 279 405 minecraft:basalt
fill 100 278 374 100 279 374 minecraft:basalt
fill 100 278 375 130 279 375 minecraft:blackstone
fill 100 278 405 130 279 405 minecraft:blackstone
fill 100 278 406 100 279 406 minecraft:basalt
fill 101 278 373 101 279 373 minecraft:basalt
fill 101 278 374 129 279 374 minecraft:blackstone
fill 101 278 406 129 279 406 minecraft:blackstone
fill 101 278 407 101 279 407 minecraft:basalt
setblock 102 278 372 minecraft:basalt
fill 102 278 373 128 278 373 minecraft:blackstone
fill 102 278 407 128 278 407 minecraft:blackstone
setblock 102 278 408 minecraft:basalt
fill 103 278 372 127 278 372 minecraft:blackstone
fill 103 278 408 127 278 408 minecraft:blackstone
fill 104 278 371 104 279 371 minecraft:basalt
fill 104 278 409 104 279 409 minecraft:basalt
fill 105 278 370 125 278 370 minecraft:basalt
fill 105 278 371 125 278 371 minecraft:blackstone
fill 105 278 409 125 278 409 minecraft:blackstone
fill 105 278 410 125 278 410 minecraft:basalt
fill 111 278 378 133 278 378 minecraft:blackstone
fill 111 278 380 111 278 386 minecraft:blackstone
setblock 111 278 387 minecraft:magma_block
fill 111 278 389 111 278 390 minecraft:magma_block
fill 111 278 391 111 278 400 minecraft:blackstone
fill 111 278 402 133 278 402 minecraft:blackstone
fill 112 278 380 112 278 385 minecraft:blackstone
fill 112 278 391 113 278 391 minecraft:magma_block
fill 112 278 392 134 278 400 minecraft:blackstone
fill 113 278 380 134 278 384 minecraft:blackstone
setblock 113 278 385 minecraft:magma_block
fill 115 278 385 116 278 385 minecraft:magma_block
fill 115 278 391 116 278 391 minecraft:magma_block
fill 117 278 385 134 278 385 minecraft:blackstone
fill 117 278 386 117 278 387 minecraft:magma_block
fill 117 278 389 117 278 390 minecraft:magma_block
fill 117 278 391 134 278 391 minecraft:blackstone
fill 118 278 386 134 278 387 minecraft:blackstone
fill 118 278 389 134 278 390 minecraft:blackstone
fill 126 278 371 126 279 371 minecraft:basalt
fill 126 278 409 126 279 409 minecraft:basalt
setblock 128 278 372 minecraft:basalt
setblock 128 278 408 minecraft:basalt
fill 129 278 373 129 279 373 minecraft:basalt
fill 129 278 407 129 279 407 minecraft:basalt
fill 130 278 374 130 279 374 minecraft:basalt
fill 130 278 406 130 279 406 minecraft:basalt
fill 131 278 375 131 279 375 minecraft:basalt
fill 131 278 405 131 279 405 minecraft:basalt
fill 132 278 376 132 279 376 minecraft:basalt
fill 132 278 404 132 279 404 minecraft:basalt
setblock 133 278 377 minecraft:basalt
setblock 133 278 403 minecraft:basalt
fill 134 278 379 134 279 379 minecraft:basalt
fill 134 278 401 134 279 401 minecraft:basalt
fill 135 278 380 135 278 400 minecraft:basalt
fill 95 279 370 95 279 380 minecraft:blackstone
fill 95 279 381 95 279 399 minecraft:basalt
fill 95 279 400 95 279 410 minecraft:blackstone
fill 96 279 370 96 279 378 minecraft:blackstone
fill 96 279 380 96 280 380 minecraft:basalt
fill 96 279 381 109 279 399 minecraft:blackstone
fill 96 279 400 96 280 400 minecraft:basalt
fill 96 279 402 96 279 410 minecraft:blackstone
fill 97 279 370 97 279 377 minecraft:blackstone
setblock 97 279 378 minecraft:basalt
fill 97 279 380 133 280 380 minecraft:blackstone
fill 97 279 400 133 280 400 minecraft:blackstone
setblock 97 279 402 minecraft:basalt
fill 97 279 403 97 279 410 minecraft:blackstone
fill 98 279 370 98 279 375 minecraft:blackstone
fill 98 279 377 98 280 377 minecraft:basalt
fill 98 279 378 132 279 378 minecraft:blackstone
fill 98 279 402 132 279 402 minecraft:blackstone
fill 98 279 403 98 280 403 minecraft:basalt
fill 98 279 405 98 279 410 minecraft:blackstone
fill 99 279 370 99 279 374 minecraft:blackstone
fill 99 279 377 131 280 377 minecraft:blackstone
fill 99 279 403 131 280 403 minecraft:blackstone
fill 99 279 406 99 279 410 minecraft:blackstone
fill 100 279 370 100 279 373 minecraft:blackstone
fill 100 279 407 100 279 410 minecraft:blackstone
fill 101 279 370 102 279 372 minecraft:blackstone
fill 101 279 408 102 279 410 minecraft:blackstone
fill 102 279 373 102 280 373 minecraft:basalt
fill 102 279 407 102 280 407 minecraft:basalt
fill 103 279 370 103 279 371 minecraft:blackstone
setblock 103 279 372 minecraft:basalt
fill 103 279 373 127 279 373 minecraft:blackstone
fill 103 279 407 127 279 407 minecraft:blackstone
setblock 103 279 408 minecraft:basalt
fill 103 279 409 103 279 410 minecraft:blackstone
fill 104 279 370 105 279 370 minecraft:blackstone
fill 104 279 372 126 279 372 minecraft:blackstone
fill 104 279 408 126 279 408 minecraft:blackstone
fill 104 279 410 105 279 410 minecraft:blackstone
fill 105 279 371 105 280 371 minecraft:basalt
fill 105 279 409 105 280 409 minecraft:basalt
fill 106 279 370 124 279 370 minecraft:basalt
fill 106 279 371 124 279 371 minecraft:blackstone
fill 106 279 409 124 279 409 minecraft:blackstone
fill 106 279 410 124 279 410 minecraft:basalt
fill 110 279 381 110 279 386 minecraft:blackstone
fill 110 279 387 110 279 390 minecraft:shroomlight
fill 110 279 391 110 279 399 minecraft:blackstone
fill 111 279 381 112 279 384 minecraft:blackstone
fill 111 279 385 111 279 387 minecraft:shroomlight
fill 111 279 389 111 279 391 minecraft:shroomlight
fill 111 279 392 111 279 399 minecraft:blackstone
fill 112 279 385 113 279 385 minecraft:shroomlight
fill 112 279 391 113 279 392 minecraft:shroomlight
fill 112 279 393 134 279 399 minecraft:blackstone
fill 113 279 381 134 279 383 minecraft:blackstone
fill 113 279 384 116 279 384 minecraft:shroomlight
fill 114 279 392 117 279 392 minecraft:shroomlight
fill 115 279 385 117 279 385 minecraft:shroomlight
fill 115 279 391 117 279 391 minecraft:shroomlight
fill 117 279 384 134 279 384 minecraft:blackstone
fill 117 279 386 118 279 387 minecraft:shroomlight
fill 117 279 389 118 279 390 minecraft:shroomlight
fill 118 279 385 134 279 385 minecraft:blackstone
setblock 118 279 388 minecraft:shroomlight
fill 118 279 391 134 279 392 minecraft:blackstone
fill 119 279 386 134 279 390 minecraft:blackstone
fill 125 279 370 135 279 370 minecraft:blackstone
fill 125 279 371 125 280 371 minecraft:basalt
fill 125 279 409 125 280 409 minecraft:basalt
fill 125 279 410 135 279 410 minecraft:blackstone
fill 127 279 371 135 279 371 minecraft:blackstone
setblock 127 279 372 minecraft:basalt
setblock 127 279 408 minecraft:basalt
fill 127 279 409 135 279 409 minecraft:blackstone
fill 128 279 372 135 279 372 minecraft:blackstone
fill 128 279 373 128 280 373 minecraft:basalt
fill 128 279 407 128 280 407 minecraft:basalt
fill 128 279 408 135 279 408 minecraft:blackstone
fill 130 279 373 135 279 373 minecraft:blackstone
fill 130 279 407 135 279 407 minecraft:blackstone
fill 131 279 374 135 279 374 minecraft:blackstone
fill 131 279 406 135 279 406 minecraft:blackstone
fill 132 279 375 135 279 375 minecraft:blackstone
fill 132 279 377 132 280 377 minecraft:basalt
fill 132 279 403 132 280 403 minecraft:basalt
fill 132 279 405 135 279 405 minecraft:blackstone
fill 133 279 376 135 279 377 minecraft:blackstone
setblock 133 279 378 minecraft:basalt
setblock 133 279 402 minecraft:basalt
fill 133 279 403 135 279 404 minecraft:blackstone
fill 134 279 378 135 279 378 minecraft:blackstone
fill 134 279 380 134 280 380 minecraft:basalt
fill 134 279 400 134 280 400 minecraft:basalt
fill 134 279 402 135 279 402 minecraft:blackstone
fill 135 279 379 135 279 380 minecraft:blackstone
fill 135 279 381 135 279 399 minecraft:basalt
fill 135 279 400 135 279 401 minecraft:blackstone
fill 95 280 382 95 280 398 minecraft:basalt
setblock 96 280 381 minecraft:basalt
fill 96 280 382 108 280 398 minecraft:blackstone
setblock 96 280 399 minecraft:basalt
setblock 97 280 379 minecraft:basalt
fill 97 280 381 133 280 381 minecraft:blackstone
fill 97 280 399 133 280 399 minecraft:blackstone
setblock 97 280 401 minecraft:basalt
fill 98 280 378 98 281 378 minecraft:basalt
fill 98 280 379 132 280 379 minecraft:blackstone
fill 98 280 401 132 280 401 minecraft:blackstone
fill 98 280 402 98 281 402 minecraft:basalt
setblock 99 280 376 minecraft:basalt
fill 99 280 378 131 281 378 minecraft:blackstone
fill 99 280 402 131 281 402 minecraft:blackstone
setblock 99 280 404 minecraft:basalt
setblock 100 280 375 minecraft:basalt
fill 100 280 376 130 280 376 minecraft:blackstone
fill 100 280 404 130 280 404 minecraft:blackstone
setblock 100 280 405 minecraft:basalt
setblock 101 280 374 minecraft:basalt
fill 101 280 375 129 280 375 minecraft:blackstone
fill 101 280 405 129 280 405 minecraft:blackstone
setblock 101 280 406 minecraft:basalt
fill 102 280 374 128 280 374 minecraft:blackstone
fill 102 280 406 128 280 406 minecraft:blackstone
fill 103 280 373 103 281 373 minecraft:basalt
fill 103 280 407 103 281 407 minecraft:basalt
setblock 104 280 372 minecraft:basalt
fill 104 280 373 126 280 373 minecraft:blackstone
fill 104 280 407 126 280 407 minecraft:blackstone
setblock 104 280 408 minecraft:basalt
fill 105 280 372 125 280 372 minecraft:blackstone
fill 105 280 408 125 280 408 minecraft:blackstone
setblock 106 280 371 minecraft:basalt
setblock 106 280 409 minecraft:basalt
fill 107 280 370 123 280 370 minecraft:basalt
fill 107 280 371 123 280 371 minecraft:blackstone
fill 107 280 409 123 280 409 minecraft:blackstone
fill 107 280 410 123 280 410 minecraft:basalt
fill 109 280 382 109 280 386 minecraft:blackstone
fill 109 280 387 109 280 390 minecraft:magma_block
fill 109 280 391 109 280 398 minecraft:blackstone
fill 110 280 382 110 280 384 minecraft:blackstone
fill 110 280 385 110 280 386 minecraft:magma_block
fill 110 280 391 110 280 392 minecraft:magma_block
fill 110 280 393 110 280 398 minecraft:blackstone
fill 111 280 382 112 280 383 minecraft:blackstone
fill 111 280 384 112 280 384 minecraft:magma_block
fill 111 280 392 111 280 393 minecraft:magma_block
fill 111 280 394 112 280 398 minecraft:blackstone
fill 112 280 393 117 280 393 minecraft:magma_block
fill 113 280 382 134 280 382 minecraft:blackstone
fill 113 280 383 115 280 383 minecraft:magma_block
fill 113 280 394 115 280 394 minecraft:magma_block
fill 113 280 395 134 280 398 minecraft:blackstone
fill 116 280 383 134 280 383 minecraft:blackstone
fill 116 280 384 117 280 384 minecraft:magma_block
fill 116 280 394 134 280 394 minecraft:blackstone
fill 118 280 384 134 280 384 minecraft:blackstone
setblock 118 280 385 minecraft:magma_block
fill 118 280 391 118 280 392 minecraft:magma_block
fill 118 280 393 134 280 393 minecraft:blackstone
fill 119 280 385 134 280 385 minecraft:blackstone
fill 119 280 386 119 280 391 minecraft:magma_block
fill 119 280 392 134 280 392 minecraft:blackstone
fill 120 280 386 134 280 391 minecraft:blackstone
setblock 124 280 371 minecraft:basalt
setblock 124 280 409 minecraft:basalt
setblock 126 280 372 minecraft:basalt
setblock 126 280 408 minecraft:basalt
fill 127 280 373 127 281 373 minecraft:basalt
fill 127 280 407 127 281 407 minecraft:basalt
setblock 129 280 374 minecraft:basalt
setblock 129 280 406 minecraft:basalt
setblock 130 280 375 minecraft:basalt
setblock 130 280 405 minecraft:basalt
setblock 131 280 376 minecraft:basalt
setblock 131 280 404 minecraft:basalt
fill 132 280 378 132 281 378 minecraft:basalt
fill 132 280 402 132 281 402 minecraft:basalt
setblock 133 280 379 minecraft:basalt
setblock 133 280 401 minecraft:basalt
setblock 134 280 381 minecraft:basalt
setblock 134 280 399 minecraft:basalt
fill 135 280 382 135 280 398 minecraft:basalt
fill 95 281 384 95 281 396 minecraft:basalt
fill 96 281 382 96 281 383 minecraft:basalt
fill 96 281 384 107 281 396 minecraft:blackstone
fill 96 281 397 96 281 398 minecraft:basalt
fill 97 281 380 97 281 381 minecraft:basalt
fill 97 281 382 110 281 383 minecraft:blackstone
fill 97 281 397 133 281 398 minecraft:blackstone
fill 97 281 399 97 281 400 minecraft:basalt
fill 98 281 379 98 282 379 minecraft:basalt
fill 98 281 380 132 281 381 minecraft:blackstone
fill 98 281 399 132 281 400 minecraft:blackstone
fill 98 281 401 98 282 401 minecraft:basalt
setblock 99 281 377 minecraft:basalt
fill 99 281 379 131 282 379 minecraft:blackstone
fill 99 281 401 131 282 401 minecraft:blackstone
setblock 99 281 403 minecraft:basalt
setblock 100 281 376 minecraft:basalt
fill 100 281 377 130 281 377 minecraft:blackstone
fill 100 281 403 130 281 403 minecraft:blackstone
setblock 100 281 404 minecraft:basalt
setblock 101 281 375 minecraft:basalt
fill 101 281 376 129 281 376 minecraft:blackstone
fill 101 281 404 129 281 404 minecraft:blackstone
setblock 101 281 405 minecraft:basalt
setblock 102 281 374 minecraft:basalt
fill 102 281 375 128 281 375 minecraft:blackstone
fill 102 281 405 128 281 405 minecraft:blackstone
setblock 102 281 406 minecraft:basalt
fill 103 281 374 127 281 374 minecraft:blackstone
fill 103 281 406 127 281 406 minecraft:blackstone
fill 104 281 373 104 282 373 minecraft:basalt
fill 104 281 407 104 282 407 minecraft:basalt
fill 105 281 372 106 281 372 minecraft:basalt
fill 105 281 373 125 281 373 minecraft:blackstone
fill 105 281 407 125 281 407 minecraft:blackstone
fill 105 281 408 106 281 408 minecraft:basalt
fill 107 281 371 108 281 371 minecraft:basalt
fill 107 281 372 123 281 372 minecraft:blackstone
fill 107 281 408 123 281 408 minecraft:blackstone
fill 107 281 409 108 281 409 minecraft:basalt
fill 108 281 384 108 281 386 minecraft:blackstone
fill 108 281 387 108 281 390 minecraft:magma_block
fill 108 281 391 108 281 396 minecraft:blackstone
fill 109 281 370 121 281 370 minecraft:basalt
fill 109 281 371 121 281 371 minecraft:blackstone
setblock 109 281 384 minecraft:blackstone
fill 109 281 385 109 281 386 minecraft:magma_block
fill 109 281 391 109 281 392 minecraft:magma_block
fill 109 281 393 109 281 396 minecraft:blackstone
fill 109 281 409 121 281 409 minecraft:blackstone
fill 109 281 410 121 281 410 minecraft:basalt
setblock 110 281 384 minecraft:magma_block
setblock 110 281 393 minecraft:magma_block
fill 110 281 394 110 281 396 minecraft:blackstone
fill 111 281 382 113 281 382 minecraft:blackstone
fill 111 281 383 113 281 383 minecraft:magma_block
fill 111 281 394 112 281 394 minecraft:magma_block
fill 111 281 395 112 281 396 minecraft:blackstone
fill 113 281 395 116 281 395 minecraft:magma_block
fill 113 281 396 134 281 396 minecraft:blackstone
fill 114 281 382 115 281 382 minecraft:magma_block
fill 116 281 382 133 281 382 minecraft:blackstone
fill 116 281 383 117 281 383 minecraft:magma_block
fill 116 281 394 118 281 394 minecraft:magma_block
fill 117 281 395 134 281 395 minecraft:blackstone
fill 118 281 383 133 281 383 minecraft:blackstone
setblock 118 281 384 minecraft:magma_block
fill 118 281 393 119 281 393 minecraft:magma_block
fill 119 281 384 134 281 384 minecraft:blackstone
setblock 119 281 385 minecraft:magma_block
fill 119 281 392 120 281 392 minecraft:magma_block
fill 119 281 394 134 281 394 minecraft:blackstone
fill 120 281 385 134 281 385 minecraft:blackstone
fill 120 281 386 120 281 391 minecraft:magma_block
fill 120 281 393 134 281 393 minecraft:blackstone
fill 121 281 386 134 281 388 minecraft:blackstone
setblock 121 281 389 minecraft:magma_block
fill 121 281 390 134 281 392 minecraft:blackstone
fill 122 281 371 123 281 371 minecraft:basalt
fill 122 281 389 134 281 389 minecraft:blackstone
fill 122 281 409 123 281 409 minecraft:basalt
fill 124 281 372 125 281 372 minecraft:basalt
fill 124 281 408 125 281 408 minecraft:basalt
fill 126 281 373 126 282 373 minecraft:basalt
fill 126 281 407 126 282 407 minecraft:basalt
setblock 128 281 374 minecraft:basalt
setblock 128 281 406 minecraft:basalt
setblock 129 281 375 minecraft:basalt
setblock 129 281 405 minecraft:basalt
setblock 130 281 376 minecraft:basalt
setblock 130 281 404 minecraft:basalt
setblock 131 281 377 minecraft:basalt
setblock 131 281 403 minecraft:basalt
fill 132 281 379 132 282 379 minecraft:basalt
fill 132 281 401 132 282 401 minecraft:basalt
fill 133 281 380 133 281 381 minecraft:basalt
fill 133 281 399 133 281 400 minecraft:basalt
fill 134 281 382 134 281 383 minecraft:basalt
fill 134 281 397 134 281 398 minecraft:basalt
fill 135 281 384 135 281 396 minecraft:basalt
fill 95 282 387 95 282 393 minecraft:basalt
fill 96 282 383 96 282 386 minecraft:basalt
fill 96 282 387 106 282 393 minecraft:blackstone
fill 96 282 394 96 282 397 minecraft:basalt
fill 97 282 381 97 282 382 minecraft:basalt
fill 97 282 383 107 282 386 minecraft:blackstone
fill 97 282 394 108 282 397 minecraft:blackstone
fill 97 282 398 97 282 399 minecraft:basalt
setblock 98 282 380 minecraft:basalt
fill 98 282 381 111 282 382 minecraft:blackstone
fill 98 282 398 132 282 399 minecraft:blackstone
setblock 98 282 400 minecraft:basalt
setblock 99 282 378 minecraft:basalt
fill 99 282 380 131 282 380 minecraft:blackstone
fill 99 282 400 131 282 400 minecraft:blackstone
setblock 99 282 402 minecraft:basalt
setblock 100 282 377 minecraft:basalt
fill 100 282 378 130 282 378 minecraft:blackstone
fill 100 282 402 130 282 402 minecraft:blackstone
setblock 100 282 403 minecraft:basalt
setblock 101 282 376 minecraft:basalt
fill 101 282 377 129 282 377 minecraft:blackstone
fill 101 282 403 129 282 403 minecraft:blackstone
setblock 101 282 404 minecraft:basalt
setblock 102 282 375 minecraft:basalt
fill 102 282 376 128 282 376 minecraft:blackstone
fill 102 282 404 128 282 404 minecraft:blackstone
setblock 102 282 405 minecraft:basalt
setblock 103 282 374 minecraft:basalt
fill 103 282 375 127 282 375 minecraft:blackstone
fill 103 282 405 127 282 405 minecraft:blackstone
setblock 103 282 406 minecraft:basalt
fill 104 282 374 126 282 374 minecraft:blackstone
fill 104 282 406 126 282 406 minecraft:blackstone
setblock 105 282 373 minecraft:basalt
setblock 105 282 407 minecraft:basalt
fill 106 282 372 107 282 372 minecraft:basalt
fill 106 282 373 124 282 373 minecraft:blackstone
fill 106 282 407 124 282 407 minecraft:blackstone
fill 106 282 408 107 282 408 minecraft:basalt
setblock 107 282 387 minecraft:blackstone
fill 107 282 388 107 282 390 minecraft:shroomlight
fill 107 282 391 107 282 393 minecraft:blackstone
fill 108 282 371 111 282 371 minecraft:basalt
fill 108 282 372 122 282 372 minecraft:blackstone
fill 108 282 383 108 282 384 minecraft:blackstone
fill 108 282 385 108 282 387 minecraft:shroomlight
fill 108 282 391 108 282 392 minecraft:shroomlight
setblock 108 282 393 minecraft:blackstone
fill 108 282 408 122 282 408 minecraft:blackstone
fill 108 282 409 111 282 409 minecraft:basalt
setblock 109 282 383 minecraft:blackstone
setblock 109 282 384 minecraft:shroomlight
fill 109 282 393 109 282 394 minecraft:shroomlight
fill 109 282 395 109 282 397 minecraft:blackstone
fill 110 282 383 111 282 383 minecraft:shroomlight
fill 110 282 394 110 282 395 minecraft:shroomlight
fill 110 282 396 111 282 397 minecraft:blackstone
fill 111 282 395 112 282 395 minecraft:shroomlight
fill 112 282 370 118 282 370 minecraft:basalt
fill 112 282 371 118 282 371 minecraft:blackstone
fill 112 282 381 132 282 381 minecraft:blackstone
fill 112 282 382 117 282 382 minecraft:shroomlight
fill 112 282 396 117 282 396 minecraft:shroomlight
fill 112 282 397 133 282 397 minecraft:blackstone
fill 112 282 409 118 282 409 minecraft:blackstone
fill 112 282 410 118 282 410 minecraft:basalt
fill 117 282 395 119 282 395 minecraft:shroomlight
fill 118 282 382 132 282 382 minecraft:blackstone
fill 118 282 383 119 282 383 minecraft:shroomlight
fill 118 282 396 133 282 396 minecraft:blackstone
fill 119 282 371 122 282 371 minecraft:basalt
fill 119 282 384 120 282 384 minecraft:shroomlight
fill 119 282 394 120 282 394 minecraft:shroomlight
fill 119 282 409 122 282 409 minecraft:basalt
fill 120 282 383 133 282 383 minecraft:blackstone
setblock 120 282 385 minecraft:shroomlight
setblock 120 282 393 minecraft:shroomlight
fill 120 282 395 133 282 395 minecraft:blackstone
fill 121 282 384 133 282 385 minecraft:blackstone
fill 121 282 386 121 282 388 minecraft:shroomlight
fill 121 282 390 121 282 392 minecraft:shroomlight
fill 121 282 393 133 282 394 minecraft:blackstone
fill 122 282 386 133 282 387 minecraft:blackstone
fill 122 282 388 122 282 390 minecraft:shroomlight
fill 122 282 391 134 282 392 minecraft:blackstone
fill 123 282 372 124 282 372 minecraft:basalt
fill 123 282 388 134 282 390 minecraft:blackstone
fill 123 282 408 124 282 408 minecraft:basalt
setblock 125 282 373 minecraft:basalt
setblock 125 282 407 minecraft:basalt
setblock 127 282 374 minecraft:basalt
setblock 127 282 406 minecraft:basalt
setblock 128 282 375 minecraft:basalt
setblock 128 282 405 minecraft:basalt
setblock 129 282 376 minecraft:basalt
setblock 129 282 404 minecraft:basalt
setblock 130 282 377 minecraft:basalt
setblock 130 282 403 minecraft:basalt
setblock 131 282 378 minecraft:basalt
schedule function dropper:buildpart/86_2 1t
