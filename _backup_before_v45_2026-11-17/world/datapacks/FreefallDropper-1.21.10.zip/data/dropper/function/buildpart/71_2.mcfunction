setblock 517 112 317 minecraft:white_concrete
fill 518 112 317 519 112 317 minecraft:shroomlight
setblock 519 112 275 minecraft:white_concrete
setblock 520 112 317 minecraft:brown_terracotta
fill 522 112 280 530 112 280 minecraft:red_concrete
fill 522 112 311 522 139 312 minecraft:white_concrete
setblock 523 112 275 minecraft:white_concrete
fill 523 112 312 523 139 312 minecraft:white_concrete
setblock 523 112 317 minecraft:white_concrete
setblock 524 112 275 minecraft:brown_terracotta
fill 525 112 275 527 115 275 minecraft:shroomlight
setblock 527 112 317 minecraft:white_concrete
fill 529 112 317 529 113 317 minecraft:brown_terracotta
fill 530 112 317 531 112 317 minecraft:shroomlight
setblock 531 112 275 minecraft:white_concrete
setblock 532 112 317 minecraft:brown_terracotta
setblock 535 112 275 minecraft:white_concrete
setblock 535 112 317 minecraft:white_concrete
setblock 536 112 275 minecraft:brown_terracotta
fill 537 112 275 538 112 275 minecraft:shroomlight
setblock 539 112 275 minecraft:white_concrete
setblock 539 112 317 minecraft:white_concrete
fill 541 112 317 541 113 317 minecraft:brown_terracotta
fill 542 112 317 543 112 317 minecraft:shroomlight
setblock 543 112 275 minecraft:white_concrete
setblock 544 112 317 minecraft:brown_terracotta
setblock 547 112 275 minecraft:white_concrete
setblock 547 112 317 minecraft:white_concrete
setblock 548 112 275 minecraft:brown_terracotta
fill 549 112 275 550 112 275 minecraft:shroomlight
setblock 551 112 275 minecraft:white_concrete
setblock 551 112 317 minecraft:white_concrete
fill 553 112 317 553 113 317 minecraft:brown_terracotta
fill 554 112 284 555 115 288 minecraft:orange_terracotta
fill 554 112 317 555 112 317 minecraft:shroomlight
setblock 555 112 275 minecraft:white_concrete
fill 556 112 284 558 115 285 minecraft:orange_terracotta
fill 556 112 286 556 113 286 minecraft:ochre_froglight
fill 556 112 287 558 115 288 minecraft:orange_terracotta
setblock 556 112 317 minecraft:brown_terracotta
fill 557 112 275 558 112 275 minecraft:brown_terracotta
fill 557 112 286 558 115 286 minecraft:orange_terracotta
setblock 559 112 275 minecraft:white_concrete
setblock 559 112 276 minecraft:brown_terracotta
fill 559 112 277 559 112 278 minecraft:shroomlight
fill 559 112 279 559 113 279 minecraft:brown_terracotta
setblock 559 112 281 minecraft:white_concrete
setblock 559 112 285 minecraft:white_concrete
setblock 559 112 288 minecraft:brown_terracotta
fill 559 112 289 559 112 290 minecraft:shroomlight
fill 559 112 291 559 113 291 minecraft:brown_terracotta
setblock 559 112 293 minecraft:white_concrete
setblock 559 112 297 minecraft:white_concrete
setblock 559 112 300 minecraft:brown_terracotta
fill 559 112 301 559 112 302 minecraft:shroomlight
fill 559 112 303 559 113 303 minecraft:brown_terracotta
setblock 559 112 305 minecraft:white_concrete
setblock 559 112 309 minecraft:white_concrete
setblock 559 112 312 minecraft:brown_terracotta
fill 559 112 313 559 112 314 minecraft:shroomlight
fill 559 112 315 559 113 315 minecraft:brown_terracotta
setblock 559 112 317 minecraft:white_concrete
setblock 517 113 276 minecraft:white_concrete
fill 517 113 277 517 120 277 minecraft:brown_terracotta
setblock 517 113 278 minecraft:white_concrete
setblock 517 113 279 minecraft:brown_terracotta
setblock 517 113 280 minecraft:white_concrete
fill 517 113 281 517 120 281 minecraft:brown_terracotta
setblock 517 113 282 minecraft:white_concrete
setblock 517 113 283 minecraft:brown_terracotta
setblock 517 113 284 minecraft:white_concrete
fill 517 113 285 517 120 285 minecraft:brown_terracotta
setblock 517 113 286 minecraft:white_concrete
setblock 517 113 288 minecraft:white_concrete
fill 517 113 289 517 120 289 minecraft:brown_terracotta
setblock 517 113 290 minecraft:white_concrete
setblock 517 113 291 minecraft:brown_terracotta
setblock 517 113 292 minecraft:white_concrete
fill 517 113 293 517 120 293 minecraft:brown_terracotta
setblock 517 113 294 minecraft:white_concrete
setblock 517 113 295 minecraft:brown_terracotta
setblock 517 113 296 minecraft:white_concrete
fill 517 113 297 517 120 297 minecraft:brown_terracotta
setblock 517 113 298 minecraft:white_concrete
setblock 517 113 300 minecraft:white_concrete
fill 517 113 301 517 120 301 minecraft:brown_terracotta
setblock 517 113 302 minecraft:white_concrete
setblock 517 113 303 minecraft:brown_terracotta
setblock 517 113 304 minecraft:white_concrete
fill 517 113 305 517 120 305 minecraft:brown_terracotta
setblock 517 113 306 minecraft:white_concrete
setblock 517 113 307 minecraft:brown_terracotta
setblock 517 113 308 minecraft:white_concrete
fill 517 113 309 517 120 309 minecraft:brown_terracotta
setblock 517 113 310 minecraft:white_concrete
setblock 517 113 312 minecraft:white_concrete
fill 517 113 313 517 120 313 minecraft:brown_terracotta
setblock 517 113 314 minecraft:white_concrete
setblock 517 113 315 minecraft:brown_terracotta
setblock 517 113 316 minecraft:white_concrete
setblock 517 113 317 minecraft:brown_terracotta
setblock 518 113 275 minecraft:white_concrete
setblock 518 113 317 minecraft:white_concrete
fill 519 113 275 519 120 275 minecraft:brown_terracotta
fill 519 113 317 519 120 317 minecraft:brown_terracotta
setblock 520 113 275 minecraft:white_concrete
fill 520 113 288 524 113 292 minecraft:white_concrete
fill 520 113 312 520 113 314 minecraft:brown_terracotta
setblock 520 113 317 minecraft:white_concrete
setblock 521 113 275 minecraft:brown_terracotta
setblock 521 113 311 minecraft:brown_terracotta
fill 521 113 315 523 113 315 minecraft:brown_terracotta
setblock 522 113 275 minecraft:white_concrete
setblock 522 113 280 minecraft:white_concrete
setblock 522 113 317 minecraft:white_concrete
fill 523 113 275 523 120 275 minecraft:brown_terracotta
fill 523 113 311 524 113 311 minecraft:brown_terracotta
fill 523 113 317 523 120 317 minecraft:brown_terracotta
setblock 524 113 275 minecraft:white_concrete
fill 524 113 312 524 113 314 minecraft:brown_terracotta
setblock 524 113 317 minecraft:white_concrete
setblock 526 113 280 minecraft:white_concrete
setblock 526 113 317 minecraft:white_concrete
fill 527 113 317 527 120 317 minecraft:brown_terracotta
setblock 528 113 275 minecraft:white_concrete
setblock 528 113 317 minecraft:white_concrete
setblock 530 113 275 minecraft:white_concrete
setblock 530 113 280 minecraft:white_concrete
setblock 530 113 317 minecraft:white_concrete
fill 531 113 275 531 120 275 minecraft:brown_terracotta
fill 531 113 317 531 120 317 minecraft:brown_terracotta
setblock 532 113 275 minecraft:white_concrete
setblock 532 113 317 minecraft:white_concrete
setblock 533 113 275 minecraft:brown_terracotta
setblock 534 113 275 minecraft:white_concrete
setblock 534 113 317 minecraft:white_concrete
fill 535 113 275 535 120 275 minecraft:brown_terracotta
fill 535 113 317 535 120 317 minecraft:brown_terracotta
setblock 536 113 275 minecraft:white_concrete
setblock 536 113 317 minecraft:white_concrete
setblock 537 113 275 minecraft:brown_terracotta
setblock 538 113 275 minecraft:white_concrete
setblock 538 113 317 minecraft:white_concrete
fill 539 113 275 539 120 275 minecraft:brown_terracotta
fill 539 113 317 539 120 317 minecraft:brown_terracotta
setblock 540 113 275 minecraft:white_concrete
setblock 540 113 317 minecraft:white_concrete
setblock 542 113 275 minecraft:white_concrete
setblock 542 113 317 minecraft:white_concrete
fill 543 113 275 543 120 275 minecraft:brown_terracotta
fill 543 113 317 543 120 317 minecraft:brown_terracotta
setblock 544 113 275 minecraft:white_concrete
setblock 544 113 317 minecraft:white_concrete
setblock 545 113 275 minecraft:brown_terracotta
setblock 546 113 275 minecraft:white_concrete
setblock 546 113 317 minecraft:white_concrete
fill 547 113 275 547 120 275 minecraft:brown_terracotta
fill 547 113 317 547 120 317 minecraft:brown_terracotta
setblock 548 113 275 minecraft:white_concrete
setblock 548 113 317 minecraft:white_concrete
setblock 549 113 275 minecraft:brown_terracotta
fill 550 113 275 550 113 280 minecraft:white_concrete
setblock 550 113 317 minecraft:white_concrete
fill 551 113 275 551 120 275 minecraft:brown_terracotta
fill 551 113 276 554 113 280 minecraft:white_concrete
fill 551 113 317 551 120 317 minecraft:brown_terracotta
setblock 552 113 275 minecraft:white_concrete
setblock 552 113 317 minecraft:white_concrete
setblock 554 113 275 minecraft:white_concrete
setblock 554 113 317 minecraft:white_concrete
fill 555 113 275 555 120 275 minecraft:brown_terracotta
fill 555 113 317 555 120 317 minecraft:brown_terracotta
setblock 556 113 275 minecraft:white_concrete
setblock 556 113 317 minecraft:white_concrete
setblock 557 113 275 minecraft:brown_terracotta
setblock 558 113 275 minecraft:white_concrete
setblock 558 113 317 minecraft:white_concrete
setblock 559 113 275 minecraft:brown_terracotta
setblock 559 113 276 minecraft:white_concrete
fill 559 113 277 559 120 277 minecraft:brown_terracotta
setblock 559 113 278 minecraft:white_concrete
setblock 559 113 280 minecraft:white_concrete
fill 559 113 281 559 120 281 minecraft:brown_terracotta
setblock 559 113 282 minecraft:white_concrete
setblock 559 113 284 minecraft:white_concrete
fill 559 113 285 559 120 285 minecraft:brown_terracotta
setblock 559 113 286 minecraft:white_concrete
setblock 559 113 288 minecraft:white_concrete
fill 559 113 289 559 120 289 minecraft:brown_terracotta
setblock 559 113 290 minecraft:white_concrete
setblock 559 113 292 minecraft:white_concrete
fill 559 113 293 559 120 293 minecraft:brown_terracotta
setblock 559 113 294 minecraft:white_concrete
setblock 559 113 296 minecraft:white_concrete
fill 559 113 297 559 120 297 minecraft:brown_terracotta
setblock 559 113 298 minecraft:white_concrete
setblock 559 113 300 minecraft:white_concrete
fill 559 113 301 559 120 301 minecraft:brown_terracotta
setblock 559 113 302 minecraft:white_concrete
setblock 559 113 304 minecraft:white_concrete
fill 559 113 305 559 120 305 minecraft:brown_terracotta
setblock 559 113 306 minecraft:white_concrete
setblock 559 113 308 minecraft:white_concrete
fill 559 113 309 559 120 309 minecraft:brown_terracotta
setblock 559 113 310 minecraft:white_concrete
setblock 559 113 312 minecraft:white_concrete
fill 559 113 313 559 120 313 minecraft:brown_terracotta
setblock 559 113 314 minecraft:white_concrete
setblock 559 113 316 minecraft:white_concrete
fill 559 113 317 559 120 317 minecraft:brown_terracotta
setblock 517 114 275 minecraft:white_concrete
fill 517 114 276 517 121 276 minecraft:brown_terracotta
fill 517 114 278 517 121 278 minecraft:brown_terracotta
setblock 517 114 279 minecraft:white_concrete
fill 517 114 280 517 121 280 minecraft:brown_terracotta
fill 517 114 282 517 121 282 minecraft:brown_terracotta
setblock 517 114 283 minecraft:white_concrete
fill 517 114 284 517 121 284 minecraft:brown_terracotta
fill 517 114 286 517 121 286 minecraft:brown_terracotta
setblock 517 114 287 minecraft:white_concrete
fill 517 114 288 517 121 288 minecraft:brown_terracotta
fill 517 114 290 517 121 290 minecraft:brown_terracotta
setblock 517 114 291 minecraft:white_concrete
fill 517 114 292 517 121 292 minecraft:brown_terracotta
fill 517 114 294 517 121 294 minecraft:brown_terracotta
setblock 517 114 295 minecraft:white_concrete
fill 517 114 296 517 121 296 minecraft:brown_terracotta
fill 517 114 298 517 121 298 minecraft:brown_terracotta
setblock 517 114 299 minecraft:white_concrete
fill 517 114 300 517 121 300 minecraft:brown_terracotta
fill 517 114 302 517 121 302 minecraft:brown_terracotta
setblock 517 114 303 minecraft:white_concrete
fill 517 114 304 517 121 304 minecraft:brown_terracotta
fill 517 114 306 517 121 306 minecraft:brown_terracotta
setblock 517 114 307 minecraft:white_concrete
fill 517 114 308 517 121 308 minecraft:brown_terracotta
fill 517 114 310 517 121 310 minecraft:brown_terracotta
setblock 517 114 311 minecraft:white_concrete
fill 517 114 312 517 121 312 minecraft:brown_terracotta
fill 517 114 314 517 121 314 minecraft:brown_terracotta
setblock 517 114 315 minecraft:white_concrete
fill 517 114 316 517 121 316 minecraft:brown_terracotta
setblock 517 114 317 minecraft:white_concrete
fill 518 114 275 518 121 275 minecraft:brown_terracotta
fill 518 114 317 518 121 317 minecraft:brown_terracotta
fill 520 114 275 520 121 275 minecraft:brown_terracotta
fill 520 114 317 520 121 317 minecraft:brown_terracotta
setblock 521 114 275 minecraft:white_concrete
fill 521 114 288 523 114 292 minecraft:white_concrete
setblock 521 114 317 minecraft:white_concrete
fill 522 114 275 522 121 275 minecraft:brown_terracotta
fill 522 114 317 522 121 317 minecraft:brown_terracotta
fill 524 114 275 524 121 275 minecraft:brown_terracotta
fill 524 114 317 524 121 317 minecraft:brown_terracotta
setblock 525 114 317 minecraft:white_concrete
fill 526 114 317 526 121 317 minecraft:brown_terracotta
fill 528 114 275 528 121 275 minecraft:brown_terracotta
fill 528 114 317 528 121 317 minecraft:brown_terracotta
setblock 529 114 275 minecraft:white_concrete
setblock 529 114 317 minecraft:white_concrete
fill 530 114 275 530 121 275 minecraft:brown_terracotta
fill 530 114 317 530 121 317 minecraft:brown_terracotta
fill 532 114 275 532 121 275 minecraft:brown_terracotta
fill 532 114 317 532 121 317 minecraft:brown_terracotta
setblock 533 114 275 minecraft:white_concrete
setblock 533 114 317 minecraft:white_concrete
fill 534 114 275 534 121 275 minecraft:brown_terracotta
fill 534 114 317 534 121 317 minecraft:brown_terracotta
fill 536 114 275 536 121 275 minecraft:brown_terracotta
fill 536 114 317 536 121 317 minecraft:brown_terracotta
setblock 537 114 275 minecraft:white_concrete
setblock 537 114 317 minecraft:white_concrete
fill 538 114 275 538 121 275 minecraft:brown_terracotta
fill 538 114 317 538 121 317 minecraft:brown_terracotta
fill 540 114 275 540 121 275 minecraft:brown_terracotta
fill 540 114 317 540 121 317 minecraft:brown_terracotta
setblock 541 114 275 minecraft:white_concrete
setblock 541 114 317 minecraft:white_concrete
fill 542 114 275 542 121 275 minecraft:brown_terracotta
fill 542 114 317 542 121 317 minecraft:brown_terracotta
fill 544 114 275 544 121 275 minecraft:brown_terracotta
fill 544 114 317 544 121 317 minecraft:brown_terracotta
setblock 545 114 275 minecraft:white_concrete
setblock 545 114 317 minecraft:white_concrete
fill 546 114 275 546 121 275 minecraft:brown_terracotta
fill 546 114 317 546 121 317 minecraft:brown_terracotta
fill 548 114 275 548 121 275 minecraft:brown_terracotta
fill 548 114 317 548 121 317 minecraft:brown_terracotta
setblock 549 114 275 minecraft:white_concrete
setblock 549 114 317 minecraft:white_concrete
fill 550 114 275 550 121 275 minecraft:brown_terracotta
fill 550 114 317 550 121 317 minecraft:brown_terracotta
fill 551 114 276 553 114 280 minecraft:white_concrete
fill 552 114 275 552 121 275 minecraft:brown_terracotta
fill 552 114 317 552 121 317 minecraft:brown_terracotta
setblock 553 114 275 minecraft:white_concrete
setblock 553 114 317 minecraft:white_concrete
fill 554 114 275 554 121 275 minecraft:brown_terracotta
fill 554 114 276 554 139 276 minecraft:white_concrete
fill 554 114 317 554 121 317 minecraft:brown_terracotta
fill 556 114 275 556 121 275 minecraft:brown_terracotta
fill 556 114 286 556 115 286 minecraft:orange_terracotta
fill 556 114 317 556 121 317 minecraft:brown_terracotta
setblock 557 114 275 minecraft:white_concrete
setblock 557 114 317 minecraft:white_concrete
fill 558 114 275 558 121 275 minecraft:brown_terracotta
fill 558 114 317 558 121 317 minecraft:brown_terracotta
setblock 559 114 275 minecraft:white_concrete
fill 559 114 276 559 121 276 minecraft:brown_terracotta
fill 559 114 278 559 121 278 minecraft:brown_terracotta
setblock 559 114 279 minecraft:white_concrete
fill 559 114 280 559 121 280 minecraft:brown_terracotta
fill 559 114 282 559 121 282 minecraft:brown_terracotta
setblock 559 114 283 minecraft:white_concrete
fill 559 114 284 559 121 284 minecraft:brown_terracotta
fill 559 114 286 559 121 286 minecraft:brown_terracotta
setblock 559 114 287 minecraft:white_concrete
fill 559 114 288 559 121 288 minecraft:brown_terracotta
fill 559 114 290 559 121 290 minecraft:brown_terracotta
setblock 559 114 291 minecraft:white_concrete
fill 559 114 292 559 121 292 minecraft:brown_terracotta
fill 559 114 294 559 121 294 minecraft:brown_terracotta
setblock 559 114 295 minecraft:white_concrete
fill 559 114 296 559 121 296 minecraft:brown_terracotta
fill 559 114 298 559 121 298 minecraft:brown_terracotta
setblock 559 114 299 minecraft:white_concrete
fill 559 114 300 559 121 300 minecraft:brown_terracotta
fill 559 114 302 559 121 302 minecraft:brown_terracotta
setblock 559 114 303 minecraft:white_concrete
fill 559 114 304 559 121 304 minecraft:brown_terracotta
fill 559 114 306 559 121 306 minecraft:brown_terracotta
setblock 559 114 307 minecraft:white_concrete
fill 559 114 308 559 121 308 minecraft:brown_terracotta
fill 559 114 310 559 121 310 minecraft:brown_terracotta
setblock 559 114 311 minecraft:white_concrete
fill 559 114 312 559 121 312 minecraft:brown_terracotta
fill 559 114 314 559 121 314 minecraft:brown_terracotta
setblock 559 114 315 minecraft:white_concrete
fill 559 114 316 559 121 316 minecraft:brown_terracotta
fill 517 115 275 517 122 275 minecraft:brown_terracotta
fill 517 115 279 517 122 279 minecraft:brown_terracotta
fill 517 115 283 517 122 283 minecraft:brown_terracotta
fill 517 115 287 517 122 287 minecraft:brown_terracotta
fill 517 115 291 517 122 291 minecraft:brown_terracotta
fill 517 115 295 517 122 295 minecraft:brown_terracotta
fill 517 115 299 517 122 299 minecraft:brown_terracotta
fill 517 115 303 517 122 303 minecraft:brown_terracotta
fill 517 115 307 517 122 307 minecraft:brown_terracotta
fill 517 115 311 517 122 311 minecraft:brown_terracotta
fill 517 115 315 517 122 315 minecraft:brown_terracotta
fill 517 115 317 517 120 317 minecraft:brown_terracotta
setblock 520 115 278 minecraft:light[level=12]
setblock 520 115 285 minecraft:light[level=12]
setblock 520 115 292 minecraft:light[level=12]
setblock 520 115 299 minecraft:light[level=12]
setblock 520 115 306 minecraft:light[level=12]
setblock 520 115 313 minecraft:light[level=12]
fill 521 115 275 521 122 275 minecraft:brown_terracotta
fill 521 115 317 521 122 317 minecraft:brown_terracotta
fill 522 115 288 522 115 292 minecraft:white_concrete
fill 525 115 317 525 122 317 minecraft:brown_terracotta
setblock 527 115 278 minecraft:light[level=12]
setblock 527 115 285 minecraft:light[level=12]
setblock 527 115 292 minecraft:light[level=12]
setblock 527 115 299 minecraft:light[level=12]
setblock 527 115 306 minecraft:light[level=12]
setblock 527 115 313 minecraft:light[level=12]
fill 529 115 275 529 122 275 minecraft:brown_terracotta
fill 529 115 317 529 122 317 minecraft:brown_terracotta
fill 533 115 275 533 122 275 minecraft:brown_terracotta
fill 533 115 317 533 122 317 minecraft:brown_terracotta
setblock 534 115 278 minecraft:light[level=12]
setblock 534 115 285 minecraft:light[level=12]
setblock 534 115 292 minecraft:light[level=12]
setblock 534 115 299 minecraft:light[level=12]
setblock 534 115 306 minecraft:light[level=12]
setblock 534 115 313 minecraft:light[level=12]
fill 537 115 275 537 122 275 minecraft:brown_terracotta
fill 537 115 317 537 122 317 minecraft:brown_terracotta
fill 541 115 275 541 122 275 minecraft:brown_terracotta
setblock 541 115 278 minecraft:light[level=12]
setblock 541 115 285 minecraft:light[level=12]
setblock 541 115 292 minecraft:light[level=12]
setblock 541 115 299 minecraft:light[level=12]
setblock 541 115 306 minecraft:light[level=12]
setblock 541 115 313 minecraft:light[level=12]
fill 541 115 317 541 122 317 minecraft:brown_terracotta
fill 545 115 275 545 122 275 minecraft:brown_terracotta
fill 545 115 317 545 122 317 minecraft:brown_terracotta
setblock 548 115 278 minecraft:light[level=12]
setblock 548 115 285 minecraft:light[level=12]
setblock 548 115 292 minecraft:light[level=12]
setblock 548 115 299 minecraft:light[level=12]
setblock 548 115 306 minecraft:light[level=12]
setblock 548 115 313 minecraft:light[level=12]
fill 549 115 275 549 122 275 minecraft:brown_terracotta
fill 549 115 317 549 122 317 minecraft:brown_terracotta
fill 552 115 276 552 115 280 minecraft:white_concrete
fill 553 115 275 553 122 275 minecraft:brown_terracotta
fill 553 115 317 553 122 317 minecraft:brown_terracotta
setblock 555 115 278 minecraft:light[level=12]
setblock 555 115 292 minecraft:light[level=12]
setblock 555 115 299 minecraft:light[level=12]
setblock 555 115 306 minecraft:light[level=12]
setblock 555 115 313 minecraft:light[level=12]
fill 557 115 275 557 122 275 minecraft:brown_terracotta
fill 557 115 317 557 122 317 minecraft:brown_terracotta
fill 559 115 275 559 120 275 minecraft:brown_terracotta
fill 559 115 279 559 122 279 minecraft:brown_terracotta
fill 559 115 283 559 122 283 minecraft:brown_terracotta
fill 559 115 287 559 122 287 minecraft:brown_terracotta
fill 559 115 291 559 122 291 minecraft:brown_terracotta
fill 559 115 295 559 122 295 minecraft:brown_terracotta
fill 559 115 299 559 122 299 minecraft:brown_terracotta
fill 559 115 303 559 122 303 minecraft:brown_terracotta
fill 559 115 307 559 122 307 minecraft:brown_terracotta
fill 559 115 311 559 122 311 minecraft:brown_terracotta
fill 559 115 315 559 122 315 minecraft:brown_terracotta
fill 525 116 275 527 120 275 minecraft:brown_terracotta
fill 554 116 284 558 116 288 minecraft:white_concrete
setblock 520 117 278 minecraft:light[level=15]
setblock 520 117 286 minecraft:light[level=15]
setblock 520 117 294 minecraft:light[level=15]
setblock 520 117 302 minecraft:light[level=15]
setblock 520 117 310 minecraft:light[level=15]
setblock 528 117 278 minecraft:light[level=15]
setblock 528 117 286 minecraft:light[level=15]
setblock 528 117 294 minecraft:light[level=15]
setblock 528 117 302 minecraft:light[level=15]
setblock 528 117 310 minecraft:light[level=15]
setblock 536 117 278 minecraft:light[level=15]
setblock 536 117 286 minecraft:light[level=15]
setblock 536 117 294 minecraft:light[level=15]
setblock 536 117 302 minecraft:light[level=15]
setblock 536 117 310 minecraft:light[level=15]
setblock 544 117 278 minecraft:light[level=15]
setblock 544 117 286 minecraft:light[level=15]
setblock 544 117 294 minecraft:light[level=15]
setblock 544 117 302 minecraft:light[level=15]
setblock 544 117 310 minecraft:light[level=15]
setblock 552 117 278 minecraft:light[level=15]
setblock 552 117 286 minecraft:light[level=15]
setblock 552 117 294 minecraft:light[level=15]
setblock 552 117 302 minecraft:light[level=15]
setblock 552 117 310 minecraft:light[level=15]
fill 555 117 284 557 117 288 minecraft:white_concrete
fill 555 117 292 555 118 292 minecraft:red_concrete
fill 558 117 284 558 139 286 minecraft:white_concrete
fill 556 118 284 556 118 288 minecraft:white_concrete
fill 519 119 294 519 132 294 minecraft:red_wool
fill 519 120 285 519 125 287 minecraft:white_concrete
fill 519 120 292 519 132 293 minecraft:red_wool
fill 519 120 295 519 132 296 minecraft:red_wool
fill 519 120 297 519 125 299 minecraft:white_concrete
fill 519 120 309 519 125 311 minecraft:white_concrete
fill 525 120 315 527 125 315 minecraft:white_concrete
fill 529 120 277 531 125 277 minecraft:white_concrete
fill 537 120 315 539 125 315 minecraft:white_concrete
fill 541 120 277 543 125 277 minecraft:white_concrete
fill 542 120 315 544 121 316 minecraft:white_concrete
fill 549 120 315 551 125 315 minecraft:white_concrete
fill 553 120 277 555 125 277 minecraft:white_concrete
fill 557 120 285 557 125 287 minecraft:white_concrete
fill 557 120 297 557 125 299 minecraft:white_concrete
fill 557 120 309 557 125 311 minecraft:white_concrete
setblock 517 121 277 minecraft:white_concrete
setblock 517 121 281 minecraft:white_concrete
setblock 517 121 285 minecraft:white_concrete
setblock 517 121 289 minecraft:white_concrete
setblock 517 121 293 minecraft:white_concrete
setblock 517 121 297 minecraft:white_concrete
setblock 517 121 301 minecraft:white_concrete
setblock 517 121 305 minecraft:white_concrete
setblock 517 121 309 minecraft:white_concrete
setblock 517 121 313 minecraft:white_concrete
setblock 517 121 317 minecraft:white_concrete
setblock 519 121 275 minecraft:white_concrete
setblock 519 121 317 minecraft:white_concrete
setblock 520 121 278 minecraft:light[level=12]
setblock 520 121 285 minecraft:light[level=12]
setblock 520 121 292 minecraft:light[level=12]
setblock 520 121 299 minecraft:light[level=12]
setblock 520 121 306 minecraft:light[level=12]
fill 520 121 312 520 121 314 minecraft:brown_terracotta
setblock 521 121 311 minecraft:brown_terracotta
fill 521 121 315 523 121 315 minecraft:brown_terracotta
setblock 523 121 275 minecraft:white_concrete
fill 523 121 311 524 121 311 minecraft:brown_terracotta
setblock 523 121 317 minecraft:white_concrete
fill 524 121 312 524 121 314 minecraft:brown_terracotta
fill 525 121 275 526 121 275 minecraft:brown_terracotta
setblock 527 121 275 minecraft:white_concrete
setblock 527 121 278 minecraft:light[level=12]
setblock 527 121 285 minecraft:light[level=12]
setblock 527 121 292 minecraft:light[level=12]
setblock 527 121 299 minecraft:light[level=12]
setblock 527 121 306 minecraft:light[level=12]
setblock 527 121 313 minecraft:light[level=12]
setblock 527 121 317 minecraft:white_concrete
setblock 531 121 275 minecraft:white_concrete
setblock 531 121 317 minecraft:white_concrete
setblock 534 121 278 minecraft:light[level=12]
setblock 534 121 285 minecraft:light[level=12]
setblock 534 121 292 minecraft:light[level=12]
setblock 534 121 299 minecraft:light[level=12]
setblock 534 121 306 minecraft:light[level=12]
setblock 534 121 313 minecraft:light[level=12]
setblock 535 121 275 minecraft:white_concrete
setblock 535 121 317 minecraft:white_concrete
setblock 539 121 275 minecraft:white_concrete
setblock 539 121 317 minecraft:white_concrete
setblock 541 121 278 minecraft:light[level=12]
setblock 541 121 285 minecraft:light[level=12]
setblock 541 121 292 minecraft:light[level=12]
setblock 541 121 299 minecraft:light[level=12]
setblock 541 121 306 minecraft:light[level=12]
setblock 541 121 313 minecraft:light[level=12]
fill 542 121 314 544 122 314 minecraft:white_concrete
setblock 543 121 275 minecraft:white_concrete
fill 543 121 278 543 124 278 minecraft:white_concrete
fill 543 121 313 543 124 313 minecraft:white_concrete
setblock 543 121 317 minecraft:white_concrete
fill 544 121 277 544 122 277 minecraft:white_concrete
setblock 547 121 275 minecraft:white_concrete
setblock 547 121 317 minecraft:white_concrete
setblock 548 121 278 minecraft:light[level=12]
setblock 548 121 285 minecraft:light[level=12]
setblock 548 121 292 minecraft:light[level=12]
setblock 548 121 299 minecraft:light[level=12]
setblock 548 121 306 minecraft:light[level=12]
setblock 548 121 313 minecraft:light[level=12]
setblock 551 121 275 minecraft:white_concrete
setblock 551 121 317 minecraft:white_concrete
setblock 555 121 275 minecraft:white_concrete
setblock 555 121 278 minecraft:light[level=12]
setblock 555 121 285 minecraft:light[level=12]
setblock 555 121 292 minecraft:light[level=12]
setblock 555 121 299 minecraft:light[level=12]
setblock 555 121 306 minecraft:light[level=12]
setblock 555 121 313 minecraft:light[level=12]
setblock 555 121 317 minecraft:white_concrete
setblock 559 121 275 minecraft:white_concrete
setblock 559 121 277 minecraft:white_concrete
setblock 559 121 281 minecraft:white_concrete
setblock 559 121 285 minecraft:white_concrete
setblock 559 121 289 minecraft:white_concrete
setblock 559 121 293 minecraft:white_concrete
setblock 559 121 297 minecraft:white_concrete
setblock 559 121 301 minecraft:white_concrete
setblock 559 121 305 minecraft:white_concrete
setblock 559 121 309 minecraft:white_concrete
setblock 559 121 313 minecraft:white_concrete
setblock 559 121 317 minecraft:white_concrete
setblock 517 122 276 minecraft:white_concrete
fill 517 122 277 517 129 277 minecraft:brown_terracotta
setblock 517 122 278 minecraft:white_concrete
setblock 517 122 280 minecraft:white_concrete
fill 517 122 281 517 125 281 minecraft:brown_terracotta
setblock 517 122 282 minecraft:white_concrete
setblock 517 122 284 minecraft:white_concrete
fill 517 122 285 517 129 285 minecraft:brown_terracotta
setblock 517 122 286 minecraft:white_concrete
setblock 517 122 288 minecraft:white_concrete
fill 517 122 289 517 129 289 minecraft:brown_terracotta
setblock 517 122 290 minecraft:white_concrete
setblock 517 122 292 minecraft:white_concrete
fill 517 122 293 517 125 293 minecraft:brown_terracotta
setblock 517 122 294 minecraft:white_concrete
setblock 517 122 296 minecraft:white_concrete
fill 517 122 297 517 129 297 minecraft:brown_terracotta
setblock 517 122 298 minecraft:white_concrete
setblock 517 122 300 minecraft:white_concrete
fill 517 122 301 517 129 301 minecraft:brown_terracotta
setblock 517 122 302 minecraft:white_concrete
setblock 517 122 304 minecraft:white_concrete
fill 517 122 305 517 125 305 minecraft:brown_terracotta
setblock 517 122 306 minecraft:white_concrete
setblock 517 122 308 minecraft:white_concrete
fill 517 122 309 517 129 309 minecraft:brown_terracotta
setblock 517 122 310 minecraft:white_concrete
setblock 517 122 312 minecraft:white_concrete
fill 517 122 313 517 129 313 minecraft:brown_terracotta
setblock 517 122 314 minecraft:white_concrete
setblock 517 122 316 minecraft:white_concrete
setblock 517 122 317 minecraft:brown_terracotta
setblock 518 122 275 minecraft:white_concrete
setblock 518 122 317 minecraft:white_concrete
fill 519 122 275 519 129 275 minecraft:brown_terracotta
fill 519 122 317 519 125 317 minecraft:brown_terracotta
setblock 520 122 275 minecraft:white_concrete
setblock 520 122 317 minecraft:white_concrete
setblock 522 122 275 minecraft:white_concrete
setblock 522 122 317 minecraft:white_concrete
fill 523 122 275 523 129 275 minecraft:brown_terracotta
fill 523 122 317 523 129 317 minecraft:brown_terracotta
setblock 524 122 275 minecraft:white_concrete
setblock 524 122 317 minecraft:white_concrete
setblock 525 122 275 minecraft:brown_terracotta
setblock 526 122 275 minecraft:white_concrete
setblock 526 122 317 minecraft:white_concrete
fill 527 122 275 527 125 275 minecraft:brown_terracotta
fill 527 122 317 527 129 317 minecraft:brown_terracotta
setblock 528 122 275 minecraft:white_concrete
setblock 528 122 317 minecraft:white_concrete
setblock 530 122 275 minecraft:white_concrete
setblock 530 122 317 minecraft:white_concrete
fill 531 122 275 531 129 275 minecraft:brown_terracotta
fill 531 122 317 531 125 317 minecraft:brown_terracotta
setblock 532 122 275 minecraft:white_concrete
setblock 532 122 317 minecraft:white_concrete
setblock 534 122 275 minecraft:white_concrete
setblock 534 122 317 minecraft:white_concrete
fill 535 122 275 535 129 275 minecraft:brown_terracotta
fill 535 122 317 535 129 317 minecraft:brown_terracotta
setblock 536 122 275 minecraft:white_concrete
setblock 536 122 317 minecraft:white_concrete
setblock 538 122 275 minecraft:white_concrete
setblock 538 122 317 minecraft:white_concrete
fill 539 122 275 539 125 275 minecraft:brown_terracotta
fill 539 122 317 539 129 317 minecraft:brown_terracotta
setblock 540 122 275 minecraft:white_concrete
setblock 540 122 317 minecraft:white_concrete
setblock 542 122 275 minecraft:white_concrete
fill 542 122 278 542 123 278 minecraft:white_concrete
fill 542 122 313 542 123 313 minecraft:white_concrete
setblock 542 122 317 minecraft:white_concrete
fill 543 122 275 543 129 275 minecraft:brown_terracotta
fill 543 122 279 543 124 279 minecraft:white_concrete
fill 543 122 312 543 124 312 minecraft:white_concrete
setblock 543 122 315 minecraft:white_concrete
setblock 543 122 316 minecraft:red_concrete
fill 543 122 317 543 125 317 minecraft:brown_terracotta
setblock 544 122 275 minecraft:white_concrete
fill 544 122 278 544 123 278 minecraft:white_concrete
fill 544 122 313 544 123 313 minecraft:white_concrete
setblock 544 122 317 minecraft:white_concrete
setblock 546 122 275 minecraft:white_concrete
setblock 546 122 317 minecraft:white_concrete
fill 547 122 275 547 129 275 minecraft:brown_terracotta
fill 547 122 317 547 129 317 minecraft:brown_terracotta
setblock 548 122 275 minecraft:white_concrete
setblock 548 122 317 minecraft:white_concrete
setblock 550 122 275 minecraft:white_concrete
setblock 550 122 317 minecraft:white_concrete
fill 551 122 275 551 125 275 minecraft:brown_terracotta
fill 551 122 317 551 129 317 minecraft:brown_terracotta
setblock 552 122 275 minecraft:white_concrete
setblock 552 122 317 minecraft:white_concrete
setblock 554 122 275 minecraft:white_concrete
setblock 554 122 317 minecraft:white_concrete
fill 555 122 275 555 129 275 minecraft:brown_terracotta
fill 555 122 317 555 125 317 minecraft:brown_terracotta
setblock 556 122 275 minecraft:white_concrete
setblock 556 122 317 minecraft:white_concrete
setblock 558 122 275 minecraft:white_concrete
setblock 558 122 317 minecraft:white_concrete
setblock 559 122 275 minecraft:brown_terracotta
setblock 559 122 276 minecraft:white_concrete
fill 559 122 277 559 125 277 minecraft:brown_terracotta
setblock 559 122 278 minecraft:white_concrete
setblock 559 122 280 minecraft:white_concrete
fill 559 122 281 559 129 281 minecraft:brown_terracotta
setblock 559 122 282 minecraft:white_concrete
setblock 559 122 284 minecraft:white_concrete
fill 559 122 285 559 129 285 minecraft:brown_terracotta
setblock 559 122 286 minecraft:white_concrete
setblock 559 122 288 minecraft:white_concrete
fill 559 122 289 559 125 289 minecraft:brown_terracotta
setblock 559 122 290 minecraft:white_concrete
setblock 559 122 292 minecraft:white_concrete
fill 559 122 293 559 129 293 minecraft:brown_terracotta
setblock 559 122 294 minecraft:white_concrete
setblock 559 122 296 minecraft:white_concrete
fill 559 122 297 559 129 297 minecraft:brown_terracotta
setblock 559 122 298 minecraft:white_concrete
setblock 559 122 300 minecraft:white_concrete
fill 559 122 301 559 125 301 minecraft:brown_terracotta
setblock 559 122 302 minecraft:white_concrete
setblock 559 122 304 minecraft:white_concrete
fill 559 122 305 559 129 305 minecraft:brown_terracotta
setblock 559 122 306 minecraft:white_concrete
setblock 559 122 308 minecraft:white_concrete
fill 559 122 309 559 129 309 minecraft:brown_terracotta
setblock 559 122 310 minecraft:white_concrete
setblock 559 122 312 minecraft:white_concrete
fill 559 122 313 559 125 313 minecraft:brown_terracotta
setblock 559 122 314 minecraft:white_concrete
setblock 559 122 316 minecraft:white_concrete
fill 559 122 317 559 129 317 minecraft:brown_terracotta
setblock 517 123 275 minecraft:white_concrete
fill 517 123 276 517 130 276 minecraft:brown_terracotta
fill 517 123 278 517 130 278 minecraft:brown_terracotta
setblock 517 123 279 minecraft:white_concrete
fill 517 123 280 517 130 280 minecraft:brown_terracotta
fill 517 123 282 517 125 282 minecraft:brown_terracotta
setblock 517 123 283 minecraft:white_concrete
fill 517 123 284 517 125 284 minecraft:brown_terracotta
fill 517 123 286 517 130 286 minecraft:brown_terracotta
setblock 517 123 287 minecraft:white_concrete
fill 517 123 288 517 130 288 minecraft:brown_terracotta
fill 517 123 290 517 130 290 minecraft:brown_terracotta
setblock 517 123 291 minecraft:white_concrete
fill 517 123 292 517 130 292 minecraft:brown_terracotta
fill 517 123 294 517 125 294 minecraft:brown_terracotta
setblock 517 123 295 minecraft:white_concrete
fill 517 123 296 517 125 296 minecraft:brown_terracotta
fill 517 123 298 517 130 298 minecraft:brown_terracotta
setblock 517 123 299 minecraft:white_concrete
fill 517 123 300 517 130 300 minecraft:brown_terracotta
fill 517 123 302 517 130 302 minecraft:brown_terracotta
setblock 517 123 303 minecraft:white_concrete
fill 517 123 304 517 130 304 minecraft:brown_terracotta
fill 517 123 306 517 125 306 minecraft:brown_terracotta
setblock 517 123 307 minecraft:white_concrete
fill 517 123 308 517 125 308 minecraft:brown_terracotta
fill 517 123 310 517 130 310 minecraft:brown_terracotta
setblock 517 123 311 minecraft:white_concrete
fill 517 123 312 517 130 312 minecraft:brown_terracotta
fill 517 123 314 517 130 314 minecraft:brown_terracotta
setblock 517 123 315 minecraft:white_concrete
fill 517 123 316 517 130 316 minecraft:brown_terracotta
setblock 517 123 317 minecraft:white_concrete
fill 518 123 275 518 130 275 minecraft:brown_terracotta
fill 518 123 317 518 125 317 minecraft:brown_terracotta
fill 520 123 275 520 130 275 minecraft:brown_terracotta
fill 520 123 317 520 125 317 minecraft:brown_terracotta
setblock 521 123 275 minecraft:white_concrete
setblock 521 123 317 minecraft:white_concrete
fill 522 123 275 522 130 275 minecraft:brown_terracotta
fill 522 123 317 522 130 317 minecraft:brown_terracotta
fill 524 123 275 524 125 275 minecraft:brown_terracotta
fill 524 123 317 524 130 317 minecraft:brown_terracotta
setblock 525 123 275 minecraft:white_concrete
setblock 525 123 317 minecraft:white_concrete
fill 526 123 275 526 125 275 minecraft:brown_terracotta
fill 526 123 317 526 130 317 minecraft:brown_terracotta
fill 528 123 275 528 130 275 minecraft:brown_terracotta
fill 528 123 317 528 130 317 minecraft:brown_terracotta
setblock 529 123 275 minecraft:white_concrete
setblock 529 123 317 minecraft:white_concrete
fill 530 123 275 530 130 275 minecraft:brown_terracotta
fill 530 123 317 530 125 317 minecraft:brown_terracotta
fill 532 123 275 532 130 275 minecraft:brown_terracotta
fill 532 123 317 532 125 317 minecraft:brown_terracotta
setblock 533 123 275 minecraft:white_concrete
setblock 533 123 317 minecraft:white_concrete
fill 534 123 275 534 130 275 minecraft:brown_terracotta
fill 534 123 317 534 130 317 minecraft:brown_terracotta
fill 536 123 275 536 125 275 minecraft:brown_terracotta
fill 536 123 317 536 130 317 minecraft:brown_terracotta
setblock 537 123 275 minecraft:white_concrete
setblock 537 123 317 minecraft:white_concrete
fill 538 123 275 538 125 275 minecraft:brown_terracotta
fill 538 123 317 538 130 317 minecraft:brown_terracotta
fill 540 123 275 540 130 275 minecraft:brown_terracotta
fill 540 123 317 540 130 317 minecraft:brown_terracotta
setblock 541 123 275 minecraft:white_concrete
setblock 541 123 317 minecraft:white_concrete
fill 542 123 275 542 130 275 minecraft:brown_terracotta
fill 542 123 279 542 124 280 minecraft:white_concrete
fill 542 123 311 542 124 312 minecraft:white_concrete
fill 542 123 317 542 125 317 minecraft:brown_terracotta
fill 543 123 280 544 124 280 minecraft:white_concrete
fill 543 123 311 544 124 311 minecraft:white_concrete
setblock 543 123 314 minecraft:white_concrete
setblock 543 123 315 minecraft:red_concrete
fill 544 123 275 544 130 275 minecraft:brown_terracotta
fill 544 123 279 544 124 279 minecraft:white_concrete
fill 544 123 312 544 124 312 minecraft:white_concrete
fill 544 123 317 544 125 317 minecraft:brown_terracotta
setblock 545 123 275 minecraft:white_concrete
setblock 545 123 317 minecraft:white_concrete
fill 546 123 275 546 130 275 minecraft:brown_terracotta
fill 546 123 317 546 130 317 minecraft:brown_terracotta
fill 548 123 275 548 125 275 minecraft:brown_terracotta
fill 548 123 317 548 130 317 minecraft:brown_terracotta
setblock 549 123 275 minecraft:white_concrete
setblock 549 123 317 minecraft:white_concrete
fill 550 123 275 550 125 275 minecraft:brown_terracotta
fill 550 123 317 550 130 317 minecraft:brown_terracotta
fill 552 123 275 552 130 275 minecraft:brown_terracotta
fill 552 123 317 552 130 317 minecraft:brown_terracotta
setblock 553 123 275 minecraft:white_concrete
setblock 553 123 317 minecraft:white_concrete
fill 554 123 275 554 130 275 minecraft:brown_terracotta
fill 554 123 317 554 125 317 minecraft:brown_terracotta
fill 556 123 275 556 130 275 minecraft:brown_terracotta
fill 556 123 317 556 125 317 minecraft:brown_terracotta
setblock 557 123 275 minecraft:white_concrete
setblock 557 123 317 minecraft:white_concrete
fill 558 123 275 558 130 275 minecraft:brown_terracotta
fill 558 123 317 558 130 317 minecraft:brown_terracotta
setblock 559 123 275 minecraft:white_concrete
fill 559 123 276 559 125 276 minecraft:brown_terracotta
fill 559 123 278 559 125 278 minecraft:brown_terracotta
setblock 559 123 279 minecraft:white_concrete
fill 559 123 280 559 130 280 minecraft:brown_terracotta
fill 559 123 282 559 130 282 minecraft:brown_terracotta
setblock 559 123 283 minecraft:white_concrete
fill 559 123 284 559 130 284 minecraft:brown_terracotta
fill 559 123 286 559 130 286 minecraft:brown_terracotta
setblock 559 123 287 minecraft:white_concrete
fill 559 123 288 559 125 288 minecraft:brown_terracotta
fill 559 123 290 559 125 290 minecraft:brown_terracotta
setblock 559 123 291 minecraft:white_concrete
fill 559 123 292 559 130 292 minecraft:brown_terracotta
fill 559 123 294 559 130 294 minecraft:brown_terracotta
setblock 559 123 295 minecraft:white_concrete
fill 559 123 296 559 130 296 minecraft:brown_terracotta
fill 559 123 298 559 130 298 minecraft:brown_terracotta
setblock 559 123 299 minecraft:white_concrete
fill 559 123 300 559 125 300 minecraft:brown_terracotta
fill 559 123 302 559 125 302 minecraft:brown_terracotta
setblock 559 123 303 minecraft:white_concrete
fill 559 123 304 559 130 304 minecraft:brown_terracotta
fill 559 123 306 559 130 306 minecraft:brown_terracotta
setblock 559 123 307 minecraft:white_concrete
fill 559 123 308 559 130 308 minecraft:brown_terracotta
fill 559 123 310 559 130 310 minecraft:brown_terracotta
setblock 559 123 311 minecraft:white_concrete
fill 559 123 312 559 125 312 minecraft:brown_terracotta
fill 559 123 314 559 125 314 minecraft:brown_terracotta
setblock 559 123 315 minecraft:white_concrete
fill 559 123 316 559 130 316 minecraft:brown_terracotta
fill 517 124 275 517 131 275 minecraft:brown_terracotta
fill 517 124 279 517 131 279 minecraft:brown_terracotta
fill 517 124 283 517 125 283 minecraft:brown_terracotta
fill 517 124 287 517 131 287 minecraft:brown_terracotta
fill 517 124 291 517 131 291 minecraft:brown_terracotta
fill 517 124 295 517 125 295 minecraft:brown_terracotta
fill 517 124 299 517 131 299 minecraft:brown_terracotta
fill 517 124 303 517 131 303 minecraft:brown_terracotta
fill 517 124 307 517 125 307 minecraft:brown_terracotta
fill 517 124 311 517 131 311 minecraft:brown_terracotta
fill 517 124 315 517 131 315 minecraft:brown_terracotta
fill 517 124 317 517 125 317 minecraft:brown_terracotta
fill 521 124 275 521 131 275 minecraft:brown_terracotta
fill 521 124 317 521 131 317 minecraft:brown_terracotta
fill 525 124 275 525 125 275 minecraft:brown_terracotta
fill 525 124 317 525 131 317 minecraft:brown_terracotta
fill 529 124 275 529 131 275 minecraft:brown_terracotta
fill 529 124 317 529 125 317 minecraft:brown_terracotta
fill 533 124 275 533 131 275 minecraft:brown_terracotta
fill 533 124 317 533 131 317 minecraft:brown_terracotta
fill 537 124 275 537 125 275 minecraft:brown_terracotta
fill 537 124 317 537 131 317 minecraft:brown_terracotta
fill 541 124 275 541 131 275 minecraft:brown_terracotta
fill 541 124 307 541 125 307 minecraft:shroomlight
fill 541 124 317 541 125 317 minecraft:brown_terracotta
fill 542 124 281 544 125 281 minecraft:white_concrete
fill 542 124 310 544 125 310 minecraft:white_concrete
fill 543 124 282 543 126 282 minecraft:white_concrete
fill 543 124 309 543 126 309 minecraft:white_concrete
setblock 543 124 314 minecraft:red_concrete
fill 545 124 275 545 131 275 minecraft:brown_terracotta
fill 545 124 317 545 131 317 minecraft:brown_terracotta
fill 549 124 275 549 125 275 minecraft:brown_terracotta
fill 549 124 317 549 131 317 minecraft:brown_terracotta
fill 553 124 275 553 131 275 minecraft:brown_terracotta
fill 553 124 317 553 125 317 minecraft:brown_terracotta
fill 557 124 275 557 131 275 minecraft:brown_terracotta
fill 557 124 317 557 131 317 minecraft:brown_terracotta
fill 559 124 275 559 129 275 minecraft:brown_terracotta
fill 559 124 279 559 125 279 minecraft:brown_terracotta
fill 559 124 283 559 131 283 minecraft:brown_terracotta
fill 559 124 287 559 131 287 minecraft:brown_terracotta
fill 559 124 291 559 125 291 minecraft:brown_terracotta
fill 559 124 295 559 131 295 minecraft:brown_terracotta
fill 559 124 299 559 131 299 minecraft:brown_terracotta
fill 559 124 303 559 125 303 minecraft:brown_terracotta
fill 559 124 307 559 131 307 minecraft:brown_terracotta
fill 559 124 311 559 131 311 minecraft:brown_terracotta
fill 559 124 315 559 125 315 minecraft:brown_terracotta
fill 518 125 279 518 125 284 minecraft:brown_terracotta
fill 518 125 291 518 125 296 minecraft:brown_terracotta
fill 518 125 303 518 125 308 minecraft:brown_terracotta
fill 518 125 315 518 125 316 minecraft:brown_terracotta
fill 519 125 316 522 125 316 minecraft:brown_terracotta
setblock 520 125 278 minecraft:light[level=15]
setblock 520 125 286 minecraft:light[level=15]
setblock 520 125 294 minecraft:light[level=15]
setblock 520 125 302 minecraft:light[level=15]
setblock 520 125 310 minecraft:light[level=15]
fill 522 125 276 527 125 276 minecraft:brown_terracotta
setblock 528 125 278 minecraft:light[level=15]
setblock 528 125 286 minecraft:light[level=15]
setblock 528 125 294 minecraft:light[level=15]
setblock 528 125 302 minecraft:light[level=15]
setblock 528 125 310 minecraft:light[level=15]
fill 529 125 316 534 125 316 minecraft:brown_terracotta
fill 534 125 276 539 125 276 minecraft:brown_terracotta
setblock 536 125 278 minecraft:light[level=15]
setblock 536 125 286 minecraft:light[level=15]
setblock 536 125 294 minecraft:light[level=15]
setblock 536 125 302 minecraft:light[level=15]
setblock 536 125 310 minecraft:light[level=15]
fill 540 125 284 541 126 285 minecraft:lime_concrete
fill 541 125 316 546 125 316 minecraft:brown_terracotta
fill 542 125 282 542 126 282 minecraft:white_concrete
fill 542 125 309 542 126 309 minecraft:white_concrete
setblock 543 125 279 minecraft:red_concrete
setblock 543 125 280 minecraft:white_concrete
fill 543 125 283 543 127 283 minecraft:white_concrete
fill 543 125 308 543 127 308 minecraft:white_concrete
setblock 543 125 311 minecraft:white_concrete
setblock 543 125 312 minecraft:red_concrete
setblock 544 125 278 minecraft:light[level=15]
fill 544 125 282 544 126 282 minecraft:white_concrete
setblock 544 125 286 minecraft:light[level=15]
setblock 544 125 294 minecraft:light[level=15]
setblock 544 125 302 minecraft:light[level=15]
fill 544 125 309 544 126 309 minecraft:white_concrete
fill 546 125 276 551 125 276 minecraft:brown_terracotta
setblock 552 125 278 minecraft:light[level=15]
setblock 552 125 286 minecraft:light[level=15]
setblock 552 125 294 minecraft:light[level=15]
setblock 552 125 302 minecraft:light[level=15]
setblock 552 125 310 minecraft:light[level=15]
fill 553 125 316 558 125 316 minecraft:brown_terracotta
fill 558 125 276 558 125 281 minecraft:brown_terracotta
fill 558 125 288 558 125 293 minecraft:brown_terracotta
fill 558 125 300 558 125 305 minecraft:brown_terracotta
fill 558 125 312 558 125 315 minecraft:brown_terracotta
fill 517 126 281 517 131 284 minecraft:shroomlight
fill 517 126 293 517 131 296 minecraft:shroomlight
fill 517 126 305 517 131 308 minecraft:shroomlight
fill 517 126 317 520 131 317 minecraft:shroomlight
fill 524 126 275 527 131 275 minecraft:shroomlight
fill 529 126 317 532 131 317 minecraft:shroomlight
fill 536 126 275 539 131 275 minecraft:shroomlight
fill 541 126 307 541 134 307 minecraft:brown_terracotta
fill 541 126 317 544 131 317 minecraft:shroomlight
fill 542 126 283 542 126 284 minecraft:white_concrete
fill 542 126 307 542 126 308 minecraft:white_concrete
setblock 543 126 280 minecraft:red_concrete
setblock 543 126 281 minecraft:white_concrete
fill 543 126 284 543 128 285 minecraft:white_concrete
fill 543 126 306 543 128 307 minecraft:white_concrete
setblock 543 126 310 minecraft:white_concrete
setblock 543 126 311 minecraft:red_concrete
fill 544 126 283 544 126 284 minecraft:white_concrete
fill 544 126 307 544 126 308 minecraft:white_concrete
fill 548 126 275 551 131 275 minecraft:shroomlight
fill 553 126 317 556 131 317 minecraft:shroomlight
fill 559 126 276 559 131 279 minecraft:shroomlight
fill 559 126 288 559 131 291 minecraft:shroomlight
fill 559 126 300 559 131 303 minecraft:shroomlight
fill 559 126 312 559 131 315 minecraft:shroomlight
setblock 520 127 278 minecraft:light[level=12]
setblock 520 127 285 minecraft:light[level=12]
setblock 520 127 292 minecraft:light[level=12]
setblock 520 127 299 minecraft:light[level=12]
setblock 520 127 306 minecraft:light[level=12]
setblock 520 127 313 minecraft:light[level=12]
setblock 527 127 278 minecraft:light[level=12]
setblock 527 127 285 minecraft:light[level=12]
setblock 527 127 292 minecraft:light[level=12]
setblock 527 127 299 minecraft:light[level=12]
setblock 527 127 306 minecraft:light[level=12]
setblock 527 127 313 minecraft:light[level=12]
setblock 534 127 278 minecraft:light[level=12]
setblock 534 127 285 minecraft:light[level=12]
setblock 534 127 292 minecraft:light[level=12]
setblock 534 127 299 minecraft:light[level=12]
setblock 534 127 306 minecraft:light[level=12]
setblock 534 127 313 minecraft:light[level=12]
setblock 541 127 278 minecraft:light[level=12]
setblock 541 127 285 minecraft:light[level=12]
setblock 541 127 292 minecraft:light[level=12]
setblock 541 127 299 minecraft:light[level=12]
setblock 541 127 306 minecraft:light[level=12]
setblock 541 127 313 minecraft:light[level=12]
fill 542 127 284 542 127 286 minecraft:white_concrete
fill 542 127 305 542 127 307 minecraft:white_concrete
setblock 543 127 282 minecraft:red_concrete
fill 543 127 286 543 129 287 minecraft:white_concrete
fill 543 127 304 543 129 305 minecraft:white_concrete
setblock 543 127 309 minecraft:red_concrete
fill 544 127 284 544 127 286 minecraft:white_concrete
fill 544 127 305 544 127 307 minecraft:white_concrete
setblock 548 127 278 minecraft:light[level=12]
setblock 548 127 285 minecraft:light[level=12]
setblock 548 127 292 minecraft:light[level=12]
setblock 548 127 299 minecraft:light[level=12]
setblock 548 127 306 minecraft:light[level=12]
setblock 548 127 313 minecraft:light[level=12]
setblock 555 127 278 minecraft:light[level=12]
setblock 555 127 285 minecraft:light[level=12]
setblock 555 127 292 minecraft:light[level=12]
setblock 555 127 299 minecraft:light[level=12]
setblock 555 127 306 minecraft:light[level=12]
setblock 555 127 313 minecraft:light[level=12]
fill 541 128 306 541 134 306 minecraft:brown_terracotta
fill 542 128 285 542 128 288 minecraft:white_concrete
fill 542 128 303 542 128 306 minecraft:white_concrete
fill 542 128 307 542 134 307 minecraft:brown_terracotta
setblock 543 128 283 minecraft:red_concrete
fill 543 128 288 543 130 289 minecraft:white_concrete
fill 543 128 302 543 130 303 minecraft:white_concrete
setblock 543 128 308 minecraft:red_concrete
fill 544 128 285 544 128 288 minecraft:white_concrete
fill 544 128 303 544 128 306 minecraft:white_concrete
fill 520 129 312 520 129 314 minecraft:brown_terracotta
setblock 521 129 311 minecraft:brown_terracotta
fill 521 129 315 523 129 315 minecraft:brown_terracotta
fill 523 129 311 524 129 311 minecraft:brown_terracotta
fill 524 129 312 524 129 314 minecraft:brown_terracotta
fill 540 129 306 540 134 307 minecraft:brown_terracotta
fill 541 129 308 541 134 308 minecraft:brown_terracotta
fill 542 129 287 542 129 291 minecraft:white_concrete
fill 542 129 300 542 129 304 minecraft:white_concrete
fill 542 129 306 542 134 306 minecraft:brown_terracotta
setblock 543 129 285 minecraft:red_concrete
fill 543 129 290 543 130 293 minecraft:white_concrete
fill 543 129 298 543 130 301 minecraft:white_concrete
setblock 543 129 306 minecraft:red_concrete
fill 544 129 287 544 129 291 minecraft:white_concrete
fill 544 129 300 544 129 304 minecraft:white_concrete
setblock 517 130 277 minecraft:white_concrete
setblock 517 130 285 minecraft:white_concrete
setblock 517 130 289 minecraft:white_concrete
setblock 517 130 297 minecraft:white_concrete
setblock 517 130 301 minecraft:white_concrete
setblock 517 130 309 minecraft:white_concrete
setblock 517 130 313 minecraft:white_concrete
setblock 519 130 275 minecraft:white_concrete
setblock 523 130 275 minecraft:white_concrete
setblock 523 130 317 minecraft:white_concrete
setblock 527 130 317 minecraft:white_concrete
setblock 531 130 275 minecraft:white_concrete
setblock 535 130 275 minecraft:white_concrete
setblock 535 130 317 minecraft:white_concrete
setblock 539 130 317 minecraft:white_concrete
fill 540 130 305 542 134 305 minecraft:brown_terracotta
fill 540 130 308 540 134 308 minecraft:brown_terracotta
fill 542 130 290 542 130 301 minecraft:white_concrete
fill 542 130 308 542 134 308 minecraft:brown_terracotta
setblock 543 130 275 minecraft:white_concrete
fill 543 130 286 543 130 287 minecraft:red_concrete
fill 543 130 294 544 131 297 minecraft:white_concrete
fill 543 130 304 543 130 305 minecraft:red_concrete
fill 543 130 306 543 134 307 minecraft:brown_terracotta
fill 544 130 290 544 130 293 minecraft:white_concrete
fill 544 130 298 544 130 301 minecraft:white_concrete
setblock 547 130 275 minecraft:white_concrete
setblock 547 130 317 minecraft:white_concrete
setblock 551 130 317 minecraft:white_concrete
setblock 555 130 275 minecraft:white_concrete
setblock 559 130 275 minecraft:white_concrete
setblock 559 130 281 minecraft:white_concrete
setblock 559 130 285 minecraft:white_concrete
setblock 559 130 293 minecraft:white_concrete
setblock 559 130 297 minecraft:white_concrete
setblock 559 130 305 minecraft:white_concrete
setblock 559 130 309 minecraft:white_concrete
setblock 559 130 317 minecraft:white_concrete
setblock 517 131 276 minecraft:white_concrete
fill 517 131 277 517 138 277 minecraft:brown_terracotta
setblock 517 131 278 minecraft:white_concrete
setblock 517 131 280 minecraft:white_concrete
fill 517 131 285 517 138 285 minecraft:brown_terracotta
setblock 517 131 286 minecraft:white_concrete
setblock 517 131 288 minecraft:white_concrete
fill 517 131 289 517 138 289 minecraft:brown_terracotta
setblock 517 131 290 minecraft:white_concrete
setblock 517 131 292 minecraft:white_concrete
fill 517 131 297 517 138 297 minecraft:brown_terracotta
setblock 517 131 298 minecraft:white_concrete
setblock 517 131 300 minecraft:white_concrete
fill 517 131 301 517 138 301 minecraft:brown_terracotta
setblock 517 131 302 minecraft:white_concrete
setblock 517 131 304 minecraft:white_concrete
fill 517 131 309 517 138 309 minecraft:brown_terracotta
setblock 517 131 310 minecraft:white_concrete
setblock 517 131 312 minecraft:white_concrete
fill 517 131 313 517 138 313 minecraft:brown_terracotta
setblock 517 131 314 minecraft:white_concrete
setblock 517 131 316 minecraft:white_concrete
setblock 518 131 275 minecraft:white_concrete
fill 519 131 275 519 138 275 minecraft:brown_terracotta
setblock 520 131 275 minecraft:white_concrete
setblock 522 131 275 minecraft:white_concrete
fill 522 131 295 522 132 295 minecraft:shroomlight
setblock 522 131 317 minecraft:white_concrete
fill 523 131 275 523 138 275 minecraft:brown_terracotta
fill 523 131 317 523 138 317 minecraft:brown_terracotta
setblock 524 131 317 minecraft:white_concrete
setblock 526 131 317 minecraft:white_concrete
fill 527 131 317 527 138 317 minecraft:brown_terracotta
setblock 528 131 275 minecraft:white_concrete
setblock 528 131 317 minecraft:white_concrete
setblock 530 131 275 minecraft:white_concrete
fill 531 131 275 531 138 275 minecraft:brown_terracotta
setblock 532 131 275 minecraft:white_concrete
setblock 534 131 275 minecraft:white_concrete
setblock 534 131 317 minecraft:white_concrete
fill 535 131 275 535 138 275 minecraft:brown_terracotta
fill 535 131 317 535 138 317 minecraft:brown_terracotta
setblock 536 131 317 minecraft:white_concrete
setblock 538 131 317 minecraft:white_concrete
fill 539 131 306 539 134 308 minecraft:brown_terracotta
fill 539 131 317 539 138 317 minecraft:brown_terracotta
setblock 540 131 275 minecraft:white_concrete
setblock 540 131 317 minecraft:white_concrete
fill 541 131 309 542 134 309 minecraft:brown_terracotta
setblock 542 131 275 minecraft:white_concrete
fill 542 131 293 542 131 298 minecraft:white_concrete
fill 543 131 275 543 138 275 minecraft:brown_terracotta
fill 543 131 288 543 131 290 minecraft:red_concrete
fill 543 131 291 543 131 293 minecraft:white_concrete
fill 543 131 298 543 131 300 minecraft:white_concrete
fill 543 131 301 543 131 303 minecraft:red_concrete
fill 543 131 305 543 134 305 minecraft:brown_terracotta
fill 543 131 308 543 134 308 minecraft:brown_terracotta
setblock 544 131 275 minecraft:white_concrete
setblock 544 131 293 minecraft:white_concrete
setblock 544 131 298 minecraft:white_concrete
setblock 546 131 275 minecraft:white_concrete
setblock 546 131 317 minecraft:white_concrete
fill 547 131 275 547 138 275 minecraft:brown_terracotta
fill 547 131 317 547 138 317 minecraft:brown_terracotta
setblock 548 131 317 minecraft:white_concrete
setblock 550 131 317 minecraft:white_concrete
fill 551 131 317 551 138 317 minecraft:brown_terracotta
setblock 552 131 275 minecraft:white_concrete
setblock 552 131 317 minecraft:white_concrete
setblock 554 131 275 minecraft:white_concrete
fill 555 131 275 555 138 275 minecraft:brown_terracotta
setblock 556 131 275 minecraft:white_concrete
setblock 558 131 275 minecraft:white_concrete
setblock 558 131 317 minecraft:white_concrete
setblock 559 131 275 minecraft:brown_terracotta
setblock 559 131 280 minecraft:white_concrete
fill 559 131 281 559 138 281 minecraft:brown_terracotta
setblock 559 131 282 minecraft:white_concrete
setblock 559 131 284 minecraft:white_concrete
fill 559 131 285 559 138 285 minecraft:brown_terracotta
setblock 559 131 286 minecraft:white_concrete
setblock 559 131 292 minecraft:white_concrete
fill 559 131 293 559 138 293 minecraft:brown_terracotta
setblock 559 131 294 minecraft:white_concrete
setblock 559 131 296 minecraft:white_concrete
fill 559 131 297 559 138 297 minecraft:brown_terracotta
setblock 559 131 298 minecraft:white_concrete
setblock 559 131 304 minecraft:white_concrete
fill 559 131 305 559 138 305 minecraft:brown_terracotta
setblock 559 131 306 minecraft:white_concrete
setblock 559 131 308 minecraft:white_concrete
fill 559 131 309 559 138 309 minecraft:brown_terracotta
setblock 559 131 310 minecraft:white_concrete
setblock 559 131 316 minecraft:white_concrete
fill 559 131 317 559 138 317 minecraft:brown_terracotta
setblock 517 132 275 minecraft:white_concrete
fill 517 132 276 517 139 276 minecraft:brown_terracotta
fill 517 132 278 517 139 278 minecraft:brown_terracotta
setblock 517 132 279 minecraft:white_concrete
fill 517 132 280 517 138 281 minecraft:brown_terracotta
fill 517 132 282 517 132 283 minecraft:shroomlight
fill 517 132 284 517 139 284 minecraft:brown_terracotta
fill 517 132 286 517 139 286 minecraft:brown_terracotta
setblock 517 132 287 minecraft:white_concrete
fill 517 132 288 517 139 288 minecraft:brown_terracotta
fill 517 132 290 517 139 290 minecraft:brown_terracotta
setblock 517 132 291 minecraft:white_concrete
fill 517 132 292 517 138 293 minecraft:brown_terracotta
fill 517 132 294 517 132 295 minecraft:shroomlight
fill 517 132 296 517 139 296 minecraft:brown_terracotta
fill 517 132 298 517 139 298 minecraft:brown_terracotta
setblock 517 132 299 minecraft:white_concrete
fill 517 132 300 517 139 300 minecraft:brown_terracotta
fill 517 132 302 517 139 302 minecraft:brown_terracotta
setblock 517 132 303 minecraft:white_concrete
fill 517 132 304 517 138 305 minecraft:brown_terracotta
fill 517 132 306 517 132 307 minecraft:shroomlight
fill 517 132 308 517 139 308 minecraft:brown_terracotta
fill 517 132 310 517 139 310 minecraft:brown_terracotta
setblock 517 132 311 minecraft:white_concrete
fill 517 132 312 517 139 312 minecraft:brown_terracotta
fill 517 132 314 517 139 314 minecraft:brown_terracotta
setblock 517 132 315 minecraft:white_concrete
fill 517 132 316 517 139 316 minecraft:brown_terracotta
setblock 517 132 317 minecraft:white_concrete
fill 518 132 275 518 139 275 minecraft:brown_terracotta
fill 518 132 317 519 132 317 minecraft:shroomlight
fill 520 132 275 520 139 275 minecraft:brown_terracotta
fill 520 132 317 520 139 317 minecraft:brown_terracotta
setblock 521 132 275 minecraft:white_concrete
setblock 521 132 317 minecraft:white_concrete
fill 522 132 275 522 139 275 minecraft:brown_terracotta
fill 522 132 317 522 139 317 minecraft:brown_terracotta
fill 524 132 275 524 139 275 minecraft:brown_terracotta
fill 524 132 317 524 139 317 minecraft:brown_terracotta
fill 525 132 275 526 132 275 minecraft:shroomlight
setblock 525 132 317 minecraft:white_concrete
fill 526 132 317 526 139 317 minecraft:brown_terracotta
fill 527 132 275 528 138 275 minecraft:brown_terracotta
fill 528 132 317 528 139 317 minecraft:brown_terracotta
setblock 529 132 275 minecraft:white_concrete
setblock 529 132 317 minecraft:white_concrete
fill 530 132 275 530 139 275 minecraft:brown_terracotta
fill 530 132 317 531 132 317 minecraft:shroomlight
fill 532 132 275 532 139 275 minecraft:brown_terracotta
fill 532 132 317 532 139 317 minecraft:brown_terracotta
setblock 533 132 275 minecraft:white_concrete
setblock 533 132 317 minecraft:white_concrete
fill 534 132 275 534 139 275 minecraft:brown_terracotta
fill 534 132 317 534 139 317 minecraft:brown_terracotta
fill 536 132 275 536 139 275 minecraft:brown_terracotta
fill 536 132 317 536 139 317 minecraft:brown_terracotta
fill 537 132 275 538 132 275 minecraft:shroomlight
setblock 537 132 317 minecraft:white_concrete
fill 538 132 317 538 139 317 minecraft:brown_terracotta
fill 539 132 275 540 138 275 minecraft:brown_terracotta
fill 539 132 305 539 134 305 minecraft:brown_terracotta
fill 540 132 304 542 134 304 minecraft:brown_terracotta
fill 540 132 309 540 134 309 minecraft:brown_terracotta
fill 540 132 317 540 139 317 minecraft:brown_terracotta
setblock 541 132 275 minecraft:white_concrete
setblock 541 132 317 minecraft:white_concrete
fill 542 132 275 542 139 275 minecraft:brown_terracotta
fill 542 132 317 543 132 317 minecraft:shroomlight
fill 543 132 292 543 132 299 minecraft:red_concrete
fill 544 132 275 544 139 275 minecraft:brown_terracotta
fill 544 132 306 544 134 307 minecraft:brown_terracotta
fill 544 132 317 544 139 317 minecraft:brown_terracotta
setblock 545 132 275 minecraft:white_concrete
setblock 545 132 317 minecraft:white_concrete
fill 546 132 275 546 139 275 minecraft:brown_terracotta
fill 546 132 317 546 139 317 minecraft:brown_terracotta
fill 548 132 275 548 139 275 minecraft:brown_terracotta
fill 548 132 317 548 139 317 minecraft:brown_terracotta
fill 549 132 275 550 132 275 minecraft:shroomlight
setblock 549 132 317 minecraft:white_concrete
fill 550 132 317 550 139 317 minecraft:brown_terracotta
fill 551 132 275 552 138 275 minecraft:brown_terracotta
fill 552 132 317 552 139 317 minecraft:brown_terracotta
setblock 553 132 275 minecraft:white_concrete
setblock 553 132 317 minecraft:white_concrete
fill 554 132 275 554 139 275 minecraft:brown_terracotta
fill 554 132 317 555 132 317 minecraft:shroomlight
fill 556 132 275 556 139 275 minecraft:brown_terracotta
fill 556 132 317 556 139 317 minecraft:brown_terracotta
setblock 557 132 275 minecraft:white_concrete
setblock 557 132 317 minecraft:white_concrete
fill 558 132 275 558 139 275 minecraft:brown_terracotta
fill 558 132 317 558 139 317 minecraft:brown_terracotta
setblock 559 132 275 minecraft:white_concrete
fill 559 132 276 559 139 276 minecraft:brown_terracotta
fill 559 132 277 559 132 278 minecraft:shroomlight
setblock 559 132 279 minecraft:white_concrete
fill 559 132 280 559 139 280 minecraft:brown_terracotta
fill 559 132 282 559 139 282 minecraft:brown_terracotta
setblock 559 132 283 minecraft:white_concrete
fill 559 132 284 559 139 284 minecraft:brown_terracotta
fill 559 132 286 559 139 286 minecraft:brown_terracotta
setblock 559 132 287 minecraft:white_concrete
fill 559 132 288 559 139 288 minecraft:brown_terracotta
fill 559 132 289 559 132 290 minecraft:shroomlight
setblock 559 132 291 minecraft:white_concrete
fill 559 132 292 559 139 292 minecraft:brown_terracotta
fill 559 132 294 559 139 294 minecraft:brown_terracotta
setblock 559 132 295 minecraft:white_concrete
fill 559 132 296 559 139 296 minecraft:brown_terracotta
fill 559 132 298 559 139 298 minecraft:brown_terracotta
setblock 559 132 299 minecraft:white_concrete
fill 559 132 300 559 139 300 minecraft:brown_terracotta
fill 559 132 301 559 132 302 minecraft:shroomlight
setblock 559 132 303 minecraft:white_concrete
fill 559 132 304 559 139 304 minecraft:brown_terracotta
fill 559 132 306 559 139 306 minecraft:brown_terracotta
setblock 559 132 307 minecraft:white_concrete
fill 559 132 308 559 139 308 minecraft:brown_terracotta
fill 559 132 310 559 139 310 minecraft:brown_terracotta
setblock 559 132 311 minecraft:white_concrete
fill 559 132 312 559 139 312 minecraft:brown_terracotta
fill 559 132 313 559 132 314 minecraft:shroomlight
setblock 559 132 315 minecraft:white_concrete
fill 559 132 316 559 139 316 minecraft:brown_terracotta
fill 517 133 275 517 140 275 minecraft:brown_terracotta
fill 517 133 279 517 140 279 minecraft:brown_terracotta
fill 517 133 282 517 139 283 minecraft:brown_terracotta
fill 517 133 287 517 140 287 minecraft:brown_terracotta
fill 517 133 291 517 140 291 minecraft:brown_terracotta
fill 517 133 294 517 139 295 minecraft:brown_terracotta
fill 517 133 299 517 140 299 minecraft:brown_terracotta
fill 517 133 303 517 140 303 minecraft:brown_terracotta
fill 517 133 306 517 139 307 minecraft:brown_terracotta
fill 517 133 311 517 140 311 minecraft:brown_terracotta
fill 517 133 315 517 140 315 minecraft:brown_terracotta
fill 517 133 317 519 138 317 minecraft:brown_terracotta
fill 519 133 291 519 134 297 minecraft:iron_block
setblock 520 133 278 minecraft:light[level=15]
setblock 520 133 285 minecraft:light[level=12]
setblock 520 133 286 minecraft:light[level=15]
setblock 520 133 292 minecraft:light[level=12]
setblock 520 133 294 minecraft:light[level=15]
setblock 520 133 299 minecraft:light[level=12]
setblock 520 133 302 minecraft:light[level=15]
setblock 520 133 306 minecraft:light[level=12]
setblock 520 133 310 minecraft:light[level=15]
setblock 520 133 313 minecraft:light[level=12]
fill 521 133 275 521 140 275 minecraft:brown_terracotta
fill 521 133 317 521 140 317 minecraft:brown_terracotta
fill 522 133 295 522 139 295 minecraft:brown_terracotta
fill 525 133 275 526 139 275 minecraft:brown_terracotta
fill 525 133 317 525 140 317 minecraft:brown_terracotta
setblock 527 133 278 minecraft:light[level=12]
setblock 527 133 285 minecraft:light[level=12]
setblock 527 133 292 minecraft:light[level=12]
setblock 527 133 299 minecraft:light[level=12]
setblock 527 133 306 minecraft:light[level=12]
setblock 527 133 313 minecraft:light[level=12]
setblock 528 133 278 minecraft:light[level=15]
setblock 528 133 286 minecraft:light[level=15]
setblock 528 133 294 minecraft:light[level=15]
setblock 528 133 302 minecraft:light[level=15]
setblock 528 133 310 minecraft:light[level=15]
fill 529 133 275 529 140 275 minecraft:brown_terracotta
fill 529 133 317 531 138 317 minecraft:brown_terracotta
fill 533 133 275 533 140 275 minecraft:brown_terracotta
fill 533 133 317 533 140 317 minecraft:brown_terracotta
setblock 534 133 278 minecraft:light[level=12]
setblock 534 133 285 minecraft:light[level=12]
setblock 534 133 292 minecraft:light[level=12]
setblock 534 133 299 minecraft:light[level=12]
setblock 534 133 306 minecraft:light[level=12]
setblock 534 133 313 minecraft:light[level=12]
setblock 536 133 278 minecraft:light[level=15]
setblock 536 133 286 minecraft:light[level=15]
setblock 536 133 294 minecraft:light[level=15]
setblock 536 133 302 minecraft:light[level=15]
setblock 536 133 310 minecraft:light[level=15]
fill 537 133 275 538 139 275 minecraft:brown_terracotta
fill 537 133 317 537 140 317 minecraft:brown_terracotta
fill 538 133 306 538 134 308 minecraft:brown_terracotta
fill 539 133 304 539 134 304 minecraft:brown_terracotta
fill 539 133 309 539 134 309 minecraft:brown_terracotta
fill 541 133 275 541 140 275 minecraft:brown_terracotta
setblock 541 133 278 minecraft:light[level=12]
setblock 541 133 285 minecraft:light[level=12]
setblock 541 133 292 minecraft:light[level=12]
setblock 541 133 299 minecraft:light[level=12]
fill 541 133 310 542 134 310 minecraft:brown_terracotta
setblock 541 133 313 minecraft:light[level=12]
fill 541 133 317 543 138 317 minecraft:brown_terracotta
fill 543 133 304 543 134 304 minecraft:brown_terracotta
fill 543 133 309 543 134 309 minecraft:brown_terracotta
setblock 544 133 278 minecraft:light[level=15]
setblock 544 133 286 minecraft:light[level=15]
setblock 544 133 294 minecraft:light[level=15]
setblock 544 133 302 minecraft:light[level=15]
fill 544 133 305 544 134 305 minecraft:brown_terracotta
fill 544 133 308 544 134 308 minecraft:brown_terracotta
setblock 544 133 310 minecraft:light[level=15]
fill 545 133 275 545 140 275 minecraft:brown_terracotta
fill 545 133 317 545 140 317 minecraft:brown_terracotta
setblock 548 133 278 minecraft:light[level=12]
setblock 548 133 285 minecraft:light[level=12]
setblock 548 133 292 minecraft:light[level=12]
setblock 548 133 299 minecraft:light[level=12]
setblock 548 133 306 minecraft:light[level=12]
setblock 548 133 313 minecraft:light[level=12]
fill 549 133 275 550 139 275 minecraft:brown_terracotta
fill 549 133 317 549 140 317 minecraft:brown_terracotta
setblock 552 133 278 minecraft:light[level=15]
setblock 552 133 286 minecraft:light[level=15]
setblock 552 133 294 minecraft:light[level=15]
setblock 552 133 302 minecraft:light[level=15]
setblock 552 133 310 minecraft:light[level=15]
fill 553 133 275 553 140 275 minecraft:brown_terracotta
fill 553 133 317 555 138 317 minecraft:brown_terracotta
setblock 555 133 278 minecraft:light[level=12]
setblock 555 133 285 minecraft:light[level=12]
setblock 555 133 292 minecraft:light[level=12]
setblock 555 133 299 minecraft:light[level=12]
setblock 555 133 306 minecraft:light[level=12]
setblock 555 133 313 minecraft:light[level=12]
fill 557 133 275 557 140 275 minecraft:brown_terracotta
fill 557 133 317 557 140 317 minecraft:brown_terracotta
fill 559 133 275 559 138 275 minecraft:brown_terracotta
fill 559 133 277 559 138 279 minecraft:brown_terracotta
fill 559 133 283 559 140 283 minecraft:brown_terracotta
fill 559 133 287 559 140 287 minecraft:brown_terracotta
fill 559 133 289 559 138 291 minecraft:brown_terracotta
fill 559 133 295 559 140 295 minecraft:brown_terracotta
fill 559 133 299 559 140 299 minecraft:brown_terracotta
fill 559 133 301 559 138 303 minecraft:brown_terracotta
fill 559 133 307 559 140 307 minecraft:brown_terracotta
fill 559 133 311 559 140 311 minecraft:brown_terracotta
fill 559 133 313 559 138 315 minecraft:brown_terracotta
fill 522 134 294 522 139 294 minecraft:brown_terracotta
fill 523 134 295 523 139 295 minecraft:brown_terracotta
setblock 538 134 305 minecraft:brown_terracotta
setblock 538 134 309 minecraft:brown_terracotta
fill 540 134 303 542 134 303 minecraft:brown_terracotta
setblock 540 134 310 minecraft:brown_terracotta
setblock 543 134 310 minecraft:brown_terracotta
setblock 544 134 309 minecraft:brown_terracotta
setblock 545 134 307 minecraft:brown_terracotta
fill 521 135 295 521 139 295 minecraft:brown_terracotta
fill 522 135 296 523 139 296 minecraft:brown_terracotta
fill 523 135 294 523 139 294 minecraft:brown_terracotta
fill 541 135 307 541 137 307 minecraft:white_concrete
fill 546 135 292 547 136 293 minecraft:white_concrete
fill 521 136 294 521 139 294 minecraft:brown_terracotta
fill 521 136 296 521 139 296 minecraft:brown_terracotta
fill 522 136 293 522 139 293 minecraft:brown_terracotta
fill 524 136 294 524 139 295 minecraft:brown_terracotta
fill 520 137 295 520 139 295 minecraft:brown_terracotta
fill 520 137 312 520 137 314 minecraft:brown_terracotta
fill 521 137 293 521 139 293 minecraft:brown_terracotta
setblock 521 137 311 minecraft:brown_terracotta
fill 521 137 315 523 137 315 minecraft:brown_terracotta
fill 522 137 297 523 139 297 minecraft:brown_terracotta
fill 523 137 293 523 139 293 minecraft:brown_terracotta
fill 523 137 311 524 137 311 minecraft:brown_terracotta
fill 524 137 296 524 139 296 minecraft:brown_terracotta
fill 524 137 312 524 137 314 minecraft:brown_terracotta
fill 520 138 294 520 139 294 minecraft:brown_terracotta
fill 520 138 296 520 139 296 minecraft:brown_terracotta
fill 520 138 312 520 139 313 minecraft:red_concrete
fill 521 138 297 521 139 297 minecraft:brown_terracotta
fill 521 138 303 521 139 303 minecraft:lime_concrete
fill 521 138 311 521 139 311 minecraft:red_concrete
fill 522 138 315 522 139 315 minecraft:red_concrete
fill 523 138 311 523 139 311 minecraft:red_concrete
fill 524 138 293 524 139 293 minecraft:brown_terracotta
fill 524 138 297 524 139 297 minecraft:brown_terracotta
fill 524 138 312 524 139 314 minecraft:red_concrete
fill 525 138 295 525 139 295 minecraft:brown_terracotta
fill 540 138 306 542 139 308 minecraft:spruce_leaves[persistent=true]
fill 541 138 305 542 139 305 minecraft:spruce_leaves[persistent=true]
fill 543 138 306 543 139 307 minecraft:spruce_leaves[persistent=true]
setblock 517 139 277 minecraft:white_concrete
setblock 517 139 280 minecraft:brown_terracotta
setblock 517 139 281 minecraft:white_concrete
setblock 517 139 285 minecraft:white_concrete
setblock 517 139 289 minecraft:white_concrete
setblock 517 139 292 minecraft:brown_terracotta
setblock 517 139 293 minecraft:white_concrete
setblock 517 139 297 minecraft:white_concrete
setblock 517 139 301 minecraft:white_concrete
setblock 517 139 304 minecraft:brown_terracotta
setblock 517 139 305 minecraft:white_concrete
setblock 517 139 309 minecraft:white_concrete
setblock 517 139 313 minecraft:white_concrete
setblock 517 139 317 minecraft:white_concrete
setblock 518 139 317 minecraft:brown_terracotta
setblock 519 139 275 minecraft:white_concrete
setblock 519 139 317 minecraft:white_concrete
setblock 520 139 278 minecraft:light[level=12]
setblock 520 139 285 minecraft:light[level=12]
setblock 520 139 292 minecraft:light[level=12]
setblock 520 139 293 minecraft:brown_terracotta
setblock 520 139 297 minecraft:brown_terracotta
setblock 520 139 299 minecraft:light[level=12]
setblock 520 139 306 minecraft:light[level=12]
fill 521 139 292 523 139 292 minecraft:brown_terracotta
fill 522 139 298 523 139 298 minecraft:brown_terracotta
setblock 523 139 275 minecraft:white_concrete
setblock 523 139 317 minecraft:white_concrete
setblock 525 139 294 minecraft:brown_terracotta
setblock 525 139 296 minecraft:brown_terracotta
setblock 527 139 275 minecraft:white_concrete
setblock 527 139 278 minecraft:light[level=12]
setblock 527 139 285 minecraft:light[level=12]
setblock 527 139 292 minecraft:light[level=12]
setblock 527 139 299 minecraft:light[level=12]
setblock 527 139 306 minecraft:light[level=12]
setblock 527 139 313 minecraft:light[level=12]
setblock 527 139 317 minecraft:white_concrete
setblock 528 139 275 minecraft:brown_terracotta
fill 529 139 317 530 139 317 minecraft:brown_terracotta
setblock 531 139 275 minecraft:white_concrete
setblock 531 139 317 minecraft:white_concrete
setblock 534 139 278 minecraft:light[level=12]
setblock 534 139 285 minecraft:light[level=12]
setblock 534 139 292 minecraft:light[level=12]
setblock 534 139 299 minecraft:light[level=12]
setblock 534 139 306 minecraft:light[level=12]
setblock 534 139 313 minecraft:light[level=12]
setblock 535 139 275 minecraft:white_concrete
setblock 535 139 317 minecraft:white_concrete
setblock 539 139 275 minecraft:white_concrete
fill 539 139 306 539 139 307 minecraft:spruce_leaves[persistent=true]
setblock 539 139 317 minecraft:white_concrete
setblock 540 139 275 minecraft:brown_terracotta
setblock 540 139 305 minecraft:spruce_leaves[persistent=true]
setblock 541 139 278 minecraft:light[level=12]
setblock 541 139 285 minecraft:light[level=12]
setblock 541 139 292 minecraft:light[level=12]
setblock 541 139 299 minecraft:light[level=12]
setblock 541 139 309 minecraft:spruce_leaves[persistent=true]
setblock 541 139 313 minecraft:light[level=12]
fill 541 139 317 542 139 317 minecraft:brown_terracotta
setblock 543 139 275 minecraft:white_concrete
setblock 543 139 308 minecraft:spruce_leaves[persistent=true]
setblock 543 139 317 minecraft:white_concrete
setblock 547 139 275 minecraft:white_concrete
setblock 547 139 317 minecraft:white_concrete
setblock 548 139 278 minecraft:light[level=12]
setblock 548 139 285 minecraft:light[level=12]
setblock 548 139 292 minecraft:light[level=12]
setblock 548 139 299 minecraft:light[level=12]
setblock 548 139 306 minecraft:light[level=12]
setblock 548 139 313 minecraft:light[level=12]
setblock 551 139 275 minecraft:white_concrete
setblock 551 139 317 minecraft:white_concrete
setblock 552 139 275 minecraft:brown_terracotta
fill 553 139 317 554 139 317 minecraft:brown_terracotta
setblock 555 139 275 minecraft:white_concrete
setblock 555 139 278 minecraft:light[level=12]
setblock 555 139 285 minecraft:light[level=12]
setblock 555 139 292 minecraft:light[level=12]
setblock 555 139 299 minecraft:light[level=12]
setblock 555 139 306 minecraft:light[level=12]
setblock 555 139 313 minecraft:light[level=12]
setblock 555 139 317 minecraft:white_concrete
setblock 559 139 275 minecraft:white_concrete
setblock 559 139 277 minecraft:white_concrete
fill 559 139 278 559 139 279 minecraft:brown_terracotta
setblock 559 139 281 minecraft:white_concrete
setblock 559 139 285 minecraft:white_concrete
setblock 559 139 289 minecraft:white_concrete
fill 559 139 290 559 139 291 minecraft:brown_terracotta
setblock 559 139 293 minecraft:white_concrete
setblock 559 139 297 minecraft:white_concrete
setblock 559 139 301 minecraft:white_concrete
fill 559 139 302 559 139 303 minecraft:brown_terracotta
setblock 559 139 305 minecraft:white_concrete
setblock 559 139 309 minecraft:white_concrete
setblock 559 139 313 minecraft:white_concrete
fill 559 139 314 559 139 315 minecraft:brown_terracotta
setblock 559 139 317 minecraft:white_concrete
setblock 517 140 276 minecraft:white_concrete
fill 517 140 277 517 147 277 minecraft:brown_terracotta
setblock 517 140 278 minecraft:white_concrete
setblock 517 140 280 minecraft:white_concrete
fill 517 140 281 517 147 281 minecraft:brown_terracotta
setblock 517 140 282 minecraft:white_concrete
setblock 517 140 283 minecraft:brown_terracotta
setblock 517 140 284 minecraft:white_concrete
fill 517 140 285 517 147 285 minecraft:brown_terracotta
setblock 517 140 286 minecraft:white_concrete
setblock 517 140 288 minecraft:white_concrete
fill 517 140 289 517 147 289 minecraft:brown_terracotta
setblock 517 140 290 minecraft:white_concrete
setblock 517 140 292 minecraft:white_concrete
fill 517 140 293 517 147 293 minecraft:brown_terracotta
setblock 517 140 294 minecraft:white_concrete
setblock 517 140 295 minecraft:brown_terracotta
setblock 517 140 296 minecraft:white_concrete
fill 517 140 297 517 147 297 minecraft:brown_terracotta
setblock 517 140 298 minecraft:white_concrete
setblock 517 140 300 minecraft:white_concrete
fill 517 140 301 517 147 301 minecraft:brown_terracotta
setblock 517 140 302 minecraft:white_concrete
setblock 517 140 304 minecraft:white_concrete
fill 517 140 305 517 147 305 minecraft:brown_terracotta
setblock 517 140 306 minecraft:white_concrete
setblock 517 140 307 minecraft:brown_terracotta
setblock 517 140 308 minecraft:white_concrete
fill 517 140 309 517 147 309 minecraft:brown_terracotta
setblock 517 140 310 minecraft:white_concrete
setblock 517 140 312 minecraft:white_concrete
fill 517 140 313 517 147 313 minecraft:brown_terracotta
setblock 517 140 314 minecraft:white_concrete
setblock 517 140 316 minecraft:white_concrete
setblock 517 140 317 minecraft:brown_terracotta
setblock 518 140 275 minecraft:white_concrete
setblock 518 140 317 minecraft:white_concrete
fill 519 140 275 519 147 275 minecraft:brown_terracotta
fill 519 140 317 519 147 317 minecraft:brown_terracotta
setblock 520 140 275 minecraft:white_concrete
setblock 520 140 317 minecraft:white_concrete
setblock 522 140 275 minecraft:white_concrete
setblock 522 140 317 minecraft:white_concrete
fill 523 140 275 523 147 275 minecraft:brown_terracotta
fill 523 140 317 523 147 317 minecraft:brown_terracotta
setblock 524 140 275 minecraft:white_concrete
setblock 524 140 317 minecraft:white_concrete
setblock 525 140 275 minecraft:brown_terracotta
setblock 526 140 275 minecraft:white_concrete
setblock 526 140 317 minecraft:white_concrete
fill 527 140 275 527 147 275 minecraft:brown_terracotta
fill 527 140 317 527 147 317 minecraft:brown_terracotta
setblock 528 140 275 minecraft:white_concrete
setblock 528 140 317 minecraft:white_concrete
setblock 529 140 317 minecraft:brown_terracotta
setblock 530 140 275 minecraft:white_concrete
setblock 530 140 317 minecraft:white_concrete
fill 531 140 275 531 147 275 minecraft:brown_terracotta
fill 531 140 317 531 147 317 minecraft:brown_terracotta
setblock 532 140 275 minecraft:white_concrete
setblock 532 140 317 minecraft:white_concrete
setblock 534 140 275 minecraft:white_concrete
setblock 534 140 317 minecraft:white_concrete
fill 535 140 275 535 147 275 minecraft:brown_terracotta
fill 535 140 317 535 147 317 minecraft:brown_terracotta
setblock 536 140 275 minecraft:white_concrete
setblock 536 140 317 minecraft:white_concrete
setblock 537 140 275 minecraft:brown_terracotta
setblock 538 140 275 minecraft:white_concrete
setblock 538 140 317 minecraft:white_concrete
fill 539 140 275 539 147 275 minecraft:brown_terracotta
fill 539 140 317 539 147 317 minecraft:brown_terracotta
setblock 540 140 275 minecraft:white_concrete
setblock 540 140 317 minecraft:white_concrete
setblock 541 140 317 minecraft:brown_terracotta
setblock 542 140 275 minecraft:white_concrete
setblock 542 140 317 minecraft:white_concrete
fill 543 140 275 543 147 275 minecraft:brown_terracotta
fill 543 140 317 543 147 317 minecraft:brown_terracotta
setblock 544 140 275 minecraft:white_concrete
setblock 544 140 317 minecraft:white_concrete
setblock 546 140 275 minecraft:white_concrete
setblock 546 140 317 minecraft:white_concrete
fill 547 140 275 547 147 275 minecraft:brown_terracotta
fill 547 140 317 547 147 317 minecraft:brown_terracotta
setblock 548 140 275 minecraft:white_concrete
setblock 548 140 317 minecraft:white_concrete
setblock 549 140 275 minecraft:brown_terracotta
setblock 550 140 275 minecraft:white_concrete
setblock 550 140 317 minecraft:white_concrete
fill 551 140 275 551 147 275 minecraft:brown_terracotta
fill 551 140 317 551 147 317 minecraft:brown_terracotta
setblock 552 140 275 minecraft:white_concrete
setblock 552 140 317 minecraft:white_concrete
setblock 553 140 317 minecraft:brown_terracotta
setblock 554 140 275 minecraft:white_concrete
setblock 554 140 317 minecraft:white_concrete
fill 555 140 275 555 147 275 minecraft:brown_terracotta
fill 555 140 317 555 147 317 minecraft:brown_terracotta
setblock 556 140 275 minecraft:white_concrete
setblock 556 140 317 minecraft:white_concrete
setblock 558 140 275 minecraft:white_concrete
setblock 558 140 317 minecraft:white_concrete
setblock 559 140 275 minecraft:brown_terracotta
setblock 559 140 276 minecraft:white_concrete
fill 559 140 277 559 147 277 minecraft:brown_terracotta
setblock 559 140 278 minecraft:white_concrete
setblock 559 140 279 minecraft:brown_terracotta
setblock 559 140 280 minecraft:white_concrete
fill 559 140 281 559 147 281 minecraft:brown_terracotta
setblock 559 140 282 minecraft:white_concrete
setblock 559 140 284 minecraft:white_concrete
fill 559 140 285 559 147 285 minecraft:brown_terracotta
setblock 559 140 286 minecraft:white_concrete
setblock 559 140 288 minecraft:white_concrete
fill 559 140 289 559 147 289 minecraft:brown_terracotta
setblock 559 140 290 minecraft:white_concrete
setblock 559 140 291 minecraft:brown_terracotta
setblock 559 140 292 minecraft:white_concrete
fill 559 140 293 559 147 293 minecraft:brown_terracotta
setblock 559 140 294 minecraft:white_concrete
setblock 559 140 296 minecraft:white_concrete
fill 559 140 297 559 147 297 minecraft:brown_terracotta
setblock 559 140 298 minecraft:white_concrete
setblock 559 140 300 minecraft:white_concrete
fill 559 140 301 559 147 301 minecraft:brown_terracotta
setblock 559 140 302 minecraft:white_concrete
setblock 559 140 303 minecraft:brown_terracotta
setblock 559 140 304 minecraft:white_concrete
fill 559 140 305 559 147 305 minecraft:brown_terracotta
setblock 559 140 306 minecraft:white_concrete
setblock 559 140 308 minecraft:white_concrete
fill 559 140 309 559 147 309 minecraft:brown_terracotta
setblock 559 140 310 minecraft:white_concrete
setblock 559 140 312 minecraft:white_concrete
fill 559 140 313 559 147 313 minecraft:brown_terracotta
setblock 559 140 314 minecraft:white_concrete
setblock 559 140 315 minecraft:brown_terracotta
setblock 559 140 316 minecraft:white_concrete
fill 559 140 317 559 147 317 minecraft:brown_terracotta
setblock 517 141 275 minecraft:white_concrete
fill 517 141 276 517 148 276 minecraft:brown_terracotta
fill 517 141 278 517 148 278 minecraft:brown_terracotta
setblock 517 141 279 minecraft:white_concrete
fill 517 141 280 517 148 280 minecraft:brown_terracotta
fill 517 141 282 517 148 282 minecraft:brown_terracotta
setblock 517 141 283 minecraft:white_concrete
fill 517 141 284 517 148 284 minecraft:brown_terracotta
fill 517 141 286 517 148 286 minecraft:brown_terracotta
setblock 517 141 287 minecraft:white_concrete
fill 517 141 288 517 148 288 minecraft:brown_terracotta
fill 517 141 290 517 148 290 minecraft:brown_terracotta
setblock 517 141 291 minecraft:white_concrete
fill 517 141 292 517 148 292 minecraft:brown_terracotta
fill 517 141 294 517 148 294 minecraft:brown_terracotta
setblock 517 141 295 minecraft:white_concrete
fill 517 141 296 517 148 296 minecraft:brown_terracotta
fill 517 141 298 517 148 298 minecraft:brown_terracotta
setblock 517 141 299 minecraft:white_concrete
fill 517 141 300 517 148 300 minecraft:brown_terracotta
fill 517 141 302 517 148 302 minecraft:brown_terracotta
setblock 517 141 303 minecraft:white_concrete
fill 517 141 304 517 148 304 minecraft:brown_terracotta
fill 517 141 306 517 148 306 minecraft:brown_terracotta
setblock 517 141 307 minecraft:white_concrete
fill 517 141 308 517 148 308 minecraft:brown_terracotta
fill 517 141 310 517 148 310 minecraft:brown_terracotta
setblock 517 141 311 minecraft:white_concrete
fill 517 141 312 517 148 312 minecraft:brown_terracotta
fill 517 141 314 517 148 314 minecraft:brown_terracotta
setblock 517 141 315 minecraft:white_concrete
fill 517 141 316 517 148 316 minecraft:brown_terracotta
setblock 517 141 317 minecraft:white_concrete
fill 518 141 275 518 148 275 minecraft:brown_terracotta
fill 518 141 317 518 148 317 minecraft:brown_terracotta
fill 520 141 275 520 148 275 minecraft:brown_terracotta
setblock 520 141 278 minecraft:light[level=15]
setblock 520 141 286 minecraft:light[level=15]
setblock 520 141 294 minecraft:light[level=15]
setblock 520 141 302 minecraft:light[level=15]
setblock 520 141 310 minecraft:light[level=15]
fill 520 141 317 520 148 317 minecraft:brown_terracotta
setblock 521 141 275 minecraft:white_concrete
setblock 521 141 317 minecraft:white_concrete
fill 522 141 275 522 148 275 minecraft:brown_terracotta
fill 522 141 317 522 148 317 minecraft:brown_terracotta
fill 524 141 275 524 148 275 minecraft:brown_terracotta
fill 524 141 317 524 148 317 minecraft:brown_terracotta
setblock 525 141 275 minecraft:white_concrete
setblock 525 141 317 minecraft:white_concrete
fill 526 141 275 526 148 275 minecraft:brown_terracotta
fill 526 141 317 526 148 317 minecraft:brown_terracotta
fill 528 141 275 528 148 275 minecraft:brown_terracotta
setblock 528 141 278 minecraft:light[level=15]
setblock 528 141 286 minecraft:light[level=15]
setblock 528 141 294 minecraft:light[level=15]
setblock 528 141 302 minecraft:light[level=15]
setblock 528 141 310 minecraft:light[level=15]
fill 528 141 317 528 148 317 minecraft:brown_terracotta
setblock 529 141 275 minecraft:white_concrete
setblock 529 141 317 minecraft:white_concrete
fill 530 141 275 530 148 275 minecraft:brown_terracotta
fill 530 141 317 530 148 317 minecraft:brown_terracotta
fill 532 141 275 532 148 275 minecraft:brown_terracotta
fill 532 141 317 532 148 317 minecraft:brown_terracotta
setblock 533 141 275 minecraft:white_concrete
setblock 533 141 317 minecraft:white_concrete
fill 534 141 275 534 148 275 minecraft:brown_terracotta
fill 534 141 317 534 148 317 minecraft:brown_terracotta
fill 536 141 275 536 148 275 minecraft:brown_terracotta
setblock 536 141 278 minecraft:light[level=15]
setblock 536 141 286 minecraft:light[level=15]
setblock 536 141 294 minecraft:light[level=15]
setblock 536 141 302 minecraft:light[level=15]
setblock 536 141 310 minecraft:light[level=15]
fill 536 141 317 536 148 317 minecraft:brown_terracotta
setblock 537 141 275 minecraft:white_concrete
setblock 537 141 317 minecraft:white_concrete
fill 538 141 275 538 148 275 minecraft:brown_terracotta
fill 538 141 317 538 148 317 minecraft:brown_terracotta
fill 540 141 275 540 148 275 minecraft:brown_terracotta
fill 540 141 317 540 148 317 minecraft:brown_terracotta
setblock 541 141 275 minecraft:white_concrete
setblock 541 141 317 minecraft:white_concrete
fill 542 141 275 542 148 275 minecraft:brown_terracotta
fill 542 141 317 542 148 317 minecraft:brown_terracotta
fill 544 141 275 544 148 275 minecraft:brown_terracotta
setblock 544 141 278 minecraft:light[level=15]
setblock 544 141 286 minecraft:light[level=15]
setblock 544 141 294 minecraft:light[level=15]
setblock 544 141 302 minecraft:light[level=15]
setblock 544 141 310 minecraft:light[level=15]
fill 544 141 317 544 148 317 minecraft:brown_terracotta
setblock 545 141 275 minecraft:white_concrete
setblock 545 141 317 minecraft:white_concrete
fill 546 141 275 546 148 275 minecraft:brown_terracotta
fill 546 141 317 546 148 317 minecraft:brown_terracotta
fill 548 141 275 548 148 275 minecraft:brown_terracotta
fill 548 141 317 548 148 317 minecraft:brown_terracotta
setblock 549 141 275 minecraft:white_concrete
setblock 549 141 317 minecraft:white_concrete
fill 550 141 275 550 148 275 minecraft:brown_terracotta
fill 550 141 317 550 148 317 minecraft:brown_terracotta
fill 552 141 275 552 148 275 minecraft:brown_terracotta
setblock 552 141 278 minecraft:light[level=15]
setblock 552 141 286 minecraft:light[level=15]
setblock 552 141 294 minecraft:light[level=15]
setblock 552 141 302 minecraft:light[level=15]
setblock 552 141 310 minecraft:light[level=15]
fill 552 141 317 552 148 317 minecraft:brown_terracotta
setblock 553 141 275 minecraft:white_concrete
setblock 553 141 317 minecraft:white_concrete
fill 554 141 275 554 148 275 minecraft:brown_terracotta
fill 554 141 317 554 148 317 minecraft:brown_terracotta
fill 556 141 275 556 148 275 minecraft:brown_terracotta
fill 556 141 317 556 148 317 minecraft:brown_terracotta
setblock 557 141 275 minecraft:white_concrete
setblock 557 141 317 minecraft:white_concrete
fill 558 141 275 558 148 275 minecraft:brown_terracotta
fill 558 141 317 558 148 317 minecraft:brown_terracotta
setblock 559 141 275 minecraft:white_concrete
fill 559 141 276 559 148 276 minecraft:brown_terracotta
fill 559 141 278 559 148 278 minecraft:brown_terracotta
setblock 559 141 279 minecraft:white_concrete
fill 559 141 280 559 148 280 minecraft:brown_terracotta
fill 559 141 282 559 148 282 minecraft:brown_terracotta
setblock 559 141 283 minecraft:white_concrete
fill 559 141 284 559 148 284 minecraft:brown_terracotta
fill 559 141 286 559 148 286 minecraft:brown_terracotta
setblock 559 141 287 minecraft:white_concrete
fill 559 141 288 559 148 288 minecraft:brown_terracotta
fill 559 141 290 559 148 290 minecraft:brown_terracotta
setblock 559 141 291 minecraft:white_concrete
fill 559 141 292 559 148 292 minecraft:brown_terracotta
fill 559 141 294 559 148 294 minecraft:brown_terracotta
setblock 559 141 295 minecraft:white_concrete
fill 559 141 296 559 148 296 minecraft:brown_terracotta
fill 559 141 298 559 148 298 minecraft:brown_terracotta
setblock 559 141 299 minecraft:white_concrete
fill 559 141 300 559 148 300 minecraft:brown_terracotta
fill 559 141 302 559 148 302 minecraft:brown_terracotta
setblock 559 141 303 minecraft:white_concrete
fill 559 141 304 559 148 304 minecraft:brown_terracotta
fill 559 141 306 559 148 306 minecraft:brown_terracotta
setblock 559 141 307 minecraft:white_concrete
fill 559 141 308 559 148 308 minecraft:brown_terracotta
fill 559 141 310 559 148 310 minecraft:brown_terracotta
setblock 559 141 311 minecraft:white_concrete
fill 559 141 312 559 148 312 minecraft:brown_terracotta
fill 559 141 314 559 148 314 minecraft:brown_terracotta
setblock 559 141 315 minecraft:white_concrete
fill 559 141 316 559 148 316 minecraft:brown_terracotta
fill 517 142 275 517 149 275 minecraft:brown_terracotta
fill 517 142 279 517 149 279 minecraft:brown_terracotta
fill 517 142 283 517 149 283 minecraft:brown_terracotta
fill 517 142 287 517 149 287 minecraft:brown_terracotta
fill 517 142 291 517 149 291 minecraft:brown_terracotta
fill 517 142 295 517 149 295 minecraft:brown_terracotta
fill 517 142 299 517 149 299 minecraft:brown_terracotta
fill 517 142 303 517 149 303 minecraft:brown_terracotta
fill 517 142 307 517 149 307 minecraft:brown_terracotta
fill 517 142 311 517 149 311 minecraft:brown_terracotta
fill 517 142 315 517 149 315 minecraft:brown_terracotta
fill 517 142 317 517 147 317 minecraft:brown_terracotta
fill 521 142 275 521 149 275 minecraft:brown_terracotta
fill 521 142 317 521 149 317 minecraft:brown_terracotta
fill 525 142 275 525 149 275 minecraft:brown_terracotta
fill 525 142 317 525 149 317 minecraft:brown_terracotta
fill 529 142 275 529 149 275 minecraft:brown_terracotta
fill 529 142 317 529 149 317 minecraft:brown_terracotta
fill 533 142 275 533 149 275 minecraft:brown_terracotta
fill 533 142 317 533 149 317 minecraft:brown_terracotta
fill 537 142 275 537 149 275 minecraft:brown_terracotta
fill 537 142 317 537 149 317 minecraft:brown_terracotta
fill 541 142 275 541 149 275 minecraft:brown_terracotta
fill 541 142 317 541 149 317 minecraft:brown_terracotta
fill 545 142 275 545 149 275 minecraft:brown_terracotta
fill 545 142 317 545 149 317 minecraft:brown_terracotta
fill 549 142 275 549 149 275 minecraft:brown_terracotta
fill 549 142 317 549 149 317 minecraft:brown_terracotta
fill 553 142 275 553 149 275 minecraft:brown_terracotta
fill 553 142 317 553 149 317 minecraft:brown_terracotta
fill 557 142 275 557 149 275 minecraft:brown_terracotta
fill 557 142 317 557 149 317 minecraft:brown_terracotta
fill 559 142 275 559 147 275 minecraft:brown_terracotta
fill 559 142 279 559 149 279 minecraft:brown_terracotta
fill 559 142 283 559 149 283 minecraft:brown_terracotta
fill 559 142 287 559 149 287 minecraft:brown_terracotta
fill 559 142 291 559 149 291 minecraft:brown_terracotta
fill 559 142 295 559 149 295 minecraft:brown_terracotta
fill 559 142 299 559 149 299 minecraft:brown_terracotta
fill 559 142 303 559 149 303 minecraft:brown_terracotta
fill 559 142 307 559 149 307 minecraft:brown_terracotta
fill 559 142 311 559 149 311 minecraft:brown_terracotta
fill 559 142 315 559 149 315 minecraft:brown_terracotta
fill 518 145 276 527 146 276 minecraft:light_blue_stained_glass
fill 518 145 277 518 146 278 minecraft:white_stained_glass
fill 518 145 279 518 146 287 minecraft:light_blue_stained_glass
fill 518 145 288 518 146 288 minecraft:white_stained_glass
fill 518 145 289 518 146 297 minecraft:light_blue_stained_glass
fill 518 145 298 518 146 299 minecraft:white_stained_glass
fill 518 145 300 518 146 308 minecraft:light_blue_stained_glass
fill 518 145 309 518 146 309 minecraft:white_stained_glass
fill 518 145 310 518 146 316 minecraft:light_blue_stained_glass
fill 519 145 277 522 146 278 minecraft:light_blue_stained_glass
fill 519 145 279 519 146 280 minecraft:white_stained_glass
fill 519 145 281 519 146 289 minecraft:light_blue_stained_glass
fill 519 145 290 519 146 290 minecraft:white_stained_glass
fill 519 145 291 519 146 299 minecraft:light_blue_stained_glass
fill 519 145 300 519 146 301 minecraft:white_stained_glass
fill 519 145 302 519 146 310 minecraft:light_blue_stained_glass
fill 519 145 311 519 146 311 minecraft:white_stained_glass
fill 519 145 312 519 146 316 minecraft:light_blue_stained_glass
fill 520 145 279 523 146 280 minecraft:light_blue_stained_glass
fill 520 145 281 520 146 282 minecraft:white_stained_glass
fill 520 145 283 520 146 291 minecraft:light_blue_stained_glass
fill 520 145 292 520 146 292 minecraft:white_stained_glass
fill 520 145 293 520 146 301 minecraft:light_blue_stained_glass
fill 520 145 302 520 146 303 minecraft:white_stained_glass
fill 520 145 304 520 146 312 minecraft:light_blue_stained_glass
fill 520 145 313 520 146 313 minecraft:white_stained_glass
fill 520 145 314 520 146 316 minecraft:light_blue_stained_glass
fill 521 145 281 524 146 282 minecraft:light_blue_stained_glass
fill 521 145 283 521 146 284 minecraft:white_stained_glass
fill 521 145 285 521 146 293 minecraft:light_blue_stained_glass
fill 521 145 294 521 146 294 minecraft:white_stained_glass
fill 521 145 295 521 146 303 minecraft:light_blue_stained_glass
fill 521 145 304 521 146 305 minecraft:white_stained_glass
fill 521 145 306 521 146 314 minecraft:light_blue_stained_glass
fill 521 145 315 521 146 315 minecraft:white_stained_glass
fill 521 145 316 526 146 316 minecraft:light_blue_stained_glass
fill 522 145 283 525 146 284 minecraft:light_blue_stained_glass
fill 522 145 285 522 146 286 minecraft:white_stained_glass
fill 522 145 287 522 146 295 minecraft:light_blue_stained_glass
fill 522 145 296 522 146 296 minecraft:white_stained_glass
fill 522 145 297 522 146 305 minecraft:light_blue_stained_glass
fill 522 145 306 522 146 307 minecraft:white_stained_glass
fill 522 145 308 522 146 315 minecraft:light_blue_stained_glass
fill 523 145 277 523 146 277 minecraft:white_stained_glass
fill 523 145 278 528 146 278 minecraft:light_blue_stained_glass
fill 523 145 285 526 146 286 minecraft:light_blue_stained_glass
fill 523 145 287 523 146 288 minecraft:white_stained_glass
fill 523 145 289 523 146 297 minecraft:light_blue_stained_glass
fill 523 145 298 523 146 298 minecraft:white_stained_glass
fill 523 145 299 523 146 307 minecraft:light_blue_stained_glass
fill 523 145 308 523 146 309 minecraft:white_stained_glass
fill 523 145 310 523 146 315 minecraft:light_blue_stained_glass
fill 524 145 277 527 146 277 minecraft:light_blue_stained_glass
fill 524 145 279 524 146 279 minecraft:white_stained_glass
fill 524 145 280 529 146 280 minecraft:light_blue_stained_glass
fill 524 145 287 527 146 288 minecraft:light_blue_stained_glass
fill 524 145 289 524 146 290 minecraft:white_stained_glass
fill 524 145 291 524 146 299 minecraft:light_blue_stained_glass
fill 524 145 300 524 146 300 minecraft:white_stained_glass
fill 524 145 301 524 146 309 minecraft:light_blue_stained_glass
fill 524 145 310 524 146 311 minecraft:white_stained_glass
fill 524 145 312 524 146 315 minecraft:light_blue_stained_glass
fill 525 145 279 528 146 279 minecraft:light_blue_stained_glass
fill 525 145 281 525 146 281 minecraft:white_stained_glass
fill 525 145 282 530 146 282 minecraft:light_blue_stained_glass
fill 525 145 289 528 146 290 minecraft:light_blue_stained_glass
fill 525 145 291 525 146 292 minecraft:white_stained_glass
fill 525 145 293 525 146 301 minecraft:light_blue_stained_glass
fill 525 145 302 525 146 302 minecraft:white_stained_glass
fill 525 145 303 525 146 311 minecraft:light_blue_stained_glass
fill 525 145 312 525 146 313 minecraft:white_stained_glass
fill 525 145 314 525 146 315 minecraft:light_blue_stained_glass
fill 526 145 281 529 146 281 minecraft:light_blue_stained_glass
fill 526 145 283 526 146 283 minecraft:white_stained_glass
fill 526 145 284 531 146 284 minecraft:light_blue_stained_glass
fill 526 145 291 529 146 292 minecraft:light_blue_stained_glass
fill 526 145 293 526 146 294 minecraft:white_stained_glass
fill 526 145 295 526 146 303 minecraft:light_blue_stained_glass
fill 526 145 304 526 146 304 minecraft:white_stained_glass
fill 526 145 305 526 146 313 minecraft:light_blue_stained_glass
fill 526 145 314 526 146 315 minecraft:white_stained_glass
fill 527 145 283 530 146 283 minecraft:light_blue_stained_glass
fill 527 145 285 527 146 285 minecraft:white_stained_glass
fill 527 145 286 532 146 286 minecraft:light_blue_stained_glass
fill 527 145 293 530 146 294 minecraft:light_blue_stained_glass
fill 527 145 295 527 146 296 minecraft:white_stained_glass
fill 527 145 297 527 146 305 minecraft:light_blue_stained_glass
fill 527 145 306 527 146 306 minecraft:white_stained_glass
fill 527 145 307 527 146 315 minecraft:light_blue_stained_glass
fill 527 145 316 527 146 316 minecraft:white_stained_glass
fill 528 145 276 528 146 277 minecraft:white_stained_glass
fill 528 145 285 531 146 285 minecraft:light_blue_stained_glass
fill 528 145 287 528 146 287 minecraft:white_stained_glass
fill 528 145 288 533 146 288 minecraft:light_blue_stained_glass
fill 528 145 295 531 146 296 minecraft:light_blue_stained_glass
fill 528 145 297 528 146 298 minecraft:white_stained_glass
fill 528 145 299 528 146 307 minecraft:light_blue_stained_glass
fill 528 145 308 528 146 308 minecraft:white_stained_glass
fill 528 145 309 528 146 316 minecraft:light_blue_stained_glass
fill 529 145 276 532 146 277 minecraft:light_blue_stained_glass
fill 529 145 278 529 146 279 minecraft:white_stained_glass
fill 529 145 287 532 146 287 minecraft:light_blue_stained_glass
fill 529 145 289 529 146 289 minecraft:white_stained_glass
fill 529 145 290 534 146 290 minecraft:light_blue_stained_glass
fill 529 145 297 532 145 298 minecraft:light_blue_stained_glass
fill 529 145 299 529 146 300 minecraft:white_stained_glass
fill 529 145 301 529 146 309 minecraft:light_blue_stained_glass
fill 529 145 310 529 146 310 minecraft:white_stained_glass
fill 529 145 311 529 146 316 minecraft:light_blue_stained_glass
fill 530 145 278 533 146 279 minecraft:light_blue_stained_glass
fill 530 145 280 530 146 281 minecraft:white_stained_glass
fill 530 145 289 533 146 289 minecraft:light_blue_stained_glass
fill 530 145 291 530 146 291 minecraft:white_stained_glass
fill 530 145 292 535 146 292 minecraft:light_blue_stained_glass
fill 530 145 299 532 145 300 minecraft:light_blue_stained_glass
fill 530 145 301 530 146 302 minecraft:white_stained_glass
fill 530 145 303 530 146 311 minecraft:light_blue_stained_glass
fill 530 145 312 530 146 312 minecraft:white_stained_glass
fill 530 145 313 530 146 316 minecraft:light_blue_stained_glass
fill 531 145 280 534 146 281 minecraft:light_blue_stained_glass
fill 531 145 282 531 146 283 minecraft:white_stained_glass
fill 531 145 291 534 146 291 minecraft:light_blue_stained_glass
fill 531 145 293 531 146 293 minecraft:white_stained_glass
fill 531 145 294 536 146 294 minecraft:light_blue_stained_glass
fill 531 145 301 534 145 302 minecraft:light_blue_stained_glass
fill 531 145 303 531 146 304 minecraft:white_stained_glass
fill 531 145 305 531 146 313 minecraft:light_blue_stained_glass
fill 531 145 314 531 146 314 minecraft:white_stained_glass
fill 531 145 315 531 146 316 minecraft:light_blue_stained_glass
fill 532 145 282 535 146 283 minecraft:light_blue_stained_glass
fill 532 145 284 532 146 285 minecraft:white_stained_glass
fill 532 145 293 535 146 293 minecraft:light_blue_stained_glass
fill 532 145 295 532 146 295 minecraft:white_stained_glass
fill 532 145 296 533 145 296 minecraft:light_blue_stained_glass
fill 532 145 303 535 146 304 minecraft:light_blue_stained_glass
fill 532 145 305 532 146 306 minecraft:white_stained_glass
fill 532 145 307 532 146 315 minecraft:light_blue_stained_glass
fill 532 145 316 532 146 316 minecraft:white_stained_glass
fill 533 145 276 533 146 276 minecraft:white_stained_glass
fill 533 145 277 538 146 277 minecraft:light_blue_stained_glass
fill 533 145 284 536 146 285 minecraft:light_blue_stained_glass
fill 533 145 286 533 146 287 minecraft:white_stained_glass
fill 533 145 295 536 145 295 minecraft:light_blue_stained_glass
setblock 533 145 300 minecraft:light_blue_stained_glass
fill 533 145 305 536 146 306 minecraft:light_blue_stained_glass
fill 533 145 307 533 146 308 minecraft:white_stained_glass
fill 533 145 309 533 146 316 minecraft:light_blue_stained_glass
fill 534 145 276 537 146 276 minecraft:light_blue_stained_glass
fill 534 145 278 534 146 278 minecraft:white_stained_glass
fill 534 145 279 539 146 279 minecraft:light_blue_stained_glass
fill 534 145 286 537 146 287 minecraft:light_blue_stained_glass
fill 534 145 288 534 146 289 minecraft:white_stained_glass
fill 534 145 307 537 146 308 minecraft:light_blue_stained_glass
fill 534 145 309 534 146 310 minecraft:white_stained_glass
fill 534 145 311 534 146 316 minecraft:light_blue_stained_glass
fill 535 145 278 538 146 278 minecraft:light_blue_stained_glass
fill 535 145 280 535 146 280 minecraft:white_stained_glass
fill 535 145 281 540 146 281 minecraft:light_blue_stained_glass
fill 535 145 288 538 146 289 minecraft:light_blue_stained_glass
fill 535 145 290 535 146 291 minecraft:white_stained_glass
setblock 535 145 301 minecraft:white_stained_glass
fill 535 145 302 540 146 302 minecraft:light_blue_stained_glass
fill 535 145 309 538 146 310 minecraft:light_blue_stained_glass
fill 535 145 311 535 146 312 minecraft:white_stained_glass
fill 535 145 313 535 146 316 minecraft:light_blue_stained_glass
fill 536 145 280 539 146 280 minecraft:light_blue_stained_glass
fill 536 145 282 536 146 282 minecraft:white_stained_glass
fill 536 145 283 541 146 283 minecraft:light_blue_stained_glass
fill 536 145 290 539 146 291 minecraft:light_blue_stained_glass
fill 536 145 292 536 146 293 minecraft:white_stained_glass
fill 536 145 301 539 145 301 minecraft:light_blue_stained_glass
fill 536 145 303 536 146 303 minecraft:white_stained_glass
fill 536 145 304 541 146 304 minecraft:light_blue_stained_glass
fill 536 145 311 539 146 312 minecraft:light_blue_stained_glass
fill 536 145 313 536 146 314 minecraft:white_stained_glass
fill 536 145 315 536 146 316 minecraft:light_blue_stained_glass
fill 537 145 282 540 146 282 minecraft:light_blue_stained_glass
fill 537 145 284 537 146 284 minecraft:white_stained_glass
fill 537 145 285 542 146 285 minecraft:light_blue_stained_glass
fill 537 145 292 540 146 293 minecraft:light_blue_stained_glass
fill 537 145 294 537 145 295 minecraft:white_stained_glass
setblock 537 145 296 minecraft:light_blue_stained_glass
fill 537 145 300 539 145 300 minecraft:light_blue_stained_glass
fill 537 145 303 540 146 303 minecraft:light_blue_stained_glass
fill 537 145 305 537 146 305 minecraft:white_stained_glass
fill 537 145 306 542 146 306 minecraft:light_blue_stained_glass
fill 537 145 313 540 146 314 minecraft:light_blue_stained_glass
fill 537 145 315 537 146 316 minecraft:white_stained_glass
fill 538 145 276 538 146 276 minecraft:white_stained_glass
fill 538 145 284 541 146 284 minecraft:light_blue_stained_glass
fill 538 145 286 538 146 286 minecraft:white_stained_glass
fill 538 145 287 543 146 287 minecraft:light_blue_stained_glass
fill 538 145 294 541 146 295 minecraft:light_blue_stained_glass
fill 538 145 296 538 145 297 minecraft:white_stained_glass
fill 538 145 298 538 145 299 minecraft:light_blue_stained_glass
fill 538 145 305 541 146 305 minecraft:light_blue_stained_glass
fill 538 145 307 538 146 307 minecraft:white_stained_glass
fill 538 145 308 543 146 308 minecraft:light_blue_stained_glass
fill 538 145 315 541 146 316 minecraft:light_blue_stained_glass
fill 539 145 276 548 146 276 minecraft:light_blue_stained_glass
fill 539 145 277 539 146 278 minecraft:white_stained_glass
fill 539 145 286 542 146 286 minecraft:light_blue_stained_glass
fill 539 145 288 539 146 288 minecraft:white_stained_glass
fill 539 145 289 544 146 289 minecraft:light_blue_stained_glass
fill 539 145 296 542 146 297 minecraft:light_blue_stained_glass
fill 539 145 298 539 146 299 minecraft:white_stained_glass
fill 539 145 307 542 146 307 minecraft:light_blue_stained_glass
fill 539 145 309 539 146 309 minecraft:white_stained_glass
fill 539 145 310 544 146 310 minecraft:light_blue_stained_glass
fill 540 145 277 543 146 278 minecraft:light_blue_stained_glass
fill 540 145 279 540 146 280 minecraft:white_stained_glass
fill 540 145 288 543 146 288 minecraft:light_blue_stained_glass
fill 540 145 290 540 146 290 minecraft:white_stained_glass
fill 540 145 291 545 146 291 minecraft:light_blue_stained_glass
fill 540 145 298 543 146 299 minecraft:light_blue_stained_glass
fill 540 145 300 540 146 301 minecraft:white_stained_glass
fill 540 145 309 543 146 309 minecraft:light_blue_stained_glass
fill 540 145 311 540 146 311 minecraft:white_stained_glass
fill 540 145 312 545 146 312 minecraft:light_blue_stained_glass
fill 541 145 279 544 146 280 minecraft:light_blue_stained_glass
fill 541 145 281 541 146 282 minecraft:white_stained_glass
fill 541 145 290 544 146 290 minecraft:light_blue_stained_glass
fill 541 145 292 541 146 292 minecraft:white_stained_glass
fill 541 145 293 546 146 293 minecraft:light_blue_stained_glass
fill 541 145 300 544 146 301 minecraft:light_blue_stained_glass
fill 541 145 302 541 146 303 minecraft:white_stained_glass
fill 541 145 311 544 146 311 minecraft:light_blue_stained_glass
fill 541 145 313 541 146 313 minecraft:white_stained_glass
fill 541 145 314 546 146 314 minecraft:light_blue_stained_glass
fill 542 145 281 545 146 282 minecraft:light_blue_stained_glass
fill 542 145 283 542 146 284 minecraft:white_stained_glass
fill 542 145 292 545 146 292 minecraft:light_blue_stained_glass
fill 542 145 294 542 146 294 minecraft:white_stained_glass
fill 542 145 295 547 146 295 minecraft:light_blue_stained_glass
fill 542 145 302 545 146 303 minecraft:light_blue_stained_glass
fill 542 145 304 542 146 305 minecraft:white_stained_glass
fill 542 145 313 545 146 313 minecraft:light_blue_stained_glass
fill 542 145 315 542 146 315 minecraft:white_stained_glass
fill 542 145 316 547 146 316 minecraft:light_blue_stained_glass
fill 543 145 283 546 146 284 minecraft:light_blue_stained_glass
fill 543 145 285 543 146 286 minecraft:white_stained_glass
fill 543 145 294 546 146 294 minecraft:light_blue_stained_glass
fill 543 145 296 543 146 296 minecraft:white_stained_glass
fill 543 145 297 548 146 297 minecraft:light_blue_stained_glass
fill 543 145 304 546 146 305 minecraft:light_blue_stained_glass
fill 543 145 306 543 146 307 minecraft:white_stained_glass
fill 543 145 315 546 146 315 minecraft:light_blue_stained_glass
fill 544 145 277 544 146 277 minecraft:white_stained_glass
fill 544 145 278 549 146 278 minecraft:light_blue_stained_glass
fill 544 145 285 547 146 286 minecraft:light_blue_stained_glass
fill 544 145 287 544 146 288 minecraft:white_stained_glass
fill 544 145 296 547 146 296 minecraft:light_blue_stained_glass
fill 544 145 298 544 146 298 minecraft:white_stained_glass
fill 544 145 299 549 146 299 minecraft:light_blue_stained_glass
fill 544 145 306 547 146 307 minecraft:light_blue_stained_glass
fill 544 145 308 544 146 309 minecraft:white_stained_glass
fill 545 145 277 548 146 277 minecraft:light_blue_stained_glass
fill 545 145 279 545 146 279 minecraft:white_stained_glass
fill 545 145 280 550 146 280 minecraft:light_blue_stained_glass
fill 545 145 287 548 146 288 minecraft:light_blue_stained_glass
fill 545 145 289 545 146 290 minecraft:white_stained_glass
fill 545 145 298 548 146 298 minecraft:light_blue_stained_glass
fill 545 145 300 545 146 300 minecraft:white_stained_glass
fill 545 145 301 550 146 301 minecraft:light_blue_stained_glass
fill 545 145 308 548 146 309 minecraft:light_blue_stained_glass
fill 545 145 310 545 146 311 minecraft:white_stained_glass
fill 546 145 279 549 146 279 minecraft:light_blue_stained_glass
fill 546 145 281 546 146 281 minecraft:white_stained_glass
fill 546 145 282 551 146 282 minecraft:light_blue_stained_glass
fill 546 145 289 549 146 290 minecraft:light_blue_stained_glass
fill 546 145 291 546 146 292 minecraft:white_stained_glass
fill 546 145 300 549 146 300 minecraft:light_blue_stained_glass
fill 546 145 302 546 146 302 minecraft:white_stained_glass
fill 546 145 303 551 146 303 minecraft:light_blue_stained_glass
fill 546 145 310 549 146 311 minecraft:light_blue_stained_glass
fill 546 145 312 546 146 313 minecraft:white_stained_glass
fill 547 145 281 550 146 281 minecraft:light_blue_stained_glass
fill 547 145 283 547 146 283 minecraft:white_stained_glass
fill 547 145 284 552 146 284 minecraft:light_blue_stained_glass
fill 547 145 291 550 146 292 minecraft:light_blue_stained_glass
fill 547 145 293 547 146 294 minecraft:white_stained_glass
fill 547 145 302 550 146 302 minecraft:light_blue_stained_glass
fill 547 145 304 547 146 304 minecraft:white_stained_glass
fill 547 145 305 552 146 305 minecraft:light_blue_stained_glass
fill 547 145 312 550 146 313 minecraft:light_blue_stained_glass
fill 547 145 314 547 146 315 minecraft:white_stained_glass
fill 548 145 283 551 146 283 minecraft:light_blue_stained_glass
fill 548 145 285 548 146 285 minecraft:white_stained_glass
fill 548 145 286 553 146 286 minecraft:light_blue_stained_glass
fill 548 145 293 551 146 294 minecraft:light_blue_stained_glass
fill 548 145 295 548 146 296 minecraft:white_stained_glass
fill 548 145 304 551 146 304 minecraft:light_blue_stained_glass
fill 548 145 306 548 146 306 minecraft:white_stained_glass
fill 548 145 307 553 146 307 minecraft:light_blue_stained_glass
fill 548 145 314 551 146 315 minecraft:light_blue_stained_glass
fill 548 145 316 548 146 316 minecraft:white_stained_glass
fill 549 145 276 549 146 277 minecraft:white_stained_glass
fill 549 145 285 552 146 285 minecraft:light_blue_stained_glass
fill 549 145 287 549 146 287 minecraft:white_stained_glass
fill 549 145 288 554 146 288 minecraft:light_blue_stained_glass
fill 549 145 295 552 146 296 minecraft:light_blue_stained_glass
fill 549 145 297 549 146 298 minecraft:white_stained_glass
fill 549 145 306 552 146 306 minecraft:light_blue_stained_glass
fill 549 145 308 549 146 308 minecraft:white_stained_glass
fill 549 145 309 554 146 309 minecraft:light_blue_stained_glass
fill 549 145 316 552 146 316 minecraft:light_blue_stained_glass
fill 550 145 276 553 146 277 minecraft:light_blue_stained_glass
fill 550 145 278 550 146 279 minecraft:white_stained_glass
fill 550 145 287 553 146 287 minecraft:light_blue_stained_glass
fill 550 145 289 550 146 289 minecraft:white_stained_glass
fill 550 145 290 555 146 290 minecraft:light_blue_stained_glass
fill 550 145 297 553 146 298 minecraft:light_blue_stained_glass
fill 550 145 299 550 146 300 minecraft:white_stained_glass
fill 550 145 308 553 146 308 minecraft:light_blue_stained_glass
fill 550 145 310 550 146 310 minecraft:white_stained_glass
fill 550 145 311 555 146 311 minecraft:light_blue_stained_glass
fill 551 145 278 554 146 279 minecraft:light_blue_stained_glass
fill 551 145 280 551 146 281 minecraft:white_stained_glass
fill 551 145 289 554 146 289 minecraft:light_blue_stained_glass
fill 551 145 291 551 146 291 minecraft:white_stained_glass
fill 551 145 292 556 146 292 minecraft:light_blue_stained_glass
fill 551 145 299 554 146 300 minecraft:light_blue_stained_glass
fill 551 145 301 551 146 302 minecraft:white_stained_glass
fill 551 145 310 554 146 310 minecraft:light_blue_stained_glass
fill 551 145 312 551 146 312 minecraft:white_stained_glass
fill 551 145 313 556 146 313 minecraft:light_blue_stained_glass
fill 552 145 280 555 146 281 minecraft:light_blue_stained_glass
fill 552 145 282 552 146 283 minecraft:white_stained_glass
fill 552 145 291 555 146 291 minecraft:light_blue_stained_glass
fill 552 145 293 552 146 293 minecraft:white_stained_glass
fill 552 145 294 557 146 294 minecraft:light_blue_stained_glass
fill 552 145 301 555 146 302 minecraft:light_blue_stained_glass
fill 552 145 303 552 146 304 minecraft:white_stained_glass
fill 552 145 312 555 146 312 minecraft:light_blue_stained_glass
fill 552 145 314 552 146 314 minecraft:white_stained_glass
fill 552 145 315 557 146 315 minecraft:light_blue_stained_glass
fill 553 145 282 556 146 283 minecraft:light_blue_stained_glass
fill 553 145 284 553 146 285 minecraft:white_stained_glass
fill 553 145 293 556 146 293 minecraft:light_blue_stained_glass
fill 553 145 295 553 146 295 minecraft:white_stained_glass
fill 553 145 296 558 146 296 minecraft:light_blue_stained_glass
fill 553 145 303 556 146 304 minecraft:light_blue_stained_glass
fill 553 145 305 553 146 306 minecraft:white_stained_glass
fill 553 145 314 556 146 314 minecraft:light_blue_stained_glass
fill 553 145 316 553 146 316 minecraft:white_stained_glass
fill 554 145 276 554 146 276 minecraft:white_stained_glass
fill 554 145 277 558 146 277 minecraft:light_blue_stained_glass
fill 554 145 284 557 146 285 minecraft:light_blue_stained_glass
fill 554 145 286 554 146 287 minecraft:white_stained_glass
fill 554 145 295 557 146 295 minecraft:light_blue_stained_glass
fill 554 145 297 554 146 297 minecraft:white_stained_glass
fill 554 145 298 558 146 298 minecraft:light_blue_stained_glass
fill 554 145 305 557 146 306 minecraft:light_blue_stained_glass
fill 554 145 307 554 146 308 minecraft:white_stained_glass
fill 554 145 316 557 146 316 minecraft:light_blue_stained_glass
fill 555 145 276 558 146 276 minecraft:light_blue_stained_glass
fill 555 145 278 555 146 278 minecraft:white_stained_glass
fill 555 145 279 558 146 279 minecraft:light_blue_stained_glass
fill 555 145 286 558 146 287 minecraft:light_blue_stained_glass
fill 555 145 288 555 146 289 minecraft:white_stained_glass
fill 555 145 297 558 146 297 minecraft:light_blue_stained_glass
fill 555 145 299 555 146 299 minecraft:white_stained_glass
fill 555 145 300 558 146 300 minecraft:light_blue_stained_glass
fill 555 145 307 558 146 308 minecraft:light_blue_stained_glass
fill 555 145 309 555 146 310 minecraft:white_stained_glass
fill 556 145 278 558 146 278 minecraft:light_blue_stained_glass
fill 556 145 280 556 146 280 minecraft:white_stained_glass
fill 556 145 281 558 146 281 minecraft:light_blue_stained_glass
fill 556 145 288 558 146 289 minecraft:light_blue_stained_glass
fill 556 145 290 556 146 291 minecraft:white_stained_glass
fill 556 145 299 558 146 299 minecraft:light_blue_stained_glass
fill 556 145 301 556 146 301 minecraft:white_stained_glass
fill 556 145 302 558 146 302 minecraft:light_blue_stained_glass
fill 556 145 309 558 146 310 minecraft:light_blue_stained_glass
fill 556 145 311 556 146 312 minecraft:white_stained_glass
fill 557 145 280 558 146 280 minecraft:light_blue_stained_glass
fill 557 145 282 557 146 282 minecraft:white_stained_glass
fill 557 145 283 558 146 283 minecraft:light_blue_stained_glass
fill 557 145 290 558 146 291 minecraft:light_blue_stained_glass
fill 557 145 292 557 146 293 minecraft:white_stained_glass
fill 557 145 301 558 146 301 minecraft:light_blue_stained_glass
fill 557 145 303 557 146 303 minecraft:white_stained_glass
fill 557 145 304 558 146 304 minecraft:light_blue_stained_glass
fill 557 145 311 558 146 312 minecraft:light_blue_stained_glass
fill 557 145 313 557 146 314 minecraft:white_stained_glass
fill 558 145 282 558 146 282 minecraft:light_blue_stained_glass
fill 558 145 284 558 146 284 minecraft:white_stained_glass
fill 558 145 285 558 146 285 minecraft:light_blue_stained_glass
fill 558 145 292 558 146 293 minecraft:light_blue_stained_glass
fill 558 145 294 558 146 295 minecraft:white_stained_glass
fill 558 145 303 558 146 303 minecraft:light_blue_stained_glass
fill 558 145 305 558 146 305 minecraft:white_stained_glass
fill 558 145 306 558 146 306 minecraft:light_blue_stained_glass
fill 558 145 313 558 146 314 minecraft:light_blue_stained_glass
fill 558 145 315 558 146 316 minecraft:white_stained_glass
fill 529 146 297 531 146 298 minecraft:light_blue_stained_glass
fill 530 146 299 531 146 300 minecraft:light_blue_stained_glass
fill 531 146 301 532 146 302 minecraft:light_blue_stained_glass
fill 532 146 296 532 146 300 minecraft:white_concrete
fill 533 146 295 533 146 296 minecraft:white_concrete
fill 533 146 300 533 146 301 minecraft:white_concrete
fill 533 146 302 534 146 302 minecraft:light_blue_stained_glass
fill 534 146 295 537 146 295 minecraft:white_concrete
fill 534 146 301 537 146 301 minecraft:white_concrete
setblock 537 146 294 minecraft:white_stained_glass
fill 537 146 296 538 146 296 minecraft:white_concrete
fill 537 146 300 538 146 300 minecraft:white_concrete
fill 538 146 297 538 146 299 minecraft:white_concrete
fill 538 146 301 539 146 301 minecraft:light_blue_stained_glass
setblock 539 146 300 minecraft:light_blue_stained_glass
setblock 525 147 298 minecraft:red_concrete
setblock 528 147 291 minecraft:red_concrete
setblock 528 147 305 minecraft:red_concrete
setblock 535 147 288 minecraft:red_concrete
setblock 535 147 308 minecraft:red_concrete
setblock 542 147 291 minecraft:red_concrete
setblock 542 147 305 minecraft:red_concrete
setblock 545 147 298 minecraft:red_concrete
setblock 517 148 277 minecraft:white_concrete
setblock 517 148 281 minecraft:white_concrete
setblock 517 148 285 minecraft:white_concrete
setblock 517 148 289 minecraft:white_concrete
setblock 517 148 293 minecraft:white_concrete
setblock 517 148 297 minecraft:white_concrete
setblock 517 148 301 minecraft:white_concrete
setblock 517 148 305 minecraft:white_concrete
setblock 517 148 309 minecraft:white_concrete
setblock 517 148 313 minecraft:white_concrete
setblock 517 148 317 minecraft:white_concrete
setblock 519 148 275 minecraft:white_concrete
setblock 519 148 317 minecraft:white_concrete
setblock 523 148 275 minecraft:white_concrete
setblock 523 148 317 minecraft:white_concrete
setblock 525 148 298 minecraft:white_concrete
setblock 527 148 275 minecraft:white_concrete
setblock 527 148 317 minecraft:white_concrete
setblock 528 148 291 minecraft:white_concrete
setblock 528 148 305 minecraft:white_concrete
setblock 531 148 275 minecraft:white_concrete
setblock 531 148 317 minecraft:white_concrete
setblock 535 148 275 minecraft:white_concrete
setblock 535 148 288 minecraft:white_concrete
setblock 535 148 308 minecraft:white_concrete
setblock 535 148 317 minecraft:white_concrete
setblock 539 148 275 minecraft:white_concrete
setblock 539 148 317 minecraft:white_concrete
setblock 542 148 291 minecraft:white_concrete
setblock 542 148 305 minecraft:white_concrete
setblock 543 148 275 minecraft:white_concrete
setblock 543 148 317 minecraft:white_concrete
setblock 545 148 298 minecraft:white_concrete
setblock 547 148 275 minecraft:white_concrete
setblock 547 148 317 minecraft:white_concrete
setblock 551 148 275 minecraft:white_concrete
setblock 551 148 317 minecraft:white_concrete
setblock 555 148 275 minecraft:white_concrete
setblock 555 148 317 minecraft:white_concrete
setblock 559 148 275 minecraft:white_concrete
setblock 559 148 277 minecraft:white_concrete
setblock 559 148 281 minecraft:white_concrete
setblock 559 148 285 minecraft:white_concrete
setblock 559 148 289 minecraft:white_concrete
setblock 559 148 293 minecraft:white_concrete
setblock 559 148 297 minecraft:white_concrete
setblock 559 148 301 minecraft:white_concrete
setblock 559 148 305 minecraft:white_concrete
setblock 559 148 309 minecraft:white_concrete
setblock 559 148 313 minecraft:white_concrete
setblock 559 148 317 minecraft:white_concrete
setblock 517 149 276 minecraft:white_concrete
fill 517 149 277 517 156 277 minecraft:brown_terracotta
setblock 517 149 278 minecraft:white_concrete
setblock 517 149 280 minecraft:white_concrete
setblock 517 149 281 minecraft:brown_terracotta
setblock 517 149 282 minecraft:white_concrete
setblock 517 149 284 minecraft:white_concrete
fill 517 149 285 517 156 285 minecraft:brown_terracotta
setblock 517 149 286 minecraft:white_concrete
setblock 517 149 288 minecraft:white_concrete
fill 517 149 289 517 156 289 minecraft:brown_terracotta
setblock 517 149 290 minecraft:white_concrete
setblock 517 149 292 minecraft:white_concrete
setblock 517 149 293 minecraft:brown_terracotta
setblock 517 149 294 minecraft:white_concrete
setblock 517 149 296 minecraft:white_concrete
fill 517 149 297 517 156 297 minecraft:brown_terracotta
setblock 517 149 298 minecraft:white_concrete
setblock 517 149 300 minecraft:white_concrete
fill 517 149 301 517 156 301 minecraft:brown_terracotta
setblock 517 149 302 minecraft:white_concrete
setblock 517 149 304 minecraft:white_concrete
setblock 517 149 305 minecraft:brown_terracotta
setblock 517 149 306 minecraft:white_concrete
setblock 517 149 308 minecraft:white_concrete
fill 517 149 309 517 156 309 minecraft:brown_terracotta
setblock 517 149 310 minecraft:white_concrete
setblock 517 149 312 minecraft:white_concrete
fill 517 149 313 517 156 313 minecraft:brown_terracotta
setblock 517 149 314 minecraft:white_concrete
setblock 517 149 316 minecraft:white_concrete
setblock 517 149 317 minecraft:brown_terracotta
setblock 518 149 275 minecraft:white_concrete
setblock 518 149 317 minecraft:white_concrete
fill 519 149 275 519 156 275 minecraft:brown_terracotta
setblock 519 149 317 minecraft:brown_terracotta
setblock 520 149 275 minecraft:white_concrete
setblock 520 149 278 minecraft:light[level=15]
setblock 520 149 286 minecraft:light[level=15]
setblock 520 149 294 minecraft:light[level=15]
setblock 520 149 302 minecraft:light[level=15]
setblock 520 149 310 minecraft:light[level=15]
setblock 520 149 317 minecraft:white_concrete
setblock 522 149 275 minecraft:white_concrete
setblock 522 149 317 minecraft:white_concrete
fill 523 149 275 523 156 275 minecraft:brown_terracotta
fill 523 149 317 523 156 317 minecraft:brown_terracotta
setblock 524 149 275 minecraft:white_concrete
setblock 524 149 317 minecraft:white_concrete
setblock 525 149 298 minecraft:red_concrete
setblock 526 149 275 minecraft:white_concrete
setblock 526 149 317 minecraft:white_concrete
setblock 527 149 275 minecraft:brown_terracotta
fill 527 149 317 527 156 317 minecraft:brown_terracotta
setblock 528 149 275 minecraft:white_concrete
setblock 528 149 278 minecraft:light[level=15]
setblock 528 149 286 minecraft:light[level=15]
setblock 528 149 291 minecraft:red_concrete
setblock 528 149 294 minecraft:light[level=15]
setblock 528 149 302 minecraft:light[level=15]
setblock 528 149 305 minecraft:red_concrete
setblock 528 149 310 minecraft:light[level=15]
setblock 528 149 317 minecraft:white_concrete
setblock 530 149 275 minecraft:white_concrete
setblock 530 149 317 minecraft:white_concrete
fill 531 149 275 531 156 275 minecraft:brown_terracotta
setblock 531 149 317 minecraft:brown_terracotta
setblock 532 149 275 minecraft:white_concrete
setblock 532 149 317 minecraft:white_concrete
setblock 534 149 275 minecraft:white_concrete
setblock 534 149 317 minecraft:white_concrete
fill 535 149 275 535 156 275 minecraft:brown_terracotta
setblock 535 149 288 minecraft:red_concrete
setblock 535 149 308 minecraft:red_concrete
fill 535 149 317 535 156 317 minecraft:brown_terracotta
setblock 536 149 275 minecraft:white_concrete
setblock 536 149 278 minecraft:light[level=15]
setblock 536 149 286 minecraft:light[level=15]
setblock 536 149 294 minecraft:light[level=15]
setblock 536 149 302 minecraft:light[level=15]
setblock 536 149 310 minecraft:light[level=15]
setblock 536 149 317 minecraft:white_concrete
setblock 538 149 275 minecraft:white_concrete
setblock 538 149 317 minecraft:white_concrete
setblock 539 149 275 minecraft:brown_terracotta
fill 539 149 317 539 156 317 minecraft:brown_terracotta
setblock 540 149 275 minecraft:white_concrete
setblock 540 149 317 minecraft:white_concrete
setblock 542 149 275 minecraft:white_concrete
setblock 542 149 291 minecraft:red_concrete
setblock 542 149 305 minecraft:red_concrete
setblock 542 149 317 minecraft:white_concrete
fill 543 149 275 543 156 275 minecraft:brown_terracotta
setblock 543 149 317 minecraft:brown_terracotta
setblock 544 149 275 minecraft:white_concrete
setblock 544 149 278 minecraft:light[level=15]
setblock 544 149 286 minecraft:light[level=15]
setblock 544 149 294 minecraft:light[level=15]
setblock 544 149 302 minecraft:light[level=15]
setblock 544 149 310 minecraft:light[level=15]
setblock 544 149 317 minecraft:white_concrete
setblock 545 149 298 minecraft:red_concrete
setblock 546 149 275 minecraft:white_concrete
setblock 546 149 317 minecraft:white_concrete
fill 547 149 275 547 156 275 minecraft:brown_terracotta
fill 547 149 317 547 156 317 minecraft:brown_terracotta
setblock 548 149 275 minecraft:white_concrete
setblock 548 149 317 minecraft:white_concrete
setblock 550 149 275 minecraft:white_concrete
setblock 550 149 317 minecraft:white_concrete
setblock 551 149 275 minecraft:brown_terracotta
fill 551 149 317 551 156 317 minecraft:brown_terracotta
setblock 552 149 275 minecraft:white_concrete
setblock 552 149 278 minecraft:light[level=15]
setblock 552 149 286 minecraft:light[level=15]
setblock 552 149 294 minecraft:light[level=15]
setblock 552 149 302 minecraft:light[level=15]
setblock 552 149 310 minecraft:light[level=15]
setblock 552 149 317 minecraft:white_concrete
setblock 554 149 275 minecraft:white_concrete
setblock 554 149 317 minecraft:white_concrete
fill 555 149 275 555 150 275 minecraft:brown_terracotta
setblock 555 149 317 minecraft:brown_terracotta
setblock 556 149 275 minecraft:white_concrete
setblock 556 149 317 minecraft:white_concrete
setblock 558 149 275 minecraft:white_concrete
setblock 558 149 317 minecraft:white_concrete
setblock 559 149 275 minecraft:brown_terracotta
setblock 559 149 276 minecraft:white_concrete
setblock 559 149 277 minecraft:brown_terracotta
setblock 559 149 278 minecraft:white_concrete
setblock 559 149 280 minecraft:white_concrete
fill 559 149 281 559 156 281 minecraft:brown_terracotta
setblock 559 149 282 minecraft:white_concrete
setblock 559 149 284 minecraft:white_concrete
fill 559 149 285 559 156 285 minecraft:brown_terracotta
setblock 559 149 286 minecraft:white_concrete
setblock 559 149 288 minecraft:white_concrete
setblock 559 149 289 minecraft:brown_terracotta
setblock 559 149 290 minecraft:white_concrete
setblock 559 149 292 minecraft:white_concrete
fill 559 149 293 559 156 293 minecraft:brown_terracotta
setblock 559 149 294 minecraft:white_concrete
setblock 559 149 296 minecraft:white_concrete
fill 559 149 297 559 156 297 minecraft:brown_terracotta
setblock 559 149 298 minecraft:white_concrete
setblock 559 149 300 minecraft:white_concrete
setblock 559 149 301 minecraft:brown_terracotta
setblock 559 149 302 minecraft:white_concrete
setblock 559 149 304 minecraft:white_concrete
fill 559 149 305 559 156 305 minecraft:brown_terracotta
setblock 559 149 306 minecraft:white_concrete
setblock 559 149 308 minecraft:white_concrete
fill 559 149 309 559 156 309 minecraft:brown_terracotta
setblock 559 149 310 minecraft:white_concrete
setblock 559 149 312 minecraft:white_concrete
setblock 559 149 313 minecraft:brown_terracotta
setblock 559 149 314 minecraft:white_concrete
setblock 559 149 316 minecraft:white_concrete
fill 559 149 317 559 156 317 minecraft:brown_terracotta
setblock 517 150 275 minecraft:white_concrete
fill 517 150 276 517 157 276 minecraft:brown_terracotta
schedule function dropper:buildpart/71_3 1t
