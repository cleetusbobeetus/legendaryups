fill 475 207 278 475 209 278 minecraft:deepslate_tiles
setblock 476 207 276 minecraft:cobbled_deepslate
fill 476 207 277 476 209 277 minecraft:deepslate_tiles
setblock 476 207 316 minecraft:cobbled_deepslate
fill 477 207 276 477 209 276 minecraft:deepslate_tiles
setblock 477 207 315 minecraft:cobbled_deepslate
fill 477 207 316 477 209 316 minecraft:deepslate_tiles
fill 478 207 315 481 207 315 minecraft:deepslate_tiles
setblock 479 207 278 minecraft:cobbled_deepslate
setblock 480 207 277 minecraft:cobbled_deepslate
fill 481 207 275 481 308 275 minecraft:deepslate_tiles
setblock 481 207 276 minecraft:cobbled_deepslate
fill 481 207 277 481 209 277 minecraft:deepslate_tiles
setblock 481 207 316 minecraft:cobbled_deepslate
fill 482 207 276 482 209 276 minecraft:deepslate_tiles
setblock 482 207 315 minecraft:cobbled_deepslate
fill 482 207 316 482 209 316 minecraft:deepslate_tiles
fill 483 207 315 483 209 315 minecraft:deepslate_tiles
setblock 485 207 276 minecraft:deepslate_tiles
setblock 485 207 277 minecraft:cobbled_deepslate
setblock 486 207 276 minecraft:cobbled_deepslate
fill 486 207 277 488 207 278 minecraft:deepslate_tiles
setblock 486 207 316 minecraft:cobbled_deepslate
fill 487 207 276 487 209 276 minecraft:deepslate_tiles
setblock 487 207 315 minecraft:cobbled_deepslate
fill 487 207 316 487 209 316 minecraft:deepslate_tiles
setblock 488 207 314 minecraft:cobbled_deepslate
fill 488 207 315 488 209 315 minecraft:deepslate_tiles
setblock 489 207 277 minecraft:deepslate_tiles
setblock 489 207 278 minecraft:cobbled_deepslate
fill 489 207 314 489 209 314 minecraft:deepslate_tiles
setblock 490 207 277 minecraft:cobbled_deepslate
fill 490 207 278 490 209 278 minecraft:deepslate_tiles
setblock 490 207 313 minecraft:deepslate_tiles
setblock 491 207 276 minecraft:cobbled_deepslate
fill 491 207 277 491 209 277 minecraft:deepslate_tiles
setblock 491 207 316 minecraft:cobbled_deepslate
fill 492 207 276 492 209 276 minecraft:deepslate_tiles
setblock 492 207 315 minecraft:cobbled_deepslate
fill 492 207 316 492 209 316 minecraft:deepslate_tiles
setblock 493 207 314 minecraft:cobbled_deepslate
fill 493 207 315 493 209 315 minecraft:deepslate_tiles
fill 494 207 314 494 208 314 minecraft:deepslate_tiles
setblock 495 207 277 minecraft:cobbled_deepslate
setblock 496 207 276 minecraft:cobbled_deepslate
fill 496 207 277 496 208 277 minecraft:deepslate_tiles
setblock 496 207 316 minecraft:cobbled_deepslate
fill 497 207 276 497 209 276 minecraft:deepslate_tiles
setblock 497 207 315 minecraft:cobbled_deepslate
fill 497 207 316 497 209 316 minecraft:deepslate_tiles
setblock 498 207 315 minecraft:deepslate_tiles
setblock 501 207 276 minecraft:cobbled_deepslate
setblock 501 207 316 minecraft:cobbled_deepslate
fill 502 207 276 505 207 276 minecraft:deepslate_tiles
fill 502 207 316 502 208 316 minecraft:deepslate_tiles
setblock 505 207 316 minecraft:deepslate_tiles
setblock 506 207 276 minecraft:cobbled_deepslate
fill 506 207 277 506 209 277 minecraft:deepslate_tiles
setblock 506 207 316 minecraft:cobbled_deepslate
fill 507 207 276 507 209 276 minecraft:deepslate_tiles
fill 507 207 316 507 209 316 minecraft:deepslate_tiles
setblock 508 207 293 minecraft:deepslate_tiles
setblock 508 207 294 minecraft:cobbled_deepslate
fill 508 207 295 508 209 295 minecraft:deepslate_tiles
setblock 508 207 298 minecraft:deepslate_tiles
setblock 508 207 299 minecraft:cobbled_deepslate
fill 508 207 300 508 209 300 minecraft:deepslate_tiles
setblock 508 207 315 minecraft:deepslate_tiles
setblock 509 207 278 minecraft:cobbled_deepslate
fill 509 207 279 509 209 280 minecraft:deepslate_tiles
fill 509 207 289 509 209 289 minecraft:deepslate_tiles
setblock 509 207 293 minecraft:cobbled_deepslate
fill 509 207 294 509 209 294 minecraft:deepslate_tiles
setblock 509 207 298 minecraft:cobbled_deepslate
fill 509 207 299 509 209 299 minecraft:deepslate_tiles
setblock 509 207 302 minecraft:deepslate_tiles
setblock 509 207 303 minecraft:cobbled_deepslate
setblock 510 207 276 minecraft:deepslate_tiles
setblock 510 207 277 minecraft:cobbled_deepslate
fill 510 207 278 510 209 278 minecraft:deepslate_tiles
fill 510 207 280 510 207 281 minecraft:deepslate_tiles
setblock 510 207 282 minecraft:cobbled_deepslate
fill 510 207 283 510 209 283 minecraft:deepslate_tiles
setblock 510 207 287 minecraft:cobbled_deepslate
fill 510 207 288 510 209 288 minecraft:deepslate_tiles
setblock 510 207 292 minecraft:cobbled_deepslate
fill 510 207 293 510 209 293 minecraft:deepslate_tiles
setblock 510 207 297 minecraft:cobbled_deepslate
fill 510 207 298 510 209 298 minecraft:deepslate_tiles
setblock 510 207 301 minecraft:deepslate_tiles
setblock 510 207 302 minecraft:cobbled_deepslate
fill 510 207 303 510 209 303 minecraft:deepslate_tiles
fill 510 207 305 511 207 305 minecraft:deepslate_tiles
setblock 511 207 276 minecraft:cobbled_deepslate
fill 511 207 277 511 209 277 minecraft:deepslate_tiles
setblock 511 207 280 minecraft:deepslate_tiles
setblock 511 207 281 minecraft:cobbled_deepslate
fill 511 207 282 511 209 282 minecraft:deepslate_tiles
setblock 511 207 286 minecraft:cobbled_deepslate
fill 511 207 287 511 209 287 minecraft:deepslate_tiles
setblock 511 207 291 minecraft:cobbled_deepslate
fill 511 207 292 511 209 292 minecraft:deepslate_tiles
setblock 511 207 296 minecraft:cobbled_deepslate
fill 511 207 297 511 209 297 minecraft:deepslate_tiles
setblock 511 207 301 minecraft:cobbled_deepslate
fill 511 207 302 511 209 302 minecraft:deepslate_tiles
setblock 511 207 306 minecraft:cobbled_deepslate
fill 511 207 307 511 209 307 minecraft:deepslate_tiles
setblock 511 207 311 minecraft:cobbled_deepslate
fill 511 207 312 511 209 312 minecraft:deepslate_tiles
setblock 511 207 316 minecraft:cobbled_deepslate
fill 471 208 276 471 209 276 minecraft:deepslate_tiles
setblock 471 208 280 minecraft:cobbled_deepslate
fill 471 208 281 471 209 281 minecraft:deepslate_tiles
setblock 471 208 285 minecraft:cobbled_deepslate
fill 471 208 286 471 209 286 minecraft:deepslate_tiles
setblock 471 208 290 minecraft:cobbled_deepslate
fill 471 208 291 471 209 291 minecraft:deepslate_tiles
setblock 471 208 295 minecraft:cobbled_deepslate
fill 471 208 296 471 209 296 minecraft:deepslate_tiles
setblock 471 208 300 minecraft:cobbled_deepslate
fill 471 208 301 471 209 301 minecraft:deepslate_tiles
setblock 471 208 305 minecraft:cobbled_deepslate
fill 471 208 306 471 209 306 minecraft:deepslate_tiles
setblock 471 208 310 minecraft:cobbled_deepslate
fill 471 208 311 471 209 311 minecraft:deepslate_tiles
setblock 471 208 315 minecraft:cobbled_deepslate
fill 471 208 316 474 208 316 minecraft:deepslate_tiles
setblock 472 208 279 minecraft:cobbled_deepslate
fill 472 208 280 472 209 280 minecraft:deepslate_tiles
setblock 472 208 283 minecraft:deepslate_tiles
setblock 472 208 284 minecraft:cobbled_deepslate
fill 472 208 285 472 209 285 minecraft:deepslate_tiles
setblock 472 208 289 minecraft:cobbled_deepslate
fill 472 208 290 472 209 290 minecraft:deepslate_tiles
setblock 472 208 294 minecraft:cobbled_deepslate
fill 472 208 295 472 209 295 minecraft:deepslate_tiles
setblock 472 208 299 minecraft:cobbled_deepslate
fill 472 208 300 472 209 300 minecraft:deepslate_tiles
setblock 472 208 314 minecraft:cobbled_deepslate
fill 472 208 315 472 209 315 minecraft:deepslate_tiles
setblock 473 208 278 minecraft:cobbled_deepslate
fill 473 208 279 473 209 279 minecraft:deepslate_tiles
setblock 473 208 283 minecraft:cobbled_deepslate
fill 473 208 284 473 209 284 minecraft:deepslate_tiles
setblock 473 208 294 minecraft:deepslate_tiles
setblock 473 208 298 minecraft:cobbled_deepslate
setblock 473 208 299 minecraft:deepslate_tiles
setblock 474 208 277 minecraft:cobbled_deepslate
fill 474 208 278 474 209 278 minecraft:deepslate_tiles
setblock 475 208 276 minecraft:cobbled_deepslate
fill 475 208 277 475 209 277 minecraft:deepslate_tiles
setblock 475 208 316 minecraft:cobbled_deepslate
fill 476 208 276 476 209 276 minecraft:deepslate_tiles
setblock 476 208 315 minecraft:cobbled_deepslate
fill 476 208 316 476 209 316 minecraft:deepslate_tiles
setblock 477 208 278 minecraft:deepslate_tiles
fill 477 208 315 480 208 315 minecraft:deepslate_tiles
setblock 478 208 278 minecraft:cobbled_deepslate
setblock 479 208 277 minecraft:cobbled_deepslate
setblock 479 208 278 minecraft:deepslate_tiles
setblock 480 208 276 minecraft:cobbled_deepslate
fill 480 208 277 480 209 277 minecraft:deepslate_tiles
setblock 480 208 316 minecraft:cobbled_deepslate
fill 481 208 276 481 209 276 minecraft:deepslate_tiles
setblock 481 208 315 minecraft:cobbled_deepslate
fill 481 208 316 481 209 316 minecraft:deepslate_tiles
fill 482 208 315 482 209 315 minecraft:deepslate_tiles
setblock 483 208 277 minecraft:deepslate_tiles
setblock 484 208 277 minecraft:cobbled_deepslate
setblock 485 208 276 minecraft:cobbled_deepslate
fill 485 208 277 487 208 278 minecraft:deepslate_tiles
setblock 485 208 316 minecraft:cobbled_deepslate
fill 486 208 276 486 209 276 minecraft:deepslate_tiles
setblock 486 208 315 minecraft:cobbled_deepslate
fill 486 208 316 486 209 316 minecraft:deepslate_tiles
setblock 487 208 314 minecraft:cobbled_deepslate
fill 487 208 315 487 209 315 minecraft:deepslate_tiles
setblock 488 208 277 minecraft:deepslate_tiles
setblock 488 208 278 minecraft:cobbled_deepslate
fill 488 208 314 488 209 314 minecraft:deepslate_tiles
setblock 489 208 277 minecraft:cobbled_deepslate
fill 489 208 278 489 209 278 minecraft:deepslate_tiles
setblock 490 208 276 minecraft:cobbled_deepslate
fill 490 208 277 490 209 277 minecraft:deepslate_tiles
setblock 490 208 316 minecraft:cobbled_deepslate
fill 490 208 317 490 308 317 minecraft:deepslate_tiles
fill 491 208 276 491 209 276 minecraft:deepslate_tiles
setblock 491 208 315 minecraft:cobbled_deepslate
fill 491 208 316 491 209 316 minecraft:deepslate_tiles
setblock 492 208 314 minecraft:cobbled_deepslate
fill 492 208 315 492 209 315 minecraft:deepslate_tiles
setblock 493 208 278 minecraft:cobbled_deepslate
fill 493 208 314 493 209 314 minecraft:deepslate_tiles
setblock 494 208 277 minecraft:cobbled_deepslate
fill 495 208 275 495 308 275 minecraft:deepslate_tiles
setblock 495 208 276 minecraft:cobbled_deepslate
fill 495 208 277 495 209 277 minecraft:deepslate_tiles
setblock 495 208 316 minecraft:cobbled_deepslate
fill 496 208 276 496 209 276 minecraft:deepslate_tiles
setblock 496 208 315 minecraft:cobbled_deepslate
fill 496 208 316 496 209 316 minecraft:deepslate_tiles
setblock 497 208 315 minecraft:deepslate_tiles
setblock 499 208 276 minecraft:deepslate_tiles
setblock 500 208 276 minecraft:cobbled_deepslate
setblock 500 208 316 minecraft:cobbled_deepslate
fill 501 208 276 504 208 276 minecraft:deepslate_tiles
setblock 501 208 316 minecraft:deepslate_tiles
setblock 505 208 276 minecraft:cobbled_deepslate
setblock 505 208 316 minecraft:cobbled_deepslate
fill 506 208 276 506 209 276 minecraft:deepslate_tiles
fill 506 208 316 506 209 316 minecraft:deepslate_tiles
setblock 508 208 278 minecraft:cobbled_deepslate
fill 508 208 294 508 209 294 minecraft:deepslate_tiles
setblock 508 208 298 minecraft:cobbled_deepslate
fill 508 208 299 508 209 299 minecraft:deepslate_tiles
fill 508 208 301 508 209 301 minecraft:deepslate_tiles
setblock 509 208 276 minecraft:deepslate_tiles
setblock 509 208 277 minecraft:cobbled_deepslate
fill 509 208 278 509 209 278 minecraft:deepslate_tiles
setblock 509 208 281 minecraft:deepslate_tiles
setblock 509 208 282 minecraft:cobbled_deepslate
fill 509 208 283 509 209 283 minecraft:deepslate_tiles
setblock 509 208 292 minecraft:cobbled_deepslate
fill 509 208 293 509 209 293 minecraft:deepslate_tiles
setblock 509 208 297 minecraft:cobbled_deepslate
fill 509 208 298 509 209 298 minecraft:deepslate_tiles
setblock 509 208 302 minecraft:cobbled_deepslate
fill 509 208 303 509 209 303 minecraft:deepslate_tiles
setblock 510 208 276 minecraft:cobbled_deepslate
fill 510 208 277 510 209 277 minecraft:deepslate_tiles
setblock 510 208 280 minecraft:deepslate_tiles
setblock 510 208 281 minecraft:cobbled_deepslate
fill 510 208 282 510 209 282 minecraft:deepslate_tiles
setblock 510 208 286 minecraft:cobbled_deepslate
fill 510 208 287 510 209 287 minecraft:deepslate_tiles
setblock 510 208 291 minecraft:cobbled_deepslate
fill 510 208 292 510 209 292 minecraft:deepslate_tiles
setblock 510 208 296 minecraft:cobbled_deepslate
fill 510 208 297 510 209 297 minecraft:deepslate_tiles
setblock 510 208 301 minecraft:cobbled_deepslate
fill 510 208 302 510 209 302 minecraft:deepslate_tiles
setblock 510 208 305 minecraft:deepslate_tiles
setblock 510 208 306 minecraft:cobbled_deepslate
setblock 510 208 316 minecraft:cobbled_deepslate
fill 511 208 276 511 209 276 minecraft:deepslate_tiles
setblock 511 208 280 minecraft:cobbled_deepslate
fill 511 208 281 511 209 281 minecraft:deepslate_tiles
setblock 511 208 285 minecraft:cobbled_deepslate
fill 511 208 286 511 209 286 minecraft:deepslate_tiles
setblock 511 208 290 minecraft:cobbled_deepslate
fill 511 208 291 511 209 291 minecraft:deepslate_tiles
setblock 511 208 295 minecraft:cobbled_deepslate
fill 511 208 296 511 209 296 minecraft:deepslate_tiles
setblock 511 208 300 minecraft:cobbled_deepslate
fill 511 208 301 511 209 301 minecraft:deepslate_tiles
setblock 511 208 305 minecraft:cobbled_deepslate
fill 511 208 306 511 209 306 minecraft:deepslate_tiles
setblock 511 208 310 minecraft:cobbled_deepslate
fill 511 208 311 511 209 311 minecraft:deepslate_tiles
setblock 511 208 315 minecraft:cobbled_deepslate
fill 511 208 316 511 209 316 minecraft:deepslate_tiles
setblock 471 209 279 minecraft:cobbled_deepslate
setblock 471 209 280 minecraft:deepslate_tiles
setblock 471 209 284 minecraft:cobbled_deepslate
setblock 471 209 285 minecraft:deepslate_tiles
setblock 471 209 289 minecraft:cobbled_deepslate
setblock 471 209 290 minecraft:deepslate_tiles
setblock 471 209 294 minecraft:cobbled_deepslate
setblock 471 209 295 minecraft:deepslate_tiles
setblock 471 209 299 minecraft:cobbled_deepslate
setblock 471 209 300 minecraft:deepslate_tiles
setblock 471 209 304 minecraft:cobbled_deepslate
setblock 471 209 305 minecraft:deepslate_tiles
setblock 471 209 309 minecraft:cobbled_deepslate
setblock 471 209 310 minecraft:deepslate_tiles
setblock 471 209 314 minecraft:cobbled_deepslate
fill 471 209 315 471 209 316 minecraft:deepslate_tiles
setblock 472 209 278 minecraft:cobbled_deepslate
setblock 472 209 279 minecraft:deepslate_tiles
setblock 472 209 283 minecraft:cobbled_deepslate
setblock 472 209 284 minecraft:deepslate_tiles
setblock 472 209 288 minecraft:cobbled_deepslate
setblock 472 209 289 minecraft:deepslate_tiles
setblock 472 209 293 minecraft:cobbled_deepslate
setblock 472 209 294 minecraft:deepslate_tiles
setblock 472 209 298 minecraft:cobbled_deepslate
setblock 472 209 299 minecraft:deepslate_tiles
setblock 472 209 303 minecraft:cobbled_deepslate
setblock 472 209 314 minecraft:deepslate_tiles
fill 472 209 316 473 209 316 minecraft:deepslate_tiles
setblock 473 209 277 minecraft:cobbled_deepslate
setblock 473 209 278 minecraft:deepslate_tiles
setblock 473 209 282 minecraft:cobbled_deepslate
setblock 473 209 283 minecraft:deepslate_tiles
setblock 474 209 276 minecraft:cobbled_deepslate
setblock 474 209 277 minecraft:deepslate_tiles
setblock 474 209 316 minecraft:cobbled_deepslate
setblock 475 209 276 minecraft:deepslate_tiles
setblock 475 209 315 minecraft:cobbled_deepslate
setblock 475 209 316 minecraft:deepslate_tiles
setblock 476 209 315 minecraft:deepslate_tiles
setblock 477 209 278 minecraft:cobbled_deepslate
setblock 478 209 277 minecraft:cobbled_deepslate
setblock 478 209 278 minecraft:deepslate_tiles
setblock 479 209 276 minecraft:cobbled_deepslate
setblock 479 209 277 minecraft:deepslate_tiles
setblock 479 209 316 minecraft:cobbled_deepslate
setblock 480 209 276 minecraft:deepslate_tiles
setblock 480 209 316 minecraft:deepslate_tiles
setblock 483 209 277 minecraft:cobbled_deepslate
setblock 484 209 276 minecraft:cobbled_deepslate
fill 484 209 277 486 209 278 minecraft:deepslate_tiles
setblock 484 209 316 minecraft:cobbled_deepslate
setblock 485 209 276 minecraft:deepslate_tiles
setblock 485 209 315 minecraft:cobbled_deepslate
setblock 485 209 316 minecraft:deepslate_tiles
setblock 486 209 314 minecraft:cobbled_deepslate
setblock 486 209 315 minecraft:deepslate_tiles
setblock 487 209 277 minecraft:deepslate_tiles
setblock 487 209 278 minecraft:cobbled_deepslate
setblock 487 209 314 minecraft:deepslate_tiles
setblock 488 209 277 minecraft:cobbled_deepslate
setblock 488 209 278 minecraft:deepslate_tiles
setblock 489 209 276 minecraft:cobbled_deepslate
setblock 489 209 277 minecraft:deepslate_tiles
setblock 489 209 316 minecraft:cobbled_deepslate
setblock 490 209 276 minecraft:deepslate_tiles
setblock 490 209 315 minecraft:cobbled_deepslate
setblock 490 209 316 minecraft:deepslate_tiles
setblock 491 209 314 minecraft:cobbled_deepslate
setblock 491 209 315 minecraft:deepslate_tiles
setblock 492 209 278 minecraft:cobbled_deepslate
setblock 492 209 314 minecraft:deepslate_tiles
setblock 493 209 277 minecraft:cobbled_deepslate
setblock 493 209 278 minecraft:deepslate_tiles
fill 494 209 275 494 308 275 minecraft:deepslate_tiles
setblock 494 209 276 minecraft:cobbled_deepslate
setblock 494 209 277 minecraft:deepslate_tiles
setblock 494 209 316 minecraft:cobbled_deepslate
setblock 495 209 276 minecraft:deepslate_tiles
setblock 495 209 315 minecraft:cobbled_deepslate
setblock 495 209 316 minecraft:deepslate_tiles
setblock 496 209 315 minecraft:deepslate_tiles
setblock 499 209 276 minecraft:cobbled_deepslate
setblock 499 209 316 minecraft:cobbled_deepslate
fill 502 209 276 503 209 276 minecraft:deepslate_tiles
setblock 504 209 276 minecraft:cobbled_deepslate
fill 505 209 276 505 209 277 minecraft:deepslate_tiles
setblock 505 209 316 minecraft:deepslate_tiles
setblock 507 209 277 minecraft:deepslate_tiles
setblock 507 209 278 minecraft:cobbled_deepslate
setblock 508 209 277 minecraft:cobbled_deepslate
setblock 508 209 278 minecraft:deepslate_tiles
setblock 508 209 297 minecraft:cobbled_deepslate
setblock 508 209 298 minecraft:deepslate_tiles
setblock 509 209 276 minecraft:cobbled_deepslate
setblock 509 209 277 minecraft:deepslate_tiles
setblock 509 209 281 minecraft:cobbled_deepslate
setblock 509 209 282 minecraft:deepslate_tiles
fill 509 209 284 509 209 285 minecraft:deepslate_tiles
setblock 509 209 291 minecraft:cobbled_deepslate
setblock 509 209 292 minecraft:deepslate_tiles
setblock 509 209 296 minecraft:cobbled_deepslate
setblock 509 209 297 minecraft:deepslate_tiles
setblock 509 209 301 minecraft:cobbled_deepslate
setblock 509 209 302 minecraft:deepslate_tiles
fill 509 209 304 510 209 304 minecraft:deepslate_tiles
setblock 509 209 316 minecraft:cobbled_deepslate
setblock 510 209 276 minecraft:deepslate_tiles
setblock 510 209 280 minecraft:cobbled_deepslate
setblock 510 209 281 minecraft:deepslate_tiles
setblock 510 209 284 minecraft:deepslate_tiles
setblock 510 209 285 minecraft:cobbled_deepslate
setblock 510 209 286 minecraft:deepslate_tiles
setblock 510 209 290 minecraft:cobbled_deepslate
setblock 510 209 291 minecraft:deepslate_tiles
setblock 510 209 295 minecraft:cobbled_deepslate
setblock 510 209 296 minecraft:deepslate_tiles
setblock 510 209 300 minecraft:cobbled_deepslate
setblock 510 209 301 minecraft:deepslate_tiles
setblock 510 209 305 minecraft:cobbled_deepslate
setblock 510 209 306 minecraft:deepslate_tiles
setblock 510 209 315 minecraft:cobbled_deepslate
setblock 510 209 316 minecraft:deepslate_tiles
setblock 511 209 279 minecraft:cobbled_deepslate
setblock 511 209 280 minecraft:deepslate_tiles
setblock 511 209 284 minecraft:cobbled_deepslate
setblock 511 209 285 minecraft:deepslate_tiles
setblock 511 209 289 minecraft:cobbled_deepslate
setblock 511 209 290 minecraft:deepslate_tiles
setblock 511 209 294 minecraft:cobbled_deepslate
setblock 511 209 295 minecraft:deepslate_tiles
setblock 511 209 299 minecraft:cobbled_deepslate
setblock 511 209 300 minecraft:deepslate_tiles
setblock 511 209 304 minecraft:cobbled_deepslate
setblock 511 209 305 minecraft:deepslate_tiles
setblock 511 209 309 minecraft:cobbled_deepslate
setblock 511 209 310 minecraft:deepslate_tiles
setblock 511 209 314 minecraft:cobbled_deepslate
setblock 511 209 315 minecraft:deepslate_tiles
fill 512 209 314 512 308 314 minecraft:deepslate_tiles
setblock 512 210 313 minecraft:white_wool
setblock 473 211 278 minecraft:light[level=12]
setblock 473 211 285 minecraft:light[level=12]
setblock 473 211 292 minecraft:light[level=12]
setblock 473 211 299 minecraft:light[level=12]
setblock 473 211 306 minecraft:light[level=12]
setblock 473 211 313 minecraft:light[level=12]
setblock 480 211 278 minecraft:light[level=12]
setblock 480 211 285 minecraft:light[level=12]
setblock 480 211 292 minecraft:light[level=12]
setblock 480 211 299 minecraft:light[level=12]
setblock 480 211 306 minecraft:light[level=12]
setblock 480 211 313 minecraft:light[level=12]
setblock 487 211 278 minecraft:light[level=12]
setblock 487 211 285 minecraft:light[level=12]
setblock 487 211 292 minecraft:light[level=12]
setblock 487 211 299 minecraft:light[level=12]
setblock 487 211 306 minecraft:light[level=12]
setblock 487 211 313 minecraft:light[level=12]
setblock 494 211 278 minecraft:light[level=12]
setblock 494 211 285 minecraft:light[level=12]
setblock 494 211 292 minecraft:light[level=12]
setblock 494 211 299 minecraft:light[level=12]
setblock 494 211 306 minecraft:light[level=12]
setblock 494 211 313 minecraft:light[level=12]
setblock 501 211 278 minecraft:light[level=12]
setblock 501 211 285 minecraft:light[level=12]
setblock 501 211 292 minecraft:light[level=12]
setblock 501 211 299 minecraft:light[level=12]
setblock 501 211 306 minecraft:light[level=12]
setblock 501 211 313 minecraft:light[level=12]
setblock 508 211 278 minecraft:light[level=12]
setblock 508 211 285 minecraft:light[level=12]
setblock 508 211 292 minecraft:light[level=12]
setblock 508 211 299 minecraft:light[level=12]
setblock 508 211 306 minecraft:light[level=12]
setblock 508 211 313 minecraft:light[level=12]
fill 512 211 313 512 308 313 minecraft:deepslate_tiles
setblock 473 213 278 minecraft:light[level=13]
setblock 473 213 286 minecraft:light[level=13]
setblock 473 213 294 minecraft:light[level=13]
setblock 473 213 302 minecraft:light[level=13]
setblock 473 213 310 minecraft:light[level=13]
setblock 481 213 278 minecraft:light[level=13]
setblock 481 213 286 minecraft:light[level=13]
setblock 481 213 294 minecraft:light[level=13]
setblock 481 213 302 minecraft:light[level=13]
setblock 481 213 310 minecraft:light[level=13]
setblock 489 213 278 minecraft:light[level=13]
setblock 489 213 286 minecraft:light[level=13]
setblock 489 213 294 minecraft:light[level=13]
setblock 489 213 302 minecraft:light[level=13]
setblock 489 213 310 minecraft:light[level=13]
setblock 497 213 278 minecraft:light[level=13]
setblock 497 213 286 minecraft:light[level=13]
setblock 497 213 294 minecraft:light[level=13]
setblock 497 213 302 minecraft:light[level=13]
setblock 497 213 310 minecraft:light[level=13]
setblock 505 213 278 minecraft:light[level=13]
setblock 505 213 286 minecraft:light[level=13]
setblock 505 213 294 minecraft:light[level=13]
setblock 505 213 302 minecraft:light[level=13]
setblock 505 213 310 minecraft:light[level=13]
setblock 512 213 278 minecraft:redstone_block
fill 487 214 296 487 227 298 minecraft:black_concrete
fill 488 214 294 488 227 296 minecraft:black_concrete
fill 488 214 300 488 227 300 minecraft:black_concrete
fill 489 214 294 493 227 295 minecraft:black_concrete
fill 492 214 296 494 227 296 minecraft:black_concrete
fill 492 214 300 493 227 300 minecraft:black_concrete
fill 493 214 297 493 227 299 minecraft:black_concrete
fill 494 214 297 494 227 298 minecraft:black_concrete
setblock 512 214 278 minecraft:deepslate_tiles
fill 472 215 293 473 215 293 minecraft:black_wool
fill 474 215 317 479 231 317 minecraft:deepslate_tiles
fill 475 215 307 475 217 307 minecraft:black_wool
fill 480 215 281 480 215 282 minecraft:black_wool
setblock 480 215 317 minecraft:white_wool
fill 481 215 317 487 217 317 minecraft:deepslate_tiles
fill 486 215 294 486 227 300 minecraft:black_concrete
fill 487 215 293 487 227 295 minecraft:black_concrete
fill 487 215 299 487 227 301 minecraft:black_concrete
fill 487 215 315 487 218 315 minecraft:black_wool
fill 488 215 293 494 227 293 minecraft:black_concrete
fill 488 215 301 494 227 301 minecraft:black_concrete
fill 489 215 292 492 227 292 minecraft:black_concrete
fill 489 215 302 492 227 302 minecraft:black_concrete
fill 494 215 279 494 218 279 minecraft:black_wool
fill 494 215 294 495 227 295 minecraft:black_concrete
fill 494 215 299 495 227 300 minecraft:black_concrete
fill 495 215 296 495 227 298 minecraft:black_concrete
fill 501 215 312 501 215 313 minecraft:black_wool
fill 506 215 287 506 217 287 minecraft:black_wool
fill 508 215 301 509 215 301 minecraft:black_wool
setblock 512 215 278 minecraft:redstone_block
fill 473 216 293 473 219 293 minecraft:black_wool
fill 476 216 307 476 220 307 minecraft:black_wool
fill 480 216 282 481 217 282 minecraft:black_wool
fill 480 216 317 480 308 317 minecraft:deepslate_tiles
fill 485 216 294 485 227 300 minecraft:black_concrete
fill 486 216 293 486 227 293 minecraft:black_concrete
fill 486 216 301 486 227 301 minecraft:black_concrete
fill 487 216 292 488 227 292 minecraft:black_concrete
fill 487 216 302 488 227 302 minecraft:black_concrete
fill 489 216 291 492 227 291 minecraft:black_concrete
fill 489 216 303 492 225 303 minecraft:black_concrete
fill 493 216 292 494 227 292 minecraft:black_concrete
fill 493 216 302 494 227 302 minecraft:black_concrete
fill 495 216 293 495 227 293 minecraft:black_concrete
fill 495 216 301 495 227 301 minecraft:black_concrete
fill 496 216 294 496 227 300 minecraft:black_concrete
fill 500 216 312 501 217 312 minecraft:black_wool
fill 505 216 287 505 220 287 minecraft:black_wool
fill 508 216 301 508 219 301 minecraft:black_wool
fill 512 216 278 512 308 278 minecraft:deepslate_tiles
setblock 473 217 278 minecraft:light[level=12]
setblock 473 217 285 minecraft:light[level=12]
setblock 473 217 292 minecraft:light[level=12]
fill 473 217 294 473 219 294 minecraft:black_wool
setblock 473 217 299 minecraft:light[level=12]
setblock 473 217 306 minecraft:light[level=12]
setblock 473 217 313 minecraft:light[level=12]
setblock 480 217 278 minecraft:light[level=12]
setblock 480 217 285 minecraft:light[level=12]
setblock 480 217 292 minecraft:light[level=12]
setblock 480 217 299 minecraft:light[level=12]
setblock 480 217 306 minecraft:light[level=12]
setblock 480 217 313 minecraft:light[level=12]
fill 484 217 294 484 226 300 minecraft:black_concrete
fill 485 217 293 485 226 293 minecraft:black_concrete
fill 485 217 301 485 226 301 minecraft:black_concrete
fill 486 217 292 486 226 292 minecraft:black_concrete
fill 486 217 302 486 226 302 minecraft:black_concrete
setblock 487 217 278 minecraft:light[level=12]
setblock 487 217 285 minecraft:light[level=12]
fill 487 217 291 488 226 291 minecraft:black_concrete
fill 487 217 303 488 225 303 minecraft:black_concrete
setblock 487 217 306 minecraft:light[level=12]
setblock 487 217 313 minecraft:light[level=12]
fill 487 217 314 487 221 314 minecraft:black_wool
fill 489 217 290 492 222 290 minecraft:black_concrete
fill 489 217 304 492 222 304 minecraft:black_concrete
fill 493 217 291 494 226 291 minecraft:black_concrete
fill 493 217 303 494 225 303 minecraft:black_concrete
setblock 494 217 278 minecraft:light[level=12]
fill 494 217 280 494 221 280 minecraft:black_wool
setblock 494 217 285 minecraft:light[level=12]
setblock 494 217 306 minecraft:light[level=12]
setblock 494 217 313 minecraft:light[level=12]
fill 495 217 292 495 226 292 minecraft:black_concrete
fill 495 217 302 495 226 302 minecraft:black_concrete
fill 496 217 293 496 226 293 minecraft:black_concrete
fill 496 217 301 496 226 301 minecraft:black_concrete
fill 497 217 294 497 226 300 minecraft:black_concrete
setblock 501 217 278 minecraft:light[level=12]
setblock 501 217 285 minecraft:light[level=12]
setblock 501 217 292 minecraft:light[level=12]
setblock 501 217 299 minecraft:light[level=12]
setblock 501 217 306 minecraft:light[level=12]
setblock 501 217 313 minecraft:light[level=12]
setblock 508 217 278 minecraft:light[level=12]
setblock 508 217 285 minecraft:light[level=12]
setblock 508 217 292 minecraft:light[level=12]
setblock 508 217 299 minecraft:light[level=12]
fill 508 217 300 508 219 300 minecraft:black_wool
setblock 508 217 306 minecraft:light[level=12]
setblock 508 217 313 minecraft:light[level=12]
setblock 512 217 316 minecraft:redstone_block
fill 481 218 282 481 220 282 minecraft:black_wool
fill 481 218 317 482 308 317 minecraft:deepslate_tiles
fill 483 218 296 483 222 298 minecraft:black_concrete
setblock 483 218 317 minecraft:white_wool
fill 484 218 293 484 225 293 minecraft:black_concrete
fill 484 218 301 484 222 301 minecraft:black_concrete
fill 484 218 317 487 279 317 minecraft:deepslate_tiles
fill 485 218 292 485 225 292 minecraft:black_concrete
fill 485 218 302 485 225 302 minecraft:black_concrete
fill 486 218 291 486 222 291 minecraft:black_concrete
fill 486 218 303 486 225 303 minecraft:black_concrete
fill 488 218 290 488 225 290 minecraft:black_concrete
fill 488 218 304 488 225 304 minecraft:black_concrete
fill 493 218 290 493 225 290 minecraft:black_concrete
fill 493 218 304 493 225 304 minecraft:black_concrete
fill 495 218 291 495 225 291 minecraft:black_concrete
fill 495 218 303 495 222 303 minecraft:black_concrete
fill 496 218 292 496 225 292 minecraft:black_concrete
fill 496 218 302 496 225 302 minecraft:black_concrete
fill 497 218 293 497 222 293 minecraft:black_concrete
fill 497 218 301 497 225 301 minecraft:black_concrete
fill 498 218 296 498 222 298 minecraft:black_concrete
fill 500 218 312 500 220 312 minecraft:black_wool
fill 512 218 316 512 253 316 minecraft:deepslate_tiles
fill 476 219 306 476 222 306 minecraft:black_wool
fill 481 219 283 481 223 283 minecraft:black_wool
fill 483 219 294 483 222 295 minecraft:black_concrete
fill 483 219 299 483 224 300 minecraft:black_concrete
fill 483 219 317 483 308 317 minecraft:deepslate_tiles
fill 487 219 290 487 224 290 minecraft:black_concrete
fill 487 219 304 487 224 304 minecraft:black_concrete
fill 490 219 289 491 224 289 minecraft:black_concrete
fill 490 219 305 491 224 305 minecraft:black_concrete
fill 494 219 290 494 224 290 minecraft:black_concrete
fill 494 219 304 494 224 304 minecraft:black_concrete
fill 498 219 294 498 224 295 minecraft:black_concrete
fill 498 219 299 498 222 300 minecraft:black_concrete
fill 500 219 311 500 223 311 minecraft:black_wool
fill 505 219 275 506 221 275 minecraft:deepslate_tiles
fill 505 219 288 505 222 288 minecraft:black_wool
setblock 507 219 275 minecraft:redstone_block
fill 474 220 293 474 221 294 minecraft:black_wool
fill 484 220 292 484 223 292 minecraft:black_concrete
fill 484 220 302 484 222 302 minecraft:black_concrete
fill 485 220 291 485 223 291 minecraft:black_concrete
fill 485 220 303 485 223 303 minecraft:black_concrete
fill 486 220 290 486 222 290 minecraft:black_concrete
fill 486 220 304 486 223 304 minecraft:black_concrete
fill 489 220 289 489 223 289 minecraft:black_concrete
fill 489 220 305 489 222 305 minecraft:black_concrete
fill 492 220 289 492 222 289 minecraft:black_concrete
fill 492 220 305 492 223 305 minecraft:black_concrete
fill 495 220 290 495 223 290 minecraft:black_concrete
fill 495 220 304 495 222 304 minecraft:black_concrete
fill 496 220 291 496 223 291 minecraft:black_concrete
fill 496 220 303 496 223 303 minecraft:black_concrete
fill 497 220 292 497 222 292 minecraft:black_concrete
fill 497 220 302 497 223 302 minecraft:black_concrete
fill 507 220 275 507 308 275 minecraft:deepslate_tiles
fill 507 220 300 507 221 301 minecraft:black_wool
setblock 512 220 296 minecraft:redstone_block
setblock 471 221 276 minecraft:light_gray_wool
fill 471 221 277 471 221 280 minecraft:white_wool
setblock 471 221 281 minecraft:light_gray_wool
fill 471 221 282 471 221 285 minecraft:white_wool
setblock 471 221 286 minecraft:light_gray_wool
fill 471 221 287 471 221 290 minecraft:white_wool
setblock 471 221 291 minecraft:light_gray_wool
fill 471 221 292 471 221 295 minecraft:white_wool
setblock 471 221 296 minecraft:light_gray_wool
fill 471 221 297 471 221 300 minecraft:white_wool
setblock 471 221 301 minecraft:light_gray_wool
fill 471 221 302 471 221 305 minecraft:white_wool
setblock 471 221 306 minecraft:light_gray_wool
fill 471 221 307 471 221 310 minecraft:white_wool
setblock 471 221 311 minecraft:light_gray_wool
fill 471 221 312 471 221 315 minecraft:white_wool
setblock 471 221 316 minecraft:light_gray_wool
fill 472 221 276 475 221 276 minecraft:white_wool
setblock 472 221 277 minecraft:light_gray_wool
fill 472 221 278 472 221 281 minecraft:white_wool
setblock 472 221 282 minecraft:light_gray_wool
fill 472 221 283 472 221 286 minecraft:white_wool
setblock 472 221 287 minecraft:light_gray_wool
fill 472 221 288 472 221 291 minecraft:white_wool
setblock 472 221 292 minecraft:light_gray_wool
fill 472 221 293 472 221 296 minecraft:white_wool
setblock 472 221 297 minecraft:light_gray_wool
fill 472 221 298 472 221 301 minecraft:white_wool
setblock 472 221 302 minecraft:light_gray_wool
fill 472 221 303 472 221 306 minecraft:white_wool
setblock 472 221 307 minecraft:light_gray_wool
fill 472 221 308 472 221 311 minecraft:white_wool
setblock 472 221 312 minecraft:light_gray_wool
fill 472 221 313 472 221 316 minecraft:white_wool
fill 473 221 277 476 221 277 minecraft:white_wool
setblock 473 221 278 minecraft:light_gray_wool
fill 473 221 279 473 221 282 minecraft:white_wool
setblock 473 221 283 minecraft:light_gray_wool
fill 473 221 284 473 221 287 minecraft:white_wool
setblock 473 221 288 minecraft:light_gray_wool
fill 473 221 289 473 221 292 minecraft:white_wool
setblock 473 221 293 minecraft:light_gray_wool
fill 473 221 294 473 221 297 minecraft:white_wool
setblock 473 221 298 minecraft:light_gray_wool
fill 473 221 299 473 221 302 minecraft:white_wool
setblock 473 221 303 minecraft:light_gray_wool
fill 473 221 304 473 221 307 minecraft:white_wool
setblock 473 221 308 minecraft:light_gray_wool
fill 473 221 309 473 221 312 minecraft:white_wool
setblock 473 221 313 minecraft:light_gray_wool
fill 473 221 314 473 221 316 minecraft:white_wool
fill 474 221 278 477 221 278 minecraft:white_wool
setblock 474 221 279 minecraft:light_gray_wool
fill 474 221 280 474 221 283 minecraft:white_wool
setblock 474 221 284 minecraft:light_gray_wool
fill 474 221 285 474 221 288 minecraft:white_wool
setblock 474 221 289 minecraft:light_gray_wool
fill 474 221 290 474 221 292 minecraft:white_wool
fill 474 221 295 474 221 298 minecraft:white_wool
setblock 474 221 299 minecraft:light_gray_wool
fill 474 221 300 474 221 303 minecraft:white_wool
setblock 474 221 304 minecraft:light_gray_wool
fill 474 221 305 474 221 308 minecraft:white_wool
setblock 474 221 309 minecraft:light_gray_wool
fill 474 221 310 474 221 313 minecraft:white_wool
setblock 474 221 314 minecraft:light_gray_wool
fill 474 221 315 474 221 316 minecraft:white_wool
fill 475 221 279 478 221 279 minecraft:white_wool
setblock 475 221 280 minecraft:light_gray_wool
fill 475 221 281 475 221 284 minecraft:white_wool
setblock 475 221 285 minecraft:light_gray_wool
fill 475 221 286 475 221 289 minecraft:white_wool
setblock 475 221 290 minecraft:light_gray_wool
fill 475 221 291 475 221 294 minecraft:white_wool
setblock 475 221 295 minecraft:light_gray_wool
fill 475 221 296 475 221 299 minecraft:white_wool
setblock 475 221 300 minecraft:light_gray_wool
fill 475 221 301 475 221 304 minecraft:white_wool
setblock 475 221 305 minecraft:light_gray_wool
fill 475 221 306 475 221 309 minecraft:white_wool
setblock 475 221 310 minecraft:light_gray_wool
fill 475 221 311 475 221 314 minecraft:white_wool
setblock 475 221 315 minecraft:light_gray_wool
setblock 475 221 316 minecraft:white_wool
setblock 476 221 276 minecraft:light_gray_wool
fill 476 221 280 479 221 280 minecraft:white_wool
setblock 476 221 281 minecraft:light_gray_wool
fill 476 221 282 476 221 285 minecraft:white_wool
setblock 476 221 286 minecraft:light_gray_wool
fill 476 221 287 476 221 290 minecraft:white_wool
setblock 476 221 291 minecraft:light_gray_wool
fill 476 221 292 476 221 295 minecraft:white_wool
setblock 476 221 296 minecraft:light_gray_wool
fill 476 221 297 476 221 300 minecraft:white_wool
setblock 476 221 301 minecraft:light_gray_wool
fill 476 221 302 476 221 305 minecraft:white_wool
fill 476 221 307 476 221 310 minecraft:white_wool
setblock 476 221 311 minecraft:light_gray_wool
fill 476 221 312 476 221 315 minecraft:white_wool
setblock 476 221 316 minecraft:light_gray_wool
fill 477 221 276 480 221 276 minecraft:white_wool
setblock 477 221 277 minecraft:light_gray_wool
fill 477 221 281 480 221 281 minecraft:white_wool
setblock 477 221 282 minecraft:light_gray_wool
fill 477 221 283 477 221 286 minecraft:white_wool
setblock 477 221 287 minecraft:light_gray_wool
fill 477 221 288 477 221 291 minecraft:white_wool
setblock 477 221 292 minecraft:light_gray_wool
fill 477 221 293 477 221 296 minecraft:white_wool
setblock 477 221 297 minecraft:light_gray_wool
fill 477 221 298 477 221 301 minecraft:white_wool
setblock 477 221 302 minecraft:light_gray_wool
fill 477 221 303 477 221 305 minecraft:white_wool
fill 477 221 306 477 226 306 minecraft:black_wool
setblock 477 221 307 minecraft:light_gray_wool
fill 477 221 308 477 221 311 minecraft:white_wool
setblock 477 221 312 minecraft:light_gray_wool
fill 477 221 313 477 221 316 minecraft:white_wool
fill 478 221 277 481 221 277 minecraft:white_wool
setblock 478 221 278 minecraft:light_gray_wool
fill 478 221 282 481 221 282 minecraft:white_wool
setblock 478 221 283 minecraft:light_gray_wool
fill 478 221 284 478 221 287 minecraft:white_wool
setblock 478 221 288 minecraft:light_gray_wool
fill 478 221 289 478 221 292 minecraft:white_wool
setblock 478 221 293 minecraft:light_gray_wool
fill 478 221 294 478 221 297 minecraft:white_wool
setblock 478 221 298 minecraft:light_gray_wool
fill 478 221 299 478 221 302 minecraft:white_wool
setblock 478 221 303 minecraft:light_gray_wool
fill 478 221 304 478 221 307 minecraft:white_wool
setblock 478 221 308 minecraft:light_gray_wool
fill 478 221 309 478 221 312 minecraft:white_wool
setblock 478 221 313 minecraft:light_gray_wool
fill 478 221 314 478 221 316 minecraft:white_wool
fill 479 221 278 482 221 278 minecraft:white_wool
setblock 479 221 279 minecraft:light_gray_wool
fill 479 221 283 480 221 283 minecraft:white_wool
setblock 479 221 284 minecraft:light_gray_wool
fill 479 221 285 479 221 288 minecraft:white_wool
setblock 479 221 289 minecraft:light_gray_wool
fill 479 221 290 479 221 293 minecraft:white_wool
setblock 479 221 294 minecraft:light_gray_wool
fill 479 221 295 479 221 298 minecraft:white_wool
setblock 479 221 299 minecraft:light_gray_wool
fill 479 221 300 479 221 303 minecraft:white_wool
setblock 479 221 304 minecraft:light_gray_wool
fill 479 221 305 479 221 308 minecraft:white_wool
setblock 479 221 309 minecraft:light_gray_wool
fill 479 221 310 479 221 313 minecraft:white_wool
setblock 479 221 314 minecraft:light_gray_wool
fill 479 221 315 479 221 316 minecraft:white_wool
fill 480 221 279 483 221 279 minecraft:white_wool
setblock 480 221 280 minecraft:light_gray_wool
fill 480 221 284 483 221 284 minecraft:white_wool
setblock 480 221 285 minecraft:light_gray_wool
fill 480 221 286 480 221 289 minecraft:white_wool
setblock 480 221 290 minecraft:light_gray_wool
fill 480 221 291 480 221 294 minecraft:white_wool
setblock 480 221 295 minecraft:light_gray_wool
fill 480 221 296 480 221 299 minecraft:white_wool
setblock 480 221 300 minecraft:light_gray_wool
fill 480 221 301 480 221 304 minecraft:white_wool
setblock 480 221 305 minecraft:light_gray_wool
fill 480 221 306 480 221 309 minecraft:white_wool
setblock 480 221 310 minecraft:light_gray_wool
fill 480 221 311 480 221 314 minecraft:white_wool
setblock 480 221 315 minecraft:light_gray_wool
setblock 480 221 316 minecraft:white_wool
setblock 481 221 276 minecraft:light_gray_wool
fill 481 221 280 484 221 280 minecraft:white_wool
setblock 481 221 281 minecraft:light_gray_wool
fill 481 221 285 484 221 285 minecraft:white_wool
setblock 481 221 286 minecraft:light_gray_wool
fill 481 221 287 481 221 290 minecraft:white_wool
setblock 481 221 291 minecraft:light_gray_wool
fill 481 221 292 481 221 295 minecraft:white_wool
setblock 481 221 296 minecraft:light_gray_wool
fill 481 221 297 481 221 300 minecraft:white_wool
setblock 481 221 301 minecraft:light_gray_wool
fill 481 221 302 481 221 305 minecraft:white_wool
setblock 481 221 306 minecraft:light_gray_wool
fill 481 221 307 481 221 310 minecraft:white_wool
setblock 481 221 311 minecraft:light_gray_wool
fill 481 221 312 481 221 315 minecraft:white_wool
setblock 481 221 316 minecraft:light_gray_wool
fill 482 221 276 485 221 276 minecraft:white_wool
setblock 482 221 277 minecraft:light_gray_wool
fill 482 221 281 485 221 281 minecraft:white_wool
setblock 482 221 282 minecraft:light_gray_wool
setblock 482 221 283 minecraft:white_wool
fill 482 221 286 485 221 286 minecraft:white_wool
setblock 482 221 287 minecraft:light_gray_wool
fill 482 221 288 482 221 291 minecraft:white_wool
setblock 482 221 292 minecraft:light_gray_wool
fill 482 221 293 482 221 296 minecraft:white_wool
setblock 482 221 297 minecraft:light_gray_wool
fill 482 221 298 482 221 301 minecraft:white_wool
setblock 482 221 302 minecraft:light_gray_wool
fill 482 221 303 482 221 306 minecraft:white_wool
setblock 482 221 307 minecraft:light_gray_wool
fill 482 221 308 482 221 311 minecraft:white_wool
setblock 482 221 312 minecraft:light_gray_wool
fill 482 221 313 482 221 316 minecraft:white_wool
fill 483 221 277 486 221 277 minecraft:white_wool
setblock 483 221 278 minecraft:light_gray_wool
fill 483 221 282 486 221 282 minecraft:white_wool
setblock 483 221 283 minecraft:light_gray_wool
fill 483 221 287 486 221 287 minecraft:white_wool
setblock 483 221 288 minecraft:light_gray_wool
fill 483 221 289 483 221 292 minecraft:white_wool
setblock 483 221 293 minecraft:light_gray_wool
fill 483 221 301 483 221 302 minecraft:white_wool
setblock 483 221 303 minecraft:light_gray_wool
fill 483 221 304 483 221 307 minecraft:white_wool
setblock 483 221 308 minecraft:light_gray_wool
fill 483 221 309 483 221 312 minecraft:white_wool
setblock 483 221 313 minecraft:light_gray_wool
fill 483 221 314 483 221 316 minecraft:white_wool
fill 484 221 278 487 221 278 minecraft:white_wool
setblock 484 221 279 minecraft:light_gray_wool
fill 484 221 283 487 221 283 minecraft:white_wool
setblock 484 221 284 minecraft:light_gray_wool
fill 484 221 288 487 221 288 minecraft:white_wool
setblock 484 221 289 minecraft:light_gray_wool
fill 484 221 290 484 221 291 minecraft:white_wool
setblock 484 221 303 minecraft:white_wool
setblock 484 221 304 minecraft:light_gray_wool
fill 484 221 305 484 221 308 minecraft:white_wool
setblock 484 221 309 minecraft:light_gray_wool
fill 484 221 310 484 221 313 minecraft:white_wool
setblock 484 221 314 minecraft:light_gray_wool
fill 484 221 315 484 221 316 minecraft:white_wool
fill 485 221 279 488 221 279 minecraft:white_wool
setblock 485 221 280 minecraft:light_gray_wool
fill 485 221 284 488 221 284 minecraft:white_wool
setblock 485 221 285 minecraft:light_gray_wool
fill 485 221 289 487 221 289 minecraft:white_wool
setblock 485 221 290 minecraft:light_gray_wool
setblock 485 221 304 minecraft:white_wool
setblock 485 221 305 minecraft:light_gray_wool
fill 485 221 306 485 221 309 minecraft:white_wool
setblock 485 221 310 minecraft:light_gray_wool
fill 485 221 311 485 221 314 minecraft:white_wool
setblock 485 221 315 minecraft:light_gray_wool
setblock 485 221 316 minecraft:white_wool
setblock 486 221 276 minecraft:light_gray_wool
fill 486 221 280 489 221 280 minecraft:white_wool
setblock 486 221 281 minecraft:light_gray_wool
fill 486 221 285 489 221 285 minecraft:white_wool
setblock 486 221 286 minecraft:light_gray_wool
fill 486 221 305 487 221 305 minecraft:white_wool
setblock 486 221 306 minecraft:light_gray_wool
fill 486 221 307 486 221 310 minecraft:white_wool
setblock 486 221 311 minecraft:light_gray_wool
fill 486 221 312 486 221 315 minecraft:white_wool
setblock 486 221 316 minecraft:light_gray_wool
fill 487 221 276 490 221 276 minecraft:white_wool
setblock 487 221 277 minecraft:light_gray_wool
fill 487 221 281 490 221 281 minecraft:white_wool
setblock 487 221 282 minecraft:light_gray_wool
fill 487 221 286 490 221 286 minecraft:white_wool
setblock 487 221 287 minecraft:light_gray_wool
fill 487 221 306 490 221 306 minecraft:white_wool
setblock 487 221 307 minecraft:light_gray_wool
fill 487 221 308 487 221 311 minecraft:white_wool
setblock 487 221 312 minecraft:light_gray_wool
fill 487 221 313 487 225 313 minecraft:black_wool
fill 487 221 315 489 221 316 minecraft:white_wool
fill 488 221 277 491 221 277 minecraft:white_wool
setblock 488 221 278 minecraft:light_gray_wool
fill 488 221 282 491 221 282 minecraft:white_wool
setblock 488 221 283 minecraft:light_gray_wool
fill 488 221 287 491 221 287 minecraft:white_wool
setblock 488 221 288 minecraft:light_gray_wool
fill 488 221 289 488 222 289 minecraft:black_concrete
fill 488 221 305 488 222 305 minecraft:black_concrete
fill 488 221 307 491 221 307 minecraft:white_wool
setblock 488 221 308 minecraft:light_gray_wool
fill 488 221 309 488 221 312 minecraft:white_wool
setblock 488 221 313 minecraft:light_gray_wool
setblock 488 221 314 minecraft:white_wool
fill 489 221 278 492 221 278 minecraft:white_wool
setblock 489 221 279 minecraft:light_gray_wool
fill 489 221 283 492 221 283 minecraft:white_wool
setblock 489 221 284 minecraft:light_gray_wool
fill 489 221 288 492 221 288 minecraft:white_wool
fill 489 221 308 492 221 308 minecraft:white_wool
setblock 489 221 309 minecraft:light_gray_wool
fill 489 221 310 489 221 313 minecraft:white_wool
setblock 489 221 314 minecraft:light_gray_wool
fill 490 221 279 493 221 279 minecraft:white_wool
setblock 490 221 280 minecraft:light_gray_wool
fill 490 221 284 493 221 284 minecraft:white_wool
setblock 490 221 285 minecraft:light_gray_wool
fill 490 221 309 493 221 309 minecraft:white_wool
setblock 490 221 310 minecraft:light_gray_wool
fill 490 221 311 490 221 314 minecraft:white_wool
setblock 490 221 315 minecraft:light_gray_wool
setblock 490 221 316 minecraft:white_wool
setblock 491 221 276 minecraft:light_gray_wool
fill 491 221 280 493 221 280 minecraft:white_wool
setblock 491 221 281 minecraft:light_gray_wool
fill 491 221 285 494 221 285 minecraft:white_wool
setblock 491 221 286 minecraft:light_gray_wool
setblock 491 221 306 minecraft:light_gray_wool
fill 491 221 310 494 221 310 minecraft:white_wool
setblock 491 221 311 minecraft:light_gray_wool
fill 491 221 312 491 221 315 minecraft:white_wool
setblock 491 221 316 minecraft:light_gray_wool
fill 492 221 276 495 221 276 minecraft:white_wool
setblock 492 221 277 minecraft:light_gray_wool
fill 492 221 281 493 221 281 minecraft:white_wool
setblock 492 221 282 minecraft:light_gray_wool
fill 492 221 286 495 221 286 minecraft:white_wool
setblock 492 221 287 minecraft:light_gray_wool
fill 492 221 306 495 221 306 minecraft:white_wool
setblock 492 221 307 minecraft:light_gray_wool
fill 492 221 311 495 221 311 minecraft:white_wool
setblock 492 221 312 minecraft:light_gray_wool
fill 492 221 313 492 221 316 minecraft:white_wool
fill 493 221 277 496 221 277 minecraft:white_wool
setblock 493 221 278 minecraft:light_gray_wool
fill 493 221 282 496 221 282 minecraft:white_wool
setblock 493 221 283 minecraft:light_gray_wool
fill 493 221 287 496 221 287 minecraft:white_wool
setblock 493 221 288 minecraft:light_gray_wool
fill 493 221 289 493 222 289 minecraft:black_concrete
fill 493 221 305 493 222 305 minecraft:black_concrete
fill 493 221 307 496 221 307 minecraft:white_wool
setblock 493 221 308 minecraft:light_gray_wool
fill 493 221 312 496 221 312 minecraft:white_wool
setblock 493 221 313 minecraft:light_gray_wool
fill 493 221 314 493 221 316 minecraft:white_wool
fill 494 221 278 497 221 278 minecraft:white_wool
setblock 494 221 279 minecraft:light_gray_wool
fill 494 221 281 494 225 281 minecraft:black_wool
fill 494 221 283 497 221 283 minecraft:white_wool
setblock 494 221 284 minecraft:light_gray_wool
fill 494 221 288 497 221 288 minecraft:white_wool
setblock 494 221 289 minecraft:light_gray_wool
setblock 494 221 305 minecraft:white_wool
fill 494 221 308 497 221 308 minecraft:white_wool
setblock 494 221 309 minecraft:light_gray_wool
fill 494 221 313 497 221 313 minecraft:white_wool
setblock 494 221 314 minecraft:light_gray_wool
fill 494 221 315 494 221 316 minecraft:white_wool
fill 495 221 279 498 221 279 minecraft:white_wool
setblock 495 221 280 minecraft:light_gray_wool
setblock 495 221 281 minecraft:white_wool
fill 495 221 284 498 221 284 minecraft:white_wool
setblock 495 221 285 minecraft:light_gray_wool
fill 495 221 289 498 221 289 minecraft:white_wool
setblock 495 221 305 minecraft:light_gray_wool
fill 495 221 309 498 221 309 minecraft:white_wool
setblock 495 221 310 minecraft:light_gray_wool
fill 495 221 314 498 221 314 minecraft:white_wool
setblock 495 221 315 minecraft:light_gray_wool
setblock 495 221 316 minecraft:white_wool
setblock 496 221 276 minecraft:light_gray_wool
fill 496 221 280 499 221 280 minecraft:white_wool
setblock 496 221 281 minecraft:light_gray_wool
fill 496 221 285 499 221 285 minecraft:white_wool
setblock 496 221 286 minecraft:light_gray_wool
fill 496 221 290 499 221 290 minecraft:white_wool
fill 496 221 304 498 221 305 minecraft:white_wool
setblock 496 221 306 minecraft:light_gray_wool
fill 496 221 310 499 221 310 minecraft:white_wool
setblock 496 221 311 minecraft:light_gray_wool
fill 496 221 315 499 221 315 minecraft:white_wool
setblock 496 221 316 minecraft:light_gray_wool
fill 497 221 276 500 221 276 minecraft:white_wool
setblock 497 221 277 minecraft:light_gray_wool
fill 497 221 281 500 221 281 minecraft:white_wool
setblock 497 221 282 minecraft:light_gray_wool
fill 497 221 286 500 221 286 minecraft:white_wool
setblock 497 221 287 minecraft:light_gray_wool
fill 497 221 291 500 221 291 minecraft:white_wool
setblock 497 221 303 minecraft:white_wool
fill 497 221 306 500 221 306 minecraft:white_wool
setblock 497 221 307 minecraft:light_gray_wool
fill 497 221 311 499 221 311 minecraft:white_wool
setblock 497 221 312 minecraft:light_gray_wool
fill 497 221 316 500 221 316 minecraft:white_wool
fill 498 221 277 501 221 277 minecraft:white_wool
setblock 498 221 278 minecraft:light_gray_wool
fill 498 221 282 501 221 282 minecraft:white_wool
setblock 498 221 283 minecraft:light_gray_wool
fill 498 221 287 501 221 287 minecraft:white_wool
setblock 498 221 288 minecraft:light_gray_wool
fill 498 221 292 501 221 292 minecraft:white_wool
setblock 498 221 293 minecraft:light_gray_wool
fill 498 221 301 500 221 302 minecraft:white_wool
setblock 498 221 303 minecraft:light_gray_wool
fill 498 221 307 501 221 307 minecraft:white_wool
setblock 498 221 308 minecraft:light_gray_wool
fill 498 221 312 501 221 312 minecraft:white_wool
setblock 498 221 313 minecraft:light_gray_wool
fill 499 221 278 502 221 278 minecraft:white_wool
setblock 499 221 279 minecraft:light_gray_wool
fill 499 221 283 502 221 283 minecraft:white_wool
setblock 499 221 284 minecraft:light_gray_wool
fill 499 221 288 502 221 288 minecraft:white_wool
setblock 499 221 289 minecraft:light_gray_wool
fill 499 221 293 502 221 293 minecraft:white_wool
setblock 499 221 294 minecraft:light_gray_wool
fill 499 221 295 499 221 298 minecraft:white_wool
setblock 499 221 299 minecraft:light_gray_wool
setblock 499 221 300 minecraft:white_wool
fill 499 221 303 502 221 303 minecraft:white_wool
setblock 499 221 304 minecraft:light_gray_wool
setblock 499 221 305 minecraft:white_wool
fill 499 221 308 502 221 308 minecraft:white_wool
setblock 499 221 309 minecraft:light_gray_wool
fill 499 221 313 502 221 313 minecraft:white_wool
setblock 499 221 314 minecraft:light_gray_wool
fill 500 221 279 503 221 279 minecraft:white_wool
setblock 500 221 280 minecraft:light_gray_wool
fill 500 221 284 503 221 284 minecraft:white_wool
setblock 500 221 285 minecraft:light_gray_wool
fill 500 221 289 503 221 289 minecraft:white_wool
setblock 500 221 290 minecraft:light_gray_wool
fill 500 221 294 503 221 294 minecraft:white_wool
setblock 500 221 295 minecraft:light_gray_wool
fill 500 221 296 500 221 299 minecraft:white_wool
setblock 500 221 300 minecraft:light_gray_wool
fill 500 221 304 503 221 304 minecraft:white_wool
setblock 500 221 305 minecraft:light_gray_wool
fill 500 221 309 503 221 309 minecraft:white_wool
setblock 500 221 310 minecraft:light_gray_wool
fill 500 221 314 503 221 314 minecraft:white_wool
setblock 500 221 315 minecraft:light_gray_wool
setblock 501 221 276 minecraft:light_gray_wool
fill 501 221 280 504 221 280 minecraft:white_wool
setblock 501 221 281 minecraft:light_gray_wool
fill 501 221 285 504 221 285 minecraft:white_wool
setblock 501 221 286 minecraft:light_gray_wool
fill 501 221 290 504 221 290 minecraft:white_wool
setblock 501 221 291 minecraft:light_gray_wool
fill 501 221 295 504 221 295 minecraft:white_wool
setblock 501 221 296 minecraft:light_gray_wool
fill 501 221 297 501 221 300 minecraft:white_wool
setblock 501 221 301 minecraft:light_gray_wool
setblock 501 221 302 minecraft:white_wool
fill 501 221 305 504 221 305 minecraft:white_wool
setblock 501 221 306 minecraft:light_gray_wool
fill 501 221 310 504 221 310 minecraft:white_wool
setblock 501 221 311 minecraft:light_gray_wool
fill 501 221 315 504 221 315 minecraft:white_wool
setblock 501 221 316 minecraft:light_gray_wool
fill 502 221 276 505 221 276 minecraft:white_wool
setblock 502 221 277 minecraft:light_gray_wool
fill 502 221 281 505 221 281 minecraft:white_wool
setblock 502 221 282 minecraft:light_gray_wool
fill 502 221 286 505 221 286 minecraft:white_wool
setblock 502 221 287 minecraft:light_gray_wool
fill 502 221 291 505 221 291 minecraft:white_wool
setblock 502 221 292 minecraft:light_gray_wool
fill 502 221 296 505 221 296 minecraft:white_wool
setblock 502 221 297 minecraft:light_gray_wool
fill 502 221 298 502 221 301 minecraft:white_wool
setblock 502 221 302 minecraft:light_gray_wool
fill 502 221 306 505 221 306 minecraft:white_wool
setblock 502 221 307 minecraft:light_gray_wool
fill 502 221 311 505 221 311 minecraft:white_wool
setblock 502 221 312 minecraft:light_gray_wool
fill 502 221 316 505 221 316 minecraft:white_wool
fill 503 221 277 506 221 277 minecraft:white_wool
setblock 503 221 278 minecraft:light_gray_wool
fill 503 221 282 506 221 282 minecraft:white_wool
setblock 503 221 283 minecraft:light_gray_wool
fill 503 221 287 506 221 287 minecraft:white_wool
setblock 503 221 288 minecraft:light_gray_wool
fill 503 221 292 506 221 292 minecraft:white_wool
setblock 503 221 293 minecraft:light_gray_wool
fill 503 221 297 506 221 297 minecraft:white_wool
setblock 503 221 298 minecraft:light_gray_wool
fill 503 221 299 503 221 302 minecraft:white_wool
setblock 503 221 303 minecraft:light_gray_wool
fill 503 221 307 506 221 307 minecraft:white_wool
setblock 503 221 308 minecraft:light_gray_wool
fill 503 221 312 506 221 312 minecraft:white_wool
setblock 503 221 313 minecraft:light_gray_wool
fill 504 221 278 507 221 278 minecraft:white_wool
setblock 504 221 279 minecraft:light_gray_wool
fill 504 221 283 507 221 283 minecraft:white_wool
setblock 504 221 284 minecraft:light_gray_wool
fill 504 221 288 504 226 288 minecraft:black_wool
setblock 504 221 289 minecraft:light_gray_wool
fill 504 221 293 507 221 293 minecraft:white_wool
setblock 504 221 294 minecraft:light_gray_wool
fill 504 221 298 507 221 298 minecraft:white_wool
setblock 504 221 299 minecraft:light_gray_wool
fill 504 221 300 504 221 303 minecraft:white_wool
setblock 504 221 304 minecraft:light_gray_wool
fill 504 221 308 507 221 308 minecraft:white_wool
setblock 504 221 309 minecraft:light_gray_wool
fill 504 221 313 507 221 313 minecraft:white_wool
setblock 504 221 314 minecraft:light_gray_wool
fill 505 221 279 508 221 279 minecraft:white_wool
setblock 505 221 280 minecraft:light_gray_wool
fill 505 221 284 508 221 284 minecraft:white_wool
setblock 505 221 285 minecraft:light_gray_wool
fill 505 221 289 508 221 289 minecraft:white_wool
setblock 505 221 290 minecraft:light_gray_wool
fill 505 221 294 508 221 294 minecraft:white_wool
setblock 505 221 295 minecraft:light_gray_wool
fill 505 221 299 508 221 299 minecraft:white_wool
setblock 505 221 300 minecraft:light_gray_wool
fill 505 221 301 505 221 304 minecraft:white_wool
setblock 505 221 305 minecraft:light_gray_wool
fill 505 221 309 508 221 309 minecraft:white_wool
setblock 505 221 310 minecraft:light_gray_wool
fill 505 221 314 508 221 314 minecraft:white_wool
setblock 505 221 315 minecraft:light_gray_wool
setblock 506 221 276 minecraft:light_gray_wool
fill 506 221 280 509 221 280 minecraft:white_wool
setblock 506 221 281 minecraft:light_gray_wool
fill 506 221 285 509 221 285 minecraft:white_wool
setblock 506 221 286 minecraft:light_gray_wool
fill 506 221 288 507 221 288 minecraft:white_wool
fill 506 221 290 509 221 290 minecraft:white_wool
setblock 506 221 291 minecraft:light_gray_wool
fill 506 221 295 509 221 295 minecraft:white_wool
setblock 506 221 296 minecraft:light_gray_wool
setblock 506 221 300 minecraft:white_wool
setblock 506 221 301 minecraft:light_gray_wool
fill 506 221 302 506 221 305 minecraft:white_wool
setblock 506 221 306 minecraft:light_gray_wool
fill 506 221 310 509 221 310 minecraft:white_wool
setblock 506 221 311 minecraft:light_gray_wool
fill 506 221 315 509 221 315 minecraft:white_wool
setblock 506 221 316 minecraft:light_gray_wool
fill 507 221 276 510 221 276 minecraft:white_wool
setblock 507 221 277 minecraft:light_gray_wool
fill 507 221 281 510 221 281 minecraft:white_wool
setblock 507 221 282 minecraft:light_gray_wool
fill 507 221 286 510 221 286 minecraft:white_wool
setblock 507 221 287 minecraft:light_gray_wool
fill 507 221 291 510 221 291 minecraft:white_wool
setblock 507 221 292 minecraft:light_gray_wool
fill 507 221 296 510 221 296 minecraft:white_wool
setblock 507 221 297 minecraft:light_gray_wool
setblock 507 221 302 minecraft:light_gray_wool
fill 507 221 303 507 221 306 minecraft:white_wool
setblock 507 221 307 minecraft:light_gray_wool
fill 507 221 311 510 221 311 minecraft:white_wool
setblock 507 221 312 minecraft:light_gray_wool
fill 507 221 316 510 221 316 minecraft:white_wool
fill 508 221 277 511 221 277 minecraft:white_wool
setblock 508 221 278 minecraft:light_gray_wool
fill 508 221 282 511 221 282 minecraft:white_wool
setblock 508 221 283 minecraft:light_gray_wool
fill 508 221 287 511 221 287 minecraft:white_wool
setblock 508 221 288 minecraft:light_gray_wool
fill 508 221 292 511 221 292 minecraft:white_wool
setblock 508 221 293 minecraft:light_gray_wool
fill 508 221 297 511 221 297 minecraft:white_wool
setblock 508 221 298 minecraft:light_gray_wool
fill 508 221 300 509 221 302 minecraft:white_wool
setblock 508 221 303 minecraft:light_gray_wool
fill 508 221 304 508 221 307 minecraft:white_wool
setblock 508 221 308 minecraft:light_gray_wool
fill 508 221 312 511 221 312 minecraft:white_wool
setblock 508 221 313 minecraft:light_gray_wool
fill 509 221 278 511 221 278 minecraft:white_wool
setblock 509 221 279 minecraft:light_gray_wool
fill 509 221 283 511 221 283 minecraft:white_wool
setblock 509 221 284 minecraft:light_gray_wool
fill 509 221 288 511 221 288 minecraft:white_wool
setblock 509 221 289 minecraft:light_gray_wool
fill 509 221 293 511 221 293 minecraft:white_wool
setblock 509 221 294 minecraft:light_gray_wool
fill 509 221 298 511 221 298 minecraft:white_wool
setblock 509 221 299 minecraft:light_gray_wool
fill 509 221 303 511 221 303 minecraft:white_wool
setblock 509 221 304 minecraft:light_gray_wool
fill 509 221 305 509 221 308 minecraft:white_wool
setblock 509 221 309 minecraft:light_gray_wool
fill 509 221 313 511 221 313 minecraft:white_wool
setblock 509 221 314 minecraft:light_gray_wool
fill 510 221 279 511 221 279 minecraft:white_wool
setblock 510 221 280 minecraft:light_gray_wool
fill 510 221 284 511 221 284 minecraft:white_wool
setblock 510 221 285 minecraft:light_gray_wool
fill 510 221 289 511 221 289 minecraft:white_wool
setblock 510 221 290 minecraft:light_gray_wool
fill 510 221 294 511 221 294 minecraft:white_wool
setblock 510 221 295 minecraft:light_gray_wool
fill 510 221 299 511 221 299 minecraft:white_wool
setblock 510 221 300 minecraft:light_gray_wool
fill 510 221 301 510 221 302 minecraft:white_wool
fill 510 221 304 511 221 304 minecraft:white_wool
setblock 510 221 305 minecraft:light_gray_wool
fill 510 221 306 510 221 309 minecraft:white_wool
setblock 510 221 310 minecraft:light_gray_wool
fill 510 221 314 511 221 314 minecraft:white_wool
setblock 510 221 315 minecraft:light_gray_wool
setblock 511 221 276 minecraft:light_gray_wool
setblock 511 221 280 minecraft:white_wool
setblock 511 221 281 minecraft:light_gray_wool
setblock 511 221 285 minecraft:white_wool
setblock 511 221 286 minecraft:light_gray_wool
setblock 511 221 290 minecraft:white_wool
setblock 511 221 291 minecraft:light_gray_wool
setblock 511 221 295 minecraft:white_wool
setblock 511 221 296 minecraft:light_gray_wool
setblock 511 221 300 minecraft:white_wool
setblock 511 221 301 minecraft:light_gray_wool
setblock 511 221 302 minecraft:white_wool
setblock 511 221 305 minecraft:white_wool
setblock 511 221 306 minecraft:light_gray_wool
fill 511 221 307 511 221 310 minecraft:white_wool
setblock 511 221 311 minecraft:light_gray_wool
setblock 511 221 315 minecraft:white_wool
setblock 511 221 316 minecraft:light_gray_wool
fill 512 221 296 512 308 296 minecraft:deepslate_tiles
setblock 512 221 315 minecraft:redstone_block
fill 474 222 294 474 223 294 minecraft:black_wool
fill 482 222 283 482 223 283 minecraft:black_wool
fill 499 222 311 499 223 311 minecraft:black_wool
fill 499 222 317 501 242 317 minecraft:deepslate_tiles
setblock 502 222 317 minecraft:redstone_block
fill 505 222 275 505 308 275 minecraft:deepslate_tiles
setblock 506 222 275 minecraft:redstone_block
fill 507 222 300 507 223 300 minecraft:black_wool
fill 512 222 315 512 308 315 minecraft:deepslate_tiles
setblock 470 223 281 minecraft:redstone_block
setblock 473 223 278 minecraft:light[level=12]
setblock 473 223 285 minecraft:light[level=12]
setblock 473 223 292 minecraft:light[level=12]
setblock 473 223 299 minecraft:light[level=12]
setblock 473 223 306 minecraft:light[level=12]
setblock 473 223 313 minecraft:light[level=12]
fill 475 223 294 475 228 294 minecraft:black_wool
setblock 480 223 278 minecraft:light[level=12]
setblock 480 223 285 minecraft:light[level=12]
setblock 480 223 292 minecraft:light[level=12]
setblock 480 223 299 minecraft:light[level=12]
setblock 480 223 306 minecraft:light[level=12]
setblock 480 223 313 minecraft:light[level=12]
fill 482 223 295 483 223 296 minecraft:black_wool
fill 483 223 294 483 224 294 minecraft:black_concrete
fill 483 223 297 483 225 298 minecraft:black_concrete
fill 483 223 301 484 223 302 minecraft:black_wool
fill 485 223 290 486 224 290 minecraft:black_wool
setblock 486 223 291 minecraft:black_wool
setblock 487 223 278 minecraft:light[level=12]
setblock 487 223 285 minecraft:light[level=12]
setblock 487 223 306 minecraft:light[level=12]
fill 488 223 305 489 223 305 minecraft:black_wool
fill 489 223 290 491 226 290 minecraft:black_concrete
setblock 489 223 304 minecraft:black_wool
fill 489 223 306 489 224 306 minecraft:black_wool
fill 490 223 304 492 225 304 minecraft:black_concrete
fill 492 223 288 492 223 290 minecraft:black_wool
setblock 493 223 289 minecraft:black_wool
setblock 494 223 278 minecraft:light[level=12]
setblock 494 223 285 minecraft:light[level=12]
setblock 494 223 306 minecraft:light[level=12]
setblock 494 223 313 minecraft:light[level=12]
fill 495 223 303 495 223 304 minecraft:black_wool
fill 496 223 304 496 224 304 minecraft:black_wool
fill 497 223 292 498 223 293 minecraft:black_wool
fill 498 223 296 498 225 297 minecraft:black_concrete
fill 498 223 298 499 223 299 minecraft:black_wool
fill 498 223 300 498 224 300 minecraft:black_concrete
setblock 501 223 278 minecraft:light[level=12]
setblock 501 223 285 minecraft:light[level=12]
setblock 501 223 292 minecraft:light[level=12]
setblock 501 223 299 minecraft:light[level=12]
setblock 501 223 306 minecraft:light[level=12]
setblock 501 223 313 minecraft:light[level=12]
fill 502 223 317 502 308 317 minecraft:deepslate_tiles
fill 506 223 275 506 308 275 minecraft:deepslate_tiles
fill 506 223 300 506 228 300 minecraft:black_wool
setblock 508 223 278 minecraft:light[level=12]
setblock 508 223 285 minecraft:light[level=12]
setblock 508 223 292 minecraft:light[level=12]
setblock 508 223 299 minecraft:light[level=12]
setblock 508 223 306 minecraft:light[level=12]
setblock 508 223 313 minecraft:light[level=12]
fill 470 224 281 470 234 281 minecraft:deepslate_tiles
fill 480 224 295 482 224 295 minecraft:black_wool
fill 482 224 284 482 228 284 minecraft:black_wool
setblock 482 224 296 minecraft:black_wool
fill 482 224 302 483 224 303 minecraft:black_wool
fill 483 224 295 483 224 296 minecraft:black_concrete
fill 484 224 301 484 225 301 minecraft:black_concrete
fill 485 224 288 485 225 289 minecraft:black_wool
setblock 486 224 289 minecraft:black_wool
fill 486 224 291 486 225 291 minecraft:black_concrete
fill 488 224 306 488 224 307 minecraft:black_wool
fill 489 224 304 489 225 304 minecraft:black_concrete
setblock 489 224 305 minecraft:black_wool
fill 489 224 307 489 225 307 minecraft:black_wool
fill 492 224 287 492 224 289 minecraft:black_wool
fill 492 224 290 492 226 290 minecraft:black_concrete
fill 493 224 287 493 224 288 minecraft:black_wool
fill 495 224 303 495 225 303 minecraft:black_concrete
fill 495 224 304 495 224 305 minecraft:black_wool
fill 496 224 305 496 225 306 minecraft:black_wool
fill 497 224 293 497 225 293 minecraft:black_concrete
fill 498 224 291 499 224 292 minecraft:black_wool
fill 498 224 298 498 224 299 minecraft:black_concrete
fill 499 224 298 499 224 299 minecraft:black_wool
fill 499 224 310 499 228 310 minecraft:black_wool
fill 500 224 299 501 225 299 minecraft:black_wool
fill 479 225 295 481 225 295 minecraft:black_wool
setblock 480 225 294 minecraft:black_wool
fill 481 225 303 481 226 304 minecraft:black_wool
fill 482 225 302 482 225 303 minecraft:black_wool
setblock 483 225 296 minecraft:black_concrete
fill 484 225 287 484 226 288 minecraft:black_wool
fill 487 225 312 487 228 312 minecraft:black_wool
fill 488 225 307 488 225 309 minecraft:black_wool
setblock 489 225 308 minecraft:black_wool
fill 492 225 286 493 225 287 minecraft:black_wool
fill 493 225 285 493 227 285 minecraft:black_wool
fill 494 225 282 494 228 282 minecraft:black_wool
fill 497 225 306 497 226 307 minecraft:black_wool
setblock 498 225 298 minecraft:black_concrete
fill 499 225 291 499 225 292 minecraft:black_wool
fill 500 225 290 500 226 291 minecraft:black_wool
setblock 501 225 300 minecraft:black_wool
fill 502 225 299 502 226 299 minecraft:black_wool
fill 472 226 317 472 308 317 minecraft:deepslate_tiles
setblock 473 226 317 minecraft:redstone_block
fill 478 226 294 479 226 295 minecraft:black_wool
fill 478 226 306 478 228 306 minecraft:black_wool
fill 479 226 304 480 227 304 minecraft:black_wool
setblock 480 226 295 minecraft:black_wool
setblock 480 226 303 minecraft:black_wool
fill 483 226 286 483 226 287 minecraft:black_wool
fill 484 226 286 484 227 286 minecraft:black_wool
setblock 487 226 303 minecraft:black_concrete
fill 488 226 303 489 227 304 minecraft:redstone_block
fill 488 226 308 488 226 310 minecraft:black_wool
fill 488 226 312 488 228 312 minecraft:black_wool
fill 490 226 303 491 226 304 minecraft:black_concrete
fill 492 226 303 493 227 304 minecraft:redstone_block
fill 493 226 282 493 228 282 minecraft:black_wool
fill 493 226 284 493 227 284 minecraft:black_wool
setblock 493 226 286 minecraft:black_wool
setblock 494 226 303 minecraft:black_concrete
fill 497 226 308 498 227 308 minecraft:black_wool
setblock 498 226 307 minecraft:black_wool
fill 501 226 290 501 226 291 minecraft:black_wool
setblock 501 226 299 minecraft:black_wool
fill 502 226 290 502 227 290 minecraft:black_wool
fill 502 226 300 503 226 300 minecraft:black_wool
fill 503 226 288 503 228 288 minecraft:black_wool
fill 503 226 299 503 227 299 minecraft:black_wool
fill 473 227 317 473 308 317 minecraft:deepslate_tiles
fill 476 227 294 478 227 294 minecraft:black_wool
fill 477 227 275 477 308 275 minecraft:deepslate_tiles
fill 477 227 295 478 227 295 minecraft:black_wool
setblock 478 227 275 minecraft:redstone_block
fill 478 227 305 479 228 305 minecraft:black_wool
fill 482 227 285 483 228 285 minecraft:black_wool
setblock 483 227 286 minecraft:black_wool
fill 487 227 310 488 227 311 minecraft:black_wool
setblock 488 227 309 minecraft:black_wool
fill 490 227 303 491 227 303 minecraft:black_concrete
fill 493 227 283 494 228 283 minecraft:black_wool
setblock 494 227 284 minecraft:black_wool
fill 498 227 309 499 228 309 minecraft:black_wool
setblock 501 227 290 minecraft:black_wool
fill 502 227 289 503 228 289 minecraft:black_wool
fill 503 227 300 505 227 300 minecraft:black_wool
setblock 504 227 299 minecraft:black_wool
setblock 470 228 309 minecraft:white_wool
fill 471 228 276 474 228 316 minecraft:black_stained_glass
fill 475 228 276 477 228 293 minecraft:black_stained_glass
fill 475 228 295 476 228 316 minecraft:black_stained_glass
fill 476 228 294 477 228 294 minecraft:black_wool
fill 477 228 295 477 228 297 minecraft:black_stained_glass
fill 477 228 298 485 229 298 minecraft:iron_block
fill 477 228 299 477 228 316 minecraft:black_stained_glass
fill 478 228 275 478 308 275 minecraft:deepslate_tiles
fill 478 228 276 478 228 292 minecraft:black_stained_glass
fill 478 228 293 502 229 293 minecraft:iron_block
fill 478 228 294 478 228 296 minecraft:black_stained_glass
fill 478 228 297 478 229 297 minecraft:iron_block
fill 478 228 299 478 229 299 minecraft:iron_block
fill 478 228 300 478 228 302 minecraft:black_stained_glass
fill 478 228 303 502 229 303 minecraft:iron_block
setblock 478 228 304 minecraft:black_stained_glass
fill 478 228 307 481 228 316 minecraft:black_stained_glass
fill 479 228 276 481 228 291 minecraft:black_stained_glass
fill 479 228 292 501 229 292 minecraft:iron_block
fill 479 228 294 489 229 294 minecraft:iron_block
fill 479 228 295 479 228 297 minecraft:black_stained_glass
fill 479 228 299 479 228 301 minecraft:black_stained_glass
fill 479 228 302 489 229 302 minecraft:iron_block
fill 479 228 304 501 229 304 minecraft:iron_block
fill 479 228 306 482 228 306 minecraft:black_stained_glass
fill 480 228 295 486 229 297 minecraft:iron_block
fill 480 228 299 486 229 301 minecraft:iron_block
fill 480 228 305 481 228 305 minecraft:black_stained_glass
fill 482 228 276 492 228 283 minecraft:black_stained_glass
fill 482 228 286 486 228 287 minecraft:black_stained_glass
fill 482 228 288 483 229 289 minecraft:iron_block
setblock 482 228 290 minecraft:black_stained_glass
fill 482 228 291 498 229 291 minecraft:iron_block
fill 482 228 305 498 229 305 minecraft:iron_block
fill 482 228 307 483 229 308 minecraft:iron_block
fill 482 228 309 486 228 316 minecraft:black_stained_glass
fill 483 228 284 511 228 284 minecraft:black_stained_glass
fill 483 228 290 497 229 290 minecraft:iron_block
fill 483 228 306 497 229 306 minecraft:iron_block
fill 484 228 285 511 228 285 minecraft:black_stained_glass
fill 484 228 288 485 228 288 minecraft:black_stained_glass
fill 484 228 289 498 229 289 minecraft:iron_block
fill 484 228 307 498 229 307 minecraft:iron_block
fill 484 228 308 485 228 308 minecraft:black_stained_glass
fill 486 228 275 489 240 275 minecraft:deepslate_tiles
fill 486 228 288 494 229 288 minecraft:iron_block
fill 486 228 298 487 228 298 minecraft:waxed_copper_block
fill 486 228 308 494 229 308 minecraft:iron_block
fill 487 228 286 488 229 287 minecraft:iron_block
fill 487 228 295 487 229 295 minecraft:iron_block
fill 487 228 296 487 229 297 minecraft:waxed_copper_block
fill 487 228 299 487 229 300 minecraft:waxed_copper_block
fill 487 228 301 487 229 301 minecraft:iron_block
fill 487 228 309 488 229 310 minecraft:iron_block
fill 487 228 311 488 228 311 minecraft:black_wool
fill 487 228 313 511 228 316 minecraft:black_stained_glass
fill 488 228 295 488 228 296 minecraft:waxed_copper_block
fill 488 228 300 488 228 301 minecraft:waxed_copper_block
fill 489 228 286 489 228 287 minecraft:black_stained_glass
fill 489 228 295 492 228 295 minecraft:waxed_copper_block
fill 489 228 301 492 228 301 minecraft:waxed_copper_block
fill 489 228 309 489 228 312 minecraft:black_stained_glass
setblock 490 228 275 minecraft:redstone_block
fill 490 228 286 491 228 286 minecraft:black_stained_glass
fill 490 228 287 490 229 287 minecraft:iron_block
fill 490 228 294 490 230 294 minecraft:waxed_copper_block
fill 490 228 302 490 230 302 minecraft:waxed_copper_block
fill 490 228 309 490 229 309 minecraft:iron_block
fill 490 228 310 491 228 312 minecraft:black_stained_glass
fill 491 228 275 493 308 275 minecraft:deepslate_tiles
setblock 491 228 287 minecraft:black_stained_glass
fill 491 228 294 501 229 294 minecraft:iron_block
fill 491 228 302 501 229 302 minecraft:iron_block
setblock 491 228 309 minecraft:black_stained_glass
fill 492 228 286 493 229 287 minecraft:iron_block
fill 492 228 296 493 228 296 minecraft:waxed_copper_block
fill 492 228 300 493 228 300 minecraft:waxed_copper_block
fill 492 228 309 493 229 310 minecraft:iron_block
fill 492 228 311 511 228 312 minecraft:black_stained_glass
fill 493 228 276 511 228 281 minecraft:black_stained_glass
fill 493 228 295 500 229 295 minecraft:iron_block
fill 493 228 297 493 228 299 minecraft:waxed_copper_block
fill 493 228 301 500 229 301 minecraft:iron_block
fill 494 228 286 511 228 287 minecraft:black_stained_glass
fill 494 228 296 500 229 297 minecraft:iron_block
fill 494 228 298 494 230 298 minecraft:waxed_copper_block
fill 494 228 299 500 229 300 minecraft:iron_block
fill 494 228 309 497 228 310 minecraft:black_stained_glass
fill 495 228 282 511 228 283 minecraft:black_stained_glass
fill 495 228 288 496 228 288 minecraft:black_stained_glass
fill 495 228 298 503 229 298 minecraft:iron_block
fill 495 228 308 496 228 308 minecraft:black_stained_glass
fill 497 228 288 498 229 288 minecraft:iron_block
fill 497 228 308 498 229 308 minecraft:iron_block
fill 498 228 290 511 228 290 minecraft:black_stained_glass
fill 498 228 306 511 228 306 minecraft:black_stained_glass
setblock 498 228 310 minecraft:black_stained_glass
fill 499 228 288 501 228 289 minecraft:black_stained_glass
fill 499 228 291 511 228 291 minecraft:black_stained_glass
fill 499 228 305 511 228 305 minecraft:black_stained_glass
fill 499 228 307 511 228 308 minecraft:black_stained_glass
fill 500 228 309 511 228 310 minecraft:black_stained_glass
fill 501 228 295 501 228 297 minecraft:black_stained_glass
fill 501 228 299 501 228 301 minecraft:black_stained_glass
setblock 502 228 288 minecraft:black_stained_glass
fill 502 228 292 511 228 292 minecraft:black_stained_glass
fill 502 228 294 511 228 296 minecraft:black_stained_glass
fill 502 228 297 502 229 297 minecraft:iron_block
fill 502 228 299 502 229 299 minecraft:iron_block
fill 502 228 300 503 228 302 minecraft:black_stained_glass
fill 502 228 304 511 228 304 minecraft:black_stained_glass
fill 503 228 293 511 228 293 minecraft:black_stained_glass
fill 503 228 297 511 228 297 minecraft:black_stained_glass
fill 503 228 299 511 228 299 minecraft:black_stained_glass
fill 503 228 303 511 228 303 minecraft:black_stained_glass
fill 504 228 288 511 228 289 minecraft:black_stained_glass
fill 504 228 298 511 228 298 minecraft:black_stained_glass
fill 504 228 300 505 228 300 minecraft:black_wool
fill 504 228 301 511 228 302 minecraft:black_stained_glass
fill 507 228 300 511 228 300 minecraft:black_stained_glass
fill 470 229 309 470 308 309 minecraft:deepslate_tiles
setblock 473 229 278 minecraft:light[level=13]
setblock 473 229 285 minecraft:light[level=12]
setblock 473 229 286 minecraft:light[level=13]
setblock 473 229 292 minecraft:light[level=12]
setblock 473 229 294 minecraft:light[level=13]
setblock 473 229 299 minecraft:light[level=12]
setblock 473 229 302 minecraft:light[level=13]
setblock 473 229 306 minecraft:light[level=12]
setblock 473 229 310 minecraft:light[level=13]
setblock 473 229 313 minecraft:light[level=12]
setblock 480 229 278 minecraft:light[level=12]
setblock 480 229 285 minecraft:light[level=12]
setblock 480 229 306 minecraft:light[level=12]
setblock 480 229 313 minecraft:light[level=12]
setblock 481 229 278 minecraft:light[level=13]
setblock 481 229 286 minecraft:light[level=13]
setblock 481 229 310 minecraft:light[level=13]
fill 486 229 298 486 230 298 minecraft:waxed_copper_block
setblock 487 229 278 minecraft:light[level=12]
setblock 487 229 285 minecraft:light[level=12]
setblock 487 229 313 minecraft:light[level=12]
fill 488 229 295 489 229 295 minecraft:waxed_copper_block
fill 488 229 301 489 229 301 minecraft:waxed_copper_block
setblock 489 229 278 minecraft:light[level=13]
setblock 489 229 286 minecraft:light[level=13]
setblock 489 229 310 minecraft:light[level=13]
fill 490 229 275 490 308 275 minecraft:deepslate_tiles
fill 491 229 295 492 229 295 minecraft:waxed_copper_block
fill 491 229 301 492 229 301 minecraft:waxed_copper_block
fill 493 229 296 493 229 297 minecraft:waxed_copper_block
fill 493 229 299 493 229 300 minecraft:waxed_copper_block
setblock 494 229 278 minecraft:light[level=12]
setblock 494 229 285 minecraft:light[level=12]
setblock 494 229 313 minecraft:light[level=12]
setblock 497 229 278 minecraft:light[level=13]
setblock 497 229 286 minecraft:light[level=13]
setblock 497 229 310 minecraft:light[level=13]
setblock 501 229 278 minecraft:light[level=12]
setblock 501 229 285 minecraft:light[level=12]
setblock 501 229 299 minecraft:light[level=12]
setblock 501 229 306 minecraft:light[level=12]
setblock 501 229 313 minecraft:light[level=12]
setblock 505 229 278 minecraft:light[level=13]
setblock 505 229 286 minecraft:light[level=13]
setblock 505 229 294 minecraft:light[level=13]
setblock 505 229 302 minecraft:light[level=13]
setblock 505 229 310 minecraft:light[level=13]
setblock 508 229 278 minecraft:light[level=12]
setblock 508 229 285 minecraft:light[level=12]
setblock 508 229 292 minecraft:light[level=12]
setblock 508 229 299 minecraft:light[level=12]
setblock 508 229 306 minecraft:light[level=12]
setblock 508 229 313 minecraft:light[level=12]
fill 483 230 296 483 230 300 minecraft:waxed_oxidized_copper
fill 484 230 294 484 230 295 minecraft:waxed_oxidized_copper
fill 484 230 301 484 230 302 minecraft:waxed_oxidized_copper
setblock 485 230 293 minecraft:waxed_oxidized_copper
setblock 485 230 303 minecraft:waxed_oxidized_copper
fill 486 230 292 487 230 292 minecraft:waxed_oxidized_copper
fill 486 230 304 487 230 304 minecraft:waxed_oxidized_copper
setblock 487 230 296 minecraft:waxed_copper_block
setblock 487 230 300 minecraft:waxed_copper_block
fill 488 230 291 492 230 291 minecraft:waxed_oxidized_copper
setblock 488 230 295 minecraft:waxed_copper_block
setblock 488 230 301 minecraft:waxed_copper_block
fill 488 230 305 492 230 305 minecraft:waxed_oxidized_copper
setblock 492 230 295 minecraft:waxed_copper_block
setblock 492 230 301 minecraft:waxed_copper_block
fill 493 230 292 494 230 292 minecraft:waxed_oxidized_copper
setblock 493 230 296 minecraft:waxed_copper_block
setblock 493 230 300 minecraft:waxed_copper_block
fill 493 230 304 494 230 304 minecraft:waxed_oxidized_copper
setblock 495 230 293 minecraft:waxed_oxidized_copper
setblock 495 230 303 minecraft:waxed_oxidized_copper
fill 496 230 294 496 230 295 minecraft:waxed_oxidized_copper
fill 496 230 301 496 230 302 minecraft:waxed_oxidized_copper
fill 497 230 296 497 230 300 minecraft:waxed_oxidized_copper
setblock 471 232 276 minecraft:cobbled_deepslate
fill 471 232 277 471 235 277 minecraft:deepslate_tiles
setblock 471 232 295 minecraft:deepslate_tiles
fill 471 232 308 471 232 310 minecraft:deepslate_tiles
setblock 471 232 311 minecraft:cobbled_deepslate
fill 471 232 312 471 232 315 minecraft:deepslate_tiles
setblock 471 232 316 minecraft:cobbled_deepslate
fill 472 232 276 475 232 276 minecraft:deepslate_tiles
setblock 472 232 310 minecraft:cobbled_deepslate
fill 472 232 311 472 232 314 minecraft:deepslate_tiles
setblock 472 232 315 minecraft:cobbled_deepslate
fill 472 232 316 475 232 316 minecraft:deepslate_tiles
fill 473 232 300 473 234 300 minecraft:white_wool
fill 473 232 312 473 232 313 minecraft:deepslate_tiles
setblock 473 232 314 minecraft:cobbled_deepslate
fill 473 232 315 476 232 315 minecraft:deepslate_tiles
fill 474 232 308 474 251 308 minecraft:white_wool
fill 474 232 314 477 232 314 minecraft:deepslate_tiles
fill 474 232 317 474 246 317 minecraft:deepslate_tiles
fill 475 232 284 475 241 284 minecraft:white_wool
setblock 475 232 317 minecraft:white_wool
setblock 476 232 276 minecraft:cobbled_deepslate
fill 476 232 313 478 232 313 minecraft:deepslate_tiles
setblock 476 232 316 minecraft:cobbled_deepslate
fill 476 232 317 479 244 317 minecraft:deepslate_tiles
fill 477 232 276 480 232 276 minecraft:deepslate_tiles
setblock 477 232 279 minecraft:white_wool
setblock 477 232 315 minecraft:cobbled_deepslate
fill 477 232 316 480 232 316 minecraft:deepslate_tiles
setblock 478 232 314 minecraft:cobbled_deepslate
fill 478 232 315 481 232 315 minecraft:deepslate_tiles
fill 479 232 314 481 233 314 minecraft:deepslate_tiles
fill 480 232 310 480 248 310 minecraft:white_wool
setblock 481 232 276 minecraft:cobbled_deepslate
setblock 481 232 316 minecraft:cobbled_deepslate
fill 482 232 276 482 235 276 minecraft:deepslate_tiles
setblock 482 232 315 minecraft:cobbled_deepslate
fill 482 232 316 485 232 316 minecraft:deepslate_tiles
fill 483 232 315 483 233 315 minecraft:deepslate_tiles
fill 492 232 316 495 232 316 minecraft:deepslate_tiles
fill 493 232 276 495 232 276 minecraft:deepslate_tiles
setblock 495 232 277 minecraft:cobbled_deepslate
fill 495 232 315 496 232 315 minecraft:deepslate_tiles
setblock 496 232 276 minecraft:cobbled_deepslate
fill 496 232 277 499 232 277 minecraft:deepslate_tiles
setblock 496 232 316 minecraft:cobbled_deepslate
fill 497 232 276 500 232 276 minecraft:deepslate_tiles
setblock 497 232 315 minecraft:cobbled_deepslate
fill 497 232 316 500 232 316 minecraft:deepslate_tiles
fill 498 232 315 501 232 315 minecraft:deepslate_tiles
setblock 500 232 277 minecraft:cobbled_deepslate
setblock 501 232 276 minecraft:cobbled_deepslate
fill 501 232 277 504 232 277 minecraft:deepslate_tiles
setblock 501 232 316 minecraft:cobbled_deepslate
fill 502 232 276 505 232 276 minecraft:deepslate_tiles
setblock 502 232 315 minecraft:cobbled_deepslate
fill 502 232 316 505 232 316 minecraft:deepslate_tiles
fill 503 232 315 503 235 315 minecraft:deepslate_tiles
setblock 506 232 276 minecraft:cobbled_deepslate
setblock 506 232 316 minecraft:cobbled_deepslate
fill 507 232 276 510 232 276 minecraft:deepslate_tiles
fill 507 232 316 510 232 316 minecraft:deepslate_tiles
fill 510 232 315 511 232 315 minecraft:deepslate_tiles
setblock 511 232 276 minecraft:cobbled_deepslate
fill 511 232 277 511 233 279 minecraft:deepslate_tiles
setblock 511 232 311 minecraft:cobbled_deepslate
fill 511 232 312 511 233 314 minecraft:deepslate_tiles
setblock 511 232 316 minecraft:cobbled_deepslate
fill 471 233 276 474 233 276 minecraft:deepslate_tiles
fill 471 233 278 471 234 278 minecraft:deepslate_tiles
fill 471 233 292 471 233 294 minecraft:deepslate_tiles
setblock 471 233 295 minecraft:cobbled_deepslate
fill 471 233 296 471 233 299 minecraft:deepslate_tiles
setblock 471 233 300 minecraft:cobbled_deepslate
fill 471 233 307 471 233 309 minecraft:deepslate_tiles
setblock 471 233 310 minecraft:cobbled_deepslate
fill 471 233 311 471 233 314 minecraft:deepslate_tiles
setblock 471 233 315 minecraft:cobbled_deepslate
fill 471 233 316 474 233 316 minecraft:deepslate_tiles
setblock 472 233 309 minecraft:cobbled_deepslate
fill 472 233 310 472 233 313 minecraft:deepslate_tiles
setblock 472 233 314 minecraft:cobbled_deepslate
fill 472 233 315 475 233 315 minecraft:deepslate_tiles
fill 473 233 311 473 233 312 minecraft:deepslate_tiles
setblock 473 233 313 minecraft:cobbled_deepslate
fill 473 233 314 476 233 314 minecraft:deepslate_tiles
setblock 474 233 277 minecraft:cobbled_deepslate
fill 474 233 286 474 237 286 minecraft:cobbled_deepslate
setblock 475 233 276 minecraft:cobbled_deepslate
fill 475 233 277 478 233 277 minecraft:deepslate_tiles
fill 475 233 313 477 233 313 minecraft:deepslate_tiles
setblock 475 233 316 minecraft:cobbled_deepslate
fill 475 233 317 475 241 317 minecraft:deepslate_tiles
fill 476 233 276 479 233 276 minecraft:deepslate_tiles
setblock 476 233 315 minecraft:cobbled_deepslate
fill 476 233 316 479 233 316 minecraft:deepslate_tiles
setblock 477 233 314 minecraft:cobbled_deepslate
fill 477 233 315 480 233 315 minecraft:deepslate_tiles
fill 478 233 314 478 236 314 minecraft:deepslate_tiles
setblock 480 233 276 minecraft:cobbled_deepslate
setblock 480 233 316 minecraft:cobbled_deepslate
fill 481 233 276 481 236 276 minecraft:deepslate_tiles
setblock 481 233 315 minecraft:cobbled_deepslate
fill 481 233 316 484 233 316 minecraft:deepslate_tiles
fill 482 233 315 482 235 315 minecraft:deepslate_tiles
setblock 485 233 316 minecraft:cobbled_deepslate
fill 490 233 279 490 240 279 minecraft:cobbled_deepslate
fill 491 233 276 494 233 276 minecraft:deepslate_tiles
fill 491 233 316 494 233 316 minecraft:deepslate_tiles
setblock 494 233 277 minecraft:cobbled_deepslate
fill 494 233 315 495 233 315 minecraft:deepslate_tiles
setblock 495 233 276 minecraft:cobbled_deepslate
fill 495 233 277 498 233 277 minecraft:deepslate_tiles
setblock 495 233 316 minecraft:cobbled_deepslate
fill 496 233 276 499 233 276 minecraft:deepslate_tiles
setblock 496 233 315 minecraft:cobbled_deepslate
fill 496 233 316 499 233 316 minecraft:deepslate_tiles
setblock 497 233 278 minecraft:deepslate_tiles
fill 497 233 315 500 233 315 minecraft:deepslate_tiles
setblock 498 233 278 minecraft:cobbled_deepslate
setblock 499 233 277 minecraft:cobbled_deepslate
fill 499 233 278 500 235 278 minecraft:deepslate_tiles
setblock 500 233 276 minecraft:cobbled_deepslate
fill 500 233 277 503 233 277 minecraft:deepslate_tiles
setblock 500 233 316 minecraft:cobbled_deepslate
fill 501 233 276 504 233 276 minecraft:deepslate_tiles
setblock 501 233 315 minecraft:cobbled_deepslate
fill 501 233 316 504 233 316 minecraft:deepslate_tiles
fill 502 233 315 502 236 315 minecraft:deepslate_tiles
setblock 504 233 277 minecraft:cobbled_deepslate
setblock 505 233 276 minecraft:cobbled_deepslate
fill 505 233 277 506 235 277 minecraft:deepslate_tiles
setblock 505 233 316 minecraft:cobbled_deepslate
fill 506 233 276 509 233 276 minecraft:deepslate_tiles
fill 506 233 316 509 233 316 minecraft:deepslate_tiles
fill 508 233 289 508 251 289 minecraft:white_wool
setblock 509 233 277 minecraft:cobbled_deepslate
fill 509 233 315 510 233 315 minecraft:deepslate_tiles
setblock 510 233 276 minecraft:cobbled_deepslate
fill 510 233 277 510 236 277 minecraft:deepslate_tiles
fill 510 233 314 510 234 314 minecraft:deepslate_tiles
setblock 510 233 316 minecraft:cobbled_deepslate
fill 511 233 276 511 236 276 minecraft:deepslate_tiles
setblock 511 233 280 minecraft:cobbled_deepslate
fill 511 233 292 511 233 294 minecraft:deepslate_tiles
setblock 511 233 295 minecraft:cobbled_deepslate
fill 511 233 311 511 236 311 minecraft:deepslate_tiles
setblock 511 233 315 minecraft:cobbled_deepslate
fill 511 233 316 511 236 316 minecraft:deepslate_tiles
setblock 470 234 313 minecraft:white_wool
fill 471 234 276 473 234 276 minecraft:deepslate_tiles
setblock 471 234 279 minecraft:cobbled_deepslate
fill 471 234 292 471 234 293 minecraft:deepslate_tiles
setblock 471 234 294 minecraft:cobbled_deepslate
fill 471 234 295 471 234 298 minecraft:deepslate_tiles
setblock 471 234 299 minecraft:cobbled_deepslate
fill 471 234 300 471 234 303 minecraft:deepslate_tiles
setblock 471 234 304 minecraft:cobbled_deepslate
fill 471 234 305 471 234 308 minecraft:deepslate_tiles
setblock 471 234 309 minecraft:cobbled_deepslate
fill 471 234 310 471 234 313 minecraft:deepslate_tiles
setblock 471 234 314 minecraft:cobbled_deepslate
fill 471 234 315 473 234 316 minecraft:deepslate_tiles
setblock 472 234 277 minecraft:deepslate_tiles
setblock 472 234 293 minecraft:cobbled_deepslate
fill 472 234 294 472 234 297 minecraft:deepslate_tiles
setblock 472 234 298 minecraft:cobbled_deepslate
fill 472 234 299 472 235 301 minecraft:deepslate_tiles
setblock 472 234 308 minecraft:cobbled_deepslate
fill 472 234 309 472 234 312 minecraft:deepslate_tiles
setblock 472 234 313 minecraft:cobbled_deepslate
fill 472 234 314 475 234 314 minecraft:deepslate_tiles
setblock 473 234 277 minecraft:cobbled_deepslate
setblock 473 234 296 minecraft:deepslate_tiles
setblock 473 234 297 minecraft:cobbled_deepslate
fill 473 234 298 473 237 298 minecraft:deepslate_tiles
setblock 473 234 311 minecraft:deepslate_tiles
setblock 473 234 312 minecraft:cobbled_deepslate
fill 473 234 313 476 234 313 minecraft:deepslate_tiles
setblock 474 234 276 minecraft:cobbled_deepslate
fill 474 234 277 477 234 277 minecraft:deepslate_tiles
setblock 474 234 315 minecraft:deepslate_tiles
setblock 474 234 316 minecraft:cobbled_deepslate
fill 475 234 276 478 234 276 minecraft:deepslate_tiles
fill 475 234 289 475 235 290 minecraft:white_wool
fill 475 234 296 475 241 296 minecraft:black_concrete
fill 475 234 298 477 235 298 minecraft:waxed_copper_block
setblock 475 234 315 minecraft:cobbled_deepslate
fill 475 234 316 478 234 316 minecraft:deepslate_tiles
fill 476 234 295 478 235 297 minecraft:waxed_copper_block
fill 476 234 299 478 235 301 minecraft:waxed_copper_block
setblock 476 234 314 minecraft:cobbled_deepslate
fill 476 234 315 479 234 315 minecraft:deepslate_tiles
fill 477 234 294 485 235 294 minecraft:waxed_copper_block
fill 477 234 302 485 235 302 minecraft:waxed_copper_block
setblock 477 234 313 minecraft:cobbled_deepslate
fill 477 234 314 477 237 314 minecraft:deepslate_tiles
setblock 478 234 277 minecraft:cobbled_deepslate
fill 478 234 293 484 235 293 minecraft:waxed_copper_block
fill 478 234 303 484 235 303 minecraft:waxed_copper_block
setblock 479 234 276 minecraft:cobbled_deepslate
fill 479 234 277 479 237 277 minecraft:deepslate_tiles
fill 479 234 290 480 235 291 minecraft:white_wool
fill 479 234 295 480 235 295 minecraft:waxed_copper_block
fill 479 234 301 480 235 301 minecraft:waxed_copper_block
fill 479 234 314 480 234 314 minecraft:deepslate_tiles
setblock 479 234 316 minecraft:cobbled_deepslate
fill 480 234 276 480 237 276 minecraft:deepslate_tiles
setblock 480 234 315 minecraft:cobbled_deepslate
fill 480 234 316 483 234 316 minecraft:deepslate_tiles
fill 481 234 290 481 235 290 minecraft:white_wool
fill 481 234 292 481 235 292 minecraft:waxed_copper_block
fill 481 234 304 481 235 304 minecraft:waxed_copper_block
fill 481 234 315 481 236 315 minecraft:deepslate_tiles
fill 482 234 295 486 235 295 minecraft:waxed_copper_block
fill 482 234 301 486 235 301 minecraft:waxed_copper_block
setblock 483 234 276 minecraft:deepslate_tiles
fill 484 234 296 485 235 297 minecraft:waxed_copper_block
fill 484 234 299 485 235 300 minecraft:waxed_copper_block
setblock 484 234 316 minecraft:cobbled_deepslate
fill 485 234 298 485 235 298 minecraft:waxed_copper_block
fill 485 234 316 485 236 316 minecraft:deepslate_tiles
fill 490 234 276 493 234 276 minecraft:deepslate_tiles
fill 490 234 316 493 234 316 minecraft:deepslate_tiles
setblock 492 234 277 minecraft:deepslate_tiles
setblock 493 234 277 minecraft:cobbled_deepslate
fill 493 234 315 494 234 315 minecraft:deepslate_tiles
setblock 494 234 276 minecraft:cobbled_deepslate
fill 494 234 277 497 234 277 minecraft:deepslate_tiles
setblock 494 234 316 minecraft:cobbled_deepslate
fill 495 234 276 498 234 276 minecraft:deepslate_tiles
fill 495 234 278 496 234 278 minecraft:deepslate_tiles
setblock 495 234 315 minecraft:cobbled_deepslate
fill 495 234 316 498 234 316 minecraft:deepslate_tiles
fill 496 234 315 499 234 315 minecraft:deepslate_tiles
setblock 497 234 278 minecraft:cobbled_deepslate
setblock 498 234 277 minecraft:cobbled_deepslate
fill 498 234 278 498 237 278 minecraft:deepslate_tiles
setblock 499 234 276 minecraft:cobbled_deepslate
fill 499 234 277 502 234 277 minecraft:deepslate_tiles
setblock 499 234 316 minecraft:cobbled_deepslate
fill 500 234 276 503 234 276 minecraft:deepslate_tiles
setblock 500 234 315 minecraft:cobbled_deepslate
fill 500 234 316 503 234 316 minecraft:deepslate_tiles
setblock 501 234 278 minecraft:deepslate_tiles
fill 501 234 315 501 237 315 minecraft:deepslate_tiles
setblock 502 234 278 minecraft:cobbled_deepslate
setblock 503 234 277 minecraft:cobbled_deepslate
setblock 504 234 276 minecraft:cobbled_deepslate
fill 504 234 277 504 237 277 minecraft:deepslate_tiles
setblock 504 234 315 minecraft:deepslate_tiles
setblock 504 234 316 minecraft:cobbled_deepslate
fill 505 234 276 508 234 276 minecraft:deepslate_tiles
fill 505 234 316 508 234 316 minecraft:deepslate_tiles
setblock 507 234 277 minecraft:deepslate_tiles
setblock 508 234 277 minecraft:cobbled_deepslate
fill 508 234 315 509 234 315 minecraft:deepslate_tiles
setblock 509 234 276 minecraft:cobbled_deepslate
fill 509 234 277 509 237 277 minecraft:deepslate_tiles
setblock 509 234 316 minecraft:cobbled_deepslate
fill 510 234 276 510 237 276 minecraft:deepslate_tiles
fill 510 234 278 511 234 278 minecraft:deepslate_tiles
fill 510 234 313 511 234 313 minecraft:deepslate_tiles
setblock 510 234 315 minecraft:cobbled_deepslate
fill 510 234 316 510 237 316 minecraft:deepslate_tiles
fill 511 234 277 511 235 277 minecraft:deepslate_tiles
setblock 511 234 279 minecraft:cobbled_deepslate
fill 511 234 280 511 236 281 minecraft:deepslate_tiles
fill 511 234 291 511 234 293 minecraft:deepslate_tiles
setblock 511 234 294 minecraft:cobbled_deepslate
fill 511 234 295 511 234 298 minecraft:deepslate_tiles
fill 511 234 310 511 237 310 minecraft:deepslate_tiles
fill 511 234 312 511 235 312 minecraft:deepslate_tiles
setblock 511 234 314 minecraft:cobbled_deepslate
fill 511 234 315 511 237 315 minecraft:deepslate_tiles
setblock 470 235 281 minecraft:redstone_block
fill 470 235 313 470 308 313 minecraft:deepslate_tiles
fill 471 235 276 472 235 276 minecraft:deepslate_tiles
setblock 471 235 278 minecraft:cobbled_deepslate
fill 471 235 279 471 237 280 minecraft:deepslate_tiles
fill 471 235 291 471 235 292 minecraft:deepslate_tiles
setblock 471 235 293 minecraft:cobbled_deepslate
fill 471 235 294 471 235 297 minecraft:deepslate_tiles
setblock 471 235 298 minecraft:cobbled_deepslate
fill 471 235 299 471 235 302 minecraft:deepslate_tiles
setblock 471 235 303 minecraft:cobbled_deepslate
fill 471 235 304 471 235 307 minecraft:deepslate_tiles
setblock 471 235 308 minecraft:cobbled_deepslate
fill 471 235 309 471 235 312 minecraft:deepslate_tiles
setblock 471 235 313 minecraft:cobbled_deepslate
fill 471 235 314 472 235 316 minecraft:deepslate_tiles
setblock 472 235 277 minecraft:cobbled_deepslate
fill 472 235 278 472 238 278 minecraft:deepslate_tiles
fill 472 235 293 472 235 296 minecraft:deepslate_tiles
setblock 472 235 297 minecraft:cobbled_deepslate
fill 472 235 298 472 238 298 minecraft:deepslate_tiles
setblock 472 235 302 minecraft:cobbled_deepslate
fill 472 235 303 472 235 306 minecraft:deepslate_tiles
setblock 472 235 307 minecraft:cobbled_deepslate
fill 472 235 308 472 235 311 minecraft:deepslate_tiles
setblock 472 235 312 minecraft:cobbled_deepslate
fill 472 235 313 475 235 313 minecraft:deepslate_tiles
setblock 473 235 276 minecraft:cobbled_deepslate
fill 473 235 277 476 235 277 minecraft:deepslate_tiles
setblock 473 235 278 minecraft:light[level=12]
setblock 473 235 285 minecraft:light[level=12]
setblock 473 235 292 minecraft:light[level=12]
fill 473 235 294 473 235 295 minecraft:deepslate_tiles
setblock 473 235 296 minecraft:cobbled_deepslate
fill 473 235 297 473 238 297 minecraft:deepslate_tiles
fill 473 235 299 473 235 300 minecraft:deepslate_tiles
setblock 473 235 301 minecraft:cobbled_deepslate
fill 473 235 302 473 238 302 minecraft:deepslate_tiles
setblock 473 235 306 minecraft:light[level=12]
setblock 473 235 310 minecraft:deepslate_tiles
setblock 473 235 311 minecraft:cobbled_deepslate
fill 473 235 312 473 238 312 minecraft:deepslate_tiles
fill 473 235 314 473 235 315 minecraft:deepslate_tiles
setblock 473 235 316 minecraft:cobbled_deepslate
fill 474 235 276 477 235 276 minecraft:deepslate_tiles
setblock 474 235 314 minecraft:deepslate_tiles
setblock 474 235 315 minecraft:cobbled_deepslate
fill 474 235 316 477 235 316 minecraft:deepslate_tiles
setblock 475 235 314 minecraft:cobbled_deepslate
fill 475 235 315 478 235 315 minecraft:deepslate_tiles
setblock 476 235 313 minecraft:cobbled_deepslate
fill 476 235 314 476 238 314 minecraft:deepslate_tiles
setblock 477 235 277 minecraft:cobbled_deepslate
setblock 478 235 276 minecraft:cobbled_deepslate
fill 478 235 277 478 238 277 minecraft:deepslate_tiles
setblock 478 235 316 minecraft:cobbled_deepslate
fill 479 235 276 479 238 276 minecraft:deepslate_tiles
setblock 479 235 314 minecraft:deepslate_tiles
setblock 479 235 315 minecraft:cobbled_deepslate
fill 479 235 316 482 235 316 minecraft:deepslate_tiles
fill 480 235 277 480 236 277 minecraft:deepslate_tiles
setblock 480 235 278 minecraft:light[level=12]
setblock 480 235 285 minecraft:light[level=12]
setblock 480 235 292 minecraft:light[level=12]
setblock 480 235 299 minecraft:light[level=12]
setblock 480 235 306 minecraft:light[level=12]
setblock 480 235 313 minecraft:light[level=12]
setblock 480 235 314 minecraft:cobbled_deepslate
fill 480 235 315 480 237 315 minecraft:deepslate_tiles
setblock 483 235 276 minecraft:cobbled_deepslate
setblock 483 235 316 minecraft:cobbled_deepslate
fill 484 235 276 484 238 276 minecraft:deepslate_tiles
fill 484 235 316 484 236 316 minecraft:deepslate_tiles
setblock 487 235 278 minecraft:light[level=12]
setblock 487 235 285 minecraft:light[level=12]
setblock 487 235 292 minecraft:light[level=12]
setblock 487 235 306 minecraft:light[level=12]
setblock 487 235 313 minecraft:light[level=12]
setblock 488 235 276 minecraft:cobbled_deepslate
setblock 488 235 316 minecraft:cobbled_deepslate
fill 489 235 276 492 235 276 minecraft:deepslate_tiles
fill 489 235 316 492 235 316 minecraft:deepslate_tiles
setblock 491 235 277 minecraft:deepslate_tiles
setblock 492 235 277 minecraft:cobbled_deepslate
setblock 493 235 276 minecraft:cobbled_deepslate
fill 493 235 277 495 235 278 minecraft:deepslate_tiles
setblock 493 235 315 minecraft:deepslate_tiles
setblock 493 235 316 minecraft:cobbled_deepslate
fill 494 235 276 497 235 276 minecraft:deepslate_tiles
setblock 494 235 285 minecraft:light[level=12]
setblock 494 235 292 minecraft:light[level=12]
setblock 494 235 306 minecraft:light[level=12]
setblock 494 235 313 minecraft:light[level=12]
setblock 494 235 315 minecraft:cobbled_deepslate
fill 494 235 316 497 235 316 minecraft:deepslate_tiles
fill 495 235 315 498 235 315 minecraft:deepslate_tiles
setblock 496 235 277 minecraft:deepslate_tiles
setblock 496 235 278 minecraft:cobbled_deepslate
setblock 497 235 277 minecraft:cobbled_deepslate
fill 497 235 278 497 238 278 minecraft:deepslate_tiles
setblock 498 235 276 minecraft:cobbled_deepslate
fill 498 235 277 501 235 277 minecraft:deepslate_tiles
setblock 498 235 316 minecraft:cobbled_deepslate
fill 499 235 276 502 235 276 minecraft:deepslate_tiles
setblock 499 235 315 minecraft:cobbled_deepslate
fill 499 235 316 502 235 316 minecraft:deepslate_tiles
fill 500 235 315 500 237 315 minecraft:deepslate_tiles
setblock 501 235 278 minecraft:cobbled_deepslate
setblock 501 235 285 minecraft:light[level=12]
setblock 501 235 292 minecraft:light[level=12]
setblock 501 235 299 minecraft:light[level=12]
setblock 501 235 306 minecraft:light[level=12]
setblock 501 235 313 minecraft:light[level=12]
setblock 502 235 277 minecraft:cobbled_deepslate
fill 502 235 278 503 237 278 minecraft:deepslate_tiles
setblock 503 235 276 minecraft:cobbled_deepslate
fill 503 235 277 503 238 277 minecraft:deepslate_tiles
setblock 503 235 316 minecraft:cobbled_deepslate
fill 504 235 276 507 235 276 minecraft:deepslate_tiles
setblock 504 235 315 minecraft:cobbled_deepslate
fill 504 235 316 507 235 316 minecraft:deepslate_tiles
fill 506 235 315 508 235 315 minecraft:deepslate_tiles
setblock 507 235 277 minecraft:cobbled_deepslate
setblock 508 235 276 minecraft:cobbled_deepslate
fill 508 235 277 508 238 277 minecraft:deepslate_tiles
setblock 508 235 278 minecraft:light[level=12]
setblock 508 235 285 minecraft:light[level=12]
setblock 508 235 292 minecraft:light[level=12]
setblock 508 235 299 minecraft:light[level=12]
setblock 508 235 306 minecraft:light[level=12]
setblock 508 235 313 minecraft:light[level=12]
setblock 508 235 316 minecraft:cobbled_deepslate
fill 509 235 276 509 238 276 minecraft:deepslate_tiles
setblock 509 235 315 minecraft:cobbled_deepslate
fill 509 235 316 509 238 316 minecraft:deepslate_tiles
setblock 510 235 278 minecraft:deepslate_tiles
setblock 510 235 279 minecraft:cobbled_deepslate
fill 510 235 280 510 238 280 minecraft:deepslate_tiles
setblock 510 235 313 minecraft:deepslate_tiles
setblock 510 235 314 minecraft:cobbled_deepslate
fill 510 235 315 510 238 315 minecraft:deepslate_tiles
setblock 511 235 278 minecraft:cobbled_deepslate
fill 511 235 279 511 238 279 minecraft:deepslate_tiles
setblock 511 235 282 minecraft:deepslate_tiles
setblock 511 235 283 minecraft:cobbled_deepslate
fill 511 235 291 511 235 292 minecraft:deepslate_tiles
setblock 511 235 293 minecraft:cobbled_deepslate
fill 511 235 294 511 235 297 minecraft:deepslate_tiles
setblock 511 235 298 minecraft:cobbled_deepslate
fill 511 235 299 511 236 301 minecraft:deepslate_tiles
fill 511 235 309 511 238 309 minecraft:deepslate_tiles
setblock 511 235 313 minecraft:cobbled_deepslate
fill 511 235 314 511 238 314 minecraft:deepslate_tiles
fill 470 236 281 471 236 281 minecraft:deepslate_tiles
setblock 471 236 276 minecraft:deepslate_tiles
setblock 471 236 277 minecraft:cobbled_deepslate
fill 471 236 278 471 239 278 minecraft:deepslate_tiles
setblock 471 236 291 minecraft:deepslate_tiles
setblock 471 236 292 minecraft:cobbled_deepslate
fill 471 236 293 471 236 296 minecraft:deepslate_tiles
setblock 471 236 297 minecraft:cobbled_deepslate
fill 471 236 298 471 236 301 minecraft:deepslate_tiles
setblock 471 236 302 minecraft:cobbled_deepslate
fill 471 236 303 471 236 306 minecraft:deepslate_tiles
setblock 471 236 307 minecraft:cobbled_deepslate
fill 471 236 308 471 236 311 minecraft:deepslate_tiles
setblock 471 236 312 minecraft:cobbled_deepslate
fill 471 236 313 471 236 316 minecraft:deepslate_tiles
setblock 472 236 276 minecraft:cobbled_deepslate
fill 472 236 277 475 236 277 minecraft:deepslate_tiles
fill 472 236 279 472 237 279 minecraft:deepslate_tiles
fill 472 236 292 472 236 295 minecraft:deepslate_tiles
setblock 472 236 296 minecraft:cobbled_deepslate
fill 472 236 297 472 239 297 minecraft:deepslate_tiles
fill 472 236 299 472 236 300 minecraft:deepslate_tiles
setblock 472 236 301 minecraft:cobbled_deepslate
fill 472 236 302 472 236 305 minecraft:deepslate_tiles
setblock 472 236 306 minecraft:cobbled_deepslate
fill 472 236 307 472 236 310 minecraft:deepslate_tiles
setblock 472 236 311 minecraft:cobbled_deepslate
fill 472 236 312 472 236 315 minecraft:deepslate_tiles
setblock 472 236 316 minecraft:cobbled_deepslate
fill 473 236 276 476 236 276 minecraft:deepslate_tiles
setblock 473 236 294 minecraft:deepslate_tiles
setblock 473 236 295 minecraft:cobbled_deepslate
fill 473 236 296 474 238 296 minecraft:deepslate_tiles
setblock 473 236 299 minecraft:deepslate_tiles
setblock 473 236 300 minecraft:cobbled_deepslate
fill 473 236 301 474 238 301 minecraft:deepslate_tiles
fill 473 236 303 473 236 304 minecraft:deepslate_tiles
setblock 473 236 305 minecraft:cobbled_deepslate
setblock 473 236 309 minecraft:deepslate_tiles
setblock 473 236 310 minecraft:cobbled_deepslate
fill 473 236 311 473 238 311 minecraft:deepslate_tiles
fill 473 236 313 473 236 314 minecraft:deepslate_tiles
setblock 473 236 315 minecraft:cobbled_deepslate
fill 473 236 316 476 236 316 minecraft:deepslate_tiles
fill 474 236 297 474 236 298 minecraft:deepslate_tiles
setblock 474 236 299 minecraft:cobbled_deepslate
fill 474 236 300 474 239 300 minecraft:deepslate_tiles
setblock 474 236 313 minecraft:deepslate_tiles
setblock 474 236 314 minecraft:cobbled_deepslate
fill 474 236 315 477 236 315 minecraft:deepslate_tiles
setblock 475 236 278 minecraft:cobbled_deepslate
setblock 475 236 313 minecraft:cobbled_deepslate
fill 475 236 314 475 239 314 minecraft:deepslate_tiles
setblock 476 236 277 minecraft:cobbled_deepslate
setblock 477 236 276 minecraft:cobbled_deepslate
fill 477 236 277 477 239 277 minecraft:deepslate_tiles
setblock 477 236 316 minecraft:cobbled_deepslate
fill 478 236 276 478 239 276 minecraft:deepslate_tiles
setblock 478 236 315 minecraft:cobbled_deepslate
fill 478 236 316 481 236 316 minecraft:deepslate_tiles
setblock 479 236 314 minecraft:cobbled_deepslate
fill 479 236 315 479 238 315 minecraft:deepslate_tiles
setblock 482 236 276 minecraft:cobbled_deepslate
setblock 482 236 316 minecraft:cobbled_deepslate
fill 483 236 276 483 238 276 minecraft:deepslate_tiles
fill 483 236 316 483 237 316 minecraft:deepslate_tiles
fill 485 236 276 486 236 276 minecraft:deepslate_tiles
setblock 487 236 276 minecraft:cobbled_deepslate
fill 488 236 276 491 236 276 minecraft:deepslate_tiles
fill 488 236 316 491 236 316 minecraft:deepslate_tiles
setblock 490 236 277 minecraft:deepslate_tiles
setblock 491 236 277 minecraft:cobbled_deepslate
setblock 492 236 276 minecraft:cobbled_deepslate
fill 492 236 277 494 236 278 minecraft:deepslate_tiles
setblock 492 236 315 minecraft:deepslate_tiles
setblock 492 236 316 minecraft:cobbled_deepslate
fill 493 236 276 496 236 276 minecraft:deepslate_tiles
setblock 493 236 315 minecraft:cobbled_deepslate
fill 493 236 316 496 236 316 minecraft:deepslate_tiles
fill 494 236 315 497 236 315 minecraft:deepslate_tiles
setblock 495 236 277 minecraft:deepslate_tiles
setblock 495 236 278 minecraft:cobbled_deepslate
fill 495 236 279 498 236 279 minecraft:deepslate_tiles
setblock 496 236 277 minecraft:cobbled_deepslate
fill 496 236 278 496 239 278 minecraft:deepslate_tiles
setblock 497 236 276 minecraft:cobbled_deepslate
fill 497 236 277 500 236 277 minecraft:deepslate_tiles
setblock 497 236 316 minecraft:cobbled_deepslate
fill 498 236 276 501 236 276 minecraft:deepslate_tiles
setblock 498 236 315 minecraft:cobbled_deepslate
fill 498 236 316 501 236 316 minecraft:deepslate_tiles
setblock 499 236 278 minecraft:deepslate_tiles
setblock 499 236 279 minecraft:cobbled_deepslate
fill 499 236 315 499 238 315 minecraft:deepslate_tiles
setblock 500 236 278 minecraft:cobbled_deepslate
setblock 501 236 277 minecraft:cobbled_deepslate
fill 501 236 278 501 239 278 minecraft:deepslate_tiles
setblock 502 236 276 minecraft:cobbled_deepslate
fill 502 236 277 502 239 277 minecraft:deepslate_tiles
setblock 502 236 316 minecraft:cobbled_deepslate
fill 503 236 276 506 236 276 minecraft:deepslate_tiles
setblock 503 236 315 minecraft:cobbled_deepslate
fill 503 236 316 506 236 316 minecraft:deepslate_tiles
setblock 505 236 277 minecraft:deepslate_tiles
setblock 506 236 277 minecraft:cobbled_deepslate
fill 506 236 315 507 236 315 minecraft:deepslate_tiles
setblock 507 236 276 minecraft:cobbled_deepslate
fill 507 236 277 507 239 277 minecraft:deepslate_tiles
setblock 507 236 316 minecraft:cobbled_deepslate
fill 508 236 276 508 239 276 minecraft:deepslate_tiles
setblock 508 236 315 minecraft:cobbled_deepslate
fill 508 236 316 508 239 316 minecraft:deepslate_tiles
setblock 509 236 278 minecraft:deepslate_tiles
fill 509 236 315 509 239 315 minecraft:deepslate_tiles
setblock 510 236 278 minecraft:cobbled_deepslate
fill 510 236 279 510 239 279 minecraft:deepslate_tiles
fill 510 236 281 510 237 281 minecraft:deepslate_tiles
setblock 510 236 312 minecraft:deepslate_tiles
setblock 510 236 313 minecraft:cobbled_deepslate
fill 510 236 314 510 239 314 minecraft:deepslate_tiles
setblock 511 236 277 minecraft:cobbled_deepslate
fill 511 236 278 511 239 278 minecraft:deepslate_tiles
setblock 511 236 282 minecraft:cobbled_deepslate
fill 511 236 283 511 238 284 minecraft:deepslate_tiles
setblock 511 236 291 minecraft:deepslate_tiles
setblock 511 236 292 minecraft:cobbled_deepslate
fill 511 236 293 511 236 296 minecraft:deepslate_tiles
setblock 511 236 297 minecraft:cobbled_deepslate
fill 511 236 298 511 239 298 minecraft:deepslate_tiles
setblock 511 236 302 minecraft:cobbled_deepslate
fill 511 236 303 511 238 304 minecraft:deepslate_tiles
setblock 511 236 307 minecraft:cobbled_deepslate
fill 511 236 308 511 239 308 minecraft:deepslate_tiles
setblock 511 236 312 minecraft:cobbled_deepslate
fill 511 236 313 511 239 313 minecraft:deepslate_tiles
fill 470 237 281 470 241 281 minecraft:deepslate_tiles
setblock 471 237 276 minecraft:cobbled_deepslate
fill 471 237 277 474 237 277 minecraft:deepslate_tiles
setblock 471 237 281 minecraft:cobbled_deepslate
fill 471 237 282 471 240 282 minecraft:deepslate_tiles
setblock 471 237 291 minecraft:cobbled_deepslate
fill 471 237 292 471 237 295 minecraft:deepslate_tiles
setblock 471 237 296 minecraft:cobbled_deepslate
fill 471 237 297 471 237 300 minecraft:deepslate_tiles
setblock 471 237 301 minecraft:cobbled_deepslate
fill 471 237 302 471 237 305 minecraft:deepslate_tiles
setblock 471 237 306 minecraft:cobbled_deepslate
fill 471 237 307 471 237 310 minecraft:deepslate_tiles
setblock 471 237 311 minecraft:cobbled_deepslate
fill 471 237 312 471 237 315 minecraft:deepslate_tiles
setblock 471 237 316 minecraft:cobbled_deepslate
fill 472 237 276 475 237 276 minecraft:deepslate_tiles
setblock 472 237 280 minecraft:cobbled_deepslate
fill 472 237 292 472 237 294 minecraft:deepslate_tiles
setblock 472 237 295 minecraft:cobbled_deepslate
fill 472 237 296 472 240 296 minecraft:deepslate_tiles
setblock 472 237 299 minecraft:deepslate_tiles
setblock 472 237 300 minecraft:cobbled_deepslate
fill 472 237 301 472 237 304 minecraft:deepslate_tiles
setblock 472 237 305 minecraft:cobbled_deepslate
fill 472 237 306 472 237 309 minecraft:deepslate_tiles
setblock 472 237 310 minecraft:cobbled_deepslate
fill 472 237 311 472 237 314 minecraft:deepslate_tiles
setblock 472 237 315 minecraft:cobbled_deepslate
fill 472 237 316 475 237 316 minecraft:deepslate_tiles
setblock 473 237 278 minecraft:deepslate_tiles
setblock 473 237 286 minecraft:cobbled_deepslate
setblock 473 237 294 minecraft:cobbled_deepslate
fill 473 237 295 474 237 295 minecraft:deepslate_tiles
setblock 473 237 299 minecraft:cobbled_deepslate
fill 473 237 300 473 240 300 minecraft:deepslate_tiles
setblock 473 237 303 minecraft:deepslate_tiles
setblock 473 237 304 minecraft:cobbled_deepslate
fill 473 237 305 473 237 308 minecraft:deepslate_tiles
setblock 473 237 309 minecraft:cobbled_deepslate
fill 473 237 310 473 238 310 minecraft:deepslate_tiles
setblock 473 237 313 minecraft:deepslate_tiles
setblock 473 237 314 minecraft:cobbled_deepslate
fill 473 237 315 476 237 315 minecraft:deepslate_tiles
setblock 474 237 278 minecraft:cobbled_deepslate
setblock 474 237 285 minecraft:cobbled_deepslate
setblock 474 237 287 minecraft:cobbled_deepslate
setblock 474 237 297 minecraft:deepslate_tiles
setblock 474 237 298 minecraft:cobbled_deepslate
fill 474 237 299 474 240 299 minecraft:deepslate_tiles
setblock 474 237 302 minecraft:deepslate_tiles
setblock 474 237 303 minecraft:cobbled_deepslate
fill 474 237 314 474 239 314 minecraft:deepslate_tiles
setblock 475 237 277 minecraft:cobbled_deepslate
fill 475 237 278 476 237 278 minecraft:deepslate_tiles
setblock 475 237 286 minecraft:cobbled_deepslate
setblock 476 237 276 minecraft:cobbled_deepslate
fill 476 237 277 476 240 277 minecraft:deepslate_tiles
setblock 476 237 316 minecraft:cobbled_deepslate
fill 477 237 276 477 240 276 minecraft:deepslate_tiles
setblock 477 237 315 minecraft:cobbled_deepslate
fill 477 237 316 480 237 316 minecraft:deepslate_tiles
setblock 478 237 314 minecraft:cobbled_deepslate
fill 478 237 315 478 239 315 minecraft:deepslate_tiles
setblock 480 237 277 minecraft:cobbled_deepslate
setblock 481 237 276 minecraft:cobbled_deepslate
setblock 481 237 278 minecraft:light[level=13]
setblock 481 237 286 minecraft:light[level=13]
setblock 481 237 294 minecraft:light[level=13]
setblock 481 237 302 minecraft:light[level=13]
setblock 481 237 310 minecraft:light[level=13]
setblock 481 237 316 minecraft:cobbled_deepslate
fill 482 237 276 482 239 276 minecraft:deepslate_tiles
fill 482 237 316 482 238 316 minecraft:deepslate_tiles
setblock 485 237 276 minecraft:deepslate_tiles
setblock 486 237 276 minecraft:cobbled_deepslate
fill 487 237 276 490 237 276 minecraft:deepslate_tiles
fill 488 237 316 490 237 316 minecraft:deepslate_tiles
setblock 489 237 277 minecraft:deepslate_tiles
setblock 489 237 278 minecraft:light[level=13]
fill 489 237 279 489 240 279 minecraft:cobbled_deepslate
setblock 489 237 286 minecraft:light[level=13]
setblock 489 237 310 minecraft:light[level=13]
fill 490 237 277 490 237 278 minecraft:cobbled_deepslate
fill 490 237 280 490 240 280 minecraft:cobbled_deepslate
setblock 491 237 276 minecraft:cobbled_deepslate
fill 491 237 277 493 237 278 minecraft:deepslate_tiles
fill 491 237 279 491 240 279 minecraft:cobbled_deepslate
setblock 491 237 316 minecraft:cobbled_deepslate
fill 492 237 276 495 237 276 minecraft:deepslate_tiles
setblock 492 237 315 minecraft:cobbled_deepslate
fill 492 237 316 495 237 316 minecraft:deepslate_tiles
setblock 493 237 279 minecraft:cobbled_deepslate
fill 493 237 280 494 238 280 minecraft:white_wool
fill 493 237 315 496 237 315 minecraft:deepslate_tiles
setblock 494 237 277 minecraft:deepslate_tiles
setblock 494 237 278 minecraft:cobbled_deepslate
fill 494 237 279 497 237 279 minecraft:deepslate_tiles
setblock 495 237 277 minecraft:cobbled_deepslate
fill 495 237 278 495 240 278 minecraft:deepslate_tiles
setblock 496 237 276 minecraft:cobbled_deepslate
fill 496 237 277 499 237 277 minecraft:deepslate_tiles
setblock 496 237 316 minecraft:cobbled_deepslate
fill 497 237 276 500 237 276 minecraft:deepslate_tiles
setblock 497 237 286 minecraft:light[level=13]
setblock 497 237 294 minecraft:light[level=13]
setblock 497 237 302 minecraft:light[level=13]
setblock 497 237 310 minecraft:light[level=13]
setblock 497 237 315 minecraft:cobbled_deepslate
fill 497 237 316 500 237 316 minecraft:deepslate_tiles
setblock 498 237 279 minecraft:cobbled_deepslate
fill 498 237 315 498 238 315 minecraft:deepslate_tiles
setblock 499 237 278 minecraft:cobbled_deepslate
fill 499 237 279 499 238 279 minecraft:deepslate_tiles
setblock 500 237 277 minecraft:cobbled_deepslate
fill 500 237 278 500 240 278 minecraft:deepslate_tiles
setblock 501 237 276 minecraft:cobbled_deepslate
fill 501 237 277 501 240 277 minecraft:deepslate_tiles
setblock 501 237 316 minecraft:cobbled_deepslate
fill 502 237 276 505 237 276 minecraft:deepslate_tiles
fill 502 237 316 505 237 316 minecraft:deepslate_tiles
setblock 504 237 278 minecraft:cobbled_deepslate
setblock 505 237 277 minecraft:cobbled_deepslate
setblock 505 237 278 minecraft:light[level=13]
setblock 505 237 286 minecraft:light[level=13]
setblock 505 237 294 minecraft:light[level=13]
setblock 505 237 302 minecraft:light[level=13]
setblock 505 237 310 minecraft:light[level=13]
setblock 506 237 276 minecraft:cobbled_deepslate
fill 506 237 277 506 240 277 minecraft:deepslate_tiles
setblock 506 237 315 minecraft:deepslate_tiles
setblock 506 237 316 minecraft:cobbled_deepslate
fill 507 237 276 507 240 276 minecraft:deepslate_tiles
fill 507 237 278 508 237 278 minecraft:deepslate_tiles
setblock 507 237 315 minecraft:cobbled_deepslate
fill 507 237 316 507 240 316 minecraft:deepslate_tiles
fill 508 237 315 508 240 315 minecraft:deepslate_tiles
setblock 509 237 278 minecraft:cobbled_deepslate
fill 509 237 279 509 240 279 minecraft:deepslate_tiles
setblock 510 237 277 minecraft:cobbled_deepslate
fill 510 237 278 510 240 278 minecraft:deepslate_tiles
setblock 510 237 297 minecraft:cobbled_deepslate
fill 510 237 298 510 239 299 minecraft:deepslate_tiles
setblock 510 237 312 minecraft:cobbled_deepslate
fill 510 237 313 510 240 313 minecraft:deepslate_tiles
setblock 511 237 276 minecraft:cobbled_deepslate
fill 511 237 277 511 240 277 minecraft:deepslate_tiles
setblock 511 237 280 minecraft:deepslate_tiles
setblock 511 237 281 minecraft:cobbled_deepslate
fill 511 237 282 511 240 282 minecraft:deepslate_tiles
setblock 511 237 291 minecraft:cobbled_deepslate
fill 511 237 292 511 237 295 minecraft:deepslate_tiles
setblock 511 237 296 minecraft:cobbled_deepslate
fill 511 237 297 511 240 297 minecraft:deepslate_tiles
fill 511 237 299 511 237 300 minecraft:deepslate_tiles
setblock 511 237 301 minecraft:cobbled_deepslate
fill 511 237 302 511 240 302 minecraft:deepslate_tiles
setblock 511 237 305 minecraft:deepslate_tiles
setblock 511 237 306 minecraft:cobbled_deepslate
fill 511 237 307 511 240 307 minecraft:deepslate_tiles
setblock 511 237 311 minecraft:cobbled_deepslate
fill 511 237 312 511 240 312 minecraft:deepslate_tiles
setblock 511 237 316 minecraft:cobbled_deepslate
fill 471 238 276 473 238 277 minecraft:deepslate_tiles
setblock 471 238 279 minecraft:deepslate_tiles
setblock 471 238 280 minecraft:cobbled_deepslate
fill 471 238 281 472 240 281 minecraft:deepslate_tiles
fill 471 238 283 471 239 283 minecraft:deepslate_tiles
fill 471 238 291 471 238 294 minecraft:deepslate_tiles
setblock 471 238 295 minecraft:cobbled_deepslate
fill 471 238 296 471 238 299 minecraft:deepslate_tiles
setblock 471 238 300 minecraft:cobbled_deepslate
fill 471 238 301 471 238 304 minecraft:deepslate_tiles
setblock 471 238 305 minecraft:cobbled_deepslate
fill 471 238 306 471 238 309 minecraft:deepslate_tiles
setblock 471 238 310 minecraft:cobbled_deepslate
fill 471 238 311 471 238 314 minecraft:deepslate_tiles
setblock 471 238 315 minecraft:cobbled_deepslate
fill 471 238 316 474 238 316 minecraft:deepslate_tiles
setblock 472 238 279 minecraft:cobbled_deepslate
fill 472 238 280 472 241 280 minecraft:deepslate_tiles
fill 472 238 292 472 238 293 minecraft:deepslate_tiles
setblock 472 238 294 minecraft:cobbled_deepslate
fill 472 238 295 473 240 295 minecraft:deepslate_tiles
setblock 472 238 299 minecraft:cobbled_deepslate
fill 472 238 300 472 238 303 minecraft:deepslate_tiles
setblock 472 238 304 minecraft:cobbled_deepslate
fill 472 238 305 472 238 308 minecraft:deepslate_tiles
setblock 472 238 309 minecraft:cobbled_deepslate
fill 472 238 310 472 238 313 minecraft:deepslate_tiles
setblock 472 238 314 minecraft:cobbled_deepslate
fill 472 238 315 475 238 315 minecraft:deepslate_tiles
setblock 473 238 278 minecraft:cobbled_deepslate
fill 473 238 294 473 239 294 minecraft:deepslate_tiles
setblock 473 238 298 minecraft:cobbled_deepslate
fill 473 238 299 473 241 299 minecraft:deepslate_tiles
setblock 473 238 303 minecraft:cobbled_deepslate
fill 473 238 304 473 238 307 minecraft:deepslate_tiles
setblock 473 238 308 minecraft:cobbled_deepslate
setblock 473 238 309 minecraft:deepslate_tiles
setblock 473 238 313 minecraft:cobbled_deepslate
fill 473 238 314 473 239 314 minecraft:deepslate_tiles
setblock 474 238 276 minecraft:deepslate_tiles
setblock 474 238 277 minecraft:cobbled_deepslate
fill 474 238 278 475 238 278 minecraft:deepslate_tiles
setblock 474 238 297 minecraft:cobbled_deepslate
fill 474 238 298 474 241 298 minecraft:deepslate_tiles
setblock 474 238 302 minecraft:cobbled_deepslate
fill 474 238 303 474 240 304 minecraft:deepslate_tiles
setblock 475 238 276 minecraft:cobbled_deepslate
fill 475 238 277 475 241 277 minecraft:deepslate_tiles
setblock 475 238 316 minecraft:cobbled_deepslate
fill 476 238 276 476 241 276 minecraft:deepslate_tiles
setblock 476 238 315 minecraft:cobbled_deepslate
fill 476 238 316 479 238 316 minecraft:deepslate_tiles
fill 477 238 315 477 239 315 minecraft:deepslate_tiles
setblock 479 238 277 minecraft:cobbled_deepslate
setblock 480 238 276 minecraft:cobbled_deepslate
setblock 480 238 316 minecraft:cobbled_deepslate
fill 481 238 276 481 239 276 minecraft:deepslate_tiles
setblock 481 238 316 minecraft:deepslate_tiles
setblock 485 238 276 minecraft:cobbled_deepslate
fill 486 238 276 489 238 276 minecraft:deepslate_tiles
setblock 488 238 277 minecraft:deepslate_tiles
fill 489 238 277 489 238 278 minecraft:cobbled_deepslate
fill 489 238 280 489 240 280 minecraft:cobbled_deepslate
setblock 489 238 316 minecraft:deepslate_tiles
setblock 490 238 276 minecraft:cobbled_deepslate
fill 490 238 277 492 238 278 minecraft:deepslate_tiles
setblock 490 238 316 minecraft:cobbled_deepslate
fill 491 238 276 494 238 276 minecraft:deepslate_tiles
fill 491 238 280 491 240 280 minecraft:cobbled_deepslate
fill 491 238 316 494 238 316 minecraft:deepslate_tiles
setblock 493 238 277 minecraft:deepslate_tiles
setblock 493 238 278 minecraft:cobbled_deepslate
fill 493 238 279 496 238 279 minecraft:deepslate_tiles
fill 493 238 315 495 238 315 minecraft:deepslate_tiles
setblock 494 238 277 minecraft:cobbled_deepslate
fill 494 238 278 494 241 278 minecraft:deepslate_tiles
setblock 495 238 276 minecraft:cobbled_deepslate
fill 495 238 277 498 238 277 minecraft:deepslate_tiles
setblock 495 238 316 minecraft:cobbled_deepslate
fill 496 238 276 499 238 276 minecraft:deepslate_tiles
setblock 496 238 315 minecraft:cobbled_deepslate
fill 496 238 316 499 238 316 minecraft:deepslate_tiles
setblock 497 238 279 minecraft:cobbled_deepslate
fill 497 238 315 497 239 315 minecraft:deepslate_tiles
setblock 498 238 278 minecraft:cobbled_deepslate
fill 498 238 279 498 240 279 minecraft:deepslate_tiles
setblock 499 238 277 minecraft:cobbled_deepslate
fill 499 238 278 499 241 278 minecraft:deepslate_tiles
setblock 500 238 276 minecraft:cobbled_deepslate
fill 500 238 277 500 241 277 minecraft:deepslate_tiles
setblock 500 238 316 minecraft:cobbled_deepslate
fill 501 238 276 504 238 276 minecraft:deepslate_tiles
fill 501 238 316 504 238 316 minecraft:deepslate_tiles
setblock 502 238 278 minecraft:deepslate_tiles
setblock 503 238 278 minecraft:cobbled_deepslate
setblock 504 238 277 minecraft:cobbled_deepslate
fill 504 238 278 507 238 278 minecraft:deepslate_tiles
setblock 505 238 276 minecraft:cobbled_deepslate
fill 505 238 277 505 241 277 minecraft:deepslate_tiles
setblock 505 238 316 minecraft:cobbled_deepslate
fill 506 238 276 506 241 276 minecraft:deepslate_tiles
fill 506 238 316 506 241 316 minecraft:deepslate_tiles
setblock 507 238 315 minecraft:deepslate_tiles
setblock 508 238 278 minecraft:cobbled_deepslate
setblock 509 238 277 minecraft:cobbled_deepslate
fill 509 238 278 509 241 278 minecraft:deepslate_tiles
setblock 510 238 276 minecraft:cobbled_deepslate
fill 510 238 277 510 241 277 minecraft:deepslate_tiles
setblock 510 238 281 minecraft:cobbled_deepslate
fill 510 238 282 510 241 282 minecraft:deepslate_tiles
fill 510 238 297 510 239 297 minecraft:deepslate_tiles
setblock 510 238 300 minecraft:deepslate_tiles
setblock 510 238 301 minecraft:cobbled_deepslate
fill 510 238 312 510 239 312 minecraft:deepslate_tiles
setblock 510 238 316 minecraft:cobbled_deepslate
fill 511 238 276 511 241 276 minecraft:deepslate_tiles
setblock 511 238 280 minecraft:cobbled_deepslate
fill 511 238 281 511 241 281 minecraft:deepslate_tiles
setblock 511 238 285 minecraft:cobbled_deepslate
fill 511 238 292 511 238 294 minecraft:deepslate_tiles
setblock 511 238 295 minecraft:cobbled_deepslate
fill 511 238 296 511 241 296 minecraft:deepslate_tiles
setblock 511 238 299 minecraft:deepslate_tiles
setblock 511 238 300 minecraft:cobbled_deepslate
fill 511 238 301 511 241 301 minecraft:deepslate_tiles
setblock 511 238 305 minecraft:cobbled_deepslate
fill 511 238 306 511 241 306 minecraft:deepslate_tiles
setblock 511 238 310 minecraft:cobbled_deepslate
fill 511 238 311 511 241 311 minecraft:deepslate_tiles
setblock 511 238 315 minecraft:cobbled_deepslate
fill 511 238 316 511 241 316 minecraft:deepslate_tiles
fill 471 239 276 472 239 277 minecraft:deepslate_tiles
setblock 471 239 279 minecraft:cobbled_deepslate
fill 471 239 280 471 242 280 minecraft:deepslate_tiles
setblock 471 239 284 minecraft:cobbled_deepslate
fill 471 239 291 471 239 293 minecraft:deepslate_tiles
setblock 471 239 294 minecraft:cobbled_deepslate
fill 471 239 295 471 239 298 minecraft:deepslate_tiles
setblock 471 239 299 minecraft:cobbled_deepslate
fill 471 239 300 471 239 303 minecraft:deepslate_tiles
setblock 471 239 304 minecraft:cobbled_deepslate
fill 471 239 305 471 239 308 minecraft:deepslate_tiles
setblock 471 239 309 minecraft:cobbled_deepslate
fill 471 239 310 471 239 313 minecraft:deepslate_tiles
setblock 471 239 314 minecraft:cobbled_deepslate
fill 471 239 315 473 239 316 minecraft:deepslate_tiles
setblock 472 239 278 minecraft:cobbled_deepslate
fill 472 239 279 472 242 279 minecraft:deepslate_tiles
setblock 472 239 293 minecraft:cobbled_deepslate
fill 472 239 294 472 241 294 minecraft:deepslate_tiles
setblock 472 239 298 minecraft:cobbled_deepslate
fill 472 239 299 472 239 302 minecraft:deepslate_tiles
setblock 472 239 303 minecraft:cobbled_deepslate
fill 472 239 304 472 239 307 minecraft:deepslate_tiles
setblock 472 239 308 minecraft:cobbled_deepslate
fill 472 239 309 472 239 312 minecraft:deepslate_tiles
setblock 472 239 313 minecraft:cobbled_deepslate
fill 472 239 314 472 242 314 minecraft:deepslate_tiles
setblock 473 239 276 minecraft:deepslate_tiles
setblock 473 239 277 minecraft:cobbled_deepslate
fill 473 239 278 474 239 278 minecraft:deepslate_tiles
setblock 473 239 296 minecraft:deepslate_tiles
setblock 473 239 297 minecraft:cobbled_deepslate
fill 473 239 298 473 242 298 minecraft:deepslate_tiles
setblock 473 239 301 minecraft:deepslate_tiles
setblock 473 239 302 minecraft:cobbled_deepslate
fill 473 239 303 473 239 306 minecraft:deepslate_tiles
setblock 473 239 307 minecraft:cobbled_deepslate
fill 473 239 308 473 240 308 minecraft:deepslate_tiles
setblock 473 239 313 minecraft:deepslate_tiles
setblock 474 239 276 minecraft:cobbled_deepslate
fill 474 239 277 474 242 277 minecraft:deepslate_tiles
setblock 474 239 296 minecraft:cobbled_deepslate
schedule function dropper:buildpart/70_10 1t
