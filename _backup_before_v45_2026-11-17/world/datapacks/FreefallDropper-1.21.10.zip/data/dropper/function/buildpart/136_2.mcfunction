fill 205 208 571 205 208 584 minecraft:quartz_block
fill 206 208 568 206 208 569 minecraft:gold_block
fill 206 208 576 206 209 579 minecraft:quartz_block
fill 206 208 586 206 208 587 minecraft:gold_block
fill 207 208 571 207 208 575 minecraft:quartz_block
fill 207 208 579 207 208 584 minecraft:quartz_block
fill 208 208 599 208 210 599 minecraft:yellow_terracotta
fill 217 208 557 217 210 557 minecraft:yellow_terracotta
setblock 218 208 557 minecraft:gold_block
fill 223 208 557 223 210 557 minecraft:yellow_terracotta
setblock 224 208 557 minecraft:gold_block
fill 225 208 557 228 210 557 minecraft:yellow_terracotta
setblock 229 208 557 minecraft:gold_block
fill 230 208 557 230 210 557 minecraft:yellow_terracotta
fill 230 208 562 230 210 564 minecraft:yellow_terracotta
setblock 230 208 565 minecraft:gold_block
fill 230 208 566 230 208 567 minecraft:yellow_terracotta
setblock 230 208 569 minecraft:gold_block
fill 188 209 557 188 210 557 minecraft:yellow_terracotta
fill 188 209 559 188 210 559 minecraft:yellow_terracotta
fill 188 209 573 188 210 573 minecraft:yellow_terracotta
setblock 188 209 574 minecraft:gold_block
fill 188 209 579 188 210 580 minecraft:yellow_terracotta
fill 188 209 596 188 210 596 minecraft:yellow_terracotta
setblock 193 209 557 minecraft:gold_block
fill 194 209 557 194 210 557 minecraft:yellow_terracotta
fill 194 209 599 195 210 599 minecraft:yellow_terracotta
setblock 196 209 599 minecraft:gold_block
fill 199 209 557 200 210 557 minecraft:yellow_terracotta
setblock 201 209 557 minecraft:gold_block
fill 202 209 557 206 210 557 minecraft:yellow_terracotta
fill 205 209 575 205 209 580 minecraft:quartz_block
fill 206 209 570 206 209 572 minecraft:gold_block
fill 206 209 573 206 209 575 minecraft:quartz_block
fill 206 209 580 206 209 582 minecraft:quartz_block
fill 206 209 583 206 209 585 minecraft:gold_block
setblock 207 209 575 minecraft:quartz_block
fill 207 209 579 207 209 580 minecraft:quartz_block
setblock 211 209 557 minecraft:gold_block
fill 212 209 557 214 210 557 minecraft:yellow_terracotta
setblock 215 209 557 minecraft:gold_block
fill 218 209 557 218 210 557 minecraft:yellow_terracotta
fill 220 209 599 220 210 599 minecraft:yellow_terracotta
setblock 221 209 599 minecraft:gold_block
fill 224 209 557 224 211 557 minecraft:yellow_terracotta
fill 229 209 557 229 211 557 minecraft:yellow_terracotta
fill 230 209 565 230 210 566 minecraft:yellow_terracotta
fill 230 209 567 230 209 568 minecraft:gold_block
fill 230 209 569 230 212 569 minecraft:yellow_terracotta
setblock 188 210 574 minecraft:yellow_terracotta
setblock 191 210 560 minecraft:light[level=14]
setblock 191 210 568 minecraft:light[level=14]
setblock 191 210 576 minecraft:light[level=14]
setblock 191 210 584 minecraft:light[level=14]
setblock 191 210 592 minecraft:light[level=14]
setblock 193 210 557 minecraft:yellow_terracotta
fill 196 210 599 196 211 599 minecraft:yellow_terracotta
setblock 199 210 560 minecraft:light[level=14]
setblock 199 210 568 minecraft:light[level=14]
setblock 199 210 576 minecraft:light[level=14]
setblock 199 210 584 minecraft:light[level=14]
setblock 199 210 592 minecraft:light[level=14]
setblock 201 210 557 minecraft:yellow_terracotta
fill 206 210 573 206 210 582 minecraft:gold_block
setblock 207 210 560 minecraft:light[level=14]
setblock 207 210 568 minecraft:light[level=14]
setblock 207 210 576 minecraft:light[level=14]
setblock 207 210 584 minecraft:light[level=14]
setblock 207 210 592 minecraft:light[level=14]
fill 211 210 557 211 211 557 minecraft:yellow_terracotta
fill 215 210 557 215 212 557 minecraft:yellow_terracotta
setblock 215 210 560 minecraft:light[level=14]
setblock 215 210 568 minecraft:light[level=14]
setblock 215 210 576 minecraft:light[level=14]
setblock 215 210 584 minecraft:light[level=14]
setblock 215 210 592 minecraft:light[level=14]
setblock 221 210 599 minecraft:yellow_terracotta
setblock 223 210 560 minecraft:light[level=14]
setblock 223 210 568 minecraft:light[level=14]
setblock 223 210 576 minecraft:light[level=14]
setblock 223 210 584 minecraft:light[level=14]
setblock 223 210 592 minecraft:light[level=14]
fill 230 210 567 230 210 568 minecraft:yellow_terracotta
fill 188 211 557 188 211 562 minecraft:gold_block
fill 188 211 567 188 212 570 minecraft:gold_block
fill 188 211 572 188 307 574 minecraft:gold_block
fill 188 211 579 188 307 579 minecraft:gold_block
setblock 188 211 580 minecraft:yellow_terracotta
fill 188 211 581 188 212 586 minecraft:gold_block
fill 188 211 591 188 211 598 minecraft:gold_block
fill 189 211 557 194 212 557 minecraft:gold_block
fill 192 211 599 195 307 599 minecraft:gold_block
fill 197 211 599 197 307 599 minecraft:gold_block
fill 198 211 599 198 212 599 minecraft:yellow_terracotta
fill 199 211 557 206 211 557 minecraft:gold_block
fill 199 211 599 199 307 599 minecraft:gold_block
fill 204 211 599 208 211 599 minecraft:gold_block
setblock 209 211 599 minecraft:yellow_terracotta
fill 210 211 599 210 307 599 minecraft:gold_block
setblock 211 211 599 minecraft:yellow_terracotta
setblock 212 211 557 minecraft:yellow_terracotta
fill 213 211 557 214 212 557 minecraft:gold_block
fill 216 211 557 218 307 557 minecraft:gold_block
fill 216 211 596 216 225 596 minecraft:red_wool
fill 216 211 599 223 211 599 minecraft:gold_block
fill 223 211 557 223 307 557 minecraft:gold_block
fill 225 211 557 228 211 557 minecraft:gold_block
fill 228 211 599 230 211 599 minecraft:gold_block
fill 230 211 557 230 307 557 minecraft:gold_block
fill 230 211 562 230 211 563 minecraft:yellow_terracotta
fill 230 211 564 230 212 566 minecraft:gold_block
setblock 230 211 567 minecraft:yellow_terracotta
fill 230 211 568 230 307 568 minecraft:gold_block
fill 230 211 574 230 307 579 minecraft:gold_block
setblock 230 211 580 minecraft:yellow_terracotta
fill 230 211 581 230 307 581 minecraft:gold_block
fill 230 211 586 230 211 593 minecraft:gold_block
fill 230 211 598 230 307 598 minecraft:gold_block
fill 188 212 557 188 213 557 minecraft:yellow_terracotta
fill 188 212 558 188 225 563 minecraft:gold_block
fill 188 212 564 188 212 565 minecraft:ochre_froglight
setblock 188 212 566 minecraft:yellow_terracotta
fill 188 212 571 188 307 571 minecraft:gold_block
fill 188 212 575 188 225 575 minecraft:gold_block
fill 188 212 576 188 212 577 minecraft:ochre_froglight
setblock 188 212 578 minecraft:gold_block
fill 188 212 580 188 307 580 minecraft:gold_block
fill 188 212 587 188 225 587 minecraft:gold_block
fill 188 212 588 188 212 589 minecraft:ochre_froglight
fill 188 212 590 188 212 591 minecraft:gold_block
setblock 188 212 592 minecraft:yellow_terracotta
fill 188 212 593 188 212 599 minecraft:gold_block
fill 189 212 599 190 212 599 minecraft:ochre_froglight
fill 191 212 599 191 225 599 minecraft:gold_block
fill 195 212 557 195 225 557 minecraft:gold_block
fill 196 212 557 197 212 557 minecraft:ochre_froglight
fill 196 212 599 196 307 599 minecraft:gold_block
fill 198 212 557 203 212 557 minecraft:gold_block
fill 200 212 599 200 225 599 minecraft:gold_block
fill 201 212 599 202 212 599 minecraft:ochre_froglight
fill 203 212 599 206 225 599 minecraft:gold_block
setblock 204 212 557 minecraft:yellow_terracotta
fill 205 212 557 207 225 557 minecraft:gold_block
setblock 207 212 599 minecraft:yellow_terracotta
fill 208 212 557 209 212 557 minecraft:ochre_froglight
fill 208 212 599 209 212 599 minecraft:gold_block
fill 210 212 557 212 212 557 minecraft:gold_block
fill 211 212 599 211 307 599 minecraft:gold_block
setblock 212 212 599 minecraft:yellow_terracotta
fill 213 212 599 214 212 599 minecraft:ochre_froglight
fill 214 212 596 215 225 596 minecraft:red_wool
setblock 215 212 599 minecraft:yellow_terracotta
fill 216 212 599 217 212 599 minecraft:gold_block
fill 217 212 596 218 225 596 minecraft:red_wool
fill 218 212 599 218 213 599 minecraft:yellow_terracotta
fill 219 212 557 219 225 557 minecraft:gold_block
fill 219 212 599 220 307 599 minecraft:gold_block
fill 220 212 557 221 212 557 minecraft:ochre_froglight
setblock 221 212 599 minecraft:yellow_terracotta
setblock 222 212 557 minecraft:gold_block
fill 222 212 599 224 225 599 minecraft:gold_block
fill 224 212 557 226 307 557 minecraft:gold_block
fill 225 212 599 226 212 599 minecraft:ochre_froglight
fill 227 212 557 228 212 557 minecraft:yellow_terracotta
fill 227 212 599 229 225 599 minecraft:gold_block
fill 229 212 557 229 307 557 minecraft:gold_block
setblock 230 212 558 minecraft:gold_block
fill 230 212 559 230 212 560 minecraft:ochre_froglight
fill 230 212 561 230 225 563 minecraft:gold_block
setblock 230 212 567 minecraft:gold_block
fill 230 212 570 230 225 570 minecraft:gold_block
fill 230 212 571 230 212 572 minecraft:ochre_froglight
fill 230 212 573 230 225 573 minecraft:gold_block
fill 230 212 580 230 307 580 minecraft:gold_block
fill 230 212 582 230 225 582 minecraft:gold_block
fill 230 212 583 230 212 584 minecraft:ochre_froglight
fill 230 212 585 230 225 585 minecraft:gold_block
setblock 230 212 586 minecraft:yellow_terracotta
fill 230 212 587 230 212 592 minecraft:gold_block
setblock 230 212 593 minecraft:yellow_terracotta
fill 230 212 594 230 225 594 minecraft:gold_block
fill 230 212 595 230 212 596 minecraft:ochre_froglight
fill 230 212 597 230 225 597 minecraft:gold_block
setblock 230 212 599 minecraft:yellow_terracotta
fill 188 213 564 188 225 566 minecraft:gold_block
setblock 188 213 567 minecraft:yellow_terracotta
fill 188 213 568 188 307 569 minecraft:gold_block
setblock 188 213 570 minecraft:yellow_terracotta
fill 188 213 576 188 225 577 minecraft:gold_block
setblock 188 213 578 minecraft:yellow_terracotta
fill 188 213 581 188 307 582 minecraft:gold_block
setblock 188 213 583 minecraft:yellow_terracotta
fill 188 213 584 188 307 586 minecraft:gold_block
fill 188 213 588 188 225 590 minecraft:gold_block
setblock 188 213 591 minecraft:yellow_terracotta
fill 188 213 592 188 307 592 minecraft:gold_block
setblock 188 213 593 minecraft:yellow_terracotta
fill 188 213 594 188 307 596 minecraft:gold_block
setblock 188 213 597 minecraft:yellow_terracotta
fill 188 213 598 188 225 599 minecraft:gold_block
setblock 189 213 557 minecraft:yellow_terracotta
fill 189 213 599 189 225 599 minecraft:gold_block
fill 190 213 557 194 307 557 minecraft:gold_block
setblock 190 213 599 minecraft:yellow_terracotta
fill 196 213 557 201 225 557 minecraft:gold_block
fill 198 213 599 198 307 599 minecraft:gold_block
fill 201 213 599 202 225 599 minecraft:gold_block
setblock 202 213 557 minecraft:yellow_terracotta
fill 203 213 557 204 307 557 minecraft:gold_block
fill 207 213 599 207 307 599 minecraft:gold_block
fill 208 213 557 211 225 557 minecraft:gold_block
fill 208 213 599 209 213 599 minecraft:yellow_terracotta
fill 212 213 557 213 213 557 minecraft:yellow_terracotta
fill 212 213 599 216 225 599 minecraft:gold_block
fill 214 213 557 215 307 557 minecraft:gold_block
setblock 217 213 599 minecraft:yellow_terracotta
fill 220 213 557 221 225 557 minecraft:gold_block
fill 221 213 599 221 307 599 minecraft:gold_block
setblock 222 213 557 minecraft:yellow_terracotta
fill 224 213 561 224 213 563 minecraft:yellow_terracotta
fill 225 213 560 227 213 560 minecraft:yellow_terracotta
setblock 225 213 564 minecraft:yellow_terracotta
fill 225 213 599 226 225 599 minecraft:gold_block
fill 227 213 557 228 307 557 minecraft:gold_block
setblock 227 213 564 minecraft:yellow_terracotta
fill 228 213 561 228 213 563 minecraft:yellow_terracotta
setblock 230 213 558 minecraft:yellow_terracotta
fill 230 213 559 230 225 560 minecraft:gold_block
fill 230 213 564 230 307 564 minecraft:gold_block
fill 230 213 565 230 213 567 minecraft:yellow_terracotta
fill 230 213 569 230 307 569 minecraft:gold_block
fill 230 213 571 230 225 572 minecraft:gold_block
fill 230 213 583 230 225 584 minecraft:gold_block
fill 230 213 586 230 307 588 minecraft:gold_block
setblock 230 213 589 minecraft:yellow_terracotta
fill 230 213 590 230 285 591 minecraft:gold_block
setblock 230 213 592 minecraft:yellow_terracotta
fill 230 213 593 230 285 593 minecraft:gold_block
fill 230 213 595 230 225 596 minecraft:gold_block
fill 230 213 599 230 307 599 minecraft:gold_block
fill 188 214 557 189 307 557 minecraft:gold_block
fill 188 214 567 188 307 567 minecraft:gold_block
fill 188 214 570 188 307 570 minecraft:gold_block
fill 188 214 578 188 225 578 minecraft:gold_block
fill 188 214 583 188 307 583 minecraft:gold_block
fill 188 214 591 188 307 591 minecraft:gold_block
fill 188 214 593 188 307 593 minecraft:gold_block
fill 188 214 597 188 307 597 minecraft:gold_block
fill 190 214 599 190 225 599 minecraft:gold_block
fill 202 214 557 202 307 557 minecraft:gold_block
fill 208 214 599 209 307 599 minecraft:gold_block
fill 212 214 557 213 307 557 minecraft:gold_block
fill 212 214 559 218 215 559 minecraft:gold_block
fill 217 214 599 218 307 599 minecraft:gold_block
fill 222 214 557 222 225 557 minecraft:gold_block
fill 230 214 558 230 225 558 minecraft:gold_block
fill 230 214 565 230 307 567 minecraft:gold_block
fill 230 214 589 230 285 589 minecraft:gold_block
fill 230 214 592 230 307 592 minecraft:gold_block
setblock 191 218 560 minecraft:light[level=14]
setblock 191 218 568 minecraft:light[level=14]
setblock 191 218 576 minecraft:light[level=14]
setblock 191 218 584 minecraft:light[level=14]
setblock 191 218 592 minecraft:light[level=14]
fill 197 218 577 198 219 577 minecraft:gold_block
setblock 199 218 560 minecraft:light[level=14]
setblock 199 218 568 minecraft:light[level=14]
setblock 199 218 576 minecraft:light[level=14]
setblock 199 218 584 minecraft:light[level=14]
setblock 199 218 592 minecraft:light[level=14]
setblock 207 218 560 minecraft:light[level=14]
setblock 207 218 568 minecraft:light[level=14]
setblock 207 218 576 minecraft:light[level=14]
setblock 207 218 584 minecraft:light[level=14]
setblock 207 218 592 minecraft:light[level=14]
setblock 215 218 560 minecraft:light[level=14]
setblock 215 218 568 minecraft:light[level=14]
setblock 215 218 576 minecraft:light[level=14]
setblock 215 218 584 minecraft:light[level=14]
setblock 215 218 592 minecraft:light[level=14]
fill 220 218 563 222 219 564 minecraft:raw_gold_block
setblock 223 218 560 minecraft:light[level=14]
setblock 223 218 568 minecraft:light[level=14]
setblock 223 218 576 minecraft:light[level=14]
setblock 223 218 584 minecraft:light[level=14]
setblock 223 218 592 minecraft:light[level=14]
fill 190 220 567 190 225 569 minecraft:quartz_block
fill 190 220 579 190 225 581 minecraft:quartz_block
fill 190 220 591 190 225 593 minecraft:quartz_block
fill 196 220 597 198 225 597 minecraft:quartz_block
fill 200 220 559 202 225 559 minecraft:quartz_block
fill 208 220 597 210 225 597 minecraft:quartz_block
fill 212 220 559 214 225 559 minecraft:quartz_block
fill 220 220 597 222 225 597 minecraft:quartz_block
fill 224 220 559 226 225 559 minecraft:quartz_block
fill 228 220 567 228 225 569 minecraft:quartz_block
fill 228 220 579 228 225 581 minecraft:quartz_block
fill 228 220 591 228 225 593 minecraft:quartz_block
fill 224 221 561 224 221 563 minecraft:yellow_terracotta
fill 225 221 560 227 221 560 minecraft:yellow_terracotta
setblock 225 221 564 minecraft:yellow_terracotta
setblock 227 221 564 minecraft:yellow_terracotta
fill 228 221 561 228 221 563 minecraft:yellow_terracotta
fill 189 225 561 189 225 566 minecraft:yellow_terracotta
fill 189 225 573 189 225 578 minecraft:yellow_terracotta
fill 189 225 585 189 225 590 minecraft:yellow_terracotta
fill 189 225 597 189 225 598 minecraft:yellow_terracotta
fill 190 225 598 193 225 598 minecraft:yellow_terracotta
fill 193 225 558 198 225 558 minecraft:yellow_terracotta
fill 200 225 598 205 225 598 minecraft:yellow_terracotta
fill 205 225 558 210 225 558 minecraft:yellow_terracotta
fill 212 225 598 217 225 598 minecraft:yellow_terracotta
fill 217 225 558 222 225 558 minecraft:yellow_terracotta
fill 224 225 598 229 225 598 minecraft:yellow_terracotta
fill 229 225 558 229 225 563 minecraft:yellow_terracotta
fill 229 225 570 229 225 575 minecraft:yellow_terracotta
fill 229 225 582 229 225 587 minecraft:yellow_terracotta
fill 229 225 594 229 225 597 minecraft:yellow_terracotta
fill 188 226 558 188 307 562 minecraft:gold_block
fill 188 226 563 188 228 566 minecraft:ochre_froglight
fill 188 226 575 188 228 578 minecraft:ochre_froglight
fill 188 226 587 188 228 590 minecraft:ochre_froglight
fill 188 226 598 188 307 598 minecraft:gold_block
fill 188 226 599 191 228 599 minecraft:ochre_froglight
setblock 191 226 560 minecraft:light[level=14]
setblock 191 226 568 minecraft:light[level=14]
setblock 191 226 576 minecraft:light[level=14]
setblock 191 226 584 minecraft:light[level=14]
setblock 191 226 592 minecraft:light[level=14]
fill 195 226 557 198 228 557 minecraft:ochre_froglight
fill 199 226 557 201 307 557 minecraft:gold_block
setblock 199 226 560 minecraft:light[level=14]
setblock 199 226 568 minecraft:light[level=14]
setblock 199 226 576 minecraft:light[level=14]
setblock 199 226 584 minecraft:light[level=14]
setblock 199 226 592 minecraft:light[level=14]
fill 200 226 599 203 228 599 minecraft:ochre_froglight
fill 204 226 599 206 307 599 minecraft:gold_block
fill 205 226 557 206 307 557 minecraft:gold_block
fill 207 226 557 210 228 557 minecraft:ochre_froglight
setblock 207 226 560 minecraft:light[level=14]
setblock 207 226 568 minecraft:light[level=14]
setblock 207 226 576 minecraft:light[level=14]
setblock 207 226 584 minecraft:light[level=14]
setblock 207 226 592 minecraft:light[level=14]
fill 211 226 557 211 307 557 minecraft:gold_block
fill 212 226 599 215 228 599 minecraft:ochre_froglight
fill 213 226 596 219 227 596 minecraft:gold_block
setblock 215 226 560 minecraft:light[level=14]
setblock 215 226 568 minecraft:light[level=14]
setblock 215 226 576 minecraft:light[level=14]
setblock 215 226 584 minecraft:light[level=14]
setblock 215 226 592 minecraft:light[level=14]
fill 216 226 599 216 307 599 minecraft:gold_block
fill 219 226 557 222 228 557 minecraft:ochre_froglight
fill 222 226 599 223 307 599 minecraft:gold_block
setblock 223 226 560 minecraft:light[level=14]
setblock 223 226 568 minecraft:light[level=14]
setblock 223 226 576 minecraft:light[level=14]
setblock 223 226 584 minecraft:light[level=14]
setblock 223 226 592 minecraft:light[level=14]
fill 224 226 599 227 228 599 minecraft:ochre_froglight
fill 228 226 599 229 307 599 minecraft:gold_block
fill 230 226 558 230 228 561 minecraft:ochre_froglight
fill 230 226 562 230 307 563 minecraft:gold_block
fill 230 226 570 230 228 573 minecraft:ochre_froglight
fill 230 226 582 230 228 585 minecraft:ochre_froglight
fill 230 226 594 230 228 597 minecraft:ochre_froglight
fill 224 227 561 224 228 563 minecraft:gold_block
fill 225 227 564 225 228 564 minecraft:gold_block
fill 226 227 560 226 228 560 minecraft:gold_block
fill 227 227 564 227 228 564 minecraft:gold_block
fill 228 227 561 228 228 563 minecraft:gold_block
fill 188 229 563 188 245 566 minecraft:gold_block
fill 188 229 575 188 245 578 minecraft:gold_block
fill 188 229 587 188 245 590 minecraft:gold_block
fill 188 229 599 191 245 599 minecraft:gold_block
fill 195 229 557 198 245 557 minecraft:gold_block
fill 200 229 599 203 245 599 minecraft:gold_block
fill 207 229 557 210 245 557 minecraft:gold_block
fill 212 229 599 215 245 599 minecraft:gold_block
fill 219 229 557 222 245 557 minecraft:gold_block
fill 224 229 599 227 245 599 minecraft:gold_block
fill 230 229 558 230 245 561 minecraft:gold_block
fill 230 229 570 230 245 573 minecraft:gold_block
fill 230 229 582 230 245 585 minecraft:gold_block
fill 230 229 594 230 245 597 minecraft:gold_block
fill 204 233 579 206 233 581 minecraft:redstone_block
fill 205 233 572 207 233 574 minecraft:redstone_block
fill 211 233 572 213 233 574 minecraft:redstone_block
fill 212 233 579 214 233 581 minecraft:redstone_block
fill 189 234 558 192 234 560 minecraft:gold_block
fill 189 234 561 192 234 564 minecraft:red_wool
fill 189 234 565 192 234 568 minecraft:gold_block
fill 189 234 569 192 234 572 minecraft:red_wool
fill 189 234 573 192 234 576 minecraft:gold_block
fill 189 234 577 192 234 580 minecraft:red_wool
fill 189 234 581 192 234 584 minecraft:gold_block
fill 189 234 585 192 234 588 minecraft:red_wool
fill 189 234 589 192 234 592 minecraft:gold_block
fill 189 234 593 192 234 596 minecraft:red_wool
fill 189 234 597 192 234 598 minecraft:gold_block
fill 193 234 558 196 234 560 minecraft:red_wool
fill 193 234 561 196 234 564 minecraft:gold_block
fill 193 234 565 196 234 568 minecraft:red_wool
fill 193 234 569 196 234 572 minecraft:gold_block
fill 193 234 573 196 234 576 minecraft:red_wool
fill 193 234 577 196 234 580 minecraft:gold_block
fill 193 234 581 196 234 584 minecraft:red_wool
fill 193 234 585 196 234 588 minecraft:gold_block
fill 193 234 589 196 234 592 minecraft:red_wool
fill 193 234 593 196 234 596 minecraft:gold_block
fill 193 234 597 196 234 598 minecraft:red_wool
fill 197 234 558 200 234 560 minecraft:gold_block
fill 197 234 561 200 234 564 minecraft:red_wool
fill 197 234 565 200 234 568 minecraft:gold_block
fill 197 234 569 200 234 572 minecraft:red_wool
fill 197 234 573 200 234 576 minecraft:gold_block
fill 197 234 577 200 234 580 minecraft:red_wool
fill 197 234 581 200 234 584 minecraft:gold_block
fill 197 234 585 200 234 588 minecraft:red_wool
fill 197 234 589 200 234 592 minecraft:gold_block
fill 197 234 593 200 234 596 minecraft:red_wool
fill 197 234 597 200 234 598 minecraft:gold_block
fill 201 234 558 204 234 560 minecraft:red_wool
fill 201 234 561 204 234 564 minecraft:gold_block
fill 201 234 565 204 234 568 minecraft:red_wool
fill 201 234 569 204 234 572 minecraft:gold_block
fill 201 234 573 204 234 576 minecraft:red_wool
fill 201 234 577 203 234 580 minecraft:gold_block
fill 201 234 581 203 234 584 minecraft:red_wool
fill 201 234 585 204 234 588 minecraft:gold_block
fill 201 234 589 204 234 592 minecraft:red_wool
fill 201 234 593 204 234 596 minecraft:gold_block
fill 201 234 597 204 234 598 minecraft:red_wool
fill 204 234 577 204 234 578 minecraft:gold_block
fill 204 234 582 204 234 584 minecraft:red_wool
fill 205 234 558 208 234 560 minecraft:gold_block
fill 205 234 561 208 234 564 minecraft:red_wool
fill 205 234 565 208 234 568 minecraft:gold_block
fill 205 234 569 208 234 571 minecraft:red_wool
fill 205 234 575 207 234 576 minecraft:gold_block
fill 205 234 577 207 234 578 minecraft:red_wool
fill 205 234 582 208 234 584 minecraft:gold_block
fill 205 234 585 208 234 588 minecraft:red_wool
fill 205 234 589 208 234 592 minecraft:gold_block
fill 205 234 593 208 234 596 minecraft:red_wool
fill 205 234 597 208 234 598 minecraft:gold_block
fill 207 234 579 208 234 580 minecraft:red_wool
fill 207 234 581 208 234 581 minecraft:gold_block
setblock 208 234 572 minecraft:red_wool
fill 208 234 573 208 234 575 minecraft:gold_block
fill 209 234 558 212 234 560 minecraft:red_wool
fill 209 234 561 212 234 564 minecraft:gold_block
fill 209 234 565 212 234 568 minecraft:red_wool
fill 209 234 569 210 234 572 minecraft:gold_block
fill 209 234 573 210 234 575 minecraft:red_wool
fill 209 234 579 211 234 580 minecraft:gold_block
fill 209 234 581 211 234 584 minecraft:red_wool
fill 209 234 585 212 234 588 minecraft:gold_block
fill 209 234 589 212 234 592 minecraft:red_wool
fill 209 234 593 212 234 596 minecraft:gold_block
fill 209 234 597 212 234 598 minecraft:red_wool
fill 211 234 569 212 234 571 minecraft:gold_block
fill 211 234 575 212 234 576 minecraft:red_wool
fill 211 234 577 212 234 578 minecraft:gold_block
fill 212 234 582 212 234 584 minecraft:red_wool
fill 213 234 558 216 234 560 minecraft:gold_block
fill 213 234 561 216 234 564 minecraft:red_wool
fill 213 234 565 216 234 568 minecraft:gold_block
fill 213 234 569 216 234 571 minecraft:red_wool
fill 213 234 575 216 234 576 minecraft:gold_block
fill 213 234 577 216 234 578 minecraft:red_wool
fill 213 234 582 216 234 584 minecraft:gold_block
fill 213 234 585 216 234 588 minecraft:red_wool
fill 213 234 589 216 234 592 minecraft:gold_block
fill 213 234 593 216 234 596 minecraft:red_wool
fill 213 234 597 216 234 598 minecraft:gold_block
fill 214 234 572 216 234 572 minecraft:red_wool
fill 214 234 573 216 234 574 minecraft:gold_block
fill 215 234 579 216 234 580 minecraft:red_wool
fill 215 234 581 216 234 581 minecraft:gold_block
fill 217 234 558 220 234 560 minecraft:red_wool
fill 217 234 561 220 234 564 minecraft:gold_block
fill 217 234 565 220 234 568 minecraft:red_wool
fill 217 234 569 220 234 572 minecraft:gold_block
fill 217 234 573 220 234 576 minecraft:red_wool
fill 217 234 577 220 234 580 minecraft:gold_block
fill 217 234 581 220 234 584 minecraft:red_wool
fill 217 234 585 220 234 588 minecraft:gold_block
fill 217 234 589 220 234 592 minecraft:red_wool
fill 217 234 593 220 234 596 minecraft:gold_block
fill 217 234 597 220 234 598 minecraft:red_wool
fill 221 234 558 224 234 560 minecraft:gold_block
fill 221 234 561 224 234 564 minecraft:red_wool
fill 221 234 565 224 234 568 minecraft:gold_block
fill 221 234 569 224 234 572 minecraft:red_wool
fill 221 234 573 224 234 576 minecraft:gold_block
fill 221 234 577 224 234 580 minecraft:red_wool
fill 221 234 581 224 234 584 minecraft:gold_block
fill 221 234 585 224 234 588 minecraft:red_wool
fill 221 234 589 224 234 592 minecraft:gold_block
fill 221 234 593 224 234 596 minecraft:red_wool
fill 221 234 597 224 234 598 minecraft:gold_block
fill 225 234 558 228 234 560 minecraft:red_wool
fill 225 234 561 228 234 564 minecraft:gold_block
fill 225 234 565 228 234 568 minecraft:red_wool
fill 225 234 569 228 234 572 minecraft:gold_block
fill 225 234 573 228 234 576 minecraft:red_wool
fill 225 234 577 228 234 580 minecraft:gold_block
fill 225 234 581 228 234 584 minecraft:red_wool
fill 225 234 585 228 234 588 minecraft:gold_block
fill 225 234 589 228 234 592 minecraft:red_wool
fill 225 234 593 228 234 596 minecraft:gold_block
fill 225 234 597 228 234 598 minecraft:red_wool
fill 229 234 558 229 234 560 minecraft:gold_block
fill 229 234 561 229 234 564 minecraft:red_wool
fill 229 234 565 229 234 568 minecraft:gold_block
fill 229 234 569 229 234 572 minecraft:red_wool
fill 229 234 573 229 234 576 minecraft:gold_block
fill 229 234 577 229 234 580 minecraft:red_wool
fill 229 234 581 229 234 584 minecraft:gold_block
fill 229 234 585 229 234 588 minecraft:red_wool
fill 229 234 589 229 234 592 minecraft:gold_block
fill 229 234 593 229 234 596 minecraft:red_wool
fill 229 234 597 229 234 598 minecraft:gold_block
fill 189 235 558 189 235 598 minecraft:quartz_block
fill 190 235 558 192 235 560 minecraft:gold_block
fill 190 235 561 229 235 561 minecraft:quartz_block
fill 190 235 562 192 235 564 minecraft:red_wool
fill 190 235 565 229 235 565 minecraft:quartz_block
fill 190 235 566 192 235 568 minecraft:gold_block
fill 190 235 569 229 235 569 minecraft:quartz_block
fill 190 235 570 192 235 572 minecraft:red_wool
fill 190 235 573 203 235 573 minecraft:quartz_block
fill 190 235 574 192 235 576 minecraft:gold_block
fill 190 235 577 206 235 577 minecraft:quartz_block
fill 190 235 578 192 235 580 minecraft:red_wool
fill 190 235 581 202 235 581 minecraft:quartz_block
fill 190 235 582 192 235 584 minecraft:gold_block
fill 190 235 585 229 235 585 minecraft:quartz_block
fill 190 235 586 192 235 588 minecraft:red_wool
fill 190 235 589 229 235 589 minecraft:quartz_block
fill 190 235 590 192 235 592 minecraft:gold_block
fill 190 235 593 229 235 593 minecraft:quartz_block
fill 190 235 594 192 235 596 minecraft:red_wool
fill 190 235 597 229 235 597 minecraft:quartz_block
fill 190 235 598 192 235 598 minecraft:gold_block
fill 193 235 558 193 235 560 minecraft:quartz_block
fill 193 235 562 193 235 564 minecraft:quartz_block
fill 193 235 566 193 235 568 minecraft:quartz_block
fill 193 235 570 193 235 572 minecraft:quartz_block
fill 193 235 574 193 235 576 minecraft:quartz_block
fill 193 235 578 193 235 580 minecraft:quartz_block
fill 193 235 582 193 235 584 minecraft:quartz_block
fill 193 235 586 193 235 588 minecraft:quartz_block
fill 193 235 590 193 235 592 minecraft:quartz_block
fill 193 235 594 193 235 596 minecraft:quartz_block
setblock 193 235 598 minecraft:quartz_block
fill 194 235 558 196 235 560 minecraft:red_wool
fill 194 235 562 196 235 564 minecraft:gold_block
fill 194 235 566 196 235 568 minecraft:red_wool
fill 194 235 570 196 235 572 minecraft:gold_block
fill 194 235 574 196 235 576 minecraft:red_wool
fill 194 235 578 196 235 580 minecraft:gold_block
fill 194 235 582 196 235 584 minecraft:red_wool
fill 194 235 586 196 235 588 minecraft:gold_block
fill 194 235 590 196 235 592 minecraft:red_wool
fill 194 235 594 196 235 596 minecraft:gold_block
fill 194 235 598 196 235 598 minecraft:red_wool
fill 197 235 558 197 235 560 minecraft:quartz_block
fill 197 235 562 197 235 564 minecraft:quartz_block
fill 197 235 566 197 235 568 minecraft:quartz_block
fill 197 235 570 197 235 572 minecraft:quartz_block
fill 197 235 574 197 235 576 minecraft:quartz_block
fill 197 235 578 197 235 580 minecraft:quartz_block
fill 197 235 582 197 235 584 minecraft:quartz_block
fill 197 235 586 197 235 588 minecraft:quartz_block
fill 197 235 590 197 235 592 minecraft:quartz_block
fill 197 235 594 197 235 596 minecraft:quartz_block
setblock 197 235 598 minecraft:quartz_block
fill 198 235 558 200 235 560 minecraft:gold_block
fill 198 235 562 200 235 564 minecraft:red_wool
fill 198 235 566 200 235 568 minecraft:gold_block
fill 198 235 570 200 235 572 minecraft:red_wool
fill 198 235 574 200 235 576 minecraft:gold_block
fill 198 235 578 200 235 580 minecraft:red_wool
fill 198 235 582 200 235 584 minecraft:gold_block
fill 198 235 586 200 235 588 minecraft:red_wool
fill 198 235 590 200 235 592 minecraft:gold_block
fill 198 235 594 200 235 596 minecraft:red_wool
fill 198 235 598 200 235 598 minecraft:gold_block
fill 201 235 558 201 235 560 minecraft:quartz_block
fill 201 235 562 201 235 564 minecraft:quartz_block
fill 201 235 566 201 235 568 minecraft:quartz_block
fill 201 235 570 201 235 572 minecraft:quartz_block
fill 201 235 574 201 235 576 minecraft:quartz_block
fill 201 235 578 201 235 580 minecraft:quartz_block
fill 201 235 582 201 235 584 minecraft:quartz_block
fill 201 235 586 201 235 588 minecraft:quartz_block
fill 201 235 590 201 235 592 minecraft:quartz_block
fill 201 235 594 201 235 596 minecraft:quartz_block
setblock 201 235 598 minecraft:quartz_block
fill 202 235 558 204 235 560 minecraft:red_wool
fill 202 235 562 204 235 564 minecraft:gold_block
fill 202 235 566 204 235 568 minecraft:red_wool
fill 202 235 570 203 235 572 minecraft:gold_block
fill 202 235 574 203 235 576 minecraft:red_wool
fill 202 235 578 202 235 580 minecraft:gold_block
fill 202 235 582 202 235 584 minecraft:red_wool
fill 202 235 586 204 235 588 minecraft:gold_block
fill 202 235 590 204 235 592 minecraft:red_wool
fill 202 235 594 204 235 596 minecraft:gold_block
fill 202 235 598 204 235 598 minecraft:red_wool
fill 203 235 578 203 235 582 minecraft:ochre_froglight
fill 203 235 583 204 235 584 minecraft:red_wool
setblock 204 235 570 minecraft:gold_block
fill 204 235 571 204 235 575 minecraft:ochre_froglight
setblock 204 235 576 minecraft:red_wool
fill 204 235 578 207 235 578 minecraft:ochre_froglight
fill 204 235 579 206 235 581 minecraft:quartz_block
fill 204 235 582 207 235 582 minecraft:ochre_froglight
fill 205 235 558 205 235 560 minecraft:quartz_block
fill 205 235 562 205 235 564 minecraft:quartz_block
fill 205 235 566 205 235 568 minecraft:quartz_block
setblock 205 235 570 minecraft:quartz_block
fill 205 235 571 208 235 571 minecraft:ochre_froglight
fill 205 235 572 207 235 574 minecraft:quartz_block
fill 205 235 575 214 235 575 minecraft:ochre_froglight
setblock 205 235 576 minecraft:quartz_block
fill 205 235 583 205 235 584 minecraft:quartz_block
fill 205 235 586 205 235 588 minecraft:quartz_block
fill 205 235 590 205 235 592 minecraft:quartz_block
fill 205 235 594 205 235 596 minecraft:quartz_block
setblock 205 235 598 minecraft:quartz_block
fill 206 235 558 208 235 560 minecraft:gold_block
fill 206 235 562 208 235 564 minecraft:red_wool
fill 206 235 566 208 235 568 minecraft:gold_block
fill 206 235 570 208 235 570 minecraft:red_wool
setblock 206 235 576 minecraft:gold_block
fill 206 235 583 208 235 584 minecraft:gold_block
fill 206 235 586 208 235 588 minecraft:red_wool
fill 206 235 590 208 235 592 minecraft:gold_block
fill 206 235 594 208 235 596 minecraft:red_wool
fill 206 235 598 208 235 598 minecraft:gold_block
fill 207 235 576 207 235 577 minecraft:ochre_froglight
fill 207 235 579 207 235 581 minecraft:ochre_froglight
fill 208 235 572 208 235 574 minecraft:ochre_froglight
fill 208 235 579 211 235 579 minecraft:ochre_froglight
setblock 208 235 580 minecraft:red_wool
fill 208 235 581 210 235 581 minecraft:quartz_block
setblock 208 235 582 minecraft:gold_block
fill 209 235 558 209 235 560 minecraft:quartz_block
fill 209 235 562 209 235 564 minecraft:quartz_block
fill 209 235 566 209 235 568 minecraft:quartz_block
fill 209 235 570 209 235 574 minecraft:quartz_block
setblock 209 235 580 minecraft:quartz_block
fill 209 235 582 209 235 584 minecraft:quartz_block
fill 209 235 586 209 235 588 minecraft:quartz_block
fill 209 235 590 209 235 592 minecraft:quartz_block
fill 209 235 594 209 235 596 minecraft:quartz_block
setblock 209 235 598 minecraft:quartz_block
fill 210 235 558 212 235 560 minecraft:red_wool
fill 210 235 562 212 235 564 minecraft:gold_block
fill 210 235 566 212 235 568 minecraft:red_wool
fill 210 235 570 212 235 570 minecraft:gold_block
fill 210 235 571 210 235 574 minecraft:ochre_froglight
setblock 210 235 580 minecraft:gold_block
fill 210 235 582 210 235 584 minecraft:red_wool
fill 210 235 586 212 235 588 minecraft:gold_block
fill 210 235 590 212 235 592 minecraft:red_wool
fill 210 235 594 212 235 596 minecraft:gold_block
fill 210 235 598 212 235 598 minecraft:red_wool
fill 211 235 571 214 235 571 minecraft:ochre_froglight
fill 211 235 572 213 235 574 minecraft:quartz_block
fill 211 235 576 211 235 578 minecraft:ochre_froglight
fill 211 235 580 211 235 582 minecraft:ochre_froglight
fill 211 235 583 212 235 584 minecraft:red_wool
setblock 212 235 576 minecraft:red_wool
fill 212 235 577 229 235 577 minecraft:quartz_block
fill 212 235 578 215 235 578 minecraft:ochre_froglight
fill 212 235 579 214 235 581 minecraft:quartz_block
fill 212 235 582 215 235 582 minecraft:ochre_froglight
fill 213 235 558 213 235 560 minecraft:quartz_block
fill 213 235 562 213 235 564 minecraft:quartz_block
fill 213 235 566 213 235 568 minecraft:quartz_block
setblock 213 235 570 minecraft:quartz_block
setblock 213 235 576 minecraft:quartz_block
fill 213 235 583 213 235 584 minecraft:quartz_block
fill 213 235 586 213 235 588 minecraft:quartz_block
fill 213 235 590 213 235 592 minecraft:quartz_block
fill 213 235 594 213 235 596 minecraft:quartz_block
setblock 213 235 598 minecraft:quartz_block
fill 214 235 558 216 235 560 minecraft:gold_block
fill 214 235 562 216 235 564 minecraft:red_wool
fill 214 235 566 216 235 568 minecraft:gold_block
fill 214 235 570 216 235 570 minecraft:red_wool
fill 214 235 572 214 235 574 minecraft:ochre_froglight
fill 214 235 576 216 235 576 minecraft:gold_block
fill 214 235 583 216 235 584 minecraft:gold_block
fill 214 235 586 216 235 588 minecraft:red_wool
fill 214 235 590 216 235 592 minecraft:gold_block
fill 214 235 594 216 235 596 minecraft:red_wool
fill 214 235 598 216 235 598 minecraft:gold_block
fill 215 235 571 216 235 572 minecraft:red_wool
fill 215 235 573 229 235 573 minecraft:quartz_block
fill 215 235 574 216 235 575 minecraft:gold_block
fill 215 235 579 215 235 581 minecraft:ochre_froglight
fill 216 235 578 216 235 580 minecraft:red_wool
fill 216 235 581 229 235 581 minecraft:quartz_block
setblock 216 235 582 minecraft:gold_block
fill 217 235 558 217 235 560 minecraft:quartz_block
fill 217 235 562 217 235 564 minecraft:quartz_block
fill 217 235 566 217 235 568 minecraft:quartz_block
fill 217 235 570 217 235 572 minecraft:quartz_block
fill 217 235 574 217 235 576 minecraft:quartz_block
fill 217 235 578 217 235 580 minecraft:quartz_block
fill 217 235 582 217 235 584 minecraft:quartz_block
fill 217 235 586 217 235 588 minecraft:quartz_block
fill 217 235 590 217 235 592 minecraft:quartz_block
fill 217 235 594 217 235 596 minecraft:quartz_block
setblock 217 235 598 minecraft:quartz_block
fill 218 235 558 220 235 560 minecraft:red_wool
fill 218 235 562 220 235 564 minecraft:gold_block
fill 218 235 566 220 235 568 minecraft:red_wool
fill 218 235 570 220 235 572 minecraft:gold_block
fill 218 235 574 220 235 576 minecraft:red_wool
fill 218 235 578 220 235 580 minecraft:gold_block
fill 218 235 582 220 235 584 minecraft:red_wool
fill 218 235 586 220 235 588 minecraft:gold_block
fill 218 235 590 220 235 592 minecraft:red_wool
fill 218 235 594 220 235 596 minecraft:gold_block
fill 218 235 598 220 235 598 minecraft:red_wool
fill 221 235 558 221 235 560 minecraft:quartz_block
fill 221 235 562 221 235 564 minecraft:quartz_block
fill 221 235 566 221 235 568 minecraft:quartz_block
fill 221 235 570 221 235 572 minecraft:quartz_block
fill 221 235 574 221 235 576 minecraft:quartz_block
fill 221 235 578 221 235 580 minecraft:quartz_block
fill 221 235 582 221 235 584 minecraft:quartz_block
fill 221 235 586 221 235 588 minecraft:quartz_block
fill 221 235 590 221 235 592 minecraft:quartz_block
fill 221 235 594 221 235 596 minecraft:quartz_block
setblock 221 235 598 minecraft:quartz_block
fill 222 235 558 224 235 560 minecraft:gold_block
fill 222 235 562 224 235 564 minecraft:red_wool
fill 222 235 566 224 235 568 minecraft:gold_block
fill 222 235 570 224 235 572 minecraft:red_wool
fill 222 235 574 224 235 576 minecraft:gold_block
fill 222 235 578 224 235 580 minecraft:red_wool
fill 222 235 582 224 235 584 minecraft:gold_block
fill 222 235 586 224 235 588 minecraft:red_wool
fill 222 235 590 224 235 592 minecraft:gold_block
fill 222 235 594 224 235 596 minecraft:red_wool
fill 222 235 598 224 235 598 minecraft:gold_block
fill 225 235 558 225 235 560 minecraft:quartz_block
fill 225 235 562 225 235 564 minecraft:quartz_block
fill 225 235 566 225 235 568 minecraft:quartz_block
fill 225 235 570 225 235 572 minecraft:quartz_block
fill 225 235 574 225 235 576 minecraft:quartz_block
fill 225 235 578 225 235 580 minecraft:quartz_block
fill 225 235 582 225 235 584 minecraft:quartz_block
fill 225 235 586 225 235 588 minecraft:quartz_block
fill 225 235 590 225 235 592 minecraft:quartz_block
fill 225 235 594 225 235 596 minecraft:quartz_block
setblock 225 235 598 minecraft:quartz_block
fill 226 235 558 228 235 560 minecraft:red_wool
fill 226 235 562 228 235 564 minecraft:gold_block
fill 226 235 566 228 235 568 minecraft:red_wool
fill 226 235 570 228 235 572 minecraft:gold_block
fill 226 235 574 228 235 576 minecraft:red_wool
fill 226 235 578 228 235 580 minecraft:gold_block
fill 226 235 582 228 235 584 minecraft:red_wool
fill 226 235 586 228 235 588 minecraft:gold_block
fill 226 235 590 228 235 592 minecraft:red_wool
fill 226 235 594 228 235 596 minecraft:gold_block
fill 226 235 598 228 235 598 minecraft:red_wool
fill 229 235 558 229 235 560 minecraft:quartz_block
fill 229 235 562 229 235 564 minecraft:quartz_block
fill 229 235 566 229 235 568 minecraft:quartz_block
fill 229 235 570 229 235 572 minecraft:quartz_block
fill 229 235 574 229 235 576 minecraft:quartz_block
fill 229 235 578 229 235 580 minecraft:quartz_block
fill 229 235 582 229 235 584 minecraft:quartz_block
fill 229 235 586 229 235 588 minecraft:quartz_block
fill 229 235 590 229 235 592 minecraft:quartz_block
fill 229 235 594 229 235 596 minecraft:quartz_block
setblock 229 235 598 minecraft:quartz_block
fill 189 239 558 191 273 558 minecraft:quartz_block
fill 189 239 568 189 273 570 minecraft:quartz_block
fill 189 239 580 189 273 582 minecraft:quartz_block
fill 189 239 592 189 273 594 minecraft:quartz_block
fill 195 239 598 197 273 598 minecraft:quartz_block
fill 196 239 584 197 240 585 minecraft:gold_block
fill 199 239 558 207 240 561 minecraft:quartz_block
fill 203 239 590 215 240 598 minecraft:quartz_block
fill 213 239 558 215 273 558 minecraft:quartz_block
fill 219 239 558 225 240 567 minecraft:quartz_block
fill 219 239 598 221 273 598 minecraft:quartz_block
fill 226 239 558 228 240 561 minecraft:quartz_block
fill 229 239 566 229 273 568 minecraft:quartz_block
fill 229 239 578 229 273 580 minecraft:quartz_block
fill 229 239 590 229 273 592 minecraft:quartz_block
fill 190 240 567 190 245 569 minecraft:quartz_block
fill 190 240 579 190 245 581 minecraft:quartz_block
fill 190 240 591 190 245 593 minecraft:quartz_block
fill 196 240 597 198 245 597 minecraft:quartz_block
fill 212 240 559 214 245 559 minecraft:quartz_block
fill 220 240 597 222 245 597 minecraft:quartz_block
fill 228 240 567 228 245 569 minecraft:quartz_block
fill 228 240 579 228 245 581 minecraft:quartz_block
fill 228 240 591 228 245 593 minecraft:quartz_block
setblock 199 241 558 minecraft:ochre_froglight
fill 199 241 559 199 257 559 minecraft:quartz_block
setblock 199 241 560 minecraft:ochre_froglight
fill 199 241 561 199 257 561 minecraft:quartz_block
fill 200 241 558 200 257 558 minecraft:quartz_block
setblock 200 241 559 minecraft:ochre_froglight
fill 200 241 560 200 257 560 minecraft:quartz_block
setblock 200 241 561 minecraft:ochre_froglight
setblock 201 241 558 minecraft:ochre_froglight
fill 201 241 559 201 257 559 minecraft:quartz_block
setblock 201 241 560 minecraft:ochre_froglight
fill 201 241 561 201 257 561 minecraft:quartz_block
fill 202 241 558 202 273 558 minecraft:quartz_block
setblock 202 241 559 minecraft:ochre_froglight
fill 202 241 560 202 257 560 minecraft:quartz_block
setblock 202 241 561 minecraft:ochre_froglight
setblock 203 241 558 minecraft:ochre_froglight
fill 203 241 559 203 257 559 minecraft:quartz_block
setblock 203 241 560 minecraft:ochre_froglight
fill 203 241 561 203 257 561 minecraft:quartz_block
setblock 203 241 590 minecraft:ochre_froglight
fill 203 241 591 203 262 591 minecraft:quartz_block
setblock 203 241 592 minecraft:ochre_froglight
fill 203 241 593 203 262 593 minecraft:quartz_block
setblock 203 241 594 minecraft:ochre_froglight
fill 203 241 595 203 262 595 minecraft:quartz_block
setblock 203 241 596 minecraft:ochre_froglight
fill 203 241 597 203 262 597 minecraft:quartz_block
setblock 203 241 598 minecraft:ochre_froglight
fill 204 241 558 204 257 558 minecraft:quartz_block
setblock 204 241 559 minecraft:ochre_froglight
fill 204 241 560 204 257 560 minecraft:quartz_block
setblock 204 241 561 minecraft:ochre_froglight
fill 204 241 590 204 262 590 minecraft:quartz_block
setblock 204 241 591 minecraft:ochre_froglight
fill 204 241 592 204 262 592 minecraft:quartz_block
setblock 204 241 593 minecraft:ochre_froglight
fill 204 241 594 204 262 594 minecraft:quartz_block
setblock 204 241 595 minecraft:ochre_froglight
fill 204 241 596 204 262 596 minecraft:quartz_block
setblock 204 241 597 minecraft:ochre_froglight
fill 204 241 598 204 244 598 minecraft:quartz_block
setblock 205 241 558 minecraft:ochre_froglight
fill 205 241 559 205 257 559 minecraft:quartz_block
setblock 205 241 560 minecraft:ochre_froglight
fill 205 241 561 205 257 561 minecraft:quartz_block
setblock 205 241 590 minecraft:ochre_froglight
fill 205 241 591 205 262 591 minecraft:quartz_block
setblock 205 241 592 minecraft:ochre_froglight
fill 205 241 593 205 262 593 minecraft:quartz_block
setblock 205 241 594 minecraft:ochre_froglight
fill 205 241 595 205 262 595 minecraft:quartz_block
setblock 205 241 596 minecraft:ochre_froglight
fill 205 241 597 205 262 597 minecraft:quartz_block
setblock 205 241 598 minecraft:ochre_froglight
fill 206 241 558 206 244 558 minecraft:quartz_block
setblock 206 241 559 minecraft:ochre_froglight
fill 206 241 560 206 257 560 minecraft:quartz_block
setblock 206 241 561 minecraft:ochre_froglight
fill 206 241 590 206 262 590 minecraft:quartz_block
setblock 206 241 591 minecraft:ochre_froglight
fill 206 241 592 206 262 592 minecraft:quartz_block
setblock 206 241 593 minecraft:ochre_froglight
fill 206 241 594 206 262 594 minecraft:quartz_block
setblock 206 241 595 minecraft:ochre_froglight
fill 206 241 596 206 262 596 minecraft:quartz_block
setblock 206 241 597 minecraft:ochre_froglight
fill 206 241 598 206 262 598 minecraft:quartz_block
setblock 207 241 558 minecraft:ochre_froglight
fill 207 241 559 207 257 559 minecraft:quartz_block
setblock 207 241 560 minecraft:ochre_froglight
fill 207 241 561 207 257 561 minecraft:quartz_block
setblock 207 241 590 minecraft:ochre_froglight
fill 207 241 591 207 262 591 minecraft:quartz_block
setblock 207 241 592 minecraft:ochre_froglight
fill 207 241 593 207 262 593 minecraft:quartz_block
setblock 207 241 594 minecraft:ochre_froglight
fill 207 241 595 207 262 595 minecraft:quartz_block
setblock 207 241 596 minecraft:ochre_froglight
fill 207 241 597 207 262 597 minecraft:quartz_block
setblock 207 241 598 minecraft:ochre_froglight
fill 208 241 590 208 262 590 minecraft:quartz_block
setblock 208 241 591 minecraft:ochre_froglight
fill 208 241 592 208 262 592 minecraft:quartz_block
setblock 208 241 593 minecraft:ochre_froglight
fill 208 241 594 208 262 594 minecraft:quartz_block
setblock 208 241 595 minecraft:ochre_froglight
fill 208 241 596 208 262 596 minecraft:quartz_block
setblock 208 241 597 minecraft:ochre_froglight
fill 208 241 598 208 273 598 minecraft:quartz_block
setblock 209 241 590 minecraft:ochre_froglight
fill 209 241 591 209 262 591 minecraft:quartz_block
setblock 209 241 592 minecraft:ochre_froglight
fill 209 241 593 209 262 593 minecraft:quartz_block
setblock 209 241 594 minecraft:ochre_froglight
fill 209 241 595 209 262 595 minecraft:quartz_block
setblock 209 241 596 minecraft:ochre_froglight
fill 209 241 597 209 265 597 minecraft:quartz_block
setblock 209 241 598 minecraft:ochre_froglight
fill 210 241 590 210 262 590 minecraft:quartz_block
setblock 210 241 591 minecraft:ochre_froglight
fill 210 241 592 210 262 592 minecraft:quartz_block
setblock 210 241 593 minecraft:ochre_froglight
fill 210 241 594 210 262 594 minecraft:quartz_block
setblock 210 241 595 minecraft:ochre_froglight
fill 210 241 596 210 262 596 minecraft:quartz_block
setblock 210 241 597 minecraft:ochre_froglight
fill 210 241 598 210 262 598 minecraft:quartz_block
setblock 211 241 590 minecraft:ochre_froglight
fill 211 241 591 211 262 591 minecraft:quartz_block
setblock 211 241 592 minecraft:ochre_froglight
fill 211 241 593 211 262 593 minecraft:quartz_block
setblock 211 241 594 minecraft:ochre_froglight
fill 211 241 595 211 262 595 minecraft:quartz_block
setblock 211 241 596 minecraft:ochre_froglight
fill 211 241 597 211 262 597 minecraft:quartz_block
setblock 211 241 598 minecraft:ochre_froglight
fill 212 241 590 212 262 590 minecraft:quartz_block
setblock 212 241 591 minecraft:ochre_froglight
fill 212 241 592 212 262 592 minecraft:quartz_block
setblock 212 241 593 minecraft:ochre_froglight
fill 212 241 594 212 262 594 minecraft:quartz_block
setblock 212 241 595 minecraft:ochre_froglight
fill 212 241 596 212 262 596 minecraft:quartz_block
setblock 212 241 597 minecraft:ochre_froglight
fill 212 241 598 212 244 598 minecraft:quartz_block
setblock 213 241 590 minecraft:ochre_froglight
fill 213 241 591 213 262 591 minecraft:quartz_block
setblock 213 241 592 minecraft:ochre_froglight
fill 213 241 593 213 262 593 minecraft:quartz_block
setblock 213 241 594 minecraft:ochre_froglight
fill 213 241 595 213 262 595 minecraft:quartz_block
setblock 213 241 596 minecraft:ochre_froglight
fill 213 241 597 213 262 597 minecraft:quartz_block
setblock 213 241 598 minecraft:ochre_froglight
fill 214 241 590 214 262 590 minecraft:quartz_block
setblock 214 241 591 minecraft:ochre_froglight
fill 214 241 592 214 262 592 minecraft:quartz_block
setblock 214 241 593 minecraft:ochre_froglight
fill 214 241 594 214 262 594 minecraft:quartz_block
setblock 214 241 595 minecraft:ochre_froglight
fill 214 241 596 214 262 596 minecraft:quartz_block
setblock 214 241 597 minecraft:ochre_froglight
fill 214 241 598 214 244 598 minecraft:quartz_block
setblock 215 241 590 minecraft:ochre_froglight
fill 215 241 591 215 262 591 minecraft:quartz_block
setblock 215 241 592 minecraft:ochre_froglight
fill 215 241 593 215 262 593 minecraft:quartz_block
setblock 215 241 594 minecraft:ochre_froglight
fill 215 241 595 215 262 595 minecraft:quartz_block
setblock 215 241 596 minecraft:ochre_froglight
fill 215 241 597 215 262 597 minecraft:quartz_block
setblock 215 241 598 minecraft:ochre_froglight
fill 218 241 592 218 242 592 minecraft:raw_gold_block
setblock 219 241 558 minecraft:ochre_froglight
fill 219 241 559 219 255 559 minecraft:quartz_block
setblock 219 241 560 minecraft:ochre_froglight
fill 219 241 561 219 255 561 minecraft:quartz_block
setblock 219 241 562 minecraft:ochre_froglight
fill 219 241 563 219 255 563 minecraft:quartz_block
setblock 219 241 564 minecraft:ochre_froglight
fill 219 241 565 219 255 565 minecraft:quartz_block
setblock 219 241 566 minecraft:ochre_froglight
fill 219 241 567 219 255 567 minecraft:quartz_block
fill 220 241 558 220 244 558 minecraft:quartz_block
setblock 220 241 559 minecraft:ochre_froglight
fill 220 241 560 220 255 560 minecraft:quartz_block
setblock 220 241 561 minecraft:ochre_froglight
fill 220 241 562 220 255 562 minecraft:quartz_block
setblock 220 241 563 minecraft:ochre_froglight
fill 220 241 564 220 255 564 minecraft:quartz_block
setblock 220 241 565 minecraft:ochre_froglight
fill 220 241 566 220 255 566 minecraft:quartz_block
setblock 220 241 567 minecraft:ochre_froglight
setblock 221 241 558 minecraft:ochre_froglight
fill 221 241 559 221 249 559 minecraft:quartz_block
setblock 221 241 560 minecraft:ochre_froglight
fill 221 241 561 221 255 561 minecraft:quartz_block
setblock 221 241 562 minecraft:ochre_froglight
fill 221 241 563 221 255 563 minecraft:quartz_block
setblock 221 241 564 minecraft:ochre_froglight
fill 221 241 565 221 255 565 minecraft:quartz_block
setblock 221 241 566 minecraft:ochre_froglight
fill 221 241 567 221 255 567 minecraft:quartz_block
fill 222 241 558 222 244 558 minecraft:quartz_block
setblock 222 241 559 minecraft:ochre_froglight
fill 222 241 560 222 249 560 minecraft:quartz_block
setblock 222 241 561 minecraft:ochre_froglight
fill 222 241 562 222 255 562 minecraft:quartz_block
setblock 222 241 563 minecraft:ochre_froglight
fill 222 241 564 222 255 564 minecraft:quartz_block
setblock 222 241 565 minecraft:ochre_froglight
fill 222 241 566 222 255 566 minecraft:quartz_block
setblock 222 241 567 minecraft:ochre_froglight
setblock 223 241 558 minecraft:ochre_froglight
fill 223 241 559 223 249 559 minecraft:quartz_block
setblock 223 241 560 minecraft:ochre_froglight
fill 223 241 561 223 251 561 minecraft:quartz_block
setblock 223 241 562 minecraft:ochre_froglight
fill 223 241 563 223 255 563 minecraft:quartz_block
setblock 223 241 564 minecraft:ochre_froglight
fill 223 241 565 223 255 565 minecraft:quartz_block
setblock 223 241 566 minecraft:ochre_froglight
fill 223 241 567 223 255 567 minecraft:quartz_block
fill 224 241 558 224 251 558 minecraft:quartz_block
setblock 224 241 559 minecraft:ochre_froglight
fill 224 241 560 224 249 560 minecraft:quartz_block
setblock 224 241 561 minecraft:ochre_froglight
fill 224 241 562 224 252 562 minecraft:quartz_block
setblock 224 241 563 minecraft:ochre_froglight
fill 224 241 564 224 255 564 minecraft:quartz_block
setblock 224 241 565 minecraft:ochre_froglight
fill 224 241 566 224 255 566 minecraft:quartz_block
setblock 224 241 567 minecraft:ochre_froglight
setblock 225 241 558 minecraft:ochre_froglight
fill 225 241 559 225 249 559 minecraft:quartz_block
setblock 225 241 560 minecraft:ochre_froglight
fill 225 241 561 225 251 561 minecraft:quartz_block
setblock 225 241 562 minecraft:ochre_froglight
fill 225 241 563 225 255 563 minecraft:quartz_block
setblock 225 241 564 minecraft:ochre_froglight
fill 225 241 565 225 255 565 minecraft:quartz_block
setblock 225 241 566 minecraft:ochre_froglight
fill 225 241 567 225 255 567 minecraft:quartz_block
fill 226 241 558 226 273 558 minecraft:quartz_block
setblock 226 241 559 minecraft:ochre_froglight
fill 226 241 560 226 249 560 minecraft:quartz_block
setblock 226 241 561 minecraft:ochre_froglight
setblock 227 241 558 minecraft:ochre_froglight
fill 227 241 559 227 249 559 minecraft:quartz_block
setblock 227 241 560 minecraft:ochre_froglight
fill 227 241 561 227 249 561 minecraft:quartz_block
fill 228 241 558 228 249 558 minecraft:quartz_block
setblock 228 241 559 minecraft:ochre_froglight
fill 228 241 560 228 249 560 minecraft:quartz_block
setblock 228 241 561 minecraft:ochre_froglight
setblock 191 242 560 minecraft:light[level=14]
setblock 191 242 568 minecraft:light[level=14]
setblock 191 242 576 minecraft:light[level=14]
setblock 191 242 584 minecraft:light[level=14]
setblock 191 242 592 minecraft:light[level=14]
fill 199 242 558 199 243 558 minecraft:quartz_block
fill 199 242 560 199 243 560 minecraft:quartz_block
setblock 199 242 568 minecraft:light[level=14]
setblock 199 242 576 minecraft:light[level=14]
setblock 199 242 584 minecraft:light[level=14]
setblock 199 242 592 minecraft:light[level=14]
fill 200 242 559 200 243 559 minecraft:quartz_block
fill 200 242 561 200 243 561 minecraft:quartz_block
fill 201 242 558 201 243 558 minecraft:quartz_block
fill 201 242 560 201 243 560 minecraft:quartz_block
fill 202 242 559 202 243 559 minecraft:quartz_block
fill 202 242 561 202 243 561 minecraft:quartz_block
fill 203 242 558 203 243 558 minecraft:quartz_block
fill 203 242 560 203 243 560 minecraft:quartz_block
fill 203 242 590 203 243 590 minecraft:quartz_block
fill 203 242 592 203 243 592 minecraft:quartz_block
fill 203 242 594 203 243 594 minecraft:quartz_block
fill 203 242 596 203 243 596 minecraft:quartz_block
fill 203 242 598 203 243 598 minecraft:quartz_block
fill 204 242 559 204 243 559 minecraft:quartz_block
fill 204 242 561 204 243 561 minecraft:quartz_block
fill 204 242 591 204 243 591 minecraft:quartz_block
fill 204 242 593 204 243 593 minecraft:quartz_block
fill 204 242 595 204 243 595 minecraft:quartz_block
fill 204 242 597 204 243 597 minecraft:quartz_block
fill 205 242 558 205 243 558 minecraft:quartz_block
fill 205 242 560 205 243 560 minecraft:quartz_block
fill 205 242 590 205 243 590 minecraft:quartz_block
fill 205 242 592 205 243 592 minecraft:quartz_block
fill 205 242 594 205 243 594 minecraft:quartz_block
fill 205 242 596 205 243 596 minecraft:quartz_block
fill 205 242 598 205 243 598 minecraft:quartz_block
fill 206 242 559 206 243 559 minecraft:quartz_block
fill 206 242 561 206 243 561 minecraft:quartz_block
fill 206 242 591 206 243 591 minecraft:quartz_block
fill 206 242 593 206 243 593 minecraft:quartz_block
fill 206 242 595 206 243 595 minecraft:quartz_block
fill 206 242 597 206 243 597 minecraft:quartz_block
fill 207 242 558 207 243 558 minecraft:quartz_block
fill 207 242 560 207 243 560 minecraft:quartz_block
setblock 207 242 568 minecraft:light[level=14]
setblock 207 242 576 minecraft:light[level=14]
setblock 207 242 584 minecraft:light[level=14]
fill 207 242 590 207 243 590 minecraft:quartz_block
fill 207 242 592 207 243 592 minecraft:quartz_block
fill 207 242 594 207 243 594 minecraft:quartz_block
fill 207 242 596 207 243 596 minecraft:quartz_block
fill 207 242 598 207 243 598 minecraft:quartz_block
fill 208 242 591 208 243 591 minecraft:quartz_block
fill 208 242 593 208 243 593 minecraft:quartz_block
fill 208 242 595 208 243 595 minecraft:quartz_block
fill 208 242 597 208 243 597 minecraft:quartz_block
fill 209 242 590 209 243 590 minecraft:quartz_block
fill 209 242 592 209 243 592 minecraft:quartz_block
fill 209 242 594 209 243 594 minecraft:quartz_block
fill 209 242 596 209 243 596 minecraft:quartz_block
fill 209 242 598 209 243 598 minecraft:quartz_block
fill 210 242 591 210 243 591 minecraft:quartz_block
fill 210 242 593 210 243 593 minecraft:quartz_block
fill 210 242 595 210 243 595 minecraft:quartz_block
fill 210 242 597 210 243 597 minecraft:quartz_block
fill 211 242 590 211 243 590 minecraft:quartz_block
fill 211 242 592 211 243 592 minecraft:quartz_block
fill 211 242 594 211 243 594 minecraft:quartz_block
fill 211 242 596 211 243 596 minecraft:quartz_block
fill 211 242 598 211 243 598 minecraft:quartz_block
fill 212 242 591 212 243 591 minecraft:quartz_block
fill 212 242 593 212 243 593 minecraft:quartz_block
fill 212 242 595 212 243 595 minecraft:quartz_block
fill 212 242 597 212 243 597 minecraft:quartz_block
fill 213 242 590 213 243 590 minecraft:quartz_block
fill 213 242 592 213 243 592 minecraft:quartz_block
fill 213 242 594 213 243 594 minecraft:quartz_block
fill 213 242 596 213 243 596 minecraft:quartz_block
fill 213 242 598 213 243 598 minecraft:quartz_block
fill 214 242 591 214 243 591 minecraft:quartz_block
fill 214 242 593 214 243 593 minecraft:quartz_block
fill 214 242 595 214 243 595 minecraft:quartz_block
fill 214 242 597 214 243 597 minecraft:quartz_block
setblock 215 242 560 minecraft:light[level=14]
setblock 215 242 568 minecraft:light[level=14]
setblock 215 242 576 minecraft:light[level=14]
setblock 215 242 584 minecraft:light[level=14]
fill 215 242 590 215 243 590 minecraft:quartz_block
fill 215 242 592 215 243 592 minecraft:quartz_block
fill 215 242 594 215 243 594 minecraft:quartz_block
fill 215 242 596 215 243 596 minecraft:quartz_block
fill 215 242 598 215 243 598 minecraft:quartz_block
fill 219 242 558 219 243 558 minecraft:quartz_block
fill 219 242 560 219 243 560 minecraft:quartz_block
fill 219 242 562 219 243 562 minecraft:quartz_block
fill 219 242 564 219 243 564 minecraft:quartz_block
fill 219 242 566 219 243 566 minecraft:quartz_block
fill 220 242 559 220 243 559 minecraft:quartz_block
fill 220 242 561 220 243 561 minecraft:quartz_block
fill 220 242 563 220 243 563 minecraft:quartz_block
fill 220 242 565 220 243 565 minecraft:quartz_block
fill 220 242 567 220 243 567 minecraft:quartz_block
fill 221 242 558 221 243 558 minecraft:quartz_block
fill 221 242 560 221 243 560 minecraft:quartz_block
fill 221 242 562 221 243 562 minecraft:quartz_block
fill 221 242 564 221 243 564 minecraft:quartz_block
fill 221 242 566 221 243 566 minecraft:quartz_block
fill 222 242 559 222 243 559 minecraft:quartz_block
fill 222 242 561 222 243 561 minecraft:quartz_block
fill 222 242 563 222 243 563 minecraft:quartz_block
fill 222 242 565 222 243 565 minecraft:quartz_block
fill 222 242 567 222 243 567 minecraft:quartz_block
fill 223 242 558 223 243 558 minecraft:quartz_block
fill 223 242 560 223 243 560 minecraft:quartz_block
fill 223 242 562 223 243 562 minecraft:quartz_block
fill 223 242 564 223 243 564 minecraft:quartz_block
fill 223 242 566 223 243 566 minecraft:quartz_block
setblock 223 242 568 minecraft:light[level=14]
setblock 223 242 576 minecraft:light[level=14]
setblock 223 242 584 minecraft:light[level=14]
setblock 223 242 592 minecraft:light[level=14]
fill 224 242 559 224 243 559 minecraft:quartz_block
fill 224 242 561 224 243 561 minecraft:quartz_block
fill 224 242 563 224 243 563 minecraft:quartz_block
fill 224 242 565 224 243 565 minecraft:quartz_block
fill 224 242 567 224 243 567 minecraft:quartz_block
fill 225 242 558 225 243 558 minecraft:quartz_block
fill 225 242 560 225 243 560 minecraft:quartz_block
fill 225 242 562 225 243 562 minecraft:quartz_block
fill 225 242 564 225 243 564 minecraft:quartz_block
fill 225 242 566 225 243 566 minecraft:quartz_block
fill 226 242 559 226 243 559 minecraft:quartz_block
fill 226 242 561 226 243 561 minecraft:quartz_block
fill 227 242 558 227 243 558 minecraft:quartz_block
fill 227 242 560 227 243 560 minecraft:quartz_block
fill 228 242 559 228 243 559 minecraft:quartz_block
fill 228 242 561 228 243 561 minecraft:quartz_block
setblock 199 244 558 minecraft:ochre_froglight
setblock 199 244 560 minecraft:ochre_froglight
setblock 200 244 559 minecraft:ochre_froglight
setblock 200 244 561 minecraft:ochre_froglight
setblock 201 244 558 minecraft:ochre_froglight
setblock 201 244 560 minecraft:ochre_froglight
setblock 202 244 559 minecraft:ochre_froglight
setblock 202 244 561 minecraft:ochre_froglight
setblock 203 244 558 minecraft:ochre_froglight
setblock 203 244 560 minecraft:ochre_froglight
setblock 203 244 590 minecraft:ochre_froglight
setblock 203 244 592 minecraft:ochre_froglight
setblock 203 244 594 minecraft:ochre_froglight
setblock 203 244 596 minecraft:ochre_froglight
setblock 203 244 598 minecraft:ochre_froglight
setblock 204 244 559 minecraft:ochre_froglight
setblock 204 244 561 minecraft:ochre_froglight
setblock 204 244 591 minecraft:ochre_froglight
setblock 204 244 593 minecraft:ochre_froglight
setblock 204 244 595 minecraft:ochre_froglight
setblock 204 244 597 minecraft:ochre_froglight
setblock 205 244 558 minecraft:ochre_froglight
setblock 205 244 560 minecraft:ochre_froglight
setblock 205 244 590 minecraft:ochre_froglight
setblock 205 244 592 minecraft:ochre_froglight
setblock 205 244 594 minecraft:ochre_froglight
setblock 205 244 596 minecraft:ochre_froglight
setblock 205 244 598 minecraft:ochre_froglight
setblock 206 244 559 minecraft:ochre_froglight
setblock 206 244 561 minecraft:ochre_froglight
setblock 206 244 591 minecraft:ochre_froglight
setblock 206 244 593 minecraft:ochre_froglight
setblock 206 244 595 minecraft:ochre_froglight
setblock 206 244 597 minecraft:ochre_froglight
setblock 207 244 558 minecraft:ochre_froglight
setblock 207 244 560 minecraft:ochre_froglight
setblock 207 244 590 minecraft:ochre_froglight
setblock 207 244 592 minecraft:ochre_froglight
setblock 207 244 594 minecraft:ochre_froglight
setblock 207 244 596 minecraft:ochre_froglight
setblock 207 244 598 minecraft:ochre_froglight
setblock 208 244 591 minecraft:ochre_froglight
setblock 208 244 593 minecraft:ochre_froglight
setblock 208 244 595 minecraft:ochre_froglight
setblock 208 244 597 minecraft:ochre_froglight
setblock 209 244 590 minecraft:ochre_froglight
setblock 209 244 592 minecraft:ochre_froglight
setblock 209 244 594 minecraft:ochre_froglight
setblock 209 244 596 minecraft:ochre_froglight
setblock 209 244 598 minecraft:ochre_froglight
setblock 210 244 591 minecraft:ochre_froglight
setblock 210 244 593 minecraft:ochre_froglight
setblock 210 244 595 minecraft:ochre_froglight
setblock 210 244 597 minecraft:ochre_froglight
setblock 211 244 590 minecraft:ochre_froglight
setblock 211 244 592 minecraft:ochre_froglight
setblock 211 244 594 minecraft:ochre_froglight
setblock 211 244 596 minecraft:ochre_froglight
setblock 211 244 598 minecraft:ochre_froglight
setblock 212 244 591 minecraft:ochre_froglight
setblock 212 244 593 minecraft:ochre_froglight
setblock 212 244 595 minecraft:ochre_froglight
setblock 212 244 597 minecraft:ochre_froglight
setblock 213 244 590 minecraft:ochre_froglight
setblock 213 244 592 minecraft:ochre_froglight
setblock 213 244 594 minecraft:ochre_froglight
setblock 213 244 596 minecraft:ochre_froglight
setblock 213 244 598 minecraft:ochre_froglight
setblock 214 244 591 minecraft:ochre_froglight
setblock 214 244 593 minecraft:ochre_froglight
setblock 214 244 595 minecraft:ochre_froglight
setblock 214 244 597 minecraft:ochre_froglight
setblock 215 244 590 minecraft:ochre_froglight
setblock 215 244 592 minecraft:ochre_froglight
setblock 215 244 594 minecraft:ochre_froglight
setblock 215 244 596 minecraft:ochre_froglight
setblock 215 244 598 minecraft:ochre_froglight
setblock 219 244 558 minecraft:ochre_froglight
setblock 219 244 560 minecraft:ochre_froglight
setblock 219 244 562 minecraft:ochre_froglight
setblock 219 244 564 minecraft:ochre_froglight
setblock 219 244 566 minecraft:ochre_froglight
setblock 220 244 559 minecraft:ochre_froglight
setblock 220 244 561 minecraft:ochre_froglight
setblock 220 244 563 minecraft:ochre_froglight
setblock 220 244 565 minecraft:ochre_froglight
setblock 220 244 567 minecraft:ochre_froglight
setblock 221 244 558 minecraft:ochre_froglight
setblock 221 244 560 minecraft:ochre_froglight
setblock 221 244 562 minecraft:ochre_froglight
setblock 221 244 564 minecraft:ochre_froglight
setblock 221 244 566 minecraft:ochre_froglight
setblock 222 244 559 minecraft:ochre_froglight
setblock 222 244 561 minecraft:ochre_froglight
setblock 222 244 563 minecraft:ochre_froglight
setblock 222 244 565 minecraft:ochre_froglight
setblock 222 244 567 minecraft:ochre_froglight
setblock 223 244 558 minecraft:ochre_froglight
setblock 223 244 560 minecraft:ochre_froglight
setblock 223 244 562 minecraft:ochre_froglight
setblock 223 244 564 minecraft:ochre_froglight
setblock 223 244 566 minecraft:ochre_froglight
setblock 224 244 559 minecraft:ochre_froglight
setblock 224 244 561 minecraft:ochre_froglight
setblock 224 244 563 minecraft:ochre_froglight
setblock 224 244 565 minecraft:ochre_froglight
setblock 224 244 567 minecraft:ochre_froglight
setblock 225 244 558 minecraft:ochre_froglight
setblock 225 244 560 minecraft:ochre_froglight
setblock 225 244 562 minecraft:ochre_froglight
setblock 225 244 564 minecraft:ochre_froglight
setblock 225 244 566 minecraft:ochre_froglight
setblock 226 244 559 minecraft:ochre_froglight
setblock 226 244 561 minecraft:ochre_froglight
setblock 227 244 558 minecraft:ochre_froglight
setblock 227 244 560 minecraft:ochre_froglight
setblock 228 244 559 minecraft:ochre_froglight
setblock 228 244 561 minecraft:ochre_froglight
fill 189 245 561 189 245 566 minecraft:yellow_terracotta
fill 189 245 573 189 245 578 minecraft:yellow_terracotta
fill 189 245 585 189 245 590 minecraft:yellow_terracotta
fill 189 245 597 189 245 598 minecraft:yellow_terracotta
fill 190 245 598 193 245 598 minecraft:yellow_terracotta
fill 193 245 558 198 245 558 minecraft:yellow_terracotta
fill 199 245 558 199 246 558 minecraft:quartz_block
fill 199 245 560 199 246 560 minecraft:quartz_block
fill 200 245 559 200 246 559 minecraft:quartz_block
fill 200 245 561 200 246 561 minecraft:quartz_block
fill 200 245 598 205 245 598 minecraft:yellow_terracotta
fill 201 245 558 201 246 558 minecraft:quartz_block
fill 201 245 560 201 246 560 minecraft:quartz_block
fill 202 245 559 202 246 559 minecraft:quartz_block
fill 202 245 561 202 246 561 minecraft:quartz_block
fill 203 245 558 203 246 558 minecraft:quartz_block
fill 203 245 560 203 246 560 minecraft:quartz_block
fill 203 245 590 203 246 590 minecraft:quartz_block
fill 203 245 592 203 246 592 minecraft:quartz_block
fill 203 245 594 203 246 594 minecraft:quartz_block
fill 203 245 596 203 246 596 minecraft:quartz_block
fill 204 245 559 204 246 559 minecraft:quartz_block
fill 204 245 561 204 246 561 minecraft:quartz_block
fill 204 245 591 204 246 591 minecraft:quartz_block
fill 204 245 593 204 246 593 minecraft:quartz_block
fill 204 245 595 204 246 595 minecraft:quartz_block
fill 204 245 597 204 246 597 minecraft:quartz_block
fill 205 245 558 210 245 558 minecraft:yellow_terracotta
fill 205 245 560 205 246 560 minecraft:quartz_block
fill 205 245 590 205 246 590 minecraft:quartz_block
fill 205 245 592 205 246 592 minecraft:quartz_block
fill 205 245 594 205 246 594 minecraft:quartz_block
fill 205 245 596 205 246 596 minecraft:quartz_block
fill 206 245 559 206 246 559 minecraft:quartz_block
fill 206 245 561 206 246 561 minecraft:quartz_block
fill 206 245 591 206 246 591 minecraft:quartz_block
fill 206 245 593 206 246 593 minecraft:quartz_block
fill 206 245 595 206 246 595 minecraft:quartz_block
fill 206 245 597 206 246 597 minecraft:quartz_block
fill 207 245 560 207 246 560 minecraft:quartz_block
fill 207 245 590 207 246 590 minecraft:quartz_block
fill 207 245 592 207 246 592 minecraft:quartz_block
fill 207 245 594 207 246 594 minecraft:quartz_block
fill 207 245 596 207 246 596 minecraft:quartz_block
fill 207 245 598 207 246 598 minecraft:quartz_block
fill 208 245 591 208 246 591 minecraft:quartz_block
fill 208 245 593 208 246 593 minecraft:quartz_block
fill 208 245 595 208 246 595 minecraft:quartz_block
fill 208 245 597 208 246 597 minecraft:quartz_block
fill 209 245 590 209 246 590 minecraft:quartz_block
fill 209 245 592 209 246 592 minecraft:quartz_block
fill 209 245 594 209 246 594 minecraft:quartz_block
fill 209 245 596 209 246 596 minecraft:quartz_block
fill 209 245 598 209 246 598 minecraft:quartz_block
fill 210 245 591 210 246 591 minecraft:quartz_block
fill 210 245 593 210 246 593 minecraft:quartz_block
fill 210 245 595 210 246 595 minecraft:quartz_block
fill 210 245 597 210 246 597 minecraft:quartz_block
fill 211 245 590 211 246 590 minecraft:quartz_block
fill 211 245 592 211 246 592 minecraft:quartz_block
fill 211 245 594 211 246 594 minecraft:quartz_block
fill 211 245 596 211 246 596 minecraft:quartz_block
fill 211 245 598 211 246 598 minecraft:quartz_block
fill 212 245 591 212 246 591 minecraft:quartz_block
fill 212 245 593 212 246 593 minecraft:quartz_block
fill 212 245 595 212 246 595 minecraft:quartz_block
fill 212 245 597 212 246 597 minecraft:quartz_block
fill 212 245 598 217 245 598 minecraft:yellow_terracotta
fill 213 245 590 213 246 590 minecraft:quartz_block
fill 213 245 592 213 246 592 minecraft:quartz_block
fill 213 245 594 213 246 594 minecraft:quartz_block
fill 213 245 596 213 246 596 minecraft:quartz_block
fill 214 245 591 214 246 591 minecraft:quartz_block
fill 214 245 593 214 246 593 minecraft:quartz_block
fill 214 245 595 214 246 595 minecraft:quartz_block
fill 214 245 597 214 246 597 minecraft:quartz_block
fill 215 245 590 215 246 590 minecraft:quartz_block
fill 215 245 592 215 246 592 minecraft:quartz_block
fill 215 245 594 215 246 594 minecraft:quartz_block
fill 215 245 596 215 246 596 minecraft:quartz_block
fill 217 245 558 222 245 558 minecraft:yellow_terracotta
fill 219 245 560 219 246 560 minecraft:quartz_block
fill 219 245 562 219 246 562 minecraft:quartz_block
fill 219 245 564 219 246 564 minecraft:quartz_block
fill 219 245 566 219 246 566 minecraft:quartz_block
fill 220 245 559 220 246 559 minecraft:quartz_block
fill 220 245 561 220 246 561 minecraft:quartz_block
fill 220 245 563 220 246 563 minecraft:quartz_block
fill 220 245 565 220 246 565 minecraft:quartz_block
fill 220 245 567 220 246 567 minecraft:quartz_block
fill 221 245 560 221 246 560 minecraft:quartz_block
fill 221 245 562 221 246 562 minecraft:quartz_block
fill 221 245 564 221 246 564 minecraft:quartz_block
fill 221 245 566 221 246 566 minecraft:quartz_block
fill 222 245 559 222 246 559 minecraft:quartz_block
fill 222 245 561 222 246 561 minecraft:quartz_block
fill 222 245 563 222 246 563 minecraft:quartz_block
fill 222 245 565 222 246 565 minecraft:quartz_block
fill 222 245 567 222 246 567 minecraft:quartz_block
fill 223 245 558 223 246 558 minecraft:quartz_block
fill 223 245 560 223 246 560 minecraft:quartz_block
fill 223 245 562 223 246 562 minecraft:quartz_block
fill 223 245 564 223 246 564 minecraft:quartz_block
fill 223 245 566 223 246 566 minecraft:quartz_block
fill 224 245 559 224 246 559 minecraft:quartz_block
fill 224 245 561 224 246 561 minecraft:quartz_block
fill 224 245 563 224 246 563 minecraft:quartz_block
fill 224 245 565 224 246 565 minecraft:quartz_block
fill 224 245 567 224 246 567 minecraft:quartz_block
fill 224 245 598 229 245 598 minecraft:yellow_terracotta
fill 225 245 558 225 246 558 minecraft:quartz_block
fill 225 245 560 225 246 560 minecraft:quartz_block
fill 225 245 562 225 246 562 minecraft:quartz_block
fill 225 245 564 225 246 564 minecraft:quartz_block
fill 225 245 566 225 246 566 minecraft:quartz_block
fill 226 245 559 226 246 559 minecraft:quartz_block
fill 226 245 561 226 246 561 minecraft:quartz_block
fill 227 245 558 227 246 558 minecraft:quartz_block
fill 227 245 560 227 246 560 minecraft:quartz_block
fill 228 245 559 228 246 559 minecraft:quartz_block
fill 228 245 561 228 246 561 minecraft:quartz_block
fill 229 245 558 229 245 563 minecraft:yellow_terracotta
fill 229 245 570 229 245 575 minecraft:yellow_terracotta
fill 229 245 582 229 245 587 minecraft:yellow_terracotta
fill 229 245 594 229 245 597 minecraft:yellow_terracotta
fill 188 246 563 188 251 566 minecraft:ochre_froglight
fill 188 246 575 188 251 578 minecraft:ochre_froglight
fill 188 246 587 188 251 590 minecraft:ochre_froglight
fill 188 246 599 191 251 599 minecraft:ochre_froglight
fill 195 246 557 198 251 557 minecraft:ochre_froglight
fill 200 246 599 203 251 599 minecraft:ochre_froglight
fill 203 246 598 205 246 598 minecraft:quartz_block
fill 205 246 558 207 246 558 minecraft:quartz_block
fill 207 246 557 210 251 557 minecraft:ochre_froglight
fill 212 246 598 215 246 598 minecraft:quartz_block
fill 212 246 599 215 251 599 minecraft:ochre_froglight
fill 219 246 557 222 251 557 minecraft:ochre_froglight
fill 219 246 558 222 246 558 minecraft:quartz_block
fill 224 246 599 227 251 599 minecraft:ochre_froglight
fill 230 246 558 230 251 561 minecraft:ochre_froglight
fill 230 246 570 230 251 573 minecraft:ochre_froglight
fill 230 246 582 230 251 585 minecraft:ochre_froglight
fill 230 246 594 230 251 597 minecraft:ochre_froglight
setblock 199 247 558 minecraft:ochre_froglight
setblock 199 247 560 minecraft:ochre_froglight
setblock 200 247 559 minecraft:ochre_froglight
setblock 200 247 561 minecraft:ochre_froglight
setblock 201 247 558 minecraft:ochre_froglight
setblock 201 247 560 minecraft:ochre_froglight
setblock 202 247 559 minecraft:ochre_froglight
setblock 202 247 561 minecraft:ochre_froglight
setblock 203 247 558 minecraft:ochre_froglight
setblock 203 247 560 minecraft:ochre_froglight
setblock 203 247 590 minecraft:ochre_froglight
setblock 203 247 592 minecraft:ochre_froglight
setblock 203 247 594 minecraft:ochre_froglight
setblock 203 247 596 minecraft:ochre_froglight
setblock 203 247 598 minecraft:ochre_froglight
setblock 204 247 559 minecraft:ochre_froglight
setblock 204 247 561 minecraft:ochre_froglight
setblock 204 247 591 minecraft:ochre_froglight
setblock 204 247 593 minecraft:ochre_froglight
setblock 204 247 595 minecraft:ochre_froglight
setblock 204 247 597 minecraft:ochre_froglight
fill 204 247 598 204 262 598 minecraft:quartz_block
setblock 205 247 558 minecraft:ochre_froglight
setblock 205 247 560 minecraft:ochre_froglight
setblock 205 247 590 minecraft:ochre_froglight
setblock 205 247 592 minecraft:ochre_froglight
setblock 205 247 594 minecraft:ochre_froglight
setblock 205 247 596 minecraft:ochre_froglight
setblock 205 247 598 minecraft:ochre_froglight
fill 206 247 558 206 257 558 minecraft:quartz_block
setblock 206 247 559 minecraft:ochre_froglight
setblock 206 247 561 minecraft:ochre_froglight
setblock 206 247 591 minecraft:ochre_froglight
setblock 206 247 593 minecraft:ochre_froglight
setblock 206 247 595 minecraft:ochre_froglight
setblock 206 247 597 minecraft:ochre_froglight
setblock 207 247 558 minecraft:ochre_froglight
setblock 207 247 560 minecraft:ochre_froglight
setblock 207 247 590 minecraft:ochre_froglight
setblock 207 247 592 minecraft:ochre_froglight
setblock 207 247 594 minecraft:ochre_froglight
setblock 207 247 596 minecraft:ochre_froglight
setblock 207 247 598 minecraft:ochre_froglight
setblock 208 247 591 minecraft:ochre_froglight
setblock 208 247 593 minecraft:ochre_froglight
setblock 208 247 595 minecraft:ochre_froglight
setblock 208 247 597 minecraft:ochre_froglight
setblock 209 247 590 minecraft:ochre_froglight
setblock 209 247 592 minecraft:ochre_froglight
setblock 209 247 594 minecraft:ochre_froglight
setblock 209 247 596 minecraft:ochre_froglight
setblock 209 247 598 minecraft:ochre_froglight
setblock 210 247 591 minecraft:ochre_froglight
setblock 210 247 593 minecraft:ochre_froglight
setblock 210 247 595 minecraft:ochre_froglight
setblock 210 247 597 minecraft:ochre_froglight
setblock 211 247 590 minecraft:ochre_froglight
setblock 211 247 592 minecraft:ochre_froglight
setblock 211 247 594 minecraft:ochre_froglight
setblock 211 247 596 minecraft:ochre_froglight
setblock 211 247 598 minecraft:ochre_froglight
setblock 212 247 591 minecraft:ochre_froglight
setblock 212 247 593 minecraft:ochre_froglight
setblock 212 247 595 minecraft:ochre_froglight
setblock 212 247 597 minecraft:ochre_froglight
fill 212 247 598 212 262 598 minecraft:quartz_block
setblock 213 247 590 minecraft:ochre_froglight
setblock 213 247 592 minecraft:ochre_froglight
setblock 213 247 594 minecraft:ochre_froglight
setblock 213 247 596 minecraft:ochre_froglight
setblock 213 247 598 minecraft:ochre_froglight
setblock 214 247 591 minecraft:ochre_froglight
setblock 214 247 593 minecraft:ochre_froglight
setblock 214 247 595 minecraft:ochre_froglight
setblock 214 247 597 minecraft:ochre_froglight
fill 214 247 598 214 262 598 minecraft:quartz_block
setblock 215 247 590 minecraft:ochre_froglight
setblock 215 247 592 minecraft:ochre_froglight
setblock 215 247 594 minecraft:ochre_froglight
setblock 215 247 596 minecraft:ochre_froglight
setblock 215 247 598 minecraft:ochre_froglight
setblock 219 247 558 minecraft:ochre_froglight
setblock 219 247 560 minecraft:ochre_froglight
setblock 219 247 562 minecraft:ochre_froglight
setblock 219 247 564 minecraft:ochre_froglight
setblock 219 247 566 minecraft:ochre_froglight
fill 220 247 558 220 255 558 minecraft:quartz_block
setblock 220 247 559 minecraft:ochre_froglight
setblock 220 247 561 minecraft:ochre_froglight
setblock 220 247 563 minecraft:ochre_froglight
setblock 220 247 565 minecraft:ochre_froglight
setblock 220 247 567 minecraft:ochre_froglight
setblock 221 247 558 minecraft:ochre_froglight
setblock 221 247 560 minecraft:ochre_froglight
setblock 221 247 562 minecraft:ochre_froglight
setblock 221 247 564 minecraft:ochre_froglight
setblock 221 247 566 minecraft:ochre_froglight
fill 222 247 558 222 255 558 minecraft:quartz_block
setblock 222 247 559 minecraft:ochre_froglight
setblock 222 247 561 minecraft:ochre_froglight
setblock 222 247 563 minecraft:ochre_froglight
setblock 222 247 565 minecraft:ochre_froglight
setblock 222 247 567 minecraft:ochre_froglight
setblock 223 247 558 minecraft:ochre_froglight
setblock 223 247 560 minecraft:ochre_froglight
setblock 223 247 562 minecraft:ochre_froglight
setblock 223 247 564 minecraft:ochre_froglight
setblock 223 247 566 minecraft:ochre_froglight
setblock 224 247 559 minecraft:ochre_froglight
setblock 224 247 561 minecraft:ochre_froglight
setblock 224 247 563 minecraft:ochre_froglight
setblock 224 247 565 minecraft:ochre_froglight
setblock 224 247 567 minecraft:ochre_froglight
setblock 225 247 558 minecraft:ochre_froglight
setblock 225 247 560 minecraft:ochre_froglight
setblock 225 247 562 minecraft:ochre_froglight
setblock 225 247 564 minecraft:ochre_froglight
setblock 225 247 566 minecraft:ochre_froglight
setblock 226 247 559 minecraft:ochre_froglight
setblock 226 247 561 minecraft:ochre_froglight
setblock 227 247 558 minecraft:ochre_froglight
setblock 227 247 560 minecraft:ochre_froglight
setblock 228 247 559 minecraft:ochre_froglight
setblock 228 247 561 minecraft:ochre_froglight
fill 199 248 558 199 249 558 minecraft:quartz_block
fill 199 248 560 199 249 560 minecraft:quartz_block
fill 200 248 559 200 249 559 minecraft:quartz_block
fill 200 248 561 200 249 561 minecraft:quartz_block
fill 201 248 558 201 249 558 minecraft:quartz_block
fill 201 248 560 201 249 560 minecraft:quartz_block
fill 202 248 559 202 249 559 minecraft:quartz_block
fill 202 248 561 202 249 561 minecraft:quartz_block
fill 203 248 558 203 249 558 minecraft:quartz_block
fill 203 248 560 203 249 560 minecraft:quartz_block
fill 203 248 590 203 249 590 minecraft:quartz_block
fill 203 248 592 203 249 592 minecraft:quartz_block
fill 203 248 594 203 249 594 minecraft:quartz_block
fill 203 248 596 203 249 596 minecraft:quartz_block
fill 203 248 598 203 249 598 minecraft:quartz_block
fill 204 248 559 204 249 559 minecraft:quartz_block
fill 204 248 561 204 249 561 minecraft:quartz_block
fill 204 248 591 204 249 591 minecraft:quartz_block
fill 204 248 593 204 249 593 minecraft:quartz_block
fill 204 248 595 204 249 595 minecraft:quartz_block
fill 204 248 597 204 249 597 minecraft:quartz_block
fill 205 248 558 205 249 558 minecraft:quartz_block
fill 205 248 560 205 249 560 minecraft:quartz_block
fill 205 248 590 205 249 590 minecraft:quartz_block
fill 205 248 592 205 249 592 minecraft:quartz_block
fill 205 248 594 205 249 594 minecraft:quartz_block
fill 205 248 596 205 249 596 minecraft:quartz_block
fill 205 248 598 205 249 598 minecraft:quartz_block
fill 206 248 559 206 249 559 minecraft:quartz_block
fill 206 248 561 206 249 561 minecraft:quartz_block
fill 206 248 591 206 249 591 minecraft:quartz_block
fill 206 248 593 206 249 593 minecraft:quartz_block
fill 206 248 595 206 249 595 minecraft:quartz_block
fill 206 248 597 206 249 597 minecraft:quartz_block
fill 207 248 558 207 249 558 minecraft:quartz_block
fill 207 248 560 207 249 560 minecraft:quartz_block
fill 207 248 590 207 249 590 minecraft:quartz_block
fill 207 248 592 207 249 592 minecraft:quartz_block
fill 207 248 594 207 249 594 minecraft:quartz_block
fill 207 248 596 207 249 596 minecraft:quartz_block
fill 207 248 598 207 249 598 minecraft:quartz_block
fill 208 248 591 208 249 591 minecraft:quartz_block
fill 208 248 593 208 249 593 minecraft:quartz_block
fill 208 248 595 208 249 595 minecraft:quartz_block
fill 208 248 597 208 249 597 minecraft:quartz_block
fill 209 248 590 209 249 590 minecraft:quartz_block
fill 209 248 592 209 249 592 minecraft:quartz_block
fill 209 248 594 209 249 594 minecraft:quartz_block
fill 209 248 596 209 249 596 minecraft:quartz_block
fill 209 248 598 209 249 598 minecraft:quartz_block
fill 210 248 591 210 249 591 minecraft:quartz_block
fill 210 248 593 210 249 593 minecraft:quartz_block
fill 210 248 595 210 249 595 minecraft:quartz_block
fill 210 248 597 210 249 597 minecraft:quartz_block
fill 211 248 590 211 249 590 minecraft:quartz_block
fill 211 248 592 211 249 592 minecraft:quartz_block
fill 211 248 594 211 249 594 minecraft:quartz_block
fill 211 248 596 211 249 596 minecraft:quartz_block
fill 211 248 598 211 249 598 minecraft:quartz_block
fill 212 248 591 212 249 591 minecraft:quartz_block
fill 212 248 593 212 249 593 minecraft:quartz_block
fill 212 248 595 212 249 595 minecraft:quartz_block
fill 212 248 597 212 249 597 minecraft:quartz_block
fill 213 248 590 213 249 590 minecraft:quartz_block
fill 213 248 592 213 249 592 minecraft:quartz_block
fill 213 248 594 213 249 594 minecraft:quartz_block
fill 213 248 596 213 249 596 minecraft:quartz_block
fill 213 248 598 213 249 598 minecraft:quartz_block
fill 214 248 591 214 249 591 minecraft:quartz_block
fill 214 248 593 214 249 593 minecraft:quartz_block
fill 214 248 595 214 249 595 minecraft:quartz_block
fill 214 248 597 214 249 597 minecraft:quartz_block
fill 215 248 590 215 249 590 minecraft:quartz_block
fill 215 248 592 215 249 592 minecraft:quartz_block
fill 215 248 594 215 249 594 minecraft:quartz_block
fill 215 248 596 215 249 596 minecraft:quartz_block
fill 215 248 598 215 249 598 minecraft:quartz_block
fill 219 248 558 219 249 558 minecraft:quartz_block
fill 219 248 560 219 249 560 minecraft:quartz_block
fill 219 248 562 219 249 562 minecraft:quartz_block
fill 219 248 564 219 249 564 minecraft:quartz_block
fill 219 248 566 219 249 566 minecraft:quartz_block
fill 220 248 559 220 249 559 minecraft:quartz_block
fill 220 248 561 220 249 561 minecraft:quartz_block
fill 220 248 563 220 249 563 minecraft:quartz_block
fill 220 248 565 220 249 565 minecraft:quartz_block
fill 220 248 567 220 249 567 minecraft:quartz_block
fill 221 248 558 221 249 558 minecraft:quartz_block
fill 221 248 560 221 249 560 minecraft:quartz_block
fill 221 248 562 221 249 562 minecraft:quartz_block
fill 221 248 564 221 249 564 minecraft:quartz_block
fill 221 248 566 221 249 566 minecraft:quartz_block
fill 222 248 559 222 249 559 minecraft:quartz_block
fill 222 248 561 222 249 561 minecraft:quartz_block
fill 222 248 563 222 249 563 minecraft:quartz_block
fill 222 248 565 222 249 565 minecraft:quartz_block
fill 222 248 567 222 249 567 minecraft:quartz_block
fill 223 248 558 223 249 558 minecraft:quartz_block
fill 223 248 560 223 249 560 minecraft:quartz_block
fill 223 248 562 223 249 562 minecraft:quartz_block
fill 223 248 564 223 249 564 minecraft:quartz_block
fill 223 248 566 223 249 566 minecraft:quartz_block
fill 224 248 559 224 249 559 minecraft:quartz_block
fill 224 248 561 224 249 561 minecraft:quartz_block
fill 224 248 563 224 249 563 minecraft:quartz_block
fill 224 248 565 224 249 565 minecraft:quartz_block
fill 224 248 567 224 249 567 minecraft:quartz_block
fill 225 248 558 225 249 558 minecraft:quartz_block
fill 225 248 560 225 249 560 minecraft:quartz_block
fill 225 248 562 225 249 562 minecraft:quartz_block
fill 225 248 564 225 249 564 minecraft:quartz_block
fill 225 248 566 225 249 566 minecraft:quartz_block
fill 226 248 559 226 249 559 minecraft:quartz_block
fill 226 248 561 226 249 561 minecraft:quartz_block
fill 227 248 558 227 273 558 minecraft:quartz_block
fill 227 248 560 227 249 560 minecraft:quartz_block
fill 228 248 559 228 249 559 minecraft:quartz_block
fill 228 248 561 228 249 561 minecraft:quartz_block
setblock 191 250 560 minecraft:light[level=14]
setblock 191 250 568 minecraft:light[level=14]
setblock 191 250 576 minecraft:light[level=14]
setblock 191 250 584 minecraft:light[level=14]
setblock 191 250 592 minecraft:light[level=14]
setblock 199 250 558 minecraft:ochre_froglight
setblock 199 250 560 minecraft:ochre_froglight
setblock 199 250 568 minecraft:light[level=14]
setblock 199 250 576 minecraft:light[level=14]
setblock 199 250 584 minecraft:light[level=14]
setblock 199 250 592 minecraft:light[level=14]
setblock 200 250 559 minecraft:ochre_froglight
setblock 200 250 561 minecraft:ochre_froglight
setblock 201 250 558 minecraft:ochre_froglight
setblock 201 250 560 minecraft:ochre_froglight
setblock 202 250 559 minecraft:ochre_froglight
setblock 202 250 561 minecraft:ochre_froglight
setblock 203 250 558 minecraft:ochre_froglight
setblock 203 250 560 minecraft:ochre_froglight
setblock 203 250 590 minecraft:ochre_froglight
setblock 203 250 592 minecraft:ochre_froglight
setblock 203 250 594 minecraft:ochre_froglight
setblock 203 250 596 minecraft:ochre_froglight
setblock 203 250 598 minecraft:ochre_froglight
setblock 204 250 559 minecraft:ochre_froglight
setblock 204 250 561 minecraft:ochre_froglight
setblock 204 250 591 minecraft:ochre_froglight
setblock 204 250 593 minecraft:ochre_froglight
setblock 204 250 595 minecraft:ochre_froglight
setblock 204 250 597 minecraft:ochre_froglight
setblock 205 250 558 minecraft:ochre_froglight
setblock 205 250 560 minecraft:ochre_froglight
setblock 205 250 590 minecraft:ochre_froglight
setblock 205 250 592 minecraft:ochre_froglight
setblock 205 250 594 minecraft:ochre_froglight
setblock 205 250 596 minecraft:ochre_froglight
setblock 205 250 598 minecraft:ochre_froglight
setblock 206 250 559 minecraft:ochre_froglight
setblock 206 250 561 minecraft:ochre_froglight
setblock 206 250 591 minecraft:ochre_froglight
setblock 206 250 593 minecraft:ochre_froglight
setblock 206 250 595 minecraft:ochre_froglight
setblock 206 250 597 minecraft:ochre_froglight
setblock 207 250 558 minecraft:ochre_froglight
setblock 207 250 560 minecraft:ochre_froglight
setblock 207 250 568 minecraft:light[level=14]
setblock 207 250 584 minecraft:light[level=14]
setblock 207 250 590 minecraft:ochre_froglight
setblock 207 250 592 minecraft:ochre_froglight
setblock 207 250 594 minecraft:ochre_froglight
setblock 207 250 596 minecraft:ochre_froglight
setblock 207 250 598 minecraft:ochre_froglight
setblock 208 250 591 minecraft:ochre_froglight
setblock 208 250 593 minecraft:ochre_froglight
setblock 208 250 595 minecraft:ochre_froglight
setblock 208 250 597 minecraft:ochre_froglight
setblock 209 250 590 minecraft:ochre_froglight
setblock 209 250 592 minecraft:ochre_froglight
setblock 209 250 594 minecraft:ochre_froglight
setblock 209 250 596 minecraft:ochre_froglight
setblock 209 250 598 minecraft:ochre_froglight
setblock 210 250 591 minecraft:ochre_froglight
setblock 210 250 593 minecraft:ochre_froglight
setblock 210 250 595 minecraft:ochre_froglight
setblock 210 250 597 minecraft:ochre_froglight
setblock 211 250 590 minecraft:ochre_froglight
setblock 211 250 592 minecraft:ochre_froglight
setblock 211 250 594 minecraft:ochre_froglight
setblock 211 250 596 minecraft:ochre_froglight
setblock 211 250 598 minecraft:ochre_froglight
setblock 212 250 591 minecraft:ochre_froglight
setblock 212 250 593 minecraft:ochre_froglight
setblock 212 250 595 minecraft:ochre_froglight
setblock 212 250 597 minecraft:ochre_froglight
setblock 213 250 590 minecraft:ochre_froglight
setblock 213 250 592 minecraft:ochre_froglight
setblock 213 250 594 minecraft:ochre_froglight
setblock 213 250 596 minecraft:ochre_froglight
setblock 213 250 598 minecraft:ochre_froglight
setblock 214 250 591 minecraft:ochre_froglight
setblock 214 250 593 minecraft:ochre_froglight
setblock 214 250 595 minecraft:ochre_froglight
setblock 214 250 597 minecraft:ochre_froglight
setblock 215 250 560 minecraft:light[level=14]
setblock 215 250 568 minecraft:light[level=14]
setblock 215 250 576 minecraft:light[level=14]
setblock 215 250 584 minecraft:light[level=14]
setblock 215 250 590 minecraft:ochre_froglight
setblock 215 250 592 minecraft:ochre_froglight
setblock 215 250 594 minecraft:ochre_froglight
setblock 215 250 596 minecraft:ochre_froglight
setblock 215 250 598 minecraft:ochre_froglight
setblock 219 250 558 minecraft:ochre_froglight
setblock 219 250 560 minecraft:ochre_froglight
setblock 219 250 562 minecraft:ochre_froglight
setblock 219 250 564 minecraft:ochre_froglight
setblock 219 250 566 minecraft:ochre_froglight
setblock 220 250 559 minecraft:ochre_froglight
setblock 220 250 561 minecraft:ochre_froglight
setblock 220 250 563 minecraft:ochre_froglight
setblock 220 250 565 minecraft:ochre_froglight
setblock 220 250 567 minecraft:ochre_froglight
setblock 221 250 558 minecraft:ochre_froglight
setblock 221 250 559 minecraft:gold_block
setblock 221 250 560 minecraft:ochre_froglight
setblock 221 250 562 minecraft:ochre_froglight
setblock 221 250 564 minecraft:ochre_froglight
setblock 221 250 566 minecraft:ochre_froglight
setblock 222 250 559 minecraft:ochre_froglight
fill 222 250 560 222 251 560 minecraft:gold_block
setblock 222 250 561 minecraft:ochre_froglight
setblock 222 250 563 minecraft:ochre_froglight
setblock 222 250 565 minecraft:ochre_froglight
setblock 222 250 567 minecraft:ochre_froglight
setblock 223 250 558 minecraft:ochre_froglight
fill 223 250 559 223 252 559 minecraft:gold_block
setblock 223 250 560 minecraft:ochre_froglight
setblock 223 250 562 minecraft:ochre_froglight
setblock 223 250 564 minecraft:ochre_froglight
setblock 223 250 566 minecraft:ochre_froglight
setblock 223 250 568 minecraft:light[level=14]
setblock 223 250 576 minecraft:light[level=14]
setblock 223 250 584 minecraft:light[level=14]
setblock 223 250 592 minecraft:light[level=14]
setblock 224 250 559 minecraft:ochre_froglight
fill 224 250 560 224 253 560 minecraft:gold_block
setblock 224 250 561 minecraft:ochre_froglight
setblock 224 250 563 minecraft:ochre_froglight
setblock 224 250 565 minecraft:ochre_froglight
setblock 224 250 567 minecraft:ochre_froglight
setblock 225 250 558 minecraft:ochre_froglight
fill 225 250 559 227 250 559 minecraft:gold_block
setblock 225 250 560 minecraft:ochre_froglight
setblock 225 250 562 minecraft:ochre_froglight
setblock 225 250 564 minecraft:ochre_froglight
setblock 225 250 566 minecraft:ochre_froglight
fill 226 250 560 227 250 560 minecraft:gold_block
fill 199 251 558 199 252 558 minecraft:quartz_block
fill 199 251 560 199 252 560 minecraft:quartz_block
fill 200 251 559 200 252 559 minecraft:quartz_block
fill 200 251 561 200 252 561 minecraft:quartz_block
fill 201 251 558 201 252 558 minecraft:quartz_block
fill 201 251 560 201 252 560 minecraft:quartz_block
fill 202 251 559 202 252 559 minecraft:quartz_block
fill 202 251 561 202 252 561 minecraft:quartz_block
fill 203 251 558 203 252 558 minecraft:quartz_block
fill 203 251 560 203 252 560 minecraft:quartz_block
fill 203 251 590 203 252 590 minecraft:quartz_block
fill 203 251 592 203 252 592 minecraft:quartz_block
fill 203 251 594 203 252 594 minecraft:quartz_block
fill 203 251 596 203 252 596 minecraft:quartz_block
fill 203 251 598 203 252 598 minecraft:quartz_block
fill 204 251 559 204 252 559 minecraft:quartz_block
fill 204 251 561 204 252 561 minecraft:quartz_block
fill 204 251 591 204 252 591 minecraft:quartz_block
fill 204 251 593 204 252 593 minecraft:quartz_block
fill 204 251 595 204 252 595 minecraft:quartz_block
fill 204 251 597 204 252 597 minecraft:quartz_block
fill 205 251 558 205 252 558 minecraft:quartz_block
fill 205 251 560 205 252 560 minecraft:quartz_block
fill 205 251 590 205 252 590 minecraft:quartz_block
fill 205 251 592 205 252 592 minecraft:quartz_block
fill 205 251 594 205 252 594 minecraft:quartz_block
fill 205 251 596 205 252 596 minecraft:quartz_block
fill 205 251 598 205 252 598 minecraft:quartz_block
fill 206 251 559 206 252 559 minecraft:quartz_block
fill 206 251 561 206 252 561 minecraft:quartz_block
fill 206 251 591 206 252 591 minecraft:quartz_block
fill 206 251 593 206 252 593 minecraft:quartz_block
fill 206 251 595 206 252 595 minecraft:quartz_block
fill 206 251 597 206 252 597 minecraft:quartz_block
fill 207 251 558 207 252 558 minecraft:quartz_block
fill 207 251 560 207 252 560 minecraft:quartz_block
fill 207 251 590 207 252 590 minecraft:quartz_block
fill 207 251 592 207 252 592 minecraft:quartz_block
fill 207 251 594 207 252 594 minecraft:quartz_block
fill 207 251 596 207 252 596 minecraft:quartz_block
fill 207 251 598 207 252 598 minecraft:quartz_block
fill 208 251 591 208 252 591 minecraft:quartz_block
fill 208 251 593 208 252 593 minecraft:quartz_block
fill 208 251 595 208 252 595 minecraft:quartz_block
fill 208 251 597 208 252 597 minecraft:quartz_block
fill 209 251 590 209 252 590 minecraft:quartz_block
fill 209 251 592 209 252 592 minecraft:quartz_block
fill 209 251 594 209 252 594 minecraft:quartz_block
fill 209 251 596 209 252 596 minecraft:quartz_block
fill 209 251 598 209 252 598 minecraft:quartz_block
fill 210 251 591 210 252 591 minecraft:quartz_block
fill 210 251 593 210 252 593 minecraft:quartz_block
fill 210 251 595 210 252 595 minecraft:quartz_block
fill 210 251 597 210 252 597 minecraft:quartz_block
fill 211 251 590 211 252 590 minecraft:quartz_block
fill 211 251 592 211 252 592 minecraft:quartz_block
fill 211 251 594 211 252 594 minecraft:quartz_block
fill 211 251 596 211 252 596 minecraft:quartz_block
fill 211 251 598 211 252 598 minecraft:quartz_block
fill 212 251 591 212 252 591 minecraft:quartz_block
fill 212 251 593 212 252 593 minecraft:quartz_block
fill 212 251 595 212 252 595 minecraft:quartz_block
fill 212 251 597 212 252 597 minecraft:quartz_block
fill 213 251 590 213 252 590 minecraft:quartz_block
fill 213 251 592 213 252 592 minecraft:quartz_block
fill 213 251 594 213 252 594 minecraft:quartz_block
fill 213 251 596 213 252 596 minecraft:quartz_block
fill 213 251 598 213 252 598 minecraft:quartz_block
fill 214 251 591 214 252 591 minecraft:quartz_block
fill 214 251 593 214 252 593 minecraft:quartz_block
fill 214 251 595 214 252 595 minecraft:quartz_block
fill 214 251 597 214 252 597 minecraft:quartz_block
fill 215 251 590 215 252 590 minecraft:quartz_block
fill 215 251 592 215 252 592 minecraft:quartz_block
fill 215 251 594 215 252 594 minecraft:quartz_block
fill 215 251 596 215 252 596 minecraft:quartz_block
fill 215 251 598 215 252 598 minecraft:quartz_block
fill 219 251 558 219 252 558 minecraft:quartz_block
fill 219 251 560 219 252 560 minecraft:quartz_block
fill 219 251 562 219 252 562 minecraft:quartz_block
fill 219 251 564 219 252 564 minecraft:quartz_block
fill 219 251 566 219 252 566 minecraft:quartz_block
fill 220 251 559 221 252 559 minecraft:quartz_block
fill 220 251 561 220 252 561 minecraft:quartz_block
fill 220 251 563 220 252 563 minecraft:quartz_block
fill 220 251 565 220 252 565 minecraft:quartz_block
fill 220 251 567 220 252 567 minecraft:quartz_block
fill 221 251 558 221 252 558 minecraft:quartz_block
fill 221 251 560 221 252 560 minecraft:quartz_block
fill 221 251 562 221 252 562 minecraft:quartz_block
fill 221 251 564 221 252 564 minecraft:quartz_block
fill 221 251 566 221 252 566 minecraft:quartz_block
setblock 222 251 559 minecraft:gold_block
fill 222 251 561 222 252 561 minecraft:quartz_block
fill 222 251 563 222 252 563 minecraft:quartz_block
fill 222 251 565 222 252 565 minecraft:quartz_block
fill 222 251 567 222 252 567 minecraft:quartz_block
setblock 223 251 558 minecraft:quartz_block
fill 223 251 560 223 252 560 minecraft:gold_block
fill 223 251 562 223 252 562 minecraft:quartz_block
fill 223 251 564 223 252 564 minecraft:quartz_block
fill 223 251 566 223 252 566 minecraft:quartz_block
fill 224 251 559 226 251 559 minecraft:gold_block
setblock 224 251 561 minecraft:quartz_block
fill 224 251 563 224 252 563 minecraft:quartz_block
fill 224 251 565 224 252 565 minecraft:quartz_block
fill 224 251 567 224 252 567 minecraft:quartz_block
fill 225 251 558 225 252 558 minecraft:quartz_block
fill 225 251 560 226 251 560 minecraft:gold_block
fill 225 251 562 225 252 562 minecraft:quartz_block
fill 225 251 564 225 252 564 minecraft:quartz_block
fill 225 251 566 225 252 566 minecraft:quartz_block
fill 188 252 563 188 265 563 minecraft:gold_block
fill 188 252 564 188 252 565 minecraft:ochre_froglight
fill 188 252 566 188 265 566 minecraft:gold_block
fill 188 252 575 188 265 575 minecraft:gold_block
fill 188 252 576 188 252 577 minecraft:ochre_froglight
fill 188 252 578 188 265 578 minecraft:gold_block
fill 188 252 587 188 265 587 minecraft:gold_block
fill 188 252 588 188 252 589 minecraft:ochre_froglight
fill 188 252 590 188 265 590 minecraft:gold_block
fill 188 252 599 188 265 599 minecraft:gold_block
fill 189 252 599 190 252 599 minecraft:ochre_froglight
fill 191 252 599 191 265 599 minecraft:gold_block
fill 195 252 557 195 265 557 minecraft:gold_block
fill 196 252 557 197 252 557 minecraft:ochre_froglight
fill 198 252 557 198 265 557 minecraft:gold_block
fill 200 252 599 200 265 599 minecraft:gold_block
fill 201 252 599 202 252 599 minecraft:ochre_froglight
fill 203 252 599 203 265 599 minecraft:gold_block
fill 207 252 557 207 265 557 minecraft:gold_block
fill 208 252 557 209 252 557 minecraft:ochre_froglight
fill 210 252 557 210 265 557 minecraft:gold_block
fill 212 252 599 212 265 599 minecraft:gold_block
fill 213 252 599 214 252 599 minecraft:ochre_froglight
fill 215 252 599 215 265 599 minecraft:gold_block
fill 219 252 557 219 265 557 minecraft:gold_block
fill 220 252 557 221 252 557 minecraft:ochre_froglight
fill 222 252 557 222 265 557 minecraft:gold_block
fill 222 252 559 222 252 560 minecraft:quartz_block
fill 223 252 558 224 252 558 minecraft:gold_block
fill 223 252 561 225 252 561 minecraft:gold_block
fill 224 252 559 225 252 559 minecraft:gold_block
fill 224 252 599 224 265 599 minecraft:gold_block
setblock 225 252 560 minecraft:gold_block
fill 225 252 599 226 252 599 minecraft:ochre_froglight
fill 227 252 599 227 265 599 minecraft:gold_block
fill 230 252 558 230 265 558 minecraft:gold_block
fill 230 252 559 230 252 560 minecraft:ochre_froglight
fill 230 252 561 230 265 561 minecraft:gold_block
fill 230 252 570 230 265 570 minecraft:gold_block
fill 230 252 571 230 252 572 minecraft:ochre_froglight
fill 230 252 573 230 265 573 minecraft:gold_block
fill 230 252 582 230 265 582 minecraft:gold_block
fill 230 252 583 230 252 584 minecraft:ochre_froglight
fill 230 252 585 230 265 585 minecraft:gold_block
fill 230 252 594 230 265 594 minecraft:gold_block
fill 230 252 595 230 252 596 minecraft:ochre_froglight
fill 230 252 597 230 265 597 minecraft:gold_block
fill 188 253 564 188 265 565 minecraft:gold_block
fill 188 253 576 188 265 577 minecraft:gold_block
fill 188 253 588 188 265 589 minecraft:gold_block
fill 189 253 599 190 265 599 minecraft:gold_block
fill 196 253 557 197 265 557 minecraft:gold_block
setblock 199 253 558 minecraft:ochre_froglight
setblock 199 253 560 minecraft:ochre_froglight
setblock 200 253 559 minecraft:ochre_froglight
setblock 200 253 561 minecraft:ochre_froglight
setblock 201 253 558 minecraft:ochre_froglight
setblock 201 253 560 minecraft:ochre_froglight
fill 201 253 599 202 265 599 minecraft:gold_block
setblock 202 253 559 minecraft:ochre_froglight
setblock 202 253 561 minecraft:ochre_froglight
setblock 203 253 558 minecraft:ochre_froglight
setblock 203 253 560 minecraft:ochre_froglight
setblock 203 253 590 minecraft:ochre_froglight
setblock 203 253 592 minecraft:ochre_froglight
setblock 203 253 594 minecraft:ochre_froglight
setblock 203 253 596 minecraft:ochre_froglight
setblock 203 253 598 minecraft:ochre_froglight
setblock 204 253 559 minecraft:ochre_froglight
setblock 204 253 561 minecraft:ochre_froglight
setblock 204 253 591 minecraft:ochre_froglight
setblock 204 253 593 minecraft:ochre_froglight
setblock 204 253 595 minecraft:ochre_froglight
setblock 204 253 597 minecraft:ochre_froglight
setblock 205 253 558 minecraft:ochre_froglight
setblock 205 253 560 minecraft:ochre_froglight
setblock 205 253 590 minecraft:ochre_froglight
setblock 205 253 592 minecraft:ochre_froglight
setblock 205 253 594 minecraft:ochre_froglight
setblock 205 253 596 minecraft:ochre_froglight
setblock 205 253 598 minecraft:ochre_froglight
setblock 206 253 559 minecraft:ochre_froglight
setblock 206 253 561 minecraft:ochre_froglight
setblock 206 253 591 minecraft:ochre_froglight
setblock 206 253 593 minecraft:ochre_froglight
setblock 206 253 595 minecraft:ochre_froglight
setblock 206 253 597 minecraft:ochre_froglight
setblock 207 253 558 minecraft:ochre_froglight
setblock 207 253 560 minecraft:ochre_froglight
setblock 207 253 590 minecraft:ochre_froglight
setblock 207 253 592 minecraft:ochre_froglight
setblock 207 253 594 minecraft:ochre_froglight
setblock 207 253 596 minecraft:ochre_froglight
setblock 207 253 598 minecraft:ochre_froglight
fill 208 253 557 209 265 557 minecraft:gold_block
setblock 208 253 591 minecraft:ochre_froglight
setblock 208 253 593 minecraft:ochre_froglight
setblock 208 253 595 minecraft:ochre_froglight
setblock 208 253 597 minecraft:ochre_froglight
setblock 209 253 590 minecraft:ochre_froglight
setblock 209 253 592 minecraft:ochre_froglight
setblock 209 253 594 minecraft:ochre_froglight
setblock 209 253 596 minecraft:ochre_froglight
setblock 209 253 598 minecraft:ochre_froglight
setblock 210 253 591 minecraft:ochre_froglight
setblock 210 253 593 minecraft:ochre_froglight
setblock 210 253 595 minecraft:ochre_froglight
setblock 210 253 597 minecraft:ochre_froglight
setblock 211 253 590 minecraft:ochre_froglight
setblock 211 253 592 minecraft:ochre_froglight
setblock 211 253 594 minecraft:ochre_froglight
setblock 211 253 596 minecraft:ochre_froglight
setblock 211 253 598 minecraft:ochre_froglight
setblock 212 253 591 minecraft:ochre_froglight
setblock 212 253 593 minecraft:ochre_froglight
setblock 212 253 595 minecraft:ochre_froglight
setblock 212 253 597 minecraft:ochre_froglight
setblock 213 253 590 minecraft:ochre_froglight
setblock 213 253 592 minecraft:ochre_froglight
setblock 213 253 594 minecraft:ochre_froglight
setblock 213 253 596 minecraft:ochre_froglight
setblock 213 253 598 minecraft:ochre_froglight
fill 213 253 599 214 265 599 minecraft:gold_block
setblock 214 253 591 minecraft:ochre_froglight
setblock 214 253 593 minecraft:ochre_froglight
setblock 214 253 595 minecraft:ochre_froglight
setblock 214 253 597 minecraft:ochre_froglight
setblock 215 253 590 minecraft:ochre_froglight
setblock 215 253 592 minecraft:ochre_froglight
setblock 215 253 594 minecraft:ochre_froglight
setblock 215 253 596 minecraft:ochre_froglight
setblock 215 253 598 minecraft:ochre_froglight
setblock 219 253 558 minecraft:ochre_froglight
setblock 219 253 560 minecraft:ochre_froglight
setblock 219 253 562 minecraft:ochre_froglight
setblock 219 253 564 minecraft:ochre_froglight
setblock 219 253 566 minecraft:ochre_froglight
fill 220 253 557 221 265 557 minecraft:gold_block
setblock 220 253 559 minecraft:ochre_froglight
setblock 220 253 561 minecraft:ochre_froglight
setblock 220 253 563 minecraft:ochre_froglight
setblock 220 253 565 minecraft:ochre_froglight
setblock 220 253 567 minecraft:ochre_froglight
setblock 221 253 558 minecraft:ochre_froglight
fill 221 253 559 221 255 559 minecraft:quartz_block
setblock 221 253 560 minecraft:ochre_froglight
setblock 221 253 562 minecraft:ochre_froglight
setblock 221 253 564 minecraft:ochre_froglight
setblock 221 253 566 minecraft:ochre_froglight
setblock 222 253 559 minecraft:ochre_froglight
fill 222 253 560 222 255 560 minecraft:quartz_block
setblock 222 253 561 minecraft:ochre_froglight
setblock 222 253 563 minecraft:ochre_froglight
setblock 222 253 565 minecraft:ochre_froglight
setblock 222 253 567 minecraft:ochre_froglight
setblock 223 253 558 minecraft:ochre_froglight
fill 223 253 559 223 255 559 minecraft:quartz_block
setblock 223 253 560 minecraft:ochre_froglight
fill 223 253 561 223 255 561 minecraft:quartz_block
setblock 223 253 562 minecraft:ochre_froglight
setblock 223 253 564 minecraft:ochre_froglight
setblock 223 253 566 minecraft:ochre_froglight
setblock 224 253 558 minecraft:gold_block
setblock 224 253 559 minecraft:ochre_froglight
setblock 224 253 561 minecraft:ochre_froglight
setblock 224 253 562 minecraft:gold_block
setblock 224 253 563 minecraft:ochre_froglight
setblock 224 253 565 minecraft:ochre_froglight
setblock 224 253 567 minecraft:ochre_froglight
setblock 225 253 558 minecraft:ochre_froglight
fill 225 253 559 225 255 559 minecraft:quartz_block
setblock 225 253 560 minecraft:ochre_froglight
fill 225 253 561 225 255 561 minecraft:quartz_block
setblock 225 253 562 minecraft:ochre_froglight
setblock 225 253 564 minecraft:ochre_froglight
setblock 225 253 566 minecraft:ochre_froglight
fill 225 253 599 226 265 599 minecraft:gold_block
fill 230 253 559 230 265 560 minecraft:gold_block
fill 230 253 571 230 265 572 minecraft:gold_block
fill 230 253 583 230 265 584 minecraft:gold_block
fill 230 253 595 230 265 596 minecraft:gold_block
fill 199 254 558 199 255 558 minecraft:quartz_block
fill 199 254 560 199 255 560 minecraft:quartz_block
fill 200 254 559 200 255 559 minecraft:quartz_block
fill 200 254 561 200 255 561 minecraft:quartz_block
fill 201 254 558 201 255 558 minecraft:quartz_block
fill 201 254 560 201 255 560 minecraft:quartz_block
fill 202 254 559 202 255 559 minecraft:quartz_block
fill 202 254 561 202 255 561 minecraft:quartz_block
fill 203 254 558 203 255 558 minecraft:quartz_block
fill 203 254 560 203 255 560 minecraft:quartz_block
fill 203 254 590 203 255 590 minecraft:quartz_block
fill 203 254 592 203 255 592 minecraft:quartz_block
fill 203 254 594 203 255 594 minecraft:quartz_block
fill 203 254 596 203 255 596 minecraft:quartz_block
fill 203 254 598 203 255 598 minecraft:quartz_block
fill 204 254 559 204 255 559 minecraft:quartz_block
fill 204 254 561 204 255 561 minecraft:quartz_block
fill 204 254 591 204 255 591 minecraft:quartz_block
fill 204 254 593 204 255 593 minecraft:quartz_block
fill 204 254 595 204 255 595 minecraft:quartz_block
fill 204 254 597 204 255 597 minecraft:quartz_block
fill 205 254 558 205 255 558 minecraft:quartz_block
fill 205 254 560 205 255 560 minecraft:quartz_block
fill 205 254 590 205 255 590 minecraft:quartz_block
fill 205 254 592 205 255 592 minecraft:quartz_block
fill 205 254 594 205 255 594 minecraft:quartz_block
fill 205 254 596 205 255 596 minecraft:quartz_block
fill 205 254 598 205 255 598 minecraft:quartz_block
fill 206 254 559 206 255 559 minecraft:quartz_block
fill 206 254 561 206 255 561 minecraft:quartz_block
fill 206 254 591 206 255 591 minecraft:quartz_block
fill 206 254 593 206 255 593 minecraft:quartz_block
fill 206 254 595 206 255 595 minecraft:quartz_block
fill 206 254 597 206 255 597 minecraft:quartz_block
fill 207 254 558 207 255 558 minecraft:quartz_block
fill 207 254 560 207 255 560 minecraft:quartz_block
fill 207 254 590 207 255 590 minecraft:quartz_block
fill 207 254 592 207 255 592 minecraft:quartz_block
fill 207 254 594 207 255 594 minecraft:quartz_block
fill 207 254 596 207 255 596 minecraft:quartz_block
fill 207 254 598 207 255 598 minecraft:quartz_block
fill 208 254 591 208 255 591 minecraft:quartz_block
fill 208 254 593 208 255 593 minecraft:quartz_block
fill 208 254 595 208 255 595 minecraft:quartz_block
fill 208 254 597 208 255 597 minecraft:quartz_block
fill 209 254 590 209 255 590 minecraft:quartz_block
fill 209 254 592 209 255 592 minecraft:quartz_block
fill 209 254 594 209 255 594 minecraft:quartz_block
fill 209 254 596 209 255 596 minecraft:quartz_block
fill 209 254 598 209 255 598 minecraft:quartz_block
fill 210 254 591 210 255 591 minecraft:quartz_block
fill 210 254 593 210 255 593 minecraft:quartz_block
fill 210 254 595 210 255 595 minecraft:quartz_block
fill 210 254 597 210 255 597 minecraft:quartz_block
fill 211 254 590 211 255 590 minecraft:quartz_block
fill 211 254 592 211 255 592 minecraft:quartz_block
fill 211 254 594 211 255 594 minecraft:quartz_block
fill 211 254 596 211 255 596 minecraft:quartz_block
fill 211 254 598 211 255 598 minecraft:quartz_block
fill 212 254 591 212 255 591 minecraft:quartz_block
fill 212 254 593 212 255 593 minecraft:quartz_block
fill 212 254 595 212 255 595 minecraft:quartz_block
fill 212 254 597 212 255 597 minecraft:quartz_block
fill 213 254 590 213 255 590 minecraft:quartz_block
fill 213 254 592 213 255 592 minecraft:quartz_block
fill 213 254 594 213 255 594 minecraft:quartz_block
fill 213 254 596 213 255 596 minecraft:quartz_block
fill 213 254 598 213 255 598 minecraft:quartz_block
fill 214 254 591 214 255 591 minecraft:quartz_block
fill 214 254 593 214 255 593 minecraft:quartz_block
fill 214 254 595 214 255 595 minecraft:quartz_block
fill 214 254 597 214 255 597 minecraft:quartz_block
fill 215 254 590 215 255 590 minecraft:quartz_block
fill 215 254 592 215 255 592 minecraft:quartz_block
fill 215 254 594 215 255 594 minecraft:quartz_block
fill 215 254 596 215 255 596 minecraft:quartz_block
fill 215 254 598 215 255 598 minecraft:quartz_block
fill 219 254 558 219 255 558 minecraft:quartz_block
fill 219 254 560 219 255 560 minecraft:quartz_block
fill 219 254 562 219 255 562 minecraft:quartz_block
fill 219 254 564 219 255 564 minecraft:quartz_block
fill 219 254 566 219 255 566 minecraft:quartz_block
fill 220 254 559 220 255 559 minecraft:quartz_block
fill 220 254 561 220 255 561 minecraft:quartz_block
fill 220 254 563 220 255 563 minecraft:quartz_block
fill 220 254 565 220 255 565 minecraft:quartz_block
fill 220 254 567 220 255 567 minecraft:quartz_block
fill 221 254 558 221 255 558 minecraft:quartz_block
fill 221 254 560 221 255 560 minecraft:quartz_block
fill 221 254 562 221 255 562 minecraft:quartz_block
fill 221 254 564 221 255 564 minecraft:quartz_block
fill 221 254 566 221 255 566 minecraft:quartz_block
fill 222 254 559 222 255 559 minecraft:quartz_block
fill 222 254 561 222 255 561 minecraft:quartz_block
fill 222 254 563 222 255 563 minecraft:quartz_block
fill 222 254 565 222 255 565 minecraft:quartz_block
fill 222 254 567 222 255 567 minecraft:quartz_block
fill 223 254 558 225 255 558 minecraft:quartz_block
fill 223 254 560 225 255 560 minecraft:quartz_block
fill 223 254 562 225 255 562 minecraft:quartz_block
fill 223 254 564 223 255 564 minecraft:quartz_block
fill 223 254 566 223 255 566 minecraft:quartz_block
fill 224 254 559 224 255 559 minecraft:quartz_block
fill 224 254 561 224 255 561 minecraft:quartz_block
fill 224 254 563 224 255 563 minecraft:quartz_block
fill 224 254 565 224 255 565 minecraft:quartz_block
fill 224 254 567 224 255 567 minecraft:quartz_block
fill 225 254 564 225 255 564 minecraft:quartz_block
fill 225 254 566 225 255 566 minecraft:quartz_block
setblock 199 256 558 minecraft:ochre_froglight
setblock 199 256 560 minecraft:ochre_froglight
setblock 200 256 559 minecraft:ochre_froglight
setblock 200 256 561 minecraft:ochre_froglight
setblock 201 256 558 minecraft:ochre_froglight
setblock 201 256 560 minecraft:ochre_froglight
setblock 202 256 559 minecraft:ochre_froglight
setblock 202 256 561 minecraft:ochre_froglight
setblock 203 256 558 minecraft:ochre_froglight
setblock 203 256 560 minecraft:ochre_froglight
setblock 203 256 590 minecraft:ochre_froglight
setblock 203 256 592 minecraft:ochre_froglight
setblock 203 256 594 minecraft:ochre_froglight
setblock 203 256 596 minecraft:ochre_froglight
setblock 203 256 598 minecraft:ochre_froglight
setblock 204 256 559 minecraft:ochre_froglight
setblock 204 256 561 minecraft:ochre_froglight
setblock 204 256 591 minecraft:ochre_froglight
setblock 204 256 593 minecraft:ochre_froglight
setblock 204 256 595 minecraft:ochre_froglight
setblock 204 256 597 minecraft:ochre_froglight
setblock 205 256 558 minecraft:ochre_froglight
setblock 205 256 560 minecraft:ochre_froglight
setblock 205 256 590 minecraft:ochre_froglight
setblock 205 256 592 minecraft:ochre_froglight
setblock 205 256 594 minecraft:ochre_froglight
setblock 205 256 596 minecraft:ochre_froglight
setblock 205 256 598 minecraft:ochre_froglight
setblock 206 256 559 minecraft:ochre_froglight
setblock 206 256 561 minecraft:ochre_froglight
setblock 206 256 591 minecraft:ochre_froglight
setblock 206 256 593 minecraft:ochre_froglight
setblock 206 256 595 minecraft:ochre_froglight
setblock 206 256 597 minecraft:ochre_froglight
setblock 207 256 558 minecraft:ochre_froglight
setblock 207 256 560 minecraft:ochre_froglight
setblock 207 256 590 minecraft:ochre_froglight
setblock 207 256 592 minecraft:ochre_froglight
setblock 207 256 594 minecraft:ochre_froglight
setblock 207 256 596 minecraft:ochre_froglight
setblock 207 256 598 minecraft:ochre_froglight
setblock 208 256 591 minecraft:ochre_froglight
setblock 208 256 593 minecraft:ochre_froglight
setblock 208 256 595 minecraft:ochre_froglight
setblock 208 256 597 minecraft:ochre_froglight
setblock 209 256 590 minecraft:ochre_froglight
setblock 209 256 592 minecraft:ochre_froglight
setblock 209 256 594 minecraft:ochre_froglight
setblock 209 256 596 minecraft:ochre_froglight
setblock 209 256 598 minecraft:ochre_froglight
setblock 210 256 591 minecraft:ochre_froglight
setblock 210 256 593 minecraft:ochre_froglight
setblock 210 256 595 minecraft:ochre_froglight
setblock 210 256 597 minecraft:ochre_froglight
setblock 211 256 590 minecraft:ochre_froglight
setblock 211 256 592 minecraft:ochre_froglight
setblock 211 256 594 minecraft:ochre_froglight
setblock 211 256 596 minecraft:ochre_froglight
setblock 211 256 598 minecraft:ochre_froglight
setblock 212 256 591 minecraft:ochre_froglight
setblock 212 256 593 minecraft:ochre_froglight
setblock 212 256 595 minecraft:ochre_froglight
setblock 212 256 597 minecraft:ochre_froglight
setblock 213 256 590 minecraft:ochre_froglight
setblock 213 256 592 minecraft:ochre_froglight
setblock 213 256 594 minecraft:ochre_froglight
setblock 213 256 596 minecraft:ochre_froglight
setblock 213 256 598 minecraft:ochre_froglight
setblock 214 256 591 minecraft:ochre_froglight
setblock 214 256 593 minecraft:ochre_froglight
setblock 214 256 595 minecraft:ochre_froglight
setblock 214 256 597 minecraft:ochre_froglight
setblock 215 256 590 minecraft:ochre_froglight
setblock 215 256 592 minecraft:ochre_froglight
setblock 215 256 594 minecraft:ochre_froglight
setblock 215 256 596 minecraft:ochre_froglight
setblock 215 256 598 minecraft:ochre_froglight
fill 217 256 590 218 257 590 minecraft:gold_block
fill 220 256 559 224 256 566 minecraft:gold_block
fill 225 256 558 225 273 558 minecraft:quartz_block
setblock 199 257 558 minecraft:quartz_block
setblock 199 257 560 minecraft:quartz_block
setblock 200 257 559 minecraft:quartz_block
setblock 200 257 561 minecraft:quartz_block
fill 201 257 558 201 273 558 minecraft:quartz_block
setblock 201 257 560 minecraft:quartz_block
setblock 202 257 559 minecraft:quartz_block
setblock 202 257 561 minecraft:quartz_block
fill 203 257 558 203 273 558 minecraft:quartz_block
setblock 203 257 560 minecraft:quartz_block
fill 203 257 590 203 258 590 minecraft:quartz_block
fill 203 257 592 203 258 592 minecraft:quartz_block
fill 203 257 594 203 258 594 minecraft:quartz_block
fill 203 257 596 203 258 596 minecraft:quartz_block
fill 203 257 598 203 258 598 minecraft:quartz_block
setblock 204 257 559 minecraft:quartz_block
setblock 204 257 561 minecraft:quartz_block
fill 204 257 591 204 258 591 minecraft:quartz_block
fill 204 257 593 204 258 593 minecraft:quartz_block
fill 204 257 595 204 258 595 minecraft:quartz_block
fill 204 257 597 204 258 597 minecraft:quartz_block
setblock 205 257 558 minecraft:quartz_block
setblock 205 257 560 minecraft:quartz_block
fill 205 257 590 205 258 590 minecraft:quartz_block
fill 205 257 592 205 258 592 minecraft:quartz_block
fill 205 257 594 205 258 594 minecraft:quartz_block
fill 205 257 596 205 258 596 minecraft:quartz_block
fill 205 257 598 205 258 598 minecraft:quartz_block
setblock 206 257 559 minecraft:quartz_block
setblock 206 257 561 minecraft:quartz_block
fill 206 257 591 206 258 591 minecraft:quartz_block
fill 206 257 593 206 258 593 minecraft:quartz_block
fill 206 257 595 206 258 595 minecraft:quartz_block
fill 206 257 597 206 258 597 minecraft:quartz_block
setblock 207 257 558 minecraft:quartz_block
setblock 207 257 560 minecraft:quartz_block
fill 207 257 590 207 258 590 minecraft:quartz_block
fill 207 257 592 207 258 592 minecraft:quartz_block
fill 207 257 594 207 258 594 minecraft:quartz_block
fill 207 257 596 207 258 596 minecraft:quartz_block
fill 207 257 598 207 258 598 minecraft:quartz_block
fill 208 257 591 208 258 591 minecraft:quartz_block
fill 208 257 593 208 258 593 minecraft:quartz_block
fill 208 257 595 208 258 595 minecraft:quartz_block
fill 208 257 597 208 258 597 minecraft:quartz_block
fill 209 257 590 209 258 590 minecraft:quartz_block
fill 209 257 592 209 258 592 minecraft:quartz_block
fill 209 257 594 209 258 594 minecraft:quartz_block
fill 209 257 596 209 258 596 minecraft:quartz_block
fill 209 257 598 209 258 598 minecraft:quartz_block
fill 210 257 591 210 258 591 minecraft:quartz_block
fill 210 257 593 210 258 593 minecraft:quartz_block
fill 210 257 595 210 258 595 minecraft:quartz_block
fill 210 257 597 210 258 597 minecraft:quartz_block
fill 211 257 590 211 258 590 minecraft:quartz_block
fill 211 257 592 211 258 592 minecraft:quartz_block
fill 211 257 594 211 258 594 minecraft:quartz_block
fill 211 257 596 211 258 596 minecraft:quartz_block
fill 211 257 598 211 258 598 minecraft:quartz_block
fill 212 257 591 212 258 591 minecraft:quartz_block
fill 212 257 593 212 258 593 minecraft:quartz_block
fill 212 257 595 212 258 595 minecraft:quartz_block
fill 212 257 597 212 258 597 minecraft:quartz_block
fill 213 257 590 213 258 590 minecraft:quartz_block
fill 213 257 592 213 258 592 minecraft:quartz_block
fill 213 257 594 213 258 594 minecraft:quartz_block
fill 213 257 596 213 258 596 minecraft:quartz_block
fill 213 257 598 213 258 598 minecraft:quartz_block
fill 214 257 591 214 258 591 minecraft:quartz_block
fill 214 257 593 214 258 593 minecraft:quartz_block
fill 214 257 595 214 258 595 minecraft:quartz_block
fill 214 257 597 214 258 597 minecraft:quartz_block
fill 215 257 590 215 258 590 minecraft:quartz_block
fill 215 257 592 215 258 592 minecraft:quartz_block
fill 215 257 594 215 258 594 minecraft:quartz_block
fill 215 257 596 215 258 596 minecraft:quartz_block
fill 215 257 598 215 258 598 minecraft:quartz_block
fill 221 257 560 223 257 565 minecraft:gold_block
setblock 191 258 560 minecraft:light[level=14]
setblock 191 258 568 minecraft:light[level=14]
setblock 191 258 576 minecraft:light[level=14]
setblock 191 258 584 minecraft:light[level=14]
setblock 191 258 592 minecraft:light[level=14]
setblock 199 258 560 minecraft:light[level=14]
setblock 199 258 568 minecraft:light[level=14]
setblock 199 258 576 minecraft:light[level=14]
setblock 199 258 584 minecraft:light[level=14]
setblock 199 258 592 minecraft:light[level=14]
fill 200 258 559 206 258 560 minecraft:gold_block
setblock 207 258 560 minecraft:light[level=14]
setblock 207 258 568 minecraft:light[level=14]
setblock 207 258 584 minecraft:light[level=14]
setblock 215 258 560 minecraft:light[level=14]
setblock 215 258 568 minecraft:light[level=14]
setblock 215 258 576 minecraft:light[level=14]
setblock 215 258 584 minecraft:light[level=14]
fill 222 258 561 222 258 564 minecraft:gold_block
setblock 223 258 560 minecraft:light[level=14]
setblock 223 258 568 minecraft:light[level=14]
setblock 223 258 576 minecraft:light[level=14]
setblock 223 258 584 minecraft:light[level=14]
setblock 223 258 592 minecraft:light[level=14]
fill 201 259 559 205 259 560 minecraft:gold_block
setblock 203 259 590 minecraft:ochre_froglight
setblock 203 259 592 minecraft:ochre_froglight
setblock 203 259 594 minecraft:ochre_froglight
setblock 203 259 596 minecraft:ochre_froglight
setblock 203 259 598 minecraft:ochre_froglight
setblock 204 259 591 minecraft:ochre_froglight
setblock 204 259 593 minecraft:ochre_froglight
setblock 204 259 595 minecraft:ochre_froglight
setblock 204 259 597 minecraft:ochre_froglight
setblock 205 259 590 minecraft:ochre_froglight
setblock 205 259 592 minecraft:ochre_froglight
setblock 205 259 594 minecraft:ochre_froglight
setblock 205 259 596 minecraft:ochre_froglight
setblock 205 259 598 minecraft:ochre_froglight
setblock 206 259 591 minecraft:ochre_froglight
setblock 206 259 593 minecraft:ochre_froglight
setblock 206 259 595 minecraft:ochre_froglight
setblock 206 259 597 minecraft:ochre_froglight
setblock 207 259 590 minecraft:ochre_froglight
setblock 207 259 592 minecraft:ochre_froglight
setblock 207 259 594 minecraft:ochre_froglight
setblock 207 259 596 minecraft:ochre_froglight
setblock 207 259 598 minecraft:ochre_froglight
setblock 208 259 591 minecraft:ochre_froglight
setblock 208 259 593 minecraft:ochre_froglight
setblock 208 259 595 minecraft:ochre_froglight
setblock 208 259 597 minecraft:ochre_froglight
setblock 209 259 590 minecraft:ochre_froglight
setblock 209 259 592 minecraft:ochre_froglight
setblock 209 259 594 minecraft:ochre_froglight
setblock 209 259 596 minecraft:ochre_froglight
setblock 209 259 598 minecraft:ochre_froglight
setblock 210 259 591 minecraft:ochre_froglight
setblock 210 259 593 minecraft:ochre_froglight
setblock 210 259 595 minecraft:ochre_froglight
setblock 210 259 597 minecraft:ochre_froglight
setblock 211 259 590 minecraft:ochre_froglight
setblock 211 259 592 minecraft:ochre_froglight
setblock 211 259 594 minecraft:ochre_froglight
setblock 211 259 596 minecraft:ochre_froglight
setblock 211 259 598 minecraft:ochre_froglight
setblock 212 259 591 minecraft:ochre_froglight
setblock 212 259 593 minecraft:ochre_froglight
setblock 212 259 595 minecraft:ochre_froglight
setblock 212 259 597 minecraft:ochre_froglight
setblock 213 259 590 minecraft:ochre_froglight
setblock 213 259 592 minecraft:ochre_froglight
setblock 213 259 594 minecraft:ochre_froglight
setblock 213 259 596 minecraft:ochre_froglight
setblock 213 259 598 minecraft:ochre_froglight
setblock 214 259 591 minecraft:ochre_froglight
setblock 214 259 593 minecraft:ochre_froglight
setblock 214 259 595 minecraft:ochre_froglight
setblock 214 259 597 minecraft:ochre_froglight
setblock 215 259 590 minecraft:ochre_froglight
setblock 215 259 592 minecraft:ochre_froglight
setblock 215 259 594 minecraft:ochre_froglight
setblock 215 259 596 minecraft:ochre_froglight
setblock 215 259 598 minecraft:ochre_froglight
fill 221 259 562 223 259 563 minecraft:gold_block
fill 190 260 567 190 265 569 minecraft:quartz_block
fill 190 260 579 190 265 581 minecraft:quartz_block
fill 190 260 591 190 265 593 minecraft:quartz_block
fill 196 260 597 198 265 597 minecraft:quartz_block
fill 200 260 559 202 265 559 minecraft:quartz_block
fill 202 260 560 204 260 561 minecraft:gold_block
fill 203 260 559 204 260 559 minecraft:gold_block
fill 203 260 590 203 262 590 minecraft:quartz_block
fill 203 260 592 203 262 592 minecraft:quartz_block
fill 203 260 594 203 262 594 minecraft:quartz_block
fill 203 260 596 203 262 596 minecraft:quartz_block
fill 203 260 598 203 262 598 minecraft:quartz_block
setblock 204 260 558 minecraft:gold_block
fill 204 260 591 204 262 591 minecraft:quartz_block
fill 204 260 593 204 262 593 minecraft:quartz_block
fill 204 260 595 204 262 595 minecraft:quartz_block
fill 204 260 597 204 262 597 minecraft:quartz_block
fill 205 260 590 205 262 590 minecraft:quartz_block
fill 205 260 592 205 262 592 minecraft:quartz_block
fill 205 260 594 205 262 594 minecraft:quartz_block
fill 205 260 596 205 262 596 minecraft:quartz_block
fill 205 260 598 205 262 598 minecraft:quartz_block
fill 206 260 591 206 262 591 minecraft:quartz_block
fill 206 260 593 206 262 593 minecraft:quartz_block
fill 206 260 595 206 262 595 minecraft:quartz_block
fill 206 260 597 206 262 597 minecraft:quartz_block
fill 207 260 590 207 262 590 minecraft:quartz_block
fill 207 260 592 207 262 592 minecraft:quartz_block
fill 207 260 594 207 262 594 minecraft:quartz_block
schedule function dropper:buildpart/136_3 1t
