fill 418 194 598 418 199 598 minecraft:purple_terracotta
fill 376 195 563 376 198 563 minecraft:purple_terracotta
setblock 376 195 568 minecraft:purple_concrete
setblock 376 195 579 minecraft:purple_concrete
fill 376 195 583 376 198 584 minecraft:purple_terracotta
setblock 377 195 599 minecraft:purple_concrete
setblock 380 195 599 minecraft:purple_concrete
fill 381 195 599 381 198 599 minecraft:purple_terracotta
fill 385 195 557 386 198 557 minecraft:purple_terracotta
setblock 388 195 599 minecraft:purple_concrete
setblock 390 195 557 minecraft:purple_concrete
fill 392 195 599 392 198 599 minecraft:purple_terracotta
setblock 401 195 557 minecraft:purple_concrete
fill 401 195 592 401 203 592 minecraft:obsidian
fill 402 195 557 402 197 557 minecraft:purple_terracotta
fill 406 195 557 406 198 557 minecraft:purple_terracotta
fill 408 195 599 409 195 599 minecraft:purple_concrete
setblock 409 195 583 minecraft:black_concrete
fill 409 195 584 409 195 586 minecraft:purple_concrete
fill 410 195 581 410 198 581 minecraft:black_concrete
setblock 410 195 585 minecraft:black_concrete
fill 410 195 586 412 196 586 minecraft:purple_concrete
fill 411 195 580 411 197 580 minecraft:black_concrete
setblock 411 195 587 minecraft:purple_concrete
fill 412 195 579 413 196 579 minecraft:black_concrete
setblock 412 195 599 minecraft:purple_concrete
fill 413 195 580 413 196 580 minecraft:black_concrete
fill 413 195 585 413 196 585 minecraft:black_concrete
fill 413 195 599 413 198 599 minecraft:purple_terracotta
fill 414 195 581 414 199 581 minecraft:black_concrete
fill 414 195 584 414 196 584 minecraft:black_concrete
fill 417 195 557 417 198 557 minecraft:purple_terracotta
setblock 418 195 557 minecraft:purple_concrete
fill 418 195 560 418 195 561 minecraft:purple_concrete
fill 418 195 576 418 197 577 minecraft:purple_terracotta
setblock 418 195 581 minecraft:purple_concrete
setblock 418 195 592 minecraft:purple_concrete
fill 418 195 597 418 198 597 minecraft:purple_terracotta
fill 376 196 557 376 197 558 minecraft:purple_concrete
fill 376 196 559 376 201 560 minecraft:purple_terracotta
fill 376 196 568 376 201 568 minecraft:purple_terracotta
fill 376 196 569 376 196 570 minecraft:purple_concrete
fill 376 196 571 376 201 572 minecraft:purple_terracotta
fill 376 196 577 376 197 578 minecraft:purple_concrete
fill 376 196 579 376 201 580 minecraft:purple_terracotta
setblock 376 196 581 minecraft:purple_concrete
fill 376 196 589 376 197 590 minecraft:purple_concrete
fill 376 196 591 376 201 592 minecraft:purple_terracotta
fill 376 196 598 376 197 598 minecraft:purple_concrete
fill 377 196 557 378 201 557 minecraft:purple_terracotta
fill 377 196 599 377 201 599 minecraft:purple_terracotta
fill 378 196 599 379 196 599 minecraft:purple_concrete
fill 379 196 557 380 197 557 minecraft:purple_concrete
setblock 379 196 560 minecraft:light[level=12]
setblock 379 196 568 minecraft:light[level=12]
setblock 379 196 576 minecraft:light[level=12]
setblock 379 196 584 minecraft:light[level=12]
setblock 379 196 592 minecraft:light[level=12]
fill 380 196 599 380 201 599 minecraft:purple_terracotta
fill 386 196 599 387 197 599 minecraft:purple_concrete
setblock 387 196 560 minecraft:light[level=12]
setblock 387 196 568 minecraft:light[level=12]
setblock 387 196 576 minecraft:light[level=12]
setblock 387 196 584 minecraft:light[level=12]
setblock 387 196 592 minecraft:light[level=12]
setblock 388 196 557 minecraft:purple_concrete
fill 388 196 599 389 201 599 minecraft:purple_terracotta
fill 389 196 557 390 201 557 minecraft:purple_terracotta
fill 391 196 557 392 197 557 minecraft:purple_concrete
setblock 395 196 560 minecraft:light[level=12]
setblock 395 196 568 minecraft:light[level=12]
setblock 395 196 576 minecraft:light[level=12]
setblock 395 196 584 minecraft:light[level=12]
setblock 395 196 592 minecraft:light[level=12]
fill 397 196 557 398 201 557 minecraft:purple_terracotta
fill 398 196 599 399 196 599 minecraft:purple_concrete
fill 399 196 557 400 196 557 minecraft:purple_concrete
fill 400 196 591 401 203 591 minecraft:obsidian
fill 400 196 593 400 203 593 minecraft:obsidian
fill 400 196 599 401 201 599 minecraft:purple_terracotta
fill 401 196 557 401 201 557 minecraft:purple_terracotta
setblock 403 196 560 minecraft:light[level=12]
setblock 403 196 568 minecraft:light[level=12]
setblock 403 196 576 minecraft:light[level=12]
setblock 403 196 584 minecraft:light[level=12]
setblock 403 196 592 minecraft:light[level=12]
fill 407 196 599 407 197 599 minecraft:purple_concrete
fill 408 196 599 409 201 599 minecraft:purple_terracotta
fill 409 196 557 410 201 557 minecraft:purple_terracotta
fill 409 196 583 409 196 584 minecraft:purple_concrete
fill 410 196 580 410 199 580 minecraft:black_concrete
setblock 410 196 585 minecraft:purple_concrete
setblock 410 196 599 minecraft:purple_concrete
fill 411 196 557 412 197 557 minecraft:purple_concrete
setblock 411 196 560 minecraft:light[level=12]
setblock 411 196 568 minecraft:light[level=12]
setblock 411 196 576 minecraft:light[level=12]
fill 411 196 578 411 196 579 minecraft:black_concrete
setblock 411 196 592 minecraft:light[level=12]
fill 412 196 578 413 196 578 minecraft:black_concrete
fill 412 196 599 412 201 599 minecraft:purple_terracotta
fill 414 196 579 414 196 580 minecraft:black_concrete
fill 418 196 557 418 201 557 minecraft:purple_terracotta
fill 418 196 558 418 196 559 minecraft:purple_concrete
fill 418 196 560 418 197 561 minecraft:purple_terracotta
fill 418 196 562 418 197 562 minecraft:purple_concrete
fill 418 196 568 418 201 569 minecraft:purple_terracotta
fill 418 196 570 418 197 571 minecraft:purple_concrete
setblock 418 196 579 minecraft:purple_concrete
fill 418 196 580 418 201 581 minecraft:purple_terracotta
fill 418 196 582 418 197 583 minecraft:purple_concrete
fill 418 196 588 418 201 589 minecraft:purple_terracotta
fill 418 196 590 418 196 591 minecraft:purple_concrete
fill 418 196 592 418 201 592 minecraft:purple_terracotta
fill 418 196 599 418 197 599 minecraft:purple_concrete
fill 376 197 565 376 197 566 minecraft:purple_concrete
setblock 376 197 569 minecraft:purple_concrete
fill 376 197 570 376 200 570 minecraft:purple_terracotta
fill 376 197 581 376 200 581 minecraft:purple_terracotta
setblock 376 197 586 minecraft:purple_concrete
setblock 376 197 597 minecraft:purple_concrete
fill 378 197 599 379 200 599 minecraft:purple_terracotta
setblock 383 197 557 minecraft:purple_concrete
fill 388 197 557 388 200 557 minecraft:purple_terracotta
fill 391 197 570 395 197 571 minecraft:dark_oak_planks
fill 391 197 581 395 197 582 minecraft:dark_oak_planks
fill 392 197 569 395 197 569 minecraft:dark_oak_planks
fill 392 197 572 395 197 572 minecraft:dark_oak_planks
fill 392 197 580 395 197 580 minecraft:dark_oak_planks
fill 392 197 583 395 197 583 minecraft:dark_oak_planks
fill 393 197 568 394 197 568 minecraft:dark_oak_planks
fill 393 197 584 394 197 584 minecraft:dark_oak_planks
setblock 395 197 599 minecraft:purple_concrete
setblock 398 197 599 minecraft:purple_concrete
fill 399 197 557 399 200 557 minecraft:purple_terracotta
fill 399 197 591 399 203 592 minecraft:obsidian
fill 399 197 599 399 200 599 minecraft:purple_terracotta
setblock 400 197 557 minecraft:purple_concrete
fill 401 197 593 401 203 593 minecraft:obsidian
fill 402 197 592 402 203 592 minecraft:obsidian
fill 403 197 557 404 197 557 minecraft:purple_concrete
fill 403 197 569 406 197 572 minecraft:dark_oak_planks
fill 403 197 580 406 197 583 minecraft:dark_oak_planks
fill 404 197 568 405 197 568 minecraft:dark_oak_planks
fill 404 197 584 405 197 584 minecraft:dark_oak_planks
setblock 406 197 599 minecraft:purple_concrete
fill 407 197 570 407 197 571 minecraft:dark_oak_planks
fill 407 197 581 407 197 582 minecraft:dark_oak_planks
setblock 410 197 579 minecraft:black_concrete
fill 410 197 599 410 200 599 minecraft:purple_terracotta
fill 411 197 577 414 201 579 minecraft:purple_concrete
setblock 411 197 585 minecraft:purple_concrete
fill 412 197 580 413 201 580 minecraft:purple_concrete
setblock 412 197 585 minecraft:black_concrete
setblock 414 197 580 minecraft:black_concrete
fill 418 197 558 418 199 559 minecraft:purple_terracotta
setblock 418 197 563 minecraft:purple_concrete
setblock 418 197 574 minecraft:purple_concrete
fill 418 197 579 418 199 579 minecraft:purple_terracotta
fill 418 197 590 418 200 590 minecraft:purple_terracotta
setblock 418 197 591 minecraft:purple_concrete
fill 418 197 594 418 197 595 minecraft:purple_concrete
fill 376 198 557 376 203 558 minecraft:purple_terracotta
fill 376 198 564 376 199 564 minecraft:purple_concrete
fill 376 198 565 376 203 566 minecraft:purple_terracotta
setblock 376 198 567 minecraft:purple_concrete
fill 376 198 569 376 203 569 minecraft:purple_terracotta
fill 376 198 575 376 199 576 minecraft:purple_concrete
fill 376 198 577 376 203 578 minecraft:purple_terracotta
fill 376 198 586 376 203 586 minecraft:purple_terracotta
fill 376 198 587 376 198 588 minecraft:purple_concrete
fill 376 198 589 376 203 590 minecraft:purple_terracotta
fill 376 198 595 376 199 596 minecraft:purple_concrete
fill 376 198 597 376 203 598 minecraft:purple_terracotta
setblock 376 198 599 minecraft:purple_concrete
fill 377 198 558 379 198 558 minecraft:obsidian
fill 377 198 560 377 198 562 minecraft:obsidian
fill 377 198 564 377 198 566 minecraft:obsidian
fill 377 198 568 377 198 570 minecraft:obsidian
fill 377 198 572 377 198 574 minecraft:obsidian
fill 377 198 576 377 198 578 minecraft:obsidian
fill 377 198 580 377 198 582 minecraft:obsidian
fill 377 198 584 377 198 586 minecraft:obsidian
fill 377 198 588 377 198 590 minecraft:obsidian
fill 377 198 592 377 198 594 minecraft:obsidian
fill 377 198 596 377 198 598 minecraft:obsidian
fill 379 198 557 380 203 557 minecraft:purple_terracotta
fill 379 198 598 381 198 598 minecraft:obsidian
fill 381 198 557 382 198 557 minecraft:purple_concrete
fill 381 198 558 383 198 558 minecraft:obsidian
fill 383 198 557 383 203 557 minecraft:purple_terracotta
fill 383 198 598 385 198 598 minecraft:obsidian
fill 384 198 599 385 199 599 minecraft:purple_concrete
fill 385 198 558 387 198 558 minecraft:obsidian
fill 386 198 599 387 203 599 minecraft:purple_terracotta
fill 387 198 598 389 198 598 minecraft:obsidian
fill 389 198 558 391 198 558 minecraft:obsidian
fill 391 198 557 392 203 557 minecraft:purple_terracotta
fill 391 198 598 393 198 598 minecraft:obsidian
fill 392 198 569 394 198 571 minecraft:dark_oak_planks
fill 392 198 581 394 198 583 minecraft:dark_oak_planks
fill 393 198 557 394 199 557 minecraft:purple_concrete
fill 393 198 558 395 198 558 minecraft:obsidian
fill 393 198 572 394 198 572 minecraft:dark_oak_planks
fill 393 198 580 394 198 580 minecraft:dark_oak_planks
fill 393 198 599 393 199 599 minecraft:purple_concrete
fill 395 198 570 395 198 571 minecraft:dark_oak_planks
fill 395 198 581 395 198 582 minecraft:dark_oak_planks
fill 395 198 598 397 198 598 minecraft:obsidian
fill 395 198 599 395 203 599 minecraft:purple_terracotta
fill 396 198 599 397 198 599 minecraft:purple_concrete
fill 397 198 558 399 198 558 minecraft:obsidian
fill 398 198 599 398 203 599 minecraft:purple_terracotta
fill 399 198 593 399 203 593 minecraft:obsidian
fill 399 198 598 401 198 598 minecraft:obsidian
fill 400 198 557 400 203 557 minecraft:purple_terracotta
fill 400 198 590 401 203 590 minecraft:obsidian
fill 400 198 594 400 203 594 minecraft:obsidian
fill 401 198 558 403 198 558 minecraft:obsidian
setblock 402 198 557 minecraft:purple_concrete
fill 402 198 591 402 203 591 minecraft:obsidian
fill 402 198 593 402 203 593 minecraft:obsidian
fill 403 198 557 404 203 557 minecraft:purple_terracotta
fill 403 198 570 406 198 571 minecraft:dark_oak_planks
fill 403 198 581 406 198 582 minecraft:dark_oak_planks
fill 403 198 598 405 198 598 minecraft:obsidian
fill 404 198 569 406 198 569 minecraft:dark_oak_planks
fill 404 198 572 405 198 572 minecraft:dark_oak_planks
fill 404 198 580 405 198 580 minecraft:dark_oak_planks
fill 404 198 583 406 198 583 minecraft:dark_oak_planks
fill 404 198 599 405 199 599 minecraft:purple_concrete
fill 405 198 557 405 199 557 minecraft:purple_concrete
fill 405 198 558 407 198 558 minecraft:obsidian
fill 406 198 599 407 203 599 minecraft:purple_terracotta
fill 407 198 598 409 198 598 minecraft:obsidian
fill 409 198 558 411 198 558 minecraft:obsidian
fill 410 198 578 410 199 579 minecraft:purple_concrete
fill 410 198 582 412 198 582 minecraft:black_concrete
fill 411 198 557 412 203 557 minecraft:purple_terracotta
fill 411 198 576 414 203 576 minecraft:purple_concrete
fill 411 198 580 411 200 580 minecraft:purple_concrete
fill 411 198 583 412 198 583 minecraft:black_concrete
fill 411 198 598 413 198 598 minecraft:obsidian
fill 412 198 575 412 205 575 minecraft:purple_concrete
fill 413 198 557 414 199 557 minecraft:purple_concrete
fill 413 198 558 415 198 558 minecraft:obsidian
fill 414 198 580 414 200 580 minecraft:purple_concrete
setblock 414 198 582 minecraft:black_concrete
fill 415 198 578 415 199 579 minecraft:purple_concrete
setblock 415 198 580 minecraft:black_concrete
fill 415 198 598 417 198 598 minecraft:obsidian
fill 416 198 599 417 198 599 minecraft:purple_concrete
fill 417 198 558 417 198 560 minecraft:obsidian
fill 417 198 562 417 198 564 minecraft:obsidian
fill 417 198 566 417 198 568 minecraft:obsidian
fill 417 198 570 417 198 572 minecraft:obsidian
fill 417 198 574 417 198 576 minecraft:obsidian
fill 417 198 578 417 198 580 minecraft:obsidian
fill 417 198 582 417 198 584 minecraft:obsidian
fill 417 198 586 417 198 588 minecraft:obsidian
fill 417 198 590 417 198 592 minecraft:obsidian
fill 417 198 594 417 198 596 minecraft:obsidian
fill 418 198 560 418 201 560 minecraft:purple_terracotta
setblock 418 198 561 minecraft:purple_concrete
fill 418 198 562 418 203 563 minecraft:purple_terracotta
fill 418 198 564 418 199 565 minecraft:purple_concrete
fill 418 198 570 418 200 571 minecraft:purple_terracotta
fill 418 198 572 418 198 573 minecraft:purple_concrete
fill 418 198 574 418 203 574 minecraft:purple_terracotta
fill 418 198 576 418 199 576 minecraft:purple_concrete
setblock 418 198 577 minecraft:purple_terracotta
fill 418 198 582 418 203 583 minecraft:purple_terracotta
fill 418 198 584 418 199 585 minecraft:purple_concrete
fill 418 198 591 418 203 591 minecraft:purple_terracotta
setblock 418 198 593 minecraft:purple_concrete
fill 418 198 594 418 203 595 minecraft:purple_terracotta
fill 418 198 596 418 199 596 minecraft:purple_concrete
fill 418 198 599 418 203 599 minecraft:purple_terracotta
setblock 376 199 563 minecraft:purple_concrete
fill 376 199 567 376 202 567 minecraft:purple_terracotta
fill 376 199 583 376 199 584 minecraft:purple_concrete
setblock 376 199 587 minecraft:purple_concrete
fill 376 199 588 376 202 588 minecraft:purple_terracotta
fill 376 199 599 376 202 599 minecraft:purple_terracotta
fill 381 199 557 381 202 557 minecraft:purple_terracotta
setblock 381 199 599 minecraft:purple_concrete
setblock 382 199 557 minecraft:purple_concrete
fill 385 199 557 386 199 557 minecraft:purple_concrete
fill 392 199 570 394 199 571 minecraft:dark_oak_planks
fill 392 199 581 394 199 582 minecraft:dark_oak_planks
setblock 392 199 599 minecraft:purple_concrete
fill 393 199 569 394 199 569 minecraft:dark_oak_planks
fill 393 199 583 394 199 583 minecraft:dark_oak_planks
fill 396 199 599 397 202 599 minecraft:purple_terracotta
fill 398 199 591 398 203 593 minecraft:obsidian
fill 399 199 590 399 203 590 minecraft:obsidian
fill 399 199 594 399 203 594 minecraft:obsidian
fill 401 199 594 401 203 594 minecraft:obsidian
fill 402 199 557 402 202 557 minecraft:purple_terracotta
fill 402 199 590 402 203 590 minecraft:obsidian
fill 403 199 592 403 203 592 minecraft:obsidian
fill 404 199 569 405 199 571 minecraft:dark_oak_planks
fill 404 199 581 405 199 583 minecraft:dark_oak_planks
setblock 406 199 557 minecraft:purple_concrete
fill 406 199 570 406 199 571 minecraft:dark_oak_planks
fill 406 199 581 406 199 582 minecraft:dark_oak_planks
fill 410 199 576 410 202 577 minecraft:purple_concrete
fill 411 199 574 411 204 575 minecraft:purple_concrete
fill 411 199 581 411 199 582 minecraft:black_concrete
fill 412 199 574 413 205 574 minecraft:purple_concrete
fill 412 199 581 413 199 581 minecraft:purple_concrete
fill 412 199 582 413 199 582 minecraft:black_concrete
fill 413 199 575 414 203 575 minecraft:purple_concrete
setblock 413 199 599 minecraft:purple_concrete
fill 415 199 577 415 200 577 minecraft:purple_concrete
setblock 416 199 599 minecraft:purple_concrete
setblock 417 199 557 minecraft:purple_concrete
fill 417 199 599 417 202 599 minecraft:purple_terracotta
fill 418 199 561 418 201 561 minecraft:purple_terracotta
fill 418 199 572 418 202 572 minecraft:purple_terracotta
setblock 418 199 573 minecraft:purple_concrete
setblock 418 199 577 minecraft:purple_concrete
fill 418 199 593 418 202 593 minecraft:purple_terracotta
setblock 418 199 597 minecraft:purple_concrete
fill 376 200 561 376 201 562 minecraft:purple_concrete
fill 376 200 563 376 205 564 minecraft:purple_terracotta
fill 376 200 573 376 200 574 minecraft:purple_concrete
fill 376 200 575 376 205 576 minecraft:purple_terracotta
fill 376 200 582 376 201 582 minecraft:purple_concrete
fill 376 200 583 376 205 584 minecraft:purple_terracotta
setblock 376 200 585 minecraft:purple_concrete
fill 376 200 587 376 205 587 minecraft:purple_terracotta
fill 376 200 593 376 201 594 minecraft:purple_concrete
fill 376 200 595 376 205 596 minecraft:purple_terracotta
fill 381 200 599 381 205 599 minecraft:purple_terracotta
fill 382 200 557 382 205 557 minecraft:purple_terracotta
fill 382 200 599 383 200 599 minecraft:purple_concrete
setblock 384 200 557 minecraft:purple_concrete
fill 384 200 599 385 205 599 minecraft:purple_terracotta
fill 385 200 557 386 205 557 minecraft:purple_terracotta
fill 387 200 557 387 201 557 minecraft:purple_concrete
fill 390 200 599 391 201 599 minecraft:purple_concrete
fill 392 200 599 393 205 599 minecraft:purple_terracotta
fill 393 200 557 394 205 557 minecraft:purple_terracotta
fill 393 200 570 394 200 571 minecraft:dark_oak_planks
fill 393 200 581 394 200 582 minecraft:dark_oak_planks
setblock 394 200 599 minecraft:purple_concrete
fill 395 200 557 396 200 557 minecraft:purple_concrete
fill 398 200 590 398 203 590 minecraft:obsidian
fill 400 200 589 401 203 589 minecraft:obsidian
fill 400 200 595 400 203 595 minecraft:obsidian
fill 402 200 594 402 203 594 minecraft:obsidian
fill 402 200 599 403 201 599 minecraft:purple_concrete
fill 403 200 591 403 203 591 minecraft:obsidian
fill 403 200 593 403 203 593 minecraft:obsidian
fill 404 200 570 405 200 571 minecraft:dark_oak_planks
fill 404 200 581 405 200 582 minecraft:dark_oak_planks
fill 404 200 599 405 205 599 minecraft:purple_terracotta
fill 405 200 557 406 205 557 minecraft:purple_terracotta
fill 407 200 557 408 201 557 minecraft:purple_concrete
fill 410 200 574 410 204 575 minecraft:purple_concrete
fill 410 200 578 410 201 578 minecraft:purple_concrete
fill 411 200 573 413 205 573 minecraft:purple_concrete
fill 411 200 599 411 201 599 minecraft:purple_concrete
fill 412 200 581 413 200 581 minecraft:black_concrete
fill 413 200 557 414 202 557 minecraft:purple_terracotta
fill 413 200 599 413 205 599 minecraft:purple_terracotta
fill 414 200 574 414 204 574 minecraft:purple_concrete
fill 414 200 599 415 200 599 minecraft:purple_concrete
fill 415 200 557 416 200 557 minecraft:purple_concrete
setblock 415 200 576 minecraft:purple_concrete
setblock 415 200 578 minecraft:purple_concrete
fill 416 200 599 416 205 599 minecraft:purple_terracotta
fill 417 200 557 417 205 557 minecraft:purple_terracotta
fill 418 200 558 418 201 558 minecraft:purple_concrete
setblock 418 200 559 minecraft:purple_terracotta
fill 418 200 564 418 205 565 minecraft:purple_terracotta
fill 418 200 566 418 201 567 minecraft:purple_concrete
fill 418 200 573 418 202 573 minecraft:purple_terracotta
setblock 418 200 575 minecraft:purple_concrete
fill 418 200 576 418 205 577 minecraft:purple_terracotta
fill 418 200 578 418 201 579 minecraft:purple_concrete
fill 418 200 584 418 205 585 minecraft:purple_terracotta
fill 418 200 586 418 200 587 minecraft:purple_concrete
fill 418 200 596 418 205 597 minecraft:purple_terracotta
fill 418 200 598 418 201 598 minecraft:purple_concrete
setblock 376 201 570 minecraft:purple_concrete
setblock 376 201 573 minecraft:purple_concrete
fill 376 201 574 376 204 574 minecraft:purple_terracotta
setblock 376 201 581 minecraft:purple_concrete
fill 376 201 585 376 204 585 minecraft:purple_terracotta
fill 378 201 599 379 201 599 minecraft:purple_concrete
setblock 382 201 599 minecraft:purple_concrete
fill 383 201 599 383 204 599 minecraft:purple_terracotta
fill 384 201 557 384 204 557 minecraft:purple_terracotta
setblock 388 201 557 minecraft:purple_concrete
setblock 393 201 570 minecraft:dark_oak_planks
setblock 393 201 582 minecraft:dark_oak_planks
fill 394 201 599 394 204 599 minecraft:purple_terracotta
fill 395 201 557 395 204 557 minecraft:purple_terracotta
setblock 396 201 557 minecraft:purple_concrete
fill 397 201 591 397 203 593 minecraft:obsidian
fill 398 201 594 398 203 594 minecraft:obsidian
setblock 399 201 557 minecraft:purple_concrete
fill 399 201 589 399 203 589 minecraft:obsidian
fill 399 201 595 399 203 595 minecraft:obsidian
setblock 399 201 599 minecraft:purple_concrete
fill 401 201 595 402 203 595 minecraft:obsidian
fill 402 201 589 402 203 589 minecraft:obsidian
fill 403 201 590 403 203 590 minecraft:obsidian
fill 403 201 594 403 203 594 minecraft:obsidian
setblock 405 201 570 minecraft:dark_oak_planks
setblock 405 201 582 minecraft:dark_oak_planks
fill 410 201 572 410 204 573 minecraft:purple_concrete
setblock 410 201 599 minecraft:purple_concrete
fill 411 201 572 413 205 572 minecraft:purple_concrete
fill 414 201 573 414 204 573 minecraft:purple_concrete
fill 414 201 599 415 204 599 minecraft:purple_terracotta
fill 415 201 557 415 204 557 minecraft:purple_terracotta
setblock 416 201 557 minecraft:purple_concrete
setblock 418 201 559 minecraft:purple_concrete
setblock 418 201 570 minecraft:purple_concrete
fill 418 201 571 418 203 571 minecraft:purple_terracotta
fill 418 201 575 418 204 575 minecraft:purple_terracotta
fill 418 201 586 418 204 586 minecraft:purple_terracotta
setblock 418 201 587 minecraft:purple_concrete
setblock 418 201 590 minecraft:purple_concrete
fill 376 202 559 376 203 560 minecraft:purple_concrete
fill 376 202 561 376 207 562 minecraft:purple_terracotta
fill 376 202 568 376 203 568 minecraft:purple_concrete
fill 376 202 570 376 207 570 minecraft:purple_terracotta
fill 376 202 571 376 202 572 minecraft:purple_concrete
fill 376 202 573 376 207 573 minecraft:purple_terracotta
fill 376 202 579 376 203 580 minecraft:purple_concrete
fill 376 202 581 376 207 582 minecraft:purple_terracotta
fill 376 202 591 376 202 592 minecraft:purple_concrete
fill 376 202 593 376 207 594 minecraft:purple_terracotta
fill 377 202 557 378 202 557 minecraft:purple_concrete
fill 377 202 599 377 203 599 minecraft:purple_concrete
fill 378 202 599 379 207 599 minecraft:purple_terracotta
setblock 380 202 599 minecraft:purple_concrete
fill 382 202 599 382 207 599 minecraft:purple_terracotta
fill 387 202 557 388 207 557 minecraft:purple_terracotta
fill 388 202 599 389 203 599 minecraft:purple_concrete
fill 389 202 557 390 203 557 minecraft:purple_concrete
fill 390 202 599 391 207 599 minecraft:purple_terracotta
fill 396 202 557 396 207 557 minecraft:purple_terracotta
fill 397 202 557 398 202 557 minecraft:purple_concrete
fill 397 202 590 397 203 590 minecraft:obsidian
fill 397 202 594 397 203 594 minecraft:obsidian
fill 398 202 589 398 203 589 minecraft:obsidian
fill 398 202 595 398 203 595 minecraft:obsidian
fill 399 202 557 399 207 557 minecraft:purple_terracotta
fill 399 202 599 399 207 599 minecraft:purple_terracotta
fill 400 202 588 401 203 588 minecraft:obsidian
fill 400 202 599 401 202 599 minecraft:purple_concrete
fill 401 202 557 401 203 557 minecraft:purple_concrete
fill 402 202 599 403 207 599 minecraft:purple_terracotta
fill 403 202 589 403 203 589 minecraft:obsidian
fill 403 202 595 403 203 595 minecraft:obsidian
fill 404 202 591 404 203 593 minecraft:obsidian
fill 407 202 557 408 207 557 minecraft:purple_terracotta
fill 408 202 599 409 203 599 minecraft:purple_concrete
fill 409 202 557 410 203 557 minecraft:purple_concrete
fill 409 202 573 409 205 573 minecraft:purple_concrete
fill 410 202 571 413 203 571 minecraft:purple_concrete
fill 410 202 599 411 207 599 minecraft:purple_terracotta
fill 411 202 570 411 203 570 minecraft:purple_concrete
fill 411 202 577 413 202 578 minecraft:purple_concrete
fill 412 202 579 413 205 579 minecraft:amethyst_block
setblock 412 202 599 minecraft:purple_concrete
fill 414 202 572 414 204 572 minecraft:purple_concrete
setblock 414 202 577 minecraft:purple_concrete
fill 416 202 557 416 204 557 minecraft:purple_terracotta
setblock 418 202 557 minecraft:purple_concrete
fill 418 202 558 418 207 559 minecraft:purple_terracotta
fill 418 202 560 418 203 561 minecraft:purple_concrete
fill 418 202 566 418 207 567 minecraft:purple_terracotta
fill 418 202 568 418 202 569 minecraft:purple_concrete
fill 418 202 570 418 203 570 minecraft:purple_terracotta
fill 418 202 578 418 207 579 minecraft:purple_terracotta
fill 418 202 580 418 203 581 minecraft:purple_concrete
fill 418 202 587 418 207 587 minecraft:purple_terracotta
fill 418 202 588 418 202 589 minecraft:purple_concrete
fill 418 202 590 418 207 590 minecraft:purple_terracotta
fill 418 202 592 418 203 592 minecraft:purple_concrete
fill 418 202 598 418 207 598 minecraft:purple_terracotta
setblock 376 203 567 minecraft:purple_concrete
fill 376 203 571 376 206 572 minecraft:purple_terracotta
setblock 376 203 588 minecraft:purple_concrete
setblock 376 203 591 minecraft:purple_concrete
fill 376 203 592 376 206 592 minecraft:purple_terracotta
setblock 376 203 599 minecraft:purple_concrete
fill 377 203 557 377 206 557 minecraft:purple_terracotta
setblock 378 203 557 minecraft:purple_concrete
fill 380 203 599 380 206 599 minecraft:purple_terracotta
setblock 381 203 557 minecraft:purple_concrete
fill 396 203 591 396 203 593 minecraft:obsidian
fill 396 203 599 397 203 599 minecraft:purple_concrete
fill 397 203 557 398 206 557 minecraft:purple_terracotta
setblock 397 203 589 minecraft:obsidian
setblock 397 203 595 minecraft:obsidian
fill 398 203 588 399 203 588 minecraft:obsidian
fill 399 203 596 402 203 596 minecraft:obsidian
setblock 400 203 599 minecraft:purple_concrete
fill 401 203 599 401 206 599 minecraft:purple_terracotta
setblock 402 203 557 minecraft:purple_concrete
setblock 402 203 588 minecraft:obsidian
setblock 404 203 590 minecraft:obsidian
setblock 404 203 594 minecraft:obsidian
fill 409 203 570 409 203 572 minecraft:purple_concrete
setblock 409 203 574 minecraft:purple_concrete
fill 410 203 569 410 203 570 minecraft:purple_concrete
setblock 410 203 576 minecraft:purple_concrete
setblock 411 203 569 minecraft:purple_concrete
fill 411 203 577 413 203 577 minecraft:purple_concrete
fill 412 203 570 412 204 570 minecraft:purple_concrete
fill 412 203 578 413 205 578 minecraft:amethyst_block
fill 412 203 599 412 206 599 minecraft:purple_terracotta
setblock 413 203 557 minecraft:purple_concrete
fill 414 203 557 414 205 557 minecraft:purple_terracotta
setblock 417 203 599 minecraft:purple_concrete
fill 418 203 557 418 206 557 minecraft:purple_terracotta
fill 418 203 568 418 206 568 minecraft:purple_terracotta
setblock 418 203 569 minecraft:purple_concrete
fill 418 203 572 418 203 573 minecraft:purple_concrete
fill 418 203 588 418 205 589 minecraft:purple_terracotta
setblock 418 203 593 minecraft:purple_concrete
fill 376 204 557 376 204 558 minecraft:purple_concrete
fill 376 204 559 376 209 560 minecraft:purple_terracotta
fill 376 204 565 376 205 566 minecraft:purple_concrete
fill 376 204 567 376 209 568 minecraft:purple_terracotta
setblock 376 204 569 minecraft:purple_concrete
fill 376 204 577 376 205 578 minecraft:purple_concrete
fill 376 204 579 376 209 580 minecraft:purple_terracotta
fill 376 204 586 376 205 586 minecraft:purple_concrete
fill 376 204 588 376 209 588 minecraft:purple_terracotta
fill 376 204 589 376 204 590 minecraft:purple_concrete
fill 376 204 591 376 209 591 minecraft:purple_terracotta
fill 376 204 597 376 205 598 minecraft:purple_concrete
fill 376 204 599 377 209 599 minecraft:purple_terracotta
fill 377 204 558 379 204 558 minecraft:obsidian
fill 377 204 560 377 204 562 minecraft:obsidian
fill 377 204 564 377 204 566 minecraft:obsidian
fill 377 204 568 377 204 570 minecraft:obsidian
fill 377 204 572 377 204 574 minecraft:obsidian
fill 377 204 576 377 204 578 minecraft:obsidian
fill 377 204 580 377 204 582 minecraft:obsidian
fill 377 204 584 377 204 586 minecraft:obsidian
fill 377 204 588 377 204 590 minecraft:obsidian
fill 377 204 592 377 204 594 minecraft:obsidian
fill 377 204 596 377 204 598 minecraft:obsidian
fill 378 204 557 378 209 557 minecraft:purple_terracotta
fill 379 204 557 380 204 557 minecraft:purple_concrete
setblock 379 204 560 minecraft:light[level=12]
setblock 379 204 568 minecraft:light[level=12]
setblock 379 204 576 minecraft:light[level=12]
setblock 379 204 584 minecraft:light[level=12]
setblock 379 204 592 minecraft:light[level=12]
fill 379 204 598 381 204 598 minecraft:obsidian
fill 381 204 557 381 209 557 minecraft:purple_terracotta
fill 381 204 558 383 204 558 minecraft:obsidian
fill 383 204 557 383 205 557 minecraft:purple_concrete
fill 383 204 598 385 204 598 minecraft:obsidian
fill 385 204 558 387 204 558 minecraft:obsidian
fill 386 204 599 387 204 599 minecraft:purple_concrete
setblock 387 204 560 minecraft:light[level=12]
setblock 387 204 568 minecraft:light[level=12]
setblock 387 204 576 minecraft:light[level=12]
setblock 387 204 584 minecraft:light[level=12]
setblock 387 204 592 minecraft:light[level=12]
fill 387 204 598 389 204 598 minecraft:obsidian
fill 388 204 599 389 209 599 minecraft:purple_terracotta
fill 389 204 557 390 209 557 minecraft:purple_terracotta
fill 389 204 558 391 204 558 minecraft:obsidian
fill 391 204 557 392 205 557 minecraft:purple_concrete
fill 391 204 598 393 204 598 minecraft:obsidian
fill 393 204 558 395 204 558 minecraft:obsidian
setblock 395 204 560 minecraft:light[level=12]
setblock 395 204 568 minecraft:light[level=12]
setblock 395 204 576 minecraft:light[level=12]
setblock 395 204 584 minecraft:light[level=12]
setblock 395 204 592 minecraft:light[level=12]
fill 395 204 598 397 204 598 minecraft:obsidian
fill 395 204 599 395 205 599 minecraft:purple_concrete
fill 396 204 599 397 209 599 minecraft:purple_terracotta
fill 397 204 558 399 204 558 minecraft:obsidian
setblock 398 204 599 minecraft:purple_concrete
fill 399 204 598 401 204 598 minecraft:obsidian
setblock 400 204 557 minecraft:purple_concrete
fill 400 204 591 401 204 593 minecraft:amethyst_block
fill 400 204 599 400 209 599 minecraft:purple_terracotta
fill 401 204 557 402 209 557 minecraft:purple_terracotta
fill 401 204 558 403 204 558 minecraft:obsidian
fill 403 204 557 404 205 557 minecraft:purple_concrete
setblock 403 204 560 minecraft:light[level=12]
setblock 403 204 568 minecraft:light[level=12]
setblock 403 204 576 minecraft:light[level=12]
setblock 403 204 584 minecraft:light[level=12]
setblock 403 204 592 minecraft:light[level=12]
fill 403 204 598 405 204 598 minecraft:obsidian
fill 405 204 558 407 204 558 minecraft:obsidian
fill 406 204 599 407 205 599 minecraft:purple_concrete
fill 407 204 598 409 204 598 minecraft:obsidian
fill 408 204 570 408 204 571 minecraft:purple_concrete
fill 408 204 599 409 209 599 minecraft:purple_terracotta
fill 409 204 557 410 209 557 minecraft:purple_terracotta
fill 409 204 558 411 204 558 minecraft:obsidian
fill 409 204 568 410 208 571 minecraft:black_concrete
fill 409 204 572 409 205 572 minecraft:purple_concrete
fill 411 204 557 412 204 557 minecraft:purple_concrete
setblock 411 204 560 minecraft:light[level=12]
fill 411 204 568 411 208 570 minecraft:black_concrete
fill 411 204 571 413 204 571 minecraft:purple_concrete
fill 411 204 576 412 204 576 minecraft:purple_concrete
setblock 411 204 584 minecraft:light[level=12]
setblock 411 204 592 minecraft:light[level=12]
fill 411 204 598 413 204 598 minecraft:obsidian
setblock 412 204 569 minecraft:purple_concrete
fill 413 204 557 413 209 557 minecraft:purple_terracotta
fill 413 204 558 415 204 558 minecraft:obsidian
fill 413 204 570 413 206 570 minecraft:purple_concrete
setblock 413 204 575 minecraft:purple_concrete
fill 415 204 598 417 204 598 minecraft:obsidian
fill 417 204 558 417 204 560 minecraft:obsidian
fill 417 204 562 417 204 564 minecraft:obsidian
fill 417 204 566 417 204 568 minecraft:obsidian
fill 417 204 570 417 204 572 minecraft:obsidian
fill 417 204 574 417 204 576 minecraft:obsidian
fill 417 204 578 417 204 580 minecraft:obsidian
fill 417 204 582 417 204 584 minecraft:obsidian
fill 417 204 586 417 204 588 minecraft:obsidian
fill 417 204 590 417 204 592 minecraft:obsidian
fill 417 204 594 417 204 596 minecraft:obsidian
fill 417 204 599 417 209 599 minecraft:purple_terracotta
fill 418 204 560 418 209 561 minecraft:purple_terracotta
fill 418 204 562 418 205 563 minecraft:purple_concrete
fill 418 204 569 418 209 569 minecraft:purple_terracotta
fill 418 204 570 418 204 571 minecraft:purple_concrete
fill 418 204 572 418 205 573 minecraft:purple_terracotta
fill 418 204 574 418 205 574 minecraft:purple_concrete
fill 418 204 580 418 209 581 minecraft:purple_terracotta
fill 418 204 582 418 205 583 minecraft:purple_concrete
setblock 418 204 591 minecraft:purple_concrete
fill 418 204 592 418 209 593 minecraft:purple_terracotta
fill 418 204 594 418 205 595 minecraft:purple_concrete
fill 418 204 599 418 205 599 minecraft:purple_concrete
setblock 376 205 557 minecraft:purple_concrete
fill 376 205 558 376 208 558 minecraft:purple_terracotta
fill 376 205 569 376 208 569 minecraft:purple_terracotta
setblock 376 205 574 minecraft:purple_concrete
setblock 376 205 585 minecraft:purple_concrete
fill 376 205 589 376 208 590 minecraft:purple_terracotta
fill 379 205 557 380 208 557 minecraft:purple_terracotta
setblock 383 205 599 minecraft:purple_concrete
setblock 384 205 557 minecraft:purple_concrete
setblock 386 205 599 minecraft:purple_concrete
fill 387 205 599 387 208 599 minecraft:purple_terracotta
setblock 394 205 599 minecraft:purple_concrete
setblock 395 205 557 minecraft:purple_concrete
fill 398 205 599 398 208 599 minecraft:purple_terracotta
fill 400 205 557 400 208 557 minecraft:purple_terracotta
fill 400 205 591 400 205 592 minecraft:amethyst_block
fill 401 205 592 401 206 592 minecraft:amethyst_block
fill 408 205 567 408 207 571 minecraft:black_concrete
fill 409 205 567 410 208 567 minecraft:black_concrete
fill 410 205 572 410 207 572 minecraft:black_concrete
fill 410 205 573 410 205 574 minecraft:purple_concrete
fill 411 205 557 411 208 557 minecraft:purple_terracotta
fill 411 205 571 412 207 571 minecraft:black_concrete
setblock 411 205 574 minecraft:purple_concrete
setblock 412 205 557 minecraft:purple_concrete
fill 412 205 568 412 207 570 minecraft:black_concrete
fill 413 205 571 413 206 571 minecraft:purple_concrete
fill 414 205 599 415 205 599 minecraft:purple_concrete
fill 415 205 557 416 205 557 minecraft:purple_concrete
fill 418 205 570 418 207 571 minecraft:purple_terracotta
setblock 418 205 575 minecraft:purple_concrete
setblock 418 205 586 minecraft:purple_concrete
fill 418 205 591 418 207 591 minecraft:purple_terracotta
fill 376 206 557 376 211 557 minecraft:purple_terracotta
fill 376 206 563 376 207 564 minecraft:purple_concrete
fill 376 206 565 376 211 566 minecraft:purple_terracotta
fill 376 206 574 376 211 574 minecraft:purple_terracotta
fill 376 206 575 376 206 576 minecraft:purple_concrete
fill 376 206 577 376 211 578 minecraft:purple_terracotta
fill 376 206 583 376 207 584 minecraft:purple_concrete
fill 376 206 585 376 211 586 minecraft:purple_terracotta
setblock 376 206 587 minecraft:purple_concrete
fill 376 206 595 376 207 596 minecraft:purple_concrete
fill 376 206 597 376 211 598 minecraft:purple_terracotta
fill 381 206 599 381 207 599 minecraft:purple_concrete
setblock 382 206 557 minecraft:purple_concrete
fill 383 206 557 384 211 557 minecraft:purple_terracotta
fill 383 206 599 383 211 599 minecraft:purple_terracotta
fill 384 206 599 385 206 599 minecraft:purple_concrete
fill 385 206 557 386 207 557 minecraft:purple_concrete
fill 386 206 599 386 211 599 minecraft:purple_terracotta
fill 391 206 557 392 211 557 minecraft:purple_terracotta
fill 392 206 599 393 207 599 minecraft:purple_concrete
fill 393 206 557 394 206 557 minecraft:purple_concrete
fill 394 206 563 394 207 563 minecraft:amethyst_block
fill 394 206 599 395 211 599 minecraft:purple_terracotta
fill 395 206 557 395 211 557 minecraft:purple_terracotta
fill 400 206 592 400 207 592 minecraft:amethyst_block
fill 403 206 557 404 211 557 minecraft:purple_terracotta
fill 404 206 599 405 206 599 minecraft:purple_concrete
fill 405 206 557 406 207 557 minecraft:purple_concrete
fill 406 206 599 407 211 599 minecraft:purple_terracotta
fill 407 206 567 407 207 570 minecraft:black_concrete
fill 408 206 566 409 207 566 minecraft:black_concrete
setblock 409 206 572 minecraft:black_concrete
fill 410 206 573 412 206 573 minecraft:purple_concrete
fill 411 206 567 411 208 567 minecraft:black_concrete
setblock 411 206 572 minecraft:black_concrete
fill 412 206 557 412 211 557 minecraft:purple_terracotta
fill 412 206 572 413 206 572 minecraft:purple_concrete
fill 413 206 599 413 207 599 minecraft:purple_concrete
setblock 414 206 557 minecraft:purple_concrete
fill 414 206 599 415 211 599 minecraft:purple_terracotta
fill 415 206 557 416 211 557 minecraft:purple_terracotta
setblock 416 206 599 minecraft:purple_concrete
fill 417 206 557 417 207 557 minecraft:purple_concrete
fill 418 206 562 418 211 563 minecraft:purple_terracotta
fill 418 206 564 418 207 565 minecraft:purple_concrete
fill 418 206 572 418 209 572 minecraft:purple_terracotta
setblock 418 206 573 minecraft:purple_concrete
fill 418 206 574 418 211 575 minecraft:purple_terracotta
fill 418 206 576 418 207 577 minecraft:purple_concrete
fill 418 206 582 418 208 583 minecraft:purple_terracotta
fill 418 206 584 418 206 585 minecraft:purple_concrete
fill 418 206 586 418 211 586 minecraft:purple_terracotta
fill 418 206 588 418 207 588 minecraft:purple_concrete
setblock 418 206 589 minecraft:purple_terracotta
fill 418 206 594 418 211 595 minecraft:purple_terracotta
fill 418 206 596 418 207 597 minecraft:purple_concrete
fill 418 206 599 418 211 599 minecraft:purple_terracotta
fill 376 207 571 376 207 572 minecraft:purple_concrete
setblock 376 207 575 minecraft:purple_concrete
fill 376 207 576 376 210 576 minecraft:purple_terracotta
fill 376 207 587 376 210 587 minecraft:purple_terracotta
setblock 376 207 592 minecraft:purple_concrete
setblock 377 207 557 minecraft:purple_concrete
setblock 380 207 599 minecraft:purple_concrete
fill 382 207 557 382 210 557 minecraft:purple_terracotta
fill 384 207 599 385 210 599 minecraft:purple_terracotta
fill 393 207 557 393 210 557 minecraft:purple_terracotta
setblock 394 207 557 minecraft:purple_concrete
fill 397 207 557 398 207 557 minecraft:purple_concrete
setblock 401 207 599 minecraft:purple_concrete
setblock 404 207 599 minecraft:purple_concrete
fill 405 207 599 405 210 599 minecraft:purple_terracotta
fill 406 207 566 406 207 568 minecraft:black_concrete
fill 407 207 565 408 207 565 minecraft:black_concrete
fill 407 207 566 407 213 566 minecraft:purple_concrete
setblock 409 207 572 minecraft:purple_concrete
fill 410 207 566 410 209 566 minecraft:black_concrete
fill 411 207 572 412 207 572 minecraft:purple_concrete
setblock 412 207 599 minecraft:purple_concrete
fill 414 207 557 414 210 557 minecraft:purple_terracotta
fill 416 207 599 416 210 599 minecraft:purple_terracotta
setblock 418 207 557 minecraft:purple_concrete
setblock 418 207 568 minecraft:purple_concrete
fill 418 207 573 418 209 573 minecraft:purple_terracotta
fill 418 207 584 418 210 584 minecraft:purple_terracotta
setblock 418 207 585 minecraft:purple_concrete
setblock 418 207 589 minecraft:purple_concrete
fill 376 208 561 376 208 562 minecraft:purple_concrete
fill 376 208 563 376 213 564 minecraft:purple_terracotta
fill 376 208 570 376 209 570 minecraft:purple_concrete
fill 376 208 571 376 213 572 minecraft:purple_terracotta
setblock 376 208 573 minecraft:purple_concrete
fill 376 208 575 376 213 575 minecraft:purple_terracotta
fill 376 208 581 376 209 582 minecraft:purple_concrete
fill 376 208 583 376 213 584 minecraft:purple_terracotta
fill 376 208 592 376 213 592 minecraft:purple_terracotta
fill 376 208 593 376 208 594 minecraft:purple_concrete
fill 376 208 595 376 213 596 minecraft:purple_terracotta
fill 377 208 557 377 213 557 minecraft:purple_terracotta
fill 378 208 599 379 209 599 minecraft:purple_concrete
fill 380 208 599 381 213 599 minecraft:purple_terracotta
setblock 382 208 599 minecraft:purple_concrete
fill 385 208 557 386 213 557 minecraft:purple_terracotta
fill 387 208 557 388 209 557 minecraft:purple_concrete
fill 390 208 599 391 209 599 minecraft:purple_concrete
fill 392 208 599 393 213 599 minecraft:purple_terracotta
fill 394 208 557 394 213 557 minecraft:purple_terracotta
setblock 396 208 557 minecraft:purple_concrete
fill 397 208 557 398 213 557 minecraft:purple_terracotta
fill 399 208 557 399 209 557 minecraft:purple_concrete
fill 399 208 599 399 209 599 minecraft:purple_concrete
fill 401 208 599 401 213 599 minecraft:purple_terracotta
fill 402 208 599 403 208 599 minecraft:purple_concrete
fill 404 208 599 404 213 599 minecraft:purple_terracotta
fill 405 208 557 406 213 557 minecraft:purple_terracotta
fill 405 208 565 406 213 567 minecraft:purple_concrete
fill 406 208 564 407 213 564 minecraft:purple_concrete
fill 406 208 568 407 211 568 minecraft:purple_concrete
fill 406 208 569 408 209 569 minecraft:black_concrete
fill 407 208 557 408 208 557 minecraft:purple_concrete
fill 407 208 565 408 212 565 minecraft:purple_concrete
fill 407 208 567 408 212 567 minecraft:purple_concrete
fill 407 208 570 408 208 570 minecraft:black_concrete
fill 408 208 566 409 211 566 minecraft:purple_concrete
setblock 408 208 568 minecraft:black_concrete
setblock 409 208 565 minecraft:black_concrete
fill 410 208 599 411 209 599 minecraft:purple_concrete
setblock 411 208 571 minecraft:black_concrete
fill 412 208 599 413 213 599 minecraft:purple_terracotta
fill 417 208 557 418 213 557 minecraft:purple_terracotta
fill 418 208 558 418 209 559 minecraft:purple_concrete
fill 418 208 564 418 210 565 minecraft:purple_terracotta
fill 418 208 566 418 208 567 minecraft:purple_concrete
fill 418 208 568 418 213 568 minecraft:purple_terracotta
fill 418 208 570 418 209 570 minecraft:purple_concrete
setblock 418 208 571 minecraft:purple_terracotta
fill 418 208 576 418 213 577 minecraft:purple_terracotta
fill 418 208 578 418 209 579 minecraft:purple_concrete
fill 418 208 585 418 210 585 minecraft:purple_terracotta
setblock 418 208 587 minecraft:purple_concrete
fill 418 208 588 418 213 589 minecraft:purple_terracotta
fill 418 208 590 418 209 591 minecraft:purple_concrete
fill 418 208 596 418 213 597 minecraft:purple_terracotta
setblock 418 208 598 minecraft:purple_concrete
setblock 376 209 558 minecraft:purple_concrete
setblock 376 209 561 minecraft:purple_concrete
fill 376 209 562 376 212 562 minecraft:purple_terracotta
setblock 376 209 569 minecraft:purple_concrete
fill 376 209 573 376 212 573 minecraft:purple_terracotta
fill 376 209 589 376 209 590 minecraft:purple_concrete
setblock 376 209 593 minecraft:purple_concrete
fill 376 209 594 376 212 594 minecraft:purple_terracotta
fill 379 209 557 380 209 557 minecraft:purple_concrete
fill 382 209 599 382 212 599 minecraft:purple_terracotta
setblock 387 209 599 minecraft:purple_concrete
fill 396 209 557 396 212 557 minecraft:purple_terracotta
setblock 398 209 599 minecraft:purple_concrete
setblock 400 209 557 minecraft:purple_concrete
fill 402 209 599 403 212 599 minecraft:purple_terracotta
fill 404 209 564 404 214 566 minecraft:purple_concrete
fill 405 209 564 405 215 564 minecraft:purple_concrete
fill 405 209 568 405 211 568 minecraft:purple_concrete
fill 407 209 557 407 212 557 minecraft:purple_terracotta
setblock 408 209 557 minecraft:purple_concrete
fill 408 209 564 408 211 564 minecraft:purple_concrete
fill 408 209 568 408 211 568 minecraft:purple_concrete
fill 408 209 570 410 209 570 minecraft:black_concrete
fill 409 209 565 409 211 565 minecraft:purple_concrete
fill 409 209 567 409 211 567 minecraft:purple_concrete
fill 409 209 568 411 209 569 minecraft:black_concrete
fill 410 209 567 410 210 567 minecraft:black_concrete
setblock 411 209 557 minecraft:purple_concrete
fill 418 209 566 418 212 566 minecraft:purple_terracotta
setblock 418 209 567 minecraft:purple_concrete
setblock 418 209 571 minecraft:purple_concrete
setblock 418 209 582 minecraft:purple_concrete
fill 418 209 583 418 211 583 minecraft:purple_terracotta
fill 418 209 587 418 212 587 minecraft:purple_terracotta
fill 418 209 598 418 212 598 minecraft:purple_terracotta
fill 376 210 558 376 215 558 minecraft:purple_terracotta
fill 376 210 559 376 210 560 minecraft:purple_concrete
fill 376 210 561 376 215 561 minecraft:purple_terracotta
fill 376 210 567 376 211 568 minecraft:purple_concrete
fill 376 210 569 376 215 570 minecraft:purple_terracotta
fill 376 210 579 376 210 580 minecraft:purple_concrete
fill 376 210 581 376 215 582 minecraft:purple_terracotta
fill 376 210 588 376 211 588 minecraft:purple_concrete
fill 376 210 589 376 215 590 minecraft:purple_terracotta
setblock 376 210 591 minecraft:purple_concrete
fill 376 210 593 376 215 593 minecraft:purple_terracotta
fill 376 210 599 377 211 599 minecraft:purple_concrete
fill 377 210 558 379 210 558 minecraft:obsidian
fill 377 210 560 377 210 562 minecraft:obsidian
fill 377 210 564 377 210 566 minecraft:obsidian
fill 377 210 568 377 210 570 minecraft:obsidian
fill 377 210 572 377 210 574 minecraft:obsidian
fill 377 210 576 377 210 578 minecraft:obsidian
fill 377 210 580 377 210 582 minecraft:obsidian
fill 377 210 584 377 210 586 minecraft:obsidian
fill 377 210 588 377 210 590 minecraft:obsidian
fill 377 210 592 377 210 594 minecraft:obsidian
fill 377 210 596 377 210 598 minecraft:obsidian
setblock 378 210 557 minecraft:purple_concrete
fill 378 210 599 379 215 599 minecraft:purple_terracotta
fill 379 210 557 380 215 557 minecraft:purple_terracotta
fill 379 210 598 381 210 598 minecraft:obsidian
fill 381 210 557 381 211 557 minecraft:purple_concrete
fill 381 210 558 383 210 558 minecraft:obsidian
fill 383 210 598 385 210 598 minecraft:obsidian
fill 385 210 558 387 210 558 minecraft:obsidian
fill 387 210 557 388 215 557 minecraft:purple_terracotta
fill 387 210 598 389 210 598 minecraft:obsidian
fill 387 210 599 387 215 599 minecraft:purple_terracotta
fill 388 210 599 389 210 599 minecraft:purple_concrete
fill 389 210 557 390 210 557 minecraft:purple_concrete
fill 389 210 558 391 210 558 minecraft:obsidian
fill 390 210 599 391 215 599 minecraft:purple_terracotta
fill 391 210 598 393 210 598 minecraft:obsidian
fill 393 210 558 395 210 558 minecraft:obsidian
fill 395 210 598 397 210 598 minecraft:obsidian
fill 396 210 599 397 211 599 minecraft:purple_concrete
fill 397 210 558 399 210 558 minecraft:obsidian
fill 398 210 599 399 215 599 minecraft:purple_terracotta
fill 399 210 557 400 215 557 minecraft:purple_terracotta
fill 399 210 598 401 210 598 minecraft:obsidian
setblock 400 210 599 minecraft:purple_concrete
fill 401 210 557 402 211 557 minecraft:purple_concrete
fill 401 210 558 403 210 558 minecraft:obsidian
fill 403 210 564 403 214 566 minecraft:purple_concrete
fill 403 210 598 405 210 598 minecraft:obsidian
fill 404 210 563 407 211 563 minecraft:purple_concrete
fill 404 210 567 404 213 567 minecraft:purple_concrete
fill 405 210 558 407 210 558 minecraft:obsidian
fill 407 210 569 409 210 569 minecraft:black_concrete
fill 407 210 598 409 210 598 minecraft:obsidian
fill 408 210 557 408 215 557 minecraft:purple_terracotta
fill 408 210 599 409 211 599 minecraft:purple_concrete
fill 409 210 557 410 210 557 minecraft:purple_concrete
fill 409 210 558 411 210 558 minecraft:obsidian
fill 409 210 568 410 210 568 minecraft:black_concrete
fill 410 210 599 411 215 599 minecraft:purple_terracotta
fill 411 210 557 411 215 557 minecraft:purple_terracotta
fill 411 210 598 413 210 598 minecraft:obsidian
fill 413 210 557 413 211 557 minecraft:purple_concrete
fill 413 210 558 415 210 558 minecraft:obsidian
fill 415 210 598 417 210 598 minecraft:obsidian
fill 417 210 558 417 210 560 minecraft:obsidian
fill 417 210 562 417 210 564 minecraft:obsidian
fill 417 210 566 417 210 568 minecraft:obsidian
fill 417 210 570 417 210 572 minecraft:obsidian
fill 417 210 574 417 210 576 minecraft:obsidian
fill 417 210 578 417 210 580 minecraft:obsidian
fill 417 210 582 417 210 584 minecraft:obsidian
fill 417 210 586 417 210 588 minecraft:obsidian
fill 417 210 590 417 210 592 minecraft:obsidian
fill 417 210 594 417 210 596 minecraft:obsidian
fill 417 210 599 417 211 599 minecraft:purple_concrete
fill 418 210 558 418 215 559 minecraft:purple_terracotta
fill 418 210 560 418 211 561 minecraft:purple_concrete
fill 418 210 567 418 212 567 minecraft:purple_terracotta
setblock 418 210 569 minecraft:purple_concrete
fill 418 210 570 418 215 571 minecraft:purple_terracotta
fill 418 210 572 418 211 573 minecraft:purple_concrete
fill 418 210 578 418 215 579 minecraft:purple_terracotta
fill 418 210 580 418 210 581 minecraft:purple_concrete
fill 418 210 582 418 211 582 minecraft:purple_terracotta
fill 418 210 590 418 215 591 minecraft:purple_terracotta
fill 418 210 592 418 211 593 minecraft:purple_concrete
fill 376 211 559 376 214 560 minecraft:purple_terracotta
setblock 376 211 576 minecraft:purple_concrete
setblock 376 211 579 minecraft:purple_concrete
fill 376 211 580 376 214 580 minecraft:purple_terracotta
setblock 376 211 587 minecraft:purple_concrete
fill 376 211 591 376 214 591 minecraft:purple_terracotta
fill 378 211 557 378 214 557 minecraft:purple_terracotta
setblock 382 211 557 minecraft:purple_concrete
fill 384 211 599 385 211 599 minecraft:purple_concrete
setblock 388 211 599 minecraft:purple_concrete
fill 389 211 557 389 214 557 minecraft:purple_terracotta
fill 389 211 599 389 214 599 minecraft:purple_terracotta
setblock 390 211 557 minecraft:purple_concrete
setblock 393 211 557 minecraft:purple_concrete
fill 400 211 599 400 214 599 minecraft:purple_terracotta
fill 402 211 563 402 216 565 minecraft:purple_concrete
fill 403 211 562 403 216 563 minecraft:purple_concrete
fill 404 211 562 405 214 562 minecraft:purple_concrete
setblock 405 211 599 minecraft:purple_concrete
fill 409 211 557 410 214 557 minecraft:purple_terracotta
setblock 414 211 557 minecraft:purple_concrete
setblock 416 211 599 minecraft:purple_concrete
setblock 418 211 564 minecraft:purple_concrete
fill 418 211 565 418 213 565 minecraft:purple_terracotta
fill 418 211 569 418 214 569 minecraft:purple_terracotta
fill 418 211 580 418 214 580 minecraft:purple_terracotta
setblock 418 211 581 minecraft:purple_concrete
fill 418 211 584 418 211 585 minecraft:purple_concrete
setblock 376 212 557 minecraft:purple_concrete
fill 376 212 565 376 213 566 minecraft:purple_concrete
fill 376 212 567 376 215 568 minecraft:purple_terracotta
fill 376 212 574 376 213 574 minecraft:purple_concrete
fill 376 212 576 376 217 576 minecraft:purple_terracotta
fill 376 212 577 376 212 578 minecraft:purple_concrete
fill 376 212 579 376 217 579 minecraft:purple_terracotta
fill 376 212 585 376 213 586 minecraft:purple_concrete
fill 376 212 587 376 217 588 minecraft:purple_terracotta
fill 376 212 597 376 212 598 minecraft:purple_concrete
fill 376 212 599 377 217 599 minecraft:purple_terracotta
setblock 379 212 560 minecraft:light[level=12]
setblock 379 212 568 minecraft:light[level=12]
setblock 379 212 576 minecraft:light[level=12]
setblock 379 212 584 minecraft:light[level=12]
setblock 379 212 592 minecraft:light[level=12]
fill 381 212 557 382 217 557 minecraft:purple_terracotta
fill 383 212 557 384 213 557 minecraft:purple_concrete
fill 383 212 599 383 213 599 minecraft:purple_concrete
fill 384 212 599 385 215 599 minecraft:purple_terracotta
setblock 386 212 599 minecraft:purple_concrete
setblock 387 212 560 minecraft:light[level=12]
setblock 387 212 568 minecraft:light[level=12]
setblock 387 212 576 minecraft:light[level=12]
setblock 387 212 584 minecraft:light[level=12]
setblock 387 212 592 minecraft:light[level=12]
fill 388 212 599 388 216 599 minecraft:purple_terracotta
fill 390 212 557 390 215 557 minecraft:purple_terracotta
fill 391 212 557 392 212 557 minecraft:purple_concrete
fill 393 212 557 393 217 557 minecraft:purple_terracotta
fill 394 212 599 395 213 599 minecraft:purple_concrete
fill 395 212 557 395 213 557 minecraft:purple_concrete
setblock 395 212 560 minecraft:light[level=12]
setblock 395 212 568 minecraft:light[level=12]
setblock 395 212 576 minecraft:light[level=12]
setblock 395 212 584 minecraft:light[level=12]
setblock 395 212 592 minecraft:light[level=12]
fill 396 212 599 397 216 599 minecraft:purple_terracotta
fill 401 212 557 402 217 557 minecraft:purple_terracotta
fill 401 212 562 401 216 565 minecraft:purple_concrete
fill 402 212 562 402 217 562 minecraft:purple_concrete
fill 402 212 566 402 215 566 minecraft:purple_concrete
fill 403 212 557 404 213 557 minecraft:purple_concrete
setblock 403 212 560 minecraft:light[level=12]
setblock 403 212 568 minecraft:light[level=12]
setblock 403 212 576 minecraft:light[level=12]
setblock 403 212 584 minecraft:light[level=12]
setblock 403 212 592 minecraft:light[level=12]
fill 404 212 563 406 213 563 minecraft:purple_concrete
fill 405 212 599 405 217 599 minecraft:purple_terracotta
fill 406 212 599 407 212 599 minecraft:purple_concrete
setblock 408 212 566 minecraft:purple_concrete
fill 408 212 599 409 217 599 minecraft:purple_terracotta
setblock 411 212 560 minecraft:light[level=12]
setblock 411 212 568 minecraft:light[level=12]
setblock 411 212 576 minecraft:light[level=12]
setblock 411 212 584 minecraft:light[level=12]
setblock 411 212 592 minecraft:light[level=12]
setblock 412 212 557 minecraft:purple_concrete
fill 413 212 557 414 217 557 minecraft:purple_terracotta
fill 414 212 599 415 213 599 minecraft:purple_concrete
fill 415 212 557 416 213 557 minecraft:purple_concrete
fill 416 212 599 417 217 599 minecraft:purple_terracotta
fill 418 212 560 418 215 561 minecraft:purple_terracotta
fill 418 212 562 418 212 563 minecraft:purple_concrete
fill 418 212 564 418 217 564 minecraft:purple_terracotta
fill 418 212 572 418 215 573 minecraft:purple_terracotta
fill 418 212 574 418 213 575 minecraft:purple_concrete
fill 418 212 581 418 217 581 minecraft:purple_terracotta
fill 418 212 582 418 212 583 minecraft:purple_concrete
fill 418 212 584 418 213 585 minecraft:purple_terracotta
fill 418 212 586 418 213 586 minecraft:purple_concrete
fill 418 212 592 418 217 593 minecraft:purple_terracotta
fill 418 212 594 418 213 595 minecraft:purple_concrete
setblock 418 212 599 minecraft:purple_concrete
fill 376 213 557 376 216 557 minecraft:purple_terracotta
setblock 376 213 562 minecraft:purple_concrete
setblock 376 213 573 minecraft:purple_concrete
fill 376 213 577 376 216 578 minecraft:purple_terracotta
setblock 376 213 594 minecraft:purple_concrete
setblock 376 213 597 minecraft:purple_concrete
fill 376 213 598 376 216 598 minecraft:purple_terracotta
setblock 382 213 599 minecraft:purple_concrete
fill 386 213 599 386 216 599 minecraft:purple_terracotta
fill 391 213 557 392 216 557 minecraft:purple_terracotta
setblock 396 213 557 minecraft:purple_concrete
fill 399 213 563 400 214 564 minecraft:purple_concrete
fill 400 213 562 400 214 562 minecraft:purple_concrete
fill 400 213 565 400 217 565 minecraft:purple_concrete
fill 401 213 561 403 214 561 minecraft:purple_concrete
fill 402 213 599 403 213 599 minecraft:purple_concrete
setblock 406 213 599 minecraft:purple_concrete
setblock 407 213 557 minecraft:purple_concrete
setblock 407 213 565 minecraft:purple_concrete
fill 407 213 599 407 215 599 minecraft:purple_terracotta
fill 412 213 557 412 216 557 minecraft:purple_terracotta
fill 418 213 562 418 216 562 minecraft:purple_terracotta
setblock 418 213 563 minecraft:purple_concrete
fill 418 213 566 418 213 567 minecraft:purple_concrete
fill 418 213 582 418 215 583 minecraft:purple_terracotta
setblock 418 213 587 minecraft:purple_concrete
setblock 418 213 598 minecraft:purple_concrete
fill 418 213 599 418 215 599 minecraft:purple_terracotta
fill 376 214 562 376 219 562 minecraft:purple_terracotta
fill 376 214 563 376 214 564 minecraft:purple_concrete
fill 376 214 565 376 217 566 minecraft:purple_terracotta
fill 376 214 571 376 215 572 minecraft:purple_concrete
fill 376 214 573 376 219 574 minecraft:purple_terracotta
setblock 376 214 575 minecraft:purple_concrete
fill 376 214 583 376 215 584 minecraft:purple_concrete
fill 376 214 585 376 219 586 minecraft:purple_terracotta
fill 376 214 592 376 215 592 minecraft:purple_concrete
fill 376 214 594 376 219 594 minecraft:purple_terracotta
fill 376 214 595 376 214 596 minecraft:purple_concrete
fill 376 214 597 376 219 597 minecraft:purple_terracotta
fill 377 214 557 377 215 557 minecraft:purple_concrete
fill 380 214 599 381 215 599 minecraft:purple_concrete
fill 382 214 599 383 219 599 minecraft:purple_terracotta
fill 383 214 557 384 219 557 minecraft:purple_terracotta
fill 385 214 557 386 215 557 minecraft:purple_concrete
fill 392 214 599 393 214 599 minecraft:purple_concrete
setblock 394 214 557 minecraft:purple_concrete
fill 394 214 599 395 219 599 minecraft:purple_terracotta
fill 395 214 557 396 216 557 minecraft:purple_terracotta
fill 397 214 557 398 215 557 minecraft:purple_concrete
fill 398 214 562 398 214 564 minecraft:purple_concrete
fill 399 214 561 399 214 562 minecraft:purple_concrete
fill 399 214 565 399 215 565 minecraft:purple_concrete
fill 400 214 561 400 215 561 minecraft:purple_concrete
fill 401 214 566 401 215 566 minecraft:purple_concrete
fill 401 214 599 401 215 599 minecraft:purple_concrete
fill 402 214 599 403 216 599 minecraft:purple_terracotta
fill 403 214 557 404 216 557 minecraft:purple_terracotta
fill 404 214 563 405 214 563 minecraft:purple_concrete
setblock 404 214 599 minecraft:purple_concrete
fill 405 214 557 406 214 557 minecraft:purple_concrete
fill 405 214 565 405 214 566 minecraft:purple_concrete
fill 406 214 564 406 214 565 minecraft:purple_concrete
fill 406 214 566 407 216 566 minecraft:amethyst_block
fill 406 214 599 406 219 599 minecraft:purple_terracotta
fill 407 214 557 407 219 557 minecraft:purple_terracotta
fill 412 214 599 413 215 599 minecraft:purple_concrete
fill 414 214 599 415 215 599 minecraft:purple_terracotta
fill 415 214 557 416 219 557 minecraft:purple_terracotta
fill 417 214 557 418 215 557 minecraft:purple_concrete
fill 418 214 563 418 219 563 minecraft:purple_terracotta
setblock 418 214 565 minecraft:purple_concrete
fill 418 214 566 418 215 567 minecraft:purple_terracotta
fill 418 214 568 418 215 568 minecraft:purple_concrete
fill 418 214 574 418 219 575 minecraft:purple_terracotta
fill 418 214 576 418 215 577 minecraft:purple_concrete
fill 418 214 584 418 216 584 minecraft:purple_terracotta
setblock 418 214 585 minecraft:purple_concrete
fill 418 214 586 418 215 587 minecraft:purple_terracotta
fill 418 214 588 418 215 589 minecraft:purple_concrete
fill 418 214 594 418 215 595 minecraft:purple_terracotta
fill 418 214 596 418 214 597 minecraft:purple_concrete
fill 418 214 598 418 215 598 minecraft:purple_terracotta
fill 376 215 559 376 215 560 minecraft:purple_concrete
setblock 376 215 563 minecraft:purple_concrete
fill 376 215 564 376 218 564 minecraft:purple_terracotta
fill 376 215 575 376 216 575 minecraft:purple_terracotta
setblock 376 215 580 minecraft:purple_concrete
setblock 376 215 591 minecraft:purple_concrete
fill 376 215 595 376 218 596 minecraft:purple_terracotta
setblock 378 215 557 minecraft:purple_concrete
setblock 389 215 557 minecraft:purple_concrete
setblock 389 215 599 minecraft:purple_concrete
setblock 392 215 599 minecraft:purple_concrete
fill 393 215 599 393 217 599 minecraft:purple_terracotta
setblock 394 215 557 minecraft:purple_terracotta
fill 397 215 562 399 219 564 minecraft:black_concrete
fill 398 215 561 399 219 561 minecraft:black_concrete
fill 400 215 562 400 219 563 minecraft:black_concrete
setblock 400 215 564 minecraft:purple_concrete
setblock 400 215 599 minecraft:purple_concrete
fill 401 215 561 402 216 561 minecraft:purple_concrete
fill 403 215 564 404 215 565 minecraft:purple_concrete
fill 404 215 562 404 215 563 minecraft:purple_concrete
fill 404 215 599 404 218 599 minecraft:purple_terracotta
fill 405 215 557 405 218 557 minecraft:purple_terracotta
setblock 406 215 557 minecraft:purple_concrete
fill 409 215 557 410 215 557 minecraft:purple_concrete
fill 418 215 565 418 218 565 minecraft:purple_terracotta
setblock 418 215 569 minecraft:purple_concrete
setblock 418 215 580 minecraft:purple_concrete
fill 418 215 585 418 217 585 minecraft:purple_terracotta
fill 418 215 596 418 218 596 minecraft:purple_terracotta
setblock 418 215 597 minecraft:purple_concrete
fill 376 216 558 376 217 558 minecraft:purple_concrete
fill 376 216 559 376 219 560 minecraft:purple_terracotta
setblock 376 216 561 minecraft:purple_concrete
setblock 376 216 563 minecraft:black_concrete
fill 376 216 567 376 217 567 minecraft:purple_terracotta
setblock 376 216 568 minecraft:black_concrete
fill 376 216 569 376 217 570 minecraft:purple_concrete
setblock 376 216 571 minecraft:black_concrete
fill 376 216 572 376 219 572 minecraft:purple_terracotta
setblock 376 216 580 minecraft:black_concrete
fill 376 216 581 376 216 582 minecraft:purple_concrete
fill 376 216 583 376 216 584 minecraft:purple_terracotta
fill 376 216 589 376 217 590 minecraft:purple_concrete
fill 376 216 591 376 220 591 minecraft:purple_terracotta
setblock 376 216 592 minecraft:black_concrete
setblock 376 216 593 minecraft:purple_concrete
fill 377 216 557 378 219 557 minecraft:purple_terracotta
fill 377 216 558 379 216 558 minecraft:obsidian
fill 377 216 560 377 216 562 minecraft:obsidian
fill 377 216 564 377 216 566 minecraft:obsidian
fill 377 216 568 377 216 570 minecraft:obsidian
fill 377 216 572 377 216 574 minecraft:obsidian
fill 377 216 576 377 216 578 minecraft:obsidian
fill 377 216 580 377 216 582 minecraft:obsidian
fill 377 216 584 377 216 586 minecraft:obsidian
fill 377 216 588 377 216 590 minecraft:obsidian
fill 377 216 592 377 216 594 minecraft:obsidian
fill 377 216 596 377 216 598 minecraft:obsidian
fill 378 216 599 379 217 599 minecraft:purple_concrete
fill 379 216 557 380 217 557 minecraft:purple_concrete
fill 379 216 598 381 216 598 minecraft:obsidian
fill 380 216 599 381 219 599 minecraft:purple_terracotta
fill 381 216 558 383 216 558 minecraft:obsidian
fill 383 216 598 385 216 598 minecraft:obsidian
fill 384 216 599 384 217 599 minecraft:purple_terracotta
fill 385 216 557 385 219 557 minecraft:purple_terracotta
fill 385 216 558 387 216 558 minecraft:obsidian
fill 385 216 599 385 217 599 minecraft:black_concrete
setblock 386 216 557 minecraft:black_concrete
fill 387 216 557 388 216 557 minecraft:purple_concrete
fill 387 216 598 389 216 598 minecraft:obsidian
fill 387 216 599 387 217 599 minecraft:purple_concrete
fill 389 216 557 389 219 557 minecraft:purple_terracotta
fill 389 216 558 391 216 558 minecraft:obsidian
fill 389 216 599 389 217 599 minecraft:purple_terracotta
setblock 390 216 557 minecraft:black_concrete
fill 390 216 599 391 216 599 minecraft:purple_concrete
fill 391 216 598 393 216 598 minecraft:obsidian
setblock 392 216 599 minecraft:purple_terracotta
fill 393 216 558 395 216 558 minecraft:obsidian
setblock 394 216 557 minecraft:black_concrete
fill 395 216 563 396 218 563 minecraft:black_concrete
fill 395 216 598 397 216 598 minecraft:obsidian
fill 396 216 561 396 219 562 minecraft:black_concrete
fill 396 216 564 396 219 564 minecraft:black_concrete
fill 397 216 557 398 216 557 minecraft:black_concrete
fill 397 216 558 399 216 558 minecraft:obsidian
fill 397 216 561 397 220 561 minecraft:black_concrete
fill 398 216 560 399 217 560 minecraft:black_concrete
fill 398 216 565 399 218 565 minecraft:black_concrete
fill 398 216 599 399 217 599 minecraft:purple_concrete
fill 399 216 557 400 217 557 minecraft:purple_concrete
fill 399 216 598 401 216 598 minecraft:obsidian
fill 400 216 561 400 218 561 minecraft:black_concrete
fill 400 216 564 400 218 564 minecraft:black_concrete
fill 400 216 599 401 219 599 minecraft:purple_terracotta
fill 401 216 558 403 216 558 minecraft:obsidian
fill 403 216 564 403 216 565 minecraft:purple_concrete
fill 403 216 598 405 216 598 minecraft:obsidian
fill 405 216 558 407 216 558 minecraft:obsidian
fill 406 216 557 406 219 557 minecraft:purple_terracotta
fill 407 216 598 409 216 598 minecraft:obsidian
setblock 407 216 599 minecraft:black_concrete
setblock 408 216 557 minecraft:purple_concrete
fill 409 216 557 410 219 557 minecraft:purple_terracotta
fill 409 216 558 411 216 558 minecraft:obsidian
fill 410 216 599 411 216 599 minecraft:purple_concrete
fill 411 216 557 411 217 557 minecraft:purple_concrete
fill 411 216 598 413 216 598 minecraft:obsidian
fill 412 216 599 414 219 599 minecraft:purple_terracotta
fill 413 216 558 415 216 558 minecraft:obsidian
fill 415 216 598 417 216 598 minecraft:obsidian
setblock 415 216 599 minecraft:black_concrete
fill 417 216 557 418 219 557 minecraft:purple_terracotta
fill 417 216 558 417 216 560 minecraft:obsidian
fill 417 216 562 417 216 564 minecraft:obsidian
fill 417 216 566 417 216 568 minecraft:obsidian
fill 417 216 570 417 216 572 minecraft:obsidian
fill 417 216 574 417 216 576 minecraft:obsidian
fill 417 216 578 417 216 580 minecraft:obsidian
fill 417 216 582 417 216 584 minecraft:obsidian
fill 417 216 586 417 216 588 minecraft:obsidian
fill 417 216 590 417 216 592 minecraft:obsidian
fill 417 216 594 417 216 596 minecraft:obsidian
fill 418 216 558 418 216 559 minecraft:purple_concrete
fill 418 216 560 418 217 560 minecraft:purple_terracotta
setblock 418 216 561 minecraft:black_concrete
setblock 418 216 566 minecraft:black_concrete
fill 418 216 567 418 219 569 minecraft:purple_terracotta
fill 418 216 570 418 217 571 minecraft:purple_concrete
setblock 418 216 572 minecraft:black_concrete
setblock 418 216 573 minecraft:purple_terracotta
setblock 418 216 576 minecraft:black_concrete
setblock 418 216 577 minecraft:purple_terracotta
fill 418 216 578 418 216 579 minecraft:purple_concrete
fill 418 216 580 418 219 580 minecraft:purple_terracotta
fill 418 216 582 418 217 582 minecraft:purple_concrete
setblock 418 216 583 minecraft:purple_terracotta
fill 418 216 586 418 219 586 minecraft:purple_terracotta
setblock 418 216 587 minecraft:black_concrete
fill 418 216 588 418 219 588 minecraft:purple_terracotta
setblock 418 216 589 minecraft:black_concrete
fill 418 216 590 418 217 591 minecraft:purple_concrete
setblock 418 216 594 minecraft:purple_terracotta
setblock 418 216 595 minecraft:black_concrete
fill 418 216 597 418 218 597 minecraft:purple_terracotta
setblock 418 216 598 minecraft:black_concrete
fill 418 216 599 418 217 599 minecraft:purple_concrete
setblock 376 217 557 minecraft:purple_concrete
fill 376 217 561 376 220 561 minecraft:purple_terracotta
fill 376 217 563 376 219 563 minecraft:purple_terracotta
setblock 376 217 568 minecraft:purple_terracotta
fill 376 217 571 376 219 571 minecraft:purple_terracotta
setblock 376 217 575 minecraft:black_concrete
fill 376 217 577 376 217 578 minecraft:purple_concrete
fill 376 217 580 376 219 580 minecraft:purple_terracotta
setblock 376 217 581 minecraft:purple_concrete
fill 376 217 582 376 217 583 minecraft:black_concrete
fill 376 217 584 376 219 584 minecraft:purple_terracotta
fill 376 217 592 376 217 593 minecraft:purple_terracotta
setblock 376 217 598 minecraft:purple_concrete
fill 386 217 557 387 219 557 minecraft:purple_terracotta
setblock 386 217 599 minecraft:purple_concrete
setblock 388 217 557 minecraft:purple_concrete
setblock 388 217 599 minecraft:black_concrete
setblock 390 217 557 minecraft:purple_terracotta
fill 390 217 599 391 217 599 minecraft:purple_terracotta
fill 391 217 557 392 217 557 minecraft:purple_concrete
setblock 392 217 599 minecraft:black_concrete
fill 394 217 557 395 218 557 minecraft:purple_terracotta
fill 394 217 562 394 217 563 minecraft:black_concrete
fill 395 217 561 395 218 562 minecraft:black_concrete
fill 395 217 564 395 218 564 minecraft:black_concrete
setblock 396 217 557 minecraft:black_concrete
fill 396 217 565 397 219 565 minecraft:black_concrete
setblock 396 217 599 minecraft:purple_terracotta
fill 397 217 557 397 219 557 minecraft:purple_terracotta
fill 397 217 560 397 219 560 minecraft:black_concrete
setblock 397 217 599 minecraft:black_concrete
setblock 398 217 557 minecraft:black_concrete
setblock 401 217 561 minecraft:purple_concrete
fill 401 217 562 401 217 563 minecraft:black_concrete
fill 401 217 564 401 217 565 minecraft:purple_concrete
fill 402 217 563 402 217 564 minecraft:purple_concrete
fill 402 217 599 402 219 599 minecraft:purple_terracotta
fill 403 217 557 403 219 557 minecraft:purple_terracotta
setblock 403 217 599 minecraft:black_concrete
setblock 404 217 557 minecraft:black_concrete
setblock 407 217 599 minecraft:purple_concrete
fill 408 217 557 408 219 557 minecraft:purple_terracotta
setblock 410 217 599 minecraft:purple_concrete
fill 411 217 599 411 219 599 minecraft:purple_terracotta
setblock 412 217 557 minecraft:purple_concrete
fill 415 217 599 415 219 599 minecraft:purple_terracotta
setblock 418 217 558 minecraft:black_concrete
setblock 418 217 559 minecraft:purple_concrete
setblock 418 217 561 minecraft:purple_terracotta
setblock 418 217 562 minecraft:purple_concrete
fill 418 217 566 418 219 566 minecraft:purple_terracotta
setblock 418 217 572 minecraft:purple_terracotta
setblock 418 217 573 minecraft:black_concrete
fill 418 217 576 418 218 576 minecraft:purple_terracotta
fill 418 217 577 418 217 578 minecraft:black_concrete
setblock 418 217 579 minecraft:purple_concrete
setblock 418 217 583 minecraft:purple_concrete
setblock 418 217 584 minecraft:black_concrete
fill 418 217 587 418 219 587 minecraft:purple_terracotta
setblock 418 217 589 minecraft:purple_terracotta
setblock 418 217 594 minecraft:purple_concrete
fill 418 217 595 418 219 595 minecraft:purple_terracotta
fill 418 217 598 418 219 598 minecraft:purple_terracotta
fill 376 218 557 376 219 558 minecraft:purple_terracotta
setblock 376 218 565 minecraft:black_concrete
fill 376 218 566 376 219 566 minecraft:purple_terracotta
fill 376 218 567 376 218 568 minecraft:purple_concrete
fill 376 218 569 376 219 570 minecraft:purple_terracotta
setblock 376 218 575 minecraft:purple_terracotta
fill 376 218 576 376 219 576 minecraft:purple_concrete
fill 376 218 577 376 219 578 minecraft:purple_terracotta
setblock 376 218 579 minecraft:purple_concrete
fill 376 218 581 376 219 583 minecraft:purple_terracotta
fill 376 218 587 376 219 588 minecraft:purple_concrete
fill 376 218 589 376 219 590 minecraft:purple_terracotta
fill 376 218 592 376 219 592 minecraft:purple_terracotta
setblock 376 218 593 minecraft:black_concrete
fill 376 218 598 376 219 598 minecraft:purple_terracotta
fill 376 218 599 377 218 599 minecraft:purple_concrete
fill 378 218 599 379 219 599 minecraft:purple_terracotta
fill 379 218 557 380 219 557 minecraft:purple_terracotta
fill 381 218 557 382 219 557 minecraft:purple_concrete
fill 384 218 599 385 219 599 minecraft:purple_concrete
fill 386 218 599 387 219 599 minecraft:purple_terracotta
fill 388 218 557 388 219 557 minecraft:purple_terracotta
setblock 388 218 599 minecraft:purple_concrete
fill 389 218 599 391 218 599 minecraft:black_concrete
setblock 390 218 557 minecraft:purple_concrete
fill 391 218 557 392 219 557 minecraft:purple_terracotta
fill 392 218 599 392 219 599 minecraft:purple_terracotta
fill 393 218 557 393 219 557 minecraft:purple_concrete
fill 393 218 562 394 223 563 minecraft:purple_concrete
setblock 393 218 564 minecraft:black_concrete
setblock 393 218 599 minecraft:black_concrete
setblock 394 218 561 minecraft:black_concrete
fill 394 218 564 394 223 564 minecraft:purple_concrete
fill 395 218 565 395 219 565 minecraft:black_concrete
fill 396 218 557 396 219 557 minecraft:purple_terracotta
fill 396 218 560 396 219 560 minecraft:black_concrete
fill 396 218 599 397 219 599 minecraft:purple_concrete
fill 398 218 557 400 219 557 minecraft:purple_terracotta
setblock 398 218 560 minecraft:black_concrete
fill 398 218 599 399 219 599 minecraft:purple_terracotta
fill 401 218 557 402 218 557 minecraft:purple_concrete
fill 401 218 562 401 218 564 minecraft:purple_concrete
fill 403 218 599 403 219 599 minecraft:purple_terracotta
fill 404 218 557 404 219 557 minecraft:purple_terracotta
fill 405 218 599 405 219 599 minecraft:purple_concrete
fill 407 218 599 407 219 599 minecraft:purple_terracotta
fill 408 218 599 409 218 599 minecraft:purple_concrete
fill 410 218 599 410 219 599 minecraft:purple_terracotta
fill 411 218 557 412 218 557 minecraft:black_concrete
fill 413 218 557 414 219 557 minecraft:purple_concrete
fill 416 218 599 417 219 599 minecraft:purple_concrete
fill 418 218 558 418 219 559 minecraft:purple_terracotta
fill 418 218 560 418 218 561 minecraft:purple_concrete
setblock 418 218 562 minecraft:black_concrete
fill 418 218 564 418 219 564 minecraft:purple_concrete
setblock 418 218 570 minecraft:black_concrete
fill 418 218 571 418 219 571 minecraft:purple_terracotta
fill 418 218 572 418 219 573 minecraft:purple_concrete
setblock 418 218 577 minecraft:black_concrete
fill 418 218 578 418 219 579 minecraft:purple_terracotta
setblock 418 218 581 minecraft:purple_concrete
fill 418 218 582 418 219 582 minecraft:purple_terracotta
setblock 418 218 583 minecraft:black_concrete
fill 418 218 584 418 219 585 minecraft:purple_concrete
setblock 418 218 589 minecraft:black_concrete
fill 418 218 590 418 219 591 minecraft:purple_terracotta
fill 418 218 592 418 218 593 minecraft:purple_concrete
fill 418 218 594 418 219 594 minecraft:purple_terracotta
setblock 418 218 599 minecraft:black_concrete
setblock 376 219 564 minecraft:purple_concrete
setblock 376 219 565 minecraft:purple_terracotta
setblock 376 219 567 minecraft:purple_concrete
setblock 376 219 568 minecraft:purple_terracotta
setblock 376 219 575 minecraft:purple_concrete
setblock 376 219 579 minecraft:purple_terracotta
setblock 376 219 593 minecraft:purple_terracotta
fill 376 219 595 376 219 596 minecraft:purple_concrete
setblock 376 219 599 minecraft:purple_concrete
setblock 377 219 599 minecraft:purple_terracotta
fill 383 219 582 384 220 582 minecraft:obsidian
fill 386 219 584 386 220 584 minecraft:amethyst_block
fill 388 219 599 391 219 599 minecraft:purple_terracotta
setblock 390 219 557 minecraft:purple_terracotta
fill 392 219 562 392 224 564 minecraft:purple_concrete
fill 393 219 561 395 222 561 minecraft:purple_concrete
fill 393 219 564 393 224 565 minecraft:purple_concrete
setblock 393 219 599 minecraft:purple_concrete
setblock 394 219 557 minecraft:purple_concrete
fill 394 219 565 394 223 565 minecraft:purple_concrete
setblock 395 219 557 minecraft:purple_terracotta
setblock 395 219 560 minecraft:black_concrete
fill 395 219 562 395 222 564 minecraft:purple_concrete
fill 396 219 563 396 222 563 minecraft:purple_concrete
setblock 398 219 565 minecraft:black_concrete
setblock 401 219 557 minecraft:purple_terracotta
setblock 402 219 557 minecraft:purple_concrete
setblock 404 219 599 minecraft:purple_concrete
setblock 405 219 557 minecraft:purple_concrete
fill 408 219 599 409 219 599 minecraft:purple_terracotta
fill 411 219 557 412 219 557 minecraft:purple_terracotta
fill 418 219 560 418 219 562 minecraft:purple_terracotta
setblock 418 219 565 minecraft:purple_concrete
setblock 418 219 570 minecraft:purple_terracotta
setblock 418 219 576 minecraft:purple_concrete
fill 418 219 577 418 220 577 minecraft:purple_terracotta
setblock 418 219 581 minecraft:purple_terracotta
setblock 418 219 583 minecraft:purple_terracotta
setblock 418 219 589 minecraft:purple_terracotta
setblock 418 219 592 minecraft:purple_terracotta
setblock 418 219 593 minecraft:purple_concrete
fill 418 219 596 418 219 597 minecraft:purple_concrete
setblock 418 219 599 minecraft:purple_terracotta
fill 376 220 557 376 221 560 minecraft:black_concrete
fill 376 220 562 376 221 562 minecraft:purple_concrete
fill 376 220 563 376 221 563 minecraft:black_concrete
setblock 376 220 564 minecraft:purple_terracotta
fill 376 220 565 376 220 566 minecraft:purple_concrete
fill 376 220 567 376 220 572 minecraft:black_concrete
fill 376 220 573 376 221 574 minecraft:purple_concrete
fill 376 220 575 376 220 584 minecraft:black_concrete
fill 376 220 585 376 220 586 minecraft:purple_concrete
fill 376 220 587 376 223 590 minecraft:black_concrete
fill 376 220 592 376 220 593 minecraft:black_concrete
fill 376 220 594 376 221 594 minecraft:purple_concrete
fill 376 220 595 376 225 596 minecraft:black_concrete
setblock 376 220 597 minecraft:purple_concrete
fill 376 220 598 376 220 599 minecraft:black_concrete
fill 377 220 557 382 221 557 minecraft:black_concrete
fill 377 220 599 381 221 599 minecraft:black_concrete
setblock 379 220 560 minecraft:light[level=12]
setblock 379 220 568 minecraft:light[level=12]
setblock 379 220 576 minecraft:light[level=12]
setblock 379 220 584 minecraft:light[level=12]
setblock 379 220 592 minecraft:light[level=12]
fill 382 220 599 383 221 599 minecraft:purple_concrete
fill 383 220 557 384 220 557 minecraft:purple_concrete
fill 384 220 599 393 220 599 minecraft:black_concrete
fill 385 220 557 386 221 557 minecraft:black_concrete
setblock 387 220 557 minecraft:purple_terracotta
setblock 387 220 560 minecraft:light[level=12]
setblock 387 220 568 minecraft:light[level=12]
setblock 387 220 576 minecraft:light[level=12]
setblock 387 220 584 minecraft:light[level=12]
setblock 387 220 592 minecraft:light[level=12]
fill 388 220 557 394 220 557 minecraft:black_concrete
fill 390 220 564 391 226 564 minecraft:purple_concrete
fill 391 220 562 391 225 563 minecraft:purple_concrete
fill 391 220 565 392 225 565 minecraft:purple_concrete
fill 392 220 561 392 223 561 minecraft:purple_concrete
fill 394 220 599 395 220 599 minecraft:purple_concrete
fill 395 220 557 396 221 557 minecraft:purple_concrete
setblock 395 220 560 minecraft:light[level=12]
fill 395 220 565 395 221 565 minecraft:purple_concrete
setblock 395 220 568 minecraft:light[level=12]
setblock 395 220 576 minecraft:light[level=12]
setblock 395 220 584 minecraft:light[level=12]
setblock 395 220 592 minecraft:light[level=12]
fill 396 220 561 396 221 561 minecraft:black_concrete
fill 396 220 562 396 221 562 minecraft:purple_concrete
fill 396 220 564 396 221 564 minecraft:purple_concrete
setblock 396 220 565 minecraft:black_concrete
fill 396 220 599 399 220 599 minecraft:black_concrete
fill 397 220 557 402 221 557 minecraft:black_concrete
fill 397 220 562 398 220 564 minecraft:black_concrete
setblock 398 220 561 minecraft:black_concrete
setblock 400 220 599 minecraft:purple_terracotta
fill 401 220 599 401 221 599 minecraft:black_concrete
fill 402 220 599 403 221 599 minecraft:purple_concrete
fill 403 220 557 404 220 557 minecraft:purple_concrete
setblock 403 220 560 minecraft:light[level=12]
setblock 403 220 568 minecraft:light[level=12]
setblock 403 220 576 minecraft:light[level=12]
setblock 403 220 584 minecraft:light[level=12]
setblock 403 220 592 minecraft:light[level=12]
fill 404 220 599 405 220 599 minecraft:black_concrete
fill 405 220 557 406 221 557 minecraft:black_concrete
setblock 406 220 599 minecraft:purple_concrete
fill 407 220 557 407 221 557 minecraft:purple_concrete
fill 407 220 599 412 220 599 minecraft:black_concrete
fill 408 220 557 411 220 557 minecraft:black_concrete
setblock 411 220 560 minecraft:light[level=12]
setblock 411 220 568 minecraft:light[level=12]
setblock 411 220 576 minecraft:light[level=12]
setblock 411 220 584 minecraft:light[level=12]
setblock 411 220 592 minecraft:light[level=12]
fill 412 220 557 412 221 557 minecraft:purple_terracotta
fill 413 220 557 414 225 557 minecraft:black_concrete
setblock 413 220 599 minecraft:purple_terracotta
fill 414 220 599 415 221 599 minecraft:purple_concrete
fill 415 220 557 416 221 557 minecraft:purple_concrete
fill 416 220 599 418 221 599 minecraft:black_concrete
fill 417 220 557 418 220 557 minecraft:black_concrete
setblock 418 220 558 minecraft:purple_terracotta
fill 418 220 559 418 220 562 minecraft:black_concrete
setblock 418 220 563 minecraft:purple_concrete
fill 418 220 564 418 225 564 minecraft:black_concrete
setblock 418 220 565 minecraft:purple_terracotta
fill 418 220 566 418 221 567 minecraft:purple_concrete
setblock 418 220 568 minecraft:purple_terracotta
fill 418 220 569 418 221 572 minecraft:black_concrete
fill 418 220 573 418 221 573 minecraft:purple_terracotta
fill 418 220 574 418 220 575 minecraft:purple_concrete
fill 418 220 576 418 225 576 minecraft:black_concrete
fill 418 220 578 418 220 585 minecraft:black_concrete
fill 418 220 586 418 221 587 minecraft:purple_concrete
fill 418 220 588 418 221 593 minecraft:black_concrete
fill 418 220 594 418 220 595 minecraft:purple_concrete
fill 418 220 596 418 221 597 minecraft:black_concrete
fill 418 220 598 418 221 598 minecraft:purple_concrete
setblock 376 221 561 minecraft:purple_concrete
fill 376 221 564 376 221 570 minecraft:black_concrete
setblock 376 221 571 minecraft:purple_terracotta
setblock 376 221 572 minecraft:black_concrete
fill 376 221 575 376 223 578 minecraft:black_concrete
setblock 376 221 579 minecraft:purple_terracotta
fill 376 221 580 376 221 581 minecraft:black_concrete
setblock 376 221 582 minecraft:purple_concrete
fill 376 221 583 376 221 584 minecraft:black_concrete
setblock 376 221 585 minecraft:purple_concrete
fill 376 221 586 376 224 586 minecraft:black_concrete
fill 376 221 591 376 221 592 minecraft:black_concrete
setblock 376 221 593 minecraft:purple_concrete
fill 376 221 597 376 223 598 minecraft:black_concrete
setblock 376 221 599 minecraft:purple_terracotta
setblock 383 221 557 minecraft:purple_terracotta
setblock 384 221 557 minecraft:purple_concrete
fill 384 221 599 387 223 599 minecraft:black_concrete
setblock 387 221 557 minecraft:purple_concrete
fill 388 221 557 390 221 557 minecraft:black_concrete
fill 388 221 599 389 221 599 minecraft:purple_terracotta
fill 389 221 564 389 227 564 minecraft:purple_concrete
fill 390 221 562 390 225 563 minecraft:purple_concrete
fill 390 221 565 390 227 565 minecraft:purple_concrete
fill 390 221 599 391 221 599 minecraft:purple_concrete
fill 391 221 557 392 221 557 minecraft:purple_terracotta
fill 391 221 566 393 222 566 minecraft:purple_concrete
fill 392 221 599 393 221 599 minecraft:black_concrete
fill 393 221 557 394 225 557 minecraft:black_concrete
setblock 394 221 599 minecraft:purple_concrete
fill 395 221 599 396 224 599 minecraft:black_concrete
fill 397 221 562 397 221 564 minecraft:black_concrete
setblock 397 221 599 minecraft:purple_terracotta
fill 398 221 599 400 221 599 minecraft:black_concrete
fill 403 221 557 404 221 557 minecraft:black_concrete
fill 404 221 599 405 221 599 minecraft:purple_terracotta
fill 406 221 599 410 221 599 minecraft:black_concrete
setblock 408 221 557 minecraft:purple_concrete
fill 409 221 557 411 221 557 minecraft:black_concrete
setblock 411 221 599 minecraft:purple_concrete
fill 412 221 599 413 221 599 minecraft:black_concrete
setblock 417 221 557 minecraft:black_concrete
setblock 418 221 557 minecraft:purple_terracotta
setblock 418 221 558 minecraft:purple_concrete
setblock 418 221 559 minecraft:black_concrete
setblock 418 221 560 minecraft:purple_terracotta
fill 418 221 561 418 222 563 minecraft:black_concrete
fill 418 221 565 418 225 565 minecraft:black_concrete
setblock 418 221 568 minecraft:black_concrete
setblock 418 221 574 minecraft:black_concrete
setblock 418 221 575 minecraft:purple_concrete
setblock 418 221 577 minecraft:black_concrete
fill 418 221 578 418 221 579 minecraft:purple_concrete
fill 418 221 580 418 221 585 minecraft:black_concrete
fill 418 221 594 418 223 595 minecraft:black_concrete
fill 376 222 557 376 223 558 minecraft:black_concrete
fill 376 222 559 376 223 560 minecraft:purple_concrete
fill 376 222 561 376 248 561 minecraft:black_concrete
setblock 376 222 562 minecraft:purple_terracotta
setblock 376 222 563 minecraft:purple_concrete
fill 376 222 564 376 222 565 minecraft:purple_terracotta
fill 376 222 566 376 222 570 minecraft:black_concrete
fill 376 222 571 376 223 572 minecraft:purple_concrete
fill 376 222 573 376 247 574 minecraft:black_concrete
setblock 376 222 579 minecraft:black_concrete
fill 376 222 580 376 223 580 minecraft:purple_concrete
fill 376 222 581 376 223 582 minecraft:black_concrete
fill 376 222 583 376 222 584 minecraft:purple_concrete
fill 376 222 585 376 247 585 minecraft:black_concrete
fill 376 222 591 376 223 592 minecraft:purple_concrete
fill 376 222 593 376 247 594 minecraft:black_concrete
fill 376 222 599 379 222 599 minecraft:black_concrete
fill 377 222 557 378 223 557 minecraft:purple_concrete
fill 377 222 558 379 222 558 minecraft:obsidian
fill 377 222 560 377 222 562 minecraft:obsidian
fill 377 222 564 377 222 566 minecraft:obsidian
fill 377 222 568 377 222 570 minecraft:obsidian
fill 377 222 572 377 222 574 minecraft:obsidian
fill 377 222 576 377 222 578 minecraft:obsidian
fill 377 222 580 377 222 582 minecraft:obsidian
fill 377 222 584 377 222 586 minecraft:obsidian
fill 377 222 588 377 222 590 minecraft:obsidian
fill 377 222 592 377 222 594 minecraft:obsidian
fill 377 222 596 377 222 598 minecraft:obsidian
fill 379 222 557 384 223 557 minecraft:black_concrete
fill 379 222 598 381 222 598 minecraft:obsidian
fill 380 222 599 381 222 599 minecraft:purple_concrete
fill 381 222 558 383 222 558 minecraft:obsidian
fill 382 222 599 383 247 599 minecraft:black_concrete
fill 383 222 598 385 222 598 minecraft:obsidian
fill 385 222 557 386 222 557 minecraft:purple_concrete
fill 385 222 558 387 222 558 minecraft:obsidian
fill 387 222 557 388 223 557 minecraft:black_concrete
fill 387 222 598 389 222 598 minecraft:obsidian
fill 388 222 564 388 227 565 minecraft:purple_concrete
setblock 388 222 599 minecraft:black_concrete
fill 389 222 557 389 223 557 minecraft:purple_concrete
fill 389 222 558 391 222 558 minecraft:obsidian
fill 389 222 563 389 226 563 minecraft:purple_concrete
fill 389 222 565 389 227 566 minecraft:purple_concrete
fill 389 222 599 389 223 599 minecraft:purple_concrete
fill 390 222 557 392 222 557 minecraft:black_concrete
fill 390 222 566 390 227 566 minecraft:purple_concrete
fill 390 222 599 391 247 599 minecraft:black_concrete
setblock 391 222 561 minecraft:purple_concrete
fill 391 222 598 393 222 598 minecraft:obsidian
setblock 392 222 599 minecraft:purple_concrete
fill 393 222 558 395 222 558 minecraft:obsidian
setblock 393 222 599 minecraft:purple_terracotta
fill 394 222 599 394 247 599 minecraft:black_concrete
fill 395 222 557 395 247 557 minecraft:black_concrete
fill 395 222 598 397 222 598 minecraft:obsidian
setblock 396 222 557 minecraft:purple_terracotta
setblock 396 222 562 minecraft:black_concrete
fill 397 222 557 398 223 557 minecraft:purple_concrete
fill 397 222 558 399 222 558 minecraft:obsidian
fill 397 222 599 397 225 599 minecraft:black_concrete
setblock 398 222 599 minecraft:purple_terracotta
fill 399 222 557 403 222 557 minecraft:black_concrete
fill 399 222 598 401 222 598 minecraft:obsidian
fill 399 222 599 399 223 599 minecraft:black_concrete
fill 400 222 599 401 223 599 minecraft:purple_concrete
fill 401 222 558 403 222 558 minecraft:obsidian
fill 402 222 599 406 223 599 minecraft:black_concrete
fill 403 222 598 405 222 598 minecraft:obsidian
setblock 404 222 557 minecraft:purple_terracotta
fill 405 222 557 405 225 557 minecraft:black_concrete
fill 405 222 558 407 222 558 minecraft:obsidian
setblock 406 222 557 minecraft:purple_concrete
fill 407 222 557 408 247 557 minecraft:black_concrete
fill 407 222 598 409 222 598 minecraft:obsidian
setblock 407 222 599 minecraft:purple_terracotta
setblock 408 222 599 minecraft:black_concrete
fill 409 222 557 410 223 557 minecraft:purple_concrete
fill 409 222 558 411 222 558 minecraft:obsidian
fill 409 222 599 409 223 599 minecraft:purple_concrete
fill 410 222 599 411 223 599 minecraft:black_concrete
fill 411 222 557 412 223 557 minecraft:black_concrete
fill 411 222 598 413 222 598 minecraft:obsidian
fill 412 222 599 413 222 599 minecraft:purple_concrete
fill 413 222 558 415 222 558 minecraft:obsidian
fill 414 222 599 417 224 599 minecraft:black_concrete
fill 415 222 557 416 247 557 minecraft:black_concrete
fill 415 222 598 417 222 598 minecraft:obsidian
fill 417 222 557 418 222 557 minecraft:purple_concrete
fill 417 222 558 417 222 560 minecraft:obsidian
fill 417 222 562 417 222 564 minecraft:obsidian
fill 417 222 566 417 222 568 minecraft:obsidian
fill 417 222 570 417 222 572 minecraft:obsidian
fill 417 222 574 417 222 576 minecraft:obsidian
fill 417 222 578 417 222 580 minecraft:obsidian
fill 417 222 582 417 222 584 minecraft:obsidian
fill 417 222 586 417 222 588 minecraft:obsidian
fill 417 222 590 417 222 592 minecraft:obsidian
fill 417 222 594 417 222 596 minecraft:obsidian
fill 418 222 558 418 248 558 minecraft:black_concrete
setblock 418 222 559 minecraft:purple_terracotta
setblock 418 222 560 minecraft:black_concrete
fill 418 222 566 418 247 567 minecraft:black_concrete
fill 418 222 568 418 223 569 minecraft:purple_concrete
fill 418 222 570 418 223 573 minecraft:black_concrete
setblock 418 222 574 minecraft:purple_terracotta
fill 418 222 575 418 247 575 minecraft:black_concrete
setblock 418 222 577 minecraft:purple_concrete
fill 418 222 578 418 248 579 minecraft:black_concrete
fill 418 222 580 418 223 580 minecraft:purple_concrete
fill 418 222 581 418 222 586 minecraft:black_concrete
setblock 418 222 587 minecraft:purple_terracotta
fill 418 222 588 418 223 589 minecraft:purple_concrete
fill 418 222 590 418 222 593 minecraft:black_concrete
fill 418 222 596 418 225 596 minecraft:black_concrete
setblock 418 222 597 minecraft:purple_concrete
fill 418 222 598 418 247 598 minecraft:black_concrete
setblock 418 222 599 minecraft:purple_terracotta
fill 376 223 562 376 224 567 minecraft:black_concrete
setblock 376 223 568 minecraft:purple_concrete
fill 376 223 569 376 223 570 minecraft:black_concrete
setblock 376 223 579 minecraft:purple_concrete
fill 376 223 583 376 226 584 minecraft:black_concrete
fill 376 223 599 376 225 599 minecraft:black_concrete
setblock 377 223 599 minecraft:purple_concrete
fill 378 223 599 379 223 599 minecraft:black_concrete
setblock 380 223 599 minecraft:purple_concrete
fill 381 223 599 381 226 599 minecraft:black_concrete
fill 385 223 557 386 226 557 minecraft:black_concrete
fill 387 223 564 387 225 566 minecraft:purple_concrete
fill 388 223 563 388 226 563 minecraft:purple_concrete
fill 388 223 566 388 226 567 minecraft:purple_concrete
setblock 388 223 599 minecraft:purple_concrete
fill 389 223 562 389 225 562 minecraft:purple_concrete
fill 389 223 567 390 226 567 minecraft:purple_concrete
setblock 390 223 557 minecraft:purple_concrete
fill 391 223 557 392 223 557 minecraft:black_concrete
fill 391 223 566 392 224 566 minecraft:purple_concrete
fill 392 223 599 393 225 599 minecraft:black_concrete
setblock 393 223 561 minecraft:purple_concrete
setblock 395 223 563 minecraft:purple_concrete
fill 396 223 557 396 247 557 minecraft:black_concrete
setblock 398 223 599 minecraft:black_concrete
fill 399 223 557 400 223 557 minecraft:black_concrete
setblock 401 223 557 minecraft:purple_concrete
fill 402 223 557 404 224 557 minecraft:black_concrete
fill 406 223 557 406 226 557 minecraft:black_concrete
setblock 407 223 599 minecraft:black_concrete
setblock 408 223 599 minecraft:purple_concrete
setblock 412 223 599 minecraft:purple_concrete
fill 413 223 599 413 226 599 minecraft:black_concrete
fill 417 223 557 417 226 557 minecraft:black_concrete
setblock 418 223 557 minecraft:purple_concrete
setblock 418 223 559 minecraft:black_concrete
fill 418 223 560 418 223 561 minecraft:purple_concrete
fill 418 223 562 418 223 563 minecraft:black_concrete
fill 418 223 574 418 224 574 minecraft:black_concrete
fill 418 223 577 418 226 577 minecraft:black_concrete
setblock 418 223 581 minecraft:purple_concrete
fill 418 223 582 418 223 587 minecraft:black_concrete
fill 418 223 590 418 223 591 minecraft:black_concrete
setblock 418 223 592 minecraft:purple_concrete
fill 418 223 593 418 225 593 minecraft:black_concrete
fill 418 223 597 418 225 597 minecraft:black_concrete
setblock 418 223 599 minecraft:black_concrete
fill 376 224 557 376 225 558 minecraft:purple_concrete
fill 376 224 559 376 249 560 minecraft:black_concrete
fill 376 224 568 376 250 568 minecraft:black_concrete
fill 376 224 569 376 224 570 minecraft:purple_concrete
fill 376 224 571 376 249 572 minecraft:black_concrete
fill 376 224 575 376 225 576 minecraft:black_concrete
fill 376 224 577 376 225 578 minecraft:purple_concrete
fill 376 224 579 376 249 580 minecraft:black_concrete
setblock 376 224 581 minecraft:purple_concrete
fill 376 224 582 376 248 582 minecraft:black_concrete
fill 376 224 587 376 225 588 minecraft:black_concrete
fill 376 224 589 376 225 590 minecraft:purple_concrete
fill 376 224 591 376 249 592 minecraft:black_concrete
setblock 376 224 597 minecraft:black_concrete
fill 376 224 598 376 225 598 minecraft:purple_concrete
fill 377 224 557 378 249 557 minecraft:black_concrete
fill 377 224 599 377 250 599 minecraft:black_concrete
fill 378 224 599 379 224 599 minecraft:purple_concrete
fill 379 224 557 380 225 557 minecraft:purple_concrete
fill 380 224 599 380 249 599 minecraft:black_concrete
fill 381 224 557 384 224 557 minecraft:black_concrete
fill 384 224 599 385 225 599 minecraft:black_concrete
fill 386 224 565 386 224 567 minecraft:purple_concrete
fill 386 224 599 387 225 599 minecraft:purple_concrete
fill 387 224 557 387 248 557 minecraft:black_concrete
fill 387 224 563 387 225 563 minecraft:purple_concrete
fill 387 224 567 387 225 567 minecraft:purple_concrete
setblock 388 224 557 minecraft:purple_concrete
fill 388 224 599 389 249 599 minecraft:black_concrete
fill 389 224 557 390 249 557 minecraft:black_concrete
fill 391 224 557 392 225 557 minecraft:purple_concrete
fill 393 224 562 393 224 563 minecraft:purple_concrete
fill 394 224 562 394 226 563 minecraft:amethyst_block
fill 397 224 557 398 249 557 minecraft:black_concrete
fill 398 224 599 399 224 599 minecraft:purple_concrete
fill 399 224 557 400 224 557 minecraft:purple_concrete
fill 400 224 599 405 225 599 minecraft:black_concrete
fill 401 224 557 401 250 557 minecraft:black_concrete
fill 406 224 599 407 225 599 minecraft:purple_concrete
fill 408 224 599 409 249 599 minecraft:black_concrete
fill 409 224 557 410 249 557 minecraft:black_concrete
setblock 410 224 599 minecraft:purple_concrete
fill 411 224 557 412 225 557 minecraft:purple_concrete
fill 411 224 599 412 226 599 minecraft:black_concrete
fill 418 224 557 418 249 557 minecraft:black_concrete
setblock 418 224 559 minecraft:purple_concrete
fill 418 224 560 418 250 561 minecraft:black_concrete
fill 418 224 562 418 225 562 minecraft:purple_concrete
setblock 418 224 563 minecraft:black_concrete
fill 418 224 568 418 249 569 minecraft:black_concrete
fill 418 224 570 418 224 571 minecraft:purple_concrete
fill 418 224 572 418 225 573 minecraft:black_concrete
fill 418 224 580 418 249 581 minecraft:black_concrete
fill 418 224 582 418 225 583 minecraft:purple_concrete
fill 418 224 584 418 225 589 minecraft:black_concrete
fill 418 224 590 418 224 591 minecraft:purple_concrete
fill 418 224 592 418 250 592 minecraft:black_concrete
fill 418 224 594 418 225 594 minecraft:purple_concrete
setblock 418 224 595 minecraft:black_concrete
fill 418 224 599 418 225 599 minecraft:purple_concrete
fill 376 225 562 376 225 564 minecraft:black_concrete
fill 376 225 565 376 225 566 minecraft:purple_concrete
setblock 376 225 567 minecraft:black_concrete
setblock 376 225 569 minecraft:purple_concrete
fill 376 225 570 376 251 570 minecraft:black_concrete
fill 376 225 581 376 251 581 minecraft:black_concrete
setblock 376 225 586 minecraft:purple_concrete
setblock 376 225 597 minecraft:purple_concrete
fill 378 225 599 379 248 599 minecraft:black_concrete
fill 381 225 557 382 225 557 minecraft:black_concrete
setblock 383 225 557 minecraft:purple_concrete
fill 384 225 557 384 247 557 minecraft:black_concrete
fill 385 225 566 385 225 568 minecraft:purple_concrete
fill 386 225 564 386 225 566 minecraft:purple_concrete
fill 386 225 567 386 227 568 minecraft:black_concrete
fill 387 225 568 389 225 568 minecraft:purple_concrete
fill 388 225 557 388 251 557 minecraft:black_concrete
fill 391 225 566 391 226 566 minecraft:purple_concrete
fill 392 225 563 392 225 564 minecraft:purple_concrete
fill 393 225 563 393 227 563 minecraft:amethyst_block
setblock 395 225 599 minecraft:purple_concrete
setblock 396 225 599 minecraft:black_concrete
setblock 398 225 599 minecraft:purple_concrete
fill 399 225 557 399 251 557 minecraft:black_concrete
fill 399 225 599 399 251 599 minecraft:black_concrete
setblock 400 225 557 minecraft:purple_concrete
setblock 402 225 557 minecraft:black_concrete
fill 403 225 557 404 225 557 minecraft:purple_concrete
fill 410 225 599 410 251 599 minecraft:black_concrete
fill 414 225 599 414 247 599 minecraft:black_concrete
setblock 415 225 599 minecraft:purple_concrete
fill 416 225 599 417 225 599 minecraft:black_concrete
fill 418 225 559 418 251 559 minecraft:black_concrete
setblock 418 225 563 minecraft:purple_concrete
fill 418 225 570 418 251 570 minecraft:black_concrete
setblock 418 225 571 minecraft:purple_concrete
setblock 418 225 574 minecraft:purple_concrete
fill 418 225 590 418 251 590 minecraft:black_concrete
setblock 418 225 591 minecraft:purple_concrete
setblock 418 225 595 minecraft:purple_concrete
fill 376 226 557 376 251 558 minecraft:black_concrete
fill 376 226 562 376 226 563 minecraft:black_concrete
fill 376 226 564 376 227 564 minecraft:purple_concrete
fill 376 226 565 376 247 566 minecraft:black_concrete
setblock 376 226 567 minecraft:purple_concrete
fill 376 226 569 376 251 569 minecraft:black_concrete
fill 376 226 575 376 227 576 minecraft:purple_concrete
fill 376 226 577 376 251 578 minecraft:black_concrete
fill 376 226 586 376 247 586 minecraft:black_concrete
fill 376 226 587 376 226 588 minecraft:purple_concrete
fill 376 226 589 376 251 590 minecraft:black_concrete
fill 376 226 595 376 227 596 minecraft:purple_concrete
fill 376 226 597 376 247 598 minecraft:black_concrete
setblock 376 226 599 minecraft:purple_concrete
fill 379 226 557 380 251 557 minecraft:black_concrete
fill 381 226 557 382 226 557 minecraft:purple_concrete
fill 383 226 557 383 247 557 minecraft:black_concrete
fill 384 226 566 385 227 568 minecraft:black_concrete
fill 384 226 599 385 227 599 minecraft:purple_concrete
fill 385 226 565 387 226 565 minecraft:purple_concrete
fill 385 226 569 387 227 569 minecraft:black_concrete
fill 386 226 564 387 227 564 minecraft:purple_concrete
fill 386 226 566 387 227 566 minecraft:black_concrete
fill 386 226 599 387 251 599 minecraft:black_concrete
fill 387 226 567 387 227 568 minecraft:black_concrete
fill 388 226 568 389 226 568 minecraft:purple_concrete
setblock 390 226 563 minecraft:purple_concrete
fill 391 226 557 392 251 557 minecraft:black_concrete
setblock 391 226 565 minecraft:purple_concrete
setblock 392 226 599 minecraft:black_concrete
fill 393 226 557 394 227 557 minecraft:purple_concrete
fill 393 226 599 393 227 599 minecraft:purple_concrete
fill 395 226 599 395 247 599 minecraft:black_concrete
fill 396 226 599 397 226 599 minecraft:purple_concrete
fill 398 226 599 398 251 599 minecraft:black_concrete
fill 400 226 557 400 251 557 minecraft:black_concrete
fill 400 226 599 403 247 599 minecraft:black_concrete
setblock 402 226 557 minecraft:purple_concrete
fill 403 226 557 404 247 557 minecraft:black_concrete
fill 404 226 599 405 227 599 minecraft:purple_concrete
fill 405 226 557 405 227 557 minecraft:purple_concrete
fill 406 226 599 407 251 599 minecraft:black_concrete
fill 411 226 557 412 251 557 minecraft:black_concrete
fill 413 226 557 414 226 557 minecraft:purple_concrete
fill 415 226 599 415 247 599 minecraft:black_concrete
fill 416 226 599 417 226 599 minecraft:purple_concrete
fill 418 226 562 418 247 563 minecraft:black_concrete
fill 418 226 564 418 227 565 minecraft:purple_concrete
fill 418 226 571 418 251 571 minecraft:black_concrete
fill 418 226 572 418 226 573 minecraft:purple_concrete
fill 418 226 574 418 247 574 minecraft:black_concrete
fill 418 226 576 418 227 576 minecraft:purple_concrete
fill 418 226 582 418 251 583 minecraft:black_concrete
fill 418 226 584 418 227 585 minecraft:purple_concrete
fill 418 226 586 418 226 589 minecraft:black_concrete
fill 418 226 591 418 251 591 minecraft:black_concrete
setblock 418 226 593 minecraft:purple_concrete
fill 418 226 594 418 247 595 minecraft:black_concrete
fill 418 226 596 418 227 597 minecraft:purple_concrete
fill 418 226 599 418 251 599 minecraft:black_concrete
fill 376 227 562 376 247 562 minecraft:black_concrete
setblock 376 227 563 minecraft:purple_concrete
fill 376 227 567 376 246 567 minecraft:black_concrete
fill 376 227 583 376 227 584 minecraft:purple_concrete
setblock 376 227 587 minecraft:purple_concrete
fill 376 227 588 376 246 588 minecraft:black_concrete
fill 376 227 599 376 246 599 minecraft:black_concrete
fill 381 227 557 381 246 557 minecraft:black_concrete
setblock 381 227 599 minecraft:purple_concrete
setblock 382 227 557 minecraft:purple_concrete
fill 383 227 567 383 227 569 minecraft:black_concrete
fill 384 227 569 384 227 570 minecraft:black_concrete
fill 385 227 557 386 227 557 minecraft:purple_concrete
fill 385 227 565 387 227 565 minecraft:black_concrete
fill 385 227 570 386 227 570 minecraft:black_concrete
fill 388 227 566 388 227 568 minecraft:black_concrete
setblock 388 227 569 minecraft:purple_concrete
fill 389 227 567 389 227 568 minecraft:purple_concrete
setblock 390 227 564 minecraft:purple_concrete
setblock 392 227 599 minecraft:purple_concrete
setblock 394 227 563 minecraft:amethyst_block
fill 396 227 599 397 246 599 minecraft:black_concrete
fill 402 227 557 402 246 557 minecraft:black_concrete
setblock 406 227 557 minecraft:purple_concrete
fill 411 227 599 411 248 599 minecraft:black_concrete
fill 412 227 599 413 227 599 minecraft:purple_concrete
fill 413 227 557 413 246 557 minecraft:black_concrete
setblock 414 227 557 minecraft:purple_concrete
setblock 416 227 599 minecraft:purple_concrete
setblock 417 227 557 minecraft:purple_concrete
fill 417 227 599 417 246 599 minecraft:black_concrete
fill 418 227 572 418 246 573 minecraft:black_concrete
setblock 418 227 577 minecraft:purple_concrete
fill 418 227 586 418 247 587 minecraft:black_concrete
setblock 418 227 588 minecraft:purple_concrete
fill 418 227 589 418 249 589 minecraft:black_concrete
fill 418 227 593 418 246 593 minecraft:black_concrete
fill 376 228 563 376 246 564 minecraft:black_concrete
fill 376 228 575 376 246 576 minecraft:black_concrete
fill 376 228 583 376 249 584 minecraft:black_concrete
fill 376 228 587 376 246 587 minecraft:black_concrete
fill 376 228 595 376 246 596 minecraft:black_concrete
setblock 379 228 560 minecraft:light[level=12]
setblock 379 228 568 minecraft:light[level=12]
setblock 379 228 576 minecraft:light[level=12]
setblock 379 228 584 minecraft:light[level=12]
setblock 379 228 592 minecraft:light[level=12]
fill 381 228 599 381 249 599 minecraft:black_concrete
fill 382 228 557 382 246 557 minecraft:black_concrete
fill 384 228 599 385 246 599 minecraft:black_concrete
fill 385 228 557 386 249 557 minecraft:black_concrete
setblock 387 228 560 minecraft:light[level=12]
setblock 387 228 568 minecraft:light[level=12]
setblock 387 228 576 minecraft:light[level=12]
setblock 387 228 584 minecraft:light[level=12]
setblock 387 228 592 minecraft:light[level=12]
fill 392 228 599 393 246 599 minecraft:black_concrete
fill 393 228 557 394 246 557 minecraft:black_concrete
setblock 395 228 560 minecraft:light[level=12]
setblock 395 228 568 minecraft:light[level=12]
setblock 395 228 576 minecraft:light[level=12]
setblock 395 228 584 minecraft:light[level=12]
setblock 395 228 592 minecraft:light[level=12]
setblock 403 228 560 minecraft:light[level=12]
setblock 403 228 568 minecraft:light[level=12]
setblock 403 228 576 minecraft:light[level=12]
setblock 403 228 584 minecraft:light[level=12]
setblock 403 228 592 minecraft:light[level=12]
fill 404 228 599 405 246 599 minecraft:black_concrete
fill 405 228 557 406 246 557 minecraft:black_concrete
setblock 411 228 560 minecraft:light[level=12]
setblock 411 228 568 minecraft:light[level=12]
setblock 411 228 576 minecraft:light[level=12]
setblock 411 228 584 minecraft:light[level=12]
setblock 411 228 592 minecraft:light[level=12]
fill 412 228 599 413 249 599 minecraft:black_concrete
fill 414 228 557 414 246 557 minecraft:black_concrete
fill 416 228 599 416 246 599 minecraft:black_concrete
fill 417 228 557 417 249 557 minecraft:black_concrete
fill 418 228 564 418 246 565 minecraft:black_concrete
fill 418 228 576 418 246 577 minecraft:black_concrete
fill 418 228 584 418 246 585 minecraft:black_concrete
fill 418 228 588 418 249 588 minecraft:black_concrete
fill 418 228 596 418 246 597 minecraft:black_concrete
fill 377 233 559 394 234 597 minecraft:black_concrete
fill 378 233 558 416 234 558 minecraft:black_concrete
fill 378 233 598 416 234 598 minecraft:black_concrete
fill 395 233 559 395 241 573 minecraft:black_concrete
fill 395 233 575 395 241 597 minecraft:black_concrete
fill 396 233 559 396 241 572 minecraft:black_concrete
fill 396 233 576 396 241 597 minecraft:black_concrete
fill 397 233 559 417 234 571 minecraft:black_concrete
fill 397 233 577 417 234 597 minecraft:black_concrete
fill 398 233 572 417 241 572 minecraft:black_concrete
fill 398 233 576 417 241 576 minecraft:black_concrete
fill 399 233 573 417 241 573 minecraft:black_concrete
fill 399 233 575 417 241 575 minecraft:black_concrete
fill 400 233 574 417 242 574 minecraft:black_concrete
fill 377 235 560 394 236 596 minecraft:black_concrete
fill 378 235 559 394 236 559 minecraft:black_concrete
fill 378 235 597 394 236 597 minecraft:black_concrete
fill 379 235 558 415 236 558 minecraft:black_concrete
fill 379 235 598 415 236 598 minecraft:black_concrete
fill 397 235 559 416 236 571 minecraft:black_concrete
fill 397 235 577 416 236 597 minecraft:black_concrete
fill 417 235 560 417 236 571 minecraft:black_concrete
fill 417 235 577 417 236 596 minecraft:black_concrete
fill 377 237 561 394 238 595 minecraft:black_concrete
fill 378 237 560 394 238 560 minecraft:black_concrete
fill 378 237 596 394 238 596 minecraft:black_concrete
fill 379 237 559 394 238 559 minecraft:black_concrete
fill 379 237 597 394 238 597 minecraft:black_concrete
fill 380 237 558 414 238 558 minecraft:black_concrete
fill 380 237 598 414 238 598 minecraft:black_concrete
fill 397 237 559 415 238 571 minecraft:black_concrete
fill 397 237 577 415 238 597 minecraft:black_concrete
fill 416 237 560 416 238 571 minecraft:black_concrete
fill 416 237 577 416 238 596 minecraft:black_concrete
fill 417 237 561 417 238 571 minecraft:black_concrete
fill 417 237 577 417 238 595 minecraft:black_concrete
fill 377 239 562 394 239 594 minecraft:black_concrete
fill 378 239 561 394 240 561 minecraft:black_concrete
fill 378 239 595 394 240 595 minecraft:black_concrete
fill 379 239 560 394 240 560 minecraft:black_concrete
fill 379 239 596 394 240 596 minecraft:black_concrete
fill 380 239 559 394 240 559 minecraft:black_concrete
fill 380 239 597 394 240 597 minecraft:black_concrete
fill 381 239 558 413 239 558 minecraft:black_concrete
fill 381 239 598 413 239 598 minecraft:black_concrete
fill 397 239 559 414 240 571 minecraft:black_concrete
fill 397 239 577 414 240 597 minecraft:black_concrete
fill 415 239 560 415 240 571 minecraft:black_concrete
fill 415 239 577 415 240 596 minecraft:black_concrete
fill 416 239 561 416 240 571 minecraft:black_concrete
fill 416 239 577 416 240 595 minecraft:black_concrete
fill 417 239 562 417 239 571 minecraft:black_concrete
fill 417 239 577 417 239 594 minecraft:black_concrete
fill 377 240 563 394 241 593 minecraft:black_concrete
fill 378 240 562 394 241 562 minecraft:black_concrete
fill 378 240 594 394 241 594 minecraft:black_concrete
fill 382 240 558 412 241 558 minecraft:black_concrete
fill 382 240 598 412 241 598 minecraft:black_concrete
fill 417 240 563 417 241 571 minecraft:black_concrete
fill 417 240 577 417 241 593 minecraft:black_concrete
fill 379 241 561 394 241 561 minecraft:black_concrete
fill 379 241 595 394 241 595 minecraft:black_concrete
fill 380 241 560 394 241 560 minecraft:black_concrete
fill 380 241 596 394 241 596 minecraft:black_concrete
fill 381 241 559 394 241 559 minecraft:black_concrete
fill 381 241 597 394 241 597 minecraft:black_concrete
fill 397 241 559 413 241 571 minecraft:black_concrete
fill 397 241 577 413 241 597 minecraft:black_concrete
fill 414 241 560 414 241 571 minecraft:black_concrete
fill 414 241 577 414 241 596 minecraft:black_concrete
fill 415 241 561 415 241 571 minecraft:black_concrete
fill 415 241 577 415 241 595 minecraft:black_concrete
fill 416 241 562 416 241 571 minecraft:black_concrete
fill 416 241 577 416 241 594 minecraft:black_concrete
fill 377 242 564 394 242 592 minecraft:black_concrete
fill 378 242 563 416 242 563 minecraft:black_concrete
fill 378 242 593 416 242 593 minecraft:black_concrete
fill 379 242 562 415 243 562 minecraft:black_concrete
fill 379 242 594 415 243 594 minecraft:black_concrete
fill 380 242 561 414 243 561 minecraft:black_concrete
fill 380 242 595 414 243 595 minecraft:black_concrete
fill 381 242 560 413 243 560 minecraft:black_concrete
fill 381 242 596 413 243 596 minecraft:black_concrete
fill 382 242 559 412 242 559 minecraft:black_concrete
fill 382 242 597 412 242 597 minecraft:black_concrete
fill 383 242 558 411 242 558 minecraft:black_concrete
fill 383 242 598 411 242 598 minecraft:black_concrete
fill 395 242 564 395 242 572 minecraft:black_concrete
setblock 395 242 573 minecraft:purple_concrete
setblock 395 242 575 minecraft:purple_concrete
fill 395 242 576 395 242 592 minecraft:black_concrete
fill 396 242 564 417 242 571 minecraft:black_concrete
setblock 396 242 572 minecraft:purple_concrete
setblock 396 242 576 minecraft:purple_concrete
fill 396 242 577 417 242 592 minecraft:black_concrete
setblock 398 242 572 minecraft:purple_concrete
setblock 398 242 576 minecraft:purple_concrete
fill 399 242 572 417 242 572 minecraft:black_concrete
setblock 399 242 573 minecraft:purple_concrete
setblock 399 242 575 minecraft:purple_concrete
fill 399 242 576 417 242 576 minecraft:black_concrete
fill 400 242 573 417 242 573 minecraft:black_concrete
fill 400 242 575 417 242 575 minecraft:black_concrete
fill 377 243 558 377 243 564 minecraft:obsidian
fill 377 243 565 393 243 591 minecraft:black_concrete
fill 377 243 592 377 243 598 minecraft:obsidian
fill 378 243 558 378 243 563 minecraft:obsidian
fill 378 243 564 416 244 564 minecraft:black_concrete
fill 378 243 592 416 244 592 minecraft:black_concrete
fill 378 243 593 378 243 598 minecraft:obsidian
fill 379 243 558 379 243 561 minecraft:obsidian
fill 379 243 563 415 244 563 minecraft:black_concrete
fill 379 243 593 415 244 593 minecraft:black_concrete
fill 379 243 595 379 243 598 minecraft:obsidian
fill 380 243 558 380 243 560 minecraft:obsidian
fill 380 243 596 380 243 598 minecraft:obsidian
fill 381 243 558 382 243 559 minecraft:obsidian
fill 381 243 597 382 243 598 minecraft:obsidian
setblock 383 243 558 minecraft:obsidian
fill 383 243 559 411 244 559 minecraft:black_concrete
fill 383 243 597 411 244 597 minecraft:black_concrete
setblock 383 243 598 minecraft:obsidian
fill 384 243 558 410 243 558 minecraft:black_concrete
fill 384 243 598 410 243 598 minecraft:black_concrete
fill 394 243 565 394 243 572 minecraft:black_concrete
setblock 394 243 573 minecraft:red_nether_bricks
fill 394 243 574 394 245 574 minecraft:quartz_block
setblock 394 243 575 minecraft:red_nether_bricks
setblock 394 243 576 minecraft:crying_obsidian
fill 394 243 577 394 243 591 minecraft:black_concrete
fill 395 243 565 395 243 571 minecraft:black_concrete
fill 395 243 572 395 243 573 minecraft:shroomlight
fill 395 243 575 395 243 576 minecraft:shroomlight
fill 395 243 577 396 243 577 minecraft:crying_obsidian
fill 395 243 578 395 243 591 minecraft:black_concrete
fill 396 243 565 417 243 570 minecraft:black_concrete
setblock 396 243 571 minecraft:crying_obsidian
setblock 396 243 572 minecraft:shroomlight
setblock 396 243 576 minecraft:shroomlight
fill 396 243 578 398 243 578 minecraft:crying_obsidian
fill 396 243 579 417 243 591 minecraft:black_concrete
fill 397 243 571 397 245 571 minecraft:quartz_block
fill 397 243 577 397 245 577 minecraft:quartz_block
setblock 398 243 571 minecraft:crying_obsidian
fill 398 243 572 399 243 572 minecraft:shroomlight
fill 398 243 576 399 243 576 minecraft:shroomlight
fill 398 243 577 399 243 577 minecraft:crying_obsidian
fill 399 243 571 417 243 571 minecraft:black_concrete
setblock 399 243 573 minecraft:shroomlight
setblock 399 243 575 minecraft:shroomlight
fill 399 243 578 417 243 578 minecraft:black_concrete
fill 400 243 572 417 243 572 minecraft:black_concrete
setblock 400 243 573 minecraft:red_nether_bricks
fill 400 243 574 400 245 574 minecraft:quartz_block
setblock 400 243 575 minecraft:red_nether_bricks
setblock 400 243 576 minecraft:crying_obsidian
fill 400 243 577 417 243 577 minecraft:black_concrete
fill 401 243 573 417 243 576 minecraft:black_concrete
fill 411 243 558 417 243 558 minecraft:obsidian
fill 411 243 598 417 243 598 minecraft:obsidian
fill 412 243 559 417 243 559 minecraft:obsidian
fill 412 243 597 417 243 597 minecraft:obsidian
fill 414 243 560 417 243 560 minecraft:obsidian
fill 414 243 596 417 243 596 minecraft:obsidian
fill 415 243 561 417 243 561 minecraft:obsidian
fill 415 243 595 417 243 595 minecraft:obsidian
fill 416 243 562 417 243 563 minecraft:obsidian
fill 416 243 593 417 243 594 minecraft:obsidian
setblock 417 243 564 minecraft:obsidian
setblock 417 243 592 minecraft:obsidian
fill 377 244 566 390 244 590 minecraft:black_concrete
fill 378 244 565 416 245 565 minecraft:black_concrete
fill 378 244 591 416 245 591 minecraft:black_concrete
setblock 379 244 560 minecraft:light[level=12]
fill 380 244 562 414 244 562 minecraft:black_concrete
fill 380 244 594 414 244 594 minecraft:black_concrete
fill 381 244 561 413 244 561 minecraft:black_concrete
fill 381 244 595 413 244 595 minecraft:black_concrete
fill 382 244 560 412 244 560 minecraft:black_concrete
fill 382 244 596 412 244 596 minecraft:black_concrete
fill 385 244 558 409 244 558 minecraft:black_concrete
fill 385 244 598 409 244 598 minecraft:black_concrete
fill 391 244 566 391 244 573 minecraft:black_concrete
fill 391 244 574 393 244 574 minecraft:red_nether_bricks
fill 391 244 575 391 244 590 minecraft:black_concrete
fill 392 244 566 392 244 571 minecraft:black_concrete
fill 392 244 572 393 244 573 minecraft:red_nether_bricks
fill 392 244 575 393 244 576 minecraft:red_nether_bricks
fill 392 244 577 392 244 590 minecraft:black_concrete
fill 393 244 566 393 244 570 minecraft:black_concrete
fill 393 244 571 394 246 571 minecraft:red_nether_bricks
fill 393 244 577 394 246 577 minecraft:red_nether_bricks
fill 393 244 578 393 244 590 minecraft:black_concrete
fill 394 244 566 417 244 569 minecraft:black_concrete
fill 394 244 570 400 244 570 minecraft:red_nether_bricks
fill 394 244 572 394 245 573 minecraft:quartz_block
fill 394 244 575 394 245 576 minecraft:quartz_block
fill 394 244 578 400 244 578 minecraft:red_nether_bricks
fill 394 244 579 394 244 590 minecraft:black_concrete
fill 395 244 571 396 245 571 minecraft:quartz_block
setblock 395 244 572 minecraft:red_nether_bricks
setblock 395 244 576 minecraft:red_nether_bricks
fill 395 244 577 396 245 577 minecraft:quartz_block
fill 395 244 579 399 244 579 minecraft:purple_concrete
fill 395 244 580 417 244 590 minecraft:black_concrete
fill 398 244 571 399 245 571 minecraft:quartz_block
fill 398 244 577 399 245 577 minecraft:quartz_block
setblock 399 244 572 minecraft:red_nether_bricks
setblock 399 244 576 minecraft:red_nether_bricks
fill 400 244 571 401 249 571 minecraft:red_nether_bricks
fill 400 244 572 400 245 573 minecraft:quartz_block
fill 400 244 575 400 245 576 minecraft:quartz_block
fill 400 244 577 401 249 577 minecraft:red_nether_bricks
fill 400 244 579 417 244 579 minecraft:black_concrete
fill 401 244 570 417 244 570 minecraft:black_concrete
fill 401 244 572 402 244 576 minecraft:red_nether_bricks
fill 401 244 578 417 244 578 minecraft:black_concrete
fill 402 244 571 417 244 571 minecraft:black_concrete
fill 402 244 577 417 244 577 minecraft:black_concrete
fill 403 244 572 417 244 573 minecraft:black_concrete
fill 403 244 574 403 255 574 minecraft:red_nether_bricks
fill 403 244 575 417 244 576 minecraft:black_concrete
fill 404 244 574 417 244 574 minecraft:black_concrete
fill 377 245 567 385 245 589 minecraft:black_concrete
fill 378 245 566 416 246 566 minecraft:black_concrete
fill 378 245 590 416 246 590 minecraft:black_concrete
fill 379 245 564 415 245 564 minecraft:black_concrete
fill 379 245 592 415 245 592 minecraft:black_concrete
fill 380 245 563 414 245 563 minecraft:black_concrete
fill 380 245 593 414 245 593 minecraft:black_concrete
fill 381 245 562 413 245 562 minecraft:black_concrete
fill 381 245 594 413 245 594 minecraft:black_concrete
fill 382 245 561 412 245 561 minecraft:black_concrete
fill 382 245 595 412 245 595 minecraft:black_concrete
fill 383 245 560 411 245 560 minecraft:black_concrete
fill 383 245 596 411 245 596 minecraft:black_concrete
fill 384 245 559 410 245 559 minecraft:black_concrete
fill 384 245 597 410 245 597 minecraft:black_concrete
fill 386 245 558 408 245 558 minecraft:black_concrete
fill 386 245 567 386 245 572 minecraft:black_concrete
fill 386 245 573 392 251 575 minecraft:nether_bricks
fill 386 245 576 386 245 589 minecraft:black_concrete
fill 386 245 598 408 245 598 minecraft:black_concrete
fill 387 245 567 390 245 571 minecraft:black_concrete
fill 387 245 572 391 251 572 minecraft:nether_bricks
fill 387 245 576 391 251 576 minecraft:nether_bricks
fill 387 245 577 390 245 589 minecraft:black_concrete
fill 391 245 567 391 245 570 minecraft:black_concrete
fill 391 245 571 392 245 571 minecraft:red_nether_bricks
fill 391 245 577 392 245 577 minecraft:red_nether_bricks
fill 391 245 578 391 245 589 minecraft:black_concrete
fill 392 245 567 392 245 569 minecraft:black_concrete
fill 392 245 570 394 252 570 minecraft:red_nether_bricks
setblock 392 245 572 minecraft:red_nether_bricks
setblock 392 245 576 minecraft:red_nether_bricks
fill 392 245 578 394 252 578 minecraft:red_nether_bricks
fill 392 245 579 392 245 589 minecraft:black_concrete
fill 393 245 567 395 245 568 minecraft:black_concrete
fill 393 245 569 401 252 569 minecraft:red_nether_bricks
setblock 393 245 572 minecraft:quartz_block
setblock 393 245 573 minecraft:red_nether_bricks
setblock 393 245 574 minecraft:quartz_block
setblock 393 245 575 minecraft:red_nether_bricks
setblock 393 245 576 minecraft:quartz_block
fill 393 245 579 401 252 579 minecraft:red_nether_bricks
fill 393 245 580 393 245 589 minecraft:black_concrete
fill 394 245 580 395 245 580 minecraft:purple_concrete
fill 394 245 581 417 245 589 minecraft:black_concrete
setblock 395 245 570 minecraft:quartz_block
setblock 395 245 578 minecraft:quartz_block
fill 396 245 567 417 245 567 minecraft:black_concrete
fill 396 245 568 398 254 568 minecraft:red_nether_bricks
fill 396 245 570 396 249 570 minecraft:red_nether_bricks
fill 396 245 578 396 249 578 minecraft:red_nether_bricks
fill 396 245 580 398 254 580 minecraft:red_nether_bricks
setblock 397 245 570 minecraft:quartz_block
setblock 397 245 578 minecraft:quartz_block
fill 398 245 570 398 249 570 minecraft:red_nether_bricks
fill 398 245 578 398 249 578 minecraft:red_nether_bricks
fill 399 245 568 417 245 568 minecraft:black_concrete
setblock 399 245 570 minecraft:quartz_block
setblock 399 245 578 minecraft:quartz_block
fill 399 245 580 400 245 580 minecraft:purple_concrete
fill 400 245 570 402 252 570 minecraft:red_nether_bricks
fill 400 245 578 402 252 578 minecraft:red_nether_bricks
setblock 401 245 572 minecraft:quartz_block
fill 401 245 573 404 249 573 minecraft:red_nether_bricks
setblock 401 245 574 minecraft:quartz_block
fill 401 245 575 404 249 575 minecraft:red_nether_bricks
setblock 401 245 576 minecraft:quartz_block
fill 401 245 580 417 245 580 minecraft:black_concrete
fill 402 245 569 417 245 569 minecraft:black_concrete
fill 402 245 571 403 253 572 minecraft:red_nether_bricks
fill 402 245 574 402 252 574 minecraft:red_nether_bricks
fill 402 245 576 403 253 577 minecraft:red_nether_bricks
fill 402 245 579 417 245 579 minecraft:black_concrete
fill 403 245 570 417 245 570 minecraft:black_concrete
fill 403 245 578 417 245 578 minecraft:black_concrete
fill 404 245 571 417 245 571 minecraft:black_concrete
fill 404 245 572 404 254 572 minecraft:red_nether_bricks
fill 404 245 574 404 254 574 minecraft:red_nether_bricks
fill 404 245 576 404 254 576 minecraft:red_nether_bricks
fill 404 245 577 417 245 577 minecraft:black_concrete
fill 405 245 572 417 245 576 minecraft:black_concrete
fill 377 246 568 383 246 588 minecraft:black_concrete
fill 378 246 567 416 246 567 minecraft:black_concrete
fill 378 246 589 416 247 589 minecraft:black_concrete
fill 379 246 565 415 246 565 minecraft:black_concrete
fill 379 246 591 415 246 591 minecraft:black_concrete
fill 380 246 564 414 246 564 minecraft:black_concrete
fill 380 246 592 414 246 592 minecraft:black_concrete
fill 381 246 563 413 247 563 minecraft:black_concrete
fill 381 246 593 413 247 593 minecraft:black_concrete
fill 382 246 562 412 247 562 minecraft:black_concrete
fill 382 246 594 412 247 594 minecraft:black_concrete
fill 383 246 561 411 246 561 minecraft:black_concrete
fill 383 246 595 411 246 595 minecraft:black_concrete
fill 384 246 560 410 246 560 minecraft:black_concrete
fill 384 246 568 384 246 573 minecraft:black_concrete
fill 384 246 574 385 250 574 minecraft:nether_bricks
fill 384 246 575 384 246 588 minecraft:black_concrete
fill 384 246 596 410 246 596 minecraft:black_concrete
fill 385 246 559 409 246 559 minecraft:black_concrete
fill 385 246 568 385 246 571 minecraft:black_concrete
fill 385 246 572 385 248 573 minecraft:nether_bricks
fill 385 246 575 385 248 576 minecraft:nether_bricks
fill 385 246 577 385 246 588 minecraft:black_concrete
fill 385 246 597 409 246 597 minecraft:black_concrete
fill 386 246 568 390 246 570 minecraft:black_concrete
fill 386 246 571 386 250 572 minecraft:nether_bricks
fill 386 246 576 386 250 577 minecraft:nether_bricks
fill 386 246 578 390 246 588 minecraft:black_concrete
fill 387 246 558 407 246 558 minecraft:black_concrete
fill 387 246 571 392 250 571 minecraft:nether_bricks
fill 387 246 577 392 250 577 minecraft:nether_bricks
fill 387 246 598 407 246 598 minecraft:black_concrete
fill 391 246 568 391 246 569 minecraft:black_concrete
setblock 391 246 570 minecraft:red_nether_bricks
setblock 391 246 578 minecraft:red_nether_bricks
fill 391 246 579 391 246 588 minecraft:black_concrete
setblock 392 246 568 minecraft:black_concrete
fill 392 246 569 392 254 569 minecraft:red_nether_bricks
fill 392 246 572 393 250 572 minecraft:nether_bricks
fill 392 246 576 393 250 576 minecraft:nether_bricks
fill 392 246 579 392 254 579 minecraft:red_nether_bricks
fill 392 246 580 392 246 588 minecraft:black_concrete
fill 393 246 568 395 253 568 minecraft:red_nether_bricks
fill 393 246 573 393 248 575 minecraft:nether_bricks
fill 393 246 580 395 253 580 minecraft:red_nether_bricks
fill 393 246 581 393 246 588 minecraft:black_concrete
fill 394 246 572 394 246 573 minecraft:red_nether_bricks
fill 394 246 575 394 246 576 minecraft:red_nether_bricks
fill 394 246 581 400 246 581 minecraft:crying_obsidian
fill 394 246 582 395 246 588 minecraft:black_concrete
fill 395 246 570 395 247 571 minecraft:red_nether_bricks
fill 395 246 577 395 247 578 minecraft:red_nether_bricks
setblock 396 246 571 minecraft:red_nether_bricks
setblock 396 246 577 minecraft:red_nether_bricks
fill 396 246 582 398 246 582 minecraft:crying_obsidian
fill 396 246 583 417 246 588 minecraft:black_concrete
fill 397 246 570 397 248 570 minecraft:red_nether_bricks
fill 397 246 578 397 248 578 minecraft:red_nether_bricks
fill 398 246 571 399 246 571 minecraft:red_nether_bricks
fill 398 246 577 399 246 577 minecraft:red_nether_bricks
fill 399 246 568 401 253 568 minecraft:red_nether_bricks
fill 399 246 570 399 250 570 minecraft:red_nether_bricks
fill 399 246 578 399 250 578 minecraft:red_nether_bricks
fill 399 246 580 401 253 580 minecraft:red_nether_bricks
fill 399 246 582 417 246 582 minecraft:black_concrete
fill 400 246 572 400 246 573 minecraft:red_nether_bricks
fill 400 246 575 400 246 576 minecraft:red_nether_bricks
fill 401 246 572 401 250 572 minecraft:red_nether_bricks
fill 401 246 574 401 248 574 minecraft:red_nether_bricks
fill 401 246 576 401 250 576 minecraft:red_nether_bricks
fill 401 246 581 417 246 581 minecraft:black_concrete
fill 402 246 568 417 246 568 minecraft:black_concrete
fill 402 246 569 402 254 569 minecraft:red_nether_bricks
fill 402 246 579 402 254 579 minecraft:red_nether_bricks
fill 402 246 580 417 246 580 minecraft:black_concrete
fill 403 246 569 417 246 569 minecraft:black_concrete
fill 403 246 570 403 254 570 minecraft:red_nether_bricks
fill 403 246 578 403 254 578 minecraft:red_nether_bricks
fill 403 246 579 417 246 579 minecraft:black_concrete
fill 404 246 570 417 246 570 minecraft:black_concrete
fill 404 246 571 404 254 571 minecraft:red_nether_bricks
fill 404 246 577 404 254 577 minecraft:red_nether_bricks
fill 404 246 578 417 246 578 minecraft:black_concrete
fill 405 246 571 417 246 571 minecraft:black_concrete
fill 405 246 572 405 253 576 minecraft:red_nether_bricks
fill 405 246 577 417 246 577 minecraft:black_concrete
fill 406 246 572 417 246 576 minecraft:black_concrete
fill 376 247 563 376 249 563 minecraft:black_concrete
setblock 376 247 564 minecraft:purple_concrete
setblock 376 247 567 minecraft:purple_concrete
fill 376 247 575 376 247 576 minecraft:purple_concrete
fill 376 247 587 376 247 588 minecraft:purple_concrete
fill 376 247 595 376 247 596 minecraft:purple_concrete
setblock 376 247 599 minecraft:purple_concrete
fill 377 247 569 383 247 587 minecraft:black_concrete
fill 378 247 567 391 247 568 minecraft:black_concrete
fill 378 247 588 416 247 588 minecraft:black_concrete
fill 379 247 566 415 247 566 minecraft:black_concrete
fill 379 247 590 415 247 590 minecraft:black_concrete
fill 380 247 565 414 247 565 minecraft:black_concrete
fill 380 247 591 414 247 591 minecraft:black_concrete
fill 381 247 557 382 247 557 minecraft:purple_concrete
fill 381 247 564 413 248 564 minecraft:black_concrete
fill 381 247 592 413 248 592 minecraft:black_concrete
fill 384 247 561 410 247 561 minecraft:black_concrete
fill 384 247 569 384 253 571 minecraft:black_concrete
fill 384 247 572 384 249 573 minecraft:nether_bricks
fill 384 247 575 384 249 576 minecraft:nether_bricks
fill 384 247 577 384 252 587 minecraft:black_concrete
fill 384 247 595 410 247 595 minecraft:black_concrete
fill 384 247 599 385 247 599 minecraft:purple_concrete
fill 385 247 560 409 247 560 minecraft:black_concrete
fill 385 247 569 386 253 570 minecraft:black_concrete
fill 385 247 571 385 249 571 minecraft:nether_bricks
fill 385 247 577 385 249 577 minecraft:nether_bricks
fill 385 247 578 386 250 587 minecraft:black_concrete
fill 385 247 596 409 247 596 minecraft:black_concrete
fill 386 247 559 408 247 559 minecraft:black_concrete
fill 386 247 597 408 247 597 minecraft:black_concrete
fill 387 247 569 390 247 569 minecraft:black_concrete
fill 387 247 570 391 249 570 minecraft:nether_bricks
fill 387 247 578 391 249 578 minecraft:nether_bricks
fill 387 247 579 390 247 587 minecraft:black_concrete
fill 388 247 558 406 247 558 minecraft:black_concrete
fill 388 247 598 406 247 598 minecraft:black_concrete
fill 391 247 569 391 253 569 minecraft:red_nether_bricks
fill 391 247 579 391 253 579 minecraft:red_nether_bricks
setblock 391 247 580 minecraft:purple_concrete
fill 391 247 581 391 247 587 minecraft:black_concrete
fill 392 247 567 393 247 567 minecraft:black_concrete
fill 392 247 568 392 252 568 minecraft:red_nether_bricks
fill 392 247 580 392 252 580 minecraft:red_nether_bricks
fill 392 247 581 393 247 581 minecraft:purple_concrete
fill 392 247 582 392 247 587 minecraft:black_concrete
fill 392 247 599 392 249 599 minecraft:black_concrete
fill 393 247 557 394 247 557 minecraft:purple_concrete
fill 393 247 571 393 249 571 minecraft:nether_bricks
fill 393 247 577 393 249 577 minecraft:nether_bricks
fill 393 247 582 395 247 582 minecraft:purple_concrete
fill 393 247 583 394 247 587 minecraft:black_concrete
setblock 393 247 599 minecraft:purple_concrete
fill 394 247 567 400 251 567 minecraft:red_nether_bricks
fill 394 247 571 394 249 571 minecraft:red_nether_bricks
setblock 394 247 572 minecraft:nether_bricks
setblock 394 247 576 minecraft:nether_bricks
fill 394 247 577 394 249 577 minecraft:red_nether_bricks
fill 394 247 581 400 251 581 minecraft:red_nether_bricks
fill 395 247 583 399 247 583 minecraft:purple_concrete
fill 395 247 584 417 247 587 minecraft:black_concrete
fill 396 247 599 397 247 599 minecraft:purple_concrete
setblock 399 247 571 minecraft:red_nether_bricks
setblock 399 247 577 minecraft:red_nether_bricks
fill 399 247 582 401 247 582 minecraft:purple_concrete
setblock 400 247 572 minecraft:red_nether_bricks
setblock 400 247 576 minecraft:red_nether_bricks
fill 400 247 583 417 247 583 minecraft:black_concrete
fill 401 247 567 416 247 567 minecraft:black_concrete
fill 401 247 581 402 247 581 minecraft:purple_concrete
setblock 402 247 557 minecraft:purple_concrete
fill 402 247 568 402 252 568 minecraft:red_nether_bricks
fill 402 247 580 402 252 580 minecraft:red_nether_bricks
fill 402 247 582 417 247 582 minecraft:black_concrete
fill 403 247 568 416 247 568 minecraft:black_concrete
fill 403 247 569 403 253 569 minecraft:red_nether_bricks
fill 403 247 579 403 253 579 minecraft:red_nether_bricks
setblock 403 247 580 minecraft:purple_concrete
fill 403 247 581 417 247 581 minecraft:black_concrete
fill 404 247 569 417 247 569 minecraft:black_concrete
fill 404 247 570 404 253 570 minecraft:red_nether_bricks
fill 404 247 578 404 253 578 minecraft:red_nether_bricks
fill 404 247 579 417 247 580 minecraft:black_concrete
fill 404 247 599 405 247 599 minecraft:purple_concrete
setblock 405 247 557 minecraft:purple_concrete
fill 405 247 570 417 247 570 minecraft:black_concrete
fill 405 247 571 405 253 571 minecraft:red_nether_bricks
fill 405 247 577 405 253 577 minecraft:red_nether_bricks
schedule function dropper:buildpart/140_4 1t
