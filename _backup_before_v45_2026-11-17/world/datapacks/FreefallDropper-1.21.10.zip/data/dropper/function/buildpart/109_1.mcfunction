setblock 66 97 482 minecraft:light[level=14]
setblock 66 97 490 minecraft:light[level=14]
setblock 66 97 498 minecraft:light[level=14]
setblock 74 97 466 minecraft:light[level=14]
setblock 74 97 474 minecraft:light[level=14]
setblock 74 97 482 minecraft:light[level=14]
setblock 74 97 490 minecraft:light[level=14]
setblock 74 97 498 minecraft:light[level=14]
setblock 82 97 466 minecraft:light[level=14]
setblock 82 97 474 minecraft:light[level=14]
setblock 82 97 482 minecraft:light[level=14]
setblock 82 97 490 minecraft:light[level=14]
setblock 82 97 498 minecraft:light[level=14]
fill 83 97 486 83 97 491 minecraft:black_concrete
fill 83 97 500 88 98 500 minecraft:quartz_block
fill 84 97 492 84 97 499 minecraft:quartz_block
fill 84 97 501 88 98 502 minecraft:quartz_block
fill 85 97 493 85 97 499 minecraft:quartz_block
fill 85 97 503 88 98 503 minecraft:quartz_block
fill 86 97 493 86 97 495 minecraft:quartz_block
fill 86 97 497 86 97 499 minecraft:quartz_block
fill 87 97 494 88 98 495 minecraft:quartz_block
fill 87 97 498 87 98 499 minecraft:quartz_block
fill 88 97 499 88 99 499 minecraft:quartz_block
fill 88 97 504 88 99 504 minecraft:quartz_block
fill 48 98 464 48 99 469 minecraft:quartz_block
fill 48 98 472 49 98 477 minecraft:quartz_block
fill 48 98 480 49 98 485 minecraft:quartz_block
fill 48 98 488 49 98 493 minecraft:quartz_block
fill 48 98 496 49 98 501 minecraft:quartz_block
fill 48 98 504 53 99 504 minecraft:quartz_block
fill 49 98 465 49 98 471 minecraft:quartz_block
fill 49 98 478 49 98 479 minecraft:quartz_block
fill 49 98 486 49 98 487 minecraft:quartz_block
fill 49 98 494 49 98 495 minecraft:quartz_block
fill 49 98 502 49 98 503 minecraft:quartz_block
fill 50 98 465 87 98 465 minecraft:quartz_block
fill 50 98 503 84 98 503 minecraft:quartz_block
fill 51 98 464 56 99 464 minecraft:quartz_block
fill 56 98 504 61 99 504 minecraft:quartz_block
fill 59 98 464 64 99 464 minecraft:quartz_block
fill 64 98 504 69 99 504 minecraft:quartz_block
fill 67 98 464 72 99 464 minecraft:quartz_block
fill 72 98 504 77 99 504 minecraft:quartz_block
fill 75 98 464 80 99 464 minecraft:quartz_block
fill 77 98 500 82 98 501 minecraft:quartz_block
fill 78 98 502 83 98 502 minecraft:quartz_block
fill 80 98 504 85 99 504 minecraft:quartz_block
fill 83 98 464 88 99 464 minecraft:quartz_block
fill 83 98 489 83 98 496 minecraft:black_concrete
setblock 83 98 501 minecraft:quartz_block
fill 84 98 498 84 98 499 minecraft:quartz_block
setblock 85 98 499 minecraft:quartz_block
fill 87 98 466 87 98 493 minecraft:quartz_block
fill 87 98 496 88 98 496 minecraft:quartz_block
fill 88 98 467 88 99 472 minecraft:quartz_block
fill 88 98 475 88 99 480 minecraft:quartz_block
fill 88 98 483 88 99 488 minecraft:quartz_block
fill 88 98 491 88 99 493 minecraft:quartz_block
fill 48 99 472 48 99 477 minecraft:quartz_block
fill 48 99 480 48 99 485 minecraft:quartz_block
fill 48 99 488 48 99 493 minecraft:quartz_block
fill 48 99 496 48 99 501 minecraft:quartz_block
fill 72 99 500 79 99 500 minecraft:quartz_block
fill 73 99 501 80 99 503 minecraft:quartz_block
fill 79 99 499 83 99 499 minecraft:black_concrete
fill 81 99 502 81 99 503 minecraft:quartz_block
fill 83 99 494 83 99 498 minecraft:black_concrete
fill 88 99 494 88 99 496 minecraft:quartz_block
fill 88 99 500 88 99 503 minecraft:quartz_block
fill 68 100 500 69 101 504 minecraft:quartz_block
fill 70 100 500 74 100 503 minecraft:quartz_block
fill 72 100 504 76 100 504 minecraft:quartz_block
fill 75 100 499 82 100 499 minecraft:black_concrete
fill 75 100 502 75 100 503 minecraft:quartz_block
fill 64 101 501 67 101 504 minecraft:quartz_block
fill 65 101 500 67 101 500 minecraft:quartz_block
fill 70 101 500 70 101 503 minecraft:quartz_block
fill 71 101 499 76 101 499 minecraft:black_concrete
fill 47 102 468 47 107 468 minecraft:sea_lantern
fill 47 102 476 47 107 476 minecraft:sea_lantern
fill 47 102 484 47 107 484 minecraft:sea_lantern
fill 47 102 492 47 107 492 minecraft:sea_lantern
fill 47 102 500 47 107 500 minecraft:sea_lantern
fill 47 102 501 47 149 501 minecraft:gray_concrete
fill 49 102 466 49 102 468 minecraft:gray_concrete
fill 50 102 465 52 102 465 minecraft:gray_concrete
fill 50 102 469 53 102 469 minecraft:gray_concrete
fill 50 102 505 50 107 505 minecraft:sea_lantern
setblock 53 102 466 minecraft:gray_concrete
setblock 53 102 468 minecraft:gray_concrete
fill 54 102 463 54 107 463 minecraft:sea_lantern
fill 58 102 504 61 102 504 minecraft:quartz_block
fill 58 102 505 58 107 505 minecraft:sea_lantern
fill 59 102 502 66 102 503 minecraft:quartz_block
fill 60 102 500 66 102 501 minecraft:quartz_block
fill 62 102 463 62 107 463 minecraft:sea_lantern
fill 64 102 504 66 102 504 minecraft:quartz_block
fill 66 102 505 66 107 505 minecraft:sea_lantern
fill 67 102 499 72 102 499 minecraft:black_concrete
fill 69 102 463 69 153 463 minecraft:gray_concrete
fill 70 102 463 70 107 463 minecraft:sea_lantern
fill 74 102 505 74 107 505 minecraft:sea_lantern
fill 78 102 463 78 107 463 minecraft:sea_lantern
fill 82 102 505 82 107 505 minecraft:sea_lantern
setblock 83 102 467 minecraft:gray_concrete
setblock 83 102 470 minecraft:gray_concrete
fill 84 102 466 85 102 466 minecraft:gray_concrete
fill 84 102 471 85 102 471 minecraft:gray_concrete
fill 86 102 463 86 107 463 minecraft:sea_lantern
setblock 86 102 467 minecraft:gray_concrete
setblock 86 102 470 minecraft:gray_concrete
fill 87 102 468 87 102 469 minecraft:gray_concrete
fill 89 102 468 89 107 468 minecraft:sea_lantern
fill 89 102 476 89 107 476 minecraft:sea_lantern
fill 89 102 484 89 107 484 minecraft:sea_lantern
fill 89 102 485 89 154 485 minecraft:gray_concrete
fill 89 102 492 89 107 492 minecraft:sea_lantern
fill 89 102 500 89 107 500 minecraft:sea_lantern
fill 51 103 504 53 104 504 minecraft:quartz_block
fill 52 103 503 61 103 503 minecraft:quartz_block
fill 53 103 501 61 103 502 minecraft:quartz_block
fill 54 103 500 62 103 500 minecraft:quartz_block
fill 56 103 504 60 103 504 minecraft:quartz_block
setblock 62 103 501 minecraft:quartz_block
fill 63 103 499 68 103 499 minecraft:black_concrete
fill 48 104 498 52 104 501 minecraft:quartz_block
fill 48 104 504 50 104 504 minecraft:quartz_block
fill 49 104 502 55 104 503 minecraft:quartz_block
fill 50 104 497 52 105 497 minecraft:quartz_block
fill 51 104 496 52 105 496 minecraft:quartz_block
fill 53 104 500 56 104 501 minecraft:quartz_block
setblock 56 104 502 minecraft:quartz_block
setblock 57 104 500 minecraft:quartz_block
fill 59 104 499 65 104 499 minecraft:black_concrete
fill 48 105 492 52 105 493 minecraft:quartz_block
fill 48 105 496 49 105 501 minecraft:quartz_block
fill 49 105 494 52 105 495 minecraft:quartz_block
setblock 50 105 474 minecraft:light[level=14]
setblock 50 105 482 minecraft:light[level=14]
setblock 50 105 490 minecraft:light[level=14]
fill 50 105 491 52 106 491 minecraft:quartz_block
setblock 50 105 496 minecraft:quartz_block
fill 50 105 498 50 105 500 minecraft:quartz_block
fill 51 105 498 51 105 499 minecraft:quartz_block
setblock 52 105 498 minecraft:quartz_block
fill 53 105 498 53 106 499 minecraft:black_concrete
fill 54 105 499 61 105 499 minecraft:black_concrete
setblock 58 105 466 minecraft:light[level=14]
setblock 58 105 474 minecraft:light[level=14]
setblock 58 105 482 minecraft:light[level=14]
setblock 58 105 490 minecraft:light[level=14]
setblock 58 105 498 minecraft:light[level=14]
setblock 66 105 466 minecraft:light[level=14]
setblock 66 105 474 minecraft:light[level=14]
setblock 66 105 482 minecraft:light[level=14]
setblock 66 105 490 minecraft:light[level=14]
setblock 66 105 498 minecraft:light[level=14]
setblock 74 105 466 minecraft:light[level=14]
setblock 74 105 474 minecraft:light[level=14]
setblock 74 105 482 minecraft:light[level=14]
setblock 74 105 490 minecraft:light[level=14]
setblock 74 105 498 minecraft:light[level=14]
setblock 82 105 466 minecraft:light[level=14]
setblock 82 105 474 minecraft:light[level=14]
setblock 82 105 482 minecraft:light[level=14]
setblock 82 105 490 minecraft:light[level=14]
setblock 82 105 498 minecraft:light[level=14]
fill 48 106 488 49 106 493 minecraft:quartz_block
fill 49 106 487 52 107 487 minecraft:quartz_block
fill 49 106 494 50 106 494 minecraft:quartz_block
fill 50 106 488 52 106 490 minecraft:quartz_block
fill 50 106 492 51 106 493 minecraft:quartz_block
fill 52 106 486 52 107 486 minecraft:quartz_block
setblock 52 106 492 minecraft:quartz_block
fill 53 106 493 53 106 497 minecraft:black_concrete
fill 54 106 499 55 106 499 minecraft:black_concrete
fill 48 107 482 51 107 485 minecraft:quartz_block
fill 48 107 488 49 107 489 minecraft:quartz_block
fill 49 107 486 51 107 486 minecraft:quartz_block
fill 50 107 488 52 107 488 minecraft:quartz_block
fill 52 107 483 52 107 485 minecraft:quartz_block
fill 53 107 489 53 107 495 minecraft:black_concrete
fill 47 108 468 47 115 468 minecraft:gray_concrete
fill 47 108 476 47 115 476 minecraft:gray_concrete
fill 47 108 484 47 115 484 minecraft:gray_concrete
fill 47 108 492 47 115 492 minecraft:gray_concrete
fill 47 108 500 47 115 500 minecraft:gray_concrete
fill 48 108 477 49 109 477 minecraft:quartz_block
fill 48 108 480 52 108 484 minecraft:quartz_block
fill 49 108 478 52 109 479 minecraft:quartz_block
fill 50 108 505 50 115 505 minecraft:gray_concrete
fill 53 108 464 53 109 466 minecraft:iron_block
fill 53 108 485 53 108 490 minecraft:black_concrete
fill 54 108 463 54 115 463 minecraft:gray_concrete
fill 58 108 505 58 115 505 minecraft:gray_concrete
fill 62 108 463 62 115 463 minecraft:gray_concrete
fill 66 108 505 66 115 505 minecraft:gray_concrete
fill 70 108 463 70 115 463 minecraft:gray_concrete
fill 74 108 505 74 115 505 minecraft:gray_concrete
fill 78 108 463 78 115 463 minecraft:gray_concrete
fill 82 108 505 82 115 505 minecraft:gray_concrete
fill 86 108 463 86 115 463 minecraft:gray_concrete
fill 89 108 468 89 115 468 minecraft:gray_concrete
fill 89 108 476 89 115 476 minecraft:gray_concrete
fill 89 108 484 89 115 484 minecraft:gray_concrete
fill 89 108 492 89 115 492 minecraft:gray_concrete
fill 89 108 500 89 115 500 minecraft:gray_concrete
fill 48 109 472 50 109 476 minecraft:quartz_block
fill 49 109 471 49 110 471 minecraft:quartz_block
fill 50 109 477 52 109 477 minecraft:quartz_block
fill 50 109 480 52 109 480 minecraft:quartz_block
fill 51 109 473 52 109 476 minecraft:quartz_block
fill 53 109 481 53 109 486 minecraft:black_concrete
fill 48 110 464 48 110 469 minecraft:quartz_block
fill 48 110 472 52 110 474 minecraft:quartz_block
fill 49 110 465 49 110 470 minecraft:quartz_block
fill 50 110 465 51 112 465 minecraft:quartz_block
fill 50 110 469 52 110 471 minecraft:quartz_block
fill 50 110 475 52 110 475 minecraft:quartz_block
setblock 52 110 465 minecraft:gray_concrete
setblock 52 110 476 minecraft:quartz_block
setblock 53 110 466 minecraft:gray_concrete
fill 53 110 468 53 111 468 minecraft:quartz_block
setblock 53 110 469 minecraft:gray_concrete
fill 53 110 477 53 110 482 minecraft:black_concrete
setblock 83 110 467 minecraft:gray_concrete
setblock 83 110 470 minecraft:gray_concrete
fill 84 110 466 85 110 466 minecraft:gray_concrete
fill 84 110 471 85 110 471 minecraft:gray_concrete
setblock 86 110 467 minecraft:gray_concrete
setblock 86 110 470 minecraft:gray_concrete
fill 87 110 468 87 110 469 minecraft:gray_concrete
fill 48 111 464 48 113 467 minecraft:quartz_block
fill 49 111 465 49 112 467 minecraft:quartz_block
fill 51 111 464 56 113 464 minecraft:quartz_block
fill 51 111 469 52 111 469 minecraft:quartz_block
fill 52 111 465 58 112 465 minecraft:quartz_block
setblock 52 111 470 minecraft:quartz_block
fill 53 111 466 58 111 466 minecraft:quartz_block
fill 53 111 472 53 111 479 minecraft:black_concrete
fill 54 111 467 59 111 468 minecraft:quartz_block
fill 48 112 468 49 112 469 minecraft:quartz_block
fill 48 112 472 49 112 477 minecraft:quartz_block
fill 48 112 480 49 112 485 minecraft:quartz_block
fill 48 112 488 49 112 493 minecraft:quartz_block
fill 48 112 496 49 112 501 minecraft:quartz_block
fill 48 112 504 53 113 504 minecraft:quartz_block
fill 49 112 470 49 112 471 minecraft:quartz_block
fill 49 112 478 49 112 479 minecraft:quartz_block
fill 49 112 486 49 112 487 minecraft:quartz_block
fill 49 112 494 49 112 495 minecraft:quartz_block
fill 49 112 502 49 112 503 minecraft:quartz_block
fill 50 112 503 88 112 503 minecraft:quartz_block
fill 53 112 469 53 112 474 minecraft:black_concrete
fill 54 112 469 57 113 469 minecraft:black_concrete
fill 55 112 466 63 112 466 minecraft:quartz_block
fill 56 112 467 63 112 467 minecraft:quartz_block
fill 56 112 504 61 113 504 minecraft:quartz_block
fill 57 112 468 64 112 468 minecraft:quartz_block
fill 59 112 464 64 112 465 minecraft:quartz_block
fill 64 112 504 69 113 504 minecraft:quartz_block
fill 65 112 465 87 112 465 minecraft:quartz_block
fill 67 112 464 72 114 464 minecraft:quartz_block
fill 72 112 501 72 113 502 minecraft:iron_block
fill 72 112 504 77 113 504 minecraft:quartz_block
fill 75 112 464 80 113 464 minecraft:quartz_block
fill 80 112 504 85 113 504 minecraft:quartz_block
fill 83 112 464 88 113 464 minecraft:quartz_block
fill 87 112 466 87 112 502 minecraft:quartz_block
fill 88 112 467 88 113 472 minecraft:quartz_block
fill 88 112 475 88 113 480 minecraft:quartz_block
fill 88 112 483 88 113 488 minecraft:quartz_block
fill 88 112 491 88 113 496 minecraft:quartz_block
fill 88 112 499 88 113 502 minecraft:quartz_block
fill 88 112 504 88 113 504 minecraft:quartz_block
fill 48 113 468 48 113 469 minecraft:quartz_block
fill 48 113 472 48 113 477 minecraft:quartz_block
fill 48 113 480 48 113 485 minecraft:quartz_block
fill 48 113 488 48 113 493 minecraft:quartz_block
fill 48 113 496 48 113 501 minecraft:quartz_block
fill 49 113 501 49 113 503 minecraft:iron_block
setblock 50 113 474 minecraft:light[level=14]
setblock 50 113 482 minecraft:light[level=14]
setblock 50 113 490 minecraft:light[level=14]
setblock 50 113 498 minecraft:light[level=14]
setblock 58 113 466 minecraft:light[level=14]
fill 58 113 469 61 113 469 minecraft:black_concrete
setblock 58 113 474 minecraft:light[level=14]
setblock 58 113 482 minecraft:light[level=14]
setblock 58 113 490 minecraft:light[level=14]
setblock 58 113 498 minecraft:light[level=14]
fill 59 113 464 64 113 464 minecraft:quartz_block
fill 61 113 465 68 113 466 minecraft:quartz_block
fill 62 113 467 68 113 468 minecraft:quartz_block
setblock 66 113 474 minecraft:light[level=14]
setblock 66 113 482 minecraft:light[level=14]
setblock 66 113 490 minecraft:light[level=14]
setblock 66 113 498 minecraft:light[level=14]
setblock 72 113 503 minecraft:iron_block
setblock 74 113 466 minecraft:light[level=14]
setblock 74 113 474 minecraft:light[level=14]
setblock 74 113 482 minecraft:light[level=14]
setblock 74 113 490 minecraft:light[level=14]
setblock 74 113 498 minecraft:light[level=14]
setblock 82 113 466 minecraft:light[level=14]
setblock 82 113 474 minecraft:light[level=14]
setblock 82 113 482 minecraft:light[level=14]
setblock 82 113 490 minecraft:light[level=14]
setblock 82 113 498 minecraft:light[level=14]
setblock 88 113 503 minecraft:quartz_block
fill 60 114 469 65 114 469 minecraft:black_concrete
fill 66 114 465 71 114 468 minecraft:quartz_block
fill 72 114 465 72 115 467 minecraft:quartz_block
fill 64 115 469 69 115 469 minecraft:black_concrete
fill 70 115 464 71 115 468 minecraft:quartz_block
setblock 72 115 464 minecraft:quartz_block
fill 72 115 468 76 115 468 minecraft:quartz_block
fill 73 115 465 76 115 467 minecraft:quartz_block
fill 75 115 464 78 115 464 minecraft:quartz_block
fill 77 115 465 77 116 466 minecraft:quartz_block
fill 47 116 468 47 121 468 minecraft:sea_lantern
fill 47 116 476 47 121 476 minecraft:sea_lantern
fill 47 116 484 47 121 484 minecraft:sea_lantern
fill 47 116 492 47 121 492 minecraft:sea_lantern
fill 47 116 500 47 121 500 minecraft:sea_lantern
fill 50 116 505 50 121 505 minecraft:sea_lantern
fill 54 116 463 54 121 463 minecraft:sea_lantern
fill 58 116 505 58 121 505 minecraft:sea_lantern
fill 62 116 463 62 121 463 minecraft:sea_lantern
fill 66 116 505 66 121 505 minecraft:sea_lantern
fill 68 116 469 73 116 469 minecraft:black_concrete
fill 70 116 463 70 121 463 minecraft:sea_lantern
fill 74 116 467 82 116 468 minecraft:quartz_block
fill 74 116 505 74 121 505 minecraft:sea_lantern
fill 75 116 465 76 116 466 minecraft:quartz_block
fill 76 116 464 80 116 464 minecraft:quartz_block
fill 78 116 463 78 121 463 minecraft:sea_lantern
fill 78 116 465 83 116 466 minecraft:quartz_block
fill 82 116 505 82 121 505 minecraft:sea_lantern
fill 83 116 464 85 117 464 minecraft:quartz_block
fill 83 116 467 83 117 467 minecraft:quartz_block
fill 84 116 465 84 117 465 minecraft:quartz_block
fill 86 116 463 86 121 463 minecraft:sea_lantern
fill 89 116 468 89 121 468 minecraft:sea_lantern
fill 89 116 476 89 121 476 minecraft:sea_lantern
fill 89 116 484 89 121 484 minecraft:sea_lantern
fill 89 116 492 89 121 492 minecraft:sea_lantern
fill 89 116 500 89 121 500 minecraft:sea_lantern
fill 71 117 469 77 117 469 minecraft:black_concrete
fill 79 117 468 82 117 468 minecraft:quartz_block
fill 80 117 466 82 117 467 minecraft:quartz_block
fill 81 117 465 83 117 465 minecraft:quartz_block
fill 83 117 466 87 117 466 minecraft:quartz_block
fill 84 117 471 85 118 472 minecraft:quartz_block
fill 85 117 465 87 117 465 minecraft:quartz_block
fill 86 117 464 88 117 464 minecraft:quartz_block
fill 86 117 467 88 117 467 minecraft:quartz_block
fill 86 117 470 86 118 471 minecraft:quartz_block
fill 87 117 468 88 118 470 minecraft:quartz_block
fill 49 118 466 49 118 468 minecraft:gray_concrete
fill 50 118 465 52 118 465 minecraft:gray_concrete
fill 50 118 469 53 118 469 minecraft:gray_concrete
setblock 53 118 466 minecraft:gray_concrete
setblock 53 118 468 minecraft:gray_concrete
fill 75 118 469 83 118 469 minecraft:black_concrete
setblock 83 118 467 minecraft:gray_concrete
fill 83 118 468 86 158 468 minecraft:quartz_block
fill 83 118 470 83 119 470 minecraft:black_concrete
fill 84 118 466 85 118 466 minecraft:gray_concrete
fill 84 118 469 86 158 469 minecraft:quartz_block
fill 84 118 473 86 118 477 minecraft:quartz_block
setblock 86 118 467 minecraft:gray_concrete
fill 86 118 472 88 118 472 minecraft:quartz_block
fill 87 118 467 88 118 467 minecraft:quartz_block
fill 87 118 471 88 118 471 minecraft:quartz_block
fill 87 118 473 87 118 476 minecraft:quartz_block
fill 88 118 475 88 119 476 minecraft:quartz_block
fill 81 119 469 83 119 469 minecraft:black_concrete
fill 83 119 471 83 119 475 minecraft:black_concrete
fill 84 119 476 84 119 482 minecraft:quartz_block
fill 85 119 475 87 119 481 minecraft:quartz_block
fill 86 119 474 87 119 474 minecraft:quartz_block
fill 88 119 477 88 119 480 minecraft:quartz_block
fill 83 120 469 83 143 469 minecraft:quartz_block
fill 83 120 473 83 120 479 minecraft:black_concrete
fill 84 120 480 87 120 485 minecraft:quartz_block
fill 85 120 486 88 121 486 minecraft:quartz_block
fill 87 120 479 88 120 479 minecraft:quartz_block
setblock 88 120 480 minecraft:quartz_block
fill 88 120 483 88 120 485 minecraft:quartz_block
setblock 50 121 474 minecraft:light[level=14]
setblock 50 121 482 minecraft:light[level=14]
setblock 50 121 490 minecraft:light[level=14]
setblock 50 121 498 minecraft:light[level=14]
setblock 58 121 466 minecraft:light[level=14]
setblock 58 121 474 minecraft:light[level=14]
setblock 58 121 482 minecraft:light[level=14]
setblock 58 121 490 minecraft:light[level=14]
setblock 58 121 498 minecraft:light[level=14]
setblock 66 121 466 minecraft:light[level=14]
setblock 66 121 474 minecraft:light[level=14]
setblock 66 121 482 minecraft:light[level=14]
setblock 66 121 490 minecraft:light[level=14]
setblock 66 121 498 minecraft:light[level=14]
setblock 74 121 466 minecraft:light[level=14]
setblock 74 121 474 minecraft:light[level=14]
setblock 74 121 482 minecraft:light[level=14]
setblock 74 121 490 minecraft:light[level=14]
setblock 74 121 498 minecraft:light[level=14]
setblock 82 121 466 minecraft:light[level=14]
setblock 82 121 474 minecraft:light[level=14]
setblock 82 121 482 minecraft:light[level=14]
setblock 82 121 490 minecraft:light[level=14]
setblock 82 121 498 minecraft:light[level=14]
fill 83 121 478 83 121 483 minecraft:black_concrete
fill 84 121 484 84 121 490 minecraft:quartz_block
fill 85 121 484 88 121 485 minecraft:quartz_block
fill 85 121 487 87 121 490 minecraft:quartz_block
fill 87 121 491 88 122 491 minecraft:quartz_block
fill 88 121 487 88 121 488 minecraft:quartz_block
fill 47 122 468 47 129 468 minecraft:gray_concrete
fill 47 122 476 47 129 476 minecraft:gray_concrete
fill 47 122 484 47 129 484 minecraft:gray_concrete
fill 47 122 492 47 129 492 minecraft:gray_concrete
fill 47 122 500 47 129 500 minecraft:gray_concrete
fill 50 122 505 50 129 505 minecraft:gray_concrete
fill 54 122 463 54 129 463 minecraft:gray_concrete
fill 58 122 505 58 129 505 minecraft:gray_concrete
fill 62 122 463 62 129 463 minecraft:gray_concrete
fill 66 122 505 66 129 505 minecraft:gray_concrete
fill 70 122 463 70 129 463 minecraft:gray_concrete
fill 74 122 505 74 129 505 minecraft:gray_concrete
fill 78 122 463 78 129 463 minecraft:gray_concrete
fill 82 122 505 82 129 505 minecraft:gray_concrete
fill 83 122 482 83 122 487 minecraft:black_concrete
fill 84 122 488 86 122 495 minecraft:quartz_block
fill 86 122 463 86 129 463 minecraft:gray_concrete
fill 86 122 496 88 123 496 minecraft:quartz_block
fill 87 122 489 87 122 490 minecraft:quartz_block
fill 87 122 492 88 122 495 minecraft:quartz_block
fill 87 122 497 87 123 497 minecraft:quartz_block
fill 89 122 468 89 129 468 minecraft:gray_concrete
fill 89 122 476 89 129 476 minecraft:gray_concrete
fill 89 122 484 89 129 484 minecraft:gray_concrete
fill 89 122 492 89 129 492 minecraft:gray_concrete
fill 89 122 500 89 129 500 minecraft:gray_concrete
fill 83 123 486 83 123 491 minecraft:black_concrete
fill 83 123 500 88 123 500 minecraft:quartz_block
fill 84 123 492 84 123 499 minecraft:quartz_block
fill 84 123 501 88 124 502 minecraft:quartz_block
fill 85 123 493 85 123 499 minecraft:quartz_block
fill 85 123 503 88 124 503 minecraft:quartz_block
fill 86 123 493 86 123 495 minecraft:quartz_block
fill 86 123 497 86 123 499 minecraft:quartz_block
fill 87 123 494 88 123 495 minecraft:quartz_block
fill 87 123 498 87 123 499 minecraft:quartz_block
setblock 88 123 499 minecraft:quartz_block
fill 88 123 504 88 124 504 minecraft:quartz_block
fill 77 124 500 83 124 501 minecraft:quartz_block
fill 78 124 502 83 124 503 minecraft:quartz_block
fill 80 124 504 85 124 504 minecraft:quartz_block
fill 83 124 489 83 124 496 minecraft:black_concrete
fill 84 124 498 84 124 500 minecraft:quartz_block
setblock 84 124 503 minecraft:quartz_block
fill 85 124 499 85 124 500 minecraft:quartz_block
setblock 86 124 500 minecraft:quartz_block
fill 72 125 500 79 125 500 minecraft:quartz_block
fill 73 125 501 77 125 504 minecraft:quartz_block
fill 78 125 501 80 125 503 minecraft:quartz_block
fill 79 125 499 83 125 499 minecraft:black_concrete
fill 80 125 504 82 127 504 minecraft:quartz_block
fill 81 125 502 81 125 503 minecraft:quartz_block
fill 83 125 494 83 125 498 minecraft:black_concrete
fill 85 125 476 87 125 476 minecraft:iron_block
fill 48 126 464 48 127 469 minecraft:quartz_block
fill 48 126 472 49 126 477 minecraft:quartz_block
fill 48 126 480 49 126 485 minecraft:quartz_block
fill 48 126 488 49 126 493 minecraft:quartz_block
fill 48 126 496 49 126 501 minecraft:quartz_block
fill 48 126 504 53 127 504 minecraft:quartz_block
fill 49 126 465 49 126 471 minecraft:quartz_block
fill 49 126 478 49 126 479 minecraft:quartz_block
fill 49 126 486 49 126 487 minecraft:quartz_block
fill 49 126 494 49 126 495 minecraft:quartz_block
fill 49 126 502 49 126 503 minecraft:quartz_block
fill 50 126 465 87 126 465 minecraft:quartz_block
fill 50 126 469 53 126 469 minecraft:gray_concrete
fill 50 126 503 88 126 503 minecraft:quartz_block
fill 51 126 464 56 127 464 minecraft:quartz_block
setblock 53 126 466 minecraft:gray_concrete
setblock 53 126 468 minecraft:gray_concrete
fill 56 126 504 61 127 504 minecraft:quartz_block
fill 59 126 464 64 127 464 minecraft:quartz_block
fill 64 126 504 69 127 504 minecraft:quartz_block
fill 67 126 464 72 127 464 minecraft:quartz_block
fill 68 126 500 74 126 502 minecraft:quartz_block
fill 72 126 504 77 127 504 minecraft:quartz_block
fill 75 126 464 80 127 464 minecraft:quartz_block
fill 75 126 499 82 126 499 minecraft:black_concrete
setblock 75 126 502 minecraft:quartz_block
fill 83 126 464 88 127 464 minecraft:quartz_block
setblock 83 126 467 minecraft:gray_concrete
setblock 83 126 470 minecraft:gray_concrete
fill 83 126 504 85 127 504 minecraft:quartz_block
fill 84 126 466 85 126 466 minecraft:gray_concrete
fill 84 126 471 85 126 471 minecraft:gray_concrete
fill 85 126 476 86 126 476 minecraft:iron_block
setblock 86 126 467 minecraft:gray_concrete
setblock 86 126 470 minecraft:gray_concrete
fill 87 126 466 87 126 502 minecraft:quartz_block
fill 88 126 467 88 127 472 minecraft:quartz_block
fill 88 126 475 88 127 480 minecraft:quartz_block
fill 88 126 483 88 127 488 minecraft:quartz_block
fill 88 126 491 88 127 496 minecraft:quartz_block
fill 88 126 499 88 127 502 minecraft:quartz_block
fill 88 126 504 88 127 504 minecraft:quartz_block
fill 48 127 472 48 127 477 minecraft:quartz_block
fill 48 127 480 48 127 485 minecraft:quartz_block
fill 48 127 488 48 127 493 minecraft:quartz_block
fill 48 127 496 48 127 501 minecraft:quartz_block
fill 64 127 501 70 127 503 minecraft:quartz_block
fill 65 127 500 70 127 500 minecraft:quartz_block
fill 71 127 499 76 127 499 minecraft:black_concrete
setblock 88 127 503 minecraft:quartz_block
fill 58 128 504 61 128 504 minecraft:quartz_block
fill 59 128 502 66 128 503 minecraft:quartz_block
fill 60 128 500 66 128 501 minecraft:quartz_block
fill 64 128 504 66 128 504 minecraft:quartz_block
fill 67 128 499 72 128 499 minecraft:black_concrete
setblock 50 129 474 minecraft:light[level=14]
setblock 50 129 482 minecraft:light[level=14]
setblock 50 129 490 minecraft:light[level=14]
setblock 50 129 498 minecraft:light[level=14]
fill 51 129 504 53 130 504 minecraft:quartz_block
fill 52 129 503 61 129 503 minecraft:quartz_block
fill 53 129 501 61 129 502 minecraft:quartz_block
fill 54 129 500 62 129 500 minecraft:quartz_block
fill 56 129 504 60 129 504 minecraft:quartz_block
setblock 58 129 466 minecraft:light[level=14]
setblock 58 129 474 minecraft:light[level=14]
setblock 58 129 482 minecraft:light[level=14]
setblock 58 129 490 minecraft:light[level=14]
setblock 58 129 498 minecraft:light[level=14]
setblock 62 129 501 minecraft:quartz_block
fill 63 129 499 68 129 499 minecraft:black_concrete
setblock 66 129 466 minecraft:light[level=14]
setblock 66 129 474 minecraft:light[level=14]
setblock 66 129 482 minecraft:light[level=14]
setblock 66 129 490 minecraft:light[level=14]
setblock 66 129 498 minecraft:light[level=14]
setblock 74 129 466 minecraft:light[level=14]
setblock 74 129 474 minecraft:light[level=14]
setblock 74 129 482 minecraft:light[level=14]
setblock 74 129 490 minecraft:light[level=14]
setblock 74 129 498 minecraft:light[level=14]
setblock 82 129 466 minecraft:light[level=14]
setblock 82 129 474 minecraft:light[level=14]
setblock 82 129 482 minecraft:light[level=14]
setblock 82 129 490 minecraft:light[level=14]
setblock 82 129 498 minecraft:light[level=14]
fill 47 130 468 47 135 468 minecraft:sea_lantern
fill 47 130 476 47 135 476 minecraft:sea_lantern
fill 47 130 484 47 135 484 minecraft:sea_lantern
fill 47 130 492 47 135 492 minecraft:sea_lantern
fill 47 130 500 47 135 500 minecraft:sea_lantern
fill 48 130 498 52 130 501 minecraft:quartz_block
fill 48 130 504 50 130 504 minecraft:quartz_block
fill 49 130 502 55 130 503 minecraft:quartz_block
fill 50 130 497 52 131 497 minecraft:quartz_block
fill 50 130 505 50 135 505 minecraft:sea_lantern
fill 51 130 496 52 131 496 minecraft:quartz_block
fill 53 130 500 56 130 501 minecraft:quartz_block
fill 54 130 463 54 135 463 minecraft:sea_lantern
setblock 56 130 502 minecraft:quartz_block
setblock 57 130 500 minecraft:quartz_block
fill 58 130 505 58 135 505 minecraft:sea_lantern
fill 59 130 499 65 130 499 minecraft:black_concrete
fill 62 130 463 62 135 463 minecraft:sea_lantern
fill 66 130 505 66 135 505 minecraft:sea_lantern
fill 70 130 463 70 135 463 minecraft:sea_lantern
fill 74 130 505 74 135 505 minecraft:sea_lantern
fill 78 130 463 78 135 463 minecraft:sea_lantern
fill 82 130 505 82 135 505 minecraft:sea_lantern
fill 86 130 463 86 135 463 minecraft:sea_lantern
fill 89 130 468 89 135 468 minecraft:sea_lantern
fill 89 130 476 89 135 476 minecraft:sea_lantern
fill 89 130 484 89 135 484 minecraft:sea_lantern
fill 89 130 492 89 135 492 minecraft:sea_lantern
fill 89 130 500 89 135 500 minecraft:sea_lantern
fill 48 131 492 52 131 493 minecraft:quartz_block
fill 48 131 496 49 131 501 minecraft:quartz_block
fill 49 131 494 52 131 495 minecraft:quartz_block
fill 50 131 491 52 132 491 minecraft:quartz_block
setblock 50 131 496 minecraft:quartz_block
fill 50 131 498 50 131 500 minecraft:quartz_block
fill 51 131 498 51 131 499 minecraft:quartz_block
setblock 52 131 498 minecraft:quartz_block
fill 53 131 498 53 132 499 minecraft:black_concrete
fill 54 131 499 61 131 499 minecraft:black_concrete
fill 48 132 488 49 132 493 minecraft:quartz_block
fill 49 132 487 52 133 487 minecraft:quartz_block
fill 49 132 494 50 132 494 minecraft:quartz_block
fill 50 132 488 52 132 490 minecraft:quartz_block
fill 50 132 492 51 132 493 minecraft:quartz_block
fill 52 132 486 52 133 486 minecraft:quartz_block
setblock 52 132 492 minecraft:quartz_block
fill 53 132 493 53 132 497 minecraft:black_concrete
fill 54 132 499 55 132 499 minecraft:black_concrete
fill 48 133 482 51 133 485 minecraft:quartz_block
fill 48 133 488 49 133 489 minecraft:quartz_block
fill 49 133 486 51 133 486 minecraft:quartz_block
fill 50 133 488 52 133 488 minecraft:quartz_block
fill 52 133 483 52 133 485 minecraft:quartz_block
fill 53 133 489 53 133 495 minecraft:black_concrete
fill 48 134 477 49 135 477 minecraft:quartz_block
fill 48 134 480 52 134 484 minecraft:quartz_block
fill 49 134 466 49 134 468 minecraft:gray_concrete
fill 49 134 478 52 135 479 minecraft:quartz_block
fill 50 134 465 52 134 465 minecraft:gray_concrete
fill 50 134 469 53 134 469 minecraft:gray_concrete
setblock 53 134 466 minecraft:gray_concrete
setblock 53 134 468 minecraft:gray_concrete
fill 53 134 485 53 134 490 minecraft:black_concrete
setblock 83 134 467 minecraft:gray_concrete
setblock 83 134 470 minecraft:gray_concrete
fill 84 134 466 85 134 466 minecraft:gray_concrete
fill 84 134 471 85 134 471 minecraft:gray_concrete
setblock 86 134 467 minecraft:gray_concrete
setblock 86 134 470 minecraft:gray_concrete
fill 87 134 468 87 134 469 minecraft:gray_concrete
fill 48 135 472 50 135 476 minecraft:quartz_block
fill 49 135 471 49 136 471 minecraft:quartz_block
fill 50 135 477 52 135 477 minecraft:quartz_block
fill 50 135 480 52 135 480 minecraft:quartz_block
fill 51 135 473 52 135 476 minecraft:quartz_block
fill 53 135 481 53 135 486 minecraft:black_concrete
fill 47 136 468 47 143 468 minecraft:gray_concrete
fill 47 136 476 47 143 476 minecraft:gray_concrete
fill 47 136 484 47 143 484 minecraft:gray_concrete
fill 47 136 492 47 143 492 minecraft:gray_concrete
fill 47 136 500 47 143 500 minecraft:gray_concrete
fill 48 136 464 48 136 469 minecraft:quartz_block
fill 48 136 472 52 136 474 minecraft:quartz_block
fill 49 136 465 49 136 470 minecraft:quartz_block
fill 50 136 465 51 137 465 minecraft:quartz_block
fill 50 136 469 52 136 471 minecraft:quartz_block
fill 50 136 475 52 136 475 minecraft:quartz_block
fill 50 136 505 50 143 505 minecraft:gray_concrete
setblock 52 136 476 minecraft:quartz_block
fill 53 136 468 53 137 468 minecraft:quartz_block
fill 53 136 477 53 136 482 minecraft:black_concrete
fill 54 136 463 54 143 463 minecraft:gray_concrete
fill 58 136 505 58 143 505 minecraft:gray_concrete
fill 62 136 463 62 143 463 minecraft:gray_concrete
fill 66 136 505 66 143 505 minecraft:gray_concrete
fill 70 136 463 70 143 463 minecraft:gray_concrete
fill 74 136 505 74 143 505 minecraft:gray_concrete
fill 78 136 463 78 143 463 minecraft:gray_concrete
fill 82 136 505 82 143 505 minecraft:gray_concrete
fill 86 136 463 86 143 463 minecraft:gray_concrete
fill 89 136 468 89 143 468 minecraft:gray_concrete
fill 89 136 476 89 143 476 minecraft:gray_concrete
fill 89 136 484 89 143 484 minecraft:gray_concrete
fill 89 136 492 89 143 492 minecraft:gray_concrete
fill 89 136 500 89 143 500 minecraft:gray_concrete
fill 48 137 464 48 137 467 minecraft:quartz_block
fill 49 137 465 49 137 467 minecraft:quartz_block
setblock 50 137 474 minecraft:light[level=14]
setblock 50 137 482 minecraft:light[level=14]
setblock 50 137 490 minecraft:light[level=14]
setblock 50 137 498 minecraft:light[level=14]
fill 51 137 464 56 137 464 minecraft:quartz_block
fill 51 137 469 52 137 469 minecraft:quartz_block
fill 52 137 465 58 137 465 minecraft:quartz_block
setblock 52 137 470 minecraft:quartz_block
fill 53 137 466 58 137 466 minecraft:quartz_block
fill 53 137 472 53 137 479 minecraft:black_concrete
fill 54 137 467 59 137 468 minecraft:quartz_block
setblock 58 137 474 minecraft:light[level=14]
setblock 58 137 482 minecraft:light[level=14]
setblock 58 137 490 minecraft:light[level=14]
setblock 58 137 498 minecraft:light[level=14]
setblock 66 137 466 minecraft:light[level=14]
setblock 66 137 474 minecraft:light[level=14]
setblock 66 137 482 minecraft:light[level=14]
setblock 66 137 490 minecraft:light[level=14]
setblock 66 137 498 minecraft:light[level=14]
setblock 74 137 466 minecraft:light[level=14]
setblock 74 137 474 minecraft:light[level=14]
setblock 74 137 482 minecraft:light[level=14]
setblock 74 137 490 minecraft:light[level=14]
setblock 74 137 498 minecraft:light[level=14]
setblock 82 137 466 minecraft:light[level=14]
setblock 82 137 474 minecraft:light[level=14]
setblock 82 137 482 minecraft:light[level=14]
setblock 82 137 490 minecraft:light[level=14]
setblock 82 137 498 minecraft:light[level=14]
fill 53 138 469 53 138 474 minecraft:black_concrete
fill 54 138 464 56 138 464 minecraft:quartz_block
fill 54 138 469 57 139 469 minecraft:black_concrete
fill 55 138 465 63 138 466 minecraft:quartz_block
fill 56 138 467 63 138 467 minecraft:quartz_block
fill 57 138 468 64 138 468 minecraft:quartz_block
fill 59 138 464 63 138 464 minecraft:quartz_block
fill 58 139 469 61 139 469 minecraft:black_concrete
fill 60 139 464 64 141 464 minecraft:quartz_block
fill 61 139 465 68 139 466 minecraft:quartz_block
fill 62 139 467 68 139 468 minecraft:quartz_block
fill 67 139 464 68 141 464 minecraft:quartz_block
fill 48 140 464 48 141 469 minecraft:quartz_block
fill 48 140 472 49 140 477 minecraft:quartz_block
fill 48 140 480 49 140 485 minecraft:quartz_block
fill 48 140 488 49 140 493 minecraft:quartz_block
fill 48 140 496 49 140 501 minecraft:quartz_block
fill 48 140 504 53 141 504 minecraft:quartz_block
fill 49 140 465 49 140 471 minecraft:quartz_block
fill 49 140 478 49 140 479 minecraft:quartz_block
fill 49 140 486 49 140 487 minecraft:quartz_block
fill 49 140 494 49 140 495 minecraft:quartz_block
fill 49 140 502 49 140 503 minecraft:quartz_block
fill 50 140 465 87 140 465 minecraft:quartz_block
fill 50 140 503 88 140 503 minecraft:quartz_block
fill 51 140 464 56 141 464 minecraft:quartz_block
fill 56 140 504 61 141 504 minecraft:quartz_block
fill 59 140 464 59 141 464 minecraft:quartz_block
fill 60 140 469 65 140 469 minecraft:black_concrete
fill 64 140 504 69 141 504 minecraft:quartz_block
fill 66 140 466 71 140 468 minecraft:quartz_block
fill 69 140 464 72 141 464 minecraft:quartz_block
fill 72 140 466 72 141 467 minecraft:quartz_block
fill 72 140 504 77 141 504 minecraft:quartz_block
fill 75 140 464 80 141 464 minecraft:quartz_block
fill 80 140 504 85 141 504 minecraft:quartz_block
fill 83 140 464 88 141 464 minecraft:quartz_block
fill 87 140 466 87 140 502 minecraft:quartz_block
fill 88 140 467 88 141 472 minecraft:quartz_block
fill 88 140 475 88 141 480 minecraft:quartz_block
fill 88 140 483 88 141 488 minecraft:quartz_block
fill 88 140 491 88 141 496 minecraft:quartz_block
fill 88 140 499 88 141 502 minecraft:quartz_block
fill 88 140 504 88 141 504 minecraft:quartz_block
fill 48 141 472 48 141 477 minecraft:quartz_block
fill 48 141 480 48 141 485 minecraft:quartz_block
fill 48 141 488 48 141 493 minecraft:quartz_block
fill 48 141 496 48 141 501 minecraft:quartz_block
fill 64 141 469 69 141 469 minecraft:black_concrete
fill 70 141 465 71 141 468 minecraft:quartz_block
fill 72 141 465 77 141 465 minecraft:quartz_block
fill 72 141 468 76 141 468 minecraft:quartz_block
fill 73 141 466 76 141 467 minecraft:quartz_block
fill 77 141 466 77 142 466 minecraft:quartz_block
setblock 88 141 503 minecraft:quartz_block
fill 49 142 466 49 142 468 minecraft:gray_concrete
fill 50 142 465 52 142 465 minecraft:gray_concrete
fill 50 142 469 53 142 469 minecraft:gray_concrete
setblock 53 142 466 minecraft:gray_concrete
setblock 53 142 468 minecraft:gray_concrete
fill 68 142 469 73 142 469 minecraft:black_concrete
fill 74 142 467 82 142 468 minecraft:quartz_block
fill 75 142 465 76 142 466 minecraft:quartz_block
fill 76 142 464 80 142 464 minecraft:quartz_block
fill 77 142 465 84 142 465 minecraft:quartz_block
fill 78 142 466 83 142 466 minecraft:quartz_block
fill 83 142 464 85 143 464 minecraft:quartz_block
fill 83 142 467 83 143 467 minecraft:quartz_block
setblock 83 142 470 minecraft:gray_concrete
fill 84 142 466 85 142 466 minecraft:gray_concrete
fill 84 142 471 85 142 471 minecraft:gray_concrete
setblock 86 142 467 minecraft:gray_concrete
setblock 86 142 470 minecraft:gray_concrete
fill 87 142 468 87 142 469 minecraft:gray_concrete
fill 71 143 469 77 143 469 minecraft:black_concrete
fill 79 143 468 82 143 468 minecraft:quartz_block
fill 80 143 466 82 143 467 minecraft:quartz_block
fill 81 143 465 87 143 465 minecraft:quartz_block
fill 83 143 466 87 143 466 minecraft:quartz_block
fill 84 143 471 85 144 472 minecraft:quartz_block
fill 86 143 464 88 143 464 minecraft:quartz_block
fill 86 143 467 88 143 467 minecraft:quartz_block
fill 86 143 470 86 144 471 minecraft:quartz_block
fill 87 143 468 88 144 470 minecraft:quartz_block
fill 47 144 468 47 149 468 minecraft:sea_lantern
fill 47 144 476 47 149 476 minecraft:sea_lantern
fill 47 144 484 47 149 484 minecraft:sea_lantern
fill 47 144 492 47 149 492 minecraft:sea_lantern
fill 47 144 500 47 149 500 minecraft:sea_lantern
fill 50 144 505 50 149 505 minecraft:sea_lantern
fill 54 144 463 54 149 463 minecraft:sea_lantern
fill 58 144 505 58 149 505 minecraft:sea_lantern
fill 62 144 463 62 149 463 minecraft:sea_lantern
fill 66 144 505 66 149 505 minecraft:sea_lantern
fill 70 144 463 70 149 463 minecraft:sea_lantern
fill 74 144 505 74 149 505 minecraft:sea_lantern
fill 75 144 469 83 144 469 minecraft:black_concrete
fill 78 144 463 78 149 463 minecraft:sea_lantern
fill 82 144 505 82 149 505 minecraft:sea_lantern
fill 83 144 470 83 145 470 minecraft:black_concrete
fill 84 144 473 86 144 477 minecraft:quartz_block
fill 86 144 463 86 149 463 minecraft:sea_lantern
fill 86 144 472 88 144 472 minecraft:quartz_block
fill 87 144 467 88 144 467 minecraft:quartz_block
fill 87 144 471 88 144 471 minecraft:quartz_block
fill 87 144 473 87 144 476 minecraft:quartz_block
fill 88 144 475 88 145 476 minecraft:quartz_block
fill 89 144 468 89 149 468 minecraft:sea_lantern
fill 89 144 476 89 149 476 minecraft:sea_lantern
fill 89 144 484 89 149 484 minecraft:sea_lantern
fill 89 144 492 89 149 492 minecraft:sea_lantern
fill 89 144 500 89 149 500 minecraft:sea_lantern
setblock 50 145 474 minecraft:light[level=14]
setblock 50 145 482 minecraft:light[level=14]
setblock 50 145 490 minecraft:light[level=14]
setblock 50 145 498 minecraft:light[level=14]
setblock 58 145 466 minecraft:light[level=14]
setblock 58 145 474 minecraft:light[level=14]
setblock 58 145 482 minecraft:light[level=14]
setblock 58 145 490 minecraft:light[level=14]
setblock 58 145 498 minecraft:light[level=14]
setblock 66 145 466 minecraft:light[level=14]
setblock 66 145 474 minecraft:light[level=14]
setblock 66 145 482 minecraft:light[level=14]
setblock 66 145 490 minecraft:light[level=14]
setblock 66 145 498 minecraft:light[level=14]
setblock 74 145 466 minecraft:light[level=14]
setblock 74 145 474 minecraft:light[level=14]
setblock 74 145 482 minecraft:light[level=14]
setblock 74 145 490 minecraft:light[level=14]
setblock 74 145 498 minecraft:light[level=14]
fill 81 145 469 83 145 469 minecraft:black_concrete
setblock 82 145 466 minecraft:light[level=14]
setblock 82 145 474 minecraft:light[level=14]
setblock 82 145 482 minecraft:light[level=14]
setblock 82 145 490 minecraft:light[level=14]
setblock 82 145 498 minecraft:light[level=14]
fill 83 145 471 83 145 475 minecraft:black_concrete
fill 84 145 476 84 145 482 minecraft:quartz_block
fill 85 145 475 87 145 481 minecraft:quartz_block
fill 86 145 474 87 145 474 minecraft:quartz_block
fill 88 145 477 88 145 480 minecraft:quartz_block
fill 83 146 469 83 158 469 minecraft:quartz_block
fill 83 146 473 83 146 479 minecraft:black_concrete
fill 84 146 480 87 146 485 minecraft:quartz_block
fill 85 146 486 88 147 486 minecraft:quartz_block
fill 87 146 479 88 146 479 minecraft:quartz_block
setblock 88 146 480 minecraft:quartz_block
fill 88 146 483 88 146 485 minecraft:quartz_block
fill 83 147 478 83 147 483 minecraft:black_concrete
fill 84 147 484 84 147 490 minecraft:quartz_block
fill 85 147 484 88 147 485 minecraft:quartz_block
fill 85 147 487 87 147 490 minecraft:quartz_block
fill 87 147 491 88 148 491 minecraft:quartz_block
fill 88 147 487 88 147 488 minecraft:quartz_block
fill 83 148 482 83 148 487 minecraft:black_concrete
fill 84 148 488 86 148 495 minecraft:quartz_block
fill 86 148 496 88 149 496 minecraft:quartz_block
fill 87 148 489 87 148 490 minecraft:quartz_block
fill 87 148 492 88 148 495 minecraft:quartz_block
fill 87 148 497 87 149 497 minecraft:quartz_block
fill 83 149 486 83 149 491 minecraft:black_concrete
fill 83 149 500 88 149 500 minecraft:quartz_block
fill 84 149 492 84 149 499 minecraft:quartz_block
fill 84 149 501 88 150 502 minecraft:quartz_block
fill 85 149 493 85 149 499 minecraft:quartz_block
fill 85 149 503 88 150 503 minecraft:quartz_block
fill 86 149 493 86 149 495 minecraft:quartz_block
fill 86 149 497 86 149 499 minecraft:quartz_block
fill 87 149 494 88 149 495 minecraft:quartz_block
fill 87 149 498 87 149 499 minecraft:quartz_block
setblock 88 149 499 minecraft:quartz_block
fill 88 149 504 88 150 504 minecraft:quartz_block
setblock 47 150 466 minecraft:light_gray_concrete
fill 47 150 468 47 151 469 minecraft:gray_concrete
fill 47 150 470 47 151 470 minecraft:light_gray_concrete
fill 47 150 476 47 151 476 minecraft:gray_concrete
setblock 47 150 483 minecraft:light_gray_concrete
fill 47 150 484 47 154 484 minecraft:gray_concrete
setblock 47 150 489 minecraft:light_gray_concrete
fill 47 150 490 47 150 492 minecraft:gray_concrete
fill 47 150 493 47 150 494 minecraft:light_gray_concrete
fill 47 150 495 47 151 497 minecraft:gray_concrete
fill 47 150 500 47 150 501 minecraft:light_gray_concrete
setblock 48 150 463 minecraft:light_gray_concrete
fill 49 150 463 49 153 463 minecraft:gray_concrete
fill 49 150 466 49 150 468 minecraft:gray_concrete
fill 50 150 463 51 150 463 minecraft:light_gray_concrete
fill 50 150 465 52 150 465 minecraft:gray_concrete
fill 50 150 469 53 150 469 minecraft:gray_concrete
fill 50 150 505 50 151 505 minecraft:gray_concrete
setblock 53 150 466 minecraft:gray_concrete
setblock 53 150 468 minecraft:gray_concrete
fill 54 150 463 56 153 463 minecraft:gray_concrete
setblock 57 150 463 minecraft:light_gray_concrete
fill 58 150 463 58 154 463 minecraft:gray_concrete
fill 58 150 505 58 153 505 minecraft:gray_concrete
setblock 59 150 463 minecraft:light_gray_concrete
fill 62 150 463 62 153 463 minecraft:gray_concrete
fill 66 150 505 66 153 505 minecraft:gray_concrete
setblock 67 150 505 minecraft:light_gray_concrete
fill 68 150 505 69 150 505 minecraft:gray_concrete
setblock 70 150 463 minecraft:gray_concrete
fill 73 150 505 74 150 505 minecraft:light_gray_concrete
fill 77 150 500 83 150 501 minecraft:quartz_block
fill 78 150 463 78 153 463 minecraft:gray_concrete
fill 78 150 502 83 150 503 minecraft:quartz_block
setblock 78 150 505 minecraft:light_gray_concrete
fill 80 150 504 85 150 504 minecraft:quartz_block
fill 82 150 505 82 153 505 minecraft:gray_concrete
setblock 83 150 467 minecraft:gray_concrete
setblock 83 150 470 minecraft:gray_concrete
fill 83 150 489 83 150 496 minecraft:black_concrete
setblock 84 150 463 minecraft:gray_concrete
fill 84 150 466 85 150 466 minecraft:gray_concrete
fill 84 150 471 85 150 471 minecraft:gray_concrete
fill 84 150 498 84 150 500 minecraft:quartz_block
setblock 84 150 503 minecraft:quartz_block
setblock 85 150 463 minecraft:light_gray_concrete
fill 85 150 499 85 150 500 minecraft:quartz_block
fill 86 150 463 86 153 463 minecraft:gray_concrete
setblock 86 150 467 minecraft:gray_concrete
setblock 86 150 470 minecraft:gray_concrete
setblock 86 150 500 minecraft:quartz_block
fill 87 150 468 87 150 469 minecraft:gray_concrete
fill 88 150 463 88 153 463 minecraft:gray_concrete
setblock 89 150 463 minecraft:light_gray_concrete
fill 89 150 468 89 153 468 minecraft:gray_concrete
fill 89 150 474 89 150 475 minecraft:light_gray_concrete
fill 89 150 476 89 153 476 minecraft:gray_concrete
setblock 89 150 482 minecraft:light_gray_concrete
setblock 89 150 484 minecraft:gray_concrete
setblock 89 150 490 minecraft:light_gray_concrete
fill 89 150 491 89 151 496 minecraft:gray_concrete
setblock 89 150 497 minecraft:light_gray_concrete
fill 89 150 498 89 150 500 minecraft:gray_concrete
fill 47 151 466 47 153 466 minecraft:gray_concrete
setblock 47 151 477 minecraft:light_gray_concrete
fill 47 151 480 47 153 480 minecraft:gray_concrete
setblock 47 151 481 minecraft:light_gray_concrete
fill 47 151 483 47 153 483 minecraft:gray_concrete
setblock 47 151 487 minecraft:light_gray_concrete
fill 47 151 489 47 153 490 minecraft:gray_concrete
setblock 47 151 491 minecraft:light_gray_concrete
fill 47 151 492 47 153 493 minecraft:gray_concrete
setblock 47 151 494 minecraft:light_gray_concrete
fill 47 151 500 47 153 501 minecraft:gray_concrete
fill 48 151 463 48 153 463 minecraft:gray_concrete
fill 50 151 463 50 153 463 minecraft:gray_concrete
setblock 51 151 463 minecraft:light_gray_concrete
fill 52 151 463 52 153 463 minecraft:gray_concrete
setblock 53 151 463 minecraft:light_gray_concrete
fill 57 151 463 57 153 463 minecraft:gray_concrete
fill 59 151 463 59 153 463 minecraft:gray_concrete
fill 67 151 505 67 154 505 minecraft:gray_concrete
setblock 68 151 505 minecraft:light_gray_concrete
fill 69 151 505 69 153 505 minecraft:gray_concrete
setblock 70 151 463 minecraft:light_gray_concrete
fill 71 151 505 71 152 505 minecraft:light_gray_concrete
setblock 72 151 463 minecraft:light_gray_concrete
fill 72 151 500 79 151 500 minecraft:quartz_block
fill 73 151 501 77 151 504 minecraft:quartz_block
fill 73 151 505 74 151 505 minecraft:gray_concrete
fill 78 151 501 80 151 503 minecraft:quartz_block
fill 78 151 505 78 153 505 minecraft:gray_concrete
fill 79 151 499 83 151 499 minecraft:black_concrete
fill 80 151 504 82 151 504 minecraft:quartz_block
fill 81 151 502 81 151 503 minecraft:quartz_block
fill 83 151 494 83 151 498 minecraft:black_concrete
setblock 84 151 463 minecraft:light_gray_concrete
fill 85 151 463 85 153 463 minecraft:gray_concrete
fill 89 151 463 89 154 463 minecraft:gray_concrete
fill 89 151 474 89 153 475 minecraft:gray_concrete
setblock 89 151 481 minecraft:light_gray_concrete
fill 89 151 482 89 153 482 minecraft:gray_concrete
setblock 89 151 484 minecraft:light_gray_concrete
fill 89 151 490 89 153 490 minecraft:gray_concrete
fill 89 151 497 89 153 497 minecraft:gray_concrete
setblock 89 151 498 minecraft:light_gray_concrete
fill 89 151 499 89 153 500 minecraft:gray_concrete
setblock 89 151 505 minecraft:light_gray_concrete
fill 47 152 468 47 153 468 minecraft:gray_concrete
setblock 47 152 469 minecraft:light_gray_concrete
fill 47 152 470 47 153 470 minecraft:gray_concrete
setblock 47 152 476 minecraft:light_gray_concrete
fill 47 152 477 47 153 477 minecraft:gray_concrete
fill 47 152 481 47 153 481 minecraft:gray_concrete
setblock 47 152 482 minecraft:light_gray_concrete
setblock 47 152 486 minecraft:light_gray_concrete
fill 47 152 487 47 153 487 minecraft:gray_concrete
fill 47 152 491 47 153 491 minecraft:gray_concrete
fill 47 152 494 47 153 496 minecraft:gray_concrete
setblock 47 152 497 minecraft:light_gray_concrete
setblock 50 152 505 minecraft:light_gray_concrete
fill 51 152 463 51 153 463 minecraft:gray_concrete
fill 53 152 463 53 153 463 minecraft:gray_concrete
fill 54 152 505 55 154 505 minecraft:gray_concrete
fill 56 152 505 57 152 505 minecraft:light_gray_concrete
fill 63 152 463 64 153 463 minecraft:gray_concrete
setblock 65 152 463 minecraft:light_gray_concrete
fill 68 152 500 69 153 504 minecraft:quartz_block
fill 68 152 505 68 153 505 minecraft:gray_concrete
fill 70 152 463 70 153 463 minecraft:gray_concrete
fill 70 152 500 74 152 503 minecraft:quartz_block
fill 72 152 463 72 154 463 minecraft:gray_concrete
fill 72 152 504 76 152 504 minecraft:quartz_block
fill 73 152 505 73 153 505 minecraft:gray_concrete
setblock 74 152 505 minecraft:light_gray_concrete
fill 75 152 499 82 152 499 minecraft:black_concrete
fill 75 152 502 75 152 503 minecraft:quartz_block
fill 84 152 463 84 153 463 minecraft:gray_concrete
fill 89 152 481 89 153 481 minecraft:gray_concrete
fill 89 152 484 89 154 484 minecraft:gray_concrete
fill 89 152 491 89 153 491 minecraft:gray_concrete
setblock 89 152 492 minecraft:light_gray_concrete
fill 89 152 493 89 153 494 minecraft:gray_concrete
setblock 89 152 495 minecraft:light_gray_concrete
fill 89 152 496 89 153 496 minecraft:gray_concrete
fill 89 152 498 89 153 498 minecraft:gray_concrete
fill 89 152 505 89 153 505 minecraft:gray_concrete
setblock 47 153 469 minecraft:gray_concrete
setblock 47 153 476 minecraft:gray_concrete
fill 47 153 482 47 154 482 minecraft:gray_concrete
setblock 47 153 486 minecraft:gray_concrete
setblock 47 153 497 minecraft:gray_concrete
setblock 50 153 474 minecraft:light[level=14]
setblock 50 153 482 minecraft:light[level=14]
setblock 50 153 490 minecraft:light[level=14]
setblock 50 153 498 minecraft:light[level=14]
setblock 50 153 505 minecraft:gray_concrete
fill 56 153 505 57 153 505 minecraft:gray_concrete
setblock 58 153 466 minecraft:light[level=14]
setblock 58 153 474 minecraft:light[level=14]
setblock 58 153 482 minecraft:light[level=14]
setblock 58 153 490 minecraft:light[level=14]
setblock 58 153 498 minecraft:light[level=14]
fill 63 153 501 63 153 503 minecraft:iron_block
fill 64 153 501 67 153 504 minecraft:quartz_block
setblock 65 153 463 minecraft:gray_concrete
fill 65 153 500 67 153 500 minecraft:quartz_block
setblock 66 153 466 minecraft:light[level=14]
setblock 66 153 474 minecraft:light[level=14]
setblock 66 153 482 minecraft:light[level=14]
setblock 66 153 490 minecraft:light[level=14]
setblock 66 153 498 minecraft:light[level=14]
fill 70 153 500 70 153 503 minecraft:quartz_block
fill 71 153 499 76 153 499 minecraft:black_concrete
setblock 71 153 505 minecraft:gray_concrete
setblock 74 153 466 minecraft:light[level=14]
setblock 74 153 474 minecraft:light[level=14]
setblock 74 153 482 minecraft:light[level=14]
setblock 74 153 490 minecraft:light[level=14]
setblock 74 153 498 minecraft:light[level=14]
fill 74 153 505 74 154 505 minecraft:gray_concrete
setblock 82 153 466 minecraft:light[level=14]
setblock 82 153 474 minecraft:light[level=14]
setblock 82 153 482 minecraft:light[level=14]
setblock 82 153 490 minecraft:light[level=14]
setblock 82 153 498 minecraft:light[level=14]
fill 85 153 472 87 153 472 minecraft:iron_block
setblock 89 153 492 minecraft:gray_concrete
setblock 89 153 495 minecraft:gray_concrete
fill 47 154 463 47 227 464 minecraft:light_gray_concrete
fill 47 154 466 47 230 466 minecraft:light_gray_concrete
fill 47 154 468 47 154 481 minecraft:light_gray_concrete
fill 47 154 483 47 230 483 minecraft:light_gray_concrete
fill 47 154 485 47 154 497 minecraft:light_gray_concrete
fill 47 154 499 47 155 505 minecraft:light_gray_concrete
fill 48 154 463 57 155 463 minecraft:light_gray_concrete
fill 48 154 464 48 155 469 minecraft:quartz_block
fill 48 154 472 49 154 477 minecraft:quartz_block
fill 48 154 480 49 154 485 minecraft:quartz_block
fill 48 154 488 49 154 493 minecraft:quartz_block
fill 48 154 496 49 154 501 minecraft:quartz_block
fill 48 154 504 53 156 504 minecraft:quartz_block
setblock 48 154 505 minecraft:gray_concrete
fill 49 154 465 49 154 471 minecraft:quartz_block
fill 49 154 478 49 154 479 minecraft:quartz_block
fill 49 154 486 49 154 487 minecraft:quartz_block
fill 49 154 494 49 154 495 minecraft:quartz_block
fill 49 154 502 49 154 503 minecraft:quartz_block
fill 49 154 505 51 154 505 minecraft:light_gray_concrete
fill 50 154 465 87 154 465 minecraft:quartz_block
fill 50 154 503 88 154 503 minecraft:quartz_block
fill 51 154 464 56 155 464 minecraft:quartz_block
fill 53 154 505 53 230 505 minecraft:light_gray_concrete
fill 56 154 504 61 155 504 minecraft:quartz_block
fill 56 154 505 60 154 505 minecraft:light_gray_concrete
fill 59 154 463 70 155 463 minecraft:light_gray_concrete
fill 59 154 464 64 155 464 minecraft:quartz_block
fill 59 154 502 66 154 502 minecraft:quartz_block
fill 60 154 500 66 154 501 minecraft:quartz_block
setblock 61 154 505 minecraft:gray_concrete
fill 62 154 505 66 154 505 minecraft:light_gray_concrete
fill 64 154 504 69 155 504 minecraft:quartz_block
fill 67 154 464 72 155 464 minecraft:quartz_block
fill 67 154 499 72 154 499 minecraft:black_concrete
fill 68 154 505 73 226 505 minecraft:light_gray_concrete
fill 72 154 504 77 155 504 minecraft:quartz_block
fill 73 154 463 79 154 463 minecraft:light_gray_concrete
fill 75 154 464 80 155 464 minecraft:quartz_block
fill 75 154 505 89 154 505 minecraft:light_gray_concrete
setblock 80 154 463 minecraft:gray_concrete
fill 80 154 504 85 155 504 minecraft:quartz_block
fill 81 154 463 88 155 463 minecraft:light_gray_concrete
fill 83 154 464 88 155 464 minecraft:quartz_block
fill 85 154 472 86 154 472 minecraft:iron_block
fill 87 154 466 87 154 502 minecraft:quartz_block
fill 88 154 467 88 155 472 minecraft:quartz_block
fill 88 154 475 88 155 480 minecraft:quartz_block
fill 88 154 483 88 155 488 minecraft:quartz_block
fill 88 154 491 88 155 496 minecraft:quartz_block
fill 88 154 499 88 155 502 minecraft:quartz_block
fill 88 154 504 88 155 504 minecraft:quartz_block
setblock 89 154 464 minecraft:gray_concrete
fill 89 154 465 89 226 466 minecraft:light_gray_concrete
fill 89 154 468 89 157 472 minecraft:light_gray_concrete
fill 89 154 474 89 154 482 minecraft:light_gray_concrete
fill 89 154 486 89 154 498 minecraft:light_gray_concrete
fill 89 154 499 89 155 499 minecraft:gray_concrete
fill 89 154 500 89 154 504 minecraft:light_gray_concrete
fill 47 155 465 47 228 465 minecraft:light_gray_concrete
fill 47 155 468 47 157 478 minecraft:light_gray_concrete
setblock 47 155 479 minecraft:gray_concrete
fill 47 155 480 47 227 482 minecraft:light_gray_concrete
fill 47 155 484 47 155 491 minecraft:light_gray_concrete
setblock 47 155 492 minecraft:gray_concrete
fill 47 155 493 47 230 493 minecraft:light_gray_concrete
fill 47 155 494 47 155 495 minecraft:gray_concrete
fill 47 155 496 47 227 498 minecraft:light_gray_concrete
fill 48 155 472 48 155 477 minecraft:quartz_block
fill 48 155 480 48 155 485 minecraft:quartz_block
fill 48 155 488 48 155 493 minecraft:quartz_block
fill 48 155 496 48 155 501 minecraft:quartz_block
fill 48 155 505 50 157 505 minecraft:light_gray_concrete
setblock 51 155 505 minecraft:gray_concrete
fill 52 155 503 61 155 503 minecraft:quartz_block
fill 53 155 501 61 155 502 minecraft:quartz_block
fill 54 155 500 62 155 500 minecraft:quartz_block
fill 54 155 505 57 155 505 minecraft:light_gray_concrete
fill 58 155 463 58 231 463 minecraft:light_gray_concrete
setblock 58 155 505 minecraft:gray_concrete
fill 59 155 505 63 155 505 minecraft:light_gray_concrete
setblock 62 155 501 minecraft:quartz_block
fill 63 155 499 68 155 499 minecraft:black_concrete
setblock 64 155 505 minecraft:gray_concrete
fill 65 155 505 67 155 505 minecraft:light_gray_concrete
fill 71 155 463 75 155 463 minecraft:light_gray_concrete
fill 74 155 505 85 155 505 minecraft:light_gray_concrete
setblock 76 155 463 minecraft:gray_concrete
fill 77 155 463 80 157 463 minecraft:light_gray_concrete
setblock 86 155 505 minecraft:gray_concrete
fill 87 155 505 89 227 505 minecraft:light_gray_concrete
setblock 88 155 503 minecraft:quartz_block
fill 89 155 463 89 228 464 minecraft:light_gray_concrete
fill 89 155 467 89 230 467 minecraft:light_gray_concrete
fill 89 155 473 89 155 481 minecraft:light_gray_concrete
setblock 89 155 482 minecraft:gray_concrete
fill 89 155 483 89 155 487 minecraft:light_gray_concrete
fill 89 155 488 89 155 489 minecraft:gray_concrete
fill 89 155 490 89 155 498 minecraft:light_gray_concrete
fill 89 155 500 89 157 500 minecraft:light_gray_concrete
setblock 89 155 501 minecraft:gray_concrete
fill 89 155 502 89 230 504 minecraft:light_gray_concrete
fill 47 156 467 47 230 467 minecraft:light_gray_concrete
fill 47 156 479 47 230 479 minecraft:light_gray_concrete
fill 47 156 484 47 157 486 minecraft:light_gray_concrete
setblock 47 156 487 minecraft:gray_concrete
fill 47 156 488 47 230 488 minecraft:light_gray_concrete
setblock 47 156 489 minecraft:gray_concrete
fill 47 156 490 47 157 492 minecraft:light_gray_concrete
fill 47 156 494 47 227 495 minecraft:light_gray_concrete
fill 47 156 499 47 157 504 minecraft:light_gray_concrete
setblock 47 156 505 minecraft:gray_concrete
fill 48 156 463 54 157 463 minecraft:light_gray_concrete
fill 48 156 498 52 156 501 minecraft:quartz_block
fill 49 156 502 55 156 503 minecraft:quartz_block
fill 50 156 497 52 157 497 minecraft:quartz_block
fill 51 156 496 52 157 496 minecraft:quartz_block
fill 51 156 505 52 228 505 minecraft:light_gray_concrete
fill 53 156 500 56 156 501 minecraft:quartz_block
fill 54 156 505 55 226 505 minecraft:light_gray_concrete
setblock 55 156 463 minecraft:gray_concrete
fill 56 156 463 57 226 463 minecraft:light_gray_concrete
setblock 56 156 502 minecraft:quartz_block
setblock 56 156 505 minecraft:gray_concrete
setblock 57 156 500 minecraft:quartz_block
fill 57 156 505 61 157 505 minecraft:light_gray_concrete
fill 59 156 463 61 227 463 minecraft:light_gray_concrete
fill 59 156 499 65 156 499 minecraft:black_concrete
setblock 62 156 463 minecraft:gray_concrete
setblock 62 156 505 minecraft:gray_concrete
fill 63 156 463 72 157 463 minecraft:light_gray_concrete
fill 63 156 505 65 230 505 minecraft:light_gray_concrete
setblock 66 156 505 minecraft:gray_concrete
fill 67 156 505 67 230 505 minecraft:light_gray_concrete
setblock 73 156 463 minecraft:gray_concrete
fill 74 156 463 76 226 463 minecraft:light_gray_concrete
setblock 74 156 505 minecraft:gray_concrete
fill 75 156 505 81 226 505 minecraft:light_gray_concrete
fill 81 156 463 82 156 463 minecraft:gray_concrete
setblock 82 156 505 minecraft:gray_concrete
fill 83 156 463 88 157 463 minecraft:light_gray_concrete
fill 83 156 505 86 230 505 minecraft:light_gray_concrete
fill 89 156 473 89 157 477 minecraft:light_gray_concrete
setblock 89 156 478 minecraft:gray_concrete
fill 89 156 479 89 227 482 minecraft:light_gray_concrete
setblock 89 156 483 minecraft:gray_concrete
fill 89 156 484 89 157 485 minecraft:light_gray_concrete
setblock 89 156 486 minecraft:gray_concrete
fill 89 156 487 89 226 489 minecraft:light_gray_concrete
setblock 89 156 490 minecraft:gray_concrete
fill 89 156 491 89 157 499 minecraft:light_gray_concrete
fill 89 156 501 89 230 501 minecraft:light_gray_concrete
fill 47 157 487 47 227 487 minecraft:light_gray_concrete
fill 47 157 489 47 230 489 minecraft:light_gray_concrete
fill 47 157 505 47 227 505 minecraft:light_gray_concrete
fill 48 157 492 52 157 493 minecraft:quartz_block
fill 48 157 496 49 157 501 minecraft:quartz_block
fill 49 157 467 49 158 467 minecraft:black_concrete
fill 49 157 494 52 157 495 minecraft:quartz_block
fill 50 157 469 52 158 469 minecraft:black_concrete
fill 50 157 491 52 158 491 minecraft:quartz_block
setblock 50 157 496 minecraft:quartz_block
fill 50 157 498 50 157 500 minecraft:quartz_block
fill 51 157 465 52 158 465 minecraft:black_concrete
fill 51 157 498 51 157 499 minecraft:quartz_block
setblock 52 157 498 minecraft:quartz_block
fill 53 157 466 53 158 466 minecraft:black_concrete
fill 53 157 468 53 158 468 minecraft:black_concrete
fill 53 157 498 53 158 499 minecraft:black_concrete
fill 54 157 499 61 157 499 minecraft:black_concrete
fill 55 157 463 55 228 463 minecraft:light_gray_concrete
fill 56 157 505 56 226 505 minecraft:light_gray_concrete
setblock 62 157 463 minecraft:light_gray_concrete
fill 62 157 505 62 230 505 minecraft:light_gray_concrete
setblock 66 157 505 minecraft:light_gray_concrete
fill 73 157 463 73 230 463 minecraft:light_gray_concrete
setblock 74 157 505 minecraft:light_gray_concrete
fill 81 157 463 82 226 463 minecraft:light_gray_concrete
setblock 82 157 505 minecraft:light_gray_concrete
fill 83 157 467 83 158 467 minecraft:black_concrete
fill 83 157 470 83 158 470 minecraft:black_concrete
fill 86 157 467 86 158 467 minecraft:black_concrete
fill 86 157 470 86 158 470 minecraft:black_concrete
fill 89 157 478 89 230 478 minecraft:light_gray_concrete
fill 89 157 483 89 227 483 minecraft:light_gray_concrete
fill 89 157 486 89 230 486 minecraft:light_gray_concrete
fill 89 157 490 89 230 490 minecraft:light_gray_concrete
setblock 47 158 468 minecraft:sea_lantern
fill 47 158 469 47 230 475 minecraft:light_gray_concrete
setblock 47 158 476 minecraft:sea_lantern
fill 47 158 477 47 230 478 minecraft:light_gray_concrete
setblock 47 158 484 minecraft:sea_lantern
fill 47 158 485 47 226 486 minecraft:light_gray_concrete
fill 47 158 490 47 228 491 minecraft:light_gray_concrete
setblock 47 158 492 minecraft:sea_lantern
fill 47 158 499 47 230 499 minecraft:light_gray_concrete
setblock 47 158 500 minecraft:sea_lantern
fill 47 158 501 47 226 504 minecraft:light_gray_concrete
fill 48 158 463 53 228 463 minecraft:light_gray_concrete
fill 48 158 488 49 158 493 minecraft:quartz_block
fill 48 158 505 49 228 505 minecraft:light_gray_concrete
fill 49 158 487 52 158 487 minecraft:quartz_block
fill 49 158 494 50 158 494 minecraft:quartz_block
fill 50 158 488 52 158 490 minecraft:quartz_block
fill 50 158 492 51 158 493 minecraft:quartz_block
setblock 50 158 505 minecraft:sea_lantern
setblock 52 158 486 minecraft:quartz_block
setblock 52 158 492 minecraft:quartz_block
fill 53 158 493 53 158 497 minecraft:black_concrete
setblock 54 158 463 minecraft:sea_lantern
fill 54 158 499 55 158 499 minecraft:black_concrete
fill 57 158 505 57 231 505 minecraft:light_gray_concrete
setblock 58 158 505 minecraft:sea_lantern
fill 59 158 505 61 226 505 minecraft:light_gray_concrete
setblock 62 158 463 minecraft:sea_lantern
fill 63 158 463 69 228 463 minecraft:light_gray_concrete
setblock 66 158 505 minecraft:sea_lantern
setblock 70 158 463 minecraft:sea_lantern
fill 71 158 463 72 230 463 minecraft:light_gray_concrete
setblock 74 158 505 minecraft:sea_lantern
fill 77 158 463 77 226 463 minecraft:light_gray_concrete
setblock 78 158 463 minecraft:sea_lantern
fill 79 158 463 80 230 463 minecraft:light_gray_concrete
setblock 82 158 505 minecraft:sea_lantern
fill 83 158 463 85 228 463 minecraft:light_gray_concrete
setblock 86 158 463 minecraft:sea_lantern
fill 87 158 463 88 227 463 minecraft:light_gray_concrete
setblock 89 158 468 minecraft:sea_lantern
fill 89 158 469 89 226 475 minecraft:light_gray_concrete
setblock 89 158 476 minecraft:sea_lantern
fill 89 158 477 89 226 477 minecraft:light_gray_concrete
setblock 89 158 484 minecraft:sea_lantern
fill 89 158 485 89 230 485 minecraft:light_gray_concrete
fill 89 158 491 89 230 491 minecraft:light_gray_concrete
setblock 89 158 492 minecraft:sea_lantern
fill 89 158 493 89 226 499 minecraft:light_gray_concrete
setblock 89 158 500 minecraft:sea_lantern
fill 47 159 468 47 171 468 minecraft:light_gray_concrete
fill 47 159 476 47 171 476 minecraft:light_gray_concrete
fill 47 159 484 47 171 484 minecraft:light_gray_concrete
fill 47 159 492 47 171 492 minecraft:light_gray_concrete
fill 47 159 500 47 171 500 minecraft:light_gray_concrete
fill 50 159 505 50 171 505 minecraft:light_gray_concrete
fill 54 159 463 54 171 463 minecraft:light_gray_concrete
fill 58 159 505 58 171 505 minecraft:light_gray_concrete
fill 62 159 463 62 171 463 minecraft:light_gray_concrete
fill 66 159 505 66 171 505 minecraft:light_gray_concrete
fill 70 159 463 70 171 463 minecraft:light_gray_concrete
fill 74 159 505 74 171 505 minecraft:light_gray_concrete
fill 78 159 463 78 171 463 minecraft:light_gray_concrete
fill 82 159 505 82 171 505 minecraft:light_gray_concrete
fill 86 159 463 86 171 463 minecraft:light_gray_concrete
fill 89 159 468 89 171 468 minecraft:light_gray_concrete
fill 89 159 476 89 171 476 minecraft:light_gray_concrete
fill 89 159 484 89 171 484 minecraft:light_gray_concrete
fill 89 159 492 89 171 492 minecraft:light_gray_concrete
fill 89 159 500 89 171 500 minecraft:light_gray_concrete
setblock 50 161 466 minecraft:light[level=14]
setblock 50 161 474 minecraft:light[level=14]
setblock 50 161 482 minecraft:light[level=14]
setblock 50 161 490 minecraft:light[level=14]
setblock 50 161 498 minecraft:light[level=14]
setblock 58 161 466 minecraft:light[level=14]
setblock 58 161 474 minecraft:light[level=14]
setblock 58 161 482 minecraft:light[level=14]
setblock 58 161 490 minecraft:light[level=14]
setblock 58 161 498 minecraft:light[level=14]
setblock 66 161 466 minecraft:light[level=14]
setblock 66 161 474 minecraft:light[level=14]
setblock 66 161 482 minecraft:light[level=14]
setblock 66 161 490 minecraft:light[level=14]
setblock 66 161 498 minecraft:light[level=14]
setblock 74 161 466 minecraft:light[level=14]
setblock 74 161 474 minecraft:light[level=14]
setblock 74 161 482 minecraft:light[level=14]
setblock 74 161 490 minecraft:light[level=14]
setblock 74 161 498 minecraft:light[level=14]
setblock 82 161 466 minecraft:light[level=14]
setblock 82 161 474 minecraft:light[level=14]
setblock 82 161 482 minecraft:light[level=14]
setblock 82 161 490 minecraft:light[level=14]
setblock 82 161 498 minecraft:light[level=14]
fill 48 164 464 49 165 465 minecraft:gray_concrete
fill 48 164 466 49 164 468 minecraft:quartz_block
fill 48 164 469 49 164 471 minecraft:gray_concrete
fill 48 164 472 49 164 474 minecraft:quartz_block
fill 48 164 475 49 164 477 minecraft:gray_concrete
fill 48 164 478 49 164 480 minecraft:quartz_block
fill 48 164 481 49 164 483 minecraft:gray_concrete
fill 48 164 484 49 164 486 minecraft:quartz_block
fill 48 164 487 49 164 489 minecraft:gray_concrete
fill 48 164 490 49 164 492 minecraft:quartz_block
fill 48 164 493 49 164 495 minecraft:gray_concrete
fill 48 164 496 49 164 498 minecraft:quartz_block
fill 48 164 499 49 164 501 minecraft:gray_concrete
fill 48 164 502 49 164 504 minecraft:quartz_block
fill 50 164 464 52 164 465 minecraft:quartz_block
fill 50 164 466 52 164 468 minecraft:gray_concrete
fill 50 164 469 52 164 471 minecraft:quartz_block
fill 50 164 472 52 164 474 minecraft:gray_concrete
fill 50 164 475 52 164 477 minecraft:quartz_block
fill 50 164 478 52 164 480 minecraft:gray_concrete
fill 50 164 481 52 164 483 minecraft:quartz_block
fill 50 164 484 52 164 486 minecraft:gray_concrete
fill 50 164 487 52 164 489 minecraft:quartz_block
fill 50 164 490 52 164 492 minecraft:gray_concrete
fill 50 164 493 52 164 495 minecraft:quartz_block
fill 50 164 496 52 164 498 minecraft:gray_concrete
fill 50 164 499 52 164 501 minecraft:quartz_block
fill 50 164 502 52 164 504 minecraft:gray_concrete
fill 53 164 464 55 164 465 minecraft:gray_concrete
fill 53 164 466 55 164 468 minecraft:quartz_block
fill 53 164 469 55 164 471 minecraft:gray_concrete
fill 53 164 472 55 164 474 minecraft:quartz_block
fill 53 164 475 55 164 477 minecraft:gray_concrete
fill 53 164 478 55 164 480 minecraft:quartz_block
fill 53 164 481 55 164 483 minecraft:gray_concrete
fill 53 164 484 55 164 486 minecraft:quartz_block
fill 53 164 487 55 164 489 minecraft:gray_concrete
fill 53 164 490 55 164 492 minecraft:quartz_block
fill 53 164 493 55 164 495 minecraft:gray_concrete
fill 53 164 496 55 164 498 minecraft:quartz_block
fill 53 164 499 55 164 501 minecraft:gray_concrete
fill 53 164 502 55 164 504 minecraft:quartz_block
fill 56 164 464 58 164 465 minecraft:quartz_block
fill 56 164 466 58 164 468 minecraft:gray_concrete
fill 56 164 469 58 164 471 minecraft:quartz_block
fill 56 164 472 58 164 474 minecraft:gray_concrete
fill 56 164 475 58 164 477 minecraft:quartz_block
fill 56 164 478 58 164 480 minecraft:gray_concrete
fill 56 164 481 58 164 483 minecraft:quartz_block
fill 56 164 484 58 164 486 minecraft:gray_concrete
fill 56 164 487 58 164 489 minecraft:quartz_block
fill 56 164 490 58 164 492 minecraft:gray_concrete
fill 56 164 493 58 164 495 minecraft:quartz_block
fill 56 164 496 58 164 498 minecraft:gray_concrete
fill 56 164 499 58 164 501 minecraft:quartz_block
fill 56 164 502 58 164 504 minecraft:gray_concrete
fill 59 164 464 61 164 465 minecraft:gray_concrete
fill 59 164 466 61 164 468 minecraft:quartz_block
fill 59 164 469 61 164 471 minecraft:gray_concrete
fill 59 164 472 61 164 474 minecraft:quartz_block
fill 59 164 475 61 164 477 minecraft:gray_concrete
fill 59 164 478 61 164 480 minecraft:quartz_block
fill 59 164 481 61 164 483 minecraft:gray_concrete
fill 59 164 484 61 164 486 minecraft:quartz_block
fill 59 164 487 61 164 489 minecraft:gray_concrete
fill 59 164 490 61 164 492 minecraft:quartz_block
fill 59 164 493 61 164 495 minecraft:gray_concrete
fill 59 164 496 61 164 498 minecraft:quartz_block
fill 59 164 499 61 164 501 minecraft:gray_concrete
fill 59 164 502 61 164 504 minecraft:quartz_block
fill 62 164 464 64 164 465 minecraft:quartz_block
fill 62 164 466 64 164 468 minecraft:gray_concrete
fill 62 164 469 64 164 471 minecraft:quartz_block
fill 62 164 472 64 164 474 minecraft:gray_concrete
fill 62 164 475 64 164 477 minecraft:quartz_block
fill 62 164 478 64 164 480 minecraft:gray_concrete
fill 62 164 481 64 164 483 minecraft:quartz_block
fill 62 164 484 64 164 486 minecraft:gray_concrete
fill 62 164 487 64 164 489 minecraft:quartz_block
fill 62 164 490 64 164 492 minecraft:gray_concrete
fill 62 164 493 64 164 495 minecraft:quartz_block
fill 62 164 496 64 164 498 minecraft:gray_concrete
fill 62 164 499 64 164 501 minecraft:quartz_block
fill 62 164 502 64 164 504 minecraft:gray_concrete
fill 65 164 464 67 164 465 minecraft:gray_concrete
fill 65 164 466 67 164 468 minecraft:quartz_block
fill 65 164 469 67 164 471 minecraft:gray_concrete
fill 65 164 472 67 164 474 minecraft:quartz_block
fill 65 164 475 67 164 477 minecraft:gray_concrete
fill 65 164 478 67 164 480 minecraft:quartz_block
fill 65 164 481 67 164 483 minecraft:gray_concrete
fill 65 164 484 67 164 486 minecraft:quartz_block
fill 65 164 487 67 164 489 minecraft:gray_concrete
fill 65 164 490 67 164 492 minecraft:quartz_block
fill 65 164 493 67 164 495 minecraft:gray_concrete
fill 65 164 496 67 164 498 minecraft:quartz_block
fill 65 164 499 67 164 501 minecraft:gray_concrete
fill 65 164 502 67 164 504 minecraft:quartz_block
fill 68 164 464 70 164 465 minecraft:quartz_block
fill 68 164 466 70 164 468 minecraft:gray_concrete
fill 68 164 469 70 164 471 minecraft:quartz_block
fill 68 164 472 70 164 474 minecraft:gray_concrete
fill 68 164 475 70 164 477 minecraft:quartz_block
fill 68 164 478 70 164 480 minecraft:gray_concrete
fill 68 164 481 70 164 483 minecraft:quartz_block
fill 68 164 484 70 164 486 minecraft:gray_concrete
fill 68 164 487 70 164 489 minecraft:quartz_block
fill 68 164 490 70 164 492 minecraft:gray_concrete
fill 68 164 493 70 164 495 minecraft:quartz_block
fill 68 164 496 70 164 498 minecraft:gray_concrete
fill 68 164 499 70 164 501 minecraft:quartz_block
fill 68 164 502 70 164 504 minecraft:gray_concrete
fill 71 164 464 73 164 465 minecraft:gray_concrete
fill 71 164 466 73 164 468 minecraft:quartz_block
fill 71 164 469 73 164 471 minecraft:gray_concrete
fill 71 164 472 73 164 474 minecraft:quartz_block
fill 71 164 475 73 164 477 minecraft:gray_concrete
fill 71 164 478 73 164 480 minecraft:quartz_block
fill 71 164 481 73 164 483 minecraft:gray_concrete
fill 71 164 484 72 164 486 minecraft:quartz_block
fill 71 164 487 71 164 489 minecraft:gray_concrete
fill 71 164 490 73 164 492 minecraft:quartz_block
fill 71 164 493 73 164 495 minecraft:gray_concrete
fill 71 164 496 73 164 498 minecraft:quartz_block
fill 71 164 499 73 164 501 minecraft:gray_concrete
fill 71 164 502 73 164 504 minecraft:quartz_block
fill 72 164 488 72 164 489 minecraft:gray_concrete
fill 73 164 484 73 164 485 minecraft:quartz_block
setblock 73 164 489 minecraft:gray_concrete
fill 74 164 464 76 164 465 minecraft:quartz_block
fill 74 164 466 76 164 468 minecraft:gray_concrete
fill 74 164 469 76 164 471 minecraft:quartz_block
fill 74 164 472 76 164 474 minecraft:gray_concrete
fill 74 164 475 76 164 477 minecraft:quartz_block
fill 74 164 478 76 164 480 minecraft:gray_concrete
fill 74 164 481 76 164 483 minecraft:quartz_block
fill 74 164 484 76 164 484 minecraft:gray_concrete
fill 74 164 490 76 164 492 minecraft:gray_concrete
fill 74 164 493 76 164 495 minecraft:quartz_block
fill 74 164 496 76 164 498 minecraft:gray_concrete
fill 74 164 499 76 164 501 minecraft:quartz_block
fill 74 164 502 76 164 504 minecraft:gray_concrete
fill 75 164 485 76 164 485 minecraft:gray_concrete
fill 75 164 489 76 164 489 minecraft:quartz_block
setblock 76 164 486 minecraft:gray_concrete
setblock 76 164 488 minecraft:quartz_block
fill 77 164 464 79 164 465 minecraft:gray_concrete
fill 77 164 466 79 164 468 minecraft:quartz_block
fill 77 164 469 79 164 471 minecraft:gray_concrete
fill 77 164 472 79 164 474 minecraft:quartz_block
fill 77 164 475 79 164 477 minecraft:gray_concrete
fill 77 164 478 79 164 480 minecraft:quartz_block
fill 77 164 481 79 164 483 minecraft:gray_concrete
fill 77 164 484 79 164 486 minecraft:quartz_block
fill 77 164 487 79 164 489 minecraft:gray_concrete
fill 77 164 490 79 164 492 minecraft:quartz_block
fill 77 164 493 79 164 495 minecraft:gray_concrete
fill 77 164 496 79 164 498 minecraft:quartz_block
fill 77 164 499 79 164 501 minecraft:gray_concrete
fill 77 164 502 79 164 504 minecraft:quartz_block
fill 80 164 464 82 164 465 minecraft:quartz_block
fill 80 164 466 82 164 468 minecraft:gray_concrete
fill 80 164 469 82 164 471 minecraft:quartz_block
fill 80 164 472 82 164 474 minecraft:gray_concrete
fill 80 164 475 82 164 477 minecraft:quartz_block
fill 80 164 478 82 164 480 minecraft:gray_concrete
fill 80 164 481 82 164 483 minecraft:quartz_block
fill 80 164 484 82 164 486 minecraft:gray_concrete
fill 80 164 487 82 164 489 minecraft:quartz_block
fill 80 164 490 82 164 492 minecraft:gray_concrete
fill 80 164 493 82 164 495 minecraft:quartz_block
fill 80 164 496 82 164 498 minecraft:gray_concrete
fill 80 164 499 82 164 501 minecraft:quartz_block
fill 80 164 502 82 164 504 minecraft:gray_concrete
fill 83 164 464 85 164 465 minecraft:gray_concrete
fill 83 164 466 85 164 468 minecraft:quartz_block
fill 83 164 469 85 164 471 minecraft:gray_concrete
fill 83 164 472 85 164 474 minecraft:quartz_block
fill 83 164 475 85 164 477 minecraft:gray_concrete
fill 83 164 478 85 164 480 minecraft:quartz_block
fill 83 164 481 85 164 483 minecraft:gray_concrete
fill 83 164 484 85 164 486 minecraft:quartz_block
fill 83 164 487 85 164 489 minecraft:gray_concrete
fill 83 164 490 85 164 492 minecraft:quartz_block
fill 83 164 493 85 164 495 minecraft:gray_concrete
fill 83 164 496 85 164 498 minecraft:quartz_block
fill 83 164 499 85 164 501 minecraft:gray_concrete
fill 83 164 502 85 164 504 minecraft:quartz_block
fill 86 164 464 88 164 465 minecraft:quartz_block
fill 86 164 466 88 164 468 minecraft:gray_concrete
fill 86 164 469 88 164 471 minecraft:quartz_block
fill 86 164 472 88 164 474 minecraft:gray_concrete
fill 86 164 475 88 164 477 minecraft:quartz_block
fill 86 164 478 88 164 480 minecraft:gray_concrete
fill 86 164 481 88 164 483 minecraft:quartz_block
fill 86 164 484 88 164 486 minecraft:gray_concrete
fill 86 164 487 88 164 489 minecraft:quartz_block
fill 86 164 490 88 164 492 minecraft:gray_concrete
fill 86 164 493 88 164 495 minecraft:quartz_block
fill 86 164 496 88 164 498 minecraft:gray_concrete
fill 86 164 499 88 164 501 minecraft:quartz_block
fill 86 164 502 88 164 504 minecraft:gray_concrete
fill 48 165 466 88 165 466 minecraft:black_concrete
fill 48 165 467 49 165 468 minecraft:quartz_block
fill 48 165 469 88 165 469 minecraft:black_concrete
fill 48 165 470 49 165 471 minecraft:gray_concrete
fill 48 165 472 88 165 472 minecraft:black_concrete
fill 48 165 473 49 165 474 minecraft:quartz_block
fill 48 165 475 88 165 475 minecraft:black_concrete
fill 48 165 476 49 165 477 minecraft:gray_concrete
fill 48 165 478 88 165 478 minecraft:black_concrete
fill 48 165 479 49 165 480 minecraft:quartz_block
fill 48 165 481 88 165 481 minecraft:black_concrete
fill 48 165 482 49 165 483 minecraft:gray_concrete
fill 48 165 484 72 165 484 minecraft:black_concrete
fill 48 165 485 49 165 486 minecraft:quartz_block
fill 48 165 487 70 165 487 minecraft:black_concrete
fill 48 165 488 49 165 489 minecraft:gray_concrete
fill 48 165 490 72 165 490 minecraft:black_concrete
fill 48 165 491 49 165 492 minecraft:quartz_block
fill 48 165 493 88 165 493 minecraft:black_concrete
fill 48 165 494 49 165 495 minecraft:gray_concrete
fill 48 165 496 88 165 496 minecraft:black_concrete
fill 48 165 497 49 165 498 minecraft:quartz_block
fill 48 165 499 88 165 499 minecraft:black_concrete
fill 48 165 500 49 165 501 minecraft:gray_concrete
fill 48 165 502 88 165 502 minecraft:black_concrete
fill 48 165 503 49 165 504 minecraft:quartz_block
fill 50 165 464 50 165 465 minecraft:black_concrete
fill 50 165 467 50 165 468 minecraft:black_concrete
fill 50 165 470 50 165 471 minecraft:black_concrete
fill 50 165 473 50 165 474 minecraft:black_concrete
fill 50 165 476 50 165 477 minecraft:black_concrete
fill 50 165 479 50 165 480 minecraft:black_concrete
fill 50 165 482 50 165 483 minecraft:black_concrete
fill 50 165 485 50 165 486 minecraft:black_concrete
fill 50 165 488 50 165 489 minecraft:black_concrete
fill 50 165 491 50 165 492 minecraft:black_concrete
fill 50 165 494 50 165 495 minecraft:black_concrete
fill 50 165 497 50 165 498 minecraft:black_concrete
fill 50 165 500 50 165 501 minecraft:black_concrete
fill 50 165 503 50 165 504 minecraft:black_concrete
fill 51 165 464 52 165 465 minecraft:quartz_block
fill 51 165 467 52 165 468 minecraft:gray_concrete
fill 51 165 470 52 165 471 minecraft:quartz_block
fill 51 165 473 52 165 474 minecraft:gray_concrete
fill 51 165 476 52 165 477 minecraft:quartz_block
fill 51 165 479 52 165 480 minecraft:gray_concrete
fill 51 165 482 52 165 483 minecraft:quartz_block
fill 51 165 485 52 165 486 minecraft:gray_concrete
fill 51 165 488 52 165 489 minecraft:quartz_block
fill 51 165 491 52 165 492 minecraft:gray_concrete
fill 51 165 494 52 165 495 minecraft:quartz_block
fill 51 165 497 52 165 498 minecraft:gray_concrete
fill 51 165 500 52 165 501 minecraft:quartz_block
fill 51 165 503 52 165 504 minecraft:gray_concrete
fill 53 165 464 53 165 465 minecraft:black_concrete
fill 53 165 467 53 165 468 minecraft:black_concrete
fill 53 165 470 53 165 471 minecraft:black_concrete
fill 53 165 473 53 165 474 minecraft:black_concrete
fill 53 165 476 53 165 477 minecraft:black_concrete
fill 53 165 479 53 165 480 minecraft:black_concrete
fill 53 165 482 53 165 483 minecraft:black_concrete
fill 53 165 485 53 165 486 minecraft:black_concrete
fill 53 165 488 53 165 489 minecraft:black_concrete
fill 53 165 491 53 165 492 minecraft:black_concrete
fill 53 165 494 53 165 495 minecraft:black_concrete
fill 53 165 497 53 165 498 minecraft:black_concrete
fill 53 165 500 53 165 501 minecraft:black_concrete
fill 53 165 503 53 165 504 minecraft:black_concrete
fill 54 165 464 55 165 465 minecraft:gray_concrete
fill 54 165 467 55 165 468 minecraft:quartz_block
fill 54 165 470 55 165 471 minecraft:gray_concrete
fill 54 165 473 55 165 474 minecraft:quartz_block
fill 54 165 476 55 165 477 minecraft:gray_concrete
fill 54 165 479 55 165 480 minecraft:quartz_block
fill 54 165 482 55 165 483 minecraft:gray_concrete
fill 54 165 485 55 165 486 minecraft:quartz_block
fill 54 165 488 55 165 489 minecraft:gray_concrete
fill 54 165 491 55 165 492 minecraft:quartz_block
fill 54 165 494 55 165 495 minecraft:gray_concrete
fill 54 165 497 55 165 498 minecraft:quartz_block
fill 54 165 500 55 165 501 minecraft:gray_concrete
fill 54 165 503 55 165 504 minecraft:quartz_block
fill 56 165 464 56 165 465 minecraft:black_concrete
fill 56 165 467 56 165 468 minecraft:black_concrete
fill 56 165 470 56 165 471 minecraft:black_concrete
fill 56 165 473 56 165 474 minecraft:black_concrete
fill 56 165 476 56 165 477 minecraft:black_concrete
fill 56 165 479 56 165 480 minecraft:black_concrete
fill 56 165 482 56 165 483 minecraft:black_concrete
fill 56 165 485 56 165 486 minecraft:black_concrete
fill 56 165 488 56 165 489 minecraft:black_concrete
fill 56 165 491 56 165 492 minecraft:black_concrete
fill 56 165 494 56 165 495 minecraft:black_concrete
fill 56 165 497 56 165 498 minecraft:black_concrete
fill 56 165 500 56 165 501 minecraft:black_concrete
fill 56 165 503 56 165 504 minecraft:black_concrete
fill 57 165 464 58 165 465 minecraft:quartz_block
fill 57 165 467 58 165 468 minecraft:gray_concrete
fill 57 165 470 58 165 471 minecraft:quartz_block
fill 57 165 473 58 165 474 minecraft:gray_concrete
fill 57 165 476 58 165 477 minecraft:quartz_block
fill 57 165 479 58 165 480 minecraft:gray_concrete
fill 57 165 482 58 165 483 minecraft:quartz_block
fill 57 165 485 58 165 486 minecraft:gray_concrete
fill 57 165 488 58 165 489 minecraft:quartz_block
fill 57 165 491 58 165 492 minecraft:gray_concrete
fill 57 165 494 58 165 495 minecraft:quartz_block
fill 57 165 497 58 165 498 minecraft:gray_concrete
fill 57 165 500 58 165 501 minecraft:quartz_block
fill 57 165 503 58 165 504 minecraft:gray_concrete
fill 59 165 464 59 165 465 minecraft:black_concrete
fill 59 165 467 59 165 468 minecraft:black_concrete
fill 59 165 470 59 165 471 minecraft:black_concrete
fill 59 165 473 59 165 474 minecraft:black_concrete
fill 59 165 476 59 165 477 minecraft:black_concrete
fill 59 165 479 59 165 480 minecraft:black_concrete
fill 59 165 482 59 165 483 minecraft:black_concrete
fill 59 165 485 59 165 486 minecraft:black_concrete
fill 59 165 488 59 165 489 minecraft:black_concrete
fill 59 165 491 59 165 492 minecraft:black_concrete
fill 59 165 494 59 165 495 minecraft:black_concrete
fill 59 165 497 59 165 498 minecraft:black_concrete
fill 59 165 500 59 165 501 minecraft:black_concrete
fill 59 165 503 59 165 504 minecraft:black_concrete
fill 60 165 464 61 165 465 minecraft:gray_concrete
fill 60 165 467 61 165 468 minecraft:quartz_block
fill 60 165 470 61 165 471 minecraft:gray_concrete
fill 60 165 473 61 165 474 minecraft:quartz_block
fill 60 165 476 61 165 477 minecraft:gray_concrete
fill 60 165 479 61 165 480 minecraft:quartz_block
fill 60 165 482 61 165 483 minecraft:gray_concrete
fill 60 165 485 61 165 486 minecraft:quartz_block
fill 60 165 488 61 165 489 minecraft:gray_concrete
fill 60 165 491 61 165 492 minecraft:quartz_block
fill 60 165 494 61 165 495 minecraft:gray_concrete
fill 60 165 497 61 165 498 minecraft:quartz_block
fill 60 165 500 61 165 501 minecraft:gray_concrete
fill 60 165 503 61 165 504 minecraft:quartz_block
fill 62 165 464 62 165 465 minecraft:black_concrete
fill 62 165 467 62 165 468 minecraft:black_concrete
fill 62 165 470 62 165 471 minecraft:black_concrete
fill 62 165 473 62 165 474 minecraft:black_concrete
fill 62 165 476 62 165 477 minecraft:black_concrete
fill 62 165 479 62 165 480 minecraft:black_concrete
fill 62 165 482 62 165 483 minecraft:black_concrete
fill 62 165 485 62 165 486 minecraft:black_concrete
fill 62 165 488 62 165 489 minecraft:black_concrete
fill 62 165 491 62 165 492 minecraft:black_concrete
fill 62 165 494 62 165 495 minecraft:black_concrete
fill 62 165 497 62 165 498 minecraft:black_concrete
fill 62 165 500 62 165 501 minecraft:black_concrete
fill 62 165 503 62 165 504 minecraft:black_concrete
fill 63 165 464 64 165 465 minecraft:quartz_block
fill 63 165 467 64 165 468 minecraft:gray_concrete
fill 63 165 470 64 165 471 minecraft:quartz_block
fill 63 165 473 64 165 474 minecraft:gray_concrete
fill 63 165 476 64 165 477 minecraft:quartz_block
fill 63 165 479 64 165 480 minecraft:gray_concrete
fill 63 165 482 64 165 483 minecraft:quartz_block
fill 63 165 485 64 165 486 minecraft:gray_concrete
fill 63 165 488 64 165 489 minecraft:quartz_block
fill 63 165 491 64 165 492 minecraft:gray_concrete
fill 63 165 494 64 165 495 minecraft:quartz_block
fill 63 165 497 64 165 498 minecraft:gray_concrete
fill 63 165 500 64 165 501 minecraft:quartz_block
fill 63 165 503 64 165 504 minecraft:gray_concrete
fill 65 165 464 65 165 465 minecraft:black_concrete
fill 65 165 467 65 165 468 minecraft:black_concrete
fill 65 165 470 65 165 471 minecraft:black_concrete
fill 65 165 473 65 165 474 minecraft:black_concrete
fill 65 165 476 65 165 477 minecraft:black_concrete
fill 65 165 479 65 165 480 minecraft:black_concrete
fill 65 165 482 65 165 483 minecraft:black_concrete
fill 65 165 485 65 165 486 minecraft:black_concrete
fill 65 165 488 65 165 489 minecraft:black_concrete
fill 65 165 491 65 165 492 minecraft:black_concrete
fill 65 165 494 65 165 495 minecraft:black_concrete
fill 65 165 497 65 165 498 minecraft:black_concrete
fill 65 165 500 65 165 501 minecraft:black_concrete
fill 65 165 503 65 165 504 minecraft:black_concrete
fill 66 165 464 67 165 465 minecraft:gray_concrete
fill 66 165 467 67 165 468 minecraft:quartz_block
fill 66 165 470 67 165 471 minecraft:gray_concrete
fill 66 165 473 67 165 474 minecraft:quartz_block
fill 66 165 476 67 165 477 minecraft:gray_concrete
fill 66 165 479 67 165 480 minecraft:quartz_block
fill 66 165 482 67 165 483 minecraft:gray_concrete
fill 66 165 485 67 165 486 minecraft:quartz_block
fill 66 165 488 67 165 489 minecraft:gray_concrete
fill 66 165 491 67 165 492 minecraft:quartz_block
fill 66 165 494 67 165 495 minecraft:gray_concrete
fill 66 165 497 67 165 498 minecraft:quartz_block
fill 66 165 500 67 165 501 minecraft:gray_concrete
fill 66 165 503 67 165 504 minecraft:quartz_block
fill 68 165 464 68 165 465 minecraft:black_concrete
fill 68 165 467 68 165 468 minecraft:black_concrete
fill 68 165 470 68 165 471 minecraft:black_concrete
fill 68 165 473 68 165 474 minecraft:black_concrete
fill 68 165 476 68 165 477 minecraft:black_concrete
fill 68 165 479 68 165 480 minecraft:black_concrete
fill 68 165 482 68 165 483 minecraft:black_concrete
fill 68 165 485 68 165 486 minecraft:black_concrete
fill 68 165 488 68 165 489 minecraft:black_concrete
fill 68 165 491 68 165 492 minecraft:black_concrete
fill 68 165 494 68 165 495 minecraft:black_concrete
fill 68 165 497 68 165 498 minecraft:black_concrete
fill 68 165 500 68 165 501 minecraft:black_concrete
fill 68 165 503 68 165 504 minecraft:black_concrete
fill 69 165 464 70 165 465 minecraft:quartz_block
fill 69 165 467 70 165 468 minecraft:gray_concrete
fill 69 165 470 70 165 471 minecraft:quartz_block
fill 69 165 473 70 165 474 minecraft:gray_concrete
fill 69 165 476 70 165 477 minecraft:quartz_block
fill 69 165 479 70 165 480 minecraft:gray_concrete
fill 69 165 482 70 165 483 minecraft:quartz_block
fill 69 165 485 70 165 486 minecraft:gray_concrete
fill 69 165 488 70 165 489 minecraft:quartz_block
fill 69 165 491 70 165 492 minecraft:gray_concrete
fill 69 165 494 70 165 495 minecraft:quartz_block
fill 69 165 497 70 165 498 minecraft:gray_concrete
fill 69 165 500 70 165 501 minecraft:quartz_block
fill 69 165 503 70 165 504 minecraft:gray_concrete
fill 71 165 464 71 165 465 minecraft:black_concrete
fill 71 165 467 71 165 468 minecraft:black_concrete
fill 71 165 470 71 165 471 minecraft:black_concrete
fill 71 165 473 71 165 474 minecraft:black_concrete
fill 71 165 476 71 165 477 minecraft:black_concrete
fill 71 165 479 71 165 480 minecraft:black_concrete
fill 71 165 482 71 165 483 minecraft:black_concrete
setblock 71 165 485 minecraft:black_concrete
fill 71 165 486 71 165 488 minecraft:sea_lantern
setblock 71 165 489 minecraft:black_concrete
fill 71 165 491 71 165 492 minecraft:black_concrete
fill 71 165 494 71 165 495 minecraft:black_concrete
fill 71 165 497 71 165 498 minecraft:black_concrete
fill 71 165 500 71 165 501 minecraft:black_concrete
fill 71 165 503 71 165 504 minecraft:black_concrete
fill 72 165 464 73 165 465 minecraft:gray_concrete
fill 72 165 467 73 165 468 minecraft:quartz_block
fill 72 165 470 73 165 471 minecraft:gray_concrete
fill 72 165 473 73 165 474 minecraft:quartz_block
fill 72 165 476 73 165 477 minecraft:gray_concrete
fill 72 165 479 73 165 480 minecraft:quartz_block
fill 72 165 482 73 165 483 minecraft:gray_concrete
fill 72 165 485 72 165 486 minecraft:shroomlight
fill 72 165 488 72 165 489 minecraft:shroomlight
fill 72 165 491 73 165 492 minecraft:quartz_block
fill 72 165 494 73 165 495 minecraft:gray_concrete
fill 72 165 497 73 165 498 minecraft:quartz_block
fill 72 165 500 73 165 501 minecraft:gray_concrete
fill 72 165 503 73 165 504 minecraft:quartz_block
fill 73 165 484 75 165 484 minecraft:sea_lantern
setblock 73 165 485 minecraft:shroomlight
setblock 73 165 489 minecraft:shroomlight
fill 73 165 490 75 165 490 minecraft:sea_lantern
fill 74 165 464 74 165 465 minecraft:black_concrete
fill 74 165 467 74 165 468 minecraft:black_concrete
fill 74 165 470 74 165 471 minecraft:black_concrete
fill 74 165 473 74 165 474 minecraft:black_concrete
fill 74 165 476 74 165 477 minecraft:black_concrete
fill 74 165 479 74 165 480 minecraft:black_concrete
fill 74 165 482 74 165 483 minecraft:black_concrete
fill 74 165 491 74 165 492 minecraft:black_concrete
fill 74 165 494 74 165 495 minecraft:black_concrete
fill 74 165 497 74 165 498 minecraft:black_concrete
fill 74 165 500 74 165 501 minecraft:black_concrete
fill 74 165 503 74 165 504 minecraft:black_concrete
fill 75 165 464 76 165 465 minecraft:quartz_block
fill 75 165 467 76 165 468 minecraft:gray_concrete
fill 75 165 470 76 165 471 minecraft:quartz_block
fill 75 165 473 76 165 474 minecraft:gray_concrete
fill 75 165 476 76 165 477 minecraft:quartz_block
fill 75 165 479 76 165 480 minecraft:gray_concrete
fill 75 165 482 76 165 483 minecraft:quartz_block
fill 75 165 485 76 165 485 minecraft:shroomlight
fill 75 165 489 76 165 489 minecraft:shroomlight
fill 75 165 491 76 165 492 minecraft:gray_concrete
fill 75 165 494 76 165 495 minecraft:quartz_block
fill 75 165 497 76 165 498 minecraft:gray_concrete
fill 75 165 500 76 165 501 minecraft:quartz_block
fill 75 165 503 76 165 504 minecraft:gray_concrete
fill 76 165 484 88 165 484 minecraft:black_concrete
setblock 76 165 486 minecraft:shroomlight
setblock 76 165 488 minecraft:shroomlight
fill 76 165 490 88 165 490 minecraft:black_concrete
fill 77 165 464 77 165 465 minecraft:black_concrete
fill 77 165 467 77 165 468 minecraft:black_concrete
fill 77 165 470 77 165 471 minecraft:black_concrete
fill 77 165 473 77 165 474 minecraft:black_concrete
fill 77 165 476 77 165 477 minecraft:black_concrete
fill 77 165 479 77 165 480 minecraft:black_concrete
fill 77 165 482 77 165 483 minecraft:black_concrete
setblock 77 165 485 minecraft:black_concrete
fill 77 165 486 77 165 488 minecraft:sea_lantern
setblock 77 165 489 minecraft:black_concrete
fill 77 165 491 77 165 492 minecraft:black_concrete
fill 77 165 494 77 165 495 minecraft:black_concrete
fill 77 165 497 77 165 498 minecraft:black_concrete
fill 77 165 500 77 165 501 minecraft:black_concrete
fill 77 165 503 77 165 504 minecraft:black_concrete
fill 78 165 464 79 165 465 minecraft:gray_concrete
fill 78 165 467 79 165 468 minecraft:quartz_block
fill 78 165 470 79 165 471 minecraft:gray_concrete
fill 78 165 473 79 165 474 minecraft:quartz_block
fill 78 165 476 79 165 477 minecraft:gray_concrete
fill 78 165 479 79 165 480 minecraft:quartz_block
fill 78 165 482 79 165 483 minecraft:gray_concrete
fill 78 165 485 79 165 486 minecraft:quartz_block
fill 78 165 487 88 165 487 minecraft:black_concrete
fill 78 165 488 79 165 489 minecraft:gray_concrete
fill 78 165 491 79 165 492 minecraft:quartz_block
fill 78 165 494 79 165 495 minecraft:gray_concrete
fill 78 165 497 79 165 498 minecraft:quartz_block
fill 78 165 500 79 165 501 minecraft:gray_concrete
fill 78 165 503 79 165 504 minecraft:quartz_block
fill 80 165 464 80 165 465 minecraft:black_concrete
fill 80 165 467 80 165 468 minecraft:black_concrete
fill 80 165 470 80 165 471 minecraft:black_concrete
fill 80 165 473 80 165 474 minecraft:black_concrete
fill 80 165 476 80 165 477 minecraft:black_concrete
fill 80 165 479 80 165 480 minecraft:black_concrete
fill 80 165 482 80 165 483 minecraft:black_concrete
fill 80 165 485 80 165 486 minecraft:black_concrete
fill 80 165 488 80 165 489 minecraft:black_concrete
fill 80 165 491 80 165 492 minecraft:black_concrete
fill 80 165 494 80 165 495 minecraft:black_concrete
fill 80 165 497 80 165 498 minecraft:black_concrete
fill 80 165 500 80 165 501 minecraft:black_concrete
fill 80 165 503 80 165 504 minecraft:black_concrete
fill 81 165 464 82 165 465 minecraft:quartz_block
fill 81 165 467 82 165 468 minecraft:gray_concrete
fill 81 165 470 82 165 471 minecraft:quartz_block
fill 81 165 473 82 165 474 minecraft:gray_concrete
fill 81 165 476 82 165 477 minecraft:quartz_block
fill 81 165 479 82 165 480 minecraft:gray_concrete
fill 81 165 482 82 165 483 minecraft:quartz_block
fill 81 165 485 82 165 486 minecraft:gray_concrete
fill 81 165 488 82 165 489 minecraft:quartz_block
fill 81 165 491 82 165 492 minecraft:gray_concrete
fill 81 165 494 82 165 495 minecraft:quartz_block
fill 81 165 497 82 165 498 minecraft:gray_concrete
fill 81 165 500 82 165 501 minecraft:quartz_block
fill 81 165 503 82 165 504 minecraft:gray_concrete
fill 83 165 464 83 165 465 minecraft:black_concrete
fill 83 165 467 83 165 468 minecraft:black_concrete
fill 83 165 470 83 165 471 minecraft:black_concrete
fill 83 165 473 83 165 474 minecraft:black_concrete
fill 83 165 476 83 165 477 minecraft:black_concrete
fill 83 165 479 83 165 480 minecraft:black_concrete
fill 83 165 482 83 165 483 minecraft:black_concrete
fill 83 165 485 83 165 486 minecraft:black_concrete
fill 83 165 488 83 165 489 minecraft:black_concrete
fill 83 165 491 83 165 492 minecraft:black_concrete
fill 83 165 494 83 165 495 minecraft:black_concrete
fill 83 165 497 83 165 498 minecraft:black_concrete
fill 83 165 500 83 165 501 minecraft:black_concrete
fill 83 165 503 83 165 504 minecraft:black_concrete
fill 84 165 464 85 165 465 minecraft:gray_concrete
fill 84 165 467 85 165 468 minecraft:quartz_block
fill 84 165 470 85 165 471 minecraft:gray_concrete
fill 84 165 473 85 165 474 minecraft:quartz_block
fill 84 165 476 85 165 477 minecraft:gray_concrete
fill 84 165 479 85 165 480 minecraft:quartz_block
fill 84 165 482 85 165 483 minecraft:gray_concrete
fill 84 165 485 85 165 486 minecraft:quartz_block
fill 84 165 488 85 165 489 minecraft:gray_concrete
fill 84 165 491 85 165 492 minecraft:quartz_block
fill 84 165 494 85 165 495 minecraft:gray_concrete
fill 84 165 497 85 165 498 minecraft:quartz_block
fill 84 165 500 85 165 501 minecraft:gray_concrete
fill 84 165 503 85 165 504 minecraft:quartz_block
fill 86 165 464 86 165 465 minecraft:black_concrete
fill 86 165 467 86 165 468 minecraft:black_concrete
fill 86 165 470 86 165 471 minecraft:black_concrete
fill 86 165 473 86 165 474 minecraft:black_concrete
fill 86 165 476 86 165 477 minecraft:black_concrete
fill 86 165 479 86 165 480 minecraft:black_concrete
fill 86 165 482 86 165 483 minecraft:black_concrete
fill 86 165 485 86 165 486 minecraft:black_concrete
fill 86 165 488 86 165 489 minecraft:black_concrete
fill 86 165 491 86 165 492 minecraft:black_concrete
fill 86 165 494 86 165 495 minecraft:black_concrete
fill 86 165 497 86 165 498 minecraft:black_concrete
fill 86 165 500 86 165 501 minecraft:black_concrete
fill 86 165 503 86 165 504 minecraft:black_concrete
fill 87 165 464 88 165 465 minecraft:quartz_block
fill 87 165 467 88 165 468 minecraft:gray_concrete
fill 87 165 470 88 165 471 minecraft:quartz_block
fill 87 165 473 88 165 474 minecraft:gray_concrete
fill 87 165 476 88 165 477 minecraft:quartz_block
fill 87 165 479 88 165 480 minecraft:gray_concrete
fill 87 165 482 88 165 483 minecraft:quartz_block
fill 87 165 485 88 165 486 minecraft:gray_concrete
fill 87 165 488 88 165 489 minecraft:quartz_block
fill 87 165 491 88 165 492 minecraft:gray_concrete
fill 87 165 494 88 165 495 minecraft:quartz_block
fill 87 165 497 88 165 498 minecraft:gray_concrete
fill 87 165 500 88 165 501 minecraft:quartz_block
fill 87 165 503 88 165 504 minecraft:gray_concrete
fill 51 166 482 52 166 492 minecraft:basalt
fill 52 166 479 52 166 481 minecraft:basalt
fill 52 166 493 52 166 495 minecraft:basalt
fill 53 166 477 55 166 478 minecraft:basalt
setblock 53 166 479 minecraft:magma_block
fill 53 166 480 55 167 481 minecraft:basalt
setblock 53 166 482 minecraft:magma_block
fill 53 166 483 55 168 484 minecraft:basalt
setblock 53 166 485 minecraft:magma_block
fill 53 166 486 55 168 487 minecraft:basalt
setblock 53 166 488 minecraft:magma_block
fill 53 166 489 55 168 490 minecraft:basalt
setblock 53 166 491 minecraft:magma_block
fill 53 166 492 55 167 493 minecraft:basalt
setblock 53 166 494 minecraft:magma_block
fill 53 166 495 55 166 496 minecraft:basalt
setblock 53 166 497 minecraft:magma_block
fill 54 166 475 55 166 476 minecraft:basalt
fill 54 166 479 61 167 479 minecraft:basalt
fill 54 166 482 60 169 482 minecraft:basalt
fill 54 166 485 59 169 485 minecraft:basalt
fill 54 166 488 59 170 488 minecraft:basalt
fill 54 166 491 59 169 491 minecraft:basalt
fill 54 166 494 61 167 494 minecraft:basalt
fill 54 166 497 55 166 499 minecraft:basalt
fill 55 166 474 58 166 474 minecraft:basalt
fill 55 166 500 61 166 500 minecraft:basalt
setblock 56 166 472 minecraft:magma_block
fill 56 166 473 61 166 473 minecraft:basalt
setblock 56 166 475 minecraft:magma_block
fill 56 166 476 58 168 477 minecraft:basalt
setblock 56 166 478 minecraft:magma_block
fill 56 166 480 58 170 480 minecraft:basalt
setblock 56 166 481 minecraft:magma_block
fill 56 166 483 58 171 483 minecraft:basalt
setblock 56 166 484 minecraft:magma_block
fill 56 166 486 58 172 486 minecraft:basalt
setblock 56 166 487 minecraft:magma_block
fill 56 166 489 58 172 489 minecraft:basalt
setblock 56 166 490 minecraft:magma_block
fill 56 166 492 58 171 492 minecraft:basalt
setblock 56 166 493 minecraft:magma_block
fill 56 166 495 58 170 495 minecraft:basalt
setblock 56 166 496 minecraft:magma_block
fill 56 166 497 58 168 498 minecraft:basalt
setblock 56 166 499 minecraft:magma_block
fill 56 166 501 58 166 501 minecraft:basalt
setblock 56 166 502 minecraft:magma_block
fill 57 166 471 58 166 472 minecraft:basalt
fill 57 166 475 64 169 475 minecraft:basalt
fill 57 166 478 62 170 478 minecraft:basalt
fill 57 166 481 60 172 481 minecraft:basalt
fill 57 166 484 59 173 484 minecraft:basalt
fill 57 166 487 59 173 487 minecraft:basalt
fill 57 166 490 59 173 490 minecraft:basalt
fill 57 166 493 60 172 493 minecraft:basalt
fill 57 166 496 62 170 496 minecraft:basalt
fill 57 166 499 64 169 499 minecraft:basalt
fill 57 166 502 61 166 503 minecraft:basalt
fill 58 166 470 61 166 470 minecraft:basalt
setblock 58 166 504 minecraft:basalt
fill 59 166 469 64 166 469 minecraft:basalt
setblock 59 166 471 minecraft:magma_block
fill 59 166 472 64 168 472 minecraft:basalt
setblock 59 166 474 minecraft:magma_block
fill 59 166 476 61 171 476 minecraft:basalt
setblock 59 166 477 minecraft:magma_block
setblock 59 166 480 minecraft:magma_block
setblock 59 166 483 minecraft:magma_block
setblock 59 166 486 minecraft:magma_block
setblock 59 166 489 minecraft:magma_block
setblock 59 166 492 minecraft:magma_block
setblock 59 166 495 minecraft:magma_block
fill 59 166 497 61 172 497 minecraft:basalt
setblock 59 166 498 minecraft:magma_block
setblock 59 166 501 minecraft:magma_block
setblock 59 166 504 minecraft:magma_block
fill 60 166 471 67 167 471 minecraft:basalt
fill 60 166 474 67 171 474 minecraft:basalt
fill 60 166 477 63 173 477 minecraft:basalt
fill 60 166 480 61 175 480 minecraft:basalt
fill 60 166 492 60 175 492 minecraft:basalt
fill 60 166 495 61 174 495 minecraft:basalt
fill 60 166 498 64 172 498 minecraft:basalt
fill 60 166 501 67 170 501 minecraft:basalt
fill 60 166 504 67 167 504 minecraft:basalt
fill 61 166 468 67 166 468 minecraft:basalt
setblock 62 166 467 minecraft:magma_block
setblock 62 166 470 minecraft:magma_block
setblock 62 166 473 minecraft:magma_block
setblock 62 166 476 minecraft:magma_block
setblock 62 166 497 minecraft:magma_block
setblock 62 166 500 minecraft:magma_block
fill 62 166 502 64 170 502 minecraft:basalt
setblock 62 166 503 minecraft:magma_block
fill 63 166 467 70 166 467 minecraft:basalt
fill 63 166 470 70 169 470 minecraft:basalt
fill 63 166 473 69 172 473 minecraft:basalt
fill 63 166 476 64 175 476 minecraft:basalt
fill 63 166 497 63 175 497 minecraft:basalt
fill 63 166 500 67 166 500 minecraft:basalt
fill 63 166 503 70 170 503 minecraft:basalt
setblock 64 166 466 minecraft:basalt
setblock 65 166 466 minecraft:magma_block
setblock 65 166 469 minecraft:magma_block
setblock 65 166 472 minecraft:magma_block
setblock 65 166 475 minecraft:magma_block
setblock 65 166 499 minecraft:magma_block
setblock 65 166 502 minecraft:magma_block
fill 66 166 465 67 166 466 minecraft:basalt
fill 66 166 469 73 169 469 minecraft:basalt
fill 66 166 472 73 173 472 minecraft:basalt
fill 66 166 502 73 173 502 minecraft:basalt
setblock 68 166 465 minecraft:magma_block
fill 68 166 466 73 167 466 minecraft:basalt
setblock 68 166 468 minecraft:magma_block
setblock 68 166 471 minecraft:magma_block
setblock 68 166 501 minecraft:magma_block
setblock 68 166 504 minecraft:magma_block
fill 69 166 464 70 166 465 minecraft:basalt
fill 69 166 468 76 169 468 minecraft:basalt
fill 69 166 471 76 173 471 minecraft:basalt
fill 69 166 501 69 175 501 minecraft:basalt
fill 69 166 504 76 172 504 minecraft:basalt
setblock 71 166 464 minecraft:magma_block
fill 71 166 465 76 166 465 minecraft:basalt
setblock 71 166 467 minecraft:magma_block
setblock 71 166 470 minecraft:magma_block
setblock 71 166 503 minecraft:magma_block
fill 72 166 464 79 166 464 minecraft:basalt
fill 72 166 467 79 168 467 minecraft:basalt
fill 72 166 470 79 172 470 minecraft:basalt
fill 72 166 503 79 172 503 minecraft:basalt
setblock 74 166 466 minecraft:magma_block
setblock 74 166 469 minecraft:magma_block
setblock 74 166 472 minecraft:magma_block
setblock 74 166 502 minecraft:magma_block
fill 75 166 466 82 167 466 minecraft:basalt
fill 75 166 469 82 170 469 minecraft:basalt
fill 75 166 472 82 172 472 minecraft:basalt
fill 75 166 502 82 172 502 minecraft:basalt
setblock 77 166 465 minecraft:magma_block
setblock 77 166 468 minecraft:magma_block
setblock 77 166 471 minecraft:magma_block
setblock 77 166 504 minecraft:magma_block
fill 78 166 465 82 166 465 minecraft:basalt
fill 78 166 468 85 167 468 minecraft:basalt
fill 78 166 471 85 170 471 minecraft:basalt
fill 78 166 504 85 169 504 minecraft:basalt
fill 79 166 473 79 175 473 minecraft:basalt
fill 79 166 501 85 172 501 minecraft:basalt
setblock 80 166 467 minecraft:magma_block
setblock 80 166 470 minecraft:magma_block
setblock 80 166 473 minecraft:magma_block
setblock 80 166 503 minecraft:magma_block
fill 81 166 467 86 166 467 minecraft:basalt
fill 81 166 470 88 167 470 minecraft:basalt
fill 81 166 473 85 172 474 minecraft:basalt
fill 81 166 500 88 170 500 minecraft:basalt
fill 81 166 503 88 168 503 minecraft:basalt
setblock 83 166 466 minecraft:magma_block
setblock 83 166 469 minecraft:magma_block
setblock 83 166 472 minecraft:magma_block
setblock 83 166 475 minecraft:magma_block
setblock 83 166 499 minecraft:magma_block
setblock 83 166 502 minecraft:magma_block
setblock 84 166 466 minecraft:basalt
fill 84 166 469 88 166 469 minecraft:basalt
fill 84 166 472 88 169 472 minecraft:basalt
fill 84 166 475 88 171 476 minecraft:basalt
fill 84 166 498 85 174 499 minecraft:basalt
fill 84 166 502 88 169 502 minecraft:basalt
fill 85 166 477 85 175 477 minecraft:basalt
fill 85 166 497 88 172 497 minecraft:basalt
setblock 86 166 468 minecraft:magma_block
setblock 86 166 471 minecraft:magma_block
fill 86 166 473 88 170 473 minecraft:basalt
setblock 86 166 474 minecraft:magma_block
setblock 86 166 477 minecraft:magma_block
fill 86 166 478 88 173 478 minecraft:basalt
fill 86 166 496 88 173 496 minecraft:basalt
setblock 86 166 498 minecraft:magma_block
fill 86 166 499 88 171 499 minecraft:basalt
setblock 86 166 501 minecraft:magma_block
setblock 86 166 504 minecraft:magma_block
setblock 87 166 468 minecraft:basalt
fill 87 166 471 88 168 471 minecraft:basalt
fill 87 166 474 88 171 474 minecraft:basalt
fill 87 166 477 88 173 477 minecraft:basalt
fill 87 166 479 88 174 480 minecraft:basalt
fill 87 166 494 88 174 495 minecraft:basalt
fill 87 166 498 88 172 498 minecraft:basalt
fill 87 166 501 88 169 501 minecraft:basalt
fill 87 166 504 88 167 504 minecraft:basalt
fill 88 166 481 88 175 482 minecraft:basalt
fill 88 166 492 88 175 493 minecraft:basalt
fill 52 167 482 52 167 483 minecraft:basalt
setblock 52 167 484 minecraft:magma_block
fill 52 167 485 52 167 486 minecraft:basalt
setblock 52 167 487 minecraft:magma_block
fill 52 167 488 52 167 489 minecraft:basalt
setblock 52 167 490 minecraft:magma_block
fill 52 167 491 52 167 492 minecraft:basalt
setblock 53 167 479 minecraft:basalt
fill 53 167 482 53 168 482 minecraft:basalt
fill 53 167 485 53 168 485 minecraft:basalt
fill 53 167 488 53 168 488 minecraft:basalt
fill 53 167 491 53 168 491 minecraft:basalt
fill 53 167 494 53 167 495 minecraft:basalt
fill 54 167 477 55 167 478 minecraft:basalt
fill 54 167 495 55 167 497 minecraft:basalt
fill 55 167 475 55 167 476 minecraft:basalt
setblock 55 167 498 minecraft:magma_block
fill 55 167 499 56 167 499 minecraft:basalt
fill 56 167 474 56 167 475 minecraft:basalt
fill 56 167 478 56 169 478 minecraft:basalt
fill 56 167 481 56 171 481 minecraft:basalt
fill 56 167 484 56 172 484 minecraft:basalt
fill 56 167 487 56 172 487 minecraft:basalt
fill 56 167 490 56 172 490 minecraft:basalt
fill 56 167 493 56 171 493 minecraft:basalt
fill 56 167 496 56 169 496 minecraft:basalt
fill 56 167 500 66 167 500 minecraft:basalt
fill 57 167 472 58 167 474 minecraft:basalt
fill 57 167 501 59 167 502 minecraft:basalt
fill 58 167 471 59 167 471 minecraft:basalt
setblock 58 167 503 minecraft:magma_block
fill 59 167 470 62 167 470 minecraft:basalt
fill 59 167 473 59 168 474 minecraft:basalt
fill 59 167 477 59 172 477 minecraft:basalt
fill 59 167 480 59 174 480 minecraft:basalt
fill 59 167 483 60 174 483 minecraft:basalt
fill 59 167 486 59 174 486 minecraft:basalt
fill 59 167 489 60 167 489 minecraft:basalt
fill 59 167 492 59 174 492 minecraft:basalt
fill 59 167 495 59 173 495 minecraft:basalt
fill 59 167 498 59 171 498 minecraft:basalt
fill 59 167 503 59 167 504 minecraft:basalt
fill 60 167 473 62 170 473 minecraft:basalt
fill 60 167 484 60 176 485 minecraft:basalt
fill 60 167 490 60 176 491 minecraft:basalt
fill 60 167 502 61 168 503 minecraft:basalt
setblock 61 167 469 minecraft:magma_block
setblock 61 167 481 minecraft:magma_block
setblock 61 167 493 minecraft:magma_block
fill 62 167 468 65 167 469 minecraft:basalt
fill 62 167 476 62 174 476 minecraft:basalt
fill 62 167 479 62 176 479 minecraft:basalt
fill 62 167 495 62 176 495 minecraft:basalt
fill 62 167 497 62 174 497 minecraft:basalt
fill 62 167 503 62 170 503 minecraft:basalt
fill 63 167 478 63 176 478 minecraft:basalt
fill 63 167 496 63 176 496 minecraft:basalt
fill 64 167 467 71 167 467 minecraft:basalt
setblock 64 167 477 minecraft:magma_block
fill 64 167 497 64 176 497 minecraft:basalt
fill 65 167 472 65 172 472 minecraft:basalt
fill 65 167 475 65 174 476 minecraft:basalt
fill 65 167 498 65 174 499 minecraft:basalt
fill 65 167 502 65 172 502 minecraft:basalt
fill 66 167 466 67 167 466 minecraft:basalt
fill 66 167 468 68 169 468 minecraft:basalt
fill 66 167 475 66 176 475 minecraft:basalt
fill 66 167 499 66 176 499 minecraft:basalt
setblock 67 167 500 minecraft:magma_block
fill 68 167 471 68 173 471 minecraft:basalt
fill 68 167 474 68 176 474 minecraft:basalt
fill 68 167 500 68 174 501 minecraft:basalt
fill 68 167 504 68 172 504 minecraft:basalt
fill 69 167 465 72 167 465 minecraft:basalt
fill 70 167 473 72 167 473 minecraft:basalt
fill 70 167 501 72 176 501 minecraft:basalt
fill 71 167 470 71 173 470 minecraft:basalt
fill 71 167 503 71 174 503 minecraft:basalt
setblock 73 167 465 minecraft:magma_block
fill 74 167 465 74 167 466 minecraft:basalt
fill 74 167 469 74 172 469 minecraft:basalt
fill 74 167 472 74 174 472 minecraft:basalt
fill 74 167 502 74 174 502 minecraft:basalt
fill 75 167 465 79 167 465 minecraft:basalt
setblock 76 167 473 minecraft:magma_block
fill 76 167 501 78 176 501 minecraft:basalt
fill 77 167 468 77 170 468 minecraft:basalt
fill 77 167 471 77 174 471 minecraft:basalt
fill 77 167 473 78 176 473 minecraft:basalt
fill 77 167 504 77 173 504 minecraft:basalt
fill 80 167 467 84 167 467 minecraft:basalt
fill 80 167 470 80 172 470 minecraft:basalt
fill 80 167 473 80 174 474 minecraft:basalt
fill 80 167 500 80 176 500 minecraft:basalt
fill 80 167 503 80 173 503 minecraft:basalt
fill 82 167 475 83 174 475 minecraft:basalt
fill 82 167 499 83 174 499 minecraft:basalt
fill 83 167 469 87 167 469 minecraft:basalt
fill 83 167 472 83 172 472 minecraft:basalt
fill 83 167 476 83 176 476 minecraft:basalt
fill 83 167 498 83 176 498 minecraft:basalt
fill 83 167 502 83 172 502 minecraft:basalt
fill 84 167 477 84 176 477 minecraft:basalt
fill 84 167 497 84 176 497 minecraft:basalt
fill 85 167 478 85 176 478 minecraft:basalt
fill 85 167 496 85 176 496 minecraft:basalt
setblock 86 167 468 minecraft:basalt
fill 86 167 471 86 170 471 minecraft:basalt
fill 86 167 474 86 172 474 minecraft:basalt
fill 86 167 477 86 174 477 minecraft:basalt
fill 86 167 479 86 176 479 minecraft:basalt
fill 86 167 495 86 176 495 minecraft:basalt
fill 86 167 498 86 174 498 minecraft:basalt
fill 86 167 501 86 171 501 minecraft:basalt
fill 86 167 504 86 169 504 minecraft:basalt
fill 87 167 481 87 176 481 minecraft:basalt
fill 87 167 493 87 176 493 minecraft:basalt
fill 88 167 483 88 176 483 minecraft:basalt
setblock 88 167 484 minecraft:magma_block
fill 88 167 485 88 176 485 minecraft:basalt
fill 88 167 489 88 176 489 minecraft:basalt
setblock 88 167 490 minecraft:magma_block
fill 88 167 491 88 176 491 minecraft:basalt
fill 53 168 492 55 168 492 minecraft:basalt
setblock 54 168 479 minecraft:magma_block
fill 54 168 480 55 168 481 minecraft:basalt
fill 54 168 493 55 169 493 minecraft:basalt
setblock 54 168 494 minecraft:magma_block
fill 54 168 495 55 168 495 minecraft:basalt
fill 55 168 477 55 168 479 minecraft:basalt
fill 55 168 494 62 169 494 minecraft:basalt
fill 55 168 496 55 168 497 minecraft:basalt
setblock 56 168 475 minecraft:basalt
fill 56 168 479 61 170 479 minecraft:basalt
setblock 56 168 499 minecraft:basalt
fill 57 168 474 58 168 474 minecraft:basalt
fill 57 168 500 67 168 500 minecraft:basalt
setblock 58 168 473 minecraft:basalt
fill 58 168 501 59 168 501 minecraft:basalt
fill 59 168 489 59 174 489 minecraft:basalt
setblock 59 168 502 minecraft:basalt
setblock 60 168 471 minecraft:magma_block
setblock 60 168 486 minecraft:magma_block
fill 60 168 487 60 176 488 minecraft:basalt
setblock 60 168 489 minecraft:magma_block
fill 61 168 470 62 168 471 minecraft:basalt
fill 61 168 481 61 175 483 minecraft:basalt
fill 61 168 491 61 175 493 minecraft:basalt
fill 61 168 504 67 168 504 minecraft:basalt
fill 62 168 469 65 168 469 minecraft:basalt
fill 62 168 480 62 177 480 minecraft:basalt
fill 63 168 471 67 170 471 minecraft:basalt
setblock 63 168 479 minecraft:magma_block
fill 63 168 495 63 177 495 minecraft:basalt
fill 64 168 468 65 168 468 minecraft:basalt
fill 64 168 477 64 175 478 minecraft:basalt
fill 64 168 496 64 177 496 minecraft:basalt
setblock 65 168 477 minecraft:basalt
fill 65 168 497 65 177 497 minecraft:basalt
fill 66 168 467 71 168 467 minecraft:basalt
fill 66 168 476 66 177 476 minecraft:basalt
fill 66 168 498 66 177 498 minecraft:basalt
fill 67 168 475 67 177 475 minecraft:basalt
fill 67 168 499 67 177 499 minecraft:basalt
fill 69 168 466 74 168 466 minecraft:basalt
setblock 69 168 474 minecraft:magma_block
fill 69 168 500 70 177 500 minecraft:basalt
fill 70 168 473 70 176 474 minecraft:basalt
fill 71 168 473 71 176 473 minecraft:basalt
setblock 72 168 473 minecraft:magma_block
fill 73 168 473 76 175 473 minecraft:basalt
fill 73 168 501 75 175 501 minecraft:basalt
setblock 75 168 466 minecraft:magma_block
fill 76 168 466 79 168 466 minecraft:basalt
fill 78 168 468 84 168 468 minecraft:basalt
setblock 78 168 474 minecraft:magma_block
fill 78 168 500 79 177 500 minecraft:basalt
fill 79 168 474 79 177 474 minecraft:basalt
fill 80 168 467 80 169 467 minecraft:basalt
setblock 81 168 467 minecraft:magma_block
fill 81 168 470 87 168 470 minecraft:basalt
fill 81 168 475 81 177 475 minecraft:basalt
fill 81 168 499 81 177 499 minecraft:basalt
setblock 82 168 467 minecraft:basalt
fill 82 168 476 82 177 476 minecraft:basalt
fill 82 168 498 82 177 498 minecraft:basalt
fill 83 168 469 86 168 469 minecraft:basalt
setblock 83 168 477 minecraft:basalt
fill 83 168 497 83 177 497 minecraft:basalt
setblock 84 168 478 minecraft:magma_block
setblock 84 168 496 minecraft:magma_block
fill 85 168 479 85 177 479 minecraft:basalt
fill 85 168 495 85 177 495 minecraft:basalt
fill 86 168 480 86 177 480 minecraft:basalt
fill 86 168 494 86 177 494 minecraft:basalt
fill 87 168 482 87 177 482 minecraft:basalt
setblock 87 168 483 minecraft:magma_block
fill 87 168 491 87 177 491 minecraft:basalt
setblock 87 168 492 minecraft:magma_block
setblock 87 168 504 minecraft:magma_block
fill 88 168 484 88 175 484 minecraft:basalt
fill 88 168 486 88 175 488 minecraft:basalt
fill 88 168 490 88 175 490 minecraft:basalt
fill 48 169 464 48 169 504 minecraft:quartz_block
fill 49 169 464 88 169 464 minecraft:quartz_block
fill 49 169 504 61 169 504 minecraft:quartz_block
setblock 50 169 466 minecraft:light[level=14]
setblock 50 169 474 minecraft:light[level=14]
setblock 50 169 482 minecraft:light[level=14]
setblock 50 169 490 minecraft:light[level=14]
setblock 50 169 498 minecraft:light[level=14]
fill 54 169 481 55 169 481 minecraft:basalt
fill 54 169 483 55 169 484 minecraft:basalt
fill 54 169 486 55 170 487 minecraft:basalt
fill 54 169 489 55 169 490 minecraft:basalt
fill 54 169 492 55 169 492 minecraft:basalt
fill 55 169 479 55 169 480 minecraft:basalt
setblock 55 169 495 minecraft:basalt
setblock 56 169 477 minecraft:magma_block
fill 56 169 497 58 169 497 minecraft:basalt
fill 57 169 476 58 169 477 minecraft:basalt
fill 57 169 498 58 169 498 minecraft:basalt
setblock 58 169 466 minecraft:light[level=14]
fill 58 169 474 59 169 474 minecraft:basalt
fill 58 169 500 67 169 500 minecraft:basalt
setblock 59 169 473 minecraft:magma_block
setblock 59 169 501 minecraft:basalt
fill 60 169 472 64 169 472 minecraft:basalt
fill 60 169 486 61 169 486 minecraft:basalt
fill 60 169 489 61 169 489 minecraft:basalt
fill 60 169 502 61 169 502 minecraft:basalt
fill 61 169 471 62 169 471 minecraft:basalt
fill 61 169 484 61 177 485 minecraft:basalt
fill 61 169 487 61 178 488 minecraft:basalt
fill 61 169 490 61 177 490 minecraft:basalt
setblock 61 169 503 minecraft:basalt
setblock 62 169 470 minecraft:basalt
setblock 62 169 481 minecraft:magma_block
fill 62 169 482 62 178 482 minecraft:basalt
fill 62 169 492 62 178 492 minecraft:basalt
setblock 62 169 493 minecraft:magma_block
fill 62 169 504 67 169 504 minecraft:basalt
fill 63 169 479 63 176 480 minecraft:basalt
fill 63 169 494 63 178 494 minecraft:basalt
fill 64 169 469 65 169 469 minecraft:basalt
setblock 65 169 477 minecraft:magma_block
setblock 66 169 466 minecraft:light[level=14]
setblock 66 169 482 minecraft:light[level=14]
setblock 66 169 490 minecraft:light[level=14]
fill 67 169 476 67 178 476 minecraft:basalt
fill 67 169 498 67 178 498 minecraft:basalt
setblock 68 169 467 minecraft:magma_block
fill 68 169 475 69 177 475 minecraft:basalt
fill 68 169 499 69 177 499 minecraft:basalt
fill 69 169 467 76 169 467 minecraft:basalt
fill 69 169 474 69 176 474 minecraft:basalt
fill 71 169 474 73 177 474 minecraft:basalt
fill 71 169 500 76 169 500 minecraft:basalt
fill 72 169 473 72 176 473 minecraft:basalt
setblock 74 169 466 minecraft:light[level=14]
setblock 74 169 474 minecraft:magma_block
setblock 74 169 482 minecraft:light[level=14]
setblock 74 169 490 minecraft:light[level=14]
setblock 74 169 498 minecraft:light[level=14]
fill 75 169 474 78 176 474 minecraft:basalt
setblock 77 169 467 minecraft:magma_block
setblock 77 169 500 minecraft:magma_block
fill 78 169 467 79 169 468 minecraft:basalt
fill 79 169 475 79 178 475 minecraft:basalt
fill 79 169 499 79 178 499 minecraft:basalt
fill 80 169 468 82 169 468 minecraft:basalt
setblock 80 169 475 minecraft:magma_block
setblock 80 169 499 minecraft:magma_block
fill 81 169 470 85 169 470 minecraft:basalt
fill 81 169 476 81 178 476 minecraft:basalt
fill 81 169 498 81 178 498 minecraft:basalt
fill 81 169 503 87 169 503 minecraft:basalt
setblock 82 169 466 minecraft:light[level=14]
setblock 82 169 482 minecraft:light[level=14]
setblock 82 169 490 minecraft:light[level=14]
fill 83 169 469 84 169 469 minecraft:basalt
setblock 83 169 477 minecraft:magma_block
fill 83 169 478 83 169 479 minecraft:black_concrete
fill 84 169 478 84 176 478 minecraft:basalt
fill 84 169 480 84 169 485 minecraft:quartz_block
fill 84 169 496 84 176 496 minecraft:basalt
fill 85 169 480 85 178 480 minecraft:basalt
fill 85 169 481 85 169 486 minecraft:quartz_block
fill 85 169 494 85 178 494 minecraft:basalt
setblock 86 169 470 minecraft:magma_block
fill 86 169 481 86 177 481 minecraft:basalt
setblock 86 169 482 minecraft:magma_block
fill 86 169 483 86 169 486 minecraft:quartz_block
fill 86 169 492 86 177 493 minecraft:basalt
setblock 87 169 471 minecraft:basalt
fill 87 169 483 87 176 490 minecraft:basalt
fill 87 169 492 87 176 492 minecraft:basalt
fill 87 169 504 88 169 504 minecraft:quartz_block
fill 88 169 465 88 169 471 minecraft:quartz_block
setblock 88 169 503 minecraft:quartz_block
fill 48 170 470 48 223 471 minecraft:quartz_block
fill 48 170 478 48 223 479 minecraft:quartz_block
fill 48 170 486 48 223 487 minecraft:quartz_block
fill 48 170 494 48 223 495 minecraft:quartz_block
fill 48 170 502 48 223 503 minecraft:quartz_block
fill 49 170 464 50 223 464 minecraft:quartz_block
fill 54 170 504 55 223 504 minecraft:quartz_block
setblock 55 170 481 minecraft:basalt
setblock 55 170 482 minecraft:magma_block
fill 55 170 483 55 170 484 minecraft:basalt
setblock 55 170 485 minecraft:magma_block
fill 55 170 489 55 170 490 minecraft:basalt
setblock 55 170 491 minecraft:magma_block
fill 55 170 492 55 170 493 minecraft:basalt
fill 56 170 482 60 171 482 minecraft:basalt
fill 56 170 485 59 171 485 minecraft:basalt
fill 56 170 491 59 171 491 minecraft:basalt
fill 56 170 494 62 170 494 minecraft:basalt
fill 57 170 464 58 223 464 minecraft:quartz_block
fill 57 170 477 58 170 477 minecraft:basalt
fill 57 170 497 58 170 497 minecraft:basalt
setblock 58 170 475 minecraft:magma_block
setblock 58 170 476 minecraft:basalt
setblock 58 170 498 minecraft:basalt
setblock 58 170 499 minecraft:magma_block
fill 59 170 474 59 170 475 minecraft:basalt
fill 59 170 499 64 170 500 minecraft:basalt
fill 60 170 475 64 171 475 minecraft:basalt
fill 60 170 486 60 176 486 minecraft:basalt
fill 60 170 489 60 176 489 minecraft:basalt
fill 61 170 472 64 170 472 minecraft:basalt
setblock 61 170 486 minecraft:magma_block
setblock 61 170 489 minecraft:magma_block
setblock 61 170 502 minecraft:basalt
setblock 62 170 471 minecraft:basalt
fill 62 170 481 63 177 481 minecraft:basalt
fill 62 170 483 62 177 484 minecraft:basalt
fill 62 170 490 62 177 491 minecraft:basalt
fill 62 170 493 63 177 493 minecraft:basalt
fill 62 170 504 63 223 504 minecraft:quartz_block
setblock 64 170 470 minecraft:magma_block
setblock 64 170 479 minecraft:magma_block
fill 64 170 480 64 178 480 minecraft:basalt
setblock 64 170 494 minecraft:magma_block
fill 64 170 495 64 178 495 minecraft:basalt
fill 64 170 504 67 170 504 minecraft:basalt
fill 65 170 464 66 223 464 minecraft:quartz_block
fill 65 170 470 70 170 470 minecraft:basalt
fill 65 170 477 65 177 478 minecraft:basalt
fill 65 170 496 65 178 496 minecraft:basalt
fill 65 170 500 67 174 500 minecraft:basalt
setblock 66 170 469 minecraft:basalt
fill 66 170 477 67 178 477 minecraft:basalt
fill 66 170 497 67 178 497 minecraft:basalt
setblock 67 170 469 minecraft:magma_block
fill 68 170 468 69 170 469 minecraft:basalt
fill 68 170 476 68 177 476 minecraft:basalt
fill 68 170 498 68 178 498 minecraft:basalt
setblock 70 170 468 minecraft:magma_block
fill 70 170 469 73 171 469 minecraft:basalt
fill 70 170 475 71 177 475 minecraft:basalt
schedule function dropper:buildpart/109_2 1t
