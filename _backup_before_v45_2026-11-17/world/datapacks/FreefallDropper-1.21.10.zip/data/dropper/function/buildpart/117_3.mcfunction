setblock 424 113 484 minecraft:blackstone
setblock 424 113 488 minecraft:polished_blackstone_bricks
setblock 424 113 489 minecraft:blackstone
setblock 424 113 493 minecraft:polished_blackstone_bricks
setblock 424 113 494 minecraft:blackstone
setblock 424 113 498 minecraft:polished_blackstone_bricks
setblock 424 113 499 minecraft:blackstone
setblock 425 113 467 minecraft:polished_blackstone_bricks
setblock 425 113 468 minecraft:blackstone
setblock 425 113 472 minecraft:polished_blackstone_bricks
setblock 425 113 473 minecraft:blackstone
setblock 425 113 477 minecraft:polished_blackstone_bricks
fill 425 113 478 426 113 478 minecraft:blackstone
setblock 425 113 492 minecraft:polished_blackstone_bricks
setblock 425 113 493 minecraft:blackstone
setblock 426 113 471 minecraft:polished_blackstone_bricks
setblock 426 113 472 minecraft:blackstone
setblock 426 113 476 minecraft:polished_blackstone_bricks
setblock 426 113 477 minecraft:blackstone
setblock 427 113 471 minecraft:blackstone
setblock 428 113 464 minecraft:polished_blackstone_bricks
setblock 429 113 464 minecraft:blackstone
setblock 441 113 504 minecraft:blackstone
setblock 443 113 464 minecraft:polished_blackstone_bricks
setblock 443 113 503 minecraft:blackstone
setblock 443 113 504 minecraft:polished_blackstone_bricks
setblock 444 113 464 minecraft:blackstone
setblock 444 113 503 minecraft:polished_blackstone_bricks
setblock 444 113 504 minecraft:blackstone
setblock 445 113 503 minecraft:blackstone
setblock 448 113 504 minecraft:polished_blackstone_bricks
setblock 449 113 504 minecraft:blackstone
setblock 462 113 495 minecraft:polished_blackstone_bricks
fill 463 113 470 463 113 473 minecraft:blackstone
setblock 463 113 474 minecraft:polished_blackstone_bricks
setblock 463 113 475 minecraft:blackstone
setblock 463 113 478 minecraft:blackstone
setblock 463 113 479 minecraft:polished_blackstone_bricks
setblock 463 113 480 minecraft:blackstone
setblock 463 113 489 minecraft:polished_blackstone_bricks
setblock 463 113 490 minecraft:blackstone
setblock 463 113 494 minecraft:polished_blackstone_bricks
setblock 463 113 495 minecraft:blackstone
setblock 463 113 498 minecraft:blackstone
setblock 464 113 468 minecraft:polished_blackstone_bricks
fill 464 113 469 464 113 472 minecraft:blackstone
setblock 464 113 473 minecraft:polished_blackstone_bricks
setblock 464 113 474 minecraft:blackstone
setblock 464 113 478 minecraft:polished_blackstone_bricks
setblock 464 113 479 minecraft:blackstone
setblock 464 113 483 minecraft:polished_blackstone_bricks
setblock 464 113 484 minecraft:blackstone
setblock 464 113 488 minecraft:polished_blackstone_bricks
setblock 464 113 489 minecraft:blackstone
setblock 464 113 493 minecraft:polished_blackstone_bricks
setblock 464 113 494 minecraft:blackstone
setblock 464 113 498 minecraft:polished_blackstone_bricks
setblock 464 113 499 minecraft:blackstone
setblock 464 113 501 minecraft:blackstone
fill 439 118 484 441 118 486 minecraft:redstone_block
fill 447 118 480 449 118 482 minecraft:redstone_block
fill 447 118 488 449 118 490 minecraft:redstone_block
fill 423 119 463 423 122 464 minecraft:basalt
setblock 423 119 465 minecraft:blackstone
fill 423 119 466 423 119 505 minecraft:basalt
fill 424 119 463 424 120 463 minecraft:blackstone
fill 424 119 505 424 122 505 minecraft:basalt
fill 425 119 463 429 119 463 minecraft:basalt
setblock 425 119 505 minecraft:blackstone
fill 426 119 505 432 122 505 minecraft:basalt
setblock 430 119 463 minecraft:blackstone
fill 431 119 463 438 120 463 minecraft:basalt
fill 433 119 505 433 120 505 minecraft:blackstone
fill 434 119 505 440 122 505 minecraft:basalt
setblock 439 119 463 minecraft:blackstone
fill 440 119 463 458 119 463 minecraft:basalt
fill 441 119 482 446 119 483 minecraft:soul_soil
fill 441 119 487 446 119 488 minecraft:soul_soil
setblock 441 119 505 minecraft:blackstone
fill 442 119 481 446 119 481 minecraft:soul_soil
fill 442 119 484 443 119 486 minecraft:soul_soil
fill 442 119 489 446 119 489 minecraft:soul_soil
fill 442 119 505 459 120 505 minecraft:basalt
setblock 445 119 480 minecraft:soul_soil
setblock 445 119 490 minecraft:soul_soil
fill 447 119 483 449 119 487 minecraft:soul_soil
setblock 450 119 485 minecraft:soul_soil
fill 459 119 463 459 120 463 minecraft:blackstone
fill 460 119 463 464 119 463 minecraft:basalt
fill 460 119 505 460 120 505 minecraft:blackstone
fill 461 119 505 461 122 505 minecraft:basalt
setblock 462 119 505 minecraft:blackstone
fill 463 119 505 465 119 505 minecraft:basalt
setblock 465 119 463 minecraft:blackstone
fill 465 119 464 465 120 470 minecraft:basalt
setblock 465 119 471 minecraft:blackstone
fill 465 119 472 465 119 476 minecraft:basalt
fill 465 119 477 465 121 477 minecraft:blackstone
fill 465 119 478 465 122 480 minecraft:basalt
fill 465 119 481 465 120 481 minecraft:blackstone
fill 465 119 482 465 122 486 minecraft:basalt
setblock 465 119 487 minecraft:blackstone
fill 465 119 488 465 119 490 minecraft:basalt
fill 465 119 491 465 120 491 minecraft:blackstone
fill 465 119 492 465 122 497 minecraft:basalt
setblock 465 119 498 minecraft:blackstone
fill 465 119 499 465 120 504 minecraft:basalt
fill 423 120 465 423 120 466 minecraft:basalt
setblock 423 120 467 minecraft:blackstone
fill 423 120 468 423 122 468 minecraft:basalt
setblock 423 120 469 minecraft:blackstone
setblock 423 120 470 minecraft:basalt
setblock 423 120 471 minecraft:blackstone
fill 423 120 472 423 120 489 minecraft:basalt
setblock 423 120 490 minecraft:blackstone
fill 423 120 491 423 122 501 minecraft:basalt
setblock 423 120 502 minecraft:blackstone
fill 423 120 503 423 122 505 minecraft:basalt
fill 424 120 464 437 120 504 minecraft:soul_soil
fill 425 120 463 425 121 463 minecraft:blackstone
fill 425 120 505 425 123 505 minecraft:basalt
fill 426 120 463 427 120 463 minecraft:basalt
fill 428 120 463 428 121 463 minecraft:blackstone
fill 429 120 463 430 122 463 minecraft:basalt
fill 438 120 464 440 120 482 minecraft:soul_soil
fill 438 120 483 438 120 487 minecraft:sea_lantern
fill 438 120 488 440 120 504 minecraft:soul_soil
fill 439 120 463 445 120 463 minecraft:basalt
fill 439 120 483 450 120 483 minecraft:sea_lantern
fill 439 120 484 441 120 486 minecraft:soul_soil
fill 439 120 487 450 120 487 minecraft:sea_lantern
fill 441 120 464 441 120 481 minecraft:soul_soil
fill 441 120 482 445 120 482 minecraft:dirt
fill 441 120 488 445 120 488 minecraft:dirt
fill 441 120 489 441 120 504 minecraft:soul_soil
setblock 441 120 505 minecraft:basalt
fill 442 120 464 444 120 480 minecraft:soul_soil
fill 442 120 481 445 120 481 minecraft:dirt
fill 442 120 484 443 120 486 minecraft:sea_lantern
fill 442 120 489 445 120 489 minecraft:dirt
fill 442 120 490 444 120 504 minecraft:soul_soil
fill 445 120 464 445 120 479 minecraft:soul_soil
setblock 445 120 480 minecraft:dirt
setblock 445 120 490 minecraft:dirt
fill 445 120 491 445 120 504 minecraft:soul_soil
setblock 446 120 463 minecraft:blackstone
fill 446 120 464 464 120 478 minecraft:soul_soil
fill 446 120 479 446 120 482 minecraft:sea_lantern
fill 446 120 488 446 120 491 minecraft:sea_lantern
fill 446 120 492 464 120 504 minecraft:soul_soil
fill 447 120 463 453 120 463 minecraft:basalt
fill 447 120 479 450 120 479 minecraft:sea_lantern
fill 447 120 480 449 120 482 minecraft:soul_soil
fill 447 120 484 447 120 486 minecraft:sea_lantern
fill 447 120 488 449 120 490 minecraft:soul_soil
fill 447 120 491 450 120 491 minecraft:sea_lantern
fill 448 120 484 449 120 486 minecraft:dirt
fill 450 120 480 450 120 482 minecraft:sea_lantern
fill 450 120 484 464 120 484 minecraft:soul_soil
setblock 450 120 485 minecraft:dirt
fill 450 120 486 464 120 486 minecraft:soul_soil
fill 450 120 488 450 120 490 minecraft:sea_lantern
fill 451 120 479 464 120 483 minecraft:soul_soil
fill 451 120 485 464 120 485 minecraft:soul_soil
fill 451 120 487 464 120 491 minecraft:soul_soil
setblock 454 120 463 minecraft:blackstone
fill 455 120 463 458 122 463 minecraft:basalt
fill 460 120 463 461 120 463 minecraft:basalt
setblock 462 120 463 minecraft:blackstone
fill 462 120 505 462 123 505 minecraft:basalt
fill 463 120 463 465 122 463 minecraft:basalt
setblock 463 120 505 minecraft:blackstone
fill 464 120 505 465 122 505 minecraft:basalt
fill 465 120 471 465 120 474 minecraft:basalt
setblock 465 120 475 minecraft:blackstone
fill 465 120 476 465 122 476 minecraft:basalt
fill 465 120 487 465 122 489 minecraft:basalt
setblock 465 120 490 minecraft:blackstone
fill 465 120 498 465 122 498 minecraft:basalt
setblock 423 121 465 minecraft:blackstone
fill 423 121 466 423 122 467 minecraft:basalt
fill 423 121 469 423 122 469 minecraft:basalt
setblock 423 121 470 minecraft:blackstone
fill 423 121 471 423 122 476 minecraft:basalt
fill 423 121 477 423 121 478 minecraft:blackstone
fill 423 121 479 423 122 490 minecraft:basalt
fill 423 121 502 423 122 502 minecraft:basalt
fill 424 121 463 424 122 463 minecraft:basalt
setblock 426 121 463 minecraft:blackstone
fill 427 121 463 427 123 463 minecraft:basalt
fill 431 121 463 436 122 463 minecraft:basalt
fill 433 121 505 433 122 505 minecraft:basalt
setblock 437 121 463 minecraft:blackstone
fill 438 121 463 438 124 463 minecraft:basalt
setblock 439 121 463 minecraft:blackstone
fill 440 121 463 443 122 463 minecraft:basalt
setblock 441 121 505 minecraft:blackstone
fill 442 121 505 445 122 505 minecraft:basalt
setblock 444 121 463 minecraft:blackstone
fill 445 121 463 452 122 463 minecraft:basalt
setblock 446 121 505 minecraft:blackstone
fill 447 121 505 460 122 505 minecraft:basalt
setblock 453 121 463 minecraft:blackstone
fill 454 121 463 454 122 463 minecraft:basalt
fill 459 121 463 460 122 463 minecraft:basalt
setblock 461 121 463 minecraft:blackstone
fill 462 121 463 462 123 463 minecraft:basalt
fill 463 121 505 463 122 505 minecraft:basalt
fill 465 121 464 465 122 464 minecraft:basalt
setblock 465 121 465 minecraft:blackstone
fill 465 121 466 465 122 472 minecraft:basalt
setblock 465 121 473 minecraft:blackstone
fill 465 121 474 465 122 475 minecraft:basalt
fill 465 121 481 465 122 481 minecraft:basalt
fill 465 121 490 465 122 491 minecraft:basalt
fill 465 121 499 465 122 499 minecraft:basalt
setblock 465 121 500 minecraft:blackstone
fill 465 121 501 465 122 504 minecraft:basalt
setblock 423 122 465 minecraft:basalt
setblock 423 122 470 minecraft:basalt
fill 423 122 477 423 122 478 minecraft:basalt
fill 425 122 463 426 122 463 minecraft:basalt
setblock 428 122 463 minecraft:basalt
setblock 437 122 463 minecraft:basalt
setblock 439 122 463 minecraft:basalt
setblock 441 122 505 minecraft:basalt
setblock 444 122 463 minecraft:basalt
setblock 446 122 505 minecraft:basalt
setblock 453 122 463 minecraft:basalt
setblock 461 122 463 minecraft:basalt
setblock 465 122 465 minecraft:basalt
setblock 465 122 473 minecraft:basalt
setblock 465 122 477 minecraft:basalt
fill 465 122 500 465 123 500 minecraft:basalt
fill 423 123 463 423 123 470 minecraft:blackstone
setblock 423 123 471 minecraft:basalt
fill 423 123 472 423 215 472 minecraft:blackstone
setblock 423 123 473 minecraft:basalt
fill 423 123 474 423 124 477 minecraft:blackstone
fill 423 123 478 423 124 478 minecraft:basalt
fill 423 123 479 423 124 483 minecraft:blackstone
setblock 423 123 484 minecraft:basalt
fill 423 123 485 423 212 490 minecraft:blackstone
setblock 423 123 491 minecraft:basalt
fill 423 123 492 423 212 493 minecraft:blackstone
setblock 423 123 494 minecraft:basalt
fill 423 123 495 423 215 496 minecraft:blackstone
setblock 423 123 497 minecraft:basalt
fill 423 123 498 423 211 505 minecraft:blackstone
fill 424 123 463 426 123 463 minecraft:blackstone
fill 424 123 505 424 215 505 minecraft:blackstone
fill 426 123 505 435 123 505 minecraft:blackstone
fill 428 123 463 428 215 463 minecraft:blackstone
fill 429 123 463 429 124 463 minecraft:basalt
fill 430 123 463 431 124 463 minecraft:blackstone
setblock 432 123 463 minecraft:basalt
fill 433 123 463 437 123 463 minecraft:blackstone
setblock 436 123 505 minecraft:basalt
fill 437 123 505 444 123 505 minecraft:blackstone
fill 439 123 463 454 124 463 minecraft:blackstone
setblock 445 123 505 minecraft:basalt
fill 446 123 505 450 123 505 minecraft:blackstone
fill 451 123 505 451 124 505 minecraft:basalt
fill 452 123 505 456 123 505 minecraft:blackstone
fill 455 123 463 456 123 463 minecraft:basalt
fill 457 123 463 457 211 463 minecraft:blackstone
setblock 457 123 505 minecraft:basalt
setblock 458 123 463 minecraft:basalt
fill 458 123 505 461 124 505 minecraft:blackstone
setblock 459 123 463 minecraft:blackstone
setblock 460 123 463 minecraft:basalt
fill 461 123 463 461 215 463 minecraft:blackstone
fill 463 123 463 463 211 463 minecraft:blackstone
fill 463 123 505 465 123 505 minecraft:blackstone
setblock 464 123 463 minecraft:basalt
fill 465 123 463 465 212 467 minecraft:blackstone
setblock 465 123 468 minecraft:basalt
fill 465 123 469 465 123 485 minecraft:blackstone
fill 465 123 486 465 124 486 minecraft:basalt
fill 465 123 487 465 123 499 minecraft:blackstone
fill 465 123 501 465 123 504 minecraft:blackstone
fill 423 124 463 423 212 469 minecraft:blackstone
fill 423 124 470 423 125 470 minecraft:basalt
fill 423 124 471 424 124 471 minecraft:blackstone
fill 423 124 473 424 125 473 minecraft:blackstone
fill 423 124 484 424 126 484 minecraft:blackstone
fill 423 124 491 423 215 491 minecraft:blackstone
fill 423 124 494 423 215 494 minecraft:blackstone
fill 423 124 497 423 212 497 minecraft:blackstone
fill 424 124 463 424 124 466 minecraft:blackstone
setblock 424 124 467 minecraft:polished_blackstone_bricks
fill 424 124 468 424 125 470 minecraft:blackstone
setblock 424 124 472 minecraft:polished_blackstone_bricks
fill 424 124 474 424 124 476 minecraft:blackstone
setblock 424 124 477 minecraft:polished_blackstone_bricks
fill 424 124 478 424 124 481 minecraft:blackstone
setblock 424 124 482 minecraft:polished_blackstone_bricks
fill 424 124 483 424 127 483 minecraft:blackstone
setblock 424 124 485 minecraft:blackstone
fill 424 124 498 424 124 501 minecraft:blackstone
setblock 424 124 502 minecraft:polished_blackstone_bricks
fill 424 124 503 426 124 504 minecraft:blackstone
fill 425 124 463 425 124 465 minecraft:blackstone
fill 425 124 477 425 124 480 minecraft:blackstone
setblock 425 124 481 minecraft:polished_blackstone_bricks
setblock 425 124 502 minecraft:blackstone
fill 425 124 505 431 211 505 minecraft:blackstone
setblock 426 124 463 minecraft:basalt
setblock 426 124 464 minecraft:blackstone
fill 427 124 463 427 215 463 minecraft:blackstone
setblock 427 124 464 minecraft:polished_blackstone_bricks
setblock 427 124 504 minecraft:polished_blackstone_bricks
fill 428 124 464 431 124 464 minecraft:blackstone
fill 428 124 504 431 124 504 minecraft:blackstone
fill 430 124 503 432 124 503 minecraft:blackstone
fill 432 124 463 434 211 463 minecraft:blackstone
setblock 432 124 464 minecraft:polished_blackstone_bricks
setblock 432 124 504 minecraft:polished_blackstone_bricks
setblock 432 124 505 minecraft:basalt
fill 433 124 464 436 124 464 minecraft:blackstone
setblock 433 124 503 minecraft:polished_blackstone_bricks
fill 433 124 504 434 126 505 minecraft:blackstone
setblock 434 124 502 minecraft:polished_blackstone_bricks
fill 434 124 503 437 124 503 minecraft:blackstone
setblock 435 124 463 minecraft:basalt
fill 435 124 502 438 124 502 minecraft:blackstone
fill 435 124 504 436 124 504 minecraft:blackstone
setblock 435 124 505 minecraft:basalt
fill 436 124 463 437 213 463 minecraft:blackstone
setblock 436 124 465 minecraft:polished_blackstone_bricks
fill 436 124 505 436 215 505 minecraft:blackstone
setblock 437 124 464 minecraft:polished_blackstone_bricks
fill 437 124 465 440 124 465 minecraft:blackstone
fill 437 124 501 439 124 501 minecraft:blackstone
setblock 437 124 504 minecraft:polished_blackstone_bricks
setblock 437 124 505 minecraft:basalt
fill 438 124 464 441 124 464 minecraft:blackstone
setblock 438 124 503 minecraft:polished_blackstone_bricks
fill 438 124 504 441 124 505 minecraft:blackstone
setblock 439 124 502 minecraft:polished_blackstone_bricks
fill 439 124 503 442 124 503 minecraft:blackstone
setblock 440 124 501 minecraft:polished_blackstone_bricks
fill 440 124 502 443 124 502 minecraft:blackstone
fill 441 124 501 442 124 501 minecraft:blackstone
setblock 442 124 464 minecraft:polished_blackstone_bricks
setblock 442 124 504 minecraft:polished_blackstone_bricks
fill 442 124 505 448 124 505 minecraft:blackstone
fill 443 124 464 444 125 464 minecraft:blackstone
setblock 443 124 503 minecraft:polished_blackstone_bricks
fill 443 124 504 446 124 504 minecraft:blackstone
setblock 444 124 502 minecraft:polished_blackstone_bricks
fill 444 124 503 447 124 503 minecraft:blackstone
setblock 445 124 502 minecraft:blackstone
setblock 447 124 504 minecraft:polished_blackstone_bricks
fill 448 124 504 451 124 504 minecraft:blackstone
setblock 449 124 505 minecraft:basalt
fill 450 124 505 450 215 505 minecraft:blackstone
setblock 452 124 504 minecraft:polished_blackstone_bricks
fill 452 124 505 454 215 505 minecraft:blackstone
fill 453 124 504 456 124 504 minecraft:blackstone
fill 455 124 463 456 211 463 minecraft:blackstone
setblock 455 124 505 minecraft:basalt
fill 456 124 503 457 124 503 minecraft:blackstone
fill 456 124 505 457 215 505 minecraft:blackstone
setblock 457 124 464 minecraft:polished_blackstone_bricks
setblock 457 124 504 minecraft:polished_blackstone_bricks
fill 458 124 463 458 127 464 minecraft:blackstone
setblock 458 124 503 minecraft:polished_blackstone_bricks
fill 458 124 504 461 124 504 minecraft:blackstone
setblock 459 124 463 minecraft:basalt
fill 459 124 464 461 124 464 minecraft:blackstone
fill 459 124 503 462 124 503 minecraft:blackstone
fill 460 124 463 460 215 463 minecraft:blackstone
fill 461 124 478 461 124 479 minecraft:blackstone
setblock 461 124 480 minecraft:polished_blackstone_bricks
fill 461 124 481 462 124 483 minecraft:blackstone
fill 462 124 463 462 215 463 minecraft:blackstone
setblock 462 124 464 minecraft:polished_blackstone_bricks
fill 462 124 475 462 124 478 minecraft:blackstone
setblock 462 124 479 minecraft:polished_blackstone_bricks
fill 462 124 480 465 125 480 minecraft:blackstone
setblock 462 124 484 minecraft:polished_blackstone_bricks
fill 462 124 485 465 125 485 minecraft:blackstone
setblock 462 124 504 minecraft:polished_blackstone_bricks
fill 462 124 505 463 215 505 minecraft:blackstone
fill 463 124 464 464 126 464 minecraft:blackstone
setblock 463 124 473 minecraft:polished_blackstone_bricks
fill 463 124 474 463 124 477 minecraft:blackstone
setblock 463 124 478 minecraft:polished_blackstone_bricks
fill 463 124 479 465 126 479 minecraft:blackstone
fill 463 124 481 463 124 482 minecraft:blackstone
setblock 463 124 483 minecraft:polished_blackstone_bricks
fill 463 124 484 465 126 484 minecraft:blackstone
fill 463 124 486 463 124 487 minecraft:blackstone
setblock 463 124 503 minecraft:polished_blackstone_bricks
fill 463 124 504 465 126 504 minecraft:blackstone
fill 464 124 463 464 216 463 minecraft:blackstone
fill 464 124 465 464 124 466 minecraft:blackstone
setblock 464 124 467 minecraft:polished_blackstone_bricks
fill 464 124 468 465 124 471 minecraft:blackstone
setblock 464 124 472 minecraft:polished_blackstone_bricks
fill 464 124 473 464 124 476 minecraft:blackstone
setblock 464 124 477 minecraft:polished_blackstone_bricks
fill 464 124 478 465 127 478 minecraft:blackstone
fill 464 124 481 465 124 481 minecraft:blackstone
setblock 464 124 482 minecraft:polished_blackstone_bricks
fill 464 124 483 465 127 483 minecraft:blackstone
setblock 464 124 486 minecraft:blackstone
setblock 464 124 487 minecraft:polished_blackstone_bricks
fill 464 124 488 465 124 488 minecraft:blackstone
fill 464 124 499 465 124 501 minecraft:blackstone
setblock 464 124 502 minecraft:polished_blackstone_bricks
fill 464 124 503 464 126 503 minecraft:blackstone
setblock 464 124 505 minecraft:basalt
fill 465 124 472 465 124 474 minecraft:blackstone
setblock 465 124 475 minecraft:basalt
fill 465 124 476 465 215 477 minecraft:blackstone
fill 465 124 482 465 215 482 minecraft:blackstone
setblock 465 124 487 minecraft:blackstone
fill 465 124 489 465 124 493 minecraft:blackstone
setblock 465 124 494 minecraft:basalt
fill 465 124 495 465 212 498 minecraft:blackstone
fill 465 124 502 465 124 503 minecraft:basalt
fill 465 124 505 465 215 505 minecraft:blackstone
fill 423 125 471 423 211 471 minecraft:blackstone
fill 423 125 474 424 125 474 minecraft:blackstone
setblock 423 125 475 minecraft:basalt
fill 423 125 476 423 215 476 minecraft:blackstone
setblock 423 125 477 minecraft:basalt
fill 423 125 478 423 211 481 minecraft:blackstone
setblock 423 125 482 minecraft:basalt
fill 423 125 483 423 215 483 minecraft:blackstone
fill 424 125 463 424 125 465 minecraft:blackstone
setblock 424 125 466 minecraft:polished_blackstone_bricks
fill 424 125 467 424 128 467 minecraft:blackstone
setblock 424 125 471 minecraft:polished_blackstone_bricks
setblock 424 125 472 minecraft:blackstone
setblock 424 125 475 minecraft:blackstone
setblock 424 125 476 minecraft:polished_blackstone_bricks
fill 424 125 477 424 125 480 minecraft:blackstone
setblock 424 125 481 minecraft:polished_blackstone_bricks
fill 424 125 482 424 127 482 minecraft:blackstone
setblock 424 125 500 minecraft:blackstone
setblock 424 125 501 minecraft:polished_blackstone_bricks
fill 424 125 502 424 126 504 minecraft:blackstone
fill 425 125 463 425 125 464 minecraft:blackstone
setblock 425 125 504 minecraft:blackstone
fill 426 125 463 426 216 463 minecraft:blackstone
setblock 426 125 464 minecraft:polished_blackstone_bricks
setblock 426 125 504 minecraft:polished_blackstone_bricks
fill 427 125 464 430 125 464 minecraft:blackstone
fill 427 125 504 430 125 504 minecraft:blackstone
fill 429 125 463 430 215 463 minecraft:blackstone
setblock 431 125 463 minecraft:basalt
setblock 431 125 464 minecraft:polished_blackstone_bricks
setblock 431 125 503 minecraft:blackstone
setblock 431 125 504 minecraft:polished_blackstone_bricks
fill 432 125 464 435 125 464 minecraft:blackstone
setblock 432 125 503 minecraft:polished_blackstone_bricks
fill 432 125 504 432 128 505 minecraft:blackstone
fill 433 125 503 436 125 503 minecraft:blackstone
fill 434 125 502 437 125 502 minecraft:blackstone
fill 435 125 463 435 215 463 minecraft:blackstone
setblock 435 125 465 minecraft:polished_blackstone_bricks
fill 435 125 504 435 125 505 minecraft:blackstone
setblock 436 125 464 minecraft:polished_blackstone_bricks
fill 436 125 465 439 125 465 minecraft:blackstone
setblock 436 125 504 minecraft:polished_blackstone_bricks
fill 437 125 464 440 125 464 minecraft:blackstone
fill 437 125 501 438 125 501 minecraft:blackstone
setblock 437 125 503 minecraft:polished_blackstone_bricks
fill 437 125 504 440 125 505 minecraft:blackstone
fill 438 125 463 449 211 463 minecraft:blackstone
setblock 438 125 502 minecraft:polished_blackstone_bricks
fill 438 125 503 441 125 503 minecraft:blackstone
setblock 439 125 501 minecraft:polished_blackstone_bricks
fill 439 125 502 442 125 502 minecraft:blackstone
setblock 440 125 465 minecraft:polished_blackstone_bricks
fill 440 125 501 441 125 501 minecraft:blackstone
setblock 441 125 464 minecraft:polished_blackstone_bricks
setblock 441 125 504 minecraft:polished_blackstone_bricks
fill 441 125 505 442 215 505 minecraft:blackstone
fill 442 125 464 442 128 464 minecraft:blackstone
setblock 442 125 503 minecraft:polished_blackstone_bricks
fill 442 125 504 445 125 504 minecraft:blackstone
setblock 443 125 502 minecraft:polished_blackstone_bricks
fill 443 125 503 446 125 503 minecraft:blackstone
setblock 443 125 505 minecraft:basalt
setblock 444 125 502 minecraft:blackstone
fill 444 125 505 444 213 505 minecraft:blackstone
setblock 445 125 505 minecraft:basalt
setblock 446 125 504 minecraft:polished_blackstone_bricks
fill 446 125 505 449 215 505 minecraft:blackstone
fill 447 125 504 449 125 504 minecraft:blackstone
fill 450 125 463 451 125 463 minecraft:basalt
fill 451 125 505 451 215 505 minecraft:blackstone
fill 452 125 463 454 215 463 minecraft:blackstone
fill 452 125 504 455 125 504 minecraft:blackstone
fill 455 125 505 455 213 505 minecraft:blackstone
setblock 456 125 464 minecraft:polished_blackstone_bricks
setblock 456 125 503 minecraft:blackstone
setblock 456 125 504 minecraft:polished_blackstone_bricks
fill 457 125 464 457 128 464 minecraft:blackstone
setblock 457 125 503 minecraft:polished_blackstone_bricks
fill 457 125 504 460 125 504 minecraft:blackstone
fill 458 125 503 461 125 503 minecraft:blackstone
fill 458 125 505 459 211 505 minecraft:blackstone
fill 459 125 463 459 126 464 minecraft:blackstone
setblock 460 125 464 minecraft:blackstone
setblock 460 125 505 minecraft:basalt
setblock 461 125 464 minecraft:polished_blackstone_bricks
setblock 461 125 479 minecraft:polished_blackstone_bricks
fill 461 125 480 461 125 483 minecraft:blackstone
setblock 461 125 504 minecraft:polished_blackstone_bricks
fill 461 125 505 461 215 505 minecraft:blackstone
fill 462 125 464 462 128 464 minecraft:blackstone
setblock 462 125 477 minecraft:blackstone
setblock 462 125 478 minecraft:polished_blackstone_bricks
fill 462 125 479 462 126 479 minecraft:blackstone
fill 462 125 481 462 125 482 minecraft:blackstone
setblock 462 125 483 minecraft:polished_blackstone_bricks
fill 462 125 484 462 127 484 minecraft:blackstone
fill 462 125 504 462 128 504 minecraft:blackstone
fill 463 125 474 463 125 476 minecraft:blackstone
setblock 463 125 477 minecraft:polished_blackstone_bricks
fill 463 125 478 463 127 478 minecraft:blackstone
setblock 463 125 481 minecraft:blackstone
setblock 463 125 482 minecraft:polished_blackstone_bricks
fill 463 125 483 463 128 483 minecraft:blackstone
setblock 463 125 486 minecraft:blackstone
setblock 464 125 465 minecraft:blackstone
setblock 464 125 466 minecraft:polished_blackstone_bricks
fill 464 125 467 464 125 470 minecraft:blackstone
setblock 464 125 471 minecraft:polished_blackstone_bricks
fill 464 125 472 464 125 475 minecraft:blackstone
setblock 464 125 476 minecraft:polished_blackstone_bricks
fill 464 125 477 464 128 477 minecraft:blackstone
setblock 464 125 481 minecraft:polished_blackstone_bricks
fill 464 125 482 464 128 482 minecraft:blackstone
setblock 464 125 486 minecraft:polished_blackstone_bricks
fill 464 125 487 464 128 487 minecraft:blackstone
setblock 464 125 501 minecraft:polished_blackstone_bricks
fill 464 125 502 465 125 502 minecraft:blackstone
fill 464 125 505 464 215 505 minecraft:blackstone
fill 465 125 468 465 216 468 minecraft:blackstone
setblock 465 125 469 minecraft:basalt
fill 465 125 470 465 212 472 minecraft:blackstone
setblock 465 125 473 minecraft:basalt
fill 465 125 474 465 213 475 minecraft:blackstone
fill 465 125 481 465 216 481 minecraft:blackstone
fill 465 125 486 465 215 486 minecraft:blackstone
setblock 465 125 487 minecraft:basalt
fill 465 125 488 465 212 490 minecraft:blackstone
setblock 465 125 491 minecraft:basalt
fill 465 125 492 465 213 492 minecraft:blackstone
setblock 465 125 493 minecraft:basalt
fill 465 125 494 465 215 494 minecraft:blackstone
fill 465 125 499 465 211 501 minecraft:blackstone
fill 465 125 503 465 215 503 minecraft:blackstone
fill 423 126 470 423 215 470 minecraft:blackstone
fill 423 126 473 423 213 475 minecraft:blackstone
fill 423 126 477 424 126 477 minecraft:blackstone
fill 423 126 482 423 215 482 minecraft:blackstone
fill 424 126 463 424 126 464 minecraft:blackstone
setblock 424 126 465 minecraft:polished_blackstone_bricks
fill 424 126 466 424 129 466 minecraft:blackstone
fill 424 126 468 424 126 469 minecraft:blackstone
setblock 424 126 476 minecraft:blackstone
fill 424 126 478 424 126 479 minecraft:blackstone
setblock 424 126 480 minecraft:polished_blackstone_bricks
fill 424 126 481 424 127 481 minecraft:blackstone
setblock 424 126 501 minecraft:blackstone
fill 425 126 463 425 213 463 minecraft:blackstone
setblock 425 126 464 minecraft:polished_blackstone_bricks
setblock 425 126 504 minecraft:polished_blackstone_bricks
fill 426 126 464 429 126 464 minecraft:blackstone
fill 426 126 504 429 126 504 minecraft:blackstone
setblock 430 126 464 minecraft:polished_blackstone_bricks
setblock 430 126 504 minecraft:polished_blackstone_bricks
fill 431 126 463 431 129 464 minecraft:blackstone
setblock 431 126 503 minecraft:polished_blackstone_bricks
fill 431 126 504 431 129 504 minecraft:blackstone
fill 432 126 464 434 126 464 minecraft:blackstone
fill 432 126 503 435 126 503 minecraft:blackstone
setblock 434 126 465 minecraft:polished_blackstone_bricks
fill 434 126 502 436 126 502 minecraft:blackstone
setblock 435 126 464 minecraft:polished_blackstone_bricks
fill 435 126 465 438 126 465 minecraft:blackstone
setblock 435 126 504 minecraft:polished_blackstone_bricks
fill 435 126 505 435 215 505 minecraft:blackstone
fill 436 126 464 439 126 464 minecraft:blackstone
setblock 436 126 503 minecraft:polished_blackstone_bricks
fill 436 126 504 439 126 504 minecraft:blackstone
setblock 437 126 502 minecraft:polished_blackstone_bricks
fill 437 126 503 440 126 503 minecraft:blackstone
fill 437 126 505 440 215 505 minecraft:blackstone
setblock 438 126 501 minecraft:polished_blackstone_bricks
fill 438 126 502 441 126 502 minecraft:blackstone
setblock 439 126 465 minecraft:polished_blackstone_bricks
setblock 439 126 501 minecraft:blackstone
setblock 440 126 464 minecraft:polished_blackstone_bricks
fill 440 126 465 440 129 465 minecraft:blackstone
setblock 440 126 504 minecraft:polished_blackstone_bricks
fill 441 126 464 441 129 464 minecraft:blackstone
setblock 441 126 503 minecraft:polished_blackstone_bricks
fill 441 126 504 444 126 504 minecraft:blackstone
setblock 442 126 502 minecraft:polished_blackstone_bricks
fill 442 126 503 445 126 503 minecraft:blackstone
fill 443 126 464 443 127 464 minecraft:blackstone
setblock 443 126 502 minecraft:blackstone
fill 443 126 505 443 215 505 minecraft:blackstone
setblock 445 126 504 minecraft:polished_blackstone_bricks
fill 445 126 505 445 213 505 minecraft:blackstone
fill 446 126 504 447 127 504 minecraft:blackstone
fill 450 126 463 451 215 463 minecraft:blackstone
fill 452 126 504 454 126 504 minecraft:blackstone
setblock 455 126 464 minecraft:polished_blackstone_bricks
setblock 455 126 504 minecraft:polished_blackstone_bricks
fill 456 126 464 456 129 464 minecraft:blackstone
fill 456 126 504 459 126 504 minecraft:blackstone
fill 457 126 503 460 126 503 minecraft:blackstone
setblock 459 126 465 minecraft:polished_blackstone_bricks
setblock 460 126 464 minecraft:polished_blackstone_bricks
fill 460 126 465 461 128 465 minecraft:blackstone
setblock 460 126 504 minecraft:polished_blackstone_bricks
fill 460 126 505 460 215 505 minecraft:blackstone
fill 461 126 464 461 129 464 minecraft:blackstone
fill 461 126 504 461 129 504 minecraft:blackstone
setblock 462 126 478 minecraft:blackstone
fill 462 126 480 462 126 481 minecraft:blackstone
setblock 462 126 482 minecraft:polished_blackstone_bricks
fill 462 126 483 462 128 483 minecraft:blackstone
setblock 463 126 476 minecraft:polished_blackstone_bricks
fill 463 126 477 463 127 477 minecraft:blackstone
setblock 463 126 480 minecraft:blackstone
setblock 463 126 481 minecraft:polished_blackstone_bricks
fill 463 126 482 463 129 482 minecraft:blackstone
setblock 463 126 485 minecraft:blackstone
setblock 463 126 486 minecraft:polished_blackstone_bricks
setblock 464 126 465 minecraft:polished_blackstone_bricks
fill 464 126 466 464 127 468 minecraft:blackstone
fill 464 126 473 464 126 474 minecraft:blackstone
setblock 464 126 475 minecraft:polished_blackstone_bricks
fill 464 126 476 464 128 476 minecraft:blackstone
setblock 464 126 480 minecraft:polished_blackstone_bricks
fill 464 126 481 464 129 481 minecraft:blackstone
setblock 464 126 485 minecraft:polished_blackstone_bricks
fill 464 126 486 464 129 486 minecraft:blackstone
fill 465 126 469 465 215 469 minecraft:blackstone
fill 465 126 473 465 216 473 minecraft:blackstone
fill 465 126 480 465 215 480 minecraft:blackstone
fill 465 126 485 465 216 485 minecraft:blackstone
fill 465 126 487 465 215 487 minecraft:blackstone
fill 465 126 491 465 215 491 minecraft:blackstone
fill 465 126 493 465 216 493 minecraft:blackstone
fill 465 126 502 465 216 502 minecraft:blackstone
fill 423 127 477 423 215 477 minecraft:blackstone
fill 423 127 484 423 212 484 minecraft:blackstone
fill 424 127 463 424 215 463 minecraft:blackstone
setblock 424 127 464 minecraft:polished_blackstone_bricks
fill 424 127 465 424 130 465 minecraft:blackstone
setblock 424 127 468 minecraft:blackstone
setblock 424 127 480 minecraft:blackstone
fill 424 127 502 424 127 503 minecraft:blackstone
setblock 424 127 504 minecraft:polished_blackstone_bricks
fill 425 127 464 428 127 464 minecraft:blackstone
fill 425 127 504 428 127 504 minecraft:blackstone
setblock 429 127 464 minecraft:polished_blackstone_bricks
setblock 429 127 504 minecraft:polished_blackstone_bricks
fill 430 127 464 430 130 464 minecraft:blackstone
setblock 430 127 503 minecraft:polished_blackstone_bricks
fill 430 127 504 430 130 504 minecraft:blackstone
fill 431 127 503 434 127 503 minecraft:blackstone
fill 432 127 464 433 127 464 minecraft:blackstone
setblock 433 127 465 minecraft:polished_blackstone_bricks
fill 433 127 504 433 127 505 minecraft:blackstone
setblock 434 127 464 minecraft:polished_blackstone_bricks
fill 434 127 465 437 127 465 minecraft:blackstone
fill 434 127 502 435 127 502 minecraft:blackstone
setblock 434 127 504 minecraft:polished_blackstone_bricks
fill 434 127 505 434 215 505 minecraft:blackstone
fill 435 127 464 438 127 464 minecraft:blackstone
setblock 435 127 503 minecraft:polished_blackstone_bricks
fill 435 127 504 438 127 504 minecraft:blackstone
setblock 436 127 502 minecraft:polished_blackstone_bricks
fill 436 127 503 439 127 503 minecraft:blackstone
fill 437 127 502 440 127 502 minecraft:blackstone
setblock 438 127 465 minecraft:polished_blackstone_bricks
setblock 439 127 464 minecraft:polished_blackstone_bricks
fill 439 127 465 439 130 465 minecraft:blackstone
setblock 439 127 504 minecraft:polished_blackstone_bricks
fill 440 127 464 440 130 464 minecraft:blackstone
setblock 440 127 503 minecraft:polished_blackstone_bricks
fill 440 127 504 443 127 504 minecraft:blackstone
setblock 441 127 502 minecraft:polished_blackstone_bricks
fill 441 127 503 444 127 503 minecraft:blackstone
setblock 442 127 502 minecraft:blackstone
setblock 444 127 504 minecraft:polished_blackstone_bricks
fill 445 127 504 445 130 504 minecraft:blackstone
fill 452 127 504 453 127 504 minecraft:blackstone
setblock 454 127 464 minecraft:polished_blackstone_bricks
setblock 454 127 504 minecraft:polished_blackstone_bricks
fill 455 127 464 455 130 464 minecraft:blackstone
fill 455 127 504 458 127 504 minecraft:blackstone
fill 457 127 503 459 127 503 minecraft:blackstone
setblock 458 127 465 minecraft:polished_blackstone_bricks
fill 459 127 463 459 216 463 minecraft:blackstone
setblock 459 127 464 minecraft:polished_blackstone_bricks
fill 459 127 465 459 130 465 minecraft:blackstone
setblock 459 127 504 minecraft:polished_blackstone_bricks
fill 460 127 464 460 130 464 minecraft:blackstone
fill 460 127 504 460 130 504 minecraft:blackstone
setblock 462 127 465 minecraft:blackstone
setblock 462 127 480 minecraft:blackstone
setblock 462 127 481 minecraft:polished_blackstone_bricks
fill 462 127 482 462 128 482 minecraft:blackstone
setblock 463 127 464 minecraft:blackstone
setblock 463 127 479 minecraft:blackstone
setblock 463 127 480 minecraft:polished_blackstone_bricks
fill 463 127 481 463 130 481 minecraft:blackstone
setblock 463 127 484 minecraft:blackstone
setblock 463 127 485 minecraft:polished_blackstone_bricks
fill 463 127 486 463 130 486 minecraft:blackstone
setblock 463 127 504 minecraft:blackstone
setblock 464 127 464 minecraft:polished_blackstone_bricks
fill 464 127 465 464 130 465 minecraft:blackstone
setblock 464 127 475 minecraft:blackstone
setblock 464 127 479 minecraft:polished_blackstone_bricks
fill 464 127 480 464 130 480 minecraft:blackstone
setblock 464 127 484 minecraft:polished_blackstone_bricks
fill 464 127 485 464 130 485 minecraft:blackstone
setblock 464 127 504 minecraft:polished_blackstone_bricks
fill 465 127 479 465 211 479 minecraft:blackstone
fill 465 127 484 465 215 484 minecraft:blackstone
fill 465 127 504 465 215 504 minecraft:blackstone
fill 424 128 464 427 128 464 minecraft:blackstone
setblock 424 128 468 minecraft:polished_blackstone_bricks
fill 424 128 469 424 131 469 minecraft:blackstone
setblock 424 128 502 minecraft:blackstone
setblock 424 128 503 minecraft:polished_blackstone_bricks
fill 424 128 504 427 128 504 minecraft:blackstone
fill 425 128 465 425 129 465 minecraft:blackstone
setblock 426 128 466 minecraft:light[level=11]
setblock 426 128 474 minecraft:light[level=11]
setblock 426 128 482 minecraft:light[level=11]
setblock 426 128 490 minecraft:light[level=11]
setblock 426 128 498 minecraft:light[level=11]
setblock 428 128 464 minecraft:polished_blackstone_bricks
setblock 428 128 504 minecraft:polished_blackstone_bricks
fill 429 128 464 429 131 464 minecraft:blackstone
fill 429 128 504 429 131 504 minecraft:blackstone
fill 430 128 503 433 128 503 minecraft:blackstone
setblock 431 128 465 minecraft:blackstone
setblock 432 128 464 minecraft:blackstone
setblock 432 128 465 minecraft:polished_blackstone_bricks
setblock 433 128 464 minecraft:polished_blackstone_bricks
fill 433 128 465 436 128 465 minecraft:blackstone
fill 433 128 502 434 128 502 minecraft:blackstone
setblock 433 128 504 minecraft:polished_blackstone_bricks
fill 433 128 505 433 215 505 minecraft:blackstone
fill 434 128 464 437 128 464 minecraft:blackstone
setblock 434 128 466 minecraft:light[level=11]
setblock 434 128 474 minecraft:light[level=11]
setblock 434 128 482 minecraft:light[level=11]
setblock 434 128 490 minecraft:light[level=11]
setblock 434 128 498 minecraft:light[level=11]
setblock 434 128 503 minecraft:polished_blackstone_bricks
fill 434 128 504 437 128 504 minecraft:blackstone
setblock 435 128 502 minecraft:polished_blackstone_bricks
fill 435 128 503 438 128 503 minecraft:blackstone
fill 436 128 502 439 128 502 minecraft:blackstone
setblock 437 128 465 minecraft:polished_blackstone_bricks
setblock 438 128 464 minecraft:polished_blackstone_bricks
fill 438 128 465 438 131 465 minecraft:blackstone
setblock 438 128 504 minecraft:polished_blackstone_bricks
fill 439 128 464 439 131 464 minecraft:blackstone
setblock 439 128 503 minecraft:polished_blackstone_bricks
fill 439 128 504 442 128 504 minecraft:blackstone
setblock 440 128 502 minecraft:polished_blackstone_bricks
fill 440 128 503 443 128 503 minecraft:blackstone
setblock 441 128 502 minecraft:blackstone
setblock 442 128 466 minecraft:light[level=11]
setblock 442 128 474 minecraft:light[level=11]
setblock 442 128 482 minecraft:light[level=11]
setblock 442 128 490 minecraft:light[level=11]
setblock 442 128 498 minecraft:light[level=11]
setblock 443 128 464 minecraft:polished_blackstone_bricks
setblock 443 128 504 minecraft:polished_blackstone_bricks
fill 444 128 504 444 131 504 minecraft:blackstone
fill 446 128 504 446 129 504 minecraft:blackstone
setblock 450 128 466 minecraft:light[level=11]
setblock 450 128 474 minecraft:light[level=11]
setblock 450 128 482 minecraft:light[level=11]
setblock 450 128 490 minecraft:light[level=11]
setblock 450 128 498 minecraft:light[level=11]
setblock 452 128 504 minecraft:blackstone
setblock 453 128 464 minecraft:polished_blackstone_bricks
setblock 453 128 504 minecraft:polished_blackstone_bricks
fill 454 128 464 454 131 464 minecraft:blackstone
fill 454 128 504 457 128 504 minecraft:blackstone
setblock 456 128 465 minecraft:blackstone
setblock 457 128 465 minecraft:polished_blackstone_bricks
fill 457 128 503 457 129 503 minecraft:blackstone
fill 458 128 463 458 215 463 minecraft:blackstone
setblock 458 128 464 minecraft:polished_blackstone_bricks
fill 458 128 465 458 131 465 minecraft:blackstone
setblock 458 128 466 minecraft:light[level=11]
setblock 458 128 474 minecraft:light[level=11]
setblock 458 128 482 minecraft:light[level=11]
setblock 458 128 490 minecraft:light[level=11]
setblock 458 128 498 minecraft:light[level=11]
setblock 458 128 504 minecraft:polished_blackstone_bricks
fill 459 128 464 459 131 464 minecraft:blackstone
fill 459 128 504 459 131 504 minecraft:blackstone
setblock 462 128 465 minecraft:polished_blackstone_bricks
setblock 462 128 481 minecraft:blackstone
setblock 463 128 464 minecraft:polished_blackstone_bricks
fill 463 128 465 463 131 465 minecraft:blackstone
setblock 463 128 479 minecraft:polished_blackstone_bricks
fill 463 128 480 463 129 480 minecraft:blackstone
setblock 463 128 484 minecraft:polished_blackstone_bricks
fill 463 128 485 463 131 485 minecraft:blackstone
setblock 463 128 504 minecraft:polished_blackstone_bricks
fill 464 128 464 464 131 464 minecraft:blackstone
fill 464 128 466 464 128 467 minecraft:blackstone
setblock 464 128 468 minecraft:polished_blackstone_bricks
fill 464 128 469 464 131 469 minecraft:blackstone
setblock 464 128 478 minecraft:polished_blackstone_bricks
fill 464 128 479 464 131 479 minecraft:blackstone
setblock 464 128 483 minecraft:polished_blackstone_bricks
fill 464 128 484 464 131 484 minecraft:blackstone
fill 465 128 478 465 215 478 minecraft:blackstone
fill 465 128 483 465 215 483 minecraft:blackstone
fill 424 129 464 426 129 464 minecraft:blackstone
setblock 424 129 467 minecraft:polished_blackstone_bricks
fill 424 129 468 424 132 468 minecraft:blackstone
setblock 424 129 502 minecraft:polished_blackstone_bricks
fill 424 129 503 424 131 504 minecraft:blackstone
setblock 425 129 466 minecraft:polished_blackstone_bricks
fill 425 129 504 426 129 504 minecraft:blackstone
setblock 426 129 465 minecraft:polished_blackstone_bricks
setblock 427 129 464 minecraft:polished_blackstone_bricks
fill 427 129 465 430 129 465 minecraft:blackstone
setblock 427 129 504 minecraft:polished_blackstone_bricks
fill 428 129 464 428 132 464 minecraft:blackstone
fill 428 129 504 428 132 504 minecraft:blackstone
fill 429 129 503 432 129 503 minecraft:blackstone
setblock 431 129 465 minecraft:polished_blackstone_bricks
setblock 432 129 464 minecraft:polished_blackstone_bricks
fill 432 129 465 435 129 465 minecraft:blackstone
setblock 432 129 504 minecraft:polished_blackstone_bricks
fill 432 129 505 432 216 505 minecraft:blackstone
fill 433 129 464 436 129 464 minecraft:blackstone
setblock 433 129 502 minecraft:blackstone
setblock 433 129 503 minecraft:polished_blackstone_bricks
fill 433 129 504 436 129 504 minecraft:blackstone
setblock 434 129 502 minecraft:polished_blackstone_bricks
fill 434 129 503 437 129 503 minecraft:blackstone
fill 435 129 502 438 129 502 minecraft:blackstone
setblock 436 129 465 minecraft:polished_blackstone_bricks
setblock 437 129 464 minecraft:polished_blackstone_bricks
fill 437 129 465 437 132 465 minecraft:blackstone
setblock 437 129 504 minecraft:polished_blackstone_bricks
fill 438 129 464 438 132 464 minecraft:blackstone
setblock 438 129 503 minecraft:polished_blackstone_bricks
fill 438 129 504 441 129 504 minecraft:blackstone
setblock 439 129 502 minecraft:polished_blackstone_bricks
fill 439 129 503 442 129 503 minecraft:blackstone
setblock 440 129 502 minecraft:blackstone
setblock 442 129 464 minecraft:polished_blackstone_bricks
setblock 442 129 504 minecraft:polished_blackstone_bricks
fill 443 129 464 443 132 464 minecraft:blackstone
setblock 443 129 503 minecraft:polished_blackstone_bricks
fill 443 129 504 443 132 504 minecraft:blackstone
setblock 451 129 504 minecraft:blackstone
setblock 452 129 464 minecraft:polished_blackstone_bricks
setblock 452 129 504 minecraft:polished_blackstone_bricks
fill 453 129 464 453 132 464 minecraft:blackstone
fill 453 129 504 456 129 504 minecraft:blackstone
fill 454 129 465 455 129 465 minecraft:blackstone
setblock 456 129 465 minecraft:polished_blackstone_bricks
setblock 457 129 464 minecraft:polished_blackstone_bricks
fill 457 129 465 457 132 465 minecraft:blackstone
setblock 457 129 504 minecraft:polished_blackstone_bricks
fill 458 129 464 458 132 464 minecraft:blackstone
fill 458 129 504 458 132 504 minecraft:blackstone
setblock 460 129 465 minecraft:blackstone
setblock 461 129 465 minecraft:polished_blackstone_bricks
setblock 462 129 464 minecraft:polished_blackstone_bricks
fill 462 129 465 462 132 465 minecraft:blackstone
setblock 462 129 504 minecraft:polished_blackstone_bricks
fill 463 129 464 463 132 464 minecraft:blackstone
fill 463 129 466 464 129 466 minecraft:blackstone
setblock 463 129 483 minecraft:polished_blackstone_bricks
fill 463 129 484 463 132 484 minecraft:blackstone
fill 463 129 504 463 131 504 minecraft:blackstone
setblock 464 129 467 minecraft:polished_blackstone_bricks
fill 464 129 468 464 132 468 minecraft:blackstone
fill 464 129 470 464 130 470 minecraft:blackstone
setblock 464 129 477 minecraft:polished_blackstone_bricks
fill 464 129 478 464 130 478 minecraft:blackstone
setblock 464 129 482 minecraft:polished_blackstone_bricks
fill 464 129 483 464 132 483 minecraft:blackstone
setblock 464 129 487 minecraft:polished_blackstone_bricks
fill 424 130 464 425 130 464 minecraft:blackstone
setblock 424 130 466 minecraft:polished_blackstone_bricks
fill 424 130 467 424 133 467 minecraft:blackstone
setblock 424 130 470 minecraft:blackstone
fill 424 130 502 424 133 502 minecraft:blackstone
setblock 425 130 465 minecraft:polished_blackstone_bricks
fill 425 130 466 425 133 466 minecraft:blackstone
setblock 425 130 504 minecraft:blackstone
setblock 426 130 464 minecraft:polished_blackstone_bricks
fill 426 130 465 429 130 465 minecraft:blackstone
setblock 426 130 504 minecraft:polished_blackstone_bricks
fill 427 130 464 427 133 464 minecraft:blackstone
fill 427 130 504 427 133 504 minecraft:blackstone
fill 429 130 503 431 130 503 minecraft:blackstone
setblock 430 130 465 minecraft:polished_blackstone_bricks
fill 431 130 463 431 215 463 minecraft:blackstone
setblock 431 130 464 minecraft:polished_blackstone_bricks
fill 431 130 465 434 130 465 minecraft:blackstone
setblock 431 130 504 minecraft:polished_blackstone_bricks
fill 432 130 464 435 130 464 minecraft:blackstone
setblock 432 130 502 minecraft:blackstone
setblock 432 130 503 minecraft:polished_blackstone_bricks
fill 432 130 504 435 130 504 minecraft:blackstone
setblock 433 130 466 minecraft:blackstone
setblock 433 130 502 minecraft:polished_blackstone_bricks
fill 433 130 503 436 130 503 minecraft:blackstone
setblock 434 130 466 minecraft:polished_blackstone_bricks
fill 434 130 502 437 130 502 minecraft:blackstone
setblock 435 130 465 minecraft:polished_blackstone_bricks
fill 435 130 466 436 132 466 minecraft:blackstone
setblock 436 130 464 minecraft:polished_blackstone_bricks
fill 436 130 465 436 133 465 minecraft:blackstone
setblock 436 130 504 minecraft:polished_blackstone_bricks
fill 437 130 464 437 133 464 minecraft:blackstone
setblock 437 130 503 minecraft:polished_blackstone_bricks
fill 437 130 504 440 130 504 minecraft:blackstone
setblock 438 130 502 minecraft:polished_blackstone_bricks
fill 438 130 503 441 130 503 minecraft:blackstone
fill 439 130 502 439 131 502 minecraft:blackstone
setblock 440 130 465 minecraft:polished_blackstone_bricks
setblock 441 130 464 minecraft:polished_blackstone_bricks
setblock 441 130 504 minecraft:polished_blackstone_bricks
fill 442 130 464 442 133 464 minecraft:blackstone
setblock 442 130 503 minecraft:polished_blackstone_bricks
fill 442 130 504 442 133 504 minecraft:blackstone
setblock 450 130 464 minecraft:blackstone
setblock 450 130 504 minecraft:blackstone
setblock 451 130 464 minecraft:polished_blackstone_bricks
setblock 451 130 504 minecraft:polished_blackstone_bricks
fill 452 130 464 452 133 464 minecraft:blackstone
fill 452 130 504 455 130 504 minecraft:blackstone
fill 453 130 465 454 130 465 minecraft:blackstone
setblock 455 130 465 minecraft:polished_blackstone_bricks
setblock 456 130 464 minecraft:polished_blackstone_bricks
fill 456 130 465 456 132 466 minecraft:blackstone
setblock 456 130 503 minecraft:blackstone
setblock 456 130 504 minecraft:polished_blackstone_bricks
fill 457 130 464 457 133 464 minecraft:blackstone
fill 457 130 466 458 130 466 minecraft:blackstone
setblock 457 130 503 minecraft:polished_blackstone_bricks
fill 457 130 504 457 133 504 minecraft:blackstone
setblock 459 130 466 minecraft:polished_blackstone_bricks
setblock 460 130 465 minecraft:polished_blackstone_bricks
fill 460 130 466 460 133 466 minecraft:blackstone
setblock 461 130 464 minecraft:polished_blackstone_bricks
fill 461 130 465 461 133 465 minecraft:blackstone
setblock 461 130 504 minecraft:polished_blackstone_bricks
fill 462 130 464 462 133 464 minecraft:blackstone
fill 462 130 504 462 132 504 minecraft:blackstone
setblock 463 130 466 minecraft:blackstone
setblock 463 130 467 minecraft:polished_blackstone_bricks
fill 463 130 468 463 133 468 minecraft:blackstone
setblock 463 130 482 minecraft:polished_blackstone_bricks
fill 463 130 483 463 131 483 minecraft:blackstone
setblock 464 130 466 minecraft:polished_blackstone_bricks
fill 464 130 467 464 133 467 minecraft:blackstone
setblock 464 130 471 minecraft:polished_blackstone_bricks
setblock 464 130 481 minecraft:polished_blackstone_bricks
fill 464 130 482 464 133 482 minecraft:blackstone
setblock 464 130 486 minecraft:polished_blackstone_bricks
fill 464 130 487 464 132 488 minecraft:blackstone
setblock 424 131 464 minecraft:blackstone
setblock 424 131 465 minecraft:polished_blackstone_bricks
fill 424 131 466 424 134 466 minecraft:blackstone
setblock 424 131 470 minecraft:polished_blackstone_bricks
setblock 425 131 464 minecraft:polished_blackstone_bricks
fill 425 131 465 428 131 465 minecraft:blackstone
fill 425 131 467 425 132 467 minecraft:blackstone
setblock 425 131 504 minecraft:polished_blackstone_bricks
fill 426 131 464 426 134 464 minecraft:blackstone
fill 426 131 504 426 134 504 minecraft:blackstone
fill 428 131 503 430 131 503 minecraft:blackstone
setblock 429 131 465 minecraft:polished_blackstone_bricks
setblock 430 131 464 minecraft:polished_blackstone_bricks
fill 430 131 465 433 131 465 minecraft:blackstone
setblock 430 131 504 minecraft:polished_blackstone_bricks
fill 431 131 464 434 131 464 minecraft:blackstone
fill 431 131 466 432 131 466 minecraft:blackstone
setblock 431 131 503 minecraft:polished_blackstone_bricks
fill 431 131 504 434 131 504 minecraft:blackstone
setblock 432 131 502 minecraft:polished_blackstone_bricks
fill 432 131 503 435 131 503 minecraft:blackstone
setblock 433 131 466 minecraft:polished_blackstone_bricks
fill 433 131 502 436 131 502 minecraft:blackstone
setblock 434 131 465 minecraft:polished_blackstone_bricks
fill 434 131 466 434 134 466 minecraft:blackstone
setblock 435 131 464 minecraft:polished_blackstone_bricks
fill 435 131 465 435 134 465 minecraft:blackstone
setblock 435 131 504 minecraft:polished_blackstone_bricks
fill 436 131 464 436 134 464 minecraft:blackstone
setblock 436 131 503 minecraft:polished_blackstone_bricks
fill 436 131 504 439 131 504 minecraft:blackstone
setblock 437 131 466 minecraft:blackstone
setblock 437 131 502 minecraft:polished_blackstone_bricks
fill 437 131 503 440 131 503 minecraft:blackstone
fill 438 131 502 438 132 502 minecraft:blackstone
setblock 439 131 465 minecraft:polished_blackstone_bricks
setblock 440 131 464 minecraft:polished_blackstone_bricks
fill 440 131 465 440 133 465 minecraft:blackstone
setblock 440 131 504 minecraft:polished_blackstone_bricks
fill 441 131 464 441 134 464 minecraft:blackstone
setblock 441 131 503 minecraft:polished_blackstone_bricks
fill 441 131 504 441 134 504 minecraft:blackstone
setblock 442 131 503 minecraft:blackstone
setblock 445 131 504 minecraft:polished_blackstone_bricks
setblock 449 131 464 minecraft:blackstone
setblock 449 131 504 minecraft:blackstone
setblock 450 131 464 minecraft:polished_blackstone_bricks
setblock 450 131 504 minecraft:polished_blackstone_bricks
fill 451 131 464 451 134 464 minecraft:blackstone
fill 451 131 504 454 131 504 minecraft:blackstone
fill 452 131 465 453 131 465 minecraft:blackstone
setblock 454 131 465 minecraft:polished_blackstone_bricks
fill 454 131 466 455 133 466 minecraft:blackstone
setblock 455 131 464 minecraft:polished_blackstone_bricks
fill 455 131 465 455 134 465 minecraft:blackstone
setblock 455 131 503 minecraft:blackstone
setblock 455 131 504 minecraft:polished_blackstone_bricks
fill 456 131 464 456 134 464 minecraft:blackstone
setblock 456 131 503 minecraft:polished_blackstone_bricks
fill 456 131 504 456 134 504 minecraft:blackstone
setblock 457 131 466 minecraft:blackstone
setblock 458 131 466 minecraft:polished_blackstone_bricks
setblock 459 131 465 minecraft:polished_blackstone_bricks
fill 459 131 466 459 134 466 minecraft:blackstone
setblock 460 131 464 minecraft:polished_blackstone_bricks
fill 460 131 465 460 134 465 minecraft:blackstone
setblock 460 131 504 minecraft:polished_blackstone_bricks
fill 461 131 464 461 134 464 minecraft:blackstone
fill 461 131 466 461 132 466 minecraft:blackstone
fill 461 131 504 461 133 504 minecraft:blackstone
setblock 463 131 466 minecraft:polished_blackstone_bricks
fill 463 131 467 463 134 467 minecraft:blackstone
fill 463 131 469 463 132 469 minecraft:blackstone
setblock 463 131 482 minecraft:blackstone
setblock 463 131 486 minecraft:polished_blackstone_bricks
setblock 464 131 465 minecraft:polished_blackstone_bricks
fill 464 131 466 464 134 466 minecraft:blackstone
setblock 464 131 470 minecraft:polished_blackstone_bricks
fill 464 131 471 464 132 473 minecraft:blackstone
setblock 464 131 480 minecraft:polished_blackstone_bricks
fill 464 131 481 464 132 481 minecraft:blackstone
setblock 464 131 485 minecraft:polished_blackstone_bricks
fill 464 131 486 464 134 486 minecraft:blackstone
setblock 424 132 464 minecraft:polished_blackstone_bricks
fill 424 132 465 427 132 465 minecraft:blackstone
setblock 424 132 469 minecraft:polished_blackstone_bricks
fill 424 132 470 424 134 471 minecraft:blackstone
setblock 424 132 503 minecraft:blackstone
setblock 424 132 504 minecraft:polished_blackstone_bricks
fill 425 132 464 425 135 464 minecraft:blackstone
setblock 425 132 468 minecraft:polished_blackstone_bricks
fill 425 132 504 425 135 504 minecraft:blackstone
setblock 428 132 465 minecraft:polished_blackstone_bricks
fill 428 132 503 429 132 503 minecraft:blackstone
setblock 429 132 464 minecraft:polished_blackstone_bricks
fill 429 132 465 431 132 466 minecraft:blackstone
setblock 429 132 504 minecraft:polished_blackstone_bricks
fill 430 132 464 433 132 464 minecraft:blackstone
setblock 430 132 503 minecraft:polished_blackstone_bricks
fill 430 132 504 433 132 504 minecraft:blackstone
setblock 431 132 502 minecraft:polished_blackstone_bricks
fill 431 132 503 434 132 503 minecraft:blackstone
setblock 432 132 465 minecraft:blackstone
setblock 432 132 466 minecraft:polished_blackstone_bricks
fill 432 132 502 435 132 502 minecraft:blackstone
setblock 433 132 465 minecraft:polished_blackstone_bricks
fill 433 132 466 433 135 466 minecraft:blackstone
setblock 434 132 464 minecraft:polished_blackstone_bricks
fill 434 132 465 434 135 465 minecraft:blackstone
setblock 434 132 504 minecraft:polished_blackstone_bricks
fill 435 132 464 435 135 464 minecraft:blackstone
setblock 435 132 503 minecraft:polished_blackstone_bricks
fill 435 132 504 438 132 504 minecraft:blackstone
setblock 436 132 502 minecraft:polished_blackstone_bricks
fill 436 132 503 439 132 503 minecraft:blackstone
setblock 437 132 466 minecraft:polished_blackstone_bricks
fill 437 132 502 437 134 502 minecraft:blackstone
setblock 438 132 465 minecraft:polished_blackstone_bricks
setblock 438 132 466 minecraft:blackstone
setblock 439 132 464 minecraft:polished_blackstone_bricks
fill 439 132 465 439 134 465 minecraft:blackstone
setblock 439 132 504 minecraft:polished_blackstone_bricks
fill 440 132 464 440 135 464 minecraft:blackstone
setblock 440 132 503 minecraft:polished_blackstone_bricks
fill 440 132 504 440 135 504 minecraft:blackstone
setblock 441 132 503 minecraft:blackstone
setblock 444 132 504 minecraft:polished_blackstone_bricks
setblock 448 132 464 minecraft:blackstone
setblock 449 132 464 minecraft:polished_blackstone_bricks
setblock 449 132 504 minecraft:polished_blackstone_bricks
fill 450 132 464 450 135 464 minecraft:blackstone
fill 450 132 504 453 132 504 minecraft:blackstone
fill 451 132 465 452 132 465 minecraft:blackstone
setblock 453 132 465 minecraft:polished_blackstone_bricks
fill 453 132 466 453 135 466 minecraft:blackstone
setblock 454 132 464 minecraft:polished_blackstone_bricks
fill 454 132 465 454 135 465 minecraft:blackstone
setblock 454 132 504 minecraft:polished_blackstone_bricks
fill 455 132 464 455 135 464 minecraft:blackstone
setblock 455 132 503 minecraft:polished_blackstone_bricks
fill 455 132 504 455 135 504 minecraft:blackstone
setblock 456 132 503 minecraft:blackstone
setblock 457 132 466 minecraft:polished_blackstone_bricks
setblock 458 132 465 minecraft:polished_blackstone_bricks
fill 458 132 466 458 135 466 minecraft:blackstone
setblock 459 132 464 minecraft:polished_blackstone_bricks
fill 459 132 465 459 135 465 minecraft:blackstone
setblock 459 132 504 minecraft:polished_blackstone_bricks
fill 460 132 464 460 135 464 minecraft:blackstone
fill 460 132 504 460 134 504 minecraft:blackstone
setblock 462 132 466 minecraft:polished_blackstone_bricks
fill 462 132 467 462 135 467 minecraft:blackstone
setblock 463 132 465 minecraft:polished_blackstone_bricks
fill 463 132 466 463 135 466 minecraft:blackstone
setblock 463 132 470 minecraft:polished_blackstone_bricks
fill 463 132 471 463 135 471 minecraft:blackstone
setblock 463 132 485 minecraft:polished_blackstone_bricks
setblock 463 132 486 minecraft:blackstone
setblock 464 132 464 minecraft:polished_blackstone_bricks
fill 464 132 465 464 135 465 minecraft:blackstone
setblock 464 132 469 minecraft:polished_blackstone_bricks
fill 464 132 470 464 135 470 minecraft:blackstone
setblock 464 132 474 minecraft:polished_blackstone_bricks
setblock 464 132 480 minecraft:blackstone
setblock 464 132 484 minecraft:polished_blackstone_bricks
fill 464 132 485 464 134 485 minecraft:blackstone
setblock 464 132 489 minecraft:polished_blackstone_bricks
fill 424 133 464 424 135 465 minecraft:blackstone
setblock 424 133 468 minecraft:polished_blackstone_bricks
fill 424 133 469 425 135 469 minecraft:blackstone
setblock 424 133 487 minecraft:blackstone
setblock 424 133 488 minecraft:polished_blackstone_bricks
setblock 424 133 503 minecraft:polished_blackstone_bricks
fill 424 133 504 424 136 504 minecraft:blackstone
fill 425 133 465 426 133 465 minecraft:blackstone
setblock 425 133 467 minecraft:polished_blackstone_bricks
fill 425 133 468 425 136 468 minecraft:blackstone
setblock 427 133 465 minecraft:polished_blackstone_bricks
fill 427 133 466 430 133 466 minecraft:blackstone
fill 427 133 503 428 133 503 minecraft:blackstone
setblock 428 133 464 minecraft:polished_blackstone_bricks
fill 428 133 465 431 133 465 minecraft:blackstone
setblock 428 133 504 minecraft:polished_blackstone_bricks
fill 429 133 464 432 133 464 minecraft:blackstone
setblock 429 133 503 minecraft:polished_blackstone_bricks
fill 429 133 504 432 133 504 minecraft:blackstone
fill 430 133 503 433 133 503 minecraft:blackstone
setblock 431 133 466 minecraft:polished_blackstone_bricks
fill 431 133 502 434 133 502 minecraft:blackstone
setblock 432 133 465 minecraft:polished_blackstone_bricks
fill 432 133 466 432 136 466 minecraft:blackstone
setblock 433 133 464 minecraft:polished_blackstone_bricks
fill 433 133 465 433 136 465 minecraft:blackstone
setblock 433 133 504 minecraft:polished_blackstone_bricks
fill 434 133 464 434 136 464 minecraft:blackstone
setblock 434 133 503 minecraft:polished_blackstone_bricks
fill 434 133 504 437 133 504 minecraft:blackstone
setblock 435 133 466 minecraft:blackstone
setblock 435 133 502 minecraft:polished_blackstone_bricks
fill 435 133 503 438 133 503 minecraft:blackstone
setblock 436 133 466 minecraft:polished_blackstone_bricks
fill 436 133 502 436 134 502 minecraft:blackstone
setblock 437 133 465 minecraft:polished_blackstone_bricks
fill 437 133 466 437 134 466 minecraft:blackstone
setblock 438 133 464 minecraft:polished_blackstone_bricks
fill 438 133 465 438 135 465 minecraft:blackstone
setblock 438 133 504 minecraft:polished_blackstone_bricks
fill 439 133 464 439 136 464 minecraft:blackstone
setblock 439 133 503 minecraft:polished_blackstone_bricks
fill 439 133 504 439 136 504 minecraft:blackstone
setblock 440 133 503 minecraft:blackstone
setblock 443 133 464 minecraft:polished_blackstone_bricks
setblock 443 133 504 minecraft:polished_blackstone_bricks
setblock 447 133 464 minecraft:blackstone
setblock 448 133 464 minecraft:polished_blackstone_bricks
fill 449 133 464 449 136 464 minecraft:blackstone
fill 449 133 504 452 133 504 minecraft:blackstone
fill 450 133 465 451 133 465 minecraft:blackstone
setblock 452 133 465 minecraft:polished_blackstone_bricks
fill 452 133 466 452 136 466 minecraft:blackstone
setblock 453 133 464 minecraft:polished_blackstone_bricks
fill 453 133 465 453 136 465 minecraft:blackstone
fill 453 133 498 453 134 499 minecraft:light_blue_stained_glass
setblock 453 133 504 minecraft:polished_blackstone_bricks
fill 454 133 464 454 136 464 minecraft:blackstone
fill 454 133 504 454 136 504 minecraft:blackstone
setblock 455 133 467 minecraft:polished_blackstone_bricks
setblock 456 133 465 minecraft:blackstone
setblock 456 133 466 minecraft:polished_blackstone_bricks
fill 456 133 467 458 134 467 minecraft:blackstone
setblock 457 133 465 minecraft:polished_blackstone_bricks
fill 457 133 466 457 136 466 minecraft:blackstone
setblock 458 133 464 minecraft:polished_blackstone_bricks
fill 458 133 465 458 136 465 minecraft:blackstone
setblock 458 133 504 minecraft:polished_blackstone_bricks
fill 459 133 464 459 136 464 minecraft:blackstone
fill 459 133 504 459 134 504 minecraft:blackstone
setblock 461 133 466 minecraft:polished_blackstone_bricks
setblock 462 133 465 minecraft:polished_blackstone_bricks
fill 462 133 466 462 135 466 minecraft:blackstone
fill 462 133 468 462 133 469 minecraft:blackstone
setblock 463 133 464 minecraft:polished_blackstone_bricks
fill 463 133 465 463 136 465 minecraft:blackstone
setblock 463 133 469 minecraft:polished_blackstone_bricks
fill 463 133 470 463 136 470 minecraft:blackstone
fill 464 133 464 464 136 464 minecraft:blackstone
setblock 464 133 468 minecraft:polished_blackstone_bricks
fill 464 133 469 464 136 469 minecraft:blackstone
fill 464 133 471 464 133 472 minecraft:blackstone
setblock 464 133 473 minecraft:polished_blackstone_bricks
fill 464 133 474 464 136 474 minecraft:blackstone
setblock 464 133 483 minecraft:polished_blackstone_bricks
fill 464 133 484 464 134 484 minecraft:blackstone
setblock 464 133 487 minecraft:blackstone
setblock 464 133 488 minecraft:polished_blackstone_bricks
fill 464 133 489 464 135 489 minecraft:blackstone
setblock 424 134 467 minecraft:polished_blackstone_bricks
fill 424 134 468 424 137 468 minecraft:blackstone
setblock 424 134 472 minecraft:polished_blackstone_bricks
setblock 424 134 487 minecraft:polished_blackstone_bricks
fill 424 134 488 424 135 490 minecraft:blackstone
fill 424 134 503 424 136 503 minecraft:blackstone
setblock 425 134 465 minecraft:blackstone
setblock 425 134 466 minecraft:polished_blackstone_bricks
fill 425 134 467 425 137 467 minecraft:blackstone
setblock 426 134 465 minecraft:polished_blackstone_bricks
fill 426 134 466 429 134 466 minecraft:blackstone
setblock 427 134 464 minecraft:polished_blackstone_bricks
fill 427 134 465 430 134 465 minecraft:blackstone
setblock 427 134 503 minecraft:blackstone
setblock 427 134 504 minecraft:polished_blackstone_bricks
fill 428 134 464 431 134 464 minecraft:blackstone
setblock 428 134 503 minecraft:polished_blackstone_bricks
fill 428 134 504 431 134 504 minecraft:blackstone
fill 429 134 503 432 134 503 minecraft:blackstone
setblock 430 134 466 minecraft:polished_blackstone_bricks
setblock 431 134 465 minecraft:polished_blackstone_bricks
fill 431 134 466 431 137 466 minecraft:blackstone
fill 431 134 502 433 134 502 minecraft:blackstone
setblock 432 134 464 minecraft:polished_blackstone_bricks
fill 432 134 465 432 137 465 minecraft:blackstone
setblock 432 134 504 minecraft:polished_blackstone_bricks
fill 433 134 464 433 137 464 minecraft:blackstone
setblock 433 134 503 minecraft:polished_blackstone_bricks
fill 433 134 504 436 134 504 minecraft:blackstone
setblock 434 134 502 minecraft:polished_blackstone_bricks
fill 434 134 503 437 134 503 minecraft:blackstone
setblock 435 134 466 minecraft:polished_blackstone_bricks
fill 435 134 502 435 135 502 minecraft:blackstone
setblock 436 134 465 minecraft:polished_blackstone_bricks
fill 436 134 466 436 135 466 minecraft:blackstone
setblock 437 134 464 minecraft:polished_blackstone_bricks
fill 437 134 465 437 136 465 minecraft:blackstone
fill 437 134 481 439 176 484 minecraft:polished_blackstone_bricks
setblock 437 134 504 minecraft:polished_blackstone_bricks
fill 438 134 464 438 137 464 minecraft:blackstone
setblock 438 134 503 minecraft:polished_blackstone_bricks
fill 438 134 504 438 137 504 minecraft:blackstone
setblock 439 134 503 minecraft:blackstone
fill 440 134 482 440 176 483 minecraft:polished_blackstone_bricks
setblock 442 134 464 minecraft:polished_blackstone_bricks
setblock 442 134 504 minecraft:polished_blackstone_bricks
setblock 447 134 464 minecraft:polished_blackstone_bricks
fill 448 134 464 448 137 464 minecraft:blackstone
fill 449 134 465 450 134 465 minecraft:blackstone
fill 449 134 504 451 134 504 minecraft:blackstone
setblock 451 134 465 minecraft:polished_blackstone_bricks
fill 451 134 466 451 137 466 minecraft:blackstone
setblock 452 134 464 minecraft:polished_blackstone_bricks
fill 452 134 465 452 137 465 minecraft:blackstone
setblock 452 134 504 minecraft:polished_blackstone_bricks
fill 453 134 464 453 137 464 minecraft:blackstone
setblock 453 134 467 minecraft:blackstone
fill 453 134 504 453 137 504 minecraft:blackstone
setblock 454 134 466 minecraft:blackstone
setblock 454 134 467 minecraft:polished_blackstone_bricks
setblock 455 134 466 minecraft:polished_blackstone_bricks
fill 455 134 467 455 136 467 minecraft:blackstone
setblock 456 134 465 minecraft:polished_blackstone_bricks
fill 456 134 466 456 137 466 minecraft:blackstone
setblock 457 134 464 minecraft:polished_blackstone_bricks
fill 457 134 465 457 137 465 minecraft:blackstone
setblock 457 134 504 minecraft:polished_blackstone_bricks
fill 458 134 464 458 137 464 minecraft:blackstone
fill 458 134 504 458 135 504 minecraft:blackstone
setblock 460 134 466 minecraft:polished_blackstone_bricks
setblock 461 134 465 minecraft:polished_blackstone_bricks
fill 461 134 466 461 135 466 minecraft:blackstone
setblock 462 134 464 minecraft:polished_blackstone_bricks
fill 462 134 465 462 137 465 minecraft:blackstone
setblock 462 134 468 minecraft:blackstone
setblock 462 134 469 minecraft:polished_blackstone_bricks
fill 463 134 464 463 137 464 minecraft:blackstone
setblock 463 134 468 minecraft:polished_blackstone_bricks
fill 463 134 469 463 137 469 minecraft:blackstone
setblock 463 134 472 minecraft:blackstone
setblock 464 134 467 minecraft:polished_blackstone_bricks
fill 464 134 468 464 137 468 minecraft:blackstone
setblock 464 134 471 minecraft:blackstone
setblock 464 134 472 minecraft:polished_blackstone_bricks
fill 464 134 473 464 137 473 minecraft:blackstone
fill 464 134 475 464 135 475 minecraft:blackstone
setblock 464 134 483 minecraft:blackstone
setblock 464 134 487 minecraft:polished_blackstone_bricks
fill 464 134 488 464 135 488 minecraft:blackstone
fill 464 134 490 464 135 490 minecraft:blackstone
setblock 424 135 466 minecraft:polished_blackstone_bricks
fill 424 135 467 424 138 467 minecraft:blackstone
setblock 424 135 470 minecraft:blackstone
setblock 424 135 471 minecraft:polished_blackstone_bricks
fill 424 135 472 424 138 472 minecraft:blackstone
setblock 424 135 491 minecraft:polished_blackstone_bricks
fill 424 135 492 424 138 492 minecraft:blackstone
setblock 425 135 465 minecraft:polished_blackstone_bricks
fill 425 135 466 428 135 466 minecraft:blackstone
setblock 425 135 470 minecraft:polished_blackstone_bricks
setblock 426 135 464 minecraft:polished_blackstone_bricks
fill 426 135 465 429 135 465 minecraft:blackstone
setblock 426 135 504 minecraft:polished_blackstone_bricks
fill 427 135 464 430 135 464 minecraft:blackstone
setblock 427 135 503 minecraft:polished_blackstone_bricks
fill 427 135 504 430 135 504 minecraft:blackstone
fill 428 135 503 431 135 503 minecraft:blackstone
setblock 429 135 466 minecraft:polished_blackstone_bricks
setblock 430 135 465 minecraft:polished_blackstone_bricks
fill 430 135 466 430 137 466 minecraft:blackstone
setblock 431 135 464 minecraft:polished_blackstone_bricks
fill 431 135 465 431 138 465 minecraft:blackstone
fill 431 135 502 432 135 502 minecraft:blackstone
setblock 431 135 504 minecraft:polished_blackstone_bricks
fill 432 135 464 432 138 464 minecraft:blackstone
setblock 432 135 503 minecraft:polished_blackstone_bricks
fill 432 135 504 435 135 504 minecraft:blackstone
setblock 433 135 502 minecraft:polished_blackstone_bricks
fill 433 135 503 436 135 503 minecraft:blackstone
setblock 434 135 466 minecraft:polished_blackstone_bricks
fill 434 135 502 434 136 502 minecraft:blackstone
setblock 435 135 465 minecraft:polished_blackstone_bricks
fill 435 135 466 435 136 466 minecraft:blackstone
setblock 436 135 464 minecraft:polished_blackstone_bricks
fill 436 135 465 436 137 465 minecraft:blackstone
fill 436 135 481 436 136 484 minecraft:blackstone
setblock 436 135 504 minecraft:polished_blackstone_bricks
fill 437 135 464 437 137 464 minecraft:blackstone
fill 437 135 480 439 136 480 minecraft:blackstone
fill 437 135 485 439 136 485 minecraft:blackstone
setblock 437 135 503 minecraft:polished_blackstone_bricks
fill 437 135 504 437 137 504 minecraft:blackstone
setblock 438 135 503 minecraft:blackstone
fill 440 135 481 440 136 481 minecraft:blackstone
fill 440 135 484 440 136 484 minecraft:blackstone
setblock 441 135 464 minecraft:polished_blackstone_bricks
fill 441 135 482 441 136 483 minecraft:blackstone
setblock 441 135 504 minecraft:polished_blackstone_bricks
fill 447 135 464 447 136 464 minecraft:blackstone
setblock 449 135 465 minecraft:blackstone
setblock 450 135 465 minecraft:polished_blackstone_bricks
setblock 450 135 504 minecraft:blackstone
setblock 451 135 464 minecraft:polished_blackstone_bricks
fill 451 135 465 451 138 465 minecraft:blackstone
setblock 451 135 504 minecraft:polished_blackstone_bricks
fill 452 135 464 452 138 464 minecraft:blackstone
fill 452 135 504 452 137 504 minecraft:blackstone
setblock 453 135 467 minecraft:polished_blackstone_bricks
setblock 454 135 466 minecraft:polished_blackstone_bricks
fill 454 135 467 454 136 467 minecraft:blackstone
setblock 455 135 465 minecraft:polished_blackstone_bricks
fill 455 135 466 455 138 466 minecraft:blackstone
setblock 456 135 464 minecraft:polished_blackstone_bricks
fill 456 135 465 456 138 465 minecraft:blackstone
fill 456 135 467 457 135 467 minecraft:blackstone
setblock 456 135 504 minecraft:polished_blackstone_bricks
fill 457 135 464 457 138 464 minecraft:blackstone
setblock 457 135 504 minecraft:blackstone
setblock 458 135 467 minecraft:polished_blackstone_bricks
setblock 459 135 466 minecraft:polished_blackstone_bricks
setblock 460 135 465 minecraft:polished_blackstone_bricks
fill 460 135 466 460 136 466 minecraft:blackstone
setblock 461 135 464 minecraft:polished_blackstone_bricks
fill 461 135 465 461 137 465 minecraft:blackstone
fill 462 135 464 462 138 464 minecraft:blackstone
setblock 462 135 468 minecraft:polished_blackstone_bricks
fill 462 135 469 462 135 470 minecraft:blackstone
setblock 463 135 467 minecraft:polished_blackstone_bricks
fill 463 135 468 463 138 468 minecraft:blackstone
setblock 463 135 472 minecraft:polished_blackstone_bricks
setblock 464 135 466 minecraft:polished_blackstone_bricks
fill 464 135 467 464 138 467 minecraft:blackstone
setblock 464 135 471 minecraft:polished_blackstone_bricks
fill 464 135 472 464 138 472 minecraft:blackstone
setblock 464 135 486 minecraft:polished_blackstone_bricks
setblock 464 135 487 minecraft:blackstone
setblock 424 136 464 minecraft:blackstone
setblock 424 136 465 minecraft:polished_blackstone_bricks
fill 424 136 466 425 138 466 minecraft:blackstone
setblock 424 136 469 minecraft:blackstone
setblock 424 136 470 minecraft:polished_blackstone_bricks
fill 424 136 471 424 139 471 minecraft:blackstone
setblock 424 136 489 minecraft:blackstone
setblock 424 136 490 minecraft:polished_blackstone_bricks
fill 424 136 491 424 139 491 minecraft:blackstone
fill 424 136 493 424 137 493 minecraft:blackstone
setblock 425 136 464 minecraft:polished_blackstone_bricks
fill 425 136 465 428 136 465 minecraft:blackstone
setblock 425 136 469 minecraft:polished_blackstone_bricks
fill 425 136 470 425 137 470 minecraft:blackstone
setblock 425 136 504 minecraft:polished_blackstone_bricks
fill 426 136 464 429 136 464 minecraft:blackstone
setblock 426 136 466 minecraft:light[level=11]
setblock 426 136 474 minecraft:light[level=11]
setblock 426 136 482 minecraft:light[level=11]
setblock 426 136 490 minecraft:light[level=11]
setblock 426 136 498 minecraft:light[level=11]
fill 426 136 504 429 136 504 minecraft:blackstone
setblock 427 136 466 minecraft:blackstone
setblock 428 136 466 minecraft:polished_blackstone_bricks
fill 428 136 503 430 136 503 minecraft:blackstone
setblock 429 136 465 minecraft:polished_blackstone_bricks
fill 429 136 466 429 137 466 minecraft:blackstone
setblock 430 136 464 minecraft:polished_blackstone_bricks
fill 430 136 465 430 139 465 minecraft:blackstone
setblock 430 136 504 minecraft:polished_blackstone_bricks
fill 431 136 464 431 139 464 minecraft:blackstone
setblock 431 136 502 minecraft:blackstone
setblock 431 136 503 minecraft:polished_blackstone_bricks
fill 431 136 504 434 136 504 minecraft:blackstone
setblock 432 136 502 minecraft:polished_blackstone_bricks
fill 432 136 503 435 136 503 minecraft:blackstone
setblock 433 136 466 minecraft:polished_blackstone_bricks
setblock 433 136 502 minecraft:blackstone
setblock 434 136 465 minecraft:polished_blackstone_bricks
setblock 434 136 466 minecraft:blackstone
setblock 434 136 474 minecraft:light[level=11]
setblock 434 136 482 minecraft:light[level=11]
setblock 434 136 490 minecraft:light[level=11]
setblock 434 136 498 minecraft:light[level=11]
setblock 435 136 464 minecraft:polished_blackstone_bricks
fill 435 136 465 435 137 465 minecraft:blackstone
fill 435 136 481 435 136 484 minecraft:blackstone
setblock 435 136 504 minecraft:polished_blackstone_bricks
fill 436 136 464 436 138 464 minecraft:blackstone
setblock 436 136 480 minecraft:blackstone
setblock 436 136 485 minecraft:blackstone
setblock 436 136 503 minecraft:polished_blackstone_bricks
fill 436 136 504 436 138 504 minecraft:blackstone
fill 437 136 479 439 136 479 minecraft:blackstone
setblock 437 136 503 minecraft:blackstone
fill 438 136 486 439 136 486 minecraft:blackstone
fill 440 136 480 441 136 480 minecraft:blackstone
setblock 440 136 485 minecraft:blackstone
setblock 441 136 481 minecraft:blackstone
setblock 441 136 484 minecraft:blackstone
setblock 442 136 466 minecraft:light[level=11]
setblock 442 136 474 minecraft:light[level=11]
setblock 442 136 482 minecraft:light[level=11]
setblock 442 136 490 minecraft:light[level=11]
setblock 442 136 498 minecraft:light[level=11]
setblock 449 136 465 minecraft:polished_blackstone_bricks
setblock 450 136 464 minecraft:polished_blackstone_bricks
fill 450 136 465 450 139 465 minecraft:blackstone
setblock 450 136 466 minecraft:light[level=11]
setblock 450 136 474 minecraft:light[level=11]
setblock 450 136 482 minecraft:light[level=11]
setblock 450 136 490 minecraft:light[level=11]
setblock 450 136 498 minecraft:light[level=11]
setblock 450 136 504 minecraft:polished_blackstone_bricks
fill 451 136 464 451 139 464 minecraft:blackstone
setblock 451 136 504 minecraft:blackstone
setblock 453 136 466 minecraft:polished_blackstone_bricks
setblock 453 136 467 minecraft:blackstone
setblock 454 136 465 minecraft:polished_blackstone_bricks
fill 454 136 466 454 138 466 minecraft:blackstone
setblock 455 136 464 minecraft:polished_blackstone_bricks
fill 455 136 465 455 139 465 minecraft:blackstone
setblock 455 136 504 minecraft:polished_blackstone_bricks
fill 456 136 464 456 139 464 minecraft:blackstone
setblock 456 136 467 minecraft:blackstone
setblock 456 136 504 minecraft:blackstone
setblock 458 136 466 minecraft:polished_blackstone_bricks
setblock 458 136 474 minecraft:light[level=11]
setblock 458 136 482 minecraft:light[level=11]
setblock 458 136 490 minecraft:light[level=11]
setblock 458 136 498 minecraft:light[level=11]
setblock 459 136 465 minecraft:polished_blackstone_bricks
setblock 459 136 466 minecraft:blackstone
setblock 460 136 464 minecraft:polished_blackstone_bricks
fill 460 136 465 460 137 465 minecraft:blackstone
fill 461 136 464 461 138 464 minecraft:blackstone
setblock 462 136 467 minecraft:polished_blackstone_bricks
fill 462 136 468 462 136 469 minecraft:blackstone
setblock 463 136 466 minecraft:polished_blackstone_bricks
fill 463 136 467 463 139 467 minecraft:blackstone
setblock 463 136 471 minecraft:polished_blackstone_bricks
fill 463 136 472 463 139 472 minecraft:blackstone
setblock 464 136 465 minecraft:polished_blackstone_bricks
fill 464 136 466 464 139 466 minecraft:blackstone
setblock 464 136 470 minecraft:polished_blackstone_bricks
fill 464 136 471 464 139 471 minecraft:blackstone
setblock 464 136 475 minecraft:polished_blackstone_bricks
setblock 424 137 464 minecraft:polished_blackstone_bricks
fill 424 137 465 427 137 465 minecraft:blackstone
setblock 424 137 469 minecraft:polished_blackstone_bricks
fill 424 137 470 424 140 470 minecraft:blackstone
setblock 424 137 489 minecraft:polished_blackstone_bricks
fill 424 137 490 424 139 490 minecraft:blackstone
setblock 424 137 494 minecraft:polished_blackstone_bricks
setblock 424 137 504 minecraft:polished_blackstone_bricks
fill 425 137 464 428 137 464 minecraft:blackstone
setblock 425 137 468 minecraft:polished_blackstone_bricks
fill 425 137 469 425 138 469 minecraft:blackstone
fill 425 137 504 428 137 504 minecraft:blackstone
setblock 428 137 465 minecraft:polished_blackstone_bricks
setblock 428 137 466 minecraft:blackstone
fill 428 137 503 429 137 503 minecraft:blackstone
setblock 429 137 464 minecraft:polished_blackstone_bricks
fill 429 137 465 429 139 465 minecraft:blackstone
setblock 429 137 504 minecraft:polished_blackstone_bricks
fill 430 137 464 430 140 464 minecraft:blackstone
setblock 430 137 503 minecraft:polished_blackstone_bricks
fill 430 137 504 433 137 504 minecraft:blackstone
fill 431 137 503 434 137 503 minecraft:blackstone
setblock 432 137 466 minecraft:polished_blackstone_bricks
setblock 433 137 465 minecraft:polished_blackstone_bricks
setblock 433 137 466 minecraft:blackstone
setblock 434 137 464 minecraft:polished_blackstone_bricks
fill 434 137 465 434 138 465 minecraft:blackstone
setblock 434 137 504 minecraft:polished_blackstone_bricks
fill 435 137 464 435 138 464 minecraft:blackstone
setblock 435 137 503 minecraft:polished_blackstone_bricks
fill 435 137 504 435 139 504 minecraft:blackstone
setblock 449 137 464 minecraft:polished_blackstone_bricks
setblock 449 137 465 minecraft:blackstone
fill 450 137 464 450 140 464 minecraft:blackstone
setblock 452 137 466 minecraft:polished_blackstone_bricks
setblock 453 137 465 minecraft:polished_blackstone_bricks
fill 453 137 466 453 138 466 minecraft:blackstone
setblock 454 137 464 minecraft:polished_blackstone_bricks
fill 454 137 465 454 139 465 minecraft:blackstone
setblock 454 137 504 minecraft:polished_blackstone_bricks
fill 455 137 464 455 140 464 minecraft:blackstone
setblock 457 137 466 minecraft:polished_blackstone_bricks
setblock 458 137 465 minecraft:polished_blackstone_bricks
setblock 458 137 466 minecraft:blackstone
setblock 459 137 464 minecraft:polished_blackstone_bricks
fill 459 137 465 459 138 465 minecraft:blackstone
fill 460 137 464 460 138 464 minecraft:blackstone
setblock 463 137 465 minecraft:polished_blackstone_bricks
fill 463 137 466 463 138 466 minecraft:blackstone
setblock 463 137 470 minecraft:polished_blackstone_bricks
fill 463 137 471 463 140 471 minecraft:blackstone
setblock 464 137 464 minecraft:polished_blackstone_bricks
fill 464 137 465 464 140 465 minecraft:blackstone
setblock 464 137 469 minecraft:polished_blackstone_bricks
fill 464 137 470 464 140 470 minecraft:blackstone
setblock 464 137 474 minecraft:polished_blackstone_bricks
fill 464 137 475 464 140 475 minecraft:blackstone
fill 424 138 464 424 139 465 minecraft:blackstone
setblock 424 138 468 minecraft:polished_blackstone_bricks
fill 424 138 469 424 141 469 minecraft:blackstone
setblock 424 138 493 minecraft:polished_blackstone_bricks
fill 424 138 494 424 140 495 minecraft:blackstone
fill 425 138 464 427 138 464 minecraft:blackstone
setblock 425 138 467 minecraft:polished_blackstone_bricks
setblock 425 138 468 minecraft:blackstone
fill 425 138 504 427 138 504 minecraft:blackstone
setblock 426 138 465 minecraft:blackstone
setblock 427 138 465 minecraft:polished_blackstone_bricks
setblock 428 138 464 minecraft:polished_blackstone_bricks
fill 428 138 465 428 139 465 minecraft:blackstone
setblock 428 138 503 minecraft:blackstone
setblock 428 138 504 minecraft:polished_blackstone_bricks
fill 429 138 464 429 141 464 minecraft:blackstone
setblock 429 138 503 minecraft:polished_blackstone_bricks
fill 429 138 504 432 138 504 minecraft:blackstone
fill 430 138 503 433 138 503 minecraft:blackstone
setblock 432 138 465 minecraft:polished_blackstone_bricks
setblock 433 138 464 minecraft:polished_blackstone_bricks
setblock 433 138 465 minecraft:blackstone
setblock 433 138 504 minecraft:polished_blackstone_bricks
fill 434 138 464 434 139 464 minecraft:blackstone
setblock 434 138 503 minecraft:polished_blackstone_bricks
fill 434 138 504 434 140 504 minecraft:blackstone
setblock 448 138 464 minecraft:polished_blackstone_bricks
fill 449 138 464 449 140 464 minecraft:blackstone
setblock 452 138 465 minecraft:polished_blackstone_bricks
setblock 452 138 466 minecraft:blackstone
setblock 453 138 464 minecraft:polished_blackstone_bricks
fill 453 138 465 453 140 465 minecraft:blackstone
fill 454 138 464 454 141 464 minecraft:blackstone
setblock 456 138 466 minecraft:polished_blackstone_bricks
setblock 457 138 465 minecraft:polished_blackstone_bricks
setblock 458 138 464 minecraft:polished_blackstone_bricks
setblock 458 138 465 minecraft:blackstone
fill 459 138 464 459 139 464 minecraft:blackstone
setblock 463 138 464 minecraft:polished_blackstone_bricks
setblock 463 138 469 minecraft:polished_blackstone_bricks
fill 463 138 470 463 141 470 minecraft:blackstone
fill 464 138 464 464 141 464 minecraft:blackstone
setblock 464 138 468 minecraft:polished_blackstone_bricks
fill 464 138 469 464 141 469 minecraft:blackstone
setblock 464 138 473 minecraft:polished_blackstone_bricks
fill 464 138 474 464 141 474 minecraft:blackstone
setblock 424 139 466 minecraft:blackstone
setblock 424 139 467 minecraft:polished_blackstone_bricks
fill 424 139 468 424 142 468 minecraft:blackstone
setblock 424 139 472 minecraft:polished_blackstone_bricks
setblock 424 139 492 minecraft:polished_blackstone_bricks
fill 424 139 493 424 142 493 minecraft:blackstone
setblock 424 139 496 minecraft:blackstone
setblock 424 139 497 minecraft:polished_blackstone_bricks
fill 425 139 464 426 139 464 minecraft:blackstone
setblock 426 139 504 minecraft:blackstone
setblock 427 139 464 minecraft:polished_blackstone_bricks
setblock 427 139 465 minecraft:blackstone
setblock 427 139 504 minecraft:polished_blackstone_bricks
fill 428 139 464 428 142 464 minecraft:blackstone
fill 428 139 504 431 139 504 minecraft:blackstone
fill 429 139 503 432 139 503 minecraft:blackstone
setblock 431 139 465 minecraft:polished_blackstone_bricks
setblock 432 139 464 minecraft:polished_blackstone_bricks
setblock 432 139 465 minecraft:blackstone
setblock 432 139 504 minecraft:polished_blackstone_bricks
fill 433 139 464 433 140 464 minecraft:blackstone
fill 433 139 504 433 142 504 minecraft:blackstone
fill 440 139 468 441 176 469 minecraft:polished_blackstone_bricks
setblock 451 139 465 minecraft:polished_blackstone_bricks
setblock 452 139 464 minecraft:polished_blackstone_bricks
fill 452 139 465 452 140 465 minecraft:blackstone
fill 453 139 464 453 142 464 minecraft:blackstone
setblock 456 139 465 minecraft:polished_blackstone_bricks
setblock 457 139 464 minecraft:polished_blackstone_bricks
setblock 458 139 464 minecraft:blackstone
setblock 463 139 464 minecraft:blackstone
setblock 463 139 468 minecraft:polished_blackstone_bricks
fill 463 139 469 463 142 469 minecraft:blackstone
setblock 464 139 467 minecraft:polished_blackstone_bricks
fill 464 139 468 464 142 468 minecraft:blackstone
setblock 464 139 472 minecraft:polished_blackstone_bricks
fill 464 139 473 464 142 473 minecraft:blackstone
setblock 424 140 465 minecraft:blackstone
setblock 424 140 466 minecraft:polished_blackstone_bricks
fill 424 140 467 424 143 467 minecraft:blackstone
setblock 424 140 471 minecraft:polished_blackstone_bricks
fill 424 140 472 424 143 472 minecraft:blackstone
setblock 424 140 491 minecraft:polished_blackstone_bricks
fill 424 140 492 424 143 492 minecraft:blackstone
setblock 424 140 496 minecraft:polished_blackstone_bricks
fill 424 140 497 424 142 498 minecraft:blackstone
setblock 425 140 464 minecraft:blackstone
fill 425 140 493 425 140 494 minecraft:blackstone
setblock 425 140 495 minecraft:polished_blackstone_bricks
setblock 426 140 464 minecraft:polished_blackstone_bricks
setblock 426 140 504 minecraft:polished_blackstone_bricks
fill 427 140 464 427 143 464 minecraft:blackstone
fill 427 140 504 430 140 504 minecraft:blackstone
fill 429 140 503 431 140 503 minecraft:blackstone
setblock 431 140 464 minecraft:polished_blackstone_bricks
setblock 431 140 504 minecraft:polished_blackstone_bricks
setblock 432 140 464 minecraft:blackstone
fill 432 140 504 432 143 504 minecraft:blackstone
fill 439 140 468 439 141 469 minecraft:blackstone
fill 440 140 470 441 141 470 minecraft:blackstone
fill 442 140 469 442 141 469 minecraft:blackstone
setblock 451 140 464 minecraft:polished_blackstone_bricks
fill 452 140 464 452 143 464 minecraft:blackstone
setblock 456 140 464 minecraft:polished_blackstone_bricks
setblock 463 140 468 minecraft:blackstone
setblock 463 140 472 minecraft:polished_blackstone_bricks
setblock 464 140 466 minecraft:polished_blackstone_bricks
fill 464 140 467 464 143 467 minecraft:blackstone
setblock 464 140 471 minecraft:polished_blackstone_bricks
fill 464 140 472 464 143 472 minecraft:blackstone
setblock 424 141 466 minecraft:blackstone
setblock 424 141 470 minecraft:polished_blackstone_bricks
fill 424 141 471 424 144 471 minecraft:blackstone
fill 424 141 473 424 142 473 minecraft:blackstone
fill 424 141 491 424 144 491 minecraft:blackstone
setblock 424 141 494 minecraft:blackstone
setblock 424 141 495 minecraft:polished_blackstone_bricks
fill 424 141 496 425 143 496 minecraft:blackstone
setblock 424 141 499 minecraft:blackstone
setblock 424 141 500 minecraft:polished_blackstone_bricks
fill 425 141 492 425 141 493 minecraft:blackstone
setblock 425 141 494 minecraft:polished_blackstone_bricks
fill 425 141 495 425 144 495 minecraft:blackstone
fill 425 141 497 425 142 497 minecraft:blackstone
setblock 425 141 504 minecraft:polished_blackstone_bricks
fill 426 141 464 426 144 464 minecraft:blackstone
fill 426 141 504 429 141 504 minecraft:blackstone
fill 429 141 503 430 141 503 minecraft:blackstone
setblock 430 141 464 minecraft:polished_blackstone_bricks
setblock 430 141 504 minecraft:polished_blackstone_bricks
setblock 431 141 464 minecraft:blackstone
fill 431 141 504 431 144 504 minecraft:blackstone
setblock 439 141 470 minecraft:blackstone
fill 440 141 467 441 141 467 minecraft:blackstone
setblock 442 141 468 minecraft:blackstone
setblock 442 141 470 minecraft:blackstone
setblock 450 141 464 minecraft:polished_blackstone_bricks
fill 451 141 464 451 144 464 minecraft:blackstone
setblock 463 141 471 minecraft:polished_blackstone_bricks
fill 463 141 472 463 144 472 minecraft:blackstone
setblock 464 141 465 minecraft:polished_blackstone_bricks
fill 464 141 466 464 144 466 minecraft:blackstone
setblock 464 141 470 minecraft:polished_blackstone_bricks
fill 464 141 471 464 144 471 minecraft:blackstone
setblock 464 141 475 minecraft:polished_blackstone_bricks
setblock 424 142 469 minecraft:polished_blackstone_bricks
fill 424 142 470 424 145 470 minecraft:blackstone
setblock 424 142 474 minecraft:polished_blackstone_bricks
fill 424 142 490 424 145 490 minecraft:blackstone
setblock 424 142 494 minecraft:polished_blackstone_bricks
fill 424 142 495 424 145 495 minecraft:blackstone
setblock 424 142 499 minecraft:polished_blackstone_bricks
fill 424 142 500 424 143 502 minecraft:blackstone
setblock 425 142 492 minecraft:blackstone
setblock 425 142 493 minecraft:polished_blackstone_bricks
fill 425 142 494 426 144 494 minecraft:blackstone
setblock 425 142 498 minecraft:polished_blackstone_bricks
fill 425 142 499 425 145 499 minecraft:blackstone
fill 425 142 504 428 142 504 minecraft:blackstone
fill 426 142 493 426 145 493 minecraft:blackstone
fill 426 142 495 426 142 496 minecraft:blackstone
setblock 426 142 497 minecraft:polished_blackstone_bricks
fill 428 142 503 429 142 503 minecraft:blackstone
setblock 429 142 464 minecraft:polished_blackstone_bricks
setblock 429 142 504 minecraft:polished_blackstone_bricks
setblock 430 142 464 minecraft:blackstone
setblock 430 142 503 minecraft:polished_blackstone_bricks
fill 430 142 504 430 145 504 minecraft:blackstone
fill 450 142 464 450 145 464 minecraft:blackstone
fill 454 142 466 458 143 470 minecraft:blackstone
fill 456 142 464 456 142 465 minecraft:blackstone
setblock 463 142 470 minecraft:polished_blackstone_bricks
fill 463 142 471 463 145 471 minecraft:blackstone
fill 463 142 473 463 143 473 minecraft:blackstone
setblock 464 142 464 minecraft:polished_blackstone_bricks
fill 464 142 465 464 145 465 minecraft:blackstone
setblock 464 142 469 minecraft:polished_blackstone_bricks
fill 464 142 470 464 145 470 minecraft:blackstone
setblock 464 142 474 minecraft:polished_blackstone_bricks
fill 464 142 475 464 144 476 minecraft:blackstone
fill 464 142 495 464 145 495 minecraft:blackstone
setblock 424 143 468 minecraft:polished_blackstone_bricks
fill 424 143 469 424 146 469 minecraft:blackstone
setblock 424 143 473 minecraft:polished_blackstone_bricks
fill 424 143 474 424 145 475 minecraft:blackstone
setblock 424 143 493 minecraft:polished_blackstone_bricks
fill 424 143 494 424 146 494 minecraft:blackstone
setblock 424 143 497 minecraft:blackstone
setblock 424 143 498 minecraft:polished_blackstone_bricks
fill 424 143 499 424 146 499 minecraft:blackstone
setblock 424 143 503 minecraft:polished_blackstone_bricks
fill 424 143 504 427 143 504 minecraft:blackstone
setblock 425 143 491 minecraft:blackstone
setblock 425 143 492 minecraft:polished_blackstone_bricks
fill 425 143 493 425 146 493 minecraft:blackstone
setblock 425 143 497 minecraft:polished_blackstone_bricks
fill 425 143 498 426 145 498 minecraft:blackstone
fill 425 143 500 425 143 501 minecraft:blackstone
setblock 426 143 495 minecraft:blackstone
setblock 426 143 496 minecraft:polished_blackstone_bricks
fill 426 143 497 426 146 497 minecraft:blackstone
fill 426 143 499 426 144 499 minecraft:blackstone
fill 426 143 503 428 143 503 minecraft:blackstone
setblock 428 143 464 minecraft:polished_blackstone_bricks
setblock 428 143 504 minecraft:polished_blackstone_bricks
fill 429 143 464 429 146 464 minecraft:blackstone
setblock 429 143 503 minecraft:polished_blackstone_bricks
fill 429 143 504 429 146 504 minecraft:blackstone
fill 430 143 503 430 146 503 minecraft:blackstone
fill 449 143 464 449 146 464 minecraft:blackstone
setblock 463 143 469 minecraft:polished_blackstone_bricks
fill 463 143 470 463 146 470 minecraft:blackstone
setblock 463 143 474 minecraft:polished_blackstone_bricks
fill 464 143 464 464 146 464 minecraft:blackstone
setblock 464 143 468 minecraft:polished_blackstone_bricks
fill 464 143 469 464 146 469 minecraft:blackstone
setblock 464 143 473 minecraft:polished_blackstone_bricks
fill 464 143 474 464 146 474 minecraft:blackstone
setblock 464 143 477 minecraft:blackstone
setblock 464 143 493 minecraft:polished_blackstone_bricks
fill 464 143 494 464 146 494 minecraft:blackstone
fill 464 143 496 464 143 497 minecraft:blackstone
setblock 464 143 498 minecraft:polished_blackstone_bricks
fill 464 143 499 464 146 499 minecraft:blackstone
setblock 424 144 467 minecraft:polished_blackstone_bricks
fill 424 144 468 424 147 468 minecraft:blackstone
setblock 424 144 472 minecraft:polished_blackstone_bricks
fill 424 144 473 425 146 473 minecraft:blackstone
setblock 424 144 476 minecraft:blackstone
setblock 424 144 477 minecraft:polished_blackstone_bricks
fill 424 144 489 424 146 489 minecraft:blackstone
setblock 424 144 492 minecraft:polished_blackstone_bricks
fill 424 144 493 424 147 493 minecraft:blackstone
setblock 424 144 496 minecraft:blackstone
setblock 424 144 497 minecraft:polished_blackstone_bricks
fill 424 144 498 424 147 498 minecraft:blackstone
fill 424 144 500 424 144 501 minecraft:blackstone
setblock 424 144 502 minecraft:polished_blackstone_bricks
fill 424 144 503 426 144 504 minecraft:blackstone
fill 425 144 464 425 145 464 minecraft:blackstone
fill 425 144 472 425 147 472 minecraft:blackstone
setblock 425 144 491 minecraft:polished_blackstone_bricks
fill 425 144 492 426 146 492 minecraft:blackstone
setblock 425 144 496 minecraft:polished_blackstone_bricks
fill 425 144 497 425 147 497 minecraft:blackstone
setblock 425 144 500 minecraft:blackstone
setblock 425 144 501 minecraft:polished_blackstone_bricks
fill 425 144 502 425 147 502 minecraft:blackstone
setblock 426 144 466 minecraft:light[level=11]
setblock 426 144 474 minecraft:light[level=11]
setblock 426 144 482 minecraft:light[level=11]
setblock 426 144 490 minecraft:light[level=11]
setblock 426 144 495 minecraft:polished_blackstone_bricks
fill 426 144 496 427 146 496 minecraft:blackstone
setblock 426 144 500 minecraft:polished_blackstone_bricks
fill 426 144 501 426 147 501 minecraft:blackstone
setblock 427 144 464 minecraft:polished_blackstone_bricks
setblock 427 144 494 minecraft:polished_blackstone_bricks
fill 427 144 495 427 147 495 minecraft:blackstone
fill 427 144 497 427 144 498 minecraft:blackstone
setblock 427 144 503 minecraft:blackstone
setblock 427 144 504 minecraft:polished_blackstone_bricks
fill 428 144 464 428 147 464 minecraft:blackstone
setblock 428 144 502 minecraft:blackstone
setblock 428 144 503 minecraft:polished_blackstone_bricks
fill 428 144 504 428 147 504 minecraft:blackstone
fill 429 144 503 429 147 503 minecraft:blackstone
fill 431 144 503 431 145 503 minecraft:blackstone
setblock 432 144 504 minecraft:polished_blackstone_bricks
setblock 434 144 466 minecraft:light[level=11]
setblock 434 144 474 minecraft:light[level=11]
setblock 434 144 482 minecraft:light[level=11]
setblock 434 144 490 minecraft:light[level=11]
setblock 434 144 498 minecraft:light[level=11]
setblock 442 144 466 minecraft:light[level=11]
setblock 442 144 474 minecraft:light[level=11]
setblock 442 144 482 minecraft:light[level=11]
setblock 442 144 490 minecraft:light[level=11]
setblock 442 144 498 minecraft:light[level=11]
fill 448 144 464 448 147 464 minecraft:blackstone
setblock 450 144 466 minecraft:light[level=11]
setblock 450 144 474 minecraft:light[level=11]
setblock 450 144 482 minecraft:light[level=11]
setblock 450 144 490 minecraft:light[level=11]
setblock 450 144 498 minecraft:light[level=11]
setblock 452 144 464 minecraft:polished_blackstone_bricks
fill 455 144 468 457 150 468 minecraft:polished_blackstone_bricks
fill 456 144 467 456 150 467 minecraft:polished_blackstone_bricks
fill 456 144 469 456 150 469 minecraft:polished_blackstone_bricks
setblock 458 144 466 minecraft:light[level=11]
setblock 458 144 474 minecraft:light[level=11]
setblock 458 144 482 minecraft:light[level=11]
setblock 458 144 490 minecraft:light[level=11]
setblock 458 144 498 minecraft:light[level=11]
fill 463 144 464 463 147 464 minecraft:blackstone
fill 463 144 469 463 147 469 minecraft:blackstone
setblock 463 144 473 minecraft:polished_blackstone_bricks
fill 463 144 474 463 146 475 minecraft:blackstone
setblock 464 144 467 minecraft:polished_blackstone_bricks
fill 464 144 468 464 147 468 minecraft:blackstone
setblock 464 144 472 minecraft:polished_blackstone_bricks
fill 464 144 473 464 147 473 minecraft:blackstone
setblock 464 144 477 minecraft:polished_blackstone_bricks
fill 464 144 478 464 147 478 minecraft:blackstone
setblock 464 144 492 minecraft:polished_blackstone_bricks
fill 464 144 493 464 147 493 minecraft:blackstone
setblock 464 144 496 minecraft:blackstone
setblock 464 144 497 minecraft:polished_blackstone_bricks
fill 464 144 498 464 147 498 minecraft:blackstone
fill 464 144 500 464 144 501 minecraft:blackstone
setblock 464 144 502 minecraft:polished_blackstone_bricks
fill 464 144 503 464 146 504 minecraft:blackstone
fill 424 145 464 424 145 465 minecraft:blackstone
setblock 424 145 466 minecraft:polished_blackstone_bricks
fill 424 145 467 424 148 467 minecraft:blackstone
setblock 424 145 471 minecraft:polished_blackstone_bricks
fill 424 145 472 424 148 472 minecraft:blackstone
setblock 424 145 476 minecraft:polished_blackstone_bricks
fill 424 145 477 424 146 479 minecraft:blackstone
setblock 424 145 491 minecraft:polished_blackstone_bricks
fill 424 145 492 424 148 492 minecraft:blackstone
setblock 424 145 496 minecraft:polished_blackstone_bricks
fill 424 145 497 424 148 497 minecraft:blackstone
setblock 424 145 500 minecraft:blackstone
setblock 424 145 501 minecraft:polished_blackstone_bricks
fill 424 145 502 424 146 504 minecraft:blackstone
fill 425 145 471 425 148 471 minecraft:blackstone
setblock 425 145 474 minecraft:blackstone
setblock 425 145 475 minecraft:polished_blackstone_bricks
fill 425 145 476 425 148 476 minecraft:blackstone
setblock 425 145 490 minecraft:polished_blackstone_bricks
fill 425 145 491 426 147 491 minecraft:blackstone
setblock 425 145 494 minecraft:blackstone
setblock 425 145 495 minecraft:polished_blackstone_bricks
fill 425 145 496 425 148 496 minecraft:blackstone
setblock 425 145 500 minecraft:polished_blackstone_bricks
fill 425 145 501 425 148 501 minecraft:blackstone
fill 425 145 503 425 145 504 minecraft:blackstone
setblock 426 145 464 minecraft:polished_blackstone_bricks
setblock 426 145 494 minecraft:polished_blackstone_bricks
fill 426 145 495 426 148 495 minecraft:blackstone
setblock 426 145 499 minecraft:polished_blackstone_bricks
fill 426 145 500 427 147 500 minecraft:blackstone
fill 426 145 502 426 145 503 minecraft:blackstone
setblock 426 145 504 minecraft:polished_blackstone_bricks
fill 427 145 464 427 148 464 minecraft:blackstone
setblock 427 145 493 minecraft:polished_blackstone_bricks
fill 427 145 494 427 148 494 minecraft:blackstone
setblock 427 145 497 minecraft:blackstone
setblock 427 145 498 minecraft:polished_blackstone_bricks
fill 427 145 499 427 148 499 minecraft:blackstone
setblock 427 145 502 minecraft:blackstone
setblock 427 145 503 minecraft:polished_blackstone_bricks
fill 427 145 504 427 148 504 minecraft:blackstone
setblock 428 145 502 minecraft:polished_blackstone_bricks
fill 428 145 503 428 148 503 minecraft:blackstone
fill 429 145 502 430 147 502 minecraft:blackstone
setblock 431 145 504 minecraft:polished_blackstone_bricks
fill 432 145 504 433 147 504 minecraft:blackstone
fill 447 145 464 447 148 464 minecraft:blackstone
setblock 451 145 464 minecraft:polished_blackstone_bricks
fill 452 145 464 453 147 464 minecraft:blackstone
fill 462 145 464 462 148 464 minecraft:blackstone
fill 463 145 468 463 148 468 minecraft:blackstone
setblock 463 145 472 minecraft:polished_blackstone_bricks
fill 463 145 473 463 148 473 minecraft:blackstone
setblock 463 145 476 minecraft:blackstone
setblock 463 145 496 minecraft:blackstone
setblock 463 145 497 minecraft:polished_blackstone_bricks
fill 463 145 498 463 147 499 minecraft:blackstone
fill 463 145 504 463 147 504 minecraft:blackstone
setblock 464 145 466 minecraft:polished_blackstone_bricks
fill 464 145 467 464 148 467 minecraft:blackstone
setblock 464 145 471 minecraft:polished_blackstone_bricks
fill 464 145 472 464 148 472 minecraft:blackstone
setblock 464 145 475 minecraft:blackstone
setblock 464 145 476 minecraft:polished_blackstone_bricks
fill 464 145 477 464 148 477 minecraft:blackstone
fill 464 145 479 464 146 479 minecraft:blackstone
setblock 464 145 491 minecraft:polished_blackstone_bricks
fill 464 145 492 464 148 492 minecraft:blackstone
setblock 464 145 496 minecraft:polished_blackstone_bricks
fill 464 145 497 464 148 497 minecraft:blackstone
setblock 464 145 500 minecraft:blackstone
setblock 464 145 501 minecraft:polished_blackstone_bricks
fill 464 145 502 464 148 502 minecraft:blackstone
setblock 424 146 464 minecraft:blackstone
setblock 424 146 465 minecraft:polished_blackstone_bricks
fill 424 146 466 424 149 466 minecraft:blackstone
setblock 424 146 470 minecraft:polished_blackstone_bricks
fill 424 146 471 424 149 471 minecraft:blackstone
setblock 424 146 474 minecraft:blackstone
setblock 424 146 475 minecraft:polished_blackstone_bricks
fill 424 146 476 424 149 476 minecraft:blackstone
setblock 424 146 480 minecraft:polished_blackstone_bricks
fill 424 146 481 424 149 481 minecraft:blackstone
fill 424 146 488 424 147 488 minecraft:blackstone
setblock 424 146 490 minecraft:polished_blackstone_bricks
fill 424 146 491 424 149 491 minecraft:blackstone
setblock 424 146 495 minecraft:polished_blackstone_bricks
fill 424 146 496 424 149 496 minecraft:blackstone
setblock 424 146 500 minecraft:polished_blackstone_bricks
fill 424 146 501 424 149 501 minecraft:blackstone
setblock 425 146 464 minecraft:polished_blackstone_bricks
setblock 425 146 474 minecraft:polished_blackstone_bricks
fill 425 146 475 425 149 475 minecraft:blackstone
fill 425 146 477 425 146 478 minecraft:blackstone
setblock 425 146 479 minecraft:polished_blackstone_bricks
setblock 425 146 489 minecraft:polished_blackstone_bricks
fill 425 146 490 425 149 490 minecraft:blackstone
setblock 425 146 494 minecraft:polished_blackstone_bricks
fill 425 146 495 425 149 495 minecraft:blackstone
setblock 425 146 498 minecraft:blackstone
setblock 425 146 499 minecraft:polished_blackstone_bricks
fill 425 146 500 425 149 500 minecraft:blackstone
setblock 425 146 503 minecraft:blackstone
setblock 425 146 504 minecraft:polished_blackstone_bricks
fill 426 146 464 426 149 464 minecraft:blackstone
setblock 426 146 493 minecraft:polished_blackstone_bricks
fill 426 146 494 426 149 494 minecraft:blackstone
setblock 426 146 498 minecraft:polished_blackstone_bricks
fill 426 146 499 426 149 499 minecraft:blackstone
setblock 426 146 502 minecraft:blackstone
setblock 426 146 503 minecraft:polished_blackstone_bricks
fill 426 146 504 426 149 504 minecraft:blackstone
fill 427 146 493 427 149 493 minecraft:blackstone
setblock 427 146 497 minecraft:polished_blackstone_bricks
fill 427 146 498 428 148 498 minecraft:blackstone
setblock 427 146 501 minecraft:blackstone
setblock 427 146 502 minecraft:polished_blackstone_bricks
fill 427 146 503 427 149 503 minecraft:blackstone
setblock 428 146 496 minecraft:polished_blackstone_bricks
fill 428 146 497 428 149 497 minecraft:blackstone
setblock 428 146 501 minecraft:polished_blackstone_bricks
fill 428 146 502 428 149 502 minecraft:blackstone
fill 429 146 501 429 149 501 minecraft:blackstone
setblock 430 146 504 minecraft:polished_blackstone_bricks
setblock 431 146 503 minecraft:polished_blackstone_bricks
fill 431 146 504 431 149 504 minecraft:blackstone
fill 432 146 503 432 149 503 minecraft:blackstone
fill 433 146 500 434 147 500 minecraft:cyan_stained_glass
fill 446 146 464 446 149 464 minecraft:blackstone
fill 446 146 504 449 146 504 minecraft:blackstone
setblock 450 146 464 minecraft:polished_blackstone_bricks
setblock 450 146 504 minecraft:polished_blackstone_bricks
fill 451 146 464 451 149 464 minecraft:blackstone
fill 457 146 489 461 147 493 minecraft:blackstone
fill 461 146 464 461 149 464 minecraft:blackstone
fill 461 146 504 462 148 504 minecraft:blackstone
fill 462 146 491 464 146 491 minecraft:blackstone
setblock 463 146 471 minecraft:polished_blackstone_bricks
fill 463 146 472 463 149 472 minecraft:blackstone
setblock 463 146 476 minecraft:polished_blackstone_bricks
fill 463 146 477 463 148 478 minecraft:blackstone
fill 463 146 494 463 146 495 minecraft:blackstone
setblock 463 146 496 minecraft:polished_blackstone_bricks
fill 463 146 497 463 149 497 minecraft:blackstone
setblock 463 146 500 minecraft:blackstone
setblock 463 146 501 minecraft:polished_blackstone_bricks
fill 463 146 502 463 148 503 minecraft:blackstone
setblock 464 146 465 minecraft:polished_blackstone_bricks
fill 464 146 466 464 149 466 minecraft:blackstone
setblock 464 146 470 minecraft:polished_blackstone_bricks
fill 464 146 471 464 149 471 minecraft:blackstone
setblock 464 146 475 minecraft:polished_blackstone_bricks
fill 464 146 476 464 149 476 minecraft:blackstone
setblock 464 146 480 minecraft:polished_blackstone_bricks
fill 464 146 481 464 149 481 minecraft:blackstone
setblock 464 146 495 minecraft:polished_blackstone_bricks
fill 464 146 496 464 149 496 minecraft:blackstone
setblock 464 146 500 minecraft:polished_blackstone_bricks
fill 464 146 501 464 149 501 minecraft:blackstone
setblock 424 147 464 minecraft:polished_blackstone_bricks
fill 424 147 465 424 150 465 minecraft:blackstone
setblock 424 147 469 minecraft:polished_blackstone_bricks
fill 424 147 470 424 150 470 minecraft:blackstone
setblock 424 147 473 minecraft:blackstone
setblock 424 147 474 minecraft:polished_blackstone_bricks
fill 424 147 475 424 150 475 minecraft:blackstone
fill 424 147 477 424 147 478 minecraft:blackstone
setblock 424 147 479 minecraft:polished_blackstone_bricks
fill 424 147 480 425 149 480 minecraft:blackstone
fill 424 147 482 424 147 483 minecraft:blackstone
setblock 424 147 484 minecraft:polished_blackstone_bricks
fill 424 147 485 424 148 487 minecraft:blackstone
setblock 424 147 489 minecraft:polished_blackstone_bricks
fill 424 147 490 424 150 490 minecraft:blackstone
setblock 424 147 494 minecraft:polished_blackstone_bricks
fill 424 147 495 424 150 495 minecraft:blackstone
setblock 424 147 499 minecraft:polished_blackstone_bricks
fill 424 147 500 424 150 500 minecraft:blackstone
fill 424 147 502 424 147 503 minecraft:blackstone
setblock 424 147 504 minecraft:polished_blackstone_bricks
fill 425 147 464 425 150 464 minecraft:blackstone
setblock 425 147 473 minecraft:polished_blackstone_bricks
fill 425 147 474 425 150 474 minecraft:blackstone
setblock 425 147 477 minecraft:blackstone
setblock 425 147 478 minecraft:polished_blackstone_bricks
fill 425 147 479 425 150 479 minecraft:blackstone
fill 425 147 481 425 148 481 minecraft:blackstone
fill 425 147 489 425 150 489 minecraft:blackstone
setblock 425 147 492 minecraft:blackstone
setblock 425 147 493 minecraft:polished_blackstone_bricks
fill 425 147 494 425 150 494 minecraft:blackstone
setblock 425 147 498 minecraft:polished_blackstone_bricks
fill 425 147 499 425 150 499 minecraft:blackstone
setblock 425 147 503 minecraft:polished_blackstone_bricks
fill 425 147 504 425 150 504 minecraft:blackstone
fill 426 147 475 426 147 476 minecraft:blackstone
setblock 426 147 477 minecraft:polished_blackstone_bricks
setblock 426 147 492 minecraft:polished_blackstone_bricks
fill 426 147 493 426 150 493 minecraft:blackstone
setblock 426 147 496 minecraft:blackstone
setblock 426 147 497 minecraft:polished_blackstone_bricks
fill 426 147 498 426 150 498 minecraft:blackstone
setblock 426 147 502 minecraft:polished_blackstone_bricks
fill 426 147 503 426 150 503 minecraft:blackstone
setblock 427 147 496 minecraft:polished_blackstone_bricks
fill 427 147 497 427 150 497 minecraft:blackstone
setblock 427 147 501 minecraft:polished_blackstone_bricks
fill 427 147 502 427 150 502 minecraft:blackstone
fill 428 147 496 428 148 496 minecraft:blackstone
setblock 428 147 499 minecraft:blackstone
fill 428 147 501 428 150 501 minecraft:blackstone
setblock 429 147 464 minecraft:polished_blackstone_bricks
setblock 429 147 504 minecraft:polished_blackstone_bricks
setblock 430 147 503 minecraft:polished_blackstone_bricks
fill 430 147 504 430 150 504 minecraft:blackstone
setblock 431 147 502 minecraft:polished_blackstone_bricks
fill 431 147 503 431 150 503 minecraft:blackstone
setblock 444 147 504 minecraft:polished_blackstone_bricks
fill 445 147 464 445 150 464 minecraft:blackstone
fill 445 147 504 448 147 504 minecraft:blackstone
setblock 448 147 465 minecraft:polished_blackstone_bricks
setblock 449 147 464 minecraft:polished_blackstone_bricks
fill 449 147 465 449 150 465 minecraft:blackstone
setblock 449 147 504 minecraft:polished_blackstone_bricks
fill 450 147 464 450 150 464 minecraft:blackstone
fill 450 147 504 452 148 504 minecraft:blackstone
setblock 454 147 464 minecraft:polished_blackstone_bricks
setblock 459 147 464 minecraft:polished_blackstone_bricks
fill 460 147 464 460 150 464 minecraft:blackstone
fill 460 147 504 460 150 504 minecraft:blackstone
fill 462 147 503 462 149 503 minecraft:blackstone
setblock 463 147 465 minecraft:polished_blackstone_bricks
fill 463 147 466 463 149 467 minecraft:blackstone
setblock 463 147 470 minecraft:polished_blackstone_bricks
fill 463 147 471 463 150 471 minecraft:blackstone
setblock 463 147 474 minecraft:blackstone
setblock 463 147 475 minecraft:polished_blackstone_bricks
fill 463 147 476 463 150 476 minecraft:blackstone
setblock 463 147 479 minecraft:blackstone
setblock 463 147 494 minecraft:blackstone
setblock 463 147 495 minecraft:polished_blackstone_bricks
fill 463 147 496 463 150 496 minecraft:blackstone
setblock 463 147 500 minecraft:polished_blackstone_bricks
fill 463 147 501 463 150 501 minecraft:blackstone
setblock 464 147 464 minecraft:polished_blackstone_bricks
fill 464 147 465 464 150 465 minecraft:blackstone
setblock 464 147 469 minecraft:polished_blackstone_bricks
fill 464 147 470 464 150 470 minecraft:blackstone
setblock 464 147 474 minecraft:polished_blackstone_bricks
fill 464 147 475 464 150 475 minecraft:blackstone
setblock 464 147 479 minecraft:polished_blackstone_bricks
fill 464 147 480 464 150 480 minecraft:blackstone
fill 464 147 482 464 148 482 minecraft:blackstone
fill 464 147 490 464 149 491 minecraft:blackstone
setblock 464 147 494 minecraft:polished_blackstone_bricks
fill 464 147 495 464 150 495 minecraft:blackstone
setblock 464 147 499 minecraft:polished_blackstone_bricks
fill 464 147 500 464 150 500 minecraft:blackstone
setblock 464 147 503 minecraft:blackstone
setblock 464 147 504 minecraft:polished_blackstone_bricks
fill 424 148 464 424 151 464 minecraft:blackstone
setblock 424 148 468 minecraft:polished_blackstone_bricks
fill 424 148 469 424 151 469 minecraft:blackstone
setblock 424 148 473 minecraft:polished_blackstone_bricks
fill 424 148 474 424 151 474 minecraft:blackstone
setblock 424 148 477 minecraft:blackstone
setblock 424 148 478 minecraft:polished_blackstone_bricks
fill 424 148 479 424 151 479 minecraft:blackstone
setblock 424 148 482 minecraft:blackstone
setblock 424 148 483 minecraft:polished_blackstone_bricks
fill 424 148 484 425 150 484 minecraft:blackstone
setblock 424 148 488 minecraft:polished_blackstone_bricks
fill 424 148 489 424 151 489 minecraft:blackstone
setblock 424 148 493 minecraft:polished_blackstone_bricks
fill 424 148 494 424 151 494 minecraft:blackstone
setblock 424 148 498 minecraft:polished_blackstone_bricks
fill 424 148 499 424 151 499 minecraft:blackstone
setblock 424 148 502 minecraft:blackstone
setblock 424 148 503 minecraft:polished_blackstone_bricks
fill 424 148 504 424 151 504 minecraft:blackstone
setblock 425 148 472 minecraft:polished_blackstone_bricks
fill 425 148 473 425 150 473 minecraft:blackstone
setblock 425 148 477 minecraft:polished_blackstone_bricks
fill 425 148 478 426 150 478 minecraft:blackstone
setblock 425 148 482 minecraft:polished_blackstone_bricks
fill 425 148 483 425 151 483 minecraft:blackstone
setblock 425 148 487 minecraft:polished_blackstone_bricks
fill 425 148 488 425 151 488 minecraft:blackstone
setblock 425 148 491 minecraft:blackstone
setblock 425 148 492 minecraft:polished_blackstone_bricks
fill 425 148 493 425 151 493 minecraft:blackstone
setblock 425 148 497 minecraft:polished_blackstone_bricks
fill 425 148 498 425 151 498 minecraft:blackstone
setblock 425 148 502 minecraft:polished_blackstone_bricks
fill 425 148 503 425 151 503 minecraft:blackstone
setblock 426 148 475 minecraft:blackstone
setblock 426 148 476 minecraft:polished_blackstone_bricks
fill 426 148 477 426 151 477 minecraft:blackstone
fill 426 148 479 426 148 480 minecraft:blackstone
setblock 426 148 490 minecraft:blackstone
setblock 426 148 491 minecraft:polished_blackstone_bricks
fill 426 148 492 426 151 492 minecraft:blackstone
setblock 426 148 496 minecraft:polished_blackstone_bricks
fill 426 148 497 426 151 497 minecraft:blackstone
setblock 426 148 500 minecraft:blackstone
setblock 426 148 501 minecraft:polished_blackstone_bricks
fill 426 148 502 426 151 502 minecraft:blackstone
setblock 427 148 495 minecraft:polished_blackstone_bricks
fill 427 148 496 427 151 496 minecraft:blackstone
setblock 427 148 500 minecraft:polished_blackstone_bricks
fill 427 148 501 427 151 501 minecraft:blackstone
setblock 428 148 464 minecraft:polished_blackstone_bricks
setblock 428 148 499 minecraft:polished_blackstone_bricks
setblock 428 148 504 minecraft:polished_blackstone_bricks
fill 429 148 464 429 149 464 minecraft:blackstone
setblock 429 148 502 minecraft:blackstone
setblock 429 148 503 minecraft:polished_blackstone_bricks
fill 429 148 504 429 151 504 minecraft:blackstone
setblock 430 148 501 minecraft:blackstone
setblock 430 148 502 minecraft:polished_blackstone_bricks
fill 430 148 503 430 151 503 minecraft:blackstone
fill 431 148 502 431 149 502 minecraft:blackstone
setblock 432 148 504 minecraft:blackstone
setblock 433 148 504 minecraft:polished_blackstone_bricks
setblock 442 148 504 minecraft:blackstone
setblock 443 148 504 minecraft:polished_blackstone_bricks
fill 444 148 464 444 151 464 minecraft:blackstone
fill 444 148 504 447 148 504 minecraft:blackstone
fill 445 148 503 448 148 503 minecraft:blackstone
setblock 447 148 465 minecraft:polished_blackstone_bricks
setblock 448 148 464 minecraft:polished_blackstone_bricks
fill 448 148 465 448 151 465 minecraft:blackstone
setblock 448 148 504 minecraft:polished_blackstone_bricks
fill 449 148 464 449 151 464 minecraft:blackstone
setblock 449 148 503 minecraft:polished_blackstone_bricks
fill 449 148 504 449 151 504 minecraft:blackstone
fill 450 148 465 450 149 465 minecraft:blackstone
setblock 452 148 464 minecraft:blackstone
setblock 453 148 464 minecraft:polished_blackstone_bricks
setblock 453 148 504 minecraft:polished_blackstone_bricks
fill 454 148 464 457 148 464 minecraft:blackstone
setblock 458 148 464 minecraft:polished_blackstone_bricks
fill 458 148 491 460 152 491 minecraft:polished_blackstone_bricks
setblock 458 148 504 minecraft:polished_blackstone_bricks
fill 459 148 464 459 151 464 minecraft:blackstone
fill 459 148 504 459 151 504 minecraft:blackstone
fill 460 148 503 461 150 503 minecraft:blackstone
setblock 462 148 465 minecraft:polished_blackstone_bricks
setblock 462 148 474 minecraft:blackstone
setblock 462 148 475 minecraft:polished_blackstone_bricks
fill 462 148 497 462 148 499 minecraft:blackstone
setblock 462 148 500 minecraft:polished_blackstone_bricks
fill 462 148 501 462 150 502 minecraft:blackstone
setblock 463 148 464 minecraft:polished_blackstone_bricks
fill 463 148 465 463 151 465 minecraft:blackstone
setblock 463 148 469 minecraft:polished_blackstone_bricks
fill 463 148 470 463 150 470 minecraft:blackstone
setblock 463 148 474 minecraft:polished_blackstone_bricks
fill 463 148 475 463 151 475 minecraft:blackstone
setblock 463 148 479 minecraft:polished_blackstone_bricks
fill 463 148 480 463 151 480 minecraft:blackstone
setblock 463 148 493 minecraft:blackstone
setblock 463 148 494 minecraft:polished_blackstone_bricks
fill 463 148 495 463 151 495 minecraft:blackstone
setblock 463 148 498 minecraft:blackstone
setblock 463 148 499 minecraft:polished_blackstone_bricks
fill 463 148 500 463 151 500 minecraft:blackstone
setblock 463 148 504 minecraft:polished_blackstone_bricks
fill 464 148 464 464 151 464 minecraft:blackstone
setblock 464 148 468 minecraft:polished_blackstone_bricks
fill 464 148 469 464 151 469 minecraft:blackstone
setblock 464 148 473 minecraft:polished_blackstone_bricks
fill 464 148 474 464 151 474 minecraft:blackstone
setblock 464 148 478 minecraft:polished_blackstone_bricks
fill 464 148 479 464 151 479 minecraft:blackstone
setblock 464 148 483 minecraft:polished_blackstone_bricks
fill 464 148 484 464 151 484 minecraft:blackstone
setblock 464 148 493 minecraft:polished_blackstone_bricks
fill 464 148 494 464 151 494 minecraft:blackstone
setblock 464 148 498 minecraft:polished_blackstone_bricks
fill 464 148 499 464 151 499 minecraft:blackstone
setblock 464 148 503 minecraft:polished_blackstone_bricks
fill 464 148 504 464 151 504 minecraft:blackstone
setblock 424 149 467 minecraft:polished_blackstone_bricks
fill 424 149 468 424 151 468 minecraft:blackstone
setblock 424 149 472 minecraft:polished_blackstone_bricks
fill 424 149 473 424 152 473 minecraft:blackstone
setblock 424 149 477 minecraft:polished_blackstone_bricks
fill 424 149 478 424 152 478 minecraft:blackstone
setblock 424 149 482 minecraft:polished_blackstone_bricks
fill 424 149 483 424 152 483 minecraft:blackstone
fill 424 149 485 424 149 486 minecraft:blackstone
setblock 424 149 487 minecraft:polished_blackstone_bricks
fill 424 149 488 424 152 488 minecraft:blackstone
setblock 424 149 492 minecraft:polished_blackstone_bricks
fill 424 149 493 424 152 493 minecraft:blackstone
setblock 424 149 497 minecraft:polished_blackstone_bricks
fill 424 149 498 424 152 498 minecraft:blackstone
setblock 424 149 502 minecraft:polished_blackstone_bricks
fill 424 149 503 424 152 503 minecraft:blackstone
setblock 425 149 472 minecraft:blackstone
setblock 425 149 476 minecraft:polished_blackstone_bricks
fill 425 149 477 425 152 477 minecraft:blackstone
setblock 425 149 481 minecraft:polished_blackstone_bricks
fill 425 149 482 425 152 482 minecraft:blackstone
setblock 425 149 485 minecraft:blackstone
setblock 425 149 486 minecraft:polished_blackstone_bricks
fill 425 149 487 425 152 487 minecraft:blackstone
setblock 425 149 491 minecraft:polished_blackstone_bricks
fill 425 149 492 425 152 492 minecraft:blackstone
setblock 425 149 496 minecraft:polished_blackstone_bricks
fill 425 149 497 425 152 497 minecraft:blackstone
setblock 425 149 501 minecraft:polished_blackstone_bricks
fill 425 149 502 425 152 502 minecraft:blackstone
setblock 426 149 475 minecraft:polished_blackstone_bricks
fill 426 149 476 426 150 476 minecraft:blackstone
setblock 426 149 479 minecraft:blackstone
setblock 426 149 480 minecraft:polished_blackstone_bricks
fill 426 149 481 426 152 481 minecraft:blackstone
fill 426 149 491 426 150 491 minecraft:blackstone
setblock 426 149 495 minecraft:polished_blackstone_bricks
fill 426 149 496 426 152 496 minecraft:blackstone
setblock 426 149 500 minecraft:polished_blackstone_bricks
fill 426 149 501 426 152 501 minecraft:blackstone
setblock 427 149 464 minecraft:polished_blackstone_bricks
setblock 427 149 494 minecraft:polished_blackstone_bricks
fill 427 149 495 427 150 495 minecraft:blackstone
setblock 427 149 498 minecraft:blackstone
setblock 427 149 499 minecraft:polished_blackstone_bricks
fill 427 149 500 427 152 500 minecraft:blackstone
setblock 427 149 504 minecraft:polished_blackstone_bricks
fill 428 149 464 428 151 464 minecraft:blackstone
setblock 428 149 498 minecraft:polished_blackstone_bricks
setblock 428 149 499 minecraft:blackstone
setblock 428 149 503 minecraft:polished_blackstone_bricks
fill 428 149 504 428 152 504 minecraft:blackstone
setblock 429 149 502 minecraft:polished_blackstone_bricks
fill 429 149 503 429 152 503 minecraft:blackstone
fill 430 149 502 430 151 502 minecraft:blackstone
setblock 432 149 504 minecraft:polished_blackstone_bricks
fill 433 149 504 433 151 504 minecraft:blackstone
setblock 441 149 504 minecraft:blackstone
setblock 442 149 504 minecraft:polished_blackstone_bricks
fill 443 149 464 443 152 464 minecraft:blackstone
setblock 443 149 503 minecraft:polished_blackstone_bricks
fill 443 149 504 446 149 504 minecraft:blackstone
fill 444 149 503 447 149 503 minecraft:blackstone
setblock 446 149 465 minecraft:polished_blackstone_bricks
setblock 447 149 464 minecraft:polished_blackstone_bricks
fill 447 149 465 447 152 465 minecraft:blackstone
setblock 447 149 504 minecraft:polished_blackstone_bricks
fill 448 149 464 448 152 464 minecraft:blackstone
setblock 448 149 503 minecraft:polished_blackstone_bricks
fill 448 149 504 448 152 504 minecraft:blackstone
fill 449 149 503 450 151 503 minecraft:blackstone
fill 450 149 504 451 149 504 minecraft:blackstone
setblock 452 149 464 minecraft:polished_blackstone_bricks
setblock 452 149 504 minecraft:polished_blackstone_bricks
fill 453 149 464 456 149 464 minecraft:blackstone
fill 453 149 504 456 149 504 minecraft:blackstone
setblock 457 149 464 minecraft:polished_blackstone_bricks
setblock 457 149 504 minecraft:polished_blackstone_bricks
fill 458 149 464 458 152 464 minecraft:blackstone
fill 458 149 504 458 152 504 minecraft:blackstone
fill 459 149 503 459 152 503 minecraft:blackstone
setblock 461 149 465 minecraft:polished_blackstone_bricks
fill 461 149 502 461 151 502 minecraft:blackstone
setblock 461 149 504 minecraft:blackstone
setblock 462 149 464 minecraft:polished_blackstone_bricks
fill 462 149 465 462 152 465 minecraft:blackstone
fill 462 149 475 462 149 476 minecraft:blackstone
fill 462 149 497 462 149 498 minecraft:blackstone
setblock 462 149 499 minecraft:polished_blackstone_bricks
fill 462 149 500 462 152 500 minecraft:blackstone
setblock 462 149 504 minecraft:polished_blackstone_bricks
fill 463 149 464 463 152 464 minecraft:blackstone
setblock 463 149 468 minecraft:polished_blackstone_bricks
fill 463 149 469 463 150 469 minecraft:blackstone
setblock 463 149 473 minecraft:polished_blackstone_bricks
fill 463 149 474 463 152 474 minecraft:blackstone
setblock 463 149 477 minecraft:blackstone
setblock 463 149 478 minecraft:polished_blackstone_bricks
fill 463 149 479 463 152 479 minecraft:blackstone
fill 463 149 481 463 150 481 minecraft:blackstone
setblock 463 149 493 minecraft:polished_blackstone_bricks
fill 463 149 494 463 152 494 minecraft:blackstone
setblock 463 149 498 minecraft:polished_blackstone_bricks
fill 463 149 499 463 152 499 minecraft:blackstone
setblock 463 149 502 minecraft:blackstone
setblock 463 149 503 minecraft:polished_blackstone_bricks
fill 463 149 504 463 152 504 minecraft:blackstone
setblock 464 149 467 minecraft:polished_blackstone_bricks
fill 464 149 468 464 152 468 minecraft:blackstone
setblock 464 149 472 minecraft:polished_blackstone_bricks
fill 464 149 473 464 152 473 minecraft:blackstone
setblock 464 149 477 minecraft:polished_blackstone_bricks
fill 464 149 478 464 152 478 minecraft:blackstone
setblock 464 149 482 minecraft:polished_blackstone_bricks
fill 464 149 483 464 152 483 minecraft:blackstone
fill 464 149 485 464 150 485 minecraft:blackstone
fill 464 149 489 464 151 489 minecraft:blackstone
setblock 464 149 492 minecraft:polished_blackstone_bricks
fill 464 149 493 464 152 493 minecraft:blackstone
setblock 464 149 497 minecraft:polished_blackstone_bricks
fill 464 149 498 464 152 498 minecraft:blackstone
setblock 464 149 502 minecraft:polished_blackstone_bricks
fill 464 149 503 464 152 503 minecraft:blackstone
setblock 424 150 466 minecraft:polished_blackstone_bricks
fill 424 150 467 424 152 467 minecraft:blackstone
setblock 424 150 471 minecraft:polished_blackstone_bricks
fill 424 150 472 424 152 472 minecraft:blackstone
setblock 424 150 476 minecraft:polished_blackstone_bricks
fill 424 150 477 424 153 477 minecraft:blackstone
setblock 424 150 480 minecraft:blackstone
setblock 424 150 481 minecraft:polished_blackstone_bricks
fill 424 150 482 424 153 482 minecraft:blackstone
setblock 424 150 485 minecraft:blackstone
setblock 424 150 486 minecraft:polished_blackstone_bricks
fill 424 150 487 424 153 487 minecraft:blackstone
setblock 424 150 491 minecraft:polished_blackstone_bricks
fill 424 150 492 424 153 492 minecraft:blackstone
setblock 424 150 496 minecraft:polished_blackstone_bricks
fill 424 150 497 424 153 497 minecraft:blackstone
setblock 424 150 501 minecraft:polished_blackstone_bricks
fill 424 150 502 424 153 502 minecraft:blackstone
setblock 425 150 475 minecraft:polished_blackstone_bricks
fill 425 150 476 425 152 476 minecraft:blackstone
setblock 425 150 480 minecraft:polished_blackstone_bricks
fill 425 150 481 425 153 481 minecraft:blackstone
setblock 425 150 485 minecraft:polished_blackstone_bricks
fill 425 150 486 425 153 486 minecraft:blackstone
setblock 425 150 490 minecraft:polished_blackstone_bricks
fill 425 150 491 425 153 491 minecraft:blackstone
setblock 425 150 495 minecraft:polished_blackstone_bricks
fill 425 150 496 425 153 496 minecraft:blackstone
setblock 425 150 500 minecraft:polished_blackstone_bricks
fill 425 150 501 425 153 501 minecraft:blackstone
setblock 426 150 464 minecraft:polished_blackstone_bricks
setblock 426 150 479 minecraft:polished_blackstone_bricks
fill 426 150 480 426 153 480 minecraft:blackstone
fill 426 150 482 426 150 483 minecraft:blackstone
setblock 426 150 494 minecraft:polished_blackstone_bricks
fill 426 150 495 426 152 495 minecraft:blackstone
setblock 426 150 499 minecraft:polished_blackstone_bricks
fill 426 150 500 426 153 500 minecraft:blackstone
setblock 426 150 504 minecraft:polished_blackstone_bricks
fill 427 150 464 427 153 464 minecraft:blackstone
setblock 427 150 494 minecraft:blackstone
setblock 427 150 498 minecraft:polished_blackstone_bricks
fill 427 150 499 427 152 499 minecraft:blackstone
setblock 427 150 503 minecraft:polished_blackstone_bricks
fill 427 150 504 427 153 504 minecraft:blackstone
setblock 428 150 502 minecraft:polished_blackstone_bricks
fill 428 150 503 428 153 503 minecraft:blackstone
setblock 429 150 501 minecraft:polished_blackstone_bricks
fill 429 150 502 429 152 502 minecraft:blackstone
setblock 431 150 504 minecraft:polished_blackstone_bricks
setblock 432 150 503 minecraft:polished_blackstone_bricks
fill 432 150 504 432 152 504 minecraft:blackstone
setblock 440 150 504 minecraft:blackstone
setblock 441 150 504 minecraft:polished_blackstone_bricks
fill 442 150 464 442 153 464 minecraft:blackstone
setblock 442 150 503 minecraft:polished_blackstone_bricks
fill 442 150 504 445 150 504 minecraft:blackstone
fill 443 150 503 446 150 503 minecraft:blackstone
setblock 445 150 465 minecraft:polished_blackstone_bricks
setblock 446 150 464 minecraft:polished_blackstone_bricks
fill 446 150 465 446 153 465 minecraft:blackstone
setblock 446 150 504 minecraft:polished_blackstone_bricks
fill 447 150 464 447 153 464 minecraft:blackstone
setblock 447 150 503 minecraft:polished_blackstone_bricks
fill 447 150 504 447 153 504 minecraft:blackstone
fill 448 150 503 448 153 503 minecraft:blackstone
setblock 450 150 504 minecraft:blackstone
setblock 451 150 464 minecraft:polished_blackstone_bricks
setblock 451 150 504 minecraft:polished_blackstone_bricks
fill 452 150 464 455 150 464 minecraft:blackstone
fill 452 150 504 455 150 504 minecraft:blackstone
setblock 456 150 464 minecraft:polished_blackstone_bricks
setblock 456 150 504 minecraft:polished_blackstone_bricks
fill 457 150 464 457 153 464 minecraft:blackstone
fill 457 150 504 457 153 504 minecraft:blackstone
fill 458 150 503 458 153 503 minecraft:blackstone
fill 460 150 502 460 152 502 minecraft:blackstone
setblock 461 150 464 minecraft:polished_blackstone_bricks
fill 461 150 465 461 153 465 minecraft:blackstone
setblock 461 150 504 minecraft:polished_blackstone_bricks
fill 462 150 464 462 153 464 minecraft:blackstone
setblock 462 150 497 minecraft:blackstone
setblock 462 150 498 minecraft:polished_blackstone_bricks
fill 462 150 499 462 153 499 minecraft:blackstone
setblock 462 150 503 minecraft:polished_blackstone_bricks
fill 462 150 504 462 153 504 minecraft:blackstone
setblock 463 150 466 minecraft:blackstone
setblock 463 150 467 minecraft:polished_blackstone_bricks
fill 463 150 468 463 151 468 minecraft:blackstone
setblock 463 150 472 minecraft:polished_blackstone_bricks
fill 463 150 473 463 151 473 minecraft:blackstone
setblock 463 150 477 minecraft:polished_blackstone_bricks
fill 463 150 478 463 153 478 minecraft:blackstone
schedule function dropper:buildpart/117_4 1t
