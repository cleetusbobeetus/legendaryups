setblock 48 66 579 minecraft:calcite
fill 48 66 580 48 69 580 minecraft:cobbled_deepslate
setblock 48 66 584 minecraft:calcite
fill 48 66 585 48 69 585 minecraft:cobbled_deepslate
setblock 48 66 589 minecraft:calcite
fill 48 66 590 48 69 590 minecraft:cobbled_deepslate
setblock 48 66 594 minecraft:calcite
fill 48 66 595 48 69 595 minecraft:cobbled_deepslate
setblock 49 66 558 minecraft:calcite
setblock 49 66 568 minecraft:calcite
fill 49 66 569 49 67 569 minecraft:cobbled_deepslate
setblock 49 66 573 minecraft:calcite
fill 49 66 574 49 69 574 minecraft:cobbled_deepslate
setblock 49 66 578 minecraft:calcite
fill 49 66 579 49 69 579 minecraft:cobbled_deepslate
setblock 49 66 583 minecraft:calcite
fill 49 66 584 49 69 584 minecraft:cobbled_deepslate
setblock 49 66 588 minecraft:calcite
fill 49 66 589 49 69 589 minecraft:cobbled_deepslate
setblock 49 66 593 minecraft:calcite
fill 49 66 594 49 69 594 minecraft:cobbled_deepslate
setblock 49 66 598 minecraft:calcite
fill 50 66 558 50 69 558 minecraft:cobbled_deepslate
setblock 50 66 572 minecraft:calcite
fill 50 66 573 50 69 573 minecraft:cobbled_deepslate
setblock 50 66 577 minecraft:calcite
fill 50 66 578 50 69 578 minecraft:cobbled_deepslate
setblock 50 66 581 minecraft:cobbled_deepslate
setblock 50 66 582 minecraft:calcite
fill 50 66 583 50 67 583 minecraft:cobbled_deepslate
setblock 50 66 587 minecraft:calcite
fill 50 66 588 50 67 588 minecraft:cobbled_deepslate
setblock 50 66 592 minecraft:calcite
fill 50 66 593 50 69 593 minecraft:cobbled_deepslate
setblock 50 66 597 minecraft:calcite
fill 50 66 598 50 69 598 minecraft:cobbled_deepslate
setblock 51 66 575 minecraft:cobbled_deepslate
setblock 51 66 576 minecraft:calcite
fill 51 66 577 51 67 577 minecraft:cobbled_deepslate
setblock 51 66 591 minecraft:calcite
setblock 51 66 592 minecraft:cobbled_deepslate
setblock 51 66 596 minecraft:calcite
fill 51 66 597 51 69 597 minecraft:cobbled_deepslate
setblock 52 66 595 minecraft:calcite
fill 52 66 596 52 68 596 minecraft:cobbled_deepslate
setblock 54 66 598 minecraft:calcite
setblock 55 66 597 minecraft:calcite
fill 55 66 598 55 69 598 minecraft:cobbled_deepslate
setblock 63 66 598 minecraft:cobbled_deepslate
setblock 64 66 558 minecraft:calcite
setblock 64 66 598 minecraft:calcite
fill 65 66 558 65 69 558 minecraft:cobbled_deepslate
setblock 65 66 597 minecraft:calcite
fill 65 66 598 68 66 598 minecraft:cobbled_deepslate
fill 66 66 559 67 66 559 minecraft:cobbled_deepslate
fill 66 66 597 69 66 597 minecraft:cobbled_deepslate
setblock 68 66 559 minecraft:calcite
fill 68 66 596 70 66 596 minecraft:cobbled_deepslate
setblock 69 66 558 minecraft:calcite
fill 69 66 559 69 69 559 minecraft:cobbled_deepslate
setblock 69 66 598 minecraft:calcite
fill 70 66 558 70 69 558 minecraft:cobbled_deepslate
fill 70 66 560 70 67 560 minecraft:cobbled_deepslate
setblock 70 66 597 minecraft:calcite
fill 70 66 598 70 69 598 minecraft:cobbled_deepslate
setblock 71 66 596 minecraft:calcite
fill 71 66 597 71 69 597 minecraft:cobbled_deepslate
setblock 72 66 560 minecraft:calcite
fill 72 66 596 73 66 596 minecraft:cobbled_deepslate
setblock 73 66 559 minecraft:calcite
setblock 74 66 558 minecraft:calcite
fill 74 66 559 74 69 559 minecraft:cobbled_deepslate
setblock 74 66 598 minecraft:calcite
fill 75 66 558 75 69 558 minecraft:cobbled_deepslate
setblock 75 66 597 minecraft:calcite
fill 75 66 598 78 66 598 minecraft:cobbled_deepslate
fill 76 66 597 79 66 597 minecraft:cobbled_deepslate
setblock 79 66 558 minecraft:calcite
setblock 79 66 598 minecraft:calcite
fill 80 66 558 83 66 558 minecraft:cobbled_deepslate
setblock 80 66 597 minecraft:calcite
fill 80 66 598 80 69 598 minecraft:cobbled_deepslate
fill 81 66 597 81 69 597 minecraft:cobbled_deepslate
setblock 84 66 558 minecraft:calcite
fill 84 66 559 84 69 559 minecraft:cobbled_deepslate
setblock 84 66 598 minecraft:calcite
fill 85 66 558 85 69 558 minecraft:cobbled_deepslate
fill 85 66 595 86 66 595 minecraft:cobbled_deepslate
setblock 85 66 597 minecraft:calcite
fill 85 66 598 85 69 598 minecraft:cobbled_deepslate
setblock 86 66 591 minecraft:calcite
fill 86 66 592 86 69 592 minecraft:cobbled_deepslate
setblock 86 66 596 minecraft:calcite
fill 86 66 597 86 69 597 minecraft:cobbled_deepslate
setblock 87 66 560 minecraft:calcite
setblock 87 66 570 minecraft:calcite
fill 87 66 571 87 68 571 minecraft:cobbled_deepslate
fill 87 66 573 87 66 574 minecraft:cobbled_deepslate
setblock 87 66 575 minecraft:calcite
fill 87 66 576 87 69 576 minecraft:cobbled_deepslate
fill 87 66 578 87 67 578 minecraft:cobbled_deepslate
fill 87 66 587 87 66 589 minecraft:cobbled_deepslate
setblock 87 66 590 minecraft:calcite
fill 87 66 591 87 69 591 minecraft:cobbled_deepslate
setblock 87 66 595 minecraft:calcite
fill 87 66 596 87 69 596 minecraft:cobbled_deepslate
setblock 88 66 559 minecraft:calcite
fill 88 66 560 88 69 560 minecraft:cobbled_deepslate
setblock 88 66 564 minecraft:calcite
fill 88 66 565 88 68 565 minecraft:cobbled_deepslate
setblock 88 66 569 minecraft:calcite
fill 88 66 570 88 69 570 minecraft:cobbled_deepslate
setblock 88 66 574 minecraft:calcite
fill 88 66 575 88 69 575 minecraft:cobbled_deepslate
setblock 88 66 579 minecraft:calcite
fill 88 66 580 88 69 580 minecraft:cobbled_deepslate
setblock 88 66 584 minecraft:calcite
fill 88 66 585 88 69 585 minecraft:cobbled_deepslate
setblock 88 66 589 minecraft:calcite
fill 88 66 590 88 69 590 minecraft:cobbled_deepslate
setblock 88 66 594 minecraft:calcite
fill 88 66 595 88 69 595 minecraft:cobbled_deepslate
setblock 48 67 558 minecraft:calcite
fill 48 67 559 48 70 559 minecraft:cobbled_deepslate
setblock 48 67 568 minecraft:calcite
fill 48 67 569 48 70 569 minecraft:cobbled_deepslate
setblock 48 67 573 minecraft:calcite
fill 48 67 574 48 70 574 minecraft:cobbled_deepslate
setblock 48 67 578 minecraft:calcite
fill 48 67 579 48 70 579 minecraft:cobbled_deepslate
setblock 48 67 583 minecraft:calcite
fill 48 67 584 48 70 584 minecraft:cobbled_deepslate
setblock 48 67 588 minecraft:calcite
fill 48 67 589 48 70 589 minecraft:cobbled_deepslate
setblock 48 67 593 minecraft:calcite
fill 48 67 594 48 70 594 minecraft:cobbled_deepslate
setblock 48 67 598 minecraft:calcite
fill 49 67 558 49 70 558 minecraft:cobbled_deepslate
setblock 49 67 572 minecraft:calcite
fill 49 67 573 49 70 573 minecraft:cobbled_deepslate
setblock 49 67 577 minecraft:calcite
fill 49 67 578 49 70 578 minecraft:cobbled_deepslate
setblock 49 67 582 minecraft:calcite
fill 49 67 583 49 70 583 minecraft:cobbled_deepslate
setblock 49 67 587 minecraft:calcite
fill 49 67 588 49 70 588 minecraft:cobbled_deepslate
setblock 49 67 592 minecraft:calcite
fill 49 67 593 49 70 593 minecraft:cobbled_deepslate
setblock 49 67 597 minecraft:calcite
fill 49 67 598 49 70 598 minecraft:cobbled_deepslate
setblock 50 67 571 minecraft:calcite
fill 50 67 572 50 68 572 minecraft:cobbled_deepslate
setblock 50 67 576 minecraft:calcite
fill 50 67 577 50 70 577 minecraft:cobbled_deepslate
setblock 50 67 581 minecraft:calcite
fill 50 67 582 50 69 582 minecraft:cobbled_deepslate
setblock 50 67 587 minecraft:cobbled_deepslate
setblock 50 67 591 minecraft:calcite
fill 50 67 592 50 68 592 minecraft:cobbled_deepslate
setblock 50 67 596 minecraft:calcite
fill 50 67 597 50 70 597 minecraft:cobbled_deepslate
setblock 51 67 575 minecraft:calcite
setblock 51 67 576 minecraft:cobbled_deepslate
setblock 51 67 595 minecraft:calcite
fill 51 67 596 51 69 596 minecraft:cobbled_deepslate
setblock 53 67 558 minecraft:calcite
setblock 53 67 598 minecraft:calcite
setblock 54 67 597 minecraft:calcite
fill 54 67 598 54 70 598 minecraft:cobbled_deepslate
setblock 55 67 597 minecraft:cobbled_deepslate
setblock 62 67 598 minecraft:cobbled_deepslate
setblock 63 67 558 minecraft:calcite
setblock 63 67 598 minecraft:calcite
fill 64 67 558 64 70 558 minecraft:cobbled_deepslate
fill 64 67 598 67 67 598 minecraft:cobbled_deepslate
fill 65 67 597 68 67 597 minecraft:cobbled_deepslate
setblock 66 67 559 minecraft:cobbled_deepslate
setblock 67 67 559 minecraft:calcite
setblock 68 67 558 minecraft:calcite
fill 68 67 559 68 70 559 minecraft:cobbled_deepslate
fill 68 67 596 69 67 596 minecraft:cobbled_deepslate
setblock 68 67 598 minecraft:calcite
fill 69 67 558 69 70 558 minecraft:cobbled_deepslate
fill 69 67 560 69 68 560 minecraft:cobbled_deepslate
setblock 69 67 597 minecraft:calcite
fill 69 67 598 69 70 598 minecraft:cobbled_deepslate
setblock 70 67 596 minecraft:calcite
fill 70 67 597 70 70 597 minecraft:cobbled_deepslate
setblock 71 67 560 minecraft:calcite
fill 71 67 596 72 67 596 minecraft:cobbled_deepslate
setblock 72 67 559 minecraft:calcite
setblock 73 67 558 minecraft:calcite
fill 73 67 559 73 70 559 minecraft:cobbled_deepslate
setblock 73 67 598 minecraft:calcite
fill 74 67 558 74 70 558 minecraft:cobbled_deepslate
setblock 74 67 597 minecraft:calcite
fill 74 67 598 77 67 598 minecraft:cobbled_deepslate
fill 75 67 597 78 67 597 minecraft:cobbled_deepslate
setblock 78 67 558 minecraft:calcite
setblock 78 67 598 minecraft:calcite
fill 79 67 558 82 67 558 minecraft:cobbled_deepslate
setblock 79 67 597 minecraft:calcite
fill 79 67 598 79 70 598 minecraft:cobbled_deepslate
fill 80 67 597 80 70 597 minecraft:cobbled_deepslate
fill 82 67 596 82 68 596 minecraft:cobbled_deepslate
setblock 83 67 558 minecraft:calcite
fill 83 67 559 83 70 559 minecraft:cobbled_deepslate
setblock 83 67 598 minecraft:calcite
fill 84 67 558 84 70 558 minecraft:cobbled_deepslate
setblock 84 67 596 minecraft:cobbled_deepslate
setblock 84 67 597 minecraft:calcite
fill 84 67 598 84 70 598 minecraft:cobbled_deepslate
setblock 85 67 595 minecraft:cobbled_deepslate
setblock 85 67 596 minecraft:calcite
fill 85 67 597 85 70 597 minecraft:cobbled_deepslate
fill 86 67 591 86 68 591 minecraft:cobbled_deepslate
setblock 86 67 595 minecraft:calcite
fill 86 67 596 86 70 596 minecraft:cobbled_deepslate
setblock 87 67 558 minecraft:cobbled_deepslate
setblock 87 67 559 minecraft:calcite
fill 87 67 560 87 70 560 minecraft:cobbled_deepslate
setblock 87 67 570 minecraft:cobbled_deepslate
setblock 87 67 573 minecraft:cobbled_deepslate
setblock 87 67 574 minecraft:calcite
fill 87 67 575 87 70 575 minecraft:cobbled_deepslate
setblock 87 67 579 minecraft:calcite
fill 87 67 587 87 67 588 minecraft:cobbled_deepslate
setblock 87 67 589 minecraft:calcite
fill 87 67 590 87 70 590 minecraft:cobbled_deepslate
setblock 87 67 594 minecraft:calcite
fill 87 67 595 87 70 595 minecraft:cobbled_deepslate
setblock 88 67 558 minecraft:calcite
fill 88 67 559 88 70 559 minecraft:cobbled_deepslate
setblock 88 67 563 minecraft:calcite
fill 88 67 564 88 68 564 minecraft:cobbled_deepslate
setblock 88 67 568 minecraft:calcite
fill 88 67 569 88 69 569 minecraft:cobbled_deepslate
setblock 88 67 573 minecraft:calcite
fill 88 67 574 88 70 574 minecraft:cobbled_deepslate
setblock 88 67 578 minecraft:calcite
fill 88 67 579 88 70 579 minecraft:cobbled_deepslate
setblock 88 67 582 minecraft:cobbled_deepslate
setblock 88 67 583 minecraft:calcite
fill 88 67 584 88 70 584 minecraft:cobbled_deepslate
setblock 88 67 588 minecraft:calcite
fill 88 67 589 88 70 589 minecraft:cobbled_deepslate
setblock 88 67 593 minecraft:calcite
fill 88 67 594 88 70 594 minecraft:cobbled_deepslate
setblock 88 67 598 minecraft:calcite
fill 48 68 558 48 71 558 minecraft:cobbled_deepslate
setblock 48 68 567 minecraft:calcite
fill 48 68 568 48 69 568 minecraft:cobbled_deepslate
setblock 48 68 572 minecraft:calcite
fill 48 68 573 48 71 573 minecraft:cobbled_deepslate
setblock 48 68 577 minecraft:calcite
fill 48 68 578 48 71 578 minecraft:cobbled_deepslate
setblock 48 68 582 minecraft:calcite
fill 48 68 583 48 71 583 minecraft:cobbled_deepslate
setblock 48 68 587 minecraft:calcite
fill 48 68 588 48 71 588 minecraft:cobbled_deepslate
setblock 48 68 592 minecraft:calcite
fill 48 68 593 48 71 593 minecraft:cobbled_deepslate
setblock 48 68 597 minecraft:calcite
fill 48 68 598 48 71 598 minecraft:cobbled_deepslate
setblock 49 68 571 minecraft:calcite
fill 49 68 572 49 70 572 minecraft:cobbled_deepslate
setblock 49 68 576 minecraft:calcite
fill 49 68 577 49 71 577 minecraft:cobbled_deepslate
setblock 49 68 580 minecraft:cobbled_deepslate
setblock 49 68 581 minecraft:calcite
fill 49 68 582 49 71 582 minecraft:cobbled_deepslate
setblock 49 68 586 minecraft:calcite
fill 49 68 587 49 70 587 minecraft:cobbled_deepslate
setblock 49 68 591 minecraft:calcite
fill 49 68 592 49 71 592 minecraft:cobbled_deepslate
setblock 49 68 596 minecraft:calcite
fill 49 68 597 49 71 597 minecraft:cobbled_deepslate
setblock 50 68 560 minecraft:light[level=14]
setblock 50 68 568 minecraft:light[level=14]
setblock 50 68 574 minecraft:cobbled_deepslate
setblock 50 68 575 minecraft:calcite
fill 50 68 576 50 71 576 minecraft:cobbled_deepslate
setblock 50 68 580 minecraft:calcite
fill 50 68 581 50 71 581 minecraft:cobbled_deepslate
setblock 50 68 584 minecraft:light[level=14]
setblock 50 68 590 minecraft:calcite
setblock 50 68 591 minecraft:cobbled_deepslate
setblock 50 68 595 minecraft:calcite
fill 50 68 596 50 69 596 minecraft:cobbled_deepslate
setblock 52 68 558 minecraft:calcite
setblock 52 68 598 minecraft:calcite
setblock 53 68 597 minecraft:calcite
fill 53 68 598 53 71 598 minecraft:cobbled_deepslate
setblock 54 68 597 minecraft:cobbled_deepslate
setblock 58 68 560 minecraft:light[level=14]
setblock 58 68 568 minecraft:light[level=14]
setblock 58 68 576 minecraft:light[level=14]
setblock 58 68 584 minecraft:light[level=14]
setblock 58 68 592 minecraft:light[level=14]
setblock 62 68 558 minecraft:calcite
setblock 62 68 598 minecraft:calcite
fill 63 68 558 63 71 558 minecraft:cobbled_deepslate
fill 63 68 598 66 68 598 minecraft:cobbled_deepslate
setblock 65 68 559 minecraft:cobbled_deepslate
fill 65 68 597 67 68 597 minecraft:cobbled_deepslate
setblock 66 68 559 minecraft:calcite
setblock 66 68 560 minecraft:light[level=14]
setblock 66 68 568 minecraft:light[level=14]
setblock 66 68 576 minecraft:light[level=14]
setblock 66 68 584 minecraft:light[level=14]
setblock 66 68 592 minecraft:light[level=14]
setblock 67 68 558 minecraft:calcite
fill 67 68 559 67 71 559 minecraft:cobbled_deepslate
setblock 67 68 598 minecraft:calcite
fill 68 68 558 68 71 558 minecraft:cobbled_deepslate
fill 68 68 560 68 69 560 minecraft:cobbled_deepslate
setblock 68 68 597 minecraft:calcite
fill 68 68 598 68 71 598 minecraft:cobbled_deepslate
setblock 69 68 596 minecraft:calcite
fill 69 68 597 69 71 597 minecraft:cobbled_deepslate
setblock 70 68 560 minecraft:calcite
setblock 70 68 596 minecraft:cobbled_deepslate
setblock 71 68 559 minecraft:calcite
setblock 71 68 560 minecraft:cobbled_deepslate
setblock 72 68 558 minecraft:calcite
fill 72 68 559 72 71 559 minecraft:cobbled_deepslate
setblock 72 68 598 minecraft:calcite
fill 73 68 558 73 71 558 minecraft:cobbled_deepslate
setblock 73 68 597 minecraft:calcite
fill 73 68 598 76 68 598 minecraft:cobbled_deepslate
setblock 74 68 560 minecraft:light[level=14]
setblock 74 68 568 minecraft:light[level=14]
setblock 74 68 576 minecraft:light[level=14]
setblock 74 68 584 minecraft:light[level=14]
setblock 74 68 592 minecraft:light[level=14]
fill 74 68 597 77 68 597 minecraft:cobbled_deepslate
setblock 77 68 558 minecraft:calcite
setblock 77 68 598 minecraft:calcite
fill 78 68 558 81 68 558 minecraft:cobbled_deepslate
setblock 78 68 597 minecraft:calcite
fill 78 68 598 78 71 598 minecraft:cobbled_deepslate
fill 79 68 597 79 70 597 minecraft:cobbled_deepslate
setblock 82 68 558 minecraft:calcite
setblock 82 68 560 minecraft:light[level=14]
setblock 82 68 568 minecraft:light[level=14]
setblock 82 68 576 minecraft:light[level=14]
setblock 82 68 584 minecraft:light[level=14]
setblock 82 68 592 minecraft:light[level=14]
setblock 82 68 598 minecraft:calcite
fill 83 68 558 83 71 558 minecraft:cobbled_deepslate
setblock 83 68 597 minecraft:calcite
fill 83 68 598 83 71 598 minecraft:cobbled_deepslate
setblock 84 68 596 minecraft:calcite
fill 84 68 597 84 71 597 minecraft:cobbled_deepslate
setblock 85 68 559 minecraft:cobbled_deepslate
setblock 85 68 595 minecraft:calcite
fill 85 68 596 85 71 596 minecraft:cobbled_deepslate
setblock 86 68 559 minecraft:calcite
setblock 86 68 594 minecraft:calcite
fill 86 68 595 86 71 595 minecraft:cobbled_deepslate
setblock 87 68 558 minecraft:calcite
fill 87 68 559 87 71 559 minecraft:cobbled_deepslate
setblock 87 68 573 minecraft:calcite
fill 87 68 574 87 70 574 minecraft:cobbled_deepslate
setblock 87 68 578 minecraft:calcite
fill 87 68 579 87 70 580 minecraft:cobbled_deepslate
setblock 87 68 588 minecraft:calcite
fill 87 68 589 87 70 589 minecraft:cobbled_deepslate
setblock 87 68 593 minecraft:calcite
fill 87 68 594 87 71 594 minecraft:cobbled_deepslate
setblock 87 68 598 minecraft:calcite
fill 88 68 558 88 71 558 minecraft:cobbled_deepslate
setblock 88 68 562 minecraft:calcite
fill 88 68 563 88 69 563 minecraft:cobbled_deepslate
setblock 88 68 567 minecraft:calcite
setblock 88 68 568 minecraft:cobbled_deepslate
setblock 88 68 572 minecraft:calcite
fill 88 68 573 88 71 573 minecraft:cobbled_deepslate
setblock 88 68 577 minecraft:calcite
fill 88 68 578 88 71 578 minecraft:cobbled_deepslate
setblock 88 68 582 minecraft:calcite
fill 88 68 583 88 71 583 minecraft:cobbled_deepslate
setblock 88 68 587 minecraft:calcite
fill 88 68 588 88 71 588 minecraft:cobbled_deepslate
setblock 88 68 592 minecraft:calcite
fill 88 68 593 88 71 593 minecraft:cobbled_deepslate
setblock 88 68 597 minecraft:calcite
fill 88 68 598 88 71 598 minecraft:cobbled_deepslate
setblock 48 69 561 minecraft:calcite
setblock 48 69 571 minecraft:calcite
fill 48 69 572 48 72 572 minecraft:cobbled_deepslate
setblock 48 69 576 minecraft:calcite
fill 48 69 577 48 72 577 minecraft:cobbled_deepslate
setblock 48 69 581 minecraft:calcite
fill 48 69 582 48 72 582 minecraft:cobbled_deepslate
setblock 48 69 586 minecraft:calcite
fill 48 69 587 48 72 587 minecraft:cobbled_deepslate
setblock 48 69 591 minecraft:calcite
fill 48 69 592 48 72 592 minecraft:cobbled_deepslate
setblock 48 69 596 minecraft:calcite
fill 48 69 597 48 72 597 minecraft:cobbled_deepslate
setblock 49 69 571 minecraft:cobbled_deepslate
setblock 49 69 575 minecraft:calcite
fill 49 69 576 49 72 576 minecraft:cobbled_deepslate
setblock 49 69 580 minecraft:calcite
fill 49 69 581 49 72 581 minecraft:cobbled_deepslate
setblock 49 69 585 minecraft:calcite
fill 49 69 586 49 72 586 minecraft:cobbled_deepslate
setblock 49 69 590 minecraft:calcite
fill 49 69 591 49 70 591 minecraft:cobbled_deepslate
setblock 49 69 595 minecraft:calcite
fill 49 69 596 49 72 596 minecraft:cobbled_deepslate
setblock 50 69 574 minecraft:calcite
fill 50 69 575 50 71 575 minecraft:cobbled_deepslate
setblock 50 69 579 minecraft:calcite
fill 50 69 580 50 72 580 minecraft:cobbled_deepslate
setblock 50 69 594 minecraft:calcite
setblock 50 69 595 minecraft:cobbled_deepslate
setblock 51 69 558 minecraft:calcite
setblock 51 69 598 minecraft:calcite
setblock 52 69 558 minecraft:cobbled_deepslate
setblock 52 69 597 minecraft:calcite
fill 52 69 598 52 72 598 minecraft:cobbled_deepslate
setblock 53 69 597 minecraft:cobbled_deepslate
fill 62 69 558 62 72 558 minecraft:cobbled_deepslate
fill 62 69 598 65 69 598 minecraft:cobbled_deepslate
setblock 64 69 559 minecraft:cobbled_deepslate
setblock 65 69 559 minecraft:calcite
fill 65 69 597 66 69 597 minecraft:cobbled_deepslate
setblock 66 69 558 minecraft:calcite
fill 66 69 559 66 72 559 minecraft:cobbled_deepslate
setblock 66 69 598 minecraft:calcite
fill 67 69 558 67 72 558 minecraft:cobbled_deepslate
setblock 67 69 597 minecraft:calcite
fill 67 69 598 67 72 598 minecraft:cobbled_deepslate
fill 68 69 597 68 72 597 minecraft:cobbled_deepslate
setblock 69 69 560 minecraft:calcite
setblock 70 69 559 minecraft:calcite
fill 70 69 560 70 72 560 minecraft:cobbled_deepslate
setblock 71 69 558 minecraft:calcite
fill 71 69 559 71 72 559 minecraft:cobbled_deepslate
setblock 71 69 598 minecraft:calcite
fill 72 69 558 72 72 558 minecraft:cobbled_deepslate
setblock 72 69 597 minecraft:calcite
fill 72 69 598 75 69 598 minecraft:cobbled_deepslate
fill 73 69 597 75 69 597 minecraft:cobbled_deepslate
setblock 75 69 559 minecraft:calcite
setblock 76 69 558 minecraft:calcite
setblock 76 69 598 minecraft:calcite
fill 77 69 558 80 69 558 minecraft:cobbled_deepslate
fill 77 69 598 77 72 598 minecraft:cobbled_deepslate
setblock 78 69 597 minecraft:cobbled_deepslate
setblock 81 69 558 minecraft:calcite
setblock 81 69 598 minecraft:calcite
fill 82 69 558 82 71 559 minecraft:cobbled_deepslate
setblock 82 69 597 minecraft:calcite
fill 82 69 598 82 72 598 minecraft:cobbled_deepslate
setblock 83 69 596 minecraft:calcite
fill 83 69 597 83 72 597 minecraft:cobbled_deepslate
fill 84 69 596 84 72 596 minecraft:cobbled_deepslate
setblock 85 69 559 minecraft:calcite
setblock 86 69 558 minecraft:calcite
fill 86 69 559 86 72 559 minecraft:cobbled_deepslate
setblock 86 69 593 minecraft:calcite
fill 86 69 594 86 72 594 minecraft:cobbled_deepslate
setblock 86 69 598 minecraft:calcite
fill 87 69 558 87 72 558 minecraft:cobbled_deepslate
setblock 87 69 573 minecraft:cobbled_deepslate
setblock 87 69 577 minecraft:calcite
fill 87 69 578 87 72 578 minecraft:cobbled_deepslate
setblock 87 69 581 minecraft:cobbled_deepslate
setblock 87 69 588 minecraft:cobbled_deepslate
setblock 87 69 592 minecraft:calcite
fill 87 69 593 87 72 593 minecraft:cobbled_deepslate
setblock 87 69 597 minecraft:calcite
fill 87 69 598 87 72 598 minecraft:cobbled_deepslate
setblock 88 69 561 minecraft:calcite
fill 88 69 562 88 72 562 minecraft:cobbled_deepslate
setblock 88 69 571 minecraft:calcite
fill 88 69 572 88 71 572 minecraft:cobbled_deepslate
setblock 88 69 576 minecraft:calcite
fill 88 69 577 88 72 577 minecraft:cobbled_deepslate
setblock 88 69 581 minecraft:calcite
fill 88 69 582 88 72 582 minecraft:cobbled_deepslate
setblock 88 69 586 minecraft:calcite
fill 88 69 587 88 72 587 minecraft:cobbled_deepslate
setblock 88 69 591 minecraft:calcite
fill 88 69 592 88 72 592 minecraft:cobbled_deepslate
setblock 88 69 596 minecraft:calcite
fill 88 69 597 88 72 597 minecraft:cobbled_deepslate
setblock 48 70 560 minecraft:calcite
setblock 48 70 570 minecraft:calcite
fill 48 70 571 48 73 571 minecraft:cobbled_deepslate
setblock 48 70 575 minecraft:calcite
fill 48 70 576 48 73 576 minecraft:cobbled_deepslate
setblock 48 70 580 minecraft:calcite
fill 48 70 581 48 73 581 minecraft:cobbled_deepslate
setblock 48 70 585 minecraft:calcite
fill 48 70 586 48 73 586 minecraft:cobbled_deepslate
setblock 48 70 590 minecraft:calcite
fill 48 70 591 48 73 591 minecraft:cobbled_deepslate
setblock 48 70 595 minecraft:calcite
fill 48 70 596 48 73 596 minecraft:cobbled_deepslate
setblock 49 70 574 minecraft:calcite
fill 49 70 575 49 73 575 minecraft:cobbled_deepslate
setblock 49 70 579 minecraft:calcite
fill 49 70 580 49 73 580 minecraft:cobbled_deepslate
setblock 49 70 584 minecraft:calcite
fill 49 70 585 49 73 585 minecraft:cobbled_deepslate
setblock 49 70 589 minecraft:calcite
setblock 49 70 590 minecraft:cobbled_deepslate
setblock 49 70 594 minecraft:calcite
fill 49 70 595 49 72 595 minecraft:cobbled_deepslate
setblock 50 70 558 minecraft:calcite
setblock 50 70 574 minecraft:cobbled_deepslate
setblock 50 70 578 minecraft:calcite
fill 50 70 579 50 73 579 minecraft:cobbled_deepslate
setblock 50 70 598 minecraft:calcite
fill 51 70 558 51 71 558 minecraft:cobbled_deepslate
setblock 51 70 597 minecraft:calcite
fill 51 70 598 51 73 598 minecraft:cobbled_deepslate
fill 61 70 558 61 73 558 minecraft:cobbled_deepslate
fill 62 70 598 64 70 598 minecraft:cobbled_deepslate
setblock 64 70 559 minecraft:calcite
setblock 65 70 558 minecraft:calcite
fill 65 70 559 65 73 559 minecraft:cobbled_deepslate
setblock 65 70 597 minecraft:cobbled_deepslate
setblock 65 70 598 minecraft:calcite
fill 66 70 558 66 73 558 minecraft:cobbled_deepslate
setblock 66 70 597 minecraft:calcite
fill 66 70 598 66 73 598 minecraft:cobbled_deepslate
setblock 67 70 560 minecraft:cobbled_deepslate
fill 67 70 597 67 73 597 minecraft:cobbled_deepslate
setblock 68 70 560 minecraft:calcite
setblock 69 70 559 minecraft:calcite
fill 69 70 560 69 73 560 minecraft:cobbled_deepslate
setblock 70 70 558 minecraft:calcite
fill 70 70 559 70 73 559 minecraft:cobbled_deepslate
setblock 70 70 598 minecraft:calcite
fill 71 70 558 71 73 558 minecraft:cobbled_deepslate
setblock 71 70 597 minecraft:calcite
fill 71 70 598 74 70 598 minecraft:cobbled_deepslate
fill 72 70 597 73 70 597 minecraft:cobbled_deepslate
setblock 74 70 559 minecraft:calcite
setblock 75 70 558 minecraft:calcite
setblock 75 70 598 minecraft:calcite
fill 76 70 558 79 70 558 minecraft:cobbled_deepslate
fill 76 70 598 76 73 598 minecraft:cobbled_deepslate
setblock 80 70 558 minecraft:calcite
setblock 80 70 598 minecraft:calcite
fill 81 70 558 81 73 558 minecraft:cobbled_deepslate
setblock 81 70 597 minecraft:calcite
fill 81 70 598 81 73 598 minecraft:cobbled_deepslate
fill 82 70 597 82 73 597 minecraft:cobbled_deepslate
fill 83 70 596 83 73 596 minecraft:cobbled_deepslate
setblock 84 70 559 minecraft:calcite
setblock 85 70 558 minecraft:calcite
fill 85 70 559 85 73 559 minecraft:cobbled_deepslate
setblock 85 70 598 minecraft:calcite
fill 86 70 558 86 73 558 minecraft:cobbled_deepslate
fill 86 70 593 86 71 593 minecraft:cobbled_deepslate
setblock 86 70 597 minecraft:calcite
fill 86 70 598 86 73 598 minecraft:cobbled_deepslate
setblock 87 70 576 minecraft:calcite
fill 87 70 577 87 73 577 minecraft:cobbled_deepslate
setblock 87 70 581 minecraft:calcite
fill 87 70 582 87 73 582 minecraft:cobbled_deepslate
setblock 87 70 591 minecraft:calcite
fill 87 70 592 87 73 592 minecraft:cobbled_deepslate
setblock 87 70 596 minecraft:calcite
fill 87 70 597 87 73 597 minecraft:cobbled_deepslate
setblock 88 70 560 minecraft:calcite
fill 88 70 561 88 73 561 minecraft:cobbled_deepslate
setblock 88 70 571 minecraft:cobbled_deepslate
setblock 88 70 575 minecraft:calcite
fill 88 70 576 88 73 576 minecraft:cobbled_deepslate
setblock 88 70 580 minecraft:calcite
fill 88 70 581 88 73 581 minecraft:cobbled_deepslate
setblock 88 70 585 minecraft:calcite
fill 88 70 586 88 73 586 minecraft:cobbled_deepslate
setblock 88 70 590 minecraft:calcite
fill 88 70 591 88 73 591 minecraft:cobbled_deepslate
setblock 88 70 595 minecraft:calcite
fill 88 70 596 88 73 596 minecraft:cobbled_deepslate
setblock 48 71 559 minecraft:calcite
fill 48 71 560 48 74 560 minecraft:cobbled_deepslate
setblock 48 71 570 minecraft:cobbled_deepslate
setblock 48 71 574 minecraft:calcite
fill 48 71 575 48 74 575 minecraft:cobbled_deepslate
setblock 48 71 579 minecraft:calcite
fill 48 71 580 48 74 580 minecraft:cobbled_deepslate
setblock 48 71 584 minecraft:calcite
fill 48 71 585 48 74 585 minecraft:cobbled_deepslate
setblock 48 71 589 minecraft:calcite
fill 48 71 590 48 74 590 minecraft:cobbled_deepslate
setblock 48 71 594 minecraft:calcite
fill 48 71 595 48 74 595 minecraft:cobbled_deepslate
setblock 49 71 558 minecraft:calcite
setblock 49 71 573 minecraft:calcite
fill 49 71 574 49 74 574 minecraft:cobbled_deepslate
setblock 49 71 578 minecraft:calcite
fill 49 71 579 49 74 579 minecraft:cobbled_deepslate
setblock 49 71 583 minecraft:calcite
fill 49 71 584 49 74 584 minecraft:cobbled_deepslate
setblock 49 71 593 minecraft:calcite
setblock 49 71 594 minecraft:cobbled_deepslate
setblock 49 71 598 minecraft:calcite
fill 50 71 558 50 74 558 minecraft:cobbled_deepslate
setblock 50 71 577 minecraft:calcite
fill 50 71 578 50 74 578 minecraft:cobbled_deepslate
setblock 50 71 597 minecraft:calcite
fill 50 71 598 50 74 598 minecraft:cobbled_deepslate
fill 62 71 598 63 71 598 minecraft:cobbled_deepslate
setblock 63 71 559 minecraft:calcite
setblock 64 71 558 minecraft:calcite
fill 64 71 559 64 74 559 minecraft:cobbled_deepslate
setblock 64 71 598 minecraft:calcite
fill 65 71 558 65 74 558 minecraft:cobbled_deepslate
setblock 65 71 597 minecraft:calcite
fill 65 71 598 65 74 598 minecraft:cobbled_deepslate
setblock 66 71 560 minecraft:cobbled_deepslate
fill 66 71 597 66 74 597 minecraft:cobbled_deepslate
setblock 67 71 560 minecraft:calcite
setblock 68 71 559 minecraft:calcite
fill 68 71 560 68 74 560 minecraft:cobbled_deepslate
setblock 69 71 558 minecraft:calcite
fill 69 71 559 69 74 559 minecraft:cobbled_deepslate
setblock 69 71 598 minecraft:calcite
fill 70 71 558 70 74 558 minecraft:cobbled_deepslate
setblock 70 71 597 minecraft:calcite
fill 70 71 598 73 71 598 minecraft:cobbled_deepslate
setblock 71 71 597 minecraft:cobbled_deepslate
setblock 73 71 559 minecraft:calcite
setblock 74 71 558 minecraft:calcite
fill 74 71 559 74 74 559 minecraft:cobbled_deepslate
setblock 74 71 598 minecraft:calcite
fill 75 71 558 78 71 558 minecraft:cobbled_deepslate
fill 75 71 598 75 74 598 minecraft:cobbled_deepslate
setblock 79 71 558 minecraft:calcite
setblock 79 71 598 minecraft:calcite
fill 80 71 558 80 74 558 minecraft:cobbled_deepslate
setblock 80 71 597 minecraft:calcite
fill 80 71 598 80 74 598 minecraft:cobbled_deepslate
fill 81 71 559 81 72 559 minecraft:cobbled_deepslate
fill 81 71 597 81 74 597 minecraft:cobbled_deepslate
setblock 83 71 559 minecraft:calcite
setblock 84 71 558 minecraft:calcite
fill 84 71 559 84 74 559 minecraft:cobbled_deepslate
setblock 84 71 598 minecraft:calcite
fill 85 71 558 85 74 558 minecraft:cobbled_deepslate
setblock 85 71 597 minecraft:calcite
fill 85 71 598 85 74 598 minecraft:cobbled_deepslate
setblock 86 71 596 minecraft:calcite
fill 86 71 597 86 74 597 minecraft:cobbled_deepslate
setblock 87 71 560 minecraft:calcite
setblock 87 71 575 minecraft:calcite
fill 87 71 576 87 74 576 minecraft:cobbled_deepslate
setblock 87 71 579 minecraft:cobbled_deepslate
setblock 87 71 580 minecraft:calcite
fill 87 71 581 87 74 581 minecraft:cobbled_deepslate
fill 87 71 583 87 72 583 minecraft:cobbled_deepslate
setblock 87 71 590 minecraft:calcite
fill 87 71 591 87 74 591 minecraft:cobbled_deepslate
setblock 87 71 595 minecraft:calcite
fill 87 71 596 87 74 596 minecraft:cobbled_deepslate
setblock 88 71 559 minecraft:calcite
fill 88 71 560 88 74 560 minecraft:cobbled_deepslate
setblock 88 71 574 minecraft:calcite
fill 88 71 575 88 74 575 minecraft:cobbled_deepslate
setblock 88 71 579 minecraft:calcite
fill 88 71 580 88 74 580 minecraft:cobbled_deepslate
setblock 88 71 584 minecraft:calcite
fill 88 71 585 88 74 585 minecraft:cobbled_deepslate
setblock 88 71 589 minecraft:calcite
fill 88 71 590 88 74 590 minecraft:cobbled_deepslate
setblock 88 71 594 minecraft:calcite
fill 88 71 595 88 74 595 minecraft:cobbled_deepslate
setblock 48 72 558 minecraft:calcite
fill 48 72 559 48 75 559 minecraft:cobbled_deepslate
fill 48 72 561 48 73 561 minecraft:cobbled_deepslate
setblock 48 72 573 minecraft:calcite
fill 48 72 574 48 75 574 minecraft:cobbled_deepslate
setblock 48 72 578 minecraft:calcite
fill 48 72 579 48 75 579 minecraft:cobbled_deepslate
setblock 48 72 583 minecraft:calcite
fill 48 72 584 48 75 584 minecraft:cobbled_deepslate
setblock 48 72 588 minecraft:calcite
fill 48 72 589 48 75 589 minecraft:cobbled_deepslate
setblock 48 72 593 minecraft:calcite
fill 48 72 594 48 75 594 minecraft:cobbled_deepslate
setblock 48 72 598 minecraft:calcite
fill 49 72 558 49 75 558 minecraft:cobbled_deepslate
setblock 49 72 573 minecraft:cobbled_deepslate
setblock 49 72 577 minecraft:calcite
fill 49 72 578 49 75 578 minecraft:cobbled_deepslate
setblock 49 72 582 minecraft:calcite
fill 49 72 583 49 75 583 minecraft:cobbled_deepslate
setblock 49 72 597 minecraft:calcite
fill 49 72 598 49 75 598 minecraft:cobbled_deepslate
setblock 50 72 576 minecraft:calcite
fill 50 72 577 50 73 577 minecraft:cobbled_deepslate
setblock 50 72 581 minecraft:calcite
fill 60 72 558 60 74 558 minecraft:cobbled_deepslate
setblock 62 72 559 minecraft:calcite
setblock 62 72 598 minecraft:cobbled_deepslate
setblock 63 72 558 minecraft:calcite
fill 63 72 559 63 75 559 minecraft:cobbled_deepslate
setblock 63 72 598 minecraft:calcite
fill 64 72 558 64 75 558 minecraft:cobbled_deepslate
fill 64 72 598 64 75 598 minecraft:cobbled_deepslate
setblock 65 72 560 minecraft:cobbled_deepslate
setblock 65 72 597 minecraft:cobbled_deepslate
setblock 66 72 560 minecraft:calcite
setblock 67 72 559 minecraft:calcite
fill 67 72 560 67 75 560 minecraft:cobbled_deepslate
setblock 68 72 558 minecraft:calcite
fill 68 72 559 68 75 559 minecraft:cobbled_deepslate
setblock 68 72 598 minecraft:calcite
fill 69 72 558 69 75 558 minecraft:cobbled_deepslate
setblock 69 72 597 minecraft:calcite
fill 69 72 598 72 72 598 minecraft:cobbled_deepslate
setblock 70 72 597 minecraft:cobbled_deepslate
setblock 72 72 559 minecraft:calcite
setblock 73 72 558 minecraft:calcite
fill 73 72 559 73 75 559 minecraft:cobbled_deepslate
setblock 73 72 598 minecraft:calcite
fill 74 72 558 77 72 558 minecraft:cobbled_deepslate
fill 74 72 598 74 75 598 minecraft:cobbled_deepslate
setblock 78 72 558 minecraft:calcite
setblock 78 72 598 minecraft:calcite
fill 79 72 558 79 75 558 minecraft:cobbled_deepslate
fill 79 72 598 79 75 598 minecraft:cobbled_deepslate
fill 80 72 559 80 73 559 minecraft:cobbled_deepslate
fill 80 72 597 80 75 597 minecraft:cobbled_deepslate
setblock 82 72 558 minecraft:cobbled_deepslate
setblock 82 72 559 minecraft:calcite
setblock 83 72 558 minecraft:calcite
fill 83 72 559 83 75 559 minecraft:cobbled_deepslate
setblock 83 72 598 minecraft:calcite
fill 84 72 558 84 75 558 minecraft:cobbled_deepslate
setblock 84 72 597 minecraft:calcite
fill 84 72 598 84 75 598 minecraft:cobbled_deepslate
setblock 85 72 596 minecraft:calcite
fill 85 72 597 85 75 597 minecraft:cobbled_deepslate
setblock 86 72 595 minecraft:calcite
fill 86 72 596 86 75 596 minecraft:cobbled_deepslate
setblock 87 72 559 minecraft:calcite
fill 87 72 560 87 75 560 minecraft:cobbled_deepslate
setblock 87 72 575 minecraft:cobbled_deepslate
setblock 87 72 579 minecraft:calcite
fill 87 72 580 87 75 580 minecraft:cobbled_deepslate
setblock 87 72 584 minecraft:calcite
fill 87 72 585 87 75 585 minecraft:cobbled_deepslate
fill 87 72 590 87 75 590 minecraft:cobbled_deepslate
setblock 87 72 594 minecraft:calcite
fill 87 72 595 87 75 595 minecraft:cobbled_deepslate
setblock 88 72 558 minecraft:calcite
fill 88 72 559 88 75 559 minecraft:cobbled_deepslate
setblock 88 72 573 minecraft:calcite
fill 88 72 574 88 75 574 minecraft:cobbled_deepslate
setblock 88 72 578 minecraft:calcite
fill 88 72 579 88 75 579 minecraft:cobbled_deepslate
setblock 88 72 583 minecraft:calcite
fill 88 72 584 88 75 584 minecraft:cobbled_deepslate
setblock 88 72 588 minecraft:calcite
fill 88 72 589 88 75 589 minecraft:cobbled_deepslate
setblock 88 72 593 minecraft:calcite
fill 88 72 594 88 75 594 minecraft:cobbled_deepslate
setblock 88 72 598 minecraft:calcite
fill 48 73 558 48 76 558 minecraft:cobbled_deepslate
setblock 48 73 572 minecraft:calcite
fill 48 73 573 48 76 573 minecraft:cobbled_deepslate
setblock 48 73 577 minecraft:calcite
fill 48 73 578 48 76 578 minecraft:cobbled_deepslate
setblock 48 73 582 minecraft:calcite
fill 48 73 583 48 76 583 minecraft:cobbled_deepslate
setblock 48 73 587 minecraft:calcite
fill 48 73 588 48 76 588 minecraft:cobbled_deepslate
setblock 48 73 592 minecraft:calcite
fill 48 73 593 48 76 593 minecraft:cobbled_deepslate
setblock 48 73 597 minecraft:calcite
fill 48 73 598 48 76 598 minecraft:cobbled_deepslate
setblock 49 73 576 minecraft:calcite
fill 49 73 577 49 76 577 minecraft:cobbled_deepslate
setblock 49 73 581 minecraft:calcite
fill 49 73 582 49 76 582 minecraft:cobbled_deepslate
setblock 49 73 586 minecraft:calcite
setblock 50 73 580 minecraft:calcite
fill 50 73 581 50 76 581 minecraft:cobbled_deepslate
fill 59 73 558 59 75 558 minecraft:cobbled_deepslate
setblock 61 73 559 minecraft:calcite
setblock 61 73 598 minecraft:cobbled_deepslate
setblock 62 73 558 minecraft:calcite
fill 62 73 559 62 76 559 minecraft:cobbled_deepslate
setblock 62 73 598 minecraft:calcite
fill 63 73 558 63 76 558 minecraft:cobbled_deepslate
fill 63 73 598 63 76 598 minecraft:cobbled_deepslate
setblock 64 73 560 minecraft:cobbled_deepslate
setblock 65 73 560 minecraft:calcite
setblock 66 73 559 minecraft:calcite
fill 66 73 560 66 76 560 minecraft:cobbled_deepslate
setblock 67 73 558 minecraft:calcite
fill 67 73 559 67 76 559 minecraft:cobbled_deepslate
setblock 67 73 598 minecraft:calcite
fill 68 73 558 68 76 558 minecraft:cobbled_deepslate
setblock 68 73 597 minecraft:calcite
fill 68 73 598 71 73 598 minecraft:cobbled_deepslate
setblock 70 73 560 minecraft:calcite
setblock 71 73 559 minecraft:calcite
setblock 72 73 558 minecraft:calcite
fill 72 73 559 72 76 559 minecraft:cobbled_deepslate
setblock 72 73 598 minecraft:calcite
fill 73 73 558 76 73 558 minecraft:cobbled_deepslate
fill 73 73 598 73 76 598 minecraft:cobbled_deepslate
setblock 75 73 559 minecraft:cobbled_deepslate
setblock 77 73 558 minecraft:calcite
setblock 77 73 598 minecraft:calcite
fill 78 73 558 78 75 559 minecraft:cobbled_deepslate
fill 78 73 598 78 76 598 minecraft:cobbled_deepslate
fill 79 73 559 79 74 559 minecraft:cobbled_deepslate
fill 79 73 597 79 76 597 minecraft:cobbled_deepslate
setblock 81 73 559 minecraft:calcite
setblock 82 73 558 minecraft:calcite
fill 82 73 559 82 76 559 minecraft:cobbled_deepslate
setblock 82 73 598 minecraft:calcite
fill 83 73 558 83 76 558 minecraft:cobbled_deepslate
setblock 83 73 597 minecraft:calcite
fill 83 73 598 83 76 598 minecraft:cobbled_deepslate
setblock 84 73 596 minecraft:calcite
fill 84 73 597 84 76 597 minecraft:cobbled_deepslate
fill 85 73 596 85 76 596 minecraft:cobbled_deepslate
setblock 86 73 559 minecraft:calcite
setblock 86 73 594 minecraft:calcite
fill 86 73 595 86 76 595 minecraft:cobbled_deepslate
setblock 87 73 558 minecraft:calcite
fill 87 73 559 87 76 559 minecraft:cobbled_deepslate
fill 87 73 561 87 74 561 minecraft:cobbled_deepslate
setblock 87 73 578 minecraft:calcite
fill 87 73 579 87 76 579 minecraft:cobbled_deepslate
setblock 87 73 583 minecraft:calcite
fill 87 73 584 87 76 584 minecraft:cobbled_deepslate
fill 87 73 586 87 73 587 minecraft:cobbled_deepslate
setblock 87 73 593 minecraft:calcite
fill 87 73 594 87 76 594 minecraft:cobbled_deepslate
setblock 87 73 598 minecraft:calcite
fill 88 73 558 88 76 558 minecraft:cobbled_deepslate
setblock 88 73 562 minecraft:calcite
setblock 88 73 573 minecraft:cobbled_deepslate
setblock 88 73 577 minecraft:calcite
fill 88 73 578 88 76 578 minecraft:cobbled_deepslate
setblock 88 73 582 minecraft:calcite
fill 88 73 583 88 76 583 minecraft:cobbled_deepslate
setblock 88 73 587 minecraft:calcite
fill 88 73 588 88 76 588 minecraft:cobbled_deepslate
setblock 88 73 592 minecraft:calcite
fill 88 73 593 88 76 593 minecraft:cobbled_deepslate
setblock 88 73 597 minecraft:calcite
fill 88 73 598 88 76 598 minecraft:cobbled_deepslate
setblock 48 74 561 minecraft:calcite
fill 48 74 562 48 77 562 minecraft:cobbled_deepslate
fill 48 74 572 48 77 572 minecraft:cobbled_deepslate
setblock 48 74 576 minecraft:calcite
fill 48 74 577 48 77 577 minecraft:cobbled_deepslate
setblock 48 74 581 minecraft:calcite
fill 48 74 582 48 77 582 minecraft:cobbled_deepslate
setblock 48 74 586 minecraft:calcite
fill 48 74 587 48 77 587 minecraft:cobbled_deepslate
setblock 48 74 591 minecraft:calcite
fill 48 74 592 48 77 592 minecraft:cobbled_deepslate
setblock 48 74 596 minecraft:calcite
fill 48 74 597 48 77 597 minecraft:cobbled_deepslate
setblock 49 74 575 minecraft:calcite
fill 49 74 576 49 77 576 minecraft:cobbled_deepslate
setblock 49 74 580 minecraft:calcite
fill 49 74 581 49 77 581 minecraft:cobbled_deepslate
setblock 49 74 585 minecraft:calcite
fill 49 74 586 49 77 586 minecraft:cobbled_deepslate
setblock 50 74 579 minecraft:calcite
fill 50 74 580 50 77 580 minecraft:cobbled_deepslate
fill 50 74 582 50 75 582 minecraft:cobbled_deepslate
fill 51 74 559 51 79 559 minecraft:deepslate
fill 58 74 558 58 76 558 minecraft:cobbled_deepslate
setblock 60 74 559 minecraft:calcite
setblock 61 74 558 minecraft:calcite
fill 61 74 559 61 77 559 minecraft:cobbled_deepslate
setblock 61 74 598 minecraft:calcite
fill 62 74 558 62 77 558 minecraft:cobbled_deepslate
fill 62 74 560 63 74 560 minecraft:cobbled_deepslate
fill 62 74 598 62 77 598 minecraft:cobbled_deepslate
setblock 64 74 560 minecraft:calcite
setblock 65 74 559 minecraft:calcite
fill 65 74 560 65 77 560 minecraft:cobbled_deepslate
fill 65 74 597 65 75 597 minecraft:cobbled_deepslate
setblock 66 74 558 minecraft:calcite
fill 66 74 559 66 77 559 minecraft:cobbled_deepslate
setblock 66 74 598 minecraft:calcite
fill 67 74 558 67 77 558 minecraft:cobbled_deepslate
setblock 67 74 597 minecraft:calcite
fill 67 74 598 70 74 598 minecraft:cobbled_deepslate
setblock 69 74 560 minecraft:calcite
setblock 70 74 559 minecraft:calcite
fill 70 74 560 70 77 560 minecraft:cobbled_deepslate
setblock 71 74 558 minecraft:calcite
fill 71 74 559 71 77 559 minecraft:cobbled_deepslate
setblock 71 74 598 minecraft:calcite
fill 72 74 558 75 74 558 minecraft:cobbled_deepslate
fill 72 74 598 72 77 598 minecraft:cobbled_deepslate
setblock 75 74 559 minecraft:calcite
setblock 76 74 558 minecraft:calcite
fill 76 74 559 77 76 559 minecraft:cobbled_deepslate
setblock 76 74 598 minecraft:calcite
fill 77 74 558 77 77 558 minecraft:cobbled_deepslate
fill 77 74 598 77 77 598 minecraft:cobbled_deepslate
setblock 80 74 559 minecraft:calcite
setblock 81 74 558 minecraft:calcite
fill 81 74 559 81 77 559 minecraft:cobbled_deepslate
setblock 81 74 598 minecraft:calcite
fill 82 74 558 82 77 558 minecraft:cobbled_deepslate
setblock 82 74 597 minecraft:calcite
fill 82 74 598 82 77 598 minecraft:cobbled_deepslate
setblock 83 74 596 minecraft:calcite
fill 83 74 597 83 77 597 minecraft:cobbled_deepslate
fill 84 74 596 84 77 596 minecraft:cobbled_deepslate
setblock 85 74 559 minecraft:calcite
setblock 86 74 558 minecraft:calcite
fill 86 74 559 86 77 559 minecraft:cobbled_deepslate
fill 86 74 579 86 74 582 minecraft:cobbled_deepslate
setblock 86 74 583 minecraft:calcite
setblock 86 74 598 minecraft:calcite
fill 87 74 558 87 77 558 minecraft:cobbled_deepslate
setblock 87 74 577 minecraft:calcite
fill 87 74 578 87 77 578 minecraft:cobbled_deepslate
setblock 87 74 582 minecraft:calcite
fill 87 74 583 87 77 583 minecraft:cobbled_deepslate
setblock 87 74 586 minecraft:cobbled_deepslate
setblock 87 74 587 minecraft:calcite
fill 87 74 588 87 76 589 minecraft:cobbled_deepslate
setblock 87 74 592 minecraft:calcite
fill 87 74 593 87 77 593 minecraft:cobbled_deepslate
setblock 87 74 597 minecraft:calcite
fill 87 74 598 87 77 598 minecraft:cobbled_deepslate
setblock 88 74 561 minecraft:calcite
fill 88 74 562 88 76 563 minecraft:cobbled_deepslate
setblock 88 74 576 minecraft:calcite
fill 88 74 577 88 77 577 minecraft:cobbled_deepslate
setblock 88 74 581 minecraft:calcite
fill 88 74 582 88 77 582 minecraft:cobbled_deepslate
setblock 88 74 586 minecraft:calcite
fill 88 74 587 88 77 587 minecraft:cobbled_deepslate
setblock 88 74 591 minecraft:calcite
fill 88 74 592 88 77 592 minecraft:cobbled_deepslate
setblock 88 74 596 minecraft:calcite
fill 88 74 597 88 77 597 minecraft:cobbled_deepslate
setblock 48 75 560 minecraft:calcite
fill 48 75 561 48 78 561 minecraft:cobbled_deepslate
fill 48 75 563 48 75 564 minecraft:cobbled_deepslate
setblock 48 75 575 minecraft:calcite
fill 48 75 576 48 78 576 minecraft:cobbled_deepslate
setblock 48 75 580 minecraft:calcite
fill 48 75 581 48 78 581 minecraft:cobbled_deepslate
setblock 48 75 585 minecraft:calcite
fill 48 75 586 48 78 586 minecraft:cobbled_deepslate
setblock 48 75 590 minecraft:calcite
fill 48 75 591 48 78 591 minecraft:cobbled_deepslate
setblock 48 75 595 minecraft:calcite
fill 48 75 596 48 77 596 minecraft:cobbled_deepslate
fill 49 75 575 49 78 575 minecraft:cobbled_deepslate
setblock 49 75 579 minecraft:calcite
fill 49 75 580 49 78 580 minecraft:cobbled_deepslate
setblock 49 75 584 minecraft:calcite
fill 49 75 585 49 78 585 minecraft:cobbled_deepslate
setblock 50 75 558 minecraft:calcite
setblock 50 75 578 minecraft:calcite
fill 50 75 579 50 78 579 minecraft:cobbled_deepslate
setblock 50 75 583 minecraft:calcite
setblock 50 75 598 minecraft:calcite
fill 57 75 558 57 77 558 minecraft:cobbled_deepslate
setblock 59 75 559 minecraft:calcite
setblock 60 75 558 minecraft:calcite
fill 60 75 559 60 78 559 minecraft:cobbled_deepslate
setblock 60 75 598 minecraft:calcite
fill 61 75 558 61 78 558 minecraft:cobbled_deepslate
fill 61 75 560 62 75 560 minecraft:cobbled_deepslate
fill 61 75 598 61 78 598 minecraft:cobbled_deepslate
setblock 63 75 560 minecraft:calcite
setblock 64 75 559 minecraft:calcite
fill 64 75 560 64 77 561 minecraft:cobbled_deepslate
setblock 65 75 558 minecraft:calcite
fill 65 75 559 65 78 559 minecraft:cobbled_deepslate
fill 65 75 561 66 75 561 minecraft:cobbled_deepslate
setblock 65 75 598 minecraft:calcite
fill 66 75 558 66 78 558 minecraft:cobbled_deepslate
setblock 66 75 597 minecraft:calcite
fill 66 75 598 69 75 598 minecraft:cobbled_deepslate
setblock 67 75 561 minecraft:calcite
fill 67 75 597 67 76 597 minecraft:cobbled_deepslate
setblock 68 75 560 minecraft:calcite
setblock 69 75 559 minecraft:calcite
fill 69 75 560 69 78 560 minecraft:cobbled_deepslate
setblock 70 75 558 minecraft:calcite
fill 70 75 559 70 78 559 minecraft:cobbled_deepslate
setblock 70 75 598 minecraft:calcite
fill 71 75 558 74 75 558 minecraft:cobbled_deepslate
fill 71 75 560 71 76 560 minecraft:cobbled_deepslate
fill 71 75 598 71 78 598 minecraft:cobbled_deepslate
setblock 74 75 559 minecraft:calcite
setblock 75 75 558 minecraft:calcite
fill 75 75 559 75 78 559 minecraft:cobbled_deepslate
setblock 75 75 598 minecraft:calcite
fill 76 75 558 76 78 558 minecraft:cobbled_deepslate
fill 76 75 598 76 78 598 minecraft:cobbled_deepslate
setblock 79 75 559 minecraft:calcite
setblock 80 75 558 minecraft:calcite
fill 80 75 559 80 78 559 minecraft:cobbled_deepslate
setblock 80 75 598 minecraft:calcite
fill 81 75 558 81 78 558 minecraft:cobbled_deepslate
fill 81 75 560 82 75 560 minecraft:cobbled_deepslate
setblock 81 75 597 minecraft:calcite
fill 81 75 598 81 78 598 minecraft:cobbled_deepslate
setblock 82 75 596 minecraft:calcite
fill 82 75 597 82 78 597 minecraft:cobbled_deepslate
setblock 83 75 560 minecraft:calcite
fill 83 75 596 83 78 596 minecraft:cobbled_deepslate
setblock 84 75 559 minecraft:calcite
fill 84 75 560 85 77 560 minecraft:cobbled_deepslate
setblock 85 75 558 minecraft:calcite
fill 85 75 559 85 78 559 minecraft:cobbled_deepslate
setblock 85 75 598 minecraft:calcite
fill 86 75 558 86 78 558 minecraft:cobbled_deepslate
fill 86 75 579 86 75 581 minecraft:cobbled_deepslate
setblock 86 75 582 minecraft:calcite
fill 86 75 583 86 76 585 minecraft:cobbled_deepslate
setblock 86 75 597 minecraft:calcite
fill 86 75 598 86 78 598 minecraft:cobbled_deepslate
setblock 87 75 561 minecraft:calcite
fill 87 75 562 87 78 562 minecraft:cobbled_deepslate
setblock 87 75 576 minecraft:calcite
fill 87 75 577 87 78 577 minecraft:cobbled_deepslate
setblock 87 75 581 minecraft:calcite
fill 87 75 582 87 78 582 minecraft:cobbled_deepslate
setblock 87 75 586 minecraft:calcite
fill 87 75 587 87 78 587 minecraft:cobbled_deepslate
setblock 87 75 591 minecraft:calcite
fill 87 75 592 87 78 592 minecraft:cobbled_deepslate
setblock 87 75 596 minecraft:calcite
fill 87 75 597 87 78 597 minecraft:cobbled_deepslate
setblock 88 75 560 minecraft:calcite
fill 88 75 561 88 78 561 minecraft:cobbled_deepslate
setblock 88 75 575 minecraft:calcite
fill 88 75 576 88 78 576 minecraft:cobbled_deepslate
setblock 88 75 580 minecraft:calcite
fill 88 75 581 88 78 581 minecraft:cobbled_deepslate
setblock 88 75 585 minecraft:calcite
fill 88 75 586 88 78 586 minecraft:cobbled_deepslate
setblock 88 75 590 minecraft:calcite
fill 88 75 591 88 78 591 minecraft:cobbled_deepslate
setblock 88 75 595 minecraft:calcite
fill 88 75 596 88 78 596 minecraft:cobbled_deepslate
setblock 48 76 559 minecraft:calcite
fill 48 76 560 48 79 560 minecraft:cobbled_deepslate
setblock 48 76 563 minecraft:cobbled_deepslate
setblock 48 76 564 minecraft:calcite
fill 48 76 565 48 79 565 minecraft:cobbled_deepslate
fill 48 76 571 48 78 571 minecraft:cobbled_deepslate
setblock 48 76 574 minecraft:calcite
fill 48 76 575 48 79 575 minecraft:cobbled_deepslate
setblock 48 76 579 minecraft:calcite
fill 48 76 580 48 79 580 minecraft:cobbled_deepslate
setblock 48 76 584 minecraft:calcite
fill 48 76 585 48 79 585 minecraft:cobbled_deepslate
setblock 48 76 589 minecraft:calcite
fill 48 76 590 48 79 590 minecraft:cobbled_deepslate
setblock 48 76 594 minecraft:calcite
setblock 48 76 595 minecraft:cobbled_deepslate
setblock 49 76 558 minecraft:calcite
setblock 49 76 578 minecraft:calcite
fill 49 76 579 49 79 579 minecraft:cobbled_deepslate
setblock 49 76 583 minecraft:calcite
fill 49 76 584 49 79 584 minecraft:cobbled_deepslate
setblock 49 76 587 minecraft:cobbled_deepslate
setblock 49 76 598 minecraft:calcite
fill 50 76 558 51 78 558 minecraft:cobbled_deepslate
setblock 50 76 560 minecraft:light[level=14]
setblock 50 76 568 minecraft:light[level=14]
setblock 50 76 576 minecraft:light[level=14]
setblock 50 76 578 minecraft:cobbled_deepslate
setblock 50 76 582 minecraft:calcite
fill 50 76 583 50 79 583 minecraft:cobbled_deepslate
setblock 50 76 584 minecraft:light[level=14]
setblock 50 76 592 minecraft:light[level=14]
fill 56 76 558 56 78 558 minecraft:cobbled_deepslate
setblock 58 76 559 minecraft:calcite
setblock 58 76 560 minecraft:light[level=14]
setblock 58 76 568 minecraft:light[level=14]
setblock 58 76 576 minecraft:light[level=14]
setblock 58 76 584 minecraft:light[level=14]
setblock 58 76 592 minecraft:light[level=14]
setblock 59 76 558 minecraft:calcite
fill 59 76 559 59 79 559 minecraft:cobbled_deepslate
fill 60 76 558 60 79 558 minecraft:cobbled_deepslate
fill 60 76 560 61 76 560 minecraft:cobbled_deepslate
fill 60 76 598 60 79 598 minecraft:cobbled_deepslate
setblock 62 76 560 minecraft:calcite
fill 62 76 561 63 78 561 minecraft:cobbled_deepslate
setblock 63 76 559 minecraft:calcite
fill 63 76 560 63 79 560 minecraft:cobbled_deepslate
setblock 64 76 558 minecraft:calcite
fill 64 76 559 64 79 559 minecraft:cobbled_deepslate
setblock 64 76 597 minecraft:cobbled_deepslate
setblock 64 76 598 minecraft:calcite
fill 65 76 558 65 79 558 minecraft:cobbled_deepslate
setblock 65 76 561 minecraft:cobbled_deepslate
setblock 65 76 597 minecraft:calcite
fill 65 76 598 68 76 598 minecraft:cobbled_deepslate
setblock 66 76 561 minecraft:calcite
setblock 66 76 568 minecraft:light[level=14]
setblock 66 76 576 minecraft:light[level=14]
setblock 66 76 584 minecraft:light[level=14]
setblock 66 76 592 minecraft:light[level=14]
fill 66 76 597 66 77 597 minecraft:cobbled_deepslate
setblock 67 76 560 minecraft:calcite
fill 67 76 561 68 78 561 minecraft:cobbled_deepslate
setblock 68 76 559 minecraft:calcite
fill 68 76 560 68 79 560 minecraft:cobbled_deepslate
setblock 69 76 558 minecraft:calcite
fill 69 76 559 69 79 559 minecraft:cobbled_deepslate
setblock 69 76 598 minecraft:calcite
fill 70 76 558 73 76 558 minecraft:cobbled_deepslate
fill 70 76 598 70 79 598 minecraft:cobbled_deepslate
setblock 73 76 559 minecraft:calcite
setblock 74 76 558 minecraft:calcite
fill 74 76 559 74 79 559 minecraft:cobbled_deepslate
setblock 74 76 560 minecraft:light[level=14]
setblock 74 76 568 minecraft:light[level=14]
setblock 74 76 576 minecraft:light[level=14]
setblock 74 76 584 minecraft:light[level=14]
setblock 74 76 592 minecraft:light[level=14]
setblock 74 76 598 minecraft:calcite
fill 75 76 558 75 79 558 minecraft:cobbled_deepslate
fill 75 76 598 75 79 598 minecraft:cobbled_deepslate
setblock 78 76 558 minecraft:cobbled_deepslate
setblock 78 76 559 minecraft:calcite
fill 78 76 597 78 77 597 minecraft:cobbled_deepslate
setblock 79 76 558 minecraft:calcite
fill 79 76 559 79 78 560 minecraft:cobbled_deepslate
setblock 79 76 598 minecraft:calcite
fill 80 76 558 80 79 558 minecraft:cobbled_deepslate
fill 80 76 560 81 76 560 minecraft:cobbled_deepslate
setblock 80 76 597 minecraft:calcite
fill 80 76 598 80 79 598 minecraft:cobbled_deepslate
fill 81 76 597 81 79 597 minecraft:cobbled_deepslate
setblock 82 76 560 minecraft:calcite
setblock 82 76 568 minecraft:light[level=14]
setblock 82 76 576 minecraft:light[level=14]
setblock 82 76 584 minecraft:light[level=14]
setblock 82 76 592 minecraft:light[level=14]
fill 82 76 596 82 79 596 minecraft:cobbled_deepslate
setblock 83 76 559 minecraft:calcite
fill 83 76 560 83 79 560 minecraft:cobbled_deepslate
setblock 84 76 558 minecraft:calcite
fill 84 76 559 84 79 559 minecraft:cobbled_deepslate
setblock 84 76 598 minecraft:calcite
fill 85 76 558 85 79 558 minecraft:cobbled_deepslate
setblock 85 76 597 minecraft:calcite
fill 85 76 598 85 79 598 minecraft:cobbled_deepslate
setblock 86 76 560 minecraft:cobbled_deepslate
fill 86 76 578 86 76 580 minecraft:cobbled_deepslate
setblock 86 76 581 minecraft:calcite
fill 86 76 582 86 79 582 minecraft:cobbled_deepslate
setblock 86 76 586 minecraft:calcite
fill 86 76 587 86 79 587 minecraft:cobbled_deepslate
setblock 86 76 596 minecraft:calcite
fill 86 76 597 86 79 597 minecraft:cobbled_deepslate
setblock 87 76 560 minecraft:calcite
fill 87 76 561 87 79 561 minecraft:cobbled_deepslate
fill 87 76 576 87 77 576 minecraft:cobbled_deepslate
setblock 87 76 580 minecraft:calcite
fill 87 76 581 87 79 581 minecraft:cobbled_deepslate
setblock 87 76 585 minecraft:calcite
fill 87 76 586 87 79 586 minecraft:cobbled_deepslate
setblock 87 76 590 minecraft:calcite
fill 87 76 591 87 79 591 minecraft:cobbled_deepslate
setblock 87 76 595 minecraft:calcite
fill 87 76 596 87 79 596 minecraft:cobbled_deepslate
setblock 88 76 559 minecraft:calcite
fill 88 76 560 88 79 560 minecraft:cobbled_deepslate
setblock 88 76 564 minecraft:calcite
setblock 88 76 574 minecraft:calcite
fill 88 76 575 88 79 575 minecraft:cobbled_deepslate
setblock 88 76 579 minecraft:calcite
fill 88 76 580 88 79 580 minecraft:cobbled_deepslate
setblock 88 76 584 minecraft:calcite
fill 88 76 585 88 79 585 minecraft:cobbled_deepslate
setblock 88 76 589 minecraft:calcite
fill 88 76 590 88 79 590 minecraft:cobbled_deepslate
setblock 88 76 594 minecraft:calcite
fill 88 76 595 88 79 595 minecraft:cobbled_deepslate
setblock 48 77 558 minecraft:calcite
fill 48 77 559 48 80 559 minecraft:cobbled_deepslate
setblock 48 77 563 minecraft:calcite
fill 48 77 564 48 80 564 minecraft:cobbled_deepslate
fill 48 77 566 48 77 567 minecraft:cobbled_deepslate
setblock 48 77 568 minecraft:calcite
fill 48 77 570 48 79 570 minecraft:cobbled_deepslate
setblock 48 77 573 minecraft:calcite
fill 48 77 574 48 80 574 minecraft:cobbled_deepslate
setblock 48 77 578 minecraft:calcite
fill 48 77 579 48 80 579 minecraft:cobbled_deepslate
setblock 48 77 583 minecraft:calcite
fill 48 77 584 48 80 584 minecraft:cobbled_deepslate
setblock 48 77 588 minecraft:calcite
fill 48 77 589 48 80 589 minecraft:cobbled_deepslate
setblock 48 77 598 minecraft:calcite
fill 49 77 558 49 79 558 minecraft:cobbled_deepslate
setblock 49 77 577 minecraft:calcite
fill 49 77 578 49 80 578 minecraft:cobbled_deepslate
setblock 49 77 582 minecraft:calcite
fill 49 77 583 49 80 583 minecraft:cobbled_deepslate
setblock 49 77 587 minecraft:calcite
fill 50 77 559 50 79 559 minecraft:deepslate
setblock 50 77 581 minecraft:calcite
fill 50 77 582 50 80 582 minecraft:cobbled_deepslate
fill 50 77 584 50 78 584 minecraft:cobbled_deepslate
fill 51 77 560 51 79 560 minecraft:deepslate
fill 52 77 559 52 79 559 minecraft:deepslate
fill 54 77 558 55 79 558 minecraft:cobbled_deepslate
setblock 57 77 559 minecraft:calcite
setblock 58 77 558 minecraft:calcite
fill 58 77 559 58 80 559 minecraft:cobbled_deepslate
fill 59 77 558 59 80 558 minecraft:cobbled_deepslate
fill 59 77 560 60 77 560 minecraft:cobbled_deepslate
fill 59 77 598 59 80 598 minecraft:cobbled_deepslate
setblock 61 77 560 minecraft:calcite
fill 61 77 561 61 80 561 minecraft:cobbled_deepslate
setblock 62 77 559 minecraft:calcite
fill 62 77 560 62 80 560 minecraft:cobbled_deepslate
setblock 63 77 558 minecraft:calcite
fill 63 77 559 63 80 559 minecraft:cobbled_deepslate
setblock 63 77 598 minecraft:calcite
fill 64 77 558 64 80 558 minecraft:cobbled_deepslate
setblock 64 77 597 minecraft:calcite
fill 64 77 598 67 77 598 minecraft:cobbled_deepslate
setblock 65 77 561 minecraft:calcite
fill 65 77 597 65 78 597 minecraft:cobbled_deepslate
setblock 66 77 560 minecraft:calcite
fill 66 77 561 66 80 561 minecraft:cobbled_deepslate
setblock 67 77 559 minecraft:calcite
fill 67 77 560 67 80 560 minecraft:cobbled_deepslate
setblock 68 77 558 minecraft:calcite
fill 68 77 559 68 80 559 minecraft:cobbled_deepslate
setblock 68 77 598 minecraft:calcite
fill 69 77 558 72 77 558 minecraft:cobbled_deepslate
fill 69 77 598 69 80 598 minecraft:cobbled_deepslate
setblock 71 77 560 minecraft:calcite
setblock 72 77 559 minecraft:calcite
fill 72 77 560 72 79 560 minecraft:cobbled_deepslate
setblock 73 77 558 minecraft:calcite
fill 73 77 559 73 80 559 minecraft:cobbled_deepslate
setblock 73 77 598 minecraft:calcite
fill 74 77 558 74 80 558 minecraft:cobbled_deepslate
fill 74 77 598 74 80 598 minecraft:cobbled_deepslate
setblock 76 77 559 minecraft:cobbled_deepslate
setblock 77 77 559 minecraft:calcite
fill 77 77 597 77 78 597 minecraft:cobbled_deepslate
setblock 78 77 558 minecraft:calcite
fill 78 77 559 78 79 560 minecraft:cobbled_deepslate
setblock 78 77 598 minecraft:calcite
fill 79 77 558 79 80 558 minecraft:cobbled_deepslate
setblock 79 77 597 minecraft:calcite
fill 79 77 598 79 80 598 minecraft:cobbled_deepslate
setblock 80 77 560 minecraft:cobbled_deepslate
fill 80 77 569 88 78 569 minecraft:light_blue_stained_glass
fill 80 77 597 80 80 597 minecraft:cobbled_deepslate
setblock 81 77 560 minecraft:calcite
fill 81 77 596 81 80 596 minecraft:cobbled_deepslate
setblock 82 77 559 minecraft:calcite
fill 82 77 560 82 80 560 minecraft:cobbled_deepslate
setblock 83 77 558 minecraft:calcite
fill 83 77 559 83 80 559 minecraft:cobbled_deepslate
setblock 83 77 598 minecraft:calcite
fill 84 77 558 84 80 558 minecraft:cobbled_deepslate
fill 84 77 568 88 80 568 minecraft:light_blue_stained_glass
fill 84 77 570 88 80 570 minecraft:light_blue_stained_glass
setblock 84 77 597 minecraft:calcite
fill 84 77 598 84 80 598 minecraft:cobbled_deepslate
setblock 85 77 581 minecraft:calcite
fill 85 77 582 85 77 585 minecraft:cobbled_deepslate
setblock 85 77 596 minecraft:calcite
fill 85 77 597 85 80 597 minecraft:cobbled_deepslate
setblock 86 77 560 minecraft:calcite
fill 86 77 561 86 78 561 minecraft:cobbled_deepslate
fill 86 77 578 86 77 579 minecraft:cobbled_deepslate
setblock 86 77 580 minecraft:calcite
fill 86 77 581 86 80 581 minecraft:cobbled_deepslate
fill 86 77 583 86 77 584 minecraft:cobbled_deepslate
setblock 86 77 585 minecraft:calcite
fill 86 77 586 86 80 586 minecraft:cobbled_deepslate
fill 86 77 588 86 77 589 minecraft:cobbled_deepslate
setblock 86 77 596 minecraft:cobbled_deepslate
setblock 87 77 559 minecraft:calcite
fill 87 77 560 87 80 560 minecraft:cobbled_deepslate
setblock 87 77 563 minecraft:cobbled_deepslate
setblock 87 77 579 minecraft:calcite
fill 87 77 580 87 80 580 minecraft:cobbled_deepslate
setblock 87 77 584 minecraft:calcite
fill 87 77 585 87 80 585 minecraft:cobbled_deepslate
setblock 87 77 588 minecraft:cobbled_deepslate
setblock 87 77 589 minecraft:calcite
fill 87 77 590 87 80 590 minecraft:cobbled_deepslate
setblock 87 77 594 minecraft:calcite
fill 87 77 595 87 79 595 minecraft:cobbled_deepslate
setblock 88 77 558 minecraft:calcite
fill 88 77 559 88 80 559 minecraft:cobbled_deepslate
setblock 88 77 562 minecraft:cobbled_deepslate
setblock 88 77 563 minecraft:calcite
fill 88 77 564 88 79 565 minecraft:cobbled_deepslate
setblock 88 77 574 minecraft:cobbled_deepslate
setblock 88 77 578 minecraft:calcite
fill 88 77 579 88 80 579 minecraft:cobbled_deepslate
setblock 88 77 583 minecraft:calcite
fill 88 77 584 88 80 584 minecraft:cobbled_deepslate
setblock 88 77 588 minecraft:calcite
fill 88 77 589 88 80 589 minecraft:cobbled_deepslate
setblock 88 77 593 minecraft:calcite
fill 88 77 594 88 80 594 minecraft:cobbled_deepslate
setblock 88 77 598 minecraft:calcite
fill 48 78 558 48 80 558 minecraft:cobbled_deepslate
setblock 48 78 562 minecraft:calcite
fill 48 78 563 48 81 563 minecraft:cobbled_deepslate
setblock 48 78 566 minecraft:cobbled_deepslate
setblock 48 78 567 minecraft:calcite
fill 48 78 568 48 80 569 minecraft:cobbled_deepslate
setblock 48 78 572 minecraft:calcite
fill 48 78 573 48 81 573 minecraft:cobbled_deepslate
setblock 48 78 577 minecraft:calcite
fill 48 78 578 48 81 578 minecraft:cobbled_deepslate
setblock 48 78 582 minecraft:calcite
fill 48 78 583 48 81 583 minecraft:cobbled_deepslate
setblock 48 78 587 minecraft:calcite
fill 48 78 588 49 80 588 minecraft:cobbled_deepslate
setblock 48 78 592 minecraft:calcite
setblock 48 78 598 minecraft:cobbled_deepslate
setblock 49 78 576 minecraft:calcite
fill 49 78 577 49 80 577 minecraft:cobbled_deepslate
setblock 49 78 581 minecraft:calcite
fill 49 78 582 49 81 582 minecraft:cobbled_deepslate
setblock 49 78 586 minecraft:calcite
fill 49 78 587 49 81 587 minecraft:cobbled_deepslate
fill 50 78 560 50 79 560 minecraft:deepslate
setblock 50 78 580 minecraft:calcite
fill 50 78 581 50 79 581 minecraft:cobbled_deepslate
fill 52 78 558 52 79 558 minecraft:deepslate
fill 52 78 560 52 79 560 minecraft:deepslate
fill 53 78 558 53 79 558 minecraft:cobbled_deepslate
setblock 56 78 559 minecraft:calcite
setblock 57 78 558 minecraft:calcite
fill 57 78 559 57 81 559 minecraft:cobbled_deepslate
fill 58 78 558 58 81 558 minecraft:cobbled_deepslate
fill 58 78 560 59 78 560 minecraft:cobbled_deepslate
setblock 60 78 560 minecraft:calcite
fill 60 78 561 60 81 561 minecraft:cobbled_deepslate
setblock 61 78 559 minecraft:calcite
fill 61 78 560 61 81 560 minecraft:cobbled_deepslate
setblock 62 78 558 minecraft:calcite
fill 62 78 559 62 81 559 minecraft:cobbled_deepslate
setblock 62 78 562 minecraft:cobbled_deepslate
setblock 62 78 598 minecraft:calcite
fill 63 78 558 63 81 558 minecraft:cobbled_deepslate
setblock 63 78 562 minecraft:calcite
setblock 63 78 597 minecraft:calcite
fill 63 78 598 66 78 598 minecraft:cobbled_deepslate
setblock 64 78 560 minecraft:cobbled_deepslate
setblock 64 78 561 minecraft:calcite
fill 64 78 562 65 79 562 minecraft:cobbled_deepslate
fill 64 78 597 64 79 597 minecraft:cobbled_deepslate
setblock 65 78 560 minecraft:calcite
fill 65 78 561 65 81 561 minecraft:cobbled_deepslate
setblock 66 78 559 minecraft:calcite
fill 66 78 560 66 81 560 minecraft:cobbled_deepslate
setblock 67 78 558 minecraft:calcite
fill 67 78 559 67 81 559 minecraft:cobbled_deepslate
setblock 67 78 598 minecraft:calcite
fill 68 78 558 71 78 558 minecraft:cobbled_deepslate
fill 68 78 598 68 81 598 minecraft:cobbled_deepslate
setblock 70 78 560 minecraft:calcite
setblock 71 78 559 minecraft:calcite
fill 71 78 560 71 79 560 minecraft:cobbled_deepslate
setblock 72 78 558 minecraft:calcite
fill 72 78 559 72 81 559 minecraft:cobbled_deepslate
setblock 72 78 598 minecraft:calcite
fill 73 78 558 73 81 558 minecraft:cobbled_deepslate
fill 73 78 598 73 81 598 minecraft:cobbled_deepslate
setblock 76 78 559 minecraft:calcite
fill 76 78 560 77 80 560 minecraft:cobbled_deepslate
setblock 77 78 558 minecraft:calcite
fill 77 78 559 77 81 559 minecraft:cobbled_deepslate
setblock 77 78 598 minecraft:calcite
fill 78 78 558 78 81 558 minecraft:cobbled_deepslate
setblock 78 78 597 minecraft:calcite
fill 78 78 598 78 81 598 minecraft:cobbled_deepslate
fill 79 78 597 79 81 597 minecraft:cobbled_deepslate
setblock 80 78 560 minecraft:calcite
setblock 81 78 559 minecraft:calcite
fill 81 78 560 81 81 560 minecraft:cobbled_deepslate
setblock 82 78 558 minecraft:calcite
fill 82 78 559 82 81 559 minecraft:cobbled_deepslate
fill 82 78 568 83 79 568 minecraft:light_blue_stained_glass
fill 82 78 570 83 79 570 minecraft:light_blue_stained_glass
setblock 82 78 598 minecraft:calcite
fill 83 78 558 83 81 558 minecraft:cobbled_deepslate
setblock 83 78 597 minecraft:calcite
fill 83 78 598 83 81 598 minecraft:cobbled_deepslate
setblock 84 78 560 minecraft:cobbled_deepslate
setblock 84 78 596 minecraft:calcite
fill 84 78 597 84 81 597 minecraft:cobbled_deepslate
setblock 85 78 560 minecraft:calcite
fill 85 78 567 88 79 567 minecraft:light_blue_stained_glass
fill 85 78 571 88 80 571 minecraft:light_blue_stained_glass
fill 85 78 581 85 78 584 minecraft:cobbled_deepslate
setblock 85 78 585 minecraft:calcite
fill 85 78 586 85 80 587 minecraft:cobbled_deepslate
setblock 85 78 596 minecraft:cobbled_deepslate
setblock 86 78 559 minecraft:calcite
setblock 86 78 560 minecraft:cobbled_deepslate
setblock 86 78 578 minecraft:cobbled_deepslate
setblock 86 78 579 minecraft:calcite
fill 86 78 580 86 81 580 minecraft:cobbled_deepslate
setblock 86 78 583 minecraft:cobbled_deepslate
setblock 86 78 584 minecraft:calcite
fill 86 78 585 86 81 585 minecraft:cobbled_deepslate
setblock 86 78 588 minecraft:cobbled_deepslate
setblock 86 78 589 minecraft:calcite
fill 86 78 590 86 81 590 minecraft:cobbled_deepslate
setblock 87 78 558 minecraft:calcite
fill 87 78 559 87 80 559 minecraft:cobbled_deepslate
setblock 87 78 563 minecraft:calcite
fill 87 78 564 87 80 564 minecraft:cobbled_deepslate
setblock 87 78 578 minecraft:calcite
fill 87 78 579 87 81 579 minecraft:cobbled_deepslate
setblock 87 78 583 minecraft:calcite
fill 87 78 584 87 81 584 minecraft:cobbled_deepslate
setblock 87 78 588 minecraft:calcite
fill 87 78 589 87 81 589 minecraft:cobbled_deepslate
setblock 87 78 593 minecraft:calcite
fill 87 78 594 87 79 594 minecraft:cobbled_deepslate
setblock 87 78 598 minecraft:calcite
fill 88 78 558 88 80 558 minecraft:cobbled_deepslate
setblock 88 78 562 minecraft:calcite
fill 88 78 563 88 81 563 minecraft:cobbled_deepslate
setblock 88 78 566 minecraft:cobbled_deepslate
setblock 88 78 577 minecraft:calcite
fill 88 78 578 88 81 578 minecraft:cobbled_deepslate
setblock 88 78 582 minecraft:calcite
fill 88 78 583 88 81 583 minecraft:cobbled_deepslate
setblock 88 78 587 minecraft:calcite
fill 88 78 588 88 81 588 minecraft:cobbled_deepslate
setblock 88 78 592 minecraft:calcite
fill 88 78 593 88 81 593 minecraft:cobbled_deepslate
setblock 88 78 597 minecraft:calcite
fill 88 78 598 88 80 598 minecraft:cobbled_deepslate
setblock 48 79 561 minecraft:calcite
fill 48 79 562 49 79 562 minecraft:cobbled_deepslate
setblock 48 79 566 minecraft:calcite
fill 48 79 567 48 82 567 minecraft:cobbled_deepslate
setblock 48 79 571 minecraft:calcite
fill 48 79 572 48 82 572 minecraft:cobbled_deepslate
setblock 48 79 576 minecraft:calcite
fill 48 79 577 48 82 577 minecraft:cobbled_deepslate
setblock 48 79 581 minecraft:calcite
fill 48 79 582 48 82 582 minecraft:cobbled_deepslate
setblock 48 79 586 minecraft:calcite
fill 48 79 587 48 82 587 minecraft:cobbled_deepslate
setblock 48 79 591 minecraft:calcite
fill 49 79 563 49 80 563 minecraft:cobbled_deepslate
setblock 49 79 576 minecraft:cobbled_deepslate
setblock 49 79 580 minecraft:calcite
fill 49 79 581 49 82 581 minecraft:cobbled_deepslate
setblock 49 79 585 minecraft:calcite
fill 49 79 586 49 82 586 minecraft:cobbled_deepslate
setblock 50 79 558 minecraft:cobbled_deepslate
setblock 50 79 580 minecraft:cobbled_deepslate
setblock 50 79 584 minecraft:calcite
setblock 51 79 558 minecraft:deepslate
setblock 56 79 558 minecraft:calcite
fill 56 79 559 56 82 559 minecraft:cobbled_deepslate
fill 57 79 558 57 82 558 minecraft:cobbled_deepslate
fill 57 79 560 58 79 560 minecraft:cobbled_deepslate
setblock 59 79 560 minecraft:calcite
fill 59 79 561 59 82 561 minecraft:cobbled_deepslate
setblock 60 79 559 minecraft:calcite
fill 60 79 560 60 82 560 minecraft:cobbled_deepslate
setblock 61 79 558 minecraft:calcite
fill 61 79 559 61 82 559 minecraft:cobbled_deepslate
setblock 61 79 562 minecraft:cobbled_deepslate
setblock 61 79 598 minecraft:calcite
fill 62 79 558 62 82 558 minecraft:cobbled_deepslate
setblock 62 79 561 minecraft:cobbled_deepslate
setblock 62 79 562 minecraft:calcite
fill 62 79 598 65 79 598 minecraft:cobbled_deepslate
setblock 63 79 561 minecraft:calcite
fill 63 79 562 63 81 562 minecraft:cobbled_deepslate
setblock 64 79 560 minecraft:calcite
fill 64 79 561 64 82 561 minecraft:cobbled_deepslate
setblock 65 79 559 minecraft:calcite
fill 65 79 560 65 82 560 minecraft:cobbled_deepslate
setblock 66 79 558 minecraft:calcite
fill 66 79 559 66 82 559 minecraft:cobbled_deepslate
setblock 66 79 598 minecraft:calcite
fill 67 79 558 70 79 558 minecraft:cobbled_deepslate
setblock 67 79 561 minecraft:cobbled_deepslate
fill 67 79 598 67 81 598 minecraft:cobbled_deepslate
setblock 68 79 561 minecraft:calcite
setblock 69 79 560 minecraft:calcite
setblock 70 79 559 minecraft:calcite
fill 70 79 560 70 80 560 minecraft:cobbled_deepslate
setblock 71 79 558 minecraft:calcite
fill 71 79 559 71 81 559 minecraft:cobbled_deepslate
setblock 71 79 598 minecraft:calcite
fill 72 79 558 72 82 558 minecraft:cobbled_deepslate
fill 72 79 598 72 81 598 minecraft:cobbled_deepslate
setblock 75 79 559 minecraft:calcite
setblock 75 79 560 minecraft:cobbled_deepslate
setblock 76 79 558 minecraft:calcite
fill 76 79 559 76 82 559 minecraft:cobbled_deepslate
setblock 76 79 598 minecraft:calcite
fill 77 79 558 77 82 558 minecraft:cobbled_deepslate
setblock 77 79 597 minecraft:calcite
fill 77 79 598 77 82 598 minecraft:cobbled_deepslate
fill 78 79 597 78 82 597 minecraft:cobbled_deepslate
setblock 79 79 559 minecraft:cobbled_deepslate
setblock 79 79 560 minecraft:calcite
setblock 80 79 559 minecraft:calcite
fill 80 79 560 80 82 560 minecraft:cobbled_deepslate
fill 80 79 596 80 81 596 minecraft:cobbled_deepslate
setblock 81 79 558 minecraft:calcite
fill 81 79 559 81 82 559 minecraft:cobbled_deepslate
setblock 81 79 598 minecraft:calcite
fill 82 79 558 82 82 558 minecraft:cobbled_deepslate
fill 82 79 569 88 79 569 minecraft:light_blue_stained_glass
setblock 82 79 597 minecraft:calcite
fill 82 79 598 82 82 598 minecraft:cobbled_deepslate
setblock 83 79 596 minecraft:calcite
fill 83 79 597 83 82 597 minecraft:cobbled_deepslate
setblock 84 79 560 minecraft:calcite
setblock 84 79 567 minecraft:light_blue_stained_glass
setblock 84 79 571 minecraft:light_blue_stained_glass
setblock 84 79 596 minecraft:cobbled_deepslate
setblock 85 79 559 minecraft:calcite
fill 85 79 560 85 80 560 minecraft:cobbled_deepslate
fill 85 79 581 85 79 583 minecraft:cobbled_deepslate
setblock 85 79 584 minecraft:calcite
fill 85 79 585 85 82 585 minecraft:cobbled_deepslate
setblock 85 79 588 minecraft:cobbled_deepslate
setblock 86 79 558 minecraft:calcite
fill 86 79 559 86 80 559 minecraft:cobbled_deepslate
fill 86 79 579 86 80 579 minecraft:cobbled_deepslate
setblock 86 79 583 minecraft:calcite
fill 86 79 584 86 82 584 minecraft:cobbled_deepslate
setblock 86 79 588 minecraft:calcite
fill 86 79 589 86 82 589 minecraft:cobbled_deepslate
fill 86 79 591 86 80 591 minecraft:cobbled_deepslate
setblock 86 79 598 minecraft:calcite
fill 87 79 558 87 81 558 minecraft:cobbled_deepslate
setblock 87 79 562 minecraft:calcite
fill 87 79 563 87 80 563 minecraft:cobbled_deepslate
setblock 87 79 577 minecraft:calcite
fill 87 79 578 87 80 578 minecraft:cobbled_deepslate
setblock 87 79 582 minecraft:calcite
fill 87 79 583 87 82 583 minecraft:cobbled_deepslate
setblock 87 79 587 minecraft:calcite
fill 87 79 588 87 82 588 minecraft:cobbled_deepslate
setblock 87 79 592 minecraft:calcite
fill 87 79 593 87 80 593 minecraft:cobbled_deepslate
setblock 87 79 597 minecraft:calcite
fill 87 79 598 87 81 598 minecraft:cobbled_deepslate
setblock 88 79 561 minecraft:calcite
fill 88 79 562 88 82 562 minecraft:cobbled_deepslate
setblock 88 79 566 minecraft:calcite
setblock 88 79 576 minecraft:calcite
fill 88 79 577 88 81 577 minecraft:cobbled_deepslate
setblock 88 79 581 minecraft:calcite
fill 88 79 582 88 82 582 minecraft:cobbled_deepslate
setblock 88 79 586 minecraft:calcite
fill 88 79 587 88 82 587 minecraft:cobbled_deepslate
setblock 88 79 591 minecraft:calcite
fill 88 79 592 88 82 592 minecraft:cobbled_deepslate
setblock 88 79 596 minecraft:calcite
fill 88 79 597 88 80 597 minecraft:cobbled_deepslate
setblock 48 80 560 minecraft:calcite
fill 48 80 561 48 82 562 minecraft:cobbled_deepslate
setblock 48 80 565 minecraft:calcite
fill 48 80 566 48 83 566 minecraft:cobbled_deepslate
setblock 48 80 570 minecraft:calcite
fill 48 80 571 48 83 571 minecraft:cobbled_deepslate
setblock 48 80 575 minecraft:calcite
fill 48 80 576 48 82 576 minecraft:cobbled_deepslate
setblock 48 80 580 minecraft:calcite
fill 48 80 581 48 83 581 minecraft:cobbled_deepslate
setblock 48 80 585 minecraft:calcite
fill 48 80 586 48 83 586 minecraft:cobbled_deepslate
setblock 48 80 590 minecraft:calcite
fill 48 80 591 48 81 591 minecraft:cobbled_deepslate
setblock 49 80 564 minecraft:calcite
setblock 49 80 579 minecraft:calcite
fill 49 80 580 49 82 580 minecraft:cobbled_deepslate
setblock 49 80 584 minecraft:calcite
fill 49 80 585 49 83 585 minecraft:cobbled_deepslate
setblock 50 80 583 minecraft:calcite
setblock 54 80 558 minecraft:cobbled_deepslate
setblock 55 80 558 minecraft:calcite
fill 55 80 559 55 81 559 minecraft:cobbled_deepslate
fill 56 80 558 56 83 558 minecraft:cobbled_deepslate
setblock 57 80 560 minecraft:cobbled_deepslate
setblock 58 80 560 minecraft:calcite
fill 58 80 561 58 82 561 minecraft:cobbled_deepslate
setblock 58 80 598 minecraft:cobbled_deepslate
setblock 59 80 559 minecraft:calcite
fill 59 80 560 59 83 560 minecraft:cobbled_deepslate
setblock 60 80 558 minecraft:calcite
fill 60 80 559 60 83 559 minecraft:cobbled_deepslate
setblock 60 80 562 minecraft:cobbled_deepslate
setblock 60 80 598 minecraft:calcite
fill 61 80 558 61 83 558 minecraft:cobbled_deepslate
setblock 61 80 562 minecraft:calcite
fill 61 80 598 64 80 598 minecraft:cobbled_deepslate
setblock 62 80 561 minecraft:calcite
fill 62 80 562 62 81 562 minecraft:cobbled_deepslate
setblock 63 80 560 minecraft:calcite
fill 63 80 561 63 83 561 minecraft:cobbled_deepslate
setblock 64 80 559 minecraft:calcite
fill 64 80 560 64 83 560 minecraft:cobbled_deepslate
setblock 64 80 562 minecraft:cobbled_deepslate
setblock 65 80 558 minecraft:calcite
fill 65 80 559 65 83 559 minecraft:cobbled_deepslate
setblock 65 80 598 minecraft:calcite
fill 66 80 558 69 80 558 minecraft:cobbled_deepslate
fill 66 80 598 66 82 598 minecraft:cobbled_deepslate
setblock 67 80 561 minecraft:calcite
setblock 68 80 560 minecraft:calcite
setblock 69 80 559 minecraft:calcite
fill 69 80 560 69 81 560 minecraft:cobbled_deepslate
setblock 70 80 558 minecraft:calcite
fill 70 80 559 70 82 559 minecraft:cobbled_deepslate
setblock 70 80 598 minecraft:calcite
fill 71 80 558 71 83 558 minecraft:cobbled_deepslate
setblock 71 80 598 minecraft:cobbled_deepslate
setblock 74 80 559 minecraft:calcite
setblock 75 80 558 minecraft:calcite
fill 75 80 559 75 82 559 minecraft:cobbled_deepslate
setblock 75 80 598 minecraft:calcite
fill 76 80 558 76 83 558 minecraft:cobbled_deepslate
fill 76 80 598 76 83 598 minecraft:cobbled_deepslate
fill 77 80 597 77 83 597 minecraft:cobbled_deepslate
setblock 78 80 559 minecraft:cobbled_deepslate
setblock 78 80 560 minecraft:calcite
setblock 79 80 559 minecraft:calcite
fill 79 80 560 79 82 560 minecraft:cobbled_deepslate
setblock 80 80 558 minecraft:calcite
fill 80 80 559 80 83 559 minecraft:cobbled_deepslate
setblock 80 80 598 minecraft:calcite
fill 81 80 558 81 83 558 minecraft:cobbled_deepslate
setblock 81 80 597 minecraft:calcite
fill 81 80 598 81 83 598 minecraft:cobbled_deepslate
setblock 82 80 596 minecraft:calcite
fill 82 80 597 82 83 597 minecraft:cobbled_deepslate
setblock 83 80 560 minecraft:calcite
fill 83 80 568 83 80 570 minecraft:light_blue_stained_glass
setblock 83 80 596 minecraft:cobbled_deepslate
setblock 84 80 559 minecraft:calcite
setblock 84 80 560 minecraft:cobbled_deepslate
fill 84 80 569 88 81 569 minecraft:light_blue_stained_glass
setblock 85 80 558 minecraft:calcite
fill 85 80 559 85 81 559 minecraft:cobbled_deepslate
fill 85 80 567 87 80 567 minecraft:light_blue_stained_glass
setblock 85 80 582 minecraft:cobbled_deepslate
setblock 85 80 583 minecraft:calcite
fill 85 80 584 85 82 584 minecraft:cobbled_deepslate
setblock 85 80 588 minecraft:calcite
setblock 85 80 598 minecraft:calcite
fill 86 80 558 86 82 558 minecraft:cobbled_deepslate
setblock 86 80 582 minecraft:calcite
fill 86 80 583 86 83 583 minecraft:cobbled_deepslate
setblock 86 80 587 minecraft:calcite
fill 86 80 588 86 83 588 minecraft:cobbled_deepslate
setblock 86 80 597 minecraft:calcite
fill 86 80 598 86 82 598 minecraft:cobbled_deepslate
setblock 87 80 561 minecraft:calcite
setblock 87 80 562 minecraft:cobbled_deepslate
setblock 87 80 581 minecraft:calcite
fill 87 80 582 87 83 582 minecraft:cobbled_deepslate
setblock 87 80 586 minecraft:calcite
fill 87 80 587 87 83 587 minecraft:cobbled_deepslate
setblock 87 80 591 minecraft:calcite
fill 87 80 592 87 82 592 minecraft:cobbled_deepslate
setblock 88 80 560 minecraft:calcite
fill 88 80 561 88 82 561 minecraft:cobbled_deepslate
setblock 88 80 564 minecraft:cobbled_deepslate
setblock 88 80 565 minecraft:calcite
fill 88 80 566 88 81 567 minecraft:cobbled_deepslate
setblock 88 80 576 minecraft:cobbled_deepslate
setblock 88 80 580 minecraft:calcite
fill 88 80 581 88 83 581 minecraft:cobbled_deepslate
setblock 88 80 585 minecraft:calcite
fill 88 80 586 88 83 586 minecraft:cobbled_deepslate
setblock 88 80 590 minecraft:calcite
fill 88 80 591 88 83 591 minecraft:cobbled_deepslate
setblock 88 80 595 minecraft:calcite
setblock 88 80 596 minecraft:cobbled_deepslate
setblock 48 81 559 minecraft:calcite
setblock 48 81 560 minecraft:cobbled_deepslate
setblock 48 81 564 minecraft:calcite
fill 48 81 565 49 81 565 minecraft:cobbled_deepslate
setblock 48 81 568 minecraft:cobbled_deepslate
setblock 48 81 569 minecraft:calcite
fill 48 81 570 48 84 570 minecraft:cobbled_deepslate
setblock 48 81 574 minecraft:calcite
fill 48 81 575 48 82 575 minecraft:cobbled_deepslate
setblock 48 81 579 minecraft:calcite
fill 48 81 580 48 84 580 minecraft:cobbled_deepslate
setblock 48 81 584 minecraft:calcite
fill 48 81 585 48 84 585 minecraft:cobbled_deepslate
setblock 48 81 588 minecraft:cobbled_deepslate
setblock 48 81 589 minecraft:calcite
fill 48 81 590 48 83 590 minecraft:cobbled_deepslate
setblock 49 81 564 minecraft:cobbled_deepslate
setblock 49 81 579 minecraft:cobbled_deepslate
setblock 49 81 583 minecraft:calcite
fill 49 81 584 49 83 584 minecraft:cobbled_deepslate
setblock 54 81 558 minecraft:calcite
fill 55 81 558 55 84 558 minecraft:cobbled_deepslate
setblock 57 81 560 minecraft:calcite
setblock 58 81 559 minecraft:calcite
fill 58 81 560 58 84 560 minecraft:cobbled_deepslate
setblock 59 81 558 minecraft:calcite
fill 59 81 559 59 84 559 minecraft:cobbled_deepslate
setblock 59 81 598 minecraft:calcite
fill 60 81 558 60 84 558 minecraft:cobbled_deepslate
setblock 60 81 562 minecraft:calcite
fill 60 81 598 63 81 598 minecraft:cobbled_deepslate
setblock 61 81 561 minecraft:calcite
setblock 61 81 562 minecraft:cobbled_deepslate
setblock 62 81 560 minecraft:calcite
fill 62 81 561 62 83 561 minecraft:cobbled_deepslate
setblock 63 81 559 minecraft:calcite
fill 63 81 560 63 84 560 minecraft:cobbled_deepslate
setblock 64 81 558 minecraft:calcite
fill 64 81 559 64 84 559 minecraft:cobbled_deepslate
setblock 64 81 598 minecraft:calcite
fill 65 81 558 68 81 558 minecraft:cobbled_deepslate
fill 65 81 598 65 82 598 minecraft:cobbled_deepslate
setblock 66 81 561 minecraft:calcite
setblock 67 81 560 minecraft:calcite
setblock 68 81 559 minecraft:calcite
setblock 68 81 560 minecraft:cobbled_deepslate
setblock 69 81 558 minecraft:calcite
fill 69 81 559 69 82 559 minecraft:cobbled_deepslate
setblock 69 81 598 minecraft:calcite
fill 70 81 558 70 83 558 minecraft:cobbled_deepslate
setblock 73 81 559 minecraft:calcite
setblock 74 81 558 minecraft:calcite
fill 74 81 559 74 82 559 minecraft:cobbled_deepslate
setblock 74 81 598 minecraft:calcite
fill 75 81 558 75 84 558 minecraft:cobbled_deepslate
fill 75 81 598 75 84 598 minecraft:cobbled_deepslate
setblock 77 81 560 minecraft:calcite
setblock 78 81 559 minecraft:calcite
fill 78 81 560 78 82 560 minecraft:cobbled_deepslate
setblock 79 81 558 minecraft:calcite
fill 79 81 559 79 84 559 minecraft:cobbled_deepslate
setblock 79 81 598 minecraft:calcite
fill 80 81 558 80 84 558 minecraft:cobbled_deepslate
setblock 80 81 597 minecraft:calcite
fill 80 81 598 80 84 598 minecraft:cobbled_deepslate
setblock 81 81 596 minecraft:calcite
fill 81 81 597 81 84 597 minecraft:cobbled_deepslate
setblock 82 81 560 minecraft:calcite
setblock 82 81 596 minecraft:cobbled_deepslate
setblock 83 81 559 minecraft:calcite
setblock 83 81 560 minecraft:cobbled_deepslate
setblock 84 81 558 minecraft:calcite
fill 84 81 559 84 82 559 minecraft:cobbled_deepslate
setblock 84 81 598 minecraft:calcite
fill 85 81 558 85 82 558 minecraft:cobbled_deepslate
fill 85 81 568 88 81 568 minecraft:light_blue_stained_glass
fill 85 81 570 88 81 570 minecraft:light_blue_stained_glass
setblock 85 81 582 minecraft:calcite
setblock 85 81 583 minecraft:cobbled_deepslate
setblock 85 81 586 minecraft:cobbled_deepslate
setblock 85 81 587 minecraft:calcite
fill 85 81 588 85 82 588 minecraft:cobbled_deepslate
setblock 85 81 597 minecraft:calcite
fill 85 81 598 85 83 598 minecraft:cobbled_deepslate
fill 86 81 567 87 81 567 minecraft:light_blue_stained_glass
fill 86 81 571 88 81 571 minecraft:light_blue_stained_glass
setblock 86 81 581 minecraft:calcite
fill 86 81 582 86 82 582 minecraft:cobbled_deepslate
setblock 86 81 586 minecraft:calcite
fill 86 81 587 86 84 587 minecraft:cobbled_deepslate
setblock 87 81 580 minecraft:calcite
fill 87 81 581 87 83 581 minecraft:cobbled_deepslate
setblock 87 81 585 minecraft:calcite
fill 87 81 586 87 84 586 minecraft:cobbled_deepslate
setblock 87 81 590 minecraft:calcite
fill 87 81 591 87 83 591 minecraft:cobbled_deepslate
setblock 88 81 559 minecraft:calcite
setblock 88 81 560 minecraft:cobbled_deepslate
setblock 88 81 564 minecraft:calcite
fill 88 81 565 88 82 565 minecraft:cobbled_deepslate
setblock 88 81 579 minecraft:calcite
fill 88 81 580 88 84 580 minecraft:cobbled_deepslate
setblock 88 81 584 minecraft:calcite
fill 88 81 585 88 84 585 minecraft:cobbled_deepslate
setblock 88 81 589 minecraft:calcite
fill 88 81 590 88 84 590 minecraft:cobbled_deepslate
setblock 88 81 594 minecraft:calcite
setblock 88 81 595 minecraft:cobbled_deepslate
setblock 48 82 563 minecraft:calcite
fill 48 82 564 48 84 565 minecraft:cobbled_deepslate
setblock 48 82 568 minecraft:calcite
fill 48 82 569 48 85 569 minecraft:cobbled_deepslate
setblock 48 82 578 minecraft:calcite
fill 48 82 579 48 83 579 minecraft:cobbled_deepslate
setblock 48 82 583 minecraft:calcite
fill 48 82 584 48 85 584 minecraft:cobbled_deepslate
setblock 48 82 588 minecraft:calcite
fill 48 82 589 48 84 589 minecraft:cobbled_deepslate
setblock 49 82 582 minecraft:calcite
fill 49 82 583 49 83 583 minecraft:cobbled_deepslate
setblock 49 82 587 minecraft:calcite
setblock 54 82 558 minecraft:cobbled_deepslate
fill 55 82 576 55 84 576 minecraft:light_blue_stained_glass
setblock 57 82 559 minecraft:calcite
fill 57 82 560 57 83 560 minecraft:cobbled_deepslate
setblock 58 82 558 minecraft:calcite
fill 58 82 559 58 85 559 minecraft:cobbled_deepslate
fill 59 82 558 59 85 558 minecraft:cobbled_deepslate
fill 59 82 598 62 82 598 minecraft:cobbled_deepslate
setblock 60 82 561 minecraft:calcite
setblock 61 82 560 minecraft:calcite
fill 61 82 561 61 83 561 minecraft:cobbled_deepslate
setblock 62 82 559 minecraft:calcite
fill 62 82 560 62 84 560 minecraft:cobbled_deepslate
setblock 63 82 558 minecraft:calcite
fill 63 82 559 63 85 559 minecraft:cobbled_deepslate
setblock 63 82 598 minecraft:calcite
fill 64 82 558 67 82 558 minecraft:cobbled_deepslate
fill 64 82 598 64 83 598 minecraft:cobbled_deepslate
setblock 65 82 561 minecraft:calcite
setblock 66 82 560 minecraft:calcite
setblock 67 82 559 minecraft:calcite
setblock 67 82 560 minecraft:cobbled_deepslate
setblock 68 82 558 minecraft:calcite
setblock 68 82 559 minecraft:cobbled_deepslate
fill 69 82 558 69 83 558 minecraft:cobbled_deepslate
setblock 73 82 558 minecraft:calcite
setblock 73 82 559 minecraft:cobbled_deepslate
setblock 73 82 598 minecraft:calcite
fill 74 82 558 74 84 558 minecraft:cobbled_deepslate
fill 74 82 598 74 85 598 minecraft:cobbled_deepslate
setblock 77 82 559 minecraft:calcite
setblock 78 82 558 minecraft:calcite
fill 78 82 559 78 84 559 minecraft:cobbled_deepslate
setblock 78 82 598 minecraft:calcite
fill 79 82 558 79 85 558 minecraft:cobbled_deepslate
setblock 79 82 597 minecraft:calcite
fill 79 82 598 79 85 598 minecraft:cobbled_deepslate
fill 80 82 597 80 85 597 minecraft:cobbled_deepslate
setblock 81 82 560 minecraft:calcite
setblock 82 82 559 minecraft:calcite
setblock 83 82 558 minecraft:calcite
setblock 83 82 559 minecraft:cobbled_deepslate
setblock 83 82 598 minecraft:calcite
fill 84 82 558 84 83 558 minecraft:cobbled_deepslate
setblock 84 82 597 minecraft:calcite
fill 84 82 598 84 84 598 minecraft:cobbled_deepslate
setblock 85 82 586 minecraft:calcite
setblock 85 82 587 minecraft:cobbled_deepslate
fill 86 82 568 88 82 570 minecraft:light_blue_stained_glass
setblock 86 82 585 minecraft:calcite
fill 86 82 586 86 84 586 minecraft:cobbled_deepslate
setblock 86 82 590 minecraft:calcite
setblock 87 82 580 minecraft:cobbled_deepslate
setblock 87 82 584 minecraft:calcite
fill 87 82 585 87 85 585 minecraft:cobbled_deepslate
setblock 87 82 589 minecraft:calcite
fill 87 82 590 87 85 590 minecraft:cobbled_deepslate
setblock 88 82 563 minecraft:calcite
setblock 88 82 564 minecraft:cobbled_deepslate
setblock 88 82 566 minecraft:cobbled_deepslate
setblock 88 82 578 minecraft:calcite
fill 88 82 579 88 83 579 minecraft:cobbled_deepslate
setblock 88 82 583 minecraft:calcite
fill 88 82 584 88 85 584 minecraft:cobbled_deepslate
setblock 88 82 588 minecraft:calcite
fill 88 82 589 88 85 589 minecraft:cobbled_deepslate
setblock 88 82 593 minecraft:calcite
setblock 48 83 562 minecraft:calcite
fill 48 83 563 48 84 563 minecraft:cobbled_deepslate
setblock 48 83 567 minecraft:calcite
fill 48 83 568 48 86 568 minecraft:cobbled_deepslate
setblock 48 83 578 minecraft:cobbled_deepslate
setblock 48 83 582 minecraft:calcite
fill 48 83 583 48 85 583 minecraft:cobbled_deepslate
setblock 48 83 587 minecraft:calcite
fill 48 83 588 48 85 588 minecraft:cobbled_deepslate
setblock 49 83 586 minecraft:calcite
fill 49 83 587 53 84 587 minecraft:light_blue_stained_glass
fill 50 83 585 53 84 586 minecraft:light_blue_stained_glass
fill 54 83 586 55 83 586 minecraft:light_blue_stained_glass
setblock 56 83 559 minecraft:calcite
setblock 57 83 558 minecraft:calcite
fill 57 83 559 57 86 559 minecraft:cobbled_deepslate
fill 58 83 558 58 86 558 minecraft:cobbled_deepslate
setblock 59 83 561 minecraft:calcite
fill 59 83 598 61 83 598 minecraft:cobbled_deepslate
setblock 60 83 560 minecraft:calcite
setblock 60 83 561 minecraft:cobbled_deepslate
setblock 61 83 559 minecraft:calcite
fill 61 83 560 61 85 560 minecraft:cobbled_deepslate
setblock 62 83 558 minecraft:calcite
fill 62 83 559 62 86 559 minecraft:cobbled_deepslate
setblock 62 83 598 minecraft:calcite
fill 63 83 558 66 83 558 minecraft:cobbled_deepslate
setblock 63 83 598 minecraft:cobbled_deepslate
setblock 65 83 560 minecraft:calcite
setblock 66 83 559 minecraft:calcite
setblock 67 83 558 minecraft:calcite
setblock 67 83 559 minecraft:cobbled_deepslate
fill 68 83 558 68 84 558 minecraft:cobbled_deepslate
setblock 72 83 558 minecraft:calcite
fill 73 83 558 73 84 558 minecraft:cobbled_deepslate
setblock 76 83 559 minecraft:calcite
setblock 77 83 558 minecraft:calcite
setblock 77 83 559 minecraft:cobbled_deepslate
setblock 77 83 598 minecraft:calcite
fill 78 83 558 78 86 558 minecraft:cobbled_deepslate
setblock 78 83 597 minecraft:calcite
fill 78 83 598 78 86 598 minecraft:cobbled_deepslate
fill 79 83 597 79 86 597 minecraft:cobbled_deepslate
setblock 81 83 559 minecraft:calcite
setblock 82 83 558 minecraft:calcite
setblock 82 83 559 minecraft:cobbled_deepslate
setblock 82 83 598 minecraft:calcite
setblock 83 83 558 minecraft:cobbled_deepslate
setblock 83 83 597 minecraft:calcite
fill 83 83 598 83 85 598 minecraft:cobbled_deepslate
setblock 86 83 584 minecraft:calcite
fill 86 83 585 86 84 585 minecraft:cobbled_deepslate
setblock 86 83 589 minecraft:calcite
setblock 87 83 583 minecraft:calcite
fill 87 83 584 87 85 584 minecraft:cobbled_deepslate
setblock 87 83 588 minecraft:calcite
fill 87 83 589 87 86 589 minecraft:cobbled_deepslate
setblock 88 83 582 minecraft:calcite
fill 88 83 583 88 86 583 minecraft:cobbled_deepslate
setblock 88 83 587 minecraft:calcite
fill 88 83 588 88 86 588 minecraft:cobbled_deepslate
setblock 88 83 592 minecraft:calcite
setblock 48 84 566 minecraft:calcite
fill 48 84 567 48 87 567 minecraft:cobbled_deepslate
setblock 48 84 571 minecraft:calcite
setblock 48 84 581 minecraft:calcite
setblock 48 84 582 minecraft:cobbled_deepslate
setblock 48 84 586 minecraft:calcite
fill 48 84 587 48 86 587 minecraft:cobbled_deepslate
fill 49 84 584 49 85 586 minecraft:light_blue_stained_glass
fill 49 84 588 50 84 588 minecraft:light_blue_stained_glass
setblock 50 84 560 minecraft:light[level=14]
setblock 50 84 568 minecraft:light[level=14]
setblock 50 84 576 minecraft:light[level=14]
setblock 50 84 584 minecraft:light_blue_stained_glass
setblock 50 84 592 minecraft:light[level=14]
setblock 54 84 586 minecraft:light_blue_stained_glass
setblock 56 84 558 minecraft:calcite
setblock 56 84 559 minecraft:cobbled_deepslate
fill 57 84 558 57 87 558 minecraft:cobbled_deepslate
setblock 58 84 568 minecraft:light[level=14]
setblock 58 84 576 minecraft:light[level=14]
setblock 58 84 584 minecraft:light[level=14]
setblock 58 84 592 minecraft:light[level=14]
setblock 59 84 560 minecraft:calcite
setblock 60 84 559 minecraft:calcite
fill 60 84 560 60 85 560 minecraft:cobbled_deepslate
setblock 60 84 598 minecraft:cobbled_deepslate
setblock 61 84 558 minecraft:calcite
fill 61 84 559 61 87 559 minecraft:cobbled_deepslate
setblock 61 84 598 minecraft:calcite
fill 62 84 558 65 84 558 minecraft:cobbled_deepslate
setblock 62 84 598 minecraft:cobbled_deepslate
setblock 65 84 559 minecraft:calcite
setblock 66 84 558 minecraft:calcite
setblock 66 84 560 minecraft:light[level=14]
setblock 66 84 568 minecraft:light[level=14]
setblock 66 84 576 minecraft:light[level=14]
setblock 66 84 584 minecraft:light[level=14]
setblock 66 84 592 minecraft:light[level=14]
setblock 67 84 558 minecraft:cobbled_deepslate
setblock 74 84 560 minecraft:light[level=14]
setblock 74 84 568 minecraft:light[level=14]
setblock 74 84 576 minecraft:light[level=14]
setblock 74 84 584 minecraft:light[level=14]
setblock 74 84 592 minecraft:light[level=14]
setblock 76 84 558 minecraft:calcite
setblock 76 84 598 minecraft:calcite
fill 77 84 558 77 87 558 minecraft:cobbled_deepslate
setblock 77 84 597 minecraft:calcite
fill 77 84 598 77 87 598 minecraft:cobbled_deepslate
fill 78 84 597 78 87 597 minecraft:cobbled_deepslate
setblock 81 84 558 minecraft:calcite
setblock 81 84 598 minecraft:calcite
setblock 82 84 558 minecraft:cobbled_deepslate
setblock 82 84 560 minecraft:light[level=14]
setblock 82 84 568 minecraft:light[level=14]
setblock 82 84 576 minecraft:light[level=14]
setblock 82 84 584 minecraft:light[level=14]
setblock 82 84 592 minecraft:light[level=14]
fill 82 84 598 82 86 598 minecraft:cobbled_deepslate
setblock 86 84 588 minecraft:calcite
setblock 87 84 582 minecraft:calcite
setblock 87 84 583 minecraft:cobbled_deepslate
setblock 87 84 587 minecraft:calcite
fill 87 84 588 87 87 588 minecraft:cobbled_deepslate
setblock 88 84 581 minecraft:calcite
fill 88 84 582 88 85 582 minecraft:cobbled_deepslate
setblock 88 84 586 minecraft:calcite
fill 88 84 587 88 87 587 minecraft:cobbled_deepslate
setblock 88 84 591 minecraft:calcite
fill 88 84 592 88 85 592 minecraft:cobbled_deepslate
setblock 48 85 564 minecraft:cobbled_deepslate
setblock 48 85 565 minecraft:calcite
fill 48 85 566 48 88 566 minecraft:cobbled_deepslate
setblock 48 85 570 minecraft:calcite
fill 48 85 571 48 88 571 minecraft:cobbled_deepslate
setblock 48 85 585 minecraft:calcite
fill 48 85 586 48 86 586 minecraft:cobbled_deepslate
fill 49 85 587 49 85 588 minecraft:light_blue_stained_glass
fill 50 85 585 51 85 587 minecraft:light_blue_stained_glass
setblock 52 85 586 minecraft:light_blue_stained_glass
fill 54 85 576 55 91 576 minecraft:deepslate
setblock 55 85 558 minecraft:calcite
fill 56 85 558 56 88 558 minecraft:cobbled_deepslate
setblock 59 85 559 minecraft:calcite
setblock 59 85 560 minecraft:cobbled_deepslate
setblock 60 85 558 minecraft:calcite
fill 60 85 559 60 88 559 minecraft:cobbled_deepslate
fill 61 85 558 64 85 558 minecraft:cobbled_deepslate
setblock 65 85 558 minecraft:calcite
setblock 66 85 558 minecraft:cobbled_deepslate
setblock 75 85 558 minecraft:calcite
setblock 75 85 598 minecraft:calcite
fill 76 85 558 76 86 558 minecraft:cobbled_deepslate
fill 76 85 598 76 88 598 minecraft:cobbled_deepslate
fill 77 85 597 77 88 597 minecraft:cobbled_deepslate
setblock 80 85 558 minecraft:calcite
setblock 80 85 598 minecraft:calcite
setblock 81 85 558 minecraft:cobbled_deepslate
fill 81 85 598 81 88 598 minecraft:cobbled_deepslate
setblock 87 85 586 minecraft:calcite
fill 87 85 587 87 87 587 minecraft:cobbled_deepslate
setblock 88 85 585 minecraft:calcite
fill 88 85 586 88 88 586 minecraft:cobbled_deepslate
setblock 88 85 590 minecraft:calcite
fill 88 85 591 88 88 591 minecraft:cobbled_deepslate
fill 48 86 565 48 89 565 minecraft:cobbled_deepslate
setblock 48 86 569 minecraft:calcite
fill 48 86 570 48 89 570 minecraft:cobbled_deepslate
fill 48 86 584 48 86 585 minecraft:light_blue_stained_glass
setblock 48 86 588 minecraft:light_blue_stained_glass
fill 48 86 590 48 90 592 minecraft:light_blue_stained_glass
fill 49 86 585 50 86 587 minecraft:light_blue_stained_glass
fill 49 86 591 49 91 591 minecraft:light_blue_stained_glass
fill 54 86 575 55 91 575 minecraft:deepslate
fill 55 86 558 55 89 558 minecraft:cobbled_deepslate
setblock 58 86 559 minecraft:calcite
setblock 59 86 558 minecraft:calcite
fill 59 86 559 59 89 559 minecraft:cobbled_deepslate
fill 60 86 558 63 86 558 minecraft:cobbled_deepslate
setblock 64 86 558 minecraft:calcite
setblock 74 86 598 minecraft:calcite
fill 75 86 598 75 89 598 minecraft:cobbled_deepslate
setblock 79 86 558 minecraft:calcite
setblock 79 86 598 minecraft:calcite
fill 80 86 598 80 89 598 minecraft:cobbled_deepslate
setblock 87 86 586 minecraft:cobbled_deepslate
setblock 88 86 584 minecraft:calcite
fill 88 86 585 88 89 585 minecraft:cobbled_deepslate
setblock 88 86 589 minecraft:calcite
fill 88 86 590 88 89 590 minecraft:cobbled_deepslate
setblock 48 87 568 minecraft:calcite
fill 48 87 569 48 90 569 minecraft:cobbled_deepslate
setblock 48 87 572 minecraft:cobbled_deepslate
setblock 48 87 586 minecraft:light_blue_stained_glass
fill 48 87 589 49 90 589 minecraft:light_blue_stained_glass
fill 48 87 593 49 90 593 minecraft:light_blue_stained_glass
fill 49 87 590 50 90 590 minecraft:light_blue_stained_glass
fill 49 87 592 50 90 592 minecraft:light_blue_stained_glass
fill 50 87 591 50 90 591 minecraft:light_blue_stained_glass
fill 53 87 576 53 91 576 minecraft:deepslate
fill 54 87 577 55 91 577 minecraft:deepslate
fill 56 87 576 56 91 576 minecraft:deepslate
setblock 57 87 559 minecraft:calcite
setblock 58 87 558 minecraft:calcite
fill 58 87 559 58 90 559 minecraft:cobbled_deepslate
fill 59 87 558 62 87 558 minecraft:cobbled_deepslate
setblock 63 87 558 minecraft:calcite
setblock 73 87 598 minecraft:calcite
fill 74 87 598 74 90 598 minecraft:cobbled_deepslate
fill 76 87 597 76 89 597 minecraft:cobbled_deepslate
setblock 78 87 598 minecraft:calcite
setblock 79 87 597 minecraft:calcite
fill 79 87 598 79 90 598 minecraft:cobbled_deepslate
setblock 87 87 589 minecraft:calcite
fill 88 87 584 88 88 584 minecraft:cobbled_deepslate
setblock 88 87 588 minecraft:calcite
fill 88 87 589 88 90 589 minecraft:cobbled_deepslate
setblock 88 87 592 minecraft:cobbled_deepslate
setblock 48 88 567 minecraft:calcite
fill 48 88 568 49 90 568 minecraft:cobbled_deepslate
setblock 48 88 572 minecraft:calcite
fill 48 88 573 48 91 573 minecraft:cobbled_deepslate
fill 49 88 567 49 91 567 minecraft:cobbled_deepslate
fill 49 88 569 49 88 570 minecraft:cobbled_deepslate
fill 50 88 589 50 89 589 minecraft:light_blue_stained_glass
fill 50 88 593 50 89 593 minecraft:light_blue_stained_glass
fill 51 88 590 51 89 592 minecraft:light_blue_stained_glass
fill 52 88 591 52 89 591 minecraft:light_blue_stained_glass
fill 53 88 575 53 91 575 minecraft:deepslate
fill 53 88 577 53 91 577 minecraft:deepslate
fill 54 88 574 54 91 574 minecraft:deepslate
fill 56 88 577 56 91 577 minecraft:deepslate
setblock 57 88 558 minecraft:calcite
fill 57 88 559 57 91 559 minecraft:cobbled_deepslate
fill 58 88 558 61 88 558 minecraft:cobbled_deepslate
fill 58 88 598 60 89 598 minecraft:cobbled_deepslate
setblock 62 88 558 minecraft:calcite
setblock 63 88 558 minecraft:cobbled_deepslate
setblock 72 88 598 minecraft:calcite
fill 73 88 598 73 91 598 minecraft:cobbled_deepslate
fill 74 88 597 75 90 597 minecraft:cobbled_deepslate
setblock 77 88 598 minecraft:calcite
setblock 78 88 597 minecraft:calcite
fill 78 88 598 78 91 598 minecraft:cobbled_deepslate
fill 79 88 597 80 90 597 minecraft:cobbled_deepslate
setblock 88 88 587 minecraft:calcite
fill 88 88 588 88 91 588 minecraft:cobbled_deepslate
setblock 88 88 592 minecraft:calcite
setblock 48 89 566 minecraft:calcite
fill 48 89 567 48 92 567 minecraft:cobbled_deepslate
setblock 48 89 571 minecraft:calcite
fill 48 89 572 49 91 572 minecraft:cobbled_deepslate
fill 48 89 574 48 90 574 minecraft:cobbled_deepslate
fill 49 89 566 49 92 566 minecraft:cobbled_deepslate
setblock 49 89 569 minecraft:cobbled_deepslate
setblock 49 89 570 minecraft:calcite
fill 49 89 571 49 92 571 minecraft:cobbled_deepslate
fill 53 89 574 53 91 574 minecraft:deepslate
fill 54 89 558 54 90 558 minecraft:cobbled_deepslate
fill 54 89 578 55 91 578 minecraft:deepslate
setblock 56 89 558 minecraft:calcite
fill 56 89 559 56 92 559 minecraft:cobbled_deepslate
setblock 56 89 598 minecraft:calcite
fill 57 89 558 60 89 558 minecraft:cobbled_deepslate
fill 57 89 576 57 91 576 minecraft:deepslate
fill 57 89 598 57 92 598 minecraft:cobbled_deepslate
setblock 61 89 558 minecraft:calcite
setblock 61 89 598 minecraft:calcite
fill 62 89 558 62 92 558 minecraft:cobbled_deepslate
setblock 71 89 598 minecraft:calcite
fill 72 89 598 72 92 598 minecraft:cobbled_deepslate
fill 73 89 597 73 92 597 minecraft:cobbled_deepslate
setblock 75 89 558 minecraft:cobbled_deepslate
fill 75 89 596 77 89 596 minecraft:cobbled_deepslate
setblock 76 89 558 minecraft:calcite
setblock 76 89 598 minecraft:calcite
fill 77 89 558 77 92 558 minecraft:cobbled_deepslate
setblock 77 89 597 minecraft:calcite
fill 77 89 598 77 92 598 minecraft:cobbled_deepslate
setblock 78 89 596 minecraft:calcite
fill 78 89 597 78 92 597 minecraft:cobbled_deepslate
setblock 81 89 598 minecraft:calcite
fill 88 89 568 88 89 570 minecraft:cobbled_deepslate
setblock 88 89 571 minecraft:calcite
fill 88 89 572 88 91 573 minecraft:cobbled_deepslate
setblock 88 89 586 minecraft:calcite
fill 88 89 587 88 92 587 minecraft:cobbled_deepslate
setblock 88 89 591 minecraft:calcite
fill 88 89 592 88 91 593 minecraft:cobbled_deepslate
setblock 48 90 564 minecraft:cobbled_deepslate
setblock 48 90 565 minecraft:calcite
fill 48 90 566 48 93 566 minecraft:cobbled_deepslate
setblock 48 90 570 minecraft:calcite
fill 48 90 571 48 93 571 minecraft:cobbled_deepslate
setblock 48 90 575 minecraft:calcite
fill 48 90 576 48 93 576 minecraft:cobbled_deepslate
setblock 49 90 569 minecraft:calcite
fill 49 90 570 50 92 570 minecraft:cobbled_deepslate
setblock 49 90 573 minecraft:cobbled_deepslate
setblock 49 90 574 minecraft:calcite
setblock 50 90 568 minecraft:calcite
fill 50 90 569 50 93 569 minecraft:cobbled_deepslate
fill 50 90 571 50 91 571 minecraft:cobbled_deepslate
setblock 51 90 591 minecraft:light_blue_stained_glass
fill 52 90 574 52 91 577 minecraft:deepslate
fill 53 90 558 53 91 558 minecraft:cobbled_deepslate
fill 53 90 578 53 91 578 minecraft:deepslate
fill 54 90 573 54 91 573 minecraft:deepslate
setblock 54 90 598 minecraft:cobbled_deepslate
setblock 55 90 558 minecraft:calcite
fill 55 90 559 55 93 559 minecraft:cobbled_deepslate
setblock 55 90 598 minecraft:calcite
fill 56 90 558 59 90 558 minecraft:cobbled_deepslate
fill 56 90 578 56 91 578 minecraft:deepslate
fill 56 90 598 56 93 598 minecraft:cobbled_deepslate
fill 57 90 577 57 91 577 minecraft:deepslate
fill 57 90 597 58 92 597 minecraft:cobbled_deepslate
fill 58 90 598 59 90 598 minecraft:cobbled_deepslate
setblock 59 90 559 minecraft:calcite
setblock 60 90 558 minecraft:calcite
setblock 60 90 598 minecraft:calcite
fill 61 90 558 61 93 558 minecraft:cobbled_deepslate
fill 61 90 598 63 91 598 minecraft:cobbled_deepslate
fill 63 90 558 63 91 558 minecraft:cobbled_deepslate
fill 68 90 598 69 90 598 minecraft:cobbled_deepslate
setblock 70 90 598 minecraft:calcite
setblock 71 90 597 minecraft:calcite
fill 71 90 598 71 93 598 minecraft:cobbled_deepslate
fill 72 90 597 72 93 597 minecraft:cobbled_deepslate
fill 73 90 558 74 90 558 minecraft:cobbled_deepslate
fill 73 90 596 76 90 596 minecraft:cobbled_deepslate
setblock 75 90 558 minecraft:calcite
setblock 75 90 598 minecraft:calcite
fill 76 90 558 76 93 558 minecraft:cobbled_deepslate
fill 76 90 595 77 90 595 minecraft:cobbled_deepslate
setblock 76 90 597 minecraft:calcite
fill 76 90 598 76 93 598 minecraft:cobbled_deepslate
setblock 77 90 596 minecraft:calcite
fill 77 90 597 77 93 597 minecraft:cobbled_deepslate
fill 78 90 596 79 92 596 minecraft:cobbled_deepslate
setblock 80 90 598 minecraft:calcite
fill 81 90 598 82 92 598 minecraft:cobbled_deepslate
fill 88 90 567 88 90 569 minecraft:cobbled_deepslate
setblock 88 90 570 minecraft:calcite
fill 88 90 571 88 93 571 minecraft:cobbled_deepslate
setblock 88 90 574 minecraft:cobbled_deepslate
setblock 88 90 575 minecraft:calcite
setblock 88 90 585 minecraft:calcite
fill 88 90 586 88 93 586 minecraft:cobbled_deepslate
setblock 88 90 590 minecraft:calcite
fill 88 90 591 88 93 591 minecraft:cobbled_deepslate
setblock 48 91 564 minecraft:calcite
fill 48 91 565 49 93 565 minecraft:cobbled_deepslate
setblock 48 91 568 minecraft:cobbled_deepslate
setblock 48 91 569 minecraft:calcite
fill 48 91 570 48 94 570 minecraft:cobbled_deepslate
setblock 48 91 574 minecraft:calcite
fill 48 91 575 49 93 575 minecraft:cobbled_deepslate
fill 48 91 577 48 92 577 minecraft:cobbled_deepslate
fill 48 91 590 48 92 592 minecraft:cobbled_deepslate
setblock 49 91 568 minecraft:calcite
fill 49 91 569 49 94 569 minecraft:cobbled_deepslate
setblock 49 91 573 minecraft:calcite
fill 49 91 574 49 94 574 minecraft:cobbled_deepslate
setblock 50 91 567 minecraft:calcite
fill 50 91 568 50 94 568 minecraft:cobbled_deepslate
setblock 50 91 572 minecraft:calcite
fill 50 91 573 50 94 573 minecraft:cobbled_deepslate
fill 52 91 558 52 92 558 minecraft:cobbled_deepslate
fill 52 91 598 53 91 598 minecraft:cobbled_deepslate
setblock 53 91 573 minecraft:deepslate
setblock 54 91 558 minecraft:calcite
fill 54 91 559 54 94 559 minecraft:cobbled_deepslate
fill 54 91 579 55 91 579 minecraft:deepslate
setblock 54 91 597 minecraft:cobbled_deepslate
setblock 54 91 598 minecraft:calcite
fill 55 91 558 58 91 558 minecraft:cobbled_deepslate
setblock 55 91 597 minecraft:calcite
fill 55 91 598 55 94 598 minecraft:cobbled_deepslate
fill 56 91 597 56 94 597 minecraft:cobbled_deepslate
setblock 57 91 578 minecraft:deepslate
setblock 58 91 559 minecraft:calcite
setblock 58 91 598 minecraft:cobbled_deepslate
setblock 59 91 558 minecraft:calcite
fill 59 91 559 60 93 559 minecraft:cobbled_deepslate
setblock 59 91 597 minecraft:cobbled_deepslate
setblock 59 91 598 minecraft:calcite
fill 60 91 558 60 94 558 minecraft:cobbled_deepslate
setblock 60 91 597 minecraft:calcite
fill 60 91 598 60 94 598 minecraft:cobbled_deepslate
fill 61 91 597 61 94 597 minecraft:cobbled_deepslate
setblock 64 91 598 minecraft:calcite
fill 65 91 598 68 91 598 minecraft:cobbled_deepslate
setblock 69 91 597 minecraft:cobbled_deepslate
setblock 69 91 598 minecraft:calcite
setblock 70 91 597 minecraft:calcite
fill 70 91 598 70 94 598 minecraft:cobbled_deepslate
fill 71 91 558 73 91 558 minecraft:cobbled_deepslate
setblock 71 91 596 minecraft:calcite
fill 71 91 597 71 94 597 minecraft:cobbled_deepslate
fill 72 91 596 75 91 596 minecraft:cobbled_deepslate
fill 73 91 595 76 91 595 minecraft:cobbled_deepslate
setblock 74 91 558 minecraft:calcite
setblock 74 91 597 minecraft:cobbled_deepslate
setblock 74 91 598 minecraft:calcite
fill 75 91 558 75 94 558 minecraft:cobbled_deepslate
setblock 75 91 597 minecraft:calcite
fill 75 91 598 75 94 598 minecraft:cobbled_deepslate
setblock 76 91 596 minecraft:calcite
fill 76 91 597 76 94 597 minecraft:cobbled_deepslate
setblock 77 91 595 minecraft:calcite
fill 77 91 596 77 94 596 minecraft:cobbled_deepslate
setblock 78 91 558 minecraft:cobbled_deepslate
fill 78 91 595 78 94 595 minecraft:cobbled_deepslate
setblock 79 91 597 minecraft:cobbled_deepslate
setblock 79 91 598 minecraft:calcite
setblock 80 91 596 minecraft:cobbled_deepslate
setblock 80 91 597 minecraft:calcite
fill 80 91 598 80 94 598 minecraft:cobbled_deepslate
fill 81 91 597 81 94 597 minecraft:cobbled_deepslate
fill 87 91 571 87 93 572 minecraft:cobbled_deepslate
setblock 87 91 590 minecraft:calcite
fill 87 91 591 87 94 591 minecraft:cobbled_deepslate
fill 88 91 567 88 91 568 minecraft:cobbled_deepslate
setblock 88 91 569 minecraft:calcite
fill 88 91 570 88 94 570 minecraft:cobbled_deepslate
setblock 88 91 574 minecraft:calcite
fill 88 91 575 88 91 578 minecraft:cobbled_deepslate
setblock 88 91 584 minecraft:calcite
fill 88 91 585 88 94 585 minecraft:cobbled_deepslate
setblock 88 91 589 minecraft:calcite
fill 88 91 590 88 94 590 minecraft:cobbled_deepslate
setblock 88 91 594 minecraft:calcite
setblock 48 92 563 minecraft:calcite
fill 48 92 564 48 95 564 minecraft:cobbled_deepslate
setblock 48 92 568 minecraft:calcite
fill 48 92 569 48 95 569 minecraft:cobbled_deepslate
setblock 48 92 572 minecraft:cobbled_deepslate
setblock 48 92 573 minecraft:calcite
fill 48 92 574 48 95 574 minecraft:cobbled_deepslate
setblock 48 92 578 minecraft:calcite
fill 48 92 589 48 94 589 minecraft:cobbled_deepslate
setblock 48 92 593 minecraft:calcite
fill 48 92 594 48 95 594 minecraft:cobbled_deepslate
setblock 49 92 567 minecraft:calcite
fill 49 92 568 49 95 568 minecraft:cobbled_deepslate
setblock 49 92 572 minecraft:calcite
fill 49 92 573 49 95 573 minecraft:cobbled_deepslate
setblock 49 92 576 minecraft:cobbled_deepslate
fill 50 92 558 51 93 558 minecraft:cobbled_deepslate
setblock 50 92 560 minecraft:light[level=14]
setblock 50 92 566 minecraft:calcite
fill 50 92 567 50 95 567 minecraft:cobbled_deepslate
setblock 50 92 571 minecraft:calcite
fill 50 92 572 51 94 572 minecraft:cobbled_deepslate
fill 50 92 574 50 93 574 minecraft:cobbled_deepslate
setblock 50 92 576 minecraft:light[level=14]
setblock 50 92 584 minecraft:light[level=14]
setblock 50 92 592 minecraft:light[level=14]
fill 51 92 568 51 92 569 minecraft:cobbled_deepslate
setblock 51 92 570 minecraft:calcite
fill 51 92 571 51 95 571 minecraft:cobbled_deepslate
fill 51 92 598 52 92 598 minecraft:cobbled_deepslate
setblock 52 92 559 minecraft:calcite
setblock 53 92 558 minecraft:calcite
fill 53 92 559 53 95 559 minecraft:cobbled_deepslate
setblock 53 92 597 minecraft:cobbled_deepslate
setblock 53 92 598 minecraft:calcite
fill 54 92 558 57 92 558 minecraft:cobbled_deepslate
fill 54 92 575 55 94 576 minecraft:light_blue_stained_glass
setblock 54 92 597 minecraft:calcite
fill 54 92 598 54 95 598 minecraft:cobbled_deepslate
setblock 55 92 596 minecraft:calcite
fill 55 92 597 55 95 597 minecraft:cobbled_deepslate
fill 56 92 596 58 93 596 minecraft:cobbled_deepslate
setblock 57 92 559 minecraft:calcite
setblock 58 92 558 minecraft:calcite
fill 58 92 559 58 95 559 minecraft:cobbled_deepslate
setblock 58 92 560 minecraft:light[level=14]
setblock 58 92 568 minecraft:light[level=14]
setblock 58 92 576 minecraft:light[level=14]
setblock 58 92 584 minecraft:light[level=14]
setblock 58 92 592 minecraft:light[level=14]
setblock 58 92 598 minecraft:calcite
fill 59 92 558 59 95 558 minecraft:cobbled_deepslate
setblock 59 92 597 minecraft:calcite
fill 59 92 598 59 95 598 minecraft:cobbled_deepslate
fill 60 92 597 60 95 597 minecraft:cobbled_deepslate
fill 61 92 598 62 92 598 minecraft:cobbled_deepslate
fill 62 92 597 63 92 597 minecraft:cobbled_deepslate
setblock 63 92 558 minecraft:calcite
setblock 63 92 598 minecraft:calcite
fill 64 92 558 64 95 558 minecraft:cobbled_deepslate
fill 64 92 598 67 92 598 minecraft:cobbled_deepslate
setblock 66 92 560 minecraft:light[level=14]
setblock 66 92 568 minecraft:light[level=14]
setblock 66 92 576 minecraft:light[level=14]
setblock 66 92 584 minecraft:light[level=14]
setblock 66 92 592 minecraft:light[level=14]
fill 66 92 597 68 92 597 minecraft:cobbled_deepslate
setblock 68 92 598 minecraft:calcite
fill 69 92 558 72 92 558 minecraft:cobbled_deepslate
setblock 69 92 596 minecraft:cobbled_deepslate
setblock 69 92 597 minecraft:calcite
fill 69 92 598 69 95 598 minecraft:cobbled_deepslate
setblock 70 92 596 minecraft:calcite
fill 70 92 597 70 95 597 minecraft:cobbled_deepslate
fill 71 92 596 74 92 596 minecraft:cobbled_deepslate
fill 72 92 595 75 92 595 minecraft:cobbled_deepslate
setblock 73 92 558 minecraft:calcite
setblock 73 92 598 minecraft:calcite
fill 74 92 558 74 95 558 minecraft:cobbled_deepslate
setblock 74 92 560 minecraft:light[level=14]
setblock 74 92 568 minecraft:light[level=14]
setblock 74 92 576 minecraft:light[level=14]
setblock 74 92 584 minecraft:light[level=14]
setblock 74 92 592 minecraft:light[level=14]
setblock 74 92 597 minecraft:calcite
fill 74 92 598 74 95 598 minecraft:cobbled_deepslate
fill 75 92 594 76 92 594 minecraft:cobbled_deepslate
setblock 75 92 596 minecraft:calcite
fill 75 92 597 75 95 597 minecraft:cobbled_deepslate
setblock 76 92 595 minecraft:calcite
fill 76 92 596 76 95 596 minecraft:cobbled_deepslate
fill 77 92 595 77 95 595 minecraft:cobbled_deepslate
setblock 78 92 558 minecraft:calcite
setblock 78 92 598 minecraft:calcite
setblock 79 92 597 minecraft:calcite
fill 79 92 598 79 95 598 minecraft:cobbled_deepslate
setblock 80 92 596 minecraft:calcite
fill 80 92 597 80 95 597 minecraft:cobbled_deepslate
setblock 82 92 560 minecraft:light[level=14]
setblock 82 92 568 minecraft:light[level=14]
setblock 82 92 576 minecraft:light[level=14]
setblock 82 92 584 minecraft:light[level=14]
setblock 82 92 592 minecraft:light[level=14]
setblock 87 92 569 minecraft:calcite
fill 87 92 570 87 95 570 minecraft:cobbled_deepslate
setblock 87 92 573 minecraft:cobbled_deepslate
setblock 87 92 574 minecraft:calcite
fill 87 92 575 88 94 575 minecraft:cobbled_deepslate
fill 87 92 590 87 93 590 minecraft:cobbled_deepslate
fill 87 92 592 88 92 592 minecraft:cobbled_deepslate
fill 88 92 566 88 92 567 minecraft:cobbled_deepslate
setblock 88 92 568 minecraft:calcite
fill 88 92 569 88 95 569 minecraft:cobbled_deepslate
setblock 88 92 572 minecraft:cobbled_deepslate
setblock 88 92 573 minecraft:calcite
fill 88 92 574 88 95 574 minecraft:cobbled_deepslate
fill 88 92 576 88 92 577 minecraft:cobbled_deepslate
setblock 88 92 578 minecraft:calcite
fill 88 92 579 88 92 582 minecraft:cobbled_deepslate
setblock 88 92 583 minecraft:calcite
fill 88 92 584 88 95 584 minecraft:cobbled_deepslate
setblock 88 92 588 minecraft:calcite
fill 88 92 589 88 95 589 minecraft:cobbled_deepslate
setblock 88 92 593 minecraft:calcite
fill 88 92 594 88 93 596 minecraft:cobbled_deepslate
setblock 48 93 562 minecraft:calcite
fill 48 93 563 48 96 563 minecraft:cobbled_deepslate
setblock 48 93 567 minecraft:calcite
fill 48 93 568 48 96 568 minecraft:cobbled_deepslate
setblock 48 93 572 minecraft:calcite
fill 48 93 573 48 96 573 minecraft:cobbled_deepslate
setblock 48 93 577 minecraft:calcite
fill 48 93 578 48 95 579 minecraft:cobbled_deepslate
fill 48 93 590 48 93 591 minecraft:cobbled_deepslate
setblock 48 93 592 minecraft:calcite
fill 48 93 593 48 96 593 minecraft:cobbled_deepslate
fill 48 93 595 48 93 596 minecraft:cobbled_deepslate
fill 49 93 558 49 95 558 minecraft:cobbled_deepslate
fill 49 93 564 49 94 564 minecraft:cobbled_deepslate
setblock 49 93 566 minecraft:calcite
fill 49 93 567 49 96 567 minecraft:cobbled_deepslate
setblock 49 93 570 minecraft:cobbled_deepslate
setblock 49 93 571 minecraft:calcite
fill 49 93 572 49 96 572 minecraft:cobbled_deepslate
setblock 49 93 576 minecraft:calcite
fill 49 93 577 49 96 577 minecraft:cobbled_deepslate
fill 49 93 598 51 93 598 minecraft:cobbled_deepslate
fill 50 93 566 50 96 566 minecraft:cobbled_deepslate
setblock 50 93 570 minecraft:calcite
fill 50 93 571 50 96 571 minecraft:cobbled_deepslate
setblock 50 93 575 minecraft:calcite
fill 50 93 576 50 96 576 minecraft:cobbled_deepslate
setblock 51 93 559 minecraft:calcite
setblock 51 93 568 minecraft:cobbled_deepslate
setblock 51 93 569 minecraft:calcite
fill 51 93 570 51 96 570 minecraft:cobbled_deepslate
setblock 51 93 573 minecraft:cobbled_deepslate
setblock 51 93 574 minecraft:calcite
fill 51 93 597 52 93 597 minecraft:cobbled_deepslate
setblock 52 93 558 minecraft:calcite
fill 52 93 559 52 96 559 minecraft:cobbled_deepslate
setblock 52 93 598 minecraft:calcite
fill 53 93 558 56 93 558 minecraft:cobbled_deepslate
setblock 53 93 596 minecraft:cobbled_deepslate
setblock 53 93 597 minecraft:calcite
fill 53 93 598 53 96 598 minecraft:cobbled_deepslate
setblock 54 93 560 minecraft:cobbled_deepslate
setblock 54 93 596 minecraft:calcite
fill 54 93 597 54 96 597 minecraft:cobbled_deepslate
schedule function dropper:buildpart/133_3 1t
