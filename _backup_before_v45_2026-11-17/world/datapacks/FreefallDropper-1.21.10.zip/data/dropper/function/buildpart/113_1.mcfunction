setblock 239 38 474 minecraft:brown_terracotta
setblock 239 38 475 minecraft:bone_block
fill 239 38 476 239 39 476 minecraft:brown_terracotta
fill 239 38 478 239 39 478 minecraft:brown_terracotta
setblock 239 38 480 minecraft:bone_block
fill 239 38 481 239 39 481 minecraft:brown_terracotta
fill 239 38 502 241 38 502 minecraft:brown_terracotta
setblock 240 38 464 minecraft:bone_block
fill 240 38 465 240 41 465 minecraft:brown_terracotta
setblock 240 38 504 minecraft:bone_block
fill 241 38 464 241 41 464 minecraft:brown_terracotta
setblock 241 38 503 minecraft:bone_block
fill 241 38 504 241 41 504 minecraft:brown_terracotta
setblock 242 38 502 minecraft:bone_block
fill 242 38 503 242 41 503 minecraft:brown_terracotta
setblock 243 38 502 minecraft:brown_terracotta
setblock 244 38 465 minecraft:bone_block
setblock 245 38 464 minecraft:bone_block
setblock 245 38 465 minecraft:brown_terracotta
setblock 245 38 504 minecraft:bone_block
fill 246 38 464 246 41 464 minecraft:brown_terracotta
setblock 246 38 503 minecraft:bone_block
fill 246 38 504 249 38 504 minecraft:brown_terracotta
fill 247 38 503 250 38 503 minecraft:brown_terracotta
setblock 250 38 464 minecraft:bone_block
setblock 250 38 504 minecraft:bone_block
fill 251 38 464 251 41 464 minecraft:brown_terracotta
setblock 251 38 503 minecraft:bone_block
fill 251 38 504 251 41 504 minecraft:brown_terracotta
fill 252 38 503 255 38 503 minecraft:brown_terracotta
fill 253 38 502 256 38 502 minecraft:brown_terracotta
setblock 255 38 464 minecraft:bone_block
setblock 255 38 504 minecraft:bone_block
fill 256 38 464 256 41 464 minecraft:brown_terracotta
fill 256 38 501 257 38 501 minecraft:brown_terracotta
setblock 256 38 503 minecraft:bone_block
fill 256 38 504 256 41 504 minecraft:brown_terracotta
setblock 257 38 502 minecraft:bone_block
fill 257 38 503 257 41 503 minecraft:brown_terracotta
setblock 258 38 501 minecraft:bone_block
fill 258 38 502 258 41 502 minecraft:brown_terracotta
setblock 259 38 465 minecraft:bone_block
setblock 259 38 500 minecraft:bone_block
fill 259 38 501 259 41 501 minecraft:brown_terracotta
setblock 260 38 464 minecraft:bone_block
setblock 260 38 500 minecraft:brown_terracotta
setblock 260 38 504 minecraft:bone_block
fill 261 38 464 261 41 464 minecraft:brown_terracotta
setblock 261 38 503 minecraft:bone_block
fill 261 38 504 261 41 504 minecraft:brown_terracotta
setblock 262 38 502 minecraft:bone_block
fill 262 38 503 262 41 503 minecraft:brown_terracotta
setblock 263 38 501 minecraft:bone_block
fill 263 38 502 263 41 502 minecraft:brown_terracotta
setblock 264 38 501 minecraft:brown_terracotta
setblock 265 38 504 minecraft:bone_block
setblock 266 38 503 minecraft:bone_block
fill 266 38 504 266 41 504 minecraft:brown_terracotta
setblock 267 38 503 minecraft:brown_terracotta
fill 274 38 477 274 38 479 minecraft:brown_terracotta
setblock 274 38 480 minecraft:bone_block
fill 274 38 481 275 40 481 minecraft:brown_terracotta
setblock 274 38 504 minecraft:brown_terracotta
setblock 275 38 474 minecraft:bone_block
fill 275 38 475 275 41 475 minecraft:brown_terracotta
setblock 275 38 479 minecraft:bone_block
fill 275 38 480 275 41 480 minecraft:brown_terracotta
fill 275 38 482 275 38 483 minecraft:brown_terracotta
setblock 275 38 484 minecraft:bone_block
fill 275 38 485 275 41 485 minecraft:brown_terracotta
setblock 275 38 494 minecraft:bone_block
setblock 275 38 495 minecraft:brown_terracotta
setblock 275 38 499 minecraft:bone_block
fill 275 38 500 275 40 500 minecraft:brown_terracotta
setblock 275 38 504 minecraft:bone_block
setblock 276 38 473 minecraft:bone_block
fill 276 38 474 276 41 474 minecraft:brown_terracotta
setblock 276 38 478 minecraft:bone_block
fill 276 38 479 276 41 479 minecraft:brown_terracotta
setblock 276 38 482 minecraft:brown_terracotta
setblock 276 38 483 minecraft:bone_block
fill 276 38 484 276 41 484 minecraft:brown_terracotta
setblock 276 38 488 minecraft:bone_block
fill 276 38 489 276 41 489 minecraft:brown_terracotta
setblock 276 38 493 minecraft:bone_block
fill 276 38 494 276 41 494 minecraft:brown_terracotta
setblock 276 38 498 minecraft:bone_block
fill 276 38 499 276 41 499 minecraft:brown_terracotta
setblock 276 38 502 minecraft:brown_terracotta
setblock 276 38 503 minecraft:bone_block
fill 276 38 504 276 41 504 minecraft:brown_terracotta
setblock 236 39 467 minecraft:bone_block
fill 236 39 468 236 42 468 minecraft:brown_terracotta
setblock 236 39 472 minecraft:bone_block
fill 236 39 473 236 42 473 minecraft:brown_terracotta
setblock 236 39 477 minecraft:bone_block
fill 236 39 478 236 42 478 minecraft:brown_terracotta
setblock 236 39 482 minecraft:bone_block
fill 236 39 483 236 42 483 minecraft:brown_terracotta
setblock 236 39 487 minecraft:bone_block
fill 236 39 488 236 42 488 minecraft:brown_terracotta
setblock 236 39 497 minecraft:bone_block
fill 236 39 498 236 42 498 minecraft:brown_terracotta
setblock 236 39 501 minecraft:brown_terracotta
setblock 236 39 502 minecraft:bone_block
fill 236 39 503 238 39 504 minecraft:brown_terracotta
setblock 237 39 465 minecraft:brown_terracotta
setblock 237 39 466 minecraft:bone_block
fill 237 39 467 237 42 467 minecraft:brown_terracotta
setblock 237 39 471 minecraft:bone_block
fill 237 39 472 237 42 472 minecraft:brown_terracotta
setblock 237 39 476 minecraft:bone_block
fill 237 39 477 237 42 477 minecraft:brown_terracotta
setblock 237 39 481 minecraft:bone_block
fill 237 39 482 237 42 482 minecraft:brown_terracotta
setblock 237 39 497 minecraft:brown_terracotta
setblock 237 39 501 minecraft:bone_block
fill 237 39 502 237 42 502 minecraft:brown_terracotta
setblock 238 39 464 minecraft:brown_terracotta
setblock 238 39 465 minecraft:bone_block
setblock 238 39 471 minecraft:brown_terracotta
setblock 238 39 475 minecraft:bone_block
fill 238 39 476 238 42 476 minecraft:brown_terracotta
setblock 238 39 480 minecraft:bone_block
fill 238 39 481 238 42 481 minecraft:brown_terracotta
setblock 239 39 464 minecraft:bone_block
fill 239 39 465 239 42 465 minecraft:brown_terracotta
setblock 239 39 474 minecraft:bone_block
setblock 239 39 475 minecraft:brown_terracotta
setblock 239 39 479 minecraft:bone_block
fill 239 39 480 239 40 480 minecraft:brown_terracotta
fill 239 39 502 239 39 503 minecraft:brown_terracotta
setblock 239 39 504 minecraft:bone_block
fill 240 39 464 240 42 464 minecraft:brown_terracotta
setblock 240 39 502 minecraft:brown_terracotta
setblock 240 39 503 minecraft:bone_block
fill 240 39 504 240 42 504 minecraft:brown_terracotta
setblock 241 39 502 minecraft:bone_block
fill 241 39 503 241 42 503 minecraft:brown_terracotta
setblock 242 39 502 minecraft:brown_terracotta
setblock 243 39 465 minecraft:bone_block
setblock 244 39 464 minecraft:bone_block
fill 244 39 465 244 40 465 minecraft:brown_terracotta
setblock 244 39 504 minecraft:bone_block
fill 245 39 464 245 42 464 minecraft:brown_terracotta
setblock 245 39 503 minecraft:bone_block
fill 245 39 504 248 39 504 minecraft:brown_terracotta
fill 246 39 503 249 39 503 minecraft:brown_terracotta
setblock 249 39 464 minecraft:bone_block
setblock 249 39 504 minecraft:bone_block
fill 250 39 464 250 42 464 minecraft:brown_terracotta
setblock 250 39 503 minecraft:bone_block
fill 250 39 504 250 42 504 minecraft:brown_terracotta
fill 251 39 503 254 39 503 minecraft:brown_terracotta
fill 253 39 502 255 39 502 minecraft:brown_terracotta
setblock 254 39 464 minecraft:bone_block
setblock 254 39 504 minecraft:bone_block
fill 255 39 464 255 42 464 minecraft:brown_terracotta
fill 255 39 501 256 39 501 minecraft:brown_terracotta
setblock 255 39 503 minecraft:bone_block
fill 255 39 504 255 42 504 minecraft:brown_terracotta
setblock 256 39 502 minecraft:bone_block
fill 256 39 503 256 42 503 minecraft:brown_terracotta
setblock 257 39 501 minecraft:bone_block
fill 257 39 502 257 42 502 minecraft:brown_terracotta
fill 258 39 501 258 42 501 minecraft:brown_terracotta
setblock 259 39 464 minecraft:bone_block
setblock 259 39 504 minecraft:bone_block
fill 260 39 464 260 42 464 minecraft:brown_terracotta
setblock 260 39 503 minecraft:bone_block
fill 260 39 504 260 42 504 minecraft:brown_terracotta
setblock 261 39 502 minecraft:bone_block
fill 261 39 503 261 42 503 minecraft:brown_terracotta
setblock 262 39 501 minecraft:bone_block
fill 262 39 502 262 42 502 minecraft:brown_terracotta
setblock 263 39 501 minecraft:brown_terracotta
setblock 264 39 504 minecraft:bone_block
fill 265 39 501 265 40 501 minecraft:soul_soil
setblock 265 39 503 minecraft:bone_block
fill 265 39 504 265 42 504 minecraft:brown_terracotta
fill 266 39 502 266 40 502 minecraft:soul_soil
fill 266 39 503 266 40 503 minecraft:brown_terracotta
setblock 274 39 478 minecraft:brown_terracotta
setblock 274 39 479 minecraft:bone_block
fill 274 39 480 274 42 480 minecraft:brown_terracotta
fill 274 39 482 275 39 482 minecraft:brown_terracotta
setblock 274 39 504 minecraft:bone_block
fill 275 39 474 275 40 474 minecraft:brown_terracotta
setblock 275 39 478 minecraft:bone_block
fill 275 39 479 275 42 479 minecraft:brown_terracotta
setblock 275 39 483 minecraft:bone_block
fill 275 39 484 275 42 484 minecraft:brown_terracotta
setblock 275 39 487 minecraft:brown_terracotta
setblock 275 39 498 minecraft:bone_block
fill 275 39 499 275 40 499 minecraft:brown_terracotta
setblock 275 39 502 minecraft:brown_terracotta
fill 275 39 504 275 42 504 minecraft:brown_terracotta
setblock 276 39 472 minecraft:bone_block
fill 276 39 473 276 42 473 minecraft:brown_terracotta
setblock 276 39 477 minecraft:bone_block
fill 276 39 478 276 42 478 minecraft:brown_terracotta
setblock 276 39 482 minecraft:bone_block
fill 276 39 483 276 42 483 minecraft:brown_terracotta
setblock 276 39 487 minecraft:bone_block
fill 276 39 488 276 42 488 minecraft:brown_terracotta
setblock 276 39 492 minecraft:bone_block
fill 276 39 493 276 41 493 minecraft:brown_terracotta
setblock 276 39 497 minecraft:bone_block
fill 276 39 498 276 42 498 minecraft:brown_terracotta
setblock 276 39 502 minecraft:bone_block
fill 276 39 503 276 42 503 minecraft:brown_terracotta
setblock 236 40 466 minecraft:bone_block
fill 236 40 467 236 43 467 minecraft:brown_terracotta
setblock 236 40 471 minecraft:bone_block
fill 236 40 472 236 43 472 minecraft:brown_terracotta
setblock 236 40 476 minecraft:bone_block
fill 236 40 477 236 43 477 minecraft:brown_terracotta
setblock 236 40 481 minecraft:bone_block
fill 236 40 482 236 43 482 minecraft:brown_terracotta
setblock 236 40 486 minecraft:bone_block
fill 236 40 487 236 43 487 minecraft:brown_terracotta
setblock 236 40 496 minecraft:bone_block
fill 236 40 497 236 41 497 minecraft:brown_terracotta
setblock 236 40 501 minecraft:bone_block
fill 236 40 502 236 41 504 minecraft:brown_terracotta
setblock 237 40 465 minecraft:bone_block
fill 237 40 466 237 43 466 minecraft:brown_terracotta
setblock 237 40 470 minecraft:bone_block
fill 237 40 471 237 43 471 minecraft:brown_terracotta
setblock 237 40 475 minecraft:bone_block
fill 237 40 476 237 43 476 minecraft:brown_terracotta
setblock 237 40 480 minecraft:bone_block
fill 237 40 481 237 43 481 minecraft:brown_terracotta
setblock 237 40 485 minecraft:bone_block
fill 237 40 497 237 41 498 minecraft:soul_soil
setblock 237 40 500 minecraft:bone_block
fill 237 40 501 237 43 501 minecraft:brown_terracotta
fill 237 40 503 237 40 504 minecraft:brown_terracotta
setblock 238 40 464 minecraft:bone_block
fill 238 40 465 238 43 465 minecraft:brown_terracotta
setblock 238 40 474 minecraft:bone_block
fill 238 40 475 238 41 475 minecraft:brown_terracotta
setblock 238 40 479 minecraft:bone_block
fill 238 40 480 238 43 480 minecraft:brown_terracotta
setblock 238 40 503 minecraft:brown_terracotta
setblock 238 40 504 minecraft:bone_block
fill 239 40 464 239 43 464 minecraft:brown_terracotta
setblock 239 40 478 minecraft:bone_block
setblock 239 40 479 minecraft:brown_terracotta
fill 239 40 497 239 41 497 minecraft:soul_soil
fill 239 40 499 239 41 499 minecraft:soul_soil
setblock 239 40 502 minecraft:brown_terracotta
setblock 239 40 503 minecraft:bone_block
fill 239 40 504 239 43 504 minecraft:brown_terracotta
setblock 240 40 502 minecraft:bone_block
fill 240 40 503 240 43 503 minecraft:brown_terracotta
setblock 241 40 465 minecraft:brown_terracotta
setblock 241 40 502 minecraft:brown_terracotta
setblock 242 40 465 minecraft:bone_block
setblock 243 40 464 minecraft:bone_block
fill 243 40 465 243 43 465 minecraft:brown_terracotta
setblock 243 40 504 minecraft:bone_block
fill 244 40 464 244 43 464 minecraft:brown_terracotta
setblock 244 40 503 minecraft:bone_block
fill 244 40 504 247 40 504 minecraft:brown_terracotta
fill 245 40 503 248 40 503 minecraft:brown_terracotta
setblock 248 40 464 minecraft:bone_block
setblock 248 40 504 minecraft:bone_block
fill 249 40 464 249 43 464 minecraft:brown_terracotta
setblock 249 40 503 minecraft:bone_block
fill 249 40 504 249 43 504 minecraft:brown_terracotta
fill 250 40 503 253 40 503 minecraft:brown_terracotta
setblock 253 40 464 minecraft:bone_block
fill 253 40 502 254 40 502 minecraft:brown_terracotta
setblock 253 40 504 minecraft:bone_block
fill 254 40 464 254 43 464 minecraft:brown_terracotta
setblock 254 40 503 minecraft:bone_block
fill 254 40 504 254 43 504 minecraft:brown_terracotta
setblock 255 40 502 minecraft:bone_block
fill 255 40 503 255 43 503 minecraft:brown_terracotta
setblock 256 40 501 minecraft:bone_block
fill 256 40 502 256 43 502 minecraft:brown_terracotta
fill 257 40 501 257 43 501 minecraft:brown_terracotta
setblock 258 40 464 minecraft:bone_block
setblock 258 40 504 minecraft:bone_block
fill 259 40 464 259 43 464 minecraft:brown_terracotta
setblock 259 40 503 minecraft:bone_block
fill 259 40 504 259 43 504 minecraft:brown_terracotta
setblock 260 40 502 minecraft:bone_block
fill 260 40 503 260 43 503 minecraft:brown_terracotta
setblock 261 40 501 minecraft:bone_block
fill 261 40 502 261 43 502 minecraft:brown_terracotta
setblock 262 40 501 minecraft:brown_terracotta
setblock 263 40 464 minecraft:bone_block
setblock 263 40 504 minecraft:bone_block
setblock 264 40 501 minecraft:soul_soil
setblock 264 40 503 minecraft:bone_block
fill 264 40 504 264 43 504 minecraft:brown_terracotta
setblock 265 40 502 minecraft:soul_soil
fill 265 40 503 265 41 503 minecraft:brown_terracotta
setblock 266 40 501 minecraft:soul_soil
setblock 273 40 504 minecraft:bone_block
setblock 274 40 478 minecraft:bone_block
fill 274 40 479 274 43 479 minecraft:brown_terracotta
setblock 274 40 482 minecraft:brown_terracotta
setblock 274 40 483 minecraft:bone_block
fill 274 40 504 274 43 504 minecraft:brown_terracotta
setblock 275 40 477 minecraft:bone_block
fill 275 40 478 275 43 478 minecraft:brown_terracotta
setblock 275 40 482 minecraft:bone_block
fill 275 40 483 275 43 483 minecraft:brown_terracotta
setblock 275 40 487 minecraft:bone_block
fill 276 40 464 276 41 464 minecraft:brown_terracotta
setblock 276 40 471 minecraft:bone_block
fill 276 40 472 276 43 472 minecraft:brown_terracotta
setblock 276 40 476 minecraft:bone_block
fill 276 40 477 276 43 477 minecraft:brown_terracotta
setblock 276 40 481 minecraft:bone_block
fill 276 40 482 276 43 482 minecraft:brown_terracotta
setblock 276 40 486 minecraft:bone_block
fill 276 40 487 276 43 487 minecraft:brown_terracotta
setblock 276 40 491 minecraft:bone_block
fill 276 40 492 276 41 492 minecraft:brown_terracotta
setblock 276 40 496 minecraft:bone_block
fill 276 40 497 276 43 497 minecraft:brown_terracotta
setblock 276 40 501 minecraft:bone_block
fill 276 40 502 276 43 502 minecraft:brown_terracotta
setblock 236 41 465 minecraft:bone_block
fill 236 41 466 236 44 466 minecraft:brown_terracotta
setblock 236 41 470 minecraft:bone_block
fill 236 41 471 236 44 471 minecraft:brown_terracotta
setblock 236 41 475 minecraft:bone_block
fill 236 41 476 236 44 476 minecraft:brown_terracotta
setblock 236 41 480 minecraft:bone_block
fill 236 41 481 236 44 481 minecraft:brown_terracotta
setblock 236 41 485 minecraft:bone_block
fill 236 41 486 236 44 486 minecraft:brown_terracotta
setblock 236 41 500 minecraft:bone_block
fill 236 41 501 236 44 501 minecraft:brown_terracotta
setblock 237 41 464 minecraft:bone_block
fill 237 41 465 237 44 465 minecraft:brown_terracotta
setblock 237 41 469 minecraft:bone_block
fill 237 41 470 237 44 470 minecraft:brown_terracotta
setblock 237 41 474 minecraft:bone_block
fill 237 41 475 237 44 475 minecraft:brown_terracotta
setblock 237 41 479 minecraft:bone_block
fill 237 41 480 237 44 480 minecraft:brown_terracotta
setblock 237 41 484 minecraft:bone_block
fill 237 41 485 237 44 485 minecraft:brown_terracotta
setblock 237 41 499 minecraft:soul_soil
fill 237 41 500 237 42 500 minecraft:brown_terracotta
setblock 237 41 503 minecraft:brown_terracotta
setblock 237 41 504 minecraft:bone_block
fill 238 41 464 238 44 464 minecraft:brown_terracotta
setblock 238 41 474 minecraft:brown_terracotta
setblock 238 41 478 minecraft:bone_block
fill 238 41 479 238 43 479 minecraft:brown_terracotta
setblock 238 41 483 minecraft:bone_block
setblock 238 41 503 minecraft:bone_block
fill 238 41 504 238 44 504 minecraft:brown_terracotta
fill 239 41 503 239 44 503 minecraft:brown_terracotta
setblock 241 41 465 minecraft:bone_block
setblock 242 41 464 minecraft:bone_block
fill 242 41 465 242 44 465 minecraft:brown_terracotta
setblock 242 41 504 minecraft:bone_block
fill 243 41 464 243 44 464 minecraft:brown_terracotta
setblock 243 41 503 minecraft:bone_block
fill 243 41 504 246 41 504 minecraft:brown_terracotta
fill 244 41 503 246 41 503 minecraft:brown_terracotta
setblock 247 41 464 minecraft:bone_block
setblock 247 41 504 minecraft:bone_block
fill 248 41 464 248 44 464 minecraft:brown_terracotta
fill 248 41 504 248 44 504 minecraft:brown_terracotta
fill 249 41 503 252 41 503 minecraft:brown_terracotta
setblock 252 41 464 minecraft:bone_block
setblock 252 41 504 minecraft:bone_block
fill 253 41 464 253 44 464 minecraft:brown_terracotta
setblock 253 41 502 minecraft:brown_terracotta
setblock 253 41 503 minecraft:bone_block
fill 253 41 504 253 44 504 minecraft:brown_terracotta
setblock 254 41 502 minecraft:bone_block
fill 254 41 503 254 44 503 minecraft:brown_terracotta
fill 255 41 502 255 44 502 minecraft:brown_terracotta
fill 256 41 501 256 42 501 minecraft:brown_terracotta
setblock 257 41 464 minecraft:bone_block
setblock 257 41 504 minecraft:bone_block
fill 258 41 464 258 44 464 minecraft:brown_terracotta
setblock 258 41 503 minecraft:bone_block
fill 258 41 504 258 44 504 minecraft:brown_terracotta
setblock 259 41 502 minecraft:bone_block
fill 259 41 503 259 44 503 minecraft:brown_terracotta
setblock 260 41 501 minecraft:bone_block
fill 260 41 502 260 44 502 minecraft:brown_terracotta
setblock 261 41 501 minecraft:brown_terracotta
setblock 262 41 464 minecraft:bone_block
setblock 262 41 504 minecraft:bone_block
setblock 263 41 503 minecraft:bone_block
fill 263 41 504 263 44 504 minecraft:brown_terracotta
fill 264 41 503 264 42 503 minecraft:brown_terracotta
setblock 267 41 504 minecraft:bone_block
fill 272 41 474 272 50 474 minecraft:soul_soil
fill 273 41 504 273 44 504 minecraft:brown_terracotta
setblock 274 41 478 minecraft:brown_terracotta
setblock 274 41 481 minecraft:brown_terracotta
setblock 274 41 482 minecraft:bone_block
fill 274 41 483 274 43 484 minecraft:brown_terracotta
setblock 275 41 476 minecraft:bone_block
fill 275 41 477 275 44 477 minecraft:brown_terracotta
setblock 275 41 481 minecraft:bone_block
fill 275 41 482 275 44 482 minecraft:brown_terracotta
setblock 275 41 486 minecraft:bone_block
fill 275 41 487 275 44 487 minecraft:brown_terracotta
setblock 276 41 465 minecraft:bone_block
fill 276 41 471 276 44 471 minecraft:brown_terracotta
setblock 276 41 475 minecraft:bone_block
fill 276 41 476 276 44 476 minecraft:brown_terracotta
setblock 276 41 480 minecraft:bone_block
fill 276 41 481 276 44 481 minecraft:brown_terracotta
setblock 276 41 485 minecraft:bone_block
fill 276 41 486 276 44 486 minecraft:brown_terracotta
setblock 276 41 490 minecraft:bone_block
fill 276 41 491 276 44 491 minecraft:brown_terracotta
setblock 276 41 495 minecraft:bone_block
fill 276 41 496 276 42 496 minecraft:brown_terracotta
setblock 276 41 500 minecraft:bone_block
fill 276 41 501 276 44 501 minecraft:brown_terracotta
setblock 236 42 464 minecraft:bone_block
fill 236 42 465 236 45 465 minecraft:brown_terracotta
setblock 236 42 469 minecraft:bone_block
fill 236 42 470 236 45 470 minecraft:brown_terracotta
setblock 236 42 474 minecraft:bone_block
fill 236 42 475 236 45 475 minecraft:brown_terracotta
setblock 236 42 479 minecraft:bone_block
fill 236 42 480 236 45 480 minecraft:brown_terracotta
setblock 236 42 484 minecraft:bone_block
fill 236 42 485 236 45 485 minecraft:brown_terracotta
setblock 236 42 499 minecraft:bone_block
fill 236 42 500 236 45 500 minecraft:brown_terracotta
fill 236 42 502 236 42 503 minecraft:brown_terracotta
setblock 236 42 504 minecraft:bone_block
fill 237 42 464 237 45 464 minecraft:brown_terracotta
setblock 237 42 468 minecraft:bone_block
fill 237 42 469 237 45 469 minecraft:brown_terracotta
setblock 237 42 473 minecraft:bone_block
fill 237 42 474 237 45 474 minecraft:brown_terracotta
setblock 237 42 478 minecraft:bone_block
fill 237 42 479 237 45 479 minecraft:brown_terracotta
setblock 237 42 483 minecraft:bone_block
fill 237 42 484 237 45 484 minecraft:brown_terracotta
fill 237 42 486 237 43 486 minecraft:brown_terracotta
setblock 237 42 503 minecraft:bone_block
fill 237 42 504 237 45 504 minecraft:brown_terracotta
setblock 238 42 477 minecraft:bone_block
fill 238 42 478 238 43 478 minecraft:brown_terracotta
setblock 238 42 482 minecraft:bone_block
setblock 238 42 483 minecraft:brown_terracotta
fill 238 42 503 238 45 503 minecraft:brown_terracotta
setblock 240 42 465 minecraft:bone_block
setblock 241 42 464 minecraft:bone_block
fill 241 42 465 241 45 465 minecraft:brown_terracotta
setblock 241 42 504 minecraft:bone_block
fill 242 42 464 242 45 464 minecraft:brown_terracotta
setblock 242 42 503 minecraft:bone_block
fill 242 42 504 245 42 504 minecraft:brown_terracotta
fill 243 42 503 244 42 503 minecraft:brown_terracotta
setblock 246 42 464 minecraft:bone_block
setblock 246 42 504 minecraft:bone_block
fill 247 42 464 247 45 464 minecraft:brown_terracotta
fill 247 42 504 247 45 504 minecraft:brown_terracotta
fill 249 42 503 251 42 503 minecraft:brown_terracotta
setblock 251 42 464 minecraft:bone_block
setblock 251 42 504 minecraft:bone_block
fill 252 42 464 252 45 464 minecraft:brown_terracotta
setblock 252 42 503 minecraft:bone_block
fill 252 42 504 252 45 504 minecraft:brown_terracotta
setblock 253 42 502 minecraft:bone_block
fill 253 42 503 253 45 503 minecraft:brown_terracotta
fill 254 42 502 254 45 502 minecraft:brown_terracotta
setblock 256 42 464 minecraft:bone_block
setblock 256 42 504 minecraft:bone_block
fill 257 42 464 257 45 464 minecraft:brown_terracotta
setblock 257 42 503 minecraft:bone_block
fill 257 42 504 257 45 504 minecraft:brown_terracotta
setblock 258 42 502 minecraft:bone_block
fill 258 42 503 258 45 503 minecraft:brown_terracotta
setblock 259 42 501 minecraft:bone_block
fill 259 42 502 259 45 502 minecraft:brown_terracotta
setblock 261 42 464 minecraft:bone_block
setblock 261 42 504 minecraft:bone_block
setblock 262 42 464 minecraft:brown_terracotta
setblock 262 42 503 minecraft:bone_block
fill 262 42 504 262 45 504 minecraft:brown_terracotta
fill 263 42 503 263 43 503 minecraft:brown_terracotta
setblock 266 42 504 minecraft:bone_block
setblock 274 42 481 minecraft:bone_block
fill 274 42 482 274 45 482 minecraft:brown_terracotta
setblock 275 42 464 minecraft:brown_terracotta
setblock 275 42 475 minecraft:bone_block
fill 275 42 476 275 45 476 minecraft:brown_terracotta
setblock 275 42 480 minecraft:bone_block
fill 275 42 481 275 45 481 minecraft:brown_terracotta
setblock 275 42 485 minecraft:bone_block
fill 275 42 486 275 45 486 minecraft:brown_terracotta
fill 275 42 488 275 43 488 minecraft:brown_terracotta
setblock 276 42 464 minecraft:bone_block
fill 276 42 465 276 42 468 minecraft:brown_terracotta
fill 276 42 470 276 45 470 minecraft:brown_terracotta
setblock 276 42 474 minecraft:bone_block
fill 276 42 475 276 45 475 minecraft:brown_terracotta
setblock 276 42 479 minecraft:bone_block
fill 276 42 480 276 45 480 minecraft:brown_terracotta
setblock 276 42 484 minecraft:bone_block
fill 276 42 485 276 45 485 minecraft:brown_terracotta
setblock 276 42 489 minecraft:bone_block
fill 276 42 490 276 45 490 minecraft:brown_terracotta
setblock 276 42 499 minecraft:bone_block
fill 276 42 500 276 45 500 minecraft:brown_terracotta
setblock 276 42 504 minecraft:bone_block
fill 236 43 464 236 46 464 minecraft:brown_terracotta
setblock 236 43 468 minecraft:bone_block
fill 236 43 469 236 46 469 minecraft:brown_terracotta
setblock 236 43 473 minecraft:bone_block
fill 236 43 474 236 46 474 minecraft:brown_terracotta
setblock 236 43 478 minecraft:bone_block
fill 236 43 479 236 46 479 minecraft:brown_terracotta
setblock 236 43 483 minecraft:bone_block
fill 236 43 484 236 46 484 minecraft:brown_terracotta
setblock 236 43 488 minecraft:bone_block
setblock 236 43 498 minecraft:bone_block
fill 236 43 499 236 46 499 minecraft:brown_terracotta
setblock 236 43 502 minecraft:brown_terracotta
setblock 236 43 503 minecraft:bone_block
fill 236 43 504 236 46 504 minecraft:brown_terracotta
setblock 237 43 467 minecraft:bone_block
fill 237 43 468 237 46 468 minecraft:brown_terracotta
setblock 237 43 472 minecraft:bone_block
fill 237 43 473 237 46 473 minecraft:brown_terracotta
setblock 237 43 477 minecraft:bone_block
fill 237 43 478 237 46 478 minecraft:brown_terracotta
setblock 237 43 482 minecraft:bone_block
fill 237 43 483 237 46 483 minecraft:brown_terracotta
setblock 237 43 502 minecraft:bone_block
fill 237 43 503 237 46 503 minecraft:brown_terracotta
setblock 238 43 466 minecraft:light[level=12]
setblock 238 43 474 minecraft:light[level=12]
setblock 238 43 481 minecraft:bone_block
fill 238 43 482 238 44 482 minecraft:brown_terracotta
setblock 238 43 490 minecraft:light[level=12]
setblock 238 43 498 minecraft:light[level=12]
setblock 239 43 465 minecraft:bone_block
setblock 240 43 464 minecraft:bone_block
fill 240 43 465 240 46 465 minecraft:brown_terracotta
setblock 240 43 504 minecraft:bone_block
fill 241 43 464 241 46 464 minecraft:brown_terracotta
setblock 241 43 503 minecraft:bone_block
fill 241 43 504 244 43 504 minecraft:brown_terracotta
fill 242 43 503 243 45 503 minecraft:brown_terracotta
setblock 245 43 464 minecraft:bone_block
setblock 245 43 504 minecraft:bone_block
fill 246 43 464 246 46 464 minecraft:brown_terracotta
setblock 246 43 466 minecraft:light[level=12]
setblock 246 43 474 minecraft:light[level=12]
setblock 246 43 482 minecraft:light[level=12]
setblock 246 43 490 minecraft:light[level=12]
setblock 246 43 498 minecraft:light[level=12]
fill 246 43 504 246 46 504 minecraft:brown_terracotta
fill 249 43 503 250 43 503 minecraft:brown_terracotta
setblock 250 43 464 minecraft:bone_block
setblock 250 43 504 minecraft:bone_block
fill 251 43 464 251 46 464 minecraft:brown_terracotta
setblock 251 43 503 minecraft:bone_block
fill 251 43 504 251 46 504 minecraft:brown_terracotta
fill 252 43 503 252 46 503 minecraft:brown_terracotta
fill 253 43 502 253 46 502 minecraft:brown_terracotta
setblock 254 43 466 minecraft:light[level=12]
setblock 254 43 474 minecraft:light[level=12]
setblock 254 43 482 minecraft:light[level=12]
setblock 254 43 490 minecraft:light[level=12]
setblock 254 43 498 minecraft:light[level=12]
setblock 255 43 464 minecraft:bone_block
fill 255 43 465 257 44 465 minecraft:brown_terracotta
setblock 255 43 504 minecraft:bone_block
fill 256 43 464 256 46 464 minecraft:brown_terracotta
setblock 256 43 503 minecraft:bone_block
fill 256 43 504 256 46 504 minecraft:brown_terracotta
setblock 257 43 502 minecraft:bone_block
fill 257 43 503 257 46 503 minecraft:brown_terracotta
fill 258 43 502 258 46 502 minecraft:brown_terracotta
setblock 260 43 464 minecraft:bone_block
fill 260 43 497 264 44 501 minecraft:soul_soil
setblock 260 43 504 minecraft:bone_block
fill 261 43 464 261 46 464 minecraft:brown_terracotta
setblock 261 43 503 minecraft:bone_block
fill 261 43 504 261 46 504 minecraft:brown_terracotta
setblock 262 43 466 minecraft:light[level=12]
setblock 262 43 474 minecraft:light[level=12]
setblock 262 43 482 minecraft:light[level=12]
setblock 262 43 490 minecraft:light[level=12]
setblock 262 43 502 minecraft:soul_soil
fill 262 43 503 262 45 503 minecraft:brown_terracotta
setblock 265 43 504 minecraft:bone_block
setblock 270 43 466 minecraft:light[level=12]
setblock 270 43 474 minecraft:light[level=12]
setblock 270 43 482 minecraft:light[level=12]
setblock 270 43 490 minecraft:light[level=12]
setblock 270 43 498 minecraft:light[level=12]
setblock 274 43 464 minecraft:brown_terracotta
setblock 274 43 480 minecraft:bone_block
fill 274 43 481 274 46 481 minecraft:brown_terracotta
setblock 274 43 485 minecraft:bone_block
setblock 275 43 464 minecraft:bone_block
fill 275 43 475 275 46 475 minecraft:brown_terracotta
setblock 275 43 479 minecraft:bone_block
fill 275 43 480 275 46 480 minecraft:brown_terracotta
setblock 275 43 484 minecraft:bone_block
fill 275 43 485 275 46 485 minecraft:brown_terracotta
setblock 275 43 504 minecraft:bone_block
fill 276 43 464 276 43 467 minecraft:brown_terracotta
setblock 276 43 468 minecraft:bone_block
fill 276 43 469 276 46 469 minecraft:brown_terracotta
setblock 276 43 473 minecraft:bone_block
fill 276 43 474 276 46 474 minecraft:brown_terracotta
setblock 276 43 478 minecraft:bone_block
fill 276 43 479 276 46 479 minecraft:brown_terracotta
setblock 276 43 483 minecraft:bone_block
fill 276 43 484 276 46 484 minecraft:brown_terracotta
setblock 276 43 488 minecraft:bone_block
fill 276 43 489 276 46 489 minecraft:brown_terracotta
setblock 276 43 498 minecraft:bone_block
fill 276 43 499 276 46 499 minecraft:brown_terracotta
setblock 276 43 503 minecraft:bone_block
fill 276 43 504 276 46 504 minecraft:brown_terracotta
setblock 236 44 467 minecraft:bone_block
fill 236 44 468 236 47 468 minecraft:brown_terracotta
setblock 236 44 472 minecraft:bone_block
fill 236 44 473 236 47 473 minecraft:brown_terracotta
setblock 236 44 477 minecraft:bone_block
fill 236 44 478 236 47 478 minecraft:brown_terracotta
setblock 236 44 482 minecraft:bone_block
fill 236 44 483 236 47 483 minecraft:brown_terracotta
setblock 236 44 487 minecraft:bone_block
fill 236 44 488 236 46 489 minecraft:brown_terracotta
setblock 236 44 502 minecraft:bone_block
fill 236 44 503 236 47 503 minecraft:brown_terracotta
setblock 237 44 466 minecraft:bone_block
fill 237 44 467 237 47 467 minecraft:brown_terracotta
setblock 237 44 471 minecraft:bone_block
fill 237 44 472 237 47 472 minecraft:brown_terracotta
setblock 237 44 476 minecraft:bone_block
fill 237 44 477 237 47 477 minecraft:brown_terracotta
setblock 237 44 481 minecraft:bone_block
fill 237 44 482 237 47 482 minecraft:brown_terracotta
setblock 237 44 486 minecraft:bone_block
setblock 237 44 501 minecraft:bone_block
fill 237 44 502 237 47 502 minecraft:brown_terracotta
setblock 238 44 465 minecraft:bone_block
fill 238 44 466 239 46 466 minecraft:brown_terracotta
setblock 238 44 480 minecraft:bone_block
setblock 238 44 481 minecraft:brown_terracotta
setblock 239 44 464 minecraft:bone_block
fill 239 44 465 239 47 465 minecraft:brown_terracotta
setblock 239 44 504 minecraft:bone_block
fill 240 44 464 240 47 464 minecraft:brown_terracotta
setblock 240 44 503 minecraft:bone_block
fill 240 44 504 243 44 504 minecraft:brown_terracotta
fill 241 44 503 241 47 503 minecraft:brown_terracotta
setblock 243 44 465 minecraft:bone_block
setblock 244 44 464 minecraft:bone_block
setblock 244 44 504 minecraft:bone_block
fill 245 44 464 245 47 464 minecraft:brown_terracotta
fill 245 44 504 245 47 504 minecraft:brown_terracotta
fill 248 44 503 249 44 503 minecraft:brown_terracotta
setblock 249 44 464 minecraft:bone_block
setblock 249 44 504 minecraft:bone_block
fill 250 44 464 250 47 464 minecraft:brown_terracotta
setblock 250 44 503 minecraft:bone_block
fill 250 44 504 250 47 504 minecraft:brown_terracotta
fill 251 44 503 251 47 503 minecraft:brown_terracotta
fill 252 44 502 252 47 502 minecraft:brown_terracotta
setblock 253 44 465 minecraft:bone_block
setblock 254 44 464 minecraft:bone_block
fill 254 44 465 254 47 465 minecraft:brown_terracotta
setblock 254 44 504 minecraft:bone_block
fill 255 44 464 255 47 464 minecraft:brown_terracotta
setblock 255 44 503 minecraft:bone_block
fill 255 44 504 255 47 504 minecraft:brown_terracotta
setblock 256 44 502 minecraft:bone_block
fill 256 44 503 256 47 503 minecraft:brown_terracotta
fill 257 44 502 257 47 502 minecraft:brown_terracotta
setblock 259 44 464 minecraft:bone_block
setblock 259 44 504 minecraft:bone_block
fill 260 44 464 260 47 464 minecraft:brown_terracotta
setblock 260 44 503 minecraft:bone_block
fill 260 44 504 260 47 504 minecraft:brown_terracotta
fill 261 44 503 261 47 503 minecraft:brown_terracotta
setblock 264 44 504 minecraft:bone_block
setblock 265 44 504 minecraft:brown_terracotta
fill 268 44 482 272 63 484 minecraft:bone_block
fill 269 44 481 271 63 481 minecraft:bone_block
fill 269 44 485 271 63 485 minecraft:bone_block
fill 272 44 504 272 45 504 minecraft:brown_terracotta
setblock 273 44 464 minecraft:brown_terracotta
setblock 274 44 464 minecraft:bone_block
setblock 274 44 479 minecraft:bone_block
fill 274 44 480 274 47 480 minecraft:brown_terracotta
setblock 274 44 483 minecraft:brown_terracotta
setblock 274 44 484 minecraft:bone_block
fill 274 44 485 274 46 486 minecraft:brown_terracotta
setblock 274 44 504 minecraft:bone_block
fill 275 44 464 276 46 464 minecraft:brown_terracotta
setblock 275 44 478 minecraft:bone_block
fill 275 44 479 275 47 479 minecraft:brown_terracotta
setblock 275 44 483 minecraft:bone_block
fill 275 44 484 275 47 484 minecraft:brown_terracotta
setblock 275 44 488 minecraft:bone_block
fill 275 44 489 275 47 489 minecraft:brown_terracotta
fill 275 44 504 275 47 504 minecraft:brown_terracotta
fill 276 44 465 276 44 466 minecraft:brown_terracotta
setblock 276 44 467 minecraft:bone_block
fill 276 44 468 276 47 468 minecraft:brown_terracotta
setblock 276 44 472 minecraft:bone_block
fill 276 44 473 276 47 473 minecraft:brown_terracotta
setblock 276 44 477 minecraft:bone_block
fill 276 44 478 276 47 478 minecraft:brown_terracotta
setblock 276 44 482 minecraft:bone_block
fill 276 44 483 276 47 483 minecraft:brown_terracotta
setblock 276 44 487 minecraft:bone_block
fill 276 44 488 276 47 488 minecraft:brown_terracotta
setblock 276 44 492 minecraft:bone_block
setblock 276 44 498 minecraft:brown_terracotta
setblock 276 44 502 minecraft:bone_block
fill 276 44 503 276 47 503 minecraft:brown_terracotta
setblock 236 45 466 minecraft:bone_block
fill 236 45 467 236 48 467 minecraft:brown_terracotta
setblock 236 45 471 minecraft:bone_block
fill 236 45 472 236 48 472 minecraft:brown_terracotta
setblock 236 45 476 minecraft:bone_block
fill 236 45 477 236 48 477 minecraft:brown_terracotta
setblock 236 45 481 minecraft:bone_block
fill 236 45 482 236 48 482 minecraft:brown_terracotta
setblock 236 45 486 minecraft:bone_block
fill 236 45 487 237 47 487 minecraft:brown_terracotta
setblock 236 45 501 minecraft:bone_block
fill 236 45 502 236 48 502 minecraft:brown_terracotta
setblock 237 45 465 minecraft:bone_block
fill 237 45 466 237 48 466 minecraft:brown_terracotta
setblock 237 45 470 minecraft:bone_block
fill 237 45 471 237 48 471 minecraft:brown_terracotta
setblock 237 45 475 minecraft:bone_block
fill 237 45 476 237 48 476 minecraft:brown_terracotta
setblock 237 45 480 minecraft:bone_block
fill 237 45 481 237 48 481 minecraft:brown_terracotta
setblock 237 45 485 minecraft:bone_block
fill 237 45 486 237 48 486 minecraft:brown_terracotta
fill 237 45 501 237 48 501 minecraft:brown_terracotta
setblock 238 45 464 minecraft:bone_block
fill 238 45 465 238 48 465 minecraft:brown_terracotta
fill 238 45 467 238 46 467 minecraft:brown_terracotta
setblock 238 45 504 minecraft:bone_block
fill 239 45 464 239 48 464 minecraft:brown_terracotta
setblock 239 45 503 minecraft:bone_block
fill 239 45 504 242 45 504 minecraft:brown_terracotta
setblock 240 45 466 minecraft:brown_terracotta
fill 240 45 503 240 48 503 minecraft:brown_terracotta
setblock 242 45 465 minecraft:bone_block
setblock 243 45 464 minecraft:bone_block
fill 243 45 465 243 48 465 minecraft:brown_terracotta
setblock 243 45 504 minecraft:bone_block
fill 244 45 464 244 48 464 minecraft:brown_terracotta
fill 244 45 504 244 48 504 minecraft:brown_terracotta
setblock 248 45 464 minecraft:bone_block
setblock 248 45 503 minecraft:brown_terracotta
setblock 248 45 504 minecraft:bone_block
fill 249 45 464 249 48 464 minecraft:brown_terracotta
setblock 249 45 503 minecraft:bone_block
fill 249 45 504 249 48 504 minecraft:brown_terracotta
fill 250 45 503 250 48 503 minecraft:brown_terracotta
setblock 251 45 465 minecraft:brown_terracotta
setblock 252 45 465 minecraft:bone_block
setblock 253 45 464 minecraft:bone_block
fill 253 45 465 253 48 465 minecraft:brown_terracotta
setblock 253 45 504 minecraft:bone_block
fill 254 45 464 254 48 464 minecraft:brown_terracotta
setblock 254 45 503 minecraft:bone_block
fill 254 45 504 254 48 504 minecraft:brown_terracotta
fill 255 45 465 256 45 465 minecraft:brown_terracotta
setblock 255 45 502 minecraft:bone_block
fill 255 45 503 255 48 503 minecraft:brown_terracotta
fill 256 45 502 256 48 502 minecraft:brown_terracotta
setblock 257 45 465 minecraft:bone_block
setblock 258 45 464 minecraft:bone_block
fill 258 45 465 258 48 465 minecraft:brown_terracotta
fill 258 45 498 260 46 498 minecraft:bone_block
fill 258 45 500 260 46 500 minecraft:bone_block
setblock 258 45 504 minecraft:bone_block
fill 259 45 464 259 48 464 minecraft:brown_terracotta
fill 259 45 499 259 46 499 minecraft:bone_block
setblock 259 45 503 minecraft:bone_block
fill 259 45 504 259 48 504 minecraft:brown_terracotta
setblock 260 45 502 minecraft:bone_block
fill 260 45 503 260 48 503 minecraft:brown_terracotta
setblock 263 45 504 minecraft:bone_block
fill 264 45 504 264 48 504 minecraft:brown_terracotta
fill 266 45 481 267 62 485 minecraft:bone_block
fill 267 45 480 273 62 480 minecraft:bone_block
fill 267 45 486 273 46 486 minecraft:bone_block
fill 268 45 479 272 62 479 minecraft:bone_block
fill 268 45 481 268 62 481 minecraft:bone_block
fill 268 45 485 268 62 485 minecraft:bone_block
fill 268 45 487 272 62 487 minecraft:bone_block
fill 271 45 465 271 46 465 minecraft:bone_block
fill 271 45 474 271 50 474 minecraft:soul_soil
fill 271 45 504 271 46 504 minecraft:brown_terracotta
setblock 272 45 464 minecraft:brown_terracotta
fill 272 45 473 272 50 473 minecraft:soul_soil
fill 272 45 475 272 49 475 minecraft:soul_soil
fill 272 45 481 273 46 481 minecraft:bone_block
fill 272 45 485 273 45 485 minecraft:bone_block
setblock 273 45 464 minecraft:bone_block
fill 273 45 474 273 50 474 minecraft:soul_soil
fill 273 45 482 273 45 484 minecraft:bone_block
setblock 273 45 504 minecraft:bone_block
fill 274 45 464 274 47 465 minecraft:brown_terracotta
setblock 274 45 478 minecraft:bone_block
fill 274 45 479 274 48 479 minecraft:brown_terracotta
setblock 274 45 483 minecraft:bone_block
fill 274 45 484 274 48 484 minecraft:brown_terracotta
setblock 274 45 487 minecraft:brown_terracotta
fill 274 45 504 274 48 504 minecraft:brown_terracotta
fill 275 45 465 275 45 466 minecraft:brown_terracotta
setblock 275 45 467 minecraft:bone_block
fill 275 45 474 275 47 474 minecraft:brown_terracotta
setblock 275 45 477 minecraft:bone_block
fill 275 45 478 275 48 478 minecraft:brown_terracotta
setblock 275 45 482 minecraft:bone_block
fill 275 45 483 275 48 483 minecraft:brown_terracotta
setblock 275 45 487 minecraft:bone_block
fill 275 45 488 275 48 488 minecraft:brown_terracotta
fill 275 45 490 275 46 490 minecraft:brown_terracotta
fill 275 45 503 275 48 503 minecraft:brown_terracotta
setblock 276 45 465 minecraft:brown_terracotta
setblock 276 45 466 minecraft:bone_block
fill 276 45 467 276 48 467 minecraft:brown_terracotta
setblock 276 45 471 minecraft:bone_block
fill 276 45 472 276 48 472 minecraft:brown_terracotta
setblock 276 45 476 minecraft:bone_block
fill 276 45 477 276 48 477 minecraft:brown_terracotta
setblock 276 45 481 minecraft:bone_block
fill 276 45 482 276 48 482 minecraft:brown_terracotta
setblock 276 45 486 minecraft:bone_block
fill 276 45 487 276 48 487 minecraft:brown_terracotta
setblock 276 45 491 minecraft:bone_block
fill 276 45 492 276 48 492 minecraft:brown_terracotta
setblock 276 45 501 minecraft:bone_block
fill 276 45 502 276 48 502 minecraft:brown_terracotta
setblock 236 46 465 minecraft:bone_block
fill 236 46 466 236 49 466 minecraft:brown_terracotta
setblock 236 46 470 minecraft:bone_block
fill 236 46 471 236 49 471 minecraft:brown_terracotta
setblock 236 46 475 minecraft:bone_block
fill 236 46 476 236 49 476 minecraft:brown_terracotta
setblock 236 46 480 minecraft:bone_block
fill 236 46 481 236 49 481 minecraft:brown_terracotta
setblock 236 46 485 minecraft:bone_block
fill 236 46 486 236 49 486 minecraft:brown_terracotta
setblock 236 46 490 minecraft:bone_block
setblock 236 46 500 minecraft:bone_block
fill 236 46 501 236 49 501 minecraft:brown_terracotta
setblock 237 46 464 minecraft:bone_block
fill 237 46 465 237 49 465 minecraft:brown_terracotta
setblock 237 46 469 minecraft:bone_block
fill 237 46 470 237 49 470 minecraft:brown_terracotta
setblock 237 46 474 minecraft:bone_block
fill 237 46 475 237 49 475 minecraft:brown_terracotta
setblock 237 46 479 minecraft:bone_block
fill 237 46 480 237 49 480 minecraft:brown_terracotta
setblock 237 46 484 minecraft:bone_block
fill 237 46 485 237 49 485 minecraft:brown_terracotta
setblock 237 46 504 minecraft:bone_block
fill 238 46 464 238 49 464 minecraft:brown_terracotta
setblock 238 46 468 minecraft:bone_block
setblock 238 46 503 minecraft:bone_block
fill 238 46 504 241 46 504 minecraft:brown_terracotta
fill 239 46 503 239 49 503 minecraft:brown_terracotta
setblock 240 46 466 minecraft:bone_block
setblock 241 46 465 minecraft:bone_block
setblock 242 46 464 minecraft:bone_block
fill 242 46 465 242 49 465 minecraft:brown_terracotta
setblock 242 46 503 minecraft:brown_terracotta
setblock 242 46 504 minecraft:bone_block
fill 243 46 464 243 49 464 minecraft:brown_terracotta
setblock 243 46 503 minecraft:bone_block
fill 243 46 504 243 49 504 minecraft:brown_terracotta
fill 244 46 465 245 46 465 minecraft:brown_terracotta
setblock 247 46 464 minecraft:bone_block
setblock 247 46 503 minecraft:brown_terracotta
setblock 247 46 504 minecraft:bone_block
fill 248 46 464 248 49 464 minecraft:brown_terracotta
setblock 248 46 503 minecraft:bone_block
fill 248 46 504 248 49 504 minecraft:brown_terracotta
fill 249 46 465 250 46 465 minecraft:brown_terracotta
fill 249 46 503 249 49 503 minecraft:brown_terracotta
setblock 251 46 465 minecraft:bone_block
fill 251 46 502 251 48 502 minecraft:brown_terracotta
setblock 252 46 464 minecraft:bone_block
fill 252 46 465 252 49 465 minecraft:brown_terracotta
setblock 252 46 504 minecraft:bone_block
fill 253 46 464 253 49 464 minecraft:brown_terracotta
setblock 253 46 503 minecraft:bone_block
fill 253 46 504 253 49 504 minecraft:brown_terracotta
setblock 254 46 502 minecraft:bone_block
fill 254 46 503 254 49 503 minecraft:brown_terracotta
setblock 255 46 465 minecraft:brown_terracotta
fill 255 46 502 255 49 502 minecraft:brown_terracotta
setblock 256 46 465 minecraft:bone_block
setblock 257 46 464 minecraft:bone_block
fill 257 46 465 257 49 465 minecraft:brown_terracotta
setblock 257 46 504 minecraft:bone_block
fill 258 46 464 258 49 464 minecraft:brown_terracotta
setblock 258 46 503 minecraft:bone_block
fill 258 46 504 258 49 504 minecraft:brown_terracotta
setblock 259 46 502 minecraft:bone_block
fill 259 46 503 259 49 503 minecraft:brown_terracotta
fill 260 46 499 261 47 499 minecraft:bone_block
setblock 262 46 464 minecraft:bone_block
setblock 262 46 504 minecraft:bone_block
fill 263 46 504 263 49 504 minecraft:brown_terracotta
fill 265 46 480 265 61 486 minecraft:bone_block
fill 266 46 479 266 61 480 minecraft:bone_block
fill 266 46 486 266 61 487 minecraft:bone_block
fill 267 46 478 267 61 479 minecraft:bone_block
fill 267 46 487 267 61 488 minecraft:bone_block
fill 268 46 478 273 61 478 minecraft:bone_block
fill 268 46 488 273 47 488 minecraft:bone_block
fill 270 46 464 271 46 464 minecraft:brown_terracotta
fill 270 46 504 270 47 504 minecraft:brown_terracotta
setblock 272 46 464 minecraft:bone_block
fill 272 46 485 272 62 485 minecraft:bone_block
setblock 272 46 504 minecraft:bone_block
fill 273 46 464 273 48 465 minecraft:brown_terracotta
fill 273 46 479 273 61 479 minecraft:bone_block
setblock 273 46 482 minecraft:brown_terracotta
setblock 273 46 483 minecraft:bone_block
fill 273 46 484 273 48 485 minecraft:brown_terracotta
fill 273 46 487 274 46 487 minecraft:bone_block
fill 273 46 504 273 49 504 minecraft:brown_terracotta
fill 274 46 478 274 49 478 minecraft:brown_terracotta
setblock 274 46 482 minecraft:bone_block
fill 274 46 483 274 49 483 minecraft:brown_terracotta
fill 274 46 488 274 49 488 minecraft:brown_terracotta
setblock 275 46 465 minecraft:brown_terracotta
setblock 275 46 466 minecraft:bone_block
fill 275 46 467 275 46 470 minecraft:brown_terracotta
setblock 275 46 471 minecraft:bone_block
fill 275 46 472 275 48 473 minecraft:brown_terracotta
setblock 275 46 476 minecraft:bone_block
fill 275 46 477 275 49 477 minecraft:brown_terracotta
setblock 275 46 481 minecraft:bone_block
fill 275 46 482 275 49 482 minecraft:brown_terracotta
setblock 275 46 486 minecraft:bone_block
fill 275 46 487 275 49 487 minecraft:brown_terracotta
setblock 276 46 465 minecraft:bone_block
fill 276 46 466 276 49 466 minecraft:brown_terracotta
setblock 276 46 470 minecraft:bone_block
fill 276 46 471 276 49 471 minecraft:brown_terracotta
setblock 276 46 475 minecraft:bone_block
fill 276 46 476 276 49 476 minecraft:brown_terracotta
setblock 276 46 480 minecraft:bone_block
fill 276 46 481 276 49 481 minecraft:brown_terracotta
setblock 276 46 485 minecraft:bone_block
fill 276 46 486 276 49 486 minecraft:brown_terracotta
setblock 276 46 490 minecraft:bone_block
fill 276 46 491 276 49 491 minecraft:brown_terracotta
fill 276 46 493 276 47 493 minecraft:brown_terracotta
setblock 276 46 500 minecraft:bone_block
fill 276 46 501 276 49 501 minecraft:brown_terracotta
setblock 236 47 464 minecraft:bone_block
fill 236 47 465 236 50 465 minecraft:brown_terracotta
setblock 236 47 469 minecraft:bone_block
fill 236 47 470 236 50 470 minecraft:brown_terracotta
setblock 236 47 474 minecraft:bone_block
fill 236 47 475 236 50 475 minecraft:brown_terracotta
setblock 236 47 479 minecraft:bone_block
fill 236 47 480 236 50 480 minecraft:brown_terracotta
setblock 236 47 484 minecraft:bone_block
fill 236 47 485 236 50 485 minecraft:brown_terracotta
setblock 236 47 488 minecraft:brown_terracotta
setblock 236 47 489 minecraft:bone_block
fill 236 47 490 236 48 492 minecraft:brown_terracotta
setblock 236 47 499 minecraft:bone_block
fill 236 47 500 236 50 500 minecraft:brown_terracotta
setblock 236 47 504 minecraft:bone_block
fill 237 47 464 237 50 464 minecraft:brown_terracotta
setblock 237 47 468 minecraft:bone_block
fill 237 47 469 238 49 469 minecraft:brown_terracotta
setblock 237 47 473 minecraft:bone_block
fill 237 47 474 237 50 474 minecraft:brown_terracotta
setblock 237 47 478 minecraft:bone_block
fill 237 47 479 237 49 479 minecraft:brown_terracotta
setblock 237 47 483 minecraft:bone_block
fill 237 47 484 237 50 484 minecraft:brown_terracotta
setblock 237 47 488 minecraft:bone_block
setblock 237 47 503 minecraft:bone_block
fill 237 47 504 240 47 504 minecraft:brown_terracotta
setblock 238 47 466 minecraft:brown_terracotta
setblock 238 47 467 minecraft:bone_block
fill 238 47 468 238 50 468 minecraft:brown_terracotta
fill 238 47 503 238 50 503 minecraft:brown_terracotta
setblock 239 47 466 minecraft:bone_block
setblock 240 47 465 minecraft:bone_block
fill 240 47 466 241 49 466 minecraft:brown_terracotta
setblock 241 47 464 minecraft:bone_block
fill 241 47 465 241 50 465 minecraft:brown_terracotta
setblock 241 47 504 minecraft:bone_block
fill 242 47 464 242 50 464 minecraft:brown_terracotta
setblock 242 47 503 minecraft:bone_block
fill 242 47 504 242 50 504 minecraft:brown_terracotta
fill 243 47 503 243 48 503 minecraft:brown_terracotta
setblock 244 47 465 minecraft:brown_terracotta
setblock 245 47 465 minecraft:bone_block
setblock 246 47 464 minecraft:bone_block
fill 246 47 465 249 47 465 minecraft:brown_terracotta
fill 246 47 466 246 54 466 minecraft:soul_soil
setblock 246 47 503 minecraft:brown_terracotta
setblock 246 47 504 minecraft:bone_block
fill 247 47 464 247 50 464 minecraft:brown_terracotta
setblock 247 47 503 minecraft:bone_block
fill 247 47 504 247 50 504 minecraft:brown_terracotta
fill 248 47 503 248 50 503 minecraft:brown_terracotta
setblock 250 47 465 minecraft:bone_block
setblock 251 47 464 minecraft:bone_block
fill 251 47 465 251 50 465 minecraft:brown_terracotta
setblock 251 47 504 minecraft:bone_block
fill 252 47 464 252 50 464 minecraft:brown_terracotta
setblock 252 47 503 minecraft:bone_block
fill 252 47 504 252 50 504 minecraft:brown_terracotta
setblock 253 47 502 minecraft:bone_block
fill 253 47 503 253 50 503 minecraft:brown_terracotta
fill 254 47 502 254 50 502 minecraft:brown_terracotta
setblock 255 47 465 minecraft:bone_block
setblock 256 47 464 minecraft:bone_block
fill 256 47 465 256 50 465 minecraft:brown_terracotta
setblock 256 47 504 minecraft:bone_block
fill 257 47 464 257 50 464 minecraft:brown_terracotta
setblock 257 47 503 minecraft:bone_block
fill 257 47 504 257 50 504 minecraft:brown_terracotta
setblock 258 47 502 minecraft:bone_block
fill 258 47 503 258 50 503 minecraft:brown_terracotta
setblock 259 47 465 minecraft:brown_terracotta
setblock 261 47 464 minecraft:bone_block
setblock 261 47 504 minecraft:bone_block
fill 262 47 464 262 50 464 minecraft:brown_terracotta
fill 262 47 499 262 48 499 minecraft:bone_block
fill 262 47 504 262 50 504 minecraft:brown_terracotta
fill 264 47 480 264 60 486 minecraft:bone_block
fill 265 47 479 265 60 479 minecraft:bone_block
fill 265 47 487 265 60 487 minecraft:bone_block
fill 266 47 478 266 60 478 minecraft:bone_block
fill 266 47 488 266 60 488 minecraft:bone_block
fill 267 47 477 273 60 477 minecraft:bone_block
fill 267 47 486 272 62 486 minecraft:bone_block
fill 267 47 489 273 48 489 minecraft:bone_block
fill 269 47 464 270 47 464 minecraft:brown_terracotta
fill 269 47 504 269 48 504 minecraft:brown_terracotta
setblock 271 47 464 minecraft:bone_block
fill 271 47 465 272 49 465 minecraft:brown_terracotta
fill 271 47 473 271 50 473 minecraft:soul_soil
fill 271 47 475 271 49 475 minecraft:soul_soil
setblock 271 47 504 minecraft:bone_block
fill 272 47 464 272 50 464 minecraft:brown_terracotta
fill 272 47 481 272 62 481 minecraft:bone_block
fill 272 47 504 272 50 504 minecraft:brown_terracotta
fill 273 47 473 273 50 473 minecraft:soul_soil
fill 273 47 475 273 50 475 minecraft:soul_soil
setblock 273 47 481 minecraft:brown_terracotta
setblock 273 47 482 minecraft:bone_block
fill 273 47 483 273 50 483 minecraft:brown_terracotta
setblock 273 47 486 minecraft:brown_terracotta
setblock 273 47 487 minecraft:bone_block
setblock 274 47 466 minecraft:bone_block
fill 274 47 467 275 49 467 minecraft:brown_terracotta
setblock 274 47 481 minecraft:bone_block
fill 274 47 482 274 50 482 minecraft:brown_terracotta
setblock 274 47 485 minecraft:brown_terracotta
setblock 274 47 486 minecraft:bone_block
fill 274 47 487 274 50 487 minecraft:brown_terracotta
fill 274 47 489 274 48 489 minecraft:brown_terracotta
fill 274 47 503 274 49 503 minecraft:brown_terracotta
setblock 275 47 464 minecraft:brown_terracotta
setblock 275 47 465 minecraft:bone_block
fill 275 47 466 275 50 466 minecraft:brown_terracotta
fill 275 47 468 275 47 469 minecraft:brown_terracotta
setblock 275 47 470 minecraft:bone_block
fill 275 47 471 275 50 471 minecraft:brown_terracotta
setblock 275 47 475 minecraft:bone_block
fill 275 47 476 275 50 476 minecraft:brown_terracotta
setblock 275 47 480 minecraft:bone_block
fill 275 47 481 275 50 481 minecraft:brown_terracotta
setblock 275 47 485 minecraft:bone_block
fill 275 47 486 275 50 486 minecraft:brown_terracotta
setblock 275 47 490 minecraft:bone_block
fill 275 47 491 275 50 491 minecraft:brown_terracotta
setblock 276 47 464 minecraft:bone_block
fill 276 47 465 276 50 465 minecraft:brown_terracotta
setblock 276 47 469 minecraft:bone_block
fill 276 47 470 276 50 470 minecraft:brown_terracotta
setblock 276 47 474 minecraft:bone_block
fill 276 47 475 276 50 475 minecraft:brown_terracotta
setblock 276 47 479 minecraft:bone_block
fill 276 47 480 276 50 480 minecraft:brown_terracotta
setblock 276 47 484 minecraft:bone_block
fill 276 47 485 276 50 485 minecraft:brown_terracotta
setblock 276 47 489 minecraft:bone_block
fill 276 47 490 276 50 490 minecraft:brown_terracotta
setblock 276 47 494 minecraft:bone_block
setblock 276 47 499 minecraft:bone_block
fill 276 47 500 276 50 500 minecraft:brown_terracotta
setblock 276 47 504 minecraft:bone_block
fill 236 48 464 236 51 464 minecraft:brown_terracotta
setblock 236 48 468 minecraft:bone_block
fill 236 48 469 236 51 469 minecraft:brown_terracotta
setblock 236 48 473 minecraft:bone_block
fill 236 48 474 236 51 474 minecraft:brown_terracotta
setblock 236 48 478 minecraft:bone_block
fill 236 48 479 236 51 479 minecraft:brown_terracotta
setblock 236 48 483 minecraft:bone_block
fill 236 48 484 236 51 484 minecraft:brown_terracotta
setblock 236 48 487 minecraft:brown_terracotta
setblock 236 48 488 minecraft:bone_block
fill 236 48 489 237 50 489 minecraft:brown_terracotta
setblock 236 48 493 minecraft:bone_block
setblock 236 48 498 minecraft:bone_block
fill 236 48 499 236 51 499 minecraft:brown_terracotta
setblock 236 48 503 minecraft:bone_block
fill 236 48 504 239 48 504 minecraft:brown_terracotta
setblock 237 48 467 minecraft:bone_block
fill 237 48 468 237 51 468 minecraft:brown_terracotta
setblock 237 48 472 minecraft:bone_block
fill 237 48 473 237 51 473 minecraft:brown_terracotta
setblock 237 48 477 minecraft:bone_block
setblock 237 48 478 minecraft:brown_terracotta
setblock 237 48 482 minecraft:bone_block
fill 237 48 483 237 50 483 minecraft:brown_terracotta
setblock 237 48 487 minecraft:bone_block
fill 237 48 488 237 51 488 minecraft:brown_terracotta
setblock 237 48 502 minecraft:bone_block
fill 237 48 503 237 51 503 minecraft:brown_terracotta
setblock 238 48 466 minecraft:bone_block
fill 238 48 467 238 51 467 minecraft:brown_terracotta
setblock 238 48 470 minecraft:brown_terracotta
setblock 239 48 465 minecraft:bone_block
fill 239 48 466 239 51 466 minecraft:brown_terracotta
setblock 240 48 464 minecraft:bone_block
fill 240 48 465 240 51 465 minecraft:brown_terracotta
setblock 240 48 504 minecraft:bone_block
fill 241 48 464 241 51 464 minecraft:brown_terracotta
setblock 241 48 503 minecraft:bone_block
fill 241 48 504 241 51 504 minecraft:brown_terracotta
fill 242 48 503 242 49 503 minecraft:brown_terracotta
setblock 244 48 465 minecraft:bone_block
fill 244 48 503 245 48 503 minecraft:brown_terracotta
setblock 245 48 464 minecraft:bone_block
fill 245 48 465 248 48 465 minecraft:brown_terracotta
setblock 245 48 504 minecraft:bone_block
fill 246 48 464 246 51 464 minecraft:brown_terracotta
setblock 246 48 503 minecraft:bone_block
fill 246 48 504 246 51 504 minecraft:brown_terracotta
fill 247 48 503 247 51 503 minecraft:brown_terracotta
setblock 249 48 465 minecraft:bone_block
setblock 250 48 464 minecraft:bone_block
fill 250 48 465 250 51 465 minecraft:brown_terracotta
fill 250 48 502 250 49 502 minecraft:brown_terracotta
setblock 250 48 504 minecraft:bone_block
fill 251 48 464 251 51 464 minecraft:brown_terracotta
fill 251 48 466 252 48 466 minecraft:brown_terracotta
setblock 251 48 503 minecraft:bone_block
fill 251 48 504 251 51 504 minecraft:brown_terracotta
setblock 252 48 502 minecraft:bone_block
fill 252 48 503 252 51 503 minecraft:brown_terracotta
setblock 253 48 466 minecraft:bone_block
fill 253 48 502 253 51 502 minecraft:brown_terracotta
setblock 254 48 465 minecraft:bone_block
fill 254 48 466 256 49 466 minecraft:brown_terracotta
setblock 255 48 464 minecraft:bone_block
fill 255 48 465 255 51 465 minecraft:brown_terracotta
setblock 255 48 504 minecraft:bone_block
fill 256 48 464 256 51 464 minecraft:brown_terracotta
setblock 256 48 503 minecraft:bone_block
fill 256 48 504 256 51 504 minecraft:brown_terracotta
setblock 257 48 502 minecraft:bone_block
fill 257 48 503 257 51 503 minecraft:brown_terracotta
setblock 258 48 502 minecraft:brown_terracotta
setblock 259 48 465 minecraft:bone_block
setblock 260 48 464 minecraft:bone_block
setblock 260 48 504 minecraft:bone_block
fill 261 48 464 261 51 464 minecraft:brown_terracotta
fill 261 48 504 261 50 504 minecraft:brown_terracotta
fill 263 48 481 263 59 485 minecraft:bone_block
fill 263 48 499 264 49 499 minecraft:bone_block
fill 264 48 479 264 59 479 minecraft:bone_block
fill 264 48 487 264 59 487 minecraft:bone_block
fill 265 48 478 265 59 478 minecraft:bone_block
fill 265 48 488 265 59 488 minecraft:bone_block
fill 266 48 477 266 59 477 minecraft:bone_block
fill 266 48 489 266 59 489 minecraft:bone_block
fill 267 48 464 269 48 464 minecraft:brown_terracotta
fill 268 48 476 272 59 476 minecraft:bone_block
fill 268 48 488 272 61 488 minecraft:bone_block
fill 268 48 490 272 59 490 minecraft:bone_block
fill 268 48 504 268 49 504 minecraft:brown_terracotta
setblock 270 48 464 minecraft:bone_block
fill 270 48 465 270 51 465 minecraft:brown_terracotta
setblock 270 48 504 minecraft:bone_block
fill 271 48 464 271 51 464 minecraft:brown_terracotta
fill 271 48 504 271 51 504 minecraft:brown_terracotta
setblock 272 48 466 minecraft:brown_terracotta
setblock 273 48 466 minecraft:bone_block
setblock 273 48 481 minecraft:bone_block
fill 273 48 482 273 51 482 minecraft:brown_terracotta
setblock 273 48 486 minecraft:bone_block
fill 273 48 487 273 50 488 minecraft:brown_terracotta
fill 273 48 503 273 50 503 minecraft:brown_terracotta
setblock 274 48 464 minecraft:brown_terracotta
setblock 274 48 465 minecraft:bone_block
fill 274 48 466 274 51 466 minecraft:brown_terracotta
fill 274 48 468 274 48 469 minecraft:brown_terracotta
setblock 274 48 470 minecraft:bone_block
fill 274 48 477 274 50 477 minecraft:brown_terracotta
setblock 274 48 480 minecraft:bone_block
fill 274 48 481 274 51 481 minecraft:brown_terracotta
setblock 274 48 485 minecraft:bone_block
fill 274 48 486 274 51 486 minecraft:brown_terracotta
setblock 274 48 490 minecraft:bone_block
setblock 275 48 464 minecraft:bone_block
fill 275 48 465 275 51 465 minecraft:brown_terracotta
setblock 275 48 468 minecraft:brown_terracotta
setblock 275 48 469 minecraft:bone_block
fill 275 48 470 275 51 470 minecraft:brown_terracotta
setblock 275 48 474 minecraft:bone_block
fill 275 48 475 275 51 475 minecraft:brown_terracotta
setblock 275 48 479 minecraft:bone_block
fill 275 48 480 275 51 480 minecraft:brown_terracotta
setblock 275 48 484 minecraft:bone_block
fill 275 48 485 275 51 485 minecraft:brown_terracotta
setblock 275 48 489 minecraft:bone_block
fill 275 48 490 275 51 490 minecraft:brown_terracotta
fill 275 48 492 275 49 492 minecraft:brown_terracotta
setblock 275 48 504 minecraft:bone_block
fill 276 48 464 276 51 464 minecraft:brown_terracotta
setblock 276 48 468 minecraft:bone_block
fill 276 48 469 276 51 469 minecraft:brown_terracotta
setblock 276 48 473 minecraft:bone_block
fill 276 48 474 276 51 474 minecraft:brown_terracotta
setblock 276 48 478 minecraft:bone_block
fill 276 48 479 276 51 479 minecraft:brown_terracotta
setblock 276 48 483 minecraft:bone_block
fill 276 48 484 276 51 484 minecraft:brown_terracotta
setblock 276 48 488 minecraft:bone_block
fill 276 48 489 276 51 489 minecraft:brown_terracotta
setblock 276 48 493 minecraft:bone_block
fill 276 48 494 276 50 495 minecraft:brown_terracotta
setblock 276 48 499 minecraft:brown_terracotta
setblock 276 48 503 minecraft:bone_block
fill 276 48 504 276 51 504 minecraft:brown_terracotta
setblock 236 49 467 minecraft:bone_block
fill 236 49 468 236 52 468 minecraft:brown_terracotta
setblock 236 49 472 minecraft:bone_block
fill 236 49 473 236 52 473 minecraft:brown_terracotta
setblock 236 49 477 minecraft:bone_block
fill 236 49 478 236 52 478 minecraft:brown_terracotta
setblock 236 49 482 minecraft:bone_block
fill 236 49 483 236 52 483 minecraft:brown_terracotta
setblock 236 49 487 minecraft:bone_block
fill 236 49 488 236 52 488 minecraft:brown_terracotta
fill 236 49 490 236 49 491 minecraft:brown_terracotta
setblock 236 49 492 minecraft:bone_block
fill 236 49 493 236 51 494 minecraft:brown_terracotta
fill 236 49 498 236 51 498 minecraft:brown_terracotta
setblock 236 49 502 minecraft:bone_block
fill 236 49 503 236 51 504 minecraft:brown_terracotta
setblock 237 49 466 minecraft:bone_block
fill 237 49 467 237 52 467 minecraft:brown_terracotta
setblock 237 49 471 minecraft:bone_block
fill 237 49 472 237 52 472 minecraft:brown_terracotta
setblock 237 49 481 minecraft:bone_block
fill 237 49 482 237 50 482 minecraft:brown_terracotta
setblock 237 49 486 minecraft:bone_block
fill 237 49 487 237 52 487 minecraft:brown_terracotta
setblock 237 49 490 minecraft:brown_terracotta
fill 237 49 502 237 50 502 minecraft:brown_terracotta
fill 237 49 504 238 49 504 minecraft:brown_terracotta
setblock 238 49 465 minecraft:bone_block
fill 238 49 466 238 52 466 minecraft:brown_terracotta
setblock 238 49 470 minecraft:bone_block
setblock 239 49 464 minecraft:bone_block
fill 239 49 465 239 52 465 minecraft:brown_terracotta
setblock 239 49 504 minecraft:bone_block
fill 240 49 464 240 52 464 minecraft:brown_terracotta
setblock 240 49 503 minecraft:bone_block
fill 240 49 504 240 52 504 minecraft:brown_terracotta
setblock 241 49 503 minecraft:brown_terracotta
setblock 242 49 466 minecraft:bone_block
setblock 243 49 465 minecraft:bone_block
setblock 244 49 464 minecraft:bone_block
fill 244 49 465 247 49 465 minecraft:brown_terracotta
setblock 244 49 503 minecraft:brown_terracotta
setblock 244 49 504 minecraft:bone_block
fill 245 49 464 245 52 464 minecraft:brown_terracotta
setblock 245 49 503 minecraft:bone_block
fill 245 49 504 245 52 504 minecraft:brown_terracotta
fill 246 49 503 246 52 503 minecraft:brown_terracotta
setblock 248 49 465 minecraft:bone_block
setblock 249 49 464 minecraft:bone_block
fill 249 49 465 249 51 466 minecraft:brown_terracotta
setblock 249 49 504 minecraft:bone_block
fill 250 49 464 250 52 464 minecraft:brown_terracotta
fill 250 49 466 251 49 466 minecraft:brown_terracotta
setblock 250 49 503 minecraft:bone_block
fill 250 49 504 250 52 504 minecraft:brown_terracotta
setblock 251 49 502 minecraft:bone_block
fill 251 49 503 251 52 503 minecraft:brown_terracotta
setblock 252 49 466 minecraft:bone_block
fill 252 49 502 252 52 502 minecraft:brown_terracotta
setblock 253 49 465 minecraft:bone_block
fill 253 49 466 253 52 466 minecraft:brown_terracotta
setblock 254 49 464 minecraft:bone_block
fill 254 49 465 254 52 465 minecraft:brown_terracotta
setblock 254 49 504 minecraft:bone_block
fill 255 49 464 255 52 464 minecraft:brown_terracotta
setblock 255 49 503 minecraft:bone_block
fill 255 49 504 255 52 504 minecraft:brown_terracotta
setblock 256 49 502 minecraft:bone_block
fill 256 49 503 256 52 503 minecraft:brown_terracotta
setblock 257 49 502 minecraft:brown_terracotta
setblock 258 49 465 minecraft:bone_block
setblock 259 49 464 minecraft:bone_block
fill 259 49 465 259 50 465 minecraft:brown_terracotta
setblock 259 49 504 minecraft:bone_block
fill 260 49 464 260 51 464 minecraft:brown_terracotta
setblock 260 49 503 minecraft:bone_block
fill 260 49 504 260 51 504 minecraft:brown_terracotta
fill 262 49 480 262 49 482 minecraft:soul_soil
fill 262 49 483 262 58 483 minecraft:bone_block
fill 262 49 484 262 49 486 minecraft:soul_soil
setblock 263 49 464 minecraft:brown_terracotta
fill 263 49 480 263 58 480 minecraft:bone_block
fill 263 49 486 263 58 486 minecraft:bone_block
fill 264 49 478 264 58 478 minecraft:bone_block
fill 264 49 488 264 58 488 minecraft:bone_block
fill 264 49 498 266 50 498 minecraft:bone_block
fill 264 49 500 266 50 500 minecraft:bone_block
fill 265 49 477 265 58 477 minecraft:bone_block
fill 265 49 489 265 58 489 minecraft:bone_block
fill 265 49 499 265 50 499 minecraft:bone_block
fill 266 49 464 268 49 464 minecraft:brown_terracotta
fill 267 49 476 267 58 476 minecraft:bone_block
fill 267 49 489 267 58 490 minecraft:bone_block
fill 268 49 489 272 60 489 minecraft:bone_block
setblock 269 49 464 minecraft:bone_block
fill 269 49 465 269 52 465 minecraft:brown_terracotta
setblock 269 49 504 minecraft:bone_block
fill 270 49 464 270 52 464 minecraft:brown_terracotta
fill 270 49 475 270 58 475 minecraft:bone_block
fill 270 49 491 270 58 491 minecraft:bone_block
fill 270 49 504 270 52 504 minecraft:brown_terracotta
setblock 271 49 466 minecraft:brown_terracotta
setblock 272 49 466 minecraft:bone_block
setblock 273 49 464 minecraft:brown_terracotta
setblock 273 49 465 minecraft:bone_block
fill 273 49 466 273 52 466 minecraft:brown_terracotta
fill 273 49 476 273 58 476 minecraft:bone_block
fill 273 49 481 273 50 481 minecraft:brown_terracotta
setblock 273 49 484 minecraft:brown_terracotta
setblock 273 49 485 minecraft:bone_block
fill 273 49 486 273 52 486 minecraft:brown_terracotta
setblock 273 49 489 minecraft:brown_terracotta
fill 273 49 490 273 50 490 minecraft:bone_block
setblock 274 49 464 minecraft:bone_block
fill 274 49 465 274 52 465 minecraft:brown_terracotta
setblock 274 49 468 minecraft:brown_terracotta
setblock 274 49 469 minecraft:bone_block
fill 274 49 470 274 49 473 minecraft:brown_terracotta
setblock 274 49 474 minecraft:bone_block
fill 274 49 475 274 51 476 minecraft:brown_terracotta
setblock 274 49 479 minecraft:bone_block
fill 274 49 480 274 52 480 minecraft:brown_terracotta
setblock 274 49 484 minecraft:bone_block
fill 274 49 485 274 52 485 minecraft:brown_terracotta
setblock 274 49 489 minecraft:bone_block
fill 274 49 490 274 51 491 minecraft:brown_terracotta
setblock 274 49 504 minecraft:bone_block
fill 275 49 464 275 52 464 minecraft:brown_terracotta
setblock 275 49 468 minecraft:bone_block
fill 275 49 469 275 52 469 minecraft:brown_terracotta
setblock 275 49 472 minecraft:brown_terracotta
setblock 275 49 473 minecraft:bone_block
fill 275 49 474 275 52 474 minecraft:brown_terracotta
setblock 275 49 478 minecraft:bone_block
fill 275 49 479 275 52 479 minecraft:brown_terracotta
setblock 275 49 483 minecraft:bone_block
fill 275 49 484 275 52 484 minecraft:brown_terracotta
setblock 275 49 488 minecraft:bone_block
fill 275 49 489 275 52 489 minecraft:brown_terracotta
setblock 275 49 493 minecraft:bone_block
setblock 275 49 503 minecraft:bone_block
fill 275 49 504 275 52 504 minecraft:brown_terracotta
setblock 276 49 467 minecraft:bone_block
fill 276 49 468 276 52 468 minecraft:brown_terracotta
setblock 276 49 472 minecraft:bone_block
fill 276 49 473 276 52 473 minecraft:brown_terracotta
setblock 276 49 477 minecraft:bone_block
fill 276 49 478 276 52 478 minecraft:brown_terracotta
setblock 276 49 482 minecraft:bone_block
fill 276 49 483 276 52 483 minecraft:brown_terracotta
setblock 276 49 487 minecraft:bone_block
fill 276 49 488 276 52 488 minecraft:brown_terracotta
setblock 276 49 492 minecraft:bone_block
fill 276 49 493 276 52 493 minecraft:brown_terracotta
setblock 276 49 496 minecraft:brown_terracotta
setblock 276 49 502 minecraft:bone_block
fill 276 49 503 276 52 503 minecraft:brown_terracotta
setblock 236 50 466 minecraft:bone_block
fill 236 50 467 236 53 467 minecraft:brown_terracotta
setblock 236 50 471 minecraft:bone_block
fill 236 50 472 236 53 472 minecraft:brown_terracotta
setblock 236 50 476 minecraft:bone_block
fill 236 50 477 236 53 477 minecraft:brown_terracotta
setblock 236 50 481 minecraft:bone_block
fill 236 50 482 236 52 482 minecraft:brown_terracotta
setblock 236 50 486 minecraft:bone_block
fill 236 50 487 236 53 487 minecraft:brown_terracotta
setblock 236 50 490 minecraft:brown_terracotta
setblock 236 50 491 minecraft:bone_block
fill 236 50 492 236 53 492 minecraft:brown_terracotta
setblock 236 50 495 minecraft:brown_terracotta
setblock 236 50 496 minecraft:bone_block
fill 236 50 497 236 51 497 minecraft:brown_terracotta
setblock 236 50 501 minecraft:bone_block
fill 236 50 502 236 53 502 minecraft:brown_terracotta
setblock 237 50 465 minecraft:bone_block
fill 237 50 466 237 53 466 minecraft:brown_terracotta
setblock 237 50 469 minecraft:brown_terracotta
setblock 237 50 470 minecraft:bone_block
fill 237 50 471 237 53 471 minecraft:brown_terracotta
setblock 237 50 481 minecraft:brown_terracotta
setblock 237 50 485 minecraft:bone_block
fill 237 50 486 237 51 486 minecraft:brown_terracotta
setblock 237 50 490 minecraft:bone_block
setblock 237 50 504 minecraft:brown_terracotta
setblock 238 50 464 minecraft:bone_block
fill 238 50 465 238 53 465 minecraft:brown_terracotta
setblock 238 50 469 minecraft:bone_block
fill 238 50 470 238 52 470 minecraft:brown_terracotta
setblock 238 50 504 minecraft:bone_block
fill 239 50 464 239 53 464 minecraft:brown_terracotta
setblock 239 50 503 minecraft:bone_block
fill 239 50 504 239 53 504 minecraft:brown_terracotta
setblock 240 50 466 minecraft:brown_terracotta
setblock 240 50 503 minecraft:brown_terracotta
setblock 241 50 466 minecraft:bone_block
setblock 242 50 465 minecraft:bone_block
setblock 242 50 466 minecraft:brown_terracotta
setblock 243 50 464 minecraft:bone_block
fill 243 50 465 246 50 465 minecraft:brown_terracotta
setblock 243 50 504 minecraft:bone_block
fill 244 50 464 244 53 464 minecraft:brown_terracotta
fill 244 50 504 244 53 504 minecraft:brown_terracotta
fill 245 50 503 245 51 503 minecraft:brown_terracotta
setblock 247 50 465 minecraft:bone_block
setblock 248 50 464 minecraft:bone_block
fill 248 50 465 248 52 466 minecraft:brown_terracotta
setblock 248 50 504 minecraft:bone_block
fill 249 50 464 249 53 464 minecraft:brown_terracotta
setblock 249 50 502 minecraft:brown_terracotta
setblock 249 50 503 minecraft:bone_block
fill 249 50 504 249 53 504 minecraft:brown_terracotta
setblock 250 50 466 minecraft:brown_terracotta
setblock 250 50 502 minecraft:bone_block
fill 250 50 503 250 53 503 minecraft:brown_terracotta
setblock 251 50 466 minecraft:bone_block
fill 251 50 502 251 52 502 minecraft:brown_terracotta
setblock 252 50 465 minecraft:bone_block
fill 252 50 466 252 53 466 minecraft:brown_terracotta
setblock 253 50 464 minecraft:bone_block
fill 253 50 465 253 53 465 minecraft:brown_terracotta
setblock 253 50 504 minecraft:bone_block
fill 254 50 464 254 53 464 minecraft:brown_terracotta
fill 254 50 466 255 50 466 minecraft:brown_terracotta
setblock 254 50 503 minecraft:bone_block
fill 254 50 504 254 53 504 minecraft:brown_terracotta
setblock 255 50 502 minecraft:bone_block
fill 255 50 503 255 53 503 minecraft:brown_terracotta
setblock 256 50 466 minecraft:bone_block
setblock 256 50 502 minecraft:brown_terracotta
setblock 257 50 465 minecraft:bone_block
setblock 258 50 464 minecraft:bone_block
fill 258 50 465 258 51 465 minecraft:brown_terracotta
setblock 258 50 504 minecraft:bone_block
fill 259 50 464 259 52 464 minecraft:brown_terracotta
setblock 259 50 503 minecraft:bone_block
fill 259 50 504 259 52 504 minecraft:brown_terracotta
setblock 262 50 480 minecraft:soul_soil
fill 262 50 481 262 57 482 minecraft:bone_block
fill 262 50 484 262 57 485 minecraft:bone_block
setblock 262 50 486 minecraft:soul_soil
fill 263 50 479 263 57 479 minecraft:bone_block
fill 263 50 487 263 57 487 minecraft:bone_block
fill 265 50 464 267 50 464 minecraft:brown_terracotta
fill 266 50 476 266 57 476 minecraft:bone_block
fill 266 50 490 266 57 490 minecraft:bone_block
setblock 268 50 464 minecraft:bone_block
fill 268 50 465 268 53 465 minecraft:brown_terracotta
fill 268 50 475 269 57 475 minecraft:bone_block
fill 268 50 491 269 57 491 minecraft:bone_block
setblock 268 50 504 minecraft:bone_block
fill 269 50 464 269 53 464 minecraft:brown_terracotta
fill 269 50 504 269 52 504 minecraft:brown_terracotta
setblock 270 50 466 minecraft:brown_terracotta
setblock 270 50 474 minecraft:soul_soil
setblock 271 50 465 minecraft:brown_terracotta
setblock 271 50 466 minecraft:bone_block
fill 271 50 475 272 57 475 minecraft:bone_block
fill 271 50 491 272 57 491 minecraft:bone_block
setblock 272 50 465 minecraft:bone_block
fill 272 50 466 272 52 467 minecraft:brown_terracotta
setblock 272 50 472 minecraft:soul_soil
setblock 273 50 464 minecraft:bone_block
fill 273 50 465 273 53 465 minecraft:brown_terracotta
fill 273 50 467 273 50 468 minecraft:brown_terracotta
setblock 273 50 469 minecraft:bone_block
setblock 273 50 484 minecraft:bone_block
fill 273 50 485 273 52 485 minecraft:brown_terracotta
setblock 273 50 489 minecraft:bone_block
setblock 273 50 504 minecraft:bone_block
fill 274 50 464 274 53 464 minecraft:brown_terracotta
setblock 274 50 467 minecraft:brown_terracotta
setblock 274 50 468 minecraft:bone_block
fill 274 50 469 274 50 472 minecraft:brown_terracotta
setblock 274 50 473 minecraft:bone_block
fill 274 50 474 274 53 474 minecraft:brown_terracotta
setblock 274 50 478 minecraft:bone_block
fill 274 50 479 274 52 479 minecraft:brown_terracotta
setblock 274 50 483 minecraft:bone_block
fill 274 50 484 274 53 484 minecraft:brown_terracotta
setblock 274 50 488 minecraft:bone_block
fill 274 50 489 274 53 489 minecraft:brown_terracotta
setblock 274 50 503 minecraft:bone_block
fill 274 50 504 274 53 504 minecraft:brown_terracotta
setblock 275 50 467 minecraft:bone_block
fill 275 50 468 275 53 468 minecraft:brown_terracotta
setblock 275 50 472 minecraft:bone_block
fill 275 50 473 275 53 473 minecraft:brown_terracotta
setblock 275 50 477 minecraft:bone_block
fill 275 50 478 275 53 478 minecraft:brown_terracotta
setblock 275 50 482 minecraft:bone_block
fill 275 50 483 275 53 483 minecraft:brown_terracotta
setblock 275 50 487 minecraft:bone_block
fill 275 50 488 275 53 488 minecraft:brown_terracotta
setblock 275 50 492 minecraft:bone_block
fill 275 50 493 275 53 493 minecraft:brown_terracotta
setblock 275 50 503 minecraft:brown_terracotta
setblock 276 50 466 minecraft:bone_block
fill 276 50 467 276 53 467 minecraft:brown_terracotta
setblock 276 50 471 minecraft:bone_block
fill 276 50 472 276 53 472 minecraft:brown_terracotta
setblock 276 50 476 minecraft:bone_block
fill 276 50 477 276 53 477 minecraft:brown_terracotta
setblock 276 50 481 minecraft:bone_block
fill 276 50 482 276 53 482 minecraft:brown_terracotta
setblock 276 50 486 minecraft:bone_block
fill 276 50 487 276 53 487 minecraft:brown_terracotta
setblock 276 50 491 minecraft:bone_block
fill 276 50 492 276 53 492 minecraft:brown_terracotta
setblock 276 50 496 minecraft:bone_block
setblock 276 50 501 minecraft:bone_block
fill 276 50 502 276 51 502 minecraft:brown_terracotta
setblock 236 51 465 minecraft:bone_block
fill 236 51 466 236 54 466 minecraft:brown_terracotta
setblock 236 51 470 minecraft:bone_block
fill 236 51 471 236 54 471 minecraft:brown_terracotta
setblock 236 51 475 minecraft:bone_block
fill 236 51 476 236 54 476 minecraft:brown_terracotta
setblock 236 51 480 minecraft:bone_block
fill 236 51 481 236 52 481 minecraft:brown_terracotta
setblock 236 51 485 minecraft:bone_block
fill 236 51 486 236 54 486 minecraft:brown_terracotta
setblock 236 51 489 minecraft:brown_terracotta
setblock 236 51 490 minecraft:bone_block
fill 236 51 491 236 54 491 minecraft:brown_terracotta
setblock 236 51 495 minecraft:bone_block
fill 236 51 496 236 52 496 minecraft:brown_terracotta
setblock 236 51 500 minecraft:bone_block
fill 236 51 501 236 53 501 minecraft:brown_terracotta
setblock 237 51 464 minecraft:bone_block
fill 237 51 465 237 54 465 minecraft:brown_terracotta
setblock 237 51 469 minecraft:bone_block
fill 237 51 470 237 54 470 minecraft:brown_terracotta
setblock 237 51 474 minecraft:bone_block
setblock 237 51 484 minecraft:bone_block
setblock 237 51 485 minecraft:brown_terracotta
setblock 237 51 489 minecraft:bone_block
fill 237 51 490 237 52 490 minecraft:brown_terracotta
setblock 237 51 504 minecraft:bone_block
fill 238 51 464 238 54 464 minecraft:brown_terracotta
setblock 238 51 468 minecraft:bone_block
fill 238 51 469 238 53 469 minecraft:brown_terracotta
setblock 238 51 474 minecraft:light[level=12]
setblock 238 51 482 minecraft:light[level=12]
setblock 238 51 490 minecraft:light[level=12]
setblock 238 51 498 minecraft:light[level=12]
setblock 238 51 503 minecraft:bone_block
fill 238 51 504 238 54 504 minecraft:brown_terracotta
setblock 240 51 466 minecraft:bone_block
setblock 241 51 465 minecraft:bone_block
setblock 241 51 466 minecraft:brown_terracotta
setblock 242 51 464 minecraft:bone_block
fill 242 51 465 245 51 465 minecraft:brown_terracotta
setblock 242 51 504 minecraft:bone_block
fill 243 51 464 243 54 464 minecraft:brown_terracotta
fill 243 51 504 243 54 504 minecraft:brown_terracotta
setblock 246 51 465 minecraft:bone_block
setblock 246 51 474 minecraft:light[level=12]
setblock 246 51 482 minecraft:light[level=12]
setblock 246 51 490 minecraft:light[level=12]
setblock 246 51 498 minecraft:light[level=12]
setblock 247 51 464 minecraft:bone_block
fill 247 51 465 247 52 466 minecraft:brown_terracotta
setblock 247 51 504 minecraft:bone_block
fill 248 51 464 248 54 464 minecraft:brown_terracotta
setblock 248 51 503 minecraft:bone_block
fill 248 51 504 248 54 504 minecraft:brown_terracotta
setblock 249 51 502 minecraft:bone_block
fill 249 51 503 249 54 503 minecraft:brown_terracotta
setblock 250 51 466 minecraft:bone_block
fill 250 51 502 250 52 502 minecraft:brown_terracotta
setblock 251 51 465 minecraft:bone_block
fill 251 51 466 251 53 466 minecraft:brown_terracotta
setblock 252 51 464 minecraft:bone_block
fill 252 51 465 252 54 465 minecraft:brown_terracotta
setblock 252 51 504 minecraft:bone_block
fill 253 51 464 253 54 464 minecraft:brown_terracotta
setblock 253 51 503 minecraft:bone_block
fill 253 51 504 253 54 504 minecraft:brown_terracotta
setblock 254 51 466 minecraft:brown_terracotta
setblock 254 51 474 minecraft:light[level=12]
setblock 254 51 490 minecraft:light[level=12]
setblock 254 51 498 minecraft:light[level=12]
setblock 254 51 502 minecraft:bone_block
fill 254 51 503 254 54 503 minecraft:brown_terracotta
setblock 255 51 466 minecraft:bone_block
setblock 255 51 502 minecraft:brown_terracotta
setblock 256 51 465 minecraft:bone_block
setblock 257 51 464 minecraft:bone_block
fill 257 51 465 257 52 465 minecraft:brown_terracotta
setblock 257 51 504 minecraft:bone_block
fill 258 51 464 258 53 464 minecraft:brown_terracotta
setblock 258 51 503 minecraft:bone_block
fill 258 51 504 258 53 504 minecraft:brown_terracotta
setblock 262 51 466 minecraft:light[level=12]
setblock 262 51 474 minecraft:light[level=12]
fill 262 51 480 262 56 480 minecraft:bone_block
fill 262 51 486 262 56 486 minecraft:bone_block
setblock 262 51 490 minecraft:light[level=12]
setblock 262 51 498 minecraft:light[level=12]
fill 263 51 478 263 56 478 minecraft:bone_block
fill 263 51 488 263 56 488 minecraft:bone_block
fill 264 51 477 264 56 477 minecraft:bone_block
fill 264 51 489 264 57 489 minecraft:bone_block
fill 265 51 464 266 51 464 minecraft:brown_terracotta
fill 265 51 476 265 56 476 minecraft:bone_block
fill 265 51 490 265 56 490 minecraft:bone_block
setblock 267 51 464 minecraft:bone_block
fill 267 51 475 267 56 475 minecraft:bone_block
fill 267 51 491 267 56 491 minecraft:bone_block
fill 268 51 464 268 54 464 minecraft:brown_terracotta
setblock 268 51 504 minecraft:brown_terracotta
setblock 269 51 466 minecraft:brown_terracotta
setblock 270 51 466 minecraft:bone_block
setblock 270 51 474 minecraft:light[level=12]
setblock 270 51 498 minecraft:light[level=12]
setblock 271 51 465 minecraft:bone_block
fill 271 51 466 271 54 466 minecraft:brown_terracotta
setblock 272 51 464 minecraft:bone_block
fill 272 51 465 272 54 465 minecraft:brown_terracotta
setblock 272 51 504 minecraft:bone_block
fill 273 51 464 273 54 464 minecraft:brown_terracotta
setblock 273 51 467 minecraft:brown_terracotta
setblock 273 51 468 minecraft:bone_block
fill 273 51 469 274 51 471 minecraft:brown_terracotta
fill 273 51 475 273 56 475 minecraft:bone_block
fill 273 51 481 273 62 481 minecraft:bone_block
fill 273 51 483 273 62 483 minecraft:bone_block
fill 273 51 484 273 52 484 minecraft:brown_terracotta
setblock 273 51 487 minecraft:brown_terracotta
setblock 273 51 488 minecraft:bone_block
fill 273 51 489 273 51 490 minecraft:brown_terracotta
fill 273 51 491 273 56 491 minecraft:bone_block
fill 273 51 504 273 54 504 minecraft:brown_terracotta
setblock 274 51 467 minecraft:bone_block
fill 274 51 468 274 54 468 minecraft:brown_terracotta
setblock 274 51 472 minecraft:bone_block
fill 274 51 473 274 54 473 minecraft:brown_terracotta
setblock 274 51 477 minecraft:bone_block
fill 274 51 478 274 52 478 minecraft:brown_terracotta
setblock 274 51 482 minecraft:bone_block
fill 274 51 483 274 53 483 minecraft:brown_terracotta
setblock 274 51 487 minecraft:bone_block
fill 274 51 488 274 54 488 minecraft:brown_terracotta
setblock 274 51 492 minecraft:bone_block
setblock 275 51 466 minecraft:bone_block
fill 275 51 467 275 54 467 minecraft:brown_terracotta
setblock 275 51 471 minecraft:bone_block
fill 275 51 472 275 54 472 minecraft:brown_terracotta
setblock 275 51 476 minecraft:bone_block
fill 275 51 477 275 54 477 minecraft:brown_terracotta
setblock 275 51 481 minecraft:bone_block
fill 275 51 482 275 53 482 minecraft:brown_terracotta
setblock 275 51 486 minecraft:bone_block
fill 275 51 487 275 54 487 minecraft:brown_terracotta
setblock 275 51 491 minecraft:bone_block
fill 275 51 492 275 54 492 minecraft:brown_terracotta
setblock 276 51 465 minecraft:bone_block
fill 276 51 466 276 54 466 minecraft:brown_terracotta
setblock 276 51 470 minecraft:bone_block
fill 276 51 471 276 54 471 minecraft:brown_terracotta
setblock 276 51 475 minecraft:bone_block
fill 276 51 476 276 54 476 minecraft:brown_terracotta
setblock 276 51 480 minecraft:bone_block
fill 276 51 481 276 54 481 minecraft:brown_terracotta
setblock 276 51 485 minecraft:bone_block
fill 276 51 486 276 54 486 minecraft:brown_terracotta
setblock 276 51 490 minecraft:bone_block
fill 276 51 491 276 54 491 minecraft:brown_terracotta
setblock 276 51 494 minecraft:brown_terracotta
setblock 276 51 495 minecraft:bone_block
setblock 276 51 496 minecraft:brown_terracotta
setblock 276 51 501 minecraft:brown_terracotta
setblock 236 52 464 minecraft:bone_block
fill 236 52 465 236 55 465 minecraft:brown_terracotta
setblock 236 52 469 minecraft:bone_block
fill 236 52 470 236 55 470 minecraft:brown_terracotta
setblock 236 52 474 minecraft:bone_block
fill 236 52 475 236 55 475 minecraft:brown_terracotta
setblock 236 52 479 minecraft:bone_block
setblock 236 52 480 minecraft:brown_terracotta
setblock 236 52 484 minecraft:bone_block
fill 236 52 485 236 53 485 minecraft:brown_terracotta
setblock 236 52 489 minecraft:bone_block
fill 236 52 490 236 55 490 minecraft:brown_terracotta
setblock 236 52 493 minecraft:brown_terracotta
setblock 236 52 494 minecraft:bone_block
fill 236 52 495 236 54 495 minecraft:brown_terracotta
setblock 236 52 500 minecraft:brown_terracotta
setblock 236 52 503 minecraft:brown_terracotta
setblock 236 52 504 minecraft:bone_block
fill 237 52 464 237 55 464 minecraft:brown_terracotta
setblock 237 52 468 minecraft:bone_block
fill 237 52 469 237 55 469 minecraft:brown_terracotta
setblock 237 52 473 minecraft:bone_block
setblock 237 52 488 minecraft:bone_block
setblock 237 52 489 minecraft:brown_terracotta
fill 237 52 504 237 54 504 minecraft:brown_terracotta
setblock 238 52 467 minecraft:bone_block
fill 238 52 468 238 53 468 minecraft:brown_terracotta
setblock 239 52 466 minecraft:bone_block
setblock 240 52 465 minecraft:bone_block
setblock 240 52 466 minecraft:brown_terracotta
setblock 241 52 464 minecraft:bone_block
fill 241 52 465 244 52 465 minecraft:brown_terracotta
setblock 241 52 504 minecraft:bone_block
fill 242 52 464 242 55 464 minecraft:brown_terracotta
fill 242 52 504 242 54 504 minecraft:brown_terracotta
setblock 245 52 465 minecraft:bone_block
fill 245 52 466 245 54 466 minecraft:soul_soil
setblock 246 52 464 minecraft:bone_block
fill 246 52 465 246 55 465 minecraft:brown_terracotta
fill 246 52 467 246 54 467 minecraft:soul_soil
setblock 246 52 504 minecraft:bone_block
fill 247 52 464 247 55 464 minecraft:brown_terracotta
setblock 247 52 503 minecraft:bone_block
fill 247 52 504 247 55 504 minecraft:brown_terracotta
fill 248 52 503 248 55 503 minecraft:brown_terracotta
setblock 249 52 465 minecraft:brown_terracotta
setblock 249 52 466 minecraft:bone_block
setblock 250 52 465 minecraft:bone_block
fill 250 52 466 250 54 466 minecraft:brown_terracotta
setblock 251 52 464 minecraft:bone_block
fill 251 52 465 251 55 465 minecraft:brown_terracotta
setblock 251 52 504 minecraft:bone_block
fill 252 52 464 252 55 464 minecraft:brown_terracotta
setblock 252 52 503 minecraft:bone_block
fill 252 52 504 252 55 504 minecraft:brown_terracotta
setblock 253 52 502 minecraft:bone_block
fill 253 52 503 253 54 503 minecraft:brown_terracotta
setblock 254 52 466 minecraft:bone_block
setblock 254 52 502 minecraft:brown_terracotta
setblock 255 52 465 minecraft:bone_block
setblock 256 52 464 minecraft:bone_block
fill 256 52 465 256 53 465 minecraft:brown_terracotta
setblock 256 52 504 minecraft:bone_block
fill 257 52 464 257 53 464 minecraft:brown_terracotta
setblock 257 52 503 minecraft:bone_block
fill 257 52 504 257 53 504 minecraft:brown_terracotta
setblock 265 52 464 minecraft:brown_terracotta
setblock 266 52 464 minecraft:bone_block
fill 267 52 464 267 52 465 minecraft:brown_terracotta
setblock 269 52 466 minecraft:bone_block
setblock 270 52 465 minecraft:bone_block
fill 270 52 466 270 55 466 minecraft:brown_terracotta
setblock 271 52 464 minecraft:bone_block
fill 271 52 465 271 55 465 minecraft:brown_terracotta
fill 271 52 467 271 53 467 minecraft:brown_terracotta
setblock 271 52 504 minecraft:bone_block
fill 272 52 464 272 55 464 minecraft:brown_terracotta
fill 272 52 504 272 54 504 minecraft:brown_terracotta
setblock 273 52 467 minecraft:bone_block
fill 273 52 468 273 52 471 minecraft:brown_terracotta
setblock 273 52 472 minecraft:bone_block
fill 273 52 482 273 62 482 minecraft:bone_block
setblock 273 52 487 minecraft:bone_block
fill 273 52 488 273 52 489 minecraft:brown_terracotta
fill 273 52 490 273 58 490 minecraft:bone_block
setblock 274 52 466 minecraft:bone_block
fill 274 52 467 274 55 467 minecraft:brown_terracotta
fill 274 52 469 274 52 470 minecraft:brown_terracotta
setblock 274 52 471 minecraft:bone_block
fill 274 52 472 274 55 472 minecraft:brown_terracotta
setblock 274 52 475 minecraft:brown_terracotta
setblock 274 52 476 minecraft:bone_block
setblock 274 52 477 minecraft:brown_terracotta
fill 274 52 481 274 62 481 minecraft:bone_block
setblock 274 52 482 minecraft:brown_terracotta
setblock 274 52 486 minecraft:bone_block
fill 274 52 487 274 54 487 minecraft:brown_terracotta
setblock 274 52 490 minecraft:brown_terracotta
setblock 274 52 491 minecraft:bone_block
setblock 274 52 492 minecraft:brown_terracotta
setblock 275 52 465 minecraft:bone_block
fill 275 52 466 275 55 466 minecraft:brown_terracotta
setblock 275 52 470 minecraft:bone_block
fill 275 52 471 275 55 471 minecraft:brown_terracotta
setblock 275 52 475 minecraft:bone_block
fill 275 52 476 275 55 476 minecraft:brown_terracotta
setblock 275 52 480 minecraft:bone_block
fill 275 52 481 275 53 481 minecraft:brown_terracotta
setblock 275 52 485 minecraft:bone_block
fill 275 52 486 275 54 486 minecraft:brown_terracotta
setblock 275 52 490 minecraft:bone_block
fill 275 52 491 275 55 491 minecraft:brown_terracotta
setblock 276 52 464 minecraft:bone_block
fill 276 52 465 276 55 465 minecraft:brown_terracotta
setblock 276 52 469 minecraft:bone_block
fill 276 52 470 276 55 470 minecraft:brown_terracotta
setblock 276 52 474 minecraft:bone_block
fill 276 52 475 276 55 475 minecraft:brown_terracotta
setblock 276 52 479 minecraft:bone_block
fill 276 52 480 276 54 480 minecraft:brown_terracotta
setblock 276 52 484 minecraft:bone_block
fill 276 52 485 276 55 485 minecraft:brown_terracotta
setblock 276 52 489 minecraft:bone_block
fill 276 52 490 276 55 490 minecraft:brown_terracotta
setblock 276 52 494 minecraft:bone_block
fill 276 52 495 276 53 495 minecraft:brown_terracotta
setblock 276 52 504 minecraft:bone_block
fill 236 53 464 236 56 464 minecraft:brown_terracotta
setblock 236 53 468 minecraft:bone_block
fill 236 53 469 236 56 469 minecraft:brown_terracotta
setblock 236 53 473 minecraft:bone_block
fill 236 53 474 236 56 474 minecraft:brown_terracotta
setblock 236 53 483 minecraft:bone_block
setblock 236 53 484 minecraft:brown_terracotta
setblock 236 53 488 minecraft:bone_block
fill 236 53 489 236 55 489 minecraft:brown_terracotta
setblock 236 53 493 minecraft:bone_block
fill 236 53 494 236 56 494 minecraft:brown_terracotta
setblock 236 53 503 minecraft:bone_block
fill 236 53 504 236 55 504 minecraft:brown_terracotta
setblock 237 53 467 minecraft:bone_block
fill 237 53 468 237 56 468 minecraft:brown_terracotta
setblock 237 53 472 minecraft:bone_block
setblock 237 53 473 minecraft:brown_terracotta
setblock 238 53 466 minecraft:bone_block
setblock 238 53 467 minecraft:brown_terracotta
setblock 239 53 465 minecraft:bone_block
setblock 239 53 466 minecraft:brown_terracotta
setblock 240 53 464 minecraft:bone_block
fill 240 53 465 243 53 465 minecraft:brown_terracotta
setblock 240 53 504 minecraft:bone_block
fill 241 53 464 241 55 464 minecraft:brown_terracotta
setblock 241 53 504 minecraft:brown_terracotta
setblock 244 53 465 minecraft:bone_block
setblock 245 53 464 minecraft:bone_block
fill 245 53 465 245 54 465 minecraft:brown_terracotta
setblock 245 53 504 minecraft:bone_block
fill 246 53 464 246 56 464 minecraft:brown_terracotta
fill 246 53 504 246 56 504 minecraft:brown_terracotta
fill 247 53 465 248 53 465 minecraft:brown_terracotta
fill 247 53 466 247 54 466 minecraft:soul_soil
fill 247 53 503 247 54 503 minecraft:brown_terracotta
setblock 248 53 466 minecraft:bone_block
setblock 249 53 465 minecraft:bone_block
setblock 249 53 466 minecraft:brown_terracotta
setblock 250 53 464 minecraft:bone_block
fill 250 53 465 250 55 465 minecraft:brown_terracotta
setblock 250 53 504 minecraft:bone_block
fill 251 53 464 251 56 464 minecraft:brown_terracotta
setblock 251 53 503 minecraft:bone_block
fill 251 53 504 251 56 504 minecraft:brown_terracotta
fill 252 53 503 252 55 503 minecraft:brown_terracotta
setblock 253 53 466 minecraft:bone_block
setblock 254 53 465 minecraft:bone_block
setblock 255 53 464 minecraft:bone_block
setblock 255 53 465 minecraft:brown_terracotta
setblock 255 53 504 minecraft:bone_block
fill 256 53 464 256 54 464 minecraft:brown_terracotta
fill 256 53 504 256 54 504 minecraft:brown_terracotta
fill 262 53 479 262 54 479 minecraft:bone_block
fill 262 53 487 262 54 487 minecraft:bone_block
fill 266 53 464 267 54 464 minecraft:brown_terracotta
fill 266 53 475 266 54 475 minecraft:bone_block
fill 266 53 491 266 54 491 minecraft:bone_block
setblock 269 53 465 minecraft:bone_block
fill 269 53 466 269 54 466 minecraft:brown_terracotta
setblock 270 53 464 minecraft:bone_block
fill 270 53 465 270 56 465 minecraft:brown_terracotta
setblock 270 53 504 minecraft:bone_block
fill 271 53 464 271 56 464 minecraft:brown_terracotta
fill 271 53 504 271 54 504 minecraft:brown_terracotta
setblock 272 53 466 minecraft:brown_terracotta
setblock 272 53 467 minecraft:bone_block
setblock 273 53 466 minecraft:bone_block
fill 273 53 467 273 53 470 minecraft:brown_terracotta
setblock 273 53 471 minecraft:bone_block
fill 273 53 472 273 55 472 minecraft:brown_terracotta
fill 273 53 484 273 62 486 minecraft:bone_block
fill 273 53 487 273 53 488 minecraft:brown_terracotta
fill 273 53 489 273 60 489 minecraft:bone_block
setblock 274 53 465 minecraft:bone_block
fill 274 53 466 274 55 466 minecraft:brown_terracotta
setblock 274 53 469 minecraft:brown_terracotta
setblock 274 53 470 minecraft:bone_block
fill 274 53 471 274 56 471 minecraft:brown_terracotta
setblock 274 53 475 minecraft:bone_block
setblock 274 53 476 minecraft:brown_terracotta
fill 274 53 477 274 59 480 minecraft:bone_block
fill 274 53 482 274 62 482 minecraft:bone_block
fill 274 53 485 274 62 485 minecraft:bone_block
fill 274 53 486 274 54 486 minecraft:brown_terracotta
setblock 274 53 490 minecraft:bone_block
setblock 274 53 491 minecraft:brown_terracotta
setblock 275 53 464 minecraft:bone_block
fill 275 53 465 275 56 465 minecraft:brown_terracotta
setblock 275 53 469 minecraft:bone_block
fill 275 53 470 275 56 470 minecraft:brown_terracotta
setblock 275 53 474 minecraft:bone_block
fill 275 53 475 275 56 475 minecraft:brown_terracotta
fill 275 53 479 275 60 479 minecraft:bone_block
setblock 275 53 480 minecraft:brown_terracotta
setblock 275 53 484 minecraft:bone_block
fill 275 53 485 275 54 485 minecraft:brown_terracotta
setblock 275 53 489 minecraft:bone_block
fill 275 53 490 275 55 490 minecraft:brown_terracotta
setblock 275 53 504 minecraft:bone_block
fill 276 53 464 276 56 464 minecraft:brown_terracotta
setblock 276 53 468 minecraft:bone_block
fill 276 53 469 276 56 469 minecraft:brown_terracotta
setblock 276 53 473 minecraft:bone_block
fill 276 53 474 276 56 474 minecraft:brown_terracotta
setblock 276 53 478 minecraft:bone_block
fill 276 53 479 276 55 479 minecraft:brown_terracotta
setblock 276 53 483 minecraft:bone_block
fill 276 53 484 276 55 484 minecraft:brown_terracotta
setblock 276 53 488 minecraft:bone_block
fill 276 53 489 276 56 489 minecraft:brown_terracotta
setblock 276 53 493 minecraft:bone_block
fill 276 53 494 276 54 494 minecraft:brown_terracotta
setblock 276 53 504 minecraft:brown_terracotta
setblock 236 54 467 minecraft:bone_block
fill 236 54 468 236 57 468 minecraft:brown_terracotta
setblock 236 54 472 minecraft:bone_block
fill 236 54 473 236 57 473 minecraft:brown_terracotta
setblock 236 54 487 minecraft:bone_block
fill 236 54 488 236 55 488 minecraft:brown_terracotta
setblock 236 54 492 minecraft:bone_block
fill 236 54 493 236 56 493 minecraft:brown_terracotta
setblock 236 54 503 minecraft:brown_terracotta
setblock 237 54 466 minecraft:bone_block
fill 237 54 467 237 56 467 minecraft:brown_terracotta
setblock 237 54 471 minecraft:bone_block
setblock 237 54 472 minecraft:brown_terracotta
setblock 238 54 465 minecraft:bone_block
setblock 239 54 464 minecraft:bone_block
fill 239 54 465 241 54 465 minecraft:brown_terracotta
setblock 239 54 504 minecraft:bone_block
fill 240 54 464 240 55 464 minecraft:brown_terracotta
setblock 244 54 464 minecraft:bone_block
setblock 244 54 465 minecraft:brown_terracotta
setblock 244 54 504 minecraft:bone_block
fill 245 54 464 245 57 464 minecraft:brown_terracotta
fill 245 54 504 245 57 504 minecraft:brown_terracotta
setblock 247 54 465 minecraft:brown_terracotta
setblock 248 54 465 minecraft:bone_block
setblock 249 54 464 minecraft:bone_block
fill 249 54 465 249 56 465 minecraft:brown_terracotta
setblock 249 54 504 minecraft:bone_block
fill 250 54 464 250 57 464 minecraft:brown_terracotta
setblock 250 54 503 minecraft:bone_block
fill 250 54 504 250 57 504 minecraft:brown_terracotta
fill 251 54 503 251 55 503 minecraft:brown_terracotta
setblock 253 54 465 minecraft:bone_block
setblock 254 54 464 minecraft:bone_block
setblock 254 54 465 minecraft:brown_terracotta
setblock 254 54 504 minecraft:bone_block
setblock 255 54 464 minecraft:brown_terracotta
fill 255 54 504 255 55 504 minecraft:brown_terracotta
setblock 268 54 465 minecraft:bone_block
setblock 269 54 464 minecraft:bone_block
fill 269 54 465 269 57 465 minecraft:brown_terracotta
fill 270 54 464 270 57 464 minecraft:brown_terracotta
setblock 272 54 466 minecraft:bone_block
fill 272 54 467 273 54 467 minecraft:brown_terracotta
setblock 273 54 465 minecraft:bone_block
fill 273 54 466 273 56 466 minecraft:brown_terracotta
fill 273 54 468 273 54 469 minecraft:brown_terracotta
setblock 273 54 470 minecraft:bone_block
fill 273 54 471 273 56 471 minecraft:brown_terracotta
fill 273 54 487 273 61 488 minecraft:bone_block
setblock 274 54 464 minecraft:bone_block
fill 274 54 465 274 57 465 minecraft:brown_terracotta
setblock 274 54 469 minecraft:bone_block
fill 274 54 470 274 57 470 minecraft:brown_terracotta
setblock 274 54 474 minecraft:bone_block
setblock 274 54 475 minecraft:brown_terracotta
fill 274 54 476 274 57 476 minecraft:bone_block
fill 274 54 483 274 62 484 minecraft:bone_block
fill 274 54 489 274 59 489 minecraft:bone_block
setblock 274 54 490 minecraft:brown_terracotta
setblock 274 54 491 minecraft:bone_block
setblock 274 54 504 minecraft:bone_block
fill 275 54 464 275 57 464 minecraft:brown_terracotta
setblock 275 54 468 minecraft:bone_block
fill 275 54 469 275 57 469 minecraft:brown_terracotta
setblock 275 54 473 minecraft:bone_block
fill 275 54 474 275 57 474 minecraft:brown_terracotta
fill 275 54 478 275 59 478 minecraft:bone_block
fill 275 54 480 275 61 483 minecraft:bone_block
setblock 275 54 484 minecraft:brown_terracotta
setblock 275 54 488 minecraft:bone_block
fill 275 54 489 275 55 489 minecraft:brown_terracotta
setblock 276 54 467 minecraft:bone_block
fill 276 54 468 276 57 468 minecraft:brown_terracotta
setblock 276 54 472 minecraft:bone_block
fill 276 54 473 276 57 473 minecraft:brown_terracotta
setblock 276 54 477 minecraft:bone_block
fill 276 54 478 276 55 478 minecraft:brown_terracotta
fill 276 54 482 276 60 482 minecraft:bone_block
setblock 276 54 483 minecraft:brown_terracotta
setblock 276 54 487 minecraft:bone_block
fill 276 54 488 276 56 488 minecraft:brown_terracotta
setblock 276 54 492 minecraft:bone_block
fill 276 54 493 276 55 493 minecraft:brown_terracotta
setblock 236 55 466 minecraft:bone_block
fill 236 55 467 236 58 467 minecraft:brown_terracotta
setblock 236 55 471 minecraft:bone_block
fill 236 55 472 236 58 472 minecraft:brown_terracotta
setblock 236 55 491 minecraft:bone_block
fill 236 55 492 236 56 492 minecraft:brown_terracotta
setblock 237 55 465 minecraft:bone_block
fill 237 55 466 237 56 466 minecraft:brown_terracotta
setblock 237 55 470 minecraft:bone_block
setblock 237 55 471 minecraft:brown_terracotta
setblock 238 55 464 minecraft:bone_block
setblock 238 55 465 minecraft:brown_terracotta
fill 239 55 464 239 56 464 minecraft:brown_terracotta
setblock 243 55 464 minecraft:bone_block
fill 244 55 464 244 56 464 minecraft:brown_terracotta
setblock 244 55 504 minecraft:brown_terracotta
fill 246 55 477 248 56 477 minecraft:bone_block
setblock 247 55 465 minecraft:bone_block
fill 247 55 476 247 56 476 minecraft:bone_block
fill 247 55 478 247 56 478 minecraft:bone_block
setblock 248 55 464 minecraft:bone_block
setblock 248 55 465 minecraft:brown_terracotta
setblock 248 55 504 minecraft:bone_block
fill 249 55 464 249 58 464 minecraft:brown_terracotta
setblock 249 55 503 minecraft:bone_block
fill 249 55 504 249 58 504 minecraft:brown_terracotta
fill 250 55 503 250 56 503 minecraft:brown_terracotta
setblock 252 55 465 minecraft:bone_block
setblock 253 55 464 minecraft:bone_block
setblock 253 55 504 minecraft:bone_block
setblock 254 55 464 minecraft:brown_terracotta
setblock 254 55 504 minecraft:brown_terracotta
fill 261 55 479 261 55 480 minecraft:shroomlight
fill 261 55 486 261 55 487 minecraft:shroomlight
fill 262 55 478 262 56 479 minecraft:shroomlight
fill 262 55 487 262 56 488 minecraft:shroomlight
setblock 267 55 464 minecraft:brown_terracotta
setblock 268 55 464 minecraft:bone_block
setblock 268 55 465 minecraft:brown_terracotta
fill 269 55 464 269 58 464 minecraft:brown_terracotta
setblock 271 55 466 minecraft:bone_block
setblock 272 55 465 minecraft:bone_block
fill 272 55 466 272 56 466 minecraft:brown_terracotta
setblock 273 55 464 minecraft:bone_block
fill 273 55 465 273 57 465 minecraft:brown_terracotta
setblock 273 55 468 minecraft:brown_terracotta
setblock 273 55 469 minecraft:bone_block
fill 273 55 470 273 56 470 minecraft:brown_terracotta
fill 274 55 464 274 58 464 minecraft:brown_terracotta
setblock 274 55 468 minecraft:bone_block
fill 274 55 469 274 58 469 minecraft:brown_terracotta
setblock 274 55 473 minecraft:bone_block
fill 274 55 474 274 57 474 minecraft:brown_terracotta
fill 274 55 486 274 60 488 minecraft:bone_block
fill 274 55 490 274 57 490 minecraft:bone_block
setblock 275 55 467 minecraft:bone_block
fill 275 55 468 275 58 468 minecraft:brown_terracotta
setblock 275 55 472 minecraft:bone_block
fill 275 55 473 275 58 473 minecraft:brown_terracotta
fill 275 55 477 275 58 477 minecraft:bone_block
fill 275 55 484 275 60 487 minecraft:bone_block
setblock 275 55 488 minecraft:brown_terracotta
setblock 276 55 466 minecraft:bone_block
fill 276 55 467 276 58 467 minecraft:brown_terracotta
setblock 276 55 471 minecraft:bone_block
fill 276 55 472 276 58 472 minecraft:brown_terracotta
setblock 276 55 476 minecraft:bone_block
fill 276 55 477 276 58 477 minecraft:brown_terracotta
fill 276 55 480 276 60 481 minecraft:bone_block
fill 276 55 483 276 60 483 minecraft:bone_block
fill 276 55 486 276 60 486 minecraft:bone_block
setblock 276 55 487 minecraft:brown_terracotta
setblock 276 55 491 minecraft:bone_block
fill 276 55 492 276 56 492 minecraft:brown_terracotta
setblock 236 56 465 minecraft:bone_block
fill 236 56 466 236 59 466 minecraft:brown_terracotta
setblock 236 56 470 minecraft:bone_block
fill 236 56 471 236 59 471 minecraft:brown_terracotta
setblock 236 56 491 minecraft:brown_terracotta
setblock 237 56 464 minecraft:bone_block
setblock 237 56 469 minecraft:bone_block
setblock 237 56 470 minecraft:brown_terracotta
setblock 238 56 464 minecraft:brown_terracotta
setblock 247 56 464 minecraft:bone_block
setblock 247 56 504 minecraft:bone_block
fill 248 56 464 248 59 464 minecraft:brown_terracotta
fill 248 56 504 248 59 504 minecraft:brown_terracotta
setblock 249 56 503 minecraft:brown_terracotta
setblock 252 56 464 minecraft:bone_block
setblock 252 56 504 minecraft:bone_block
setblock 253 56 464 minecraft:brown_terracotta
setblock 253 56 504 minecraft:brown_terracotta
setblock 261 56 480 minecraft:shroomlight
setblock 261 56 486 minecraft:shroomlight
fill 263 56 489 263 57 489 minecraft:bone_block
setblock 267 56 464 minecraft:bone_block
fill 268 56 464 268 59 464 minecraft:brown_terracotta
setblock 270 56 466 minecraft:bone_block
setblock 271 56 465 minecraft:bone_block
setblock 271 56 466 minecraft:brown_terracotta
setblock 272 56 464 minecraft:bone_block
fill 272 56 465 272 58 465 minecraft:brown_terracotta
fill 273 56 464 273 59 464 minecraft:brown_terracotta
setblock 274 56 467 minecraft:bone_block
fill 274 56 468 274 57 468 minecraft:brown_terracotta
setblock 274 56 472 minecraft:bone_block
fill 274 56 473 274 59 473 minecraft:brown_terracotta
setblock 275 56 466 minecraft:bone_block
fill 275 56 467 275 59 467 minecraft:brown_terracotta
setblock 275 56 471 minecraft:bone_block
fill 275 56 472 275 59 472 minecraft:brown_terracotta
setblock 275 56 476 minecraft:bone_block
fill 275 56 488 275 56 490 minecraft:bone_block
setblock 276 56 465 minecraft:bone_block
fill 276 56 466 276 59 466 minecraft:brown_terracotta
setblock 276 56 470 minecraft:bone_block
fill 276 56 471 276 59 471 minecraft:brown_terracotta
setblock 276 56 475 minecraft:bone_block
fill 276 56 476 276 59 476 minecraft:brown_terracotta
fill 276 56 478 276 58 479 minecraft:bone_block
fill 276 56 484 276 60 485 minecraft:bone_block
fill 276 56 487 276 59 487 minecraft:bone_block
setblock 276 56 490 minecraft:bone_block
setblock 276 56 491 minecraft:brown_terracotta
setblock 236 57 464 minecraft:bone_block
fill 236 57 465 236 58 465 minecraft:brown_terracotta
setblock 236 57 469 minecraft:bone_block
fill 236 57 470 236 60 470 minecraft:brown_terracotta
setblock 236 57 474 minecraft:bone_block
setblock 237 57 464 minecraft:brown_terracotta
setblock 246 57 464 minecraft:bone_block
setblock 246 57 504 minecraft:bone_block
fill 247 57 464 247 60 464 minecraft:brown_terracotta
fill 247 57 504 247 60 504 minecraft:brown_terracotta
setblock 251 57 464 minecraft:bone_block
setblock 251 57 504 minecraft:bone_block
setblock 252 57 504 minecraft:brown_terracotta
fill 262 57 479 262 57 480 minecraft:shroomlight
fill 262 57 486 262 57 487 minecraft:shroomlight
setblock 267 57 464 minecraft:brown_terracotta
setblock 270 57 465 minecraft:bone_block
setblock 271 57 464 minecraft:bone_block
fill 271 57 465 271 59 465 minecraft:brown_terracotta
fill 272 57 464 272 60 464 minecraft:brown_terracotta
setblock 274 57 471 minecraft:bone_block
fill 274 57 472 274 60 472 minecraft:brown_terracotta
setblock 275 57 466 minecraft:brown_terracotta
setblock 275 57 470 minecraft:bone_block
fill 275 57 471 275 60 471 minecraft:brown_terracotta
setblock 275 57 475 minecraft:bone_block
fill 275 57 488 275 58 489 minecraft:bone_block
setblock 276 57 464 minecraft:bone_block
fill 276 57 465 276 59 465 minecraft:brown_terracotta
setblock 276 57 469 minecraft:bone_block
fill 276 57 470 276 60 470 minecraft:brown_terracotta
setblock 276 57 474 minecraft:bone_block
fill 276 57 475 276 60 475 minecraft:brown_terracotta
fill 276 57 488 276 58 488 minecraft:bone_block
setblock 236 58 468 minecraft:bone_block
fill 236 58 469 236 61 469 minecraft:brown_terracotta
setblock 236 58 473 minecraft:bone_block
fill 236 58 474 236 61 474 minecraft:brown_terracotta
setblock 245 58 504 minecraft:bone_block
setblock 246 58 464 minecraft:brown_terracotta
fill 246 58 504 246 61 504 minecraft:brown_terracotta
setblock 250 58 464 minecraft:bone_block
setblock 250 58 504 minecraft:bone_block
fill 251 58 504 251 61 504 minecraft:brown_terracotta
setblock 269 58 465 minecraft:bone_block
setblock 270 58 464 minecraft:bone_block
fill 270 58 465 270 61 465 minecraft:brown_terracotta
fill 271 58 464 271 61 464 minecraft:brown_terracotta
setblock 274 58 470 minecraft:bone_block
fill 274 58 471 274 61 471 minecraft:brown_terracotta
setblock 275 58 464 minecraft:bone_block
setblock 275 58 469 minecraft:bone_block
fill 275 58 470 275 61 470 minecraft:brown_terracotta
setblock 275 58 474 minecraft:bone_block
fill 275 58 475 275 61 475 minecraft:brown_terracotta
setblock 276 58 468 minecraft:bone_block
fill 276 58 469 276 61 469 minecraft:brown_terracotta
setblock 276 58 473 minecraft:bone_block
fill 276 58 474 276 61 474 minecraft:brown_terracotta
setblock 236 59 467 minecraft:bone_block
fill 236 59 468 236 61 468 minecraft:brown_terracotta
setblock 236 59 472 minecraft:bone_block
fill 236 59 473 236 62 473 minecraft:brown_terracotta
fill 236 59 494 236 59 496 minecraft:brown_terracotta
setblock 238 59 466 minecraft:light[level=12]
setblock 238 59 474 minecraft:light[level=12]
setblock 238 59 482 minecraft:light[level=12]
setblock 238 59 490 minecraft:light[level=12]
setblock 238 59 498 minecraft:light[level=12]
setblock 244 59 504 minecraft:bone_block
fill 245 59 504 245 62 504 minecraft:brown_terracotta
setblock 246 59 466 minecraft:light[level=12]
setblock 246 59 474 minecraft:light[level=12]
setblock 246 59 482 minecraft:light[level=12]
setblock 246 59 490 minecraft:light[level=12]
setblock 246 59 498 minecraft:light[level=12]
setblock 249 59 504 minecraft:bone_block
fill 250 59 504 250 62 504 minecraft:brown_terracotta
setblock 254 59 466 minecraft:light[level=12]
setblock 254 59 474 minecraft:light[level=12]
setblock 254 59 490 minecraft:light[level=12]
setblock 254 59 498 minecraft:light[level=12]
setblock 262 59 466 minecraft:light[level=12]
setblock 262 59 474 minecraft:light[level=12]
setblock 262 59 482 minecraft:light[level=12]
setblock 262 59 490 minecraft:light[level=12]
setblock 262 59 498 minecraft:light[level=12]
fill 267 59 464 267 60 464 minecraft:brown_terracotta
fill 267 59 489 267 60 489 minecraft:bone_block
setblock 269 59 464 minecraft:bone_block
fill 270 59 464 270 62 464 minecraft:brown_terracotta
setblock 270 59 466 minecraft:light[level=12]
setblock 270 59 474 minecraft:light[level=12]
setblock 270 59 498 minecraft:light[level=12]
setblock 274 59 464 minecraft:bone_block
fill 274 59 470 274 60 470 minecraft:brown_terracotta
setblock 274 59 474 minecraft:bone_block
setblock 275 59 468 minecraft:bone_block
fill 275 59 469 275 62 469 minecraft:brown_terracotta
setblock 275 59 473 minecraft:bone_block
fill 275 59 474 275 62 474 minecraft:brown_terracotta
setblock 275 59 488 minecraft:bone_block
setblock 276 59 467 minecraft:bone_block
fill 276 59 468 276 62 468 minecraft:brown_terracotta
setblock 276 59 472 minecraft:bone_block
fill 276 59 473 276 62 473 minecraft:brown_terracotta
setblock 276 59 477 minecraft:bone_block
setblock 276 59 479 minecraft:bone_block
setblock 236 60 467 minecraft:brown_terracotta
setblock 236 60 471 minecraft:bone_block
fill 236 60 472 236 63 472 minecraft:brown_terracotta
fill 236 60 494 236 60 495 minecraft:brown_terracotta
setblock 236 60 496 minecraft:bone_block
fill 236 60 497 236 62 498 minecraft:brown_terracotta
setblock 243 60 504 minecraft:bone_block
fill 244 60 504 244 63 504 minecraft:brown_terracotta
fill 246 60 464 246 61 464 minecraft:brown_terracotta
fill 246 60 503 248 60 503 minecraft:brown_terracotta
setblock 248 60 504 minecraft:bone_block
fill 249 60 504 249 63 504 minecraft:brown_terracotta
setblock 268 60 464 minecraft:bone_block
fill 269 60 464 269 63 464 minecraft:brown_terracotta
setblock 273 60 464 minecraft:bone_block
setblock 274 60 473 minecraft:bone_block
fill 274 60 474 274 63 474 minecraft:brown_terracotta
fill 274 60 478 274 60 480 minecraft:bone_block
setblock 275 60 468 minecraft:brown_terracotta
setblock 275 60 472 minecraft:bone_block
fill 275 60 473 275 63 473 minecraft:brown_terracotta
setblock 275 60 476 minecraft:brown_terracotta
setblock 276 60 466 minecraft:bone_block
fill 276 60 467 276 63 467 minecraft:brown_terracotta
setblock 276 60 471 minecraft:bone_block
fill 276 60 472 276 63 472 minecraft:brown_terracotta
setblock 276 60 476 minecraft:bone_block
fill 276 60 477 276 63 477 minecraft:brown_terracotta
setblock 236 61 470 minecraft:bone_block
fill 236 61 471 236 64 471 minecraft:brown_terracotta
fill 236 61 493 236 61 494 minecraft:brown_terracotta
setblock 236 61 495 minecraft:bone_block
fill 236 61 496 236 64 496 minecraft:brown_terracotta
setblock 236 61 499 minecraft:brown_terracotta
setblock 236 61 500 minecraft:bone_block
setblock 241 61 504 minecraft:brown_terracotta
setblock 242 61 504 minecraft:bone_block
fill 243 61 504 243 64 504 minecraft:brown_terracotta
fill 244 61 503 247 61 503 minecraft:brown_terracotta
fill 245 61 464 245 62 464 minecraft:brown_terracotta
setblock 247 61 464 minecraft:bone_block
setblock 247 61 504 minecraft:bone_block
setblock 248 61 503 minecraft:bone_block
fill 248 61 504 248 64 504 minecraft:brown_terracotta
fill 249 61 503 249 64 503 minecraft:brown_terracotta
setblock 266 61 464 minecraft:brown_terracotta
setblock 267 61 464 minecraft:bone_block
fill 268 61 464 268 63 465 minecraft:brown_terracotta
fill 269 61 465 269 62 465 minecraft:brown_terracotta
setblock 272 61 464 minecraft:bone_block
fill 273 61 464 273 64 464 minecraft:brown_terracotta
setblock 274 61 472 minecraft:bone_block
fill 274 61 473 274 63 473 minecraft:brown_terracotta
fill 274 61 479 274 61 480 minecraft:bone_block
fill 274 61 486 274 61 487 minecraft:bone_block
setblock 275 61 471 minecraft:bone_block
fill 275 61 472 275 64 472 minecraft:brown_terracotta
setblock 275 61 476 minecraft:bone_block
fill 275 61 484 275 61 486 minecraft:bone_block
fill 276 61 466 276 64 466 minecraft:brown_terracotta
setblock 276 61 470 minecraft:bone_block
fill 276 61 471 276 64 471 minecraft:brown_terracotta
setblock 276 61 475 minecraft:bone_block
fill 276 61 476 276 64 476 minecraft:brown_terracotta
fill 276 61 478 276 62 478 minecraft:brown_terracotta
setblock 236 62 469 minecraft:bone_block
fill 236 62 470 236 63 470 minecraft:brown_terracotta
setblock 236 62 474 minecraft:bone_block
fill 236 62 475 236 65 475 minecraft:brown_terracotta
setblock 236 62 493 minecraft:brown_terracotta
setblock 236 62 494 minecraft:bone_block
fill 236 62 495 236 65 495 minecraft:brown_terracotta
setblock 236 62 499 minecraft:bone_block
fill 236 62 500 236 62 503 minecraft:brown_terracotta
fill 237 62 496 237 62 497 minecraft:brown_terracotta
setblock 237 62 498 minecraft:bone_block
fill 239 62 504 240 62 504 minecraft:brown_terracotta
setblock 241 62 504 minecraft:bone_block
setblock 242 62 503 minecraft:bone_block
fill 242 62 504 242 65 504 minecraft:brown_terracotta
fill 243 62 503 246 62 503 minecraft:brown_terracotta
fill 244 62 464 244 63 464 minecraft:brown_terracotta
fill 244 62 502 247 62 502 minecraft:brown_terracotta
setblock 246 62 464 minecraft:bone_block
setblock 246 62 504 minecraft:bone_block
fill 247 62 464 248 64 464 minecraft:brown_terracotta
setblock 247 62 503 minecraft:bone_block
fill 247 62 504 247 65 504 minecraft:brown_terracotta
setblock 248 62 502 minecraft:bone_block
fill 248 62 503 248 65 503 minecraft:brown_terracotta
fill 250 62 503 250 63 503 minecraft:brown_terracotta
setblock 251 62 504 minecraft:bone_block
setblock 265 62 464 minecraft:brown_terracotta
setblock 266 62 464 minecraft:bone_block
fill 267 62 464 267 64 465 minecraft:brown_terracotta
fill 267 62 504 269 63 504 minecraft:brown_terracotta
setblock 270 62 465 minecraft:bone_block
setblock 271 62 464 minecraft:bone_block
fill 272 62 464 272 65 464 minecraft:brown_terracotta
fill 274 62 464 274 63 464 minecraft:brown_terracotta
fill 274 62 472 274 63 472 minecraft:brown_terracotta
setblock 275 62 470 minecraft:bone_block
fill 275 62 471 275 65 471 minecraft:brown_terracotta
setblock 275 62 475 minecraft:bone_block
fill 275 62 476 275 64 477 minecraft:brown_terracotta
setblock 276 62 469 minecraft:bone_block
fill 276 62 470 276 65 470 minecraft:brown_terracotta
setblock 276 62 474 minecraft:bone_block
fill 276 62 475 276 65 475 minecraft:brown_terracotta
setblock 236 63 473 minecraft:bone_block
fill 236 63 474 236 66 474 minecraft:brown_terracotta
fill 236 63 476 236 64 476 minecraft:brown_terracotta
setblock 236 63 493 minecraft:bone_block
fill 236 63 494 236 66 494 minecraft:brown_terracotta
setblock 236 63 497 minecraft:brown_terracotta
setblock 236 63 498 minecraft:bone_block
fill 236 63 499 236 63 502 minecraft:brown_terracotta
setblock 236 63 503 minecraft:bone_block
fill 236 63 504 239 63 504 minecraft:brown_terracotta
fill 237 63 495 237 63 496 minecraft:brown_terracotta
setblock 237 63 497 minecraft:bone_block
fill 237 63 498 237 63 501 minecraft:brown_terracotta
setblock 240 63 503 minecraft:brown_terracotta
setblock 240 63 504 minecraft:bone_block
setblock 241 63 503 minecraft:bone_block
fill 241 63 504 241 66 504 minecraft:brown_terracotta
fill 242 63 464 243 64 464 minecraft:brown_terracotta
setblock 242 63 502 minecraft:bone_block
fill 242 63 503 245 63 503 minecraft:brown_terracotta
fill 243 63 502 246 63 502 minecraft:brown_terracotta
setblock 245 63 464 minecraft:bone_block
fill 245 63 501 247 63 501 minecraft:brown_terracotta
setblock 245 63 504 minecraft:bone_block
fill 246 63 464 246 66 464 minecraft:brown_terracotta
setblock 246 63 503 minecraft:bone_block
fill 246 63 504 246 66 504 minecraft:brown_terracotta
setblock 247 63 502 minecraft:bone_block
fill 247 63 503 247 66 503 minecraft:brown_terracotta
fill 248 63 502 249 65 502 minecraft:brown_terracotta
setblock 250 63 504 minecraft:bone_block
fill 251 63 504 251 66 504 minecraft:brown_terracotta
setblock 264 63 464 minecraft:brown_terracotta
fill 264 63 497 264 64 497 minecraft:soul_soil
setblock 265 63 464 minecraft:bone_block
setblock 265 63 504 minecraft:bone_block
fill 266 63 464 266 65 465 minecraft:brown_terracotta
fill 266 63 504 266 66 504 minecraft:brown_terracotta
setblock 269 63 465 minecraft:bone_block
setblock 270 63 464 minecraft:bone_block
fill 270 63 465 270 65 465 minecraft:brown_terracotta
setblock 270 63 504 minecraft:bone_block
fill 271 63 464 271 66 464 minecraft:brown_terracotta
fill 271 63 504 271 66 504 minecraft:brown_terracotta
setblock 274 63 475 minecraft:bone_block
setblock 275 63 469 minecraft:bone_block
fill 275 63 470 275 64 470 minecraft:brown_terracotta
setblock 275 63 474 minecraft:bone_block
fill 275 63 475 275 66 475 minecraft:brown_terracotta
setblock 276 63 468 minecraft:bone_block
fill 276 63 469 276 66 469 minecraft:brown_terracotta
setblock 276 63 473 minecraft:bone_block
fill 276 63 474 276 66 474 minecraft:brown_terracotta
setblock 276 63 478 minecraft:bone_block
fill 276 63 479 276 66 479 minecraft:brown_terracotta
fill 276 63 496 276 63 497 minecraft:brown_terracotta
setblock 276 63 498 minecraft:bone_block
fill 276 63 499 276 65 500 minecraft:brown_terracotta
setblock 236 64 472 minecraft:bone_block
fill 236 64 473 236 65 473 minecraft:brown_terracotta
setblock 236 64 477 minecraft:bone_block
fill 236 64 493 236 67 493 minecraft:brown_terracotta
setblock 236 64 497 minecraft:bone_block
fill 236 64 498 236 64 501 minecraft:brown_terracotta
setblock 236 64 502 minecraft:bone_block
fill 236 64 503 236 66 504 minecraft:brown_terracotta
setblock 237 64 495 minecraft:brown_terracotta
setblock 237 64 496 minecraft:bone_block
fill 237 64 497 237 64 500 minecraft:brown_terracotta
setblock 237 64 501 minecraft:bone_block
fill 237 64 502 237 67 502 minecraft:brown_terracotta
fill 237 64 504 238 64 504 minecraft:brown_terracotta
fill 238 64 497 238 64 499 minecraft:brown_terracotta
fill 238 64 503 239 64 503 minecraft:brown_terracotta
setblock 239 64 504 minecraft:bone_block
setblock 240 64 502 minecraft:brown_terracotta
setblock 240 64 503 minecraft:bone_block
fill 240 64 504 240 67 504 minecraft:brown_terracotta
fill 241 64 464 241 66 464 minecraft:brown_terracotta
setblock 241 64 502 minecraft:bone_block
fill 241 64 503 244 64 503 minecraft:brown_terracotta
setblock 242 64 501 minecraft:bone_block
fill 242 64 502 245 64 502 minecraft:brown_terracotta
fill 243 64 501 246 64 501 minecraft:brown_terracotta
setblock 244 64 464 minecraft:bone_block
setblock 244 64 504 minecraft:bone_block
fill 245 64 464 245 67 464 minecraft:brown_terracotta
setblock 245 64 503 minecraft:bone_block
fill 245 64 504 245 67 504 minecraft:brown_terracotta
setblock 246 64 502 minecraft:bone_block
fill 246 64 503 246 67 503 minecraft:brown_terracotta
setblock 247 64 501 minecraft:bone_block
fill 247 64 502 247 67 502 minecraft:brown_terracotta
fill 248 64 501 248 65 501 minecraft:brown_terracotta
setblock 249 64 504 minecraft:bone_block
setblock 250 64 503 minecraft:bone_block
fill 250 64 504 250 67 504 minecraft:brown_terracotta
setblock 263 64 464 minecraft:brown_terracotta
schedule function dropper:buildpart/113_2 1t
