fill 181 188 277 181 191 277 minecraft:packed_ice
setblock 181 188 281 minecraft:snow_block
fill 181 188 282 181 191 282 minecraft:packed_ice
setblock 181 188 286 minecraft:snow_block
fill 181 188 287 181 191 287 minecraft:packed_ice
setblock 181 188 290 minecraft:packed_ice
setblock 181 188 291 minecraft:snow_block
fill 181 188 292 181 191 292 minecraft:packed_ice
fill 181 188 294 181 189 294 minecraft:packed_ice
fill 181 188 308 181 188 310 minecraft:packed_ice
setblock 181 188 311 minecraft:snow_block
fill 181 188 312 181 191 312 minecraft:packed_ice
setblock 181 188 316 minecraft:snow_block
fill 182 188 276 182 191 276 minecraft:packed_ice
setblock 182 188 280 minecraft:snow_block
fill 182 188 281 182 191 281 minecraft:packed_ice
setblock 182 188 285 minecraft:snow_block
fill 182 188 286 182 191 286 minecraft:packed_ice
setblock 182 188 290 minecraft:snow_block
fill 182 188 291 182 191 291 minecraft:packed_ice
setblock 182 188 295 minecraft:snow_block
fill 182 188 296 182 190 297 minecraft:packed_ice
setblock 182 188 304 minecraft:packed_ice
setblock 182 188 305 minecraft:snow_block
fill 182 188 306 182 191 306 minecraft:packed_ice
setblock 182 188 310 minecraft:snow_block
fill 182 188 311 182 191 311 minecraft:packed_ice
setblock 182 188 314 minecraft:packed_ice
setblock 182 188 315 minecraft:snow_block
fill 182 188 316 182 191 316 minecraft:packed_ice
fill 141 189 313 141 228 313 minecraft:packed_ice
setblock 142 189 279 minecraft:snow_block
fill 142 189 280 142 192 280 minecraft:packed_ice
setblock 142 189 284 minecraft:snow_block
fill 142 189 285 142 192 285 minecraft:packed_ice
setblock 142 189 289 minecraft:snow_block
fill 142 189 290 142 192 290 minecraft:packed_ice
setblock 142 189 293 minecraft:packed_ice
setblock 142 189 294 minecraft:snow_block
fill 142 189 295 143 191 295 minecraft:packed_ice
setblock 142 189 298 minecraft:packed_ice
setblock 142 189 299 minecraft:snow_block
fill 142 189 300 142 189 303 minecraft:packed_ice
setblock 142 189 304 minecraft:snow_block
fill 142 189 305 142 189 308 minecraft:packed_ice
setblock 142 189 309 minecraft:snow_block
fill 142 189 310 142 192 310 minecraft:packed_ice
setblock 142 189 314 minecraft:snow_block
fill 142 189 315 142 191 316 minecraft:packed_ice
setblock 143 189 278 minecraft:snow_block
fill 143 189 279 143 191 279 minecraft:packed_ice
setblock 143 189 283 minecraft:snow_block
fill 143 189 284 143 190 284 minecraft:packed_ice
setblock 143 189 288 minecraft:snow_block
fill 143 189 289 143 192 289 minecraft:packed_ice
setblock 143 189 293 minecraft:snow_block
fill 143 189 294 143 192 294 minecraft:packed_ice
fill 143 189 304 143 190 304 minecraft:packed_ice
setblock 143 189 308 minecraft:snow_block
fill 143 189 309 143 192 309 minecraft:packed_ice
setblock 143 189 313 minecraft:snow_block
fill 143 189 314 143 192 314 minecraft:packed_ice
fill 143 189 316 144 189 316 minecraft:packed_ice
setblock 144 189 277 minecraft:snow_block
setblock 144 189 287 minecraft:snow_block
setblock 144 189 288 minecraft:packed_ice
setblock 144 189 292 minecraft:snow_block
setblock 144 189 307 minecraft:snow_block
fill 144 189 308 144 192 308 minecraft:packed_ice
setblock 144 189 312 minecraft:snow_block
fill 144 189 313 144 192 313 minecraft:packed_ice
setblock 145 189 276 minecraft:snow_block
fill 145 189 277 145 192 277 minecraft:packed_ice
setblock 145 189 311 minecraft:snow_block
fill 145 189 312 145 192 312 minecraft:packed_ice
setblock 145 189 316 minecraft:snow_block
fill 146 189 276 146 192 276 minecraft:packed_ice
setblock 146 189 311 minecraft:packed_ice
setblock 146 189 315 minecraft:snow_block
fill 146 189 316 146 192 316 minecraft:packed_ice
setblock 147 189 314 minecraft:snow_block
fill 147 189 315 147 192 315 minecraft:packed_ice
setblock 148 189 313 minecraft:snow_block
fill 148 189 314 148 192 314 minecraft:packed_ice
fill 149 189 313 149 190 313 minecraft:packed_ice
setblock 150 189 276 minecraft:snow_block
setblock 150 189 316 minecraft:snow_block
setblock 151 189 300 minecraft:blue_ice
setblock 151 189 315 minecraft:snow_block
fill 151 189 316 151 192 316 minecraft:packed_ice
setblock 152 189 314 minecraft:snow_block
fill 152 189 315 152 192 315 minecraft:packed_ice
setblock 154 189 316 minecraft:packed_ice
setblock 155 189 315 minecraft:packed_ice
setblock 155 189 316 minecraft:snow_block
fill 156 189 316 159 189 316 minecraft:packed_ice
fill 157 189 315 160 189 315 minecraft:packed_ice
setblock 160 189 316 minecraft:snow_block
setblock 161 189 314 minecraft:packed_ice
setblock 161 189 315 minecraft:snow_block
fill 161 189 316 161 192 316 minecraft:packed_ice
fill 162 189 276 164 189 276 minecraft:packed_ice
fill 162 189 311 162 190 311 minecraft:packed_ice
setblock 162 189 314 minecraft:snow_block
fill 162 189 315 162 192 315 minecraft:packed_ice
fill 163 189 314 163 191 314 minecraft:packed_ice
setblock 165 189 276 minecraft:snow_block
setblock 165 189 315 minecraft:packed_ice
setblock 165 189 316 minecraft:snow_block
fill 166 189 276 166 192 276 minecraft:packed_ice
setblock 166 189 315 minecraft:snow_block
fill 166 189 316 166 192 316 minecraft:packed_ice
fill 167 189 315 167 191 315 minecraft:packed_ice
setblock 170 189 276 minecraft:snow_block
setblock 170 189 316 minecraft:snow_block
setblock 171 189 316 minecraft:packed_ice
fill 174 189 311 174 190 311 minecraft:packed_ice
fill 175 189 288 175 189 291 minecraft:blue_ice
fill 176 189 292 176 189 294 minecraft:blue_ice
fill 176 189 296 176 189 298 minecraft:blue_ice
fill 177 189 276 177 191 276 minecraft:packed_ice
fill 177 189 295 177 190 295 minecraft:packed_ice
fill 177 189 299 177 189 304 minecraft:blue_ice
fill 177 189 316 179 189 316 minecraft:packed_ice
fill 178 189 280 178 190 280 minecraft:packed_ice
fill 178 189 307 178 189 310 minecraft:snow_block
setblock 179 189 314 minecraft:snow_block
fill 179 189 315 179 190 315 minecraft:packed_ice
setblock 180 189 276 minecraft:snow_block
fill 180 189 277 180 192 277 minecraft:packed_ice
setblock 180 189 286 minecraft:snow_block
fill 180 189 287 180 191 287 minecraft:packed_ice
fill 180 189 289 180 189 290 minecraft:packed_ice
setblock 180 189 291 minecraft:snow_block
fill 180 189 292 180 191 292 minecraft:packed_ice
setblock 180 189 316 minecraft:snow_block
fill 181 189 276 181 192 276 minecraft:packed_ice
setblock 181 189 280 minecraft:snow_block
fill 181 189 281 181 192 281 minecraft:packed_ice
setblock 181 189 285 minecraft:snow_block
fill 181 189 286 181 192 286 minecraft:packed_ice
setblock 181 189 290 minecraft:snow_block
fill 181 189 291 181 192 291 minecraft:packed_ice
setblock 181 189 295 minecraft:snow_block
fill 181 189 308 181 189 309 minecraft:packed_ice
setblock 181 189 310 minecraft:snow_block
fill 181 189 311 181 192 311 minecraft:packed_ice
fill 181 189 313 181 189 314 minecraft:packed_ice
setblock 181 189 315 minecraft:snow_block
fill 181 189 316 181 192 316 minecraft:packed_ice
setblock 182 189 279 minecraft:snow_block
fill 182 189 280 182 192 280 minecraft:packed_ice
setblock 182 189 284 minecraft:snow_block
fill 182 189 285 182 192 285 minecraft:packed_ice
setblock 182 189 289 minecraft:snow_block
fill 182 189 290 182 192 290 minecraft:packed_ice
setblock 182 189 294 minecraft:snow_block
fill 182 189 295 182 192 295 minecraft:packed_ice
setblock 182 189 298 minecraft:packed_ice
setblock 182 189 304 minecraft:snow_block
fill 182 189 305 182 190 305 minecraft:packed_ice
setblock 182 189 309 minecraft:snow_block
fill 182 189 310 182 192 310 minecraft:packed_ice
setblock 182 189 314 minecraft:snow_block
fill 182 189 315 182 192 315 minecraft:packed_ice
setblock 142 190 278 minecraft:snow_block
fill 142 190 279 142 193 279 minecraft:packed_ice
setblock 142 190 283 minecraft:snow_block
fill 142 190 284 142 192 284 minecraft:packed_ice
setblock 142 190 288 minecraft:snow_block
fill 142 190 289 142 193 289 minecraft:packed_ice
setblock 142 190 292 minecraft:packed_ice
setblock 142 190 293 minecraft:snow_block
fill 142 190 294 142 193 294 minecraft:packed_ice
setblock 142 190 298 minecraft:snow_block
fill 142 190 299 142 190 302 minecraft:packed_ice
setblock 142 190 303 minecraft:snow_block
fill 142 190 304 142 190 307 minecraft:packed_ice
setblock 142 190 308 minecraft:snow_block
fill 142 190 309 142 193 309 minecraft:packed_ice
setblock 142 190 313 minecraft:snow_block
fill 142 190 314 142 193 314 minecraft:packed_ice
setblock 143 190 277 minecraft:snow_block
fill 143 190 278 143 193 278 minecraft:packed_ice
setblock 143 190 287 minecraft:snow_block
fill 143 190 288 143 191 288 minecraft:packed_ice
setblock 143 190 292 minecraft:snow_block
fill 143 190 293 143 193 293 minecraft:packed_ice
setblock 143 190 296 minecraft:packed_ice
setblock 143 190 307 minecraft:snow_block
fill 143 190 308 143 193 308 minecraft:packed_ice
setblock 143 190 312 minecraft:snow_block
fill 143 190 313 143 193 313 minecraft:packed_ice
setblock 143 190 316 minecraft:packed_ice
setblock 144 190 276 minecraft:snow_block
fill 144 190 277 144 193 277 minecraft:packed_ice
setblock 144 190 278 minecraft:light[level=12]
setblock 144 190 285 minecraft:light[level=12]
setblock 144 190 291 minecraft:snow_block
setblock 144 190 292 minecraft:packed_ice
setblock 144 190 299 minecraft:light[level=12]
setblock 144 190 306 minecraft:snow_block
fill 144 190 307 144 191 307 minecraft:packed_ice
setblock 144 190 311 minecraft:snow_block
fill 144 190 312 144 193 312 minecraft:packed_ice
setblock 144 190 316 minecraft:snow_block
fill 145 190 276 145 193 276 minecraft:packed_ice
setblock 145 190 310 minecraft:snow_block
fill 145 190 311 145 192 311 minecraft:packed_ice
setblock 145 190 315 minecraft:snow_block
fill 145 190 316 145 193 316 minecraft:packed_ice
setblock 146 190 314 minecraft:snow_block
fill 146 190 315 146 193 315 minecraft:packed_ice
setblock 147 190 313 minecraft:snow_block
fill 147 190 314 147 193 314 minecraft:packed_ice
fill 148 190 313 148 191 313 minecraft:packed_ice
setblock 149 190 276 minecraft:snow_block
setblock 149 190 316 minecraft:snow_block
setblock 150 190 315 minecraft:snow_block
fill 150 190 316 150 193 316 minecraft:packed_ice
setblock 151 190 278 minecraft:light[level=12]
setblock 151 190 285 minecraft:light[level=12]
setblock 151 190 292 minecraft:light[level=12]
setblock 151 190 299 minecraft:light[level=12]
setblock 151 190 306 minecraft:light[level=12]
setblock 151 190 313 minecraft:light[level=12]
setblock 151 190 314 minecraft:snow_block
fill 151 190 315 151 192 315 minecraft:packed_ice
setblock 154 190 316 minecraft:snow_block
setblock 155 190 315 minecraft:snow_block
fill 155 190 316 158 190 316 minecraft:packed_ice
fill 156 190 315 159 190 315 minecraft:packed_ice
setblock 158 190 278 minecraft:light[level=12]
setblock 158 190 285 minecraft:light[level=12]
setblock 158 190 292 minecraft:light[level=12]
setblock 158 190 299 minecraft:light[level=12]
setblock 158 190 306 minecraft:light[level=12]
setblock 158 190 313 minecraft:light[level=12]
setblock 159 190 316 minecraft:snow_block
setblock 160 190 315 minecraft:snow_block
fill 160 190 316 160 193 316 minecraft:packed_ice
fill 161 190 276 163 190 276 minecraft:packed_ice
setblock 161 190 314 minecraft:snow_block
fill 161 190 315 161 193 315 minecraft:packed_ice
fill 162 190 312 162 191 312 minecraft:packed_ice
fill 162 190 314 162 193 314 minecraft:packed_ice
setblock 164 190 276 minecraft:snow_block
setblock 164 190 316 minecraft:snow_block
fill 165 190 276 165 193 276 minecraft:packed_ice
setblock 165 190 278 minecraft:light[level=12]
setblock 165 190 285 minecraft:light[level=12]
setblock 165 190 292 minecraft:light[level=12]
setblock 165 190 299 minecraft:light[level=12]
setblock 165 190 306 minecraft:light[level=12]
setblock 165 190 313 minecraft:light[level=12]
setblock 165 190 315 minecraft:snow_block
fill 165 190 316 165 193 316 minecraft:packed_ice
fill 166 190 315 166 192 315 minecraft:packed_ice
setblock 168 190 276 minecraft:packed_ice
setblock 169 190 276 minecraft:snow_block
fill 169 190 315 169 192 315 minecraft:packed_ice
setblock 169 190 316 minecraft:snow_block
setblock 170 190 276 minecraft:packed_ice
fill 170 190 316 170 191 316 minecraft:packed_ice
fill 171 190 278 171 196 278 minecraft:packed_ice
setblock 172 190 278 minecraft:light[level=12]
setblock 172 190 285 minecraft:light[level=12]
setblock 172 190 292 minecraft:light[level=12]
setblock 172 190 299 minecraft:light[level=12]
setblock 172 190 306 minecraft:light[level=12]
setblock 172 190 313 minecraft:light[level=12]
fill 174 190 312 174 191 312 minecraft:packed_ice
fill 176 190 276 176 192 276 minecraft:packed_ice
fill 176 190 316 178 190 316 minecraft:packed_ice
fill 178 190 279 178 191 279 minecraft:packed_ice
fill 178 190 295 178 191 295 minecraft:packed_ice
fill 178 190 308 178 190 310 minecraft:blue_ice
setblock 179 190 276 minecraft:snow_block
fill 179 190 277 179 193 277 minecraft:packed_ice
setblock 179 190 278 minecraft:light[level=12]
setblock 179 190 285 minecraft:light[level=12]
setblock 179 190 292 minecraft:light[level=12]
setblock 179 190 299 minecraft:light[level=12]
setblock 179 190 306 minecraft:light[level=12]
fill 179 190 312 179 190 314 minecraft:blue_ice
setblock 179 190 316 minecraft:snow_block
fill 180 190 276 180 193 276 minecraft:packed_ice
setblock 180 190 286 minecraft:packed_ice
setblock 180 190 289 minecraft:packed_ice
setblock 180 190 290 minecraft:snow_block
fill 180 190 291 180 192 291 minecraft:packed_ice
setblock 180 190 315 minecraft:snow_block
fill 180 190 316 180 193 316 minecraft:packed_ice
setblock 181 190 278 minecraft:packed_ice
setblock 181 190 279 minecraft:snow_block
fill 181 190 280 181 193 280 minecraft:packed_ice
setblock 181 190 284 minecraft:snow_block
fill 181 190 285 181 193 285 minecraft:packed_ice
setblock 181 190 289 minecraft:snow_block
fill 181 190 290 181 193 290 minecraft:packed_ice
setblock 181 190 294 minecraft:snow_block
fill 181 190 295 181 193 295 minecraft:packed_ice
setblock 181 190 309 minecraft:snow_block
fill 181 190 310 181 193 310 minecraft:packed_ice
setblock 181 190 313 minecraft:packed_ice
setblock 181 190 314 minecraft:snow_block
fill 181 190 315 181 193 315 minecraft:packed_ice
setblock 182 190 278 minecraft:snow_block
fill 182 190 279 182 193 279 minecraft:packed_ice
setblock 182 190 283 minecraft:snow_block
fill 182 190 284 182 193 284 minecraft:packed_ice
setblock 182 190 288 minecraft:snow_block
fill 182 190 289 182 193 289 minecraft:packed_ice
setblock 182 190 293 minecraft:snow_block
fill 182 190 294 182 193 294 minecraft:packed_ice
setblock 182 190 298 minecraft:snow_block
setblock 182 190 308 minecraft:snow_block
fill 182 190 309 182 193 309 minecraft:packed_ice
setblock 182 190 313 minecraft:snow_block
fill 182 190 314 182 193 314 minecraft:packed_ice
setblock 183 190 315 minecraft:light_blue_concrete
setblock 142 191 277 minecraft:snow_block
fill 142 191 278 142 194 278 minecraft:packed_ice
setblock 142 191 282 minecraft:snow_block
fill 142 191 283 142 192 283 minecraft:packed_ice
setblock 142 191 287 minecraft:snow_block
fill 142 191 288 142 194 288 minecraft:packed_ice
setblock 142 191 292 minecraft:snow_block
fill 142 191 293 142 194 293 minecraft:packed_ice
setblock 142 191 296 minecraft:packed_ice
setblock 142 191 297 minecraft:snow_block
fill 142 191 298 142 191 301 minecraft:packed_ice
setblock 142 191 302 minecraft:snow_block
fill 142 191 303 142 191 306 minecraft:packed_ice
setblock 142 191 307 minecraft:snow_block
fill 142 191 308 142 194 308 minecraft:packed_ice
setblock 142 191 312 minecraft:snow_block
fill 142 191 313 142 194 313 minecraft:packed_ice
setblock 143 191 276 minecraft:snow_block
fill 143 191 277 143 194 277 minecraft:packed_ice
setblock 143 191 286 minecraft:snow_block
setblock 143 191 287 minecraft:packed_ice
setblock 143 191 291 minecraft:snow_block
fill 143 191 292 143 194 292 minecraft:packed_ice
setblock 143 191 296 minecraft:snow_block
setblock 143 191 306 minecraft:snow_block
fill 143 191 307 143 193 307 minecraft:packed_ice
setblock 143 191 311 minecraft:snow_block
fill 143 191 312 143 194 312 minecraft:packed_ice
setblock 143 191 316 minecraft:snow_block
fill 144 191 276 144 194 276 minecraft:packed_ice
setblock 144 191 310 minecraft:snow_block
fill 144 191 311 144 194 311 minecraft:packed_ice
setblock 144 191 315 minecraft:snow_block
fill 144 191 316 144 194 316 minecraft:packed_ice
setblock 145 191 310 minecraft:packed_ice
setblock 145 191 314 minecraft:snow_block
fill 145 191 315 145 194 315 minecraft:packed_ice
setblock 146 191 313 minecraft:snow_block
fill 146 191 314 146 194 314 minecraft:packed_ice
setblock 147 191 313 minecraft:packed_ice
setblock 148 191 276 minecraft:snow_block
setblock 148 191 316 minecraft:snow_block
setblock 149 191 276 minecraft:packed_ice
setblock 149 191 315 minecraft:snow_block
fill 149 191 316 149 194 316 minecraft:packed_ice
setblock 150 191 314 minecraft:snow_block
fill 150 191 315 150 193 315 minecraft:packed_ice
setblock 153 191 316 minecraft:snow_block
fill 154 191 316 157 191 316 minecraft:packed_ice
fill 157 191 315 158 191 315 minecraft:packed_ice
setblock 158 191 316 minecraft:snow_block
setblock 159 191 315 minecraft:snow_block
fill 159 191 316 159 194 316 minecraft:packed_ice
fill 160 191 315 160 194 315 minecraft:packed_ice
fill 161 191 276 162 191 276 minecraft:packed_ice
setblock 161 191 314 minecraft:packed_ice
fill 162 191 313 162 192 313 minecraft:packed_ice
setblock 163 191 276 minecraft:snow_block
setblock 163 191 316 minecraft:snow_block
fill 164 191 276 164 194 276 minecraft:packed_ice
setblock 164 191 315 minecraft:snow_block
fill 164 191 316 164 194 316 minecraft:packed_ice
fill 165 191 315 165 193 315 minecraft:packed_ice
setblock 168 191 276 minecraft:snow_block
setblock 168 191 316 minecraft:snow_block
fill 169 191 276 169 192 276 minecraft:packed_ice
fill 169 191 314 169 192 314 minecraft:packed_ice
fill 169 191 316 169 192 317 minecraft:packed_ice
fill 170 191 275 171 244 275 minecraft:packed_ice
fill 170 191 315 170 192 315 minecraft:packed_ice
setblock 170 191 317 minecraft:white_concrete
setblock 172 191 275 minecraft:white_concrete
fill 173 191 275 173 244 275 minecraft:packed_ice
fill 174 191 313 174 192 313 minecraft:packed_ice
fill 175 191 276 175 193 276 minecraft:packed_ice
fill 176 191 316 177 191 316 minecraft:packed_ice
setblock 178 191 276 minecraft:snow_block
fill 178 191 278 178 192 278 minecraft:packed_ice
setblock 178 191 315 minecraft:packed_ice
setblock 178 191 316 minecraft:snow_block
fill 179 191 276 179 194 276 minecraft:packed_ice
fill 179 191 295 179 192 295 minecraft:packed_ice
setblock 179 191 315 minecraft:snow_block
fill 179 191 316 179 194 316 minecraft:packed_ice
setblock 180 191 289 minecraft:snow_block
fill 180 191 290 180 192 290 minecraft:packed_ice
setblock 180 191 314 minecraft:snow_block
fill 180 191 315 180 194 315 minecraft:packed_ice
setblock 181 191 278 minecraft:snow_block
fill 181 191 279 181 194 279 minecraft:packed_ice
setblock 181 191 283 minecraft:snow_block
fill 181 191 284 181 192 284 minecraft:packed_ice
setblock 181 191 288 minecraft:snow_block
fill 181 191 289 181 194 289 minecraft:packed_ice
setblock 181 191 293 minecraft:snow_block
fill 181 191 294 181 194 294 minecraft:packed_ice
setblock 181 191 309 minecraft:packed_ice
setblock 181 191 313 minecraft:snow_block
fill 181 191 314 181 194 314 minecraft:packed_ice
setblock 182 191 277 minecraft:snow_block
fill 182 191 278 182 194 278 minecraft:packed_ice
setblock 182 191 282 minecraft:snow_block
fill 182 191 283 182 194 283 minecraft:packed_ice
setblock 182 191 287 minecraft:snow_block
fill 182 191 288 182 194 288 minecraft:packed_ice
setblock 182 191 292 minecraft:snow_block
fill 182 191 293 182 194 293 minecraft:packed_ice
setblock 182 191 296 minecraft:packed_ice
setblock 182 191 297 minecraft:snow_block
fill 182 191 298 182 193 299 minecraft:packed_ice
setblock 182 191 307 minecraft:snow_block
fill 182 191 308 182 194 308 minecraft:packed_ice
setblock 182 191 312 minecraft:snow_block
fill 182 191 313 182 194 313 minecraft:packed_ice
fill 183 191 315 183 244 315 minecraft:packed_ice
setblock 142 192 276 minecraft:snow_block
fill 142 192 277 142 195 277 minecraft:packed_ice
setblock 142 192 281 minecraft:snow_block
setblock 142 192 282 minecraft:packed_ice
setblock 142 192 286 minecraft:snow_block
fill 142 192 287 142 193 287 minecraft:packed_ice
setblock 142 192 291 minecraft:snow_block
fill 142 192 292 142 195 292 minecraft:packed_ice
setblock 142 192 295 minecraft:packed_ice
setblock 142 192 296 minecraft:snow_block
fill 142 192 297 142 192 300 minecraft:packed_ice
setblock 142 192 301 minecraft:snow_block
fill 142 192 302 142 192 305 minecraft:packed_ice
setblock 142 192 306 minecraft:snow_block
fill 142 192 307 142 195 307 minecraft:packed_ice
setblock 142 192 311 minecraft:snow_block
fill 142 192 312 142 195 312 minecraft:packed_ice
setblock 142 192 315 minecraft:packed_ice
setblock 142 192 316 minecraft:snow_block
fill 143 192 276 143 195 276 minecraft:packed_ice
setblock 143 192 290 minecraft:snow_block
fill 143 192 291 143 193 291 minecraft:packed_ice
setblock 143 192 295 minecraft:snow_block
fill 143 192 296 143 194 297 minecraft:packed_ice
setblock 143 192 306 minecraft:packed_ice
setblock 143 192 310 minecraft:snow_block
fill 143 192 311 143 195 311 minecraft:packed_ice
setblock 143 192 315 minecraft:snow_block
fill 143 192 316 143 195 316 minecraft:packed_ice
setblock 144 192 309 minecraft:snow_block
fill 144 192 310 144 194 310 minecraft:packed_ice
setblock 144 192 314 minecraft:snow_block
fill 144 192 315 144 195 315 minecraft:packed_ice
setblock 145 192 313 minecraft:snow_block
fill 145 192 314 145 195 314 minecraft:packed_ice
setblock 146 192 313 minecraft:packed_ice
setblock 147 192 276 minecraft:snow_block
setblock 147 192 316 minecraft:snow_block
setblock 148 192 276 minecraft:packed_ice
setblock 148 192 315 minecraft:snow_block
fill 148 192 316 148 195 316 minecraft:packed_ice
setblock 149 192 314 minecraft:snow_block
fill 149 192 315 149 194 315 minecraft:packed_ice
setblock 152 192 316 minecraft:snow_block
fill 153 192 316 156 192 316 minecraft:packed_ice
setblock 157 192 315 minecraft:packed_ice
setblock 157 192 316 minecraft:snow_block
setblock 158 192 315 minecraft:snow_block
fill 158 192 316 158 195 316 minecraft:packed_ice
fill 159 192 315 159 195 315 minecraft:packed_ice
fill 160 192 276 161 192 276 minecraft:packed_ice
setblock 162 192 276 minecraft:snow_block
setblock 162 192 316 minecraft:snow_block
fill 163 192 276 163 195 276 minecraft:packed_ice
setblock 163 192 315 minecraft:snow_block
fill 163 192 316 163 195 316 minecraft:packed_ice
fill 164 192 315 164 194 315 minecraft:packed_ice
setblock 167 192 276 minecraft:snow_block
setblock 167 192 316 minecraft:snow_block
fill 168 192 276 168 195 276 minecraft:packed_ice
fill 168 192 316 168 193 316 minecraft:packed_ice
fill 170 192 317 170 244 317 minecraft:packed_ice
fill 172 192 275 172 237 275 minecraft:packed_ice
fill 174 192 314 174 193 314 minecraft:packed_ice
setblock 176 192 316 minecraft:packed_ice
setblock 177 192 276 minecraft:snow_block
setblock 177 192 316 minecraft:snow_block
fill 178 192 276 178 194 277 minecraft:packed_ice
setblock 178 192 315 minecraft:snow_block
fill 178 192 316 178 195 316 minecraft:packed_ice
fill 179 192 315 179 195 315 minecraft:packed_ice
fill 180 192 295 180 193 295 minecraft:packed_ice
fill 180 192 314 180 195 314 minecraft:packed_ice
setblock 181 192 277 minecraft:snow_block
fill 181 192 278 181 195 278 minecraft:packed_ice
setblock 181 192 282 minecraft:snow_block
setblock 181 192 283 minecraft:packed_ice
setblock 181 192 287 minecraft:snow_block
fill 181 192 288 181 194 288 minecraft:packed_ice
setblock 181 192 292 minecraft:snow_block
fill 181 192 293 181 195 293 minecraft:packed_ice
setblock 181 192 296 minecraft:packed_ice
setblock 181 192 312 minecraft:snow_block
fill 181 192 313 181 195 313 minecraft:packed_ice
setblock 182 192 276 minecraft:snow_block
fill 182 192 277 182 195 277 minecraft:packed_ice
setblock 182 192 281 minecraft:snow_block
fill 182 192 282 182 195 282 minecraft:packed_ice
setblock 182 192 286 minecraft:snow_block
fill 182 192 287 182 195 287 minecraft:packed_ice
setblock 182 192 291 minecraft:snow_block
fill 182 192 292 182 195 292 minecraft:packed_ice
setblock 182 192 296 minecraft:snow_block
fill 182 192 297 182 195 297 minecraft:packed_ice
fill 182 192 307 182 193 307 minecraft:packed_ice
setblock 182 192 311 minecraft:snow_block
fill 182 192 312 182 195 312 minecraft:packed_ice
setblock 182 192 316 minecraft:snow_block
setblock 183 192 292 minecraft:light_blue_concrete
fill 142 193 276 142 196 276 minecraft:packed_ice
setblock 142 193 280 minecraft:snow_block
setblock 142 193 281 minecraft:packed_ice
setblock 142 193 286 minecraft:packed_ice
setblock 142 193 290 minecraft:snow_block
fill 142 193 291 142 196 291 minecraft:packed_ice
setblock 142 193 295 minecraft:snow_block
fill 142 193 296 142 193 299 minecraft:packed_ice
setblock 142 193 300 minecraft:snow_block
fill 142 193 301 142 193 304 minecraft:packed_ice
setblock 142 193 305 minecraft:snow_block
fill 142 193 306 142 196 306 minecraft:packed_ice
setblock 142 193 310 minecraft:snow_block
fill 142 193 311 142 196 311 minecraft:packed_ice
setblock 142 193 315 minecraft:snow_block
fill 142 193 316 142 196 316 minecraft:packed_ice
setblock 143 193 290 minecraft:packed_ice
setblock 143 193 294 minecraft:snow_block
fill 143 193 295 143 196 295 minecraft:packed_ice
setblock 143 193 309 minecraft:snow_block
fill 143 193 310 143 196 310 minecraft:packed_ice
setblock 143 193 314 minecraft:snow_block
fill 143 193 315 143 196 315 minecraft:packed_ice
setblock 144 193 309 minecraft:packed_ice
setblock 144 193 313 minecraft:snow_block
fill 144 193 314 144 196 314 minecraft:packed_ice
setblock 145 193 313 minecraft:packed_ice
setblock 146 193 276 minecraft:snow_block
setblock 146 193 316 minecraft:snow_block
fill 147 193 276 147 195 276 minecraft:packed_ice
setblock 147 193 315 minecraft:snow_block
fill 147 193 316 147 196 316 minecraft:packed_ice
setblock 148 193 314 minecraft:snow_block
fill 148 193 315 148 195 315 minecraft:packed_ice
setblock 151 193 316 minecraft:snow_block
fill 152 193 316 155 193 316 minecraft:packed_ice
setblock 156 193 316 minecraft:snow_block
fill 157 193 316 157 196 316 minecraft:packed_ice
fill 158 193 315 158 196 315 minecraft:packed_ice
setblock 160 193 276 minecraft:packed_ice
setblock 161 193 276 minecraft:snow_block
setblock 161 193 316 minecraft:snow_block
fill 162 193 276 162 196 276 minecraft:packed_ice
setblock 162 193 315 minecraft:snow_block
fill 162 193 316 162 196 316 minecraft:packed_ice
fill 163 193 315 163 195 315 minecraft:packed_ice
setblock 166 193 276 minecraft:snow_block
setblock 166 193 316 minecraft:snow_block
fill 167 193 276 167 196 276 minecraft:packed_ice
fill 167 193 316 167 194 316 minecraft:packed_ice
fill 169 193 317 169 244 317 minecraft:packed_ice
fill 174 193 276 174 194 276 minecraft:packed_ice
fill 174 193 315 174 194 315 minecraft:packed_ice
setblock 175 193 316 minecraft:packed_ice
setblock 176 193 276 minecraft:snow_block
setblock 176 193 316 minecraft:snow_block
fill 177 193 276 177 196 276 minecraft:packed_ice
fill 177 193 316 177 196 316 minecraft:packed_ice
fill 178 193 315 178 196 315 minecraft:packed_ice
setblock 180 193 277 minecraft:snow_block
setblock 181 193 276 minecraft:snow_block
fill 181 193 277 181 196 277 minecraft:packed_ice
setblock 181 193 281 minecraft:snow_block
setblock 181 193 282 minecraft:packed_ice
setblock 181 193 286 minecraft:snow_block
setblock 181 193 287 minecraft:packed_ice
setblock 181 193 291 minecraft:snow_block
fill 181 193 292 181 196 292 minecraft:packed_ice
setblock 181 193 296 minecraft:snow_block
setblock 181 193 311 minecraft:snow_block
fill 181 193 312 181 196 312 minecraft:packed_ice
setblock 181 193 316 minecraft:snow_block
fill 182 193 276 182 196 276 minecraft:packed_ice
setblock 182 193 280 minecraft:snow_block
fill 182 193 281 182 196 281 minecraft:packed_ice
setblock 182 193 285 minecraft:snow_block
fill 182 193 286 182 196 286 minecraft:packed_ice
setblock 182 193 290 minecraft:snow_block
fill 182 193 291 182 196 291 minecraft:packed_ice
setblock 182 193 295 minecraft:snow_block
fill 182 193 296 182 196 296 minecraft:packed_ice
setblock 182 193 310 minecraft:snow_block
fill 182 193 311 182 196 311 minecraft:packed_ice
setblock 182 193 315 minecraft:snow_block
fill 182 193 316 182 196 316 minecraft:packed_ice
fill 183 193 292 183 196 292 minecraft:packed_ice
fill 141 194 275 141 244 276 minecraft:packed_ice
setblock 141 194 277 minecraft:light_blue_concrete
fill 141 194 278 141 198 280 minecraft:packed_ice
fill 141 194 295 142 195 297 minecraft:packed_ice
setblock 141 194 298 minecraft:light_blue_concrete
fill 141 194 299 141 195 301 minecraft:packed_ice
setblock 142 194 279 minecraft:snow_block
fill 142 194 280 142 197 280 minecraft:packed_ice
setblock 142 194 289 minecraft:snow_block
fill 142 194 290 142 196 290 minecraft:packed_ice
setblock 142 194 294 minecraft:snow_block
setblock 142 194 298 minecraft:packed_ice
setblock 142 194 299 minecraft:snow_block
fill 142 194 300 142 194 303 minecraft:packed_ice
setblock 142 194 304 minecraft:snow_block
fill 142 194 305 142 197 305 minecraft:packed_ice
setblock 142 194 309 minecraft:snow_block
fill 142 194 310 142 197 310 minecraft:packed_ice
setblock 142 194 314 minecraft:snow_block
fill 142 194 315 142 197 315 minecraft:packed_ice
setblock 143 194 293 minecraft:snow_block
fill 143 194 294 143 197 294 minecraft:packed_ice
setblock 143 194 308 minecraft:snow_block
fill 143 194 309 143 197 309 minecraft:packed_ice
setblock 143 194 313 minecraft:snow_block
fill 143 194 314 143 197 314 minecraft:packed_ice
fill 144 194 277 144 195 277 minecraft:snow_block
setblock 144 194 312 minecraft:snow_block
fill 144 194 313 144 196 313 minecraft:packed_ice
setblock 145 194 276 minecraft:snow_block
setblock 145 194 316 minecraft:snow_block
fill 146 194 276 146 197 276 minecraft:packed_ice
setblock 146 194 315 minecraft:snow_block
fill 146 194 316 146 197 316 minecraft:packed_ice
setblock 147 194 281 minecraft:sea_lantern
setblock 147 194 287 minecraft:sea_lantern
setblock 147 194 293 minecraft:sea_lantern
setblock 147 194 299 minecraft:sea_lantern
setblock 147 194 305 minecraft:sea_lantern
setblock 147 194 311 minecraft:sea_lantern
fill 147 194 314 147 195 314 minecraft:snow_block
fill 147 194 315 147 197 315 minecraft:packed_ice
setblock 150 194 316 minecraft:snow_block
fill 151 194 316 154 194 316 minecraft:packed_ice
setblock 152 194 312 minecraft:blue_ice
fill 152 194 314 152 194 315 minecraft:blue_ice
setblock 153 194 281 minecraft:sea_lantern
setblock 153 194 311 minecraft:sea_lantern
setblock 155 194 316 minecraft:snow_block
fill 156 194 316 156 197 316 minecraft:packed_ice
setblock 159 194 276 minecraft:packed_ice
setblock 159 194 281 minecraft:sea_lantern
setblock 159 194 311 minecraft:sea_lantern
setblock 160 194 276 minecraft:snow_block
setblock 160 194 316 minecraft:snow_block
fill 161 194 276 161 197 276 minecraft:packed_ice
setblock 161 194 315 minecraft:snow_block
fill 161 194 316 161 197 316 minecraft:packed_ice
fill 162 194 315 162 196 315 minecraft:packed_ice
setblock 165 194 276 minecraft:snow_block
setblock 165 194 281 minecraft:sea_lantern
setblock 165 194 311 minecraft:sea_lantern
setblock 165 194 316 minecraft:snow_block
fill 166 194 276 166 197 276 minecraft:packed_ice
fill 166 194 316 166 196 316 minecraft:packed_ice
setblock 171 194 281 minecraft:sea_lantern
setblock 171 194 311 minecraft:sea_lantern
setblock 171 194 317 minecraft:light_blue_concrete
fill 173 194 276 173 195 276 minecraft:packed_ice
setblock 175 194 276 minecraft:snow_block
setblock 175 194 316 minecraft:snow_block
fill 176 194 276 176 197 276 minecraft:packed_ice
fill 176 194 316 176 197 316 minecraft:packed_ice
fill 177 194 277 177 195 277 minecraft:packed_ice
setblock 177 194 281 minecraft:sea_lantern
setblock 177 194 287 minecraft:sea_lantern
setblock 177 194 293 minecraft:sea_lantern
setblock 177 194 299 minecraft:sea_lantern
setblock 177 194 305 minecraft:sea_lantern
setblock 179 194 277 minecraft:snow_block
setblock 180 194 276 minecraft:snow_block
fill 180 194 277 180 197 277 minecraft:packed_ice
setblock 180 194 316 minecraft:snow_block
fill 181 194 276 181 197 276 minecraft:packed_ice
setblock 181 194 280 minecraft:snow_block
fill 181 194 281 181 197 281 minecraft:packed_ice
setblock 181 194 290 minecraft:snow_block
fill 181 194 291 181 195 291 minecraft:packed_ice
setblock 181 194 295 minecraft:snow_block
fill 181 194 296 181 197 296 minecraft:packed_ice
fill 181 194 311 181 197 311 minecraft:packed_ice
setblock 181 194 315 minecraft:snow_block
fill 181 194 316 181 197 316 minecraft:packed_ice
setblock 182 194 279 minecraft:snow_block
fill 182 194 280 182 197 280 minecraft:packed_ice
setblock 182 194 284 minecraft:snow_block
fill 182 194 285 182 197 285 minecraft:packed_ice
setblock 182 194 289 minecraft:snow_block
fill 182 194 290 182 197 290 minecraft:packed_ice
setblock 182 194 294 minecraft:snow_block
fill 182 194 295 182 197 295 minecraft:packed_ice
setblock 182 194 298 minecraft:packed_ice
setblock 182 194 299 minecraft:snow_block
setblock 182 194 309 minecraft:snow_block
fill 182 194 310 182 197 310 minecraft:packed_ice
setblock 182 194 314 minecraft:snow_block
fill 182 194 315 182 197 315 minecraft:packed_ice
setblock 183 194 289 minecraft:white_concrete
fill 141 195 277 141 245 277 minecraft:packed_ice
setblock 141 195 285 minecraft:light_blue_concrete
fill 141 195 298 141 234 298 minecraft:packed_ice
setblock 141 195 304 minecraft:light_blue_concrete
fill 142 195 278 169 195 278 minecraft:snow_block
fill 142 195 279 142 198 279 minecraft:packed_ice
fill 142 195 281 146 195 288 minecraft:snow_block
setblock 142 195 289 minecraft:packed_ice
setblock 142 195 293 minecraft:snow_block
fill 142 195 294 142 198 294 minecraft:packed_ice
setblock 142 195 298 minecraft:snow_block
fill 142 195 299 142 195 302 minecraft:packed_ice
fill 142 195 303 147 195 303 minecraft:snow_block
fill 142 195 304 142 198 304 minecraft:packed_ice
setblock 142 195 308 minecraft:snow_block
fill 142 195 309 142 198 309 minecraft:packed_ice
setblock 142 195 313 minecraft:snow_block
fill 142 195 314 142 198 314 minecraft:packed_ice
setblock 143 195 277 minecraft:snow_block
fill 143 195 279 170 195 280 minecraft:snow_block
fill 143 195 289 147 195 292 minecraft:snow_block
setblock 143 195 293 minecraft:packed_ice
setblock 143 195 296 minecraft:packed_ice
fill 143 195 297 147 195 297 minecraft:snow_block
fill 143 195 298 143 198 298 minecraft:packed_ice
fill 143 195 299 147 195 302 minecraft:snow_block
fill 143 195 304 147 195 307 minecraft:snow_block
setblock 143 195 308 minecraft:packed_ice
setblock 143 195 312 minecraft:snow_block
fill 143 195 313 143 198 313 minecraft:packed_ice
setblock 144 195 276 minecraft:snow_block
fill 144 195 293 147 195 296 minecraft:snow_block
fill 144 195 298 147 195 298 minecraft:snow_block
fill 144 195 308 147 195 311 minecraft:snow_block
setblock 144 195 312 minecraft:packed_ice
setblock 144 195 316 minecraft:snow_block
fill 145 195 276 145 198 276 minecraft:packed_ice
fill 145 195 277 170 195 277 minecraft:snow_block
fill 145 195 312 174 195 313 minecraft:snow_block
setblock 145 195 315 minecraft:snow_block
fill 145 195 316 145 198 316 minecraft:packed_ice
setblock 146 195 314 minecraft:snow_block
fill 146 195 315 146 198 315 minecraft:packed_ice
fill 147 195 281 147 195 287 minecraft:snow_block
setblock 148 195 275 minecraft:light_blue_concrete
fill 148 195 276 157 195 276 minecraft:snow_block
fill 148 195 281 180 195 281 minecraft:snow_block
fill 148 195 311 174 195 311 minecraft:snow_block
fill 148 195 314 179 195 314 minecraft:snow_block
setblock 148 195 317 minecraft:white_concrete
fill 149 195 315 149 195 316 minecraft:snow_block
fill 150 195 315 157 195 315 minecraft:snow_block
fill 150 195 316 153 195 316 minecraft:packed_ice
fill 152 195 308 152 195 310 minecraft:blue_ice
setblock 154 195 316 minecraft:snow_block
setblock 155 195 275 minecraft:light_blue_concrete
fill 155 195 316 155 198 316 minecraft:packed_ice
fill 156 195 275 156 224 275 minecraft:packed_ice
setblock 158 195 276 minecraft:packed_ice
setblock 159 195 276 minecraft:snow_block
setblock 159 195 316 minecraft:snow_block
fill 160 195 276 160 198 276 minecraft:packed_ice
setblock 160 195 315 minecraft:snow_block
fill 160 195 316 160 198 316 minecraft:packed_ice
fill 161 195 315 161 197 315 minecraft:packed_ice
setblock 164 195 276 minecraft:snow_block
fill 164 195 315 164 195 316 minecraft:snow_block
fill 165 195 276 165 198 276 minecraft:packed_ice
fill 165 195 315 176 195 315 minecraft:snow_block
fill 165 195 316 165 198 316 minecraft:packed_ice
fill 167 195 316 174 195 316 minecraft:snow_block
fill 169 195 276 171 195 276 minecraft:snow_block
fill 169 195 306 169 196 306 minecraft:blue_ice
fill 170 195 278 170 196 278 minecraft:packed_ice
fill 171 195 277 171 196 277 minecraft:packed_ice
fill 171 195 279 171 196 279 minecraft:packed_ice
fill 171 195 280 180 195 280 minecraft:snow_block
fill 171 195 317 171 242 317 minecraft:packed_ice
fill 172 195 276 172 196 276 minecraft:packed_ice
fill 172 195 277 175 195 277 minecraft:snow_block
fill 172 195 278 172 196 278 minecraft:packed_ice
fill 172 195 279 181 195 279 minecraft:snow_block
fill 173 195 278 179 195 278 minecraft:snow_block
setblock 174 195 276 minecraft:snow_block
fill 175 195 276 175 198 276 minecraft:packed_ice
fill 175 195 316 175 198 316 minecraft:packed_ice
fill 176 195 277 176 196 277 minecraft:packed_ice
fill 177 195 282 180 195 309 minecraft:snow_block
fill 177 195 315 177 197 315 minecraft:packed_ice
setblock 178 195 276 minecraft:packed_ice
setblock 178 195 277 minecraft:snow_block
fill 178 195 310 181 195 310 minecraft:snow_block
setblock 179 195 276 minecraft:snow_block
fill 179 195 277 179 198 277 minecraft:packed_ice
fill 179 195 311 180 195 313 minecraft:snow_block
setblock 179 195 316 minecraft:snow_block
fill 180 195 276 180 198 276 minecraft:packed_ice
fill 180 195 278 180 196 278 minecraft:packed_ice
setblock 180 195 315 minecraft:snow_block
fill 180 195 316 180 198 316 minecraft:packed_ice
fill 181 195 280 181 198 280 minecraft:packed_ice
fill 181 195 282 181 195 289 minecraft:snow_block
setblock 181 195 290 minecraft:packed_ice
setblock 181 195 294 minecraft:snow_block
fill 181 195 295 181 198 295 minecraft:packed_ice
fill 181 195 297 181 195 309 minecraft:snow_block
setblock 181 195 314 minecraft:snow_block
fill 181 195 315 181 198 315 minecraft:packed_ice
setblock 182 195 278 minecraft:snow_block
fill 182 195 279 182 198 279 minecraft:packed_ice
setblock 182 195 283 minecraft:snow_block
fill 182 195 284 182 198 284 minecraft:packed_ice
setblock 182 195 288 minecraft:snow_block
fill 182 195 289 183 198 289 minecraft:packed_ice
setblock 182 195 293 minecraft:snow_block
fill 182 195 294 182 198 294 minecraft:packed_ice
setblock 182 195 298 minecraft:snow_block
fill 182 195 299 182 197 300 minecraft:packed_ice
fill 182 195 301 182 195 308 minecraft:snow_block
fill 182 195 309 182 198 309 minecraft:packed_ice
setblock 182 195 313 minecraft:snow_block
fill 182 195 314 182 198 314 minecraft:packed_ice
fill 183 195 276 183 241 276 minecraft:packed_ice
setblock 183 195 277 minecraft:white_concrete
fill 183 195 278 183 216 278 minecraft:packed_ice
fill 141 196 285 141 197 285 minecraft:packed_ice
setblock 141 196 286 minecraft:white_concrete
fill 141 196 287 141 242 287 minecraft:packed_ice
fill 141 196 295 141 241 297 minecraft:packed_ice
fill 141 196 299 143 197 299 minecraft:packed_ice
setblock 141 196 300 minecraft:light_blue_concrete
fill 141 196 301 142 196 301 minecraft:packed_ice
fill 141 196 304 141 245 304 minecraft:packed_ice
setblock 142 196 277 minecraft:snow_block
fill 142 196 278 142 199 278 minecraft:packed_ice
setblock 142 196 292 minecraft:snow_block
fill 142 196 293 142 199 293 minecraft:packed_ice
fill 142 196 295 142 196 296 minecraft:packed_ice
setblock 142 196 297 minecraft:snow_block
fill 142 196 298 142 199 298 minecraft:packed_ice
fill 142 196 300 142 197 300 minecraft:packed_ice
setblock 142 196 302 minecraft:snow_block
fill 142 196 303 142 199 303 minecraft:packed_ice
setblock 142 196 307 minecraft:snow_block
fill 142 196 308 142 199 308 minecraft:packed_ice
setblock 142 196 312 minecraft:snow_block
fill 142 196 313 142 199 313 minecraft:packed_ice
setblock 143 196 276 minecraft:snow_block
fill 143 196 277 143 199 277 minecraft:packed_ice
setblock 143 196 296 minecraft:snow_block
fill 143 196 297 143 199 297 minecraft:packed_ice
setblock 143 196 311 minecraft:snow_block
fill 143 196 312 143 199 312 minecraft:packed_ice
setblock 143 196 316 minecraft:snow_block
fill 144 196 276 144 199 276 minecraft:packed_ice
setblock 144 196 278 minecraft:light[level=15]
setblock 144 196 285 minecraft:light[level=12]
setblock 144 196 286 minecraft:light[level=15]
setblock 144 196 292 minecraft:light[level=12]
setblock 144 196 294 minecraft:light[level=15]
setblock 144 196 299 minecraft:light[level=12]
setblock 144 196 302 minecraft:light[level=15]
setblock 144 196 306 minecraft:light[level=12]
setblock 144 196 310 minecraft:light[level=15]
setblock 144 196 315 minecraft:snow_block
fill 144 196 316 144 199 316 minecraft:packed_ice
setblock 145 196 314 minecraft:snow_block
fill 145 196 315 145 199 315 minecraft:packed_ice
fill 147 196 281 147 196 287 minecraft:blue_ice
fill 147 196 289 147 196 311 minecraft:blue_ice
fill 148 196 275 148 244 275 minecraft:packed_ice
fill 148 196 281 177 196 281 minecraft:blue_ice
fill 148 196 311 174 196 311 minecraft:blue_ice
setblock 148 196 316 minecraft:snow_block
fill 148 196 317 148 231 317 minecraft:packed_ice
setblock 149 196 306 minecraft:blue_ice
fill 149 196 316 152 196 316 minecraft:packed_ice
setblock 151 196 278 minecraft:light[level=12]
setblock 151 196 285 minecraft:light[level=12]
setblock 151 196 292 minecraft:light[level=12]
setblock 151 196 299 minecraft:light[level=12]
setblock 151 196 306 minecraft:light[level=12]
fill 151 196 313 153 196 315 minecraft:blue_ice
setblock 152 196 278 minecraft:light[level=15]
setblock 152 196 286 minecraft:light[level=15]
setblock 152 196 294 minecraft:light[level=15]
setblock 152 196 302 minecraft:light[level=15]
setblock 152 196 310 minecraft:light[level=15]
setblock 152 196 312 minecraft:blue_ice
setblock 153 196 316 minecraft:snow_block
fill 154 196 316 154 199 316 minecraft:packed_ice
fill 155 196 275 155 244 275 minecraft:packed_ice
setblock 157 196 276 minecraft:packed_ice
setblock 158 196 276 minecraft:snow_block
setblock 158 196 278 minecraft:light[level=12]
setblock 158 196 285 minecraft:light[level=12]
setblock 158 196 292 minecraft:light[level=12]
setblock 158 196 299 minecraft:light[level=12]
setblock 158 196 306 minecraft:light[level=12]
setblock 158 196 313 minecraft:light[level=12]
setblock 158 196 316 minecraft:snow_block
fill 159 196 276 159 199 276 minecraft:packed_ice
setblock 159 196 315 minecraft:snow_block
fill 159 196 316 159 199 316 minecraft:packed_ice
setblock 160 196 278 minecraft:light[level=15]
setblock 160 196 286 minecraft:light[level=15]
setblock 160 196 294 minecraft:light[level=15]
setblock 160 196 302 minecraft:light[level=15]
setblock 160 196 310 minecraft:light[level=15]
fill 160 196 315 160 199 315 minecraft:packed_ice
setblock 161 196 277 minecraft:packed_ice
setblock 162 196 277 minecraft:snow_block
setblock 163 196 276 minecraft:snow_block
fill 163 196 277 163 199 277 minecraft:packed_ice
setblock 163 196 316 minecraft:snow_block
fill 164 196 276 164 199 276 minecraft:packed_ice
fill 164 196 316 164 199 316 minecraft:packed_ice
setblock 165 196 278 minecraft:light[level=12]
setblock 165 196 285 minecraft:light[level=12]
setblock 165 196 292 minecraft:light[level=12]
setblock 165 196 299 minecraft:light[level=12]
setblock 165 196 306 minecraft:light[level=12]
setblock 165 196 313 minecraft:light[level=12]
setblock 168 196 276 minecraft:snow_block
setblock 168 196 278 minecraft:light[level=15]
setblock 168 196 286 minecraft:light[level=15]
setblock 168 196 294 minecraft:light[level=15]
setblock 168 196 302 minecraft:light[level=15]
setblock 168 196 310 minecraft:light[level=15]
fill 169 196 276 171 197 276 minecraft:packed_ice
setblock 172 196 285 minecraft:light[level=12]
setblock 172 196 292 minecraft:light[level=12]
setblock 172 196 299 minecraft:light[level=12]
setblock 172 196 306 minecraft:light[level=12]
setblock 172 196 313 minecraft:light[level=12]
setblock 173 196 276 minecraft:snow_block
fill 174 196 276 174 199 276 minecraft:packed_ice
fill 174 196 316 174 199 316 minecraft:packed_ice
fill 175 196 277 175 197 277 minecraft:packed_ice
setblock 176 196 278 minecraft:light[level=15]
setblock 176 196 286 minecraft:light[level=15]
setblock 176 196 294 minecraft:light[level=15]
setblock 176 196 302 minecraft:light[level=15]
setblock 177 196 277 minecraft:snow_block
fill 177 196 282 177 196 309 minecraft:blue_ice
setblock 178 196 276 minecraft:snow_block
fill 178 196 277 178 198 278 minecraft:packed_ice
setblock 178 196 316 minecraft:snow_block
fill 179 196 276 179 199 276 minecraft:packed_ice
fill 179 196 278 179 197 278 minecraft:packed_ice
setblock 179 196 285 minecraft:light[level=12]
setblock 179 196 292 minecraft:light[level=12]
setblock 179 196 299 minecraft:light[level=12]
setblock 179 196 306 minecraft:light[level=12]
setblock 179 196 313 minecraft:light[level=12]
setblock 179 196 315 minecraft:snow_block
fill 179 196 316 179 199 316 minecraft:packed_ice
setblock 180 196 279 minecraft:snow_block
fill 180 196 292 180 200 292 minecraft:packed_ice
setblock 180 196 314 minecraft:snow_block
fill 180 196 315 180 199 315 minecraft:packed_ice
setblock 181 196 278 minecraft:snow_block
fill 181 196 279 181 199 279 minecraft:packed_ice
setblock 181 196 293 minecraft:snow_block
fill 181 196 294 181 199 294 minecraft:packed_ice
setblock 181 196 297 minecraft:packed_ice
setblock 181 196 313 minecraft:snow_block
fill 181 196 314 181 199 314 minecraft:packed_ice
setblock 182 196 277 minecraft:snow_block
fill 182 196 278 182 199 278 minecraft:packed_ice
setblock 182 196 282 minecraft:snow_block
fill 182 196 283 182 199 283 minecraft:packed_ice
setblock 182 196 287 minecraft:snow_block
fill 182 196 288 182 197 288 minecraft:packed_ice
setblock 182 196 292 minecraft:snow_block
fill 182 196 293 182 199 293 minecraft:packed_ice
setblock 182 196 297 minecraft:snow_block
fill 182 196 298 182 199 298 minecraft:packed_ice
setblock 182 196 312 minecraft:snow_block
fill 182 196 313 182 199 313 minecraft:packed_ice
fill 183 196 277 183 211 277 minecraft:packed_ice
setblock 183 196 293 minecraft:light_blue_concrete
fill 183 196 294 183 199 294 minecraft:packed_ice
fill 141 197 286 141 226 286 minecraft:packed_ice
fill 141 197 300 141 218 301 minecraft:packed_ice
setblock 142 197 276 minecraft:snow_block
fill 142 197 277 142 200 277 minecraft:packed_ice
setblock 142 197 281 minecraft:snow_block
setblock 142 197 291 minecraft:snow_block
fill 142 197 292 142 200 292 minecraft:packed_ice
setblock 142 197 295 minecraft:packed_ice
setblock 142 197 296 minecraft:snow_block
fill 142 197 297 142 200 297 minecraft:packed_ice
setblock 142 197 301 minecraft:snow_block
fill 142 197 302 142 200 302 minecraft:packed_ice
setblock 142 197 306 minecraft:snow_block
fill 142 197 307 142 200 307 minecraft:packed_ice
setblock 142 197 311 minecraft:snow_block
fill 142 197 312 142 200 312 minecraft:packed_ice
setblock 142 197 316 minecraft:snow_block
fill 143 197 276 143 200 276 minecraft:packed_ice
fill 143 197 278 143 198 278 minecraft:packed_ice
setblock 143 197 295 minecraft:snow_block
fill 143 197 296 143 200 296 minecraft:packed_ice
setblock 143 197 300 minecraft:snow_block
fill 143 197 301 143 200 301 minecraft:packed_ice
fill 143 197 305 143 198 307 minecraft:blue_ice
setblock 143 197 310 minecraft:snow_block
fill 143 197 311 143 200 311 minecraft:packed_ice
setblock 143 197 315 minecraft:snow_block
fill 143 197 316 143 200 316 minecraft:packed_ice
fill 144 197 306 148 197 306 minecraft:blue_ice
setblock 144 197 314 minecraft:snow_block
fill 144 197 315 144 200 315 minecraft:packed_ice
fill 145 197 305 146 197 305 minecraft:blue_ice
fill 145 197 307 146 197 307 minecraft:blue_ice
setblock 147 197 316 minecraft:snow_block
fill 148 197 316 151 197 316 minecraft:packed_ice
setblock 152 197 315 minecraft:blue_ice
setblock 152 197 316 minecraft:snow_block
fill 153 197 316 153 200 316 minecraft:packed_ice
setblock 156 197 276 minecraft:packed_ice
setblock 157 197 276 minecraft:snow_block
setblock 157 197 316 minecraft:snow_block
fill 158 197 276 158 200 276 minecraft:packed_ice
setblock 158 197 315 minecraft:snow_block
fill 158 197 316 158 200 316 minecraft:packed_ice
fill 159 197 277 160 197 277 minecraft:packed_ice
fill 159 197 315 159 200 315 minecraft:packed_ice
setblock 161 197 277 minecraft:snow_block
setblock 162 197 276 minecraft:snow_block
fill 162 197 277 162 200 277 minecraft:packed_ice
setblock 162 197 316 minecraft:snow_block
fill 163 197 276 163 200 276 minecraft:packed_ice
fill 163 197 316 163 200 316 minecraft:packed_ice
fill 164 197 277 164 198 277 minecraft:packed_ice
setblock 167 197 276 minecraft:snow_block
fill 168 197 276 168 200 276 minecraft:packed_ice
fill 169 197 306 169 206 306 minecraft:packed_ice
setblock 172 197 276 minecraft:snow_block
fill 173 197 276 173 199 277 minecraft:packed_ice
fill 173 197 316 173 200 316 minecraft:packed_ice
fill 174 197 277 174 198 277 minecraft:packed_ice
fill 175 197 299 176 198 299 minecraft:white_concrete
setblock 176 197 277 minecraft:snow_block
fill 176 197 315 176 198 315 minecraft:packed_ice
setblock 177 197 276 minecraft:snow_block
fill 177 197 277 177 199 278 minecraft:packed_ice
setblock 177 197 316 minecraft:snow_block
fill 178 197 276 178 200 276 minecraft:packed_ice
setblock 178 197 315 minecraft:snow_block
fill 178 197 316 178 200 316 minecraft:packed_ice
fill 179 197 315 179 200 315 minecraft:packed_ice
setblock 180 197 278 minecraft:snow_block
fill 180 197 279 180 199 280 minecraft:packed_ice
fill 180 197 314 180 200 314 minecraft:packed_ice
setblock 181 197 277 minecraft:snow_block
fill 181 197 278 181 200 278 minecraft:packed_ice
setblock 181 197 282 minecraft:snow_block
fill 181 197 293 181 200 293 minecraft:packed_ice
setblock 181 197 297 minecraft:snow_block
fill 181 197 298 181 200 298 minecraft:packed_ice
setblock 181 197 312 minecraft:snow_block
fill 181 197 313 181 200 313 minecraft:packed_ice
setblock 182 197 276 minecraft:snow_block
fill 182 197 277 182 200 277 minecraft:packed_ice
setblock 182 197 281 minecraft:snow_block
fill 182 197 282 182 200 282 minecraft:packed_ice
setblock 182 197 291 minecraft:snow_block
fill 182 197 292 182 200 292 minecraft:packed_ice
setblock 182 197 296 minecraft:snow_block
fill 182 197 297 182 200 297 minecraft:packed_ice
setblock 182 197 301 minecraft:snow_block
fill 182 197 302 182 200 302 minecraft:packed_ice
setblock 182 197 311 minecraft:snow_block
fill 182 197 312 182 200 312 minecraft:packed_ice
setblock 182 197 316 minecraft:snow_block
setblock 183 197 292 minecraft:white_concrete
fill 183 197 293 183 210 293 minecraft:packed_ice
setblock 141 198 285 minecraft:light_blue_concrete
fill 141 198 299 142 198 299 minecraft:packed_ice
fill 141 198 305 141 200 310 minecraft:packed_ice
setblock 141 198 311 minecraft:white_concrete
fill 141 198 312 141 212 312 minecraft:packed_ice
fill 142 198 276 142 201 276 minecraft:packed_ice
setblock 142 198 280 minecraft:snow_block
fill 142 198 281 142 201 281 minecraft:packed_ice
fill 142 198 282 145 198 282 minecraft:blue_ice
setblock 142 198 291 minecraft:packed_ice
setblock 142 198 295 minecraft:snow_block
fill 142 198 296 142 201 296 minecraft:packed_ice
setblock 142 198 300 minecraft:snow_block
fill 142 198 301 142 201 301 minecraft:packed_ice
setblock 142 198 305 minecraft:snow_block
fill 142 198 306 142 201 306 minecraft:packed_ice
setblock 142 198 310 minecraft:snow_block
fill 142 198 311 142 201 311 minecraft:packed_ice
setblock 142 198 315 minecraft:snow_block
fill 142 198 316 142 201 316 minecraft:packed_ice
fill 143 198 280 145 200 281 minecraft:blue_ice
fill 143 198 295 143 201 295 minecraft:packed_ice
setblock 143 198 299 minecraft:snow_block
fill 143 198 300 143 201 300 minecraft:packed_ice
fill 143 198 302 143 198 303 minecraft:packed_ice
fill 143 198 310 143 200 310 minecraft:packed_ice
setblock 143 198 314 minecraft:snow_block
fill 143 198 315 143 201 315 minecraft:packed_ice
setblock 144 198 277 minecraft:packed_ice
fill 144 198 305 145 198 307 minecraft:blue_ice
setblock 146 198 276 minecraft:snow_block
fill 146 198 281 149 199 281 minecraft:blue_ice
setblock 146 198 306 minecraft:blue_ice
setblock 146 198 316 minecraft:snow_block
fill 147 198 276 147 201 276 minecraft:packed_ice
fill 147 198 316 150 198 316 minecraft:packed_ice
setblock 151 198 316 minecraft:snow_block
fill 152 198 316 152 201 316 minecraft:packed_ice
fill 154 198 276 155 198 276 minecraft:packed_ice
setblock 156 198 276 minecraft:snow_block
setblock 156 198 316 minecraft:snow_block
fill 157 198 276 157 200 277 minecraft:packed_ice
fill 157 198 316 157 201 316 minecraft:packed_ice
fill 158 198 277 159 198 277 minecraft:packed_ice
fill 158 198 315 158 201 315 minecraft:packed_ice
setblock 160 198 277 minecraft:snow_block
setblock 161 198 276 minecraft:snow_block
fill 161 198 277 161 201 277 minecraft:packed_ice
setblock 161 198 316 minecraft:snow_block
fill 162 198 276 162 201 276 minecraft:packed_ice
fill 162 198 316 162 201 316 minecraft:packed_ice
setblock 165 198 277 minecraft:snow_block
setblock 166 198 276 minecraft:snow_block
fill 167 198 276 167 201 276 minecraft:packed_ice
fill 168 198 306 168 206 306 minecraft:packed_ice
setblock 169 198 275 minecraft:light_blue_concrete
fill 169 198 276 170 198 276 minecraft:packed_ice
fill 169 198 305 169 206 305 minecraft:packed_ice
setblock 171 198 276 minecraft:snow_block
fill 172 198 276 172 200 277 minecraft:packed_ice
fill 172 198 316 172 201 316 minecraft:packed_ice
setblock 175 198 277 minecraft:snow_block
fill 175 198 278 176 200 278 minecraft:packed_ice
setblock 176 198 276 minecraft:snow_block
fill 176 198 277 176 201 277 minecraft:packed_ice
setblock 176 198 316 minecraft:snow_block
fill 177 198 276 177 201 276 minecraft:packed_ice
setblock 177 198 315 minecraft:snow_block
fill 177 198 316 177 201 316 minecraft:packed_ice
fill 178 198 315 178 201 315 minecraft:packed_ice
setblock 179 198 278 minecraft:snow_block
fill 179 198 292 179 200 292 minecraft:packed_ice
fill 179 198 314 179 201 314 minecraft:packed_ice
setblock 180 198 277 minecraft:snow_block
fill 180 198 278 180 201 278 minecraft:packed_ice
fill 180 198 291 180 200 291 minecraft:packed_ice
fill 180 198 293 180 200 293 minecraft:packed_ice
setblock 181 198 276 minecraft:snow_block
fill 181 198 277 181 201 277 minecraft:packed_ice
setblock 181 198 281 minecraft:snow_block
fill 181 198 282 181 201 282 minecraft:packed_ice
fill 181 198 292 181 200 292 minecraft:packed_ice
setblock 181 198 296 minecraft:snow_block
fill 181 198 297 181 201 297 minecraft:packed_ice
fill 181 198 299 182 198 299 minecraft:packed_ice
setblock 181 198 311 minecraft:snow_block
fill 181 198 312 181 201 312 minecraft:packed_ice
setblock 181 198 316 minecraft:snow_block
fill 182 198 276 182 201 276 minecraft:packed_ice
setblock 182 198 280 minecraft:snow_block
fill 182 198 281 182 201 281 minecraft:packed_ice
setblock 182 198 285 minecraft:snow_block
setblock 182 198 290 minecraft:snow_block
fill 182 198 291 182 200 291 minecraft:packed_ice
setblock 182 198 295 minecraft:snow_block
fill 182 198 296 182 201 296 minecraft:packed_ice
setblock 182 198 300 minecraft:snow_block
fill 182 198 301 182 201 301 minecraft:packed_ice
fill 182 198 303 182 198 304 minecraft:packed_ice
fill 182 198 308 182 199 308 minecraft:packed_ice
setblock 182 198 310 minecraft:snow_block
fill 182 198 311 182 201 311 minecraft:packed_ice
setblock 182 198 315 minecraft:snow_block
fill 182 198 316 182 201 316 minecraft:packed_ice
fill 183 198 292 183 244 292 minecraft:packed_ice
setblock 183 198 308 minecraft:light_blue_concrete
fill 141 199 278 141 210 279 minecraft:packed_ice
setblock 141 199 280 minecraft:white_concrete
fill 141 199 285 141 203 285 minecraft:packed_ice
fill 141 199 299 141 206 299 minecraft:packed_ice
fill 141 199 311 141 202 311 minecraft:packed_ice
setblock 142 199 279 minecraft:snow_block
fill 142 199 280 142 202 280 minecraft:packed_ice
fill 142 199 282 142 200 282 minecraft:packed_ice
fill 142 199 283 142 200 283 minecraft:blue_ice
setblock 142 199 294 minecraft:snow_block
fill 142 199 295 142 202 295 minecraft:packed_ice
setblock 142 199 299 minecraft:snow_block
fill 142 199 300 142 202 300 minecraft:packed_ice
setblock 142 199 304 minecraft:snow_block
fill 142 199 305 143 201 305 minecraft:packed_ice
setblock 142 199 309 minecraft:snow_block
fill 142 199 310 142 202 310 minecraft:packed_ice
setblock 142 199 314 minecraft:snow_block
fill 142 199 315 142 202 315 minecraft:packed_ice
setblock 143 199 278 minecraft:snow_block
fill 143 199 282 147 199 282 minecraft:blue_ice
setblock 143 199 298 minecraft:snow_block
fill 143 199 299 143 202 299 minecraft:packed_ice
setblock 143 199 302 minecraft:packed_ice
setblock 143 199 303 minecraft:snow_block
fill 143 199 304 143 202 304 minecraft:packed_ice
fill 143 199 306 144 199 307 minecraft:blue_ice
setblock 143 199 313 minecraft:snow_block
fill 143 199 314 143 202 314 minecraft:packed_ice
setblock 144 199 277 minecraft:snow_block
setblock 144 199 305 minecraft:blue_ice
setblock 145 199 276 minecraft:snow_block
setblock 145 199 316 minecraft:snow_block
fill 146 199 276 146 202 276 minecraft:packed_ice
fill 146 199 280 147 199 280 minecraft:blue_ice
setblock 146 199 315 minecraft:snow_block
fill 146 199 316 149 199 316 minecraft:packed_ice
setblock 150 199 316 minecraft:snow_block
fill 151 199 316 151 202 316 minecraft:packed_ice
fill 153 199 276 154 199 276 minecraft:packed_ice
setblock 155 199 276 minecraft:snow_block
setblock 155 199 316 minecraft:snow_block
fill 156 199 276 156 201 277 minecraft:packed_ice
fill 156 199 316 156 202 316 minecraft:packed_ice
fill 157 199 315 157 202 315 minecraft:packed_ice
setblock 158 199 277 minecraft:packed_ice
setblock 159 199 277 minecraft:snow_block
setblock 160 199 276 minecraft:snow_block
fill 160 199 277 160 201 278 minecraft:packed_ice
setblock 160 199 316 minecraft:snow_block
fill 161 199 276 161 202 276 minecraft:packed_ice
fill 161 199 278 161 200 278 minecraft:packed_ice
fill 161 199 285 162 200 286 minecraft:white_concrete
fill 161 199 316 161 202 316 minecraft:packed_ice
fill 162 199 284 162 200 284 minecraft:white_concrete
setblock 164 199 277 minecraft:snow_block
setblock 165 199 276 minecraft:snow_block
fill 165 199 277 168 199 277 minecraft:packed_ice
setblock 165 199 316 minecraft:snow_block
fill 166 199 276 166 202 276 minecraft:packed_ice
fill 168 199 305 168 206 305 minecraft:packed_ice
fill 169 199 275 169 199 276 minecraft:packed_ice
setblock 169 199 277 minecraft:snow_block
fill 169 199 307 169 206 307 minecraft:packed_ice
setblock 170 199 276 minecraft:snow_block
fill 170 199 277 171 201 277 minecraft:packed_ice
fill 170 199 306 170 206 306 minecraft:packed_ice
fill 171 199 276 171 202 276 minecraft:packed_ice
setblock 173 199 278 minecraft:snow_block
setblock 174 199 277 minecraft:snow_block
fill 174 199 278 174 202 278 minecraft:packed_ice
setblock 175 199 276 minecraft:snow_block
fill 175 199 277 175 202 277 minecraft:packed_ice
setblock 175 199 315 minecraft:packed_ice
setblock 175 199 316 minecraft:snow_block
fill 176 199 276 176 202 276 minecraft:packed_ice
setblock 176 199 315 minecraft:snow_block
fill 176 199 316 176 202 316 minecraft:packed_ice
setblock 177 199 279 minecraft:snow_block
fill 177 199 315 177 202 315 minecraft:packed_ice
setblock 178 199 277 minecraft:packed_ice
setblock 178 199 278 minecraft:snow_block
fill 178 199 279 179 201 279 minecraft:packed_ice
fill 178 199 314 178 202 314 minecraft:packed_ice
setblock 179 199 277 minecraft:snow_block
fill 179 199 278 179 202 278 minecraft:packed_ice
fill 179 199 291 179 200 291 minecraft:packed_ice
fill 179 199 293 179 200 293 minecraft:packed_ice
setblock 180 199 276 minecraft:snow_block
fill 180 199 277 180 202 277 minecraft:packed_ice
setblock 180 199 281 minecraft:snow_block
setblock 180 199 316 minecraft:snow_block
fill 181 199 276 181 202 276 minecraft:packed_ice
setblock 181 199 280 minecraft:snow_block
fill 181 199 281 181 202 281 minecraft:packed_ice
fill 181 199 283 181 200 283 minecraft:packed_ice
fill 181 199 291 181 200 291 minecraft:packed_ice
setblock 181 199 295 minecraft:snow_block
fill 181 199 296 181 202 296 minecraft:packed_ice
setblock 181 199 299 minecraft:packed_ice
setblock 181 199 300 minecraft:snow_block
fill 181 199 301 181 202 301 minecraft:packed_ice
fill 181 199 311 181 202 311 minecraft:packed_ice
setblock 181 199 315 minecraft:snow_block
fill 181 199 316 181 202 316 minecraft:packed_ice
setblock 182 199 279 minecraft:snow_block
fill 182 199 280 182 202 280 minecraft:packed_ice
setblock 182 199 284 minecraft:snow_block
fill 182 199 285 182 202 285 minecraft:packed_ice
setblock 182 199 290 minecraft:packed_ice
setblock 182 199 294 minecraft:snow_block
fill 182 199 295 182 202 295 minecraft:packed_ice
setblock 182 199 299 minecraft:snow_block
fill 182 199 300 182 202 300 minecraft:packed_ice
setblock 182 199 303 minecraft:packed_ice
setblock 182 199 304 minecraft:snow_block
fill 182 199 305 182 200 307 minecraft:packed_ice
setblock 182 199 309 minecraft:snow_block
fill 182 199 310 182 202 310 minecraft:packed_ice
setblock 182 199 314 minecraft:snow_block
fill 182 199 315 182 202 315 minecraft:packed_ice
fill 183 199 289 183 245 289 minecraft:packed_ice
fill 183 199 308 183 241 308 minecraft:packed_ice
fill 141 200 280 141 245 280 minecraft:packed_ice
setblock 141 200 316 minecraft:light_blue_concrete
setblock 142 200 278 minecraft:snow_block
fill 142 200 279 143 202 279 minecraft:packed_ice
setblock 142 200 293 minecraft:snow_block
fill 142 200 294 142 203 294 minecraft:packed_ice
setblock 142 200 298 minecraft:snow_block
fill 142 200 299 142 203 299 minecraft:packed_ice
setblock 142 200 303 minecraft:snow_block
fill 142 200 304 142 203 304 minecraft:packed_ice
setblock 142 200 308 minecraft:snow_block
fill 142 200 309 142 203 309 minecraft:packed_ice
setblock 142 200 313 minecraft:snow_block
fill 142 200 314 142 203 314 minecraft:packed_ice
setblock 143 200 277 minecraft:snow_block
fill 143 200 278 143 203 278 minecraft:packed_ice
fill 143 200 282 145 200 282 minecraft:blue_ice
setblock 143 200 297 minecraft:snow_block
fill 143 200 298 143 203 298 minecraft:packed_ice
setblock 143 200 302 minecraft:snow_block
fill 143 200 303 143 203 303 minecraft:packed_ice
setblock 143 200 306 minecraft:packed_ice
setblock 143 200 307 minecraft:snow_block
setblock 143 200 312 minecraft:snow_block
fill 143 200 313 143 202 313 minecraft:packed_ice
setblock 144 200 276 minecraft:snow_block
fill 144 200 277 144 201 277 minecraft:packed_ice
fill 144 200 299 144 200 300 minecraft:packed_ice
setblock 144 200 316 minecraft:snow_block
fill 145 200 276 145 203 276 minecraft:packed_ice
setblock 145 200 315 minecraft:snow_block
fill 145 200 316 148 200 316 minecraft:packed_ice
setblock 146 200 281 minecraft:blue_ice
setblock 149 200 316 minecraft:snow_block
fill 150 200 316 150 202 316 minecraft:packed_ice
fill 151 200 276 153 200 276 minecraft:packed_ice
setblock 154 200 276 minecraft:snow_block
setblock 154 200 316 minecraft:snow_block
fill 155 200 276 155 202 277 minecraft:packed_ice
fill 155 200 316 155 203 316 minecraft:packed_ice
fill 156 200 315 156 201 315 minecraft:packed_ice
setblock 157 200 278 minecraft:snow_block
setblock 158 200 277 minecraft:snow_block
fill 158 200 278 159 202 278 minecraft:packed_ice
setblock 159 200 276 minecraft:snow_block
fill 159 200 277 159 203 277 minecraft:packed_ice
setblock 159 200 316 minecraft:snow_block
fill 160 200 276 160 203 276 minecraft:packed_ice
setblock 160 200 315 minecraft:snow_block
fill 160 200 316 160 203 316 minecraft:packed_ice
setblock 162 200 278 minecraft:snow_block
setblock 163 200 277 minecraft:snow_block
fill 163 200 278 163 203 278 minecraft:packed_ice
setblock 164 200 276 minecraft:snow_block
fill 164 200 277 167 200 277 minecraft:packed_ice
setblock 164 200 316 minecraft:snow_block
fill 165 200 276 165 203 276 minecraft:packed_ice
fill 167 200 306 167 206 306 minecraft:packed_ice
setblock 168 200 277 minecraft:snow_block
fill 168 200 307 168 206 307 minecraft:packed_ice
fill 169 200 275 169 244 275 minecraft:packed_ice
setblock 169 200 276 minecraft:snow_block
fill 169 200 277 169 203 277 minecraft:packed_ice
fill 169 200 304 169 206 304 minecraft:packed_ice
fill 170 200 276 170 203 276 minecraft:packed_ice
fill 170 200 305 170 206 305 minecraft:packed_ice
fill 170 200 307 170 206 307 minecraft:packed_ice
fill 171 200 316 171 202 316 minecraft:packed_ice
setblock 172 200 278 minecraft:snow_block
setblock 173 200 276 minecraft:packed_ice
setblock 173 200 277 minecraft:snow_block
fill 173 200 278 173 203 278 minecraft:packed_ice
setblock 174 200 276 minecraft:snow_block
fill 174 200 277 174 203 277 minecraft:packed_ice
setblock 174 200 315 minecraft:packed_ice
setblock 174 200 316 minecraft:snow_block
fill 175 200 276 175 203 276 minecraft:packed_ice
setblock 175 200 279 minecraft:packed_ice
setblock 175 200 315 minecraft:snow_block
fill 175 200 316 175 203 316 minecraft:packed_ice
setblock 176 200 279 minecraft:snow_block
fill 176 200 315 176 203 315 minecraft:packed_ice
setblock 177 200 277 minecraft:packed_ice
setblock 177 200 278 minecraft:snow_block
fill 177 200 279 177 203 279 minecraft:packed_ice
setblock 178 200 277 minecraft:snow_block
fill 178 200 278 178 203 278 minecraft:packed_ice
setblock 179 200 276 minecraft:snow_block
fill 179 200 277 179 203 277 minecraft:packed_ice
setblock 179 200 280 minecraft:packed_ice
setblock 179 200 316 minecraft:snow_block
fill 180 200 276 180 203 276 minecraft:packed_ice
setblock 180 200 279 minecraft:packed_ice
setblock 180 200 280 minecraft:snow_block
fill 180 200 281 180 202 282 minecraft:packed_ice
setblock 180 200 315 minecraft:snow_block
fill 180 200 316 180 203 316 minecraft:packed_ice
setblock 181 200 279 minecraft:snow_block
fill 181 200 280 181 203 280 minecraft:packed_ice
setblock 181 200 284 minecraft:snow_block
setblock 181 200 294 minecraft:snow_block
fill 181 200 295 181 201 295 minecraft:packed_ice
setblock 181 200 299 minecraft:snow_block
fill 181 200 300 181 203 300 minecraft:packed_ice
fill 181 200 302 181 200 303 minecraft:packed_ice
setblock 181 200 314 minecraft:snow_block
fill 181 200 315 181 203 315 minecraft:packed_ice
setblock 182 200 278 minecraft:snow_block
fill 182 200 279 182 203 279 minecraft:packed_ice
setblock 182 200 283 minecraft:snow_block
fill 182 200 284 182 203 284 minecraft:packed_ice
fill 182 200 286 182 201 286 minecraft:packed_ice
setblock 182 200 293 minecraft:snow_block
fill 182 200 294 182 202 294 minecraft:packed_ice
setblock 182 200 298 minecraft:snow_block
fill 182 200 299 182 203 299 minecraft:packed_ice
setblock 182 200 303 minecraft:snow_block
fill 182 200 304 182 203 304 minecraft:packed_ice
setblock 182 200 308 minecraft:snow_block
fill 182 200 309 182 203 309 minecraft:packed_ice
setblock 182 200 313 minecraft:snow_block
fill 182 200 314 182 203 314 minecraft:packed_ice
setblock 183 200 294 minecraft:white_concrete
fill 141 201 305 141 244 305 minecraft:packed_ice
setblock 141 201 306 minecraft:white_concrete
fill 141 201 307 141 213 310 minecraft:packed_ice
fill 141 201 316 141 202 316 minecraft:packed_ice
setblock 142 201 277 minecraft:snow_block
fill 142 201 278 142 204 278 minecraft:packed_ice
setblock 142 201 282 minecraft:snow_block
fill 142 201 283 142 204 283 minecraft:packed_ice
setblock 142 201 292 minecraft:snow_block
fill 142 201 293 142 203 293 minecraft:packed_ice
setblock 142 201 297 minecraft:snow_block
fill 142 201 298 142 204 298 minecraft:packed_ice
setblock 142 201 302 minecraft:snow_block
fill 142 201 303 142 204 303 minecraft:packed_ice
setblock 142 201 307 minecraft:snow_block
fill 142 201 308 143 203 308 minecraft:packed_ice
setblock 142 201 312 minecraft:snow_block
fill 142 201 313 142 204 313 minecraft:packed_ice
setblock 143 201 276 minecraft:snow_block
fill 143 201 277 143 203 277 minecraft:packed_ice
fill 143 201 280 143 201 282 minecraft:blue_ice
setblock 143 201 296 minecraft:snow_block
fill 143 201 297 143 204 297 minecraft:packed_ice
setblock 143 201 301 minecraft:snow_block
fill 143 201 302 144 203 302 minecraft:packed_ice
setblock 143 201 306 minecraft:snow_block
fill 143 201 307 143 204 307 minecraft:packed_ice
setblock 143 201 309 minecraft:packed_ice
setblock 143 201 311 minecraft:snow_block
setblock 143 201 312 minecraft:packed_ice
setblock 143 201 316 minecraft:snow_block
fill 144 201 276 144 204 276 minecraft:packed_ice
setblock 144 201 281 minecraft:blue_ice
setblock 144 201 299 minecraft:packed_ice
setblock 144 201 300 minecraft:snow_block
fill 144 201 301 144 204 301 minecraft:packed_ice
setblock 144 201 315 minecraft:snow_block
fill 144 201 316 147 201 316 minecraft:packed_ice
setblock 148 201 276 minecraft:snow_block
setblock 148 201 316 minecraft:snow_block
fill 149 201 316 149 202 316 minecraft:packed_ice
fill 150 201 276 152 201 276 minecraft:packed_ice
setblock 153 201 276 minecraft:snow_block
fill 153 201 277 154 203 277 minecraft:packed_ice
setblock 153 201 316 minecraft:snow_block
fill 154 201 276 154 204 276 minecraft:packed_ice
fill 154 201 316 154 204 316 minecraft:packed_ice
setblock 156 201 278 minecraft:snow_block
setblock 157 201 276 minecraft:packed_ice
setblock 157 201 277 minecraft:snow_block
fill 157 201 278 157 204 278 minecraft:packed_ice
setblock 158 201 276 minecraft:snow_block
fill 158 201 277 158 204 277 minecraft:packed_ice
setblock 158 201 316 minecraft:snow_block
fill 159 201 276 159 204 276 minecraft:packed_ice
setblock 159 201 315 minecraft:snow_block
fill 159 201 316 159 204 316 minecraft:packed_ice
setblock 161 201 278 minecraft:snow_block
setblock 162 201 277 minecraft:snow_block
fill 162 201 278 162 204 278 minecraft:packed_ice
setblock 163 201 276 minecraft:snow_block
fill 163 201 277 166 201 277 minecraft:packed_ice
setblock 163 201 316 minecraft:snow_block
fill 164 201 276 164 204 276 minecraft:packed_ice
fill 164 201 278 164 202 278 minecraft:packed_ice
setblock 164 201 316 minecraft:packed_ice
setblock 167 201 277 minecraft:snow_block
fill 167 201 305 167 206 305 minecraft:packed_ice
fill 167 201 307 167 206 307 minecraft:packed_ice
setblock 168 201 276 minecraft:snow_block
fill 168 201 277 168 204 277 minecraft:packed_ice
fill 168 201 304 168 206 304 minecraft:packed_ice
fill 168 201 308 169 206 308 minecraft:packed_ice
fill 169 201 276 169 204 276 minecraft:packed_ice
setblock 170 201 278 minecraft:packed_ice
fill 170 201 304 170 206 304 minecraft:packed_ice
fill 170 201 316 170 203 316 minecraft:packed_ice
setblock 171 201 278 minecraft:snow_block
fill 171 201 305 171 206 306 minecraft:packed_ice
setblock 172 201 276 minecraft:packed_ice
setblock 172 201 277 minecraft:snow_block
fill 172 201 278 172 204 278 minecraft:packed_ice
setblock 173 201 276 minecraft:snow_block
fill 173 201 277 173 204 277 minecraft:packed_ice
setblock 173 201 316 minecraft:snow_block
fill 174 201 276 174 204 276 minecraft:packed_ice
setblock 174 201 279 minecraft:packed_ice
setblock 174 201 315 minecraft:snow_block
fill 174 201 316 174 204 316 minecraft:packed_ice
setblock 175 201 278 minecraft:packed_ice
setblock 175 201 279 minecraft:snow_block
fill 175 201 315 175 204 315 minecraft:packed_ice
setblock 176 201 278 minecraft:snow_block
fill 176 201 279 176 204 279 minecraft:packed_ice
setblock 177 201 277 minecraft:snow_block
fill 177 201 278 177 204 278 minecraft:packed_ice
fill 177 201 314 177 203 314 minecraft:packed_ice
setblock 178 201 276 minecraft:snow_block
fill 178 201 277 178 204 277 minecraft:packed_ice
setblock 178 201 316 minecraft:snow_block
fill 179 201 276 179 204 276 minecraft:packed_ice
setblock 179 201 280 minecraft:snow_block
fill 179 201 281 179 204 281 minecraft:packed_ice
setblock 179 201 315 minecraft:snow_block
fill 179 201 316 179 204 316 minecraft:packed_ice
setblock 180 201 279 minecraft:snow_block
fill 180 201 280 180 204 280 minecraft:packed_ice
setblock 180 201 283 minecraft:packed_ice
setblock 180 201 299 minecraft:snow_block
fill 180 201 300 180 203 300 minecraft:packed_ice
setblock 180 201 314 minecraft:snow_block
fill 180 201 315 180 204 315 minecraft:packed_ice
setblock 181 201 278 minecraft:snow_block
fill 181 201 279 181 204 279 minecraft:packed_ice
setblock 181 201 283 minecraft:snow_block
fill 181 201 284 181 204 284 minecraft:packed_ice
setblock 181 201 298 minecraft:snow_block
fill 181 201 299 181 204 299 minecraft:packed_ice
setblock 181 201 302 minecraft:packed_ice
setblock 181 201 303 minecraft:snow_block
fill 181 201 304 181 202 306 minecraft:packed_ice
fill 181 201 310 181 203 310 minecraft:packed_ice
setblock 181 201 313 minecraft:snow_block
fill 181 201 314 181 204 314 minecraft:packed_ice
setblock 182 201 277 minecraft:snow_block
fill 182 201 278 182 204 278 minecraft:packed_ice
setblock 182 201 282 minecraft:snow_block
fill 182 201 283 182 204 283 minecraft:packed_ice
setblock 182 201 292 minecraft:snow_block
fill 182 201 293 182 202 293 minecraft:packed_ice
setblock 182 201 297 minecraft:snow_block
fill 182 201 298 182 204 298 minecraft:packed_ice
setblock 182 201 302 minecraft:snow_block
fill 182 201 303 182 204 303 minecraft:packed_ice
fill 182 201 305 182 201 306 minecraft:packed_ice
setblock 182 201 307 minecraft:snow_block
fill 182 201 308 182 204 308 minecraft:packed_ice
setblock 182 201 312 minecraft:snow_block
fill 182 201 313 182 204 313 minecraft:packed_ice
fill 183 201 294 183 238 294 minecraft:packed_ice
fill 141 202 306 141 244 306 minecraft:packed_ice
setblock 142 202 276 minecraft:snow_block
fill 142 202 277 142 205 277 minecraft:packed_ice
setblock 142 202 281 minecraft:snow_block
fill 142 202 282 142 205 282 minecraft:packed_ice
setblock 142 202 296 minecraft:snow_block
fill 142 202 297 142 205 297 minecraft:packed_ice
setblock 142 202 301 minecraft:snow_block
fill 142 202 302 142 205 302 minecraft:packed_ice
setblock 142 202 305 minecraft:packed_ice
setblock 142 202 306 minecraft:snow_block
fill 142 202 307 142 205 307 minecraft:packed_ice
setblock 142 202 311 minecraft:snow_block
fill 142 202 312 142 205 312 minecraft:packed_ice
setblock 142 202 316 minecraft:snow_block
fill 143 202 276 143 204 276 minecraft:packed_ice
setblock 143 202 295 minecraft:snow_block
fill 143 202 296 143 203 296 minecraft:packed_ice
setblock 143 202 300 minecraft:snow_block
fill 143 202 301 143 205 301 minecraft:packed_ice
setblock 143 202 305 minecraft:snow_block
fill 143 202 306 143 205 306 minecraft:packed_ice
setblock 143 202 315 minecraft:snow_block
fill 143 202 316 146 202 316 minecraft:packed_ice
setblock 144 202 278 minecraft:light[level=12]
setblock 144 202 285 minecraft:light[level=12]
setblock 144 202 292 minecraft:light[level=12]
setblock 144 202 299 minecraft:snow_block
fill 144 202 300 144 204 300 minecraft:packed_ice
setblock 144 202 303 minecraft:packed_ice
setblock 144 202 306 minecraft:light[level=12]
setblock 144 202 313 minecraft:light[level=12]
setblock 147 202 276 minecraft:snow_block
setblock 147 202 316 minecraft:snow_block
setblock 148 202 316 minecraft:packed_ice
fill 149 202 276 151 202 276 minecraft:packed_ice
setblock 150 202 275 minecraft:light_blue_concrete
fill 151 202 275 151 244 275 minecraft:packed_ice
setblock 151 202 278 minecraft:light[level=12]
setblock 151 202 285 minecraft:light[level=12]
setblock 151 202 292 minecraft:light[level=12]
setblock 151 202 299 minecraft:light[level=12]
setblock 151 202 306 minecraft:light[level=12]
setblock 151 202 313 minecraft:light[level=12]
setblock 152 202 276 minecraft:snow_block
setblock 152 202 316 minecraft:snow_block
fill 153 202 276 153 205 276 minecraft:packed_ice
fill 153 202 316 153 205 316 minecraft:packed_ice
setblock 155 202 278 minecraft:snow_block
setblock 156 202 276 minecraft:packed_ice
setblock 156 202 277 minecraft:snow_block
fill 156 202 278 156 205 278 minecraft:packed_ice
setblock 157 202 276 minecraft:snow_block
fill 157 202 277 157 205 277 minecraft:packed_ice
setblock 157 202 316 minecraft:snow_block
fill 158 202 276 158 205 276 minecraft:packed_ice
setblock 158 202 285 minecraft:light[level=12]
setblock 158 202 292 minecraft:light[level=12]
setblock 158 202 299 minecraft:light[level=12]
setblock 158 202 306 minecraft:light[level=12]
setblock 158 202 313 minecraft:light[level=12]
fill 158 202 316 158 205 316 minecraft:packed_ice
setblock 160 202 277 minecraft:packed_ice
setblock 160 202 278 minecraft:snow_block
setblock 161 202 277 minecraft:snow_block
fill 161 202 278 161 205 278 minecraft:packed_ice
setblock 162 202 276 minecraft:snow_block
fill 162 202 277 165 202 277 minecraft:packed_ice
setblock 162 202 316 minecraft:snow_block
fill 163 202 276 163 205 276 minecraft:packed_ice
setblock 163 202 316 minecraft:packed_ice
setblock 165 202 278 minecraft:light[level=12]
setblock 165 202 285 minecraft:light[level=12]
setblock 165 202 292 minecraft:light[level=12]
setblock 165 202 299 minecraft:light[level=12]
setblock 165 202 306 minecraft:light[level=12]
setblock 165 202 313 minecraft:light[level=12]
setblock 166 202 277 minecraft:snow_block
fill 166 202 306 166 206 306 minecraft:packed_ice
setblock 167 202 276 minecraft:snow_block
fill 167 202 277 167 205 277 minecraft:packed_ice
fill 167 202 304 167 206 304 minecraft:packed_ice
fill 167 202 308 167 206 308 minecraft:packed_ice
fill 168 202 276 168 205 276 minecraft:packed_ice
setblock 169 202 278 minecraft:packed_ice
fill 169 202 303 169 206 303 minecraft:packed_ice
setblock 170 202 277 minecraft:packed_ice
setblock 170 202 278 minecraft:snow_block
fill 170 202 308 170 206 308 minecraft:packed_ice
setblock 171 202 277 minecraft:snow_block
fill 171 202 278 171 205 278 minecraft:packed_ice
fill 171 202 304 171 206 304 minecraft:packed_ice
fill 171 202 307 171 206 307 minecraft:packed_ice
setblock 172 202 276 minecraft:snow_block
fill 172 202 277 172 205 277 minecraft:packed_ice
setblock 172 202 285 minecraft:light[level=12]
setblock 172 202 292 minecraft:light[level=12]
setblock 172 202 299 minecraft:light[level=12]
setblock 172 202 306 minecraft:light[level=12]
setblock 172 202 313 minecraft:light[level=12]
setblock 172 202 316 minecraft:snow_block
fill 173 202 276 173 205 276 minecraft:packed_ice
setblock 173 202 279 minecraft:packed_ice
setblock 173 202 315 minecraft:snow_block
fill 173 202 316 173 205 316 minecraft:packed_ice
setblock 174 202 279 minecraft:snow_block
fill 174 202 315 174 205 315 minecraft:packed_ice
setblock 175 202 278 minecraft:snow_block
fill 175 202 279 175 205 279 minecraft:packed_ice
setblock 176 202 277 minecraft:snow_block
fill 176 202 278 176 205 278 minecraft:packed_ice
setblock 177 202 276 minecraft:snow_block
fill 177 202 277 177 205 277 minecraft:packed_ice
setblock 177 202 316 minecraft:snow_block
fill 178 202 276 178 205 276 minecraft:packed_ice
setblock 178 202 279 minecraft:packed_ice
setblock 178 202 315 minecraft:snow_block
fill 178 202 316 178 205 316 minecraft:packed_ice
setblock 179 202 279 minecraft:snow_block
fill 179 202 280 179 205 280 minecraft:packed_ice
setblock 179 202 285 minecraft:light[level=12]
setblock 179 202 292 minecraft:light[level=12]
setblock 179 202 299 minecraft:light[level=12]
setblock 179 202 306 minecraft:light[level=12]
setblock 179 202 313 minecraft:light[level=12]
setblock 179 202 314 minecraft:snow_block
fill 179 202 315 179 205 315 minecraft:packed_ice
setblock 180 202 278 minecraft:snow_block
fill 180 202 279 180 205 279 minecraft:packed_ice
setblock 180 202 283 minecraft:snow_block
setblock 180 202 299 minecraft:packed_ice
fill 180 202 301 180 202 302 minecraft:packed_ice
fill 180 202 314 180 203 314 minecraft:packed_ice
setblock 181 202 277 minecraft:snow_block
fill 181 202 278 181 205 278 minecraft:packed_ice
setblock 181 202 282 minecraft:snow_block
fill 181 202 283 181 205 283 minecraft:packed_ice
setblock 181 202 297 minecraft:snow_block
fill 181 202 298 181 204 298 minecraft:packed_ice
setblock 181 202 302 minecraft:snow_block
fill 181 202 303 181 205 303 minecraft:packed_ice
setblock 181 202 307 minecraft:snow_block
fill 181 202 308 181 204 309 minecraft:packed_ice
setblock 181 202 312 minecraft:snow_block
fill 181 202 313 181 204 313 minecraft:packed_ice
setblock 182 202 276 minecraft:snow_block
fill 182 202 277 182 205 277 minecraft:packed_ice
setblock 182 202 281 minecraft:snow_block
fill 182 202 282 182 205 282 minecraft:packed_ice
setblock 182 202 286 minecraft:snow_block
setblock 182 202 296 minecraft:snow_block
fill 182 202 297 182 205 297 minecraft:packed_ice
setblock 182 202 301 minecraft:snow_block
fill 182 202 302 182 205 302 minecraft:packed_ice
setblock 182 202 305 minecraft:packed_ice
setblock 182 202 306 minecraft:snow_block
fill 182 202 307 182 205 307 minecraft:packed_ice
setblock 182 202 311 minecraft:snow_block
fill 182 202 312 182 205 312 minecraft:packed_ice
setblock 182 202 316 minecraft:snow_block
setblock 141 203 311 minecraft:white_concrete
setblock 141 203 316 minecraft:white_concrete
fill 142 203 276 142 205 276 minecraft:packed_ice
setblock 142 203 279 minecraft:packed_ice
setblock 142 203 280 minecraft:snow_block
fill 142 203 281 142 206 281 minecraft:packed_ice
setblock 142 203 295 minecraft:snow_block
fill 142 203 296 142 205 296 minecraft:packed_ice
setblock 142 203 300 minecraft:snow_block
fill 142 203 301 142 206 301 minecraft:packed_ice
setblock 142 203 305 minecraft:snow_block
fill 142 203 306 142 206 306 minecraft:packed_ice
setblock 142 203 310 minecraft:snow_block
fill 142 203 311 142 206 311 minecraft:packed_ice
setblock 142 203 315 minecraft:snow_block
fill 142 203 316 145 203 316 minecraft:packed_ice
setblock 143 203 299 minecraft:snow_block
fill 143 203 300 143 206 300 minecraft:packed_ice
setblock 143 203 304 minecraft:snow_block
fill 143 203 305 143 206 305 minecraft:packed_ice
setblock 144 203 299 minecraft:packed_ice
setblock 144 203 303 minecraft:snow_block
setblock 146 203 276 minecraft:snow_block
setblock 146 203 316 minecraft:snow_block
fill 149 203 276 150 203 276 minecraft:packed_ice
fill 150 203 275 150 244 275 minecraft:packed_ice
setblock 151 203 276 minecraft:snow_block
setblock 151 203 316 minecraft:snow_block
fill 152 203 276 152 205 277 minecraft:packed_ice
fill 152 203 316 152 204 316 minecraft:packed_ice
setblock 154 203 278 minecraft:snow_block
setblock 155 203 276 minecraft:packed_ice
setblock 155 203 277 minecraft:snow_block
fill 155 203 278 155 206 278 minecraft:packed_ice
setblock 156 203 276 minecraft:snow_block
fill 156 203 277 156 206 277 minecraft:packed_ice
setblock 156 203 316 minecraft:snow_block
fill 157 203 276 157 206 276 minecraft:packed_ice
fill 157 203 316 157 205 316 minecraft:packed_ice
setblock 158 203 278 minecraft:packed_ice
setblock 158 203 279 minecraft:snow_block
setblock 159 203 278 minecraft:snow_block
setblock 159 203 279 minecraft:packed_ice
setblock 160 203 277 minecraft:snow_block
fill 160 203 278 160 205 278 minecraft:packed_ice
setblock 161 203 276 minecraft:snow_block
fill 161 203 277 164 203 277 minecraft:packed_ice
setblock 161 203 316 minecraft:snow_block
fill 162 203 276 162 206 276 minecraft:packed_ice
setblock 162 203 316 minecraft:packed_ice
setblock 164 203 278 minecraft:snow_block
setblock 165 203 277 minecraft:snow_block
setblock 166 203 276 minecraft:snow_block
fill 166 203 277 166 205 277 minecraft:packed_ice
fill 166 203 305 166 206 305 minecraft:packed_ice
fill 166 203 307 166 206 307 minecraft:packed_ice
fill 167 203 276 167 206 276 minecraft:packed_ice
setblock 168 203 278 minecraft:packed_ice
fill 168 203 303 168 206 303 minecraft:packed_ice
fill 168 203 309 169 206 309 minecraft:packed_ice
setblock 169 203 278 minecraft:snow_block
setblock 170 203 277 minecraft:snow_block
fill 170 203 278 170 206 278 minecraft:packed_ice
fill 170 203 303 170 206 303 minecraft:packed_ice
setblock 171 203 276 minecraft:snow_block
fill 171 203 277 171 206 277 minecraft:packed_ice
fill 171 203 308 171 206 308 minecraft:packed_ice
setblock 171 203 316 minecraft:snow_block
fill 172 203 276 172 206 276 minecraft:packed_ice
setblock 172 203 279 minecraft:packed_ice
fill 172 203 305 172 206 307 minecraft:packed_ice
fill 172 203 316 172 206 316 minecraft:packed_ice
setblock 173 203 279 minecraft:snow_block
fill 173 203 315 173 205 315 minecraft:packed_ice
setblock 174 203 278 minecraft:snow_block
fill 174 203 279 174 206 279 minecraft:packed_ice
setblock 175 203 277 minecraft:snow_block
fill 175 203 278 175 206 278 minecraft:packed_ice
setblock 176 203 276 minecraft:snow_block
fill 176 203 277 176 206 277 minecraft:packed_ice
setblock 176 203 280 minecraft:packed_ice
setblock 176 203 316 minecraft:snow_block
fill 177 203 276 177 206 276 minecraft:packed_ice
setblock 177 203 280 minecraft:snow_block
setblock 177 203 315 minecraft:snow_block
fill 177 203 316 177 206 316 minecraft:packed_ice
setblock 178 203 279 minecraft:snow_block
setblock 178 203 314 minecraft:snow_block
fill 178 203 315 178 206 315 minecraft:packed_ice
setblock 179 203 278 minecraft:snow_block
fill 179 203 279 179 205 279 minecraft:packed_ice
setblock 179 203 314 minecraft:packed_ice
setblock 180 203 277 minecraft:snow_block
fill 180 203 278 180 206 278 minecraft:packed_ice
setblock 180 203 281 minecraft:packed_ice
setblock 180 203 282 minecraft:snow_block
fill 180 203 283 180 204 283 minecraft:packed_ice
setblock 180 203 301 minecraft:packed_ice
setblock 180 203 302 minecraft:snow_block
fill 180 203 303 180 204 303 minecraft:packed_ice
fill 180 203 311 180 209 311 minecraft:packed_ice
setblock 181 203 276 minecraft:snow_block
fill 181 203 277 181 206 277 minecraft:packed_ice
setblock 181 203 281 minecraft:snow_block
fill 181 203 282 181 206 282 minecraft:packed_ice
setblock 181 203 297 minecraft:packed_ice
setblock 181 203 301 minecraft:snow_block
fill 181 203 302 181 206 302 minecraft:packed_ice
fill 181 203 304 181 203 305 minecraft:packed_ice
setblock 181 203 306 minecraft:snow_block
fill 181 203 307 181 206 307 minecraft:packed_ice
setblock 181 203 311 minecraft:snow_block
fill 181 203 312 181 204 312 minecraft:packed_ice
setblock 181 203 316 minecraft:snow_block
fill 182 203 276 182 206 276 minecraft:packed_ice
setblock 182 203 280 minecraft:snow_block
fill 182 203 281 182 206 281 minecraft:packed_ice
setblock 182 203 285 minecraft:snow_block
setblock 182 203 295 minecraft:snow_block
fill 182 203 296 182 204 296 minecraft:packed_ice
setblock 182 203 300 minecraft:snow_block
fill 182 203 301 182 206 301 minecraft:packed_ice
setblock 182 203 305 minecraft:snow_block
fill 182 203 306 182 206 306 minecraft:packed_ice
setblock 182 203 310 minecraft:snow_block
fill 182 203 311 182 206 311 minecraft:packed_ice
setblock 182 203 315 minecraft:snow_block
fill 182 203 316 182 206 316 minecraft:packed_ice
setblock 141 204 285 minecraft:light_blue_concrete
fill 141 204 311 141 240 311 minecraft:packed_ice
fill 141 204 314 141 244 314 minecraft:packed_ice
setblock 141 204 315 minecraft:light_blue_concrete
fill 141 204 316 144 204 316 minecraft:packed_ice
setblock 142 204 279 minecraft:snow_block
fill 142 204 280 142 206 280 minecraft:packed_ice
setblock 142 204 294 minecraft:snow_block
fill 142 204 295 142 205 295 minecraft:packed_ice
setblock 142 204 299 minecraft:snow_block
fill 142 204 300 142 207 300 minecraft:packed_ice
setblock 142 204 304 minecraft:snow_block
fill 142 204 305 142 207 305 minecraft:packed_ice
setblock 142 204 308 minecraft:packed_ice
setblock 142 204 309 minecraft:snow_block
fill 142 204 310 142 207 310 minecraft:packed_ice
setblock 142 204 314 minecraft:snow_block
fill 142 204 315 142 205 315 minecraft:packed_ice
setblock 143 204 298 minecraft:snow_block
fill 143 204 299 143 206 299 minecraft:packed_ice
setblock 143 204 302 minecraft:packed_ice
setblock 143 204 303 minecraft:snow_block
fill 143 204 304 143 207 304 minecraft:packed_ice
setblock 143 204 308 minecraft:snow_block
setblock 144 204 278 minecraft:light[level=15]
setblock 144 204 286 minecraft:light[level=15]
setblock 144 204 294 minecraft:light[level=15]
setblock 144 204 302 minecraft:snow_block
fill 144 204 303 144 205 303 minecraft:packed_ice
setblock 144 204 310 minecraft:light[level=15]
setblock 150 204 276 minecraft:snow_block
fill 151 204 276 151 206 276 minecraft:packed_ice
setblock 152 204 278 minecraft:light[level=15]
setblock 152 204 286 minecraft:light[level=15]
setblock 152 204 294 minecraft:light[level=15]
setblock 152 204 302 minecraft:light[level=15]
setblock 152 204 310 minecraft:light[level=15]
setblock 153 204 277 minecraft:packed_ice
setblock 154 204 277 minecraft:snow_block
fill 154 204 278 154 205 278 minecraft:packed_ice
setblock 155 204 276 minecraft:snow_block
fill 155 204 277 155 207 277 minecraft:packed_ice
setblock 155 204 316 minecraft:snow_block
fill 156 204 276 156 207 276 minecraft:packed_ice
fill 156 204 316 156 205 316 minecraft:packed_ice
setblock 158 204 278 minecraft:snow_block
setblock 159 204 277 minecraft:snow_block
fill 159 204 278 159 205 278 minecraft:packed_ice
setblock 160 204 276 minecraft:snow_block
fill 160 204 277 163 204 277 minecraft:packed_ice
setblock 160 204 286 minecraft:light[level=15]
setblock 160 204 294 minecraft:light[level=15]
setblock 160 204 302 minecraft:light[level=15]
setblock 160 204 310 minecraft:light[level=15]
setblock 160 204 316 minecraft:snow_block
fill 161 204 276 161 207 276 minecraft:packed_ice
setblock 163 204 278 minecraft:snow_block
setblock 164 204 277 minecraft:snow_block
setblock 165 204 276 minecraft:snow_block
fill 165 204 277 165 205 277 minecraft:packed_ice
fill 166 204 276 166 207 276 minecraft:packed_ice
fill 166 204 304 166 206 304 minecraft:packed_ice
fill 166 204 308 166 206 308 minecraft:packed_ice
fill 167 204 303 167 206 303 minecraft:packed_ice
fill 167 204 309 167 206 309 minecraft:packed_ice
setblock 168 204 278 minecraft:snow_block
setblock 168 204 286 minecraft:light[level=15]
setblock 168 204 294 minecraft:light[level=15]
setblock 168 204 302 minecraft:light[level=15]
setblock 168 204 310 minecraft:light[level=15]
setblock 169 204 277 minecraft:snow_block
fill 169 204 278 169 206 278 minecraft:packed_ice
setblock 170 204 276 minecraft:snow_block
fill 170 204 277 170 207 277 minecraft:packed_ice
fill 170 204 309 171 206 309 minecraft:packed_ice
setblock 170 204 316 minecraft:snow_block
fill 171 204 276 171 207 276 minecraft:packed_ice
setblock 171 204 279 minecraft:packed_ice
fill 171 204 298 171 205 298 minecraft:white_concrete
fill 171 204 303 171 206 303 minecraft:packed_ice
fill 171 204 316 171 207 316 minecraft:packed_ice
setblock 172 204 279 minecraft:snow_block
fill 172 204 304 172 206 304 minecraft:packed_ice
fill 172 204 308 172 206 308 minecraft:packed_ice
setblock 173 204 278 minecraft:snow_block
fill 173 204 279 173 207 279 minecraft:packed_ice
setblock 174 204 277 minecraft:snow_block
fill 174 204 278 174 207 278 minecraft:packed_ice
setblock 175 204 276 minecraft:snow_block
fill 175 204 277 175 207 277 minecraft:packed_ice
setblock 175 204 316 minecraft:snow_block
fill 176 204 276 176 207 276 minecraft:packed_ice
setblock 176 204 280 minecraft:snow_block
setblock 176 204 286 minecraft:light[level=15]
setblock 176 204 294 minecraft:light[level=15]
setblock 176 204 302 minecraft:light[level=15]
setblock 176 204 315 minecraft:snow_block
fill 176 204 316 176 207 316 minecraft:packed_ice
setblock 177 204 279 minecraft:snow_block
fill 177 204 315 177 207 315 minecraft:packed_ice
setblock 178 204 278 minecraft:snow_block
fill 178 204 279 178 205 279 minecraft:packed_ice
setblock 179 204 277 minecraft:snow_block
fill 179 204 278 179 206 278 minecraft:packed_ice
setblock 180 204 276 minecraft:snow_block
fill 180 204 277 180 207 277 minecraft:packed_ice
setblock 180 204 281 minecraft:snow_block
fill 180 204 282 180 205 282 minecraft:packed_ice
setblock 180 204 301 minecraft:snow_block
setblock 180 204 302 minecraft:packed_ice
fill 180 204 304 181 204 304 minecraft:packed_ice
setblock 180 204 316 minecraft:snow_block
fill 181 204 276 181 207 276 minecraft:packed_ice
setblock 181 204 280 minecraft:snow_block
fill 181 204 281 181 206 281 minecraft:packed_ice
setblock 181 204 300 minecraft:snow_block
fill 181 204 301 181 206 301 minecraft:packed_ice
setblock 181 204 305 minecraft:snow_block
fill 181 204 306 181 207 306 minecraft:packed_ice
setblock 181 204 310 minecraft:snow_block
setblock 181 204 315 minecraft:snow_block
fill 181 204 316 181 207 316 minecraft:packed_ice
setblock 182 204 279 minecraft:snow_block
fill 182 204 280 182 207 280 minecraft:packed_ice
setblock 182 204 284 minecraft:snow_block
fill 182 204 285 182 205 285 minecraft:packed_ice
setblock 182 204 299 minecraft:snow_block
fill 182 204 300 182 207 300 minecraft:packed_ice
setblock 182 204 304 minecraft:snow_block
fill 182 204 305 182 207 305 minecraft:packed_ice
setblock 182 204 309 minecraft:snow_block
fill 182 204 310 182 207 310 minecraft:packed_ice
setblock 182 204 314 minecraft:snow_block
fill 182 204 315 182 206 315 minecraft:packed_ice
fill 141 205 285 141 240 285 minecraft:packed_ice
fill 141 205 315 141 240 316 minecraft:packed_ice
setblock 142 205 278 minecraft:snow_block
fill 142 205 279 142 206 279 minecraft:packed_ice
setblock 142 205 283 minecraft:snow_block
setblock 142 205 298 minecraft:snow_block
fill 142 205 299 142 208 299 minecraft:packed_ice
setblock 142 205 303 minecraft:snow_block
fill 142 205 304 142 208 304 minecraft:packed_ice
setblock 142 205 308 minecraft:snow_block
fill 142 205 309 142 208 309 minecraft:packed_ice
setblock 142 205 313 minecraft:snow_block
setblock 142 205 314 minecraft:packed_ice
setblock 142 205 316 minecraft:packed_ice
setblock 143 205 298 minecraft:packed_ice
setblock 143 205 302 minecraft:snow_block
fill 143 205 303 143 208 303 minecraft:packed_ice
setblock 143 205 307 minecraft:snow_block
setblock 144 205 302 minecraft:packed_ice
setblock 153 205 275 minecraft:light_blue_concrete
setblock 153 205 277 minecraft:snow_block
setblock 154 205 276 minecraft:snow_block
fill 154 205 277 154 207 277 minecraft:packed_ice
setblock 154 205 316 minecraft:snow_block
fill 155 205 276 155 208 276 minecraft:packed_ice
setblock 155 205 316 minecraft:packed_ice
setblock 157 205 278 minecraft:snow_block
setblock 158 205 277 minecraft:snow_block
fill 158 205 278 158 206 278 minecraft:packed_ice
setblock 159 205 276 minecraft:snow_block
fill 159 205 277 162 205 277 minecraft:packed_ice
fill 160 205 276 160 207 276 minecraft:packed_ice
setblock 163 205 277 minecraft:snow_block
setblock 164 205 276 minecraft:snow_block
setblock 164 205 277 minecraft:packed_ice
fill 165 205 276 165 207 276 minecraft:packed_ice
fill 165 205 304 165 206 307 minecraft:packed_ice
fill 166 205 303 166 206 303 minecraft:packed_ice
fill 166 205 309 166 206 309 minecraft:packed_ice
fill 167 205 302 170 206 302 minecraft:packed_ice
setblock 168 205 277 minecraft:snow_block
fill 168 205 310 170 206 310 minecraft:packed_ice
setblock 169 205 276 minecraft:snow_block
fill 169 205 277 169 208 277 minecraft:packed_ice
fill 170 205 276 170 208 276 minecraft:packed_ice
setblock 171 205 279 minecraft:snow_block
setblock 172 205 278 minecraft:snow_block
fill 172 205 279 172 206 279 minecraft:packed_ice
fill 172 205 303 172 206 303 minecraft:packed_ice
setblock 173 205 277 minecraft:snow_block
fill 173 205 278 173 208 278 minecraft:packed_ice
fill 173 205 305 173 206 307 minecraft:packed_ice
setblock 174 205 276 minecraft:snow_block
fill 174 205 277 174 208 277 minecraft:packed_ice
setblock 174 205 316 minecraft:snow_block
fill 175 205 276 175 208 276 minecraft:packed_ice
setblock 175 205 315 minecraft:snow_block
fill 175 205 316 175 208 316 minecraft:packed_ice
setblock 176 205 279 minecraft:snow_block
fill 176 205 315 176 208 315 minecraft:packed_ice
setblock 177 205 278 minecraft:snow_block
fill 177 205 279 177 206 279 minecraft:packed_ice
setblock 178 205 277 minecraft:snow_block
fill 178 205 278 178 207 278 minecraft:packed_ice
setblock 179 205 276 minecraft:snow_block
fill 179 205 277 179 208 277 minecraft:packed_ice
setblock 179 205 316 minecraft:snow_block
fill 180 205 276 180 208 276 minecraft:packed_ice
setblock 180 205 280 minecraft:snow_block
setblock 180 205 281 minecraft:packed_ice
setblock 180 205 315 minecraft:snow_block
fill 180 205 316 180 208 316 minecraft:packed_ice
setblock 181 205 279 minecraft:snow_block
fill 181 205 280 181 207 280 minecraft:packed_ice
setblock 181 205 299 minecraft:snow_block
setblock 181 205 300 minecraft:packed_ice
setblock 181 205 304 minecraft:snow_block
fill 181 205 305 181 208 305 minecraft:packed_ice
setblock 181 205 308 minecraft:packed_ice
setblock 181 205 314 minecraft:snow_block
setblock 181 205 315 minecraft:packed_ice
setblock 182 205 278 minecraft:snow_block
fill 182 205 279 182 207 279 minecraft:packed_ice
setblock 182 205 283 minecraft:snow_block
fill 182 205 284 182 206 284 minecraft:packed_ice
setblock 182 205 298 minecraft:snow_block
fill 182 205 299 182 206 299 minecraft:packed_ice
setblock 182 205 303 minecraft:snow_block
fill 182 205 304 182 208 304 minecraft:packed_ice
setblock 182 205 308 minecraft:snow_block
fill 182 205 309 182 208 309 minecraft:packed_ice
setblock 182 205 313 minecraft:snow_block
fill 182 205 314 182 206 314 minecraft:packed_ice
setblock 142 206 282 minecraft:snow_block
setblock 142 206 297 minecraft:snow_block
fill 142 206 298 142 207 298 minecraft:packed_ice
setblock 142 206 302 minecraft:snow_block
fill 142 206 303 142 209 303 minecraft:packed_ice
setblock 142 206 307 minecraft:snow_block
fill 142 206 308 142 209 308 minecraft:packed_ice
setblock 143 206 301 minecraft:snow_block
fill 143 206 302 143 208 302 minecraft:packed_ice
setblock 143 206 306 minecraft:snow_block
fill 143 206 307 143 207 307 minecraft:packed_ice
setblock 152 206 276 minecraft:packed_ice
fill 153 206 275 153 209 275 minecraft:packed_ice
setblock 153 206 276 minecraft:snow_block
setblock 153 206 277 minecraft:packed_ice
fill 154 206 276 154 209 276 minecraft:packed_ice
setblock 156 206 278 minecraft:snow_block
setblock 157 206 277 minecraft:snow_block
setblock 157 206 278 minecraft:packed_ice
setblock 158 206 276 minecraft:snow_block
fill 158 206 277 161 206 277 minecraft:packed_ice
fill 159 206 276 159 208 276 minecraft:packed_ice
setblock 162 206 277 minecraft:snow_block
setblock 163 206 276 minecraft:snow_block
setblock 164 206 276 minecraft:packed_ice
setblock 165 206 303 minecraft:packed_ice
setblock 165 206 308 minecraft:packed_ice
setblock 166 206 302 minecraft:packed_ice
setblock 167 206 277 minecraft:snow_block
setblock 167 206 310 minecraft:packed_ice
setblock 168 206 276 minecraft:snow_block
fill 168 206 277 168 207 277 minecraft:packed_ice
fill 169 206 276 169 209 276 minecraft:packed_ice
setblock 171 206 278 minecraft:snow_block
setblock 171 206 302 minecraft:packed_ice
setblock 171 206 310 minecraft:packed_ice
setblock 172 206 277 minecraft:snow_block
fill 172 206 278 172 209 278 minecraft:packed_ice
setblock 172 206 309 minecraft:packed_ice
setblock 173 206 276 minecraft:snow_block
fill 173 206 277 173 209 277 minecraft:packed_ice
setblock 173 206 304 minecraft:packed_ice
setblock 173 206 308 minecraft:packed_ice
setblock 173 206 316 minecraft:snow_block
fill 174 206 276 174 209 276 minecraft:packed_ice
setblock 174 206 315 minecraft:snow_block
fill 174 206 316 174 209 316 minecraft:packed_ice
setblock 175 206 279 minecraft:snow_block
fill 175 206 315 175 208 315 minecraft:packed_ice
setblock 176 206 278 minecraft:snow_block
fill 176 206 279 176 207 279 minecraft:packed_ice
setblock 177 206 277 minecraft:snow_block
fill 177 206 278 177 208 278 minecraft:packed_ice
setblock 178 206 276 minecraft:snow_block
fill 178 206 277 178 208 277 minecraft:packed_ice
setblock 178 206 316 minecraft:snow_block
fill 179 206 276 179 209 276 minecraft:packed_ice
setblock 179 206 315 minecraft:snow_block
fill 179 206 316 179 209 316 minecraft:packed_ice
setblock 180 206 279 minecraft:snow_block
setblock 180 206 280 minecraft:packed_ice
setblock 180 206 315 minecraft:packed_ice
setblock 181 206 278 minecraft:snow_block
fill 181 206 279 181 207 279 minecraft:packed_ice
setblock 181 206 283 minecraft:snow_block
setblock 181 206 303 minecraft:snow_block
fill 181 206 304 181 208 304 minecraft:packed_ice
setblock 181 206 308 minecraft:snow_block
setblock 182 206 277 minecraft:snow_block
fill 182 206 278 182 207 278 minecraft:packed_ice
setblock 182 206 282 minecraft:snow_block
fill 182 206 283 182 207 283 minecraft:packed_ice
setblock 182 206 302 minecraft:snow_block
fill 182 206 303 182 209 303 minecraft:packed_ice
setblock 182 206 307 minecraft:snow_block
fill 182 206 308 182 209 308 minecraft:packed_ice
setblock 182 206 312 minecraft:snow_block
setblock 182 206 313 minecraft:packed_ice
setblock 141 207 299 minecraft:light_blue_concrete
setblock 142 207 301 minecraft:snow_block
fill 142 207 302 142 210 302 minecraft:packed_ice
setblock 142 207 306 minecraft:snow_block
fill 142 207 307 142 210 307 minecraft:packed_ice
setblock 143 207 300 minecraft:snow_block
setblock 143 207 301 minecraft:packed_ice
setblock 143 207 305 minecraft:snow_block
fill 143 207 306 143 210 306 minecraft:packed_ice
setblock 152 207 276 minecraft:snow_block
fill 153 207 276 153 208 276 minecraft:packed_ice
setblock 156 207 277 minecraft:snow_block
setblock 157 207 276 minecraft:snow_block
fill 157 207 277 159 207 277 minecraft:packed_ice
fill 158 207 276 158 208 276 minecraft:packed_ice
setblock 162 207 276 minecraft:snow_block
setblock 167 207 276 minecraft:snow_block
fill 168 207 276 168 210 276 minecraft:packed_ice
fill 168 207 305 169 207 306 minecraft:blue_ice
setblock 169 207 307 minecraft:blue_ice
setblock 170 207 278 minecraft:snow_block
setblock 170 207 306 minecraft:blue_ice
setblock 171 207 277 minecraft:snow_block
fill 171 207 278 171 208 278 minecraft:packed_ice
setblock 172 207 276 minecraft:snow_block
fill 172 207 277 172 210 277 minecraft:packed_ice
setblock 172 207 316 minecraft:snow_block
fill 173 207 276 173 210 276 minecraft:packed_ice
fill 173 207 316 173 210 316 minecraft:packed_ice
setblock 174 207 279 minecraft:snow_block
setblock 174 207 315 minecraft:packed_ice
setblock 175 207 278 minecraft:snow_block
setblock 175 207 279 minecraft:packed_ice
setblock 176 207 277 minecraft:snow_block
fill 176 207 278 176 208 278 minecraft:packed_ice
setblock 177 207 276 minecraft:snow_block
fill 177 207 277 177 209 277 minecraft:packed_ice
setblock 177 207 316 minecraft:snow_block
fill 178 207 276 178 210 276 minecraft:packed_ice
setblock 178 207 315 minecraft:snow_block
fill 178 207 316 178 210 316 minecraft:packed_ice
setblock 181 207 302 minecraft:snow_block
setblock 181 207 303 minecraft:packed_ice
setblock 181 207 307 minecraft:snow_block
setblock 182 207 276 minecraft:snow_block
setblock 182 207 277 minecraft:packed_ice
setblock 182 207 281 minecraft:snow_block
setblock 182 207 282 minecraft:packed_ice
setblock 182 207 301 minecraft:snow_block
fill 182 207 302 182 209 302 minecraft:packed_ice
setblock 182 207 306 minecraft:snow_block
fill 182 207 307 182 210 307 minecraft:packed_ice
setblock 182 207 311 minecraft:snow_block
setblock 182 207 316 minecraft:snow_block
fill 141 208 299 141 235 299 minecraft:packed_ice
setblock 142 208 300 minecraft:snow_block
fill 142 208 301 142 211 301 minecraft:packed_ice
setblock 142 208 305 minecraft:snow_block
fill 142 208 306 142 211 306 minecraft:packed_ice
setblock 142 208 310 minecraft:snow_block
setblock 143 208 304 minecraft:snow_block
fill 143 208 305 143 211 305 minecraft:packed_ice
setblock 144 208 278 minecraft:light[level=12]
setblock 144 208 285 minecraft:light[level=12]
setblock 144 208 292 minecraft:light[level=12]
setblock 144 208 299 minecraft:light[level=12]
setblock 144 208 306 minecraft:light[level=12]
setblock 144 208 313 minecraft:light[level=12]
fill 146 208 287 146 208 289 minecraft:blue_ice
fill 147 208 286 147 208 287 minecraft:blue_ice
fill 147 208 289 147 209 290 minecraft:blue_ice
fill 148 208 286 150 208 286 minecraft:blue_ice
fill 148 208 290 149 208 291 minecraft:blue_ice
fill 150 208 287 150 209 290 minecraft:blue_ice
fill 150 208 295 150 208 297 minecraft:blue_ice
setblock 151 208 278 minecraft:light[level=12]
setblock 151 208 285 minecraft:light[level=12]
fill 151 208 287 151 208 289 minecraft:blue_ice
setblock 151 208 292 minecraft:light[level=12]
fill 151 208 294 152 208 294 minecraft:blue_ice
fill 151 208 297 153 208 297 minecraft:blue_ice
setblock 151 208 299 minecraft:light[level=12]
setblock 151 208 306 minecraft:light[level=12]
setblock 151 208 313 minecraft:light[level=12]
fill 153 208 295 153 209 296 minecraft:blue_ice
fill 155 208 304 155 208 307 minecraft:blue_ice
setblock 156 208 276 minecraft:snow_block
fill 156 208 304 158 208 304 minecraft:blue_ice
fill 156 208 307 158 208 307 minecraft:blue_ice
fill 157 208 276 157 209 276 minecraft:packed_ice
setblock 158 208 278 minecraft:light[level=12]
setblock 158 208 285 minecraft:light[level=12]
setblock 158 208 292 minecraft:light[level=12]
setblock 158 208 299 minecraft:light[level=12]
fill 158 208 305 158 209 306 minecraft:blue_ice
setblock 158 208 313 minecraft:light[level=12]
setblock 160 208 290 minecraft:blue_ice
fill 161 208 288 161 208 289 minecraft:blue_ice
setblock 162 208 288 minecraft:blue_ice
setblock 165 208 278 minecraft:light[level=12]
setblock 165 208 285 minecraft:light[level=12]
setblock 165 208 292 minecraft:light[level=12]
setblock 165 208 299 minecraft:light[level=12]
setblock 165 208 306 minecraft:light[level=12]
setblock 165 208 313 minecraft:light[level=12]
setblock 167 208 276 minecraft:packed_ice
fill 168 208 306 169 208 306 minecraft:blue_ice
setblock 169 208 305 minecraft:blue_ice
setblock 170 208 277 minecraft:snow_block
setblock 171 208 276 minecraft:snow_block
fill 171 208 277 171 211 277 minecraft:packed_ice
fill 171 208 294 171 208 297 minecraft:blue_ice
setblock 171 208 316 minecraft:snow_block
fill 172 208 276 172 211 276 minecraft:packed_ice
setblock 172 208 285 minecraft:light[level=12]
setblock 172 208 292 minecraft:light[level=12]
fill 172 208 294 174 208 294 minecraft:blue_ice
fill 172 208 297 174 208 297 minecraft:blue_ice
setblock 172 208 299 minecraft:light[level=12]
setblock 172 208 306 minecraft:light[level=12]
setblock 172 208 313 minecraft:light[level=12]
fill 172 208 316 172 211 316 minecraft:packed_ice
fill 173 208 311 174 208 313 minecraft:blue_ice
setblock 174 208 278 minecraft:snow_block
fill 174 208 295 174 209 296 minecraft:blue_ice
fill 174 208 309 175 208 310 minecraft:blue_ice
fill 174 208 314 179 208 314 minecraft:blue_ice
setblock 175 208 277 minecraft:snow_block
fill 175 208 278 175 209 278 minecraft:packed_ice
setblock 176 208 276 minecraft:snow_block
fill 176 208 277 176 210 277 minecraft:packed_ice
fill 176 208 308 177 208 309 minecraft:blue_ice
setblock 176 208 316 minecraft:snow_block
fill 177 208 276 177 211 276 minecraft:packed_ice
fill 177 208 315 178 208 315 minecraft:blue_ice
fill 177 208 316 177 211 316 minecraft:packed_ice
fill 178 208 309 179 208 310 minecraft:blue_ice
setblock 179 208 278 minecraft:light[level=12]
setblock 179 208 285 minecraft:light[level=12]
setblock 179 208 292 minecraft:light[level=12]
setblock 179 208 299 minecraft:light[level=12]
setblock 179 208 306 minecraft:light[level=12]
fill 179 208 311 179 209 311 minecraft:packed_ice
fill 179 208 312 179 210 313 minecraft:blue_ice
fill 180 208 310 180 209 310 minecraft:packed_ice
fill 180 208 312 180 209 312 minecraft:packed_ice
setblock 180 208 313 minecraft:blue_ice
setblock 181 208 306 minecraft:snow_block
setblock 181 208 307 minecraft:packed_ice
fill 181 208 311 181 209 311 minecraft:packed_ice
setblock 182 208 280 minecraft:snow_block
setblock 182 208 281 minecraft:packed_ice
setblock 182 208 301 minecraft:packed_ice
setblock 182 208 305 minecraft:snow_block
fill 182 208 306 182 211 306 minecraft:packed_ice
setblock 182 208 310 minecraft:snow_block
setblock 183 208 309 minecraft:light_blue_concrete
fill 183 208 310 183 211 311 minecraft:packed_ice
fill 142 209 300 142 210 300 minecraft:packed_ice
setblock 142 209 304 minecraft:snow_block
fill 142 209 305 142 211 305 minecraft:packed_ice
setblock 142 209 309 minecraft:snow_block
setblock 143 209 303 minecraft:snow_block
fill 143 209 304 143 211 304 minecraft:packed_ice
fill 145 209 294 147 210 294 minecraft:white_concrete
fill 146 209 293 146 210 293 minecraft:white_concrete
fill 146 209 295 146 210 295 minecraft:white_concrete
setblock 147 209 287 minecraft:blue_ice
fill 148 209 286 149 209 286 minecraft:blue_ice
fill 148 209 290 149 210 290 minecraft:blue_ice
fill 150 209 295 150 209 296 minecraft:blue_ice
fill 151 209 297 152 210 297 minecraft:blue_ice
setblock 155 209 276 minecraft:snow_block
fill 155 209 305 155 209 306 minecraft:blue_ice
setblock 156 209 276 minecraft:packed_ice
fill 156 209 304 157 209 304 minecraft:blue_ice
fill 156 209 307 157 209 307 minecraft:blue_ice
fill 161 209 289 161 210 289 minecraft:blue_ice
setblock 169 209 277 minecraft:snow_block
fill 169 209 306 169 211 306 minecraft:blue_ice
setblock 170 209 276 minecraft:snow_block
fill 170 209 277 170 211 277 minecraft:packed_ice
fill 171 209 276 171 211 276 minecraft:packed_ice
fill 171 209 295 171 210 296 minecraft:blue_ice
fill 171 209 316 171 211 316 minecraft:packed_ice
fill 172 209 294 173 210 294 minecraft:blue_ice
fill 172 209 297 173 209 297 minecraft:blue_ice
setblock 173 209 278 minecraft:snow_block
setblock 174 209 277 minecraft:snow_block
setblock 174 209 278 minecraft:packed_ice
fill 174 209 310 174 209 313 minecraft:blue_ice
setblock 175 209 276 minecraft:snow_block
fill 175 209 277 175 211 277 minecraft:packed_ice
fill 175 209 309 175 209 310 minecraft:blue_ice
fill 175 209 314 179 209 314 minecraft:blue_ice
setblock 175 209 316 minecraft:snow_block
fill 176 209 276 176 211 276 minecraft:packed_ice
fill 176 209 309 178 209 309 minecraft:blue_ice
fill 176 209 315 177 209 315 minecraft:blue_ice
fill 176 209 316 176 211 316 minecraft:packed_ice
fill 178 209 310 179 209 310 minecraft:blue_ice
fill 180 209 291 180 215 291 minecraft:packed_ice
fill 181 209 306 181 211 306 minecraft:packed_ice
setblock 182 209 304 minecraft:snow_block
fill 182 209 305 182 211 305 minecraft:packed_ice
setblock 182 209 309 minecraft:snow_block
fill 182 209 310 182 211 310 minecraft:packed_ice
fill 183 209 309 183 244 309 minecraft:packed_ice
setblock 142 210 303 minecraft:snow_block
fill 142 210 304 142 211 304 minecraft:packed_ice
setblock 142 210 308 minecraft:snow_block
fill 142 210 309 142 211 310 minecraft:packed_ice
setblock 147 210 289 minecraft:blue_ice
fill 150 210 288 150 210 289 minecraft:blue_ice
setblock 153 210 275 minecraft:white_concrete
setblock 169 210 276 minecraft:snow_block
fill 170 210 276 170 211 276 minecraft:packed_ice
setblock 173 210 277 minecraft:snow_block
fill 173 210 301 173 211 301 minecraft:white_concrete
setblock 174 210 276 minecraft:snow_block
fill 174 210 277 174 211 277 minecraft:packed_ice
setblock 174 210 295 minecraft:blue_ice
setblock 174 210 312 minecraft:blue_ice
setblock 174 210 316 minecraft:snow_block
setblock 175 210 275 minecraft:light_blue_concrete
fill 175 210 276 175 211 276 minecraft:packed_ice
setblock 175 210 310 minecraft:blue_ice
fill 175 210 314 178 210 314 minecraft:blue_ice
fill 175 210 316 175 211 316 minecraft:packed_ice
setblock 178 210 310 minecraft:blue_ice
setblock 179 210 311 minecraft:blue_ice
fill 181 210 307 181 211 307 minecraft:packed_ice
setblock 182 210 303 minecraft:snow_block
fill 182 210 304 182 211 304 minecraft:packed_ice
setblock 182 210 308 minecraft:snow_block
fill 182 210 309 182 211 309 minecraft:packed_ice
fill 182 210 311 182 211 311 minecraft:packed_ice
setblock 141 211 278 minecraft:white_concrete
fill 141 211 279 141 244 279 minecraft:packed_ice
setblock 142 211 302 minecraft:snow_block
setblock 142 211 303 minecraft:packed_ice
setblock 142 211 307 minecraft:snow_block
setblock 142 211 308 minecraft:packed_ice
setblock 143 211 306 minecraft:snow_block
fill 153 211 275 153 244 275 minecraft:packed_ice
setblock 167 211 276 minecraft:packed_ice
setblock 168 211 276 minecraft:snow_block
fill 169 211 276 169 211 277 minecraft:packed_ice
setblock 170 211 316 minecraft:packed_ice
setblock 172 211 277 minecraft:snow_block
setblock 173 211 276 minecraft:snow_block
setblock 173 211 277 minecraft:packed_ice
setblock 173 211 315 minecraft:packed_ice
setblock 173 211 316 minecraft:snow_block
setblock 174 211 276 minecraft:packed_ice
setblock 174 211 315 minecraft:snow_block
setblock 174 211 316 minecraft:packed_ice
fill 175 211 275 175 244 275 minecraft:packed_ice
setblock 175 211 315 minecraft:packed_ice
setblock 178 211 316 minecraft:snow_block
setblock 181 211 308 minecraft:snow_block
setblock 182 211 303 minecraft:packed_ice
setblock 182 211 307 minecraft:snow_block
setblock 182 211 308 minecraft:packed_ice
setblock 183 211 293 minecraft:white_concrete
fill 141 212 278 141 244 278 minecraft:packed_ice
setblock 144 212 278 minecraft:light[level=15]
setblock 144 212 286 minecraft:light[level=15]
setblock 144 212 294 minecraft:light[level=15]
setblock 144 212 302 minecraft:light[level=15]
setblock 144 212 310 minecraft:light[level=15]
setblock 152 212 278 minecraft:light[level=15]
setblock 152 212 286 minecraft:light[level=15]
setblock 152 212 294 minecraft:light[level=15]
setblock 152 212 302 minecraft:light[level=15]
setblock 152 212 310 minecraft:light[level=15]
setblock 160 212 278 minecraft:light[level=15]
setblock 160 212 286 minecraft:light[level=15]
setblock 160 212 294 minecraft:light[level=15]
setblock 160 212 302 minecraft:light[level=15]
setblock 160 212 310 minecraft:light[level=15]
setblock 168 212 278 minecraft:light[level=15]
setblock 168 212 286 minecraft:light[level=15]
setblock 168 212 294 minecraft:light[level=15]
setblock 168 212 302 minecraft:light[level=15]
setblock 168 212 310 minecraft:light[level=15]
fill 176 212 275 176 213 275 minecraft:packed_ice
setblock 176 212 278 minecraft:light[level=15]
setblock 176 212 286 minecraft:light[level=15]
setblock 176 212 294 minecraft:light[level=15]
setblock 176 212 302 minecraft:light[level=15]
setblock 176 212 310 minecraft:light[level=15]
setblock 177 212 275 minecraft:white_concrete
fill 178 212 275 182 215 275 minecraft:packed_ice
setblock 183 212 277 minecraft:light_blue_concrete
fill 183 212 293 183 244 293 minecraft:packed_ice
fill 183 212 310 183 225 310 minecraft:packed_ice
setblock 183 212 311 minecraft:white_concrete
fill 141 213 312 141 214 312 minecraft:light_blue_concrete
fill 177 213 275 177 244 275 minecraft:packed_ice
fill 179 213 296 179 219 296 minecraft:packed_ice
fill 183 213 277 183 244 277 minecraft:packed_ice
fill 183 213 311 183 244 311 minecraft:packed_ice
fill 141 214 307 141 227 309 minecraft:packed_ice
setblock 141 214 310 minecraft:light_blue_concrete
setblock 144 214 278 minecraft:light[level=12]
setblock 144 214 285 minecraft:light[level=12]
schedule function dropper:buildpart/63_7 1t
