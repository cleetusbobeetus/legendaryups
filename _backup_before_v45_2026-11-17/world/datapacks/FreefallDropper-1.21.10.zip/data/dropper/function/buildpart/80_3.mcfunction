setblock 395 129 356 minecraft:light_blue_concrete
fill 396 129 363 396 131 363 minecraft:gray_concrete
fill 396 129 364 396 132 364 minecraft:gray_wool
setblock 399 129 322 minecraft:light_blue_stained_glass
setblock 415 129 323 minecraft:polished_deepslate
setblock 415 129 328 minecraft:polished_deepslate
fill 415 129 329 415 131 329 minecraft:gray_concrete
setblock 415 129 333 minecraft:polished_deepslate
fill 415 129 334 415 131 334 minecraft:gray_concrete
fill 416 129 323 416 131 323 minecraft:gray_concrete
setblock 416 129 327 minecraft:polished_deepslate
fill 416 129 328 416 131 328 minecraft:gray_concrete
setblock 416 129 332 minecraft:polished_deepslate
fill 416 129 333 416 131 333 minecraft:gray_concrete
setblock 416 129 337 minecraft:polished_deepslate
fill 416 129 338 416 131 338 minecraft:gray_concrete
setblock 416 129 352 minecraft:polished_deepslate
fill 416 129 353 416 131 353 minecraft:gray_concrete
setblock 417 129 326 minecraft:polished_deepslate
fill 417 129 327 417 131 327 minecraft:gray_concrete
setblock 417 129 331 minecraft:polished_deepslate
fill 417 129 332 417 131 332 minecraft:gray_concrete
setblock 417 129 336 minecraft:polished_deepslate
fill 417 129 337 417 131 337 minecraft:gray_concrete
setblock 417 129 341 minecraft:polished_deepslate
fill 417 129 342 417 131 342 minecraft:gray_concrete
setblock 417 129 346 minecraft:polished_deepslate
fill 417 129 347 417 130 347 minecraft:gray_concrete
setblock 417 129 351 minecraft:polished_deepslate
fill 417 129 352 417 131 352 minecraft:gray_concrete
setblock 417 129 356 minecraft:polished_deepslate
fill 417 129 357 417 131 357 minecraft:gray_concrete
setblock 377 130 325 minecraft:polished_deepslate
fill 377 130 326 377 131 326 minecraft:gray_concrete
setblock 377 130 330 minecraft:polished_deepslate
fill 377 130 331 377 131 331 minecraft:gray_concrete
setblock 377 130 335 minecraft:polished_deepslate
fill 377 130 336 377 131 336 minecraft:gray_concrete
fill 377 130 338 377 131 338 minecraft:gray_concrete
setblock 377 130 339 minecraft:ochre_froglight
setblock 377 130 350 minecraft:polished_deepslate
fill 377 130 351 377 131 351 minecraft:gray_concrete
setblock 377 130 355 minecraft:polished_deepslate
fill 377 130 356 377 131 356 minecraft:gray_concrete
setblock 377 130 360 minecraft:polished_deepslate
fill 377 130 361 378 131 361 minecraft:gray_concrete
setblock 378 130 324 minecraft:polished_deepslate
fill 378 130 325 378 131 325 minecraft:gray_concrete
setblock 378 130 329 minecraft:polished_deepslate
fill 378 130 330 378 131 330 minecraft:gray_concrete
setblock 378 130 334 minecraft:polished_deepslate
fill 378 130 335 378 131 335 minecraft:gray_concrete
setblock 378 130 354 minecraft:polished_deepslate
fill 378 130 355 378 131 355 minecraft:gray_concrete
setblock 378 130 359 minecraft:polished_deepslate
fill 378 130 360 378 131 360 minecraft:gray_concrete
setblock 378 130 363 minecraft:gray_concrete
setblock 379 130 323 minecraft:polished_deepslate
setblock 379 130 324 minecraft:gray_concrete
setblock 379 130 329 minecraft:gray_concrete
setblock 379 130 363 minecraft:polished_deepslate
fill 380 130 323 381 131 323 minecraft:gray_concrete
fill 380 130 363 380 131 363 minecraft:gray_concrete
setblock 387 130 327 minecraft:light_blue_concrete
fill 389 130 356 390 130 357 minecraft:light_blue_concrete
setblock 390 130 355 minecraft:light_blue_concrete
fill 390 130 358 390 131 358 minecraft:polished_deepslate
setblock 391 130 359 minecraft:light_blue_concrete
setblock 392 130 354 minecraft:light_blue_concrete
setblock 393 130 358 minecraft:light_blue_concrete
fill 395 130 363 395 131 363 minecraft:gray_concrete
fill 399 130 322 399 184 322 minecraft:gray_wool
fill 415 130 323 415 131 323 minecraft:gray_concrete
fill 415 130 328 415 131 328 minecraft:gray_concrete
setblock 415 130 332 minecraft:polished_deepslate
fill 415 130 333 415 131 333 minecraft:gray_concrete
setblock 415 130 336 minecraft:gray_concrete
setblock 416 130 326 minecraft:polished_deepslate
fill 416 130 327 416 131 327 minecraft:gray_concrete
setblock 416 130 331 minecraft:polished_deepslate
fill 416 130 332 416 131 332 minecraft:gray_concrete
setblock 416 130 336 minecraft:polished_deepslate
fill 416 130 337 416 131 337 minecraft:gray_concrete
fill 416 130 339 416 131 339 minecraft:gray_concrete
fill 416 130 354 416 131 354 minecraft:gray_concrete
setblock 417 130 325 minecraft:polished_deepslate
fill 417 130 326 417 131 326 minecraft:gray_concrete
setblock 417 130 330 minecraft:polished_deepslate
fill 417 130 331 417 131 331 minecraft:gray_concrete
setblock 417 130 335 minecraft:polished_deepslate
fill 417 130 336 417 131 336 minecraft:gray_concrete
setblock 417 130 340 minecraft:polished_deepslate
fill 417 130 341 417 131 341 minecraft:gray_concrete
setblock 417 130 350 minecraft:polished_deepslate
fill 417 130 351 417 131 351 minecraft:gray_concrete
setblock 417 130 355 minecraft:polished_deepslate
fill 417 130 356 417 131 356 minecraft:gray_concrete
setblock 417 130 359 minecraft:gray_concrete
setblock 417 130 360 minecraft:polished_deepslate
fill 418 130 325 418 136 327 minecraft:gray_wool
setblock 418 130 328 minecraft:light_blue_stained_glass
fill 418 130 329 418 157 330 minecraft:gray_wool
fill 418 130 354 418 178 356 minecraft:gray_wool
setblock 418 130 357 minecraft:light_blue_stained_glass
setblock 376 131 339 minecraft:light_blue_stained_glass
setblock 377 131 324 minecraft:polished_deepslate
setblock 377 131 325 minecraft:gray_concrete
setblock 377 131 329 minecraft:polished_deepslate
setblock 377 131 330 minecraft:gray_concrete
setblock 377 131 334 minecraft:polished_deepslate
setblock 377 131 335 minecraft:gray_concrete
setblock 377 131 339 minecraft:polished_deepslate
setblock 377 131 340 minecraft:yellow_concrete
setblock 377 131 349 minecraft:polished_deepslate
setblock 377 131 350 minecraft:gray_concrete
setblock 377 131 354 minecraft:polished_deepslate
setblock 377 131 355 minecraft:gray_concrete
setblock 377 131 359 minecraft:polished_deepslate
setblock 377 131 360 minecraft:gray_concrete
setblock 378 131 323 minecraft:polished_deepslate
setblock 378 131 324 minecraft:gray_concrete
setblock 378 131 328 minecraft:polished_deepslate
setblock 378 131 329 minecraft:gray_concrete
setblock 378 131 333 minecraft:polished_deepslate
setblock 378 131 334 minecraft:gray_concrete
setblock 378 131 353 minecraft:polished_deepslate
setblock 378 131 354 minecraft:gray_concrete
setblock 378 131 358 minecraft:polished_deepslate
setblock 378 131 359 minecraft:gray_concrete
setblock 378 131 362 minecraft:gray_concrete
setblock 378 131 363 minecraft:polished_deepslate
setblock 379 131 323 minecraft:gray_concrete
setblock 379 131 362 minecraft:polished_deepslate
setblock 379 131 363 minecraft:gray_concrete
fill 390 131 356 390 131 357 minecraft:polished_deepslate
setblock 391 131 358 minecraft:polished_deepslate
setblock 394 131 363 minecraft:gray_concrete
setblock 414 131 323 minecraft:gray_concrete
setblock 414 131 364 minecraft:light_blue_stained_glass
setblock 415 131 331 minecraft:polished_deepslate
setblock 415 131 332 minecraft:gray_concrete
setblock 415 131 336 minecraft:polished_deepslate
setblock 415 131 337 minecraft:gray_concrete
setblock 416 131 325 minecraft:polished_deepslate
setblock 416 131 326 minecraft:gray_concrete
setblock 416 131 330 minecraft:polished_deepslate
setblock 416 131 331 minecraft:gray_concrete
setblock 416 131 335 minecraft:polished_deepslate
setblock 416 131 336 minecraft:gray_concrete
setblock 416 131 355 minecraft:polished_deepslate
setblock 416 131 356 minecraft:gray_concrete
setblock 417 131 324 minecraft:polished_deepslate
setblock 417 131 325 minecraft:gray_concrete
setblock 417 131 329 minecraft:polished_deepslate
setblock 417 131 330 minecraft:gray_concrete
setblock 417 131 334 minecraft:polished_deepslate
setblock 417 131 335 minecraft:gray_concrete
setblock 417 131 339 minecraft:polished_deepslate
setblock 417 131 340 minecraft:gray_concrete
setblock 417 131 349 minecraft:polished_deepslate
setblock 417 131 350 minecraft:gray_concrete
setblock 417 131 354 minecraft:polished_deepslate
setblock 417 131 355 minecraft:gray_concrete
setblock 417 131 359 minecraft:polished_deepslate
fill 417 131 360 417 131 362 minecraft:gray_concrete
fill 418 131 328 418 184 328 minecraft:gray_wool
setblock 418 131 353 minecraft:light_blue_stained_glass
fill 418 131 357 418 140 357 minecraft:gray_wool
fill 376 132 339 376 184 339 minecraft:gray_wool
setblock 377 132 339 minecraft:yellow_concrete
setblock 380 132 322 minecraft:light_blue_stained_glass
fill 414 132 364 414 184 364 minecraft:gray_wool
fill 418 132 353 418 163 353 minecraft:gray_wool
setblock 377 133 338 minecraft:yellow_concrete
fill 380 133 322 380 181 322 minecraft:gray_wool
setblock 396 133 364 minecraft:light_blue_stained_glass
setblock 377 134 337 minecraft:yellow_concrete
setblock 379 134 325 minecraft:light[level=13]
setblock 379 134 332 minecraft:light[level=12]
setblock 379 134 333 minecraft:light[level=13]
setblock 379 134 339 minecraft:light[level=12]
setblock 379 134 341 minecraft:light[level=13]
setblock 379 134 346 minecraft:light[level=12]
setblock 379 134 349 minecraft:light[level=13]
setblock 379 134 353 minecraft:light[level=12]
setblock 379 134 357 minecraft:light[level=13]
setblock 379 134 360 minecraft:light[level=12]
fill 384 134 364 384 143 364 minecraft:gray_wool
setblock 385 134 364 minecraft:light_blue_stained_glass
setblock 386 134 325 minecraft:light[level=12]
setblock 386 134 332 minecraft:light[level=12]
setblock 386 134 339 minecraft:light[level=12]
setblock 386 134 346 minecraft:light[level=12]
setblock 386 134 353 minecraft:light[level=12]
setblock 386 134 360 minecraft:light[level=12]
setblock 387 134 325 minecraft:light[level=13]
setblock 387 134 333 minecraft:light[level=13]
setblock 387 134 341 minecraft:light[level=13]
setblock 387 134 349 minecraft:light[level=13]
setblock 387 134 357 minecraft:light[level=13]
setblock 393 134 325 minecraft:light[level=12]
setblock 393 134 332 minecraft:light[level=12]
setblock 393 134 339 minecraft:light[level=12]
setblock 393 134 346 minecraft:light[level=12]
setblock 393 134 353 minecraft:light[level=12]
setblock 393 134 360 minecraft:light[level=12]
setblock 395 134 325 minecraft:light[level=13]
setblock 395 134 333 minecraft:light[level=13]
setblock 395 134 341 minecraft:light[level=13]
setblock 395 134 349 minecraft:light[level=13]
setblock 395 134 357 minecraft:light[level=13]
fill 396 134 364 396 146 364 minecraft:gray_wool
setblock 400 134 325 minecraft:light[level=12]
setblock 400 134 332 minecraft:light[level=12]
setblock 400 134 339 minecraft:light[level=12]
setblock 400 134 346 minecraft:light[level=12]
setblock 400 134 353 minecraft:light[level=12]
setblock 400 134 360 minecraft:light[level=12]
setblock 403 134 325 minecraft:light[level=13]
setblock 403 134 333 minecraft:light[level=13]
setblock 403 134 341 minecraft:light[level=13]
setblock 403 134 349 minecraft:light[level=13]
setblock 403 134 357 minecraft:light[level=13]
setblock 407 134 322 minecraft:light_blue_stained_glass
setblock 407 134 325 minecraft:light[level=12]
setblock 407 134 332 minecraft:light[level=12]
setblock 407 134 339 minecraft:light[level=12]
setblock 407 134 346 minecraft:light[level=12]
setblock 407 134 353 minecraft:light[level=12]
setblock 407 134 360 minecraft:light[level=12]
setblock 411 134 325 minecraft:light[level=13]
setblock 411 134 333 minecraft:light[level=13]
setblock 411 134 341 minecraft:light[level=13]
setblock 411 134 349 minecraft:light[level=13]
setblock 411 134 357 minecraft:light[level=13]
setblock 414 134 325 minecraft:light[level=12]
setblock 414 134 332 minecraft:light[level=12]
setblock 414 134 339 minecraft:light[level=12]
setblock 414 134 346 minecraft:light[level=12]
setblock 414 134 353 minecraft:light[level=12]
setblock 414 134 360 minecraft:light[level=12]
setblock 377 135 338 minecraft:ochre_froglight
fill 385 135 364 385 184 364 minecraft:gray_wool
fill 407 135 322 407 145 322 minecraft:gray_wool
setblock 418 135 323 minecraft:light_blue_stained_glass
setblock 377 136 339 minecraft:yellow_concrete
fill 418 136 323 418 182 323 minecraft:gray_wool
setblock 376 137 363 minecraft:light_blue_stained_glass
fill 376 137 364 376 184 364 minecraft:gray_wool
fill 377 137 323 379 138 338 minecraft:gray_stained_glass
fill 377 137 339 377 138 343 minecraft:white_stained_glass
fill 377 137 344 377 138 348 minecraft:gray_stained_glass
fill 377 137 349 377 138 351 minecraft:white_stained_glass
fill 377 137 352 377 138 356 minecraft:gray_stained_glass
fill 377 137 357 378 138 359 minecraft:white_stained_glass
fill 377 137 360 378 138 363 minecraft:gray_stained_glass
fill 378 137 339 381 138 340 minecraft:gray_stained_glass
fill 378 137 341 378 138 344 minecraft:white_stained_glass
fill 378 137 345 378 138 349 minecraft:gray_stained_glass
fill 378 137 350 378 138 352 minecraft:white_stained_glass
fill 378 137 353 378 138 356 minecraft:gray_stained_glass
fill 379 137 341 383 138 341 minecraft:gray_stained_glass
fill 379 137 342 379 138 345 minecraft:white_stained_glass
fill 379 137 346 380 138 350 minecraft:gray_stained_glass
fill 379 137 351 380 138 353 minecraft:white_stained_glass
fill 379 137 354 381 138 357 minecraft:gray_stained_glass
fill 379 137 358 380 138 360 minecraft:white_stained_glass
fill 379 137 361 381 138 363 minecraft:gray_stained_glass
fill 380 137 323 380 138 325 minecraft:gray_stained_glass
fill 380 137 326 381 138 335 minecraft:white_stained_glass
fill 380 137 336 380 138 338 minecraft:gray_stained_glass
fill 380 137 342 385 138 342 minecraft:gray_stained_glass
fill 380 137 343 380 138 345 minecraft:white_stained_glass
fill 381 137 323 381 138 323 minecraft:gray_stained_glass
fill 381 137 324 383 138 325 minecraft:white_stained_glass
fill 381 137 336 382 138 337 minecraft:white_stained_glass
fill 381 137 338 381 138 338 minecraft:gray_stained_glass
fill 381 137 343 396 138 343 minecraft:gray_stained_glass
fill 381 137 344 381 138 346 minecraft:white_stained_glass
fill 381 137 347 381 138 351 minecraft:gray_stained_glass
fill 381 137 352 383 138 353 minecraft:white_stained_glass
fill 381 137 358 396 138 358 minecraft:gray_stained_glass
fill 381 137 359 384 138 360 minecraft:white_stained_glass
fill 382 137 323 384 138 323 minecraft:white_stained_glass
fill 382 137 326 382 138 327 minecraft:white_stained_glass
fill 382 137 328 385 138 334 minecraft:gray_stained_glass
fill 382 137 335 382 138 335 minecraft:white_stained_glass
fill 382 137 338 384 138 339 minecraft:white_stained_glass
fill 382 137 340 382 138 340 minecraft:gray_stained_glass
fill 382 137 344 395 138 344 minecraft:gray_stained_glass
fill 382 137 345 383 138 347 minecraft:white_stained_glass
fill 382 137 348 383 138 351 minecraft:gray_stained_glass
fill 382 137 354 396 138 354 minecraft:white_stained_glass
fill 382 137 355 384 138 357 minecraft:gray_stained_glass
fill 382 137 361 396 138 361 minecraft:white_stained_glass
fill 382 137 362 401 138 363 minecraft:gray_stained_glass
fill 383 137 326 386 138 327 minecraft:gray_stained_glass
fill 383 137 335 386 138 336 minecraft:gray_stained_glass
fill 383 137 337 383 138 337 minecraft:white_stained_glass
fill 383 137 340 387 138 340 minecraft:white_stained_glass
fill 384 137 324 387 138 325 minecraft:gray_stained_glass
fill 384 137 337 388 138 337 minecraft:gray_stained_glass
fill 384 137 341 393 138 341 minecraft:white_stained_glass
fill 384 137 345 394 138 345 minecraft:gray_stained_glass
fill 384 137 346 385 138 348 minecraft:white_stained_glass
fill 384 137 349 394 138 352 minecraft:gray_stained_glass
fill 384 137 353 398 138 353 minecraft:white_stained_glass
fill 385 137 323 390 138 323 minecraft:gray_stained_glass
fill 385 137 338 393 137 338 minecraft:gray_stained_glass
fill 385 137 339 385 138 339 minecraft:white_stained_glass
fill 385 137 355 393 138 355 minecraft:white_stained_glass
fill 385 137 356 399 138 357 minecraft:gray_stained_glass
fill 385 137 359 393 138 359 minecraft:gray_stained_glass
fill 385 137 360 398 138 360 minecraft:white_stained_glass
fill 386 137 328 387 138 334 minecraft:white_stained_glass
fill 386 137 339 393 138 339 minecraft:gray_stained_glass
fill 386 137 342 392 138 342 minecraft:white_stained_glass
fill 386 137 346 392 138 346 minecraft:gray_stained_glass
fill 386 137 347 393 138 348 minecraft:white_stained_glass
fill 387 137 326 389 138 327 minecraft:white_stained_glass
fill 387 137 335 389 138 335 minecraft:white_stained_glass
fill 387 137 336 387 138 336 minecraft:gray_stained_glass
fill 388 137 324 388 138 324 minecraft:gray_stained_glass
fill 388 137 325 391 138 325 minecraft:white_stained_glass
fill 388 137 328 388 138 329 minecraft:white_stained_glass
fill 388 137 330 390 138 333 minecraft:gray_stained_glass
fill 388 137 334 388 138 334 minecraft:white_stained_glass
fill 388 137 336 391 137 336 minecraft:white_stained_glass
fill 388 137 340 391 138 340 minecraft:gray_stained_glass
fill 389 137 324 393 138 324 minecraft:white_stained_glass
fill 389 137 328 392 138 329 minecraft:gray_stained_glass
fill 389 137 334 391 137 334 minecraft:gray_stained_glass
fill 389 137 337 391 137 337 minecraft:white_stained_glass
fill 390 137 326 390 138 326 minecraft:white_stained_glass
fill 390 137 327 405 138 327 minecraft:gray_stained_glass
setblock 390 137 335 minecraft:gray_stained_glass
fill 391 137 323 404 138 323 minecraft:white_stained_glass
fill 391 137 326 404 138 326 minecraft:gray_stained_glass
fill 391 137 330 391 138 330 minecraft:gray_stained_glass
fill 391 137 331 392 137 333 minecraft:white_stained_glass
fill 392 137 325 402 138 325 minecraft:gray_stained_glass
fill 392 137 330 394 138 330 minecraft:white_stained_glass
setblock 392 137 337 minecraft:gray_stained_glass
fill 392 137 340 394 138 340 minecraft:white_stained_glass
fill 393 137 328 393 138 328 minecraft:gray_stained_glass
fill 393 137 329 402 138 329 minecraft:white_stained_glass
fill 393 137 331 393 138 331 minecraft:white_stained_glass
fill 393 137 332 401 137 332 minecraft:gray_stained_glass
fill 393 137 342 397 138 342 minecraft:gray_stained_glass
fill 393 137 346 397 138 346 minecraft:white_stained_glass
fill 394 137 324 400 138 324 minecraft:gray_stained_glass
fill 394 137 328 400 138 328 minecraft:white_stained_glass
fill 394 137 331 400 138 331 minecraft:gray_stained_glass
setblock 394 137 333 minecraft:gray_stained_glass
fill 394 137 337 395 137 339 minecraft:white_stained_glass
fill 394 137 341 397 138 341 minecraft:gray_stained_glass
fill 394 137 347 395 138 347 minecraft:white_stained_glass
fill 394 137 348 400 138 348 minecraft:gray_stained_glass
fill 394 137 355 402 138 355 minecraft:gray_stained_glass
fill 394 137 359 401 138 359 minecraft:white_stained_glass
fill 395 137 330 398 138 330 minecraft:gray_stained_glass
fill 395 137 333 397 137 334 minecraft:white_stained_glass
fill 395 137 336 397 137 336 minecraft:gray_stained_glass
fill 395 137 340 398 138 340 minecraft:gray_stained_glass
fill 395 137 345 398 138 345 minecraft:white_stained_glass
fill 395 137 349 396 138 351 minecraft:gray_stained_glass
fill 395 137 352 399 138 352 minecraft:white_stained_glass
fill 396 137 335 397 137 335 minecraft:gray_stained_glass
fill 396 137 337 398 138 339 minecraft:gray_stained_glass
fill 396 137 344 399 138 344 minecraft:white_stained_glass
fill 396 137 347 401 138 347 minecraft:gray_stained_glass
fill 397 137 343 399 138 343 minecraft:white_stained_glass
fill 397 137 349 398 138 350 minecraft:gray_stained_glass
fill 397 137 351 401 138 351 minecraft:white_stained_glass
fill 397 137 354 403 138 354 minecraft:gray_stained_glass
fill 397 137 358 402 138 358 minecraft:white_stained_glass
fill 397 137 361 405 138 361 minecraft:gray_stained_glass
fill 398 137 333 402 138 333 minecraft:gray_stained_glass
fill 398 137 334 398 138 336 minecraft:white_stained_glass
fill 398 137 341 400 138 342 minecraft:white_stained_glass
fill 398 137 346 402 138 346 minecraft:gray_stained_glass
fill 399 137 330 403 138 330 minecraft:white_stained_glass
fill 399 137 334 403 138 334 minecraft:gray_stained_glass
fill 399 137 335 399 138 340 minecraft:white_stained_glass
fill 399 137 345 402 138 345 minecraft:gray_stained_glass
fill 399 137 349 399 138 349 minecraft:gray_stained_glass
fill 399 137 350 402 138 350 minecraft:white_stained_glass
fill 399 137 353 404 138 353 minecraft:gray_stained_glass
fill 399 137 360 406 138 360 minecraft:gray_stained_glass
fill 400 137 335 403 138 335 minecraft:gray_stained_glass
fill 400 137 336 400 138 340 minecraft:white_stained_glass
fill 400 137 343 403 138 344 minecraft:gray_stained_glass
fill 400 137 349 403 138 349 minecraft:white_stained_glass
fill 400 137 352 405 138 352 minecraft:gray_stained_glass
fill 400 137 356 400 138 356 minecraft:gray_stained_glass
fill 400 137 357 404 138 357 minecraft:white_stained_glass
fill 401 137 324 405 138 324 minecraft:white_stained_glass
fill 401 137 328 406 138 328 minecraft:gray_stained_glass
fill 401 137 331 404 138 331 minecraft:white_stained_glass
fill 401 137 336 404 138 342 minecraft:gray_stained_glass
fill 401 137 348 403 138 348 minecraft:white_stained_glass
fill 401 137 356 405 138 356 minecraft:white_stained_glass
fill 402 137 332 404 138 332 minecraft:white_stained_glass
fill 402 137 347 404 138 347 minecraft:white_stained_glass
fill 402 137 351 406 138 351 minecraft:gray_stained_glass
fill 402 137 359 407 138 359 minecraft:gray_stained_glass
fill 402 137 362 403 138 362 minecraft:gray_stained_glass
fill 402 137 363 407 138 363 minecraft:white_stained_glass
fill 403 137 325 407 138 325 minecraft:white_stained_glass
fill 403 137 329 407 138 329 minecraft:gray_stained_glass
fill 403 137 333 405 138 333 minecraft:white_stained_glass
fill 403 137 345 405 138 346 minecraft:white_stained_glass
fill 403 137 350 407 138 350 minecraft:gray_stained_glass
fill 403 137 355 406 138 355 minecraft:white_stained_glass
fill 403 137 358 409 138 358 minecraft:gray_stained_glass
fill 404 137 330 408 138 330 minecraft:gray_stained_glass
fill 404 137 334 405 138 335 minecraft:white_stained_glass
fill 404 137 343 406 138 344 minecraft:white_stained_glass
fill 404 137 348 408 138 349 minecraft:gray_stained_glass
fill 404 137 354 407 138 354 minecraft:white_stained_glass
fill 404 137 362 408 138 362 minecraft:white_stained_glass
fill 405 137 323 410 138 323 minecraft:gray_stained_glass
fill 405 137 326 408 138 326 minecraft:white_stained_glass
fill 405 137 331 408 138 332 minecraft:gray_stained_glass
fill 405 137 336 406 138 342 minecraft:white_stained_glass
fill 405 137 347 409 138 347 minecraft:gray_stained_glass
fill 405 137 353 408 138 353 minecraft:white_stained_glass
fill 405 137 357 410 138 357 minecraft:gray_stained_glass
fill 406 137 324 411 138 324 minecraft:gray_stained_glass
fill 406 137 327 409 138 327 minecraft:white_stained_glass
fill 406 137 333 409 138 334 minecraft:gray_stained_glass
fill 406 137 335 406 138 335 minecraft:white_stained_glass
fill 406 137 345 409 138 346 minecraft:gray_stained_glass
fill 406 137 352 409 138 352 minecraft:white_stained_glass
fill 406 137 356 411 138 356 minecraft:gray_stained_glass
fill 406 137 361 409 138 361 minecraft:white_stained_glass
fill 407 137 328 409 138 328 minecraft:white_stained_glass
fill 407 137 335 410 138 344 minecraft:gray_stained_glass
fill 407 137 351 409 138 351 minecraft:white_stained_glass
fill 407 137 355 411 138 355 minecraft:gray_stained_glass
fill 407 137 360 410 138 360 minecraft:white_stained_glass
fill 408 137 325 412 138 325 minecraft:gray_stained_glass
fill 408 137 329 410 138 329 minecraft:white_stained_glass
fill 408 137 350 410 138 350 minecraft:white_stained_glass
fill 408 137 354 412 138 354 minecraft:gray_stained_glass
fill 408 137 359 411 138 359 minecraft:white_stained_glass
fill 408 137 363 413 138 363 minecraft:gray_stained_glass
fill 409 137 326 413 138 326 minecraft:gray_stained_glass
fill 409 137 330 411 138 331 minecraft:white_stained_glass
fill 409 137 332 409 138 332 minecraft:gray_stained_glass
fill 409 137 348 411 138 349 minecraft:white_stained_glass
fill 409 137 353 413 138 353 minecraft:gray_stained_glass
fill 409 137 362 414 138 362 minecraft:gray_stained_glass
fill 410 137 327 413 138 328 minecraft:gray_stained_glass
fill 410 137 332 412 138 333 minecraft:white_stained_glass
fill 410 137 334 410 138 334 minecraft:gray_stained_glass
fill 410 137 345 411 138 347 minecraft:white_stained_glass
fill 410 137 351 413 138 352 minecraft:gray_stained_glass
fill 410 137 358 412 138 358 minecraft:white_stained_glass
fill 410 137 361 415 138 361 minecraft:gray_stained_glass
fill 411 137 323 414 138 323 minecraft:white_stained_glass
fill 411 137 329 415 138 329 minecraft:gray_stained_glass
fill 411 137 334 412 138 344 minecraft:white_stained_glass
fill 411 137 350 414 138 350 minecraft:gray_stained_glass
fill 411 137 357 413 138 357 minecraft:white_stained_glass
fill 411 137 360 416 138 360 minecraft:gray_stained_glass
fill 412 137 324 415 138 324 minecraft:white_stained_glass
fill 412 137 330 415 138 331 minecraft:gray_stained_glass
fill 412 137 345 412 138 346 minecraft:white_stained_glass
fill 412 137 347 415 138 349 minecraft:gray_stained_glass
fill 412 137 355 414 138 356 minecraft:white_stained_glass
fill 412 137 359 417 138 359 minecraft:gray_stained_glass
fill 413 137 325 415 138 325 minecraft:white_stained_glass
fill 413 137 332 416 138 334 minecraft:gray_stained_glass
fill 413 137 335 413 138 343 minecraft:white_stained_glass
fill 413 137 344 416 138 346 minecraft:gray_stained_glass
fill 413 137 354 415 138 354 minecraft:white_stained_glass
fill 413 137 358 417 138 358 minecraft:gray_stained_glass
fill 414 137 326 416 138 327 minecraft:white_stained_glass
fill 414 137 328 414 138 328 minecraft:gray_stained_glass
fill 414 137 335 417 138 343 minecraft:gray_stained_glass
fill 414 137 351 414 138 351 minecraft:gray_stained_glass
fill 414 137 352 416 138 353 minecraft:white_stained_glass
fill 414 137 357 417 138 357 minecraft:gray_stained_glass
fill 414 137 363 417 138 363 minecraft:white_stained_glass
fill 415 137 323 417 138 323 minecraft:gray_stained_glass
fill 415 137 328 417 138 328 minecraft:white_stained_glass
fill 415 137 350 417 138 351 minecraft:white_stained_glass
fill 415 137 355 415 138 355 minecraft:white_stained_glass
fill 415 137 356 417 138 356 minecraft:gray_stained_glass
fill 415 137 362 417 138 362 minecraft:white_stained_glass
fill 416 137 324 417 138 325 minecraft:gray_stained_glass
fill 416 137 329 417 138 331 minecraft:white_stained_glass
fill 416 137 347 416 138 347 minecraft:gray_stained_glass
fill 416 137 348 417 138 349 minecraft:white_stained_glass
fill 416 137 354 417 138 355 minecraft:gray_stained_glass
fill 416 137 361 417 138 361 minecraft:white_stained_glass
fill 417 137 326 417 138 326 minecraft:gray_stained_glass
fill 417 137 327 417 138 327 minecraft:white_stained_glass
fill 417 137 332 417 138 334 minecraft:white_stained_glass
fill 417 137 344 417 138 347 minecraft:white_stained_glass
fill 417 137 352 417 138 353 minecraft:gray_stained_glass
fill 417 137 360 417 138 360 minecraft:white_stained_glass
fill 418 137 325 418 164 325 minecraft:gray_wool
setblock 418 137 326 minecraft:light_blue_stained_glass
fill 418 137 327 418 184 327 minecraft:gray_wool
fill 376 138 363 376 182 363 minecraft:gray_wool
fill 385 138 338 391 138 338 minecraft:gray_stained_glass
fill 388 138 336 389 138 336 minecraft:white_stained_glass
setblock 389 138 334 minecraft:gray_stained_glass
fill 389 138 337 390 138 337 minecraft:white_stained_glass
fill 390 138 334 390 138 336 minecraft:ochre_froglight
fill 391 138 331 391 138 332 minecraft:white_stained_glass
fill 391 138 333 391 138 334 minecraft:ochre_froglight
fill 391 138 336 391 138 337 minecraft:ochre_froglight
setblock 392 138 331 minecraft:white_stained_glass
fill 392 138 332 392 138 333 minecraft:ochre_froglight
fill 392 138 337 392 138 338 minecraft:ochre_froglight
fill 393 138 332 394 138 332 minecraft:ochre_froglight
fill 393 138 338 394 138 338 minecraft:ochre_froglight
fill 394 138 333 395 138 333 minecraft:ochre_froglight
fill 394 138 337 395 138 337 minecraft:ochre_froglight
fill 394 138 339 395 138 339 minecraft:white_stained_glass
fill 395 138 332 401 138 332 minecraft:gray_stained_glass
fill 395 138 334 396 138 334 minecraft:ochre_froglight
fill 395 138 336 396 138 336 minecraft:ochre_froglight
setblock 395 138 338 minecraft:white_stained_glass
fill 396 138 333 397 138 333 minecraft:white_stained_glass
setblock 396 138 335 minecraft:ochre_froglight
setblock 397 138 334 minecraft:white_stained_glass
fill 397 138 335 397 138 336 minecraft:gray_stained_glass
fill 418 138 326 418 150 326 minecraft:gray_wool
setblock 377 139 338 minecraft:yellow_concrete
fill 408 139 364 410 156 364 minecraft:gray_wool
setblock 411 139 364 minecraft:light_blue_stained_glass
fill 412 139 364 413 184 364 minecraft:gray_wool
fill 418 139 332 418 181 335 minecraft:gray_wool
setblock 418 139 336 minecraft:light_blue_stained_glass
fill 376 140 341 376 172 343 minecraft:gray_wool
setblock 376 140 344 minecraft:light_blue_stained_glass
fill 376 140 345 376 150 348 minecraft:gray_wool
setblock 377 140 337 minecraft:ochre_froglight
setblock 379 140 325 minecraft:light[level=12]
setblock 379 140 332 minecraft:light[level=12]
setblock 379 140 339 minecraft:light[level=12]
setblock 379 140 346 minecraft:light[level=12]
setblock 379 140 353 minecraft:light[level=12]
setblock 379 140 360 minecraft:light[level=12]
setblock 386 140 325 minecraft:light[level=12]
setblock 386 140 332 minecraft:light[level=12]
setblock 386 140 339 minecraft:light[level=12]
setblock 386 140 346 minecraft:light[level=12]
setblock 386 140 353 minecraft:light[level=12]
setblock 386 140 360 minecraft:light[level=12]
setblock 391 140 364 minecraft:light_blue_stained_glass
setblock 393 140 325 minecraft:light[level=12]
setblock 393 140 332 minecraft:light[level=12]
setblock 393 140 339 minecraft:light[level=12]
setblock 393 140 346 minecraft:light[level=12]
setblock 393 140 353 minecraft:light[level=12]
setblock 393 140 360 minecraft:light[level=12]
setblock 400 140 325 minecraft:light[level=12]
setblock 400 140 332 minecraft:light[level=12]
setblock 400 140 339 minecraft:light[level=12]
setblock 400 140 346 minecraft:light[level=12]
setblock 400 140 353 minecraft:light[level=12]
setblock 400 140 360 minecraft:light[level=12]
setblock 407 140 325 minecraft:light[level=12]
setblock 407 140 332 minecraft:light[level=12]
setblock 407 140 339 minecraft:light[level=12]
setblock 407 140 346 minecraft:light[level=12]
setblock 407 140 353 minecraft:light[level=12]
setblock 407 140 360 minecraft:light[level=12]
fill 411 140 364 411 181 364 minecraft:gray_wool
setblock 414 140 325 minecraft:light[level=12]
setblock 414 140 332 minecraft:light[level=12]
setblock 414 140 339 minecraft:light[level=12]
setblock 414 140 346 minecraft:light[level=12]
setblock 414 140 353 minecraft:light[level=12]
setblock 414 140 360 minecraft:light[level=12]
setblock 418 140 331 minecraft:light_blue_stained_glass
fill 418 140 336 418 186 336 minecraft:gray_wool
fill 376 141 344 376 182 344 minecraft:gray_wool
fill 391 141 364 391 184 364 minecraft:gray_wool
fill 409 141 322 410 184 322 minecraft:gray_wool
setblock 411 141 322 minecraft:light_blue_stained_glass
fill 412 141 322 413 181 322 minecraft:gray_wool
fill 418 141 331 418 186 331 minecraft:gray_wool
setblock 418 141 338 minecraft:light_blue_stained_glass
setblock 418 141 357 minecraft:light_blue_stained_glass
setblock 377 142 323 minecraft:polished_deepslate
fill 377 142 324 377 143 324 minecraft:gray_concrete
fill 377 142 341 377 142 342 minecraft:gray_concrete
fill 377 142 355 377 142 357 minecraft:gray_concrete
setblock 377 142 358 minecraft:polished_deepslate
fill 377 142 359 377 142 362 minecraft:gray_concrete
setblock 377 142 363 minecraft:polished_deepslate
fill 378 142 323 378 143 323 minecraft:gray_concrete
fill 378 142 358 378 142 361 minecraft:gray_concrete
setblock 378 142 362 minecraft:polished_deepslate
fill 378 142 363 381 142 363 minecraft:gray_concrete
setblock 379 142 325 minecraft:light[level=13]
setblock 379 142 333 minecraft:light[level=13]
setblock 379 142 341 minecraft:light[level=13]
setblock 379 142 349 minecraft:light[level=13]
setblock 379 142 357 minecraft:light[level=13]
fill 379 142 362 382 142 362 minecraft:gray_concrete
setblock 382 142 363 minecraft:polished_deepslate
setblock 383 142 362 minecraft:polished_deepslate
fill 383 142 363 386 142 363 minecraft:gray_concrete
fill 384 142 362 387 142 362 minecraft:gray_concrete
setblock 386 142 323 minecraft:gray_concrete
setblock 387 142 323 minecraft:polished_deepslate
setblock 387 142 325 minecraft:light[level=13]
setblock 387 142 333 minecraft:light[level=13]
setblock 387 142 341 minecraft:light[level=13]
setblock 387 142 349 minecraft:light[level=13]
setblock 387 142 357 minecraft:light[level=13]
fill 387 142 361 388 142 361 minecraft:gray_concrete
setblock 387 142 363 minecraft:polished_deepslate
fill 388 142 323 391 142 323 minecraft:gray_concrete
fill 388 142 351 388 147 351 minecraft:black_concrete
setblock 388 142 362 minecraft:polished_deepslate
fill 388 142 363 391 142 363 minecraft:gray_concrete
setblock 389 142 361 minecraft:polished_deepslate
fill 389 142 362 392 142 362 minecraft:gray_concrete
fill 390 142 361 392 142 361 minecraft:gray_concrete
setblock 392 142 323 minecraft:polished_deepslate
setblock 392 142 363 minecraft:polished_deepslate
fill 393 142 323 395 143 323 minecraft:gray_concrete
fill 393 142 355 399 143 356 minecraft:black_concrete
setblock 393 142 362 minecraft:polished_deepslate
fill 393 142 363 396 142 363 minecraft:gray_concrete
fill 394 142 353 398 143 354 minecraft:black_concrete
fill 394 142 357 398 143 358 minecraft:black_concrete
setblock 394 142 362 minecraft:gray_concrete
setblock 395 142 325 minecraft:light[level=13]
setblock 395 142 333 minecraft:light[level=13]
setblock 395 142 341 minecraft:light[level=13]
setblock 395 142 349 minecraft:light[level=13]
setblock 397 142 363 minecraft:polished_deepslate
fill 399 142 354 399 143 354 minecraft:black_concrete
fill 399 142 357 399 143 357 minecraft:black_concrete
setblock 403 142 325 minecraft:light[level=13]
setblock 403 142 333 minecraft:light[level=13]
setblock 403 142 341 minecraft:light[level=13]
setblock 403 142 349 minecraft:light[level=13]
setblock 403 142 357 minecraft:light[level=13]
fill 404 142 323 406 142 323 minecraft:gray_concrete
fill 405 142 363 406 142 363 minecraft:gray_concrete
setblock 407 142 323 minecraft:polished_deepslate
fill 407 142 324 410 142 324 minecraft:gray_concrete
setblock 407 142 362 minecraft:gray_concrete
setblock 407 142 363 minecraft:polished_deepslate
fill 408 142 323 411 142 323 minecraft:gray_concrete
setblock 408 142 362 minecraft:polished_deepslate
fill 408 142 363 411 142 363 minecraft:gray_concrete
fill 409 142 362 412 142 362 minecraft:gray_concrete
setblock 410 142 325 minecraft:polished_deepslate
fill 411 142 322 411 184 322 minecraft:gray_wool
setblock 411 142 324 minecraft:polished_deepslate
fill 411 142 325 413 143 325 minecraft:gray_concrete
setblock 411 142 333 minecraft:light[level=13]
setblock 411 142 341 minecraft:light[level=13]
setblock 411 142 349 minecraft:light[level=13]
setblock 411 142 357 minecraft:light[level=13]
fill 411 142 361 413 142 361 minecraft:gray_concrete
setblock 412 142 323 minecraft:polished_deepslate
fill 412 142 324 415 142 324 minecraft:gray_concrete
setblock 412 142 363 minecraft:polished_deepslate
fill 413 142 323 416 142 323 minecraft:gray_concrete
setblock 413 142 362 minecraft:polished_deepslate
fill 413 142 363 416 142 363 minecraft:gray_concrete
setblock 414 142 361 minecraft:polished_deepslate
fill 414 142 362 417 142 362 minecraft:gray_concrete
setblock 416 142 324 minecraft:polished_deepslate
fill 416 142 325 417 144 325 minecraft:gray_concrete
setblock 416 142 359 minecraft:polished_deepslate
fill 416 142 360 417 142 361 minecraft:gray_concrete
setblock 417 142 323 minecraft:polished_deepslate
fill 417 142 324 417 145 324 minecraft:gray_concrete
fill 417 142 326 417 142 327 minecraft:gray_concrete
fill 417 142 336 417 142 337 minecraft:gray_concrete
setblock 417 142 338 minecraft:polished_deepslate
fill 417 142 339 417 142 342 minecraft:gray_concrete
setblock 417 142 358 minecraft:polished_deepslate
fill 417 142 359 417 143 359 minecraft:gray_concrete
setblock 417 142 363 minecraft:polished_deepslate
fill 418 142 338 418 149 342 minecraft:gray_wool
setblock 418 142 343 minecraft:light_blue_stained_glass
fill 418 142 344 418 156 344 minecraft:gray_wool
fill 418 142 357 418 184 357 minecraft:gray_wool
fill 377 143 323 377 146 323 minecraft:gray_concrete
setblock 377 143 357 minecraft:polished_deepslate
fill 377 143 358 377 143 361 minecraft:gray_concrete
setblock 377 143 362 minecraft:polished_deepslate
fill 377 143 363 380 143 363 minecraft:gray_concrete
setblock 378 143 360 minecraft:gray_concrete
setblock 378 143 361 minecraft:polished_deepslate
fill 378 143 362 381 143 362 minecraft:gray_concrete
setblock 381 143 363 minecraft:polished_deepslate
setblock 382 143 362 minecraft:polished_deepslate
fill 382 143 363 385 143 363 minecraft:gray_concrete
fill 383 143 362 386 143 362 minecraft:gray_concrete
setblock 386 143 323 minecraft:polished_deepslate
setblock 386 143 363 minecraft:polished_deepslate
fill 387 143 323 390 143 323 minecraft:gray_concrete
fill 387 143 351 387 147 352 minecraft:black_concrete
setblock 387 143 362 minecraft:polished_deepslate
fill 387 143 363 390 143 363 minecraft:gray_concrete
fill 388 143 350 388 147 350 minecraft:black_concrete
fill 388 143 352 388 147 352 minecraft:black_concrete
setblock 388 143 361 minecraft:polished_deepslate
fill 388 143 362 391 143 362 minecraft:gray_concrete
fill 389 143 351 389 147 351 minecraft:black_concrete
fill 389 143 361 390 143 361 minecraft:gray_concrete
fill 390 143 328 390 144 329 minecraft:gray_wool
setblock 391 143 323 minecraft:polished_deepslate
setblock 391 143 363 minecraft:polished_deepslate
fill 392 143 323 392 146 323 minecraft:gray_concrete
setblock 392 143 362 minecraft:polished_deepslate
fill 392 143 363 395 143 363 minecraft:gray_concrete
setblock 393 143 354 minecraft:black_concrete
setblock 393 143 357 minecraft:black_concrete
setblock 393 143 362 minecraft:gray_concrete
fill 395 143 352 398 143 352 minecraft:black_concrete
fill 395 143 359 397 143 359 minecraft:black_concrete
setblock 396 143 363 minecraft:polished_deepslate
setblock 399 143 353 minecraft:black_concrete
setblock 399 143 358 minecraft:black_concrete
fill 400 143 355 400 143 356 minecraft:black_concrete
fill 403 143 323 405 143 323 minecraft:gray_concrete
setblock 405 143 363 minecraft:gray_concrete
setblock 406 143 323 minecraft:polished_deepslate
fill 406 143 324 409 143 324 minecraft:gray_concrete
setblock 406 143 363 minecraft:polished_deepslate
fill 407 143 323 410 143 323 minecraft:gray_concrete
setblock 407 143 362 minecraft:polished_deepslate
fill 407 143 363 410 143 363 minecraft:gray_concrete
fill 408 143 362 411 143 362 minecraft:gray_concrete
setblock 409 143 325 minecraft:polished_deepslate
setblock 410 143 324 minecraft:polished_deepslate
fill 410 143 325 410 146 325 minecraft:gray_concrete
setblock 411 143 323 minecraft:polished_deepslate
fill 411 143 324 414 143 324 minecraft:gray_concrete
setblock 411 143 363 minecraft:polished_deepslate
fill 412 143 323 415 143 323 minecraft:gray_concrete
setblock 412 143 362 minecraft:polished_deepslate
fill 412 143 363 415 143 363 minecraft:gray_concrete
fill 413 143 362 416 143 362 minecraft:gray_concrete
setblock 415 143 324 minecraft:polished_deepslate
setblock 416 143 323 minecraft:polished_deepslate
fill 416 143 324 416 146 324 minecraft:gray_concrete
fill 416 143 361 417 143 361 minecraft:gray_concrete
setblock 416 143 363 minecraft:polished_deepslate
fill 417 143 323 417 146 323 minecraft:gray_concrete
setblock 417 143 326 minecraft:gray_concrete
fill 417 143 360 417 144 360 minecraft:gray_concrete
setblock 417 143 362 minecraft:polished_deepslate
fill 417 143 363 417 146 363 minecraft:gray_concrete
fill 418 143 343 418 181 343 minecraft:gray_wool
fill 377 144 358 377 144 360 minecraft:gray_concrete
setblock 377 144 361 minecraft:polished_deepslate
fill 377 144 362 378 144 363 minecraft:gray_concrete
setblock 379 144 363 minecraft:gray_concrete
setblock 380 144 363 minecraft:polished_deepslate
fill 381 144 363 384 144 363 minecraft:gray_concrete
fill 383 144 362 385 144 362 minecraft:gray_concrete
setblock 384 144 364 minecraft:light_blue_stained_glass
setblock 385 144 323 minecraft:polished_deepslate
setblock 385 144 363 minecraft:polished_deepslate
fill 386 144 323 389 144 323 minecraft:gray_concrete
setblock 386 144 362 minecraft:polished_deepslate
fill 386 144 363 389 144 363 minecraft:gray_concrete
fill 387 144 350 387 147 350 minecraft:black_concrete
fill 387 144 362 390 144 362 minecraft:gray_concrete
fill 389 144 350 389 147 350 minecraft:black_concrete
fill 389 144 352 389 147 352 minecraft:black_concrete
setblock 390 144 323 minecraft:polished_deepslate
setblock 390 144 363 minecraft:polished_deepslate
fill 391 144 323 391 147 323 minecraft:gray_concrete
setblock 391 144 362 minecraft:polished_deepslate
fill 391 144 363 394 144 363 minecraft:gray_concrete
fill 392 144 327 392 145 327 minecraft:light_gray_wool
setblock 392 144 362 minecraft:gray_concrete
fill 393 144 323 394 144 323 minecraft:gray_concrete
fill 395 144 355 395 146 355 minecraft:polished_deepslate
setblock 395 144 363 minecraft:polished_deepslate
fill 396 144 357 396 148 357 minecraft:polished_deepslate
fill 398 144 355 398 145 355 minecraft:polished_deepslate
fill 403 144 323 404 144 323 minecraft:gray_concrete
setblock 404 144 363 minecraft:gray_concrete
setblock 405 144 323 minecraft:polished_deepslate
fill 405 144 324 408 144 324 minecraft:gray_concrete
setblock 405 144 363 minecraft:polished_deepslate
fill 406 144 323 409 144 323 minecraft:gray_concrete
fill 406 144 363 409 144 363 minecraft:gray_concrete
fill 407 144 362 410 144 362 minecraft:gray_concrete
setblock 408 144 325 minecraft:polished_deepslate
fill 408 144 360 408 148 360 minecraft:polished_deepslate
setblock 409 144 324 minecraft:polished_deepslate
fill 409 144 325 409 147 325 minecraft:gray_concrete
setblock 410 144 323 minecraft:polished_deepslate
fill 410 144 324 413 144 324 minecraft:gray_concrete
setblock 410 144 363 minecraft:polished_deepslate
fill 411 144 323 414 144 323 minecraft:gray_concrete
fill 411 144 325 412 144 325 minecraft:gray_concrete
setblock 411 144 362 minecraft:polished_deepslate
fill 411 144 363 414 144 363 minecraft:gray_concrete
fill 412 144 362 415 144 362 minecraft:gray_concrete
setblock 413 144 325 minecraft:polished_deepslate
setblock 414 144 324 minecraft:polished_deepslate
setblock 415 144 323 minecraft:polished_deepslate
fill 415 144 324 415 147 324 minecraft:gray_concrete
setblock 415 144 363 minecraft:polished_deepslate
fill 416 144 323 416 147 323 minecraft:gray_concrete
setblock 416 144 362 minecraft:polished_deepslate
fill 416 144 363 416 147 363 minecraft:gray_concrete
setblock 417 144 326 minecraft:polished_deepslate
setblock 417 144 361 minecraft:polished_deepslate
fill 417 144 362 417 147 362 minecraft:gray_concrete
setblock 377 145 359 minecraft:gray_concrete
setblock 377 145 360 minecraft:polished_deepslate
fill 377 145 361 377 146 363 minecraft:gray_concrete
setblock 378 145 363 minecraft:gray_concrete
setblock 379 145 363 minecraft:polished_deepslate
fill 380 145 363 383 145 363 minecraft:gray_concrete
fill 383 145 362 384 145 362 minecraft:gray_concrete
setblock 384 145 323 minecraft:polished_deepslate
setblock 384 145 363 minecraft:polished_deepslate
fill 384 145 364 384 184 364 minecraft:gray_wool
fill 385 145 323 388 145 323 minecraft:gray_concrete
setblock 385 145 362 minecraft:polished_deepslate
fill 385 145 363 388 145 363 minecraft:gray_concrete
fill 386 145 351 386 147 352 minecraft:black_concrete
fill 386 145 362 389 145 362 minecraft:gray_concrete
fill 387 145 353 389 147 353 minecraft:black_concrete
setblock 389 145 323 minecraft:polished_deepslate
setblock 389 145 363 minecraft:polished_deepslate
fill 390 145 323 390 148 323 minecraft:gray_concrete
setblock 390 145 362 minecraft:polished_deepslate
fill 390 145 363 393 145 363 minecraft:gray_concrete
setblock 391 145 362 minecraft:gray_concrete
setblock 393 145 323 minecraft:gray_concrete
setblock 394 145 323 minecraft:polished_deepslate
setblock 394 145 363 minecraft:polished_deepslate
fill 402 145 323 403 145 323 minecraft:gray_concrete
fill 402 145 337 403 146 337 minecraft:white_wool
setblock 404 145 323 minecraft:polished_deepslate
fill 404 145 324 407 145 324 minecraft:gray_concrete
setblock 404 145 363 minecraft:polished_deepslate
fill 405 145 323 408 145 323 minecraft:gray_concrete
fill 405 145 363 408 145 363 minecraft:gray_concrete
setblock 407 145 325 minecraft:polished_deepslate
fill 407 145 362 409 145 362 minecraft:gray_concrete
setblock 408 145 324 minecraft:polished_deepslate
fill 408 145 325 408 148 325 minecraft:gray_concrete
setblock 409 145 323 minecraft:polished_deepslate
fill 409 145 324 412 145 324 minecraft:gray_concrete
setblock 409 145 363 minecraft:polished_deepslate
fill 410 145 323 413 145 323 minecraft:gray_concrete
setblock 410 145 362 minecraft:polished_deepslate
fill 410 145 363 413 145 363 minecraft:gray_concrete
setblock 411 145 325 minecraft:gray_concrete
fill 411 145 362 414 145 362 minecraft:gray_concrete
setblock 412 145 325 minecraft:polished_deepslate
setblock 413 145 324 minecraft:polished_deepslate
fill 413 145 325 413 148 325 minecraft:gray_concrete
setblock 414 145 323 minecraft:polished_deepslate
fill 414 145 324 414 148 324 minecraft:gray_concrete
setblock 414 145 363 minecraft:polished_deepslate
fill 415 145 323 415 148 323 minecraft:gray_concrete
setblock 415 145 362 minecraft:polished_deepslate
fill 415 145 363 415 148 363 minecraft:gray_concrete
setblock 416 145 362 minecraft:gray_concrete
setblock 417 145 325 minecraft:polished_deepslate
fill 417 145 326 417 148 326 minecraft:gray_concrete
setblock 417 145 360 minecraft:polished_deepslate
fill 417 145 361 417 148 361 minecraft:gray_concrete
fill 377 146 360 377 149 360 minecraft:gray_concrete
fill 377 146 364 378 180 364 minecraft:gray_wool
setblock 378 146 363 minecraft:polished_deepslate
setblock 379 146 325 minecraft:light[level=12]
setblock 379 146 332 minecraft:light[level=12]
setblock 379 146 339 minecraft:light[level=12]
setblock 379 146 346 minecraft:light[level=12]
setblock 379 146 353 minecraft:light[level=12]
setblock 379 146 360 minecraft:light[level=12]
fill 379 146 363 382 146 363 minecraft:gray_concrete
setblock 379 146 364 minecraft:light_blue_stained_glass
fill 380 146 364 381 154 364 minecraft:gray_wool
setblock 383 146 323 minecraft:polished_deepslate
setblock 383 146 362 minecraft:gray_concrete
setblock 383 146 363 minecraft:polished_deepslate
fill 384 146 323 387 146 323 minecraft:gray_concrete
setblock 384 146 362 minecraft:polished_deepslate
fill 384 146 363 387 146 363 minecraft:gray_concrete
fill 385 146 362 388 146 362 minecraft:gray_concrete
setblock 386 146 325 minecraft:light[level=12]
setblock 386 146 332 minecraft:light[level=12]
setblock 386 146 339 minecraft:light[level=12]
setblock 386 146 346 minecraft:light[level=12]
fill 386 146 350 386 147 350 minecraft:black_concrete
fill 386 146 353 386 147 353 minecraft:black_concrete
setblock 386 146 360 minecraft:light[level=12]
fill 387 146 349 389 147 349 minecraft:black_concrete
setblock 388 146 323 minecraft:polished_deepslate
fill 388 146 324 389 148 324 minecraft:gray_concrete
setblock 388 146 363 minecraft:polished_deepslate
setblock 388 146 364 minecraft:light_blue_stained_glass
fill 389 146 323 389 149 323 minecraft:gray_concrete
setblock 389 146 362 minecraft:polished_deepslate
fill 389 146 363 392 146 363 minecraft:gray_concrete
fill 390 146 350 390 147 352 minecraft:black_concrete
fill 390 146 362 390 147 362 minecraft:gray_concrete
setblock 393 146 323 minecraft:polished_deepslate
setblock 393 146 325 minecraft:light[level=12]
setblock 393 146 332 minecraft:light[level=12]
setblock 393 146 339 minecraft:light[level=12]
setblock 393 146 346 minecraft:light[level=12]
setblock 393 146 353 minecraft:light[level=12]
setblock 393 146 360 minecraft:light[level=12]
setblock 393 146 363 minecraft:polished_deepslate
fill 394 146 323 394 149 323 minecraft:gray_concrete
fill 400 146 323 402 146 323 minecraft:gray_concrete
setblock 400 146 325 minecraft:light[level=12]
setblock 400 146 332 minecraft:light[level=12]
setblock 400 146 339 minecraft:light[level=12]
setblock 400 146 346 minecraft:light[level=12]
setblock 400 146 353 minecraft:light[level=12]
setblock 400 146 360 minecraft:light[level=12]
setblock 402 146 364 minecraft:light_blue_stained_glass
setblock 403 146 322 minecraft:light_blue_stained_glass
setblock 403 146 323 minecraft:polished_deepslate
fill 403 146 324 406 146 324 minecraft:gray_concrete
fill 403 146 364 405 174 364 minecraft:gray_wool
fill 404 146 323 407 146 323 minecraft:gray_concrete
fill 404 146 355 404 147 355 minecraft:light_blue_stained_glass
fill 404 146 363 407 146 363 minecraft:gray_concrete
setblock 405 146 325 minecraft:gray_concrete
setblock 406 146 325 minecraft:polished_deepslate
setblock 407 146 322 minecraft:light_blue_stained_glass
setblock 407 146 324 minecraft:polished_deepslate
fill 407 146 325 407 149 325 minecraft:gray_concrete
setblock 407 146 332 minecraft:light[level=12]
setblock 407 146 339 minecraft:light[level=12]
setblock 407 146 346 minecraft:light[level=12]
setblock 407 146 353 minecraft:light[level=12]
fill 407 146 360 407 148 360 minecraft:polished_deepslate
fill 407 146 362 408 146 362 minecraft:gray_concrete
setblock 408 146 323 minecraft:polished_deepslate
fill 408 146 324 411 146 324 minecraft:gray_concrete
fill 408 146 359 408 148 359 minecraft:polished_deepslate
fill 408 146 361 408 148 361 minecraft:polished_deepslate
setblock 408 146 363 minecraft:polished_deepslate
fill 409 146 323 412 146 323 minecraft:gray_concrete
fill 409 146 360 409 148 360 minecraft:polished_deepslate
setblock 409 146 362 minecraft:polished_deepslate
fill 409 146 363 412 146 363 minecraft:gray_concrete
fill 410 146 362 413 146 362 minecraft:gray_concrete
setblock 411 146 325 minecraft:polished_deepslate
setblock 412 146 324 minecraft:polished_deepslate
fill 412 146 325 412 149 325 minecraft:gray_concrete
setblock 413 146 323 minecraft:polished_deepslate
fill 413 146 324 413 149 324 minecraft:gray_concrete
setblock 413 146 363 minecraft:polished_deepslate
fill 414 146 323 414 149 323 minecraft:gray_concrete
setblock 414 146 325 minecraft:light[level=12]
setblock 414 146 332 minecraft:light[level=12]
setblock 414 146 339 minecraft:light[level=12]
setblock 414 146 346 minecraft:light[level=12]
setblock 414 146 353 minecraft:light[level=12]
setblock 414 146 360 minecraft:light[level=12]
setblock 414 146 362 minecraft:polished_deepslate
fill 414 146 363 414 149 363 minecraft:gray_concrete
setblock 415 146 362 minecraft:gray_concrete
setblock 416 146 325 minecraft:polished_deepslate
setblock 417 146 324 minecraft:polished_deepslate
fill 417 146 325 417 149 325 minecraft:gray_concrete
fill 418 146 347 418 184 347 minecraft:gray_wool
setblock 418 146 348 minecraft:light_blue_stained_glass
fill 418 146 349 418 146 352 minecraft:gray_wool
setblock 377 147 323 minecraft:polished_deepslate
fill 377 147 344 377 147 347 minecraft:gray_concrete
setblock 377 147 348 minecraft:polished_deepslate
fill 377 147 361 377 147 362 minecraft:gray_concrete
setblock 377 147 363 minecraft:polished_deepslate
fill 378 147 323 378 150 323 minecraft:gray_concrete
fill 378 147 363 381 147 363 minecraft:gray_concrete
fill 379 147 364 379 150 364 minecraft:gray_wool
setblock 381 147 323 minecraft:gray_concrete
setblock 382 147 323 minecraft:polished_deepslate
setblock 382 147 363 minecraft:polished_deepslate
fill 383 147 323 386 147 323 minecraft:gray_concrete
setblock 383 147 362 minecraft:polished_deepslate
fill 383 147 363 386 147 363 minecraft:gray_concrete
fill 384 147 362 387 147 362 minecraft:gray_concrete
fill 385 147 351 385 147 352 minecraft:black_concrete
setblock 386 147 324 minecraft:polished_deepslate
setblock 386 147 349 minecraft:black_concrete
setblock 387 147 323 minecraft:polished_deepslate
fill 387 147 324 387 150 324 minecraft:gray_concrete
fill 387 147 354 389 147 354 minecraft:black_concrete
setblock 387 147 363 minecraft:polished_deepslate
fill 388 147 323 388 150 323 minecraft:gray_concrete
setblock 388 147 362 minecraft:polished_deepslate
fill 388 147 363 391 147 363 minecraft:gray_concrete
fill 388 147 364 388 184 364 minecraft:gray_wool
fill 389 147 362 389 148 362 minecraft:gray_concrete
setblock 390 147 324 minecraft:gray_concrete
setblock 390 147 353 minecraft:black_concrete
setblock 391 147 324 minecraft:polished_deepslate
setblock 392 147 323 minecraft:polished_deepslate
setblock 392 147 363 minecraft:polished_deepslate
fill 393 147 323 393 150 323 minecraft:gray_concrete
setblock 393 147 363 minecraft:gray_concrete
fill 395 147 323 395 148 323 minecraft:gray_concrete
setblock 396 147 364 minecraft:light_blue_stained_glass
fill 399 147 323 401 147 323 minecraft:gray_concrete
setblock 402 147 323 minecraft:polished_deepslate
fill 402 147 324 405 147 324 minecraft:gray_concrete
fill 402 147 364 402 179 364 minecraft:gray_wool
fill 403 147 322 403 178 322 minecraft:gray_wool
fill 403 147 323 406 147 323 minecraft:gray_concrete
fill 403 147 363 406 147 363 minecraft:gray_concrete
setblock 404 147 325 minecraft:gray_concrete
setblock 405 147 325 minecraft:polished_deepslate
setblock 406 147 324 minecraft:polished_deepslate
fill 406 147 325 406 150 325 minecraft:gray_concrete
fill 406 147 362 407 147 362 minecraft:gray_concrete
fill 407 147 322 407 181 322 minecraft:gray_wool
setblock 407 147 323 minecraft:polished_deepslate
fill 407 147 324 410 147 324 minecraft:gray_concrete
fill 407 147 359 407 148 359 minecraft:polished_deepslate
fill 407 147 361 407 148 361 minecraft:polished_deepslate
setblock 407 147 363 minecraft:polished_deepslate
fill 408 147 323 411 147 323 minecraft:gray_concrete
setblock 408 147 326 minecraft:gray_concrete
setblock 408 147 362 minecraft:polished_deepslate
fill 408 147 363 411 147 363 minecraft:gray_concrete
setblock 409 147 326 minecraft:polished_deepslate
fill 409 147 359 409 148 359 minecraft:polished_deepslate
fill 409 147 361 409 148 361 minecraft:polished_deepslate
fill 409 147 362 412 147 362 minecraft:gray_concrete
setblock 410 147 325 minecraft:polished_deepslate
setblock 411 147 324 minecraft:polished_deepslate
fill 411 147 325 411 150 325 minecraft:gray_concrete
setblock 412 147 323 minecraft:polished_deepslate
fill 412 147 324 412 150 324 minecraft:gray_concrete
setblock 412 147 363 minecraft:polished_deepslate
fill 413 147 323 413 150 323 minecraft:gray_concrete
setblock 413 147 362 minecraft:polished_deepslate
fill 413 147 363 413 150 363 minecraft:gray_concrete
fill 414 147 362 414 148 362 minecraft:gray_concrete
setblock 416 147 324 minecraft:polished_deepslate
fill 416 147 325 416 150 325 minecraft:gray_concrete
setblock 417 147 323 minecraft:polished_deepslate
fill 417 147 324 417 150 324 minecraft:gray_concrete
setblock 417 147 327 minecraft:gray_concrete
setblock 417 147 363 minecraft:polished_deepslate
fill 418 147 348 418 168 350 minecraft:gray_wool
setblock 418 147 351 minecraft:light_blue_stained_glass
fill 418 147 352 418 184 352 minecraft:gray_wool
setblock 377 148 322 minecraft:light_blue_stained_glass
fill 377 148 323 377 150 324 minecraft:gray_concrete
fill 377 148 344 377 148 346 minecraft:gray_concrete
setblock 377 148 347 minecraft:polished_deepslate
fill 377 148 348 377 149 350 minecraft:gray_concrete
setblock 377 148 361 minecraft:gray_concrete
setblock 377 148 362 minecraft:polished_deepslate
fill 377 148 363 380 148 363 minecraft:gray_concrete
fill 378 148 322 379 184 322 minecraft:gray_wool
fill 379 148 323 380 148 323 minecraft:gray_concrete
setblock 381 148 323 minecraft:polished_deepslate
setblock 381 148 363 minecraft:polished_deepslate
fill 382 148 323 385 148 323 minecraft:gray_concrete
fill 382 148 363 385 148 363 minecraft:gray_concrete
fill 383 148 362 386 148 362 minecraft:gray_concrete
setblock 384 148 324 minecraft:gray_concrete
setblock 385 148 324 minecraft:polished_deepslate
setblock 386 148 323 minecraft:polished_deepslate
fill 386 148 324 386 151 324 minecraft:gray_concrete
setblock 386 148 363 minecraft:polished_deepslate
fill 387 148 323 387 151 323 minecraft:gray_concrete
fill 387 148 352 387 151 352 minecraft:polished_deepslate
setblock 387 148 362 minecraft:polished_deepslate
fill 387 148 363 390 148 363 minecraft:gray_concrete
fill 388 148 350 388 150 350 minecraft:polished_deepslate
fill 388 148 362 388 150 362 minecraft:gray_concrete
fill 389 148 352 389 152 352 minecraft:polished_deepslate
setblock 390 148 324 minecraft:polished_deepslate
setblock 391 148 323 minecraft:polished_deepslate
fill 391 148 324 391 151 324 minecraft:gray_concrete
setblock 391 148 363 minecraft:polished_deepslate
fill 392 148 323 392 151 323 minecraft:gray_concrete
fill 392 148 363 392 149 363 minecraft:gray_concrete
setblock 396 148 323 minecraft:polished_deepslate
fill 396 148 364 396 185 364 minecraft:gray_wool
fill 397 148 323 400 148 323 minecraft:gray_concrete
setblock 401 148 323 minecraft:polished_deepslate
fill 401 148 324 404 148 324 minecraft:gray_concrete
fill 402 148 323 405 148 323 minecraft:gray_concrete
fill 402 148 363 405 148 363 minecraft:gray_concrete
setblock 403 148 325 minecraft:gray_concrete
setblock 404 148 325 minecraft:polished_deepslate
fill 404 148 355 404 156 355 minecraft:black_concrete
setblock 405 148 324 minecraft:polished_deepslate
fill 405 148 325 405 150 326 minecraft:gray_concrete
setblock 406 148 323 minecraft:polished_deepslate
fill 406 148 324 409 148 324 minecraft:gray_concrete
fill 406 148 326 407 148 326 minecraft:gray_concrete
setblock 406 148 360 minecraft:polished_deepslate
setblock 406 148 362 minecraft:gray_concrete
setblock 406 148 363 minecraft:polished_deepslate
fill 407 148 323 410 148 323 minecraft:gray_concrete
setblock 407 148 362 minecraft:polished_deepslate
fill 407 148 363 410 148 363 minecraft:gray_concrete
setblock 408 148 326 minecraft:polished_deepslate
setblock 408 148 358 minecraft:polished_deepslate
fill 408 148 362 411 148 362 minecraft:gray_concrete
setblock 409 148 325 minecraft:polished_deepslate
fill 409 148 326 410 150 326 minecraft:gray_concrete
setblock 410 148 324 minecraft:polished_deepslate
fill 410 148 325 410 151 325 minecraft:gray_concrete
setblock 410 148 360 minecraft:polished_deepslate
setblock 411 148 323 minecraft:polished_deepslate
fill 411 148 324 411 151 324 minecraft:gray_concrete
setblock 411 148 363 minecraft:polished_deepslate
fill 412 148 323 412 151 323 minecraft:gray_concrete
setblock 412 148 362 minecraft:polished_deepslate
fill 412 148 363 412 151 363 minecraft:gray_concrete
fill 413 148 362 413 150 362 minecraft:gray_concrete
setblock 414 148 325 minecraft:polished_deepslate
setblock 415 148 324 minecraft:polished_deepslate
setblock 416 148 323 minecraft:polished_deepslate
fill 416 148 324 416 151 324 minecraft:gray_concrete
fill 416 148 326 416 149 326 minecraft:gray_concrete
setblock 416 148 363 minecraft:polished_deepslate
fill 417 148 323 417 151 323 minecraft:gray_concrete
setblock 417 148 327 minecraft:polished_deepslate
setblock 417 148 362 minecraft:polished_deepslate
fill 417 148 363 417 151 363 minecraft:gray_concrete
fill 418 148 351 418 185 351 minecraft:gray_wool
fill 377 149 322 377 184 322 minecraft:gray_wool
setblock 377 149 325 minecraft:gray_concrete
fill 377 149 343 377 149 345 minecraft:gray_concrete
setblock 377 149 346 minecraft:polished_deepslate
fill 377 149 347 378 151 347 minecraft:gray_concrete
setblock 377 149 351 minecraft:polished_deepslate
fill 377 149 352 377 151 353 minecraft:gray_concrete
setblock 377 149 361 minecraft:polished_deepslate
fill 377 149 362 377 151 363 minecraft:gray_concrete
fill 378 149 346 378 152 346 minecraft:gray_concrete
fill 378 149 348 378 149 349 minecraft:gray_concrete
fill 378 149 363 379 149 363 minecraft:gray_concrete
setblock 379 149 323 minecraft:gray_concrete
setblock 380 149 323 minecraft:polished_deepslate
setblock 380 149 363 minecraft:polished_deepslate
fill 381 149 323 384 149 323 minecraft:gray_concrete
fill 381 149 363 384 149 363 minecraft:gray_concrete
fill 382 149 362 385 149 362 minecraft:gray_concrete
setblock 383 149 324 minecraft:gray_concrete
setblock 384 149 324 minecraft:polished_deepslate
setblock 385 149 323 minecraft:polished_deepslate
fill 385 149 324 385 152 324 minecraft:gray_concrete
setblock 385 149 363 minecraft:polished_deepslate
fill 386 149 323 386 152 323 minecraft:gray_concrete
setblock 386 149 362 minecraft:polished_deepslate
fill 386 149 363 389 149 363 minecraft:gray_concrete
fill 387 149 362 387 151 362 minecraft:gray_concrete
setblock 388 149 324 minecraft:gray_concrete
setblock 389 149 324 minecraft:polished_deepslate
setblock 390 149 323 minecraft:polished_deepslate
fill 390 149 324 390 152 324 minecraft:gray_concrete
setblock 390 149 363 minecraft:polished_deepslate
fill 391 149 323 391 152 323 minecraft:gray_concrete
fill 391 149 363 391 150 363 minecraft:gray_concrete
fill 392 149 324 392 150 324 minecraft:gray_concrete
setblock 395 149 323 minecraft:polished_deepslate
fill 396 149 323 399 149 323 minecraft:gray_concrete
setblock 399 149 324 minecraft:polished_deepslate
setblock 400 149 323 minecraft:polished_deepslate
fill 400 149 324 403 149 324 minecraft:gray_concrete
fill 401 149 323 404 149 323 minecraft:gray_concrete
setblock 402 149 325 minecraft:gray_concrete
fill 402 149 363 404 149 363 minecraft:gray_concrete
setblock 403 149 325 minecraft:polished_deepslate
setblock 404 149 324 minecraft:polished_deepslate
fill 404 149 325 404 151 326 minecraft:gray_concrete
fill 404 149 354 404 156 354 minecraft:black_concrete
setblock 405 149 323 minecraft:polished_deepslate
fill 405 149 324 408 149 324 minecraft:gray_concrete
fill 405 149 355 405 156 355 minecraft:black_concrete
setblock 405 149 362 minecraft:gray_concrete
setblock 405 149 363 minecraft:polished_deepslate
fill 406 149 323 409 149 323 minecraft:gray_concrete
setblock 406 149 326 minecraft:gray_concrete
setblock 406 149 362 minecraft:polished_deepslate
fill 406 149 363 409 149 363 minecraft:gray_concrete
setblock 407 149 326 minecraft:polished_deepslate
fill 407 149 362 410 149 362 minecraft:gray_concrete
setblock 408 149 325 minecraft:polished_deepslate
fill 408 149 326 408 152 326 minecraft:gray_concrete
setblock 409 149 324 minecraft:polished_deepslate
fill 409 149 325 409 152 325 minecraft:gray_concrete
setblock 410 149 323 minecraft:polished_deepslate
fill 410 149 324 410 152 324 minecraft:gray_concrete
setblock 410 149 363 minecraft:polished_deepslate
fill 411 149 323 411 152 323 minecraft:gray_concrete
setblock 411 149 326 minecraft:gray_concrete
setblock 411 149 362 minecraft:polished_deepslate
fill 411 149 363 411 152 363 minecraft:gray_concrete
fill 412 149 362 412 151 362 minecraft:gray_concrete
setblock 413 149 325 minecraft:polished_deepslate
setblock 414 149 324 minecraft:polished_deepslate
fill 414 149 325 414 151 325 minecraft:gray_concrete
setblock 415 149 323 minecraft:polished_deepslate
fill 415 149 324 415 152 324 minecraft:gray_concrete
setblock 415 149 363 minecraft:polished_deepslate
fill 416 149 323 416 152 323 minecraft:gray_concrete
fill 416 149 363 416 152 363 minecraft:gray_concrete
setblock 417 149 326 minecraft:polished_deepslate
fill 417 149 327 417 151 328 minecraft:gray_concrete
setblock 417 149 361 minecraft:polished_deepslate
fill 417 149 362 417 152 362 minecraft:gray_concrete
setblock 418 149 359 minecraft:light_blue_stained_glass
fill 418 149 360 418 181 361 minecraft:gray_wool
setblock 376 150 337 minecraft:light_blue_stained_glass
setblock 377 150 325 minecraft:polished_deepslate
fill 377 150 326 377 153 326 minecraft:gray_concrete
fill 377 150 343 377 150 344 minecraft:gray_concrete
setblock 377 150 345 minecraft:polished_deepslate
fill 377 150 346 377 153 346 minecraft:gray_concrete
fill 377 150 348 377 150 349 minecraft:gray_concrete
setblock 377 150 350 minecraft:polished_deepslate
fill 377 150 351 378 152 351 minecraft:gray_concrete
setblock 377 150 354 minecraft:gray_concrete
setblock 377 150 355 minecraft:polished_deepslate
setblock 377 150 360 minecraft:polished_deepslate
fill 377 150 361 377 152 361 minecraft:gray_concrete
fill 378 150 345 378 153 345 minecraft:gray_concrete
setblock 378 150 348 minecraft:gray_concrete
setblock 378 150 349 minecraft:polished_deepslate
fill 378 150 350 378 153 350 minecraft:gray_concrete
setblock 378 150 363 minecraft:gray_concrete
setblock 379 150 323 minecraft:polished_deepslate
setblock 379 150 325 minecraft:light[level=13]
setblock 379 150 333 minecraft:light[level=13]
setblock 379 150 341 minecraft:light[level=13]
setblock 379 150 349 minecraft:light[level=13]
setblock 379 150 357 minecraft:light[level=13]
setblock 379 150 363 minecraft:polished_deepslate
fill 380 150 323 383 150 323 minecraft:gray_concrete
fill 380 150 363 383 150 363 minecraft:gray_concrete
setblock 382 150 324 minecraft:gray_concrete
fill 382 150 362 384 150 362 minecraft:gray_concrete
setblock 383 150 324 minecraft:polished_deepslate
setblock 384 150 323 minecraft:polished_deepslate
fill 384 150 324 384 153 324 minecraft:gray_concrete
setblock 384 150 363 minecraft:polished_deepslate
fill 385 150 323 385 153 323 minecraft:gray_concrete
setblock 385 150 362 minecraft:polished_deepslate
fill 385 150 363 388 150 363 minecraft:gray_concrete
setblock 386 150 325 minecraft:gray_concrete
fill 386 150 362 386 152 362 minecraft:gray_concrete
setblock 387 150 325 minecraft:polished_deepslate
setblock 387 150 333 minecraft:light[level=13]
setblock 387 150 341 minecraft:light[level=13]
setblock 387 150 349 minecraft:light[level=13]
setblock 387 150 357 minecraft:light[level=13]
setblock 388 150 324 minecraft:polished_deepslate
fill 388 150 325 388 152 325 minecraft:gray_concrete
setblock 389 150 323 minecraft:polished_deepslate
fill 389 150 324 389 153 324 minecraft:gray_concrete
setblock 389 150 363 minecraft:polished_deepslate
fill 390 150 323 390 153 323 minecraft:gray_concrete
fill 390 150 363 390 151 363 minecraft:gray_concrete
setblock 394 150 323 minecraft:polished_deepslate
fill 395 150 323 398 150 323 minecraft:gray_concrete
setblock 395 150 325 minecraft:light[level=13]
setblock 395 150 333 minecraft:light[level=13]
setblock 395 150 341 minecraft:light[level=13]
setblock 395 150 349 minecraft:light[level=13]
setblock 395 150 357 minecraft:light[level=13]
setblock 398 150 324 minecraft:polished_deepslate
setblock 399 150 323 minecraft:polished_deepslate
fill 399 150 324 402 150 324 minecraft:gray_concrete
fill 400 150 323 403 150 323 minecraft:gray_concrete
fill 400 150 325 401 150 325 minecraft:gray_concrete
fill 401 150 363 403 150 363 minecraft:gray_concrete
setblock 402 150 325 minecraft:polished_deepslate
setblock 403 150 324 minecraft:polished_deepslate
fill 403 150 325 403 152 326 minecraft:gray_concrete
setblock 403 150 333 minecraft:light[level=13]
setblock 403 150 341 minecraft:light[level=13]
setblock 403 150 349 minecraft:light[level=13]
fill 403 150 354 403 156 355 minecraft:black_concrete
setblock 403 150 357 minecraft:light[level=13]
setblock 404 150 322 minecraft:light_blue_stained_glass
setblock 404 150 323 minecraft:polished_deepslate
fill 404 150 324 407 150 324 minecraft:gray_concrete
fill 404 150 356 404 156 356 minecraft:black_concrete
setblock 404 150 363 minecraft:polished_deepslate
fill 405 150 322 406 151 322 minecraft:gray_wool
fill 405 150 323 408 150 323 minecraft:gray_concrete
fill 405 150 354 405 156 354 minecraft:black_concrete
setblock 405 150 362 minecraft:polished_deepslate
fill 405 150 363 408 150 363 minecraft:gray_concrete
setblock 406 150 326 minecraft:polished_deepslate
fill 406 150 327 407 152 327 minecraft:gray_concrete
fill 406 150 362 409 150 362 minecraft:gray_concrete
setblock 407 150 325 minecraft:polished_deepslate
fill 407 150 326 407 153 326 minecraft:gray_concrete
setblock 408 150 324 minecraft:polished_deepslate
fill 408 150 325 408 153 325 minecraft:gray_concrete
setblock 409 150 323 minecraft:polished_deepslate
fill 409 150 324 409 153 324 minecraft:gray_concrete
setblock 409 150 363 minecraft:polished_deepslate
fill 410 150 323 410 153 323 minecraft:gray_concrete
setblock 410 150 362 minecraft:polished_deepslate
fill 410 150 363 410 153 363 minecraft:gray_concrete
setblock 411 150 326 minecraft:polished_deepslate
setblock 411 150 333 minecraft:light[level=13]
setblock 411 150 341 minecraft:light[level=13]
setblock 411 150 349 minecraft:light[level=13]
setblock 411 150 357 minecraft:light[level=13]
fill 411 150 362 411 152 362 minecraft:gray_concrete
setblock 412 150 325 minecraft:polished_deepslate
setblock 413 150 324 minecraft:polished_deepslate
fill 413 150 325 413 152 325 minecraft:gray_concrete
setblock 414 150 323 minecraft:polished_deepslate
fill 414 150 324 414 153 324 minecraft:gray_concrete
setblock 414 150 363 minecraft:polished_deepslate
fill 415 150 323 415 153 323 minecraft:gray_concrete
fill 415 150 363 415 153 363 minecraft:gray_concrete
setblock 416 150 326 minecraft:polished_deepslate
fill 416 150 327 416 153 327 minecraft:gray_concrete
setblock 417 150 325 minecraft:polished_deepslate
fill 417 150 326 417 153 326 minecraft:gray_concrete
setblock 417 150 329 minecraft:gray_concrete
fill 417 150 346 417 150 349 minecraft:gray_concrete
setblock 417 150 350 minecraft:polished_deepslate
fill 417 150 361 417 153 361 minecraft:gray_concrete
fill 418 150 338 418 181 338 minecraft:gray_wool
setblock 418 150 339 minecraft:light_blue_stained_glass
fill 418 150 340 418 184 342 minecraft:gray_wool
fill 418 150 359 418 184 359 minecraft:gray_wool
fill 376 151 337 376 174 337 minecraft:gray_wool
setblock 376 151 345 minecraft:light_blue_stained_glass
fill 376 151 346 376 184 348 minecraft:gray_wool
setblock 377 151 323 minecraft:gray_concrete
setblock 377 151 324 minecraft:polished_deepslate
fill 377 151 325 377 154 325 minecraft:gray_concrete
fill 377 151 327 377 152 327 minecraft:gray_concrete
setblock 377 151 343 minecraft:gray_concrete
setblock 377 151 344 minecraft:polished_deepslate
fill 377 151 345 377 154 345 minecraft:gray_concrete
setblock 377 151 348 minecraft:gray_concrete
setblock 377 151 349 minecraft:polished_deepslate
fill 377 151 350 377 154 350 minecraft:gray_concrete
setblock 377 151 354 minecraft:polished_deepslate
fill 377 151 355 377 151 358 minecraft:gray_concrete
setblock 377 151 359 minecraft:polished_deepslate
fill 377 151 360 377 152 360 minecraft:gray_concrete
setblock 378 151 323 minecraft:polished_deepslate
fill 378 151 344 378 154 344 minecraft:gray_concrete
setblock 378 151 348 minecraft:polished_deepslate
fill 378 151 349 379 153 349 minecraft:gray_concrete
setblock 378 151 352 minecraft:gray_concrete
setblock 378 151 353 minecraft:polished_deepslate
setblock 378 151 363 minecraft:polished_deepslate
fill 379 151 323 382 151 323 minecraft:gray_concrete
setblock 379 151 346 minecraft:gray_concrete
setblock 379 151 347 minecraft:polished_deepslate
fill 379 151 348 379 154 348 minecraft:gray_concrete
fill 379 151 350 379 151 351 minecraft:gray_concrete
fill 379 151 363 382 151 363 minecraft:gray_concrete
setblock 379 151 364 minecraft:light_blue_stained_glass
setblock 381 151 324 minecraft:gray_concrete
setblock 382 151 324 minecraft:polished_deepslate
fill 382 151 362 383 151 362 minecraft:gray_concrete
setblock 383 151 323 minecraft:polished_deepslate
fill 383 151 324 383 154 324 minecraft:gray_concrete
setblock 383 151 363 minecraft:polished_deepslate
fill 384 151 323 384 154 323 minecraft:gray_concrete
fill 384 151 325 385 151 325 minecraft:gray_concrete
setblock 384 151 362 minecraft:polished_deepslate
fill 384 151 363 387 151 363 minecraft:gray_concrete
fill 385 151 362 385 152 362 minecraft:gray_concrete
setblock 386 151 325 minecraft:polished_deepslate
setblock 387 151 324 minecraft:polished_deepslate
fill 387 151 325 387 153 325 minecraft:gray_concrete
setblock 388 151 323 minecraft:polished_deepslate
fill 388 151 324 388 154 324 minecraft:gray_concrete
setblock 388 151 363 minecraft:polished_deepslate
fill 389 151 323 389 154 323 minecraft:gray_concrete
setblock 389 151 325 minecraft:gray_concrete
fill 389 151 363 389 152 363 minecraft:gray_concrete
setblock 392 151 324 minecraft:polished_deepslate
setblock 393 151 323 minecraft:polished_deepslate
fill 394 151 323 397 151 323 minecraft:gray_concrete
setblock 397 151 324 minecraft:polished_deepslate
setblock 398 151 323 minecraft:polished_deepslate
fill 398 151 324 401 151 324 minecraft:gray_concrete
fill 399 151 323 402 151 323 minecraft:gray_concrete
fill 399 151 325 400 151 325 minecraft:gray_concrete
setblock 401 151 325 minecraft:polished_deepslate
fill 401 151 363 402 151 363 minecraft:gray_concrete
setblock 402 151 324 minecraft:polished_deepslate
fill 402 151 325 402 153 326 minecraft:gray_concrete
setblock 403 151 323 minecraft:polished_deepslate
fill 403 151 324 406 151 324 minecraft:gray_concrete
fill 403 151 356 403 156 356 minecraft:black_concrete
setblock 403 151 363 minecraft:polished_deepslate
fill 404 151 322 404 184 322 minecraft:gray_wool
fill 404 151 323 407 151 323 minecraft:gray_concrete
setblock 404 151 327 minecraft:polished_deepslate
fill 404 151 353 405 156 353 minecraft:black_concrete
setblock 404 151 362 minecraft:polished_deepslate
fill 404 151 363 407 151 363 minecraft:gray_concrete
setblock 405 151 325 minecraft:gray_concrete
setblock 405 151 326 minecraft:polished_deepslate
fill 405 151 327 405 154 327 minecraft:gray_concrete
fill 405 151 356 405 156 356 minecraft:black_concrete
fill 405 151 362 408 151 362 minecraft:gray_concrete
setblock 406 151 325 minecraft:polished_deepslate
fill 406 151 326 406 154 326 minecraft:gray_concrete
fill 406 151 355 406 156 355 minecraft:black_concrete
setblock 407 151 324 minecraft:polished_deepslate
fill 407 151 325 407 154 325 minecraft:gray_concrete
setblock 408 151 323 minecraft:polished_deepslate
fill 408 151 324 408 154 324 minecraft:gray_concrete
setblock 408 151 327 minecraft:gray_concrete
setblock 408 151 363 minecraft:polished_deepslate
fill 409 151 323 409 154 323 minecraft:gray_concrete
setblock 409 151 326 minecraft:gray_concrete
setblock 409 151 362 minecraft:polished_deepslate
fill 409 151 363 409 154 363 minecraft:gray_concrete
setblock 410 151 326 minecraft:polished_deepslate
fill 410 151 362 410 152 362 minecraft:gray_concrete
setblock 411 151 325 minecraft:polished_deepslate
setblock 411 151 326 minecraft:gray_concrete
setblock 412 151 324 minecraft:polished_deepslate
fill 412 151 325 412 153 325 minecraft:gray_concrete
setblock 413 151 323 minecraft:polished_deepslate
fill 413 151 324 413 154 324 minecraft:gray_concrete
setblock 413 151 363 minecraft:polished_deepslate
fill 414 151 322 416 167 322 minecraft:gray_wool
fill 414 151 323 414 154 323 minecraft:gray_concrete
fill 414 151 363 414 154 363 minecraft:gray_concrete
setblock 416 151 325 minecraft:polished_deepslate
fill 416 151 326 416 153 326 minecraft:gray_concrete
setblock 417 151 322 minecraft:light_blue_stained_glass
setblock 417 151 324 minecraft:polished_deepslate
fill 417 151 325 417 154 325 minecraft:gray_concrete
setblock 417 151 329 minecraft:polished_deepslate
fill 417 151 345 417 151 348 minecraft:gray_concrete
setblock 417 151 349 minecraft:polished_deepslate
fill 417 151 350 417 151 353 minecraft:gray_concrete
fill 417 151 360 417 154 360 minecraft:gray_concrete
fill 418 151 322 418 184 322 minecraft:gray_wool
setblock 418 151 326 minecraft:light_blue_stained_glass
fill 418 151 339 418 163 339 minecraft:gray_wool
fill 376 152 324 376 169 330 minecraft:gray_wool
setblock 376 152 331 minecraft:light_blue_stained_glass
fill 376 152 332 376 181 332 minecraft:gray_wool
setblock 376 152 333 minecraft:light_blue_stained_glass
fill 376 152 345 376 180 345 minecraft:gray_wool
setblock 377 152 323 minecraft:polished_deepslate
fill 377 152 324 377 153 324 minecraft:gray_concrete
setblock 377 152 328 minecraft:polished_deepslate
setblock 377 152 343 minecraft:polished_deepslate
fill 377 152 344 377 155 344 minecraft:gray_concrete
setblock 377 152 347 minecraft:gray_concrete
setblock 377 152 348 minecraft:polished_deepslate
fill 377 152 349 377 155 349 minecraft:gray_concrete
setblock 377 152 352 minecraft:gray_concrete
setblock 377 152 353 minecraft:polished_deepslate
fill 377 152 354 377 152 357 minecraft:gray_concrete
setblock 377 152 358 minecraft:polished_deepslate
fill 377 152 359 377 155 359 minecraft:gray_concrete
setblock 377 152 362 minecraft:gray_concrete
setblock 377 152 363 minecraft:polished_deepslate
fill 378 152 323 381 152 323 minecraft:gray_concrete
setblock 378 152 347 minecraft:polished_deepslate
fill 378 152 348 378 155 348 minecraft:gray_concrete
setblock 378 152 352 minecraft:polished_deepslate
fill 378 152 353 378 153 355 minecraft:gray_concrete
fill 378 152 363 381 152 363 minecraft:gray_concrete
setblock 379 152 325 minecraft:light[level=12]
setblock 379 152 332 minecraft:light[level=12]
setblock 379 152 339 minecraft:light[level=12]
setblock 379 152 345 minecraft:gray_concrete
setblock 379 152 346 minecraft:polished_deepslate
fill 379 152 347 380 154 347 minecraft:gray_concrete
setblock 379 152 350 minecraft:gray_concrete
setblock 379 152 351 minecraft:polished_deepslate
fill 379 152 352 379 155 352 minecraft:gray_concrete
setblock 379 152 353 minecraft:light[level=12]
setblock 379 152 360 minecraft:light[level=12]
fill 379 152 364 379 175 364 minecraft:gray_wool
fill 380 152 348 380 152 349 minecraft:gray_concrete
setblock 380 152 350 minecraft:polished_deepslate
setblock 381 152 322 minecraft:light_blue_stained_glass
setblock 381 152 324 minecraft:polished_deepslate
fill 382 152 322 383 169 322 minecraft:gray_wool
setblock 382 152 323 minecraft:polished_deepslate
fill 382 152 324 382 154 324 minecraft:gray_concrete
setblock 382 152 362 minecraft:gray_concrete
setblock 382 152 363 minecraft:polished_deepslate
fill 383 152 323 383 155 323 minecraft:gray_concrete
setblock 383 152 362 minecraft:polished_deepslate
fill 383 152 363 386 152 363 minecraft:gray_concrete
setblock 384 152 325 minecraft:gray_concrete
setblock 384 152 362 minecraft:gray_concrete
setblock 385 152 325 minecraft:polished_deepslate
setblock 386 152 324 minecraft:polished_deepslate
fill 386 152 325 386 153 325 minecraft:gray_concrete
setblock 386 152 332 minecraft:light[level=12]
setblock 386 152 339 minecraft:light[level=12]
setblock 386 152 346 minecraft:light[level=12]
setblock 386 152 353 minecraft:light[level=12]
setblock 386 152 360 minecraft:light[level=12]
setblock 387 152 323 minecraft:polished_deepslate
fill 387 152 324 387 154 324 minecraft:gray_concrete
setblock 387 152 363 minecraft:polished_deepslate
fill 388 152 323 388 155 323 minecraft:gray_concrete
fill 388 152 363 388 153 363 minecraft:gray_concrete
setblock 391 152 324 minecraft:polished_deepslate
setblock 392 152 323 minecraft:polished_deepslate
fill 393 152 323 396 152 323 minecraft:gray_concrete
setblock 393 152 325 minecraft:light[level=12]
setblock 393 152 332 minecraft:light[level=12]
setblock 393 152 339 minecraft:light[level=12]
setblock 393 152 346 minecraft:light[level=12]
setblock 393 152 353 minecraft:light[level=12]
setblock 393 152 360 minecraft:light[level=12]
setblock 397 152 323 minecraft:polished_deepslate
fill 397 152 324 400 152 324 minecraft:gray_concrete
fill 398 152 323 401 152 323 minecraft:gray_concrete
setblock 399 152 325 minecraft:gray_concrete
setblock 400 152 325 minecraft:polished_deepslate
setblock 400 152 332 minecraft:light[level=12]
setblock 400 152 339 minecraft:light[level=12]
setblock 400 152 346 minecraft:light[level=12]
setblock 400 152 353 minecraft:light[level=12]
setblock 400 152 360 minecraft:light[level=12]
setblock 401 152 324 minecraft:polished_deepslate
fill 401 152 325 401 154 326 minecraft:gray_concrete
setblock 401 152 363 minecraft:gray_concrete
setblock 402 152 323 minecraft:polished_deepslate
fill 402 152 324 405 152 324 minecraft:gray_concrete
fill 402 152 354 402 156 355 minecraft:black_concrete
setblock 402 152 363 minecraft:polished_deepslate
fill 403 152 323 406 152 323 minecraft:gray_concrete
setblock 403 152 327 minecraft:polished_deepslate
fill 403 152 353 403 156 353 minecraft:black_concrete
fill 403 152 363 406 152 363 minecraft:gray_concrete
setblock 404 152 325 minecraft:gray_concrete
setblock 404 152 326 minecraft:polished_deepslate
fill 404 152 327 404 154 327 minecraft:gray_concrete
fill 404 152 357 404 156 357 minecraft:black_concrete
fill 404 152 362 407 152 362 minecraft:gray_concrete
setblock 405 152 322 minecraft:light_blue_stained_glass
setblock 405 152 325 minecraft:polished_deepslate
fill 405 152 326 405 155 326 minecraft:gray_concrete
fill 406 152 322 406 159 322 minecraft:gray_wool
setblock 406 152 324 minecraft:polished_deepslate
fill 406 152 325 406 155 325 minecraft:gray_concrete
fill 406 152 354 406 156 354 minecraft:black_concrete
fill 406 152 356 406 156 356 minecraft:black_concrete
setblock 407 152 323 minecraft:polished_deepslate
fill 407 152 324 407 155 324 minecraft:gray_concrete
setblock 407 152 332 minecraft:light[level=12]
setblock 407 152 339 minecraft:light[level=12]
setblock 407 152 346 minecraft:light[level=12]
setblock 407 152 353 minecraft:light[level=12]
setblock 407 152 360 minecraft:light[level=12]
setblock 407 152 363 minecraft:polished_deepslate
fill 408 152 323 408 155 323 minecraft:gray_concrete
setblock 408 152 327 minecraft:polished_deepslate
setblock 408 152 362 minecraft:polished_deepslate
fill 408 152 363 408 155 363 minecraft:gray_concrete
setblock 409 152 326 minecraft:polished_deepslate
fill 409 152 362 409 153 362 minecraft:gray_concrete
setblock 410 152 325 minecraft:polished_deepslate
fill 410 152 326 410 153 326 minecraft:gray_concrete
setblock 411 152 324 minecraft:polished_deepslate
fill 411 152 325 411 154 325 minecraft:gray_concrete
setblock 412 152 323 minecraft:polished_deepslate
fill 412 152 324 412 154 324 minecraft:gray_concrete
setblock 412 152 363 minecraft:polished_deepslate
fill 413 152 323 413 155 323 minecraft:gray_concrete
fill 413 152 363 413 154 363 minecraft:gray_concrete
setblock 414 152 325 minecraft:light[level=12]
setblock 414 152 332 minecraft:light[level=12]
setblock 414 152 339 minecraft:light[level=12]
setblock 414 152 346 minecraft:light[level=12]
setblock 414 152 353 minecraft:light[level=12]
setblock 414 152 360 minecraft:light[level=12]
setblock 416 152 324 minecraft:polished_deepslate
fill 416 152 325 416 153 325 minecraft:gray_concrete
fill 417 152 322 417 182 322 minecraft:gray_wool
setblock 417 152 323 minecraft:polished_deepslate
fill 417 152 324 417 155 324 minecraft:gray_concrete
setblock 417 152 327 minecraft:gray_concrete
setblock 417 152 328 minecraft:polished_deepslate
fill 417 152 329 417 154 330 minecraft:gray_concrete
fill 417 152 345 417 152 347 minecraft:gray_concrete
setblock 417 152 348 minecraft:polished_deepslate
fill 417 152 349 417 152 352 minecraft:gray_concrete
setblock 417 152 353 minecraft:polished_deepslate
fill 417 152 354 417 153 356 minecraft:gray_concrete
setblock 417 152 363 minecraft:polished_deepslate
fill 418 152 326 418 182 326 minecraft:gray_wool
fill 376 153 331 376 178 331 minecraft:gray_wool
fill 376 153 333 376 167 333 minecraft:gray_wool
fill 377 153 323 380 153 323 minecraft:gray_concrete
setblock 377 153 327 minecraft:polished_deepslate
fill 377 153 328 377 155 329 minecraft:gray_concrete
fill 377 153 343 377 155 343 minecraft:gray_concrete
setblock 377 153 347 minecraft:polished_deepslate
fill 377 153 348 377 156 348 minecraft:gray_concrete
setblock 377 153 351 minecraft:gray_concrete
setblock 377 153 352 minecraft:polished_deepslate
fill 377 153 353 377 153 356 minecraft:gray_concrete
setblock 377 153 357 minecraft:polished_deepslate
fill 377 153 358 377 156 358 minecraft:gray_concrete
setblock 377 153 362 minecraft:polished_deepslate
fill 377 153 363 380 153 363 minecraft:gray_concrete
setblock 378 153 346 minecraft:polished_deepslate
fill 378 153 347 378 156 347 minecraft:gray_concrete
setblock 378 153 351 minecraft:polished_deepslate
fill 378 153 352 378 156 352 minecraft:gray_concrete
setblock 379 153 345 minecraft:polished_deepslate
fill 379 153 346 379 155 346 minecraft:gray_concrete
setblock 379 153 350 minecraft:polished_deepslate
fill 379 153 351 380 155 351 minecraft:gray_concrete
fill 379 153 353 379 154 353 minecraft:gray_concrete
setblock 380 153 348 minecraft:gray_concrete
setblock 380 153 349 minecraft:polished_deepslate
fill 380 153 350 380 156 350 minecraft:gray_concrete
fill 381 153 322 381 181 322 minecraft:gray_wool
setblock 381 153 323 minecraft:polished_deepslate
setblock 381 153 324 minecraft:gray_concrete
setblock 381 153 363 minecraft:polished_deepslate
fill 382 153 323 382 156 323 minecraft:gray_concrete
fill 382 153 363 385 153 363 minecraft:gray_concrete
fill 382 153 364 382 162 364 minecraft:gray_wool
setblock 383 153 364 minecraft:light_blue_stained_glass
setblock 384 153 325 minecraft:polished_deepslate
setblock 385 153 324 minecraft:polished_deepslate
setblock 385 153 325 minecraft:gray_concrete
setblock 386 153 323 minecraft:polished_deepslate
fill 386 153 324 386 154 324 minecraft:gray_concrete
setblock 386 153 363 minecraft:polished_deepslate
fill 387 153 323 387 155 323 minecraft:gray_concrete
fill 387 153 363 387 154 363 minecraft:gray_concrete
setblock 390 153 324 minecraft:polished_deepslate
setblock 391 153 323 minecraft:polished_deepslate
fill 392 153 323 395 153 323 minecraft:gray_concrete
setblock 396 153 323 minecraft:polished_deepslate
fill 397 153 323 399 153 324 minecraft:gray_concrete
setblock 399 153 325 minecraft:polished_deepslate
setblock 400 153 323 minecraft:gray_concrete
setblock 400 153 324 minecraft:polished_deepslate
fill 400 153 325 400 154 326 minecraft:gray_concrete
setblock 401 153 323 minecraft:polished_deepslate
fill 401 153 324 404 153 324 minecraft:gray_concrete
setblock 401 153 363 minecraft:polished_deepslate
fill 402 153 323 405 153 323 minecraft:gray_concrete
fill 402 153 353 402 156 353 minecraft:black_concrete
fill 402 153 356 402 156 356 minecraft:black_concrete
fill 402 153 363 405 153 363 minecraft:gray_concrete
setblock 403 153 325 minecraft:gray_concrete
setblock 403 153 326 minecraft:polished_deepslate
fill 403 153 327 403 154 327 minecraft:gray_concrete
fill 403 153 352 405 156 352 minecraft:black_concrete
fill 403 153 357 403 156 357 minecraft:black_concrete
setblock 404 153 325 minecraft:polished_deepslate
fill 404 153 326 404 156 326 minecraft:gray_concrete
fill 404 153 362 406 153 362 minecraft:gray_concrete
fill 405 153 322 405 184 322 minecraft:gray_wool
setblock 405 153 324 minecraft:polished_deepslate
fill 405 153 325 405 156 325 minecraft:gray_concrete
fill 405 153 357 405 156 357 minecraft:black_concrete
setblock 406 153 323 minecraft:polished_deepslate
fill 406 153 324 406 156 324 minecraft:gray_concrete
setblock 406 153 327 minecraft:gray_concrete
fill 406 153 353 406 156 353 minecraft:black_concrete
setblock 406 153 363 minecraft:polished_deepslate
fill 407 153 323 407 156 323 minecraft:gray_concrete
setblock 407 153 327 minecraft:polished_deepslate
fill 407 153 355 407 156 355 minecraft:black_concrete
setblock 407 153 362 minecraft:polished_deepslate
fill 407 153 363 407 156 363 minecraft:gray_concrete
setblock 408 153 326 minecraft:polished_deepslate
setblock 408 153 362 minecraft:gray_concrete
setblock 409 153 325 minecraft:polished_deepslate
fill 409 153 326 409 154 326 minecraft:gray_concrete
setblock 410 153 324 minecraft:polished_deepslate
fill 410 153 325 410 154 325 minecraft:gray_concrete
setblock 411 153 323 minecraft:polished_deepslate
fill 411 153 324 411 155 324 minecraft:gray_concrete
setblock 411 153 363 minecraft:polished_deepslate
fill 412 153 323 412 156 323 minecraft:gray_concrete
fill 412 153 363 412 154 363 minecraft:gray_concrete
setblock 415 153 324 minecraft:polished_deepslate
setblock 416 153 323 minecraft:polished_deepslate
setblock 416 153 324 minecraft:gray_concrete
setblock 416 153 363 minecraft:polished_deepslate
fill 417 153 323 417 155 323 minecraft:gray_concrete
setblock 417 153 327 minecraft:polished_deepslate
fill 417 153 328 417 156 328 minecraft:gray_concrete
fill 417 153 345 417 153 346 minecraft:gray_concrete
setblock 417 153 347 minecraft:polished_deepslate
fill 417 153 348 417 153 351 minecraft:gray_concrete
setblock 417 153 352 minecraft:polished_deepslate
fill 417 153 353 417 156 353 minecraft:gray_concrete
setblock 417 153 357 minecraft:polished_deepslate
fill 417 153 358 417 155 359 minecraft:gray_concrete
setblock 417 153 362 minecraft:polished_deepslate
fill 417 153 363 417 156 363 minecraft:gray_concrete
fill 376 154 354 376 154 355 minecraft:light_blue_stained_glass
fill 376 154 356 376 181 359 minecraft:gray_wool
setblock 377 154 326 minecraft:polished_deepslate
fill 377 154 327 377 155 327 minecraft:gray_concrete
setblock 377 154 330 minecraft:gray_concrete
setblock 377 154 346 minecraft:polished_deepslate
fill 377 154 347 377 157 347 minecraft:gray_concrete
setblock 377 154 351 minecraft:polished_deepslate
fill 377 154 352 377 154 355 minecraft:gray_concrete
setblock 377 154 356 minecraft:polished_deepslate
fill 377 154 357 377 157 357 minecraft:gray_concrete
setblock 378 154 345 minecraft:polished_deepslate
fill 378 154 346 378 157 346 minecraft:gray_concrete
setblock 378 154 349 minecraft:gray_concrete
setblock 378 154 350 minecraft:polished_deepslate
fill 378 154 351 378 157 351 minecraft:gray_concrete
fill 378 154 353 378 154 354 minecraft:gray_concrete
setblock 378 154 355 minecraft:polished_deepslate
fill 378 154 356 378 157 356 minecraft:gray_concrete
fill 378 154 363 379 154 363 minecraft:gray_concrete
setblock 379 154 323 minecraft:gray_concrete
setblock 379 154 349 minecraft:polished_deepslate
fill 379 154 350 379 157 350 minecraft:gray_concrete
setblock 379 154 354 minecraft:polished_deepslate
setblock 380 154 323 minecraft:polished_deepslate
setblock 380 154 348 minecraft:polished_deepslate
fill 380 154 349 380 156 349 minecraft:gray_concrete
setblock 380 154 352 minecraft:gray_concrete
setblock 380 154 363 minecraft:polished_deepslate
fill 381 154 323 381 156 323 minecraft:gray_concrete
fill 381 154 363 384 154 363 minecraft:gray_concrete
fill 383 154 364 383 184 364 minecraft:gray_wool
setblock 384 154 324 minecraft:polished_deepslate
setblock 385 154 323 minecraft:polished_deepslate
fill 385 154 324 385 155 324 minecraft:gray_concrete
setblock 385 154 363 minecraft:polished_deepslate
fill 386 154 323 386 156 323 minecraft:gray_concrete
setblock 386 154 363 minecraft:gray_concrete
setblock 390 154 323 minecraft:polished_deepslate
setblock 391 154 323 minecraft:gray_concrete
setblock 395 154 323 minecraft:polished_deepslate
fill 396 154 323 399 154 323 minecraft:gray_concrete
fill 397 154 324 398 154 324 minecraft:gray_concrete
setblock 399 154 324 minecraft:polished_deepslate
fill 399 154 325 399 156 325 minecraft:gray_concrete
setblock 400 154 323 minecraft:polished_deepslate
fill 400 154 324 403 154 324 minecraft:gray_concrete
fill 401 154 323 404 154 323 minecraft:gray_concrete
fill 401 154 354 401 156 355 minecraft:black_concrete
fill 401 154 363 404 154 363 minecraft:gray_concrete
setblock 402 154 325 minecraft:gray_concrete
setblock 402 154 326 minecraft:polished_deepslate
fill 402 154 352 402 156 352 minecraft:black_concrete
fill 402 154 357 402 156 357 minecraft:black_concrete
setblock 403 154 325 minecraft:polished_deepslate
fill 403 154 326 403 156 326 minecraft:gray_concrete
setblock 404 154 324 minecraft:polished_deepslate
fill 404 154 325 404 157 325 minecraft:gray_concrete
fill 404 154 358 404 156 358 minecraft:black_concrete
fill 404 154 362 405 154 362 minecraft:gray_concrete
setblock 405 154 323 minecraft:polished_deepslate
fill 405 154 324 405 157 324 minecraft:gray_concrete
setblock 405 154 363 minecraft:polished_deepslate
fill 406 154 323 406 157 323 minecraft:gray_concrete
setblock 406 154 327 minecraft:polished_deepslate
fill 406 154 352 406 156 352 minecraft:black_concrete
fill 406 154 357 406 156 357 minecraft:black_concrete
setblock 406 154 362 minecraft:polished_deepslate
fill 406 154 363 406 157 363 minecraft:gray_concrete
setblock 407 154 326 minecraft:polished_deepslate
fill 407 154 353 407 156 354 minecraft:black_concrete
fill 407 154 356 407 156 356 minecraft:black_concrete
setblock 407 154 362 minecraft:gray_concrete
setblock 408 154 325 minecraft:polished_deepslate
setblock 408 154 326 minecraft:gray_concrete
setblock 409 154 324 minecraft:polished_deepslate
fill 409 154 325 409 155 325 minecraft:gray_concrete
setblock 410 154 323 minecraft:polished_deepslate
fill 410 154 324 410 155 324 minecraft:gray_concrete
setblock 410 154 363 minecraft:polished_deepslate
fill 411 154 323 411 156 323 minecraft:gray_concrete
fill 411 154 363 411 155 363 minecraft:gray_concrete
setblock 414 154 324 minecraft:polished_deepslate
setblock 415 154 323 minecraft:polished_deepslate
setblock 415 154 363 minecraft:polished_deepslate
fill 416 154 323 416 155 323 minecraft:gray_concrete
fill 416 154 363 416 155 363 minecraft:gray_concrete
setblock 417 154 326 minecraft:polished_deepslate
fill 417 154 327 417 157 327 minecraft:gray_concrete
setblock 417 154 331 minecraft:polished_deepslate
setblock 417 154 346 minecraft:polished_deepslate
fill 417 154 347 417 154 350 minecraft:gray_concrete
setblock 417 154 351 minecraft:polished_deepslate
fill 417 154 352 417 157 352 minecraft:gray_concrete
fill 417 154 354 417 154 355 minecraft:gray_concrete
setblock 417 154 356 minecraft:polished_deepslate
fill 417 154 357 417 157 357 minecraft:gray_concrete
setblock 417 154 361 minecraft:polished_deepslate
fill 417 154 362 417 155 362 minecraft:gray_concrete
fill 376 155 354 376 180 355 minecraft:gray_wool
setblock 377 155 326 minecraft:gray_concrete
setblock 377 155 330 minecraft:polished_deepslate
setblock 377 155 345 minecraft:polished_deepslate
fill 377 155 346 377 158 346 minecraft:gray_concrete
setblock 377 155 350 minecraft:polished_deepslate
fill 377 155 351 377 155 354 minecraft:gray_concrete
setblock 377 155 355 minecraft:polished_deepslate
fill 377 155 356 377 158 356 minecraft:gray_concrete
fill 378 155 345 378 156 345 minecraft:gray_concrete
setblock 378 155 349 minecraft:polished_deepslate
fill 378 155 350 378 158 350 minecraft:gray_concrete
setblock 378 155 353 minecraft:gray_concrete
setblock 378 155 354 minecraft:polished_deepslate
fill 378 155 355 378 158 355 minecraft:gray_concrete
setblock 379 155 347 minecraft:gray_concrete
setblock 379 155 348 minecraft:polished_deepslate
fill 379 155 349 379 158 349 minecraft:gray_concrete
setblock 379 155 353 minecraft:polished_deepslate
fill 379 155 354 379 158 354 minecraft:gray_concrete
setblock 380 155 323 minecraft:gray_concrete
setblock 380 155 348 minecraft:gray_concrete
setblock 380 155 352 minecraft:polished_deepslate
fill 380 155 363 383 155 363 minecraft:gray_concrete
fill 380 155 364 380 180 364 minecraft:gray_wool
setblock 381 155 364 minecraft:light_blue_stained_glass
setblock 383 155 324 minecraft:polished_deepslate
setblock 384 155 323 minecraft:polished_deepslate
setblock 384 155 324 minecraft:gray_concrete
setblock 384 155 363 minecraft:polished_deepslate
fill 385 155 323 385 156 323 minecraft:gray_concrete
setblock 385 155 363 minecraft:gray_concrete
fill 386 155 364 386 161 364 minecraft:gray_wool
setblock 387 155 364 minecraft:light_blue_stained_glass
fill 396 155 323 398 155 323 minecraft:gray_concrete
setblock 398 155 324 minecraft:polished_deepslate
setblock 399 155 323 minecraft:polished_deepslate
fill 399 155 324 402 155 324 minecraft:gray_concrete
fill 400 155 323 403 155 323 minecraft:gray_concrete
fill 400 155 325 401 155 325 minecraft:gray_concrete
setblock 401 155 326 minecraft:polished_deepslate
fill 401 155 353 401 156 353 minecraft:black_concrete
fill 401 155 356 401 156 356 minecraft:black_concrete
fill 401 155 363 403 155 363 minecraft:gray_concrete
setblock 402 155 325 minecraft:polished_deepslate
fill 402 155 326 402 156 326 minecraft:gray_concrete
setblock 403 155 324 minecraft:polished_deepslate
fill 403 155 325 403 158 325 minecraft:gray_concrete
fill 403 155 351 405 156 351 minecraft:black_concrete
fill 403 155 358 403 156 358 minecraft:black_concrete
setblock 404 155 323 minecraft:polished_deepslate
fill 404 155 324 404 158 324 minecraft:gray_concrete
setblock 404 155 363 minecraft:polished_deepslate
fill 405 155 323 405 158 323 minecraft:gray_concrete
fill 405 155 358 406 156 358 minecraft:black_concrete
fill 405 155 363 405 158 363 minecraft:gray_concrete
setblock 406 155 326 minecraft:polished_deepslate
setblock 407 155 325 minecraft:polished_deepslate
setblock 407 155 326 minecraft:gray_concrete
fill 407 155 357 407 156 357 minecraft:black_concrete
setblock 408 155 324 minecraft:polished_deepslate
fill 408 155 325 408 156 325 minecraft:gray_concrete
setblock 409 155 323 minecraft:polished_deepslate
fill 409 155 324 409 156 324 minecraft:gray_concrete
setblock 409 155 363 minecraft:polished_deepslate
fill 410 155 323 410 157 323 minecraft:gray_concrete
setblock 410 155 363 minecraft:gray_concrete
setblock 414 155 323 minecraft:polished_deepslate
setblock 415 155 323 minecraft:gray_concrete
setblock 416 155 351 minecraft:polished_deepslate
fill 416 155 352 416 157 353 minecraft:gray_concrete
setblock 417 155 325 minecraft:polished_deepslate
fill 417 155 326 417 157 326 minecraft:gray_concrete
setblock 417 155 329 minecraft:gray_concrete
setblock 417 155 330 minecraft:polished_deepslate
fill 417 155 331 417 158 331 minecraft:gray_concrete
fill 417 155 346 417 155 349 minecraft:gray_concrete
setblock 417 155 350 minecraft:polished_deepslate
fill 417 155 351 417 158 351 minecraft:gray_concrete
setblock 417 155 354 minecraft:gray_concrete
setblock 417 155 355 minecraft:polished_deepslate
fill 417 155 356 417 158 356 minecraft:gray_concrete
setblock 417 155 360 minecraft:polished_deepslate
fill 417 155 361 417 158 361 minecraft:gray_concrete
setblock 377 156 328 minecraft:gray_concrete
setblock 377 156 329 minecraft:polished_deepslate
fill 377 156 330 377 158 331 minecraft:gray_concrete
setblock 377 156 344 minecraft:polished_deepslate
fill 377 156 345 377 159 345 minecraft:gray_concrete
setblock 377 156 349 minecraft:polished_deepslate
fill 377 156 350 377 156 353 minecraft:gray_concrete
setblock 377 156 354 minecraft:polished_deepslate
fill 377 156 355 377 159 355 minecraft:gray_concrete
setblock 377 156 359 minecraft:polished_deepslate
setblock 378 156 348 minecraft:polished_deepslate
fill 378 156 349 378 159 349 minecraft:gray_concrete
setblock 378 156 353 minecraft:polished_deepslate
fill 378 156 354 378 159 354 minecraft:gray_concrete
setblock 378 156 357 minecraft:gray_concrete
setblock 379 156 347 minecraft:polished_deepslate
fill 379 156 348 379 159 348 minecraft:gray_concrete
setblock 379 156 351 minecraft:gray_concrete
setblock 379 156 352 minecraft:polished_deepslate
fill 379 156 353 379 159 353 minecraft:gray_concrete
fill 379 156 355 379 157 355 minecraft:gray_concrete
setblock 380 156 351 minecraft:polished_deepslate
fill 380 156 352 380 158 352 minecraft:gray_concrete
fill 381 156 364 381 181 364 minecraft:gray_wool
setblock 383 156 323 minecraft:polished_deepslate
setblock 384 156 323 minecraft:gray_concrete
fill 387 156 364 387 184 364 minecraft:gray_wool
setblock 397 156 323 minecraft:gray_concrete
setblock 398 156 323 minecraft:polished_deepslate
fill 398 156 324 401 156 324 minecraft:gray_concrete
fill 399 156 323 402 156 323 minecraft:gray_concrete
setblock 400 156 325 minecraft:gray_concrete
fill 400 156 354 400 156 356 minecraft:black_concrete
setblock 401 156 325 minecraft:polished_deepslate
setblock 401 156 326 minecraft:gray_concrete
setblock 401 156 352 minecraft:black_concrete
setblock 401 156 357 minecraft:black_concrete
fill 401 156 363 402 156 363 minecraft:gray_concrete
setblock 402 156 324 minecraft:polished_deepslate
fill 402 156 325 402 158 325 minecraft:gray_concrete
setblock 402 156 351 minecraft:black_concrete
setblock 402 156 358 minecraft:black_concrete
setblock 403 156 323 minecraft:polished_deepslate
fill 403 156 324 403 159 324 minecraft:gray_concrete
setblock 403 156 363 minecraft:polished_deepslate
fill 404 156 323 404 159 323 minecraft:gray_concrete
setblock 404 156 359 minecraft:black_concrete
fill 404 156 363 404 159 363 minecraft:gray_concrete
setblock 405 156 326 minecraft:polished_deepslate
setblock 406 156 325 minecraft:polished_deepslate
setblock 406 156 351 minecraft:black_concrete
setblock 407 156 324 minecraft:polished_deepslate
setblock 407 156 325 minecraft:gray_concrete
setblock 407 156 352 minecraft:black_concrete
setblock 408 156 323 minecraft:polished_deepslate
fill 408 156 324 408 157 324 minecraft:gray_concrete
fill 408 156 353 408 156 356 minecraft:black_concrete
setblock 408 156 363 minecraft:polished_deepslate
fill 409 156 323 409 157 323 minecraft:gray_concrete
setblock 409 156 363 minecraft:gray_concrete
fill 410 156 361 412 159 363 minecraft:light_blue_stained_glass
fill 415 156 349 415 159 351 minecraft:light_blue_stained_glass
fill 416 156 349 416 159 350 minecraft:light_blue_stained_glass
fill 416 156 351 416 159 351 minecraft:gray_concrete
setblock 416 156 354 minecraft:gray_concrete
setblock 417 156 324 minecraft:polished_deepslate
setblock 417 156 325 minecraft:gray_concrete
setblock 417 156 329 minecraft:polished_deepslate
fill 417 156 330 417 159 330 minecraft:gray_concrete
fill 417 156 347 417 156 348 minecraft:gray_concrete
setblock 417 156 349 minecraft:polished_deepslate
fill 417 156 350 417 159 350 minecraft:gray_concrete
setblock 417 156 354 minecraft:polished_deepslate
fill 417 156 355 417 159 355 minecraft:gray_concrete
setblock 417 156 358 minecraft:gray_concrete
setblock 417 156 359 minecraft:polished_deepslate
fill 417 156 360 417 159 360 minecraft:gray_concrete
fill 377 157 329 377 160 329 minecraft:gray_concrete
setblock 377 157 332 minecraft:gray_concrete
setblock 377 157 333 minecraft:polished_deepslate
fill 377 157 344 377 160 344 minecraft:gray_concrete
setblock 377 157 348 minecraft:polished_deepslate
fill 377 157 349 377 157 352 minecraft:gray_concrete
setblock 377 157 353 minecraft:polished_deepslate
fill 377 157 354 377 160 354 minecraft:gray_concrete
setblock 377 157 358 minecraft:polished_deepslate
fill 377 157 359 377 160 359 minecraft:gray_concrete
setblock 378 157 347 minecraft:polished_deepslate
fill 378 157 348 378 160 348 minecraft:gray_concrete
setblock 378 157 352 minecraft:polished_deepslate
fill 378 157 353 378 160 353 minecraft:gray_concrete
setblock 378 157 357 minecraft:polished_deepslate
setblock 379 157 347 minecraft:gray_concrete
setblock 379 157 351 minecraft:polished_deepslate
fill 379 157 352 379 160 352 minecraft:gray_concrete
setblock 380 157 350 minecraft:polished_deepslate
fill 380 157 351 380 158 351 minecraft:gray_concrete
fill 385 157 348 385 158 348 minecraft:light_gray_wool
setblock 397 157 323 minecraft:polished_deepslate
fill 398 157 323 401 157 323 minecraft:gray_concrete
fill 399 157 324 400 157 324 minecraft:gray_concrete
setblock 400 157 325 minecraft:polished_deepslate
setblock 401 157 324 minecraft:polished_deepslate
fill 401 157 325 401 158 325 minecraft:gray_concrete
setblock 401 157 363 minecraft:gray_concrete
setblock 402 157 323 minecraft:polished_deepslate
fill 402 157 324 402 160 324 minecraft:gray_concrete
setblock 402 157 363 minecraft:polished_deepslate
fill 403 157 323 403 160 323 minecraft:gray_concrete
fill 403 157 355 403 161 355 minecraft:polished_deepslate
fill 403 157 363 403 160 363 minecraft:gray_concrete
setblock 405 157 325 minecraft:polished_deepslate
fill 405 157 353 405 159 353 minecraft:polished_deepslate
fill 405 157 356 405 159 356 minecraft:polished_deepslate
setblock 406 157 324 minecraft:polished_deepslate
setblock 406 157 325 minecraft:gray_concrete
setblock 407 157 323 minecraft:polished_deepslate
setblock 407 157 324 minecraft:gray_concrete
setblock 407 157 363 minecraft:polished_deepslate
fill 408 157 323 408 158 323 minecraft:gray_concrete
setblock 408 157 363 minecraft:gray_concrete
setblock 408 157 364 minecraft:light_blue_stained_glass
fill 409 157 362 409 158 362 minecraft:light_blue_stained_glass
fill 409 157 364 410 184 364 minecraft:gray_wool
fill 410 157 360 412 159 360 minecraft:light_blue_stained_glass
fill 411 157 359 411 159 359 minecraft:light_blue_stained_glass
fill 412 157 343 412 158 343 minecraft:gray_wool
fill 413 157 362 413 158 362 minecraft:light_blue_stained_glass
fill 414 157 349 414 159 351 minecraft:light_blue_stained_glass
fill 415 157 348 416 158 348 minecraft:light_blue_stained_glass
fill 415 157 352 415 158 352 minecraft:light_blue_stained_glass
setblock 416 157 354 minecraft:polished_deepslate
fill 416 157 355 416 160 355 minecraft:gray_concrete
setblock 417 157 328 minecraft:polished_deepslate
fill 417 157 329 417 160 329 minecraft:gray_concrete
setblock 417 157 347 minecraft:gray_concrete
setblock 417 157 348 minecraft:polished_deepslate
fill 417 157 349 417 160 349 minecraft:gray_concrete
setblock 417 157 353 minecraft:polished_deepslate
fill 417 157 354 417 160 354 minecraft:gray_concrete
setblock 417 157 358 minecraft:polished_deepslate
fill 417 157 359 417 160 359 minecraft:gray_concrete
fill 418 157 344 418 158 344 minecraft:light_blue_stained_glass
setblock 377 158 332 minecraft:polished_deepslate
fill 377 158 333 377 160 334 minecraft:gray_concrete
setblock 377 158 347 minecraft:polished_deepslate
fill 377 158 348 377 158 351 minecraft:gray_concrete
setblock 377 158 352 minecraft:polished_deepslate
fill 377 158 353 377 161 353 minecraft:gray_concrete
setblock 377 158 357 minecraft:polished_deepslate
fill 377 158 358 377 161 358 minecraft:gray_concrete
setblock 378 158 346 minecraft:polished_deepslate
fill 378 158 347 378 161 347 minecraft:gray_concrete
setblock 378 158 351 minecraft:polished_deepslate
fill 378 158 352 378 161 352 minecraft:gray_concrete
setblock 378 158 356 minecraft:polished_deepslate
fill 378 158 357 378 161 357 minecraft:gray_concrete
setblock 379 158 325 minecraft:light[level=13]
setblock 379 158 332 minecraft:light[level=12]
setblock 379 158 333 minecraft:light[level=13]
setblock 379 158 339 minecraft:light[level=12]
setblock 379 158 341 minecraft:light[level=13]
setblock 379 158 346 minecraft:light[level=12]
setblock 379 158 350 minecraft:polished_deepslate
fill 379 158 351 379 161 351 minecraft:gray_concrete
setblock 379 158 355 minecraft:polished_deepslate
setblock 379 158 357 minecraft:light[level=13]
setblock 379 158 360 minecraft:light[level=12]
setblock 386 158 325 minecraft:light[level=12]
setblock 386 158 332 minecraft:light[level=12]
setblock 386 158 339 minecraft:light[level=12]
setblock 386 158 346 minecraft:light[level=12]
setblock 386 158 353 minecraft:light[level=12]
setblock 386 158 360 minecraft:light[level=12]
setblock 387 158 325 minecraft:light[level=13]
setblock 387 158 333 minecraft:light[level=13]
setblock 387 158 341 minecraft:light[level=13]
setblock 387 158 349 minecraft:light[level=13]
setblock 387 158 357 minecraft:light[level=13]
setblock 393 158 325 minecraft:light[level=12]
setblock 393 158 332 minecraft:light[level=12]
setblock 393 158 339 minecraft:light[level=12]
setblock 393 158 346 minecraft:light[level=12]
setblock 393 158 353 minecraft:light[level=12]
setblock 393 158 360 minecraft:light[level=12]
setblock 395 158 325 minecraft:light[level=13]
setblock 395 158 333 minecraft:light[level=13]
setblock 395 158 341 minecraft:light[level=13]
setblock 395 158 349 minecraft:light[level=13]
setblock 395 158 357 minecraft:light[level=13]
fill 397 158 323 400 158 323 minecraft:gray_concrete
setblock 399 158 324 minecraft:gray_concrete
setblock 400 158 324 minecraft:polished_deepslate
setblock 400 158 325 minecraft:light[level=12]
setblock 400 158 332 minecraft:light[level=12]
setblock 400 158 339 minecraft:light[level=12]
setblock 400 158 346 minecraft:light[level=12]
setblock 400 158 353 minecraft:light[level=12]
setblock 400 158 360 minecraft:light[level=12]
setblock 401 158 323 minecraft:polished_deepslate
fill 401 158 324 401 161 324 minecraft:gray_concrete
setblock 401 158 363 minecraft:polished_deepslate
fill 402 158 323 402 161 323 minecraft:gray_concrete
fill 402 158 363 402 161 363 minecraft:gray_concrete
setblock 403 158 333 minecraft:light[level=13]
setblock 403 158 341 minecraft:light[level=13]
setblock 403 158 349 minecraft:light[level=13]
setblock 403 158 357 minecraft:light[level=13]
setblock 404 158 325 minecraft:polished_deepslate
setblock 405 158 324 minecraft:polished_deepslate
setblock 406 158 323 minecraft:polished_deepslate
setblock 406 158 324 minecraft:gray_concrete
setblock 406 158 363 minecraft:polished_deepslate
fill 407 158 323 407 159 323 minecraft:gray_concrete
setblock 407 158 325 minecraft:light[level=12]
setblock 407 158 332 minecraft:light[level=12]
setblock 407 158 339 minecraft:light[level=12]
setblock 407 158 346 minecraft:light[level=12]
setblock 407 158 353 minecraft:light[level=12]
setblock 407 158 360 minecraft:light[level=12]
fill 408 158 364 408 162 364 minecraft:gray_wool
fill 410 158 358 410 159 359 minecraft:light_blue_stained_glass
setblock 411 158 325 minecraft:light[level=13]
setblock 411 158 333 minecraft:light[level=13]
setblock 411 158 341 minecraft:light[level=13]
setblock 411 158 349 minecraft:light[level=13]
setblock 411 158 357 minecraft:light[level=13]
fill 411 158 358 412 159 358 minecraft:light_blue_stained_glass
fill 412 158 359 412 159 359 minecraft:light_blue_stained_glass
fill 413 158 350 413 160 350 minecraft:light_blue_stained_glass
setblock 414 158 325 minecraft:light[level=12]
setblock 414 158 332 minecraft:light[level=12]
setblock 414 158 339 minecraft:light[level=12]
setblock 414 158 346 minecraft:light[level=12]
setblock 414 158 353 minecraft:light[level=12]
setblock 414 158 360 minecraft:light[level=12]
setblock 416 158 352 minecraft:gray_concrete
setblock 416 158 353 minecraft:polished_deepslate
fill 416 158 354 416 161 354 minecraft:gray_concrete
fill 416 158 356 416 159 356 minecraft:gray_concrete
setblock 417 158 328 minecraft:gray_concrete
setblock 417 158 347 minecraft:polished_deepslate
fill 417 158 348 417 161 348 minecraft:gray_concrete
setblock 417 158 352 minecraft:polished_deepslate
fill 417 158 353 417 161 353 minecraft:gray_concrete
setblock 417 158 357 minecraft:polished_deepslate
fill 417 158 358 417 161 358 minecraft:gray_concrete
setblock 418 158 329 minecraft:light_blue_stained_glass
fill 418 158 330 418 166 330 minecraft:gray_wool
setblock 377 159 330 minecraft:gray_concrete
setblock 377 159 331 minecraft:polished_deepslate
fill 377 159 332 378 161 332 minecraft:gray_concrete
setblock 377 159 335 minecraft:gray_concrete
setblock 377 159 336 minecraft:polished_deepslate
fill 377 159 337 377 162 337 minecraft:gray_concrete
setblock 377 159 346 minecraft:polished_deepslate
fill 377 159 347 377 159 350 minecraft:gray_concrete
setblock 377 159 351 minecraft:polished_deepslate
fill 377 159 352 377 162 352 minecraft:gray_concrete
setblock 377 159 356 minecraft:polished_deepslate
fill 377 159 357 377 162 357 minecraft:gray_concrete
setblock 377 159 360 minecraft:gray_concrete
fill 378 159 333 378 160 333 minecraft:gray_concrete
fill 378 159 346 378 162 346 minecraft:gray_concrete
setblock 378 159 350 minecraft:polished_deepslate
fill 378 159 351 378 162 351 minecraft:gray_concrete
setblock 378 159 355 minecraft:polished_deepslate
fill 378 159 356 379 161 356 minecraft:gray_concrete
fill 378 159 358 378 160 358 minecraft:gray_concrete
setblock 379 159 349 minecraft:polished_deepslate
fill 379 159 350 379 162 350 minecraft:gray_concrete
setblock 379 159 354 minecraft:polished_deepslate
fill 379 159 355 379 162 355 minecraft:gray_concrete
fill 397 159 323 399 159 323 minecraft:gray_concrete
setblock 399 159 324 minecraft:polished_deepslate
setblock 400 159 323 minecraft:polished_deepslate
fill 400 159 324 400 162 324 minecraft:gray_concrete
fill 401 159 323 401 162 323 minecraft:gray_concrete
fill 401 159 363 401 162 363 minecraft:gray_concrete
setblock 404 159 324 minecraft:polished_deepslate
setblock 405 159 323 minecraft:polished_deepslate
setblock 405 159 324 minecraft:gray_concrete
setblock 405 159 363 minecraft:polished_deepslate
fill 406 159 323 406 161 323 minecraft:gray_concrete
fill 406 159 363 406 162 363 minecraft:gray_concrete
fill 411 159 356 411 159 357 minecraft:light_blue_stained_glass
fill 412 159 341 414 160 341 minecraft:white_wool
fill 412 159 350 412 160 350 minecraft:light_blue_stained_glass
fill 413 159 340 413 160 340 minecraft:white_wool
fill 413 159 342 413 160 342 minecraft:white_wool
setblock 413 159 349 minecraft:light_blue_stained_glass
setblock 413 159 351 minecraft:light_blue_stained_glass
setblock 416 159 352 minecraft:polished_deepslate
fill 416 159 353 416 162 353 minecraft:gray_concrete
setblock 416 159 357 minecraft:polished_deepslate
setblock 417 159 331 minecraft:polished_deepslate
fill 417 159 332 417 162 332 minecraft:gray_concrete
setblock 417 159 351 minecraft:polished_deepslate
fill 417 159 352 417 162 352 minecraft:gray_concrete
setblock 417 159 356 minecraft:polished_deepslate
fill 417 159 357 417 162 357 minecraft:gray_concrete
setblock 417 159 361 minecraft:polished_deepslate
fill 417 159 362 417 162 362 minecraft:gray_concrete
fill 418 159 329 418 184 329 minecraft:gray_wool
fill 418 159 344 418 184 344 minecraft:gray_wool
setblock 377 160 330 minecraft:polished_deepslate
fill 377 160 331 378 162 331 minecraft:gray_concrete
setblock 377 160 335 minecraft:polished_deepslate
fill 377 160 336 378 162 336 minecraft:gray_concrete
fill 377 160 338 377 160 339 minecraft:gray_concrete
setblock 377 160 340 minecraft:polished_deepslate
fill 377 160 341 377 161 343 minecraft:gray_concrete
setblock 377 160 345 minecraft:polished_deepslate
fill 377 160 346 377 160 349 minecraft:gray_concrete
setblock 377 160 350 minecraft:polished_deepslate
fill 377 160 351 377 163 351 minecraft:gray_concrete
setblock 377 160 355 minecraft:polished_deepslate
fill 377 160 356 377 163 356 minecraft:gray_concrete
setblock 377 160 360 minecraft:polished_deepslate
setblock 378 160 334 minecraft:polished_deepslate
fill 378 160 335 378 163 335 minecraft:gray_concrete
fill 378 160 337 378 161 337 minecraft:gray_concrete
setblock 378 160 349 minecraft:polished_deepslate
fill 378 160 350 378 163 350 minecraft:gray_concrete
setblock 378 160 354 minecraft:polished_deepslate
fill 378 160 355 378 163 355 minecraft:gray_concrete
fill 379 160 349 379 163 349 minecraft:gray_concrete
setblock 379 160 353 minecraft:polished_deepslate
fill 379 160 354 379 163 354 minecraft:gray_concrete
fill 397 160 323 398 160 323 minecraft:gray_concrete
setblock 399 160 323 minecraft:polished_deepslate
fill 399 160 324 399 163 324 minecraft:gray_concrete
fill 400 160 323 400 163 323 minecraft:gray_concrete
fill 400 160 363 400 163 363 minecraft:gray_concrete
setblock 403 160 324 minecraft:polished_deepslate
setblock 404 160 323 minecraft:polished_deepslate
setblock 404 160 324 minecraft:gray_concrete
setblock 404 160 363 minecraft:polished_deepslate
fill 405 160 323 405 163 323 minecraft:gray_concrete
fill 405 160 363 405 163 363 minecraft:gray_concrete
setblock 406 160 322 minecraft:light_blue_stained_glass
setblock 411 160 356 minecraft:light_blue_stained_glass
fill 414 160 350 415 160 350 minecraft:light_blue_stained_glass
setblock 416 160 351 minecraft:polished_deepslate
fill 416 160 352 416 163 352 minecraft:gray_concrete
setblock 416 160 356 minecraft:polished_deepslate
fill 416 160 357 416 161 359 minecraft:gray_concrete
setblock 417 160 330 minecraft:polished_deepslate
fill 417 160 331 417 163 331 minecraft:gray_concrete
fill 417 160 333 417 160 334 minecraft:gray_concrete
fill 417 160 347 417 162 347 minecraft:gray_concrete
setblock 417 160 350 minecraft:polished_deepslate
fill 417 160 351 417 163 351 minecraft:gray_concrete
setblock 417 160 355 minecraft:polished_deepslate
fill 417 160 356 417 163 356 minecraft:gray_concrete
setblock 417 160 360 minecraft:polished_deepslate
fill 417 160 361 417 163 361 minecraft:gray_concrete
fill 417 160 363 417 161 363 minecraft:gray_concrete
setblock 377 161 329 minecraft:polished_deepslate
fill 377 161 330 378 163 330 minecraft:gray_concrete
setblock 377 161 333 minecraft:gray_concrete
setblock 377 161 334 minecraft:polished_deepslate
fill 377 161 335 377 164 335 minecraft:gray_concrete
setblock 377 161 338 minecraft:gray_concrete
setblock 377 161 339 minecraft:polished_deepslate
fill 377 161 340 378 163 340 minecraft:gray_concrete
setblock 377 161 344 minecraft:polished_deepslate
fill 377 161 345 377 161 348 minecraft:gray_concrete
setblock 377 161 349 minecraft:polished_deepslate
fill 377 161 350 377 164 350 minecraft:gray_concrete
setblock 377 161 354 minecraft:polished_deepslate
fill 377 161 355 377 164 355 minecraft:gray_concrete
setblock 377 161 359 minecraft:polished_deepslate
fill 377 161 360 377 163 361 minecraft:gray_concrete
setblock 378 161 333 minecraft:polished_deepslate
fill 378 161 334 379 163 334 minecraft:gray_concrete
setblock 378 161 338 minecraft:polished_deepslate
fill 378 161 339 378 164 339 minecraft:gray_concrete
fill 378 161 345 378 163 345 minecraft:gray_concrete
setblock 378 161 348 minecraft:polished_deepslate
fill 378 161 349 378 164 349 minecraft:gray_concrete
setblock 378 161 353 minecraft:polished_deepslate
fill 378 161 354 378 164 354 minecraft:gray_concrete
setblock 378 161 358 minecraft:polished_deepslate
fill 378 161 359 378 164 359 minecraft:gray_concrete
fill 379 161 333 379 164 333 minecraft:gray_concrete
fill 379 161 335 379 161 336 minecraft:gray_concrete
setblock 379 161 352 minecraft:polished_deepslate
fill 379 161 353 379 164 353 minecraft:gray_concrete
setblock 379 161 357 minecraft:polished_deepslate
setblock 397 161 323 minecraft:gray_concrete
setblock 398 161 323 minecraft:polished_deepslate
fill 398 161 324 398 164 324 minecraft:gray_concrete
fill 399 161 323 399 164 323 minecraft:gray_concrete
fill 399 161 363 399 164 363 minecraft:gray_concrete
setblock 402 161 324 minecraft:polished_deepslate
setblock 403 161 323 minecraft:polished_deepslate
fill 403 161 324 403 164 324 minecraft:gray_concrete
setblock 403 161 363 minecraft:polished_deepslate
fill 404 161 323 404 164 323 minecraft:gray_concrete
fill 404 161 363 404 164 363 minecraft:gray_concrete
fill 406 161 322 406 184 322 minecraft:gray_wool
setblock 416 161 350 minecraft:polished_deepslate
fill 416 161 351 416 164 351 minecraft:gray_concrete
setblock 416 161 355 minecraft:polished_deepslate
fill 416 161 356 416 164 356 minecraft:gray_concrete
setblock 416 161 360 minecraft:polished_deepslate
fill 416 161 363 416 162 363 minecraft:gray_concrete
setblock 417 161 329 minecraft:polished_deepslate
fill 417 161 330 417 164 330 minecraft:gray_concrete
setblock 417 161 333 minecraft:gray_concrete
setblock 417 161 334 minecraft:polished_deepslate
fill 417 161 335 417 162 337 minecraft:gray_concrete
setblock 417 161 349 minecraft:polished_deepslate
fill 417 161 350 417 164 350 minecraft:gray_concrete
setblock 417 161 354 minecraft:polished_deepslate
fill 417 161 355 417 164 355 minecraft:gray_concrete
setblock 417 161 359 minecraft:polished_deepslate
fill 417 161 360 417 164 360 minecraft:gray_concrete
setblock 377 162 328 minecraft:polished_deepslate
fill 377 162 329 377 165 329 minecraft:gray_concrete
setblock 377 162 332 minecraft:gray_concrete
setblock 377 162 333 minecraft:polished_deepslate
fill 377 162 334 377 165 334 minecraft:gray_concrete
setblock 377 162 338 minecraft:polished_deepslate
fill 377 162 339 377 165 339 minecraft:gray_concrete
fill 377 162 341 377 162 342 minecraft:gray_concrete
setblock 377 162 343 minecraft:polished_deepslate
fill 377 162 344 377 162 347 minecraft:gray_concrete
setblock 377 162 348 minecraft:polished_deepslate
fill 377 162 349 377 165 349 minecraft:gray_concrete
setblock 377 162 353 minecraft:polished_deepslate
fill 377 162 354 377 165 354 minecraft:gray_concrete
setblock 377 162 358 minecraft:polished_deepslate
fill 377 162 359 377 165 359 minecraft:gray_concrete
setblock 377 162 362 minecraft:gray_concrete
setblock 378 162 332 minecraft:polished_deepslate
fill 378 162 333 378 165 333 minecraft:gray_concrete
setblock 378 162 337 minecraft:polished_deepslate
fill 378 162 338 379 164 338 minecraft:gray_concrete
setblock 378 162 341 minecraft:gray_concrete
setblock 378 162 342 minecraft:polished_deepslate
fill 378 162 343 378 164 344 minecraft:gray_concrete
setblock 378 162 347 minecraft:polished_deepslate
fill 378 162 348 378 165 348 minecraft:gray_concrete
setblock 378 162 352 minecraft:polished_deepslate
fill 378 162 353 378 165 353 minecraft:gray_concrete
setblock 378 162 356 minecraft:gray_concrete
setblock 378 162 357 minecraft:polished_deepslate
fill 378 162 358 379 164 358 minecraft:gray_concrete
fill 378 162 360 378 163 360 minecraft:gray_concrete
fill 378 162 363 379 164 363 minecraft:gray_concrete
fill 379 162 332 379 165 332 minecraft:gray_concrete
setblock 379 162 335 minecraft:gray_concrete
setblock 379 162 336 minecraft:polished_deepslate
fill 379 162 337 379 165 337 minecraft:gray_concrete
fill 379 162 339 379 163 339 minecraft:gray_concrete
setblock 379 162 351 minecraft:polished_deepslate
fill 379 162 352 379 165 352 minecraft:gray_concrete
setblock 379 162 356 minecraft:polished_deepslate
fill 379 162 357 379 165 357 minecraft:gray_concrete
setblock 386 162 364 minecraft:light_blue_stained_glass
fill 387 162 351 388 163 351 minecraft:light_gray_wool
setblock 396 162 323 minecraft:gray_concrete
setblock 397 162 323 minecraft:polished_deepslate
setblock 397 162 363 minecraft:polished_deepslate
fill 398 162 323 398 165 323 minecraft:gray_concrete
fill 398 162 363 398 165 363 minecraft:gray_concrete
fill 400 162 362 402 162 362 minecraft:gray_concrete
setblock 401 162 324 minecraft:polished_deepslate
setblock 402 162 323 minecraft:polished_deepslate
fill 402 162 324 402 165 324 minecraft:gray_concrete
setblock 402 162 363 minecraft:polished_deepslate
fill 403 162 323 403 165 323 minecraft:gray_concrete
setblock 403 162 362 minecraft:polished_deepslate
fill 403 162 363 403 165 363 minecraft:gray_concrete
fill 404 162 339 405 163 339 minecraft:white_wool
setblock 407 162 363 minecraft:polished_deepslate
fill 414 162 363 415 163 363 minecraft:gray_concrete
fill 415 162 353 415 162 354 minecraft:gray_concrete
setblock 415 162 355 minecraft:polished_deepslate
fill 415 162 356 415 163 358 minecraft:gray_concrete
fill 416 162 350 416 165 350 minecraft:gray_concrete
setblock 416 162 354 minecraft:polished_deepslate
fill 416 162 355 416 165 355 minecraft:gray_concrete
fill 416 162 357 416 162 358 minecraft:gray_concrete
setblock 416 162 359 minecraft:polished_deepslate
fill 416 162 360 416 163 362 minecraft:gray_concrete
fill 417 162 329 417 165 329 minecraft:gray_concrete
setblock 417 162 333 minecraft:polished_deepslate
fill 417 162 334 417 165 334 minecraft:gray_concrete
setblock 417 162 338 minecraft:polished_deepslate
fill 417 162 339 417 164 340 minecraft:gray_concrete
fill 417 162 346 417 163 346 minecraft:gray_concrete
setblock 417 162 348 minecraft:polished_deepslate
fill 417 162 349 417 165 349 minecraft:gray_concrete
setblock 417 162 353 minecraft:polished_deepslate
fill 417 162 354 417 165 354 minecraft:gray_concrete
setblock 417 162 358 minecraft:polished_deepslate
fill 417 162 359 417 165 359 minecraft:gray_concrete
setblock 417 162 363 minecraft:polished_deepslate
fill 377 163 328 377 166 328 minecraft:gray_concrete
setblock 377 163 331 minecraft:gray_concrete
setblock 377 163 332 minecraft:polished_deepslate
fill 377 163 333 377 166 333 minecraft:gray_concrete
setblock 377 163 336 minecraft:gray_concrete
setblock 377 163 337 minecraft:polished_deepslate
fill 377 163 338 377 166 338 minecraft:gray_concrete
setblock 377 163 341 minecraft:gray_concrete
setblock 377 163 342 minecraft:polished_deepslate
fill 377 163 343 377 163 346 minecraft:gray_concrete
setblock 377 163 347 minecraft:polished_deepslate
fill 377 163 348 377 166 348 minecraft:gray_concrete
setblock 377 163 352 minecraft:polished_deepslate
fill 377 163 353 377 166 353 minecraft:gray_concrete
setblock 377 163 357 minecraft:polished_deepslate
fill 377 163 358 377 166 358 minecraft:gray_concrete
setblock 377 163 362 minecraft:polished_deepslate
fill 377 163 363 377 166 363 minecraft:gray_concrete
fill 378 163 329 378 164 329 minecraft:gray_concrete
setblock 378 163 331 minecraft:polished_deepslate
fill 378 163 332 378 166 332 minecraft:gray_concrete
setblock 378 163 336 minecraft:polished_deepslate
fill 378 163 337 378 166 337 minecraft:gray_concrete
setblock 378 163 341 minecraft:polished_deepslate
fill 378 163 342 379 165 342 minecraft:gray_concrete
setblock 378 163 346 minecraft:polished_deepslate
fill 378 163 347 378 166 347 minecraft:gray_concrete
setblock 378 163 351 minecraft:polished_deepslate
fill 378 163 352 378 166 352 minecraft:gray_concrete
setblock 378 163 356 minecraft:polished_deepslate
fill 378 163 357 378 166 357 minecraft:gray_concrete
setblock 378 163 361 minecraft:polished_deepslate
fill 379 163 331 379 166 331 minecraft:gray_concrete
setblock 379 163 335 minecraft:polished_deepslate
fill 379 163 336 380 165 336 minecraft:gray_concrete
setblock 379 163 340 minecraft:polished_deepslate
fill 379 163 341 379 166 341 minecraft:gray_concrete
fill 379 163 348 379 164 348 minecraft:gray_concrete
setblock 379 163 350 minecraft:polished_deepslate
fill 379 163 351 379 166 351 minecraft:gray_concrete
setblock 379 163 355 minecraft:polished_deepslate
fill 379 163 356 379 166 356 minecraft:gray_concrete
setblock 379 163 359 minecraft:gray_concrete
setblock 380 163 334 minecraft:polished_deepslate
fill 380 163 335 380 166 335 minecraft:gray_concrete
fill 380 163 337 380 164 337 minecraft:gray_concrete
setblock 380 163 363 minecraft:gray_concrete
setblock 381 163 363 minecraft:polished_deepslate
setblock 382 163 364 minecraft:light_blue_stained_glass
fill 386 163 354 387 164 355 minecraft:light_gray_wool
fill 386 163 364 386 184 364 minecraft:gray_wool
fill 392 163 364 392 184 364 minecraft:gray_wool
setblock 393 163 364 minecraft:light_blue_stained_glass
fill 394 163 323 395 163 323 minecraft:gray_concrete
setblock 396 163 323 minecraft:polished_deepslate
setblock 396 163 363 minecraft:polished_deepslate
fill 397 163 323 397 165 324 minecraft:gray_concrete
fill 397 163 363 397 166 363 minecraft:gray_concrete
fill 398 163 362 401 163 362 minecraft:gray_concrete
setblock 400 163 324 minecraft:polished_deepslate
setblock 401 163 323 minecraft:polished_deepslate
fill 401 163 324 401 166 324 minecraft:gray_concrete
setblock 401 163 363 minecraft:polished_deepslate
fill 402 163 323 402 166 323 minecraft:gray_concrete
setblock 402 163 362 minecraft:polished_deepslate
fill 402 163 363 402 166 363 minecraft:gray_concrete
fill 403 163 362 405 164 362 minecraft:gray_concrete
setblock 406 163 363 minecraft:polished_deepslate
fill 407 163 363 410 163 363 minecraft:gray_concrete
setblock 408 163 364 minecraft:light_blue_stained_glass
setblock 411 163 363 minecraft:polished_deepslate
fill 412 163 363 413 165 363 minecraft:gray_concrete
fill 414 163 362 415 164 362 minecraft:gray_concrete
setblock 415 163 353 minecraft:gray_concrete
setblock 415 163 354 minecraft:polished_deepslate
fill 415 163 355 415 166 355 minecraft:gray_concrete
setblock 415 163 359 minecraft:polished_deepslate
fill 415 163 360 415 166 360 minecraft:gray_concrete
setblock 415 163 364 minecraft:light_blue_stained_glass
fill 416 163 334 416 165 335 minecraft:gray_concrete
fill 416 163 349 416 166 349 minecraft:gray_concrete
setblock 416 163 353 minecraft:polished_deepslate
fill 416 163 354 416 166 354 minecraft:gray_concrete
setblock 416 163 357 minecraft:gray_concrete
setblock 416 163 358 minecraft:polished_deepslate
fill 416 163 359 416 166 359 minecraft:gray_concrete
setblock 416 163 363 minecraft:polished_deepslate
fill 417 163 328 417 166 328 minecraft:gray_concrete
setblock 417 163 332 minecraft:polished_deepslate
fill 417 163 333 417 166 333 minecraft:gray_concrete
fill 417 163 335 417 163 336 minecraft:gray_concrete
setblock 417 163 337 minecraft:polished_deepslate
fill 417 163 338 417 166 338 minecraft:gray_concrete
schedule function dropper:buildpart/80_4 1t
