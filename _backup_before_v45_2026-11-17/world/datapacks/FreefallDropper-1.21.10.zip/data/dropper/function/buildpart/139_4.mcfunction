fill 331 159 571 331 162 571 minecraft:green_terracotta
setblock 331 159 575 minecraft:oak_log
fill 331 159 576 331 162 576 minecraft:green_terracotta
setblock 331 159 580 minecraft:oak_log
fill 331 159 581 331 162 581 minecraft:green_terracotta
setblock 331 159 594 minecraft:green_terracotta
setblock 331 159 595 minecraft:oak_log
fill 331 159 596 331 162 596 minecraft:green_terracotta
setblock 332 159 558 minecraft:green_terracotta
setblock 332 159 559 minecraft:oak_log
setblock 332 159 569 minecraft:oak_log
fill 332 159 570 332 162 570 minecraft:green_terracotta
setblock 332 159 573 minecraft:green_terracotta
setblock 332 159 574 minecraft:oak_log
fill 332 159 575 332 162 575 minecraft:green_terracotta
setblock 332 159 579 minecraft:oak_log
setblock 333 159 558 minecraft:oak_log
fill 333 159 559 333 162 559 minecraft:green_terracotta
setblock 333 159 569 minecraft:green_terracotta
setblock 333 159 573 minecraft:oak_log
fill 333 159 574 333 162 574 minecraft:green_terracotta
setblock 333 159 597 minecraft:green_terracotta
setblock 333 159 598 minecraft:oak_log
fill 334 159 558 334 162 558 minecraft:green_terracotta
fill 334 159 560 335 159 560 minecraft:green_terracotta
setblock 334 159 573 minecraft:green_terracotta
setblock 334 159 596 minecraft:green_terracotta
setblock 334 159 597 minecraft:oak_log
fill 334 159 598 337 159 598 minecraft:green_terracotta
setblock 335 159 596 minecraft:oak_log
fill 335 159 597 335 162 597 minecraft:green_terracotta
setblock 336 159 560 minecraft:oak_log
fill 336 159 596 336 161 596 minecraft:green_terracotta
setblock 337 159 559 minecraft:oak_log
fill 337 159 560 337 162 560 minecraft:green_terracotta
setblock 338 159 558 minecraft:oak_log
fill 338 159 559 338 162 559 minecraft:green_terracotta
setblock 338 159 598 minecraft:oak_log
fill 339 159 558 339 162 558 minecraft:green_terracotta
setblock 339 159 597 minecraft:oak_log
fill 339 159 598 339 162 598 minecraft:green_terracotta
setblock 340 159 596 minecraft:oak_log
fill 340 159 597 340 162 597 minecraft:green_terracotta
setblock 341 159 559 minecraft:green_terracotta
setblock 342 159 559 minecraft:oak_log
setblock 343 159 558 minecraft:oak_log
fill 343 159 559 343 161 559 minecraft:green_terracotta
setblock 343 159 597 minecraft:green_terracotta
setblock 343 159 598 minecraft:oak_log
fill 344 159 558 347 159 558 minecraft:green_terracotta
setblock 344 159 597 minecraft:oak_log
fill 344 159 598 347 159 598 minecraft:green_terracotta
fill 345 159 597 348 159 597 minecraft:green_terracotta
setblock 348 159 558 minecraft:oak_log
fill 348 159 596 349 159 596 minecraft:green_terracotta
setblock 348 159 598 minecraft:oak_log
fill 349 159 558 351 159 559 minecraft:green_terracotta
setblock 349 159 597 minecraft:oak_log
fill 349 159 598 352 159 598 minecraft:green_terracotta
setblock 350 159 596 minecraft:oak_log
fill 350 159 597 353 159 597 minecraft:green_terracotta
setblock 351 159 595 minecraft:oak_log
fill 351 159 596 351 162 596 minecraft:green_terracotta
setblock 352 159 558 minecraft:green_terracotta
setblock 352 159 559 minecraft:oak_log
fill 352 159 595 352 162 595 minecraft:green_terracotta
setblock 353 159 558 minecraft:oak_log
fill 353 159 559 353 162 559 minecraft:green_terracotta
setblock 353 159 598 minecraft:oak_log
fill 354 159 558 354 162 558 minecraft:green_terracotta
fill 354 159 594 356 159 594 minecraft:green_terracotta
setblock 354 159 597 minecraft:oak_log
fill 354 159 598 354 162 598 minecraft:green_terracotta
setblock 355 159 596 minecraft:oak_log
fill 355 159 597 355 162 597 minecraft:green_terracotta
setblock 356 159 559 minecraft:green_terracotta
setblock 356 159 595 minecraft:oak_log
fill 356 159 596 356 162 596 minecraft:green_terracotta
setblock 357 159 559 minecraft:oak_log
setblock 357 159 594 minecraft:oak_log
fill 357 159 595 357 161 595 minecraft:green_terracotta
setblock 358 159 558 minecraft:oak_log
fill 358 159 559 358 160 559 minecraft:green_terracotta
setblock 358 159 598 minecraft:oak_log
fill 359 159 558 359 162 558 minecraft:green_terracotta
setblock 359 159 597 minecraft:oak_log
fill 359 159 598 359 162 598 minecraft:green_terracotta
setblock 360 159 596 minecraft:oak_log
fill 360 159 597 360 162 597 minecraft:green_terracotta
fill 361 159 558 361 160 558 minecraft:green_terracotta
fill 361 159 596 361 160 596 minecraft:green_terracotta
setblock 363 159 598 minecraft:oak_log
setblock 364 159 597 minecraft:oak_log
fill 364 159 598 367 159 598 minecraft:green_terracotta
setblock 365 159 597 minecraft:green_terracotta
setblock 368 159 598 minecraft:oak_log
setblock 369 159 571 minecraft:green_terracotta
setblock 369 159 572 minecraft:oak_log
fill 369 159 573 369 162 573 minecraft:green_terracotta
setblock 369 159 576 minecraft:green_terracotta
setblock 369 159 577 minecraft:oak_log
fill 369 159 578 369 162 578 minecraft:green_terracotta
setblock 369 159 581 minecraft:green_terracotta
setblock 369 159 592 minecraft:oak_log
fill 369 159 593 369 160 593 minecraft:green_terracotta
setblock 369 159 597 minecraft:oak_log
fill 369 159 598 369 162 598 minecraft:green_terracotta
setblock 370 159 560 minecraft:oak_leaves[persistent=true]
setblock 370 159 567 minecraft:green_terracotta
setblock 370 159 571 minecraft:oak_log
fill 370 159 572 370 162 572 minecraft:green_terracotta
setblock 370 159 576 minecraft:oak_log
fill 370 159 577 370 162 577 minecraft:green_terracotta
setblock 370 159 581 minecraft:oak_log
fill 370 159 582 370 162 582 minecraft:green_terracotta
setblock 370 159 586 minecraft:oak_log
fill 370 159 587 370 162 587 minecraft:green_terracotta
setblock 370 159 591 minecraft:oak_log
fill 370 159 592 370 162 592 minecraft:green_terracotta
setblock 370 159 596 minecraft:oak_log
fill 370 159 597 370 162 597 minecraft:green_terracotta
setblock 330 160 560 minecraft:oak_log
fill 330 160 561 331 162 561 minecraft:green_terracotta
setblock 330 160 565 minecraft:oak_log
fill 330 160 566 330 163 566 minecraft:green_terracotta
setblock 330 160 570 minecraft:oak_log
fill 330 160 571 330 163 571 minecraft:green_terracotta
setblock 330 160 575 minecraft:oak_log
fill 330 160 576 330 163 576 minecraft:green_terracotta
setblock 330 160 579 minecraft:green_terracotta
setblock 330 160 580 minecraft:oak_log
fill 330 160 581 330 163 581 minecraft:green_terracotta
setblock 330 160 584 minecraft:green_terracotta
setblock 330 160 591 minecraft:green_terracotta
setblock 330 160 595 minecraft:oak_log
fill 330 160 596 330 161 598 minecraft:green_terracotta
setblock 331 160 558 minecraft:green_terracotta
setblock 331 160 559 minecraft:oak_log
fill 331 160 560 331 163 560 minecraft:green_terracotta
fill 331 160 562 331 161 562 minecraft:green_terracotta
setblock 331 160 564 minecraft:oak_log
fill 331 160 565 331 163 565 minecraft:green_terracotta
setblock 331 160 569 minecraft:oak_log
fill 331 160 570 331 163 570 minecraft:green_terracotta
setblock 331 160 574 minecraft:oak_log
fill 331 160 575 331 163 575 minecraft:green_terracotta
setblock 331 160 578 minecraft:green_terracotta
setblock 331 160 579 minecraft:oak_log
fill 331 160 580 332 162 580 minecraft:green_terracotta
setblock 331 160 594 minecraft:oak_log
fill 331 160 595 331 161 595 minecraft:green_terracotta
fill 331 160 597 331 160 598 minecraft:green_terracotta
setblock 332 160 558 minecraft:oak_log
fill 332 160 559 332 163 559 minecraft:green_terracotta
setblock 332 160 560 minecraft:light[level=14]
setblock 332 160 568 minecraft:oak_log
fill 332 160 569 332 161 569 minecraft:green_terracotta
setblock 332 160 573 minecraft:oak_log
fill 332 160 574 332 163 574 minecraft:green_terracotta
setblock 332 160 578 minecraft:oak_log
fill 332 160 579 332 163 579 minecraft:green_terracotta
setblock 332 160 584 minecraft:light[level=14]
setblock 332 160 592 minecraft:light[level=14]
setblock 332 160 597 minecraft:green_terracotta
setblock 332 160 598 minecraft:oak_log
fill 333 160 558 333 163 558 minecraft:green_terracotta
fill 333 160 560 334 160 560 minecraft:green_terracotta
setblock 333 160 572 minecraft:oak_log
fill 333 160 573 333 161 573 minecraft:green_terracotta
setblock 333 160 577 minecraft:oak_log
setblock 333 160 597 minecraft:oak_log
fill 333 160 598 336 160 598 minecraft:green_terracotta
setblock 334 160 596 minecraft:oak_log
fill 334 160 597 334 163 597 minecraft:green_terracotta
setblock 335 160 560 minecraft:oak_log
fill 335 160 596 335 161 596 minecraft:green_terracotta
setblock 336 160 559 minecraft:oak_log
fill 336 160 560 336 163 560 minecraft:green_terracotta
setblock 337 160 558 minecraft:oak_log
fill 337 160 559 337 163 559 minecraft:green_terracotta
setblock 337 160 598 minecraft:oak_log
fill 338 160 558 338 163 558 minecraft:green_terracotta
fill 338 160 560 338 161 560 minecraft:green_terracotta
setblock 338 160 597 minecraft:oak_log
fill 338 160 598 338 163 598 minecraft:green_terracotta
fill 339 160 597 339 163 597 minecraft:green_terracotta
setblock 340 160 560 minecraft:light[level=14]
setblock 340 160 568 minecraft:light[level=14]
setblock 340 160 576 minecraft:light[level=14]
setblock 340 160 584 minecraft:light[level=14]
setblock 340 160 592 minecraft:light[level=14]
setblock 341 160 559 minecraft:oak_log
setblock 342 160 558 minecraft:oak_log
fill 342 160 559 342 162 559 minecraft:green_terracotta
setblock 342 160 598 minecraft:oak_log
fill 343 160 558 346 160 558 minecraft:green_terracotta
setblock 343 160 597 minecraft:oak_log
fill 343 160 598 346 160 598 minecraft:green_terracotta
fill 344 160 597 347 160 597 minecraft:green_terracotta
setblock 347 160 558 minecraft:oak_log
setblock 347 160 598 minecraft:oak_log
fill 348 160 558 350 160 559 minecraft:green_terracotta
setblock 348 160 560 minecraft:light[level=14]
setblock 348 160 568 minecraft:light[level=14]
setblock 348 160 576 minecraft:light[level=14]
setblock 348 160 584 minecraft:light[level=14]
setblock 348 160 592 minecraft:light[level=14]
setblock 348 160 596 minecraft:green_terracotta
setblock 348 160 597 minecraft:oak_log
fill 348 160 598 351 160 598 minecraft:green_terracotta
setblock 349 160 596 minecraft:oak_log
fill 349 160 597 352 160 597 minecraft:green_terracotta
fill 350 160 596 350 163 596 minecraft:green_terracotta
setblock 351 160 558 minecraft:green_terracotta
setblock 351 160 559 minecraft:oak_log
fill 351 160 595 351 161 595 minecraft:green_terracotta
setblock 352 160 558 minecraft:oak_log
fill 352 160 559 352 163 559 minecraft:green_terracotta
setblock 352 160 598 minecraft:oak_log
fill 353 160 558 353 163 558 minecraft:green_terracotta
setblock 353 160 597 minecraft:oak_log
fill 353 160 598 353 163 598 minecraft:green_terracotta
setblock 354 160 596 minecraft:oak_log
fill 354 160 597 354 163 597 minecraft:green_terracotta
setblock 355 160 595 minecraft:oak_log
fill 355 160 596 355 163 596 minecraft:green_terracotta
setblock 356 160 559 minecraft:oak_log
setblock 356 160 560 minecraft:light[level=14]
setblock 356 160 568 minecraft:light[level=14]
setblock 356 160 576 minecraft:light[level=14]
setblock 356 160 584 minecraft:light[level=14]
setblock 356 160 592 minecraft:light[level=14]
fill 356 160 595 356 162 595 minecraft:green_terracotta
setblock 357 160 558 minecraft:oak_log
fill 357 160 559 357 162 559 minecraft:green_terracotta
setblock 357 160 598 minecraft:oak_log
fill 358 160 558 358 163 558 minecraft:green_terracotta
setblock 358 160 597 minecraft:oak_log
fill 358 160 598 358 163 598 minecraft:green_terracotta
setblock 359 160 596 minecraft:oak_log
fill 359 160 597 359 163 597 minecraft:green_terracotta
fill 360 160 596 360 161 596 minecraft:green_terracotta
setblock 362 160 598 minecraft:oak_log
setblock 363 160 597 minecraft:oak_log
fill 363 160 598 366 160 598 minecraft:green_terracotta
setblock 364 160 560 minecraft:light[level=14]
setblock 364 160 568 minecraft:light[level=14]
setblock 364 160 576 minecraft:light[level=14]
setblock 364 160 584 minecraft:light[level=14]
setblock 364 160 592 minecraft:light[level=14]
setblock 364 160 597 minecraft:green_terracotta
setblock 366 160 558 minecraft:oak_leaves[persistent=true]
setblock 367 160 598 minecraft:oak_log
fill 368 160 575 368 160 576 minecraft:green_terracotta
setblock 368 160 577 minecraft:oak_log
fill 368 160 598 368 163 598 minecraft:green_terracotta
setblock 369 160 571 minecraft:oak_log
fill 369 160 572 369 163 572 minecraft:green_terracotta
setblock 369 160 576 minecraft:oak_log
fill 369 160 577 369 163 577 minecraft:green_terracotta
fill 369 160 579 369 160 580 minecraft:green_terracotta
setblock 369 160 581 minecraft:oak_log
fill 369 160 582 369 163 582 minecraft:green_terracotta
setblock 369 160 595 minecraft:green_terracotta
setblock 369 160 596 minecraft:oak_log
setblock 369 160 597 minecraft:green_terracotta
fill 370 160 558 370 161 558 minecraft:green_terracotta
setblock 370 160 570 minecraft:oak_log
fill 370 160 571 370 163 571 minecraft:green_terracotta
setblock 370 160 575 minecraft:oak_log
fill 370 160 576 370 163 576 minecraft:green_terracotta
setblock 370 160 579 minecraft:green_terracotta
setblock 370 160 580 minecraft:oak_log
fill 370 160 581 370 163 581 minecraft:green_terracotta
setblock 370 160 585 minecraft:oak_log
fill 370 160 586 370 163 586 minecraft:green_terracotta
setblock 370 160 590 minecraft:oak_log
fill 370 160 591 370 162 591 minecraft:green_terracotta
setblock 370 160 595 minecraft:oak_log
fill 370 160 596 370 163 596 minecraft:green_terracotta
setblock 330 161 558 minecraft:green_terracotta
setblock 330 161 559 minecraft:oak_log
fill 330 161 560 330 164 560 minecraft:green_terracotta
setblock 330 161 564 minecraft:oak_log
fill 330 161 565 330 164 565 minecraft:green_terracotta
setblock 330 161 569 minecraft:oak_log
fill 330 161 570 330 164 570 minecraft:green_terracotta
setblock 330 161 574 minecraft:oak_log
fill 330 161 575 330 164 575 minecraft:green_terracotta
setblock 330 161 579 minecraft:oak_log
fill 330 161 580 330 164 580 minecraft:green_terracotta
setblock 330 161 584 minecraft:oak_log
setblock 330 161 593 minecraft:green_terracotta
setblock 330 161 594 minecraft:oak_log
fill 330 161 595 330 164 595 minecraft:green_terracotta
setblock 331 161 558 minecraft:oak_log
fill 331 161 559 331 164 559 minecraft:green_terracotta
setblock 331 161 563 minecraft:oak_log
fill 331 161 564 331 164 564 minecraft:green_terracotta
setblock 331 161 568 minecraft:oak_log
fill 331 161 569 331 164 569 minecraft:green_terracotta
setblock 331 161 573 minecraft:oak_log
fill 331 161 574 331 164 574 minecraft:green_terracotta
setblock 331 161 578 minecraft:oak_log
fill 331 161 579 331 164 579 minecraft:green_terracotta
setblock 331 161 582 minecraft:green_terracotta
setblock 331 161 597 minecraft:green_terracotta
setblock 331 161 598 minecraft:oak_log
fill 332 161 558 332 164 558 minecraft:green_terracotta
setblock 332 161 572 minecraft:oak_log
fill 332 161 573 332 164 573 minecraft:green_terracotta
setblock 332 161 577 minecraft:oak_log
fill 332 161 578 332 164 578 minecraft:green_terracotta
setblock 332 161 597 minecraft:oak_log
fill 332 161 598 335 161 598 minecraft:green_terracotta
setblock 333 161 560 minecraft:green_terracotta
setblock 333 161 572 minecraft:green_terracotta
setblock 333 161 576 minecraft:oak_log
fill 333 161 577 333 162 577 minecraft:green_terracotta
fill 333 161 597 333 164 597 minecraft:green_terracotta
setblock 334 161 560 minecraft:oak_log
setblock 335 161 559 minecraft:oak_log
fill 335 161 560 335 164 560 minecraft:green_terracotta
setblock 336 161 558 minecraft:oak_log
fill 336 161 559 336 164 559 minecraft:green_terracotta
setblock 336 161 598 minecraft:oak_log
fill 337 161 558 337 164 558 minecraft:green_terracotta
setblock 337 161 597 minecraft:oak_log
fill 337 161 598 337 164 598 minecraft:green_terracotta
fill 338 161 597 338 163 597 minecraft:green_terracotta
setblock 340 161 559 minecraft:oak_log
setblock 341 161 558 minecraft:oak_log
fill 341 161 559 341 164 559 minecraft:green_terracotta
setblock 341 161 598 minecraft:oak_log
fill 342 161 558 345 161 558 minecraft:green_terracotta
setblock 342 161 597 minecraft:oak_log
fill 342 161 598 345 161 598 minecraft:green_terracotta
fill 343 161 597 346 161 597 minecraft:green_terracotta
setblock 346 161 558 minecraft:oak_log
setblock 346 161 598 minecraft:oak_log
fill 347 161 558 349 161 559 minecraft:green_terracotta
setblock 347 161 597 minecraft:oak_log
fill 347 161 598 350 161 598 minecraft:green_terracotta
setblock 348 161 596 minecraft:oak_log
fill 348 161 597 351 161 597 minecraft:green_terracotta
fill 349 161 596 349 164 596 minecraft:green_terracotta
setblock 350 161 558 minecraft:green_terracotta
setblock 350 161 559 minecraft:oak_log
fill 350 161 579 350 188 579 minecraft:oak_log
setblock 351 161 558 minecraft:oak_log
fill 351 161 559 351 164 559 minecraft:green_terracotta
setblock 351 161 598 minecraft:oak_log
fill 352 161 558 352 164 558 minecraft:green_terracotta
setblock 352 161 597 minecraft:oak_log
fill 352 161 598 352 164 598 minecraft:green_terracotta
setblock 353 161 596 minecraft:oak_log
fill 353 161 597 353 164 597 minecraft:green_terracotta
setblock 354 161 595 minecraft:oak_log
fill 354 161 596 354 164 596 minecraft:green_terracotta
setblock 355 161 559 minecraft:oak_log
fill 355 161 595 355 162 595 minecraft:green_terracotta
setblock 356 161 558 minecraft:oak_log
fill 356 161 559 356 164 559 minecraft:green_terracotta
setblock 356 161 598 minecraft:oak_log
fill 357 161 558 357 164 558 minecraft:green_terracotta
setblock 357 161 597 minecraft:oak_log
fill 357 161 598 357 164 598 minecraft:green_terracotta
setblock 358 161 596 minecraft:oak_log
fill 358 161 597 358 164 597 minecraft:green_terracotta
fill 359 161 596 359 162 596 minecraft:green_terracotta
setblock 361 161 558 minecraft:oak_log
setblock 361 161 598 minecraft:oak_log
setblock 362 161 597 minecraft:oak_log
fill 362 161 598 365 161 598 minecraft:green_terracotta
setblock 363 161 597 minecraft:green_terracotta
setblock 366 161 598 minecraft:oak_log
fill 367 161 598 367 163 598 minecraft:green_terracotta
setblock 368 161 575 minecraft:green_terracotta
setblock 368 161 576 minecraft:oak_log
fill 368 161 577 368 163 578 minecraft:green_terracotta
setblock 369 161 571 minecraft:green_terracotta
setblock 369 161 575 minecraft:oak_log
fill 369 161 576 369 164 576 minecraft:green_terracotta
setblock 369 161 579 minecraft:green_terracotta
setblock 369 161 580 minecraft:oak_log
fill 369 161 581 369 164 581 minecraft:green_terracotta
setblock 370 161 559 minecraft:oak_log
setblock 370 161 569 minecraft:oak_log
fill 370 161 570 370 164 570 minecraft:green_terracotta
setblock 370 161 574 minecraft:oak_log
fill 370 161 575 370 164 575 minecraft:green_terracotta
setblock 370 161 579 minecraft:oak_log
fill 370 161 580 370 164 580 minecraft:green_terracotta
setblock 370 161 584 minecraft:oak_log
fill 370 161 585 370 164 585 minecraft:green_terracotta
setblock 370 161 589 minecraft:oak_log
fill 370 161 590 370 162 590 minecraft:green_terracotta
setblock 370 161 594 minecraft:oak_log
fill 370 161 595 370 164 595 minecraft:green_terracotta
setblock 330 162 558 minecraft:oak_log
fill 330 162 559 330 165 559 minecraft:green_terracotta
setblock 330 162 563 minecraft:oak_log
fill 330 162 564 330 165 564 minecraft:green_terracotta
setblock 330 162 568 minecraft:oak_log
fill 330 162 569 330 165 569 minecraft:green_terracotta
setblock 330 162 573 minecraft:oak_log
fill 330 162 574 330 165 574 minecraft:green_terracotta
setblock 330 162 578 minecraft:oak_log
fill 330 162 579 330 165 579 minecraft:green_terracotta
setblock 330 162 583 minecraft:oak_log
fill 330 162 584 330 165 584 minecraft:green_terracotta
setblock 330 162 589 minecraft:oak_leaves[persistent=true]
setblock 330 162 594 minecraft:green_terracotta
fill 330 162 596 330 162 597 minecraft:green_terracotta
setblock 330 162 598 minecraft:oak_log
fill 331 162 558 331 165 558 minecraft:green_terracotta
setblock 331 162 562 minecraft:oak_log
fill 331 162 563 331 165 563 minecraft:green_terracotta
setblock 331 162 567 minecraft:oak_log
fill 331 162 568 331 165 568 minecraft:green_terracotta
setblock 331 162 572 minecraft:oak_log
fill 331 162 573 331 165 573 minecraft:green_terracotta
setblock 331 162 577 minecraft:oak_log
fill 331 162 578 331 165 578 minecraft:green_terracotta
setblock 331 162 582 minecraft:oak_log
setblock 331 162 597 minecraft:oak_log
fill 331 162 598 334 162 598 minecraft:green_terracotta
setblock 332 162 560 minecraft:green_terracotta
setblock 332 162 571 minecraft:oak_log
fill 332 162 572 332 163 572 minecraft:green_terracotta
setblock 332 162 576 minecraft:oak_log
fill 332 162 577 332 165 577 minecraft:green_terracotta
fill 332 162 597 332 165 597 minecraft:green_terracotta
setblock 333 162 560 minecraft:oak_log
setblock 333 162 575 minecraft:oak_log
setblock 333 162 576 minecraft:green_terracotta
setblock 334 162 559 minecraft:oak_log
fill 334 162 560 334 165 560 minecraft:green_terracotta
setblock 335 162 558 minecraft:oak_log
fill 335 162 559 335 165 559 minecraft:green_terracotta
setblock 335 162 598 minecraft:oak_log
fill 336 162 558 336 165 558 minecraft:green_terracotta
setblock 336 162 597 minecraft:oak_log
fill 336 162 598 336 165 598 minecraft:green_terracotta
fill 337 162 597 337 164 597 minecraft:green_terracotta
setblock 339 162 559 minecraft:oak_log
setblock 340 162 558 minecraft:oak_log
fill 340 162 559 340 165 559 minecraft:green_terracotta
setblock 340 162 598 minecraft:oak_log
fill 341 162 558 344 162 558 minecraft:green_terracotta
setblock 341 162 597 minecraft:oak_log
fill 341 162 598 344 162 598 minecraft:green_terracotta
fill 342 162 597 345 162 597 minecraft:green_terracotta
setblock 345 162 558 minecraft:oak_log
setblock 345 162 598 minecraft:oak_log
fill 346 162 558 349 162 558 minecraft:green_terracotta
setblock 346 162 597 minecraft:oak_log
fill 346 162 598 349 162 598 minecraft:green_terracotta
fill 347 162 559 348 162 559 minecraft:green_terracotta
fill 347 162 597 350 162 597 minecraft:green_terracotta
setblock 348 162 596 minecraft:green_terracotta
setblock 349 162 559 minecraft:oak_log
setblock 350 162 558 minecraft:oak_log
fill 350 162 559 350 165 559 minecraft:green_terracotta
setblock 350 162 598 minecraft:oak_log
fill 351 162 558 351 165 558 minecraft:green_terracotta
setblock 351 162 597 minecraft:oak_log
fill 351 162 598 351 165 598 minecraft:green_terracotta
setblock 352 162 596 minecraft:oak_log
fill 352 162 597 352 165 597 minecraft:green_terracotta
setblock 353 162 595 minecraft:oak_log
fill 353 162 596 353 165 596 minecraft:green_terracotta
setblock 354 162 559 minecraft:oak_log
setblock 354 162 595 minecraft:green_terracotta
setblock 355 162 558 minecraft:oak_log
fill 355 162 559 355 165 559 minecraft:green_terracotta
setblock 355 162 598 minecraft:oak_log
fill 356 162 558 356 165 558 minecraft:green_terracotta
setblock 356 162 597 minecraft:oak_log
fill 356 162 598 356 165 598 minecraft:green_terracotta
setblock 357 162 596 minecraft:oak_log
fill 357 162 597 357 165 597 minecraft:green_terracotta
setblock 358 162 596 minecraft:green_terracotta
setblock 360 162 558 minecraft:oak_log
setblock 360 162 598 minecraft:oak_log
setblock 361 162 597 minecraft:oak_log
fill 361 162 598 364 162 598 minecraft:green_terracotta
setblock 365 162 598 minecraft:oak_log
setblock 366 162 598 minecraft:green_terracotta
fill 368 162 576 368 165 576 minecraft:green_terracotta
setblock 368 162 579 minecraft:green_terracotta
setblock 369 162 558 minecraft:green_terracotta
setblock 369 162 574 minecraft:oak_log
fill 369 162 575 369 165 575 minecraft:green_terracotta
setblock 369 162 579 minecraft:oak_log
fill 369 162 580 369 165 580 minecraft:green_terracotta
setblock 369 162 583 minecraft:green_terracotta
setblock 370 162 558 minecraft:oak_log
fill 370 162 559 370 164 560 minecraft:green_terracotta
setblock 370 162 567 minecraft:oak_leaves[persistent=true]
setblock 370 162 568 minecraft:oak_log
fill 370 162 569 370 165 569 minecraft:green_terracotta
setblock 370 162 573 minecraft:oak_log
fill 370 162 574 370 165 574 minecraft:green_terracotta
setblock 370 162 578 minecraft:oak_log
fill 370 162 579 370 165 579 minecraft:green_terracotta
setblock 370 162 583 minecraft:oak_log
fill 370 162 584 370 165 584 minecraft:green_terracotta
setblock 370 162 588 minecraft:oak_log
setblock 370 162 589 minecraft:green_terracotta
setblock 370 162 593 minecraft:oak_log
fill 370 162 594 370 164 594 minecraft:green_terracotta
setblock 370 162 598 minecraft:oak_log
fill 330 163 558 330 166 558 minecraft:green_terracotta
setblock 330 163 561 minecraft:green_terracotta
setblock 330 163 562 minecraft:oak_log
fill 330 163 563 330 166 563 minecraft:green_terracotta
setblock 330 163 567 minecraft:oak_log
fill 330 163 568 330 166 568 minecraft:green_terracotta
setblock 330 163 572 minecraft:oak_log
fill 330 163 573 330 166 573 minecraft:green_terracotta
setblock 330 163 577 minecraft:oak_log
fill 330 163 578 330 166 578 minecraft:green_terracotta
setblock 330 163 582 minecraft:oak_log
fill 330 163 583 330 166 583 minecraft:green_terracotta
setblock 330 163 596 minecraft:green_terracotta
setblock 330 163 597 minecraft:oak_log
fill 330 163 598 333 163 598 minecraft:green_terracotta
setblock 331 163 561 minecraft:oak_log
fill 331 163 562 331 166 562 minecraft:green_terracotta
setblock 331 163 566 minecraft:oak_log
fill 331 163 567 331 166 567 minecraft:green_terracotta
setblock 331 163 571 minecraft:oak_log
fill 331 163 572 331 166 572 minecraft:green_terracotta
setblock 331 163 576 minecraft:oak_log
fill 331 163 577 331 166 577 minecraft:green_terracotta
setblock 331 163 580 minecraft:green_terracotta
setblock 331 163 581 minecraft:oak_log
fill 331 163 582 331 166 582 minecraft:green_terracotta
fill 331 163 597 331 164 597 minecraft:green_terracotta
setblock 332 163 560 minecraft:oak_log
fill 332 163 561 332 166 561 minecraft:green_terracotta
setblock 332 163 571 minecraft:green_terracotta
setblock 332 163 575 minecraft:oak_log
fill 332 163 576 332 165 576 minecraft:green_terracotta
setblock 332 163 580 minecraft:oak_log
setblock 333 163 559 minecraft:oak_log
fill 333 163 560 333 166 560 minecraft:green_terracotta
setblock 334 163 558 minecraft:oak_log
fill 334 163 559 334 166 559 minecraft:green_terracotta
setblock 334 163 598 minecraft:oak_log
fill 335 163 558 335 166 558 minecraft:green_terracotta
setblock 335 163 597 minecraft:oak_log
fill 335 163 598 335 166 598 minecraft:green_terracotta
fill 336 163 597 336 164 597 minecraft:green_terracotta
setblock 337 163 560 minecraft:oak_log
setblock 338 163 559 minecraft:oak_log
setblock 339 163 558 minecraft:oak_log
fill 339 163 559 339 166 559 minecraft:green_terracotta
setblock 339 163 598 minecraft:oak_log
fill 340 163 558 343 163 558 minecraft:green_terracotta
fill 340 163 598 343 163 598 minecraft:green_terracotta
setblock 344 163 558 minecraft:oak_log
setblock 344 163 598 minecraft:oak_log
fill 345 163 558 348 163 558 minecraft:green_terracotta
setblock 345 163 597 minecraft:oak_log
fill 345 163 598 348 163 598 minecraft:green_terracotta
fill 346 163 597 349 163 597 minecraft:green_terracotta
setblock 347 163 559 minecraft:green_terracotta
setblock 348 163 559 minecraft:oak_log
setblock 349 163 558 minecraft:oak_log
fill 349 163 559 349 166 559 minecraft:green_terracotta
setblock 349 163 598 minecraft:oak_log
fill 350 163 558 350 166 558 minecraft:green_terracotta
setblock 350 163 597 minecraft:oak_log
fill 350 163 598 350 166 598 minecraft:green_terracotta
setblock 351 163 596 minecraft:oak_log
fill 351 163 597 351 166 597 minecraft:green_terracotta
fill 352 163 596 352 166 596 minecraft:green_terracotta
setblock 353 163 559 minecraft:oak_log
setblock 354 163 558 minecraft:oak_log
fill 354 163 559 354 166 559 minecraft:green_terracotta
setblock 354 163 598 minecraft:oak_log
fill 355 163 558 355 166 558 minecraft:green_terracotta
setblock 355 163 597 minecraft:oak_log
fill 355 163 598 355 166 598 minecraft:green_terracotta
setblock 356 163 596 minecraft:oak_log
fill 356 163 597 356 166 597 minecraft:green_terracotta
setblock 357 163 596 minecraft:green_terracotta
setblock 359 163 558 minecraft:oak_log
setblock 359 163 598 minecraft:oak_log
setblock 360 163 597 minecraft:oak_log
fill 360 163 598 363 163 598 minecraft:green_terracotta
setblock 368 163 579 minecraft:oak_log
setblock 369 163 558 minecraft:oak_log
setblock 369 163 573 minecraft:oak_log
fill 369 163 574 369 166 574 minecraft:green_terracotta
setblock 369 163 578 minecraft:oak_log
fill 369 163 579 369 166 579 minecraft:green_terracotta
setblock 369 163 583 minecraft:oak_log
setblock 369 163 598 minecraft:oak_log
fill 370 163 558 370 166 558 minecraft:green_terracotta
setblock 370 163 561 minecraft:green_terracotta
fill 370 163 568 370 166 568 minecraft:green_terracotta
setblock 370 163 572 minecraft:oak_log
fill 370 163 573 370 166 573 minecraft:green_terracotta
setblock 370 163 577 minecraft:oak_log
fill 370 163 578 370 166 578 minecraft:green_terracotta
setblock 370 163 582 minecraft:oak_log
fill 370 163 583 370 166 583 minecraft:green_terracotta
setblock 370 163 587 minecraft:oak_log
setblock 370 163 593 minecraft:green_terracotta
setblock 370 163 597 minecraft:oak_log
fill 370 163 598 370 166 598 minecraft:green_terracotta
setblock 330 164 561 minecraft:oak_log
fill 330 164 562 330 167 562 minecraft:green_terracotta
setblock 330 164 566 minecraft:oak_log
fill 330 164 567 330 167 567 minecraft:green_terracotta
setblock 330 164 571 minecraft:oak_log
fill 330 164 572 330 167 572 minecraft:green_terracotta
setblock 330 164 576 minecraft:oak_log
fill 330 164 577 330 167 577 minecraft:green_terracotta
setblock 330 164 581 minecraft:oak_log
fill 330 164 582 330 167 582 minecraft:green_terracotta
setblock 330 164 596 minecraft:oak_log
fill 330 164 597 330 166 598 minecraft:green_terracotta
setblock 331 164 560 minecraft:oak_log
fill 331 164 561 331 167 561 minecraft:green_terracotta
setblock 331 164 565 minecraft:oak_log
fill 331 164 566 331 167 566 minecraft:green_terracotta
setblock 331 164 570 minecraft:oak_log
fill 331 164 571 331 167 571 minecraft:green_terracotta
setblock 331 164 575 minecraft:oak_log
fill 331 164 576 331 167 576 minecraft:green_terracotta
setblock 331 164 580 minecraft:oak_log
fill 331 164 581 331 167 581 minecraft:green_terracotta
fill 331 164 598 332 164 598 minecraft:green_terracotta
setblock 332 164 559 minecraft:oak_log
fill 332 164 560 332 167 560 minecraft:green_terracotta
fill 332 164 562 332 165 562 minecraft:green_terracotta
setblock 332 164 574 minecraft:oak_log
fill 332 164 575 332 165 575 minecraft:green_terracotta
setblock 332 164 579 minecraft:oak_log
setblock 333 164 558 minecraft:oak_log
fill 333 164 559 333 167 559 minecraft:green_terracotta
setblock 333 164 598 minecraft:oak_log
fill 334 164 558 334 167 558 minecraft:green_terracotta
setblock 334 164 597 minecraft:oak_log
fill 334 164 598 334 167 598 minecraft:green_terracotta
fill 335 164 597 335 165 597 minecraft:green_terracotta
setblock 336 164 560 minecraft:oak_log
setblock 337 164 559 minecraft:oak_log
setblock 337 164 560 minecraft:green_terracotta
setblock 338 164 558 minecraft:oak_log
fill 338 164 559 338 167 559 minecraft:green_terracotta
setblock 338 164 598 minecraft:oak_log
fill 339 164 558 342 164 558 minecraft:green_terracotta
fill 339 164 598 342 164 598 minecraft:green_terracotta
setblock 343 164 558 minecraft:oak_log
setblock 343 164 598 minecraft:oak_log
fill 344 164 558 347 164 558 minecraft:green_terracotta
fill 344 164 598 347 164 598 minecraft:green_terracotta
setblock 346 164 559 minecraft:green_terracotta
fill 346 164 597 348 164 597 minecraft:green_terracotta
setblock 347 164 559 minecraft:oak_log
setblock 348 164 558 minecraft:oak_log
fill 348 164 559 348 167 559 minecraft:green_terracotta
setblock 348 164 598 minecraft:oak_log
fill 349 164 558 349 167 558 minecraft:green_terracotta
setblock 349 164 597 minecraft:oak_log
fill 349 164 598 349 167 598 minecraft:green_terracotta
setblock 350 164 596 minecraft:oak_log
fill 350 164 597 350 167 597 minecraft:green_terracotta
fill 351 164 596 351 167 596 minecraft:green_terracotta
setblock 352 164 559 minecraft:oak_log
setblock 353 164 558 minecraft:oak_log
fill 353 164 559 353 167 559 minecraft:green_terracotta
setblock 353 164 598 minecraft:oak_log
fill 354 164 558 354 167 558 minecraft:green_terracotta
setblock 354 164 597 minecraft:oak_log
fill 354 164 598 354 167 598 minecraft:green_terracotta
setblock 355 164 596 minecraft:oak_log
fill 355 164 597 355 167 597 minecraft:green_terracotta
setblock 356 164 596 minecraft:green_terracotta
setblock 358 164 558 minecraft:oak_log
setblock 358 164 598 minecraft:oak_log
setblock 359 164 597 minecraft:oak_log
fill 359 164 598 361 164 598 minecraft:green_terracotta
fill 361 164 558 361 165 558 minecraft:oak_leaves[persistent=true]
setblock 367 164 558 minecraft:oak_leaves[persistent=true]
setblock 368 164 558 minecraft:oak_log
setblock 368 164 577 minecraft:green_terracotta
setblock 368 164 578 minecraft:oak_log
fill 368 164 579 368 166 580 minecraft:green_terracotta
setblock 368 164 598 minecraft:oak_log
fill 369 164 558 369 167 558 minecraft:green_terracotta
setblock 369 164 572 minecraft:oak_log
fill 369 164 573 369 167 573 minecraft:green_terracotta
setblock 369 164 577 minecraft:oak_log
fill 369 164 578 369 167 578 minecraft:green_terracotta
setblock 369 164 582 minecraft:oak_log
fill 369 164 583 369 166 584 minecraft:green_terracotta
fill 369 164 598 369 167 598 minecraft:green_terracotta
setblock 370 164 561 minecraft:oak_log
fill 370 164 562 370 166 563 minecraft:green_terracotta
setblock 370 164 571 minecraft:oak_log
fill 370 164 572 370 167 572 minecraft:green_terracotta
setblock 370 164 576 minecraft:oak_log
fill 370 164 577 370 167 577 minecraft:green_terracotta
setblock 370 164 581 minecraft:oak_log
fill 370 164 582 370 167 582 minecraft:green_terracotta
setblock 370 164 586 minecraft:oak_log
fill 370 164 587 370 167 587 minecraft:green_terracotta
setblock 370 164 596 minecraft:oak_log
fill 370 164 597 370 167 597 minecraft:green_terracotta
setblock 330 165 560 minecraft:oak_log
fill 330 165 561 330 168 561 minecraft:green_terracotta
setblock 330 165 565 minecraft:oak_log
fill 330 165 566 330 168 566 minecraft:green_terracotta
setblock 330 165 570 minecraft:oak_log
fill 330 165 571 330 168 571 minecraft:green_terracotta
setblock 330 165 575 minecraft:oak_log
fill 330 165 576 330 168 576 minecraft:green_terracotta
setblock 330 165 580 minecraft:oak_log
fill 330 165 581 330 168 581 minecraft:green_terracotta
setblock 330 165 585 minecraft:oak_log
setblock 330 165 588 minecraft:oak_leaves[persistent=true]
fill 330 165 596 330 168 596 minecraft:green_terracotta
setblock 331 165 559 minecraft:oak_log
fill 331 165 560 331 168 560 minecraft:green_terracotta
setblock 331 165 564 minecraft:oak_log
fill 331 165 565 331 168 565 minecraft:green_terracotta
setblock 331 165 569 minecraft:oak_log
fill 331 165 570 331 168 570 minecraft:green_terracotta
setblock 331 165 574 minecraft:oak_log
fill 331 165 575 331 168 575 minecraft:green_terracotta
setblock 331 165 579 minecraft:oak_log
fill 331 165 580 331 168 580 minecraft:green_terracotta
setblock 331 165 598 minecraft:green_terracotta
setblock 332 165 558 minecraft:oak_log
fill 332 165 559 332 168 559 minecraft:green_terracotta
setblock 332 165 563 minecraft:oak_log
setblock 332 165 578 minecraft:oak_log
fill 332 165 579 332 166 579 minecraft:green_terracotta
setblock 332 165 598 minecraft:oak_log
fill 333 165 558 333 168 558 minecraft:green_terracotta
setblock 333 165 597 minecraft:oak_log
fill 333 165 598 333 168 598 minecraft:green_terracotta
setblock 334 165 597 minecraft:green_terracotta
setblock 335 165 560 minecraft:oak_log
setblock 336 165 559 minecraft:oak_log
fill 336 165 560 336 168 560 minecraft:green_terracotta
setblock 337 165 558 minecraft:oak_log
fill 337 165 559 337 168 559 minecraft:green_terracotta
setblock 337 165 598 minecraft:oak_log
fill 338 165 558 341 165 558 minecraft:green_terracotta
fill 338 165 598 341 165 598 minecraft:green_terracotta
setblock 341 165 559 minecraft:oak_log
setblock 342 165 558 minecraft:oak_log
setblock 342 165 598 minecraft:oak_log
fill 343 165 558 346 165 558 minecraft:green_terracotta
fill 343 165 598 346 165 598 minecraft:green_terracotta
setblock 345 165 559 minecraft:green_terracotta
setblock 346 165 559 minecraft:oak_log
fill 346 165 597 347 165 597 minecraft:green_terracotta
setblock 347 165 558 minecraft:oak_log
fill 347 165 559 347 168 559 minecraft:green_terracotta
setblock 347 165 598 minecraft:oak_log
fill 348 165 558 348 168 558 minecraft:green_terracotta
setblock 348 165 597 minecraft:oak_log
fill 348 165 598 348 168 598 minecraft:green_terracotta
setblock 349 165 596 minecraft:oak_log
fill 349 165 597 349 168 597 minecraft:green_terracotta
fill 350 165 596 350 168 596 minecraft:green_terracotta
setblock 351 165 559 minecraft:oak_log
setblock 352 165 558 minecraft:oak_log
fill 352 165 559 352 168 559 minecraft:green_terracotta
setblock 352 165 598 minecraft:oak_log
fill 353 165 558 353 168 558 minecraft:green_terracotta
setblock 353 165 597 minecraft:oak_log
fill 353 165 598 353 168 598 minecraft:green_terracotta
setblock 354 165 596 minecraft:oak_log
fill 354 165 597 354 168 597 minecraft:green_terracotta
setblock 355 165 596 minecraft:green_terracotta
setblock 357 165 558 minecraft:oak_log
setblock 357 165 598 minecraft:oak_log
setblock 358 165 558 minecraft:green_terracotta
fill 358 165 598 360 165 598 minecraft:green_terracotta
setblock 364 165 598 minecraft:oak_leaves[persistent=true]
fill 368 165 558 368 168 558 minecraft:green_terracotta
setblock 368 165 577 minecraft:oak_log
fill 368 165 578 368 168 578 minecraft:green_terracotta
setblock 368 165 581 minecraft:green_terracotta
fill 368 165 598 368 168 598 minecraft:green_terracotta
setblock 369 165 576 minecraft:oak_log
fill 369 165 577 369 168 577 minecraft:green_terracotta
setblock 369 165 581 minecraft:oak_log
fill 369 165 582 369 168 582 minecraft:green_terracotta
setblock 370 165 559 minecraft:green_terracotta
setblock 370 165 560 minecraft:oak_log
fill 370 165 561 370 168 561 minecraft:green_terracotta
setblock 370 165 564 minecraft:green_terracotta
setblock 370 165 565 minecraft:oak_log
fill 370 165 566 370 167 567 minecraft:green_terracotta
setblock 370 165 570 minecraft:oak_log
fill 370 165 571 370 168 571 minecraft:green_terracotta
setblock 370 165 575 minecraft:oak_log
fill 370 165 576 370 168 576 minecraft:green_terracotta
setblock 370 165 580 minecraft:oak_log
fill 370 165 581 370 168 581 minecraft:green_terracotta
setblock 370 165 585 minecraft:oak_log
fill 370 165 586 370 168 586 minecraft:green_terracotta
setblock 370 165 593 minecraft:oak_leaves[persistent=true]
fill 370 165 596 370 168 596 minecraft:green_terracotta
setblock 330 166 559 minecraft:oak_log
fill 330 166 560 330 169 560 minecraft:green_terracotta
setblock 330 166 564 minecraft:oak_log
fill 330 166 565 330 169 565 minecraft:green_terracotta
setblock 330 166 569 minecraft:oak_log
fill 330 166 570 330 169 570 minecraft:green_terracotta
setblock 330 166 574 minecraft:oak_log
fill 330 166 575 330 169 575 minecraft:green_terracotta
setblock 330 166 579 minecraft:oak_log
fill 330 166 580 330 169 580 minecraft:green_terracotta
setblock 330 166 584 minecraft:oak_log
fill 330 166 585 330 169 585 minecraft:green_terracotta
setblock 330 166 594 minecraft:oak_leaves[persistent=true]
setblock 331 166 558 minecraft:oak_log
fill 331 166 559 331 169 559 minecraft:green_terracotta
setblock 331 166 563 minecraft:oak_log
fill 331 166 564 331 169 564 minecraft:green_terracotta
setblock 331 166 568 minecraft:oak_log
fill 331 166 569 331 169 569 minecraft:green_terracotta
setblock 331 166 573 minecraft:oak_log
fill 331 166 574 331 169 574 minecraft:green_terracotta
setblock 331 166 578 minecraft:oak_log
fill 331 166 579 331 169 579 minecraft:green_terracotta
setblock 331 166 583 minecraft:oak_log
setblock 331 166 598 minecraft:oak_log
fill 332 166 558 332 169 558 minecraft:green_terracotta
setblock 332 166 562 minecraft:oak_log
fill 332 166 563 332 169 563 minecraft:green_terracotta
setblock 332 166 577 minecraft:oak_log
setblock 332 166 578 minecraft:green_terracotta
fill 332 166 598 332 169 598 minecraft:green_terracotta
setblock 334 166 560 minecraft:oak_log
setblock 335 166 559 minecraft:oak_log
fill 335 166 560 335 169 560 minecraft:green_terracotta
setblock 336 166 558 minecraft:oak_log
fill 336 166 559 336 169 559 minecraft:green_terracotta
setblock 336 166 598 minecraft:oak_log
fill 337 166 558 340 166 558 minecraft:green_terracotta
fill 337 166 598 340 166 598 minecraft:green_terracotta
setblock 340 166 559 minecraft:oak_log
setblock 341 166 558 minecraft:oak_log
fill 341 166 559 341 169 559 minecraft:green_terracotta
setblock 341 166 598 minecraft:oak_log
fill 342 166 558 345 166 558 minecraft:green_terracotta
fill 342 166 598 345 166 598 minecraft:green_terracotta
setblock 344 166 559 minecraft:green_terracotta
setblock 345 166 559 minecraft:oak_log
setblock 346 166 558 minecraft:oak_log
fill 346 166 559 346 169 559 minecraft:green_terracotta
setblock 346 166 597 minecraft:green_terracotta
setblock 346 166 598 minecraft:oak_log
fill 347 166 558 347 169 558 minecraft:green_terracotta
setblock 347 166 597 minecraft:oak_log
fill 347 166 598 347 169 598 minecraft:green_terracotta
fill 348 166 597 348 169 597 minecraft:green_terracotta
setblock 350 166 559 minecraft:oak_log
setblock 351 166 558 minecraft:oak_log
fill 351 166 559 351 169 559 minecraft:green_terracotta
setblock 351 166 598 minecraft:oak_log
fill 352 166 558 352 169 558 minecraft:green_terracotta
setblock 352 166 597 minecraft:oak_log
fill 352 166 598 352 169 598 minecraft:green_terracotta
setblock 353 166 596 minecraft:oak_log
fill 353 166 597 353 169 597 minecraft:green_terracotta
setblock 355 166 559 minecraft:oak_log
setblock 356 166 558 minecraft:oak_log
setblock 356 166 598 minecraft:oak_log
fill 357 166 558 357 169 558 minecraft:green_terracotta
fill 357 166 598 359 166 598 minecraft:green_terracotta
fill 358 166 571 358 167 571 minecraft:glowstone
fill 367 166 558 367 169 558 minecraft:green_terracotta
setblock 368 166 576 minecraft:oak_log
fill 368 166 577 368 169 577 minecraft:green_terracotta
setblock 368 166 581 minecraft:oak_log
fill 368 166 582 368 169 582 minecraft:green_terracotta
setblock 369 166 575 minecraft:oak_log
fill 369 166 576 369 169 576 minecraft:green_terracotta
setblock 369 166 580 minecraft:oak_log
fill 369 166 581 369 169 581 minecraft:green_terracotta
setblock 369 166 585 minecraft:oak_log
setblock 370 166 559 minecraft:oak_log
fill 370 166 560 370 169 560 minecraft:green_terracotta
setblock 370 166 564 minecraft:oak_log
fill 370 166 565 370 169 565 minecraft:green_terracotta
setblock 370 166 569 minecraft:oak_log
fill 370 166 570 370 169 570 minecraft:green_terracotta
setblock 370 166 574 minecraft:oak_log
fill 370 166 575 370 169 575 minecraft:green_terracotta
setblock 370 166 579 minecraft:oak_log
fill 370 166 580 370 169 580 minecraft:green_terracotta
setblock 370 166 584 minecraft:oak_log
fill 370 166 585 370 169 585 minecraft:green_terracotta
setblock 370 166 588 minecraft:green_terracotta
setblock 330 167 558 minecraft:oak_log
fill 330 167 559 330 170 559 minecraft:green_terracotta
setblock 330 167 563 minecraft:oak_log
fill 330 167 564 330 170 564 minecraft:green_terracotta
setblock 330 167 568 minecraft:oak_log
fill 330 167 569 330 170 569 minecraft:green_terracotta
setblock 330 167 573 minecraft:oak_log
fill 330 167 574 330 170 574 minecraft:green_terracotta
setblock 330 167 578 minecraft:oak_log
fill 330 167 579 330 170 579 minecraft:green_terracotta
setblock 330 167 583 minecraft:oak_log
fill 330 167 584 330 170 584 minecraft:green_terracotta
fill 330 167 586 330 168 586 minecraft:green_terracotta
setblock 330 167 597 minecraft:green_terracotta
setblock 330 167 598 minecraft:oak_log
fill 331 167 558 331 170 558 minecraft:green_terracotta
setblock 331 167 562 minecraft:oak_log
fill 331 167 563 331 170 563 minecraft:green_terracotta
setblock 331 167 567 minecraft:oak_log
fill 331 167 568 331 170 568 minecraft:green_terracotta
setblock 331 167 572 minecraft:oak_log
fill 331 167 573 331 170 573 minecraft:green_terracotta
setblock 331 167 577 minecraft:oak_log
fill 331 167 578 331 170 578 minecraft:green_terracotta
setblock 331 167 582 minecraft:oak_log
fill 331 167 583 331 170 583 minecraft:green_terracotta
fill 331 167 598 331 170 598 minecraft:green_terracotta
setblock 332 167 561 minecraft:oak_log
fill 332 167 562 332 170 562 minecraft:green_terracotta
fill 332 167 564 332 168 564 minecraft:green_terracotta
setblock 333 167 560 minecraft:oak_log
setblock 334 167 559 minecraft:oak_log
fill 334 167 560 334 170 560 minecraft:green_terracotta
setblock 335 167 558 minecraft:oak_log
fill 335 167 559 335 170 559 minecraft:green_terracotta
setblock 335 167 598 minecraft:oak_log
fill 336 167 558 339 167 558 minecraft:green_terracotta
fill 336 167 598 339 167 598 minecraft:green_terracotta
setblock 339 167 559 minecraft:oak_log
setblock 340 167 558 minecraft:oak_log
fill 340 167 559 340 170 559 minecraft:green_terracotta
setblock 340 167 598 minecraft:oak_log
fill 341 167 558 344 167 558 minecraft:green_terracotta
fill 341 167 598 344 167 598 minecraft:green_terracotta
fill 342 167 559 343 167 559 minecraft:green_terracotta
setblock 344 167 559 minecraft:oak_log
setblock 345 167 558 minecraft:oak_log
fill 345 167 559 345 170 559 minecraft:green_terracotta
setblock 345 167 598 minecraft:oak_log
fill 346 167 558 346 170 558 minecraft:green_terracotta
setblock 346 167 597 minecraft:oak_log
fill 346 167 598 346 170 598 minecraft:green_terracotta
fill 347 167 597 347 170 597 minecraft:green_terracotta
setblock 349 167 559 minecraft:oak_log
setblock 350 167 558 minecraft:oak_log
fill 350 167 559 350 169 560 minecraft:green_terracotta
setblock 350 167 598 minecraft:oak_log
fill 351 167 558 351 170 558 minecraft:green_terracotta
setblock 351 167 597 minecraft:oak_log
fill 351 167 598 351 170 598 minecraft:green_terracotta
setblock 352 167 596 minecraft:oak_log
fill 352 167 597 352 170 597 minecraft:green_terracotta
setblock 354 167 559 minecraft:oak_log
setblock 355 167 558 minecraft:oak_log
setblock 355 167 559 minecraft:green_terracotta
setblock 355 167 598 minecraft:oak_log
fill 356 167 558 356 170 558 minecraft:green_terracotta
setblock 356 167 597 minecraft:oak_log
fill 356 167 598 358 167 598 minecraft:green_terracotta
fill 366 167 558 366 170 558 minecraft:green_terracotta
fill 368 167 576 368 170 576 minecraft:green_terracotta
setblock 368 167 579 minecraft:green_terracotta
setblock 368 167 580 minecraft:oak_log
fill 368 167 581 368 170 581 minecraft:green_terracotta
fill 368 167 583 369 167 583 minecraft:green_terracotta
setblock 369 167 559 minecraft:oak_log
fill 369 167 560 369 167 563 minecraft:green_terracotta
fill 369 167 572 369 168 572 minecraft:green_terracotta
setblock 369 167 574 minecraft:oak_log
fill 369 167 575 369 170 575 minecraft:green_terracotta
setblock 369 167 579 minecraft:oak_log
fill 369 167 580 369 170 580 minecraft:green_terracotta
setblock 369 167 584 minecraft:oak_log
fill 369 167 585 369 169 586 minecraft:green_terracotta
setblock 370 167 558 minecraft:oak_log
fill 370 167 559 370 170 559 minecraft:green_terracotta
setblock 370 167 562 minecraft:green_terracotta
setblock 370 167 563 minecraft:oak_log
fill 370 167 564 370 170 564 minecraft:green_terracotta
setblock 370 167 568 minecraft:oak_log
fill 370 167 569 370 170 569 minecraft:green_terracotta
setblock 370 167 573 minecraft:oak_log
fill 370 167 574 370 170 574 minecraft:green_terracotta
setblock 370 167 578 minecraft:oak_log
fill 370 167 579 370 170 579 minecraft:green_terracotta
setblock 370 167 583 minecraft:oak_log
fill 370 167 584 370 170 584 minecraft:green_terracotta
setblock 370 167 588 minecraft:oak_log
setblock 370 167 598 minecraft:oak_log
fill 330 168 558 330 171 558 minecraft:green_terracotta
setblock 330 168 562 minecraft:oak_log
fill 330 168 563 330 171 563 minecraft:green_terracotta
setblock 330 168 567 minecraft:oak_log
fill 330 168 568 330 171 568 minecraft:green_terracotta
setblock 330 168 572 minecraft:oak_log
fill 330 168 573 330 171 573 minecraft:green_terracotta
setblock 330 168 577 minecraft:oak_log
fill 330 168 578 330 171 578 minecraft:green_terracotta
setblock 330 168 582 minecraft:oak_log
fill 330 168 583 330 171 583 minecraft:green_terracotta
setblock 330 168 587 minecraft:oak_log
setblock 330 168 597 minecraft:oak_log
fill 330 168 598 330 171 598 minecraft:green_terracotta
setblock 331 168 561 minecraft:oak_log
fill 331 168 562 331 171 562 minecraft:green_terracotta
setblock 331 168 566 minecraft:oak_log
fill 331 168 567 331 171 567 minecraft:green_terracotta
setblock 331 168 571 minecraft:oak_log
fill 331 168 572 331 171 572 minecraft:green_terracotta
setblock 331 168 576 minecraft:oak_log
fill 331 168 577 331 171 577 minecraft:green_terracotta
setblock 331 168 581 minecraft:oak_log
fill 331 168 582 331 171 582 minecraft:green_terracotta
fill 331 168 584 331 169 584 minecraft:green_terracotta
setblock 332 168 560 minecraft:oak_log
fill 332 168 561 333 170 561 minecraft:green_terracotta
setblock 332 168 565 minecraft:oak_log
setblock 332 168 568 minecraft:light[level=14]
setblock 332 168 576 minecraft:light[level=14]
setblock 332 168 584 minecraft:light[level=14]
setblock 332 168 592 minecraft:light[level=14]
setblock 333 168 559 minecraft:oak_log
fill 333 168 560 333 171 560 minecraft:green_terracotta
setblock 334 168 558 minecraft:oak_log
fill 334 168 559 334 171 559 minecraft:green_terracotta
setblock 334 168 598 minecraft:oak_log
fill 335 168 558 338 168 558 minecraft:green_terracotta
fill 335 168 598 338 168 598 minecraft:green_terracotta
setblock 337 168 560 minecraft:oak_log
setblock 338 168 559 minecraft:oak_log
setblock 339 168 558 minecraft:oak_log
fill 339 168 559 339 171 559 minecraft:green_terracotta
setblock 339 168 598 minecraft:oak_log
fill 340 168 558 343 168 558 minecraft:green_terracotta
setblock 340 168 560 minecraft:light[level=14]
setblock 340 168 568 minecraft:light[level=14]
setblock 340 168 576 minecraft:light[level=14]
setblock 340 168 584 minecraft:light[level=14]
setblock 340 168 592 minecraft:light[level=14]
fill 340 168 598 343 168 598 minecraft:green_terracotta
setblock 342 168 559 minecraft:green_terracotta
setblock 343 168 559 minecraft:oak_log
setblock 344 168 558 minecraft:oak_log
fill 344 168 559 344 171 559 minecraft:green_terracotta
setblock 344 168 598 minecraft:oak_log
fill 345 168 558 345 171 558 minecraft:green_terracotta
setblock 345 168 597 minecraft:oak_log
fill 345 168 598 345 171 598 minecraft:green_terracotta
fill 346 168 597 346 171 597 minecraft:green_terracotta
setblock 347 168 560 minecraft:oak_log
setblock 348 168 559 minecraft:oak_log
fill 348 168 560 349 170 560 minecraft:green_terracotta
setblock 348 168 568 minecraft:light[level=14]
setblock 348 168 576 minecraft:light[level=14]
setblock 348 168 584 minecraft:light[level=14]
setblock 348 168 592 minecraft:light[level=14]
setblock 349 168 558 minecraft:oak_log
fill 349 168 559 349 171 559 minecraft:green_terracotta
fill 349 168 596 349 169 596 minecraft:green_terracotta
setblock 349 168 598 minecraft:oak_log
fill 350 168 558 350 171 558 minecraft:green_terracotta
fill 350 168 578 350 186 578 minecraft:oak_log
setblock 350 168 597 minecraft:oak_log
fill 350 168 598 350 171 598 minecraft:green_terracotta
setblock 351 168 560 minecraft:green_terracotta
setblock 351 168 596 minecraft:oak_log
fill 351 168 597 351 171 597 minecraft:green_terracotta
setblock 353 168 559 minecraft:oak_log
setblock 354 168 558 minecraft:oak_log
fill 354 168 559 354 171 559 minecraft:green_terracotta
setblock 354 168 598 minecraft:oak_log
fill 355 168 558 355 171 558 minecraft:green_terracotta
setblock 355 168 597 minecraft:oak_log
fill 355 168 598 357 169 598 minecraft:green_terracotta
setblock 356 168 560 minecraft:light[level=14]
setblock 356 168 568 minecraft:light[level=14]
setblock 356 168 576 minecraft:light[level=14]
setblock 356 168 584 minecraft:light[level=14]
setblock 356 168 592 minecraft:light[level=14]
setblock 362 168 558 minecraft:oak_leaves[persistent=true]
setblock 363 168 598 minecraft:oak_leaves[persistent=true]
setblock 364 168 560 minecraft:light[level=14]
setblock 364 168 568 minecraft:light[level=14]
setblock 364 168 576 minecraft:light[level=14]
setblock 364 168 584 minecraft:light[level=14]
setblock 364 168 592 minecraft:light[level=14]
fill 365 168 558 365 171 558 minecraft:green_terracotta
setblock 367 168 559 minecraft:green_terracotta
setblock 368 168 559 minecraft:oak_log
setblock 368 168 579 minecraft:oak_log
fill 368 168 580 368 171 580 minecraft:green_terracotta
setblock 368 168 583 minecraft:green_terracotta
setblock 368 168 584 minecraft:oak_log
setblock 369 168 558 minecraft:oak_log
fill 369 168 559 369 168 562 minecraft:green_terracotta
setblock 369 168 563 minecraft:oak_log
fill 369 168 564 369 168 567 minecraft:green_terracotta
fill 369 168 570 369 169 571 minecraft:green_terracotta
setblock 369 168 573 minecraft:oak_log
fill 369 168 574 369 171 574 minecraft:green_terracotta
setblock 369 168 578 minecraft:oak_log
fill 369 168 579 369 171 579 minecraft:green_terracotta
setblock 369 168 583 minecraft:oak_log
fill 369 168 584 369 171 584 minecraft:green_terracotta
setblock 369 168 587 minecraft:green_terracotta
setblock 369 168 598 minecraft:oak_log
fill 370 168 558 370 171 558 minecraft:green_terracotta
setblock 370 168 562 minecraft:oak_log
fill 370 168 563 370 171 563 minecraft:green_terracotta
setblock 370 168 566 minecraft:green_terracotta
setblock 370 168 567 minecraft:oak_log
fill 370 168 568 370 171 568 minecraft:green_terracotta
setblock 370 168 572 minecraft:oak_log
fill 370 168 573 370 171 573 minecraft:green_terracotta
setblock 370 168 577 minecraft:oak_log
fill 370 168 578 370 171 578 minecraft:green_terracotta
setblock 370 168 582 minecraft:oak_log
fill 370 168 583 370 171 583 minecraft:green_terracotta
setblock 370 168 587 minecraft:oak_log
fill 370 168 588 370 170 589 minecraft:green_terracotta
setblock 370 168 594 minecraft:oak_leaves[persistent=true]
setblock 370 168 597 minecraft:oak_log
fill 370 168 598 370 171 598 minecraft:green_terracotta
setblock 330 169 561 minecraft:oak_log
fill 330 169 562 330 172 562 minecraft:green_terracotta
setblock 330 169 566 minecraft:oak_log
fill 330 169 567 330 172 567 minecraft:green_terracotta
setblock 330 169 571 minecraft:oak_log
fill 330 169 572 330 172 572 minecraft:green_terracotta
setblock 330 169 576 minecraft:oak_log
fill 330 169 577 330 172 577 minecraft:green_terracotta
setblock 330 169 581 minecraft:oak_log
fill 330 169 582 330 172 582 minecraft:green_terracotta
setblock 330 169 586 minecraft:oak_log
fill 330 169 587 330 171 588 minecraft:green_terracotta
setblock 330 169 593 minecraft:oak_leaves[persistent=true]
setblock 330 169 595 minecraft:green_terracotta
setblock 330 169 596 minecraft:oak_log
fill 330 169 597 330 172 597 minecraft:green_terracotta
setblock 331 169 560 minecraft:oak_log
fill 331 169 561 331 172 561 minecraft:green_terracotta
setblock 331 169 565 minecraft:oak_log
fill 331 169 566 332 171 566 minecraft:green_terracotta
setblock 331 169 570 minecraft:oak_log
fill 331 169 571 331 172 571 minecraft:green_terracotta
setblock 331 169 575 minecraft:oak_log
fill 331 169 576 331 171 576 minecraft:green_terracotta
setblock 331 169 580 minecraft:oak_log
fill 331 169 581 331 172 581 minecraft:green_terracotta
setblock 331 169 585 minecraft:oak_log
setblock 332 169 559 minecraft:oak_log
fill 332 169 560 332 172 560 minecraft:green_terracotta
setblock 332 169 564 minecraft:oak_log
fill 332 169 565 332 172 565 minecraft:green_terracotta
setblock 333 169 558 minecraft:oak_log
fill 333 169 559 333 172 559 minecraft:green_terracotta
setblock 333 169 562 minecraft:green_terracotta
setblock 333 169 563 minecraft:oak_log
setblock 333 169 598 minecraft:oak_log
fill 334 169 558 337 169 558 minecraft:green_terracotta
setblock 334 169 561 minecraft:green_terracotta
fill 334 169 598 337 169 598 minecraft:green_terracotta
setblock 336 169 560 minecraft:oak_log
setblock 337 169 559 minecraft:oak_log
fill 337 169 560 337 171 560 minecraft:green_terracotta
setblock 338 169 558 minecraft:oak_log
fill 338 169 559 338 172 559 minecraft:green_terracotta
setblock 338 169 598 minecraft:oak_log
fill 339 169 558 342 169 558 minecraft:green_terracotta
fill 339 169 598 342 169 598 minecraft:green_terracotta
setblock 342 169 559 minecraft:oak_log
setblock 343 169 558 minecraft:oak_log
fill 343 169 559 343 172 559 minecraft:green_terracotta
setblock 343 169 598 minecraft:oak_log
fill 344 169 558 344 172 558 minecraft:green_terracotta
fill 344 169 598 344 172 598 minecraft:green_terracotta
fill 345 169 597 345 172 597 minecraft:green_terracotta
setblock 346 169 560 minecraft:oak_log
setblock 347 169 559 minecraft:oak_log
fill 347 169 560 347 172 560 minecraft:green_terracotta
setblock 348 169 558 minecraft:oak_log
fill 348 169 559 348 172 559 minecraft:green_terracotta
setblock 348 169 598 minecraft:oak_log
fill 349 169 558 349 172 558 minecraft:green_terracotta
setblock 349 169 597 minecraft:oak_log
fill 349 169 598 349 172 598 minecraft:green_terracotta
setblock 350 169 596 minecraft:oak_log
fill 350 169 597 350 172 597 minecraft:green_terracotta
setblock 351 169 560 minecraft:oak_log
fill 351 169 596 351 170 596 minecraft:green_terracotta
setblock 352 169 559 minecraft:oak_log
setblock 353 169 558 minecraft:oak_log
fill 353 169 559 353 172 559 minecraft:green_terracotta
setblock 353 169 598 minecraft:oak_log
fill 354 169 558 354 172 558 minecraft:green_terracotta
setblock 354 169 597 minecraft:oak_log
fill 354 169 598 354 172 598 minecraft:green_terracotta
fill 364 169 558 364 172 558 minecraft:green_terracotta
setblock 366 169 559 minecraft:green_terracotta
setblock 367 169 559 minecraft:oak_log
fill 367 169 580 367 170 582 minecraft:green_terracotta
setblock 367 169 598 minecraft:green_terracotta
setblock 368 169 558 minecraft:oak_log
fill 368 169 559 368 169 562 minecraft:green_terracotta
setblock 368 169 563 minecraft:oak_log
fill 368 169 575 368 171 575 minecraft:green_terracotta
setblock 368 169 578 minecraft:oak_log
fill 368 169 579 368 172 579 minecraft:green_terracotta
setblock 368 169 583 minecraft:oak_log
fill 368 169 584 368 171 585 minecraft:green_terracotta
setblock 368 169 598 minecraft:oak_log
fill 369 169 558 369 169 561 minecraft:green_terracotta
setblock 369 169 562 minecraft:oak_log
fill 369 169 563 369 169 566 minecraft:green_terracotta
setblock 369 169 567 minecraft:oak_log
fill 369 169 568 369 171 569 minecraft:green_terracotta
setblock 369 169 572 minecraft:oak_log
fill 369 169 573 369 172 573 minecraft:green_terracotta
setblock 369 169 577 minecraft:oak_log
fill 369 169 578 369 172 578 minecraft:green_terracotta
setblock 369 169 582 minecraft:oak_log
fill 369 169 583 369 172 583 minecraft:green_terracotta
setblock 369 169 587 minecraft:oak_log
fill 369 169 588 369 172 588 minecraft:green_terracotta
fill 369 169 598 369 172 598 minecraft:green_terracotta
setblock 370 169 561 minecraft:oak_log
fill 370 169 562 370 172 562 minecraft:green_terracotta
setblock 370 169 566 minecraft:oak_log
fill 370 169 567 370 172 567 minecraft:green_terracotta
setblock 370 169 571 minecraft:oak_log
fill 370 169 572 370 172 572 minecraft:green_terracotta
setblock 370 169 576 minecraft:oak_log
fill 370 169 577 370 172 577 minecraft:green_terracotta
setblock 370 169 581 minecraft:oak_log
fill 370 169 582 370 172 582 minecraft:green_terracotta
setblock 370 169 586 minecraft:oak_log
fill 370 169 587 370 172 587 minecraft:green_terracotta
setblock 370 169 590 minecraft:green_terracotta
setblock 370 169 596 minecraft:oak_log
fill 370 169 597 370 172 597 minecraft:green_terracotta
setblock 330 170 560 minecraft:oak_log
fill 330 170 561 330 173 561 minecraft:green_terracotta
setblock 330 170 565 minecraft:oak_log
fill 330 170 566 330 173 566 minecraft:green_terracotta
setblock 330 170 570 minecraft:oak_log
fill 330 170 571 330 173 571 minecraft:green_terracotta
setblock 330 170 575 minecraft:oak_log
fill 330 170 576 330 173 576 minecraft:green_terracotta
setblock 330 170 580 minecraft:oak_log
fill 330 170 581 330 173 581 minecraft:green_terracotta
setblock 330 170 585 minecraft:oak_log
fill 330 170 586 331 172 586 minecraft:green_terracotta
setblock 330 170 589 minecraft:green_terracotta
setblock 330 170 590 minecraft:oak_log
setblock 330 170 595 minecraft:oak_log
fill 330 170 596 330 173 596 minecraft:green_terracotta
setblock 331 170 559 minecraft:oak_log
fill 331 170 560 331 173 560 minecraft:green_terracotta
setblock 331 170 564 minecraft:oak_log
fill 331 170 565 331 173 565 minecraft:green_terracotta
setblock 331 170 569 minecraft:oak_log
fill 331 170 570 331 173 570 minecraft:green_terracotta
setblock 331 170 574 minecraft:oak_log
fill 331 170 575 331 171 575 minecraft:green_terracotta
setblock 331 170 579 minecraft:oak_log
fill 331 170 580 331 173 580 minecraft:green_terracotta
setblock 331 170 584 minecraft:oak_log
fill 331 170 585 331 173 585 minecraft:green_terracotta
setblock 332 170 558 minecraft:oak_log
fill 332 170 559 332 173 559 minecraft:green_terracotta
setblock 332 170 563 minecraft:oak_log
fill 332 170 564 332 173 564 minecraft:green_terracotta
setblock 332 170 567 minecraft:green_terracotta
setblock 332 170 598 minecraft:oak_log
fill 333 170 558 336 170 558 minecraft:green_terracotta
setblock 333 170 562 minecraft:oak_log
fill 333 170 563 333 173 563 minecraft:green_terracotta
fill 333 170 598 336 170 598 minecraft:green_terracotta
setblock 334 170 561 minecraft:oak_log
setblock 335 170 560 minecraft:oak_log
setblock 336 170 559 minecraft:oak_log
fill 336 170 560 336 172 560 minecraft:green_terracotta
setblock 337 170 558 minecraft:oak_log
fill 337 170 559 337 173 559 minecraft:green_terracotta
setblock 337 170 598 minecraft:oak_log
fill 338 170 558 341 170 558 minecraft:green_terracotta
fill 338 170 598 341 170 598 minecraft:green_terracotta
setblock 341 170 559 minecraft:oak_log
setblock 342 170 558 minecraft:oak_log
fill 342 170 559 342 173 559 minecraft:green_terracotta
setblock 342 170 598 minecraft:oak_log
fill 343 170 558 343 173 558 minecraft:green_terracotta
fill 343 170 598 343 173 598 minecraft:green_terracotta
setblock 344 170 560 minecraft:green_terracotta
fill 344 170 597 344 173 597 minecraft:green_terracotta
setblock 345 170 560 minecraft:oak_log
setblock 346 170 559 minecraft:oak_log
fill 346 170 560 346 173 560 minecraft:green_terracotta
setblock 347 170 558 minecraft:oak_log
fill 347 170 559 347 173 559 minecraft:green_terracotta
setblock 347 170 598 minecraft:oak_log
fill 348 170 558 348 173 558 minecraft:green_terracotta
setblock 348 170 596 minecraft:green_terracotta
setblock 348 170 597 minecraft:oak_log
fill 348 170 598 348 173 598 minecraft:green_terracotta
setblock 349 170 596 minecraft:oak_log
fill 349 170 597 349 173 597 minecraft:green_terracotta
setblock 350 170 559 minecraft:green_terracotta
setblock 350 170 560 minecraft:oak_log
fill 350 170 596 350 172 596 minecraft:green_terracotta
setblock 351 170 559 minecraft:oak_log
fill 351 170 560 352 170 560 minecraft:green_terracotta
setblock 352 170 558 minecraft:oak_log
fill 352 170 559 352 173 559 minecraft:green_terracotta
setblock 352 170 598 minecraft:oak_log
fill 353 170 558 353 173 558 minecraft:green_terracotta
setblock 353 170 597 minecraft:oak_log
fill 353 170 598 353 173 598 minecraft:green_terracotta
setblock 354 170 597 minecraft:green_terracotta
fill 355 170 598 356 170 598 minecraft:green_terracotta
setblock 366 170 559 minecraft:oak_log
setblock 367 170 558 minecraft:oak_log
fill 367 170 559 369 170 560 minecraft:green_terracotta
fill 367 170 579 367 172 579 minecraft:green_terracotta
setblock 367 170 583 minecraft:oak_log
fill 367 170 584 367 173 584 minecraft:green_terracotta
setblock 367 170 598 minecraft:oak_log
fill 368 170 558 369 172 558 minecraft:green_terracotta
setblock 368 170 561 minecraft:green_terracotta
setblock 368 170 562 minecraft:oak_log
fill 368 170 563 368 170 566 minecraft:green_terracotta
setblock 368 170 567 minecraft:oak_log
setblock 368 170 577 minecraft:oak_log
fill 368 170 578 368 173 578 minecraft:green_terracotta
setblock 368 170 582 minecraft:oak_log
fill 368 170 583 368 173 583 minecraft:green_terracotta
setblock 368 170 586 minecraft:green_terracotta
fill 368 170 598 368 173 598 minecraft:green_terracotta
setblock 369 170 561 minecraft:oak_log
fill 369 170 562 369 170 565 minecraft:green_terracotta
setblock 369 170 566 minecraft:oak_log
fill 369 170 567 369 173 567 minecraft:green_terracotta
setblock 369 170 570 minecraft:green_terracotta
setblock 369 170 571 minecraft:oak_log
fill 369 170 572 369 173 572 minecraft:green_terracotta
setblock 369 170 576 minecraft:oak_log
fill 369 170 577 369 173 577 minecraft:green_terracotta
setblock 369 170 581 minecraft:oak_log
fill 369 170 582 369 173 582 minecraft:green_terracotta
setblock 369 170 585 minecraft:green_terracotta
setblock 369 170 586 minecraft:oak_log
fill 369 170 587 369 173 587 minecraft:green_terracotta
fill 369 170 589 369 171 589 minecraft:green_terracotta
setblock 370 170 560 minecraft:oak_log
fill 370 170 561 370 173 561 minecraft:green_terracotta
setblock 370 170 565 minecraft:oak_log
fill 370 170 566 370 173 566 minecraft:green_terracotta
setblock 370 170 570 minecraft:oak_log
fill 370 170 571 370 173 571 minecraft:green_terracotta
setblock 370 170 575 minecraft:oak_log
fill 370 170 576 370 173 576 minecraft:green_terracotta
setblock 370 170 580 minecraft:oak_log
fill 370 170 581 370 173 581 minecraft:green_terracotta
setblock 370 170 585 minecraft:oak_log
fill 370 170 586 370 173 586 minecraft:green_terracotta
setblock 370 170 590 minecraft:oak_log
fill 370 170 591 370 172 592 minecraft:green_terracotta
fill 370 170 596 370 172 596 minecraft:green_terracotta
setblock 330 171 559 minecraft:oak_log
fill 330 171 560 330 174 560 minecraft:green_terracotta
setblock 330 171 564 minecraft:oak_log
fill 330 171 565 330 174 565 minecraft:green_terracotta
setblock 330 171 569 minecraft:oak_log
fill 330 171 570 330 174 570 minecraft:green_terracotta
setblock 330 171 574 minecraft:oak_log
fill 330 171 575 330 174 575 minecraft:green_terracotta
setblock 330 171 579 minecraft:oak_log
fill 330 171 580 330 174 580 minecraft:green_terracotta
setblock 330 171 584 minecraft:oak_log
fill 330 171 585 330 174 585 minecraft:green_terracotta
setblock 330 171 589 minecraft:oak_log
fill 330 171 590 330 171 593 minecraft:green_terracotta
setblock 330 171 594 minecraft:oak_log
fill 330 171 595 330 174 595 minecraft:green_terracotta
setblock 331 171 558 minecraft:oak_log
fill 331 171 559 331 174 559 minecraft:green_terracotta
setblock 331 171 563 minecraft:oak_log
fill 331 171 564 331 174 564 minecraft:green_terracotta
setblock 331 171 568 minecraft:oak_log
fill 331 171 569 331 174 569 minecraft:green_terracotta
setblock 331 171 573 minecraft:oak_log
setblock 331 171 574 minecraft:green_terracotta
setblock 331 171 578 minecraft:oak_log
fill 331 171 579 331 172 579 minecraft:green_terracotta
setblock 331 171 583 minecraft:oak_log
fill 331 171 584 331 174 584 minecraft:green_terracotta
setblock 331 171 587 minecraft:green_terracotta
setblock 331 171 598 minecraft:oak_log
fill 332 171 558 335 171 558 minecraft:green_terracotta
setblock 332 171 561 minecraft:green_terracotta
setblock 332 171 562 minecraft:oak_log
fill 332 171 563 332 174 563 minecraft:green_terracotta
setblock 332 171 567 minecraft:oak_log
fill 332 171 568 332 173 568 minecraft:green_terracotta
fill 332 171 598 335 171 598 minecraft:green_terracotta
setblock 333 171 561 minecraft:oak_log
fill 333 171 562 333 173 562 minecraft:green_terracotta
fill 333 171 564 333 172 564 minecraft:green_terracotta
setblock 334 171 560 minecraft:oak_log
fill 334 171 561 334 172 561 minecraft:green_terracotta
setblock 335 171 559 minecraft:oak_log
fill 335 171 560 335 173 560 minecraft:green_terracotta
setblock 336 171 558 minecraft:oak_log
fill 336 171 559 336 174 559 minecraft:green_terracotta
setblock 336 171 598 minecraft:oak_log
fill 337 171 558 340 171 558 minecraft:green_terracotta
fill 337 171 598 340 171 598 minecraft:green_terracotta
setblock 340 171 559 minecraft:oak_log
setblock 341 171 558 minecraft:oak_log
fill 341 171 559 341 174 559 minecraft:green_terracotta
setblock 341 171 598 minecraft:oak_log
fill 342 171 558 342 174 558 minecraft:green_terracotta
fill 342 171 598 342 174 598 minecraft:green_terracotta
setblock 343 171 560 minecraft:green_terracotta
fill 343 171 597 343 174 597 minecraft:green_terracotta
setblock 344 171 560 minecraft:oak_log
setblock 345 171 559 minecraft:oak_log
fill 345 171 560 345 174 560 minecraft:green_terracotta
fill 345 171 565 345 172 565 minecraft:oak_leaves[persistent=true]
setblock 346 171 558 minecraft:oak_log
fill 346 171 559 346 174 559 minecraft:green_terracotta
setblock 346 171 598 minecraft:oak_log
fill 347 171 558 347 174 558 minecraft:green_terracotta
setblock 347 171 596 minecraft:green_terracotta
setblock 347 171 597 minecraft:oak_log
fill 347 171 598 347 174 598 minecraft:green_terracotta
setblock 348 171 560 minecraft:green_terracotta
setblock 348 171 596 minecraft:oak_log
fill 348 171 597 348 174 597 minecraft:green_terracotta
setblock 349 171 560 minecraft:oak_log
fill 349 171 596 349 173 596 minecraft:green_terracotta
setblock 350 171 559 minecraft:oak_log
fill 350 171 560 351 172 560 minecraft:green_terracotta
setblock 351 171 558 minecraft:oak_log
fill 351 171 559 351 174 559 minecraft:green_terracotta
setblock 351 171 598 minecraft:oak_log
fill 352 171 558 352 174 558 minecraft:green_terracotta
setblock 352 171 597 minecraft:oak_log
fill 352 171 598 352 174 598 minecraft:green_terracotta
setblock 353 171 597 minecraft:green_terracotta
setblock 355 171 598 minecraft:green_terracotta
setblock 356 171 558 minecraft:oak_log
setblock 356 171 598 minecraft:oak_log
fill 363 171 558 363 173 558 minecraft:green_terracotta
setblock 365 171 559 minecraft:oak_log
setblock 366 171 558 minecraft:oak_log
fill 366 171 559 368 171 560 minecraft:green_terracotta
setblock 366 171 598 minecraft:oak_log
fill 367 171 558 367 174 558 minecraft:green_terracotta
fill 367 171 580 367 171 581 minecraft:green_terracotta
setblock 367 171 582 minecraft:oak_log
fill 367 171 583 367 174 583 minecraft:green_terracotta
fill 367 171 585 367 172 585 minecraft:green_terracotta
fill 367 171 598 367 174 598 minecraft:green_terracotta
setblock 368 171 561 minecraft:oak_log
fill 368 171 562 368 171 565 minecraft:green_terracotta
setblock 368 171 566 minecraft:oak_log
fill 368 171 567 368 171 570 minecraft:green_terracotta
fill 368 171 573 368 172 574 minecraft:green_terracotta
setblock 368 171 576 minecraft:oak_log
fill 368 171 577 368 174 577 minecraft:green_terracotta
setblock 368 171 581 minecraft:oak_log
fill 368 171 582 368 174 582 minecraft:green_terracotta
setblock 368 171 586 minecraft:oak_log
fill 368 171 587 368 174 587 minecraft:green_terracotta
setblock 369 171 559 minecraft:green_terracotta
setblock 369 171 560 minecraft:oak_log
fill 369 171 561 369 171 564 minecraft:green_terracotta
setblock 369 171 565 minecraft:oak_log
fill 369 171 566 369 174 566 minecraft:green_terracotta
setblock 369 171 570 minecraft:oak_log
fill 369 171 571 369 174 571 minecraft:green_terracotta
setblock 369 171 575 minecraft:oak_log
fill 369 171 576 369 174 576 minecraft:green_terracotta
setblock 369 171 580 minecraft:oak_log
fill 369 171 581 369 174 581 minecraft:green_terracotta
setblock 369 171 585 minecraft:oak_log
fill 369 171 586 369 174 586 minecraft:green_terracotta
setblock 369 171 590 minecraft:oak_log
setblock 370 171 559 minecraft:oak_log
fill 370 171 560 370 174 560 minecraft:green_terracotta
setblock 370 171 564 minecraft:oak_log
fill 370 171 565 370 174 565 minecraft:green_terracotta
setblock 370 171 569 minecraft:oak_log
fill 370 171 570 370 174 570 minecraft:green_terracotta
setblock 370 171 574 minecraft:oak_log
fill 370 171 575 370 174 575 minecraft:green_terracotta
setblock 370 171 579 minecraft:oak_log
fill 370 171 580 370 174 580 minecraft:green_terracotta
setblock 370 171 584 minecraft:oak_log
fill 370 171 585 370 174 585 minecraft:green_terracotta
setblock 370 171 588 minecraft:green_terracotta
setblock 370 171 589 minecraft:oak_log
fill 370 171 590 370 174 590 minecraft:green_terracotta
setblock 370 171 593 minecraft:green_terracotta
setblock 370 171 595 minecraft:oak_leaves[persistent=true]
setblock 330 172 558 minecraft:oak_log
fill 330 172 559 330 175 559 minecraft:green_terracotta
setblock 330 172 563 minecraft:oak_log
fill 330 172 564 330 175 564 minecraft:green_terracotta
setblock 330 172 568 minecraft:oak_log
fill 330 172 569 330 175 569 minecraft:green_terracotta
setblock 330 172 573 minecraft:oak_log
fill 330 172 574 330 175 574 minecraft:green_terracotta
setblock 330 172 578 minecraft:oak_log
fill 330 172 579 330 175 579 minecraft:green_terracotta
setblock 330 172 583 minecraft:oak_log
fill 330 172 584 330 175 584 minecraft:green_terracotta
setblock 330 172 587 minecraft:green_terracotta
setblock 330 172 588 minecraft:oak_log
fill 330 172 589 330 172 592 minecraft:green_terracotta
setblock 330 172 593 minecraft:oak_log
fill 330 172 594 330 175 594 minecraft:green_terracotta
setblock 330 172 598 minecraft:oak_log
fill 331 172 558 334 172 558 minecraft:green_terracotta
setblock 331 172 562 minecraft:oak_log
fill 331 172 563 331 175 563 minecraft:green_terracotta
setblock 331 172 566 minecraft:green_terracotta
setblock 331 172 567 minecraft:oak_log
fill 331 172 568 331 175 568 minecraft:green_terracotta
setblock 331 172 572 minecraft:oak_log
setblock 331 172 577 minecraft:oak_log
setblock 331 172 578 minecraft:green_terracotta
setblock 331 172 582 minecraft:oak_log
fill 331 172 583 331 174 583 minecraft:green_terracotta
setblock 331 172 587 minecraft:oak_log
fill 331 172 588 331 175 588 minecraft:green_terracotta
fill 331 172 598 334 172 598 minecraft:green_terracotta
setblock 332 172 561 minecraft:oak_log
fill 332 172 562 332 175 562 minecraft:green_terracotta
setblock 332 172 566 minecraft:oak_log
fill 332 172 567 332 175 567 minecraft:green_terracotta
setblock 333 172 560 minecraft:oak_log
fill 333 172 561 333 173 561 minecraft:green_terracotta
setblock 334 172 559 minecraft:oak_log
fill 334 172 560 334 174 560 minecraft:green_terracotta
setblock 335 172 558 minecraft:oak_log
fill 335 172 559 335 175 559 minecraft:green_terracotta
setblock 335 172 598 minecraft:oak_log
fill 336 172 558 339 172 558 minecraft:green_terracotta
fill 336 172 598 339 172 598 minecraft:green_terracotta
setblock 339 172 559 minecraft:oak_log
setblock 340 172 558 minecraft:oak_log
fill 340 172 559 340 174 559 minecraft:green_terracotta
setblock 340 172 598 minecraft:oak_log
fill 341 172 558 341 175 558 minecraft:green_terracotta
fill 341 172 598 341 175 598 minecraft:green_terracotta
setblock 343 172 560 minecraft:oak_log
setblock 344 172 559 minecraft:oak_log
fill 344 172 560 344 174 560 minecraft:green_terracotta
setblock 345 172 558 minecraft:oak_log
fill 345 172 559 345 175 559 minecraft:green_terracotta
setblock 345 172 598 minecraft:oak_log
fill 346 172 558 346 175 558 minecraft:green_terracotta
setblock 346 172 597 minecraft:oak_log
fill 346 172 598 346 175 598 minecraft:green_terracotta
setblock 347 172 596 minecraft:oak_log
fill 347 172 597 347 175 597 minecraft:green_terracotta
setblock 348 172 560 minecraft:oak_log
fill 348 172 596 348 174 596 minecraft:green_terracotta
setblock 349 172 559 minecraft:oak_log
fill 349 172 560 349 173 560 minecraft:green_terracotta
setblock 350 172 558 minecraft:oak_log
fill 350 172 559 350 174 559 minecraft:green_terracotta
setblock 350 172 598 minecraft:oak_log
fill 351 172 558 351 175 558 minecraft:green_terracotta
setblock 351 172 597 minecraft:oak_log
fill 351 172 598 351 175 598 minecraft:green_terracotta
fill 352 172 597 352 173 597 minecraft:green_terracotta
setblock 355 172 558 minecraft:oak_log
setblock 355 172 598 minecraft:oak_log
setblock 357 172 558 minecraft:oak_leaves[persistent=true]
setblock 362 172 598 minecraft:oak_leaves[persistent=true]
setblock 364 172 559 minecraft:oak_log
setblock 365 172 558 minecraft:oak_log
fill 365 172 559 368 172 559 minecraft:green_terracotta
fill 366 172 558 366 175 558 minecraft:green_terracotta
fill 366 172 560 367 172 560 minecraft:green_terracotta
fill 366 172 598 366 173 598 minecraft:green_terracotta
fill 367 172 562 367 172 565 minecraft:green_terracotta
setblock 367 172 566 minecraft:oak_log
setblock 367 172 580 minecraft:green_terracotta
setblock 367 172 581 minecraft:oak_log
fill 367 172 582 367 174 582 minecraft:green_terracotta
setblock 367 172 586 minecraft:oak_log
setblock 368 172 560 minecraft:oak_log
fill 368 172 561 368 172 564 minecraft:green_terracotta
setblock 368 172 565 minecraft:oak_log
fill 368 172 566 368 172 569 minecraft:green_terracotta
setblock 368 172 570 minecraft:oak_log
fill 368 172 571 368 174 572 minecraft:green_terracotta
setblock 368 172 575 minecraft:oak_log
fill 368 172 576 368 174 576 minecraft:green_terracotta
setblock 368 172 580 minecraft:oak_log
fill 368 172 581 368 175 581 minecraft:green_terracotta
setblock 368 172 584 minecraft:green_terracotta
setblock 368 172 585 minecraft:oak_log
fill 368 172 586 368 175 586 minecraft:green_terracotta
fill 368 172 588 368 173 588 minecraft:green_terracotta
setblock 369 172 559 minecraft:oak_log
fill 369 172 560 369 172 563 minecraft:green_terracotta
setblock 369 172 564 minecraft:oak_log
fill 369 172 565 369 175 565 minecraft:green_terracotta
setblock 369 172 568 minecraft:green_terracotta
setblock 369 172 569 minecraft:oak_log
fill 369 172 570 369 175 570 minecraft:green_terracotta
setblock 369 172 574 minecraft:oak_log
fill 369 172 575 369 175 575 minecraft:green_terracotta
setblock 369 172 579 minecraft:oak_log
fill 369 172 580 369 175 580 minecraft:green_terracotta
setblock 369 172 584 minecraft:oak_log
fill 369 172 585 369 175 585 minecraft:green_terracotta
setblock 369 172 589 minecraft:oak_log
fill 369 172 590 369 175 590 minecraft:green_terracotta
setblock 370 172 558 minecraft:oak_log
fill 370 172 559 370 175 559 minecraft:green_terracotta
setblock 370 172 563 minecraft:oak_log
fill 370 172 564 370 175 564 minecraft:green_terracotta
setblock 370 172 568 minecraft:oak_log
fill 370 172 569 370 175 569 minecraft:green_terracotta
setblock 370 172 573 minecraft:oak_log
fill 370 172 574 370 175 574 minecraft:green_terracotta
setblock 370 172 578 minecraft:oak_log
fill 370 172 579 370 175 579 minecraft:green_terracotta
setblock 370 172 583 minecraft:oak_log
fill 370 172 584 370 175 584 minecraft:green_terracotta
setblock 370 172 588 minecraft:oak_log
fill 370 172 589 370 175 589 minecraft:green_terracotta
setblock 370 172 593 minecraft:oak_log
setblock 370 172 598 minecraft:oak_log
setblock 329 173 559 minecraft:green_terracotta
fill 329 173 560 329 176 560 minecraft:brown_terracotta
setblock 329 173 574 minecraft:brown_terracotta
setblock 329 173 575 minecraft:green_terracotta
fill 329 173 576 329 176 577 minecraft:brown_terracotta
fill 329 173 578 330 173 578 minecraft:green_terracotta
fill 329 173 579 329 174 581 minecraft:brown_terracotta
fill 329 173 586 330 173 586 minecraft:green_terracotta
fill 329 173 588 330 173 588 minecraft:green_terracotta
fill 329 173 589 329 177 589 minecraft:brown_terracotta
fill 329 173 590 330 173 590 minecraft:green_terracotta
fill 329 173 591 329 176 591 minecraft:brown_terracotta
setblock 329 173 592 minecraft:green_terracotta
fill 329 173 593 329 176 593 minecraft:brown_terracotta
fill 329 173 595 329 176 595 minecraft:brown_terracotta
setblock 329 173 596 minecraft:green_terracotta
fill 329 173 597 329 176 597 minecraft:brown_terracotta
fill 329 173 598 329 173 599 minecraft:green_terracotta
fill 330 173 557 330 176 557 minecraft:brown_terracotta
fill 330 173 558 333 173 558 minecraft:green_terracotta
setblock 330 173 562 minecraft:oak_log
fill 330 173 563 330 176 563 minecraft:green_terracotta
setblock 330 173 567 minecraft:oak_log
fill 330 173 568 330 176 568 minecraft:green_terracotta
setblock 330 173 572 minecraft:oak_log
fill 330 173 573 330 176 573 minecraft:green_terracotta
setblock 330 173 577 minecraft:oak_log
setblock 330 173 582 minecraft:oak_log
fill 330 173 583 330 176 583 minecraft:green_terracotta
setblock 330 173 587 minecraft:oak_log
fill 330 173 589 331 174 589 minecraft:green_terracotta
setblock 330 173 591 minecraft:green_terracotta
setblock 330 173 592 minecraft:oak_log
fill 330 173 593 330 176 593 minecraft:green_terracotta
setblock 330 173 597 minecraft:oak_log
fill 330 173 598 333 173 598 minecraft:green_terracotta
setblock 331 173 557 minecraft:green_terracotta
setblock 331 173 561 minecraft:oak_log
fill 331 173 562 331 176 562 minecraft:green_terracotta
setblock 331 173 566 minecraft:oak_log
fill 331 173 567 331 176 567 minecraft:green_terracotta
setblock 331 173 571 minecraft:oak_log
setblock 331 173 581 minecraft:oak_log
fill 331 173 582 331 174 582 minecraft:green_terracotta
setblock 331 173 586 minecraft:oak_log
fill 331 173 587 331 175 587 minecraft:green_terracotta
fill 332 173 557 332 176 557 minecraft:brown_terracotta
setblock 332 173 560 minecraft:oak_log
fill 332 173 561 332 175 561 minecraft:green_terracotta
setblock 332 173 565 minecraft:oak_log
fill 332 173 566 332 176 566 minecraft:green_terracotta
fill 333 173 557 334 173 557 minecraft:green_terracotta
setblock 333 173 559 minecraft:oak_log
fill 333 173 560 333 174 560 minecraft:green_terracotta
setblock 333 173 564 minecraft:oak_log
setblock 334 173 558 minecraft:oak_log
fill 334 173 559 334 175 559 minecraft:green_terracotta
setblock 334 173 598 minecraft:oak_log
fill 335 173 557 336 176 557 minecraft:brown_terracotta
fill 335 173 558 338 173 558 minecraft:green_terracotta
fill 335 173 598 338 173 598 minecraft:green_terracotta
setblock 338 173 559 minecraft:oak_log
setblock 339 173 558 minecraft:oak_log
fill 339 173 559 339 174 559 minecraft:green_terracotta
setblock 339 173 598 minecraft:oak_log
fill 340 173 558 340 176 558 minecraft:green_terracotta
fill 340 173 598 340 173 599 minecraft:green_terracotta
fill 341 173 599 350 174 599 minecraft:brown_terracotta
fill 342 173 557 347 174 557 minecraft:brown_terracotta
setblock 343 173 559 minecraft:oak_log
setblock 343 173 560 minecraft:green_terracotta
setblock 344 173 558 minecraft:oak_log
fill 344 173 559 344 176 559 minecraft:green_terracotta
setblock 344 173 598 minecraft:oak_log
fill 345 173 558 345 176 558 minecraft:green_terracotta
setblock 345 173 597 minecraft:oak_log
fill 345 173 598 345 176 598 minecraft:green_terracotta
setblock 346 173 596 minecraft:oak_log
fill 346 173 597 346 176 597 minecraft:green_terracotta
setblock 347 173 560 minecraft:oak_log
fill 347 173 596 347 174 596 minecraft:green_terracotta
setblock 348 173 557 minecraft:green_terracotta
setblock 348 173 559 minecraft:oak_log
fill 348 173 560 348 174 560 minecraft:green_terracotta
fill 349 173 557 349 174 557 minecraft:brown_terracotta
setblock 349 173 558 minecraft:oak_log
fill 349 173 559 349 175 559 minecraft:green_terracotta
setblock 349 173 598 minecraft:oak_log
fill 350 173 557 350 173 558 minecraft:green_terracotta
setblock 350 173 560 minecraft:green_terracotta
setblock 350 173 597 minecraft:oak_log
fill 350 173 598 350 176 598 minecraft:green_terracotta
fill 351 173 557 354 176 557 minecraft:brown_terracotta
fill 351 173 597 351 174 597 minecraft:green_terracotta
setblock 354 173 558 minecraft:oak_log
setblock 354 173 598 minecraft:oak_log
setblock 355 173 557 minecraft:green_terracotta
fill 356 173 557 357 176 557 minecraft:brown_terracotta
fill 358 173 599 359 173 599 minecraft:green_terracotta
fill 359 173 557 360 176 557 minecraft:brown_terracotta
fill 360 173 599 363 176 599 minecraft:brown_terracotta
setblock 361 173 557 minecraft:green_terracotta
fill 362 173 557 362 176 557 minecraft:brown_terracotta
setblock 363 173 557 minecraft:green_terracotta
setblock 364 173 558 minecraft:oak_log
fill 364 173 559 367 173 559 minecraft:green_terracotta
fill 365 173 558 365 176 558 minecraft:green_terracotta
setblock 366 173 560 minecraft:green_terracotta
setblock 367 173 560 minecraft:oak_log
fill 367 173 561 367 173 564 minecraft:green_terracotta
setblock 367 173 565 minecraft:oak_log
fill 367 173 566 368 173 568 minecraft:green_terracotta
setblock 367 173 580 minecraft:oak_log
fill 367 173 581 367 174 581 minecraft:green_terracotta
setblock 367 173 585 minecraft:oak_log
fill 367 173 586 367 174 586 minecraft:green_terracotta
setblock 367 173 599 minecraft:brown_terracotta
fill 368 173 557 369 176 557 minecraft:brown_terracotta
setblock 368 173 558 minecraft:green_terracotta
setblock 368 173 559 minecraft:oak_log
fill 368 173 560 368 173 563 minecraft:green_terracotta
setblock 368 173 564 minecraft:oak_log
fill 368 173 565 368 176 565 minecraft:green_terracotta
setblock 368 173 569 minecraft:oak_log
fill 368 173 570 368 176 570 minecraft:green_terracotta
setblock 368 173 573 minecraft:green_terracotta
setblock 368 173 574 minecraft:oak_log
fill 368 173 575 368 174 575 minecraft:green_terracotta
setblock 368 173 579 minecraft:oak_log
fill 368 173 580 368 175 580 minecraft:green_terracotta
setblock 368 173 584 minecraft:oak_log
fill 368 173 585 368 176 585 minecraft:green_terracotta
setblock 368 173 599 minecraft:green_terracotta
setblock 369 173 558 minecraft:oak_log
fill 369 173 559 369 173 562 minecraft:green_terracotta
setblock 369 173 563 minecraft:oak_log
fill 369 173 564 369 176 564 minecraft:green_terracotta
setblock 369 173 568 minecraft:oak_log
fill 369 173 569 369 176 569 minecraft:green_terracotta
setblock 369 173 573 minecraft:oak_log
fill 369 173 574 369 176 574 minecraft:green_terracotta
setblock 369 173 578 minecraft:oak_log
fill 369 173 579 369 176 579 minecraft:green_terracotta
setblock 369 173 583 minecraft:oak_log
fill 369 173 584 369 176 584 minecraft:green_terracotta
setblock 369 173 588 minecraft:oak_log
fill 369 173 589 369 176 589 minecraft:green_terracotta
fill 369 173 591 370 173 591 minecraft:green_terracotta
setblock 369 173 598 minecraft:oak_log
fill 369 173 599 371 176 599 minecraft:brown_terracotta
fill 370 173 557 370 173 558 minecraft:green_terracotta
setblock 370 173 562 minecraft:oak_log
fill 370 173 563 370 176 563 minecraft:green_terracotta
setblock 370 173 567 minecraft:oak_log
fill 370 173 568 371 173 568 minecraft:green_terracotta
setblock 370 173 572 minecraft:oak_log
fill 370 173 573 370 176 573 minecraft:green_terracotta
setblock 370 173 577 minecraft:oak_log
fill 370 173 578 371 173 578 minecraft:green_terracotta
setblock 370 173 582 minecraft:oak_log
fill 370 173 583 370 176 583 minecraft:green_terracotta
setblock 370 173 587 minecraft:oak_log
fill 370 173 588 371 173 588 minecraft:green_terracotta
setblock 370 173 592 minecraft:oak_log
fill 370 173 593 370 175 593 minecraft:green_terracotta
setblock 370 173 597 minecraft:oak_log
setblock 370 173 598 minecraft:green_terracotta
fill 371 173 557 371 176 557 minecraft:brown_terracotta
setblock 371 173 558 minecraft:green_terracotta
fill 371 173 559 371 174 562 minecraft:brown_terracotta
fill 371 173 569 371 176 571 minecraft:brown_terracotta
setblock 371 173 577 minecraft:brown_terracotta
fill 371 173 579 371 174 584 minecraft:brown_terracotta
setblock 371 173 585 minecraft:green_terracotta
setblock 371 173 587 minecraft:green_terracotta
fill 371 173 589 371 174 597 minecraft:brown_terracotta
fill 329 174 559 329 176 559 minecraft:brown_terracotta
setblock 329 174 574 minecraft:green_terracotta
fill 329 174 575 329 176 575 minecraft:brown_terracotta
fill 329 174 578 329 176 578 minecraft:brown_terracotta
fill 329 174 582 329 174 583 minecraft:green_terracotta
fill 329 174 584 329 176 584 minecraft:brown_terracotta
fill 329 174 586 329 177 586 minecraft:brown_terracotta
fill 329 174 588 329 176 588 minecraft:brown_terracotta
fill 329 174 590 329 176 590 minecraft:brown_terracotta
fill 329 174 592 329 176 592 minecraft:brown_terracotta
fill 329 174 596 329 177 596 minecraft:brown_terracotta
fill 329 174 598 329 176 599 minecraft:brown_terracotta
fill 330 174 558 332 174 558 minecraft:green_terracotta
setblock 330 174 561 minecraft:oak_log
fill 330 174 562 330 177 562 minecraft:green_terracotta
setblock 330 174 566 minecraft:oak_log
fill 330 174 567 330 177 567 minecraft:green_terracotta
setblock 330 174 571 minecraft:oak_log
fill 330 174 572 330 177 572 minecraft:green_terracotta
setblock 330 174 576 minecraft:oak_log
fill 330 174 577 330 174 578 minecraft:green_terracotta
setblock 330 174 581 minecraft:oak_log
fill 330 174 582 330 176 582 minecraft:green_terracotta
setblock 330 174 586 minecraft:oak_log
fill 330 174 587 330 176 588 minecraft:green_terracotta
setblock 330 174 590 minecraft:green_terracotta
setblock 330 174 591 minecraft:oak_log
fill 330 174 592 330 177 592 minecraft:green_terracotta
setblock 330 174 596 minecraft:oak_log
fill 330 174 597 330 176 598 minecraft:green_terracotta
fill 331 174 557 331 176 557 minecraft:brown_terracotta
setblock 331 174 560 minecraft:oak_log
fill 331 174 561 331 177 561 minecraft:green_terracotta
setblock 331 174 565 minecraft:oak_log
fill 331 174 566 331 177 566 minecraft:green_terracotta
setblock 331 174 570 minecraft:oak_log
setblock 331 174 571 minecraft:green_terracotta
setblock 331 174 585 minecraft:oak_log
fill 331 174 586 331 175 586 minecraft:green_terracotta
fill 331 174 598 332 174 598 minecraft:green_terracotta
setblock 332 174 559 minecraft:oak_log
fill 332 174 560 332 175 560 minecraft:green_terracotta
setblock 332 174 564 minecraft:oak_log
fill 332 174 565 332 176 565 minecraft:green_terracotta
fill 333 174 557 334 176 557 minecraft:brown_terracotta
setblock 333 174 558 minecraft:oak_log
fill 333 174 559 333 175 559 minecraft:green_terracotta
setblock 333 174 598 minecraft:oak_log
setblock 333 174 599 minecraft:green_terracotta
fill 334 174 558 337 174 558 minecraft:green_terracotta
setblock 334 174 598 minecraft:green_terracotta
setblock 337 174 559 minecraft:oak_log
setblock 338 174 558 minecraft:oak_log
setblock 338 174 559 minecraft:green_terracotta
setblock 338 174 598 minecraft:oak_log
fill 339 174 558 339 176 558 minecraft:green_terracotta
fill 339 174 598 340 175 598 minecraft:green_terracotta
fill 340 174 599 340 176 599 minecraft:brown_terracotta
setblock 342 174 559 minecraft:oak_log
setblock 343 174 558 minecraft:oak_log
fill 343 174 559 343 176 559 minecraft:green_terracotta
setblock 343 174 598 minecraft:oak_log
fill 344 174 558 344 177 558 minecraft:green_terracotta
setblock 344 174 597 minecraft:oak_log
fill 344 174 598 344 177 598 minecraft:green_terracotta
fill 345 174 597 345 177 597 minecraft:green_terracotta
setblock 346 174 560 minecraft:oak_log
setblock 346 174 596 minecraft:green_terracotta
setblock 347 174 559 minecraft:oak_log
setblock 347 174 560 minecraft:green_terracotta
fill 348 174 557 348 176 557 minecraft:brown_terracotta
setblock 348 174 558 minecraft:oak_log
fill 348 174 559 348 175 559 minecraft:green_terracotta
setblock 348 174 598 minecraft:oak_log
fill 349 174 558 350 175 558 minecraft:green_terracotta
setblock 349 174 597 minecraft:oak_log
fill 349 174 598 349 177 598 minecraft:green_terracotta
fill 350 174 557 350 176 557 minecraft:brown_terracotta
fill 350 174 597 350 175 597 minecraft:green_terracotta
setblock 353 174 598 minecraft:oak_log
fill 355 174 557 355 176 557 minecraft:brown_terracotta
setblock 355 174 598 minecraft:oak_leaves[persistent=true]
fill 358 174 599 359 176 599 minecraft:brown_terracotta
fill 361 174 557 361 177 557 minecraft:brown_terracotta
fill 363 174 557 363 176 557 minecraft:brown_terracotta
setblock 363 174 558 minecraft:oak_log
fill 364 174 557 364 174 559 minecraft:green_terracotta
fill 365 174 559 366 174 559 minecraft:green_terracotta
setblock 366 174 560 minecraft:oak_log
setblock 367 174 559 minecraft:oak_log
fill 367 174 560 369 175 560 minecraft:green_terracotta
fill 367 174 562 367 174 563 minecraft:green_terracotta
setblock 367 174 564 minecraft:oak_log
fill 367 174 565 367 174 568 minecraft:green_terracotta
setblock 367 174 569 minecraft:oak_log
setblock 367 174 584 minecraft:oak_log
setblock 367 174 585 minecraft:green_terracotta
setblock 367 174 599 minecraft:green_terracotta
setblock 368 174 558 minecraft:oak_log
fill 368 174 559 369 176 559 minecraft:green_terracotta
fill 368 174 561 368 174 562 minecraft:green_terracotta
setblock 368 174 563 minecraft:oak_log
fill 368 174 564 368 177 564 minecraft:green_terracotta
fill 368 174 566 368 174 567 minecraft:green_terracotta
setblock 368 174 568 minecraft:oak_log
fill 368 174 569 368 177 569 minecraft:green_terracotta
setblock 368 174 573 minecraft:oak_log
setblock 368 174 574 minecraft:green_terracotta
setblock 368 174 578 minecraft:oak_log
fill 368 174 579 368 175 579 minecraft:green_terracotta
setblock 368 174 583 minecraft:oak_log
fill 368 174 584 368 176 584 minecraft:green_terracotta
setblock 368 174 588 minecraft:oak_log
setblock 368 174 589 minecraft:green_terracotta
setblock 368 174 598 minecraft:oak_log
fill 368 174 599 368 176 599 minecraft:brown_terracotta
fill 369 174 558 370 176 558 minecraft:green_terracotta
setblock 369 174 561 minecraft:green_terracotta
setblock 369 174 562 minecraft:oak_log
fill 369 174 563 369 177 563 minecraft:green_terracotta
setblock 369 174 567 minecraft:oak_log
fill 369 174 568 370 176 568 minecraft:green_terracotta
setblock 369 174 572 minecraft:oak_log
fill 369 174 573 369 177 573 minecraft:green_terracotta
setblock 369 174 577 minecraft:oak_log
fill 369 174 578 370 176 578 minecraft:green_terracotta
setblock 369 174 582 minecraft:oak_log
fill 369 174 583 369 177 583 minecraft:green_terracotta
setblock 369 174 587 minecraft:oak_log
fill 369 174 588 370 176 588 minecraft:green_terracotta
setblock 369 174 591 minecraft:green_terracotta
setblock 369 174 598 minecraft:green_terracotta
fill 370 174 557 370 176 557 minecraft:brown_terracotta
setblock 370 174 561 minecraft:oak_log
fill 370 174 562 370 177 562 minecraft:green_terracotta
setblock 370 174 566 minecraft:oak_log
fill 370 174 567 370 177 567 minecraft:green_terracotta
setblock 370 174 571 minecraft:oak_log
fill 370 174 572 371 175 572 minecraft:green_terracotta
setblock 370 174 576 minecraft:oak_log
fill 370 174 577 371 174 577 minecraft:green_terracotta
setblock 370 174 581 minecraft:oak_log
fill 370 174 582 370 177 582 minecraft:green_terracotta
setblock 370 174 586 minecraft:oak_log
fill 370 174 587 370 177 587 minecraft:green_terracotta
setblock 370 174 591 minecraft:oak_log
fill 370 174 592 370 176 592 minecraft:green_terracotta
fill 371 174 558 371 176 558 minecraft:brown_terracotta
fill 371 174 563 371 174 564 minecraft:green_terracotta
fill 371 174 565 371 174 566 minecraft:brown_terracotta
setblock 371 174 568 minecraft:brown_terracotta
fill 371 174 573 371 176 573 minecraft:brown_terracotta
setblock 371 174 574 minecraft:green_terracotta
fill 371 174 575 371 176 576 minecraft:brown_terracotta
fill 371 174 578 371 176 578 minecraft:brown_terracotta
fill 371 174 585 371 176 585 minecraft:brown_terracotta
fill 371 174 587 371 174 588 minecraft:brown_terracotta
fill 329 175 574 329 176 574 minecraft:brown_terracotta
setblock 329 175 579 minecraft:green_terracotta
fill 329 175 580 329 176 580 minecraft:brown_terracotta
fill 329 175 581 330 175 581 minecraft:green_terracotta
fill 329 175 582 329 176 583 minecraft:brown_terracotta
fill 330 175 558 331 175 558 minecraft:green_terracotta
setblock 330 175 560 minecraft:oak_log
fill 330 175 561 330 178 561 minecraft:green_terracotta
setblock 330 175 565 minecraft:oak_log
fill 330 175 566 330 178 566 minecraft:green_terracotta
setblock 330 175 570 minecraft:oak_log
fill 330 175 571 330 178 571 minecraft:green_terracotta
setblock 330 175 575 minecraft:oak_log
setblock 330 175 578 minecraft:green_terracotta
setblock 330 175 580 minecraft:oak_log
setblock 330 175 585 minecraft:oak_log
fill 330 175 586 330 178 586 minecraft:green_terracotta
setblock 330 175 589 minecraft:green_terracotta
setblock 330 175 590 minecraft:oak_log
fill 330 175 591 330 178 591 minecraft:green_terracotta
setblock 330 175 595 minecraft:oak_log
setblock 330 175 596 minecraft:green_terracotta
setblock 331 175 559 minecraft:oak_log
fill 331 175 560 331 177 560 minecraft:green_terracotta
setblock 331 175 564 minecraft:oak_log
fill 331 175 565 331 178 565 minecraft:green_terracotta
setblock 331 175 569 minecraft:oak_log
fill 331 175 570 331 176 570 minecraft:green_terracotta
setblock 331 175 585 minecraft:green_terracotta
setblock 331 175 598 minecraft:green_terracotta
setblock 332 175 558 minecraft:oak_log
fill 332 175 559 332 176 559 minecraft:green_terracotta
setblock 332 175 563 minecraft:oak_log
fill 332 175 564 332 176 564 minecraft:green_terracotta
setblock 332 175 598 minecraft:oak_log
fill 333 175 558 336 175 558 minecraft:green_terracotta
fill 333 175 599 333 176 599 minecraft:brown_terracotta
setblock 336 175 598 minecraft:oak_leaves[persistent=true]
setblock 337 175 558 minecraft:oak_log
fill 338 175 558 338 176 558 minecraft:green_terracotta
setblock 341 175 559 minecraft:oak_log
fill 341 175 599 343 176 599 minecraft:brown_terracotta
fill 342 175 557 343 176 557 minecraft:brown_terracotta
setblock 342 175 558 minecraft:oak_log
setblock 342 175 559 minecraft:green_terracotta
setblock 342 175 598 minecraft:oak_log
fill 343 175 558 343 178 558 minecraft:green_terracotta
setblock 343 175 597 minecraft:oak_log
fill 343 175 598 343 178 598 minecraft:green_terracotta
setblock 344 175 557 minecraft:green_terracotta
fill 344 175 597 344 178 597 minecraft:green_terracotta
setblock 344 175 599 minecraft:green_terracotta
fill 345 175 557 347 176 557 minecraft:brown_terracotta
fill 345 175 599 348 176 599 minecraft:brown_terracotta
setblock 346 175 559 minecraft:oak_log
setblock 347 175 558 minecraft:oak_log
fill 347 175 559 347 176 559 minecraft:green_terracotta
setblock 347 175 598 minecraft:oak_log
fill 348 175 558 348 177 558 minecraft:green_terracotta
setblock 348 175 597 minecraft:oak_log
fill 348 175 598 348 178 598 minecraft:green_terracotta
setblock 349 175 557 minecraft:green_terracotta
setblock 349 175 597 minecraft:green_terracotta
setblock 349 175 599 minecraft:green_terracotta
fill 350 175 599 350 176 599 minecraft:brown_terracotta
setblock 352 175 598 minecraft:oak_log
setblock 352 175 599 minecraft:green_terracotta
fill 355 175 599 355 176 599 minecraft:brown_terracotta
setblock 356 175 599 minecraft:green_terracotta
setblock 358 175 558 minecraft:oak_leaves[persistent=true]
setblock 361 175 598 minecraft:oak_leaves[persistent=true]
fill 363 175 558 364 175 558 minecraft:green_terracotta
fill 364 175 557 364 176 557 minecraft:brown_terracotta
setblock 365 175 559 minecraft:green_terracotta
setblock 366 175 559 minecraft:oak_log
setblock 366 175 560 minecraft:green_terracotta
setblock 367 175 558 minecraft:oak_log
fill 367 175 559 367 177 559 minecraft:green_terracotta
setblock 367 175 562 minecraft:green_terracotta
setblock 367 175 563 minecraft:oak_log
fill 367 175 564 367 175 567 minecraft:green_terracotta
setblock 367 175 568 minecraft:oak_log
fill 367 175 569 367 178 569 minecraft:green_terracotta
fill 367 175 599 367 176 599 minecraft:brown_terracotta
fill 368 175 558 368 178 558 minecraft:green_terracotta
setblock 368 175 561 minecraft:green_terracotta
setblock 368 175 562 minecraft:oak_log
fill 368 175 563 368 178 563 minecraft:green_terracotta
setblock 368 175 566 minecraft:green_terracotta
setblock 368 175 567 minecraft:oak_log
fill 368 175 568 368 178 568 minecraft:green_terracotta
setblock 368 175 571 minecraft:green_terracotta
setblock 368 175 572 minecraft:oak_log
setblock 368 175 573 minecraft:green_terracotta
setblock 368 175 582 minecraft:oak_log
fill 368 175 583 368 176 583 minecraft:green_terracotta
setblock 368 175 587 minecraft:oak_log
fill 368 175 588 368 176 588 minecraft:green_terracotta
setblock 369 175 561 minecraft:oak_log
fill 369 175 562 369 178 562 minecraft:green_terracotta
setblock 369 175 566 minecraft:oak_log
fill 369 175 567 369 178 567 minecraft:green_terracotta
setblock 369 175 571 minecraft:oak_log
fill 369 175 572 369 178 572 minecraft:green_terracotta
setblock 369 175 576 minecraft:oak_log
fill 369 175 577 370 176 577 minecraft:green_terracotta
setblock 369 175 581 minecraft:oak_log
fill 369 175 582 369 177 582 minecraft:green_terracotta
setblock 369 175 586 minecraft:oak_log
fill 369 175 587 369 177 587 minecraft:green_terracotta
setblock 370 175 560 minecraft:oak_log
fill 370 175 561 371 175 561 minecraft:green_terracotta
setblock 370 175 565 minecraft:oak_log
fill 370 175 566 370 178 566 minecraft:green_terracotta
setblock 370 175 570 minecraft:oak_log
fill 370 175 571 370 178 571 minecraft:green_terracotta
setblock 370 175 575 minecraft:oak_log
fill 370 175 576 370 177 576 minecraft:green_terracotta
setblock 370 175 580 minecraft:oak_log
fill 370 175 581 371 175 581 minecraft:green_terracotta
setblock 370 175 585 minecraft:oak_log
fill 370 175 586 370 178 586 minecraft:green_terracotta
setblock 370 175 590 minecraft:oak_log
fill 370 175 591 370 178 591 minecraft:green_terracotta
setblock 370 175 596 minecraft:oak_leaves[persistent=true]
fill 371 175 559 371 176 559 minecraft:brown_terracotta
setblock 371 175 560 minecraft:green_terracotta
fill 371 175 562 371 176 564 minecraft:brown_terracotta
setblock 371 175 565 minecraft:green_terracotta
fill 371 175 566 371 176 566 minecraft:brown_terracotta
setblock 371 175 568 minecraft:green_terracotta
fill 371 175 574 371 176 574 minecraft:brown_terracotta
fill 371 175 577 371 176 577 minecraft:brown_terracotta
fill 371 175 579 371 176 580 minecraft:brown_terracotta
fill 371 175 582 371 176 584 minecraft:brown_terracotta
fill 371 175 587 371 176 587 minecraft:brown_terracotta
setblock 371 175 588 minecraft:green_terracotta
fill 371 175 589 371 176 591 minecraft:brown_terracotta
setblock 371 175 592 minecraft:green_terracotta
fill 371 175 593 371 176 597 minecraft:brown_terracotta
setblock 329 176 579 minecraft:brown_terracotta
setblock 329 176 581 minecraft:brown_terracotta
setblock 330 176 558 minecraft:green_terracotta
setblock 330 176 559 minecraft:oak_log
fill 330 176 560 330 179 560 minecraft:green_terracotta
setblock 330 176 564 minecraft:oak_log
fill 330 176 565 330 179 565 minecraft:green_terracotta
setblock 330 176 569 minecraft:oak_log
fill 330 176 570 330 179 570 minecraft:green_terracotta
setblock 330 176 584 minecraft:oak_log
fill 330 176 585 330 177 585 minecraft:green_terracotta
setblock 330 176 589 minecraft:oak_log
fill 330 176 590 330 179 590 minecraft:green_terracotta
setblock 330 176 594 minecraft:oak_log
setblock 330 176 595 minecraft:green_terracotta
setblock 331 176 558 minecraft:oak_log
setblock 331 176 559 minecraft:green_terracotta
setblock 331 176 563 minecraft:oak_log
fill 331 176 564 331 178 564 minecraft:green_terracotta
setblock 331 176 568 minecraft:oak_log
fill 331 176 569 331 177 569 minecraft:green_terracotta
fill 332 176 558 335 176 558 minecraft:green_terracotta
setblock 332 176 560 minecraft:light[level=14]
setblock 332 176 562 minecraft:oak_log
setblock 332 176 563 minecraft:green_terracotta
setblock 332 176 568 minecraft:light[level=14]
setblock 332 176 576 minecraft:light[level=14]
setblock 332 176 584 minecraft:light[level=14]
setblock 332 176 592 minecraft:light[level=14]
setblock 336 176 558 minecraft:oak_log
setblock 337 176 558 minecraft:green_terracotta
setblock 340 176 560 minecraft:light[level=14]
setblock 340 176 568 minecraft:light[level=14]
setblock 340 176 576 minecraft:light[level=14]
setblock 340 176 584 minecraft:light[level=14]
setblock 340 176 592 minecraft:light[level=14]
setblock 340 176 598 minecraft:green_terracotta
setblock 341 176 558 minecraft:oak_log
setblock 341 176 598 minecraft:oak_log
fill 342 176 558 342 178 558 minecraft:green_terracotta
fill 342 176 598 342 179 598 minecraft:green_terracotta
fill 343 176 597 343 179 597 minecraft:green_terracotta
setblock 344 176 557 minecraft:brown_terracotta
setblock 344 176 599 minecraft:brown_terracotta
setblock 345 176 559 minecraft:oak_log
setblock 346 176 558 minecraft:oak_log
setblock 346 176 559 minecraft:green_terracotta
setblock 346 176 598 minecraft:oak_log
fill 347 176 558 347 177 558 minecraft:green_terracotta
setblock 347 176 597 minecraft:oak_log
fill 347 176 598 347 179 598 minecraft:green_terracotta
setblock 348 176 560 minecraft:light[level=14]
setblock 348 176 568 minecraft:light[level=14]
setblock 348 176 576 minecraft:light[level=14]
setblock 348 176 584 minecraft:light[level=14]
setblock 348 176 592 minecraft:light[level=14]
setblock 348 176 597 minecraft:green_terracotta
setblock 349 176 557 minecraft:brown_terracotta
setblock 349 176 558 minecraft:green_terracotta
setblock 349 176 599 minecraft:brown_terracotta
setblock 352 176 558 minecraft:oak_leaves[persistent=true]
setblock 352 176 599 minecraft:brown_terracotta
setblock 356 176 560 minecraft:light[level=14]
setblock 356 176 568 minecraft:light[level=14]
setblock 356 176 576 minecraft:light[level=14]
setblock 356 176 584 minecraft:light[level=14]
setblock 356 176 592 minecraft:light[level=14]
setblock 356 176 599 minecraft:brown_terracotta
fill 364 176 558 364 177 558 minecraft:green_terracotta
setblock 364 176 560 minecraft:light[level=14]
setblock 364 176 568 minecraft:light[level=14]
setblock 364 176 576 minecraft:light[level=14]
setblock 364 176 584 minecraft:light[level=14]
setblock 364 176 592 minecraft:light[level=14]
setblock 365 176 559 minecraft:oak_log
setblock 366 176 558 minecraft:oak_log
setblock 366 176 559 minecraft:green_terracotta
fill 367 176 558 367 179 558 minecraft:green_terracotta
fill 367 176 563 367 176 566 minecraft:green_terracotta
setblock 367 176 567 minecraft:oak_log
fill 367 176 568 367 179 568 minecraft:green_terracotta
setblock 367 176 598 minecraft:oak_leaves[persistent=true]
setblock 368 176 560 minecraft:green_terracotta
setblock 368 176 561 minecraft:oak_log
fill 368 176 562 368 177 562 minecraft:green_terracotta
setblock 368 176 566 minecraft:oak_log
fill 368 176 567 368 179 567 minecraft:green_terracotta
setblock 368 176 571 minecraft:oak_log
fill 368 176 572 368 178 572 minecraft:green_terracotta
setblock 368 176 582 minecraft:green_terracotta
setblock 368 176 586 minecraft:oak_log
setblock 368 176 587 minecraft:green_terracotta
setblock 369 176 560 minecraft:oak_log
fill 369 176 561 370 178 561 minecraft:green_terracotta
setblock 369 176 565 minecraft:oak_log
fill 369 176 566 369 179 566 minecraft:green_terracotta
setblock 369 176 570 minecraft:oak_log
fill 369 176 571 369 179 571 minecraft:green_terracotta
setblock 369 176 575 minecraft:oak_log
setblock 369 176 576 minecraft:green_terracotta
setblock 369 176 580 minecraft:oak_log
fill 369 176 581 370 176 581 minecraft:green_terracotta
setblock 369 176 585 minecraft:oak_log
fill 369 176 586 369 177 586 minecraft:green_terracotta
setblock 369 176 590 minecraft:oak_log
setblock 370 176 559 minecraft:oak_log
fill 370 176 560 370 179 560 minecraft:green_terracotta
setblock 370 176 564 minecraft:oak_log
fill 370 176 565 370 179 565 minecraft:green_terracotta
setblock 370 176 569 minecraft:oak_log
fill 370 176 570 370 179 570 minecraft:green_terracotta
fill 370 176 572 370 177 572 minecraft:green_terracotta
setblock 370 176 574 minecraft:oak_log
fill 370 176 575 370 178 575 minecraft:green_terracotta
setblock 370 176 579 minecraft:oak_log
fill 370 176 580 370 177 580 minecraft:green_terracotta
setblock 370 176 584 minecraft:oak_log
fill 370 176 585 370 178 585 minecraft:green_terracotta
setblock 370 176 589 minecraft:oak_log
fill 370 176 590 370 179 590 minecraft:green_terracotta
fill 371 176 560 371 176 561 minecraft:brown_terracotta
setblock 371 176 565 minecraft:brown_terracotta
setblock 371 176 568 minecraft:brown_terracotta
setblock 371 176 572 minecraft:brown_terracotta
setblock 371 176 581 minecraft:brown_terracotta
setblock 371 176 588 minecraft:brown_terracotta
setblock 371 176 592 minecraft:brown_terracotta
fill 329 177 557 329 177 563 minecraft:green_terracotta
fill 329 177 564 329 178 564 minecraft:brown_terracotta
fill 329 177 565 329 177 575 minecraft:green_terracotta
setblock 329 177 576 minecraft:brown_terracotta
fill 329 177 577 329 178 585 minecraft:green_terracotta
fill 329 177 588 329 238 588 minecraft:green_terracotta
fill 329 177 590 329 178 595 minecraft:green_terracotta
fill 329 177 597 329 177 599 minecraft:green_terracotta
fill 330 177 557 336 239 557 minecraft:green_terracotta
setblock 330 177 558 minecraft:oak_log
fill 330 177 559 330 179 559 minecraft:green_terracotta
setblock 330 177 563 minecraft:oak_log
fill 330 177 564 330 180 564 minecraft:green_terracotta
setblock 330 177 568 minecraft:oak_log
fill 330 177 569 330 180 569 minecraft:green_terracotta
fill 330 177 578 330 178 578 minecraft:oak_leaves[persistent=true]
setblock 330 177 584 minecraft:green_terracotta
setblock 330 177 587 minecraft:green_terracotta
setblock 330 177 588 minecraft:oak_log
fill 330 177 589 330 180 589 minecraft:green_terracotta
setblock 330 177 593 minecraft:oak_log
setblock 330 177 594 minecraft:green_terracotta
setblock 330 177 597 minecraft:oak_leaves[persistent=true]
fill 330 177 599 345 177 599 minecraft:green_terracotta
fill 331 177 558 333 177 558 minecraft:green_terracotta
setblock 331 177 562 minecraft:oak_log
fill 331 177 563 331 178 563 minecraft:green_terracotta
setblock 331 177 567 minecraft:oak_log
fill 331 177 568 331 178 568 minecraft:green_terracotta
fill 338 177 557 339 239 557 minecraft:green_terracotta
fill 340 177 557 340 178 557 minecraft:brown_terracotta
setblock 340 177 558 minecraft:oak_log
setblock 340 177 598 minecraft:oak_log
fill 341 177 557 341 177 558 minecraft:green_terracotta
fill 341 177 598 341 180 598 minecraft:green_terracotta
fill 342 177 557 360 177 557 minecraft:green_terracotta
setblock 345 177 558 minecraft:oak_log
setblock 345 177 598 minecraft:oak_log
fill 346 177 558 346 178 558 minecraft:green_terracotta
setblock 346 177 597 minecraft:oak_log
fill 346 177 598 346 180 598 minecraft:green_terracotta
setblock 346 177 599 minecraft:brown_terracotta
setblock 347 177 597 minecraft:green_terracotta
fill 347 177 599 371 177 599 minecraft:green_terracotta
setblock 354 177 598 minecraft:oak_leaves[persistent=true]
fill 362 177 557 371 177 557 minecraft:green_terracotta
setblock 365 177 558 minecraft:oak_log
fill 366 177 558 366 179 558 minecraft:green_terracotta
fill 367 177 564 367 177 565 minecraft:green_terracotta
setblock 367 177 566 minecraft:oak_log
fill 367 177 567 367 179 567 minecraft:green_terracotta
setblock 368 177 559 minecraft:green_terracotta
setblock 368 177 565 minecraft:oak_log
fill 368 177 566 368 180 566 minecraft:green_terracotta
setblock 368 177 570 minecraft:oak_log
fill 368 177 571 368 180 571 minecraft:green_terracotta
setblock 369 177 558 minecraft:green_terracotta
setblock 369 177 559 minecraft:oak_log
setblock 369 177 560 minecraft:green_terracotta
setblock 369 177 564 minecraft:oak_log
fill 369 177 565 369 180 565 minecraft:green_terracotta
setblock 369 177 568 minecraft:green_terracotta
setblock 369 177 569 minecraft:oak_log
fill 369 177 570 369 180 570 minecraft:green_terracotta
setblock 369 177 574 minecraft:oak_log
setblock 369 177 584 minecraft:oak_log
setblock 369 177 585 minecraft:green_terracotta
setblock 369 177 588 minecraft:green_terracotta
setblock 369 177 589 minecraft:oak_log
setblock 370 177 558 minecraft:oak_log
fill 370 177 559 371 178 559 minecraft:green_terracotta
setblock 370 177 563 minecraft:oak_log
fill 370 177 564 371 180 564 minecraft:green_terracotta
setblock 370 177 568 minecraft:oak_log
fill 370 177 569 371 177 569 minecraft:green_terracotta
setblock 370 177 573 minecraft:oak_log
fill 370 177 574 371 180 574 minecraft:green_terracotta
fill 370 177 577 371 177 577 minecraft:green_terracotta
setblock 370 177 578 minecraft:oak_log
fill 370 177 579 371 177 579 minecraft:green_terracotta
fill 370 177 581 371 177 581 minecraft:green_terracotta
setblock 370 177 583 minecraft:oak_log
fill 370 177 584 371 177 584 minecraft:green_terracotta
setblock 370 177 588 minecraft:oak_log
fill 370 177 589 371 178 589 minecraft:green_terracotta
fill 371 177 558 371 242 558 minecraft:green_terracotta
fill 371 177 560 371 178 563 minecraft:green_terracotta
fill 371 177 565 371 178 568 minecraft:green_terracotta
fill 371 177 570 371 177 573 minecraft:green_terracotta
fill 371 177 575 371 178 576 minecraft:green_terracotta
fill 371 177 578 371 243 578 minecraft:green_terracotta
fill 371 177 580 371 242 580 minecraft:green_terracotta
setblock 371 177 582 minecraft:brown_terracotta
fill 371 177 583 371 242 583 minecraft:green_terracotta
fill 371 177 585 371 242 588 minecraft:green_terracotta
fill 371 177 590 371 177 598 minecraft:green_terracotta
setblock 329 178 557 minecraft:green_terracotta
setblock 329 178 558 minecraft:brown_terracotta
fill 329 178 559 329 238 563 minecraft:green_terracotta
fill 329 178 565 329 178 572 minecraft:green_terracotta
setblock 329 178 573 minecraft:brown_terracotta
fill 329 178 574 329 240 576 minecraft:green_terracotta
fill 329 178 586 329 238 587 minecraft:green_terracotta
fill 329 178 589 329 242 589 minecraft:green_terracotta
fill 329 178 596 329 240 598 minecraft:green_terracotta
fill 329 178 599 329 179 599 minecraft:brown_terracotta
fill 330 178 558 331 178 558 minecraft:green_terracotta
setblock 330 178 562 minecraft:oak_log
fill 330 178 563 330 181 563 minecraft:green_terracotta
setblock 330 178 567 minecraft:oak_log
fill 330 178 568 330 181 568 minecraft:green_terracotta
setblock 330 178 572 minecraft:oak_log
setblock 330 178 584 minecraft:oak_leaves[persistent=true]
setblock 330 178 587 minecraft:oak_log
fill 330 178 588 330 179 588 minecraft:green_terracotta
setblock 330 178 592 minecraft:oak_log
fill 330 178 593 330 181 593 minecraft:green_terracotta
fill 330 178 599 332 242 599 minecraft:green_terracotta
setblock 331 178 562 minecraft:green_terracotta
setblock 331 178 566 minecraft:oak_log
fill 331 178 567 331 179 567 minecraft:green_terracotta
setblock 333 178 599 minecraft:brown_terracotta
fill 334 178 599 342 178 599 minecraft:green_terracotta
setblock 335 178 598 minecraft:oak_leaves[persistent=true]
fill 337 178 557 337 242 557 minecraft:green_terracotta
setblock 340 178 558 minecraft:oak_leaves[persistent=true]
fill 340 178 598 340 181 598 minecraft:green_terracotta
fill 341 178 557 343 242 557 minecraft:green_terracotta
setblock 343 178 599 minecraft:brown_terracotta
setblock 344 178 557 minecraft:brown_terracotta
setblock 344 178 558 minecraft:oak_log
setblock 344 178 598 minecraft:oak_log
fill 344 178 599 355 178 599 minecraft:green_terracotta
fill 345 178 557 345 178 558 minecraft:green_terracotta
setblock 345 178 597 minecraft:oak_log
fill 345 178 598 345 181 598 minecraft:green_terracotta
fill 346 178 557 349 238 557 minecraft:green_terracotta
fill 346 178 597 346 181 597 minecraft:green_terracotta
fill 350 178 557 351 178 557 minecraft:brown_terracotta
fill 352 178 557 366 178 557 minecraft:green_terracotta
setblock 356 178 599 minecraft:brown_terracotta
fill 357 178 599 362 178 599 minecraft:green_terracotta
setblock 360 178 598 minecraft:oak_leaves[persistent=true]
setblock 363 178 599 minecraft:brown_terracotta
fill 364 178 599 364 242 599 minecraft:green_terracotta
setblock 365 178 558 minecraft:green_terracotta
setblock 365 178 599 minecraft:brown_terracotta
fill 366 178 599 366 242 599 minecraft:green_terracotta
setblock 367 178 557 minecraft:brown_terracotta
setblock 367 178 565 minecraft:oak_log
fill 367 178 566 367 179 566 minecraft:green_terracotta
setblock 367 178 599 minecraft:brown_terracotta
fill 368 178 557 368 242 557 minecraft:green_terracotta
setblock 368 178 564 minecraft:oak_log
fill 368 178 565 368 181 565 minecraft:green_terracotta
setblock 368 178 569 minecraft:oak_log
fill 368 178 570 368 181 570 minecraft:green_terracotta
fill 368 178 599 370 178 599 minecraft:green_terracotta
setblock 369 178 557 minecraft:brown_terracotta
setblock 369 178 558 minecraft:oak_log
setblock 369 178 563 minecraft:oak_log
fill 369 178 564 369 181 564 minecraft:green_terracotta
setblock 369 178 568 minecraft:oak_log
fill 369 178 569 370 180 569 minecraft:green_terracotta
setblock 369 178 573 minecraft:oak_log
fill 370 178 557 371 238 557 minecraft:green_terracotta
setblock 370 178 562 minecraft:oak_log
fill 370 178 563 370 181 563 minecraft:green_terracotta
setblock 370 178 567 minecraft:oak_log
fill 370 178 568 370 181 568 minecraft:green_terracotta
setblock 370 178 572 minecraft:oak_log
fill 370 178 573 371 178 573 minecraft:green_terracotta
fill 370 178 583 370 178 584 minecraft:green_terracotta
setblock 370 178 587 minecraft:oak_log
fill 370 178 588 370 179 588 minecraft:green_terracotta
setblock 370 178 597 minecraft:oak_leaves[persistent=true]
fill 371 178 569 371 179 569 minecraft:brown_terracotta
setblock 371 178 570 minecraft:green_terracotta
fill 371 178 571 371 179 571 minecraft:brown_terracotta
fill 371 178 572 371 242 572 minecraft:green_terracotta
fill 371 178 577 371 242 577 minecraft:green_terracotta
fill 371 178 579 371 242 579 minecraft:green_terracotta
fill 371 178 581 371 238 582 minecraft:green_terracotta
setblock 371 178 584 minecraft:brown_terracotta
fill 371 178 590 371 240 592 minecraft:green_terracotta
fill 371 178 593 371 179 593 minecraft:brown_terracotta
fill 371 178 594 371 239 598 minecraft:green_terracotta
setblock 371 178 599 minecraft:brown_terracotta
setblock 329 179 557 minecraft:brown_terracotta
fill 329 179 558 330 179 558 minecraft:green_terracotta
fill 329 179 564 329 238 568 minecraft:green_terracotta
setblock 329 179 569 minecraft:brown_terracotta
fill 329 179 570 329 238 573 minecraft:green_terracotta
fill 329 179 577 329 240 577 minecraft:green_terracotta
setblock 329 179 578 minecraft:brown_terracotta
fill 329 179 579 329 239 585 minecraft:green_terracotta
fill 329 179 590 329 242 591 minecraft:green_terracotta
setblock 329 179 592 minecraft:brown_terracotta
fill 329 179 593 329 240 595 minecraft:green_terracotta
setblock 330 179 561 minecraft:oak_log
fill 330 179 562 330 181 562 minecraft:green_terracotta
setblock 330 179 566 minecraft:oak_log
fill 330 179 567 330 182 567 minecraft:green_terracotta
setblock 330 179 571 minecraft:oak_log
setblock 330 179 591 minecraft:oak_log
fill 330 179 592 330 182 592 minecraft:green_terracotta
setblock 331 179 565 minecraft:oak_log
setblock 331 179 566 minecraft:green_terracotta
fill 333 179 599 339 240 599 minecraft:green_terracotta
setblock 334 179 558 minecraft:oak_leaves[persistent=true]
fill 339 179 598 339 182 598 minecraft:green_terracotta
fill 340 179 557 340 242 557 minecraft:green_terracotta
setblock 340 179 599 minecraft:brown_terracotta
fill 341 179 599 348 239 599 minecraft:green_terracotta
fill 342 179 597 342 180 597 minecraft:green_terracotta
setblock 343 179 598 minecraft:oak_log
fill 344 179 557 345 240 557 minecraft:green_terracotta
setblock 344 179 597 minecraft:oak_log
fill 344 179 598 344 182 598 minecraft:green_terracotta
fill 345 179 597 345 182 597 minecraft:green_terracotta
setblock 348 179 598 minecraft:oak_log
setblock 349 179 599 minecraft:brown_terracotta
fill 350 179 557 352 239 557 minecraft:green_terracotta
fill 350 179 599 359 239 599 minecraft:green_terracotta
setblock 353 179 557 minecraft:brown_terracotta
fill 354 179 557 367 238 557 minecraft:green_terracotta
setblock 359 179 558 minecraft:oak_leaves[persistent=true]
setblock 360 179 599 minecraft:brown_terracotta
fill 361 179 599 363 238 599 minecraft:green_terracotta
fill 365 179 599 365 242 599 minecraft:green_terracotta
setblock 366 179 598 minecraft:oak_leaves[persistent=true]
setblock 367 179 569 minecraft:oak_log
fill 367 179 599 367 242 599 minecraft:green_terracotta
setblock 368 179 564 minecraft:green_terracotta
setblock 368 179 568 minecraft:oak_log
fill 368 179 569 368 182 569 minecraft:green_terracotta
fill 368 179 599 369 179 599 minecraft:brown_terracotta
fill 369 179 557 369 240 557 minecraft:green_terracotta
setblock 369 179 562 minecraft:oak_log
fill 369 179 563 369 181 563 minecraft:green_terracotta
setblock 369 179 567 minecraft:oak_log
fill 369 179 568 369 182 568 minecraft:green_terracotta
setblock 369 179 572 minecraft:oak_log
schedule function dropper:buildpart/139_5 1t
