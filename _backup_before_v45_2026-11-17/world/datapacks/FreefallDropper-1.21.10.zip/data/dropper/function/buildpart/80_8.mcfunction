setblock 405 255 362 minecraft:polished_deepslate
fill 405 255 363 405 258 364 minecraft:gray_concrete
setblock 406 255 361 minecraft:polished_deepslate
fill 406 255 362 408 255 363 minecraft:gray_concrete
fill 407 255 361 407 258 361 minecraft:gray_concrete
setblock 408 255 323 minecraft:gray_concrete
fill 408 255 360 409 255 360 minecraft:gray_concrete
setblock 409 255 323 minecraft:polished_deepslate
fill 409 255 361 409 255 362 minecraft:gray_concrete
setblock 409 255 363 minecraft:polished_deepslate
fill 410 255 323 410 258 323 minecraft:gray_concrete
setblock 410 255 361 minecraft:gray_concrete
setblock 410 255 362 minecraft:polished_deepslate
fill 410 255 363 410 258 363 minecraft:gray_concrete
setblock 411 255 361 minecraft:polished_deepslate
fill 411 255 362 411 258 362 minecraft:gray_concrete
setblock 412 255 361 minecraft:gray_concrete
fill 414 255 336 414 255 337 minecraft:gray_concrete
setblock 414 255 338 minecraft:polished_deepslate
setblock 414 255 339 minecraft:gray_concrete
setblock 414 255 363 minecraft:polished_deepslate
setblock 415 255 333 minecraft:gray_concrete
setblock 415 255 337 minecraft:polished_deepslate
fill 415 255 338 415 258 338 minecraft:gray_concrete
setblock 415 255 363 minecraft:gray_concrete
setblock 416 255 331 minecraft:polished_deepslate
fill 416 255 332 416 256 332 minecraft:gray_concrete
setblock 416 255 336 minecraft:polished_deepslate
fill 416 255 337 416 258 337 minecraft:gray_concrete
setblock 416 255 341 minecraft:polished_deepslate
fill 416 255 342 416 258 342 minecraft:gray_concrete
setblock 416 255 356 minecraft:polished_deepslate
setblock 416 255 357 minecraft:gray_concrete
setblock 417 255 330 minecraft:polished_deepslate
fill 417 255 331 417 257 331 minecraft:gray_concrete
setblock 417 255 335 minecraft:polished_deepslate
fill 417 255 336 417 258 336 minecraft:gray_concrete
setblock 417 255 340 minecraft:polished_deepslate
fill 417 255 341 417 258 341 minecraft:gray_concrete
setblock 417 255 345 minecraft:polished_deepslate
setblock 417 255 346 minecraft:gray_concrete
setblock 417 255 350 minecraft:polished_deepslate
setblock 417 255 351 minecraft:gray_concrete
setblock 417 255 355 minecraft:polished_deepslate
fill 417 255 356 417 256 356 minecraft:gray_concrete
setblock 417 255 360 minecraft:polished_deepslate
setblock 417 255 361 minecraft:gray_concrete
fill 418 255 343 418 308 343 minecraft:gray_concrete
fill 376 256 344 376 263 346 minecraft:gray_concrete
setblock 376 256 347 minecraft:light_blue_stained_glass
fill 376 256 348 376 308 348 minecraft:gray_concrete
fill 376 256 361 376 262 361 minecraft:gray_concrete
setblock 377 256 329 minecraft:polished_deepslate
fill 377 256 330 377 256 333 minecraft:gray_concrete
setblock 377 256 334 minecraft:polished_deepslate
fill 377 256 335 377 259 335 minecraft:gray_concrete
setblock 377 256 339 minecraft:polished_deepslate
fill 377 256 340 377 259 340 minecraft:gray_concrete
setblock 377 256 359 minecraft:polished_deepslate
fill 377 256 360 377 257 360 minecraft:gray_concrete
setblock 378 256 333 minecraft:polished_deepslate
fill 378 256 334 378 257 334 minecraft:gray_concrete
setblock 378 256 338 minecraft:polished_deepslate
fill 378 256 339 378 257 339 minecraft:gray_concrete
fill 380 256 323 382 256 323 minecraft:gray_concrete
fill 381 256 363 382 256 363 minecraft:gray_concrete
setblock 383 256 323 minecraft:polished_deepslate
setblock 383 256 362 minecraft:gray_concrete
setblock 383 256 363 minecraft:polished_deepslate
fill 384 256 323 384 258 324 minecraft:gray_concrete
setblock 384 256 362 minecraft:polished_deepslate
fill 384 256 363 387 256 363 minecraft:gray_concrete
setblock 385 256 361 minecraft:polished_deepslate
fill 385 256 362 388 256 362 minecraft:gray_concrete
setblock 386 256 322 minecraft:light_blue_stained_glass
fill 386 256 323 386 256 324 minecraft:gray_concrete
fill 386 256 361 389 256 361 minecraft:gray_concrete
setblock 387 256 324 minecraft:polished_deepslate
fill 387 256 360 390 256 360 minecraft:gray_concrete
setblock 388 256 323 minecraft:polished_deepslate
fill 388 256 324 388 259 324 minecraft:gray_concrete
fill 388 256 331 388 261 332 minecraft:black_concrete
setblock 388 256 363 minecraft:polished_deepslate
fill 389 256 323 389 259 323 minecraft:gray_concrete
fill 389 256 330 389 261 330 minecraft:black_concrete
fill 389 256 333 390 261 333 minecraft:black_concrete
setblock 389 256 362 minecraft:polished_deepslate
fill 389 256 363 389 259 363 minecraft:gray_concrete
setblock 390 256 361 minecraft:polished_deepslate
fill 390 256 362 390 259 362 minecraft:gray_concrete
setblock 391 256 360 minecraft:polished_deepslate
fill 391 256 361 391 259 361 minecraft:gray_concrete
setblock 392 256 324 minecraft:polished_deepslate
fill 392 256 360 392 258 360 minecraft:gray_concrete
setblock 393 256 323 minecraft:polished_deepslate
setblock 393 256 363 minecraft:polished_deepslate
fill 394 256 323 394 258 323 minecraft:gray_concrete
setblock 394 256 362 minecraft:polished_deepslate
fill 394 256 363 394 259 363 minecraft:gray_concrete
setblock 395 256 361 minecraft:polished_deepslate
fill 395 256 362 398 256 362 minecraft:gray_concrete
fill 396 256 361 396 257 361 minecraft:gray_concrete
setblock 397 256 363 minecraft:gray_concrete
setblock 398 256 363 minecraft:yellow_concrete
setblock 399 256 362 minecraft:polished_deepslate
fill 399 256 363 402 256 363 minecraft:gray_concrete
fill 400 256 362 403 256 362 minecraft:gray_concrete
setblock 403 256 363 minecraft:polished_deepslate
setblock 404 256 361 minecraft:gray_concrete
setblock 404 256 362 minecraft:polished_deepslate
fill 404 256 363 404 259 363 minecraft:gray_concrete
setblock 405 256 361 minecraft:polished_deepslate
fill 405 256 362 408 256 362 minecraft:gray_concrete
fill 406 256 361 406 259 361 minecraft:gray_concrete
fill 406 256 363 407 256 363 minecraft:gray_concrete
setblock 407 256 323 minecraft:gray_concrete
setblock 408 256 323 minecraft:polished_deepslate
setblock 408 256 360 minecraft:gray_concrete
setblock 408 256 363 minecraft:polished_deepslate
fill 409 256 323 409 259 323 minecraft:gray_concrete
setblock 409 256 361 minecraft:gray_concrete
setblock 409 256 362 minecraft:polished_deepslate
fill 409 256 363 409 259 363 minecraft:gray_concrete
setblock 410 256 361 minecraft:polished_deepslate
fill 410 256 362 410 259 362 minecraft:gray_concrete
fill 411 256 323 411 257 323 minecraft:gray_concrete
fill 411 256 361 411 257 361 minecraft:gray_concrete
setblock 413 256 363 minecraft:polished_deepslate
setblock 414 256 337 minecraft:polished_deepslate
setblock 414 256 338 minecraft:gray_concrete
fill 414 256 363 414 257 363 minecraft:gray_concrete
setblock 415 256 336 minecraft:polished_deepslate
fill 415 256 337 415 258 337 minecraft:gray_concrete
setblock 415 256 340 minecraft:gray_concrete
setblock 415 256 341 minecraft:polished_deepslate
setblock 416 256 335 minecraft:polished_deepslate
fill 416 256 336 416 259 336 minecraft:gray_concrete
setblock 416 256 340 minecraft:polished_deepslate
fill 416 256 341 416 259 341 minecraft:gray_concrete
setblock 417 256 330 minecraft:gray_concrete
setblock 417 256 334 minecraft:polished_deepslate
fill 417 256 335 417 259 335 minecraft:gray_concrete
setblock 417 256 339 minecraft:polished_deepslate
fill 417 256 340 417 259 340 minecraft:gray_concrete
setblock 417 256 344 minecraft:polished_deepslate
setblock 417 256 345 minecraft:gray_concrete
setblock 417 256 354 minecraft:polished_deepslate
setblock 417 256 355 minecraft:gray_concrete
setblock 417 256 359 minecraft:polished_deepslate
setblock 417 256 360 minecraft:gray_concrete
fill 418 256 336 418 308 336 minecraft:gray_concrete
setblock 418 256 337 minecraft:light_blue_stained_glass
fill 418 256 338 418 308 339 minecraft:gray_concrete
fill 376 257 347 376 308 347 minecraft:gray_concrete
fill 377 257 329 377 257 332 minecraft:gray_concrete
setblock 377 257 333 minecraft:polished_deepslate
fill 377 257 334 377 259 334 minecraft:gray_concrete
setblock 377 257 338 minecraft:polished_deepslate
fill 377 257 339 377 260 339 minecraft:gray_concrete
setblock 377 257 359 minecraft:gray_concrete
setblock 378 257 333 minecraft:gray_concrete
setblock 378 257 337 minecraft:polished_deepslate
setblock 378 257 338 minecraft:gray_concrete
fill 380 257 323 381 257 323 minecraft:gray_concrete
fill 380 257 363 381 257 363 minecraft:gray_concrete
setblock 382 257 323 minecraft:polished_deepslate
setblock 382 257 362 minecraft:gray_concrete
setblock 382 257 363 minecraft:polished_deepslate
fill 383 257 323 383 260 323 minecraft:gray_concrete
setblock 383 257 362 minecraft:polished_deepslate
fill 383 257 363 386 257 363 minecraft:gray_concrete
setblock 384 257 361 minecraft:polished_deepslate
fill 384 257 362 387 257 362 minecraft:gray_concrete
fill 385 257 361 388 257 361 minecraft:gray_concrete
fill 386 257 322 386 257 323 minecraft:gray_concrete
setblock 386 257 324 minecraft:polished_deepslate
fill 387 257 322 387 279 322 minecraft:gray_concrete
setblock 387 257 323 minecraft:polished_deepslate
fill 387 257 324 387 260 324 minecraft:gray_concrete
fill 387 257 360 389 257 360 minecraft:gray_concrete
setblock 387 257 363 minecraft:polished_deepslate
fill 388 257 323 388 260 323 minecraft:gray_concrete
fill 388 257 330 388 261 330 minecraft:black_concrete
fill 388 257 333 388 261 333 minecraft:black_concrete
setblock 388 257 362 minecraft:polished_deepslate
fill 388 257 363 388 260 363 minecraft:gray_concrete
setblock 389 257 361 minecraft:polished_deepslate
fill 389 257 362 389 260 362 minecraft:gray_concrete
fill 390 257 330 390 261 330 minecraft:black_concrete
setblock 390 257 360 minecraft:polished_deepslate
fill 390 257 361 390 260 361 minecraft:gray_concrete
setblock 391 257 324 minecraft:polished_deepslate
fill 391 257 331 391 261 332 minecraft:black_concrete
fill 391 257 360 391 258 360 minecraft:gray_concrete
setblock 392 257 323 minecraft:polished_deepslate
setblock 392 257 324 minecraft:gray_concrete
setblock 392 257 363 minecraft:polished_deepslate
fill 393 257 323 393 260 323 minecraft:gray_concrete
setblock 393 257 362 minecraft:polished_deepslate
fill 393 257 363 393 260 363 minecraft:gray_concrete
setblock 394 257 361 minecraft:polished_deepslate
fill 394 257 362 397 257 362 minecraft:gray_concrete
fill 395 257 361 395 258 361 minecraft:gray_concrete
setblock 397 257 363 minecraft:polished_deepslate
setblock 398 257 362 minecraft:polished_deepslate
setblock 398 257 363 minecraft:gray_concrete
fill 399 257 362 402 257 362 minecraft:gray_concrete
setblock 399 257 363 minecraft:yellow_concrete
fill 400 257 363 401 257 363 minecraft:gray_concrete
setblock 402 257 363 minecraft:polished_deepslate
setblock 403 257 361 minecraft:gray_concrete
setblock 403 257 362 minecraft:polished_deepslate
fill 403 257 363 403 260 363 minecraft:gray_concrete
setblock 404 257 361 minecraft:polished_deepslate
fill 404 257 362 407 257 362 minecraft:gray_concrete
fill 405 257 361 405 260 361 minecraft:gray_concrete
setblock 406 257 363 minecraft:gray_concrete
setblock 407 257 323 minecraft:polished_deepslate
setblock 407 257 363 minecraft:polished_deepslate
fill 408 257 323 408 260 323 minecraft:gray_concrete
setblock 408 257 362 minecraft:polished_deepslate
fill 408 257 363 408 260 363 minecraft:gray_concrete
setblock 409 257 361 minecraft:polished_deepslate
fill 409 257 362 409 260 362 minecraft:gray_concrete
fill 410 257 361 410 258 361 minecraft:gray_concrete
setblock 412 257 363 minecraft:polished_deepslate
fill 413 257 363 413 259 363 minecraft:gray_concrete
setblock 415 257 335 minecraft:polished_deepslate
setblock 415 257 336 minecraft:gray_concrete
setblock 415 257 340 minecraft:polished_deepslate
setblock 415 257 341 minecraft:gray_concrete
setblock 416 257 334 minecraft:polished_deepslate
fill 416 257 335 416 258 335 minecraft:gray_concrete
setblock 416 257 339 minecraft:polished_deepslate
fill 416 257 340 416 260 340 minecraft:gray_concrete
setblock 417 257 333 minecraft:polished_deepslate
fill 417 257 334 417 260 334 minecraft:gray_concrete
setblock 417 257 338 minecraft:polished_deepslate
fill 417 257 339 417 260 339 minecraft:gray_concrete
setblock 417 257 343 minecraft:polished_deepslate
fill 417 257 344 417 259 344 minecraft:gray_concrete
setblock 417 257 358 minecraft:polished_deepslate
setblock 417 257 359 minecraft:gray_concrete
fill 418 257 330 418 308 330 minecraft:gray_concrete
setblock 418 257 331 minecraft:light_blue_stained_glass
fill 418 257 332 418 308 333 minecraft:gray_concrete
fill 418 257 337 418 308 337 minecraft:gray_concrete
fill 376 258 341 376 308 341 minecraft:gray_concrete
setblock 376 258 342 minecraft:light_blue_stained_glass
setblock 377 258 331 minecraft:gray_concrete
setblock 377 258 332 minecraft:polished_deepslate
fill 377 258 333 377 259 333 minecraft:gray_concrete
setblock 377 258 337 minecraft:polished_deepslate
fill 377 258 338 377 261 338 minecraft:gray_concrete
setblock 378 258 336 minecraft:polished_deepslate
setblock 378 258 337 minecraft:gray_concrete
fill 379 258 323 380 258 323 minecraft:gray_concrete
fill 379 258 363 380 258 363 minecraft:gray_concrete
setblock 381 258 323 minecraft:polished_deepslate
setblock 381 258 363 minecraft:polished_deepslate
fill 382 258 323 382 261 323 minecraft:gray_concrete
setblock 382 258 362 minecraft:polished_deepslate
fill 382 258 363 385 258 363 minecraft:gray_concrete
fill 383 258 324 383 259 324 minecraft:gray_concrete
fill 383 258 362 386 258 362 minecraft:gray_concrete
fill 384 258 361 387 258 361 minecraft:gray_concrete
setblock 385 258 323 minecraft:gray_concrete
setblock 385 258 324 minecraft:polished_deepslate
fill 386 258 322 386 288 322 minecraft:gray_concrete
setblock 386 258 323 minecraft:polished_deepslate
fill 386 258 324 386 261 324 minecraft:gray_concrete
fill 386 258 360 388 258 360 minecraft:gray_concrete
setblock 386 258 363 minecraft:polished_deepslate
fill 387 258 323 387 261 323 minecraft:gray_concrete
fill 387 258 331 387 261 332 minecraft:black_concrete
setblock 387 258 362 minecraft:polished_deepslate
fill 387 258 363 387 261 363 minecraft:gray_concrete
setblock 388 258 361 minecraft:polished_deepslate
fill 388 258 362 388 261 362 minecraft:gray_concrete
fill 389 258 329 389 261 329 minecraft:black_concrete
fill 389 258 334 390 261 334 minecraft:black_concrete
setblock 389 258 360 minecraft:polished_deepslate
fill 389 258 361 389 261 361 minecraft:gray_concrete
setblock 390 258 324 minecraft:polished_deepslate
fill 390 258 360 390 259 360 minecraft:gray_concrete
setblock 391 258 323 minecraft:polished_deepslate
setblock 391 258 324 minecraft:gray_concrete
fill 391 258 330 391 261 330 minecraft:black_concrete
fill 391 258 333 391 261 333 minecraft:black_concrete
setblock 391 258 363 minecraft:polished_deepslate
fill 392 258 322 392 261 323 minecraft:gray_concrete
setblock 392 258 362 minecraft:polished_deepslate
fill 392 258 363 392 261 363 minecraft:gray_concrete
fill 393 258 322 393 308 322 minecraft:gray_concrete
setblock 393 258 361 minecraft:polished_deepslate
fill 393 258 362 396 258 362 minecraft:gray_concrete
setblock 394 258 322 minecraft:light_blue_stained_glass
fill 394 258 361 394 259 361 minecraft:gray_concrete
setblock 395 258 363 minecraft:gray_concrete
setblock 396 258 363 minecraft:polished_deepslate
setblock 397 258 362 minecraft:polished_deepslate
setblock 397 258 363 minecraft:gray_concrete
fill 398 258 362 401 258 362 minecraft:gray_concrete
setblock 398 258 363 minecraft:yellow_concrete
fill 399 258 363 400 258 363 minecraft:gray_concrete
setblock 401 258 363 minecraft:polished_deepslate
setblock 402 258 362 minecraft:polished_deepslate
fill 402 258 363 402 261 363 minecraft:gray_concrete
fill 403 258 362 406 258 362 minecraft:gray_concrete
fill 404 258 361 404 259 361 minecraft:gray_concrete
setblock 406 258 363 minecraft:polished_deepslate
fill 407 258 323 407 261 323 minecraft:gray_concrete
setblock 407 258 362 minecraft:polished_deepslate
fill 407 258 363 407 261 363 minecraft:gray_concrete
setblock 408 258 361 minecraft:polished_deepslate
fill 408 258 362 408 261 362 minecraft:gray_concrete
setblock 409 258 361 minecraft:gray_concrete
setblock 411 258 363 minecraft:polished_deepslate
setblock 412 258 362 minecraft:polished_deepslate
fill 412 258 363 412 260 363 minecraft:gray_concrete
setblock 415 258 339 minecraft:polished_deepslate
setblock 415 258 340 minecraft:gray_concrete
setblock 416 258 334 minecraft:gray_concrete
setblock 416 258 338 minecraft:polished_deepslate
fill 416 258 339 416 261 339 minecraft:gray_concrete
setblock 417 258 332 minecraft:polished_deepslate
fill 417 258 333 417 259 333 minecraft:gray_concrete
setblock 417 258 337 minecraft:polished_deepslate
fill 417 258 338 417 261 338 minecraft:gray_concrete
setblock 417 258 342 minecraft:polished_deepslate
fill 417 258 343 417 261 343 minecraft:gray_concrete
fill 418 258 331 418 308 331 minecraft:gray_concrete
fill 418 258 342 418 264 342 minecraft:gray_concrete
setblock 376 259 329 minecraft:light_blue_stained_glass
fill 376 259 330 376 308 333 minecraft:gray_concrete
fill 376 259 342 376 308 342 minecraft:gray_concrete
setblock 377 259 336 minecraft:polished_deepslate
fill 377 259 337 377 261 337 minecraft:gray_concrete
setblock 377 259 341 minecraft:polished_deepslate
fill 378 259 323 379 259 323 minecraft:gray_concrete
setblock 379 259 363 minecraft:gray_concrete
setblock 380 259 323 minecraft:polished_deepslate
setblock 380 259 363 minecraft:polished_deepslate
fill 381 259 323 381 262 323 minecraft:gray_concrete
fill 381 259 363 384 259 363 minecraft:gray_concrete
fill 382 259 362 385 259 362 minecraft:gray_concrete
setblock 384 259 323 minecraft:gray_concrete
setblock 384 259 324 minecraft:polished_deepslate
fill 384 259 361 386 259 361 minecraft:gray_concrete
setblock 385 259 323 minecraft:polished_deepslate
fill 385 259 324 385 262 324 minecraft:gray_concrete
setblock 385 259 363 minecraft:polished_deepslate
fill 386 259 323 386 262 323 minecraft:gray_concrete
setblock 386 259 362 minecraft:polished_deepslate
fill 386 259 363 386 262 363 minecraft:gray_concrete
fill 387 259 330 387 261 330 minecraft:black_concrete
fill 387 259 333 387 261 333 minecraft:black_concrete
setblock 387 259 360 minecraft:gray_concrete
setblock 387 259 361 minecraft:polished_deepslate
fill 387 259 362 387 262 362 minecraft:gray_concrete
fill 388 259 329 388 261 329 minecraft:black_concrete
fill 388 259 334 388 261 334 minecraft:black_concrete
setblock 388 259 360 minecraft:polished_deepslate
fill 388 259 361 388 262 361 minecraft:gray_concrete
setblock 389 259 324 minecraft:polished_deepslate
setblock 389 259 360 minecraft:gray_concrete
setblock 390 259 323 minecraft:polished_deepslate
fill 390 259 324 390 260 324 minecraft:gray_concrete
fill 390 259 329 390 261 329 minecraft:black_concrete
setblock 390 259 363 minecraft:polished_deepslate
fill 391 259 323 391 262 323 minecraft:gray_concrete
fill 391 259 334 391 261 334 minecraft:black_concrete
setblock 391 259 362 minecraft:polished_deepslate
fill 391 259 363 391 262 363 minecraft:gray_concrete
fill 392 259 331 392 261 332 minecraft:black_concrete
setblock 392 259 361 minecraft:polished_deepslate
fill 392 259 362 395 259 362 minecraft:gray_concrete
fill 393 259 361 393 260 361 minecraft:gray_concrete
fill 394 259 322 394 262 322 minecraft:gray_concrete
setblock 395 259 363 minecraft:polished_deepslate
setblock 396 259 362 minecraft:polished_deepslate
setblock 396 259 363 minecraft:gray_concrete
fill 397 259 362 400 259 362 minecraft:gray_concrete
setblock 397 259 363 minecraft:yellow_concrete
fill 398 259 363 399 259 363 minecraft:gray_concrete
setblock 400 259 363 minecraft:polished_deepslate
setblock 401 259 362 minecraft:polished_deepslate
fill 401 259 363 401 262 363 minecraft:gray_concrete
fill 402 259 362 405 259 362 minecraft:gray_concrete
setblock 405 259 363 minecraft:polished_deepslate
fill 405 259 364 405 276 364 minecraft:gray_concrete
fill 406 259 323 406 262 323 minecraft:gray_concrete
setblock 406 259 362 minecraft:polished_deepslate
fill 406 259 363 406 262 363 minecraft:gray_concrete
setblock 407 259 361 minecraft:polished_deepslate
fill 407 259 362 407 262 362 minecraft:gray_concrete
setblock 408 259 361 minecraft:gray_concrete
setblock 410 259 323 minecraft:polished_deepslate
setblock 410 259 363 minecraft:polished_deepslate
setblock 411 259 362 minecraft:polished_deepslate
fill 411 259 363 411 262 363 minecraft:gray_concrete
setblock 416 259 337 minecraft:polished_deepslate
fill 416 259 338 416 260 338 minecraft:gray_concrete
setblock 416 259 342 minecraft:polished_deepslate
setblock 417 259 336 minecraft:polished_deepslate
fill 417 259 337 417 262 337 minecraft:gray_concrete
setblock 417 259 341 minecraft:polished_deepslate
fill 417 259 342 417 262 342 minecraft:gray_concrete
fill 376 260 329 376 308 329 minecraft:gray_concrete
setblock 377 260 335 minecraft:polished_deepslate
setblock 377 260 336 minecraft:gray_concrete
setblock 377 260 340 minecraft:polished_deepslate
setblock 378 260 323 minecraft:gray_concrete
setblock 378 260 363 minecraft:gray_concrete
setblock 379 260 323 minecraft:polished_deepslate
setblock 379 260 325 minecraft:light[level=12]
setblock 379 260 332 minecraft:light[level=12]
setblock 379 260 339 minecraft:light[level=12]
setblock 379 260 346 minecraft:light[level=12]
setblock 379 260 353 minecraft:light[level=12]
setblock 379 260 360 minecraft:light[level=12]
setblock 379 260 363 minecraft:polished_deepslate
fill 380 260 323 380 263 323 minecraft:gray_concrete
fill 380 260 363 383 260 363 minecraft:gray_concrete
fill 381 260 362 384 260 362 minecraft:gray_concrete
setblock 382 260 324 minecraft:gray_concrete
setblock 383 260 324 minecraft:polished_deepslate
fill 383 260 361 385 260 361 minecraft:gray_concrete
setblock 384 260 323 minecraft:polished_deepslate
fill 384 260 324 384 263 324 minecraft:gray_concrete
setblock 384 260 363 minecraft:polished_deepslate
fill 385 260 323 385 263 323 minecraft:gray_concrete
setblock 385 260 362 minecraft:polished_deepslate
fill 385 260 363 385 263 363 minecraft:gray_concrete
setblock 386 260 325 minecraft:light[level=12]
fill 386 260 330 386 261 333 minecraft:black_concrete
setblock 386 260 339 minecraft:light[level=12]
setblock 386 260 346 minecraft:light[level=12]
setblock 386 260 353 minecraft:light[level=12]
setblock 386 260 360 minecraft:light[level=12]
setblock 386 260 361 minecraft:polished_deepslate
fill 386 260 362 386 263 362 minecraft:gray_concrete
fill 387 260 329 387 261 329 minecraft:black_concrete
fill 387 260 334 387 261 334 minecraft:black_concrete
setblock 387 260 360 minecraft:polished_deepslate
fill 387 260 361 387 263 361 minecraft:gray_concrete
setblock 388 260 324 minecraft:polished_deepslate
setblock 388 260 360 minecraft:gray_concrete
setblock 389 260 323 minecraft:polished_deepslate
fill 389 260 324 389 263 324 minecraft:gray_concrete
fill 389 260 335 390 261 335 minecraft:black_concrete
setblock 389 260 363 minecraft:polished_deepslate
fill 390 260 323 390 263 323 minecraft:gray_concrete
setblock 390 260 362 minecraft:polished_deepslate
fill 390 260 363 390 263 363 minecraft:gray_concrete
fill 391 260 329 391 261 329 minecraft:black_concrete
setblock 391 260 361 minecraft:polished_deepslate
fill 391 260 362 394 260 362 minecraft:gray_concrete
fill 392 260 330 392 261 330 minecraft:black_concrete
fill 392 260 333 392 261 333 minecraft:black_concrete
fill 392 260 361 392 261 361 minecraft:gray_concrete
setblock 393 260 325 minecraft:light[level=12]
setblock 393 260 332 minecraft:light[level=12]
setblock 393 260 339 minecraft:light[level=12]
setblock 393 260 346 minecraft:light[level=12]
setblock 393 260 353 minecraft:light[level=12]
setblock 393 260 360 minecraft:light[level=12]
setblock 394 260 363 minecraft:polished_deepslate
setblock 395 260 362 minecraft:polished_deepslate
fill 395 260 363 395 263 363 minecraft:gray_concrete
setblock 396 260 362 minecraft:gray_concrete
setblock 396 260 363 minecraft:ochre_froglight
fill 397 260 363 398 260 363 minecraft:gray_concrete
setblock 399 260 363 minecraft:polished_deepslate
setblock 400 260 325 minecraft:light[level=12]
setblock 400 260 332 minecraft:light[level=12]
setblock 400 260 339 minecraft:light[level=12]
setblock 400 260 346 minecraft:light[level=12]
setblock 400 260 353 minecraft:light[level=12]
setblock 400 260 360 minecraft:light[level=12]
setblock 400 260 362 minecraft:polished_deepslate
fill 400 260 363 400 263 363 minecraft:gray_concrete
fill 401 260 362 404 260 362 minecraft:gray_concrete
setblock 404 260 363 minecraft:polished_deepslate
fill 405 260 323 405 263 323 minecraft:gray_concrete
setblock 405 260 362 minecraft:polished_deepslate
fill 405 260 363 405 263 363 minecraft:gray_concrete
setblock 406 260 361 minecraft:polished_deepslate
fill 406 260 362 406 263 362 minecraft:gray_concrete
setblock 407 260 325 minecraft:light[level=12]
setblock 407 260 332 minecraft:light[level=12]
setblock 407 260 339 minecraft:light[level=12]
setblock 407 260 346 minecraft:light[level=12]
setblock 407 260 353 minecraft:light[level=12]
setblock 407 260 360 minecraft:light[level=12]
setblock 407 260 361 minecraft:gray_concrete
setblock 409 260 323 minecraft:polished_deepslate
setblock 409 260 363 minecraft:polished_deepslate
setblock 410 260 362 minecraft:polished_deepslate
fill 410 260 363 410 263 363 minecraft:gray_concrete
setblock 414 260 325 minecraft:light[level=12]
setblock 414 260 332 minecraft:light[level=12]
setblock 414 260 339 minecraft:light[level=12]
setblock 414 260 346 minecraft:light[level=12]
setblock 414 260 353 minecraft:light[level=12]
setblock 414 260 360 minecraft:light[level=12]
setblock 416 260 337 minecraft:gray_concrete
setblock 416 260 341 minecraft:polished_deepslate
setblock 417 260 335 minecraft:polished_deepslate
fill 417 260 336 417 263 336 minecraft:gray_concrete
setblock 417 260 340 minecraft:polished_deepslate
fill 417 260 341 417 263 341 minecraft:gray_concrete
setblock 377 261 323 minecraft:gray_concrete
setblock 377 261 339 minecraft:polished_deepslate
setblock 377 261 340 minecraft:gray_concrete
setblock 378 261 323 minecraft:polished_deepslate
setblock 378 261 363 minecraft:polished_deepslate
fill 379 261 323 379 264 323 minecraft:gray_concrete
fill 379 261 363 382 261 363 minecraft:gray_concrete
setblock 380 261 322 minecraft:light_blue_stained_glass
setblock 381 261 324 minecraft:gray_concrete
fill 381 261 362 383 261 362 minecraft:gray_concrete
setblock 382 261 324 minecraft:polished_deepslate
setblock 383 261 323 minecraft:polished_deepslate
fill 383 261 324 383 264 324 minecraft:gray_concrete
fill 383 261 361 384 261 361 minecraft:gray_concrete
setblock 383 261 363 minecraft:polished_deepslate
fill 384 261 323 384 264 323 minecraft:gray_concrete
setblock 384 261 362 minecraft:polished_deepslate
fill 384 261 363 384 264 363 minecraft:gray_concrete
setblock 385 261 361 minecraft:polished_deepslate
fill 385 261 362 385 264 362 minecraft:gray_concrete
setblock 386 261 334 minecraft:black_concrete
fill 386 261 361 386 264 361 minecraft:gray_concrete
setblock 387 261 324 minecraft:polished_deepslate
setblock 388 261 323 minecraft:polished_deepslate
fill 388 261 324 388 264 324 minecraft:gray_concrete
fill 388 261 328 391 261 328 minecraft:black_concrete
setblock 388 261 335 minecraft:black_concrete
setblock 388 261 363 minecraft:polished_deepslate
fill 389 261 323 389 264 323 minecraft:gray_concrete
setblock 389 261 362 minecraft:polished_deepslate
fill 389 261 363 389 264 363 minecraft:gray_concrete
setblock 390 261 361 minecraft:polished_deepslate
fill 390 261 362 393 261 362 minecraft:gray_concrete
setblock 391 261 335 minecraft:black_concrete
fill 391 261 361 391 262 361 minecraft:gray_concrete
setblock 392 261 329 minecraft:black_concrete
setblock 392 261 334 minecraft:black_concrete
fill 393 261 331 393 261 332 minecraft:black_concrete
setblock 393 261 363 minecraft:polished_deepslate
setblock 394 261 362 minecraft:polished_deepslate
fill 394 261 363 394 264 363 minecraft:gray_concrete
setblock 395 261 362 minecraft:gray_concrete
fill 396 261 363 397 261 363 minecraft:gray_concrete
setblock 398 261 363 minecraft:polished_deepslate
fill 399 261 363 399 264 363 minecraft:gray_concrete
fill 400 261 362 403 261 362 minecraft:gray_concrete
setblock 403 261 363 minecraft:polished_deepslate
fill 404 261 323 404 264 323 minecraft:gray_concrete
setblock 404 261 362 minecraft:polished_deepslate
fill 404 261 363 404 264 363 minecraft:gray_concrete
fill 405 261 362 405 264 362 minecraft:gray_concrete
setblock 408 261 323 minecraft:polished_deepslate
setblock 408 261 363 minecraft:polished_deepslate
fill 409 261 323 409 264 323 minecraft:gray_concrete
setblock 409 261 362 minecraft:polished_deepslate
fill 409 261 363 409 264 363 minecraft:gray_concrete
setblock 416 261 340 minecraft:polished_deepslate
setblock 416 261 341 minecraft:gray_concrete
setblock 417 261 335 minecraft:gray_concrete
setblock 417 261 339 minecraft:polished_deepslate
fill 417 261 340 417 264 340 minecraft:gray_concrete
setblock 417 261 344 minecraft:polished_deepslate
setblock 417 261 364 minecraft:light_blue_stained_glass
fill 376 262 350 376 292 350 minecraft:gray_concrete
setblock 376 262 351 minecraft:light_blue_stained_glass
fill 376 262 352 376 308 354 minecraft:gray_concrete
setblock 377 262 323 minecraft:polished_deepslate
fill 377 262 324 377 264 325 minecraft:gray_concrete
setblock 377 262 363 minecraft:polished_deepslate
fill 378 262 323 378 265 323 minecraft:gray_concrete
fill 378 262 363 381 262 363 minecraft:gray_concrete
setblock 379 262 325 minecraft:light[level=13]
setblock 379 262 333 minecraft:light[level=13]
setblock 379 262 341 minecraft:light[level=13]
setblock 379 262 349 minecraft:light[level=13]
setblock 379 262 357 minecraft:light[level=13]
fill 380 262 322 380 273 322 minecraft:gray_concrete
setblock 380 262 324 minecraft:gray_concrete
fill 380 262 362 382 262 362 minecraft:gray_concrete
setblock 381 262 324 minecraft:polished_deepslate
setblock 382 262 323 minecraft:polished_deepslate
fill 382 262 324 382 265 324 minecraft:gray_concrete
setblock 382 262 363 minecraft:polished_deepslate
fill 383 262 323 383 265 323 minecraft:gray_concrete
setblock 383 262 361 minecraft:gray_concrete
setblock 383 262 362 minecraft:polished_deepslate
fill 383 262 363 383 265 363 minecraft:gray_concrete
setblock 384 262 361 minecraft:polished_deepslate
fill 384 262 362 384 265 362 minecraft:gray_concrete
fill 385 262 361 385 265 361 minecraft:gray_concrete
setblock 386 262 324 minecraft:polished_deepslate
setblock 387 262 323 minecraft:polished_deepslate
fill 387 262 324 387 265 324 minecraft:gray_concrete
setblock 387 262 325 minecraft:light[level=13]
setblock 387 262 333 minecraft:light[level=13]
setblock 387 262 341 minecraft:light[level=13]
setblock 387 262 349 minecraft:light[level=13]
setblock 387 262 357 minecraft:light[level=13]
setblock 387 262 363 minecraft:polished_deepslate
fill 388 262 323 388 265 323 minecraft:gray_concrete
fill 388 262 332 390 262 332 minecraft:light_blue_stained_glass
setblock 388 262 362 minecraft:polished_deepslate
fill 388 262 363 388 265 363 minecraft:gray_concrete
fill 389 262 331 390 263 331 minecraft:light_blue_stained_glass
setblock 389 262 361 minecraft:polished_deepslate
fill 389 262 362 392 262 362 minecraft:gray_concrete
fill 390 262 361 390 264 361 minecraft:gray_concrete
setblock 391 262 322 minecraft:light_blue_stained_glass
fill 392 262 322 392 308 322 minecraft:gray_concrete
setblock 392 262 323 minecraft:polished_deepslate
setblock 392 262 363 minecraft:polished_deepslate
setblock 392 262 364 minecraft:light_blue_stained_glass
setblock 393 262 362 minecraft:polished_deepslate
fill 393 262 363 393 265 364 minecraft:gray_concrete
fill 394 262 362 394 265 362 minecraft:gray_concrete
setblock 395 262 325 minecraft:light[level=13]
setblock 395 262 333 minecraft:light[level=13]
setblock 395 262 341 minecraft:light[level=13]
setblock 395 262 349 minecraft:light[level=13]
setblock 395 262 357 minecraft:light[level=13]
setblock 396 262 363 minecraft:gray_concrete
setblock 397 262 363 minecraft:polished_deepslate
fill 398 262 322 398 308 322 minecraft:gray_concrete
fill 398 262 363 398 265 363 minecraft:gray_concrete
setblock 399 262 322 minecraft:light_blue_stained_glass
fill 400 262 322 408 271 322 minecraft:gray_concrete
fill 400 262 362 402 262 362 minecraft:gray_concrete
setblock 402 262 363 minecraft:polished_deepslate
fill 403 262 323 403 265 323 minecraft:gray_concrete
setblock 403 262 325 minecraft:light[level=13]
setblock 403 262 333 minecraft:light[level=13]
setblock 403 262 341 minecraft:light[level=13]
setblock 403 262 349 minecraft:light[level=13]
setblock 403 262 357 minecraft:light[level=13]
setblock 403 262 362 minecraft:polished_deepslate
fill 403 262 363 403 265 363 minecraft:gray_concrete
fill 404 262 362 404 265 362 minecraft:gray_concrete
setblock 407 262 323 minecraft:polished_deepslate
fill 407 262 346 408 263 346 minecraft:white_wool
setblock 407 262 363 minecraft:polished_deepslate
fill 408 262 323 408 265 323 minecraft:gray_concrete
setblock 408 262 362 minecraft:polished_deepslate
fill 408 262 363 408 265 363 minecraft:gray_concrete
fill 410 262 323 410 263 323 minecraft:gray_concrete
setblock 411 262 325 minecraft:light[level=13]
setblock 411 262 333 minecraft:light[level=13]
setblock 411 262 341 minecraft:light[level=13]
setblock 411 262 349 minecraft:light[level=13]
setblock 411 262 357 minecraft:light[level=13]
setblock 417 262 338 minecraft:polished_deepslate
fill 417 262 339 417 265 339 minecraft:gray_concrete
setblock 417 262 343 minecraft:polished_deepslate
fill 417 262 344 417 265 344 minecraft:gray_concrete
fill 417 262 364 417 296 364 minecraft:gray_concrete
fill 376 263 351 376 284 351 minecraft:gray_concrete
setblock 376 263 361 minecraft:light_blue_stained_glass
fill 377 263 323 377 266 323 minecraft:gray_concrete
setblock 377 263 326 minecraft:gray_concrete
setblock 377 263 362 minecraft:polished_deepslate
fill 377 263 363 380 263 363 minecraft:gray_concrete
setblock 379 263 324 minecraft:gray_concrete
setblock 380 263 324 minecraft:polished_deepslate
fill 380 263 362 381 263 362 minecraft:gray_concrete
setblock 381 263 323 minecraft:polished_deepslate
fill 381 263 324 381 266 324 minecraft:gray_concrete
setblock 381 263 363 minecraft:polished_deepslate
fill 382 263 323 382 266 323 minecraft:gray_concrete
setblock 382 263 361 minecraft:gray_concrete
setblock 382 263 362 minecraft:polished_deepslate
fill 382 263 363 382 266 363 minecraft:gray_concrete
setblock 383 263 325 minecraft:gray_concrete
setblock 383 263 361 minecraft:polished_deepslate
fill 383 263 362 383 266 362 minecraft:gray_concrete
setblock 384 263 325 minecraft:polished_deepslate
fill 384 263 361 384 266 361 minecraft:gray_concrete
setblock 385 263 324 minecraft:polished_deepslate
fill 385 263 325 385 266 325 minecraft:gray_concrete
setblock 386 263 323 minecraft:polished_deepslate
fill 386 263 324 386 266 324 minecraft:gray_concrete
setblock 386 263 363 minecraft:polished_deepslate
fill 387 263 323 387 266 323 minecraft:gray_concrete
setblock 387 263 362 minecraft:polished_deepslate
fill 387 263 363 387 266 363 minecraft:gray_concrete
setblock 388 263 361 minecraft:polished_deepslate
fill 388 263 362 391 263 362 minecraft:gray_concrete
fill 389 263 332 390 263 332 minecraft:light_blue_stained_glass
fill 389 263 361 389 266 361 minecraft:gray_concrete
fill 391 263 322 391 308 322 minecraft:gray_concrete
setblock 391 263 323 minecraft:polished_deepslate
setblock 391 263 363 minecraft:polished_deepslate
fill 392 263 323 392 266 323 minecraft:gray_concrete
setblock 392 263 362 minecraft:polished_deepslate
fill 392 263 363 392 266 364 minecraft:gray_concrete
fill 393 263 362 393 266 362 minecraft:gray_concrete
setblock 394 263 322 minecraft:light_blue_stained_glass
setblock 396 263 363 minecraft:polished_deepslate
fill 397 263 363 397 266 363 minecraft:gray_concrete
fill 399 263 322 399 296 322 minecraft:gray_concrete
fill 399 263 362 401 263 362 minecraft:gray_concrete
setblock 401 263 323 minecraft:polished_deepslate
setblock 401 263 363 minecraft:polished_deepslate
fill 402 263 323 402 266 323 minecraft:gray_concrete
setblock 402 263 362 minecraft:polished_deepslate
fill 402 263 363 402 266 363 minecraft:gray_concrete
fill 403 263 362 403 266 362 minecraft:gray_concrete
fill 404 263 335 405 264 336 minecraft:gray_wool
setblock 406 263 323 minecraft:polished_deepslate
setblock 406 263 363 minecraft:polished_deepslate
fill 407 263 323 407 266 323 minecraft:gray_concrete
setblock 407 263 362 minecraft:polished_deepslate
fill 407 263 363 407 266 363 minecraft:gray_concrete
fill 408 263 362 408 264 362 minecraft:gray_concrete
setblock 411 263 363 minecraft:polished_deepslate
setblock 417 263 337 minecraft:polished_deepslate
fill 417 263 338 417 266 338 minecraft:gray_concrete
setblock 417 263 342 minecraft:polished_deepslate
fill 417 263 343 417 266 343 minecraft:gray_concrete
setblock 418 263 340 minecraft:light_blue_stained_glass
fill 376 264 344 376 295 344 minecraft:gray_concrete
setblock 376 264 345 minecraft:light_blue_stained_glass
fill 376 264 346 376 284 346 minecraft:gray_concrete
fill 376 264 361 376 308 361 minecraft:gray_concrete
setblock 377 264 326 minecraft:polished_deepslate
fill 377 264 327 377 267 327 minecraft:gray_concrete
setblock 377 264 340 minecraft:gray_concrete
setblock 377 264 341 minecraft:polished_deepslate
fill 377 264 342 377 267 342 minecraft:gray_concrete
setblock 377 264 361 minecraft:polished_deepslate
fill 377 264 362 377 266 363 minecraft:gray_concrete
setblock 378 264 324 minecraft:gray_concrete
setblock 378 264 325 minecraft:polished_deepslate
fill 378 264 363 379 264 363 minecraft:gray_concrete
setblock 379 264 324 minecraft:polished_deepslate
fill 379 264 362 380 264 362 minecraft:gray_concrete
setblock 380 264 323 minecraft:polished_deepslate
fill 380 264 324 380 267 324 minecraft:gray_concrete
setblock 380 264 363 minecraft:polished_deepslate
fill 381 264 323 381 267 323 minecraft:gray_concrete
fill 381 264 325 382 264 325 minecraft:gray_concrete
setblock 381 264 362 minecraft:polished_deepslate
fill 381 264 363 381 267 363 minecraft:gray_concrete
setblock 382 264 361 minecraft:polished_deepslate
fill 382 264 362 382 267 362 minecraft:gray_concrete
setblock 383 264 325 minecraft:polished_deepslate
fill 383 264 361 383 267 361 minecraft:gray_concrete
setblock 384 264 324 minecraft:polished_deepslate
fill 384 264 325 384 267 325 minecraft:gray_concrete
setblock 385 264 323 minecraft:polished_deepslate
fill 385 264 324 385 267 324 minecraft:gray_concrete
setblock 385 264 363 minecraft:polished_deepslate
fill 386 264 323 386 267 323 minecraft:gray_concrete
fill 386 264 325 386 265 325 minecraft:gray_concrete
setblock 386 264 362 minecraft:polished_deepslate
fill 386 264 363 386 267 363 minecraft:gray_concrete
setblock 387 264 361 minecraft:polished_deepslate
fill 387 264 362 390 264 362 minecraft:gray_concrete
fill 388 264 361 388 267 361 minecraft:gray_concrete
setblock 389 264 324 minecraft:polished_deepslate
fill 389 264 331 389 264 332 minecraft:light_blue_stained_glass
setblock 390 264 323 minecraft:polished_deepslate
setblock 390 264 363 minecraft:polished_deepslate
fill 391 264 323 391 267 323 minecraft:gray_concrete
setblock 391 264 362 minecraft:polished_deepslate
fill 391 264 363 391 267 363 minecraft:gray_concrete
fill 392 264 362 392 267 362 minecraft:gray_concrete
fill 393 264 323 393 265 323 minecraft:gray_concrete
fill 394 264 322 394 308 322 minecraft:gray_concrete
setblock 395 264 363 minecraft:polished_deepslate
fill 396 264 363 396 267 363 minecraft:gray_concrete
fill 398 264 362 400 264 362 minecraft:gray_concrete
setblock 400 264 323 minecraft:polished_deepslate
setblock 400 264 363 minecraft:polished_deepslate
fill 401 264 323 401 267 323 minecraft:gray_concrete
setblock 401 264 362 minecraft:polished_deepslate
fill 401 264 363 401 267 363 minecraft:gray_concrete
fill 402 264 362 402 267 362 minecraft:gray_concrete
setblock 405 264 323 minecraft:polished_deepslate
fill 405 264 324 405 267 324 minecraft:gray_concrete
setblock 405 264 363 minecraft:polished_deepslate
fill 406 264 323 406 267 323 minecraft:gray_concrete
setblock 406 264 362 minecraft:polished_deepslate
fill 406 264 363 406 267 363 minecraft:gray_concrete
fill 407 264 362 407 266 362 minecraft:gray_concrete
setblock 410 264 323 minecraft:polished_deepslate
setblock 410 264 363 minecraft:polished_deepslate
fill 411 264 323 412 266 323 minecraft:gray_concrete
fill 416 264 323 417 266 323 minecraft:gray_concrete
setblock 416 264 341 minecraft:gray_concrete
setblock 416 264 342 minecraft:polished_deepslate
fill 417 264 324 417 264 325 minecraft:gray_concrete
setblock 417 264 326 minecraft:polished_deepslate
setblock 417 264 336 minecraft:polished_deepslate
fill 417 264 337 417 267 337 minecraft:gray_concrete
setblock 417 264 341 minecraft:polished_deepslate
fill 417 264 342 417 267 342 minecraft:gray_concrete
setblock 417 264 345 minecraft:gray_concrete
fill 418 264 340 418 308 340 minecraft:gray_concrete
fill 376 265 345 376 301 345 minecraft:gray_concrete
setblock 376 265 358 minecraft:light_blue_stained_glass
setblock 377 265 324 minecraft:gray_concrete
setblock 377 265 325 minecraft:polished_deepslate
fill 377 265 326 378 267 326 minecraft:gray_concrete
fill 377 265 328 377 265 329 minecraft:gray_concrete
setblock 377 265 340 minecraft:polished_deepslate
fill 377 265 341 377 268 341 minecraft:gray_concrete
fill 377 265 343 377 265 344 minecraft:gray_concrete
fill 377 265 361 377 268 361 minecraft:gray_concrete
setblock 378 265 324 minecraft:polished_deepslate
fill 378 265 325 381 265 325 minecraft:gray_concrete
fill 378 265 327 378 266 327 minecraft:gray_concrete
fill 378 265 362 378 265 363 minecraft:gray_concrete
setblock 379 265 323 minecraft:polished_deepslate
fill 379 265 324 379 268 324 minecraft:gray_concrete
setblock 379 265 362 minecraft:gray_concrete
setblock 379 265 363 minecraft:polished_deepslate
fill 380 265 323 380 268 323 minecraft:gray_concrete
setblock 380 265 362 minecraft:polished_deepslate
fill 380 265 363 380 268 363 minecraft:gray_concrete
setblock 381 265 361 minecraft:polished_deepslate
fill 381 265 362 381 268 362 minecraft:gray_concrete
setblock 382 265 325 minecraft:polished_deepslate
fill 382 265 361 382 268 361 minecraft:gray_concrete
setblock 383 265 324 minecraft:polished_deepslate
fill 383 265 325 383 268 325 minecraft:gray_concrete
setblock 384 265 323 minecraft:polished_deepslate
fill 384 265 324 384 268 324 minecraft:gray_concrete
setblock 384 265 363 minecraft:polished_deepslate
fill 385 265 323 385 268 323 minecraft:gray_concrete
setblock 385 265 362 minecraft:polished_deepslate
fill 385 265 363 385 268 363 minecraft:gray_concrete
setblock 386 265 361 minecraft:polished_deepslate
fill 386 265 362 389 265 362 minecraft:gray_concrete
setblock 387 265 325 minecraft:polished_deepslate
fill 387 265 361 387 268 361 minecraft:gray_concrete
setblock 388 265 324 minecraft:polished_deepslate
setblock 389 265 323 minecraft:polished_deepslate
fill 389 265 324 390 267 324 minecraft:gray_concrete
setblock 389 265 332 minecraft:light_blue_stained_glass
setblock 389 265 363 minecraft:polished_deepslate
fill 390 265 323 390 268 323 minecraft:gray_concrete
setblock 390 265 362 minecraft:polished_deepslate
fill 390 265 363 390 268 363 minecraft:gray_concrete
fill 391 265 362 391 268 362 minecraft:gray_concrete
setblock 394 265 323 minecraft:polished_deepslate
setblock 394 265 363 minecraft:polished_deepslate
fill 395 265 363 395 268 363 minecraft:gray_concrete
fill 397 265 323 398 265 323 minecraft:gray_concrete
fill 397 265 362 399 265 362 minecraft:gray_concrete
setblock 399 265 323 minecraft:polished_deepslate
setblock 399 265 363 minecraft:polished_deepslate
fill 400 265 323 400 268 323 minecraft:gray_concrete
setblock 400 265 362 minecraft:polished_deepslate
fill 400 265 363 400 268 363 minecraft:gray_concrete
fill 401 265 362 401 268 362 minecraft:gray_concrete
setblock 402 265 324 minecraft:gray_concrete
setblock 403 265 324 minecraft:polished_deepslate
setblock 404 265 323 minecraft:polished_deepslate
fill 404 265 324 404 268 324 minecraft:gray_concrete
setblock 404 265 363 minecraft:polished_deepslate
fill 405 265 323 405 268 323 minecraft:gray_concrete
setblock 405 265 362 minecraft:polished_deepslate
fill 405 265 363 405 268 363 minecraft:gray_concrete
fill 406 265 324 407 265 324 minecraft:gray_concrete
fill 406 265 362 406 267 362 minecraft:gray_concrete
setblock 408 265 324 minecraft:polished_deepslate
setblock 409 265 323 minecraft:polished_deepslate
setblock 409 265 363 minecraft:polished_deepslate
fill 410 265 323 410 268 323 minecraft:gray_concrete
fill 410 265 363 410 267 363 minecraft:gray_concrete
setblock 413 265 323 minecraft:gray_concrete
setblock 414 265 323 minecraft:polished_deepslate
fill 415 265 323 415 268 323 minecraft:gray_concrete
setblock 416 265 340 minecraft:gray_concrete
setblock 416 265 341 minecraft:polished_deepslate
fill 416 265 342 416 267 343 minecraft:gray_concrete
setblock 417 265 324 minecraft:gray_concrete
setblock 417 265 325 minecraft:polished_deepslate
fill 417 265 326 417 265 329 minecraft:gray_concrete
setblock 417 265 335 minecraft:polished_deepslate
fill 417 265 336 417 268 336 minecraft:gray_concrete
setblock 417 265 340 minecraft:polished_deepslate
fill 417 265 341 417 268 341 minecraft:gray_concrete
setblock 417 265 345 minecraft:polished_deepslate
fill 417 265 346 417 268 346 minecraft:gray_concrete
setblock 418 265 342 minecraft:light_blue_stained_glass
fill 376 266 358 376 308 358 minecraft:gray_concrete
setblock 376 266 362 minecraft:light_blue_stained_glass
fill 376 266 363 376 308 364 minecraft:gray_concrete
setblock 377 266 324 minecraft:polished_deepslate
fill 377 266 325 380 266 325 minecraft:gray_concrete
setblock 377 266 328 minecraft:gray_concrete
setblock 377 266 329 minecraft:polished_deepslate
fill 377 266 330 377 268 331 minecraft:gray_concrete
setblock 377 266 339 minecraft:polished_deepslate
fill 377 266 340 377 269 340 minecraft:gray_concrete
setblock 377 266 343 minecraft:gray_concrete
setblock 377 266 344 minecraft:polished_deepslate
fill 377 266 345 377 268 346 minecraft:gray_concrete
fill 377 266 360 377 269 360 minecraft:gray_concrete
setblock 378 266 323 minecraft:polished_deepslate
fill 378 266 324 378 269 324 minecraft:gray_concrete
setblock 378 266 328 minecraft:polished_deepslate
fill 378 266 361 378 266 362 minecraft:gray_concrete
setblock 378 266 363 minecraft:polished_deepslate
fill 379 266 323 379 269 323 minecraft:gray_concrete
setblock 379 266 326 minecraft:gray_concrete
setblock 379 266 332 minecraft:light[level=12]
setblock 379 266 339 minecraft:light[level=12]
setblock 379 266 346 minecraft:light[level=12]
setblock 379 266 353 minecraft:light[level=12]
setblock 379 266 360 minecraft:light[level=12]
setblock 379 266 362 minecraft:polished_deepslate
fill 379 266 363 379 269 363 minecraft:gray_concrete
setblock 380 266 361 minecraft:polished_deepslate
fill 380 266 362 380 269 362 minecraft:gray_concrete
setblock 381 266 325 minecraft:polished_deepslate
fill 381 266 361 381 269 361 minecraft:gray_concrete
setblock 382 266 324 minecraft:polished_deepslate
fill 382 266 325 382 269 325 minecraft:gray_concrete
setblock 383 266 323 minecraft:polished_deepslate
fill 383 266 324 383 269 324 minecraft:gray_concrete
setblock 383 266 363 minecraft:polished_deepslate
fill 384 266 323 384 269 323 minecraft:gray_concrete
setblock 384 266 362 minecraft:polished_deepslate
fill 384 266 363 384 269 363 minecraft:gray_concrete
setblock 385 266 361 minecraft:polished_deepslate
fill 385 266 362 388 266 362 minecraft:gray_concrete
setblock 386 266 325 minecraft:polished_deepslate
setblock 386 266 332 minecraft:light[level=12]
setblock 386 266 339 minecraft:light[level=12]
setblock 386 266 346 minecraft:light[level=12]
setblock 386 266 353 minecraft:light[level=12]
setblock 386 266 360 minecraft:light[level=12]
fill 386 266 361 386 269 361 minecraft:gray_concrete
setblock 387 266 324 minecraft:polished_deepslate
fill 387 266 325 387 269 325 minecraft:gray_concrete
setblock 388 266 323 minecraft:polished_deepslate
fill 388 266 324 388 269 324 minecraft:gray_concrete
setblock 388 266 363 minecraft:polished_deepslate
fill 389 266 323 389 269 323 minecraft:gray_concrete
setblock 389 266 362 minecraft:polished_deepslate
fill 389 266 363 389 269 363 minecraft:gray_concrete
fill 390 266 362 390 269 362 minecraft:gray_concrete
fill 392 266 326 392 267 326 minecraft:gray_wool
setblock 393 266 323 minecraft:polished_deepslate
setblock 393 266 325 minecraft:light[level=12]
setblock 393 266 332 minecraft:light[level=12]
setblock 393 266 339 minecraft:light[level=12]
setblock 393 266 346 minecraft:light[level=12]
setblock 393 266 353 minecraft:light[level=12]
setblock 393 266 360 minecraft:light[level=12]
setblock 393 266 363 minecraft:polished_deepslate
fill 393 266 364 393 297 364 minecraft:gray_concrete
fill 394 266 323 397 266 323 minecraft:gray_concrete
fill 394 266 363 394 269 363 minecraft:gray_concrete
fill 396 266 362 398 266 362 minecraft:gray_concrete
setblock 398 266 323 minecraft:polished_deepslate
setblock 398 266 363 minecraft:polished_deepslate
fill 399 266 323 399 269 323 minecraft:gray_concrete
setblock 399 266 362 minecraft:polished_deepslate
fill 399 266 363 399 269 363 minecraft:gray_concrete
fill 400 266 324 401 266 324 minecraft:gray_concrete
setblock 400 266 325 minecraft:light[level=12]
setblock 400 266 332 minecraft:light[level=12]
setblock 400 266 339 minecraft:light[level=12]
setblock 400 266 346 minecraft:light[level=12]
setblock 400 266 353 minecraft:light[level=12]
setblock 400 266 360 minecraft:light[level=12]
fill 400 266 362 400 269 362 minecraft:gray_concrete
setblock 402 266 324 minecraft:polished_deepslate
setblock 403 266 323 minecraft:polished_deepslate
fill 403 266 324 403 269 324 minecraft:gray_concrete
setblock 403 266 363 minecraft:polished_deepslate
fill 404 266 323 404 269 323 minecraft:gray_concrete
setblock 404 266 362 minecraft:polished_deepslate
fill 404 266 363 404 269 363 minecraft:gray_concrete
fill 405 266 362 405 268 362 minecraft:gray_concrete
setblock 406 266 324 minecraft:gray_concrete
setblock 407 266 324 minecraft:polished_deepslate
setblock 407 266 325 minecraft:light[level=12]
setblock 407 266 332 minecraft:light[level=12]
setblock 407 266 339 minecraft:light[level=12]
setblock 407 266 346 minecraft:light[level=12]
setblock 407 266 353 minecraft:light[level=12]
setblock 407 266 360 minecraft:light[level=12]
setblock 408 266 323 minecraft:polished_deepslate
fill 408 266 324 409 268 324 minecraft:gray_concrete
setblock 408 266 363 minecraft:polished_deepslate
fill 409 266 323 409 269 323 minecraft:gray_concrete
fill 409 266 363 409 268 363 minecraft:gray_concrete
setblock 413 266 323 minecraft:polished_deepslate
fill 414 266 323 414 269 323 minecraft:gray_concrete
setblock 414 266 325 minecraft:light[level=12]
setblock 414 266 332 minecraft:light[level=12]
setblock 414 266 339 minecraft:light[level=12]
setblock 414 266 346 minecraft:light[level=12]
setblock 414 266 353 minecraft:light[level=12]
setblock 414 266 360 minecraft:light[level=12]
setblock 416 266 324 minecraft:gray_concrete
setblock 416 266 325 minecraft:polished_deepslate
setblock 416 266 340 minecraft:polished_deepslate
fill 416 266 341 416 269 341 minecraft:gray_concrete
setblock 416 266 344 minecraft:gray_concrete
setblock 417 266 324 minecraft:polished_deepslate
fill 417 266 325 417 266 328 minecraft:gray_concrete
setblock 417 266 329 minecraft:polished_deepslate
fill 417 266 330 417 266 333 minecraft:gray_concrete
setblock 417 266 334 minecraft:polished_deepslate
fill 417 266 335 417 269 335 minecraft:gray_concrete
setblock 417 266 339 minecraft:polished_deepslate
fill 417 266 340 417 269 340 minecraft:gray_concrete
setblock 417 266 344 minecraft:polished_deepslate
fill 417 266 345 417 269 345 minecraft:gray_concrete
fill 417 266 347 417 266 348 minecraft:gray_concrete
setblock 417 266 363 minecraft:gray_concrete
fill 418 266 342 418 296 342 minecraft:gray_concrete
setblock 376 267 334 minecraft:light_blue_stained_glass
fill 376 267 335 376 285 340 minecraft:gray_concrete
fill 376 267 362 377 267 362 minecraft:gray_concrete
setblock 377 267 323 minecraft:polished_deepslate
fill 377 267 324 377 269 325 minecraft:gray_concrete
setblock 377 267 328 minecraft:polished_deepslate
fill 377 267 329 378 269 329 minecraft:gray_concrete
setblock 377 267 332 minecraft:gray_concrete
fill 377 267 339 377 269 339 minecraft:gray_concrete
setblock 377 267 343 minecraft:polished_deepslate
fill 377 267 344 378 269 344 minecraft:gray_concrete
setblock 377 267 347 minecraft:gray_concrete
setblock 377 267 348 minecraft:polished_deepslate
setblock 377 267 363 minecraft:polished_deepslate
fill 378 267 323 378 270 323 minecraft:gray_concrete
fill 378 267 325 379 267 325 minecraft:gray_concrete
setblock 378 267 327 minecraft:polished_deepslate
fill 378 267 328 379 269 328 minecraft:gray_concrete
fill 378 267 330 378 268 330 minecraft:gray_concrete
setblock 378 267 361 minecraft:gray_concrete
setblock 378 267 362 minecraft:polished_deepslate
fill 378 267 363 378 270 363 minecraft:gray_concrete
setblock 379 267 326 minecraft:polished_deepslate
fill 379 267 327 379 270 327 minecraft:gray_concrete
fill 379 267 362 379 270 362 minecraft:gray_concrete
setblock 380 267 325 minecraft:polished_deepslate
fill 380 267 326 383 267 326 minecraft:gray_concrete
fill 380 267 361 380 270 361 minecraft:gray_concrete
setblock 381 267 324 minecraft:polished_deepslate
fill 381 267 325 381 270 325 minecraft:gray_concrete
setblock 382 267 323 minecraft:polished_deepslate
fill 382 267 324 382 270 324 minecraft:gray_concrete
setblock 382 267 363 minecraft:polished_deepslate
fill 383 267 323 383 270 323 minecraft:gray_concrete
setblock 383 267 362 minecraft:polished_deepslate
fill 383 267 363 383 270 363 minecraft:gray_concrete
setblock 384 267 326 minecraft:polished_deepslate
setblock 384 267 361 minecraft:polished_deepslate
fill 384 267 362 387 267 362 minecraft:gray_concrete
setblock 385 267 325 minecraft:polished_deepslate
fill 385 267 361 385 270 361 minecraft:gray_concrete
setblock 386 267 324 minecraft:polished_deepslate
fill 386 267 325 386 270 325 minecraft:gray_concrete
setblock 387 267 323 minecraft:polished_deepslate
fill 387 267 324 387 270 324 minecraft:gray_concrete
setblock 387 267 363 minecraft:polished_deepslate
fill 388 267 323 388 270 323 minecraft:gray_concrete
setblock 388 267 362 minecraft:polished_deepslate
fill 388 267 363 388 270 363 minecraft:gray_concrete
fill 389 267 362 389 269 362 minecraft:gray_concrete
setblock 392 267 323 minecraft:polished_deepslate
setblock 392 267 363 minecraft:polished_deepslate
fill 392 267 364 392 308 364 minecraft:gray_concrete
fill 393 267 323 396 267 323 minecraft:gray_concrete
setblock 393 267 362 minecraft:polished_deepslate
fill 393 267 363 393 270 363 minecraft:gray_concrete
fill 396 267 362 397 267 362 minecraft:gray_concrete
setblock 397 267 323 minecraft:polished_deepslate
setblock 397 267 363 minecraft:polished_deepslate
fill 398 267 323 398 270 323 minecraft:gray_concrete
setblock 398 267 362 minecraft:polished_deepslate
fill 398 267 363 398 270 363 minecraft:gray_concrete
fill 399 267 324 400 267 324 minecraft:gray_concrete
fill 399 267 362 399 270 362 minecraft:gray_concrete
setblock 401 267 324 minecraft:polished_deepslate
setblock 402 267 323 minecraft:polished_deepslate
fill 402 267 324 402 270 324 minecraft:gray_concrete
setblock 402 267 363 minecraft:polished_deepslate
fill 403 267 323 403 270 323 minecraft:gray_concrete
setblock 403 267 362 minecraft:polished_deepslate
fill 403 267 363 403 270 363 minecraft:gray_concrete
setblock 404 267 325 minecraft:gray_concrete
fill 404 267 362 404 269 362 minecraft:gray_concrete
setblock 406 267 324 minecraft:polished_deepslate
setblock 407 267 323 minecraft:polished_deepslate
fill 407 267 324 407 270 324 minecraft:gray_concrete
setblock 407 267 363 minecraft:polished_deepslate
fill 408 267 323 408 270 323 minecraft:gray_concrete
fill 408 267 363 408 269 363 minecraft:gray_concrete
setblock 410 267 324 minecraft:gray_concrete
setblock 411 267 323 minecraft:gray_concrete
setblock 412 267 323 minecraft:polished_deepslate
fill 413 267 323 413 270 323 minecraft:gray_concrete
fill 414 267 324 415 267 324 minecraft:gray_concrete
setblock 416 267 323 minecraft:gray_concrete
setblock 416 267 324 minecraft:polished_deepslate
fill 416 267 325 416 267 328 minecraft:gray_concrete
fill 416 267 340 416 268 340 minecraft:gray_concrete
setblock 416 267 344 minecraft:polished_deepslate
fill 416 267 345 416 269 346 minecraft:gray_concrete
setblock 416 267 363 minecraft:gray_concrete
setblock 417 267 323 minecraft:polished_deepslate
fill 417 267 324 417 267 327 minecraft:gray_concrete
setblock 417 267 328 minecraft:polished_deepslate
fill 417 267 329 417 267 332 minecraft:gray_concrete
setblock 417 267 333 minecraft:polished_deepslate
fill 417 267 334 417 270 334 minecraft:gray_concrete
setblock 417 267 338 minecraft:polished_deepslate
fill 417 267 339 417 270 339 minecraft:gray_concrete
setblock 417 267 343 minecraft:polished_deepslate
fill 417 267 344 417 270 344 minecraft:gray_concrete
setblock 417 267 347 minecraft:gray_concrete
setblock 417 267 348 minecraft:polished_deepslate
fill 417 267 349 417 270 349 minecraft:gray_concrete
setblock 417 267 362 minecraft:gray_concrete
setblock 417 267 363 minecraft:polished_deepslate
fill 376 268 334 376 308 334 minecraft:gray_concrete
fill 376 268 362 376 308 362 minecraft:gray_concrete
fill 377 268 323 377 271 323 minecraft:gray_concrete
setblock 377 268 326 minecraft:gray_concrete
setblock 377 268 327 minecraft:polished_deepslate
fill 377 268 328 377 271 328 minecraft:gray_concrete
setblock 377 268 332 minecraft:polished_deepslate
fill 377 268 333 377 271 333 minecraft:gray_concrete
setblock 377 268 342 minecraft:polished_deepslate
fill 377 268 343 378 270 343 minecraft:gray_concrete
setblock 377 268 347 minecraft:polished_deepslate
fill 377 268 348 377 269 350 minecraft:gray_concrete
fill 377 268 359 377 270 359 minecraft:gray_concrete
setblock 377 268 362 minecraft:polished_deepslate
fill 377 268 363 377 271 363 minecraft:gray_concrete
setblock 378 268 325 minecraft:gray_concrete
setblock 378 268 326 minecraft:polished_deepslate
fill 378 268 327 378 271 327 minecraft:gray_concrete
setblock 378 268 331 minecraft:polished_deepslate
setblock 378 268 345 minecraft:gray_concrete
setblock 378 268 346 minecraft:polished_deepslate
fill 378 268 347 378 270 348 minecraft:gray_concrete
setblock 378 268 360 minecraft:gray_concrete
setblock 378 268 361 minecraft:polished_deepslate
fill 378 268 362 378 271 362 minecraft:gray_concrete
setblock 379 268 325 minecraft:polished_deepslate
fill 379 268 326 382 268 326 minecraft:gray_concrete
setblock 379 268 329 minecraft:gray_concrete
setblock 380 268 324 minecraft:polished_deepslate
fill 380 268 325 380 271 325 minecraft:gray_concrete
fill 380 268 327 380 269 327 minecraft:gray_concrete
setblock 381 268 323 minecraft:polished_deepslate
fill 381 268 324 381 271 324 minecraft:gray_concrete
setblock 381 268 363 minecraft:polished_deepslate
fill 382 268 323 382 271 323 minecraft:gray_concrete
setblock 382 268 362 minecraft:polished_deepslate
fill 382 268 363 382 271 364 minecraft:gray_concrete
setblock 383 268 326 minecraft:polished_deepslate
setblock 383 268 361 minecraft:polished_deepslate
fill 383 268 362 386 268 362 minecraft:gray_concrete
fill 383 268 364 383 308 364 minecraft:gray_concrete
setblock 384 268 325 minecraft:polished_deepslate
fill 384 268 326 384 269 326 minecraft:gray_concrete
fill 384 268 361 384 270 361 minecraft:gray_concrete
setblock 384 268 364 minecraft:light_blue_stained_glass
setblock 385 268 324 minecraft:polished_deepslate
fill 385 268 325 385 271 325 minecraft:gray_concrete
fill 385 268 364 389 269 364 minecraft:gray_concrete
setblock 386 268 323 minecraft:polished_deepslate
fill 386 268 324 386 271 324 minecraft:gray_concrete
setblock 386 268 363 minecraft:polished_deepslate
fill 387 268 323 387 271 323 minecraft:gray_concrete
setblock 387 268 362 minecraft:polished_deepslate
fill 387 268 363 387 271 363 minecraft:gray_concrete
fill 388 268 362 388 270 362 minecraft:gray_concrete
setblock 389 268 324 minecraft:gray_concrete
setblock 390 268 324 minecraft:polished_deepslate
setblock 391 268 323 minecraft:polished_deepslate
setblock 391 268 363 minecraft:polished_deepslate
fill 392 268 323 395 268 323 minecraft:gray_concrete
fill 392 268 363 392 271 363 minecraft:gray_concrete
fill 395 268 327 396 269 328 minecraft:gray_wool
setblock 396 268 323 minecraft:polished_deepslate
fill 396 268 329 396 269 329 minecraft:gray_wool
setblock 396 268 362 minecraft:gray_concrete
setblock 396 268 363 minecraft:polished_deepslate
fill 397 268 323 397 271 323 minecraft:gray_concrete
fill 397 268 328 397 269 328 minecraft:gray_wool
setblock 397 268 362 minecraft:polished_deepslate
fill 397 268 363 397 271 363 minecraft:gray_concrete
fill 398 268 324 399 268 324 minecraft:gray_concrete
fill 398 268 362 398 270 362 minecraft:gray_concrete
setblock 400 268 324 minecraft:polished_deepslate
setblock 401 268 323 minecraft:polished_deepslate
fill 401 268 324 401 271 324 minecraft:gray_concrete
setblock 401 268 363 minecraft:polished_deepslate
fill 402 268 323 402 271 323 minecraft:gray_concrete
fill 402 268 325 403 268 325 minecraft:gray_concrete
setblock 402 268 362 minecraft:polished_deepslate
fill 402 268 363 402 271 363 minecraft:gray_concrete
fill 403 268 362 403 270 362 minecraft:gray_concrete
setblock 404 268 325 minecraft:polished_deepslate
setblock 405 268 324 minecraft:polished_deepslate
fill 405 268 325 406 269 325 minecraft:gray_concrete
setblock 406 268 323 minecraft:polished_deepslate
fill 406 268 324 406 271 324 minecraft:gray_concrete
setblock 406 268 363 minecraft:polished_deepslate
fill 407 268 323 407 271 323 minecraft:gray_concrete
fill 407 268 363 407 269 363 minecraft:gray_concrete
setblock 410 268 324 minecraft:polished_deepslate
setblock 411 268 323 minecraft:polished_deepslate
fill 411 268 324 414 268 324 minecraft:gray_concrete
fill 411 268 328 412 268 331 minecraft:light_blue_concrete
fill 412 268 323 412 271 323 minecraft:gray_concrete
fill 412 268 327 415 268 327 minecraft:light_blue_concrete
fill 412 268 332 416 268 332 minecraft:light_blue_concrete
fill 413 268 326 415 268 326 minecraft:light_blue_concrete
fill 413 268 331 413 270 331 minecraft:light_blue_concrete
setblock 415 268 324 minecraft:polished_deepslate
fill 415 268 331 416 268 331 minecraft:light_blue_concrete
setblock 416 268 323 minecraft:polished_deepslate
fill 416 268 324 416 268 327 minecraft:gray_concrete
setblock 416 268 328 minecraft:polished_deepslate
fill 416 268 329 417 269 330 minecraft:gray_concrete
setblock 416 268 342 minecraft:gray_concrete
setblock 416 268 343 minecraft:polished_deepslate
fill 416 268 344 416 271 344 minecraft:gray_concrete
setblock 416 268 347 minecraft:gray_concrete
setblock 416 268 363 minecraft:polished_deepslate
fill 417 268 323 417 268 326 minecraft:gray_concrete
setblock 417 268 327 minecraft:polished_deepslate
fill 417 268 328 417 271 328 minecraft:gray_concrete
setblock 417 268 331 minecraft:gray_concrete
setblock 417 268 332 minecraft:polished_deepslate
fill 417 268 333 417 271 333 minecraft:gray_concrete
setblock 417 268 337 minecraft:polished_deepslate
fill 417 268 338 417 271 338 minecraft:gray_concrete
setblock 417 268 342 minecraft:polished_deepslate
fill 417 268 343 417 271 343 minecraft:gray_concrete
setblock 417 268 347 minecraft:polished_deepslate
fill 417 268 348 417 271 348 minecraft:gray_concrete
fill 417 268 350 417 269 350 minecraft:gray_concrete
setblock 417 268 362 minecraft:polished_deepslate
fill 417 268 363 417 271 363 minecraft:gray_concrete
setblock 418 268 329 minecraft:light_blue_stained_glass
setblock 418 268 341 minecraft:light_blue_stained_glass
setblock 377 269 326 minecraft:polished_deepslate
fill 377 269 327 377 271 327 minecraft:gray_concrete
setblock 377 269 330 minecraft:gray_concrete
setblock 377 269 331 minecraft:polished_deepslate
fill 377 269 332 378 271 332 minecraft:gray_concrete
fill 377 269 334 377 270 334 minecraft:gray_concrete
setblock 377 269 341 minecraft:polished_deepslate
fill 377 269 342 377 271 342 minecraft:gray_concrete
setblock 377 269 345 minecraft:gray_concrete
setblock 377 269 346 minecraft:polished_deepslate
fill 377 269 347 377 271 347 minecraft:gray_concrete
setblock 377 269 351 minecraft:polished_deepslate
fill 377 269 352 377 271 352 minecraft:gray_concrete
fill 377 269 358 377 271 358 minecraft:gray_concrete
setblock 377 269 361 minecraft:polished_deepslate
fill 377 269 362 377 271 362 minecraft:gray_concrete
setblock 378 269 325 minecraft:polished_deepslate
fill 378 269 326 381 269 326 minecraft:gray_concrete
setblock 378 269 330 minecraft:polished_deepslate
fill 378 269 331 378 271 331 minecraft:gray_concrete
setblock 378 269 345 minecraft:polished_deepslate
fill 378 269 346 378 271 346 minecraft:gray_concrete
setblock 378 269 349 minecraft:gray_concrete
setblock 378 269 350 minecraft:polished_deepslate
setblock 378 269 360 minecraft:polished_deepslate
fill 378 269 361 379 270 361 minecraft:gray_concrete
setblock 379 269 324 minecraft:polished_deepslate
fill 379 269 325 379 271 325 minecraft:gray_concrete
setblock 379 269 329 minecraft:polished_deepslate
fill 379 269 330 379 271 330 minecraft:gray_concrete
setblock 380 269 323 minecraft:polished_deepslate
fill 380 269 324 380 271 324 minecraft:gray_concrete
setblock 380 269 328 minecraft:polished_deepslate
setblock 380 269 363 minecraft:polished_deepslate
fill 381 269 323 381 271 323 minecraft:gray_concrete
setblock 381 269 362 minecraft:polished_deepslate
fill 381 269 363 381 271 363 minecraft:gray_concrete
setblock 382 269 326 minecraft:polished_deepslate
setblock 382 269 361 minecraft:polished_deepslate
fill 382 269 362 385 269 362 minecraft:gray_concrete
setblock 383 269 325 minecraft:polished_deepslate
fill 383 269 326 383 271 326 minecraft:gray_concrete
fill 383 269 361 383 271 361 minecraft:gray_concrete
setblock 384 269 324 minecraft:polished_deepslate
fill 384 269 325 384 271 325 minecraft:gray_concrete
fill 384 269 364 384 308 364 minecraft:gray_concrete
setblock 385 269 323 minecraft:polished_deepslate
fill 385 269 324 385 271 324 minecraft:gray_concrete
setblock 385 269 363 minecraft:polished_deepslate
fill 386 269 323 386 271 323 minecraft:gray_concrete
setblock 386 269 362 minecraft:polished_deepslate
fill 386 269 363 386 271 363 minecraft:gray_concrete
fill 387 269 362 387 271 362 minecraft:gray_concrete
setblock 389 269 324 minecraft:polished_deepslate
setblock 390 269 323 minecraft:polished_deepslate
setblock 390 269 363 minecraft:polished_deepslate
fill 391 269 323 394 269 323 minecraft:gray_concrete
fill 391 269 363 391 271 363 minecraft:gray_concrete
fill 394 269 333 395 270 333 minecraft:light_gray_wool
setblock 395 269 323 minecraft:polished_deepslate
setblock 395 269 363 minecraft:polished_deepslate
fill 396 269 323 396 271 323 minecraft:gray_concrete
fill 396 269 363 396 271 363 minecraft:gray_concrete
fill 397 269 324 398 269 324 minecraft:gray_concrete
setblock 397 269 362 minecraft:gray_concrete
setblock 399 269 324 minecraft:polished_deepslate
setblock 400 269 323 minecraft:polished_deepslate
fill 400 269 324 400 271 325 minecraft:gray_concrete
setblock 400 269 363 minecraft:polished_deepslate
fill 401 269 323 401 271 323 minecraft:gray_concrete
fill 401 269 325 402 269 325 minecraft:gray_concrete
setblock 401 269 362 minecraft:polished_deepslate
fill 401 269 363 401 271 363 minecraft:gray_concrete
fill 402 269 362 402 270 362 minecraft:gray_concrete
setblock 403 269 325 minecraft:polished_deepslate
setblock 404 269 324 minecraft:polished_deepslate
fill 404 269 325 404 271 325 minecraft:gray_concrete
setblock 405 269 323 minecraft:polished_deepslate
fill 405 269 324 405 271 324 minecraft:gray_concrete
setblock 405 269 363 minecraft:polished_deepslate
fill 406 269 323 406 271 323 minecraft:gray_concrete
fill 406 269 363 406 270 363 minecraft:gray_concrete
setblock 408 269 324 minecraft:gray_concrete
fill 408 269 364 412 308 364 minecraft:gray_concrete
setblock 409 269 324 minecraft:polished_deepslate
setblock 410 269 323 minecraft:polished_deepslate
fill 410 269 324 413 269 324 minecraft:gray_concrete
fill 411 269 323 411 271 323 minecraft:gray_concrete
fill 412 269 327 412 269 331 minecraft:light_blue_concrete
fill 413 269 327 414 270 327 minecraft:light_blue_concrete
fill 413 269 332 415 269 332 minecraft:light_blue_concrete
setblock 413 269 364 minecraft:light_blue_stained_glass
setblock 414 269 324 minecraft:polished_deepslate
fill 414 269 364 414 285 364 minecraft:gray_concrete
setblock 415 269 323 minecraft:polished_deepslate
fill 415 269 324 415 269 327 minecraft:gray_concrete
fill 415 269 331 415 270 331 minecraft:light_blue_concrete
fill 416 269 323 416 269 326 minecraft:gray_concrete
setblock 416 269 327 minecraft:polished_deepslate
fill 416 269 328 416 271 328 minecraft:gray_concrete
setblock 416 269 331 minecraft:gray_concrete
setblock 416 269 332 minecraft:polished_deepslate
setblock 416 269 342 minecraft:polished_deepslate
fill 416 269 343 416 271 343 minecraft:gray_concrete
setblock 416 269 347 minecraft:polished_deepslate
fill 416 269 363 416 271 363 minecraft:gray_concrete
fill 417 269 323 417 269 325 minecraft:gray_concrete
setblock 417 269 326 minecraft:polished_deepslate
fill 417 269 327 417 271 327 minecraft:gray_concrete
setblock 417 269 331 minecraft:polished_deepslate
fill 417 269 332 417 271 332 minecraft:gray_concrete
setblock 417 269 336 minecraft:polished_deepslate
fill 417 269 337 417 271 337 minecraft:gray_concrete
setblock 417 269 341 minecraft:polished_deepslate
fill 417 269 342 417 271 342 minecraft:gray_concrete
setblock 417 269 346 minecraft:polished_deepslate
fill 417 269 347 417 271 347 minecraft:gray_concrete
setblock 417 269 351 minecraft:polished_deepslate
fill 417 269 362 417 271 362 minecraft:gray_concrete
fill 418 269 329 418 299 329 minecraft:gray_concrete
fill 418 269 341 418 301 341 minecraft:gray_concrete
setblock 418 269 358 minecraft:light_blue_stained_glass
setblock 377 270 324 minecraft:gray_concrete
setblock 377 270 325 minecraft:polished_deepslate
fill 377 270 326 380 270 326 minecraft:gray_concrete
setblock 377 270 329 minecraft:gray_concrete
setblock 377 270 330 minecraft:polished_deepslate
fill 377 270 331 377 271 331 minecraft:gray_concrete
setblock 377 270 335 minecraft:polished_deepslate
setblock 377 270 340 minecraft:polished_deepslate
fill 377 270 341 377 271 341 minecraft:gray_concrete
setblock 377 270 344 minecraft:gray_concrete
setblock 377 270 345 minecraft:polished_deepslate
fill 377 270 346 377 271 346 minecraft:gray_concrete
fill 377 270 348 377 270 349 minecraft:gray_concrete
setblock 377 270 350 minecraft:polished_deepslate
fill 377 270 351 378 271 351 minecraft:gray_concrete
fill 377 270 353 377 270 354 minecraft:gray_concrete
setblock 377 270 355 minecraft:polished_deepslate
fill 377 270 356 377 271 357 minecraft:gray_concrete
setblock 377 270 360 minecraft:polished_deepslate
fill 377 270 361 377 271 361 minecraft:gray_concrete
setblock 378 270 324 minecraft:polished_deepslate
fill 378 270 325 378 271 325 minecraft:gray_concrete
setblock 378 270 328 minecraft:gray_concrete
setblock 378 270 329 minecraft:polished_deepslate
fill 378 270 330 378 271 330 minecraft:gray_concrete
setblock 378 270 344 minecraft:polished_deepslate
fill 378 270 345 378 271 345 minecraft:gray_concrete
setblock 378 270 349 minecraft:polished_deepslate
fill 378 270 350 378 271 350 minecraft:gray_concrete
fill 378 270 352 378 271 352 minecraft:gray_concrete
fill 378 270 360 378 271 360 minecraft:gray_concrete
setblock 379 270 323 minecraft:polished_deepslate
fill 379 270 324 379 271 324 minecraft:gray_concrete
setblock 379 270 328 minecraft:polished_deepslate
fill 379 270 329 379 271 329 minecraft:gray_concrete
setblock 379 270 333 minecraft:light[level=13]
setblock 379 270 341 minecraft:light[level=13]
setblock 379 270 349 minecraft:light[level=13]
setblock 379 270 357 minecraft:light[level=13]
setblock 379 270 363 minecraft:polished_deepslate
fill 380 270 323 380 271 323 minecraft:gray_concrete
setblock 380 270 327 minecraft:polished_deepslate
fill 380 270 328 380 271 328 minecraft:gray_concrete
setblock 380 270 362 minecraft:polished_deepslate
fill 380 270 363 380 271 363 minecraft:gray_concrete
setblock 381 270 326 minecraft:polished_deepslate
setblock 381 270 361 minecraft:polished_deepslate
fill 381 270 362 384 270 362 minecraft:gray_concrete
setblock 382 270 325 minecraft:polished_deepslate
fill 382 270 326 382 271 326 minecraft:gray_concrete
fill 382 270 361 382 271 361 minecraft:gray_concrete
setblock 383 270 324 minecraft:polished_deepslate
fill 383 270 325 383 271 325 minecraft:gray_concrete
setblock 384 270 323 minecraft:polished_deepslate
fill 384 270 324 384 271 324 minecraft:gray_concrete
setblock 384 270 363 minecraft:polished_deepslate
fill 385 270 323 385 271 323 minecraft:gray_concrete
setblock 385 270 362 minecraft:polished_deepslate
fill 385 270 363 385 271 364 minecraft:gray_concrete
fill 386 270 362 386 271 362 minecraft:gray_concrete
setblock 386 270 364 minecraft:gray_concrete
setblock 387 270 325 minecraft:light[level=13]
setblock 387 270 333 minecraft:light[level=13]
setblock 387 270 341 minecraft:light[level=13]
setblock 387 270 349 minecraft:light[level=13]
setblock 387 270 357 minecraft:light[level=13]
setblock 387 270 364 minecraft:light_blue_stained_glass
setblock 388 270 324 minecraft:polished_deepslate
fill 388 270 364 389 308 364 minecraft:gray_concrete
setblock 389 270 323 minecraft:polished_deepslate
setblock 389 270 324 minecraft:gray_concrete
setblock 389 270 363 minecraft:polished_deepslate
fill 390 270 323 393 270 323 minecraft:gray_concrete
fill 390 270 363 390 271 363 minecraft:gray_concrete
setblock 394 270 323 minecraft:polished_deepslate
setblock 394 270 363 minecraft:polished_deepslate
fill 395 270 323 395 271 323 minecraft:gray_concrete
setblock 395 270 325 minecraft:light[level=13]
setblock 395 270 341 minecraft:light[level=13]
setblock 395 270 349 minecraft:light[level=13]
setblock 395 270 357 minecraft:light[level=13]
fill 395 270 363 395 271 363 minecraft:gray_concrete
setblock 397 270 324 minecraft:gray_concrete
setblock 397 270 364 minecraft:light_blue_stained_glass
setblock 398 270 324 minecraft:polished_deepslate
fill 398 270 364 398 290 364 minecraft:gray_concrete
setblock 399 270 323 minecraft:polished_deepslate
fill 399 270 324 399 271 324 minecraft:gray_concrete
setblock 399 270 363 minecraft:polished_deepslate
fill 400 270 323 400 271 323 minecraft:gray_concrete
setblock 400 270 362 minecraft:polished_deepslate
fill 400 270 363 400 271 363 minecraft:gray_concrete
setblock 400 270 364 minecraft:light_blue_stained_glass
setblock 401 270 325 minecraft:gray_concrete
setblock 401 270 362 minecraft:gray_concrete
setblock 402 270 325 minecraft:polished_deepslate
setblock 403 270 324 minecraft:polished_deepslate
fill 403 270 325 403 271 325 minecraft:gray_concrete
setblock 403 270 333 minecraft:light[level=13]
setblock 403 270 341 minecraft:light[level=13]
setblock 403 270 349 minecraft:light[level=13]
setblock 403 270 357 minecraft:light[level=13]
setblock 404 270 323 minecraft:polished_deepslate
fill 404 270 324 404 271 324 minecraft:gray_concrete
setblock 404 270 363 minecraft:polished_deepslate
fill 405 270 323 405 271 323 minecraft:gray_concrete
setblock 405 270 325 minecraft:gray_concrete
fill 405 270 363 405 271 363 minecraft:gray_concrete
setblock 408 270 324 minecraft:polished_deepslate
setblock 409 270 323 minecraft:polished_deepslate
fill 409 270 324 412 270 324 minecraft:gray_concrete
fill 410 270 323 410 271 323 minecraft:gray_concrete
setblock 411 270 325 minecraft:light[level=13]
setblock 411 270 333 minecraft:light[level=13]
setblock 411 270 341 minecraft:light[level=13]
setblock 411 270 349 minecraft:light[level=13]
setblock 411 270 357 minecraft:light[level=13]
fill 412 270 328 412 270 330 minecraft:light_blue_concrete
setblock 413 270 324 minecraft:polished_deepslate
fill 413 270 328 414 271 330 minecraft:polished_deepslate
fill 413 270 364 413 277 364 minecraft:gray_concrete
setblock 414 270 323 minecraft:polished_deepslate
fill 414 270 324 418 270 324 minecraft:gray_concrete
fill 415 270 323 417 271 323 minecraft:gray_concrete
fill 415 270 325 415 270 326 minecraft:gray_concrete
setblock 415 270 327 minecraft:polished_deepslate
fill 415 270 328 415 271 328 minecraft:gray_concrete
fill 415 270 329 415 270 330 minecraft:polished_deepslate
setblock 416 270 325 minecraft:gray_concrete
setblock 416 270 326 minecraft:polished_deepslate
fill 416 270 327 416 271 327 minecraft:gray_concrete
fill 416 270 329 416 270 330 minecraft:gray_concrete
setblock 416 270 331 minecraft:polished_deepslate
fill 416 270 332 416 271 333 minecraft:gray_concrete
setblock 416 270 342 minecraft:gray_concrete
setblock 416 270 345 minecraft:gray_concrete
setblock 416 270 346 minecraft:polished_deepslate
fill 416 270 347 416 271 348 minecraft:gray_concrete
setblock 417 270 325 minecraft:polished_deepslate
fill 417 270 326 417 271 326 minecraft:gray_concrete
setblock 417 270 329 minecraft:gray_concrete
setblock 417 270 330 minecraft:polished_deepslate
fill 417 270 331 417 271 331 minecraft:gray_concrete
setblock 417 270 335 minecraft:polished_deepslate
fill 417 270 336 417 271 336 minecraft:gray_concrete
setblock 417 270 340 minecraft:polished_deepslate
fill 417 270 341 417 271 341 minecraft:gray_concrete
setblock 417 270 345 minecraft:polished_deepslate
fill 417 270 346 417 271 346 minecraft:gray_concrete
setblock 417 270 350 minecraft:polished_deepslate
fill 417 270 351 417 271 352 minecraft:gray_concrete
setblock 418 270 323 minecraft:light_blue_stained_glass
fill 418 270 325 418 308 325 minecraft:gray_concrete
fill 418 270 358 418 308 358 minecraft:gray_concrete
setblock 377 271 324 minecraft:polished_deepslate
fill 377 271 325 377 271 326 minecraft:gray_concrete
setblock 377 271 329 minecraft:polished_deepslate
setblock 377 271 330 minecraft:gray_concrete
setblock 377 271 334 minecraft:polished_deepslate
setblock 377 271 335 minecraft:gray_concrete
setblock 377 271 343 minecraft:gray_concrete
setblock 377 271 344 minecraft:polished_deepslate
setblock 377 271 345 minecraft:gray_concrete
setblock 377 271 348 minecraft:gray_concrete
setblock 377 271 349 minecraft:polished_deepslate
setblock 377 271 350 minecraft:gray_concrete
setblock 377 271 353 minecraft:gray_concrete
setblock 377 271 354 minecraft:polished_deepslate
setblock 377 271 355 minecraft:gray_concrete
setblock 377 271 359 minecraft:polished_deepslate
setblock 377 271 360 minecraft:gray_concrete
setblock 378 271 323 minecraft:polished_deepslate
setblock 378 271 324 minecraft:gray_concrete
fill 378 271 326 379 271 326 minecraft:gray_concrete
setblock 378 271 328 minecraft:polished_deepslate
setblock 378 271 329 minecraft:gray_concrete
setblock 378 271 344 minecraft:gray_concrete
setblock 378 271 347 minecraft:gray_concrete
setblock 378 271 348 minecraft:polished_deepslate
fill 378 271 349 379 271 349 minecraft:gray_concrete
setblock 378 271 353 minecraft:polished_deepslate
setblock 378 271 361 minecraft:gray_concrete
setblock 378 271 363 minecraft:polished_deepslate
setblock 379 271 323 minecraft:gray_concrete
setblock 379 271 327 minecraft:polished_deepslate
setblock 379 271 328 minecraft:gray_concrete
setblock 379 271 347 minecraft:polished_deepslate
setblock 379 271 348 minecraft:gray_concrete
setblock 379 271 350 minecraft:gray_concrete
setblock 379 271 362 minecraft:polished_deepslate
setblock 379 271 363 minecraft:gray_concrete
setblock 380 271 326 minecraft:polished_deepslate
setblock 380 271 327 minecraft:gray_concrete
setblock 380 271 361 minecraft:polished_deepslate
fill 380 271 362 383 271 362 minecraft:gray_concrete
setblock 381 271 325 minecraft:polished_deepslate
setblock 381 271 326 minecraft:gray_concrete
setblock 381 271 361 minecraft:gray_concrete
setblock 382 271 324 minecraft:polished_deepslate
setblock 382 271 325 minecraft:gray_concrete
setblock 383 271 323 minecraft:polished_deepslate
setblock 383 271 324 minecraft:gray_concrete
setblock 383 271 363 minecraft:polished_deepslate
setblock 384 271 323 minecraft:gray_concrete
setblock 384 271 362 minecraft:polished_deepslate
setblock 384 271 363 minecraft:gray_concrete
setblock 385 271 362 minecraft:gray_concrete
setblock 386 271 364 minecraft:light_blue_stained_glass
setblock 387 271 324 minecraft:polished_deepslate
fill 387 271 364 387 308 364 minecraft:gray_concrete
setblock 388 271 323 minecraft:polished_deepslate
setblock 388 271 363 minecraft:polished_deepslate
fill 389 271 323 391 271 323 minecraft:gray_concrete
setblock 389 271 363 minecraft:gray_concrete
setblock 393 271 323 minecraft:polished_deepslate
setblock 393 271 363 minecraft:polished_deepslate
setblock 394 271 323 minecraft:gray_concrete
setblock 394 271 363 minecraft:gray_concrete
setblock 397 271 324 minecraft:polished_deepslate
fill 397 271 364 397 275 364 minecraft:gray_concrete
setblock 398 271 323 minecraft:polished_deepslate
setblock 398 271 324 minecraft:gray_concrete
setblock 398 271 363 minecraft:polished_deepslate
setblock 399 271 323 minecraft:gray_concrete
setblock 399 271 363 minecraft:gray_concrete
fill 400 271 364 400 308 364 minecraft:gray_concrete
setblock 401 271 325 minecraft:polished_deepslate
setblock 402 271 324 minecraft:polished_deepslate
setblock 402 271 325 minecraft:gray_concrete
setblock 403 271 323 minecraft:polished_deepslate
setblock 403 271 324 minecraft:gray_concrete
setblock 403 271 363 minecraft:polished_deepslate
setblock 404 271 323 minecraft:gray_concrete
setblock 404 271 363 minecraft:gray_concrete
setblock 407 271 324 minecraft:polished_deepslate
setblock 408 271 323 minecraft:polished_deepslate
setblock 408 271 324 minecraft:gray_concrete
setblock 409 271 323 minecraft:gray_concrete
setblock 412 271 324 minecraft:polished_deepslate
setblock 413 271 323 minecraft:polished_deepslate
fill 413 271 324 416 271 324 minecraft:gray_concrete
setblock 414 271 323 minecraft:gray_concrete
setblock 415 271 325 minecraft:gray_concrete
setblock 415 271 326 minecraft:polished_deepslate
setblock 415 271 327 minecraft:gray_concrete
fill 415 271 329 416 271 329 minecraft:gray_concrete
fill 415 271 330 416 271 330 minecraft:polished_deepslate
setblock 416 271 325 minecraft:polished_deepslate
setblock 416 271 326 minecraft:gray_concrete
setblock 416 271 331 minecraft:gray_concrete
setblock 416 271 345 minecraft:polished_deepslate
setblock 416 271 346 minecraft:gray_concrete
setblock 417 271 324 minecraft:polished_deepslate
setblock 417 271 325 minecraft:gray_concrete
setblock 417 271 329 minecraft:polished_deepslate
setblock 417 271 330 minecraft:gray_concrete
setblock 417 271 334 minecraft:polished_deepslate
setblock 417 271 335 minecraft:gray_concrete
setblock 417 271 339 minecraft:polished_deepslate
setblock 417 271 340 minecraft:gray_concrete
setblock 417 271 344 minecraft:polished_deepslate
setblock 417 271 345 minecraft:gray_concrete
setblock 417 271 349 minecraft:polished_deepslate
setblock 417 271 350 minecraft:gray_concrete
setblock 417 271 353 minecraft:gray_concrete
setblock 417 271 356 minecraft:yellow_concrete
fill 418 271 323 418 288 324 minecraft:gray_concrete
setblock 418 271 350 minecraft:light_blue_stained_glass
setblock 379 272 325 minecraft:light[level=12]
setblock 379 272 332 minecraft:light[level=12]
setblock 379 272 339 minecraft:light[level=12]
setblock 379 272 346 minecraft:light[level=12]
setblock 379 272 353 minecraft:light[level=12]
setblock 379 272 360 minecraft:light[level=12]
fill 382 272 364 382 303 364 minecraft:gray_concrete
fill 385 272 364 386 293 364 minecraft:gray_concrete
setblock 386 272 325 minecraft:light[level=12]
setblock 386 272 332 minecraft:light[level=12]
setblock 386 272 339 minecraft:light[level=12]
setblock 386 272 346 minecraft:light[level=12]
setblock 386 272 353 minecraft:light[level=12]
setblock 386 272 360 minecraft:light[level=12]
setblock 393 272 325 minecraft:light[level=12]
setblock 393 272 332 minecraft:light[level=12]
setblock 393 272 339 minecraft:light[level=12]
setblock 393 272 346 minecraft:light[level=12]
setblock 393 272 353 minecraft:light[level=12]
setblock 393 272 360 minecraft:light[level=12]
fill 400 272 322 402 283 322 minecraft:gray_concrete
setblock 400 272 325 minecraft:light[level=12]
setblock 400 272 332 minecraft:light[level=12]
setblock 400 272 339 minecraft:light[level=12]
setblock 400 272 346 minecraft:light[level=12]
setblock 400 272 353 minecraft:light[level=12]
setblock 400 272 360 minecraft:light[level=12]
setblock 403 272 322 minecraft:light_blue_stained_glass
fill 404 272 322 408 278 322 minecraft:gray_concrete
setblock 407 272 325 minecraft:light[level=12]
setblock 407 272 332 minecraft:light[level=12]
setblock 407 272 339 minecraft:light[level=12]
setblock 407 272 346 minecraft:light[level=12]
setblock 407 272 353 minecraft:light[level=12]
setblock 407 272 360 minecraft:light[level=12]
setblock 414 272 325 minecraft:light[level=12]
setblock 414 272 332 minecraft:light[level=12]
setblock 414 272 339 minecraft:light[level=12]
setblock 414 272 346 minecraft:light[level=12]
setblock 414 272 353 minecraft:light[level=12]
setblock 414 272 360 minecraft:light[level=12]
setblock 417 272 355 minecraft:yellow_concrete
fill 418 272 350 418 308 350 minecraft:gray_concrete
fill 403 273 322 403 291 322 minecraft:gray_concrete
setblock 417 273 356 minecraft:yellow_concrete
setblock 380 274 322 minecraft:light_blue_stained_glass
setblock 417 274 357 minecraft:ochre_froglight
fill 380 275 322 380 308 322 minecraft:gray_concrete
setblock 396 275 364 minecraft:light_blue_stained_glass
setblock 417 275 358 minecraft:yellow_concrete
fill 379 276 364 379 304 364 minecraft:gray_concrete
setblock 380 276 364 minecraft:light_blue_stained_glass
fill 396 276 364 396 286 364 minecraft:gray_concrete
setblock 397 276 364 minecraft:light_blue_stained_glass
setblock 417 276 357 minecraft:yellow_concrete
fill 377 277 323 377 279 328 minecraft:light_gray_wool
fill 377 277 329 377 279 341 minecraft:gray_wool
fill 377 277 342 377 279 349 minecraft:light_gray_wool
fill 377 277 350 377 279 362 minecraft:gray_wool
fill 377 277 363 381 279 363 minecraft:light_gray_wool
fill 378 277 323 378 279 326 minecraft:light_gray_wool
fill 378 277 327 378 279 339 minecraft:gray_wool
fill 378 277 340 378 279 347 minecraft:light_gray_wool
fill 378 277 348 378 279 360 minecraft:gray_wool
fill 378 277 361 381 279 362 minecraft:light_gray_wool
fill 379 277 323 379 279 324 minecraft:light_gray_wool
fill 379 277 325 379 279 337 minecraft:gray_wool
fill 379 277 338 379 279 345 minecraft:light_gray_wool
fill 379 277 346 379 279 358 minecraft:gray_wool
fill 379 277 359 382 279 360 minecraft:light_gray_wool
fill 380 277 323 380 279 323 minecraft:light_gray_wool
fill 380 277 324 380 279 336 minecraft:gray_wool
fill 380 277 337 380 279 344 minecraft:light_gray_wool
fill 380 277 345 380 279 357 minecraft:gray_wool
fill 380 277 358 384 279 358 minecraft:light_gray_wool
fill 380 277 364 380 308 364 minecraft:gray_concrete
fill 381 277 323 381 279 334 minecraft:gray_wool
fill 381 277 335 381 279 342 minecraft:light_gray_wool
fill 381 277 343 381 279 355 minecraft:gray_wool
fill 381 277 356 384 279 357 minecraft:light_gray_wool
fill 382 277 323 382 279 332 minecraft:gray_wool
fill 382 277 333 382 279 340 minecraft:light_gray_wool
fill 382 277 341 382 279 353 minecraft:gray_wool
fill 382 277 354 385 279 355 minecraft:light_gray_wool
fill 382 277 361 382 279 361 minecraft:light_gray_wool
fill 382 277 362 389 279 363 minecraft:gray_wool
fill 383 277 323 383 279 331 minecraft:gray_wool
fill 383 277 332 383 279 339 minecraft:light_gray_wool
fill 383 277 340 383 279 352 minecraft:gray_wool
fill 383 277 353 387 279 353 minecraft:light_gray_wool
fill 383 277 359 383 279 359 minecraft:light_gray_wool
fill 383 277 360 390 279 361 minecraft:gray_wool
fill 384 277 323 384 279 329 minecraft:gray_wool
fill 384 277 330 384 279 337 minecraft:light_gray_wool
fill 384 277 338 384 279 350 minecraft:gray_wool
fill 384 277 351 387 279 352 minecraft:light_gray_wool
fill 384 277 359 391 279 359 minecraft:gray_wool
fill 385 277 323 385 279 327 minecraft:gray_wool
fill 385 277 328 385 279 335 minecraft:light_gray_wool
fill 385 277 336 385 279 348 minecraft:gray_wool
fill 385 277 349 388 279 350 minecraft:light_gray_wool
fill 385 277 356 385 279 356 minecraft:light_gray_wool
fill 385 277 357 392 279 358 minecraft:gray_wool
fill 386 277 323 386 279 326 minecraft:gray_wool
fill 386 277 327 386 279 334 minecraft:light_gray_wool
fill 386 277 335 386 279 347 minecraft:gray_wool
fill 386 277 348 390 279 348 minecraft:light_gray_wool
fill 386 277 354 386 279 354 minecraft:light_gray_wool
fill 386 277 355 393 279 356 minecraft:gray_wool
fill 387 277 323 387 279 324 minecraft:gray_wool
fill 387 277 325 387 279 332 minecraft:light_gray_wool
fill 387 277 333 387 279 345 minecraft:gray_wool
fill 387 277 346 390 279 347 minecraft:light_gray_wool
fill 387 277 354 394 279 354 minecraft:gray_wool
fill 388 277 323 388 279 330 minecraft:light_gray_wool
fill 388 277 331 388 279 343 minecraft:gray_wool
fill 388 277 344 391 279 345 minecraft:light_gray_wool
fill 388 277 351 388 279 351 minecraft:light_gray_wool
fill 388 277 352 395 279 353 minecraft:gray_wool
fill 389 277 323 389 279 329 minecraft:light_gray_wool
fill 389 277 330 389 279 342 minecraft:gray_wool
fill 389 277 343 393 279 343 minecraft:light_gray_wool
fill 389 277 349 389 279 349 minecraft:light_gray_wool
fill 389 277 350 396 279 351 minecraft:gray_wool
fill 390 277 323 390 279 327 minecraft:light_gray_wool
fill 390 277 328 390 279 340 minecraft:gray_wool
fill 390 277 341 393 279 342 minecraft:light_gray_wool
fill 390 277 349 397 279 349 minecraft:gray_wool
fill 390 277 362 393 279 363 minecraft:light_gray_wool
fill 391 277 323 391 279 325 minecraft:light_gray_wool
fill 391 277 326 391 279 338 minecraft:gray_wool
fill 391 277 339 394 278 340 minecraft:light_gray_wool
fill 391 277 346 391 279 346 minecraft:light_gray_wool
fill 391 277 347 398 279 348 minecraft:gray_wool
fill 391 277 360 394 279 361 minecraft:light_gray_wool
fill 392 277 323 392 279 324 minecraft:light_gray_wool
fill 392 277 325 392 279 337 minecraft:gray_wool
fill 392 277 338 395 278 338 minecraft:light_gray_wool
fill 392 277 344 392 279 344 minecraft:light_gray_wool
fill 392 277 345 399 279 346 minecraft:gray_wool
fill 392 277 359 396 279 359 minecraft:light_gray_wool
fill 393 277 323 393 279 335 minecraft:gray_wool
fill 393 277 336 396 278 337 minecraft:light_gray_wool
fill 393 277 344 400 279 344 minecraft:gray_wool
fill 393 277 357 396 279 358 minecraft:light_gray_wool
fill 394 277 323 394 279 333 minecraft:gray_wool
fill 394 277 334 397 279 335 minecraft:light_gray_wool
fill 394 277 341 394 278 341 minecraft:light_gray_wool
fill 394 277 342 395 278 343 minecraft:gray_wool
fill 394 277 355 397 279 356 minecraft:light_gray_wool
fill 394 277 362 394 279 362 minecraft:light_gray_wool
fill 394 277 363 401 279 363 minecraft:gray_wool
fill 395 277 323 395 279 332 minecraft:gray_wool
fill 395 277 333 399 279 333 minecraft:light_gray_wool
fill 395 277 354 399 279 354 minecraft:light_gray_wool
fill 395 277 360 395 279 360 minecraft:light_gray_wool
fill 395 277 361 402 279 362 minecraft:gray_wool
fill 396 277 323 396 279 330 minecraft:gray_wool
fill 396 277 331 399 279 332 minecraft:light_gray_wool
fill 396 277 343 401 278 343 minecraft:gray_wool
fill 396 277 352 399 279 353 minecraft:light_gray_wool
fill 396 277 360 403 279 360 minecraft:gray_wool
fill 397 277 323 397 279 328 minecraft:gray_wool
fill 397 277 329 400 279 330 minecraft:light_gray_wool
fill 397 277 336 397 279 336 minecraft:light_gray_wool
fill 397 277 337 404 278 337 minecraft:gray_wool
fill 397 277 350 400 279 351 minecraft:light_gray_wool
fill 397 277 357 397 279 357 minecraft:light_gray_wool
fill 397 277 358 404 279 359 minecraft:gray_wool
fill 397 277 364 397 280 364 minecraft:gray_concrete
fill 398 277 323 398 279 327 minecraft:gray_wool
fill 398 277 328 402 279 328 minecraft:light_gray_wool
fill 398 277 334 398 279 334 minecraft:light_gray_wool
fill 398 277 335 405 279 336 minecraft:gray_wool
fill 398 277 349 402 279 349 minecraft:light_gray_wool
fill 398 277 355 398 279 355 minecraft:light_gray_wool
fill 398 277 356 405 279 357 minecraft:gray_wool
fill 399 277 323 399 279 325 minecraft:gray_wool
fill 399 277 326 402 279 327 minecraft:light_gray_wool
fill 399 277 334 406 279 334 minecraft:gray_wool
fill 399 277 338 404 278 338 minecraft:gray_wool
fill 399 277 342 401 278 342 minecraft:gray_wool
fill 399 277 347 402 279 348 minecraft:light_gray_wool
fill 399 277 355 406 279 355 minecraft:gray_wool
fill 400 277 323 400 279 323 minecraft:gray_wool
fill 400 277 324 403 279 325 minecraft:light_gray_wool
fill 400 277 331 400 279 331 minecraft:light_gray_wool
fill 400 277 332 407 279 333 minecraft:gray_wool
fill 400 277 339 402 278 341 minecraft:gray_wool
fill 400 277 345 403 279 346 minecraft:light_gray_wool
fill 400 277 352 400 279 352 minecraft:light_gray_wool
fill 400 277 353 407 279 354 minecraft:gray_wool
fill 401 277 323 405 279 323 minecraft:light_gray_wool
fill 401 277 329 401 279 329 minecraft:light_gray_wool
fill 401 277 330 408 279 331 minecraft:gray_wool
fill 401 277 344 405 279 344 minecraft:light_gray_wool
fill 401 277 350 401 279 350 minecraft:light_gray_wool
fill 401 277 351 408 279 352 minecraft:gray_wool
fill 402 277 329 409 279 329 minecraft:gray_wool
fill 402 277 342 405 279 343 minecraft:light_gray_wool
fill 402 277 350 409 279 350 minecraft:gray_wool
fill 402 277 363 406 279 363 minecraft:light_gray_wool
fill 403 277 326 403 279 326 minecraft:light_gray_wool
fill 403 277 327 410 279 328 minecraft:gray_wool
fill 403 277 339 403 279 339 minecraft:gray_wool
fill 403 277 340 406 279 341 minecraft:light_gray_wool
fill 403 277 347 403 279 347 minecraft:light_gray_wool
fill 403 277 348 410 279 349 minecraft:gray_wool
fill 403 277 361 406 279 362 minecraft:light_gray_wool
fill 404 277 324 404 279 324 minecraft:light_gray_wool
fill 404 277 325 411 279 326 minecraft:gray_wool
fill 404 277 339 408 279 339 minecraft:light_gray_wool
fill 404 277 345 404 279 345 minecraft:light_gray_wool
fill 404 277 346 411 279 347 minecraft:gray_wool
fill 404 277 360 408 279 360 minecraft:light_gray_wool
fill 405 277 324 412 279 324 minecraft:gray_wool
fill 405 277 337 408 279 338 minecraft:light_gray_wool
fill 405 277 345 412 279 345 minecraft:gray_wool
fill 405 277 358 408 279 359 minecraft:light_gray_wool
setblock 405 277 364 minecraft:light_blue_stained_glass
fill 406 277 323 413 279 323 minecraft:gray_wool
fill 406 277 335 409 279 336 minecraft:light_gray_wool
fill 406 277 342 406 279 342 minecraft:light_gray_wool
fill 406 277 343 413 279 344 minecraft:gray_wool
fill 406 277 356 409 279 357 minecraft:light_gray_wool
fill 407 277 334 411 279 334 minecraft:light_gray_wool
fill 407 277 340 407 279 340 minecraft:light_gray_wool
fill 407 277 341 414 279 342 minecraft:gray_wool
fill 407 277 355 411 279 355 minecraft:light_gray_wool
fill 407 277 361 407 279 361 minecraft:light_gray_wool
fill 407 277 362 414 279 363 minecraft:gray_wool
fill 408 277 332 411 279 333 minecraft:light_gray_wool
fill 408 277 340 415 279 340 minecraft:gray_wool
fill 408 277 353 411 279 354 minecraft:light_gray_wool
fill 408 277 361 415 279 361 minecraft:gray_wool
fill 409 277 330 412 279 331 minecraft:light_gray_wool
fill 409 277 337 409 279 337 minecraft:light_gray_wool
fill 409 277 338 416 279 339 minecraft:gray_wool
fill 409 277 351 412 279 352 minecraft:light_gray_wool
fill 409 277 358 409 279 358 minecraft:light_gray_wool
fill 409 277 359 416 279 360 minecraft:gray_wool
fill 410 277 329 414 279 329 minecraft:light_gray_wool
fill 410 277 335 410 279 335 minecraft:light_gray_wool
fill 410 277 336 417 279 337 minecraft:gray_wool
fill 410 277 350 414 279 350 minecraft:light_gray_wool
fill 410 277 356 410 279 356 minecraft:light_gray_wool
fill 410 277 357 417 279 358 minecraft:gray_wool
fill 411 277 327 414 279 328 minecraft:light_gray_wool
fill 411 277 335 417 279 335 minecraft:gray_wool
fill 411 277 348 414 279 349 minecraft:light_gray_wool
fill 411 277 356 417 279 356 minecraft:gray_wool
fill 412 277 325 415 279 326 minecraft:light_gray_wool
fill 412 277 332 412 279 332 minecraft:light_gray_wool
fill 412 277 333 417 279 334 minecraft:gray_wool
fill 412 277 346 415 279 347 minecraft:light_gray_wool
fill 412 277 353 412 279 353 minecraft:light_gray_wool
fill 412 277 354 417 279 355 minecraft:gray_wool
fill 413 277 324 417 279 324 minecraft:light_gray_wool
fill 413 277 330 413 279 330 minecraft:light_gray_wool
fill 413 277 331 417 279 332 minecraft:gray_wool
fill 413 277 345 417 279 345 minecraft:light_gray_wool
fill 413 277 351 413 279 351 minecraft:light_gray_wool
fill 413 277 352 417 279 353 minecraft:gray_wool
fill 414 277 323 417 279 323 minecraft:light_gray_wool
fill 414 277 330 417 279 330 minecraft:gray_wool
fill 414 277 343 417 279 344 minecraft:light_gray_wool
fill 414 277 351 417 279 351 minecraft:gray_wool
fill 415 277 327 415 279 327 minecraft:light_gray_wool
fill 415 277 328 417 279 329 minecraft:gray_wool
fill 415 277 341 417 279 342 minecraft:light_gray_wool
fill 415 277 348 415 279 348 minecraft:light_gray_wool
fill 415 277 349 417 279 350 minecraft:gray_wool
fill 415 277 362 417 279 363 minecraft:light_gray_wool
fill 416 277 325 416 279 325 minecraft:light_gray_wool
fill 416 277 326 417 279 327 minecraft:gray_wool
fill 416 277 340 417 279 340 minecraft:light_gray_wool
fill 416 277 346 416 279 346 minecraft:light_gray_wool
fill 416 277 347 417 279 348 minecraft:gray_wool
fill 416 277 361 417 279 361 minecraft:light_gray_wool
fill 417 277 325 417 279 325 minecraft:gray_wool
fill 417 277 338 417 279 339 minecraft:light_gray_wool
fill 417 277 346 417 279 346 minecraft:gray_wool
fill 417 277 359 417 279 360 minecraft:light_gray_wool
fill 405 278 364 405 308 364 minecraft:gray_concrete
setblock 413 278 364 minecraft:light_blue_stained_glass
fill 391 279 339 393 279 340 minecraft:light_gray_wool
fill 392 279 338 393 279 338 minecraft:light_gray_wool
fill 393 279 336 394 279 337 minecraft:light_gray_wool
fill 394 279 338 394 279 342 minecraft:ochre_froglight
setblock 394 279 343 minecraft:gray_wool
fill 395 279 336 396 279 336 minecraft:light_gray_wool
fill 395 279 337 395 279 338 minecraft:ochre_froglight
fill 395 279 342 395 279 343 minecraft:ochre_froglight
fill 396 279 337 399 279 337 minecraft:ochre_froglight
fill 396 279 343 399 279 343 minecraft:ochre_froglight
fill 399 279 338 400 279 338 minecraft:ochre_froglight
fill 399 279 342 400 279 342 minecraft:ochre_froglight
fill 400 279 337 404 279 337 minecraft:gray_wool
fill 400 279 339 400 279 341 minecraft:ochre_froglight
fill 400 279 343 401 279 343 minecraft:gray_wool
fill 401 279 338 401 279 342 minecraft:gray_wool
fill 402 279 338 402 279 341 minecraft:gray_wool
fill 403 279 338 404 279 338 minecraft:gray_wool
setblock 404 279 322 minecraft:light_blue_stained_glass
fill 405 279 322 408 292 322 minecraft:gray_concrete
fill 413 279 364 413 308 364 minecraft:gray_concrete
setblock 377 280 354 minecraft:yellow_concrete
setblock 387 280 322 minecraft:light_blue_stained_glass
fill 404 280 322 404 308 322 minecraft:gray_concrete
setblock 417 280 357 minecraft:yellow_concrete
setblock 377 281 353 minecraft:yellow_concrete
fill 387 281 322 387 305 322 minecraft:gray_concrete
setblock 397 281 364 minecraft:light_blue_stained_glass
setblock 417 281 358 minecraft:yellow_concrete
setblock 377 282 354 minecraft:yellow_concrete
setblock 390 282 364 minecraft:light_blue_stained_glass
setblock 395 282 364 minecraft:light_blue_stained_glass
fill 397 282 364 397 308 364 minecraft:gray_concrete
setblock 417 282 357 minecraft:yellow_concrete
fill 377 283 323 377 283 326 minecraft:gray_concrete
setblock 377 283 327 minecraft:polished_deepslate
fill 377 283 328 377 283 331 minecraft:gray_concrete
setblock 377 283 332 minecraft:polished_deepslate
fill 377 283 333 377 283 336 minecraft:gray_concrete
setblock 377 283 337 minecraft:polished_deepslate
fill 377 283 338 377 283 341 minecraft:gray_concrete
setblock 377 283 342 minecraft:polished_deepslate
fill 377 283 343 377 283 346 minecraft:gray_concrete
setblock 377 283 347 minecraft:polished_deepslate
fill 377 283 348 377 283 351 minecraft:gray_concrete
setblock 377 283 352 minecraft:polished_deepslate
fill 377 283 353 379 283 354 minecraft:gray_concrete
setblock 377 283 355 minecraft:ochre_froglight
setblock 377 283 356 minecraft:gray_concrete
setblock 377 283 357 minecraft:polished_deepslate
fill 377 283 358 377 283 361 minecraft:gray_concrete
setblock 377 283 362 minecraft:polished_deepslate
fill 377 283 363 380 283 363 minecraft:gray_concrete
fill 378 283 323 379 283 323 minecraft:gray_concrete
setblock 378 283 330 minecraft:gray_concrete
setblock 378 283 331 minecraft:polished_deepslate
fill 378 283 332 378 283 335 minecraft:gray_concrete
setblock 378 283 336 minecraft:polished_deepslate
fill 378 283 337 378 285 338 minecraft:gray_concrete
fill 378 283 349 378 283 350 minecraft:gray_concrete
setblock 378 283 351 minecraft:polished_deepslate
fill 378 283 352 379 284 352 minecraft:gray_concrete
setblock 378 283 355 minecraft:gray_concrete
setblock 378 283 356 minecraft:polished_deepslate
fill 378 283 357 378 283 360 minecraft:gray_concrete
setblock 378 283 361 minecraft:polished_deepslate
fill 378 283 362 381 283 362 minecraft:gray_concrete
setblock 379 283 355 minecraft:polished_deepslate
fill 379 283 356 379 283 359 minecraft:gray_concrete
setblock 379 283 360 minecraft:polished_deepslate
fill 379 283 361 380 284 361 minecraft:gray_concrete
fill 380 283 356 380 283 357 minecraft:gray_concrete
setblock 381 283 363 minecraft:polished_deepslate
fill 382 283 363 383 285 363 minecraft:gray_concrete
fill 388 283 363 390 283 363 minecraft:gray_concrete
fill 390 283 364 390 291 364 minecraft:gray_concrete
setblock 391 283 362 minecraft:gray_concrete
setblock 391 283 363 minecraft:polished_deepslate
setblock 392 283 362 minecraft:polished_deepslate
fill 392 283 363 395 283 363 minecraft:gray_concrete
fill 393 283 362 396 283 362 minecraft:gray_concrete
fill 394 283 323 395 283 323 minecraft:gray_concrete
fill 395 283 353 396 284 354 minecraft:light_gray_wool
fill 395 283 364 395 308 364 minecraft:gray_concrete
setblock 396 283 323 minecraft:polished_deepslate
setblock 396 283 363 minecraft:polished_deepslate
fill 397 283 323 397 285 323 minecraft:gray_concrete
fill 397 283 359 399 284 359 minecraft:polished_deepslate
fill 397 283 363 398 285 363 minecraft:gray_concrete
fill 398 283 358 398 284 358 minecraft:polished_deepslate
fill 398 283 360 398 284 360 minecraft:polished_deepslate
fill 408 283 323 410 283 323 minecraft:gray_concrete
fill 409 283 363 410 283 363 minecraft:gray_concrete
setblock 410 283 324 minecraft:polished_deepslate
setblock 411 283 323 minecraft:polished_deepslate
fill 411 283 324 414 283 324 minecraft:gray_concrete
setblock 411 283 362 minecraft:gray_concrete
setblock 411 283 363 minecraft:polished_deepslate
fill 412 283 323 415 283 323 minecraft:gray_concrete
setblock 412 283 362 minecraft:polished_deepslate
fill 412 283 363 415 283 363 minecraft:gray_concrete
setblock 413 283 325 minecraft:gray_concrete
setblock 413 283 361 minecraft:polished_deepslate
fill 413 283 362 416 283 362 minecraft:gray_concrete
setblock 414 283 325 minecraft:polished_deepslate
setblock 414 283 329 minecraft:gray_concrete
setblock 414 283 330 minecraft:polished_deepslate
fill 414 283 331 414 283 334 minecraft:gray_concrete
setblock 414 283 335 minecraft:polished_deepslate
fill 414 283 336 417 283 336 minecraft:gray_concrete
fill 414 283 361 417 283 361 minecraft:gray_concrete
setblock 415 283 324 minecraft:polished_deepslate
fill 415 283 325 415 283 328 minecraft:gray_concrete
setblock 415 283 329 minecraft:polished_deepslate
fill 415 283 330 415 283 333 minecraft:gray_concrete
setblock 415 283 334 minecraft:polished_deepslate
fill 415 283 335 417 284 335 minecraft:gray_concrete
fill 415 283 337 415 283 338 minecraft:gray_concrete
setblock 415 283 353 minecraft:gray_concrete
setblock 415 283 354 minecraft:polished_deepslate
fill 415 283 355 415 283 358 minecraft:gray_concrete
setblock 415 283 359 minecraft:polished_deepslate
fill 415 283 360 417 284 360 minecraft:gray_concrete
setblock 416 283 323 minecraft:polished_deepslate
fill 416 283 324 416 283 327 minecraft:gray_concrete
setblock 416 283 328 minecraft:polished_deepslate
fill 416 283 329 416 283 332 minecraft:gray_concrete
setblock 416 283 333 minecraft:polished_deepslate
fill 416 283 334 417 285 334 minecraft:gray_concrete
setblock 416 283 337 minecraft:gray_concrete
setblock 416 283 338 minecraft:polished_deepslate
fill 416 283 339 417 284 340 minecraft:gray_concrete
fill 416 283 351 416 283 352 minecraft:gray_concrete
setblock 416 283 353 minecraft:polished_deepslate
fill 416 283 354 416 283 357 minecraft:gray_concrete
setblock 416 283 358 minecraft:polished_deepslate
fill 416 283 359 417 285 359 minecraft:gray_concrete
setblock 416 283 363 minecraft:polished_deepslate
fill 417 283 323 417 283 326 minecraft:gray_concrete
setblock 417 283 327 minecraft:polished_deepslate
fill 417 283 328 417 283 331 minecraft:gray_concrete
setblock 417 283 332 minecraft:polished_deepslate
fill 417 283 333 417 286 333 minecraft:gray_concrete
setblock 417 283 337 minecraft:polished_deepslate
fill 417 283 338 417 286 338 minecraft:gray_concrete
setblock 417 283 341 minecraft:gray_concrete
setblock 417 283 342 minecraft:polished_deepslate
fill 417 283 343 417 285 343 minecraft:gray_concrete
fill 417 283 348 417 283 351 minecraft:gray_concrete
setblock 417 283 352 minecraft:polished_deepslate
fill 417 283 353 417 283 355 minecraft:gray_concrete
setblock 417 283 356 minecraft:yellow_concrete
setblock 417 283 357 minecraft:polished_deepslate
fill 417 283 358 417 286 358 minecraft:gray_concrete
setblock 417 283 362 minecraft:polished_deepslate
fill 417 283 363 417 286 363 minecraft:gray_concrete
fill 377 284 323 377 284 325 minecraft:gray_concrete
setblock 377 284 326 minecraft:polished_deepslate
fill 377 284 327 377 284 330 minecraft:gray_concrete
setblock 377 284 331 minecraft:polished_deepslate
fill 377 284 332 377 284 335 minecraft:gray_concrete
setblock 377 284 336 minecraft:polished_deepslate
fill 377 284 337 377 284 340 minecraft:gray_concrete
setblock 377 284 341 minecraft:polished_deepslate
fill 377 284 342 377 284 345 minecraft:gray_concrete
setblock 377 284 346 minecraft:polished_deepslate
fill 377 284 347 377 284 350 minecraft:gray_concrete
setblock 377 284 351 minecraft:polished_deepslate
fill 377 284 352 377 284 355 minecraft:gray_concrete
setblock 377 284 356 minecraft:yellow_concrete
fill 377 284 357 377 284 360 minecraft:gray_concrete
setblock 377 284 361 minecraft:polished_deepslate
fill 377 284 362 379 284 363 minecraft:gray_concrete
fill 378 284 323 378 285 323 minecraft:gray_concrete
fill 378 284 332 378 284 334 minecraft:gray_concrete
setblock 378 284 335 minecraft:polished_deepslate
fill 378 284 336 378 285 336 minecraft:gray_concrete
setblock 378 284 350 minecraft:polished_deepslate
fill 378 284 351 378 285 351 minecraft:gray_concrete
fill 378 284 353 378 284 354 minecraft:gray_concrete
setblock 378 284 355 minecraft:polished_deepslate
fill 378 284 356 378 284 359 minecraft:gray_concrete
setblock 378 284 360 minecraft:polished_deepslate
fill 378 284 361 378 287 361 minecraft:gray_concrete
setblock 379 284 325 minecraft:light[level=12]
setblock 379 284 332 minecraft:light[level=12]
setblock 379 284 339 minecraft:light[level=12]
setblock 379 284 346 minecraft:light[level=12]
setblock 379 284 353 minecraft:gray_concrete
setblock 379 284 354 minecraft:polished_deepslate
fill 379 284 355 379 284 358 minecraft:gray_concrete
setblock 379 284 359 minecraft:polished_deepslate
fill 379 284 360 379 287 360 minecraft:gray_concrete
setblock 380 284 362 minecraft:gray_concrete
setblock 380 284 363 minecraft:polished_deepslate
setblock 381 284 362 minecraft:polished_deepslate
fill 381 284 363 381 287 363 minecraft:gray_concrete
setblock 384 284 363 minecraft:gray_concrete
setblock 385 284 363 minecraft:polished_deepslate
setblock 386 284 325 minecraft:light[level=12]
setblock 386 284 332 minecraft:light[level=12]
setblock 386 284 339 minecraft:light[level=12]
setblock 386 284 346 minecraft:light[level=12]
setblock 386 284 353 minecraft:light[level=12]
setblock 386 284 360 minecraft:light[level=12]
fill 386 284 363 389 284 363 minecraft:gray_concrete
setblock 390 284 362 minecraft:gray_concrete
setblock 390 284 363 minecraft:polished_deepslate
setblock 391 284 362 minecraft:polished_deepslate
fill 391 284 363 394 284 363 minecraft:gray_concrete
fill 392 284 362 395 284 362 minecraft:gray_concrete
fill 393 284 323 394 284 323 minecraft:gray_concrete
setblock 393 284 325 minecraft:light[level=12]
setblock 393 284 332 minecraft:light[level=12]
setblock 393 284 339 minecraft:light[level=12]
setblock 393 284 346 minecraft:light[level=12]
setblock 393 284 353 minecraft:light[level=12]
setblock 393 284 360 minecraft:light[level=12]
setblock 395 284 323 minecraft:polished_deepslate
setblock 395 284 363 minecraft:polished_deepslate
fill 396 284 323 396 287 323 minecraft:gray_concrete
setblock 396 284 362 minecraft:polished_deepslate
fill 396 284 363 396 287 363 minecraft:gray_concrete
setblock 397 284 358 minecraft:polished_deepslate
setblock 397 284 360 minecraft:polished_deepslate
setblock 399 284 358 minecraft:polished_deepslate
setblock 399 284 360 minecraft:polished_deepslate
setblock 400 284 322 minecraft:light_blue_stained_glass
setblock 400 284 325 minecraft:light[level=12]
setblock 400 284 332 minecraft:light[level=12]
setblock 400 284 339 minecraft:light[level=12]
setblock 400 284 346 minecraft:light[level=12]
setblock 400 284 353 minecraft:light[level=12]
setblock 400 284 360 minecraft:light[level=12]
fill 401 284 322 402 306 322 minecraft:gray_concrete
fill 407 284 323 409 284 323 minecraft:gray_concrete
setblock 407 284 325 minecraft:light[level=12]
setblock 407 284 332 minecraft:light[level=12]
setblock 407 284 339 minecraft:light[level=12]
setblock 407 284 346 minecraft:light[level=12]
setblock 407 284 353 minecraft:light[level=12]
setblock 407 284 360 minecraft:light[level=12]
fill 408 284 363 409 284 363 minecraft:gray_concrete
setblock 410 284 323 minecraft:polished_deepslate
fill 410 284 324 413 284 324 minecraft:gray_concrete
setblock 410 284 362 minecraft:gray_concrete
setblock 410 284 363 minecraft:polished_deepslate
fill 411 284 323 414 284 323 minecraft:gray_concrete
setblock 411 284 362 minecraft:polished_deepslate
fill 411 284 363 414 284 363 minecraft:gray_concrete
setblock 412 284 361 minecraft:polished_deepslate
fill 412 284 362 415 284 362 minecraft:gray_concrete
setblock 413 284 325 minecraft:polished_deepslate
fill 413 284 361 416 284 361 minecraft:gray_concrete
setblock 414 284 324 minecraft:polished_deepslate
fill 414 284 325 417 284 325 minecraft:gray_concrete
fill 414 284 331 414 284 333 minecraft:gray_concrete
setblock 414 284 334 minecraft:polished_deepslate
fill 414 284 335 414 285 336 minecraft:gray_concrete
setblock 414 284 339 minecraft:light[level=12]
setblock 414 284 346 minecraft:light[level=12]
setblock 414 284 353 minecraft:light[level=12]
fill 414 284 357 414 284 358 minecraft:gray_concrete
setblock 414 284 359 minecraft:polished_deepslate
fill 414 284 360 414 287 360 minecraft:gray_concrete
setblock 415 284 323 minecraft:polished_deepslate
fill 415 284 324 417 285 324 minecraft:gray_concrete
fill 415 284 326 415 284 327 minecraft:gray_concrete
setblock 415 284 328 minecraft:polished_deepslate
fill 415 284 329 415 284 332 minecraft:gray_concrete
setblock 415 284 333 minecraft:polished_deepslate
fill 415 284 334 415 286 334 minecraft:gray_concrete
fill 415 284 336 415 284 337 minecraft:gray_concrete
setblock 415 284 338 minecraft:polished_deepslate
fill 415 284 339 415 285 339 minecraft:gray_concrete
fill 415 284 354 415 284 357 minecraft:gray_concrete
setblock 415 284 358 minecraft:polished_deepslate
fill 415 284 359 415 287 359 minecraft:gray_concrete
setblock 415 284 363 minecraft:polished_deepslate
fill 416 284 323 417 286 323 minecraft:gray_concrete
setblock 416 284 326 minecraft:gray_concrete
setblock 416 284 327 minecraft:polished_deepslate
fill 416 284 328 416 284 331 minecraft:gray_concrete
setblock 416 284 332 minecraft:polished_deepslate
fill 416 284 333 416 287 333 minecraft:gray_concrete
setblock 416 284 336 minecraft:gray_concrete
setblock 416 284 337 minecraft:polished_deepslate
fill 416 284 338 416 287 338 minecraft:gray_concrete
setblock 416 284 341 minecraft:gray_concrete
setblock 416 284 351 minecraft:gray_concrete
setblock 416 284 352 minecraft:polished_deepslate
fill 416 284 353 416 284 356 minecraft:gray_concrete
setblock 416 284 357 minecraft:polished_deepslate
fill 416 284 358 416 287 358 minecraft:gray_concrete
setblock 416 284 362 minecraft:polished_deepslate
fill 416 284 363 416 287 363 minecraft:gray_concrete
setblock 417 284 326 minecraft:polished_deepslate
fill 417 284 327 417 284 330 minecraft:gray_concrete
setblock 417 284 331 minecraft:polished_deepslate
fill 417 284 332 417 287 332 minecraft:gray_concrete
setblock 417 284 336 minecraft:polished_deepslate
fill 417 284 337 417 287 337 minecraft:gray_concrete
setblock 417 284 341 minecraft:polished_deepslate
fill 417 284 342 417 287 342 minecraft:gray_concrete
fill 417 284 349 417 284 350 minecraft:gray_concrete
setblock 417 284 351 minecraft:polished_deepslate
fill 417 284 352 417 285 354 minecraft:gray_concrete
setblock 417 284 355 minecraft:ochre_froglight
setblock 417 284 356 minecraft:polished_deepslate
fill 417 284 357 417 287 357 minecraft:gray_concrete
setblock 417 284 361 minecraft:polished_deepslate
fill 417 284 362 417 287 362 minecraft:gray_concrete
setblock 376 285 346 minecraft:light_blue_stained_glass
setblock 376 285 351 minecraft:light_blue_stained_glass
fill 377 285 323 377 285 324 minecraft:gray_concrete
setblock 377 285 325 minecraft:polished_deepslate
fill 377 285 328 377 285 329 minecraft:gray_concrete
setblock 377 285 330 minecraft:polished_deepslate
fill 377 285 331 377 285 334 minecraft:gray_concrete
setblock 377 285 335 minecraft:polished_deepslate
fill 377 285 336 377 285 339 minecraft:gray_concrete
setblock 377 285 340 minecraft:polished_deepslate
fill 377 285 341 377 285 344 minecraft:gray_concrete
setblock 377 285 345 minecraft:polished_deepslate
fill 377 285 346 377 285 349 minecraft:gray_concrete
setblock 377 285 350 minecraft:polished_deepslate
fill 377 285 351 377 285 354 minecraft:gray_concrete
setblock 377 285 355 minecraft:yellow_concrete
fill 377 285 356 377 285 359 minecraft:gray_concrete
setblock 377 285 360 minecraft:polished_deepslate
fill 377 285 361 377 286 363 minecraft:gray_concrete
setblock 378 285 335 minecraft:gray_concrete
setblock 378 285 350 minecraft:gray_concrete
fill 378 285 352 378 285 353 minecraft:gray_concrete
setblock 378 285 354 minecraft:polished_deepslate
fill 378 285 355 378 285 358 minecraft:gray_concrete
setblock 378 285 359 minecraft:polished_deepslate
fill 378 285 360 378 288 360 minecraft:gray_concrete
fill 378 285 362 378 285 363 minecraft:gray_concrete
fill 379 285 354 379 285 357 minecraft:gray_concrete
setblock 379 285 358 minecraft:polished_deepslate
fill 379 285 359 379 287 359 minecraft:gray_concrete
fill 379 285 361 379 285 362 minecraft:gray_concrete
setblock 379 285 363 minecraft:polished_deepslate
setblock 380 285 362 minecraft:polished_deepslate
fill 380 285 363 380 288 363 minecraft:gray_concrete
fill 381 285 362 381 286 362 minecraft:gray_concrete
setblock 384 285 363 minecraft:polished_deepslate
fill 385 285 363 388 285 363 minecraft:gray_concrete
setblock 389 285 362 minecraft:gray_concrete
setblock 389 285 363 minecraft:polished_deepslate
setblock 390 285 362 minecraft:polished_deepslate
fill 390 285 363 393 285 363 minecraft:gray_concrete
fill 391 285 362 394 285 362 minecraft:gray_concrete
fill 392 285 323 393 285 323 minecraft:gray_concrete
fill 392 285 361 393 285 361 minecraft:gray_concrete
setblock 394 285 323 minecraft:polished_deepslate
setblock 394 285 363 minecraft:polished_deepslate
fill 395 285 323 395 288 323 minecraft:gray_concrete
setblock 395 285 362 minecraft:polished_deepslate
fill 395 285 363 395 288 363 minecraft:gray_concrete
setblock 396 285 362 minecraft:gray_concrete
fill 400 285 322 400 308 322 minecraft:gray_concrete
fill 407 285 323 408 285 323 minecraft:gray_concrete
fill 407 285 363 408 285 363 minecraft:gray_concrete
setblock 409 285 323 minecraft:polished_deepslate
fill 409 285 324 412 285 324 minecraft:gray_concrete
setblock 409 285 362 minecraft:gray_concrete
setblock 409 285 363 minecraft:polished_deepslate
fill 410 285 323 413 285 323 minecraft:gray_concrete
setblock 410 285 362 minecraft:polished_deepslate
fill 410 285 363 413 285 363 minecraft:gray_concrete
setblock 411 285 361 minecraft:polished_deepslate
fill 411 285 362 414 285 362 minecraft:gray_concrete
fill 412 285 361 415 285 361 minecraft:gray_concrete
setblock 413 285 324 minecraft:polished_deepslate
fill 413 285 325 414 285 325 minecraft:gray_concrete
fill 413 285 360 413 287 360 minecraft:gray_concrete
setblock 414 285 323 minecraft:polished_deepslate
fill 414 285 324 414 288 324 minecraft:gray_concrete
setblock 414 285 333 minecraft:polished_deepslate
setblock 414 285 334 minecraft:gray_concrete
setblock 414 285 358 minecraft:polished_deepslate
fill 414 285 359 414 286 359 minecraft:gray_concrete
setblock 414 285 363 minecraft:polished_deepslate
fill 415 285 323 415 288 323 minecraft:gray_concrete
fill 415 285 328 415 285 331 minecraft:gray_concrete
setblock 415 285 332 minecraft:polished_deepslate
fill 415 285 333 415 286 333 minecraft:gray_concrete
fill 415 285 335 415 285 336 minecraft:gray_concrete
setblock 415 285 337 minecraft:polished_deepslate
fill 415 285 338 415 286 338 minecraft:gray_concrete
fill 415 285 354 415 285 356 minecraft:gray_concrete
setblock 415 285 357 minecraft:polished_deepslate
fill 415 285 358 415 288 358 minecraft:gray_concrete
fill 415 285 360 416 285 360 minecraft:gray_concrete
setblock 415 285 362 minecraft:polished_deepslate
fill 415 285 363 415 288 363 minecraft:gray_concrete
setblock 416 285 325 minecraft:gray_concrete
setblock 416 285 326 minecraft:polished_deepslate
fill 416 285 327 416 285 330 minecraft:gray_concrete
setblock 416 285 331 minecraft:polished_deepslate
fill 416 285 332 416 287 332 minecraft:gray_concrete
setblock 416 285 335 minecraft:gray_concrete
setblock 416 285 336 minecraft:polished_deepslate
fill 416 285 337 416 288 337 minecraft:gray_concrete
fill 416 285 339 416 285 340 minecraft:gray_concrete
setblock 416 285 341 minecraft:polished_deepslate
fill 416 285 352 416 285 355 minecraft:gray_concrete
setblock 416 285 356 minecraft:polished_deepslate
fill 416 285 357 416 288 357 minecraft:gray_concrete
setblock 416 285 361 minecraft:polished_deepslate
fill 416 285 362 416 288 362 minecraft:gray_concrete
setblock 417 285 325 minecraft:polished_deepslate
fill 417 285 326 417 285 329 minecraft:gray_concrete
setblock 417 285 330 minecraft:polished_deepslate
fill 417 285 331 417 287 331 minecraft:gray_concrete
setblock 417 285 335 minecraft:polished_deepslate
fill 417 285 336 417 288 336 minecraft:gray_concrete
setblock 417 285 339 minecraft:gray_concrete
setblock 417 285 340 minecraft:polished_deepslate
fill 417 285 341 417 288 341 minecraft:gray_concrete
setblock 417 285 350 minecraft:polished_deepslate
fill 417 285 351 417 286 351 minecraft:gray_concrete
setblock 417 285 355 minecraft:polished_deepslate
fill 417 285 356 417 288 356 minecraft:gray_concrete
setblock 417 285 360 minecraft:polished_deepslate
fill 417 285 361 417 288 361 minecraft:gray_concrete
setblock 418 285 334 minecraft:light_blue_stained_glass
fill 376 286 335 377 286 338 minecraft:gray_concrete
setblock 376 286 339 minecraft:light_blue_stained_glass
fill 376 286 340 377 289 340 minecraft:gray_concrete
fill 376 286 346 377 286 346 minecraft:gray_concrete
fill 376 286 351 377 288 351 minecraft:gray_concrete
setblock 377 286 323 minecraft:gray_concrete
fill 377 286 331 377 286 333 minecraft:gray_concrete
setblock 377 286 334 minecraft:polished_deepslate
setblock 377 286 339 minecraft:polished_deepslate
fill 377 286 341 377 286 343 minecraft:gray_concrete
setblock 377 286 344 minecraft:polished_deepslate
setblock 377 286 345 minecraft:gray_concrete
fill 377 286 347 377 286 348 minecraft:gray_concrete
setblock 377 286 349 minecraft:polished_deepslate
fill 377 286 350 377 287 350 minecraft:gray_concrete
fill 377 286 352 377 286 353 minecraft:gray_concrete
setblock 377 286 354 minecraft:yellow_concrete
fill 377 286 355 377 286 358 minecraft:gray_concrete
setblock 377 286 359 minecraft:polished_deepslate
fill 377 286 360 377 289 360 minecraft:gray_concrete
setblock 378 286 352 minecraft:gray_concrete
setblock 378 286 353 minecraft:polished_deepslate
fill 378 286 354 378 286 357 minecraft:gray_concrete
setblock 378 286 358 minecraft:polished_deepslate
fill 378 286 359 378 289 359 minecraft:gray_concrete
setblock 378 286 362 minecraft:gray_concrete
setblock 378 286 363 minecraft:polished_deepslate
setblock 379 286 325 minecraft:light[level=13]
setblock 379 286 333 minecraft:light[level=13]
setblock 379 286 341 minecraft:light[level=13]
setblock 379 286 349 minecraft:light[level=13]
fill 379 286 355 379 286 356 minecraft:gray_concrete
setblock 379 286 357 minecraft:polished_deepslate
fill 379 286 358 379 287 358 minecraft:gray_concrete
setblock 379 286 361 minecraft:gray_concrete
setblock 379 286 362 minecraft:polished_deepslate
fill 379 286 363 379 289 363 minecraft:gray_concrete
fill 380 286 362 380 287 362 minecraft:gray_concrete
setblock 382 286 363 minecraft:gray_concrete
setblock 383 286 363 minecraft:polished_deepslate
fill 384 286 363 387 286 363 minecraft:gray_concrete
setblock 387 286 325 minecraft:light[level=13]
setblock 387 286 333 minecraft:light[level=13]
setblock 387 286 341 minecraft:light[level=13]
setblock 387 286 349 minecraft:light[level=13]
setblock 387 286 357 minecraft:light[level=13]
setblock 388 286 362 minecraft:gray_concrete
setblock 388 286 363 minecraft:polished_deepslate
setblock 389 286 362 minecraft:polished_deepslate
fill 389 286 363 392 286 363 minecraft:gray_concrete
fill 390 286 362 393 286 362 minecraft:gray_concrete
setblock 392 286 323 minecraft:gray_concrete
setblock 392 286 361 minecraft:gray_concrete
setblock 393 286 323 minecraft:polished_deepslate
setblock 393 286 363 minecraft:polished_deepslate
fill 394 286 323 394 289 323 minecraft:gray_concrete
setblock 394 286 362 minecraft:polished_deepslate
fill 394 286 363 394 289 363 minecraft:gray_concrete
setblock 395 286 325 minecraft:light[level=13]
setblock 395 286 333 minecraft:light[level=13]
setblock 395 286 341 minecraft:light[level=13]
setblock 395 286 349 minecraft:light[level=13]
setblock 395 286 357 minecraft:light[level=13]
fill 395 286 362 395 287 362 minecraft:gray_concrete
setblock 397 286 363 minecraft:gray_concrete
setblock 398 286 363 minecraft:polished_deepslate
setblock 403 286 325 minecraft:light[level=13]
setblock 403 286 333 minecraft:light[level=13]
setblock 403 286 341 minecraft:light[level=13]
setblock 403 286 349 minecraft:light[level=13]
setblock 403 286 357 minecraft:light[level=13]
fill 406 286 323 407 286 323 minecraft:gray_concrete
fill 406 286 363 407 286 363 minecraft:gray_concrete
setblock 408 286 323 minecraft:polished_deepslate
setblock 408 286 362 minecraft:gray_concrete
setblock 408 286 363 minecraft:polished_deepslate
fill 409 286 323 411 286 324 minecraft:gray_concrete
setblock 409 286 362 minecraft:polished_deepslate
fill 409 286 363 412 286 363 minecraft:gray_concrete
setblock 410 286 361 minecraft:polished_deepslate
fill 410 286 362 413 286 362 minecraft:gray_concrete
setblock 411 286 325 minecraft:light[level=13]
setblock 411 286 333 minecraft:light[level=13]
setblock 411 286 341 minecraft:light[level=13]
setblock 411 286 349 minecraft:light[level=13]
setblock 411 286 357 minecraft:light[level=13]
fill 411 286 361 414 286 361 minecraft:gray_concrete
setblock 412 286 323 minecraft:gray_concrete
setblock 412 286 324 minecraft:polished_deepslate
fill 412 286 339 414 300 341 minecraft:polished_deepslate
setblock 413 286 323 minecraft:polished_deepslate
fill 413 286 324 413 289 324 minecraft:gray_concrete
fill 413 286 342 413 300 342 minecraft:polished_deepslate
setblock 413 286 363 minecraft:polished_deepslate
fill 414 286 323 414 289 323 minecraft:gray_concrete
setblock 414 286 358 minecraft:gray_concrete
setblock 414 286 362 minecraft:polished_deepslate
fill 414 286 363 414 289 363 minecraft:gray_concrete
setblock 414 286 364 minecraft:light_blue_stained_glass
fill 415 286 324 416 286 324 minecraft:gray_concrete
setblock 415 286 332 minecraft:gray_concrete
setblock 415 286 335 minecraft:gray_concrete
setblock 415 286 336 minecraft:polished_deepslate
setblock 415 286 337 minecraft:gray_concrete
fill 415 286 340 416 286 340 minecraft:polished_deepslate
setblock 415 286 355 minecraft:gray_concrete
setblock 415 286 356 minecraft:polished_deepslate
fill 415 286 357 415 288 357 minecraft:gray_concrete
setblock 415 286 360 minecraft:gray_concrete
setblock 415 286 361 minecraft:polished_deepslate
fill 415 286 362 415 289 362 minecraft:gray_concrete
setblock 416 286 325 minecraft:polished_deepslate
fill 416 286 326 416 286 329 minecraft:gray_concrete
setblock 416 286 330 minecraft:polished_deepslate
setblock 416 286 331 minecraft:gray_concrete
setblock 416 286 334 minecraft:gray_concrete
setblock 416 286 335 minecraft:polished_deepslate
fill 416 286 336 416 287 336 minecraft:gray_concrete
setblock 416 286 339 minecraft:gray_concrete
fill 416 286 353 416 286 354 minecraft:gray_concrete
setblock 416 286 355 minecraft:polished_deepslate
fill 416 286 356 416 289 356 minecraft:gray_concrete
setblock 416 286 359 minecraft:gray_concrete
setblock 416 286 360 minecraft:polished_deepslate
fill 416 286 361 416 289 361 minecraft:gray_concrete
setblock 417 286 324 minecraft:polished_deepslate
fill 417 286 325 417 286 328 minecraft:gray_concrete
setblock 417 286 329 minecraft:polished_deepslate
fill 417 286 330 417 287 330 minecraft:gray_concrete
setblock 417 286 334 minecraft:polished_deepslate
fill 417 286 335 417 288 335 minecraft:gray_concrete
setblock 417 286 339 minecraft:polished_deepslate
fill 417 286 340 417 289 340 minecraft:gray_concrete
fill 417 286 352 417 286 353 minecraft:gray_concrete
setblock 417 286 354 minecraft:polished_deepslate
fill 417 286 355 417 289 355 minecraft:gray_concrete
schedule function dropper:buildpart/80_9 1t
