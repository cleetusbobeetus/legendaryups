setblock 33 292 482 minecraft:ochre_froglight
setblock 33 292 484 minecraft:ochre_froglight
setblock 34 292 473 minecraft:ochre_froglight
setblock 34 292 475 minecraft:ochre_froglight
setblock 34 292 477 minecraft:ochre_froglight
setblock 34 292 479 minecraft:ochre_froglight
setblock 34 292 481 minecraft:ochre_froglight
setblock 34 292 483 minecraft:ochre_froglight
setblock 34 292 485 minecraft:ochre_froglight
setblock 34 292 504 minecraft:bookshelf
setblock 35 292 474 minecraft:ochre_froglight
setblock 35 292 476 minecraft:ochre_froglight
setblock 35 292 478 minecraft:ochre_froglight
setblock 35 292 480 minecraft:ochre_froglight
setblock 35 292 482 minecraft:ochre_froglight
setblock 35 292 484 minecraft:ochre_froglight
setblock 36 292 473 minecraft:ochre_froglight
setblock 36 292 475 minecraft:ochre_froglight
setblock 36 292 477 minecraft:ochre_froglight
setblock 36 292 479 minecraft:ochre_froglight
setblock 36 292 481 minecraft:ochre_froglight
setblock 36 292 483 minecraft:ochre_froglight
setblock 36 292 485 minecraft:ochre_froglight
setblock 37 292 474 minecraft:ochre_froglight
setblock 37 292 476 minecraft:ochre_froglight
setblock 37 292 478 minecraft:ochre_froglight
setblock 37 292 480 minecraft:ochre_froglight
setblock 37 292 482 minecraft:ochre_froglight
setblock 37 292 484 minecraft:ochre_froglight
setblock 38 292 473 minecraft:ochre_froglight
setblock 38 292 475 minecraft:ochre_froglight
setblock 38 292 477 minecraft:ochre_froglight
setblock 38 292 479 minecraft:ochre_froglight
setblock 38 292 481 minecraft:ochre_froglight
setblock 38 292 483 minecraft:ochre_froglight
setblock 38 292 485 minecraft:ochre_froglight
setblock 39 292 474 minecraft:ochre_froglight
setblock 39 292 476 minecraft:ochre_froglight
setblock 39 292 478 minecraft:ochre_froglight
setblock 39 292 480 minecraft:ochre_froglight
setblock 39 292 482 minecraft:ochre_froglight
setblock 39 292 484 minecraft:ochre_froglight
setblock 40 292 464 minecraft:bookshelf
setblock 40 292 473 minecraft:ochre_froglight
setblock 40 292 475 minecraft:ochre_froglight
setblock 40 292 477 minecraft:ochre_froglight
setblock 40 292 479 minecraft:ochre_froglight
setblock 40 292 481 minecraft:ochre_froglight
setblock 40 292 483 minecraft:ochre_froglight
setblock 40 292 485 minecraft:ochre_froglight
setblock 41 292 470 minecraft:bookshelf
setblock 41 292 474 minecraft:ochre_froglight
setblock 41 292 476 minecraft:ochre_froglight
setblock 41 292 478 minecraft:ochre_froglight
setblock 41 292 480 minecraft:ochre_froglight
setblock 41 292 482 minecraft:ochre_froglight
setblock 41 292 484 minecraft:ochre_froglight
setblock 41 292 491 minecraft:bookshelf
setblock 41 292 498 minecraft:bookshelf
setblock 41 292 504 minecraft:bookshelf
setblock 1 293 468 minecraft:bookshelf
setblock 1 293 475 minecraft:bookshelf
setblock 1 293 482 minecraft:bookshelf
setblock 1 293 489 minecraft:bookshelf
setblock 1 293 496 minecraft:bookshelf
setblock 1 293 503 minecraft:bookshelf
setblock 4 293 464 minecraft:bookshelf
fill 6 293 495 6 294 495 minecraft:bookshelf
fill 6 293 497 6 294 497 minecraft:bookshelf
fill 6 293 499 6 294 499 minecraft:bookshelf
fill 6 293 501 6 294 501 minecraft:bookshelf
fill 6 293 503 6 294 503 minecraft:bookshelf
fill 7 293 494 7 294 494 minecraft:bookshelf
fill 7 293 496 7 294 496 minecraft:bookshelf
fill 7 293 498 7 294 498 minecraft:bookshelf
fill 7 293 500 7 294 500 minecraft:bookshelf
fill 7 293 502 7 294 502 minecraft:bookshelf
fill 7 293 504 7 294 504 minecraft:bookshelf
fill 8 293 495 8 294 495 minecraft:bookshelf
fill 8 293 497 8 294 497 minecraft:bookshelf
fill 8 293 499 8 294 499 minecraft:bookshelf
fill 8 293 501 8 294 501 minecraft:bookshelf
fill 8 293 503 8 294 503 minecraft:bookshelf
fill 9 293 494 9 294 494 minecraft:bookshelf
fill 9 293 496 9 294 496 minecraft:bookshelf
fill 9 293 498 9 294 498 minecraft:bookshelf
fill 9 293 500 9 294 500 minecraft:bookshelf
fill 9 293 502 9 294 502 minecraft:bookshelf
fill 9 293 504 9 295 504 minecraft:bookshelf
fill 10 293 495 10 294 495 minecraft:bookshelf
fill 10 293 497 10 294 497 minecraft:bookshelf
fill 10 293 499 10 294 499 minecraft:bookshelf
fill 10 293 501 10 294 501 minecraft:bookshelf
fill 10 293 503 10 294 503 minecraft:bookshelf
setblock 11 293 464 minecraft:bookshelf
fill 11 293 494 11 294 494 minecraft:bookshelf
fill 11 293 496 11 294 496 minecraft:bookshelf
fill 11 293 498 11 294 498 minecraft:bookshelf
fill 11 293 500 11 294 500 minecraft:bookshelf
fill 11 293 502 11 294 502 minecraft:bookshelf
fill 11 293 504 11 294 504 minecraft:bookshelf
fill 12 293 495 12 294 495 minecraft:bookshelf
fill 12 293 497 12 294 497 minecraft:bookshelf
fill 12 293 499 12 294 499 minecraft:bookshelf
fill 12 293 501 12 294 501 minecraft:bookshelf
fill 12 293 503 12 294 503 minecraft:bookshelf
fill 13 293 494 13 294 494 minecraft:bookshelf
fill 13 293 496 13 294 496 minecraft:bookshelf
fill 13 293 498 13 294 498 minecraft:bookshelf
fill 13 293 500 13 294 500 minecraft:bookshelf
fill 13 293 502 13 294 502 minecraft:bookshelf
fill 13 293 504 13 294 504 minecraft:bookshelf
fill 14 293 495 14 294 495 minecraft:bookshelf
fill 14 293 497 14 294 497 minecraft:bookshelf
fill 14 293 499 14 294 499 minecraft:bookshelf
fill 14 293 501 14 294 501 minecraft:bookshelf
fill 14 293 503 14 294 503 minecraft:bookshelf
fill 15 293 494 15 294 494 minecraft:bookshelf
fill 15 293 496 15 294 496 minecraft:bookshelf
fill 15 293 498 15 294 498 minecraft:bookshelf
fill 15 293 500 15 294 500 minecraft:bookshelf
fill 15 293 502 15 294 502 minecraft:bookshelf
fill 15 293 504 15 294 504 minecraft:bookshelf
fill 16 293 495 16 294 495 minecraft:bookshelf
fill 16 293 497 16 294 497 minecraft:bookshelf
fill 16 293 499 16 294 499 minecraft:bookshelf
fill 16 293 501 16 294 501 minecraft:bookshelf
fill 16 293 503 16 294 503 minecraft:bookshelf
fill 17 293 494 17 294 494 minecraft:bookshelf
fill 17 293 496 17 294 496 minecraft:bookshelf
fill 17 293 498 17 294 498 minecraft:bookshelf
fill 17 293 500 17 294 500 minecraft:bookshelf
fill 17 293 502 17 294 502 minecraft:bookshelf
fill 17 293 504 17 294 504 minecraft:bookshelf
setblock 18 293 464 minecraft:bookshelf
fill 18 293 495 18 294 495 minecraft:bookshelf
fill 18 293 497 18 294 497 minecraft:bookshelf
fill 18 293 499 18 294 499 minecraft:bookshelf
fill 18 293 501 18 294 501 minecraft:bookshelf
fill 18 293 503 18 294 503 minecraft:bookshelf
fill 19 293 496 19 294 496 minecraft:bookshelf
fill 19 293 498 19 294 498 minecraft:bookshelf
fill 19 293 500 19 294 500 minecraft:bookshelf
fill 19 293 502 19 294 502 minecraft:bookshelf
fill 19 293 504 19 294 504 minecraft:bookshelf
fill 20 293 497 20 294 497 minecraft:bookshelf
fill 20 293 499 20 294 499 minecraft:bookshelf
fill 20 293 501 20 294 501 minecraft:bookshelf
fill 20 293 503 20 294 503 minecraft:bookshelf
fill 21 293 496 21 294 496 minecraft:bookshelf
fill 21 293 498 21 294 498 minecraft:bookshelf
fill 21 293 500 21 294 500 minecraft:bookshelf
fill 21 293 502 21 294 502 minecraft:bookshelf
fill 21 293 504 21 294 504 minecraft:bookshelf
fill 22 293 497 22 294 497 minecraft:bookshelf
fill 22 293 499 22 294 499 minecraft:bookshelf
fill 22 293 501 22 294 501 minecraft:bookshelf
fill 22 293 503 22 294 503 minecraft:bookshelf
fill 23 293 496 23 294 496 minecraft:bookshelf
fill 23 293 498 23 294 498 minecraft:bookshelf
fill 23 293 500 23 294 500 minecraft:bookshelf
fill 23 293 502 23 294 502 minecraft:bookshelf
fill 23 293 504 23 294 504 minecraft:bookshelf
fill 24 293 497 24 294 497 minecraft:bookshelf
fill 24 293 499 24 294 499 minecraft:bookshelf
fill 24 293 501 24 294 501 minecraft:bookshelf
fill 24 293 503 27 293 503 minecraft:bookshelf
setblock 25 293 464 minecraft:bookshelf
fill 25 293 502 27 293 502 minecraft:bookshelf
setblock 25 293 504 minecraft:bookshelf
setblock 32 293 464 minecraft:bookshelf
fill 32 293 473 32 294 473 minecraft:bookshelf
fill 32 293 475 32 294 475 minecraft:bookshelf
fill 32 293 477 32 294 477 minecraft:bookshelf
fill 32 293 479 32 294 479 minecraft:bookshelf
fill 32 293 481 32 294 481 minecraft:bookshelf
fill 32 293 483 32 294 483 minecraft:bookshelf
fill 32 293 485 32 294 485 minecraft:bookshelf
fill 33 293 474 33 294 474 minecraft:bookshelf
fill 33 293 476 33 294 476 minecraft:bookshelf
fill 33 293 478 33 294 478 minecraft:bookshelf
fill 33 293 480 33 294 480 minecraft:bookshelf
fill 33 293 482 33 294 482 minecraft:bookshelf
fill 33 293 484 33 294 484 minecraft:bookshelf
fill 34 293 473 34 294 473 minecraft:bookshelf
fill 34 293 475 34 294 475 minecraft:bookshelf
fill 34 293 477 34 294 477 minecraft:bookshelf
fill 34 293 479 34 294 479 minecraft:bookshelf
fill 34 293 481 34 294 481 minecraft:bookshelf
fill 34 293 483 34 294 483 minecraft:bookshelf
fill 34 293 485 34 294 485 minecraft:bookshelf
fill 35 293 474 35 294 474 minecraft:bookshelf
fill 35 293 476 35 294 476 minecraft:bookshelf
fill 35 293 478 35 294 478 minecraft:bookshelf
fill 35 293 480 35 294 480 minecraft:bookshelf
fill 35 293 482 35 294 482 minecraft:bookshelf
fill 35 293 484 35 294 484 minecraft:bookshelf
setblock 35 293 504 minecraft:bookshelf
fill 36 293 473 36 294 473 minecraft:bookshelf
fill 36 293 475 36 294 475 minecraft:bookshelf
fill 36 293 477 36 294 477 minecraft:bookshelf
fill 36 293 479 36 294 479 minecraft:bookshelf
fill 36 293 481 36 294 481 minecraft:bookshelf
fill 36 293 483 36 294 483 minecraft:bookshelf
fill 36 293 485 36 294 485 minecraft:bookshelf
fill 37 293 474 37 294 474 minecraft:bookshelf
fill 37 293 476 37 294 476 minecraft:bookshelf
fill 37 293 478 37 294 478 minecraft:bookshelf
fill 37 293 480 37 294 480 minecraft:bookshelf
fill 37 293 482 37 294 482 minecraft:bookshelf
fill 37 293 484 37 294 484 minecraft:bookshelf
fill 38 293 473 38 294 473 minecraft:bookshelf
fill 38 293 475 38 294 475 minecraft:bookshelf
fill 38 293 477 38 294 477 minecraft:bookshelf
fill 38 293 479 38 294 479 minecraft:bookshelf
fill 38 293 481 38 294 481 minecraft:bookshelf
fill 38 293 483 38 294 483 minecraft:bookshelf
fill 38 293 485 38 294 485 minecraft:bookshelf
setblock 39 293 464 minecraft:bookshelf
fill 39 293 474 39 294 474 minecraft:bookshelf
fill 39 293 476 39 294 476 minecraft:bookshelf
fill 39 293 478 39 294 478 minecraft:bookshelf
fill 39 293 480 39 294 480 minecraft:bookshelf
fill 39 293 482 39 294 482 minecraft:bookshelf
fill 39 293 484 39 294 484 minecraft:bookshelf
fill 40 293 473 40 294 473 minecraft:bookshelf
fill 40 293 475 40 294 475 minecraft:bookshelf
fill 40 293 477 40 294 477 minecraft:bookshelf
fill 40 293 479 40 294 479 minecraft:bookshelf
fill 40 293 481 40 294 481 minecraft:bookshelf
fill 40 293 483 40 294 483 minecraft:bookshelf
fill 40 293 485 40 294 485 minecraft:bookshelf
setblock 41 293 469 minecraft:bookshelf
fill 41 293 474 41 294 474 minecraft:bookshelf
fill 41 293 476 41 294 476 minecraft:bookshelf
fill 41 293 478 41 294 478 minecraft:bookshelf
fill 41 293 480 41 294 480 minecraft:bookshelf
fill 41 293 482 41 294 482 minecraft:bookshelf
fill 41 293 484 41 294 484 minecraft:bookshelf
setblock 41 293 490 minecraft:bookshelf
setblock 41 293 497 minecraft:bookshelf
setblock 3 294 466 minecraft:light[level=12]
setblock 3 294 474 minecraft:light[level=12]
setblock 3 294 482 minecraft:light[level=12]
setblock 3 294 490 minecraft:light[level=12]
setblock 3 294 498 minecraft:light[level=12]
setblock 11 294 466 minecraft:light[level=12]
setblock 11 294 474 minecraft:light[level=12]
setblock 11 294 482 minecraft:light[level=12]
setblock 11 294 490 minecraft:light[level=12]
setblock 19 294 466 minecraft:light[level=12]
setblock 19 294 474 minecraft:light[level=12]
setblock 19 294 490 minecraft:light[level=12]
setblock 24 294 503 minecraft:bookshelf
setblock 27 294 466 minecraft:light[level=12]
setblock 27 294 474 minecraft:light[level=12]
setblock 27 294 482 minecraft:light[level=12]
setblock 27 294 490 minecraft:light[level=12]
setblock 27 294 498 minecraft:light[level=12]
setblock 35 294 466 minecraft:light[level=12]
setblock 35 294 490 minecraft:light[level=12]
setblock 35 294 498 minecraft:light[level=12]
setblock 1 295 470 minecraft:bookshelf
setblock 1 295 477 minecraft:bookshelf
setblock 1 295 484 minecraft:bookshelf
setblock 1 295 491 minecraft:bookshelf
setblock 1 295 498 minecraft:bookshelf
setblock 2 295 464 minecraft:bookshelf
setblock 2 295 504 minecraft:bookshelf
setblock 9 295 464 minecraft:bookshelf
setblock 14 295 497 minecraft:ochre_froglight
setblock 14 295 499 minecraft:ochre_froglight
setblock 14 295 501 minecraft:ochre_froglight
setblock 14 295 503 minecraft:ochre_froglight
setblock 15 295 496 minecraft:ochre_froglight
setblock 15 295 498 minecraft:ochre_froglight
setblock 15 295 500 minecraft:ochre_froglight
setblock 15 295 502 minecraft:ochre_froglight
setblock 15 295 504 minecraft:ochre_froglight
setblock 16 295 464 minecraft:bookshelf
setblock 16 295 497 minecraft:ochre_froglight
setblock 16 295 499 minecraft:ochre_froglight
setblock 16 295 501 minecraft:ochre_froglight
setblock 16 295 503 minecraft:ochre_froglight
setblock 17 295 496 minecraft:ochre_froglight
setblock 17 295 498 minecraft:ochre_froglight
setblock 17 295 500 minecraft:ochre_froglight
setblock 17 295 502 minecraft:ochre_froglight
setblock 17 295 504 minecraft:ochre_froglight
setblock 18 295 497 minecraft:ochre_froglight
setblock 18 295 499 minecraft:ochre_froglight
setblock 18 295 501 minecraft:ochre_froglight
setblock 18 295 503 minecraft:ochre_froglight
setblock 19 295 496 minecraft:ochre_froglight
setblock 19 295 498 minecraft:ochre_froglight
setblock 19 295 500 minecraft:ochre_froglight
setblock 19 295 502 minecraft:ochre_froglight
setblock 19 295 504 minecraft:ochre_froglight
setblock 20 295 497 minecraft:ochre_froglight
setblock 20 295 499 minecraft:ochre_froglight
setblock 20 295 501 minecraft:ochre_froglight
setblock 20 295 503 minecraft:ochre_froglight
setblock 21 295 496 minecraft:ochre_froglight
setblock 21 295 498 minecraft:ochre_froglight
setblock 21 295 500 minecraft:ochre_froglight
setblock 21 295 502 minecraft:ochre_froglight
setblock 21 295 504 minecraft:ochre_froglight
setblock 22 295 497 minecraft:ochre_froglight
setblock 22 295 499 minecraft:ochre_froglight
setblock 22 295 501 minecraft:ochre_froglight
setblock 22 295 503 minecraft:ochre_froglight
setblock 23 295 464 minecraft:bookshelf
setblock 23 295 496 minecraft:ochre_froglight
setblock 23 295 498 minecraft:ochre_froglight
setblock 23 295 500 minecraft:ochre_froglight
setblock 23 295 502 minecraft:ochre_froglight
setblock 23 295 504 minecraft:ochre_froglight
setblock 24 295 497 minecraft:ochre_froglight
setblock 24 295 499 minecraft:ochre_froglight
setblock 24 295 501 minecraft:ochre_froglight
setblock 24 295 503 minecraft:ochre_froglight
setblock 30 295 464 minecraft:bookshelf
setblock 30 295 504 minecraft:bookshelf
setblock 32 295 473 minecraft:ochre_froglight
setblock 32 295 475 minecraft:ochre_froglight
setblock 32 295 477 minecraft:ochre_froglight
setblock 32 295 479 minecraft:ochre_froglight
setblock 32 295 481 minecraft:ochre_froglight
setblock 32 295 483 minecraft:ochre_froglight
setblock 32 295 485 minecraft:ochre_froglight
setblock 33 295 474 minecraft:ochre_froglight
setblock 33 295 476 minecraft:ochre_froglight
setblock 33 295 478 minecraft:ochre_froglight
setblock 33 295 480 minecraft:ochre_froglight
setblock 33 295 482 minecraft:ochre_froglight
setblock 33 295 484 minecraft:ochre_froglight
setblock 34 295 473 minecraft:ochre_froglight
setblock 34 295 475 minecraft:ochre_froglight
setblock 34 295 477 minecraft:ochre_froglight
setblock 34 295 479 minecraft:ochre_froglight
setblock 34 295 481 minecraft:ochre_froglight
setblock 34 295 483 minecraft:ochre_froglight
setblock 34 295 485 minecraft:ochre_froglight
setblock 35 295 474 minecraft:ochre_froglight
setblock 35 295 476 minecraft:ochre_froglight
setblock 35 295 478 minecraft:ochre_froglight
setblock 35 295 480 minecraft:ochre_froglight
setblock 35 295 482 minecraft:ochre_froglight
setblock 35 295 484 minecraft:ochre_froglight
setblock 36 295 473 minecraft:ochre_froglight
setblock 36 295 475 minecraft:ochre_froglight
setblock 36 295 477 minecraft:ochre_froglight
setblock 36 295 479 minecraft:ochre_froglight
setblock 36 295 481 minecraft:ochre_froglight
setblock 36 295 483 minecraft:ochre_froglight
setblock 36 295 485 minecraft:ochre_froglight
setblock 37 295 464 minecraft:bookshelf
setblock 37 295 474 minecraft:ochre_froglight
setblock 37 295 476 minecraft:ochre_froglight
setblock 37 295 478 minecraft:ochre_froglight
setblock 37 295 480 minecraft:ochre_froglight
setblock 37 295 482 minecraft:ochre_froglight
setblock 37 295 484 minecraft:ochre_froglight
setblock 37 295 504 minecraft:bookshelf
setblock 38 295 473 minecraft:ochre_froglight
setblock 38 295 475 minecraft:ochre_froglight
setblock 38 295 477 minecraft:ochre_froglight
setblock 38 295 479 minecraft:ochre_froglight
setblock 38 295 481 minecraft:ochre_froglight
setblock 38 295 483 minecraft:ochre_froglight
setblock 38 295 485 minecraft:ochre_froglight
setblock 39 295 474 minecraft:ochre_froglight
setblock 39 295 476 minecraft:ochre_froglight
setblock 39 295 478 minecraft:ochre_froglight
setblock 39 295 480 minecraft:ochre_froglight
setblock 39 295 482 minecraft:ochre_froglight
setblock 39 295 484 minecraft:ochre_froglight
setblock 40 295 473 minecraft:ochre_froglight
setblock 40 295 475 minecraft:ochre_froglight
setblock 40 295 477 minecraft:ochre_froglight
setblock 40 295 479 minecraft:ochre_froglight
setblock 40 295 481 minecraft:ochre_froglight
setblock 40 295 483 minecraft:ochre_froglight
setblock 40 295 485 minecraft:ochre_froglight
setblock 41 295 467 minecraft:bookshelf
setblock 41 295 474 minecraft:ochre_froglight
setblock 41 295 476 minecraft:ochre_froglight
setblock 41 295 478 minecraft:ochre_froglight
setblock 41 295 480 minecraft:ochre_froglight
setblock 41 295 482 minecraft:ochre_froglight
setblock 41 295 484 minecraft:ochre_froglight
setblock 41 295 488 minecraft:bookshelf
setblock 41 295 495 minecraft:bookshelf
setblock 41 295 502 minecraft:bookshelf
setblock 1 296 464 minecraft:bookshelf
setblock 1 296 471 minecraft:bookshelf
setblock 1 296 478 minecraft:bookshelf
setblock 1 296 485 minecraft:bookshelf
setblock 1 296 492 minecraft:bookshelf
setblock 1 296 499 minecraft:bookshelf
setblock 3 296 504 minecraft:bookshelf
setblock 8 296 464 minecraft:bookshelf
fill 10 296 504 10 298 504 minecraft:bookshelf
fill 13 296 504 13 297 504 minecraft:bookshelf
fill 14 296 497 14 297 497 minecraft:bookshelf
fill 14 296 499 14 297 499 minecraft:bookshelf
fill 14 296 501 14 297 501 minecraft:bookshelf
fill 14 296 503 14 297 503 minecraft:bookshelf
setblock 15 296 464 minecraft:bookshelf
fill 15 296 496 15 297 496 minecraft:bookshelf
fill 15 296 498 15 297 498 minecraft:bookshelf
fill 15 296 500 15 297 500 minecraft:bookshelf
fill 15 296 502 15 297 502 minecraft:bookshelf
fill 15 296 504 15 297 504 minecraft:bookshelf
fill 16 296 497 16 297 497 minecraft:bookshelf
fill 16 296 499 16 297 499 minecraft:bookshelf
fill 16 296 501 16 297 501 minecraft:bookshelf
fill 16 296 503 16 297 503 minecraft:bookshelf
fill 17 296 496 17 297 496 minecraft:bookshelf
fill 17 296 498 17 297 498 minecraft:bookshelf
fill 17 296 500 17 297 500 minecraft:bookshelf
fill 17 296 502 17 297 502 minecraft:bookshelf
fill 17 296 504 17 297 504 minecraft:bookshelf
fill 18 296 497 18 297 497 minecraft:bookshelf
fill 18 296 499 18 297 499 minecraft:bookshelf
fill 18 296 501 18 297 501 minecraft:bookshelf
fill 18 296 503 18 297 503 minecraft:bookshelf
fill 19 296 496 19 297 496 minecraft:bookshelf
fill 19 296 498 19 297 498 minecraft:bookshelf
fill 19 296 500 19 297 500 minecraft:bookshelf
fill 19 296 502 19 297 502 minecraft:bookshelf
fill 19 296 504 19 297 504 minecraft:bookshelf
fill 20 296 497 20 297 497 minecraft:bookshelf
fill 20 296 499 20 297 499 minecraft:bookshelf
fill 20 296 501 20 297 501 minecraft:bookshelf
fill 20 296 503 20 297 503 minecraft:bookshelf
fill 21 296 496 21 297 496 minecraft:bookshelf
fill 21 296 498 21 297 498 minecraft:bookshelf
fill 21 296 500 21 297 500 minecraft:bookshelf
fill 21 296 502 21 297 502 minecraft:bookshelf
fill 21 296 504 21 297 504 minecraft:bookshelf
setblock 22 296 464 minecraft:bookshelf
fill 22 296 497 22 297 497 minecraft:bookshelf
fill 22 296 499 22 297 499 minecraft:bookshelf
fill 22 296 501 22 297 501 minecraft:bookshelf
fill 22 296 503 22 297 503 minecraft:bookshelf
fill 23 296 496 23 297 496 minecraft:bookshelf
fill 23 296 498 23 297 498 minecraft:bookshelf
fill 23 296 500 23 297 500 minecraft:bookshelf
fill 23 296 502 23 297 502 minecraft:bookshelf
fill 23 296 504 23 297 504 minecraft:bookshelf
fill 24 296 497 24 297 497 minecraft:bookshelf
fill 24 296 499 24 297 499 minecraft:bookshelf
fill 24 296 501 24 297 501 minecraft:bookshelf
fill 24 296 503 24 297 503 minecraft:bookshelf
setblock 29 296 464 minecraft:bookshelf
setblock 31 296 504 minecraft:bookshelf
fill 32 296 473 32 297 473 minecraft:bookshelf
fill 32 296 475 32 297 475 minecraft:bookshelf
fill 32 296 477 32 297 477 minecraft:bookshelf
fill 32 296 479 32 297 479 minecraft:bookshelf
fill 32 296 481 32 297 481 minecraft:bookshelf
fill 32 296 483 32 297 483 minecraft:bookshelf
fill 32 296 485 32 297 485 minecraft:bookshelf
fill 33 296 474 33 297 474 minecraft:bookshelf
fill 33 296 476 33 297 476 minecraft:bookshelf
fill 33 296 478 33 297 478 minecraft:bookshelf
fill 33 296 480 33 297 480 minecraft:bookshelf
fill 33 296 482 33 297 482 minecraft:bookshelf
fill 33 296 484 33 297 484 minecraft:bookshelf
fill 34 296 473 34 297 473 minecraft:bookshelf
fill 34 296 475 34 297 475 minecraft:bookshelf
fill 34 296 477 34 297 477 minecraft:bookshelf
fill 34 296 479 34 297 479 minecraft:bookshelf
fill 34 296 481 34 297 481 minecraft:bookshelf
fill 34 296 483 34 297 483 minecraft:bookshelf
fill 34 296 485 34 297 485 minecraft:bookshelf
fill 35 296 474 35 297 474 minecraft:bookshelf
fill 35 296 476 35 297 476 minecraft:bookshelf
fill 35 296 478 35 297 478 minecraft:bookshelf
fill 35 296 480 35 297 480 minecraft:bookshelf
fill 35 296 482 35 297 482 minecraft:bookshelf
fill 35 296 484 35 297 484 minecraft:bookshelf
setblock 36 296 464 minecraft:bookshelf
fill 36 296 473 36 297 473 minecraft:bookshelf
fill 36 296 475 36 297 475 minecraft:bookshelf
fill 36 296 477 36 297 477 minecraft:bookshelf
fill 36 296 479 36 297 479 minecraft:bookshelf
fill 36 296 481 36 297 481 minecraft:bookshelf
fill 36 296 483 36 297 483 minecraft:bookshelf
fill 36 296 485 36 297 485 minecraft:bookshelf
fill 37 296 474 37 297 474 minecraft:bookshelf
fill 37 296 476 37 297 476 minecraft:bookshelf
fill 37 296 478 37 297 478 minecraft:bookshelf
fill 37 296 480 37 297 480 minecraft:bookshelf
fill 37 296 482 37 297 482 minecraft:bookshelf
fill 37 296 484 37 297 484 minecraft:bookshelf
fill 38 296 473 38 297 473 minecraft:bookshelf
fill 38 296 475 38 297 475 minecraft:bookshelf
fill 38 296 477 38 297 477 minecraft:bookshelf
fill 38 296 479 38 297 479 minecraft:bookshelf
fill 38 296 481 38 297 481 minecraft:bookshelf
fill 38 296 483 38 297 483 minecraft:bookshelf
fill 38 296 485 38 297 485 minecraft:bookshelf
setblock 38 296 504 minecraft:bookshelf
fill 39 296 474 39 297 474 minecraft:bookshelf
fill 39 296 476 39 297 476 minecraft:bookshelf
fill 39 296 478 39 297 478 minecraft:bookshelf
fill 39 296 480 39 297 480 minecraft:bookshelf
fill 39 296 482 39 297 482 minecraft:bookshelf
fill 39 296 484 39 297 484 minecraft:bookshelf
fill 40 296 473 40 297 473 minecraft:bookshelf
fill 40 296 475 40 297 475 minecraft:bookshelf
fill 40 296 477 40 297 477 minecraft:bookshelf
fill 40 296 479 40 297 479 minecraft:bookshelf
fill 40 296 481 40 297 481 minecraft:bookshelf
fill 40 296 483 40 297 483 minecraft:bookshelf
fill 40 296 485 40 297 485 minecraft:bookshelf
setblock 41 296 466 minecraft:bookshelf
fill 41 296 474 41 297 474 minecraft:bookshelf
fill 41 296 476 41 297 476 minecraft:bookshelf
fill 41 296 478 41 298 478 minecraft:bookshelf
fill 41 296 480 41 297 480 minecraft:bookshelf
fill 41 296 482 41 300 482 minecraft:bookshelf
fill 41 296 484 41 297 484 minecraft:bookshelf
setblock 41 296 487 minecraft:bookshelf
setblock 41 296 494 minecraft:bookshelf
setblock 41 296 501 minecraft:bookshelf
setblock 1 297 465 minecraft:bookshelf
setblock 1 297 472 minecraft:bookshelf
setblock 1 297 479 minecraft:bookshelf
setblock 1 297 486 minecraft:bookshelf
setblock 1 297 493 minecraft:bookshelf
setblock 1 297 500 minecraft:bookshelf
fill 4 297 504 4 300 504 minecraft:bookshelf
setblock 7 297 464 minecraft:bookshelf
fill 9 297 504 9 298 504 minecraft:bookshelf
fill 10 297 502 13 297 503 minecraft:bookshelf
fill 11 297 504 12 298 504 minecraft:bookshelf
setblock 14 297 464 minecraft:bookshelf
setblock 21 297 464 minecraft:bookshelf
setblock 25 297 504 minecraft:bookshelf
setblock 28 297 464 minecraft:bookshelf
setblock 32 297 504 minecraft:bookshelf
fill 33 297 486 33 298 486 minecraft:blue_wool
setblock 35 297 464 minecraft:bookshelf
setblock 39 297 504 minecraft:bookshelf
setblock 41 297 465 minecraft:bookshelf
setblock 41 297 472 minecraft:bookshelf
setblock 41 297 486 minecraft:bookshelf
setblock 41 297 493 minecraft:bookshelf
setblock 41 297 500 minecraft:bookshelf
setblock 1 298 466 minecraft:bookshelf
setblock 1 298 473 minecraft:bookshelf
setblock 1 298 480 minecraft:bookshelf
setblock 1 298 487 minecraft:bookshelf
setblock 1 298 494 minecraft:bookshelf
setblock 1 298 501 minecraft:bookshelf
fill 5 298 503 7 298 504 minecraft:bookshelf
setblock 6 298 464 minecraft:bookshelf
fill 6 298 502 12 298 502 minecraft:bookshelf
fill 8 298 503 11 298 503 minecraft:bookshelf
setblock 13 298 464 minecraft:bookshelf
setblock 14 298 497 minecraft:ochre_froglight
setblock 14 298 499 minecraft:ochre_froglight
setblock 14 298 501 minecraft:ochre_froglight
setblock 14 298 503 minecraft:ochre_froglight
setblock 15 298 496 minecraft:ochre_froglight
setblock 15 298 498 minecraft:ochre_froglight
setblock 15 298 500 minecraft:ochre_froglight
setblock 15 298 502 minecraft:ochre_froglight
setblock 15 298 504 minecraft:ochre_froglight
setblock 16 298 497 minecraft:ochre_froglight
setblock 16 298 499 minecraft:ochre_froglight
setblock 16 298 501 minecraft:ochre_froglight
setblock 16 298 503 minecraft:ochre_froglight
setblock 17 298 496 minecraft:ochre_froglight
setblock 17 298 498 minecraft:ochre_froglight
setblock 17 298 500 minecraft:ochre_froglight
setblock 17 298 502 minecraft:ochre_froglight
setblock 17 298 504 minecraft:ochre_froglight
setblock 18 298 497 minecraft:ochre_froglight
setblock 18 298 499 minecraft:ochre_froglight
setblock 18 298 501 minecraft:ochre_froglight
setblock 18 298 503 minecraft:ochre_froglight
setblock 19 298 496 minecraft:ochre_froglight
setblock 19 298 498 minecraft:ochre_froglight
setblock 19 298 500 minecraft:ochre_froglight
setblock 19 298 502 minecraft:ochre_froglight
setblock 19 298 504 minecraft:ochre_froglight
setblock 20 298 464 minecraft:bookshelf
setblock 20 298 497 minecraft:ochre_froglight
setblock 20 298 499 minecraft:ochre_froglight
setblock 20 298 501 minecraft:ochre_froglight
setblock 20 298 503 minecraft:ochre_froglight
setblock 21 298 496 minecraft:ochre_froglight
setblock 21 298 498 minecraft:ochre_froglight
setblock 21 298 500 minecraft:ochre_froglight
setblock 21 298 502 minecraft:ochre_froglight
setblock 21 298 504 minecraft:ochre_froglight
setblock 22 298 497 minecraft:ochre_froglight
setblock 22 298 499 minecraft:ochre_froglight
setblock 22 298 501 minecraft:ochre_froglight
setblock 22 298 503 minecraft:ochre_froglight
setblock 23 298 496 minecraft:ochre_froglight
setblock 23 298 498 minecraft:ochre_froglight
setblock 23 298 500 minecraft:ochre_froglight
setblock 23 298 502 minecraft:ochre_froglight
setblock 23 298 504 minecraft:ochre_froglight
setblock 24 298 497 minecraft:ochre_froglight
setblock 24 298 499 minecraft:ochre_froglight
setblock 24 298 501 minecraft:ochre_froglight
setblock 24 298 503 minecraft:ochre_froglight
setblock 26 298 504 minecraft:bookshelf
setblock 27 298 464 minecraft:bookshelf
setblock 33 298 504 minecraft:bookshelf
setblock 34 298 464 minecraft:bookshelf
fill 34 298 489 35 299 489 minecraft:green_wool
setblock 40 298 504 minecraft:bookshelf
setblock 41 298 464 minecraft:bookshelf
setblock 41 298 471 minecraft:bookshelf
setblock 41 298 492 minecraft:bookshelf
setblock 41 298 499 minecraft:bookshelf
fill 1 299 467 1 300 467 minecraft:bookshelf
fill 1 299 474 1 300 474 minecraft:bookshelf
fill 1 299 481 1 300 481 minecraft:bookshelf
fill 1 299 488 1 300 488 minecraft:bookshelf
fill 1 299 495 1 300 495 minecraft:bookshelf
fill 1 299 502 7 299 503 minecraft:bookshelf
fill 2 299 501 3 300 501 minecraft:bookshelf
fill 2 299 504 3 300 504 minecraft:bookshelf
fill 3 299 500 3 300 500 minecraft:bookshelf
fill 5 299 464 5 300 464 minecraft:bookshelf
fill 5 299 504 6 300 504 minecraft:bookshelf
setblock 8 299 502 minecraft:bookshelf
fill 12 299 464 12 300 464 minecraft:bookshelf
fill 13 299 504 13 300 504 minecraft:bookshelf
fill 14 299 497 14 300 497 minecraft:bookshelf
fill 14 299 499 14 300 499 minecraft:bookshelf
fill 14 299 501 14 300 501 minecraft:bookshelf
fill 14 299 503 14 300 503 minecraft:bookshelf
fill 15 299 496 15 300 496 minecraft:bookshelf
fill 15 299 498 15 300 498 minecraft:bookshelf
fill 15 299 500 15 300 500 minecraft:bookshelf
fill 15 299 502 15 300 502 minecraft:bookshelf
fill 15 299 504 15 300 504 minecraft:bookshelf
fill 16 299 497 16 300 497 minecraft:bookshelf
fill 16 299 499 16 300 499 minecraft:bookshelf
fill 16 299 501 16 300 501 minecraft:bookshelf
fill 16 299 503 16 300 503 minecraft:bookshelf
fill 17 299 496 17 300 496 minecraft:bookshelf
fill 17 299 498 17 300 498 minecraft:bookshelf
fill 17 299 500 17 300 500 minecraft:bookshelf
fill 17 299 502 17 300 502 minecraft:bookshelf
fill 17 299 504 17 300 504 minecraft:bookshelf
fill 18 299 497 18 300 497 minecraft:bookshelf
fill 18 299 499 18 300 499 minecraft:bookshelf
fill 18 299 501 18 300 501 minecraft:bookshelf
fill 18 299 503 18 300 503 minecraft:bookshelf
fill 19 299 464 19 300 464 minecraft:bookshelf
fill 19 299 496 19 300 496 minecraft:bookshelf
fill 19 299 498 19 300 498 minecraft:bookshelf
fill 19 299 500 19 300 500 minecraft:bookshelf
fill 19 299 502 19 300 502 minecraft:bookshelf
fill 19 299 504 19 300 504 minecraft:bookshelf
fill 20 299 497 20 300 497 minecraft:bookshelf
fill 20 299 499 20 300 499 minecraft:bookshelf
fill 20 299 501 20 300 501 minecraft:bookshelf
fill 20 299 503 20 300 503 minecraft:bookshelf
fill 21 299 496 21 300 496 minecraft:bookshelf
fill 21 299 498 21 300 498 minecraft:bookshelf
fill 21 299 500 21 300 500 minecraft:bookshelf
fill 21 299 502 21 300 502 minecraft:bookshelf
fill 21 299 504 21 300 504 minecraft:bookshelf
fill 22 299 497 22 300 497 minecraft:bookshelf
fill 22 299 499 22 300 499 minecraft:bookshelf
fill 22 299 501 22 300 501 minecraft:bookshelf
fill 22 299 503 22 300 503 minecraft:bookshelf
fill 23 299 496 23 300 496 minecraft:bookshelf
fill 23 299 498 23 300 498 minecraft:bookshelf
fill 23 299 500 23 300 500 minecraft:bookshelf
fill 23 299 502 23 300 502 minecraft:bookshelf
fill 23 299 504 23 300 504 minecraft:bookshelf
fill 24 299 497 24 300 497 minecraft:bookshelf
fill 24 299 499 24 300 499 minecraft:bookshelf
fill 24 299 501 24 300 501 minecraft:bookshelf
fill 24 299 503 24 300 503 minecraft:bookshelf
fill 26 299 464 26 300 464 minecraft:bookshelf
fill 27 299 504 27 300 504 minecraft:bookshelf
fill 33 299 464 33 300 464 minecraft:bookshelf
fill 34 299 504 34 300 504 minecraft:bookshelf
fill 40 299 464 40 300 464 minecraft:bookshelf
fill 41 299 470 41 300 470 minecraft:bookshelf
fill 41 299 477 41 300 477 minecraft:bookshelf
fill 41 299 484 41 300 484 minecraft:bookshelf
fill 41 299 491 41 300 491 minecraft:bookshelf
fill 41 299 498 41 300 498 minecraft:bookshelf
fill 41 299 504 41 300 504 minecraft:bookshelf
fill 1 300 464 1 300 466 minecraft:bookshelf
setblock 1 300 468 minecraft:bookshelf
fill 1 300 470 1 300 473 minecraft:bookshelf
setblock 1 300 475 minecraft:bookshelf
fill 1 300 477 1 300 480 minecraft:bookshelf
setblock 1 300 482 minecraft:bookshelf
fill 1 300 484 1 300 487 minecraft:bookshelf
setblock 1 300 489 minecraft:bookshelf
fill 1 300 491 1 300 494 minecraft:bookshelf
fill 1 300 496 3 300 496 minecraft:bookshelf
fill 1 300 498 1 300 503 minecraft:bookshelf
setblock 2 300 464 minecraft:bookshelf
fill 2 300 497 2 300 500 minecraft:bookshelf
fill 2 300 502 2 300 503 minecraft:bookshelf
fill 3 300 497 3 300 499 minecraft:bookshelf
setblock 3 300 502 minecraft:bookshelf
setblock 4 300 464 minecraft:bookshelf
fill 6 300 464 9 300 464 minecraft:bookshelf
setblock 7 300 504 minecraft:bookshelf
fill 9 300 504 12 300 504 minecraft:bookshelf
setblock 11 300 464 minecraft:bookshelf
fill 13 300 464 16 300 464 minecraft:bookshelf
setblock 18 300 464 minecraft:bookshelf
fill 20 300 464 23 300 464 minecraft:bookshelf
setblock 25 300 464 minecraft:bookshelf
fill 25 300 504 26 300 504 minecraft:bookshelf
fill 27 300 464 30 300 464 minecraft:bookshelf
setblock 28 300 504 minecraft:bookshelf
fill 30 300 504 33 300 504 minecraft:bookshelf
setblock 32 300 464 minecraft:bookshelf
fill 34 300 464 37 300 464 minecraft:bookshelf
setblock 35 300 504 minecraft:bookshelf
fill 37 300 504 40 300 504 minecraft:bookshelf
setblock 39 300 464 minecraft:bookshelf
fill 41 300 464 41 300 467 minecraft:bookshelf
setblock 41 300 469 minecraft:bookshelf
fill 41 300 471 41 300 474 minecraft:bookshelf
setblock 41 300 476 minecraft:bookshelf
fill 41 300 478 41 300 481 minecraft:bookshelf
setblock 41 300 483 minecraft:bookshelf
fill 41 300 485 41 300 488 minecraft:bookshelf
setblock 41 300 490 minecraft:bookshelf
fill 41 300 492 41 300 495 minecraft:bookshelf
setblock 41 300 497 minecraft:bookshelf
fill 41 300 499 41 300 502 minecraft:bookshelf
setblock 3 302 466 minecraft:light[level=12]
setblock 3 302 474 minecraft:light[level=12]
setblock 3 302 482 minecraft:light[level=12]
setblock 3 302 490 minecraft:light[level=12]
setblock 3 302 498 minecraft:light[level=12]
setblock 11 302 466 minecraft:light[level=12]
setblock 11 302 474 minecraft:light[level=12]
setblock 11 302 482 minecraft:light[level=12]
setblock 11 302 490 minecraft:light[level=12]
setblock 11 302 498 minecraft:light[level=12]
setblock 19 302 466 minecraft:light[level=12]
setblock 19 302 474 minecraft:light[level=12]
setblock 19 302 482 minecraft:light[level=12]
setblock 19 302 490 minecraft:light[level=12]
setblock 19 302 498 minecraft:light[level=12]
setblock 27 302 466 minecraft:light[level=12]
setblock 27 302 474 minecraft:light[level=12]
setblock 27 302 482 minecraft:light[level=12]
setblock 27 302 490 minecraft:light[level=12]
setblock 27 302 498 minecraft:light[level=12]
setblock 35 302 466 minecraft:light[level=12]
setblock 35 302 474 minecraft:light[level=12]
setblock 35 302 482 minecraft:light[level=12]
setblock 35 302 490 minecraft:light[level=12]
setblock 35 302 498 minecraft:light[level=12]
