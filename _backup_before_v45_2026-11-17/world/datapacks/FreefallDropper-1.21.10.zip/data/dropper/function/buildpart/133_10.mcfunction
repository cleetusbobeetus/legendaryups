setblock 68 298 596 minecraft:cobbled_deepslate
setblock 68 298 597 minecraft:calcite
fill 68 298 598 68 300 598 minecraft:cobbled_deepslate
fill 69 298 597 69 300 597 minecraft:cobbled_deepslate
fill 71 298 597 71 299 597 minecraft:cobbled_deepslate
fill 72 298 580 72 298 582 minecraft:diamond_block
setblock 72 298 598 minecraft:calcite
fill 73 298 578 76 298 578 minecraft:diamond_block
fill 73 298 582 73 298 583 minecraft:diamond_block
fill 73 298 598 76 298 598 minecraft:cobbled_deepslate
fill 74 298 583 76 298 583 minecraft:diamond_block
fill 76 298 579 77 298 579 minecraft:diamond_block
fill 77 298 580 77 298 582 minecraft:diamond_block
setblock 77 298 598 minecraft:calcite
setblock 78 298 597 minecraft:calcite
fill 78 298 598 78 300 598 minecraft:cobbled_deepslate
fill 79 298 597 82 298 597 minecraft:cobbled_deepslate
fill 81 298 596 83 298 596 minecraft:cobbled_deepslate
setblock 82 298 558 minecraft:calcite
setblock 82 298 598 minecraft:calcite
fill 83 298 558 83 300 558 minecraft:cobbled_deepslate
setblock 83 298 597 minecraft:calcite
fill 83 298 598 83 300 598 minecraft:cobbled_deepslate
setblock 84 298 587 minecraft:cobbled_deepslate
setblock 84 298 591 minecraft:calcite
fill 84 298 597 84 300 597 minecraft:cobbled_deepslate
setblock 85 298 584 minecraft:cobbled_deepslate
setblock 85 298 585 minecraft:calcite
fill 85 298 586 85 300 586 minecraft:cobbled_deepslate
setblock 85 298 590 minecraft:calcite
fill 85 298 591 85 300 591 minecraft:cobbled_deepslate
fill 85 298 596 85 300 596 minecraft:cobbled_deepslate
fill 86 298 566 86 298 568 minecraft:cobbled_deepslate
setblock 86 298 569 minecraft:calcite
fill 86 298 570 86 298 573 minecraft:cobbled_deepslate
setblock 86 298 574 minecraft:calcite
fill 86 298 575 86 300 575 minecraft:cobbled_deepslate
setblock 86 298 584 minecraft:calcite
fill 86 298 585 86 300 585 minecraft:cobbled_deepslate
setblock 86 298 589 minecraft:calcite
fill 86 298 590 86 300 590 minecraft:cobbled_deepslate
setblock 86 298 594 minecraft:calcite
fill 86 298 595 86 300 595 minecraft:cobbled_deepslate
fill 87 298 564 87 298 567 minecraft:cobbled_deepslate
setblock 87 298 568 minecraft:calcite
fill 87 298 569 87 300 569 minecraft:cobbled_deepslate
fill 87 298 571 87 298 572 minecraft:cobbled_deepslate
setblock 87 298 573 minecraft:calcite
fill 87 298 574 87 300 574 minecraft:cobbled_deepslate
setblock 87 298 578 minecraft:calcite
fill 87 298 579 87 300 579 minecraft:cobbled_deepslate
setblock 87 298 583 minecraft:calcite
fill 87 298 584 87 300 584 minecraft:cobbled_deepslate
setblock 87 298 588 minecraft:calcite
fill 87 298 589 87 300 589 minecraft:cobbled_deepslate
setblock 87 298 593 minecraft:calcite
fill 87 298 594 87 300 594 minecraft:cobbled_deepslate
setblock 87 298 597 minecraft:cobbled_deepslate
setblock 87 298 598 minecraft:calcite
setblock 88 298 562 minecraft:calcite
fill 88 298 563 88 300 563 minecraft:cobbled_deepslate
setblock 88 298 567 minecraft:calcite
fill 88 298 568 88 300 568 minecraft:cobbled_deepslate
setblock 88 298 571 minecraft:cobbled_deepslate
setblock 88 298 572 minecraft:calcite
fill 88 298 573 88 300 573 minecraft:cobbled_deepslate
setblock 88 298 577 minecraft:calcite
fill 88 298 578 88 300 578 minecraft:cobbled_deepslate
setblock 88 298 582 minecraft:calcite
fill 88 298 583 88 300 583 minecraft:cobbled_deepslate
setblock 88 298 587 minecraft:calcite
fill 88 298 588 88 300 588 minecraft:cobbled_deepslate
setblock 88 298 592 minecraft:calcite
fill 88 298 593 88 300 593 minecraft:cobbled_deepslate
setblock 88 298 597 minecraft:calcite
fill 88 298 598 88 300 598 minecraft:cobbled_deepslate
setblock 48 299 560 minecraft:cobbled_deepslate
setblock 48 299 561 minecraft:calcite
fill 48 299 562 48 299 565 minecraft:cobbled_deepslate
setblock 48 299 566 minecraft:calcite
fill 48 299 567 48 299 570 minecraft:cobbled_deepslate
setblock 48 299 571 minecraft:calcite
fill 48 299 572 48 299 575 minecraft:cobbled_deepslate
setblock 48 299 576 minecraft:calcite
fill 48 299 577 48 299 580 minecraft:cobbled_deepslate
setblock 48 299 581 minecraft:calcite
fill 48 299 582 48 300 582 minecraft:cobbled_deepslate
setblock 48 299 586 minecraft:calcite
fill 48 299 587 48 300 587 minecraft:cobbled_deepslate
setblock 48 299 591 minecraft:calcite
fill 48 299 592 48 300 592 minecraft:cobbled_deepslate
setblock 48 299 596 minecraft:calcite
setblock 49 299 565 minecraft:calcite
fill 49 299 566 49 300 566 minecraft:cobbled_deepslate
setblock 49 299 570 minecraft:calcite
fill 49 299 571 49 299 574 minecraft:cobbled_deepslate
setblock 49 299 575 minecraft:calcite
fill 49 299 576 49 300 576 minecraft:cobbled_deepslate
setblock 49 299 590 minecraft:calcite
setblock 49 299 591 minecraft:cobbled_deepslate
setblock 50 299 569 minecraft:calcite
fill 50 299 570 50 300 570 minecraft:cobbled_deepslate
setblock 56 299 558 minecraft:calcite
fill 57 299 558 60 299 558 minecraft:cobbled_deepslate
fill 58 299 598 60 299 598 minecraft:cobbled_deepslate
setblock 59 299 559 minecraft:cobbled_deepslate
setblock 60 299 559 minecraft:calcite
fill 60 299 597 61 299 597 minecraft:cobbled_deepslate
setblock 61 299 558 minecraft:calcite
fill 61 299 559 63 299 560 minecraft:cobbled_deepslate
setblock 61 299 598 minecraft:calcite
fill 62 299 558 65 299 558 minecraft:cobbled_deepslate
setblock 62 299 596 minecraft:cobbled_deepslate
setblock 62 299 597 minecraft:calcite
fill 62 299 598 65 299 598 minecraft:cobbled_deepslate
setblock 63 299 596 minecraft:calcite
fill 63 299 597 63 300 597 minecraft:cobbled_deepslate
setblock 64 299 559 minecraft:cobbled_deepslate
setblock 64 299 560 minecraft:calcite
fill 64 299 596 64 300 596 minecraft:cobbled_deepslate
setblock 65 299 559 minecraft:calcite
setblock 65 299 560 minecraft:cobbled_deepslate
setblock 66 299 558 minecraft:calcite
fill 66 299 559 66 300 559 minecraft:cobbled_deepslate
setblock 66 299 598 minecraft:calcite
fill 67 299 558 67 300 558 minecraft:cobbled_deepslate
setblock 67 299 597 minecraft:calcite
fill 67 299 598 67 300 598 minecraft:cobbled_deepslate
setblock 68 299 596 minecraft:calcite
fill 68 299 597 68 300 597 minecraft:cobbled_deepslate
setblock 71 299 598 minecraft:calcite
fill 72 299 598 75 299 598 minecraft:cobbled_deepslate
setblock 73 299 579 minecraft:diamond_block
setblock 73 299 582 minecraft:diamond_block
fill 74 299 583 75 299 583 minecraft:diamond_block
setblock 76 299 579 minecraft:diamond_block
setblock 76 299 598 minecraft:calcite
fill 77 299 580 77 299 581 minecraft:diamond_block
setblock 77 299 597 minecraft:calcite
fill 77 299 598 77 300 598 minecraft:cobbled_deepslate
fill 78 299 597 81 299 597 minecraft:cobbled_deepslate
fill 79 299 596 82 299 596 minecraft:cobbled_deepslate
setblock 81 299 598 minecraft:calcite
fill 82 299 558 82 300 558 minecraft:cobbled_deepslate
setblock 82 299 597 minecraft:calcite
fill 82 299 598 82 300 598 minecraft:cobbled_deepslate
setblock 83 299 596 minecraft:calcite
fill 83 299 597 83 300 597 minecraft:cobbled_deepslate
fill 84 299 588 84 299 589 minecraft:cobbled_deepslate
setblock 84 299 590 minecraft:calcite
setblock 84 299 591 minecraft:cobbled_deepslate
fill 84 299 596 84 300 596 minecraft:cobbled_deepslate
setblock 85 299 585 minecraft:cobbled_deepslate
setblock 85 299 589 minecraft:calcite
fill 85 299 590 85 300 590 minecraft:cobbled_deepslate
setblock 85 299 594 minecraft:calcite
fill 86 299 566 86 299 567 minecraft:cobbled_deepslate
setblock 86 299 568 minecraft:calcite
fill 86 299 569 86 299 572 minecraft:cobbled_deepslate
setblock 86 299 573 minecraft:calcite
fill 86 299 574 86 300 574 minecraft:cobbled_deepslate
fill 86 299 576 86 299 577 minecraft:cobbled_deepslate
setblock 86 299 583 minecraft:calcite
fill 86 299 584 86 300 584 minecraft:cobbled_deepslate
setblock 86 299 588 minecraft:calcite
fill 86 299 589 86 300 589 minecraft:cobbled_deepslate
setblock 86 299 593 minecraft:calcite
fill 86 299 594 86 300 594 minecraft:cobbled_deepslate
setblock 86 299 598 minecraft:calcite
fill 87 299 564 87 299 566 minecraft:cobbled_deepslate
setblock 87 299 567 minecraft:calcite
fill 87 299 568 87 300 568 minecraft:cobbled_deepslate
setblock 87 299 571 minecraft:cobbled_deepslate
setblock 87 299 572 minecraft:calcite
fill 87 299 573 87 300 573 minecraft:cobbled_deepslate
setblock 87 299 577 minecraft:calcite
fill 87 299 578 87 300 578 minecraft:cobbled_deepslate
setblock 87 299 582 minecraft:calcite
fill 87 299 583 87 300 583 minecraft:cobbled_deepslate
setblock 87 299 587 minecraft:calcite
fill 87 299 588 87 300 588 minecraft:cobbled_deepslate
setblock 87 299 592 minecraft:calcite
fill 87 299 593 87 300 593 minecraft:cobbled_deepslate
fill 87 299 598 87 300 598 minecraft:cobbled_deepslate
setblock 88 299 562 minecraft:cobbled_deepslate
setblock 88 299 566 minecraft:calcite
fill 88 299 567 88 300 567 minecraft:cobbled_deepslate
setblock 88 299 571 minecraft:calcite
fill 88 299 572 88 300 572 minecraft:cobbled_deepslate
setblock 88 299 576 minecraft:calcite
fill 88 299 577 88 300 577 minecraft:cobbled_deepslate
setblock 88 299 581 minecraft:calcite
fill 88 299 582 88 300 582 minecraft:cobbled_deepslate
setblock 88 299 586 minecraft:calcite
fill 88 299 587 88 300 587 minecraft:cobbled_deepslate
setblock 88 299 591 minecraft:calcite
fill 88 299 592 88 300 592 minecraft:cobbled_deepslate
setblock 88 299 596 minecraft:calcite
fill 88 299 597 88 300 597 minecraft:cobbled_deepslate
fill 48 300 561 48 300 564 minecraft:cobbled_deepslate
setblock 48 300 565 minecraft:calcite
fill 48 300 566 48 300 569 minecraft:cobbled_deepslate
setblock 48 300 570 minecraft:calcite
fill 48 300 571 48 300 574 minecraft:cobbled_deepslate
setblock 48 300 575 minecraft:calcite
fill 48 300 576 48 300 579 minecraft:cobbled_deepslate
setblock 48 300 580 minecraft:calcite
setblock 48 300 581 minecraft:cobbled_deepslate
setblock 48 300 585 minecraft:calcite
setblock 48 300 586 minecraft:cobbled_deepslate
setblock 48 300 590 minecraft:calcite
setblock 48 300 591 minecraft:cobbled_deepslate
setblock 48 300 595 minecraft:calcite
setblock 48 300 596 minecraft:cobbled_deepslate
setblock 49 300 564 minecraft:calcite
setblock 49 300 565 minecraft:cobbled_deepslate
setblock 49 300 569 minecraft:calcite
fill 49 300 570 49 300 573 minecraft:cobbled_deepslate
setblock 49 300 574 minecraft:calcite
setblock 49 300 575 minecraft:cobbled_deepslate
setblock 50 300 560 minecraft:light[level=14]
setblock 50 300 568 minecraft:calcite
setblock 50 300 569 minecraft:cobbled_deepslate
setblock 50 300 576 minecraft:light[level=14]
setblock 50 300 584 minecraft:light[level=14]
setblock 50 300 592 minecraft:light[level=14]
fill 56 300 558 59 300 558 minecraft:cobbled_deepslate
fill 57 300 598 59 300 598 minecraft:cobbled_deepslate
setblock 58 300 559 minecraft:cobbled_deepslate
setblock 58 300 560 minecraft:light[level=14]
setblock 58 300 568 minecraft:light[level=14]
setblock 58 300 576 minecraft:light[level=14]
setblock 58 300 584 minecraft:light[level=14]
setblock 58 300 592 minecraft:light[level=14]
setblock 59 300 559 minecraft:calcite
fill 59 300 597 60 300 597 minecraft:cobbled_deepslate
setblock 60 300 558 minecraft:calcite
fill 60 300 559 63 300 559 minecraft:cobbled_deepslate
setblock 60 300 598 minecraft:calcite
fill 61 300 558 64 300 558 minecraft:cobbled_deepslate
fill 61 300 560 62 300 560 minecraft:cobbled_deepslate
setblock 61 300 596 minecraft:cobbled_deepslate
setblock 61 300 597 minecraft:calcite
fill 61 300 598 64 300 598 minecraft:cobbled_deepslate
setblock 62 300 596 minecraft:calcite
setblock 62 300 597 minecraft:cobbled_deepslate
setblock 63 300 560 minecraft:calcite
setblock 63 300 596 minecraft:cobbled_deepslate
setblock 64 300 559 minecraft:calcite
setblock 64 300 560 minecraft:cobbled_deepslate
setblock 64 300 595 minecraft:cobbled_deepslate
setblock 65 300 558 minecraft:calcite
setblock 65 300 559 minecraft:cobbled_deepslate
setblock 65 300 598 minecraft:calcite
setblock 66 300 558 minecraft:cobbled_deepslate
setblock 66 300 560 minecraft:light[level=14]
setblock 66 300 568 minecraft:light[level=14]
setblock 66 300 576 minecraft:light[level=14]
setblock 66 300 584 minecraft:light[level=14]
setblock 66 300 592 minecraft:light[level=14]
setblock 66 300 596 minecraft:cobbled_deepslate
setblock 66 300 597 minecraft:calcite
setblock 66 300 598 minecraft:cobbled_deepslate
setblock 67 300 596 minecraft:calcite
setblock 67 300 597 minecraft:cobbled_deepslate
setblock 68 300 596 minecraft:cobbled_deepslate
setblock 70 300 598 minecraft:calcite
setblock 71 300 597 minecraft:calcite
fill 71 300 598 74 300 598 minecraft:cobbled_deepslate
setblock 72 300 597 minecraft:cobbled_deepslate
setblock 74 300 560 minecraft:light[level=14]
setblock 74 300 568 minecraft:light[level=14]
setblock 74 300 576 minecraft:light[level=14]
setblock 74 300 584 minecraft:light[level=14]
setblock 74 300 592 minecraft:light[level=14]
setblock 75 300 597 minecraft:cobbled_deepslate
setblock 75 300 598 minecraft:calcite
setblock 76 300 597 minecraft:calcite
setblock 76 300 598 minecraft:cobbled_deepslate
fill 77 300 597 80 300 597 minecraft:cobbled_deepslate
fill 78 300 596 81 300 596 minecraft:cobbled_deepslate
setblock 80 300 598 minecraft:calcite
fill 81 300 595 82 300 595 minecraft:cobbled_deepslate
setblock 81 300 597 minecraft:calcite
setblock 81 300 598 minecraft:cobbled_deepslate
setblock 82 300 560 minecraft:light[level=14]
setblock 82 300 568 minecraft:light[level=14]
setblock 82 300 576 minecraft:light[level=14]
setblock 82 300 584 minecraft:light[level=14]
setblock 82 300 592 minecraft:light[level=14]
setblock 82 300 596 minecraft:calcite
setblock 82 300 597 minecraft:cobbled_deepslate
setblock 83 300 595 minecraft:calcite
setblock 83 300 596 minecraft:cobbled_deepslate
setblock 85 300 588 minecraft:calcite
setblock 85 300 589 minecraft:cobbled_deepslate
setblock 85 300 592 minecraft:cobbled_deepslate
setblock 85 300 593 minecraft:calcite
setblock 85 300 598 minecraft:calcite
setblock 86 300 567 minecraft:calcite
fill 86 300 568 86 300 571 minecraft:cobbled_deepslate
setblock 86 300 572 minecraft:calcite
setblock 86 300 573 minecraft:cobbled_deepslate
setblock 86 300 576 minecraft:cobbled_deepslate
setblock 86 300 577 minecraft:calcite
setblock 86 300 583 minecraft:cobbled_deepslate
setblock 86 300 587 minecraft:calcite
setblock 86 300 588 minecraft:cobbled_deepslate
setblock 86 300 592 minecraft:calcite
setblock 86 300 593 minecraft:cobbled_deepslate
setblock 86 300 597 minecraft:calcite
setblock 86 300 598 minecraft:cobbled_deepslate
setblock 87 300 565 minecraft:cobbled_deepslate
setblock 87 300 566 minecraft:calcite
setblock 87 300 567 minecraft:cobbled_deepslate
setblock 87 300 570 minecraft:cobbled_deepslate
setblock 87 300 571 minecraft:calcite
setblock 87 300 572 minecraft:cobbled_deepslate
setblock 87 300 576 minecraft:calcite
setblock 87 300 577 minecraft:cobbled_deepslate
setblock 87 300 581 minecraft:calcite
setblock 87 300 582 minecraft:cobbled_deepslate
setblock 87 300 586 minecraft:calcite
setblock 87 300 587 minecraft:cobbled_deepslate
setblock 87 300 591 minecraft:calcite
setblock 87 300 592 minecraft:cobbled_deepslate
setblock 87 300 596 minecraft:calcite
setblock 88 300 565 minecraft:calcite
setblock 88 300 566 minecraft:cobbled_deepslate
setblock 88 300 570 minecraft:calcite
setblock 88 300 571 minecraft:cobbled_deepslate
setblock 88 300 575 minecraft:calcite
setblock 88 300 576 minecraft:cobbled_deepslate
setblock 88 300 580 minecraft:calcite
setblock 88 300 581 minecraft:cobbled_deepslate
setblock 88 300 585 minecraft:calcite
setblock 88 300 586 minecraft:cobbled_deepslate
setblock 88 300 590 minecraft:calcite
setblock 88 300 591 minecraft:cobbled_deepslate
setblock 88 300 595 minecraft:calcite
setblock 88 300 596 minecraft:cobbled_deepslate
