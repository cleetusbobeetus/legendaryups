fill 196 83 636 196 84 636 minecraft:black_concrete
fill 197 83 625 197 84 625 minecraft:black_concrete
fill 197 83 627 197 84 627 minecraft:black_concrete
fill 197 83 629 197 84 629 minecraft:black_concrete
fill 197 83 631 197 84 631 minecraft:black_concrete
fill 197 83 633 197 84 633 minecraft:black_concrete
fill 197 83 635 197 84 635 minecraft:black_concrete
fill 197 83 637 197 84 637 minecraft:black_concrete
fill 198 83 604 204 87 604 minecraft:cyan_concrete
fill 198 83 606 198 84 606 minecraft:black_concrete
fill 198 83 608 198 84 608 minecraft:black_concrete
fill 198 83 610 198 84 610 minecraft:black_concrete
fill 198 83 612 198 84 612 minecraft:black_concrete
fill 198 83 626 198 84 626 minecraft:black_concrete
fill 198 83 628 198 84 628 minecraft:black_concrete
fill 198 83 630 198 84 630 minecraft:black_concrete
fill 198 83 632 198 84 632 minecraft:black_concrete
fill 198 83 634 198 84 634 minecraft:black_concrete
fill 198 83 636 198 84 636 minecraft:black_concrete
fill 198 83 646 198 156 646 minecraft:cyan_concrete
fill 199 83 605 199 84 605 minecraft:black_concrete
fill 199 83 607 199 84 607 minecraft:black_concrete
fill 199 83 609 199 84 609 minecraft:black_concrete
fill 199 83 611 199 84 611 minecraft:black_concrete
fill 199 83 613 199 84 613 minecraft:black_concrete
fill 200 83 606 200 84 606 minecraft:black_concrete
fill 200 83 608 200 84 608 minecraft:black_concrete
fill 200 83 610 200 84 610 minecraft:black_concrete
fill 200 83 612 200 84 612 minecraft:black_concrete
fill 201 83 605 201 84 605 minecraft:black_concrete
fill 201 83 607 201 84 607 minecraft:black_concrete
fill 201 83 609 201 84 609 minecraft:black_concrete
fill 201 83 611 201 84 611 minecraft:black_concrete
fill 201 83 613 201 84 613 minecraft:black_concrete
fill 201 83 646 202 154 646 minecraft:cyan_concrete
fill 202 83 606 202 84 606 minecraft:black_concrete
fill 202 83 608 202 84 608 minecraft:black_concrete
fill 202 83 610 202 84 610 minecraft:black_concrete
fill 202 83 612 202 84 612 minecraft:black_concrete
fill 203 83 605 203 84 605 minecraft:black_concrete
fill 203 83 607 203 84 607 minecraft:black_concrete
fill 203 83 609 203 84 609 minecraft:black_concrete
fill 203 83 611 203 84 611 minecraft:black_concrete
fill 203 83 613 203 84 613 minecraft:black_concrete
setblock 203 83 646 minecraft:yellow_concrete
fill 204 83 606 204 84 606 minecraft:black_concrete
fill 204 83 608 204 84 608 minecraft:black_concrete
fill 204 83 610 204 84 610 minecraft:black_concrete
fill 204 83 612 204 84 612 minecraft:black_concrete
fill 204 83 646 208 87 646 minecraft:cyan_concrete
setblock 205 83 604 minecraft:yellow_concrete
fill 205 83 605 205 84 605 minecraft:black_concrete
fill 205 83 607 205 84 607 minecraft:black_concrete
fill 205 83 609 205 84 609 minecraft:black_concrete
fill 205 83 611 205 84 611 minecraft:black_concrete
fill 205 83 613 205 84 613 minecraft:black_concrete
fill 206 83 604 210 153 604 minecraft:cyan_concrete
fill 206 83 606 206 84 606 minecraft:black_concrete
fill 206 83 608 206 84 608 minecraft:black_concrete
fill 206 83 610 206 84 610 minecraft:black_concrete
fill 206 83 612 206 84 612 minecraft:black_concrete
fill 207 83 605 207 84 605 minecraft:black_concrete
fill 207 83 607 207 84 607 minecraft:black_concrete
fill 207 83 609 207 84 609 minecraft:black_concrete
fill 207 83 611 207 84 611 minecraft:black_concrete
fill 207 83 613 207 84 613 minecraft:black_concrete
fill 208 83 606 208 84 606 minecraft:black_concrete
fill 208 83 608 208 84 608 minecraft:black_concrete
fill 208 83 610 208 84 610 minecraft:black_concrete
fill 208 83 612 208 84 612 minecraft:black_concrete
fill 209 83 605 209 84 605 minecraft:black_concrete
fill 209 83 607 209 84 607 minecraft:black_concrete
fill 209 83 609 209 84 609 minecraft:black_concrete
fill 209 83 611 209 84 611 minecraft:black_concrete
fill 209 83 613 209 84 613 minecraft:black_concrete
fill 210 83 606 210 84 606 minecraft:black_concrete
fill 210 83 608 210 84 608 minecraft:black_concrete
fill 210 83 610 210 84 610 minecraft:black_concrete
fill 210 83 612 210 84 612 minecraft:black_concrete
setblock 211 83 604 minecraft:yellow_concrete
fill 211 83 646 211 154 646 minecraft:cyan_concrete
fill 212 83 604 212 157 604 minecraft:cyan_concrete
setblock 213 83 604 minecraft:yellow_concrete
fill 214 83 604 214 156 604 minecraft:cyan_concrete
setblock 215 83 604 minecraft:yellow_concrete
fill 216 83 604 216 157 604 minecraft:cyan_concrete
fill 216 83 646 216 156 646 minecraft:cyan_concrete
setblock 217 83 604 minecraft:yellow_concrete
setblock 217 83 646 minecraft:yellow_concrete
fill 218 83 604 222 87 604 minecraft:cyan_concrete
fill 218 83 646 229 87 646 minecraft:cyan_concrete
setblock 223 83 604 minecraft:yellow_concrete
fill 223 83 629 223 84 629 minecraft:black_concrete
fill 223 83 631 223 84 631 minecraft:black_concrete
fill 223 83 633 223 84 633 minecraft:black_concrete
fill 224 83 604 225 154 604 minecraft:cyan_concrete
fill 224 83 628 224 84 628 minecraft:black_concrete
fill 224 83 630 224 84 630 minecraft:black_concrete
fill 224 83 632 224 84 632 minecraft:black_concrete
fill 224 83 634 224 84 634 minecraft:black_concrete
fill 225 83 629 225 84 629 minecraft:black_concrete
fill 225 83 631 225 84 631 minecraft:black_concrete
fill 225 83 633 225 84 633 minecraft:black_concrete
fill 226 83 628 226 84 628 minecraft:black_concrete
fill 226 83 630 226 84 630 minecraft:black_concrete
fill 226 83 632 226 84 632 minecraft:black_concrete
fill 226 83 634 226 84 634 minecraft:black_concrete
fill 227 83 629 227 84 629 minecraft:black_concrete
fill 227 83 631 227 84 631 minecraft:black_concrete
fill 227 83 633 227 84 633 minecraft:black_concrete
fill 228 83 628 228 84 628 minecraft:black_concrete
fill 228 83 630 228 84 630 minecraft:black_concrete
fill 228 83 632 228 84 632 minecraft:black_concrete
fill 228 83 634 228 84 634 minecraft:black_concrete
fill 229 83 629 229 84 629 minecraft:black_concrete
fill 229 83 631 229 84 631 minecraft:black_concrete
fill 229 83 633 229 84 633 minecraft:black_concrete
fill 230 83 604 230 156 604 minecraft:cyan_concrete
setblock 230 83 605 minecraft:yellow_concrete
fill 230 83 606 230 87 612 minecraft:cyan_concrete
fill 230 83 614 230 156 614 minecraft:cyan_concrete
fill 230 83 621 230 154 621 minecraft:cyan_concrete
fill 230 83 623 230 156 623 minecraft:cyan_concrete
fill 230 83 639 230 156 639 minecraft:cyan_concrete
setblock 230 83 646 minecraft:yellow_concrete
fill 188 84 606 188 156 606 minecraft:cyan_concrete
fill 188 84 620 188 156 620 minecraft:cyan_concrete
fill 188 84 639 188 154 640 minecraft:cyan_concrete
fill 189 84 605 189 85 610 minecraft:black_concrete
fill 189 84 613 190 84 618 minecraft:black_concrete
fill 189 84 621 190 84 624 minecraft:black_concrete
fill 189 84 638 190 84 642 minecraft:black_concrete
fill 189 84 645 194 85 645 minecraft:black_concrete
fill 190 84 606 190 84 612 minecraft:black_concrete
fill 190 84 619 190 84 620 minecraft:black_concrete
fill 190 84 643 190 84 644 minecraft:black_concrete
fill 191 84 606 197 84 606 minecraft:black_concrete
fill 191 84 644 229 84 644 minecraft:black_concrete
fill 192 84 605 197 85 605 minecraft:black_concrete
fill 196 84 604 197 152 604 minecraft:cyan_concrete
fill 197 84 645 202 85 645 minecraft:black_concrete
fill 199 84 627 199 88 627 minecraft:black_concrete
fill 199 84 631 199 88 631 minecraft:black_concrete
fill 200 84 628 200 88 630 minecraft:black_concrete
fill 200 84 646 200 156 646 minecraft:cyan_concrete
fill 203 84 646 203 156 646 minecraft:cyan_concrete
fill 205 84 604 205 156 604 minecraft:cyan_concrete
fill 205 84 645 210 85 645 minecraft:black_concrete
fill 211 84 604 211 87 604 minecraft:cyan_concrete
fill 211 84 605 213 84 606 minecraft:black_concrete
fill 213 84 604 213 156 604 minecraft:cyan_concrete
fill 213 84 645 218 85 645 minecraft:black_concrete
fill 214 84 606 228 84 606 minecraft:black_concrete
fill 215 84 604 215 156 604 minecraft:cyan_concrete
fill 216 84 605 221 85 605 minecraft:black_concrete
fill 217 84 604 217 152 604 minecraft:cyan_concrete
fill 217 84 646 217 156 646 minecraft:cyan_concrete
fill 221 84 645 226 85 645 minecraft:black_concrete
fill 223 84 604 223 156 604 minecraft:cyan_concrete
fill 224 84 605 229 85 605 minecraft:black_concrete
fill 228 84 607 228 84 627 minecraft:black_concrete
fill 228 84 635 228 84 643 minecraft:black_concrete
fill 229 84 608 229 85 613 minecraft:black_concrete
fill 229 84 616 229 85 621 minecraft:black_concrete
fill 229 84 624 229 85 627 minecraft:black_concrete
fill 229 84 635 229 85 637 minecraft:black_concrete
fill 229 84 640 229 85 643 minecraft:black_concrete
fill 229 84 645 229 85 645 minecraft:black_concrete
fill 230 84 605 230 156 605 minecraft:cyan_concrete
fill 230 84 630 230 156 630 minecraft:cyan_concrete
fill 230 84 646 230 153 646 minecraft:cyan_concrete
fill 189 85 613 189 85 618 minecraft:black_concrete
fill 189 85 621 189 85 624 minecraft:black_concrete
setblock 189 85 625 minecraft:sea_lantern
setblock 189 85 627 minecraft:sea_lantern
setblock 189 85 629 minecraft:sea_lantern
setblock 189 85 631 minecraft:sea_lantern
setblock 189 85 633 minecraft:sea_lantern
setblock 189 85 635 minecraft:sea_lantern
setblock 189 85 637 minecraft:sea_lantern
fill 189 85 638 189 85 642 minecraft:black_concrete
setblock 190 85 626 minecraft:sea_lantern
setblock 190 85 628 minecraft:sea_lantern
setblock 190 85 630 minecraft:sea_lantern
setblock 190 85 632 minecraft:sea_lantern
setblock 190 85 634 minecraft:sea_lantern
setblock 190 85 636 minecraft:sea_lantern
setblock 191 85 625 minecraft:sea_lantern
setblock 191 85 627 minecraft:sea_lantern
setblock 191 85 629 minecraft:sea_lantern
setblock 191 85 631 minecraft:sea_lantern
setblock 191 85 633 minecraft:sea_lantern
setblock 191 85 635 minecraft:sea_lantern
setblock 191 85 637 minecraft:sea_lantern
setblock 192 85 626 minecraft:sea_lantern
setblock 192 85 628 minecraft:sea_lantern
setblock 192 85 630 minecraft:sea_lantern
setblock 192 85 632 minecraft:sea_lantern
setblock 192 85 634 minecraft:sea_lantern
setblock 192 85 636 minecraft:sea_lantern
setblock 193 85 625 minecraft:sea_lantern
setblock 193 85 627 minecraft:sea_lantern
setblock 193 85 629 minecraft:sea_lantern
setblock 193 85 631 minecraft:sea_lantern
setblock 193 85 633 minecraft:sea_lantern
setblock 193 85 635 minecraft:sea_lantern
setblock 193 85 637 minecraft:sea_lantern
setblock 194 85 626 minecraft:sea_lantern
setblock 194 85 628 minecraft:sea_lantern
setblock 194 85 630 minecraft:sea_lantern
setblock 194 85 632 minecraft:sea_lantern
setblock 194 85 634 minecraft:sea_lantern
setblock 194 85 636 minecraft:sea_lantern
setblock 195 85 625 minecraft:sea_lantern
setblock 195 85 627 minecraft:sea_lantern
setblock 195 85 629 minecraft:sea_lantern
setblock 195 85 631 minecraft:sea_lantern
setblock 195 85 633 minecraft:sea_lantern
setblock 195 85 635 minecraft:sea_lantern
setblock 195 85 637 minecraft:sea_lantern
setblock 196 85 626 minecraft:sea_lantern
setblock 196 85 628 minecraft:sea_lantern
setblock 196 85 630 minecraft:sea_lantern
setblock 196 85 632 minecraft:sea_lantern
setblock 196 85 634 minecraft:sea_lantern
setblock 196 85 636 minecraft:sea_lantern
setblock 197 85 625 minecraft:sea_lantern
setblock 197 85 627 minecraft:sea_lantern
setblock 197 85 629 minecraft:sea_lantern
setblock 197 85 631 minecraft:sea_lantern
setblock 197 85 633 minecraft:sea_lantern
setblock 197 85 635 minecraft:sea_lantern
setblock 197 85 637 minecraft:sea_lantern
setblock 198 85 606 minecraft:sea_lantern
setblock 198 85 608 minecraft:sea_lantern
setblock 198 85 610 minecraft:sea_lantern
setblock 198 85 612 minecraft:sea_lantern
setblock 198 85 626 minecraft:sea_lantern
setblock 198 85 628 minecraft:sea_lantern
setblock 198 85 630 minecraft:sea_lantern
setblock 198 85 632 minecraft:sea_lantern
setblock 198 85 634 minecraft:sea_lantern
setblock 198 85 636 minecraft:sea_lantern
setblock 199 85 605 minecraft:sea_lantern
setblock 199 85 607 minecraft:sea_lantern
setblock 199 85 609 minecraft:sea_lantern
setblock 199 85 611 minecraft:sea_lantern
setblock 199 85 613 minecraft:sea_lantern
setblock 200 85 606 minecraft:sea_lantern
setblock 200 85 608 minecraft:sea_lantern
setblock 200 85 610 minecraft:sea_lantern
setblock 200 85 612 minecraft:sea_lantern
fill 200 85 627 200 88 627 minecraft:black_concrete
fill 200 85 631 200 88 631 minecraft:black_concrete
setblock 201 85 605 minecraft:sea_lantern
setblock 201 85 607 minecraft:sea_lantern
setblock 201 85 609 minecraft:sea_lantern
setblock 201 85 611 minecraft:sea_lantern
setblock 201 85 613 minecraft:sea_lantern
setblock 202 85 606 minecraft:sea_lantern
setblock 202 85 608 minecraft:sea_lantern
setblock 202 85 610 minecraft:sea_lantern
setblock 202 85 612 minecraft:sea_lantern
setblock 203 85 605 minecraft:sea_lantern
setblock 203 85 607 minecraft:sea_lantern
setblock 203 85 609 minecraft:sea_lantern
setblock 203 85 611 minecraft:sea_lantern
setblock 203 85 613 minecraft:sea_lantern
setblock 204 85 606 minecraft:sea_lantern
setblock 204 85 608 minecraft:sea_lantern
setblock 204 85 610 minecraft:sea_lantern
setblock 204 85 612 minecraft:sea_lantern
setblock 205 85 605 minecraft:sea_lantern
setblock 205 85 607 minecraft:sea_lantern
setblock 205 85 609 minecraft:sea_lantern
setblock 205 85 611 minecraft:sea_lantern
setblock 205 85 613 minecraft:sea_lantern
setblock 206 85 606 minecraft:sea_lantern
setblock 206 85 608 minecraft:sea_lantern
setblock 206 85 610 minecraft:sea_lantern
setblock 206 85 612 minecraft:sea_lantern
setblock 207 85 605 minecraft:sea_lantern
setblock 207 85 607 minecraft:sea_lantern
setblock 207 85 609 minecraft:sea_lantern
setblock 207 85 611 minecraft:sea_lantern
setblock 207 85 613 minecraft:sea_lantern
setblock 208 85 606 minecraft:sea_lantern
setblock 208 85 608 minecraft:sea_lantern
setblock 208 85 610 minecraft:sea_lantern
setblock 208 85 612 minecraft:sea_lantern
setblock 209 85 605 minecraft:sea_lantern
setblock 209 85 607 minecraft:sea_lantern
setblock 209 85 609 minecraft:sea_lantern
setblock 209 85 611 minecraft:sea_lantern
setblock 209 85 613 minecraft:sea_lantern
setblock 210 85 606 minecraft:sea_lantern
setblock 210 85 608 minecraft:sea_lantern
setblock 210 85 610 minecraft:sea_lantern
setblock 210 85 612 minecraft:sea_lantern
fill 211 85 605 213 85 605 minecraft:black_concrete
setblock 223 85 629 minecraft:sea_lantern
setblock 223 85 631 minecraft:sea_lantern
setblock 223 85 633 minecraft:sea_lantern
setblock 224 85 628 minecraft:sea_lantern
setblock 224 85 630 minecraft:sea_lantern
setblock 224 85 632 minecraft:sea_lantern
setblock 224 85 634 minecraft:sea_lantern
setblock 225 85 629 minecraft:sea_lantern
setblock 225 85 631 minecraft:sea_lantern
setblock 225 85 633 minecraft:sea_lantern
setblock 226 85 628 minecraft:sea_lantern
setblock 226 85 630 minecraft:sea_lantern
setblock 226 85 632 minecraft:sea_lantern
setblock 226 85 634 minecraft:sea_lantern
setblock 227 85 629 minecraft:sea_lantern
setblock 227 85 631 minecraft:sea_lantern
setblock 227 85 633 minecraft:sea_lantern
setblock 228 85 628 minecraft:sea_lantern
setblock 228 85 630 minecraft:sea_lantern
setblock 228 85 632 minecraft:sea_lantern
setblock 228 85 634 minecraft:sea_lantern
setblock 229 85 629 minecraft:sea_lantern
setblock 229 85 631 minecraft:sea_lantern
setblock 229 85 633 minecraft:sea_lantern
setblock 229 85 644 minecraft:black_concrete
fill 189 86 625 189 87 625 minecraft:black_concrete
fill 189 86 627 189 87 627 minecraft:black_concrete
fill 189 86 629 189 87 629 minecraft:black_concrete
fill 189 86 631 189 87 631 minecraft:black_concrete
fill 189 86 633 189 87 633 minecraft:black_concrete
fill 189 86 635 189 87 635 minecraft:black_concrete
fill 189 86 637 189 87 637 minecraft:black_concrete
fill 190 86 626 190 87 626 minecraft:black_concrete
fill 190 86 628 190 87 628 minecraft:black_concrete
fill 190 86 630 190 87 630 minecraft:black_concrete
fill 190 86 632 190 87 632 minecraft:black_concrete
fill 190 86 634 190 87 634 minecraft:black_concrete
fill 190 86 636 190 87 636 minecraft:black_concrete
fill 191 86 625 191 87 625 minecraft:black_concrete
fill 191 86 627 191 87 627 minecraft:black_concrete
fill 191 86 629 191 87 629 minecraft:black_concrete
fill 191 86 631 191 87 631 minecraft:black_concrete
fill 191 86 633 191 87 633 minecraft:black_concrete
fill 191 86 635 191 87 635 minecraft:black_concrete
fill 191 86 637 191 87 637 minecraft:black_concrete
fill 192 86 626 192 87 626 minecraft:black_concrete
fill 192 86 628 192 87 628 minecraft:black_concrete
fill 192 86 630 192 87 630 minecraft:black_concrete
fill 192 86 632 192 87 632 minecraft:black_concrete
fill 192 86 634 192 87 634 minecraft:black_concrete
fill 192 86 636 192 87 636 minecraft:black_concrete
fill 193 86 625 193 87 625 minecraft:black_concrete
fill 193 86 627 193 87 627 minecraft:black_concrete
fill 193 86 629 193 87 629 minecraft:black_concrete
fill 193 86 631 193 87 631 minecraft:black_concrete
fill 193 86 633 193 87 633 minecraft:black_concrete
fill 193 86 635 193 87 635 minecraft:black_concrete
fill 193 86 637 193 87 637 minecraft:black_concrete
fill 194 86 626 194 87 626 minecraft:black_concrete
fill 194 86 628 194 87 628 minecraft:black_concrete
fill 194 86 630 194 87 630 minecraft:black_concrete
fill 194 86 632 194 87 632 minecraft:black_concrete
fill 194 86 634 194 87 634 minecraft:black_concrete
fill 194 86 636 194 87 636 minecraft:black_concrete
fill 195 86 625 195 87 625 minecraft:black_concrete
fill 195 86 627 195 87 627 minecraft:black_concrete
fill 195 86 629 195 87 629 minecraft:black_concrete
fill 195 86 631 195 87 631 minecraft:black_concrete
fill 195 86 633 195 87 633 minecraft:black_concrete
fill 195 86 635 195 87 635 minecraft:black_concrete
fill 195 86 637 195 87 637 minecraft:black_concrete
fill 196 86 626 196 87 626 minecraft:black_concrete
fill 196 86 628 196 87 628 minecraft:black_concrete
fill 196 86 630 196 87 630 minecraft:black_concrete
fill 196 86 632 196 87 632 minecraft:black_concrete
fill 196 86 634 196 87 634 minecraft:black_concrete
fill 196 86 636 196 87 636 minecraft:black_concrete
fill 197 86 625 197 87 625 minecraft:black_concrete
fill 197 86 627 197 87 627 minecraft:black_concrete
fill 197 86 629 197 87 629 minecraft:black_concrete
fill 197 86 631 197 87 631 minecraft:black_concrete
fill 197 86 633 197 87 633 minecraft:black_concrete
fill 197 86 635 197 87 635 minecraft:black_concrete
fill 197 86 637 197 87 637 minecraft:black_concrete
fill 198 86 606 198 87 606 minecraft:black_concrete
fill 198 86 608 198 87 608 minecraft:black_concrete
fill 198 86 610 198 87 610 minecraft:black_concrete
fill 198 86 612 198 87 612 minecraft:black_concrete
fill 198 86 626 199 87 626 minecraft:black_concrete
fill 198 86 628 198 87 628 minecraft:black_concrete
fill 198 86 630 198 87 630 minecraft:black_concrete
fill 198 86 632 199 87 632 minecraft:black_concrete
fill 198 86 634 198 87 634 minecraft:black_concrete
fill 198 86 636 198 87 636 minecraft:black_concrete
fill 199 86 605 199 87 605 minecraft:black_concrete
fill 199 86 607 199 87 607 minecraft:black_concrete
fill 199 86 609 199 87 609 minecraft:black_concrete
fill 199 86 611 199 87 611 minecraft:black_concrete
fill 199 86 613 199 87 613 minecraft:black_concrete
fill 200 86 606 200 87 606 minecraft:black_concrete
fill 200 86 608 200 87 608 minecraft:black_concrete
fill 200 86 610 200 87 610 minecraft:black_concrete
fill 200 86 612 200 87 612 minecraft:black_concrete
fill 201 86 605 201 87 605 minecraft:black_concrete
fill 201 86 607 201 87 607 minecraft:black_concrete
fill 201 86 609 201 87 609 minecraft:black_concrete
fill 201 86 611 201 87 611 minecraft:black_concrete
fill 201 86 613 201 87 613 minecraft:black_concrete
fill 201 86 628 201 88 630 minecraft:black_concrete
fill 202 86 606 202 87 606 minecraft:black_concrete
fill 202 86 608 202 87 608 minecraft:black_concrete
fill 202 86 610 202 87 610 minecraft:black_concrete
fill 202 86 612 202 87 612 minecraft:black_concrete
fill 203 86 605 203 87 605 minecraft:black_concrete
fill 203 86 607 203 87 607 minecraft:black_concrete
fill 203 86 609 203 87 609 minecraft:black_concrete
fill 203 86 611 203 87 611 minecraft:black_concrete
fill 203 86 613 203 87 613 minecraft:black_concrete
fill 204 86 606 204 87 606 minecraft:black_concrete
fill 204 86 608 204 87 608 minecraft:black_concrete
fill 204 86 610 204 87 610 minecraft:black_concrete
fill 204 86 612 204 87 612 minecraft:black_concrete
fill 205 86 605 205 87 605 minecraft:black_concrete
fill 205 86 607 205 87 607 minecraft:black_concrete
fill 205 86 609 205 87 609 minecraft:black_concrete
fill 205 86 611 205 87 611 minecraft:black_concrete
fill 205 86 613 205 87 613 minecraft:black_concrete
fill 206 86 606 206 87 606 minecraft:black_concrete
fill 206 86 608 206 87 608 minecraft:black_concrete
fill 206 86 610 206 87 610 minecraft:black_concrete
fill 206 86 612 206 87 612 minecraft:black_concrete
fill 207 86 605 207 87 605 minecraft:black_concrete
fill 207 86 607 207 87 607 minecraft:black_concrete
fill 207 86 609 207 87 609 minecraft:black_concrete
fill 207 86 611 207 87 611 minecraft:black_concrete
fill 207 86 613 207 87 613 minecraft:black_concrete
fill 208 86 606 208 87 606 minecraft:black_concrete
fill 208 86 608 208 87 608 minecraft:black_concrete
fill 208 86 610 208 87 610 minecraft:black_concrete
fill 208 86 612 208 87 612 minecraft:black_concrete
fill 209 86 605 209 87 605 minecraft:black_concrete
fill 209 86 607 209 87 607 minecraft:black_concrete
fill 209 86 609 209 87 609 minecraft:black_concrete
fill 209 86 611 209 87 611 minecraft:black_concrete
fill 209 86 613 209 87 613 minecraft:black_concrete
fill 210 86 606 210 87 606 minecraft:black_concrete
fill 210 86 608 210 87 608 minecraft:black_concrete
fill 210 86 610 210 87 610 minecraft:black_concrete
fill 210 86 612 210 87 612 minecraft:black_concrete
fill 223 86 629 223 87 629 minecraft:black_concrete
fill 223 86 631 223 87 631 minecraft:black_concrete
fill 223 86 633 223 87 633 minecraft:black_concrete
fill 224 86 628 224 87 628 minecraft:black_concrete
fill 224 86 630 224 87 630 minecraft:black_concrete
fill 224 86 632 224 87 632 minecraft:black_concrete
fill 224 86 634 224 87 634 minecraft:black_concrete
fill 225 86 629 225 87 629 minecraft:black_concrete
fill 225 86 631 225 87 631 minecraft:black_concrete
fill 225 86 633 225 87 633 minecraft:black_concrete
fill 226 86 628 226 87 628 minecraft:black_concrete
fill 226 86 630 226 87 630 minecraft:black_concrete
fill 226 86 632 226 87 632 minecraft:black_concrete
fill 226 86 634 226 87 634 minecraft:black_concrete
fill 227 86 629 227 87 629 minecraft:black_concrete
fill 227 86 631 227 87 631 minecraft:black_concrete
fill 227 86 633 227 87 633 minecraft:black_concrete
fill 228 86 628 228 87 628 minecraft:black_concrete
fill 228 86 630 228 87 630 minecraft:black_concrete
fill 228 86 632 228 87 632 minecraft:black_concrete
fill 228 86 634 228 87 634 minecraft:black_concrete
fill 229 86 629 229 87 629 minecraft:black_concrete
fill 229 86 631 229 87 631 minecraft:black_concrete
fill 229 86 633 229 87 633 minecraft:black_concrete
setblock 191 87 607 minecraft:light[level=14]
setblock 191 87 615 minecraft:light[level=14]
setblock 191 87 623 minecraft:light[level=14]
setblock 191 87 639 minecraft:light[level=14]
setblock 199 87 615 minecraft:light[level=14]
setblock 199 87 623 minecraft:light[level=14]
setblock 199 87 639 minecraft:light[level=14]
fill 200 87 626 200 88 626 minecraft:black_concrete
fill 200 87 632 200 88 632 minecraft:black_concrete
fill 201 87 627 201 88 627 minecraft:black_concrete
fill 201 87 631 201 88 631 minecraft:black_concrete
setblock 207 87 615 minecraft:light[level=14]
setblock 207 87 623 minecraft:light[level=14]
setblock 207 87 631 minecraft:light[level=14]
setblock 207 87 639 minecraft:light[level=14]
fill 209 87 616 211 88 617 minecraft:yellow_concrete
setblock 215 87 607 minecraft:light[level=14]
setblock 215 87 615 minecraft:light[level=14]
setblock 215 87 623 minecraft:light[level=14]
setblock 215 87 631 minecraft:light[level=14]
setblock 215 87 639 minecraft:light[level=14]
setblock 223 87 607 minecraft:light[level=14]
setblock 223 87 615 minecraft:light[level=14]
setblock 223 87 623 minecraft:light[level=14]
setblock 223 87 639 minecraft:light[level=14]
fill 188 88 607 188 152 608 minecraft:cyan_concrete
fill 188 88 609 188 93 609 minecraft:sea_lantern
fill 188 88 610 188 153 616 minecraft:cyan_concrete
fill 188 88 617 188 93 617 minecraft:sea_lantern
fill 188 88 618 188 156 619 minecraft:cyan_concrete
fill 188 88 621 188 152 624 minecraft:cyan_concrete
fill 188 88 625 189 88 625 minecraft:sea_lantern
fill 188 88 626 188 152 631 minecraft:cyan_concrete
fill 188 88 633 189 88 633 minecraft:sea_lantern
fill 188 88 641 188 93 641 minecraft:sea_lantern
fill 188 88 642 188 152 646 minecraft:cyan_concrete
setblock 189 88 627 minecraft:sea_lantern
setblock 189 88 629 minecraft:sea_lantern
setblock 189 88 631 minecraft:sea_lantern
setblock 189 88 635 minecraft:sea_lantern
setblock 189 88 637 minecraft:sea_lantern
setblock 190 88 626 minecraft:sea_lantern
setblock 190 88 628 minecraft:sea_lantern
setblock 190 88 630 minecraft:sea_lantern
setblock 190 88 632 minecraft:sea_lantern
setblock 190 88 634 minecraft:sea_lantern
setblock 190 88 636 minecraft:sea_lantern
setblock 191 88 625 minecraft:sea_lantern
setblock 191 88 627 minecraft:sea_lantern
setblock 191 88 629 minecraft:sea_lantern
setblock 191 88 631 minecraft:sea_lantern
setblock 191 88 633 minecraft:sea_lantern
setblock 191 88 635 minecraft:sea_lantern
setblock 191 88 637 minecraft:sea_lantern
fill 191 88 646 191 93 646 minecraft:sea_lantern
setblock 192 88 626 minecraft:sea_lantern
setblock 192 88 628 minecraft:sea_lantern
setblock 192 88 630 minecraft:sea_lantern
setblock 192 88 632 minecraft:sea_lantern
setblock 192 88 634 minecraft:sea_lantern
setblock 192 88 636 minecraft:sea_lantern
fill 192 88 646 197 150 646 minecraft:cyan_concrete
setblock 193 88 625 minecraft:sea_lantern
setblock 193 88 627 minecraft:sea_lantern
setblock 193 88 629 minecraft:sea_lantern
setblock 193 88 631 minecraft:sea_lantern
setblock 193 88 633 minecraft:sea_lantern
setblock 193 88 635 minecraft:sea_lantern
setblock 193 88 637 minecraft:sea_lantern
setblock 194 88 626 minecraft:sea_lantern
setblock 194 88 628 minecraft:sea_lantern
setblock 194 88 630 minecraft:sea_lantern
setblock 194 88 632 minecraft:sea_lantern
setblock 194 88 634 minecraft:sea_lantern
setblock 194 88 636 minecraft:sea_lantern
fill 195 88 604 195 93 604 minecraft:sea_lantern
setblock 195 88 625 minecraft:sea_lantern
setblock 195 88 627 minecraft:sea_lantern
setblock 195 88 629 minecraft:sea_lantern
setblock 195 88 631 minecraft:sea_lantern
setblock 195 88 633 minecraft:sea_lantern
setblock 195 88 635 minecraft:sea_lantern
setblock 195 88 637 minecraft:sea_lantern
setblock 196 88 626 minecraft:sea_lantern
setblock 196 88 628 minecraft:sea_lantern
setblock 196 88 630 minecraft:sea_lantern
setblock 196 88 632 minecraft:sea_lantern
setblock 196 88 634 minecraft:sea_lantern
setblock 196 88 636 minecraft:sea_lantern
setblock 197 88 625 minecraft:sea_lantern
setblock 197 88 627 minecraft:sea_lantern
setblock 197 88 629 minecraft:sea_lantern
setblock 197 88 631 minecraft:sea_lantern
setblock 197 88 633 minecraft:sea_lantern
setblock 197 88 635 minecraft:sea_lantern
setblock 197 88 637 minecraft:sea_lantern
fill 198 88 604 202 154 604 minecraft:cyan_concrete
setblock 198 88 606 minecraft:sea_lantern
setblock 198 88 608 minecraft:sea_lantern
setblock 198 88 610 minecraft:sea_lantern
setblock 198 88 612 minecraft:sea_lantern
setblock 198 88 626 minecraft:sea_lantern
setblock 198 88 628 minecraft:sea_lantern
setblock 198 88 630 minecraft:sea_lantern
setblock 198 88 632 minecraft:sea_lantern
setblock 198 88 634 minecraft:sea_lantern
setblock 198 88 636 minecraft:sea_lantern
setblock 199 88 605 minecraft:sea_lantern
setblock 199 88 607 minecraft:sea_lantern
setblock 199 88 609 minecraft:sea_lantern
setblock 199 88 611 minecraft:sea_lantern
setblock 199 88 613 minecraft:sea_lantern
fill 199 88 625 199 88 626 minecraft:black_concrete
fill 199 88 632 199 88 633 minecraft:black_concrete
fill 199 88 646 199 93 646 minecraft:sea_lantern
setblock 200 88 606 minecraft:sea_lantern
setblock 200 88 608 minecraft:sea_lantern
setblock 200 88 610 minecraft:sea_lantern
setblock 200 88 612 minecraft:sea_lantern
setblock 201 88 605 minecraft:sea_lantern
setblock 201 88 607 minecraft:sea_lantern
setblock 201 88 609 minecraft:sea_lantern
setblock 201 88 611 minecraft:sea_lantern
setblock 201 88 613 minecraft:sea_lantern
setblock 201 88 626 minecraft:black_concrete
setblock 201 88 632 minecraft:black_concrete
setblock 202 88 606 minecraft:sea_lantern
setblock 202 88 608 minecraft:sea_lantern
setblock 202 88 610 minecraft:sea_lantern
setblock 202 88 612 minecraft:sea_lantern
fill 202 88 628 202 88 630 minecraft:black_concrete
fill 203 88 604 203 88 605 minecraft:sea_lantern
setblock 203 88 607 minecraft:sea_lantern
setblock 203 88 609 minecraft:sea_lantern
setblock 203 88 611 minecraft:sea_lantern
setblock 203 88 613 minecraft:sea_lantern
fill 204 88 604 204 153 604 minecraft:cyan_concrete
setblock 204 88 606 minecraft:sea_lantern
setblock 204 88 608 minecraft:sea_lantern
setblock 204 88 610 minecraft:sea_lantern
setblock 204 88 612 minecraft:sea_lantern
fill 204 88 646 206 152 646 minecraft:cyan_concrete
setblock 205 88 605 minecraft:sea_lantern
setblock 205 88 607 minecraft:sea_lantern
setblock 205 88 609 minecraft:sea_lantern
setblock 205 88 611 minecraft:sea_lantern
setblock 205 88 613 minecraft:sea_lantern
setblock 206 88 606 minecraft:sea_lantern
setblock 206 88 608 minecraft:sea_lantern
setblock 206 88 610 minecraft:sea_lantern
setblock 206 88 612 minecraft:sea_lantern
setblock 207 88 605 minecraft:sea_lantern
setblock 207 88 607 minecraft:sea_lantern
setblock 207 88 609 minecraft:sea_lantern
setblock 207 88 611 minecraft:sea_lantern
setblock 207 88 613 minecraft:sea_lantern
fill 207 88 646 207 93 646 minecraft:sea_lantern
setblock 208 88 606 minecraft:sea_lantern
setblock 208 88 608 minecraft:sea_lantern
setblock 208 88 610 minecraft:sea_lantern
setblock 208 88 612 minecraft:sea_lantern
fill 208 88 646 208 156 646 minecraft:cyan_concrete
setblock 209 88 605 minecraft:sea_lantern
setblock 209 88 607 minecraft:sea_lantern
setblock 209 88 609 minecraft:sea_lantern
setblock 209 88 611 minecraft:sea_lantern
setblock 209 88 613 minecraft:sea_lantern
setblock 210 88 606 minecraft:sea_lantern
setblock 210 88 608 minecraft:sea_lantern
setblock 210 88 610 minecraft:sea_lantern
setblock 210 88 612 minecraft:sea_lantern
fill 211 88 604 211 93 604 minecraft:sea_lantern
fill 212 88 646 214 156 646 minecraft:cyan_concrete
fill 215 88 646 215 93 646 minecraft:sea_lantern
fill 218 88 604 218 156 604 minecraft:cyan_concrete
fill 218 88 646 222 153 646 minecraft:cyan_concrete
fill 219 88 604 219 93 604 minecraft:sea_lantern
fill 220 88 604 222 156 604 minecraft:cyan_concrete
setblock 223 88 629 minecraft:sea_lantern
setblock 223 88 631 minecraft:sea_lantern
setblock 223 88 633 minecraft:sea_lantern
fill 223 88 646 223 93 646 minecraft:sea_lantern
setblock 224 88 628 minecraft:sea_lantern
setblock 224 88 630 minecraft:sea_lantern
setblock 224 88 632 minecraft:sea_lantern
setblock 224 88 634 minecraft:sea_lantern
fill 224 88 646 229 156 646 minecraft:cyan_concrete
setblock 225 88 629 minecraft:sea_lantern
setblock 225 88 631 minecraft:sea_lantern
setblock 225 88 633 minecraft:sea_lantern
fill 226 88 604 226 156 604 minecraft:cyan_concrete
setblock 226 88 628 minecraft:sea_lantern
setblock 226 88 630 minecraft:sea_lantern
setblock 226 88 632 minecraft:sea_lantern
setblock 226 88 634 minecraft:sea_lantern
fill 227 88 604 227 93 604 minecraft:sea_lantern
setblock 227 88 629 minecraft:sea_lantern
setblock 227 88 631 minecraft:sea_lantern
setblock 227 88 633 minecraft:sea_lantern
fill 228 88 604 229 156 604 minecraft:cyan_concrete
setblock 228 88 628 minecraft:sea_lantern
setblock 228 88 630 minecraft:sea_lantern
setblock 228 88 632 minecraft:sea_lantern
setblock 228 88 634 minecraft:sea_lantern
setblock 229 88 629 minecraft:sea_lantern
setblock 229 88 631 minecraft:sea_lantern
fill 229 88 633 230 88 633 minecraft:sea_lantern
fill 230 88 606 230 154 608 minecraft:cyan_concrete
fill 230 88 609 230 93 609 minecraft:sea_lantern
fill 230 88 610 230 152 612 minecraft:cyan_concrete
fill 230 88 615 230 152 616 minecraft:cyan_concrete
fill 230 88 617 230 93 617 minecraft:sea_lantern
fill 230 88 618 230 154 620 minecraft:cyan_concrete
fill 230 88 624 230 156 624 minecraft:cyan_concrete
fill 230 88 625 230 93 625 minecraft:sea_lantern
fill 230 88 626 230 154 629 minecraft:cyan_concrete
fill 230 88 631 230 156 632 minecraft:cyan_concrete
fill 230 88 634 230 152 638 minecraft:cyan_concrete
fill 230 88 640 230 156 640 minecraft:cyan_concrete
fill 230 88 641 230 93 641 minecraft:sea_lantern
fill 230 88 642 230 152 645 minecraft:cyan_concrete
fill 188 89 625 188 93 625 minecraft:sea_lantern
fill 188 89 633 188 93 633 minecraft:sea_lantern
fill 189 89 625 189 90 625 minecraft:black_concrete
fill 189 89 627 189 90 627 minecraft:black_concrete
fill 189 89 629 189 90 629 minecraft:black_concrete
fill 189 89 631 189 90 631 minecraft:black_concrete
fill 189 89 633 189 90 633 minecraft:black_concrete
fill 189 89 635 189 90 635 minecraft:black_concrete
fill 189 89 637 189 90 637 minecraft:black_concrete
fill 190 89 626 190 90 626 minecraft:black_concrete
fill 190 89 628 190 90 628 minecraft:black_concrete
fill 190 89 630 190 90 630 minecraft:black_concrete
fill 190 89 632 190 90 632 minecraft:black_concrete
fill 190 89 634 190 90 634 minecraft:black_concrete
fill 190 89 636 190 90 636 minecraft:black_concrete
fill 191 89 625 191 90 625 minecraft:black_concrete
fill 191 89 627 191 90 627 minecraft:black_concrete
fill 191 89 629 191 90 629 minecraft:black_concrete
fill 191 89 631 191 90 631 minecraft:black_concrete
fill 191 89 633 191 90 633 minecraft:black_concrete
fill 191 89 635 191 90 635 minecraft:black_concrete
fill 191 89 637 191 90 637 minecraft:black_concrete
fill 192 89 626 192 90 626 minecraft:black_concrete
fill 192 89 628 192 90 628 minecraft:black_concrete
fill 192 89 630 192 90 630 minecraft:black_concrete
fill 192 89 632 192 90 632 minecraft:black_concrete
fill 192 89 634 192 90 634 minecraft:black_concrete
fill 192 89 636 192 90 636 minecraft:black_concrete
fill 193 89 625 193 90 625 minecraft:black_concrete
fill 193 89 627 193 90 627 minecraft:black_concrete
fill 193 89 629 193 90 629 minecraft:black_concrete
fill 193 89 631 193 90 631 minecraft:black_concrete
fill 193 89 633 193 90 633 minecraft:black_concrete
fill 193 89 635 193 90 635 minecraft:black_concrete
fill 193 89 637 193 90 637 minecraft:black_concrete
fill 194 89 626 194 90 626 minecraft:black_concrete
fill 194 89 628 194 90 628 minecraft:black_concrete
fill 194 89 630 194 90 630 minecraft:black_concrete
fill 194 89 632 194 90 632 minecraft:black_concrete
fill 194 89 634 194 90 634 minecraft:black_concrete
fill 194 89 636 194 90 636 minecraft:black_concrete
fill 195 89 625 195 90 625 minecraft:black_concrete
fill 195 89 627 195 90 627 minecraft:black_concrete
fill 195 89 629 195 90 629 minecraft:black_concrete
fill 195 89 631 195 90 631 minecraft:black_concrete
fill 195 89 633 195 90 633 minecraft:black_concrete
fill 195 89 635 195 90 635 minecraft:black_concrete
fill 195 89 637 195 90 637 minecraft:black_concrete
fill 196 89 626 196 90 626 minecraft:black_concrete
fill 196 89 628 196 90 628 minecraft:black_concrete
fill 196 89 630 196 90 630 minecraft:black_concrete
fill 196 89 632 196 90 632 minecraft:black_concrete
fill 196 89 634 196 90 634 minecraft:black_concrete
fill 196 89 636 196 90 636 minecraft:black_concrete
fill 197 89 625 197 90 625 minecraft:black_concrete
fill 197 89 627 197 90 627 minecraft:black_concrete
fill 197 89 629 199 89 629 minecraft:white_stained_glass
fill 197 89 631 197 90 631 minecraft:black_concrete
fill 197 89 633 197 90 633 minecraft:black_concrete
fill 197 89 635 197 90 635 minecraft:black_concrete
fill 197 89 637 197 90 637 minecraft:black_concrete
fill 198 89 606 198 90 606 minecraft:black_concrete
fill 198 89 608 198 90 608 minecraft:black_concrete
fill 198 89 610 198 90 610 minecraft:black_concrete
fill 198 89 612 198 90 612 minecraft:black_concrete
fill 198 89 626 198 90 626 minecraft:black_concrete
fill 198 89 628 198 90 628 minecraft:white_stained_glass
fill 198 89 630 198 90 630 minecraft:white_stained_glass
fill 198 89 632 198 90 632 minecraft:black_concrete
fill 198 89 634 198 90 634 minecraft:black_concrete
fill 198 89 636 198 90 636 minecraft:black_concrete
fill 199 89 605 199 90 605 minecraft:black_concrete
fill 199 89 607 199 90 607 minecraft:black_concrete
fill 199 89 609 199 90 609 minecraft:black_concrete
fill 199 89 611 199 90 611 minecraft:black_concrete
fill 199 89 613 199 90 613 minecraft:black_concrete
fill 200 89 606 200 90 606 minecraft:black_concrete
fill 200 89 608 200 90 608 minecraft:black_concrete
fill 200 89 610 200 90 610 minecraft:black_concrete
fill 200 89 612 200 90 612 minecraft:black_concrete
fill 201 89 605 201 90 605 minecraft:black_concrete
fill 201 89 607 201 90 607 minecraft:black_concrete
fill 201 89 609 201 90 609 minecraft:black_concrete
fill 201 89 611 201 90 611 minecraft:black_concrete
fill 201 89 613 201 90 613 minecraft:black_concrete
fill 202 89 606 202 90 606 minecraft:black_concrete
fill 202 89 608 202 90 608 minecraft:black_concrete
fill 202 89 610 202 90 610 minecraft:black_concrete
fill 202 89 612 202 90 612 minecraft:black_concrete
fill 203 89 604 203 93 604 minecraft:sea_lantern
fill 203 89 605 203 90 605 minecraft:black_concrete
fill 203 89 607 203 90 607 minecraft:black_concrete
fill 203 89 609 203 90 609 minecraft:black_concrete
fill 203 89 611 203 90 611 minecraft:black_concrete
fill 203 89 613 203 90 613 minecraft:black_concrete
fill 204 89 606 204 90 606 minecraft:black_concrete
fill 204 89 608 204 90 608 minecraft:black_concrete
fill 204 89 610 204 90 610 minecraft:black_concrete
fill 204 89 612 204 90 612 minecraft:black_concrete
fill 205 89 605 205 90 605 minecraft:black_concrete
fill 205 89 607 205 90 607 minecraft:black_concrete
fill 205 89 609 205 90 609 minecraft:black_concrete
fill 205 89 611 205 90 611 minecraft:black_concrete
fill 205 89 613 205 90 613 minecraft:black_concrete
fill 206 89 606 206 90 606 minecraft:black_concrete
fill 206 89 608 206 90 608 minecraft:black_concrete
fill 206 89 610 206 90 610 minecraft:black_concrete
fill 206 89 612 206 90 612 minecraft:black_concrete
fill 207 89 605 207 90 605 minecraft:black_concrete
fill 207 89 607 207 90 607 minecraft:black_concrete
fill 207 89 609 207 90 609 minecraft:black_concrete
fill 207 89 611 207 90 611 minecraft:black_concrete
fill 207 89 613 207 90 613 minecraft:black_concrete
fill 208 89 606 208 90 606 minecraft:black_concrete
fill 208 89 608 208 90 608 minecraft:black_concrete
fill 208 89 610 208 90 610 minecraft:black_concrete
fill 208 89 612 208 90 612 minecraft:black_concrete
fill 209 89 605 209 90 605 minecraft:black_concrete
fill 209 89 607 209 90 607 minecraft:black_concrete
fill 209 89 609 209 90 609 minecraft:black_concrete
fill 209 89 611 209 90 611 minecraft:black_concrete
fill 209 89 613 209 90 613 minecraft:black_concrete
fill 210 89 606 210 90 606 minecraft:black_concrete
fill 210 89 608 210 90 608 minecraft:black_concrete
fill 210 89 610 210 90 610 minecraft:black_concrete
fill 210 89 612 210 90 612 minecraft:black_concrete
fill 223 89 629 223 90 629 minecraft:black_concrete
fill 223 89 631 223 90 631 minecraft:black_concrete
fill 223 89 633 223 90 633 minecraft:black_concrete
fill 224 89 628 224 90 628 minecraft:black_concrete
fill 224 89 630 224 90 630 minecraft:black_concrete
fill 224 89 632 224 90 632 minecraft:black_concrete
fill 224 89 634 224 90 634 minecraft:black_concrete
fill 225 89 629 225 90 629 minecraft:black_concrete
fill 225 89 631 225 90 631 minecraft:black_concrete
fill 225 89 633 225 90 633 minecraft:black_concrete
fill 226 89 628 226 90 628 minecraft:black_concrete
fill 226 89 630 226 90 630 minecraft:black_concrete
fill 226 89 632 226 90 632 minecraft:black_concrete
fill 226 89 634 226 90 634 minecraft:black_concrete
fill 227 89 629 227 90 629 minecraft:black_concrete
fill 227 89 631 227 90 631 minecraft:black_concrete
fill 227 89 633 227 90 633 minecraft:black_concrete
fill 228 89 628 228 90 628 minecraft:black_concrete
fill 228 89 630 228 90 630 minecraft:black_concrete
fill 228 89 632 228 90 632 minecraft:black_concrete
fill 228 89 634 228 90 634 minecraft:black_concrete
fill 229 89 629 229 90 629 minecraft:black_concrete
fill 229 89 631 229 90 631 minecraft:black_concrete
fill 229 89 633 229 90 633 minecraft:black_concrete
fill 230 89 633 230 93 633 minecraft:sea_lantern
fill 197 90 629 198 90 629 minecraft:white_stained_glass
fill 205 90 617 205 91 617 minecraft:yellow_concrete
setblock 189 91 625 minecraft:sea_lantern
setblock 189 91 627 minecraft:sea_lantern
setblock 189 91 629 minecraft:sea_lantern
setblock 189 91 631 minecraft:sea_lantern
setblock 189 91 633 minecraft:sea_lantern
setblock 189 91 635 minecraft:sea_lantern
setblock 189 91 637 minecraft:sea_lantern
setblock 190 91 626 minecraft:sea_lantern
setblock 190 91 628 minecraft:sea_lantern
setblock 190 91 630 minecraft:sea_lantern
setblock 190 91 632 minecraft:sea_lantern
setblock 190 91 634 minecraft:sea_lantern
setblock 190 91 636 minecraft:sea_lantern
setblock 191 91 625 minecraft:sea_lantern
setblock 191 91 627 minecraft:sea_lantern
setblock 191 91 629 minecraft:sea_lantern
setblock 191 91 631 minecraft:sea_lantern
setblock 191 91 633 minecraft:sea_lantern
setblock 191 91 635 minecraft:sea_lantern
setblock 191 91 637 minecraft:sea_lantern
setblock 192 91 626 minecraft:sea_lantern
setblock 192 91 628 minecraft:sea_lantern
setblock 192 91 630 minecraft:sea_lantern
setblock 192 91 632 minecraft:sea_lantern
setblock 192 91 634 minecraft:sea_lantern
setblock 192 91 636 minecraft:sea_lantern
setblock 193 91 625 minecraft:sea_lantern
setblock 193 91 627 minecraft:sea_lantern
setblock 193 91 629 minecraft:sea_lantern
setblock 193 91 631 minecraft:sea_lantern
setblock 193 91 633 minecraft:sea_lantern
setblock 193 91 635 minecraft:sea_lantern
setblock 193 91 637 minecraft:sea_lantern
setblock 194 91 626 minecraft:sea_lantern
setblock 194 91 628 minecraft:sea_lantern
setblock 194 91 630 minecraft:sea_lantern
setblock 194 91 632 minecraft:sea_lantern
setblock 194 91 634 minecraft:sea_lantern
setblock 194 91 636 minecraft:sea_lantern
setblock 195 91 625 minecraft:sea_lantern
setblock 195 91 627 minecraft:sea_lantern
setblock 195 91 629 minecraft:sea_lantern
setblock 195 91 631 minecraft:sea_lantern
setblock 195 91 633 minecraft:sea_lantern
setblock 195 91 635 minecraft:sea_lantern
setblock 195 91 637 minecraft:sea_lantern
setblock 196 91 626 minecraft:sea_lantern
setblock 196 91 628 minecraft:sea_lantern
setblock 196 91 630 minecraft:sea_lantern
setblock 196 91 632 minecraft:sea_lantern
setblock 196 91 634 minecraft:sea_lantern
setblock 196 91 636 minecraft:sea_lantern
setblock 197 91 625 minecraft:sea_lantern
setblock 197 91 627 minecraft:sea_lantern
setblock 197 91 629 minecraft:sea_lantern
setblock 197 91 631 minecraft:sea_lantern
setblock 197 91 633 minecraft:sea_lantern
setblock 197 91 635 minecraft:sea_lantern
setblock 197 91 637 minecraft:sea_lantern
setblock 198 91 606 minecraft:sea_lantern
setblock 198 91 608 minecraft:sea_lantern
setblock 198 91 610 minecraft:sea_lantern
setblock 198 91 612 minecraft:sea_lantern
setblock 198 91 626 minecraft:sea_lantern
setblock 198 91 628 minecraft:sea_lantern
fill 198 91 629 198 93 629 minecraft:white_stained_glass
setblock 198 91 630 minecraft:sea_lantern
setblock 198 91 632 minecraft:sea_lantern
setblock 198 91 634 minecraft:sea_lantern
setblock 198 91 636 minecraft:sea_lantern
setblock 199 91 605 minecraft:sea_lantern
setblock 199 91 607 minecraft:sea_lantern
setblock 199 91 609 minecraft:sea_lantern
setblock 199 91 611 minecraft:sea_lantern
setblock 199 91 613 minecraft:sea_lantern
setblock 200 91 606 minecraft:sea_lantern
setblock 200 91 608 minecraft:sea_lantern
setblock 200 91 610 minecraft:sea_lantern
setblock 200 91 612 minecraft:sea_lantern
setblock 201 91 605 minecraft:sea_lantern
setblock 201 91 607 minecraft:sea_lantern
setblock 201 91 609 minecraft:sea_lantern
setblock 201 91 611 minecraft:sea_lantern
setblock 201 91 613 minecraft:sea_lantern
setblock 202 91 606 minecraft:sea_lantern
setblock 202 91 608 minecraft:sea_lantern
setblock 202 91 610 minecraft:sea_lantern
setblock 202 91 612 minecraft:sea_lantern
setblock 203 91 605 minecraft:sea_lantern
setblock 203 91 607 minecraft:sea_lantern
setblock 203 91 609 minecraft:sea_lantern
setblock 203 91 611 minecraft:sea_lantern
setblock 203 91 613 minecraft:sea_lantern
setblock 204 91 606 minecraft:sea_lantern
setblock 204 91 608 minecraft:sea_lantern
setblock 204 91 610 minecraft:sea_lantern
setblock 204 91 612 minecraft:sea_lantern
setblock 205 91 605 minecraft:sea_lantern
setblock 205 91 607 minecraft:sea_lantern
setblock 205 91 609 minecraft:sea_lantern
setblock 205 91 611 minecraft:sea_lantern
setblock 205 91 613 minecraft:sea_lantern
setblock 206 91 606 minecraft:sea_lantern
setblock 206 91 608 minecraft:sea_lantern
setblock 206 91 610 minecraft:sea_lantern
setblock 206 91 612 minecraft:sea_lantern
setblock 207 91 605 minecraft:sea_lantern
setblock 207 91 607 minecraft:sea_lantern
setblock 207 91 609 minecraft:sea_lantern
setblock 207 91 611 minecraft:sea_lantern
setblock 207 91 613 minecraft:sea_lantern
setblock 208 91 606 minecraft:sea_lantern
setblock 208 91 608 minecraft:sea_lantern
setblock 208 91 610 minecraft:sea_lantern
setblock 208 91 612 minecraft:sea_lantern
setblock 209 91 605 minecraft:sea_lantern
setblock 209 91 607 minecraft:sea_lantern
setblock 209 91 609 minecraft:sea_lantern
setblock 209 91 611 minecraft:sea_lantern
setblock 209 91 613 minecraft:sea_lantern
setblock 210 91 606 minecraft:sea_lantern
setblock 210 91 608 minecraft:sea_lantern
setblock 210 91 610 minecraft:sea_lantern
setblock 210 91 612 minecraft:sea_lantern
setblock 223 91 629 minecraft:sea_lantern
setblock 223 91 631 minecraft:sea_lantern
setblock 223 91 633 minecraft:sea_lantern
setblock 224 91 628 minecraft:sea_lantern
setblock 224 91 630 minecraft:sea_lantern
setblock 224 91 632 minecraft:sea_lantern
setblock 224 91 634 minecraft:sea_lantern
setblock 225 91 629 minecraft:sea_lantern
setblock 225 91 631 minecraft:sea_lantern
setblock 225 91 633 minecraft:sea_lantern
setblock 226 91 628 minecraft:sea_lantern
setblock 226 91 630 minecraft:sea_lantern
setblock 226 91 632 minecraft:sea_lantern
setblock 226 91 634 minecraft:sea_lantern
setblock 227 91 629 minecraft:sea_lantern
setblock 227 91 631 minecraft:sea_lantern
setblock 227 91 633 minecraft:sea_lantern
setblock 228 91 628 minecraft:sea_lantern
setblock 228 91 630 minecraft:sea_lantern
setblock 228 91 632 minecraft:sea_lantern
setblock 228 91 634 minecraft:sea_lantern
setblock 229 91 629 minecraft:sea_lantern
setblock 229 91 631 minecraft:sea_lantern
setblock 229 91 633 minecraft:sea_lantern
fill 189 92 625 189 93 625 minecraft:black_concrete
fill 189 92 627 189 93 627 minecraft:black_concrete
fill 189 92 629 189 93 629 minecraft:black_concrete
fill 189 92 631 189 93 631 minecraft:black_concrete
fill 189 92 633 189 93 633 minecraft:black_concrete
fill 189 92 635 189 93 635 minecraft:black_concrete
fill 189 92 637 189 93 637 minecraft:black_concrete
fill 190 92 626 190 93 626 minecraft:black_concrete
fill 190 92 628 190 93 628 minecraft:black_concrete
fill 190 92 630 190 93 630 minecraft:black_concrete
fill 190 92 632 190 93 632 minecraft:black_concrete
fill 190 92 634 190 93 634 minecraft:black_concrete
fill 190 92 636 190 93 636 minecraft:black_concrete
fill 191 92 625 191 93 625 minecraft:black_concrete
fill 191 92 627 191 93 627 minecraft:black_concrete
fill 191 92 629 191 93 629 minecraft:black_concrete
fill 191 92 631 191 93 631 minecraft:black_concrete
fill 191 92 633 191 93 633 minecraft:black_concrete
fill 191 92 635 191 93 635 minecraft:black_concrete
fill 191 92 637 191 93 637 minecraft:black_concrete
fill 192 92 626 192 93 626 minecraft:black_concrete
fill 192 92 628 192 93 628 minecraft:black_concrete
fill 192 92 630 192 93 630 minecraft:black_concrete
fill 192 92 632 192 93 632 minecraft:black_concrete
fill 192 92 634 192 93 634 minecraft:black_concrete
fill 192 92 636 192 93 636 minecraft:black_concrete
fill 193 92 625 193 93 625 minecraft:black_concrete
fill 193 92 627 193 93 627 minecraft:black_concrete
fill 193 92 629 193 93 629 minecraft:black_concrete
fill 193 92 631 193 93 631 minecraft:black_concrete
fill 193 92 633 193 93 633 minecraft:black_concrete
fill 193 92 635 193 93 635 minecraft:black_concrete
fill 193 92 637 193 93 637 minecraft:black_concrete
fill 194 92 626 194 93 626 minecraft:black_concrete
fill 194 92 628 194 93 628 minecraft:black_concrete
fill 194 92 630 194 93 630 minecraft:black_concrete
fill 194 92 632 194 93 632 minecraft:black_concrete
fill 194 92 634 194 93 634 minecraft:black_concrete
fill 194 92 636 194 93 636 minecraft:black_concrete
fill 195 92 625 195 93 625 minecraft:black_concrete
fill 195 92 627 195 93 627 minecraft:black_concrete
fill 195 92 629 195 93 629 minecraft:black_concrete
fill 195 92 631 195 93 631 minecraft:black_concrete
fill 195 92 633 195 93 633 minecraft:black_concrete
fill 195 92 635 195 93 635 minecraft:black_concrete
fill 195 92 637 195 93 637 minecraft:black_concrete
fill 196 92 626 196 93 626 minecraft:black_concrete
fill 196 92 628 196 93 628 minecraft:black_concrete
fill 196 92 630 196 93 630 minecraft:black_concrete
fill 196 92 632 196 93 632 minecraft:black_concrete
fill 196 92 634 196 93 634 minecraft:black_concrete
fill 196 92 636 196 93 636 minecraft:black_concrete
fill 197 92 625 197 93 625 minecraft:black_concrete
fill 197 92 627 197 93 627 minecraft:black_concrete
fill 197 92 629 197 93 629 minecraft:black_concrete
fill 197 92 631 197 93 631 minecraft:black_concrete
fill 197 92 633 197 93 633 minecraft:black_concrete
fill 197 92 635 197 93 635 minecraft:black_concrete
fill 197 92 637 197 93 637 minecraft:black_concrete
fill 198 92 606 198 93 606 minecraft:black_concrete
fill 198 92 608 198 93 608 minecraft:black_concrete
fill 198 92 610 198 93 610 minecraft:black_concrete
fill 198 92 612 198 93 612 minecraft:black_concrete
fill 198 92 626 198 93 626 minecraft:black_concrete
fill 198 92 628 198 93 628 minecraft:black_concrete
fill 198 92 630 198 93 630 minecraft:black_concrete
fill 198 92 632 198 93 632 minecraft:black_concrete
fill 198 92 634 198 93 634 minecraft:black_concrete
fill 198 92 636 198 93 636 minecraft:black_concrete
fill 199 92 605 199 93 605 minecraft:black_concrete
fill 199 92 607 199 93 607 minecraft:black_concrete
fill 199 92 609 199 93 609 minecraft:black_concrete
fill 199 92 611 199 93 611 minecraft:black_concrete
fill 199 92 613 199 93 613 minecraft:black_concrete
fill 200 92 606 200 93 606 minecraft:black_concrete
fill 200 92 608 200 93 608 minecraft:black_concrete
fill 200 92 610 200 93 610 minecraft:black_concrete
fill 200 92 612 200 93 612 minecraft:black_concrete
fill 201 92 605 201 93 605 minecraft:black_concrete
fill 201 92 607 201 93 607 minecraft:black_concrete
fill 201 92 609 201 93 609 minecraft:black_concrete
fill 201 92 611 201 93 611 minecraft:black_concrete
fill 201 92 613 201 93 613 minecraft:black_concrete
fill 202 92 606 202 93 606 minecraft:black_concrete
fill 202 92 608 202 93 608 minecraft:black_concrete
fill 202 92 610 202 93 610 minecraft:black_concrete
fill 202 92 612 202 93 612 minecraft:black_concrete
fill 203 92 605 203 93 605 minecraft:black_concrete
fill 203 92 607 203 93 607 minecraft:black_concrete
fill 203 92 609 203 93 609 minecraft:black_concrete
fill 203 92 611 203 93 611 minecraft:black_concrete
fill 203 92 613 203 93 613 minecraft:black_concrete
fill 204 92 606 204 93 606 minecraft:black_concrete
fill 204 92 608 204 93 608 minecraft:black_concrete
fill 204 92 610 204 93 610 minecraft:black_concrete
fill 204 92 612 204 93 612 minecraft:black_concrete
fill 205 92 605 205 93 605 minecraft:black_concrete
fill 205 92 607 205 93 607 minecraft:black_concrete
fill 205 92 609 205 93 609 minecraft:black_concrete
fill 205 92 611 205 93 611 minecraft:black_concrete
fill 205 92 613 205 93 613 minecraft:black_concrete
fill 206 92 606 206 93 606 minecraft:black_concrete
fill 206 92 608 206 93 608 minecraft:black_concrete
fill 206 92 610 206 93 610 minecraft:black_concrete
fill 206 92 612 206 93 612 minecraft:black_concrete
fill 207 92 605 207 93 605 minecraft:black_concrete
fill 207 92 607 207 93 607 minecraft:black_concrete
fill 207 92 609 207 93 609 minecraft:black_concrete
fill 207 92 611 207 93 611 minecraft:black_concrete
fill 207 92 613 207 93 613 minecraft:black_concrete
fill 208 92 606 208 93 606 minecraft:black_concrete
fill 208 92 608 208 93 608 minecraft:black_concrete
fill 208 92 610 208 93 610 minecraft:black_concrete
fill 208 92 612 208 93 612 minecraft:black_concrete
fill 209 92 605 209 93 605 minecraft:black_concrete
fill 209 92 607 209 93 607 minecraft:black_concrete
fill 209 92 609 209 93 609 minecraft:black_concrete
fill 209 92 611 209 93 611 minecraft:black_concrete
fill 209 92 613 209 93 613 minecraft:black_concrete
fill 210 92 606 210 93 606 minecraft:black_concrete
fill 210 92 608 210 93 608 minecraft:black_concrete
fill 210 92 610 210 93 610 minecraft:black_concrete
fill 210 92 612 210 93 612 minecraft:black_concrete
fill 223 92 629 223 93 629 minecraft:black_concrete
fill 223 92 631 223 93 631 minecraft:black_concrete
fill 223 92 633 223 93 633 minecraft:black_concrete
fill 224 92 628 224 93 628 minecraft:black_concrete
fill 224 92 630 224 93 630 minecraft:black_concrete
fill 224 92 632 224 93 632 minecraft:black_concrete
fill 224 92 634 224 93 634 minecraft:black_concrete
fill 225 92 629 225 93 629 minecraft:black_concrete
fill 225 92 631 225 93 631 minecraft:black_concrete
fill 225 92 633 225 93 633 minecraft:black_concrete
fill 226 92 628 226 93 628 minecraft:black_concrete
fill 226 92 630 226 93 630 minecraft:black_concrete
fill 226 92 632 226 93 632 minecraft:black_concrete
fill 226 92 634 226 93 634 minecraft:black_concrete
fill 227 92 629 227 93 629 minecraft:black_concrete
fill 227 92 631 227 93 631 minecraft:black_concrete
fill 227 92 633 227 93 633 minecraft:black_concrete
fill 228 92 628 228 93 628 minecraft:black_concrete
fill 228 92 630 228 93 630 minecraft:black_concrete
fill 228 92 632 228 93 632 minecraft:black_concrete
fill 228 92 634 228 93 634 minecraft:black_concrete
fill 229 92 629 229 93 629 minecraft:black_concrete
fill 229 92 631 229 93 631 minecraft:black_concrete
fill 229 92 633 229 93 633 minecraft:black_concrete
fill 191 93 621 192 94 624 minecraft:black_concrete
fill 192 93 618 193 94 620 minecraft:black_concrete
fill 193 93 616 194 94 617 minecraft:black_concrete
fill 194 93 615 195 94 615 minecraft:black_concrete
fill 194 93 618 194 94 618 minecraft:black_concrete
fill 195 93 613 196 94 614 minecraft:black_concrete
fill 195 93 616 195 94 616 minecraft:black_concrete
fill 196 93 612 197 94 612 minecraft:black_concrete
fill 196 93 638 198 94 638 minecraft:black_concrete
fill 197 93 611 197 94 611 minecraft:black_concrete
fill 197 93 613 197 94 613 minecraft:black_concrete
fill 197 93 639 200 94 639 minecraft:black_concrete
fill 199 93 629 199 94 629 minecraft:lime_concrete
fill 199 93 640 202 94 640 minecraft:black_concrete
fill 200 93 641 204 94 641 minecraft:black_concrete
fill 202 93 642 216 94 642 minecraft:black_concrete
fill 205 93 643 213 94 643 minecraft:black_concrete
fill 211 93 607 213 94 608 minecraft:black_concrete
fill 214 93 608 216 94 609 minecraft:black_concrete
fill 214 93 641 218 94 641 minecraft:black_concrete
fill 216 93 610 219 94 610 minecraft:black_concrete
fill 216 93 640 219 94 640 minecraft:black_concrete
fill 217 93 609 218 94 609 minecraft:black_concrete
fill 218 93 611 221 94 611 minecraft:black_concrete
fill 218 93 639 221 94 639 minecraft:black_concrete
fill 220 93 612 222 94 612 minecraft:black_concrete
fill 220 93 638 222 94 638 minecraft:black_concrete
fill 221 93 613 223 94 613 minecraft:black_concrete
fill 221 93 637 223 94 637 minecraft:black_concrete
fill 222 93 614 223 94 614 minecraft:black_concrete
fill 222 93 636 223 94 636 minecraft:black_concrete
fill 223 93 615 224 94 616 minecraft:black_concrete
fill 223 93 635 224 94 635 minecraft:black_concrete
fill 224 93 617 225 94 618 minecraft:black_concrete
fill 225 93 616 225 94 616 minecraft:black_concrete
fill 225 93 619 226 94 620 minecraft:black_concrete
fill 226 93 618 226 94 618 minecraft:black_concrete
fill 226 93 621 227 94 627 minecraft:black_concrete
fill 188 94 609 188 106 609 minecraft:cyan_concrete
fill 188 94 617 188 106 617 minecraft:cyan_concrete
fill 188 94 625 188 106 625 minecraft:cyan_concrete
fill 188 94 633 188 106 633 minecraft:cyan_concrete
fill 188 94 641 188 106 641 minecraft:cyan_concrete
setblock 189 94 625 minecraft:sea_lantern
setblock 189 94 627 minecraft:sea_lantern
setblock 189 94 629 minecraft:sea_lantern
setblock 189 94 631 minecraft:sea_lantern
setblock 189 94 633 minecraft:sea_lantern
setblock 189 94 635 minecraft:sea_lantern
setblock 189 94 637 minecraft:sea_lantern
setblock 190 94 626 minecraft:sea_lantern
setblock 190 94 628 minecraft:sea_lantern
setblock 190 94 630 minecraft:sea_lantern
setblock 190 94 632 minecraft:sea_lantern
setblock 190 94 634 minecraft:sea_lantern
setblock 190 94 636 minecraft:sea_lantern
setblock 191 94 625 minecraft:sea_lantern
setblock 191 94 627 minecraft:sea_lantern
setblock 191 94 629 minecraft:sea_lantern
setblock 191 94 631 minecraft:sea_lantern
setblock 191 94 633 minecraft:sea_lantern
setblock 191 94 635 minecraft:sea_lantern
setblock 191 94 637 minecraft:sea_lantern
fill 191 94 646 191 106 646 minecraft:cyan_concrete
setblock 192 94 626 minecraft:sea_lantern
setblock 192 94 628 minecraft:sea_lantern
setblock 192 94 630 minecraft:sea_lantern
setblock 192 94 632 minecraft:sea_lantern
setblock 192 94 634 minecraft:sea_lantern
setblock 192 94 636 minecraft:sea_lantern
setblock 193 94 625 minecraft:sea_lantern
setblock 193 94 627 minecraft:sea_lantern
setblock 193 94 629 minecraft:sea_lantern
setblock 193 94 631 minecraft:sea_lantern
setblock 193 94 633 minecraft:sea_lantern
setblock 193 94 635 minecraft:sea_lantern
setblock 193 94 637 minecraft:sea_lantern
setblock 194 94 626 minecraft:sea_lantern
setblock 194 94 628 minecraft:sea_lantern
setblock 194 94 630 minecraft:sea_lantern
setblock 194 94 632 minecraft:sea_lantern
setblock 194 94 634 minecraft:sea_lantern
setblock 194 94 636 minecraft:sea_lantern
fill 195 94 604 195 106 604 minecraft:cyan_concrete
setblock 195 94 625 minecraft:sea_lantern
setblock 195 94 627 minecraft:sea_lantern
setblock 195 94 629 minecraft:sea_lantern
setblock 195 94 631 minecraft:sea_lantern
setblock 195 94 633 minecraft:sea_lantern
setblock 195 94 635 minecraft:sea_lantern
setblock 195 94 637 minecraft:sea_lantern
setblock 196 94 626 minecraft:sea_lantern
setblock 196 94 628 minecraft:sea_lantern
setblock 196 94 630 minecraft:sea_lantern
setblock 196 94 632 minecraft:sea_lantern
setblock 196 94 634 minecraft:sea_lantern
setblock 196 94 636 minecraft:sea_lantern
setblock 197 94 625 minecraft:sea_lantern
setblock 197 94 627 minecraft:sea_lantern
setblock 197 94 629 minecraft:sea_lantern
setblock 197 94 631 minecraft:sea_lantern
setblock 197 94 633 minecraft:sea_lantern
setblock 197 94 635 minecraft:sea_lantern
setblock 197 94 637 minecraft:sea_lantern
setblock 198 94 606 minecraft:sea_lantern
setblock 198 94 608 minecraft:sea_lantern
setblock 198 94 610 minecraft:sea_lantern
setblock 198 94 612 minecraft:sea_lantern
setblock 198 94 626 minecraft:sea_lantern
setblock 198 94 628 minecraft:sea_lantern
fill 198 94 629 198 96 629 minecraft:black_concrete
setblock 198 94 630 minecraft:sea_lantern
setblock 198 94 632 minecraft:sea_lantern
setblock 198 94 634 minecraft:sea_lantern
setblock 198 94 636 minecraft:sea_lantern
setblock 199 94 605 minecraft:sea_lantern
setblock 199 94 607 minecraft:sea_lantern
setblock 199 94 609 minecraft:sea_lantern
setblock 199 94 611 minecraft:sea_lantern
setblock 199 94 613 minecraft:sea_lantern
fill 199 94 646 199 106 646 minecraft:cyan_concrete
setblock 200 94 606 minecraft:sea_lantern
setblock 200 94 608 minecraft:sea_lantern
setblock 200 94 610 minecraft:sea_lantern
setblock 200 94 612 minecraft:sea_lantern
setblock 201 94 605 minecraft:sea_lantern
setblock 201 94 607 minecraft:sea_lantern
setblock 201 94 609 minecraft:sea_lantern
setblock 201 94 611 minecraft:sea_lantern
setblock 201 94 613 minecraft:sea_lantern
setblock 202 94 606 minecraft:sea_lantern
setblock 202 94 608 minecraft:sea_lantern
setblock 202 94 610 minecraft:sea_lantern
setblock 202 94 612 minecraft:sea_lantern
fill 203 94 604 203 106 604 minecraft:cyan_concrete
setblock 203 94 605 minecraft:sea_lantern
setblock 203 94 607 minecraft:sea_lantern
setblock 203 94 609 minecraft:sea_lantern
setblock 203 94 611 minecraft:sea_lantern
setblock 203 94 613 minecraft:sea_lantern
setblock 204 94 606 minecraft:sea_lantern
setblock 204 94 608 minecraft:sea_lantern
setblock 204 94 610 minecraft:sea_lantern
setblock 204 94 612 minecraft:sea_lantern
setblock 205 94 605 minecraft:sea_lantern
setblock 205 94 607 minecraft:sea_lantern
setblock 205 94 609 minecraft:sea_lantern
setblock 205 94 611 minecraft:sea_lantern
setblock 205 94 613 minecraft:sea_lantern
setblock 206 94 606 minecraft:sea_lantern
setblock 206 94 608 minecraft:sea_lantern
setblock 206 94 610 minecraft:sea_lantern
setblock 206 94 612 minecraft:sea_lantern
setblock 207 94 605 minecraft:sea_lantern
setblock 207 94 607 minecraft:sea_lantern
setblock 207 94 609 minecraft:sea_lantern
setblock 207 94 611 minecraft:sea_lantern
setblock 207 94 613 minecraft:sea_lantern
fill 207 94 646 207 106 646 minecraft:cyan_concrete
setblock 208 94 606 minecraft:sea_lantern
setblock 208 94 608 minecraft:sea_lantern
setblock 208 94 610 minecraft:sea_lantern
setblock 208 94 612 minecraft:sea_lantern
setblock 209 94 605 minecraft:sea_lantern
setblock 209 94 607 minecraft:sea_lantern
setblock 209 94 609 minecraft:sea_lantern
setblock 209 94 611 minecraft:sea_lantern
setblock 209 94 613 minecraft:sea_lantern
setblock 210 94 606 minecraft:sea_lantern
setblock 210 94 608 minecraft:sea_lantern
setblock 210 94 610 minecraft:sea_lantern
setblock 210 94 612 minecraft:sea_lantern
fill 211 94 604 211 106 604 minecraft:cyan_concrete
fill 213 94 613 213 95 613 minecraft:yellow_concrete
fill 215 94 646 215 106 646 minecraft:cyan_concrete
fill 219 94 604 219 106 604 minecraft:cyan_concrete
setblock 223 94 629 minecraft:sea_lantern
setblock 223 94 631 minecraft:sea_lantern
setblock 223 94 633 minecraft:sea_lantern
fill 223 94 646 223 106 646 minecraft:cyan_concrete
setblock 224 94 628 minecraft:sea_lantern
setblock 224 94 630 minecraft:sea_lantern
setblock 224 94 632 minecraft:sea_lantern
setblock 224 94 634 minecraft:sea_lantern
setblock 225 94 629 minecraft:sea_lantern
setblock 225 94 631 minecraft:sea_lantern
setblock 225 94 633 minecraft:sea_lantern
setblock 226 94 628 minecraft:sea_lantern
setblock 226 94 630 minecraft:sea_lantern
setblock 226 94 632 minecraft:sea_lantern
setblock 226 94 634 minecraft:sea_lantern
fill 227 94 604 227 106 604 minecraft:cyan_concrete
setblock 227 94 629 minecraft:sea_lantern
setblock 227 94 631 minecraft:sea_lantern
setblock 227 94 633 minecraft:sea_lantern
setblock 228 94 628 minecraft:sea_lantern
setblock 228 94 630 minecraft:sea_lantern
setblock 228 94 632 minecraft:sea_lantern
setblock 228 94 634 minecraft:sea_lantern
setblock 229 94 629 minecraft:sea_lantern
setblock 229 94 631 minecraft:sea_lantern
setblock 229 94 633 minecraft:sea_lantern
fill 230 94 609 230 106 609 minecraft:cyan_concrete
fill 230 94 617 230 106 617 minecraft:cyan_concrete
fill 230 94 625 230 106 625 minecraft:cyan_concrete
fill 230 94 633 230 106 633 minecraft:cyan_concrete
fill 230 94 641 230 106 641 minecraft:cyan_concrete
fill 189 95 625 189 96 625 minecraft:black_concrete
fill 189 95 627 189 96 627 minecraft:black_concrete
fill 189 95 629 189 96 629 minecraft:black_concrete
fill 189 95 631 189 96 631 minecraft:black_concrete
fill 189 95 633 189 96 633 minecraft:black_concrete
fill 189 95 635 189 96 635 minecraft:black_concrete
fill 189 95 637 189 96 637 minecraft:black_concrete
fill 190 95 626 190 96 626 minecraft:black_concrete
fill 190 95 628 190 96 628 minecraft:black_concrete
fill 190 95 630 190 96 630 minecraft:black_concrete
fill 190 95 632 190 96 632 minecraft:black_concrete
fill 190 95 634 190 96 634 minecraft:black_concrete
fill 190 95 636 190 96 636 minecraft:black_concrete
setblock 191 95 607 minecraft:light[level=14]
setblock 191 95 615 minecraft:light[level=14]
fill 191 95 621 191 95 624 minecraft:sea_lantern
fill 191 95 625 191 96 625 minecraft:black_concrete
fill 191 95 627 191 96 627 minecraft:black_concrete
fill 191 95 629 191 96 629 minecraft:black_concrete
fill 191 95 631 191 96 631 minecraft:black_concrete
fill 191 95 633 191 96 633 minecraft:black_concrete
fill 191 95 635 191 96 635 minecraft:black_concrete
fill 191 95 637 191 96 637 minecraft:black_concrete
setblock 191 95 639 minecraft:light[level=14]
fill 192 95 618 192 95 620 minecraft:sea_lantern
fill 192 95 626 192 96 626 minecraft:black_concrete
fill 192 95 628 192 96 628 minecraft:black_concrete
fill 192 95 630 192 96 630 minecraft:black_concrete
fill 192 95 632 192 96 632 minecraft:black_concrete
fill 192 95 634 192 96 634 minecraft:black_concrete
fill 192 95 636 192 96 636 minecraft:black_concrete
fill 193 95 616 193 95 617 minecraft:sea_lantern
fill 193 95 625 193 96 625 minecraft:black_concrete
fill 193 95 627 193 96 627 minecraft:black_concrete
fill 193 95 629 193 96 629 minecraft:black_concrete
fill 193 95 631 193 96 631 minecraft:black_concrete
fill 193 95 633 193 96 633 minecraft:black_concrete
fill 193 95 635 193 96 635 minecraft:black_concrete
fill 193 95 637 193 96 637 minecraft:black_concrete
setblock 194 95 615 minecraft:sea_lantern
fill 194 95 626 194 96 626 minecraft:black_concrete
fill 194 95 628 194 96 628 minecraft:black_concrete
fill 194 95 630 194 96 630 minecraft:black_concrete
fill 194 95 632 194 96 632 minecraft:black_concrete
fill 194 95 634 194 96 634 minecraft:black_concrete
fill 194 95 636 194 96 636 minecraft:black_concrete
fill 195 95 613 195 95 614 minecraft:sea_lantern
fill 195 95 625 195 96 625 minecraft:black_concrete
fill 195 95 627 195 96 627 minecraft:black_concrete
fill 195 95 629 195 96 629 minecraft:black_concrete
fill 195 95 631 195 96 631 minecraft:black_concrete
fill 195 95 633 195 96 633 minecraft:black_concrete
fill 195 95 635 195 96 635 minecraft:black_concrete
fill 195 95 637 195 96 637 minecraft:black_concrete
fill 196 95 612 196 95 613 minecraft:sea_lantern
fill 196 95 626 196 96 626 minecraft:black_concrete
fill 196 95 628 196 96 628 minecraft:black_concrete
fill 196 95 630 196 96 630 minecraft:black_concrete
fill 196 95 632 196 96 632 minecraft:black_concrete
fill 196 95 634 196 96 634 minecraft:black_concrete
fill 196 95 636 196 96 636 minecraft:black_concrete
fill 197 95 611 197 95 612 minecraft:sea_lantern
fill 197 95 625 197 96 625 minecraft:black_concrete
fill 197 95 627 197 96 627 minecraft:black_concrete
fill 197 95 629 197 96 629 minecraft:black_concrete
fill 197 95 631 197 96 631 minecraft:black_concrete
fill 197 95 633 197 96 633 minecraft:black_concrete
fill 197 95 635 197 96 635 minecraft:black_concrete
fill 197 95 637 197 96 637 minecraft:black_concrete
fill 198 95 606 198 96 606 minecraft:black_concrete
fill 198 95 608 198 96 608 minecraft:black_concrete
fill 198 95 610 198 96 610 minecraft:black_concrete
fill 198 95 612 198 96 612 minecraft:black_concrete
fill 198 95 626 198 96 626 minecraft:black_concrete
fill 198 95 628 198 96 628 minecraft:black_concrete
fill 198 95 630 198 96 630 minecraft:black_concrete
fill 198 95 632 198 96 632 minecraft:black_concrete
fill 198 95 634 198 96 634 minecraft:black_concrete
fill 198 95 636 198 96 636 minecraft:black_concrete
fill 199 95 605 199 96 605 minecraft:black_concrete
fill 199 95 607 199 96 607 minecraft:black_concrete
fill 199 95 609 199 96 609 minecraft:black_concrete
fill 199 95 611 199 96 611 minecraft:black_concrete
fill 199 95 613 199 96 613 minecraft:black_concrete
setblock 199 95 615 minecraft:light[level=14]
setblock 199 95 623 minecraft:light[level=14]
setblock 199 95 631 minecraft:light[level=14]
setblock 199 95 639 minecraft:light[level=14]
fill 200 95 606 200 96 606 minecraft:black_concrete
fill 200 95 608 200 96 608 minecraft:black_concrete
fill 200 95 610 200 96 610 minecraft:black_concrete
fill 200 95 612 200 96 612 minecraft:black_concrete
fill 201 95 605 201 96 605 minecraft:black_concrete
fill 201 95 607 201 96 607 minecraft:black_concrete
fill 201 95 609 201 96 609 minecraft:black_concrete
fill 201 95 611 201 96 611 minecraft:black_concrete
fill 201 95 613 201 96 613 minecraft:black_concrete
fill 202 95 606 202 96 606 minecraft:black_concrete
fill 202 95 608 202 96 608 minecraft:black_concrete
fill 202 95 610 202 96 610 minecraft:black_concrete
fill 202 95 612 202 96 612 minecraft:black_concrete
fill 203 95 605 203 96 605 minecraft:black_concrete
fill 203 95 607 203 96 607 minecraft:black_concrete
fill 203 95 609 203 96 609 minecraft:black_concrete
fill 203 95 611 203 96 611 minecraft:black_concrete
fill 203 95 613 203 96 613 minecraft:black_concrete
fill 204 95 606 204 96 606 minecraft:black_concrete
fill 204 95 608 204 96 608 minecraft:black_concrete
fill 204 95 610 204 96 610 minecraft:black_concrete
fill 204 95 612 204 96 612 minecraft:black_concrete
fill 205 95 605 205 96 605 minecraft:black_concrete
fill 205 95 607 205 96 607 minecraft:black_concrete
fill 205 95 609 205 96 609 minecraft:black_concrete
fill 205 95 611 205 96 611 minecraft:black_concrete
fill 205 95 613 205 96 613 minecraft:black_concrete
fill 206 95 606 206 96 606 minecraft:black_concrete
fill 206 95 608 206 96 608 minecraft:black_concrete
fill 206 95 610 206 96 610 minecraft:black_concrete
fill 206 95 612 206 96 612 minecraft:black_concrete
fill 207 95 605 207 96 605 minecraft:black_concrete
fill 207 95 607 207 96 607 minecraft:black_concrete
fill 207 95 609 207 96 609 minecraft:black_concrete
fill 207 95 611 207 96 611 minecraft:black_concrete
fill 207 95 613 207 96 613 minecraft:black_concrete
setblock 207 95 615 minecraft:light[level=14]
setblock 207 95 623 minecraft:light[level=14]
setblock 207 95 631 minecraft:light[level=14]
setblock 207 95 639 minecraft:light[level=14]
fill 208 95 606 208 96 606 minecraft:black_concrete
fill 208 95 608 208 96 608 minecraft:black_concrete
fill 208 95 610 208 96 610 minecraft:black_concrete
fill 208 95 612 208 96 612 minecraft:black_concrete
fill 209 95 605 209 96 605 minecraft:black_concrete
fill 209 95 607 209 96 607 minecraft:black_concrete
fill 209 95 609 209 96 609 minecraft:black_concrete
fill 209 95 611 209 96 611 minecraft:black_concrete
fill 209 95 613 209 96 613 minecraft:black_concrete
fill 210 95 606 210 96 606 minecraft:black_concrete
fill 210 95 608 210 96 608 minecraft:black_concrete
fill 210 95 610 210 96 610 minecraft:black_concrete
fill 210 95 612 210 96 612 minecraft:black_concrete
fill 211 95 607 213 95 607 minecraft:sea_lantern
fill 214 95 608 216 95 608 minecraft:sea_lantern
setblock 215 95 607 minecraft:light[level=14]
setblock 215 95 615 minecraft:light[level=14]
setblock 215 95 623 minecraft:light[level=14]
setblock 215 95 631 minecraft:light[level=14]
setblock 215 95 639 minecraft:light[level=14]
setblock 217 95 609 minecraft:sea_lantern
setblock 223 95 607 minecraft:light[level=14]
setblock 223 95 615 minecraft:light[level=14]
setblock 223 95 623 minecraft:light[level=14]
fill 223 95 629 223 96 629 minecraft:black_concrete
fill 223 95 631 223 96 631 minecraft:black_concrete
fill 223 95 633 223 96 633 minecraft:black_concrete
setblock 223 95 639 minecraft:light[level=14]
fill 224 95 628 224 96 628 minecraft:black_concrete
fill 224 95 630 224 96 630 minecraft:black_concrete
fill 224 95 632 224 96 632 minecraft:black_concrete
fill 224 95 634 224 96 634 minecraft:black_concrete
fill 225 95 629 225 96 629 minecraft:black_concrete
fill 225 95 631 225 96 631 minecraft:black_concrete
fill 225 95 633 225 96 633 minecraft:black_concrete
fill 226 95 628 226 96 628 minecraft:black_concrete
fill 226 95 630 226 96 630 minecraft:black_concrete
fill 226 95 632 226 96 632 minecraft:black_concrete
fill 226 95 634 226 96 634 minecraft:black_concrete
fill 227 95 629 227 96 629 minecraft:black_concrete
fill 227 95 631 227 96 631 minecraft:black_concrete
fill 227 95 633 227 96 633 minecraft:black_concrete
fill 228 95 628 228 96 628 minecraft:black_concrete
fill 228 95 630 228 96 630 minecraft:black_concrete
fill 228 95 632 228 96 632 minecraft:black_concrete
fill 228 95 634 228 96 634 minecraft:black_concrete
fill 229 95 629 229 96 629 minecraft:black_concrete
fill 229 95 631 229 96 631 minecraft:black_concrete
fill 229 95 633 229 96 633 minecraft:black_concrete
fill 207 101 621 209 101 623 minecraft:redstone_block
fill 207 101 627 209 101 629 minecraft:redstone_block
fill 214 101 620 216 101 622 minecraft:redstone_block
fill 215 101 627 217 101 629 minecraft:redstone_block
fill 200 102 621 206 102 621 minecraft:yellow_concrete
fill 200 102 629 206 102 629 minecraft:yellow_concrete
fill 201 102 620 203 103 620 minecraft:yellow_concrete
fill 201 102 622 206 102 622 minecraft:yellow_concrete
fill 201 102 628 206 102 628 minecraft:yellow_concrete
fill 201 102 630 203 103 630 minecraft:yellow_concrete
fill 202 102 623 206 102 623 minecraft:yellow_concrete
fill 202 102 627 206 102 627 minecraft:yellow_concrete
fill 204 102 624 210 102 624 minecraft:yellow_concrete
fill 204 102 626 210 102 626 minecraft:yellow_concrete
fill 205 102 613 205 103 614 minecraft:yellow_concrete
fill 205 102 636 205 103 637 minecraft:yellow_concrete
fill 206 102 614 206 103 618 minecraft:yellow_concrete
fill 206 102 625 210 102 625 minecraft:yellow_concrete
fill 206 102 632 206 103 636 minecraft:yellow_concrete
fill 207 102 615 208 102 620 minecraft:yellow_concrete
fill 207 102 630 208 102 635 minecraft:yellow_concrete
fill 209 102 616 209 102 620 minecraft:yellow_concrete
fill 209 102 630 209 102 634 minecraft:yellow_concrete
fill 210 102 618 210 102 623 minecraft:yellow_concrete
fill 210 102 627 210 102 632 minecraft:yellow_concrete
fill 211 102 619 213 102 623 minecraft:yellow_concrete
fill 211 102 627 214 102 631 minecraft:yellow_concrete
fill 212 102 615 215 102 618 minecraft:yellow_concrete
fill 212 102 632 215 102 635 minecraft:yellow_concrete
fill 213 102 614 215 103 614 minecraft:yellow_concrete
fill 213 102 636 215 103 636 minecraft:yellow_concrete
fill 214 102 612 214 103 613 minecraft:yellow_concrete
fill 214 102 619 221 102 619 minecraft:yellow_concrete
fill 214 102 623 220 102 626 minecraft:yellow_concrete
fill 214 102 637 214 103 638 minecraft:yellow_concrete
fill 215 102 613 215 103 613 minecraft:yellow_concrete
fill 215 102 630 220 102 631 minecraft:yellow_concrete
fill 215 102 637 215 103 637 minecraft:yellow_concrete
fill 217 102 620 218 102 622 minecraft:yellow_concrete
fill 218 102 618 221 103 618 minecraft:yellow_concrete
fill 218 102 627 218 102 629 minecraft:yellow_concrete
fill 218 102 632 221 103 632 minecraft:yellow_concrete
fill 219 102 620 219 103 621 minecraft:yellow_concrete
fill 219 102 627 220 103 627 minecraft:yellow_concrete
fill 219 102 629 219 103 629 minecraft:yellow_concrete
fill 220 102 617 222 103 617 minecraft:yellow_concrete
fill 220 102 620 220 103 620 minecraft:yellow_concrete
fill 220 102 633 222 103 633 minecraft:yellow_concrete
fill 221 102 624 224 102 626 minecraft:yellow_concrete
fill 221 102 631 221 103 631 minecraft:yellow_concrete
fill 225 102 625 226 103 625 minecraft:yellow_concrete
fill 189 103 605 199 103 645 minecraft:black_concrete
fill 200 103 605 200 103 620 minecraft:black_concrete
fill 200 103 621 205 103 621 minecraft:yellow_concrete
fill 200 103 622 200 103 628 minecraft:black_concrete
fill 200 103 629 205 103 629 minecraft:yellow_concrete
fill 200 103 630 200 103 645 minecraft:black_concrete
fill 201 103 605 204 103 619 minecraft:black_concrete
fill 201 103 622 203 103 622 minecraft:yellow_concrete
fill 201 103 623 201 103 627 minecraft:black_concrete
fill 201 103 628 203 103 628 minecraft:yellow_concrete
fill 201 103 631 204 103 645 minecraft:black_concrete
fill 202 103 623 204 103 623 minecraft:yellow_concrete
fill 202 103 624 203 103 626 minecraft:black_concrete
fill 202 103 627 204 103 627 minecraft:yellow_concrete
fill 204 103 620 205 103 620 minecraft:black_concrete
fill 204 103 622 205 103 622 minecraft:black_concrete
fill 204 103 624 205 103 624 minecraft:yellow_concrete
fill 204 103 625 205 103 625 minecraft:black_concrete
fill 204 103 626 205 103 626 minecraft:yellow_concrete
fill 204 103 628 205 103 628 minecraft:black_concrete
fill 204 103 630 205 103 630 minecraft:black_concrete
fill 205 103 605 213 103 612 minecraft:black_concrete
fill 205 103 615 205 103 619 minecraft:black_concrete
setblock 205 103 623 minecraft:black_concrete
setblock 205 103 627 minecraft:black_concrete
fill 205 103 631 205 103 635 minecraft:black_concrete
fill 205 103 638 213 103 645 minecraft:black_concrete
fill 206 103 613 213 103 613 minecraft:black_concrete
setblock 206 103 619 minecraft:black_concrete
fill 206 103 620 206 103 624 minecraft:sea_lantern
fill 206 103 625 207 103 625 minecraft:yellow_concrete
fill 206 103 626 206 103 630 minecraft:sea_lantern
setblock 206 103 631 minecraft:black_concrete
fill 206 103 637 213 103 637 minecraft:black_concrete
fill 207 103 614 212 103 614 minecraft:black_concrete
fill 207 103 615 207 103 619 minecraft:yellow_concrete
fill 207 103 620 210 103 620 minecraft:sea_lantern
fill 207 103 621 209 103 623 minecraft:black_concrete
fill 207 103 624 210 103 624 minecraft:sea_lantern
fill 207 103 626 210 103 626 minecraft:sea_lantern
fill 207 103 627 209 103 629 minecraft:black_concrete
fill 207 103 630 210 103 630 minecraft:sea_lantern
fill 207 103 631 207 103 635 minecraft:yellow_concrete
fill 207 103 636 212 103 636 minecraft:black_concrete
fill 208 103 615 208 103 617 minecraft:yellow_concrete
fill 208 103 618 209 103 619 minecraft:black_concrete
fill 208 103 625 209 103 625 minecraft:white_concrete
fill 208 103 631 209 103 632 minecraft:black_concrete
fill 208 103 633 208 103 635 minecraft:yellow_concrete
fill 209 103 615 211 103 615 minecraft:black_concrete
fill 209 103 616 209 103 617 minecraft:yellow_concrete
fill 209 103 633 209 103 634 minecraft:yellow_concrete
fill 209 103 635 211 103 635 minecraft:black_concrete
fill 210 103 616 211 103 617 minecraft:black_concrete
setblock 210 103 618 minecraft:yellow_concrete
setblock 210 103 619 minecraft:black_concrete
fill 210 103 621 210 103 623 minecraft:sea_lantern
setblock 210 103 625 minecraft:sea_lantern
fill 210 103 627 210 103 629 minecraft:sea_lantern
setblock 210 103 631 minecraft:black_concrete
setblock 210 103 632 minecraft:yellow_concrete
fill 210 103 633 211 103 634 minecraft:black_concrete
fill 211 103 618 214 103 618 minecraft:black_concrete
fill 211 103 619 211 103 620 minecraft:yellow_concrete
setblock 211 103 621 minecraft:black_concrete
fill 211 103 622 212 103 622 minecraft:white_concrete
fill 211 103 623 217 103 623 minecraft:sea_lantern
fill 211 103 627 214 103 627 minecraft:sea_lantern
fill 211 103 628 213 103 628 minecraft:white_concrete
setblock 211 103 629 minecraft:black_concrete
fill 211 103 630 211 103 631 minecraft:yellow_concrete
fill 211 103 632 214 103 632 minecraft:black_concrete
fill 212 103 615 212 103 617 minecraft:yellow_concrete
fill 212 103 619 212 103 620 minecraft:black_concrete
setblock 212 103 621 minecraft:white_concrete
setblock 212 103 629 minecraft:white_concrete
fill 212 103 630 213 103 631 minecraft:black_concrete
fill 212 103 633 212 103 635 minecraft:yellow_concrete
fill 213 103 615 215 103 616 minecraft:yellow_concrete
fill 213 103 617 214 103 617 minecraft:black_concrete
fill 213 103 619 213 103 622 minecraft:sea_lantern
setblock 213 103 629 minecraft:black_concrete
fill 213 103 633 214 103 633 minecraft:black_concrete
fill 213 103 634 215 103 635 minecraft:yellow_concrete
fill 214 103 605 229 103 611 minecraft:black_concrete
fill 214 103 619 217 103 619 minecraft:sea_lantern
fill 214 103 620 216 103 622 minecraft:black_concrete
fill 214 103 624 214 103 626 minecraft:sea_lantern
fill 214 103 628 214 103 630 minecraft:sea_lantern
setblock 214 103 631 minecraft:black_concrete
fill 214 103 639 229 103 645 minecraft:black_concrete
fill 215 103 612 229 103 612 minecraft:black_concrete
fill 215 103 617 215 103 618 minecraft:yellow_concrete
fill 215 103 624 215 103 625 minecraft:white_concrete
fill 215 103 626 218 103 626 minecraft:sea_lantern
fill 215 103 627 217 103 629 minecraft:black_concrete
fill 215 103 630 218 103 630 minecraft:sea_lantern
fill 215 103 631 215 103 633 minecraft:yellow_concrete
fill 215 103 638 229 103 638 minecraft:black_concrete
fill 216 103 613 217 103 618 minecraft:black_concrete
fill 216 103 624 219 103 624 minecraft:black_concrete
setblock 216 103 625 minecraft:white_concrete
fill 216 103 631 218 103 631 minecraft:yellow_concrete
fill 216 103 632 217 103 637 minecraft:black_concrete
fill 217 103 620 217 103 622 minecraft:sea_lantern
fill 217 103 625 221 103 625 minecraft:black_concrete
fill 218 103 613 219 103 617 minecraft:black_concrete
setblock 218 103 619 minecraft:yellow_concrete
fill 218 103 620 218 103 621 minecraft:black_concrete
fill 218 103 622 218 103 623 minecraft:yellow_concrete
fill 218 103 627 218 103 629 minecraft:sea_lantern
fill 218 103 633 219 103 637 minecraft:black_concrete
setblock 219 103 619 minecraft:black_concrete
fill 219 103 622 229 103 622 minecraft:black_concrete
fill 219 103 623 220 103 623 minecraft:yellow_concrete
setblock 219 103 626 minecraft:black_concrete
fill 219 103 628 229 103 628 minecraft:black_concrete
fill 219 103 630 220 103 630 minecraft:yellow_concrete
setblock 219 103 631 minecraft:black_concrete
fill 220 103 613 229 103 616 minecraft:black_concrete
fill 220 103 619 221 103 619 minecraft:yellow_concrete
fill 220 103 621 229 103 621 minecraft:black_concrete
fill 220 103 624 224 103 624 minecraft:yellow_concrete
fill 220 103 626 224 103 626 minecraft:yellow_concrete
fill 220 103 629 229 103 629 minecraft:black_concrete
setblock 220 103 631 minecraft:yellow_concrete
fill 220 103 634 229 103 637 minecraft:black_concrete
fill 221 103 620 229 103 620 minecraft:black_concrete
fill 221 103 623 229 103 623 minecraft:black_concrete
fill 221 103 627 229 103 627 minecraft:black_concrete
fill 221 103 630 229 103 630 minecraft:black_concrete
fill 222 103 618 229 103 619 minecraft:black_concrete
fill 222 103 625 224 103 625 minecraft:yellow_concrete
fill 222 103 631 229 103 632 minecraft:black_concrete
fill 223 103 617 229 103 617 minecraft:black_concrete
fill 223 103 633 229 103 633 minecraft:black_concrete
fill 225 103 624 229 103 624 minecraft:black_concrete
fill 225 103 626 229 103 626 minecraft:black_concrete
fill 227 103 625 229 103 625 minecraft:black_concrete
setblock 188 107 609 minecraft:sea_lantern
setblock 188 107 617 minecraft:sea_lantern
setblock 188 107 625 minecraft:sea_lantern
setblock 188 107 633 minecraft:sea_lantern
setblock 188 107 641 minecraft:sea_lantern
fill 189 107 611 189 165 612 minecraft:black_concrete
fill 189 107 619 189 165 620 minecraft:black_concrete
fill 189 107 627 189 165 628 minecraft:black_concrete
fill 189 107 635 189 165 636 minecraft:black_concrete
fill 189 107 643 189 150 644 minecraft:black_concrete
fill 190 107 605 191 165 605 minecraft:black_concrete
setblock 191 107 646 minecraft:sea_lantern
setblock 195 107 604 minecraft:sea_lantern
fill 195 107 645 196 150 645 minecraft:black_concrete
fill 198 107 605 199 165 605 minecraft:black_concrete
setblock 199 107 646 minecraft:sea_lantern
setblock 203 107 604 minecraft:sea_lantern
fill 203 107 637 208 111 638 minecraft:black_concrete
fill 203 107 645 204 165 645 minecraft:black_concrete
fill 204 107 636 207 111 636 minecraft:black_concrete
fill 204 107 639 206 111 640 minecraft:black_concrete
fill 206 107 605 207 165 605 minecraft:black_concrete
fill 207 107 639 207 111 639 minecraft:black_concrete
setblock 207 107 646 minecraft:sea_lantern
setblock 211 107 604 minecraft:sea_lantern
fill 211 107 645 212 165 645 minecraft:black_concrete
fill 212 107 633 213 108 634 minecraft:yellow_concrete
fill 214 107 605 215 165 605 minecraft:black_concrete
setblock 215 107 646 minecraft:sea_lantern
setblock 219 107 604 minecraft:sea_lantern
setblock 219 107 623 minecraft:lime_concrete
fill 219 107 645 220 165 645 minecraft:black_concrete
fill 222 107 605 223 165 605 minecraft:black_concrete
setblock 223 107 646 minecraft:sea_lantern
setblock 227 107 604 minecraft:sea_lantern
fill 227 107 645 228 165 645 minecraft:black_concrete
fill 229 107 606 229 165 607 minecraft:black_concrete
fill 229 107 614 229 165 615 minecraft:black_concrete
fill 229 107 622 229 165 623 minecraft:black_concrete
fill 229 107 630 229 165 631 minecraft:black_concrete
fill 229 107 638 229 165 639 minecraft:black_concrete
setblock 230 107 609 minecraft:sea_lantern
setblock 230 107 617 minecraft:sea_lantern
setblock 230 107 625 minecraft:sea_lantern
setblock 230 107 633 minecraft:sea_lantern
setblock 230 107 641 minecraft:sea_lantern
fill 188 108 609 188 115 609 minecraft:cyan_concrete
fill 188 108 617 188 115 617 minecraft:cyan_concrete
fill 188 108 625 188 115 625 minecraft:cyan_concrete
fill 188 108 633 188 115 633 minecraft:cyan_concrete
fill 188 108 641 188 115 641 minecraft:cyan_concrete
fill 191 108 646 191 115 646 minecraft:cyan_concrete
fill 195 108 604 195 115 604 minecraft:cyan_concrete
fill 199 108 646 199 115 646 minecraft:cyan_concrete
fill 203 108 604 203 115 604 minecraft:cyan_concrete
fill 203 108 636 203 111 636 minecraft:black_concrete
fill 203 108 639 203 111 639 minecraft:black_concrete
fill 204 108 635 207 111 635 minecraft:black_concrete
fill 207 108 640 207 111 640 minecraft:black_concrete
fill 207 108 646 207 115 646 minecraft:cyan_concrete
fill 208 108 636 208 111 636 minecraft:black_concrete
fill 208 108 639 208 111 639 minecraft:black_concrete
fill 211 108 604 211 115 604 minecraft:cyan_concrete
fill 215 108 646 215 115 646 minecraft:cyan_concrete
fill 219 108 604 219 115 604 minecraft:cyan_concrete
fill 223 108 646 223 115 646 minecraft:cyan_concrete
fill 227 108 604 227 115 604 minecraft:cyan_concrete
fill 230 108 609 230 115 609 minecraft:cyan_concrete
fill 230 108 617 230 115 617 minecraft:cyan_concrete
fill 230 108 625 230 115 625 minecraft:cyan_concrete
fill 230 108 633 230 115 633 minecraft:cyan_concrete
fill 230 108 641 230 115 641 minecraft:cyan_concrete
fill 202 109 637 202 111 638 minecraft:black_concrete
fill 203 109 635 203 111 635 minecraft:black_concrete
fill 203 109 640 203 111 640 minecraft:black_concrete
fill 204 109 641 207 111 641 minecraft:black_concrete
fill 208 109 635 208 111 635 minecraft:black_concrete
fill 208 109 640 208 111 640 minecraft:black_concrete
fill 209 109 637 209 111 638 minecraft:black_concrete
fill 202 110 636 202 111 636 minecraft:black_concrete
fill 202 110 639 202 111 640 minecraft:black_concrete
fill 203 110 641 203 111 641 minecraft:black_concrete
fill 204 110 634 207 111 634 minecraft:black_concrete
fill 208 110 641 208 111 641 minecraft:black_concrete
fill 209 110 636 209 111 636 minecraft:black_concrete
fill 209 110 639 209 111 640 minecraft:black_concrete
fill 212 110 636 212 111 636 minecraft:lime_concrete
setblock 191 111 607 minecraft:light[level=14]
setblock 191 111 615 minecraft:light[level=14]
setblock 191 111 623 minecraft:light[level=14]
setblock 191 111 631 minecraft:light[level=14]
setblock 191 111 639 minecraft:light[level=14]
setblock 199 111 607 minecraft:light[level=14]
setblock 199 111 615 minecraft:light[level=14]
setblock 199 111 623 minecraft:light[level=14]
setblock 199 111 631 minecraft:light[level=14]
setblock 199 111 639 minecraft:light[level=14]
fill 201 111 637 201 111 638 minecraft:black_concrete
setblock 202 111 635 minecraft:black_concrete
setblock 203 111 634 minecraft:black_concrete
fill 204 111 642 207 111 642 minecraft:black_concrete
setblock 207 111 607 minecraft:light[level=14]
setblock 207 111 615 minecraft:light[level=14]
setblock 207 111 623 minecraft:light[level=14]
setblock 207 111 631 minecraft:light[level=14]
setblock 208 111 634 minecraft:black_concrete
setblock 209 111 635 minecraft:black_concrete
fill 210 111 637 210 111 638 minecraft:black_concrete
setblock 215 111 607 minecraft:light[level=14]
setblock 215 111 615 minecraft:light[level=14]
setblock 215 111 623 minecraft:light[level=14]
setblock 215 111 631 minecraft:light[level=14]
setblock 215 111 639 minecraft:light[level=14]
setblock 223 111 607 minecraft:light[level=14]
setblock 223 111 615 minecraft:light[level=14]
setblock 223 111 623 minecraft:light[level=14]
setblock 223 111 631 minecraft:light[level=14]
setblock 223 111 639 minecraft:light[level=14]
fill 189 112 605 189 113 610 minecraft:black_concrete
fill 189 112 613 190 112 618 minecraft:black_concrete
fill 189 112 621 190 112 626 minecraft:black_concrete
fill 189 112 629 190 112 634 minecraft:black_concrete
fill 189 112 637 190 112 642 minecraft:black_concrete
fill 189 112 645 194 113 645 minecraft:black_concrete
fill 190 112 606 190 112 612 minecraft:black_concrete
fill 190 112 619 190 112 620 minecraft:black_concrete
fill 190 112 627 190 112 628 minecraft:black_concrete
fill 190 112 635 190 112 636 minecraft:black_concrete
fill 190 112 643 190 112 644 minecraft:black_concrete
fill 191 112 606 228 112 606 minecraft:black_concrete
fill 191 112 644 229 112 644 minecraft:black_concrete
fill 192 112 605 197 113 605 minecraft:black_concrete
fill 197 112 645 202 113 645 minecraft:black_concrete
fill 200 112 605 205 113 605 minecraft:black_concrete
fill 205 112 637 206 113 638 minecraft:white_stained_glass
fill 205 112 645 210 113 645 minecraft:black_concrete
fill 208 112 605 213 113 605 minecraft:black_concrete
fill 213 112 645 218 113 645 minecraft:black_concrete
fill 214 112 614 215 113 614 minecraft:lime_concrete
fill 216 112 605 221 113 605 minecraft:black_concrete
fill 221 112 645 226 113 645 minecraft:black_concrete
fill 224 112 605 229 113 605 minecraft:black_concrete
fill 228 112 607 228 112 643 minecraft:black_concrete
fill 229 112 608 229 113 613 minecraft:black_concrete
fill 229 112 616 229 113 621 minecraft:black_concrete
fill 229 112 624 229 113 629 minecraft:black_concrete
fill 229 112 632 229 113 637 minecraft:black_concrete
fill 229 112 640 229 113 643 minecraft:black_concrete
fill 229 112 645 229 113 645 minecraft:black_concrete
fill 189 113 613 189 113 618 minecraft:black_concrete
fill 189 113 621 189 113 626 minecraft:black_concrete
fill 189 113 629 189 113 634 minecraft:black_concrete
fill 189 113 637 189 113 642 minecraft:black_concrete
setblock 229 113 644 minecraft:black_concrete
fill 205 114 638 206 114 638 minecraft:white_stained_glass
fill 188 116 609 188 121 609 minecraft:sea_lantern
fill 188 116 617 188 121 617 minecraft:sea_lantern
fill 188 116 625 188 121 625 minecraft:sea_lantern
fill 188 116 633 188 121 633 minecraft:sea_lantern
fill 188 116 641 188 121 641 minecraft:sea_lantern
fill 191 116 646 191 121 646 minecraft:sea_lantern
fill 195 116 604 195 121 604 minecraft:sea_lantern
fill 199 116 646 199 121 646 minecraft:sea_lantern
fill 203 116 604 203 121 604 minecraft:sea_lantern
fill 207 116 646 207 121 646 minecraft:sea_lantern
fill 211 116 604 211 121 604 minecraft:sea_lantern
fill 215 116 646 215 121 646 minecraft:sea_lantern
fill 219 116 604 219 121 604 minecraft:sea_lantern
fill 223 116 646 223 121 646 minecraft:sea_lantern
fill 227 116 604 227 121 604 minecraft:sea_lantern
fill 230 116 609 230 121 609 minecraft:sea_lantern
fill 230 116 617 230 121 617 minecraft:sea_lantern
fill 230 116 625 230 121 625 minecraft:sea_lantern
fill 230 116 633 230 121 633 minecraft:sea_lantern
fill 230 116 641 230 121 641 minecraft:sea_lantern
setblock 191 119 607 minecraft:light[level=14]
setblock 191 119 615 minecraft:light[level=14]
setblock 191 119 623 minecraft:light[level=14]
setblock 191 119 631 minecraft:light[level=14]
setblock 191 119 639 minecraft:light[level=14]
setblock 199 119 607 minecraft:light[level=14]
setblock 199 119 615 minecraft:light[level=14]
setblock 199 119 623 minecraft:light[level=14]
setblock 199 119 631 minecraft:light[level=14]
setblock 199 119 639 minecraft:light[level=14]
setblock 207 119 607 minecraft:light[level=14]
setblock 207 119 615 minecraft:light[level=14]
setblock 207 119 623 minecraft:light[level=14]
setblock 207 119 631 minecraft:light[level=14]
setblock 207 119 639 minecraft:light[level=14]
setblock 215 119 607 minecraft:light[level=14]
setblock 215 119 615 minecraft:light[level=14]
setblock 215 119 623 minecraft:light[level=14]
setblock 215 119 631 minecraft:light[level=14]
setblock 215 119 639 minecraft:light[level=14]
setblock 223 119 607 minecraft:light[level=14]
setblock 223 119 615 minecraft:light[level=14]
setblock 223 119 623 minecraft:light[level=14]
setblock 223 119 631 minecraft:light[level=14]
setblock 223 119 639 minecraft:light[level=14]
fill 188 122 609 188 129 609 minecraft:cyan_concrete
fill 188 122 617 188 129 617 minecraft:cyan_concrete
fill 188 122 625 188 129 625 minecraft:cyan_concrete
fill 188 122 633 188 129 633 minecraft:cyan_concrete
fill 188 122 641 188 129 641 minecraft:cyan_concrete
fill 191 122 646 191 129 646 minecraft:cyan_concrete
fill 195 122 604 195 129 604 minecraft:cyan_concrete
fill 199 122 646 199 129 646 minecraft:cyan_concrete
fill 203 122 604 203 129 604 minecraft:cyan_concrete
fill 207 122 646 207 129 646 minecraft:cyan_concrete
fill 211 122 604 211 129 604 minecraft:cyan_concrete
fill 215 122 646 215 129 646 minecraft:cyan_concrete
fill 219 122 604 219 129 604 minecraft:cyan_concrete
fill 223 122 646 223 129 646 minecraft:cyan_concrete
fill 227 122 604 227 129 604 minecraft:cyan_concrete
fill 230 122 609 230 129 609 minecraft:cyan_concrete
fill 230 122 617 230 129 617 minecraft:cyan_concrete
fill 230 122 625 230 129 625 minecraft:cyan_concrete
fill 230 122 633 230 129 633 minecraft:cyan_concrete
fill 230 122 641 230 129 641 minecraft:cyan_concrete
fill 222 124 633 222 125 633 minecraft:cyan_concrete
fill 189 126 605 189 127 610 minecraft:black_concrete
fill 189 126 613 190 126 618 minecraft:black_concrete
fill 189 126 621 190 126 626 minecraft:black_concrete
fill 189 126 629 190 126 634 minecraft:black_concrete
fill 189 126 637 190 126 642 minecraft:black_concrete
fill 189 126 645 194 127 645 minecraft:black_concrete
fill 190 126 606 190 126 612 minecraft:black_concrete
fill 190 126 619 190 126 620 minecraft:black_concrete
fill 190 126 627 190 126 628 minecraft:black_concrete
fill 190 126 635 190 126 636 minecraft:black_concrete
fill 190 126 643 190 126 644 minecraft:black_concrete
fill 191 126 606 228 126 606 minecraft:black_concrete
fill 191 126 644 229 126 644 minecraft:black_concrete
fill 192 126 605 197 127 605 minecraft:black_concrete
fill 197 126 645 202 127 645 minecraft:black_concrete
fill 200 126 605 205 127 605 minecraft:black_concrete
fill 205 126 645 210 127 645 minecraft:black_concrete
fill 208 126 605 213 127 605 minecraft:black_concrete
fill 213 126 645 218 127 645 minecraft:black_concrete
fill 216 126 605 221 127 605 minecraft:black_concrete
fill 221 126 645 226 127 645 minecraft:black_concrete
fill 224 126 605 229 127 605 minecraft:black_concrete
fill 228 126 607 228 126 643 minecraft:black_concrete
fill 229 126 608 229 127 613 minecraft:black_concrete
fill 229 126 616 229 127 621 minecraft:black_concrete
fill 229 126 624 229 127 629 minecraft:black_concrete
fill 229 126 632 229 127 637 minecraft:black_concrete
fill 229 126 640 229 127 643 minecraft:black_concrete
fill 229 126 645 229 127 645 minecraft:black_concrete
fill 189 127 613 189 127 618 minecraft:black_concrete
fill 189 127 621 189 127 626 minecraft:black_concrete
fill 189 127 629 189 127 634 minecraft:black_concrete
fill 189 127 637 189 127 642 minecraft:black_concrete
setblock 191 127 607 minecraft:light[level=14]
setblock 191 127 615 minecraft:light[level=14]
setblock 191 127 623 minecraft:light[level=14]
setblock 191 127 631 minecraft:light[level=14]
setblock 191 127 639 minecraft:light[level=14]
setblock 199 127 607 minecraft:light[level=14]
setblock 199 127 615 minecraft:light[level=14]
setblock 199 127 623 minecraft:light[level=14]
setblock 199 127 631 minecraft:light[level=14]
setblock 199 127 639 minecraft:light[level=14]
setblock 207 127 607 minecraft:light[level=14]
setblock 207 127 615 minecraft:light[level=14]
setblock 207 127 623 minecraft:light[level=14]
setblock 207 127 631 minecraft:light[level=14]
setblock 207 127 639 minecraft:light[level=14]
setblock 215 127 607 minecraft:light[level=14]
setblock 215 127 615 minecraft:light[level=14]
setblock 215 127 623 minecraft:light[level=14]
setblock 215 127 631 minecraft:light[level=14]
setblock 215 127 639 minecraft:light[level=14]
setblock 223 127 607 minecraft:light[level=14]
setblock 223 127 615 minecraft:light[level=14]
setblock 223 127 623 minecraft:light[level=14]
setblock 223 127 631 minecraft:light[level=14]
setblock 223 127 639 minecraft:light[level=14]
setblock 229 127 644 minecraft:black_concrete
fill 188 130 609 188 135 609 minecraft:sea_lantern
fill 188 130 617 188 135 617 minecraft:sea_lantern
fill 188 130 625 188 135 625 minecraft:sea_lantern
fill 188 130 633 188 135 633 minecraft:sea_lantern
fill 188 130 641 188 135 641 minecraft:sea_lantern
fill 191 130 646 191 135 646 minecraft:sea_lantern
fill 195 130 604 195 135 604 minecraft:sea_lantern
fill 199 130 646 199 135 646 minecraft:sea_lantern
fill 203 130 604 203 135 604 minecraft:sea_lantern
fill 207 130 646 207 135 646 minecraft:sea_lantern
fill 211 130 604 211 135 604 minecraft:sea_lantern
fill 215 130 646 215 135 646 minecraft:sea_lantern
fill 219 130 604 219 135 604 minecraft:sea_lantern
fill 223 130 646 223 135 646 minecraft:sea_lantern
fill 227 130 604 227 135 604 minecraft:sea_lantern
fill 230 130 609 230 135 609 minecraft:sea_lantern
fill 230 130 617 230 135 617 minecraft:sea_lantern
fill 230 130 625 230 135 625 minecraft:sea_lantern
fill 230 130 633 230 135 633 minecraft:sea_lantern
fill 230 130 641 230 135 641 minecraft:sea_lantern
fill 211 132 639 213 133 639 minecraft:yellow_concrete
fill 212 132 638 212 133 638 minecraft:yellow_concrete
fill 212 132 640 212 133 640 minecraft:yellow_concrete
setblock 191 135 607 minecraft:light[level=14]
setblock 191 135 615 minecraft:light[level=14]
setblock 191 135 623 minecraft:light[level=14]
setblock 191 135 631 minecraft:light[level=14]
setblock 191 135 639 minecraft:light[level=14]
setblock 199 135 607 minecraft:light[level=14]
setblock 199 135 615 minecraft:light[level=14]
setblock 199 135 623 minecraft:light[level=14]
setblock 199 135 631 minecraft:light[level=14]
setblock 199 135 639 minecraft:light[level=14]
setblock 207 135 607 minecraft:light[level=14]
setblock 207 135 615 minecraft:light[level=14]
setblock 207 135 623 minecraft:light[level=14]
setblock 207 135 631 minecraft:light[level=14]
setblock 207 135 639 minecraft:light[level=14]
setblock 215 135 607 minecraft:light[level=14]
setblock 215 135 615 minecraft:light[level=14]
setblock 215 135 623 minecraft:light[level=14]
setblock 215 135 631 minecraft:light[level=14]
setblock 215 135 639 minecraft:light[level=14]
setblock 223 135 607 minecraft:light[level=14]
setblock 223 135 615 minecraft:light[level=14]
setblock 223 135 623 minecraft:light[level=14]
setblock 223 135 631 minecraft:light[level=14]
setblock 223 135 639 minecraft:light[level=14]
fill 188 136 609 188 143 609 minecraft:cyan_concrete
fill 188 136 617 188 143 617 minecraft:cyan_concrete
fill 188 136 625 188 143 625 minecraft:cyan_concrete
fill 188 136 633 188 143 633 minecraft:cyan_concrete
fill 188 136 641 188 143 641 minecraft:cyan_concrete
fill 191 136 646 191 143 646 minecraft:cyan_concrete
fill 195 136 604 195 143 604 minecraft:cyan_concrete
fill 199 136 646 199 143 646 minecraft:cyan_concrete
fill 203 136 604 203 143 604 minecraft:cyan_concrete
fill 207 136 646 207 143 646 minecraft:cyan_concrete
fill 211 136 604 211 143 604 minecraft:cyan_concrete
fill 215 136 646 215 143 646 minecraft:cyan_concrete
fill 219 136 604 219 143 604 minecraft:cyan_concrete
fill 223 136 646 223 143 646 minecraft:cyan_concrete
fill 227 136 604 227 143 604 minecraft:cyan_concrete
fill 230 136 609 230 143 609 minecraft:cyan_concrete
fill 230 136 617 230 143 617 minecraft:cyan_concrete
fill 230 136 625 230 143 625 minecraft:cyan_concrete
fill 230 136 633 230 143 633 minecraft:cyan_concrete
fill 230 136 641 230 143 641 minecraft:cyan_concrete
fill 189 140 605 189 141 610 minecraft:black_concrete
fill 189 140 613 190 140 618 minecraft:black_concrete
fill 189 140 621 190 140 626 minecraft:black_concrete
fill 189 140 629 190 140 634 minecraft:black_concrete
fill 189 140 637 190 140 642 minecraft:black_concrete
fill 189 140 645 194 141 645 minecraft:black_concrete
fill 190 140 606 190 140 612 minecraft:black_concrete
fill 190 140 619 190 140 620 minecraft:black_concrete
fill 190 140 627 190 140 628 minecraft:black_concrete
fill 190 140 635 190 140 636 minecraft:black_concrete
fill 190 140 643 190 140 644 minecraft:black_concrete
fill 191 140 606 228 140 606 minecraft:black_concrete
fill 191 140 644 229 140 644 minecraft:black_concrete
fill 192 140 605 197 141 605 minecraft:black_concrete
fill 197 140 645 202 141 645 minecraft:black_concrete
fill 200 140 605 205 141 605 minecraft:black_concrete
fill 205 140 645 210 141 645 minecraft:black_concrete
fill 208 140 605 213 141 605 minecraft:black_concrete
fill 213 140 645 218 141 645 minecraft:black_concrete
fill 216 140 605 221 141 605 minecraft:black_concrete
fill 221 140 645 226 141 645 minecraft:black_concrete
fill 224 140 605 229 141 605 minecraft:black_concrete
fill 228 140 607 228 140 643 minecraft:black_concrete
fill 229 140 608 229 141 613 minecraft:black_concrete
fill 229 140 616 229 141 621 minecraft:black_concrete
fill 229 140 624 229 141 629 minecraft:black_concrete
fill 229 140 632 229 141 637 minecraft:black_concrete
fill 229 140 640 229 141 643 minecraft:black_concrete
fill 229 140 645 229 141 645 minecraft:black_concrete
fill 189 141 613 189 141 618 minecraft:black_concrete
fill 189 141 621 189 141 626 minecraft:black_concrete
fill 189 141 629 189 141 634 minecraft:black_concrete
fill 189 141 637 189 141 642 minecraft:black_concrete
fill 219 141 632 220 142 633 minecraft:magenta_concrete
fill 220 141 631 220 142 631 minecraft:magenta_concrete
setblock 229 141 644 minecraft:black_concrete
setblock 191 143 607 minecraft:light[level=14]
setblock 191 143 615 minecraft:light[level=14]
setblock 191 143 623 minecraft:light[level=14]
setblock 191 143 631 minecraft:light[level=14]
setblock 191 143 639 minecraft:light[level=14]
setblock 199 143 607 minecraft:light[level=14]
setblock 199 143 615 minecraft:light[level=14]
setblock 199 143 623 minecraft:light[level=14]
setblock 199 143 631 minecraft:light[level=14]
setblock 199 143 639 minecraft:light[level=14]
setblock 207 143 607 minecraft:light[level=14]
setblock 207 143 615 minecraft:light[level=14]
setblock 207 143 623 minecraft:light[level=14]
setblock 207 143 631 minecraft:light[level=14]
setblock 207 143 639 minecraft:light[level=14]
setblock 215 143 607 minecraft:light[level=14]
setblock 215 143 615 minecraft:light[level=14]
setblock 215 143 623 minecraft:light[level=14]
setblock 215 143 631 minecraft:light[level=14]
setblock 215 143 639 minecraft:light[level=14]
setblock 223 143 607 minecraft:light[level=14]
setblock 223 143 615 minecraft:light[level=14]
setblock 223 143 623 minecraft:light[level=14]
setblock 223 143 631 minecraft:light[level=14]
setblock 223 143 639 minecraft:light[level=14]
fill 188 144 609 188 149 609 minecraft:sea_lantern
fill 188 144 617 188 149 617 minecraft:sea_lantern
fill 188 144 625 188 149 625 minecraft:sea_lantern
fill 188 144 633 188 149 633 minecraft:sea_lantern
fill 188 144 641 188 149 641 minecraft:sea_lantern
fill 191 144 646 191 149 646 minecraft:sea_lantern
fill 192 144 641 192 149 641 minecraft:white_concrete
fill 195 144 604 195 149 604 minecraft:sea_lantern
fill 199 144 646 199 149 646 minecraft:sea_lantern
fill 203 144 604 203 149 604 minecraft:sea_lantern
fill 207 144 646 207 149 646 minecraft:sea_lantern
fill 211 144 604 211 149 604 minecraft:sea_lantern
fill 215 144 646 215 149 646 minecraft:sea_lantern
fill 219 144 604 219 149 604 minecraft:sea_lantern
fill 223 144 646 223 149 646 minecraft:sea_lantern
fill 227 144 604 227 149 604 minecraft:sea_lantern
fill 230 144 609 230 149 609 minecraft:sea_lantern
fill 230 144 617 230 149 617 minecraft:sea_lantern
fill 230 144 625 230 149 625 minecraft:sea_lantern
fill 230 144 633 230 149 633 minecraft:sea_lantern
fill 230 144 641 230 149 641 minecraft:sea_lantern
fill 193 145 641 193 149 641 minecraft:white_concrete
fill 191 146 641 191 149 641 minecraft:white_concrete
fill 192 146 640 193 149 640 minecraft:white_concrete
fill 192 146 642 193 149 642 minecraft:white_concrete
fill 191 147 640 191 149 640 minecraft:white_concrete
fill 191 147 642 191 149 642 minecraft:white_concrete
fill 192 147 639 192 149 639 minecraft:white_concrete
fill 192 147 643 192 149 643 minecraft:white_concrete
fill 194 147 640 194 149 642 minecraft:white_concrete
fill 190 148 640 190 149 642 minecraft:white_concrete
fill 191 148 639 191 149 639 minecraft:white_concrete
fill 191 148 643 191 149 643 minecraft:white_concrete
fill 193 148 639 193 149 639 minecraft:white_concrete
fill 193 148 643 193 149 643 minecraft:white_concrete
setblock 190 149 639 minecraft:white_concrete
setblock 190 149 643 minecraft:white_concrete
fill 192 149 638 193 149 638 minecraft:white_concrete
fill 192 149 644 193 149 644 minecraft:white_concrete
setblock 194 149 639 minecraft:white_concrete
setblock 194 149 643 minecraft:white_concrete
fill 195 149 640 195 149 642 minecraft:white_concrete
fill 188 150 609 188 153 609 minecraft:cyan_concrete
fill 188 150 617 188 156 617 minecraft:cyan_concrete
fill 188 150 625 188 157 625 minecraft:cyan_concrete
fill 188 150 633 188 156 633 minecraft:cyan_concrete
fill 188 150 641 188 156 641 minecraft:cyan_concrete
fill 189 150 637 196 150 642 minecraft:black_concrete
fill 189 150 645 194 150 645 minecraft:black_concrete
fill 190 150 636 196 150 636 minecraft:black_concrete
fill 190 150 643 196 150 644 minecraft:black_concrete
fill 191 150 646 191 156 646 minecraft:cyan_concrete
fill 195 150 604 195 156 604 minecraft:cyan_concrete
fill 199 150 646 199 152 646 minecraft:cyan_concrete
fill 203 150 604 203 156 604 minecraft:cyan_concrete
fill 207 150 646 207 152 646 minecraft:cyan_concrete
fill 211 150 604 211 156 604 minecraft:cyan_concrete
fill 215 150 646 215 156 646 minecraft:cyan_concrete
fill 219 150 604 219 157 604 minecraft:cyan_concrete
fill 223 150 646 223 152 646 minecraft:cyan_concrete
fill 227 150 604 227 152 604 minecraft:cyan_concrete
fill 230 150 609 230 152 609 minecraft:cyan_concrete
fill 230 150 617 230 156 617 minecraft:cyan_concrete
fill 230 150 625 230 152 625 minecraft:cyan_concrete
fill 230 150 633 230 156 633 minecraft:cyan_concrete
fill 230 150 641 230 152 641 minecraft:cyan_concrete
setblock 189 151 637 minecraft:sea_lantern
fill 189 151 638 189 165 638 minecraft:black_concrete
setblock 189 151 639 minecraft:sea_lantern
fill 189 151 640 189 165 640 minecraft:black_concrete
setblock 189 151 641 minecraft:sea_lantern
fill 189 151 642 189 165 642 minecraft:black_concrete
setblock 189 151 643 minecraft:sea_lantern
fill 189 151 644 189 165 644 minecraft:black_concrete
setblock 189 151 645 minecraft:sea_lantern
setblock 190 151 636 minecraft:sea_lantern
fill 190 151 637 190 165 637 minecraft:black_concrete
setblock 190 151 638 minecraft:sea_lantern
fill 190 151 639 190 165 639 minecraft:black_concrete
setblock 190 151 640 minecraft:sea_lantern
fill 190 151 641 190 165 641 minecraft:black_concrete
setblock 190 151 642 minecraft:sea_lantern
fill 190 151 643 190 165 643 minecraft:black_concrete
setblock 190 151 644 minecraft:sea_lantern
fill 190 151 645 190 165 645 minecraft:black_concrete
setblock 190 151 646 minecraft:sea_lantern
setblock 191 151 607 minecraft:light[level=14]
setblock 191 151 615 minecraft:light[level=14]
setblock 191 151 623 minecraft:light[level=14]
setblock 191 151 631 minecraft:light[level=14]
fill 191 151 636 191 165 636 minecraft:black_concrete
setblock 191 151 637 minecraft:sea_lantern
fill 191 151 638 191 165 638 minecraft:black_concrete
setblock 191 151 639 minecraft:sea_lantern
fill 191 151 640 191 165 640 minecraft:black_concrete
setblock 191 151 641 minecraft:sea_lantern
fill 191 151 642 191 165 642 minecraft:black_concrete
setblock 191 151 643 minecraft:sea_lantern
fill 191 151 644 191 165 644 minecraft:black_concrete
setblock 191 151 645 minecraft:sea_lantern
setblock 192 151 636 minecraft:sea_lantern
fill 192 151 637 192 165 637 minecraft:black_concrete
setblock 192 151 638 minecraft:sea_lantern
fill 192 151 639 192 165 639 minecraft:black_concrete
setblock 192 151 640 minecraft:sea_lantern
fill 192 151 641 192 165 641 minecraft:black_concrete
setblock 192 151 642 minecraft:sea_lantern
fill 192 151 643 192 165 643 minecraft:black_concrete
setblock 192 151 644 minecraft:sea_lantern
fill 192 151 645 192 165 645 minecraft:black_concrete
setblock 192 151 646 minecraft:sea_lantern
fill 193 151 636 193 165 636 minecraft:black_concrete
setblock 193 151 637 minecraft:sea_lantern
fill 193 151 638 193 165 638 minecraft:black_concrete
setblock 193 151 639 minecraft:sea_lantern
fill 193 151 640 193 165 640 minecraft:black_concrete
setblock 193 151 641 minecraft:sea_lantern
fill 193 151 642 193 165 642 minecraft:black_concrete
setblock 193 151 643 minecraft:sea_lantern
fill 193 151 644 193 165 644 minecraft:black_concrete
setblock 193 151 645 minecraft:sea_lantern
fill 193 151 646 193 156 646 minecraft:cyan_concrete
setblock 194 151 636 minecraft:sea_lantern
fill 194 151 637 194 165 637 minecraft:black_concrete
setblock 194 151 638 minecraft:sea_lantern
fill 194 151 639 194 165 639 minecraft:black_concrete
setblock 194 151 640 minecraft:sea_lantern
fill 194 151 641 194 165 641 minecraft:black_concrete
setblock 194 151 642 minecraft:sea_lantern
fill 194 151 643 194 165 643 minecraft:black_concrete
setblock 194 151 644 minecraft:sea_lantern
fill 194 151 645 194 165 645 minecraft:black_concrete
setblock 194 151 646 minecraft:sea_lantern
fill 195 151 636 195 165 636 minecraft:black_concrete
setblock 195 151 637 minecraft:sea_lantern
fill 195 151 638 195 165 638 minecraft:black_concrete
setblock 195 151 639 minecraft:sea_lantern
fill 195 151 640 195 165 640 minecraft:black_concrete
setblock 195 151 641 minecraft:sea_lantern
fill 195 151 642 195 165 642 minecraft:black_concrete
setblock 195 151 643 minecraft:sea_lantern
fill 195 151 644 195 165 644 minecraft:black_concrete
setblock 195 151 645 minecraft:sea_lantern
fill 195 151 646 195 156 646 minecraft:cyan_concrete
setblock 196 151 636 minecraft:sea_lantern
fill 196 151 637 196 165 637 minecraft:black_concrete
setblock 196 151 638 minecraft:sea_lantern
fill 196 151 639 196 165 639 minecraft:black_concrete
setblock 196 151 640 minecraft:sea_lantern
fill 196 151 641 196 165 641 minecraft:black_concrete
setblock 196 151 642 minecraft:sea_lantern
fill 196 151 643 196 165 643 minecraft:black_concrete
setblock 196 151 644 minecraft:sea_lantern
fill 196 151 645 196 165 645 minecraft:black_concrete
setblock 196 151 646 minecraft:sea_lantern
fill 197 151 646 197 156 646 minecraft:cyan_concrete
setblock 199 151 607 minecraft:light[level=14]
setblock 199 151 615 minecraft:light[level=14]
setblock 199 151 623 minecraft:light[level=14]
setblock 199 151 631 minecraft:light[level=14]
setblock 199 151 639 minecraft:light[level=14]
setblock 207 151 607 minecraft:light[level=14]
setblock 207 151 615 minecraft:light[level=14]
setblock 207 151 623 minecraft:light[level=14]
setblock 207 151 631 minecraft:light[level=14]
setblock 207 151 639 minecraft:light[level=14]
setblock 215 151 607 minecraft:light[level=14]
setblock 215 151 615 minecraft:light[level=14]
setblock 215 151 623 minecraft:light[level=14]
setblock 215 151 631 minecraft:light[level=14]
setblock 215 151 639 minecraft:light[level=14]
setblock 223 151 607 minecraft:light[level=14]
setblock 223 151 615 minecraft:light[level=14]
setblock 223 151 623 minecraft:light[level=14]
setblock 223 151 631 minecraft:light[level=14]
setblock 223 151 639 minecraft:light[level=14]
fill 189 152 637 189 153 637 minecraft:black_concrete
fill 189 152 639 189 153 639 minecraft:black_concrete
fill 189 152 641 189 153 641 minecraft:black_concrete
fill 189 152 643 189 153 643 minecraft:black_concrete
fill 189 152 645 189 153 645 minecraft:black_concrete
fill 190 152 636 190 153 636 minecraft:black_concrete
fill 190 152 638 190 153 638 minecraft:black_concrete
fill 190 152 640 190 153 640 minecraft:black_concrete
fill 190 152 642 190 153 642 minecraft:black_concrete
fill 190 152 644 190 153 644 minecraft:black_concrete
fill 190 152 646 190 153 646 minecraft:cyan_concrete
fill 191 152 637 191 153 637 minecraft:black_concrete
fill 191 152 639 191 153 639 minecraft:black_concrete
fill 191 152 641 191 153 641 minecraft:black_concrete
fill 191 152 643 191 153 643 minecraft:black_concrete
fill 191 152 645 191 153 645 minecraft:black_concrete
fill 192 152 636 192 153 636 minecraft:black_concrete
fill 192 152 638 192 153 638 minecraft:black_concrete
fill 192 152 640 192 153 640 minecraft:black_concrete
fill 192 152 642 192 153 642 minecraft:black_concrete
fill 192 152 644 192 153 644 minecraft:black_concrete
fill 192 152 646 192 153 646 minecraft:cyan_concrete
fill 193 152 637 193 153 637 minecraft:black_concrete
fill 193 152 639 193 153 639 minecraft:black_concrete
fill 193 152 641 193 153 641 minecraft:black_concrete
fill 193 152 643 193 153 643 minecraft:black_concrete
fill 193 152 645 193 153 645 minecraft:black_concrete
fill 194 152 636 194 153 636 minecraft:black_concrete
fill 194 152 638 194 153 638 minecraft:black_concrete
fill 194 152 640 194 153 640 minecraft:black_concrete
fill 194 152 642 194 153 642 minecraft:black_concrete
fill 194 152 644 194 153 644 minecraft:black_concrete
fill 194 152 646 194 153 646 minecraft:cyan_concrete
fill 195 152 637 195 153 637 minecraft:black_concrete
fill 195 152 639 195 153 639 minecraft:black_concrete
fill 195 152 641 195 153 641 minecraft:black_concrete
fill 195 152 643 195 153 643 minecraft:black_concrete
fill 195 152 645 195 153 645 minecraft:black_concrete
fill 196 152 636 196 153 636 minecraft:black_concrete
fill 196 152 638 196 153 638 minecraft:black_concrete
fill 196 152 640 196 153 640 minecraft:black_concrete
fill 196 152 642 196 153 642 minecraft:black_concrete
fill 196 152 644 196 153 644 minecraft:black_concrete
fill 196 152 646 196 153 646 minecraft:cyan_concrete
setblock 188 153 607 minecraft:magenta_concrete
fill 188 153 608 188 156 608 minecraft:cyan_concrete
setblock 188 153 621 minecraft:magenta_concrete
fill 188 153 622 188 153 623 minecraft:cyan_concrete
setblock 188 153 624 minecraft:magenta_concrete
fill 188 153 626 188 156 627 minecraft:cyan_concrete
setblock 188 153 628 minecraft:magenta_concrete
fill 188 153 629 188 154 631 minecraft:cyan_concrete
fill 188 153 642 188 153 643 minecraft:magenta_concrete
fill 188 153 644 188 156 645 minecraft:cyan_concrete
setblock 188 153 646 minecraft:magenta_concrete
fill 193 153 604 193 156 604 minecraft:cyan_concrete
setblock 194 153 604 minecraft:magenta_concrete
fill 195 153 629 196 154 630 minecraft:cyan_concrete
setblock 196 153 604 minecraft:magenta_concrete
fill 196 153 628 196 154 628 minecraft:cyan_concrete
fill 197 153 604 197 156 604 minecraft:cyan_concrete
fill 197 153 629 197 154 629 minecraft:cyan_concrete
setblock 199 153 646 minecraft:magenta_concrete
fill 204 153 646 204 157 646 minecraft:cyan_concrete
setblock 205 153 646 minecraft:magenta_concrete
fill 206 153 646 206 156 646 minecraft:cyan_concrete
setblock 207 153 646 minecraft:magenta_concrete
setblock 209 153 646 minecraft:magenta_concrete
fill 210 153 646 210 156 646 minecraft:cyan_concrete
setblock 217 153 604 minecraft:magenta_concrete
setblock 223 153 646 minecraft:magenta_concrete
setblock 227 153 604 minecraft:magenta_concrete
fill 230 153 609 230 153 610 minecraft:magenta_concrete
fill 230 153 611 230 156 611 minecraft:cyan_concrete
fill 230 153 612 230 153 613 minecraft:magenta_concrete
setblock 230 153 615 minecraft:magenta_concrete
fill 230 153 616 230 156 616 minecraft:cyan_concrete
setblock 230 153 625 minecraft:magenta_concrete
fill 230 153 634 230 154 636 minecraft:cyan_concrete
setblock 230 153 637 minecraft:magenta_concrete
fill 230 153 638 230 157 638 minecraft:cyan_concrete
fill 230 153 641 230 153 642 minecraft:magenta_concrete
fill 230 153 643 230 156 643 minecraft:cyan_concrete
fill 230 153 644 230 155 644 minecraft:magenta_concrete
fill 230 153 645 230 157 645 minecraft:cyan_concrete
fill 188 154 607 188 156 607 minecraft:cyan_concrete
setblock 188 154 609 minecraft:magenta_concrete
fill 188 154 610 188 156 611 minecraft:cyan_concrete
fill 188 154 612 188 155 612 minecraft:magenta_concrete
fill 188 154 613 188 156 615 minecraft:cyan_concrete
setblock 188 154 616 minecraft:magenta_concrete
fill 188 154 621 188 156 621 minecraft:cyan_concrete
setblock 188 154 622 minecraft:magenta_concrete
fill 188 154 623 188 156 624 minecraft:cyan_concrete
fill 188 154 628 188 156 628 minecraft:cyan_concrete
fill 188 154 642 188 156 643 minecraft:cyan_concrete
fill 188 154 646 188 156 646 minecraft:cyan_concrete
fill 189 154 605 189 155 610 minecraft:black_concrete
fill 189 154 613 190 154 618 minecraft:black_concrete
fill 189 154 621 190 154 626 minecraft:black_concrete
fill 189 154 629 190 154 634 minecraft:black_concrete
setblock 189 154 637 minecraft:sea_lantern
setblock 189 154 639 minecraft:sea_lantern
setblock 189 154 641 minecraft:sea_lantern
setblock 189 154 643 minecraft:sea_lantern
setblock 189 154 645 minecraft:sea_lantern
fill 190 154 606 190 154 612 minecraft:black_concrete
fill 190 154 619 190 154 620 minecraft:black_concrete
fill 190 154 627 190 154 628 minecraft:black_concrete
setblock 190 154 635 minecraft:black_concrete
setblock 190 154 636 minecraft:sea_lantern
setblock 190 154 638 minecraft:sea_lantern
setblock 190 154 640 minecraft:sea_lantern
setblock 190 154 642 minecraft:sea_lantern
setblock 190 154 644 minecraft:sea_lantern
setblock 190 154 646 minecraft:sea_lantern
fill 191 154 606 228 154 606 minecraft:black_concrete
setblock 191 154 637 minecraft:sea_lantern
setblock 191 154 639 minecraft:sea_lantern
setblock 191 154 641 minecraft:sea_lantern
setblock 191 154 643 minecraft:sea_lantern
setblock 191 154 645 minecraft:sea_lantern
fill 192 154 605 197 155 605 minecraft:black_concrete
setblock 192 154 636 minecraft:sea_lantern
setblock 192 154 638 minecraft:sea_lantern
setblock 192 154 640 minecraft:sea_lantern
setblock 192 154 642 minecraft:sea_lantern
setblock 192 154 644 minecraft:sea_lantern
setblock 192 154 646 minecraft:sea_lantern
setblock 193 154 637 minecraft:sea_lantern
setblock 193 154 639 minecraft:sea_lantern
setblock 193 154 641 minecraft:sea_lantern
setblock 193 154 643 minecraft:sea_lantern
setblock 193 154 645 minecraft:sea_lantern
fill 194 154 604 194 156 604 minecraft:cyan_concrete
setblock 194 154 636 minecraft:sea_lantern
setblock 194 154 638 minecraft:sea_lantern
setblock 194 154 640 minecraft:sea_lantern
setblock 194 154 642 minecraft:sea_lantern
setblock 194 154 644 minecraft:sea_lantern
setblock 194 154 646 minecraft:sea_lantern
setblock 195 154 637 minecraft:sea_lantern
setblock 195 154 639 minecraft:sea_lantern
setblock 195 154 641 minecraft:sea_lantern
setblock 195 154 643 minecraft:sea_lantern
setblock 195 154 645 minecraft:sea_lantern
fill 196 154 604 196 156 604 minecraft:cyan_concrete
setblock 196 154 636 minecraft:sea_lantern
setblock 196 154 638 minecraft:sea_lantern
setblock 196 154 640 minecraft:sea_lantern
setblock 196 154 642 minecraft:sea_lantern
setblock 196 154 644 minecraft:sea_lantern
setblock 196 154 646 minecraft:sea_lantern
fill 197 154 644 202 154 645 minecraft:black_concrete
fill 199 154 646 199 157 646 minecraft:cyan_concrete
fill 200 154 605 205 155 605 minecraft:black_concrete
fill 203 154 644 229 154 644 minecraft:black_concrete
setblock 204 154 604 minecraft:magenta_concrete
fill 205 154 645 210 155 645 minecraft:black_concrete
fill 205 154 646 205 156 646 minecraft:cyan_concrete
fill 206 154 604 208 156 604 minecraft:cyan_concrete
fill 207 154 646 207 156 646 minecraft:cyan_concrete
fill 208 154 605 213 155 605 minecraft:black_concrete
setblock 209 154 604 minecraft:magenta_concrete
fill 209 154 646 209 156 646 minecraft:cyan_concrete
fill 210 154 604 210 156 604 minecraft:cyan_concrete
fill 213 154 645 218 155 645 minecraft:black_concrete
fill 216 154 605 221 155 605 minecraft:black_concrete
fill 217 154 604 217 156 604 minecraft:cyan_concrete
fill 218 154 646 221 154 646 minecraft:cyan_concrete
fill 221 154 645 226 155 645 minecraft:black_concrete
setblock 222 154 646 minecraft:magenta_concrete
fill 223 154 646 223 156 646 minecraft:cyan_concrete
fill 224 154 605 229 155 605 minecraft:black_concrete
setblock 227 154 604 minecraft:cyan_concrete
fill 228 154 607 228 154 643 minecraft:black_concrete
fill 229 154 608 229 155 613 minecraft:black_concrete
fill 229 154 616 229 155 621 minecraft:black_concrete
fill 229 154 624 229 155 629 minecraft:black_concrete
fill 229 154 632 229 155 637 minecraft:black_concrete
fill 229 154 640 229 155 643 minecraft:black_concrete
fill 229 154 645 229 155 645 minecraft:black_concrete
fill 230 154 609 230 156 610 minecraft:cyan_concrete
fill 230 154 612 230 156 613 minecraft:cyan_concrete
setblock 230 154 615 minecraft:cyan_concrete
fill 230 154 625 230 156 625 minecraft:cyan_concrete
fill 230 154 637 230 156 637 minecraft:cyan_concrete
fill 230 154 641 230 154 642 minecraft:cyan_concrete
setblock 230 154 646 minecraft:magenta_concrete
fill 188 155 609 188 156 609 minecraft:cyan_concrete
fill 188 155 616 188 156 616 minecraft:cyan_concrete
fill 188 155 622 188 156 622 minecraft:cyan_concrete
fill 188 155 629 188 157 629 minecraft:cyan_concrete
setblock 188 155 630 minecraft:magenta_concrete
fill 188 155 631 188 156 631 minecraft:cyan_concrete
setblock 188 155 636 minecraft:magenta_concrete
fill 188 155 637 188 156 638 minecraft:cyan_concrete
setblock 188 155 639 minecraft:magenta_concrete
fill 188 155 640 188 156 640 minecraft:cyan_concrete
schedule function dropper:buildpart/148_2 1t
