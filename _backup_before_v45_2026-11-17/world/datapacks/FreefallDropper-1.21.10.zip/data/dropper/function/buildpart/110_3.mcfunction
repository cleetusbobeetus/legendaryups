setblock 97 271 498 minecraft:light[level=11]
setblock 105 271 466 minecraft:light[level=11]
setblock 105 271 474 minecraft:light[level=11]
setblock 105 271 482 minecraft:light[level=11]
setblock 105 271 490 minecraft:light[level=11]
setblock 105 271 498 minecraft:light[level=11]
setblock 113 271 466 minecraft:light[level=11]
setblock 113 271 474 minecraft:light[level=11]
setblock 113 271 482 minecraft:light[level=11]
setblock 113 271 490 minecraft:light[level=11]
setblock 113 271 498 minecraft:light[level=11]
setblock 121 271 466 minecraft:light[level=11]
setblock 121 271 474 minecraft:light[level=11]
setblock 121 271 482 minecraft:light[level=11]
setblock 121 271 490 minecraft:light[level=11]
setblock 121 271 498 minecraft:light[level=11]
fill 124 271 470 124 271 472 minecraft:cyan_concrete
fill 125 271 470 126 272 470 minecraft:cyan_concrete
fill 125 271 473 126 271 473 minecraft:cyan_concrete
fill 127 271 471 127 271 472 minecraft:cyan_concrete
setblock 129 271 466 minecraft:light[level=11]
setblock 129 271 474 minecraft:light[level=11]
setblock 129 271 482 minecraft:light[level=11]
setblock 129 271 490 minecraft:light[level=11]
setblock 129 271 498 minecraft:light[level=11]
fill 94 272 469 94 285 469 minecraft:deepslate_tiles
fill 94 272 470 94 272 471 minecraft:sea_lantern
fill 94 272 472 94 285 472 minecraft:deepslate_tiles
fill 94 272 481 94 285 481 minecraft:deepslate_tiles
fill 94 272 482 94 272 483 minecraft:sea_lantern
fill 94 272 484 94 285 484 minecraft:deepslate_tiles
fill 94 272 493 94 285 493 minecraft:deepslate_tiles
fill 94 272 494 94 272 495 minecraft:sea_lantern
fill 94 272 496 94 285 496 minecraft:deepslate_tiles
fill 94 272 505 94 285 505 minecraft:deepslate_tiles
fill 95 272 505 96 272 505 minecraft:sea_lantern
fill 97 272 505 97 285 505 minecraft:deepslate_tiles
fill 101 272 463 101 285 463 minecraft:deepslate_tiles
fill 102 272 463 103 272 463 minecraft:sea_lantern
fill 104 272 463 104 285 463 minecraft:deepslate_tiles
fill 106 272 505 106 285 505 minecraft:deepslate_tiles
fill 107 272 505 108 272 505 minecraft:sea_lantern
fill 109 272 505 109 285 505 minecraft:deepslate_tiles
fill 113 272 463 113 285 463 minecraft:deepslate_tiles
fill 114 272 463 115 272 463 minecraft:sea_lantern
fill 116 272 463 116 285 463 minecraft:deepslate_tiles
fill 118 272 505 118 285 505 minecraft:deepslate_tiles
fill 119 272 505 120 272 505 minecraft:sea_lantern
fill 121 272 505 121 285 505 minecraft:deepslate_tiles
fill 124 272 471 124 272 472 minecraft:cyan_concrete
fill 125 272 463 125 285 463 minecraft:deepslate_tiles
fill 126 272 463 127 272 463 minecraft:sea_lantern
setblock 127 272 471 minecraft:cyan_concrete
fill 128 272 463 128 285 463 minecraft:deepslate_tiles
fill 130 272 505 130 285 505 minecraft:deepslate_tiles
fill 131 272 505 132 272 505 minecraft:sea_lantern
fill 133 272 505 133 285 505 minecraft:deepslate_tiles
fill 136 272 464 136 285 464 minecraft:deepslate_tiles
fill 136 272 465 136 272 466 minecraft:sea_lantern
fill 136 272 467 136 285 467 minecraft:deepslate_tiles
fill 136 272 476 136 285 476 minecraft:deepslate_tiles
fill 136 272 477 136 272 478 minecraft:sea_lantern
fill 136 272 479 136 285 479 minecraft:deepslate_tiles
fill 136 272 488 136 285 488 minecraft:deepslate_tiles
fill 136 272 489 136 272 490 minecraft:sea_lantern
fill 136 272 491 136 285 491 minecraft:deepslate_tiles
fill 136 272 500 136 285 500 minecraft:deepslate_tiles
fill 136 272 501 136 272 502 minecraft:sea_lantern
fill 136 272 503 136 285 503 minecraft:deepslate_tiles
fill 94 273 470 94 285 471 minecraft:deepslate_tiles
fill 94 273 482 94 285 483 minecraft:deepslate_tiles
fill 94 273 494 94 285 495 minecraft:deepslate_tiles
fill 95 273 505 96 285 505 minecraft:deepslate_tiles
fill 102 273 463 103 285 463 minecraft:deepslate_tiles
fill 107 273 505 108 285 505 minecraft:deepslate_tiles
fill 114 273 463 115 285 463 minecraft:deepslate_tiles
fill 119 273 505 120 285 505 minecraft:deepslate_tiles
fill 126 273 463 127 285 463 minecraft:deepslate_tiles
fill 131 273 505 132 285 505 minecraft:deepslate_tiles
fill 136 273 465 136 285 466 minecraft:deepslate_tiles
fill 136 273 477 136 285 478 minecraft:deepslate_tiles
fill 136 273 489 136 285 490 minecraft:deepslate_tiles
fill 136 273 501 136 285 502 minecraft:deepslate_tiles
setblock 97 279 466 minecraft:light[level=11]
setblock 97 279 474 minecraft:light[level=11]
setblock 97 279 482 minecraft:light[level=11]
setblock 97 279 490 minecraft:light[level=11]
setblock 97 279 498 minecraft:light[level=11]
fill 104 279 476 105 279 496 minecraft:reinforced_deepslate
setblock 105 279 466 minecraft:light[level=11]
setblock 105 279 474 minecraft:light[level=11]
setblock 105 279 498 minecraft:light[level=11]
fill 106 279 476 124 279 477 minecraft:reinforced_deepslate
fill 106 279 478 111 279 494 minecraft:sculk
fill 106 279 495 124 279 496 minecraft:reinforced_deepslate
fill 112 279 478 112 279 485 minecraft:sculk
fill 112 279 487 112 279 494 minecraft:sculk
setblock 113 279 466 minecraft:light[level=11]
setblock 113 279 474 minecraft:light[level=11]
fill 113 279 478 113 279 484 minecraft:sculk
fill 113 279 488 113 279 494 minecraft:sculk
setblock 113 279 498 minecraft:light[level=11]
fill 114 279 478 122 279 483 minecraft:sculk
fill 114 279 489 122 279 494 minecraft:sculk
fill 115 279 484 122 279 484 minecraft:sculk
fill 115 279 488 122 279 488 minecraft:sculk
fill 116 279 485 122 279 485 minecraft:sculk
fill 116 279 487 122 279 487 minecraft:sculk
fill 117 279 486 122 279 486 minecraft:sculk
setblock 121 279 466 minecraft:light[level=11]
setblock 121 279 474 minecraft:light[level=11]
setblock 121 279 498 minecraft:light[level=11]
fill 123 279 478 124 279 494 minecraft:reinforced_deepslate
setblock 129 279 466 minecraft:light[level=11]
setblock 129 279 474 minecraft:light[level=11]
setblock 129 279 482 minecraft:light[level=11]
setblock 129 279 490 minecraft:light[level=11]
setblock 129 279 498 minecraft:light[level=11]
fill 95 280 464 103 280 504 minecraft:deepslate_tiles
fill 104 280 464 135 280 475 minecraft:deepslate_tiles
setblock 104 280 476 minecraft:reinforced_deepslate
setblock 104 280 477 minecraft:sea_lantern
fill 104 280 478 104 280 480 minecraft:reinforced_deepslate
setblock 104 280 481 minecraft:sea_lantern
fill 104 280 482 104 280 484 minecraft:reinforced_deepslate
setblock 104 280 485 minecraft:sea_lantern
fill 104 280 486 104 280 488 minecraft:reinforced_deepslate
setblock 104 280 489 minecraft:sea_lantern
fill 104 280 490 104 280 492 minecraft:reinforced_deepslate
setblock 104 280 493 minecraft:sea_lantern
fill 104 280 494 104 280 496 minecraft:reinforced_deepslate
fill 104 280 497 135 280 504 minecraft:deepslate_tiles
setblock 105 280 476 minecraft:sea_lantern
fill 105 280 477 105 280 479 minecraft:reinforced_deepslate
setblock 105 280 480 minecraft:sea_lantern
fill 105 280 481 105 280 483 minecraft:reinforced_deepslate
setblock 105 280 484 minecraft:sea_lantern
fill 105 280 485 105 280 487 minecraft:reinforced_deepslate
setblock 105 280 488 minecraft:sea_lantern
fill 105 280 489 105 280 491 minecraft:reinforced_deepslate
setblock 105 280 492 minecraft:sea_lantern
fill 105 280 493 105 280 495 minecraft:reinforced_deepslate
setblock 105 280 496 minecraft:sea_lantern
fill 106 280 476 107 280 477 minecraft:reinforced_deepslate
fill 106 280 478 110 280 494 minecraft:sculk
setblock 106 280 495 minecraft:sea_lantern
fill 106 280 496 108 280 496 minecraft:reinforced_deepslate
fill 107 280 495 109 280 495 minecraft:reinforced_deepslate
setblock 108 280 476 minecraft:reinforced_deepslate
setblock 108 280 477 minecraft:sea_lantern
setblock 109 280 476 minecraft:sea_lantern
fill 109 280 477 111 280 477 minecraft:reinforced_deepslate
setblock 109 280 496 minecraft:sea_lantern
fill 110 280 476 112 280 476 minecraft:reinforced_deepslate
setblock 110 280 495 minecraft:sea_lantern
fill 110 280 496 112 280 496 minecraft:reinforced_deepslate
fill 111 280 478 111 280 484 minecraft:sculk
fill 111 280 485 111 280 487 minecraft:sea_lantern
fill 111 280 488 111 280 494 minecraft:sculk
fill 111 280 495 113 280 495 minecraft:reinforced_deepslate
setblock 112 280 477 minecraft:sea_lantern
fill 112 280 478 112 280 483 minecraft:sculk
fill 112 280 484 112 280 485 minecraft:sea_lantern
fill 112 280 487 112 280 488 minecraft:sea_lantern
fill 112 280 489 112 280 494 minecraft:sculk
setblock 113 280 476 minecraft:sea_lantern
fill 113 280 477 115 280 477 minecraft:reinforced_deepslate
fill 113 280 478 122 280 482 minecraft:sculk
fill 113 280 483 113 280 484 minecraft:sea_lantern
fill 113 280 488 113 280 489 minecraft:sea_lantern
fill 113 280 490 122 280 494 minecraft:sculk
setblock 113 280 496 minecraft:sea_lantern
fill 114 280 476 116 280 476 minecraft:reinforced_deepslate
fill 114 280 483 115 280 483 minecraft:sea_lantern
fill 114 280 489 115 280 489 minecraft:sea_lantern
setblock 114 280 495 minecraft:sea_lantern
fill 114 280 496 116 280 496 minecraft:reinforced_deepslate
fill 115 280 484 116 280 484 minecraft:sea_lantern
fill 115 280 488 116 280 488 minecraft:sea_lantern
fill 115 280 495 117 280 495 minecraft:reinforced_deepslate
setblock 116 280 477 minecraft:sea_lantern
fill 116 280 483 122 280 483 minecraft:sculk
fill 116 280 485 117 280 485 minecraft:sea_lantern
fill 116 280 487 117 280 487 minecraft:sea_lantern
fill 116 280 489 122 280 489 minecraft:sculk
setblock 117 280 476 minecraft:sea_lantern
fill 117 280 477 119 280 477 minecraft:reinforced_deepslate
fill 117 280 484 122 280 484 minecraft:sculk
setblock 117 280 486 minecraft:sea_lantern
fill 117 280 488 122 280 488 minecraft:sculk
setblock 117 280 496 minecraft:sea_lantern
fill 118 280 476 120 280 476 minecraft:reinforced_deepslate
fill 118 280 485 122 280 487 minecraft:sculk
setblock 118 280 495 minecraft:sea_lantern
fill 118 280 496 120 280 496 minecraft:reinforced_deepslate
fill 119 280 495 121 280 495 minecraft:reinforced_deepslate
setblock 120 280 477 minecraft:sea_lantern
setblock 121 280 476 minecraft:sea_lantern
fill 121 280 477 123 280 477 minecraft:reinforced_deepslate
setblock 121 280 496 minecraft:sea_lantern
fill 122 280 476 124 280 476 minecraft:reinforced_deepslate
setblock 122 280 495 minecraft:sea_lantern
fill 122 280 496 124 280 496 minecraft:reinforced_deepslate
setblock 123 280 478 minecraft:sea_lantern
fill 123 280 479 123 280 481 minecraft:reinforced_deepslate
setblock 123 280 482 minecraft:sea_lantern
fill 123 280 483 123 280 485 minecraft:reinforced_deepslate
setblock 123 280 486 minecraft:sea_lantern
fill 123 280 487 123 280 489 minecraft:reinforced_deepslate
setblock 123 280 490 minecraft:sea_lantern
fill 123 280 491 123 280 493 minecraft:reinforced_deepslate
setblock 123 280 494 minecraft:sea_lantern
fill 123 280 495 124 284 495 minecraft:reinforced_deepslate
setblock 124 280 477 minecraft:sea_lantern
fill 124 280 478 124 280 480 minecraft:reinforced_deepslate
setblock 124 280 481 minecraft:sea_lantern
fill 124 280 482 124 280 484 minecraft:reinforced_deepslate
setblock 124 280 485 minecraft:sea_lantern
fill 124 280 486 124 280 488 minecraft:reinforced_deepslate
setblock 124 280 489 minecraft:sea_lantern
fill 124 280 490 124 280 492 minecraft:reinforced_deepslate
setblock 124 280 493 minecraft:sea_lantern
setblock 124 280 494 minecraft:reinforced_deepslate
fill 125 280 476 135 280 496 minecraft:deepslate_tiles
fill 104 281 477 106 284 477 minecraft:reinforced_deepslate
fill 104 281 495 106 284 495 minecraft:reinforced_deepslate
fill 105 281 476 105 284 476 minecraft:reinforced_deepslate
fill 105 281 478 105 284 478 minecraft:reinforced_deepslate
fill 105 281 494 105 284 494 minecraft:reinforced_deepslate
fill 105 281 496 105 284 496 minecraft:reinforced_deepslate
fill 122 281 477 124 284 477 minecraft:reinforced_deepslate
fill 122 281 495 122 284 495 minecraft:reinforced_deepslate
fill 123 281 476 123 284 476 minecraft:reinforced_deepslate
fill 123 281 478 123 284 478 minecraft:reinforced_deepslate
fill 123 281 494 123 284 494 minecraft:reinforced_deepslate
fill 123 281 496 123 284 496 minecraft:reinforced_deepslate
fill 95 284 464 97 300 464 minecraft:deepslate_bricks
fill 95 284 474 95 300 476 minecraft:deepslate_bricks
fill 95 284 486 95 300 488 minecraft:deepslate_bricks
fill 95 284 498 95 300 500 minecraft:deepslate_bricks
fill 96 284 473 96 285 475 minecraft:deepslate_bricks
fill 96 284 484 96 287 484 minecraft:reinforced_deepslate
fill 96 284 485 96 285 487 minecraft:deepslate_bricks
fill 96 284 497 96 285 499 minecraft:deepslate_bricks
fill 101 284 504 103 300 504 minecraft:deepslate_bricks
fill 102 284 503 104 285 503 minecraft:deepslate_bricks
fill 104 284 464 114 284 470 minecraft:deepslate_bricks
setblock 105 284 502 minecraft:reinforced_deepslate
fill 113 284 504 115 300 504 minecraft:deepslate_bricks
fill 114 284 503 116 285 503 minecraft:deepslate_bricks
fill 118 284 465 120 285 465 minecraft:deepslate_bricks
fill 119 284 464 121 300 464 minecraft:deepslate_bricks
fill 125 284 504 127 300 504 minecraft:deepslate_bricks
fill 126 284 503 128 285 503 minecraft:deepslate_bricks
fill 130 284 465 132 285 465 minecraft:deepslate_bricks
fill 131 284 464 133 300 464 minecraft:deepslate_bricks
fill 131 284 498 131 296 498 minecraft:reinforced_deepslate
fill 134 284 473 134 285 475 minecraft:deepslate_bricks
fill 134 284 485 134 285 487 minecraft:deepslate_bricks
fill 134 284 497 134 285 499 minecraft:deepslate_bricks
fill 135 284 472 135 300 474 minecraft:deepslate_bricks
fill 135 284 484 135 300 486 minecraft:deepslate_bricks
fill 135 284 496 135 300 498 minecraft:deepslate_bricks
fill 95 285 467 95 285 472 minecraft:sculk
fill 95 285 479 95 285 484 minecraft:sculk
fill 95 285 491 95 285 496 minecraft:sculk
fill 95 285 503 95 285 504 minecraft:sculk
fill 96 285 504 99 285 504 minecraft:sculk
fill 99 285 464 104 285 464 minecraft:sculk
fill 104 285 465 114 285 470 minecraft:deepslate_bricks
fill 105 285 464 110 285 464 minecraft:deepslate_bricks
fill 106 285 504 111 285 504 minecraft:sculk
fill 111 285 464 116 285 464 minecraft:sculk
fill 118 285 504 123 285 504 minecraft:sculk
fill 123 285 464 128 285 464 minecraft:sculk
fill 130 285 504 135 285 504 minecraft:sculk
fill 135 285 464 135 285 469 minecraft:sculk
fill 135 285 476 135 285 481 minecraft:sculk
fill 135 285 488 135 285 493 minecraft:sculk
fill 135 285 500 135 285 503 minecraft:sculk
fill 94 286 469 94 291 472 minecraft:sea_lantern
fill 94 286 481 94 291 484 minecraft:sea_lantern
fill 94 286 493 94 291 496 minecraft:sea_lantern
fill 94 286 505 97 291 505 minecraft:sea_lantern
fill 101 286 463 104 291 463 minecraft:sea_lantern
fill 104 286 464 104 298 464 minecraft:deepslate_bricks
setblock 104 286 465 minecraft:sea_lantern
fill 104 286 466 104 298 466 minecraft:deepslate_bricks
setblock 104 286 467 minecraft:sea_lantern
fill 104 286 468 104 298 468 minecraft:deepslate_bricks
setblock 104 286 469 minecraft:sea_lantern
fill 104 286 470 104 298 470 minecraft:deepslate_bricks
setblock 105 286 464 minecraft:sea_lantern
fill 105 286 465 105 298 465 minecraft:deepslate_bricks
setblock 105 286 466 minecraft:sea_lantern
fill 105 286 467 105 298 467 minecraft:deepslate_bricks
setblock 105 286 468 minecraft:sea_lantern
fill 105 286 469 105 298 469 minecraft:deepslate_bricks
setblock 105 286 470 minecraft:sea_lantern
fill 106 286 464 106 298 464 minecraft:deepslate_bricks
setblock 106 286 465 minecraft:sea_lantern
fill 106 286 466 106 298 466 minecraft:deepslate_bricks
setblock 106 286 467 minecraft:sea_lantern
fill 106 286 468 106 298 468 minecraft:deepslate_bricks
setblock 106 286 469 minecraft:sea_lantern
fill 106 286 470 106 298 470 minecraft:deepslate_bricks
fill 106 286 505 109 291 505 minecraft:sea_lantern
setblock 107 286 464 minecraft:sea_lantern
fill 107 286 465 107 298 465 minecraft:deepslate_bricks
setblock 107 286 466 minecraft:sea_lantern
fill 107 286 467 107 298 467 minecraft:deepslate_bricks
setblock 107 286 468 minecraft:sea_lantern
fill 107 286 469 107 298 469 minecraft:deepslate_bricks
setblock 107 286 470 minecraft:sea_lantern
fill 108 286 464 108 300 464 minecraft:deepslate_bricks
setblock 108 286 465 minecraft:sea_lantern
fill 108 286 466 108 298 466 minecraft:deepslate_bricks
setblock 108 286 467 minecraft:sea_lantern
fill 108 286 468 108 298 468 minecraft:deepslate_bricks
setblock 108 286 469 minecraft:sea_lantern
fill 108 286 470 108 298 470 minecraft:deepslate_bricks
setblock 109 286 464 minecraft:sea_lantern
fill 109 286 465 109 298 465 minecraft:deepslate_bricks
setblock 109 286 466 minecraft:sea_lantern
fill 109 286 467 109 298 467 minecraft:deepslate_bricks
setblock 109 286 468 minecraft:sea_lantern
fill 109 286 469 109 298 469 minecraft:deepslate_bricks
setblock 109 286 470 minecraft:sea_lantern
fill 110 286 464 110 298 464 minecraft:deepslate_bricks
setblock 110 286 465 minecraft:sea_lantern
fill 110 286 466 110 298 466 minecraft:deepslate_bricks
setblock 110 286 467 minecraft:sea_lantern
fill 110 286 468 110 298 468 minecraft:deepslate_bricks
setblock 110 286 469 minecraft:sea_lantern
fill 110 286 470 110 298 470 minecraft:deepslate_bricks
setblock 111 286 464 minecraft:sea_lantern
fill 111 286 465 111 298 465 minecraft:deepslate_bricks
setblock 111 286 466 minecraft:sea_lantern
fill 111 286 467 111 298 467 minecraft:deepslate_bricks
setblock 111 286 468 minecraft:sea_lantern
fill 111 286 469 111 298 469 minecraft:deepslate_bricks
setblock 111 286 470 minecraft:sea_lantern
fill 112 286 464 112 298 464 minecraft:deepslate_bricks
setblock 112 286 465 minecraft:sea_lantern
fill 112 286 466 112 298 466 minecraft:deepslate_bricks
setblock 112 286 467 minecraft:sea_lantern
fill 112 286 468 112 298 468 minecraft:deepslate_bricks
setblock 112 286 469 minecraft:sea_lantern
fill 112 286 470 112 298 470 minecraft:deepslate_bricks
fill 113 286 463 113 286 464 minecraft:sea_lantern
fill 113 286 465 113 298 465 minecraft:deepslate_bricks
setblock 113 286 466 minecraft:sea_lantern
fill 113 286 467 113 298 467 minecraft:deepslate_bricks
setblock 113 286 468 minecraft:sea_lantern
fill 113 286 469 113 298 469 minecraft:deepslate_bricks
setblock 113 286 470 minecraft:sea_lantern
fill 114 286 463 116 291 463 minecraft:sea_lantern
fill 114 286 464 114 298 464 minecraft:deepslate_bricks
setblock 114 286 465 minecraft:sea_lantern
fill 114 286 466 114 298 466 minecraft:deepslate_bricks
setblock 114 286 467 minecraft:sea_lantern
fill 114 286 468 114 298 468 minecraft:deepslate_bricks
setblock 114 286 469 minecraft:sea_lantern
fill 114 286 470 114 298 470 minecraft:deepslate_bricks
fill 118 286 505 121 291 505 minecraft:sea_lantern
fill 125 286 463 128 291 463 minecraft:sea_lantern
fill 130 286 505 133 291 505 minecraft:sea_lantern
fill 136 286 464 136 291 467 minecraft:sea_lantern
fill 136 286 476 136 291 479 minecraft:sea_lantern
fill 136 286 488 136 291 491 minecraft:sea_lantern
fill 136 286 500 136 291 503 minecraft:sea_lantern
setblock 97 287 466 minecraft:light[level=11]
setblock 97 287 474 minecraft:light[level=11]
setblock 97 287 482 minecraft:light[level=11]
setblock 97 287 490 minecraft:light[level=11]
setblock 97 287 498 minecraft:light[level=11]
fill 104 287 465 104 288 465 minecraft:deepslate_bricks
fill 104 287 467 104 288 467 minecraft:deepslate_bricks
fill 104 287 469 104 288 469 minecraft:deepslate_bricks
fill 105 287 464 105 288 464 minecraft:deepslate_bricks
fill 105 287 466 105 288 466 minecraft:deepslate_bricks
fill 105 287 468 105 288 468 minecraft:deepslate_bricks
fill 105 287 470 105 288 470 minecraft:deepslate_bricks
setblock 105 287 474 minecraft:light[level=11]
setblock 105 287 482 minecraft:light[level=11]
setblock 105 287 490 minecraft:light[level=11]
setblock 105 287 498 minecraft:light[level=11]
fill 106 287 465 106 288 465 minecraft:deepslate_bricks
fill 106 287 467 106 288 467 minecraft:deepslate_bricks
fill 106 287 469 106 288 469 minecraft:deepslate_bricks
fill 107 287 464 107 288 464 minecraft:deepslate_bricks
fill 107 287 466 107 288 466 minecraft:deepslate_bricks
fill 107 287 468 107 288 468 minecraft:deepslate_bricks
fill 107 287 470 107 288 470 minecraft:deepslate_bricks
fill 108 287 465 108 288 465 minecraft:deepslate_bricks
fill 108 287 467 108 288 467 minecraft:deepslate_bricks
fill 108 287 469 108 288 469 minecraft:deepslate_bricks
fill 109 287 464 109 288 464 minecraft:deepslate_bricks
fill 109 287 466 109 288 466 minecraft:deepslate_bricks
fill 109 287 468 109 288 468 minecraft:deepslate_bricks
fill 109 287 470 109 288 470 minecraft:deepslate_bricks
fill 110 287 465 110 288 465 minecraft:deepslate_bricks
fill 110 287 467 110 288 467 minecraft:deepslate_bricks
fill 110 287 469 110 288 469 minecraft:deepslate_bricks
fill 111 287 464 111 288 464 minecraft:deepslate_bricks
fill 111 287 466 111 288 466 minecraft:deepslate_bricks
fill 111 287 468 111 288 468 minecraft:deepslate_bricks
fill 111 287 470 111 288 470 minecraft:deepslate_bricks
fill 112 287 465 112 288 465 minecraft:deepslate_bricks
fill 112 287 467 112 288 467 minecraft:deepslate_bricks
fill 112 287 469 112 288 469 minecraft:deepslate_bricks
fill 113 287 463 113 291 463 minecraft:sea_lantern
fill 113 287 464 113 288 464 minecraft:deepslate_bricks
fill 113 287 466 113 288 466 minecraft:deepslate_bricks
fill 113 287 468 113 288 468 minecraft:deepslate_bricks
fill 113 287 470 113 288 470 minecraft:deepslate_bricks
setblock 113 287 474 minecraft:light[level=11]
setblock 113 287 482 minecraft:light[level=11]
setblock 113 287 490 minecraft:light[level=11]
setblock 113 287 498 minecraft:light[level=11]
fill 114 287 465 114 288 465 minecraft:deepslate_bricks
fill 114 287 467 114 288 467 minecraft:deepslate_bricks
fill 114 287 469 114 288 469 minecraft:deepslate_bricks
setblock 121 287 466 minecraft:light[level=11]
setblock 121 287 474 minecraft:light[level=11]
setblock 121 287 482 minecraft:light[level=11]
setblock 121 287 490 minecraft:light[level=11]
setblock 121 287 498 minecraft:light[level=11]
setblock 129 287 466 minecraft:light[level=11]
setblock 129 287 474 minecraft:light[level=11]
setblock 129 287 482 minecraft:light[level=11]
setblock 129 287 490 minecraft:light[level=11]
setblock 129 287 498 minecraft:light[level=11]
setblock 104 289 465 minecraft:sea_lantern
setblock 104 289 467 minecraft:sea_lantern
setblock 104 289 469 minecraft:sea_lantern
setblock 105 289 464 minecraft:sea_lantern
setblock 105 289 466 minecraft:sea_lantern
setblock 105 289 468 minecraft:sea_lantern
setblock 105 289 470 minecraft:sea_lantern
setblock 106 289 465 minecraft:sea_lantern
setblock 106 289 467 minecraft:sea_lantern
setblock 106 289 469 minecraft:sea_lantern
setblock 107 289 464 minecraft:sea_lantern
setblock 107 289 466 minecraft:sea_lantern
setblock 107 289 468 minecraft:sea_lantern
setblock 107 289 470 minecraft:sea_lantern
setblock 108 289 465 minecraft:sea_lantern
setblock 108 289 467 minecraft:sea_lantern
setblock 108 289 469 minecraft:sea_lantern
setblock 109 289 464 minecraft:sea_lantern
setblock 109 289 466 minecraft:sea_lantern
setblock 109 289 468 minecraft:sea_lantern
setblock 109 289 470 minecraft:sea_lantern
setblock 110 289 465 minecraft:sea_lantern
setblock 110 289 467 minecraft:sea_lantern
setblock 110 289 469 minecraft:sea_lantern
setblock 111 289 464 minecraft:sea_lantern
setblock 111 289 466 minecraft:sea_lantern
setblock 111 289 468 minecraft:sea_lantern
setblock 111 289 470 minecraft:sea_lantern
setblock 112 289 465 minecraft:sea_lantern
setblock 112 289 467 minecraft:sea_lantern
setblock 112 289 469 minecraft:sea_lantern
setblock 113 289 464 minecraft:sea_lantern
setblock 113 289 466 minecraft:sea_lantern
setblock 113 289 468 minecraft:sea_lantern
setblock 113 289 470 minecraft:sea_lantern
setblock 114 289 465 minecraft:sea_lantern
setblock 114 289 467 minecraft:sea_lantern
setblock 114 289 469 minecraft:sea_lantern
fill 104 290 465 104 291 465 minecraft:deepslate_bricks
fill 104 290 467 104 291 467 minecraft:deepslate_bricks
fill 104 290 469 104 291 469 minecraft:deepslate_bricks
fill 105 290 464 105 291 464 minecraft:deepslate_bricks
fill 105 290 466 105 291 466 minecraft:deepslate_bricks
fill 105 290 468 105 291 468 minecraft:deepslate_bricks
fill 105 290 470 105 291 470 minecraft:deepslate_bricks
fill 106 290 465 106 291 465 minecraft:deepslate_bricks
fill 106 290 467 106 291 467 minecraft:deepslate_bricks
fill 106 290 469 106 291 469 minecraft:deepslate_bricks
fill 107 290 464 107 291 464 minecraft:deepslate_bricks
fill 107 290 466 107 291 466 minecraft:deepslate_bricks
fill 107 290 468 107 291 468 minecraft:deepslate_bricks
fill 107 290 470 107 291 470 minecraft:deepslate_bricks
fill 108 290 465 108 291 465 minecraft:deepslate_bricks
fill 108 290 467 108 291 467 minecraft:deepslate_bricks
fill 108 290 469 108 291 469 minecraft:deepslate_bricks
fill 109 290 464 109 291 464 minecraft:deepslate_bricks
fill 109 290 466 109 291 466 minecraft:deepslate_bricks
fill 109 290 468 109 291 468 minecraft:deepslate_bricks
fill 109 290 470 109 291 470 minecraft:deepslate_bricks
fill 110 290 465 110 291 465 minecraft:deepslate_bricks
fill 110 290 467 110 291 467 minecraft:deepslate_bricks
fill 110 290 469 110 291 469 minecraft:deepslate_bricks
fill 111 290 464 111 291 464 minecraft:deepslate_bricks
fill 111 290 466 111 291 466 minecraft:deepslate_bricks
fill 111 290 468 111 291 468 minecraft:deepslate_bricks
fill 111 290 470 111 291 470 minecraft:deepslate_bricks
fill 112 290 465 112 291 465 minecraft:deepslate_bricks
fill 112 290 467 112 291 467 minecraft:deepslate_bricks
fill 112 290 469 112 291 469 minecraft:deepslate_bricks
fill 113 290 464 113 291 464 minecraft:deepslate_bricks
fill 113 290 466 113 291 466 minecraft:deepslate_bricks
fill 113 290 468 113 291 468 minecraft:deepslate_bricks
fill 113 290 470 113 291 470 minecraft:deepslate_bricks
fill 114 290 465 114 291 465 minecraft:deepslate_bricks
fill 114 290 467 114 291 467 minecraft:deepslate_bricks
fill 114 290 469 114 291 469 minecraft:deepslate_bricks
fill 94 292 469 94 307 469 minecraft:deepslate_tiles
fill 94 292 470 94 292 471 minecraft:sea_lantern
fill 94 292 472 94 307 472 minecraft:deepslate_tiles
fill 94 292 481 94 307 481 minecraft:deepslate_tiles
fill 94 292 482 94 292 483 minecraft:sea_lantern
fill 94 292 484 94 307 484 minecraft:deepslate_tiles
fill 94 292 493 94 307 493 minecraft:deepslate_tiles
fill 94 292 494 94 292 495 minecraft:sea_lantern
fill 94 292 496 94 307 496 minecraft:deepslate_tiles
fill 94 292 505 94 307 505 minecraft:deepslate_tiles
fill 95 292 505 96 292 505 minecraft:sea_lantern
fill 97 292 505 97 307 505 minecraft:deepslate_tiles
fill 101 292 463 101 307 463 minecraft:deepslate_tiles
fill 102 292 463 103 292 463 minecraft:sea_lantern
fill 104 292 463 104 307 463 minecraft:deepslate_tiles
setblock 104 292 465 minecraft:sea_lantern
setblock 104 292 467 minecraft:sea_lantern
setblock 104 292 469 minecraft:sea_lantern
setblock 105 292 464 minecraft:sea_lantern
setblock 105 292 466 minecraft:sea_lantern
setblock 105 292 468 minecraft:sea_lantern
setblock 105 292 470 minecraft:sea_lantern
setblock 106 292 465 minecraft:sea_lantern
setblock 106 292 467 minecraft:sea_lantern
setblock 106 292 469 minecraft:sea_lantern
fill 106 292 505 106 307 505 minecraft:deepslate_tiles
setblock 107 292 464 minecraft:sea_lantern
setblock 107 292 466 minecraft:sea_lantern
setblock 107 292 468 minecraft:sea_lantern
setblock 107 292 470 minecraft:sea_lantern
fill 107 292 505 108 292 505 minecraft:sea_lantern
setblock 108 292 465 minecraft:sea_lantern
setblock 108 292 467 minecraft:sea_lantern
setblock 108 292 469 minecraft:sea_lantern
setblock 109 292 464 minecraft:sea_lantern
setblock 109 292 466 minecraft:sea_lantern
setblock 109 292 468 minecraft:sea_lantern
setblock 109 292 470 minecraft:sea_lantern
fill 109 292 505 109 307 505 minecraft:deepslate_tiles
setblock 110 292 465 minecraft:sea_lantern
setblock 110 292 467 minecraft:sea_lantern
setblock 110 292 469 minecraft:sea_lantern
setblock 111 292 464 minecraft:sea_lantern
setblock 111 292 466 minecraft:sea_lantern
setblock 111 292 468 minecraft:sea_lantern
setblock 111 292 470 minecraft:sea_lantern
setblock 112 292 465 minecraft:sea_lantern
setblock 112 292 467 minecraft:sea_lantern
setblock 112 292 469 minecraft:sea_lantern
fill 113 292 463 113 307 463 minecraft:deepslate_tiles
setblock 113 292 464 minecraft:sea_lantern
setblock 113 292 466 minecraft:sea_lantern
setblock 113 292 468 minecraft:sea_lantern
setblock 113 292 470 minecraft:sea_lantern
fill 114 292 463 115 292 463 minecraft:sea_lantern
setblock 114 292 465 minecraft:sea_lantern
setblock 114 292 467 minecraft:sea_lantern
setblock 114 292 469 minecraft:sea_lantern
fill 116 292 463 116 307 463 minecraft:deepslate_tiles
fill 118 292 505 118 307 505 minecraft:deepslate_tiles
fill 119 292 505 120 292 505 minecraft:sea_lantern
fill 121 292 505 121 307 505 minecraft:deepslate_tiles
fill 125 292 463 125 307 463 minecraft:deepslate_tiles
fill 126 292 463 127 292 463 minecraft:sea_lantern
fill 128 292 463 128 307 463 minecraft:deepslate_tiles
fill 130 292 505 130 307 505 minecraft:deepslate_tiles
fill 131 292 505 132 292 505 minecraft:sea_lantern
fill 133 292 505 133 307 505 minecraft:deepslate_tiles
fill 136 292 464 136 307 464 minecraft:deepslate_tiles
fill 136 292 465 136 292 466 minecraft:sea_lantern
fill 136 292 467 136 307 467 minecraft:deepslate_tiles
fill 136 292 476 136 307 476 minecraft:deepslate_tiles
fill 136 292 477 136 292 478 minecraft:sea_lantern
fill 136 292 479 136 307 479 minecraft:deepslate_tiles
fill 136 292 488 136 307 488 minecraft:deepslate_tiles
fill 136 292 489 136 292 490 minecraft:sea_lantern
fill 136 292 491 136 307 491 minecraft:deepslate_tiles
fill 136 292 500 136 307 500 minecraft:deepslate_tiles
fill 136 292 501 136 292 502 minecraft:sea_lantern
fill 136 292 503 136 307 503 minecraft:deepslate_tiles
fill 94 293 470 94 307 471 minecraft:deepslate_tiles
fill 94 293 482 94 307 483 minecraft:deepslate_tiles
fill 94 293 494 94 307 495 minecraft:deepslate_tiles
fill 95 293 505 96 307 505 minecraft:deepslate_tiles
fill 102 293 463 103 307 463 minecraft:deepslate_tiles
fill 104 293 465 104 294 465 minecraft:deepslate_bricks
fill 104 293 467 104 294 467 minecraft:deepslate_bricks
fill 104 293 469 104 294 469 minecraft:deepslate_bricks
fill 105 293 464 105 294 464 minecraft:deepslate_bricks
fill 105 293 466 105 294 466 minecraft:deepslate_bricks
fill 105 293 468 105 294 468 minecraft:deepslate_bricks
fill 105 293 470 105 294 470 minecraft:deepslate_bricks
fill 106 293 465 106 294 465 minecraft:deepslate_bricks
fill 106 293 467 106 294 467 minecraft:deepslate_bricks
fill 106 293 469 106 294 469 minecraft:deepslate_bricks
fill 107 293 464 107 294 464 minecraft:deepslate_bricks
fill 107 293 466 107 294 466 minecraft:deepslate_bricks
fill 107 293 468 107 294 468 minecraft:deepslate_bricks
fill 107 293 470 107 294 470 minecraft:deepslate_bricks
fill 107 293 505 108 307 505 minecraft:deepslate_tiles
fill 108 293 465 108 294 465 minecraft:deepslate_bricks
fill 108 293 467 108 294 467 minecraft:deepslate_bricks
fill 108 293 469 108 294 469 minecraft:deepslate_bricks
fill 109 293 464 109 294 464 minecraft:deepslate_bricks
fill 109 293 466 109 294 466 minecraft:deepslate_bricks
fill 109 293 468 109 294 468 minecraft:deepslate_bricks
fill 109 293 470 109 294 470 minecraft:deepslate_bricks
fill 110 293 465 110 294 465 minecraft:deepslate_bricks
fill 110 293 467 110 294 467 minecraft:deepslate_bricks
fill 110 293 469 110 294 469 minecraft:deepslate_bricks
fill 111 293 464 111 294 464 minecraft:deepslate_bricks
fill 111 293 466 111 294 466 minecraft:deepslate_bricks
fill 111 293 468 111 294 468 minecraft:deepslate_bricks
fill 111 293 470 111 294 470 minecraft:deepslate_bricks
fill 112 293 465 112 294 465 minecraft:deepslate_bricks
fill 112 293 467 112 294 467 minecraft:deepslate_bricks
fill 112 293 469 112 294 469 minecraft:deepslate_bricks
fill 113 293 464 113 294 464 minecraft:deepslate_bricks
fill 113 293 466 113 294 466 minecraft:deepslate_bricks
fill 113 293 468 113 294 468 minecraft:deepslate_bricks
fill 113 293 470 113 294 470 minecraft:deepslate_bricks
fill 114 293 463 115 307 463 minecraft:deepslate_tiles
fill 114 293 465 114 294 465 minecraft:deepslate_bricks
fill 114 293 467 114 294 467 minecraft:deepslate_bricks
fill 114 293 469 114 294 469 minecraft:deepslate_bricks
fill 119 293 505 120 307 505 minecraft:deepslate_tiles
fill 126 293 463 127 307 463 minecraft:deepslate_tiles
fill 131 293 505 132 307 505 minecraft:deepslate_tiles
fill 136 293 465 136 307 466 minecraft:deepslate_tiles
fill 136 293 477 136 307 478 minecraft:deepslate_tiles
fill 136 293 489 136 307 490 minecraft:deepslate_tiles
fill 136 293 501 136 307 502 minecraft:deepslate_tiles
fill 95 294 469 96 296 471 minecraft:cyan_stained_glass
fill 97 294 470 102 295 470 minecraft:cyan_stained_glass
fill 134 294 489 134 297 489 minecraft:cyan_stained_glass
setblock 97 295 466 minecraft:light[level=11]
fill 97 295 469 99 295 469 minecraft:cyan_stained_glass
fill 97 295 471 99 295 471 minecraft:cyan_stained_glass
setblock 97 295 474 minecraft:light[level=11]
setblock 97 295 482 minecraft:light[level=11]
setblock 97 295 490 minecraft:light[level=11]
setblock 97 295 498 minecraft:light[level=11]
setblock 104 295 465 minecraft:sea_lantern
setblock 104 295 467 minecraft:sea_lantern
setblock 104 295 469 minecraft:sea_lantern
setblock 105 295 464 minecraft:sea_lantern
setblock 105 295 466 minecraft:sea_lantern
setblock 105 295 468 minecraft:sea_lantern
setblock 105 295 470 minecraft:sea_lantern
setblock 105 295 474 minecraft:light[level=11]
setblock 105 295 482 minecraft:light[level=11]
setblock 105 295 490 minecraft:light[level=11]
setblock 105 295 498 minecraft:light[level=11]
setblock 106 295 465 minecraft:sea_lantern
setblock 106 295 467 minecraft:sea_lantern
setblock 106 295 469 minecraft:sea_lantern
setblock 107 295 464 minecraft:sea_lantern
setblock 107 295 466 minecraft:sea_lantern
setblock 107 295 468 minecraft:sea_lantern
setblock 107 295 470 minecraft:sea_lantern
setblock 108 295 465 minecraft:sea_lantern
setblock 108 295 467 minecraft:sea_lantern
setblock 108 295 469 minecraft:sea_lantern
setblock 109 295 464 minecraft:sea_lantern
setblock 109 295 466 minecraft:sea_lantern
setblock 109 295 468 minecraft:sea_lantern
setblock 109 295 470 minecraft:sea_lantern
setblock 110 295 465 minecraft:sea_lantern
setblock 110 295 467 minecraft:sea_lantern
setblock 110 295 469 minecraft:sea_lantern
setblock 111 295 464 minecraft:sea_lantern
setblock 111 295 466 minecraft:sea_lantern
setblock 111 295 468 minecraft:sea_lantern
setblock 111 295 470 minecraft:sea_lantern
setblock 112 295 465 minecraft:sea_lantern
setblock 112 295 467 minecraft:sea_lantern
setblock 112 295 469 minecraft:sea_lantern
setblock 113 295 464 minecraft:sea_lantern
setblock 113 295 466 minecraft:sea_lantern
setblock 113 295 468 minecraft:sea_lantern
setblock 113 295 470 minecraft:sea_lantern
setblock 113 295 474 minecraft:light[level=11]
setblock 113 295 482 minecraft:light[level=11]
setblock 113 295 490 minecraft:light[level=11]
setblock 113 295 498 minecraft:light[level=11]
setblock 114 295 465 minecraft:sea_lantern
setblock 114 295 467 minecraft:sea_lantern
setblock 114 295 469 minecraft:sea_lantern
setblock 121 295 466 minecraft:light[level=11]
setblock 121 295 474 minecraft:light[level=11]
setblock 121 295 482 minecraft:light[level=11]
setblock 121 295 490 minecraft:light[level=11]
setblock 121 295 498 minecraft:light[level=11]
setblock 129 295 466 minecraft:light[level=11]
setblock 129 295 474 minecraft:light[level=11]
setblock 129 295 482 minecraft:light[level=11]
setblock 129 295 490 minecraft:light[level=11]
setblock 129 295 498 minecraft:light[level=11]
fill 131 295 489 133 297 489 minecraft:cyan_stained_glass
fill 132 295 488 135 296 488 minecraft:cyan_stained_glass
fill 132 295 490 135 296 490 minecraft:cyan_stained_glass
fill 135 295 489 135 296 489 minecraft:cyan_stained_glass
fill 97 296 469 98 296 471 minecraft:cyan_stained_glass
setblock 99 296 470 minecraft:cyan_stained_glass
fill 104 296 465 104 298 465 minecraft:deepslate_bricks
fill 104 296 467 104 298 467 minecraft:deepslate_bricks
fill 104 296 469 104 298 469 minecraft:deepslate_bricks
fill 105 296 464 105 298 464 minecraft:deepslate_bricks
fill 105 296 466 105 298 466 minecraft:deepslate_bricks
fill 105 296 468 105 298 468 minecraft:deepslate_bricks
fill 105 296 470 105 298 470 minecraft:deepslate_bricks
fill 106 296 465 106 298 465 minecraft:deepslate_bricks
fill 106 296 467 106 298 467 minecraft:deepslate_bricks
fill 106 296 469 106 298 469 minecraft:deepslate_bricks
fill 107 296 464 107 300 464 minecraft:deepslate_bricks
fill 107 296 466 107 298 466 minecraft:deepslate_bricks
fill 107 296 468 107 298 468 minecraft:deepslate_bricks
fill 107 296 470 107 298 470 minecraft:deepslate_bricks
fill 108 296 465 108 298 465 minecraft:deepslate_bricks
fill 108 296 467 108 298 467 minecraft:deepslate_bricks
fill 108 296 469 108 298 469 minecraft:deepslate_bricks
fill 109 296 464 109 300 464 minecraft:deepslate_bricks
fill 109 296 466 109 298 466 minecraft:deepslate_bricks
fill 109 296 468 109 298 468 minecraft:deepslate_bricks
fill 109 296 470 109 298 470 minecraft:deepslate_bricks
fill 110 296 465 110 298 465 minecraft:deepslate_bricks
fill 110 296 467 110 298 467 minecraft:deepslate_bricks
fill 110 296 469 110 298 469 minecraft:deepslate_bricks
fill 111 296 464 111 298 464 minecraft:deepslate_bricks
fill 111 296 466 111 298 466 minecraft:deepslate_bricks
fill 111 296 468 111 298 468 minecraft:deepslate_bricks
fill 111 296 470 111 298 470 minecraft:deepslate_bricks
fill 112 296 465 112 298 465 minecraft:deepslate_bricks
fill 112 296 467 112 298 467 minecraft:deepslate_bricks
fill 112 296 469 112 298 469 minecraft:deepslate_bricks
fill 113 296 464 113 298 464 minecraft:deepslate_bricks
fill 113 296 466 113 298 466 minecraft:deepslate_bricks
fill 113 296 468 113 298 468 minecraft:deepslate_bricks
fill 113 296 470 113 298 470 minecraft:deepslate_bricks
fill 114 296 465 114 298 465 minecraft:deepslate_bricks
fill 114 296 467 114 298 467 minecraft:deepslate_bricks
fill 114 296 469 114 298 469 minecraft:deepslate_bricks
fill 129 296 489 130 297 489 minecraft:cyan_stained_glass
fill 130 296 488 131 296 488 minecraft:cyan_stained_glass
fill 130 296 490 131 296 490 minecraft:cyan_stained_glass
fill 95 297 469 95 297 471 minecraft:cyan_stained_glass
setblock 96 297 470 minecraft:cyan_stained_glass
setblock 128 297 489 minecraft:cyan_stained_glass
fill 105 299 465 113 299 469 minecraft:cyan_concrete
fill 96 300 473 96 300 475 minecraft:deepslate_bricks
fill 96 300 485 96 300 487 minecraft:deepslate_bricks
fill 96 300 497 96 300 499 minecraft:deepslate_bricks
fill 102 300 503 104 300 503 minecraft:deepslate_bricks
fill 106 300 465 108 300 465 minecraft:deepslate_bricks
fill 106 300 466 112 300 468 minecraft:cyan_concrete
fill 114 300 503 116 300 503 minecraft:deepslate_bricks
fill 118 300 465 120 300 465 minecraft:deepslate_bricks
fill 126 300 503 128 300 503 minecraft:deepslate_bricks
fill 130 300 465 132 300 465 minecraft:deepslate_bricks
fill 134 300 473 134 300 475 minecraft:deepslate_bricks
fill 134 300 485 134 300 487 minecraft:deepslate_bricks
fill 134 300 497 134 300 499 minecraft:deepslate_bricks
setblock 97 303 466 minecraft:light[level=11]
setblock 97 303 474 minecraft:light[level=11]
setblock 97 303 482 minecraft:light[level=11]
setblock 97 303 490 minecraft:light[level=11]
setblock 97 303 498 minecraft:light[level=11]
setblock 105 303 466 minecraft:light[level=11]
setblock 105 303 474 minecraft:light[level=11]
setblock 105 303 482 minecraft:light[level=11]
setblock 105 303 490 minecraft:light[level=11]
setblock 105 303 498 minecraft:light[level=11]
setblock 113 303 466 minecraft:light[level=11]
setblock 113 303 474 minecraft:light[level=11]
setblock 113 303 482 minecraft:light[level=11]
setblock 113 303 490 minecraft:light[level=11]
setblock 113 303 498 minecraft:light[level=11]
setblock 121 303 466 minecraft:light[level=11]
setblock 121 303 474 minecraft:light[level=11]
setblock 121 303 482 minecraft:light[level=11]
setblock 121 303 490 minecraft:light[level=11]
setblock 121 303 498 minecraft:light[level=11]
setblock 129 303 466 minecraft:light[level=11]
setblock 129 303 474 minecraft:light[level=11]
setblock 129 303 482 minecraft:light[level=11]
setblock 129 303 490 minecraft:light[level=11]
setblock 129 303 498 minecraft:light[level=11]
