fill 288 184 240 288 194 240 minecraft:basalt
fill 288 184 264 288 194 264 minecraft:basalt
setblock 288 184 265 minecraft:magma_block
fill 288 184 267 290 191 267 minecraft:basalt
setblock 288 184 268 minecraft:magma_block
fill 289 184 232 296 187 232 minecraft:basalt
fill 289 184 235 296 190 235 minecraft:basalt
fill 289 184 238 290 192 238 minecraft:basalt
fill 289 184 265 289 193 265 minecraft:basalt
fill 289 184 268 296 191 268 minecraft:basalt
fill 290 184 229 296 184 229 minecraft:basalt
setblock 291 184 231 minecraft:magma_block
setblock 291 184 234 minecraft:magma_block
setblock 291 184 237 minecraft:magma_block
setblock 291 184 267 minecraft:magma_block
fill 292 184 231 299 187 231 minecraft:basalt
fill 292 184 234 299 190 234 minecraft:basalt
fill 292 184 237 292 193 237 minecraft:basalt
fill 292 184 251 292 184 253 minecraft:magma_block
fill 292 184 267 292 193 267 minecraft:basalt
setblock 293 184 249 minecraft:magma_block
fill 293 184 250 293 184 254 minecraft:shroomlight
setblock 293 184 255 minecraft:magma_block
setblock 294 184 230 minecraft:magma_block
setblock 294 184 233 minecraft:magma_block
setblock 294 184 236 minecraft:magma_block
setblock 294 184 247 minecraft:magma_block
fill 294 184 248 294 184 250 minecraft:shroomlight
fill 294 184 251 294 184 253 minecraft:magma_block
fill 294 184 254 294 184 256 minecraft:shroomlight
setblock 294 184 257 minecraft:magma_block
setblock 294 184 269 minecraft:magma_block
fill 295 184 230 302 185 230 minecraft:basalt
fill 295 184 233 302 189 233 minecraft:basalt
fill 295 184 236 296 193 236 minecraft:basalt
fill 295 184 247 295 184 248 minecraft:shroomlight
setblock 295 184 251 minecraft:basalt
fill 295 184 253 295 184 254 minecraft:basalt
fill 295 184 256 295 184 257 minecraft:shroomlight
fill 295 184 269 302 192 269 minecraft:basalt
setblock 296 184 246 minecraft:magma_block
fill 296 184 247 297 184 247 minecraft:shroomlight
setblock 296 184 248 minecraft:magma_block
setblock 296 184 250 minecraft:basalt
fill 296 184 254 296 184 255 minecraft:basalt
setblock 296 184 256 minecraft:magma_block
fill 296 184 257 297 184 257 minecraft:shroomlight
setblock 296 184 258 minecraft:magma_block
setblock 297 184 229 minecraft:magma_block
setblock 297 184 232 minecraft:magma_block
setblock 297 184 235 minecraft:magma_block
fill 297 184 246 301 184 246 minecraft:shroomlight
setblock 297 184 249 minecraft:basalt
fill 297 184 255 297 184 256 minecraft:basalt
fill 297 184 258 301 184 258 minecraft:shroomlight
fill 298 184 229 305 185 229 minecraft:basalt
fill 298 184 232 305 188 232 minecraft:basalt
fill 298 184 235 305 190 235 minecraft:basalt
fill 298 184 247 300 184 247 minecraft:magma_block
fill 298 184 257 300 184 257 minecraft:magma_block
setblock 300 184 231 minecraft:magma_block
setblock 300 184 234 minecraft:magma_block
fill 300 184 270 301 198 270 minecraft:blackstone
fill 301 184 231 308 186 231 minecraft:basalt
fill 301 184 234 308 189 234 minecraft:basalt
fill 301 184 247 303 184 247 minecraft:shroomlight
setblock 301 184 249 minecraft:basalt
fill 301 184 257 303 184 257 minecraft:shroomlight
fill 302 184 236 302 194 236 minecraft:basalt
setblock 302 184 246 minecraft:magma_block
setblock 302 184 248 minecraft:magma_block
setblock 302 184 250 minecraft:basalt
setblock 302 184 256 minecraft:magma_block
setblock 302 184 258 minecraft:magma_block
fill 302 184 268 305 184 268 minecraft:basalt
setblock 302 184 270 minecraft:shroomlight
setblock 303 184 230 minecraft:magma_block
setblock 303 184 233 minecraft:magma_block
setblock 303 184 236 minecraft:magma_block
fill 303 184 248 304 184 248 minecraft:shroomlight
setblock 303 184 249 minecraft:magma_block
setblock 303 184 255 minecraft:magma_block
fill 303 184 256 304 184 256 minecraft:shroomlight
setblock 303 184 269 minecraft:magma_block
fill 304 184 230 311 184 230 minecraft:basalt
fill 304 184 233 311 186 233 minecraft:basalt
fill 304 184 236 311 189 236 minecraft:basalt
setblock 304 184 247 minecraft:magma_block
fill 304 184 249 304 184 250 minecraft:shroomlight
fill 304 184 251 304 184 253 minecraft:magma_block
fill 304 184 254 304 184 255 minecraft:shroomlight
setblock 304 184 257 minecraft:magma_block
fill 304 184 269 311 188 269 minecraft:basalt
setblock 305 184 249 minecraft:magma_block
fill 305 184 250 305 184 254 minecraft:shroomlight
setblock 305 184 255 minecraft:magma_block
setblock 306 184 229 minecraft:magma_block
setblock 306 184 232 minecraft:magma_block
setblock 306 184 235 minecraft:magma_block
fill 306 184 237 308 192 237 minecraft:basalt
fill 306 184 267 308 192 267 minecraft:basalt
setblock 306 184 268 minecraft:magma_block
fill 307 184 229 308 184 229 minecraft:basalt
fill 307 184 232 314 184 232 minecraft:basalt
fill 307 184 235 314 186 235 minecraft:basalt
fill 307 184 268 314 187 268 minecraft:basalt
fill 308 184 238 314 189 238 minecraft:basalt
fill 308 184 266 311 190 266 minecraft:basalt
setblock 309 184 231 minecraft:magma_block
setblock 309 184 234 minecraft:magma_block
setblock 309 184 237 minecraft:magma_block
fill 309 184 239 311 192 239 minecraft:basalt
fill 309 184 265 314 189 265 minecraft:basalt
setblock 309 184 267 minecraft:magma_block
fill 310 184 231 312 184 231 minecraft:basalt
fill 310 184 234 316 184 234 minecraft:basalt
fill 310 184 237 317 185 237 minecraft:basalt
fill 310 184 240 317 187 240 minecraft:basalt
fill 310 184 264 317 187 264 minecraft:basalt
fill 310 184 267 317 185 267 minecraft:basalt
fill 311 184 241 314 184 241 minecraft:basalt
fill 311 184 263 311 194 263 minecraft:basalt
setblock 312 184 233 minecraft:magma_block
setblock 312 184 236 minecraft:magma_block
setblock 312 184 239 minecraft:magma_block
setblock 312 184 242 minecraft:magma_block
fill 312 184 262 314 192 262 minecraft:basalt
setblock 312 184 263 minecraft:magma_block
setblock 312 184 266 minecraft:magma_block
setblock 312 184 269 minecraft:magma_block
fill 313 184 233 315 184 233 minecraft:basalt
fill 313 184 236 318 184 236 minecraft:basalt
fill 313 184 239 320 184 239 minecraft:basalt
fill 313 184 242 317 189 243 minecraft:basalt
fill 313 184 261 317 189 261 minecraft:basalt
fill 313 184 263 320 185 263 minecraft:basalt
fill 313 184 266 319 184 266 minecraft:basalt
fill 313 184 269 317 184 269 minecraft:basalt
fill 314 184 244 314 193 245 minecraft:basalt
fill 314 184 259 314 193 260 minecraft:basalt
setblock 314 184 270 minecraft:magma_block
setblock 315 184 235 minecraft:magma_block
setblock 315 184 238 minecraft:magma_block
setblock 315 184 241 minecraft:magma_block
setblock 315 184 244 minecraft:magma_block
fill 315 184 245 317 190 246 minecraft:basalt
setblock 315 184 247 minecraft:magma_block
fill 315 184 248 317 190 249 minecraft:basalt
fill 315 184 255 317 190 255 minecraft:basalt
setblock 315 184 256 minecraft:magma_block
fill 315 184 257 317 190 258 minecraft:basalt
setblock 315 184 259 minecraft:magma_block
fill 315 184 260 320 186 260 minecraft:basalt
setblock 315 184 262 minecraft:magma_block
setblock 315 184 265 minecraft:magma_block
setblock 315 184 268 minecraft:magma_block
fill 316 184 235 317 184 235 minecraft:basalt
fill 316 184 238 319 184 238 minecraft:basalt
fill 316 184 241 321 184 241 minecraft:basalt
fill 316 184 244 322 184 244 minecraft:basalt
fill 316 184 247 323 184 247 minecraft:basalt
fill 316 184 250 317 190 254 minecraft:basalt
fill 316 184 256 323 184 256 minecraft:basalt
fill 316 184 259 323 184 259 minecraft:basalt
fill 316 184 262 321 185 262 minecraft:basalt
fill 316 184 265 320 184 265 minecraft:basalt
fill 316 184 268 318 184 268 minecraft:basalt
setblock 318 184 237 minecraft:magma_block
setblock 318 184 240 minecraft:magma_block
fill 318 184 242 320 186 242 minecraft:basalt
setblock 318 184 243 minecraft:magma_block
fill 318 184 245 320 187 245 minecraft:basalt
setblock 318 184 246 minecraft:magma_block
fill 318 184 248 320 188 248 minecraft:basalt
setblock 318 184 249 minecraft:magma_block
fill 318 184 250 320 188 251 minecraft:basalt
setblock 318 184 252 minecraft:magma_block
fill 318 184 253 320 188 254 minecraft:basalt
setblock 318 184 255 minecraft:magma_block
fill 318 184 257 320 187 257 minecraft:basalt
setblock 318 184 258 minecraft:magma_block
setblock 318 184 261 minecraft:magma_block
setblock 318 184 264 minecraft:magma_block
setblock 318 184 267 minecraft:magma_block
setblock 319 184 237 minecraft:basalt
fill 319 184 240 321 184 240 minecraft:basalt
fill 319 184 243 322 184 243 minecraft:basalt
fill 319 184 246 323 184 246 minecraft:basalt
fill 319 184 249 323 184 249 minecraft:basalt
fill 319 184 252 323 184 252 minecraft:basalt
fill 319 184 255 323 184 255 minecraft:basalt
fill 319 184 258 323 184 258 minecraft:basalt
fill 319 184 261 322 184 261 minecraft:basalt
fill 319 184 264 321 184 264 minecraft:basalt
setblock 319 184 267 minecraft:basalt
setblock 321 184 242 minecraft:magma_block
setblock 321 184 245 minecraft:magma_block
setblock 321 184 248 minecraft:magma_block
fill 321 184 250 323 185 250 minecraft:basalt
setblock 321 184 251 minecraft:magma_block
fill 321 184 253 323 185 253 minecraft:basalt
setblock 321 184 254 minecraft:magma_block
setblock 321 184 257 minecraft:magma_block
setblock 321 184 260 minecraft:magma_block
setblock 321 184 263 minecraft:magma_block
fill 322 184 245 323 184 245 minecraft:basalt
fill 322 184 248 323 184 248 minecraft:basalt
fill 322 184 251 323 185 251 minecraft:basalt
fill 322 184 254 323 185 254 minecraft:basalt
fill 322 184 257 323 184 257 minecraft:basalt
setblock 322 184 260 minecraft:basalt
fill 282 185 236 282 215 239 minecraft:blackstone
setblock 282 185 240 minecraft:crying_obsidian
fill 282 185 241 282 198 242 minecraft:blackstone
fill 283 185 234 283 185 254 minecraft:basalt
fill 284 185 234 284 185 246 minecraft:basalt
setblock 284 185 247 minecraft:magma_block
fill 284 185 257 284 194 258 minecraft:basalt
setblock 285 185 233 minecraft:basalt
fill 285 185 236 285 188 236 minecraft:basalt
fill 285 185 239 285 190 239 minecraft:basalt
fill 285 185 242 285 192 242 minecraft:basalt
fill 285 185 244 285 194 245 minecraft:basalt
fill 285 185 259 285 194 260 minecraft:basalt
fill 285 185 263 285 192 263 minecraft:basalt
fill 285 185 266 285 190 266 minecraft:basalt
fill 285 185 269 285 187 269 minecraft:basalt
fill 286 185 232 288 185 232 minecraft:basalt
fill 286 185 243 286 194 243 minecraft:basalt
fill 286 185 261 286 194 261 minecraft:basalt
setblock 287 185 231 minecraft:magma_block
fill 287 185 242 287 194 242 minecraft:basalt
fill 287 185 262 287 194 262 minecraft:basalt
fill 288 185 231 291 185 231 minecraft:basalt
fill 288 185 235 288 189 235 minecraft:basalt
fill 288 185 238 288 192 238 minecraft:basalt
fill 288 185 265 288 192 265 minecraft:basalt
fill 288 185 268 288 190 268 minecraft:basalt
setblock 289 185 230 minecraft:basalt
fill 289 185 240 289 194 240 minecraft:basalt
fill 289 185 264 289 194 264 minecraft:basalt
setblock 290 185 230 minecraft:magma_block
setblock 290 185 239 minecraft:magma_block
fill 290 185 265 290 194 265 minecraft:basalt
fill 291 185 230 294 185 230 minecraft:basalt
fill 291 185 234 291 190 234 minecraft:basalt
fill 291 185 237 291 192 238 minecraft:basalt
fill 291 185 266 291 192 267 minecraft:basalt
setblock 292 185 229 minecraft:basalt
fill 292 185 238 292 194 238 minecraft:basalt
fill 292 185 266 292 194 266 minecraft:basalt
setblock 293 185 229 minecraft:magma_block
fill 293 185 237 294 194 237 minecraft:basalt
fill 293 185 267 294 194 267 minecraft:basalt
fill 293 185 270 293 196 270 minecraft:blackstone
fill 294 185 229 297 185 229 minecraft:basalt
fill 294 185 233 294 190 233 minecraft:basalt
fill 294 185 236 294 192 236 minecraft:basalt
fill 294 185 269 294 192 269 minecraft:basalt
setblock 294 185 270 minecraft:shroomlight
fill 297 185 232 297 189 232 minecraft:basalt
fill 297 185 235 297 192 236 minecraft:basalt
fill 297 185 268 301 194 268 minecraft:basalt
fill 298 185 236 298 194 236 minecraft:basalt
setblock 299 185 236 minecraft:magma_block
fill 300 185 231 300 188 231 minecraft:basalt
fill 300 185 234 300 192 234 minecraft:basalt
fill 300 185 236 301 194 236 minecraft:basalt
setblock 302 185 268 minecraft:magma_block
fill 302 185 270 302 235 270 minecraft:blackstone
fill 303 185 230 307 185 230 minecraft:basalt
fill 303 185 233 303 190 233 minecraft:basalt
fill 303 185 236 303 192 236 minecraft:basalt
fill 303 185 268 303 192 269 minecraft:basalt
fill 304 185 237 304 194 237 minecraft:basalt
fill 304 185 267 304 193 268 minecraft:basalt
setblock 305 185 237 minecraft:magma_block
setblock 305 185 267 minecraft:magma_block
fill 305 185 268 306 192 268 minecraft:basalt
setblock 306 185 229 minecraft:basalt
fill 306 185 232 310 186 232 minecraft:basalt
fill 306 185 235 306 191 235 minecraft:basalt
fill 306 185 238 307 194 238 minecraft:basalt
fill 306 185 266 307 194 266 minecraft:basalt
setblock 308 185 230 minecraft:magma_block
setblock 308 185 239 minecraft:magma_block
fill 308 185 265 308 194 265 minecraft:basalt
fill 309 185 230 309 185 231 minecraft:basalt
fill 309 185 234 313 186 234 minecraft:basalt
fill 309 185 237 309 192 237 minecraft:basalt
fill 309 185 240 309 194 240 minecraft:basalt
fill 309 185 264 309 194 264 minecraft:basalt
fill 309 185 267 309 192 267 minecraft:basalt
fill 310 185 231 311 185 231 minecraft:basalt
setblock 311 185 232 minecraft:magma_block
setblock 311 185 241 minecraft:magma_block
fill 311 185 242 312 192 242 minecraft:basalt
setblock 311 185 262 minecraft:magma_block
fill 312 185 232 312 185 233 minecraft:basalt
fill 312 185 236 316 185 236 minecraft:basalt
fill 312 185 239 319 185 239 minecraft:basalt
fill 312 185 241 319 186 241 minecraft:basalt
fill 312 185 243 312 194 243 minecraft:basalt
fill 312 185 261 312 194 261 minecraft:basalt
fill 312 185 263 312 192 263 minecraft:basalt
fill 312 185 266 318 185 266 minecraft:basalt
fill 312 185 269 316 185 269 minecraft:basalt
setblock 313 185 233 minecraft:basalt
fill 313 185 244 313 185 245 minecraft:basalt
fill 313 185 259 313 194 260 minecraft:basalt
setblock 314 185 234 minecraft:magma_block
setblock 314 185 246 minecraft:magma_block
fill 314 185 247 322 185 247 minecraft:basalt
fill 314 185 257 314 194 257 minecraft:basalt
setblock 314 185 258 minecraft:magma_block
fill 314 185 270 314 283 270 minecraft:blackstone
fill 315 185 234 315 185 235 minecraft:basalt
fill 315 185 238 318 185 238 minecraft:basalt
fill 315 185 244 321 185 244 minecraft:basalt
fill 315 185 250 315 194 254 minecraft:basalt
fill 315 185 256 322 185 256 minecraft:basalt
fill 315 185 259 322 185 259 minecraft:basalt
fill 315 185 262 315 191 262 minecraft:basalt
fill 315 185 265 319 185 265 minecraft:basalt
fill 315 185 268 317 185 268 minecraft:basalt
setblock 316 185 235 minecraft:basalt
setblock 317 185 236 minecraft:magma_block
fill 318 185 240 320 185 240 minecraft:basalt
fill 318 185 243 321 185 243 minecraft:basalt
fill 318 185 246 322 185 246 minecraft:basalt
fill 318 185 249 322 186 249 minecraft:basalt
fill 318 185 252 322 186 252 minecraft:basalt
fill 318 185 255 322 186 255 minecraft:basalt
fill 318 185 258 322 185 258 minecraft:basalt
fill 318 185 261 321 185 261 minecraft:basalt
fill 318 185 264 320 185 264 minecraft:basalt
setblock 320 185 241 minecraft:magma_block
setblock 321 185 242 minecraft:basalt
fill 321 185 245 322 185 245 minecraft:basalt
fill 321 185 248 322 185 248 minecraft:basalt
fill 321 185 251 321 187 251 minecraft:basalt
fill 321 185 254 321 187 254 minecraft:basalt
fill 321 185 257 322 185 257 minecraft:basalt
setblock 321 185 260 minecraft:basalt
setblock 323 185 249 minecraft:magma_block
setblock 323 185 252 minecraft:magma_block
setblock 323 185 255 minecraft:magma_block
fill 324 185 265 324 198 267 minecraft:blackstone
setblock 324 185 268 minecraft:magma_block
fill 282 186 240 282 265 240 minecraft:blackstone
fill 283 186 236 283 186 268 minecraft:basalt
fill 284 186 235 284 186 256 minecraft:basalt
fill 285 186 246 285 195 246 minecraft:basalt
fill 285 186 258 285 195 258 minecraft:basalt
setblock 286 186 233 minecraft:magma_block
fill 286 186 244 286 195 244 minecraft:basalt
setblock 286 186 260 minecraft:magma_block
fill 287 186 233 293 186 233 minecraft:basalt
fill 287 186 243 287 195 243 minecraft:basalt
fill 287 186 261 287 195 261 minecraft:basalt
setblock 288 186 232 minecraft:basalt
fill 288 186 241 288 194 241 minecraft:basalt
fill 288 186 263 288 194 263 minecraft:basalt
fill 289 186 231 291 186 231 minecraft:basalt
fill 290 186 239 290 193 240 minecraft:basalt
fill 290 186 264 290 195 264 minecraft:basalt
fill 291 186 239 291 195 239 minecraft:basalt
fill 291 186 265 291 195 265 minecraft:basalt
fill 292 186 230 294 186 230 minecraft:basalt
fill 293 186 238 293 195 238 minecraft:basalt
fill 293 186 266 293 195 266 minecraft:basalt
fill 294 186 270 294 283 270 minecraft:blackstone
setblock 295 186 230 minecraft:magma_block
fill 295 186 237 300 186 237 minecraft:basalt
fill 295 186 267 300 186 267 minecraft:basalt
fill 296 186 229 297 186 230 minecraft:basalt
setblock 298 186 229 minecraft:magma_block
fill 298 186 230 303 186 230 minecraft:basalt
fill 299 186 229 302 186 229 minecraft:basalt
fill 299 186 236 299 193 236 minecraft:basalt
setblock 301 186 237 minecraft:magma_block
setblock 301 186 267 minecraft:magma_block
fill 302 186 237 303 194 237 minecraft:basalt
fill 302 186 267 302 193 268 minecraft:basalt
fill 303 186 267 303 194 267 minecraft:basalt
setblock 304 186 230 minecraft:magma_block
fill 305 186 230 306 186 230 minecraft:basalt
fill 305 186 237 305 193 238 minecraft:basalt
fill 305 186 266 305 193 267 minecraft:basalt
fill 307 186 239 308 193 239 minecraft:basalt
setblock 307 186 265 minecraft:magma_block
fill 308 186 240 308 195 240 minecraft:basalt
fill 308 186 264 308 195 264 minecraft:basalt
fill 309 186 228 310 186 228 minecraft:blackstone
setblock 309 186 231 minecraft:basalt
fill 310 186 237 316 186 237 minecraft:basalt
fill 310 186 241 311 193 241 minecraft:basalt
fill 310 186 263 310 194 263 minecraft:basalt
fill 310 186 267 316 186 267 minecraft:basalt
setblock 311 186 228 minecraft:magma_block
fill 311 186 243 311 195 243 minecraft:basalt
fill 311 186 261 311 193 262 minecraft:basalt
setblock 312 186 228 minecraft:crying_obsidian
setblock 312 186 233 minecraft:basalt
fill 312 186 236 315 186 236 minecraft:basalt
fill 312 186 239 318 186 239 minecraft:basalt
fill 312 186 244 313 194 244 minecraft:basalt
fill 312 186 260 312 195 260 minecraft:basalt
fill 312 186 266 317 186 266 minecraft:basalt
fill 312 186 269 314 186 269 minecraft:basalt
fill 313 186 228 316 190 228 minecraft:blackstone
setblock 313 186 245 minecraft:magma_block
fill 313 186 246 314 193 246 minecraft:basalt
fill 313 186 258 314 193 258 minecraft:basalt
fill 313 186 263 319 186 263 minecraft:basalt
fill 314 186 247 314 194 256 minecraft:basalt
fill 315 186 238 317 186 238 minecraft:basalt
fill 315 186 244 320 186 244 minecraft:basalt
fill 315 186 247 321 186 247 minecraft:basalt
fill 315 186 256 321 186 256 minecraft:basalt
fill 315 186 259 321 186 259 minecraft:basalt
fill 315 186 265 318 186 265 minecraft:basalt
setblock 315 186 268 minecraft:basalt
fill 316 186 262 320 186 262 minecraft:basalt
fill 318 186 228 320 195 228 minecraft:blackstone
setblock 318 186 240 minecraft:basalt
fill 318 186 243 320 186 243 minecraft:basalt
fill 318 186 246 321 186 246 minecraft:basalt
fill 318 186 258 321 186 258 minecraft:basalt
fill 318 186 261 320 186 261 minecraft:basalt
setblock 318 186 264 minecraft:basalt
setblock 321 186 228 minecraft:magma_block
setblock 321 186 245 minecraft:basalt
fill 321 186 248 321 187 248 minecraft:basalt
fill 321 186 250 322 186 250 minecraft:basalt
fill 321 186 253 322 186 253 minecraft:basalt
setblock 321 186 257 minecraft:basalt
setblock 322 186 251 minecraft:magma_block
setblock 322 186 254 minecraft:magma_block
fill 324 186 268 324 283 268 minecraft:blackstone
fill 282 187 259 282 216 260 minecraft:blackstone
setblock 282 187 261 minecraft:magma_block
fill 282 187 262 282 194 263 minecraft:blackstone
fill 283 187 237 283 187 267 minecraft:basalt
fill 284 187 236 284 187 256 minecraft:basalt
fill 284 187 259 284 187 268 minecraft:basalt
setblock 285 187 235 minecraft:magma_block
setblock 285 187 247 minecraft:magma_block
fill 285 187 248 285 196 249 minecraft:basalt
setblock 285 187 253 minecraft:blackstone
fill 285 187 255 285 196 255 minecraft:basalt
setblock 285 187 256 minecraft:magma_block
fill 285 187 257 285 195 257 minecraft:basalt
fill 286 187 234 287 187 235 minecraft:basalt
fill 286 187 245 286 194 246 minecraft:basalt
fill 286 187 258 286 194 260 minecraft:basalt
fill 287 187 244 287 196 244 minecraft:basalt
setblock 287 187 260 minecraft:basalt
fill 288 187 233 293 187 233 minecraft:basalt
fill 288 187 242 288 195 242 minecraft:basalt
fill 288 187 262 288 195 262 minecraft:basalt
fill 289 187 241 289 194 241 minecraft:basalt
fill 289 187 263 289 195 263 minecraft:basalt
fill 291 187 240 291 196 240 minecraft:basalt
fill 291 187 264 291 196 264 minecraft:basalt
fill 292 187 239 293 195 239 minecraft:basalt
fill 292 187 265 293 195 265 minecraft:basalt
setblock 294 187 238 minecraft:magma_block
fill 294 187 266 296 187 266 minecraft:basalt
fill 295 187 230 299 187 230 minecraft:basalt
fill 295 187 237 296 194 238 minecraft:basalt
fill 295 187 267 296 194 267 minecraft:basalt
setblock 297 187 237 minecraft:magma_block
setblock 297 187 267 minecraft:magma_block
fill 298 187 237 301 194 237 minecraft:basalt
fill 298 187 238 300 187 238 minecraft:blackstone
fill 298 187 267 301 194 267 minecraft:basalt
setblock 300 187 230 minecraft:magma_block
fill 301 187 230 303 187 231 minecraft:basalt
fill 302 187 238 302 196 238 minecraft:basalt
fill 302 187 266 304 194 266 minecraft:basalt
setblock 303 187 238 minecraft:magma_block
fill 304 187 231 305 187 231 minecraft:basalt
fill 304 187 233 310 187 233 minecraft:basalt
fill 304 187 238 304 195 238 minecraft:basalt
fill 305 187 239 306 187 239 minecraft:basalt
fill 305 187 265 307 194 265 minecraft:basalt
setblock 306 187 231 minecraft:magma_block
fill 306 187 232 309 187 232 minecraft:basalt
fill 307 187 235 313 187 235 minecraft:basalt
fill 307 187 240 307 196 240 minecraft:basalt
fill 307 187 264 307 196 264 minecraft:basalt
fill 309 187 228 309 275 228 minecraft:blackstone
fill 309 187 234 312 187 234 minecraft:basalt
fill 309 187 241 309 195 241 minecraft:basalt
setblock 309 187 263 minecraft:magma_block
setblock 310 187 228 minecraft:shroomlight
fill 310 187 237 314 188 237 minecraft:basalt
fill 310 187 242 310 195 242 minecraft:basalt
fill 310 187 262 310 195 262 minecraft:basalt
fill 310 187 267 314 188 267 minecraft:basalt
fill 311 187 228 312 187 228 minecraft:blackstone
fill 311 187 244 311 196 244 minecraft:basalt
fill 311 187 260 311 196 260 minecraft:basalt
fill 312 187 236 314 187 236 minecraft:basalt
fill 312 187 239 317 187 239 minecraft:basalt
fill 312 187 241 318 187 241 minecraft:basalt
fill 312 187 245 312 195 246 minecraft:basalt
fill 312 187 258 312 196 258 minecraft:basalt
setblock 312 187 259 minecraft:magma_block
fill 312 187 266 316 187 266 minecraft:basalt
fill 312 187 269 313 187 269 minecraft:basalt
fill 313 187 245 313 194 245 minecraft:basalt
fill 313 187 247 313 194 249 minecraft:basalt
fill 313 187 255 313 194 257 minecraft:basalt
fill 313 187 263 317 188 263 minecraft:basalt
setblock 315 187 237 minecraft:magma_block
fill 315 187 238 316 187 238 minecraft:basalt
fill 315 187 244 319 188 244 minecraft:basalt
fill 315 187 247 320 187 247 minecraft:basalt
fill 315 187 256 320 188 256 minecraft:basalt
fill 315 187 259 319 188 260 minecraft:basalt
fill 315 187 265 317 187 265 minecraft:basalt
setblock 315 187 267 minecraft:magma_block
fill 316 187 262 319 187 262 minecraft:basalt
fill 318 187 242 319 187 243 minecraft:basalt
fill 318 187 246 320 187 246 minecraft:basalt
fill 318 187 249 321 187 249 minecraft:basalt
fill 318 187 252 321 187 252 minecraft:basalt
fill 318 187 255 321 187 255 minecraft:basalt
fill 318 187 258 320 187 258 minecraft:basalt
fill 318 187 261 319 187 261 minecraft:basalt
setblock 318 187 263 minecraft:magma_block
setblock 320 187 259 minecraft:basalt
fill 321 187 228 321 283 228 minecraft:blackstone
setblock 321 187 250 minecraft:magma_block
setblock 321 187 253 minecraft:magma_block
setblock 321 187 256 minecraft:magma_block
fill 282 188 261 282 219 261 minecraft:blackstone
fill 283 188 238 283 188 266 minecraft:basalt
setblock 284 188 237 minecraft:magma_block
fill 284 188 238 284 189 256 minecraft:basalt
fill 284 188 259 284 189 266 minecraft:basalt
setblock 284 188 267 minecraft:magma_block
fill 285 188 247 286 188 247 minecraft:basalt
fill 285 188 250 285 195 254 minecraft:basalt
fill 285 188 256 285 195 256 minecraft:basalt
fill 286 188 235 287 188 235 minecraft:basalt
fill 286 188 257 286 196 257 minecraft:basalt
setblock 286 188 269 minecraft:basalt
setblock 287 188 245 minecraft:magma_block
fill 287 188 259 287 196 259 minecraft:basalt
setblock 287 188 260 minecraft:magma_block
setblock 287 188 269 minecraft:magma_block
fill 288 188 243 288 195 243 minecraft:basalt
fill 288 188 261 288 195 261 minecraft:basalt
fill 288 188 269 293 189 269 minecraft:basalt
fill 289 188 233 293 188 233 minecraft:basalt
fill 289 188 242 289 196 242 minecraft:basalt
fill 289 188 262 289 196 262 minecraft:basalt
setblock 290 188 241 minecraft:magma_block
fill 290 188 263 290 196 263 minecraft:basalt
fill 291 188 232 296 188 232 minecraft:basalt
fill 292 188 240 292 196 240 minecraft:basalt
fill 292 188 264 292 196 264 minecraft:basalt
fill 294 188 238 294 195 239 minecraft:basalt
fill 294 188 265 294 195 266 minecraft:basalt
fill 295 188 231 299 188 231 minecraft:basalt
fill 295 188 266 295 194 266 minecraft:basalt
setblock 296 188 266 minecraft:magma_block
fill 297 188 237 297 195 238 minecraft:basalt
fill 297 188 266 297 195 267 minecraft:basalt
fill 298 188 238 298 196 238 minecraft:basalt
fill 298 188 266 301 195 266 minecraft:basalt
setblock 299 188 238 minecraft:magma_block
fill 299 188 239 299 189 239 minecraft:blackstone
fill 300 188 238 301 196 238 minecraft:basalt
setblock 301 188 231 minecraft:basalt
setblock 302 188 231 minecraft:magma_block
setblock 303 188 231 minecraft:basalt
fill 303 188 238 303 195 238 minecraft:basalt
fill 304 188 233 309 188 233 minecraft:basalt
fill 304 188 239 304 196 239 minecraft:basalt
setblock 304 188 265 minecraft:basalt
setblock 305 188 239 minecraft:magma_block
fill 306 188 232 307 188 232 minecraft:basalt
fill 306 188 239 306 195 240 minecraft:basalt
fill 306 188 264 306 195 264 minecraft:basalt
fill 307 188 235 312 188 235 minecraft:basalt
fill 307 188 268 313 188 268 minecraft:basalt
setblock 308 188 241 minecraft:magma_block
fill 308 188 263 309 195 263 minecraft:basalt
fill 309 188 234 310 188 234 minecraft:basalt
fill 309 188 242 309 195 242 minecraft:basalt
fill 309 188 262 309 196 262 minecraft:basalt
fill 310 188 228 310 283 228 minecraft:blackstone
fill 310 188 240 316 188 240 minecraft:basalt
fill 310 188 243 310 196 243 minecraft:basalt
fill 310 188 261 310 196 261 minecraft:basalt
fill 310 188 264 316 188 264 minecraft:basalt
fill 311 188 228 311 189 228 minecraft:magma_block
fill 311 188 245 311 196 245 minecraft:basalt
fill 311 188 259 312 195 259 minecraft:basalt
fill 312 188 228 312 189 228 minecraft:blackstone
fill 312 188 236 313 188 236 minecraft:basalt
fill 312 188 239 316 188 239 minecraft:basalt
fill 312 188 241 316 189 241 minecraft:basalt
fill 312 188 247 312 195 247 minecraft:basalt
fill 312 188 257 312 196 257 minecraft:basalt
fill 312 188 266 315 188 266 minecraft:basalt
setblock 312 188 269 minecraft:basalt
fill 313 188 250 313 188 254 minecraft:basalt
setblock 315 188 238 minecraft:basalt
fill 315 188 247 319 189 247 minecraft:basalt
fill 315 188 265 316 188 265 minecraft:basalt
fill 316 188 262 318 188 262 minecraft:basalt
setblock 317 188 241 minecraft:magma_block
fill 318 188 242 318 188 243 minecraft:basalt
fill 318 188 245 319 188 246 minecraft:basalt
fill 318 188 249 319 189 249 minecraft:basalt
fill 318 188 252 319 189 252 minecraft:basalt
fill 318 188 255 319 189 255 minecraft:basalt
fill 318 188 257 319 188 258 minecraft:basalt
setblock 318 188 261 minecraft:basalt
setblock 320 188 249 minecraft:magma_block
setblock 320 188 252 minecraft:magma_block
setblock 320 188 255 minecraft:magma_block
setblock 283 189 239 minecraft:magma_block
fill 283 189 240 283 189 265 minecraft:basalt
fill 285 189 231 285 190 231 minecraft:light[level=12]
fill 285 189 247 285 195 247 minecraft:basalt
fill 285 189 267 287 189 267 minecraft:basalt
setblock 286 189 247 minecraft:magma_block
fill 286 189 248 286 197 249 minecraft:basalt
setblock 286 189 250 minecraft:magma_block
fill 286 189 254 286 197 255 minecraft:basalt
setblock 286 189 256 minecraft:magma_block
setblock 286 189 268 minecraft:magma_block
fill 287 189 245 287 196 246 minecraft:basalt
fill 287 189 258 287 197 258 minecraft:basalt
fill 287 189 260 288 196 260 minecraft:basalt
setblock 287 189 268 minecraft:basalt
fill 288 189 244 288 197 244 minecraft:basalt
setblock 289 189 234 minecraft:magma_block
setblock 289 189 243 minecraft:magma_block
setblock 289 189 261 minecraft:magma_block
setblock 290 189 234 minecraft:basalt
fill 290 189 241 290 196 242 minecraft:basalt
fill 290 189 262 290 196 262 minecraft:basalt
setblock 291 189 233 minecraft:basalt
fill 291 189 241 291 197 241 minecraft:basalt
fill 291 189 263 291 197 263 minecraft:basalt
setblock 292 189 231 minecraft:light[level=12]
setblock 292 189 233 minecraft:magma_block
setblock 292 189 245 minecraft:light[level=12]
setblock 292 189 252 minecraft:light[level=12]
setblock 292 189 259 minecraft:light[level=12]
setblock 293 189 233 minecraft:basalt
fill 293 189 240 293 196 240 minecraft:basalt
fill 293 189 264 293 196 264 minecraft:basalt
setblock 294 189 232 minecraft:basalt
setblock 295 189 232 minecraft:magma_block
fill 295 189 239 297 189 239 minecraft:basalt
setblock 295 189 265 minecraft:magma_block
setblock 296 189 232 minecraft:basalt
fill 296 189 265 296 196 266 minecraft:basalt
fill 297 189 265 297 197 265 minecraft:basalt
fill 298 189 232 303 189 232 minecraft:basalt
setblock 298 189 239 minecraft:blackstone
setblock 299 189 231 minecraft:light[level=12]
fill 299 189 238 299 196 238 minecraft:basalt
setblock 299 189 245 minecraft:light[level=12]
setblock 299 189 259 minecraft:light[level=12]
setblock 300 189 239 minecraft:blackstone
setblock 301 189 239 minecraft:magma_block
fill 301 189 265 303 197 265 minecraft:basalt
fill 302 189 239 303 197 239 minecraft:basalt
setblock 304 189 232 minecraft:magma_block
fill 304 189 233 307 189 233 minecraft:basalt
setblock 304 189 265 minecraft:magma_block
fill 304 189 269 309 190 269 minecraft:basalt
fill 305 189 239 305 196 240 minecraft:basalt
fill 305 189 264 305 197 264 minecraft:basalt
setblock 306 189 231 minecraft:light[level=12]
setblock 306 189 245 minecraft:light[level=12]
setblock 306 189 252 minecraft:light[level=12]
setblock 306 189 259 minecraft:light[level=12]
fill 307 189 235 310 189 235 minecraft:basalt
fill 307 189 241 308 196 241 minecraft:basalt
fill 307 189 263 307 197 263 minecraft:basalt
fill 307 189 268 312 189 268 minecraft:basalt
fill 308 189 242 308 197 242 minecraft:basalt
fill 308 189 262 308 196 262 minecraft:basalt
setblock 309 189 234 minecraft:basalt
fill 309 189 243 309 197 243 minecraft:basalt
fill 309 189 261 309 197 261 minecraft:basalt
fill 310 189 237 313 189 237 minecraft:basalt
fill 310 189 240 315 189 240 minecraft:basalt
fill 310 189 244 310 197 244 minecraft:basalt
setblock 310 189 260 minecraft:magma_block
fill 310 189 264 315 189 264 minecraft:basalt
fill 310 189 267 313 189 267 minecraft:basalt
setblock 310 189 269 minecraft:magma_block
fill 311 189 246 311 196 246 minecraft:basalt
fill 311 189 258 311 196 258 minecraft:basalt
setblock 312 189 236 minecraft:basalt
fill 312 189 239 315 189 239 minecraft:basalt
fill 312 189 248 312 189 250 minecraft:basalt
fill 312 189 254 312 189 256 minecraft:basalt
fill 312 189 266 314 189 266 minecraft:basalt
setblock 313 189 231 minecraft:light[level=12]
fill 313 189 250 313 196 252 minecraft:basalt
setblock 313 189 253 minecraft:magma_block
fill 313 189 254 313 196 254 minecraft:basalt
fill 313 189 263 316 189 263 minecraft:basalt
fill 315 189 244 318 189 244 minecraft:basalt
fill 315 189 256 319 189 256 minecraft:basalt
fill 315 189 259 318 189 260 minecraft:basalt
setblock 315 189 265 minecraft:basalt
fill 316 189 262 317 189 262 minecraft:basalt
fill 318 189 245 318 189 246 minecraft:basalt
fill 318 189 248 318 190 248 minecraft:basalt
fill 318 189 250 318 189 251 minecraft:basalt
fill 318 189 253 318 189 254 minecraft:basalt
fill 318 189 257 318 189 258 minecraft:basalt
setblock 319 189 248 minecraft:magma_block
setblock 319 189 250 minecraft:basalt
setblock 319 189 251 minecraft:magma_block
setblock 319 189 253 minecraft:basalt
setblock 319 189 254 minecraft:magma_block
setblock 319 189 257 minecraft:magma_block
setblock 320 189 231 minecraft:light[level=12]
setblock 320 189 238 minecraft:light[level=12]
setblock 320 189 245 minecraft:light[level=12]
setblock 320 189 252 minecraft:light[level=12]
setblock 320 189 259 minecraft:light[level=12]
setblock 320 189 266 minecraft:light[level=12]
fill 283 190 241 283 190 263 minecraft:basalt
fill 284 190 240 284 190 256 minecraft:basalt
fill 284 190 259 284 190 264 minecraft:basalt
fill 285 190 238 287 190 238 minecraft:basalt
fill 286 190 247 287 196 247 minecraft:basalt
fill 286 190 250 286 197 253 minecraft:basalt
fill 286 190 256 287 190 256 minecraft:basalt
setblock 287 190 237 minecraft:basalt
fill 287 190 248 287 198 248 minecraft:basalt
fill 287 190 257 287 196 257 minecraft:basalt
setblock 287 190 267 minecraft:basalt
setblock 288 190 236 minecraft:magma_block
setblock 288 190 245 minecraft:magma_block
fill 288 190 246 288 198 246 minecraft:basalt
fill 288 190 258 288 197 259 minecraft:basalt
fill 289 190 236 293 191 236 minecraft:basalt
fill 289 190 243 289 197 244 minecraft:basalt
fill 289 190 260 289 197 261 minecraft:basalt
fill 289 190 269 293 190 269 minecraft:basalt
fill 290 190 243 290 198 243 minecraft:basalt
fill 290 190 261 290 198 261 minecraft:basalt
fill 291 190 242 291 198 242 minecraft:basalt
setblock 291 190 262 minecraft:magma_block
fill 292 190 241 293 197 241 minecraft:basalt
fill 292 190 263 293 190 263 minecraft:basalt
setblock 293 190 231 minecraft:light[level=12]
setblock 293 190 247 minecraft:light[level=12]
setblock 293 190 255 minecraft:light[level=12]
setblock 294 190 240 minecraft:magma_block
setblock 294 190 264 minecraft:magma_block
fill 295 190 233 296 190 233 minecraft:basalt
fill 295 190 239 295 197 240 minecraft:basalt
fill 295 190 242 298 195 243 minecraft:basalt
fill 295 190 264 295 197 265 minecraft:basalt
fill 296 190 239 296 196 239 minecraft:basalt
fill 296 190 241 298 192 241 minecraft:basalt
fill 296 190 244 298 255 244 minecraft:basalt
setblock 297 190 233 minecraft:magma_block
setblock 297 190 239 minecraft:magma_block
fill 298 190 233 302 190 233 minecraft:basalt
fill 298 190 239 301 197 239 minecraft:basalt
fill 298 190 265 299 196 265 minecraft:basalt
setblock 299 190 240 minecraft:blackstone
setblock 300 190 265 minecraft:magma_block
setblock 301 190 231 minecraft:light[level=12]
fill 301 190 234 307 190 234 minecraft:basalt
setblock 301 190 247 minecraft:light[level=12]
setblock 301 190 255 minecraft:light[level=12]
setblock 301 190 263 minecraft:light[level=12]
setblock 303 190 240 minecraft:magma_block
setblock 303 190 264 minecraft:magma_block
setblock 304 190 233 minecraft:basalt
fill 304 190 236 310 190 236 minecraft:basalt
fill 304 190 240 304 197 240 minecraft:basalt
fill 304 190 264 304 196 265 minecraft:basalt
fill 305 190 241 306 190 241 minecraft:basalt
fill 305 190 263 305 198 263 minecraft:basalt
setblock 306 190 263 minecraft:magma_block
fill 307 190 235 308 190 235 minecraft:basalt
fill 307 190 242 307 198 242 minecraft:basalt
fill 307 190 262 307 198 262 minecraft:basalt
fill 307 190 268 310 190 268 minecraft:basalt
fill 308 190 238 313 190 238 minecraft:basalt
fill 308 190 243 308 198 243 minecraft:basalt
fill 308 190 261 308 198 261 minecraft:basalt
setblock 309 190 231 minecraft:light[level=12]
setblock 309 190 235 minecraft:magma_block
setblock 309 190 244 minecraft:magma_block
setblock 309 190 247 minecraft:light[level=12]
setblock 309 190 255 minecraft:light[level=12]
fill 309 190 260 310 197 260 minecraft:basalt
fill 309 190 265 313 190 265 minecraft:basalt
fill 310 190 237 311 190 237 minecraft:basalt
fill 310 190 240 314 190 240 minecraft:basalt
fill 310 190 245 310 197 246 minecraft:basalt
fill 310 190 258 310 197 259 minecraft:basalt
fill 310 190 264 314 190 264 minecraft:basalt
fill 310 190 267 311 190 267 minecraft:basalt
fill 311 190 228 311 283 228 minecraft:blackstone
fill 311 190 247 311 190 248 minecraft:basalt
fill 311 190 256 311 197 257 minecraft:basalt
setblock 312 190 228 minecraft:magma_block
fill 312 190 239 313 190 239 minecraft:basalt
fill 312 190 241 315 190 241 minecraft:basalt
fill 312 190 248 312 197 248 minecraft:basalt
setblock 312 190 249 minecraft:magma_block
fill 312 190 250 312 197 251 minecraft:basalt
setblock 312 190 252 minecraft:magma_block
fill 312 190 253 312 197 254 minecraft:basalt
setblock 312 190 255 minecraft:magma_block
fill 312 190 256 312 197 256 minecraft:basalt
fill 312 190 266 313 190 266 minecraft:basalt
fill 313 190 242 316 190 243 minecraft:basalt
fill 313 190 253 313 196 253 minecraft:basalt
fill 313 190 261 316 190 261 minecraft:basalt
fill 313 190 263 314 191 263 minecraft:basalt
fill 315 190 244 317 190 244 minecraft:basalt
fill 315 190 247 317 191 247 minecraft:basalt
fill 315 190 256 317 191 256 minecraft:basalt
fill 315 190 259 317 190 260 minecraft:basalt
setblock 315 190 263 minecraft:magma_block
setblock 316 190 262 minecraft:basalt
setblock 317 190 231 minecraft:light[level=12]
setblock 317 190 239 minecraft:light[level=12]
setblock 317 190 263 minecraft:light[level=12]
setblock 318 190 247 minecraft:magma_block
setblock 318 190 249 minecraft:basalt
setblock 318 190 250 minecraft:magma_block
fill 318 190 251 318 190 252 minecraft:basalt
setblock 318 190 253 minecraft:magma_block
fill 318 190 254 318 190 255 minecraft:basalt
setblock 318 190 256 minecraft:magma_block
setblock 318 190 257 minecraft:basalt
fill 283 191 242 283 191 262 minecraft:basalt
fill 284 191 241 284 191 256 minecraft:basalt
fill 284 191 259 284 192 262 minecraft:basalt
setblock 284 191 263 minecraft:magma_block
fill 285 191 264 287 191 264 minecraft:basalt
fill 286 191 256 286 197 256 minecraft:basalt
fill 286 191 265 287 191 265 minecraft:basalt
setblock 287 191 238 minecraft:magma_block
fill 287 191 249 287 198 249 minecraft:basalt
setblock 287 191 250 minecraft:magma_block
fill 287 191 251 287 198 252 minecraft:basalt
setblock 287 191 253 minecraft:magma_block
fill 287 191 254 287 198 255 minecraft:basalt
setblock 287 191 256 minecraft:magma_block
fill 287 191 266 290 191 266 minecraft:basalt
fill 288 191 245 289 197 245 minecraft:basalt
fill 288 191 247 288 198 247 minecraft:basalt
fill 288 191 257 288 198 257 minecraft:basalt
fill 289 191 259 289 198 259 minecraft:basalt
fill 290 191 244 290 198 244 minecraft:basalt
fill 290 191 260 290 198 260 minecraft:basalt
fill 291 191 235 296 191 235 minecraft:basalt
fill 291 191 243 291 198 243 minecraft:basalt
fill 291 191 261 291 198 262 minecraft:basalt
fill 291 191 269 292 191 269 minecraft:basalt
fill 292 191 242 292 197 242 minecraft:basalt
fill 292 191 262 292 197 263 minecraft:basalt
setblock 293 191 263 minecraft:magma_block
setblock 293 191 269 minecraft:magma_block
fill 294 191 234 298 191 234 minecraft:basalt
fill 294 191 240 294 197 241 minecraft:basalt
fill 294 191 242 294 192 243 minecraft:blackstone
fill 294 191 263 294 197 264 minecraft:basalt
setblock 295 191 241 minecraft:blackstone
fill 295 191 244 295 192 244 minecraft:blackstone
fill 296 191 233 302 193 233 minecraft:blackstone
fill 296 191 240 298 197 240 minecraft:basalt
fill 296 191 245 298 192 245 minecraft:blackstone
fill 296 191 264 298 197 264 minecraft:basalt
fill 297 191 239 297 197 239 minecraft:basalt
fill 298 191 232 301 193 232 minecraft:blackstone
fill 298 191 235 304 191 235 minecraft:basalt
setblock 299 191 234 minecraft:magma_block
setblock 299 191 240 minecraft:magma_block
fill 299 191 241 299 192 244 minecraft:blackstone
setblock 299 191 264 minecraft:magma_block
fill 300 191 240 303 198 240 minecraft:basalt
fill 300 191 264 300 197 265 minecraft:basalt
fill 301 191 234 304 191 234 minecraft:basalt
fill 301 191 264 303 198 264 minecraft:basalt
fill 304 191 236 309 191 236 minecraft:basalt
fill 304 191 241 304 197 241 minecraft:basalt
fill 304 191 263 304 198 263 minecraft:basalt
fill 304 191 269 307 191 269 minecraft:basalt
setblock 305 191 235 minecraft:magma_block
setblock 305 191 241 minecraft:magma_block
fill 306 191 241 306 197 242 minecraft:basalt
fill 306 191 262 306 197 263 minecraft:basalt
setblock 307 191 235 minecraft:basalt
fill 307 191 243 307 197 243 minecraft:basalt
fill 307 191 261 307 197 261 minecraft:basalt
fill 307 191 268 309 191 268 minecraft:basalt
fill 308 191 238 311 191 238 minecraft:basalt
fill 308 191 244 309 198 244 minecraft:basalt
fill 308 191 260 308 198 260 minecraft:basalt
fill 308 191 266 310 192 266 minecraft:basalt
fill 309 191 245 309 198 245 minecraft:basalt
fill 309 191 259 309 198 259 minecraft:basalt
fill 309 191 265 312 191 265 minecraft:basalt
setblock 310 191 237 minecraft:basalt
fill 310 191 240 313 191 240 minecraft:basalt
fill 310 191 247 311 191 247 minecraft:basalt
fill 310 191 257 310 197 257 minecraft:basalt
fill 310 191 264 313 191 264 minecraft:basalt
setblock 310 191 267 minecraft:basalt
setblock 311 191 248 minecraft:magma_block
fill 311 191 249 311 198 250 minecraft:basalt
setblock 311 191 251 minecraft:magma_block
fill 311 191 252 311 198 253 minecraft:basalt
setblock 311 191 254 minecraft:magma_block
fill 311 191 255 312 197 255 minecraft:basalt
setblock 311 191 266 minecraft:magma_block
fill 312 191 228 312 283 228 minecraft:blackstone
setblock 312 191 239 minecraft:basalt
fill 312 191 241 313 192 241 minecraft:basalt
fill 312 191 249 312 197 249 minecraft:basalt
fill 312 191 252 312 197 252 minecraft:basalt
setblock 313 191 228 minecraft:shroomlight
fill 313 191 242 315 191 243 minecraft:basalt
fill 313 191 261 315 191 261 minecraft:basalt
fill 314 191 228 314 192 228 minecraft:blackstone
setblock 314 191 241 minecraft:magma_block
setblock 315 191 228 minecraft:magma_block
fill 315 191 244 316 191 246 minecraft:basalt
fill 315 191 248 316 191 249 minecraft:basalt
fill 315 191 255 316 192 255 minecraft:basalt
fill 315 191 257 316 191 260 minecraft:basalt
fill 316 191 228 316 283 228 minecraft:blackstone
fill 316 191 250 316 191 254 minecraft:basalt
setblock 317 191 248 minecraft:basalt
setblock 317 191 249 minecraft:magma_block
fill 317 191 250 317 191 251 minecraft:basalt
setblock 317 191 252 minecraft:magma_block
fill 317 191 253 317 191 254 minecraft:basalt
setblock 317 191 255 minecraft:magma_block
setblock 317 191 257 minecraft:basalt
fill 321 191 270 322 231 270 minecraft:blackstone
setblock 323 191 270 minecraft:magma_block
fill 324 191 270 324 283 270 minecraft:blackstone
setblock 283 192 244 minecraft:magma_block
fill 283 192 245 283 192 258 minecraft:basalt
setblock 283 192 259 minecraft:magma_block
setblock 283 192 260 minecraft:basalt
fill 284 192 242 284 192 256 minecraft:basalt
fill 285 192 241 287 192 241 minecraft:basalt
setblock 286 192 240 minecraft:magma_block
setblock 286 192 264 minecraft:magma_block
fill 287 192 239 287 192 240 minecraft:basalt
fill 287 192 250 287 198 250 minecraft:basalt
fill 287 192 253 287 198 253 minecraft:basalt
fill 287 192 256 288 198 256 minecraft:basalt
fill 287 192 264 287 192 265 minecraft:basalt
fill 288 192 239 289 193 239 minecraft:basalt
fill 288 192 248 288 198 249 minecraft:basalt
fill 288 192 255 288 199 255 minecraft:basalt
setblock 288 192 266 minecraft:basalt
fill 289 192 237 290 192 237 minecraft:basalt
fill 289 192 246 289 199 246 minecraft:basalt
fill 289 192 258 289 199 258 minecraft:basalt
setblock 289 192 266 minecraft:magma_block
fill 289 192 267 290 192 267 minecraft:basalt
fill 290 192 245 290 199 245 minecraft:basalt
fill 290 192 259 290 199 259 minecraft:basalt
fill 290 192 266 290 193 266 minecraft:basalt
fill 291 192 236 293 192 236 minecraft:basalt
fill 291 192 244 291 198 244 minecraft:basalt
fill 291 192 260 291 199 260 minecraft:basalt
setblock 291 192 268 minecraft:basalt
fill 292 192 243 292 199 243 minecraft:basalt
fill 292 192 261 292 199 261 minecraft:basalt
setblock 292 192 268 minecraft:magma_block
fill 293 192 235 296 192 235 minecraft:basalt
fill 293 192 242 293 199 242 minecraft:basalt
setblock 293 192 243 minecraft:blackstone
fill 293 192 262 293 198 263 minecraft:basalt
fill 293 192 268 293 192 269 minecraft:basalt
fill 294 192 244 294 192 245 minecraft:blackstone
fill 294 192 268 296 193 268 minecraft:basalt
fill 295 192 234 297 193 234 minecraft:blackstone
fill 295 192 241 295 199 241 minecraft:basalt
setblock 295 192 245 minecraft:blackstone
fill 295 192 263 296 199 263 minecraft:basalt
fill 296 192 246 298 192 246 minecraft:blackstone
fill 297 192 232 297 193 232 minecraft:blackstone
fill 298 192 234 299 192 235 minecraft:basalt
fill 299 192 240 299 198 240 minecraft:basalt
setblock 299 192 245 minecraft:blackstone
fill 299 192 264 299 198 264 minecraft:basalt
fill 300 192 235 300 193 235 minecraft:basalt
fill 300 192 241 300 192 244 minecraft:blackstone
fill 301 192 234 303 193 234 minecraft:blackstone
setblock 301 192 235 minecraft:magma_block
fill 302 192 232 302 193 232 minecraft:blackstone
fill 302 192 235 305 192 235 minecraft:basalt
fill 302 192 241 303 199 241 minecraft:basalt
fill 302 192 263 303 199 263 minecraft:basalt
fill 303 192 233 303 193 233 minecraft:blackstone
fill 304 192 236 306 192 236 minecraft:basalt
fill 304 192 269 305 192 269 minecraft:basalt
fill 305 192 241 305 198 242 minecraft:basalt
fill 305 192 262 305 199 262 minecraft:basalt
fill 306 192 243 306 199 243 minecraft:basalt
fill 306 192 261 306 199 261 minecraft:basalt
setblock 307 192 236 minecraft:magma_block
fill 307 192 244 307 199 244 minecraft:basalt
setblock 307 192 260 minecraft:magma_block
setblock 307 192 268 minecraft:basalt
fill 308 192 238 309 192 238 minecraft:basalt
fill 308 192 245 308 199 245 minecraft:basalt
fill 308 192 259 308 199 259 minecraft:basalt
fill 309 192 246 309 199 246 minecraft:basalt
fill 309 192 258 309 199 258 minecraft:basalt
fill 309 192 265 311 192 265 minecraft:basalt
setblock 310 192 238 minecraft:magma_block
fill 310 192 240 312 192 240 minecraft:basalt
setblock 310 192 247 minecraft:magma_block
fill 310 192 248 310 199 249 minecraft:basalt
fill 310 192 255 310 199 255 minecraft:basalt
setblock 310 192 256 minecraft:magma_block
fill 310 192 264 312 192 264 minecraft:basalt
fill 311 192 247 311 197 248 minecraft:basalt
fill 311 192 251 311 198 251 minecraft:basalt
fill 311 192 254 311 198 254 minecraft:basalt
setblock 313 192 228 minecraft:magma_block
fill 313 192 242 314 192 243 minecraft:basalt
fill 313 192 261 314 192 261 minecraft:basalt
setblock 313 192 263 minecraft:basalt
fill 315 192 228 315 234 228 minecraft:blackstone
fill 315 192 244 315 192 249 minecraft:basalt
fill 315 192 256 315 192 260 minecraft:basalt
fill 316 192 246 316 192 247 minecraft:basalt
setblock 316 192 248 minecraft:magma_block
fill 316 192 249 316 192 253 minecraft:basalt
setblock 316 192 254 minecraft:magma_block
setblock 316 192 256 minecraft:basalt
setblock 316 192 257 minecraft:magma_block
setblock 316 192 258 minecraft:basalt
fill 317 192 251 317 192 253 minecraft:basalt
setblock 323 192 270 minecraft:blackstone
fill 283 193 246 283 193 258 minecraft:basalt
fill 284 193 244 284 193 256 minecraft:basalt
fill 284 193 259 284 193 260 minecraft:basalt
setblock 285 193 261 minecraft:basalt
fill 286 193 241 287 193 241 minecraft:basalt
setblock 287 193 240 minecraft:basalt
setblock 287 193 264 minecraft:basalt
setblock 288 193 250 minecraft:magma_block
fill 288 193 251 288 198 252 minecraft:basalt
setblock 288 193 253 minecraft:magma_block
fill 288 193 254 288 198 254 minecraft:basalt
setblock 288 193 265 minecraft:magma_block
fill 289 193 247 289 199 248 minecraft:basalt
fill 289 193 256 289 199 257 minecraft:basalt
fill 290 193 238 291 193 238 minecraft:basalt
fill 290 193 246 290 199 246 minecraft:basalt
fill 290 193 258 290 199 258 minecraft:basalt
setblock 291 193 237 minecraft:magma_block
fill 291 193 245 291 199 245 minecraft:basalt
fill 291 193 259 291 198 259 minecraft:basalt
fill 291 193 266 291 194 266 minecraft:basalt
setblock 291 193 267 minecraft:magma_block
fill 292 193 244 292 199 244 minecraft:basalt
fill 292 193 260 292 199 260 minecraft:basalt
setblock 293 193 236 minecraft:basalt
fill 293 193 243 293 199 243 minecraft:basalt
fill 293 193 261 293 199 261 minecraft:basalt
setblock 293 193 268 minecraft:basalt
fill 294 193 235 296 193 235 minecraft:blackstone
setblock 294 193 236 minecraft:magma_block
setblock 294 193 242 minecraft:magma_block
fill 294 193 262 295 199 262 minecraft:basalt
setblock 295 193 233 minecraft:blackstone
setblock 296 193 232 minecraft:blackstone
fill 296 193 241 296 255 241 minecraft:basalt
fill 297 193 231 301 193 231 minecraft:blackstone
setblock 297 193 235 minecraft:magma_block
fill 297 193 236 297 194 236 minecraft:basalt
setblock 297 193 241 minecraft:magma_block
fill 297 193 263 301 198 263 minecraft:basalt
fill 297 193 269 301 193 269 minecraft:basalt
fill 298 193 234 300 193 234 minecraft:blackstone
fill 298 193 235 299 193 235 minecraft:basalt
fill 298 193 241 301 198 241 minecraft:basalt
setblock 301 193 235 minecraft:basalt
fill 302 193 235 304 193 235 minecraft:blackstone
setblock 303 193 236 minecraft:magma_block
setblock 303 193 242 minecraft:magma_block
fill 303 193 262 304 199 262 minecraft:basalt
setblock 303 193 268 minecraft:basalt
setblock 304 193 234 minecraft:blackstone
fill 304 193 236 305 193 236 minecraft:basalt
fill 304 193 242 304 199 242 minecraft:basalt
fill 305 193 243 305 199 243 minecraft:basalt
fill 305 193 261 305 199 261 minecraft:basalt
setblock 305 193 268 minecraft:basalt
fill 306 193 237 307 193 237 minecraft:basalt
setblock 306 193 244 minecraft:magma_block
fill 306 193 260 307 198 260 minecraft:basalt
fill 306 193 267 307 193 267 minecraft:basalt
fill 307 193 245 307 199 245 minecraft:basalt
fill 307 193 259 307 199 259 minecraft:basalt
setblock 308 193 238 minecraft:basalt
fill 308 193 246 308 199 246 minecraft:basalt
fill 308 193 258 308 199 258 minecraft:basalt
setblock 308 193 266 minecraft:basalt
fill 309 193 239 310 193 239 minecraft:basalt
fill 309 193 247 309 198 248 minecraft:basalt
fill 309 193 256 309 198 257 minecraft:basalt
fill 309 193 265 310 193 265 minecraft:basalt
fill 310 193 240 311 193 240 minecraft:basalt
fill 310 193 247 310 198 247 minecraft:basalt
fill 310 193 250 310 199 254 minecraft:basalt
fill 310 193 256 310 199 256 minecraft:basalt
fill 310 193 264 311 193 264 minecraft:basalt
fill 311 193 242 311 194 242 minecraft:basalt
setblock 312 193 241 minecraft:basalt
setblock 312 193 242 minecraft:magma_block
setblock 312 193 262 minecraft:basalt
setblock 312 193 263 minecraft:magma_block
fill 313 193 228 313 194 228 minecraft:blackstone
setblock 313 193 243 minecraft:basalt
setblock 313 193 261 minecraft:basalt
fill 314 193 228 314 194 228 minecraft:magma_block
setblock 315 193 246 minecraft:basalt
setblock 315 193 247 minecraft:magma_block
fill 315 193 248 315 193 249 minecraft:basalt
fill 315 193 255 315 194 255 minecraft:basalt
setblock 315 193 256 minecraft:magma_block
fill 315 193 257 315 193 258 minecraft:basalt
fill 316 193 250 316 193 254 minecraft:basalt
setblock 323 193 270 minecraft:shroomlight
fill 324 193 257 324 230 258 minecraft:blackstone
setblock 324 193 259 minecraft:magma_block
fill 324 193 260 324 283 260 minecraft:blackstone
fill 283 194 249 284 194 255 minecraft:basalt
setblock 284 194 246 minecraft:basalt
setblock 284 194 247 minecraft:magma_block
setblock 284 194 248 minecraft:basalt
setblock 284 194 256 minecraft:magma_block
setblock 287 194 241 minecraft:basalt
fill 288 194 250 289 194 250 minecraft:basalt
fill 288 194 253 289 194 253 minecraft:basalt
fill 289 194 249 289 199 249 minecraft:basalt
fill 289 194 251 289 199 252 minecraft:basalt
fill 289 194 254 289 199 255 minecraft:basalt
setblock 290 194 239 minecraft:magma_block
fill 290 194 240 290 195 240 minecraft:basalt
fill 290 194 247 290 199 247 minecraft:basalt
setblock 290 194 257 minecraft:magma_block
setblock 291 194 238 minecraft:basalt
fill 291 194 246 291 199 246 minecraft:basalt
fill 291 194 258 291 199 258 minecraft:basalt
setblock 293 194 244 minecraft:magma_block
fill 293 194 260 293 199 260 minecraft:basalt
fill 294 194 242 294 198 243 minecraft:basalt
fill 294 194 261 294 198 261 minecraft:basalt
setblock 296 194 236 minecraft:basalt
fill 296 194 262 301 194 262 minecraft:basalt
setblock 296 194 268 minecraft:basalt
fill 297 194 241 297 255 241 minecraft:basalt
fill 299 194 235 299 195 236 minecraft:magma_block
setblock 299 194 242 minecraft:magma_block
fill 300 194 242 303 199 242 minecraft:basalt
setblock 302 194 262 minecraft:magma_block
fill 302 194 267 302 195 267 minecraft:basalt
setblock 302 194 268 minecraft:magma_block
fill 304 194 243 304 199 243 minecraft:basalt
fill 304 194 261 304 199 261 minecraft:basalt
setblock 304 194 267 minecraft:basalt
setblock 305 194 237 minecraft:magma_block
fill 305 194 238 305 195 238 minecraft:basalt
fill 305 194 244 306 199 244 minecraft:basalt
fill 305 194 260 305 199 260 minecraft:basalt
fill 305 194 266 305 195 266 minecraft:basalt
setblock 305 194 267 minecraft:magma_block
fill 307 194 239 307 195 239 minecraft:basalt
fill 307 194 246 307 199 246 minecraft:basalt
fill 307 194 258 307 199 258 minecraft:basalt
setblock 308 194 239 minecraft:magma_block
fill 308 194 247 308 199 247 minecraft:basalt
setblock 308 194 257 minecraft:magma_block
fill 309 194 249 309 198 255 minecraft:basalt
fill 310 194 240 310 194 241 minecraft:basalt
setblock 310 194 264 minecraft:basalt
setblock 311 194 241 minecraft:magma_block
fill 311 194 261 311 195 261 minecraft:basalt
setblock 311 194 262 minecraft:magma_block
fill 313 194 246 313 195 246 minecraft:basalt
fill 313 194 258 313 195 258 minecraft:basalt
setblock 314 194 246 minecraft:magma_block
setblock 314 194 258 minecraft:magma_block
setblock 315 194 249 minecraft:basalt
fill 323 194 270 323 283 270 minecraft:blackstone
fill 324 194 259 324 206 259 minecraft:blackstone
fill 282 195 262 282 205 262 minecraft:blackstone
setblock 282 195 263 minecraft:crying_obsidian
fill 284 195 249 284 195 255 minecraft:basalt
setblock 285 195 231 minecraft:light[level=12]
setblock 285 195 238 minecraft:light[level=12]
setblock 285 195 245 minecraft:light[level=12]
setblock 285 195 259 minecraft:light[level=12]
setblock 285 195 266 minecraft:light[level=12]
setblock 286 195 245 minecraft:magma_block
fill 286 195 246 286 196 246 minecraft:basalt
fill 286 195 258 286 195 259 minecraft:basalt
setblock 286 195 260 minecraft:magma_block
fill 288 195 250 288 199 250 minecraft:basalt
fill 288 195 253 288 199 253 minecraft:basalt
setblock 289 195 241 minecraft:magma_block
setblock 289 195 250 minecraft:magma_block
setblock 289 195 253 minecraft:magma_block
fill 290 195 248 290 199 249 minecraft:basalt
fill 290 195 255 290 199 257 minecraft:basalt
fill 291 195 247 291 198 247 minecraft:basalt
setblock 291 195 257 minecraft:basalt
setblock 292 195 231 minecraft:light[level=12]
setblock 292 195 238 minecraft:light[level=12]
fill 292 195 245 292 199 245 minecraft:basalt
setblock 292 195 252 minecraft:light[level=12]
fill 292 195 259 292 199 259 minecraft:basalt
setblock 292 195 266 minecraft:light[level=12]
fill 293 195 244 294 195 244 minecraft:basalt
fill 294 195 260 294 199 260 minecraft:basalt
fill 295 195 238 296 196 238 minecraft:basalt
fill 295 195 261 296 199 261 minecraft:basalt
setblock 295 195 266 minecraft:magma_block
setblock 296 195 237 minecraft:basalt
fill 296 195 262 297 199 262 minecraft:basalt
setblock 296 195 267 minecraft:basalt
fill 298 195 237 300 195 237 minecraft:basalt
setblock 298 195 262 minecraft:magma_block
fill 298 195 267 300 195 267 minecraft:basalt
setblock 299 195 231 minecraft:light[level=12]
fill 299 195 242 299 199 242 minecraft:basalt
setblock 299 195 245 minecraft:light[level=12]
setblock 299 195 259 minecraft:light[level=12]
fill 299 195 262 302 198 262 minecraft:basalt
setblock 300 195 236 minecraft:magma_block
setblock 301 195 237 minecraft:magma_block
setblock 301 195 267 minecraft:magma_block
setblock 302 195 237 minecraft:basalt
fill 302 195 243 303 198 243 minecraft:basalt
fill 302 195 261 303 198 261 minecraft:basalt
fill 302 195 266 303 196 266 minecraft:basalt
fill 304 195 244 304 199 244 minecraft:basalt
setblock 304 195 260 minecraft:magma_block
setblock 304 195 266 minecraft:magma_block
fill 305 195 265 306 195 265 minecraft:basalt
setblock 306 195 231 minecraft:light[level=12]
setblock 306 195 238 minecraft:light[level=12]
fill 306 195 245 306 198 245 minecraft:basalt
setblock 306 195 252 minecraft:light[level=12]
fill 306 195 259 306 199 259 minecraft:basalt
setblock 306 195 266 minecraft:light[level=12]
setblock 307 195 247 minecraft:magma_block
fill 307 195 257 308 199 257 minecraft:basalt
setblock 307 195 265 minecraft:magma_block
fill 308 195 248 308 199 249 minecraft:basalt
fill 308 195 255 308 199 256 minecraft:basalt
setblock 312 195 244 minecraft:basalt
setblock 313 195 228 minecraft:shroomlight
setblock 313 195 231 minecraft:light[level=12]
setblock 313 195 238 minecraft:light[level=12]
setblock 313 195 245 minecraft:light[level=12]
setblock 313 195 247 minecraft:basalt
setblock 313 195 248 minecraft:magma_block
fill 313 195 249 314 195 249 minecraft:basalt
fill 313 195 255 313 196 256 minecraft:basalt
setblock 313 195 257 minecraft:magma_block
setblock 313 195 259 minecraft:light[level=12]
setblock 313 195 266 minecraft:light[level=12]
fill 314 195 228 314 283 228 minecraft:blackstone
fill 314 195 250 314 195 255 minecraft:basalt
setblock 320 195 231 minecraft:light[level=12]
setblock 320 195 238 minecraft:light[level=12]
setblock 320 195 245 minecraft:light[level=12]
setblock 320 195 252 minecraft:light[level=12]
setblock 320 195 259 minecraft:light[level=12]
setblock 320 195 266 minecraft:light[level=12]
fill 282 196 263 282 203 263 minecraft:blackstone
fill 282 196 265 282 283 265 minecraft:blackstone
setblock 282 196 266 minecraft:crying_obsidian
fill 282 196 267 282 201 270 minecraft:blackstone
setblock 285 196 250 minecraft:magma_block
fill 285 196 251 285 196 252 minecraft:basalt
setblock 285 196 253 minecraft:magma_block
setblock 285 196 254 minecraft:basalt
setblock 285 196 256 minecraft:magma_block
setblock 286 196 258 minecraft:basalt
setblock 288 196 243 minecraft:magma_block
setblock 288 196 261 minecraft:magma_block
fill 289 196 250 290 199 250 minecraft:basalt
fill 289 196 253 290 196 253 minecraft:basalt
fill 290 196 251 290 199 252 minecraft:basalt
fill 290 196 254 290 199 254 minecraft:basalt
setblock 291 196 248 minecraft:magma_block
fill 291 196 256 291 198 256 minecraft:basalt
setblock 291 196 257 minecraft:magma_block
fill 292 196 246 292 199 246 minecraft:basalt
fill 292 196 258 292 199 258 minecraft:basalt
fill 293 196 239 294 196 239 minecraft:basalt
fill 293 196 244 293 199 245 minecraft:basalt
fill 293 196 259 293 199 259 minecraft:basalt
setblock 293 196 265 minecraft:basalt
setblock 294 196 244 minecraft:magma_block
setblock 294 196 265 minecraft:magma_block
fill 295 196 242 295 199 244 minecraft:basalt
fill 295 196 260 295 199 260 minecraft:basalt
setblock 295 196 266 minecraft:basalt
fill 296 196 242 296 255 243 minecraft:basalt
setblock 297 196 238 minecraft:basalt
fill 297 196 242 298 198 242 minecraft:basalt
setblock 297 196 243 minecraft:magma_block
setblock 297 196 261 minecraft:magma_block
fill 297 196 266 299 196 266 minecraft:basalt
fill 298 196 243 301 199 243 minecraft:basalt
fill 298 196 261 298 199 262 minecraft:basalt
fill 299 196 236 299 198 236 minecraft:magma_block
fill 299 196 261 301 199 261 minecraft:basalt
setblock 300 196 266 minecraft:magma_block
setblock 301 196 266 minecraft:basalt
setblock 303 196 238 minecraft:magma_block
setblock 303 196 244 minecraft:magma_block
fill 303 196 260 304 199 260 minecraft:basalt
fill 305 196 245 305 199 245 minecraft:basalt
fill 305 196 259 305 199 259 minecraft:basalt
setblock 305 196 265 minecraft:basalt
setblock 306 196 240 minecraft:magma_block
setblock 306 196 246 minecraft:magma_block
setblock 306 196 258 minecraft:magma_block
setblock 306 196 264 minecraft:magma_block
fill 307 196 247 307 199 248 minecraft:basalt
fill 307 196 256 307 199 256 minecraft:basalt
fill 308 196 250 308 196 254 minecraft:basalt
setblock 308 196 263 minecraft:basalt
setblock 309 196 242 minecraft:magma_block
setblock 311 196 259 minecraft:basalt
setblock 312 196 246 minecraft:basalt
setblock 312 196 247 minecraft:magma_block
fill 313 196 228 313 283 228 minecraft:blackstone
fill 313 196 248 313 196 249 minecraft:basalt
fill 318 196 228 319 196 228 minecraft:blackstone
setblock 320 196 228 minecraft:shroomlight
fill 324 196 240 324 205 244 minecraft:blackstone
setblock 324 196 245 minecraft:shroomlight
fill 324 196 254 324 283 254 minecraft:blackstone
setblock 324 196 255 minecraft:magma_block
fill 282 197 266 282 283 266 minecraft:blackstone
setblock 285 197 231 minecraft:light[level=12]
setblock 285 197 239 minecraft:light[level=12]
setblock 285 197 247 minecraft:light[level=12]
setblock 285 197 255 minecraft:light[level=12]
setblock 285 197 263 minecraft:light[level=12]
fill 287 197 246 287 197 247 minecraft:basalt
setblock 287 197 257 minecraft:magma_block
setblock 288 197 260 minecraft:basalt
fill 289 197 253 289 199 253 minecraft:basalt
setblock 290 197 228 minecraft:shroomlight
setblock 290 197 242 minecraft:basalt
setblock 290 197 253 minecraft:magma_block
setblock 290 197 262 minecraft:magma_block
fill 291 197 248 291 198 250 minecraft:basalt
fill 291 197 254 291 199 255 minecraft:basalt
fill 291 197 257 292 199 257 minecraft:basalt
fill 292 197 247 292 199 247 minecraft:basalt
setblock 293 197 231 minecraft:light[level=12]
setblock 293 197 239 minecraft:light[level=12]
setblock 293 197 240 minecraft:magma_block
setblock 293 197 246 minecraft:magma_block
setblock 293 197 247 minecraft:light[level=12]
setblock 293 197 255 minecraft:light[level=12]
setblock 293 197 258 minecraft:magma_block
setblock 293 197 264 minecraft:magma_block
setblock 293 197 270 minecraft:shroomlight
fill 294 197 244 294 199 245 minecraft:basalt
fill 294 197 259 294 199 259 minecraft:basalt
setblock 296 197 239 minecraft:magma_block
setblock 296 197 260 minecraft:magma_block
setblock 296 197 265 minecraft:basalt
fill 297 197 243 297 255 243 minecraft:basalt
fill 297 197 260 297 198 261 minecraft:basalt
setblock 298 197 265 minecraft:basalt
setblock 299 197 265 minecraft:magma_block
setblock 301 197 231 minecraft:light[level=12]
fill 301 197 244 303 199 244 minecraft:basalt
setblock 301 197 247 minecraft:light[level=12]
setblock 301 197 255 minecraft:light[level=12]
fill 301 197 260 302 197 260 minecraft:basalt
fill 304 197 245 304 199 245 minecraft:basalt
fill 304 197 259 304 199 259 minecraft:basalt
setblock 304 197 264 minecraft:basalt
setblock 305 197 240 minecraft:basalt
fill 305 197 246 306 199 246 minecraft:basalt
fill 305 197 258 306 199 258 minecraft:basalt
fill 306 197 247 306 199 247 minecraft:basalt
fill 306 197 257 306 198 257 minecraft:basalt
setblock 307 197 241 minecraft:basalt
fill 307 197 249 307 199 250 minecraft:basalt
fill 307 197 254 307 199 255 minecraft:basalt
fill 308 197 250 308 199 252 minecraft:basalt
setblock 308 197 253 minecraft:magma_block
fill 308 197 254 308 199 254 minecraft:basalt
setblock 308 197 262 minecraft:magma_block
setblock 309 197 231 minecraft:light[level=12]
setblock 309 197 239 minecraft:light[level=12]
setblock 309 197 263 minecraft:light[level=12]
setblock 311 197 246 minecraft:magma_block
setblock 311 197 258 minecraft:magma_block
setblock 317 197 231 minecraft:light[level=12]
setblock 317 197 239 minecraft:light[level=12]
setblock 317 197 247 minecraft:light[level=12]
setblock 317 197 255 minecraft:light[level=12]
setblock 317 197 263 minecraft:light[level=12]
setblock 318 197 228 minecraft:crying_obsidian
fill 319 197 228 320 237 228 minecraft:blackstone
fill 324 197 245 324 250 245 minecraft:blackstone
fill 324 197 255 324 283 255 minecraft:blackstone
setblock 288 198 258 minecraft:basalt
fill 289 198 244 289 198 245 minecraft:basalt
setblock 289 198 260 minecraft:basalt
fill 290 198 228 290 283 228 minecraft:blackstone
fill 290 198 253 291 198 253 minecraft:basalt
fill 291 198 251 291 199 252 minecraft:basalt
setblock 292 198 242 minecraft:magma_block
setblock 292 198 248 minecraft:magma_block
setblock 292 198 249 minecraft:basalt
fill 292 198 255 292 198 256 minecraft:basalt
setblock 292 198 262 minecraft:basalt
fill 293 198 241 294 198 241 minecraft:basalt
fill 293 198 246 293 199 247 minecraft:basalt
fill 293 198 257 293 199 258 minecraft:basalt
fill 293 198 270 293 252 270 minecraft:blackstone
setblock 294 198 246 minecraft:basalt
setblock 294 198 258 minecraft:basalt
setblock 294 198 263 minecraft:basalt
fill 295 198 240 297 198 240 minecraft:basalt
fill 295 198 245 296 198 245 minecraft:basalt
setblock 295 198 259 minecraft:magma_block
fill 295 198 264 297 198 264 minecraft:basalt
fill 296 198 259 296 198 260 minecraft:basalt
setblock 298 198 240 minecraft:magma_block
fill 298 198 260 300 199 260 minecraft:basalt
setblock 298 198 264 minecraft:magma_block
fill 299 198 244 300 198 244 minecraft:basalt
setblock 300 198 264 minecraft:basalt
setblock 301 198 260 minecraft:magma_block
fill 302 198 245 303 198 245 minecraft:basalt
fill 302 198 259 302 198 260 minecraft:basalt
fill 303 198 259 303 199 259 minecraft:basalt
setblock 304 198 241 minecraft:magma_block
fill 304 198 246 304 199 246 minecraft:basalt
fill 304 198 258 304 199 258 minecraft:basalt
fill 305 198 247 305 199 247 minecraft:basalt
fill 305 198 257 305 199 257 minecraft:basalt
setblock 306 198 242 minecraft:basalt
fill 306 198 248 306 198 249 minecraft:basalt
fill 306 198 255 306 198 256 minecraft:basalt
setblock 306 198 262 minecraft:basalt
setblock 307 198 243 minecraft:magma_block
fill 307 198 251 307 199 251 minecraft:basalt
setblock 307 198 252 minecraft:magma_block
fill 307 198 253 308 199 253 minecraft:basalt
setblock 307 198 261 minecraft:magma_block
setblock 309 198 260 minecraft:basalt
setblock 310 198 246 minecraft:basalt
setblock 310 198 257 minecraft:magma_block
setblock 310 198 258 minecraft:basalt
setblock 311 198 248 minecraft:basalt
fill 311 198 255 311 198 256 minecraft:basalt
setblock 318 198 228 minecraft:shroomlight
fill 282 199 241 286 199 241 minecraft:blackstone
setblock 282 199 242 minecraft:magma_block
fill 283 199 229 286 199 240 minecraft:blackstone
fill 283 199 242 286 199 269 minecraft:blackstone
fill 287 199 229 323 199 232 minecraft:blackstone
fill 287 199 233 288 255 234 minecraft:basalt
fill 287 199 266 323 199 269 minecraft:blackstone
fill 288 199 237 289 200 238 minecraft:basalt
setblock 288 199 248 minecraft:magma_block
setblock 288 199 249 minecraft:basalt
setblock 288 199 251 minecraft:magma_block
setblock 288 199 252 minecraft:basalt
setblock 288 199 254 minecraft:magma_block
setblock 288 199 256 minecraft:basalt
fill 289 199 233 289 255 233 minecraft:basalt
setblock 290 199 253 minecraft:basalt
setblock 291 199 244 minecraft:magma_block
setblock 291 199 247 minecraft:magma_block
fill 291 199 248 291 199 249 minecraft:basalt
fill 291 199 250 292 199 250 minecraft:magma_block
fill 291 199 253 292 199 253 minecraft:magma_block
setblock 291 199 256 minecraft:magma_block
setblock 291 199 259 minecraft:magma_block
setblock 292 199 248 minecraft:basalt
fill 292 199 249 293 199 249 minecraft:magma_block
fill 292 199 251 292 199 252 minecraft:magma_block
fill 292 199 254 292 199 255 minecraft:magma_block
setblock 292 199 256 minecraft:basalt
setblock 293 199 248 minecraft:magma_block
fill 293 199 255 293 199 256 minecraft:magma_block
setblock 293 199 262 minecraft:basalt
setblock 294 199 242 minecraft:basalt
setblock 294 199 243 minecraft:magma_block
fill 294 199 246 294 199 247 minecraft:magma_block
fill 294 199 257 294 199 258 minecraft:magma_block
setblock 294 199 261 minecraft:magma_block
setblock 295 199 245 minecraft:basalt
fill 295 199 246 296 199 246 minecraft:magma_block
fill 295 199 258 296 199 258 minecraft:magma_block
setblock 295 199 259 minecraft:basalt
fill 296 199 245 302 199 245 minecraft:magma_block
fill 296 199 259 302 199 259 minecraft:magma_block
setblock 296 199 260 minecraft:basalt
setblock 297 199 242 minecraft:magma_block
setblock 297 199 260 minecraft:magma_block
setblock 297 199 261 minecraft:basalt
setblock 297 199 263 minecraft:magma_block
fill 298 199 241 298 255 242 minecraft:basalt
fill 298 199 263 301 199 263 minecraft:basalt
setblock 299 199 241 minecraft:basalt
setblock 299 199 244 minecraft:basalt
setblock 299 199 262 minecraft:basalt
setblock 300 199 241 minecraft:magma_block
setblock 300 199 244 minecraft:magma_block
setblock 300 199 262 minecraft:magma_block
setblock 300 199 270 minecraft:magma_block
setblock 301 199 241 minecraft:basalt
fill 301 199 260 302 199 260 minecraft:basalt
fill 301 199 262 302 199 262 minecraft:basalt
fill 301 199 270 301 283 270 minecraft:blackstone
setblock 302 199 243 minecraft:basalt
fill 302 199 246 303 199 246 minecraft:magma_block
fill 302 199 258 303 199 258 minecraft:magma_block
setblock 302 199 261 minecraft:basalt
setblock 303 199 243 minecraft:magma_block
setblock 303 199 245 minecraft:basalt
setblock 303 199 261 minecraft:magma_block
setblock 304 199 247 minecraft:magma_block
setblock 304 199 257 minecraft:magma_block
setblock 305 199 242 minecraft:basalt
fill 305 199 248 306 199 249 minecraft:magma_block
fill 305 199 255 305 199 256 minecraft:magma_block
setblock 306 199 245 minecraft:magma_block
fill 306 199 250 306 199 255 minecraft:magma_block
setblock 306 199 256 minecraft:basalt
setblock 306 199 257 minecraft:magma_block
setblock 306 199 260 minecraft:magma_block
setblock 307 199 252 minecraft:basalt
setblock 307 199 260 minecraft:basalt
setblock 309 199 247 minecraft:magma_block
fill 309 199 248 309 199 249 minecraft:basalt
setblock 309 199 250 minecraft:magma_block
fill 309 199 251 309 199 252 minecraft:basalt
setblock 309 199 253 minecraft:magma_block
fill 309 199 254 309 199 255 minecraft:basalt
setblock 309 199 256 minecraft:magma_block
setblock 309 199 257 minecraft:basalt
setblock 309 199 270 minecraft:crying_obsidian
fill 310 199 270 313 223 270 minecraft:blackstone
fill 313 199 264 313 200 264 minecraft:magma_block
fill 318 199 228 318 283 228 minecraft:blackstone
fill 320 199 233 323 199 265 minecraft:blackstone
setblock 324 199 265 minecraft:shroomlight
fill 324 199 266 324 218 267 minecraft:blackstone
fill 282 200 241 282 220 242 minecraft:blackstone
fill 283 200 229 285 200 269 minecraft:magma_block
fill 286 200 229 323 200 231 minecraft:magma_block
fill 286 200 232 286 217 234 minecraft:basalt
fill 286 200 235 288 201 235 minecraft:blackstone
fill 286 200 267 323 200 269 minecraft:magma_block
fill 287 200 232 289 217 232 minecraft:basalt
fill 289 200 234 289 201 234 minecraft:blackstone
fill 290 200 232 290 201 233 minecraft:blackstone
fill 295 200 242 295 255 243 minecraft:basalt
fill 295 200 252 295 201 253 minecraft:magma_block
setblock 295 200 270 minecraft:magma_block
fill 296 200 253 296 201 253 minecraft:magma_block
fill 297 200 242 297 255 242 minecraft:basalt
fill 298 200 243 298 255 243 minecraft:basalt
fill 300 200 270 300 251 270 minecraft:blackstone
fill 304 200 270 304 283 270 minecraft:blackstone
setblock 305 200 270 minecraft:shroomlight
fill 306 200 270 307 247 270 minecraft:blackstone
fill 309 200 270 309 283 270 minecraft:blackstone
fill 321 200 232 323 200 266 minecraft:magma_block
fill 324 200 265 324 208 265 minecraft:blackstone
fill 282 201 243 282 213 247 minecraft:blackstone
fill 282 201 248 284 201 248 minecraft:shroomlight
fill 283 201 229 284 201 247 minecraft:shroomlight
fill 283 201 249 284 201 269 minecraft:shroomlight
fill 285 201 229 323 201 230 minecraft:shroomlight
fill 285 201 231 285 217 233 minecraft:basalt
fill 285 201 234 285 201 236 minecraft:blackstone
setblock 285 201 238 minecraft:light[level=12]
setblock 285 201 245 minecraft:light[level=12]
setblock 285 201 252 minecraft:light[level=12]
setblock 285 201 259 minecraft:light[level=12]
setblock 285 201 266 minecraft:light[level=12]
fill 285 201 268 323 201 269 minecraft:shroomlight
fill 286 201 231 288 217 231 minecraft:basalt
fill 286 201 236 288 201 236 minecraft:blackstone
fill 289 201 231 291 201 231 minecraft:blackstone
fill 289 201 235 290 201 235 minecraft:blackstone
setblock 290 201 234 minecraft:blackstone
fill 291 201 232 291 201 233 minecraft:blackstone
setblock 292 201 231 minecraft:light[level=12]
setblock 292 201 238 minecraft:light[level=12]
setblock 292 201 245 minecraft:light[level=12]
setblock 292 201 252 minecraft:light[level=12]
setblock 292 201 259 minecraft:light[level=12]
setblock 292 201 266 minecraft:light[level=12]
fill 295 201 270 295 245 270 minecraft:blackstone
setblock 299 201 231 minecraft:light[level=12]
setblock 299 201 238 minecraft:light[level=12]
setblock 299 201 245 minecraft:light[level=12]
setblock 299 201 259 minecraft:light[level=12]
setblock 299 201 266 minecraft:light[level=12]
fill 305 201 270 305 273 270 minecraft:blackstone
setblock 306 201 231 minecraft:light[level=12]
setblock 306 201 238 minecraft:light[level=12]
setblock 306 201 245 minecraft:light[level=12]
setblock 306 201 252 minecraft:light[level=12]
setblock 306 201 259 minecraft:light[level=12]
setblock 306 201 266 minecraft:light[level=12]
setblock 313 201 231 minecraft:light[level=12]
setblock 313 201 238 minecraft:light[level=12]
setblock 313 201 245 minecraft:light[level=12]
setblock 313 201 252 minecraft:light[level=12]
setblock 313 201 259 minecraft:light[level=12]
setblock 313 201 266 minecraft:light[level=12]
setblock 320 201 231 minecraft:light[level=12]
setblock 320 201 238 minecraft:light[level=12]
setblock 320 201 245 minecraft:light[level=12]
setblock 320 201 252 minecraft:light[level=12]
setblock 320 201 259 minecraft:light[level=12]
setblock 320 201 266 minecraft:light[level=12]
fill 322 201 231 323 201 267 minecraft:shroomlight
fill 282 202 248 282 245 248 minecraft:blackstone
fill 282 202 267 282 283 267 minecraft:blackstone
setblock 282 202 268 minecraft:shroomlight
fill 282 202 269 282 283 270 minecraft:blackstone
fill 286 202 230 287 217 230 minecraft:basalt
fill 311 202 260 312 203 261 minecraft:basalt
fill 282 203 268 282 212 268 minecraft:blackstone
setblock 282 204 263 minecraft:magma_block
setblock 285 204 239 minecraft:light[level=12]
setblock 285 204 247 minecraft:light[level=12]
setblock 285 204 255 minecraft:light[level=12]
setblock 285 204 263 minecraft:light[level=12]
setblock 293 204 231 minecraft:light[level=12]
setblock 293 204 239 minecraft:light[level=12]
setblock 293 204 247 minecraft:light[level=12]
setblock 293 204 255 minecraft:light[level=12]
setblock 293 204 263 minecraft:light[level=12]
setblock 301 204 231 minecraft:light[level=12]
setblock 301 204 239 minecraft:light[level=12]
setblock 301 204 247 minecraft:light[level=12]
setblock 301 204 255 minecraft:light[level=12]
setblock 301 204 263 minecraft:light[level=12]
setblock 309 204 231 minecraft:light[level=12]
setblock 309 204 239 minecraft:light[level=12]
setblock 309 204 247 minecraft:light[level=12]
setblock 309 204 255 minecraft:light[level=12]
setblock 309 204 263 minecraft:light[level=12]
setblock 317 204 231 minecraft:light[level=12]
setblock 317 204 239 minecraft:light[level=12]
setblock 317 204 247 minecraft:light[level=12]
setblock 317 204 255 minecraft:light[level=12]
setblock 317 204 263 minecraft:light[level=12]
fill 282 205 263 282 283 263 minecraft:blackstone
fill 297 205 228 297 261 228 minecraft:blackstone
setblock 298 205 228 minecraft:magma_block
fill 299 205 228 299 271 228 minecraft:blackstone
setblock 282 206 262 minecraft:magma_block
setblock 288 206 270 minecraft:magma_block
fill 298 206 228 298 283 228 minecraft:blackstone
fill 324 206 240 324 280 242 minecraft:blackstone
setblock 324 206 243 minecraft:magma_block
fill 324 206 244 324 283 244 minecraft:blackstone
fill 282 207 262 282 283 262 minecraft:blackstone
setblock 285 207 238 minecraft:light[level=12]
setblock 285 207 245 minecraft:light[level=12]
setblock 285 207 252 minecraft:light[level=12]
setblock 285 207 259 minecraft:light[level=12]
setblock 285 207 266 minecraft:light[level=12]
fill 288 207 270 288 240 270 minecraft:blackstone
setblock 292 207 231 minecraft:light[level=12]
setblock 292 207 238 minecraft:light[level=12]
setblock 292 207 245 minecraft:light[level=12]
setblock 292 207 252 minecraft:light[level=12]
setblock 292 207 259 minecraft:light[level=12]
setblock 292 207 266 minecraft:light[level=12]
setblock 299 207 231 minecraft:light[level=12]
setblock 299 207 238 minecraft:light[level=12]
setblock 299 207 245 minecraft:light[level=12]
setblock 299 207 259 minecraft:light[level=12]
setblock 299 207 266 minecraft:light[level=12]
setblock 306 207 231 minecraft:light[level=12]
setblock 306 207 238 minecraft:light[level=12]
setblock 306 207 245 minecraft:light[level=12]
setblock 306 207 252 minecraft:light[level=12]
setblock 306 207 259 minecraft:light[level=12]
setblock 306 207 266 minecraft:light[level=12]
setblock 313 207 231 minecraft:light[level=12]
setblock 313 207 238 minecraft:light[level=12]
setblock 313 207 245 minecraft:light[level=12]
setblock 313 207 252 minecraft:light[level=12]
setblock 313 207 259 minecraft:light[level=12]
setblock 313 207 266 minecraft:light[level=12]
setblock 320 207 231 minecraft:light[level=12]
setblock 320 207 238 minecraft:light[level=12]
setblock 320 207 245 minecraft:light[level=12]
setblock 320 207 252 minecraft:light[level=12]
setblock 320 207 259 minecraft:light[level=12]
setblock 320 207 266 minecraft:light[level=12]
fill 324 207 243 324 232 243 minecraft:blackstone
setblock 324 207 259 minecraft:crying_obsidian
fill 324 208 259 324 237 259 minecraft:blackstone
fill 289 209 270 289 283 270 minecraft:blackstone
setblock 290 209 270 minecraft:magma_block
fill 291 209 270 291 263 270 minecraft:blackstone
fill 314 209 246 316 209 247 minecraft:basalt
setblock 324 209 265 minecraft:magma_block
fill 290 210 270 290 248 270 minecraft:blackstone
fill 311 210 260 312 210 262 minecraft:basalt
fill 312 210 263 312 214 263 minecraft:basalt
fill 313 210 260 313 210 261 minecraft:basalt
fill 314 210 246 314 210 247 minecraft:basalt
fill 315 210 245 316 210 245 minecraft:basalt
fill 315 210 246 315 210 247 minecraft:magma_block
fill 315 210 248 316 210 248 minecraft:basalt
fill 316 210 246 318 210 247 minecraft:basalt
fill 324 210 265 324 283 265 minecraft:blackstone
setblock 285 211 239 minecraft:light[level=12]
setblock 285 211 247 minecraft:light[level=12]
setblock 285 211 255 minecraft:light[level=12]
setblock 285 211 263 minecraft:light[level=12]
setblock 293 211 231 minecraft:light[level=12]
setblock 293 211 239 minecraft:light[level=12]
setblock 293 211 247 minecraft:light[level=12]
setblock 293 211 255 minecraft:light[level=12]
setblock 293 211 263 minecraft:light[level=12]
setblock 301 211 231 minecraft:light[level=12]
setblock 301 211 239 minecraft:light[level=12]
setblock 301 211 247 minecraft:light[level=12]
setblock 301 211 255 minecraft:light[level=12]
setblock 301 211 263 minecraft:light[level=12]
setblock 309 211 231 minecraft:light[level=12]
setblock 309 211 239 minecraft:light[level=12]
setblock 309 211 247 minecraft:light[level=12]
setblock 309 211 255 minecraft:light[level=12]
setblock 309 211 263 minecraft:light[level=12]
fill 310 211 259 312 211 261 minecraft:basalt
fill 311 211 258 312 212 258 minecraft:basalt
fill 311 211 262 311 215 262 minecraft:basalt
setblock 311 211 263 minecraft:magma_block
setblock 312 211 262 minecraft:magma_block
fill 312 211 264 313 212 264 minecraft:basalt
fill 313 211 259 313 211 260 minecraft:basalt
setblock 313 211 261 minecraft:magma_block
fill 313 211 262 314 212 263 minecraft:basalt
fill 314 211 261 314 215 261 minecraft:basalt
fill 315 211 246 316 211 247 minecraft:basalt
fill 316 211 245 317 211 245 minecraft:basalt
fill 316 211 248 317 211 248 minecraft:basalt
setblock 317 211 231 minecraft:light[level=12]
setblock 317 211 239 minecraft:light[level=12]
fill 317 211 246 317 211 247 minecraft:magma_block
setblock 317 211 255 minecraft:light[level=12]
setblock 317 211 263 minecraft:light[level=12]
fill 318 211 246 319 211 247 minecraft:basalt
setblock 324 211 230 minecraft:magma_block
fill 291 212 228 293 218 228 minecraft:blackstone
setblock 294 212 228 minecraft:shroomlight
fill 295 212 228 296 212 228 minecraft:blackstone
fill 296 212 270 297 278 270 minecraft:blackstone
setblock 298 212 270 minecraft:shroomlight
fill 309 212 261 310 212 261 minecraft:basalt
fill 310 212 258 310 212 260 minecraft:basalt
setblock 310 212 262 minecraft:magma_block
fill 311 212 259 311 212 260 minecraft:basalt
setblock 311 212 261 minecraft:magma_block
fill 311 212 263 311 213 263 minecraft:basalt
fill 312 212 259 312 214 259 minecraft:basalt
setblock 312 212 260 minecraft:magma_block
fill 312 212 261 312 213 262 minecraft:basalt
setblock 313 212 258 minecraft:basalt
setblock 313 212 259 minecraft:magma_block
fill 313 212 260 313 213 261 minecraft:basalt
fill 314 212 260 314 213 260 minecraft:basalt
fill 316 212 246 317 212 247 minecraft:basalt
fill 318 212 245 319 212 245 minecraft:basalt
fill 318 212 246 319 212 247 minecraft:magma_block
fill 318 212 248 319 212 248 minecraft:basalt
fill 320 212 246 321 212 247 minecraft:basalt
setblock 324 212 230 minecraft:blackstone
setblock 282 213 268 minecraft:magma_block
setblock 285 213 238 minecraft:light[level=12]
setblock 285 213 245 minecraft:light[level=12]
setblock 285 213 252 minecraft:light[level=12]
setblock 285 213 259 minecraft:light[level=12]
setblock 285 213 266 minecraft:light[level=12]
setblock 292 213 231 minecraft:light[level=12]
setblock 292 213 238 minecraft:light[level=12]
setblock 292 213 245 minecraft:light[level=12]
setblock 292 213 252 minecraft:light[level=12]
setblock 292 213 259 minecraft:light[level=12]
setblock 292 213 266 minecraft:light[level=12]
fill 294 213 228 294 283 228 minecraft:blackstone
fill 294 213 260 295 213 262 minecraft:polished_blackstone
setblock 295 213 228 minecraft:shroomlight
fill 296 213 228 296 263 228 minecraft:blackstone
fill 298 213 270 298 283 270 minecraft:blackstone
setblock 299 213 231 minecraft:light[level=12]
setblock 299 213 238 minecraft:light[level=12]
setblock 299 213 245 minecraft:light[level=12]
setblock 299 213 252 minecraft:light[level=12]
setblock 299 213 259 minecraft:light[level=12]
setblock 299 213 266 minecraft:light[level=12]
fill 304 213 228 304 283 228 minecraft:blackstone
setblock 305 213 228 minecraft:crying_obsidian
setblock 306 213 231 minecraft:light[level=12]
setblock 306 213 238 minecraft:light[level=12]
setblock 306 213 245 minecraft:light[level=12]
setblock 306 213 252 minecraft:light[level=12]
setblock 306 213 259 minecraft:light[level=12]
setblock 306 213 266 minecraft:light[level=12]
setblock 309 213 261 minecraft:magma_block
fill 309 213 262 310 214 262 minecraft:basalt
fill 310 213 259 310 214 259 minecraft:basalt
setblock 310 213 260 minecraft:magma_block
fill 310 213 261 311 214 261 minecraft:basalt
fill 310 213 263 310 215 263 minecraft:basalt
setblock 311 213 258 minecraft:basalt
setblock 311 213 259 minecraft:magma_block
fill 311 213 260 312 214 260 minecraft:basalt
setblock 312 213 258 minecraft:magma_block
setblock 313 213 231 minecraft:light[level=12]
setblock 313 213 238 minecraft:light[level=12]
setblock 313 213 245 minecraft:light[level=12]
setblock 313 213 252 minecraft:light[level=12]
fill 313 213 259 313 214 259 minecraft:basalt
fill 313 213 262 313 214 262 minecraft:basalt
setblock 313 213 263 minecraft:magma_block
setblock 313 213 266 minecraft:light[level=12]
setblock 314 213 262 minecraft:magma_block
setblock 314 213 263 minecraft:basalt
fill 318 213 246 319 213 247 minecraft:basalt
setblock 320 213 231 minecraft:light[level=12]
setblock 320 213 238 minecraft:light[level=12]
fill 320 213 245 321 213 245 minecraft:basalt
fill 320 213 246 320 213 247 minecraft:magma_block
fill 320 213 248 321 213 248 minecraft:basalt
setblock 320 213 252 minecraft:light[level=12]
setblock 320 213 259 minecraft:light[level=12]
setblock 320 213 266 minecraft:light[level=12]
fill 321 213 246 322 213 247 minecraft:basalt
setblock 324 213 230 minecraft:magma_block
fill 282 214 243 282 252 244 minecraft:blackstone
setblock 282 214 245 minecraft:shroomlight
fill 282 214 246 282 216 247 minecraft:blackstone
fill 282 214 268 282 283 268 minecraft:blackstone
fill 293 214 261 293 214 262 minecraft:polished_blackstone
fill 294 214 260 295 214 260 minecraft:polished_blackstone
fill 294 214 261 295 214 262 minecraft:magma_block
fill 294 214 263 295 214 264 minecraft:polished_blackstone
fill 295 214 228 295 283 228 minecraft:blackstone
fill 296 214 261 296 214 262 minecraft:polished_blackstone
setblock 303 214 228 minecraft:magma_block
fill 305 214 228 305 283 228 minecraft:blackstone
setblock 309 214 261 minecraft:basalt
fill 310 214 260 310 215 260 minecraft:basalt
setblock 311 214 259 minecraft:basalt
setblock 311 214 263 minecraft:magma_block
fill 312 214 261 312 215 261 minecraft:basalt
setblock 312 214 262 minecraft:magma_block
fill 313 214 260 313 215 260 minecraft:basalt
setblock 313 214 261 minecraft:magma_block
setblock 314 214 259 minecraft:basalt
setblock 314 214 260 minecraft:magma_block
setblock 314 214 262 minecraft:basalt
fill 319 214 246 321 214 247 minecraft:basalt
fill 319 214 255 319 215 256 minecraft:blackstone
fill 321 214 245 322 214 245 minecraft:basalt
fill 321 214 248 322 214 248 minecraft:basalt
fill 322 214 246 322 214 247 minecraft:magma_block
fill 323 214 246 323 215 247 minecraft:basalt
fill 324 214 230 324 223 230 minecraft:blackstone
fill 282 215 245 282 252 245 minecraft:blackstone
fill 293 215 263 293 215 264 minecraft:polished_blackstone
fill 294 215 261 295 215 262 minecraft:polished_blackstone
fill 294 215 263 295 215 264 minecraft:magma_block
fill 294 215 265 295 215 266 minecraft:polished_blackstone
fill 296 215 263 296 215 264 minecraft:polished_blackstone
fill 303 215 228 303 251 228 minecraft:blackstone
setblock 310 215 262 minecraft:magma_block
setblock 311 215 260 minecraft:basalt
setblock 311 215 261 minecraft:magma_block
setblock 311 215 263 minecraft:basalt
setblock 312 215 260 minecraft:magma_block
setblock 312 215 262 minecraft:basalt
setblock 313 215 261 minecraft:basalt
setblock 314 215 260 minecraft:basalt
fill 321 215 246 322 215 247 minecraft:basalt
setblock 324 215 261 minecraft:shroomlight
fill 282 216 236 282 283 236 minecraft:blackstone
setblock 282 216 237 minecraft:magma_block
fill 282 216 238 282 283 238 minecraft:blackstone
setblock 282 216 239 minecraft:shroomlight
setblock 283 216 270 minecraft:crying_obsidian
fill 284 216 270 284 283 270 minecraft:blackstone
fill 293 216 265 293 216 266 minecraft:polished_blackstone
fill 294 216 263 295 216 264 minecraft:polished_blackstone
fill 294 216 265 295 216 266 minecraft:magma_block
fill 294 216 267 295 216 268 minecraft:polished_blackstone
fill 296 216 265 296 216 266 minecraft:polished_blackstone
fill 324 216 261 324 270 261 minecraft:blackstone
fill 282 217 237 282 283 237 minecraft:blackstone
fill 282 217 239 282 229 239 minecraft:blackstone
fill 282 217 246 282 283 246 minecraft:blackstone
setblock 282 217 247 minecraft:shroomlight
setblock 282 217 259 minecraft:magma_block
fill 282 217 260 282 283 260 minecraft:blackstone
fill 283 217 270 283 283 270 minecraft:blackstone
fill 293 217 267 293 217 268 minecraft:polished_blackstone
fill 294 217 265 295 217 266 minecraft:polished_blackstone
fill 294 217 267 295 217 268 minecraft:magma_block
fill 294 217 269 295 218 269 minecraft:polished_blackstone
fill 296 217 267 296 217 268 minecraft:polished_blackstone
fill 282 218 247 286 218 247 minecraft:blackstone
fill 282 218 259 286 218 259 minecraft:blackstone
fill 283 218 229 286 218 246 minecraft:blackstone
fill 283 218 248 286 218 258 minecraft:blackstone
fill 283 218 260 286 218 269 minecraft:blackstone
fill 287 218 229 323 218 232 minecraft:blackstone
fill 287 218 266 293 218 269 minecraft:blackstone
setblock 293 218 239 minecraft:light[level=12]
setblock 293 218 247 minecraft:light[level=12]
setblock 293 218 255 minecraft:light[level=12]
setblock 293 218 263 minecraft:light[level=12]
fill 294 218 266 323 218 266 minecraft:blackstone
fill 294 218 267 295 218 268 minecraft:polished_blackstone
fill 296 218 267 323 218 269 minecraft:blackstone
setblock 301 218 239 minecraft:light[level=12]
setblock 301 218 247 minecraft:light[level=12]
setblock 301 218 255 minecraft:light[level=12]
setblock 301 218 263 minecraft:light[level=12]
setblock 309 218 239 minecraft:light[level=12]
setblock 309 218 247 minecraft:light[level=12]
setblock 309 218 255 minecraft:light[level=12]
setblock 309 218 263 minecraft:light[level=12]
setblock 317 218 239 minecraft:light[level=12]
setblock 317 218 247 minecraft:light[level=12]
setblock 317 218 255 minecraft:light[level=12]
setblock 317 218 263 minecraft:light[level=12]
fill 320 218 233 323 218 265 minecraft:blackstone
fill 282 219 247 282 283 247 minecraft:blackstone
fill 282 219 259 282 234 259 minecraft:blackstone
fill 283 219 229 285 219 269 minecraft:magma_block
fill 286 219 229 323 219 231 minecraft:magma_block
fill 286 219 232 286 236 234 minecraft:basalt
fill 286 219 267 323 219 269 minecraft:magma_block
fill 287 219 232 289 236 232 minecraft:basalt
fill 291 219 228 292 265 228 minecraft:blackstone
setblock 292 219 238 minecraft:light[level=12]
setblock 292 219 245 minecraft:light[level=12]
setblock 292 219 252 minecraft:light[level=12]
setblock 292 219 259 minecraft:light[level=12]
setblock 292 219 266 minecraft:light[level=12]
setblock 293 219 228 minecraft:crying_obsidian
setblock 299 219 238 minecraft:light[level=12]
setblock 299 219 245 minecraft:light[level=12]
setblock 299 219 252 minecraft:light[level=12]
setblock 299 219 259 minecraft:light[level=12]
setblock 299 219 266 minecraft:light[level=12]
setblock 299 219 270 minecraft:magma_block
setblock 306 219 238 minecraft:light[level=12]
setblock 306 219 245 minecraft:light[level=12]
setblock 306 219 252 minecraft:light[level=12]
setblock 306 219 259 minecraft:light[level=12]
setblock 306 219 266 minecraft:light[level=12]
setblock 313 219 238 minecraft:light[level=12]
setblock 313 219 245 minecraft:light[level=12]
setblock 313 219 252 minecraft:light[level=12]
setblock 313 219 259 minecraft:light[level=12]
setblock 313 219 266 minecraft:light[level=12]
setblock 320 219 238 minecraft:light[level=12]
setblock 320 219 245 minecraft:light[level=12]
setblock 320 219 252 minecraft:light[level=12]
setblock 320 219 259 minecraft:light[level=12]
setblock 320 219 266 minecraft:light[level=12]
fill 321 219 232 323 219 266 minecraft:magma_block
fill 324 219 266 324 283 266 minecraft:blackstone
setblock 324 219 267 minecraft:crying_obsidian
fill 282 220 261 284 220 261 minecraft:shroomlight
fill 283 220 229 284 220 260 minecraft:shroomlight
fill 283 220 262 284 220 269 minecraft:shroomlight
fill 285 220 229 323 220 230 minecraft:shroomlight
fill 285 220 231 285 236 233 minecraft:basalt
fill 285 220 268 323 220 269 minecraft:shroomlight
fill 286 220 231 288 236 231 minecraft:basalt
fill 293 220 228 293 283 228 minecraft:blackstone
fill 299 220 270 299 257 270 minecraft:blackstone
fill 322 220 231 323 220 267 minecraft:shroomlight
fill 324 220 267 324 283 267 minecraft:blackstone
fill 282 221 241 282 281 241 minecraft:blackstone
setblock 282 221 242 minecraft:crying_obsidian
fill 282 221 261 282 226 261 minecraft:blackstone
setblock 286 221 228 minecraft:crying_obsidian
fill 286 221 230 287 236 230 minecraft:basalt
fill 287 221 228 289 278 228 minecraft:blackstone
fill 301 221 260 303 222 260 minecraft:basalt
fill 302 221 261 304 221 261 minecraft:basalt
fill 303 221 259 303 222 259 minecraft:basalt
fill 303 221 262 303 223 262 minecraft:basalt
setblock 304 221 262 minecraft:magma_block
fill 282 222 242 282 283 242 minecraft:blackstone
fill 286 222 228 286 253 228 minecraft:blackstone
setblock 300 222 260 minecraft:basalt
fill 301 222 259 302 223 259 minecraft:basalt
fill 301 222 261 302 222 261 minecraft:basalt
setblock 302 222 262 minecraft:magma_block
setblock 303 222 258 minecraft:basalt
setblock 303 222 261 minecraft:magma_block
fill 304 222 259 304 223 259 minecraft:basalt
setblock 304 222 260 minecraft:magma_block
fill 304 222 261 304 222 262 minecraft:basalt
setblock 301 223 260 minecraft:basalt
setblock 301 223 261 minecraft:magma_block
fill 301 223 262 302 223 262 minecraft:basalt
setblock 302 223 258 minecraft:basalt
setblock 302 223 260 minecraft:magma_block
fill 302 223 261 304 223 261 minecraft:basalt
setblock 303 223 259 minecraft:magma_block
fill 303 223 260 304 224 260 minecraft:basalt
setblock 282 224 233 minecraft:shroomlight
fill 282 224 234 282 259 234 minecraft:blackstone
fill 301 224 261 303 224 261 minecraft:basalt
fill 302 224 259 302 224 260 minecraft:basalt
setblock 302 224 262 minecraft:basalt
setblock 303 224 259 minecraft:basalt
fill 310 224 270 311 283 270 minecraft:blackstone
setblock 312 224 270 minecraft:crying_obsidian
fill 313 224 270 313 234 270 minecraft:blackstone
setblock 322 224 228 minecraft:crying_obsidian
setblock 324 224 230 minecraft:crying_obsidian
fill 324 224 247 324 225 248 minecraft:blackstone
setblock 324 224 249 minecraft:magma_block
fill 324 224 250 324 242 253 minecraft:blackstone
fill 282 225 228 282 283 228 minecraft:blackstone
fill 282 225 233 282 259 233 minecraft:blackstone
setblock 283 225 228 minecraft:magma_block
fill 284 225 228 285 283 228 minecraft:blackstone
fill 285 225 238 285 225 239 minecraft:light[level=12]
setblock 285 225 245 minecraft:light[level=12]
setblock 285 225 247 minecraft:light[level=12]
setblock 285 225 252 minecraft:light[level=12]
setblock 285 225 255 minecraft:light[level=12]
setblock 285 225 259 minecraft:light[level=12]
setblock 285 225 263 minecraft:light[level=12]
setblock 285 225 266 minecraft:light[level=12]
setblock 286 225 270 minecraft:magma_block
fill 287 225 270 287 250 270 minecraft:blackstone
fill 292 225 231 293 225 231 minecraft:light[level=12]
setblock 292 225 238 minecraft:light[level=12]
setblock 292 225 245 minecraft:light[level=12]
setblock 292 225 252 minecraft:light[level=12]
setblock 292 225 259 minecraft:light[level=12]
setblock 292 225 266 minecraft:light[level=12]
setblock 293 225 239 minecraft:light[level=12]
setblock 293 225 247 minecraft:light[level=12]
setblock 293 225 255 minecraft:light[level=12]
setblock 293 225 263 minecraft:light[level=12]
setblock 299 225 231 minecraft:light[level=12]
setblock 299 225 238 minecraft:light[level=12]
setblock 299 225 245 minecraft:light[level=12]
setblock 299 225 252 minecraft:light[level=12]
setblock 299 225 259 minecraft:light[level=12]
setblock 299 225 266 minecraft:light[level=12]
setblock 301 225 231 minecraft:light[level=12]
setblock 301 225 239 minecraft:light[level=12]
setblock 301 225 247 minecraft:light[level=12]
setblock 301 225 255 minecraft:light[level=12]
setblock 301 225 263 minecraft:light[level=12]
setblock 306 225 231 minecraft:light[level=12]
setblock 306 225 238 minecraft:light[level=12]
setblock 306 225 245 minecraft:light[level=12]
setblock 306 225 252 minecraft:light[level=12]
setblock 306 225 259 minecraft:light[level=12]
setblock 306 225 266 minecraft:light[level=12]
setblock 309 225 231 minecraft:light[level=12]
setblock 309 225 239 minecraft:light[level=12]
setblock 309 225 247 minecraft:light[level=12]
setblock 309 225 255 minecraft:light[level=12]
setblock 309 225 263 minecraft:light[level=12]
fill 312 225 270 312 283 270 minecraft:blackstone
setblock 313 225 231 minecraft:light[level=12]
setblock 313 225 238 minecraft:light[level=12]
setblock 313 225 245 minecraft:light[level=12]
setblock 313 225 252 minecraft:light[level=12]
setblock 313 225 259 minecraft:light[level=12]
setblock 313 225 266 minecraft:light[level=12]
setblock 317 225 231 minecraft:light[level=12]
setblock 317 225 239 minecraft:light[level=12]
setblock 317 225 247 minecraft:light[level=12]
setblock 317 225 255 minecraft:light[level=12]
setblock 317 225 263 minecraft:light[level=12]
setblock 320 225 231 minecraft:light[level=12]
setblock 320 225 238 minecraft:light[level=12]
setblock 320 225 245 minecraft:light[level=12]
setblock 320 225 252 minecraft:light[level=12]
setblock 320 225 259 minecraft:light[level=12]
setblock 320 225 266 minecraft:light[level=12]
fill 322 225 228 322 283 228 minecraft:blackstone
fill 324 225 230 324 283 230 minecraft:blackstone
fill 324 225 249 324 237 249 minecraft:blackstone
fill 283 226 228 283 269 228 minecraft:blackstone
fill 286 226 270 286 283 270 minecraft:blackstone
fill 324 226 247 324 263 247 minecraft:blackstone
setblock 324 226 248 minecraft:magma_block
setblock 282 227 261 minecraft:crying_obsidian
fill 324 227 248 324 283 248 minecraft:blackstone
fill 282 228 261 282 283 261 minecraft:blackstone
fill 302 229 238 303 230 239 minecraft:basalt
setblock 282 230 239 minecraft:crying_obsidian
fill 282 231 239 282 283 239 minecraft:blackstone
setblock 285 231 238 minecraft:light[level=12]
setblock 285 231 245 minecraft:light[level=12]
setblock 285 231 252 minecraft:light[level=12]
setblock 285 231 259 minecraft:light[level=12]
setblock 285 231 266 minecraft:light[level=12]
setblock 292 231 231 minecraft:light[level=12]
setblock 292 231 238 minecraft:light[level=12]
setblock 292 231 245 minecraft:light[level=12]
setblock 292 231 252 minecraft:light[level=12]
setblock 292 231 259 minecraft:light[level=12]
setblock 292 231 266 minecraft:light[level=12]
setblock 299 231 231 minecraft:light[level=12]
setblock 299 231 238 minecraft:light[level=12]
setblock 299 231 245 minecraft:light[level=12]
setblock 299 231 252 minecraft:light[level=12]
setblock 299 231 259 minecraft:light[level=12]
setblock 299 231 266 minecraft:light[level=12]
setblock 306 231 231 minecraft:light[level=12]
setblock 306 231 238 minecraft:light[level=12]
setblock 306 231 245 minecraft:light[level=12]
setblock 306 231 252 minecraft:light[level=12]
setblock 306 231 259 minecraft:light[level=12]
setblock 306 231 266 minecraft:light[level=12]
setblock 313 231 231 minecraft:light[level=12]
setblock 313 231 238 minecraft:light[level=12]
setblock 313 231 245 minecraft:light[level=12]
setblock 313 231 252 minecraft:light[level=12]
setblock 313 231 259 minecraft:light[level=12]
setblock 313 231 266 minecraft:light[level=12]
setblock 320 231 231 minecraft:light[level=12]
setblock 320 231 238 minecraft:light[level=12]
setblock 320 231 245 minecraft:light[level=12]
setblock 320 231 252 minecraft:light[level=12]
setblock 320 231 259 minecraft:light[level=12]
setblock 320 231 266 minecraft:light[level=12]
fill 324 231 257 324 258 257 minecraft:blackstone
setblock 324 231 258 minecraft:crying_obsidian
fill 282 232 251 282 283 253 minecraft:blackstone
setblock 282 232 254 minecraft:shroomlight
fill 282 232 255 282 261 257 minecraft:blackstone
setblock 285 232 239 minecraft:light[level=12]
setblock 285 232 247 minecraft:light[level=12]
setblock 285 232 255 minecraft:light[level=12]
setblock 285 232 263 minecraft:light[level=12]
setblock 293 232 231 minecraft:light[level=12]
setblock 293 232 239 minecraft:light[level=12]
setblock 293 232 247 minecraft:light[level=12]
setblock 293 232 255 minecraft:light[level=12]
setblock 293 232 263 minecraft:light[level=12]
setblock 300 232 228 minecraft:magma_block
fill 301 232 228 301 283 228 minecraft:blackstone
setblock 301 232 231 minecraft:light[level=12]
setblock 301 232 239 minecraft:light[level=12]
setblock 301 232 247 minecraft:light[level=12]
setblock 301 232 255 minecraft:light[level=12]
setblock 301 232 263 minecraft:light[level=12]
setblock 309 232 231 minecraft:light[level=12]
setblock 309 232 239 minecraft:light[level=12]
setblock 309 232 247 minecraft:light[level=12]
setblock 309 232 255 minecraft:light[level=12]
setblock 309 232 263 minecraft:light[level=12]
setblock 317 232 231 minecraft:light[level=12]
setblock 317 232 239 minecraft:light[level=12]
setblock 317 232 247 minecraft:light[level=12]
setblock 317 232 255 minecraft:light[level=12]
setblock 317 232 263 minecraft:light[level=12]
setblock 321 232 270 minecraft:magma_block
fill 322 232 270 322 283 270 minecraft:blackstone
fill 324 232 258 324 283 258 minecraft:blackstone
fill 282 233 254 282 283 254 minecraft:blackstone
setblock 282 233 264 minecraft:crying_obsidian
fill 300 233 228 300 283 228 minecraft:blackstone
fill 321 233 270 321 283 270 minecraft:blackstone
setblock 324 233 243 minecraft:shroomlight
fill 282 234 264 282 283 264 minecraft:blackstone
fill 324 234 243 324 283 243 minecraft:blackstone
setblock 282 235 259 minecraft:shroomlight
setblock 313 235 270 minecraft:shroomlight
setblock 315 235 228 minecraft:magma_block
fill 282 236 259 282 283 259 minecraft:blackstone
setblock 302 236 270 minecraft:shroomlight
fill 313 236 270 313 283 270 minecraft:blackstone
fill 315 236 228 315 245 228 minecraft:blackstone
fill 283 237 229 286 237 269 minecraft:blackstone
fill 287 237 229 323 237 232 minecraft:blackstone
fill 287 237 266 323 237 269 minecraft:blackstone
setblock 292 237 238 minecraft:light[level=12]
setblock 292 237 245 minecraft:light[level=12]
setblock 292 237 252 minecraft:light[level=12]
setblock 292 237 259 minecraft:light[level=12]
setblock 299 237 238 minecraft:light[level=12]
setblock 299 237 245 minecraft:light[level=12]
setblock 299 237 252 minecraft:light[level=12]
setblock 299 237 259 minecraft:light[level=12]
fill 302 237 270 302 283 270 minecraft:blackstone
setblock 306 237 238 minecraft:light[level=12]
setblock 306 237 245 minecraft:light[level=12]
setblock 306 237 252 minecraft:light[level=12]
setblock 306 237 259 minecraft:light[level=12]
setblock 308 237 270 minecraft:magma_block
setblock 313 237 238 minecraft:light[level=12]
setblock 313 237 245 minecraft:light[level=12]
setblock 313 237 252 minecraft:light[level=12]
setblock 313 237 259 minecraft:light[level=12]
fill 319 237 270 319 257 270 minecraft:blackstone
fill 320 237 233 323 237 265 minecraft:blackstone
setblock 320 237 270 minecraft:shroomlight
fill 283 238 229 285 238 269 minecraft:magma_block
fill 286 238 229 323 238 231 minecraft:magma_block
fill 286 238 232 286 255 234 minecraft:basalt
fill 286 238 267 323 238 269 minecraft:magma_block
fill 287 238 232 289 255 232 minecraft:basalt
fill 308 238 270 308 253 270 minecraft:blackstone
setblock 319 238 228 minecraft:magma_block
fill 320 238 228 320 263 228 minecraft:blackstone
fill 320 238 270 320 283 270 minecraft:blackstone
fill 321 238 232 323 238 266 minecraft:magma_block
setblock 324 238 249 minecraft:magma_block
setblock 324 238 259 minecraft:crying_obsidian
fill 283 239 229 284 239 269 minecraft:shroomlight
fill 285 239 229 323 239 230 minecraft:shroomlight
fill 285 239 231 285 255 233 minecraft:basalt
setblock 285 239 239 minecraft:light[level=12]
setblock 285 239 247 minecraft:light[level=12]
setblock 285 239 255 minecraft:light[level=12]
setblock 285 239 263 minecraft:light[level=12]
fill 285 239 268 323 239 269 minecraft:shroomlight
fill 286 239 231 288 255 231 minecraft:basalt
setblock 293 239 231 minecraft:light[level=12]
setblock 293 239 239 minecraft:light[level=12]
setblock 293 239 247 minecraft:light[level=12]
setblock 293 239 255 minecraft:light[level=12]
setblock 293 239 263 minecraft:light[level=12]
setblock 301 239 231 minecraft:light[level=12]
setblock 301 239 239 minecraft:light[level=12]
setblock 301 239 247 minecraft:light[level=12]
setblock 301 239 255 minecraft:light[level=12]
setblock 301 239 263 minecraft:light[level=12]
setblock 309 239 231 minecraft:light[level=12]
setblock 309 239 239 minecraft:light[level=12]
setblock 309 239 247 minecraft:light[level=12]
setblock 309 239 255 minecraft:light[level=12]
setblock 309 239 263 minecraft:light[level=12]
setblock 317 239 231 minecraft:light[level=12]
setblock 317 239 239 minecraft:light[level=12]
setblock 317 239 247 minecraft:light[level=12]
setblock 317 239 255 minecraft:light[level=12]
setblock 317 239 263 minecraft:light[level=12]
fill 319 239 228 319 254 228 minecraft:blackstone
fill 322 239 231 323 239 267 minecraft:shroomlight
fill 324 239 249 324 276 249 minecraft:blackstone
fill 324 239 259 324 283 259 minecraft:blackstone
fill 286 240 230 287 255 230 minecraft:basalt
setblock 288 241 270 minecraft:shroomlight
fill 288 242 270 288 283 270 minecraft:blackstone
fill 307 242 228 307 283 228 minecraft:blackstone
setblock 308 242 228 minecraft:magma_block
setblock 285 243 238 minecraft:light[level=12]
setblock 285 243 245 minecraft:light[level=12]
setblock 285 243 252 minecraft:light[level=12]
setblock 285 243 259 minecraft:light[level=12]
setblock 285 243 266 minecraft:light[level=12]
setblock 292 243 231 minecraft:light[level=12]
setblock 292 243 238 minecraft:light[level=12]
setblock 292 243 245 minecraft:light[level=12]
setblock 292 243 252 minecraft:light[level=12]
setblock 292 243 259 minecraft:light[level=12]
setblock 292 243 266 minecraft:light[level=12]
setblock 299 243 231 minecraft:light[level=12]
setblock 299 243 238 minecraft:light[level=12]
setblock 299 243 245 minecraft:light[level=12]
setblock 299 243 252 minecraft:light[level=12]
setblock 299 243 259 minecraft:light[level=12]
setblock 299 243 266 minecraft:light[level=12]
setblock 306 243 231 minecraft:light[level=12]
setblock 306 243 238 minecraft:light[level=12]
setblock 306 243 245 minecraft:light[level=12]
setblock 306 243 252 minecraft:light[level=12]
setblock 306 243 259 minecraft:light[level=12]
setblock 306 243 266 minecraft:light[level=12]
fill 308 243 228 308 264 228 minecraft:blackstone
setblock 313 243 231 minecraft:light[level=12]
setblock 313 243 238 minecraft:light[level=12]
setblock 313 243 245 minecraft:light[level=12]
setblock 313 243 252 minecraft:light[level=12]
setblock 313 243 259 minecraft:light[level=12]
setblock 313 243 266 minecraft:light[level=12]
setblock 320 243 231 minecraft:light[level=12]
setblock 320 243 238 minecraft:light[level=12]
setblock 320 243 245 minecraft:light[level=12]
setblock 320 243 252 minecraft:light[level=12]
setblock 320 243 259 minecraft:light[level=12]
setblock 320 243 266 minecraft:light[level=12]
fill 324 243 250 324 264 251 minecraft:blackstone
setblock 324 243 252 minecraft:magma_block
fill 324 243 253 324 283 253 minecraft:blackstone
fill 324 244 252 324 254 252 minecraft:blackstone
fill 300 245 264 300 252 264 minecraft:basalt
setblock 282 246 248 minecraft:crying_obsidian
setblock 285 246 239 minecraft:light[level=12]
setblock 285 246 247 minecraft:light[level=12]
setblock 285 246 255 minecraft:light[level=12]
setblock 285 246 263 minecraft:light[level=12]
setblock 293 246 231 minecraft:light[level=12]
setblock 293 246 239 minecraft:light[level=12]
setblock 293 246 247 minecraft:light[level=12]
setblock 293 246 255 minecraft:light[level=12]
setblock 293 246 263 minecraft:light[level=12]
setblock 295 246 270 minecraft:magma_block
setblock 301 246 231 minecraft:light[level=12]
setblock 301 246 239 minecraft:light[level=12]
setblock 301 246 247 minecraft:light[level=12]
setblock 301 246 255 minecraft:light[level=12]
setblock 301 246 263 minecraft:light[level=12]
setblock 309 246 231 minecraft:light[level=12]
setblock 309 246 239 minecraft:light[level=12]
setblock 309 246 247 minecraft:light[level=12]
setblock 309 246 255 minecraft:light[level=12]
setblock 309 246 263 minecraft:light[level=12]
setblock 315 246 228 minecraft:crying_obsidian
setblock 317 246 231 minecraft:light[level=12]
setblock 317 246 239 minecraft:light[level=12]
setblock 317 246 247 minecraft:light[level=12]
setblock 317 246 255 minecraft:light[level=12]
setblock 317 246 263 minecraft:light[level=12]
fill 282 247 248 282 283 248 minecraft:blackstone
fill 295 247 270 295 283 270 minecraft:blackstone
fill 315 247 228 315 283 228 minecraft:blackstone
fill 306 248 270 306 258 270 minecraft:blackstone
setblock 307 248 270 minecraft:magma_block
setblock 285 249 238 minecraft:light[level=12]
setblock 285 249 245 minecraft:light[level=12]
setblock 285 249 252 minecraft:light[level=12]
setblock 285 249 259 minecraft:light[level=12]
setblock 285 249 266 minecraft:light[level=12]
setblock 290 249 270 minecraft:magma_block
setblock 292 249 231 minecraft:light[level=12]
setblock 292 249 238 minecraft:light[level=12]
setblock 292 249 245 minecraft:light[level=12]
setblock 292 249 252 minecraft:light[level=12]
setblock 292 249 259 minecraft:light[level=12]
setblock 292 249 266 minecraft:light[level=12]
setblock 299 249 231 minecraft:light[level=12]
setblock 299 249 238 minecraft:light[level=12]
setblock 299 249 245 minecraft:light[level=12]
setblock 299 249 252 minecraft:light[level=12]
setblock 299 249 259 minecraft:light[level=12]
fill 299 249 264 299 252 264 minecraft:basalt
setblock 299 249 266 minecraft:light[level=12]
fill 300 249 263 300 252 263 minecraft:basalt
fill 300 249 265 300 252 265 minecraft:basalt
fill 301 249 264 301 252 264 minecraft:basalt
setblock 306 249 231 minecraft:light[level=12]
setblock 306 249 238 minecraft:light[level=12]
setblock 306 249 245 minecraft:light[level=12]
setblock 306 249 252 minecraft:light[level=12]
setblock 306 249 259 minecraft:light[level=12]
setblock 306 249 266 minecraft:light[level=12]
fill 307 249 270 307 283 270 minecraft:blackstone
setblock 313 249 231 minecraft:light[level=12]
setblock 313 249 238 minecraft:light[level=12]
setblock 313 249 245 minecraft:light[level=12]
setblock 313 249 252 minecraft:light[level=12]
setblock 313 249 259 minecraft:light[level=12]
setblock 313 249 266 minecraft:light[level=12]
setblock 320 249 231 minecraft:light[level=12]
setblock 320 249 238 minecraft:light[level=12]
setblock 320 249 245 minecraft:light[level=12]
setblock 320 249 252 minecraft:light[level=12]
setblock 320 249 259 minecraft:light[level=12]
setblock 320 249 266 minecraft:light[level=12]
fill 290 250 270 290 283 270 minecraft:blackstone
fill 299 250 263 299 252 263 minecraft:basalt
fill 299 250 265 299 252 265 minecraft:basalt
fill 301 250 263 301 252 263 minecraft:basalt
fill 301 250 265 301 252 265 minecraft:basalt
setblock 324 250 263 minecraft:crying_obsidian
fill 324 250 264 324 283 264 minecraft:blackstone
setblock 287 251 270 minecraft:shroomlight
setblock 292 251 270 minecraft:shroomlight
setblock 323 251 228 minecraft:magma_block
fill 324 251 228 324 283 228 minecraft:blackstone
setblock 324 251 245 minecraft:crying_obsidian
fill 324 251 263 324 283 263 minecraft:blackstone
fill 283 252 230 284 252 234 minecraft:orange_concrete
fill 284 252 229 290 252 229 minecraft:orange_concrete
fill 284 252 235 290 252 235 minecraft:orange_concrete
fill 285 252 230 285 254 230 minecraft:orange_concrete
fill 285 252 234 285 254 234 minecraft:orange_concrete
fill 285 252 236 289 252 236 minecraft:orange_concrete
fill 287 252 270 287 283 270 minecraft:blackstone
fill 288 252 230 290 253 230 minecraft:orange_concrete
fill 289 252 231 291 252 231 minecraft:orange_concrete
fill 289 252 234 291 252 234 minecraft:orange_concrete
fill 290 252 232 291 252 233 minecraft:orange_concrete
fill 292 252 270 292 283 270 minecraft:blackstone
fill 293 252 242 294 252 243 minecraft:orange_concrete
fill 294 252 240 295 252 241 minecraft:orange_concrete
fill 294 252 244 295 252 245 minecraft:orange_concrete
fill 295 252 239 298 252 239 minecraft:orange_concrete
fill 295 252 246 297 252 246 minecraft:orange_concrete
fill 296 252 240 299 252 240 minecraft:orange_concrete
fill 296 252 245 299 252 245 minecraft:orange_concrete
fill 299 252 241 300 252 244 minecraft:orange_concrete
setblock 300 252 270 minecraft:magma_block
setblock 303 252 228 minecraft:magma_block
fill 323 252 228 323 283 228 minecraft:blackstone
fill 324 252 245 324 271 245 minecraft:blackstone
setblock 282 253 243 minecraft:magma_block
fill 282 253 244 282 283 244 minecraft:blackstone
setblock 282 253 245 minecraft:shroomlight
fill 283 253 232 284 253 232 minecraft:orange_concrete
fill 284 253 230 284 253 231 minecraft:orange_concrete
fill 284 253 233 284 253 234 minecraft:orange_concrete
fill 285 253 229 289 253 229 minecraft:orange_concrete
fill 285 253 235 289 253 235 minecraft:orange_concrete
setblock 285 253 239 minecraft:light[level=12]
setblock 285 253 247 minecraft:light[level=12]
setblock 285 253 255 minecraft:light[level=12]
setblock 285 253 263 minecraft:light[level=12]
setblock 287 253 236 minecraft:orange_concrete
fill 289 253 231 290 253 231 minecraft:orange_concrete
fill 289 253 234 290 253 234 minecraft:orange_concrete
fill 290 253 232 290 253 233 minecraft:orange_concrete
fill 291 253 240 291 260 240 minecraft:dripstone_block
setblock 293 253 231 minecraft:light[level=12]
setblock 293 253 239 minecraft:light[level=12]
setblock 293 253 247 minecraft:light[level=12]
setblock 293 253 255 minecraft:light[level=12]
setblock 293 253 263 minecraft:light[level=12]
setblock 293 253 270 minecraft:shroomlight
fill 294 253 241 294 253 244 minecraft:orange_concrete
fill 294 253 249 294 260 249 minecraft:dripstone_block
fill 295 253 240 295 253 241 minecraft:orange_concrete
fill 295 253 244 295 254 244 minecraft:orange_concrete
fill 295 253 245 295 260 245 minecraft:dripstone_block
fill 296 253 240 298 253 240 minecraft:orange_concrete
fill 296 253 245 298 253 245 minecraft:orange_concrete
fill 298 253 257 298 260 257 minecraft:dripstone_block
fill 299 253 241 299 253 244 minecraft:orange_concrete
fill 300 253 242 300 253 243 minecraft:orange_concrete
fill 300 253 270 300 279 270 minecraft:blackstone
setblock 301 253 231 minecraft:light[level=12]
setblock 301 253 239 minecraft:light[level=12]
setblock 301 253 247 minecraft:light[level=12]
setblock 301 253 255 minecraft:light[level=12]
setblock 301 253 263 minecraft:light[level=12]
fill 303 253 228 303 283 228 minecraft:blackstone
fill 307 253 233 307 260 233 minecraft:dripstone_block
setblock 309 253 231 minecraft:light[level=12]
setblock 309 253 239 minecraft:light[level=12]
setblock 309 253 247 minecraft:light[level=12]
setblock 309 253 255 minecraft:light[level=12]
setblock 309 253 263 minecraft:light[level=12]
schedule function dropper:buildpart/54_3 1t
