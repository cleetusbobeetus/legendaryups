fill 271 280 425 271 286 427 minecraft:obsidian
fill 271 280 436 271 285 436 minecraft:purple_concrete
fill 271 280 437 276 285 437 minecraft:obsidian
fill 271 280 443 276 285 443 minecraft:obsidian
fill 271 280 454 276 280 454 minecraft:black_concrete
fill 272 280 425 276 280 425 minecraft:black_concrete
fill 272 280 426 272 286 427 minecraft:obsidian
fill 272 280 435 272 285 435 minecraft:purple_concrete
fill 272 280 436 276 285 436 minecraft:obsidian
fill 272 280 442 273 285 442 minecraft:purple_concrete
fill 272 280 449 274 286 449 minecraft:obsidian
fill 272 280 453 276 280 453 minecraft:black_concrete
fill 273 280 426 276 280 426 minecraft:black_concrete
fill 273 280 427 273 286 427 minecraft:obsidian
fill 273 280 433 273 286 433 minecraft:purple_concrete
fill 273 280 435 276 286 435 minecraft:obsidian
fill 273 280 452 276 280 452 minecraft:black_concrete
fill 274 280 427 276 280 428 minecraft:black_concrete
fill 274 280 429 274 286 430 minecraft:obsidian
fill 274 280 432 274 286 432 minecraft:purple_concrete
fill 274 280 433 276 286 433 minecraft:obsidian
fill 274 280 441 274 286 441 minecraft:purple_concrete
fill 274 280 442 276 286 442 minecraft:obsidian
fill 274 280 450 276 280 451 minecraft:black_concrete
fill 275 280 429 276 280 430 minecraft:black_concrete
fill 275 280 432 275 286 432 minecraft:obsidian
fill 275 280 441 276 286 441 minecraft:obsidian
fill 275 280 448 276 280 449 minecraft:black_concrete
fill 276 280 431 276 280 432 minecraft:black_concrete
fill 276 280 440 276 286 440 minecraft:purple_concrete
fill 276 280 445 276 286 445 minecraft:obsidian
fill 276 280 446 276 280 447 minecraft:black_concrete
fill 277 280 439 277 286 439 minecraft:purple_concrete
setblock 235 281 447 minecraft:amethyst_block
fill 251 281 437 252 281 441 minecraft:crying_obsidian
fill 252 281 436 253 281 436 minecraft:crying_obsidian
fill 252 281 442 253 281 442 minecraft:crying_obsidian
fill 259 281 436 260 281 436 minecraft:crying_obsidian
fill 259 281 442 260 281 442 minecraft:crying_obsidian
fill 260 281 437 261 281 441 minecraft:crying_obsidian
setblock 267 281 458 minecraft:amethyst_block
setblock 235 282 432 minecraft:white_concrete
fill 235 282 447 235 284 447 minecraft:black_concrete
fill 239 282 437 249 282 437 minecraft:obsidian
fill 241 282 436 250 282 436 minecraft:obsidian
fill 242 282 433 251 282 434 minecraft:obsidian
fill 243 282 441 249 282 441 minecraft:obsidian
fill 244 282 439 249 282 439 minecraft:obsidian
fill 245 282 440 249 282 440 minecraft:obsidian
fill 246 282 445 253 282 446 minecraft:obsidian
fill 247 282 444 251 282 444 minecraft:obsidian
fill 248 282 443 250 282 443 minecraft:obsidian
fill 249 282 442 250 282 442 minecraft:obsidian
fill 252 282 433 253 282 433 minecraft:obsidian
fill 254 282 446 275 282 446 minecraft:obsidian
fill 259 282 433 272 282 433 minecraft:obsidian
fill 259 282 445 275 282 445 minecraft:obsidian
fill 261 282 434 265 282 434 minecraft:obsidian
fill 261 282 444 276 282 444 minecraft:obsidian
fill 262 282 435 263 282 436 minecraft:obsidian
fill 262 282 442 271 282 442 minecraft:obsidian
setblock 264 282 435 minecraft:obsidian
fill 267 282 458 267 306 458 minecraft:black_concrete
setblock 277 282 440 minecraft:crying_obsidian
setblock 277 282 443 minecraft:white_concrete
setblock 235 283 432 minecraft:black_concrete
fill 237 283 438 246 283 438 minecraft:obsidian
fill 239 283 437 247 283 437 minecraft:obsidian
fill 241 283 436 247 283 436 minecraft:obsidian
fill 242 283 433 248 283 434 minecraft:obsidian
fill 243 283 441 247 283 441 minecraft:obsidian
fill 244 283 435 247 283 435 minecraft:obsidian
fill 244 283 439 246 283 439 minecraft:obsidian
fill 244 283 447 251 283 447 minecraft:obsidian
fill 245 283 440 246 283 440 minecraft:obsidian
fill 245 283 448 254 283 448 minecraft:obsidian
fill 246 283 445 249 283 446 minecraft:obsidian
fill 247 283 444 248 283 444 minecraft:obsidian
fill 249 283 430 254 283 430 minecraft:obsidian
setblock 249 283 433 minecraft:obsidian
setblock 250 283 432 minecraft:obsidian
setblock 250 283 446 minecraft:obsidian
setblock 251 283 431 minecraft:obsidian
fill 258 283 430 267 283 430 minecraft:obsidian
fill 258 283 448 263 283 448 minecraft:obsidian
fill 261 283 431 275 283 431 minecraft:obsidian
setblock 261 283 447 minecraft:obsidian
fill 262 283 432 266 283 432 minecraft:obsidian
fill 262 283 446 275 283 446 minecraft:obsidian
fill 263 283 433 272 283 433 minecraft:obsidian
fill 263 283 445 275 283 445 minecraft:obsidian
fill 264 283 434 265 283 434 minecraft:obsidian
fill 264 283 444 276 283 444 minecraft:obsidian
fill 265 283 437 267 283 437 minecraft:obsidian
fill 265 283 441 268 283 443 minecraft:obsidian
fill 266 283 438 267 283 440 minecraft:obsidian
setblock 268 283 416 minecraft:white_concrete
fill 268 283 440 275 284 440 minecraft:obsidian
fill 269 283 441 271 284 442 minecraft:obsidian
fill 272 283 441 273 285 441 minecraft:obsidian
setblock 276 283 458 minecraft:white_concrete
fill 277 283 440 277 307 440 minecraft:black_concrete
fill 277 283 443 277 307 443 minecraft:black_concrete
setblock 235 284 424 minecraft:amethyst_block
setblock 235 284 432 minecraft:white_concrete
setblock 235 284 434 minecraft:crying_obsidian
fill 237 284 431 246 284 432 minecraft:obsidian
fill 237 284 438 244 284 438 minecraft:obsidian
fill 239 284 437 244 284 437 minecraft:obsidian
fill 241 284 436 244 284 436 minecraft:obsidian
fill 241 284 443 244 284 443 minecraft:obsidian
fill 242 284 433 245 284 434 minecraft:obsidian
fill 242 284 442 244 284 442 minecraft:obsidian
fill 243 284 441 244 284 441 minecraft:obsidian
fill 244 284 429 249 284 429 minecraft:obsidian
setblock 244 284 435 minecraft:obsidian
setblock 244 284 439 minecraft:obsidian
fill 244 284 447 247 284 447 minecraft:obsidian
setblock 244 284 458 minecraft:amethyst_block
fill 245 284 448 248 284 448 minecraft:obsidian
setblock 246 284 446 minecraft:obsidian
setblock 247 284 431 minecraft:obsidian
setblock 247 284 458 minecraft:crying_obsidian
fill 250 284 450 251 284 455 minecraft:obsidian
fill 252 284 451 253 284 455 minecraft:obsidian
setblock 254 284 451 minecraft:purple_concrete
fill 255 284 451 258 284 452 minecraft:obsidian
setblock 258 284 427 minecraft:purple_concrete
fill 259 284 427 262 284 427 minecraft:obsidian
fill 261 284 428 262 284 428 minecraft:obsidian
fill 261 284 450 273 284 450 minecraft:obsidian
fill 263 284 449 268 284 449 minecraft:obsidian
fill 264 284 430 267 284 430 minecraft:obsidian
fill 264 284 431 264 290 432 minecraft:black_concrete
setblock 265 284 416 minecraft:amethyst_block
fill 265 284 431 275 284 431 minecraft:obsidian
fill 265 284 432 265 290 433 minecraft:black_concrete
fill 265 284 447 275 284 447 minecraft:obsidian
setblock 266 284 432 minecraft:obsidian
fill 266 284 433 266 290 433 minecraft:black_concrete
fill 266 284 446 275 284 446 minecraft:obsidian
fill 267 284 433 272 284 433 minecraft:obsidian
fill 267 284 444 275 284 445 minecraft:obsidian
fill 268 284 416 268 307 416 minecraft:black_concrete
fill 268 284 435 270 284 436 minecraft:obsidian
fill 268 284 441 268 284 443 minecraft:obsidian
fill 271 284 435 271 285 435 minecraft:obsidian
fill 276 284 444 276 286 444 minecraft:obsidian
fill 276 284 458 276 307 458 minecraft:black_concrete
fill 235 285 424 235 287 424 minecraft:black_concrete
fill 235 285 432 235 307 432 minecraft:black_concrete
fill 235 285 434 235 307 434 minecraft:black_concrete
setblock 235 285 435 minecraft:amethyst_block
setblock 235 285 447 minecraft:crying_obsidian
fill 237 285 431 243 285 432 minecraft:obsidian
fill 237 285 438 241 285 438 minecraft:obsidian
setblock 238 285 419 minecraft:light[level=12]
setblock 238 285 427 minecraft:light[level=12]
setblock 238 285 451 minecraft:light[level=12]
fill 239 285 427 246 285 428 minecraft:obsidian
fill 239 285 437 241 285 437 minecraft:obsidian
fill 239 285 446 243 285 446 minecraft:obsidian
fill 240 285 426 249 285 426 minecraft:obsidian
fill 240 285 444 242 285 445 minecraft:obsidian
fill 241 285 425 252 285 425 minecraft:obsidian
fill 241 285 430 244 285 430 minecraft:obsidian
setblock 241 285 436 minecraft:obsidian
fill 241 285 443 242 285 443 minecraft:obsidian
fill 242 285 433 242 285 434 minecraft:obsidian
setblock 242 285 435 minecraft:purple_concrete
fill 243 285 450 246 285 450 minecraft:obsidian
fill 244 285 429 245 285 429 minecraft:obsidian
fill 244 285 449 245 285 449 minecraft:obsidian
fill 244 285 451 247 285 456 minecraft:obsidian
fill 244 285 458 244 307 458 minecraft:black_concrete
setblock 246 285 419 minecraft:light[level=12]
setblock 246 285 435 minecraft:light[level=12]
setblock 246 285 443 minecraft:light[level=12]
setblock 247 285 427 minecraft:obsidian
setblock 247 285 458 minecraft:black_concrete
fill 248 285 452 248 285 456 minecraft:obsidian
fill 249 285 452 249 285 453 minecraft:purple_concrete
fill 250 285 453 252 285 455 minecraft:obsidian
fill 253 285 454 254 285 455 minecraft:obsidian
setblock 254 285 427 minecraft:light[level=12]
setblock 254 285 435 minecraft:light[level=12]
setblock 254 285 443 minecraft:light[level=12]
setblock 254 285 451 minecraft:light[level=12]
fill 256 285 454 263 285 454 minecraft:obsidian
fill 260 285 425 262 285 425 minecraft:obsidian
fill 260 285 453 263 285 453 minecraft:obsidian
setblock 262 285 427 minecraft:light[level=12]
setblock 262 285 435 minecraft:light[level=12]
setblock 262 285 443 minecraft:light[level=12]
setblock 262 285 451 minecraft:light[level=12]
fill 263 285 425 263 285 426 minecraft:purple_concrete
fill 263 285 452 272 285 452 minecraft:obsidian
fill 264 285 425 268 285 426 minecraft:obsidian
fill 264 285 430 267 290 430 minecraft:black_concrete
fill 264 285 433 264 290 433 minecraft:black_concrete
fill 265 285 416 265 286 416 minecraft:black_concrete
fill 265 285 427 268 285 427 minecraft:obsidian
fill 265 285 431 267 290 431 minecraft:black_concrete
fill 265 285 434 266 290 434 minecraft:black_concrete
fill 265 285 451 273 285 451 minecraft:obsidian
fill 266 285 428 268 285 428 minecraft:obsidian
fill 266 285 432 267 290 432 minecraft:black_concrete
fill 266 285 450 273 285 450 minecraft:obsidian
fill 267 285 429 268 285 429 minecraft:obsidian
fill 267 285 433 267 290 433 minecraft:black_concrete
fill 267 285 449 268 285 449 minecraft:obsidian
fill 268 285 448 274 285 448 minecraft:obsidian
fill 269 285 431 273 285 432 minecraft:obsidian
fill 269 285 446 275 285 447 minecraft:obsidian
setblock 270 285 419 minecraft:light[level=12]
fill 270 285 433 270 285 435 minecraft:obsidian
setblock 270 285 443 minecraft:purple_concrete
fill 270 285 444 275 285 445 minecraft:obsidian
fill 271 285 433 272 285 434 minecraft:obsidian
fill 271 285 438 271 285 442 minecraft:obsidian
fill 272 285 438 275 285 440 minecraft:obsidian
fill 273 285 434 276 286 434 minecraft:obsidian
fill 274 285 431 275 286 431 minecraft:obsidian
fill 276 285 438 276 286 439 minecraft:obsidian
setblock 235 286 423 minecraft:amethyst_block
fill 235 286 435 235 307 435 minecraft:black_concrete
fill 235 286 447 235 307 447 minecraft:black_concrete
fill 237 286 431 240 286 432 minecraft:obsidian
fill 237 286 438 238 286 438 minecraft:obsidian
fill 238 286 447 240 286 449 minecraft:obsidian
fill 239 286 427 242 286 428 minecraft:obsidian
fill 239 286 433 239 286 435 minecraft:obsidian
setblock 239 286 436 minecraft:purple_concrete
fill 239 286 442 239 286 444 minecraft:obsidian
fill 239 286 446 240 286 446 minecraft:obsidian
fill 240 286 426 244 286 426 minecraft:obsidian
fill 241 286 425 246 286 425 minecraft:obsidian
fill 241 286 429 242 286 429 minecraft:purple_concrete
setblock 241 286 430 minecraft:obsidian
fill 241 286 448 241 286 449 minecraft:obsidian
setblock 242 286 449 minecraft:obsidian
setblock 243 286 427 minecraft:obsidian
fill 244 286 422 253 286 422 minecraft:obsidian
fill 244 286 452 244 286 456 minecraft:obsidian
fill 245 286 453 246 286 456 minecraft:obsidian
fill 246 286 423 249 286 423 minecraft:obsidian
setblock 247 286 424 minecraft:purple_concrete
fill 247 286 454 247 286 456 minecraft:obsidian
setblock 247 286 458 minecraft:amethyst_block
fill 248 286 455 249 286 456 minecraft:obsidian
fill 251 286 456 253 286 457 minecraft:obsidian
fill 254 286 457 256 286 457 minecraft:obsidian
fill 259 286 422 261 286 422 minecraft:obsidian
fill 259 286 456 268 286 456 minecraft:obsidian
fill 263 286 423 268 286 423 minecraft:obsidian
fill 263 286 431 263 290 433 minecraft:black_concrete
fill 263 286 455 266 286 455 minecraft:obsidian
fill 264 286 434 264 290 434 minecraft:black_concrete
fill 265 286 424 268 286 424 minecraft:obsidian
fill 265 286 429 266 290 429 minecraft:black_concrete
setblock 265 286 454 minecraft:purple_concrete
fill 266 286 425 268 286 425 minecraft:obsidian
fill 266 286 453 271 286 453 minecraft:obsidian
fill 267 286 434 267 290 434 minecraft:black_concrete
setblock 268 286 426 minecraft:obsidian
fill 268 286 431 268 290 433 minecraft:black_concrete
fill 268 286 452 272 286 452 minecraft:obsidian
fill 269 286 451 273 286 451 minecraft:obsidian
fill 270 286 428 273 286 429 minecraft:obsidian
fill 270 286 449 271 286 449 minecraft:purple_concrete
fill 270 286 450 273 286 450 minecraft:obsidian
fill 271 286 430 273 286 430 minecraft:obsidian
fill 271 286 448 274 286 448 minecraft:obsidian
fill 272 286 431 273 286 432 minecraft:obsidian
fill 272 286 446 275 286 447 minecraft:obsidian
fill 273 286 436 276 286 436 minecraft:obsidian
setblock 273 286 442 minecraft:purple_concrete
fill 273 286 443 275 286 445 minecraft:obsidian
fill 274 286 437 275 286 440 minecraft:obsidian
setblock 276 286 437 minecraft:obsidian
setblock 276 286 443 minecraft:obsidian
fill 235 287 423 235 291 423 minecraft:black_concrete
fill 235 287 439 235 292 439 minecraft:black_concrete
setblock 238 287 416 minecraft:white_concrete
setblock 239 287 416 minecraft:crying_obsidian
fill 247 287 458 264 287 458 minecraft:black_concrete
fill 263 287 430 263 290 430 minecraft:black_concrete
fill 263 287 434 263 290 434 minecraft:black_concrete
fill 264 287 429 264 290 429 minecraft:black_concrete
setblock 265 287 416 minecraft:white_concrete
fill 265 287 435 266 290 435 minecraft:black_concrete
fill 267 287 429 267 290 429 minecraft:black_concrete
fill 268 287 430 268 290 430 minecraft:black_concrete
fill 268 287 434 268 290 434 minecraft:black_concrete
fill 277 287 439 277 307 439 minecraft:black_concrete
fill 235 288 424 235 290 424 minecraft:purple_concrete
fill 235 288 440 235 290 440 minecraft:purple_concrete
fill 235 288 456 235 290 456 minecraft:purple_concrete
fill 238 288 416 238 307 416 minecraft:black_concrete
fill 239 288 416 239 290 416 minecraft:purple_concrete
fill 247 288 458 248 307 458 minecraft:black_concrete
fill 249 288 458 249 290 458 minecraft:purple_concrete
fill 250 288 458 264 296 458 minecraft:black_concrete
fill 255 288 416 255 290 416 minecraft:purple_concrete
fill 262 288 431 262 290 433 minecraft:black_concrete
fill 263 288 429 263 290 429 minecraft:black_concrete
fill 264 288 435 264 290 435 minecraft:black_concrete
fill 265 288 416 265 307 416 minecraft:black_concrete
fill 265 288 428 266 290 428 minecraft:black_concrete
fill 265 288 458 265 290 458 minecraft:purple_concrete
fill 267 288 435 267 290 435 minecraft:black_concrete
fill 268 288 429 268 290 429 minecraft:black_concrete
fill 269 288 430 269 290 433 minecraft:black_concrete
fill 271 288 416 271 290 416 minecraft:purple_concrete
fill 277 288 426 277 290 426 minecraft:purple_concrete
fill 277 288 442 277 290 442 minecraft:purple_concrete
fill 262 289 430 262 290 430 minecraft:black_concrete
fill 262 289 434 262 290 434 minecraft:black_concrete
fill 263 289 435 263 290 435 minecraft:black_concrete
fill 264 289 428 264 290 428 minecraft:black_concrete
fill 265 289 436 266 290 436 minecraft:black_concrete
fill 267 289 428 267 290 428 minecraft:black_concrete
fill 268 289 435 268 290 435 minecraft:black_concrete
fill 269 289 429 269 290 429 minecraft:black_concrete
fill 269 289 434 269 290 434 minecraft:black_concrete
fill 261 290 430 261 290 433 minecraft:black_concrete
setblock 262 290 429 minecraft:black_concrete
setblock 262 290 435 minecraft:black_concrete
setblock 263 290 428 minecraft:black_concrete
setblock 264 290 436 minecraft:black_concrete
fill 265 290 427 266 290 427 minecraft:black_concrete
setblock 267 290 436 minecraft:black_concrete
setblock 268 290 428 minecraft:black_concrete
setblock 269 290 435 minecraft:black_concrete
fill 270 290 430 270 290 433 minecraft:black_concrete
setblock 277 290 441 minecraft:amethyst_block
fill 235 291 424 235 296 424 minecraft:black_concrete
fill 235 291 440 235 296 440 minecraft:black_concrete
fill 235 291 456 235 296 456 minecraft:black_concrete
fill 239 291 416 239 296 416 minecraft:black_concrete
setblock 242 291 458 minecraft:crying_obsidian
fill 249 291 458 249 296 458 minecraft:black_concrete
fill 255 291 416 255 296 416 minecraft:black_concrete
fill 265 291 431 266 292 432 minecraft:amethyst_block
fill 265 291 458 265 296 458 minecraft:black_concrete
fill 271 291 416 271 296 416 minecraft:black_concrete
fill 277 291 426 277 296 426 minecraft:black_concrete
fill 277 291 441 277 294 442 minecraft:black_concrete
setblock 235 292 423 minecraft:crying_obsidian
setblock 235 292 453 minecraft:crying_obsidian
fill 242 292 458 242 307 458 minecraft:black_concrete
fill 246 292 435 246 293 435 minecraft:crying_obsidian
setblock 250 292 416 minecraft:amethyst_block
setblock 277 292 431 minecraft:amethyst_block
fill 235 293 423 235 307 423 minecraft:black_concrete
setblock 235 293 439 minecraft:amethyst_block
fill 235 293 453 235 307 453 minecraft:black_concrete
setblock 238 293 419 minecraft:light[level=12]
setblock 238 293 427 minecraft:light[level=12]
setblock 238 293 435 minecraft:light[level=12]
setblock 238 293 443 minecraft:light[level=12]
setblock 238 293 451 minecraft:light[level=12]
setblock 246 293 419 minecraft:light[level=12]
setblock 246 293 427 minecraft:light[level=12]
setblock 246 293 443 minecraft:light[level=12]
setblock 246 293 451 minecraft:light[level=12]
fill 250 293 416 250 307 416 minecraft:black_concrete
setblock 254 293 419 minecraft:light[level=12]
setblock 254 293 427 minecraft:light[level=12]
setblock 254 293 435 minecraft:light[level=12]
setblock 254 293 443 minecraft:light[level=12]
setblock 254 293 451 minecraft:light[level=12]
setblock 262 293 419 minecraft:light[level=12]
setblock 262 293 427 minecraft:light[level=12]
setblock 262 293 435 minecraft:light[level=12]
setblock 262 293 443 minecraft:light[level=12]
setblock 262 293 451 minecraft:light[level=12]
fill 265 293 432 266 293 432 minecraft:amethyst_block
setblock 268 293 458 minecraft:crying_obsidian
setblock 270 293 419 minecraft:light[level=12]
setblock 270 293 427 minecraft:light[level=12]
setblock 270 293 435 minecraft:light[level=12]
setblock 270 293 443 minecraft:light[level=12]
setblock 270 293 451 minecraft:light[level=12]
fill 277 293 431 277 307 431 minecraft:black_concrete
setblock 235 294 425 minecraft:crying_obsidian
setblock 235 294 433 minecraft:crying_obsidian
fill 235 294 439 235 307 439 minecraft:black_concrete
setblock 266 294 432 minecraft:amethyst_block
fill 268 294 458 268 298 458 minecraft:black_concrete
setblock 277 294 417 minecraft:crying_obsidian
setblock 235 295 425 minecraft:black_concrete
setblock 235 295 426 minecraft:crying_obsidian
fill 235 295 433 235 307 433 minecraft:black_concrete
fill 277 295 417 277 307 417 minecraft:black_concrete
setblock 277 295 441 minecraft:white_concrete
fill 277 295 442 277 296 442 minecraft:black_concrete
setblock 235 296 425 minecraft:crying_obsidian
fill 235 296 426 235 307 426 minecraft:black_concrete
fill 277 296 441 277 307 441 minecraft:black_concrete
fill 235 297 424 235 299 424 minecraft:purple_concrete
fill 235 297 425 235 307 425 minecraft:black_concrete
fill 235 297 440 235 299 440 minecraft:purple_concrete
fill 235 297 456 235 299 456 minecraft:purple_concrete
fill 239 297 416 239 299 416 minecraft:purple_concrete
fill 249 297 458 249 299 458 minecraft:purple_concrete
fill 250 297 458 253 307 458 minecraft:black_concrete
setblock 254 297 458 minecraft:crying_obsidian
fill 255 297 416 255 299 416 minecraft:purple_concrete
fill 255 297 458 264 307 458 minecraft:black_concrete
fill 265 297 458 265 299 458 minecraft:purple_concrete
fill 271 297 416 271 299 416 minecraft:purple_concrete
fill 277 297 426 277 299 426 minecraft:purple_concrete
fill 277 297 442 277 299 442 minecraft:purple_concrete
setblock 235 298 438 minecraft:crying_obsidian
setblock 254 298 458 minecraft:black_concrete
fill 274 298 421 276 300 423 minecraft:amethyst_block
setblock 277 298 425 minecraft:amethyst_block
setblock 277 298 433 minecraft:crying_obsidian
fill 235 299 438 235 307 438 minecraft:black_concrete
fill 245 299 448 246 300 449 minecraft:amethyst_block
setblock 254 299 458 minecraft:amethyst_block
setblock 268 299 458 minecraft:amethyst_block
fill 273 299 421 273 300 423 minecraft:amethyst_block
fill 275 299 420 275 300 420 minecraft:amethyst_block
fill 275 299 424 275 300 424 minecraft:amethyst_block
fill 277 299 425 277 307 425 minecraft:black_concrete
fill 277 299 433 277 307 433 minecraft:black_concrete
fill 235 300 424 235 307 424 minecraft:black_concrete
fill 235 300 440 235 307 440 minecraft:black_concrete
setblock 235 300 456 minecraft:crying_obsidian
fill 239 300 416 239 307 416 minecraft:black_concrete
fill 249 300 458 249 307 458 minecraft:black_concrete
fill 254 300 458 254 301 458 minecraft:black_concrete
fill 255 300 416 255 307 416 minecraft:black_concrete
fill 265 300 458 265 307 458 minecraft:black_concrete
fill 268 300 458 268 307 458 minecraft:black_concrete
fill 271 300 416 271 306 416 minecraft:black_concrete
fill 272 300 421 272 300 423 minecraft:amethyst_block
fill 277 300 426 277 304 426 minecraft:black_concrete
setblock 277 300 435 minecraft:crying_obsidian
fill 277 300 442 277 305 442 minecraft:black_concrete
setblock 235 301 443 minecraft:amethyst_block
fill 235 301 456 235 307 456 minecraft:black_concrete
setblock 238 301 419 minecraft:light[level=12]
setblock 238 301 427 minecraft:light[level=12]
setblock 238 301 435 minecraft:light[level=12]
setblock 238 301 443 minecraft:light[level=12]
setblock 238 301 451 minecraft:light[level=12]
setblock 246 301 419 minecraft:light[level=12]
setblock 246 301 427 minecraft:light[level=12]
setblock 246 301 435 minecraft:light[level=12]
setblock 246 301 443 minecraft:light[level=12]
setblock 246 301 451 minecraft:light[level=12]
setblock 254 301 419 minecraft:light[level=12]
setblock 254 301 427 minecraft:light[level=12]
setblock 254 301 435 minecraft:light[level=12]
setblock 254 301 443 minecraft:light[level=12]
setblock 254 301 451 minecraft:light[level=12]
setblock 262 301 419 minecraft:light[level=12]
setblock 262 301 427 minecraft:light[level=12]
setblock 262 301 435 minecraft:light[level=12]
setblock 262 301 443 minecraft:light[level=12]
setblock 262 301 451 minecraft:light[level=12]
setblock 270 301 419 minecraft:light[level=12]
setblock 270 301 427 minecraft:light[level=12]
setblock 270 301 435 minecraft:light[level=12]
setblock 270 301 443 minecraft:light[level=12]
setblock 270 301 451 minecraft:light[level=12]
fill 277 301 435 277 303 435 minecraft:black_concrete
setblock 277 301 453 minecraft:crying_obsidian
fill 235 302 443 235 307 443 minecraft:black_concrete
setblock 238 302 458 minecraft:amethyst_block
setblock 254 302 458 minecraft:amethyst_block
setblock 256 302 416 minecraft:crying_obsidian
fill 277 302 453 277 307 453 minecraft:black_concrete
fill 238 303 458 238 307 458 minecraft:black_concrete
setblock 254 303 458 minecraft:crying_obsidian
fill 256 303 416 256 307 416 minecraft:black_concrete
setblock 258 303 416 minecraft:white_concrete
setblock 236 304 416 minecraft:amethyst_block
setblock 243 304 416 minecraft:white_concrete
fill 254 304 458 254 307 458 minecraft:black_concrete
fill 258 304 416 258 307 416 minecraft:black_concrete
setblock 275 304 458 minecraft:white_concrete
setblock 276 304 416 minecraft:crying_obsidian
setblock 277 304 435 minecraft:amethyst_block
setblock 235 305 454 minecraft:crying_obsidian
fill 236 305 416 236 307 416 minecraft:black_concrete
fill 243 305 416 243 307 416 minecraft:black_concrete
setblock 246 305 458 minecraft:amethyst_block
fill 275 305 458 275 307 458 minecraft:black_concrete
fill 276 305 416 276 307 416 minecraft:black_concrete
setblock 277 305 426 minecraft:crying_obsidian
fill 277 305 435 277 307 435 minecraft:black_concrete
fill 235 306 454 235 307 454 minecraft:black_concrete
fill 246 306 458 246 307 458 minecraft:black_concrete
setblock 263 306 416 minecraft:crying_obsidian
setblock 266 306 416 minecraft:amethyst_block
setblock 275 306 416 minecraft:crying_obsidian
fill 277 306 426 277 307 426 minecraft:black_concrete
setblock 277 306 442 minecraft:amethyst_block
setblock 240 307 458 minecraft:crying_obsidian
setblock 253 307 416 minecraft:amethyst_block
setblock 263 307 416 minecraft:black_concrete
setblock 266 307 416 minecraft:black_concrete
setblock 267 307 458 minecraft:crying_obsidian
setblock 270 307 458 minecraft:amethyst_block
setblock 271 307 416 minecraft:crying_obsidian
setblock 275 307 416 minecraft:black_concrete
setblock 277 307 442 minecraft:black_concrete
