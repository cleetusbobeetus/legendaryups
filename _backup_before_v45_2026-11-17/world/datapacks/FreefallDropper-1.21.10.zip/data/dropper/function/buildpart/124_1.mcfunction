fill 217 155 545 217 156 545 minecraft:gray_concrete
fill 217 155 547 217 156 547 minecraft:gray_concrete
fill 217 155 549 217 156 549 minecraft:gray_concrete
fill 217 155 551 217 156 551 minecraft:gray_concrete
fill 218 155 542 218 156 542 minecraft:gray_concrete
fill 218 155 544 218 156 544 minecraft:gray_concrete
fill 218 155 546 218 156 546 minecraft:gray_concrete
fill 218 155 548 218 156 548 minecraft:gray_concrete
fill 218 155 550 218 156 550 minecraft:gray_concrete
fill 219 155 513 219 156 513 minecraft:gray_concrete
fill 219 155 515 219 156 515 minecraft:gray_concrete
fill 219 155 517 219 156 517 minecraft:gray_concrete
fill 219 155 519 219 156 519 minecraft:gray_concrete
fill 219 155 521 219 156 521 minecraft:gray_concrete
fill 219 155 523 219 156 523 minecraft:gray_concrete
fill 219 155 525 219 156 525 minecraft:gray_concrete
fill 219 155 543 219 156 543 minecraft:gray_concrete
fill 219 155 545 219 156 545 minecraft:gray_concrete
fill 219 155 547 219 156 547 minecraft:gray_concrete
fill 219 155 549 219 156 549 minecraft:gray_concrete
fill 219 155 551 219 156 551 minecraft:gray_concrete
fill 220 155 514 220 156 514 minecraft:gray_concrete
fill 220 155 516 220 156 516 minecraft:gray_concrete
fill 220 155 518 220 156 518 minecraft:gray_concrete
fill 220 155 520 220 156 520 minecraft:gray_concrete
fill 220 155 522 220 156 522 minecraft:gray_concrete
fill 220 155 524 220 156 524 minecraft:gray_concrete
fill 220 155 542 220 156 542 minecraft:gray_concrete
fill 220 155 544 220 156 544 minecraft:gray_concrete
fill 220 155 546 220 156 546 minecraft:gray_concrete
fill 220 155 548 220 156 548 minecraft:gray_concrete
fill 220 155 550 220 156 550 minecraft:gray_concrete
fill 221 155 513 221 156 513 minecraft:gray_concrete
fill 221 155 515 221 156 515 minecraft:gray_concrete
fill 221 155 517 227 156 517 minecraft:gray_concrete
fill 221 155 519 222 156 519 minecraft:gray_concrete
fill 221 155 521 227 156 521 minecraft:gray_concrete
fill 221 155 523 221 156 523 minecraft:gray_concrete
fill 221 155 525 221 156 525 minecraft:gray_concrete
fill 221 155 551 226 155 551 minecraft:gray_concrete
fill 222 155 514 222 156 514 minecraft:gray_concrete
fill 222 155 516 222 156 516 minecraft:gray_concrete
fill 222 155 518 222 156 518 minecraft:gray_concrete
fill 222 155 520 222 156 520 minecraft:gray_concrete
fill 222 155 522 222 156 522 minecraft:gray_concrete
fill 222 155 524 222 156 524 minecraft:gray_concrete
fill 223 155 513 223 156 513 minecraft:gray_concrete
fill 223 155 515 223 156 515 minecraft:gray_concrete
setblock 223 155 519 minecraft:white_concrete
fill 223 155 523 223 156 523 minecraft:gray_concrete
fill 223 155 525 223 156 525 minecraft:gray_concrete
fill 224 155 514 224 156 514 minecraft:gray_concrete
fill 224 155 516 224 156 516 minecraft:gray_concrete
setblock 224 155 518 minecraft:white_concrete
setblock 224 155 520 minecraft:white_concrete
fill 224 155 522 224 156 522 minecraft:gray_concrete
fill 224 155 524 224 156 524 minecraft:gray_concrete
fill 225 155 513 225 156 513 minecraft:gray_concrete
fill 225 155 515 225 156 515 minecraft:gray_concrete
fill 225 155 519 225 156 519 minecraft:white_concrete
fill 225 155 523 225 156 523 minecraft:gray_concrete
fill 225 155 525 225 156 525 minecraft:gray_concrete
fill 226 155 514 226 156 514 minecraft:gray_concrete
fill 226 155 516 226 156 516 minecraft:gray_concrete
setblock 226 155 518 minecraft:white_concrete
setblock 226 155 520 minecraft:white_concrete
fill 226 155 522 226 156 522 minecraft:gray_concrete
fill 226 155 524 226 156 524 minecraft:gray_concrete
fill 226 155 534 227 155 536 minecraft:white_concrete
fill 227 155 513 227 156 513 minecraft:gray_concrete
fill 227 155 515 227 156 515 minecraft:gray_concrete
setblock 227 155 519 minecraft:white_concrete
fill 227 155 523 227 156 523 minecraft:gray_concrete
fill 227 155 525 227 156 525 minecraft:gray_concrete
fill 228 155 514 228 156 514 minecraft:gray_concrete
fill 228 155 516 228 156 516 minecraft:gray_concrete
fill 228 155 518 228 156 518 minecraft:gray_concrete
fill 228 155 520 228 156 520 minecraft:gray_concrete
fill 228 155 522 228 156 522 minecraft:gray_concrete
fill 228 155 524 228 156 524 minecraft:gray_concrete
fill 229 155 513 229 156 513 minecraft:gray_concrete
fill 229 155 515 229 156 515 minecraft:gray_concrete
fill 229 155 517 229 156 517 minecraft:gray_concrete
fill 229 155 519 229 156 519 minecraft:gray_concrete
fill 229 155 521 229 156 521 minecraft:gray_concrete
fill 229 155 523 229 156 523 minecraft:gray_concrete
fill 229 155 525 229 156 525 minecraft:gray_concrete
setblock 229 155 550 minecraft:gray_concrete
fill 223 156 518 223 156 520 minecraft:gray_concrete
fill 224 156 518 227 156 518 minecraft:gray_concrete
fill 224 156 520 227 156 520 minecraft:gray_concrete
fill 226 156 535 227 157 535 minecraft:white_concrete
setblock 227 156 519 minecraft:gray_concrete
setblock 210 157 542 minecraft:pearlescent_froglight
setblock 210 157 544 minecraft:pearlescent_froglight
setblock 210 157 546 minecraft:pearlescent_froglight
setblock 210 157 548 minecraft:pearlescent_froglight
setblock 210 157 550 minecraft:pearlescent_froglight
setblock 211 157 543 minecraft:pearlescent_froglight
setblock 211 157 545 minecraft:pearlescent_froglight
setblock 211 157 547 minecraft:pearlescent_froglight
setblock 211 157 549 minecraft:pearlescent_froglight
setblock 211 157 551 minecraft:pearlescent_froglight
setblock 212 157 542 minecraft:pearlescent_froglight
setblock 212 157 544 minecraft:pearlescent_froglight
setblock 212 157 546 minecraft:pearlescent_froglight
setblock 212 157 548 minecraft:pearlescent_froglight
setblock 212 157 550 minecraft:pearlescent_froglight
setblock 213 157 543 minecraft:pearlescent_froglight
setblock 213 157 545 minecraft:pearlescent_froglight
setblock 213 157 547 minecraft:pearlescent_froglight
setblock 213 157 549 minecraft:pearlescent_froglight
setblock 213 157 551 minecraft:pearlescent_froglight
setblock 214 157 542 minecraft:pearlescent_froglight
setblock 214 157 544 minecraft:pearlescent_froglight
setblock 214 157 546 minecraft:pearlescent_froglight
setblock 214 157 548 minecraft:pearlescent_froglight
setblock 214 157 550 minecraft:pearlescent_froglight
setblock 215 157 543 minecraft:pearlescent_froglight
setblock 215 157 545 minecraft:pearlescent_froglight
setblock 215 157 547 minecraft:pearlescent_froglight
setblock 215 157 549 minecraft:pearlescent_froglight
setblock 215 157 551 minecraft:pearlescent_froglight
setblock 216 157 542 minecraft:pearlescent_froglight
setblock 216 157 544 minecraft:pearlescent_froglight
setblock 216 157 546 minecraft:pearlescent_froglight
setblock 216 157 548 minecraft:pearlescent_froglight
setblock 216 157 550 minecraft:pearlescent_froglight
setblock 217 157 543 minecraft:pearlescent_froglight
setblock 217 157 545 minecraft:pearlescent_froglight
setblock 217 157 547 minecraft:pearlescent_froglight
setblock 217 157 549 minecraft:pearlescent_froglight
setblock 217 157 551 minecraft:pearlescent_froglight
setblock 218 157 542 minecraft:pearlescent_froglight
setblock 218 157 544 minecraft:pearlescent_froglight
setblock 218 157 546 minecraft:pearlescent_froglight
setblock 218 157 548 minecraft:pearlescent_froglight
setblock 218 157 550 minecraft:pearlescent_froglight
setblock 219 157 513 minecraft:pearlescent_froglight
setblock 219 157 515 minecraft:pearlescent_froglight
setblock 219 157 517 minecraft:pearlescent_froglight
setblock 219 157 519 minecraft:pearlescent_froglight
setblock 219 157 521 minecraft:pearlescent_froglight
setblock 219 157 523 minecraft:pearlescent_froglight
setblock 219 157 525 minecraft:pearlescent_froglight
setblock 219 157 543 minecraft:pearlescent_froglight
setblock 219 157 545 minecraft:pearlescent_froglight
setblock 219 157 547 minecraft:pearlescent_froglight
setblock 219 157 549 minecraft:pearlescent_froglight
setblock 219 157 551 minecraft:pearlescent_froglight
setblock 220 157 514 minecraft:pearlescent_froglight
setblock 220 157 516 minecraft:pearlescent_froglight
setblock 220 157 518 minecraft:pearlescent_froglight
setblock 220 157 520 minecraft:pearlescent_froglight
setblock 220 157 522 minecraft:pearlescent_froglight
setblock 220 157 524 minecraft:pearlescent_froglight
setblock 220 157 542 minecraft:pearlescent_froglight
setblock 220 157 544 minecraft:pearlescent_froglight
setblock 220 157 546 minecraft:pearlescent_froglight
setblock 220 157 548 minecraft:pearlescent_froglight
setblock 220 157 550 minecraft:pearlescent_froglight
setblock 221 157 513 minecraft:pearlescent_froglight
setblock 221 157 515 minecraft:pearlescent_froglight
setblock 221 157 517 minecraft:pearlescent_froglight
setblock 221 157 519 minecraft:pearlescent_froglight
setblock 221 157 521 minecraft:pearlescent_froglight
setblock 221 157 523 minecraft:pearlescent_froglight
setblock 221 157 525 minecraft:pearlescent_froglight
setblock 222 157 514 minecraft:pearlescent_froglight
setblock 222 157 516 minecraft:pearlescent_froglight
fill 222 157 517 222 161 517 minecraft:gray_concrete
setblock 222 157 518 minecraft:pearlescent_froglight
fill 222 157 519 222 161 519 minecraft:gray_concrete
setblock 222 157 520 minecraft:pearlescent_froglight
fill 222 157 521 222 161 521 minecraft:gray_concrete
setblock 222 157 522 minecraft:pearlescent_froglight
setblock 222 157 524 minecraft:pearlescent_froglight
fill 222 157 526 226 158 530 minecraft:black_concrete
setblock 223 157 513 minecraft:pearlescent_froglight
setblock 223 157 515 minecraft:pearlescent_froglight
setblock 223 157 517 minecraft:pearlescent_froglight
fill 223 157 518 223 161 518 minecraft:gray_concrete
setblock 223 157 519 minecraft:pearlescent_froglight
fill 223 157 520 223 161 520 minecraft:gray_concrete
setblock 223 157 521 minecraft:pearlescent_froglight
setblock 223 157 523 minecraft:pearlescent_froglight
setblock 223 157 525 minecraft:pearlescent_froglight
setblock 224 157 514 minecraft:pearlescent_froglight
setblock 224 157 516 minecraft:pearlescent_froglight
fill 224 157 517 224 161 517 minecraft:gray_concrete
setblock 224 157 518 minecraft:pearlescent_froglight
fill 224 157 519 224 161 519 minecraft:gray_concrete
setblock 224 157 520 minecraft:pearlescent_froglight
fill 224 157 521 224 161 521 minecraft:gray_concrete
setblock 224 157 522 minecraft:pearlescent_froglight
setblock 224 157 524 minecraft:pearlescent_froglight
setblock 225 157 513 minecraft:pearlescent_froglight
setblock 225 157 515 minecraft:pearlescent_froglight
setblock 225 157 517 minecraft:pearlescent_froglight
setblock 225 157 518 minecraft:white_concrete
setblock 225 157 519 minecraft:pearlescent_froglight
setblock 225 157 520 minecraft:white_concrete
setblock 225 157 521 minecraft:pearlescent_froglight
setblock 225 157 523 minecraft:pearlescent_froglight
setblock 225 157 525 minecraft:pearlescent_froglight
fill 225 157 534 225 157 536 minecraft:white_concrete
setblock 226 157 514 minecraft:pearlescent_froglight
setblock 226 157 516 minecraft:pearlescent_froglight
fill 226 157 517 226 161 517 minecraft:gray_concrete
setblock 226 157 518 minecraft:pearlescent_froglight
fill 226 157 519 226 161 519 minecraft:gray_concrete
setblock 226 157 520 minecraft:pearlescent_froglight
fill 226 157 521 226 161 521 minecraft:gray_concrete
setblock 226 157 522 minecraft:pearlescent_froglight
setblock 226 157 524 minecraft:pearlescent_froglight
fill 226 157 534 228 157 534 minecraft:white_concrete
fill 226 157 536 228 157 536 minecraft:white_concrete
setblock 227 157 513 minecraft:pearlescent_froglight
setblock 227 157 515 minecraft:pearlescent_froglight
setblock 227 157 517 minecraft:pearlescent_froglight
fill 227 157 518 227 161 518 minecraft:gray_concrete
setblock 227 157 519 minecraft:pearlescent_froglight
fill 227 157 520 227 161 520 minecraft:gray_concrete
setblock 227 157 521 minecraft:pearlescent_froglight
setblock 227 157 523 minecraft:pearlescent_froglight
setblock 227 157 525 minecraft:pearlescent_froglight
fill 227 157 528 228 157 528 minecraft:black_concrete
setblock 228 157 514 minecraft:pearlescent_froglight
setblock 228 157 516 minecraft:pearlescent_froglight
setblock 228 157 518 minecraft:pearlescent_froglight
setblock 228 157 520 minecraft:pearlescent_froglight
setblock 228 157 522 minecraft:pearlescent_froglight
setblock 228 157 524 minecraft:pearlescent_froglight
setblock 228 157 535 minecraft:white_concrete
setblock 229 157 513 minecraft:pearlescent_froglight
setblock 229 157 515 minecraft:pearlescent_froglight
setblock 229 157 517 minecraft:pearlescent_froglight
setblock 229 157 519 minecraft:pearlescent_froglight
setblock 229 157 521 minecraft:pearlescent_froglight
setblock 229 157 523 minecraft:pearlescent_froglight
setblock 229 157 525 minecraft:pearlescent_froglight
fill 188 158 515 188 163 515 minecraft:pearlescent_froglight
fill 188 158 523 188 163 523 minecraft:pearlescent_froglight
fill 188 158 531 188 163 531 minecraft:pearlescent_froglight
fill 188 158 539 188 163 539 minecraft:pearlescent_froglight
fill 188 158 547 188 163 547 minecraft:pearlescent_froglight
fill 191 158 552 191 163 552 minecraft:pearlescent_froglight
fill 195 158 510 195 163 510 minecraft:pearlescent_froglight
fill 199 158 552 199 163 552 minecraft:pearlescent_froglight
fill 203 158 510 203 163 510 minecraft:pearlescent_froglight
fill 207 158 552 207 163 552 minecraft:pearlescent_froglight
fill 210 158 542 210 159 542 minecraft:gray_concrete
fill 210 158 544 210 159 544 minecraft:gray_concrete
fill 210 158 546 210 159 546 minecraft:gray_concrete
fill 210 158 548 210 159 548 minecraft:gray_concrete
fill 210 158 550 210 159 550 minecraft:gray_concrete
fill 211 158 510 211 163 510 minecraft:pearlescent_froglight
fill 211 158 543 211 159 543 minecraft:gray_concrete
fill 211 158 545 211 159 545 minecraft:gray_concrete
fill 211 158 547 211 159 547 minecraft:gray_concrete
fill 211 158 549 211 159 549 minecraft:gray_concrete
fill 211 158 551 211 159 551 minecraft:gray_concrete
fill 212 158 542 212 159 542 minecraft:gray_concrete
fill 212 158 544 212 159 544 minecraft:gray_concrete
fill 212 158 546 212 159 546 minecraft:gray_concrete
fill 212 158 548 212 159 548 minecraft:gray_concrete
fill 212 158 550 212 159 550 minecraft:gray_concrete
fill 213 158 543 213 159 543 minecraft:gray_concrete
fill 213 158 545 213 159 545 minecraft:gray_concrete
fill 213 158 547 213 159 547 minecraft:gray_concrete
fill 213 158 549 213 159 549 minecraft:gray_concrete
fill 213 158 551 213 159 551 minecraft:gray_concrete
fill 214 158 542 214 159 542 minecraft:gray_concrete
fill 214 158 544 214 159 544 minecraft:gray_concrete
fill 214 158 546 214 159 546 minecraft:gray_concrete
fill 214 158 548 214 159 548 minecraft:gray_concrete
fill 214 158 550 214 159 550 minecraft:gray_concrete
fill 215 158 543 215 159 543 minecraft:gray_concrete
fill 215 158 545 215 159 545 minecraft:gray_concrete
fill 215 158 547 215 159 547 minecraft:gray_concrete
fill 215 158 549 215 159 549 minecraft:gray_concrete
fill 215 158 551 215 159 551 minecraft:gray_concrete
fill 215 158 552 215 163 552 minecraft:pearlescent_froglight
fill 216 158 542 216 159 542 minecraft:gray_concrete
fill 216 158 544 216 159 544 minecraft:gray_concrete
fill 216 158 546 216 159 546 minecraft:gray_concrete
fill 216 158 548 216 159 548 minecraft:gray_concrete
fill 216 158 550 216 159 550 minecraft:gray_concrete
fill 217 158 543 217 159 543 minecraft:gray_concrete
fill 217 158 545 217 159 545 minecraft:gray_concrete
fill 217 158 547 217 159 547 minecraft:gray_concrete
fill 217 158 549 217 159 549 minecraft:gray_concrete
fill 217 158 551 217 159 551 minecraft:gray_concrete
fill 218 158 542 218 159 542 minecraft:gray_concrete
fill 218 158 544 218 159 544 minecraft:gray_concrete
fill 218 158 546 218 159 546 minecraft:gray_concrete
fill 218 158 548 218 159 548 minecraft:gray_concrete
fill 218 158 550 218 159 550 minecraft:gray_concrete
fill 219 158 510 219 163 510 minecraft:pearlescent_froglight
fill 219 158 513 219 159 513 minecraft:gray_concrete
fill 219 158 515 219 159 515 minecraft:gray_concrete
fill 219 158 517 219 159 517 minecraft:gray_concrete
fill 219 158 519 219 159 519 minecraft:gray_concrete
fill 219 158 521 219 159 521 minecraft:gray_concrete
fill 219 158 523 219 159 523 minecraft:gray_concrete
fill 219 158 525 219 159 525 minecraft:gray_concrete
fill 219 158 543 219 159 543 minecraft:gray_concrete
fill 219 158 545 219 159 545 minecraft:gray_concrete
fill 219 158 547 219 159 547 minecraft:gray_concrete
fill 219 158 549 219 159 549 minecraft:gray_concrete
fill 219 158 551 219 159 551 minecraft:gray_concrete
fill 220 158 514 220 159 514 minecraft:gray_concrete
fill 220 158 516 220 159 516 minecraft:gray_concrete
fill 220 158 518 220 159 518 minecraft:gray_concrete
fill 220 158 520 220 159 520 minecraft:gray_concrete
fill 220 158 522 220 159 522 minecraft:gray_concrete
fill 220 158 524 220 159 524 minecraft:gray_concrete
fill 220 158 542 220 159 542 minecraft:gray_concrete
fill 220 158 544 220 159 544 minecraft:gray_concrete
fill 220 158 546 220 159 546 minecraft:gray_concrete
fill 220 158 548 220 159 548 minecraft:gray_concrete
fill 220 158 550 220 159 550 minecraft:gray_concrete
fill 221 158 513 221 159 513 minecraft:gray_concrete
fill 221 158 515 221 159 515 minecraft:gray_concrete
fill 221 158 517 221 159 517 minecraft:gray_concrete
fill 221 158 519 221 159 519 minecraft:gray_concrete
fill 221 158 521 221 159 521 minecraft:gray_concrete
fill 221 158 523 221 159 523 minecraft:gray_concrete
fill 221 158 525 221 159 525 minecraft:gray_concrete
fill 222 158 514 222 159 514 minecraft:gray_concrete
fill 222 158 516 222 159 516 minecraft:gray_concrete
fill 222 158 518 222 159 518 minecraft:gray_concrete
fill 222 158 520 222 159 520 minecraft:gray_concrete
fill 222 158 522 222 159 522 minecraft:gray_concrete
fill 222 158 524 222 159 524 minecraft:gray_concrete
fill 223 158 513 223 159 513 minecraft:gray_concrete
fill 223 158 515 223 159 515 minecraft:gray_concrete
fill 223 158 517 223 159 517 minecraft:gray_concrete
fill 223 158 519 223 159 519 minecraft:gray_concrete
fill 223 158 521 223 159 521 minecraft:gray_concrete
fill 223 158 523 223 159 523 minecraft:gray_concrete
fill 223 158 525 223 159 525 minecraft:gray_concrete
fill 223 158 552 223 163 552 minecraft:pearlescent_froglight
fill 224 158 514 224 159 514 minecraft:gray_concrete
fill 224 158 516 224 159 516 minecraft:gray_concrete
fill 224 158 518 226 159 518 minecraft:gray_concrete
fill 224 158 520 226 159 520 minecraft:gray_concrete
fill 224 158 522 224 159 522 minecraft:gray_concrete
fill 224 158 524 224 159 524 minecraft:gray_concrete
fill 225 158 513 225 159 513 minecraft:gray_concrete
fill 225 158 515 225 159 515 minecraft:gray_concrete
fill 225 158 517 225 159 517 minecraft:gray_concrete
fill 225 158 519 225 159 519 minecraft:gray_concrete
fill 225 158 521 225 159 521 minecraft:gray_concrete
fill 225 158 523 225 159 523 minecraft:gray_concrete
fill 225 158 525 225 159 525 minecraft:gray_concrete
fill 226 158 514 226 159 514 minecraft:gray_concrete
fill 226 158 516 226 159 516 minecraft:gray_concrete
fill 226 158 522 226 159 522 minecraft:gray_concrete
fill 226 158 524 226 159 524 minecraft:gray_concrete
fill 227 158 510 227 163 510 minecraft:pearlescent_froglight
fill 227 158 513 227 159 513 minecraft:gray_concrete
fill 227 158 515 227 159 515 minecraft:gray_concrete
fill 227 158 517 227 159 517 minecraft:gray_concrete
fill 227 158 519 227 159 519 minecraft:gray_concrete
fill 227 158 521 227 159 521 minecraft:gray_concrete
fill 227 158 523 227 159 523 minecraft:gray_concrete
fill 227 158 525 227 159 525 minecraft:gray_concrete
fill 228 158 514 228 159 514 minecraft:gray_concrete
fill 228 158 516 228 159 516 minecraft:gray_concrete
fill 228 158 518 228 159 518 minecraft:gray_concrete
fill 228 158 520 228 159 520 minecraft:gray_concrete
fill 228 158 522 228 159 522 minecraft:gray_concrete
fill 228 158 524 228 159 524 minecraft:gray_concrete
fill 229 158 513 229 159 513 minecraft:gray_concrete
fill 229 158 515 229 159 515 minecraft:gray_concrete
fill 229 158 517 229 159 517 minecraft:gray_concrete
fill 229 158 519 229 159 519 minecraft:gray_concrete
fill 229 158 521 229 159 521 minecraft:gray_concrete
fill 229 158 523 229 159 523 minecraft:gray_concrete
fill 229 158 525 229 159 525 minecraft:gray_concrete
fill 230 158 515 230 163 515 minecraft:pearlescent_froglight
fill 230 158 523 230 163 523 minecraft:pearlescent_froglight
fill 230 158 531 230 163 531 minecraft:pearlescent_froglight
fill 230 158 539 230 163 539 minecraft:pearlescent_froglight
fill 230 158 547 230 163 547 minecraft:pearlescent_froglight
fill 223 159 527 225 160 529 minecraft:gray_concrete
setblock 210 160 542 minecraft:pearlescent_froglight
setblock 210 160 544 minecraft:pearlescent_froglight
setblock 210 160 546 minecraft:pearlescent_froglight
setblock 210 160 548 minecraft:pearlescent_froglight
setblock 210 160 550 minecraft:pearlescent_froglight
setblock 211 160 543 minecraft:pearlescent_froglight
setblock 211 160 545 minecraft:pearlescent_froglight
setblock 211 160 547 minecraft:pearlescent_froglight
setblock 211 160 549 minecraft:pearlescent_froglight
setblock 211 160 551 minecraft:pearlescent_froglight
setblock 212 160 542 minecraft:pearlescent_froglight
setblock 212 160 544 minecraft:pearlescent_froglight
setblock 212 160 546 minecraft:pearlescent_froglight
setblock 212 160 548 minecraft:pearlescent_froglight
setblock 212 160 550 minecraft:pearlescent_froglight
setblock 213 160 543 minecraft:pearlescent_froglight
setblock 213 160 545 minecraft:pearlescent_froglight
setblock 213 160 547 minecraft:pearlescent_froglight
setblock 213 160 549 minecraft:pearlescent_froglight
setblock 213 160 551 minecraft:pearlescent_froglight
setblock 214 160 542 minecraft:pearlescent_froglight
setblock 214 160 544 minecraft:pearlescent_froglight
setblock 214 160 546 minecraft:pearlescent_froglight
setblock 214 160 548 minecraft:pearlescent_froglight
setblock 214 160 550 minecraft:pearlescent_froglight
setblock 215 160 543 minecraft:pearlescent_froglight
setblock 215 160 545 minecraft:pearlescent_froglight
setblock 215 160 547 minecraft:pearlescent_froglight
setblock 215 160 549 minecraft:pearlescent_froglight
setblock 215 160 551 minecraft:pearlescent_froglight
setblock 216 160 542 minecraft:pearlescent_froglight
setblock 216 160 544 minecraft:pearlescent_froglight
setblock 216 160 546 minecraft:pearlescent_froglight
setblock 216 160 548 minecraft:pearlescent_froglight
setblock 216 160 550 minecraft:pearlescent_froglight
setblock 217 160 543 minecraft:pearlescent_froglight
setblock 217 160 545 minecraft:pearlescent_froglight
setblock 217 160 547 minecraft:pearlescent_froglight
setblock 217 160 549 minecraft:pearlescent_froglight
setblock 217 160 551 minecraft:pearlescent_froglight
setblock 218 160 542 minecraft:pearlescent_froglight
setblock 218 160 544 minecraft:pearlescent_froglight
setblock 218 160 546 minecraft:pearlescent_froglight
setblock 218 160 548 minecraft:pearlescent_froglight
setblock 218 160 550 minecraft:pearlescent_froglight
setblock 219 160 513 minecraft:pearlescent_froglight
setblock 219 160 515 minecraft:pearlescent_froglight
setblock 219 160 517 minecraft:pearlescent_froglight
setblock 219 160 519 minecraft:pearlescent_froglight
setblock 219 160 521 minecraft:pearlescent_froglight
setblock 219 160 523 minecraft:pearlescent_froglight
setblock 219 160 525 minecraft:pearlescent_froglight
setblock 219 160 543 minecraft:pearlescent_froglight
setblock 219 160 545 minecraft:pearlescent_froglight
setblock 219 160 547 minecraft:pearlescent_froglight
setblock 219 160 549 minecraft:pearlescent_froglight
setblock 219 160 551 minecraft:pearlescent_froglight
setblock 220 160 514 minecraft:pearlescent_froglight
setblock 220 160 516 minecraft:pearlescent_froglight
setblock 220 160 518 minecraft:pearlescent_froglight
setblock 220 160 520 minecraft:pearlescent_froglight
setblock 220 160 522 minecraft:pearlescent_froglight
setblock 220 160 524 minecraft:pearlescent_froglight
setblock 220 160 542 minecraft:pearlescent_froglight
setblock 220 160 544 minecraft:pearlescent_froglight
setblock 220 160 546 minecraft:pearlescent_froglight
setblock 220 160 548 minecraft:pearlescent_froglight
setblock 220 160 550 minecraft:pearlescent_froglight
setblock 221 160 513 minecraft:pearlescent_froglight
setblock 221 160 515 minecraft:pearlescent_froglight
setblock 221 160 517 minecraft:pearlescent_froglight
setblock 221 160 519 minecraft:pearlescent_froglight
setblock 221 160 521 minecraft:pearlescent_froglight
setblock 221 160 523 minecraft:pearlescent_froglight
setblock 221 160 525 minecraft:pearlescent_froglight
setblock 222 160 514 minecraft:pearlescent_froglight
setblock 222 160 516 minecraft:pearlescent_froglight
setblock 222 160 518 minecraft:pearlescent_froglight
setblock 222 160 520 minecraft:pearlescent_froglight
setblock 222 160 522 minecraft:pearlescent_froglight
setblock 222 160 524 minecraft:pearlescent_froglight
setblock 223 160 513 minecraft:pearlescent_froglight
setblock 223 160 515 minecraft:pearlescent_froglight
setblock 223 160 517 minecraft:pearlescent_froglight
setblock 223 160 519 minecraft:pearlescent_froglight
setblock 223 160 521 minecraft:pearlescent_froglight
setblock 223 160 523 minecraft:pearlescent_froglight
setblock 223 160 525 minecraft:pearlescent_froglight
setblock 224 160 514 minecraft:pearlescent_froglight
setblock 224 160 516 minecraft:pearlescent_froglight
setblock 224 160 518 minecraft:pearlescent_froglight
setblock 224 160 520 minecraft:pearlescent_froglight
setblock 224 160 522 minecraft:pearlescent_froglight
setblock 224 160 524 minecraft:pearlescent_froglight
setblock 225 160 513 minecraft:pearlescent_froglight
setblock 225 160 515 minecraft:pearlescent_froglight
setblock 225 160 517 minecraft:pearlescent_froglight
fill 225 160 518 225 161 518 minecraft:gray_concrete
setblock 225 160 519 minecraft:pearlescent_froglight
fill 225 160 520 225 161 520 minecraft:gray_concrete
setblock 225 160 521 minecraft:pearlescent_froglight
setblock 225 160 523 minecraft:pearlescent_froglight
setblock 225 160 525 minecraft:pearlescent_froglight
setblock 226 160 514 minecraft:pearlescent_froglight
setblock 226 160 516 minecraft:pearlescent_froglight
setblock 226 160 518 minecraft:pearlescent_froglight
setblock 226 160 520 minecraft:pearlescent_froglight
setblock 226 160 522 minecraft:pearlescent_froglight
setblock 226 160 524 minecraft:pearlescent_froglight
setblock 227 160 513 minecraft:pearlescent_froglight
setblock 227 160 515 minecraft:pearlescent_froglight
setblock 227 160 517 minecraft:pearlescent_froglight
setblock 227 160 519 minecraft:pearlescent_froglight
setblock 227 160 521 minecraft:pearlescent_froglight
setblock 227 160 523 minecraft:pearlescent_froglight
setblock 227 160 525 minecraft:pearlescent_froglight
setblock 228 160 514 minecraft:pearlescent_froglight
setblock 228 160 516 minecraft:pearlescent_froglight
setblock 228 160 518 minecraft:pearlescent_froglight
setblock 228 160 520 minecraft:pearlescent_froglight
setblock 228 160 522 minecraft:pearlescent_froglight
setblock 228 160 524 minecraft:pearlescent_froglight
setblock 229 160 513 minecraft:pearlescent_froglight
setblock 229 160 515 minecraft:pearlescent_froglight
setblock 229 160 517 minecraft:pearlescent_froglight
setblock 229 160 519 minecraft:pearlescent_froglight
setblock 229 160 521 minecraft:pearlescent_froglight
setblock 229 160 523 minecraft:pearlescent_froglight
setblock 229 160 525 minecraft:pearlescent_froglight
setblock 191 161 513 minecraft:light[level=10]
setblock 191 161 521 minecraft:light[level=10]
setblock 191 161 529 minecraft:light[level=10]
setblock 191 161 537 minecraft:light[level=10]
setblock 191 161 545 minecraft:light[level=10]
setblock 199 161 513 minecraft:light[level=10]
setblock 199 161 521 minecraft:light[level=10]
setblock 199 161 529 minecraft:light[level=10]
setblock 199 161 537 minecraft:light[level=10]
setblock 199 161 545 minecraft:light[level=10]
setblock 207 161 513 minecraft:light[level=10]
setblock 207 161 521 minecraft:light[level=10]
setblock 207 161 529 minecraft:light[level=10]
setblock 207 161 537 minecraft:light[level=10]
setblock 207 161 545 minecraft:light[level=10]
fill 210 161 542 210 162 542 minecraft:gray_concrete
fill 210 161 544 210 162 544 minecraft:gray_concrete
fill 210 161 546 210 162 546 minecraft:gray_concrete
fill 210 161 548 210 162 548 minecraft:gray_concrete
fill 210 161 550 210 162 550 minecraft:gray_concrete
fill 211 161 543 211 162 543 minecraft:gray_concrete
fill 211 161 545 211 162 545 minecraft:gray_concrete
fill 211 161 547 211 162 547 minecraft:gray_concrete
fill 211 161 549 211 162 549 minecraft:gray_concrete
fill 211 161 551 211 162 551 minecraft:gray_concrete
fill 212 161 542 212 162 542 minecraft:gray_concrete
fill 212 161 544 212 162 544 minecraft:gray_concrete
fill 212 161 546 212 162 546 minecraft:gray_concrete
fill 212 161 548 212 162 548 minecraft:gray_concrete
fill 212 161 550 212 162 550 minecraft:gray_concrete
fill 213 161 543 213 162 543 minecraft:gray_concrete
fill 213 161 545 213 162 545 minecraft:gray_concrete
fill 213 161 547 213 162 547 minecraft:gray_concrete
fill 213 161 549 213 162 549 minecraft:gray_concrete
fill 213 161 551 213 162 551 minecraft:gray_concrete
fill 214 161 542 214 162 542 minecraft:gray_concrete
fill 214 161 544 214 162 544 minecraft:gray_concrete
fill 214 161 546 214 162 546 minecraft:gray_concrete
fill 214 161 548 214 162 548 minecraft:gray_concrete
fill 214 161 550 214 162 550 minecraft:gray_concrete
setblock 215 161 513 minecraft:light[level=10]
setblock 215 161 521 minecraft:light[level=10]
setblock 215 161 529 minecraft:light[level=10]
setblock 215 161 537 minecraft:light[level=10]
fill 215 161 543 215 162 543 minecraft:gray_concrete
fill 215 161 545 215 162 545 minecraft:gray_concrete
fill 215 161 547 215 162 547 minecraft:gray_concrete
fill 215 161 549 215 162 549 minecraft:gray_concrete
fill 215 161 551 215 162 551 minecraft:gray_concrete
fill 216 161 542 216 162 542 minecraft:gray_concrete
fill 216 161 544 216 162 544 minecraft:gray_concrete
fill 216 161 546 216 162 546 minecraft:gray_concrete
fill 216 161 548 216 162 548 minecraft:gray_concrete
fill 216 161 550 216 162 550 minecraft:gray_concrete
fill 217 161 543 217 162 543 minecraft:gray_concrete
fill 217 161 545 217 162 545 minecraft:gray_concrete
fill 217 161 547 217 162 547 minecraft:gray_concrete
fill 217 161 549 217 162 549 minecraft:gray_concrete
fill 217 161 551 217 162 551 minecraft:gray_concrete
fill 218 161 542 218 162 542 minecraft:gray_concrete
fill 218 161 544 218 162 544 minecraft:gray_concrete
fill 218 161 546 218 162 546 minecraft:gray_concrete
fill 218 161 548 218 162 548 minecraft:gray_concrete
fill 218 161 550 218 162 550 minecraft:gray_concrete
setblock 219 161 513 minecraft:gray_concrete
setblock 219 161 515 minecraft:gray_concrete
setblock 219 161 517 minecraft:gray_concrete
setblock 219 161 519 minecraft:gray_concrete
setblock 219 161 521 minecraft:gray_concrete
setblock 219 161 523 minecraft:gray_concrete
setblock 219 161 525 minecraft:gray_concrete
fill 219 161 543 219 162 543 minecraft:gray_concrete
fill 219 161 545 219 162 545 minecraft:gray_concrete
fill 219 161 547 219 162 547 minecraft:gray_concrete
fill 219 161 549 219 162 549 minecraft:gray_concrete
fill 219 161 551 219 162 551 minecraft:gray_concrete
setblock 220 161 514 minecraft:gray_concrete
setblock 220 161 516 minecraft:gray_concrete
setblock 220 161 518 minecraft:gray_concrete
setblock 220 161 520 minecraft:gray_concrete
setblock 220 161 522 minecraft:gray_concrete
setblock 220 161 524 minecraft:gray_concrete
fill 220 161 542 220 162 542 minecraft:gray_concrete
fill 220 161 544 220 162 544 minecraft:gray_concrete
fill 220 161 546 220 162 546 minecraft:gray_concrete
fill 220 161 548 220 162 548 minecraft:gray_concrete
fill 220 161 550 220 162 550 minecraft:gray_concrete
setblock 221 161 513 minecraft:gray_concrete
setblock 221 161 515 minecraft:gray_concrete
setblock 221 161 517 minecraft:gray_concrete
setblock 221 161 519 minecraft:gray_concrete
setblock 221 161 521 minecraft:gray_concrete
setblock 221 161 523 minecraft:gray_concrete
setblock 221 161 525 minecraft:gray_concrete
setblock 222 161 514 minecraft:gray_concrete
setblock 222 161 516 minecraft:gray_concrete
setblock 222 161 518 minecraft:gray_concrete
setblock 222 161 520 minecraft:gray_concrete
setblock 222 161 522 minecraft:gray_concrete
setblock 222 161 524 minecraft:gray_concrete
setblock 223 161 513 minecraft:gray_concrete
setblock 223 161 515 minecraft:gray_concrete
setblock 223 161 517 minecraft:gray_concrete
setblock 223 161 519 minecraft:gray_concrete
setblock 223 161 521 minecraft:gray_concrete
setblock 223 161 523 minecraft:gray_concrete
setblock 223 161 525 minecraft:gray_concrete
fill 223 161 528 225 163 528 minecraft:gray_concrete
setblock 223 161 529 minecraft:light[level=10]
setblock 223 161 537 minecraft:light[level=10]
setblock 223 161 545 minecraft:light[level=10]
setblock 224 161 514 minecraft:gray_concrete
setblock 224 161 516 minecraft:gray_concrete
setblock 224 161 518 minecraft:gray_concrete
setblock 224 161 520 minecraft:gray_concrete
setblock 224 161 522 minecraft:gray_concrete
setblock 224 161 524 minecraft:gray_concrete
fill 224 161 527 224 163 527 minecraft:gray_concrete
fill 224 161 529 224 163 529 minecraft:gray_concrete
setblock 225 161 513 minecraft:gray_concrete
setblock 225 161 515 minecraft:gray_concrete
setblock 225 161 517 minecraft:gray_concrete
setblock 225 161 519 minecraft:gray_concrete
setblock 225 161 521 minecraft:gray_concrete
setblock 225 161 523 minecraft:gray_concrete
setblock 225 161 525 minecraft:gray_concrete
setblock 226 161 514 minecraft:gray_concrete
setblock 226 161 516 minecraft:gray_concrete
setblock 226 161 518 minecraft:gray_concrete
setblock 226 161 520 minecraft:gray_concrete
setblock 226 161 522 minecraft:gray_concrete
setblock 226 161 524 minecraft:gray_concrete
setblock 227 161 513 minecraft:gray_concrete
setblock 227 161 515 minecraft:gray_concrete
setblock 227 161 517 minecraft:gray_concrete
setblock 227 161 519 minecraft:gray_concrete
setblock 227 161 521 minecraft:gray_concrete
setblock 227 161 523 minecraft:gray_concrete
setblock 227 161 525 minecraft:gray_concrete
setblock 228 161 514 minecraft:gray_concrete
setblock 228 161 516 minecraft:gray_concrete
setblock 228 161 518 minecraft:gray_concrete
setblock 228 161 520 minecraft:gray_concrete
setblock 228 161 522 minecraft:gray_concrete
setblock 228 161 524 minecraft:gray_concrete
fill 229 161 513 229 184 513 minecraft:gray_concrete
setblock 229 161 515 minecraft:gray_concrete
setblock 229 161 517 minecraft:gray_concrete
setblock 229 161 519 minecraft:gray_concrete
fill 229 161 521 229 184 521 minecraft:gray_concrete
setblock 229 161 523 minecraft:gray_concrete
setblock 229 161 525 minecraft:gray_concrete
fill 220 162 514 228 162 524 minecraft:white_concrete
setblock 210 163 542 minecraft:pearlescent_froglight
setblock 210 163 544 minecraft:pearlescent_froglight
setblock 210 163 546 minecraft:pearlescent_froglight
setblock 210 163 548 minecraft:pearlescent_froglight
setblock 210 163 550 minecraft:pearlescent_froglight
setblock 211 163 543 minecraft:pearlescent_froglight
setblock 211 163 545 minecraft:pearlescent_froglight
setblock 211 163 547 minecraft:pearlescent_froglight
setblock 211 163 549 minecraft:pearlescent_froglight
setblock 211 163 551 minecraft:pearlescent_froglight
setblock 212 163 542 minecraft:pearlescent_froglight
setblock 212 163 544 minecraft:pearlescent_froglight
setblock 212 163 546 minecraft:pearlescent_froglight
setblock 212 163 548 minecraft:pearlescent_froglight
setblock 212 163 550 minecraft:pearlescent_froglight
setblock 213 163 543 minecraft:pearlescent_froglight
setblock 213 163 545 minecraft:pearlescent_froglight
setblock 213 163 547 minecraft:pearlescent_froglight
setblock 213 163 549 minecraft:pearlescent_froglight
setblock 213 163 551 minecraft:pearlescent_froglight
setblock 214 163 542 minecraft:pearlescent_froglight
setblock 214 163 544 minecraft:pearlescent_froglight
setblock 214 163 546 minecraft:pearlescent_froglight
setblock 214 163 548 minecraft:pearlescent_froglight
setblock 214 163 550 minecraft:pearlescent_froglight
setblock 215 163 543 minecraft:pearlescent_froglight
setblock 215 163 545 minecraft:pearlescent_froglight
setblock 215 163 547 minecraft:pearlescent_froglight
setblock 215 163 549 minecraft:pearlescent_froglight
setblock 215 163 551 minecraft:pearlescent_froglight
setblock 216 163 542 minecraft:pearlescent_froglight
setblock 216 163 544 minecraft:pearlescent_froglight
setblock 216 163 546 minecraft:pearlescent_froglight
setblock 216 163 548 minecraft:pearlescent_froglight
setblock 216 163 550 minecraft:pearlescent_froglight
setblock 217 163 543 minecraft:pearlescent_froglight
setblock 217 163 545 minecraft:pearlescent_froglight
setblock 217 163 547 minecraft:pearlescent_froglight
setblock 217 163 549 minecraft:pearlescent_froglight
setblock 217 163 551 minecraft:pearlescent_froglight
setblock 218 163 542 minecraft:pearlescent_froglight
setblock 218 163 544 minecraft:pearlescent_froglight
setblock 218 163 546 minecraft:pearlescent_froglight
setblock 218 163 548 minecraft:pearlescent_froglight
setblock 218 163 550 minecraft:pearlescent_froglight
setblock 219 163 543 minecraft:pearlescent_froglight
setblock 219 163 545 minecraft:pearlescent_froglight
setblock 219 163 547 minecraft:pearlescent_froglight
setblock 219 163 549 minecraft:pearlescent_froglight
setblock 219 163 551 minecraft:pearlescent_froglight
setblock 220 163 542 minecraft:pearlescent_froglight
setblock 220 163 544 minecraft:pearlescent_froglight
setblock 220 163 546 minecraft:pearlescent_froglight
setblock 220 163 548 minecraft:pearlescent_froglight
setblock 220 163 550 minecraft:pearlescent_froglight
fill 221 163 515 227 163 523 minecraft:white_concrete
fill 188 164 515 188 171 515 minecraft:black_concrete
fill 188 164 523 188 171 523 minecraft:black_concrete
fill 188 164 531 188 171 531 minecraft:black_concrete
fill 188 164 539 188 171 539 minecraft:black_concrete
fill 188 164 547 188 171 547 minecraft:black_concrete
fill 191 164 552 191 171 552 minecraft:black_concrete
fill 195 164 510 195 171 510 minecraft:black_concrete
fill 199 164 552 199 171 552 minecraft:black_concrete
fill 203 164 510 203 171 510 minecraft:black_concrete
fill 207 164 552 207 171 552 minecraft:black_concrete
fill 210 164 542 210 166 542 minecraft:gray_concrete
fill 210 164 544 210 166 544 minecraft:gray_concrete
fill 210 164 546 210 166 546 minecraft:gray_concrete
fill 210 164 548 210 166 548 minecraft:gray_concrete
fill 210 164 550 210 166 550 minecraft:gray_concrete
fill 211 164 510 211 171 510 minecraft:black_concrete
fill 211 164 543 211 166 543 minecraft:gray_concrete
fill 211 164 545 211 166 545 minecraft:gray_concrete
fill 211 164 547 211 166 547 minecraft:gray_concrete
fill 211 164 549 211 166 549 minecraft:gray_concrete
fill 211 164 551 211 184 551 minecraft:gray_concrete
fill 212 164 542 212 166 542 minecraft:gray_concrete
fill 212 164 544 212 166 544 minecraft:gray_concrete
fill 212 164 546 212 166 546 minecraft:gray_concrete
fill 212 164 548 212 166 548 minecraft:gray_concrete
fill 212 164 550 212 166 550 minecraft:gray_concrete
fill 213 164 543 213 166 543 minecraft:gray_concrete
fill 213 164 545 213 166 545 minecraft:gray_concrete
fill 213 164 547 213 166 547 minecraft:gray_concrete
fill 213 164 549 213 166 549 minecraft:gray_concrete
fill 213 164 551 213 166 551 minecraft:gray_concrete
fill 214 164 542 214 166 542 minecraft:gray_concrete
fill 214 164 544 214 166 544 minecraft:gray_concrete
fill 214 164 546 214 166 546 minecraft:gray_concrete
fill 214 164 548 214 166 548 minecraft:gray_concrete
fill 214 164 550 214 166 550 minecraft:gray_concrete
fill 215 164 543 215 166 543 minecraft:gray_concrete
fill 215 164 545 215 166 545 minecraft:gray_concrete
fill 215 164 547 215 166 547 minecraft:gray_concrete
fill 215 164 549 215 166 549 minecraft:gray_concrete
fill 215 164 551 215 166 551 minecraft:gray_concrete
fill 215 164 552 215 171 552 minecraft:black_concrete
fill 216 164 542 216 166 542 minecraft:gray_concrete
fill 216 164 544 216 166 544 minecraft:gray_concrete
fill 216 164 546 216 166 546 minecraft:gray_concrete
fill 216 164 548 216 166 548 minecraft:gray_concrete
fill 216 164 550 216 166 550 minecraft:gray_concrete
fill 217 164 543 217 166 543 minecraft:gray_concrete
fill 217 164 545 217 166 545 minecraft:gray_concrete
fill 217 164 547 217 166 547 minecraft:gray_concrete
fill 217 164 549 217 166 549 minecraft:gray_concrete
fill 217 164 551 217 166 551 minecraft:gray_concrete
fill 218 164 542 218 166 542 minecraft:gray_concrete
fill 218 164 544 218 166 544 minecraft:gray_concrete
fill 218 164 546 218 166 546 minecraft:gray_concrete
fill 218 164 548 218 166 548 minecraft:gray_concrete
fill 218 164 550 218 166 550 minecraft:gray_concrete
fill 219 164 510 219 171 510 minecraft:black_concrete
fill 219 164 543 219 166 543 minecraft:gray_concrete
fill 219 164 545 219 166 545 minecraft:gray_concrete
fill 219 164 547 219 166 547 minecraft:gray_concrete
fill 219 164 549 219 166 549 minecraft:gray_concrete
fill 219 164 551 219 184 551 minecraft:gray_concrete
fill 220 164 542 220 166 542 minecraft:gray_concrete
fill 220 164 544 220 166 544 minecraft:gray_concrete
fill 220 164 546 220 166 546 minecraft:gray_concrete
fill 220 164 548 220 166 548 minecraft:gray_concrete
fill 220 164 550 220 166 550 minecraft:gray_concrete
fill 222 164 516 226 164 522 minecraft:white_concrete
fill 223 164 552 223 171 552 minecraft:black_concrete
fill 224 164 528 224 168 528 minecraft:gray_concrete
fill 226 164 534 226 169 534 minecraft:white_concrete
fill 227 164 510 227 171 510 minecraft:black_concrete
fill 230 164 515 230 171 515 minecraft:black_concrete
fill 230 164 523 230 171 523 minecraft:black_concrete
fill 230 164 531 230 171 531 minecraft:black_concrete
fill 230 164 539 230 171 539 minecraft:black_concrete
fill 230 164 547 230 171 547 minecraft:black_concrete
fill 203 165 548 203 166 550 minecraft:gray_concrete
fill 223 165 517 225 165 521 minecraft:white_concrete
fill 225 166 534 225 169 534 minecraft:white_concrete
fill 226 166 533 226 169 533 minecraft:white_concrete
fill 226 166 535 226 169 535 minecraft:white_concrete
fill 211 167 543 219 167 550 minecraft:white_concrete
fill 225 167 533 225 169 533 minecraft:white_concrete
fill 225 167 535 225 169 535 minecraft:white_concrete
fill 227 167 534 227 169 534 minecraft:white_concrete
fill 189 168 511 189 169 516 minecraft:gray_concrete
fill 189 168 519 190 168 524 minecraft:gray_concrete
fill 189 168 527 190 168 532 minecraft:gray_concrete
fill 189 168 535 190 168 540 minecraft:gray_concrete
fill 189 168 543 190 168 548 minecraft:gray_concrete
fill 189 168 551 194 169 551 minecraft:gray_concrete
fill 190 168 512 190 168 518 minecraft:gray_concrete
fill 190 168 525 190 168 526 minecraft:gray_concrete
fill 190 168 533 190 168 534 minecraft:gray_concrete
fill 190 168 541 190 168 542 minecraft:gray_concrete
fill 190 168 549 190 168 550 minecraft:gray_concrete
fill 191 168 512 228 168 512 minecraft:gray_concrete
fill 191 168 550 229 168 550 minecraft:gray_concrete
fill 192 168 511 197 169 511 minecraft:gray_concrete
fill 197 168 551 202 169 551 minecraft:gray_concrete
fill 200 168 511 205 169 511 minecraft:gray_concrete
fill 205 168 551 210 169 551 minecraft:gray_concrete
fill 208 168 511 213 169 511 minecraft:gray_concrete
fill 212 168 544 218 168 549 minecraft:white_concrete
fill 213 168 551 218 169 551 minecraft:gray_concrete
fill 216 168 511 221 169 511 minecraft:gray_concrete
fill 221 168 551 226 169 551 minecraft:gray_concrete
fill 224 168 511 229 169 511 minecraft:gray_concrete
fill 224 168 534 224 169 534 minecraft:white_concrete
fill 227 168 533 227 169 533 minecraft:white_concrete
fill 227 168 535 227 169 535 minecraft:white_concrete
fill 228 168 513 228 168 549 minecraft:gray_concrete
fill 229 168 514 229 169 519 minecraft:gray_concrete
fill 229 168 522 229 169 527 minecraft:gray_concrete
fill 229 168 530 229 171 535 minecraft:gray_concrete
fill 229 168 538 229 169 543 minecraft:gray_concrete
fill 229 168 546 229 169 549 minecraft:gray_concrete
fill 229 168 551 229 169 551 minecraft:gray_concrete
fill 189 169 519 189 169 524 minecraft:gray_concrete
fill 189 169 527 189 169 532 minecraft:gray_concrete
fill 189 169 535 189 169 540 minecraft:gray_concrete
fill 189 169 543 189 169 548 minecraft:gray_concrete
setblock 191 169 513 minecraft:light[level=10]
setblock 191 169 521 minecraft:light[level=10]
setblock 191 169 529 minecraft:light[level=10]
setblock 191 169 537 minecraft:light[level=10]
setblock 191 169 545 minecraft:light[level=10]
setblock 199 169 513 minecraft:light[level=10]
setblock 199 169 521 minecraft:light[level=10]
setblock 199 169 529 minecraft:light[level=10]
setblock 199 169 537 minecraft:light[level=10]
setblock 199 169 545 minecraft:light[level=10]
setblock 207 169 513 minecraft:light[level=10]
setblock 207 169 521 minecraft:light[level=10]
setblock 207 169 529 minecraft:light[level=10]
setblock 207 169 537 minecraft:light[level=10]
setblock 207 169 545 minecraft:light[level=10]
fill 213 169 545 217 169 548 minecraft:white_concrete
setblock 215 169 513 minecraft:light[level=10]
setblock 215 169 521 minecraft:light[level=10]
setblock 215 169 529 minecraft:light[level=10]
setblock 215 169 537 minecraft:light[level=10]
setblock 223 169 513 minecraft:light[level=10]
setblock 223 169 521 minecraft:light[level=10]
setblock 223 169 529 minecraft:light[level=10]
setblock 223 169 537 minecraft:light[level=10]
setblock 223 169 545 minecraft:light[level=10]
setblock 224 169 528 minecraft:pearlescent_froglight
setblock 224 169 533 minecraft:white_concrete
setblock 224 169 535 minecraft:white_concrete
fill 225 169 532 226 169 532 minecraft:white_concrete
fill 225 169 536 226 169 536 minecraft:white_concrete
setblock 228 169 534 minecraft:white_concrete
setblock 229 169 550 minecraft:gray_concrete
fill 214 170 546 216 170 547 minecraft:white_concrete
fill 223 170 530 228 171 538 minecraft:gray_concrete
fill 229 170 538 229 184 538 minecraft:gray_concrete
fill 188 172 515 188 177 515 minecraft:pearlescent_froglight
fill 188 172 523 188 177 523 minecraft:pearlescent_froglight
fill 188 172 531 188 177 531 minecraft:pearlescent_froglight
fill 188 172 539 188 177 539 minecraft:pearlescent_froglight
fill 188 172 547 188 177 547 minecraft:pearlescent_froglight
fill 191 172 552 191 177 552 minecraft:pearlescent_froglight
fill 195 172 510 195 177 510 minecraft:pearlescent_froglight
fill 199 172 552 199 177 552 minecraft:pearlescent_froglight
fill 203 172 510 203 177 510 minecraft:pearlescent_froglight
fill 207 172 552 207 177 552 minecraft:pearlescent_froglight
fill 211 172 510 211 177 510 minecraft:pearlescent_froglight
fill 215 172 552 215 177 552 minecraft:pearlescent_froglight
fill 219 172 510 219 177 510 minecraft:pearlescent_froglight
fill 223 172 530 223 184 530 minecraft:gray_concrete
setblock 223 172 531 minecraft:pearlescent_froglight
fill 223 172 532 223 184 532 minecraft:gray_concrete
setblock 223 172 533 minecraft:pearlescent_froglight
fill 223 172 534 223 184 534 minecraft:gray_concrete
setblock 223 172 535 minecraft:pearlescent_froglight
fill 223 172 536 223 184 536 minecraft:gray_concrete
setblock 223 172 537 minecraft:pearlescent_froglight
fill 223 172 538 223 184 538 minecraft:gray_concrete
fill 223 172 552 223 177 552 minecraft:pearlescent_froglight
setblock 224 172 530 minecraft:pearlescent_froglight
fill 224 172 531 224 184 531 minecraft:gray_concrete
setblock 224 172 532 minecraft:pearlescent_froglight
fill 224 172 533 224 184 533 minecraft:gray_concrete
setblock 224 172 534 minecraft:pearlescent_froglight
fill 224 172 535 224 184 535 minecraft:gray_concrete
setblock 224 172 536 minecraft:pearlescent_froglight
fill 224 172 537 224 184 537 minecraft:gray_concrete
setblock 224 172 538 minecraft:pearlescent_froglight
fill 225 172 530 225 184 530 minecraft:gray_concrete
setblock 225 172 531 minecraft:pearlescent_froglight
fill 225 172 532 225 184 532 minecraft:gray_concrete
setblock 225 172 533 minecraft:pearlescent_froglight
fill 225 172 534 225 184 534 minecraft:gray_concrete
setblock 225 172 535 minecraft:pearlescent_froglight
fill 225 172 536 225 184 536 minecraft:gray_concrete
setblock 225 172 537 minecraft:pearlescent_froglight
fill 225 172 538 225 184 538 minecraft:gray_concrete
setblock 226 172 530 minecraft:pearlescent_froglight
fill 226 172 531 226 184 531 minecraft:gray_concrete
setblock 226 172 532 minecraft:pearlescent_froglight
fill 226 172 533 226 184 533 minecraft:gray_concrete
setblock 226 172 534 minecraft:pearlescent_froglight
fill 226 172 535 226 184 535 minecraft:gray_concrete
setblock 226 172 536 minecraft:pearlescent_froglight
fill 226 172 537 226 184 537 minecraft:gray_concrete
setblock 226 172 538 minecraft:pearlescent_froglight
fill 226 172 543 228 173 543 minecraft:gray_concrete
fill 227 172 510 227 177 510 minecraft:pearlescent_froglight
fill 227 172 530 227 184 530 minecraft:gray_concrete
setblock 227 172 531 minecraft:pearlescent_froglight
fill 227 172 532 227 184 532 minecraft:gray_concrete
setblock 227 172 533 minecraft:pearlescent_froglight
fill 227 172 534 227 184 534 minecraft:gray_concrete
setblock 227 172 535 minecraft:pearlescent_froglight
fill 227 172 536 227 184 536 minecraft:gray_concrete
setblock 227 172 537 minecraft:pearlescent_froglight
fill 227 172 538 227 184 538 minecraft:gray_concrete
setblock 228 172 530 minecraft:pearlescent_froglight
fill 228 172 531 228 184 531 minecraft:gray_concrete
setblock 228 172 532 minecraft:pearlescent_froglight
fill 228 172 533 228 184 533 minecraft:gray_concrete
setblock 228 172 534 minecraft:pearlescent_froglight
fill 228 172 535 228 184 535 minecraft:gray_concrete
setblock 228 172 536 minecraft:pearlescent_froglight
fill 228 172 537 228 184 537 minecraft:gray_concrete
setblock 228 172 538 minecraft:pearlescent_froglight
fill 229 172 530 229 184 530 minecraft:gray_concrete
fill 229 172 531 230 172 531 minecraft:pearlescent_froglight
fill 229 172 532 229 184 532 minecraft:gray_concrete
setblock 229 172 533 minecraft:pearlescent_froglight
fill 229 172 534 229 184 534 minecraft:gray_concrete
setblock 229 172 535 minecraft:pearlescent_froglight
setblock 229 172 537 minecraft:pearlescent_froglight
fill 230 172 515 230 177 515 minecraft:pearlescent_froglight
fill 230 172 523 230 177 523 minecraft:pearlescent_froglight
fill 230 172 539 230 177 539 minecraft:pearlescent_froglight
fill 230 172 547 230 177 547 minecraft:pearlescent_froglight
fill 223 173 531 223 174 531 minecraft:gray_concrete
fill 223 173 533 223 174 533 minecraft:gray_concrete
fill 223 173 535 223 174 535 minecraft:gray_concrete
fill 223 173 537 223 174 537 minecraft:gray_concrete
fill 224 173 530 224 174 530 minecraft:gray_concrete
fill 224 173 532 224 174 532 minecraft:gray_concrete
fill 224 173 534 224 174 534 minecraft:gray_concrete
fill 224 173 536 224 174 536 minecraft:gray_concrete
fill 224 173 538 224 174 538 minecraft:gray_concrete
fill 225 173 531 225 174 531 minecraft:gray_concrete
fill 225 173 533 225 174 533 minecraft:gray_concrete
fill 225 173 535 225 174 535 minecraft:gray_concrete
fill 225 173 537 225 174 537 minecraft:gray_concrete
fill 226 173 530 226 174 530 minecraft:gray_concrete
fill 226 173 532 226 174 532 minecraft:gray_concrete
fill 226 173 534 226 174 534 minecraft:gray_concrete
fill 226 173 536 226 174 536 minecraft:gray_concrete
fill 226 173 538 226 174 538 minecraft:gray_concrete
fill 227 173 531 227 174 531 minecraft:gray_concrete
fill 227 173 533 227 174 533 minecraft:gray_concrete
fill 227 173 535 227 174 535 minecraft:gray_concrete
fill 227 173 537 227 174 537 minecraft:gray_concrete
fill 228 173 530 228 174 530 minecraft:gray_concrete
fill 228 173 532 228 174 532 minecraft:gray_concrete
fill 228 173 534 228 174 534 minecraft:gray_concrete
fill 228 173 536 228 174 536 minecraft:gray_concrete
fill 228 173 538 228 174 538 minecraft:gray_concrete
fill 229 173 531 229 174 531 minecraft:gray_concrete
fill 229 173 533 229 174 533 minecraft:gray_concrete
fill 229 173 535 229 174 535 minecraft:gray_concrete
fill 229 173 537 229 174 537 minecraft:gray_concrete
fill 230 173 531 230 177 531 minecraft:pearlescent_froglight
setblock 223 175 531 minecraft:pearlescent_froglight
setblock 223 175 533 minecraft:pearlescent_froglight
setblock 223 175 535 minecraft:pearlescent_froglight
setblock 223 175 537 minecraft:pearlescent_froglight
setblock 224 175 530 minecraft:pearlescent_froglight
setblock 224 175 532 minecraft:pearlescent_froglight
setblock 224 175 534 minecraft:pearlescent_froglight
setblock 224 175 536 minecraft:pearlescent_froglight
setblock 224 175 538 minecraft:pearlescent_froglight
setblock 225 175 531 minecraft:pearlescent_froglight
setblock 225 175 533 minecraft:pearlescent_froglight
setblock 225 175 535 minecraft:pearlescent_froglight
setblock 225 175 537 minecraft:pearlescent_froglight
setblock 226 175 530 minecraft:pearlescent_froglight
setblock 226 175 532 minecraft:pearlescent_froglight
setblock 226 175 534 minecraft:pearlescent_froglight
setblock 226 175 536 minecraft:pearlescent_froglight
setblock 226 175 538 minecraft:pearlescent_froglight
setblock 227 175 531 minecraft:pearlescent_froglight
setblock 227 175 533 minecraft:pearlescent_froglight
setblock 227 175 535 minecraft:pearlescent_froglight
setblock 227 175 537 minecraft:pearlescent_froglight
setblock 228 175 530 minecraft:pearlescent_froglight
setblock 228 175 532 minecraft:pearlescent_froglight
setblock 228 175 534 minecraft:pearlescent_froglight
setblock 228 175 536 minecraft:pearlescent_froglight
setblock 228 175 538 minecraft:pearlescent_froglight
setblock 229 175 531 minecraft:pearlescent_froglight
setblock 229 175 533 minecraft:pearlescent_froglight
setblock 229 175 535 minecraft:pearlescent_froglight
setblock 229 175 537 minecraft:pearlescent_froglight
fill 223 176 531 223 177 531 minecraft:gray_concrete
fill 223 176 533 223 177 533 minecraft:gray_concrete
fill 223 176 535 223 177 535 minecraft:gray_concrete
fill 223 176 537 223 177 537 minecraft:gray_concrete
fill 224 176 530 224 177 530 minecraft:gray_concrete
fill 224 176 532 224 177 532 minecraft:gray_concrete
fill 224 176 534 224 177 534 minecraft:gray_concrete
fill 224 176 536 224 177 536 minecraft:gray_concrete
fill 224 176 538 224 177 538 minecraft:gray_concrete
fill 225 176 531 225 177 531 minecraft:gray_concrete
fill 225 176 533 225 177 533 minecraft:gray_concrete
fill 225 176 535 225 177 535 minecraft:gray_concrete
fill 225 176 537 225 177 537 minecraft:gray_concrete
fill 226 176 530 226 177 530 minecraft:gray_concrete
fill 226 176 532 226 177 532 minecraft:gray_concrete
fill 226 176 534 226 177 534 minecraft:gray_concrete
fill 226 176 536 226 177 536 minecraft:gray_concrete
fill 226 176 538 226 177 538 minecraft:gray_concrete
fill 227 176 531 227 177 531 minecraft:gray_concrete
fill 227 176 533 227 177 533 minecraft:gray_concrete
fill 227 176 535 227 177 535 minecraft:gray_concrete
fill 227 176 537 227 177 537 minecraft:gray_concrete
fill 228 176 530 228 177 530 minecraft:gray_concrete
fill 228 176 532 228 177 532 minecraft:gray_concrete
fill 228 176 534 228 177 534 minecraft:gray_concrete
fill 228 176 536 228 177 536 minecraft:gray_concrete
fill 228 176 538 228 177 538 minecraft:gray_concrete
fill 229 176 531 229 177 531 minecraft:gray_concrete
fill 229 176 533 229 177 533 minecraft:gray_concrete
fill 229 176 535 229 177 535 minecraft:gray_concrete
fill 229 176 537 229 177 537 minecraft:gray_concrete
setblock 191 177 513 minecraft:light[level=10]
setblock 191 177 521 minecraft:light[level=10]
setblock 191 177 529 minecraft:light[level=10]
setblock 191 177 537 minecraft:light[level=10]
setblock 191 177 545 minecraft:light[level=10]
setblock 199 177 513 minecraft:light[level=10]
setblock 199 177 521 minecraft:light[level=10]
setblock 199 177 529 minecraft:light[level=10]
setblock 199 177 537 minecraft:light[level=10]
setblock 199 177 545 minecraft:light[level=10]
setblock 207 177 513 minecraft:light[level=10]
setblock 207 177 521 minecraft:light[level=10]
setblock 207 177 529 minecraft:light[level=10]
setblock 207 177 537 minecraft:light[level=10]
setblock 207 177 545 minecraft:light[level=10]
setblock 215 177 513 minecraft:light[level=10]
setblock 215 177 521 minecraft:light[level=10]
setblock 215 177 529 minecraft:light[level=10]
setblock 215 177 537 minecraft:light[level=10]
setblock 215 177 545 minecraft:light[level=10]
setblock 223 177 513 minecraft:light[level=10]
setblock 223 177 521 minecraft:light[level=10]
setblock 223 177 529 minecraft:light[level=10]
setblock 223 177 545 minecraft:light[level=10]
fill 188 178 515 188 199 515 minecraft:black_concrete
fill 188 178 523 188 199 523 minecraft:black_concrete
fill 188 178 531 188 199 531 minecraft:black_concrete
fill 188 178 539 188 199 539 minecraft:black_concrete
fill 188 178 547 188 199 547 minecraft:black_concrete
fill 191 178 552 191 199 552 minecraft:black_concrete
fill 195 178 510 195 199 510 minecraft:black_concrete
fill 199 178 552 199 199 552 minecraft:black_concrete
fill 203 178 510 203 199 510 minecraft:black_concrete
fill 207 178 552 207 199 552 minecraft:black_concrete
fill 211 178 510 211 199 510 minecraft:black_concrete
fill 215 178 552 215 199 552 minecraft:black_concrete
fill 219 178 510 219 199 510 minecraft:black_concrete
setblock 223 178 531 minecraft:pearlescent_froglight
setblock 223 178 533 minecraft:pearlescent_froglight
setblock 223 178 535 minecraft:pearlescent_froglight
setblock 223 178 537 minecraft:pearlescent_froglight
fill 223 178 552 223 199 552 minecraft:black_concrete
setblock 224 178 530 minecraft:pearlescent_froglight
setblock 224 178 532 minecraft:pearlescent_froglight
setblock 224 178 534 minecraft:pearlescent_froglight
setblock 224 178 536 minecraft:pearlescent_froglight
setblock 224 178 538 minecraft:pearlescent_froglight
setblock 225 178 531 minecraft:pearlescent_froglight
setblock 225 178 533 minecraft:pearlescent_froglight
setblock 225 178 535 minecraft:pearlescent_froglight
setblock 225 178 537 minecraft:pearlescent_froglight
setblock 226 178 530 minecraft:pearlescent_froglight
setblock 226 178 532 minecraft:pearlescent_froglight
setblock 226 178 534 minecraft:pearlescent_froglight
setblock 226 178 536 minecraft:pearlescent_froglight
setblock 226 178 538 minecraft:pearlescent_froglight
fill 227 178 510 227 199 510 minecraft:black_concrete
setblock 227 178 531 minecraft:pearlescent_froglight
setblock 227 178 533 minecraft:pearlescent_froglight
setblock 227 178 535 minecraft:pearlescent_froglight
setblock 227 178 537 minecraft:pearlescent_froglight
setblock 228 178 530 minecraft:pearlescent_froglight
setblock 228 178 532 minecraft:pearlescent_froglight
setblock 228 178 534 minecraft:pearlescent_froglight
setblock 228 178 536 minecraft:pearlescent_froglight
setblock 228 178 538 minecraft:pearlescent_froglight
setblock 229 178 531 minecraft:pearlescent_froglight
setblock 229 178 533 minecraft:pearlescent_froglight
setblock 229 178 535 minecraft:pearlescent_froglight
setblock 229 178 537 minecraft:pearlescent_froglight
fill 230 178 515 230 199 515 minecraft:black_concrete
fill 230 178 523 230 199 523 minecraft:black_concrete
fill 230 178 531 230 199 531 minecraft:black_concrete
fill 230 178 539 230 199 539 minecraft:black_concrete
fill 230 178 547 230 199 547 minecraft:black_concrete
fill 223 179 531 223 180 531 minecraft:gray_concrete
fill 223 179 533 223 180 533 minecraft:gray_concrete
fill 223 179 535 223 180 535 minecraft:gray_concrete
fill 223 179 537 223 180 537 minecraft:gray_concrete
fill 224 179 530 224 180 530 minecraft:gray_concrete
fill 224 179 532 224 180 532 minecraft:gray_concrete
fill 224 179 534 224 180 534 minecraft:gray_concrete
fill 224 179 536 224 180 536 minecraft:gray_concrete
fill 224 179 538 224 180 538 minecraft:gray_concrete
fill 225 179 531 225 180 531 minecraft:gray_concrete
fill 225 179 533 225 180 533 minecraft:gray_concrete
fill 225 179 535 225 180 535 minecraft:gray_concrete
fill 225 179 537 225 180 537 minecraft:gray_concrete
fill 226 179 530 226 180 530 minecraft:gray_concrete
fill 226 179 532 226 180 532 minecraft:gray_concrete
fill 226 179 534 226 180 534 minecraft:gray_concrete
fill 226 179 536 226 180 536 minecraft:gray_concrete
fill 226 179 538 226 180 538 minecraft:gray_concrete
fill 227 179 531 227 180 531 minecraft:gray_concrete
fill 227 179 533 227 180 533 minecraft:gray_concrete
fill 227 179 535 227 180 535 minecraft:gray_concrete
fill 227 179 537 227 180 537 minecraft:gray_concrete
fill 228 179 530 228 180 530 minecraft:gray_concrete
fill 228 179 532 228 180 532 minecraft:gray_concrete
fill 228 179 534 228 180 534 minecraft:gray_concrete
fill 228 179 536 228 180 536 minecraft:gray_concrete
fill 228 179 538 228 180 538 minecraft:gray_concrete
fill 229 179 531 229 180 531 minecraft:gray_concrete
fill 229 179 533 229 180 533 minecraft:gray_concrete
fill 229 179 535 229 180 535 minecraft:gray_concrete
fill 229 179 537 229 180 537 minecraft:gray_concrete
setblock 223 181 531 minecraft:pearlescent_froglight
setblock 223 181 533 minecraft:pearlescent_froglight
setblock 223 181 535 minecraft:pearlescent_froglight
setblock 223 181 537 minecraft:pearlescent_froglight
setblock 224 181 530 minecraft:pearlescent_froglight
setblock 224 181 532 minecraft:pearlescent_froglight
setblock 224 181 534 minecraft:pearlescent_froglight
setblock 224 181 536 minecraft:pearlescent_froglight
setblock 224 181 538 minecraft:pearlescent_froglight
setblock 225 181 531 minecraft:pearlescent_froglight
setblock 225 181 533 minecraft:pearlescent_froglight
setblock 225 181 535 minecraft:pearlescent_froglight
setblock 225 181 537 minecraft:pearlescent_froglight
setblock 226 181 530 minecraft:pearlescent_froglight
setblock 226 181 532 minecraft:pearlescent_froglight
setblock 226 181 534 minecraft:pearlescent_froglight
setblock 226 181 536 minecraft:pearlescent_froglight
setblock 226 181 538 minecraft:pearlescent_froglight
setblock 227 181 531 minecraft:pearlescent_froglight
setblock 227 181 533 minecraft:pearlescent_froglight
setblock 227 181 535 minecraft:pearlescent_froglight
setblock 227 181 537 minecraft:pearlescent_froglight
setblock 228 181 530 minecraft:pearlescent_froglight
setblock 228 181 532 minecraft:pearlescent_froglight
setblock 228 181 534 minecraft:pearlescent_froglight
setblock 228 181 536 minecraft:pearlescent_froglight
setblock 228 181 538 minecraft:pearlescent_froglight
setblock 229 181 531 minecraft:pearlescent_froglight
setblock 229 181 533 minecraft:pearlescent_froglight
setblock 229 181 535 minecraft:pearlescent_froglight
setblock 229 181 537 minecraft:pearlescent_froglight
fill 189 182 511 189 183 516 minecraft:gray_concrete
fill 189 182 519 190 182 524 minecraft:gray_concrete
fill 189 182 527 190 182 532 minecraft:gray_concrete
fill 189 182 535 190 182 540 minecraft:gray_concrete
fill 189 182 543 190 182 548 minecraft:gray_concrete
fill 189 182 551 194 183 551 minecraft:gray_concrete
fill 190 182 512 190 182 518 minecraft:gray_concrete
fill 190 182 525 190 182 526 minecraft:gray_concrete
fill 190 182 533 190 182 534 minecraft:gray_concrete
fill 190 182 541 190 182 542 minecraft:gray_concrete
fill 190 182 549 190 182 550 minecraft:gray_concrete
fill 191 182 512 228 182 512 minecraft:gray_concrete
fill 191 182 550 229 182 550 minecraft:gray_concrete
fill 192 182 511 197 183 511 minecraft:gray_concrete
fill 197 182 551 202 183 551 minecraft:gray_concrete
fill 200 182 511 205 183 511 minecraft:gray_concrete
fill 205 182 551 210 183 551 minecraft:gray_concrete
fill 208 182 511 213 183 511 minecraft:gray_concrete
fill 213 182 551 218 183 551 minecraft:gray_concrete
fill 216 182 511 221 183 511 minecraft:gray_concrete
fill 221 182 551 226 183 551 minecraft:gray_concrete
fill 223 182 531 223 184 531 minecraft:gray_concrete
fill 223 182 533 223 184 533 minecraft:gray_concrete
fill 223 182 535 223 184 535 minecraft:gray_concrete
fill 223 182 537 223 184 537 minecraft:gray_concrete
fill 224 182 511 229 183 511 minecraft:gray_concrete
fill 224 182 530 224 184 530 minecraft:gray_concrete
fill 224 182 532 224 184 532 minecraft:gray_concrete
fill 224 182 534 224 184 534 minecraft:gray_concrete
fill 224 182 536 224 184 536 minecraft:gray_concrete
fill 224 182 538 224 184 538 minecraft:gray_concrete
fill 225 182 531 225 184 531 minecraft:gray_concrete
fill 225 182 533 225 184 533 minecraft:gray_concrete
fill 225 182 535 225 184 535 minecraft:gray_concrete
fill 225 182 537 225 184 537 minecraft:gray_concrete
fill 226 182 530 226 184 530 minecraft:gray_concrete
fill 226 182 532 226 184 532 minecraft:gray_concrete
fill 226 182 534 226 184 534 minecraft:gray_concrete
fill 226 182 536 226 184 536 minecraft:gray_concrete
fill 226 182 538 226 184 538 minecraft:gray_concrete
fill 227 182 531 227 184 531 minecraft:gray_concrete
fill 227 182 533 227 184 533 minecraft:gray_concrete
fill 227 182 535 227 184 535 minecraft:gray_concrete
fill 227 182 537 227 184 537 minecraft:gray_concrete
fill 228 182 513 228 182 530 minecraft:gray_concrete
fill 228 182 532 228 184 532 minecraft:gray_concrete
fill 228 182 534 228 184 534 minecraft:gray_concrete
fill 228 182 536 228 184 536 minecraft:gray_concrete
fill 228 182 538 228 182 549 minecraft:gray_concrete
fill 229 182 514 229 183 519 minecraft:gray_concrete
fill 229 182 522 229 183 527 minecraft:gray_concrete
fill 229 182 531 229 184 531 minecraft:gray_concrete
fill 229 182 533 229 184 533 minecraft:gray_concrete
fill 229 182 535 229 184 535 minecraft:gray_concrete
fill 229 182 537 229 184 537 minecraft:gray_concrete
fill 229 182 539 229 183 543 minecraft:gray_concrete
fill 229 182 546 229 183 549 minecraft:gray_concrete
fill 229 182 551 229 183 551 minecraft:gray_concrete
fill 189 183 519 189 183 524 minecraft:gray_concrete
fill 189 183 527 189 183 532 minecraft:gray_concrete
fill 189 183 535 189 183 540 minecraft:gray_concrete
fill 189 183 543 189 183 548 minecraft:gray_concrete
fill 228 183 530 228 184 530 minecraft:gray_concrete
fill 228 183 538 228 184 538 minecraft:gray_concrete
setblock 229 183 550 minecraft:gray_concrete
setblock 191 185 513 minecraft:light[level=10]
setblock 191 185 521 minecraft:light[level=10]
setblock 191 185 529 minecraft:light[level=10]
setblock 191 185 537 minecraft:light[level=10]
setblock 191 185 545 minecraft:light[level=10]
setblock 199 185 513 minecraft:light[level=10]
setblock 199 185 521 minecraft:light[level=10]
setblock 199 185 529 minecraft:light[level=10]
setblock 199 185 537 minecraft:light[level=10]
setblock 199 185 545 minecraft:light[level=10]
setblock 207 185 513 minecraft:light[level=10]
setblock 207 185 521 minecraft:light[level=10]
setblock 207 185 529 minecraft:light[level=10]
setblock 207 185 537 minecraft:light[level=10]
setblock 207 185 545 minecraft:light[level=10]
setblock 215 185 513 minecraft:light[level=10]
setblock 215 185 521 minecraft:light[level=10]
setblock 215 185 529 minecraft:light[level=10]
setblock 215 185 537 minecraft:light[level=10]
setblock 215 185 545 minecraft:light[level=10]
setblock 223 185 513 minecraft:light[level=10]
setblock 223 185 521 minecraft:light[level=10]
setblock 223 185 529 minecraft:light[level=10]
setblock 223 185 537 minecraft:light[level=10]
setblock 223 185 545 minecraft:light[level=10]
setblock 201 189 525 minecraft:white_concrete
fill 204 189 524 206 189 526 minecraft:redstone_block
fill 208 189 519 210 189 521 minecraft:redstone_block
setblock 210 189 516 minecraft:white_concrete
setblock 210 189 534 minecraft:white_concrete
fill 212 189 528 214 189 530 minecraft:redstone_block
fill 214 189 523 216 189 525 minecraft:redstone_block
setblock 219 189 525 minecraft:white_concrete
fill 200 190 522 200 192 528 minecraft:white_concrete
fill 201 190 520 201 192 524 minecraft:white_concrete
fill 201 190 525 203 190 525 minecraft:black_concrete
fill 201 190 526 201 192 530 minecraft:white_concrete
fill 202 190 518 202 192 520 minecraft:white_concrete
fill 202 190 521 203 190 524 minecraft:black_concrete
fill 202 190 526 203 190 529 minecraft:black_concrete
fill 202 190 530 202 192 532 minecraft:white_concrete
fill 203 190 517 203 191 519 minecraft:white_concrete
fill 203 190 520 207 190 520 minecraft:black_concrete
fill 203 190 530 211 190 530 minecraft:black_concrete
fill 203 190 531 203 191 533 minecraft:white_concrete
fill 204 190 517 204 191 518 minecraft:white_concrete
fill 204 190 519 207 190 519 minecraft:black_concrete
fill 204 190 521 207 190 523 minecraft:black_concrete
fill 204 190 527 211 190 529 minecraft:black_concrete
fill 204 190 531 216 190 531 minecraft:black_concrete
fill 204 190 532 204 191 533 minecraft:white_concrete
fill 205 190 516 205 192 517 minecraft:white_concrete
fill 205 190 518 215 190 518 minecraft:black_concrete
fill 205 190 532 215 191 532 minecraft:black_concrete
fill 205 190 533 205 192 534 minecraft:white_concrete
fill 206 190 516 209 192 516 minecraft:white_concrete
fill 206 190 517 214 191 517 minecraft:black_concrete
fill 206 190 533 214 191 533 minecraft:black_concrete
fill 206 190 534 209 192 534 minecraft:white_concrete
fill 207 190 515 213 192 515 minecraft:white_concrete
fill 207 190 524 208 190 526 minecraft:black_concrete
fill 207 190 535 213 192 535 minecraft:white_concrete
fill 208 190 522 213 190 523 minecraft:black_concrete
fill 210 190 516 210 191 516 minecraft:black_concrete
fill 210 190 534 210 191 534 minecraft:black_concrete
fill 211 190 516 215 192 516 minecraft:white_concrete
fill 211 190 519 216 190 521 minecraft:black_concrete
fill 211 190 534 215 192 534 minecraft:white_concrete
fill 212 190 524 213 190 527 minecraft:black_concrete
fill 214 190 522 218 190 522 minecraft:black_concrete
fill 214 190 526 218 190 527 minecraft:black_concrete
fill 215 190 517 217 192 517 minecraft:white_concrete
fill 215 190 528 217 190 530 minecraft:black_concrete
fill 215 190 533 217 192 533 minecraft:white_concrete
fill 216 190 518 218 191 518 minecraft:white_concrete
fill 216 190 532 218 191 532 minecraft:white_concrete
fill 217 190 519 218 191 519 minecraft:white_concrete
fill 217 190 520 217 191 521 minecraft:black_concrete
fill 217 190 523 218 190 525 minecraft:black_concrete
fill 217 190 531 218 191 531 minecraft:white_concrete
fill 218 190 520 219 192 520 minecraft:white_concrete
fill 218 190 521 218 191 521 minecraft:black_concrete
fill 218 190 528 218 191 529 minecraft:black_concrete
fill 218 190 530 219 192 530 minecraft:white_concrete
fill 219 190 521 219 192 524 minecraft:white_concrete
fill 219 190 525 219 191 525 minecraft:black_concrete
fill 219 190 526 219 192 529 minecraft:white_concrete
fill 220 190 522 220 192 528 minecraft:white_concrete
fill 189 191 511 198 191 551 minecraft:black_concrete
fill 199 191 511 199 191 524 minecraft:black_concrete
setblock 199 191 525 minecraft:white_concrete
fill 199 191 526 199 191 551 minecraft:black_concrete
fill 200 191 511 200 191 520 minecraft:black_concrete
setblock 200 191 521 minecraft:white_concrete
setblock 200 191 529 minecraft:white_concrete
fill 200 191 530 200 191 551 minecraft:black_concrete
fill 201 191 511 201 191 518 minecraft:black_concrete
setblock 201 191 519 minecraft:white_concrete
fill 201 191 525 202 191 525 minecraft:black_concrete
setblock 201 191 531 minecraft:white_concrete
fill 201 191 532 201 191 551 minecraft:black_concrete
fill 202 191 511 202 191 517 minecraft:black_concrete
fill 202 191 521 202 191 524 minecraft:black_concrete
fill 202 191 526 202 191 529 minecraft:black_concrete
fill 202 191 533 202 191 551 minecraft:black_concrete
fill 203 191 511 203 191 516 minecraft:black_concrete
fill 203 191 520 204 191 522 minecraft:black_concrete
fill 203 191 523 203 191 527 minecraft:pearlescent_froglight
fill 203 191 528 204 191 530 minecraft:black_concrete
fill 203 191 534 203 191 551 minecraft:black_concrete
fill 204 191 511 205 191 515 minecraft:black_concrete
setblock 204 191 516 minecraft:white_concrete
fill 204 191 519 206 191 519 minecraft:black_concrete
fill 204 191 523 208 191 527 minecraft:mossy_stone_bricks
fill 204 191 531 207 191 531 minecraft:black_concrete
setblock 204 191 534 minecraft:white_concrete
fill 204 191 535 205 191 551 minecraft:black_concrete
fill 205 191 518 206 191 518 minecraft:black_concrete
setblock 205 191 520 minecraft:black_concrete
fill 205 191 521 215 191 522 minecraft:mossy_stone_bricks
fill 205 191 528 215 191 529 minecraft:mossy_stone_bricks
setblock 205 191 530 minecraft:black_concrete
fill 206 191 511 209 191 514 minecraft:black_concrete
setblock 206 191 515 minecraft:white_concrete
fill 206 191 520 214 191 520 minecraft:mossy_stone_bricks
fill 206 191 530 214 191 530 minecraft:mossy_stone_bricks
setblock 206 191 535 minecraft:white_concrete
fill 206 191 536 209 191 551 minecraft:black_concrete
fill 207 191 518 207 191 519 minecraft:pearlescent_froglight
fill 208 191 518 211 191 518 minecraft:pearlescent_froglight
fill 208 191 519 212 191 519 minecraft:mossy_stone_bricks
fill 208 191 531 212 191 531 minecraft:mossy_stone_bricks
fill 209 191 523 216 191 523 minecraft:mossy_stone_bricks
fill 209 191 527 216 191 527 minecraft:mossy_stone_bricks
fill 210 191 511 229 191 513 minecraft:black_concrete
setblock 210 191 514 minecraft:white_concrete
setblock 210 191 536 minecraft:white_concrete
fill 210 191 537 229 191 551 minecraft:black_concrete
fill 211 191 514 229 191 514 minecraft:black_concrete
fill 211 191 536 229 191 536 minecraft:black_concrete
fill 212 191 518 215 191 518 minecraft:black_concrete
fill 212 191 524 216 191 526 minecraft:mossy_stone_bricks
fill 213 191 519 216 191 519 minecraft:black_concrete
fill 213 191 531 215 191 531 minecraft:pearlescent_froglight
setblock 214 191 515 minecraft:white_concrete
setblock 214 191 535 minecraft:white_concrete
fill 215 191 515 229 191 515 minecraft:black_concrete
fill 215 191 520 216 191 520 minecraft:black_concrete
setblock 215 191 530 minecraft:pearlescent_froglight
fill 215 191 535 229 191 535 minecraft:black_concrete
setblock 216 191 516 minecraft:white_concrete
setblock 216 191 521 minecraft:black_concrete
fill 216 191 522 217 191 522 minecraft:pearlescent_froglight
fill 216 191 528 216 191 531 minecraft:black_concrete
setblock 216 191 534 minecraft:white_concrete
fill 217 191 516 229 191 516 minecraft:black_concrete
fill 217 191 523 217 191 526 minecraft:pearlescent_froglight
fill 217 191 527 217 191 530 minecraft:black_concrete
fill 217 191 534 229 191 534 minecraft:black_concrete
fill 218 191 517 229 191 517 minecraft:black_concrete
fill 218 191 522 218 191 527 minecraft:black_concrete
fill 218 191 533 229 191 533 minecraft:black_concrete
fill 219 191 518 229 191 518 minecraft:black_concrete
setblock 219 191 519 minecraft:white_concrete
setblock 219 191 531 minecraft:white_concrete
fill 219 191 532 229 191 532 minecraft:black_concrete
fill 220 191 519 229 191 520 minecraft:black_concrete
setblock 220 191 521 minecraft:white_concrete
setblock 220 191 529 minecraft:white_concrete
fill 220 191 530 229 191 531 minecraft:black_concrete
fill 221 191 521 229 191 524 minecraft:black_concrete
setblock 221 191 525 minecraft:white_concrete
fill 221 191 526 229 191 529 minecraft:black_concrete
fill 222 191 525 229 191 525 minecraft:black_concrete
fill 201 192 525 201 193 525 minecraft:white_concrete
fill 202 192 521 202 192 522 minecraft:white_concrete
fill 202 192 523 203 201 527 minecraft:stone_bricks
fill 202 192 528 202 192 529 minecraft:white_concrete
fill 203 192 517 204 192 517 minecraft:white_concrete
fill 203 192 518 205 204 521 minecraft:cobblestone
fill 203 192 522 204 201 522 minecraft:stone_bricks
fill 203 192 528 204 202 528 minecraft:stone_bricks
fill 203 192 529 205 204 532 minecraft:cobblestone
fill 203 192 533 204 192 533 minecraft:white_concrete
fill 206 192 517 207 192 517 minecraft:white_concrete
fill 206 192 518 206 204 520 minecraft:cobblestone
fill 206 192 530 206 204 532 minecraft:cobblestone
fill 206 192 533 207 192 533 minecraft:white_concrete
fill 207 192 518 207 201 519 minecraft:stone_bricks
fill 207 192 531 207 201 532 minecraft:stone_bricks
fill 208 192 517 212 201 518 minecraft:stone_bricks
fill 208 192 532 212 201 533 minecraft:stone_bricks
fill 210 192 516 210 193 516 minecraft:white_concrete
fill 210 192 534 210 193 534 minecraft:white_concrete
fill 213 192 517 214 192 517 minecraft:white_concrete
fill 213 192 518 213 201 519 minecraft:stone_bricks
fill 213 192 531 213 202 532 minecraft:stone_bricks
fill 213 192 533 214 192 533 minecraft:white_concrete
fill 214 192 518 217 204 520 minecraft:cobblestone
fill 214 192 530 217 204 532 minecraft:cobblestone
fill 215 192 521 217 204 521 minecraft:cobblestone
fill 215 192 529 217 204 529 minecraft:cobblestone
fill 216 192 522 217 202 522 minecraft:stone_bricks
fill 216 192 528 217 201 528 minecraft:stone_bricks
fill 217 192 523 218 201 527 minecraft:stone_bricks
fill 218 192 518 218 192 519 minecraft:white_concrete
fill 218 192 521 218 192 522 minecraft:white_concrete
fill 218 192 528 218 192 529 minecraft:white_concrete
fill 218 192 531 218 192 532 minecraft:white_concrete
fill 219 192 525 219 193 525 minecraft:white_concrete
setblock 191 193 513 minecraft:light[level=10]
setblock 191 193 521 minecraft:light[level=10]
setblock 191 193 529 minecraft:light[level=10]
setblock 191 193 537 minecraft:light[level=10]
setblock 191 193 545 minecraft:light[level=10]
setblock 199 193 513 minecraft:light[level=10]
setblock 199 193 521 minecraft:light[level=10]
setblock 199 193 529 minecraft:light[level=10]
setblock 199 193 537 minecraft:light[level=10]
setblock 199 193 545 minecraft:light[level=10]
setblock 207 193 513 minecraft:light[level=10]
setblock 207 193 521 minecraft:light[level=10]
setblock 207 193 529 minecraft:light[level=10]
setblock 207 193 537 minecraft:light[level=10]
setblock 207 193 545 minecraft:light[level=10]
setblock 215 193 513 minecraft:light[level=10]
setblock 215 193 537 minecraft:light[level=10]
setblock 215 193 545 minecraft:light[level=10]
setblock 223 193 513 minecraft:light[level=10]
setblock 223 193 521 minecraft:light[level=10]
setblock 223 193 529 minecraft:light[level=10]
setblock 223 193 537 minecraft:light[level=10]
setblock 223 193 545 minecraft:light[level=10]
fill 189 195 514 189 195 526 minecraft:gray_concrete
fill 189 195 533 189 234 534 minecraft:gray_concrete
fill 189 195 541 189 234 542 minecraft:gray_concrete
fill 189 195 549 189 234 550 minecraft:gray_concrete
fill 190 195 511 191 234 511 minecraft:gray_concrete
fill 190 195 514 193 195 524 minecraft:gray_concrete
fill 195 195 551 196 234 551 minecraft:gray_concrete
fill 198 195 511 199 234 511 minecraft:gray_concrete
fill 203 195 551 204 234 551 minecraft:gray_concrete
fill 206 195 511 207 234 511 minecraft:gray_concrete
fill 211 195 551 212 234 551 minecraft:gray_concrete
fill 214 195 511 215 234 511 minecraft:gray_concrete
fill 219 195 551 220 234 551 minecraft:gray_concrete
fill 221 195 530 229 195 542 minecraft:gray_concrete
fill 222 195 511 223 234 511 minecraft:gray_concrete
fill 227 195 551 228 234 551 minecraft:gray_concrete
fill 229 195 512 229 234 513 minecraft:gray_concrete
fill 229 195 520 229 234 521 minecraft:gray_concrete
fill 229 195 528 229 234 529 minecraft:gray_concrete
fill 229 195 544 229 234 545 minecraft:gray_concrete
fill 189 196 511 189 197 514 minecraft:gray_concrete
setblock 189 196 515 minecraft:pearlescent_froglight
fill 189 196 516 189 217 516 minecraft:gray_concrete
setblock 189 196 517 minecraft:pearlescent_froglight
fill 189 196 518 189 234 518 minecraft:gray_concrete
setblock 189 196 519 minecraft:pearlescent_froglight
fill 189 196 520 189 217 520 minecraft:gray_concrete
setblock 189 196 521 minecraft:pearlescent_froglight
fill 189 196 522 189 217 522 minecraft:gray_concrete
setblock 189 196 523 minecraft:pearlescent_froglight
fill 189 196 524 189 197 532 minecraft:gray_concrete
fill 189 196 535 190 196 540 minecraft:gray_concrete
fill 189 196 543 190 196 548 minecraft:gray_concrete
fill 189 196 551 194 197 551 minecraft:gray_concrete
fill 190 196 512 190 196 513 minecraft:gray_concrete
setblock 190 196 514 minecraft:pearlescent_froglight
fill 190 196 515 190 217 515 minecraft:gray_concrete
setblock 190 196 516 minecraft:pearlescent_froglight
fill 190 196 517 190 217 517 minecraft:gray_concrete
setblock 190 196 518 minecraft:pearlescent_froglight
fill 190 196 519 190 217 519 minecraft:gray_concrete
setblock 190 196 520 minecraft:pearlescent_froglight
fill 190 196 521 190 217 521 minecraft:gray_concrete
setblock 190 196 522 minecraft:pearlescent_froglight
fill 190 196 523 190 217 523 minecraft:gray_concrete
setblock 190 196 524 minecraft:pearlescent_froglight
fill 190 196 525 190 196 534 minecraft:gray_concrete
fill 190 196 541 190 196 542 minecraft:gray_concrete
fill 190 196 549 190 196 550 minecraft:gray_concrete
fill 191 196 512 228 196 512 minecraft:gray_concrete
fill 191 196 514 191 217 514 minecraft:gray_concrete
setblock 191 196 515 minecraft:pearlescent_froglight
fill 191 196 516 191 217 516 minecraft:gray_concrete
setblock 191 196 517 minecraft:pearlescent_froglight
fill 191 196 518 191 217 518 minecraft:gray_concrete
setblock 191 196 519 minecraft:pearlescent_froglight
fill 191 196 520 191 217 520 minecraft:gray_concrete
setblock 191 196 521 minecraft:pearlescent_froglight
fill 191 196 522 191 217 522 minecraft:gray_concrete
setblock 191 196 523 minecraft:pearlescent_froglight
fill 191 196 524 191 217 524 minecraft:gray_concrete
fill 191 196 550 229 196 550 minecraft:gray_concrete
fill 192 196 511 197 197 511 minecraft:gray_concrete
setblock 192 196 514 minecraft:pearlescent_froglight
fill 192 196 515 192 217 515 minecraft:gray_concrete
setblock 192 196 516 minecraft:pearlescent_froglight
fill 192 196 517 192 217 517 minecraft:gray_concrete
setblock 192 196 518 minecraft:pearlescent_froglight
fill 192 196 519 192 217 519 minecraft:gray_concrete
setblock 192 196 520 minecraft:pearlescent_froglight
fill 192 196 521 192 217 521 minecraft:gray_concrete
setblock 192 196 522 minecraft:pearlescent_froglight
fill 192 196 523 192 217 523 minecraft:gray_concrete
setblock 192 196 524 minecraft:pearlescent_froglight
fill 193 196 514 193 217 514 minecraft:gray_concrete
setblock 193 196 515 minecraft:pearlescent_froglight
fill 193 196 516 193 217 516 minecraft:gray_concrete
setblock 193 196 517 minecraft:pearlescent_froglight
fill 193 196 518 193 217 518 minecraft:gray_concrete
setblock 193 196 519 minecraft:pearlescent_froglight
fill 193 196 520 193 217 520 minecraft:gray_concrete
setblock 193 196 521 minecraft:pearlescent_froglight
fill 193 196 522 193 217 522 minecraft:gray_concrete
setblock 193 196 523 minecraft:pearlescent_froglight
fill 193 196 524 193 217 524 minecraft:gray_concrete
fill 197 196 551 202 197 551 minecraft:gray_concrete
fill 200 196 511 205 197 511 minecraft:gray_concrete
fill 205 196 551 210 197 551 minecraft:gray_concrete
fill 208 196 511 213 197 511 minecraft:gray_concrete
fill 213 196 551 218 197 551 minecraft:gray_concrete
fill 216 196 511 221 197 511 minecraft:gray_concrete
fill 221 196 530 221 216 530 minecraft:gray_concrete
setblock 221 196 531 minecraft:pearlescent_froglight
fill 221 196 532 221 216 532 minecraft:gray_concrete
setblock 221 196 533 minecraft:pearlescent_froglight
fill 221 196 534 221 216 534 minecraft:gray_concrete
setblock 221 196 535 minecraft:pearlescent_froglight
fill 221 196 536 221 216 536 minecraft:gray_concrete
setblock 221 196 537 minecraft:pearlescent_froglight
fill 221 196 538 221 216 538 minecraft:gray_concrete
setblock 221 196 539 minecraft:pearlescent_froglight
fill 221 196 540 221 216 540 minecraft:gray_concrete
setblock 221 196 541 minecraft:pearlescent_froglight
fill 221 196 542 221 216 542 minecraft:gray_concrete
fill 221 196 551 226 197 551 minecraft:gray_concrete
setblock 222 196 530 minecraft:pearlescent_froglight
fill 222 196 531 222 216 531 minecraft:gray_concrete
setblock 222 196 532 minecraft:pearlescent_froglight
fill 222 196 533 222 216 533 minecraft:gray_concrete
setblock 222 196 534 minecraft:pearlescent_froglight
fill 222 196 535 222 216 535 minecraft:gray_concrete
setblock 222 196 536 minecraft:pearlescent_froglight
fill 222 196 537 222 216 537 minecraft:gray_concrete
setblock 222 196 538 minecraft:pearlescent_froglight
fill 222 196 539 222 216 539 minecraft:gray_concrete
setblock 222 196 540 minecraft:pearlescent_froglight
fill 222 196 541 222 216 541 minecraft:gray_concrete
setblock 222 196 542 minecraft:pearlescent_froglight
fill 223 196 530 223 216 530 minecraft:gray_concrete
setblock 223 196 531 minecraft:pearlescent_froglight
fill 223 196 532 223 216 532 minecraft:gray_concrete
setblock 223 196 533 minecraft:pearlescent_froglight
fill 223 196 534 223 216 534 minecraft:gray_concrete
setblock 223 196 535 minecraft:pearlescent_froglight
fill 223 196 536 223 216 536 minecraft:gray_concrete
setblock 223 196 537 minecraft:pearlescent_froglight
fill 223 196 538 223 216 538 minecraft:gray_concrete
setblock 223 196 539 minecraft:pearlescent_froglight
fill 223 196 540 223 216 540 minecraft:gray_concrete
setblock 223 196 541 minecraft:pearlescent_froglight
fill 223 196 542 223 216 542 minecraft:gray_concrete
fill 224 196 511 229 197 511 minecraft:gray_concrete
setblock 224 196 530 minecraft:pearlescent_froglight
fill 224 196 531 224 216 531 minecraft:gray_concrete
setblock 224 196 532 minecraft:pearlescent_froglight
fill 224 196 533 224 216 533 minecraft:gray_concrete
setblock 224 196 534 minecraft:pearlescent_froglight
fill 224 196 535 224 216 535 minecraft:gray_concrete
setblock 224 196 536 minecraft:pearlescent_froglight
fill 224 196 537 224 216 537 minecraft:gray_concrete
setblock 224 196 538 minecraft:pearlescent_froglight
fill 224 196 539 224 216 539 minecraft:gray_concrete
setblock 224 196 540 minecraft:pearlescent_froglight
fill 224 196 541 224 216 541 minecraft:gray_concrete
setblock 224 196 542 minecraft:pearlescent_froglight
fill 225 196 530 225 216 530 minecraft:gray_concrete
setblock 225 196 531 minecraft:pearlescent_froglight
fill 225 196 532 225 216 532 minecraft:gray_concrete
setblock 225 196 533 minecraft:pearlescent_froglight
fill 225 196 534 225 216 534 minecraft:gray_concrete
setblock 225 196 535 minecraft:pearlescent_froglight
fill 225 196 536 225 216 536 minecraft:gray_concrete
setblock 225 196 537 minecraft:pearlescent_froglight
fill 225 196 538 225 216 538 minecraft:gray_concrete
setblock 225 196 539 minecraft:pearlescent_froglight
fill 225 196 540 225 216 540 minecraft:gray_concrete
setblock 225 196 541 minecraft:pearlescent_froglight
fill 225 196 542 225 216 542 minecraft:gray_concrete
setblock 226 196 530 minecraft:pearlescent_froglight
fill 226 196 531 226 216 531 minecraft:gray_concrete
setblock 226 196 532 minecraft:pearlescent_froglight
fill 226 196 533 226 216 533 minecraft:gray_concrete
setblock 226 196 534 minecraft:pearlescent_froglight
fill 226 196 535 226 216 535 minecraft:gray_concrete
setblock 226 196 536 minecraft:pearlescent_froglight
fill 226 196 537 226 216 537 minecraft:gray_concrete
setblock 226 196 538 minecraft:pearlescent_froglight
fill 226 196 539 226 216 539 minecraft:gray_concrete
setblock 226 196 540 minecraft:pearlescent_froglight
fill 226 196 541 226 216 541 minecraft:gray_concrete
setblock 226 196 542 minecraft:pearlescent_froglight
fill 227 196 530 227 216 530 minecraft:gray_concrete
setblock 227 196 531 minecraft:pearlescent_froglight
fill 227 196 532 227 216 532 minecraft:gray_concrete
setblock 227 196 533 minecraft:pearlescent_froglight
fill 227 196 534 227 216 534 minecraft:gray_concrete
setblock 227 196 535 minecraft:pearlescent_froglight
fill 227 196 536 227 216 536 minecraft:gray_concrete
setblock 227 196 537 minecraft:pearlescent_froglight
fill 227 196 538 227 216 538 minecraft:gray_concrete
setblock 227 196 539 minecraft:pearlescent_froglight
fill 227 196 540 227 216 540 minecraft:gray_concrete
setblock 227 196 541 minecraft:pearlescent_froglight
fill 227 196 542 227 216 542 minecraft:gray_concrete
fill 228 196 513 228 196 529 minecraft:gray_concrete
setblock 228 196 530 minecraft:pearlescent_froglight
fill 228 196 531 228 216 531 minecraft:gray_concrete
setblock 228 196 532 minecraft:pearlescent_froglight
fill 228 196 533 228 216 533 minecraft:gray_concrete
setblock 228 196 534 minecraft:pearlescent_froglight
fill 228 196 535 228 216 535 minecraft:gray_concrete
setblock 228 196 536 minecraft:pearlescent_froglight
fill 228 196 537 228 216 537 minecraft:gray_concrete
setblock 228 196 538 minecraft:pearlescent_froglight
fill 228 196 539 228 216 539 minecraft:gray_concrete
setblock 228 196 540 minecraft:pearlescent_froglight
fill 228 196 541 228 216 541 minecraft:gray_concrete
setblock 228 196 542 minecraft:pearlescent_froglight
fill 228 196 543 228 196 549 minecraft:gray_concrete
fill 229 196 514 229 197 519 minecraft:gray_concrete
fill 229 196 522 229 197 527 minecraft:gray_concrete
fill 229 196 530 229 216 530 minecraft:gray_concrete
setblock 229 196 531 minecraft:pearlescent_froglight
fill 229 196 532 229 216 532 minecraft:gray_concrete
setblock 229 196 533 minecraft:pearlescent_froglight
fill 229 196 534 229 216 534 minecraft:gray_concrete
setblock 229 196 535 minecraft:pearlescent_froglight
fill 229 196 536 229 234 536 minecraft:gray_concrete
setblock 229 196 537 minecraft:pearlescent_froglight
fill 229 196 538 229 216 538 minecraft:gray_concrete
setblock 229 196 539 minecraft:pearlescent_froglight
fill 229 196 540 229 216 540 minecraft:gray_concrete
setblock 229 196 541 minecraft:pearlescent_froglight
fill 229 196 542 229 197 543 minecraft:gray_concrete
fill 229 196 546 229 197 549 minecraft:gray_concrete
fill 229 196 551 229 197 551 minecraft:gray_concrete
fill 189 197 515 189 198 515 minecraft:gray_concrete
fill 189 197 517 189 198 517 minecraft:gray_concrete
fill 189 197 519 189 198 519 minecraft:gray_concrete
fill 189 197 521 189 198 521 minecraft:gray_concrete
fill 189 197 523 189 198 523 minecraft:gray_concrete
fill 189 197 535 189 197 540 minecraft:gray_concrete
fill 189 197 543 189 197 548 minecraft:gray_concrete
fill 190 197 514 190 198 514 minecraft:gray_concrete
fill 190 197 516 190 198 516 minecraft:gray_concrete
fill 190 197 518 190 198 518 minecraft:gray_concrete
fill 190 197 520 190 198 520 minecraft:gray_concrete
fill 190 197 522 190 198 522 minecraft:gray_concrete
fill 190 197 524 190 198 524 minecraft:gray_concrete
fill 191 197 515 191 198 515 minecraft:gray_concrete
fill 191 197 517 191 198 517 minecraft:gray_concrete
fill 191 197 519 191 198 519 minecraft:gray_concrete
fill 191 197 521 191 198 521 minecraft:gray_concrete
fill 191 197 523 191 198 523 minecraft:gray_concrete
fill 192 197 514 192 198 514 minecraft:gray_concrete
fill 192 197 516 192 198 516 minecraft:gray_concrete
fill 192 197 518 192 198 518 minecraft:gray_concrete
fill 192 197 520 192 198 520 minecraft:gray_concrete
fill 192 197 522 192 198 522 minecraft:gray_concrete
fill 192 197 524 192 198 524 minecraft:gray_concrete
fill 193 197 515 193 198 515 minecraft:gray_concrete
fill 193 197 517 193 198 517 minecraft:gray_concrete
fill 193 197 519 193 198 519 minecraft:gray_concrete
fill 193 197 521 193 198 521 minecraft:gray_concrete
fill 193 197 523 193 198 523 minecraft:gray_concrete
fill 221 197 531 221 198 531 minecraft:gray_concrete
fill 221 197 533 221 198 533 minecraft:gray_concrete
fill 221 197 535 221 198 535 minecraft:gray_concrete
fill 221 197 537 221 198 537 minecraft:gray_concrete
fill 221 197 539 221 198 539 minecraft:gray_concrete
fill 221 197 541 221 198 541 minecraft:gray_concrete
fill 222 197 530 222 198 530 minecraft:gray_concrete
fill 222 197 532 222 198 532 minecraft:gray_concrete
fill 222 197 534 222 198 534 minecraft:gray_concrete
fill 222 197 536 222 198 536 minecraft:gray_concrete
fill 222 197 538 222 198 538 minecraft:gray_concrete
fill 222 197 540 222 198 540 minecraft:gray_concrete
fill 222 197 542 222 198 542 minecraft:gray_concrete
fill 223 197 531 223 198 531 minecraft:gray_concrete
fill 223 197 533 223 198 533 minecraft:gray_concrete
fill 223 197 535 223 198 535 minecraft:gray_concrete
fill 223 197 537 223 198 537 minecraft:gray_concrete
fill 223 197 539 223 198 539 minecraft:gray_concrete
fill 223 197 541 223 198 541 minecraft:gray_concrete
fill 224 197 530 224 198 530 minecraft:gray_concrete
fill 224 197 532 224 198 532 minecraft:gray_concrete
fill 224 197 534 224 198 534 minecraft:gray_concrete
fill 224 197 536 224 198 536 minecraft:gray_concrete
fill 224 197 538 224 198 538 minecraft:gray_concrete
fill 224 197 540 224 198 540 minecraft:gray_concrete
fill 224 197 542 224 198 542 minecraft:gray_concrete
fill 225 197 531 225 198 531 minecraft:gray_concrete
fill 225 197 533 225 198 533 minecraft:gray_concrete
fill 225 197 535 225 198 535 minecraft:gray_concrete
fill 225 197 537 225 198 537 minecraft:gray_concrete
fill 225 197 539 225 198 539 minecraft:gray_concrete
fill 225 197 541 225 198 541 minecraft:gray_concrete
fill 226 197 530 226 198 530 minecraft:gray_concrete
fill 226 197 532 226 198 532 minecraft:gray_concrete
fill 226 197 534 226 198 534 minecraft:gray_concrete
fill 226 197 536 226 198 536 minecraft:gray_concrete
fill 226 197 538 226 198 538 minecraft:gray_concrete
fill 226 197 540 226 198 540 minecraft:gray_concrete
fill 226 197 542 226 198 542 minecraft:gray_concrete
fill 227 197 531 227 198 531 minecraft:gray_concrete
fill 227 197 533 227 198 533 minecraft:gray_concrete
fill 227 197 535 227 198 535 minecraft:gray_concrete
fill 227 197 537 227 198 537 minecraft:gray_concrete
fill 227 197 539 227 198 539 minecraft:gray_concrete
fill 227 197 541 227 198 541 minecraft:gray_concrete
fill 228 197 530 228 198 530 minecraft:gray_concrete
fill 228 197 532 228 198 532 minecraft:gray_concrete
fill 228 197 534 228 198 534 minecraft:gray_concrete
fill 228 197 536 228 198 536 minecraft:gray_concrete
fill 228 197 538 228 198 538 minecraft:gray_concrete
fill 228 197 540 228 198 540 minecraft:gray_concrete
fill 228 197 542 228 198 542 minecraft:gray_concrete
fill 229 197 531 229 198 531 minecraft:gray_concrete
fill 229 197 533 229 198 533 minecraft:gray_concrete
fill 229 197 535 229 198 535 minecraft:gray_concrete
fill 229 197 537 229 198 537 minecraft:gray_concrete
fill 229 197 539 229 198 539 minecraft:gray_concrete
fill 229 197 541 229 198 541 minecraft:gray_concrete
setblock 229 197 550 minecraft:gray_concrete
fill 189 198 514 189 217 514 minecraft:gray_concrete
fill 189 198 524 189 217 526 minecraft:gray_concrete
fill 229 198 542 229 216 542 minecraft:gray_concrete
setblock 189 199 515 minecraft:pearlescent_froglight
setblock 189 199 517 minecraft:pearlescent_froglight
setblock 189 199 519 minecraft:pearlescent_froglight
setblock 189 199 521 minecraft:pearlescent_froglight
setblock 189 199 523 minecraft:pearlescent_froglight
setblock 190 199 514 minecraft:pearlescent_froglight
setblock 190 199 516 minecraft:pearlescent_froglight
setblock 190 199 518 minecraft:pearlescent_froglight
setblock 190 199 520 minecraft:pearlescent_froglight
setblock 190 199 522 minecraft:pearlescent_froglight
setblock 190 199 524 minecraft:pearlescent_froglight
setblock 191 199 515 minecraft:pearlescent_froglight
setblock 191 199 517 minecraft:pearlescent_froglight
setblock 191 199 519 minecraft:pearlescent_froglight
setblock 191 199 521 minecraft:pearlescent_froglight
setblock 191 199 523 minecraft:pearlescent_froglight
setblock 192 199 514 minecraft:pearlescent_froglight
setblock 192 199 516 minecraft:pearlescent_froglight
setblock 192 199 518 minecraft:pearlescent_froglight
setblock 192 199 520 minecraft:pearlescent_froglight
setblock 192 199 522 minecraft:pearlescent_froglight
setblock 192 199 524 minecraft:pearlescent_froglight
setblock 193 199 515 minecraft:pearlescent_froglight
setblock 193 199 517 minecraft:pearlescent_froglight
setblock 193 199 519 minecraft:pearlescent_froglight
setblock 193 199 521 minecraft:pearlescent_froglight
setblock 193 199 523 minecraft:pearlescent_froglight
setblock 221 199 531 minecraft:pearlescent_froglight
setblock 221 199 533 minecraft:pearlescent_froglight
setblock 221 199 535 minecraft:pearlescent_froglight
setblock 221 199 537 minecraft:pearlescent_froglight
setblock 221 199 539 minecraft:pearlescent_froglight
setblock 221 199 541 minecraft:pearlescent_froglight
setblock 222 199 530 minecraft:pearlescent_froglight
setblock 222 199 532 minecraft:pearlescent_froglight
setblock 222 199 534 minecraft:pearlescent_froglight
setblock 222 199 536 minecraft:pearlescent_froglight
setblock 222 199 538 minecraft:pearlescent_froglight
setblock 222 199 540 minecraft:pearlescent_froglight
setblock 222 199 542 minecraft:pearlescent_froglight
setblock 223 199 531 minecraft:pearlescent_froglight
setblock 223 199 533 minecraft:pearlescent_froglight
setblock 223 199 535 minecraft:pearlescent_froglight
setblock 223 199 537 minecraft:pearlescent_froglight
setblock 223 199 539 minecraft:pearlescent_froglight
setblock 223 199 541 minecraft:pearlescent_froglight
fill 223 199 548 223 200 550 minecraft:gray_concrete
setblock 224 199 530 minecraft:pearlescent_froglight
setblock 224 199 532 minecraft:pearlescent_froglight
setblock 224 199 534 minecraft:pearlescent_froglight
setblock 224 199 536 minecraft:pearlescent_froglight
setblock 224 199 538 minecraft:pearlescent_froglight
setblock 224 199 540 minecraft:pearlescent_froglight
setblock 224 199 542 minecraft:pearlescent_froglight
setblock 225 199 531 minecraft:pearlescent_froglight
setblock 225 199 533 minecraft:pearlescent_froglight
setblock 225 199 535 minecraft:pearlescent_froglight
setblock 225 199 537 minecraft:pearlescent_froglight
setblock 225 199 539 minecraft:pearlescent_froglight
setblock 225 199 541 minecraft:pearlescent_froglight
setblock 226 199 530 minecraft:pearlescent_froglight
setblock 226 199 532 minecraft:pearlescent_froglight
setblock 226 199 534 minecraft:pearlescent_froglight
setblock 226 199 536 minecraft:pearlescent_froglight
setblock 226 199 538 minecraft:pearlescent_froglight
setblock 226 199 540 minecraft:pearlescent_froglight
setblock 226 199 542 minecraft:pearlescent_froglight
setblock 227 199 531 minecraft:pearlescent_froglight
setblock 227 199 533 minecraft:pearlescent_froglight
setblock 227 199 535 minecraft:pearlescent_froglight
setblock 227 199 537 minecraft:pearlescent_froglight
setblock 227 199 539 minecraft:pearlescent_froglight
setblock 227 199 541 minecraft:pearlescent_froglight
setblock 228 199 530 minecraft:pearlescent_froglight
setblock 228 199 532 minecraft:pearlescent_froglight
setblock 228 199 534 minecraft:pearlescent_froglight
setblock 228 199 536 minecraft:pearlescent_froglight
setblock 228 199 538 minecraft:pearlescent_froglight
setblock 228 199 540 minecraft:pearlescent_froglight
setblock 228 199 542 minecraft:pearlescent_froglight
setblock 229 199 531 minecraft:pearlescent_froglight
setblock 229 199 533 minecraft:pearlescent_froglight
setblock 229 199 535 minecraft:pearlescent_froglight
setblock 229 199 537 minecraft:pearlescent_froglight
setblock 229 199 539 minecraft:pearlescent_froglight
setblock 229 199 541 minecraft:pearlescent_froglight
fill 188 200 515 188 205 515 minecraft:pearlescent_froglight
fill 188 200 523 188 205 523 minecraft:pearlescent_froglight
fill 188 200 531 188 205 531 minecraft:pearlescent_froglight
fill 188 200 539 188 205 539 minecraft:pearlescent_froglight
fill 188 200 547 188 205 547 minecraft:pearlescent_froglight
fill 189 200 515 189 201 515 minecraft:gray_concrete
fill 189 200 517 189 201 517 minecraft:gray_concrete
fill 189 200 519 189 201 519 minecraft:gray_concrete
fill 189 200 521 189 201 521 minecraft:gray_concrete
fill 189 200 523 189 201 523 minecraft:gray_concrete
fill 190 200 514 190 201 514 minecraft:gray_concrete
fill 190 200 516 190 201 516 minecraft:gray_concrete
fill 190 200 518 190 201 518 minecraft:gray_concrete
fill 190 200 520 190 201 520 minecraft:gray_concrete
fill 190 200 522 190 201 522 minecraft:gray_concrete
fill 190 200 524 190 201 524 minecraft:gray_concrete
fill 191 200 515 191 201 515 minecraft:gray_concrete
fill 191 200 517 191 201 517 minecraft:gray_concrete
fill 191 200 519 191 201 519 minecraft:gray_concrete
fill 191 200 521 191 201 521 minecraft:gray_concrete
fill 191 200 523 191 201 523 minecraft:gray_concrete
fill 191 200 552 191 205 552 minecraft:pearlescent_froglight
fill 192 200 514 192 201 514 minecraft:gray_concrete
fill 192 200 516 192 201 516 minecraft:gray_concrete
fill 192 200 518 192 201 518 minecraft:gray_concrete
fill 192 200 520 192 201 520 minecraft:gray_concrete
fill 192 200 522 192 201 522 minecraft:gray_concrete
fill 192 200 524 192 201 524 minecraft:gray_concrete
fill 193 200 515 193 201 515 minecraft:gray_concrete
fill 193 200 517 193 201 517 minecraft:gray_concrete
fill 193 200 519 193 201 519 minecraft:gray_concrete
fill 193 200 521 193 201 521 minecraft:gray_concrete
fill 193 200 523 193 201 523 minecraft:gray_concrete
fill 195 200 510 195 205 510 minecraft:pearlescent_froglight
fill 199 200 552 199 205 552 minecraft:pearlescent_froglight
fill 203 200 510 203 205 510 minecraft:pearlescent_froglight
fill 207 200 552 207 205 552 minecraft:pearlescent_froglight
fill 211 200 510 211 205 510 minecraft:pearlescent_froglight
fill 215 200 552 215 205 552 minecraft:pearlescent_froglight
fill 219 200 510 219 205 510 minecraft:pearlescent_froglight
fill 221 200 531 221 201 531 minecraft:gray_concrete
fill 221 200 533 221 201 533 minecraft:gray_concrete
fill 221 200 535 221 201 535 minecraft:gray_concrete
fill 221 200 537 221 201 537 minecraft:gray_concrete
fill 221 200 539 221 201 539 minecraft:gray_concrete
fill 221 200 541 221 201 541 minecraft:gray_concrete
fill 222 200 530 222 201 530 minecraft:gray_concrete
fill 222 200 532 222 201 532 minecraft:gray_concrete
fill 222 200 534 222 201 534 minecraft:gray_concrete
fill 222 200 536 222 201 536 minecraft:gray_concrete
fill 222 200 538 222 201 538 minecraft:gray_concrete
fill 222 200 540 222 201 540 minecraft:gray_concrete
fill 222 200 542 222 201 542 minecraft:gray_concrete
fill 223 200 531 223 201 531 minecraft:gray_concrete
fill 223 200 533 223 201 533 minecraft:gray_concrete
fill 223 200 535 223 201 535 minecraft:gray_concrete
fill 223 200 537 223 201 537 minecraft:gray_concrete
fill 223 200 539 223 201 539 minecraft:gray_concrete
fill 223 200 541 223 201 541 minecraft:gray_concrete
fill 223 200 552 223 205 552 minecraft:pearlescent_froglight
fill 224 200 530 224 201 530 minecraft:gray_concrete
fill 224 200 532 224 201 532 minecraft:gray_concrete
fill 224 200 534 224 201 534 minecraft:gray_concrete
fill 224 200 536 224 201 536 minecraft:gray_concrete
fill 224 200 538 224 201 538 minecraft:gray_concrete
fill 224 200 540 224 201 540 minecraft:gray_concrete
fill 224 200 542 224 201 542 minecraft:gray_concrete
fill 225 200 531 225 201 531 minecraft:gray_concrete
fill 225 200 533 225 201 533 minecraft:gray_concrete
fill 225 200 535 225 201 535 minecraft:gray_concrete
fill 225 200 537 225 201 537 minecraft:gray_concrete
fill 225 200 539 225 201 539 minecraft:gray_concrete
fill 225 200 541 225 201 541 minecraft:gray_concrete
fill 226 200 530 226 201 530 minecraft:gray_concrete
fill 226 200 532 226 201 532 minecraft:gray_concrete
fill 226 200 534 226 201 534 minecraft:gray_concrete
fill 226 200 536 226 201 536 minecraft:gray_concrete
fill 226 200 538 226 201 538 minecraft:gray_concrete
fill 226 200 540 226 201 540 minecraft:gray_concrete
fill 226 200 542 226 201 542 minecraft:gray_concrete
fill 227 200 510 227 205 510 minecraft:pearlescent_froglight
fill 227 200 531 227 201 531 minecraft:gray_concrete
fill 227 200 533 227 201 533 minecraft:gray_concrete
fill 227 200 535 227 201 535 minecraft:gray_concrete
fill 227 200 537 227 201 537 minecraft:gray_concrete
fill 227 200 539 227 201 539 minecraft:gray_concrete
fill 227 200 541 227 201 541 minecraft:gray_concrete
fill 228 200 530 228 201 530 minecraft:gray_concrete
fill 228 200 532 228 201 532 minecraft:gray_concrete
fill 228 200 534 228 201 534 minecraft:gray_concrete
fill 228 200 536 228 201 536 minecraft:gray_concrete
fill 228 200 538 228 201 538 minecraft:gray_concrete
fill 228 200 540 228 201 540 minecraft:gray_concrete
fill 228 200 542 228 201 542 minecraft:gray_concrete
fill 229 200 531 229 201 531 minecraft:gray_concrete
fill 229 200 533 229 201 533 minecraft:gray_concrete
fill 229 200 535 229 201 535 minecraft:gray_concrete
fill 229 200 537 229 201 537 minecraft:gray_concrete
fill 229 200 539 229 201 539 minecraft:gray_concrete
fill 229 200 541 229 201 541 minecraft:gray_concrete
fill 230 200 515 230 205 515 minecraft:pearlescent_froglight
fill 230 200 523 230 205 523 minecraft:pearlescent_froglight
fill 230 200 531 230 205 531 minecraft:pearlescent_froglight
fill 230 200 539 230 205 539 minecraft:pearlescent_froglight
fill 230 200 547 230 205 547 minecraft:pearlescent_froglight
setblock 191 201 513 minecraft:light[level=10]
setblock 191 201 529 minecraft:light[level=10]
setblock 191 201 537 minecraft:light[level=10]
setblock 191 201 545 minecraft:light[level=10]
setblock 199 201 513 minecraft:light[level=10]
setblock 199 201 521 minecraft:light[level=10]
setblock 199 201 529 minecraft:light[level=10]
setblock 199 201 537 minecraft:light[level=10]
setblock 199 201 545 minecraft:light[level=10]
setblock 207 201 513 minecraft:light[level=10]
setblock 207 201 521 minecraft:light[level=10]
setblock 207 201 529 minecraft:light[level=10]
setblock 207 201 537 minecraft:light[level=10]
setblock 207 201 545 minecraft:light[level=10]
setblock 215 201 513 minecraft:light[level=10]
setblock 215 201 537 minecraft:light[level=10]
setblock 215 201 545 minecraft:light[level=10]
setblock 223 201 513 minecraft:light[level=10]
setblock 223 201 521 minecraft:light[level=10]
setblock 223 201 529 minecraft:light[level=10]
setblock 223 201 545 minecraft:light[level=10]
setblock 189 202 515 minecraft:pearlescent_froglight
setblock 189 202 517 minecraft:pearlescent_froglight
setblock 189 202 519 minecraft:pearlescent_froglight
setblock 189 202 521 minecraft:pearlescent_froglight
setblock 189 202 523 minecraft:pearlescent_froglight
setblock 190 202 514 minecraft:pearlescent_froglight
setblock 190 202 516 minecraft:pearlescent_froglight
setblock 190 202 518 minecraft:pearlescent_froglight
setblock 190 202 520 minecraft:pearlescent_froglight
setblock 190 202 522 minecraft:pearlescent_froglight
setblock 190 202 524 minecraft:pearlescent_froglight
setblock 191 202 515 minecraft:pearlescent_froglight
setblock 191 202 517 minecraft:pearlescent_froglight
setblock 191 202 519 minecraft:pearlescent_froglight
setblock 191 202 521 minecraft:pearlescent_froglight
setblock 191 202 523 minecraft:pearlescent_froglight
setblock 192 202 514 minecraft:pearlescent_froglight
setblock 192 202 516 minecraft:pearlescent_froglight
setblock 192 202 518 minecraft:pearlescent_froglight
setblock 192 202 520 minecraft:pearlescent_froglight
setblock 192 202 522 minecraft:pearlescent_froglight
setblock 192 202 524 minecraft:pearlescent_froglight
setblock 193 202 515 minecraft:pearlescent_froglight
setblock 193 202 517 minecraft:pearlescent_froglight
setblock 193 202 519 minecraft:pearlescent_froglight
setblock 193 202 521 minecraft:pearlescent_froglight
setblock 193 202 523 minecraft:pearlescent_froglight
fill 202 202 523 203 202 523 minecraft:stone_bricks
fill 202 202 525 202 202 526 minecraft:stone_bricks
fill 203 202 524 203 202 525 minecraft:stone_bricks
fill 207 202 518 208 202 518 minecraft:stone_bricks
setblock 207 202 531 minecraft:stone_bricks
setblock 208 202 517 minecraft:stone_bricks
fill 209 202 532 210 202 533 minecraft:stone_bricks
fill 211 202 517 212 202 518 minecraft:stone_bricks
setblock 217 202 523 minecraft:stone_bricks
fill 217 202 525 218 202 526 minecraft:stone_bricks
setblock 218 202 527 minecraft:stone_bricks
setblock 221 202 531 minecraft:pearlescent_froglight
setblock 221 202 533 minecraft:pearlescent_froglight
setblock 221 202 535 minecraft:pearlescent_froglight
setblock 221 202 537 minecraft:pearlescent_froglight
setblock 221 202 539 minecraft:pearlescent_froglight
setblock 221 202 541 minecraft:pearlescent_froglight
setblock 222 202 530 minecraft:pearlescent_froglight
setblock 222 202 532 minecraft:pearlescent_froglight
setblock 222 202 534 minecraft:pearlescent_froglight
setblock 222 202 536 minecraft:pearlescent_froglight
setblock 222 202 538 minecraft:pearlescent_froglight
setblock 222 202 540 minecraft:pearlescent_froglight
setblock 222 202 542 minecraft:pearlescent_froglight
setblock 223 202 531 minecraft:pearlescent_froglight
setblock 223 202 533 minecraft:pearlescent_froglight
setblock 223 202 535 minecraft:pearlescent_froglight
setblock 223 202 537 minecraft:pearlescent_froglight
setblock 223 202 539 minecraft:pearlescent_froglight
setblock 223 202 541 minecraft:pearlescent_froglight
setblock 224 202 530 minecraft:pearlescent_froglight
setblock 224 202 532 minecraft:pearlescent_froglight
setblock 224 202 534 minecraft:pearlescent_froglight
setblock 224 202 536 minecraft:pearlescent_froglight
setblock 224 202 538 minecraft:pearlescent_froglight
setblock 224 202 540 minecraft:pearlescent_froglight
setblock 224 202 542 minecraft:pearlescent_froglight
setblock 225 202 531 minecraft:pearlescent_froglight
setblock 225 202 533 minecraft:pearlescent_froglight
setblock 225 202 535 minecraft:pearlescent_froglight
setblock 225 202 537 minecraft:pearlescent_froglight
setblock 225 202 539 minecraft:pearlescent_froglight
setblock 225 202 541 minecraft:pearlescent_froglight
setblock 226 202 530 minecraft:pearlescent_froglight
setblock 226 202 532 minecraft:pearlescent_froglight
setblock 226 202 534 minecraft:pearlescent_froglight
setblock 226 202 536 minecraft:pearlescent_froglight
setblock 226 202 538 minecraft:pearlescent_froglight
setblock 226 202 540 minecraft:pearlescent_froglight
setblock 226 202 542 minecraft:pearlescent_froglight
setblock 227 202 531 minecraft:pearlescent_froglight
setblock 227 202 533 minecraft:pearlescent_froglight
setblock 227 202 535 minecraft:pearlescent_froglight
setblock 227 202 537 minecraft:pearlescent_froglight
setblock 227 202 539 minecraft:pearlescent_froglight
setblock 227 202 541 minecraft:pearlescent_froglight
setblock 228 202 530 minecraft:pearlescent_froglight
setblock 228 202 532 minecraft:pearlescent_froglight
setblock 228 202 534 minecraft:pearlescent_froglight
setblock 228 202 536 minecraft:pearlescent_froglight
setblock 228 202 538 minecraft:pearlescent_froglight
setblock 228 202 540 minecraft:pearlescent_froglight
setblock 228 202 542 minecraft:pearlescent_froglight
setblock 229 202 531 minecraft:pearlescent_froglight
setblock 229 202 533 minecraft:pearlescent_froglight
setblock 229 202 535 minecraft:pearlescent_froglight
setblock 229 202 537 minecraft:pearlescent_froglight
setblock 229 202 539 minecraft:pearlescent_froglight
setblock 229 202 541 minecraft:pearlescent_froglight
fill 189 203 515 189 204 515 minecraft:gray_concrete
fill 189 203 517 189 204 517 minecraft:gray_concrete
fill 189 203 519 189 204 519 minecraft:gray_concrete
fill 189 203 521 189 204 521 minecraft:gray_concrete
fill 189 203 523 189 204 523 minecraft:gray_concrete
fill 190 203 514 190 204 514 minecraft:gray_concrete
fill 190 203 516 190 204 516 minecraft:gray_concrete
fill 190 203 518 190 204 518 minecraft:gray_concrete
fill 190 203 520 190 204 520 minecraft:gray_concrete
fill 190 203 522 190 204 522 minecraft:gray_concrete
fill 190 203 524 190 204 524 minecraft:gray_concrete
fill 191 203 515 191 204 515 minecraft:gray_concrete
fill 191 203 517 191 204 517 minecraft:gray_concrete
fill 191 203 519 191 204 519 minecraft:gray_concrete
fill 191 203 521 191 204 521 minecraft:gray_concrete
fill 191 203 523 191 204 523 minecraft:gray_concrete
fill 192 203 514 192 204 514 minecraft:gray_concrete
fill 192 203 516 192 204 516 minecraft:gray_concrete
fill 192 203 518 192 204 518 minecraft:gray_concrete
fill 192 203 520 192 204 520 minecraft:gray_concrete
fill 192 203 522 192 204 522 minecraft:gray_concrete
fill 192 203 524 192 204 524 minecraft:gray_concrete
fill 193 203 515 193 204 515 minecraft:gray_concrete
fill 193 203 517 193 204 517 minecraft:gray_concrete
fill 193 203 519 193 204 519 minecraft:gray_concrete
fill 193 203 521 193 204 521 minecraft:gray_concrete
fill 193 203 523 193 204 523 minecraft:gray_concrete
fill 221 203 531 221 204 531 minecraft:gray_concrete
fill 221 203 533 221 204 533 minecraft:gray_concrete
fill 221 203 535 221 204 535 minecraft:gray_concrete
fill 221 203 537 221 204 537 minecraft:gray_concrete
fill 221 203 539 221 204 539 minecraft:gray_concrete
fill 221 203 541 221 204 541 minecraft:gray_concrete
fill 222 203 530 222 204 530 minecraft:gray_concrete
fill 222 203 532 222 204 532 minecraft:gray_concrete
fill 222 203 534 222 204 534 minecraft:gray_concrete
fill 222 203 536 222 204 536 minecraft:gray_concrete
fill 222 203 538 222 204 538 minecraft:gray_concrete
fill 222 203 540 222 204 540 minecraft:gray_concrete
fill 222 203 542 222 204 542 minecraft:gray_concrete
fill 223 203 531 223 204 531 minecraft:gray_concrete
fill 223 203 533 223 204 533 minecraft:gray_concrete
fill 223 203 535 223 204 535 minecraft:gray_concrete
fill 223 203 537 223 204 537 minecraft:gray_concrete
fill 223 203 539 223 204 539 minecraft:gray_concrete
fill 223 203 541 223 204 541 minecraft:gray_concrete
fill 224 203 530 224 204 530 minecraft:gray_concrete
fill 224 203 532 224 204 532 minecraft:gray_concrete
fill 224 203 534 224 204 534 minecraft:gray_concrete
fill 224 203 536 224 204 536 minecraft:gray_concrete
fill 224 203 538 224 204 538 minecraft:gray_concrete
fill 224 203 540 224 204 540 minecraft:gray_concrete
fill 224 203 542 224 204 542 minecraft:gray_concrete
fill 225 203 531 225 204 531 minecraft:gray_concrete
fill 225 203 533 225 204 533 minecraft:gray_concrete
fill 225 203 535 225 204 535 minecraft:gray_concrete
fill 225 203 537 225 204 537 minecraft:gray_concrete
fill 225 203 539 225 204 539 minecraft:gray_concrete
fill 225 203 541 225 204 541 minecraft:gray_concrete
fill 226 203 530 226 204 530 minecraft:gray_concrete
fill 226 203 532 226 204 532 minecraft:gray_concrete
fill 226 203 534 226 204 534 minecraft:gray_concrete
fill 226 203 536 226 204 536 minecraft:gray_concrete
fill 226 203 538 226 204 538 minecraft:gray_concrete
fill 226 203 540 226 204 540 minecraft:gray_concrete
fill 226 203 542 226 204 542 minecraft:gray_concrete
fill 227 203 531 227 204 531 minecraft:gray_concrete
fill 227 203 533 227 204 533 minecraft:gray_concrete
fill 227 203 535 227 204 535 minecraft:gray_concrete
fill 227 203 537 227 204 537 minecraft:gray_concrete
fill 227 203 539 227 204 539 minecraft:gray_concrete
fill 227 203 541 227 204 541 minecraft:gray_concrete
fill 228 203 530 228 204 530 minecraft:gray_concrete
fill 228 203 532 228 204 532 minecraft:gray_concrete
fill 228 203 534 228 204 534 minecraft:gray_concrete
fill 228 203 536 228 204 536 minecraft:gray_concrete
fill 228 203 538 228 204 538 minecraft:gray_concrete
fill 228 203 540 228 204 540 minecraft:gray_concrete
fill 228 203 542 228 204 542 minecraft:gray_concrete
fill 229 203 531 229 204 531 minecraft:gray_concrete
fill 229 203 533 229 204 533 minecraft:gray_concrete
fill 229 203 535 229 204 535 minecraft:gray_concrete
fill 229 203 537 229 204 537 minecraft:gray_concrete
fill 229 203 539 229 204 539 minecraft:gray_concrete
fill 229 203 541 229 204 541 minecraft:gray_concrete
setblock 189 205 515 minecraft:pearlescent_froglight
setblock 189 205 517 minecraft:pearlescent_froglight
setblock 189 205 519 minecraft:pearlescent_froglight
setblock 189 205 521 minecraft:pearlescent_froglight
setblock 189 205 523 minecraft:pearlescent_froglight
setblock 190 205 514 minecraft:pearlescent_froglight
setblock 190 205 516 minecraft:pearlescent_froglight
setblock 190 205 518 minecraft:pearlescent_froglight
setblock 190 205 520 minecraft:pearlescent_froglight
setblock 190 205 522 minecraft:pearlescent_froglight
setblock 190 205 524 minecraft:pearlescent_froglight
setblock 191 205 515 minecraft:pearlescent_froglight
setblock 191 205 517 minecraft:pearlescent_froglight
setblock 191 205 519 minecraft:pearlescent_froglight
setblock 191 205 521 minecraft:pearlescent_froglight
setblock 191 205 523 minecraft:pearlescent_froglight
setblock 192 205 514 minecraft:pearlescent_froglight
setblock 192 205 516 minecraft:pearlescent_froglight
setblock 192 205 518 minecraft:pearlescent_froglight
setblock 192 205 520 minecraft:pearlescent_froglight
setblock 192 205 522 minecraft:pearlescent_froglight
setblock 192 205 524 minecraft:pearlescent_froglight
setblock 193 205 515 minecraft:pearlescent_froglight
setblock 193 205 517 minecraft:pearlescent_froglight
setblock 193 205 519 minecraft:pearlescent_froglight
setblock 193 205 521 minecraft:pearlescent_froglight
setblock 193 205 523 minecraft:pearlescent_froglight
fill 202 205 519 206 205 520 minecraft:dark_oak_planks
fill 202 205 530 206 205 531 minecraft:dark_oak_planks
fill 203 205 518 206 205 518 minecraft:dark_oak_planks
fill 203 205 521 206 205 521 minecraft:dark_oak_planks
fill 203 205 529 206 205 529 minecraft:dark_oak_planks
fill 203 205 532 206 205 532 minecraft:dark_oak_planks
fill 204 205 517 205 205 517 minecraft:dark_oak_planks
fill 204 205 533 205 205 533 minecraft:dark_oak_planks
fill 214 205 518 217 205 521 minecraft:dark_oak_planks
fill 214 205 529 217 205 532 minecraft:dark_oak_planks
fill 215 205 517 216 205 517 minecraft:dark_oak_planks
fill 215 205 533 216 205 533 minecraft:dark_oak_planks
fill 218 205 519 218 205 520 minecraft:dark_oak_planks
fill 218 205 530 218 205 531 minecraft:dark_oak_planks
setblock 221 205 531 minecraft:pearlescent_froglight
setblock 221 205 533 minecraft:pearlescent_froglight
setblock 221 205 535 minecraft:pearlescent_froglight
setblock 221 205 537 minecraft:pearlescent_froglight
setblock 221 205 539 minecraft:pearlescent_froglight
setblock 221 205 541 minecraft:pearlescent_froglight
setblock 222 205 530 minecraft:pearlescent_froglight
setblock 222 205 532 minecraft:pearlescent_froglight
setblock 222 205 534 minecraft:pearlescent_froglight
setblock 222 205 536 minecraft:pearlescent_froglight
setblock 222 205 538 minecraft:pearlescent_froglight
setblock 222 205 540 minecraft:pearlescent_froglight
setblock 222 205 542 minecraft:pearlescent_froglight
setblock 223 205 531 minecraft:pearlescent_froglight
setblock 223 205 533 minecraft:pearlescent_froglight
setblock 223 205 535 minecraft:pearlescent_froglight
setblock 223 205 537 minecraft:pearlescent_froglight
setblock 223 205 539 minecraft:pearlescent_froglight
setblock 223 205 541 minecraft:pearlescent_froglight
setblock 224 205 530 minecraft:pearlescent_froglight
setblock 224 205 532 minecraft:pearlescent_froglight
setblock 224 205 534 minecraft:pearlescent_froglight
setblock 224 205 536 minecraft:pearlescent_froglight
setblock 224 205 538 minecraft:pearlescent_froglight
setblock 224 205 540 minecraft:pearlescent_froglight
setblock 224 205 542 minecraft:pearlescent_froglight
setblock 225 205 531 minecraft:pearlescent_froglight
setblock 225 205 533 minecraft:pearlescent_froglight
setblock 225 205 535 minecraft:pearlescent_froglight
setblock 225 205 537 minecraft:pearlescent_froglight
setblock 225 205 539 minecraft:pearlescent_froglight
setblock 225 205 541 minecraft:pearlescent_froglight
setblock 226 205 530 minecraft:pearlescent_froglight
setblock 226 205 532 minecraft:pearlescent_froglight
setblock 226 205 534 minecraft:pearlescent_froglight
setblock 226 205 536 minecraft:pearlescent_froglight
setblock 226 205 538 minecraft:pearlescent_froglight
setblock 226 205 540 minecraft:pearlescent_froglight
setblock 226 205 542 minecraft:pearlescent_froglight
setblock 227 205 531 minecraft:pearlescent_froglight
setblock 227 205 533 minecraft:pearlescent_froglight
setblock 227 205 535 minecraft:pearlescent_froglight
setblock 227 205 537 minecraft:pearlescent_froglight
setblock 227 205 539 minecraft:pearlescent_froglight
setblock 227 205 541 minecraft:pearlescent_froglight
setblock 228 205 530 minecraft:pearlescent_froglight
setblock 228 205 532 minecraft:pearlescent_froglight
setblock 228 205 534 minecraft:pearlescent_froglight
setblock 228 205 536 minecraft:pearlescent_froglight
setblock 228 205 538 minecraft:pearlescent_froglight
setblock 228 205 540 minecraft:pearlescent_froglight
setblock 228 205 542 minecraft:pearlescent_froglight
setblock 229 205 531 minecraft:pearlescent_froglight
setblock 229 205 533 minecraft:pearlescent_froglight
setblock 229 205 535 minecraft:pearlescent_froglight
setblock 229 205 537 minecraft:pearlescent_froglight
setblock 229 205 539 minecraft:pearlescent_froglight
setblock 229 205 541 minecraft:pearlescent_froglight
fill 188 206 515 188 213 515 minecraft:black_concrete
fill 188 206 523 188 213 523 minecraft:black_concrete
fill 188 206 531 188 213 531 minecraft:black_concrete
fill 188 206 539 188 213 539 minecraft:black_concrete
fill 188 206 547 188 213 547 minecraft:black_concrete
fill 189 206 515 189 207 515 minecraft:gray_concrete
fill 189 206 517 189 207 517 minecraft:gray_concrete
fill 189 206 519 189 207 519 minecraft:gray_concrete
fill 189 206 521 189 207 521 minecraft:gray_concrete
fill 189 206 523 189 207 523 minecraft:gray_concrete
fill 190 206 514 190 207 514 minecraft:gray_concrete
fill 190 206 516 190 207 516 minecraft:gray_concrete
fill 190 206 518 190 207 518 minecraft:gray_concrete
fill 190 206 520 190 207 520 minecraft:gray_concrete
fill 190 206 522 190 207 522 minecraft:gray_concrete
fill 190 206 524 190 207 524 minecraft:gray_concrete
fill 191 206 515 191 207 515 minecraft:gray_concrete
fill 191 206 517 191 207 517 minecraft:gray_concrete
fill 191 206 519 191 207 519 minecraft:gray_concrete
fill 191 206 521 191 207 521 minecraft:gray_concrete
fill 191 206 523 191 207 523 minecraft:gray_concrete
fill 191 206 552 191 213 552 minecraft:black_concrete
fill 192 206 514 192 207 514 minecraft:gray_concrete
fill 192 206 516 192 207 516 minecraft:gray_concrete
fill 192 206 518 192 207 518 minecraft:gray_concrete
fill 192 206 520 192 207 520 minecraft:gray_concrete
fill 192 206 522 192 207 522 minecraft:gray_concrete
fill 192 206 524 192 207 524 minecraft:gray_concrete
fill 193 206 515 193 207 515 minecraft:gray_concrete
fill 193 206 517 193 207 517 minecraft:gray_concrete
fill 193 206 519 193 207 519 minecraft:gray_concrete
fill 193 206 521 193 207 521 minecraft:gray_concrete
fill 193 206 523 193 207 523 minecraft:gray_concrete
fill 195 206 510 195 213 510 minecraft:black_concrete
fill 199 206 552 199 213 552 minecraft:black_concrete
fill 203 206 510 203 213 510 minecraft:black_concrete
fill 203 206 518 205 206 520 minecraft:dark_oak_planks
fill 203 206 530 205 206 532 minecraft:dark_oak_planks
fill 204 206 521 205 206 521 minecraft:dark_oak_planks
fill 204 206 529 205 206 529 minecraft:dark_oak_planks
fill 206 206 519 206 206 520 minecraft:dark_oak_planks
fill 206 206 530 206 206 531 minecraft:dark_oak_planks
fill 207 206 552 207 213 552 minecraft:black_concrete
fill 211 206 510 211 213 510 minecraft:black_concrete
fill 214 206 519 217 206 520 minecraft:dark_oak_planks
fill 214 206 530 217 206 531 minecraft:dark_oak_planks
fill 215 206 518 217 206 518 minecraft:dark_oak_planks
fill 215 206 521 216 206 521 minecraft:dark_oak_planks
fill 215 206 529 216 206 529 minecraft:dark_oak_planks
fill 215 206 532 217 206 532 minecraft:dark_oak_planks
fill 215 206 552 215 213 552 minecraft:black_concrete
fill 219 206 510 219 213 510 minecraft:black_concrete
fill 221 206 531 221 207 531 minecraft:gray_concrete
fill 221 206 533 221 207 533 minecraft:gray_concrete
fill 221 206 535 221 207 535 minecraft:gray_concrete
fill 221 206 537 221 207 537 minecraft:gray_concrete
fill 221 206 539 221 207 539 minecraft:gray_concrete
fill 221 206 541 221 207 541 minecraft:gray_concrete
fill 222 206 530 222 207 530 minecraft:gray_concrete
fill 222 206 532 222 207 532 minecraft:gray_concrete
fill 222 206 534 222 207 534 minecraft:gray_concrete
fill 222 206 536 222 207 536 minecraft:gray_concrete
fill 222 206 538 222 207 538 minecraft:gray_concrete
fill 222 206 540 222 207 540 minecraft:gray_concrete
fill 222 206 542 222 207 542 minecraft:gray_concrete
fill 223 206 531 223 207 531 minecraft:gray_concrete
fill 223 206 533 223 207 533 minecraft:gray_concrete
fill 223 206 535 223 207 535 minecraft:gray_concrete
fill 223 206 537 223 207 537 minecraft:gray_concrete
fill 223 206 539 223 207 539 minecraft:gray_concrete
fill 223 206 541 223 207 541 minecraft:gray_concrete
fill 223 206 552 223 213 552 minecraft:black_concrete
fill 224 206 530 224 207 530 minecraft:gray_concrete
fill 224 206 532 224 207 532 minecraft:gray_concrete
fill 224 206 534 224 207 534 minecraft:gray_concrete
fill 224 206 536 224 207 536 minecraft:gray_concrete
fill 224 206 538 224 207 538 minecraft:gray_concrete
fill 224 206 540 224 207 540 minecraft:gray_concrete
fill 224 206 542 224 207 542 minecraft:gray_concrete
fill 225 206 531 225 207 531 minecraft:gray_concrete
fill 225 206 533 225 207 533 minecraft:gray_concrete
fill 225 206 535 225 207 535 minecraft:gray_concrete
fill 225 206 537 225 207 537 minecraft:gray_concrete
fill 225 206 539 225 207 539 minecraft:gray_concrete
fill 225 206 541 225 207 541 minecraft:gray_concrete
fill 226 206 530 226 207 530 minecraft:gray_concrete
fill 226 206 532 226 207 532 minecraft:gray_concrete
fill 226 206 534 226 207 534 minecraft:gray_concrete
fill 226 206 536 226 207 536 minecraft:gray_concrete
fill 226 206 538 226 207 538 minecraft:gray_concrete
fill 226 206 540 226 207 540 minecraft:gray_concrete
fill 226 206 542 226 207 542 minecraft:gray_concrete
fill 227 206 510 227 213 510 minecraft:black_concrete
fill 227 206 531 227 207 531 minecraft:gray_concrete
fill 227 206 533 227 207 533 minecraft:gray_concrete
fill 227 206 535 227 207 535 minecraft:gray_concrete
fill 227 206 537 227 207 537 minecraft:gray_concrete
fill 227 206 539 227 207 539 minecraft:gray_concrete
fill 227 206 541 227 207 541 minecraft:gray_concrete
fill 228 206 530 228 207 530 minecraft:gray_concrete
fill 228 206 532 228 207 532 minecraft:gray_concrete
fill 228 206 534 228 207 534 minecraft:gray_concrete
fill 228 206 536 228 207 536 minecraft:gray_concrete
fill 228 206 538 228 207 538 minecraft:gray_concrete
fill 228 206 540 228 207 540 minecraft:gray_concrete
fill 228 206 542 228 207 542 minecraft:gray_concrete
fill 229 206 531 229 207 531 minecraft:gray_concrete
fill 229 206 533 229 207 533 minecraft:gray_concrete
fill 229 206 535 229 207 535 minecraft:gray_concrete
fill 229 206 537 229 207 537 minecraft:gray_concrete
fill 229 206 539 229 207 539 minecraft:gray_concrete
fill 229 206 541 229 207 541 minecraft:gray_concrete
fill 230 206 515 230 213 515 minecraft:black_concrete
fill 230 206 523 230 213 523 minecraft:black_concrete
fill 230 206 531 230 213 531 minecraft:black_concrete
fill 230 206 539 230 213 539 minecraft:black_concrete
fill 230 206 547 230 213 547 minecraft:black_concrete
fill 203 207 519 205 207 520 minecraft:dark_oak_planks
fill 203 207 530 205 207 531 minecraft:dark_oak_planks
fill 204 207 518 205 207 518 minecraft:dark_oak_planks
fill 204 207 532 205 207 532 minecraft:dark_oak_planks
fill 215 207 518 216 207 520 minecraft:dark_oak_planks
fill 215 207 530 216 207 532 minecraft:dark_oak_planks
fill 217 207 519 217 207 520 minecraft:dark_oak_planks
fill 217 207 530 217 207 531 minecraft:dark_oak_planks
setblock 189 208 515 minecraft:pearlescent_froglight
setblock 189 208 517 minecraft:pearlescent_froglight
setblock 189 208 519 minecraft:pearlescent_froglight
setblock 189 208 521 minecraft:pearlescent_froglight
setblock 189 208 523 minecraft:pearlescent_froglight
setblock 190 208 514 minecraft:pearlescent_froglight
setblock 190 208 516 minecraft:pearlescent_froglight
setblock 190 208 518 minecraft:pearlescent_froglight
setblock 190 208 520 minecraft:pearlescent_froglight
setblock 190 208 522 minecraft:pearlescent_froglight
setblock 190 208 524 minecraft:pearlescent_froglight
setblock 191 208 515 minecraft:pearlescent_froglight
setblock 191 208 517 minecraft:pearlescent_froglight
setblock 191 208 519 minecraft:pearlescent_froglight
setblock 191 208 521 minecraft:pearlescent_froglight
setblock 191 208 523 minecraft:pearlescent_froglight
setblock 192 208 514 minecraft:pearlescent_froglight
setblock 192 208 516 minecraft:pearlescent_froglight
setblock 192 208 518 minecraft:pearlescent_froglight
setblock 192 208 520 minecraft:pearlescent_froglight
setblock 192 208 522 minecraft:pearlescent_froglight
setblock 192 208 524 minecraft:pearlescent_froglight
setblock 193 208 515 minecraft:pearlescent_froglight
setblock 193 208 517 minecraft:pearlescent_froglight
setblock 193 208 519 minecraft:pearlescent_froglight
setblock 193 208 521 minecraft:pearlescent_froglight
setblock 193 208 523 minecraft:pearlescent_froglight
fill 204 208 519 205 208 520 minecraft:dark_oak_planks
fill 204 208 530 205 208 531 minecraft:dark_oak_planks
fill 215 208 519 216 208 520 minecraft:dark_oak_planks
fill 215 208 530 216 208 531 minecraft:dark_oak_planks
setblock 221 208 531 minecraft:pearlescent_froglight
setblock 221 208 533 minecraft:pearlescent_froglight
setblock 221 208 535 minecraft:pearlescent_froglight
setblock 221 208 537 minecraft:pearlescent_froglight
setblock 221 208 539 minecraft:pearlescent_froglight
setblock 221 208 541 minecraft:pearlescent_froglight
setblock 222 208 530 minecraft:pearlescent_froglight
setblock 222 208 532 minecraft:pearlescent_froglight
setblock 222 208 534 minecraft:pearlescent_froglight
setblock 222 208 536 minecraft:pearlescent_froglight
setblock 222 208 538 minecraft:pearlescent_froglight
setblock 222 208 540 minecraft:pearlescent_froglight
setblock 222 208 542 minecraft:pearlescent_froglight
setblock 223 208 531 minecraft:pearlescent_froglight
setblock 223 208 533 minecraft:pearlescent_froglight
setblock 223 208 535 minecraft:pearlescent_froglight
setblock 223 208 537 minecraft:pearlescent_froglight
setblock 223 208 539 minecraft:pearlescent_froglight
setblock 223 208 541 minecraft:pearlescent_froglight
setblock 224 208 530 minecraft:pearlescent_froglight
setblock 224 208 532 minecraft:pearlescent_froglight
setblock 224 208 534 minecraft:pearlescent_froglight
setblock 224 208 536 minecraft:pearlescent_froglight
setblock 224 208 538 minecraft:pearlescent_froglight
setblock 224 208 540 minecraft:pearlescent_froglight
setblock 224 208 542 minecraft:pearlescent_froglight
setblock 225 208 531 minecraft:pearlescent_froglight
setblock 225 208 533 minecraft:pearlescent_froglight
setblock 225 208 535 minecraft:pearlescent_froglight
setblock 225 208 537 minecraft:pearlescent_froglight
setblock 225 208 539 minecraft:pearlescent_froglight
setblock 225 208 541 minecraft:pearlescent_froglight
setblock 226 208 530 minecraft:pearlescent_froglight
setblock 226 208 532 minecraft:pearlescent_froglight
setblock 226 208 534 minecraft:pearlescent_froglight
setblock 226 208 536 minecraft:pearlescent_froglight
setblock 226 208 538 minecraft:pearlescent_froglight
setblock 226 208 540 minecraft:pearlescent_froglight
setblock 226 208 542 minecraft:pearlescent_froglight
setblock 227 208 531 minecraft:pearlescent_froglight
setblock 227 208 533 minecraft:pearlescent_froglight
setblock 227 208 535 minecraft:pearlescent_froglight
setblock 227 208 537 minecraft:pearlescent_froglight
setblock 227 208 539 minecraft:pearlescent_froglight
setblock 227 208 541 minecraft:pearlescent_froglight
setblock 228 208 530 minecraft:pearlescent_froglight
setblock 228 208 532 minecraft:pearlescent_froglight
setblock 228 208 534 minecraft:pearlescent_froglight
setblock 228 208 536 minecraft:pearlescent_froglight
setblock 228 208 538 minecraft:pearlescent_froglight
setblock 228 208 540 minecraft:pearlescent_froglight
schedule function dropper:buildpart/124_2 1t
