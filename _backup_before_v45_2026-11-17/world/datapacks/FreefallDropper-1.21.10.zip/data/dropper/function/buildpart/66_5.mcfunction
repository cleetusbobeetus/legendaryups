fill 312 299 313 312 300 313 minecraft:iron_block
fill 312 299 315 312 300 315 minecraft:iron_block
fill 317 299 280 317 299 282 minecraft:gray_concrete
setblock 318 299 279 minecraft:gray_concrete
fill 318 299 283 320 299 283 minecraft:gray_concrete
fill 320 299 279 321 299 279 minecraft:gray_concrete
fill 321 299 280 321 299 282 minecraft:gray_concrete
fill 324 299 278 324 304 278 minecraft:light_gray_concrete
fill 324 299 285 324 304 285 minecraft:light_gray_concrete
fill 324 299 292 324 304 292 minecraft:light_gray_concrete
fill 324 299 312 324 304 312 minecraft:light_gray_concrete
setblock 283 300 278 minecraft:iron_block
setblock 283 300 288 minecraft:iron_block
setblock 283 300 298 minecraft:iron_block
setblock 283 300 308 minecraft:iron_block
setblock 285 300 278 minecraft:light[level=12]
setblock 285 300 292 minecraft:light[level=12]
setblock 285 300 299 minecraft:light[level=12]
setblock 285 300 306 minecraft:light[level=12]
setblock 285 300 313 minecraft:light[level=12]
setblock 285 300 316 minecraft:iron_block
setblock 289 300 276 minecraft:iron_block
setblock 292 300 285 minecraft:light[level=12]
setblock 292 300 292 minecraft:light[level=12]
setblock 292 300 299 minecraft:light[level=12]
setblock 292 300 306 minecraft:light[level=12]
setblock 292 300 313 minecraft:light[level=12]
setblock 295 300 316 minecraft:iron_block
setblock 299 300 276 minecraft:iron_block
setblock 299 300 278 minecraft:light[level=12]
setblock 299 300 285 minecraft:light[level=12]
setblock 299 300 292 minecraft:light[level=12]
setblock 299 300 299 minecraft:light[level=12]
setblock 299 300 306 minecraft:light[level=12]
setblock 299 300 313 minecraft:light[level=12]
setblock 305 300 316 minecraft:iron_block
setblock 306 300 278 minecraft:light[level=12]
setblock 306 300 285 minecraft:light[level=12]
setblock 306 300 292 minecraft:light[level=12]
setblock 306 300 299 minecraft:light[level=12]
setblock 306 300 306 minecraft:light[level=12]
setblock 309 300 276 minecraft:iron_block
setblock 313 300 278 minecraft:light[level=12]
setblock 313 300 285 minecraft:light[level=12]
setblock 313 300 292 minecraft:light[level=12]
setblock 313 300 299 minecraft:light[level=12]
setblock 313 300 306 minecraft:light[level=12]
setblock 313 300 313 minecraft:light[level=12]
setblock 315 300 316 minecraft:iron_block
fill 317 300 280 317 300 281 minecraft:light_gray_concrete
setblock 318 300 279 minecraft:light_gray_concrete
setblock 319 300 276 minecraft:iron_block
setblock 319 300 283 minecraft:light_gray_concrete
setblock 320 300 278 minecraft:light[level=12]
setblock 320 300 279 minecraft:light_gray_concrete
setblock 320 300 285 minecraft:light[level=12]
setblock 320 300 292 minecraft:light[level=12]
setblock 320 300 299 minecraft:light[level=12]
setblock 320 300 306 minecraft:light[level=12]
setblock 320 300 313 minecraft:light[level=12]
fill 321 300 280 321 300 282 minecraft:light_gray_concrete
setblock 323 300 282 minecraft:iron_block
setblock 323 300 292 minecraft:iron_block
setblock 323 300 302 minecraft:iron_block
setblock 323 300 312 minecraft:iron_block
fill 282 301 281 282 304 283 minecraft:light_gray_concrete
setblock 282 301 284 minecraft:redstone_block
fill 282 302 284 282 304 284 minecraft:light_gray_concrete
fill 295 302 275 297 304 275 minecraft:light_gray_concrete
setblock 298 302 275 minecraft:sea_lantern
setblock 324 302 280 minecraft:redstone_block
fill 282 303 301 282 304 301 minecraft:light_gray_concrete
setblock 282 303 302 minecraft:sea_lantern
fill 282 303 303 282 304 304 minecraft:light_gray_concrete
fill 298 303 275 298 304 275 minecraft:light_gray_concrete
fill 324 303 280 324 304 280 minecraft:light_gray_concrete
fill 324 303 286 324 304 286 minecraft:light_gray_concrete
setblock 324 303 287 minecraft:redstone_block
fill 324 303 288 324 304 289 minecraft:light_gray_concrete
setblock 282 304 302 minecraft:light_gray_concrete
setblock 324 304 287 minecraft:light_gray_concrete
fill 282 305 275 282 306 276 minecraft:yellow_concrete
fill 282 305 277 282 306 278 minecraft:black_concrete
fill 282 305 279 282 306 280 minecraft:yellow_concrete
fill 282 305 281 282 306 282 minecraft:black_concrete
fill 282 305 283 282 306 284 minecraft:yellow_concrete
fill 282 305 285 282 306 286 minecraft:black_concrete
fill 282 305 287 282 306 288 minecraft:yellow_concrete
fill 282 305 289 282 306 290 minecraft:black_concrete
fill 282 305 291 282 306 292 minecraft:yellow_concrete
fill 282 305 293 282 306 294 minecraft:black_concrete
fill 282 305 295 282 306 296 minecraft:yellow_concrete
fill 282 305 297 282 306 298 minecraft:black_concrete
fill 282 305 299 282 306 300 minecraft:yellow_concrete
fill 282 305 301 282 306 302 minecraft:black_concrete
fill 282 305 303 282 306 304 minecraft:yellow_concrete
fill 282 305 305 282 306 306 minecraft:black_concrete
fill 282 305 307 282 306 308 minecraft:yellow_concrete
fill 282 305 309 282 306 310 minecraft:black_concrete
fill 282 305 311 282 306 312 minecraft:yellow_concrete
fill 282 305 313 282 306 314 minecraft:black_concrete
fill 282 305 315 282 306 316 minecraft:yellow_concrete
fill 282 305 317 282 306 317 minecraft:black_concrete
fill 283 305 275 283 306 275 minecraft:yellow_concrete
fill 283 305 317 283 306 317 minecraft:yellow_concrete
fill 284 305 275 285 306 275 minecraft:black_concrete
fill 284 305 317 285 306 317 minecraft:black_concrete
fill 286 305 275 287 306 275 minecraft:yellow_concrete
fill 286 305 317 287 306 317 minecraft:yellow_concrete
fill 288 305 275 289 306 275 minecraft:black_concrete
fill 288 305 317 289 306 317 minecraft:black_concrete
fill 290 305 275 291 306 275 minecraft:yellow_concrete
fill 290 305 317 291 306 317 minecraft:yellow_concrete
fill 292 305 275 293 306 275 minecraft:black_concrete
fill 292 305 317 293 306 317 minecraft:black_concrete
fill 294 305 275 295 306 275 minecraft:yellow_concrete
fill 294 305 317 295 306 317 minecraft:yellow_concrete
fill 296 305 275 297 306 275 minecraft:black_concrete
fill 296 305 317 297 306 317 minecraft:black_concrete
fill 298 305 275 299 306 275 minecraft:yellow_concrete
fill 298 305 317 299 306 317 minecraft:yellow_concrete
fill 300 305 275 301 306 275 minecraft:black_concrete
fill 300 305 317 301 306 317 minecraft:black_concrete
fill 302 305 275 303 306 275 minecraft:yellow_concrete
fill 302 305 317 303 306 317 minecraft:yellow_concrete
fill 304 305 275 305 306 275 minecraft:black_concrete
fill 304 305 317 305 306 317 minecraft:black_concrete
fill 306 305 275 307 306 275 minecraft:yellow_concrete
fill 306 305 317 307 306 317 minecraft:yellow_concrete
fill 308 305 275 309 306 275 minecraft:black_concrete
fill 308 305 317 309 306 317 minecraft:black_concrete
fill 310 305 275 311 306 275 minecraft:yellow_concrete
fill 310 305 317 311 306 317 minecraft:yellow_concrete
fill 312 305 275 313 306 275 minecraft:black_concrete
fill 312 305 317 313 306 317 minecraft:black_concrete
fill 314 305 275 315 306 275 minecraft:yellow_concrete
fill 314 305 317 315 306 317 minecraft:yellow_concrete
fill 316 305 275 317 306 275 minecraft:black_concrete
fill 316 305 317 317 306 317 minecraft:black_concrete
fill 318 305 275 319 306 275 minecraft:yellow_concrete
fill 318 305 317 319 306 317 minecraft:yellow_concrete
fill 320 305 275 321 306 275 minecraft:black_concrete
fill 320 305 317 321 306 317 minecraft:black_concrete
fill 322 305 275 323 306 275 minecraft:yellow_concrete
fill 322 305 317 323 306 317 minecraft:yellow_concrete
fill 324 305 275 324 306 275 minecraft:black_concrete
fill 324 305 276 324 306 276 minecraft:yellow_concrete
fill 324 305 277 324 306 278 minecraft:black_concrete
fill 324 305 279 324 306 280 minecraft:yellow_concrete
fill 324 305 281 324 306 282 minecraft:black_concrete
fill 324 305 283 324 306 284 minecraft:yellow_concrete
fill 324 305 285 324 306 286 minecraft:black_concrete
fill 324 305 287 324 306 288 minecraft:yellow_concrete
fill 324 305 289 324 306 290 minecraft:black_concrete
fill 324 305 291 324 306 292 minecraft:yellow_concrete
fill 324 305 293 324 306 294 minecraft:black_concrete
fill 324 305 295 324 306 296 minecraft:yellow_concrete
fill 324 305 297 324 306 298 minecraft:black_concrete
fill 324 305 299 324 306 300 minecraft:yellow_concrete
fill 324 305 301 324 306 302 minecraft:black_concrete
fill 324 305 303 324 306 304 minecraft:yellow_concrete
fill 324 305 305 324 306 306 minecraft:black_concrete
fill 324 305 307 324 306 308 minecraft:yellow_concrete
fill 324 305 309 324 306 310 minecraft:black_concrete
fill 324 305 311 324 306 312 minecraft:yellow_concrete
fill 324 305 313 324 306 314 minecraft:black_concrete
fill 324 305 315 324 306 316 minecraft:yellow_concrete
fill 324 305 317 324 306 317 minecraft:black_concrete
fill 282 307 275 282 308 317 minecraft:light_gray_concrete
fill 283 307 275 324 308 275 minecraft:light_gray_concrete
fill 283 307 317 324 307 317 minecraft:light_gray_concrete
fill 324 307 276 324 308 300 minecraft:light_gray_concrete
setblock 324 307 301 minecraft:sea_lantern
fill 324 307 302 324 308 315 minecraft:light_gray_concrete
setblock 324 307 316 minecraft:redstone_block
fill 283 308 317 320 308 317 minecraft:light_gray_concrete
setblock 321 308 317 minecraft:redstone_block
fill 322 308 317 324 308 317 minecraft:light_gray_concrete
setblock 324 308 301 minecraft:light_gray_concrete
setblock 324 308 316 minecraft:light_gray_concrete
