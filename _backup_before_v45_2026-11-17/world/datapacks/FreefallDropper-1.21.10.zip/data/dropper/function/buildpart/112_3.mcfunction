fill 202 290 467 202 291 467 minecraft:light_gray_concrete
fill 203 290 463 203 297 463 minecraft:white_terracotta
fill 203 290 464 203 291 464 minecraft:light_gray_concrete
fill 203 290 466 203 291 466 minecraft:light_gray_concrete
fill 203 290 468 203 291 468 minecraft:light_gray_concrete
fill 204 290 465 204 291 465 minecraft:light_gray_concrete
fill 204 290 467 204 291 467 minecraft:light_gray_concrete
fill 204 290 495 204 291 495 minecraft:light_gray_concrete
fill 204 290 497 204 291 497 minecraft:light_gray_concrete
fill 204 290 499 204 291 499 minecraft:light_gray_concrete
fill 204 290 501 204 291 501 minecraft:light_gray_concrete
fill 204 290 503 204 291 503 minecraft:light_gray_concrete
fill 205 290 464 205 291 464 minecraft:light_gray_concrete
fill 205 290 466 205 291 466 minecraft:light_gray_concrete
fill 205 290 468 205 291 468 minecraft:light_gray_concrete
fill 205 290 496 205 291 496 minecraft:light_gray_concrete
fill 205 290 498 205 291 498 minecraft:light_gray_concrete
fill 205 290 500 205 291 500 minecraft:light_gray_concrete
fill 205 290 502 205 291 502 minecraft:light_gray_concrete
fill 205 290 504 205 291 504 minecraft:light_gray_concrete
fill 206 290 495 206 291 495 minecraft:light_gray_concrete
fill 206 290 497 206 291 497 minecraft:light_gray_concrete
fill 206 290 499 206 291 499 minecraft:light_gray_concrete
fill 206 290 501 206 291 501 minecraft:light_gray_concrete
fill 206 290 503 206 291 503 minecraft:light_gray_concrete
fill 207 290 496 207 291 496 minecraft:light_gray_concrete
fill 207 290 498 207 291 498 minecraft:light_gray_concrete
fill 207 290 500 207 291 500 minecraft:light_gray_concrete
fill 207 290 502 207 291 502 minecraft:light_gray_concrete
fill 207 290 504 207 291 504 minecraft:light_gray_concrete
fill 207 290 505 207 297 505 minecraft:white_terracotta
fill 208 290 495 208 291 495 minecraft:light_gray_concrete
fill 208 290 497 208 291 497 minecraft:light_gray_concrete
fill 208 290 499 208 291 499 minecraft:light_gray_concrete
fill 208 290 501 208 291 501 minecraft:light_gray_concrete
fill 208 290 503 208 291 503 minecraft:light_gray_concrete
fill 209 290 496 209 291 496 minecraft:light_gray_concrete
fill 209 290 498 209 291 498 minecraft:light_gray_concrete
fill 209 290 500 209 291 500 minecraft:light_gray_concrete
fill 209 290 502 209 291 502 minecraft:light_gray_concrete
fill 209 290 504 209 291 504 minecraft:light_gray_concrete
fill 210 290 495 210 291 495 minecraft:light_gray_concrete
fill 210 290 497 210 291 497 minecraft:light_gray_concrete
fill 210 290 499 210 291 499 minecraft:light_gray_concrete
fill 210 290 501 210 291 501 minecraft:light_gray_concrete
fill 210 290 503 210 291 503 minecraft:light_gray_concrete
fill 211 290 463 211 297 463 minecraft:white_terracotta
fill 215 290 505 215 297 505 minecraft:white_terracotta
fill 219 290 463 219 297 463 minecraft:white_terracotta
fill 219 290 486 219 291 486 minecraft:light_gray_concrete
fill 219 290 488 219 291 488 minecraft:light_gray_concrete
fill 219 290 490 219 291 490 minecraft:light_gray_concrete
fill 219 290 492 219 291 492 minecraft:light_gray_concrete
fill 219 290 494 219 291 494 minecraft:light_gray_concrete
fill 219 290 496 219 291 496 minecraft:light_gray_concrete
fill 219 290 498 219 291 498 minecraft:light_gray_concrete
fill 220 290 487 220 291 487 minecraft:light_gray_concrete
fill 220 290 489 220 291 489 minecraft:light_gray_concrete
fill 220 290 491 220 291 491 minecraft:light_gray_concrete
fill 220 290 493 220 291 493 minecraft:light_gray_concrete
fill 220 290 495 220 291 495 minecraft:light_gray_concrete
fill 220 290 497 220 291 497 minecraft:light_gray_concrete
fill 221 290 486 221 291 486 minecraft:light_gray_concrete
fill 221 290 488 221 291 488 minecraft:light_gray_concrete
fill 221 290 490 221 291 490 minecraft:light_gray_concrete
fill 221 290 492 221 291 492 minecraft:light_gray_concrete
fill 221 290 494 221 291 494 minecraft:light_gray_concrete
fill 221 290 496 221 291 496 minecraft:light_gray_concrete
fill 221 290 498 221 291 498 minecraft:light_gray_concrete
fill 222 290 487 222 291 487 minecraft:light_gray_concrete
fill 222 290 489 222 291 489 minecraft:light_gray_concrete
fill 222 290 491 222 291 491 minecraft:light_gray_concrete
fill 222 290 493 222 291 493 minecraft:light_gray_concrete
fill 222 290 495 222 291 495 minecraft:light_gray_concrete
fill 222 290 497 222 291 497 minecraft:light_gray_concrete
fill 223 290 486 223 291 486 minecraft:light_gray_concrete
fill 223 290 488 223 291 488 minecraft:light_gray_concrete
fill 223 290 490 223 291 490 minecraft:light_gray_concrete
fill 223 290 492 223 291 492 minecraft:light_gray_concrete
fill 223 290 494 223 291 494 minecraft:light_gray_concrete
fill 223 290 496 223 291 496 minecraft:light_gray_concrete
fill 223 290 498 223 291 498 minecraft:light_gray_concrete
fill 223 290 505 223 297 505 minecraft:white_terracotta
fill 224 290 487 224 291 487 minecraft:light_gray_concrete
fill 224 290 489 224 291 489 minecraft:light_gray_concrete
fill 224 290 491 224 291 491 minecraft:light_gray_concrete
fill 224 290 493 224 291 493 minecraft:light_gray_concrete
fill 224 290 495 224 291 495 minecraft:light_gray_concrete
fill 224 290 497 224 291 497 minecraft:light_gray_concrete
fill 225 290 486 225 291 486 minecraft:light_gray_concrete
fill 225 290 488 225 291 488 minecraft:light_gray_concrete
fill 225 290 490 225 291 490 minecraft:light_gray_concrete
fill 225 290 492 225 291 492 minecraft:light_gray_concrete
fill 225 290 494 225 291 494 minecraft:light_gray_concrete
fill 225 290 496 225 291 496 minecraft:light_gray_concrete
fill 225 290 498 225 291 498 minecraft:light_gray_concrete
fill 226 290 487 226 291 487 minecraft:light_gray_concrete
fill 226 290 489 226 291 489 minecraft:light_gray_concrete
fill 226 290 491 226 291 491 minecraft:light_gray_concrete
fill 226 290 493 226 291 493 minecraft:light_gray_concrete
fill 226 290 495 226 291 495 minecraft:light_gray_concrete
fill 226 290 497 226 291 497 minecraft:light_gray_concrete
fill 227 290 463 227 297 463 minecraft:white_terracotta
fill 227 290 486 227 291 486 minecraft:light_gray_concrete
fill 227 290 488 227 291 488 minecraft:light_gray_concrete
fill 227 290 490 227 291 490 minecraft:light_gray_concrete
fill 227 290 492 227 291 492 minecraft:light_gray_concrete
fill 227 290 494 227 291 494 minecraft:light_gray_concrete
fill 227 290 496 227 291 496 minecraft:light_gray_concrete
fill 227 290 498 227 291 498 minecraft:light_gray_concrete
fill 228 290 487 228 291 487 minecraft:light_gray_concrete
fill 228 290 489 228 291 489 minecraft:light_gray_concrete
fill 228 290 491 228 291 491 minecraft:light_gray_concrete
fill 228 290 493 228 291 493 minecraft:light_gray_concrete
fill 228 290 495 228 291 495 minecraft:light_gray_concrete
fill 228 290 497 228 291 497 minecraft:light_gray_concrete
fill 229 290 486 229 291 486 minecraft:light_gray_concrete
fill 229 290 488 229 291 488 minecraft:light_gray_concrete
fill 229 290 490 229 291 490 minecraft:light_gray_concrete
fill 229 290 492 229 291 492 minecraft:light_gray_concrete
fill 229 290 494 229 291 494 minecraft:light_gray_concrete
fill 229 290 496 229 291 496 minecraft:light_gray_concrete
fill 229 290 498 229 291 498 minecraft:light_gray_concrete
fill 230 290 468 230 297 468 minecraft:white_terracotta
fill 230 290 476 230 297 476 minecraft:white_terracotta
fill 230 290 484 230 297 484 minecraft:white_terracotta
fill 230 290 492 230 297 492 minecraft:white_terracotta
fill 230 290 500 230 297 500 minecraft:white_terracotta
setblock 199 292 464 minecraft:pearlescent_froglight
setblock 199 292 466 minecraft:pearlescent_froglight
setblock 199 292 468 minecraft:pearlescent_froglight
setblock 200 292 465 minecraft:pearlescent_froglight
setblock 200 292 467 minecraft:pearlescent_froglight
setblock 201 292 464 minecraft:pearlescent_froglight
setblock 201 292 466 minecraft:pearlescent_froglight
setblock 201 292 468 minecraft:pearlescent_froglight
setblock 202 292 465 minecraft:pearlescent_froglight
setblock 202 292 467 minecraft:pearlescent_froglight
setblock 203 292 464 minecraft:pearlescent_froglight
setblock 203 292 466 minecraft:pearlescent_froglight
setblock 203 292 468 minecraft:pearlescent_froglight
setblock 204 292 465 minecraft:pearlescent_froglight
setblock 204 292 467 minecraft:pearlescent_froglight
setblock 204 292 495 minecraft:pearlescent_froglight
setblock 204 292 497 minecraft:pearlescent_froglight
setblock 204 292 499 minecraft:pearlescent_froglight
setblock 204 292 501 minecraft:pearlescent_froglight
setblock 204 292 503 minecraft:pearlescent_froglight
setblock 205 292 464 minecraft:pearlescent_froglight
setblock 205 292 466 minecraft:pearlescent_froglight
setblock 205 292 468 minecraft:pearlescent_froglight
setblock 205 292 496 minecraft:pearlescent_froglight
setblock 205 292 498 minecraft:pearlescent_froglight
setblock 205 292 500 minecraft:pearlescent_froglight
setblock 205 292 502 minecraft:pearlescent_froglight
setblock 205 292 504 minecraft:pearlescent_froglight
setblock 206 292 495 minecraft:pearlescent_froglight
setblock 206 292 497 minecraft:pearlescent_froglight
setblock 206 292 499 minecraft:pearlescent_froglight
setblock 206 292 501 minecraft:pearlescent_froglight
setblock 206 292 503 minecraft:pearlescent_froglight
setblock 207 292 496 minecraft:pearlescent_froglight
setblock 207 292 498 minecraft:pearlescent_froglight
setblock 207 292 500 minecraft:pearlescent_froglight
setblock 207 292 502 minecraft:pearlescent_froglight
setblock 207 292 504 minecraft:pearlescent_froglight
setblock 208 292 495 minecraft:pearlescent_froglight
setblock 208 292 497 minecraft:pearlescent_froglight
setblock 208 292 499 minecraft:pearlescent_froglight
setblock 208 292 501 minecraft:pearlescent_froglight
setblock 208 292 503 minecraft:pearlescent_froglight
setblock 209 292 496 minecraft:pearlescent_froglight
setblock 209 292 498 minecraft:pearlescent_froglight
setblock 209 292 500 minecraft:pearlescent_froglight
setblock 209 292 502 minecraft:pearlescent_froglight
setblock 209 292 504 minecraft:pearlescent_froglight
setblock 210 292 495 minecraft:pearlescent_froglight
setblock 210 292 497 minecraft:pearlescent_froglight
setblock 210 292 499 minecraft:pearlescent_froglight
setblock 210 292 501 minecraft:pearlescent_froglight
setblock 210 292 503 minecraft:pearlescent_froglight
setblock 219 292 486 minecraft:pearlescent_froglight
setblock 219 292 488 minecraft:pearlescent_froglight
setblock 219 292 490 minecraft:pearlescent_froglight
setblock 219 292 492 minecraft:pearlescent_froglight
setblock 219 292 494 minecraft:pearlescent_froglight
setblock 219 292 496 minecraft:pearlescent_froglight
setblock 219 292 498 minecraft:pearlescent_froglight
setblock 220 292 487 minecraft:pearlescent_froglight
setblock 220 292 489 minecraft:pearlescent_froglight
setblock 220 292 491 minecraft:pearlescent_froglight
setblock 220 292 493 minecraft:pearlescent_froglight
setblock 220 292 495 minecraft:pearlescent_froglight
setblock 220 292 497 minecraft:pearlescent_froglight
setblock 221 292 486 minecraft:pearlescent_froglight
setblock 221 292 488 minecraft:pearlescent_froglight
setblock 221 292 490 minecraft:pearlescent_froglight
setblock 221 292 492 minecraft:pearlescent_froglight
setblock 221 292 494 minecraft:pearlescent_froglight
setblock 221 292 496 minecraft:pearlescent_froglight
setblock 221 292 498 minecraft:pearlescent_froglight
setblock 222 292 487 minecraft:pearlescent_froglight
setblock 222 292 489 minecraft:pearlescent_froglight
setblock 222 292 491 minecraft:pearlescent_froglight
setblock 222 292 493 minecraft:pearlescent_froglight
setblock 222 292 495 minecraft:pearlescent_froglight
setblock 222 292 497 minecraft:pearlescent_froglight
setblock 223 292 486 minecraft:pearlescent_froglight
setblock 223 292 488 minecraft:pearlescent_froglight
setblock 223 292 490 minecraft:pearlescent_froglight
setblock 223 292 492 minecraft:pearlescent_froglight
setblock 223 292 494 minecraft:pearlescent_froglight
setblock 223 292 496 minecraft:pearlescent_froglight
setblock 223 292 498 minecraft:pearlescent_froglight
setblock 224 292 487 minecraft:pearlescent_froglight
setblock 224 292 489 minecraft:pearlescent_froglight
setblock 224 292 491 minecraft:pearlescent_froglight
setblock 224 292 493 minecraft:pearlescent_froglight
setblock 224 292 495 minecraft:pearlescent_froglight
setblock 224 292 497 minecraft:pearlescent_froglight
setblock 225 292 486 minecraft:pearlescent_froglight
setblock 225 292 488 minecraft:pearlescent_froglight
setblock 225 292 490 minecraft:pearlescent_froglight
setblock 225 292 492 minecraft:pearlescent_froglight
setblock 225 292 494 minecraft:pearlescent_froglight
setblock 225 292 496 minecraft:pearlescent_froglight
setblock 225 292 498 minecraft:pearlescent_froglight
setblock 226 292 487 minecraft:pearlescent_froglight
setblock 226 292 489 minecraft:pearlescent_froglight
setblock 226 292 491 minecraft:pearlescent_froglight
setblock 226 292 493 minecraft:pearlescent_froglight
setblock 226 292 495 minecraft:pearlescent_froglight
setblock 226 292 497 minecraft:pearlescent_froglight
setblock 227 292 486 minecraft:pearlescent_froglight
setblock 227 292 488 minecraft:pearlescent_froglight
setblock 227 292 490 minecraft:pearlescent_froglight
setblock 227 292 492 minecraft:pearlescent_froglight
setblock 227 292 494 minecraft:pearlescent_froglight
setblock 227 292 496 minecraft:pearlescent_froglight
setblock 227 292 498 minecraft:pearlescent_froglight
setblock 228 292 487 minecraft:pearlescent_froglight
setblock 228 292 489 minecraft:pearlescent_froglight
setblock 228 292 491 minecraft:pearlescent_froglight
setblock 228 292 493 minecraft:pearlescent_froglight
setblock 228 292 495 minecraft:pearlescent_froglight
setblock 228 292 497 minecraft:pearlescent_froglight
setblock 229 292 486 minecraft:pearlescent_froglight
setblock 229 292 488 minecraft:pearlescent_froglight
setblock 229 292 490 minecraft:pearlescent_froglight
setblock 229 292 492 minecraft:pearlescent_froglight
setblock 229 292 494 minecraft:pearlescent_froglight
setblock 229 292 496 minecraft:pearlescent_froglight
setblock 229 292 498 minecraft:pearlescent_froglight
setblock 191 293 466 minecraft:light[level=11]
setblock 191 293 474 minecraft:light[level=11]
setblock 191 293 482 minecraft:light[level=11]
setblock 191 293 490 minecraft:light[level=11]
setblock 191 293 498 minecraft:light[level=11]
fill 199 293 464 199 294 464 minecraft:light_gray_concrete
fill 199 293 466 199 294 466 minecraft:light_gray_concrete
fill 199 293 468 199 294 468 minecraft:light_gray_concrete
setblock 199 293 474 minecraft:light[level=11]
setblock 199 293 482 minecraft:light[level=11]
setblock 199 293 490 minecraft:light[level=11]
setblock 199 293 498 minecraft:light[level=11]
fill 200 293 465 200 294 465 minecraft:light_gray_concrete
fill 200 293 467 200 294 467 minecraft:light_gray_concrete
fill 201 293 464 201 294 464 minecraft:light_gray_concrete
fill 201 293 466 201 294 466 minecraft:light_gray_concrete
fill 201 293 468 201 294 468 minecraft:light_gray_concrete
fill 202 293 465 202 294 465 minecraft:light_gray_concrete
fill 202 293 467 202 294 467 minecraft:light_gray_concrete
fill 203 293 464 203 294 464 minecraft:light_gray_concrete
fill 203 293 466 203 294 466 minecraft:light_gray_concrete
fill 203 293 468 203 294 468 minecraft:light_gray_concrete
fill 204 293 465 204 294 465 minecraft:light_gray_concrete
fill 204 293 467 204 294 467 minecraft:light_gray_concrete
fill 204 293 495 204 294 495 minecraft:light_gray_concrete
fill 204 293 497 204 294 497 minecraft:light_gray_concrete
fill 204 293 499 204 294 499 minecraft:light_gray_concrete
fill 204 293 501 204 294 501 minecraft:light_gray_concrete
fill 204 293 503 204 294 503 minecraft:light_gray_concrete
fill 205 293 464 205 294 464 minecraft:light_gray_concrete
fill 205 293 466 205 294 466 minecraft:light_gray_concrete
fill 205 293 468 205 294 468 minecraft:light_gray_concrete
fill 205 293 496 205 294 496 minecraft:light_gray_concrete
fill 205 293 498 205 294 498 minecraft:light_gray_concrete
fill 205 293 500 205 294 500 minecraft:light_gray_concrete
fill 205 293 502 205 294 502 minecraft:light_gray_concrete
fill 205 293 504 205 294 504 minecraft:light_gray_concrete
fill 206 293 495 206 294 495 minecraft:light_gray_concrete
fill 206 293 497 206 294 497 minecraft:light_gray_concrete
fill 206 293 499 206 294 499 minecraft:light_gray_concrete
fill 206 293 501 206 294 501 minecraft:light_gray_concrete
fill 206 293 503 206 294 503 minecraft:light_gray_concrete
setblock 207 293 466 minecraft:light[level=11]
setblock 207 293 474 minecraft:light[level=11]
setblock 207 293 482 minecraft:light[level=11]
setblock 207 293 490 minecraft:light[level=11]
fill 207 293 496 207 294 496 minecraft:light_gray_concrete
fill 207 293 498 207 294 498 minecraft:light_gray_concrete
fill 207 293 500 207 294 500 minecraft:light_gray_concrete
fill 207 293 502 207 294 502 minecraft:light_gray_concrete
fill 207 293 504 207 294 504 minecraft:light_gray_concrete
fill 208 293 495 208 294 495 minecraft:light_gray_concrete
fill 208 293 497 208 294 497 minecraft:light_gray_concrete
fill 208 293 499 208 294 499 minecraft:light_gray_concrete
fill 208 293 501 208 294 501 minecraft:light_gray_concrete
fill 208 293 503 208 294 503 minecraft:light_gray_concrete
fill 209 293 496 209 294 496 minecraft:light_gray_concrete
fill 209 293 498 209 294 498 minecraft:light_gray_concrete
fill 209 293 500 209 294 500 minecraft:light_gray_concrete
fill 209 293 502 209 294 502 minecraft:light_gray_concrete
fill 209 293 504 209 294 504 minecraft:light_gray_concrete
fill 210 293 495 210 294 495 minecraft:light_gray_concrete
fill 210 293 497 210 294 497 minecraft:light_gray_concrete
fill 210 293 499 210 294 499 minecraft:light_gray_concrete
fill 210 293 501 210 294 501 minecraft:light_gray_concrete
fill 210 293 503 210 294 503 minecraft:light_gray_concrete
setblock 215 293 466 minecraft:light[level=11]
setblock 215 293 474 minecraft:light[level=11]
setblock 215 293 482 minecraft:light[level=11]
setblock 215 293 490 minecraft:light[level=11]
setblock 215 293 498 minecraft:light[level=11]
fill 219 293 486 219 294 486 minecraft:light_gray_concrete
fill 219 293 488 219 294 488 minecraft:light_gray_concrete
fill 219 293 490 219 294 490 minecraft:light_gray_concrete
fill 219 293 492 219 294 492 minecraft:light_gray_concrete
fill 219 293 494 219 294 494 minecraft:light_gray_concrete
fill 219 293 496 219 294 496 minecraft:light_gray_concrete
fill 219 293 498 219 294 498 minecraft:light_gray_concrete
fill 220 293 487 220 294 487 minecraft:light_gray_concrete
fill 220 293 489 220 294 489 minecraft:light_gray_concrete
fill 220 293 491 220 294 491 minecraft:light_gray_concrete
fill 220 293 493 220 294 493 minecraft:light_gray_concrete
fill 220 293 495 220 294 495 minecraft:light_gray_concrete
fill 220 293 497 220 294 497 minecraft:light_gray_concrete
fill 221 293 486 221 294 486 minecraft:light_gray_concrete
fill 221 293 488 221 294 488 minecraft:light_gray_concrete
fill 221 293 490 221 294 490 minecraft:light_gray_concrete
fill 221 293 492 221 294 492 minecraft:light_gray_concrete
fill 221 293 494 221 294 494 minecraft:light_gray_concrete
fill 221 293 496 221 294 496 minecraft:light_gray_concrete
fill 221 293 498 221 294 498 minecraft:light_gray_concrete
fill 222 293 487 222 294 487 minecraft:light_gray_concrete
fill 222 293 489 222 294 489 minecraft:light_gray_concrete
fill 222 293 491 222 294 491 minecraft:light_gray_concrete
fill 222 293 493 222 294 493 minecraft:light_gray_concrete
fill 222 293 495 222 294 495 minecraft:light_gray_concrete
fill 222 293 497 222 294 497 minecraft:light_gray_concrete
setblock 223 293 466 minecraft:light[level=11]
setblock 223 293 474 minecraft:light[level=11]
setblock 223 293 482 minecraft:light[level=11]
fill 223 293 486 223 294 486 minecraft:light_gray_concrete
fill 223 293 488 223 294 488 minecraft:light_gray_concrete
fill 223 293 490 223 294 490 minecraft:light_gray_concrete
fill 223 293 492 223 294 492 minecraft:light_gray_concrete
fill 223 293 494 223 294 494 minecraft:light_gray_concrete
fill 223 293 496 223 294 496 minecraft:light_gray_concrete
fill 223 293 498 223 294 498 minecraft:light_gray_concrete
fill 224 293 487 224 294 487 minecraft:light_gray_concrete
fill 224 293 489 224 294 489 minecraft:light_gray_concrete
fill 224 293 491 224 294 491 minecraft:light_gray_concrete
fill 224 293 493 224 294 493 minecraft:light_gray_concrete
fill 224 293 495 224 294 495 minecraft:light_gray_concrete
fill 224 293 497 224 294 497 minecraft:light_gray_concrete
fill 225 293 486 225 294 486 minecraft:light_gray_concrete
fill 225 293 488 225 294 488 minecraft:light_gray_concrete
fill 225 293 490 225 294 490 minecraft:light_gray_concrete
fill 225 293 492 225 294 492 minecraft:light_gray_concrete
fill 225 293 494 225 294 494 minecraft:light_gray_concrete
fill 225 293 496 225 294 496 minecraft:light_gray_concrete
fill 225 293 498 225 294 498 minecraft:light_gray_concrete
fill 226 293 487 226 294 487 minecraft:light_gray_concrete
fill 226 293 489 226 294 489 minecraft:light_gray_concrete
fill 226 293 491 226 294 491 minecraft:light_gray_concrete
fill 226 293 493 226 294 493 minecraft:light_gray_concrete
fill 226 293 495 226 294 495 minecraft:light_gray_concrete
fill 226 293 497 226 294 497 minecraft:light_gray_concrete
fill 227 293 486 227 294 486 minecraft:light_gray_concrete
fill 227 293 488 227 294 488 minecraft:light_gray_concrete
fill 227 293 490 227 294 490 minecraft:light_gray_concrete
fill 227 293 492 227 294 492 minecraft:light_gray_concrete
fill 227 293 494 227 294 494 minecraft:light_gray_concrete
fill 227 293 496 227 294 496 minecraft:light_gray_concrete
fill 227 293 498 227 294 498 minecraft:light_gray_concrete
fill 228 293 487 228 294 487 minecraft:light_gray_concrete
fill 228 293 489 228 294 489 minecraft:light_gray_concrete
fill 228 293 491 228 294 491 minecraft:light_gray_concrete
fill 228 293 493 228 294 493 minecraft:light_gray_concrete
fill 228 293 495 228 294 495 minecraft:light_gray_concrete
fill 228 293 497 228 294 497 minecraft:light_gray_concrete
fill 229 293 486 229 294 486 minecraft:light_gray_concrete
fill 229 293 488 229 294 488 minecraft:light_gray_concrete
fill 229 293 490 229 294 490 minecraft:light_gray_concrete
fill 229 293 492 229 294 492 minecraft:light_gray_concrete
fill 229 293 494 229 294 494 minecraft:light_gray_concrete
fill 229 293 496 229 294 496 minecraft:light_gray_concrete
fill 229 293 498 229 294 498 minecraft:light_gray_concrete
fill 189 294 464 189 295 469 minecraft:light_gray_concrete
fill 189 294 472 190 294 477 minecraft:light_gray_concrete
fill 189 294 480 190 294 485 minecraft:light_gray_concrete
fill 189 294 488 190 294 493 minecraft:light_gray_concrete
fill 189 294 496 190 294 501 minecraft:light_gray_concrete
fill 189 294 504 194 295 504 minecraft:light_gray_concrete
fill 190 294 465 190 294 471 minecraft:light_gray_concrete
fill 190 294 478 190 294 479 minecraft:light_gray_concrete
fill 190 294 486 190 294 487 minecraft:light_gray_concrete
fill 190 294 494 190 294 495 minecraft:light_gray_concrete
fill 190 294 502 190 294 503 minecraft:light_gray_concrete
fill 191 294 465 198 294 465 minecraft:light_gray_concrete
fill 191 294 503 203 294 503 minecraft:light_gray_concrete
fill 192 294 464 197 295 464 minecraft:light_gray_concrete
fill 197 294 504 202 295 504 minecraft:light_gray_concrete
fill 206 294 465 228 294 465 minecraft:light_gray_concrete
fill 208 294 464 213 295 464 minecraft:light_gray_concrete
fill 211 294 503 229 294 503 minecraft:light_gray_concrete
fill 213 294 504 218 295 504 minecraft:light_gray_concrete
fill 216 294 464 221 295 464 minecraft:light_gray_concrete
fill 221 294 504 226 295 504 minecraft:light_gray_concrete
fill 224 294 464 229 295 464 minecraft:light_gray_concrete
fill 228 294 466 228 294 485 minecraft:light_gray_concrete
fill 228 294 499 229 294 502 minecraft:light_gray_concrete
fill 229 294 467 229 295 472 minecraft:light_gray_concrete
fill 229 294 475 229 295 480 minecraft:light_gray_concrete
fill 229 294 483 229 295 485 minecraft:light_gray_concrete
fill 229 294 504 229 295 504 minecraft:light_gray_concrete
fill 189 295 472 189 295 477 minecraft:light_gray_concrete
fill 189 295 480 189 295 485 minecraft:light_gray_concrete
fill 189 295 488 189 295 493 minecraft:light_gray_concrete
fill 189 295 496 189 295 501 minecraft:light_gray_concrete
setblock 199 295 464 minecraft:pearlescent_froglight
setblock 199 295 466 minecraft:pearlescent_froglight
setblock 199 295 468 minecraft:pearlescent_froglight
setblock 200 295 465 minecraft:pearlescent_froglight
setblock 200 295 467 minecraft:pearlescent_froglight
setblock 201 295 464 minecraft:pearlescent_froglight
setblock 201 295 466 minecraft:pearlescent_froglight
setblock 201 295 468 minecraft:pearlescent_froglight
setblock 202 295 465 minecraft:pearlescent_froglight
setblock 202 295 467 minecraft:pearlescent_froglight
setblock 203 295 464 minecraft:pearlescent_froglight
setblock 203 295 466 minecraft:pearlescent_froglight
setblock 203 295 468 minecraft:pearlescent_froglight
setblock 204 295 465 minecraft:pearlescent_froglight
setblock 204 295 467 minecraft:pearlescent_froglight
setblock 204 295 495 minecraft:pearlescent_froglight
setblock 204 295 497 minecraft:pearlescent_froglight
setblock 204 295 499 minecraft:pearlescent_froglight
setblock 204 295 501 minecraft:pearlescent_froglight
setblock 204 295 503 minecraft:pearlescent_froglight
setblock 205 295 464 minecraft:pearlescent_froglight
setblock 205 295 466 minecraft:pearlescent_froglight
setblock 205 295 468 minecraft:pearlescent_froglight
setblock 205 295 496 minecraft:pearlescent_froglight
setblock 205 295 498 minecraft:pearlescent_froglight
setblock 205 295 500 minecraft:pearlescent_froglight
setblock 205 295 502 minecraft:pearlescent_froglight
setblock 205 295 504 minecraft:pearlescent_froglight
setblock 206 295 495 minecraft:pearlescent_froglight
setblock 206 295 497 minecraft:pearlescent_froglight
setblock 206 295 499 minecraft:pearlescent_froglight
setblock 206 295 501 minecraft:pearlescent_froglight
setblock 206 295 503 minecraft:pearlescent_froglight
setblock 207 295 496 minecraft:pearlescent_froglight
setblock 207 295 498 minecraft:pearlescent_froglight
setblock 207 295 500 minecraft:pearlescent_froglight
setblock 207 295 502 minecraft:pearlescent_froglight
setblock 207 295 504 minecraft:pearlescent_froglight
setblock 208 295 495 minecraft:pearlescent_froglight
setblock 208 295 497 minecraft:pearlescent_froglight
setblock 208 295 499 minecraft:pearlescent_froglight
setblock 208 295 501 minecraft:pearlescent_froglight
setblock 208 295 503 minecraft:pearlescent_froglight
setblock 209 295 496 minecraft:pearlescent_froglight
setblock 209 295 498 minecraft:pearlescent_froglight
setblock 209 295 500 minecraft:pearlescent_froglight
setblock 209 295 502 minecraft:pearlescent_froglight
setblock 209 295 504 minecraft:pearlescent_froglight
setblock 210 295 495 minecraft:pearlescent_froglight
setblock 210 295 497 minecraft:pearlescent_froglight
setblock 210 295 499 minecraft:pearlescent_froglight
setblock 210 295 501 minecraft:pearlescent_froglight
setblock 210 295 503 minecraft:pearlescent_froglight
setblock 219 295 486 minecraft:pearlescent_froglight
setblock 219 295 488 minecraft:pearlescent_froglight
setblock 219 295 490 minecraft:pearlescent_froglight
setblock 219 295 492 minecraft:pearlescent_froglight
setblock 219 295 494 minecraft:pearlescent_froglight
setblock 219 295 496 minecraft:pearlescent_froglight
setblock 219 295 498 minecraft:pearlescent_froglight
setblock 220 295 487 minecraft:pearlescent_froglight
setblock 220 295 489 minecraft:pearlescent_froglight
setblock 220 295 491 minecraft:pearlescent_froglight
setblock 220 295 493 minecraft:pearlescent_froglight
setblock 220 295 495 minecraft:pearlescent_froglight
setblock 220 295 497 minecraft:pearlescent_froglight
setblock 221 295 486 minecraft:pearlescent_froglight
setblock 221 295 488 minecraft:pearlescent_froglight
setblock 221 295 490 minecraft:pearlescent_froglight
setblock 221 295 492 minecraft:pearlescent_froglight
setblock 221 295 494 minecraft:pearlescent_froglight
setblock 221 295 496 minecraft:pearlescent_froglight
setblock 221 295 498 minecraft:pearlescent_froglight
setblock 222 295 487 minecraft:pearlescent_froglight
setblock 222 295 489 minecraft:pearlescent_froglight
setblock 222 295 491 minecraft:pearlescent_froglight
setblock 222 295 493 minecraft:pearlescent_froglight
setblock 222 295 495 minecraft:pearlescent_froglight
setblock 222 295 497 minecraft:pearlescent_froglight
setblock 223 295 486 minecraft:pearlescent_froglight
setblock 223 295 488 minecraft:pearlescent_froglight
setblock 223 295 490 minecraft:pearlescent_froglight
setblock 223 295 492 minecraft:pearlescent_froglight
setblock 223 295 494 minecraft:pearlescent_froglight
setblock 223 295 496 minecraft:pearlescent_froglight
setblock 223 295 498 minecraft:pearlescent_froglight
setblock 224 295 487 minecraft:pearlescent_froglight
setblock 224 295 489 minecraft:pearlescent_froglight
setblock 224 295 491 minecraft:pearlescent_froglight
setblock 224 295 493 minecraft:pearlescent_froglight
setblock 224 295 495 minecraft:pearlescent_froglight
setblock 224 295 497 minecraft:pearlescent_froglight
setblock 225 295 486 minecraft:pearlescent_froglight
setblock 225 295 488 minecraft:pearlescent_froglight
setblock 225 295 490 minecraft:pearlescent_froglight
setblock 225 295 492 minecraft:pearlescent_froglight
setblock 225 295 494 minecraft:pearlescent_froglight
setblock 225 295 496 minecraft:pearlescent_froglight
setblock 225 295 498 minecraft:pearlescent_froglight
setblock 226 295 487 minecraft:pearlescent_froglight
setblock 226 295 489 minecraft:pearlescent_froglight
setblock 226 295 491 minecraft:pearlescent_froglight
setblock 226 295 493 minecraft:pearlescent_froglight
setblock 226 295 495 minecraft:pearlescent_froglight
setblock 226 295 497 minecraft:pearlescent_froglight
setblock 227 295 486 minecraft:pearlescent_froglight
setblock 227 295 488 minecraft:pearlescent_froglight
setblock 227 295 490 minecraft:pearlescent_froglight
setblock 227 295 492 minecraft:pearlescent_froglight
setblock 227 295 494 minecraft:pearlescent_froglight
setblock 227 295 496 minecraft:pearlescent_froglight
setblock 227 295 498 minecraft:pearlescent_froglight
setblock 228 295 487 minecraft:pearlescent_froglight
setblock 228 295 489 minecraft:pearlescent_froglight
setblock 228 295 491 minecraft:pearlescent_froglight
setblock 228 295 493 minecraft:pearlescent_froglight
setblock 228 295 495 minecraft:pearlescent_froglight
setblock 228 295 497 minecraft:pearlescent_froglight
setblock 229 295 486 minecraft:pearlescent_froglight
setblock 229 295 488 minecraft:pearlescent_froglight
setblock 229 295 490 minecraft:pearlescent_froglight
setblock 229 295 492 minecraft:pearlescent_froglight
setblock 229 295 494 minecraft:pearlescent_froglight
setblock 229 295 496 minecraft:pearlescent_froglight
setblock 229 295 498 minecraft:pearlescent_froglight
fill 229 295 499 229 295 503 minecraft:light_gray_concrete
fill 199 296 464 199 297 464 minecraft:light_gray_concrete
fill 199 296 466 199 297 466 minecraft:light_gray_concrete
fill 199 296 468 199 297 468 minecraft:light_gray_concrete
fill 200 296 465 200 297 465 minecraft:light_gray_concrete
fill 200 296 467 200 297 467 minecraft:light_gray_concrete
fill 201 296 464 201 297 464 minecraft:light_gray_concrete
fill 201 296 466 201 297 466 minecraft:light_gray_concrete
fill 201 296 468 201 297 468 minecraft:light_gray_concrete
fill 202 296 465 202 297 465 minecraft:light_gray_concrete
fill 202 296 467 202 297 467 minecraft:light_gray_concrete
fill 203 296 464 203 297 464 minecraft:light_gray_concrete
fill 203 296 466 203 297 466 minecraft:light_gray_concrete
fill 203 296 468 203 297 468 minecraft:light_gray_concrete
fill 204 296 465 204 297 465 minecraft:light_gray_concrete
fill 204 296 467 204 297 467 minecraft:light_gray_concrete
fill 204 296 495 204 297 495 minecraft:light_gray_concrete
fill 204 296 497 204 297 497 minecraft:light_gray_concrete
fill 204 296 499 204 297 499 minecraft:light_gray_concrete
fill 204 296 501 204 297 501 minecraft:light_gray_concrete
fill 204 296 503 204 297 503 minecraft:light_gray_concrete
fill 205 296 464 205 297 464 minecraft:light_gray_concrete
fill 205 296 466 205 297 466 minecraft:light_gray_concrete
fill 205 296 468 205 297 468 minecraft:light_gray_concrete
fill 205 296 496 205 297 496 minecraft:light_gray_concrete
fill 205 296 498 205 297 498 minecraft:light_gray_concrete
fill 205 296 500 205 297 500 minecraft:light_gray_concrete
fill 205 296 502 205 297 502 minecraft:light_gray_concrete
fill 205 296 504 205 297 504 minecraft:light_gray_concrete
fill 206 296 495 206 297 495 minecraft:light_gray_concrete
fill 206 296 497 206 297 497 minecraft:light_gray_concrete
fill 206 296 499 206 297 499 minecraft:light_gray_concrete
fill 206 296 501 206 297 501 minecraft:light_gray_concrete
fill 206 296 503 206 297 503 minecraft:light_gray_concrete
fill 207 296 496 207 297 496 minecraft:light_gray_concrete
fill 207 296 498 207 297 498 minecraft:light_gray_concrete
fill 207 296 500 207 297 500 minecraft:light_gray_concrete
fill 207 296 502 207 297 502 minecraft:light_gray_concrete
fill 207 296 504 207 297 504 minecraft:light_gray_concrete
fill 208 296 495 208 297 495 minecraft:light_gray_concrete
fill 208 296 497 208 297 497 minecraft:light_gray_concrete
fill 208 296 499 208 297 499 minecraft:light_gray_concrete
fill 208 296 501 208 297 501 minecraft:light_gray_concrete
fill 208 296 503 208 297 503 minecraft:light_gray_concrete
fill 209 296 496 209 297 496 minecraft:light_gray_concrete
fill 209 296 498 209 297 498 minecraft:light_gray_concrete
fill 209 296 500 209 297 500 minecraft:light_gray_concrete
fill 209 296 502 209 297 502 minecraft:light_gray_concrete
fill 209 296 504 209 297 504 minecraft:light_gray_concrete
fill 210 296 495 210 297 495 minecraft:light_gray_concrete
fill 210 296 497 210 297 497 minecraft:light_gray_concrete
fill 210 296 499 210 297 499 minecraft:light_gray_concrete
fill 210 296 501 210 297 501 minecraft:light_gray_concrete
fill 210 296 503 210 297 503 minecraft:light_gray_concrete
fill 219 296 486 219 297 486 minecraft:light_gray_concrete
fill 219 296 488 219 297 488 minecraft:light_gray_concrete
fill 219 296 490 219 297 490 minecraft:light_gray_concrete
fill 219 296 492 219 297 492 minecraft:light_gray_concrete
fill 219 296 494 219 297 494 minecraft:light_gray_concrete
fill 219 296 496 219 297 496 minecraft:light_gray_concrete
fill 219 296 498 219 297 498 minecraft:light_gray_concrete
fill 220 296 487 220 297 487 minecraft:light_gray_concrete
fill 220 296 489 220 297 489 minecraft:light_gray_concrete
fill 220 296 491 220 297 491 minecraft:light_gray_concrete
fill 220 296 493 220 297 493 minecraft:light_gray_concrete
fill 220 296 495 220 297 495 minecraft:light_gray_concrete
fill 220 296 497 220 297 497 minecraft:light_gray_concrete
fill 221 296 486 221 297 486 minecraft:light_gray_concrete
fill 221 296 488 221 297 488 minecraft:light_gray_concrete
fill 221 296 490 221 297 490 minecraft:light_gray_concrete
fill 221 296 492 221 297 492 minecraft:light_gray_concrete
fill 221 296 494 221 297 494 minecraft:light_gray_concrete
fill 221 296 496 221 297 496 minecraft:light_gray_concrete
fill 221 296 498 221 297 498 minecraft:light_gray_concrete
fill 222 296 487 222 297 487 minecraft:light_gray_concrete
fill 222 296 489 222 297 489 minecraft:light_gray_concrete
fill 222 296 491 222 297 491 minecraft:light_gray_concrete
fill 222 296 493 222 297 493 minecraft:light_gray_concrete
fill 222 296 495 222 297 495 minecraft:light_gray_concrete
fill 222 296 497 222 297 497 minecraft:light_gray_concrete
fill 223 296 486 223 297 486 minecraft:light_gray_concrete
fill 223 296 488 223 297 488 minecraft:light_gray_concrete
fill 223 296 490 223 297 490 minecraft:light_gray_concrete
fill 223 296 492 223 297 492 minecraft:light_gray_concrete
fill 223 296 494 223 297 494 minecraft:light_gray_concrete
fill 223 296 496 223 297 496 minecraft:light_gray_concrete
fill 223 296 498 223 297 498 minecraft:light_gray_concrete
fill 224 296 487 224 297 487 minecraft:light_gray_concrete
fill 224 296 489 224 297 489 minecraft:light_gray_concrete
fill 224 296 491 224 297 491 minecraft:light_gray_concrete
fill 224 296 493 224 297 493 minecraft:light_gray_concrete
fill 224 296 495 224 297 495 minecraft:light_gray_concrete
fill 224 296 497 224 297 497 minecraft:light_gray_concrete
fill 225 296 486 225 297 486 minecraft:light_gray_concrete
fill 225 296 488 225 297 488 minecraft:light_gray_concrete
fill 225 296 490 225 297 490 minecraft:light_gray_concrete
fill 225 296 492 225 297 492 minecraft:light_gray_concrete
fill 225 296 494 225 297 494 minecraft:light_gray_concrete
fill 225 296 496 225 297 496 minecraft:light_gray_concrete
fill 225 296 498 225 297 498 minecraft:light_gray_concrete
fill 226 296 487 226 297 487 minecraft:light_gray_concrete
fill 226 296 489 226 297 489 minecraft:light_gray_concrete
fill 226 296 491 226 297 491 minecraft:light_gray_concrete
fill 226 296 493 226 297 493 minecraft:light_gray_concrete
fill 226 296 495 226 297 495 minecraft:light_gray_concrete
fill 226 296 497 226 297 497 minecraft:light_gray_concrete
fill 227 296 486 227 297 486 minecraft:light_gray_concrete
fill 227 296 488 227 297 488 minecraft:light_gray_concrete
fill 227 296 490 227 297 490 minecraft:light_gray_concrete
fill 227 296 492 227 297 492 minecraft:light_gray_concrete
fill 227 296 494 227 297 494 minecraft:light_gray_concrete
fill 227 296 496 227 297 496 minecraft:light_gray_concrete
fill 227 296 498 227 297 498 minecraft:light_gray_concrete
fill 228 296 487 228 297 487 minecraft:light_gray_concrete
fill 228 296 489 228 297 489 minecraft:light_gray_concrete
fill 228 296 491 228 297 491 minecraft:light_gray_concrete
fill 228 296 493 228 297 493 minecraft:light_gray_concrete
fill 228 296 495 228 297 495 minecraft:light_gray_concrete
fill 228 296 497 228 297 497 minecraft:light_gray_concrete
fill 229 296 486 229 297 486 minecraft:light_gray_concrete
fill 229 296 488 229 297 488 minecraft:light_gray_concrete
fill 229 296 490 229 300 490 minecraft:light_gray_concrete
fill 229 296 492 229 297 492 minecraft:light_gray_concrete
fill 229 296 494 229 297 494 minecraft:light_gray_concrete
fill 229 296 496 229 297 496 minecraft:light_gray_concrete
fill 229 296 498 229 300 498 minecraft:light_gray_concrete
fill 188 298 468 188 300 468 minecraft:pearlescent_froglight
fill 188 298 476 188 300 476 minecraft:pearlescent_froglight
fill 188 298 484 188 300 484 minecraft:pearlescent_froglight
fill 188 298 492 188 300 492 minecraft:pearlescent_froglight
fill 188 298 500 188 300 500 minecraft:pearlescent_froglight
fill 191 298 505 191 300 505 minecraft:pearlescent_froglight
fill 195 298 463 195 300 463 minecraft:pearlescent_froglight
setblock 199 298 464 minecraft:pearlescent_froglight
setblock 199 298 466 minecraft:pearlescent_froglight
setblock 199 298 468 minecraft:pearlescent_froglight
fill 199 298 505 199 300 505 minecraft:pearlescent_froglight
setblock 200 298 465 minecraft:pearlescent_froglight
setblock 200 298 467 minecraft:pearlescent_froglight
setblock 201 298 464 minecraft:pearlescent_froglight
setblock 201 298 466 minecraft:pearlescent_froglight
setblock 201 298 468 minecraft:pearlescent_froglight
setblock 202 298 465 minecraft:pearlescent_froglight
setblock 202 298 467 minecraft:pearlescent_froglight
fill 203 298 463 203 298 464 minecraft:pearlescent_froglight
setblock 203 298 466 minecraft:pearlescent_froglight
setblock 203 298 468 minecraft:pearlescent_froglight
setblock 204 298 465 minecraft:pearlescent_froglight
setblock 204 298 467 minecraft:pearlescent_froglight
setblock 204 298 495 minecraft:pearlescent_froglight
setblock 204 298 497 minecraft:pearlescent_froglight
setblock 204 298 499 minecraft:pearlescent_froglight
setblock 204 298 501 minecraft:pearlescent_froglight
setblock 204 298 503 minecraft:pearlescent_froglight
setblock 205 298 464 minecraft:pearlescent_froglight
setblock 205 298 466 minecraft:pearlescent_froglight
setblock 205 298 468 minecraft:pearlescent_froglight
setblock 205 298 496 minecraft:pearlescent_froglight
setblock 205 298 498 minecraft:pearlescent_froglight
setblock 205 298 500 minecraft:pearlescent_froglight
setblock 205 298 502 minecraft:pearlescent_froglight
setblock 205 298 504 minecraft:pearlescent_froglight
setblock 206 298 495 minecraft:pearlescent_froglight
setblock 206 298 497 minecraft:pearlescent_froglight
setblock 206 298 499 minecraft:pearlescent_froglight
setblock 206 298 501 minecraft:pearlescent_froglight
setblock 206 298 503 minecraft:pearlescent_froglight
setblock 207 298 496 minecraft:pearlescent_froglight
setblock 207 298 498 minecraft:pearlescent_froglight
setblock 207 298 500 minecraft:pearlescent_froglight
setblock 207 298 502 minecraft:pearlescent_froglight
fill 207 298 504 207 298 505 minecraft:pearlescent_froglight
setblock 208 298 495 minecraft:pearlescent_froglight
setblock 208 298 497 minecraft:pearlescent_froglight
setblock 208 298 499 minecraft:pearlescent_froglight
setblock 208 298 501 minecraft:pearlescent_froglight
setblock 208 298 503 minecraft:pearlescent_froglight
setblock 209 298 496 minecraft:pearlescent_froglight
setblock 209 298 498 minecraft:pearlescent_froglight
setblock 209 298 500 minecraft:pearlescent_froglight
setblock 209 298 502 minecraft:pearlescent_froglight
setblock 209 298 504 minecraft:pearlescent_froglight
setblock 210 298 495 minecraft:pearlescent_froglight
setblock 210 298 497 minecraft:pearlescent_froglight
setblock 210 298 499 minecraft:pearlescent_froglight
setblock 210 298 501 minecraft:pearlescent_froglight
setblock 210 298 503 minecraft:pearlescent_froglight
fill 211 298 463 211 300 463 minecraft:pearlescent_froglight
fill 215 298 505 215 300 505 minecraft:pearlescent_froglight
fill 219 298 463 219 300 463 minecraft:pearlescent_froglight
fill 223 298 505 223 300 505 minecraft:pearlescent_froglight
fill 227 298 463 227 300 463 minecraft:pearlescent_froglight
fill 230 298 468 230 300 468 minecraft:pearlescent_froglight
fill 230 298 476 230 300 476 minecraft:pearlescent_froglight
fill 230 298 484 230 300 484 minecraft:pearlescent_froglight
fill 230 298 492 230 300 492 minecraft:pearlescent_froglight
fill 230 298 500 230 300 500 minecraft:pearlescent_froglight
fill 199 299 464 199 300 464 minecraft:light_gray_concrete
fill 199 299 466 199 300 466 minecraft:light_gray_concrete
fill 199 299 468 199 300 468 minecraft:light_gray_concrete
fill 200 299 465 200 300 465 minecraft:light_gray_concrete
fill 200 299 467 200 300 467 minecraft:light_gray_concrete
fill 201 299 464 201 300 464 minecraft:light_gray_concrete
fill 201 299 466 201 300 466 minecraft:light_gray_concrete
fill 201 299 468 201 300 468 minecraft:light_gray_concrete
fill 202 299 465 202 300 465 minecraft:light_gray_concrete
fill 202 299 467 202 300 467 minecraft:light_gray_concrete
fill 203 299 463 203 300 463 minecraft:pearlescent_froglight
fill 203 299 464 203 300 464 minecraft:light_gray_concrete
fill 203 299 466 203 300 466 minecraft:light_gray_concrete
fill 203 299 468 203 300 468 minecraft:light_gray_concrete
fill 204 299 465 204 300 465 minecraft:light_gray_concrete
fill 204 299 467 204 300 467 minecraft:light_gray_concrete
fill 204 299 495 204 300 495 minecraft:light_gray_concrete
fill 204 299 497 204 300 497 minecraft:light_gray_concrete
fill 204 299 499 204 300 499 minecraft:light_gray_concrete
fill 204 299 501 204 300 501 minecraft:light_gray_concrete
fill 204 299 503 204 300 503 minecraft:light_gray_concrete
fill 205 299 464 205 300 464 minecraft:light_gray_concrete
fill 205 299 466 205 300 466 minecraft:light_gray_concrete
fill 205 299 468 205 300 468 minecraft:light_gray_concrete
fill 205 299 496 205 300 496 minecraft:light_gray_concrete
fill 205 299 498 205 300 498 minecraft:light_gray_concrete
fill 205 299 500 205 300 500 minecraft:light_gray_concrete
fill 205 299 502 205 300 502 minecraft:light_gray_concrete
fill 205 299 504 205 300 504 minecraft:light_gray_concrete
fill 206 299 495 206 300 495 minecraft:light_gray_concrete
fill 206 299 497 206 300 497 minecraft:light_gray_concrete
fill 206 299 499 206 300 499 minecraft:light_gray_concrete
fill 206 299 501 206 300 501 minecraft:light_gray_concrete
fill 206 299 503 206 300 503 minecraft:light_gray_concrete
fill 207 299 496 207 300 496 minecraft:light_gray_concrete
fill 207 299 498 207 300 498 minecraft:light_gray_concrete
fill 207 299 500 207 300 500 minecraft:light_gray_concrete
fill 207 299 502 207 300 502 minecraft:light_gray_concrete
fill 207 299 504 207 300 504 minecraft:light_gray_concrete
fill 207 299 505 207 300 505 minecraft:pearlescent_froglight
fill 208 299 495 208 300 495 minecraft:light_gray_concrete
fill 208 299 497 208 300 497 minecraft:light_gray_concrete
fill 208 299 499 208 300 499 minecraft:light_gray_concrete
fill 208 299 501 208 300 501 minecraft:light_gray_concrete
fill 208 299 503 208 300 503 minecraft:light_gray_concrete
fill 209 299 496 209 300 496 minecraft:light_gray_concrete
fill 209 299 498 209 300 498 minecraft:light_gray_concrete
fill 209 299 500 209 300 500 minecraft:light_gray_concrete
fill 209 299 502 209 300 502 minecraft:light_gray_concrete
fill 209 299 504 209 300 504 minecraft:light_gray_concrete
fill 210 299 495 210 300 495 minecraft:light_gray_concrete
fill 210 299 497 210 300 497 minecraft:light_gray_concrete
fill 210 299 499 210 300 499 minecraft:light_gray_concrete
fill 210 299 501 210 300 501 minecraft:light_gray_concrete
fill 210 299 503 210 300 503 minecraft:light_gray_concrete
fill 188 301 468 188 307 468 minecraft:white_terracotta
fill 188 301 476 188 307 476 minecraft:white_terracotta
fill 188 301 484 188 307 484 minecraft:white_terracotta
fill 188 301 492 188 307 492 minecraft:white_terracotta
fill 188 301 500 188 307 500 minecraft:white_terracotta
setblock 191 301 466 minecraft:light[level=11]
setblock 191 301 474 minecraft:light[level=11]
setblock 191 301 482 minecraft:light[level=11]
setblock 191 301 490 minecraft:light[level=11]
setblock 191 301 498 minecraft:light[level=11]
fill 191 301 505 191 307 505 minecraft:white_terracotta
fill 195 301 463 195 307 463 minecraft:white_terracotta
setblock 199 301 466 minecraft:light[level=11]
setblock 199 301 474 minecraft:light[level=11]
setblock 199 301 482 minecraft:light[level=11]
setblock 199 301 490 minecraft:light[level=11]
setblock 199 301 498 minecraft:light[level=11]
fill 199 301 505 199 307 505 minecraft:white_terracotta
fill 203 301 463 203 307 463 minecraft:white_terracotta
setblock 207 301 466 minecraft:light[level=11]
setblock 207 301 474 minecraft:light[level=11]
setblock 207 301 482 minecraft:light[level=11]
setblock 207 301 490 minecraft:light[level=11]
setblock 207 301 498 minecraft:light[level=11]
fill 207 301 505 207 307 505 minecraft:white_terracotta
fill 211 301 463 211 307 463 minecraft:white_terracotta
setblock 215 301 466 minecraft:light[level=11]
setblock 215 301 474 minecraft:light[level=11]
setblock 215 301 482 minecraft:light[level=11]
setblock 215 301 490 minecraft:light[level=11]
setblock 215 301 498 minecraft:light[level=11]
fill 215 301 505 215 307 505 minecraft:white_terracotta
fill 219 301 463 219 307 463 minecraft:white_terracotta
setblock 223 301 466 minecraft:light[level=11]
setblock 223 301 474 minecraft:light[level=11]
setblock 223 301 482 minecraft:light[level=11]
setblock 223 301 490 minecraft:light[level=11]
setblock 223 301 498 minecraft:light[level=11]
fill 223 301 505 223 307 505 minecraft:white_terracotta
fill 227 301 463 227 307 463 minecraft:white_terracotta
fill 230 301 468 230 307 468 minecraft:white_terracotta
fill 230 301 476 230 307 476 minecraft:white_terracotta
fill 230 301 484 230 307 484 minecraft:white_terracotta
fill 230 301 492 230 307 492 minecraft:white_terracotta
fill 230 301 500 230 307 500 minecraft:white_terracotta
