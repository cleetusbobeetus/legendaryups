fill 214 235 252 216 235 252 minecraft:pink_terracotta
fill 215 235 237 229 235 237 minecraft:light_gray_concrete
fill 215 235 243 216 235 243 minecraft:pink_concrete
setblock 215 235 245 minecraft:shroomlight
fill 215 235 247 216 235 247 minecraft:pink_concrete
fill 215 235 253 229 235 253 minecraft:light_gray_concrete
fill 216 235 239 217 235 239 minecraft:pink_terracotta
fill 216 235 244 216 235 246 minecraft:pink_concrete
fill 216 235 251 217 235 251 minecraft:pink_terracotta
fill 217 235 238 229 235 238 minecraft:light_gray_concrete
fill 217 235 252 229 235 252 minecraft:light_gray_concrete
fill 218 235 239 229 235 239 minecraft:light_gray_concrete
fill 218 235 240 218 235 241 minecraft:pink_terracotta
fill 218 235 249 218 235 250 minecraft:pink_terracotta
fill 218 235 251 229 235 251 minecraft:light_gray_concrete
fill 219 235 240 229 235 240 minecraft:light_gray_concrete
fill 219 235 241 219 235 243 minecraft:pink_terracotta
fill 219 235 247 219 235 249 minecraft:pink_terracotta
fill 219 235 250 229 235 250 minecraft:light_gray_concrete
fill 220 235 241 229 235 242 minecraft:light_gray_concrete
fill 220 235 243 220 235 247 minecraft:pink_terracotta
fill 220 235 248 229 235 249 minecraft:light_gray_concrete
fill 221 235 243 229 235 247 minecraft:light_gray_concrete
fill 203 236 229 203 236 241 minecraft:light_gray_concrete
fill 203 236 242 203 236 248 minecraft:pink_terracotta
fill 204 236 229 204 236 239 minecraft:light_gray_concrete
fill 204 236 240 204 236 242 minecraft:pink_terracotta
fill 204 236 248 204 236 250 minecraft:pink_terracotta
fill 204 236 251 204 236 269 minecraft:light_gray_concrete
fill 205 236 229 205 236 238 minecraft:light_gray_concrete
fill 205 236 239 205 236 240 minecraft:pink_terracotta
setblock 205 236 245 minecraft:light[level=15]
fill 205 236 250 205 236 251 minecraft:pink_terracotta
fill 205 236 252 205 236 269 minecraft:light_gray_concrete
fill 206 236 229 206 236 237 minecraft:light_gray_concrete
fill 206 236 238 206 236 239 minecraft:pink_terracotta
fill 206 236 251 206 236 252 minecraft:pink_terracotta
fill 206 236 253 206 236 269 minecraft:light_gray_concrete
fill 207 236 229 208 236 236 minecraft:light_gray_concrete
fill 207 236 237 207 236 238 minecraft:pink_terracotta
fill 207 236 252 207 236 253 minecraft:pink_terracotta
fill 207 236 254 208 236 269 minecraft:light_gray_concrete
fill 208 236 237 209 236 237 minecraft:pink_terracotta
fill 208 236 253 209 236 253 minecraft:pink_terracotta
fill 209 236 229 229 236 235 minecraft:light_gray_concrete
fill 209 236 236 215 236 236 minecraft:pink_terracotta
fill 209 236 254 215 236 254 minecraft:pink_terracotta
fill 209 236 255 229 236 269 minecraft:light_gray_concrete
setblock 212 236 238 minecraft:light[level=15]
setblock 212 236 252 minecraft:light[level=15]
fill 215 236 237 217 236 237 minecraft:pink_terracotta
fill 215 236 253 217 236 253 minecraft:pink_terracotta
fill 216 236 236 229 236 236 minecraft:light_gray_concrete
fill 216 236 254 229 236 254 minecraft:light_gray_concrete
fill 217 236 238 218 236 238 minecraft:pink_terracotta
fill 217 236 252 218 236 252 minecraft:pink_terracotta
fill 218 236 237 229 236 237 minecraft:light_gray_concrete
fill 218 236 239 219 236 239 minecraft:pink_terracotta
fill 218 236 251 219 236 251 minecraft:pink_terracotta
fill 218 236 253 229 236 253 minecraft:light_gray_concrete
fill 219 236 238 229 236 238 minecraft:light_gray_concrete
fill 219 236 240 220 236 240 minecraft:pink_terracotta
setblock 219 236 245 minecraft:light[level=15]
fill 219 236 250 220 236 250 minecraft:pink_terracotta
fill 219 236 252 229 236 252 minecraft:light_gray_concrete
fill 220 236 239 229 236 239 minecraft:light_gray_concrete
fill 220 236 241 220 236 242 minecraft:pink_terracotta
fill 220 236 248 220 236 249 minecraft:pink_terracotta
fill 220 236 251 229 236 251 minecraft:light_gray_concrete
fill 221 236 240 229 236 241 minecraft:light_gray_concrete
fill 221 236 242 221 236 248 minecraft:pink_terracotta
fill 221 236 249 229 236 250 minecraft:light_gray_concrete
fill 222 236 242 229 236 248 minecraft:light_gray_concrete
fill 189 237 229 200 237 269 minecraft:light_gray_concrete
fill 201 237 229 201 237 243 minecraft:light_gray_concrete
fill 201 237 244 202 237 246 minecraft:pink_terracotta
fill 201 237 247 201 237 269 minecraft:light_gray_concrete
fill 202 237 229 202 237 240 minecraft:light_gray_concrete
fill 202 237 241 202 237 243 minecraft:pink_terracotta
fill 202 237 247 202 237 249 minecraft:pink_terracotta
fill 202 237 250 202 237 269 minecraft:light_gray_concrete
fill 203 237 229 203 237 238 minecraft:light_gray_concrete
fill 203 237 239 203 237 241 minecraft:pink_terracotta
fill 203 237 249 203 237 251 minecraft:pink_terracotta
fill 203 237 252 203 237 269 minecraft:light_gray_concrete
fill 204 237 229 204 237 237 minecraft:light_gray_concrete
fill 204 237 238 204 237 239 minecraft:pink_terracotta
fill 204 237 251 204 237 252 minecraft:pink_terracotta
fill 204 237 253 204 237 269 minecraft:light_gray_concrete
fill 205 237 229 205 237 236 minecraft:light_gray_concrete
fill 205 237 237 205 237 238 minecraft:pink_terracotta
fill 205 237 252 205 237 253 minecraft:pink_terracotta
fill 205 237 254 205 237 269 minecraft:light_gray_concrete
fill 206 237 229 207 237 235 minecraft:light_gray_concrete
fill 206 237 236 206 237 237 minecraft:pink_terracotta
fill 206 237 253 206 237 254 minecraft:pink_terracotta
fill 206 237 255 207 237 269 minecraft:light_gray_concrete
fill 207 237 236 208 237 236 minecraft:pink_terracotta
fill 207 237 254 208 237 254 minecraft:pink_terracotta
fill 208 237 229 210 237 234 minecraft:light_gray_concrete
fill 208 237 235 216 237 235 minecraft:pink_terracotta
fill 208 237 255 216 237 255 minecraft:pink_terracotta
fill 208 237 256 210 237 269 minecraft:light_gray_concrete
fill 211 237 229 229 237 233 minecraft:light_gray_concrete
fill 211 237 234 213 237 234 minecraft:pink_terracotta
fill 211 237 256 213 237 256 minecraft:pink_terracotta
fill 211 237 257 229 237 269 minecraft:light_gray_concrete
fill 214 237 234 229 237 234 minecraft:light_gray_concrete
fill 214 237 256 229 237 256 minecraft:light_gray_concrete
fill 216 237 236 218 237 236 minecraft:pink_terracotta
fill 216 237 254 218 237 254 minecraft:pink_terracotta
fill 217 237 235 229 237 235 minecraft:light_gray_concrete
fill 217 237 255 229 237 255 minecraft:light_gray_concrete
fill 218 237 237 219 237 237 minecraft:pink_terracotta
fill 218 237 253 219 237 253 minecraft:pink_terracotta
fill 219 237 236 229 237 236 minecraft:light_gray_concrete
fill 219 237 238 220 237 238 minecraft:pink_terracotta
fill 219 237 252 220 237 252 minecraft:pink_terracotta
fill 219 237 254 229 237 254 minecraft:light_gray_concrete
fill 220 237 237 229 237 237 minecraft:light_gray_concrete
fill 220 237 239 221 237 239 minecraft:pink_terracotta
fill 220 237 251 221 237 251 minecraft:pink_terracotta
fill 220 237 253 229 237 253 minecraft:light_gray_concrete
fill 221 237 238 229 237 238 minecraft:light_gray_concrete
fill 221 237 240 221 237 241 minecraft:pink_terracotta
fill 221 237 249 221 237 250 minecraft:pink_terracotta
fill 221 237 252 229 237 252 minecraft:light_gray_concrete
fill 222 237 239 229 237 240 minecraft:light_gray_concrete
fill 222 237 241 222 237 249 minecraft:pink_terracotta
fill 222 237 250 229 237 251 minecraft:light_gray_concrete
fill 223 237 241 229 237 243 minecraft:light_gray_concrete
fill 223 237 244 223 237 246 minecraft:pink_terracotta
fill 223 237 247 229 237 249 minecraft:light_gray_concrete
fill 224 237 244 229 237 246 minecraft:light_gray_concrete
fill 189 238 229 199 238 269 minecraft:light_gray_concrete
fill 200 238 229 200 238 242 minecraft:light_gray_concrete
fill 200 238 243 200 238 247 minecraft:pink_terracotta
fill 200 238 248 200 238 269 minecraft:light_gray_concrete
fill 201 238 229 201 238 239 minecraft:light_gray_concrete
fill 201 238 240 201 238 243 minecraft:pink_terracotta
fill 201 238 247 201 238 250 minecraft:pink_terracotta
fill 201 238 251 201 238 269 minecraft:light_gray_concrete
fill 202 238 229 202 238 237 minecraft:light_gray_concrete
fill 202 238 238 202 238 240 minecraft:pink_terracotta
fill 202 238 250 202 238 252 minecraft:pink_terracotta
fill 202 238 253 202 238 269 minecraft:light_gray_concrete
fill 203 238 229 203 238 236 minecraft:light_gray_concrete
fill 203 238 237 203 238 238 minecraft:pink_terracotta
fill 203 238 252 203 238 253 minecraft:pink_terracotta
fill 203 238 254 203 238 269 minecraft:light_gray_concrete
fill 204 238 229 204 238 235 minecraft:light_gray_concrete
fill 204 238 236 204 238 237 minecraft:pink_terracotta
fill 204 238 253 204 238 254 minecraft:pink_terracotta
fill 204 238 255 204 238 269 minecraft:light_gray_concrete
fill 205 238 229 206 238 234 minecraft:light_gray_concrete
fill 205 238 235 205 238 236 minecraft:pink_terracotta
fill 205 238 254 205 238 255 minecraft:pink_terracotta
fill 205 238 256 206 238 269 minecraft:light_gray_concrete
fill 206 238 235 207 238 235 minecraft:pink_terracotta
fill 206 238 255 207 238 255 minecraft:pink_terracotta
fill 207 238 229 209 238 233 minecraft:light_gray_concrete
fill 207 238 234 210 238 234 minecraft:pink_terracotta
fill 207 238 256 210 238 256 minecraft:pink_terracotta
fill 207 238 257 209 238 269 minecraft:light_gray_concrete
fill 210 238 229 229 238 232 minecraft:light_gray_concrete
fill 210 238 233 214 238 233 minecraft:pink_terracotta
fill 210 238 257 214 238 257 minecraft:pink_terracotta
fill 210 238 258 229 238 269 minecraft:light_gray_concrete
fill 214 238 234 217 238 234 minecraft:pink_terracotta
fill 214 238 256 217 238 256 minecraft:pink_terracotta
fill 215 238 233 229 238 233 minecraft:light_gray_concrete
fill 215 238 257 229 238 257 minecraft:light_gray_concrete
fill 217 238 235 219 238 235 minecraft:pink_terracotta
fill 217 238 255 219 238 255 minecraft:pink_terracotta
fill 218 238 234 229 238 234 minecraft:light_gray_concrete
fill 218 238 256 229 238 256 minecraft:light_gray_concrete
fill 219 238 236 220 238 236 minecraft:pink_terracotta
fill 219 238 254 220 238 254 minecraft:pink_terracotta
fill 220 238 235 229 238 235 minecraft:light_gray_concrete
fill 220 238 237 221 238 237 minecraft:pink_terracotta
fill 220 238 253 221 238 253 minecraft:pink_terracotta
fill 220 238 255 229 238 255 minecraft:light_gray_concrete
fill 221 238 236 229 238 236 minecraft:light_gray_concrete
fill 221 238 238 222 238 238 minecraft:pink_terracotta
fill 221 238 252 222 238 252 minecraft:pink_terracotta
fill 221 238 254 229 238 254 minecraft:light_gray_concrete
fill 222 238 237 229 238 237 minecraft:light_gray_concrete
fill 222 238 239 222 238 240 minecraft:pink_terracotta
fill 222 238 250 222 238 251 minecraft:pink_terracotta
fill 222 238 253 229 238 253 minecraft:light_gray_concrete
fill 223 238 238 229 238 239 minecraft:light_gray_concrete
fill 223 238 240 223 238 243 minecraft:pink_terracotta
fill 223 238 247 223 238 250 minecraft:pink_terracotta
fill 223 238 251 229 238 252 minecraft:light_gray_concrete
fill 224 238 240 229 238 242 minecraft:light_gray_concrete
fill 224 238 243 224 238 247 minecraft:pink_terracotta
fill 224 238 248 229 238 250 minecraft:light_gray_concrete
fill 225 238 243 229 238 247 minecraft:light_gray_concrete
fill 189 239 229 198 239 269 minecraft:light_gray_concrete
fill 199 239 229 199 239 240 minecraft:light_gray_concrete
fill 199 239 241 199 239 249 minecraft:pink_terracotta
fill 199 239 250 199 239 269 minecraft:light_gray_concrete
fill 200 239 229 200 239 238 minecraft:light_gray_concrete
fill 200 239 239 200 239 242 minecraft:pink_terracotta
fill 200 239 248 200 239 251 minecraft:pink_terracotta
fill 200 239 252 200 239 269 minecraft:light_gray_concrete
fill 201 239 229 201 239 236 minecraft:light_gray_concrete
fill 201 239 237 201 239 239 minecraft:pink_terracotta
fill 201 239 251 201 239 253 minecraft:pink_terracotta
fill 201 239 254 201 239 269 minecraft:light_gray_concrete
fill 202 239 229 202 239 235 minecraft:light_gray_concrete
fill 202 239 236 202 239 237 minecraft:pink_terracotta
fill 202 239 253 202 239 254 minecraft:pink_terracotta
fill 202 239 255 202 239 269 minecraft:light_gray_concrete
fill 203 239 229 203 239 234 minecraft:light_gray_concrete
fill 203 239 235 203 239 236 minecraft:pink_terracotta
fill 203 239 254 203 239 255 minecraft:pink_terracotta
fill 203 239 256 203 239 269 minecraft:light_gray_concrete
fill 204 239 229 205 239 233 minecraft:light_gray_concrete
fill 204 239 234 204 239 235 minecraft:pink_terracotta
fill 204 239 255 204 239 256 minecraft:pink_terracotta
fill 204 239 257 205 239 269 minecraft:light_gray_concrete
fill 205 239 234 206 239 234 minecraft:pink_terracotta
fill 205 239 256 206 239 256 minecraft:pink_terracotta
fill 206 239 229 207 239 232 minecraft:light_gray_concrete
fill 206 239 233 209 239 233 minecraft:pink_terracotta
fill 206 239 257 209 239 257 minecraft:pink_terracotta
fill 206 239 258 207 239 269 minecraft:light_gray_concrete
fill 208 239 229 229 239 231 minecraft:light_gray_concrete
fill 208 239 232 216 239 232 minecraft:pink_terracotta
fill 208 239 258 216 239 258 minecraft:pink_terracotta
fill 208 239 259 229 239 269 minecraft:light_gray_concrete
fill 215 239 233 218 239 233 minecraft:pink_terracotta
fill 215 239 257 218 239 257 minecraft:pink_terracotta
fill 217 239 232 229 239 232 minecraft:light_gray_concrete
fill 217 239 258 229 239 258 minecraft:light_gray_concrete
fill 218 239 234 220 239 234 minecraft:pink_terracotta
fill 218 239 256 220 239 256 minecraft:pink_terracotta
fill 219 239 233 229 239 233 minecraft:light_gray_concrete
fill 219 239 257 229 239 257 minecraft:light_gray_concrete
fill 220 239 235 221 239 235 minecraft:pink_terracotta
fill 220 239 255 221 239 255 minecraft:pink_terracotta
fill 221 239 234 229 239 234 minecraft:light_gray_concrete
fill 221 239 236 222 239 236 minecraft:pink_terracotta
fill 221 239 254 222 239 254 minecraft:pink_terracotta
fill 221 239 256 229 239 256 minecraft:light_gray_concrete
fill 222 239 235 229 239 235 minecraft:light_gray_concrete
fill 222 239 237 223 239 237 minecraft:pink_terracotta
fill 222 239 253 223 239 253 minecraft:pink_terracotta
fill 222 239 255 229 239 255 minecraft:light_gray_concrete
fill 223 239 236 229 239 236 minecraft:light_gray_concrete
fill 223 239 238 223 239 239 minecraft:pink_terracotta
fill 223 239 251 223 239 252 minecraft:pink_terracotta
fill 223 239 254 229 239 254 minecraft:light_gray_concrete
fill 224 239 237 229 239 238 minecraft:light_gray_concrete
fill 224 239 239 224 239 242 minecraft:pink_terracotta
fill 224 239 248 224 239 251 minecraft:pink_terracotta
fill 224 239 252 229 239 253 minecraft:light_gray_concrete
fill 225 239 239 229 239 240 minecraft:light_gray_concrete
fill 225 239 241 225 239 249 minecraft:pink_terracotta
fill 225 239 250 229 239 251 minecraft:light_gray_concrete
fill 226 239 241 229 239 249 minecraft:light_gray_concrete
fill 189 240 229 197 240 269 minecraft:light_gray_concrete
fill 198 240 229 198 240 239 minecraft:light_gray_concrete
fill 198 240 240 198 240 250 minecraft:pink_terracotta
fill 198 240 251 198 240 269 minecraft:light_gray_concrete
fill 199 240 229 199 240 237 minecraft:light_gray_concrete
fill 199 240 238 199 240 240 minecraft:pink_terracotta
fill 199 240 250 199 240 252 minecraft:pink_terracotta
fill 199 240 253 199 240 269 minecraft:light_gray_concrete
fill 200 240 229 200 240 236 minecraft:light_gray_concrete
fill 200 240 237 200 240 238 minecraft:pink_terracotta
fill 200 240 252 200 240 253 minecraft:pink_terracotta
fill 200 240 254 200 240 269 minecraft:light_gray_concrete
fill 201 240 229 201 240 234 minecraft:light_gray_concrete
fill 201 240 235 201 240 236 minecraft:pink_terracotta
fill 201 240 254 201 240 255 minecraft:pink_terracotta
fill 201 240 256 201 240 269 minecraft:light_gray_concrete
fill 202 240 229 203 240 233 minecraft:light_gray_concrete
fill 202 240 234 202 240 235 minecraft:pink_terracotta
fill 202 240 255 202 240 256 minecraft:pink_terracotta
fill 202 240 257 203 240 269 minecraft:light_gray_concrete
setblock 203 240 234 minecraft:pink_terracotta
setblock 203 240 256 minecraft:pink_terracotta
fill 204 240 229 204 240 232 minecraft:light_gray_concrete
fill 204 240 233 205 240 233 minecraft:pink_terracotta
fill 204 240 257 205 240 257 minecraft:pink_terracotta
fill 204 240 258 204 240 269 minecraft:light_gray_concrete
fill 205 240 229 206 240 231 minecraft:light_gray_concrete
fill 205 240 232 207 240 232 minecraft:pink_terracotta
fill 205 240 258 207 240 258 minecraft:pink_terracotta
fill 205 240 259 206 240 269 minecraft:light_gray_concrete
fill 207 240 229 229 240 230 minecraft:light_gray_concrete
fill 207 240 231 217 240 231 minecraft:pink_terracotta
fill 207 240 259 217 240 259 minecraft:pink_terracotta
fill 207 240 260 229 240 269 minecraft:light_gray_concrete
fill 217 240 232 219 240 232 minecraft:pink_terracotta
fill 217 240 258 219 240 258 minecraft:pink_terracotta
fill 218 240 231 229 240 231 minecraft:light_gray_concrete
fill 218 240 259 229 240 259 minecraft:light_gray_concrete
fill 219 240 233 220 240 233 minecraft:pink_terracotta
fill 219 240 257 220 240 257 minecraft:pink_terracotta
fill 220 240 232 229 240 232 minecraft:light_gray_concrete
fill 220 240 258 229 240 258 minecraft:light_gray_concrete
fill 221 240 233 229 240 233 minecraft:light_gray_concrete
fill 221 240 234 222 240 234 minecraft:pink_terracotta
fill 221 240 256 222 240 256 minecraft:pink_terracotta
fill 221 240 257 229 240 257 minecraft:light_gray_concrete
fill 222 240 235 223 240 235 minecraft:pink_terracotta
fill 222 240 255 223 240 255 minecraft:pink_terracotta
fill 223 240 234 229 240 234 minecraft:light_gray_concrete
setblock 223 240 236 minecraft:pink_terracotta
setblock 223 240 254 minecraft:pink_terracotta
fill 223 240 256 229 240 256 minecraft:light_gray_concrete
fill 224 240 235 229 240 236 minecraft:light_gray_concrete
fill 224 240 237 224 240 238 minecraft:pink_terracotta
fill 224 240 252 224 240 253 minecraft:pink_terracotta
fill 224 240 254 229 240 255 minecraft:light_gray_concrete
fill 225 240 237 229 240 237 minecraft:light_gray_concrete
fill 225 240 238 225 240 240 minecraft:pink_terracotta
fill 225 240 250 225 240 252 minecraft:pink_terracotta
fill 225 240 253 229 240 253 minecraft:light_gray_concrete
fill 226 240 238 229 240 239 minecraft:light_gray_concrete
fill 226 240 240 226 240 250 minecraft:pink_terracotta
fill 226 240 251 229 240 252 minecraft:light_gray_concrete
fill 227 240 240 229 240 250 minecraft:light_gray_concrete
fill 189 241 229 195 241 269 minecraft:light_gray_concrete
fill 196 241 229 196 241 242 minecraft:light_gray_concrete
fill 196 241 243 197 241 247 minecraft:pink_terracotta
fill 196 241 248 196 241 269 minecraft:light_gray_concrete
fill 197 241 229 197 241 238 minecraft:light_gray_concrete
fill 197 241 239 197 241 242 minecraft:pink_terracotta
fill 197 241 248 197 241 251 minecraft:pink_terracotta
fill 197 241 252 197 241 269 minecraft:light_gray_concrete
fill 198 241 229 198 241 236 minecraft:light_gray_concrete
fill 198 241 237 198 241 239 minecraft:pink_terracotta
fill 198 241 251 198 241 253 minecraft:pink_terracotta
fill 198 241 254 198 241 269 minecraft:light_gray_concrete
fill 199 241 229 199 241 235 minecraft:light_gray_concrete
fill 199 241 236 199 241 237 minecraft:pink_terracotta
fill 199 241 253 199 241 254 minecraft:pink_terracotta
fill 199 241 255 199 241 269 minecraft:light_gray_concrete
fill 200 241 229 200 241 234 minecraft:light_gray_concrete
fill 200 241 235 200 241 236 minecraft:pink_terracotta
fill 200 241 254 200 241 255 minecraft:pink_terracotta
fill 200 241 256 200 241 269 minecraft:light_gray_concrete
fill 201 241 229 201 241 233 minecraft:light_gray_concrete
setblock 201 241 234 minecraft:pink_terracotta
setblock 201 241 256 minecraft:pink_terracotta
fill 201 241 257 201 241 269 minecraft:light_gray_concrete
fill 202 241 229 202 241 232 minecraft:light_gray_concrete
fill 202 241 233 203 241 233 minecraft:pink_terracotta
fill 202 241 257 203 241 257 minecraft:pink_terracotta
fill 202 241 258 202 241 269 minecraft:light_gray_concrete
fill 203 241 229 203 241 231 minecraft:light_gray_concrete
fill 203 241 232 204 241 232 minecraft:pink_terracotta
fill 203 241 258 204 241 258 minecraft:pink_terracotta
fill 203 241 259 203 241 269 minecraft:light_gray_concrete
fill 204 241 229 205 241 230 minecraft:light_gray_concrete
fill 204 241 231 206 241 231 minecraft:pink_terracotta
fill 204 241 259 206 241 259 minecraft:pink_terracotta
fill 204 241 260 205 241 269 minecraft:light_gray_concrete
fill 206 241 229 209 241 229 minecraft:light_gray_concrete
fill 206 241 230 218 241 230 minecraft:pink_terracotta
fill 206 241 260 218 241 260 minecraft:pink_terracotta
fill 206 241 261 209 241 269 minecraft:light_gray_concrete
fill 210 241 229 214 241 229 minecraft:pink_terracotta
fill 210 241 261 214 241 261 minecraft:pink_terracotta
fill 210 241 262 229 241 269 minecraft:light_gray_concrete
fill 215 241 229 229 241 229 minecraft:light_gray_concrete
fill 215 241 261 229 241 261 minecraft:light_gray_concrete
fill 218 241 231 220 241 231 minecraft:pink_terracotta
fill 218 241 259 220 241 259 minecraft:pink_terracotta
fill 219 241 230 229 241 230 minecraft:light_gray_concrete
fill 219 241 260 229 241 260 minecraft:light_gray_concrete
fill 220 241 232 221 241 232 minecraft:pink_terracotta
fill 220 241 258 221 241 258 minecraft:pink_terracotta
fill 221 241 231 229 241 231 minecraft:light_gray_concrete
fill 221 241 233 222 241 233 minecraft:pink_terracotta
fill 221 241 257 222 241 257 minecraft:pink_terracotta
fill 221 241 259 229 241 259 minecraft:light_gray_concrete
fill 222 241 232 229 241 232 minecraft:light_gray_concrete
fill 222 241 258 229 241 258 minecraft:light_gray_concrete
fill 223 241 233 229 241 233 minecraft:light_gray_concrete
setblock 223 241 234 minecraft:pink_terracotta
setblock 223 241 256 minecraft:pink_terracotta
fill 223 241 257 229 241 257 minecraft:light_gray_concrete
fill 224 241 234 229 241 234 minecraft:light_gray_concrete
fill 224 241 235 224 241 236 minecraft:pink_terracotta
fill 224 241 254 224 241 255 minecraft:pink_terracotta
fill 224 241 256 229 241 256 minecraft:light_gray_concrete
fill 225 241 235 229 241 235 minecraft:light_gray_concrete
fill 225 241 236 225 241 237 minecraft:pink_terracotta
fill 225 241 253 225 241 254 minecraft:pink_terracotta
fill 225 241 255 229 241 255 minecraft:light_gray_concrete
fill 226 241 236 229 241 236 minecraft:light_gray_concrete
fill 226 241 237 226 241 239 minecraft:pink_terracotta
fill 226 241 251 226 241 253 minecraft:pink_terracotta
fill 226 241 254 229 241 254 minecraft:light_gray_concrete
fill 227 241 237 229 241 238 minecraft:light_gray_concrete
fill 227 241 239 227 241 251 minecraft:pink_terracotta
fill 227 241 252 229 241 253 minecraft:light_gray_concrete
fill 228 241 239 229 241 242 minecraft:light_gray_concrete
fill 228 241 243 228 241 247 minecraft:pink_terracotta
fill 228 241 248 229 241 251 minecraft:light_gray_concrete
fill 229 241 243 229 241 247 minecraft:light_gray_concrete
fill 189 242 229 194 242 269 minecraft:light_gray_concrete
fill 195 242 229 195 242 240 minecraft:light_gray_concrete
fill 195 242 241 195 242 249 minecraft:pink_terracotta
fill 195 242 250 195 242 269 minecraft:light_gray_concrete
fill 196 242 229 196 242 237 minecraft:light_gray_concrete
fill 196 242 238 196 242 242 minecraft:pink_terracotta
fill 196 242 248 196 242 252 minecraft:pink_terracotta
fill 196 242 253 196 242 269 minecraft:light_gray_concrete
fill 197 242 229 197 242 235 minecraft:light_gray_concrete
fill 197 242 236 197 242 238 minecraft:pink_terracotta
fill 197 242 252 197 242 254 minecraft:pink_terracotta
fill 197 242 255 197 242 269 minecraft:light_gray_concrete
fill 198 242 229 198 242 234 minecraft:light_gray_concrete
fill 198 242 235 198 242 236 minecraft:pink_terracotta
setblock 198 242 238 minecraft:light[level=15]
setblock 198 242 245 minecraft:light[level=15]
setblock 198 242 252 minecraft:light[level=15]
fill 198 242 254 198 242 255 minecraft:pink_terracotta
fill 198 242 256 198 242 269 minecraft:light_gray_concrete
fill 199 242 229 199 242 233 minecraft:light_gray_concrete
fill 199 242 234 199 242 235 minecraft:pink_terracotta
fill 199 242 255 199 242 256 minecraft:pink_terracotta
fill 199 242 257 199 242 269 minecraft:light_gray_concrete
fill 200 242 229 200 242 232 minecraft:light_gray_concrete
fill 200 242 233 200 242 234 minecraft:pink_terracotta
fill 200 242 256 200 242 257 minecraft:pink_terracotta
fill 200 242 258 200 242 269 minecraft:light_gray_concrete
fill 201 242 229 201 242 231 minecraft:light_gray_concrete
fill 201 242 232 201 242 233 minecraft:pink_terracotta
fill 201 242 257 201 242 258 minecraft:pink_terracotta
fill 201 242 259 201 242 269 minecraft:light_gray_concrete
fill 202 242 229 202 242 230 minecraft:light_gray_concrete
fill 202 242 231 202 242 232 minecraft:pink_terracotta
fill 202 242 258 202 242 259 minecraft:pink_terracotta
fill 202 242 260 202 242 269 minecraft:light_gray_concrete
fill 203 242 229 204 242 229 minecraft:light_gray_concrete
fill 203 242 230 203 242 231 minecraft:pink_terracotta
fill 203 242 259 203 242 260 minecraft:pink_terracotta
fill 203 242 261 204 242 269 minecraft:light_gray_concrete
fill 204 242 230 205 242 230 minecraft:pink_terracotta
fill 204 242 260 205 242 260 minecraft:pink_terracotta
fill 205 242 229 209 242 229 minecraft:pink_terracotta
setblock 205 242 231 minecraft:light[level=15]
setblock 205 242 238 minecraft:light[level=15]
setblock 205 242 245 minecraft:light[level=15]
setblock 205 242 252 minecraft:light[level=15]
setblock 205 242 259 minecraft:light[level=15]
fill 205 242 261 209 242 261 minecraft:pink_terracotta
fill 205 242 262 207 242 269 minecraft:light_gray_concrete
fill 208 242 262 216 242 262 minecraft:pink_terracotta
fill 208 242 263 229 242 269 minecraft:light_gray_concrete
setblock 212 242 231 minecraft:light[level=15]
setblock 212 242 238 minecraft:light[level=15]
setblock 212 242 252 minecraft:light[level=15]
setblock 212 242 259 minecraft:light[level=15]
fill 215 242 229 219 242 229 minecraft:pink_terracotta
fill 215 242 261 219 242 261 minecraft:pink_terracotta
fill 217 242 262 229 242 262 minecraft:light_gray_concrete
fill 219 242 230 221 242 230 minecraft:pink_terracotta
setblock 219 242 231 minecraft:light[level=15]
setblock 219 242 238 minecraft:light[level=15]
setblock 219 242 245 minecraft:light[level=15]
setblock 219 242 252 minecraft:light[level=15]
setblock 219 242 259 minecraft:light[level=15]
fill 219 242 260 221 242 260 minecraft:pink_terracotta
fill 220 242 229 229 242 229 minecraft:light_gray_concrete
fill 220 242 261 229 242 261 minecraft:light_gray_concrete
fill 221 242 231 222 242 231 minecraft:pink_terracotta
fill 221 242 259 222 242 259 minecraft:pink_terracotta
fill 222 242 230 229 242 230 minecraft:light_gray_concrete
fill 222 242 232 223 242 232 minecraft:pink_terracotta
fill 222 242 258 223 242 258 minecraft:pink_terracotta
fill 222 242 260 229 242 260 minecraft:light_gray_concrete
fill 223 242 231 229 242 231 minecraft:light_gray_concrete
fill 223 242 233 224 242 233 minecraft:pink_terracotta
fill 223 242 257 224 242 257 minecraft:pink_terracotta
fill 223 242 259 229 242 259 minecraft:light_gray_concrete
fill 224 242 232 229 242 232 minecraft:light_gray_concrete
fill 224 242 234 225 242 234 minecraft:pink_terracotta
fill 224 242 256 225 242 256 minecraft:pink_terracotta
fill 224 242 258 229 242 258 minecraft:light_gray_concrete
fill 225 242 233 229 242 233 minecraft:light_gray_concrete
fill 225 242 235 226 242 235 minecraft:pink_terracotta
fill 225 242 255 226 242 255 minecraft:pink_terracotta
fill 225 242 257 229 242 257 minecraft:light_gray_concrete
fill 226 242 234 229 242 234 minecraft:light_gray_concrete
fill 226 242 236 227 242 236 minecraft:pink_terracotta
setblock 226 242 238 minecraft:light[level=15]
setblock 226 242 245 minecraft:light[level=15]
setblock 226 242 252 minecraft:light[level=15]
fill 226 242 254 227 242 254 minecraft:pink_terracotta
fill 226 242 256 229 242 256 minecraft:light_gray_concrete
fill 227 242 235 229 242 235 minecraft:light_gray_concrete
fill 227 242 237 227 242 238 minecraft:pink_terracotta
fill 227 242 252 227 242 253 minecraft:pink_terracotta
fill 227 242 255 229 242 255 minecraft:light_gray_concrete
fill 228 242 236 229 242 237 minecraft:light_gray_concrete
fill 228 242 238 228 242 242 minecraft:pink_terracotta
fill 228 242 248 228 242 252 minecraft:pink_terracotta
fill 228 242 253 229 242 254 minecraft:light_gray_concrete
fill 229 242 238 229 242 240 minecraft:light_gray_concrete
fill 229 242 241 229 242 249 minecraft:pink_terracotta
fill 229 242 250 229 242 252 minecraft:light_gray_concrete
fill 189 243 229 193 243 269 minecraft:light_gray_concrete
fill 194 243 229 194 243 239 minecraft:light_gray_concrete
fill 194 243 240 194 243 250 minecraft:pink_terracotta
fill 194 243 251 194 243 269 minecraft:light_gray_concrete
fill 195 243 229 195 243 236 minecraft:light_gray_concrete
fill 195 243 237 195 243 240 minecraft:pink_terracotta
fill 195 243 250 195 243 253 minecraft:pink_terracotta
fill 195 243 254 195 243 269 minecraft:light_gray_concrete
fill 196 243 229 196 243 235 minecraft:light_gray_concrete
fill 196 243 236 196 243 237 minecraft:pink_terracotta
fill 196 243 253 196 243 254 minecraft:pink_terracotta
fill 196 243 255 196 243 269 minecraft:light_gray_concrete
fill 197 243 229 197 243 233 minecraft:light_gray_concrete
fill 197 243 234 197 243 235 minecraft:pink_terracotta
fill 197 243 255 197 243 256 minecraft:pink_terracotta
fill 197 243 257 197 243 269 minecraft:light_gray_concrete
fill 198 243 229 198 243 232 minecraft:light_gray_concrete
fill 198 243 233 198 243 234 minecraft:pink_terracotta
fill 198 243 256 198 243 257 minecraft:pink_terracotta
fill 198 243 258 198 243 269 minecraft:light_gray_concrete
fill 199 243 229 199 243 231 minecraft:light_gray_concrete
fill 199 243 232 199 243 233 minecraft:pink_terracotta
fill 199 243 257 199 243 258 minecraft:pink_terracotta
fill 199 243 259 199 243 269 minecraft:light_gray_concrete
fill 200 243 229 200 243 230 minecraft:light_gray_concrete
fill 200 243 231 200 243 232 minecraft:pink_terracotta
fill 200 243 258 200 243 259 minecraft:pink_terracotta
fill 200 243 260 200 243 269 minecraft:light_gray_concrete
fill 201 243 229 202 243 229 minecraft:light_gray_concrete
fill 201 243 230 201 243 231 minecraft:pink_terracotta
fill 201 243 259 201 243 260 minecraft:pink_terracotta
fill 201 243 261 202 243 269 minecraft:light_gray_concrete
setblock 202 243 230 minecraft:pink_terracotta
setblock 202 243 260 minecraft:pink_terracotta
fill 203 243 229 204 243 229 minecraft:pink_terracotta
fill 203 243 261 204 243 261 minecraft:pink_terracotta
fill 203 243 262 203 243 269 minecraft:light_gray_concrete
fill 204 243 262 207 243 262 minecraft:pink_terracotta
fill 204 243 263 206 243 269 minecraft:light_gray_concrete
setblock 205 243 229 minecraft:pink_concrete
fill 207 243 263 217 243 263 minecraft:pink_terracotta
fill 207 243 264 229 243 269 minecraft:light_gray_concrete
fill 217 243 262 220 243 262 minecraft:pink_terracotta
fill 218 243 263 229 243 263 minecraft:light_gray_concrete
fill 220 243 229 221 243 229 minecraft:pink_terracotta
fill 220 243 261 221 243 261 minecraft:pink_terracotta
fill 221 243 262 229 243 262 minecraft:light_gray_concrete
fill 222 243 229 229 243 229 minecraft:light_gray_concrete
fill 222 243 230 223 243 230 minecraft:pink_terracotta
fill 222 243 260 223 243 260 minecraft:pink_terracotta
fill 222 243 261 229 243 261 minecraft:light_gray_concrete
fill 223 243 231 224 243 231 minecraft:pink_terracotta
fill 223 243 259 224 243 259 minecraft:pink_terracotta
fill 224 243 230 229 243 230 minecraft:light_gray_concrete
fill 224 243 232 225 243 232 minecraft:pink_terracotta
fill 224 243 258 225 243 258 minecraft:pink_terracotta
fill 224 243 260 229 243 260 minecraft:light_gray_concrete
fill 225 243 231 229 243 231 minecraft:light_gray_concrete
fill 225 243 233 226 243 233 minecraft:pink_terracotta
fill 225 243 257 226 243 257 minecraft:pink_terracotta
fill 225 243 259 229 243 259 minecraft:light_gray_concrete
fill 226 243 232 229 243 232 minecraft:light_gray_concrete
fill 226 243 234 227 243 234 minecraft:pink_terracotta
fill 226 243 256 227 243 256 minecraft:pink_terracotta
fill 226 243 258 229 243 258 minecraft:light_gray_concrete
fill 227 243 233 229 243 233 minecraft:light_gray_concrete
setblock 227 243 235 minecraft:pink_terracotta
setblock 227 243 255 minecraft:pink_terracotta
fill 227 243 257 229 243 257 minecraft:light_gray_concrete
fill 228 243 234 229 243 235 minecraft:light_gray_concrete
fill 228 243 236 228 243 237 minecraft:pink_terracotta
fill 228 243 253 228 243 254 minecraft:pink_terracotta
fill 228 243 255 229 243 256 minecraft:light_gray_concrete
setblock 229 243 236 minecraft:light_gray_concrete
fill 229 243 237 229 243 240 minecraft:pink_terracotta
fill 229 243 250 229 243 253 minecraft:pink_terracotta
setblock 229 243 254 minecraft:light_gray_concrete
fill 189 244 229 192 244 269 minecraft:light_gray_concrete
fill 193 244 229 193 244 239 minecraft:light_gray_concrete
fill 193 244 240 193 244 250 minecraft:pink_terracotta
fill 193 244 251 193 244 269 minecraft:light_gray_concrete
fill 194 244 229 194 244 236 minecraft:light_gray_concrete
fill 194 244 237 194 244 239 minecraft:pink_terracotta
fill 194 244 251 194 244 253 minecraft:pink_terracotta
fill 194 244 254 194 244 269 minecraft:light_gray_concrete
fill 195 244 229 195 244 235 minecraft:light_gray_concrete
setblock 195 244 236 minecraft:pink_terracotta
setblock 195 244 254 minecraft:pink_terracotta
fill 195 244 255 195 244 269 minecraft:light_gray_concrete
fill 196 244 229 196 244 233 minecraft:light_gray_concrete
fill 196 244 234 196 244 235 minecraft:pink_terracotta
fill 196 244 255 196 244 256 minecraft:pink_terracotta
fill 196 244 257 196 244 269 minecraft:light_gray_concrete
fill 197 244 229 197 244 232 minecraft:light_gray_concrete
setblock 197 244 233 minecraft:pink_terracotta
setblock 197 244 257 minecraft:pink_terracotta
fill 197 244 258 197 244 269 minecraft:light_gray_concrete
fill 198 244 229 198 244 231 minecraft:light_gray_concrete
setblock 198 244 232 minecraft:pink_terracotta
setblock 198 244 258 minecraft:pink_terracotta
fill 198 244 259 198 244 269 minecraft:light_gray_concrete
fill 199 244 229 199 244 230 minecraft:light_gray_concrete
setblock 199 244 231 minecraft:pink_terracotta
setblock 199 244 259 minecraft:pink_terracotta
fill 199 244 260 199 244 269 minecraft:light_gray_concrete
setblock 200 244 229 minecraft:light_gray_concrete
setblock 200 244 230 minecraft:pink_terracotta
setblock 200 244 260 minecraft:pink_terracotta
fill 200 244 261 200 244 269 minecraft:light_gray_concrete
fill 201 244 229 202 244 229 minecraft:pink_terracotta
fill 201 244 261 202 244 261 minecraft:pink_terracotta
fill 201 244 262 202 244 269 minecraft:light_gray_concrete
setblock 203 244 262 minecraft:pink_terracotta
fill 203 244 263 203 244 269 minecraft:light_gray_concrete
fill 204 244 263 206 244 263 minecraft:pink_terracotta
fill 204 244 264 206 244 269 minecraft:light_gray_concrete
fill 207 244 264 217 244 264 minecraft:pink_terracotta
fill 207 244 265 229 244 269 minecraft:light_gray_concrete
setblock 208 244 229 minecraft:pink_concrete
fill 218 244 263 220 244 263 minecraft:pink_terracotta
fill 218 244 264 229 244 264 minecraft:light_gray_concrete
setblock 221 244 262 minecraft:pink_terracotta
fill 221 244 263 229 244 263 minecraft:light_gray_concrete
fill 222 244 229 223 244 229 minecraft:pink_terracotta
fill 222 244 261 223 244 261 minecraft:pink_terracotta
fill 222 244 262 229 244 262 minecraft:light_gray_concrete
fill 224 244 229 229 244 229 minecraft:light_gray_concrete
setblock 224 244 230 minecraft:pink_terracotta
setblock 224 244 260 minecraft:pink_terracotta
fill 224 244 261 229 244 261 minecraft:light_gray_concrete
fill 225 244 230 229 244 230 minecraft:light_gray_concrete
setblock 225 244 231 minecraft:pink_terracotta
setblock 225 244 259 minecraft:pink_terracotta
fill 225 244 260 229 244 260 minecraft:light_gray_concrete
fill 226 244 231 229 244 231 minecraft:light_gray_concrete
setblock 226 244 232 minecraft:pink_terracotta
setblock 226 244 258 minecraft:pink_terracotta
fill 226 244 259 229 244 259 minecraft:light_gray_concrete
fill 227 244 232 229 244 232 minecraft:light_gray_concrete
setblock 227 244 233 minecraft:pink_terracotta
setblock 227 244 257 minecraft:pink_terracotta
fill 227 244 258 229 244 258 minecraft:light_gray_concrete
fill 228 244 233 229 244 233 minecraft:light_gray_concrete
fill 228 244 234 228 244 235 minecraft:pink_terracotta
fill 228 244 255 228 244 256 minecraft:pink_terracotta
fill 228 244 257 229 244 257 minecraft:light_gray_concrete
fill 229 244 234 229 244 235 minecraft:light_gray_concrete
setblock 229 244 236 minecraft:pink_terracotta
setblock 229 244 254 minecraft:pink_terracotta
fill 229 244 255 229 244 256 minecraft:light_gray_concrete
fill 189 245 229 189 245 249 minecraft:white_terracotta
setblock 189 245 250 minecraft:red_concrete
fill 189 245 251 189 245 269 minecraft:white_terracotta
fill 190 245 229 229 245 229 minecraft:white_terracotta
fill 190 245 230 191 245 268 minecraft:bone_block
fill 190 245 269 197 245 269 minecraft:white_terracotta
fill 192 245 230 228 245 231 minecraft:bone_block
fill 192 245 267 228 245 268 minecraft:bone_block
fill 193 245 232 194 250 233 minecraft:iron_block
setblock 198 245 269 minecraft:red_concrete
fill 199 245 269 213 245 269 minecraft:white_terracotta
setblock 214 245 269 minecraft:pink_concrete
fill 215 245 269 223 245 269 minecraft:white_terracotta
setblock 224 245 269 minecraft:red_concrete
setblock 225 245 269 minecraft:magenta_terracotta
fill 226 245 269 228 245 269 minecraft:white_terracotta
fill 227 245 232 228 245 266 minecraft:bone_block
fill 229 245 230 229 245 247 minecraft:white_terracotta
setblock 229 245 248 minecraft:red_concrete
fill 229 245 249 229 245 268 minecraft:white_terracotta
setblock 229 245 269 minecraft:magenta_terracotta
setblock 189 246 239 minecraft:red_concrete
setblock 200 246 229 minecraft:red_concrete
setblock 221 246 269 minecraft:pink_concrete
fill 225 246 253 225 247 257 minecraft:spruce_planks
setblock 229 246 257 minecraft:pink_concrete
setblock 189 247 248 minecraft:pink_concrete
setblock 189 247 252 minecraft:red_concrete
setblock 190 247 269 minecraft:magenta_terracotta
setblock 207 247 269 minecraft:magenta_terracotta
setblock 215 247 229 minecraft:magenta_terracotta
setblock 217 247 269 minecraft:red_concrete
fill 223 247 254 224 247 256 minecraft:spruce_planks
fill 224 247 250 224 247 253 minecraft:spruce_planks
fill 224 247 257 224 247 260 minecraft:spruce_planks
fill 225 247 249 225 247 252 minecraft:spruce_planks
fill 225 247 258 225 247 261 minecraft:spruce_planks
fill 226 247 250 226 247 260 minecraft:spruce_planks
fill 227 247 254 227 248 256 minecraft:spruce_planks
setblock 229 247 233 minecraft:pink_concrete
setblock 229 247 263 minecraft:magenta_terracotta
setblock 189 248 239 minecraft:magenta_terracotta
setblock 189 248 251 minecraft:pink_concrete
setblock 189 248 256 minecraft:red_concrete
setblock 191 248 231 minecraft:light[level=15]
setblock 191 248 238 minecraft:light[level=15]
setblock 191 248 245 minecraft:light[level=15]
setblock 191 248 252 minecraft:light[level=15]
setblock 191 248 259 minecraft:light[level=15]
setblock 191 248 266 minecraft:light[level=15]
setblock 198 248 231 minecraft:light[level=15]
setblock 198 248 238 minecraft:light[level=15]
setblock 198 248 245 minecraft:light[level=15]
setblock 198 248 252 minecraft:light[level=15]
setblock 198 248 259 minecraft:light[level=15]
setblock 198 248 266 minecraft:light[level=15]
setblock 205 248 231 minecraft:light[level=15]
setblock 205 248 238 minecraft:light[level=15]
setblock 205 248 245 minecraft:light[level=15]
setblock 205 248 252 minecraft:light[level=15]
setblock 205 248 259 minecraft:light[level=15]
setblock 205 248 266 minecraft:light[level=15]
setblock 212 248 231 minecraft:light[level=15]
setblock 212 248 238 minecraft:light[level=15]
setblock 212 248 252 minecraft:light[level=15]
setblock 212 248 259 minecraft:light[level=15]
setblock 212 248 266 minecraft:light[level=15]
setblock 218 248 269 minecraft:pink_concrete
setblock 219 248 231 minecraft:light[level=15]
setblock 219 248 238 minecraft:light[level=15]
setblock 219 248 245 minecraft:light[level=15]
setblock 219 248 252 minecraft:light[level=15]
setblock 219 248 259 minecraft:light[level=15]
setblock 219 248 266 minecraft:light[level=15]
fill 223 248 254 223 248 256 minecraft:spruce_planks
setblock 224 248 250 minecraft:spruce_planks
fill 224 248 252 226 248 252 minecraft:dark_oak_planks
setblock 224 248 260 minecraft:spruce_planks
setblock 225 248 249 minecraft:spruce_planks
setblock 225 248 261 minecraft:spruce_planks
setblock 226 248 231 minecraft:light[level=15]
setblock 226 248 238 minecraft:light[level=15]
setblock 226 248 245 minecraft:light[level=15]
setblock 226 248 250 minecraft:spruce_planks
setblock 226 248 259 minecraft:light[level=15]
setblock 226 248 260 minecraft:spruce_planks
setblock 226 248 266 minecraft:light[level=15]
setblock 229 248 240 minecraft:magenta_terracotta
setblock 212 249 229 minecraft:pink_concrete
setblock 229 249 252 minecraft:pink_concrete
fill 189 250 229 189 250 238 minecraft:white_terracotta
setblock 189 250 239 minecraft:pink_concrete
fill 189 250 240 189 250 269 minecraft:white_terracotta
fill 190 250 229 228 250 229 minecraft:white_terracotta
fill 190 250 230 191 250 268 minecraft:bone_block
setblock 190 250 269 minecraft:pink_concrete
fill 191 250 269 204 250 269 minecraft:white_terracotta
fill 192 250 230 228 250 231 minecraft:bone_block
fill 192 250 267 228 250 268 minecraft:bone_block
setblock 205 250 269 minecraft:red_concrete
fill 206 250 269 229 250 269 minecraft:white_terracotta
fill 227 250 232 228 250 266 minecraft:bone_block
setblock 229 250 229 minecraft:red_concrete
fill 229 250 230 229 250 268 minecraft:white_terracotta
setblock 191 251 232 minecraft:iron_block
setblock 192 251 231 minecraft:iron_block
setblock 192 251 233 minecraft:iron_block
setblock 193 251 234 minecraft:iron_block
setblock 194 251 231 minecraft:iron_block
setblock 194 251 233 minecraft:iron_block
setblock 195 251 232 minecraft:iron_block
setblock 206 251 229 minecraft:red_concrete
setblock 228 251 269 minecraft:pink_concrete
setblock 229 251 246 minecraft:pink_concrete
setblock 229 251 248 minecraft:magenta_terracotta
setblock 189 252 252 minecraft:red_concrete
setblock 199 252 269 minecraft:red_concrete
setblock 206 252 269 minecraft:pink_concrete
setblock 229 252 253 minecraft:pink_concrete
setblock 189 253 231 minecraft:pink_concrete
fill 196 253 229 197 253 229 minecraft:magenta_terracotta
setblock 189 254 235 minecraft:magenta_terracotta
setblock 191 254 231 minecraft:light[level=15]
setblock 191 254 238 minecraft:light[level=15]
setblock 191 254 245 minecraft:light[level=15]
setblock 191 254 252 minecraft:light[level=15]
setblock 191 254 259 minecraft:light[level=15]
setblock 191 254 266 minecraft:light[level=15]
setblock 198 254 231 minecraft:light[level=15]
setblock 198 254 238 minecraft:light[level=15]
setblock 198 254 245 minecraft:light[level=15]
setblock 198 254 252 minecraft:light[level=15]
setblock 198 254 259 minecraft:light[level=15]
setblock 198 254 266 minecraft:light[level=15]
setblock 199 254 269 minecraft:magenta_terracotta
setblock 205 254 231 minecraft:light[level=15]
setblock 205 254 238 minecraft:light[level=15]
setblock 205 254 245 minecraft:light[level=15]
setblock 205 254 252 minecraft:light[level=15]
setblock 205 254 259 minecraft:light[level=15]
setblock 205 254 266 minecraft:light[level=15]
setblock 212 254 231 minecraft:light[level=15]
setblock 212 254 238 minecraft:light[level=15]
setblock 212 254 252 minecraft:light[level=15]
setblock 212 254 259 minecraft:light[level=15]
setblock 212 254 266 minecraft:light[level=15]
setblock 219 254 231 minecraft:light[level=15]
setblock 219 254 238 minecraft:light[level=15]
setblock 219 254 245 minecraft:light[level=15]
setblock 219 254 252 minecraft:light[level=15]
setblock 219 254 259 minecraft:light[level=15]
setblock 219 254 266 minecraft:light[level=15]
setblock 226 254 231 minecraft:light[level=15]
setblock 226 254 238 minecraft:light[level=15]
setblock 226 254 245 minecraft:light[level=15]
setblock 226 254 252 minecraft:light[level=15]
setblock 226 254 259 minecraft:light[level=15]
setblock 226 254 266 minecraft:light[level=15]
setblock 229 254 252 minecraft:magenta_terracotta
fill 188 255 228 188 255 252 minecraft:red_terracotta
setblock 188 255 253 minecraft:pink_terracotta
fill 188 255 254 188 255 259 minecraft:red_terracotta
fill 188 255 260 188 256 260 minecraft:pink_terracotta
fill 188 255 261 188 255 269 minecraft:red_terracotta
setblock 188 255 270 minecraft:pink_terracotta
fill 189 255 228 215 256 228 minecraft:red_terracotta
fill 189 255 229 192 255 229 minecraft:white_terracotta
setblock 189 255 230 minecraft:red_concrete
fill 189 255 231 189 255 269 minecraft:white_terracotta
fill 189 255 270 205 255 270 minecraft:red_terracotta
fill 190 255 230 191 255 268 minecraft:bone_block
fill 190 255 269 195 255 269 minecraft:white_terracotta
fill 192 255 230 228 255 231 minecraft:bone_block
fill 192 255 267 228 255 268 minecraft:bone_block
setblock 193 255 229 minecraft:red_concrete
fill 194 255 229 211 255 229 minecraft:white_terracotta
setblock 196 255 269 minecraft:red_concrete
fill 197 255 269 219 255 269 minecraft:white_terracotta
setblock 206 255 270 minecraft:pink_terracotta
fill 207 255 270 222 255 270 minecraft:red_terracotta
setblock 212 255 229 minecraft:red_concrete
fill 213 255 229 229 255 229 minecraft:white_terracotta
setblock 216 255 228 minecraft:pink_terracotta
fill 217 255 228 220 255 228 minecraft:red_terracotta
setblock 220 255 269 minecraft:magenta_terracotta
fill 221 255 228 223 255 228 minecraft:pink_terracotta
fill 221 255 269 229 255 269 minecraft:white_terracotta
setblock 223 255 270 minecraft:pink_terracotta
setblock 224 255 228 minecraft:red_terracotta
fill 224 255 270 225 256 270 minecraft:red_terracotta
setblock 225 255 228 minecraft:pink_terracotta
fill 226 255 228 226 256 228 minecraft:red_terracotta
setblock 226 255 270 minecraft:pink_terracotta
fill 227 255 228 228 255 228 minecraft:pink_terracotta
fill 227 255 232 228 255 266 minecraft:bone_block
fill 227 255 270 230 256 270 minecraft:red_terracotta
fill 229 255 228 229 258 228 minecraft:red_terracotta
fill 229 255 230 229 255 253 minecraft:white_terracotta
setblock 229 255 254 minecraft:pink_concrete
fill 229 255 255 229 255 268 minecraft:white_terracotta
fill 230 255 228 230 257 228 minecraft:pink_terracotta
fill 230 255 229 230 255 250 minecraft:red_terracotta
setblock 230 255 251 minecraft:pink_terracotta
fill 230 255 252 230 255 269 minecraft:red_terracotta
fill 188 256 228 188 256 250 minecraft:red_terracotta
setblock 188 256 251 minecraft:pink_terracotta
fill 188 256 252 188 256 254 minecraft:red_terracotta
setblock 188 256 255 minecraft:pink_terracotta
fill 188 256 256 188 258 259 minecraft:red_terracotta
fill 188 256 261 188 258 261 minecraft:red_terracotta
setblock 188 256 262 minecraft:pink_terracotta
fill 188 256 263 188 256 268 minecraft:red_terracotta
setblock 188 256 269 minecraft:pink_terracotta
fill 188 256 270 202 258 270 minecraft:red_terracotta
setblock 189 256 239 minecraft:pink_concrete
setblock 189 256 240 minecraft:red_concrete
setblock 189 256 260 minecraft:pink_concrete
setblock 197 256 229 minecraft:magenta_terracotta
setblock 203 256 269 minecraft:red_concrete
fill 203 256 270 204 256 270 minecraft:pink_terracotta
fill 205 256 270 210 256 270 minecraft:red_terracotta
setblock 211 256 270 minecraft:pink_terracotta
fill 212 256 270 216 258 270 minecraft:red_terracotta
fill 216 256 228 217 258 228 minecraft:red_terracotta
setblock 217 256 270 minecraft:pink_terracotta
setblock 218 256 228 minecraft:pink_terracotta
fill 218 256 270 223 258 270 minecraft:red_terracotta
fill 219 256 228 223 256 228 minecraft:red_terracotta
fill 224 256 228 224 257 228 minecraft:pink_terracotta
fill 225 256 228 225 258 228 minecraft:red_terracotta
fill 226 256 270 226 258 270 minecraft:red_terracotta
fill 227 256 228 228 258 228 minecraft:red_terracotta
setblock 229 256 243 minecraft:pink_concrete
setblock 229 256 266 minecraft:magenta_terracotta
fill 230 256 229 230 258 242 minecraft:red_terracotta
setblock 230 256 243 minecraft:pink_terracotta
fill 230 256 244 230 256 263 minecraft:red_terracotta
setblock 230 256 264 minecraft:pink_terracotta
fill 230 256 265 230 256 269 minecraft:red_terracotta
fill 188 257 228 188 258 238 minecraft:red_terracotta
setblock 188 257 239 minecraft:pink_terracotta
fill 188 257 240 188 258 241 minecraft:red_terracotta
setblock 188 257 242 minecraft:pink_terracotta
fill 188 257 243 188 258 249 minecraft:red_terracotta
setblock 188 257 250 minecraft:pink_terracotta
fill 188 257 251 188 258 252 minecraft:red_terracotta
fill 188 257 253 188 257 254 minecraft:pink_terracotta
fill 188 257 255 188 258 255 minecraft:red_terracotta
fill 188 257 260 188 258 260 minecraft:red_terracotta
fill 188 257 262 188 258 267 minecraft:red_terracotta
setblock 188 257 268 minecraft:pink_terracotta
fill 188 257 269 188 259 269 minecraft:red_terracotta
setblock 189 257 228 minecraft:pink_terracotta
fill 190 257 228 195 258 228 minecraft:red_terracotta
fill 196 257 228 197 257 228 minecraft:pink_terracotta
setblock 197 257 269 minecraft:pink_concrete
fill 198 257 228 201 258 228 minecraft:red_terracotta
setblock 202 257 228 minecraft:pink_terracotta
fill 203 257 228 209 258 228 minecraft:red_terracotta
fill 203 257 270 204 258 270 minecraft:red_terracotta
setblock 204 257 269 minecraft:pink_concrete
setblock 205 257 270 minecraft:pink_terracotta
setblock 206 257 269 minecraft:magenta_terracotta
fill 206 257 270 211 258 270 minecraft:red_terracotta
setblock 209 257 269 minecraft:magenta_terracotta
setblock 210 257 228 minecraft:pink_terracotta
fill 211 257 228 212 258 228 minecraft:red_terracotta
fill 213 257 228 214 257 228 minecraft:pink_terracotta
fill 215 257 228 215 258 228 minecraft:red_terracotta
fill 217 257 270 217 258 270 minecraft:red_terracotta
fill 218 257 228 221 258 228 minecraft:red_terracotta
setblock 222 257 228 minecraft:pink_terracotta
fill 223 257 228 223 259 228 minecraft:red_terracotta
fill 224 257 270 224 258 270 minecraft:red_terracotta
setblock 225 257 270 minecraft:pink_terracotta
setblock 226 257 228 minecraft:pink_terracotta
fill 227 257 270 229 258 270 minecraft:red_terracotta
fill 230 257 243 230 258 254 minecraft:red_terracotta
setblock 230 257 255 minecraft:pink_terracotta
fill 230 257 256 230 258 256 minecraft:red_terracotta
setblock 230 257 257 minecraft:pink_terracotta
fill 230 257 258 230 258 266 minecraft:red_terracotta
setblock 230 257 267 minecraft:pink_terracotta
fill 230 257 268 230 258 269 minecraft:red_terracotta
setblock 230 257 270 minecraft:pink_terracotta
setblock 188 258 239 minecraft:red_terracotta
fill 188 258 242 188 260 242 minecraft:red_terracotta
setblock 188 258 250 minecraft:red_terracotta
fill 188 258 253 188 258 254 minecraft:red_terracotta
setblock 188 258 268 minecraft:red_terracotta
setblock 189 258 228 minecraft:red_terracotta
setblock 189 258 234 minecraft:red_concrete
setblock 189 258 240 minecraft:magenta_terracotta
setblock 194 258 269 minecraft:red_concrete
fill 196 258 228 197 258 228 minecraft:red_terracotta
setblock 202 258 228 minecraft:red_terracotta
setblock 205 258 229 minecraft:magenta_terracotta
setblock 205 258 270 minecraft:red_terracotta
setblock 210 258 228 minecraft:red_terracotta
fill 213 258 228 214 258 228 minecraft:red_terracotta
setblock 222 258 228 minecraft:red_terracotta
fill 224 258 228 224 259 228 minecraft:red_terracotta
setblock 225 258 270 minecraft:red_terracotta
setblock 226 258 228 minecraft:red_terracotta
setblock 226 258 229 minecraft:red_concrete
setblock 229 258 230 minecraft:magenta_terracotta
setblock 229 258 235 minecraft:magenta_terracotta
setblock 230 258 228 minecraft:red_terracotta
setblock 230 258 255 minecraft:red_terracotta
setblock 230 258 257 minecraft:red_terracotta
setblock 230 258 267 minecraft:red_terracotta
setblock 230 258 270 minecraft:red_terracotta
fill 188 259 228 188 259 234 minecraft:pink_terracotta
setblock 188 259 235 minecraft:red_terracotta
fill 188 259 236 188 260 239 minecraft:pink_terracotta
setblock 188 259 240 minecraft:red_terracotta
fill 188 259 241 188 284 241 minecraft:pink_terracotta
fill 188 259 243 188 284 243 minecraft:pink_terracotta
setblock 188 259 244 minecraft:red_terracotta
fill 188 259 245 188 284 250 minecraft:pink_terracotta
setblock 188 259 251 minecraft:red_terracotta
fill 188 259 252 188 284 252 minecraft:pink_terracotta
setblock 188 259 253 minecraft:red_terracotta
fill 188 259 254 188 260 257 minecraft:pink_terracotta
setblock 188 259 258 minecraft:red_terracotta
fill 188 259 259 188 259 266 minecraft:pink_terracotta
setblock 188 259 267 minecraft:red_terracotta
fill 188 259 268 188 284 268 minecraft:pink_terracotta
fill 188 259 270 193 259 270 minecraft:pink_terracotta
fill 189 259 228 189 284 228 minecraft:pink_terracotta
setblock 189 259 236 minecraft:magenta_terracotta
setblock 189 259 244 minecraft:red_concrete
setblock 190 259 228 minecraft:red_terracotta
fill 191 259 228 193 260 228 minecraft:pink_terracotta
fill 194 259 228 194 260 228 minecraft:red_terracotta
fill 194 259 270 195 259 270 minecraft:red_terracotta
fill 195 259 228 222 259 228 minecraft:pink_terracotta
fill 196 259 270 200 260 270 minecraft:pink_terracotta
setblock 198 259 269 minecraft:pink_concrete
setblock 201 259 270 minecraft:red_terracotta
fill 202 259 270 209 284 270 minecraft:pink_terracotta
setblock 210 259 270 minecraft:red_terracotta
fill 211 259 270 213 284 270 minecraft:pink_terracotta
setblock 214 259 270 minecraft:red_terracotta
fill 215 259 270 219 260 270 minecraft:pink_terracotta
setblock 217 259 229 minecraft:pink_concrete
setblock 220 259 270 minecraft:red_terracotta
fill 221 259 270 226 259 270 minecraft:pink_terracotta
setblock 224 259 229 minecraft:red_concrete
fill 225 259 228 230 259 228 minecraft:pink_terracotta
setblock 227 259 270 minecraft:red_terracotta
fill 228 259 270 230 260 270 minecraft:pink_terracotta
setblock 229 259 234 minecraft:pink_concrete
setblock 229 259 241 minecraft:red_concrete
setblock 229 259 256 minecraft:magenta_terracotta
fill 230 259 229 230 260 232 minecraft:pink_terracotta
setblock 230 259 233 minecraft:red_terracotta
fill 230 259 234 230 259 237 minecraft:pink_terracotta
setblock 230 259 238 minecraft:red_terracotta
fill 230 259 239 230 259 250 minecraft:pink_terracotta
setblock 230 259 251 minecraft:red_terracotta
fill 230 259 252 230 259 269 minecraft:pink_terracotta
fill 188 260 228 188 284 233 minecraft:pink_terracotta
setblock 188 260 234 minecraft:red_terracotta
fill 188 260 235 188 284 235 minecraft:pink_terracotta
fill 188 260 240 188 284 240 minecraft:pink_terracotta
fill 188 260 244 188 284 244 minecraft:pink_terracotta
fill 188 260 251 188 284 251 minecraft:pink_terracotta
fill 188 260 253 188 284 253 minecraft:pink_terracotta
fill 188 260 258 188 260 265 minecraft:pink_terracotta
fill 188 260 266 188 261 266 minecraft:red_terracotta
fill 188 260 267 188 284 267 minecraft:pink_terracotta
fill 188 260 269 188 284 269 minecraft:pink_terracotta
setblock 188 260 270 minecraft:red_terracotta
setblock 189 260 243 minecraft:red_concrete
setblock 189 260 253 minecraft:magenta_terracotta
setblock 189 260 255 minecraft:pink_concrete
fill 189 260 270 195 284 270 minecraft:pink_terracotta
fill 190 260 228 190 284 228 minecraft:pink_terracotta
setblock 191 260 231 minecraft:light[level=15]
setblock 191 260 238 minecraft:light[level=15]
setblock 191 260 245 minecraft:light[level=15]
setblock 191 260 252 minecraft:light[level=15]
setblock 191 260 259 minecraft:light[level=15]
setblock 191 260 266 minecraft:light[level=15]
fill 195 260 228 199 284 228 minecraft:pink_terracotta
setblock 198 260 231 minecraft:light[level=15]
setblock 198 260 238 minecraft:light[level=15]
setblock 198 260 245 minecraft:light[level=15]
setblock 198 260 252 minecraft:light[level=15]
setblock 198 260 259 minecraft:light[level=15]
setblock 198 260 266 minecraft:light[level=15]
setblock 200 260 228 minecraft:red_terracotta
fill 201 260 228 225 260 228 minecraft:pink_terracotta
fill 201 260 270 201 284 270 minecraft:pink_terracotta
setblock 205 260 231 minecraft:light[level=15]
setblock 205 260 238 minecraft:light[level=15]
setblock 205 260 245 minecraft:light[level=15]
setblock 205 260 252 minecraft:light[level=15]
setblock 205 260 259 minecraft:light[level=15]
setblock 205 260 266 minecraft:light[level=15]
fill 210 260 270 210 284 270 minecraft:pink_terracotta
setblock 212 260 231 minecraft:light[level=15]
setblock 212 260 238 minecraft:light[level=15]
setblock 212 260 252 minecraft:light[level=15]
setblock 212 260 259 minecraft:light[level=15]
setblock 212 260 266 minecraft:light[level=15]
fill 214 260 270 214 284 270 minecraft:pink_terracotta
setblock 219 260 231 minecraft:light[level=15]
setblock 219 260 238 minecraft:light[level=15]
setblock 219 260 245 minecraft:light[level=15]
setblock 219 260 252 minecraft:light[level=15]
setblock 219 260 259 minecraft:light[level=15]
setblock 219 260 266 minecraft:light[level=15]
fill 220 260 270 224 284 270 minecraft:pink_terracotta
setblock 225 260 270 minecraft:red_terracotta
setblock 226 260 228 minecraft:red_terracotta
setblock 226 260 231 minecraft:light[level=15]
setblock 226 260 238 minecraft:light[level=15]
setblock 226 260 245 minecraft:light[level=15]
setblock 226 260 252 minecraft:light[level=15]
setblock 226 260 259 minecraft:light[level=15]
setblock 226 260 266 minecraft:light[level=15]
fill 226 260 270 227 284 270 minecraft:pink_terracotta
fill 227 260 228 230 260 228 minecraft:pink_terracotta
setblock 229 260 250 minecraft:magenta_terracotta
fill 230 260 233 230 260 234 minecraft:pink_terracotta
setblock 230 260 235 minecraft:red_terracotta
fill 230 260 236 230 260 248 minecraft:pink_terracotta
fill 230 260 249 230 261 249 minecraft:red_terracotta
fill 230 260 250 230 260 258 minecraft:pink_terracotta
setblock 230 260 259 minecraft:red_terracotta
fill 230 260 260 230 260 267 minecraft:pink_terracotta
fill 230 260 268 230 261 268 minecraft:red_terracotta
fill 230 260 269 230 284 269 minecraft:pink_terracotta
fill 188 261 234 188 284 234 minecraft:pink_terracotta
setblock 188 261 236 minecraft:red_terracotta
fill 188 261 237 188 284 239 minecraft:pink_terracotta
fill 188 261 242 188 284 242 minecraft:pink_terracotta
fill 188 261 254 188 284 255 minecraft:pink_terracotta
fill 188 261 256 188 261 257 minecraft:red_terracotta
fill 188 261 258 188 284 259 minecraft:pink_terracotta
setblock 188 261 260 minecraft:red_terracotta
fill 188 261 261 188 284 265 minecraft:pink_terracotta
fill 188 261 270 188 284 270 minecraft:pink_terracotta
fill 189 261 229 228 261 234 minecraft:white_concrete
setblock 189 261 235 minecraft:red_concrete
fill 189 261 236 229 261 242 minecraft:white_concrete
fill 189 261 243 189 282 245 minecraft:cyan_terracotta
fill 189 261 246 189 283 246 minecraft:gray_concrete
setblock 189 261 247 minecraft:magenta_terracotta
fill 189 261 248 189 283 252 minecraft:cyan_terracotta
fill 189 261 253 189 283 253 minecraft:gray_concrete
fill 189 261 254 189 279 259 minecraft:cyan_terracotta
fill 189 261 260 189 278 260 minecraft:gray_concrete
fill 189 261 261 189 270 266 minecraft:cyan_terracotta
fill 189 261 267 189 268 267 minecraft:gray_concrete
fill 189 261 268 190 261 268 minecraft:cyan_terracotta
setblock 189 261 269 minecraft:magenta_terracotta
fill 190 261 235 229 261 235 minecraft:white_concrete
fill 190 261 243 228 261 243 minecraft:white_concrete
fill 190 261 244 190 261 249 minecraft:cyan_terracotta
setblock 190 261 250 minecraft:gray_concrete
fill 190 261 251 190 261 256 minecraft:cyan_terracotta
setblock 190 261 257 minecraft:gray_concrete
fill 190 261 258 190 261 263 minecraft:cyan_terracotta
setblock 190 261 264 minecraft:gray_concrete
fill 190 261 265 191 261 267 minecraft:cyan_terracotta
fill 190 261 269 192 266 269 minecraft:cyan_terracotta
setblock 191 261 228 minecraft:red_terracotta
fill 191 261 244 210 261 244 minecraft:white_concrete
fill 191 261 245 192 261 246 minecraft:cyan_terracotta
setblock 191 261 247 minecraft:gray_concrete
fill 191 261 248 191 261 253 minecraft:cyan_terracotta
setblock 191 261 254 minecraft:gray_concrete
fill 191 261 255 191 261 260 minecraft:cyan_terracotta
setblock 191 261 261 minecraft:gray_concrete
fill 191 261 262 192 261 264 minecraft:cyan_terracotta
setblock 191 261 268 minecraft:gray_concrete
fill 192 261 228 194 284 228 minecraft:pink_terracotta
fill 192 261 247 192 261 250 minecraft:cyan_terracotta
setblock 192 261 251 minecraft:gray_concrete
fill 192 261 252 192 261 257 minecraft:cyan_terracotta
setblock 192 261 258 minecraft:gray_concrete
fill 192 261 259 193 261 261 minecraft:cyan_terracotta
setblock 192 261 265 minecraft:gray_concrete
fill 192 261 266 193 261 268 minecraft:cyan_terracotta
fill 193 261 245 209 261 245 minecraft:white_concrete
fill 193 261 246 193 261 247 minecraft:cyan_terracotta
setblock 193 261 248 minecraft:gray_concrete
fill 193 261 249 193 261 254 minecraft:cyan_terracotta
setblock 193 261 255 minecraft:gray_concrete
fill 193 261 256 194 261 258 minecraft:cyan_terracotta
setblock 193 261 262 minecraft:gray_concrete
fill 193 261 263 194 261 265 minecraft:cyan_terracotta
fill 193 261 269 193 272 269 minecraft:gray_concrete
fill 194 261 246 208 261 246 minecraft:white_concrete
fill 194 261 247 194 261 251 minecraft:cyan_terracotta
setblock 194 261 252 minecraft:gray_concrete
fill 194 261 253 195 261 255 minecraft:cyan_terracotta
setblock 194 261 259 minecraft:gray_concrete
fill 194 261 260 195 261 262 minecraft:cyan_terracotta
setblock 194 261 266 minecraft:gray_concrete
fill 194 261 267 195 261 269 minecraft:cyan_terracotta
fill 195 261 247 195 261 248 minecraft:cyan_terracotta
setblock 195 261 249 minecraft:gray_concrete
fill 195 261 250 196 261 252 minecraft:cyan_terracotta
setblock 195 261 256 minecraft:gray_concrete
fill 195 261 257 196 261 259 minecraft:cyan_terracotta
setblock 195 261 263 minecraft:gray_concrete
fill 195 261 264 196 261 266 minecraft:cyan_terracotta
fill 196 261 247 209 261 247 minecraft:white_concrete
fill 196 261 248 197 261 249 minecraft:cyan_terracotta
setblock 196 261 253 minecraft:gray_concrete
fill 196 261 254 197 261 256 minecraft:cyan_terracotta
setblock 196 261 260 minecraft:gray_concrete
fill 196 261 261 197 261 263 minecraft:cyan_terracotta
setblock 196 261 267 minecraft:gray_concrete
fill 196 261 268 197 261 269 minecraft:cyan_terracotta
fill 196 261 270 198 284 270 minecraft:pink_terracotta
setblock 197 261 250 minecraft:gray_concrete
fill 197 261 251 198 261 253 minecraft:cyan_terracotta
setblock 197 261 257 minecraft:gray_concrete
fill 197 261 258 198 261 260 minecraft:cyan_terracotta
setblock 197 261 264 minecraft:gray_concrete
fill 197 261 265 198 261 267 minecraft:cyan_terracotta
fill 198 261 248 210 261 248 minecraft:white_concrete
fill 198 261 249 200 261 250 minecraft:cyan_terracotta
setblock 198 261 254 minecraft:gray_concrete
fill 198 261 255 199 261 257 minecraft:cyan_terracotta
setblock 198 261 261 minecraft:gray_concrete
fill 198 261 262 199 261 264 minecraft:cyan_terracotta
setblock 198 261 268 minecraft:gray_concrete
fill 198 261 269 199 278 269 minecraft:cyan_terracotta
setblock 199 261 251 minecraft:gray_concrete
fill 199 261 252 200 261 254 minecraft:cyan_terracotta
setblock 199 261 258 minecraft:gray_concrete
fill 199 261 259 200 261 261 minecraft:cyan_terracotta
setblock 199 261 265 minecraft:gray_concrete
fill 199 261 266 200 261 268 minecraft:cyan_terracotta
setblock 199 261 270 minecraft:red_terracotta
fill 200 261 228 206 284 228 minecraft:pink_terracotta
fill 200 261 251 205 261 251 minecraft:cyan_terracotta
setblock 200 261 255 minecraft:gray_concrete
fill 200 261 256 201 261 258 minecraft:cyan_terracotta
setblock 200 261 262 minecraft:gray_concrete
fill 200 261 263 201 261 265 minecraft:cyan_terracotta
fill 200 261 269 200 280 269 minecraft:gray_concrete
fill 200 261 270 200 284 270 minecraft:pink_terracotta
fill 201 261 249 217 261 249 minecraft:white_concrete
fill 201 261 250 203 261 250 minecraft:cyan_terracotta
setblock 201 261 252 minecraft:gray_concrete
fill 201 261 253 202 261 255 minecraft:cyan_terracotta
setblock 201 261 259 minecraft:gray_concrete
fill 201 261 260 202 261 262 minecraft:cyan_terracotta
setblock 201 261 266 minecraft:gray_concrete
fill 201 261 267 201 261 269 minecraft:cyan_terracotta
fill 202 261 252 207 261 252 minecraft:cyan_terracotta
setblock 202 261 256 minecraft:gray_concrete
fill 202 261 257 203 261 259 minecraft:cyan_terracotta
setblock 202 261 263 minecraft:gray_concrete
fill 202 261 264 202 261 268 minecraft:cyan_terracotta
setblock 202 261 269 minecraft:pink_concrete
setblock 203 261 253 minecraft:gray_concrete
fill 203 261 254 204 261 256 minecraft:cyan_terracotta
setblock 203 261 260 minecraft:gray_concrete
fill 203 261 261 203 261 266 minecraft:cyan_terracotta
setblock 203 261 267 minecraft:gray_concrete
fill 203 261 268 204 261 269 minecraft:cyan_terracotta
fill 204 261 250 214 261 250 minecraft:white_concrete
fill 204 261 253 209 261 253 minecraft:cyan_terracotta
setblock 204 261 257 minecraft:gray_concrete
fill 204 261 258 204 261 263 minecraft:cyan_terracotta
setblock 204 261 264 minecraft:gray_concrete
fill 204 261 265 205 261 267 minecraft:cyan_terracotta
setblock 205 261 254 minecraft:gray_concrete
fill 205 261 255 205 261 260 minecraft:cyan_terracotta
setblock 205 261 261 minecraft:gray_concrete
fill 205 261 262 206 261 264 minecraft:cyan_terracotta
setblock 205 261 268 minecraft:gray_concrete
fill 205 261 269 206 283 269 minecraft:cyan_terracotta
setblock 206 261 251 minecraft:gray_concrete
fill 206 261 254 206 261 257 minecraft:cyan_terracotta
setblock 206 261 258 minecraft:gray_concrete
fill 206 261 259 207 261 261 minecraft:cyan_terracotta
setblock 206 261 265 minecraft:gray_concrete
fill 206 261 266 207 261 268 minecraft:cyan_terracotta
setblock 207 261 228 minecraft:red_terracotta
fill 207 261 251 212 261 251 minecraft:cyan_terracotta
fill 207 261 254 211 261 254 minecraft:cyan_terracotta
setblock 207 261 255 minecraft:gray_concrete
fill 207 261 256 208 261 258 minecraft:cyan_terracotta
setblock 207 261 262 minecraft:gray_concrete
fill 207 261 263 208 261 265 minecraft:cyan_terracotta
fill 207 261 269 207 283 269 minecraft:gray_concrete
fill 208 261 228 212 284 228 minecraft:pink_terracotta
setblock 208 261 252 minecraft:gray_concrete
fill 208 261 255 213 261 255 minecraft:cyan_terracotta
setblock 208 261 259 minecraft:gray_concrete
fill 208 261 260 209 261 262 minecraft:cyan_terracotta
setblock 208 261 266 minecraft:gray_concrete
fill 208 261 267 209 261 269 minecraft:cyan_terracotta
fill 209 261 252 214 261 252 minecraft:cyan_terracotta
setblock 209 261 256 minecraft:gray_concrete
fill 209 261 257 210 261 259 minecraft:cyan_terracotta
setblock 209 261 263 minecraft:gray_concrete
fill 209 261 264 210 261 266 minecraft:cyan_terracotta
setblock 210 261 253 minecraft:gray_concrete
fill 210 261 256 215 261 256 minecraft:cyan_terracotta
setblock 210 261 260 minecraft:gray_concrete
fill 210 261 261 211 261 263 minecraft:cyan_terracotta
setblock 210 261 267 minecraft:gray_concrete
fill 210 261 268 211 261 269 minecraft:cyan_terracotta
fill 211 261 253 216 261 253 minecraft:cyan_terracotta
setblock 211 261 257 minecraft:gray_concrete
fill 211 261 258 212 261 260 minecraft:cyan_terracotta
setblock 211 261 264 minecraft:gray_concrete
fill 211 261 265 212 261 267 minecraft:cyan_terracotta
fill 212 261 244 227 261 244 minecraft:white_concrete
fill 212 261 248 220 261 248 minecraft:white_concrete
setblock 212 261 254 minecraft:gray_concrete
fill 212 261 257 217 261 257 minecraft:cyan_terracotta
setblock 212 261 261 minecraft:gray_concrete
fill 212 261 262 213 261 264 minecraft:cyan_terracotta
setblock 212 261 268 minecraft:gray_concrete
fill 212 261 269 213 283 269 minecraft:cyan_terracotta
setblock 213 261 228 minecraft:red_terracotta
fill 213 261 245 225 261 245 minecraft:white_concrete
fill 213 261 247 222 261 247 minecraft:white_concrete
setblock 213 261 251 minecraft:gray_concrete
fill 213 261 254 218 261 254 minecraft:cyan_terracotta
setblock 213 261 258 minecraft:gray_concrete
fill 213 261 259 214 261 261 minecraft:cyan_terracotta
setblock 213 261 265 minecraft:gray_concrete
fill 213 261 266 214 261 268 minecraft:cyan_terracotta
fill 214 261 228 221 284 228 minecraft:pink_terracotta
fill 214 261 246 224 261 246 minecraft:white_concrete
fill 214 261 251 219 261 251 minecraft:cyan_terracotta
setblock 214 261 255 minecraft:gray_concrete
fill 214 261 258 219 261 258 minecraft:cyan_terracotta
setblock 214 261 262 minecraft:gray_concrete
fill 214 261 263 215 261 265 minecraft:cyan_terracotta
fill 214 261 269 214 283 269 minecraft:gray_concrete
fill 215 261 250 217 261 250 minecraft:cyan_terracotta
setblock 215 261 252 minecraft:gray_concrete
fill 215 261 255 220 261 255 minecraft:cyan_terracotta
setblock 215 261 259 minecraft:gray_concrete
fill 215 261 260 216 261 262 minecraft:cyan_terracotta
setblock 215 261 266 minecraft:gray_concrete
fill 215 261 267 216 261 269 minecraft:cyan_terracotta
fill 215 261 270 215 284 270 minecraft:pink_terracotta
fill 216 261 252 221 261 252 minecraft:cyan_terracotta
setblock 216 261 256 minecraft:gray_concrete
fill 216 261 259 221 261 259 minecraft:cyan_terracotta
setblock 216 261 263 minecraft:gray_concrete
fill 216 261 264 217 261 266 minecraft:cyan_terracotta
setblock 216 261 270 minecraft:red_terracotta
setblock 217 261 253 minecraft:gray_concrete
fill 217 261 256 222 261 256 minecraft:cyan_terracotta
setblock 217 261 260 minecraft:gray_concrete
fill 217 261 261 218 261 263 minecraft:cyan_terracotta
setblock 217 261 267 minecraft:gray_concrete
fill 217 261 268 218 261 269 minecraft:cyan_terracotta
fill 217 261 270 219 284 270 minecraft:pink_terracotta
fill 218 261 249 222 261 249 minecraft:cyan_terracotta
setblock 218 261 250 minecraft:gray_concrete
fill 218 261 253 223 261 253 minecraft:cyan_terracotta
setblock 218 261 257 minecraft:gray_concrete
fill 218 261 260 223 261 260 minecraft:cyan_terracotta
setblock 218 261 264 minecraft:gray_concrete
fill 218 261 265 219 261 267 minecraft:cyan_terracotta
fill 219 261 250 224 261 250 minecraft:cyan_terracotta
setblock 219 261 254 minecraft:gray_concrete
fill 219 261 257 224 261 257 minecraft:cyan_terracotta
setblock 219 261 261 minecraft:gray_concrete
fill 219 261 262 220 261 264 minecraft:cyan_terracotta
setblock 219 261 268 minecraft:gray_concrete
fill 219 261 269 220 278 269 minecraft:cyan_terracotta
setblock 220 261 251 minecraft:gray_concrete
fill 220 261 254 225 261 254 minecraft:cyan_terracotta
setblock 220 261 258 minecraft:gray_concrete
fill 220 261 261 225 261 261 minecraft:cyan_terracotta
setblock 220 261 265 minecraft:gray_concrete
fill 220 261 266 221 261 268 minecraft:cyan_terracotta
setblock 221 261 248 minecraft:gray_concrete
fill 221 261 251 226 261 251 minecraft:cyan_terracotta
setblock 221 261 255 minecraft:gray_concrete
fill 221 261 258 226 261 258 minecraft:cyan_terracotta
setblock 221 261 262 minecraft:gray_concrete
fill 221 261 263 222 261 265 minecraft:cyan_terracotta
fill 221 261 269 221 277 269 minecraft:gray_concrete
setblock 222 261 228 minecraft:red_terracotta
fill 222 261 248 227 261 248 minecraft:cyan_terracotta
setblock 222 261 252 minecraft:gray_concrete
fill 222 261 255 227 261 255 minecraft:cyan_terracotta
setblock 222 261 259 minecraft:gray_concrete
fill 222 261 262 227 261 262 minecraft:cyan_terracotta
setblock 222 261 266 minecraft:gray_concrete
fill 222 261 267 223 261 269 minecraft:cyan_terracotta
fill 223 261 228 227 284 228 minecraft:pink_terracotta
fill 223 261 247 225 261 247 minecraft:cyan_terracotta
setblock 223 261 249 minecraft:gray_concrete
fill 223 261 252 228 261 252 minecraft:cyan_terracotta
setblock 223 261 256 minecraft:gray_concrete
fill 223 261 259 228 261 259 minecraft:cyan_terracotta
setblock 223 261 263 minecraft:gray_concrete
fill 223 261 264 224 261 266 minecraft:cyan_terracotta
fill 224 261 249 229 261 249 minecraft:cyan_terracotta
setblock 224 261 253 minecraft:gray_concrete
fill 224 261 256 229 261 256 minecraft:cyan_terracotta
setblock 224 261 260 minecraft:gray_concrete
fill 224 261 263 229 261 263 minecraft:cyan_terracotta
setblock 224 261 267 minecraft:gray_concrete
fill 224 261 268 225 261 269 minecraft:cyan_terracotta
fill 225 261 246 229 261 246 minecraft:cyan_terracotta
setblock 225 261 250 minecraft:gray_concrete
fill 225 261 253 229 261 253 minecraft:cyan_terracotta
setblock 225 261 257 minecraft:gray_concrete
fill 225 261 260 229 261 260 minecraft:cyan_terracotta
setblock 225 261 264 minecraft:gray_concrete
fill 225 261 265 226 261 267 minecraft:cyan_terracotta
fill 225 261 270 225 284 270 minecraft:pink_terracotta
fill 226 261 245 228 261 245 minecraft:cyan_terracotta
setblock 226 261 247 minecraft:gray_concrete
fill 226 261 250 229 261 250 minecraft:cyan_terracotta
setblock 226 261 254 minecraft:gray_concrete
fill 226 261 257 229 261 257 minecraft:cyan_terracotta
setblock 226 261 261 minecraft:gray_concrete
fill 226 261 264 229 261 264 minecraft:cyan_terracotta
setblock 226 261 268 minecraft:gray_concrete
fill 226 261 269 227 268 269 minecraft:cyan_terracotta
fill 227 261 247 229 261 247 minecraft:cyan_terracotta
setblock 227 261 251 minecraft:gray_concrete
fill 227 261 254 229 261 254 minecraft:cyan_terracotta
setblock 227 261 258 minecraft:gray_concrete
fill 227 261 261 229 261 261 minecraft:cyan_terracotta
setblock 227 261 265 minecraft:gray_concrete
fill 227 261 266 228 261 268 minecraft:cyan_terracotta
setblock 228 261 228 minecraft:red_terracotta
fill 228 261 244 229 261 244 minecraft:cyan_terracotta
setblock 228 261 248 minecraft:gray_concrete
fill 228 261 251 229 261 251 minecraft:cyan_terracotta
setblock 228 261 255 minecraft:gray_concrete
fill 228 261 258 229 261 258 minecraft:cyan_terracotta
setblock 228 261 262 minecraft:gray_concrete
fill 228 261 265 229 261 265 minecraft:cyan_terracotta
fill 228 261 269 228 266 269 minecraft:gray_concrete
fill 228 261 270 229 284 270 minecraft:pink_terracotta
fill 229 261 228 230 284 228 minecraft:pink_terracotta
setblock 229 261 229 minecraft:pink_concrete
fill 229 261 230 229 266 234 minecraft:white_concrete
fill 229 261 243 229 282 243 minecraft:cyan_terracotta
fill 229 261 245 229 283 245 minecraft:gray_concrete
fill 229 261 248 229 284 248 minecraft:cyan_terracotta
fill 229 261 252 229 283 252 minecraft:gray_concrete
fill 229 261 255 229 282 255 minecraft:cyan_terracotta
setblock 229 261 259 minecraft:red_concrete
fill 229 261 262 229 276 262 minecraft:cyan_terracotta
fill 229 261 266 229 270 266 minecraft:gray_concrete
fill 229 261 267 229 263 269 minecraft:cyan_terracotta
fill 230 261 229 230 284 231 minecraft:pink_terracotta
setblock 230 261 232 minecraft:red_terracotta
fill 230 261 233 230 284 233 minecraft:pink_terracotta
setblock 230 261 234 minecraft:red_terracotta
fill 230 261 235 230 284 240 minecraft:pink_terracotta
fill 230 261 241 230 261 243 minecraft:red_terracotta
fill 230 261 244 230 284 244 minecraft:pink_terracotta
setblock 230 261 245 minecraft:red_terracotta
fill 230 261 246 230 284 248 minecraft:pink_terracotta
fill 230 261 250 230 284 256 minecraft:pink_terracotta
setblock 230 261 257 minecraft:red_terracotta
fill 230 261 258 230 284 259 minecraft:pink_terracotta
fill 230 261 260 230 261 261 minecraft:red_terracotta
fill 230 261 262 230 284 267 minecraft:pink_terracotta
setblock 230 261 270 minecraft:red_terracotta
fill 188 262 236 188 284 236 minecraft:pink_terracotta
fill 188 262 256 188 284 257 minecraft:pink_terracotta
fill 188 262 260 188 284 260 minecraft:pink_terracotta
fill 188 262 266 188 284 266 minecraft:pink_terracotta
fill 189 262 229 189 263 242 minecraft:white_concrete
fill 189 262 247 189 283 247 minecraft:cyan_terracotta
fill 189 262 268 189 263 269 minecraft:cyan_terracotta
fill 190 262 229 229 263 229 minecraft:white_concrete
fill 190 262 230 208 264 268 minecraft:light_gray_concrete
fill 191 262 228 191 284 228 minecraft:pink_terracotta
fill 194 262 269 197 273 269 minecraft:cyan_terracotta
fill 199 262 270 199 284 270 minecraft:pink_terracotta
fill 201 262 269 204 281 269 minecraft:cyan_terracotta
fill 207 262 228 207 284 228 minecraft:pink_terracotta
fill 208 262 269 211 283 269 minecraft:cyan_terracotta
fill 209 262 230 209 263 245 minecraft:light_gray_concrete
fill 209 262 247 209 263 268 minecraft:light_gray_concrete
fill 210 262 230 210 263 244 minecraft:light_gray_concrete
fill 210 262 248 210 263 268 minecraft:light_gray_concrete
fill 211 262 230 228 264 243 minecraft:light_gray_concrete
fill 211 262 249 228 264 268 minecraft:light_gray_concrete
fill 212 262 244 228 263 244 minecraft:light_gray_concrete
fill 212 262 248 228 263 248 minecraft:light_gray_concrete
fill 213 262 228 213 284 228 minecraft:pink_terracotta
fill 213 262 245 228 263 245 minecraft:light_gray_concrete
fill 213 262 247 228 263 247 minecraft:light_gray_concrete
fill 214 262 246 228 264 246 minecraft:light_gray_concrete
fill 215 262 269 218 280 269 minecraft:cyan_terracotta
fill 216 262 270 216 284 270 minecraft:pink_terracotta
fill 222 262 228 222 284 228 minecraft:pink_terracotta
fill 222 262 269 225 272 269 minecraft:cyan_terracotta
fill 228 262 228 228 284 228 minecraft:pink_terracotta
fill 229 262 235 229 275 242 minecraft:white_concrete
fill 229 262 244 229 283 244 minecraft:cyan_terracotta
fill 229 262 246 229 283 247 minecraft:cyan_terracotta
fill 229 262 249 229 283 251 minecraft:cyan_terracotta
fill 229 262 253 229 283 254 minecraft:cyan_terracotta
fill 229 262 256 229 280 258 minecraft:cyan_terracotta
fill 229 262 259 229 279 259 minecraft:gray_concrete
fill 229 262 260 229 277 261 minecraft:cyan_terracotta
fill 229 262 263 229 272 265 minecraft:cyan_terracotta
fill 230 262 232 230 284 232 minecraft:pink_terracotta
fill 230 262 234 230 284 234 minecraft:pink_terracotta
fill 230 262 241 230 284 243 minecraft:pink_terracotta
fill 230 262 245 230 284 245 minecraft:pink_terracotta
fill 230 262 249 230 284 249 minecraft:pink_terracotta
fill 230 262 257 230 284 257 minecraft:pink_terracotta
fill 230 262 260 230 284 261 minecraft:pink_terracotta
fill 230 262 268 230 284 268 minecraft:pink_terracotta
fill 230 262 270 230 284 270 minecraft:pink_terracotta
fill 189 264 230 189 266 242 minecraft:white_concrete
fill 189 264 268 189 266 268 minecraft:cyan_terracotta
fill 190 264 229 228 266 229 minecraft:white_concrete
fill 209 264 230 209 264 244 minecraft:light_gray_concrete
setblock 209 264 245 minecraft:red_terracotta
fill 209 264 247 209 264 248 minecraft:red_terracotta
fill 209 264 249 210 264 268 minecraft:light_gray_concrete
fill 210 264 230 210 264 243 minecraft:light_gray_concrete
setblock 210 264 244 minecraft:red_terracotta
setblock 210 264 248 minecraft:red_terracotta
setblock 212 264 244 minecraft:red_terracotta
setblock 212 264 248 minecraft:red_terracotta
fill 213 264 244 228 264 244 minecraft:light_gray_concrete
setblock 213 264 245 minecraft:red_terracotta
setblock 213 264 247 minecraft:red_terracotta
fill 213 264 248 228 264 248 minecraft:light_gray_concrete
fill 214 264 245 228 264 245 minecraft:light_gray_concrete
fill 214 264 247 228 264 247 minecraft:light_gray_concrete
fill 229 264 267 229 266 268 minecraft:cyan_terracotta
fill 190 265 230 207 265 268 minecraft:light_gray_concrete
fill 208 265 230 208 265 244 minecraft:light_gray_concrete
fill 208 265 245 208 265 247 minecraft:shroomlight
fill 208 265 248 208 266 248 minecraft:pink_terracotta
fill 208 265 249 208 266 268 minecraft:light_gray_concrete
fill 209 265 230 209 265 243 minecraft:light_gray_concrete
fill 209 265 244 209 265 245 minecraft:shroomlight
fill 209 265 247 209 265 248 minecraft:shroomlight
fill 209 265 249 209 266 249 minecraft:pink_terracotta
fill 209 265 250 228 265 268 minecraft:light_gray_concrete
fill 210 265 230 228 266 242 minecraft:light_gray_concrete
fill 210 265 243 210 265 244 minecraft:shroomlight
fill 210 265 248 210 265 249 minecraft:shroomlight
fill 211 265 243 212 265 243 minecraft:shroomlight
fill 211 265 249 212 265 249 minecraft:shroomlight
fill 212 265 244 213 265 244 minecraft:shroomlight
fill 212 265 248 213 265 248 minecraft:shroomlight
fill 213 265 243 228 265 243 minecraft:light_gray_concrete
fill 213 265 245 214 265 245 minecraft:shroomlight
fill 213 265 247 214 265 247 minecraft:shroomlight
fill 213 265 249 228 265 249 minecraft:light_gray_concrete
fill 214 265 244 228 265 244 minecraft:light_gray_concrete
setblock 214 265 246 minecraft:shroomlight
fill 214 265 248 228 265 248 minecraft:light_gray_concrete
fill 215 265 245 228 265 247 minecraft:light_gray_concrete
fill 190 266 230 206 266 268 minecraft:light_gray_concrete
fill 207 266 230 207 267 244 minecraft:light_gray_concrete
fill 207 266 245 207 266 247 minecraft:pink_terracotta
fill 207 266 248 207 266 268 minecraft:light_gray_concrete
fill 208 266 230 208 267 243 minecraft:light_gray_concrete
setblock 208 266 244 minecraft:pink_terracotta
fill 209 266 230 209 268 242 minecraft:light_gray_concrete
fill 209 266 243 213 266 243 minecraft:pink_terracotta
fill 209 266 250 209 266 268 minecraft:light_gray_concrete
fill 210 266 250 212 266 250 minecraft:pink_terracotta
fill 210 266 251 228 266 268 minecraft:light_gray_concrete
setblock 213 266 249 minecraft:pink_terracotta
fill 213 266 250 228 267 250 minecraft:light_gray_concrete
fill 214 266 243 228 269 243 minecraft:light_gray_concrete
fill 214 266 244 214 266 245 minecraft:pink_terracotta
fill 214 266 247 214 266 248 minecraft:pink_terracotta
fill 214 266 249 228 267 249 minecraft:light_gray_concrete
fill 215 266 244 228 266 245 minecraft:light_gray_concrete
setblock 215 266 246 minecraft:pink_terracotta
fill 215 266 247 228 266 248 minecraft:light_gray_concrete
fill 216 266 246 228 269 246 minecraft:light_gray_concrete
fill 189 267 231 189 268 242 minecraft:white_concrete
fill 190 267 230 190 268 230 minecraft:white_concrete
fill 190 267 231 206 267 267 minecraft:light_gray_concrete
fill 190 267 268 190 268 268 minecraft:cyan_terracotta
fill 191 267 229 227 268 229 minecraft:white_concrete
fill 191 267 230 206 268 230 minecraft:light_gray_concrete
fill 191 267 268 227 268 268 minecraft:light_gray_concrete
fill 191 267 269 192 268 269 minecraft:cyan_terracotta
fill 207 267 245 207 267 248 minecraft:red_terracotta
fill 207 267 249 207 267 267 minecraft:light_gray_concrete
setblock 208 267 244 minecraft:red_terracotta
setblock 208 267 249 minecraft:red_terracotta
fill 208 267 250 208 267 267 minecraft:light_gray_concrete
fill 209 267 243 210 267 243 minecraft:red_terracotta
fill 209 267 250 212 267 250 minecraft:red_terracotta
fill 209 267 251 228 267 267 minecraft:light_gray_concrete
fill 210 267 230 210 267 242 minecraft:light_gray_concrete
fill 211 267 230 227 268 241 minecraft:light_gray_concrete
setblock 211 267 242 minecraft:red_terracotta
fill 212 267 242 228 267 242 minecraft:light_gray_concrete
fill 212 267 243 213 267 243 minecraft:red_terracotta
setblock 213 267 249 minecraft:red_terracotta
setblock 214 267 244 minecraft:red_terracotta
setblock 214 267 248 minecraft:red_terracotta
fill 215 267 244 228 269 244 minecraft:light_gray_concrete
fill 215 267 245 215 267 247 minecraft:red_terracotta
fill 215 267 248 228 267 248 minecraft:light_gray_concrete
fill 216 267 245 228 270 245 minecraft:light_gray_concrete
fill 216 267 247 228 269 247 minecraft:light_gray_concrete
fill 228 267 230 228 268 230 minecraft:white_concrete
fill 228 267 231 228 268 241 minecraft:light_gray_concrete
fill 228 267 268 228 268 268 minecraft:cyan_terracotta
fill 229 267 231 229 268 234 minecraft:white_concrete
fill 229 267 267 229 268 267 minecraft:cyan_terracotta
fill 190 268 231 205 268 267 minecraft:light_gray_concrete
fill 206 268 231 206 268 245 minecraft:light_gray_concrete
fill 206 268 246 206 269 247 minecraft:pink_terracotta
fill 206 268 248 206 268 267 minecraft:light_gray_concrete
fill 207 268 230 207 269 243 minecraft:light_gray_concrete
fill 207 268 244 207 268 245 minecraft:pink_terracotta
fill 207 268 248 207 268 249 minecraft:pink_terracotta
fill 207 268 250 207 269 267 minecraft:light_gray_concrete
fill 208 268 230 208 270 242 minecraft:light_gray_concrete
fill 208 268 243 209 268 243 minecraft:pink_terracotta
fill 208 268 250 210 268 250 minecraft:pink_terracotta
fill 208 268 251 210 268 267 minecraft:light_gray_concrete
fill 210 268 230 210 272 241 minecraft:light_gray_concrete
fill 210 268 242 212 269 242 minecraft:pink_terracotta
fill 211 268 251 211 269 251 minecraft:pink_terracotta
fill 211 268 252 228 268 267 minecraft:light_gray_concrete
fill 212 268 250 213 268 250 minecraft:pink_terracotta
fill 212 268 251 228 268 251 minecraft:light_gray_concrete
fill 213 268 242 228 270 242 minecraft:light_gray_concrete
fill 213 268 243 213 269 243 minecraft:pink_terracotta
fill 214 268 244 214 269 244 minecraft:pink_terracotta
setblock 214 268 249 minecraft:pink_terracotta
fill 214 268 250 228 268 250 minecraft:light_gray_concrete
fill 215 268 245 215 269 248 minecraft:pink_terracotta
fill 215 268 249 228 268 249 minecraft:light_gray_concrete
fill 216 268 248 228 269 248 minecraft:light_gray_concrete
fill 189 269 232 189 270 242 minecraft:white_concrete
fill 190 269 231 190 270 231 minecraft:white_concrete
fill 190 269 232 205 269 266 minecraft:light_gray_concrete
fill 190 269 267 190 270 267 minecraft:cyan_terracotta
fill 191 269 230 191 270 230 minecraft:white_concrete
fill 191 269 231 206 270 231 minecraft:light_gray_concrete
fill 191 269 267 206 270 267 minecraft:light_gray_concrete
fill 191 269 268 191 270 268 minecraft:gray_concrete
fill 192 269 229 226 270 229 minecraft:white_concrete
fill 192 269 230 206 270 230 minecraft:light_gray_concrete
fill 192 269 268 226 270 268 minecraft:light_gray_concrete
fill 192 269 269 192 270 269 minecraft:cyan_terracotta
fill 206 269 232 206 269 244 minecraft:light_gray_concrete
setblock 206 269 245 minecraft:pink_terracotta
setblock 206 269 248 minecraft:pink_terracotta
fill 206 269 249 206 269 266 minecraft:light_gray_concrete
setblock 207 269 244 minecraft:pink_terracotta
setblock 207 269 249 minecraft:pink_terracotta
setblock 208 269 243 minecraft:pink_terracotta
setblock 208 269 250 minecraft:pink_terracotta
fill 208 269 251 208 269 267 minecraft:light_gray_concrete
fill 209 269 230 209 273 241 minecraft:light_gray_concrete
setblock 209 269 242 minecraft:pink_terracotta
fill 209 269 251 210 269 251 minecraft:pink_terracotta
fill 209 269 252 227 270 267 minecraft:light_gray_concrete
fill 211 269 230 226 270 241 minecraft:light_gray_concrete
setblock 212 269 251 minecraft:pink_terracotta
fill 213 269 250 214 269 250 minecraft:pink_terracotta
fill 213 269 251 228 269 251 minecraft:light_gray_concrete
setblock 215 269 249 minecraft:pink_terracotta
fill 215 269 250 228 270 250 minecraft:light_gray_concrete
fill 216 269 249 228 271 249 minecraft:light_gray_concrete
fill 226 269 269 226 270 269 minecraft:cyan_terracotta
fill 227 269 230 227 270 230 minecraft:white_concrete
fill 227 269 231 227 270 241 minecraft:light_gray_concrete
fill 227 269 268 227 270 268 minecraft:cyan_terracotta
fill 228 269 231 228 270 231 minecraft:white_concrete
fill 228 269 232 228 270 241 minecraft:light_gray_concrete
fill 228 269 252 228 270 266 minecraft:light_gray_concrete
fill 228 269 267 228 270 267 minecraft:cyan_terracotta
fill 229 269 232 229 270 234 minecraft:white_concrete
fill 190 270 232 204 270 266 minecraft:light_gray_concrete
fill 205 270 232 205 270 245 minecraft:light_gray_concrete
fill 205 270 246 205 270 247 minecraft:red_terracotta
fill 205 270 248 205 270 266 minecraft:light_gray_concrete
fill 206 270 232 206 271 243 minecraft:light_gray_concrete
fill 206 270 244 206 270 245 minecraft:red_terracotta
fill 206 270 248 206 270 249 minecraft:red_terracotta
fill 206 270 250 206 270 266 minecraft:light_gray_concrete
fill 207 270 230 207 272 242 minecraft:light_gray_concrete
fill 207 270 243 208 270 243 minecraft:red_terracotta
setblock 207 270 250 minecraft:red_terracotta
fill 207 270 251 207 270 267 minecraft:light_gray_concrete
fill 208 270 251 213 270 251 minecraft:red_terracotta
fill 208 270 252 208 271 267 minecraft:light_gray_concrete
fill 209 270 242 212 270 242 minecraft:red_terracotta
fill 213 270 243 214 270 243 minecraft:red_terracotta
setblock 214 270 250 minecraft:red_terracotta
fill 214 270 251 228 270 251 minecraft:light_gray_concrete
fill 215 270 243 228 272 243 minecraft:light_gray_concrete
fill 215 270 244 215 270 245 minecraft:red_terracotta
setblock 215 270 249 minecraft:red_terracotta
fill 216 270 244 228 272 244 minecraft:light_gray_concrete
fill 216 270 246 216 270 248 minecraft:red_terracotta
fill 217 270 246 228 272 248 minecraft:light_gray_concrete
fill 189 271 233 189 272 242 minecraft:white_concrete
fill 189 271 261 189 272 265 minecraft:cyan_terracotta
fill 190 271 232 190 272 232 minecraft:white_concrete
fill 190 271 233 204 271 265 minecraft:light_gray_concrete
fill 190 271 266 190 272 266 minecraft:cyan_terracotta
fill 191 271 231 191 272 231 minecraft:white_concrete
fill 191 271 232 205 272 232 minecraft:light_gray_concrete
fill 191 271 266 207 272 266 minecraft:light_gray_concrete
fill 191 271 267 191 272 267 minecraft:cyan_terracotta
fill 192 271 230 192 272 230 minecraft:white_concrete
fill 192 271 231 206 272 231 minecraft:light_gray_concrete
fill 192 271 267 207 272 267 minecraft:light_gray_concrete
fill 192 271 268 192 272 268 minecraft:cyan_terracotta
fill 193 271 229 225 272 229 minecraft:white_concrete
fill 193 271 230 206 272 230 minecraft:light_gray_concrete
fill 193 271 268 225 272 268 minecraft:light_gray_concrete
fill 205 271 233 205 271 244 minecraft:light_gray_concrete
fill 205 271 245 205 271 249 minecraft:pink_terracotta
fill 205 271 250 205 272 265 minecraft:light_gray_concrete
setblock 206 271 244 minecraft:pink_terracotta
fill 206 271 250 206 272 250 minecraft:pink_terracotta
fill 206 271 251 206 272 265 minecraft:light_gray_concrete
fill 207 271 243 207 272 243 minecraft:pink_terracotta
fill 207 271 251 208 271 251 minecraft:pink_terracotta
fill 207 271 252 207 272 265 minecraft:light_gray_concrete
fill 208 271 230 208 274 241 minecraft:light_gray_concrete
fill 208 271 242 213 272 242 minecraft:pink_terracotta
fill 209 271 252 212 272 252 minecraft:pink_terracotta
fill 209 271 253 226 272 267 minecraft:light_gray_concrete
fill 211 271 230 225 272 241 minecraft:light_gray_concrete
fill 213 271 251 214 271 251 minecraft:pink_terracotta
fill 213 271 252 228 271 252 minecraft:light_gray_concrete
fill 214 271 242 228 272 242 minecraft:light_gray_concrete
fill 214 271 243 214 272 243 minecraft:pink_terracotta
fill 215 271 244 215 272 244 minecraft:pink_terracotta
fill 215 271 249 215 271 250 minecraft:pink_terracotta
fill 215 271 251 228 272 251 minecraft:light_gray_concrete
fill 216 271 245 216 272 248 minecraft:pink_terracotta
fill 216 271 250 228 272 250 minecraft:light_gray_concrete
fill 217 271 245 228 273 245 minecraft:light_gray_concrete
fill 226 271 230 226 272 230 minecraft:white_concrete
fill 226 271 231 226 272 241 minecraft:light_gray_concrete
fill 226 271 268 226 272 268 minecraft:gray_concrete
fill 227 271 231 227 272 231 minecraft:white_concrete
fill 227 271 232 227 272 241 minecraft:light_gray_concrete
fill 227 271 253 227 272 266 minecraft:light_gray_concrete
fill 227 271 267 227 272 267 minecraft:cyan_terracotta
fill 228 271 232 228 272 232 minecraft:white_concrete
fill 228 271 233 228 272 241 minecraft:light_gray_concrete
fill 228 271 253 228 272 265 minecraft:light_gray_concrete
fill 228 271 266 228 272 266 minecraft:cyan_terracotta
fill 229 271 233 229 272 234 minecraft:white_concrete
fill 190 272 233 203 272 265 minecraft:light_gray_concrete
fill 204 272 233 204 272 245 minecraft:light_gray_concrete
fill 204 272 246 204 272 248 minecraft:pink_terracotta
fill 204 272 249 204 272 265 minecraft:light_gray_concrete
fill 205 272 233 205 274 243 minecraft:light_gray_concrete
fill 205 272 244 205 272 245 minecraft:pink_terracotta
setblock 205 272 249 minecraft:pink_terracotta
fill 206 272 232 206 274 242 minecraft:light_gray_concrete
setblock 206 272 243 minecraft:pink_terracotta
setblock 207 272 251 minecraft:pink_terracotta
setblock 208 272 252 minecraft:pink_terracotta
fill 208 272 253 208 273 267 minecraft:light_gray_concrete
setblock 212 272 245 minecraft:light[level=15]
setblock 213 272 252 minecraft:pink_terracotta
setblock 214 272 251 minecraft:pink_terracotta
fill 214 272 252 228 272 252 minecraft:light_gray_concrete
setblock 215 272 250 minecraft:pink_terracotta
setblock 216 272 249 minecraft:pink_terracotta
fill 217 272 249 228 273 249 minecraft:light_gray_concrete
fill 189 273 234 189 273 242 minecraft:white_concrete
fill 189 273 261 189 273 264 minecraft:cyan_terracotta
fill 190 273 233 190 274 233 minecraft:white_concrete
fill 190 273 234 203 273 264 minecraft:light_gray_concrete
fill 190 273 265 190 274 265 minecraft:cyan_terracotta
fill 191 273 232 191 274 232 minecraft:white_concrete
fill 191 273 233 204 274 233 minecraft:light_gray_concrete
fill 191 273 265 207 274 265 minecraft:light_gray_concrete
fill 191 273 266 191 274 266 minecraft:cyan_terracotta
fill 192 273 231 192 274 231 minecraft:white_concrete
fill 192 273 232 205 274 232 minecraft:light_gray_concrete
fill 192 273 266 207 274 266 minecraft:light_gray_concrete
fill 192 273 267 192 274 267 minecraft:cyan_terracotta
fill 193 273 230 193 274 230 minecraft:white_concrete
fill 193 273 231 207 274 231 minecraft:light_gray_concrete
fill 193 273 267 207 274 267 minecraft:light_gray_concrete
fill 193 273 268 193 274 268 minecraft:cyan_terracotta
fill 194 273 229 224 273 229 minecraft:white_concrete
fill 194 273 230 207 273 230 minecraft:light_gray_concrete
fill 194 273 268 224 273 268 minecraft:light_gray_concrete
fill 204 273 234 204 274 244 minecraft:light_gray_concrete
fill 204 273 245 204 273 249 minecraft:red_terracotta
fill 204 273 250 204 273 264 minecraft:light_gray_concrete
setblock 205 273 244 minecraft:red_terracotta
setblock 205 273 250 minecraft:red_terracotta
fill 205 273 251 205 273 264 minecraft:light_gray_concrete
setblock 206 273 243 minecraft:red_terracotta
setblock 206 273 251 minecraft:red_terracotta
fill 206 273 252 206 273 264 minecraft:light_gray_concrete
fill 207 273 232 207 275 241 minecraft:light_gray_concrete
fill 207 273 242 209 273 242 minecraft:red_terracotta
fill 207 273 252 208 273 252 minecraft:red_terracotta
fill 207 273 253 207 274 264 minecraft:light_gray_concrete
fill 209 273 253 211 273 253 minecraft:red_terracotta
fill 209 273 254 225 274 267 minecraft:light_gray_concrete
fill 210 273 230 224 273 240 minecraft:light_gray_concrete
fill 210 273 241 211 273 241 minecraft:red_terracotta
fill 212 273 241 228 273 241 minecraft:light_gray_concrete
fill 212 273 242 214 273 242 minecraft:red_terracotta
fill 212 273 252 214 273 252 minecraft:red_terracotta
fill 212 273 253 228 273 253 minecraft:light_gray_concrete
fill 215 273 242 228 276 242 minecraft:light_gray_concrete
setblock 215 273 243 minecraft:red_terracotta
setblock 215 273 251 minecraft:red_terracotta
fill 215 273 252 228 274 252 minecraft:light_gray_concrete
fill 216 273 243 228 276 243 minecraft:light_gray_concrete
fill 216 273 244 216 273 245 minecraft:red_terracotta
fill 216 273 249 216 273 250 minecraft:red_terracotta
fill 216 273 251 228 274 251 minecraft:light_gray_concrete
fill 217 273 244 228 276 244 minecraft:light_gray_concrete
fill 217 273 246 217 273 248 minecraft:red_terracotta
fill 217 273 250 228 274 250 minecraft:light_gray_concrete
fill 218 273 246 228 275 248 minecraft:light_gray_concrete
fill 222 273 269 224 273 269 minecraft:cyan_terracotta
fill 225 273 230 225 274 230 minecraft:white_concrete
fill 225 273 231 225 274 240 minecraft:light_gray_concrete
fill 225 273 268 225 274 268 minecraft:cyan_terracotta
fill 226 273 231 226 274 231 minecraft:white_concrete
fill 226 273 232 226 274 240 minecraft:light_gray_concrete
fill 226 273 254 226 274 266 minecraft:light_gray_concrete
fill 226 273 267 226 274 267 minecraft:cyan_terracotta
fill 227 273 232 227 274 232 minecraft:white_concrete
fill 227 273 233 227 274 240 minecraft:light_gray_concrete
fill 227 273 254 227 274 265 minecraft:light_gray_concrete
fill 227 273 266 227 274 266 minecraft:cyan_terracotta
fill 228 273 233 228 274 233 minecraft:white_concrete
fill 228 273 234 228 273 240 minecraft:light_gray_concrete
fill 228 273 254 228 273 264 minecraft:light_gray_concrete
fill 228 273 265 228 274 265 minecraft:cyan_terracotta
setblock 229 273 234 minecraft:white_concrete
fill 229 273 263 229 273 264 minecraft:cyan_terracotta
fill 189 274 235 189 275 242 minecraft:white_concrete
fill 189 274 261 189 275 263 minecraft:cyan_terracotta
fill 190 274 234 190 275 234 minecraft:white_concrete
fill 190 274 235 202 275 263 minecraft:light_gray_concrete
fill 190 274 264 190 275 264 minecraft:gray_concrete
fill 191 274 234 203 275 234 minecraft:light_gray_concrete
fill 191 274 264 206 275 264 minecraft:light_gray_concrete
fill 194 274 230 194 275 230 minecraft:white_concrete
fill 194 274 268 194 275 268 minecraft:cyan_terracotta
fill 195 274 229 223 275 229 minecraft:white_concrete
fill 195 274 230 207 275 230 minecraft:light_gray_concrete
fill 195 274 268 223 275 268 minecraft:light_gray_concrete
fill 195 274 269 197 275 269 minecraft:cyan_terracotta
fill 203 274 235 203 274 246 minecraft:light_gray_concrete
fill 203 274 247 203 275 248 minecraft:pink_terracotta
fill 203 274 249 203 274 263 minecraft:light_gray_concrete
fill 204 274 245 204 274 246 minecraft:pink_terracotta
fill 204 274 249 204 274 250 minecraft:pink_terracotta
fill 204 274 251 204 275 263 minecraft:light_gray_concrete
setblock 205 274 244 minecraft:pink_terracotta
fill 205 274 251 205 275 251 minecraft:pink_terracotta
fill 205 274 252 205 275 263 minecraft:light_gray_concrete
setblock 206 274 243 minecraft:pink_terracotta
fill 206 274 252 207 274 252 minecraft:pink_terracotta
fill 206 274 253 206 275 263 minecraft:light_gray_concrete
fill 207 274 242 208 274 242 minecraft:pink_terracotta
fill 208 274 253 213 275 253 minecraft:pink_terracotta
fill 208 274 254 208 275 267 minecraft:light_gray_concrete
fill 209 274 230 223 275 240 minecraft:light_gray_concrete
fill 209 274 241 212 275 241 minecraft:pink_terracotta
fill 213 274 241 228 275 241 minecraft:light_gray_concrete
fill 213 274 242 214 275 242 minecraft:pink_terracotta
fill 214 274 252 214 275 252 minecraft:pink_terracotta
fill 214 274 253 228 275 253 minecraft:light_gray_concrete
fill 215 274 243 215 275 243 minecraft:pink_terracotta
setblock 215 274 251 minecraft:pink_terracotta
fill 216 274 244 216 275 244 minecraft:pink_terracotta
setblock 216 274 250 minecraft:pink_terracotta
fill 217 274 245 217 275 249 minecraft:pink_terracotta
fill 218 274 245 228 277 245 minecraft:light_gray_concrete
fill 218 274 249 228 276 249 minecraft:light_gray_concrete
fill 222 274 269 223 275 269 minecraft:cyan_terracotta
fill 224 274 230 224 275 230 minecraft:white_concrete
fill 224 274 231 224 275 240 minecraft:light_gray_concrete
fill 224 274 268 224 275 268 minecraft:cyan_terracotta
fill 228 274 234 228 275 234 minecraft:white_concrete
fill 228 274 235 228 275 240 minecraft:light_gray_concrete
fill 228 274 254 228 275 263 minecraft:light_gray_concrete
fill 228 274 264 228 275 264 minecraft:cyan_terracotta
fill 229 274 263 229 275 263 minecraft:cyan_terracotta
fill 191 275 233 191 276 233 minecraft:white_concrete
fill 191 275 265 191 276 265 minecraft:cyan_terracotta
fill 192 275 232 192 276 232 minecraft:white_concrete
fill 192 275 233 206 276 233 minecraft:light_gray_concrete
fill 192 275 265 207 276 265 minecraft:light_gray_concrete
fill 192 275 266 192 276 266 minecraft:cyan_terracotta
fill 193 275 231 193 276 231 minecraft:white_concrete
fill 193 275 232 206 276 232 minecraft:light_gray_concrete
fill 193 275 266 207 276 266 minecraft:light_gray_concrete
fill 193 275 267 193 276 267 minecraft:cyan_terracotta
fill 194 275 231 208 275 231 minecraft:light_gray_concrete
fill 194 275 267 207 275 267 minecraft:light_gray_concrete
fill 203 275 235 203 276 244 minecraft:light_gray_concrete
fill 203 275 245 203 275 246 minecraft:pink_terracotta
setblock 203 275 249 minecraft:pink_terracotta
fill 203 275 250 203 275 263 minecraft:light_gray_concrete
fill 204 275 234 204 276 243 minecraft:light_gray_concrete
setblock 204 275 244 minecraft:pink_terracotta
setblock 204 275 250 minecraft:pink_terracotta
fill 205 275 234 205 276 242 minecraft:light_gray_concrete
setblock 205 275 243 minecraft:pink_terracotta
fill 206 275 234 206 277 241 minecraft:light_gray_concrete
fill 206 275 242 207 275 242 minecraft:pink_terracotta
setblock 206 275 252 minecraft:pink_terracotta
setblock 207 275 253 minecraft:pink_terracotta
fill 207 275 254 207 276 264 minecraft:light_gray_concrete
fill 208 275 230 208 284 230 minecraft:light_gray_concrete
fill 208 275 232 208 279 240 minecraft:light_gray_concrete
setblock 208 275 241 minecraft:pink_terracotta
fill 209 275 254 224 275 267 minecraft:light_gray_concrete
setblock 215 275 252 minecraft:pink_terracotta
setblock 216 275 251 minecraft:pink_terracotta
fill 216 275 252 228 276 252 minecraft:light_gray_concrete
setblock 217 275 250 minecraft:pink_terracotta
fill 217 275 251 228 276 251 minecraft:light_gray_concrete
fill 218 275 250 228 277 250 minecraft:light_gray_concrete
fill 225 275 231 225 276 231 minecraft:white_concrete
fill 225 275 232 225 276 240 minecraft:light_gray_concrete
fill 225 275 254 225 276 266 minecraft:light_gray_concrete
fill 225 275 267 225 276 267 minecraft:cyan_terracotta
fill 226 275 232 226 276 232 minecraft:white_concrete
fill 226 275 233 226 276 240 minecraft:light_gray_concrete
fill 226 275 254 226 276 265 minecraft:light_gray_concrete
fill 226 275 266 226 276 266 minecraft:cyan_terracotta
fill 227 275 233 227 276 233 minecraft:white_concrete
fill 227 275 234 227 275 240 minecraft:light_gray_concrete
fill 227 275 254 227 275 264 minecraft:light_gray_concrete
fill 227 275 265 227 276 265 minecraft:gray_concrete
fill 189 276 236 189 276 242 minecraft:white_concrete
fill 189 276 261 189 276 262 minecraft:cyan_terracotta
fill 190 276 235 190 277 235 minecraft:white_concrete
fill 190 276 236 201 276 262 minecraft:light_gray_concrete
fill 190 276 263 190 277 263 minecraft:cyan_terracotta
fill 191 276 234 191 277 234 minecraft:white_concrete
fill 191 276 235 202 277 235 minecraft:light_gray_concrete
fill 191 276 263 206 277 263 minecraft:light_gray_concrete
fill 191 276 264 191 277 264 minecraft:cyan_terracotta
fill 192 276 234 203 277 234 minecraft:light_gray_concrete
fill 192 276 264 206 277 264 minecraft:light_gray_concrete
fill 194 276 231 194 277 231 minecraft:white_concrete
fill 194 276 267 194 277 267 minecraft:cyan_terracotta
fill 195 276 230 195 277 230 minecraft:white_concrete
fill 195 276 231 223 277 231 minecraft:light_gray_concrete
fill 195 276 267 223 277 267 minecraft:light_gray_concrete
fill 195 276 268 195 277 268 minecraft:cyan_terracotta
fill 196 276 229 222 276 229 minecraft:white_concrete
fill 196 276 230 207 276 230 minecraft:light_gray_concrete
fill 196 276 268 222 276 268 minecraft:light_gray_concrete
fill 196 276 269 197 276 269 minecraft:cyan_terracotta
fill 202 276 236 202 276 246 minecraft:light_gray_concrete
fill 202 276 247 202 276 248 minecraft:red_terracotta
fill 202 276 249 202 276 262 minecraft:light_gray_concrete
fill 203 276 245 203 276 246 minecraft:red_terracotta
fill 203 276 249 203 276 250 minecraft:red_terracotta
fill 203 276 251 203 276 262 minecraft:light_gray_concrete
setblock 204 276 244 minecraft:red_terracotta
setblock 204 276 251 minecraft:red_terracotta
fill 204 276 252 204 276 262 minecraft:light_gray_concrete
setblock 205 276 243 minecraft:red_terracotta
setblock 205 276 252 minecraft:red_terracotta
fill 205 276 253 205 276 262 minecraft:light_gray_concrete
setblock 206 276 242 minecraft:red_terracotta
fill 206 276 253 207 276 253 minecraft:red_terracotta
fill 206 276 254 206 277 262 minecraft:light_gray_concrete
fill 207 276 232 207 280 240 minecraft:light_gray_concrete
fill 207 276 241 213 276 241 minecraft:red_terracotta
fill 208 276 254 212 276 254 minecraft:red_terracotta
fill 208 276 255 224 277 266 minecraft:light_gray_concrete
fill 209 276 230 222 276 230 minecraft:light_gray_concrete
fill 209 276 232 224 277 240 minecraft:light_gray_concrete
fill 213 276 253 214 276 253 minecraft:red_terracotta
fill 213 276 254 224 276 254 minecraft:light_gray_concrete
fill 214 276 241 228 277 241 minecraft:light_gray_concrete
setblock 214 276 242 minecraft:red_terracotta
setblock 215 276 243 minecraft:red_terracotta
setblock 215 276 252 minecraft:red_terracotta
fill 215 276 253 228 276 253 minecraft:light_gray_concrete
setblock 216 276 244 minecraft:red_terracotta
setblock 216 276 251 minecraft:red_terracotta
setblock 217 276 245 minecraft:red_terracotta
fill 217 276 249 217 276 250 minecraft:red_terracotta
fill 218 276 246 218 276 248 minecraft:red_terracotta
fill 219 276 246 228 278 248 minecraft:light_gray_concrete
setblock 222 276 269 minecraft:cyan_terracotta
fill 223 276 230 223 277 230 minecraft:white_concrete
fill 223 276 268 223 277 268 minecraft:cyan_terracotta
fill 224 276 231 224 277 231 minecraft:white_concrete
fill 224 276 267 224 277 267 minecraft:gray_concrete
fill 227 276 234 227 277 234 minecraft:white_concrete
fill 227 276 235 227 277 240 minecraft:light_gray_concrete
fill 227 276 254 227 277 263 minecraft:light_gray_concrete
fill 227 276 264 227 277 264 minecraft:cyan_terracotta
fill 228 276 235 228 277 235 minecraft:white_concrete
fill 228 276 236 228 276 240 minecraft:light_gray_concrete
fill 228 276 254 228 276 262 minecraft:light_gray_concrete
fill 228 276 263 228 277 263 minecraft:cyan_terracotta
fill 229 276 236 229 276 242 minecraft:white_concrete
fill 189 277 237 189 277 242 minecraft:white_concrete
setblock 189 277 261 minecraft:cyan_terracotta
fill 190 277 236 190 278 236 minecraft:white_concrete
fill 190 277 237 201 277 261 minecraft:light_gray_concrete
fill 190 277 262 190 278 262 minecraft:cyan_terracotta
fill 191 277 236 205 278 236 minecraft:light_gray_concrete
fill 191 277 262 205 278 262 minecraft:light_gray_concrete
setblock 192 277 233 minecraft:white_concrete
setblock 192 277 265 minecraft:gray_concrete
setblock 193 277 232 minecraft:white_concrete
fill 193 277 233 206 277 233 minecraft:light_gray_concrete
fill 193 277 265 207 277 265 minecraft:light_gray_concrete
setblock 193 277 266 minecraft:cyan_terracotta
fill 194 277 232 206 277 232 minecraft:light_gray_concrete
fill 194 277 266 207 277 266 minecraft:light_gray_concrete
fill 196 277 230 196 278 230 minecraft:white_concrete
fill 196 277 268 196 278 268 minecraft:cyan_terracotta
fill 197 277 229 221 277 229 minecraft:white_concrete
fill 197 277 230 207 277 230 minecraft:light_gray_concrete
fill 197 277 268 221 277 268 minecraft:light_gray_concrete
setblock 197 277 269 minecraft:cyan_terracotta
fill 202 277 237 202 277 245 minecraft:light_gray_concrete
fill 202 277 246 202 277 249 minecraft:pink_terracotta
fill 202 277 250 202 277 261 minecraft:light_gray_concrete
fill 203 277 235 205 287 235 minecraft:light_gray_concrete
fill 203 277 237 203 278 243 minecraft:light_gray_concrete
fill 203 277 244 203 277 245 minecraft:pink_terracotta
fill 203 277 250 203 277 251 minecraft:pink_terracotta
fill 203 277 252 203 277 261 minecraft:light_gray_concrete
fill 204 277 234 205 287 234 minecraft:light_gray_concrete
fill 204 277 237 204 278 242 minecraft:light_gray_concrete
fill 204 277 243 204 278 243 minecraft:pink_terracotta
setblock 204 277 252 minecraft:pink_terracotta
fill 204 277 253 204 277 261 minecraft:light_gray_concrete
fill 205 277 237 205 279 241 minecraft:light_gray_concrete
fill 205 277 242 206 277 242 minecraft:pink_terracotta
fill 205 277 253 206 277 253 minecraft:pink_terracotta
fill 205 277 254 205 278 261 minecraft:light_gray_concrete
fill 207 277 241 213 278 241 minecraft:pink_terracotta
fill 207 277 254 213 277 254 minecraft:pink_terracotta
fill 207 277 255 207 278 264 minecraft:light_gray_concrete
fill 209 277 230 221 277 230 minecraft:light_gray_concrete
fill 214 277 242 215 277 242 minecraft:pink_terracotta
fill 214 277 253 215 277 253 minecraft:pink_terracotta
fill 214 277 254 226 277 254 minecraft:light_gray_concrete
fill 216 277 242 228 279 242 minecraft:light_gray_concrete
fill 216 277 243 216 278 243 minecraft:pink_terracotta
fill 216 277 252 216 278 252 minecraft:pink_terracotta
fill 216 277 253 228 278 253 minecraft:light_gray_concrete
fill 217 277 243 228 279 243 minecraft:light_gray_concrete
fill 217 277 244 217 277 245 minecraft:pink_terracotta
fill 217 277 250 217 277 251 minecraft:pink_terracotta
fill 217 277 252 228 278 252 minecraft:light_gray_concrete
fill 218 277 244 228 279 244 minecraft:light_gray_concrete
fill 218 277 246 218 278 249 minecraft:pink_terracotta
fill 218 277 251 228 278 251 minecraft:light_gray_concrete
fill 219 277 249 228 278 249 minecraft:light_gray_concrete
fill 222 277 230 222 278 230 minecraft:white_concrete
fill 222 277 268 222 278 268 minecraft:cyan_terracotta
setblock 225 277 232 minecraft:white_concrete
fill 225 277 233 225 277 240 minecraft:light_gray_concrete
fill 225 277 255 225 277 265 minecraft:light_gray_concrete
setblock 225 277 266 minecraft:cyan_terracotta
setblock 226 277 233 minecraft:white_concrete
fill 226 277 234 226 277 240 minecraft:light_gray_concrete
fill 226 277 255 226 277 264 minecraft:light_gray_concrete
setblock 226 277 265 minecraft:cyan_terracotta
fill 228 277 236 228 278 236 minecraft:white_concrete
fill 228 277 237 228 277 240 minecraft:light_gray_concrete
fill 228 277 254 228 277 261 minecraft:light_gray_concrete
fill 228 277 262 228 278 262 minecraft:gray_concrete
fill 229 277 237 229 277 242 minecraft:white_concrete
fill 189 278 238 189 278 242 minecraft:white_concrete
fill 190 278 237 190 279 237 minecraft:white_concrete
fill 190 278 238 200 278 260 minecraft:light_gray_concrete
fill 190 278 261 190 279 261 minecraft:cyan_terracotta
setblock 191 278 231 minecraft:light[level=15]
setblock 191 278 235 minecraft:white_concrete
fill 191 278 237 202 279 237 minecraft:light_gray_concrete
fill 191 278 261 204 279 261 minecraft:light_gray_concrete
setblock 191 278 263 minecraft:cyan_terracotta
setblock 191 278 266 minecraft:light[level=15]
fill 192 278 234 192 279 234 minecraft:white_concrete
fill 192 278 235 202 278 235 minecraft:light_gray_concrete
fill 192 278 263 206 278 263 minecraft:light_gray_concrete
fill 192 278 264 192 279 264 minecraft:cyan_terracotta
fill 193 278 233 193 279 233 minecraft:white_concrete
fill 193 278 234 203 279 234 minecraft:light_gray_concrete
fill 193 278 264 206 279 264 minecraft:light_gray_concrete
fill 193 278 265 193 279 265 minecraft:cyan_terracotta
fill 194 278 232 194 279 232 minecraft:white_concrete
fill 194 278 233 206 279 233 minecraft:light_gray_concrete
fill 194 278 265 224 279 265 minecraft:light_gray_concrete
fill 194 278 266 194 279 266 minecraft:gray_concrete
setblock 195 278 231 minecraft:white_concrete
fill 195 278 232 206 278 232 minecraft:light_gray_concrete
fill 195 278 266 223 278 266 minecraft:light_gray_concrete
setblock 195 278 267 minecraft:cyan_terracotta
fill 196 278 231 222 278 231 minecraft:light_gray_concrete
fill 196 278 267 222 278 267 minecraft:light_gray_concrete
fill 197 278 230 197 279 230 minecraft:white_concrete
fill 197 278 268 197 279 268 minecraft:cyan_terracotta
fill 198 278 229 220 278 229 minecraft:white_concrete
fill 198 278 230 207 278 230 minecraft:light_gray_concrete
fill 198 278 268 220 278 268 minecraft:light_gray_concrete
fill 201 278 238 201 278 247 minecraft:light_gray_concrete
setblock 201 278 248 minecraft:pink_terracotta
fill 201 278 249 201 278 260 minecraft:light_gray_concrete
fill 202 278 238 202 278 244 minecraft:light_gray_concrete
fill 202 278 245 202 278 247 minecraft:pink_terracotta
fill 202 278 249 202 278 250 minecraft:pink_terracotta
fill 202 278 251 202 278 260 minecraft:light_gray_concrete
setblock 203 278 244 minecraft:pink_terracotta
fill 203 278 251 203 278 252 minecraft:pink_terracotta
fill 203 278 253 203 279 260 minecraft:light_gray_concrete
fill 204 278 253 205 278 253 minecraft:pink_terracotta
fill 204 278 254 204 279 260 minecraft:light_gray_concrete
setblock 205 278 242 minecraft:pink_terracotta
setblock 205 278 245 minecraft:light[level=15]
setblock 205 278 252 minecraft:light[level=15]
fill 206 278 234 206 281 240 minecraft:light_gray_concrete
setblock 206 278 241 minecraft:pink_terracotta
fill 206 278 254 207 278 254 minecraft:pink_terracotta
fill 206 278 255 206 279 262 minecraft:light_gray_concrete
fill 208 278 255 211 278 255 minecraft:pink_terracotta
fill 208 278 256 225 279 264 minecraft:light_gray_concrete
fill 209 278 230 220 278 230 minecraft:light_gray_concrete
fill 209 278 232 223 278 240 minecraft:light_gray_concrete
setblock 212 278 245 minecraft:light[level=15]
setblock 212 278 252 minecraft:light[level=15]
fill 212 278 254 214 278 254 minecraft:pink_terracotta
fill 212 278 255 228 278 255 minecraft:light_gray_concrete
setblock 214 278 241 minecraft:pink_terracotta
fill 215 278 241 228 280 241 minecraft:light_gray_concrete
setblock 215 278 242 minecraft:pink_terracotta
setblock 215 278 253 minecraft:pink_terracotta
fill 215 278 254 228 278 254 minecraft:light_gray_concrete
setblock 217 278 244 minecraft:pink_terracotta
setblock 217 278 251 minecraft:pink_terracotta
setblock 218 278 245 minecraft:pink_terracotta
setblock 218 278 250 minecraft:pink_terracotta
fill 219 278 245 228 280 245 minecraft:light_gray_concrete
fill 219 278 250 228 279 250 minecraft:light_gray_concrete
fill 221 278 230 221 279 230 minecraft:white_concrete
fill 221 278 268 221 279 268 minecraft:cyan_terracotta
setblock 223 278 231 minecraft:white_concrete
setblock 223 278 267 minecraft:cyan_terracotta
fill 224 278 232 224 279 232 minecraft:white_concrete
fill 224 278 233 224 279 240 minecraft:light_gray_concrete
fill 224 278 266 224 279 266 minecraft:cyan_terracotta
fill 225 278 233 225 279 233 minecraft:white_concrete
fill 225 278 234 225 279 240 minecraft:light_gray_concrete
fill 225 278 265 225 279 265 minecraft:cyan_terracotta
setblock 226 278 231 minecraft:light[level=15]
fill 226 278 234 226 279 234 minecraft:white_concrete
fill 226 278 235 226 278 240 minecraft:light_gray_concrete
fill 226 278 256 226 278 263 minecraft:light_gray_concrete
fill 226 278 264 226 279 264 minecraft:cyan_terracotta
setblock 226 278 266 minecraft:light[level=15]
setblock 227 278 235 minecraft:white_concrete
fill 227 278 236 227 278 240 minecraft:light_gray_concrete
fill 227 278 256 227 278 262 minecraft:light_gray_concrete
setblock 227 278 263 minecraft:cyan_terracotta
fill 228 278 237 228 279 237 minecraft:white_concrete
fill 228 278 238 228 278 240 minecraft:light_gray_concrete
fill 228 278 256 228 278 260 minecraft:light_gray_concrete
fill 228 278 261 228 279 261 minecraft:cyan_terracotta
fill 229 278 238 229 278 242 minecraft:white_concrete
setblock 229 278 260 minecraft:cyan_terracotta
fill 189 279 239 189 279 242 minecraft:white_concrete
fill 190 279 238 190 280 238 minecraft:white_concrete
fill 190 279 239 200 279 259 minecraft:light_gray_concrete
fill 190 279 260 190 280 260 minecraft:cyan_terracotta
fill 191 279 236 191 280 236 minecraft:white_concrete
fill 191 279 238 204 280 238 minecraft:light_gray_concrete
fill 191 279 260 202 280 260 minecraft:light_gray_concrete
fill 191 279 262 191 280 262 minecraft:cyan_terracotta
fill 192 279 235 192 280 235 minecraft:white_concrete
fill 192 279 236 205 280 236 minecraft:light_gray_concrete
fill 192 279 262 205 280 262 minecraft:light_gray_concrete
fill 192 279 263 192 280 263 minecraft:cyan_terracotta
fill 193 279 235 202 280 235 minecraft:light_gray_concrete
fill 193 279 263 207 280 263 minecraft:light_gray_concrete
fill 195 279 232 195 280 232 minecraft:white_concrete
fill 195 279 266 195 280 266 minecraft:cyan_terracotta
fill 196 279 231 196 280 231 minecraft:white_concrete
fill 196 279 232 206 280 232 minecraft:light_gray_concrete
fill 196 279 266 222 280 266 minecraft:light_gray_concrete
fill 196 279 267 196 280 267 minecraft:gray_concrete
fill 197 279 231 221 279 231 minecraft:light_gray_concrete
fill 197 279 267 221 279 267 minecraft:light_gray_concrete
fill 198 279 230 198 280 230 minecraft:white_concrete
fill 198 279 268 198 280 268 minecraft:gray_concrete
fill 199 279 229 219 279 229 minecraft:white_concrete
fill 199 279 230 207 279 230 minecraft:light_gray_concrete
fill 199 279 268 219 279 268 minecraft:light_gray_concrete
setblock 199 279 269 minecraft:cyan_terracotta
fill 201 279 239 201 279 245 minecraft:light_gray_concrete
fill 201 279 246 201 279 250 minecraft:red_terracotta
fill 201 279 251 201 279 259 minecraft:light_gray_concrete
fill 202 279 239 202 280 243 minecraft:light_gray_concrete
fill 202 279 244 202 279 245 minecraft:red_terracotta
setblock 202 279 251 minecraft:red_terracotta
fill 202 279 252 202 279 259 minecraft:light_gray_concrete
fill 203 279 237 204 288 237 minecraft:light_gray_concrete
fill 203 279 239 203 280 242 minecraft:light_gray_concrete
setblock 203 279 243 minecraft:red_terracotta
setblock 203 279 252 minecraft:red_terracotta
fill 204 279 239 204 281 241 minecraft:light_gray_concrete
fill 204 279 242 205 279 242 minecraft:red_terracotta
setblock 204 279 253 minecraft:red_terracotta
fill 205 279 254 206 279 254 minecraft:red_terracotta
fill 205 279 255 205 280 261 minecraft:light_gray_concrete
fill 206 279 241 208 279 241 minecraft:red_terracotta
fill 207 279 255 213 279 255 minecraft:red_terracotta
fill 207 279 256 207 280 262 minecraft:light_gray_concrete
fill 207 279 264 207 288 264 minecraft:light_gray_concrete
fill 209 279 230 219 279 230 minecraft:light_gray_concrete
fill 209 279 232 222 280 239 minecraft:light_gray_concrete
fill 209 279 240 211 279 240 minecraft:red_terracotta
fill 212 279 240 223 279 240 minecraft:light_gray_concrete
fill 212 279 241 214 279 241 minecraft:red_terracotta
fill 214 279 254 215 279 254 minecraft:red_terracotta
fill 214 279 255 228 279 255 minecraft:light_gray_concrete
setblock 215 279 242 minecraft:red_terracotta
setblock 216 279 243 minecraft:red_terracotta
setblock 216 279 253 minecraft:red_terracotta
fill 216 279 254 228 280 254 minecraft:light_gray_concrete
setblock 217 279 244 minecraft:red_terracotta
setblock 217 279 252 minecraft:red_terracotta
fill 217 279 253 228 280 253 minecraft:light_gray_concrete
fill 218 279 245 218 279 246 minecraft:red_terracotta
fill 218 279 250 218 279 251 minecraft:red_terracotta
fill 218 279 252 228 280 252 minecraft:light_gray_concrete
fill 219 279 246 228 279 246 minecraft:light_gray_concrete
fill 219 279 247 219 279 249 minecraft:red_terracotta
fill 219 279 251 228 280 251 minecraft:light_gray_concrete
setblock 219 279 269 minecraft:cyan_terracotta
fill 220 279 230 220 280 230 minecraft:white_concrete
fill 220 279 247 228 281 249 minecraft:light_gray_concrete
fill 220 279 268 220 280 268 minecraft:cyan_terracotta
fill 222 279 231 222 280 231 minecraft:white_concrete
fill 222 279 267 222 280 267 minecraft:cyan_terracotta
fill 223 279 232 223 280 232 minecraft:white_concrete
fill 223 279 233 223 280 239 minecraft:light_gray_concrete
fill 223 279 266 223 280 266 minecraft:cyan_terracotta
fill 226 279 235 226 280 235 minecraft:white_concrete
fill 226 279 236 226 280 240 minecraft:light_gray_concrete
fill 226 279 256 226 280 262 minecraft:light_gray_concrete
fill 226 279 263 226 280 263 minecraft:cyan_terracotta
fill 227 279 236 227 280 236 minecraft:white_concrete
fill 227 279 237 227 279 240 minecraft:light_gray_concrete
fill 227 279 256 227 279 261 minecraft:light_gray_concrete
fill 227 279 262 227 280 262 minecraft:cyan_terracotta
fill 228 279 238 228 280 238 minecraft:white_concrete
fill 228 279 239 228 279 240 minecraft:light_gray_concrete
fill 228 279 256 228 279 259 minecraft:light_gray_concrete
fill 228 279 260 228 280 260 minecraft:cyan_terracotta
fill 229 279 239 229 279 242 minecraft:white_concrete
fill 189 280 240 189 280 242 minecraft:white_concrete
fill 189 280 254 189 280 258 minecraft:cyan_terracotta
fill 190 280 239 190 281 239 minecraft:white_concrete
fill 190 280 240 200 280 258 minecraft:light_gray_concrete
fill 190 280 259 190 281 259 minecraft:cyan_terracotta
fill 191 280 237 191 281 237 minecraft:white_concrete
fill 191 280 239 201 281 239 minecraft:light_gray_concrete
fill 191 280 259 204 281 259 minecraft:light_gray_concrete
fill 191 280 261 191 281 261 minecraft:gray_concrete
fill 192 280 237 202 281 237 minecraft:light_gray_concrete
fill 192 280 261 204 281 261 minecraft:light_gray_concrete
setblock 193 280 234 minecraft:white_concrete
setblock 193 280 264 minecraft:cyan_terracotta
setblock 194 280 233 minecraft:white_concrete
fill 194 280 234 203 280 234 minecraft:light_gray_concrete
fill 194 280 264 206 280 264 minecraft:light_gray_concrete
setblock 194 280 265 minecraft:cyan_terracotta
fill 195 280 233 206 280 233 minecraft:light_gray_concrete
fill 195 280 265 223 280 265 minecraft:light_gray_concrete
fill 197 280 231 197 281 231 minecraft:white_concrete
fill 197 280 267 197 281 267 minecraft:cyan_terracotta
fill 198 280 231 220 280 231 minecraft:light_gray_concrete
fill 198 280 267 220 280 267 minecraft:light_gray_concrete
fill 199 280 230 199 281 230 minecraft:white_concrete
fill 199 280 268 199 281 268 minecraft:cyan_terracotta
fill 200 280 229 218 280 229 minecraft:white_concrete
fill 200 280 230 207 280 230 minecraft:light_gray_concrete
fill 200 280 268 218 280 268 minecraft:light_gray_concrete
fill 201 280 240 201 280 244 minecraft:light_gray_concrete
fill 201 280 245 201 280 251 minecraft:pink_terracotta
fill 201 280 252 201 280 258 minecraft:light_gray_concrete
setblock 202 280 244 minecraft:pink_terracotta
setblock 202 280 252 minecraft:pink_terracotta
fill 202 280 253 202 280 258 minecraft:light_gray_concrete
setblock 203 280 243 minecraft:pink_terracotta
setblock 203 280 253 minecraft:pink_terracotta
fill 203 280 254 203 280 258 minecraft:light_gray_concrete
fill 203 280 260 204 288 260 minecraft:light_gray_concrete
fill 204 280 242 204 281 242 minecraft:pink_terracotta
fill 204 280 254 205 280 254 minecraft:pink_terracotta
fill 204 280 255 204 281 258 minecraft:light_gray_concrete
fill 205 280 237 205 283 240 minecraft:light_gray_concrete
fill 205 280 241 207 280 241 minecraft:pink_terracotta
fill 206 280 255 208 280 255 minecraft:pink_terracotta
fill 206 280 256 206 281 262 minecraft:light_gray_concrete
fill 208 280 232 208 284 239 minecraft:light_gray_concrete
fill 208 280 240 212 281 240 minecraft:pink_terracotta
fill 208 280 256 208 280 264 minecraft:light_gray_concrete
fill 209 280 230 218 280 230 minecraft:light_gray_concrete
fill 209 280 256 210 281 256 minecraft:pink_terracotta
fill 209 280 257 224 280 264 minecraft:light_gray_concrete
fill 211 280 255 214 280 255 minecraft:pink_terracotta
fill 211 280 256 225 280 256 minecraft:light_gray_concrete
fill 213 280 240 225 281 240 minecraft:light_gray_concrete
fill 213 280 241 214 281 241 minecraft:pink_terracotta
fill 215 280 242 216 280 242 minecraft:pink_terracotta
setblock 215 280 254 minecraft:pink_terracotta
fill 215 280 255 228 280 255 minecraft:light_gray_concrete
setblock 216 280 253 minecraft:pink_terracotta
fill 217 280 242 228 282 242 minecraft:light_gray_concrete
fill 217 280 243 217 281 243 minecraft:pink_terracotta
setblock 217 280 252 minecraft:pink_terracotta
fill 218 280 243 228 282 243 minecraft:light_gray_concrete
fill 218 280 244 218 280 245 minecraft:pink_terracotta
setblock 218 280 251 minecraft:pink_terracotta
fill 219 280 230 219 281 230 minecraft:white_concrete
fill 219 280 244 228 283 244 minecraft:light_gray_concrete
fill 219 280 246 219 281 250 minecraft:pink_terracotta
fill 219 280 268 219 281 268 minecraft:gray_concrete
fill 220 280 246 228 282 246 minecraft:light_gray_concrete
fill 220 280 250 228 282 250 minecraft:light_gray_concrete
fill 221 280 231 221 281 231 minecraft:white_concrete
fill 221 280 267 221 281 267 minecraft:cyan_terracotta
setblock 224 280 233 minecraft:white_concrete
fill 224 280 234 224 280 239 minecraft:light_gray_concrete
setblock 224 280 265 minecraft:cyan_terracotta
setblock 225 280 234 minecraft:white_concrete
fill 225 280 235 225 280 239 minecraft:light_gray_concrete
fill 225 280 257 225 280 263 minecraft:light_gray_concrete
setblock 225 280 264 minecraft:gray_concrete
fill 227 280 237 227 281 237 minecraft:white_concrete
fill 227 280 238 227 280 240 minecraft:light_gray_concrete
fill 227 280 256 227 280 260 minecraft:light_gray_concrete
fill 227 280 261 227 281 261 minecraft:cyan_terracotta
fill 228 280 239 228 281 239 minecraft:white_concrete
setblock 228 280 240 minecraft:light_gray_concrete
fill 228 280 256 228 280 258 minecraft:light_gray_concrete
fill 228 280 259 228 281 259 minecraft:cyan_terracotta
fill 229 280 240 229 280 242 minecraft:white_concrete
fill 189 281 241 189 281 242 minecraft:white_concrete
fill 189 281 254 189 281 257 minecraft:cyan_terracotta
fill 190 281 240 190 282 240 minecraft:white_concrete
fill 190 281 241 199 281 257 minecraft:light_gray_concrete
fill 190 281 258 190 282 258 minecraft:cyan_terracotta
fill 191 281 238 191 282 238 minecraft:white_concrete
fill 191 281 240 203 282 240 minecraft:light_gray_concrete
fill 191 281 258 203 282 258 minecraft:light_gray_concrete
fill 191 281 260 191 282 260 minecraft:cyan_terracotta
setblock 192 281 236 minecraft:white_concrete
fill 192 281 238 204 282 238 minecraft:light_gray_concrete
fill 192 281 260 202 282 260 minecraft:light_gray_concrete
setblock 192 281 262 minecraft:cyan_terracotta
fill 193 281 235 193 282 235 minecraft:white_concrete
fill 193 281 236 205 281 236 minecraft:light_gray_concrete
fill 193 281 262 205 281 262 minecraft:light_gray_concrete
fill 193 281 263 193 282 263 minecraft:cyan_terracotta
fill 194 281 234 194 282 234 minecraft:white_concrete
fill 194 281 235 202 282 235 minecraft:light_gray_concrete
fill 194 281 263 224 282 263 minecraft:light_gray_concrete
fill 194 281 264 194 282 264 minecraft:cyan_terracotta
fill 195 281 233 195 282 233 minecraft:white_concrete
fill 195 281 234 203 282 234 minecraft:light_gray_concrete
fill 195 281 264 206 282 264 minecraft:light_gray_concrete
fill 195 281 265 195 282 265 minecraft:cyan_terracotta
setblock 196 281 232 minecraft:white_concrete
fill 196 281 233 207 281 233 minecraft:light_gray_concrete
fill 196 281 265 222 281 265 minecraft:light_gray_concrete
setblock 196 281 266 minecraft:cyan_terracotta
fill 197 281 232 207 281 232 minecraft:light_gray_concrete
fill 197 281 266 221 281 266 minecraft:light_gray_concrete
fill 198 281 231 198 282 231 minecraft:white_concrete
fill 198 281 267 198 282 267 minecraft:cyan_terracotta
fill 199 281 231 219 281 231 minecraft:light_gray_concrete
fill 199 281 267 219 281 267 minecraft:light_gray_concrete
fill 200 281 230 200 282 230 minecraft:white_concrete
fill 200 281 241 200 281 245 minecraft:light_gray_concrete
fill 200 281 246 200 281 250 minecraft:pink_terracotta
fill 200 281 251 200 281 257 minecraft:light_gray_concrete
fill 200 281 268 200 282 268 minecraft:cyan_terracotta
fill 201 281 229 217 281 229 minecraft:white_concrete
fill 201 281 230 207 281 230 minecraft:light_gray_concrete
fill 201 281 241 201 282 243 minecraft:light_gray_concrete
fill 201 281 244 201 281 245 minecraft:pink_terracotta
fill 201 281 251 201 281 252 minecraft:pink_terracotta
fill 201 281 253 201 282 257 minecraft:light_gray_concrete
fill 201 281 268 217 281 268 minecraft:light_gray_concrete
fill 202 281 239 203 288 239 minecraft:light_gray_concrete
fill 202 281 241 202 282 242 minecraft:light_gray_concrete
setblock 202 281 243 minecraft:pink_terracotta
fill 202 281 248 203 281 248 minecraft:bone_block
fill 202 281 250 203 281 250 minecraft:bone_block
setblock 202 281 253 minecraft:pink_terracotta
fill 202 281 254 202 282 257 minecraft:light_gray_concrete
fill 203 281 241 203 283 241 minecraft:light_gray_concrete
setblock 203 281 242 minecraft:pink_terracotta
fill 203 281 246 203 282 247 minecraft:bone_block
fill 203 281 251 203 282 252 minecraft:bone_block
fill 203 281 254 204 281 254 minecraft:pink_terracotta
fill 203 281 255 203 282 257 minecraft:light_gray_concrete
fill 204 281 245 204 284 245 minecraft:bone_block
setblock 204 281 247 minecraft:bone_block
setblock 204 281 251 minecraft:bone_block
fill 204 281 253 204 284 253 minecraft:bone_block
fill 205 281 241 206 281 241 minecraft:pink_terracotta
setblock 205 281 246 minecraft:bone_block
setblock 205 281 252 minecraft:bone_block
fill 205 281 255 206 281 255 minecraft:pink_terracotta
fill 205 281 256 205 282 261 minecraft:light_gray_concrete
fill 206 281 244 206 282 245 minecraft:bone_block
fill 206 281 253 206 282 254 minecraft:bone_block
fill 207 281 234 207 285 239 minecraft:light_gray_concrete
setblock 207 281 240 minecraft:pink_terracotta
fill 207 281 256 208 281 256 minecraft:pink_terracotta
fill 207 281 257 225 281 262 minecraft:light_gray_concrete
fill 208 281 244 208 281 245 minecraft:bone_block
fill 208 281 253 208 281 254 minecraft:bone_block
fill 208 281 264 223 282 264 minecraft:light_gray_concrete
fill 209 281 230 217 281 230 minecraft:light_gray_concrete
fill 209 281 232 221 281 239 minecraft:light_gray_concrete
fill 210 281 244 210 281 245 minecraft:bone_block
fill 210 281 253 210 281 254 minecraft:bone_block
fill 211 281 256 212 281 256 minecraft:pink_terracotta
fill 212 281 244 212 282 245 minecraft:bone_block
fill 212 281 253 212 282 254 minecraft:bone_block
setblock 213 281 246 minecraft:bone_block
setblock 213 281 252 minecraft:bone_block
fill 213 281 255 215 281 255 minecraft:pink_terracotta
fill 213 281 256 228 281 256 minecraft:light_gray_concrete
fill 214 281 245 214 284 245 minecraft:bone_block
fill 214 281 247 215 281 247 minecraft:bone_block
fill 214 281 251 215 281 251 minecraft:bone_block
fill 214 281 253 214 284 253 minecraft:bone_block
setblock 215 281 241 minecraft:pink_terracotta
fill 215 281 246 215 283 246 minecraft:bone_block
fill 215 281 248 216 281 248 minecraft:bone_block
fill 215 281 250 216 281 250 minecraft:bone_block
fill 215 281 252 215 283 252 minecraft:bone_block
fill 215 281 269 217 281 269 minecraft:cyan_terracotta
fill 216 281 241 228 281 241 minecraft:light_gray_concrete
setblock 216 281 242 minecraft:pink_terracotta
setblock 216 281 254 minecraft:pink_terracotta
fill 216 281 255 228 282 255 minecraft:light_gray_concrete
setblock 217 281 253 minecraft:pink_terracotta
fill 217 281 254 228 281 254 minecraft:light_gray_concrete
fill 218 281 230 218 282 230 minecraft:white_concrete
setblock 218 281 244 minecraft:pink_terracotta
setblock 218 281 252 minecraft:pink_terracotta
fill 218 281 253 228 281 253 minecraft:light_gray_concrete
fill 218 281 268 218 282 268 minecraft:cyan_terracotta
setblock 219 281 245 minecraft:pink_terracotta
setblock 219 281 251 minecraft:pink_terracotta
fill 219 281 252 228 282 252 minecraft:light_gray_concrete
fill 220 281 231 220 282 231 minecraft:white_concrete
fill 220 281 245 228 283 245 minecraft:light_gray_concrete
fill 220 281 251 228 283 251 minecraft:light_gray_concrete
fill 220 281 267 220 282 267 minecraft:cyan_terracotta
setblock 222 281 232 minecraft:white_concrete
fill 222 281 233 222 281 239 minecraft:light_gray_concrete
setblock 222 281 266 minecraft:gray_concrete
fill 223 281 233 223 282 233 minecraft:white_concrete
fill 223 281 234 223 282 239 minecraft:light_gray_concrete
fill 223 281 265 223 282 265 minecraft:cyan_terracotta
fill 224 281 234 224 282 234 minecraft:white_concrete
fill 224 281 235 224 282 239 minecraft:light_gray_concrete
fill 224 281 264 224 282 264 minecraft:cyan_terracotta
fill 225 281 235 225 282 235 minecraft:white_concrete
fill 225 281 236 225 281 239 minecraft:light_gray_concrete
fill 225 281 263 225 282 263 minecraft:cyan_terracotta
setblock 226 281 236 minecraft:white_concrete
fill 226 281 237 226 281 240 minecraft:light_gray_concrete
fill 226 281 257 226 281 261 minecraft:light_gray_concrete
setblock 226 281 262 minecraft:cyan_terracotta
fill 227 281 238 227 282 238 minecraft:white_concrete
fill 227 281 239 227 281 240 minecraft:light_gray_concrete
fill 227 281 257 227 281 259 minecraft:light_gray_concrete
fill 227 281 260 227 282 260 minecraft:cyan_terracotta
fill 228 281 240 228 282 240 minecraft:white_concrete
setblock 228 281 257 minecraft:light_gray_concrete
fill 228 281 258 228 282 258 minecraft:cyan_terracotta
fill 229 281 241 229 281 242 minecraft:white_concrete
fill 229 281 256 229 281 257 minecraft:cyan_terracotta
setblock 189 282 242 minecraft:white_concrete
fill 189 282 254 189 282 256 minecraft:cyan_terracotta
fill 190 282 241 190 283 241 minecraft:white_concrete
fill 190 282 242 199 282 256 minecraft:light_gray_concrete
fill 190 282 257 190 283 257 minecraft:gray_concrete
fill 191 282 239 191 283 239 minecraft:white_concrete
fill 191 282 241 200 283 241 minecraft:light_gray_concrete
fill 191 282 257 200 283 257 minecraft:light_gray_concrete
fill 191 282 259 191 283 259 minecraft:cyan_terracotta
setblock 192 282 237 minecraft:white_concrete
fill 192 282 239 201 283 239 minecraft:light_gray_concrete
fill 192 282 259 204 283 259 minecraft:light_gray_concrete
setblock 192 282 261 minecraft:cyan_terracotta
fill 193 282 236 193 283 236 minecraft:white_concrete
fill 193 282 237 202 282 237 minecraft:light_gray_concrete
fill 193 282 261 204 282 261 minecraft:light_gray_concrete
fill 193 282 262 193 283 262 minecraft:gray_concrete
fill 194 282 236 206 283 236 minecraft:light_gray_concrete
fill 194 282 262 224 283 262 minecraft:light_gray_concrete
fill 196 282 233 196 283 233 minecraft:white_concrete
fill 196 282 265 196 283 265 minecraft:cyan_terracotta
setblock 197 282 232 minecraft:white_concrete
fill 197 282 233 207 282 233 minecraft:light_gray_concrete
fill 197 282 265 221 282 265 minecraft:light_gray_concrete
setblock 197 282 266 minecraft:cyan_terracotta
fill 198 282 232 207 282 232 minecraft:light_gray_concrete
fill 198 282 266 220 282 266 minecraft:light_gray_concrete
schedule function dropper:buildpart/52_2 1t
