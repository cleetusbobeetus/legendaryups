setblock 277 211 564 minecraft:yellow_concrete
fill 277 211 565 277 213 565 minecraft:red_concrete
fill 277 211 569 277 214 569 minecraft:red_concrete
fill 277 211 580 277 214 580 minecraft:red_concrete
setblock 277 211 581 minecraft:yellow_concrete
setblock 277 211 583 minecraft:red_concrete
fill 277 211 584 277 211 585 minecraft:yellow_concrete
setblock 235 212 557 minecraft:yellow_concrete
fill 235 212 561 235 212 564 minecraft:red_concrete
fill 235 212 565 235 213 566 minecraft:yellow_concrete
fill 235 212 567 235 217 568 minecraft:red_concrete
fill 235 212 574 235 213 574 minecraft:yellow_concrete
fill 235 212 575 235 213 576 minecraft:red_concrete
fill 235 212 577 235 212 578 minecraft:yellow_concrete
fill 235 212 579 235 217 579 minecraft:red_concrete
fill 235 212 585 235 213 586 minecraft:yellow_concrete
fill 235 212 587 235 217 588 minecraft:red_concrete
fill 235 212 597 235 212 598 minecraft:yellow_concrete
fill 235 212 599 236 217 599 minecraft:red_concrete
fill 240 212 557 241 217 557 minecraft:red_concrete
fill 242 212 557 243 213 557 minecraft:yellow_concrete
fill 242 212 599 242 213 599 minecraft:yellow_concrete
fill 243 212 599 244 217 599 minecraft:red_concrete
setblock 245 212 599 minecraft:yellow_concrete
fill 247 212 599 247 217 599 minecraft:red_concrete
fill 249 212 557 249 217 557 minecraft:red_concrete
fill 250 212 557 251 212 557 minecraft:yellow_concrete
fill 252 212 557 253 213 557 minecraft:red_concrete
fill 253 212 599 254 213 599 minecraft:yellow_concrete
fill 254 212 557 254 213 557 minecraft:yellow_concrete
setblock 255 212 557 minecraft:red_concrete
fill 255 212 599 256 217 599 minecraft:red_concrete
fill 260 212 557 261 217 557 minecraft:red_concrete
fill 262 212 557 263 213 557 minecraft:yellow_concrete
fill 264 212 557 264 213 557 minecraft:red_concrete
fill 264 212 599 264 217 599 minecraft:red_concrete
fill 265 212 599 266 212 599 minecraft:yellow_concrete
fill 267 212 599 268 217 599 minecraft:red_concrete
setblock 271 212 557 minecraft:yellow_concrete
fill 272 212 557 273 217 557 minecraft:red_concrete
fill 273 212 599 274 213 599 minecraft:yellow_concrete
fill 274 212 557 275 213 557 minecraft:yellow_concrete
fill 275 212 599 276 217 599 minecraft:red_concrete
fill 276 212 557 277 213 557 minecraft:red_concrete
fill 277 212 560 277 217 561 minecraft:red_concrete
fill 277 212 562 277 212 563 minecraft:yellow_concrete
fill 277 212 564 277 217 564 minecraft:red_concrete
fill 277 212 572 277 217 573 minecraft:red_concrete
fill 277 212 574 277 213 575 minecraft:yellow_concrete
fill 277 212 576 277 213 579 minecraft:red_concrete
fill 277 212 581 277 217 581 minecraft:red_concrete
fill 277 212 582 277 212 583 minecraft:yellow_concrete
fill 277 212 584 277 213 585 minecraft:red_concrete
fill 277 212 586 277 213 586 minecraft:yellow_concrete
fill 277 212 592 277 217 593 minecraft:red_concrete
fill 277 212 594 277 213 595 minecraft:yellow_concrete
fill 277 212 596 277 213 596 minecraft:red_concrete
setblock 277 212 599 minecraft:yellow_concrete
fill 235 213 557 235 216 557 minecraft:red_concrete
fill 235 213 561 235 215 561 minecraft:red_concrete
setblock 235 213 562 minecraft:yellow_concrete
fill 235 213 563 235 213 564 minecraft:red_concrete
setblock 235 213 573 minecraft:yellow_concrete
fill 235 213 577 235 216 578 minecraft:red_concrete
setblock 235 213 594 minecraft:yellow_concrete
setblock 235 213 597 minecraft:yellow_concrete
fill 235 213 598 235 216 598 minecraft:red_concrete
setblock 241 213 599 minecraft:yellow_concrete
fill 245 213 599 245 216 599 minecraft:red_concrete
fill 250 213 557 251 216 557 minecraft:red_concrete
setblock 255 213 557 minecraft:yellow_concrete
fill 261 213 599 262 213 599 minecraft:yellow_concrete
setblock 265 213 599 minecraft:yellow_concrete
setblock 266 213 557 minecraft:yellow_concrete
fill 266 213 599 266 216 599 minecraft:red_concrete
fill 271 213 557 271 216 557 minecraft:red_concrete
fill 277 213 562 277 216 562 minecraft:red_concrete
setblock 277 213 563 minecraft:yellow_concrete
fill 277 213 566 277 213 567 minecraft:yellow_concrete
setblock 277 213 568 minecraft:red_concrete
fill 277 213 582 277 215 583 minecraft:red_concrete
setblock 277 213 587 minecraft:yellow_concrete
setblock 277 213 597 minecraft:red_concrete
setblock 277 213 598 minecraft:yellow_concrete
fill 277 213 599 277 215 599 minecraft:red_concrete
fill 235 214 562 235 219 562 minecraft:red_concrete
fill 235 214 563 235 214 564 minecraft:yellow_concrete
fill 235 214 565 235 219 566 minecraft:red_concrete
fill 235 214 569 235 215 570 minecraft:red_concrete
fill 235 214 571 235 215 572 minecraft:yellow_concrete
fill 235 214 573 235 219 574 minecraft:red_concrete
setblock 235 214 575 minecraft:yellow_concrete
fill 235 214 576 235 217 576 minecraft:red_concrete
fill 235 214 583 235 215 584 minecraft:yellow_concrete
fill 235 214 585 235 219 586 minecraft:red_concrete
fill 235 214 592 235 215 592 minecraft:yellow_concrete
fill 235 214 594 235 219 594 minecraft:red_concrete
fill 235 214 595 235 214 596 minecraft:yellow_concrete
fill 235 214 597 235 219 597 minecraft:red_concrete
fill 236 214 557 236 215 557 minecraft:yellow_concrete
fill 239 214 599 240 215 599 minecraft:yellow_concrete
fill 241 214 599 242 219 599 minecraft:red_concrete
fill 242 214 557 243 219 557 minecraft:red_concrete
fill 244 214 557 245 215 557 minecraft:yellow_concrete
fill 251 214 599 252 214 599 minecraft:yellow_concrete
fill 252 214 557 252 217 557 minecraft:red_concrete
setblock 253 214 557 minecraft:yellow_concrete
fill 253 214 599 254 219 599 minecraft:red_concrete
fill 254 214 557 255 219 557 minecraft:red_concrete
fill 256 214 557 257 215 557 minecraft:yellow_concrete
fill 260 214 599 260 215 599 minecraft:yellow_concrete
fill 261 214 599 262 219 599 minecraft:red_concrete
fill 262 214 557 263 219 557 minecraft:red_concrete
setblock 263 214 599 minecraft:yellow_concrete
fill 264 214 557 265 214 557 minecraft:yellow_concrete
fill 264 214 597 264 217 597 minecraft:magma_block
fill 265 214 599 265 219 599 minecraft:red_concrete
fill 266 214 557 266 219 557 minecraft:red_concrete
fill 269 214 599 270 215 599 minecraft:red_concrete
fill 271 214 599 272 215 599 minecraft:yellow_concrete
fill 273 214 599 274 219 599 minecraft:red_concrete
fill 274 214 557 275 219 557 minecraft:red_concrete
fill 276 214 557 277 215 557 minecraft:yellow_concrete
fill 277 214 563 277 219 563 minecraft:red_concrete
setblock 277 214 565 minecraft:yellow_concrete
fill 277 214 566 277 219 567 minecraft:red_concrete
fill 277 214 568 277 215 568 minecraft:yellow_concrete
fill 277 214 574 277 219 575 minecraft:red_concrete
fill 277 214 576 277 215 577 minecraft:yellow_concrete
fill 277 214 578 277 215 579 minecraft:red_concrete
fill 277 214 584 277 217 584 minecraft:red_concrete
setblock 277 214 585 minecraft:yellow_concrete
fill 277 214 586 277 219 587 minecraft:red_concrete
fill 277 214 588 277 215 589 minecraft:yellow_concrete
fill 277 214 594 277 216 595 minecraft:red_concrete
fill 277 214 596 277 214 597 minecraft:yellow_concrete
fill 277 214 598 277 219 598 minecraft:red_concrete
fill 235 215 559 235 215 560 minecraft:yellow_concrete
setblock 235 215 563 minecraft:yellow_concrete
fill 235 215 564 235 218 564 minecraft:red_concrete
fill 235 215 575 235 218 575 minecraft:red_concrete
setblock 235 215 580 minecraft:yellow_concrete
setblock 235 215 591 minecraft:yellow_concrete
fill 235 215 595 235 218 596 minecraft:red_concrete
setblock 237 215 557 minecraft:yellow_concrete
setblock 238 215 560 minecraft:light[level=14]
setblock 238 215 568 minecraft:light[level=14]
setblock 238 215 576 minecraft:light[level=14]
setblock 238 215 584 minecraft:light[level=14]
setblock 238 215 592 minecraft:light[level=14]
fill 244 215 576 245 216 577 minecraft:orange_concrete
setblock 246 215 560 minecraft:light[level=14]
setblock 246 215 568 minecraft:light[level=14]
setblock 246 215 576 minecraft:light[level=14]
setblock 246 215 584 minecraft:light[level=14]
setblock 246 215 592 minecraft:light[level=14]
setblock 248 215 557 minecraft:yellow_concrete
setblock 248 215 599 minecraft:yellow_concrete
setblock 251 215 599 minecraft:yellow_concrete
fill 252 215 599 252 218 599 minecraft:red_concrete
fill 253 215 557 253 218 557 minecraft:red_concrete
setblock 254 215 560 minecraft:light[level=14]
setblock 254 215 568 minecraft:light[level=14]
setblock 254 215 576 minecraft:light[level=14]
setblock 254 215 584 minecraft:light[level=14]
setblock 254 215 592 minecraft:light[level=14]
setblock 259 215 599 minecraft:yellow_concrete
setblock 262 215 560 minecraft:light[level=14]
setblock 262 215 568 minecraft:light[level=14]
setblock 262 215 576 minecraft:light[level=14]
setblock 262 215 584 minecraft:light[level=14]
setblock 262 215 592 minecraft:light[level=14]
fill 263 215 594 263 215 598 minecraft:magma_block
fill 263 215 599 263 218 599 minecraft:red_concrete
fill 264 215 557 264 218 557 minecraft:red_concrete
fill 264 215 591 264 215 596 minecraft:magma_block
fill 264 215 598 265 215 598 minecraft:magma_block
setblock 265 215 557 minecraft:yellow_concrete
fill 265 215 594 265 215 597 minecraft:magma_block
fill 268 215 557 269 215 557 minecraft:yellow_concrete
setblock 270 215 560 minecraft:light[level=14]
setblock 270 215 568 minecraft:light[level=14]
setblock 270 215 576 minecraft:light[level=14]
setblock 270 215 584 minecraft:light[level=14]
setblock 270 215 592 minecraft:light[level=14]
fill 277 215 565 277 218 565 minecraft:red_concrete
setblock 277 215 569 minecraft:yellow_concrete
setblock 277 215 580 minecraft:yellow_concrete
fill 277 215 585 277 217 585 minecraft:red_concrete
fill 277 215 596 277 218 596 minecraft:red_concrete
setblock 277 215 597 minecraft:yellow_concrete
fill 235 216 558 235 217 558 minecraft:yellow_concrete
fill 235 216 559 235 221 560 minecraft:red_concrete
setblock 235 216 561 minecraft:yellow_concrete
fill 235 216 563 235 221 563 minecraft:red_concrete
fill 235 216 569 235 217 570 minecraft:yellow_concrete
fill 235 216 571 235 221 572 minecraft:red_concrete
fill 235 216 580 235 221 580 minecraft:red_concrete
fill 235 216 581 235 216 582 minecraft:yellow_concrete
fill 235 216 583 235 221 584 minecraft:red_concrete
fill 235 216 589 235 217 590 minecraft:yellow_concrete
fill 235 216 591 235 221 592 minecraft:red_concrete
setblock 235 216 593 minecraft:yellow_concrete
fill 236 216 557 237 221 557 minecraft:red_concrete
fill 236 216 558 238 216 558 minecraft:orange_concrete
fill 236 216 560 236 216 562 minecraft:orange_concrete
fill 236 216 564 236 216 566 minecraft:orange_concrete
fill 236 216 568 236 216 570 minecraft:orange_concrete
fill 236 216 572 236 216 574 minecraft:orange_concrete
fill 236 216 576 236 216 578 minecraft:orange_concrete
fill 236 216 580 236 216 582 minecraft:orange_concrete
fill 236 216 584 236 216 586 minecraft:orange_concrete
fill 236 216 588 236 216 590 minecraft:orange_concrete
fill 236 216 592 236 216 594 minecraft:orange_concrete
fill 236 216 596 236 216 598 minecraft:orange_concrete
fill 237 216 599 238 217 599 minecraft:yellow_concrete
fill 238 216 557 239 217 557 minecraft:yellow_concrete
fill 238 216 598 240 216 598 minecraft:orange_concrete
fill 239 216 599 240 221 599 minecraft:red_concrete
fill 240 216 558 242 216 558 minecraft:orange_concrete
fill 242 216 598 244 216 598 minecraft:orange_concrete
fill 244 216 557 245 221 557 minecraft:red_concrete
fill 244 216 558 246 216 558 minecraft:orange_concrete
fill 246 216 557 247 216 557 minecraft:yellow_concrete
fill 246 216 598 248 216 598 minecraft:orange_concrete
fill 246 216 599 246 217 599 minecraft:yellow_concrete
fill 248 216 557 248 221 557 minecraft:red_concrete
fill 248 216 558 250 216 558 minecraft:orange_concrete
fill 248 216 599 248 221 599 minecraft:red_concrete
fill 249 216 599 250 216 599 minecraft:yellow_concrete
fill 250 216 598 252 216 598 minecraft:orange_concrete
fill 251 216 599 251 221 599 minecraft:red_concrete
fill 252 216 558 254 216 558 minecraft:orange_concrete
fill 254 216 598 256 216 598 minecraft:orange_concrete
fill 256 216 557 257 221 557 minecraft:red_concrete
fill 256 216 558 258 216 558 minecraft:orange_concrete
fill 257 216 599 258 217 599 minecraft:yellow_concrete
fill 258 216 557 259 217 557 minecraft:yellow_concrete
fill 258 216 598 260 216 598 minecraft:orange_concrete
fill 259 216 599 260 221 599 minecraft:red_concrete
fill 260 216 558 262 216 558 minecraft:orange_concrete
fill 262 216 598 264 216 598 minecraft:orange_concrete
fill 263 216 596 263 216 597 minecraft:magma_block
fill 264 216 558 266 216 558 minecraft:orange_concrete
fill 264 216 593 264 216 596 minecraft:magma_block
fill 265 216 557 265 221 557 minecraft:red_concrete
fill 265 216 596 265 216 598 minecraft:magma_block
fill 266 216 598 268 216 598 minecraft:orange_concrete
setblock 267 216 557 minecraft:yellow_concrete
fill 268 216 557 269 221 557 minecraft:red_concrete
fill 268 216 558 270 216 558 minecraft:orange_concrete
fill 269 216 599 270 216 599 minecraft:yellow_concrete
fill 270 216 557 270 217 557 minecraft:yellow_concrete
fill 270 216 598 272 216 598 minecraft:orange_concrete
fill 271 216 599 272 221 599 minecraft:red_concrete
fill 272 216 558 274 216 558 minecraft:orange_concrete
fill 274 216 598 276 216 598 minecraft:orange_concrete
fill 276 216 557 277 221 557 minecraft:red_concrete
fill 276 216 558 276 216 560 minecraft:orange_concrete
fill 276 216 562 276 216 564 minecraft:orange_concrete
fill 276 216 566 276 216 568 minecraft:orange_concrete
fill 276 216 570 276 216 572 minecraft:orange_concrete
fill 276 216 574 276 216 576 minecraft:orange_concrete
fill 276 216 578 276 216 580 minecraft:orange_concrete
fill 276 216 582 276 216 584 minecraft:orange_concrete
fill 276 216 586 276 216 588 minecraft:orange_concrete
fill 276 216 590 276 216 592 minecraft:orange_concrete
fill 276 216 594 276 216 596 minecraft:orange_concrete
fill 277 216 558 277 216 559 minecraft:yellow_concrete
fill 277 216 568 277 221 569 minecraft:red_concrete
fill 277 216 570 277 217 571 minecraft:yellow_concrete
fill 277 216 576 277 218 577 minecraft:red_concrete
fill 277 216 578 277 216 579 minecraft:yellow_concrete
fill 277 216 580 277 221 580 minecraft:red_concrete
fill 277 216 582 277 217 582 minecraft:yellow_concrete
setblock 277 216 583 minecraft:red_concrete
fill 277 216 588 277 221 589 minecraft:red_concrete
fill 277 216 590 277 217 591 minecraft:yellow_concrete
fill 277 216 597 277 218 597 minecraft:red_concrete
fill 277 216 599 277 217 599 minecraft:yellow_concrete
setblock 235 217 557 minecraft:yellow_concrete
fill 235 217 561 235 220 561 minecraft:red_concrete
fill 235 217 577 235 217 578 minecraft:yellow_concrete
setblock 235 217 581 minecraft:yellow_concrete
fill 235 217 582 235 220 582 minecraft:red_concrete
fill 235 217 593 235 220 593 minecraft:red_concrete
setblock 235 217 598 minecraft:yellow_concrete
setblock 245 217 599 minecraft:yellow_concrete
fill 246 217 557 246 220 557 minecraft:red_concrete
setblock 247 217 557 minecraft:yellow_concrete
fill 249 217 599 250 220 599 minecraft:red_concrete
fill 250 217 557 251 217 557 minecraft:yellow_concrete
setblock 266 217 599 minecraft:yellow_concrete
fill 267 217 557 267 220 557 minecraft:red_concrete
setblock 269 217 599 minecraft:yellow_concrete
fill 270 217 599 270 220 599 minecraft:red_concrete
setblock 271 217 557 minecraft:yellow_concrete
fill 277 217 558 277 220 558 minecraft:red_concrete
setblock 277 217 559 minecraft:yellow_concrete
setblock 277 217 562 minecraft:yellow_concrete
fill 277 217 578 277 220 578 minecraft:red_concrete
setblock 277 217 579 minecraft:yellow_concrete
setblock 277 217 583 minecraft:yellow_concrete
setblock 277 217 594 minecraft:yellow_concrete
fill 277 217 595 277 219 595 minecraft:red_concrete
fill 235 218 557 235 223 558 minecraft:red_concrete
fill 235 218 567 235 218 568 minecraft:yellow_concrete
fill 235 218 569 235 223 570 minecraft:red_concrete
fill 235 218 576 235 219 576 minecraft:yellow_concrete
fill 235 218 577 235 223 578 minecraft:red_concrete
setblock 235 218 579 minecraft:yellow_concrete
fill 235 218 581 235 223 581 minecraft:red_concrete
fill 235 218 587 235 219 588 minecraft:yellow_concrete
fill 235 218 589 235 223 590 minecraft:red_concrete
fill 235 218 598 235 223 598 minecraft:red_concrete
fill 235 218 599 236 218 599 minecraft:yellow_concrete
fill 237 218 599 238 223 599 minecraft:red_concrete
fill 238 218 557 239 223 557 minecraft:red_concrete
fill 240 218 557 241 219 557 minecraft:yellow_concrete
fill 243 218 599 244 219 599 minecraft:yellow_concrete
fill 245 218 599 246 223 599 minecraft:red_concrete
fill 247 218 557 247 223 557 minecraft:red_concrete
setblock 247 218 599 minecraft:yellow_concrete
setblock 249 218 557 minecraft:yellow_concrete
fill 250 218 557 251 223 557 minecraft:red_concrete
fill 252 218 557 252 219 557 minecraft:yellow_concrete
fill 255 218 599 256 219 599 minecraft:yellow_concrete
fill 257 218 599 258 223 599 minecraft:red_concrete
fill 258 218 557 259 223 557 minecraft:red_concrete
fill 260 218 557 261 218 557 minecraft:yellow_concrete
fill 264 218 599 264 219 599 minecraft:yellow_concrete
fill 266 218 599 266 223 599 minecraft:red_concrete
fill 267 218 599 268 218 599 minecraft:yellow_concrete
fill 269 218 599 269 223 599 minecraft:red_concrete
fill 270 218 557 271 223 557 minecraft:red_concrete
fill 272 218 557 273 219 557 minecraft:yellow_concrete
fill 275 218 599 276 219 599 minecraft:yellow_concrete
fill 277 218 559 277 223 559 minecraft:red_concrete
fill 277 218 560 277 218 561 minecraft:yellow_concrete
fill 277 218 562 277 223 562 minecraft:red_concrete
fill 277 218 564 277 219 564 minecraft:yellow_concrete
fill 277 218 570 277 223 571 minecraft:red_concrete
fill 277 218 572 277 219 573 minecraft:yellow_concrete
fill 277 218 579 277 220 579 minecraft:red_concrete
setblock 277 218 581 minecraft:yellow_concrete
fill 277 218 582 277 223 583 minecraft:red_concrete
fill 277 218 584 277 219 585 minecraft:yellow_concrete
fill 277 218 590 277 223 591 minecraft:red_concrete
fill 277 218 592 277 218 593 minecraft:yellow_concrete
fill 277 218 594 277 219 594 minecraft:red_concrete
fill 277 218 599 277 223 599 minecraft:red_concrete
setblock 235 219 564 minecraft:yellow_concrete
setblock 235 219 567 minecraft:yellow_concrete
fill 235 219 568 235 222 568 minecraft:red_concrete
setblock 235 219 575 minecraft:yellow_concrete
fill 235 219 579 235 222 579 minecraft:red_concrete
fill 235 219 595 235 219 596 minecraft:yellow_concrete
setblock 235 219 599 minecraft:yellow_concrete
fill 236 219 599 236 222 599 minecraft:red_concrete
fill 246 219 565 246 220 565 minecraft:yellow_concrete
fill 247 219 599 247 222 599 minecraft:red_concrete
fill 249 219 557 249 222 557 minecraft:red_concrete
setblock 252 219 599 minecraft:yellow_concrete
setblock 253 219 557 minecraft:yellow_concrete
fill 260 219 557 260 222 557 minecraft:red_concrete
setblock 261 219 557 minecraft:yellow_concrete
setblock 263 219 599 minecraft:yellow_concrete
setblock 264 219 557 minecraft:yellow_concrete
fill 267 219 599 268 221 599 minecraft:red_concrete
fill 277 219 560 277 222 561 minecraft:red_concrete
setblock 277 219 565 minecraft:yellow_concrete
setblock 277 219 576 minecraft:yellow_concrete
fill 277 219 577 277 221 577 minecraft:red_concrete
fill 277 219 581 277 222 581 minecraft:red_concrete
fill 277 219 592 277 222 592 minecraft:red_concrete
setblock 277 219 593 minecraft:yellow_concrete
fill 277 219 596 277 219 597 minecraft:yellow_concrete
fill 235 220 562 235 221 562 minecraft:yellow_concrete
fill 235 220 564 235 241 564 minecraft:red_concrete
fill 235 220 565 235 220 566 minecraft:yellow_concrete
fill 235 220 567 235 237 567 minecraft:red_concrete
fill 235 220 573 235 221 574 minecraft:yellow_concrete
fill 235 220 575 235 238 576 minecraft:red_concrete
fill 235 220 585 235 220 586 minecraft:yellow_concrete
fill 235 220 587 235 237 588 minecraft:red_concrete
fill 235 220 594 235 221 594 minecraft:yellow_concrete
fill 235 220 595 235 241 596 minecraft:red_concrete
setblock 235 220 597 minecraft:yellow_concrete
fill 235 220 599 235 237 599 minecraft:red_concrete
fill 240 220 557 241 237 557 minecraft:red_concrete
fill 241 220 599 242 221 599 minecraft:yellow_concrete
fill 242 220 557 243 220 557 minecraft:yellow_concrete
fill 243 220 599 244 237 599 minecraft:red_concrete
fill 252 220 557 253 238 557 minecraft:red_concrete
fill 252 220 599 252 241 599 minecraft:red_concrete
fill 253 220 599 254 220 599 minecraft:yellow_concrete
fill 254 220 557 255 221 557 minecraft:yellow_concrete
fill 255 220 599 256 237 599 minecraft:red_concrete
fill 261 220 557 261 237 557 minecraft:red_concrete
fill 261 220 599 262 221 599 minecraft:yellow_concrete
fill 262 220 557 263 220 557 minecraft:yellow_concrete
fill 263 220 599 264 238 599 minecraft:red_concrete
fill 264 220 557 264 241 557 minecraft:red_concrete
setblock 265 220 599 minecraft:yellow_concrete
fill 266 220 557 266 221 557 minecraft:yellow_concrete
fill 272 220 557 273 237 557 minecraft:red_concrete
fill 273 220 599 274 221 599 minecraft:yellow_concrete
fill 274 220 557 275 221 557 minecraft:yellow_concrete
fill 275 220 599 276 237 599 minecraft:red_concrete
setblock 277 220 563 minecraft:yellow_concrete
fill 277 220 564 277 238 565 minecraft:red_concrete
fill 277 220 566 277 221 567 minecraft:yellow_concrete
fill 277 220 572 277 237 573 minecraft:red_concrete
fill 277 220 574 277 220 575 minecraft:yellow_concrete
fill 277 220 576 277 241 576 minecraft:red_concrete
fill 277 220 584 277 238 585 minecraft:red_concrete
fill 277 220 586 277 221 587 minecraft:yellow_concrete
fill 277 220 593 277 237 593 minecraft:red_concrete
fill 277 220 594 277 220 595 minecraft:yellow_concrete
fill 277 220 596 277 221 597 minecraft:red_concrete
fill 277 220 598 277 221 598 minecraft:yellow_concrete
setblock 235 221 561 minecraft:yellow_concrete
fill 235 221 565 235 224 566 minecraft:red_concrete
setblock 235 221 582 minecraft:yellow_concrete
setblock 235 221 585 minecraft:yellow_concrete
fill 235 221 586 235 224 586 minecraft:red_concrete
setblock 235 221 593 minecraft:yellow_concrete
fill 235 221 597 235 224 597 minecraft:red_concrete
fill 242 221 557 242 224 557 minecraft:red_concrete
setblock 243 221 557 minecraft:yellow_concrete
setblock 246 221 557 minecraft:yellow_concrete
fill 249 221 599 250 221 599 minecraft:yellow_concrete
setblock 253 221 599 minecraft:yellow_concrete
fill 254 221 599 254 224 599 minecraft:red_concrete
fill 262 221 557 263 224 557 minecraft:red_concrete
fill 265 221 599 265 223 599 minecraft:red_concrete
setblock 267 221 557 minecraft:yellow_concrete
setblock 270 221 599 minecraft:yellow_concrete
setblock 277 221 558 minecraft:yellow_concrete
fill 277 221 563 277 224 563 minecraft:red_concrete
fill 277 221 574 277 224 574 minecraft:red_concrete
setblock 277 221 575 minecraft:yellow_concrete
fill 277 221 578 277 221 579 minecraft:yellow_concrete
fill 277 221 594 277 223 595 minecraft:red_concrete
fill 235 222 559 235 223 560 minecraft:yellow_concrete
fill 235 222 561 235 235 562 minecraft:red_concrete
setblock 235 222 563 minecraft:yellow_concrete
fill 235 222 571 235 223 572 minecraft:yellow_concrete
fill 235 222 573 235 235 574 minecraft:red_concrete
fill 235 222 580 235 223 580 minecraft:yellow_concrete
fill 235 222 582 235 235 582 minecraft:red_concrete
fill 235 222 583 235 222 584 minecraft:yellow_concrete
fill 235 222 585 235 239 585 minecraft:red_concrete
fill 235 222 591 235 223 592 minecraft:yellow_concrete
fill 235 222 593 235 235 594 minecraft:red_concrete
fill 236 222 557 237 223 557 minecraft:yellow_concrete
fill 236 222 558 238 222 558 minecraft:orange_concrete
fill 236 222 560 236 222 562 minecraft:orange_concrete
fill 236 222 564 236 222 566 minecraft:orange_concrete
fill 236 222 568 236 222 570 minecraft:orange_concrete
fill 236 222 572 236 222 574 minecraft:orange_concrete
fill 236 222 576 236 222 578 minecraft:orange_concrete
fill 236 222 580 236 222 582 minecraft:orange_concrete
fill 236 222 584 236 222 586 minecraft:orange_concrete
fill 236 222 588 236 222 590 minecraft:orange_concrete
fill 236 222 592 236 222 594 minecraft:orange_concrete
fill 236 222 596 236 222 598 minecraft:orange_concrete
fill 238 222 598 240 222 598 minecraft:orange_concrete
fill 239 222 599 240 222 599 minecraft:yellow_concrete
fill 240 222 558 242 222 558 minecraft:orange_concrete
fill 241 222 599 242 235 599 minecraft:red_concrete
fill 242 222 598 244 222 598 minecraft:orange_concrete
fill 243 222 557 243 239 557 minecraft:red_concrete
fill 244 222 557 245 222 557 minecraft:yellow_concrete
fill 244 222 558 246 222 558 minecraft:orange_concrete
fill 246 222 557 246 235 557 minecraft:red_concrete
fill 246 222 598 248 222 598 minecraft:orange_concrete
fill 248 222 557 248 223 557 minecraft:yellow_concrete
fill 248 222 558 250 222 558 minecraft:orange_concrete
fill 248 222 599 248 223 599 minecraft:yellow_concrete
fill 249 222 599 250 235 599 minecraft:red_concrete
fill 250 222 598 252 222 598 minecraft:orange_concrete
setblock 251 222 599 minecraft:yellow_concrete
fill 252 222 558 254 222 558 minecraft:orange_concrete
fill 253 222 599 253 239 599 minecraft:red_concrete
fill 254 222 557 255 235 557 minecraft:red_concrete
fill 254 222 598 256 222 598 minecraft:orange_concrete
fill 256 222 557 257 223 557 minecraft:yellow_concrete
fill 256 222 558 258 222 558 minecraft:orange_concrete
fill 258 222 598 260 222 598 minecraft:orange_concrete
fill 259 222 599 260 223 599 minecraft:yellow_concrete
fill 260 222 558 262 222 558 minecraft:orange_concrete
fill 261 222 599 262 235 599 minecraft:red_concrete
fill 262 222 598 264 222 598 minecraft:orange_concrete
fill 264 222 558 266 222 558 minecraft:orange_concrete
setblock 265 222 557 minecraft:yellow_concrete
fill 266 222 557 267 235 557 minecraft:red_concrete
fill 266 222 598 268 222 598 minecraft:orange_concrete
setblock 267 222 599 minecraft:red_concrete
fill 268 222 557 269 223 557 minecraft:yellow_concrete
fill 268 222 558 270 222 558 minecraft:orange_concrete
fill 268 222 599 268 223 599 minecraft:yellow_concrete
fill 270 222 598 272 222 598 minecraft:orange_concrete
fill 270 222 599 270 235 599 minecraft:red_concrete
fill 271 222 599 272 222 599 minecraft:yellow_concrete
fill 272 222 558 274 222 558 minecraft:orange_concrete
fill 273 222 584 275 225 584 minecraft:magma_block
fill 273 222 599 274 224 599 minecraft:red_concrete
fill 274 222 557 275 239 557 minecraft:red_concrete
fill 274 222 583 275 225 583 minecraft:magma_block
fill 274 222 585 276 225 585 minecraft:magma_block
fill 274 222 598 276 222 598 minecraft:orange_concrete
fill 276 222 557 277 222 557 minecraft:yellow_concrete
fill 276 222 558 276 222 560 minecraft:orange_concrete
fill 276 222 562 276 222 564 minecraft:orange_concrete
fill 276 222 566 276 222 568 minecraft:orange_concrete
fill 276 222 570 276 222 572 minecraft:orange_concrete
fill 276 222 574 276 222 576 minecraft:orange_concrete
fill 276 222 578 276 222 580 minecraft:orange_concrete
fill 276 222 582 276 222 584 minecraft:orange_concrete
fill 276 222 586 276 222 588 minecraft:orange_concrete
fill 276 222 590 276 222 592 minecraft:orange_concrete
fill 276 222 594 276 222 596 minecraft:orange_concrete
fill 277 222 558 277 235 558 minecraft:red_concrete
fill 277 222 566 277 235 567 minecraft:red_concrete
fill 277 222 568 277 223 569 minecraft:yellow_concrete
fill 277 222 575 277 239 575 minecraft:red_concrete
setblock 277 222 577 minecraft:yellow_concrete
fill 277 222 578 277 235 579 minecraft:red_concrete
fill 277 222 580 277 223 580 minecraft:yellow_concrete
fill 277 222 586 277 235 587 minecraft:red_concrete
fill 277 222 588 277 223 589 minecraft:yellow_concrete
fill 277 222 596 277 241 596 minecraft:red_concrete
setblock 277 222 597 minecraft:yellow_concrete
fill 277 222 598 277 235 598 minecraft:red_concrete
fill 235 223 563 235 241 563 minecraft:red_concrete
setblock 235 223 568 minecraft:yellow_concrete
setblock 235 223 579 minecraft:yellow_concrete
fill 235 223 583 235 241 584 minecraft:red_concrete
setblock 236 223 599 minecraft:yellow_concrete
setblock 238 223 560 minecraft:light[level=14]
setblock 238 223 568 minecraft:light[level=14]
setblock 238 223 576 minecraft:light[level=14]
setblock 238 223 584 minecraft:light[level=14]
setblock 238 223 592 minecraft:light[level=14]
setblock 239 223 599 minecraft:yellow_concrete
fill 240 223 599 240 241 599 minecraft:red_concrete
fill 244 223 557 245 241 557 minecraft:red_concrete
setblock 246 223 560 minecraft:light[level=14]
setblock 246 223 568 minecraft:light[level=14]
setblock 246 223 576 minecraft:light[level=14]
setblock 246 223 584 minecraft:light[level=14]
setblock 246 223 592 minecraft:light[level=14]
setblock 247 223 599 minecraft:yellow_concrete
setblock 249 223 557 minecraft:yellow_concrete
fill 251 223 599 251 241 599 minecraft:red_concrete
setblock 254 223 560 minecraft:light[level=14]
setblock 254 223 568 minecraft:light[level=14]
setblock 254 223 576 minecraft:light[level=14]
setblock 254 223 584 minecraft:light[level=14]
setblock 254 223 592 minecraft:light[level=14]
setblock 260 223 557 minecraft:yellow_concrete
setblock 262 223 560 minecraft:light[level=14]
setblock 262 223 568 minecraft:light[level=14]
setblock 262 223 576 minecraft:light[level=14]
setblock 262 223 584 minecraft:light[level=14]
setblock 262 223 592 minecraft:light[level=14]
fill 265 223 557 265 241 557 minecraft:red_concrete
setblock 267 223 599 minecraft:yellow_concrete
setblock 270 223 560 minecraft:light[level=14]
setblock 270 223 568 minecraft:light[level=14]
setblock 270 223 576 minecraft:light[level=14]
setblock 270 223 584 minecraft:light[level=14]
setblock 270 223 592 minecraft:light[level=14]
setblock 271 223 599 minecraft:yellow_concrete
fill 272 223 583 272 225 585 minecraft:magma_block
fill 272 223 599 272 241 599 minecraft:red_concrete
fill 273 223 583 273 225 583 minecraft:magma_block
fill 273 223 585 273 225 585 minecraft:magma_block
fill 274 223 582 276 224 582 minecraft:magma_block
fill 274 223 586 276 224 586 minecraft:magma_block
fill 276 223 557 276 241 557 minecraft:red_concrete
fill 276 223 583 276 225 584 minecraft:magma_block
setblock 277 223 557 minecraft:yellow_concrete
fill 277 223 560 277 223 561 minecraft:yellow_concrete
fill 277 223 577 277 241 577 minecraft:red_concrete
setblock 277 223 581 minecraft:yellow_concrete
setblock 277 223 592 minecraft:yellow_concrete
fill 277 223 597 277 241 597 minecraft:red_concrete
fill 235 224 557 235 225 558 minecraft:yellow_concrete
fill 235 224 559 235 237 560 minecraft:red_concrete
fill 235 224 568 235 237 568 minecraft:red_concrete
fill 235 224 569 235 224 570 minecraft:yellow_concrete
fill 235 224 571 235 241 572 minecraft:red_concrete
fill 235 224 577 235 225 578 minecraft:yellow_concrete
fill 235 224 579 235 237 580 minecraft:red_concrete
setblock 235 224 581 minecraft:yellow_concrete
fill 235 224 589 235 225 590 minecraft:yellow_concrete
fill 235 224 591 235 237 592 minecraft:red_concrete
fill 235 224 598 235 225 598 minecraft:yellow_concrete
fill 236 224 557 237 237 557 minecraft:red_concrete
fill 236 224 599 236 237 599 minecraft:red_concrete
fill 237 224 599 238 224 599 minecraft:yellow_concrete
fill 238 224 557 239 225 557 minecraft:yellow_concrete
fill 239 224 599 239 241 599 minecraft:red_concrete
fill 245 224 599 246 225 599 minecraft:yellow_concrete
setblock 247 224 557 minecraft:yellow_concrete
fill 247 224 599 248 237 599 minecraft:red_concrete
fill 248 224 557 249 237 557 minecraft:red_concrete
fill 250 224 557 251 225 557 minecraft:yellow_concrete
fill 256 224 557 257 241 557 minecraft:red_concrete
fill 257 224 599 258 224 599 minecraft:yellow_concrete
fill 258 224 557 259 224 557 minecraft:yellow_concrete
fill 259 224 599 260 237 599 minecraft:red_concrete
fill 260 224 557 260 237 557 minecraft:red_concrete
fill 265 224 599 266 225 599 minecraft:yellow_concrete
fill 267 224 599 268 237 599 minecraft:red_concrete
fill 268 224 557 269 237 557 minecraft:red_concrete
setblock 269 224 599 minecraft:yellow_concrete
fill 270 224 557 271 225 557 minecraft:yellow_concrete
fill 270 224 584 271 225 584 minecraft:magma_block
fill 271 224 583 271 225 583 minecraft:magma_block
fill 271 224 585 271 225 585 minecraft:magma_block
fill 271 224 599 271 241 599 minecraft:red_concrete
setblock 273 224 582 minecraft:magma_block
setblock 273 224 586 minecraft:magma_block
fill 277 224 557 277 241 557 minecraft:red_concrete
setblock 277 224 559 minecraft:yellow_concrete
fill 277 224 560 277 237 561 minecraft:red_concrete
fill 277 224 562 277 225 562 minecraft:yellow_concrete
fill 277 224 568 277 237 569 minecraft:red_concrete
fill 277 224 570 277 224 571 minecraft:yellow_concrete
fill 277 224 580 277 237 581 minecraft:red_concrete
fill 277 224 582 277 225 583 minecraft:yellow_concrete
fill 277 224 588 277 241 589 minecraft:red_concrete
fill 277 224 590 277 224 591 minecraft:yellow_concrete
fill 277 224 592 277 237 592 minecraft:red_concrete
fill 277 224 594 277 225 594 minecraft:yellow_concrete
setblock 277 224 595 minecraft:red_concrete
fill 277 224 599 277 225 599 minecraft:yellow_concrete
fill 235 225 565 235 225 566 minecraft:yellow_concrete
setblock 235 225 569 minecraft:yellow_concrete
fill 235 225 570 235 235 570 minecraft:red_concrete
fill 235 225 581 235 235 581 minecraft:red_concrete
setblock 235 225 586 minecraft:yellow_concrete
setblock 235 225 597 minecraft:yellow_concrete
fill 237 225 599 238 235 599 minecraft:red_concrete
setblock 242 225 557 minecraft:yellow_concrete
fill 247 225 557 247 235 557 minecraft:red_concrete
setblock 254 225 599 minecraft:yellow_concrete
setblock 257 225 599 minecraft:yellow_concrete
fill 258 225 557 258 235 557 minecraft:red_concrete
fill 258 225 599 258 235 599 minecraft:red_concrete
setblock 259 225 557 minecraft:yellow_concrete
fill 262 225 557 263 225 557 minecraft:yellow_concrete
setblock 269 225 584 minecraft:magma_block
fill 269 225 599 269 235 599 minecraft:red_concrete
setblock 270 225 583 minecraft:magma_block
setblock 270 225 585 minecraft:magma_block
fill 273 225 599 273 239 599 minecraft:red_concrete
setblock 274 225 599 minecraft:yellow_concrete
fill 277 225 559 277 235 559 minecraft:red_concrete
setblock 277 225 563 minecraft:yellow_concrete
fill 277 225 570 277 235 570 minecraft:red_concrete
setblock 277 225 571 minecraft:yellow_concrete
setblock 277 225 574 minecraft:yellow_concrete
fill 277 225 590 277 235 590 minecraft:red_concrete
setblock 277 225 591 minecraft:yellow_concrete
setblock 277 225 595 minecraft:yellow_concrete
fill 235 226 557 235 236 558 minecraft:red_concrete
fill 235 226 565 235 239 566 minecraft:red_concrete
fill 235 226 569 235 236 569 minecraft:red_concrete
fill 235 226 577 235 239 578 minecraft:red_concrete
fill 235 226 586 235 239 586 minecraft:red_concrete
fill 235 226 589 235 236 590 minecraft:red_concrete
fill 235 226 597 235 239 598 minecraft:red_concrete
fill 238 226 557 239 236 557 minecraft:red_concrete
fill 242 226 557 242 239 557 minecraft:red_concrete
fill 245 226 599 246 236 599 minecraft:red_concrete
fill 250 226 557 251 239 557 minecraft:red_concrete
fill 254 226 599 254 239 599 minecraft:red_concrete
fill 257 226 599 257 236 599 minecraft:red_concrete
fill 259 226 557 259 236 557 minecraft:red_concrete
fill 262 226 557 263 239 557 minecraft:red_concrete
fill 265 226 599 266 239 599 minecraft:red_concrete
fill 270 226 557 271 236 557 minecraft:red_concrete
fill 274 226 599 274 239 599 minecraft:red_concrete
fill 277 226 562 277 239 563 minecraft:red_concrete
fill 277 226 571 277 236 571 minecraft:red_concrete
fill 277 226 574 277 239 574 minecraft:red_concrete
fill 277 226 582 277 236 583 minecraft:red_concrete
fill 277 226 591 277 235 591 minecraft:red_concrete
fill 277 226 594 277 239 595 minecraft:red_concrete
fill 277 226 599 277 236 599 minecraft:red_concrete
fill 248 230 583 250 230 585 minecraft:redstone_block
fill 249 230 576 251 230 578 minecraft:redstone_block
fill 256 230 577 258 230 579 minecraft:redstone_block
fill 256 230 583 258 230 585 minecraft:redstone_block
fill 236 231 558 238 232 598 minecraft:orange_concrete
fill 239 231 558 242 232 598 minecraft:red_concrete
fill 243 231 558 245 232 598 minecraft:orange_concrete
fill 246 231 558 247 231 598 minecraft:red_concrete
fill 248 231 558 248 231 582 minecraft:red_concrete
fill 248 231 586 250 231 598 minecraft:red_concrete
fill 249 231 558 250 231 575 minecraft:red_concrete
fill 249 231 579 250 231 582 minecraft:red_concrete
fill 251 231 558 253 231 575 minecraft:orange_concrete
fill 251 231 579 251 231 598 minecraft:orange_concrete
fill 252 231 576 253 231 579 minecraft:orange_concrete
fill 252 231 583 253 231 598 minecraft:orange_concrete
fill 254 231 558 255 231 579 minecraft:red_concrete
fill 254 231 583 255 231 598 minecraft:red_concrete
fill 255 231 580 258 231 582 minecraft:red_concrete
fill 256 231 558 258 231 576 minecraft:red_concrete
fill 256 231 586 258 231 598 minecraft:red_concrete
fill 259 231 558 261 231 598 minecraft:orange_concrete
fill 262 231 558 266 232 598 minecraft:red_concrete
fill 267 231 558 269 232 598 minecraft:orange_concrete
fill 270 231 558 274 232 598 minecraft:red_concrete
fill 275 231 558 276 232 598 minecraft:orange_concrete
fill 246 232 558 246 232 598 minecraft:red_concrete
fill 247 232 558 247 232 581 minecraft:red_concrete
fill 247 232 582 247 232 586 minecraft:shroomlight
fill 247 232 587 250 232 598 minecraft:red_concrete
fill 248 232 558 250 232 574 minecraft:red_concrete
fill 248 232 575 248 232 579 minecraft:shroomlight
fill 248 232 580 250 232 581 minecraft:red_concrete
fill 248 232 582 251 232 582 minecraft:shroomlight
fill 248 232 583 250 232 585 minecraft:red_concrete
fill 248 232 586 251 232 586 minecraft:shroomlight
fill 249 232 575 252 232 575 minecraft:shroomlight
fill 249 232 576 251 232 578 minecraft:red_concrete
fill 249 232 579 255 232 579 minecraft:shroomlight
fill 251 232 558 253 232 574 minecraft:orange_concrete
fill 251 232 580 251 232 581 minecraft:shroomlight
fill 251 232 583 251 232 585 minecraft:shroomlight
fill 251 232 587 253 232 598 minecraft:orange_concrete
fill 252 232 576 252 232 578 minecraft:shroomlight
fill 252 232 583 255 232 583 minecraft:shroomlight
fill 252 232 584 253 232 586 minecraft:orange_concrete
fill 253 232 575 253 232 578 minecraft:orange_concrete
fill 254 232 558 254 232 578 minecraft:red_concrete
fill 254 232 584 254 232 598 minecraft:red_concrete
fill 255 232 558 258 232 575 minecraft:red_concrete
fill 255 232 576 255 232 578 minecraft:shroomlight
fill 255 232 580 255 232 582 minecraft:shroomlight
fill 255 232 584 255 232 586 minecraft:shroomlight
fill 255 232 587 258 232 598 minecraft:red_concrete
fill 256 232 576 259 232 576 minecraft:shroomlight
fill 256 232 577 258 232 579 minecraft:red_concrete
fill 256 232 580 259 232 580 minecraft:shroomlight
fill 256 232 581 258 232 581 minecraft:red_concrete
fill 256 232 582 259 232 582 minecraft:shroomlight
fill 256 232 583 258 232 585 minecraft:red_concrete
fill 256 232 586 259 232 586 minecraft:shroomlight
fill 259 232 558 261 232 575 minecraft:orange_concrete
fill 259 232 577 259 232 579 minecraft:shroomlight
fill 259 232 581 261 232 581 minecraft:orange_concrete
fill 259 232 583 259 232 585 minecraft:shroomlight
fill 259 232 587 261 232 598 minecraft:orange_concrete
fill 260 232 576 261 232 580 minecraft:orange_concrete
fill 260 232 582 261 232 586 minecraft:orange_concrete
fill 235 236 561 235 236 562 minecraft:yellow_concrete
fill 235 236 570 235 237 570 minecraft:yellow_concrete
setblock 235 236 573 minecraft:yellow_concrete
fill 235 236 574 235 239 574 minecraft:red_concrete
fill 235 236 581 235 237 582 minecraft:yellow_concrete
fill 235 236 593 235 236 594 minecraft:yellow_concrete
fill 237 236 599 238 237 599 minecraft:yellow_concrete
setblock 241 236 599 minecraft:yellow_concrete
fill 242 236 599 242 239 599 minecraft:red_concrete
fill 246 236 557 247 237 557 minecraft:yellow_concrete
fill 249 236 599 250 237 599 minecraft:yellow_concrete
fill 254 236 557 254 239 557 minecraft:red_concrete
setblock 255 236 557 minecraft:yellow_concrete
fill 258 236 557 258 237 557 minecraft:yellow_concrete
fill 258 236 599 258 237 599 minecraft:yellow_concrete
fill 261 236 599 262 236 599 minecraft:yellow_concrete
fill 266 236 557 267 236 557 minecraft:yellow_concrete
fill 269 236 599 270 237 599 minecraft:yellow_concrete
fill 277 236 558 277 237 559 minecraft:yellow_concrete
fill 277 236 566 277 236 567 minecraft:yellow_concrete
fill 277 236 570 277 237 570 minecraft:yellow_concrete
fill 277 236 578 277 237 579 minecraft:yellow_concrete
fill 277 236 586 277 239 586 minecraft:red_concrete
setblock 277 236 587 minecraft:yellow_concrete
fill 277 236 590 277 237 591 minecraft:yellow_concrete
setblock 277 236 598 minecraft:yellow_concrete
fill 235 237 557 235 239 557 minecraft:red_concrete
setblock 235 237 558 minecraft:yellow_concrete
setblock 235 237 561 minecraft:yellow_concrete
fill 235 237 562 235 240 562 minecraft:red_concrete
setblock 235 237 569 minecraft:yellow_concrete
fill 235 237 573 235 240 573 minecraft:red_concrete
fill 235 237 589 235 237 590 minecraft:yellow_concrete
setblock 235 237 593 minecraft:yellow_concrete
fill 235 237 594 235 240 594 minecraft:red_concrete
fill 238 237 557 239 237 557 minecraft:yellow_concrete
fill 241 237 599 241 239 599 minecraft:red_concrete
fill 245 237 599 245 239 599 minecraft:red_concrete
setblock 246 237 599 minecraft:yellow_concrete
fill 250 237 576 250 239 576 minecraft:red_concrete
fill 251 237 577 252 238 578 minecraft:red_concrete
fill 255 237 557 255 240 557 minecraft:red_concrete
setblock 257 237 599 minecraft:yellow_concrete
setblock 259 237 557 minecraft:yellow_concrete
fill 260 237 577 261 238 578 minecraft:red_concrete
fill 261 237 599 262 239 599 minecraft:red_concrete
fill 262 237 576 262 239 576 minecraft:red_concrete
fill 266 237 557 266 240 557 minecraft:red_concrete
setblock 267 237 557 minecraft:yellow_concrete
setblock 270 237 557 minecraft:yellow_concrete
fill 271 237 557 271 239 557 minecraft:red_concrete
fill 277 237 566 277 240 567 minecraft:red_concrete
setblock 277 237 571 minecraft:yellow_concrete
setblock 277 237 582 minecraft:yellow_concrete
fill 277 237 583 277 239 583 minecraft:red_concrete
fill 277 237 587 277 240 587 minecraft:red_concrete
fill 277 237 598 277 240 598 minecraft:red_concrete
setblock 277 237 599 minecraft:yellow_concrete
fill 235 238 558 235 243 558 minecraft:red_concrete
fill 235 238 559 235 238 560 minecraft:yellow_concrete
fill 235 238 561 235 243 561 minecraft:red_concrete
fill 235 238 567 235 239 568 minecraft:yellow_concrete
fill 235 238 569 235 243 570 minecraft:red_concrete
fill 235 238 579 235 238 580 minecraft:yellow_concrete
fill 235 238 581 235 243 582 minecraft:red_concrete
setblock 235 238 587 minecraft:red_concrete
fill 235 238 588 235 239 588 minecraft:yellow_concrete
fill 235 238 589 235 243 590 minecraft:red_concrete
setblock 235 238 591 minecraft:yellow_concrete
fill 235 238 592 235 241 593 minecraft:red_concrete
fill 235 238 599 236 239 599 minecraft:yellow_concrete
fill 236 238 557 236 241 557 minecraft:red_concrete
setblock 237 238 557 minecraft:yellow_concrete
fill 237 238 599 238 243 599 minecraft:red_concrete
fill 238 238 557 239 243 557 minecraft:red_concrete
fill 240 238 557 240 239 557 minecraft:yellow_concrete
setblock 241 238 557 minecraft:red_concrete
setblock 243 238 599 minecraft:red_concrete
fill 244 238 599 244 239 599 minecraft:yellow_concrete
fill 246 238 557 247 243 557 minecraft:red_concrete
fill 246 238 599 246 243 599 minecraft:red_concrete
fill 247 238 573 248 239 573 minecraft:red_concrete
fill 247 238 590 248 239 590 minecraft:yellow_concrete
fill 247 238 599 248 238 599 minecraft:yellow_concrete
fill 248 238 557 249 238 557 minecraft:yellow_concrete
fill 248 238 574 249 239 575 minecraft:red_concrete
setblock 249 238 576 minecraft:red_concrete
fill 249 238 599 250 240 599 minecraft:red_concrete
setblock 250 238 575 minecraft:red_concrete
fill 250 238 577 250 238 578 minecraft:red_concrete
setblock 251 238 576 minecraft:red_concrete
fill 251 238 579 251 240 579 minecraft:yellow_concrete
fill 255 238 599 256 239 599 minecraft:yellow_concrete
fill 257 238 599 258 243 599 minecraft:red_concrete
fill 258 238 557 259 243 557 minecraft:red_concrete
setblock 259 238 599 minecraft:yellow_concrete
fill 260 238 557 261 239 557 minecraft:yellow_concrete
fill 260 238 579 261 238 579 minecraft:yellow_concrete
fill 260 238 599 260 241 599 minecraft:red_concrete
setblock 261 238 576 minecraft:red_concrete
fill 262 238 575 264 238 575 minecraft:red_concrete
fill 262 238 577 262 238 578 minecraft:red_concrete
fill 263 238 574 264 239 574 minecraft:red_concrete
setblock 263 238 576 minecraft:red_concrete
fill 264 238 573 265 239 573 minecraft:red_concrete
fill 267 238 557 267 243 557 minecraft:red_concrete
fill 267 238 599 268 239 599 minecraft:yellow_concrete
fill 268 238 557 269 238 557 minecraft:yellow_concrete
fill 269 238 599 270 243 599 minecraft:red_concrete
fill 270 238 557 270 243 557 minecraft:red_concrete
fill 272 238 557 272 239 557 minecraft:yellow_concrete
setblock 273 238 557 minecraft:red_concrete
setblock 275 238 599 minecraft:red_concrete
fill 276 238 599 276 239 599 minecraft:yellow_concrete
fill 277 238 558 277 243 559 minecraft:red_concrete
fill 277 238 560 277 239 561 minecraft:yellow_concrete
fill 277 238 568 277 241 568 minecraft:red_concrete
setblock 277 238 569 minecraft:yellow_concrete
fill 277 238 570 277 243 571 minecraft:red_concrete
fill 277 238 572 277 239 573 minecraft:yellow_concrete
fill 277 238 578 277 243 579 minecraft:red_concrete
fill 277 238 580 277 238 581 minecraft:yellow_concrete
fill 277 238 582 277 243 582 minecraft:red_concrete
fill 277 238 590 277 243 591 minecraft:red_concrete
fill 277 238 592 277 239 593 minecraft:yellow_concrete
fill 277 238 599 277 243 599 minecraft:red_concrete
fill 235 239 559 235 242 560 minecraft:red_concrete
fill 235 239 575 235 241 575 minecraft:red_concrete
setblock 235 239 576 minecraft:yellow_concrete
setblock 235 239 579 minecraft:yellow_concrete
fill 235 239 580 235 242 580 minecraft:red_concrete
setblock 235 239 587 minecraft:yellow_concrete
fill 235 239 591 235 242 591 minecraft:red_concrete
fill 237 239 557 237 242 557 minecraft:red_concrete
setblock 238 239 560 minecraft:light[level=14]
setblock 238 239 568 minecraft:light[level=14]
setblock 238 239 576 minecraft:light[level=14]
setblock 238 239 584 minecraft:light[level=14]
setblock 238 239 592 minecraft:light[level=14]
setblock 241 239 557 minecraft:yellow_concrete
fill 243 239 569 244 240 569 minecraft:red_concrete
setblock 243 239 599 minecraft:yellow_concrete
fill 244 239 570 245 239 571 minecraft:red_concrete
fill 245 239 572 247 239 572 minecraft:red_concrete
setblock 246 239 560 minecraft:light[level=14]
setblock 246 239 568 minecraft:light[level=14]
setblock 246 239 571 minecraft:red_concrete
setblock 246 239 573 minecraft:red_concrete
setblock 246 239 576 minecraft:light[level=14]
setblock 246 239 584 minecraft:light[level=14]
setblock 246 239 592 minecraft:light[level=14]
setblock 247 239 574 minecraft:red_concrete
fill 247 239 575 247 240 575 minecraft:orange_concrete
setblock 247 239 599 minecraft:yellow_concrete
fill 248 239 557 248 242 557 minecraft:red_concrete
fill 248 239 576 249 239 576 minecraft:orange_concrete
fill 248 239 599 248 242 599 minecraft:red_concrete
setblock 249 239 557 minecraft:yellow_concrete
fill 249 239 577 249 240 577 minecraft:yellow_concrete
fill 250 239 577 251 239 577 minecraft:orange_concrete
fill 250 239 578 250 240 578 minecraft:red_concrete
fill 250 239 579 250 241 579 minecraft:yellow_concrete
fill 251 239 578 252 239 578 minecraft:yellow_concrete
setblock 252 239 557 minecraft:yellow_concrete
fill 253 239 557 253 241 557 minecraft:red_concrete
setblock 254 239 560 minecraft:light[level=14]
setblock 254 239 568 minecraft:light[level=14]
setblock 254 239 576 minecraft:light[level=14]
setblock 254 239 584 minecraft:light[level=14]
setblock 254 239 592 minecraft:light[level=14]
fill 259 239 599 259 241 599 minecraft:red_concrete
fill 260 239 578 261 239 578 minecraft:yellow_concrete
setblock 260 239 579 minecraft:orange_concrete
fill 261 239 577 262 239 577 minecraft:orange_concrete
fill 261 239 579 262 240 579 minecraft:yellow_concrete
setblock 262 239 560 minecraft:light[level=14]
setblock 262 239 568 minecraft:light[level=14]
fill 262 239 578 262 240 578 minecraft:red_concrete
setblock 262 239 584 minecraft:light[level=14]
setblock 262 239 592 minecraft:light[level=14]
fill 263 239 575 264 239 575 minecraft:red_concrete
fill 263 239 576 264 239 576 minecraft:orange_concrete
fill 263 239 577 263 240 577 minecraft:yellow_concrete
fill 263 239 599 263 241 599 minecraft:red_concrete
setblock 264 239 599 minecraft:yellow_concrete
fill 265 239 572 267 239 572 minecraft:red_concrete
setblock 265 239 574 minecraft:red_concrete
fill 265 239 575 265 240 575 minecraft:orange_concrete
fill 266 239 571 268 239 571 minecraft:red_concrete
setblock 266 239 573 minecraft:red_concrete
fill 267 239 570 268 240 570 minecraft:red_concrete
fill 268 239 557 269 242 557 minecraft:red_concrete
fill 268 239 569 269 240 569 minecraft:red_concrete
setblock 270 239 560 minecraft:light[level=14]
setblock 270 239 568 minecraft:light[level=14]
setblock 270 239 576 minecraft:light[level=14]
setblock 270 239 584 minecraft:light[level=14]
setblock 270 239 592 minecraft:light[level=14]
setblock 273 239 557 minecraft:yellow_concrete
fill 273 239 583 273 240 583 minecraft:orange_concrete
setblock 275 239 599 minecraft:yellow_concrete
setblock 277 239 564 minecraft:yellow_concrete
fill 277 239 565 277 241 565 minecraft:red_concrete
fill 277 239 569 277 242 569 minecraft:red_concrete
fill 277 239 580 277 242 580 minecraft:red_concrete
setblock 277 239 581 minecraft:yellow_concrete
fill 277 239 584 277 239 585 minecraft:yellow_concrete
setblock 235 240 557 minecraft:yellow_concrete
fill 235 240 565 235 241 566 minecraft:yellow_concrete
fill 235 240 567 235 245 568 minecraft:red_concrete
fill 235 240 574 235 241 574 minecraft:yellow_concrete
fill 235 240 576 235 245 576 minecraft:red_concrete
fill 235 240 577 235 240 578 minecraft:yellow_concrete
fill 235 240 579 235 245 579 minecraft:red_concrete
fill 235 240 585 235 241 586 minecraft:yellow_concrete
fill 235 240 587 235 245 588 minecraft:red_concrete
fill 235 240 597 235 240 598 minecraft:yellow_concrete
fill 235 240 599 236 245 599 minecraft:red_concrete
fill 236 240 558 238 240 558 minecraft:orange_concrete
fill 236 240 560 236 240 562 minecraft:orange_concrete
fill 236 240 564 236 240 566 minecraft:orange_concrete
fill 236 240 568 236 240 570 minecraft:orange_concrete
fill 236 240 572 236 240 574 minecraft:orange_concrete
fill 236 240 576 236 240 578 minecraft:orange_concrete
fill 236 240 580 236 240 582 minecraft:orange_concrete
fill 236 240 584 236 240 586 minecraft:orange_concrete
fill 236 240 588 236 240 590 minecraft:orange_concrete
fill 236 240 592 236 240 594 minecraft:orange_concrete
fill 236 240 596 236 240 598 minecraft:orange_concrete
fill 238 240 598 240 240 598 minecraft:orange_concrete
fill 239 240 565 240 241 565 minecraft:red_concrete
fill 240 240 557 241 245 557 minecraft:red_concrete
fill 240 240 558 242 240 558 minecraft:orange_concrete
fill 240 240 566 241 241 566 minecraft:red_concrete
fill 241 240 567 242 240 568 minecraft:red_concrete
fill 241 240 599 242 241 599 minecraft:yellow_concrete
fill 242 240 557 243 241 557 minecraft:yellow_concrete
setblock 242 240 569 minecraft:red_concrete
fill 242 240 598 244 240 598 minecraft:orange_concrete
setblock 243 240 568 minecraft:red_concrete
fill 243 240 570 245 240 570 minecraft:red_concrete
fill 243 240 599 244 245 599 minecraft:red_concrete
fill 244 240 558 246 240 558 minecraft:orange_concrete
setblock 245 240 571 minecraft:red_concrete
fill 245 240 572 245 241 573 minecraft:orange_concrete
setblock 245 240 599 minecraft:yellow_concrete
setblock 246 240 572 minecraft:red_concrete
fill 246 240 573 247 240 574 minecraft:orange_concrete
fill 246 240 598 248 240 598 minecraft:orange_concrete
fill 247 240 576 249 240 576 minecraft:yellow_concrete
fill 247 240 599 247 242 599 minecraft:red_concrete
fill 248 240 558 250 240 558 minecraft:orange_concrete
fill 248 240 574 248 240 575 minecraft:orange_concrete
setblock 248 240 577 minecraft:yellow_concrete
fill 249 240 557 249 245 557 minecraft:red_concrete
setblock 249 240 578 minecraft:red_concrete
fill 249 240 579 249 242 579 minecraft:yellow_concrete
fill 250 240 557 251 240 557 minecraft:yellow_concrete
setblock 250 240 577 minecraft:red_concrete
setblock 250 240 580 minecraft:orange_concrete
fill 250 240 598 252 240 598 minecraft:orange_concrete
setblock 251 240 578 minecraft:yellow_concrete
fill 252 240 557 252 245 557 minecraft:red_concrete
fill 252 240 558 254 240 558 minecraft:orange_concrete
fill 253 240 599 254 241 599 minecraft:yellow_concrete
fill 254 240 557 254 241 557 minecraft:yellow_concrete
fill 254 240 598 256 240 598 minecraft:orange_concrete
fill 255 240 599 256 245 599 minecraft:red_concrete
fill 256 240 558 258 240 558 minecraft:orange_concrete
fill 258 240 598 260 240 598 minecraft:orange_concrete
fill 260 240 557 261 245 557 minecraft:red_concrete
fill 260 240 558 262 240 558 minecraft:orange_concrete
setblock 261 240 578 minecraft:yellow_concrete
fill 261 240 580 262 240 580 minecraft:orange_concrete
setblock 261 240 599 minecraft:red_concrete
fill 262 240 557 263 241 557 minecraft:yellow_concrete
setblock 262 240 577 minecraft:red_concrete
fill 262 240 598 264 240 598 minecraft:orange_concrete
fill 262 240 599 262 241 599 minecraft:yellow_concrete
fill 263 240 576 265 240 576 minecraft:yellow_concrete
setblock 263 240 578 minecraft:red_concrete
fill 263 240 579 263 242 579 minecraft:yellow_concrete
fill 264 240 558 266 240 558 minecraft:orange_concrete
fill 264 240 574 264 240 575 minecraft:orange_concrete
setblock 264 240 577 minecraft:yellow_concrete
fill 264 240 599 264 245 599 minecraft:red_concrete
fill 265 240 573 266 240 574 minecraft:orange_concrete
fill 265 240 599 266 240 599 minecraft:yellow_concrete
setblock 266 240 572 minecraft:red_concrete
fill 266 240 598 268 240 598 minecraft:orange_concrete
setblock 267 240 571 minecraft:red_concrete
fill 267 240 572 267 241 573 minecraft:orange_concrete
fill 267 240 599 268 242 599 minecraft:red_concrete
fill 268 240 558 270 240 558 minecraft:orange_concrete
fill 269 240 568 271 240 568 minecraft:red_concrete
setblock 269 240 570 minecraft:red_concrete
fill 270 240 567 271 241 567 minecraft:red_concrete
setblock 270 240 569 minecraft:red_concrete
fill 270 240 598 272 240 598 minecraft:orange_concrete
setblock 271 240 557 minecraft:yellow_concrete
fill 271 240 566 272 241 566 minecraft:red_concrete
fill 272 240 557 273 245 557 minecraft:red_concrete
fill 272 240 558 274 240 558 minecraft:orange_concrete
fill 272 240 565 273 241 565 minecraft:red_concrete
fill 273 240 599 274 241 599 minecraft:yellow_concrete
fill 274 240 557 275 241 557 minecraft:yellow_concrete
fill 274 240 598 276 240 598 minecraft:orange_concrete
fill 275 240 599 276 245 599 minecraft:red_concrete
fill 276 240 558 276 240 560 minecraft:orange_concrete
fill 276 240 562 276 240 564 minecraft:orange_concrete
fill 276 240 566 276 240 568 minecraft:orange_concrete
fill 276 240 570 276 240 572 minecraft:orange_concrete
fill 276 240 574 276 240 576 minecraft:orange_concrete
fill 276 240 578 276 240 580 minecraft:orange_concrete
fill 276 240 582 276 240 584 minecraft:orange_concrete
fill 276 240 586 276 240 588 minecraft:orange_concrete
fill 276 240 590 276 240 592 minecraft:orange_concrete
fill 276 240 594 276 240 596 minecraft:orange_concrete
fill 277 240 560 277 245 561 minecraft:red_concrete
fill 277 240 562 277 240 563 minecraft:yellow_concrete
fill 277 240 564 277 245 564 minecraft:red_concrete
fill 277 240 572 277 245 573 minecraft:red_concrete
fill 277 240 574 277 241 575 minecraft:yellow_concrete
fill 277 240 581 277 245 581 minecraft:red_concrete
setblock 277 240 583 minecraft:yellow_concrete
fill 277 240 584 277 245 585 minecraft:red_concrete
fill 277 240 586 277 241 586 minecraft:yellow_concrete
fill 277 240 592 277 245 593 minecraft:red_concrete
fill 277 240 594 277 240 595 minecraft:yellow_concrete
fill 235 241 557 235 244 557 minecraft:red_concrete
setblock 235 241 562 minecraft:yellow_concrete
setblock 235 241 573 minecraft:yellow_concrete
fill 235 241 577 235 244 578 minecraft:red_concrete
setblock 235 241 594 minecraft:yellow_concrete
setblock 235 241 597 minecraft:yellow_concrete
fill 235 241 598 235 244 598 minecraft:red_concrete
fill 236 241 562 237 242 562 minecraft:red_concrete
fill 237 241 563 238 242 563 minecraft:red_concrete
fill 238 241 564 239 241 564 minecraft:red_concrete
fill 241 241 567 242 241 567 minecraft:red_concrete
setblock 242 241 568 minecraft:red_concrete
fill 242 241 571 244 242 571 minecraft:orange_concrete
fill 243 241 572 244 242 572 minecraft:orange_concrete
setblock 244 241 573 minecraft:orange_concrete
fill 245 241 575 247 241 575 minecraft:yellow_concrete
fill 245 241 599 245 244 599 minecraft:red_concrete
setblock 246 241 573 minecraft:orange_concrete
fill 246 241 574 246 242 574 minecraft:yellow_concrete
fill 246 241 576 248 241 576 minecraft:yellow_concrete
fill 247 241 577 249 241 577 minecraft:red_concrete
fill 248 241 578 250 241 578 minecraft:orange_concrete
fill 248 241 579 248 243 579 minecraft:yellow_concrete
fill 249 241 580 250 241 580 minecraft:red_concrete
fill 249 241 599 249 243 599 minecraft:red_concrete
fill 250 241 557 251 244 557 minecraft:red_concrete
setblock 250 241 599 minecraft:yellow_concrete
fill 251 241 558 253 244 558 minecraft:magma_block
fill 252 241 559 252 244 559 minecraft:magma_block
setblock 255 241 557 minecraft:yellow_concrete
setblock 261 241 599 minecraft:yellow_concrete
fill 262 241 571 262 242 571 minecraft:shroomlight
fill 262 241 578 264 241 578 minecraft:orange_concrete
setblock 262 241 579 minecraft:yellow_concrete
fill 262 241 580 263 241 580 minecraft:red_concrete
fill 263 241 577 265 241 577 minecraft:red_concrete
fill 264 241 576 266 241 576 minecraft:yellow_concrete
fill 264 241 579 264 243 579 minecraft:yellow_concrete
fill 265 241 575 267 241 575 minecraft:yellow_concrete
setblock 265 241 599 minecraft:yellow_concrete
setblock 266 241 557 minecraft:yellow_concrete
setblock 266 241 573 minecraft:orange_concrete
fill 266 241 574 266 242 574 minecraft:yellow_concrete
fill 266 241 599 266 244 599 minecraft:red_concrete
fill 268 241 571 268 241 573 minecraft:orange_concrete
fill 269 241 571 269 242 572 minecraft:orange_concrete
setblock 270 241 568 minecraft:red_concrete
fill 270 241 571 270 242 571 minecraft:orange_concrete
fill 271 241 557 271 244 557 minecraft:red_concrete
fill 273 241 564 274 241 564 minecraft:red_concrete
fill 274 241 563 275 242 563 minecraft:red_concrete
fill 275 241 562 277 242 562 minecraft:red_concrete
setblock 277 241 563 minecraft:yellow_concrete
fill 277 241 566 277 241 567 minecraft:yellow_concrete
fill 277 241 583 277 244 583 minecraft:red_concrete
setblock 277 241 587 minecraft:yellow_concrete
fill 277 241 594 277 244 594 minecraft:red_concrete
setblock 277 241 595 minecraft:yellow_concrete
setblock 277 241 598 minecraft:yellow_concrete
fill 235 242 562 235 247 562 minecraft:red_concrete
fill 235 242 563 235 242 564 minecraft:yellow_concrete
fill 235 242 565 235 247 566 minecraft:red_concrete
fill 235 242 571 235 243 572 minecraft:yellow_concrete
fill 235 242 573 235 247 574 minecraft:red_concrete
setblock 235 242 575 minecraft:yellow_concrete
fill 235 242 583 235 243 584 minecraft:yellow_concrete
fill 235 242 585 235 247 586 minecraft:red_concrete
fill 235 242 592 235 243 592 minecraft:yellow_concrete
fill 235 242 593 235 243 594 minecraft:red_concrete
fill 235 242 595 235 242 596 minecraft:yellow_concrete
fill 235 242 597 235 247 597 minecraft:red_concrete
fill 236 242 557 236 243 557 minecraft:yellow_concrete
setblock 238 242 564 minecraft:red_concrete
fill 239 242 599 240 243 599 minecraft:yellow_concrete
fill 240 242 569 241 243 569 minecraft:orange_concrete
fill 241 242 570 243 242 570 minecraft:orange_concrete
fill 241 242 599 242 247 599 minecraft:red_concrete
fill 242 242 557 243 247 557 minecraft:red_concrete
fill 244 242 557 245 243 557 minecraft:yellow_concrete
fill 244 242 574 245 243 574 minecraft:yellow_concrete
fill 245 242 575 246 242 575 minecraft:yellow_concrete
fill 246 242 576 247 242 577 minecraft:red_concrete
fill 247 242 578 249 242 578 minecraft:orange_concrete
setblock 248 242 577 minecraft:red_concrete
fill 248 242 580 249 242 580 minecraft:red_concrete
fill 249 242 581 249 244 581 minecraft:orange_concrete
setblock 250 242 580 minecraft:orange_concrete
fill 250 242 599 250 243 599 minecraft:red_concrete
fill 251 242 559 251 243 561 minecraft:magma_block
fill 251 242 599 252 242 599 minecraft:yellow_concrete
fill 252 242 560 252 243 563 minecraft:magma_block
setblock 253 242 557 minecraft:yellow_concrete
fill 253 242 559 253 243 561 minecraft:magma_block
fill 253 242 599 254 247 599 minecraft:red_concrete
fill 254 242 557 255 247 557 minecraft:red_concrete
fill 256 242 557 257 243 557 minecraft:yellow_concrete
fill 259 242 599 260 243 599 minecraft:yellow_concrete
fill 261 242 599 262 247 599 minecraft:red_concrete
fill 262 242 557 263 247 557 minecraft:red_concrete
setblock 262 242 580 minecraft:orange_concrete
fill 263 242 578 265 242 578 minecraft:orange_concrete
fill 263 242 580 264 242 580 minecraft:red_concrete
fill 263 242 581 263 244 581 minecraft:orange_concrete
setblock 263 242 599 minecraft:yellow_concrete
fill 264 242 557 265 242 557 minecraft:yellow_concrete
fill 264 242 577 266 242 577 minecraft:red_concrete
fill 265 242 576 266 242 576 minecraft:red_concrete
fill 265 242 599 265 244 599 minecraft:red_concrete
fill 266 242 557 266 247 557 minecraft:red_concrete
fill 266 242 575 267 242 575 minecraft:yellow_concrete
fill 267 242 574 268 243 574 minecraft:yellow_concrete
fill 268 242 571 268 242 572 minecraft:orange_concrete
fill 269 242 570 271 242 570 minecraft:orange_concrete
fill 271 242 569 272 243 569 minecraft:orange_concrete
fill 271 242 599 272 243 599 minecraft:yellow_concrete
fill 273 242 599 274 247 599 minecraft:red_concrete
fill 274 242 557 275 247 557 minecraft:red_concrete
setblock 274 242 564 minecraft:red_concrete
fill 275 242 586 275 245 586 minecraft:magma_block
fill 276 242 557 277 243 557 minecraft:yellow_concrete
fill 277 242 563 277 247 563 minecraft:red_concrete
setblock 277 242 565 minecraft:yellow_concrete
fill 277 242 566 277 247 567 minecraft:red_concrete
fill 277 242 568 277 243 568 minecraft:yellow_concrete
fill 277 242 574 277 247 575 minecraft:red_concrete
fill 277 242 576 277 242 577 minecraft:yellow_concrete
fill 277 242 586 277 247 587 minecraft:red_concrete
fill 277 242 588 277 243 589 minecraft:yellow_concrete
fill 277 242 595 277 247 595 minecraft:red_concrete
fill 277 242 596 277 242 597 minecraft:yellow_concrete
fill 277 242 598 277 247 598 minecraft:red_concrete
fill 235 243 559 235 243 560 minecraft:yellow_concrete
setblock 235 243 563 minecraft:yellow_concrete
fill 235 243 564 235 246 564 minecraft:red_concrete
fill 235 243 575 235 246 575 minecraft:red_concrete
setblock 235 243 580 minecraft:yellow_concrete
setblock 235 243 591 minecraft:yellow_concrete
fill 235 243 595 235 245 596 minecraft:red_concrete
setblock 237 243 557 minecraft:yellow_concrete
fill 238 243 567 239 244 568 minecraft:orange_concrete
setblock 239 243 569 minecraft:orange_concrete
setblock 240 243 568 minecraft:orange_concrete
fill 241 243 570 242 243 570 minecraft:orange_concrete
fill 242 243 573 244 243 573 minecraft:yellow_concrete
fill 243 243 574 243 244 574 minecraft:yellow_concrete
fill 244 243 576 246 243 576 minecraft:red_concrete
fill 245 243 577 246 243 577 minecraft:red_concrete
fill 246 243 578 248 243 578 minecraft:orange_concrete
fill 247 243 579 247 244 580 minecraft:yellow_concrete
fill 247 243 599 248 243 599 minecraft:yellow_concrete
setblock 248 243 557 minecraft:yellow_concrete
setblock 248 243 580 minecraft:yellow_concrete
fill 248 243 581 248 244 581 minecraft:red_concrete
setblock 249 243 580 minecraft:red_concrete
setblock 251 243 599 minecraft:yellow_concrete
setblock 252 243 564 minecraft:magma_block
fill 252 243 599 252 246 599 minecraft:red_concrete
fill 253 243 557 253 246 557 minecraft:red_concrete
fill 259 243 568 259 244 568 minecraft:yellow_concrete
setblock 263 243 580 minecraft:red_concrete
fill 263 243 599 263 246 599 minecraft:red_concrete
fill 264 243 557 264 246 557 minecraft:red_concrete
fill 264 243 578 266 243 578 minecraft:orange_concrete
fill 264 243 580 265 243 580 minecraft:yellow_concrete
fill 264 243 581 264 244 581 minecraft:red_concrete
setblock 265 243 557 minecraft:yellow_concrete
fill 265 243 579 265 245 579 minecraft:yellow_concrete
fill 266 243 576 267 243 577 minecraft:red_concrete
fill 267 243 599 267 245 599 minecraft:red_concrete
fill 268 243 557 269 243 557 minecraft:yellow_concrete
fill 268 243 573 270 243 573 minecraft:yellow_concrete
fill 268 243 576 268 245 576 minecraft:red_concrete
setblock 268 243 599 minecraft:yellow_concrete
fill 269 243 574 269 244 574 minecraft:yellow_concrete
fill 270 243 570 271 243 570 minecraft:orange_concrete
fill 272 243 568 274 243 568 minecraft:orange_concrete
fill 273 243 567 274 244 567 minecraft:orange_concrete
setblock 273 243 569 minecraft:orange_concrete
fill 273 243 586 274 245 586 minecraft:magma_block
fill 274 243 585 276 244 585 minecraft:magma_block
fill 274 243 587 276 244 587 minecraft:magma_block
fill 276 243 586 276 244 586 minecraft:magma_block
fill 277 243 562 277 244 562 minecraft:red_concrete
fill 277 243 565 277 246 565 minecraft:red_concrete
setblock 277 243 569 minecraft:yellow_concrete
fill 277 243 576 277 246 576 minecraft:red_concrete
setblock 277 243 577 minecraft:yellow_concrete
setblock 277 243 580 minecraft:yellow_concrete
fill 277 243 596 277 246 597 minecraft:red_concrete
fill 235 244 558 235 245 558 minecraft:yellow_concrete
fill 235 244 559 235 249 560 minecraft:red_concrete
setblock 235 244 561 minecraft:yellow_concrete
fill 235 244 563 235 249 563 minecraft:red_concrete
fill 235 244 569 235 245 570 minecraft:yellow_concrete
fill 235 244 571 235 249 572 minecraft:red_concrete
fill 235 244 580 235 249 580 minecraft:red_concrete
fill 235 244 581 235 244 582 minecraft:yellow_concrete
fill 235 244 583 235 249 584 minecraft:red_concrete
fill 235 244 589 235 245 590 minecraft:yellow_concrete
fill 235 244 591 235 249 592 minecraft:red_concrete
setblock 235 244 593 minecraft:yellow_concrete
fill 235 244 594 235 247 594 minecraft:red_concrete
fill 236 244 557 237 249 557 minecraft:red_concrete
fill 236 244 566 238 244 566 minecraft:orange_concrete
fill 237 244 567 237 245 567 minecraft:orange_concrete
fill 237 244 599 238 245 599 minecraft:yellow_concrete
fill 238 244 557 239 245 557 minecraft:yellow_concrete
fill 239 244 599 240 249 599 minecraft:red_concrete
fill 241 244 572 242 244 573 minecraft:yellow_concrete
setblock 243 244 573 minecraft:yellow_concrete
fill 243 244 576 245 244 576 minecraft:red_concrete
fill 244 244 557 245 249 557 minecraft:red_concrete
setblock 244 244 575 minecraft:red_concrete
setblock 245 244 577 minecraft:red_concrete
fill 245 244 578 247 244 578 minecraft:orange_concrete
fill 246 244 557 247 244 557 minecraft:yellow_concrete
fill 246 244 579 246 246 580 minecraft:yellow_concrete
fill 246 244 599 246 245 599 minecraft:yellow_concrete
fill 247 244 581 247 246 581 minecraft:red_concrete
fill 247 244 599 248 245 599 minecraft:red_concrete
fill 248 244 557 248 249 557 minecraft:red_concrete
setblock 248 244 580 minecraft:red_concrete
fill 248 244 582 248 245 582 minecraft:orange_concrete
fill 249 244 599 250 244 599 minecraft:yellow_concrete
fill 251 244 599 251 249 599 minecraft:red_concrete
fill 256 244 557 257 249 557 minecraft:red_concrete
fill 257 244 599 258 245 599 minecraft:yellow_concrete
fill 258 244 557 259 245 557 minecraft:yellow_concrete
fill 259 244 599 260 249 599 minecraft:red_concrete
setblock 264 244 580 minecraft:red_concrete
fill 264 244 582 264 245 582 minecraft:orange_concrete
fill 265 244 557 265 249 557 minecraft:red_concrete
fill 265 244 578 267 244 578 minecraft:orange_concrete
fill 265 244 580 266 244 580 minecraft:yellow_concrete
fill 265 244 581 265 246 581 minecraft:red_concrete
fill 266 244 579 266 246 579 minecraft:yellow_concrete
setblock 267 244 557 minecraft:yellow_concrete
fill 267 244 576 267 244 577 minecraft:red_concrete
fill 268 244 557 269 249 557 minecraft:red_concrete
setblock 268 244 575 minecraft:red_concrete
fill 268 244 599 268 249 599 minecraft:red_concrete
fill 269 244 573 271 244 573 minecraft:yellow_concrete
fill 269 244 576 269 246 576 minecraft:red_concrete
fill 269 244 599 270 244 599 minecraft:yellow_concrete
fill 270 244 557 270 245 557 minecraft:yellow_concrete
fill 270 244 572 271 244 572 minecraft:yellow_concrete
fill 271 244 599 272 249 599 minecraft:red_concrete
fill 272 244 586 272 246 586 minecraft:magma_block
fill 273 244 568 274 244 568 minecraft:orange_concrete
fill 273 244 585 273 245 585 minecraft:magma_block
fill 273 244 587 273 245 587 minecraft:magma_block
fill 274 244 566 276 244 566 minecraft:orange_concrete
fill 275 244 567 275 245 567 minecraft:orange_concrete
fill 276 244 557 277 249 557 minecraft:red_concrete
fill 277 244 558 277 244 559 minecraft:yellow_concrete
fill 277 244 568 277 249 569 minecraft:red_concrete
fill 277 244 570 277 245 571 minecraft:yellow_concrete
fill 277 244 577 277 249 577 minecraft:red_concrete
fill 277 244 578 277 244 579 minecraft:yellow_concrete
fill 277 244 580 277 249 580 minecraft:red_concrete
fill 277 244 582 277 245 582 minecraft:yellow_concrete
fill 277 244 588 277 249 589 minecraft:red_concrete
fill 277 244 590 277 245 591 minecraft:yellow_concrete
fill 277 244 599 277 245 599 minecraft:yellow_concrete
setblock 235 245 557 minecraft:yellow_concrete
fill 235 245 561 235 248 561 minecraft:red_concrete
fill 235 245 577 235 245 578 minecraft:yellow_concrete
setblock 235 245 581 minecraft:yellow_concrete
fill 235 245 582 235 248 582 minecraft:red_concrete
fill 235 245 593 235 247 593 minecraft:red_concrete
setblock 235 245 598 minecraft:yellow_concrete
fill 236 245 566 237 245 566 minecraft:orange_concrete
fill 239 245 571 240 246 572 minecraft:yellow_concrete
fill 241 245 572 241 245 573 minecraft:yellow_concrete
setblock 242 245 573 minecraft:yellow_concrete
fill 242 245 575 243 246 576 minecraft:red_concrete
setblock 244 245 576 minecraft:red_concrete
fill 244 245 578 246 245 578 minecraft:orange_concrete
fill 245 245 579 245 246 580 minecraft:yellow_concrete
setblock 245 245 599 minecraft:yellow_concrete
fill 246 245 557 246 248 557 minecraft:red_concrete
fill 246 245 581 246 247 581 minecraft:red_concrete
setblock 247 245 557 minecraft:yellow_concrete
setblock 247 245 579 minecraft:yellow_concrete
setblock 247 245 580 minecraft:red_concrete
fill 247 245 582 247 247 582 minecraft:orange_concrete
setblock 248 245 581 minecraft:orange_concrete
fill 249 245 599 250 247 599 minecraft:red_concrete
fill 250 245 557 251 245 557 minecraft:yellow_concrete
fill 256 245 560 257 246 561 minecraft:orange_concrete
setblock 264 245 581 minecraft:orange_concrete
setblock 265 245 580 minecraft:red_concrete
fill 265 245 582 265 247 582 minecraft:orange_concrete
fill 265 245 599 266 245 599 minecraft:yellow_concrete
fill 266 245 578 268 245 578 minecraft:orange_concrete
fill 266 245 580 267 246 580 minecraft:yellow_concrete
fill 266 245 581 266 247 581 minecraft:red_concrete
fill 267 245 557 267 248 557 minecraft:red_concrete
fill 267 245 579 267 246 579 minecraft:yellow_concrete
fill 269 245 575 270 246 575 minecraft:red_concrete
setblock 269 245 599 minecraft:yellow_concrete
fill 270 245 573 271 245 573 minecraft:yellow_concrete
fill 270 245 576 270 246 576 minecraft:red_concrete
fill 270 245 586 271 246 586 minecraft:magma_block
fill 270 245 599 270 248 599 minecraft:red_concrete
setblock 271 245 557 minecraft:yellow_concrete
fill 271 245 572 273 245 572 minecraft:yellow_concrete
fill 272 245 571 273 246 571 minecraft:yellow_concrete
setblock 272 245 585 minecraft:magma_block
setblock 272 245 587 minecraft:magma_block
setblock 274 245 585 minecraft:magma_block
setblock 274 245 587 minecraft:magma_block
fill 275 245 566 276 245 566 minecraft:orange_concrete
fill 277 245 558 277 248 558 minecraft:red_concrete
setblock 277 245 559 minecraft:yellow_concrete
setblock 277 245 562 minecraft:yellow_concrete
fill 277 245 578 277 248 579 minecraft:red_concrete
setblock 277 245 583 minecraft:yellow_concrete
setblock 277 245 594 minecraft:yellow_concrete
fill 235 246 557 235 251 558 minecraft:red_concrete
fill 235 246 567 235 246 568 minecraft:yellow_concrete
fill 235 246 569 235 251 570 minecraft:red_concrete
fill 235 246 576 235 247 576 minecraft:yellow_concrete
fill 235 246 577 235 251 578 minecraft:red_concrete
setblock 235 246 579 minecraft:yellow_concrete
fill 235 246 581 235 251 581 minecraft:red_concrete
fill 235 246 587 235 247 588 minecraft:yellow_concrete
fill 235 246 589 235 251 590 minecraft:red_concrete
setblock 235 246 595 minecraft:red_concrete
fill 235 246 596 235 247 596 minecraft:yellow_concrete
fill 235 246 598 235 251 598 minecraft:red_concrete
fill 235 246 599 236 246 599 minecraft:yellow_concrete
fill 236 246 558 238 246 558 minecraft:orange_concrete
fill 236 246 560 236 246 562 minecraft:orange_concrete
fill 236 246 564 236 246 566 minecraft:orange_concrete
fill 236 246 568 236 246 570 minecraft:orange_concrete
fill 236 246 572 236 246 574 minecraft:orange_concrete
fill 236 246 576 236 246 578 minecraft:orange_concrete
fill 236 246 580 236 246 582 minecraft:orange_concrete
fill 236 246 584 236 246 586 minecraft:orange_concrete
fill 236 246 588 236 246 590 minecraft:orange_concrete
fill 236 246 592 236 246 594 minecraft:orange_concrete
fill 236 246 596 236 246 598 minecraft:orange_concrete
fill 237 246 599 238 248 599 minecraft:red_concrete
fill 238 246 557 239 251 557 minecraft:red_concrete
fill 238 246 570 238 247 571 minecraft:yellow_concrete
fill 238 246 598 240 246 598 minecraft:orange_concrete
fill 240 246 557 241 247 557 minecraft:yellow_concrete
fill 240 246 558 242 246 558 minecraft:orange_concrete
fill 241 246 575 241 247 576 minecraft:red_concrete
fill 242 246 598 244 246 598 minecraft:orange_concrete
fill 243 246 578 245 246 578 minecraft:orange_concrete
fill 243 246 599 244 247 599 minecraft:yellow_concrete
fill 244 246 558 246 246 558 minecraft:orange_concrete
fill 244 246 580 244 248 580 minecraft:yellow_concrete
fill 245 246 581 245 248 581 minecraft:red_concrete
fill 245 246 599 246 251 599 minecraft:red_concrete
fill 246 246 582 246 247 582 minecraft:red_concrete
fill 246 246 583 247 247 583 minecraft:orange_concrete
fill 246 246 598 248 246 598 minecraft:orange_concrete
fill 247 246 557 247 251 557 minecraft:red_concrete
setblock 247 246 599 minecraft:yellow_concrete
fill 248 246 558 250 246 558 minecraft:orange_concrete
fill 248 246 599 248 249 599 minecraft:red_concrete
setblock 249 246 557 minecraft:yellow_concrete
fill 250 246 557 251 251 557 minecraft:red_concrete
fill 250 246 598 252 246 598 minecraft:orange_concrete
fill 252 246 557 252 247 557 minecraft:yellow_concrete
fill 252 246 558 254 246 558 minecraft:orange_concrete
fill 254 246 598 256 246 598 minecraft:orange_concrete
fill 255 246 599 256 247 599 minecraft:yellow_concrete
fill 256 246 558 258 246 558 minecraft:orange_concrete
fill 257 246 599 258 251 599 minecraft:red_concrete
fill 258 246 557 259 251 557 minecraft:red_concrete
fill 258 246 598 260 246 598 minecraft:orange_concrete
fill 260 246 557 261 246 557 minecraft:yellow_concrete
fill 260 246 558 262 246 558 minecraft:orange_concrete
fill 262 246 598 264 246 598 minecraft:orange_concrete
fill 264 246 558 266 246 558 minecraft:orange_concrete
fill 264 246 599 264 247 599 minecraft:yellow_concrete
fill 265 246 583 266 247 583 minecraft:orange_concrete
fill 265 246 599 266 251 599 minecraft:red_concrete
fill 266 246 582 266 247 582 minecraft:red_concrete
fill 266 246 598 268 246 598 minecraft:orange_concrete
fill 267 246 578 269 246 578 minecraft:orange_concrete
fill 267 246 581 267 248 581 minecraft:red_concrete
setblock 267 246 599 minecraft:yellow_concrete
fill 268 246 558 270 246 558 minecraft:orange_concrete
fill 268 246 580 268 248 580 minecraft:yellow_concrete
setblock 269 246 586 minecraft:magma_block
fill 269 246 599 269 251 599 minecraft:red_concrete
fill 270 246 557 271 251 557 minecraft:red_concrete
fill 270 246 598 272 246 598 minecraft:orange_concrete
fill 271 246 575 271 247 576 minecraft:red_concrete
fill 272 246 557 273 247 557 minecraft:yellow_concrete
fill 272 246 558 274 246 558 minecraft:orange_concrete
fill 272 246 572 273 246 572 minecraft:yellow_concrete
fill 274 246 570 274 247 571 minecraft:yellow_concrete
fill 274 246 598 276 246 598 minecraft:orange_concrete
fill 275 246 599 276 247 599 minecraft:yellow_concrete
fill 276 246 558 276 246 560 minecraft:orange_concrete
fill 276 246 562 276 246 564 minecraft:orange_concrete
fill 276 246 566 276 246 568 minecraft:orange_concrete
fill 276 246 570 276 246 572 minecraft:orange_concrete
fill 276 246 574 276 246 576 minecraft:orange_concrete
fill 276 246 578 276 246 580 minecraft:orange_concrete
fill 276 246 582 276 246 584 minecraft:orange_concrete
fill 276 246 586 276 246 588 minecraft:orange_concrete
fill 276 246 590 276 246 592 minecraft:orange_concrete
fill 276 246 594 276 246 596 minecraft:orange_concrete
fill 277 246 559 277 251 559 minecraft:red_concrete
fill 277 246 560 277 246 561 minecraft:yellow_concrete
fill 277 246 562 277 251 562 minecraft:red_concrete
fill 277 246 564 277 247 564 minecraft:yellow_concrete
fill 277 246 570 277 251 571 minecraft:red_concrete
fill 277 246 572 277 247 573 minecraft:yellow_concrete
setblock 277 246 581 minecraft:yellow_concrete
fill 277 246 582 277 251 583 minecraft:red_concrete
fill 277 246 584 277 247 585 minecraft:yellow_concrete
fill 277 246 590 277 251 591 minecraft:red_concrete
fill 277 246 592 277 246 593 minecraft:yellow_concrete
fill 277 246 594 277 251 594 minecraft:red_concrete
fill 277 246 599 277 251 599 minecraft:red_concrete
setblock 235 247 564 minecraft:yellow_concrete
setblock 235 247 567 minecraft:yellow_concrete
fill 235 247 568 235 250 568 minecraft:red_concrete
setblock 235 247 575 minecraft:yellow_concrete
fill 235 247 579 235 250 579 minecraft:red_concrete
setblock 235 247 595 minecraft:yellow_concrete
setblock 235 247 599 minecraft:yellow_concrete
fill 236 247 570 237 248 570 minecraft:yellow_concrete
fill 236 247 599 236 250 599 minecraft:red_concrete
setblock 237 247 571 minecraft:yellow_concrete
setblock 238 247 560 minecraft:light[level=14]
setblock 238 247 568 minecraft:light[level=14]
setblock 238 247 576 minecraft:light[level=14]
setblock 238 247 584 minecraft:light[level=14]
setblock 238 247 592 minecraft:light[level=14]
setblock 239 247 571 minecraft:yellow_concrete
fill 240 247 575 240 248 575 minecraft:red_concrete
setblock 242 247 575 minecraft:red_concrete
fill 242 247 578 244 247 578 minecraft:orange_concrete
fill 243 247 580 243 249 580 minecraft:yellow_concrete
fill 244 247 581 244 248 581 minecraft:yellow_concrete
setblock 245 247 580 minecraft:yellow_concrete
fill 245 247 582 245 249 582 minecraft:red_concrete
fill 245 247 583 245 249 583 minecraft:orange_concrete
setblock 246 247 560 minecraft:light[level=14]
setblock 246 247 568 minecraft:light[level=14]
setblock 246 247 576 minecraft:light[level=14]
setblock 246 247 584 minecraft:light[level=14]
setblock 246 247 592 minecraft:light[level=14]
fill 247 247 599 247 249 599 minecraft:red_concrete
fill 249 247 557 249 250 557 minecraft:red_concrete
setblock 252 247 599 minecraft:yellow_concrete
setblock 253 247 557 minecraft:yellow_concrete
setblock 254 247 560 minecraft:light[level=14]
setblock 254 247 568 minecraft:light[level=14]
setblock 254 247 576 minecraft:light[level=14]
setblock 254 247 584 minecraft:light[level=14]
setblock 254 247 592 minecraft:light[level=14]
fill 260 247 557 260 250 557 minecraft:red_concrete
setblock 261 247 557 minecraft:yellow_concrete
setblock 262 247 560 minecraft:light[level=14]
setblock 262 247 568 minecraft:light[level=14]
setblock 262 247 576 minecraft:light[level=14]
setblock 262 247 584 minecraft:light[level=14]
setblock 262 247 592 minecraft:light[level=14]
setblock 263 247 599 minecraft:yellow_concrete
setblock 264 247 557 minecraft:yellow_concrete
setblock 267 247 580 minecraft:yellow_concrete
fill 267 247 582 267 249 582 minecraft:red_concrete
fill 267 247 583 267 249 583 minecraft:orange_concrete
fill 267 247 599 267 250 599 minecraft:red_concrete
fill 268 247 578 270 247 578 minecraft:orange_concrete
fill 268 247 581 268 248 581 minecraft:yellow_concrete
fill 269 247 580 269 249 580 minecraft:yellow_concrete
setblock 270 247 560 minecraft:light[level=14]
setblock 270 247 568 minecraft:light[level=14]
setblock 270 247 575 minecraft:red_concrete
setblock 270 247 576 minecraft:light[level=14]
setblock 270 247 584 minecraft:light[level=14]
setblock 270 247 592 minecraft:light[level=14]
fill 272 247 575 272 248 575 minecraft:red_concrete
setblock 273 247 571 minecraft:yellow_concrete
fill 275 247 570 275 247 571 minecraft:yellow_concrete
fill 276 247 570 276 248 570 minecraft:yellow_concrete
fill 277 247 560 277 250 561 minecraft:red_concrete
setblock 277 247 565 minecraft:yellow_concrete
setblock 277 247 576 minecraft:yellow_concrete
fill 277 247 581 277 250 581 minecraft:red_concrete
fill 277 247 592 277 250 592 minecraft:red_concrete
setblock 277 247 593 minecraft:yellow_concrete
fill 277 247 596 277 247 597 minecraft:yellow_concrete
fill 235 248 562 235 249 562 minecraft:yellow_concrete
fill 235 248 564 235 253 564 minecraft:red_concrete
fill 235 248 565 235 248 566 minecraft:yellow_concrete
fill 235 248 567 235 253 567 minecraft:red_concrete
fill 235 248 573 235 249 574 minecraft:yellow_concrete
fill 235 248 575 235 253 576 minecraft:red_concrete
fill 235 248 585 235 248 586 minecraft:yellow_concrete
fill 235 248 587 235 253 588 minecraft:red_concrete
fill 235 248 593 235 249 594 minecraft:yellow_concrete
fill 235 248 595 235 253 596 minecraft:red_concrete
setblock 235 248 597 minecraft:yellow_concrete
fill 235 248 599 235 250 599 minecraft:red_concrete
fill 239 248 574 239 249 575 minecraft:red_concrete
fill 240 248 557 241 253 557 minecraft:red_concrete
setblock 240 248 574 minecraft:red_concrete
setblock 241 248 575 minecraft:red_concrete
fill 241 248 578 243 248 578 minecraft:orange_concrete
fill 241 248 599 242 249 599 minecraft:yellow_concrete
fill 242 248 557 243 248 557 minecraft:yellow_concrete
fill 243 248 581 243 249 581 minecraft:yellow_concrete
fill 243 248 599 244 253 599 minecraft:red_concrete
fill 244 248 582 244 250 582 minecraft:red_concrete
fill 245 248 584 245 250 584 minecraft:orange_concrete
fill 246 248 582 246 248 583 minecraft:orange_concrete
setblock 249 248 599 minecraft:red_concrete
fill 250 248 599 250 249 599 minecraft:yellow_concrete
fill 252 248 557 253 253 557 minecraft:red_concrete
fill 252 248 599 252 253 599 minecraft:red_concrete
fill 253 248 599 254 248 599 minecraft:yellow_concrete
fill 254 248 557 255 249 557 minecraft:yellow_concrete
fill 255 248 599 256 250 599 minecraft:red_concrete
fill 261 248 557 261 253 557 minecraft:red_concrete
fill 261 248 599 262 249 599 minecraft:yellow_concrete
fill 262 248 557 263 248 557 minecraft:yellow_concrete
fill 263 248 599 264 253 599 minecraft:red_concrete
fill 264 248 557 264 253 557 minecraft:red_concrete
fill 266 248 557 266 249 557 minecraft:yellow_concrete
fill 266 248 582 266 248 583 minecraft:orange_concrete
fill 267 248 584 267 250 584 minecraft:orange_concrete
fill 268 248 582 268 250 582 minecraft:red_concrete
fill 269 248 578 271 248 578 minecraft:orange_concrete
fill 269 248 581 269 249 581 minecraft:yellow_concrete
setblock 271 248 575 minecraft:red_concrete
fill 272 248 557 273 253 557 minecraft:red_concrete
fill 272 248 574 273 248 574 minecraft:red_concrete
fill 273 248 575 273 249 575 minecraft:red_concrete
fill 273 248 599 274 248 599 minecraft:yellow_concrete
fill 274 248 557 275 249 557 minecraft:yellow_concrete
setblock 275 248 570 minecraft:yellow_concrete
fill 275 248 599 276 253 599 minecraft:red_concrete
setblock 277 248 563 minecraft:yellow_concrete
fill 277 248 564 277 253 565 minecraft:red_concrete
fill 277 248 566 277 249 567 minecraft:yellow_concrete
fill 277 248 572 277 253 573 minecraft:red_concrete
fill 277 248 574 277 248 575 minecraft:yellow_concrete
fill 277 248 576 277 253 576 minecraft:red_concrete
fill 277 248 584 277 253 585 minecraft:red_concrete
fill 277 248 586 277 249 587 minecraft:yellow_concrete
fill 277 248 593 277 253 593 minecraft:red_concrete
setblock 277 248 595 minecraft:yellow_concrete
fill 277 248 596 277 253 597 minecraft:red_concrete
fill 277 248 598 277 249 598 minecraft:yellow_concrete
setblock 235 249 561 minecraft:yellow_concrete
fill 235 249 565 235 252 566 minecraft:red_concrete
setblock 235 249 582 minecraft:yellow_concrete
setblock 235 249 585 minecraft:yellow_concrete
fill 235 249 586 235 252 586 minecraft:red_concrete
fill 235 249 597 235 252 597 minecraft:red_concrete
fill 237 249 574 238 250 574 minecraft:red_concrete
fill 237 249 599 237 251 599 minecraft:red_concrete
fill 238 249 575 238 250 575 minecraft:red_concrete
setblock 238 249 599 minecraft:yellow_concrete
fill 240 249 578 242 249 578 minecraft:orange_concrete
fill 242 249 557 242 252 557 minecraft:red_concrete
fill 242 249 580 242 250 581 minecraft:yellow_concrete
setblock 243 249 557 minecraft:yellow_concrete
fill 243 249 582 243 251 583 minecraft:red_concrete
fill 244 249 583 244 250 583 minecraft:red_concrete
fill 244 249 584 244 251 584 minecraft:orange_concrete
setblock 246 249 557 minecraft:yellow_concrete
setblock 246 249 583 minecraft:orange_concrete
setblock 249 249 599 minecraft:yellow_concrete
setblock 253 249 599 minecraft:yellow_concrete
fill 254 249 599 254 252 599 minecraft:red_concrete
fill 262 249 557 263 252 557 minecraft:red_concrete
setblock 266 249 583 minecraft:orange_concrete
setblock 267 249 557 minecraft:yellow_concrete
fill 268 249 583 269 250 583 minecraft:red_concrete
fill 268 249 584 268 251 584 minecraft:orange_concrete
fill 269 249 582 269 251 582 minecraft:red_concrete
fill 270 249 578 272 249 578 minecraft:orange_concrete
fill 270 249 580 270 250 581 minecraft:yellow_concrete
setblock 270 249 599 minecraft:yellow_concrete
fill 273 249 574 275 249 574 minecraft:red_concrete
setblock 273 249 599 minecraft:yellow_concrete
fill 274 249 575 274 250 575 minecraft:red_concrete
fill 274 249 599 274 252 599 minecraft:red_concrete
setblock 277 249 558 minecraft:yellow_concrete
fill 277 249 563 277 252 563 minecraft:red_concrete
fill 277 249 574 277 252 574 minecraft:red_concrete
setblock 277 249 575 minecraft:yellow_concrete
fill 277 249 578 277 249 579 minecraft:yellow_concrete
fill 277 249 595 277 252 595 minecraft:red_concrete
fill 235 250 559 235 251 560 minecraft:yellow_concrete
fill 235 250 561 235 255 562 minecraft:red_concrete
setblock 235 250 563 minecraft:yellow_concrete
fill 235 250 571 235 251 572 minecraft:yellow_concrete
fill 235 250 573 235 255 574 minecraft:red_concrete
fill 235 250 580 235 251 580 minecraft:yellow_concrete
fill 235 250 582 235 255 582 minecraft:red_concrete
fill 235 250 583 235 250 584 minecraft:yellow_concrete
fill 235 250 585 235 255 585 minecraft:red_concrete
fill 235 250 591 235 251 592 minecraft:yellow_concrete
fill 235 250 593 235 255 594 minecraft:red_concrete
fill 236 250 557 237 251 557 minecraft:yellow_concrete
fill 236 250 574 236 251 574 minecraft:red_concrete
setblock 237 250 575 minecraft:red_concrete
fill 238 250 599 238 251 599 minecraft:red_concrete
fill 239 250 578 241 250 578 minecraft:orange_concrete
fill 239 250 599 240 250 599 minecraft:yellow_concrete
fill 241 250 580 241 251 581 minecraft:yellow_concrete
fill 241 250 599 242 255 599 minecraft:red_concrete
fill 243 250 557 243 255 557 minecraft:red_concrete
fill 244 250 557 245 250 557 minecraft:yellow_concrete
fill 244 250 585 244 252 585 minecraft:orange_concrete
fill 246 250 557 246 255 557 minecraft:red_concrete
fill 247 250 599 248 251 599 minecraft:yellow_concrete
fill 248 250 557 248 251 557 minecraft:yellow_concrete
fill 249 250 599 250 255 599 minecraft:red_concrete
setblock 251 250 599 minecraft:yellow_concrete
fill 253 250 599 253 252 599 minecraft:red_concrete
fill 254 250 557 255 255 557 minecraft:red_concrete
fill 256 250 557 257 251 557 minecraft:yellow_concrete
fill 259 250 599 260 251 599 minecraft:yellow_concrete
fill 261 250 599 262 255 599 minecraft:red_concrete
setblock 265 250 557 minecraft:yellow_concrete
fill 266 250 557 267 255 557 minecraft:red_concrete
fill 268 250 557 269 251 557 minecraft:yellow_concrete
fill 268 250 585 268 252 585 minecraft:orange_concrete
fill 268 250 599 268 251 599 minecraft:yellow_concrete
fill 270 250 599 270 255 599 minecraft:red_concrete
fill 271 250 578 273 250 578 minecraft:orange_concrete
fill 271 250 580 271 251 581 minecraft:yellow_concrete
fill 271 250 599 272 250 599 minecraft:yellow_concrete
fill 273 250 599 273 255 599 minecraft:red_concrete
fill 274 250 557 275 255 557 minecraft:red_concrete
fill 274 250 574 276 250 574 minecraft:red_concrete
setblock 275 250 575 minecraft:red_concrete
fill 276 250 557 277 250 557 minecraft:yellow_concrete
fill 277 250 558 277 255 558 minecraft:red_concrete
fill 277 250 566 277 255 567 minecraft:red_concrete
fill 277 250 568 277 251 569 minecraft:yellow_concrete
fill 277 250 575 277 255 575 minecraft:red_concrete
setblock 277 250 577 minecraft:yellow_concrete
fill 277 250 578 277 255 579 minecraft:red_concrete
fill 277 250 580 277 251 580 minecraft:yellow_concrete
fill 277 250 586 277 255 587 minecraft:red_concrete
fill 277 250 588 277 250 589 minecraft:yellow_concrete
fill 277 250 598 277 255 598 minecraft:red_concrete
fill 235 251 563 235 254 563 minecraft:red_concrete
setblock 235 251 568 minecraft:yellow_concrete
setblock 235 251 579 minecraft:yellow_concrete
fill 235 251 583 235 253 584 minecraft:red_concrete
fill 235 251 599 236 251 599 minecraft:yellow_concrete
setblock 237 251 574 minecraft:red_concrete
fill 238 251 578 240 251 578 minecraft:orange_concrete
setblock 239 251 599 minecraft:yellow_concrete
fill 240 251 581 240 253 581 minecraft:yellow_concrete
fill 240 251 599 240 254 599 minecraft:red_concrete
setblock 242 251 581 minecraft:yellow_concrete
fill 242 251 583 242 253 583 minecraft:red_concrete
fill 243 251 584 243 252 585 minecraft:orange_concrete
fill 244 251 557 245 254 557 minecraft:red_concrete
setblock 249 251 557 minecraft:yellow_concrete
fill 251 251 599 251 254 599 minecraft:red_concrete
fill 255 251 599 255 253 599 minecraft:red_concrete
setblock 256 251 599 minecraft:yellow_concrete
setblock 260 251 557 minecraft:yellow_concrete
fill 265 251 557 265 254 557 minecraft:red_concrete
setblock 267 251 599 minecraft:yellow_concrete
fill 269 251 583 270 252 583 minecraft:red_concrete
fill 269 251 584 269 252 585 minecraft:orange_concrete
setblock 270 251 581 minecraft:yellow_concrete
fill 271 251 599 272 254 599 minecraft:red_concrete
fill 272 251 578 274 251 578 minecraft:orange_concrete
fill 272 251 581 272 253 581 minecraft:yellow_concrete
fill 275 251 574 276 251 574 minecraft:red_concrete
fill 276 251 557 276 254 557 minecraft:red_concrete
setblock 277 251 557 minecraft:yellow_concrete
fill 277 251 560 277 251 561 minecraft:yellow_concrete
fill 277 251 577 277 254 577 minecraft:red_concrete
setblock 277 251 581 minecraft:yellow_concrete
fill 277 251 588 277 254 588 minecraft:red_concrete
setblock 277 251 589 minecraft:yellow_concrete
setblock 277 251 592 minecraft:yellow_concrete
fill 235 252 557 235 253 558 minecraft:yellow_concrete
fill 235 252 559 235 257 560 minecraft:red_concrete
fill 235 252 568 235 257 568 minecraft:red_concrete
fill 235 252 569 235 252 570 minecraft:yellow_concrete
fill 235 252 571 235 257 572 minecraft:red_concrete
fill 235 252 577 235 253 578 minecraft:yellow_concrete
fill 235 252 579 235 257 580 minecraft:red_concrete
setblock 235 252 581 minecraft:yellow_concrete
fill 235 252 589 235 253 590 minecraft:yellow_concrete
fill 235 252 591 235 257 592 minecraft:red_concrete
fill 235 252 598 235 253 598 minecraft:yellow_concrete
fill 235 252 599 236 253 599 minecraft:red_concrete
fill 236 252 557 237 257 557 minecraft:red_concrete
fill 236 252 558 238 252 558 minecraft:orange_concrete
fill 236 252 560 236 252 562 minecraft:orange_concrete
fill 236 252 564 236 252 566 minecraft:orange_concrete
fill 236 252 568 236 252 570 minecraft:orange_concrete
fill 236 252 572 236 252 574 minecraft:orange_concrete
fill 236 252 576 236 252 578 minecraft:orange_concrete
fill 236 252 580 236 252 582 minecraft:orange_concrete
fill 236 252 584 236 252 586 minecraft:orange_concrete
fill 236 252 588 236 252 590 minecraft:orange_concrete
fill 236 252 592 236 252 594 minecraft:orange_concrete
fill 236 252 596 236 252 598 minecraft:orange_concrete
fill 237 252 578 239 252 578 minecraft:orange_concrete
fill 237 252 599 238 252 599 minecraft:yellow_concrete
fill 238 252 557 239 253 557 minecraft:yellow_concrete
fill 238 252 598 240 252 598 minecraft:orange_concrete
fill 239 252 581 239 254 581 minecraft:yellow_concrete
fill 239 252 599 239 257 599 minecraft:red_concrete
fill 240 252 558 242 252 558 minecraft:orange_concrete
fill 240 252 582 240 253 582 minecraft:yellow_concrete
setblock 241 252 581 minecraft:yellow_concrete
fill 241 252 583 241 254 584 minecraft:red_concrete
fill 242 252 584 242 253 584 minecraft:red_concrete
fill 242 252 585 242 254 585 minecraft:orange_concrete
fill 242 252 598 244 252 598 minecraft:orange_concrete
setblock 243 252 583 minecraft:red_concrete
fill 243 252 586 243 253 586 minecraft:orange_concrete
fill 244 252 558 246 252 558 minecraft:orange_concrete
fill 245 252 599 246 253 599 minecraft:yellow_concrete
fill 246 252 598 248 252 598 minecraft:orange_concrete
setblock 247 252 557 minecraft:yellow_concrete
fill 247 252 599 248 257 599 minecraft:red_concrete
fill 248 252 557 249 257 557 minecraft:red_concrete
fill 248 252 558 250 252 558 minecraft:orange_concrete
fill 250 252 557 251 253 557 minecraft:yellow_concrete
fill 250 252 598 252 252 598 minecraft:orange_concrete
fill 252 252 558 254 252 558 minecraft:orange_concrete
fill 254 252 598 256 252 598 minecraft:orange_concrete
fill 256 252 557 257 257 557 minecraft:red_concrete
fill 256 252 558 258 252 558 minecraft:orange_concrete
fill 256 252 599 256 257 599 minecraft:red_concrete
fill 257 252 562 257 253 562 minecraft:orange_concrete
fill 257 252 599 258 252 599 minecraft:yellow_concrete
fill 258 252 557 259 252 557 minecraft:yellow_concrete
fill 258 252 598 260 252 598 minecraft:orange_concrete
fill 259 252 599 260 257 599 minecraft:red_concrete
fill 260 252 557 260 257 557 minecraft:red_concrete
fill 260 252 558 262 252 558 minecraft:orange_concrete
fill 262 252 598 264 252 598 minecraft:orange_concrete
fill 264 252 558 266 252 558 minecraft:orange_concrete
fill 265 252 599 266 253 599 minecraft:yellow_concrete
fill 266 252 598 268 252 598 minecraft:orange_concrete
fill 267 252 599 268 257 599 minecraft:red_concrete
fill 268 252 557 269 257 557 minecraft:red_concrete
fill 268 252 558 270 252 558 minecraft:orange_concrete
fill 269 252 586 269 253 586 minecraft:orange_concrete
setblock 269 252 599 minecraft:yellow_concrete
fill 270 252 557 271 253 557 minecraft:yellow_concrete
fill 270 252 584 271 253 584 minecraft:red_concrete
fill 270 252 585 270 254 585 minecraft:orange_concrete
fill 270 252 598 272 252 598 minecraft:orange_concrete
setblock 271 252 581 minecraft:yellow_concrete
fill 271 252 583 271 254 583 minecraft:red_concrete
fill 272 252 558 274 252 558 minecraft:orange_concrete
fill 272 252 582 272 253 582 minecraft:yellow_concrete
fill 273 252 578 276 252 578 minecraft:orange_concrete
fill 273 252 581 273 254 581 minecraft:yellow_concrete
fill 274 252 598 276 252 598 minecraft:orange_concrete
fill 276 252 558 276 252 560 minecraft:orange_concrete
fill 276 252 562 276 252 564 minecraft:orange_concrete
fill 276 252 566 276 252 568 minecraft:orange_concrete
fill 276 252 570 276 252 572 minecraft:orange_concrete
fill 276 252 574 276 252 576 minecraft:orange_concrete
fill 276 252 579 276 252 580 minecraft:orange_concrete
fill 276 252 582 276 252 584 minecraft:orange_concrete
fill 276 252 586 276 252 588 minecraft:orange_concrete
fill 276 252 590 276 252 592 minecraft:orange_concrete
fill 276 252 594 276 252 596 minecraft:orange_concrete
fill 277 252 557 277 257 557 minecraft:red_concrete
setblock 277 252 559 minecraft:yellow_concrete
fill 277 252 560 277 257 561 minecraft:red_concrete
fill 277 252 562 277 253 562 minecraft:yellow_concrete
fill 277 252 568 277 257 569 minecraft:red_concrete
fill 277 252 570 277 252 571 minecraft:yellow_concrete
fill 277 252 580 277 257 581 minecraft:red_concrete
fill 277 252 582 277 253 583 minecraft:yellow_concrete
fill 277 252 589 277 257 589 minecraft:red_concrete
fill 277 252 590 277 252 591 minecraft:yellow_concrete
fill 277 252 592 277 257 592 minecraft:red_concrete
fill 277 252 594 277 253 594 minecraft:yellow_concrete
fill 277 252 599 277 253 599 minecraft:yellow_concrete
fill 235 253 565 235 253 566 minecraft:yellow_concrete
setblock 235 253 569 minecraft:yellow_concrete
fill 235 253 570 235 256 570 minecraft:red_concrete
fill 235 253 581 235 255 581 minecraft:red_concrete
setblock 235 253 586 minecraft:yellow_concrete
setblock 235 253 597 minecraft:yellow_concrete
fill 236 253 578 238 253 578 minecraft:orange_concrete
fill 237 253 599 238 255 599 minecraft:red_concrete
fill 239 253 582 239 254 582 minecraft:yellow_concrete
fill 240 253 584 240 256 584 minecraft:red_concrete
setblock 242 253 557 minecraft:yellow_concrete
fill 242 253 586 242 255 586 minecraft:orange_concrete
setblock 243 253 585 minecraft:orange_concrete
fill 247 253 557 247 256 557 minecraft:red_concrete
fill 253 253 599 254 253 599 minecraft:yellow_concrete
setblock 257 253 599 minecraft:yellow_concrete
fill 258 253 557 258 256 557 minecraft:red_concrete
fill 258 253 599 258 256 599 minecraft:red_concrete
setblock 259 253 557 minecraft:yellow_concrete
fill 262 253 557 263 253 557 minecraft:yellow_concrete
setblock 269 253 585 minecraft:orange_concrete
fill 269 253 599 269 256 599 minecraft:red_concrete
setblock 270 253 583 minecraft:red_concrete
fill 270 253 586 270 255 586 minecraft:orange_concrete
fill 272 253 584 272 256 584 minecraft:red_concrete
fill 273 253 582 273 254 582 minecraft:yellow_concrete
fill 274 253 578 276 253 578 minecraft:orange_concrete
setblock 274 253 599 minecraft:yellow_concrete
fill 277 253 559 277 256 559 minecraft:red_concrete
setblock 277 253 563 minecraft:yellow_concrete
fill 277 253 570 277 256 570 minecraft:red_concrete
setblock 277 253 571 minecraft:yellow_concrete
setblock 277 253 574 minecraft:yellow_concrete
fill 277 253 590 277 256 591 minecraft:red_concrete
setblock 277 253 595 minecraft:yellow_concrete
fill 235 254 557 235 259 558 minecraft:red_concrete
fill 235 254 564 235 255 564 minecraft:yellow_concrete
fill 235 254 565 235 259 566 minecraft:red_concrete
setblock 235 254 567 minecraft:yellow_concrete
fill 235 254 569 235 259 569 minecraft:red_concrete
fill 235 254 575 235 255 576 minecraft:yellow_concrete
fill 235 254 577 235 259 578 minecraft:red_concrete
setblock 235 254 583 minecraft:red_concrete
fill 235 254 584 235 255 584 minecraft:yellow_concrete
fill 235 254 586 235 259 586 minecraft:red_concrete
fill 235 254 587 235 254 588 minecraft:yellow_concrete
fill 235 254 589 235 256 590 minecraft:red_concrete
fill 235 254 595 235 255 596 minecraft:yellow_concrete
fill 235 254 597 235 259 598 minecraft:red_concrete
setblock 235 254 599 minecraft:yellow_concrete
fill 236 254 578 237 254 578 minecraft:orange_concrete
fill 236 254 599 236 257 599 minecraft:red_concrete
fill 238 254 557 239 259 557 minecraft:red_concrete
fill 238 254 581 238 255 582 minecraft:yellow_concrete
fill 240 254 557 241 254 557 minecraft:yellow_concrete
fill 240 254 585 240 256 585 minecraft:red_concrete
fill 241 254 586 241 256 586 minecraft:orange_concrete
fill 242 254 557 242 259 557 minecraft:red_concrete
fill 243 254 599 244 255 599 minecraft:yellow_concrete
fill 245 254 599 246 259 599 minecraft:red_concrete
fill 250 254 557 251 259 557 minecraft:red_concrete
fill 252 254 557 253 255 557 minecraft:yellow_concrete
fill 252 254 599 252 255 599 minecraft:yellow_concrete
fill 253 254 599 254 259 599 minecraft:red_concrete
setblock 255 254 599 minecraft:yellow_concrete
fill 257 254 599 257 259 599 minecraft:red_concrete
fill 259 254 557 259 259 557 minecraft:red_concrete
setblock 261 254 557 minecraft:yellow_concrete
fill 262 254 557 263 259 557 minecraft:red_concrete
fill 263 254 599 264 255 599 minecraft:yellow_concrete
fill 264 254 557 264 255 557 minecraft:yellow_concrete
fill 265 254 599 266 259 599 minecraft:red_concrete
fill 270 254 557 271 259 557 minecraft:red_concrete
setblock 271 254 584 minecraft:red_concrete
fill 271 254 586 271 256 586 minecraft:orange_concrete
fill 272 254 557 273 254 557 minecraft:yellow_concrete
fill 272 254 585 272 256 585 minecraft:red_concrete
fill 274 254 581 274 255 582 minecraft:yellow_concrete
fill 274 254 599 274 259 599 minecraft:red_concrete
fill 275 254 578 276 254 578 minecraft:orange_concrete
fill 275 254 599 276 254 599 minecraft:yellow_concrete
fill 277 254 562 277 259 563 minecraft:red_concrete
fill 277 254 564 277 255 565 minecraft:yellow_concrete
fill 277 254 571 277 259 571 minecraft:red_concrete
fill 277 254 572 277 254 573 minecraft:yellow_concrete
fill 277 254 574 277 259 574 minecraft:red_concrete
fill 277 254 576 277 255 576 minecraft:yellow_concrete
fill 277 254 582 277 259 583 minecraft:red_concrete
fill 277 254 584 277 255 585 minecraft:yellow_concrete
setblock 277 254 593 minecraft:yellow_concrete
fill 277 254 594 277 259 595 minecraft:red_concrete
fill 277 254 596 277 255 597 minecraft:yellow_concrete
fill 277 254 599 277 259 599 minecraft:red_concrete
setblock 235 255 563 minecraft:yellow_concrete
fill 235 255 567 235 258 567 minecraft:red_concrete
setblock 235 255 583 minecraft:yellow_concrete
setblock 235 255 587 minecraft:yellow_concrete
fill 235 255 588 235 258 588 minecraft:red_concrete
fill 235 255 599 235 257 599 minecraft:red_concrete
fill 237 255 581 237 256 582 minecraft:yellow_concrete
setblock 238 255 560 minecraft:light[level=14]
setblock 238 255 568 minecraft:light[level=14]
setblock 238 255 576 minecraft:light[level=14]
setblock 238 255 584 minecraft:light[level=14]
setblock 238 255 592 minecraft:light[level=14]
fill 239 255 584 239 256 585 minecraft:red_concrete
fill 240 255 557 240 258 557 minecraft:red_concrete
setblock 240 255 599 minecraft:yellow_concrete
setblock 241 255 557 minecraft:yellow_concrete
fill 241 255 587 241 257 587 minecraft:orange_concrete
fill 244 255 557 245 255 557 minecraft:yellow_concrete
setblock 246 255 560 minecraft:light[level=14]
setblock 246 255 568 minecraft:light[level=14]
setblock 246 255 576 minecraft:light[level=14]
setblock 246 255 584 minecraft:light[level=14]
setblock 246 255 592 minecraft:light[level=14]
setblock 251 255 599 minecraft:yellow_concrete
setblock 254 255 560 minecraft:light[level=14]
setblock 254 255 568 minecraft:light[level=14]
setblock 254 255 576 minecraft:light[level=14]
setblock 254 255 584 minecraft:light[level=14]
setblock 254 255 592 minecraft:light[level=14]
fill 255 255 599 255 258 599 minecraft:red_concrete
fill 261 255 557 261 258 557 minecraft:red_concrete
setblock 262 255 560 minecraft:light[level=14]
setblock 262 255 568 minecraft:light[level=14]
setblock 262 255 576 minecraft:light[level=14]
setblock 262 255 584 minecraft:light[level=14]
setblock 262 255 592 minecraft:light[level=14]
setblock 265 255 557 minecraft:yellow_concrete
setblock 270 255 560 minecraft:light[level=14]
setblock 270 255 568 minecraft:light[level=14]
setblock 270 255 576 minecraft:light[level=14]
setblock 270 255 584 minecraft:light[level=14]
setblock 270 255 592 minecraft:light[level=14]
fill 271 255 587 271 257 587 minecraft:orange_concrete
fill 271 255 599 272 255 599 minecraft:yellow_concrete
fill 272 255 557 272 258 557 minecraft:red_concrete
setblock 273 255 557 minecraft:yellow_concrete
fill 273 255 584 273 256 585 minecraft:red_concrete
fill 275 255 581 275 256 582 minecraft:yellow_concrete
setblock 275 255 599 minecraft:yellow_concrete
setblock 276 255 557 minecraft:yellow_concrete
fill 276 255 599 276 258 599 minecraft:red_concrete
fill 277 255 572 277 258 573 minecraft:red_concrete
setblock 277 255 577 minecraft:yellow_concrete
setblock 277 255 588 minecraft:yellow_concrete
fill 277 255 593 277 258 593 minecraft:red_concrete
fill 235 256 561 235 257 562 minecraft:yellow_concrete
fill 235 256 563 235 261 564 minecraft:red_concrete
fill 235 256 573 235 256 574 minecraft:yellow_concrete
fill 235 256 575 235 261 576 minecraft:red_concrete
fill 235 256 581 235 257 582 minecraft:yellow_concrete
fill 235 256 583 235 261 584 minecraft:red_concrete
setblock 235 256 585 minecraft:yellow_concrete
fill 235 256 587 235 258 587 minecraft:red_concrete
fill 235 256 593 235 257 594 minecraft:yellow_concrete
fill 235 256 595 235 261 596 minecraft:red_concrete
fill 236 256 582 236 257 582 minecraft:yellow_concrete
setblock 237 256 599 minecraft:red_concrete
setblock 238 256 582 minecraft:yellow_concrete
fill 238 256 585 238 258 585 minecraft:red_concrete
fill 238 256 599 238 257 599 minecraft:yellow_concrete
fill 240 256 587 240 258 587 minecraft:orange_concrete
fill 240 256 599 240 261 599 minecraft:red_concrete
fill 241 256 557 241 261 557 minecraft:red_concrete
fill 241 256 599 242 256 599 minecraft:yellow_concrete
setblock 243 256 557 minecraft:yellow_concrete
fill 243 256 599 244 258 599 minecraft:red_concrete
fill 244 256 557 245 261 557 minecraft:red_concrete
fill 246 256 557 246 257 557 minecraft:yellow_concrete
fill 249 256 599 250 257 599 minecraft:yellow_concrete
fill 251 256 599 252 261 599 minecraft:red_concrete
fill 252 256 557 253 261 557 minecraft:red_concrete
fill 254 256 557 255 256 557 minecraft:yellow_concrete
fill 261 256 599 262 256 599 minecraft:yellow_concrete
fill 263 256 599 264 261 599 minecraft:red_concrete
fill 264 256 557 265 261 557 minecraft:red_concrete
fill 266 256 557 267 257 557 minecraft:yellow_concrete
fill 270 256 599 270 257 599 minecraft:yellow_concrete
fill 271 256 599 272 261 599 minecraft:red_concrete
fill 272 256 587 272 258 587 minecraft:orange_concrete
fill 273 256 557 273 261 557 minecraft:red_concrete
setblock 273 256 599 minecraft:yellow_concrete
fill 274 256 557 275 256 557 minecraft:yellow_concrete
setblock 274 256 582 minecraft:yellow_concrete
fill 274 256 585 274 258 585 minecraft:red_concrete
fill 275 256 599 275 261 599 minecraft:red_concrete
fill 276 256 557 276 261 557 minecraft:red_concrete
fill 276 256 582 276 257 582 minecraft:yellow_concrete
fill 277 256 558 277 257 558 minecraft:yellow_concrete
fill 277 256 564 277 261 565 minecraft:red_concrete
fill 277 256 566 277 257 567 minecraft:yellow_concrete
setblock 277 256 575 minecraft:yellow_concrete
fill 277 256 576 277 261 577 minecraft:red_concrete
fill 277 256 578 277 257 579 minecraft:yellow_concrete
fill 277 256 584 277 261 585 minecraft:red_concrete
fill 277 256 586 277 256 587 minecraft:yellow_concrete
fill 277 256 588 277 261 588 minecraft:red_concrete
fill 277 256 596 277 261 597 minecraft:red_concrete
fill 277 256 598 277 257 598 minecraft:yellow_concrete
setblock 235 257 570 minecraft:yellow_concrete
setblock 235 257 573 minecraft:yellow_concrete
fill 235 257 574 235 260 574 minecraft:red_concrete
fill 235 257 585 235 260 585 minecraft:red_concrete
fill 235 257 589 235 259 589 minecraft:red_concrete
setblock 235 257 590 minecraft:yellow_concrete
setblock 237 257 582 minecraft:yellow_concrete
setblock 237 257 599 minecraft:yellow_concrete
fill 238 257 586 238 258 586 minecraft:red_concrete
setblock 239 257 585 minecraft:red_concrete
fill 239 257 587 239 258 588 minecraft:orange_concrete
fill 240 257 588 240 258 588 minecraft:orange_concrete
setblock 241 257 599 minecraft:yellow_concrete
fill 242 257 599 242 260 599 minecraft:red_concrete
fill 243 257 557 243 260 557 minecraft:red_concrete
setblock 247 257 557 minecraft:yellow_concrete
fill 254 257 557 254 260 557 minecraft:red_concrete
setblock 255 257 557 minecraft:yellow_concrete
setblock 258 257 557 minecraft:yellow_concrete
setblock 258 257 599 minecraft:yellow_concrete
setblock 261 257 599 minecraft:yellow_concrete
fill 262 257 599 262 260 599 minecraft:red_concrete
setblock 269 257 599 minecraft:yellow_concrete
fill 272 257 588 273 258 588 minecraft:orange_concrete
setblock 273 257 585 minecraft:red_concrete
fill 273 257 587 273 258 587 minecraft:orange_concrete
fill 273 257 599 273 260 599 minecraft:red_concrete
fill 274 257 557 275 260 557 minecraft:red_concrete
fill 274 257 586 274 258 586 minecraft:red_concrete
setblock 275 257 582 minecraft:yellow_concrete
setblock 277 257 559 minecraft:yellow_concrete
setblock 277 257 570 minecraft:yellow_concrete
fill 277 257 575 277 260 575 minecraft:red_concrete
fill 277 257 586 277 260 586 minecraft:red_concrete
setblock 277 257 587 minecraft:yellow_concrete
fill 277 257 590 277 257 591 minecraft:yellow_concrete
fill 235 258 559 235 259 560 minecraft:yellow_concrete
fill 235 258 561 235 263 562 minecraft:red_concrete
fill 235 258 568 235 259 568 minecraft:yellow_concrete
fill 235 258 570 235 263 570 minecraft:red_concrete
fill 235 258 571 235 258 572 minecraft:yellow_concrete
fill 235 258 573 235 263 573 minecraft:red_concrete
fill 235 258 579 235 259 580 minecraft:yellow_concrete
fill 235 258 581 235 263 582 minecraft:red_concrete
fill 235 258 590 235 259 590 minecraft:red_concrete
fill 235 258 591 235 258 592 minecraft:yellow_concrete
fill 235 258 593 235 263 594 minecraft:red_concrete
fill 235 258 599 236 259 599 minecraft:yellow_concrete
fill 236 258 557 237 258 557 minecraft:yellow_concrete
fill 236 258 558 238 258 558 minecraft:orange_concrete
fill 236 258 560 236 258 562 minecraft:orange_concrete
fill 236 258 564 236 258 566 minecraft:orange_concrete
fill 236 258 568 236 258 570 minecraft:orange_concrete
fill 236 258 572 236 258 574 minecraft:orange_concrete
fill 236 258 576 236 258 578 minecraft:orange_concrete
fill 236 258 580 236 258 582 minecraft:orange_concrete
fill 236 258 584 236 258 586 minecraft:orange_concrete
fill 236 258 588 236 258 590 minecraft:orange_concrete
fill 236 258 592 236 258 594 minecraft:orange_concrete
fill 236 258 596 236 258 598 minecraft:orange_concrete
fill 237 258 585 237 259 586 minecraft:red_concrete
fill 237 258 599 238 263 599 minecraft:red_concrete
fill 238 258 598 240 258 598 minecraft:orange_concrete
setblock 239 258 599 minecraft:yellow_concrete
fill 240 258 558 242 258 558 minecraft:orange_concrete
fill 241 258 599 241 260 599 minecraft:red_concrete
fill 242 258 598 244 258 598 minecraft:orange_concrete
fill 244 258 558 246 258 558 minecraft:orange_concrete
fill 246 258 557 247 263 557 minecraft:red_concrete
fill 246 258 598 248 258 598 minecraft:orange_concrete
fill 247 258 599 248 259 599 minecraft:yellow_concrete
fill 248 258 557 249 259 557 minecraft:yellow_concrete
fill 248 258 558 250 258 558 minecraft:orange_concrete
fill 249 258 599 250 263 599 minecraft:red_concrete
fill 250 258 598 252 258 598 minecraft:orange_concrete
fill 252 258 558 254 258 558 minecraft:orange_concrete
fill 254 258 598 256 258 598 minecraft:orange_concrete
fill 255 258 557 255 263 557 minecraft:red_concrete
fill 256 258 557 257 258 557 minecraft:yellow_concrete
fill 256 258 558 258 258 558 minecraft:orange_concrete
fill 256 258 599 256 259 599 minecraft:yellow_concrete
fill 258 258 557 258 263 557 minecraft:red_concrete
fill 258 258 598 260 258 598 minecraft:orange_concrete
fill 258 258 599 258 263 599 minecraft:red_concrete
fill 259 258 599 260 258 599 minecraft:yellow_concrete
fill 260 258 557 260 259 557 minecraft:yellow_concrete
fill 260 258 558 262 258 558 minecraft:orange_concrete
fill 261 258 599 261 263 599 minecraft:red_concrete
fill 262 258 598 264 258 598 minecraft:orange_concrete
fill 264 258 558 266 258 558 minecraft:orange_concrete
fill 266 258 557 267 263 557 minecraft:red_concrete
fill 266 258 598 268 258 598 minecraft:orange_concrete
fill 267 258 599 268 259 599 minecraft:yellow_concrete
fill 268 258 557 269 259 557 minecraft:yellow_concrete
fill 268 258 558 270 258 558 minecraft:orange_concrete
fill 269 258 599 270 263 599 minecraft:red_concrete
fill 270 258 598 272 258 598 minecraft:orange_concrete
fill 272 258 558 274 258 558 minecraft:orange_concrete
fill 274 258 598 276 258 598 minecraft:orange_concrete
fill 275 258 585 275 259 586 minecraft:red_concrete
fill 276 258 558 276 258 560 minecraft:orange_concrete
fill 276 258 562 276 258 564 minecraft:orange_concrete
fill 276 258 566 276 258 568 minecraft:orange_concrete
fill 276 258 570 276 258 572 minecraft:orange_concrete
fill 276 258 574 276 258 576 minecraft:orange_concrete
fill 276 258 578 276 258 580 minecraft:orange_concrete
fill 276 258 582 276 258 584 minecraft:orange_concrete
fill 276 258 586 276 258 588 minecraft:orange_concrete
fill 276 258 590 276 258 592 minecraft:orange_concrete
fill 276 258 594 276 258 596 minecraft:orange_concrete
setblock 277 258 557 minecraft:yellow_concrete
fill 277 258 558 277 263 559 minecraft:red_concrete
fill 277 258 560 277 259 561 minecraft:yellow_concrete
fill 277 258 566 277 263 567 minecraft:red_concrete
fill 277 258 568 277 258 569 minecraft:yellow_concrete
fill 277 258 570 277 263 570 minecraft:red_concrete
fill 277 258 578 277 263 579 minecraft:red_concrete
fill 277 258 580 277 259 581 minecraft:yellow_concrete
fill 277 258 587 277 263 587 minecraft:red_concrete
setblock 277 258 589 minecraft:yellow_concrete
fill 277 258 590 277 263 591 minecraft:red_concrete
fill 277 258 592 277 259 592 minecraft:yellow_concrete
fill 277 258 598 277 263 598 minecraft:red_concrete
setblock 235 259 567 minecraft:yellow_concrete
fill 235 259 571 235 261 572 minecraft:red_concrete
fill 235 259 587 235 259 588 minecraft:yellow_concrete
setblock 235 259 591 minecraft:yellow_concrete
fill 235 259 592 235 262 592 minecraft:red_concrete
fill 236 259 557 236 262 557 minecraft:red_concrete
fill 236 259 586 236 260 586 minecraft:red_concrete
setblock 237 259 557 minecraft:yellow_concrete
fill 238 259 588 239 260 589 minecraft:orange_concrete
fill 239 259 599 239 262 599 minecraft:red_concrete
setblock 240 259 557 minecraft:yellow_concrete
fill 243 259 599 243 261 599 minecraft:red_concrete
setblock 244 259 599 minecraft:yellow_concrete
setblock 255 259 599 minecraft:yellow_concrete
fill 256 259 557 257 262 557 minecraft:red_concrete
fill 259 259 599 260 262 599 minecraft:red_concrete
setblock 261 259 557 minecraft:yellow_concrete
setblock 272 259 557 minecraft:yellow_concrete
fill 273 259 588 274 260 589 minecraft:orange_concrete
fill 276 259 586 276 260 586 minecraft:red_concrete
setblock 276 259 599 minecraft:yellow_concrete
fill 277 259 557 277 262 557 minecraft:red_concrete
fill 277 259 568 277 262 568 minecraft:red_concrete
setblock 277 259 569 minecraft:yellow_concrete
fill 277 259 572 277 259 573 minecraft:yellow_concrete
fill 277 259 589 277 262 589 minecraft:red_concrete
setblock 277 259 593 minecraft:yellow_concrete
fill 235 260 557 235 260 558 minecraft:yellow_concrete
fill 235 260 559 235 265 560 minecraft:red_concrete
fill 235 260 565 235 261 566 minecraft:yellow_concrete
fill 235 260 567 235 265 568 minecraft:red_concrete
setblock 235 260 569 minecraft:yellow_concrete
fill 235 260 577 235 261 578 minecraft:yellow_concrete
fill 235 260 579 235 265 580 minecraft:red_concrete
fill 235 260 586 235 261 586 minecraft:yellow_concrete
fill 235 260 587 235 261 588 minecraft:red_concrete
fill 235 260 589 235 260 590 minecraft:yellow_concrete
fill 235 260 591 235 265 591 minecraft:red_concrete
fill 235 260 597 235 261 598 minecraft:yellow_concrete
fill 235 260 599 236 265 599 minecraft:red_concrete
fill 237 260 557 237 265 557 minecraft:red_concrete
setblock 237 260 586 minecraft:red_concrete
fill 237 260 589 237 262 589 minecraft:orange_concrete
fill 238 260 557 239 260 557 minecraft:yellow_concrete
fill 240 260 557 240 265 557 minecraft:red_concrete
fill 242 260 557 242 261 557 minecraft:yellow_concrete
fill 244 260 599 244 265 599 minecraft:red_concrete
fill 245 260 599 246 260 599 minecraft:yellow_concrete
fill 247 260 599 248 265 599 minecraft:red_concrete
fill 248 260 557 249 265 557 minecraft:red_concrete
fill 250 260 557 251 261 557 minecraft:yellow_concrete
fill 253 260 599 254 261 599 minecraft:yellow_concrete
fill 255 260 599 256 265 599 minecraft:red_concrete
setblock 257 260 599 minecraft:yellow_concrete
setblock 259 260 557 minecraft:yellow_concrete
fill 260 260 557 261 265 557 minecraft:red_concrete
fill 262 260 557 263 261 557 minecraft:yellow_concrete
fill 265 260 599 266 261 599 minecraft:yellow_concrete
fill 267 260 599 268 265 599 minecraft:red_concrete
fill 268 260 557 269 265 557 minecraft:red_concrete
fill 270 260 557 271 260 557 minecraft:yellow_concrete
fill 272 260 557 272 265 557 minecraft:red_concrete
fill 274 260 599 274 261 599 minecraft:yellow_concrete
setblock 275 260 586 minecraft:red_concrete
fill 275 260 589 275 262 589 minecraft:orange_concrete
fill 276 260 599 276 265 599 minecraft:red_concrete
fill 277 260 560 277 265 561 minecraft:red_concrete
fill 277 260 562 277 261 563 minecraft:yellow_concrete
fill 277 260 569 277 265 569 minecraft:red_concrete
setblock 277 260 571 minecraft:yellow_concrete
fill 277 260 572 277 265 573 minecraft:red_concrete
fill 277 260 574 277 261 574 minecraft:yellow_concrete
fill 277 260 580 277 265 581 minecraft:red_concrete
fill 277 260 582 277 260 583 minecraft:yellow_concrete
fill 277 260 592 277 265 593 minecraft:red_concrete
fill 277 260 594 277 261 595 minecraft:yellow_concrete
setblock 277 260 599 minecraft:yellow_concrete
setblock 235 261 557 minecraft:yellow_concrete
fill 235 261 558 235 264 558 minecraft:red_concrete
fill 235 261 569 235 263 569 minecraft:red_concrete
setblock 235 261 574 minecraft:yellow_concrete
setblock 235 261 585 minecraft:yellow_concrete
fill 235 261 589 235 263 590 minecraft:red_concrete
fill 237 261 590 238 261 590 minecraft:orange_concrete
fill 238 261 557 239 264 557 minecraft:red_concrete
setblock 238 261 589 minecraft:orange_concrete
fill 241 261 599 242 261 599 minecraft:yellow_concrete
setblock 243 261 557 minecraft:yellow_concrete
setblock 245 261 599 minecraft:yellow_concrete
fill 246 261 599 246 264 599 minecraft:red_concrete
setblock 254 261 557 minecraft:yellow_concrete
fill 257 261 599 257 264 599 minecraft:red_concrete
fill 259 261 557 259 264 557 minecraft:red_concrete
setblock 262 261 599 minecraft:yellow_concrete
fill 268 261 573 269 262 574 minecraft:shroomlight
fill 270 261 557 270 264 557 minecraft:red_concrete
setblock 271 261 557 minecraft:yellow_concrete
setblock 273 261 599 minecraft:yellow_concrete
fill 274 261 557 275 261 557 minecraft:yellow_concrete
fill 274 261 589 274 261 590 minecraft:orange_concrete
fill 275 261 590 275 263 590 minecraft:orange_concrete
fill 277 261 571 277 264 571 minecraft:red_concrete
setblock 277 261 575 minecraft:yellow_concrete
fill 277 261 582 277 264 582 minecraft:red_concrete
setblock 277 261 583 minecraft:yellow_concrete
setblock 277 261 586 minecraft:yellow_concrete
fill 277 261 599 277 264 599 minecraft:red_concrete
fill 235 262 557 235 267 557 minecraft:red_concrete
fill 235 262 563 235 263 564 minecraft:yellow_concrete
fill 235 262 565 235 267 566 minecraft:red_concrete
setblock 235 262 571 minecraft:red_concrete
fill 235 262 572 235 263 572 minecraft:yellow_concrete
fill 235 262 574 235 267 574 minecraft:red_concrete
fill 235 262 575 235 262 576 minecraft:yellow_concrete
fill 235 262 577 235 264 578 minecraft:red_concrete
fill 235 262 583 235 263 584 minecraft:yellow_concrete
fill 235 262 585 235 267 586 minecraft:red_concrete
setblock 235 262 587 minecraft:yellow_concrete
fill 235 262 588 235 265 588 minecraft:red_concrete
fill 235 262 595 235 263 596 minecraft:yellow_concrete
fill 235 262 597 235 267 598 minecraft:red_concrete
fill 236 262 590 237 263 590 minecraft:orange_concrete
fill 240 262 599 240 263 599 minecraft:yellow_concrete
setblock 241 262 557 minecraft:yellow_concrete
fill 241 262 599 242 267 599 minecraft:red_concrete
fill 242 262 557 243 267 557 minecraft:red_concrete
setblock 243 262 599 minecraft:yellow_concrete
fill 244 262 557 245 263 557 minecraft:yellow_concrete
fill 245 262 599 245 267 599 minecraft:red_concrete
fill 250 262 557 251 267 557 minecraft:red_concrete
fill 251 262 599 252 263 599 minecraft:yellow_concrete
fill 252 262 557 253 262 557 minecraft:yellow_concrete
fill 253 262 599 254 267 599 minecraft:red_concrete
fill 254 262 557 254 267 557 minecraft:red_concrete
fill 262 262 557 263 267 557 minecraft:red_concrete
fill 262 262 599 262 267 599 minecraft:red_concrete
fill 263 262 599 264 262 599 minecraft:yellow_concrete
fill 264 262 557 265 263 557 minecraft:yellow_concrete
fill 265 262 599 266 267 599 minecraft:red_concrete
fill 271 262 557 271 267 557 minecraft:red_concrete
fill 271 262 599 272 263 599 minecraft:yellow_concrete
setblock 273 262 557 minecraft:yellow_concrete
fill 273 262 599 274 267 599 minecraft:red_concrete
fill 274 262 557 275 267 557 minecraft:red_concrete
setblock 275 262 599 minecraft:yellow_concrete
fill 276 262 557 276 263 557 minecraft:yellow_concrete
fill 276 262 590 276 264 590 minecraft:orange_concrete
fill 277 262 562 277 267 563 minecraft:red_concrete
fill 277 262 564 277 262 565 minecraft:yellow_concrete
fill 277 262 574 277 267 575 minecraft:red_concrete
fill 277 262 576 277 263 577 minecraft:yellow_concrete
fill 277 262 583 277 267 583 minecraft:red_concrete
fill 277 262 584 277 262 585 minecraft:yellow_concrete
fill 277 262 586 277 267 586 minecraft:red_concrete
fill 277 262 588 277 263 588 minecraft:yellow_concrete
fill 277 262 594 277 267 595 minecraft:red_concrete
fill 277 262 596 277 263 597 minecraft:yellow_concrete
setblock 235 263 571 minecraft:yellow_concrete
setblock 235 263 575 minecraft:yellow_concrete
fill 235 263 576 235 266 576 minecraft:red_concrete
fill 235 263 587 235 265 587 minecraft:red_concrete
setblock 235 263 592 minecraft:yellow_concrete
setblock 236 263 557 minecraft:yellow_concrete
setblock 238 263 560 minecraft:light[level=14]
setblock 238 263 568 minecraft:light[level=14]
setblock 238 263 576 minecraft:light[level=14]
setblock 238 263 584 minecraft:light[level=14]
setblock 238 263 592 minecraft:light[level=14]
setblock 239 263 599 minecraft:yellow_concrete
fill 241 263 557 241 266 557 minecraft:red_concrete
fill 243 263 599 243 266 599 minecraft:red_concrete
setblock 246 263 560 minecraft:light[level=14]
setblock 246 263 568 minecraft:light[level=14]
setblock 246 263 576 minecraft:light[level=14]
setblock 246 263 584 minecraft:light[level=14]
setblock 246 263 592 minecraft:light[level=14]
fill 252 263 557 252 266 557 minecraft:red_concrete
fill 252 263 590 252 264 591 minecraft:orange_concrete
setblock 253 263 557 minecraft:yellow_concrete
setblock 254 263 560 minecraft:light[level=14]
setblock 254 263 568 minecraft:light[level=14]
setblock 254 263 576 minecraft:light[level=14]
setblock 254 263 584 minecraft:light[level=14]
setblock 254 263 592 minecraft:light[level=14]
fill 256 263 557 257 263 557 minecraft:yellow_concrete
fill 259 263 599 260 263 599 minecraft:yellow_concrete
setblock 262 263 560 minecraft:light[level=14]
setblock 262 263 568 minecraft:light[level=14]
setblock 262 263 576 minecraft:light[level=14]
setblock 262 263 584 minecraft:light[level=14]
setblock 262 263 592 minecraft:light[level=14]
setblock 263 263 599 minecraft:yellow_concrete
fill 264 263 599 264 266 599 minecraft:red_concrete
setblock 270 263 560 minecraft:light[level=14]
setblock 270 263 568 minecraft:light[level=14]
setblock 270 263 576 minecraft:light[level=14]
setblock 270 263 584 minecraft:light[level=14]
setblock 270 263 592 minecraft:light[level=14]
fill 273 263 557 273 266 557 minecraft:red_concrete
fill 275 263 599 275 266 599 minecraft:red_concrete
setblock 277 263 557 minecraft:yellow_concrete
fill 277 263 564 277 266 564 minecraft:red_concrete
setblock 277 263 565 minecraft:yellow_concrete
setblock 277 263 568 minecraft:yellow_concrete
fill 277 263 584 277 266 585 minecraft:red_concrete
setblock 277 263 589 minecraft:yellow_concrete
fill 235 264 561 235 264 562 minecraft:yellow_concrete
fill 235 264 563 235 269 564 minecraft:red_concrete
fill 235 264 569 235 265 570 minecraft:yellow_concrete
fill 235 264 571 235 269 572 minecraft:red_concrete
setblock 235 264 573 minecraft:yellow_concrete
fill 235 264 575 235 266 575 minecraft:red_concrete
fill 235 264 581 235 265 582 minecraft:yellow_concrete
fill 235 264 583 235 269 584 minecraft:red_concrete
setblock 235 264 589 minecraft:red_concrete
fill 235 264 590 235 265 590 minecraft:yellow_concrete
fill 235 264 592 235 269 592 minecraft:red_concrete
fill 235 264 593 235 264 594 minecraft:yellow_concrete
fill 235 264 595 235 266 596 minecraft:red_concrete
fill 236 264 557 236 269 557 minecraft:red_concrete
fill 236 264 558 238 264 558 minecraft:orange_concrete
fill 236 264 560 236 264 562 minecraft:orange_concrete
fill 236 264 564 236 264 566 minecraft:orange_concrete
fill 236 264 568 236 264 570 minecraft:orange_concrete
fill 236 264 572 236 264 574 minecraft:orange_concrete
fill 236 264 576 236 264 578 minecraft:orange_concrete
fill 236 264 580 236 264 582 minecraft:orange_concrete
fill 236 264 584 236 264 586 minecraft:orange_concrete
fill 236 264 588 236 264 590 minecraft:orange_concrete
fill 236 264 592 236 264 594 minecraft:orange_concrete
fill 236 264 596 236 264 598 minecraft:orange_concrete
fill 237 264 599 238 265 599 minecraft:yellow_concrete
fill 238 264 598 240 264 598 minecraft:orange_concrete
fill 239 264 599 240 269 599 minecraft:red_concrete
fill 240 264 558 242 264 558 minecraft:orange_concrete
fill 242 264 598 244 264 598 minecraft:orange_concrete
fill 244 264 557 245 269 557 minecraft:red_concrete
fill 244 264 558 246 264 558 minecraft:orange_concrete
fill 246 264 557 247 265 557 minecraft:yellow_concrete
fill 246 264 598 248 264 598 minecraft:orange_concrete
fill 248 264 558 250 264 558 minecraft:orange_concrete
fill 249 264 599 250 264 599 minecraft:yellow_concrete
fill 250 264 598 252 264 598 minecraft:orange_concrete
fill 251 264 599 252 269 599 minecraft:red_concrete
fill 252 264 558 254 264 558 minecraft:orange_concrete
fill 253 264 557 253 269 557 minecraft:red_concrete
fill 254 264 598 256 264 598 minecraft:orange_concrete
setblock 255 264 557 minecraft:yellow_concrete
fill 256 264 557 257 269 557 minecraft:red_concrete
fill 256 264 558 258 264 558 minecraft:orange_concrete
fill 258 264 557 258 265 557 minecraft:yellow_concrete
fill 258 264 598 260 264 598 minecraft:orange_concrete
fill 258 264 599 258 265 599 minecraft:yellow_concrete
fill 259 264 599 260 269 599 minecraft:red_concrete
fill 260 264 558 262 264 558 minecraft:orange_concrete
setblock 261 264 599 minecraft:yellow_concrete
fill 262 264 598 264 264 598 minecraft:orange_concrete
fill 263 264 599 263 269 599 minecraft:red_concrete
fill 264 264 557 265 269 557 minecraft:red_concrete
fill 264 264 558 266 264 558 minecraft:orange_concrete
fill 266 264 557 267 264 557 minecraft:yellow_concrete
fill 266 264 598 268 264 598 minecraft:orange_concrete
fill 268 264 558 270 264 558 minecraft:orange_concrete
fill 269 264 599 270 265 599 minecraft:yellow_concrete
fill 270 264 598 272 264 598 minecraft:orange_concrete
fill 271 264 599 272 269 599 minecraft:red_concrete
fill 272 264 558 274 264 558 minecraft:orange_concrete
fill 274 264 598 276 264 598 minecraft:orange_concrete
fill 276 264 557 277 269 557 minecraft:red_concrete
fill 276 264 558 276 264 560 minecraft:orange_concrete
fill 276 264 562 276 264 564 minecraft:orange_concrete
fill 276 264 566 276 264 568 minecraft:orange_concrete
fill 276 264 570 276 264 572 minecraft:orange_concrete
fill 276 264 574 276 264 576 minecraft:orange_concrete
fill 276 264 578 276 264 580 minecraft:orange_concrete
fill 276 264 582 276 264 584 minecraft:orange_concrete
fill 276 264 586 276 264 588 minecraft:orange_concrete
fill 276 264 591 276 264 592 minecraft:orange_concrete
fill 276 264 594 276 264 596 minecraft:orange_concrete
fill 277 264 558 277 265 559 minecraft:yellow_concrete
fill 277 264 565 277 269 565 minecraft:red_concrete
fill 277 264 566 277 264 567 minecraft:yellow_concrete
fill 277 264 568 277 269 568 minecraft:red_concrete
fill 277 264 570 277 265 570 minecraft:yellow_concrete
fill 277 264 576 277 269 577 minecraft:red_concrete
fill 277 264 578 277 265 579 minecraft:yellow_concrete
setblock 277 264 587 minecraft:yellow_concrete
fill 277 264 588 277 269 589 minecraft:red_concrete
fill 277 264 590 277 265 591 minecraft:yellow_concrete
fill 277 264 596 277 269 597 minecraft:red_concrete
setblock 277 264 598 minecraft:yellow_concrete
setblock 235 265 558 minecraft:yellow_concrete
setblock 235 265 561 minecraft:yellow_concrete
schedule function dropper:buildpart/137_5 1t
