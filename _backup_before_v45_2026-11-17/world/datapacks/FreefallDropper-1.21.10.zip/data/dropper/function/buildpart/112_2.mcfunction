setblock 194 157 501 minecraft:pearlescent_froglight
setblock 195 157 494 minecraft:pearlescent_froglight
setblock 195 157 496 minecraft:pearlescent_froglight
setblock 195 157 498 minecraft:pearlescent_froglight
setblock 195 157 500 minecraft:pearlescent_froglight
setblock 195 157 502 minecraft:pearlescent_froglight
setblock 199 157 466 minecraft:light[level=11]
setblock 199 157 474 minecraft:light[level=11]
setblock 199 157 482 minecraft:light[level=11]
setblock 199 157 490 minecraft:light[level=11]
setblock 199 157 498 minecraft:light[level=11]
setblock 207 157 466 minecraft:light[level=11]
setblock 207 157 474 minecraft:light[level=11]
setblock 207 157 482 minecraft:light[level=11]
setblock 207 157 490 minecraft:light[level=11]
setblock 207 157 498 minecraft:light[level=11]
setblock 215 157 466 minecraft:light[level=11]
setblock 215 157 474 minecraft:light[level=11]
setblock 215 157 482 minecraft:light[level=11]
setblock 215 157 490 minecraft:light[level=11]
setblock 215 157 498 minecraft:light[level=11]
setblock 223 157 466 minecraft:light[level=11]
setblock 223 157 474 minecraft:light[level=11]
setblock 223 157 482 minecraft:light[level=11]
setblock 223 157 490 minecraft:light[level=11]
setblock 223 157 498 minecraft:light[level=11]
setblock 224 157 481 minecraft:blackstone
setblock 224 157 495 minecraft:blackstone
fill 188 158 468 188 163 468 minecraft:pearlescent_froglight
fill 188 158 476 188 163 476 minecraft:pearlescent_froglight
fill 188 158 484 188 163 484 minecraft:pearlescent_froglight
fill 188 158 492 188 163 492 minecraft:pearlescent_froglight
fill 188 158 500 188 163 500 minecraft:pearlescent_froglight
fill 189 158 494 189 225 494 minecraft:light_gray_concrete
setblock 189 158 496 minecraft:light_gray_concrete
setblock 189 158 498 minecraft:light_gray_concrete
setblock 189 158 500 minecraft:light_gray_concrete
fill 189 158 502 189 225 502 minecraft:light_gray_concrete
setblock 190 158 495 minecraft:light_gray_concrete
setblock 190 158 497 minecraft:light_gray_concrete
setblock 190 158 499 minecraft:light_gray_concrete
setblock 190 158 501 minecraft:light_gray_concrete
setblock 191 158 494 minecraft:light_gray_concrete
setblock 191 158 496 minecraft:light_gray_concrete
setblock 191 158 498 minecraft:light_gray_concrete
setblock 191 158 500 minecraft:light_gray_concrete
setblock 191 158 502 minecraft:light_gray_concrete
fill 191 158 505 191 163 505 minecraft:pearlescent_froglight
setblock 192 158 495 minecraft:light_gray_concrete
setblock 192 158 497 minecraft:light_gray_concrete
setblock 192 158 499 minecraft:light_gray_concrete
setblock 192 158 501 minecraft:light_gray_concrete
setblock 193 158 494 minecraft:light_gray_concrete
setblock 193 158 496 minecraft:light_gray_concrete
setblock 193 158 498 minecraft:light_gray_concrete
setblock 193 158 500 minecraft:light_gray_concrete
setblock 193 158 502 minecraft:light_gray_concrete
setblock 194 158 495 minecraft:light_gray_concrete
setblock 194 158 497 minecraft:light_gray_concrete
setblock 194 158 499 minecraft:light_gray_concrete
setblock 194 158 501 minecraft:light_gray_concrete
fill 195 158 463 195 163 463 minecraft:pearlescent_froglight
setblock 195 158 494 minecraft:light_gray_concrete
setblock 195 158 496 minecraft:light_gray_concrete
setblock 195 158 498 minecraft:light_gray_concrete
setblock 195 158 500 minecraft:light_gray_concrete
setblock 195 158 502 minecraft:light_gray_concrete
fill 199 158 505 199 163 505 minecraft:pearlescent_froglight
fill 203 158 463 203 163 463 minecraft:pearlescent_froglight
fill 206 158 468 207 159 469 minecraft:red_concrete
fill 207 158 505 207 163 505 minecraft:pearlescent_froglight
fill 211 158 463 211 163 463 minecraft:pearlescent_froglight
fill 215 158 505 215 163 505 minecraft:pearlescent_froglight
fill 219 158 463 219 163 463 minecraft:pearlescent_froglight
fill 223 158 505 223 163 505 minecraft:pearlescent_froglight
setblock 225 158 480 minecraft:blackstone
setblock 225 158 496 minecraft:blackstone
fill 227 158 463 227 163 463 minecraft:pearlescent_froglight
fill 230 158 468 230 163 468 minecraft:pearlescent_froglight
fill 230 158 475 230 196 475 minecraft:light_gray_terracotta
fill 230 158 476 230 163 476 minecraft:pearlescent_froglight
fill 230 158 484 230 163 484 minecraft:pearlescent_froglight
fill 230 158 492 230 163 492 minecraft:pearlescent_froglight
fill 230 158 500 230 163 500 minecraft:pearlescent_froglight
fill 230 158 501 230 195 501 minecraft:light_gray_terracotta
fill 188 164 468 188 171 468 minecraft:light_gray_terracotta
fill 188 164 476 188 171 476 minecraft:light_gray_terracotta
fill 188 164 484 188 171 484 minecraft:light_gray_terracotta
fill 188 164 492 188 171 492 minecraft:light_gray_terracotta
fill 188 164 500 188 171 500 minecraft:light_gray_terracotta
fill 191 164 505 191 171 505 minecraft:light_gray_terracotta
fill 195 164 463 195 171 463 minecraft:light_gray_terracotta
fill 198 164 468 198 183 468 minecraft:iron_block
fill 199 164 505 199 171 505 minecraft:light_gray_terracotta
fill 203 164 463 203 171 463 minecraft:light_gray_terracotta
fill 207 164 505 207 171 505 minecraft:light_gray_terracotta
fill 211 164 463 211 171 463 minecraft:light_gray_terracotta
fill 215 164 505 215 171 505 minecraft:light_gray_terracotta
fill 219 164 463 219 171 463 minecraft:light_gray_terracotta
fill 223 164 505 223 171 505 minecraft:light_gray_terracotta
fill 227 164 463 227 171 463 minecraft:light_gray_terracotta
fill 230 164 468 230 171 468 minecraft:light_gray_terracotta
fill 230 164 476 230 171 476 minecraft:light_gray_terracotta
fill 230 164 484 230 171 484 minecraft:light_gray_terracotta
fill 230 164 492 230 171 492 minecraft:light_gray_terracotta
fill 230 164 500 230 171 500 minecraft:light_gray_terracotta
setblock 191 165 466 minecraft:light[level=11]
setblock 191 165 474 minecraft:light[level=11]
setblock 191 165 482 minecraft:light[level=11]
setblock 191 165 490 minecraft:light[level=11]
setblock 191 165 498 minecraft:light[level=11]
setblock 199 165 466 minecraft:light[level=11]
setblock 199 165 474 minecraft:light[level=11]
setblock 199 165 482 minecraft:light[level=11]
setblock 199 165 490 minecraft:light[level=11]
setblock 199 165 498 minecraft:light[level=11]
setblock 207 165 466 minecraft:light[level=11]
setblock 207 165 474 minecraft:light[level=11]
setblock 207 165 482 minecraft:light[level=11]
setblock 207 165 490 minecraft:light[level=11]
setblock 207 165 498 minecraft:light[level=11]
setblock 215 165 466 minecraft:light[level=11]
setblock 215 165 474 minecraft:light[level=11]
setblock 215 165 482 minecraft:light[level=11]
setblock 215 165 490 minecraft:light[level=11]
setblock 215 165 498 minecraft:light[level=11]
setblock 223 165 466 minecraft:light[level=11]
setblock 223 165 474 minecraft:light[level=11]
setblock 223 165 482 minecraft:light[level=11]
setblock 223 165 490 minecraft:light[level=11]
setblock 223 165 498 minecraft:light[level=11]
fill 189 168 464 189 169 469 minecraft:light_gray_concrete
fill 189 168 472 190 168 477 minecraft:light_gray_concrete
fill 189 168 480 190 168 485 minecraft:light_gray_concrete
fill 189 168 488 190 168 493 minecraft:light_gray_concrete
fill 189 168 496 190 168 501 minecraft:light_gray_concrete
fill 189 168 504 194 169 504 minecraft:light_gray_concrete
fill 190 168 465 190 168 471 minecraft:light_gray_concrete
fill 190 168 478 190 168 479 minecraft:light_gray_concrete
fill 190 168 486 190 168 487 minecraft:light_gray_concrete
fill 190 168 494 190 168 495 minecraft:light_gray_concrete
fill 190 168 502 190 168 503 minecraft:light_gray_concrete
fill 191 168 465 228 168 465 minecraft:light_gray_concrete
fill 191 168 503 229 168 503 minecraft:light_gray_concrete
fill 192 168 464 197 169 464 minecraft:light_gray_concrete
fill 197 168 504 202 169 504 minecraft:light_gray_concrete
fill 200 168 464 205 169 464 minecraft:light_gray_concrete
fill 205 168 504 210 169 504 minecraft:light_gray_concrete
fill 208 168 464 213 169 464 minecraft:light_gray_concrete
fill 213 168 504 218 169 504 minecraft:light_gray_concrete
fill 216 168 464 221 169 464 minecraft:light_gray_concrete
fill 221 168 504 226 169 504 minecraft:light_gray_concrete
fill 224 168 464 229 169 464 minecraft:light_gray_concrete
fill 228 168 466 228 168 502 minecraft:light_gray_concrete
fill 229 168 467 229 169 472 minecraft:light_gray_concrete
fill 229 168 475 229 169 480 minecraft:light_gray_concrete
fill 229 168 483 229 169 488 minecraft:light_gray_concrete
fill 229 168 491 229 169 496 minecraft:light_gray_concrete
fill 229 168 499 229 169 502 minecraft:light_gray_concrete
fill 229 168 504 229 169 504 minecraft:light_gray_concrete
fill 189 169 472 189 169 477 minecraft:light_gray_concrete
fill 189 169 480 189 169 485 minecraft:light_gray_concrete
fill 189 169 488 189 169 493 minecraft:light_gray_concrete
fill 189 169 496 189 169 501 minecraft:light_gray_concrete
setblock 229 169 503 minecraft:light_gray_concrete
fill 188 172 468 188 177 468 minecraft:pearlescent_froglight
fill 188 172 476 188 177 476 minecraft:pearlescent_froglight
fill 188 172 484 188 177 484 minecraft:pearlescent_froglight
fill 188 172 492 188 177 492 minecraft:pearlescent_froglight
fill 188 172 500 188 177 500 minecraft:pearlescent_froglight
fill 191 172 505 191 177 505 minecraft:pearlescent_froglight
fill 195 172 463 195 177 463 minecraft:pearlescent_froglight
fill 199 172 505 199 177 505 minecraft:pearlescent_froglight
fill 203 172 463 203 177 463 minecraft:pearlescent_froglight
fill 207 172 505 207 177 505 minecraft:pearlescent_froglight
fill 211 172 463 211 177 463 minecraft:pearlescent_froglight
fill 215 172 505 215 177 505 minecraft:pearlescent_froglight
fill 219 172 463 219 177 463 minecraft:pearlescent_froglight
fill 223 172 505 223 177 505 minecraft:pearlescent_froglight
fill 227 172 463 227 177 463 minecraft:pearlescent_froglight
fill 230 172 468 230 177 468 minecraft:pearlescent_froglight
fill 230 172 476 230 177 476 minecraft:pearlescent_froglight
fill 230 172 484 230 177 484 minecraft:pearlescent_froglight
fill 230 172 492 230 177 492 minecraft:pearlescent_froglight
fill 230 172 500 230 177 500 minecraft:pearlescent_froglight
setblock 191 173 466 minecraft:light[level=11]
setblock 191 173 474 minecraft:light[level=11]
setblock 191 173 482 minecraft:light[level=11]
setblock 191 173 490 minecraft:light[level=11]
setblock 191 173 498 minecraft:light[level=11]
setblock 199 173 466 minecraft:light[level=11]
setblock 199 173 474 minecraft:light[level=11]
setblock 199 173 482 minecraft:light[level=11]
setblock 199 173 490 minecraft:light[level=11]
setblock 199 173 498 minecraft:light[level=11]
setblock 207 173 466 minecraft:light[level=11]
setblock 207 173 474 minecraft:light[level=11]
setblock 207 173 482 minecraft:light[level=11]
setblock 207 173 490 minecraft:light[level=11]
setblock 207 173 498 minecraft:light[level=11]
setblock 215 173 466 minecraft:light[level=11]
setblock 215 173 474 minecraft:light[level=11]
setblock 215 173 482 minecraft:light[level=11]
setblock 215 173 490 minecraft:light[level=11]
setblock 215 173 498 minecraft:light[level=11]
setblock 223 173 466 minecraft:light[level=11]
setblock 223 173 474 minecraft:light[level=11]
setblock 223 173 482 minecraft:light[level=11]
setblock 223 173 490 minecraft:light[level=11]
setblock 223 173 498 minecraft:light[level=11]
fill 208 177 492 208 178 493 minecraft:white_wool
fill 188 178 468 188 185 468 minecraft:light_gray_terracotta
fill 188 178 476 188 185 476 minecraft:light_gray_terracotta
fill 188 178 484 188 185 484 minecraft:light_gray_terracotta
fill 188 178 492 188 185 492 minecraft:light_gray_terracotta
fill 188 178 500 188 185 500 minecraft:light_gray_terracotta
fill 191 178 505 191 185 505 minecraft:light_gray_terracotta
fill 195 178 463 195 185 463 minecraft:light_gray_terracotta
fill 199 178 505 199 185 505 minecraft:light_gray_terracotta
fill 203 178 463 203 185 463 minecraft:light_gray_terracotta
fill 207 178 505 207 185 505 minecraft:light_gray_terracotta
fill 211 178 463 211 185 463 minecraft:light_gray_terracotta
fill 215 178 505 215 185 505 minecraft:light_gray_terracotta
fill 219 178 463 219 185 463 minecraft:light_gray_terracotta
fill 223 178 505 223 185 505 minecraft:light_gray_terracotta
fill 227 178 463 227 185 463 minecraft:light_gray_terracotta
fill 230 178 468 230 185 468 minecraft:light_gray_terracotta
fill 230 178 476 230 185 476 minecraft:light_gray_terracotta
fill 230 178 484 230 185 484 minecraft:light_gray_terracotta
fill 230 178 492 230 185 492 minecraft:light_gray_terracotta
fill 230 178 500 230 185 500 minecraft:light_gray_terracotta
setblock 191 181 466 minecraft:light[level=11]
setblock 191 181 474 minecraft:light[level=11]
setblock 191 181 482 minecraft:light[level=11]
setblock 191 181 490 minecraft:light[level=11]
setblock 191 181 498 minecraft:light[level=11]
setblock 199 181 466 minecraft:light[level=11]
setblock 199 181 474 minecraft:light[level=11]
setblock 199 181 482 minecraft:light[level=11]
setblock 199 181 490 minecraft:light[level=11]
setblock 199 181 498 minecraft:light[level=11]
setblock 207 181 466 minecraft:light[level=11]
setblock 207 181 474 minecraft:light[level=11]
setblock 207 181 482 minecraft:light[level=11]
setblock 207 181 490 minecraft:light[level=11]
setblock 207 181 498 minecraft:light[level=11]
setblock 215 181 466 minecraft:light[level=11]
setblock 215 181 474 minecraft:light[level=11]
setblock 215 181 482 minecraft:light[level=11]
setblock 215 181 490 minecraft:light[level=11]
setblock 215 181 498 minecraft:light[level=11]
setblock 223 181 466 minecraft:light[level=11]
setblock 223 181 474 minecraft:light[level=11]
setblock 223 181 482 minecraft:light[level=11]
setblock 223 181 490 minecraft:light[level=11]
setblock 223 181 498 minecraft:light[level=11]
fill 189 182 464 189 183 469 minecraft:light_gray_concrete
fill 189 182 472 190 182 477 minecraft:light_gray_concrete
fill 189 182 480 190 182 485 minecraft:light_gray_concrete
fill 189 182 488 190 182 493 minecraft:light_gray_concrete
fill 189 182 496 190 182 501 minecraft:light_gray_concrete
fill 189 182 504 194 183 504 minecraft:light_gray_concrete
fill 190 182 465 190 182 471 minecraft:light_gray_concrete
fill 190 182 478 190 182 479 minecraft:light_gray_concrete
fill 190 182 486 190 182 487 minecraft:light_gray_concrete
fill 190 182 494 190 182 495 minecraft:light_gray_concrete
fill 190 182 502 190 182 503 minecraft:light_gray_concrete
fill 191 182 465 228 182 465 minecraft:light_gray_concrete
fill 191 182 503 229 182 503 minecraft:light_gray_concrete
fill 192 182 464 197 183 464 minecraft:light_gray_concrete
fill 197 182 504 202 183 504 minecraft:light_gray_concrete
fill 200 182 464 205 183 464 minecraft:light_gray_concrete
fill 205 182 504 210 183 504 minecraft:light_gray_concrete
fill 208 182 464 213 183 464 minecraft:light_gray_concrete
fill 213 182 496 213 183 496 minecraft:red_concrete
fill 213 182 504 218 183 504 minecraft:light_gray_concrete
fill 216 182 464 221 183 464 minecraft:light_gray_concrete
fill 221 182 504 226 183 504 minecraft:light_gray_concrete
fill 224 182 464 229 183 464 minecraft:light_gray_concrete
fill 228 182 466 228 182 502 minecraft:light_gray_concrete
fill 229 182 467 229 183 472 minecraft:light_gray_concrete
fill 229 182 475 229 183 480 minecraft:light_gray_concrete
fill 229 182 483 229 183 488 minecraft:light_gray_concrete
fill 229 182 491 229 183 496 minecraft:light_gray_concrete
fill 229 182 499 229 183 502 minecraft:light_gray_concrete
fill 229 182 504 229 183 504 minecraft:light_gray_concrete
fill 189 183 472 189 183 477 minecraft:light_gray_concrete
fill 189 183 480 189 183 485 minecraft:light_gray_concrete
fill 189 183 488 189 183 493 minecraft:light_gray_concrete
fill 189 183 496 189 183 501 minecraft:light_gray_concrete
setblock 229 183 503 minecraft:light_gray_concrete
fill 188 186 468 188 191 468 minecraft:pearlescent_froglight
fill 188 186 476 188 191 476 minecraft:pearlescent_froglight
fill 188 186 484 188 191 484 minecraft:pearlescent_froglight
fill 188 186 492 188 191 492 minecraft:pearlescent_froglight
fill 188 186 500 188 191 500 minecraft:pearlescent_froglight
fill 191 186 505 191 191 505 minecraft:pearlescent_froglight
fill 195 186 463 195 191 463 minecraft:pearlescent_froglight
fill 199 186 505 199 191 505 minecraft:pearlescent_froglight
fill 203 186 463 203 191 463 minecraft:pearlescent_froglight
fill 207 186 505 207 191 505 minecraft:pearlescent_froglight
fill 211 186 463 211 191 463 minecraft:pearlescent_froglight
fill 215 186 505 215 191 505 minecraft:pearlescent_froglight
fill 219 186 463 219 191 463 minecraft:pearlescent_froglight
fill 223 186 505 223 191 505 minecraft:pearlescent_froglight
fill 227 186 463 227 191 463 minecraft:pearlescent_froglight
fill 230 186 468 230 191 468 minecraft:pearlescent_froglight
fill 230 186 476 230 191 476 minecraft:pearlescent_froglight
fill 230 186 484 230 191 484 minecraft:pearlescent_froglight
fill 230 186 492 230 191 492 minecraft:pearlescent_froglight
fill 230 186 500 230 191 500 minecraft:pearlescent_froglight
setblock 191 189 466 minecraft:light[level=11]
setblock 191 189 474 minecraft:light[level=11]
setblock 191 189 482 minecraft:light[level=11]
setblock 191 189 490 minecraft:light[level=11]
setblock 191 189 498 minecraft:light[level=11]
setblock 199 189 466 minecraft:light[level=11]
setblock 199 189 474 minecraft:light[level=11]
setblock 199 189 482 minecraft:light[level=11]
setblock 199 189 490 minecraft:light[level=11]
setblock 199 189 498 minecraft:light[level=11]
setblock 207 189 466 minecraft:light[level=11]
setblock 207 189 474 minecraft:light[level=11]
setblock 207 189 482 minecraft:light[level=11]
setblock 207 189 490 minecraft:light[level=11]
setblock 207 189 498 minecraft:light[level=11]
setblock 215 189 466 minecraft:light[level=11]
setblock 215 189 474 minecraft:light[level=11]
setblock 215 189 482 minecraft:light[level=11]
setblock 215 189 490 minecraft:light[level=11]
setblock 215 189 498 minecraft:light[level=11]
setblock 223 189 466 minecraft:light[level=11]
setblock 223 189 474 minecraft:light[level=11]
setblock 223 189 482 minecraft:light[level=11]
setblock 223 189 490 minecraft:light[level=11]
setblock 223 189 498 minecraft:light[level=11]
fill 188 192 468 188 195 468 minecraft:light_gray_terracotta
setblock 188 192 474 minecraft:white_terracotta
fill 188 192 475 188 195 476 minecraft:light_gray_terracotta
fill 188 192 484 188 195 484 minecraft:light_gray_terracotta
fill 188 192 492 188 192 493 minecraft:white_terracotta
fill 188 192 494 188 193 495 minecraft:light_gray_terracotta
setblock 188 192 496 minecraft:white_terracotta
setblock 188 192 499 minecraft:white_terracotta
fill 188 192 500 188 195 500 minecraft:light_gray_terracotta
fill 191 192 505 191 195 505 minecraft:light_gray_terracotta
fill 195 192 463 198 193 463 minecraft:light_gray_terracotta
setblock 195 192 505 minecraft:white_terracotta
fill 196 192 505 199 192 505 minecraft:light_gray_terracotta
setblock 199 192 463 minecraft:white_terracotta
fill 203 192 463 203 195 463 minecraft:light_gray_terracotta
setblock 205 192 463 minecraft:white_terracotta
fill 206 192 463 206 196 463 minecraft:light_gray_terracotta
fill 207 192 505 207 193 505 minecraft:white_terracotta
setblock 211 192 463 minecraft:white_terracotta
fill 215 192 505 215 193 505 minecraft:light_gray_terracotta
setblock 216 192 505 minecraft:white_terracotta
fill 219 192 463 219 195 463 minecraft:light_gray_terracotta
fill 223 192 505 223 195 505 minecraft:light_gray_terracotta
setblock 224 192 463 minecraft:white_terracotta
fill 225 192 463 228 195 463 minecraft:light_gray_terracotta
setblock 229 192 463 minecraft:white_terracotta
setblock 230 192 468 minecraft:light_gray_terracotta
fill 230 192 476 230 195 476 minecraft:light_gray_terracotta
fill 230 192 484 230 192 485 minecraft:white_terracotta
fill 230 192 486 230 193 492 minecraft:light_gray_terracotta
setblock 230 192 494 minecraft:white_terracotta
fill 230 192 500 230 195 500 minecraft:light_gray_terracotta
setblock 188 193 463 minecraft:white_terracotta
fill 188 193 464 188 195 466 minecraft:light_gray_terracotta
setblock 188 193 467 minecraft:white_terracotta
fill 188 193 470 188 193 471 minecraft:white_terracotta
setblock 188 193 473 minecraft:white_terracotta
fill 188 193 474 188 195 474 minecraft:light_gray_terracotta
fill 188 193 477 188 194 477 minecraft:white_terracotta
fill 188 193 492 188 195 493 minecraft:light_gray_terracotta
fill 188 193 496 188 195 496 minecraft:light_gray_terracotta
fill 188 193 499 188 195 499 minecraft:light_gray_terracotta
setblock 194 193 505 minecraft:white_terracotta
fill 195 193 505 197 195 505 minecraft:light_gray_terracotta
fill 198 193 505 198 194 505 minecraft:white_terracotta
fill 199 193 463 199 196 463 minecraft:light_gray_terracotta
setblock 199 193 505 minecraft:light_gray_terracotta
setblock 200 193 463 minecraft:white_terracotta
setblock 200 193 505 minecraft:white_terracotta
fill 201 193 505 202 193 505 minecraft:light_gray_terracotta
setblock 203 193 505 minecraft:white_terracotta
fill 204 193 463 204 194 463 minecraft:white_terracotta
fill 205 193 463 205 195 463 minecraft:light_gray_terracotta
fill 205 193 505 205 195 505 minecraft:light_gray_terracotta
setblock 206 193 505 minecraft:white_terracotta
fill 208 193 505 213 195 505 minecraft:light_gray_terracotta
fill 211 193 463 211 195 463 minecraft:light_gray_terracotta
fill 214 193 463 214 195 463 minecraft:light_gray_terracotta
setblock 214 193 505 minecraft:white_terracotta
fill 215 193 463 215 194 463 minecraft:white_terracotta
fill 216 193 463 218 193 463 minecraft:light_gray_terracotta
fill 216 193 505 216 196 505 minecraft:light_gray_terracotta
fill 220 193 463 221 193 463 minecraft:light_gray_terracotta
setblock 222 193 463 minecraft:white_terracotta
fill 224 193 463 224 195 463 minecraft:light_gray_terracotta
fill 228 193 505 229 195 505 minecraft:light_gray_terracotta
fill 229 193 463 229 195 463 minecraft:light_gray_terracotta
setblock 230 193 463 minecraft:white_terracotta
setblock 230 193 468 minecraft:white_terracotta
fill 230 193 469 230 193 473 minecraft:light_gray_terracotta
setblock 230 193 474 minecraft:white_terracotta
fill 230 193 479 230 193 481 minecraft:white_terracotta
fill 230 193 482 230 195 485 minecraft:light_gray_terracotta
fill 230 193 494 230 195 496 minecraft:light_gray_terracotta
setblock 230 193 497 minecraft:white_terracotta
fill 230 193 498 230 195 499 minecraft:light_gray_terracotta
setblock 230 193 505 minecraft:white_terracotta
fill 188 194 463 188 196 463 minecraft:light_gray_terracotta
fill 188 194 467 188 195 467 minecraft:light_gray_terracotta
fill 188 194 470 188 195 471 minecraft:light_gray_terracotta
fill 188 194 473 188 195 473 minecraft:light_gray_terracotta
setblock 188 194 478 minecraft:white_terracotta
fill 188 194 479 188 195 481 minecraft:light_gray_terracotta
fill 188 194 482 188 194 483 minecraft:white_terracotta
fill 188 194 485 188 195 490 minecraft:light_gray_terracotta
setblock 188 194 491 minecraft:white_terracotta
fill 188 194 494 188 195 494 minecraft:light_gray_terracotta
setblock 188 194 495 minecraft:white_terracotta
setblock 188 194 497 minecraft:white_terracotta
fill 189 194 505 189 195 505 minecraft:light_gray_terracotta
setblock 190 194 505 minecraft:white_terracotta
setblock 193 194 463 minecraft:white_terracotta
fill 194 194 505 194 195 505 minecraft:light_gray_terracotta
fill 195 194 463 197 195 463 minecraft:light_gray_terracotta
setblock 198 194 463 minecraft:white_terracotta
setblock 199 194 505 minecraft:white_terracotta
fill 200 194 463 200 195 463 minecraft:light_gray_terracotta
fill 200 194 505 200 195 505 minecraft:light_gray_terracotta
setblock 201 194 463 minecraft:white_terracotta
setblock 201 194 505 minecraft:white_terracotta
fill 202 194 463 202 195 463 minecraft:light_gray_terracotta
fill 202 194 505 203 195 505 minecraft:light_gray_terracotta
fill 206 194 505 207 195 505 minecraft:light_gray_terracotta
setblock 212 194 463 minecraft:white_terracotta
fill 214 194 505 214 195 505 minecraft:light_gray_terracotta
setblock 215 194 505 minecraft:white_terracotta
setblock 216 194 463 minecraft:white_terracotta
fill 217 194 463 218 195 463 minecraft:light_gray_terracotta
fill 220 194 463 220 195 463 minecraft:light_gray_terracotta
setblock 221 194 463 minecraft:white_terracotta
setblock 221 194 505 minecraft:white_terracotta
fill 222 194 463 222 196 463 minecraft:light_gray_terracotta
fill 226 194 475 226 195 476 minecraft:white_wool
fill 230 194 463 230 195 466 minecraft:light_gray_terracotta
setblock 230 194 467 minecraft:white_terracotta
fill 230 194 468 230 195 471 minecraft:light_gray_terracotta
setblock 230 194 472 minecraft:white_terracotta
fill 230 194 473 230 195 474 minecraft:light_gray_terracotta
fill 230 194 479 230 195 481 minecraft:light_gray_terracotta
fill 230 194 486 230 195 490 minecraft:light_gray_terracotta
setblock 230 194 491 minecraft:white_terracotta
fill 230 194 492 230 195 492 minecraft:light_gray_terracotta
fill 230 194 497 230 195 497 minecraft:light_gray_terracotta
fill 230 194 505 230 195 505 minecraft:light_gray_terracotta
fill 188 195 477 188 195 478 minecraft:light_gray_terracotta
fill 188 195 482 188 195 483 minecraft:light_gray_terracotta
setblock 188 195 491 minecraft:light_gray_terracotta
setblock 188 195 495 minecraft:light_gray_terracotta
setblock 188 195 497 minecraft:light_gray_terracotta
setblock 190 195 505 minecraft:light_gray_terracotta
setblock 193 195 463 minecraft:light_gray_terracotta
setblock 198 195 463 minecraft:light_gray_terracotta
fill 198 195 505 199 195 505 minecraft:light_gray_terracotta
setblock 201 195 463 minecraft:light_gray_terracotta
setblock 201 195 505 minecraft:light_gray_terracotta
setblock 204 195 463 minecraft:light_gray_terracotta
setblock 212 195 463 minecraft:light_gray_terracotta
fill 215 195 463 216 195 463 minecraft:light_gray_terracotta
setblock 215 195 505 minecraft:light_gray_terracotta
setblock 221 195 463 minecraft:light_gray_terracotta
setblock 221 195 505 minecraft:light_gray_terracotta
fill 230 195 467 230 196 467 minecraft:light_gray_terracotta
setblock 230 195 472 minecraft:light_gray_terracotta
setblock 230 195 491 minecraft:light_gray_terracotta
fill 188 196 464 188 307 464 minecraft:white_terracotta
setblock 188 196 465 minecraft:light_gray_terracotta
fill 188 196 466 188 196 482 minecraft:white_terracotta
fill 188 196 483 188 197 483 minecraft:light_gray_terracotta
fill 188 196 484 188 199 488 minecraft:white_terracotta
setblock 188 196 489 minecraft:light_gray_terracotta
fill 188 196 490 188 196 503 minecraft:white_terracotta
fill 188 196 505 215 196 505 minecraft:white_terracotta
fill 189 196 463 198 197 463 minecraft:white_terracotta
fill 189 196 464 189 197 469 minecraft:light_gray_concrete
fill 189 196 472 190 196 477 minecraft:light_gray_concrete
fill 189 196 480 190 196 485 minecraft:light_gray_concrete
fill 189 196 488 190 196 493 minecraft:light_gray_concrete
fill 189 196 496 190 196 501 minecraft:light_gray_concrete
fill 189 196 504 194 197 504 minecraft:light_gray_concrete
fill 190 196 465 190 196 471 minecraft:light_gray_concrete
fill 190 196 478 190 196 479 minecraft:light_gray_concrete
fill 190 196 486 190 196 487 minecraft:light_gray_concrete
fill 190 196 494 190 196 495 minecraft:light_gray_concrete
fill 190 196 502 190 196 503 minecraft:light_gray_concrete
fill 191 196 465 228 196 465 minecraft:light_gray_concrete
fill 191 196 503 229 196 503 minecraft:light_gray_concrete
fill 192 196 464 197 197 464 minecraft:light_gray_concrete
fill 197 196 504 202 197 504 minecraft:light_gray_concrete
fill 200 196 463 205 199 463 minecraft:white_terracotta
fill 200 196 464 205 197 464 minecraft:light_gray_concrete
fill 205 196 504 210 197 504 minecraft:light_gray_concrete
fill 207 196 463 209 307 463 minecraft:white_terracotta
fill 208 196 464 213 197 464 minecraft:light_gray_concrete
fill 211 196 463 221 196 463 minecraft:white_terracotta
fill 213 196 504 218 197 504 minecraft:light_gray_concrete
fill 216 196 464 221 197 464 minecraft:light_gray_concrete
fill 217 196 505 217 307 505 minecraft:white_terracotta
setblock 218 196 505 minecraft:light_gray_terracotta
fill 219 196 505 223 197 505 minecraft:white_terracotta
fill 221 196 504 226 197 504 minecraft:light_gray_concrete
fill 223 196 463 225 307 463 minecraft:white_terracotta
fill 224 196 464 229 197 464 minecraft:light_gray_concrete
setblock 224 196 505 minecraft:light_gray_terracotta
fill 225 196 505 228 196 505 minecraft:white_terracotta
setblock 226 196 463 minecraft:light_gray_terracotta
fill 227 196 463 229 199 463 minecraft:white_terracotta
fill 228 196 466 228 196 502 minecraft:light_gray_concrete
fill 229 196 467 229 197 472 minecraft:light_gray_concrete
fill 229 196 475 229 197 480 minecraft:light_gray_concrete
fill 229 196 483 229 197 488 minecraft:light_gray_concrete
fill 229 196 491 229 197 496 minecraft:light_gray_concrete
fill 229 196 499 229 197 502 minecraft:light_gray_concrete
fill 229 196 504 229 197 504 minecraft:light_gray_concrete
setblock 229 196 505 minecraft:light_gray_terracotta
setblock 230 196 463 minecraft:light_gray_terracotta
fill 230 196 464 230 196 466 minecraft:white_terracotta
fill 230 196 468 230 197 470 minecraft:white_terracotta
setblock 230 196 471 minecraft:light_gray_terracotta
fill 230 196 472 230 307 474 minecraft:white_terracotta
fill 230 196 476 230 196 498 minecraft:white_terracotta
setblock 230 196 499 minecraft:light_gray_terracotta
fill 230 196 500 230 196 505 minecraft:white_terracotta
fill 188 197 463 188 307 463 minecraft:white_terracotta
fill 188 197 465 188 199 468 minecraft:white_terracotta
setblock 188 197 469 minecraft:light_gray_terracotta
fill 188 197 470 188 197 475 minecraft:white_terracotta
setblock 188 197 476 minecraft:light_gray_terracotta
fill 188 197 477 188 307 482 minecraft:white_terracotta
fill 188 197 489 188 197 498 minecraft:white_terracotta
fill 188 197 499 188 197 500 minecraft:light_gray_terracotta
fill 188 197 501 188 197 505 minecraft:white_terracotta
fill 189 197 472 189 197 477 minecraft:light_gray_concrete
fill 189 197 480 189 197 485 minecraft:light_gray_concrete
fill 189 197 488 189 197 493 minecraft:light_gray_concrete
fill 189 197 496 189 197 501 minecraft:light_gray_concrete
fill 189 197 505 211 197 505 minecraft:white_terracotta
setblock 191 197 466 minecraft:light[level=11]
setblock 191 197 474 minecraft:light[level=11]
setblock 191 197 482 minecraft:light[level=11]
setblock 191 197 490 minecraft:light[level=11]
setblock 191 197 498 minecraft:light[level=11]
setblock 199 197 463 minecraft:white_terracotta
setblock 199 197 466 minecraft:light[level=11]
setblock 199 197 474 minecraft:light[level=11]
setblock 199 197 482 minecraft:light[level=11]
setblock 199 197 490 minecraft:light[level=11]
setblock 199 197 498 minecraft:light[level=11]
fill 206 197 463 206 307 463 minecraft:white_terracotta
setblock 207 197 466 minecraft:light[level=11]
setblock 207 197 474 minecraft:light[level=11]
setblock 207 197 482 minecraft:light[level=11]
setblock 207 197 490 minecraft:light[level=11]
setblock 207 197 498 minecraft:light[level=11]
fill 210 197 463 214 199 463 minecraft:white_terracotta
setblock 212 197 505 minecraft:light_gray_terracotta
fill 213 197 505 216 197 505 minecraft:white_terracotta
setblock 215 197 463 minecraft:light_gray_terracotta
setblock 215 197 466 minecraft:light[level=11]
setblock 215 197 474 minecraft:light[level=11]
setblock 215 197 482 minecraft:light[level=11]
setblock 215 197 490 minecraft:light[level=11]
setblock 215 197 498 minecraft:light[level=11]
fill 216 197 463 222 197 463 minecraft:white_terracotta
fill 217 197 465 221 209 465 minecraft:light_blue_wool
fill 218 197 505 218 307 505 minecraft:white_terracotta
setblock 223 197 466 minecraft:light[level=11]
setblock 223 197 474 minecraft:light[level=11]
setblock 223 197 482 minecraft:light[level=11]
setblock 223 197 490 minecraft:light[level=11]
setblock 223 197 498 minecraft:light[level=11]
fill 224 197 505 227 307 505 minecraft:white_terracotta
fill 226 197 463 226 307 463 minecraft:white_terracotta
setblock 228 197 505 minecraft:light_gray_terracotta
setblock 229 197 503 minecraft:light_gray_concrete
setblock 229 197 505 minecraft:white_terracotta
fill 230 197 463 230 307 464 minecraft:white_terracotta
setblock 230 197 465 minecraft:light_gray_terracotta
fill 230 197 466 230 307 467 minecraft:white_terracotta
fill 230 197 471 230 307 471 minecraft:white_terracotta
fill 230 197 475 230 199 480 minecraft:white_terracotta
fill 230 197 481 230 197 482 minecraft:light_gray_terracotta
fill 230 197 483 230 197 492 minecraft:white_terracotta
setblock 230 197 493 minecraft:light_gray_terracotta
fill 230 197 494 230 197 500 minecraft:white_terracotta
setblock 230 197 501 minecraft:light_gray_terracotta
fill 230 197 502 230 307 504 minecraft:white_terracotta
setblock 230 197 505 minecraft:light_gray_terracotta
fill 188 198 469 188 307 470 minecraft:white_terracotta
setblock 188 198 471 minecraft:light_gray_terracotta
fill 188 198 472 188 199 476 minecraft:white_terracotta
fill 188 198 483 188 307 483 minecraft:white_terracotta
fill 188 198 489 188 199 493 minecraft:white_terracotta
setblock 188 198 494 minecraft:light_gray_terracotta
fill 188 198 495 188 199 504 minecraft:white_terracotta
setblock 188 198 505 minecraft:light_gray_terracotta
fill 189 198 463 190 307 463 minecraft:white_terracotta
fill 189 198 505 190 307 505 minecraft:white_terracotta
setblock 191 198 463 minecraft:light_gray_terracotta
setblock 191 198 505 minecraft:light_gray_terracotta
fill 192 198 463 197 199 463 minecraft:white_terracotta
fill 192 198 505 193 307 505 minecraft:white_terracotta
setblock 194 198 505 minecraft:light_gray_terracotta
fill 195 198 505 214 199 505 minecraft:white_terracotta
fill 198 198 463 199 198 463 minecraft:light_gray_terracotta
fill 215 198 463 220 199 463 minecraft:white_terracotta
setblock 215 198 505 minecraft:light_gray_terracotta
fill 216 198 505 216 307 505 minecraft:white_terracotta
fill 219 198 505 220 307 505 minecraft:white_terracotta
setblock 221 198 463 minecraft:light_gray_terracotta
setblock 221 198 505 minecraft:light_gray_terracotta
fill 222 198 463 222 307 463 minecraft:white_terracotta
fill 222 198 505 223 199 505 minecraft:white_terracotta
fill 228 198 505 228 307 505 minecraft:white_terracotta
setblock 229 198 505 minecraft:light_gray_terracotta
fill 230 198 465 230 307 465 minecraft:white_terracotta
setblock 230 198 468 minecraft:light_gray_terracotta
fill 230 198 469 230 307 470 minecraft:white_terracotta
fill 230 198 481 230 199 488 minecraft:white_terracotta
setblock 230 198 489 minecraft:light_gray_terracotta
fill 230 198 490 230 199 495 minecraft:white_terracotta
setblock 230 198 496 minecraft:light_gray_terracotta
fill 230 198 497 230 199 501 minecraft:white_terracotta
fill 230 198 505 230 307 505 minecraft:white_terracotta
fill 188 199 471 188 307 471 minecraft:white_terracotta
fill 188 199 494 188 307 494 minecraft:white_terracotta
fill 188 199 505 188 307 505 minecraft:white_terracotta
fill 191 199 463 191 307 463 minecraft:white_terracotta
setblock 191 199 505 minecraft:white_terracotta
fill 194 199 505 194 307 505 minecraft:white_terracotta
fill 198 199 463 199 307 463 minecraft:white_terracotta
setblock 215 199 505 minecraft:white_terracotta
fill 221 199 463 221 307 463 minecraft:white_terracotta
fill 221 199 505 221 307 505 minecraft:white_terracotta
fill 229 199 505 229 307 505 minecraft:white_terracotta
setblock 230 199 468 minecraft:white_terracotta
fill 230 199 489 230 307 489 minecraft:white_terracotta
fill 230 199 496 230 307 496 minecraft:white_terracotta
fill 188 200 465 188 307 467 minecraft:white_terracotta
fill 188 200 468 188 205 468 minecraft:pearlescent_froglight
fill 188 200 472 188 307 475 minecraft:white_terracotta
fill 188 200 476 188 205 476 minecraft:pearlescent_froglight
fill 188 200 484 188 205 484 minecraft:pearlescent_froglight
fill 188 200 485 188 307 491 minecraft:white_terracotta
fill 188 200 492 188 205 492 minecraft:pearlescent_froglight
fill 188 200 493 188 307 493 minecraft:white_terracotta
fill 188 200 495 188 307 499 minecraft:white_terracotta
fill 188 200 500 188 205 500 minecraft:pearlescent_froglight
fill 188 200 501 188 307 504 minecraft:white_terracotta
fill 191 200 505 191 205 505 minecraft:pearlescent_froglight
fill 192 200 463 194 307 463 minecraft:white_terracotta
fill 195 200 463 195 205 463 minecraft:pearlescent_froglight
fill 195 200 505 198 307 505 minecraft:white_terracotta
fill 196 200 463 197 307 463 minecraft:white_terracotta
fill 199 200 505 199 205 505 minecraft:pearlescent_froglight
fill 200 200 463 202 307 463 minecraft:white_terracotta
fill 200 200 505 206 307 505 minecraft:white_terracotta
fill 203 200 463 203 205 463 minecraft:pearlescent_froglight
fill 204 200 463 205 307 463 minecraft:white_terracotta
fill 207 200 505 207 205 505 minecraft:pearlescent_froglight
fill 208 200 505 214 307 505 minecraft:white_terracotta
fill 210 200 463 210 307 463 minecraft:white_terracotta
fill 211 200 463 211 205 463 minecraft:pearlescent_froglight
fill 212 200 463 218 307 463 minecraft:white_terracotta
fill 215 200 505 215 205 505 minecraft:pearlescent_froglight
fill 219 200 463 219 205 463 minecraft:pearlescent_froglight
fill 220 200 463 220 307 463 minecraft:white_terracotta
fill 222 200 505 222 307 505 minecraft:white_terracotta
fill 223 200 505 223 205 505 minecraft:pearlescent_froglight
fill 227 200 463 227 205 463 minecraft:pearlescent_froglight
fill 228 200 463 229 307 463 minecraft:white_terracotta
fill 230 200 468 230 205 468 minecraft:pearlescent_froglight
fill 230 200 475 230 307 475 minecraft:white_terracotta
fill 230 200 476 230 205 476 minecraft:pearlescent_froglight
fill 230 200 477 230 307 483 minecraft:white_terracotta
fill 230 200 484 230 205 484 minecraft:pearlescent_froglight
fill 230 200 485 230 307 488 minecraft:white_terracotta
fill 230 200 490 230 307 491 minecraft:white_terracotta
fill 230 200 492 230 205 492 minecraft:pearlescent_froglight
fill 230 200 493 230 307 495 minecraft:white_terracotta
fill 230 200 497 230 307 499 minecraft:white_terracotta
fill 230 200 500 230 205 500 minecraft:pearlescent_froglight
fill 230 200 501 230 307 501 minecraft:white_terracotta
fill 190 203 490 190 209 490 minecraft:light_blue_wool
fill 190 204 488 190 209 489 minecraft:light_blue_wool
fill 190 204 491 190 209 492 minecraft:light_blue_wool
setblock 191 205 466 minecraft:light[level=11]
setblock 191 205 474 minecraft:light[level=11]
setblock 191 205 482 minecraft:light[level=11]
setblock 191 205 490 minecraft:light[level=11]
setblock 191 205 498 minecraft:light[level=11]
setblock 199 205 466 minecraft:light[level=11]
setblock 199 205 474 minecraft:light[level=11]
setblock 199 205 482 minecraft:light[level=11]
setblock 199 205 490 minecraft:light[level=11]
setblock 199 205 498 minecraft:light[level=11]
setblock 207 205 466 minecraft:light[level=11]
setblock 207 205 474 minecraft:light[level=11]
setblock 207 205 482 minecraft:light[level=11]
setblock 207 205 490 minecraft:light[level=11]
setblock 207 205 498 minecraft:light[level=11]
setblock 215 205 466 minecraft:light[level=11]
setblock 215 205 474 minecraft:light[level=11]
setblock 215 205 482 minecraft:light[level=11]
setblock 215 205 490 minecraft:light[level=11]
setblock 215 205 498 minecraft:light[level=11]
setblock 223 205 466 minecraft:light[level=11]
setblock 223 205 474 minecraft:light[level=11]
setblock 223 205 482 minecraft:light[level=11]
setblock 223 205 490 minecraft:light[level=11]
setblock 223 205 498 minecraft:light[level=11]
fill 188 206 468 188 213 468 minecraft:white_terracotta
fill 188 206 476 188 213 476 minecraft:white_terracotta
fill 188 206 484 188 213 484 minecraft:white_terracotta
fill 188 206 492 188 213 492 minecraft:white_terracotta
fill 188 206 500 188 213 500 minecraft:white_terracotta
fill 191 206 505 191 213 505 minecraft:white_terracotta
fill 195 206 463 195 213 463 minecraft:white_terracotta
fill 199 206 505 199 213 505 minecraft:white_terracotta
fill 203 206 463 203 213 463 minecraft:white_terracotta
fill 207 206 505 207 213 505 minecraft:white_terracotta
fill 211 206 463 211 213 463 minecraft:white_terracotta
fill 215 206 505 215 213 505 minecraft:white_terracotta
fill 219 206 463 219 213 463 minecraft:white_terracotta
fill 223 206 505 223 213 505 minecraft:white_terracotta
fill 227 206 463 227 213 463 minecraft:white_terracotta
fill 230 206 468 230 213 468 minecraft:white_terracotta
fill 230 206 476 230 213 476 minecraft:white_terracotta
fill 230 206 484 230 213 484 minecraft:white_terracotta
fill 230 206 492 230 213 492 minecraft:white_terracotta
fill 230 206 500 230 213 500 minecraft:white_terracotta
fill 189 210 464 189 211 469 minecraft:light_gray_concrete
fill 189 210 472 190 210 477 minecraft:light_gray_concrete
fill 189 210 480 190 210 485 minecraft:light_gray_concrete
fill 189 210 488 190 210 493 minecraft:light_gray_concrete
fill 189 210 496 190 210 501 minecraft:light_gray_concrete
fill 189 210 504 194 211 504 minecraft:light_gray_concrete
fill 190 210 465 190 210 471 minecraft:light_gray_concrete
fill 190 210 478 190 210 479 minecraft:light_gray_concrete
fill 190 210 486 190 210 487 minecraft:light_gray_concrete
fill 190 210 494 190 210 495 minecraft:light_gray_concrete
fill 190 210 502 190 210 503 minecraft:light_gray_concrete
fill 191 210 465 228 210 465 minecraft:light_gray_concrete
fill 191 210 503 229 210 503 minecraft:light_gray_concrete
fill 192 210 464 197 211 464 minecraft:light_gray_concrete
fill 197 210 504 202 211 504 minecraft:light_gray_concrete
fill 200 210 464 205 211 464 minecraft:light_gray_concrete
fill 205 210 504 210 211 504 minecraft:light_gray_concrete
fill 208 210 464 213 211 464 minecraft:light_gray_concrete
fill 213 210 504 218 211 504 minecraft:light_gray_concrete
fill 216 210 464 221 211 464 minecraft:light_gray_concrete
fill 221 210 504 226 211 504 minecraft:light_gray_concrete
fill 224 210 464 229 211 464 minecraft:light_gray_concrete
fill 228 210 466 228 210 502 minecraft:light_gray_concrete
fill 229 210 467 229 211 472 minecraft:light_gray_concrete
fill 229 210 475 229 211 480 minecraft:light_gray_concrete
fill 229 210 483 229 211 488 minecraft:light_gray_concrete
fill 229 210 491 229 211 496 minecraft:light_gray_concrete
fill 229 210 499 229 211 502 minecraft:light_gray_concrete
fill 229 210 504 229 211 504 minecraft:light_gray_concrete
fill 189 211 472 189 211 477 minecraft:light_gray_concrete
fill 189 211 480 189 211 485 minecraft:light_gray_concrete
fill 189 211 488 189 211 493 minecraft:light_gray_concrete
fill 189 211 496 189 211 501 minecraft:light_gray_concrete
fill 190 211 488 190 217 492 minecraft:light_blue_wool
fill 216 211 465 222 212 465 minecraft:iron_block
setblock 229 211 503 minecraft:light_gray_concrete
setblock 191 213 466 minecraft:light[level=11]
setblock 191 213 474 minecraft:light[level=11]
setblock 191 213 482 minecraft:light[level=11]
setblock 191 213 490 minecraft:light[level=11]
setblock 191 213 498 minecraft:light[level=11]
setblock 199 213 466 minecraft:light[level=11]
setblock 199 213 474 minecraft:light[level=11]
setblock 199 213 482 minecraft:light[level=11]
setblock 199 213 490 minecraft:light[level=11]
setblock 199 213 498 minecraft:light[level=11]
setblock 207 213 466 minecraft:light[level=11]
setblock 207 213 474 minecraft:light[level=11]
setblock 207 213 482 minecraft:light[level=11]
setblock 207 213 490 minecraft:light[level=11]
setblock 207 213 498 minecraft:light[level=11]
setblock 215 213 466 minecraft:light[level=11]
setblock 215 213 474 minecraft:light[level=11]
setblock 215 213 482 minecraft:light[level=11]
setblock 215 213 490 minecraft:light[level=11]
setblock 215 213 498 minecraft:light[level=11]
setblock 223 213 466 minecraft:light[level=11]
setblock 223 213 474 minecraft:light[level=11]
setblock 223 213 482 minecraft:light[level=11]
setblock 223 213 490 minecraft:light[level=11]
setblock 223 213 498 minecraft:light[level=11]
fill 188 214 468 188 219 468 minecraft:pearlescent_froglight
fill 188 214 476 188 219 476 minecraft:pearlescent_froglight
fill 188 214 484 188 219 484 minecraft:pearlescent_froglight
fill 188 214 492 188 219 492 minecraft:pearlescent_froglight
fill 188 214 500 188 219 500 minecraft:pearlescent_froglight
fill 191 214 505 191 219 505 minecraft:pearlescent_froglight
fill 195 214 463 195 219 463 minecraft:pearlescent_froglight
fill 199 214 505 199 219 505 minecraft:pearlescent_froglight
fill 203 214 463 203 219 463 minecraft:pearlescent_froglight
fill 207 214 505 207 219 505 minecraft:pearlescent_froglight
fill 211 214 463 211 219 463 minecraft:pearlescent_froglight
fill 215 214 505 215 219 505 minecraft:pearlescent_froglight
fill 219 214 463 219 219 463 minecraft:pearlescent_froglight
fill 223 214 505 223 219 505 minecraft:pearlescent_froglight
fill 227 214 463 227 219 463 minecraft:pearlescent_froglight
fill 230 214 468 230 219 468 minecraft:pearlescent_froglight
fill 230 214 476 230 219 476 minecraft:pearlescent_froglight
fill 230 214 484 230 219 484 minecraft:pearlescent_froglight
fill 230 214 492 230 219 492 minecraft:pearlescent_froglight
fill 230 214 500 230 219 500 minecraft:pearlescent_froglight
fill 190 218 487 190 219 493 minecraft:iron_block
fill 188 220 468 188 241 468 minecraft:white_terracotta
fill 188 220 476 188 241 476 minecraft:white_terracotta
fill 188 220 484 188 241 484 minecraft:white_terracotta
fill 188 220 492 188 241 492 minecraft:white_terracotta
fill 188 220 500 188 241 500 minecraft:white_terracotta
fill 191 220 505 191 241 505 minecraft:white_terracotta
fill 195 220 463 195 241 463 minecraft:white_terracotta
fill 199 220 505 199 241 505 minecraft:white_terracotta
fill 203 220 463 203 241 463 minecraft:white_terracotta
fill 207 220 505 207 241 505 minecraft:white_terracotta
fill 211 220 463 211 241 463 minecraft:white_terracotta
fill 215 220 505 215 241 505 minecraft:white_terracotta
fill 219 220 463 219 241 463 minecraft:white_terracotta
fill 223 220 505 223 241 505 minecraft:white_terracotta
fill 227 220 463 227 241 463 minecraft:white_terracotta
fill 230 220 468 230 241 468 minecraft:white_terracotta
fill 230 220 476 230 241 476 minecraft:white_terracotta
fill 230 220 484 230 241 484 minecraft:white_terracotta
fill 230 220 492 230 241 492 minecraft:white_terracotta
fill 230 220 500 230 241 500 minecraft:white_terracotta
setblock 191 221 466 minecraft:light[level=11]
setblock 191 221 474 minecraft:light[level=11]
setblock 191 221 482 minecraft:light[level=11]
setblock 191 221 490 minecraft:light[level=11]
setblock 191 221 498 minecraft:light[level=11]
setblock 199 221 466 minecraft:light[level=11]
setblock 199 221 474 minecraft:light[level=11]
setblock 199 221 482 minecraft:light[level=11]
setblock 199 221 490 minecraft:light[level=11]
setblock 199 221 498 minecraft:light[level=11]
setblock 207 221 466 minecraft:light[level=11]
setblock 207 221 474 minecraft:light[level=11]
setblock 207 221 482 minecraft:light[level=11]
setblock 207 221 490 minecraft:light[level=11]
setblock 207 221 498 minecraft:light[level=11]
setblock 215 221 466 minecraft:light[level=11]
setblock 215 221 474 minecraft:light[level=11]
setblock 215 221 482 minecraft:light[level=11]
setblock 215 221 490 minecraft:light[level=11]
setblock 215 221 498 minecraft:light[level=11]
setblock 223 221 466 minecraft:light[level=11]
setblock 223 221 474 minecraft:light[level=11]
setblock 223 221 482 minecraft:light[level=11]
setblock 223 221 490 minecraft:light[level=11]
setblock 223 221 498 minecraft:light[level=11]
fill 189 224 464 189 225 469 minecraft:light_gray_concrete
fill 189 224 472 190 224 477 minecraft:light_gray_concrete
fill 189 224 480 190 224 485 minecraft:light_gray_concrete
fill 189 224 488 190 224 493 minecraft:light_gray_concrete
fill 189 224 496 190 224 501 minecraft:light_gray_concrete
fill 189 224 504 194 225 504 minecraft:light_gray_concrete
fill 190 224 465 190 224 471 minecraft:light_gray_concrete
fill 190 224 478 190 224 479 minecraft:light_gray_concrete
fill 190 224 486 190 224 487 minecraft:light_gray_concrete
fill 190 224 494 190 224 495 minecraft:light_gray_concrete
fill 190 224 502 190 224 503 minecraft:light_gray_concrete
fill 191 224 465 228 224 465 minecraft:light_gray_concrete
fill 191 224 503 229 224 503 minecraft:light_gray_concrete
fill 192 224 464 197 225 464 minecraft:light_gray_concrete
fill 197 224 504 202 225 504 minecraft:light_gray_concrete
fill 200 224 464 205 225 464 minecraft:light_gray_concrete
fill 202 224 488 203 225 489 minecraft:red_concrete
fill 205 224 504 210 225 504 minecraft:light_gray_concrete
fill 208 224 464 213 225 464 minecraft:light_gray_concrete
fill 213 224 504 218 225 504 minecraft:light_gray_concrete
fill 216 224 464 221 225 464 minecraft:light_gray_concrete
fill 221 224 504 226 225 504 minecraft:light_gray_concrete
fill 224 224 464 229 225 464 minecraft:light_gray_concrete
fill 228 224 466 228 224 502 minecraft:light_gray_concrete
fill 229 224 467 229 225 472 minecraft:light_gray_concrete
fill 229 224 475 229 225 480 minecraft:light_gray_concrete
fill 229 224 483 229 225 488 minecraft:light_gray_concrete
fill 229 224 491 229 225 496 minecraft:light_gray_concrete
fill 229 224 499 229 225 502 minecraft:light_gray_concrete
fill 229 224 504 229 225 504 minecraft:light_gray_concrete
fill 189 225 472 189 225 477 minecraft:light_gray_concrete
fill 189 225 480 189 225 485 minecraft:light_gray_concrete
fill 189 225 488 189 225 493 minecraft:light_gray_concrete
fill 189 225 496 189 225 501 minecraft:light_gray_concrete
setblock 229 225 503 minecraft:light_gray_concrete
setblock 191 229 466 minecraft:light[level=11]
setblock 191 229 474 minecraft:light[level=11]
setblock 191 229 482 minecraft:light[level=11]
setblock 191 229 490 minecraft:light[level=11]
setblock 191 229 498 minecraft:light[level=11]
setblock 199 229 466 minecraft:light[level=11]
setblock 199 229 474 minecraft:light[level=11]
setblock 199 229 482 minecraft:light[level=11]
setblock 199 229 490 minecraft:light[level=11]
setblock 199 229 498 minecraft:light[level=11]
setblock 207 229 466 minecraft:light[level=11]
setblock 207 229 474 minecraft:light[level=11]
setblock 207 229 482 minecraft:light[level=11]
setblock 207 229 490 minecraft:light[level=11]
setblock 207 229 498 minecraft:light[level=11]
setblock 215 229 466 minecraft:light[level=11]
setblock 215 229 474 minecraft:light[level=11]
setblock 215 229 482 minecraft:light[level=11]
setblock 215 229 490 minecraft:light[level=11]
setblock 215 229 498 minecraft:light[level=11]
setblock 223 229 466 minecraft:light[level=11]
setblock 223 229 474 minecraft:light[level=11]
setblock 223 229 482 minecraft:light[level=11]
setblock 223 229 490 minecraft:light[level=11]
setblock 223 229 498 minecraft:light[level=11]
fill 189 231 464 189 232 464 minecraft:light_gray_concrete
fill 189 231 465 189 232 466 minecraft:white_concrete
fill 189 231 467 189 232 468 minecraft:light_gray_concrete
fill 189 231 469 189 232 470 minecraft:white_concrete
fill 189 231 471 189 232 472 minecraft:light_gray_concrete
fill 189 231 473 189 232 474 minecraft:white_concrete
fill 189 231 475 189 232 476 minecraft:light_gray_concrete
fill 189 231 477 189 232 478 minecraft:white_concrete
fill 189 231 479 189 232 480 minecraft:light_gray_concrete
fill 189 231 481 189 232 482 minecraft:white_concrete
fill 189 231 483 189 232 484 minecraft:light_gray_concrete
fill 189 231 485 189 232 486 minecraft:white_concrete
fill 189 231 487 189 232 488 minecraft:light_gray_concrete
fill 189 231 489 189 232 490 minecraft:white_concrete
fill 189 231 491 189 232 492 minecraft:light_gray_concrete
fill 189 231 493 189 232 494 minecraft:white_concrete
fill 189 231 495 189 232 496 minecraft:light_gray_concrete
fill 189 231 497 189 232 498 minecraft:white_concrete
fill 189 231 499 189 232 500 minecraft:light_gray_concrete
fill 189 231 501 189 232 502 minecraft:white_concrete
fill 189 231 503 189 232 504 minecraft:light_gray_concrete
fill 190 231 464 191 232 464 minecraft:white_concrete
fill 190 231 465 191 232 466 minecraft:light_gray_concrete
fill 190 231 467 191 232 468 minecraft:white_concrete
fill 190 231 469 191 232 470 minecraft:light_gray_concrete
fill 190 231 471 191 232 472 minecraft:white_concrete
fill 190 231 473 191 232 474 minecraft:light_gray_concrete
fill 190 231 475 191 232 476 minecraft:white_concrete
fill 190 231 477 191 232 478 minecraft:light_gray_concrete
fill 190 231 479 191 232 480 minecraft:white_concrete
fill 190 231 481 191 232 482 minecraft:light_gray_concrete
fill 190 231 483 191 232 484 minecraft:white_concrete
fill 190 231 485 191 232 486 minecraft:light_gray_concrete
fill 190 231 487 191 232 488 minecraft:white_concrete
fill 190 231 489 191 232 490 minecraft:light_gray_concrete
fill 190 231 491 191 232 492 minecraft:white_concrete
fill 190 231 493 191 232 494 minecraft:light_gray_concrete
fill 190 231 495 191 232 496 minecraft:white_concrete
fill 190 231 497 191 232 498 minecraft:light_gray_concrete
fill 190 231 499 191 232 500 minecraft:white_concrete
fill 190 231 501 191 232 502 minecraft:light_gray_concrete
fill 190 231 503 191 232 504 minecraft:white_concrete
fill 192 231 464 193 232 464 minecraft:light_gray_concrete
fill 192 231 465 193 232 466 minecraft:white_concrete
fill 192 231 467 193 232 468 minecraft:light_gray_concrete
fill 192 231 469 193 232 470 minecraft:white_concrete
fill 192 231 471 193 232 472 minecraft:light_gray_concrete
fill 192 231 473 193 232 474 minecraft:white_concrete
fill 192 231 475 193 232 476 minecraft:light_gray_concrete
fill 192 231 477 193 232 478 minecraft:white_concrete
fill 192 231 479 193 232 480 minecraft:light_gray_concrete
fill 192 231 481 193 232 482 minecraft:white_concrete
fill 192 231 483 193 232 484 minecraft:light_gray_concrete
fill 192 231 485 193 232 486 minecraft:white_concrete
fill 192 231 487 193 232 488 minecraft:light_gray_concrete
fill 192 231 489 193 232 490 minecraft:white_concrete
fill 192 231 491 193 232 492 minecraft:light_gray_concrete
fill 192 231 493 193 232 494 minecraft:white_concrete
fill 192 231 495 193 232 496 minecraft:light_gray_concrete
fill 192 231 497 193 232 498 minecraft:white_concrete
fill 192 231 499 193 232 500 minecraft:light_gray_concrete
fill 192 231 501 193 232 502 minecraft:white_concrete
fill 192 231 503 193 232 504 minecraft:light_gray_concrete
fill 194 231 464 195 232 464 minecraft:white_concrete
fill 194 231 465 195 232 466 minecraft:light_gray_concrete
fill 194 231 467 195 232 468 minecraft:white_concrete
fill 194 231 469 195 232 470 minecraft:light_gray_concrete
fill 194 231 471 195 232 472 minecraft:white_concrete
fill 194 231 473 195 232 474 minecraft:light_gray_concrete
fill 194 231 475 195 232 476 minecraft:white_concrete
fill 194 231 477 195 232 478 minecraft:light_gray_concrete
fill 194 231 479 195 232 480 minecraft:white_concrete
fill 194 231 481 195 232 482 minecraft:light_gray_concrete
fill 194 231 483 195 232 484 minecraft:white_concrete
fill 194 231 485 195 232 486 minecraft:light_gray_concrete
fill 194 231 487 195 232 488 minecraft:white_concrete
fill 194 231 489 195 232 490 minecraft:light_gray_concrete
fill 194 231 491 195 232 492 minecraft:white_concrete
fill 194 231 493 195 232 494 minecraft:light_gray_concrete
fill 194 231 495 195 232 496 minecraft:white_concrete
fill 194 231 497 195 232 498 minecraft:light_gray_concrete
fill 194 231 499 195 232 500 minecraft:white_concrete
fill 194 231 501 195 232 502 minecraft:light_gray_concrete
fill 194 231 503 195 232 504 minecraft:white_concrete
fill 196 231 464 197 232 464 minecraft:light_gray_concrete
fill 196 231 465 197 232 466 minecraft:white_concrete
fill 196 231 467 197 232 468 minecraft:light_gray_concrete
fill 196 231 469 197 232 470 minecraft:white_concrete
fill 196 231 471 197 232 472 minecraft:light_gray_concrete
fill 196 231 473 197 232 474 minecraft:white_concrete
fill 196 231 475 197 232 476 minecraft:light_gray_concrete
fill 196 231 477 197 232 478 minecraft:white_concrete
fill 196 231 479 197 232 480 minecraft:light_gray_concrete
fill 196 231 481 197 232 482 minecraft:white_concrete
fill 196 231 483 197 232 484 minecraft:light_gray_concrete
fill 196 231 485 197 232 486 minecraft:white_concrete
fill 196 231 487 197 232 488 minecraft:light_gray_concrete
fill 196 231 489 197 232 490 minecraft:white_concrete
fill 196 231 491 197 232 492 minecraft:light_gray_concrete
fill 196 231 493 197 232 494 minecraft:white_concrete
fill 196 231 495 197 232 496 minecraft:light_gray_concrete
fill 196 231 497 197 232 498 minecraft:white_concrete
fill 196 231 499 197 232 500 minecraft:light_gray_concrete
fill 196 231 501 197 232 502 minecraft:white_concrete
fill 196 231 503 197 232 504 minecraft:light_gray_concrete
fill 198 231 464 199 232 464 minecraft:white_concrete
fill 198 231 465 199 232 466 minecraft:light_gray_concrete
fill 198 231 467 199 232 468 minecraft:white_concrete
fill 198 231 469 199 232 470 minecraft:light_gray_concrete
fill 198 231 471 199 232 472 minecraft:white_concrete
fill 198 231 473 199 232 474 minecraft:light_gray_concrete
fill 198 231 475 199 232 476 minecraft:white_concrete
fill 198 231 477 199 232 478 minecraft:light_gray_concrete
fill 198 231 479 199 232 480 minecraft:white_concrete
fill 198 231 481 199 232 482 minecraft:light_gray_concrete
fill 198 231 483 199 232 484 minecraft:white_concrete
fill 198 231 485 199 232 486 minecraft:light_gray_concrete
fill 198 231 487 199 232 488 minecraft:white_concrete
fill 198 231 489 199 232 490 minecraft:light_gray_concrete
fill 198 231 491 199 232 492 minecraft:white_concrete
fill 198 231 493 199 232 494 minecraft:light_gray_concrete
fill 198 231 495 199 232 496 minecraft:white_concrete
fill 198 231 497 199 232 498 minecraft:light_gray_concrete
fill 198 231 499 199 232 500 minecraft:white_concrete
fill 198 231 501 199 232 502 minecraft:light_gray_concrete
fill 198 231 503 199 232 504 minecraft:white_concrete
fill 200 231 464 201 232 464 minecraft:light_gray_concrete
fill 200 231 465 201 232 466 minecraft:white_concrete
fill 200 231 467 201 232 468 minecraft:light_gray_concrete
fill 200 231 469 201 232 470 minecraft:white_concrete
fill 200 231 471 201 232 472 minecraft:light_gray_concrete
fill 200 231 473 201 232 474 minecraft:white_concrete
fill 200 231 475 201 232 476 minecraft:light_gray_concrete
fill 200 231 477 201 232 478 minecraft:white_concrete
fill 200 231 479 201 232 480 minecraft:light_gray_concrete
fill 200 231 481 201 232 482 minecraft:white_concrete
fill 200 231 483 201 232 484 minecraft:light_gray_concrete
fill 200 231 485 201 232 486 minecraft:white_concrete
fill 200 231 487 201 232 488 minecraft:light_gray_concrete
fill 200 231 489 201 232 490 minecraft:white_concrete
fill 200 231 491 201 232 492 minecraft:light_gray_concrete
fill 200 231 493 201 232 494 minecraft:white_concrete
fill 200 231 495 201 232 496 minecraft:light_gray_concrete
fill 200 231 497 201 232 498 minecraft:white_concrete
fill 200 231 499 201 232 500 minecraft:light_gray_concrete
fill 200 231 501 201 232 502 minecraft:white_concrete
fill 200 231 503 201 232 504 minecraft:light_gray_concrete
fill 202 231 464 203 232 464 minecraft:white_concrete
fill 202 231 465 203 232 466 minecraft:light_gray_concrete
fill 202 231 467 203 232 468 minecraft:white_concrete
fill 202 231 469 203 232 470 minecraft:light_gray_concrete
fill 202 231 471 203 232 472 minecraft:white_concrete
fill 202 231 473 203 232 474 minecraft:light_gray_concrete
fill 202 231 475 203 232 476 minecraft:white_concrete
fill 202 231 477 203 232 478 minecraft:light_gray_concrete
fill 202 231 479 203 232 480 minecraft:white_concrete
fill 202 231 481 203 232 482 minecraft:light_gray_concrete
fill 202 231 483 203 232 484 minecraft:white_concrete
fill 202 231 485 203 232 486 minecraft:light_gray_concrete
fill 202 231 487 203 232 488 minecraft:white_concrete
fill 202 231 489 203 232 490 minecraft:light_gray_concrete
fill 202 231 491 203 232 492 minecraft:white_concrete
fill 202 231 493 203 232 494 minecraft:light_gray_concrete
fill 202 231 495 203 232 496 minecraft:white_concrete
fill 202 231 497 203 232 498 minecraft:light_gray_concrete
fill 202 231 499 203 232 500 minecraft:white_concrete
fill 202 231 501 203 232 502 minecraft:light_gray_concrete
fill 202 231 503 203 232 504 minecraft:white_concrete
fill 204 231 464 205 232 464 minecraft:light_gray_concrete
fill 204 231 465 205 232 466 minecraft:white_concrete
fill 204 231 467 205 232 468 minecraft:light_gray_concrete
fill 204 231 469 205 232 470 minecraft:white_concrete
fill 204 231 471 205 232 472 minecraft:light_gray_concrete
fill 204 231 473 205 232 474 minecraft:white_concrete
fill 204 231 475 205 232 476 minecraft:light_gray_concrete
fill 204 231 477 205 232 478 minecraft:white_concrete
fill 204 231 479 205 232 480 minecraft:light_gray_concrete
fill 204 231 481 205 232 482 minecraft:white_concrete
fill 204 231 483 205 232 484 minecraft:light_gray_concrete
fill 204 231 485 205 232 486 minecraft:white_concrete
fill 204 231 487 205 232 488 minecraft:light_gray_concrete
fill 204 231 489 205 232 490 minecraft:white_concrete
fill 204 231 491 205 232 492 minecraft:light_gray_concrete
fill 204 231 493 205 232 494 minecraft:white_concrete
fill 204 231 495 205 232 496 minecraft:light_gray_concrete
fill 204 231 497 205 232 498 minecraft:white_concrete
fill 204 231 499 205 232 500 minecraft:light_gray_concrete
fill 204 231 501 205 232 502 minecraft:white_concrete
fill 204 231 503 205 232 504 minecraft:light_gray_concrete
fill 206 231 464 207 232 464 minecraft:white_concrete
fill 206 231 465 207 232 466 minecraft:light_gray_concrete
fill 206 231 467 207 232 468 minecraft:white_concrete
fill 206 231 469 207 232 470 minecraft:light_gray_concrete
fill 206 231 471 207 232 472 minecraft:white_concrete
fill 206 231 473 207 232 474 minecraft:light_gray_concrete
fill 206 231 475 207 232 476 minecraft:white_concrete
fill 206 231 477 207 232 478 minecraft:light_gray_concrete
fill 206 231 479 207 232 480 minecraft:white_concrete
fill 206 231 481 207 232 482 minecraft:light_gray_concrete
fill 206 231 483 207 232 484 minecraft:white_concrete
fill 206 231 485 207 232 486 minecraft:light_gray_concrete
fill 206 231 487 207 232 488 minecraft:white_concrete
fill 206 231 489 207 232 490 minecraft:light_gray_concrete
fill 206 231 491 207 232 492 minecraft:white_concrete
fill 206 231 493 207 232 494 minecraft:light_gray_concrete
fill 206 231 495 207 232 496 minecraft:white_concrete
fill 206 231 497 207 232 498 minecraft:light_gray_concrete
fill 206 231 499 207 232 500 minecraft:white_concrete
fill 206 231 501 207 232 502 minecraft:light_gray_concrete
fill 206 231 503 207 232 504 minecraft:white_concrete
fill 208 231 464 209 232 464 minecraft:light_gray_concrete
fill 208 231 465 209 232 466 minecraft:white_concrete
fill 208 231 467 209 232 468 minecraft:light_gray_concrete
fill 208 231 469 209 232 470 minecraft:white_concrete
fill 208 231 471 209 232 472 minecraft:light_gray_concrete
fill 208 231 473 209 232 474 minecraft:white_concrete
fill 208 231 475 209 232 476 minecraft:light_gray_concrete
fill 208 231 477 209 232 478 minecraft:white_concrete
fill 208 231 479 209 232 480 minecraft:light_gray_concrete
fill 208 231 481 209 232 482 minecraft:white_concrete
fill 208 231 483 209 232 484 minecraft:light_gray_concrete
fill 208 231 485 209 231 486 minecraft:white_concrete
fill 208 231 487 209 231 488 minecraft:light_gray_concrete
fill 208 231 489 209 232 490 minecraft:white_concrete
fill 208 231 491 209 232 492 minecraft:light_gray_concrete
fill 208 231 493 209 232 494 minecraft:white_concrete
fill 208 231 495 209 232 496 minecraft:light_gray_concrete
fill 208 231 497 209 232 498 minecraft:white_concrete
fill 208 231 499 209 232 500 minecraft:light_gray_concrete
fill 208 231 501 209 232 502 minecraft:white_concrete
fill 208 231 503 209 232 504 minecraft:light_gray_concrete
fill 210 231 464 211 232 464 minecraft:white_concrete
fill 210 231 465 211 232 466 minecraft:light_gray_concrete
fill 210 231 467 211 232 468 minecraft:white_concrete
fill 210 231 469 211 232 470 minecraft:light_gray_concrete
fill 210 231 471 211 232 472 minecraft:white_concrete
fill 210 231 473 211 232 474 minecraft:light_gray_concrete
fill 210 231 475 211 232 476 minecraft:white_concrete
fill 210 231 477 211 232 478 minecraft:light_gray_concrete
fill 210 231 479 211 232 480 minecraft:white_concrete
fill 210 231 481 211 232 482 minecraft:light_gray_concrete
fill 210 231 483 211 231 484 minecraft:white_concrete
fill 210 231 485 210 231 486 minecraft:light_gray_concrete
setblock 210 231 488 minecraft:white_concrete
fill 210 231 489 211 231 490 minecraft:light_gray_concrete
fill 210 231 491 211 232 492 minecraft:white_concrete
fill 210 231 493 211 232 494 minecraft:light_gray_concrete
fill 210 231 495 211 232 496 minecraft:white_concrete
fill 210 231 497 211 232 498 minecraft:light_gray_concrete
fill 210 231 499 211 232 500 minecraft:white_concrete
fill 210 231 501 211 232 502 minecraft:light_gray_concrete
fill 210 231 503 211 232 504 minecraft:white_concrete
setblock 211 231 485 minecraft:light_gray_concrete
fill 212 231 464 213 232 464 minecraft:light_gray_concrete
fill 212 231 465 213 232 466 minecraft:white_concrete
fill 212 231 467 213 232 468 minecraft:light_gray_concrete
fill 212 231 469 213 232 470 minecraft:white_concrete
fill 212 231 471 213 232 472 minecraft:light_gray_concrete
fill 212 231 473 213 232 474 minecraft:white_concrete
fill 212 231 475 213 232 476 minecraft:light_gray_concrete
fill 212 231 477 213 232 478 minecraft:white_concrete
fill 212 231 479 213 232 480 minecraft:light_gray_concrete
fill 212 231 481 213 232 482 minecraft:white_concrete
fill 212 231 483 213 231 484 minecraft:light_gray_concrete
fill 212 231 490 213 231 490 minecraft:white_concrete
fill 212 231 491 213 232 492 minecraft:light_gray_concrete
fill 212 231 493 213 232 494 minecraft:white_concrete
fill 212 231 495 213 232 496 minecraft:light_gray_concrete
fill 212 231 497 213 232 498 minecraft:white_concrete
fill 212 231 499 213 232 500 minecraft:light_gray_concrete
fill 212 231 501 213 232 502 minecraft:white_concrete
fill 212 231 503 213 232 504 minecraft:light_gray_concrete
setblock 213 231 485 minecraft:white_concrete
setblock 213 231 489 minecraft:white_concrete
fill 214 231 464 215 232 464 minecraft:white_concrete
fill 214 231 465 215 232 466 minecraft:light_gray_concrete
fill 214 231 467 215 232 468 minecraft:white_concrete
fill 214 231 469 215 232 470 minecraft:light_gray_concrete
fill 214 231 471 215 232 472 minecraft:white_concrete
fill 214 231 473 215 232 474 minecraft:light_gray_concrete
fill 214 231 475 215 232 476 minecraft:white_concrete
fill 214 231 477 215 232 478 minecraft:light_gray_concrete
fill 214 231 479 215 232 480 minecraft:white_concrete
fill 214 231 481 215 232 482 minecraft:light_gray_concrete
fill 214 231 483 215 232 484 minecraft:white_concrete
fill 214 231 485 215 231 486 minecraft:light_gray_concrete
fill 214 231 488 215 231 488 minecraft:white_concrete
fill 214 231 489 215 231 490 minecraft:light_gray_concrete
fill 214 231 491 215 232 492 minecraft:white_concrete
fill 214 231 493 215 232 494 minecraft:light_gray_concrete
fill 214 231 495 215 232 496 minecraft:white_concrete
fill 214 231 497 215 232 498 minecraft:light_gray_concrete
fill 214 231 499 215 232 500 minecraft:white_concrete
fill 214 231 501 215 232 502 minecraft:light_gray_concrete
fill 214 231 503 215 232 504 minecraft:white_concrete
setblock 215 231 487 minecraft:white_concrete
fill 216 231 464 217 232 464 minecraft:light_gray_concrete
fill 216 231 465 217 232 466 minecraft:white_concrete
fill 216 231 467 217 232 468 minecraft:light_gray_concrete
fill 216 231 469 217 232 470 minecraft:white_concrete
fill 216 231 471 217 232 472 minecraft:light_gray_concrete
fill 216 231 473 217 232 474 minecraft:white_concrete
fill 216 231 475 217 232 476 minecraft:light_gray_concrete
fill 216 231 477 217 232 478 minecraft:white_concrete
fill 216 231 479 217 232 480 minecraft:light_gray_concrete
fill 216 231 481 217 232 482 minecraft:white_concrete
fill 216 231 483 217 232 484 minecraft:light_gray_concrete
fill 216 231 485 217 232 486 minecraft:white_concrete
fill 216 231 487 217 232 488 minecraft:light_gray_concrete
fill 216 231 489 217 232 490 minecraft:white_concrete
fill 216 231 491 217 232 492 minecraft:light_gray_concrete
fill 216 231 493 217 232 494 minecraft:white_concrete
fill 216 231 495 217 232 496 minecraft:light_gray_concrete
fill 216 231 497 217 232 498 minecraft:white_concrete
fill 216 231 499 217 232 500 minecraft:light_gray_concrete
fill 216 231 501 217 232 502 minecraft:white_concrete
fill 216 231 503 217 232 504 minecraft:light_gray_concrete
fill 218 231 464 219 232 464 minecraft:white_concrete
fill 218 231 465 219 232 466 minecraft:light_gray_concrete
fill 218 231 467 219 232 468 minecraft:white_concrete
fill 218 231 469 219 232 470 minecraft:light_gray_concrete
fill 218 231 471 219 232 472 minecraft:white_concrete
fill 218 231 473 219 232 474 minecraft:light_gray_concrete
fill 218 231 475 219 232 476 minecraft:white_concrete
fill 218 231 477 219 232 478 minecraft:light_gray_concrete
fill 218 231 479 219 232 480 minecraft:white_concrete
fill 218 231 481 219 232 482 minecraft:light_gray_concrete
fill 218 231 483 219 232 484 minecraft:white_concrete
fill 218 231 485 219 232 486 minecraft:light_gray_concrete
fill 218 231 487 219 232 488 minecraft:white_concrete
fill 218 231 489 219 232 490 minecraft:light_gray_concrete
fill 218 231 491 219 232 492 minecraft:white_concrete
fill 218 231 493 219 232 494 minecraft:light_gray_concrete
fill 218 231 495 219 232 496 minecraft:white_concrete
fill 218 231 497 219 232 498 minecraft:light_gray_concrete
fill 218 231 499 219 232 500 minecraft:white_concrete
fill 218 231 501 219 232 502 minecraft:light_gray_concrete
fill 218 231 503 219 232 504 minecraft:white_concrete
fill 220 231 464 221 232 464 minecraft:light_gray_concrete
fill 220 231 465 221 232 466 minecraft:white_concrete
fill 220 231 467 221 232 468 minecraft:light_gray_concrete
fill 220 231 469 221 232 470 minecraft:white_concrete
fill 220 231 471 221 232 472 minecraft:light_gray_concrete
fill 220 231 473 221 232 474 minecraft:white_concrete
fill 220 231 475 221 232 476 minecraft:light_gray_concrete
fill 220 231 477 221 232 478 minecraft:white_concrete
fill 220 231 479 221 232 480 minecraft:light_gray_concrete
fill 220 231 481 221 232 482 minecraft:white_concrete
fill 220 231 483 221 232 484 minecraft:light_gray_concrete
fill 220 231 485 221 232 486 minecraft:white_concrete
fill 220 231 487 221 232 488 minecraft:light_gray_concrete
fill 220 231 489 221 232 490 minecraft:white_concrete
fill 220 231 491 221 232 492 minecraft:light_gray_concrete
fill 220 231 493 221 232 494 minecraft:white_concrete
fill 220 231 495 221 232 496 minecraft:light_gray_concrete
fill 220 231 497 221 232 498 minecraft:white_concrete
fill 220 231 499 221 232 500 minecraft:light_gray_concrete
fill 220 231 501 221 232 502 minecraft:white_concrete
fill 220 231 503 221 232 504 minecraft:light_gray_concrete
fill 222 231 464 223 232 464 minecraft:white_concrete
fill 222 231 465 223 232 466 minecraft:light_gray_concrete
fill 222 231 467 223 232 468 minecraft:white_concrete
fill 222 231 469 223 232 470 minecraft:light_gray_concrete
fill 222 231 471 223 232 472 minecraft:white_concrete
fill 222 231 473 223 232 474 minecraft:light_gray_concrete
fill 222 231 475 223 232 476 minecraft:white_concrete
fill 222 231 477 223 232 478 minecraft:light_gray_concrete
fill 222 231 479 223 232 480 minecraft:white_concrete
fill 222 231 481 223 232 482 minecraft:light_gray_concrete
fill 222 231 483 223 232 484 minecraft:white_concrete
fill 222 231 485 223 232 486 minecraft:light_gray_concrete
fill 222 231 487 223 232 488 minecraft:white_concrete
fill 222 231 489 223 232 490 minecraft:light_gray_concrete
fill 222 231 491 223 232 492 minecraft:white_concrete
fill 222 231 493 223 232 494 minecraft:light_gray_concrete
fill 222 231 495 223 232 496 minecraft:white_concrete
fill 222 231 497 223 232 498 minecraft:light_gray_concrete
fill 222 231 499 223 232 500 minecraft:white_concrete
fill 222 231 501 223 232 502 minecraft:light_gray_concrete
fill 222 231 503 223 232 504 minecraft:white_concrete
fill 224 231 464 225 232 464 minecraft:light_gray_concrete
fill 224 231 465 225 232 466 minecraft:white_concrete
fill 224 231 467 225 232 468 minecraft:light_gray_concrete
fill 224 231 469 225 232 470 minecraft:white_concrete
fill 224 231 471 225 232 472 minecraft:light_gray_concrete
fill 224 231 473 225 232 474 minecraft:white_concrete
fill 224 231 475 225 232 476 minecraft:light_gray_concrete
fill 224 231 477 225 232 478 minecraft:white_concrete
fill 224 231 479 225 232 480 minecraft:light_gray_concrete
fill 224 231 481 225 232 482 minecraft:white_concrete
fill 224 231 483 225 232 484 minecraft:light_gray_concrete
fill 224 231 485 225 232 486 minecraft:white_concrete
fill 224 231 487 225 232 488 minecraft:light_gray_concrete
fill 224 231 489 225 232 490 minecraft:white_concrete
fill 224 231 491 225 232 492 minecraft:light_gray_concrete
fill 224 231 493 225 232 494 minecraft:white_concrete
fill 224 231 495 225 232 496 minecraft:light_gray_concrete
fill 224 231 497 225 232 498 minecraft:white_concrete
fill 224 231 499 225 232 500 minecraft:light_gray_concrete
fill 224 231 501 225 232 502 minecraft:white_concrete
fill 224 231 503 225 232 504 minecraft:light_gray_concrete
fill 226 231 464 227 232 464 minecraft:white_concrete
fill 226 231 465 227 232 466 minecraft:light_gray_concrete
fill 226 231 467 227 232 468 minecraft:white_concrete
fill 226 231 469 227 232 470 minecraft:light_gray_concrete
fill 226 231 471 227 232 472 minecraft:white_concrete
fill 226 231 473 227 232 474 minecraft:light_gray_concrete
fill 226 231 475 227 232 476 minecraft:white_concrete
fill 226 231 477 227 232 478 minecraft:light_gray_concrete
fill 226 231 479 227 232 480 minecraft:white_concrete
fill 226 231 481 227 232 482 minecraft:light_gray_concrete
fill 226 231 483 227 232 484 minecraft:white_concrete
fill 226 231 485 227 232 486 minecraft:light_gray_concrete
fill 226 231 487 227 232 488 minecraft:white_concrete
fill 226 231 489 227 232 490 minecraft:light_gray_concrete
fill 226 231 491 227 232 492 minecraft:white_concrete
fill 226 231 493 227 232 494 minecraft:light_gray_concrete
fill 226 231 495 227 232 496 minecraft:white_concrete
fill 226 231 497 227 232 498 minecraft:light_gray_concrete
fill 226 231 499 227 232 500 minecraft:white_concrete
fill 226 231 501 227 232 502 minecraft:light_gray_concrete
fill 226 231 503 227 232 504 minecraft:white_concrete
fill 228 231 464 229 232 464 minecraft:light_gray_concrete
fill 228 231 465 229 232 466 minecraft:white_concrete
fill 228 231 467 229 232 468 minecraft:light_gray_concrete
fill 228 231 469 229 232 470 minecraft:white_concrete
fill 228 231 471 229 232 472 minecraft:light_gray_concrete
fill 228 231 473 229 232 474 minecraft:white_concrete
fill 228 231 475 229 232 476 minecraft:light_gray_concrete
fill 228 231 477 229 232 478 minecraft:white_concrete
fill 228 231 479 229 232 480 minecraft:light_gray_concrete
fill 228 231 481 229 232 482 minecraft:white_concrete
fill 228 231 483 229 232 484 minecraft:light_gray_concrete
fill 228 231 485 229 232 486 minecraft:white_concrete
fill 228 231 487 229 232 488 minecraft:light_gray_concrete
fill 228 231 489 229 232 490 minecraft:white_concrete
fill 228 231 491 229 232 492 minecraft:light_gray_concrete
fill 228 231 493 229 232 494 minecraft:white_concrete
fill 228 231 495 229 232 496 minecraft:light_gray_concrete
fill 228 231 497 229 232 498 minecraft:white_concrete
fill 228 231 499 229 232 500 minecraft:light_gray_concrete
fill 228 231 501 229 232 502 minecraft:white_concrete
fill 228 231 503 229 232 504 minecraft:light_gray_concrete
fill 208 232 485 208 232 486 minecraft:white_concrete
fill 208 232 487 208 232 488 minecraft:light_gray_concrete
setblock 209 232 485 minecraft:white_concrete
fill 209 232 486 209 232 488 minecraft:pearlescent_froglight
fill 210 232 483 210 232 484 minecraft:white_concrete
fill 210 232 485 210 232 486 minecraft:pearlescent_froglight
fill 210 232 488 210 232 489 minecraft:pearlescent_froglight
setblock 210 232 490 minecraft:light_gray_concrete
setblock 211 232 483 minecraft:white_concrete
fill 211 232 484 211 232 485 minecraft:pearlescent_froglight
fill 211 232 489 211 232 490 minecraft:pearlescent_froglight
fill 212 232 483 213 232 483 minecraft:light_gray_concrete
fill 212 232 484 213 232 484 minecraft:pearlescent_froglight
fill 212 232 490 213 232 490 minecraft:pearlescent_froglight
fill 213 232 485 214 232 485 minecraft:pearlescent_froglight
fill 213 232 489 214 232 489 minecraft:pearlescent_froglight
fill 214 232 486 215 232 486 minecraft:pearlescent_froglight
fill 214 232 488 215 232 488 minecraft:pearlescent_froglight
fill 214 232 490 215 232 490 minecraft:light_gray_concrete
setblock 215 232 485 minecraft:light_gray_concrete
setblock 215 232 487 minecraft:pearlescent_froglight
setblock 215 232 489 minecraft:light_gray_concrete
fill 189 236 470 189 273 471 minecraft:light_gray_concrete
fill 189 236 478 189 273 479 minecraft:light_gray_concrete
fill 189 236 486 189 273 487 minecraft:light_gray_concrete
fill 189 236 490 192 251 500 minecraft:light_gray_concrete
fill 189 236 502 189 273 503 minecraft:light_gray_concrete
fill 190 236 464 191 273 464 minecraft:light_gray_concrete
fill 195 236 504 196 273 504 minecraft:light_gray_concrete
fill 198 236 464 199 273 464 minecraft:light_gray_concrete
fill 203 236 504 204 273 504 minecraft:light_gray_concrete
fill 206 236 464 207 273 464 minecraft:light_gray_concrete
setblock 206 236 470 minecraft:red_concrete
fill 211 236 504 212 273 504 minecraft:light_gray_concrete
fill 214 236 464 215 273 464 minecraft:light_gray_concrete
fill 219 236 504 220 273 504 minecraft:light_gray_concrete
fill 222 236 464 223 273 464 minecraft:light_gray_concrete
fill 227 236 504 228 273 504 minecraft:light_gray_concrete
fill 229 236 465 229 273 466 minecraft:light_gray_concrete
fill 229 236 473 229 273 474 minecraft:light_gray_concrete
fill 229 236 481 229 273 482 minecraft:light_gray_concrete
fill 229 236 489 229 273 490 minecraft:light_gray_concrete
fill 229 236 497 229 273 498 minecraft:light_gray_concrete
setblock 191 237 466 minecraft:light[level=11]
setblock 191 237 474 minecraft:light[level=11]
setblock 191 237 482 minecraft:light[level=11]
setblock 199 237 466 minecraft:light[level=11]
setblock 199 237 474 minecraft:light[level=11]
setblock 199 237 482 minecraft:light[level=11]
setblock 199 237 490 minecraft:light[level=11]
setblock 199 237 498 minecraft:light[level=11]
setblock 207 237 466 minecraft:light[level=11]
setblock 207 237 474 minecraft:light[level=11]
setblock 207 237 482 minecraft:light[level=11]
setblock 207 237 490 minecraft:light[level=11]
setblock 207 237 498 minecraft:light[level=11]
setblock 215 237 466 minecraft:light[level=11]
setblock 215 237 474 minecraft:light[level=11]
setblock 215 237 482 minecraft:light[level=11]
setblock 215 237 490 minecraft:light[level=11]
setblock 215 237 498 minecraft:light[level=11]
setblock 223 237 466 minecraft:light[level=11]
setblock 223 237 474 minecraft:light[level=11]
setblock 223 237 482 minecraft:light[level=11]
setblock 223 237 490 minecraft:light[level=11]
setblock 223 237 498 minecraft:light[level=11]
fill 189 238 464 189 239 469 minecraft:light_gray_concrete
fill 189 238 472 190 238 477 minecraft:light_gray_concrete
fill 189 238 480 190 238 485 minecraft:light_gray_concrete
fill 189 238 488 190 238 489 minecraft:light_gray_concrete
fill 189 238 501 190 238 501 minecraft:light_gray_concrete
fill 189 238 504 194 239 504 minecraft:light_gray_concrete
fill 190 238 465 190 238 471 minecraft:light_gray_concrete
fill 190 238 478 190 238 479 minecraft:light_gray_concrete
fill 190 238 486 190 238 487 minecraft:light_gray_concrete
fill 190 238 502 190 238 503 minecraft:light_gray_concrete
fill 191 238 465 228 238 465 minecraft:light_gray_concrete
fill 191 238 503 229 238 503 minecraft:light_gray_concrete
fill 192 238 464 197 239 464 minecraft:light_gray_concrete
fill 197 238 504 202 239 504 minecraft:light_gray_concrete
fill 200 238 464 205 239 464 minecraft:light_gray_concrete
fill 205 238 504 210 239 504 minecraft:light_gray_concrete
fill 208 238 464 213 239 464 minecraft:light_gray_concrete
fill 213 238 504 218 239 504 minecraft:light_gray_concrete
fill 216 238 464 221 239 464 minecraft:light_gray_concrete
fill 221 238 504 226 239 504 minecraft:light_gray_concrete
fill 224 238 464 229 239 464 minecraft:light_gray_concrete
fill 228 238 466 228 238 502 minecraft:light_gray_concrete
fill 229 238 467 229 239 472 minecraft:light_gray_concrete
fill 229 238 475 229 239 480 minecraft:light_gray_concrete
fill 229 238 483 229 239 488 minecraft:light_gray_concrete
fill 229 238 491 229 239 496 minecraft:light_gray_concrete
fill 229 238 499 229 239 502 minecraft:light_gray_concrete
fill 229 238 504 229 239 504 minecraft:light_gray_concrete
fill 189 239 472 189 239 477 minecraft:light_gray_concrete
fill 189 239 480 189 239 485 minecraft:light_gray_concrete
fill 189 239 488 189 239 489 minecraft:light_gray_concrete
setblock 189 239 501 minecraft:light_gray_concrete
setblock 229 239 503 minecraft:light_gray_concrete
fill 188 242 468 188 247 468 minecraft:pearlescent_froglight
fill 188 242 476 188 247 476 minecraft:pearlescent_froglight
fill 188 242 484 188 247 484 minecraft:pearlescent_froglight
fill 188 242 492 188 247 492 minecraft:pearlescent_froglight
fill 188 242 500 188 247 500 minecraft:pearlescent_froglight
fill 191 242 505 191 247 505 minecraft:pearlescent_froglight
fill 195 242 463 195 247 463 minecraft:pearlescent_froglight
fill 199 242 505 199 247 505 minecraft:pearlescent_froglight
fill 203 242 463 203 247 463 minecraft:pearlescent_froglight
fill 207 242 505 207 247 505 minecraft:pearlescent_froglight
fill 211 242 463 211 247 463 minecraft:pearlescent_froglight
fill 215 242 505 215 247 505 minecraft:pearlescent_froglight
fill 219 242 463 219 247 463 minecraft:pearlescent_froglight
fill 223 242 505 223 247 505 minecraft:pearlescent_froglight
fill 227 242 463 227 247 463 minecraft:pearlescent_froglight
fill 230 242 468 230 247 468 minecraft:pearlescent_froglight
fill 230 242 476 230 247 476 minecraft:pearlescent_froglight
fill 230 242 484 230 247 484 minecraft:pearlescent_froglight
fill 230 242 492 230 247 492 minecraft:pearlescent_froglight
fill 230 242 500 230 247 500 minecraft:pearlescent_froglight
setblock 191 245 466 minecraft:light[level=11]
setblock 191 245 474 minecraft:light[level=11]
setblock 191 245 482 minecraft:light[level=11]
setblock 199 245 466 minecraft:light[level=11]
setblock 199 245 474 minecraft:light[level=11]
setblock 199 245 482 minecraft:light[level=11]
setblock 199 245 490 minecraft:light[level=11]
setblock 199 245 498 minecraft:light[level=11]
setblock 207 245 466 minecraft:light[level=11]
setblock 207 245 474 minecraft:light[level=11]
setblock 207 245 482 minecraft:light[level=11]
setblock 207 245 490 minecraft:light[level=11]
setblock 207 245 498 minecraft:light[level=11]
setblock 215 245 466 minecraft:light[level=11]
setblock 215 245 474 minecraft:light[level=11]
setblock 215 245 482 minecraft:light[level=11]
setblock 215 245 490 minecraft:light[level=11]
setblock 215 245 498 minecraft:light[level=11]
setblock 223 245 466 minecraft:light[level=11]
setblock 223 245 474 minecraft:light[level=11]
setblock 223 245 482 minecraft:light[level=11]
setblock 223 245 490 minecraft:light[level=11]
setblock 223 245 498 minecraft:light[level=11]
fill 188 248 468 188 255 468 minecraft:white_terracotta
fill 188 248 476 188 255 476 minecraft:white_terracotta
fill 188 248 484 188 255 484 minecraft:white_terracotta
fill 188 248 492 188 255 492 minecraft:white_terracotta
fill 188 248 500 188 255 500 minecraft:white_terracotta
fill 191 248 505 191 255 505 minecraft:white_terracotta
fill 195 248 463 195 255 463 minecraft:white_terracotta
fill 199 248 505 199 255 505 minecraft:white_terracotta
fill 203 248 463 203 255 463 minecraft:white_terracotta
fill 207 248 505 207 255 505 minecraft:white_terracotta
fill 211 248 463 211 255 463 minecraft:white_terracotta
fill 215 248 505 215 255 505 minecraft:white_terracotta
fill 219 248 463 219 255 463 minecraft:white_terracotta
fill 223 248 505 223 255 505 minecraft:white_terracotta
fill 227 248 463 227 255 463 minecraft:white_terracotta
fill 230 248 468 230 255 468 minecraft:white_terracotta
fill 230 248 476 230 255 476 minecraft:white_terracotta
fill 230 248 484 230 255 484 minecraft:white_terracotta
fill 230 248 492 230 255 492 minecraft:white_terracotta
fill 230 248 500 230 255 500 minecraft:white_terracotta
fill 224 249 485 224 261 485 minecraft:iron_block
fill 189 252 464 189 253 469 minecraft:light_gray_concrete
fill 189 252 472 190 252 477 minecraft:light_gray_concrete
fill 189 252 480 190 252 485 minecraft:light_gray_concrete
fill 189 252 488 190 252 501 minecraft:light_gray_concrete
fill 189 252 504 194 253 504 minecraft:light_gray_concrete
fill 190 252 465 190 252 471 minecraft:light_gray_concrete
fill 190 252 478 190 252 479 minecraft:light_gray_concrete
fill 190 252 486 190 252 487 minecraft:light_gray_concrete
fill 190 252 502 190 252 503 minecraft:light_gray_concrete
fill 191 252 465 228 252 465 minecraft:light_gray_concrete
fill 191 252 503 229 252 503 minecraft:light_gray_concrete
fill 192 252 464 197 253 464 minecraft:light_gray_concrete
fill 197 252 504 202 253 504 minecraft:light_gray_concrete
fill 200 252 464 205 253 464 minecraft:light_gray_concrete
fill 205 252 504 210 253 504 minecraft:light_gray_concrete
fill 208 252 464 213 253 464 minecraft:light_gray_concrete
fill 210 252 502 210 260 502 minecraft:light_blue_wool
fill 213 252 504 218 253 504 minecraft:light_gray_concrete
fill 216 252 464 221 253 464 minecraft:light_gray_concrete
fill 221 252 504 226 253 504 minecraft:light_gray_concrete
fill 224 252 464 229 253 464 minecraft:light_gray_concrete
fill 228 252 466 228 252 502 minecraft:light_gray_concrete
fill 229 252 467 229 253 472 minecraft:light_gray_concrete
fill 229 252 475 229 253 480 minecraft:light_gray_concrete
fill 229 252 483 229 253 488 minecraft:light_gray_concrete
fill 229 252 491 229 253 496 minecraft:light_gray_concrete
fill 229 252 499 229 253 502 minecraft:light_gray_concrete
fill 229 252 504 229 253 504 minecraft:light_gray_concrete
fill 189 253 472 189 253 477 minecraft:light_gray_concrete
fill 189 253 480 189 253 485 minecraft:light_gray_concrete
fill 189 253 488 189 253 501 minecraft:light_gray_concrete
setblock 191 253 466 minecraft:light[level=11]
setblock 191 253 474 minecraft:light[level=11]
setblock 191 253 482 minecraft:light[level=11]
setblock 191 253 490 minecraft:light[level=11]
setblock 191 253 498 minecraft:light[level=11]
setblock 199 253 466 minecraft:light[level=11]
setblock 199 253 474 minecraft:light[level=11]
setblock 199 253 482 minecraft:light[level=11]
setblock 199 253 490 minecraft:light[level=11]
setblock 199 253 498 minecraft:light[level=11]
setblock 207 253 466 minecraft:light[level=11]
setblock 207 253 474 minecraft:light[level=11]
setblock 207 253 482 minecraft:light[level=11]
setblock 207 253 490 minecraft:light[level=11]
setblock 207 253 498 minecraft:light[level=11]
fill 208 253 502 209 260 502 minecraft:light_blue_wool
fill 211 253 502 212 260 502 minecraft:light_blue_wool
setblock 215 253 466 minecraft:light[level=11]
setblock 215 253 474 minecraft:light[level=11]
setblock 215 253 482 minecraft:light[level=11]
setblock 215 253 490 minecraft:light[level=11]
setblock 215 253 498 minecraft:light[level=11]
setblock 223 253 466 minecraft:light[level=11]
setblock 223 253 474 minecraft:light[level=11]
setblock 223 253 482 minecraft:light[level=11]
setblock 223 253 490 minecraft:light[level=11]
setblock 223 253 498 minecraft:light[level=11]
setblock 229 253 503 minecraft:light_gray_concrete
fill 189 254 494 189 273 495 minecraft:light_gray_concrete
fill 188 256 468 188 261 468 minecraft:pearlescent_froglight
fill 188 256 476 188 261 476 minecraft:pearlescent_froglight
fill 188 256 484 188 261 484 minecraft:pearlescent_froglight
fill 188 256 492 188 261 492 minecraft:pearlescent_froglight
fill 188 256 500 188 261 500 minecraft:pearlescent_froglight
fill 191 256 505 191 261 505 minecraft:pearlescent_froglight
fill 195 256 463 195 261 463 minecraft:pearlescent_froglight
fill 199 256 505 199 261 505 minecraft:pearlescent_froglight
fill 203 256 463 203 261 463 minecraft:pearlescent_froglight
fill 207 256 505 207 261 505 minecraft:pearlescent_froglight
fill 211 256 463 211 261 463 minecraft:pearlescent_froglight
fill 215 256 505 215 261 505 minecraft:pearlescent_froglight
fill 219 256 463 219 261 463 minecraft:pearlescent_froglight
fill 223 256 505 223 261 505 minecraft:pearlescent_froglight
fill 227 256 463 227 261 463 minecraft:pearlescent_froglight
fill 230 256 468 230 261 468 minecraft:pearlescent_froglight
fill 230 256 476 230 261 476 minecraft:pearlescent_froglight
fill 230 256 484 230 261 484 minecraft:pearlescent_froglight
fill 230 256 492 230 261 492 minecraft:pearlescent_froglight
fill 230 256 500 230 261 500 minecraft:pearlescent_froglight
setblock 191 261 466 minecraft:light[level=11]
setblock 191 261 474 minecraft:light[level=11]
setblock 191 261 482 minecraft:light[level=11]
setblock 191 261 490 minecraft:light[level=11]
setblock 191 261 498 minecraft:light[level=11]
setblock 199 261 466 minecraft:light[level=11]
setblock 199 261 474 minecraft:light[level=11]
setblock 199 261 482 minecraft:light[level=11]
setblock 199 261 490 minecraft:light[level=11]
setblock 199 261 498 minecraft:light[level=11]
setblock 207 261 466 minecraft:light[level=11]
setblock 207 261 474 minecraft:light[level=11]
setblock 207 261 482 minecraft:light[level=11]
setblock 207 261 490 minecraft:light[level=11]
setblock 207 261 498 minecraft:light[level=11]
fill 207 261 502 213 262 502 minecraft:iron_block
setblock 215 261 466 minecraft:light[level=11]
setblock 215 261 474 minecraft:light[level=11]
setblock 215 261 482 minecraft:light[level=11]
setblock 215 261 490 minecraft:light[level=11]
setblock 215 261 498 minecraft:light[level=11]
setblock 223 261 466 minecraft:light[level=11]
setblock 223 261 474 minecraft:light[level=11]
setblock 223 261 482 minecraft:light[level=11]
setblock 223 261 490 minecraft:light[level=11]
setblock 223 261 498 minecraft:light[level=11]
fill 188 262 468 188 269 468 minecraft:white_terracotta
fill 188 262 476 188 269 476 minecraft:white_terracotta
fill 188 262 484 188 269 484 minecraft:white_terracotta
fill 188 262 492 188 269 492 minecraft:white_terracotta
fill 188 262 500 188 269 500 minecraft:white_terracotta
fill 191 262 505 191 269 505 minecraft:white_terracotta
fill 195 262 463 195 269 463 minecraft:white_terracotta
fill 199 262 505 199 269 505 minecraft:white_terracotta
fill 203 262 463 203 269 463 minecraft:white_terracotta
fill 207 262 505 207 269 505 minecraft:white_terracotta
fill 211 262 463 211 269 463 minecraft:white_terracotta
fill 215 262 505 215 269 505 minecraft:white_terracotta
fill 219 262 463 219 269 463 minecraft:white_terracotta
fill 223 262 505 223 269 505 minecraft:white_terracotta
fill 227 262 463 227 269 463 minecraft:white_terracotta
fill 230 262 468 230 269 468 minecraft:white_terracotta
fill 230 262 476 230 269 476 minecraft:white_terracotta
fill 230 262 484 230 269 484 minecraft:white_terracotta
fill 230 262 492 230 269 492 minecraft:white_terracotta
fill 230 262 500 230 269 500 minecraft:white_terracotta
fill 202 265 496 204 266 496 minecraft:white_wool
fill 203 265 495 203 266 495 minecraft:white_wool
fill 203 265 497 203 266 497 minecraft:white_wool
fill 189 266 464 189 267 469 minecraft:light_gray_concrete
fill 189 266 472 190 266 477 minecraft:light_gray_concrete
fill 189 266 480 190 266 485 minecraft:light_gray_concrete
fill 189 266 488 190 266 493 minecraft:light_gray_concrete
fill 189 266 496 190 266 501 minecraft:light_gray_concrete
fill 189 266 504 194 267 504 minecraft:light_gray_concrete
fill 190 266 465 190 266 471 minecraft:light_gray_concrete
fill 190 266 478 190 266 479 minecraft:light_gray_concrete
fill 190 266 486 190 266 487 minecraft:light_gray_concrete
fill 190 266 494 190 266 495 minecraft:light_gray_concrete
fill 190 266 502 190 266 503 minecraft:light_gray_concrete
fill 191 266 465 228 266 465 minecraft:light_gray_concrete
fill 191 266 503 229 266 503 minecraft:light_gray_concrete
fill 192 266 464 197 267 464 minecraft:light_gray_concrete
fill 197 266 504 202 267 504 minecraft:light_gray_concrete
fill 200 266 464 205 267 464 minecraft:light_gray_concrete
fill 205 266 504 210 267 504 minecraft:light_gray_concrete
fill 208 266 464 213 267 464 minecraft:light_gray_concrete
fill 213 266 504 218 267 504 minecraft:light_gray_concrete
fill 216 266 464 221 267 464 minecraft:light_gray_concrete
fill 221 266 504 226 267 504 minecraft:light_gray_concrete
fill 224 266 464 229 267 464 minecraft:light_gray_concrete
fill 228 266 466 228 266 502 minecraft:light_gray_concrete
fill 229 266 467 229 267 472 minecraft:light_gray_concrete
fill 229 266 475 229 267 480 minecraft:light_gray_concrete
fill 229 266 483 229 267 488 minecraft:light_gray_concrete
fill 229 266 491 229 267 496 minecraft:light_gray_concrete
fill 229 266 499 229 267 502 minecraft:light_gray_concrete
fill 229 266 504 229 267 504 minecraft:light_gray_concrete
fill 189 267 472 189 267 477 minecraft:light_gray_concrete
fill 189 267 480 189 267 485 minecraft:light_gray_concrete
fill 189 267 488 189 267 493 minecraft:light_gray_concrete
fill 189 267 496 189 267 501 minecraft:light_gray_concrete
setblock 229 267 503 minecraft:light_gray_concrete
setblock 191 269 466 minecraft:light[level=11]
setblock 191 269 474 minecraft:light[level=11]
setblock 191 269 482 minecraft:light[level=11]
setblock 191 269 490 minecraft:light[level=11]
setblock 191 269 498 minecraft:light[level=11]
setblock 199 269 466 minecraft:light[level=11]
setblock 199 269 474 minecraft:light[level=11]
setblock 199 269 482 minecraft:light[level=11]
setblock 199 269 490 minecraft:light[level=11]
setblock 199 269 498 minecraft:light[level=11]
setblock 207 269 466 minecraft:light[level=11]
setblock 207 269 474 minecraft:light[level=11]
setblock 207 269 482 minecraft:light[level=11]
setblock 207 269 490 minecraft:light[level=11]
setblock 207 269 498 minecraft:light[level=11]
setblock 215 269 466 minecraft:light[level=11]
setblock 215 269 474 minecraft:light[level=11]
setblock 215 269 482 minecraft:light[level=11]
setblock 215 269 490 minecraft:light[level=11]
setblock 215 269 498 minecraft:light[level=11]
setblock 223 269 466 minecraft:light[level=11]
setblock 223 269 474 minecraft:light[level=11]
setblock 223 269 482 minecraft:light[level=11]
setblock 223 269 490 minecraft:light[level=11]
setblock 223 269 498 minecraft:light[level=11]
fill 188 270 468 188 273 468 minecraft:pearlescent_froglight
fill 188 270 476 188 273 476 minecraft:pearlescent_froglight
fill 188 270 484 188 273 484 minecraft:pearlescent_froglight
fill 188 270 492 188 273 492 minecraft:pearlescent_froglight
fill 188 270 500 188 273 500 minecraft:pearlescent_froglight
fill 191 270 505 191 273 505 minecraft:pearlescent_froglight
fill 195 270 463 195 273 463 minecraft:pearlescent_froglight
fill 199 270 505 199 273 505 minecraft:pearlescent_froglight
fill 203 270 463 203 273 463 minecraft:pearlescent_froglight
fill 207 270 505 207 273 505 minecraft:pearlescent_froglight
fill 211 270 463 211 273 463 minecraft:pearlescent_froglight
fill 215 270 505 215 273 505 minecraft:pearlescent_froglight
fill 219 270 463 219 273 463 minecraft:pearlescent_froglight
fill 223 270 505 223 273 505 minecraft:pearlescent_froglight
fill 227 270 463 227 273 463 minecraft:pearlescent_froglight
fill 230 270 468 230 273 468 minecraft:pearlescent_froglight
fill 230 270 476 230 273 476 minecraft:pearlescent_froglight
fill 230 270 484 230 273 484 minecraft:pearlescent_froglight
fill 230 270 492 230 273 492 minecraft:pearlescent_froglight
fill 230 270 500 230 273 500 minecraft:pearlescent_froglight
fill 188 274 468 188 283 468 minecraft:white_terracotta
fill 188 274 476 188 283 476 minecraft:white_terracotta
fill 188 274 484 188 283 484 minecraft:white_terracotta
fill 188 274 492 188 283 492 minecraft:white_terracotta
fill 188 274 500 188 283 500 minecraft:white_terracotta
fill 191 274 505 191 283 505 minecraft:white_terracotta
fill 195 274 463 195 283 463 minecraft:white_terracotta
fill 199 274 505 199 283 505 minecraft:white_terracotta
fill 203 274 463 203 283 463 minecraft:white_terracotta
fill 207 274 505 207 283 505 minecraft:white_terracotta
fill 211 274 463 211 283 463 minecraft:white_terracotta
fill 215 274 505 215 283 505 minecraft:white_terracotta
fill 219 274 463 219 283 463 minecraft:white_terracotta
fill 223 274 505 223 283 505 minecraft:white_terracotta
fill 227 274 463 227 283 463 minecraft:white_terracotta
fill 230 274 468 230 283 468 minecraft:white_terracotta
fill 230 274 476 230 283 476 minecraft:white_terracotta
fill 230 274 484 230 283 484 minecraft:white_terracotta
fill 230 274 492 230 283 492 minecraft:white_terracotta
fill 230 274 500 230 283 500 minecraft:white_terracotta
setblock 191 277 466 minecraft:light[level=11]
setblock 191 277 474 minecraft:light[level=11]
setblock 191 277 482 minecraft:light[level=11]
setblock 191 277 490 minecraft:light[level=11]
setblock 191 277 498 minecraft:light[level=11]
setblock 199 277 466 minecraft:light[level=11]
setblock 199 277 474 minecraft:light[level=11]
setblock 199 277 482 minecraft:light[level=11]
setblock 199 277 490 minecraft:light[level=11]
setblock 199 277 498 minecraft:light[level=11]
setblock 207 277 466 minecraft:light[level=11]
setblock 207 277 474 minecraft:light[level=11]
setblock 207 277 482 minecraft:light[level=11]
setblock 207 277 490 minecraft:light[level=11]
setblock 207 277 498 minecraft:light[level=11]
setblock 215 277 466 minecraft:light[level=11]
setblock 215 277 474 minecraft:light[level=11]
setblock 215 277 482 minecraft:light[level=11]
setblock 215 277 490 minecraft:light[level=11]
setblock 215 277 498 minecraft:light[level=11]
setblock 223 277 466 minecraft:light[level=11]
setblock 223 277 474 minecraft:light[level=11]
setblock 223 277 482 minecraft:light[level=11]
setblock 223 277 490 minecraft:light[level=11]
setblock 223 277 498 minecraft:light[level=11]
fill 199 279 487 206 279 487 minecraft:pearlescent_froglight
fill 200 279 483 207 279 486 minecraft:pearlescent_froglight
fill 200 279 488 207 279 491 minecraft:pearlescent_froglight
fill 201 279 481 217 279 482 minecraft:pearlescent_froglight
fill 201 279 492 217 279 493 minecraft:pearlescent_froglight
fill 202 279 480 216 279 480 minecraft:pearlescent_froglight
fill 202 279 494 216 279 494 minecraft:pearlescent_froglight
fill 203 279 479 215 279 479 minecraft:pearlescent_froglight
fill 203 279 495 215 279 495 minecraft:pearlescent_froglight
fill 205 279 478 213 279 478 minecraft:pearlescent_froglight
fill 205 279 496 213 279 496 minecraft:pearlescent_froglight
fill 208 279 483 208 280 485 minecraft:pearlescent_froglight
fill 208 279 489 208 280 491 minecraft:pearlescent_froglight
setblock 209 279 477 minecraft:pearlescent_froglight
fill 209 279 483 218 279 484 minecraft:pearlescent_froglight
fill 209 279 490 218 279 491 minecraft:pearlescent_froglight
setblock 209 279 497 minecraft:pearlescent_froglight
fill 210 279 485 218 279 485 minecraft:pearlescent_froglight
fill 210 279 489 218 279 489 minecraft:pearlescent_froglight
fill 211 279 486 218 279 486 minecraft:pearlescent_froglight
fill 211 279 488 218 279 488 minecraft:pearlescent_froglight
fill 212 279 487 219 279 487 minecraft:pearlescent_froglight
fill 189 280 464 198 280 504 minecraft:white_terracotta
fill 199 280 464 199 280 486 minecraft:white_terracotta
fill 199 280 487 200 280 487 minecraft:iron_block
fill 199 280 488 199 280 504 minecraft:white_terracotta
fill 200 280 464 200 280 482 minecraft:white_terracotta
fill 200 280 483 200 280 486 minecraft:iron_block
fill 200 280 488 200 280 491 minecraft:iron_block
fill 200 280 492 200 280 504 minecraft:white_terracotta
fill 201 280 464 201 280 480 minecraft:white_terracotta
fill 201 280 481 201 280 483 minecraft:iron_block
fill 201 280 484 202 280 490 minecraft:pearlescent_froglight
fill 201 280 491 201 280 493 minecraft:iron_block
fill 201 280 494 201 280 504 minecraft:white_terracotta
fill 202 280 464 202 280 479 minecraft:white_terracotta
fill 202 280 480 202 280 481 minecraft:iron_block
fill 202 280 482 204 280 483 minecraft:pearlescent_froglight
fill 202 280 491 204 280 492 minecraft:pearlescent_froglight
fill 202 280 493 202 280 494 minecraft:iron_block
fill 202 280 495 202 280 504 minecraft:white_terracotta
fill 203 280 464 204 280 478 minecraft:white_terracotta
fill 203 280 479 203 280 480 minecraft:iron_block
fill 203 280 481 206 280 481 minecraft:pearlescent_froglight
setblock 203 280 484 minecraft:pearlescent_froglight
fill 203 280 485 203 280 489 minecraft:light_gray_concrete
setblock 203 280 490 minecraft:pearlescent_froglight
fill 203 280 493 206 280 493 minecraft:pearlescent_froglight
fill 203 280 494 203 280 495 minecraft:iron_block
fill 203 280 496 204 280 504 minecraft:white_terracotta
fill 204 280 479 205 280 479 minecraft:iron_block
fill 204 280 480 214 280 480 minecraft:pearlescent_froglight
setblock 204 280 484 minecraft:light_gray_concrete
fill 204 280 485 206 280 489 minecraft:pearlescent_froglight
setblock 204 280 490 minecraft:light_gray_concrete
fill 204 280 494 214 280 494 minecraft:pearlescent_froglight
fill 204 280 495 205 280 495 minecraft:iron_block
fill 205 280 464 208 280 477 minecraft:white_terracotta
fill 205 280 478 213 280 478 minecraft:iron_block
setblock 205 280 482 minecraft:pearlescent_froglight
setblock 205 280 483 minecraft:light_gray_concrete
fill 205 280 484 207 280 484 minecraft:pearlescent_froglight
fill 205 280 490 207 280 490 minecraft:pearlescent_froglight
setblock 205 280 491 minecraft:light_gray_concrete
setblock 205 280 492 minecraft:pearlescent_froglight
fill 205 280 496 213 280 496 minecraft:iron_block
fill 205 280 497 208 280 504 minecraft:white_terracotta
fill 206 280 479 212 280 479 minecraft:pearlescent_froglight
setblock 206 280 482 minecraft:light_gray_concrete
fill 206 280 483 207 280 483 minecraft:pearlescent_froglight
fill 206 280 491 207 280 491 minecraft:pearlescent_froglight
setblock 206 280 492 minecraft:light_gray_concrete
fill 206 280 495 212 280 495 minecraft:pearlescent_froglight
fill 207 280 481 211 280 481 minecraft:light_gray_concrete
fill 207 280 482 211 280 482 minecraft:pearlescent_froglight
fill 207 280 485 207 280 486 minecraft:pearlescent_froglight
fill 207 280 488 207 280 489 minecraft:pearlescent_froglight
fill 207 280 492 211 280 492 minecraft:pearlescent_froglight
fill 207 280 493 211 280 493 minecraft:light_gray_concrete
fill 209 280 464 229 280 476 minecraft:white_terracotta
setblock 209 280 477 minecraft:iron_block
fill 209 280 483 212 280 484 minecraft:pearlescent_froglight
fill 209 280 490 212 280 491 minecraft:pearlescent_froglight
setblock 209 280 497 minecraft:iron_block
fill 209 280 498 229 280 504 minecraft:white_terracotta
fill 210 280 477 229 280 477 minecraft:white_terracotta
fill 210 280 485 214 280 485 minecraft:pearlescent_froglight
fill 210 280 489 214 280 489 minecraft:pearlescent_froglight
fill 210 280 497 229 280 497 minecraft:white_terracotta
fill 211 280 486 214 280 486 minecraft:pearlescent_froglight
fill 211 280 488 214 280 488 minecraft:pearlescent_froglight
fill 212 280 481 215 280 481 minecraft:pearlescent_froglight
setblock 212 280 482 minecraft:light_gray_concrete
fill 212 280 487 214 280 487 minecraft:pearlescent_froglight
setblock 212 280 492 minecraft:light_gray_concrete
fill 212 280 493 215 280 493 minecraft:pearlescent_froglight
fill 213 280 479 215 280 479 minecraft:iron_block
fill 213 280 482 216 280 482 minecraft:pearlescent_froglight
setblock 213 280 483 minecraft:light_gray_concrete
setblock 213 280 484 minecraft:pearlescent_froglight
setblock 213 280 490 minecraft:pearlescent_froglight
setblock 213 280 491 minecraft:light_gray_concrete
fill 213 280 492 216 280 492 minecraft:pearlescent_froglight
fill 213 280 495 215 280 495 minecraft:iron_block
fill 214 280 478 229 280 478 minecraft:white_terracotta
fill 214 280 483 216 280 483 minecraft:pearlescent_froglight
setblock 214 280 484 minecraft:light_gray_concrete
setblock 214 280 490 minecraft:light_gray_concrete
fill 214 280 491 216 280 491 minecraft:pearlescent_froglight
fill 214 280 496 229 280 496 minecraft:white_terracotta
fill 215 280 480 216 280 480 minecraft:iron_block
fill 215 280 484 217 280 484 minecraft:pearlescent_froglight
fill 215 280 485 215 280 489 minecraft:light_gray_concrete
fill 215 280 490 217 280 490 minecraft:pearlescent_froglight
fill 215 280 494 216 280 494 minecraft:iron_block
fill 216 280 479 229 280 479 minecraft:white_terracotta
fill 216 280 481 217 280 481 minecraft:iron_block
fill 216 280 485 217 280 489 minecraft:pearlescent_froglight
fill 216 280 493 217 280 493 minecraft:iron_block
fill 216 280 495 229 280 495 minecraft:white_terracotta
fill 217 280 480 229 280 480 minecraft:white_terracotta
fill 217 280 482 217 280 483 minecraft:iron_block
fill 217 280 491 217 280 492 minecraft:iron_block
fill 217 280 494 229 280 494 minecraft:white_terracotta
fill 218 280 481 229 280 482 minecraft:white_terracotta
fill 218 280 483 218 280 491 minecraft:iron_block
fill 218 280 492 229 280 493 minecraft:white_terracotta
fill 219 280 483 229 280 486 minecraft:white_terracotta
setblock 219 280 487 minecraft:iron_block
fill 219 280 488 229 280 491 minecraft:white_terracotta
fill 220 280 487 229 280 487 minecraft:white_terracotta
fill 188 284 468 188 289 468 minecraft:pearlescent_froglight
fill 188 284 476 188 289 476 minecraft:pearlescent_froglight
fill 188 284 484 188 289 484 minecraft:pearlescent_froglight
fill 188 284 492 188 289 492 minecraft:pearlescent_froglight
fill 188 284 500 188 289 500 minecraft:pearlescent_froglight
fill 189 284 470 189 300 471 minecraft:light_gray_concrete
fill 189 284 478 189 300 479 minecraft:light_gray_concrete
fill 189 284 486 189 300 487 minecraft:light_gray_concrete
fill 189 284 494 189 300 495 minecraft:light_gray_concrete
fill 189 284 502 189 300 503 minecraft:light_gray_concrete
fill 190 284 464 191 300 464 minecraft:light_gray_concrete
fill 191 284 505 191 289 505 minecraft:pearlescent_froglight
fill 195 284 463 195 289 463 minecraft:pearlescent_froglight
fill 195 284 504 196 300 504 minecraft:light_gray_concrete
fill 198 284 464 207 285 464 minecraft:light_gray_concrete
fill 199 284 465 205 285 468 minecraft:light_gray_concrete
fill 199 284 505 199 289 505 minecraft:pearlescent_froglight
fill 203 284 463 203 289 463 minecraft:pearlescent_froglight
fill 203 284 504 212 285 504 minecraft:light_gray_concrete
fill 204 284 495 210 285 503 minecraft:light_gray_concrete
fill 207 284 505 207 289 505 minecraft:pearlescent_froglight
fill 211 284 463 211 289 463 minecraft:pearlescent_froglight
fill 214 284 464 215 300 464 minecraft:light_gray_concrete
fill 215 284 505 215 289 505 minecraft:pearlescent_froglight
fill 219 284 463 219 289 463 minecraft:pearlescent_froglight
fill 219 284 486 229 285 498 minecraft:light_gray_concrete
fill 219 284 504 220 300 504 minecraft:light_gray_concrete
fill 222 284 464 223 300 464 minecraft:light_gray_concrete
fill 223 284 505 223 289 505 minecraft:pearlescent_froglight
fill 227 284 463 227 289 463 minecraft:pearlescent_froglight
fill 227 284 504 228 300 504 minecraft:light_gray_concrete
fill 229 284 465 229 300 466 minecraft:light_gray_concrete
fill 229 284 473 229 300 474 minecraft:light_gray_concrete
fill 229 284 481 229 300 482 minecraft:light_gray_concrete
fill 230 284 468 230 289 468 minecraft:pearlescent_froglight
fill 230 284 476 230 289 476 minecraft:pearlescent_froglight
fill 230 284 484 230 289 484 minecraft:pearlescent_froglight
fill 230 284 492 230 289 492 minecraft:pearlescent_froglight
fill 230 284 500 230 289 500 minecraft:pearlescent_froglight
setblock 191 285 466 minecraft:light[level=11]
setblock 191 285 474 minecraft:light[level=11]
setblock 191 285 482 minecraft:light[level=11]
setblock 191 285 490 minecraft:light[level=11]
setblock 191 285 498 minecraft:light[level=11]
setblock 199 285 474 minecraft:light[level=11]
setblock 199 285 482 minecraft:light[level=11]
setblock 199 285 490 minecraft:light[level=11]
setblock 199 285 498 minecraft:light[level=11]
setblock 207 285 466 minecraft:light[level=11]
setblock 207 285 474 minecraft:light[level=11]
setblock 207 285 482 minecraft:light[level=11]
setblock 207 285 490 minecraft:light[level=11]
setblock 215 285 466 minecraft:light[level=11]
setblock 215 285 474 minecraft:light[level=11]
setblock 215 285 482 minecraft:light[level=11]
setblock 215 285 490 minecraft:light[level=11]
setblock 215 285 498 minecraft:light[level=11]
setblock 223 285 466 minecraft:light[level=11]
setblock 223 285 474 minecraft:light[level=11]
setblock 223 285 482 minecraft:light[level=11]
fill 198 286 464 198 300 464 minecraft:light_gray_concrete
setblock 199 286 464 minecraft:pearlescent_froglight
fill 199 286 465 199 300 465 minecraft:light_gray_concrete
setblock 199 286 466 minecraft:pearlescent_froglight
fill 199 286 467 199 300 467 minecraft:light_gray_concrete
setblock 199 286 468 minecraft:pearlescent_froglight
fill 200 286 464 200 300 464 minecraft:light_gray_concrete
setblock 200 286 465 minecraft:pearlescent_froglight
fill 200 286 466 200 300 466 minecraft:light_gray_concrete
setblock 200 286 467 minecraft:pearlescent_froglight
fill 200 286 468 200 300 468 minecraft:light_gray_concrete
setblock 201 286 464 minecraft:pearlescent_froglight
fill 201 286 465 201 300 465 minecraft:light_gray_concrete
setblock 201 286 466 minecraft:pearlescent_froglight
fill 201 286 467 201 300 467 minecraft:light_gray_concrete
setblock 201 286 468 minecraft:pearlescent_froglight
fill 202 286 464 202 300 464 minecraft:light_gray_concrete
setblock 202 286 465 minecraft:pearlescent_froglight
fill 202 286 466 202 300 466 minecraft:light_gray_concrete
setblock 202 286 467 minecraft:pearlescent_froglight
fill 202 286 468 202 300 468 minecraft:light_gray_concrete
setblock 203 286 464 minecraft:pearlescent_froglight
fill 203 286 465 203 300 465 minecraft:light_gray_concrete
setblock 203 286 466 minecraft:pearlescent_froglight
fill 203 286 467 203 300 467 minecraft:light_gray_concrete
setblock 203 286 468 minecraft:pearlescent_froglight
fill 203 286 504 204 300 504 minecraft:light_gray_concrete
fill 204 286 464 204 300 464 minecraft:light_gray_concrete
setblock 204 286 465 minecraft:pearlescent_froglight
fill 204 286 466 204 300 466 minecraft:light_gray_concrete
setblock 204 286 467 minecraft:pearlescent_froglight
fill 204 286 468 204 300 468 minecraft:light_gray_concrete
setblock 204 286 495 minecraft:pearlescent_froglight
fill 204 286 496 204 300 496 minecraft:light_gray_concrete
setblock 204 286 497 minecraft:pearlescent_froglight
fill 204 286 498 204 300 498 minecraft:light_gray_concrete
setblock 204 286 499 minecraft:pearlescent_froglight
fill 204 286 500 204 300 500 minecraft:light_gray_concrete
setblock 204 286 501 minecraft:pearlescent_froglight
fill 204 286 502 204 300 502 minecraft:light_gray_concrete
setblock 204 286 503 minecraft:pearlescent_froglight
setblock 205 286 464 minecraft:pearlescent_froglight
fill 205 286 465 205 300 465 minecraft:light_gray_concrete
setblock 205 286 466 minecraft:pearlescent_froglight
fill 205 286 467 205 300 467 minecraft:light_gray_concrete
setblock 205 286 468 minecraft:pearlescent_froglight
fill 205 286 495 205 300 495 minecraft:light_gray_concrete
setblock 205 286 496 minecraft:pearlescent_froglight
fill 205 286 497 205 300 497 minecraft:light_gray_concrete
setblock 205 286 498 minecraft:pearlescent_froglight
fill 205 286 499 205 300 499 minecraft:light_gray_concrete
setblock 205 286 500 minecraft:pearlescent_froglight
fill 205 286 501 205 300 501 minecraft:light_gray_concrete
setblock 205 286 502 minecraft:pearlescent_froglight
fill 205 286 503 205 300 503 minecraft:light_gray_concrete
setblock 205 286 504 minecraft:pearlescent_froglight
fill 206 286 464 207 300 464 minecraft:light_gray_concrete
setblock 206 286 495 minecraft:pearlescent_froglight
fill 206 286 496 206 300 496 minecraft:light_gray_concrete
setblock 206 286 497 minecraft:pearlescent_froglight
fill 206 286 498 206 300 498 minecraft:light_gray_concrete
setblock 206 286 499 minecraft:pearlescent_froglight
fill 206 286 500 206 300 500 minecraft:light_gray_concrete
setblock 206 286 501 minecraft:pearlescent_froglight
fill 206 286 502 206 300 502 minecraft:light_gray_concrete
setblock 206 286 503 minecraft:pearlescent_froglight
fill 206 286 504 206 300 504 minecraft:light_gray_concrete
fill 207 286 495 207 300 495 minecraft:light_gray_concrete
setblock 207 286 496 minecraft:pearlescent_froglight
fill 207 286 497 207 300 497 minecraft:light_gray_concrete
setblock 207 286 498 minecraft:pearlescent_froglight
fill 207 286 499 207 300 499 minecraft:light_gray_concrete
setblock 207 286 500 minecraft:pearlescent_froglight
fill 207 286 501 207 300 501 minecraft:light_gray_concrete
setblock 207 286 502 minecraft:pearlescent_froglight
fill 207 286 503 207 300 503 minecraft:light_gray_concrete
setblock 207 286 504 minecraft:pearlescent_froglight
setblock 208 286 495 minecraft:pearlescent_froglight
fill 208 286 496 208 300 496 minecraft:light_gray_concrete
setblock 208 286 497 minecraft:pearlescent_froglight
fill 208 286 498 208 300 498 minecraft:light_gray_concrete
setblock 208 286 499 minecraft:pearlescent_froglight
fill 208 286 500 208 300 500 minecraft:light_gray_concrete
setblock 208 286 501 minecraft:pearlescent_froglight
fill 208 286 502 208 300 502 minecraft:light_gray_concrete
setblock 208 286 503 minecraft:pearlescent_froglight
fill 208 286 504 208 300 504 minecraft:light_gray_concrete
fill 209 286 495 209 300 495 minecraft:light_gray_concrete
setblock 209 286 496 minecraft:pearlescent_froglight
fill 209 286 497 209 300 497 minecraft:light_gray_concrete
setblock 209 286 498 minecraft:pearlescent_froglight
fill 209 286 499 209 300 499 minecraft:light_gray_concrete
setblock 209 286 500 minecraft:pearlescent_froglight
fill 209 286 501 209 300 501 minecraft:light_gray_concrete
setblock 209 286 502 minecraft:pearlescent_froglight
fill 209 286 503 209 300 503 minecraft:light_gray_concrete
setblock 209 286 504 minecraft:pearlescent_froglight
setblock 210 286 495 minecraft:pearlescent_froglight
fill 210 286 496 210 300 496 minecraft:light_gray_concrete
setblock 210 286 497 minecraft:pearlescent_froglight
fill 210 286 498 210 300 498 minecraft:light_gray_concrete
setblock 210 286 499 minecraft:pearlescent_froglight
fill 210 286 500 210 300 500 minecraft:light_gray_concrete
setblock 210 286 501 minecraft:pearlescent_froglight
fill 210 286 502 210 300 502 minecraft:light_gray_concrete
setblock 210 286 503 minecraft:pearlescent_froglight
fill 210 286 504 212 300 504 minecraft:light_gray_concrete
setblock 219 286 486 minecraft:pearlescent_froglight
fill 219 286 487 219 297 487 minecraft:light_gray_concrete
setblock 219 286 488 minecraft:pearlescent_froglight
fill 219 286 489 219 297 489 minecraft:light_gray_concrete
setblock 219 286 490 minecraft:pearlescent_froglight
fill 219 286 491 219 297 491 minecraft:light_gray_concrete
setblock 219 286 492 minecraft:pearlescent_froglight
fill 219 286 493 219 297 493 minecraft:light_gray_concrete
setblock 219 286 494 minecraft:pearlescent_froglight
fill 219 286 495 219 297 495 minecraft:light_gray_concrete
setblock 219 286 496 minecraft:pearlescent_froglight
fill 219 286 497 219 297 497 minecraft:light_gray_concrete
setblock 219 286 498 minecraft:pearlescent_froglight
fill 220 286 486 220 297 486 minecraft:light_gray_concrete
setblock 220 286 487 minecraft:pearlescent_froglight
fill 220 286 488 220 297 488 minecraft:light_gray_concrete
setblock 220 286 489 minecraft:pearlescent_froglight
fill 220 286 490 220 297 490 minecraft:light_gray_concrete
setblock 220 286 491 minecraft:pearlescent_froglight
fill 220 286 492 220 297 492 minecraft:light_gray_concrete
setblock 220 286 493 minecraft:pearlescent_froglight
fill 220 286 494 220 297 494 minecraft:light_gray_concrete
setblock 220 286 495 minecraft:pearlescent_froglight
fill 220 286 496 220 297 496 minecraft:light_gray_concrete
setblock 220 286 497 minecraft:pearlescent_froglight
fill 220 286 498 220 297 498 minecraft:light_gray_concrete
setblock 221 286 486 minecraft:pearlescent_froglight
fill 221 286 487 221 297 487 minecraft:light_gray_concrete
setblock 221 286 488 minecraft:pearlescent_froglight
fill 221 286 489 221 297 489 minecraft:light_gray_concrete
setblock 221 286 490 minecraft:pearlescent_froglight
fill 221 286 491 221 297 491 minecraft:light_gray_concrete
setblock 221 286 492 minecraft:pearlescent_froglight
fill 221 286 493 221 297 493 minecraft:light_gray_concrete
setblock 221 286 494 minecraft:pearlescent_froglight
fill 221 286 495 221 297 495 minecraft:light_gray_concrete
setblock 221 286 496 minecraft:pearlescent_froglight
fill 221 286 497 221 297 497 minecraft:light_gray_concrete
setblock 221 286 498 minecraft:pearlescent_froglight
fill 222 286 486 222 297 486 minecraft:light_gray_concrete
setblock 222 286 487 minecraft:pearlescent_froglight
fill 222 286 488 222 297 488 minecraft:light_gray_concrete
setblock 222 286 489 minecraft:pearlescent_froglight
fill 222 286 490 222 297 490 minecraft:light_gray_concrete
setblock 222 286 491 minecraft:pearlescent_froglight
fill 222 286 492 222 297 492 minecraft:light_gray_concrete
setblock 222 286 493 minecraft:pearlescent_froglight
fill 222 286 494 222 297 494 minecraft:light_gray_concrete
setblock 222 286 495 minecraft:pearlescent_froglight
fill 222 286 496 222 297 496 minecraft:light_gray_concrete
setblock 222 286 497 minecraft:pearlescent_froglight
fill 222 286 498 222 297 498 minecraft:light_gray_concrete
setblock 223 286 486 minecraft:pearlescent_froglight
fill 223 286 487 223 297 487 minecraft:light_gray_concrete
setblock 223 286 488 minecraft:pearlescent_froglight
fill 223 286 489 223 297 489 minecraft:light_gray_concrete
setblock 223 286 490 minecraft:pearlescent_froglight
fill 223 286 491 223 297 491 minecraft:light_gray_concrete
setblock 223 286 492 minecraft:pearlescent_froglight
fill 223 286 493 223 297 493 minecraft:light_gray_concrete
setblock 223 286 494 minecraft:pearlescent_froglight
fill 223 286 495 223 297 495 minecraft:light_gray_concrete
setblock 223 286 496 minecraft:pearlescent_froglight
fill 223 286 497 223 297 497 minecraft:light_gray_concrete
setblock 223 286 498 minecraft:pearlescent_froglight
fill 224 286 486 224 297 486 minecraft:light_gray_concrete
setblock 224 286 487 minecraft:pearlescent_froglight
fill 224 286 488 224 297 488 minecraft:light_gray_concrete
setblock 224 286 489 minecraft:pearlescent_froglight
fill 224 286 490 224 297 490 minecraft:light_gray_concrete
setblock 224 286 491 minecraft:pearlescent_froglight
fill 224 286 492 224 297 492 minecraft:light_gray_concrete
setblock 224 286 493 minecraft:pearlescent_froglight
fill 224 286 494 224 297 494 minecraft:light_gray_concrete
setblock 224 286 495 minecraft:pearlescent_froglight
fill 224 286 496 224 297 496 minecraft:light_gray_concrete
setblock 224 286 497 minecraft:pearlescent_froglight
fill 224 286 498 224 297 498 minecraft:light_gray_concrete
setblock 225 286 486 minecraft:pearlescent_froglight
fill 225 286 487 225 297 487 minecraft:light_gray_concrete
setblock 225 286 488 minecraft:pearlescent_froglight
fill 225 286 489 225 297 489 minecraft:light_gray_concrete
setblock 225 286 490 minecraft:pearlescent_froglight
fill 225 286 491 225 297 491 minecraft:light_gray_concrete
setblock 225 286 492 minecraft:pearlescent_froglight
fill 225 286 493 225 297 493 minecraft:light_gray_concrete
setblock 225 286 494 minecraft:pearlescent_froglight
fill 225 286 495 225 297 495 minecraft:light_gray_concrete
setblock 225 286 496 minecraft:pearlescent_froglight
fill 225 286 497 225 297 497 minecraft:light_gray_concrete
setblock 225 286 498 minecraft:pearlescent_froglight
fill 226 286 486 226 297 486 minecraft:light_gray_concrete
setblock 226 286 487 minecraft:pearlescent_froglight
fill 226 286 488 226 297 488 minecraft:light_gray_concrete
setblock 226 286 489 minecraft:pearlescent_froglight
fill 226 286 490 226 297 490 minecraft:light_gray_concrete
setblock 226 286 491 minecraft:pearlescent_froglight
fill 226 286 492 226 297 492 minecraft:light_gray_concrete
setblock 226 286 493 minecraft:pearlescent_froglight
fill 226 286 494 226 297 494 minecraft:light_gray_concrete
setblock 226 286 495 minecraft:pearlescent_froglight
fill 226 286 496 226 297 496 minecraft:light_gray_concrete
setblock 226 286 497 minecraft:pearlescent_froglight
fill 226 286 498 226 297 498 minecraft:light_gray_concrete
setblock 227 286 486 minecraft:pearlescent_froglight
fill 227 286 487 227 297 487 minecraft:light_gray_concrete
setblock 227 286 488 minecraft:pearlescent_froglight
fill 227 286 489 227 297 489 minecraft:light_gray_concrete
setblock 227 286 490 minecraft:pearlescent_froglight
fill 227 286 491 227 297 491 minecraft:light_gray_concrete
setblock 227 286 492 minecraft:pearlescent_froglight
fill 227 286 493 227 297 493 minecraft:light_gray_concrete
setblock 227 286 494 minecraft:pearlescent_froglight
fill 227 286 495 227 297 495 minecraft:light_gray_concrete
setblock 227 286 496 minecraft:pearlescent_froglight
fill 227 286 497 227 297 497 minecraft:light_gray_concrete
setblock 227 286 498 minecraft:pearlescent_froglight
fill 228 286 486 228 297 486 minecraft:light_gray_concrete
setblock 228 286 487 minecraft:pearlescent_froglight
fill 228 286 488 228 297 488 minecraft:light_gray_concrete
setblock 228 286 489 minecraft:pearlescent_froglight
fill 228 286 490 228 297 490 minecraft:light_gray_concrete
setblock 228 286 491 minecraft:pearlescent_froglight
fill 228 286 492 228 297 492 minecraft:light_gray_concrete
setblock 228 286 493 minecraft:pearlescent_froglight
fill 228 286 494 228 297 494 minecraft:light_gray_concrete
setblock 228 286 495 minecraft:pearlescent_froglight
fill 228 286 496 228 297 496 minecraft:light_gray_concrete
setblock 228 286 497 minecraft:pearlescent_froglight
fill 228 286 498 228 297 498 minecraft:light_gray_concrete
setblock 229 286 486 minecraft:pearlescent_froglight
fill 229 286 487 229 297 487 minecraft:light_gray_concrete
setblock 229 286 488 minecraft:pearlescent_froglight
fill 229 286 489 229 300 489 minecraft:light_gray_concrete
setblock 229 286 490 minecraft:pearlescent_froglight
fill 229 286 491 229 297 491 minecraft:light_gray_concrete
setblock 229 286 492 minecraft:pearlescent_froglight
fill 229 286 493 229 297 493 minecraft:light_gray_concrete
setblock 229 286 494 minecraft:pearlescent_froglight
fill 229 286 495 229 297 495 minecraft:light_gray_concrete
setblock 229 286 496 minecraft:pearlescent_froglight
fill 229 286 497 229 300 497 minecraft:light_gray_concrete
setblock 229 286 498 minecraft:pearlescent_froglight
fill 199 287 464 199 288 464 minecraft:light_gray_concrete
fill 199 287 466 199 288 466 minecraft:light_gray_concrete
fill 199 287 468 199 288 468 minecraft:light_gray_concrete
fill 200 287 465 200 288 465 minecraft:light_gray_concrete
fill 200 287 467 200 288 467 minecraft:light_gray_concrete
fill 201 287 464 201 288 464 minecraft:light_gray_concrete
fill 201 287 466 201 288 466 minecraft:light_gray_concrete
fill 201 287 468 201 288 468 minecraft:light_gray_concrete
fill 202 287 465 202 288 465 minecraft:light_gray_concrete
fill 202 287 467 202 288 467 minecraft:light_gray_concrete
fill 203 287 464 203 288 464 minecraft:light_gray_concrete
fill 203 287 466 203 288 466 minecraft:light_gray_concrete
fill 203 287 468 203 288 468 minecraft:light_gray_concrete
fill 204 287 465 204 288 465 minecraft:light_gray_concrete
fill 204 287 467 204 288 467 minecraft:light_gray_concrete
fill 204 287 495 204 288 495 minecraft:light_gray_concrete
fill 204 287 497 204 288 497 minecraft:light_gray_concrete
fill 204 287 499 204 288 499 minecraft:light_gray_concrete
fill 204 287 501 204 288 501 minecraft:light_gray_concrete
fill 204 287 503 204 288 503 minecraft:light_gray_concrete
fill 205 287 464 205 288 464 minecraft:light_gray_concrete
fill 205 287 466 205 288 466 minecraft:light_gray_concrete
fill 205 287 468 205 288 468 minecraft:light_gray_concrete
fill 205 287 496 205 288 496 minecraft:light_gray_concrete
fill 205 287 498 205 288 498 minecraft:light_gray_concrete
fill 205 287 500 205 288 500 minecraft:light_gray_concrete
fill 205 287 502 205 288 502 minecraft:light_gray_concrete
fill 205 287 504 205 288 504 minecraft:light_gray_concrete
fill 206 287 495 206 288 495 minecraft:light_gray_concrete
fill 206 287 497 206 288 497 minecraft:light_gray_concrete
fill 206 287 499 206 288 499 minecraft:light_gray_concrete
fill 206 287 501 206 288 501 minecraft:light_gray_concrete
fill 206 287 503 206 288 503 minecraft:light_gray_concrete
fill 207 287 496 207 288 496 minecraft:light_gray_concrete
fill 207 287 498 207 288 498 minecraft:light_gray_concrete
fill 207 287 500 207 288 500 minecraft:light_gray_concrete
fill 207 287 502 207 288 502 minecraft:light_gray_concrete
fill 207 287 504 207 288 504 minecraft:light_gray_concrete
fill 208 287 495 208 288 495 minecraft:light_gray_concrete
fill 208 287 497 208 288 497 minecraft:light_gray_concrete
fill 208 287 499 208 288 499 minecraft:light_gray_concrete
fill 208 287 501 208 288 501 minecraft:light_gray_concrete
fill 208 287 503 208 288 503 minecraft:light_gray_concrete
fill 209 287 496 209 288 496 minecraft:light_gray_concrete
fill 209 287 498 209 288 498 minecraft:light_gray_concrete
fill 209 287 500 209 288 500 minecraft:light_gray_concrete
fill 209 287 502 209 288 502 minecraft:light_gray_concrete
fill 209 287 504 209 288 504 minecraft:light_gray_concrete
fill 210 287 495 210 288 495 minecraft:light_gray_concrete
fill 210 287 497 210 288 497 minecraft:light_gray_concrete
fill 210 287 499 210 288 499 minecraft:light_gray_concrete
fill 210 287 501 210 288 501 minecraft:light_gray_concrete
fill 210 287 503 210 288 503 minecraft:light_gray_concrete
fill 219 287 486 219 288 486 minecraft:light_gray_concrete
fill 219 287 488 219 288 488 minecraft:light_gray_concrete
fill 219 287 490 219 288 490 minecraft:light_gray_concrete
fill 219 287 492 219 288 492 minecraft:light_gray_concrete
fill 219 287 494 219 288 494 minecraft:light_gray_concrete
fill 219 287 496 219 288 496 minecraft:light_gray_concrete
fill 219 287 498 219 288 498 minecraft:light_gray_concrete
fill 220 287 487 220 288 487 minecraft:light_gray_concrete
fill 220 287 489 220 288 489 minecraft:light_gray_concrete
fill 220 287 491 220 288 491 minecraft:light_gray_concrete
fill 220 287 493 220 288 493 minecraft:light_gray_concrete
fill 220 287 495 220 288 495 minecraft:light_gray_concrete
fill 220 287 497 220 288 497 minecraft:light_gray_concrete
fill 221 287 486 221 288 486 minecraft:light_gray_concrete
fill 221 287 488 221 288 488 minecraft:light_gray_concrete
fill 221 287 490 221 288 490 minecraft:light_gray_concrete
fill 221 287 492 221 288 492 minecraft:light_gray_concrete
fill 221 287 494 221 288 494 minecraft:light_gray_concrete
fill 221 287 496 221 288 496 minecraft:light_gray_concrete
fill 221 287 498 221 288 498 minecraft:light_gray_concrete
fill 222 287 487 222 288 487 minecraft:light_gray_concrete
fill 222 287 489 222 288 489 minecraft:light_gray_concrete
fill 222 287 491 222 288 491 minecraft:light_gray_concrete
fill 222 287 493 222 288 493 minecraft:light_gray_concrete
fill 222 287 495 222 288 495 minecraft:light_gray_concrete
fill 222 287 497 222 288 497 minecraft:light_gray_concrete
fill 223 287 486 223 288 486 minecraft:light_gray_concrete
fill 223 287 488 223 288 488 minecraft:light_gray_concrete
fill 223 287 490 223 288 490 minecraft:light_gray_concrete
fill 223 287 492 223 288 492 minecraft:light_gray_concrete
fill 223 287 494 223 288 494 minecraft:light_gray_concrete
fill 223 287 496 223 288 496 minecraft:light_gray_concrete
fill 223 287 498 223 288 498 minecraft:light_gray_concrete
fill 224 287 487 224 288 487 minecraft:light_gray_concrete
fill 224 287 489 224 288 489 minecraft:light_gray_concrete
fill 224 287 491 224 288 491 minecraft:light_gray_concrete
fill 224 287 493 224 288 493 minecraft:light_gray_concrete
fill 224 287 495 224 288 495 minecraft:light_gray_concrete
fill 224 287 497 224 288 497 minecraft:light_gray_concrete
fill 225 287 486 225 288 486 minecraft:light_gray_concrete
fill 225 287 488 225 288 488 minecraft:light_gray_concrete
fill 225 287 490 225 288 490 minecraft:light_gray_concrete
fill 225 287 492 225 288 492 minecraft:light_gray_concrete
fill 225 287 494 225 288 494 minecraft:light_gray_concrete
fill 225 287 496 225 288 496 minecraft:light_gray_concrete
fill 225 287 498 225 288 498 minecraft:light_gray_concrete
fill 226 287 487 226 288 487 minecraft:light_gray_concrete
fill 226 287 489 226 288 489 minecraft:light_gray_concrete
fill 226 287 491 226 288 491 minecraft:light_gray_concrete
fill 226 287 493 226 288 493 minecraft:light_gray_concrete
fill 226 287 495 226 288 495 minecraft:light_gray_concrete
fill 226 287 497 226 288 497 minecraft:light_gray_concrete
fill 227 287 486 227 288 486 minecraft:light_gray_concrete
fill 227 287 488 227 288 488 minecraft:light_gray_concrete
fill 227 287 490 227 288 490 minecraft:light_gray_concrete
fill 227 287 492 227 288 492 minecraft:light_gray_concrete
fill 227 287 494 227 288 494 minecraft:light_gray_concrete
fill 227 287 496 227 288 496 minecraft:light_gray_concrete
fill 227 287 498 227 288 498 minecraft:light_gray_concrete
fill 228 287 487 228 288 487 minecraft:light_gray_concrete
fill 228 287 489 228 288 489 minecraft:light_gray_concrete
fill 228 287 491 228 288 491 minecraft:light_gray_concrete
fill 228 287 493 228 288 493 minecraft:light_gray_concrete
fill 228 287 495 228 288 495 minecraft:light_gray_concrete
fill 228 287 497 228 288 497 minecraft:light_gray_concrete
fill 229 287 486 229 288 486 minecraft:light_gray_concrete
fill 229 287 488 229 288 488 minecraft:light_gray_concrete
fill 229 287 490 229 288 490 minecraft:light_gray_concrete
fill 229 287 492 229 288 492 minecraft:light_gray_concrete
fill 229 287 494 229 288 494 minecraft:light_gray_concrete
fill 229 287 496 229 288 496 minecraft:light_gray_concrete
fill 229 287 498 229 288 498 minecraft:light_gray_concrete
setblock 199 289 464 minecraft:pearlescent_froglight
setblock 199 289 466 minecraft:pearlescent_froglight
setblock 199 289 468 minecraft:pearlescent_froglight
setblock 200 289 465 minecraft:pearlescent_froglight
setblock 200 289 467 minecraft:pearlescent_froglight
setblock 201 289 464 minecraft:pearlescent_froglight
setblock 201 289 466 minecraft:pearlescent_froglight
setblock 201 289 468 minecraft:pearlescent_froglight
setblock 202 289 465 minecraft:pearlescent_froglight
setblock 202 289 467 minecraft:pearlescent_froglight
setblock 203 289 464 minecraft:pearlescent_froglight
setblock 203 289 466 minecraft:pearlescent_froglight
setblock 203 289 468 minecraft:pearlescent_froglight
setblock 204 289 465 minecraft:pearlescent_froglight
setblock 204 289 467 minecraft:pearlescent_froglight
setblock 204 289 495 minecraft:pearlescent_froglight
setblock 204 289 497 minecraft:pearlescent_froglight
setblock 204 289 499 minecraft:pearlescent_froglight
setblock 204 289 501 minecraft:pearlescent_froglight
setblock 204 289 503 minecraft:pearlescent_froglight
setblock 205 289 464 minecraft:pearlescent_froglight
setblock 205 289 466 minecraft:pearlescent_froglight
setblock 205 289 468 minecraft:pearlescent_froglight
setblock 205 289 496 minecraft:pearlescent_froglight
setblock 205 289 498 minecraft:pearlescent_froglight
setblock 205 289 500 minecraft:pearlescent_froglight
setblock 205 289 502 minecraft:pearlescent_froglight
setblock 205 289 504 minecraft:pearlescent_froglight
setblock 206 289 495 minecraft:pearlescent_froglight
setblock 206 289 497 minecraft:pearlescent_froglight
setblock 206 289 499 minecraft:pearlescent_froglight
setblock 206 289 501 minecraft:pearlescent_froglight
setblock 206 289 503 minecraft:pearlescent_froglight
setblock 207 289 496 minecraft:pearlescent_froglight
setblock 207 289 498 minecraft:pearlescent_froglight
setblock 207 289 500 minecraft:pearlescent_froglight
setblock 207 289 502 minecraft:pearlescent_froglight
setblock 207 289 504 minecraft:pearlescent_froglight
setblock 208 289 495 minecraft:pearlescent_froglight
setblock 208 289 497 minecraft:pearlescent_froglight
setblock 208 289 499 minecraft:pearlescent_froglight
setblock 208 289 501 minecraft:pearlescent_froglight
setblock 208 289 503 minecraft:pearlescent_froglight
setblock 209 289 496 minecraft:pearlescent_froglight
setblock 209 289 498 minecraft:pearlescent_froglight
setblock 209 289 500 minecraft:pearlescent_froglight
setblock 209 289 502 minecraft:pearlescent_froglight
setblock 209 289 504 minecraft:pearlescent_froglight
setblock 210 289 495 minecraft:pearlescent_froglight
setblock 210 289 497 minecraft:pearlescent_froglight
setblock 210 289 499 minecraft:pearlescent_froglight
setblock 210 289 501 minecraft:pearlescent_froglight
setblock 210 289 503 minecraft:pearlescent_froglight
setblock 219 289 486 minecraft:pearlescent_froglight
setblock 219 289 488 minecraft:pearlescent_froglight
setblock 219 289 490 minecraft:pearlescent_froglight
setblock 219 289 492 minecraft:pearlescent_froglight
setblock 219 289 494 minecraft:pearlescent_froglight
setblock 219 289 496 minecraft:pearlescent_froglight
setblock 219 289 498 minecraft:pearlescent_froglight
setblock 220 289 487 minecraft:pearlescent_froglight
setblock 220 289 489 minecraft:pearlescent_froglight
setblock 220 289 491 minecraft:pearlescent_froglight
setblock 220 289 493 minecraft:pearlescent_froglight
setblock 220 289 495 minecraft:pearlescent_froglight
setblock 220 289 497 minecraft:pearlescent_froglight
setblock 221 289 486 minecraft:pearlescent_froglight
setblock 221 289 488 minecraft:pearlescent_froglight
setblock 221 289 490 minecraft:pearlescent_froglight
setblock 221 289 492 minecraft:pearlescent_froglight
setblock 221 289 494 minecraft:pearlescent_froglight
setblock 221 289 496 minecraft:pearlescent_froglight
setblock 221 289 498 minecraft:pearlescent_froglight
setblock 222 289 487 minecraft:pearlescent_froglight
setblock 222 289 489 minecraft:pearlescent_froglight
setblock 222 289 491 minecraft:pearlescent_froglight
setblock 222 289 493 minecraft:pearlescent_froglight
setblock 222 289 495 minecraft:pearlescent_froglight
setblock 222 289 497 minecraft:pearlescent_froglight
setblock 223 289 486 minecraft:pearlescent_froglight
setblock 223 289 488 minecraft:pearlescent_froglight
setblock 223 289 490 minecraft:pearlescent_froglight
setblock 223 289 492 minecraft:pearlescent_froglight
setblock 223 289 494 minecraft:pearlescent_froglight
setblock 223 289 496 minecraft:pearlescent_froglight
setblock 223 289 498 minecraft:pearlescent_froglight
setblock 224 289 487 minecraft:pearlescent_froglight
setblock 224 289 489 minecraft:pearlescent_froglight
setblock 224 289 491 minecraft:pearlescent_froglight
setblock 224 289 493 minecraft:pearlescent_froglight
setblock 224 289 495 minecraft:pearlescent_froglight
setblock 224 289 497 minecraft:pearlescent_froglight
setblock 225 289 486 minecraft:pearlescent_froglight
setblock 225 289 488 minecraft:pearlescent_froglight
setblock 225 289 490 minecraft:pearlescent_froglight
setblock 225 289 492 minecraft:pearlescent_froglight
setblock 225 289 494 minecraft:pearlescent_froglight
setblock 225 289 496 minecraft:pearlescent_froglight
setblock 225 289 498 minecraft:pearlescent_froglight
setblock 226 289 487 minecraft:pearlescent_froglight
setblock 226 289 489 minecraft:pearlescent_froglight
setblock 226 289 491 minecraft:pearlescent_froglight
setblock 226 289 493 minecraft:pearlescent_froglight
setblock 226 289 495 minecraft:pearlescent_froglight
setblock 226 289 497 minecraft:pearlescent_froglight
setblock 227 289 486 minecraft:pearlescent_froglight
setblock 227 289 488 minecraft:pearlescent_froglight
setblock 227 289 490 minecraft:pearlescent_froglight
setblock 227 289 492 minecraft:pearlescent_froglight
setblock 227 289 494 minecraft:pearlescent_froglight
setblock 227 289 496 minecraft:pearlescent_froglight
setblock 227 289 498 minecraft:pearlescent_froglight
setblock 228 289 487 minecraft:pearlescent_froglight
setblock 228 289 489 minecraft:pearlescent_froglight
setblock 228 289 491 minecraft:pearlescent_froglight
setblock 228 289 493 minecraft:pearlescent_froglight
setblock 228 289 495 minecraft:pearlescent_froglight
setblock 228 289 497 minecraft:pearlescent_froglight
setblock 229 289 486 minecraft:pearlescent_froglight
setblock 229 289 488 minecraft:pearlescent_froglight
setblock 229 289 490 minecraft:pearlescent_froglight
setblock 229 289 492 minecraft:pearlescent_froglight
setblock 229 289 494 minecraft:pearlescent_froglight
setblock 229 289 496 minecraft:pearlescent_froglight
setblock 229 289 498 minecraft:pearlescent_froglight
fill 188 290 468 188 297 468 minecraft:white_terracotta
fill 188 290 476 188 297 476 minecraft:white_terracotta
fill 188 290 484 188 297 484 minecraft:white_terracotta
fill 188 290 492 188 297 492 minecraft:white_terracotta
fill 188 290 500 188 297 500 minecraft:white_terracotta
fill 191 290 505 191 297 505 minecraft:white_terracotta
fill 195 290 463 195 297 463 minecraft:white_terracotta
fill 199 290 464 199 291 464 minecraft:light_gray_concrete
fill 199 290 466 199 291 466 minecraft:light_gray_concrete
fill 199 290 468 199 291 468 minecraft:light_gray_concrete
fill 199 290 505 199 297 505 minecraft:white_terracotta
fill 200 290 465 200 291 465 minecraft:light_gray_concrete
fill 200 290 467 200 291 467 minecraft:light_gray_concrete
fill 201 290 464 201 291 464 minecraft:light_gray_concrete
fill 201 290 466 201 291 466 minecraft:light_gray_concrete
fill 201 290 468 201 291 468 minecraft:light_gray_concrete
fill 202 290 465 202 291 465 minecraft:light_gray_concrete
schedule function dropper:buildpart/112_3 1t
