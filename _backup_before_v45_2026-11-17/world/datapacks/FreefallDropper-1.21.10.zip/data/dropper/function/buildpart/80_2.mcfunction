setblock 415 107 360 minecraft:polished_deepslate
setblock 416 107 334 minecraft:polished_deepslate
fill 416 107 335 416 109 335 minecraft:gray_concrete
setblock 416 107 339 minecraft:polished_deepslate
fill 416 107 340 416 110 340 minecraft:gray_concrete
setblock 416 107 344 minecraft:polished_deepslate
fill 416 107 345 416 110 345 minecraft:gray_concrete
setblock 416 107 354 minecraft:polished_deepslate
fill 416 107 355 416 108 355 minecraft:gray_concrete
setblock 416 107 359 minecraft:polished_deepslate
fill 416 107 360 416 109 360 minecraft:gray_concrete
setblock 417 107 333 minecraft:polished_deepslate
fill 417 107 334 417 110 334 minecraft:gray_concrete
setblock 417 107 338 minecraft:polished_deepslate
fill 417 107 339 417 110 339 minecraft:gray_concrete
setblock 417 107 343 minecraft:polished_deepslate
fill 417 107 344 417 110 344 minecraft:gray_concrete
setblock 417 107 348 minecraft:polished_deepslate
fill 417 107 349 417 109 349 minecraft:gray_concrete
setblock 417 107 353 minecraft:polished_deepslate
fill 417 107 354 417 109 354 minecraft:gray_concrete
setblock 417 107 358 minecraft:polished_deepslate
fill 417 107 359 417 110 359 minecraft:gray_concrete
setblock 417 107 363 minecraft:polished_deepslate
setblock 377 108 332 minecraft:polished_deepslate
fill 377 108 333 377 108 336 minecraft:gray_concrete
setblock 377 108 337 minecraft:polished_deepslate
fill 377 108 338 377 111 338 minecraft:gray_concrete
setblock 377 108 342 minecraft:polished_deepslate
fill 377 108 343 377 111 343 minecraft:gray_concrete
setblock 377 108 357 minecraft:polished_deepslate
setblock 377 108 358 minecraft:gray_concrete
setblock 378 108 336 minecraft:polished_deepslate
fill 378 108 337 378 111 337 minecraft:gray_concrete
setblock 378 108 341 minecraft:polished_deepslate
fill 378 108 342 378 111 342 minecraft:gray_concrete
setblock 379 108 336 minecraft:gray_concrete
setblock 379 108 339 minecraft:gray_concrete
setblock 381 108 323 minecraft:polished_deepslate
setblock 381 108 363 minecraft:polished_deepslate
fill 382 108 323 382 111 323 minecraft:gray_concrete
fill 382 108 363 385 108 363 minecraft:gray_concrete
setblock 384 108 324 minecraft:gray_concrete
fill 384 108 362 386 108 362 minecraft:gray_concrete
setblock 385 108 323 minecraft:gray_concrete
setblock 385 108 324 minecraft:polished_deepslate
setblock 386 108 322 minecraft:light_blue_stained_glass
setblock 386 108 323 minecraft:polished_deepslate
fill 386 108 324 386 111 324 minecraft:gray_concrete
fill 386 108 361 387 108 361 minecraft:gray_concrete
setblock 386 108 363 minecraft:polished_deepslate
fill 386 108 364 386 123 364 minecraft:black_concrete
fill 387 108 323 387 111 323 minecraft:gray_concrete
fill 387 108 325 388 108 325 minecraft:gray_concrete
setblock 387 108 362 minecraft:polished_deepslate
fill 387 108 363 387 111 363 minecraft:gray_concrete
setblock 388 108 361 minecraft:polished_deepslate
fill 388 108 362 388 111 362 minecraft:gray_concrete
setblock 389 108 325 minecraft:polished_deepslate
setblock 389 108 360 minecraft:polished_deepslate
fill 389 108 361 392 108 361 minecraft:gray_concrete
setblock 390 108 324 minecraft:polished_deepslate
fill 390 108 325 390 111 325 minecraft:gray_concrete
fill 390 108 360 390 110 360 minecraft:gray_concrete
setblock 391 108 323 minecraft:polished_deepslate
fill 391 108 324 391 111 324 minecraft:gray_concrete
setblock 391 108 363 minecraft:polished_deepslate
fill 392 108 323 392 111 323 minecraft:gray_concrete
setblock 392 108 362 minecraft:polished_deepslate
fill 392 108 363 392 111 363 minecraft:gray_concrete
setblock 393 108 360 minecraft:gray_concrete
setblock 393 108 361 minecraft:polished_deepslate
fill 393 108 362 393 111 362 minecraft:gray_concrete
fill 394 108 361 394 111 361 minecraft:gray_concrete
setblock 395 108 324 minecraft:polished_deepslate
setblock 396 108 323 minecraft:polished_deepslate
setblock 396 108 363 minecraft:polished_deepslate
fill 397 108 323 397 111 323 minecraft:gray_concrete
setblock 397 108 362 minecraft:polished_deepslate
fill 397 108 363 400 108 363 minecraft:gray_concrete
setblock 398 108 361 minecraft:polished_deepslate
fill 398 108 362 401 108 362 minecraft:gray_concrete
fill 399 108 323 400 108 323 minecraft:gray_concrete
fill 399 108 361 402 108 361 minecraft:gray_concrete
setblock 401 108 323 minecraft:polished_deepslate
setblock 401 108 363 minecraft:polished_deepslate
fill 402 108 323 405 108 323 minecraft:gray_concrete
setblock 402 108 362 minecraft:polished_deepslate
fill 402 108 363 402 111 363 minecraft:gray_concrete
setblock 403 108 361 minecraft:polished_deepslate
fill 403 108 362 406 108 362 minecraft:gray_concrete
setblock 404 108 360 minecraft:polished_deepslate
fill 404 108 361 407 108 361 minecraft:gray_concrete
fill 405 108 360 408 108 360 minecraft:gray_concrete
setblock 406 108 323 minecraft:polished_deepslate
setblock 406 108 363 minecraft:polished_deepslate
fill 407 108 323 407 111 323 minecraft:gray_concrete
fill 407 108 359 409 108 359 minecraft:gray_concrete
setblock 407 108 362 minecraft:polished_deepslate
fill 407 108 363 407 111 363 minecraft:gray_concrete
setblock 408 108 361 minecraft:polished_deepslate
fill 408 108 362 408 111 362 minecraft:gray_concrete
setblock 409 108 360 minecraft:polished_deepslate
fill 409 108 361 409 111 361 minecraft:gray_concrete
setblock 410 108 323 minecraft:gray_concrete
setblock 410 108 359 minecraft:polished_deepslate
fill 410 108 360 410 110 360 minecraft:gray_concrete
setblock 411 108 323 minecraft:polished_deepslate
setblock 411 108 363 minecraft:polished_deepslate
fill 412 108 323 412 111 323 minecraft:gray_concrete
fill 412 108 360 412 109 360 minecraft:gray_concrete
setblock 412 108 362 minecraft:polished_deepslate
fill 412 108 363 412 111 363 minecraft:gray_concrete
setblock 413 108 361 minecraft:polished_deepslate
fill 413 108 362 413 111 362 minecraft:gray_concrete
setblock 414 108 361 minecraft:gray_concrete
setblock 415 108 339 minecraft:polished_deepslate
fill 415 108 340 415 111 340 minecraft:gray_concrete
setblock 415 108 359 minecraft:polished_deepslate
setblock 416 108 334 minecraft:gray_concrete
setblock 416 108 338 minecraft:polished_deepslate
fill 416 108 339 416 111 339 minecraft:gray_concrete
setblock 416 108 342 minecraft:gray_concrete
setblock 416 108 343 minecraft:polished_deepslate
fill 416 108 344 416 111 344 minecraft:gray_concrete
setblock 416 108 353 minecraft:polished_deepslate
setblock 416 108 354 minecraft:gray_concrete
setblock 416 108 358 minecraft:polished_deepslate
fill 416 108 359 416 109 359 minecraft:gray_concrete
setblock 416 108 363 minecraft:polished_deepslate
setblock 417 108 332 minecraft:polished_deepslate
fill 417 108 333 417 109 333 minecraft:gray_concrete
setblock 417 108 337 minecraft:polished_deepslate
fill 417 108 338 417 111 338 minecraft:gray_concrete
setblock 417 108 342 minecraft:polished_deepslate
fill 417 108 343 417 111 343 minecraft:gray_concrete
setblock 417 108 347 minecraft:polished_deepslate
fill 417 108 348 417 110 348 minecraft:gray_concrete
setblock 417 108 352 minecraft:polished_deepslate
fill 417 108 353 417 109 353 minecraft:gray_concrete
setblock 417 108 357 minecraft:polished_deepslate
fill 417 108 358 417 110 358 minecraft:gray_concrete
setblock 417 108 362 minecraft:polished_deepslate
fill 417 108 363 417 110 363 minecraft:gray_concrete
setblock 418 108 362 minecraft:light_blue_stained_glass
fill 376 109 322 376 119 322 minecraft:black_concrete
setblock 376 109 323 minecraft:light_blue_stained_glass
fill 376 109 324 376 110 325 minecraft:black_concrete
setblock 377 109 331 minecraft:polished_deepslate
fill 377 109 332 377 109 335 minecraft:gray_concrete
setblock 377 109 336 minecraft:polished_deepslate
fill 377 109 337 377 112 337 minecraft:gray_concrete
setblock 377 109 341 minecraft:polished_deepslate
fill 377 109 342 377 112 342 minecraft:gray_concrete
setblock 377 109 361 minecraft:polished_deepslate
setblock 377 109 362 minecraft:gray_concrete
setblock 378 109 335 minecraft:polished_deepslate
fill 378 109 336 378 111 336 minecraft:gray_concrete
setblock 378 109 340 minecraft:polished_deepslate
fill 378 109 341 378 112 341 minecraft:gray_concrete
setblock 379 109 339 minecraft:polished_deepslate
setblock 380 109 323 minecraft:polished_deepslate
setblock 380 109 363 minecraft:polished_deepslate
fill 381 109 323 381 112 323 minecraft:gray_concrete
fill 381 109 363 384 109 363 minecraft:gray_concrete
setblock 383 109 324 minecraft:gray_concrete
fill 383 109 362 385 109 362 minecraft:gray_concrete
setblock 384 109 324 minecraft:polished_deepslate
setblock 385 109 323 minecraft:polished_deepslate
fill 385 109 324 385 112 324 minecraft:gray_concrete
fill 385 109 361 386 109 361 minecraft:gray_concrete
setblock 385 109 363 minecraft:polished_deepslate
fill 386 109 322 386 120 322 minecraft:black_concrete
fill 386 109 323 386 112 323 minecraft:gray_concrete
fill 386 109 325 387 109 325 minecraft:gray_concrete
setblock 386 109 362 minecraft:polished_deepslate
fill 386 109 363 386 112 363 minecraft:gray_concrete
setblock 387 109 361 minecraft:polished_deepslate
fill 387 109 362 387 112 362 minecraft:gray_concrete
setblock 388 109 325 minecraft:polished_deepslate
setblock 388 109 360 minecraft:polished_deepslate
fill 388 109 361 391 109 361 minecraft:gray_concrete
setblock 389 109 324 minecraft:polished_deepslate
fill 389 109 325 389 112 325 minecraft:gray_concrete
fill 389 109 360 389 110 360 minecraft:gray_concrete
setblock 390 109 323 minecraft:polished_deepslate
fill 390 109 324 390 112 324 minecraft:gray_concrete
setblock 390 109 363 minecraft:polished_deepslate
fill 391 109 323 391 112 323 minecraft:gray_concrete
setblock 391 109 362 minecraft:polished_deepslate
fill 391 109 363 391 112 363 minecraft:gray_concrete
setblock 392 109 361 minecraft:polished_deepslate
fill 392 109 362 392 112 362 minecraft:gray_concrete
fill 393 109 361 393 112 361 minecraft:gray_concrete
setblock 394 109 324 minecraft:polished_deepslate
setblock 395 109 323 minecraft:polished_deepslate
setblock 395 109 363 minecraft:polished_deepslate
fill 396 109 323 396 112 323 minecraft:gray_concrete
setblock 396 109 362 minecraft:polished_deepslate
fill 396 109 363 399 109 363 minecraft:gray_concrete
setblock 397 109 361 minecraft:polished_deepslate
fill 397 109 362 400 109 362 minecraft:gray_concrete
fill 398 109 361 401 109 361 minecraft:gray_concrete
setblock 399 109 323 minecraft:gray_concrete
setblock 400 109 323 minecraft:polished_deepslate
setblock 400 109 363 minecraft:polished_deepslate
fill 401 109 323 404 109 323 minecraft:gray_concrete
setblock 401 109 362 minecraft:polished_deepslate
fill 401 109 363 401 112 363 minecraft:gray_concrete
setblock 402 109 361 minecraft:polished_deepslate
fill 402 109 362 405 109 362 minecraft:gray_concrete
setblock 403 109 360 minecraft:polished_deepslate
fill 403 109 361 406 109 361 minecraft:gray_concrete
fill 404 109 360 407 109 360 minecraft:gray_concrete
setblock 405 109 323 minecraft:polished_deepslate
setblock 405 109 363 minecraft:polished_deepslate
fill 406 109 323 406 112 323 minecraft:gray_concrete
setblock 406 109 362 minecraft:polished_deepslate
fill 406 109 363 406 112 363 minecraft:gray_concrete
setblock 407 109 361 minecraft:polished_deepslate
fill 407 109 362 407 112 362 minecraft:gray_concrete
setblock 408 109 359 minecraft:gray_concrete
setblock 408 109 360 minecraft:polished_deepslate
fill 408 109 361 408 112 361 minecraft:gray_concrete
fill 409 109 360 409 111 360 minecraft:gray_concrete
setblock 410 109 323 minecraft:polished_deepslate
setblock 410 109 363 minecraft:polished_deepslate
fill 411 109 323 411 112 323 minecraft:gray_concrete
setblock 411 109 362 minecraft:polished_deepslate
fill 411 109 363 411 112 363 minecraft:gray_concrete
setblock 412 109 361 minecraft:polished_deepslate
fill 412 109 362 412 112 362 minecraft:gray_concrete
fill 413 109 361 413 110 361 minecraft:gray_concrete
fill 413 109 364 414 120 364 minecraft:black_concrete
setblock 415 109 338 minecraft:polished_deepslate
fill 415 109 339 415 110 339 minecraft:gray_concrete
setblock 415 109 343 minecraft:polished_deepslate
setblock 415 109 363 minecraft:polished_deepslate
setblock 415 109 364 minecraft:light_blue_stained_glass
setblock 416 109 337 minecraft:polished_deepslate
fill 416 109 338 416 112 338 minecraft:gray_concrete
setblock 416 109 342 minecraft:polished_deepslate
fill 416 109 343 416 112 343 minecraft:gray_concrete
setblock 416 109 357 minecraft:polished_deepslate
setblock 416 109 358 minecraft:gray_concrete
fill 416 109 363 416 111 363 minecraft:gray_concrete
fill 416 109 364 416 122 364 minecraft:black_concrete
setblock 417 109 336 minecraft:polished_deepslate
fill 417 109 337 417 112 337 minecraft:gray_concrete
setblock 417 109 341 minecraft:polished_deepslate
fill 417 109 342 417 112 342 minecraft:gray_concrete
setblock 417 109 346 minecraft:polished_deepslate
fill 417 109 347 417 112 347 minecraft:gray_concrete
setblock 417 109 352 minecraft:gray_concrete
setblock 417 109 356 minecraft:polished_deepslate
fill 417 109 357 417 110 357 minecraft:gray_concrete
setblock 417 109 361 minecraft:polished_deepslate
fill 417 109 362 417 110 362 minecraft:gray_concrete
fill 418 109 341 418 109 345 minecraft:black_concrete
fill 418 109 346 418 109 347 minecraft:light_blue_stained_glass
fill 418 109 362 418 122 362 minecraft:black_concrete
fill 376 110 323 376 123 323 minecraft:black_concrete
fill 377 110 331 377 110 334 minecraft:gray_concrete
setblock 377 110 335 minecraft:polished_deepslate
fill 377 110 336 377 113 336 minecraft:gray_concrete
setblock 377 110 340 minecraft:polished_deepslate
fill 377 110 341 377 113 341 minecraft:gray_concrete
setblock 377 110 345 minecraft:polished_deepslate
setblock 378 110 334 minecraft:polished_deepslate
setblock 378 110 335 minecraft:gray_concrete
setblock 378 110 338 minecraft:gray_concrete
setblock 378 110 339 minecraft:polished_deepslate
fill 378 110 340 378 113 340 minecraft:gray_concrete
setblock 379 110 323 minecraft:polished_deepslate
setblock 379 110 325 minecraft:light[level=13]
setblock 379 110 332 minecraft:light[level=12]
setblock 379 110 333 minecraft:light[level=13]
setblock 379 110 339 minecraft:light[level=12]
setblock 379 110 341 minecraft:light[level=13]
setblock 379 110 346 minecraft:light[level=12]
setblock 379 110 349 minecraft:light[level=13]
setblock 379 110 353 minecraft:light[level=12]
setblock 379 110 357 minecraft:light[level=13]
setblock 379 110 360 minecraft:light[level=12]
fill 380 110 323 380 113 323 minecraft:gray_concrete
fill 380 110 363 383 110 363 minecraft:gray_concrete
setblock 382 110 324 minecraft:gray_concrete
fill 382 110 362 384 110 362 minecraft:gray_concrete
setblock 383 110 324 minecraft:polished_deepslate
setblock 384 110 323 minecraft:polished_deepslate
fill 384 110 324 384 113 324 minecraft:gray_concrete
setblock 384 110 363 minecraft:polished_deepslate
fill 385 110 323 385 113 323 minecraft:gray_concrete
fill 385 110 325 386 110 325 minecraft:gray_concrete
setblock 385 110 361 minecraft:gray_concrete
setblock 385 110 362 minecraft:polished_deepslate
fill 385 110 363 385 113 363 minecraft:gray_concrete
setblock 386 110 332 minecraft:light[level=12]
setblock 386 110 339 minecraft:light[level=12]
setblock 386 110 346 minecraft:light[level=12]
setblock 386 110 353 minecraft:light[level=12]
setblock 386 110 360 minecraft:light[level=12]
setblock 386 110 361 minecraft:polished_deepslate
fill 386 110 362 386 113 362 minecraft:gray_concrete
setblock 387 110 325 minecraft:polished_deepslate
setblock 387 110 333 minecraft:light[level=13]
setblock 387 110 341 minecraft:light[level=13]
setblock 387 110 349 minecraft:light[level=13]
setblock 387 110 357 minecraft:light[level=13]
fill 387 110 361 390 110 361 minecraft:gray_concrete
setblock 388 110 324 minecraft:polished_deepslate
fill 388 110 325 388 113 325 minecraft:gray_concrete
setblock 388 110 360 minecraft:gray_concrete
setblock 389 110 323 minecraft:polished_deepslate
fill 389 110 324 389 113 324 minecraft:gray_concrete
setblock 389 110 363 minecraft:polished_deepslate
fill 390 110 323 390 113 323 minecraft:gray_concrete
setblock 390 110 362 minecraft:polished_deepslate
fill 390 110 363 390 113 363 minecraft:gray_concrete
setblock 391 110 360 minecraft:gray_concrete
setblock 391 110 361 minecraft:polished_deepslate
fill 391 110 362 391 113 362 minecraft:gray_concrete
fill 392 110 361 392 112 361 minecraft:gray_concrete
setblock 393 110 324 minecraft:polished_deepslate
setblock 393 110 325 minecraft:light[level=12]
setblock 393 110 332 minecraft:light[level=12]
setblock 393 110 339 minecraft:light[level=12]
setblock 393 110 346 minecraft:light[level=12]
setblock 393 110 353 minecraft:light[level=12]
setblock 393 110 360 minecraft:light[level=12]
setblock 394 110 323 minecraft:polished_deepslate
setblock 394 110 324 minecraft:gray_concrete
setblock 394 110 363 minecraft:polished_deepslate
fill 395 110 323 395 113 323 minecraft:gray_concrete
setblock 395 110 325 minecraft:light[level=13]
setblock 395 110 333 minecraft:light[level=13]
setblock 395 110 341 minecraft:light[level=13]
setblock 395 110 349 minecraft:light[level=13]
setblock 395 110 357 minecraft:light[level=13]
setblock 395 110 362 minecraft:polished_deepslate
fill 395 110 363 398 110 363 minecraft:gray_concrete
setblock 396 110 361 minecraft:polished_deepslate
fill 396 110 362 399 110 362 minecraft:gray_concrete
fill 397 110 361 400 110 361 minecraft:gray_concrete
setblock 399 110 323 minecraft:polished_deepslate
setblock 399 110 363 minecraft:polished_deepslate
fill 400 110 323 403 110 323 minecraft:gray_concrete
setblock 400 110 325 minecraft:light[level=12]
setblock 400 110 332 minecraft:light[level=12]
setblock 400 110 339 minecraft:light[level=12]
setblock 400 110 346 minecraft:light[level=12]
setblock 400 110 353 minecraft:light[level=12]
setblock 400 110 360 minecraft:light[level=12]
setblock 400 110 362 minecraft:polished_deepslate
fill 400 110 363 400 113 363 minecraft:gray_concrete
setblock 401 110 361 minecraft:polished_deepslate
fill 401 110 362 404 110 362 minecraft:gray_concrete
fill 402 110 361 405 110 361 minecraft:gray_concrete
setblock 403 110 325 minecraft:light[level=13]
setblock 403 110 333 minecraft:light[level=13]
setblock 403 110 341 minecraft:light[level=13]
setblock 403 110 349 minecraft:light[level=13]
setblock 403 110 357 minecraft:light[level=13]
fill 403 110 360 406 110 360 minecraft:gray_concrete
setblock 404 110 323 minecraft:polished_deepslate
setblock 404 110 363 minecraft:polished_deepslate
fill 405 110 323 405 113 323 minecraft:gray_concrete
setblock 405 110 362 minecraft:polished_deepslate
fill 405 110 363 405 113 363 minecraft:gray_concrete
setblock 406 110 361 minecraft:polished_deepslate
fill 406 110 362 406 113 362 minecraft:gray_concrete
setblock 407 110 325 minecraft:light[level=12]
setblock 407 110 332 minecraft:light[level=12]
setblock 407 110 339 minecraft:light[level=12]
setblock 407 110 346 minecraft:light[level=12]
setblock 407 110 353 minecraft:light[level=12]
setblock 407 110 360 minecraft:polished_deepslate
fill 407 110 361 407 113 361 minecraft:gray_concrete
fill 408 110 360 408 111 360 minecraft:gray_concrete
setblock 409 110 323 minecraft:polished_deepslate
setblock 409 110 363 minecraft:polished_deepslate
fill 410 110 323 410 113 323 minecraft:gray_concrete
setblock 410 110 362 minecraft:polished_deepslate
fill 410 110 363 410 113 363 minecraft:gray_concrete
setblock 411 110 325 minecraft:light[level=13]
setblock 411 110 333 minecraft:light[level=13]
setblock 411 110 341 minecraft:light[level=13]
setblock 411 110 349 minecraft:light[level=13]
setblock 411 110 357 minecraft:light[level=13]
setblock 411 110 361 minecraft:polished_deepslate
fill 411 110 362 411 113 362 minecraft:gray_concrete
fill 412 110 361 412 111 361 minecraft:gray_concrete
setblock 414 110 325 minecraft:light[level=12]
setblock 414 110 332 minecraft:light[level=12]
setblock 414 110 339 minecraft:light[level=12]
setblock 414 110 346 minecraft:light[level=12]
setblock 414 110 353 minecraft:light[level=12]
setblock 414 110 360 minecraft:light[level=12]
setblock 414 110 363 minecraft:polished_deepslate
setblock 415 110 338 minecraft:gray_concrete
setblock 415 110 341 minecraft:gray_concrete
setblock 415 110 342 minecraft:polished_deepslate
fill 415 110 363 415 112 363 minecraft:gray_concrete
fill 415 110 364 415 116 364 minecraft:black_concrete
setblock 416 110 336 minecraft:polished_deepslate
fill 416 110 337 416 111 337 minecraft:gray_concrete
setblock 416 110 341 minecraft:polished_deepslate
fill 416 110 342 416 113 342 minecraft:gray_concrete
setblock 417 110 335 minecraft:polished_deepslate
fill 417 110 336 417 113 336 minecraft:gray_concrete
setblock 417 110 340 minecraft:polished_deepslate
fill 417 110 341 417 113 341 minecraft:gray_concrete
setblock 417 110 345 minecraft:polished_deepslate
fill 417 110 346 417 113 346 minecraft:gray_concrete
setblock 417 110 356 minecraft:gray_concrete
setblock 417 110 360 minecraft:polished_deepslate
fill 417 110 361 417 111 361 minecraft:gray_concrete
fill 418 110 341 418 122 341 minecraft:black_concrete
setblock 418 110 342 minecraft:light_blue_stained_glass
fill 418 110 343 418 120 347 minecraft:black_concrete
setblock 418 110 354 minecraft:light_blue_stained_glass
fill 418 110 355 418 116 361 minecraft:black_concrete
setblock 376 111 324 minecraft:light_blue_stained_glass
fill 376 111 325 376 116 325 minecraft:black_concrete
fill 377 111 332 377 111 333 minecraft:gray_concrete
setblock 377 111 334 minecraft:polished_deepslate
fill 377 111 335 377 113 335 minecraft:gray_concrete
setblock 377 111 339 minecraft:polished_deepslate
fill 377 111 340 377 114 340 minecraft:gray_concrete
setblock 377 111 344 minecraft:polished_deepslate
setblock 377 111 345 minecraft:gray_concrete
setblock 378 111 323 minecraft:polished_deepslate
setblock 378 111 338 minecraft:polished_deepslate
fill 378 111 339 378 112 339 minecraft:gray_concrete
fill 379 111 323 379 114 323 minecraft:gray_concrete
fill 379 111 334 379 114 334 minecraft:polished_deepslate
fill 379 111 363 382 111 363 minecraft:gray_concrete
fill 380 111 333 380 114 333 minecraft:polished_deepslate
fill 380 111 335 380 114 335 minecraft:polished_deepslate
fill 381 111 334 381 114 334 minecraft:polished_deepslate
setblock 382 111 324 minecraft:polished_deepslate
fill 382 111 362 383 111 362 minecraft:gray_concrete
setblock 383 111 323 minecraft:polished_deepslate
fill 383 111 324 383 114 324 minecraft:gray_concrete
setblock 383 111 363 minecraft:polished_deepslate
fill 384 111 323 384 114 323 minecraft:gray_concrete
setblock 384 111 362 minecraft:polished_deepslate
fill 384 111 363 384 114 363 minecraft:gray_concrete
setblock 385 111 325 minecraft:gray_concrete
setblock 385 111 361 minecraft:polished_deepslate
fill 385 111 362 385 114 362 minecraft:gray_concrete
setblock 386 111 325 minecraft:polished_deepslate
fill 386 111 361 389 111 361 minecraft:gray_concrete
setblock 387 111 324 minecraft:polished_deepslate
fill 387 111 325 387 114 325 minecraft:gray_concrete
setblock 388 111 323 minecraft:polished_deepslate
fill 388 111 324 388 114 324 minecraft:gray_concrete
setblock 388 111 363 minecraft:polished_deepslate
fill 389 111 323 389 114 323 minecraft:gray_concrete
setblock 389 111 362 minecraft:polished_deepslate
fill 389 111 363 389 114 363 minecraft:gray_concrete
setblock 390 111 361 minecraft:polished_deepslate
fill 390 111 362 390 114 362 minecraft:gray_concrete
fill 391 111 361 391 113 361 minecraft:gray_concrete
setblock 392 111 324 minecraft:polished_deepslate
setblock 393 111 323 minecraft:polished_deepslate
fill 393 111 324 393 112 324 minecraft:gray_concrete
setblock 393 111 363 minecraft:polished_deepslate
fill 394 111 323 394 114 323 minecraft:gray_concrete
setblock 394 111 362 minecraft:polished_deepslate
fill 394 111 363 397 111 363 minecraft:gray_concrete
setblock 395 111 361 minecraft:polished_deepslate
fill 395 111 362 398 111 362 minecraft:gray_concrete
setblock 398 111 323 minecraft:polished_deepslate
setblock 398 111 363 minecraft:polished_deepslate
fill 399 111 323 402 111 323 minecraft:gray_concrete
setblock 399 111 362 minecraft:polished_deepslate
fill 399 111 363 399 114 363 minecraft:gray_concrete
setblock 400 111 361 minecraft:polished_deepslate
fill 400 111 362 403 111 362 minecraft:gray_concrete
fill 401 111 361 404 111 361 minecraft:gray_concrete
setblock 403 111 323 minecraft:polished_deepslate
setblock 403 111 363 minecraft:polished_deepslate
fill 404 111 323 404 114 323 minecraft:gray_concrete
fill 404 111 360 405 111 360 minecraft:gray_concrete
setblock 404 111 362 minecraft:polished_deepslate
fill 404 111 363 404 114 363 minecraft:gray_concrete
setblock 405 111 361 minecraft:polished_deepslate
fill 405 111 362 405 114 362 minecraft:gray_concrete
setblock 406 111 360 minecraft:polished_deepslate
fill 406 111 361 406 114 361 minecraft:gray_concrete
fill 407 111 360 407 112 360 minecraft:gray_concrete
setblock 408 111 323 minecraft:polished_deepslate
setblock 408 111 363 minecraft:polished_deepslate
fill 409 111 323 409 114 323 minecraft:gray_concrete
setblock 409 111 362 minecraft:polished_deepslate
fill 409 111 363 409 114 363 minecraft:gray_concrete
setblock 410 111 361 minecraft:polished_deepslate
fill 410 111 362 410 114 362 minecraft:gray_concrete
setblock 411 111 361 minecraft:gray_concrete
setblock 413 111 363 minecraft:polished_deepslate
setblock 414 111 322 minecraft:light_blue_stained_glass
fill 414 111 363 414 112 363 minecraft:gray_concrete
setblock 415 111 341 minecraft:polished_deepslate
setblock 415 111 342 minecraft:gray_concrete
setblock 416 111 340 minecraft:polished_deepslate
fill 416 111 341 416 114 341 minecraft:gray_concrete
setblock 416 111 345 minecraft:polished_deepslate
fill 417 111 335 417 112 335 minecraft:gray_concrete
setblock 417 111 339 minecraft:polished_deepslate
fill 417 111 340 417 114 340 minecraft:gray_concrete
setblock 417 111 344 minecraft:polished_deepslate
fill 417 111 345 417 114 345 minecraft:gray_concrete
setblock 417 111 359 minecraft:polished_deepslate
setblock 417 111 360 minecraft:gray_concrete
fill 418 111 342 418 123 342 minecraft:black_concrete
fill 418 111 354 418 118 354 minecraft:black_concrete
fill 376 112 324 376 122 324 minecraft:black_concrete
setblock 377 112 323 minecraft:polished_deepslate
setblock 377 112 334 minecraft:gray_concrete
setblock 377 112 338 minecraft:polished_deepslate
fill 377 112 339 377 115 339 minecraft:gray_concrete
setblock 377 112 343 minecraft:polished_deepslate
fill 377 112 344 377 115 344 minecraft:gray_concrete
fill 378 112 323 378 115 323 minecraft:gray_concrete
setblock 378 112 337 minecraft:polished_deepslate
setblock 378 112 338 minecraft:gray_concrete
fill 379 112 363 381 112 363 minecraft:gray_concrete
setblock 381 112 324 minecraft:polished_deepslate
setblock 382 112 323 minecraft:polished_deepslate
fill 382 112 324 382 115 324 minecraft:gray_concrete
setblock 382 112 362 minecraft:gray_concrete
setblock 382 112 363 minecraft:polished_deepslate
fill 383 112 323 383 115 323 minecraft:gray_concrete
setblock 383 112 362 minecraft:polished_deepslate
fill 383 112 363 383 115 363 minecraft:gray_concrete
setblock 384 112 325 minecraft:gray_concrete
fill 384 112 362 384 115 362 minecraft:gray_concrete
setblock 385 112 325 minecraft:polished_deepslate
fill 385 112 361 388 112 361 minecraft:gray_concrete
setblock 386 112 324 minecraft:polished_deepslate
fill 386 112 325 386 115 325 minecraft:gray_concrete
setblock 387 112 323 minecraft:polished_deepslate
fill 387 112 324 387 115 324 minecraft:gray_concrete
setblock 387 112 363 minecraft:polished_deepslate
fill 388 112 323 388 115 323 minecraft:gray_concrete
setblock 388 112 362 minecraft:polished_deepslate
fill 388 112 363 388 115 363 minecraft:gray_concrete
setblock 389 112 361 minecraft:polished_deepslate
fill 389 112 362 389 115 362 minecraft:gray_concrete
fill 390 112 361 390 113 361 minecraft:gray_concrete
setblock 391 112 324 minecraft:polished_deepslate
setblock 392 112 323 minecraft:polished_deepslate
fill 392 112 324 392 114 324 minecraft:gray_concrete
setblock 392 112 363 minecraft:polished_deepslate
fill 393 112 323 393 115 323 minecraft:gray_concrete
setblock 393 112 362 minecraft:polished_deepslate
fill 393 112 363 396 112 363 minecraft:gray_concrete
fill 394 112 362 397 112 362 minecraft:gray_concrete
setblock 397 112 323 minecraft:polished_deepslate
setblock 397 112 363 minecraft:polished_deepslate
fill 398 112 323 401 112 323 minecraft:gray_concrete
setblock 398 112 362 minecraft:polished_deepslate
fill 398 112 363 398 115 363 minecraft:gray_concrete
fill 399 112 362 402 112 362 minecraft:gray_concrete
fill 401 112 361 403 112 361 minecraft:gray_concrete
setblock 402 112 323 minecraft:polished_deepslate
setblock 402 112 363 minecraft:polished_deepslate
fill 403 112 323 403 115 323 minecraft:gray_concrete
setblock 403 112 362 minecraft:polished_deepslate
fill 403 112 363 403 115 363 minecraft:gray_concrete
setblock 404 112 361 minecraft:polished_deepslate
fill 404 112 362 404 115 362 minecraft:gray_concrete
fill 405 112 327 405 113 327 minecraft:gray_wool
setblock 405 112 360 minecraft:polished_deepslate
fill 405 112 361 405 115 361 minecraft:gray_concrete
setblock 406 112 360 minecraft:gray_concrete
setblock 407 112 323 minecraft:polished_deepslate
setblock 407 112 363 minecraft:polished_deepslate
fill 408 112 323 408 115 323 minecraft:gray_concrete
setblock 408 112 362 minecraft:polished_deepslate
fill 408 112 363 408 115 363 minecraft:gray_concrete
setblock 409 112 361 minecraft:polished_deepslate
fill 409 112 362 409 115 362 minecraft:gray_concrete
setblock 410 112 361 minecraft:gray_concrete
setblock 412 112 323 minecraft:polished_deepslate
setblock 412 112 363 minecraft:polished_deepslate
fill 413 112 363 413 113 363 minecraft:gray_concrete
fill 414 112 322 414 122 322 minecraft:black_concrete
setblock 416 112 339 minecraft:polished_deepslate
fill 416 112 340 416 114 340 minecraft:gray_concrete
setblock 416 112 344 minecraft:polished_deepslate
setblock 417 112 338 minecraft:polished_deepslate
fill 417 112 339 417 115 339 minecraft:gray_concrete
setblock 417 112 343 minecraft:polished_deepslate
fill 417 112 344 417 115 344 minecraft:gray_concrete
setblock 376 113 331 minecraft:light_blue_stained_glass
fill 376 113 332 376 118 334 minecraft:black_concrete
fill 377 113 323 377 116 323 minecraft:gray_concrete
setblock 377 113 337 minecraft:polished_deepslate
fill 377 113 338 377 115 338 minecraft:gray_concrete
setblock 377 113 342 minecraft:polished_deepslate
fill 377 113 343 377 116 343 minecraft:gray_concrete
fill 379 113 333 379 114 333 minecraft:polished_deepslate
fill 379 113 335 379 114 335 minecraft:polished_deepslate
fill 379 113 363 380 113 363 minecraft:gray_concrete
setblock 381 113 323 minecraft:polished_deepslate
fill 381 113 324 381 116 324 minecraft:gray_concrete
fill 381 113 333 381 114 333 minecraft:polished_deepslate
fill 381 113 335 381 114 335 minecraft:polished_deepslate
setblock 381 113 363 minecraft:polished_deepslate
fill 382 113 323 382 116 323 minecraft:gray_concrete
setblock 382 113 362 minecraft:polished_deepslate
fill 382 113 363 382 116 363 minecraft:gray_concrete
fill 383 113 362 383 116 362 minecraft:gray_concrete
setblock 384 113 325 minecraft:polished_deepslate
setblock 385 113 324 minecraft:polished_deepslate
fill 385 113 325 385 116 325 minecraft:gray_concrete
fill 385 113 361 387 113 361 minecraft:gray_concrete
setblock 386 113 323 minecraft:polished_deepslate
fill 386 113 324 386 116 324 minecraft:gray_concrete
setblock 386 113 363 minecraft:polished_deepslate
fill 387 113 323 387 116 323 minecraft:gray_concrete
setblock 387 113 362 minecraft:polished_deepslate
fill 387 113 363 387 116 363 minecraft:gray_concrete
setblock 388 113 361 minecraft:polished_deepslate
fill 388 113 362 388 116 362 minecraft:gray_concrete
setblock 389 113 325 minecraft:polished_deepslate
fill 389 113 361 389 114 361 minecraft:gray_concrete
setblock 390 113 324 minecraft:polished_deepslate
setblock 391 113 323 minecraft:polished_deepslate
fill 391 113 324 391 116 324 minecraft:gray_concrete
setblock 391 113 363 minecraft:polished_deepslate
fill 392 113 323 392 116 323 minecraft:gray_concrete
setblock 392 113 362 minecraft:polished_deepslate
fill 392 113 363 395 113 363 minecraft:gray_concrete
fill 393 113 354 393 114 354 minecraft:light_gray_wool
fill 393 113 362 396 113 362 minecraft:gray_concrete
setblock 396 113 323 minecraft:polished_deepslate
setblock 396 113 363 minecraft:polished_deepslate
fill 397 113 323 400 113 323 minecraft:gray_concrete
setblock 397 113 362 minecraft:polished_deepslate
fill 397 113 363 397 116 363 minecraft:gray_concrete
fill 398 113 362 401 113 362 minecraft:gray_concrete
setblock 401 113 323 minecraft:polished_deepslate
fill 401 113 361 402 113 361 minecraft:gray_concrete
setblock 401 113 363 minecraft:polished_deepslate
fill 402 113 323 402 116 323 minecraft:gray_concrete
setblock 402 113 362 minecraft:polished_deepslate
fill 402 113 363 402 116 363 minecraft:gray_concrete
setblock 402 113 364 minecraft:light_blue_stained_glass
setblock 403 113 361 minecraft:polished_deepslate
fill 403 113 362 403 116 362 minecraft:gray_concrete
fill 403 113 364 403 118 364 minecraft:black_concrete
fill 404 113 361 404 115 361 minecraft:gray_concrete
setblock 405 113 364 minecraft:light_blue_stained_glass
setblock 406 113 323 minecraft:polished_deepslate
setblock 406 113 363 minecraft:polished_deepslate
fill 406 113 364 406 122 364 minecraft:black_concrete
fill 407 113 323 407 116 323 minecraft:gray_concrete
setblock 407 113 362 minecraft:polished_deepslate
fill 407 113 363 407 116 363 minecraft:gray_concrete
setblock 408 113 361 minecraft:polished_deepslate
fill 408 113 362 408 116 362 minecraft:gray_concrete
setblock 409 113 361 minecraft:gray_concrete
setblock 411 113 323 minecraft:polished_deepslate
setblock 411 113 363 minecraft:polished_deepslate
fill 412 113 363 412 114 363 minecraft:gray_concrete
setblock 416 113 339 minecraft:gray_concrete
setblock 416 113 343 minecraft:polished_deepslate
fill 416 113 344 416 116 344 minecraft:gray_concrete
setblock 417 113 337 minecraft:polished_deepslate
fill 417 113 338 417 116 338 minecraft:gray_concrete
setblock 417 113 342 minecraft:polished_deepslate
fill 417 113 343 417 116 343 minecraft:gray_concrete
setblock 417 113 347 minecraft:polished_deepslate
fill 376 114 331 376 118 331 minecraft:black_concrete
fill 377 114 324 377 115 324 minecraft:gray_concrete
setblock 377 114 337 minecraft:gray_concrete
setblock 377 114 341 minecraft:polished_deepslate
fill 377 114 342 377 117 342 minecraft:gray_concrete
setblock 379 114 363 minecraft:gray_concrete
setblock 380 114 323 minecraft:polished_deepslate
fill 380 114 324 380 117 324 minecraft:gray_concrete
setblock 380 114 363 minecraft:polished_deepslate
fill 381 114 323 381 117 323 minecraft:gray_concrete
fill 381 114 363 381 117 363 minecraft:gray_concrete
fill 382 114 362 382 117 362 minecraft:gray_concrete
setblock 383 114 325 minecraft:polished_deepslate
setblock 384 114 324 minecraft:polished_deepslate
fill 384 114 325 384 117 325 minecraft:gray_concrete
setblock 385 114 323 minecraft:polished_deepslate
fill 385 114 324 385 117 324 minecraft:gray_concrete
setblock 385 114 363 minecraft:polished_deepslate
fill 386 114 323 386 117 323 minecraft:gray_concrete
setblock 386 114 361 minecraft:gray_concrete
setblock 386 114 362 minecraft:polished_deepslate
fill 386 114 363 386 117 363 minecraft:gray_concrete
setblock 387 114 361 minecraft:polished_deepslate
fill 387 114 362 387 117 362 minecraft:gray_concrete
setblock 388 114 325 minecraft:polished_deepslate
setblock 388 114 361 minecraft:gray_concrete
setblock 389 114 324 minecraft:polished_deepslate
setblock 390 114 323 minecraft:polished_deepslate
fill 390 114 324 390 117 324 minecraft:gray_concrete
setblock 390 114 363 minecraft:polished_deepslate
fill 391 114 323 391 117 323 minecraft:gray_concrete
setblock 391 114 362 minecraft:polished_deepslate
fill 391 114 363 394 114 363 minecraft:gray_concrete
setblock 392 114 322 minecraft:light_blue_stained_glass
fill 392 114 362 395 114 362 minecraft:gray_concrete
setblock 395 114 322 minecraft:light_blue_stained_glass
setblock 395 114 323 minecraft:polished_deepslate
setblock 395 114 363 minecraft:polished_deepslate
fill 396 114 323 399 114 323 minecraft:gray_concrete
setblock 396 114 362 minecraft:polished_deepslate
fill 396 114 363 396 117 363 minecraft:gray_concrete
fill 396 114 364 396 120 364 minecraft:black_concrete
fill 397 114 362 400 114 362 minecraft:gray_concrete
setblock 397 114 364 minecraft:light_blue_stained_glass
fill 398 114 364 398 122 364 minecraft:black_concrete
setblock 400 114 322 minecraft:light_blue_stained_glass
setblock 400 114 323 minecraft:polished_deepslate
setblock 400 114 363 minecraft:polished_deepslate
fill 401 114 323 401 117 323 minecraft:gray_concrete
setblock 401 114 362 minecraft:polished_deepslate
fill 401 114 363 401 117 363 minecraft:gray_concrete
setblock 402 114 361 minecraft:polished_deepslate
fill 402 114 362 402 117 362 minecraft:gray_concrete
fill 402 114 364 402 120 364 minecraft:black_concrete
fill 403 114 361 403 115 361 minecraft:gray_concrete
setblock 405 114 323 minecraft:polished_deepslate
setblock 405 114 363 minecraft:polished_deepslate
fill 405 114 364 405 122 364 minecraft:black_concrete
fill 406 114 323 406 117 323 minecraft:gray_concrete
setblock 406 114 362 minecraft:polished_deepslate
fill 406 114 363 406 117 363 minecraft:gray_concrete
setblock 407 114 361 minecraft:polished_deepslate
fill 407 114 362 407 117 362 minecraft:gray_concrete
setblock 408 114 361 minecraft:gray_concrete
setblock 410 114 323 minecraft:polished_deepslate
setblock 410 114 363 minecraft:polished_deepslate
fill 411 114 363 411 115 363 minecraft:gray_concrete
setblock 416 114 342 minecraft:polished_deepslate
fill 416 114 343 416 117 343 minecraft:gray_concrete
setblock 417 114 337 minecraft:gray_concrete
setblock 417 114 341 minecraft:polished_deepslate
fill 417 114 342 417 117 342 minecraft:gray_concrete
setblock 417 114 346 minecraft:polished_deepslate
fill 417 114 347 417 117 347 minecraft:gray_concrete
setblock 377 115 325 minecraft:polished_deepslate
fill 377 115 326 377 118 326 minecraft:gray_concrete
setblock 377 115 340 minecraft:polished_deepslate
fill 377 115 341 377 118 341 minecraft:gray_concrete
setblock 379 115 323 minecraft:polished_deepslate
fill 379 115 324 379 118 324 minecraft:gray_concrete
setblock 379 115 363 minecraft:polished_deepslate
fill 380 115 323 380 118 323 minecraft:gray_concrete
fill 380 115 363 380 118 363 minecraft:gray_concrete
setblock 382 115 325 minecraft:polished_deepslate
setblock 383 115 324 minecraft:polished_deepslate
fill 383 115 325 383 118 325 minecraft:gray_concrete
setblock 384 115 323 minecraft:polished_deepslate
fill 384 115 324 384 118 324 minecraft:gray_concrete
setblock 384 115 363 minecraft:polished_deepslate
fill 385 115 323 385 118 323 minecraft:gray_concrete
setblock 385 115 362 minecraft:polished_deepslate
fill 385 115 363 385 118 363 minecraft:gray_concrete
fill 386 115 362 386 118 362 minecraft:gray_concrete
setblock 387 115 325 minecraft:polished_deepslate
setblock 388 115 324 minecraft:polished_deepslate
fill 388 115 325 388 118 325 minecraft:gray_concrete
setblock 389 115 323 minecraft:polished_deepslate
fill 389 115 324 389 118 324 minecraft:gray_concrete
setblock 389 115 363 minecraft:polished_deepslate
fill 390 115 323 390 118 323 minecraft:gray_concrete
setblock 390 115 362 minecraft:polished_deepslate
fill 390 115 363 393 115 363 minecraft:gray_concrete
fill 391 115 362 393 115 362 minecraft:gray_concrete
fill 392 115 322 392 122 322 minecraft:black_concrete
setblock 394 115 323 minecraft:polished_deepslate
setblock 394 115 363 minecraft:polished_deepslate
fill 395 115 322 395 123 322 minecraft:black_concrete
fill 395 115 323 398 115 323 minecraft:gray_concrete
fill 395 115 363 395 118 363 minecraft:gray_concrete
fill 397 115 364 397 122 364 minecraft:black_concrete
fill 398 115 362 399 115 362 minecraft:gray_concrete
setblock 399 115 323 minecraft:polished_deepslate
setblock 399 115 363 minecraft:polished_deepslate
fill 400 115 322 400 122 322 minecraft:black_concrete
fill 400 115 323 400 118 323 minecraft:gray_concrete
setblock 400 115 362 minecraft:polished_deepslate
fill 400 115 363 400 118 363 minecraft:gray_concrete
fill 401 115 362 401 118 362 minecraft:gray_concrete
setblock 404 115 323 minecraft:polished_deepslate
setblock 404 115 363 minecraft:polished_deepslate
fill 405 115 323 405 118 323 minecraft:gray_concrete
setblock 405 115 362 minecraft:polished_deepslate
fill 405 115 363 405 118 363 minecraft:gray_concrete
setblock 406 115 361 minecraft:polished_deepslate
fill 406 115 362 406 118 362 minecraft:gray_concrete
setblock 409 115 323 minecraft:polished_deepslate
setblock 409 115 363 minecraft:polished_deepslate
fill 410 115 323 410 118 323 minecraft:gray_concrete
fill 410 115 363 410 117 363 minecraft:gray_concrete
setblock 416 115 341 minecraft:polished_deepslate
fill 416 115 342 416 118 342 minecraft:gray_concrete
setblock 417 115 340 minecraft:polished_deepslate
fill 417 115 341 417 118 341 minecraft:gray_concrete
setblock 417 115 345 minecraft:polished_deepslate
fill 417 115 346 417 118 346 minecraft:gray_concrete
setblock 377 116 324 minecraft:polished_deepslate
fill 377 116 325 378 118 325 minecraft:gray_concrete
fill 377 116 327 377 116 328 minecraft:gray_concrete
setblock 377 116 339 minecraft:polished_deepslate
fill 377 116 340 377 119 340 minecraft:gray_concrete
setblock 377 116 344 minecraft:polished_deepslate
fill 377 116 345 377 119 345 minecraft:gray_concrete
setblock 378 116 323 minecraft:polished_deepslate
fill 378 116 324 378 119 324 minecraft:gray_concrete
fill 379 116 323 379 119 323 minecraft:gray_concrete
setblock 379 116 325 minecraft:light[level=12]
setblock 379 116 332 minecraft:light[level=12]
setblock 379 116 339 minecraft:light[level=12]
setblock 379 116 346 minecraft:light[level=12]
setblock 379 116 353 minecraft:light[level=12]
setblock 379 116 360 minecraft:light[level=12]
fill 379 116 363 379 119 363 minecraft:gray_concrete
setblock 381 116 325 minecraft:polished_deepslate
setblock 382 116 324 minecraft:polished_deepslate
fill 382 116 325 382 119 325 minecraft:gray_concrete
setblock 383 116 323 minecraft:polished_deepslate
fill 383 116 324 383 119 324 minecraft:gray_concrete
setblock 383 116 363 minecraft:polished_deepslate
fill 384 116 323 384 119 323 minecraft:gray_concrete
setblock 384 116 362 minecraft:polished_deepslate
fill 384 116 363 384 119 363 minecraft:gray_concrete
fill 385 116 362 385 119 362 minecraft:gray_concrete
setblock 386 116 325 minecraft:polished_deepslate
setblock 386 116 332 minecraft:light[level=12]
setblock 386 116 339 minecraft:light[level=12]
setblock 386 116 346 minecraft:light[level=12]
setblock 386 116 353 minecraft:light[level=12]
setblock 386 116 360 minecraft:light[level=12]
setblock 387 116 324 minecraft:polished_deepslate
fill 387 116 325 387 119 325 minecraft:gray_concrete
setblock 388 116 323 minecraft:polished_deepslate
fill 388 116 324 388 119 324 minecraft:gray_concrete
setblock 388 116 363 minecraft:polished_deepslate
fill 389 116 323 389 119 323 minecraft:gray_concrete
setblock 389 116 362 minecraft:polished_deepslate
fill 389 116 363 392 116 363 minecraft:gray_concrete
fill 390 116 362 392 116 362 minecraft:gray_concrete
setblock 393 116 323 minecraft:polished_deepslate
setblock 393 116 325 minecraft:light[level=12]
setblock 393 116 332 minecraft:light[level=12]
setblock 393 116 339 minecraft:light[level=12]
setblock 393 116 346 minecraft:light[level=12]
setblock 393 116 353 minecraft:light[level=12]
setblock 393 116 360 minecraft:light[level=12]
setblock 393 116 363 minecraft:polished_deepslate
fill 394 116 323 397 116 323 minecraft:gray_concrete
fill 394 116 363 394 119 363 minecraft:gray_concrete
setblock 398 116 323 minecraft:polished_deepslate
setblock 398 116 362 minecraft:gray_concrete
setblock 398 116 363 minecraft:polished_deepslate
fill 399 116 323 399 119 323 minecraft:gray_concrete
setblock 399 116 362 minecraft:polished_deepslate
fill 399 116 363 399 119 363 minecraft:gray_concrete
setblock 400 116 325 minecraft:light[level=12]
setblock 400 116 332 minecraft:light[level=12]
setblock 400 116 339 minecraft:light[level=12]
setblock 400 116 346 minecraft:light[level=12]
setblock 400 116 353 minecraft:light[level=12]
setblock 400 116 360 minecraft:light[level=12]
fill 400 116 362 400 119 362 minecraft:gray_concrete
setblock 403 116 323 minecraft:polished_deepslate
fill 403 116 324 405 117 324 minecraft:gray_concrete
setblock 403 116 363 minecraft:polished_deepslate
fill 404 116 323 404 119 323 minecraft:gray_concrete
setblock 404 116 362 minecraft:polished_deepslate
fill 404 116 363 404 119 363 minecraft:gray_concrete
fill 405 116 362 405 119 362 minecraft:gray_concrete
setblock 407 116 325 minecraft:light[level=12]
setblock 407 116 332 minecraft:light[level=12]
setblock 407 116 339 minecraft:light[level=12]
setblock 407 116 346 minecraft:light[level=12]
setblock 407 116 353 minecraft:light[level=12]
setblock 407 116 360 minecraft:light[level=12]
setblock 408 116 323 minecraft:polished_deepslate
setblock 408 116 363 minecraft:polished_deepslate
fill 409 116 323 409 119 323 minecraft:gray_concrete
fill 409 116 363 409 119 363 minecraft:gray_concrete
setblock 414 116 325 minecraft:light[level=12]
setblock 414 116 332 minecraft:light[level=12]
setblock 414 116 339 minecraft:light[level=12]
setblock 414 116 346 minecraft:light[level=12]
setblock 414 116 353 minecraft:light[level=12]
setblock 414 116 360 minecraft:light[level=12]
setblock 417 116 339 minecraft:polished_deepslate
fill 417 116 340 417 119 340 minecraft:gray_concrete
setblock 417 116 344 minecraft:polished_deepslate
fill 417 116 345 417 119 345 minecraft:gray_concrete
setblock 418 116 333 minecraft:light_blue_stained_glass
fill 418 116 334 418 122 334 minecraft:black_concrete
setblock 376 117 325 minecraft:light_blue_stained_glass
setblock 376 117 338 minecraft:light_blue_stained_glass
setblock 377 117 323 minecraft:polished_deepslate
fill 377 117 324 377 120 324 minecraft:gray_concrete
setblock 377 117 327 minecraft:gray_concrete
setblock 377 117 328 minecraft:polished_deepslate
fill 377 117 329 377 120 329 minecraft:gray_concrete
fill 377 117 339 377 120 339 minecraft:gray_concrete
setblock 377 117 343 minecraft:polished_deepslate
fill 377 117 344 377 120 344 minecraft:gray_concrete
fill 378 117 323 378 120 323 minecraft:gray_concrete
setblock 378 117 326 minecraft:gray_concrete
setblock 378 117 327 minecraft:polished_deepslate
fill 378 117 363 378 120 363 minecraft:gray_concrete
setblock 379 117 322 minecraft:light_blue_stained_glass
setblock 380 117 325 minecraft:polished_deepslate
setblock 381 117 324 minecraft:polished_deepslate
fill 381 117 325 381 120 325 minecraft:gray_concrete
fill 381 117 362 381 118 362 minecraft:gray_concrete
setblock 382 117 323 minecraft:polished_deepslate
fill 382 117 324 382 120 324 minecraft:gray_concrete
setblock 382 117 363 minecraft:polished_deepslate
fill 383 117 323 383 120 323 minecraft:gray_concrete
setblock 383 117 362 minecraft:polished_deepslate
fill 383 117 363 383 120 363 minecraft:gray_concrete
fill 384 117 362 384 120 362 minecraft:gray_concrete
setblock 385 117 325 minecraft:polished_deepslate
setblock 386 117 324 minecraft:polished_deepslate
fill 386 117 325 386 120 325 minecraft:gray_concrete
setblock 387 117 323 minecraft:polished_deepslate
fill 387 117 324 387 120 324 minecraft:gray_concrete
setblock 387 117 363 minecraft:polished_deepslate
fill 388 117 323 388 120 323 minecraft:gray_concrete
setblock 388 117 362 minecraft:polished_deepslate
fill 388 117 363 391 117 363 minecraft:gray_concrete
fill 389 117 362 391 117 362 minecraft:gray_concrete
setblock 391 117 324 minecraft:polished_deepslate
setblock 392 117 323 minecraft:polished_deepslate
setblock 392 117 363 minecraft:polished_deepslate
fill 393 117 323 396 117 323 minecraft:gray_concrete
fill 393 117 363 393 120 363 minecraft:gray_concrete
fill 396 117 324 396 120 324 minecraft:light_blue_stained_glass
setblock 397 117 323 minecraft:polished_deepslate
setblock 397 117 363 minecraft:polished_deepslate
fill 398 117 323 398 120 323 minecraft:gray_concrete
setblock 398 117 362 minecraft:polished_deepslate
fill 398 117 363 398 120 363 minecraft:gray_concrete
fill 399 117 362 399 120 362 minecraft:gray_concrete
setblock 402 117 323 minecraft:polished_deepslate
fill 402 117 324 402 120 324 minecraft:gray_concrete
setblock 402 117 363 minecraft:polished_deepslate
fill 403 117 323 403 120 323 minecraft:gray_concrete
setblock 403 117 362 minecraft:polished_deepslate
fill 403 117 363 403 120 363 minecraft:gray_concrete
fill 404 117 362 404 120 362 minecraft:gray_concrete
setblock 405 117 322 minecraft:light_blue_stained_glass
setblock 406 117 324 minecraft:polished_deepslate
setblock 407 117 323 minecraft:polished_deepslate
setblock 407 117 363 minecraft:polished_deepslate
fill 408 117 323 408 120 323 minecraft:gray_concrete
fill 408 117 363 408 120 363 minecraft:gray_concrete
setblock 415 117 364 minecraft:light_blue_stained_glass
setblock 416 117 344 minecraft:polished_deepslate
fill 416 117 345 416 120 345 minecraft:gray_concrete
setblock 417 117 338 minecraft:polished_deepslate
fill 417 117 339 417 120 339 minecraft:gray_concrete
setblock 417 117 343 minecraft:polished_deepslate
fill 417 117 344 417 120 344 minecraft:gray_concrete
setblock 417 117 348 minecraft:polished_deepslate
fill 418 117 333 418 122 333 minecraft:black_concrete
fill 418 117 355 418 122 357 minecraft:black_concrete
setblock 418 117 358 minecraft:light_blue_stained_glass
fill 418 117 359 418 119 361 minecraft:black_concrete
fill 376 118 325 376 122 325 minecraft:black_concrete
setblock 376 118 338 minecraft:black_concrete
fill 377 118 323 377 121 323 minecraft:gray_concrete
setblock 377 118 327 minecraft:polished_deepslate
fill 377 118 328 378 120 328 minecraft:gray_concrete
fill 377 118 330 377 118 331 minecraft:gray_concrete
setblock 377 118 342 minecraft:polished_deepslate
fill 377 118 343 377 121 343 minecraft:gray_concrete
setblock 377 118 346 minecraft:gray_concrete
setblock 377 118 347 minecraft:polished_deepslate
setblock 378 118 326 minecraft:polished_deepslate
fill 378 118 327 379 120 327 minecraft:gray_concrete
fill 378 118 329 378 119 329 minecraft:gray_concrete
fill 379 118 322 379 123 322 minecraft:black_concrete
setblock 379 118 325 minecraft:polished_deepslate
fill 379 118 326 379 121 326 minecraft:gray_concrete
setblock 379 118 333 minecraft:light[level=13]
setblock 379 118 341 minecraft:light[level=13]
setblock 379 118 349 minecraft:light[level=13]
setblock 379 118 357 minecraft:light[level=13]
setblock 380 118 324 minecraft:polished_deepslate
fill 380 118 325 380 121 325 minecraft:gray_concrete
setblock 381 118 323 minecraft:polished_deepslate
fill 381 118 324 381 121 324 minecraft:gray_concrete
setblock 381 118 363 minecraft:polished_deepslate
fill 382 118 323 382 121 323 minecraft:gray_concrete
setblock 382 118 326 minecraft:gray_concrete
setblock 382 118 362 minecraft:polished_deepslate
fill 382 118 363 382 121 363 minecraft:gray_concrete
setblock 383 118 326 minecraft:polished_deepslate
fill 383 118 362 383 121 362 minecraft:gray_concrete
setblock 384 118 325 minecraft:polished_deepslate
fill 384 118 326 385 120 326 minecraft:gray_concrete
setblock 385 118 324 minecraft:polished_deepslate
fill 385 118 325 385 121 325 minecraft:gray_concrete
setblock 386 118 323 minecraft:polished_deepslate
fill 386 118 324 386 121 324 minecraft:gray_concrete
setblock 386 118 363 minecraft:polished_deepslate
fill 387 118 323 387 121 323 minecraft:gray_concrete
setblock 387 118 333 minecraft:light[level=13]
setblock 387 118 341 minecraft:light[level=13]
setblock 387 118 349 minecraft:light[level=13]
setblock 387 118 357 minecraft:light[level=13]
setblock 387 118 362 minecraft:polished_deepslate
fill 387 118 363 390 118 363 minecraft:gray_concrete
fill 388 118 362 390 119 362 minecraft:gray_concrete
setblock 390 118 324 minecraft:polished_deepslate
setblock 391 118 323 minecraft:polished_deepslate
fill 391 118 324 391 121 324 minecraft:gray_concrete
setblock 391 118 363 minecraft:polished_deepslate
fill 392 118 323 395 118 323 minecraft:gray_concrete
fill 392 118 363 392 121 363 minecraft:gray_concrete
fill 395 118 324 395 120 324 minecraft:light_blue_stained_glass
setblock 395 118 325 minecraft:light[level=13]
setblock 395 118 333 minecraft:light[level=13]
setblock 395 118 341 minecraft:light[level=13]
setblock 395 118 349 minecraft:light[level=13]
setblock 395 118 357 minecraft:light[level=13]
setblock 396 118 323 minecraft:polished_deepslate
fill 396 118 325 396 120 325 minecraft:light_blue_stained_glass
setblock 396 118 363 minecraft:polished_deepslate
fill 397 118 323 397 121 323 minecraft:gray_concrete
fill 397 118 324 397 119 324 minecraft:light_blue_stained_glass
fill 397 118 363 397 121 363 minecraft:gray_concrete
fill 398 118 362 398 121 362 minecraft:gray_concrete
setblock 400 118 324 minecraft:polished_deepslate
setblock 401 118 323 minecraft:polished_deepslate
fill 401 118 324 401 121 324 minecraft:gray_concrete
setblock 401 118 363 minecraft:polished_deepslate
fill 402 118 323 402 121 323 minecraft:gray_concrete
setblock 402 118 362 minecraft:polished_deepslate
fill 402 118 363 402 121 363 minecraft:gray_concrete
fill 403 118 324 404 118 324 minecraft:gray_concrete
setblock 403 118 325 minecraft:light[level=13]
setblock 403 118 333 minecraft:light[level=13]
setblock 403 118 341 minecraft:light[level=13]
setblock 403 118 349 minecraft:light[level=13]
setblock 403 118 357 minecraft:light[level=13]
fill 403 118 362 403 121 362 minecraft:gray_concrete
fill 405 118 322 405 122 322 minecraft:black_concrete
setblock 405 118 324 minecraft:polished_deepslate
setblock 406 118 323 minecraft:polished_deepslate
fill 406 118 324 406 121 324 minecraft:gray_concrete
setblock 406 118 363 minecraft:polished_deepslate
fill 407 118 323 407 121 323 minecraft:gray_concrete
setblock 407 118 362 minecraft:polished_deepslate
fill 407 118 363 407 121 363 minecraft:gray_concrete
setblock 411 118 325 minecraft:light[level=13]
setblock 411 118 333 minecraft:light[level=13]
setblock 411 118 341 minecraft:light[level=13]
setblock 411 118 349 minecraft:light[level=13]
setblock 411 118 357 minecraft:light[level=13]
fill 415 118 364 415 122 364 minecraft:black_concrete
setblock 416 118 343 minecraft:polished_deepslate
fill 416 118 344 416 121 344 minecraft:gray_concrete
fill 416 118 346 416 119 346 minecraft:gray_concrete
fill 417 118 323 417 118 326 minecraft:gray_concrete
setblock 417 118 327 minecraft:polished_deepslate
fill 417 118 328 417 121 328 minecraft:gray_concrete
fill 417 118 338 417 121 338 minecraft:gray_concrete
setblock 417 118 342 minecraft:polished_deepslate
fill 417 118 343 417 121 343 minecraft:gray_concrete
setblock 417 118 347 minecraft:polished_deepslate
fill 417 118 348 417 120 349 minecraft:gray_concrete
fill 418 118 358 418 122 358 minecraft:black_concrete
fill 376 119 331 376 120 331 minecraft:gray_wool
fill 376 119 332 376 119 333 minecraft:black_concrete
setblock 376 119 334 minecraft:gray_wool
setblock 376 119 338 minecraft:gray_wool
fill 376 119 341 376 121 341 minecraft:gray_wool
setblock 376 119 358 minecraft:gray_wool
setblock 377 119 325 minecraft:gray_concrete
setblock 377 119 326 minecraft:polished_deepslate
fill 377 119 327 377 122 327 minecraft:gray_concrete
setblock 377 119 330 minecraft:gray_concrete
setblock 377 119 331 minecraft:polished_deepslate
fill 377 119 332 377 120 334 minecraft:gray_concrete
setblock 377 119 341 minecraft:polished_deepslate
fill 377 119 342 377 122 342 minecraft:gray_concrete
setblock 377 119 346 minecraft:polished_deepslate
fill 377 119 347 377 121 348 minecraft:gray_concrete
fill 377 119 363 377 121 363 minecraft:gray_concrete
setblock 378 119 325 minecraft:polished_deepslate
fill 378 119 326 378 122 326 minecraft:gray_concrete
setblock 378 119 330 minecraft:polished_deepslate
fill 378 119 331 378 122 331 minecraft:gray_concrete
setblock 378 119 344 minecraft:gray_concrete
setblock 379 119 324 minecraft:polished_deepslate
fill 379 119 325 379 122 325 minecraft:gray_concrete
setblock 379 119 328 minecraft:gray_concrete
setblock 379 119 329 minecraft:polished_deepslate
setblock 380 119 323 minecraft:polished_deepslate
fill 380 119 324 380 122 324 minecraft:gray_concrete
fill 380 119 326 381 119 326 minecraft:gray_concrete
setblock 380 119 362 minecraft:gray_concrete
setblock 380 119 363 minecraft:polished_deepslate
fill 381 119 323 381 122 323 minecraft:gray_concrete
setblock 381 119 362 minecraft:polished_deepslate
fill 381 119 363 381 122 363 minecraft:gray_concrete
setblock 382 119 326 minecraft:polished_deepslate
fill 382 119 362 382 122 362 minecraft:gray_concrete
setblock 383 119 325 minecraft:polished_deepslate
fill 383 119 326 383 122 326 minecraft:gray_concrete
setblock 384 119 324 minecraft:polished_deepslate
fill 384 119 325 384 122 325 minecraft:gray_concrete
setblock 385 119 323 minecraft:polished_deepslate
fill 385 119 324 385 122 324 minecraft:gray_concrete
setblock 385 119 363 minecraft:polished_deepslate
fill 386 119 323 386 122 323 minecraft:gray_concrete
setblock 386 119 326 minecraft:gray_concrete
setblock 386 119 362 minecraft:polished_deepslate
fill 386 119 363 389 119 363 minecraft:gray_concrete
fill 387 119 362 387 122 362 minecraft:gray_concrete
setblock 388 119 325 minecraft:polished_deepslate
fill 388 119 353 388 120 354 minecraft:white_wool
setblock 389 119 324 minecraft:polished_deepslate
setblock 390 119 323 minecraft:polished_deepslate
fill 390 119 324 390 122 324 minecraft:gray_concrete
setblock 390 119 363 minecraft:polished_deepslate
fill 391 119 323 394 119 323 minecraft:gray_concrete
fill 391 119 363 391 122 363 minecraft:gray_concrete
setblock 395 119 323 minecraft:polished_deepslate
fill 395 119 325 395 120 325 minecraft:light_blue_stained_glass
setblock 395 119 363 minecraft:polished_deepslate
fill 396 119 323 396 122 323 minecraft:gray_concrete
fill 396 119 326 396 121 326 minecraft:light_blue_stained_glass
fill 396 119 363 396 122 363 minecraft:gray_concrete
fill 397 119 325 397 120 325 minecraft:light_blue_stained_glass
fill 397 119 362 397 122 362 minecraft:gray_concrete
setblock 398 119 324 minecraft:gray_concrete
setblock 399 119 324 minecraft:polished_deepslate
setblock 400 119 323 minecraft:polished_deepslate
fill 400 119 324 400 122 324 minecraft:gray_concrete
setblock 400 119 363 minecraft:polished_deepslate
fill 401 119 323 401 122 323 minecraft:gray_concrete
setblock 401 119 362 minecraft:polished_deepslate
fill 401 119 363 401 122 363 minecraft:gray_concrete
fill 402 119 362 402 122 362 minecraft:gray_concrete
setblock 403 119 324 minecraft:gray_concrete
setblock 403 119 364 minecraft:gray_wool
setblock 404 119 324 minecraft:polished_deepslate
setblock 405 119 323 minecraft:polished_deepslate
fill 405 119 324 405 122 324 minecraft:gray_concrete
setblock 405 119 363 minecraft:polished_deepslate
setblock 406 119 322 minecraft:gray_wool
fill 406 119 323 406 122 323 minecraft:gray_concrete
setblock 406 119 362 minecraft:polished_deepslate
fill 406 119 363 406 122 363 minecraft:gray_concrete
fill 407 119 324 407 120 324 minecraft:gray_concrete
setblock 410 119 323 minecraft:polished_deepslate
setblock 415 119 323 minecraft:polished_deepslate
fill 416 119 323 417 121 323 minecraft:gray_concrete
setblock 416 119 341 minecraft:gray_concrete
setblock 416 119 342 minecraft:polished_deepslate
fill 416 119 343 416 122 343 minecraft:gray_concrete
setblock 416 119 347 minecraft:polished_deepslate
fill 416 119 348 416 122 348 minecraft:gray_concrete
fill 417 119 324 417 119 325 minecraft:gray_concrete
setblock 417 119 326 minecraft:polished_deepslate
fill 417 119 327 417 122 327 minecraft:gray_concrete
fill 417 119 329 417 119 330 minecraft:gray_concrete
setblock 417 119 331 minecraft:polished_deepslate
fill 417 119 332 417 121 333 minecraft:gray_concrete
setblock 417 119 336 minecraft:polished_deepslate
fill 417 119 337 417 122 337 minecraft:gray_concrete
setblock 417 119 341 minecraft:polished_deepslate
fill 417 119 342 417 122 342 minecraft:gray_concrete
setblock 417 119 346 minecraft:polished_deepslate
fill 417 119 347 417 122 347 minecraft:gray_concrete
setblock 417 119 350 minecraft:gray_concrete
setblock 418 119 324 minecraft:gray_wool
setblock 418 119 326 minecraft:gray_wool
fill 418 119 327 418 122 327 minecraft:black_concrete
setblock 418 119 328 minecraft:light_blue_stained_glass
fill 418 119 329 418 122 331 minecraft:black_concrete
fill 418 119 354 418 120 354 minecraft:gray_wool
fill 376 120 322 377 120 322 minecraft:gray_wool
setblock 376 120 330 minecraft:gray_wool
fill 376 120 332 376 120 333 minecraft:gray_wool
setblock 376 120 334 minecraft:black_concrete
fill 376 120 338 376 122 338 minecraft:black_concrete
fill 376 120 342 376 122 343 minecraft:black_concrete
fill 376 120 344 376 120 345 minecraft:gray_wool
fill 376 120 346 376 122 346 minecraft:black_concrete
setblock 376 120 354 minecraft:gray_wool
fill 376 120 358 376 122 358 minecraft:black_concrete
fill 376 120 360 376 122 363 minecraft:black_concrete
setblock 376 120 364 minecraft:gray_wool
setblock 377 120 325 minecraft:polished_deepslate
fill 377 120 326 377 123 326 minecraft:gray_concrete
setblock 377 120 330 minecraft:polished_deepslate
fill 377 120 331 377 123 331 minecraft:gray_concrete
setblock 377 120 335 minecraft:polished_deepslate
fill 377 120 336 377 121 338 minecraft:gray_concrete
setblock 377 120 340 minecraft:polished_deepslate
fill 377 120 341 377 123 341 minecraft:gray_concrete
setblock 377 120 345 minecraft:polished_deepslate
fill 377 120 346 378 122 346 minecraft:gray_concrete
setblock 377 120 349 minecraft:gray_concrete
setblock 377 120 350 minecraft:polished_deepslate
fill 377 120 362 377 122 362 minecraft:gray_concrete
fill 378 120 322 378 122 322 minecraft:black_concrete
setblock 378 120 324 minecraft:polished_deepslate
fill 378 120 325 378 123 325 minecraft:gray_concrete
setblock 378 120 329 minecraft:polished_deepslate
fill 378 120 330 379 122 330 minecraft:gray_concrete
fill 378 120 332 378 121 332 minecraft:gray_concrete
setblock 378 120 343 minecraft:gray_concrete
setblock 378 120 344 minecraft:polished_deepslate
fill 378 120 345 378 123 345 minecraft:gray_concrete
fill 378 120 347 378 121 347 minecraft:gray_concrete
setblock 379 120 323 minecraft:polished_deepslate
fill 379 120 324 379 123 324 minecraft:gray_concrete
setblock 379 120 328 minecraft:polished_deepslate
fill 379 120 329 379 123 329 minecraft:gray_concrete
setblock 379 120 363 minecraft:polished_deepslate
fill 380 120 323 380 123 323 minecraft:gray_concrete
setblock 380 120 326 minecraft:gray_concrete
setblock 380 120 327 minecraft:polished_deepslate
fill 380 120 328 380 123 328 minecraft:gray_concrete
setblock 380 120 362 minecraft:polished_deepslate
fill 380 120 363 380 123 363 minecraft:gray_concrete
setblock 381 120 326 minecraft:polished_deepslate
fill 381 120 362 381 123 362 minecraft:gray_concrete
setblock 382 120 325 minecraft:polished_deepslate
fill 382 120 326 382 123 326 minecraft:gray_concrete
setblock 383 120 324 minecraft:polished_deepslate
fill 383 120 325 383 123 325 minecraft:gray_concrete
setblock 384 120 323 minecraft:polished_deepslate
fill 384 120 324 384 123 324 minecraft:gray_concrete
setblock 384 120 363 minecraft:polished_deepslate
setblock 384 120 364 minecraft:gray_wool
fill 385 120 323 385 123 323 minecraft:gray_concrete
setblock 385 120 362 minecraft:polished_deepslate
fill 385 120 363 388 120 363 minecraft:gray_concrete
setblock 386 120 326 minecraft:polished_deepslate
fill 386 120 362 386 123 362 minecraft:gray_concrete
setblock 387 120 325 minecraft:polished_deepslate
setblock 388 120 324 minecraft:polished_deepslate
fill 388 120 325 388 122 325 minecraft:gray_concrete
fill 388 120 362 389 120 362 minecraft:gray_concrete
setblock 389 120 323 minecraft:polished_deepslate
fill 389 120 324 389 123 324 minecraft:gray_concrete
setblock 389 120 363 minecraft:polished_deepslate
fill 390 120 323 393 120 323 minecraft:gray_concrete
fill 390 120 363 390 123 363 minecraft:gray_concrete
setblock 392 120 324 minecraft:gray_concrete
setblock 394 120 323 minecraft:polished_deepslate
setblock 394 120 363 minecraft:polished_deepslate
fill 395 120 323 395 123 323 minecraft:gray_concrete
fill 395 120 363 395 123 363 minecraft:gray_concrete
fill 396 120 327 396 121 327 minecraft:light_blue_stained_glass
setblock 397 120 324 minecraft:gray_concrete
setblock 398 120 324 minecraft:polished_deepslate
setblock 399 120 323 minecraft:polished_deepslate
fill 399 120 324 399 123 324 minecraft:gray_concrete
setblock 399 120 363 minecraft:polished_deepslate
fill 400 120 323 400 123 323 minecraft:gray_concrete
setblock 400 120 362 minecraft:polished_deepslate
fill 400 120 363 400 123 363 minecraft:gray_concrete
fill 401 120 362 401 123 362 minecraft:gray_concrete
setblock 403 120 324 minecraft:polished_deepslate
fill 403 120 364 403 122 364 minecraft:black_concrete
setblock 404 120 323 minecraft:polished_deepslate
fill 404 120 324 404 123 324 minecraft:gray_concrete
setblock 404 120 363 minecraft:polished_deepslate
fill 405 120 323 405 123 323 minecraft:gray_concrete
setblock 405 120 362 minecraft:polished_deepslate
fill 405 120 363 405 123 363 minecraft:gray_concrete
setblock 406 120 322 minecraft:black_concrete
setblock 407 120 322 minecraft:gray_wool
setblock 409 120 323 minecraft:polished_deepslate
fill 410 120 323 410 121 323 minecraft:gray_concrete
setblock 414 120 323 minecraft:polished_deepslate
fill 415 120 323 415 123 323 minecraft:gray_concrete
setblock 416 120 322 minecraft:gray_wool
setblock 416 120 325 minecraft:gray_concrete
setblock 416 120 326 minecraft:polished_deepslate
fill 416 120 327 416 122 328 minecraft:gray_concrete
setblock 416 120 341 minecraft:polished_deepslate
fill 416 120 342 416 123 342 minecraft:gray_concrete
setblock 416 120 346 minecraft:polished_deepslate
fill 416 120 347 416 123 347 minecraft:gray_concrete
fill 416 120 349 416 121 349 minecraft:gray_concrete
setblock 417 120 324 minecraft:gray_concrete
setblock 417 120 325 minecraft:polished_deepslate
fill 417 120 326 417 123 326 minecraft:gray_concrete
setblock 417 120 329 minecraft:gray_concrete
setblock 417 120 330 minecraft:polished_deepslate
fill 417 120 331 417 123 331 minecraft:gray_concrete
setblock 417 120 334 minecraft:gray_concrete
setblock 417 120 335 minecraft:polished_deepslate
fill 417 120 336 417 123 336 minecraft:gray_concrete
setblock 417 120 340 minecraft:polished_deepslate
fill 417 120 341 417 123 341 minecraft:gray_concrete
setblock 417 120 345 minecraft:polished_deepslate
fill 417 120 346 417 123 346 minecraft:gray_concrete
setblock 417 120 350 minecraft:polished_deepslate
fill 417 120 351 417 123 351 minecraft:gray_concrete
setblock 417 120 364 minecraft:gray_wool
fill 418 120 324 418 122 324 minecraft:black_concrete
fill 418 120 326 418 122 326 minecraft:black_concrete
fill 418 120 328 418 122 328 minecraft:black_concrete
setblock 418 120 335 minecraft:gray_wool
fill 418 120 359 418 120 360 minecraft:black_concrete
setblock 418 120 361 minecraft:light_blue_stained_glass
fill 376 121 322 377 122 322 minecraft:black_concrete
fill 376 121 330 376 122 333 minecraft:black_concrete
fill 376 121 334 376 121 335 minecraft:gray_wool
fill 376 121 344 376 122 345 minecraft:black_concrete
fill 376 121 347 376 122 349 minecraft:black_concrete
fill 376 121 350 376 121 351 minecraft:gray_wool
fill 376 121 352 376 122 354 minecraft:black_concrete
fill 376 121 364 376 122 364 minecraft:black_concrete
setblock 377 121 324 minecraft:polished_deepslate
fill 377 121 325 377 124 325 minecraft:gray_concrete
setblock 377 121 328 minecraft:gray_concrete
setblock 377 121 329 minecraft:polished_deepslate
fill 377 121 330 377 124 330 minecraft:gray_concrete
fill 377 121 332 377 121 333 minecraft:gray_concrete
setblock 377 121 334 minecraft:polished_deepslate
fill 377 121 335 377 124 335 minecraft:gray_concrete
setblock 377 121 339 minecraft:polished_deepslate
fill 377 121 340 377 124 340 minecraft:gray_concrete
setblock 377 121 344 minecraft:polished_deepslate
fill 377 121 345 377 124 345 minecraft:gray_concrete
setblock 377 121 349 minecraft:polished_deepslate
fill 377 121 350 377 122 352 minecraft:gray_concrete
setblock 378 121 323 minecraft:polished_deepslate
fill 378 121 324 378 124 324 minecraft:gray_concrete
setblock 378 121 327 minecraft:gray_concrete
setblock 378 121 328 minecraft:polished_deepslate
fill 378 121 329 378 124 329 minecraft:gray_concrete
setblock 378 121 333 minecraft:polished_deepslate
fill 378 121 334 378 124 334 minecraft:gray_concrete
setblock 378 121 343 minecraft:polished_deepslate
fill 378 121 344 378 124 344 minecraft:gray_concrete
setblock 378 121 348 minecraft:polished_deepslate
fill 378 121 349 378 124 349 minecraft:gray_concrete
setblock 378 121 363 minecraft:polished_deepslate
fill 379 121 323 379 124 323 minecraft:gray_concrete
setblock 379 121 327 minecraft:polished_deepslate
fill 379 121 328 379 124 328 minecraft:gray_concrete
setblock 379 121 331 minecraft:gray_concrete
setblock 379 121 332 minecraft:polished_deepslate
setblock 379 121 362 minecraft:polished_deepslate
fill 379 121 363 379 124 363 minecraft:gray_concrete
setblock 380 121 326 minecraft:polished_deepslate
fill 380 121 327 382 122 327 minecraft:gray_concrete
fill 380 121 329 380 121 330 minecraft:gray_concrete
fill 380 121 362 380 124 362 minecraft:gray_concrete
setblock 381 121 325 minecraft:polished_deepslate
fill 381 121 326 381 124 326 minecraft:gray_concrete
setblock 382 121 324 minecraft:polished_deepslate
fill 382 121 325 382 124 325 minecraft:gray_concrete
setblock 383 121 323 minecraft:polished_deepslate
fill 383 121 324 383 124 324 minecraft:gray_concrete
setblock 383 121 363 minecraft:polished_deepslate
fill 384 121 323 384 124 323 minecraft:gray_concrete
setblock 384 121 326 minecraft:gray_concrete
setblock 384 121 362 minecraft:polished_deepslate
fill 384 121 363 387 121 363 minecraft:gray_concrete
fill 384 121 364 384 122 364 minecraft:black_concrete
setblock 385 121 326 minecraft:polished_deepslate
fill 385 121 362 385 124 362 minecraft:gray_concrete
setblock 386 121 322 minecraft:gray_wool
setblock 386 121 325 minecraft:polished_deepslate
setblock 386 121 326 minecraft:gray_concrete
setblock 387 121 324 minecraft:polished_deepslate
fill 387 121 325 387 123 325 minecraft:gray_concrete
setblock 388 121 322 minecraft:gray_wool
setblock 388 121 323 minecraft:polished_deepslate
fill 388 121 324 388 124 324 minecraft:gray_concrete
setblock 388 121 362 minecraft:gray_concrete
setblock 388 121 363 minecraft:polished_deepslate
fill 389 121 322 389 122 322 minecraft:black_concrete
fill 389 121 323 392 121 323 minecraft:gray_concrete
fill 389 121 345 390 122 346 minecraft:white_wool
setblock 389 121 362 minecraft:polished_deepslate
fill 389 121 363 389 124 363 minecraft:gray_concrete
setblock 390 121 322 minecraft:gray_wool
setblock 392 121 324 minecraft:polished_deepslate
setblock 393 121 323 minecraft:polished_deepslate
setblock 393 121 363 minecraft:polished_deepslate
fill 394 121 323 394 124 323 minecraft:gray_concrete
fill 394 121 363 394 124 363 minecraft:gray_concrete
setblock 395 121 364 minecraft:gray_wool
setblock 396 121 324 minecraft:gray_concrete
fill 396 121 362 396 123 362 minecraft:gray_concrete
setblock 396 121 364 minecraft:light_blue_stained_glass
setblock 397 121 324 minecraft:polished_deepslate
setblock 398 121 322 minecraft:gray_wool
setblock 398 121 323 minecraft:polished_deepslate
fill 398 121 324 398 124 324 minecraft:gray_concrete
setblock 398 121 363 minecraft:polished_deepslate
fill 399 121 323 399 124 323 minecraft:gray_concrete
setblock 399 121 362 minecraft:polished_deepslate
fill 399 121 363 399 124 363 minecraft:gray_concrete
fill 400 121 362 400 124 362 minecraft:gray_concrete
setblock 401 121 325 minecraft:polished_deepslate
setblock 402 121 324 minecraft:polished_deepslate
fill 402 121 325 403 122 325 minecraft:gray_concrete
setblock 402 121 364 minecraft:gray_wool
setblock 403 121 323 minecraft:polished_deepslate
fill 403 121 324 403 124 324 minecraft:gray_concrete
setblock 403 121 363 minecraft:polished_deepslate
fill 404 121 323 404 124 323 minecraft:gray_concrete
setblock 404 121 362 minecraft:polished_deepslate
fill 404 121 363 404 124 363 minecraft:gray_concrete
setblock 405 121 362 minecraft:gray_concrete
setblock 406 121 322 minecraft:gray_wool
fill 407 121 322 407 122 322 minecraft:black_concrete
setblock 407 121 324 minecraft:polished_deepslate
setblock 408 121 323 minecraft:polished_deepslate
fill 409 121 323 409 122 323 minecraft:gray_concrete
setblock 410 121 364 minecraft:gray_wool
setblock 413 121 323 minecraft:polished_deepslate
setblock 413 121 364 minecraft:gray_wool
fill 414 121 323 414 124 323 minecraft:gray_concrete
fill 414 121 364 414 122 364 minecraft:black_concrete
fill 416 121 322 416 122 322 minecraft:black_concrete
setblock 416 121 324 minecraft:gray_concrete
setblock 416 121 325 minecraft:polished_deepslate
fill 416 121 326 416 124 326 minecraft:gray_concrete
setblock 416 121 329 minecraft:gray_concrete
setblock 416 121 330 minecraft:polished_deepslate
fill 416 121 331 416 123 332 minecraft:gray_concrete
fill 416 121 341 416 124 341 minecraft:gray_concrete
setblock 416 121 345 minecraft:polished_deepslate
fill 416 121 346 416 124 346 minecraft:gray_concrete
setblock 416 121 350 minecraft:polished_deepslate
setblock 417 121 324 minecraft:polished_deepslate
fill 417 121 325 417 124 325 minecraft:gray_concrete
setblock 417 121 329 minecraft:polished_deepslate
fill 417 121 330 417 124 330 minecraft:gray_concrete
setblock 417 121 334 minecraft:polished_deepslate
fill 417 121 335 417 124 335 minecraft:gray_concrete
setblock 417 121 339 minecraft:polished_deepslate
fill 417 121 340 417 124 340 minecraft:gray_concrete
setblock 417 121 344 minecraft:polished_deepslate
fill 417 121 345 417 124 345 minecraft:gray_concrete
setblock 417 121 348 minecraft:gray_concrete
setblock 417 121 349 minecraft:polished_deepslate
fill 417 121 350 417 124 350 minecraft:gray_concrete
fill 417 121 352 417 121 353 minecraft:gray_concrete
fill 417 121 364 417 124 364 minecraft:black_concrete
fill 418 121 335 418 122 336 minecraft:black_concrete
setblock 418 121 337 minecraft:gray_wool
fill 418 121 338 418 121 339 minecraft:black_concrete
fill 418 121 343 418 122 346 minecraft:black_concrete
setblock 418 121 347 minecraft:gray_wool
setblock 418 121 349 minecraft:gray_wool
fill 418 121 350 418 122 350 minecraft:black_concrete
setblock 418 121 351 minecraft:gray_wool
fill 418 121 352 418 122 352 minecraft:black_concrete
setblock 418 121 353 minecraft:gray_wool
fill 418 121 354 418 122 354 minecraft:black_concrete
fill 418 121 359 418 122 359 minecraft:black_concrete
setblock 418 121 360 minecraft:gray_wool
fill 418 121 361 418 122 361 minecraft:black_concrete
fill 376 122 334 376 122 335 minecraft:black_concrete
setblock 376 122 341 minecraft:black_concrete
fill 376 122 350 376 122 351 minecraft:black_concrete
setblock 377 122 323 minecraft:polished_deepslate
fill 377 122 324 377 125 324 minecraft:gray_concrete
setblock 377 122 328 minecraft:polished_deepslate
fill 377 122 329 377 125 329 minecraft:gray_concrete
setblock 377 122 332 minecraft:gray_concrete
setblock 377 122 333 minecraft:polished_deepslate
fill 377 122 334 377 125 334 minecraft:gray_concrete
fill 377 122 336 377 122 337 minecraft:gray_concrete
setblock 377 122 338 minecraft:polished_deepslate
fill 377 122 339 377 125 339 minecraft:gray_concrete
setblock 377 122 343 minecraft:polished_deepslate
fill 377 122 344 377 125 344 minecraft:gray_concrete
setblock 377 122 347 minecraft:gray_concrete
setblock 377 122 348 minecraft:polished_deepslate
fill 377 122 349 377 125 349 minecraft:gray_concrete
setblock 377 122 353 minecraft:polished_deepslate
fill 377 122 354 377 125 354 minecraft:gray_concrete
fill 377 122 361 377 123 361 minecraft:gray_concrete
setblock 377 122 363 minecraft:polished_deepslate
fill 378 122 323 378 125 323 minecraft:gray_concrete
setblock 378 122 327 minecraft:polished_deepslate
fill 378 122 328 378 125 328 minecraft:gray_concrete
setblock 378 122 332 minecraft:polished_deepslate
fill 378 122 333 379 124 333 minecraft:gray_concrete
fill 378 122 335 378 123 335 minecraft:gray_concrete
fill 378 122 343 378 123 343 minecraft:gray_concrete
setblock 378 122 347 minecraft:polished_deepslate
fill 378 122 348 378 125 348 minecraft:gray_concrete
fill 378 122 350 378 122 351 minecraft:gray_concrete
fill 378 122 363 378 125 363 minecraft:gray_concrete
setblock 379 122 326 minecraft:polished_deepslate
fill 379 122 327 379 125 327 minecraft:gray_concrete
setblock 379 122 331 minecraft:polished_deepslate
fill 379 122 332 379 125 332 minecraft:gray_concrete
setblock 379 122 339 minecraft:light[level=12]
setblock 379 122 346 minecraft:light[level=12]
setblock 379 122 353 minecraft:light[level=12]
setblock 379 122 360 minecraft:light[level=12]
fill 379 122 362 379 125 362 minecraft:gray_concrete
setblock 380 122 325 minecraft:polished_deepslate
fill 380 122 326 380 125 326 minecraft:gray_concrete
setblock 380 122 329 minecraft:gray_concrete
setblock 380 122 330 minecraft:polished_deepslate
setblock 381 122 324 minecraft:polished_deepslate
fill 381 122 325 381 125 325 minecraft:gray_concrete
setblock 381 122 328 minecraft:gray_concrete
setblock 382 122 323 minecraft:polished_deepslate
fill 382 122 324 382 125 324 minecraft:gray_concrete
setblock 382 122 363 minecraft:polished_deepslate
fill 383 122 323 383 125 323 minecraft:gray_concrete
setblock 383 122 362 minecraft:polished_deepslate
fill 383 122 363 386 122 363 minecraft:gray_concrete
setblock 384 122 326 minecraft:polished_deepslate
fill 384 122 362 384 125 362 minecraft:gray_concrete
setblock 385 122 325 minecraft:polished_deepslate
fill 385 122 326 385 123 326 minecraft:gray_concrete
setblock 386 122 322 minecraft:black_concrete
setblock 386 122 324 minecraft:polished_deepslate
fill 386 122 325 386 124 325 minecraft:gray_concrete
setblock 386 122 332 minecraft:light[level=12]
setblock 386 122 339 minecraft:light[level=12]
setblock 386 122 346 minecraft:light[level=12]
setblock 386 122 353 minecraft:light[level=12]
setblock 386 122 360 minecraft:light[level=12]
setblock 387 122 323 minecraft:polished_deepslate
fill 387 122 324 387 125 324 minecraft:gray_concrete
setblock 387 122 363 minecraft:polished_deepslate
setblock 388 122 322 minecraft:black_concrete
fill 388 122 323 391 122 323 minecraft:gray_concrete
setblock 388 122 362 minecraft:polished_deepslate
fill 388 122 363 388 125 363 minecraft:gray_concrete
setblock 390 122 322 minecraft:black_concrete
setblock 391 122 324 minecraft:polished_deepslate
setblock 392 122 323 minecraft:polished_deepslate
setblock 392 122 363 minecraft:polished_deepslate
setblock 392 122 364 minecraft:black_concrete
fill 393 122 323 393 125 323 minecraft:gray_concrete
setblock 393 122 325 minecraft:light[level=12]
setblock 393 122 332 minecraft:light[level=12]
setblock 393 122 339 minecraft:light[level=12]
setblock 393 122 346 minecraft:light[level=12]
setblock 393 122 353 minecraft:light[level=12]
setblock 393 122 360 minecraft:light[level=12]
fill 393 122 363 393 125 363 minecraft:gray_concrete
setblock 393 122 364 minecraft:light_blue_stained_glass
fill 394 122 364 396 122 364 minecraft:black_concrete
setblock 395 122 324 minecraft:gray_concrete
setblock 396 122 324 minecraft:polished_deepslate
setblock 397 122 322 minecraft:light_blue_stained_glass
setblock 397 122 323 minecraft:polished_deepslate
fill 397 122 324 397 125 324 minecraft:gray_concrete
setblock 397 122 363 minecraft:polished_deepslate
fill 398 122 322 398 123 322 minecraft:black_concrete
fill 398 122 323 398 125 323 minecraft:gray_concrete
setblock 398 122 362 minecraft:polished_deepslate
fill 398 122 363 398 125 363 minecraft:gray_concrete
fill 399 122 362 399 125 362 minecraft:gray_concrete
setblock 400 122 325 minecraft:polished_deepslate
setblock 400 122 332 minecraft:light[level=12]
setblock 400 122 339 minecraft:light[level=12]
setblock 400 122 346 minecraft:light[level=12]
setblock 400 122 353 minecraft:light[level=12]
setblock 400 122 360 minecraft:light[level=12]
setblock 401 122 324 minecraft:polished_deepslate
fill 401 122 325 401 123 325 minecraft:gray_concrete
setblock 402 122 323 minecraft:polished_deepslate
fill 402 122 324 402 125 324 minecraft:gray_concrete
setblock 402 122 363 minecraft:polished_deepslate
setblock 402 122 364 minecraft:black_concrete
fill 403 122 323 403 125 323 minecraft:gray_concrete
setblock 403 122 362 minecraft:polished_deepslate
fill 403 122 363 403 125 363 minecraft:gray_concrete
setblock 404 122 362 minecraft:gray_concrete
setblock 406 122 322 minecraft:black_concrete
setblock 406 122 324 minecraft:polished_deepslate
setblock 407 122 323 minecraft:polished_deepslate
setblock 407 122 325 minecraft:light[level=12]
setblock 407 122 332 minecraft:light[level=12]
setblock 407 122 339 minecraft:light[level=12]
setblock 407 122 346 minecraft:light[level=12]
setblock 407 122 353 minecraft:light[level=12]
setblock 407 122 360 minecraft:light[level=12]
setblock 407 122 363 minecraft:polished_deepslate
fill 408 122 323 408 123 323 minecraft:gray_concrete
fill 410 122 364 410 123 364 minecraft:black_concrete
fill 413 122 323 413 124 323 minecraft:gray_concrete
setblock 413 122 364 minecraft:black_concrete
setblock 414 122 325 minecraft:light[level=12]
setblock 414 122 332 minecraft:light[level=12]
setblock 414 122 339 minecraft:light[level=12]
setblock 414 122 346 minecraft:light[level=12]
setblock 414 122 353 minecraft:light[level=12]
setblock 414 122 360 minecraft:light[level=12]
setblock 415 122 324 minecraft:gray_concrete
setblock 416 122 323 minecraft:gray_concrete
setblock 416 122 324 minecraft:polished_deepslate
fill 416 122 325 416 125 325 minecraft:gray_concrete
setblock 416 122 329 minecraft:polished_deepslate
fill 416 122 330 416 125 330 minecraft:gray_concrete
setblock 416 122 333 minecraft:gray_concrete
setblock 416 122 334 minecraft:polished_deepslate
fill 416 122 340 416 124 340 minecraft:gray_concrete
setblock 416 122 344 minecraft:polished_deepslate
fill 416 122 345 416 125 345 minecraft:gray_concrete
setblock 416 122 349 minecraft:polished_deepslate
fill 416 122 350 416 124 351 minecraft:gray_concrete
setblock 417 122 323 minecraft:polished_deepslate
fill 417 122 324 417 125 324 minecraft:gray_concrete
setblock 417 122 328 minecraft:polished_deepslate
fill 417 122 329 417 125 329 minecraft:gray_concrete
setblock 417 122 332 minecraft:gray_concrete
setblock 417 122 333 minecraft:polished_deepslate
fill 417 122 334 417 125 334 minecraft:gray_concrete
setblock 417 122 338 minecraft:polished_deepslate
fill 417 122 339 417 125 339 minecraft:gray_concrete
setblock 417 122 343 minecraft:polished_deepslate
fill 417 122 344 417 125 344 minecraft:gray_concrete
setblock 417 122 348 minecraft:polished_deepslate
fill 417 122 349 417 125 349 minecraft:gray_concrete
setblock 417 122 352 minecraft:gray_concrete
setblock 417 122 353 minecraft:polished_deepslate
fill 417 122 354 417 125 354 minecraft:gray_concrete
fill 418 122 337 418 122 338 minecraft:black_concrete
setblock 418 122 339 minecraft:light_blue_stained_glass
setblock 418 122 347 minecraft:black_concrete
fill 418 122 349 418 123 349 minecraft:black_concrete
setblock 418 122 351 minecraft:black_concrete
setblock 418 122 353 minecraft:black_concrete
setblock 418 122 360 minecraft:black_concrete
fill 376 123 322 378 123 322 minecraft:gray_wool
fill 376 123 324 376 151 333 minecraft:gray_wool
setblock 376 123 334 minecraft:black_concrete
fill 376 123 335 376 123 336 minecraft:gray_wool
setblock 376 123 337 minecraft:black_concrete
fill 376 123 338 376 124 343 minecraft:gray_wool
setblock 376 123 344 minecraft:light_blue_stained_glass
fill 376 123 345 376 123 351 minecraft:gray_wool
setblock 376 123 352 minecraft:black_concrete
fill 376 123 353 376 123 364 minecraft:gray_wool
fill 377 123 323 377 126 323 minecraft:gray_concrete
setblock 377 123 327 minecraft:polished_deepslate
fill 377 123 328 377 126 328 minecraft:gray_concrete
setblock 377 123 332 minecraft:polished_deepslate
fill 377 123 333 377 126 333 minecraft:gray_concrete
setblock 377 123 336 minecraft:gray_concrete
setblock 377 123 337 minecraft:polished_deepslate
fill 377 123 338 377 126 338 minecraft:gray_concrete
setblock 377 123 342 minecraft:polished_deepslate
fill 377 123 343 377 126 343 minecraft:gray_concrete
setblock 377 123 346 minecraft:gray_concrete
setblock 377 123 347 minecraft:polished_deepslate
fill 377 123 348 377 126 348 minecraft:gray_concrete
fill 377 123 350 377 123 351 minecraft:gray_concrete
setblock 377 123 352 minecraft:polished_deepslate
fill 377 123 353 378 125 353 minecraft:gray_concrete
fill 377 123 355 377 123 356 minecraft:gray_concrete
fill 377 123 360 377 124 360 minecraft:gray_concrete
setblock 377 123 362 minecraft:polished_deepslate
fill 377 123 363 377 126 363 minecraft:gray_concrete
fill 377 123 364 385 124 364 minecraft:gray_wool
setblock 378 123 326 minecraft:polished_deepslate
fill 378 123 327 378 126 327 minecraft:gray_concrete
setblock 378 123 330 minecraft:gray_concrete
setblock 378 123 331 minecraft:polished_deepslate
fill 378 123 332 378 126 332 minecraft:gray_concrete
setblock 378 123 336 minecraft:polished_deepslate
setblock 378 123 346 minecraft:polished_deepslate
fill 378 123 347 378 126 347 minecraft:gray_concrete
setblock 378 123 350 minecraft:gray_concrete
setblock 378 123 351 minecraft:polished_deepslate
fill 378 123 352 378 126 352 minecraft:gray_concrete
fill 378 123 362 378 125 362 minecraft:gray_concrete
setblock 379 123 325 minecraft:polished_deepslate
fill 379 123 326 379 126 326 minecraft:gray_concrete
setblock 379 123 330 minecraft:polished_deepslate
fill 379 123 331 380 125 331 minecraft:gray_concrete
fill 379 123 348 379 123 349 minecraft:gray_concrete
setblock 380 123 322 minecraft:gray_wool
setblock 380 123 324 minecraft:polished_deepslate
fill 380 123 325 380 126 325 minecraft:gray_concrete
fill 380 123 327 381 123 327 minecraft:gray_concrete
setblock 380 123 329 minecraft:polished_deepslate
fill 380 123 330 380 126 330 minecraft:gray_concrete
setblock 381 123 322 minecraft:black_concrete
setblock 381 123 323 minecraft:polished_deepslate
fill 381 123 324 381 126 324 minecraft:gray_concrete
setblock 381 123 328 minecraft:polished_deepslate
setblock 381 123 363 minecraft:polished_deepslate
fill 382 123 322 394 123 322 minecraft:gray_wool
fill 382 123 323 382 126 323 minecraft:gray_concrete
setblock 382 123 327 minecraft:polished_deepslate
setblock 382 123 362 minecraft:polished_deepslate
fill 382 123 363 385 123 363 minecraft:gray_concrete
setblock 383 123 326 minecraft:polished_deepslate
fill 383 123 362 383 125 362 minecraft:gray_concrete
setblock 384 123 325 minecraft:polished_deepslate
fill 384 123 326 384 124 326 minecraft:gray_concrete
setblock 385 123 324 minecraft:polished_deepslate
fill 385 123 325 385 125 325 minecraft:gray_concrete
setblock 386 123 323 minecraft:polished_deepslate
fill 386 123 324 386 125 324 minecraft:gray_concrete
setblock 386 123 363 minecraft:polished_deepslate
fill 387 123 323 390 123 323 minecraft:gray_concrete
setblock 387 123 362 minecraft:polished_deepslate
fill 387 123 363 387 125 363 minecraft:gray_concrete
fill 388 123 364 389 124 364 minecraft:gray_wool
setblock 390 123 324 minecraft:polished_deepslate
setblock 391 123 323 minecraft:polished_deepslate
setblock 391 123 363 minecraft:polished_deepslate
fill 391 123 364 399 123 364 minecraft:gray_wool
fill 392 123 323 392 124 323 minecraft:gray_concrete
fill 392 123 363 392 125 363 minecraft:gray_concrete
setblock 395 123 324 minecraft:polished_deepslate
fill 396 123 322 397 170 322 minecraft:gray_wool
setblock 396 123 323 minecraft:polished_deepslate
fill 396 123 324 396 124 324 minecraft:gray_concrete
setblock 396 123 363 minecraft:polished_deepslate
fill 397 123 323 397 126 323 minecraft:gray_concrete
setblock 397 123 362 minecraft:polished_deepslate
fill 397 123 363 397 126 363 minecraft:gray_concrete
fill 398 123 362 398 125 362 minecraft:gray_concrete
fill 399 123 322 401 124 322 minecraft:gray_wool
setblock 400 123 324 minecraft:polished_deepslate
setblock 400 123 325 minecraft:gray_concrete
setblock 401 123 323 minecraft:polished_deepslate
fill 401 123 324 401 125 324 minecraft:gray_concrete
fill 401 123 326 402 124 326 minecraft:white_wool
setblock 401 123 363 minecraft:polished_deepslate
fill 401 123 364 405 123 364 minecraft:gray_wool
fill 402 123 322 402 125 322 minecraft:black_concrete
fill 402 123 323 402 126 323 minecraft:gray_concrete
setblock 402 123 325 minecraft:gray_concrete
setblock 402 123 362 minecraft:polished_deepslate
fill 402 123 363 402 126 363 minecraft:gray_concrete
fill 403 123 322 409 123 322 minecraft:gray_wool
fill 403 123 325 403 124 325 minecraft:white_wool
setblock 403 123 362 minecraft:gray_concrete
setblock 405 123 324 minecraft:polished_deepslate
setblock 406 123 323 minecraft:polished_deepslate
setblock 406 123 363 minecraft:polished_deepslate
setblock 406 123 364 minecraft:light_blue_stained_glass
setblock 407 123 323 minecraft:gray_concrete
fill 407 123 364 409 123 364 minecraft:gray_wool
fill 411 123 322 417 123 322 minecraft:gray_wool
fill 411 123 364 416 123 364 minecraft:gray_wool
setblock 415 123 324 minecraft:polished_deepslate
fill 415 123 327 415 123 328 minecraft:gray_concrete
setblock 415 123 329 minecraft:polished_deepslate
fill 415 123 330 415 126 330 minecraft:gray_concrete
setblock 416 123 323 minecraft:polished_deepslate
fill 416 123 324 416 126 324 minecraft:gray_concrete
setblock 416 123 327 minecraft:gray_concrete
setblock 416 123 328 minecraft:polished_deepslate
fill 416 123 329 416 126 329 minecraft:gray_concrete
setblock 416 123 333 minecraft:polished_deepslate
fill 416 123 334 416 123 337 minecraft:gray_concrete
setblock 416 123 343 minecraft:polished_deepslate
fill 416 123 344 416 125 344 minecraft:gray_concrete
setblock 416 123 348 minecraft:polished_deepslate
fill 416 123 349 416 126 349 minecraft:gray_concrete
setblock 416 123 352 minecraft:gray_concrete
fill 417 123 323 417 126 323 minecraft:gray_concrete
setblock 417 123 327 minecraft:polished_deepslate
fill 417 123 328 417 126 328 minecraft:gray_concrete
setblock 417 123 332 minecraft:polished_deepslate
fill 417 123 333 417 126 333 minecraft:gray_concrete
setblock 417 123 337 minecraft:polished_deepslate
fill 417 123 338 417 126 338 minecraft:gray_concrete
setblock 417 123 342 minecraft:polished_deepslate
fill 417 123 343 417 126 343 minecraft:gray_concrete
setblock 417 123 347 minecraft:polished_deepslate
fill 417 123 348 417 126 348 minecraft:gray_concrete
setblock 417 123 352 minecraft:polished_deepslate
fill 417 123 353 417 126 353 minecraft:gray_concrete
fill 417 123 355 417 124 355 minecraft:gray_concrete
fill 418 123 323 418 123 336 minecraft:gray_wool
setblock 418 123 337 minecraft:light_blue_stained_glass
fill 418 123 338 418 123 341 minecraft:gray_wool
fill 418 123 343 418 123 348 minecraft:gray_wool
fill 418 123 350 418 123 362 minecraft:gray_wool
setblock 376 124 322 minecraft:black_concrete
fill 376 124 323 376 184 323 minecraft:gray_wool
fill 376 124 334 376 182 335 minecraft:gray_wool
setblock 376 124 336 minecraft:black_concrete
fill 376 124 337 376 127 337 minecraft:gray_wool
setblock 376 124 344 minecraft:black_concrete
fill 376 124 345 376 124 349 minecraft:gray_wool
fill 376 124 350 376 125 350 minecraft:black_concrete
fill 376 124 351 376 124 361 minecraft:gray_wool
setblock 376 124 362 minecraft:black_concrete
fill 376 124 363 376 136 364 minecraft:gray_wool
fill 377 124 322 379 147 322 minecraft:gray_wool
setblock 377 124 326 minecraft:polished_deepslate
fill 377 124 327 377 127 327 minecraft:gray_concrete
setblock 377 124 331 minecraft:polished_deepslate
fill 377 124 332 377 127 332 minecraft:gray_concrete
setblock 377 124 336 minecraft:polished_deepslate
fill 377 124 337 377 127 337 minecraft:gray_concrete
setblock 377 124 341 minecraft:polished_deepslate
fill 377 124 342 377 125 342 minecraft:gray_concrete
setblock 377 124 346 minecraft:polished_deepslate
fill 377 124 347 377 127 347 minecraft:gray_concrete
setblock 377 124 350 minecraft:gray_concrete
setblock 377 124 351 minecraft:polished_deepslate
fill 377 124 352 377 127 352 minecraft:gray_concrete
setblock 377 124 355 minecraft:gray_concrete
setblock 377 124 356 minecraft:polished_deepslate
fill 377 124 357 377 125 359 minecraft:gray_concrete
setblock 377 124 361 minecraft:polished_deepslate
fill 377 124 362 377 127 362 minecraft:gray_concrete
setblock 378 124 325 minecraft:polished_deepslate
fill 378 124 326 378 127 326 minecraft:gray_concrete
setblock 378 124 330 minecraft:polished_deepslate
fill 378 124 331 378 127 331 minecraft:gray_concrete
setblock 378 124 335 minecraft:polished_deepslate
fill 378 124 336 378 127 336 minecraft:gray_concrete
setblock 378 124 345 minecraft:polished_deepslate
fill 378 124 346 378 125 346 minecraft:gray_concrete
setblock 378 124 350 minecraft:polished_deepslate
fill 378 124 351 379 125 351 minecraft:gray_concrete
setblock 378 124 354 minecraft:gray_concrete
setblock 378 124 355 minecraft:polished_deepslate
setblock 379 124 324 minecraft:polished_deepslate
fill 379 124 325 379 127 325 minecraft:gray_concrete
setblock 379 124 329 minecraft:polished_deepslate
fill 379 124 330 379 127 330 minecraft:gray_concrete
setblock 379 124 334 minecraft:polished_deepslate
setblock 379 124 349 minecraft:polished_deepslate
fill 379 124 350 379 125 350 minecraft:gray_concrete
setblock 380 124 322 minecraft:black_concrete
setblock 380 124 323 minecraft:polished_deepslate
fill 380 124 324 380 127 324 minecraft:gray_concrete
setblock 380 124 327 minecraft:gray_concrete
setblock 380 124 328 minecraft:polished_deepslate
fill 380 124 329 380 127 329 minecraft:gray_concrete
fill 380 124 338 382 125 338 minecraft:white_wool
setblock 380 124 363 minecraft:polished_deepslate
fill 381 124 322 383 151 322 minecraft:gray_wool
fill 381 124 323 381 127 323 minecraft:gray_concrete
setblock 381 124 327 minecraft:polished_deepslate
setblock 381 124 328 minecraft:gray_concrete
fill 381 124 337 381 125 337 minecraft:white_wool
fill 381 124 339 381 125 339 minecraft:white_wool
setblock 381 124 362 minecraft:polished_deepslate
fill 381 124 363 384 124 363 minecraft:gray_concrete
setblock 382 124 326 minecraft:polished_deepslate
fill 382 124 362 382 126 362 minecraft:gray_concrete
setblock 383 124 325 minecraft:polished_deepslate
fill 383 124 326 383 125 326 minecraft:gray_concrete
setblock 384 124 322 minecraft:black_concrete
setblock 384 124 324 minecraft:polished_deepslate
fill 384 124 325 384 125 325 minecraft:gray_concrete
fill 385 124 322 395 124 322 minecraft:gray_wool
setblock 385 124 323 minecraft:polished_deepslate
fill 385 124 324 385 126 324 minecraft:gray_concrete
setblock 385 124 363 minecraft:polished_deepslate
fill 386 124 323 389 124 323 minecraft:gray_concrete
fill 386 124 363 386 126 363 minecraft:gray_concrete
fill 386 124 364 387 154 364 minecraft:gray_wool
setblock 390 124 323 minecraft:polished_deepslate
setblock 390 124 363 minecraft:polished_deepslate
fill 390 124 364 394 124 364 minecraft:gray_wool
setblock 391 124 323 minecraft:gray_concrete
setblock 391 124 363 minecraft:gray_concrete
setblock 395 124 323 minecraft:polished_deepslate
setblock 395 124 363 minecraft:polished_deepslate
setblock 395 124 364 minecraft:light_blue_stained_glass
fill 396 124 323 396 126 323 minecraft:gray_concrete
fill 396 124 363 396 127 363 minecraft:gray_concrete
fill 396 124 364 404 124 364 minecraft:gray_wool
setblock 397 124 362 minecraft:gray_concrete
fill 398 124 322 398 181 322 minecraft:gray_wool
setblock 399 124 324 minecraft:polished_deepslate
setblock 400 124 323 minecraft:polished_deepslate
fill 400 124 324 400 125 324 minecraft:gray_concrete
setblock 400 124 363 minecraft:polished_deepslate
fill 401 124 323 401 126 323 minecraft:gray_concrete
fill 401 124 325 402 124 325 minecraft:white_wool
setblock 401 124 362 minecraft:polished_deepslate
fill 401 124 363 401 126 363 minecraft:gray_concrete
setblock 402 124 362 minecraft:gray_concrete
setblock 403 124 322 minecraft:black_concrete
fill 404 124 322 406 149 322 minecraft:gray_wool
setblock 404 124 324 minecraft:polished_deepslate
setblock 405 124 323 minecraft:polished_deepslate
setblock 405 124 364 minecraft:black_concrete
setblock 406 124 323 minecraft:gray_concrete
fill 406 124 364 406 184 364 minecraft:gray_wool
setblock 407 124 322 minecraft:black_concrete
setblock 407 124 364 minecraft:black_concrete
fill 408 124 322 416 124 322 minecraft:gray_wool
fill 408 124 364 413 138 364 minecraft:gray_wool
fill 414 124 364 414 125 364 minecraft:black_concrete
setblock 415 124 323 minecraft:polished_deepslate
fill 415 124 324 415 126 324 minecraft:gray_concrete
fill 415 124 326 415 124 327 minecraft:gray_concrete
setblock 415 124 328 minecraft:polished_deepslate
fill 415 124 329 415 127 329 minecraft:gray_concrete
fill 415 124 331 415 124 332 minecraft:gray_concrete
fill 415 124 364 416 124 364 minecraft:gray_wool
fill 416 124 323 416 127 323 minecraft:gray_concrete
setblock 416 124 327 minecraft:polished_deepslate
fill 416 124 328 416 127 328 minecraft:gray_concrete
setblock 416 124 331 minecraft:gray_concrete
setblock 416 124 332 minecraft:polished_deepslate
fill 416 124 333 416 124 336 minecraft:gray_concrete
setblock 416 124 337 minecraft:polished_deepslate
fill 416 124 338 416 127 338 minecraft:gray_concrete
setblock 416 124 342 minecraft:polished_deepslate
fill 416 124 343 416 125 343 minecraft:gray_concrete
setblock 416 124 347 minecraft:polished_deepslate
fill 416 124 348 416 127 348 minecraft:gray_concrete
setblock 416 124 352 minecraft:polished_deepslate
setblock 417 124 322 minecraft:black_concrete
setblock 417 124 326 minecraft:polished_deepslate
fill 417 124 327 417 127 327 minecraft:gray_concrete
setblock 417 124 331 minecraft:polished_deepslate
fill 417 124 332 417 127 332 minecraft:gray_concrete
setblock 417 124 336 minecraft:polished_deepslate
fill 417 124 337 417 127 337 minecraft:gray_concrete
setblock 417 124 341 minecraft:polished_deepslate
fill 417 124 342 417 127 342 minecraft:gray_concrete
setblock 417 124 346 minecraft:polished_deepslate
fill 417 124 347 417 127 347 minecraft:gray_concrete
setblock 417 124 351 minecraft:polished_deepslate
fill 417 124 352 417 127 352 minecraft:gray_concrete
setblock 417 124 356 minecraft:polished_deepslate
fill 418 124 322 418 124 335 minecraft:gray_wool
setblock 418 124 336 minecraft:black_concrete
fill 418 124 337 418 184 337 minecraft:gray_wool
setblock 418 124 338 minecraft:black_concrete
fill 418 124 339 418 141 344 minecraft:gray_wool
setblock 418 124 345 minecraft:black_concrete
fill 418 124 346 418 124 351 minecraft:gray_wool
setblock 418 124 352 minecraft:black_concrete
fill 418 124 353 418 124 357 minecraft:gray_wool
setblock 418 124 358 minecraft:light_blue_stained_glass
fill 418 124 359 418 124 362 minecraft:gray_wool
setblock 418 124 364 minecraft:gray_wool
fill 376 125 322 376 185 322 minecraft:gray_wool
fill 376 125 336 376 184 336 minecraft:gray_wool
setblock 376 125 338 minecraft:black_concrete
fill 376 125 339 376 130 339 minecraft:gray_wool
setblock 376 125 340 minecraft:black_concrete
fill 376 125 341 376 139 348 minecraft:gray_wool
setblock 376 125 349 minecraft:black_concrete
fill 376 125 351 376 184 352 minecraft:gray_wool
setblock 376 125 353 minecraft:light_blue_stained_glass
fill 376 125 354 376 153 359 minecraft:gray_wool
fill 376 125 360 376 125 361 minecraft:black_concrete
fill 376 125 362 376 180 362 minecraft:gray_wool
setblock 377 125 325 minecraft:polished_deepslate
fill 377 125 326 377 128 326 minecraft:gray_concrete
setblock 377 125 330 minecraft:polished_deepslate
fill 377 125 331 377 128 331 minecraft:gray_concrete
setblock 377 125 335 minecraft:polished_deepslate
fill 377 125 336 377 128 336 minecraft:gray_concrete
setblock 377 125 340 minecraft:polished_deepslate
setblock 377 125 341 minecraft:gray_concrete
setblock 377 125 345 minecraft:polished_deepslate
fill 377 125 346 377 127 346 minecraft:gray_concrete
setblock 377 125 350 minecraft:polished_deepslate
fill 377 125 351 377 128 351 minecraft:gray_concrete
setblock 377 125 355 minecraft:polished_deepslate
fill 377 125 356 378 127 356 minecraft:gray_concrete
setblock 377 125 360 minecraft:polished_deepslate
fill 377 125 361 377 128 361 minecraft:gray_concrete
fill 377 125 364 381 145 364 minecraft:gray_wool
setblock 378 125 324 minecraft:polished_deepslate
fill 378 125 325 378 128 325 minecraft:gray_concrete
setblock 378 125 329 minecraft:polished_deepslate
fill 378 125 330 378 128 330 minecraft:gray_concrete
setblock 378 125 333 minecraft:gray_concrete
setblock 378 125 334 minecraft:polished_deepslate
fill 378 125 335 378 128 335 minecraft:gray_concrete
setblock 378 125 349 minecraft:polished_deepslate
fill 378 125 350 378 128 350 minecraft:gray_concrete
setblock 378 125 354 minecraft:polished_deepslate
fill 378 125 355 378 128 355 minecraft:gray_concrete
setblock 379 125 323 minecraft:polished_deepslate
fill 379 125 324 379 128 324 minecraft:gray_concrete
setblock 379 125 328 minecraft:polished_deepslate
fill 379 125 329 379 128 329 minecraft:gray_concrete
setblock 379 125 333 minecraft:polished_deepslate
fill 379 125 334 379 126 334 minecraft:gray_concrete
setblock 379 125 352 minecraft:gray_concrete
setblock 379 125 363 minecraft:polished_deepslate
fill 380 125 322 380 131 322 minecraft:gray_wool
fill 380 125 323 380 128 323 minecraft:gray_concrete
setblock 380 125 327 minecraft:polished_deepslate
fill 380 125 328 380 127 328 minecraft:gray_concrete
setblock 380 125 362 minecraft:polished_deepslate
fill 380 125 363 383 125 363 minecraft:gray_concrete
setblock 381 125 326 minecraft:polished_deepslate
fill 381 125 362 381 126 362 minecraft:gray_concrete
setblock 382 125 325 minecraft:polished_deepslate
setblock 382 125 326 minecraft:gray_concrete
fill 382 125 364 383 125 364 minecraft:black_concrete
setblock 383 125 324 minecraft:polished_deepslate
fill 383 125 325 383 126 325 minecraft:gray_concrete
fill 384 125 322 390 169 322 minecraft:gray_wool
setblock 384 125 323 minecraft:polished_deepslate
fill 384 125 324 384 126 324 minecraft:gray_concrete
setblock 384 125 363 minecraft:polished_deepslate
fill 384 125 364 385 133 364 minecraft:gray_wool
fill 385 125 323 388 125 323 minecraft:gray_concrete
fill 385 125 363 385 127 363 minecraft:gray_concrete
fill 388 125 364 388 145 364 minecraft:gray_wool
setblock 389 125 323 minecraft:polished_deepslate
setblock 389 125 363 minecraft:polished_deepslate
setblock 389 125 364 minecraft:black_concrete
setblock 390 125 323 minecraft:gray_concrete
fill 390 125 364 391 127 364 minecraft:gray_wool
setblock 391 125 322 minecraft:black_concrete
fill 392 125 322 395 174 322 minecraft:gray_wool
fill 392 125 364 393 125 364 minecraft:black_concrete
setblock 394 125 323 minecraft:polished_deepslate
setblock 394 125 363 minecraft:polished_deepslate
fill 394 125 364 397 126 364 minecraft:gray_wool
fill 395 125 323 395 126 323 minecraft:gray_concrete
fill 395 125 363 395 128 363 minecraft:gray_concrete
setblock 398 125 324 minecraft:polished_deepslate
setblock 398 125 364 minecraft:light_blue_stained_glass
fill 399 125 322 399 128 322 minecraft:gray_wool
setblock 399 125 323 minecraft:polished_deepslate
setblock 399 125 324 minecraft:gray_concrete
setblock 399 125 363 minecraft:polished_deepslate
fill 399 125 364 400 185 364 minecraft:gray_wool
setblock 400 125 322 minecraft:black_concrete
fill 400 125 323 400 127 323 minecraft:gray_concrete
setblock 400 125 362 minecraft:polished_deepslate
fill 400 125 363 400 127 363 minecraft:gray_concrete
fill 401 125 322 401 185 322 minecraft:gray_wool
setblock 401 125 364 minecraft:black_concrete
fill 402 125 364 405 145 364 minecraft:gray_wool
fill 403 125 322 403 145 322 minecraft:gray_wool
setblock 404 125 323 minecraft:polished_deepslate
fill 407 125 322 412 125 322 minecraft:gray_wool
fill 407 125 364 407 181 364 minecraft:gray_wool
fill 408 125 323 410 128 324 minecraft:light_blue_stained_glass
fill 409 125 325 409 128 325 minecraft:light_blue_stained_glass
fill 409 125 338 410 126 338 minecraft:white_wool
fill 410 125 337 410 126 337 minecraft:white_wool
setblock 413 125 322 minecraft:light_blue_stained_glass
fill 414 125 322 418 150 322 minecraft:gray_wool
setblock 414 125 323 minecraft:polished_deepslate
fill 415 125 323 415 128 323 minecraft:gray_concrete
setblock 415 125 326 minecraft:gray_concrete
setblock 415 125 327 minecraft:polished_deepslate
fill 415 125 328 415 128 328 minecraft:gray_concrete
setblock 415 125 331 minecraft:gray_concrete
setblock 415 125 332 minecraft:polished_deepslate
fill 415 125 333 416 127 333 minecraft:gray_concrete
fill 415 125 364 415 162 364 minecraft:gray_wool
setblock 416 125 326 minecraft:polished_deepslate
fill 416 125 327 416 128 327 minecraft:gray_concrete
setblock 416 125 331 minecraft:polished_deepslate
fill 416 125 332 416 128 332 minecraft:gray_concrete
fill 416 125 334 416 125 335 minecraft:gray_concrete
setblock 416 125 336 minecraft:polished_deepslate
fill 416 125 337 416 128 337 minecraft:gray_concrete
setblock 416 125 346 minecraft:polished_deepslate
fill 416 125 347 416 127 347 minecraft:gray_concrete
setblock 416 125 350 minecraft:gray_concrete
setblock 416 125 351 minecraft:polished_deepslate
fill 416 125 352 416 127 353 minecraft:gray_concrete
setblock 416 125 364 minecraft:black_concrete
setblock 417 125 325 minecraft:polished_deepslate
fill 417 125 326 417 128 326 minecraft:gray_concrete
setblock 417 125 330 minecraft:polished_deepslate
fill 417 125 331 417 128 331 minecraft:gray_concrete
setblock 417 125 335 minecraft:polished_deepslate
fill 417 125 336 417 128 336 minecraft:gray_concrete
setblock 417 125 340 minecraft:polished_deepslate
fill 417 125 341 417 128 341 minecraft:gray_concrete
setblock 417 125 345 minecraft:polished_deepslate
fill 417 125 346 417 128 346 minecraft:gray_concrete
setblock 417 125 350 minecraft:polished_deepslate
fill 417 125 351 417 128 351 minecraft:gray_concrete
setblock 417 125 355 minecraft:polished_deepslate
fill 417 125 356 417 128 356 minecraft:gray_concrete
fill 417 125 364 417 184 364 minecraft:gray_wool
fill 418 125 323 418 134 323 minecraft:gray_wool
setblock 418 125 324 minecraft:black_concrete
fill 418 125 325 418 129 330 minecraft:gray_wool
setblock 418 125 331 minecraft:black_concrete
fill 418 125 332 418 138 336 minecraft:gray_wool
fill 418 125 338 418 140 338 minecraft:gray_wool
fill 418 125 345 418 184 345 minecraft:gray_wool
setblock 418 125 346 minecraft:black_concrete
fill 418 125 347 418 145 352 minecraft:gray_wool
setblock 418 125 353 minecraft:black_concrete
fill 418 125 354 418 129 357 minecraft:gray_wool
setblock 418 125 358 minecraft:black_concrete
fill 418 125 359 418 148 361 minecraft:gray_wool
setblock 418 125 362 minecraft:black_concrete
setblock 418 125 364 minecraft:black_concrete
fill 376 126 338 376 180 338 minecraft:gray_wool
fill 376 126 340 376 166 340 minecraft:gray_wool
fill 376 126 349 376 177 350 minecraft:gray_wool
fill 376 126 353 376 180 353 minecraft:gray_wool
fill 376 126 360 376 184 361 minecraft:gray_wool
setblock 377 126 324 minecraft:polished_deepslate
fill 377 126 325 377 129 325 minecraft:gray_concrete
setblock 377 126 329 minecraft:polished_deepslate
fill 377 126 330 377 129 330 minecraft:gray_concrete
setblock 377 126 334 minecraft:polished_deepslate
fill 377 126 335 377 129 335 minecraft:gray_concrete
setblock 377 126 339 minecraft:polished_deepslate
setblock 377 126 344 minecraft:polished_deepslate
fill 377 126 345 377 127 345 minecraft:gray_concrete
setblock 377 126 349 minecraft:polished_deepslate
fill 377 126 350 377 129 350 minecraft:gray_concrete
setblock 377 126 353 minecraft:gray_concrete
setblock 377 126 354 minecraft:polished_deepslate
fill 377 126 355 377 129 355 minecraft:gray_concrete
fill 377 126 357 377 126 358 minecraft:gray_concrete
setblock 377 126 359 minecraft:polished_deepslate
fill 377 126 360 377 129 360 minecraft:gray_concrete
setblock 378 126 323 minecraft:polished_deepslate
fill 378 126 324 378 129 324 minecraft:gray_concrete
setblock 378 126 328 minecraft:polished_deepslate
fill 378 126 329 378 129 329 minecraft:gray_concrete
setblock 378 126 333 minecraft:polished_deepslate
fill 378 126 334 378 129 334 minecraft:gray_concrete
setblock 378 126 348 minecraft:polished_deepslate
fill 378 126 349 378 127 349 minecraft:gray_concrete
fill 378 126 351 378 127 351 minecraft:gray_concrete
setblock 378 126 353 minecraft:polished_deepslate
fill 378 126 354 378 129 354 minecraft:gray_concrete
setblock 378 126 357 minecraft:gray_concrete
setblock 378 126 363 minecraft:polished_deepslate
fill 379 126 323 379 129 323 minecraft:gray_concrete
setblock 379 126 327 minecraft:polished_deepslate
fill 379 126 328 379 129 328 minecraft:gray_concrete
setblock 379 126 331 minecraft:gray_concrete
setblock 379 126 332 minecraft:polished_deepslate
fill 379 126 333 379 129 333 minecraft:gray_concrete
setblock 379 126 341 minecraft:light[level=13]
setblock 379 126 349 minecraft:light[level=13]
setblock 379 126 357 minecraft:light[level=13]
setblock 379 126 362 minecraft:polished_deepslate
fill 379 126 363 382 126 363 minecraft:gray_concrete
setblock 380 126 326 minecraft:polished_deepslate
setblock 380 126 327 minecraft:gray_concrete
setblock 380 126 331 minecraft:polished_deepslate
fill 380 126 362 380 127 362 minecraft:gray_concrete
setblock 381 126 325 minecraft:polished_deepslate
setblock 381 126 326 minecraft:gray_concrete
setblock 382 126 324 minecraft:polished_deepslate
fill 382 126 325 382 127 325 minecraft:gray_concrete
fill 382 126 364 383 152 364 minecraft:gray_wool
setblock 383 126 323 minecraft:polished_deepslate
fill 383 126 324 383 127 324 minecraft:gray_concrete
setblock 383 126 363 minecraft:polished_deepslate
fill 384 126 323 387 126 323 minecraft:gray_concrete
fill 384 126 363 384 128 363 minecraft:gray_concrete
setblock 387 126 325 minecraft:light[level=13]
setblock 387 126 333 minecraft:light[level=13]
setblock 387 126 341 minecraft:light[level=13]
setblock 387 126 349 minecraft:light[level=13]
setblock 387 126 357 minecraft:light[level=13]
setblock 389 126 364 minecraft:light_blue_stained_glass
fill 391 126 322 391 180 322 minecraft:gray_wool
fill 392 126 364 393 162 364 minecraft:gray_wool
setblock 394 126 363 minecraft:gray_concrete
setblock 395 126 325 minecraft:light[level=13]
setblock 395 126 333 minecraft:light[level=13]
setblock 395 126 341 minecraft:light[level=13]
setblock 395 126 349 minecraft:light[level=13]
setblock 395 126 357 minecraft:light[level=13]
setblock 398 126 323 minecraft:polished_deepslate
setblock 398 126 363 minecraft:polished_deepslate
fill 398 126 364 398 164 364 minecraft:gray_wool
fill 399 126 323 399 127 323 minecraft:gray_concrete
fill 399 126 363 399 128 363 minecraft:gray_concrete
fill 400 126 322 400 185 322 minecraft:gray_wool
fill 401 126 364 401 184 364 minecraft:gray_wool
fill 402 126 322 402 184 322 minecraft:gray_wool
fill 402 126 331 402 127 332 minecraft:light_gray_wool
setblock 403 126 325 minecraft:light[level=13]
setblock 403 126 333 minecraft:light[level=13]
setblock 403 126 341 minecraft:light[level=13]
setblock 403 126 349 minecraft:light[level=13]
setblock 403 126 357 minecraft:light[level=13]
fill 407 126 322 407 133 322 minecraft:gray_wool
fill 407 126 323 407 127 323 minecraft:light_blue_stained_glass
setblock 408 126 322 minecraft:light_blue_stained_glass
fill 408 126 325 408 127 326 minecraft:light_blue_stained_glass
fill 409 126 322 413 140 322 minecraft:gray_wool
fill 409 126 326 409 127 327 minecraft:light_blue_stained_glass
fill 410 126 325 410 127 326 minecraft:light_blue_stained_glass
fill 411 126 323 411 127 323 minecraft:light_blue_stained_glass
setblock 411 126 325 minecraft:light[level=13]
setblock 411 126 333 minecraft:light[level=13]
setblock 411 126 341 minecraft:light[level=13]
setblock 411 126 349 minecraft:light[level=13]
setblock 411 126 357 minecraft:light[level=13]
setblock 414 126 323 minecraft:gray_concrete
fill 414 126 364 414 130 364 minecraft:gray_wool
fill 415 126 327 415 127 327 minecraft:gray_concrete
setblock 415 126 331 minecraft:polished_deepslate
fill 415 126 332 415 129 332 minecraft:gray_concrete
fill 415 126 334 416 126 334 minecraft:gray_concrete
setblock 416 126 325 minecraft:polished_deepslate
fill 416 126 326 416 129 326 minecraft:gray_concrete
setblock 416 126 330 minecraft:polished_deepslate
fill 416 126 331 416 129 331 minecraft:gray_concrete
setblock 416 126 335 minecraft:polished_deepslate
fill 416 126 336 416 129 336 minecraft:gray_concrete
setblock 416 126 345 minecraft:polished_deepslate
setblock 416 126 346 minecraft:gray_concrete
setblock 416 126 350 minecraft:polished_deepslate
fill 416 126 351 416 129 351 minecraft:gray_concrete
fill 416 126 364 416 184 364 minecraft:gray_wool
setblock 417 126 324 minecraft:polished_deepslate
fill 417 126 325 417 129 325 minecraft:gray_concrete
setblock 417 126 329 minecraft:polished_deepslate
fill 417 126 330 417 129 330 minecraft:gray_concrete
setblock 417 126 334 minecraft:polished_deepslate
fill 417 126 335 417 129 335 minecraft:gray_concrete
setblock 417 126 339 minecraft:polished_deepslate
fill 417 126 340 417 129 340 minecraft:gray_concrete
setblock 417 126 344 minecraft:polished_deepslate
fill 417 126 345 417 129 345 minecraft:gray_concrete
setblock 417 126 349 minecraft:polished_deepslate
fill 417 126 350 417 129 350 minecraft:gray_concrete
setblock 417 126 354 minecraft:polished_deepslate
fill 417 126 355 417 129 355 minecraft:gray_concrete
fill 417 126 357 417 127 357 minecraft:gray_concrete
fill 418 126 324 418 180 324 minecraft:gray_wool
fill 418 126 331 418 139 331 minecraft:gray_wool
fill 418 126 346 418 184 346 minecraft:gray_wool
fill 418 126 353 418 130 353 minecraft:gray_wool
fill 418 126 358 418 184 358 minecraft:gray_wool
fill 418 126 362 418 181 364 minecraft:gray_wool
setblock 377 127 323 minecraft:polished_deepslate
fill 377 127 324 377 130 324 minecraft:gray_concrete
setblock 377 127 328 minecraft:polished_deepslate
fill 377 127 329 377 130 329 minecraft:gray_concrete
setblock 377 127 333 minecraft:polished_deepslate
fill 377 127 334 377 130 334 minecraft:gray_concrete
setblock 377 127 338 minecraft:yellow_concrete
setblock 377 127 348 minecraft:polished_deepslate
fill 377 127 349 377 130 349 minecraft:gray_concrete
setblock 377 127 353 minecraft:polished_deepslate
fill 377 127 354 377 130 354 minecraft:gray_concrete
setblock 377 127 357 minecraft:gray_concrete
setblock 377 127 358 minecraft:polished_deepslate
fill 377 127 359 377 130 359 minecraft:gray_concrete
setblock 377 127 363 minecraft:polished_deepslate
fill 378 127 323 378 130 323 minecraft:gray_concrete
setblock 378 127 327 minecraft:polished_deepslate
fill 378 127 328 378 130 328 minecraft:gray_concrete
setblock 378 127 332 minecraft:polished_deepslate
fill 378 127 333 378 130 333 minecraft:gray_concrete
setblock 378 127 348 minecraft:gray_concrete
setblock 378 127 352 minecraft:polished_deepslate
fill 378 127 353 378 130 353 minecraft:gray_concrete
setblock 378 127 357 minecraft:polished_deepslate
fill 378 127 358 378 130 358 minecraft:gray_concrete
fill 378 127 363 381 127 363 minecraft:gray_concrete
setblock 379 127 326 minecraft:polished_deepslate
fill 379 127 327 379 129 327 minecraft:gray_concrete
setblock 379 127 331 minecraft:polished_deepslate
fill 379 127 332 379 130 332 minecraft:gray_concrete
setblock 379 127 362 minecraft:gray_concrete
setblock 380 127 325 minecraft:polished_deepslate
setblock 381 127 324 minecraft:polished_deepslate
setblock 381 127 325 minecraft:gray_concrete
setblock 382 127 323 minecraft:polished_deepslate
fill 382 127 324 382 128 324 minecraft:gray_concrete
setblock 382 127 363 minecraft:polished_deepslate
fill 383 127 323 385 127 323 minecraft:gray_concrete
fill 383 127 363 383 129 363 minecraft:gray_concrete
fill 389 127 364 389 184 364 minecraft:gray_wool
setblock 394 127 364 minecraft:light_blue_stained_glass
fill 395 127 364 397 127 364 minecraft:gray_wool
setblock 397 127 323 minecraft:polished_deepslate
setblock 397 127 363 minecraft:polished_deepslate
setblock 398 127 323 minecraft:gray_concrete
fill 398 127 363 398 128 363 minecraft:gray_concrete
fill 408 127 322 408 184 322 minecraft:gray_wool
fill 412 127 332 414 128 332 minecraft:light_blue_stained_glass
setblock 415 127 330 minecraft:polished_deepslate
fill 415 127 331 415 130 331 minecraft:gray_concrete
setblock 415 127 334 minecraft:gray_concrete
setblock 416 127 324 minecraft:polished_deepslate
fill 416 127 325 416 130 325 minecraft:gray_concrete
setblock 416 127 329 minecraft:polished_deepslate
fill 416 127 330 416 130 330 minecraft:gray_concrete
setblock 416 127 334 minecraft:polished_deepslate
fill 416 127 335 416 130 335 minecraft:gray_concrete
setblock 416 127 349 minecraft:polished_deepslate
fill 416 127 350 416 128 350 minecraft:gray_concrete
setblock 417 127 323 minecraft:polished_deepslate
fill 417 127 324 417 130 324 minecraft:gray_concrete
setblock 417 127 328 minecraft:polished_deepslate
fill 417 127 329 417 130 329 minecraft:gray_concrete
setblock 417 127 333 minecraft:polished_deepslate
fill 417 127 334 417 130 334 minecraft:gray_concrete
setblock 417 127 338 minecraft:polished_deepslate
fill 417 127 339 417 130 339 minecraft:gray_concrete
setblock 417 127 343 minecraft:polished_deepslate
fill 417 127 344 417 129 344 minecraft:gray_concrete
setblock 417 127 348 minecraft:polished_deepslate
fill 417 127 349 417 130 349 minecraft:gray_concrete
setblock 417 127 353 minecraft:polished_deepslate
fill 417 127 354 417 130 354 minecraft:gray_concrete
setblock 376 128 337 minecraft:light_blue_stained_glass
fill 377 128 323 377 131 323 minecraft:gray_concrete
setblock 377 128 327 minecraft:polished_deepslate
fill 377 128 328 377 131 328 minecraft:gray_concrete
setblock 377 128 332 minecraft:polished_deepslate
fill 377 128 333 377 131 333 minecraft:gray_concrete
setblock 377 128 337 minecraft:yellow_concrete
setblock 377 128 338 minecraft:gray_concrete
setblock 377 128 347 minecraft:polished_deepslate
fill 377 128 348 377 130 348 minecraft:gray_concrete
setblock 377 128 352 minecraft:polished_deepslate
fill 377 128 353 377 131 353 minecraft:gray_concrete
setblock 377 128 356 minecraft:gray_concrete
setblock 377 128 357 minecraft:polished_deepslate
fill 377 128 358 377 131 358 minecraft:gray_concrete
setblock 377 128 362 minecraft:polished_deepslate
fill 377 128 363 380 128 363 minecraft:gray_concrete
setblock 378 128 326 minecraft:polished_deepslate
fill 378 128 327 378 131 327 minecraft:gray_concrete
setblock 378 128 331 minecraft:polished_deepslate
fill 378 128 332 378 131 332 minecraft:gray_concrete
setblock 378 128 336 minecraft:polished_deepslate
setblock 378 128 351 minecraft:polished_deepslate
fill 378 128 352 378 131 352 minecraft:gray_concrete
setblock 378 128 356 minecraft:polished_deepslate
fill 378 128 357 378 131 357 minecraft:gray_concrete
fill 378 128 359 378 129 359 minecraft:gray_concrete
setblock 379 128 325 minecraft:polished_deepslate
setblock 379 128 326 minecraft:gray_concrete
setblock 379 128 330 minecraft:polished_deepslate
fill 379 128 331 379 130 331 minecraft:gray_concrete
setblock 379 128 339 minecraft:light[level=12]
setblock 379 128 346 minecraft:light[level=12]
setblock 379 128 353 minecraft:light[level=12]
setblock 379 128 360 minecraft:light[level=12]
setblock 380 128 324 minecraft:polished_deepslate
setblock 380 128 325 minecraft:gray_concrete
setblock 381 128 323 minecraft:polished_deepslate
setblock 381 128 324 minecraft:gray_concrete
setblock 381 128 363 minecraft:polished_deepslate
fill 382 128 323 384 128 323 minecraft:gray_concrete
fill 382 128 363 382 131 363 minecraft:gray_concrete
fill 385 128 328 385 128 330 minecraft:light_blue_concrete
setblock 386 128 325 minecraft:light[level=12]
fill 386 128 327 389 128 327 minecraft:light_blue_concrete
fill 386 128 330 386 128 331 minecraft:light_blue_concrete
setblock 386 128 332 minecraft:light[level=12]
setblock 386 128 339 minecraft:light[level=12]
setblock 386 128 346 minecraft:light[level=12]
setblock 386 128 353 minecraft:light[level=12]
setblock 386 128 360 minecraft:light[level=12]
fill 387 128 331 388 128 331 minecraft:light_blue_concrete
fill 388 128 330 389 128 330 minecraft:light_blue_concrete
fill 388 128 356 390 128 358 minecraft:light_blue_concrete
fill 389 128 328 389 129 329 minecraft:light_blue_concrete
fill 389 128 355 390 129 355 minecraft:light_blue_concrete
fill 389 128 359 394 128 359 minecraft:light_blue_concrete
fill 390 128 354 394 128 354 minecraft:light_blue_concrete
fill 390 128 364 390 167 364 minecraft:gray_wool
fill 391 128 358 391 130 358 minecraft:light_blue_concrete
setblock 391 128 360 minecraft:light_blue_concrete
setblock 391 128 364 minecraft:light_blue_stained_glass
fill 392 128 353 393 128 353 minecraft:light_blue_concrete
setblock 393 128 325 minecraft:light[level=12]
setblock 393 128 332 minecraft:light[level=12]
setblock 393 128 339 minecraft:light[level=12]
setblock 393 128 346 minecraft:light[level=12]
fill 393 128 358 395 128 358 minecraft:light_blue_concrete
fill 393 128 360 393 129 360 minecraft:white_wool
fill 394 128 355 395 128 357 minecraft:light_blue_concrete
fill 394 128 364 395 164 364 minecraft:gray_wool
setblock 396 128 363 minecraft:polished_deepslate
setblock 396 128 364 minecraft:light_blue_stained_glass
fill 397 128 363 397 131 363 minecraft:gray_concrete
fill 397 128 364 397 169 364 minecraft:gray_wool
setblock 400 128 325 minecraft:light[level=12]
setblock 400 128 332 minecraft:light[level=12]
setblock 400 128 339 minecraft:light[level=12]
setblock 400 128 346 minecraft:light[level=12]
setblock 400 128 353 minecraft:light[level=12]
setblock 400 128 360 minecraft:light[level=12]
setblock 407 128 325 minecraft:light[level=12]
setblock 407 128 332 minecraft:light[level=12]
setblock 407 128 339 minecraft:light[level=12]
setblock 407 128 346 minecraft:light[level=12]
setblock 407 128 353 minecraft:light[level=12]
setblock 407 128 360 minecraft:light[level=12]
fill 410 128 332 411 128 332 minecraft:light_blue_stained_glass
fill 413 128 331 414 128 331 minecraft:light_blue_stained_glass
fill 413 128 333 414 128 333 minecraft:light_blue_stained_glass
setblock 414 128 325 minecraft:light[level=12]
setblock 414 128 339 minecraft:light[level=12]
setblock 414 128 346 minecraft:light[level=12]
setblock 414 128 353 minecraft:light[level=12]
setblock 414 128 360 minecraft:light[level=12]
setblock 415 128 329 minecraft:polished_deepslate
fill 415 128 330 415 131 330 minecraft:gray_concrete
setblock 415 128 333 minecraft:gray_concrete
setblock 415 128 334 minecraft:polished_deepslate
fill 415 128 335 415 131 335 minecraft:gray_concrete
setblock 416 128 323 minecraft:polished_deepslate
setblock 416 128 324 minecraft:gray_concrete
setblock 416 128 328 minecraft:polished_deepslate
fill 416 128 329 416 131 329 minecraft:gray_concrete
setblock 416 128 333 minecraft:polished_deepslate
fill 416 128 334 416 131 334 minecraft:gray_concrete
setblock 416 128 338 minecraft:polished_deepslate
setblock 416 128 349 minecraft:gray_concrete
setblock 416 128 352 minecraft:gray_concrete
setblock 416 128 353 minecraft:polished_deepslate
fill 417 128 323 417 131 323 minecraft:gray_concrete
setblock 417 128 327 minecraft:polished_deepslate
fill 417 128 328 417 131 328 minecraft:gray_concrete
setblock 417 128 332 minecraft:polished_deepslate
fill 417 128 333 417 131 333 minecraft:gray_concrete
setblock 417 128 337 minecraft:polished_deepslate
fill 417 128 338 417 131 338 minecraft:gray_concrete
setblock 417 128 342 minecraft:polished_deepslate
fill 417 128 343 417 129 343 minecraft:gray_concrete
setblock 417 128 347 minecraft:polished_deepslate
fill 417 128 348 417 131 348 minecraft:gray_concrete
setblock 417 128 352 minecraft:polished_deepslate
fill 417 128 353 417 131 353 minecraft:gray_concrete
setblock 417 128 357 minecraft:polished_deepslate
fill 417 128 358 417 131 358 minecraft:gray_concrete
fill 376 129 337 376 149 337 minecraft:gray_wool
setblock 377 129 326 minecraft:polished_deepslate
fill 377 129 327 377 131 327 minecraft:gray_concrete
setblock 377 129 331 minecraft:polished_deepslate
fill 377 129 332 377 131 332 minecraft:gray_concrete
setblock 377 129 336 minecraft:polished_deepslate
fill 377 129 337 377 131 337 minecraft:gray_concrete
setblock 377 129 338 minecraft:yellow_concrete
setblock 377 129 351 minecraft:polished_deepslate
fill 377 129 352 377 131 352 minecraft:gray_concrete
setblock 377 129 356 minecraft:polished_deepslate
fill 377 129 357 377 131 357 minecraft:gray_concrete
setblock 377 129 361 minecraft:polished_deepslate
fill 377 129 362 377 131 363 minecraft:gray_concrete
setblock 378 129 325 minecraft:polished_deepslate
fill 378 129 326 378 131 326 minecraft:gray_concrete
setblock 378 129 330 minecraft:polished_deepslate
fill 378 129 331 378 131 331 minecraft:gray_concrete
setblock 378 129 335 minecraft:polished_deepslate
fill 378 129 336 378 131 336 minecraft:gray_concrete
setblock 378 129 350 minecraft:polished_deepslate
fill 378 129 351 378 131 351 minecraft:gray_concrete
setblock 378 129 355 minecraft:polished_deepslate
fill 378 129 356 378 131 356 minecraft:gray_concrete
setblock 378 129 360 minecraft:polished_deepslate
fill 378 129 363 379 129 363 minecraft:gray_concrete
setblock 379 129 324 minecraft:polished_deepslate
setblock 379 129 329 minecraft:polished_deepslate
fill 379 129 330 379 130 330 minecraft:gray_concrete
setblock 380 129 323 minecraft:polished_deepslate
setblock 380 129 324 minecraft:gray_concrete
setblock 380 129 363 minecraft:polished_deepslate
fill 381 129 323 382 129 323 minecraft:gray_concrete
fill 381 129 363 381 131 363 minecraft:gray_concrete
fill 385 129 328 385 129 329 minecraft:light_blue_concrete
fill 386 129 327 388 129 327 minecraft:light_blue_concrete
fill 386 129 330 386 130 330 minecraft:light_blue_concrete
fill 388 129 330 388 130 330 minecraft:light_blue_concrete
fill 389 129 356 390 129 358 minecraft:light_blue_concrete
fill 390 129 359 392 129 359 minecraft:light_blue_concrete
fill 391 129 354 393 129 354 minecraft:light_blue_concrete
fill 391 129 364 391 139 364 minecraft:gray_wool
fill 393 129 358 394 129 358 minecraft:light_blue_concrete
setblock 393 129 359 minecraft:white_wool
fill 394 129 355 394 130 357 minecraft:light_blue_concrete
schedule function dropper:buildpart/80_3 1t
