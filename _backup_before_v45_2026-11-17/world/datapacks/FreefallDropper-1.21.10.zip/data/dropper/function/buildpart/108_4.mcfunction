fill 27 239 498 27 240 498 minecraft:bookshelf
fill 27 239 500 27 240 500 minecraft:bookshelf
fill 27 239 502 30 239 502 minecraft:bookshelf
fill 27 239 504 28 240 504 minecraft:bookshelf
fill 28 239 503 31 239 503 minecraft:bookshelf
fill 30 239 464 30 240 464 minecraft:bookshelf
fill 30 239 504 31 240 504 minecraft:bookshelf
fill 37 239 464 37 240 464 minecraft:bookshelf
fill 37 239 504 37 240 504 minecraft:bookshelf
fill 41 239 467 41 240 467 minecraft:bookshelf
fill 41 239 488 41 240 488 minecraft:bookshelf
fill 41 239 495 41 240 495 minecraft:bookshelf
fill 41 239 502 41 240 502 minecraft:bookshelf
fill 1 240 464 1 240 468 minecraft:bookshelf
fill 1 240 471 1 240 475 minecraft:bookshelf
fill 1 240 478 1 240 482 minecraft:bookshelf
fill 1 240 485 1 240 489 minecraft:bookshelf
fill 1 240 492 1 240 496 minecraft:bookshelf
fill 1 240 499 1 240 503 minecraft:bookshelf
fill 3 240 504 7 240 504 minecraft:bookshelf
fill 4 240 464 8 240 464 minecraft:bookshelf
fill 10 240 504 14 240 504 minecraft:bookshelf
fill 11 240 464 15 240 464 minecraft:bookshelf
fill 17 240 504 20 240 504 minecraft:bookshelf
fill 18 240 464 22 240 464 minecraft:bookshelf
fill 25 240 464 29 240 464 minecraft:bookshelf
setblock 27 240 502 minecraft:bookshelf
fill 32 240 464 36 240 464 minecraft:bookshelf
fill 32 240 504 35 240 504 minecraft:bookshelf
fill 38 240 504 41 240 504 minecraft:bookshelf
fill 39 240 464 41 240 464 minecraft:bookshelf
fill 41 240 465 41 240 466 minecraft:bookshelf
fill 41 240 469 41 240 473 minecraft:bookshelf
setblock 41 240 487 minecraft:bookshelf
fill 41 240 490 41 240 494 minecraft:bookshelf
fill 41 240 497 41 240 501 minecraft:bookshelf
setblock 1 241 465 minecraft:bookshelf
setblock 1 241 472 minecraft:bookshelf
setblock 1 241 479 minecraft:bookshelf
setblock 1 241 486 minecraft:bookshelf
setblock 1 241 493 minecraft:bookshelf
setblock 1 241 500 minecraft:bookshelf
setblock 4 241 504 minecraft:bookshelf
setblock 7 241 464 minecraft:bookshelf
setblock 11 241 504 minecraft:bookshelf
setblock 14 241 464 minecraft:bookshelf
fill 18 241 504 18 243 504 minecraft:bookshelf
fill 20 241 502 20 242 504 minecraft:bookshelf
setblock 21 241 464 minecraft:bookshelf
setblock 21 241 496 minecraft:ochre_froglight
setblock 21 241 498 minecraft:ochre_froglight
setblock 21 241 500 minecraft:ochre_froglight
setblock 21 241 502 minecraft:ochre_froglight
setblock 21 241 504 minecraft:ochre_froglight
setblock 22 241 497 minecraft:ochre_froglight
setblock 22 241 499 minecraft:ochre_froglight
setblock 22 241 501 minecraft:ochre_froglight
setblock 22 241 503 minecraft:ochre_froglight
setblock 23 241 496 minecraft:ochre_froglight
setblock 23 241 498 minecraft:ochre_froglight
setblock 23 241 500 minecraft:ochre_froglight
setblock 23 241 502 minecraft:ochre_froglight
setblock 23 241 504 minecraft:ochre_froglight
setblock 24 241 497 minecraft:ochre_froglight
setblock 24 241 499 minecraft:ochre_froglight
setblock 24 241 501 minecraft:ochre_froglight
setblock 24 241 503 minecraft:ochre_froglight
setblock 25 241 496 minecraft:ochre_froglight
setblock 25 241 498 minecraft:ochre_froglight
setblock 25 241 500 minecraft:ochre_froglight
setblock 25 241 502 minecraft:ochre_froglight
setblock 25 241 504 minecraft:ochre_froglight
setblock 26 241 497 minecraft:ochre_froglight
setblock 26 241 499 minecraft:ochre_froglight
setblock 26 241 501 minecraft:ochre_froglight
setblock 26 241 503 minecraft:ochre_froglight
setblock 27 241 496 minecraft:ochre_froglight
setblock 27 241 498 minecraft:ochre_froglight
setblock 27 241 500 minecraft:ochre_froglight
setblock 27 241 502 minecraft:ochre_froglight
setblock 27 241 504 minecraft:ochre_froglight
setblock 28 241 464 minecraft:bookshelf
setblock 32 241 504 minecraft:bookshelf
setblock 35 241 464 minecraft:bookshelf
setblock 39 241 504 minecraft:bookshelf
setblock 41 241 465 minecraft:bookshelf
setblock 41 241 472 minecraft:bookshelf
setblock 41 241 493 minecraft:bookshelf
setblock 41 241 500 minecraft:bookshelf
setblock 1 242 466 minecraft:bookshelf
setblock 1 242 473 minecraft:bookshelf
setblock 1 242 480 minecraft:bookshelf
setblock 1 242 487 minecraft:bookshelf
setblock 1 242 494 minecraft:bookshelf
setblock 1 242 501 minecraft:bookshelf
setblock 5 242 504 minecraft:bookshelf
setblock 6 242 464 minecraft:bookshelf
setblock 12 242 504 minecraft:bookshelf
setblock 13 242 464 minecraft:bookshelf
fill 16 242 493 16 243 494 minecraft:green_wool
fill 17 242 493 17 243 493 minecraft:green_wool
fill 17 242 502 17 243 504 minecraft:bookshelf
fill 18 242 502 19 242 503 minecraft:bookshelf
setblock 19 242 504 minecraft:bookshelf
setblock 20 242 464 minecraft:bookshelf
fill 21 242 496 21 243 496 minecraft:bookshelf
fill 21 242 498 21 243 498 minecraft:bookshelf
fill 21 242 500 21 243 500 minecraft:bookshelf
fill 21 242 502 21 243 502 minecraft:bookshelf
fill 21 242 504 21 243 504 minecraft:bookshelf
fill 22 242 497 22 243 497 minecraft:bookshelf
fill 22 242 499 22 243 499 minecraft:bookshelf
fill 22 242 501 22 243 501 minecraft:bookshelf
fill 22 242 503 22 243 503 minecraft:bookshelf
fill 23 242 496 23 243 496 minecraft:bookshelf
fill 23 242 498 23 243 498 minecraft:bookshelf
fill 23 242 500 23 243 500 minecraft:bookshelf
fill 23 242 502 23 243 502 minecraft:bookshelf
fill 23 242 504 23 243 504 minecraft:bookshelf
fill 24 242 497 24 243 497 minecraft:bookshelf
fill 24 242 499 24 243 499 minecraft:bookshelf
fill 24 242 501 24 243 501 minecraft:bookshelf
fill 24 242 503 24 243 503 minecraft:bookshelf
fill 25 242 496 25 243 496 minecraft:bookshelf
fill 25 242 498 25 243 498 minecraft:bookshelf
fill 25 242 500 25 243 500 minecraft:bookshelf
fill 25 242 502 25 243 502 minecraft:bookshelf
fill 25 242 504 25 243 504 minecraft:bookshelf
fill 26 242 497 26 243 497 minecraft:bookshelf
fill 26 242 499 26 243 499 minecraft:bookshelf
fill 26 242 501 26 243 501 minecraft:bookshelf
fill 26 242 503 26 243 503 minecraft:bookshelf
setblock 27 242 464 minecraft:bookshelf
fill 27 242 496 27 243 496 minecraft:bookshelf
fill 27 242 498 27 243 498 minecraft:bookshelf
fill 27 242 500 27 243 500 minecraft:bookshelf
fill 27 242 502 27 243 502 minecraft:bookshelf
fill 27 242 504 27 243 504 minecraft:bookshelf
setblock 33 242 504 minecraft:bookshelf
setblock 34 242 464 minecraft:bookshelf
fill 38 242 495 40 243 495 minecraft:gold_block
setblock 40 242 504 minecraft:bookshelf
setblock 41 242 464 minecraft:bookshelf
setblock 41 242 471 minecraft:bookshelf
setblock 41 242 492 minecraft:bookshelf
setblock 41 242 499 minecraft:bookshelf
setblock 1 243 467 minecraft:bookshelf
setblock 1 243 474 minecraft:bookshelf
setblock 1 243 481 minecraft:bookshelf
setblock 1 243 488 minecraft:bookshelf
setblock 1 243 495 minecraft:bookshelf
setblock 1 243 502 minecraft:bookshelf
setblock 5 243 464 minecraft:bookshelf
setblock 6 243 504 minecraft:bookshelf
setblock 12 243 464 minecraft:bookshelf
fill 13 243 504 14 244 504 minecraft:bookshelf
fill 14 243 502 16 243 503 minecraft:bookshelf
setblock 16 243 504 minecraft:bookshelf
fill 18 243 502 18 243 503 minecraft:bookshelf
setblock 19 243 464 minecraft:bookshelf
setblock 20 243 504 minecraft:bookshelf
setblock 26 243 464 minecraft:bookshelf
setblock 33 243 464 minecraft:bookshelf
setblock 34 243 504 minecraft:bookshelf
setblock 40 243 464 minecraft:bookshelf
setblock 41 243 470 minecraft:bookshelf
setblock 41 243 491 minecraft:bookshelf
setblock 41 243 498 minecraft:bookshelf
setblock 41 243 504 minecraft:bookshelf
setblock 1 244 468 minecraft:bookshelf
setblock 1 244 475 minecraft:bookshelf
setblock 1 244 482 minecraft:bookshelf
setblock 1 244 489 minecraft:bookshelf
setblock 1 244 496 minecraft:bookshelf
setblock 1 244 503 minecraft:bookshelf
setblock 4 244 464 minecraft:bookshelf
setblock 5 244 493 minecraft:ochre_froglight
fill 7 244 504 7 245 504 minecraft:bookshelf
fill 9 244 504 12 244 504 minecraft:bookshelf
fill 10 244 502 15 244 503 minecraft:bookshelf
setblock 11 244 464 minecraft:bookshelf
setblock 18 244 464 minecraft:bookshelf
setblock 21 244 496 minecraft:ochre_froglight
setblock 21 244 498 minecraft:ochre_froglight
setblock 21 244 500 minecraft:ochre_froglight
setblock 21 244 502 minecraft:ochre_froglight
setblock 21 244 504 minecraft:ochre_froglight
setblock 22 244 497 minecraft:ochre_froglight
setblock 22 244 499 minecraft:ochre_froglight
setblock 22 244 501 minecraft:ochre_froglight
setblock 22 244 503 minecraft:ochre_froglight
setblock 23 244 496 minecraft:ochre_froglight
setblock 23 244 498 minecraft:ochre_froglight
setblock 23 244 500 minecraft:ochre_froglight
setblock 23 244 502 minecraft:ochre_froglight
setblock 23 244 504 minecraft:ochre_froglight
setblock 24 244 497 minecraft:ochre_froglight
setblock 24 244 499 minecraft:ochre_froglight
setblock 24 244 501 minecraft:ochre_froglight
setblock 24 244 503 minecraft:ochre_froglight
setblock 25 244 464 minecraft:bookshelf
setblock 25 244 496 minecraft:ochre_froglight
setblock 25 244 498 minecraft:ochre_froglight
setblock 25 244 500 minecraft:ochre_froglight
setblock 25 244 502 minecraft:ochre_froglight
setblock 25 244 504 minecraft:ochre_froglight
setblock 26 244 497 minecraft:ochre_froglight
setblock 26 244 499 minecraft:ochre_froglight
setblock 26 244 501 minecraft:ochre_froglight
setblock 26 244 503 minecraft:ochre_froglight
setblock 27 244 496 minecraft:ochre_froglight
setblock 27 244 498 minecraft:ochre_froglight
setblock 27 244 500 minecraft:ochre_froglight
setblock 27 244 502 minecraft:ochre_froglight
setblock 27 244 504 minecraft:ochre_froglight
setblock 28 244 504 minecraft:bookshelf
setblock 32 244 464 minecraft:bookshelf
setblock 35 244 504 minecraft:bookshelf
setblock 39 244 464 minecraft:bookshelf
setblock 41 244 469 minecraft:bookshelf
setblock 41 244 490 minecraft:bookshelf
setblock 41 244 497 minecraft:bookshelf
fill 4 245 504 6 246 504 minecraft:bookshelf
fill 5 245 503 11 245 503 minecraft:bookshelf
fill 6 245 502 12 245 502 minecraft:bookshelf
fill 9 245 504 11 245 504 minecraft:bookshelf
fill 21 245 496 21 246 496 minecraft:bookshelf
fill 21 245 498 21 246 498 minecraft:bookshelf
fill 21 245 500 21 246 500 minecraft:bookshelf
fill 21 245 502 21 246 502 minecraft:bookshelf
fill 21 245 504 21 246 504 minecraft:bookshelf
fill 22 245 497 22 246 497 minecraft:bookshelf
fill 22 245 499 22 246 499 minecraft:bookshelf
fill 22 245 501 22 246 501 minecraft:bookshelf
fill 22 245 503 22 246 503 minecraft:bookshelf
fill 23 245 496 23 246 496 minecraft:bookshelf
fill 23 245 498 23 246 498 minecraft:bookshelf
fill 23 245 500 23 246 500 minecraft:bookshelf
fill 23 245 502 23 246 502 minecraft:bookshelf
fill 23 245 504 23 246 504 minecraft:bookshelf
fill 24 245 497 24 246 497 minecraft:bookshelf
fill 24 245 499 24 246 499 minecraft:bookshelf
fill 24 245 501 24 246 501 minecraft:bookshelf
fill 24 245 503 24 246 503 minecraft:bookshelf
fill 25 245 496 25 246 496 minecraft:bookshelf
fill 25 245 498 25 246 498 minecraft:bookshelf
fill 25 245 500 25 246 500 minecraft:bookshelf
fill 25 245 502 25 246 502 minecraft:bookshelf
fill 25 245 504 25 246 504 minecraft:bookshelf
fill 26 245 497 26 246 497 minecraft:bookshelf
fill 26 245 499 26 246 499 minecraft:bookshelf
fill 26 245 501 26 246 501 minecraft:bookshelf
fill 26 245 503 26 246 503 minecraft:bookshelf
fill 27 245 496 27 246 496 minecraft:bookshelf
fill 27 245 498 27 246 498 minecraft:bookshelf
fill 27 245 500 27 246 500 minecraft:bookshelf
fill 27 245 502 27 246 502 minecraft:bookshelf
fill 27 245 504 27 246 504 minecraft:bookshelf
setblock 1 246 470 minecraft:bookshelf
setblock 1 246 477 minecraft:bookshelf
setblock 1 246 484 minecraft:bookshelf
setblock 1 246 491 minecraft:bookshelf
fill 1 246 498 1 248 498 minecraft:bookshelf
fill 1 246 502 7 246 503 minecraft:bookshelf
setblock 2 246 464 minecraft:bookshelf
fill 2 246 501 3 247 501 minecraft:bookshelf
fill 2 246 504 3 246 504 minecraft:bookshelf
setblock 3 246 466 minecraft:light[level=12]
setblock 3 246 474 minecraft:light[level=12]
setblock 3 246 482 minecraft:light[level=12]
setblock 3 246 490 minecraft:light[level=12]
setblock 3 246 498 minecraft:light[level=12]
fill 3 246 500 3 247 500 minecraft:bookshelf
setblock 8 246 502 minecraft:bookshelf
setblock 9 246 464 minecraft:bookshelf
setblock 9 246 504 minecraft:bookshelf
setblock 11 246 466 minecraft:light[level=12]
setblock 11 246 474 minecraft:light[level=12]
setblock 11 246 482 minecraft:light[level=12]
setblock 11 246 490 minecraft:light[level=12]
setblock 11 246 498 minecraft:light[level=12]
setblock 16 246 464 minecraft:bookshelf
setblock 16 246 504 minecraft:bookshelf
setblock 19 246 466 minecraft:light[level=12]
setblock 19 246 474 minecraft:light[level=12]
setblock 19 246 482 minecraft:light[level=12]
setblock 19 246 490 minecraft:light[level=12]
setblock 19 246 498 minecraft:light[level=12]
setblock 23 246 464 minecraft:bookshelf
setblock 27 246 466 minecraft:light[level=12]
setblock 27 246 474 minecraft:light[level=12]
setblock 27 246 482 minecraft:light[level=12]
setblock 27 246 490 minecraft:light[level=12]
setblock 30 246 464 minecraft:bookshelf
setblock 30 246 504 minecraft:bookshelf
setblock 35 246 466 minecraft:light[level=12]
setblock 35 246 474 minecraft:light[level=12]
setblock 35 246 482 minecraft:light[level=12]
setblock 35 246 490 minecraft:light[level=12]
setblock 35 246 498 minecraft:light[level=12]
setblock 37 246 464 minecraft:bookshelf
setblock 37 246 504 minecraft:bookshelf
setblock 41 246 467 minecraft:bookshelf
fill 41 246 474 41 246 475 minecraft:bookshelf
fill 41 246 481 41 246 482 minecraft:bookshelf
setblock 41 246 488 minecraft:bookshelf
setblock 41 246 495 minecraft:bookshelf
setblock 41 246 502 minecraft:bookshelf
setblock 1 247 464 minecraft:bookshelf
setblock 1 247 471 minecraft:bookshelf
setblock 1 247 478 minecraft:bookshelf
setblock 1 247 485 minecraft:bookshelf
setblock 1 247 492 minecraft:bookshelf
fill 1 247 499 1 247 503 minecraft:bookshelf
fill 2 247 496 2 247 500 minecraft:bookshelf
fill 2 247 502 2 247 503 minecraft:bookshelf
fill 3 247 496 3 247 499 minecraft:bookshelf
setblock 3 247 502 minecraft:bookshelf
setblock 3 247 504 minecraft:bookshelf
setblock 8 247 464 minecraft:bookshelf
setblock 10 247 504 minecraft:bookshelf
setblock 15 247 464 minecraft:bookshelf
setblock 17 247 504 minecraft:bookshelf
setblock 22 247 464 minecraft:bookshelf
setblock 29 247 464 minecraft:bookshelf
setblock 31 247 504 minecraft:bookshelf
setblock 36 247 464 minecraft:bookshelf
setblock 38 247 504 minecraft:bookshelf
setblock 41 247 466 minecraft:bookshelf
setblock 41 247 473 minecraft:bookshelf
fill 41 247 475 41 273 475 minecraft:bookshelf
setblock 41 247 480 minecraft:bookshelf
fill 41 247 482 41 273 482 minecraft:bookshelf
setblock 41 247 487 minecraft:bookshelf
setblock 41 247 494 minecraft:bookshelf
setblock 41 247 501 minecraft:bookshelf
setblock 1 248 465 minecraft:bookshelf
setblock 1 248 472 minecraft:bookshelf
setblock 1 248 479 minecraft:bookshelf
setblock 1 248 486 minecraft:bookshelf
fill 1 248 493 3 248 496 minecraft:bookshelf
fill 1 248 499 1 248 500 minecraft:bookshelf
fill 2 248 492 3 249 492 minecraft:bookshelf
fill 2 248 497 2 248 498 minecraft:bookshelf
setblock 3 248 497 minecraft:bookshelf
setblock 4 248 504 minecraft:bookshelf
setblock 7 248 464 minecraft:bookshelf
setblock 11 248 504 minecraft:bookshelf
setblock 14 248 464 minecraft:bookshelf
fill 14 248 497 14 249 497 minecraft:red_wool
setblock 18 248 504 minecraft:bookshelf
setblock 21 248 464 minecraft:bookshelf
setblock 25 248 504 minecraft:bookshelf
setblock 28 248 464 minecraft:bookshelf
setblock 32 248 504 minecraft:bookshelf
setblock 35 248 464 minecraft:bookshelf
setblock 39 248 504 minecraft:bookshelf
setblock 41 248 465 minecraft:bookshelf
setblock 41 248 472 minecraft:bookshelf
setblock 41 248 479 minecraft:bookshelf
setblock 41 248 486 minecraft:bookshelf
setblock 41 248 493 minecraft:bookshelf
setblock 41 248 500 minecraft:bookshelf
fill 1 249 466 1 250 466 minecraft:bookshelf
fill 1 249 473 1 250 473 minecraft:bookshelf
fill 1 249 480 1 250 480 minecraft:bookshelf
fill 1 249 487 1 251 487 minecraft:bookshelf
fill 1 249 489 3 250 489 minecraft:bookshelf
fill 1 249 491 1 250 494 minecraft:bookshelf
fill 1 249 501 1 250 501 minecraft:bookshelf
fill 2 249 490 3 249 491 minecraft:bookshelf
fill 2 249 493 2 249 494 minecraft:bookshelf
setblock 3 249 493 minecraft:bookshelf
fill 5 249 504 5 250 504 minecraft:bookshelf
fill 6 249 464 6 250 464 minecraft:bookshelf
fill 12 249 504 12 250 504 minecraft:bookshelf
fill 13 249 464 13 250 464 minecraft:bookshelf
fill 19 249 504 19 250 504 minecraft:bookshelf
fill 20 249 464 20 250 464 minecraft:bookshelf
fill 26 249 504 26 250 504 minecraft:bookshelf
fill 27 249 464 27 250 464 minecraft:bookshelf
fill 33 249 504 33 250 504 minecraft:bookshelf
fill 34 249 464 34 250 464 minecraft:bookshelf
fill 40 249 504 40 250 504 minecraft:bookshelf
fill 41 249 464 41 250 464 minecraft:bookshelf
fill 41 249 471 41 250 471 minecraft:bookshelf
fill 41 249 478 41 250 478 minecraft:bookshelf
fill 41 249 485 41 250 485 minecraft:bookshelf
fill 41 249 492 41 250 492 minecraft:bookshelf
fill 41 249 499 41 250 499 minecraft:bookshelf
fill 1 250 464 1 250 465 minecraft:bookshelf
fill 1 250 467 1 250 468 minecraft:bookshelf
fill 1 250 470 1 250 472 minecraft:bookshelf
fill 1 250 474 1 250 475 minecraft:bookshelf
fill 1 250 477 1 250 479 minecraft:bookshelf
fill 1 250 481 1 250 482 minecraft:bookshelf
fill 1 250 484 1 251 486 minecraft:bookshelf
fill 1 250 488 3 250 488 minecraft:bookshelf
fill 1 250 495 1 250 496 minecraft:bookshelf
fill 1 250 498 1 250 500 minecraft:bookshelf
fill 1 250 502 1 250 503 minecraft:bookshelf
setblock 2 250 464 minecraft:bookshelf
fill 2 250 486 3 251 487 minecraft:bookshelf
fill 2 250 490 3 250 490 minecraft:bookshelf
fill 2 250 504 4 250 504 minecraft:bookshelf
fill 4 250 464 5 250 464 minecraft:bookshelf
fill 6 250 504 7 250 504 minecraft:bookshelf
fill 7 250 464 9 250 464 minecraft:bookshelf
fill 9 250 504 11 250 504 minecraft:bookshelf
fill 11 250 464 12 250 464 minecraft:bookshelf
fill 13 250 504 14 250 504 minecraft:bookshelf
fill 14 250 464 16 250 464 minecraft:bookshelf
fill 16 250 504 18 250 504 minecraft:bookshelf
fill 18 250 464 19 250 464 minecraft:bookshelf
fill 20 250 504 21 250 504 minecraft:bookshelf
fill 21 250 464 23 250 464 minecraft:bookshelf
fill 23 250 504 25 250 504 minecraft:bookshelf
fill 25 250 464 26 250 464 minecraft:bookshelf
fill 27 250 504 28 250 504 minecraft:bookshelf
fill 28 250 464 30 250 464 minecraft:bookshelf
fill 30 250 504 32 250 504 minecraft:bookshelf
fill 32 250 464 33 250 464 minecraft:bookshelf
fill 34 250 504 35 250 504 minecraft:bookshelf
fill 35 250 464 37 250 464 minecraft:bookshelf
fill 37 250 504 39 250 504 minecraft:bookshelf
fill 39 250 464 40 250 464 minecraft:bookshelf
fill 41 250 465 41 250 467 minecraft:bookshelf
fill 41 250 469 41 250 470 minecraft:bookshelf
fill 41 250 472 41 250 474 minecraft:bookshelf
fill 41 250 476 41 250 477 minecraft:bookshelf
fill 41 250 479 41 250 481 minecraft:bookshelf
fill 41 250 483 41 250 484 minecraft:bookshelf
fill 41 250 486 41 250 488 minecraft:bookshelf
fill 41 250 490 41 250 491 minecraft:bookshelf
fill 41 250 493 41 250 495 minecraft:bookshelf
fill 41 250 497 41 250 498 minecraft:bookshelf
fill 41 250 500 41 250 502 minecraft:bookshelf
setblock 41 250 504 minecraft:bookshelf
setblock 1 251 468 minecraft:bookshelf
setblock 1 251 475 minecraft:bookshelf
fill 1 251 482 1 252 482 minecraft:bookshelf
setblock 1 251 489 minecraft:bookshelf
setblock 1 251 496 minecraft:bookshelf
setblock 1 251 503 minecraft:bookshelf
fill 2 251 483 3 251 485 minecraft:bookshelf
setblock 4 251 464 minecraft:bookshelf
setblock 7 251 504 minecraft:bookshelf
setblock 11 251 464 minecraft:bookshelf
setblock 14 251 504 minecraft:bookshelf
setblock 18 251 464 minecraft:bookshelf
setblock 21 251 504 minecraft:bookshelf
setblock 25 251 464 minecraft:bookshelf
setblock 28 251 504 minecraft:bookshelf
setblock 32 251 464 minecraft:bookshelf
setblock 35 251 504 minecraft:bookshelf
setblock 39 251 464 minecraft:bookshelf
setblock 41 251 469 minecraft:bookshelf
setblock 41 251 476 minecraft:bookshelf
setblock 41 251 483 minecraft:bookshelf
setblock 41 251 490 minecraft:bookshelf
setblock 41 251 497 minecraft:bookshelf
fill 1 252 480 3 253 481 minecraft:bookshelf
fill 1 252 484 3 252 484 minecraft:bookshelf
fill 2 252 482 3 252 483 minecraft:bookshelf
setblock 1 253 470 minecraft:bookshelf
fill 1 253 477 3 253 479 minecraft:bookshelf
setblock 1 253 484 minecraft:bookshelf
setblock 1 253 491 minecraft:bookshelf
setblock 1 253 498 minecraft:bookshelf
setblock 2 253 464 minecraft:bookshelf
setblock 2 253 504 minecraft:bookshelf
setblock 9 253 464 minecraft:bookshelf
setblock 9 253 504 minecraft:bookshelf
setblock 16 253 464 minecraft:bookshelf
setblock 16 253 504 minecraft:bookshelf
setblock 23 253 464 minecraft:bookshelf
setblock 23 253 504 minecraft:bookshelf
setblock 30 253 464 minecraft:bookshelf
setblock 30 253 504 minecraft:bookshelf
setblock 37 253 464 minecraft:bookshelf
setblock 37 253 504 minecraft:bookshelf
setblock 41 253 467 minecraft:bookshelf
setblock 41 253 474 minecraft:bookshelf
setblock 41 253 481 minecraft:bookshelf
setblock 41 253 488 minecraft:bookshelf
setblock 41 253 495 minecraft:bookshelf
setblock 41 253 502 minecraft:bookshelf
setblock 1 254 464 minecraft:bookshelf
fill 1 254 471 1 254 475 minecraft:bookshelf
fill 1 254 477 3 254 478 minecraft:bookshelf
setblock 1 254 485 minecraft:bookshelf
setblock 1 254 492 minecraft:bookshelf
setblock 1 254 499 minecraft:bookshelf
fill 2 254 473 3 254 476 minecraft:bookshelf
setblock 3 254 466 minecraft:light[level=12]
setblock 3 254 482 minecraft:light[level=12]
setblock 3 254 490 minecraft:light[level=12]
setblock 3 254 498 minecraft:light[level=12]
setblock 3 254 504 minecraft:bookshelf
setblock 8 254 464 minecraft:bookshelf
setblock 10 254 504 minecraft:bookshelf
setblock 11 254 466 minecraft:light[level=12]
setblock 11 254 474 minecraft:light[level=12]
setblock 11 254 482 minecraft:light[level=12]
setblock 11 254 490 minecraft:light[level=12]
setblock 11 254 498 minecraft:light[level=12]
setblock 15 254 464 minecraft:bookshelf
setblock 17 254 504 minecraft:bookshelf
setblock 19 254 466 minecraft:light[level=12]
setblock 19 254 474 minecraft:light[level=12]
setblock 19 254 490 minecraft:light[level=12]
setblock 19 254 498 minecraft:light[level=12]
setblock 22 254 464 minecraft:bookshelf
setblock 24 254 504 minecraft:bookshelf
setblock 27 254 466 minecraft:light[level=12]
setblock 27 254 474 minecraft:light[level=12]
setblock 27 254 482 minecraft:light[level=12]
setblock 27 254 490 minecraft:light[level=12]
setblock 27 254 498 minecraft:light[level=12]
setblock 29 254 464 minecraft:bookshelf
setblock 31 254 504 minecraft:bookshelf
setblock 35 254 466 minecraft:light[level=12]
setblock 35 254 474 minecraft:light[level=12]
setblock 35 254 482 minecraft:light[level=12]
setblock 35 254 490 minecraft:light[level=12]
setblock 35 254 498 minecraft:light[level=12]
setblock 36 254 464 minecraft:bookshelf
setblock 38 254 504 minecraft:bookshelf
setblock 41 254 466 minecraft:bookshelf
setblock 41 254 473 minecraft:bookshelf
setblock 41 254 480 minecraft:bookshelf
setblock 41 254 487 minecraft:bookshelf
setblock 41 254 494 minecraft:bookshelf
setblock 41 254 501 minecraft:bookshelf
fill 1 255 465 1 256 465 minecraft:bookshelf
fill 1 255 467 1 256 468 minecraft:bookshelf
fill 1 255 470 3 255 474 minecraft:bookshelf
setblock 1 255 479 minecraft:bookshelf
setblock 1 255 486 minecraft:bookshelf
setblock 1 255 493 minecraft:bookshelf
setblock 1 255 500 minecraft:bookshelf
fill 2 255 468 2 256 469 minecraft:bookshelf
fill 3 255 469 3 256 469 minecraft:bookshelf
setblock 3 255 475 minecraft:bookshelf
setblock 4 255 504 minecraft:bookshelf
setblock 7 255 464 minecraft:bookshelf
setblock 11 255 504 minecraft:bookshelf
setblock 14 255 464 minecraft:bookshelf
setblock 18 255 504 minecraft:bookshelf
setblock 21 255 464 minecraft:bookshelf
setblock 25 255 504 minecraft:bookshelf
setblock 28 255 464 minecraft:bookshelf
setblock 32 255 504 minecraft:bookshelf
setblock 35 255 464 minecraft:bookshelf
setblock 39 255 504 minecraft:bookshelf
setblock 41 255 465 minecraft:bookshelf
setblock 41 255 472 minecraft:bookshelf
setblock 41 255 479 minecraft:bookshelf
setblock 41 255 486 minecraft:bookshelf
setblock 41 255 493 minecraft:bookshelf
setblock 41 255 500 minecraft:bookshelf
fill 1 256 464 2 257 464 minecraft:bookshelf
fill 1 256 466 5 256 466 minecraft:bookshelf
setblock 1 256 473 minecraft:bookshelf
setblock 1 256 480 minecraft:bookshelf
setblock 1 256 487 minecraft:bookshelf
setblock 1 256 494 minecraft:bookshelf
setblock 1 256 501 minecraft:bookshelf
fill 2 256 465 4 257 465 minecraft:bookshelf
fill 2 256 467 3 256 467 minecraft:bookshelf
fill 2 256 470 3 256 470 minecraft:bookshelf
setblock 3 256 468 minecraft:bookshelf
setblock 3 256 471 minecraft:bookshelf
setblock 5 256 504 minecraft:bookshelf
fill 6 256 464 6 258 464 minecraft:bookshelf
setblock 12 256 504 minecraft:bookshelf
setblock 13 256 464 minecraft:bookshelf
setblock 19 256 504 minecraft:bookshelf
setblock 20 256 464 minecraft:bookshelf
setblock 26 256 504 minecraft:bookshelf
setblock 27 256 464 minecraft:bookshelf
setblock 33 256 504 minecraft:bookshelf
setblock 34 256 464 minecraft:bookshelf
setblock 40 256 504 minecraft:bookshelf
setblock 41 256 464 minecraft:bookshelf
setblock 41 256 471 minecraft:bookshelf
setblock 41 256 478 minecraft:bookshelf
setblock 41 256 485 minecraft:bookshelf
setblock 41 256 492 minecraft:bookshelf
setblock 41 256 499 minecraft:bookshelf
setblock 1 257 467 minecraft:bookshelf
setblock 1 257 474 minecraft:bookshelf
setblock 1 257 481 minecraft:bookshelf
setblock 1 257 488 minecraft:bookshelf
setblock 1 257 495 minecraft:bookshelf
setblock 1 257 502 minecraft:bookshelf
fill 3 257 466 9 257 466 minecraft:bookshelf
fill 4 257 464 5 257 464 minecraft:bookshelf
fill 5 257 465 9 257 465 minecraft:bookshelf
setblock 6 257 504 minecraft:bookshelf
fill 7 257 464 8 258 464 minecraft:bookshelf
fill 12 257 464 12 260 464 minecraft:bookshelf
setblock 13 257 504 minecraft:bookshelf
setblock 19 257 464 minecraft:bookshelf
setblock 20 257 504 minecraft:bookshelf
setblock 26 257 464 minecraft:bookshelf
setblock 27 257 504 minecraft:bookshelf
setblock 33 257 464 minecraft:bookshelf
setblock 34 257 504 minecraft:bookshelf
setblock 40 257 464 minecraft:bookshelf
setblock 41 257 470 minecraft:bookshelf
setblock 41 257 477 minecraft:bookshelf
setblock 41 257 484 minecraft:bookshelf
setblock 41 257 491 minecraft:bookshelf
setblock 41 257 498 minecraft:bookshelf
setblock 41 257 504 minecraft:bookshelf
setblock 1 258 468 minecraft:bookshelf
setblock 1 258 475 minecraft:bookshelf
setblock 1 258 482 minecraft:bookshelf
setblock 1 258 489 minecraft:bookshelf
setblock 1 258 496 minecraft:bookshelf
setblock 1 258 503 minecraft:bookshelf
setblock 4 258 464 minecraft:bookshelf
fill 7 258 465 13 258 465 minecraft:bookshelf
setblock 7 258 504 minecraft:bookshelf
fill 8 258 466 13 258 466 minecraft:bookshelf
setblock 9 258 464 minecraft:bookshelf
fill 11 258 464 11 260 464 minecraft:bookshelf
setblock 14 258 504 minecraft:bookshelf
setblock 18 258 464 minecraft:bookshelf
setblock 21 258 504 minecraft:bookshelf
setblock 25 258 464 minecraft:bookshelf
setblock 28 258 504 minecraft:bookshelf
setblock 32 258 464 minecraft:bookshelf
setblock 35 258 504 minecraft:bookshelf
setblock 39 258 464 minecraft:bookshelf
setblock 41 258 469 minecraft:bookshelf
setblock 41 258 476 minecraft:bookshelf
setblock 41 258 483 minecraft:bookshelf
setblock 41 258 490 minecraft:bookshelf
setblock 41 258 497 minecraft:bookshelf
fill 11 259 465 16 259 465 minecraft:bookshelf
fill 12 259 466 16 259 466 minecraft:bookshelf
fill 13 259 464 16 260 464 minecraft:bookshelf
fill 1 260 464 1 260 468 minecraft:bookshelf
fill 1 260 470 1 260 475 minecraft:bookshelf
fill 1 260 477 1 260 482 minecraft:bookshelf
fill 1 260 484 1 260 489 minecraft:bookshelf
fill 1 260 491 1 260 496 minecraft:bookshelf
fill 1 260 498 1 260 503 minecraft:bookshelf
setblock 2 260 464 minecraft:bookshelf
fill 2 260 476 7 260 476 minecraft:dark_oak_planks
fill 2 260 504 7 260 504 minecraft:bookshelf
fill 3 260 474 7 261 475 minecraft:dark_oak_planks
fill 3 260 477 7 261 478 minecraft:dark_oak_planks
fill 4 260 464 9 260 464 minecraft:bookshelf
fill 9 260 504 14 260 504 minecraft:bookshelf
fill 15 260 465 19 260 466 minecraft:bookshelf
fill 16 260 504 21 260 504 minecraft:bookshelf
fill 18 260 464 23 260 464 minecraft:bookshelf
fill 23 260 504 28 260 504 minecraft:bookshelf
fill 25 260 464 30 260 464 minecraft:bookshelf
fill 30 260 504 35 260 504 minecraft:bookshelf
fill 32 260 464 37 260 464 minecraft:bookshelf
fill 37 260 504 41 260 504 minecraft:bookshelf
fill 39 260 464 41 260 464 minecraft:bookshelf
fill 41 260 465 41 260 467 minecraft:bookshelf
fill 41 260 469 41 260 474 minecraft:bookshelf
fill 41 260 476 41 260 481 minecraft:bookshelf
fill 41 260 483 41 260 488 minecraft:bookshelf
fill 41 260 490 41 260 495 minecraft:bookshelf
fill 41 260 497 41 260 502 minecraft:bookshelf
setblock 1 261 464 minecraft:bookshelf
setblock 1 261 471 minecraft:bookshelf
setblock 1 261 478 minecraft:bookshelf
setblock 1 261 485 minecraft:bookshelf
setblock 1 261 492 minecraft:bookshelf
setblock 1 261 499 minecraft:bookshelf
fill 3 261 476 7 261 476 minecraft:dark_oak_planks
setblock 3 261 504 minecraft:bookshelf
setblock 8 261 464 minecraft:bookshelf
setblock 10 261 504 minecraft:bookshelf
setblock 15 261 464 minecraft:bookshelf
setblock 17 261 504 minecraft:bookshelf
fill 18 261 464 22 261 466 minecraft:bookshelf
setblock 24 261 504 minecraft:bookshelf
setblock 29 261 464 minecraft:bookshelf
setblock 31 261 504 minecraft:bookshelf
setblock 36 261 464 minecraft:bookshelf
setblock 38 261 504 minecraft:bookshelf
setblock 41 261 466 minecraft:bookshelf
setblock 41 261 473 minecraft:bookshelf
setblock 41 261 480 minecraft:bookshelf
setblock 41 261 487 minecraft:bookshelf
setblock 41 261 494 minecraft:bookshelf
setblock 41 261 501 minecraft:bookshelf
setblock 1 262 465 minecraft:bookshelf
setblock 1 262 472 minecraft:bookshelf
setblock 1 262 479 minecraft:bookshelf
setblock 1 262 486 minecraft:bookshelf
setblock 1 262 493 minecraft:bookshelf
setblock 1 262 500 minecraft:bookshelf
setblock 3 262 466 minecraft:light[level=12]
setblock 3 262 474 minecraft:light[level=12]
setblock 3 262 482 minecraft:light[level=12]
setblock 3 262 490 minecraft:light[level=12]
setblock 3 262 498 minecraft:light[level=12]
fill 4 262 476 6 267 476 minecraft:purple_concrete
setblock 4 262 504 minecraft:bookshelf
fill 5 262 475 5 267 475 minecraft:purple_concrete
fill 5 262 477 5 267 477 minecraft:purple_concrete
setblock 7 262 464 minecraft:bookshelf
setblock 11 262 466 minecraft:light[level=12]
setblock 11 262 474 minecraft:light[level=12]
setblock 11 262 482 minecraft:light[level=12]
fill 11 262 490 12 263 490 minecraft:red_wool
setblock 11 262 498 minecraft:light[level=12]
setblock 11 262 504 minecraft:bookshelf
setblock 14 262 464 minecraft:bookshelf
setblock 18 262 504 minecraft:bookshelf
setblock 19 262 466 minecraft:light[level=12]
setblock 19 262 474 minecraft:light[level=12]
setblock 19 262 490 minecraft:light[level=12]
setblock 19 262 498 minecraft:light[level=12]
fill 21 262 464 23 262 466 minecraft:bookshelf
fill 24 262 465 25 263 466 minecraft:bookshelf
fill 25 262 464 25 263 464 minecraft:bookshelf
setblock 25 262 504 minecraft:bookshelf
setblock 27 262 466 minecraft:light[level=12]
setblock 27 262 474 minecraft:light[level=12]
setblock 27 262 482 minecraft:light[level=12]
setblock 27 262 490 minecraft:light[level=12]
setblock 27 262 498 minecraft:light[level=12]
fill 28 262 464 28 264 464 minecraft:bookshelf
setblock 32 262 504 minecraft:bookshelf
setblock 35 262 464 minecraft:bookshelf
setblock 35 262 466 minecraft:light[level=12]
setblock 35 262 474 minecraft:light[level=12]
setblock 35 262 482 minecraft:light[level=12]
setblock 35 262 490 minecraft:light[level=12]
setblock 35 262 498 minecraft:light[level=12]
setblock 39 262 504 minecraft:bookshelf
setblock 41 262 465 minecraft:bookshelf
setblock 41 262 472 minecraft:bookshelf
setblock 41 262 479 minecraft:bookshelf
setblock 41 262 486 minecraft:bookshelf
setblock 41 262 493 minecraft:bookshelf
setblock 41 262 500 minecraft:bookshelf
setblock 1 263 466 minecraft:bookshelf
setblock 1 263 473 minecraft:bookshelf
setblock 1 263 480 minecraft:bookshelf
setblock 1 263 487 minecraft:bookshelf
setblock 1 263 494 minecraft:bookshelf
setblock 1 263 501 minecraft:bookshelf
setblock 5 263 504 minecraft:bookshelf
setblock 6 263 464 minecraft:bookshelf
setblock 12 263 504 minecraft:bookshelf
setblock 13 263 464 minecraft:bookshelf
setblock 19 263 504 minecraft:bookshelf
setblock 20 263 464 minecraft:bookshelf
fill 26 263 464 27 263 466 minecraft:bookshelf
setblock 26 263 504 minecraft:bookshelf
fill 28 263 465 28 264 466 minecraft:bookshelf
fill 29 263 464 29 264 464 minecraft:bookshelf
setblock 33 263 504 minecraft:bookshelf
setblock 34 263 464 minecraft:bookshelf
setblock 40 263 504 minecraft:bookshelf
setblock 41 263 464 minecraft:bookshelf
setblock 41 263 471 minecraft:bookshelf
setblock 41 263 478 minecraft:bookshelf
setblock 41 263 485 minecraft:bookshelf
setblock 41 263 492 minecraft:bookshelf
setblock 41 263 499 minecraft:bookshelf
setblock 1 264 467 minecraft:bookshelf
setblock 1 264 474 minecraft:bookshelf
setblock 1 264 481 minecraft:bookshelf
setblock 1 264 488 minecraft:bookshelf
setblock 1 264 495 minecraft:bookshelf
setblock 1 264 502 minecraft:bookshelf
setblock 5 264 464 minecraft:bookshelf
setblock 6 264 504 minecraft:bookshelf
setblock 12 264 464 minecraft:bookshelf
setblock 13 264 504 minecraft:bookshelf
setblock 19 264 464 minecraft:bookshelf
setblock 20 264 504 minecraft:bookshelf
setblock 26 264 464 minecraft:bookshelf
fill 27 264 465 27 264 466 minecraft:bookshelf
setblock 27 264 504 minecraft:bookshelf
fill 29 264 465 32 264 466 minecraft:bookshelf
setblock 30 264 464 minecraft:bookshelf
fill 32 264 464 33 265 464 minecraft:bookshelf
setblock 34 264 504 minecraft:bookshelf
setblock 40 264 464 minecraft:bookshelf
setblock 41 264 470 minecraft:bookshelf
setblock 41 264 477 minecraft:bookshelf
setblock 41 264 484 minecraft:bookshelf
setblock 41 264 491 minecraft:bookshelf
setblock 41 264 498 minecraft:bookshelf
setblock 41 264 504 minecraft:bookshelf
setblock 1 265 468 minecraft:bookshelf
setblock 1 265 475 minecraft:bookshelf
setblock 1 265 482 minecraft:bookshelf
setblock 1 265 489 minecraft:bookshelf
setblock 1 265 496 minecraft:bookshelf
setblock 1 265 503 minecraft:bookshelf
setblock 4 265 464 minecraft:bookshelf
setblock 7 265 504 minecraft:bookshelf
setblock 11 265 464 minecraft:bookshelf
fill 11 265 494 12 266 495 minecraft:white_wool
setblock 14 265 504 minecraft:bookshelf
setblock 18 265 464 minecraft:bookshelf
setblock 21 265 504 minecraft:bookshelf
setblock 25 265 464 minecraft:bookshelf
setblock 28 265 504 minecraft:bookshelf
fill 30 265 466 36 265 466 minecraft:bookshelf
fill 31 265 465 37 265 465 minecraft:bookshelf
fill 34 265 464 37 265 464 minecraft:bookshelf
setblock 35 265 504 minecraft:bookshelf
fill 39 265 464 39 266 464 minecraft:bookshelf
setblock 41 265 469 minecraft:bookshelf
setblock 41 265 476 minecraft:bookshelf
setblock 41 265 483 minecraft:bookshelf
setblock 41 265 490 minecraft:bookshelf
setblock 41 265 497 minecraft:bookshelf
fill 34 266 466 41 266 466 minecraft:bookshelf
fill 35 266 465 41 266 465 minecraft:bookshelf
fill 36 266 464 37 266 464 minecraft:bookshelf
fill 39 266 467 39 267 468 minecraft:bookshelf
fill 40 266 464 41 266 464 minecraft:bookshelf
fill 40 266 467 40 267 467 minecraft:bookshelf
setblock 1 267 470 minecraft:bookshelf
setblock 1 267 477 minecraft:bookshelf
setblock 1 267 484 minecraft:bookshelf
setblock 1 267 491 minecraft:bookshelf
setblock 1 267 498 minecraft:bookshelf
setblock 2 267 464 minecraft:bookshelf
setblock 2 267 504 minecraft:bookshelf
setblock 9 267 464 minecraft:bookshelf
setblock 9 267 504 minecraft:bookshelf
setblock 16 267 464 minecraft:bookshelf
setblock 16 267 504 minecraft:bookshelf
setblock 23 267 464 minecraft:bookshelf
setblock 23 267 504 minecraft:bookshelf
setblock 30 267 464 minecraft:bookshelf
setblock 30 267 504 minecraft:bookshelf
setblock 37 267 464 minecraft:bookshelf
setblock 37 267 504 minecraft:bookshelf
fill 39 267 466 41 267 466 minecraft:bookshelf
fill 39 267 469 40 267 472 minecraft:bookshelf
fill 40 267 465 41 267 465 minecraft:bookshelf
setblock 40 267 468 minecraft:bookshelf
setblock 41 267 464 minecraft:bookshelf
setblock 41 267 467 minecraft:bookshelf
fill 41 267 469 41 268 471 minecraft:bookshelf
fill 41 267 474 41 270 474 minecraft:bookshelf
setblock 41 267 481 minecraft:bookshelf
setblock 41 267 488 minecraft:bookshelf
setblock 41 267 495 minecraft:bookshelf
setblock 41 267 502 minecraft:bookshelf
setblock 1 268 464 minecraft:bookshelf
setblock 1 268 471 minecraft:bookshelf
setblock 1 268 478 minecraft:bookshelf
setblock 1 268 485 minecraft:bookshelf
setblock 1 268 492 minecraft:bookshelf
setblock 1 268 499 minecraft:bookshelf
setblock 3 268 504 minecraft:bookshelf
setblock 8 268 464 minecraft:bookshelf
setblock 10 268 504 minecraft:bookshelf
setblock 15 268 464 minecraft:bookshelf
setblock 17 268 504 minecraft:bookshelf
setblock 22 268 464 minecraft:bookshelf
setblock 24 268 504 minecraft:bookshelf
setblock 29 268 464 minecraft:bookshelf
setblock 31 268 504 minecraft:bookshelf
setblock 36 268 464 minecraft:bookshelf
setblock 38 268 504 minecraft:bookshelf
fill 39 268 471 40 268 476 minecraft:bookshelf
setblock 40 268 470 minecraft:bookshelf
setblock 41 268 466 minecraft:bookshelf
fill 41 268 472 41 268 473 minecraft:bookshelf
setblock 41 268 480 minecraft:bookshelf
setblock 41 268 487 minecraft:bookshelf
setblock 41 268 494 minecraft:bookshelf
setblock 41 268 501 minecraft:bookshelf
fill 1 269 465 1 270 465 minecraft:bookshelf
fill 1 269 472 1 270 472 minecraft:bookshelf
fill 1 269 479 1 270 479 minecraft:bookshelf
fill 1 269 486 1 270 486 minecraft:bookshelf
fill 1 269 493 1 270 493 minecraft:bookshelf
fill 1 269 500 1 270 500 minecraft:bookshelf
fill 4 269 504 4 270 504 minecraft:bookshelf
fill 7 269 464 7 270 464 minecraft:bookshelf
fill 11 269 504 11 270 504 minecraft:bookshelf
fill 14 269 464 14 270 464 minecraft:bookshelf
fill 18 269 504 18 270 504 minecraft:bookshelf
fill 21 269 464 21 270 464 minecraft:bookshelf
fill 25 269 504 25 270 504 minecraft:bookshelf
fill 28 269 464 28 270 464 minecraft:bookshelf
fill 32 269 504 32 270 504 minecraft:bookshelf
fill 35 269 464 35 270 464 minecraft:bookshelf
fill 39 269 475 40 269 479 minecraft:bookshelf
fill 39 269 504 39 270 504 minecraft:bookshelf
setblock 40 269 474 minecraft:bookshelf
fill 41 269 465 41 270 465 minecraft:bookshelf
fill 41 269 472 41 270 472 minecraft:bookshelf
fill 41 269 476 41 270 479 minecraft:bookshelf
fill 41 269 486 41 270 486 minecraft:bookshelf
fill 41 269 493 41 270 493 minecraft:bookshelf
fill 41 269 500 41 270 500 minecraft:bookshelf
fill 1 270 464 2 270 464 minecraft:bookshelf
fill 1 270 466 1 270 468 minecraft:bookshelf
fill 1 270 470 1 270 471 minecraft:bookshelf
fill 1 270 473 1 270 475 minecraft:bookshelf
fill 1 270 477 1 270 478 minecraft:bookshelf
fill 1 270 480 1 270 482 minecraft:bookshelf
fill 1 270 484 1 270 485 minecraft:bookshelf
fill 1 270 487 1 270 489 minecraft:bookshelf
fill 1 270 491 1 270 492 minecraft:bookshelf
fill 1 270 494 1 270 496 minecraft:bookshelf
fill 1 270 498 1 270 499 minecraft:bookshelf
fill 1 270 501 1 270 503 minecraft:bookshelf
fill 2 270 504 3 270 504 minecraft:bookshelf
setblock 3 270 466 minecraft:light[level=12]
setblock 3 270 474 minecraft:light[level=12]
setblock 3 270 482 minecraft:light[level=12]
setblock 3 270 490 minecraft:light[level=12]
setblock 3 270 498 minecraft:light[level=12]
fill 4 270 464 6 270 464 minecraft:bookshelf
fill 5 270 504 7 270 504 minecraft:bookshelf
fill 8 270 464 9 270 464 minecraft:bookshelf
fill 8 270 478 8 272 478 minecraft:purple_stained_glass
fill 8 270 479 8 273 479 minecraft:dark_oak_planks
fill 8 270 480 8 273 484 minecraft:purple_stained_glass
fill 8 270 485 8 273 485 minecraft:dark_oak_planks
fill 8 270 486 8 272 486 minecraft:purple_stained_glass
fill 9 270 476 9 272 477 minecraft:purple_stained_glass
fill 9 270 487 9 272 488 minecraft:purple_stained_glass
fill 9 270 504 10 270 504 minecraft:bookshelf
fill 10 270 475 10 273 475 minecraft:purple_stained_glass
fill 10 270 489 10 273 489 minecraft:purple_stained_glass
fill 11 270 464 13 270 464 minecraft:bookshelf
setblock 11 270 466 minecraft:light[level=12]
fill 11 270 474 11 273 474 minecraft:dark_oak_planks
setblock 11 270 482 minecraft:light[level=12]
fill 11 270 490 11 273 490 minecraft:dark_oak_planks
setblock 11 270 498 minecraft:light[level=12]
fill 12 270 473 12 273 473 minecraft:purple_stained_glass
fill 12 270 491 12 273 491 minecraft:purple_stained_glass
fill 12 270 504 14 270 504 minecraft:bookshelf
fill 13 270 472 14 272 472 minecraft:purple_stained_glass
fill 13 270 492 14 272 492 minecraft:purple_stained_glass
fill 15 270 464 16 270 464 minecraft:bookshelf
fill 15 270 471 15 272 471 minecraft:purple_stained_glass
fill 15 270 493 15 272 493 minecraft:purple_stained_glass
fill 16 270 471 16 273 471 minecraft:dark_oak_planks
fill 16 270 493 16 273 493 minecraft:dark_oak_planks
fill 16 270 504 17 270 504 minecraft:bookshelf
fill 17 270 471 21 273 471 minecraft:purple_stained_glass
fill 17 270 493 21 273 493 minecraft:purple_stained_glass
fill 18 270 464 20 270 464 minecraft:bookshelf
setblock 19 270 466 minecraft:light[level=12]
setblock 19 270 474 minecraft:light[level=12]
setblock 19 270 490 minecraft:light[level=12]
setblock 19 270 498 minecraft:light[level=12]
fill 19 270 504 21 270 504 minecraft:bookshelf
fill 22 270 464 23 270 464 minecraft:bookshelf
fill 22 270 471 22 273 471 minecraft:dark_oak_planks
fill 22 270 493 22 273 493 minecraft:dark_oak_planks
fill 23 270 471 23 272 471 minecraft:purple_stained_glass
fill 23 270 493 23 272 493 minecraft:purple_stained_glass
fill 23 270 504 24 270 504 minecraft:bookshelf
fill 24 270 472 25 272 472 minecraft:purple_stained_glass
fill 24 270 492 25 272 492 minecraft:purple_stained_glass
fill 25 270 464 27 270 464 minecraft:bookshelf
fill 26 270 473 26 273 473 minecraft:purple_stained_glass
fill 26 270 491 26 273 491 minecraft:purple_stained_glass
fill 26 270 504 28 270 504 minecraft:bookshelf
setblock 27 270 466 minecraft:light[level=12]
fill 27 270 474 27 273 474 minecraft:dark_oak_planks
setblock 27 270 482 minecraft:light[level=12]
fill 27 270 490 27 273 490 minecraft:dark_oak_planks
setblock 27 270 498 minecraft:light[level=12]
fill 28 270 475 28 273 475 minecraft:purple_stained_glass
fill 28 270 489 28 273 489 minecraft:purple_stained_glass
fill 29 270 464 30 270 464 minecraft:bookshelf
fill 29 270 476 29 272 477 minecraft:purple_stained_glass
fill 29 270 487 29 272 488 minecraft:purple_stained_glass
fill 30 270 478 30 272 478 minecraft:purple_stained_glass
fill 30 270 479 30 273 479 minecraft:dark_oak_planks
fill 30 270 480 30 273 484 minecraft:purple_stained_glass
fill 30 270 485 30 273 485 minecraft:dark_oak_planks
fill 30 270 486 30 272 486 minecraft:purple_stained_glass
fill 30 270 504 31 270 504 minecraft:bookshelf
fill 32 270 464 34 270 464 minecraft:bookshelf
fill 33 270 504 35 270 504 minecraft:bookshelf
setblock 35 270 466 minecraft:light[level=12]
setblock 35 270 474 minecraft:light[level=12]
setblock 35 270 482 minecraft:light[level=12]
setblock 35 270 490 minecraft:light[level=12]
setblock 35 270 498 minecraft:light[level=12]
fill 36 270 464 37 270 464 minecraft:bookshelf
fill 37 270 504 38 270 504 minecraft:bookshelf
fill 39 270 464 41 270 464 minecraft:bookshelf
fill 39 270 478 40 270 482 minecraft:bookshelf
fill 40 270 504 41 270 504 minecraft:bookshelf
fill 41 270 466 41 270 467 minecraft:bookshelf
fill 41 270 469 41 270 471 minecraft:bookshelf
setblock 41 270 473 minecraft:bookshelf
fill 41 270 480 41 270 481 minecraft:bookshelf
fill 41 270 483 41 272 485 minecraft:bookshelf
fill 41 270 487 41 270 488 minecraft:bookshelf
fill 41 270 490 41 270 492 minecraft:bookshelf
fill 41 270 494 41 270 495 minecraft:bookshelf
fill 41 270 497 41 270 499 minecraft:bookshelf
fill 41 270 501 41 270 502 minecraft:bookshelf
setblock 1 271 467 minecraft:bookshelf
setblock 1 271 474 minecraft:bookshelf
setblock 1 271 481 minecraft:bookshelf
setblock 1 271 488 minecraft:bookshelf
setblock 1 271 495 minecraft:bookshelf
setblock 1 271 502 minecraft:bookshelf
setblock 5 271 464 minecraft:bookshelf
setblock 6 271 504 minecraft:bookshelf
fill 10 271 476 10 274 476 minecraft:purple_stained_glass
fill 10 271 488 10 274 488 minecraft:purple_stained_glass
setblock 12 271 464 minecraft:bookshelf
fill 13 271 473 13 274 473 minecraft:purple_stained_glass
fill 13 271 491 13 274 491 minecraft:purple_stained_glass
setblock 13 271 504 minecraft:bookshelf
setblock 19 271 464 minecraft:bookshelf
setblock 20 271 504 minecraft:bookshelf
fill 24 271 476 24 272 477 minecraft:blue_wool
fill 25 271 473 25 274 473 minecraft:purple_stained_glass
fill 25 271 491 25 274 491 minecraft:purple_stained_glass
setblock 26 271 464 minecraft:bookshelf
setblock 27 271 504 minecraft:bookshelf
fill 28 271 476 28 274 476 minecraft:purple_stained_glass
fill 28 271 488 28 274 488 minecraft:purple_stained_glass
setblock 33 271 464 minecraft:bookshelf
setblock 34 271 504 minecraft:bookshelf
fill 39 271 481 40 271 485 minecraft:bookshelf
setblock 40 271 464 minecraft:bookshelf
setblock 41 271 470 minecraft:bookshelf
setblock 41 271 477 minecraft:bookshelf
setblock 41 271 481 minecraft:bookshelf
setblock 41 271 491 minecraft:bookshelf
setblock 41 271 498 minecraft:bookshelf
setblock 41 271 504 minecraft:bookshelf
setblock 1 272 468 minecraft:bookshelf
setblock 1 272 475 minecraft:bookshelf
setblock 1 272 482 minecraft:bookshelf
setblock 1 272 489 minecraft:bookshelf
setblock 1 272 496 minecraft:bookshelf
setblock 1 272 503 minecraft:bookshelf
setblock 4 272 464 minecraft:bookshelf
setblock 5 272 476 minecraft:ochre_froglight
setblock 7 272 504 minecraft:bookshelf
fill 9 272 478 9 274 478 minecraft:purple_stained_glass
fill 9 272 486 9 274 486 minecraft:purple_stained_glass
setblock 11 272 464 minecraft:bookshelf
fill 11 272 475 11 275 475 minecraft:purple_stained_glass
fill 11 272 489 11 275 489 minecraft:purple_stained_glass
fill 12 272 474 12 275 474 minecraft:purple_stained_glass
fill 12 272 490 12 275 490 minecraft:purple_stained_glass
setblock 14 272 504 minecraft:bookshelf
fill 15 272 472 15 274 472 minecraft:purple_stained_glass
fill 15 272 492 15 274 492 minecraft:purple_stained_glass
setblock 18 272 464 minecraft:bookshelf
setblock 21 272 504 minecraft:bookshelf
fill 23 272 472 23 274 472 minecraft:purple_stained_glass
fill 23 272 492 23 274 492 minecraft:purple_stained_glass
setblock 25 272 464 minecraft:bookshelf
fill 26 272 474 26 275 474 minecraft:purple_stained_glass
fill 26 272 490 26 275 490 minecraft:purple_stained_glass
fill 27 272 475 27 275 475 minecraft:purple_stained_glass
fill 27 272 489 27 275 489 minecraft:purple_stained_glass
setblock 28 272 504 minecraft:bookshelf
fill 29 272 478 29 274 478 minecraft:purple_stained_glass
fill 29 272 486 29 274 486 minecraft:purple_stained_glass
setblock 32 272 464 minecraft:bookshelf
setblock 35 272 504 minecraft:bookshelf
setblock 39 272 464 minecraft:bookshelf
fill 39 272 484 40 272 488 minecraft:bookshelf
setblock 41 272 469 minecraft:bookshelf
setblock 41 272 476 minecraft:bookshelf
fill 41 272 486 41 272 488 minecraft:bookshelf
fill 41 272 490 41 273 490 minecraft:bookshelf
setblock 41 272 497 minecraft:bookshelf
setblock 9 273 477 minecraft:purple_stained_glass
fill 9 273 479 9 275 479 minecraft:dark_oak_planks
fill 9 273 485 9 275 485 minecraft:dark_oak_planks
setblock 9 273 487 minecraft:purple_stained_glass
setblock 14 273 472 minecraft:purple_stained_glass
setblock 14 273 492 minecraft:purple_stained_glass
fill 16 273 472 16 275 472 minecraft:dark_oak_planks
fill 16 273 492 16 275 492 minecraft:dark_oak_planks
fill 22 273 472 22 275 472 minecraft:dark_oak_planks
fill 22 273 492 22 275 492 minecraft:dark_oak_planks
setblock 24 273 472 minecraft:purple_stained_glass
setblock 24 273 492 minecraft:purple_stained_glass
setblock 29 273 477 minecraft:purple_stained_glass
fill 29 273 479 29 275 479 minecraft:dark_oak_planks
fill 29 273 485 29 275 485 minecraft:dark_oak_planks
setblock 29 273 487 minecraft:purple_stained_glass
fill 39 273 487 40 273 491 minecraft:bookshelf
fill 41 273 487 41 273 488 minecraft:bookshelf
fill 41 273 491 41 273 492 minecraft:bookshelf
fill 8 274 481 9 274 483 minecraft:purple_stained_glass
fill 9 274 480 9 275 480 minecraft:purple_stained_glass
fill 9 274 484 9 275 484 minecraft:purple_stained_glass
fill 10 274 477 10 275 477 minecraft:purple_stained_glass
fill 10 274 487 10 275 487 minecraft:purple_stained_glass
fill 11 274 476 11 276 476 minecraft:purple_stained_glass
fill 11 274 488 11 276 488 minecraft:purple_stained_glass
fill 13 274 474 13 276 474 minecraft:purple_stained_glass
fill 13 274 490 13 276 490 minecraft:purple_stained_glass
fill 14 274 473 14 275 473 minecraft:purple_stained_glass
fill 14 274 491 14 275 491 minecraft:purple_stained_glass
fill 17 274 472 21 275 472 minecraft:purple_stained_glass
fill 17 274 492 21 275 492 minecraft:purple_stained_glass
fill 18 274 471 20 274 471 minecraft:purple_stained_glass
fill 18 274 493 20 274 493 minecraft:purple_stained_glass
fill 24 274 473 24 275 473 minecraft:purple_stained_glass
fill 24 274 491 24 275 491 minecraft:purple_stained_glass
fill 25 274 474 25 276 474 minecraft:purple_stained_glass
fill 25 274 490 25 276 490 minecraft:purple_stained_glass
fill 27 274 476 27 276 476 minecraft:purple_stained_glass
fill 27 274 488 27 276 488 minecraft:purple_stained_glass
fill 28 274 477 28 275 477 minecraft:purple_stained_glass
fill 28 274 487 28 275 487 minecraft:purple_stained_glass
fill 29 274 480 29 275 484 minecraft:purple_stained_glass
fill 30 274 481 30 274 483 minecraft:purple_stained_glass
fill 9 275 481 9 276 483 minecraft:purple_stained_glass
fill 10 275 478 10 276 479 minecraft:purple_stained_glass
fill 10 275 485 10 276 486 minecraft:purple_stained_glass
fill 11 275 477 11 276 477 minecraft:purple_stained_glass
fill 11 275 487 11 276 487 minecraft:purple_stained_glass
fill 12 275 475 12 276 475 minecraft:dark_oak_planks
fill 12 275 489 12 276 489 minecraft:dark_oak_planks
fill 14 275 474 14 276 474 minecraft:purple_stained_glass
fill 14 275 490 14 276 490 minecraft:purple_stained_glass
fill 15 275 473 16 276 473 minecraft:purple_stained_glass
fill 15 275 491 16 276 491 minecraft:purple_stained_glass
fill 22 275 473 23 276 473 minecraft:purple_stained_glass
fill 22 275 491 23 276 491 minecraft:purple_stained_glass
fill 24 275 474 24 276 474 minecraft:purple_stained_glass
fill 24 275 490 24 276 490 minecraft:purple_stained_glass
fill 26 275 475 26 276 475 minecraft:dark_oak_planks
fill 26 275 489 26 276 489 minecraft:dark_oak_planks
fill 27 275 477 27 276 477 minecraft:purple_stained_glass
fill 27 275 487 27 276 487 minecraft:purple_stained_glass
fill 28 275 478 28 276 479 minecraft:purple_stained_glass
fill 28 275 485 28 276 486 minecraft:purple_stained_glass
fill 10 276 480 10 277 484 minecraft:purple_stained_glass
fill 11 276 478 11 277 478 minecraft:purple_stained_glass
fill 11 276 486 11 277 486 minecraft:purple_stained_glass
fill 12 276 476 12 277 476 minecraft:purple_stained_glass
fill 12 276 488 12 277 488 minecraft:purple_stained_glass
fill 13 276 475 13 277 475 minecraft:purple_stained_glass
fill 13 276 489 13 277 489 minecraft:purple_stained_glass
fill 15 276 474 15 277 474 minecraft:purple_stained_glass
fill 15 276 490 15 277 490 minecraft:purple_stained_glass
fill 17 276 473 21 277 473 minecraft:purple_stained_glass
fill 17 276 491 21 277 491 minecraft:purple_stained_glass
fill 18 276 472 20 276 472 minecraft:purple_stained_glass
fill 18 276 492 20 276 492 minecraft:purple_stained_glass
fill 23 276 474 23 277 474 minecraft:purple_stained_glass
fill 23 276 490 23 277 490 minecraft:purple_stained_glass
fill 25 276 475 25 277 475 minecraft:purple_stained_glass
fill 25 276 489 25 277 489 minecraft:purple_stained_glass
fill 26 276 476 26 277 476 minecraft:purple_stained_glass
fill 26 276 488 26 277 488 minecraft:purple_stained_glass
fill 27 276 478 27 277 478 minecraft:purple_stained_glass
fill 27 276 486 27 277 486 minecraft:purple_stained_glass
fill 28 276 480 28 277 484 minecraft:purple_stained_glass
fill 29 276 481 29 276 483 minecraft:purple_stained_glass
setblock 11 277 479 minecraft:purple_stained_glass
fill 11 277 480 11 278 480 minecraft:dark_oak_planks
fill 11 277 481 11 278 483 minecraft:purple_stained_glass
fill 11 277 484 11 278 484 minecraft:dark_oak_planks
setblock 11 277 485 minecraft:purple_stained_glass
fill 12 277 477 12 277 478 minecraft:purple_stained_glass
fill 12 277 486 12 277 487 minecraft:purple_stained_glass
setblock 13 277 476 minecraft:dark_oak_planks
setblock 13 277 488 minecraft:dark_oak_planks
fill 14 277 475 15 277 475 minecraft:purple_stained_glass
fill 14 277 489 15 277 489 minecraft:purple_stained_glass
setblock 16 277 474 minecraft:purple_stained_glass
setblock 16 277 490 minecraft:purple_stained_glass
fill 17 277 474 17 278 474 minecraft:dark_oak_planks
fill 17 277 490 17 278 490 minecraft:dark_oak_planks
fill 18 277 474 20 278 474 minecraft:purple_stained_glass
fill 18 277 490 20 278 490 minecraft:purple_stained_glass
fill 21 277 474 21 278 474 minecraft:dark_oak_planks
fill 21 277 490 21 278 490 minecraft:dark_oak_planks
setblock 22 277 474 minecraft:purple_stained_glass
setblock 22 277 490 minecraft:purple_stained_glass
fill 23 277 475 24 277 475 minecraft:purple_stained_glass
fill 23 277 489 24 277 489 minecraft:purple_stained_glass
setblock 25 277 476 minecraft:dark_oak_planks
setblock 25 277 488 minecraft:dark_oak_planks
fill 26 277 477 26 277 478 minecraft:purple_stained_glass
fill 26 277 486 26 277 487 minecraft:purple_stained_glass
setblock 27 277 479 minecraft:purple_stained_glass
fill 27 277 480 27 278 480 minecraft:dark_oak_planks
fill 27 277 481 27 278 483 minecraft:purple_stained_glass
fill 27 277 484 27 278 484 minecraft:dark_oak_planks
setblock 27 277 485 minecraft:purple_stained_glass
setblock 3 278 466 minecraft:light[level=12]
setblock 3 278 474 minecraft:light[level=12]
setblock 3 278 482 minecraft:light[level=12]
setblock 3 278 490 minecraft:light[level=12]
setblock 3 278 498 minecraft:light[level=12]
setblock 11 278 466 minecraft:light[level=12]
setblock 11 278 474 minecraft:light[level=12]
setblock 11 278 490 minecraft:light[level=12]
setblock 11 278 498 minecraft:light[level=12]
fill 12 278 478 12 278 479 minecraft:purple_stained_glass
fill 12 278 480 12 279 480 minecraft:dark_oak_planks
fill 12 278 481 12 280 483 minecraft:purple_stained_glass
fill 12 278 484 12 279 484 minecraft:dark_oak_planks
fill 12 278 485 12 278 486 minecraft:purple_stained_glass
fill 13 278 477 13 278 478 minecraft:purple_stained_glass
fill 13 278 486 13 278 487 minecraft:purple_stained_glass
fill 14 278 476 15 278 476 minecraft:purple_stained_glass
fill 14 278 477 14 279 477 minecraft:dark_oak_planks
fill 14 278 487 14 279 487 minecraft:dark_oak_planks
fill 14 278 488 15 278 488 minecraft:purple_stained_glass
fill 15 278 475 16 278 475 minecraft:purple_stained_glass
fill 15 278 489 16 278 489 minecraft:purple_stained_glass
fill 17 278 475 17 279 475 minecraft:dark_oak_planks
fill 17 278 489 17 279 489 minecraft:dark_oak_planks
fill 18 278 475 20 280 475 minecraft:purple_stained_glass
fill 18 278 489 20 280 489 minecraft:purple_stained_glass
setblock 19 278 466 minecraft:light[level=12]
setblock 19 278 498 minecraft:light[level=12]
fill 21 278 475 21 279 475 minecraft:dark_oak_planks
fill 21 278 489 21 279 489 minecraft:dark_oak_planks
fill 22 278 475 23 278 475 minecraft:purple_stained_glass
fill 22 278 489 23 278 489 minecraft:purple_stained_glass
fill 23 278 476 24 278 476 minecraft:purple_stained_glass
fill 23 278 488 24 278 488 minecraft:purple_stained_glass
fill 24 278 477 24 279 477 minecraft:dark_oak_planks
fill 24 278 487 24 279 487 minecraft:dark_oak_planks
fill 25 278 477 25 278 478 minecraft:purple_stained_glass
fill 25 278 486 25 278 487 minecraft:purple_stained_glass
fill 26 278 478 26 278 479 minecraft:purple_stained_glass
fill 26 278 480 26 279 480 minecraft:dark_oak_planks
fill 26 278 481 26 280 483 minecraft:purple_stained_glass
fill 26 278 484 26 279 484 minecraft:dark_oak_planks
fill 26 278 485 26 278 486 minecraft:purple_stained_glass
setblock 27 278 466 minecraft:light[level=12]
setblock 27 278 474 minecraft:light[level=12]
setblock 27 278 490 minecraft:light[level=12]
setblock 27 278 498 minecraft:light[level=12]
setblock 35 278 466 minecraft:light[level=12]
setblock 35 278 474 minecraft:light[level=12]
setblock 35 278 482 minecraft:light[level=12]
setblock 35 278 490 minecraft:light[level=12]
setblock 35 278 498 minecraft:light[level=12]
fill 13 279 478 13 280 486 minecraft:purple_stained_glass
fill 14 279 478 14 280 480 minecraft:purple_stained_glass
fill 14 279 484 14 280 486 minecraft:purple_stained_glass
fill 15 279 476 17 280 477 minecraft:purple_stained_glass
setblock 15 279 478 minecraft:dark_oak_planks
setblock 15 279 486 minecraft:dark_oak_planks
fill 15 279 487 17 280 488 minecraft:purple_stained_glass
fill 18 279 476 23 280 476 minecraft:purple_stained_glass
fill 18 279 488 23 280 488 minecraft:purple_stained_glass
fill 21 279 477 23 280 477 minecraft:purple_stained_glass
fill 21 279 487 23 280 487 minecraft:purple_stained_glass
setblock 23 279 478 minecraft:dark_oak_planks
setblock 23 279 486 minecraft:dark_oak_planks
fill 24 279 478 25 280 480 minecraft:purple_stained_glass
fill 24 279 484 25 280 486 minecraft:purple_stained_glass
fill 25 279 481 25 280 483 minecraft:purple_stained_glass
fill 1 280 464 9 280 504 minecraft:dark_oak_planks
fill 10 280 464 10 280 478 minecraft:dark_oak_planks
fill 10 280 479 11 280 485 minecraft:purple_stained_glass
fill 10 280 486 10 280 504 minecraft:dark_oak_planks
fill 11 280 464 11 280 476 minecraft:dark_oak_planks
fill 11 280 477 12 280 478 minecraft:purple_stained_glass
fill 11 280 486 12 280 487 minecraft:purple_stained_glass
fill 11 280 488 11 280 504 minecraft:dark_oak_planks
fill 12 280 464 12 280 475 minecraft:dark_oak_planks
fill 12 280 476 14 280 476 minecraft:purple_stained_glass
fill 12 280 479 12 280 480 minecraft:purple_stained_glass
fill 12 280 484 12 280 485 minecraft:purple_stained_glass
fill 12 280 488 14 280 488 minecraft:purple_stained_glass
fill 12 280 489 12 280 504 minecraft:dark_oak_planks
fill 13 280 464 13 280 474 minecraft:dark_oak_planks
fill 13 280 475 17 280 475 minecraft:purple_stained_glass
fill 13 280 477 14 280 477 minecraft:purple_stained_glass
fill 13 280 487 14 280 487 minecraft:purple_stained_glass
fill 13 280 489 17 280 489 minecraft:purple_stained_glass
fill 13 280 490 13 280 504 minecraft:dark_oak_planks
fill 14 280 464 15 280 473 minecraft:dark_oak_planks
fill 14 280 474 24 280 474 minecraft:purple_stained_glass
fill 14 280 481 15 280 483 minecraft:purple_stained_glass
fill 14 280 490 24 280 490 minecraft:purple_stained_glass
fill 14 280 491 15 280 504 minecraft:dark_oak_planks
fill 15 280 478 15 280 480 minecraft:purple_stained_glass
fill 15 280 484 15 280 486 minecraft:purple_stained_glass
fill 16 280 464 41 280 472 minecraft:dark_oak_planks
fill 16 280 473 22 280 473 minecraft:purple_stained_glass
fill 16 280 478 16 280 479 minecraft:purple_stained_glass
fill 16 280 480 16 280 484 minecraft:ochre_froglight
fill 16 280 485 16 280 486 minecraft:purple_stained_glass
fill 16 280 491 22 280 491 minecraft:purple_stained_glass
fill 16 280 492 41 280 504 minecraft:dark_oak_planks
fill 17 280 478 23 280 478 minecraft:purple_stained_glass
fill 17 280 479 17 280 480 minecraft:ochre_froglight
fill 17 280 484 17 280 485 minecraft:ochre_froglight
fill 17 280 486 23 280 486 minecraft:purple_stained_glass
fill 18 280 477 20 280 477 minecraft:purple_stained_glass
fill 18 280 479 21 280 479 minecraft:ochre_froglight
fill 18 280 485 21 280 485 minecraft:ochre_froglight
fill 18 280 487 20 280 487 minecraft:purple_stained_glass
fill 21 280 475 25 280 475 minecraft:purple_stained_glass
fill 21 280 480 22 280 480 minecraft:ochre_froglight
fill 21 280 484 22 280 484 minecraft:ochre_froglight
fill 21 280 489 25 280 489 minecraft:purple_stained_glass
fill 22 280 479 23 280 479 minecraft:purple_stained_glass
fill 22 280 481 22 280 483 minecraft:ochre_froglight
fill 22 280 485 23 280 485 minecraft:purple_stained_glass
fill 23 280 473 41 280 473 minecraft:dark_oak_planks
fill 23 280 480 23 280 484 minecraft:purple_stained_glass
fill 23 280 491 41 280 491 minecraft:dark_oak_planks
fill 24 280 476 26 280 477 minecraft:purple_stained_glass
fill 24 280 481 24 280 483 minecraft:purple_stained_glass
fill 24 280 487 26 280 488 minecraft:purple_stained_glass
fill 25 280 474 41 280 474 minecraft:dark_oak_planks
fill 25 280 490 41 280 490 minecraft:dark_oak_planks
fill 26 280 475 41 280 475 minecraft:dark_oak_planks
fill 26 280 478 27 280 480 minecraft:purple_stained_glass
fill 26 280 484 27 280 486 minecraft:purple_stained_glass
fill 26 280 489 41 280 489 minecraft:dark_oak_planks
fill 27 280 476 41 280 476 minecraft:dark_oak_planks
setblock 27 280 477 minecraft:purple_stained_glass
fill 27 280 481 28 280 483 minecraft:purple_stained_glass
setblock 27 280 487 minecraft:purple_stained_glass
fill 27 280 488 41 280 488 minecraft:dark_oak_planks
fill 28 280 477 41 280 478 minecraft:dark_oak_planks
fill 28 280 479 28 280 480 minecraft:purple_stained_glass
fill 28 280 484 28 280 485 minecraft:purple_stained_glass
fill 28 280 486 41 280 487 minecraft:dark_oak_planks
fill 29 280 479 41 280 485 minecraft:dark_oak_planks
fill 16 281 481 16 281 483 minecraft:purple_stained_glass
setblock 17 281 480 minecraft:dark_oak_planks
setblock 17 281 484 minecraft:dark_oak_planks
fill 18 281 479 20 281 479 minecraft:purple_stained_glass
fill 18 281 485 20 281 485 minecraft:purple_stained_glass
setblock 21 281 480 minecraft:dark_oak_planks
setblock 21 281 484 minecraft:dark_oak_planks
fill 22 281 481 22 281 483 minecraft:purple_stained_glass
setblock 1 284 466 minecraft:bookshelf
fill 1 284 469 1 300 469 minecraft:bookshelf
setblock 1 284 473 minecraft:bookshelf
fill 1 284 476 1 300 476 minecraft:bookshelf
setblock 1 284 480 minecraft:bookshelf
fill 1 284 483 1 300 483 minecraft:bookshelf
setblock 1 284 487 minecraft:bookshelf
fill 1 284 490 1 300 490 minecraft:bookshelf
setblock 1 284 494 minecraft:bookshelf
fill 1 284 497 1 300 497 minecraft:bookshelf
setblock 1 284 501 minecraft:bookshelf
fill 1 284 504 1 300 504 minecraft:bookshelf
fill 3 284 464 3 300 464 minecraft:bookshelf
fill 5 284 504 24 284 504 minecraft:bookshelf
setblock 6 284 464 minecraft:bookshelf
fill 6 284 494 18 285 503 minecraft:bookshelf
fill 10 284 464 10 300 464 minecraft:bookshelf
setblock 13 284 464 minecraft:bookshelf
fill 17 284 464 17 300 464 minecraft:bookshelf
fill 19 284 496 24 285 503 minecraft:bookshelf
setblock 20 284 464 minecraft:bookshelf
fill 24 284 464 24 300 464 minecraft:bookshelf
setblock 26 284 504 minecraft:bookshelf
setblock 27 284 464 minecraft:bookshelf
fill 29 284 504 29 300 504 minecraft:bookshelf
fill 31 284 464 31 300 464 minecraft:bookshelf
fill 32 284 473 41 285 485 minecraft:bookshelf
setblock 33 284 504 minecraft:bookshelf
setblock 34 284 464 minecraft:bookshelf
fill 36 284 504 36 300 504 minecraft:bookshelf
fill 38 284 464 38 300 464 minecraft:bookshelf
setblock 40 284 504 minecraft:bookshelf
setblock 41 284 464 minecraft:bookshelf
fill 41 284 468 41 300 468 minecraft:bookshelf
setblock 41 284 471 minecraft:bookshelf
fill 41 284 489 41 300 489 minecraft:bookshelf
setblock 41 284 492 minecraft:bookshelf
fill 41 284 496 41 300 496 minecraft:bookshelf
setblock 41 284 499 minecraft:bookshelf
fill 41 284 503 41 300 503 minecraft:bookshelf
setblock 1 285 467 minecraft:bookshelf
setblock 1 285 474 minecraft:bookshelf
setblock 1 285 481 minecraft:bookshelf
setblock 1 285 488 minecraft:bookshelf
setblock 1 285 495 minecraft:bookshelf
setblock 1 285 502 minecraft:bookshelf
setblock 5 285 464 minecraft:bookshelf
fill 6 285 504 24 285 504 minecraft:bookshelf
setblock 12 285 464 minecraft:bookshelf
setblock 19 285 464 minecraft:bookshelf
setblock 26 285 464 minecraft:bookshelf
setblock 27 285 504 minecraft:bookshelf
setblock 33 285 464 minecraft:bookshelf
setblock 34 285 504 minecraft:bookshelf
fill 39 285 486 41 285 488 minecraft:bookshelf
setblock 40 285 464 minecraft:bookshelf
setblock 41 285 470 minecraft:bookshelf
fill 41 285 491 41 287 491 minecraft:bookshelf
setblock 41 285 498 minecraft:bookshelf
setblock 41 285 504 minecraft:bookshelf
setblock 1 286 468 minecraft:bookshelf
setblock 1 286 475 minecraft:bookshelf
setblock 1 286 482 minecraft:bookshelf
setblock 1 286 489 minecraft:bookshelf
setblock 1 286 496 minecraft:bookshelf
setblock 1 286 503 minecraft:bookshelf
setblock 3 286 466 minecraft:light[level=12]
setblock 3 286 474 minecraft:light[level=12]
setblock 3 286 482 minecraft:light[level=12]
setblock 3 286 490 minecraft:light[level=12]
setblock 3 286 498 minecraft:light[level=12]
setblock 4 286 464 minecraft:bookshelf
fill 6 286 494 6 294 494 minecraft:bookshelf
setblock 6 286 495 minecraft:ochre_froglight
fill 6 286 496 6 294 496 minecraft:bookshelf
setblock 6 286 497 minecraft:ochre_froglight
fill 6 286 498 6 294 498 minecraft:bookshelf
setblock 6 286 499 minecraft:ochre_froglight
fill 6 286 500 6 294 500 minecraft:bookshelf
setblock 6 286 501 minecraft:ochre_froglight
fill 6 286 502 6 294 502 minecraft:bookshelf
setblock 6 286 503 minecraft:ochre_froglight
fill 6 286 504 6 294 504 minecraft:bookshelf
setblock 7 286 494 minecraft:ochre_froglight
fill 7 286 495 7 294 495 minecraft:bookshelf
setblock 7 286 496 minecraft:ochre_froglight
fill 7 286 497 7 294 497 minecraft:bookshelf
setblock 7 286 498 minecraft:ochre_froglight
fill 7 286 499 7 294 499 minecraft:bookshelf
setblock 7 286 500 minecraft:ochre_froglight
fill 7 286 501 7 294 501 minecraft:bookshelf
setblock 7 286 502 minecraft:ochre_froglight
fill 7 286 503 7 294 503 minecraft:bookshelf
setblock 7 286 504 minecraft:ochre_froglight
fill 8 286 494 8 294 494 minecraft:bookshelf
setblock 8 286 495 minecraft:ochre_froglight
fill 8 286 496 8 294 496 minecraft:bookshelf
setblock 8 286 497 minecraft:ochre_froglight
fill 8 286 498 8 294 498 minecraft:bookshelf
setblock 8 286 499 minecraft:ochre_froglight
fill 8 286 500 8 294 500 minecraft:bookshelf
setblock 8 286 501 minecraft:ochre_froglight
fill 8 286 502 8 294 502 minecraft:bookshelf
setblock 8 286 503 minecraft:ochre_froglight
fill 8 286 504 8 300 504 minecraft:bookshelf
setblock 9 286 494 minecraft:ochre_froglight
fill 9 286 495 9 294 495 minecraft:bookshelf
setblock 9 286 496 minecraft:ochre_froglight
fill 9 286 497 9 294 497 minecraft:bookshelf
setblock 9 286 498 minecraft:ochre_froglight
fill 9 286 499 9 294 499 minecraft:bookshelf
setblock 9 286 500 minecraft:ochre_froglight
fill 9 286 501 9 294 501 minecraft:bookshelf
setblock 9 286 502 minecraft:ochre_froglight
fill 9 286 503 9 294 503 minecraft:bookshelf
setblock 9 286 504 minecraft:ochre_froglight
fill 10 286 494 10 294 494 minecraft:bookshelf
setblock 10 286 495 minecraft:ochre_froglight
fill 10 286 496 10 294 496 minecraft:bookshelf
setblock 10 286 497 minecraft:ochre_froglight
fill 10 286 498 10 294 498 minecraft:bookshelf
setblock 10 286 499 minecraft:ochre_froglight
fill 10 286 500 10 294 500 minecraft:bookshelf
setblock 10 286 501 minecraft:ochre_froglight
fill 10 286 502 10 294 502 minecraft:bookshelf
setblock 10 286 503 minecraft:ochre_froglight
fill 10 286 504 10 294 504 minecraft:bookshelf
setblock 11 286 464 minecraft:bookshelf
setblock 11 286 466 minecraft:light[level=12]
setblock 11 286 474 minecraft:light[level=12]
setblock 11 286 482 minecraft:light[level=12]
setblock 11 286 490 minecraft:light[level=12]
setblock 11 286 494 minecraft:ochre_froglight
fill 11 286 495 11 294 495 minecraft:bookshelf
setblock 11 286 496 minecraft:ochre_froglight
fill 11 286 497 11 294 497 minecraft:bookshelf
setblock 11 286 498 minecraft:ochre_froglight
fill 11 286 499 11 294 499 minecraft:bookshelf
setblock 11 286 500 minecraft:ochre_froglight
fill 11 286 501 11 294 501 minecraft:bookshelf
setblock 11 286 502 minecraft:ochre_froglight
fill 11 286 503 11 294 503 minecraft:bookshelf
setblock 11 286 504 minecraft:ochre_froglight
fill 12 286 494 12 294 494 minecraft:bookshelf
setblock 12 286 495 minecraft:ochre_froglight
fill 12 286 496 12 294 496 minecraft:bookshelf
setblock 12 286 497 minecraft:ochre_froglight
fill 12 286 498 12 294 498 minecraft:bookshelf
setblock 12 286 499 minecraft:ochre_froglight
fill 12 286 500 12 294 500 minecraft:bookshelf
setblock 12 286 501 minecraft:ochre_froglight
fill 12 286 502 12 294 502 minecraft:bookshelf
setblock 12 286 503 minecraft:ochre_froglight
fill 12 286 504 12 294 504 minecraft:bookshelf
setblock 13 286 494 minecraft:ochre_froglight
fill 13 286 495 13 294 495 minecraft:bookshelf
setblock 13 286 496 minecraft:ochre_froglight
fill 13 286 497 13 294 497 minecraft:bookshelf
setblock 13 286 498 minecraft:ochre_froglight
fill 13 286 499 13 294 499 minecraft:bookshelf
setblock 13 286 500 minecraft:ochre_froglight
fill 13 286 501 13 294 501 minecraft:bookshelf
setblock 13 286 502 minecraft:ochre_froglight
fill 13 286 503 13 294 503 minecraft:bookshelf
setblock 13 286 504 minecraft:ochre_froglight
fill 14 286 494 14 294 494 minecraft:bookshelf
setblock 14 286 495 minecraft:ochre_froglight
fill 14 286 496 14 300 496 minecraft:bookshelf
setblock 14 286 497 minecraft:ochre_froglight
fill 14 286 498 14 300 498 minecraft:bookshelf
setblock 14 286 499 minecraft:ochre_froglight
fill 14 286 500 14 300 500 minecraft:bookshelf
setblock 14 286 501 minecraft:ochre_froglight
fill 14 286 502 14 300 502 minecraft:bookshelf
setblock 14 286 503 minecraft:ochre_froglight
fill 14 286 504 14 300 504 minecraft:bookshelf
setblock 15 286 494 minecraft:ochre_froglight
fill 15 286 495 15 294 495 minecraft:bookshelf
setblock 15 286 496 minecraft:ochre_froglight
fill 15 286 497 15 300 497 minecraft:bookshelf
setblock 15 286 498 minecraft:ochre_froglight
fill 15 286 499 15 300 499 minecraft:bookshelf
setblock 15 286 500 minecraft:ochre_froglight
fill 15 286 501 15 300 501 minecraft:bookshelf
setblock 15 286 502 minecraft:ochre_froglight
fill 15 286 503 15 300 503 minecraft:bookshelf
setblock 15 286 504 minecraft:ochre_froglight
fill 16 286 494 16 294 494 minecraft:bookshelf
setblock 16 286 495 minecraft:ochre_froglight
fill 16 286 496 16 300 496 minecraft:bookshelf
setblock 16 286 497 minecraft:ochre_froglight
fill 16 286 498 16 300 498 minecraft:bookshelf
setblock 16 286 499 minecraft:ochre_froglight
fill 16 286 500 16 300 500 minecraft:bookshelf
setblock 16 286 501 minecraft:ochre_froglight
fill 16 286 502 16 300 502 minecraft:bookshelf
setblock 16 286 503 minecraft:ochre_froglight
fill 16 286 504 16 300 504 minecraft:bookshelf
setblock 17 286 494 minecraft:ochre_froglight
fill 17 286 495 17 294 495 minecraft:bookshelf
setblock 17 286 496 minecraft:ochre_froglight
fill 17 286 497 17 300 497 minecraft:bookshelf
setblock 17 286 498 minecraft:ochre_froglight
fill 17 286 499 17 300 499 minecraft:bookshelf
setblock 17 286 500 minecraft:ochre_froglight
fill 17 286 501 17 300 501 minecraft:bookshelf
setblock 17 286 502 minecraft:ochre_froglight
fill 17 286 503 17 300 503 minecraft:bookshelf
setblock 17 286 504 minecraft:ochre_froglight
setblock 18 286 464 minecraft:bookshelf
fill 18 286 494 18 294 494 minecraft:bookshelf
setblock 18 286 495 minecraft:ochre_froglight
fill 18 286 496 18 300 496 minecraft:bookshelf
setblock 18 286 497 minecraft:ochre_froglight
fill 18 286 498 18 300 498 minecraft:bookshelf
setblock 18 286 499 minecraft:ochre_froglight
fill 18 286 500 18 300 500 minecraft:bookshelf
setblock 18 286 501 minecraft:ochre_froglight
fill 18 286 502 18 300 502 minecraft:bookshelf
setblock 18 286 503 minecraft:ochre_froglight
fill 18 286 504 18 300 504 minecraft:bookshelf
setblock 19 286 466 minecraft:light[level=12]
setblock 19 286 474 minecraft:light[level=12]
setblock 19 286 490 minecraft:light[level=12]
setblock 19 286 496 minecraft:ochre_froglight
fill 19 286 497 19 300 497 minecraft:bookshelf
setblock 19 286 498 minecraft:ochre_froglight
fill 19 286 499 19 300 499 minecraft:bookshelf
setblock 19 286 500 minecraft:ochre_froglight
fill 19 286 501 19 300 501 minecraft:bookshelf
setblock 19 286 502 minecraft:ochre_froglight
fill 19 286 503 19 300 503 minecraft:bookshelf
setblock 19 286 504 minecraft:ochre_froglight
fill 20 286 496 20 300 496 minecraft:bookshelf
setblock 20 286 497 minecraft:ochre_froglight
fill 20 286 498 20 300 498 minecraft:bookshelf
setblock 20 286 499 minecraft:ochre_froglight
fill 20 286 500 20 300 500 minecraft:bookshelf
setblock 20 286 501 minecraft:ochre_froglight
fill 20 286 502 20 300 502 minecraft:bookshelf
setblock 20 286 503 minecraft:ochre_froglight
fill 20 286 504 20 300 504 minecraft:bookshelf
setblock 21 286 496 minecraft:ochre_froglight
fill 21 286 497 21 300 497 minecraft:bookshelf
setblock 21 286 498 minecraft:ochre_froglight
fill 21 286 499 21 300 499 minecraft:bookshelf
setblock 21 286 500 minecraft:ochre_froglight
fill 21 286 501 21 300 501 minecraft:bookshelf
setblock 21 286 502 minecraft:ochre_froglight
fill 21 286 503 21 300 503 minecraft:bookshelf
setblock 21 286 504 minecraft:ochre_froglight
fill 22 286 496 22 300 496 minecraft:bookshelf
setblock 22 286 497 minecraft:ochre_froglight
fill 22 286 498 22 300 498 minecraft:bookshelf
setblock 22 286 499 minecraft:ochre_froglight
fill 22 286 500 22 300 500 minecraft:bookshelf
setblock 22 286 501 minecraft:ochre_froglight
fill 22 286 502 22 300 502 minecraft:bookshelf
setblock 22 286 503 minecraft:ochre_froglight
fill 22 286 504 22 300 504 minecraft:bookshelf
setblock 23 286 496 minecraft:ochre_froglight
fill 23 286 497 23 300 497 minecraft:bookshelf
setblock 23 286 498 minecraft:ochre_froglight
fill 23 286 499 23 300 499 minecraft:bookshelf
setblock 23 286 500 minecraft:ochre_froglight
fill 23 286 501 23 300 501 minecraft:bookshelf
setblock 23 286 502 minecraft:ochre_froglight
fill 23 286 503 23 300 503 minecraft:bookshelf
setblock 23 286 504 minecraft:ochre_froglight
fill 24 286 496 24 300 496 minecraft:bookshelf
setblock 24 286 497 minecraft:ochre_froglight
fill 24 286 498 24 300 498 minecraft:bookshelf
setblock 24 286 499 minecraft:ochre_froglight
fill 24 286 500 24 300 500 minecraft:bookshelf
setblock 24 286 501 minecraft:ochre_froglight
fill 24 286 502 24 300 502 minecraft:bookshelf
setblock 24 286 503 minecraft:ochre_froglight
fill 24 286 504 24 300 504 minecraft:bookshelf
setblock 25 286 464 minecraft:bookshelf
setblock 27 286 466 minecraft:light[level=12]
setblock 27 286 474 minecraft:light[level=12]
setblock 27 286 482 minecraft:light[level=12]
setblock 27 286 490 minecraft:light[level=12]
setblock 27 286 498 minecraft:light[level=12]
setblock 28 286 504 minecraft:bookshelf
setblock 32 286 464 minecraft:bookshelf
setblock 32 286 473 minecraft:ochre_froglight
fill 32 286 474 32 297 474 minecraft:bookshelf
setblock 32 286 475 minecraft:ochre_froglight
fill 32 286 476 32 297 476 minecraft:bookshelf
setblock 32 286 477 minecraft:ochre_froglight
fill 32 286 478 32 297 478 minecraft:bookshelf
setblock 32 286 479 minecraft:ochre_froglight
fill 32 286 480 32 297 480 minecraft:bookshelf
setblock 32 286 481 minecraft:ochre_froglight
fill 32 286 482 32 297 482 minecraft:bookshelf
setblock 32 286 483 minecraft:ochre_froglight
fill 32 286 484 32 297 484 minecraft:bookshelf
setblock 32 286 485 minecraft:ochre_froglight
fill 33 286 473 33 297 473 minecraft:bookshelf
setblock 33 286 474 minecraft:ochre_froglight
fill 33 286 475 33 297 475 minecraft:bookshelf
setblock 33 286 476 minecraft:ochre_froglight
fill 33 286 477 33 297 477 minecraft:bookshelf
setblock 33 286 478 minecraft:ochre_froglight
fill 33 286 479 33 297 479 minecraft:bookshelf
setblock 33 286 480 minecraft:ochre_froglight
fill 33 286 481 33 297 481 minecraft:bookshelf
setblock 33 286 482 minecraft:ochre_froglight
fill 33 286 483 33 297 483 minecraft:bookshelf
setblock 33 286 484 minecraft:ochre_froglight
fill 33 286 485 33 297 485 minecraft:bookshelf
setblock 34 286 473 minecraft:ochre_froglight
fill 34 286 474 34 297 474 minecraft:bookshelf
setblock 34 286 475 minecraft:ochre_froglight
fill 34 286 476 34 297 476 minecraft:bookshelf
setblock 34 286 477 minecraft:ochre_froglight
fill 34 286 478 34 297 478 minecraft:bookshelf
setblock 34 286 479 minecraft:ochre_froglight
fill 34 286 480 34 297 480 minecraft:bookshelf
setblock 34 286 481 minecraft:ochre_froglight
fill 34 286 482 34 297 482 minecraft:bookshelf
setblock 34 286 483 minecraft:ochre_froglight
fill 34 286 484 34 297 484 minecraft:bookshelf
setblock 34 286 485 minecraft:ochre_froglight
setblock 35 286 466 minecraft:light[level=12]
fill 35 286 473 35 297 473 minecraft:bookshelf
setblock 35 286 474 minecraft:ochre_froglight
fill 35 286 475 35 297 475 minecraft:bookshelf
setblock 35 286 476 minecraft:ochre_froglight
fill 35 286 477 35 297 477 minecraft:bookshelf
setblock 35 286 478 minecraft:ochre_froglight
fill 35 286 479 35 297 479 minecraft:bookshelf
setblock 35 286 480 minecraft:ochre_froglight
fill 35 286 481 35 297 481 minecraft:bookshelf
setblock 35 286 482 minecraft:ochre_froglight
fill 35 286 483 35 297 483 minecraft:bookshelf
setblock 35 286 484 minecraft:ochre_froglight
fill 35 286 485 35 297 485 minecraft:bookshelf
setblock 35 286 490 minecraft:light[level=12]
setblock 35 286 498 minecraft:light[level=12]
setblock 35 286 504 minecraft:bookshelf
setblock 36 286 473 minecraft:ochre_froglight
fill 36 286 474 36 297 474 minecraft:bookshelf
setblock 36 286 475 minecraft:ochre_froglight
fill 36 286 476 36 297 476 minecraft:bookshelf
setblock 36 286 477 minecraft:ochre_froglight
fill 36 286 478 36 297 478 minecraft:bookshelf
setblock 36 286 479 minecraft:ochre_froglight
fill 36 286 480 36 297 480 minecraft:bookshelf
setblock 36 286 481 minecraft:ochre_froglight
fill 36 286 482 36 297 482 minecraft:bookshelf
setblock 36 286 483 minecraft:ochre_froglight
fill 36 286 484 36 297 484 minecraft:bookshelf
setblock 36 286 485 minecraft:ochre_froglight
fill 37 286 473 37 297 473 minecraft:bookshelf
setblock 37 286 474 minecraft:ochre_froglight
fill 37 286 475 37 297 475 minecraft:bookshelf
setblock 37 286 476 minecraft:ochre_froglight
fill 37 286 477 37 297 477 minecraft:bookshelf
setblock 37 286 478 minecraft:ochre_froglight
fill 37 286 479 37 297 479 minecraft:bookshelf
setblock 37 286 480 minecraft:ochre_froglight
fill 37 286 481 37 297 481 minecraft:bookshelf
setblock 37 286 482 minecraft:ochre_froglight
fill 37 286 483 37 297 483 minecraft:bookshelf
setblock 37 286 484 minecraft:ochre_froglight
fill 37 286 485 37 297 485 minecraft:bookshelf
setblock 38 286 473 minecraft:ochre_froglight
fill 38 286 474 38 297 474 minecraft:bookshelf
setblock 38 286 475 minecraft:ochre_froglight
fill 38 286 476 38 297 476 minecraft:bookshelf
setblock 38 286 477 minecraft:ochre_froglight
fill 38 286 478 38 297 478 minecraft:bookshelf
setblock 38 286 479 minecraft:ochre_froglight
fill 38 286 480 38 297 480 minecraft:bookshelf
setblock 38 286 481 minecraft:ochre_froglight
fill 38 286 482 38 297 482 minecraft:bookshelf
setblock 38 286 483 minecraft:ochre_froglight
fill 38 286 484 38 297 484 minecraft:bookshelf
setblock 38 286 485 minecraft:ochre_froglight
setblock 39 286 464 minecraft:bookshelf
fill 39 286 473 39 297 473 minecraft:bookshelf
setblock 39 286 474 minecraft:ochre_froglight
fill 39 286 475 39 297 475 minecraft:bookshelf
setblock 39 286 476 minecraft:ochre_froglight
fill 39 286 477 39 297 477 minecraft:bookshelf
setblock 39 286 478 minecraft:ochre_froglight
fill 39 286 479 39 297 479 minecraft:bookshelf
setblock 39 286 480 minecraft:ochre_froglight
fill 39 286 481 39 297 481 minecraft:bookshelf
setblock 39 286 482 minecraft:ochre_froglight
fill 39 286 483 39 297 483 minecraft:bookshelf
setblock 39 286 484 minecraft:ochre_froglight
fill 39 286 485 39 297 485 minecraft:bookshelf
fill 39 286 487 40 286 491 minecraft:bookshelf
setblock 40 286 473 minecraft:ochre_froglight
fill 40 286 474 40 297 474 minecraft:bookshelf
setblock 40 286 475 minecraft:ochre_froglight
fill 40 286 476 40 297 476 minecraft:bookshelf
setblock 40 286 477 minecraft:ochre_froglight
fill 40 286 478 40 297 478 minecraft:bookshelf
setblock 40 286 479 minecraft:ochre_froglight
fill 40 286 480 40 297 480 minecraft:bookshelf
setblock 40 286 481 minecraft:ochre_froglight
fill 40 286 482 40 297 482 minecraft:bookshelf
setblock 40 286 483 minecraft:ochre_froglight
fill 40 286 484 40 297 484 minecraft:bookshelf
setblock 40 286 485 minecraft:ochre_froglight
setblock 41 286 469 minecraft:bookshelf
fill 41 286 473 41 297 473 minecraft:bookshelf
setblock 41 286 474 minecraft:ochre_froglight
fill 41 286 475 41 300 475 minecraft:bookshelf
setblock 41 286 476 minecraft:ochre_froglight
fill 41 286 477 41 297 477 minecraft:bookshelf
setblock 41 286 478 minecraft:ochre_froglight
fill 41 286 479 41 297 479 minecraft:bookshelf
setblock 41 286 480 minecraft:ochre_froglight
fill 41 286 481 41 297 481 minecraft:bookshelf
setblock 41 286 482 minecraft:ochre_froglight
fill 41 286 483 41 297 483 minecraft:bookshelf
setblock 41 286 484 minecraft:ochre_froglight
fill 41 286 485 41 298 485 minecraft:bookshelf
fill 41 286 487 41 286 488 minecraft:bookshelf
setblock 41 286 490 minecraft:bookshelf
fill 41 286 492 41 287 492 minecraft:bookshelf
setblock 41 286 497 minecraft:bookshelf
fill 6 287 495 6 288 495 minecraft:bookshelf
fill 6 287 497 6 288 497 minecraft:bookshelf
fill 6 287 499 6 288 499 minecraft:bookshelf
fill 6 287 501 6 288 501 minecraft:bookshelf
fill 6 287 503 6 288 503 minecraft:bookshelf
fill 7 287 494 7 288 494 minecraft:bookshelf
fill 7 287 496 7 288 496 minecraft:bookshelf
fill 7 287 498 7 288 498 minecraft:bookshelf
fill 7 287 500 7 288 500 minecraft:bookshelf
fill 7 287 502 7 288 502 minecraft:bookshelf
fill 7 287 504 7 288 504 minecraft:bookshelf
fill 8 287 495 8 288 495 minecraft:bookshelf
fill 8 287 497 8 288 497 minecraft:bookshelf
fill 8 287 499 8 288 499 minecraft:bookshelf
fill 8 287 501 8 288 501 minecraft:bookshelf
fill 8 287 503 8 288 503 minecraft:bookshelf
fill 9 287 494 9 288 494 minecraft:bookshelf
fill 9 287 496 9 288 496 minecraft:bookshelf
fill 9 287 498 9 288 498 minecraft:bookshelf
fill 9 287 500 9 288 500 minecraft:bookshelf
fill 9 287 502 9 288 502 minecraft:bookshelf
fill 9 287 504 9 288 504 minecraft:bookshelf
fill 10 287 495 10 288 495 minecraft:bookshelf
fill 10 287 497 10 288 497 minecraft:bookshelf
fill 10 287 499 10 288 499 minecraft:bookshelf
fill 10 287 501 10 288 501 minecraft:bookshelf
fill 10 287 503 10 288 503 minecraft:bookshelf
fill 11 287 494 11 288 494 minecraft:bookshelf
fill 11 287 496 11 288 496 minecraft:bookshelf
fill 11 287 498 11 288 498 minecraft:bookshelf
fill 11 287 500 11 288 500 minecraft:bookshelf
fill 11 287 502 11 288 502 minecraft:bookshelf
fill 11 287 504 11 288 504 minecraft:bookshelf
fill 12 287 495 12 288 495 minecraft:bookshelf
fill 12 287 497 12 288 497 minecraft:bookshelf
fill 12 287 499 12 288 499 minecraft:bookshelf
fill 12 287 501 12 288 501 minecraft:bookshelf
fill 12 287 503 12 288 503 minecraft:bookshelf
fill 13 287 494 13 288 494 minecraft:bookshelf
fill 13 287 496 13 288 496 minecraft:bookshelf
fill 13 287 498 13 288 498 minecraft:bookshelf
fill 13 287 500 13 288 500 minecraft:bookshelf
fill 13 287 502 13 288 502 minecraft:bookshelf
fill 13 287 504 13 288 504 minecraft:bookshelf
fill 14 287 495 14 288 495 minecraft:bookshelf
fill 14 287 497 14 288 497 minecraft:bookshelf
fill 14 287 499 14 288 499 minecraft:bookshelf
fill 14 287 501 14 288 501 minecraft:bookshelf
fill 14 287 503 14 288 503 minecraft:bookshelf
fill 15 287 494 15 288 494 minecraft:bookshelf
fill 15 287 496 15 288 496 minecraft:bookshelf
fill 15 287 498 15 288 498 minecraft:bookshelf
fill 15 287 500 15 288 500 minecraft:bookshelf
fill 15 287 502 15 288 502 minecraft:bookshelf
fill 15 287 504 15 288 504 minecraft:bookshelf
fill 16 287 495 16 288 495 minecraft:bookshelf
fill 16 287 497 16 288 497 minecraft:bookshelf
fill 16 287 499 16 288 499 minecraft:bookshelf
fill 16 287 501 16 288 501 minecraft:bookshelf
fill 16 287 503 16 288 503 minecraft:bookshelf
fill 17 287 494 17 288 494 minecraft:bookshelf
fill 17 287 496 17 288 496 minecraft:bookshelf
fill 17 287 498 17 288 498 minecraft:bookshelf
fill 17 287 500 17 288 500 minecraft:bookshelf
fill 17 287 502 17 288 502 minecraft:bookshelf
fill 17 287 504 17 288 504 minecraft:bookshelf
fill 18 287 495 18 288 495 minecraft:bookshelf
fill 18 287 497 18 288 497 minecraft:bookshelf
fill 18 287 499 18 288 499 minecraft:bookshelf
fill 18 287 501 18 288 501 minecraft:bookshelf
fill 18 287 503 18 288 503 minecraft:bookshelf
fill 19 287 496 19 288 496 minecraft:bookshelf
fill 19 287 498 19 288 498 minecraft:bookshelf
fill 19 287 500 19 288 500 minecraft:bookshelf
fill 19 287 502 19 288 502 minecraft:bookshelf
fill 19 287 504 19 288 504 minecraft:bookshelf
fill 20 287 497 20 288 497 minecraft:bookshelf
fill 20 287 499 20 288 499 minecraft:bookshelf
fill 20 287 501 20 288 501 minecraft:bookshelf
fill 20 287 503 20 288 503 minecraft:bookshelf
fill 21 287 496 21 288 496 minecraft:bookshelf
fill 21 287 498 21 288 498 minecraft:bookshelf
fill 21 287 500 21 288 500 minecraft:bookshelf
fill 21 287 502 21 288 502 minecraft:bookshelf
fill 21 287 504 21 288 504 minecraft:bookshelf
fill 22 287 497 22 288 497 minecraft:bookshelf
fill 22 287 499 22 288 499 minecraft:bookshelf
fill 22 287 501 22 288 501 minecraft:bookshelf
fill 22 287 503 22 288 503 minecraft:bookshelf
fill 23 287 496 23 288 496 minecraft:bookshelf
fill 23 287 498 23 288 498 minecraft:bookshelf
fill 23 287 500 23 288 500 minecraft:bookshelf
fill 23 287 502 23 288 502 minecraft:bookshelf
fill 23 287 504 23 288 504 minecraft:bookshelf
fill 24 287 497 24 288 497 minecraft:bookshelf
fill 24 287 499 24 288 499 minecraft:bookshelf
fill 24 287 501 24 288 501 minecraft:bookshelf
fill 24 287 503 24 288 503 minecraft:bookshelf
fill 32 287 473 32 288 473 minecraft:bookshelf
fill 32 287 475 32 288 475 minecraft:bookshelf
fill 32 287 477 32 288 477 minecraft:bookshelf
fill 32 287 479 32 288 479 minecraft:bookshelf
fill 32 287 481 32 288 481 minecraft:bookshelf
fill 32 287 483 32 288 483 minecraft:bookshelf
fill 32 287 485 32 288 485 minecraft:bookshelf
fill 33 287 474 33 288 474 minecraft:bookshelf
fill 33 287 476 33 288 476 minecraft:bookshelf
fill 33 287 478 33 288 478 minecraft:bookshelf
fill 33 287 480 33 288 480 minecraft:bookshelf
fill 33 287 482 33 288 482 minecraft:bookshelf
fill 33 287 484 33 288 484 minecraft:bookshelf
fill 34 287 473 34 288 473 minecraft:bookshelf
fill 34 287 475 34 288 475 minecraft:bookshelf
fill 34 287 477 34 288 477 minecraft:bookshelf
fill 34 287 479 34 288 479 minecraft:bookshelf
fill 34 287 481 34 288 481 minecraft:bookshelf
fill 34 287 483 34 288 483 minecraft:bookshelf
fill 34 287 485 34 288 485 minecraft:bookshelf
fill 35 287 474 35 288 474 minecraft:bookshelf
fill 35 287 476 35 288 476 minecraft:bookshelf
fill 35 287 478 35 288 478 minecraft:bookshelf
fill 35 287 480 35 288 480 minecraft:bookshelf
fill 35 287 482 35 288 482 minecraft:bookshelf
fill 35 287 484 35 288 484 minecraft:bookshelf
fill 36 287 473 36 288 473 minecraft:bookshelf
fill 36 287 475 36 288 475 minecraft:bookshelf
fill 36 287 477 36 288 477 minecraft:bookshelf
fill 36 287 479 36 288 479 minecraft:bookshelf
fill 36 287 481 36 288 481 minecraft:bookshelf
fill 36 287 483 36 288 483 minecraft:bookshelf
fill 36 287 485 36 288 485 minecraft:bookshelf
fill 37 287 474 37 288 474 minecraft:bookshelf
fill 37 287 476 37 288 476 minecraft:bookshelf
fill 37 287 478 37 288 478 minecraft:bookshelf
fill 37 287 480 37 288 480 minecraft:bookshelf
fill 37 287 482 37 288 482 minecraft:bookshelf
fill 37 287 484 37 288 484 minecraft:bookshelf
fill 38 287 473 38 288 473 minecraft:bookshelf
fill 38 287 475 38 288 475 minecraft:bookshelf
fill 38 287 477 38 288 477 minecraft:bookshelf
fill 38 287 479 38 288 479 minecraft:bookshelf
fill 38 287 481 38 288 481 minecraft:bookshelf
fill 38 287 483 38 288 483 minecraft:bookshelf
fill 38 287 485 38 288 485 minecraft:bookshelf
fill 39 287 474 39 288 474 minecraft:bookshelf
fill 39 287 476 39 288 476 minecraft:bookshelf
fill 39 287 478 39 288 478 minecraft:bookshelf
fill 39 287 480 39 288 480 minecraft:bookshelf
fill 39 287 482 39 288 482 minecraft:bookshelf
fill 39 287 484 39 288 484 minecraft:bookshelf
fill 39 287 490 40 287 495 minecraft:bookshelf
fill 40 287 473 40 288 473 minecraft:bookshelf
fill 40 287 475 40 288 475 minecraft:bookshelf
fill 40 287 477 40 288 477 minecraft:bookshelf
fill 40 287 479 40 288 479 minecraft:bookshelf
fill 40 287 481 40 288 481 minecraft:bookshelf
fill 40 287 483 40 288 483 minecraft:bookshelf
fill 40 287 485 40 288 485 minecraft:bookshelf
fill 41 287 474 41 288 474 minecraft:bookshelf
fill 41 287 476 41 288 476 minecraft:bookshelf
fill 41 287 478 41 288 478 minecraft:bookshelf
fill 41 287 480 41 288 480 minecraft:bookshelf
fill 41 287 482 41 288 482 minecraft:bookshelf
fill 41 287 484 41 288 484 minecraft:bookshelf
fill 41 287 493 41 287 495 minecraft:bookshelf
setblock 1 288 470 minecraft:bookshelf
setblock 1 288 477 minecraft:bookshelf
setblock 1 288 484 minecraft:bookshelf
setblock 1 288 491 minecraft:bookshelf
setblock 1 288 498 minecraft:bookshelf
setblock 2 288 464 minecraft:bookshelf
setblock 2 288 504 minecraft:bookshelf
setblock 9 288 464 minecraft:bookshelf
setblock 16 288 464 minecraft:bookshelf
fill 22 288 492 23 289 493 minecraft:green_wool
setblock 23 288 464 minecraft:bookshelf
fill 24 288 492 24 289 492 minecraft:green_wool
setblock 30 288 464 minecraft:bookshelf
setblock 30 288 504 minecraft:bookshelf
setblock 37 288 464 minecraft:bookshelf
setblock 37 288 504 minecraft:bookshelf
fill 39 288 493 39 288 499 minecraft:bookshelf
fill 40 288 494 40 288 500 minecraft:bookshelf
setblock 41 288 467 minecraft:bookshelf
setblock 41 288 488 minecraft:bookshelf
fill 41 288 494 41 288 495 minecraft:bookshelf
fill 41 288 497 41 288 502 minecraft:bookshelf
fill 1 289 464 1 290 464 minecraft:bookshelf
fill 1 289 471 1 290 471 minecraft:bookshelf
fill 1 289 478 1 290 478 minecraft:bookshelf
fill 1 289 485 1 290 485 minecraft:bookshelf
fill 1 289 492 1 290 492 minecraft:bookshelf
fill 1 289 499 1 290 499 minecraft:bookshelf
fill 3 289 504 3 290 504 minecraft:bookshelf
setblock 6 289 495 minecraft:ochre_froglight
setblock 6 289 497 minecraft:ochre_froglight
setblock 6 289 499 minecraft:ochre_froglight
setblock 6 289 501 minecraft:ochre_froglight
setblock 6 289 503 minecraft:ochre_froglight
setblock 7 289 494 minecraft:ochre_froglight
setblock 7 289 496 minecraft:ochre_froglight
setblock 7 289 498 minecraft:ochre_froglight
setblock 7 289 500 minecraft:ochre_froglight
setblock 7 289 502 minecraft:ochre_froglight
setblock 7 289 504 minecraft:ochre_froglight
fill 8 289 464 8 290 464 minecraft:bookshelf
setblock 8 289 495 minecraft:ochre_froglight
setblock 8 289 497 minecraft:ochre_froglight
setblock 8 289 499 minecraft:ochre_froglight
setblock 8 289 501 minecraft:ochre_froglight
setblock 8 289 503 minecraft:ochre_froglight
setblock 9 289 494 minecraft:ochre_froglight
setblock 9 289 496 minecraft:ochre_froglight
setblock 9 289 498 minecraft:ochre_froglight
setblock 9 289 500 minecraft:ochre_froglight
setblock 9 289 502 minecraft:ochre_froglight
setblock 9 289 504 minecraft:ochre_froglight
setblock 10 289 495 minecraft:ochre_froglight
setblock 10 289 497 minecraft:ochre_froglight
setblock 10 289 499 minecraft:ochre_froglight
setblock 10 289 501 minecraft:ochre_froglight
setblock 10 289 503 minecraft:ochre_froglight
setblock 11 289 494 minecraft:ochre_froglight
setblock 11 289 496 minecraft:ochre_froglight
setblock 11 289 498 minecraft:ochre_froglight
setblock 11 289 500 minecraft:ochre_froglight
setblock 11 289 502 minecraft:ochre_froglight
setblock 11 289 504 minecraft:ochre_froglight
setblock 12 289 495 minecraft:ochre_froglight
setblock 12 289 497 minecraft:ochre_froglight
setblock 12 289 499 minecraft:ochre_froglight
setblock 12 289 501 minecraft:ochre_froglight
setblock 12 289 503 minecraft:ochre_froglight
setblock 13 289 494 minecraft:ochre_froglight
setblock 13 289 496 minecraft:ochre_froglight
setblock 13 289 498 minecraft:ochre_froglight
setblock 13 289 500 minecraft:ochre_froglight
setblock 13 289 502 minecraft:ochre_froglight
setblock 13 289 504 minecraft:ochre_froglight
setblock 14 289 495 minecraft:ochre_froglight
setblock 14 289 497 minecraft:ochre_froglight
setblock 14 289 499 minecraft:ochre_froglight
setblock 14 289 501 minecraft:ochre_froglight
setblock 14 289 503 minecraft:ochre_froglight
fill 15 289 464 15 290 464 minecraft:bookshelf
setblock 15 289 494 minecraft:ochre_froglight
setblock 15 289 496 minecraft:ochre_froglight
setblock 15 289 498 minecraft:ochre_froglight
setblock 15 289 500 minecraft:ochre_froglight
setblock 15 289 502 minecraft:ochre_froglight
setblock 15 289 504 minecraft:ochre_froglight
setblock 16 289 495 minecraft:ochre_froglight
setblock 16 289 497 minecraft:ochre_froglight
setblock 16 289 499 minecraft:ochre_froglight
setblock 16 289 501 minecraft:ochre_froglight
setblock 16 289 503 minecraft:ochre_froglight
setblock 17 289 494 minecraft:ochre_froglight
setblock 17 289 496 minecraft:ochre_froglight
setblock 17 289 498 minecraft:ochre_froglight
setblock 17 289 500 minecraft:ochre_froglight
setblock 17 289 502 minecraft:ochre_froglight
setblock 17 289 504 minecraft:ochre_froglight
setblock 18 289 495 minecraft:ochre_froglight
setblock 18 289 497 minecraft:ochre_froglight
setblock 18 289 499 minecraft:ochre_froglight
setblock 18 289 501 minecraft:ochre_froglight
setblock 18 289 503 minecraft:ochre_froglight
setblock 19 289 496 minecraft:ochre_froglight
setblock 19 289 498 minecraft:ochre_froglight
setblock 19 289 500 minecraft:ochre_froglight
setblock 19 289 502 minecraft:ochre_froglight
setblock 19 289 504 minecraft:ochre_froglight
setblock 20 289 497 minecraft:ochre_froglight
setblock 20 289 499 minecraft:ochre_froglight
setblock 20 289 501 minecraft:ochre_froglight
setblock 20 289 503 minecraft:ochre_froglight
setblock 21 289 496 minecraft:ochre_froglight
setblock 21 289 498 minecraft:ochre_froglight
setblock 21 289 500 minecraft:ochre_froglight
setblock 21 289 502 minecraft:ochre_froglight
setblock 21 289 504 minecraft:ochre_froglight
fill 22 289 464 22 290 464 minecraft:bookshelf
setblock 22 289 497 minecraft:ochre_froglight
setblock 22 289 499 minecraft:ochre_froglight
setblock 22 289 501 minecraft:ochre_froglight
setblock 22 289 503 minecraft:ochre_froglight
setblock 23 289 496 minecraft:ochre_froglight
setblock 23 289 498 minecraft:ochre_froglight
setblock 23 289 500 minecraft:ochre_froglight
setblock 23 289 502 minecraft:ochre_froglight
setblock 23 289 504 minecraft:ochre_froglight
setblock 24 289 497 minecraft:ochre_froglight
setblock 24 289 499 minecraft:ochre_froglight
setblock 24 289 501 minecraft:ochre_froglight
setblock 24 289 503 minecraft:ochre_froglight
fill 29 289 464 29 290 464 minecraft:bookshelf
fill 31 289 504 31 292 504 minecraft:bookshelf
setblock 32 289 473 minecraft:ochre_froglight
setblock 32 289 475 minecraft:ochre_froglight
setblock 32 289 477 minecraft:ochre_froglight
setblock 32 289 479 minecraft:ochre_froglight
setblock 32 289 481 minecraft:ochre_froglight
setblock 32 289 483 minecraft:ochre_froglight
setblock 32 289 485 minecraft:ochre_froglight
setblock 33 289 474 minecraft:ochre_froglight
setblock 33 289 476 minecraft:ochre_froglight
setblock 33 289 478 minecraft:ochre_froglight
setblock 33 289 480 minecraft:ochre_froglight
setblock 33 289 482 minecraft:ochre_froglight
setblock 33 289 484 minecraft:ochre_froglight
setblock 34 289 473 minecraft:ochre_froglight
setblock 34 289 475 minecraft:ochre_froglight
setblock 34 289 477 minecraft:ochre_froglight
setblock 34 289 479 minecraft:ochre_froglight
setblock 34 289 481 minecraft:ochre_froglight
setblock 34 289 483 minecraft:ochre_froglight
setblock 34 289 485 minecraft:ochre_froglight
setblock 35 289 474 minecraft:ochre_froglight
setblock 35 289 476 minecraft:ochre_froglight
setblock 35 289 478 minecraft:ochre_froglight
setblock 35 289 480 minecraft:ochre_froglight
setblock 35 289 482 minecraft:ochre_froglight
setblock 35 289 484 minecraft:ochre_froglight
fill 36 289 464 36 290 464 minecraft:bookshelf
setblock 36 289 473 minecraft:ochre_froglight
setblock 36 289 475 minecraft:ochre_froglight
setblock 36 289 477 minecraft:ochre_froglight
setblock 36 289 479 minecraft:ochre_froglight
setblock 36 289 481 minecraft:ochre_froglight
setblock 36 289 483 minecraft:ochre_froglight
setblock 36 289 485 minecraft:ochre_froglight
setblock 37 289 474 minecraft:ochre_froglight
setblock 37 289 476 minecraft:ochre_froglight
setblock 37 289 478 minecraft:ochre_froglight
setblock 37 289 480 minecraft:ochre_froglight
setblock 37 289 482 minecraft:ochre_froglight
setblock 37 289 484 minecraft:ochre_froglight
fill 37 289 502 41 289 502 minecraft:bookshelf
setblock 38 289 473 minecraft:ochre_froglight
setblock 38 289 475 minecraft:ochre_froglight
setblock 38 289 477 minecraft:ochre_froglight
setblock 38 289 479 minecraft:ochre_froglight
setblock 38 289 481 minecraft:ochre_froglight
setblock 38 289 483 minecraft:ochre_froglight
setblock 38 289 485 minecraft:ochre_froglight
fill 38 289 503 40 290 504 minecraft:bookshelf
setblock 39 289 474 minecraft:ochre_froglight
setblock 39 289 476 minecraft:ochre_froglight
setblock 39 289 478 minecraft:ochre_froglight
setblock 39 289 480 minecraft:ochre_froglight
setblock 39 289 482 minecraft:ochre_froglight
setblock 39 289 484 minecraft:ochre_froglight
fill 39 289 497 39 289 501 minecraft:bookshelf
setblock 40 289 473 minecraft:ochre_froglight
setblock 40 289 475 minecraft:ochre_froglight
setblock 40 289 477 minecraft:ochre_froglight
setblock 40 289 479 minecraft:ochre_froglight
setblock 40 289 481 minecraft:ochre_froglight
setblock 40 289 483 minecraft:ochre_froglight
setblock 40 289 485 minecraft:ochre_froglight
fill 40 289 498 40 289 501 minecraft:bookshelf
fill 41 289 466 41 290 466 minecraft:bookshelf
setblock 41 289 474 minecraft:ochre_froglight
setblock 41 289 476 minecraft:ochre_froglight
setblock 41 289 478 minecraft:ochre_froglight
setblock 41 289 480 minecraft:ochre_froglight
setblock 41 289 482 minecraft:ochre_froglight
setblock 41 289 484 minecraft:ochre_froglight
fill 41 289 487 41 290 487 minecraft:bookshelf
fill 41 289 494 41 290 494 minecraft:bookshelf
fill 41 289 499 41 290 501 minecraft:bookshelf
fill 41 289 504 41 290 504 minecraft:bookshelf
fill 1 290 465 1 290 468 minecraft:bookshelf
setblock 1 290 470 minecraft:bookshelf
fill 1 290 472 1 290 475 minecraft:bookshelf
setblock 1 290 477 minecraft:bookshelf
fill 1 290 479 1 290 482 minecraft:bookshelf
setblock 1 290 484 minecraft:bookshelf
fill 1 290 486 1 290 489 minecraft:bookshelf
setblock 1 290 491 minecraft:bookshelf
fill 1 290 493 1 290 496 minecraft:bookshelf
setblock 1 290 498 minecraft:bookshelf
fill 1 290 500 1 290 503 minecraft:bookshelf
setblock 2 290 464 minecraft:bookshelf
setblock 2 290 504 minecraft:bookshelf
fill 4 290 464 7 290 464 minecraft:bookshelf
fill 4 290 504 5 290 504 minecraft:bookshelf
fill 6 290 495 6 291 495 minecraft:bookshelf
fill 6 290 497 6 291 497 minecraft:bookshelf
fill 6 290 499 6 291 499 minecraft:bookshelf
fill 6 290 501 6 291 501 minecraft:bookshelf
fill 6 290 503 6 291 503 minecraft:bookshelf
fill 7 290 494 7 291 494 minecraft:bookshelf
fill 7 290 496 7 291 496 minecraft:bookshelf
fill 7 290 498 7 291 498 minecraft:bookshelf
fill 7 290 500 7 291 500 minecraft:bookshelf
fill 7 290 502 7 291 502 minecraft:bookshelf
fill 7 290 504 7 291 504 minecraft:bookshelf
fill 8 290 495 8 291 495 minecraft:bookshelf
fill 8 290 497 8 291 497 minecraft:bookshelf
fill 8 290 499 8 291 499 minecraft:bookshelf
fill 8 290 501 8 291 501 minecraft:bookshelf
fill 8 290 503 8 291 503 minecraft:bookshelf
setblock 9 290 464 minecraft:bookshelf
fill 9 290 494 9 291 494 minecraft:bookshelf
fill 9 290 496 9 291 496 minecraft:bookshelf
fill 9 290 498 9 291 498 minecraft:bookshelf
fill 9 290 500 9 291 500 minecraft:bookshelf
fill 9 290 502 9 291 502 minecraft:bookshelf
fill 9 290 504 9 291 504 minecraft:bookshelf
fill 10 290 495 10 291 495 minecraft:bookshelf
fill 10 290 497 10 291 497 minecraft:bookshelf
fill 10 290 499 10 291 499 minecraft:bookshelf
fill 10 290 501 10 291 501 minecraft:bookshelf
fill 10 290 503 10 291 503 minecraft:bookshelf
fill 11 290 464 14 290 464 minecraft:bookshelf
fill 11 290 494 11 291 494 minecraft:bookshelf
fill 11 290 496 11 291 496 minecraft:bookshelf
fill 11 290 498 11 291 498 minecraft:bookshelf
fill 11 290 500 11 291 500 minecraft:bookshelf
fill 11 290 502 11 291 502 minecraft:bookshelf
fill 11 290 504 11 291 504 minecraft:bookshelf
fill 12 290 495 12 291 495 minecraft:bookshelf
fill 12 290 497 12 291 497 minecraft:bookshelf
fill 12 290 499 12 291 499 minecraft:bookshelf
fill 12 290 501 12 291 501 minecraft:bookshelf
fill 12 290 503 12 291 503 minecraft:bookshelf
fill 13 290 494 13 291 494 minecraft:bookshelf
fill 13 290 496 13 291 496 minecraft:bookshelf
fill 13 290 498 13 291 498 minecraft:bookshelf
fill 13 290 500 13 291 500 minecraft:bookshelf
fill 13 290 502 13 291 502 minecraft:bookshelf
fill 13 290 504 13 291 504 minecraft:bookshelf
fill 14 290 495 14 291 495 minecraft:bookshelf
fill 14 290 497 14 291 497 minecraft:bookshelf
fill 14 290 499 14 291 499 minecraft:bookshelf
fill 14 290 501 14 291 501 minecraft:bookshelf
fill 14 290 503 14 291 503 minecraft:bookshelf
fill 15 290 494 15 291 494 minecraft:bookshelf
fill 15 290 496 15 291 496 minecraft:bookshelf
fill 15 290 498 15 291 498 minecraft:bookshelf
fill 15 290 500 15 291 500 minecraft:bookshelf
fill 15 290 502 15 291 502 minecraft:bookshelf
fill 15 290 504 15 291 504 minecraft:bookshelf
setblock 16 290 464 minecraft:bookshelf
fill 16 290 495 16 291 495 minecraft:bookshelf
fill 16 290 497 16 291 497 minecraft:bookshelf
fill 16 290 499 16 291 499 minecraft:bookshelf
fill 16 290 501 16 291 501 minecraft:bookshelf
fill 16 290 503 16 291 503 minecraft:bookshelf
fill 17 290 494 17 291 494 minecraft:bookshelf
fill 17 290 496 17 291 496 minecraft:bookshelf
fill 17 290 498 17 291 498 minecraft:bookshelf
fill 17 290 500 17 291 500 minecraft:bookshelf
fill 17 290 502 17 291 502 minecraft:bookshelf
fill 17 290 504 17 291 504 minecraft:bookshelf
fill 18 290 464 21 290 464 minecraft:bookshelf
fill 18 290 495 18 291 495 minecraft:bookshelf
fill 18 290 497 18 291 497 minecraft:bookshelf
fill 18 290 499 18 291 499 minecraft:bookshelf
fill 18 290 501 18 291 501 minecraft:bookshelf
fill 18 290 503 18 291 503 minecraft:bookshelf
fill 19 290 496 19 291 496 minecraft:bookshelf
fill 19 290 498 19 291 498 minecraft:bookshelf
fill 19 290 500 19 291 500 minecraft:bookshelf
fill 19 290 502 19 291 502 minecraft:bookshelf
fill 19 290 504 19 291 504 minecraft:bookshelf
fill 20 290 497 20 291 497 minecraft:bookshelf
fill 20 290 499 20 291 499 minecraft:bookshelf
fill 20 290 501 20 291 501 minecraft:bookshelf
fill 20 290 503 20 291 503 minecraft:bookshelf
fill 21 290 496 21 291 496 minecraft:bookshelf
fill 21 290 498 21 291 498 minecraft:bookshelf
fill 21 290 500 21 291 500 minecraft:bookshelf
fill 21 290 502 21 291 502 minecraft:bookshelf
fill 21 290 504 21 291 504 minecraft:bookshelf
fill 22 290 497 22 291 497 minecraft:bookshelf
fill 22 290 499 22 291 499 minecraft:bookshelf
fill 22 290 501 22 291 501 minecraft:bookshelf
fill 22 290 503 22 291 503 minecraft:bookshelf
setblock 23 290 464 minecraft:bookshelf
fill 23 290 496 23 291 496 minecraft:bookshelf
fill 23 290 498 23 291 498 minecraft:bookshelf
fill 23 290 500 23 291 500 minecraft:bookshelf
fill 23 290 502 23 291 502 minecraft:bookshelf
fill 23 290 504 23 291 504 minecraft:bookshelf
fill 24 290 497 24 291 497 minecraft:bookshelf
fill 24 290 499 24 291 499 minecraft:bookshelf
fill 24 290 501 24 291 501 minecraft:bookshelf
fill 24 290 503 24 291 503 minecraft:bookshelf
fill 25 290 464 28 290 464 minecraft:bookshelf
fill 25 290 504 28 290 504 minecraft:bookshelf
setblock 30 290 464 minecraft:bookshelf
fill 30 290 504 30 292 504 minecraft:bookshelf
fill 32 290 464 35 290 464 minecraft:bookshelf
fill 32 290 473 32 291 473 minecraft:bookshelf
fill 32 290 475 32 291 475 minecraft:bookshelf
fill 32 290 477 32 291 477 minecraft:bookshelf
fill 32 290 479 32 291 479 minecraft:bookshelf
fill 32 290 481 32 291 481 minecraft:bookshelf
fill 32 290 483 32 291 483 minecraft:bookshelf
fill 32 290 485 32 291 485 minecraft:bookshelf
fill 32 290 504 35 291 504 minecraft:bookshelf
fill 33 290 474 33 291 474 minecraft:bookshelf
fill 33 290 476 33 291 476 minecraft:bookshelf
fill 33 290 478 33 291 478 minecraft:bookshelf
fill 33 290 480 33 291 480 minecraft:bookshelf
fill 33 290 482 33 291 482 minecraft:bookshelf
fill 33 290 484 33 291 484 minecraft:bookshelf
fill 33 290 502 37 290 503 minecraft:bookshelf
fill 34 290 473 34 291 473 minecraft:bookshelf
fill 34 290 475 34 291 475 minecraft:bookshelf
fill 34 290 477 34 291 477 minecraft:bookshelf
fill 34 290 479 34 291 479 minecraft:bookshelf
fill 34 290 481 34 291 481 minecraft:bookshelf
fill 34 290 483 34 291 483 minecraft:bookshelf
fill 34 290 485 34 291 485 minecraft:bookshelf
fill 35 290 474 35 291 474 minecraft:bookshelf
fill 35 290 476 35 291 476 minecraft:bookshelf
fill 35 290 478 35 291 478 minecraft:bookshelf
fill 35 290 480 35 291 480 minecraft:bookshelf
fill 35 290 482 35 291 482 minecraft:bookshelf
fill 35 290 484 35 291 484 minecraft:bookshelf
fill 36 290 473 36 291 473 minecraft:bookshelf
fill 36 290 475 36 291 475 minecraft:bookshelf
fill 36 290 477 36 291 477 minecraft:bookshelf
fill 36 290 479 36 291 479 minecraft:bookshelf
fill 36 290 481 36 291 481 minecraft:bookshelf
fill 36 290 483 36 291 483 minecraft:bookshelf
fill 36 290 485 36 291 485 minecraft:bookshelf
setblock 37 290 464 minecraft:bookshelf
fill 37 290 474 37 291 474 minecraft:bookshelf
fill 37 290 476 37 291 476 minecraft:bookshelf
fill 37 290 478 37 291 478 minecraft:bookshelf
fill 37 290 480 37 291 480 minecraft:bookshelf
fill 37 290 482 37 291 482 minecraft:bookshelf
fill 37 290 484 37 291 484 minecraft:bookshelf
setblock 37 290 504 minecraft:bookshelf
fill 38 290 473 38 291 473 minecraft:bookshelf
fill 38 290 475 38 291 475 minecraft:bookshelf
fill 38 290 477 38 291 477 minecraft:bookshelf
fill 38 290 479 38 291 479 minecraft:bookshelf
fill 38 290 481 38 291 481 minecraft:bookshelf
fill 38 290 483 38 291 483 minecraft:bookshelf
fill 38 290 485 38 291 485 minecraft:bookshelf
fill 38 290 502 39 290 502 minecraft:bookshelf
fill 39 290 464 41 290 464 minecraft:bookshelf
fill 39 290 474 39 291 474 minecraft:bookshelf
fill 39 290 476 39 291 476 minecraft:bookshelf
fill 39 290 478 39 291 478 minecraft:bookshelf
fill 39 290 480 39 291 480 minecraft:bookshelf
fill 39 290 482 39 291 482 minecraft:bookshelf
fill 39 290 484 39 291 484 minecraft:bookshelf
fill 40 290 473 40 291 473 minecraft:bookshelf
fill 40 290 475 40 291 475 minecraft:bookshelf
fill 40 290 477 40 291 477 minecraft:bookshelf
fill 40 290 479 40 291 479 minecraft:bookshelf
fill 40 290 481 40 291 481 minecraft:bookshelf
fill 40 290 483 40 291 483 minecraft:bookshelf
fill 40 290 485 40 291 485 minecraft:bookshelf
setblock 41 290 465 minecraft:bookshelf
setblock 41 290 467 minecraft:bookshelf
fill 41 290 469 41 290 472 minecraft:bookshelf
fill 41 290 474 41 291 474 minecraft:bookshelf
fill 41 290 476 41 291 476 minecraft:bookshelf
fill 41 290 478 41 291 478 minecraft:bookshelf
fill 41 290 480 41 291 480 minecraft:bookshelf
fill 41 290 482 41 291 482 minecraft:bookshelf
fill 41 290 484 41 291 484 minecraft:bookshelf
setblock 41 290 486 minecraft:bookshelf
setblock 41 290 488 minecraft:bookshelf
fill 41 290 490 41 290 493 minecraft:bookshelf
setblock 41 290 495 minecraft:bookshelf
fill 41 290 497 41 290 498 minecraft:bookshelf
setblock 41 290 502 minecraft:bookshelf
setblock 1 291 466 minecraft:bookshelf
setblock 1 291 473 minecraft:bookshelf
setblock 1 291 480 minecraft:bookshelf
setblock 1 291 487 minecraft:bookshelf
setblock 1 291 494 minecraft:bookshelf
setblock 1 291 501 minecraft:bookshelf
setblock 5 291 504 minecraft:bookshelf
setblock 6 291 464 minecraft:bookshelf
setblock 13 291 464 minecraft:bookshelf
setblock 20 291 464 minecraft:bookshelf
fill 26 291 504 26 293 504 minecraft:bookshelf
setblock 27 291 464 minecraft:bookshelf
fill 29 291 502 34 291 503 minecraft:bookshelf
setblock 34 291 464 minecraft:bookshelf
setblock 35 291 503 minecraft:bookshelf
setblock 40 291 504 minecraft:bookshelf
setblock 41 291 464 minecraft:bookshelf
setblock 41 291 471 minecraft:bookshelf
setblock 41 291 492 minecraft:bookshelf
setblock 41 291 499 minecraft:bookshelf
setblock 1 292 467 minecraft:bookshelf
setblock 1 292 474 minecraft:bookshelf
setblock 1 292 481 minecraft:bookshelf
setblock 1 292 488 minecraft:bookshelf
setblock 1 292 495 minecraft:bookshelf
setblock 1 292 502 minecraft:bookshelf
setblock 5 292 464 minecraft:bookshelf
setblock 6 292 495 minecraft:ochre_froglight
setblock 6 292 497 minecraft:ochre_froglight
setblock 6 292 499 minecraft:ochre_froglight
setblock 6 292 501 minecraft:ochre_froglight
setblock 6 292 503 minecraft:ochre_froglight
setblock 7 292 494 minecraft:ochre_froglight
setblock 7 292 496 minecraft:ochre_froglight
setblock 7 292 498 minecraft:ochre_froglight
setblock 7 292 500 minecraft:ochre_froglight
setblock 7 292 502 minecraft:ochre_froglight
setblock 7 292 504 minecraft:ochre_froglight
setblock 8 292 495 minecraft:ochre_froglight
setblock 8 292 497 minecraft:ochre_froglight
setblock 8 292 499 minecraft:ochre_froglight
setblock 8 292 501 minecraft:ochre_froglight
setblock 8 292 503 minecraft:ochre_froglight
setblock 9 292 494 minecraft:ochre_froglight
setblock 9 292 496 minecraft:ochre_froglight
setblock 9 292 498 minecraft:ochre_froglight
setblock 9 292 500 minecraft:ochre_froglight
setblock 9 292 502 minecraft:ochre_froglight
setblock 9 292 504 minecraft:ochre_froglight
setblock 10 292 495 minecraft:ochre_froglight
setblock 10 292 497 minecraft:ochre_froglight
setblock 10 292 499 minecraft:ochre_froglight
setblock 10 292 501 minecraft:ochre_froglight
setblock 10 292 503 minecraft:ochre_froglight
setblock 11 292 494 minecraft:ochre_froglight
setblock 11 292 496 minecraft:ochre_froglight
setblock 11 292 498 minecraft:ochre_froglight
setblock 11 292 500 minecraft:ochre_froglight
setblock 11 292 502 minecraft:ochre_froglight
setblock 11 292 504 minecraft:ochre_froglight
setblock 12 292 464 minecraft:bookshelf
setblock 12 292 495 minecraft:ochre_froglight
setblock 12 292 497 minecraft:ochre_froglight
setblock 12 292 499 minecraft:ochre_froglight
setblock 12 292 501 minecraft:ochre_froglight
setblock 12 292 503 minecraft:ochre_froglight
setblock 13 292 494 minecraft:ochre_froglight
setblock 13 292 496 minecraft:ochre_froglight
setblock 13 292 498 minecraft:ochre_froglight
setblock 13 292 500 minecraft:ochre_froglight
setblock 13 292 502 minecraft:ochre_froglight
setblock 13 292 504 minecraft:ochre_froglight
setblock 14 292 495 minecraft:ochre_froglight
setblock 14 292 497 minecraft:ochre_froglight
setblock 14 292 499 minecraft:ochre_froglight
setblock 14 292 501 minecraft:ochre_froglight
setblock 14 292 503 minecraft:ochre_froglight
setblock 15 292 494 minecraft:ochre_froglight
setblock 15 292 496 minecraft:ochre_froglight
setblock 15 292 498 minecraft:ochre_froglight
setblock 15 292 500 minecraft:ochre_froglight
setblock 15 292 502 minecraft:ochre_froglight
setblock 15 292 504 minecraft:ochre_froglight
setblock 16 292 495 minecraft:ochre_froglight
setblock 16 292 497 minecraft:ochre_froglight
setblock 16 292 499 minecraft:ochre_froglight
setblock 16 292 501 minecraft:ochre_froglight
setblock 16 292 503 minecraft:ochre_froglight
setblock 17 292 494 minecraft:ochre_froglight
setblock 17 292 496 minecraft:ochre_froglight
setblock 17 292 498 minecraft:ochre_froglight
setblock 17 292 500 minecraft:ochre_froglight
setblock 17 292 502 minecraft:ochre_froglight
setblock 17 292 504 minecraft:ochre_froglight
setblock 18 292 495 minecraft:ochre_froglight
setblock 18 292 497 minecraft:ochre_froglight
setblock 18 292 499 minecraft:ochre_froglight
setblock 18 292 501 minecraft:ochre_froglight
setblock 18 292 503 minecraft:ochre_froglight
setblock 19 292 464 minecraft:bookshelf
setblock 19 292 496 minecraft:ochre_froglight
setblock 19 292 498 minecraft:ochre_froglight
setblock 19 292 500 minecraft:ochre_froglight
setblock 19 292 502 minecraft:ochre_froglight
setblock 19 292 504 minecraft:ochre_froglight
setblock 20 292 497 minecraft:ochre_froglight
setblock 20 292 499 minecraft:ochre_froglight
setblock 20 292 501 minecraft:ochre_froglight
setblock 20 292 503 minecraft:ochre_froglight
setblock 21 292 496 minecraft:ochre_froglight
setblock 21 292 498 minecraft:ochre_froglight
setblock 21 292 500 minecraft:ochre_froglight
setblock 21 292 502 minecraft:ochre_froglight
setblock 21 292 504 minecraft:ochre_froglight
setblock 22 292 497 minecraft:ochre_froglight
setblock 22 292 499 minecraft:ochre_froglight
setblock 22 292 501 minecraft:ochre_froglight
setblock 22 292 503 minecraft:ochre_froglight
setblock 23 292 496 minecraft:ochre_froglight
setblock 23 292 498 minecraft:ochre_froglight
setblock 23 292 500 minecraft:ochre_froglight
setblock 23 292 502 minecraft:ochre_froglight
setblock 23 292 504 minecraft:ochre_froglight
setblock 24 292 497 minecraft:ochre_froglight
setblock 24 292 499 minecraft:ochre_froglight
setblock 24 292 501 minecraft:ochre_froglight
setblock 24 292 503 minecraft:ochre_froglight
setblock 26 292 464 minecraft:bookshelf
fill 26 292 502 30 292 503 minecraft:bookshelf
fill 27 292 504 28 293 504 minecraft:bookshelf
setblock 31 292 503 minecraft:bookshelf
setblock 32 292 473 minecraft:ochre_froglight
setblock 32 292 475 minecraft:ochre_froglight
setblock 32 292 477 minecraft:ochre_froglight
setblock 32 292 479 minecraft:ochre_froglight
setblock 32 292 481 minecraft:ochre_froglight
setblock 32 292 483 minecraft:ochre_froglight
setblock 32 292 485 minecraft:ochre_froglight
setblock 33 292 464 minecraft:bookshelf
setblock 33 292 474 minecraft:ochre_froglight
setblock 33 292 476 minecraft:ochre_froglight
setblock 33 292 478 minecraft:ochre_froglight
setblock 33 292 480 minecraft:ochre_froglight
schedule function dropper:buildpart/108_5 1t
