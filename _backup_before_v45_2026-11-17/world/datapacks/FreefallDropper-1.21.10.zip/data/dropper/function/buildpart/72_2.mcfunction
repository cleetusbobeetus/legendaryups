setblock 18 71 362 minecraft:yellow_terracotta
fill 18 71 363 18 74 363 minecraft:honeycomb_block
fill 19 71 362 19 74 362 minecraft:honeycomb_block
setblock 22 71 363 minecraft:yellow_terracotta
setblock 29 71 323 minecraft:honey_block
fill 32 71 341 32 79 341 minecraft:brown_terracotta
fill 33 71 344 34 75 344 minecraft:brown_terracotta
fill 33 71 346 34 75 346 minecraft:brown_terracotta
fill 34 71 329 34 72 330 minecraft:yellow_concrete
fill 34 71 342 34 71 343 minecraft:yellow_terracotta
fill 34 71 345 34 75 345 minecraft:brown_terracotta
fill 34 71 347 34 75 347 minecraft:brown_terracotta
fill 34 71 363 34 73 363 minecraft:honeycomb_block
fill 35 71 336 35 71 338 minecraft:honey_block
fill 35 71 339 35 71 341 minecraft:yellow_terracotta
fill 35 71 344 35 71 346 minecraft:yellow_terracotta
fill 35 71 347 35 71 349 minecraft:honey_block
fill 36 71 344 36 75 348 minecraft:brown_terracotta
fill 36 71 362 36 72 362 minecraft:honeycomb_block
setblock 37 71 323 minecraft:yellow_terracotta
fill 37 71 324 37 74 324 minecraft:honeycomb_block
fill 37 71 342 37 75 342 minecraft:brown_terracotta
setblock 37 71 363 minecraft:yellow_terracotta
fill 38 71 323 38 74 323 minecraft:honeycomb_block
fill 38 71 343 38 75 343 minecraft:brown_terracotta
fill 38 71 347 38 75 347 minecraft:brown_terracotta
setblock 38 71 362 minecraft:yellow_terracotta
fill 38 71 363 38 74 363 minecraft:honeycomb_block
setblock 39 71 332 minecraft:honeycomb_block
setblock 39 71 336 minecraft:yellow_terracotta
fill 39 71 337 39 72 337 minecraft:honeycomb_block
fill 39 71 345 39 75 345 minecraft:brown_terracotta
setblock 39 71 361 minecraft:yellow_terracotta
fill 39 71 362 39 74 362 minecraft:honeycomb_block
setblock 40 71 325 minecraft:yellow_terracotta
fill 40 71 326 40 72 326 minecraft:honeycomb_block
setblock 40 71 330 minecraft:yellow_terracotta
fill 40 71 331 40 72 331 minecraft:honeycomb_block
setblock 40 71 335 minecraft:yellow_terracotta
fill 40 71 336 40 74 336 minecraft:honeycomb_block
setblock 40 71 340 minecraft:yellow_terracotta
fill 40 71 341 40 72 341 minecraft:honeycomb_block
setblock 40 71 355 minecraft:yellow_terracotta
fill 40 71 356 40 72 356 minecraft:honeycomb_block
setblock 40 71 360 minecraft:yellow_terracotta
fill 40 71 361 40 74 361 minecraft:honeycomb_block
setblock 41 71 324 minecraft:yellow_terracotta
fill 41 71 325 41 74 325 minecraft:honeycomb_block
setblock 41 71 329 minecraft:yellow_terracotta
fill 41 71 330 41 74 330 minecraft:honeycomb_block
setblock 41 71 334 minecraft:yellow_terracotta
fill 41 71 335 41 74 335 minecraft:honeycomb_block
setblock 41 71 339 minecraft:yellow_terracotta
fill 41 71 340 41 74 340 minecraft:honeycomb_block
setblock 41 71 354 minecraft:yellow_terracotta
fill 41 71 355 41 73 355 minecraft:honeycomb_block
setblock 41 71 359 minecraft:yellow_terracotta
fill 41 71 360 41 74 360 minecraft:honeycomb_block
setblock 42 71 351 minecraft:yellow_terracotta
fill 0 72 339 1 75 339 minecraft:honeycomb_block
fill 0 72 353 0 176 353 minecraft:honeycomb_block
setblock 1 72 323 minecraft:yellow_terracotta
fill 1 72 324 1 75 324 minecraft:honeycomb_block
setblock 1 72 333 minecraft:yellow_terracotta
setblock 1 72 334 minecraft:honeycomb_block
setblock 1 72 338 minecraft:yellow_terracotta
fill 1 72 346 1 73 346 minecraft:brown_terracotta
setblock 1 72 353 minecraft:yellow_terracotta
fill 1 72 354 1 75 354 minecraft:honeycomb_block
setblock 1 72 358 minecraft:yellow_terracotta
fill 1 72 359 1 75 359 minecraft:honeycomb_block
setblock 1 72 363 minecraft:yellow_terracotta
fill 2 72 323 2 75 323 minecraft:honeycomb_block
fill 2 72 345 2 73 345 minecraft:brown_terracotta
fill 2 72 347 2 73 347 minecraft:brown_terracotta
setblock 2 72 357 minecraft:yellow_terracotta
fill 2 72 358 2 75 358 minecraft:honeycomb_block
setblock 2 72 362 minecraft:yellow_terracotta
fill 2 72 363 2 75 363 minecraft:honeycomb_block
setblock 3 72 325 minecraft:light[level=15]
setblock 3 72 333 minecraft:light[level=15]
setblock 3 72 341 minecraft:light[level=15]
fill 3 72 346 3 73 346 minecraft:brown_terracotta
setblock 3 72 349 minecraft:light[level=15]
setblock 3 72 357 minecraft:light[level=15]
setblock 3 72 361 minecraft:yellow_terracotta
fill 3 72 362 3 75 362 minecraft:honeycomb_block
setblock 6 72 363 minecraft:yellow_terracotta
fill 7 72 363 10 72 363 minecraft:honeycomb_block
setblock 11 72 325 minecraft:light[level=15]
setblock 11 72 333 minecraft:light[level=15]
setblock 11 72 341 minecraft:light[level=15]
setblock 11 72 349 minecraft:light[level=15]
setblock 11 72 357 minecraft:light[level=15]
setblock 11 72 363 minecraft:yellow_terracotta
fill 12 72 363 12 75 363 minecraft:honeycomb_block
fill 13 72 362 13 75 362 minecraft:honeycomb_block
setblock 16 72 363 minecraft:yellow_terracotta
setblock 17 72 362 minecraft:yellow_terracotta
fill 17 72 363 17 75 363 minecraft:honeycomb_block
fill 18 72 362 18 75 362 minecraft:honeycomb_block
setblock 19 72 325 minecraft:light[level=15]
setblock 19 72 333 minecraft:light[level=15]
setblock 19 72 341 minecraft:light[level=15]
setblock 19 72 349 minecraft:light[level=15]
setblock 19 72 357 minecraft:light[level=15]
setblock 21 72 363 minecraft:yellow_terracotta
setblock 22 72 363 minecraft:honeycomb_block
setblock 23 72 323 minecraft:honey_block
setblock 27 72 325 minecraft:light[level=15]
setblock 27 72 333 minecraft:light[level=15]
setblock 27 72 341 minecraft:light[level=15]
setblock 27 72 349 minecraft:light[level=15]
setblock 27 72 357 minecraft:light[level=15]
fill 31 72 340 31 79 341 minecraft:brown_terracotta
fill 32 72 345 32 75 345 minecraft:brown_terracotta
fill 33 72 323 33 74 323 minecraft:honeycomb_block
fill 33 72 343 34 75 343 minecraft:brown_terracotta
fill 33 72 347 33 75 347 minecraft:brown_terracotta
fill 33 72 363 33 74 363 minecraft:honeycomb_block
fill 34 72 342 34 79 342 minecraft:brown_terracotta
fill 34 72 348 35 75 348 minecraft:brown_terracotta
setblock 35 72 325 minecraft:light[level=15]
setblock 35 72 333 minecraft:light[level=15]
fill 35 72 339 35 72 346 minecraft:honey_block
fill 35 72 347 35 75 347 minecraft:brown_terracotta
setblock 35 72 349 minecraft:light[level=15]
setblock 35 72 357 minecraft:light[level=15]
fill 35 72 362 35 73 362 minecraft:honeycomb_block
setblock 36 72 323 minecraft:yellow_terracotta
fill 36 72 324 36 75 324 minecraft:honeycomb_block
fill 36 72 342 36 75 343 minecraft:brown_terracotta
setblock 36 72 363 minecraft:yellow_terracotta
fill 37 72 323 37 75 323 minecraft:honeycomb_block
fill 37 72 348 37 75 348 minecraft:brown_terracotta
setblock 37 72 362 minecraft:yellow_terracotta
fill 37 72 363 37 75 363 minecraft:honeycomb_block
fill 38 72 342 38 75 342 minecraft:brown_terracotta
setblock 38 72 361 minecraft:yellow_terracotta
fill 38 72 362 38 75 362 minecraft:honeycomb_block
setblock 39 72 335 minecraft:yellow_terracotta
setblock 39 72 336 minecraft:honeycomb_block
fill 39 72 343 39 75 344 minecraft:brown_terracotta
fill 39 72 346 39 75 346 minecraft:brown_terracotta
setblock 39 72 360 minecraft:yellow_terracotta
fill 39 72 361 39 75 361 minecraft:honeycomb_block
setblock 40 72 324 minecraft:yellow_terracotta
fill 40 72 325 40 75 325 minecraft:honeycomb_block
setblock 40 72 330 minecraft:honeycomb_block
setblock 40 72 334 minecraft:yellow_terracotta
fill 40 72 335 40 74 335 minecraft:honeycomb_block
setblock 40 72 339 minecraft:yellow_terracotta
fill 40 72 340 40 75 340 minecraft:honeycomb_block
setblock 40 72 359 minecraft:yellow_terracotta
fill 40 72 360 40 75 360 minecraft:honeycomb_block
setblock 41 72 323 minecraft:yellow_terracotta
fill 41 72 324 41 75 324 minecraft:honeycomb_block
setblock 41 72 328 minecraft:yellow_terracotta
fill 41 72 329 41 74 329 minecraft:honeycomb_block
setblock 41 72 333 minecraft:yellow_terracotta
fill 41 72 334 41 75 334 minecraft:honeycomb_block
setblock 41 72 338 minecraft:yellow_terracotta
fill 41 72 339 41 75 339 minecraft:honeycomb_block
setblock 41 72 349 minecraft:honey_block
setblock 41 72 354 minecraft:honeycomb_block
setblock 41 72 358 minecraft:yellow_terracotta
fill 41 72 359 41 75 359 minecraft:honeycomb_block
setblock 41 72 363 minecraft:yellow_terracotta
fill 42 72 351 42 76 351 minecraft:honeycomb_block
fill 1 73 323 1 76 323 minecraft:honeycomb_block
setblock 1 73 337 minecraft:yellow_terracotta
fill 1 73 338 1 76 338 minecraft:honeycomb_block
setblock 1 73 342 minecraft:yellow_terracotta
setblock 1 73 343 minecraft:honey_block
fill 1 73 353 1 74 353 minecraft:honeycomb_block
setblock 1 73 357 minecraft:yellow_terracotta
fill 1 73 358 1 76 358 minecraft:honeycomb_block
setblock 1 73 362 minecraft:yellow_terracotta
fill 1 73 363 1 76 363 minecraft:honeycomb_block
setblock 2 73 356 minecraft:yellow_terracotta
fill 2 73 357 2 76 357 minecraft:honeycomb_block
setblock 2 73 361 minecraft:yellow_terracotta
fill 2 73 362 2 76 362 minecraft:honeycomb_block
setblock 3 73 360 minecraft:yellow_terracotta
setblock 5 73 363 minecraft:yellow_terracotta
fill 6 73 363 9 73 363 minecraft:honeycomb_block
setblock 10 73 363 minecraft:yellow_terracotta
fill 11 73 363 11 76 363 minecraft:honeycomb_block
fill 12 73 362 12 76 362 minecraft:honeycomb_block
setblock 15 73 363 minecraft:yellow_terracotta
setblock 16 73 362 minecraft:yellow_terracotta
fill 16 73 363 16 76 363 minecraft:honeycomb_block
setblock 17 73 323 minecraft:honey_block
fill 17 73 362 17 76 362 minecraft:honeycomb_block
setblock 20 73 363 minecraft:yellow_terracotta
fill 21 73 363 21 76 363 minecraft:honeycomb_block
setblock 24 73 322 minecraft:yellow_concrete
setblock 25 73 363 minecraft:honey_block
fill 32 73 323 32 75 323 minecraft:honeycomb_block
fill 32 73 339 32 79 339 minecraft:brown_terracotta
fill 32 73 342 32 75 344 minecraft:brown_terracotta
fill 32 73 346 32 75 347 minecraft:brown_terracotta
fill 33 73 340 33 79 342 minecraft:brown_terracotta
fill 33 73 348 33 75 348 minecraft:brown_terracotta
setblock 33 73 364 minecraft:orange_terracotta
fill 34 73 341 37 75 341 minecraft:brown_terracotta
fill 34 73 364 34 94 364 minecraft:honeycomb_block
setblock 35 73 323 minecraft:yellow_terracotta
fill 35 73 324 35 76 324 minecraft:honeycomb_block
fill 35 73 342 35 75 346 minecraft:brown_terracotta
fill 35 73 349 36 75 349 minecraft:brown_terracotta
setblock 35 73 363 minecraft:yellow_terracotta
fill 36 73 323 36 76 323 minecraft:honeycomb_block
setblock 36 73 362 minecraft:yellow_terracotta
fill 36 73 363 36 76 363 minecraft:honeycomb_block
fill 37 73 362 37 76 362 minecraft:honeycomb_block
fill 38 73 348 38 75 348 minecraft:brown_terracotta
fill 38 73 361 38 76 361 minecraft:honeycomb_block
setblock 39 73 324 minecraft:yellow_terracotta
fill 39 73 347 39 75 347 minecraft:brown_terracotta
fill 39 73 360 39 76 360 minecraft:honeycomb_block
setblock 40 73 323 minecraft:yellow_terracotta
fill 40 73 324 40 76 324 minecraft:honeycomb_block
setblock 40 73 333 minecraft:yellow_terracotta
setblock 40 73 334 minecraft:honeycomb_block
setblock 40 73 338 minecraft:yellow_terracotta
fill 40 73 339 40 76 339 minecraft:honeycomb_block
fill 40 73 345 40 75 345 minecraft:brown_terracotta
setblock 40 73 358 minecraft:yellow_terracotta
fill 40 73 359 40 76 359 minecraft:honeycomb_block
setblock 40 73 363 minecraft:yellow_terracotta
fill 41 73 323 41 76 323 minecraft:honeycomb_block
setblock 41 73 327 minecraft:yellow_terracotta
fill 41 73 328 41 76 328 minecraft:honeycomb_block
setblock 41 73 332 minecraft:yellow_terracotta
fill 41 73 333 41 74 333 minecraft:honeycomb_block
setblock 41 73 337 minecraft:yellow_terracotta
fill 41 73 338 41 76 338 minecraft:honeycomb_block
setblock 41 73 342 minecraft:yellow_terracotta
setblock 41 73 343 minecraft:honey_block
setblock 41 73 357 minecraft:yellow_terracotta
fill 41 73 358 41 76 358 minecraft:honeycomb_block
setblock 41 73 362 minecraft:yellow_terracotta
fill 41 73 363 41 76 363 minecraft:honeycomb_block
fill 42 73 357 42 90 357 minecraft:honeycomb_block
fill 0 74 329 0 129 329 minecraft:honeycomb_block
setblock 0 74 330 minecraft:yellow_concrete
fill 0 74 331 0 90 331 minecraft:honeycomb_block
setblock 1 74 330 minecraft:honey_block
setblock 1 74 337 minecraft:honeycomb_block
setblock 1 74 341 minecraft:yellow_terracotta
fill 1 74 342 1 76 343 minecraft:honeycomb_block
setblock 1 74 349 minecraft:honey_block
setblock 1 74 356 minecraft:yellow_terracotta
fill 1 74 357 1 77 357 minecraft:honeycomb_block
setblock 1 74 361 minecraft:yellow_terracotta
fill 1 74 362 1 77 362 minecraft:honeycomb_block
setblock 2 74 356 minecraft:honeycomb_block
setblock 2 74 360 minecraft:yellow_terracotta
fill 2 74 361 2 77 361 minecraft:honeycomb_block
setblock 3 74 325 minecraft:light[level=12]
setblock 3 74 332 minecraft:light[level=12]
setblock 3 74 339 minecraft:light[level=12]
setblock 3 74 346 minecraft:light[level=12]
setblock 3 74 353 minecraft:light[level=12]
setblock 3 74 360 minecraft:light[level=12]
setblock 4 74 363 minecraft:yellow_terracotta
fill 5 74 323 5 75 323 minecraft:honey_block
setblock 5 74 362 minecraft:yellow_terracotta
fill 5 74 363 8 74 363 minecraft:honeycomb_block
setblock 9 74 363 minecraft:yellow_terracotta
setblock 10 74 325 minecraft:light[level=12]
setblock 10 74 332 minecraft:light[level=12]
setblock 10 74 339 minecraft:light[level=12]
setblock 10 74 346 minecraft:light[level=12]
setblock 10 74 353 minecraft:light[level=12]
setblock 10 74 360 minecraft:light[level=12]
fill 10 74 363 10 77 363 minecraft:honeycomb_block
setblock 11 74 323 minecraft:honey_block
fill 11 74 362 11 77 362 minecraft:honeycomb_block
setblock 14 74 363 minecraft:yellow_terracotta
setblock 15 74 362 minecraft:yellow_terracotta
fill 15 74 363 15 77 363 minecraft:honeycomb_block
fill 16 74 323 18 74 323 minecraft:honeycomb_block
fill 16 74 362 16 77 362 minecraft:honeycomb_block
setblock 17 74 325 minecraft:light[level=12]
setblock 17 74 332 minecraft:light[level=12]
setblock 17 74 339 minecraft:light[level=12]
setblock 17 74 346 minecraft:light[level=12]
setblock 17 74 353 minecraft:light[level=12]
setblock 17 74 360 minecraft:light[level=12]
setblock 19 74 323 minecraft:yellow_terracotta
setblock 19 74 363 minecraft:yellow_terracotta
fill 20 74 363 20 77 363 minecraft:honeycomb_block
fill 24 74 322 24 225 322 minecraft:honeycomb_block
setblock 24 74 325 minecraft:light[level=12]
setblock 24 74 332 minecraft:light[level=12]
setblock 24 74 339 minecraft:light[level=12]
setblock 24 74 346 minecraft:light[level=12]
setblock 24 74 353 minecraft:light[level=12]
setblock 24 74 360 minecraft:light[level=12]
setblock 30 74 323 minecraft:honey_block
fill 30 74 340 30 79 341 minecraft:brown_terracotta
fill 31 74 323 31 76 323 minecraft:honeycomb_block
setblock 31 74 325 minecraft:light[level=12]
setblock 31 74 332 minecraft:light[level=12]
fill 31 74 339 31 79 339 minecraft:brown_terracotta
fill 31 74 342 31 79 342 minecraft:brown_terracotta
fill 31 74 345 31 75 345 minecraft:brown_terracotta
setblock 31 74 346 minecraft:light[level=12]
setblock 31 74 353 minecraft:light[level=12]
setblock 31 74 360 minecraft:light[level=12]
setblock 31 74 363 minecraft:honey_block
fill 32 74 363 32 75 363 minecraft:honeycomb_block
fill 33 74 339 33 79 339 minecraft:brown_terracotta
fill 33 74 364 33 121 364 minecraft:honeycomb_block
setblock 34 74 323 minecraft:yellow_terracotta
fill 34 74 324 34 77 324 minecraft:honeycomb_block
fill 34 74 349 34 75 349 minecraft:brown_terracotta
setblock 34 74 362 minecraft:honeycomb_block
setblock 34 74 363 minecraft:yellow_terracotta
fill 35 74 323 35 77 323 minecraft:honeycomb_block
setblock 35 74 362 minecraft:yellow_terracotta
fill 35 74 363 35 77 363 minecraft:honeycomb_block
fill 36 74 350 38 74 350 minecraft:honey_block
fill 36 74 362 36 77 362 minecraft:honeycomb_block
fill 37 74 349 38 75 349 minecraft:brown_terracotta
fill 37 74 361 37 77 361 minecraft:honeycomb_block
setblock 38 74 324 minecraft:yellow_terracotta
setblock 38 74 325 minecraft:light[level=12]
setblock 38 74 332 minecraft:light[level=12]
setblock 38 74 339 minecraft:light[level=12]
fill 38 74 341 38 75 341 minecraft:brown_terracotta
setblock 38 74 353 minecraft:light[level=12]
setblock 38 74 360 minecraft:light[level=12]
setblock 39 74 323 minecraft:yellow_terracotta
fill 39 74 324 39 77 324 minecraft:honeycomb_block
fill 39 74 342 39 75 342 minecraft:brown_terracotta
fill 39 74 348 39 75 348 minecraft:brown_terracotta
setblock 39 74 363 minecraft:yellow_terracotta
fill 40 74 323 40 77 323 minecraft:honeycomb_block
setblock 40 74 337 minecraft:yellow_terracotta
fill 40 74 338 40 75 338 minecraft:honeycomb_block
fill 40 74 343 40 75 344 minecraft:brown_terracotta
fill 40 74 346 40 75 347 minecraft:brown_terracotta
setblock 40 74 357 minecraft:yellow_terracotta
fill 40 74 358 40 77 358 minecraft:honeycomb_block
setblock 40 74 362 minecraft:yellow_terracotta
fill 40 74 363 40 77 363 minecraft:honeycomb_block
setblock 41 74 326 minecraft:yellow_terracotta
fill 41 74 327 41 77 327 minecraft:honeycomb_block
setblock 41 74 331 minecraft:yellow_terracotta
setblock 41 74 332 minecraft:honeycomb_block
setblock 41 74 336 minecraft:yellow_terracotta
fill 41 74 337 41 77 337 minecraft:honeycomb_block
setblock 41 74 341 minecraft:yellow_terracotta
fill 41 74 342 41 76 343 minecraft:honeycomb_block
setblock 41 74 356 minecraft:yellow_terracotta
fill 41 74 357 41 77 357 minecraft:honeycomb_block
setblock 41 74 361 minecraft:yellow_terracotta
fill 41 74 362 41 77 362 minecraft:honeycomb_block
setblock 42 74 328 minecraft:yellow_concrete
fill 0 75 330 0 100 330 minecraft:honeycomb_block
fill 0 75 340 0 137 340 minecraft:honeycomb_block
setblock 1 75 336 minecraft:honey_block
setblock 1 75 340 minecraft:yellow_terracotta
fill 1 75 341 1 78 341 minecraft:honeycomb_block
setblock 1 75 344 minecraft:honeycomb_block
setblock 1 75 355 minecraft:yellow_terracotta
fill 1 75 356 1 78 356 minecraft:honeycomb_block
setblock 1 75 360 minecraft:yellow_terracotta
fill 1 75 361 1 78 361 minecraft:honeycomb_block
setblock 2 75 359 minecraft:yellow_terracotta
fill 2 75 360 2 78 360 minecraft:honeycomb_block
setblock 3 75 363 minecraft:yellow_terracotta
setblock 4 75 362 minecraft:yellow_terracotta
fill 4 75 363 7 75 363 minecraft:honeycomb_block
fill 5 75 362 5 78 362 minecraft:honeycomb_block
setblock 8 75 363 minecraft:yellow_terracotta
fill 9 75 363 9 78 363 minecraft:honeycomb_block
fill 10 75 362 10 78 362 minecraft:honeycomb_block
setblock 13 75 363 minecraft:yellow_terracotta
fill 14 75 323 17 75 323 minecraft:honeycomb_block
setblock 14 75 362 minecraft:yellow_terracotta
fill 14 75 363 14 78 363 minecraft:honeycomb_block
fill 15 75 362 15 78 362 minecraft:honeycomb_block
setblock 18 75 323 minecraft:yellow_terracotta
setblock 18 75 363 minecraft:yellow_terracotta
fill 19 75 323 20 77 323 minecraft:honeycomb_block
setblock 19 75 362 minecraft:yellow_terracotta
fill 19 75 363 19 78 363 minecraft:honeycomb_block
setblock 24 75 323 minecraft:honey_block
fill 29 75 323 30 77 323 minecraft:honeycomb_block
fill 30 75 339 30 79 339 minecraft:brown_terracotta
fill 30 75 342 30 79 342 minecraft:brown_terracotta
fill 30 75 363 31 76 363 minecraft:honeycomb_block
fill 31 75 338 32 79 338 minecraft:brown_terracotta
fill 31 75 343 31 75 344 minecraft:brown_terracotta
fill 31 75 346 31 75 347 minecraft:brown_terracotta
setblock 32 75 324 minecraft:yellow_terracotta
setblock 32 75 348 minecraft:brown_terracotta
setblock 33 75 323 minecraft:yellow_terracotta
fill 33 75 324 33 78 324 minecraft:honeycomb_block
setblock 33 75 349 minecraft:brown_terracotta
setblock 33 75 362 minecraft:honeycomb_block
setblock 33 75 363 minecraft:yellow_terracotta
fill 34 75 323 34 78 323 minecraft:honeycomb_block
fill 34 75 339 34 79 340 minecraft:brown_terracotta
setblock 34 75 362 minecraft:yellow_terracotta
fill 34 75 363 34 78 363 minecraft:honeycomb_block
fill 35 75 340 37 75 340 minecraft:brown_terracotta
fill 35 75 350 37 75 350 minecraft:brown_terracotta
fill 35 75 362 35 78 362 minecraft:honeycomb_block
setblock 35 75 364 minecraft:orange_terracotta
setblock 36 75 325 minecraft:yellow_terracotta
fill 36 75 361 36 78 361 minecraft:honeycomb_block
setblock 37 75 324 minecraft:yellow_terracotta
fill 37 75 325 37 78 325 minecraft:honeycomb_block
setblock 38 75 323 minecraft:yellow_terracotta
fill 38 75 324 38 78 324 minecraft:honeycomb_block
setblock 38 75 350 minecraft:honey_block
setblock 38 75 363 minecraft:yellow_terracotta
fill 39 75 323 39 78 323 minecraft:honeycomb_block
setblock 39 75 341 minecraft:brown_terracotta
setblock 39 75 349 minecraft:brown_terracotta
setblock 39 75 362 minecraft:yellow_terracotta
fill 39 75 363 39 78 363 minecraft:honeycomb_block
setblock 40 75 326 minecraft:yellow_terracotta
setblock 40 75 337 minecraft:honeycomb_block
setblock 40 75 342 minecraft:brown_terracotta
setblock 40 75 361 minecraft:yellow_terracotta
fill 40 75 362 40 78 362 minecraft:honeycomb_block
setblock 41 75 325 minecraft:yellow_terracotta
fill 41 75 326 41 78 326 minecraft:honeycomb_block
setblock 41 75 331 minecraft:honey_block
setblock 41 75 335 minecraft:yellow_terracotta
fill 41 75 336 41 76 336 minecraft:honeycomb_block
setblock 41 75 340 minecraft:yellow_terracotta
fill 41 75 341 41 78 341 minecraft:honeycomb_block
setblock 41 75 350 minecraft:honey_block
fill 41 75 356 41 78 356 minecraft:honeycomb_block
setblock 41 75 360 minecraft:yellow_terracotta
fill 41 75 361 41 78 361 minecraft:honeycomb_block
fill 42 75 328 42 258 328 minecraft:honeycomb_block
fill 42 75 352 42 92 352 minecraft:honeycomb_block
setblock 42 75 353 minecraft:yellow_terracotta
fill 0 76 339 0 102 339 minecraft:honeycomb_block
setblock 1 76 324 minecraft:yellow_terracotta
setblock 1 76 339 minecraft:yellow_terracotta
fill 1 76 340 1 79 340 minecraft:honeycomb_block
setblock 1 76 344 minecraft:yellow_terracotta
fill 1 76 345 1 78 346 minecraft:honeycomb_block
setblock 1 76 354 minecraft:yellow_terracotta
fill 1 76 355 1 79 355 minecraft:honeycomb_block
setblock 1 76 359 minecraft:yellow_terracotta
fill 1 76 360 1 79 360 minecraft:honeycomb_block
setblock 2 76 323 minecraft:yellow_terracotta
setblock 2 76 358 minecraft:yellow_terracotta
fill 2 76 359 2 79 359 minecraft:honeycomb_block
setblock 2 76 363 minecraft:yellow_terracotta
fill 3 76 323 3 79 323 minecraft:honeycomb_block
setblock 3 76 362 minecraft:yellow_terracotta
fill 3 76 363 6 76 363 minecraft:honeycomb_block
fill 4 76 362 4 79 362 minecraft:honeycomb_block
fill 6 76 362 7 76 362 minecraft:honeycomb_block
setblock 7 76 363 minecraft:yellow_terracotta
setblock 8 76 362 minecraft:yellow_terracotta
fill 8 76 363 8 79 363 minecraft:honeycomb_block
fill 9 76 362 9 79 362 minecraft:honeycomb_block
setblock 12 76 323 minecraft:yellow_terracotta
setblock 12 76 363 minecraft:yellow_terracotta
fill 13 76 323 16 76 323 minecraft:honeycomb_block
setblock 13 76 361 minecraft:honeycomb_block
setblock 13 76 362 minecraft:yellow_terracotta
fill 13 76 363 13 79 363 minecraft:honeycomb_block
setblock 14 76 361 minecraft:yellow_terracotta
fill 14 76 362 14 79 362 minecraft:honeycomb_block
fill 15 76 361 16 77 361 minecraft:honeycomb_block
setblock 17 76 323 minecraft:yellow_terracotta
setblock 17 76 363 minecraft:yellow_terracotta
fill 18 76 323 18 79 323 minecraft:honeycomb_block
setblock 18 76 362 minecraft:yellow_terracotta
fill 18 76 363 18 79 363 minecraft:honeycomb_block
fill 19 76 362 19 78 362 minecraft:honeycomb_block
setblock 21 76 323 minecraft:honeycomb_block
setblock 22 76 323 minecraft:yellow_terracotta
setblock 22 76 363 minecraft:yellow_terracotta
setblock 24 76 363 minecraft:honey_block
setblock 27 76 323 minecraft:yellow_terracotta
fill 28 76 323 28 79 323 minecraft:honeycomb_block
fill 29 76 340 29 79 341 minecraft:brown_terracotta
fill 29 76 363 29 78 363 minecraft:honeycomb_block
fill 30 76 338 30 79 338 minecraft:brown_terracotta
setblock 31 76 324 minecraft:yellow_terracotta
fill 31 76 343 33 79 343 minecraft:brown_terracotta
setblock 32 76 323 minecraft:yellow_terracotta
fill 32 76 324 32 79 324 minecraft:honeycomb_block
fill 32 76 342 32 79 342 minecraft:brown_terracotta
setblock 32 76 362 minecraft:honeycomb_block
setblock 32 76 363 minecraft:yellow_terracotta
fill 33 76 323 33 79 323 minecraft:honeycomb_block
fill 33 76 338 33 79 338 minecraft:brown_terracotta
setblock 33 76 362 minecraft:yellow_terracotta
fill 33 76 363 33 79 363 minecraft:honeycomb_block
setblock 34 76 325 minecraft:honeycomb_block
fill 34 76 341 34 79 341 minecraft:brown_terracotta
fill 34 76 362 34 79 362 minecraft:honeycomb_block
setblock 35 76 325 minecraft:yellow_terracotta
fill 35 76 361 35 79 361 minecraft:honeycomb_block
fill 35 76 364 35 308 364 minecraft:honeycomb_block
setblock 36 76 324 minecraft:yellow_terracotta
fill 36 76 325 36 79 325 minecraft:honeycomb_block
fill 36 76 345 36 79 345 minecraft:yellow_terracotta
setblock 37 76 323 minecraft:yellow_terracotta
fill 37 76 324 37 79 324 minecraft:honeycomb_block
setblock 37 76 363 minecraft:yellow_terracotta
fill 38 76 323 38 79 323 minecraft:honeycomb_block
fill 38 76 325 38 77 325 minecraft:honeycomb_block
setblock 38 76 362 minecraft:yellow_terracotta
fill 38 76 363 38 79 363 minecraft:honeycomb_block
setblock 39 76 361 minecraft:yellow_terracotta
fill 39 76 362 39 79 362 minecraft:honeycomb_block
setblock 40 76 325 minecraft:yellow_terracotta
fill 40 76 326 40 79 326 minecraft:honeycomb_block
setblock 40 76 340 minecraft:yellow_terracotta
setblock 40 76 360 minecraft:yellow_terracotta
fill 40 76 361 40 79 361 minecraft:honeycomb_block
setblock 41 76 324 minecraft:yellow_terracotta
fill 41 76 325 41 79 325 minecraft:honeycomb_block
setblock 41 76 339 minecraft:yellow_terracotta
fill 41 76 340 41 79 340 minecraft:honeycomb_block
setblock 41 76 344 minecraft:yellow_terracotta
setblock 41 76 359 minecraft:yellow_terracotta
fill 41 76 360 41 79 360 minecraft:honeycomb_block
fill 42 76 334 42 136 334 minecraft:honeycomb_block
setblock 42 76 335 minecraft:yellow_concrete
fill 42 76 336 42 87 337 minecraft:honeycomb_block
fill 42 76 353 42 92 353 minecraft:honeycomb_block
setblock 42 76 361 minecraft:yellow_terracotta
setblock 1 77 323 minecraft:yellow_terracotta
fill 1 77 324 1 79 325 minecraft:honeycomb_block
fill 1 77 339 1 79 339 minecraft:honeycomb_block
setblock 1 77 342 minecraft:honeycomb_block
setblock 1 77 343 minecraft:yellow_terracotta
fill 1 77 344 1 80 344 minecraft:honeycomb_block
setblock 1 77 347 minecraft:honeycomb_block
setblock 1 77 348 minecraft:yellow_terracotta
setblock 1 77 353 minecraft:yellow_terracotta
fill 1 77 354 1 80 354 minecraft:honeycomb_block
setblock 1 77 358 minecraft:yellow_terracotta
fill 1 77 359 1 80 359 minecraft:honeycomb_block
setblock 1 77 363 minecraft:yellow_terracotta
fill 2 77 323 2 80 323 minecraft:honeycomb_block
fill 2 77 358 2 78 358 minecraft:honeycomb_block
setblock 2 77 362 minecraft:yellow_terracotta
fill 2 77 363 5 77 363 minecraft:honeycomb_block
fill 3 77 362 3 80 362 minecraft:honeycomb_block
setblock 6 77 362 minecraft:honeycomb_block
setblock 6 77 363 minecraft:yellow_terracotta
setblock 7 77 362 minecraft:yellow_terracotta
fill 7 77 363 7 80 363 minecraft:honeycomb_block
fill 8 77 362 8 80 362 minecraft:honeycomb_block
setblock 10 77 323 minecraft:honeycomb_block
setblock 11 77 323 minecraft:yellow_terracotta
setblock 11 77 363 minecraft:yellow_terracotta
fill 12 77 323 15 77 323 minecraft:honeycomb_block
setblock 12 77 361 minecraft:honeycomb_block
setblock 12 77 362 minecraft:yellow_terracotta
fill 12 77 363 12 80 363 minecraft:honeycomb_block
setblock 13 77 361 minecraft:yellow_terracotta
fill 13 77 362 13 80 362 minecraft:honeycomb_block
fill 14 77 361 14 79 361 minecraft:honeycomb_block
setblock 15 77 324 minecraft:yellow_terracotta
setblock 16 77 323 minecraft:yellow_terracotta
fill 16 77 324 18 78 324 minecraft:honeycomb_block
setblock 16 77 363 minecraft:yellow_terracotta
fill 17 77 323 17 80 323 minecraft:honeycomb_block
setblock 17 77 362 minecraft:yellow_terracotta
fill 17 77 363 17 80 363 minecraft:honeycomb_block
setblock 18 77 322 minecraft:yellow_terracotta
fill 18 77 362 18 79 362 minecraft:honeycomb_block
fill 19 77 322 19 123 322 minecraft:honeycomb_block
setblock 20 77 322 minecraft:yellow_concrete
setblock 21 77 323 minecraft:yellow_terracotta
setblock 21 77 363 minecraft:yellow_terracotta
fill 22 77 323 25 77 323 minecraft:honeycomb_block
fill 22 77 363 22 80 363 minecraft:honeycomb_block
setblock 26 77 323 minecraft:yellow_terracotta
fill 27 77 323 27 80 323 minecraft:honeycomb_block
fill 28 77 363 28 79 363 minecraft:honeycomb_block
setblock 29 77 324 minecraft:honeycomb_block
fill 29 77 339 29 79 339 minecraft:brown_terracotta
fill 29 77 342 29 79 342 minecraft:brown_terracotta
setblock 30 77 324 minecraft:yellow_terracotta
fill 30 77 343 30 79 343 minecraft:brown_terracotta
setblock 30 77 363 minecraft:honeycomb_block
setblock 31 77 323 minecraft:yellow_terracotta
fill 31 77 324 31 80 324 minecraft:honeycomb_block
fill 31 77 337 33 79 337 minecraft:brown_terracotta
setblock 31 77 362 minecraft:honeycomb_block
setblock 31 77 363 minecraft:yellow_terracotta
fill 32 77 323 32 80 323 minecraft:honeycomb_block
fill 32 77 325 33 77 325 minecraft:honeycomb_block
setblock 32 77 362 minecraft:yellow_terracotta
fill 32 77 363 32 80 363 minecraft:honeycomb_block
fill 33 77 362 33 80 362 minecraft:honeycomb_block
setblock 34 77 325 minecraft:yellow_terracotta
fill 34 77 338 34 79 338 minecraft:brown_terracotta
fill 34 77 343 34 79 343 minecraft:brown_terracotta
fill 34 77 361 34 80 361 minecraft:honeycomb_block
setblock 35 77 324 minecraft:yellow_terracotta
fill 35 77 325 35 80 325 minecraft:honeycomb_block
fill 35 77 339 35 79 342 minecraft:brown_terracotta
setblock 36 77 323 minecraft:yellow_terracotta
fill 36 77 324 36 80 324 minecraft:honeycomb_block
setblock 36 77 363 minecraft:yellow_terracotta
fill 37 77 323 37 80 323 minecraft:honeycomb_block
setblock 37 77 362 minecraft:yellow_terracotta
fill 37 77 363 37 80 363 minecraft:honeycomb_block
setblock 38 77 361 minecraft:yellow_terracotta
fill 38 77 362 38 80 362 minecraft:honeycomb_block
setblock 39 77 325 minecraft:yellow_terracotta
setblock 39 77 360 minecraft:yellow_terracotta
fill 39 77 361 39 80 361 minecraft:honeycomb_block
setblock 40 77 324 minecraft:yellow_terracotta
fill 40 77 325 40 80 325 minecraft:honeycomb_block
fill 40 77 327 40 78 327 minecraft:honeycomb_block
setblock 40 77 359 minecraft:yellow_terracotta
fill 40 77 360 40 80 360 minecraft:honeycomb_block
setblock 41 77 323 minecraft:yellow_terracotta
fill 41 77 324 41 80 324 minecraft:honeycomb_block
setblock 41 77 328 minecraft:yellow_terracotta
setblock 41 77 338 minecraft:yellow_terracotta
fill 41 77 339 41 79 339 minecraft:honeycomb_block
setblock 41 77 342 minecraft:honeycomb_block
setblock 41 77 343 minecraft:yellow_terracotta
fill 41 77 344 41 79 345 minecraft:honeycomb_block
setblock 41 77 358 minecraft:yellow_terracotta
fill 41 77 359 41 80 359 minecraft:honeycomb_block
setblock 41 77 363 minecraft:yellow_terracotta
fill 42 77 335 42 128 335 minecraft:honeycomb_block
setblock 42 77 351 minecraft:yellow_concrete
fill 42 77 361 42 171 361 minecraft:honeycomb_block
setblock 1 78 322 minecraft:yellow_terracotta
fill 1 78 323 1 81 323 minecraft:honeycomb_block
setblock 1 78 329 minecraft:honey_block
fill 1 78 335 1 79 335 minecraft:honey_block
setblock 1 78 342 minecraft:yellow_terracotta
fill 1 78 343 1 81 343 minecraft:honeycomb_block
setblock 1 78 347 minecraft:yellow_terracotta
fill 1 78 348 1 78 351 minecraft:honeycomb_block
setblock 1 78 352 minecraft:yellow_terracotta
fill 1 78 353 1 81 353 minecraft:honeycomb_block
setblock 1 78 357 minecraft:yellow_terracotta
fill 1 78 358 1 81 358 minecraft:honeycomb_block
setblock 1 78 362 minecraft:yellow_terracotta
fill 1 78 363 4 78 363 minecraft:honeycomb_block
fill 2 78 322 4 104 322 minecraft:honeycomb_block
setblock 2 78 361 minecraft:yellow_terracotta
fill 2 78 362 2 81 362 minecraft:honeycomb_block
setblock 4 78 323 minecraft:honeycomb_block
setblock 5 78 323 minecraft:yellow_terracotta
setblock 5 78 363 minecraft:yellow_terracotta
setblock 6 78 323 minecraft:honey_block
setblock 6 78 362 minecraft:yellow_terracotta
fill 6 78 363 6 81 363 minecraft:honeycomb_block
fill 7 78 323 9 78 323 minecraft:honeycomb_block
fill 7 78 362 7 81 362 minecraft:honeycomb_block
setblock 7 78 364 minecraft:yellow_concrete
fill 8 78 364 8 148 364 minecraft:honeycomb_block
setblock 10 78 323 minecraft:yellow_terracotta
setblock 10 78 363 minecraft:yellow_terracotta
fill 11 78 323 14 78 323 minecraft:honeycomb_block
setblock 11 78 361 minecraft:honeycomb_block
setblock 11 78 362 minecraft:yellow_terracotta
fill 11 78 363 11 81 363 minecraft:honeycomb_block
fill 12 78 324 13 78 324 minecraft:honeycomb_block
setblock 12 78 361 minecraft:yellow_terracotta
fill 12 78 362 12 81 362 minecraft:honeycomb_block
fill 13 78 361 13 80 361 minecraft:honeycomb_block
setblock 14 78 324 minecraft:yellow_terracotta
setblock 15 78 323 minecraft:yellow_terracotta
fill 15 78 324 15 81 324 minecraft:honeycomb_block
fill 15 78 361 15 79 361 minecraft:honeycomb_block
setblock 15 78 363 minecraft:yellow_terracotta
fill 16 78 323 16 81 323 minecraft:honeycomb_block
setblock 16 78 362 minecraft:yellow_terracotta
fill 16 78 363 16 81 363 minecraft:honeycomb_block
fill 17 78 362 17 80 362 minecraft:honeycomb_block
fill 18 78 322 18 294 322 minecraft:honeycomb_block
setblock 19 78 323 minecraft:honeycomb_block
setblock 19 78 324 minecraft:yellow_terracotta
fill 20 78 322 20 202 322 minecraft:honeycomb_block
setblock 20 78 323 minecraft:yellow_terracotta
setblock 20 78 363 minecraft:yellow_terracotta
fill 21 78 323 24 78 323 minecraft:honeycomb_block
fill 21 78 363 21 80 363 minecraft:honeycomb_block
setblock 25 78 323 minecraft:yellow_terracotta
fill 26 78 323 26 81 323 minecraft:honeycomb_block
fill 26 78 363 27 80 363 minecraft:honeycomb_block
fill 27 78 324 28 78 324 minecraft:honeycomb_block
fill 28 78 340 28 79 341 minecraft:brown_terracotta
setblock 29 78 323 minecraft:honeycomb_block
setblock 29 78 324 minecraft:yellow_terracotta
fill 29 78 338 29 79 338 minecraft:brown_terracotta
fill 29 78 343 29 79 343 minecraft:brown_terracotta
setblock 30 78 323 minecraft:yellow_terracotta
fill 30 78 324 30 80 325 minecraft:honeycomb_block
fill 30 78 337 30 79 337 minecraft:brown_terracotta
fill 30 78 346 31 79 347 minecraft:yellow_concrete
setblock 30 78 362 minecraft:honeycomb_block
setblock 30 78 363 minecraft:yellow_terracotta
fill 31 78 323 31 81 323 minecraft:honeycomb_block
fill 31 78 325 32 78 325 minecraft:honeycomb_block
fill 31 78 344 33 79 344 minecraft:brown_terracotta
setblock 31 78 362 minecraft:yellow_terracotta
fill 31 78 363 31 81 363 minecraft:honeycomb_block
fill 32 78 347 32 79 347 minecraft:yellow_concrete
fill 32 78 362 32 81 362 minecraft:honeycomb_block
setblock 33 78 325 minecraft:yellow_terracotta
fill 33 78 361 33 81 361 minecraft:honeycomb_block
setblock 34 78 324 minecraft:yellow_terracotta
fill 34 78 325 34 80 326 minecraft:honeycomb_block
fill 34 78 337 34 79 337 minecraft:brown_terracotta
setblock 35 78 323 minecraft:yellow_terracotta
fill 35 78 324 35 81 324 minecraft:honeycomb_block
fill 35 78 326 35 79 326 minecraft:honeycomb_block
fill 35 78 338 35 79 338 minecraft:brown_terracotta
setblock 35 78 363 minecraft:yellow_terracotta
fill 36 78 323 36 81 323 minecraft:honeycomb_block
setblock 36 78 362 minecraft:yellow_terracotta
fill 36 78 363 36 81 363 minecraft:honeycomb_block
setblock 37 78 361 minecraft:yellow_terracotta
fill 37 78 362 37 81 362 minecraft:honeycomb_block
setblock 38 78 325 minecraft:yellow_terracotta
fill 38 78 361 38 81 361 minecraft:honeycomb_block
setblock 39 78 324 minecraft:yellow_terracotta
fill 39 78 325 39 80 326 minecraft:honeycomb_block
fill 39 78 360 39 79 360 minecraft:honeycomb_block
setblock 40 78 323 minecraft:yellow_terracotta
fill 40 78 324 40 81 324 minecraft:honeycomb_block
setblock 40 78 358 minecraft:yellow_terracotta
fill 40 78 359 40 80 359 minecraft:honeycomb_block
setblock 40 78 363 minecraft:yellow_terracotta
fill 41 78 323 41 81 323 minecraft:honeycomb_block
setblock 41 78 327 minecraft:yellow_terracotta
fill 41 78 328 41 81 328 minecraft:honeycomb_block
setblock 41 78 332 minecraft:honey_block
setblock 41 78 338 minecraft:honeycomb_block
setblock 41 78 342 minecraft:yellow_terracotta
fill 41 78 343 41 81 343 minecraft:honeycomb_block
setblock 41 78 346 minecraft:honeycomb_block
setblock 41 78 351 minecraft:honey_block
setblock 41 78 357 minecraft:yellow_terracotta
fill 41 78 358 41 81 358 minecraft:honeycomb_block
setblock 41 78 362 minecraft:yellow_terracotta
fill 41 78 363 41 81 363 minecraft:honeycomb_block
fill 42 78 329 42 85 331 minecraft:honeycomb_block
setblock 42 78 332 minecraft:orange_terracotta
fill 42 78 351 42 87 351 minecraft:honeycomb_block
fill 1 79 322 1 146 322 minecraft:honeycomb_block
setblock 1 79 326 minecraft:yellow_terracotta
setblock 1 79 341 minecraft:yellow_terracotta
fill 1 79 342 1 82 342 minecraft:honeycomb_block
setblock 1 79 345 minecraft:honeycomb_block
setblock 1 79 346 minecraft:yellow_terracotta
fill 1 79 347 1 79 350 minecraft:honeycomb_block
setblock 1 79 351 minecraft:yellow_terracotta
fill 1 79 352 1 82 352 minecraft:honeycomb_block
setblock 1 79 356 minecraft:yellow_terracotta
fill 1 79 357 1 82 357 minecraft:honeycomb_block
setblock 1 79 361 minecraft:yellow_terracotta
fill 1 79 362 1 81 363 minecraft:honeycomb_block
fill 2 79 343 2 79 344 minecraft:honeycomb_block
setblock 2 79 345 minecraft:yellow_terracotta
fill 2 79 346 2 82 346 minecraft:honeycomb_block
setblock 2 79 360 minecraft:yellow_terracotta
fill 2 79 361 2 81 361 minecraft:honeycomb_block
fill 2 79 363 3 79 363 minecraft:honeycomb_block
setblock 4 79 323 minecraft:yellow_terracotta
setblock 4 79 363 minecraft:yellow_terracotta
fill 5 79 323 8 79 323 minecraft:honeycomb_block
setblock 5 79 362 minecraft:yellow_terracotta
fill 5 79 363 5 82 363 minecraft:honeycomb_block
fill 6 79 362 6 81 362 minecraft:honeycomb_block
fill 7 79 364 7 120 364 minecraft:honeycomb_block
setblock 9 79 323 minecraft:yellow_terracotta
setblock 9 79 363 minecraft:yellow_terracotta
fill 10 79 323 12 79 324 minecraft:honeycomb_block
setblock 10 79 362 minecraft:yellow_terracotta
fill 10 79 363 10 82 363 minecraft:honeycomb_block
setblock 11 79 361 minecraft:yellow_terracotta
fill 11 79 362 11 82 362 minecraft:honeycomb_block
fill 12 79 361 12 80 361 minecraft:honeycomb_block
setblock 13 79 323 minecraft:honeycomb_block
setblock 13 79 324 minecraft:yellow_terracotta
setblock 14 79 323 minecraft:yellow_terracotta
fill 14 79 324 14 82 324 minecraft:honeycomb_block
setblock 14 79 363 minecraft:yellow_terracotta
fill 15 79 323 15 82 323 minecraft:honeycomb_block
setblock 15 79 362 minecraft:yellow_terracotta
fill 15 79 363 15 82 363 minecraft:honeycomb_block
fill 16 79 324 17 79 324 minecraft:honeycomb_block
fill 16 79 362 16 81 362 minecraft:honeycomb_block
setblock 18 79 324 minecraft:yellow_terracotta
setblock 19 79 323 minecraft:yellow_terracotta
fill 19 79 324 21 80 324 minecraft:honeycomb_block
setblock 19 79 363 minecraft:yellow_terracotta
fill 20 79 323 23 79 323 minecraft:honeycomb_block
fill 20 79 363 20 81 363 minecraft:honeycomb_block
setblock 22 79 322 minecraft:yellow_concrete
setblock 23 79 363 minecraft:honeycomb_block
setblock 24 79 323 minecraft:yellow_terracotta
fill 25 79 323 25 81 324 minecraft:honeycomb_block
fill 25 79 363 25 82 363 minecraft:honeycomb_block
fill 26 79 324 27 79 324 minecraft:honeycomb_block
setblock 28 79 324 minecraft:yellow_terracotta
setblock 28 79 339 minecraft:brown_terracotta
setblock 28 79 342 minecraft:brown_terracotta
setblock 29 79 323 minecraft:yellow_terracotta
fill 29 79 324 29 81 325 minecraft:honeycomb_block
setblock 29 79 337 minecraft:brown_terracotta
setblock 29 79 362 minecraft:honeycomb_block
setblock 29 79 363 minecraft:yellow_terracotta
fill 30 79 323 30 82 323 minecraft:honeycomb_block
setblock 30 79 344 minecraft:brown_terracotta
setblock 30 79 362 minecraft:yellow_terracotta
fill 30 79 363 30 82 363 minecraft:honeycomb_block
setblock 31 79 325 minecraft:honeycomb_block
fill 31 79 336 33 79 336 minecraft:brown_terracotta
fill 31 79 362 31 82 362 minecraft:honeycomb_block
setblock 32 79 325 minecraft:yellow_terracotta
fill 32 79 326 33 81 326 minecraft:honeycomb_block
fill 32 79 361 32 81 361 minecraft:honeycomb_block
setblock 33 79 324 minecraft:yellow_terracotta
fill 33 79 325 33 82 325 minecraft:honeycomb_block
setblock 34 79 323 minecraft:yellow_terracotta
fill 34 79 324 34 82 324 minecraft:honeycomb_block
fill 34 79 344 35 81 345 minecraft:flowering_azalea_leaves[persistent=true]
setblock 34 79 363 minecraft:yellow_terracotta
fill 35 79 323 35 82 323 minecraft:honeycomb_block
setblock 35 79 343 minecraft:brown_terracotta
fill 35 79 346 37 81 346 minecraft:flowering_azalea_leaves[persistent=true]
setblock 35 79 362 minecraft:yellow_terracotta
fill 35 79 363 35 82 363 minecraft:honeycomb_block
setblock 36 79 326 minecraft:yellow_terracotta
fill 36 79 339 36 79 342 minecraft:brown_terracotta
fill 36 79 343 36 81 344 minecraft:flowering_azalea_leaves[persistent=true]
setblock 36 79 361 minecraft:yellow_terracotta
fill 36 79 362 36 82 362 minecraft:honeycomb_block
setblock 37 79 325 minecraft:yellow_terracotta
fill 37 79 326 37 81 326 minecraft:honeycomb_block
fill 37 79 344 37 81 345 minecraft:flowering_azalea_leaves[persistent=true]
fill 37 79 361 37 81 361 minecraft:honeycomb_block
setblock 38 79 324 minecraft:yellow_terracotta
fill 38 79 325 38 82 325 minecraft:honeycomb_block
setblock 39 79 323 minecraft:yellow_terracotta
fill 39 79 324 39 82 324 minecraft:honeycomb_block
setblock 39 79 363 minecraft:yellow_terracotta
fill 40 79 323 40 82 323 minecraft:honeycomb_block
setblock 40 79 327 minecraft:yellow_terracotta
setblock 40 79 362 minecraft:yellow_terracotta
fill 40 79 363 40 82 363 minecraft:honeycomb_block
setblock 41 79 326 minecraft:yellow_terracotta
fill 41 79 327 41 82 327 minecraft:honeycomb_block
fill 41 79 329 41 80 329 minecraft:honeycomb_block
setblock 41 79 341 minecraft:yellow_terracotta
fill 41 79 342 41 81 342 minecraft:honeycomb_block
setblock 41 79 346 minecraft:yellow_terracotta
fill 41 79 347 41 82 347 minecraft:honeycomb_block
fill 41 79 357 41 80 357 minecraft:honeycomb_block
setblock 41 79 361 minecraft:yellow_terracotta
fill 41 79 362 41 82 362 minecraft:honeycomb_block
fill 42 79 332 42 213 332 minecraft:honeycomb_block
setblock 0 80 333 minecraft:yellow_concrete
fill 0 80 334 0 87 334 minecraft:honeycomb_block
setblock 1 80 324 minecraft:honeycomb_block
setblock 1 80 325 minecraft:yellow_terracotta
fill 1 80 326 1 82 326 minecraft:honeycomb_block
setblock 1 80 340 minecraft:yellow_terracotta
fill 1 80 341 1 82 341 minecraft:honeycomb_block
setblock 1 80 345 minecraft:yellow_terracotta
fill 1 80 346 1 80 349 minecraft:honeycomb_block
setblock 1 80 350 minecraft:yellow_terracotta
fill 1 80 351 1 83 351 minecraft:honeycomb_block
setblock 1 80 355 minecraft:yellow_terracotta
fill 1 80 356 1 82 356 minecraft:honeycomb_block
setblock 1 80 360 minecraft:yellow_terracotta
fill 1 80 361 1 83 361 minecraft:honeycomb_block
setblock 2 80 343 minecraft:honeycomb_block
setblock 2 80 344 minecraft:yellow_terracotta
fill 2 80 345 2 83 345 minecraft:honeycomb_block
fill 2 80 347 2 80 348 minecraft:honeycomb_block
setblock 2 80 360 minecraft:honeycomb_block
setblock 2 80 363 minecraft:honeycomb_block
setblock 3 80 323 minecraft:yellow_terracotta
setblock 3 80 325 minecraft:light[level=15]
setblock 3 80 332 minecraft:light[level=12]
setblock 3 80 333 minecraft:light[level=15]
setblock 3 80 339 minecraft:light[level=12]
setblock 3 80 341 minecraft:light[level=15]
setblock 3 80 346 minecraft:light[level=12]
setblock 3 80 349 minecraft:light[level=15]
setblock 3 80 353 minecraft:light[level=12]
setblock 3 80 357 minecraft:light[level=15]
setblock 3 80 360 minecraft:light[level=12]
setblock 3 80 363 minecraft:yellow_terracotta
fill 4 80 323 7 80 323 minecraft:honeycomb_block
setblock 4 80 362 minecraft:yellow_terracotta
fill 4 80 363 4 83 363 minecraft:honeycomb_block
fill 5 80 362 5 81 362 minecraft:honeycomb_block
setblock 8 80 323 minecraft:yellow_terracotta
setblock 8 80 363 minecraft:yellow_terracotta
fill 9 80 323 11 80 324 minecraft:honeycomb_block
setblock 9 80 362 minecraft:yellow_terracotta
fill 9 80 363 9 83 363 minecraft:honeycomb_block
setblock 10 80 325 minecraft:light[level=12]
setblock 10 80 332 minecraft:light[level=12]
setblock 10 80 339 minecraft:light[level=12]
setblock 10 80 346 minecraft:light[level=12]
setblock 10 80 353 minecraft:light[level=12]
setblock 10 80 360 minecraft:light[level=12]
fill 10 80 362 10 83 362 minecraft:honeycomb_block
setblock 11 80 325 minecraft:light[level=15]
setblock 11 80 333 minecraft:light[level=15]
setblock 11 80 341 minecraft:light[level=15]
setblock 11 80 349 minecraft:light[level=15]
setblock 11 80 357 minecraft:light[level=15]
setblock 12 80 323 minecraft:honeycomb_block
setblock 12 80 324 minecraft:yellow_terracotta
setblock 13 80 323 minecraft:yellow_terracotta
fill 13 80 324 13 83 324 minecraft:honeycomb_block
setblock 13 80 363 minecraft:yellow_terracotta
fill 14 80 323 14 83 323 minecraft:honeycomb_block
fill 14 80 325 15 80 325 minecraft:honeycomb_block
setblock 14 80 362 minecraft:yellow_terracotta
fill 14 80 363 14 83 363 minecraft:honeycomb_block
fill 15 80 362 15 82 362 minecraft:honeycomb_block
setblock 16 80 324 minecraft:honeycomb_block
setblock 17 80 324 minecraft:yellow_terracotta
setblock 17 80 325 minecraft:light[level=12]
setblock 17 80 332 minecraft:light[level=12]
setblock 17 80 339 minecraft:light[level=12]
setblock 17 80 346 minecraft:light[level=12]
setblock 17 80 353 minecraft:light[level=12]
setblock 17 80 360 minecraft:light[level=12]
setblock 18 80 323 minecraft:yellow_terracotta
fill 18 80 324 18 83 324 minecraft:honeycomb_block
setblock 18 80 363 minecraft:yellow_terracotta
fill 19 80 323 22 80 323 minecraft:honeycomb_block
setblock 19 80 325 minecraft:light[level=15]
setblock 19 80 333 minecraft:light[level=15]
setblock 19 80 341 minecraft:light[level=15]
setblock 19 80 349 minecraft:light[level=15]
setblock 19 80 357 minecraft:light[level=15]
fill 19 80 363 19 81 363 minecraft:honeycomb_block
fill 22 80 322 22 231 322 minecraft:honeycomb_block
setblock 22 80 324 minecraft:yellow_terracotta
setblock 23 80 323 minecraft:yellow_terracotta
fill 23 80 324 24 82 324 minecraft:honeycomb_block
fill 24 80 323 24 83 323 minecraft:honeycomb_block
setblock 24 80 325 minecraft:light[level=12]
setblock 24 80 332 minecraft:light[level=12]
setblock 24 80 339 minecraft:light[level=12]
setblock 24 80 346 minecraft:light[level=12]
setblock 24 80 353 minecraft:light[level=12]
setblock 24 80 360 minecraft:light[level=12]
setblock 26 80 324 minecraft:honeycomb_block
setblock 27 80 324 minecraft:yellow_terracotta
fill 27 80 325 28 82 325 minecraft:honeycomb_block
setblock 27 80 333 minecraft:light[level=15]
setblock 27 80 341 minecraft:light[level=15]
setblock 27 80 349 minecraft:light[level=15]
setblock 27 80 357 minecraft:light[level=15]
fill 27 80 364 27 98 364 minecraft:honeycomb_block
setblock 28 80 323 minecraft:yellow_terracotta
fill 28 80 324 28 83 324 minecraft:honeycomb_block
setblock 28 80 363 minecraft:yellow_terracotta
setblock 28 80 364 minecraft:orange_terracotta
fill 29 80 323 29 83 323 minecraft:honeycomb_block
setblock 29 80 362 minecraft:yellow_terracotta
fill 29 80 363 29 83 363 minecraft:honeycomb_block
setblock 30 80 326 minecraft:yellow_terracotta
fill 30 80 362 30 83 362 minecraft:honeycomb_block
setblock 31 80 325 minecraft:yellow_terracotta
fill 31 80 326 31 83 326 minecraft:honeycomb_block
setblock 31 80 332 minecraft:light[level=12]
setblock 31 80 339 minecraft:light[level=12]
setblock 31 80 346 minecraft:light[level=12]
setblock 31 80 353 minecraft:light[level=12]
setblock 31 80 360 minecraft:light[level=12]
setblock 32 80 324 minecraft:yellow_terracotta
fill 32 80 325 32 83 325 minecraft:honeycomb_block
fill 32 80 340 32 82 340 minecraft:yellow_terracotta
setblock 33 80 323 minecraft:yellow_terracotta
fill 33 80 324 33 83 324 minecraft:honeycomb_block
setblock 33 80 363 minecraft:yellow_terracotta
fill 34 80 323 34 83 323 minecraft:honeycomb_block
setblock 34 80 346 minecraft:flowering_azalea_leaves[persistent=true]
setblock 34 80 362 minecraft:yellow_terracotta
fill 34 80 363 34 83 363 minecraft:honeycomb_block
setblock 35 80 326 minecraft:yellow_terracotta
setblock 35 80 333 minecraft:light[level=15]
setblock 35 80 341 minecraft:light[level=15]
setblock 35 80 343 minecraft:flowering_azalea_leaves[persistent=true]
fill 35 80 347 36 80 347 minecraft:flowering_azalea_leaves[persistent=true]
setblock 35 80 349 minecraft:light[level=15]
setblock 35 80 357 minecraft:light[level=15]
setblock 35 80 361 minecraft:yellow_terracotta
fill 35 80 362 35 83 362 minecraft:honeycomb_block
setblock 36 80 325 minecraft:yellow_terracotta
fill 36 80 326 36 83 326 minecraft:honeycomb_block
fill 36 80 345 36 81 345 minecraft:flowering_azalea_leaves[persistent=true]
fill 36 80 361 36 82 361 minecraft:honeycomb_block
setblock 37 80 324 minecraft:yellow_terracotta
fill 37 80 325 37 83 325 minecraft:honeycomb_block
setblock 37 80 343 minecraft:flowering_azalea_leaves[persistent=true]
setblock 38 80 323 minecraft:yellow_terracotta
fill 38 80 324 38 83 324 minecraft:honeycomb_block
setblock 38 80 332 minecraft:light[level=12]
setblock 38 80 339 minecraft:light[level=12]
setblock 38 80 345 minecraft:flowering_azalea_leaves[persistent=true]
setblock 38 80 346 minecraft:light[level=12]
setblock 38 80 353 minecraft:light[level=12]
setblock 38 80 360 minecraft:light[level=12]
setblock 38 80 363 minecraft:yellow_terracotta
fill 39 80 323 39 83 323 minecraft:honeycomb_block
setblock 39 80 362 minecraft:yellow_terracotta
fill 39 80 363 39 83 363 minecraft:honeycomb_block
setblock 40 80 326 minecraft:yellow_terracotta
fill 40 80 327 40 82 327 minecraft:honeycomb_block
setblock 40 80 361 minecraft:yellow_terracotta
fill 40 80 362 40 83 362 minecraft:honeycomb_block
setblock 41 80 325 minecraft:yellow_terracotta
fill 41 80 326 41 83 326 minecraft:honeycomb_block
setblock 41 80 339 minecraft:honey_block
setblock 41 80 341 minecraft:honeycomb_block
setblock 41 80 344 minecraft:honeycomb_block
setblock 41 80 345 minecraft:yellow_terracotta
fill 41 80 346 41 83 346 minecraft:honeycomb_block
fill 41 80 348 41 81 348 minecraft:honeycomb_block
setblock 41 80 360 minecraft:yellow_terracotta
fill 41 80 361 41 83 361 minecraft:honeycomb_block
fill 0 81 333 0 183 333 minecraft:honeycomb_block
setblock 1 81 324 minecraft:yellow_terracotta
fill 1 81 325 1 83 325 minecraft:honeycomb_block
setblock 1 81 328 minecraft:honey_block
setblock 1 81 344 minecraft:yellow_terracotta
fill 1 81 345 1 81 348 minecraft:honeycomb_block
setblock 1 81 349 minecraft:yellow_terracotta
fill 1 81 350 1 84 350 minecraft:honeycomb_block
setblock 1 81 354 minecraft:yellow_terracotta
fill 1 81 355 1 82 355 minecraft:honeycomb_block
setblock 1 81 359 minecraft:yellow_terracotta
fill 1 81 360 1 83 360 minecraft:honeycomb_block
setblock 2 81 323 minecraft:yellow_terracotta
setblock 2 81 343 minecraft:yellow_terracotta
fill 2 81 344 2 82 344 minecraft:honeycomb_block
setblock 2 81 347 minecraft:honeycomb_block
setblock 2 81 348 minecraft:yellow_terracotta
fill 2 81 349 2 84 349 minecraft:honeycomb_block
setblock 2 81 363 minecraft:yellow_terracotta
fill 3 81 323 6 81 323 minecraft:honeycomb_block
setblock 3 81 362 minecraft:yellow_terracotta
fill 3 81 363 3 83 363 minecraft:honeycomb_block
setblock 4 81 362 minecraft:honeycomb_block
setblock 7 81 323 minecraft:yellow_terracotta
setblock 7 81 363 minecraft:yellow_terracotta
fill 8 81 323 10 81 324 minecraft:honeycomb_block
setblock 8 81 362 minecraft:yellow_terracotta
fill 8 81 363 8 84 363 minecraft:honeycomb_block
setblock 9 81 322 minecraft:yellow_terracotta
fill 9 81 362 9 83 362 minecraft:honeycomb_block
setblock 11 81 323 minecraft:honeycomb_block
setblock 11 81 324 minecraft:yellow_terracotta
setblock 12 81 323 minecraft:yellow_terracotta
fill 12 81 324 12 83 325 minecraft:honeycomb_block
fill 12 81 355 13 82 355 minecraft:honey_block
setblock 12 81 363 minecraft:yellow_terracotta
fill 13 81 323 13 84 323 minecraft:honeycomb_block
fill 13 81 325 14 81 325 minecraft:honeycomb_block
setblock 13 81 362 minecraft:yellow_terracotta
fill 13 81 363 13 84 363 minecraft:honeycomb_block
fill 14 81 362 14 82 362 minecraft:honeycomb_block
setblock 15 81 325 minecraft:yellow_terracotta
setblock 16 81 324 minecraft:yellow_terracotta
fill 16 81 325 16 82 325 minecraft:honeycomb_block
setblock 17 81 323 minecraft:yellow_terracotta
fill 17 81 324 17 84 324 minecraft:honeycomb_block
setblock 17 81 363 minecraft:yellow_terracotta
fill 18 81 323 21 81 323 minecraft:honeycomb_block
fill 18 81 363 18 82 363 minecraft:honeycomb_block
fill 19 81 324 20 81 324 minecraft:honeycomb_block
setblock 21 81 324 minecraft:yellow_terracotta
setblock 22 81 323 minecraft:yellow_terracotta
fill 22 81 324 22 83 324 minecraft:honeycomb_block
fill 23 81 323 23 84 323 minecraft:honeycomb_block
setblock 26 81 324 minecraft:yellow_terracotta
setblock 26 81 363 minecraft:honeycomb_block
setblock 27 81 323 minecraft:yellow_terracotta
fill 27 81 324 27 84 324 minecraft:honeycomb_block
setblock 27 81 363 minecraft:yellow_terracotta
fill 28 81 323 28 84 323 minecraft:honeycomb_block
fill 28 81 363 28 84 364 minecraft:honeycomb_block
setblock 29 81 326 minecraft:yellow_terracotta
fill 29 81 362 29 83 362 minecraft:honeycomb_block
setblock 30 81 324 minecraft:honeycomb_block
setblock 30 81 325 minecraft:yellow_terracotta
fill 30 81 326 30 84 326 minecraft:honeycomb_block
setblock 31 81 324 minecraft:yellow_terracotta
fill 31 81 325 31 84 325 minecraft:honeycomb_block
setblock 32 81 323 minecraft:yellow_terracotta
fill 32 81 324 32 84 324 minecraft:honeycomb_block
setblock 32 81 363 minecraft:yellow_terracotta
fill 33 81 323 33 84 323 minecraft:honeycomb_block
setblock 33 81 362 minecraft:yellow_terracotta
fill 33 81 363 33 84 363 minecraft:honeycomb_block
setblock 34 81 325 minecraft:honeycomb_block
setblock 34 81 326 minecraft:yellow_terracotta
setblock 34 81 361 minecraft:yellow_terracotta
fill 34 81 362 34 84 362 minecraft:honeycomb_block
setblock 35 81 325 minecraft:yellow_terracotta
fill 35 81 326 35 84 326 minecraft:honeycomb_block
fill 35 81 361 35 82 361 minecraft:honeycomb_block
setblock 36 81 324 minecraft:yellow_terracotta
fill 36 81 325 36 84 325 minecraft:honeycomb_block
setblock 37 81 323 minecraft:yellow_terracotta
fill 37 81 324 37 84 324 minecraft:honeycomb_block
setblock 37 81 363 minecraft:yellow_terracotta
fill 38 81 323 38 84 323 minecraft:honeycomb_block
setblock 38 81 362 minecraft:yellow_terracotta
fill 38 81 363 38 84 363 minecraft:honeycomb_block
setblock 39 81 325 minecraft:honeycomb_block
setblock 39 81 326 minecraft:yellow_terracotta
fill 39 81 362 39 83 362 minecraft:honeycomb_block
setblock 40 81 325 minecraft:yellow_terracotta
fill 40 81 326 40 83 326 minecraft:honeycomb_block
setblock 40 81 360 minecraft:yellow_terracotta
fill 40 81 361 40 82 361 minecraft:honeycomb_block
setblock 41 81 324 minecraft:yellow_terracotta
fill 41 81 325 41 84 325 minecraft:honeycomb_block
setblock 41 81 329 minecraft:yellow_terracotta
setblock 41 81 333 minecraft:honey_block
setblock 41 81 344 minecraft:yellow_terracotta
fill 41 81 345 41 83 345 minecraft:honeycomb_block
setblock 41 81 349 minecraft:yellow_terracotta
setblock 41 81 359 minecraft:yellow_terracotta
fill 41 81 360 41 83 360 minecraft:honeycomb_block
setblock 1 82 323 minecraft:yellow_terracotta
fill 1 82 324 1 83 324 minecraft:honeycomb_block
setblock 1 82 334 minecraft:honey_block
setblock 1 82 343 minecraft:yellow_terracotta
fill 1 82 344 1 82 347 minecraft:honeycomb_block
setblock 1 82 348 minecraft:yellow_terracotta
fill 1 82 349 1 85 349 minecraft:honeycomb_block
setblock 1 82 353 minecraft:yellow_terracotta
fill 1 82 354 1 83 354 minecraft:honeycomb_block
setblock 1 82 358 minecraft:yellow_terracotta
setblock 1 82 359 minecraft:honeycomb_block
setblock 1 82 362 minecraft:honeycomb_block
setblock 1 82 363 minecraft:yellow_terracotta
fill 2 82 323 5 82 323 minecraft:honeycomb_block
setblock 2 82 347 minecraft:yellow_terracotta
fill 2 82 348 2 85 348 minecraft:honeycomb_block
fill 2 82 363 2 83 363 minecraft:honeycomb_block
setblock 6 82 322 minecraft:orange_terracotta
setblock 6 82 323 minecraft:yellow_terracotta
setblock 6 82 363 minecraft:yellow_terracotta
fill 7 82 322 7 85 323 minecraft:honeycomb_block
setblock 7 82 362 minecraft:yellow_terracotta
fill 7 82 363 7 85 363 minecraft:honeycomb_block
fill 8 82 323 9 82 324 minecraft:honeycomb_block
setblock 8 82 362 minecraft:honeycomb_block
fill 9 82 322 9 92 322 minecraft:honeycomb_block
setblock 10 82 323 minecraft:honeycomb_block
setblock 10 82 324 minecraft:yellow_terracotta
setblock 11 82 323 minecraft:yellow_terracotta
fill 11 82 324 11 85 324 minecraft:honeycomb_block
setblock 11 82 363 minecraft:yellow_terracotta
fill 12 82 323 12 85 323 minecraft:honeycomb_block
setblock 12 82 362 minecraft:yellow_terracotta
fill 12 82 363 12 85 363 minecraft:honeycomb_block
setblock 13 82 325 minecraft:honeycomb_block
fill 13 82 362 13 83 362 minecraft:honeycomb_block
setblock 14 82 325 minecraft:yellow_terracotta
fill 15 82 322 15 278 322 minecraft:honeycomb_block
setblock 15 82 324 minecraft:yellow_terracotta
fill 15 82 325 15 83 325 minecraft:honeycomb_block
setblock 16 82 322 minecraft:orange_terracotta
setblock 16 82 323 minecraft:yellow_terracotta
fill 16 82 324 16 84 324 minecraft:honeycomb_block
setblock 16 82 363 minecraft:yellow_terracotta
fill 17 82 322 17 85 323 minecraft:honeycomb_block
fill 17 82 363 17 83 363 minecraft:honeycomb_block
fill 18 82 323 20 82 323 minecraft:honeycomb_block
setblock 19 82 324 minecraft:honeycomb_block
setblock 20 82 324 minecraft:yellow_terracotta
setblock 21 82 323 minecraft:yellow_terracotta
fill 21 82 324 21 83 324 minecraft:honeycomb_block
fill 22 82 323 22 85 323 minecraft:honeycomb_block
setblock 25 82 323 minecraft:honeycomb_block
setblock 25 82 324 minecraft:yellow_terracotta
setblock 26 82 323 minecraft:yellow_terracotta
fill 26 82 324 26 84 325 minecraft:honeycomb_block
setblock 26 82 363 minecraft:yellow_terracotta
fill 27 82 323 27 85 323 minecraft:honeycomb_block
fill 27 82 363 27 85 363 minecraft:honeycomb_block
setblock 29 82 324 minecraft:honeycomb_block
setblock 29 82 325 minecraft:yellow_terracotta
fill 29 82 326 29 85 326 minecraft:honeycomb_block
setblock 30 82 324 minecraft:yellow_terracotta
fill 30 82 325 30 85 325 minecraft:honeycomb_block
setblock 31 82 323 minecraft:yellow_terracotta
fill 31 82 324 31 85 324 minecraft:honeycomb_block
setblock 31 82 363 minecraft:yellow_terracotta
fill 32 82 323 32 85 323 minecraft:honeycomb_block
setblock 32 82 326 minecraft:honeycomb_block
setblock 32 82 362 minecraft:yellow_terracotta
fill 32 82 363 32 85 363 minecraft:honeycomb_block
setblock 33 82 326 minecraft:yellow_terracotta
setblock 33 82 361 minecraft:yellow_terracotta
fill 33 82 362 33 85 362 minecraft:honeycomb_block
setblock 34 82 325 minecraft:yellow_terracotta
fill 34 82 326 34 85 326 minecraft:honeycomb_block
setblock 34 82 361 minecraft:honeycomb_block
setblock 35 82 324 minecraft:yellow_terracotta
fill 35 82 325 35 85 325 minecraft:honeycomb_block
setblock 36 82 323 minecraft:yellow_terracotta
fill 36 82 324 36 85 324 minecraft:honeycomb_block
setblock 36 82 363 minecraft:yellow_terracotta
fill 37 82 323 37 85 323 minecraft:honeycomb_block
setblock 37 82 362 minecraft:yellow_terracotta
fill 37 82 363 37 85 363 minecraft:honeycomb_block
fill 38 82 362 38 83 362 minecraft:honeycomb_block
setblock 39 82 325 minecraft:yellow_terracotta
setblock 39 82 326 minecraft:honeycomb_block
setblock 40 82 324 minecraft:yellow_terracotta
fill 40 82 325 40 84 325 minecraft:honeycomb_block
setblock 41 82 323 minecraft:yellow_terracotta
fill 41 82 324 41 85 324 minecraft:honeycomb_block
setblock 41 82 328 minecraft:yellow_terracotta
setblock 41 82 343 minecraft:yellow_terracotta
setblock 41 82 344 minecraft:honeycomb_block
setblock 41 82 348 minecraft:yellow_terracotta
fill 41 82 349 41 85 349 minecraft:honeycomb_block
setblock 41 82 352 minecraft:honey_block
setblock 41 82 359 minecraft:honeycomb_block
setblock 41 82 363 minecraft:yellow_terracotta
fill 0 83 348 1 86 348 minecraft:honeycomb_block
setblock 0 83 349 minecraft:yellow_concrete
fill 1 83 323 4 83 323 minecraft:honeycomb_block
setblock 1 83 340 minecraft:honey_block
setblock 1 83 342 minecraft:yellow_terracotta
fill 1 83 343 1 83 346 minecraft:honeycomb_block
setblock 1 83 347 minecraft:yellow_terracotta
setblock 1 83 352 minecraft:yellow_terracotta
fill 1 83 353 1 86 353 minecraft:honeycomb_block
setblock 1 83 362 minecraft:yellow_terracotta
fill 1 83 363 1 84 363 minecraft:honeycomb_block
setblock 2 83 346 minecraft:yellow_terracotta
fill 2 83 347 2 86 347 minecraft:honeycomb_block
setblock 2 83 350 minecraft:honeycomb_block
setblock 5 83 323 minecraft:yellow_terracotta
setblock 5 83 363 minecraft:yellow_terracotta
fill 6 83 322 6 85 323 minecraft:honeycomb_block
fill 6 83 363 6 84 363 minecraft:honeycomb_block
fill 8 83 323 8 83 324 minecraft:honeycomb_block
setblock 9 83 323 minecraft:honeycomb_block
setblock 9 83 324 minecraft:yellow_terracotta
setblock 10 83 323 minecraft:yellow_terracotta
fill 10 83 324 10 86 324 minecraft:honeycomb_block
setblock 10 83 363 minecraft:yellow_terracotta
fill 11 83 323 11 86 323 minecraft:honeycomb_block
setblock 11 83 362 minecraft:yellow_terracotta
fill 11 83 363 11 85 363 minecraft:honeycomb_block
setblock 12 83 362 minecraft:honeycomb_block
setblock 13 83 325 minecraft:yellow_terracotta
setblock 14 83 322 minecraft:yellow_concrete
setblock 14 83 324 minecraft:yellow_terracotta
setblock 14 83 325 minecraft:honeycomb_block
setblock 15 83 323 minecraft:yellow_terracotta
fill 15 83 324 15 85 324 minecraft:honeycomb_block
setblock 15 83 363 minecraft:yellow_terracotta
fill 16 83 322 16 86 323 minecraft:honeycomb_block
fill 16 83 327 16 88 327 minecraft:brown_terracotta
setblock 16 83 363 minecraft:honeycomb_block
fill 18 83 323 19 83 323 minecraft:honeycomb_block
setblock 19 83 324 minecraft:yellow_terracotta
setblock 20 83 323 minecraft:yellow_terracotta
setblock 20 83 324 minecraft:honeycomb_block
fill 21 83 323 21 85 323 minecraft:honeycomb_block
setblock 22 83 363 minecraft:honey_block
setblock 23 83 324 minecraft:honeycomb_block
setblock 24 83 324 minecraft:yellow_terracotta
setblock 25 83 323 minecraft:yellow_terracotta
fill 25 83 324 25 86 324 minecraft:honeycomb_block
fill 26 83 323 26 86 323 minecraft:honeycomb_block
fill 26 83 363 26 84 363 minecraft:honeycomb_block
setblock 27 83 325 minecraft:honeycomb_block
setblock 28 83 325 minecraft:yellow_terracotta
fill 28 83 326 28 86 326 minecraft:honeycomb_block
setblock 29 83 324 minecraft:yellow_terracotta
fill 29 83 325 29 86 325 minecraft:honeycomb_block
setblock 30 83 323 minecraft:yellow_terracotta
fill 30 83 324 30 86 324 minecraft:honeycomb_block
fill 30 83 340 33 85 341 minecraft:flowering_azalea_leaves[persistent=true]
setblock 30 83 363 minecraft:yellow_terracotta
fill 31 83 323 31 86 323 minecraft:honeycomb_block
fill 31 83 339 33 85 339 minecraft:flowering_azalea_leaves[persistent=true]
fill 31 83 342 33 85 342 minecraft:flowering_azalea_leaves[persistent=true]
setblock 31 83 362 minecraft:yellow_terracotta
fill 31 83 363 31 86 363 minecraft:honeycomb_block
setblock 32 83 326 minecraft:yellow_terracotta
fill 32 83 362 32 86 362 minecraft:honeycomb_block
setblock 33 83 325 minecraft:yellow_terracotta
fill 33 83 326 33 85 326 minecraft:honeycomb_block
setblock 34 83 324 minecraft:yellow_terracotta
fill 34 83 325 34 86 325 minecraft:honeycomb_block
setblock 35 83 323 minecraft:yellow_terracotta
fill 35 83 324 35 86 324 minecraft:honeycomb_block
setblock 35 83 363 minecraft:yellow_terracotta
fill 36 83 323 36 86 323 minecraft:honeycomb_block
setblock 36 83 362 minecraft:yellow_terracotta
fill 36 83 363 36 86 363 minecraft:honeycomb_block
fill 37 83 362 37 84 362 minecraft:honeycomb_block
setblock 38 83 325 minecraft:yellow_terracotta
setblock 39 83 324 minecraft:yellow_terracotta
setblock 40 83 323 minecraft:yellow_terracotta
fill 40 83 324 40 84 324 minecraft:honeycomb_block
setblock 40 83 363 minecraft:yellow_terracotta
fill 41 83 323 41 86 323 minecraft:honeycomb_block
setblock 41 83 327 minecraft:yellow_terracotta
fill 41 83 328 41 84 328 minecraft:honeycomb_block
setblock 41 83 347 minecraft:yellow_terracotta
fill 41 83 348 41 85 348 minecraft:honeycomb_block
fill 41 83 350 41 84 350 minecraft:honeycomb_block
setblock 41 83 362 minecraft:yellow_terracotta
fill 41 83 363 41 85 363 minecraft:honeycomb_block
fill 0 84 349 0 105 349 minecraft:honeycomb_block
setblock 1 84 327 minecraft:honey_block
fill 1 84 343 1 84 345 minecraft:honeycomb_block
setblock 1 84 346 minecraft:yellow_terracotta
fill 1 84 347 1 87 347 minecraft:honeycomb_block
setblock 1 84 351 minecraft:yellow_terracotta
fill 1 84 352 1 87 352 minecraft:honeycomb_block
setblock 2 84 345 minecraft:yellow_terracotta
fill 2 84 346 2 85 346 minecraft:honeycomb_block
setblock 2 84 350 minecraft:yellow_terracotta
setblock 5 84 323 minecraft:honeycomb_block
setblock 5 84 363 minecraft:honeycomb_block
setblock 8 84 323 minecraft:honeycomb_block
setblock 8 84 324 minecraft:yellow_terracotta
setblock 9 84 323 minecraft:yellow_terracotta
fill 9 84 324 9 86 324 minecraft:honeycomb_block
setblock 9 84 363 minecraft:yellow_terracotta
fill 10 84 323 10 87 323 minecraft:honeycomb_block
fill 10 84 363 10 86 363 minecraft:honeycomb_block
setblock 12 84 324 minecraft:honeycomb_block
setblock 13 84 324 minecraft:yellow_terracotta
fill 14 84 322 14 217 322 minecraft:honeycomb_block
setblock 14 84 323 minecraft:yellow_terracotta
fill 14 84 324 14 85 324 minecraft:honeycomb_block
setblock 14 84 363 minecraft:yellow_terracotta
fill 15 84 323 15 86 323 minecraft:honeycomb_block
setblock 15 84 363 minecraft:honeycomb_block
setblock 18 84 323 minecraft:honeycomb_block
setblock 19 84 323 minecraft:yellow_terracotta
fill 20 84 323 20 85 323 minecraft:honeycomb_block
setblock 23 84 324 minecraft:yellow_terracotta
setblock 24 84 323 minecraft:yellow_terracotta
fill 24 84 324 24 87 324 minecraft:honeycomb_block
fill 25 84 323 25 87 323 minecraft:honeycomb_block
setblock 27 84 325 minecraft:yellow_terracotta
setblock 28 84 324 minecraft:yellow_terracotta
fill 28 84 325 28 87 325 minecraft:honeycomb_block
setblock 29 84 323 minecraft:yellow_terracotta
fill 29 84 324 29 87 324 minecraft:honeycomb_block
setblock 29 84 363 minecraft:yellow_terracotta
fill 30 84 323 30 87 323 minecraft:honeycomb_block
setblock 30 84 339 minecraft:flowering_azalea_leaves[persistent=true]
setblock 30 84 362 minecraft:yellow_terracotta
fill 30 84 363 30 87 363 minecraft:honeycomb_block
setblock 31 84 326 minecraft:yellow_terracotta
fill 31 84 362 31 85 362 minecraft:honeycomb_block
setblock 32 84 325 minecraft:yellow_terracotta
fill 32 84 326 32 86 326 minecraft:honeycomb_block
setblock 32 84 338 minecraft:flowering_azalea_leaves[persistent=true]
setblock 33 84 324 minecraft:yellow_terracotta
fill 33 84 325 33 87 325 minecraft:honeycomb_block
setblock 34 84 323 minecraft:yellow_terracotta
fill 34 84 324 34 87 324 minecraft:honeycomb_block
fill 34 84 340 34 84 341 minecraft:flowering_azalea_leaves[persistent=true]
setblock 34 84 363 minecraft:yellow_terracotta
fill 35 84 323 35 87 323 minecraft:honeycomb_block
setblock 35 84 362 minecraft:yellow_terracotta
fill 35 84 363 35 87 363 minecraft:honeycomb_block
setblock 36 84 362 minecraft:honeycomb_block
setblock 37 84 325 minecraft:yellow_terracotta
setblock 38 84 324 minecraft:yellow_terracotta
setblock 39 84 323 minecraft:yellow_terracotta
fill 39 84 324 39 85 324 minecraft:honeycomb_block
setblock 39 84 363 minecraft:yellow_terracotta
fill 40 84 323 40 86 323 minecraft:honeycomb_block
fill 40 84 363 40 85 363 minecraft:honeycomb_block
setblock 41 84 326 minecraft:yellow_terracotta
fill 41 84 327 41 85 327 minecraft:honeycomb_block
setblock 41 84 340 minecraft:honey_block
setblock 41 84 347 minecraft:honeycomb_block
setblock 41 84 359 minecraft:honey_block
setblock 41 84 361 minecraft:yellow_terracotta
setblock 41 84 362 minecraft:honeycomb_block
setblock 42 84 333 minecraft:orange_terracotta
setblock 1 85 333 minecraft:honey_block
setblock 1 85 344 minecraft:honeycomb_block
setblock 1 85 345 minecraft:yellow_terracotta
fill 1 85 346 1 88 346 minecraft:honeycomb_block
setblock 1 85 350 minecraft:yellow_terracotta
fill 1 85 351 1 88 351 minecraft:honeycomb_block
setblock 2 85 323 minecraft:honey_block
setblock 2 85 349 minecraft:yellow_terracotta
fill 2 85 350 2 88 350 minecraft:honeycomb_block
setblock 8 85 323 minecraft:yellow_terracotta
setblock 8 85 363 minecraft:yellow_terracotta
fill 9 85 323 9 88 323 minecraft:honeycomb_block
fill 9 85 363 9 86 363 minecraft:honeycomb_block
setblock 12 85 324 minecraft:yellow_terracotta
setblock 13 85 323 minecraft:yellow_terracotta
fill 13 85 324 13 86 324 minecraft:honeycomb_block
setblock 13 85 363 minecraft:yellow_terracotta
fill 14 85 323 14 87 323 minecraft:honeycomb_block
setblock 15 85 363 minecraft:honey_block
setblock 18 85 323 minecraft:yellow_terracotta
setblock 19 85 323 minecraft:honeycomb_block
setblock 23 85 323 minecraft:yellow_terracotta
setblock 23 85 324 minecraft:honeycomb_block
fill 24 85 323 24 88 323 minecraft:honeycomb_block
setblock 26 85 324 minecraft:honeycomb_block
setblock 26 85 325 minecraft:yellow_terracotta
setblock 27 85 324 minecraft:yellow_terracotta
fill 27 85 325 27 88 325 minecraft:honeycomb_block
setblock 28 85 323 minecraft:yellow_terracotta
fill 28 85 324 28 88 324 minecraft:honeycomb_block
setblock 28 85 363 minecraft:yellow_terracotta
fill 28 85 364 28 155 364 minecraft:honeycomb_block
fill 29 85 323 29 88 323 minecraft:honeycomb_block
fill 29 85 363 29 88 363 minecraft:honeycomb_block
setblock 30 85 326 minecraft:yellow_terracotta
setblock 30 85 362 minecraft:honeycomb_block
setblock 31 85 325 minecraft:yellow_terracotta
fill 31 85 326 31 87 326 minecraft:honeycomb_block
setblock 32 85 324 minecraft:yellow_terracotta
fill 32 85 325 32 88 325 minecraft:honeycomb_block
setblock 33 85 323 minecraft:yellow_terracotta
fill 33 85 324 33 88 324 minecraft:honeycomb_block
setblock 33 85 363 minecraft:yellow_terracotta
fill 34 85 323 34 88 323 minecraft:honeycomb_block
setblock 34 85 362 minecraft:yellow_terracotta
fill 34 85 363 34 88 363 minecraft:honeycomb_block
setblock 35 85 362 minecraft:honeycomb_block
setblock 36 85 325 minecraft:yellow_terracotta
setblock 37 85 324 minecraft:yellow_terracotta
setblock 38 85 323 minecraft:yellow_terracotta
setblock 38 85 324 minecraft:honeycomb_block
setblock 38 85 363 minecraft:yellow_terracotta
fill 39 85 323 39 86 323 minecraft:honeycomb_block
setblock 39 85 363 minecraft:honeycomb_block
setblock 41 85 325 minecraft:yellow_terracotta
fill 41 85 326 41 86 326 minecraft:honeycomb_block
fill 41 85 328 41 86 328 minecraft:honey_block
setblock 41 85 334 minecraft:honey_block
setblock 41 85 350 minecraft:yellow_terracotta
setblock 41 85 353 minecraft:honey_block
fill 42 85 333 42 144 333 minecraft:honeycomb_block
setblock 1 86 339 minecraft:honey_block
fill 1 86 345 1 89 345 minecraft:honeycomb_block
setblock 1 86 349 minecraft:yellow_terracotta
fill 1 86 350 1 89 350 minecraft:honeycomb_block
setblock 1 86 354 minecraft:yellow_terracotta
setblock 1 86 358 minecraft:honey_block
setblock 2 86 348 minecraft:yellow_terracotta
fill 2 86 349 2 89 349 minecraft:honeycomb_block
fill 2 86 351 2 87 351 minecraft:honeycomb_block
setblock 3 86 325 minecraft:light[level=12]
setblock 3 86 332 minecraft:light[level=12]
setblock 3 86 339 minecraft:light[level=12]
setblock 3 86 346 minecraft:light[level=12]
setblock 3 86 353 minecraft:light[level=12]
setblock 3 86 360 minecraft:light[level=12]
fill 6 86 322 7 124 322 minecraft:honeycomb_block
setblock 7 86 323 minecraft:yellow_terracotta
fill 8 86 323 8 89 323 minecraft:honeycomb_block
setblock 10 86 325 minecraft:light[level=12]
setblock 10 86 332 minecraft:light[level=12]
setblock 10 86 339 minecraft:light[level=12]
setblock 10 86 346 minecraft:light[level=12]
setblock 10 86 353 minecraft:light[level=12]
setblock 10 86 360 minecraft:light[level=12]
setblock 11 86 324 minecraft:yellow_terracotta
setblock 12 86 323 minecraft:yellow_terracotta
setblock 12 86 324 minecraft:honeycomb_block
fill 13 86 323 13 88 323 minecraft:honeycomb_block
fill 15 86 327 15 88 327 minecraft:brown_terracotta
fill 16 86 326 16 88 326 minecraft:brown_terracotta
fill 16 86 328 16 88 328 minecraft:brown_terracotta
fill 17 86 322 17 141 322 minecraft:honeycomb_block
setblock 17 86 323 minecraft:yellow_terracotta
setblock 17 86 325 minecraft:light[level=12]
fill 17 86 327 17 88 327 minecraft:brown_terracotta
setblock 17 86 332 minecraft:light[level=12]
setblock 17 86 339 minecraft:light[level=12]
setblock 17 86 346 minecraft:light[level=12]
setblock 17 86 353 minecraft:light[level=12]
setblock 17 86 360 minecraft:light[level=12]
setblock 21 86 323 minecraft:honey_block
setblock 21 86 363 minecraft:honey_block
setblock 22 86 323 minecraft:yellow_terracotta
fill 23 86 323 23 89 323 minecraft:honeycomb_block
setblock 24 86 325 minecraft:light[level=12]
setblock 24 86 332 minecraft:light[level=12]
setblock 24 86 339 minecraft:light[level=12]
setblock 24 86 346 minecraft:light[level=12]
setblock 24 86 353 minecraft:light[level=12]
setblock 24 86 360 minecraft:light[level=12]
setblock 26 86 324 minecraft:yellow_terracotta
fill 26 86 325 26 89 325 minecraft:honeycomb_block
setblock 27 86 323 minecraft:yellow_terracotta
fill 27 86 324 27 89 324 minecraft:honeycomb_block
setblock 27 86 363 minecraft:yellow_terracotta
fill 28 86 323 28 89 323 minecraft:honeycomb_block
fill 28 86 363 28 89 363 minecraft:honeycomb_block
setblock 29 86 326 minecraft:yellow_terracotta
setblock 30 86 325 minecraft:yellow_terracotta
fill 30 86 326 30 88 326 minecraft:honeycomb_block
setblock 31 86 324 minecraft:yellow_terracotta
fill 31 86 325 31 89 325 minecraft:honeycomb_block
setblock 31 86 332 minecraft:light[level=12]
setblock 31 86 339 minecraft:light[level=12]
setblock 31 86 346 minecraft:light[level=12]
setblock 31 86 353 minecraft:light[level=12]
setblock 31 86 360 minecraft:light[level=12]
setblock 32 86 323 minecraft:yellow_terracotta
fill 32 86 324 32 89 324 minecraft:honeycomb_block
setblock 32 86 363 minecraft:yellow_terracotta
fill 33 86 323 33 89 323 minecraft:honeycomb_block
fill 33 86 363 33 89 363 minecraft:honeycomb_block
setblock 35 86 325 minecraft:yellow_terracotta
setblock 36 86 324 minecraft:yellow_terracotta
setblock 37 86 323 minecraft:yellow_terracotta
setblock 37 86 324 minecraft:honeycomb_block
setblock 37 86 363 minecraft:yellow_terracotta
fill 38 86 323 38 87 323 minecraft:honeycomb_block
setblock 38 86 325 minecraft:light[level=12]
setblock 38 86 332 minecraft:light[level=12]
setblock 38 86 339 minecraft:light[level=12]
setblock 38 86 346 minecraft:light[level=12]
setblock 38 86 353 minecraft:light[level=12]
setblock 38 86 360 minecraft:light[level=12]
setblock 38 86 363 minecraft:honeycomb_block
setblock 40 86 363 minecraft:honey_block
setblock 41 86 324 minecraft:yellow_terracotta
setblock 41 86 325 minecraft:honeycomb_block
setblock 41 86 347 minecraft:honey_block
setblock 41 86 349 minecraft:yellow_terracotta
fill 41 86 350 41 88 351 minecraft:honeycomb_block
fill 42 86 329 42 275 329 minecraft:honeycomb_block
setblock 42 86 330 minecraft:orange_terracotta
fill 42 86 331 42 308 331 minecraft:honeycomb_block
setblock 42 86 342 minecraft:yellow_concrete
fill 0 87 348 0 195 348 minecraft:honeycomb_block
setblock 1 87 348 minecraft:yellow_terracotta
fill 1 87 349 1 90 349 minecraft:honeycomb_block
setblock 1 87 353 minecraft:yellow_terracotta
fill 1 87 354 1 90 354 minecraft:honeycomb_block
setblock 2 87 347 minecraft:yellow_terracotta
fill 2 87 348 2 90 348 minecraft:honeycomb_block
setblock 2 87 363 minecraft:honey_block
fill 7 87 323 7 88 323 minecraft:honeycomb_block
fill 8 87 363 8 88 363 minecraft:honey_block
setblock 11 87 323 minecraft:yellow_terracotta
fill 12 87 323 12 89 323 minecraft:honeycomb_block
setblock 15 87 323 minecraft:honey_block
fill 16 87 322 16 224 322 minecraft:honeycomb_block
fill 22 87 323 22 90 323 minecraft:honeycomb_block
setblock 25 87 324 minecraft:yellow_terracotta
setblock 26 87 323 minecraft:yellow_terracotta
fill 26 87 324 26 90 324 minecraft:honeycomb_block
fill 27 87 323 27 90 323 minecraft:honeycomb_block
fill 27 87 363 27 90 363 minecraft:honeycomb_block
setblock 28 87 326 minecraft:yellow_terracotta
setblock 29 87 325 minecraft:yellow_terracotta
fill 29 87 326 29 90 326 minecraft:honeycomb_block
setblock 30 87 324 minecraft:yellow_terracotta
fill 30 87 325 30 90 325 minecraft:honeycomb_block
setblock 31 87 323 minecraft:yellow_terracotta
fill 31 87 324 31 90 324 minecraft:honeycomb_block
setblock 31 87 363 minecraft:yellow_terracotta
fill 32 87 323 32 90 323 minecraft:honeycomb_block
fill 32 87 363 32 90 363 minecraft:honeycomb_block
setblock 34 87 325 minecraft:yellow_terracotta
setblock 35 87 324 minecraft:yellow_terracotta
setblock 36 87 323 minecraft:yellow_terracotta
setblock 36 87 324 minecraft:honeycomb_block
setblock 36 87 363 minecraft:yellow_terracotta
fill 37 87 323 37 88 323 minecraft:honeycomb_block
setblock 41 87 341 minecraft:honey_block
fill 41 87 349 41 90 349 minecraft:honeycomb_block
setblock 41 87 352 minecraft:honeycomb_block
setblock 41 87 360 minecraft:honey_block
fill 42 87 330 42 100 330 minecraft:honeycomb_block
setblock 42 87 341 minecraft:yellow_concrete
fill 42 87 342 42 229 342 minecraft:honeycomb_block
setblock 0 88 334 minecraft:orange_terracotta
setblock 1 88 326 minecraft:honey_block
fill 1 88 332 1 89 332 minecraft:honey_block
setblock 1 88 347 minecraft:yellow_terracotta
fill 1 88 348 1 91 348 minecraft:honeycomb_block
setblock 1 88 352 minecraft:yellow_terracotta
fill 1 88 353 1 91 353 minecraft:honeycomb_block
fill 1 88 355 1 89 355 minecraft:honeycomb_block
fill 2 88 347 2 91 347 minecraft:honeycomb_block
setblock 2 88 351 minecraft:yellow_terracotta
fill 2 88 352 2 91 352 minecraft:honeycomb_block
setblock 3 88 325 minecraft:light[level=15]
setblock 3 88 333 minecraft:light[level=15]
setblock 3 88 341 minecraft:light[level=15]
setblock 3 88 349 minecraft:light[level=15]
setblock 3 88 357 minecraft:light[level=15]
setblock 10 88 323 minecraft:yellow_terracotta
fill 11 88 323 11 90 323 minecraft:honeycomb_block
setblock 11 88 325 minecraft:light[level=15]
setblock 11 88 333 minecraft:light[level=15]
setblock 11 88 341 minecraft:light[level=15]
setblock 11 88 349 minecraft:light[level=15]
setblock 11 88 357 minecraft:light[level=15]
setblock 14 88 363 minecraft:honey_block
setblock 15 88 326 minecraft:brown_terracotta
setblock 15 88 328 minecraft:brown_terracotta
setblock 17 88 326 minecraft:brown_terracotta
setblock 17 88 328 minecraft:brown_terracotta
setblock 19 88 325 minecraft:light[level=15]
setblock 19 88 333 minecraft:light[level=15]
setblock 19 88 341 minecraft:light[level=15]
setblock 19 88 349 minecraft:light[level=15]
setblock 19 88 357 minecraft:light[level=15]
setblock 24 88 324 minecraft:yellow_terracotta
setblock 25 88 323 minecraft:yellow_terracotta
fill 25 88 324 25 90 325 minecraft:honeycomb_block
fill 26 88 323 26 91 323 minecraft:honeycomb_block
setblock 27 88 333 minecraft:light[level=15]
setblock 27 88 341 minecraft:light[level=15]
setblock 27 88 349 minecraft:light[level=15]
setblock 27 88 357 minecraft:light[level=15]
setblock 28 88 325 minecraft:yellow_terracotta
fill 28 88 326 28 91 326 minecraft:honeycomb_block
setblock 29 88 324 minecraft:yellow_terracotta
fill 29 88 325 29 91 325 minecraft:honeycomb_block
setblock 30 88 323 minecraft:yellow_terracotta
fill 30 88 324 30 91 324 minecraft:honeycomb_block
setblock 30 88 363 minecraft:yellow_terracotta
fill 31 88 323 31 91 323 minecraft:honeycomb_block
fill 31 88 363 31 91 363 minecraft:honeycomb_block
setblock 33 88 325 minecraft:yellow_terracotta
setblock 34 88 324 minecraft:yellow_terracotta
setblock 35 88 323 minecraft:yellow_terracotta
setblock 35 88 324 minecraft:honeycomb_block
setblock 35 88 325 minecraft:light[level=15]
setblock 35 88 333 minecraft:light[level=15]
setblock 35 88 341 minecraft:light[level=15]
setblock 35 88 349 minecraft:light[level=15]
setblock 35 88 357 minecraft:light[level=15]
setblock 35 88 363 minecraft:yellow_terracotta
fill 36 88 323 36 89 323 minecraft:honeycomb_block
setblock 41 88 335 minecraft:honey_block
fill 41 88 348 41 91 348 minecraft:honeycomb_block
setblock 41 88 352 minecraft:yellow_terracotta
fill 41 88 353 41 90 354 minecraft:honeycomb_block
setblock 42 88 336 minecraft:yellow_terracotta
fill 42 88 337 42 101 337 minecraft:honeycomb_block
fill 42 88 341 42 130 341 minecraft:honeycomb_block
setblock 42 88 351 minecraft:orange_terracotta
fill 0 89 334 0 308 334 minecraft:honeycomb_block
setblock 1 89 338 minecraft:honey_block
setblock 1 89 346 minecraft:yellow_terracotta
fill 1 89 347 1 92 347 minecraft:honeycomb_block
setblock 1 89 351 minecraft:yellow_terracotta
fill 1 89 352 1 92 352 minecraft:honeycomb_block
setblock 1 89 356 minecraft:yellow_terracotta
setblock 1 89 357 minecraft:honey_block
setblock 2 89 350 minecraft:yellow_terracotta
fill 2 89 351 3 91 351 minecraft:honeycomb_block
fill 2 89 353 2 89 354 minecraft:honeycomb_block
setblock 3 89 323 minecraft:honey_block
setblock 3 89 349 minecraft:yellow_terracotta
fill 3 89 350 3 92 350 minecraft:honeycomb_block
setblock 9 89 323 minecraft:yellow_terracotta
fill 10 89 323 10 92 323 minecraft:honeycomb_block
setblock 20 89 363 minecraft:honey_block
setblock 24 89 323 minecraft:yellow_terracotta
fill 24 89 324 24 92 324 minecraft:honeycomb_block
fill 25 89 322 25 92 323 minecraft:honeycomb_block
fill 26 89 322 29 92 322 minecraft:honeycomb_block
setblock 27 89 325 minecraft:yellow_terracotta
setblock 28 89 324 minecraft:yellow_terracotta
fill 28 89 325 28 92 325 minecraft:honeycomb_block
setblock 29 89 323 minecraft:yellow_terracotta
fill 29 89 324 29 92 324 minecraft:honeycomb_block
setblock 29 89 363 minecraft:yellow_terracotta
setblock 30 89 322 minecraft:yellow_terracotta
fill 30 89 323 30 92 323 minecraft:honeycomb_block
fill 30 89 363 30 92 363 minecraft:honeycomb_block
fill 31 89 322 31 138 322 minecraft:honeycomb_block
setblock 32 89 325 minecraft:yellow_terracotta
setblock 33 89 324 minecraft:yellow_terracotta
setblock 34 89 323 minecraft:yellow_terracotta
setblock 34 89 324 minecraft:honeycomb_block
setblock 34 89 363 minecraft:yellow_terracotta
fill 35 89 323 35 91 323 minecraft:honeycomb_block
setblock 39 89 363 minecraft:honey_block
setblock 41 89 329 minecraft:honey_block
setblock 41 89 350 minecraft:honeycomb_block
setblock 41 89 351 minecraft:yellow_terracotta
fill 41 89 352 41 92 352 minecraft:honeycomb_block
setblock 41 89 355 minecraft:honeycomb_block
setblock 41 89 356 minecraft:yellow_terracotta
fill 42 89 336 42 273 336 minecraft:honeycomb_block
fill 42 89 351 42 132 351 minecraft:honeycomb_block
setblock 42 89 362 minecraft:yellow_concrete
fill 42 89 363 42 97 363 minecraft:honeycomb_block
fill 0 90 359 0 121 360 minecraft:honeycomb_block
setblock 0 90 361 minecraft:orange_terracotta
setblock 1 90 344 minecraft:honey_block
setblock 1 90 345 minecraft:yellow_terracotta
fill 1 90 346 2 92 346 minecraft:honeycomb_block
setblock 1 90 350 minecraft:yellow_terracotta
fill 1 90 351 1 93 351 minecraft:honeycomb_block
setblock 1 90 355 minecraft:yellow_terracotta
fill 1 90 356 1 92 357 minecraft:honeycomb_block
setblock 1 90 363 minecraft:honey_block
setblock 2 90 349 minecraft:yellow_terracotta
fill 2 90 350 2 93 350 minecraft:honeycomb_block
setblock 2 90 353 minecraft:honeycomb_block
setblock 2 90 354 minecraft:yellow_terracotta
fill 2 90 355 2 93 355 minecraft:honeycomb_block
setblock 3 90 348 minecraft:yellow_terracotta
fill 3 90 349 3 93 349 minecraft:honeycomb_block
setblock 3 90 352 minecraft:honeycomb_block
setblock 3 90 353 minecraft:yellow_terracotta
setblock 7 90 323 minecraft:honeycomb_block
setblock 8 90 323 minecraft:yellow_terracotta
fill 9 90 323 9 93 323 minecraft:honeycomb_block
setblock 16 90 323 minecraft:honey_block
setblock 23 90 323 minecraft:yellow_terracotta
fill 23 90 324 23 93 324 minecraft:honeycomb_block
fill 24 90 323 24 93 323 minecraft:honeycomb_block
setblock 26 90 325 minecraft:yellow_terracotta
fill 26 90 363 26 91 363 minecraft:honeycomb_block
setblock 27 90 324 minecraft:yellow_terracotta
fill 27 90 325 27 92 326 minecraft:honeycomb_block
setblock 28 90 323 minecraft:yellow_terracotta
fill 28 90 324 28 93 324 minecraft:honeycomb_block
setblock 28 90 363 minecraft:yellow_terracotta
fill 29 90 323 29 93 323 minecraft:honeycomb_block
fill 29 90 363 29 93 363 minecraft:honeycomb_block
fill 30 90 322 30 91 322 minecraft:honeycomb_block
setblock 31 90 325 minecraft:yellow_terracotta
setblock 32 90 324 minecraft:yellow_terracotta
setblock 33 90 323 minecraft:yellow_terracotta
fill 33 90 324 33 91 324 minecraft:honeycomb_block
setblock 33 90 363 minecraft:yellow_terracotta
fill 34 90 323 34 93 323 minecraft:honeycomb_block
fill 34 90 363 34 93 363 minecraft:honeycomb_block
fill 38 90 324 38 98 324 minecraft:yellow_terracotta
fill 39 90 360 39 94 360 minecraft:yellow_terracotta
setblock 41 90 323 minecraft:honey_block
setblock 41 90 342 minecraft:honey_block
fill 41 90 347 41 92 347 minecraft:honeycomb_block
setblock 41 90 350 minecraft:yellow_terracotta
fill 41 90 351 41 93 351 minecraft:honeycomb_block
setblock 41 90 355 minecraft:yellow_terracotta
fill 41 90 356 41 91 358 minecraft:honeycomb_block
fill 42 90 362 42 118 362 minecraft:honeycomb_block
setblock 0 91 331 minecraft:yellow_terracotta
fill 0 91 361 0 148 361 minecraft:honeycomb_block
setblock 1 91 325 minecraft:honey_block
setblock 1 91 329 minecraft:yellow_terracotta
fill 1 91 330 1 91 333 minecraft:honeycomb_block
setblock 1 91 344 minecraft:yellow_terracotta
fill 1 91 345 1 94 345 minecraft:honeycomb_block
setblock 1 91 349 minecraft:yellow_terracotta
fill 1 91 350 1 94 350 minecraft:honeycomb_block
setblock 1 91 354 minecraft:yellow_terracotta
fill 1 91 355 1 94 355 minecraft:honeycomb_block
setblock 1 91 358 minecraft:honeycomb_block
setblock 2 91 348 minecraft:yellow_terracotta
fill 2 91 349 2 94 349 minecraft:honeycomb_block
setblock 2 91 353 minecraft:yellow_terracotta
fill 2 91 354 3 93 354 minecraft:honeycomb_block
fill 2 91 356 2 92 356 minecraft:honeycomb_block
setblock 3 91 347 minecraft:yellow_terracotta
fill 3 91 348 3 94 348 minecraft:honeycomb_block
setblock 3 91 352 minecraft:yellow_terracotta
fill 3 91 353 3 94 353 minecraft:honeycomb_block
setblock 4 91 351 minecraft:yellow_terracotta
setblock 7 91 323 minecraft:yellow_terracotta
setblock 7 91 363 minecraft:honey_block
fill 8 91 323 8 94 323 minecraft:honeycomb_block
setblock 21 91 323 minecraft:honeycomb_block
setblock 22 91 323 minecraft:yellow_terracotta
fill 23 91 323 23 94 323 minecraft:honeycomb_block
setblock 24 91 325 minecraft:honeycomb_block
setblock 25 91 324 minecraft:honeycomb_block
setblock 25 91 325 minecraft:yellow_terracotta
fill 25 91 363 25 92 363 minecraft:honeycomb_block
setblock 26 91 324 minecraft:yellow_terracotta
fill 26 91 325 26 94 325 minecraft:honeycomb_block
setblock 27 91 323 minecraft:yellow_terracotta
fill 27 91 324 27 94 324 minecraft:honeycomb_block
setblock 27 91 363 minecraft:yellow_terracotta
fill 28 91 323 28 94 323 minecraft:honeycomb_block
fill 28 91 363 28 94 363 minecraft:honeycomb_block
fill 29 91 362 29 94 362 minecraft:honeycomb_block
setblock 30 91 325 minecraft:yellow_terracotta
setblock 31 91 324 minecraft:yellow_terracotta
setblock 31 91 325 minecraft:honeycomb_block
setblock 32 91 323 minecraft:yellow_terracotta
fill 32 91 324 32 93 324 minecraft:honeycomb_block
setblock 32 91 363 minecraft:yellow_terracotta
fill 33 91 323 33 94 323 minecraft:honeycomb_block
fill 33 91 363 33 94 363 minecraft:honeycomb_block
fill 39 91 326 39 97 326 minecraft:yellow_terracotta
setblock 40 91 350 minecraft:yellow_terracotta
fill 40 91 351 40 91 354 minecraft:honeycomb_block
setblock 40 91 355 minecraft:yellow_terracotta
setblock 41 91 329 minecraft:yellow_terracotta
setblock 41 91 336 minecraft:honey_block
setblock 41 91 349 minecraft:yellow_terracotta
fill 41 91 350 41 94 350 minecraft:honeycomb_block
setblock 41 91 353 minecraft:honeycomb_block
setblock 41 91 354 minecraft:yellow_terracotta
fill 41 91 355 41 94 355 minecraft:honeycomb_block
setblock 41 91 359 minecraft:yellow_terracotta
fill 41 91 360 41 94 360 minecraft:honeycomb_block
setblock 41 91 361 minecraft:honey_block
setblock 42 91 357 minecraft:yellow_concrete
fill 0 92 331 2 92 331 minecraft:honeycomb_block
setblock 1 92 328 minecraft:yellow_terracotta
fill 1 92 329 1 94 330 minecraft:honeycomb_block
setblock 1 92 332 minecraft:honeycomb_block
setblock 1 92 333 minecraft:yellow_terracotta
fill 1 92 334 1 92 337 minecraft:honeycomb_block
setblock 1 92 342 minecraft:honeycomb_block
setblock 1 92 343 minecraft:yellow_terracotta
fill 1 92 344 1 95 344 minecraft:honeycomb_block
setblock 1 92 348 minecraft:yellow_terracotta
fill 1 92 349 1 95 349 minecraft:honeycomb_block
setblock 1 92 353 minecraft:yellow_terracotta
fill 1 92 354 1 95 354 minecraft:honeycomb_block
setblock 1 92 358 minecraft:yellow_terracotta
fill 1 92 359 1 95 359 minecraft:honeycomb_block
fill 2 92 330 2 93 330 minecraft:honeycomb_block
setblock 2 92 332 minecraft:yellow_terracotta
fill 2 92 333 2 94 334 minecraft:honeycomb_block
fill 2 92 345 2 93 345 minecraft:honeycomb_block
setblock 2 92 347 minecraft:yellow_terracotta
fill 2 92 348 2 95 348 minecraft:honeycomb_block
setblock 2 92 351 minecraft:honeycomb_block
setblock 2 92 352 minecraft:yellow_terracotta
fill 2 92 353 2 95 353 minecraft:honeycomb_block
setblock 2 92 357 minecraft:yellow_terracotta
setblock 3 92 325 minecraft:light[level=12]
setblock 3 92 332 minecraft:light[level=12]
setblock 3 92 339 minecraft:light[level=12]
setblock 3 92 346 minecraft:light[level=12]
fill 3 92 347 3 95 347 minecraft:honeycomb_block
setblock 3 92 351 minecraft:yellow_terracotta
fill 3 92 352 4 94 352 minecraft:honeycomb_block
setblock 3 92 355 minecraft:honeycomb_block
setblock 3 92 356 minecraft:yellow_terracotta
setblock 3 92 360 minecraft:light[level=12]
setblock 4 92 323 minecraft:honey_block
setblock 4 92 349 minecraft:honeycomb_block
setblock 4 92 350 minecraft:yellow_terracotta
fill 4 92 351 4 95 351 minecraft:honeycomb_block
fill 4 92 353 4 93 353 minecraft:honeycomb_block
setblock 6 92 323 minecraft:yellow_terracotta
fill 7 92 323 7 95 323 minecraft:honeycomb_block
setblock 10 92 325 minecraft:light[level=12]
setblock 10 92 332 minecraft:light[level=12]
fill 10 92 339 11 93 340 minecraft:yellow_concrete
setblock 10 92 346 minecraft:light[level=12]
setblock 10 92 353 minecraft:light[level=12]
setblock 10 92 360 minecraft:light[level=12]
fill 12 92 339 12 93 339 minecraft:yellow_concrete
setblock 13 92 363 minecraft:honey_block
setblock 17 92 325 minecraft:light[level=12]
setblock 17 92 332 minecraft:light[level=12]
setblock 17 92 339 minecraft:light[level=12]
setblock 17 92 346 minecraft:light[level=12]
setblock 17 92 353 minecraft:light[level=12]
setblock 17 92 360 minecraft:light[level=12]
setblock 20 92 323 minecraft:honeycomb_block
setblock 21 92 323 minecraft:yellow_terracotta
fill 22 92 323 22 94 324 minecraft:honeycomb_block
setblock 24 92 325 minecraft:yellow_terracotta
setblock 24 92 332 minecraft:light[level=12]
setblock 24 92 339 minecraft:light[level=12]
setblock 24 92 346 minecraft:light[level=12]
setblock 24 92 353 minecraft:light[level=12]
setblock 24 92 360 minecraft:light[level=12]
fill 24 92 363 24 93 363 minecraft:honeycomb_block
setblock 25 92 324 minecraft:yellow_terracotta
fill 25 92 325 25 95 325 minecraft:honeycomb_block
setblock 26 92 323 minecraft:yellow_terracotta
fill 26 92 324 26 95 324 minecraft:honeycomb_block
fill 26 92 326 26 93 326 minecraft:honeycomb_block
setblock 26 92 363 minecraft:yellow_terracotta
fill 27 92 323 27 95 323 minecraft:honeycomb_block
setblock 27 92 362 minecraft:yellow_terracotta
fill 27 92 363 27 95 363 minecraft:honeycomb_block
setblock 28 92 326 minecraft:yellow_terracotta
fill 28 92 362 28 95 362 minecraft:honeycomb_block
setblock 29 92 325 minecraft:yellow_terracotta
setblock 30 92 322 minecraft:orange_terracotta
setblock 30 92 324 minecraft:yellow_terracotta
fill 30 92 325 30 93 325 minecraft:honeycomb_block
fill 30 92 362 31 92 362 minecraft:honeycomb_block
setblock 31 92 323 minecraft:yellow_terracotta
fill 31 92 324 31 94 324 minecraft:honeycomb_block
setblock 31 92 325 minecraft:light[level=12]
setblock 31 92 332 minecraft:light[level=12]
setblock 31 92 339 minecraft:light[level=12]
setblock 31 92 346 minecraft:light[level=12]
setblock 31 92 353 minecraft:light[level=12]
setblock 31 92 360 minecraft:light[level=12]
setblock 31 92 363 minecraft:yellow_terracotta
setblock 32 92 322 minecraft:orange_terracotta
fill 32 92 323 32 95 323 minecraft:honeycomb_block
fill 32 92 363 32 95 363 minecraft:honeycomb_block
setblock 38 92 325 minecraft:light[level=12]
setblock 38 92 332 minecraft:light[level=12]
setblock 38 92 339 minecraft:light[level=12]
setblock 38 92 346 minecraft:light[level=12]
setblock 38 92 353 minecraft:light[level=12]
fill 38 92 360 38 94 360 minecraft:yellow_terracotta
setblock 38 92 363 minecraft:honey_block
fill 39 92 359 39 94 359 minecraft:yellow_terracotta
fill 39 92 361 39 94 361 minecraft:yellow_terracotta
fill 40 92 350 40 92 353 minecraft:honeycomb_block
setblock 40 92 354 minecraft:yellow_terracotta
fill 40 92 355 40 93 357 minecraft:honeycomb_block
fill 40 92 360 40 93 360 minecraft:yellow_terracotta
setblock 41 92 327 minecraft:honeycomb_block
setblock 41 92 328 minecraft:yellow_terracotta
fill 41 92 329 41 92 332 minecraft:honeycomb_block
setblock 41 92 333 minecraft:yellow_terracotta
fill 41 92 346 41 93 346 minecraft:honeycomb_block
setblock 41 92 348 minecraft:yellow_terracotta
fill 41 92 349 41 95 349 minecraft:honeycomb_block
setblock 41 92 353 minecraft:yellow_terracotta
fill 41 92 354 41 95 354 minecraft:honeycomb_block
fill 41 92 356 41 92 357 minecraft:honeycomb_block
setblock 41 92 358 minecraft:yellow_terracotta
fill 41 92 359 41 95 359 minecraft:honeycomb_block
fill 41 92 361 41 92 362 minecraft:honeycomb_block
fill 42 92 340 42 93 340 minecraft:yellow_terracotta
fill 42 92 357 42 126 357 minecraft:honeycomb_block
fill 0 93 331 1 93 331 minecraft:honeycomb_block
setblock 0 93 362 minecraft:orange_terracotta
setblock 1 93 327 minecraft:yellow_terracotta
fill 1 93 328 1 96 328 minecraft:honeycomb_block
setblock 1 93 332 minecraft:yellow_terracotta
fill 1 93 333 1 93 336 minecraft:honeycomb_block
setblock 1 93 337 minecraft:yellow_terracotta
fill 1 93 338 1 93 341 minecraft:honeycomb_block
setblock 1 93 342 minecraft:yellow_terracotta
fill 1 93 343 1 96 343 minecraft:honeycomb_block
setblock 1 93 346 minecraft:honeycomb_block
setblock 1 93 347 minecraft:yellow_terracotta
fill 1 93 348 1 96 348 minecraft:honeycomb_block
setblock 1 93 352 minecraft:yellow_terracotta
fill 1 93 353 1 96 353 minecraft:honeycomb_block
setblock 1 93 356 minecraft:honeycomb_block
setblock 1 93 357 minecraft:yellow_terracotta
fill 1 93 358 2 95 358 minecraft:honeycomb_block
fill 1 93 360 1 94 360 minecraft:honeycomb_block
setblock 1 93 362 minecraft:honey_block
fill 2 93 329 2 94 329 minecraft:honeycomb_block
setblock 2 93 331 minecraft:yellow_terracotta
fill 2 93 332 3 95 332 minecraft:honeycomb_block
setblock 2 93 335 minecraft:honeycomb_block
setblock 2 93 336 minecraft:yellow_terracotta
fill 2 93 337 2 94 339 minecraft:honeycomb_block
fill 2 93 344 2 94 344 minecraft:honeycomb_block
setblock 2 93 346 minecraft:yellow_terracotta
fill 2 93 347 2 96 347 minecraft:honeycomb_block
setblock 2 93 351 minecraft:yellow_terracotta
fill 2 93 352 2 96 352 minecraft:honeycomb_block
setblock 2 93 356 minecraft:yellow_terracotta
fill 2 93 357 3 95 357 minecraft:honeycomb_block
fill 2 93 359 2 94 359 minecraft:honeycomb_block
fill 3 93 331 3 96 331 minecraft:honeycomb_block
fill 3 93 333 3 93 334 minecraft:honeycomb_block
setblock 3 93 335 minecraft:yellow_terracotta
fill 3 93 346 3 96 346 minecraft:honeycomb_block
setblock 3 93 350 minecraft:yellow_terracotta
fill 3 93 351 3 96 351 minecraft:honeycomb_block
setblock 3 93 355 minecraft:yellow_terracotta
fill 3 93 356 3 96 356 minecraft:honeycomb_block
setblock 4 93 349 minecraft:yellow_terracotta
fill 4 93 350 4 95 350 minecraft:honeycomb_block
setblock 4 93 354 minecraft:yellow_terracotta
fill 4 93 355 4 96 355 minecraft:honeycomb_block
setblock 5 93 323 minecraft:yellow_terracotta
setblock 5 93 363 minecraft:yellow_terracotta
fill 6 93 323 6 96 323 minecraft:honeycomb_block
fill 6 93 363 6 96 363 minecraft:honeycomb_block
setblock 9 93 322 minecraft:orange_terracotta
setblock 10 93 323 minecraft:yellow_terracotta
setblock 19 93 363 minecraft:honey_block
setblock 20 93 323 minecraft:yellow_terracotta
fill 21 93 323 21 95 324 minecraft:honeycomb_block
setblock 23 93 325 minecraft:yellow_terracotta
fill 23 93 363 23 94 363 minecraft:honeycomb_block
setblock 24 93 324 minecraft:yellow_terracotta
fill 24 93 325 24 96 325 minecraft:honeycomb_block
fill 25 93 322 28 94 322 minecraft:honeycomb_block
setblock 25 93 323 minecraft:yellow_terracotta
fill 25 93 324 25 96 324 minecraft:honeycomb_block
setblock 25 93 362 minecraft:honeycomb_block
setblock 25 93 363 minecraft:yellow_terracotta
fill 26 93 323 26 96 323 minecraft:honeycomb_block
setblock 26 93 362 minecraft:yellow_terracotta
fill 26 93 363 26 96 363 minecraft:honeycomb_block
setblock 27 93 325 minecraft:honeycomb_block
setblock 27 93 326 minecraft:yellow_terracotta
fill 27 93 362 27 96 362 minecraft:honeycomb_block
setblock 28 93 325 minecraft:yellow_terracotta
setblock 29 93 322 minecraft:yellow_concrete
setblock 29 93 324 minecraft:yellow_terracotta
fill 29 93 325 29 94 325 minecraft:honeycomb_block
fill 30 93 322 30 142 322 minecraft:honeycomb_block
setblock 30 93 323 minecraft:yellow_terracotta
fill 30 93 324 30 95 324 minecraft:honeycomb_block
setblock 30 93 362 minecraft:honeycomb_block
setblock 30 93 363 minecraft:yellow_terracotta
fill 31 93 323 31 96 323 minecraft:honeycomb_block
setblock 31 93 362 minecraft:yellow_terracotta
fill 31 93 363 31 96 363 minecraft:honeycomb_block
setblock 32 93 322 minecraft:yellow_terracotta
setblock 35 93 363 minecraft:yellow_terracotta
fill 38 93 359 38 94 359 minecraft:yellow_terracotta
fill 38 93 361 38 94 361 minecraft:yellow_terracotta
fill 39 93 348 39 100 348 minecraft:brown_terracotta
setblock 39 93 354 minecraft:yellow_terracotta
fill 40 93 349 40 93 352 minecraft:honeycomb_block
setblock 40 93 353 minecraft:yellow_terracotta
fill 40 93 354 40 96 354 minecraft:honeycomb_block
setblock 40 93 358 minecraft:yellow_terracotta
fill 40 93 359 40 96 359 minecraft:honeycomb_block
setblock 40 93 361 minecraft:yellow_terracotta
setblock 40 93 363 minecraft:yellow_terracotta
setblock 41 93 324 minecraft:honey_block
setblock 41 93 327 minecraft:yellow_terracotta
fill 41 93 328 41 93 331 minecraft:honeycomb_block
setblock 41 93 332 minecraft:yellow_terracotta
fill 41 93 333 41 94 335 minecraft:honeycomb_block
setblock 41 93 347 minecraft:yellow_terracotta
fill 41 93 348 41 96 348 minecraft:honeycomb_block
setblock 41 93 352 minecraft:yellow_terracotta
fill 41 93 353 41 96 353 minecraft:honeycomb_block
setblock 41 93 356 minecraft:honeycomb_block
setblock 41 93 357 minecraft:yellow_terracotta
fill 41 93 358 41 96 358 minecraft:honeycomb_block
setblock 41 93 361 minecraft:honeycomb_block
setblock 41 93 362 minecraft:yellow_terracotta
fill 41 93 363 41 96 363 minecraft:honeycomb_block
setblock 42 93 352 minecraft:orange_terracotta
setblock 42 93 353 minecraft:yellow_terracotta
fill 0 94 331 0 154 331 minecraft:honeycomb_block
fill 0 94 362 0 307 362 minecraft:honeycomb_block
setblock 1 94 324 minecraft:honey_block
fill 1 94 327 1 97 327 minecraft:honeycomb_block
setblock 1 94 331 minecraft:yellow_terracotta
fill 1 94 332 1 94 335 minecraft:honeycomb_block
setblock 1 94 336 minecraft:yellow_terracotta
fill 1 94 337 1 94 340 minecraft:honeycomb_block
setblock 1 94 341 minecraft:yellow_terracotta
fill 1 94 342 2 96 342 minecraft:honeycomb_block
setblock 1 94 346 minecraft:yellow_terracotta
fill 1 94 347 1 97 347 minecraft:honeycomb_block
setblock 1 94 351 minecraft:yellow_terracotta
fill 1 94 352 1 97 352 minecraft:honeycomb_block
setblock 1 94 356 minecraft:yellow_terracotta
fill 1 94 357 1 97 357 minecraft:honeycomb_block
setblock 1 94 361 minecraft:yellow_terracotta
fill 2 94 328 2 95 328 minecraft:honeycomb_block
setblock 2 94 330 minecraft:yellow_terracotta
fill 2 94 331 2 97 331 minecraft:honeycomb_block
setblock 2 94 335 minecraft:yellow_terracotta
fill 2 94 336 3 96 336 minecraft:honeycomb_block
setblock 2 94 340 minecraft:yellow_terracotta
fill 2 94 341 2 97 341 minecraft:honeycomb_block
fill 2 94 343 2 95 343 minecraft:honeycomb_block
setblock 2 94 345 minecraft:yellow_terracotta
fill 2 94 346 2 97 346 minecraft:honeycomb_block
setblock 2 94 350 minecraft:yellow_terracotta
fill 2 94 351 2 97 351 minecraft:honeycomb_block
setblock 2 94 354 minecraft:honeycomb_block
setblock 2 94 355 minecraft:yellow_terracotta
fill 2 94 356 2 97 356 minecraft:honeycomb_block
setblock 2 94 360 minecraft:yellow_terracotta
fill 3 94 330 3 97 330 minecraft:honeycomb_block
setblock 3 94 333 minecraft:honeycomb_block
setblock 3 94 334 minecraft:yellow_terracotta
fill 3 94 335 4 96 335 minecraft:honeycomb_block
fill 3 94 337 3 94 338 minecraft:honeycomb_block
setblock 3 94 339 minecraft:yellow_terracotta
setblock 3 94 349 minecraft:yellow_terracotta
fill 3 94 350 3 97 350 minecraft:honeycomb_block
setblock 3 94 354 minecraft:yellow_terracotta
fill 3 94 355 3 97 355 minecraft:honeycomb_block
setblock 3 94 358 minecraft:honeycomb_block
setblock 3 94 363 minecraft:honeycomb_block
setblock 4 94 332 minecraft:honeycomb_block
setblock 4 94 333 minecraft:yellow_terracotta
fill 4 94 334 4 97 334 minecraft:honeycomb_block
setblock 4 94 349 minecraft:honeycomb_block
setblock 4 94 353 minecraft:yellow_terracotta
fill 4 94 354 4 97 354 minecraft:honeycomb_block
setblock 4 94 363 minecraft:yellow_terracotta
fill 5 94 323 5 97 323 minecraft:honeycomb_block
fill 5 94 363 5 97 363 minecraft:honeycomb_block
fill 7 94 363 7 95 363 minecraft:honeycomb_block
fill 9 94 322 9 97 322 minecraft:honeycomb_block
setblock 9 94 323 minecraft:yellow_terracotta
setblock 10 94 323 minecraft:honeycomb_block
fill 11 94 323 11 95 323 minecraft:honey_block
setblock 17 94 323 minecraft:honey_block
setblock 19 94 323 minecraft:yellow_terracotta
fill 20 94 323 20 97 323 minecraft:honeycomb_block
fill 22 94 363 22 95 363 minecraft:honeycomb_block
setblock 23 94 324 minecraft:yellow_terracotta
fill 23 94 325 23 97 325 minecraft:honeycomb_block
setblock 24 94 323 minecraft:yellow_terracotta
fill 24 94 324 24 97 324 minecraft:honeycomb_block
setblock 24 94 362 minecraft:honeycomb_block
setblock 24 94 363 minecraft:yellow_terracotta
fill 25 94 323 25 97 323 minecraft:honeycomb_block
setblock 25 94 362 minecraft:yellow_terracotta
fill 25 94 363 25 97 363 minecraft:honeycomb_block
fill 26 94 362 26 97 362 minecraft:honeycomb_block
setblock 27 94 325 minecraft:yellow_terracotta
fill 27 94 361 28 96 361 minecraft:honeycomb_block
setblock 28 94 324 minecraft:yellow_terracotta
fill 28 94 325 28 95 325 minecraft:honeycomb_block
fill 29 94 322 29 189 322 minecraft:honeycomb_block
setblock 29 94 323 minecraft:yellow_terracotta
fill 29 94 324 29 96 324 minecraft:honeycomb_block
setblock 29 94 363 minecraft:yellow_terracotta
fill 30 94 323 30 97 323 minecraft:honeycomb_block
setblock 30 94 362 minecraft:yellow_terracotta
fill 30 94 363 30 97 363 minecraft:honeycomb_block
fill 31 94 362 32 96 362 minecraft:honeycomb_block
fill 32 94 322 32 308 322 minecraft:honeycomb_block
setblock 34 94 363 minecraft:yellow_terracotta
fill 35 94 363 38 94 363 minecraft:honeycomb_block
setblock 36 94 323 minecraft:honey_block
fill 38 94 326 38 97 326 minecraft:yellow_terracotta
fill 39 94 325 39 98 325 minecraft:yellow_terracotta
fill 39 94 327 39 97 327 minecraft:yellow_terracotta
setblock 39 94 352 minecraft:honeycomb_block
setblock 39 94 353 minecraft:yellow_terracotta
fill 39 94 354 39 94 357 minecraft:honeycomb_block
setblock 39 94 363 minecraft:yellow_terracotta
fill 40 94 326 40 97 326 minecraft:yellow_terracotta
fill 40 94 349 40 94 351 minecraft:honeycomb_block
setblock 40 94 352 minecraft:yellow_terracotta
fill 40 94 353 40 97 353 minecraft:honeycomb_block
fill 40 94 355 40 94 356 minecraft:honeycomb_block
setblock 40 94 357 minecraft:yellow_terracotta
fill 40 94 358 40 97 358 minecraft:honeycomb_block
fill 40 94 360 40 94 361 minecraft:honeycomb_block
fill 40 94 363 40 97 363 minecraft:honeycomb_block
fill 41 94 327 41 94 330 minecraft:honeycomb_block
setblock 41 94 331 minecraft:yellow_terracotta
fill 41 94 332 41 97 332 minecraft:honeycomb_block
setblock 41 94 336 minecraft:yellow_terracotta
fill 41 94 337 41 96 338 minecraft:honeycomb_block
setblock 41 94 343 minecraft:honey_block
setblock 41 94 345 minecraft:honeycomb_block
setblock 41 94 346 minecraft:yellow_terracotta
fill 41 94 347 41 97 347 minecraft:honeycomb_block
setblock 41 94 351 minecraft:yellow_terracotta
fill 41 94 352 42 97 352 minecraft:honeycomb_block
setblock 41 94 356 minecraft:yellow_terracotta
fill 41 94 357 41 97 357 minecraft:honeycomb_block
setblock 41 94 361 minecraft:yellow_terracotta
fill 41 94 362 41 97 362 minecraft:honeycomb_block
fill 42 94 340 42 108 340 minecraft:honeycomb_block
fill 42 94 353 42 308 353 minecraft:honeycomb_block
setblock 1 95 329 minecraft:honeycomb_block
setblock 1 95 330 minecraft:yellow_terracotta
fill 1 95 331 1 95 334 minecraft:honeycomb_block
setblock 1 95 335 minecraft:yellow_terracotta
fill 1 95 336 1 95 339 minecraft:honeycomb_block
setblock 1 95 340 minecraft:yellow_terracotta
fill 1 95 341 1 98 341 minecraft:honeycomb_block
setblock 1 95 345 minecraft:yellow_terracotta
fill 1 95 346 1 98 346 minecraft:honeycomb_block
setblock 1 95 350 minecraft:yellow_terracotta
fill 1 95 351 1 98 351 minecraft:honeycomb_block
setblock 1 95 355 minecraft:yellow_terracotta
fill 1 95 356 1 98 356 minecraft:honeycomb_block
setblock 1 95 360 minecraft:yellow_terracotta
fill 1 95 361 1 97 362 minecraft:honeycomb_block
setblock 2 95 329 minecraft:yellow_terracotta
fill 2 95 330 2 98 330 minecraft:honeycomb_block
setblock 2 95 333 minecraft:honeycomb_block
setblock 2 95 334 minecraft:yellow_terracotta
fill 2 95 335 2 98 335 minecraft:honeycomb_block
fill 2 95 337 2 95 338 minecraft:honeycomb_block
setblock 2 95 339 minecraft:yellow_terracotta
fill 2 95 340 3 97 340 minecraft:honeycomb_block
setblock 2 95 344 minecraft:yellow_terracotta
fill 2 95 345 3 96 345 minecraft:honeycomb_block
setblock 2 95 349 minecraft:yellow_terracotta
fill 2 95 350 2 98 350 minecraft:honeycomb_block
setblock 2 95 354 minecraft:yellow_terracotta
fill 2 95 355 2 98 355 minecraft:honeycomb_block
setblock 2 95 359 minecraft:yellow_terracotta
fill 2 95 360 2 98 360 minecraft:honeycomb_block
setblock 2 95 363 minecraft:honeycomb_block
setblock 3 95 333 minecraft:yellow_terracotta
fill 3 95 334 3 98 334 minecraft:honeycomb_block
setblock 3 95 337 minecraft:honeycomb_block
setblock 3 95 338 minecraft:yellow_terracotta
fill 3 95 339 3 98 339 minecraft:honeycomb_block
fill 3 95 341 3 96 341 minecraft:honeycomb_block
setblock 3 95 348 minecraft:yellow_terracotta
fill 3 95 349 3 97 349 minecraft:honeycomb_block
setblock 3 95 352 minecraft:honeycomb_block
setblock 3 95 353 minecraft:yellow_terracotta
fill 3 95 354 3 98 354 minecraft:honeycomb_block
setblock 3 95 358 minecraft:yellow_terracotta
setblock 3 95 363 minecraft:yellow_terracotta
fill 4 95 323 4 97 323 minecraft:honeycomb_block
setblock 4 95 332 minecraft:yellow_terracotta
fill 4 95 333 4 98 333 minecraft:honeycomb_block
setblock 4 95 336 minecraft:honeycomb_block
setblock 4 95 337 minecraft:yellow_terracotta
fill 4 95 338 4 98 338 minecraft:honeycomb_block
setblock 4 95 352 minecraft:yellow_terracotta
fill 4 95 353 4 96 353 minecraft:honeycomb_block
setblock 4 95 356 minecraft:honeycomb_block
fill 4 95 363 4 98 363 minecraft:honeycomb_block
setblock 8 95 323 minecraft:yellow_terracotta
setblock 9 95 323 minecraft:honeycomb_block
setblock 12 95 363 minecraft:honey_block
fill 19 95 323 19 98 323 minecraft:honeycomb_block
fill 21 95 363 21 96 363 minecraft:honeycomb_block
setblock 22 95 323 minecraft:honeycomb_block
setblock 22 95 324 minecraft:yellow_terracotta
setblock 23 95 323 minecraft:yellow_terracotta
fill 23 95 324 23 98 324 minecraft:honeycomb_block
setblock 23 95 362 minecraft:honeycomb_block
setblock 23 95 363 minecraft:yellow_terracotta
fill 24 95 323 24 98 323 minecraft:honeycomb_block
fill 24 95 327 24 104 327 minecraft:brown_terracotta
setblock 24 95 362 minecraft:yellow_terracotta
fill 24 95 363 24 98 363 minecraft:honeycomb_block
fill 25 95 322 25 222 322 minecraft:honeycomb_block
setblock 25 95 361 minecraft:yellow_terracotta
fill 25 95 362 25 98 362 minecraft:honeycomb_block
setblock 26 95 322 minecraft:orange_terracotta
setblock 26 95 325 minecraft:yellow_terracotta
fill 26 95 361 26 98 361 minecraft:honeycomb_block
fill 27 95 322 28 96 322 minecraft:honeycomb_block
setblock 27 95 324 minecraft:yellow_terracotta
fill 27 95 325 27 96 325 minecraft:honeycomb_block
setblock 28 95 323 minecraft:yellow_terracotta
fill 28 95 324 28 97 324 minecraft:honeycomb_block
setblock 28 95 363 minecraft:yellow_terracotta
fill 29 95 323 29 98 323 minecraft:honeycomb_block
setblock 29 95 361 minecraft:honeycomb_block
setblock 29 95 362 minecraft:yellow_terracotta
fill 29 95 363 29 98 363 minecraft:honeycomb_block
fill 30 95 362 30 98 362 minecraft:honeycomb_block
setblock 33 95 363 minecraft:yellow_terracotta
fill 34 95 363 37 95 363 minecraft:honeycomb_block
setblock 34 95 364 minecraft:orange_terracotta
fill 37 95 324 37 98 324 minecraft:yellow_terracotta
fill 38 95 323 38 98 323 minecraft:yellow_terracotta
fill 38 95 325 38 98 325 minecraft:yellow_terracotta
setblock 38 95 363 minecraft:yellow_terracotta
fill 39 95 324 39 98 324 minecraft:yellow_terracotta
setblock 39 95 352 minecraft:yellow_terracotta
fill 39 95 353 39 95 356 minecraft:honeycomb_block
setblock 39 95 357 minecraft:yellow_terracotta
fill 39 95 358 39 98 358 minecraft:honeycomb_block
fill 39 95 363 39 98 363 minecraft:honeycomb_block
fill 40 95 348 40 95 350 minecraft:honeycomb_block
setblock 40 95 351 minecraft:yellow_terracotta
fill 40 95 352 40 98 352 minecraft:honeycomb_block
setblock 40 95 355 minecraft:honeycomb_block
setblock 40 95 356 minecraft:yellow_terracotta
fill 40 95 357 40 98 357 minecraft:honeycomb_block
setblock 40 95 360 minecraft:honeycomb_block
setblock 40 95 361 minecraft:yellow_terracotta
fill 40 95 362 40 98 362 minecraft:honeycomb_block
fill 41 95 327 41 95 329 minecraft:honeycomb_block
setblock 41 95 330 minecraft:yellow_terracotta
fill 41 95 331 41 98 331 minecraft:honeycomb_block
fill 41 95 333 41 95 334 minecraft:honeycomb_block
setblock 41 95 335 minecraft:yellow_terracotta
fill 41 95 336 41 98 336 minecraft:honeycomb_block
setblock 41 95 339 minecraft:honeycomb_block
setblock 41 95 340 minecraft:yellow_terracotta
fill 41 95 341 41 95 344 minecraft:honeycomb_block
setblock 41 95 345 minecraft:yellow_terracotta
fill 41 95 346 41 98 346 minecraft:honeycomb_block
setblock 41 95 350 minecraft:yellow_terracotta
fill 41 95 351 41 98 351 minecraft:honeycomb_block
setblock 41 95 355 minecraft:yellow_terracotta
fill 41 95 356 41 98 356 minecraft:honeycomb_block
setblock 41 95 360 minecraft:yellow_terracotta
fill 41 95 361 41 98 361 minecraft:honeycomb_block
setblock 1 96 329 minecraft:yellow_terracotta
fill 1 96 330 1 96 333 minecraft:honeycomb_block
setblock 1 96 334 minecraft:yellow_terracotta
fill 1 96 335 1 96 338 minecraft:honeycomb_block
setblock 1 96 339 minecraft:yellow_terracotta
fill 1 96 340 1 99 340 minecraft:honeycomb_block
setblock 1 96 344 minecraft:yellow_terracotta
fill 1 96 345 1 99 345 minecraft:honeycomb_block
setblock 1 96 349 minecraft:yellow_terracotta
fill 1 96 350 1 99 350 minecraft:honeycomb_block
setblock 1 96 354 minecraft:yellow_terracotta
fill 1 96 355 1 99 355 minecraft:honeycomb_block
setblock 1 96 358 minecraft:honeycomb_block
setblock 1 96 359 minecraft:yellow_terracotta
fill 1 96 360 1 99 360 minecraft:honeycomb_block
setblock 1 96 363 minecraft:honeycomb_block
setblock 2 96 328 minecraft:yellow_terracotta
fill 2 96 329 2 98 329 minecraft:honeycomb_block
setblock 2 96 332 minecraft:honeycomb_block
setblock 2 96 333 minecraft:yellow_terracotta
fill 2 96 334 2 99 334 minecraft:honeycomb_block
setblock 2 96 337 minecraft:honeycomb_block
setblock 2 96 338 minecraft:yellow_terracotta
fill 2 96 339 2 99 339 minecraft:honeycomb_block
setblock 2 96 343 minecraft:yellow_terracotta
fill 2 96 344 3 97 344 minecraft:honeycomb_block
setblock 2 96 348 minecraft:yellow_terracotta
fill 2 96 349 2 99 349 minecraft:honeycomb_block
setblock 2 96 353 minecraft:yellow_terracotta
fill 2 96 354 2 99 354 minecraft:honeycomb_block
setblock 2 96 357 minecraft:honeycomb_block
setblock 2 96 358 minecraft:yellow_terracotta
fill 2 96 359 3 98 359 minecraft:honeycomb_block
fill 2 96 361 2 97 361 minecraft:honeycomb_block
setblock 2 96 363 minecraft:yellow_terracotta
setblock 3 96 325 minecraft:light[level=15]
setblock 3 96 332 minecraft:yellow_terracotta
fill 3 96 333 3 99 333 minecraft:honeycomb_block
setblock 3 96 337 minecraft:yellow_terracotta
fill 3 96 338 3 99 338 minecraft:honeycomb_block
setblock 3 96 342 minecraft:yellow_terracotta
fill 3 96 343 3 99 343 minecraft:honeycomb_block
setblock 3 96 347 minecraft:yellow_terracotta
fill 3 96 348 3 97 348 minecraft:honeycomb_block
setblock 3 96 352 minecraft:yellow_terracotta
fill 3 96 353 3 99 353 minecraft:honeycomb_block
setblock 3 96 357 minecraft:yellow_terracotta
fill 3 96 358 3 99 358 minecraft:honeycomb_block
fill 3 96 363 3 99 363 minecraft:honeycomb_block
fill 4 96 332 4 97 332 minecraft:honeycomb_block
setblock 4 96 336 minecraft:yellow_terracotta
fill 4 96 337 4 99 337 minecraft:honeycomb_block
fill 4 96 339 4 97 339 minecraft:honeycomb_block
setblock 4 96 351 minecraft:yellow_terracotta
setblock 4 96 352 minecraft:honeycomb_block
setblock 4 96 356 minecraft:yellow_terracotta
setblock 7 96 323 minecraft:yellow_terracotta
setblock 7 96 363 minecraft:yellow_terracotta
setblock 8 96 323 minecraft:honeycomb_block
setblock 11 96 325 minecraft:light[level=15]
setblock 11 96 333 minecraft:light[level=15]
setblock 11 96 341 minecraft:light[level=15]
setblock 11 96 349 minecraft:light[level=15]
setblock 11 96 357 minecraft:light[level=15]
fill 13 96 332 14 97 333 minecraft:yellow_concrete
fill 18 96 323 18 99 323 minecraft:honeycomb_block
setblock 18 96 363 minecraft:honey_block
setblock 19 96 325 minecraft:light[level=15]
setblock 19 96 333 minecraft:light[level=15]
setblock 19 96 341 minecraft:light[level=15]
setblock 19 96 349 minecraft:light[level=15]
setblock 19 96 357 minecraft:light[level=15]
setblock 20 96 324 minecraft:honeycomb_block
fill 20 96 363 20 97 363 minecraft:honeycomb_block
setblock 21 96 323 minecraft:honeycomb_block
setblock 21 96 324 minecraft:yellow_terracotta
setblock 22 96 323 minecraft:yellow_terracotta
fill 22 96 324 22 99 324 minecraft:honeycomb_block
setblock 22 96 362 minecraft:honeycomb_block
setblock 22 96 363 minecraft:yellow_terracotta
fill 23 96 323 23 99 323 minecraft:honeycomb_block
setblock 23 96 362 minecraft:yellow_terracotta
fill 23 96 363 23 99 363 minecraft:honeycomb_block
setblock 24 96 361 minecraft:yellow_terracotta
fill 24 96 362 24 99 362 minecraft:honeycomb_block
setblock 25 96 325 minecraft:yellow_terracotta
fill 25 96 361 25 99 361 minecraft:honeycomb_block
fill 26 96 322 26 164 322 minecraft:honeycomb_block
setblock 26 96 324 minecraft:yellow_terracotta
setblock 26 96 325 minecraft:honeycomb_block
setblock 27 96 323 minecraft:yellow_terracotta
fill 27 96 324 27 98 324 minecraft:honeycomb_block
setblock 27 96 333 minecraft:light[level=15]
setblock 27 96 341 minecraft:light[level=15]
setblock 27 96 349 minecraft:light[level=15]
setblock 27 96 357 minecraft:light[level=15]
setblock 27 96 363 minecraft:yellow_terracotta
fill 28 96 323 28 99 323 minecraft:honeycomb_block
setblock 28 96 362 minecraft:yellow_terracotta
fill 28 96 363 28 99 363 minecraft:honeycomb_block
setblock 29 96 361 minecraft:yellow_terracotta
fill 29 96 362 29 99 362 minecraft:honeycomb_block
setblock 32 96 323 minecraft:yellow_terracotta
setblock 32 96 363 minecraft:yellow_terracotta
fill 33 96 363 36 96 363 minecraft:honeycomb_block
fill 34 96 364 34 101 364 minecraft:honeycomb_block
setblock 35 96 325 minecraft:light[level=15]
setblock 35 96 333 minecraft:light[level=15]
setblock 35 96 341 minecraft:light[level=15]
setblock 35 96 349 minecraft:light[level=15]
setblock 35 96 357 minecraft:light[level=15]
setblock 37 96 363 minecraft:yellow_terracotta
fill 38 96 327 38 97 327 minecraft:yellow_terracotta
fill 38 96 363 38 99 363 minecraft:honeycomb_block
fill 39 96 352 39 96 355 minecraft:honeycomb_block
setblock 39 96 356 minecraft:yellow_terracotta
fill 39 96 357 39 99 357 minecraft:honeycomb_block
fill 39 96 359 39 97 359 minecraft:honeycomb_block
fill 39 96 362 39 99 362 minecraft:honeycomb_block
fill 40 96 325 40 97 325 minecraft:yellow_terracotta
fill 40 96 327 40 97 327 minecraft:yellow_terracotta
setblock 40 96 334 minecraft:honeycomb_block
fill 40 96 348 40 96 349 minecraft:honeycomb_block
setblock 40 96 350 minecraft:yellow_terracotta
fill 40 96 351 40 99 351 minecraft:honeycomb_block
setblock 40 96 355 minecraft:yellow_terracotta
fill 40 96 356 40 99 356 minecraft:honeycomb_block
setblock 40 96 360 minecraft:yellow_terracotta
fill 40 96 361 40 99 361 minecraft:honeycomb_block
setblock 41 96 325 minecraft:honey_block
setblock 41 96 328 minecraft:honeycomb_block
setblock 41 96 329 minecraft:yellow_terracotta
fill 41 96 330 41 99 330 minecraft:honeycomb_block
setblock 41 96 333 minecraft:honeycomb_block
setblock 41 96 334 minecraft:yellow_terracotta
fill 41 96 335 41 99 335 minecraft:honeycomb_block
setblock 41 96 339 minecraft:yellow_terracotta
fill 41 96 340 41 96 343 minecraft:honeycomb_block
setblock 41 96 344 minecraft:yellow_terracotta
fill 41 96 345 41 99 345 minecraft:honeycomb_block
setblock 41 96 349 minecraft:yellow_terracotta
fill 41 96 350 41 99 350 minecraft:honeycomb_block
setblock 41 96 354 minecraft:yellow_terracotta
fill 41 96 355 41 99 355 minecraft:honeycomb_block
setblock 41 96 359 minecraft:yellow_terracotta
fill 41 96 360 41 99 360 minecraft:honeycomb_block
setblock 1 97 328 minecraft:yellow_terracotta
fill 1 97 329 1 97 332 minecraft:honeycomb_block
setblock 1 97 333 minecraft:yellow_terracotta
fill 1 97 334 1 97 337 minecraft:honeycomb_block
setblock 1 97 338 minecraft:yellow_terracotta
fill 1 97 339 1 100 339 minecraft:honeycomb_block
setblock 1 97 342 minecraft:honeycomb_block
setblock 1 97 343 minecraft:yellow_terracotta
fill 1 97 344 1 100 344 minecraft:honeycomb_block
setblock 1 97 348 minecraft:yellow_terracotta
fill 1 97 349 1 100 349 minecraft:honeycomb_block
setblock 1 97 353 minecraft:yellow_terracotta
fill 1 97 354 1 100 354 minecraft:honeycomb_block
setblock 1 97 358 minecraft:yellow_terracotta
fill 1 97 359 1 100 359 minecraft:honeycomb_block
setblock 1 97 363 minecraft:yellow_terracotta
setblock 2 97 332 minecraft:yellow_terracotta
fill 2 97 333 2 100 333 minecraft:honeycomb_block
setblock 2 97 336 minecraft:honeycomb_block
setblock 2 97 337 minecraft:yellow_terracotta
fill 2 97 338 2 100 338 minecraft:honeycomb_block
setblock 2 97 342 minecraft:yellow_terracotta
fill 2 97 343 2 100 343 minecraft:honeycomb_block
fill 2 97 345 2 98 345 minecraft:honeycomb_block
setblock 2 97 347 minecraft:yellow_terracotta
fill 2 97 348 2 100 348 minecraft:honeycomb_block
setblock 2 97 352 minecraft:yellow_terracotta
fill 2 97 353 2 100 353 minecraft:honeycomb_block
schedule function dropper:buildpart/72_3 1t
