fill 407 188 500 407 189 500 minecraft:black_concrete
fill 407 188 502 407 189 502 minecraft:black_concrete
fill 407 188 504 407 189 504 minecraft:black_concrete
fill 408 188 499 408 189 499 minecraft:black_concrete
fill 408 188 501 408 189 501 minecraft:black_concrete
fill 408 188 503 408 189 503 minecraft:black_concrete
fill 409 188 498 409 189 498 minecraft:black_concrete
fill 409 188 500 409 189 500 minecraft:black_concrete
fill 409 188 502 409 189 502 minecraft:black_concrete
fill 409 188 504 409 189 504 minecraft:black_concrete
fill 410 188 499 410 189 499 minecraft:black_concrete
fill 410 188 501 410 189 501 minecraft:black_concrete
fill 410 188 503 410 189 503 minecraft:black_concrete
fill 411 188 498 411 189 498 minecraft:black_concrete
fill 411 188 500 411 189 500 minecraft:black_concrete
fill 411 188 502 411 189 502 minecraft:black_concrete
fill 411 188 504 411 189 504 minecraft:black_concrete
fill 412 188 499 412 189 499 minecraft:black_concrete
fill 412 188 501 412 189 501 minecraft:black_concrete
fill 412 188 503 412 189 503 minecraft:black_concrete
fill 413 188 498 413 189 498 minecraft:black_concrete
fill 413 188 500 413 189 500 minecraft:black_concrete
fill 413 188 502 413 189 502 minecraft:black_concrete
fill 413 188 504 413 189 504 minecraft:black_concrete
setblock 407 190 498 minecraft:sea_lantern
setblock 407 190 500 minecraft:sea_lantern
setblock 407 190 502 minecraft:sea_lantern
setblock 407 190 504 minecraft:sea_lantern
setblock 408 190 499 minecraft:sea_lantern
setblock 408 190 501 minecraft:sea_lantern
setblock 408 190 503 minecraft:sea_lantern
setblock 409 190 498 minecraft:sea_lantern
setblock 409 190 500 minecraft:sea_lantern
setblock 409 190 502 minecraft:sea_lantern
setblock 409 190 504 minecraft:sea_lantern
setblock 410 190 499 minecraft:sea_lantern
setblock 410 190 501 minecraft:sea_lantern
setblock 410 190 503 minecraft:sea_lantern
setblock 411 190 498 minecraft:sea_lantern
setblock 411 190 500 minecraft:sea_lantern
setblock 411 190 502 minecraft:sea_lantern
setblock 411 190 504 minecraft:sea_lantern
setblock 412 190 499 minecraft:sea_lantern
setblock 412 190 501 minecraft:sea_lantern
setblock 412 190 503 minecraft:sea_lantern
setblock 413 190 498 minecraft:sea_lantern
setblock 413 190 500 minecraft:sea_lantern
setblock 413 190 502 minecraft:sea_lantern
setblock 413 190 504 minecraft:sea_lantern
fill 407 191 498 407 192 498 minecraft:black_concrete
fill 407 191 500 407 192 500 minecraft:black_concrete
fill 407 191 502 407 192 502 minecraft:black_concrete
fill 407 191 504 407 192 504 minecraft:black_concrete
fill 408 191 499 408 192 499 minecraft:black_concrete
fill 408 191 501 408 192 501 minecraft:black_concrete
fill 408 191 503 408 192 503 minecraft:black_concrete
fill 409 191 498 409 192 498 minecraft:black_concrete
fill 409 191 500 409 192 500 minecraft:black_concrete
fill 409 191 502 409 192 502 minecraft:black_concrete
fill 409 191 504 409 192 504 minecraft:black_concrete
fill 410 191 499 410 192 499 minecraft:black_concrete
fill 410 191 501 410 192 501 minecraft:black_concrete
fill 410 191 503 410 192 503 minecraft:black_concrete
fill 411 191 498 411 192 498 minecraft:black_concrete
fill 411 191 500 411 192 500 minecraft:black_concrete
fill 411 191 502 411 192 502 minecraft:black_concrete
fill 411 191 504 411 192 504 minecraft:black_concrete
fill 412 191 499 412 192 499 minecraft:black_concrete
fill 412 191 501 412 192 501 minecraft:black_concrete
fill 412 191 503 412 192 503 minecraft:black_concrete
fill 413 191 498 413 192 498 minecraft:black_concrete
fill 413 191 500 413 192 500 minecraft:black_concrete
fill 413 191 502 413 192 502 minecraft:black_concrete
fill 413 191 504 413 192 504 minecraft:black_concrete
fill 376 192 468 376 199 468 minecraft:black_concrete
fill 376 192 476 376 199 476 minecraft:black_concrete
fill 376 192 484 376 199 484 minecraft:black_concrete
fill 376 192 492 376 199 492 minecraft:black_concrete
fill 376 192 500 376 199 500 minecraft:black_concrete
fill 379 192 505 379 199 505 minecraft:black_concrete
fill 383 192 463 383 199 463 minecraft:black_concrete
fill 387 192 505 387 199 505 minecraft:black_concrete
fill 391 192 463 391 199 463 minecraft:black_concrete
fill 395 192 505 395 199 505 minecraft:black_concrete
fill 399 192 463 399 199 463 minecraft:black_concrete
fill 403 192 505 403 199 505 minecraft:black_concrete
fill 407 192 463 407 199 463 minecraft:black_concrete
fill 411 192 505 411 199 505 minecraft:black_concrete
fill 415 192 463 415 199 463 minecraft:black_concrete
fill 418 192 468 418 199 468 minecraft:black_concrete
fill 418 192 476 418 199 476 minecraft:black_concrete
fill 418 192 484 418 199 484 minecraft:black_concrete
fill 418 192 492 418 199 492 minecraft:black_concrete
fill 418 192 500 418 199 500 minecraft:black_concrete
setblock 407 193 498 minecraft:sea_lantern
setblock 407 193 500 minecraft:sea_lantern
setblock 407 193 502 minecraft:sea_lantern
setblock 407 193 504 minecraft:sea_lantern
setblock 408 193 499 minecraft:sea_lantern
setblock 408 193 501 minecraft:sea_lantern
setblock 408 193 503 minecraft:sea_lantern
setblock 409 193 498 minecraft:sea_lantern
setblock 409 193 500 minecraft:sea_lantern
setblock 409 193 502 minecraft:sea_lantern
setblock 409 193 504 minecraft:sea_lantern
setblock 410 193 499 minecraft:sea_lantern
setblock 410 193 501 minecraft:sea_lantern
setblock 410 193 503 minecraft:sea_lantern
setblock 411 193 498 minecraft:sea_lantern
setblock 411 193 500 minecraft:sea_lantern
setblock 411 193 502 minecraft:sea_lantern
setblock 411 193 504 minecraft:sea_lantern
setblock 412 193 499 minecraft:sea_lantern
setblock 412 193 501 minecraft:sea_lantern
setblock 412 193 503 minecraft:sea_lantern
setblock 413 193 498 minecraft:sea_lantern
setblock 413 193 500 minecraft:sea_lantern
setblock 413 193 502 minecraft:sea_lantern
setblock 413 193 504 minecraft:sea_lantern
setblock 379 194 466 minecraft:light[level=14]
setblock 379 194 474 minecraft:light[level=14]
setblock 379 194 482 minecraft:light[level=14]
setblock 379 194 490 minecraft:light[level=14]
setblock 379 194 498 minecraft:light[level=14]
setblock 387 194 466 minecraft:light[level=14]
setblock 387 194 474 minecraft:light[level=14]
setblock 387 194 482 minecraft:light[level=14]
setblock 387 194 490 minecraft:light[level=14]
setblock 387 194 498 minecraft:light[level=14]
setblock 395 194 474 minecraft:light[level=14]
setblock 395 194 482 minecraft:light[level=14]
setblock 395 194 490 minecraft:light[level=14]
setblock 395 194 498 minecraft:light[level=14]
setblock 403 194 466 minecraft:light[level=14]
setblock 403 194 474 minecraft:light[level=14]
setblock 403 194 482 minecraft:light[level=14]
setblock 403 194 490 minecraft:light[level=14]
setblock 403 194 498 minecraft:light[level=14]
fill 407 194 498 407 195 498 minecraft:black_concrete
fill 407 194 500 407 195 500 minecraft:black_concrete
fill 407 194 502 407 195 502 minecraft:black_concrete
fill 407 194 504 407 195 504 minecraft:black_concrete
fill 408 194 499 408 195 499 minecraft:black_concrete
fill 408 194 501 408 195 501 minecraft:black_concrete
fill 408 194 503 408 195 503 minecraft:black_concrete
fill 409 194 498 409 195 498 minecraft:black_concrete
fill 409 194 500 409 195 500 minecraft:black_concrete
fill 409 194 502 409 195 502 minecraft:black_concrete
fill 409 194 504 409 195 504 minecraft:black_concrete
fill 410 194 499 410 195 499 minecraft:black_concrete
fill 410 194 501 410 195 501 minecraft:black_concrete
fill 410 194 503 410 195 503 minecraft:black_concrete
setblock 411 194 466 minecraft:light[level=14]
setblock 411 194 474 minecraft:light[level=14]
setblock 411 194 482 minecraft:light[level=14]
setblock 411 194 490 minecraft:light[level=14]
fill 411 194 498 411 195 498 minecraft:black_concrete
fill 411 194 500 411 195 500 minecraft:black_concrete
fill 411 194 502 411 195 502 minecraft:black_concrete
fill 411 194 504 411 195 504 minecraft:black_concrete
fill 412 194 499 412 195 499 minecraft:black_concrete
fill 412 194 501 412 195 501 minecraft:black_concrete
fill 412 194 503 412 195 503 minecraft:black_concrete
fill 413 194 498 413 195 498 minecraft:black_concrete
fill 413 194 500 413 195 500 minecraft:black_concrete
fill 413 194 502 413 195 502 minecraft:black_concrete
fill 413 194 504 413 195 504 minecraft:black_concrete
fill 377 196 464 377 197 469 minecraft:black_concrete
fill 377 196 472 378 196 477 minecraft:black_concrete
fill 377 196 480 378 196 485 minecraft:black_concrete
fill 377 196 488 378 196 493 minecraft:black_concrete
fill 377 196 496 378 196 501 minecraft:black_concrete
fill 377 196 504 382 197 504 minecraft:black_concrete
fill 378 196 465 378 196 471 minecraft:black_concrete
fill 378 196 478 378 196 479 minecraft:black_concrete
fill 378 196 486 378 196 487 minecraft:black_concrete
fill 378 196 494 378 196 495 minecraft:black_concrete
fill 378 196 502 378 196 503 minecraft:black_concrete
fill 379 196 465 389 196 465 minecraft:black_concrete
fill 379 196 503 406 196 503 minecraft:black_concrete
fill 380 196 464 385 197 464 minecraft:black_concrete
fill 385 196 504 390 197 504 minecraft:black_concrete
fill 388 196 464 389 197 464 minecraft:black_concrete
fill 393 196 504 398 197 504 minecraft:black_concrete
fill 401 196 464 401 196 465 minecraft:black_concrete
fill 401 196 504 406 197 504 minecraft:black_concrete
fill 402 196 465 416 196 465 minecraft:black_concrete
fill 404 196 464 409 197 464 minecraft:black_concrete
setblock 407 196 498 minecraft:sea_lantern
setblock 407 196 500 minecraft:sea_lantern
setblock 407 196 502 minecraft:sea_lantern
setblock 407 196 504 minecraft:sea_lantern
setblock 408 196 499 minecraft:sea_lantern
setblock 408 196 501 minecraft:sea_lantern
setblock 408 196 503 minecraft:sea_lantern
setblock 409 196 498 minecraft:sea_lantern
setblock 409 196 500 minecraft:sea_lantern
setblock 409 196 502 minecraft:sea_lantern
setblock 409 196 504 minecraft:sea_lantern
setblock 410 196 499 minecraft:sea_lantern
setblock 410 196 501 minecraft:sea_lantern
setblock 410 196 503 minecraft:sea_lantern
setblock 411 196 498 minecraft:sea_lantern
setblock 411 196 500 minecraft:sea_lantern
setblock 411 196 502 minecraft:sea_lantern
setblock 411 196 504 minecraft:sea_lantern
fill 412 196 464 417 197 464 minecraft:black_concrete
setblock 412 196 499 minecraft:sea_lantern
setblock 412 196 501 minecraft:sea_lantern
setblock 412 196 503 minecraft:sea_lantern
setblock 413 196 498 minecraft:sea_lantern
setblock 413 196 500 minecraft:sea_lantern
setblock 413 196 502 minecraft:sea_lantern
setblock 413 196 504 minecraft:sea_lantern
fill 414 196 503 414 196 504 minecraft:black_concrete
fill 415 196 503 417 196 503 minecraft:black_concrete
fill 416 196 466 416 196 502 minecraft:black_concrete
fill 417 196 467 417 197 472 minecraft:black_concrete
fill 417 196 475 417 197 480 minecraft:black_concrete
fill 417 196 483 417 197 488 minecraft:black_concrete
fill 417 196 491 417 197 496 minecraft:black_concrete
fill 417 196 499 417 197 502 minecraft:black_concrete
fill 417 196 504 417 197 504 minecraft:black_concrete
fill 377 197 472 377 197 477 minecraft:black_concrete
fill 377 197 480 377 197 485 minecraft:black_concrete
fill 377 197 488 377 197 493 minecraft:black_concrete
fill 377 197 496 377 197 501 minecraft:black_concrete
setblock 401 197 464 minecraft:black_concrete
fill 407 197 498 407 198 498 minecraft:black_concrete
fill 407 197 500 407 198 500 minecraft:black_concrete
fill 407 197 502 407 198 502 minecraft:black_concrete
fill 407 197 504 407 198 504 minecraft:black_concrete
fill 408 197 499 408 198 499 minecraft:black_concrete
fill 408 197 501 408 198 501 minecraft:black_concrete
fill 408 197 503 408 198 503 minecraft:black_concrete
fill 409 197 498 409 198 498 minecraft:black_concrete
fill 409 197 500 409 198 500 minecraft:black_concrete
fill 409 197 502 409 198 502 minecraft:black_concrete
fill 409 197 504 409 198 504 minecraft:black_concrete
fill 410 197 499 410 198 499 minecraft:black_concrete
fill 410 197 501 410 198 501 minecraft:black_concrete
fill 410 197 503 410 198 503 minecraft:black_concrete
fill 411 197 498 411 198 498 minecraft:black_concrete
fill 411 197 500 411 198 500 minecraft:black_concrete
fill 411 197 502 411 198 502 minecraft:black_concrete
fill 411 197 504 411 198 504 minecraft:black_concrete
fill 412 197 499 412 198 499 minecraft:black_concrete
fill 412 197 501 412 198 501 minecraft:black_concrete
fill 412 197 503 412 198 503 minecraft:black_concrete
fill 413 197 498 413 198 498 minecraft:black_concrete
fill 413 197 500 413 198 500 minecraft:black_concrete
fill 413 197 502 413 198 502 minecraft:black_concrete
fill 413 197 504 414 197 504 minecraft:black_concrete
setblock 417 197 503 minecraft:black_concrete
fill 394 198 464 395 225 464 minecraft:black_concrete
setblock 413 198 504 minecraft:black_concrete
setblock 407 199 498 minecraft:sea_lantern
setblock 407 199 500 minecraft:sea_lantern
setblock 407 199 502 minecraft:sea_lantern
setblock 407 199 504 minecraft:sea_lantern
setblock 408 199 499 minecraft:sea_lantern
setblock 408 199 501 minecraft:sea_lantern
setblock 408 199 503 minecraft:sea_lantern
setblock 409 199 498 minecraft:sea_lantern
setblock 409 199 500 minecraft:sea_lantern
setblock 409 199 502 minecraft:sea_lantern
setblock 409 199 504 minecraft:sea_lantern
setblock 410 199 499 minecraft:sea_lantern
setblock 410 199 501 minecraft:sea_lantern
setblock 410 199 503 minecraft:sea_lantern
setblock 411 199 498 minecraft:sea_lantern
setblock 411 199 500 minecraft:sea_lantern
setblock 411 199 502 minecraft:sea_lantern
setblock 411 199 504 minecraft:sea_lantern
setblock 412 199 499 minecraft:sea_lantern
setblock 412 199 501 minecraft:sea_lantern
setblock 412 199 503 minecraft:sea_lantern
setblock 413 199 498 minecraft:sea_lantern
setblock 413 199 500 minecraft:sea_lantern
setblock 413 199 502 minecraft:sea_lantern
setblock 413 199 504 minecraft:sea_lantern
fill 376 200 468 376 205 468 minecraft:sea_lantern
fill 376 200 476 376 205 476 minecraft:sea_lantern
fill 376 200 484 376 205 484 minecraft:sea_lantern
fill 376 200 492 376 205 492 minecraft:sea_lantern
fill 376 200 500 376 205 500 minecraft:sea_lantern
fill 379 200 505 379 205 505 minecraft:sea_lantern
fill 383 200 463 383 205 463 minecraft:sea_lantern
fill 387 200 505 387 205 505 minecraft:sea_lantern
fill 391 200 463 391 205 463 minecraft:sea_lantern
fill 395 200 505 395 205 505 minecraft:sea_lantern
fill 399 200 463 399 205 463 minecraft:sea_lantern
fill 403 200 505 403 205 505 minecraft:sea_lantern
fill 407 200 463 407 205 463 minecraft:sea_lantern
setblock 407 200 498 minecraft:black_concrete
setblock 407 200 500 minecraft:black_concrete
setblock 407 200 502 minecraft:black_concrete
fill 407 200 504 407 225 504 minecraft:black_concrete
setblock 408 200 499 minecraft:black_concrete
setblock 408 200 501 minecraft:black_concrete
setblock 408 200 503 minecraft:black_concrete
setblock 409 200 498 minecraft:black_concrete
setblock 409 200 500 minecraft:black_concrete
setblock 409 200 502 minecraft:black_concrete
setblock 409 200 504 minecraft:black_concrete
setblock 410 200 499 minecraft:black_concrete
setblock 410 200 501 minecraft:black_concrete
setblock 410 200 503 minecraft:black_concrete
setblock 411 200 498 minecraft:black_concrete
setblock 411 200 500 minecraft:black_concrete
setblock 411 200 502 minecraft:black_concrete
setblock 411 200 504 minecraft:black_concrete
fill 411 200 505 411 205 505 minecraft:sea_lantern
setblock 412 200 499 minecraft:black_concrete
setblock 412 200 501 minecraft:black_concrete
setblock 412 200 503 minecraft:black_concrete
setblock 413 200 498 minecraft:black_concrete
setblock 413 200 500 minecraft:black_concrete
setblock 413 200 502 minecraft:black_concrete
setblock 413 200 504 minecraft:black_concrete
fill 415 200 463 415 205 463 minecraft:sea_lantern
fill 418 200 468 418 205 468 minecraft:sea_lantern
fill 418 200 476 418 205 476 minecraft:sea_lantern
fill 418 200 484 418 205 484 minecraft:sea_lantern
fill 418 200 492 418 205 492 minecraft:sea_lantern
fill 418 200 500 418 205 500 minecraft:sea_lantern
setblock 379 202 466 minecraft:light[level=14]
setblock 379 202 474 minecraft:light[level=14]
setblock 379 202 482 minecraft:light[level=14]
setblock 379 202 490 minecraft:light[level=14]
setblock 379 202 498 minecraft:light[level=14]
setblock 387 202 466 minecraft:light[level=14]
setblock 387 202 474 minecraft:light[level=14]
setblock 387 202 482 minecraft:light[level=14]
setblock 387 202 490 minecraft:light[level=14]
setblock 387 202 498 minecraft:light[level=14]
setblock 395 202 466 minecraft:light[level=14]
setblock 395 202 474 minecraft:light[level=14]
setblock 395 202 482 minecraft:light[level=14]
setblock 395 202 490 minecraft:light[level=14]
setblock 395 202 498 minecraft:light[level=14]
setblock 403 202 466 minecraft:light[level=14]
setblock 403 202 474 minecraft:light[level=14]
setblock 403 202 482 minecraft:light[level=14]
setblock 403 202 490 minecraft:light[level=14]
setblock 403 202 498 minecraft:light[level=14]
fill 407 202 478 410 205 481 minecraft:lime_concrete
setblock 411 202 466 minecraft:light[level=14]
setblock 411 202 474 minecraft:light[level=14]
setblock 411 202 482 minecraft:light[level=14]
setblock 411 202 490 minecraft:light[level=14]
setblock 411 202 498 minecraft:light[level=14]
fill 376 206 468 376 213 468 minecraft:black_concrete
fill 376 206 476 376 213 476 minecraft:black_concrete
fill 376 206 484 376 213 484 minecraft:black_concrete
fill 376 206 492 376 213 492 minecraft:black_concrete
fill 376 206 500 376 213 500 minecraft:black_concrete
fill 379 206 505 379 213 505 minecraft:black_concrete
fill 383 206 463 383 213 463 minecraft:black_concrete
fill 387 206 505 387 213 505 minecraft:black_concrete
fill 391 206 463 391 213 463 minecraft:black_concrete
fill 391 206 497 392 207 498 minecraft:white_concrete
fill 395 206 505 395 213 505 minecraft:black_concrete
fill 399 206 463 399 213 463 minecraft:black_concrete
fill 403 206 505 403 213 505 minecraft:black_concrete
fill 407 206 463 407 213 463 minecraft:black_concrete
fill 411 206 505 411 213 505 minecraft:black_concrete
fill 415 206 463 415 213 463 minecraft:black_concrete
fill 418 206 468 418 213 468 minecraft:black_concrete
fill 418 206 476 418 213 476 minecraft:black_concrete
fill 418 206 484 418 213 484 minecraft:black_concrete
fill 418 206 492 418 213 492 minecraft:black_concrete
fill 418 206 500 418 213 500 minecraft:black_concrete
fill 379 207 470 379 212 470 minecraft:magenta_concrete
fill 391 207 483 391 208 483 minecraft:cyan_concrete
fill 379 209 469 379 212 469 minecraft:magenta_concrete
fill 379 209 471 379 212 471 minecraft:magenta_concrete
fill 380 209 470 380 212 470 minecraft:magenta_concrete
fill 377 210 464 377 211 469 minecraft:black_concrete
fill 377 210 472 378 210 477 minecraft:black_concrete
fill 377 210 480 378 210 485 minecraft:black_concrete
fill 377 210 488 378 210 493 minecraft:black_concrete
fill 377 210 496 378 210 501 minecraft:black_concrete
fill 377 210 504 382 211 504 minecraft:black_concrete
fill 378 210 465 378 210 471 minecraft:black_concrete
fill 378 210 478 378 210 479 minecraft:black_concrete
fill 378 210 486 378 210 487 minecraft:black_concrete
fill 378 210 494 378 210 495 minecraft:black_concrete
fill 378 210 502 378 210 503 minecraft:black_concrete
fill 379 210 465 416 210 465 minecraft:black_concrete
setblock 379 210 466 minecraft:light[level=14]
setblock 379 210 474 minecraft:light[level=14]
setblock 379 210 482 minecraft:light[level=14]
setblock 379 210 490 minecraft:light[level=14]
setblock 379 210 498 minecraft:light[level=14]
fill 379 210 503 417 210 503 minecraft:black_concrete
fill 380 210 464 385 211 464 minecraft:black_concrete
fill 380 210 469 380 212 469 minecraft:magenta_concrete
fill 380 210 471 380 212 471 minecraft:magenta_concrete
fill 385 210 504 390 211 504 minecraft:black_concrete
setblock 387 210 466 minecraft:light[level=14]
setblock 387 210 474 minecraft:light[level=14]
setblock 387 210 482 minecraft:light[level=14]
setblock 387 210 490 minecraft:light[level=14]
setblock 387 210 498 minecraft:light[level=14]
fill 388 210 464 393 211 464 minecraft:black_concrete
fill 393 210 504 398 211 504 minecraft:black_concrete
setblock 395 210 466 minecraft:light[level=14]
setblock 395 210 474 minecraft:light[level=14]
setblock 395 210 482 minecraft:light[level=14]
setblock 395 210 490 minecraft:light[level=14]
setblock 395 210 498 minecraft:light[level=14]
fill 396 210 464 401 211 464 minecraft:black_concrete
fill 401 210 504 406 211 504 minecraft:black_concrete
setblock 403 210 466 minecraft:light[level=14]
setblock 403 210 474 minecraft:light[level=14]
setblock 403 210 482 minecraft:light[level=14]
setblock 403 210 490 minecraft:light[level=14]
setblock 403 210 498 minecraft:light[level=14]
fill 404 210 464 409 211 464 minecraft:black_concrete
fill 409 210 504 414 211 504 minecraft:black_concrete
setblock 411 210 466 minecraft:light[level=14]
setblock 411 210 474 minecraft:light[level=14]
setblock 411 210 482 minecraft:light[level=14]
setblock 411 210 490 minecraft:light[level=14]
setblock 411 210 498 minecraft:light[level=14]
fill 412 210 464 417 211 464 minecraft:black_concrete
fill 416 210 466 416 210 502 minecraft:black_concrete
fill 417 210 467 417 211 472 minecraft:black_concrete
fill 417 210 475 417 211 480 minecraft:black_concrete
fill 417 210 483 417 211 488 minecraft:black_concrete
fill 417 210 491 417 211 496 minecraft:black_concrete
fill 417 210 499 417 211 502 minecraft:black_concrete
fill 417 210 504 417 211 504 minecraft:black_concrete
fill 377 211 472 377 211 477 minecraft:black_concrete
fill 377 211 480 377 211 485 minecraft:black_concrete
fill 377 211 488 377 211 493 minecraft:black_concrete
fill 377 211 496 377 211 501 minecraft:black_concrete
fill 378 211 469 378 212 471 minecraft:magenta_concrete
fill 381 211 470 381 212 470 minecraft:magenta_concrete
fill 396 211 489 398 213 491 minecraft:lime_concrete
setblock 417 211 503 minecraft:black_concrete
fill 379 212 468 380 212 468 minecraft:magenta_concrete
fill 379 212 472 380 212 472 minecraft:magenta_concrete
setblock 381 212 469 minecraft:magenta_concrete
setblock 381 212 471 minecraft:magenta_concrete
fill 377 213 465 382 225 469 minecraft:black_concrete
fill 377 213 472 382 225 475 minecraft:black_concrete
fill 378 213 470 382 225 471 minecraft:black_concrete
fill 376 214 468 376 219 468 minecraft:sea_lantern
fill 376 214 476 376 219 476 minecraft:sea_lantern
fill 376 214 484 376 219 484 minecraft:sea_lantern
fill 376 214 492 376 219 492 minecraft:sea_lantern
fill 376 214 500 376 219 500 minecraft:sea_lantern
fill 379 214 505 379 219 505 minecraft:sea_lantern
fill 383 214 463 383 219 463 minecraft:sea_lantern
fill 387 214 505 387 219 505 minecraft:sea_lantern
fill 391 214 463 391 219 463 minecraft:sea_lantern
fill 395 214 505 395 219 505 minecraft:sea_lantern
fill 399 214 463 399 219 463 minecraft:sea_lantern
fill 403 214 505 403 219 505 minecraft:sea_lantern
fill 407 214 463 407 219 463 minecraft:sea_lantern
fill 411 214 505 411 219 505 minecraft:sea_lantern
fill 415 214 463 415 219 463 minecraft:sea_lantern
fill 418 214 468 418 219 468 minecraft:sea_lantern
fill 418 214 476 418 219 476 minecraft:sea_lantern
fill 418 214 484 418 219 484 minecraft:sea_lantern
fill 418 214 492 418 219 492 minecraft:sea_lantern
fill 418 214 500 418 219 500 minecraft:sea_lantern
setblock 379 218 482 minecraft:light[level=14]
setblock 379 218 490 minecraft:light[level=14]
setblock 379 218 498 minecraft:light[level=14]
setblock 387 218 466 minecraft:light[level=14]
setblock 387 218 474 minecraft:light[level=14]
setblock 387 218 482 minecraft:light[level=14]
setblock 387 218 490 minecraft:light[level=14]
setblock 387 218 498 minecraft:light[level=14]
setblock 395 218 466 minecraft:light[level=14]
setblock 395 218 474 minecraft:light[level=14]
setblock 395 218 482 minecraft:light[level=14]
setblock 395 218 490 minecraft:light[level=14]
setblock 395 218 498 minecraft:light[level=14]
setblock 403 218 466 minecraft:light[level=14]
setblock 403 218 474 minecraft:light[level=14]
setblock 403 218 482 minecraft:light[level=14]
setblock 403 218 490 minecraft:light[level=14]
setblock 403 218 498 minecraft:light[level=14]
setblock 411 218 466 minecraft:light[level=14]
setblock 411 218 474 minecraft:light[level=14]
setblock 411 218 482 minecraft:light[level=14]
setblock 411 218 490 minecraft:light[level=14]
setblock 411 218 498 minecraft:light[level=14]
fill 376 220 468 376 232 468 minecraft:black_concrete
fill 376 220 476 376 232 476 minecraft:black_concrete
fill 376 220 484 376 229 484 minecraft:black_concrete
fill 376 220 492 376 232 492 minecraft:black_concrete
fill 376 220 500 376 233 500 minecraft:black_concrete
fill 379 220 505 379 232 505 minecraft:black_concrete
fill 383 220 463 383 229 463 minecraft:black_concrete
fill 387 220 505 387 230 505 minecraft:black_concrete
fill 391 220 463 391 228 463 minecraft:black_concrete
fill 395 220 505 395 232 505 minecraft:black_concrete
fill 399 220 463 399 232 463 minecraft:black_concrete
fill 403 220 505 403 232 505 minecraft:black_concrete
fill 407 220 463 407 232 463 minecraft:black_concrete
fill 411 220 505 411 228 505 minecraft:black_concrete
fill 415 220 463 415 229 463 minecraft:black_concrete
fill 418 220 468 418 232 468 minecraft:black_concrete
fill 418 220 476 418 232 476 minecraft:black_concrete
fill 418 220 484 418 232 484 minecraft:black_concrete
fill 418 220 492 418 230 492 minecraft:black_concrete
fill 418 220 500 418 229 500 minecraft:black_concrete
fill 377 224 464 377 225 464 minecraft:black_concrete
fill 377 224 476 378 224 477 minecraft:black_concrete
fill 377 224 480 378 224 485 minecraft:black_concrete
fill 377 224 488 378 224 493 minecraft:black_concrete
fill 377 224 496 378 224 501 minecraft:black_concrete
fill 377 224 504 382 225 504 minecraft:black_concrete
fill 378 224 478 378 224 479 minecraft:black_concrete
fill 378 224 486 378 224 487 minecraft:black_concrete
fill 378 224 494 378 224 495 minecraft:black_concrete
fill 378 224 502 378 224 503 minecraft:black_concrete
fill 379 224 503 417 224 503 minecraft:black_concrete
fill 380 224 464 385 225 464 minecraft:black_concrete
fill 383 224 465 416 224 465 minecraft:black_concrete
fill 385 224 504 390 225 504 minecraft:black_concrete
fill 388 224 464 393 225 464 minecraft:black_concrete
fill 393 224 504 398 225 504 minecraft:black_concrete
fill 396 224 464 401 225 464 minecraft:black_concrete
fill 401 224 504 406 225 504 minecraft:black_concrete
fill 404 224 464 409 225 464 minecraft:black_concrete
fill 409 224 504 414 225 504 minecraft:black_concrete
fill 412 224 464 417 225 464 minecraft:black_concrete
fill 416 224 466 416 224 502 minecraft:black_concrete
fill 417 224 467 417 225 472 minecraft:black_concrete
fill 417 224 475 417 225 480 minecraft:black_concrete
fill 417 224 483 417 225 488 minecraft:black_concrete
fill 417 224 491 417 225 496 minecraft:black_concrete
fill 417 224 499 417 225 502 minecraft:black_concrete
fill 417 224 504 417 225 504 minecraft:black_concrete
fill 377 225 476 377 225 477 minecraft:black_concrete
fill 377 225 480 377 225 485 minecraft:black_concrete
fill 377 225 488 377 225 493 minecraft:black_concrete
fill 377 225 496 377 225 501 minecraft:black_concrete
setblock 417 225 503 minecraft:black_concrete
setblock 379 226 466 minecraft:light[level=14]
setblock 379 226 474 minecraft:light[level=14]
setblock 379 226 482 minecraft:light[level=14]
setblock 379 226 490 minecraft:light[level=14]
setblock 379 226 498 minecraft:light[level=14]
setblock 387 226 466 minecraft:light[level=14]
setblock 387 226 474 minecraft:light[level=14]
setblock 387 226 482 minecraft:light[level=14]
setblock 387 226 490 minecraft:light[level=14]
setblock 387 226 498 minecraft:light[level=14]
setblock 395 226 466 minecraft:light[level=14]
setblock 395 226 474 minecraft:light[level=14]
setblock 395 226 482 minecraft:light[level=14]
setblock 395 226 490 minecraft:light[level=14]
setblock 395 226 498 minecraft:light[level=14]
setblock 403 226 466 minecraft:light[level=14]
setblock 403 226 474 minecraft:light[level=14]
setblock 403 226 482 minecraft:light[level=14]
setblock 403 226 490 minecraft:light[level=14]
setblock 403 226 498 minecraft:light[level=14]
setblock 411 226 466 minecraft:light[level=14]
setblock 411 226 474 minecraft:light[level=14]
setblock 411 226 482 minecraft:light[level=14]
setblock 411 226 490 minecraft:light[level=14]
setblock 411 226 498 minecraft:light[level=14]
fill 376 229 465 376 232 465 minecraft:black_concrete
setblock 376 229 466 minecraft:magenta_concrete
setblock 376 229 467 minecraft:black_concrete
fill 376 229 477 376 232 477 minecraft:black_concrete
setblock 376 229 478 minecraft:magenta_concrete
fill 376 229 479 376 230 480 minecraft:black_concrete
fill 376 229 486 376 229 487 minecraft:black_concrete
fill 376 229 488 376 230 488 minecraft:magenta_concrete
fill 376 229 489 376 229 491 minecraft:black_concrete
setblock 376 229 496 minecraft:magenta_concrete
fill 376 229 497 376 232 498 minecraft:black_concrete
setblock 377 229 463 minecraft:magenta_concrete
fill 378 229 463 382 232 463 minecraft:black_concrete
fill 386 229 463 386 230 463 minecraft:magenta_concrete
fill 387 229 463 387 232 463 minecraft:black_concrete
setblock 388 229 463 minecraft:magenta_concrete
fill 389 229 463 390 232 463 minecraft:black_concrete
setblock 391 229 463 minecraft:magenta_concrete
setblock 396 229 463 minecraft:magenta_concrete
setblock 401 229 505 minecraft:magenta_concrete
fill 404 229 505 405 232 505 minecraft:black_concrete
setblock 406 229 505 minecraft:magenta_concrete
setblock 408 229 505 minecraft:black_concrete
setblock 409 229 505 minecraft:magenta_concrete
setblock 410 229 505 minecraft:black_concrete
setblock 411 229 505 minecraft:magenta_concrete
fill 412 229 505 413 232 505 minecraft:black_concrete
setblock 414 229 505 minecraft:magenta_concrete
fill 415 229 505 415 232 505 minecraft:black_concrete
fill 417 229 505 417 232 505 minecraft:black_concrete
fill 418 229 464 418 232 464 minecraft:black_concrete
setblock 418 229 465 minecraft:magenta_concrete
fill 418 229 466 418 230 467 minecraft:black_concrete
fill 418 229 493 418 232 493 minecraft:black_concrete
fill 418 229 494 418 230 494 minecraft:magenta_concrete
fill 418 229 495 418 232 495 minecraft:black_concrete
setblock 418 229 497 minecraft:magenta_concrete
setblock 418 229 499 minecraft:magenta_concrete
setblock 418 229 505 minecraft:magenta_concrete
fill 376 230 466 376 232 466 minecraft:black_concrete
setblock 376 230 467 minecraft:magenta_concrete
setblock 376 230 472 minecraft:magenta_concrete
fill 376 230 473 376 232 475 minecraft:black_concrete
fill 376 230 478 376 232 478 minecraft:black_concrete
setblock 376 230 484 minecraft:magenta_concrete
setblock 376 230 486 minecraft:magenta_concrete
fill 376 230 487 376 232 487 minecraft:black_concrete
fill 376 230 489 376 230 490 minecraft:black_concrete
setblock 376 230 491 minecraft:magenta_concrete
fill 376 230 496 376 232 496 minecraft:black_concrete
fill 376 230 505 376 232 505 minecraft:black_concrete
fill 377 230 463 377 232 463 minecraft:black_concrete
fill 377 230 505 378 230 505 minecraft:magenta_concrete
fill 383 230 463 383 231 463 minecraft:magenta_concrete
fill 388 230 463 388 232 463 minecraft:black_concrete
fill 391 230 463 393 232 463 minecraft:black_concrete
setblock 394 230 463 minecraft:magenta_concrete
fill 395 230 463 396 232 463 minecraft:black_concrete
fill 396 230 505 398 232 505 minecraft:black_concrete
fill 397 230 463 397 231 463 minecraft:magenta_concrete
setblock 399 230 505 minecraft:magenta_concrete
fill 401 230 505 401 232 505 minecraft:black_concrete
fill 402 230 505 402 231 505 minecraft:magenta_concrete
setblock 405 230 463 minecraft:magenta_concrete
fill 406 230 505 406 233 505 minecraft:black_concrete
setblock 408 230 505 minecraft:magenta_concrete
setblock 409 230 505 minecraft:black_concrete
fill 410 230 505 410 231 505 minecraft:magenta_concrete
fill 411 230 505 411 232 505 minecraft:black_concrete
fill 414 230 505 414 232 505 minecraft:black_concrete
setblock 415 230 463 minecraft:magenta_concrete
fill 416 230 463 417 232 463 minecraft:black_concrete
setblock 418 230 463 minecraft:magenta_concrete
fill 418 230 465 418 232 465 minecraft:black_concrete
fill 418 230 497 418 232 497 minecraft:black_concrete
fill 418 230 499 418 232 499 minecraft:black_concrete
setblock 418 230 500 minecraft:magenta_concrete
fill 418 230 505 418 232 505 minecraft:black_concrete
fill 376 231 463 376 231 464 minecraft:magenta_concrete
fill 376 231 467 376 232 467 minecraft:black_concrete
fill 376 231 472 376 232 472 minecraft:black_concrete
fill 376 231 479 376 232 479 minecraft:black_concrete
setblock 376 231 480 minecraft:magenta_concrete
fill 376 231 484 376 232 484 minecraft:black_concrete
fill 376 231 486 376 233 486 minecraft:black_concrete
fill 376 231 488 376 232 489 minecraft:black_concrete
setblock 376 231 490 minecraft:magenta_concrete
fill 376 231 491 376 232 491 minecraft:black_concrete
setblock 376 231 504 minecraft:magenta_concrete
fill 377 231 464 377 232 465 minecraft:lime_concrete
fill 377 231 466 377 232 477 minecraft:cyan_concrete
fill 377 231 478 377 232 480 minecraft:lime_concrete
fill 377 231 481 377 232 492 minecraft:cyan_concrete
fill 377 231 493 377 232 495 minecraft:lime_concrete
fill 377 231 496 377 232 504 minecraft:cyan_concrete
fill 377 231 505 378 232 505 minecraft:black_concrete
fill 378 231 464 385 232 465 minecraft:cyan_concrete
fill 378 231 466 379 232 468 minecraft:lime_concrete
fill 378 231 469 379 232 480 minecraft:cyan_concrete
fill 378 231 481 379 232 483 minecraft:lime_concrete
fill 378 231 484 379 232 495 minecraft:cyan_concrete
fill 378 231 496 379 232 498 minecraft:lime_concrete
fill 378 231 499 379 232 504 minecraft:cyan_concrete
fill 380 231 466 387 232 468 minecraft:cyan_concrete
fill 380 231 469 381 232 471 minecraft:lime_concrete
fill 380 231 472 381 232 483 minecraft:cyan_concrete
fill 380 231 484 381 232 486 minecraft:lime_concrete
fill 380 231 487 381 232 498 minecraft:cyan_concrete
fill 380 231 499 381 232 501 minecraft:lime_concrete
fill 380 231 502 381 232 504 minecraft:cyan_concrete
fill 382 231 469 389 232 471 minecraft:cyan_concrete
fill 382 231 472 383 232 474 minecraft:lime_concrete
fill 382 231 475 383 232 486 minecraft:cyan_concrete
fill 382 231 487 383 232 489 minecraft:lime_concrete
fill 382 231 490 383 232 501 minecraft:cyan_concrete
fill 382 231 502 383 232 504 minecraft:lime_concrete
fill 384 231 472 391 232 474 minecraft:cyan_concrete
fill 384 231 475 385 232 477 minecraft:lime_concrete
fill 384 231 478 385 232 489 minecraft:cyan_concrete
fill 384 231 490 385 232 492 minecraft:lime_concrete
fill 384 231 493 385 232 504 minecraft:cyan_concrete
fill 386 231 463 386 232 463 minecraft:black_concrete
fill 386 231 464 387 232 465 minecraft:lime_concrete
fill 386 231 475 393 232 477 minecraft:cyan_concrete
fill 386 231 478 387 232 480 minecraft:lime_concrete
fill 386 231 481 387 232 492 minecraft:cyan_concrete
fill 386 231 493 387 232 495 minecraft:lime_concrete
fill 386 231 496 387 232 504 minecraft:cyan_concrete
setblock 387 231 505 minecraft:magenta_concrete
fill 388 231 464 395 232 465 minecraft:cyan_concrete
fill 388 231 466 389 232 468 minecraft:lime_concrete
fill 388 231 478 391 231 480 minecraft:cyan_concrete
fill 388 231 481 389 232 483 minecraft:lime_concrete
fill 388 231 484 389 232 495 minecraft:cyan_concrete
fill 388 231 496 389 232 498 minecraft:lime_concrete
fill 388 231 499 389 232 504 minecraft:cyan_concrete
fill 390 231 466 397 232 468 minecraft:cyan_concrete
fill 390 231 469 391 232 471 minecraft:lime_concrete
fill 390 231 481 390 231 483 minecraft:cyan_concrete
fill 390 231 484 391 232 486 minecraft:lime_concrete
fill 390 231 487 391 232 498 minecraft:cyan_concrete
fill 390 231 499 391 232 501 minecraft:lime_concrete
fill 390 231 502 391 232 504 minecraft:cyan_concrete
fill 390 231 505 390 232 505 minecraft:black_concrete
fill 391 231 482 391 231 483 minecraft:cyan_concrete
setblock 391 231 505 minecraft:magenta_concrete
fill 392 231 469 399 232 471 minecraft:cyan_concrete
fill 392 231 472 393 232 474 minecraft:lime_concrete
fill 392 231 478 392 231 479 minecraft:cyan_concrete
fill 392 231 483 392 231 486 minecraft:cyan_concrete
fill 392 231 487 393 232 489 minecraft:lime_concrete
fill 392 231 490 393 232 501 minecraft:cyan_concrete
fill 392 231 502 393 232 504 minecraft:lime_concrete
fill 392 231 505 393 232 505 minecraft:black_concrete
fill 393 231 478 395 231 478 minecraft:cyan_concrete
fill 393 231 484 399 231 486 minecraft:cyan_concrete
fill 394 231 463 394 232 463 minecraft:black_concrete
fill 394 231 472 401 232 474 minecraft:cyan_concrete
fill 394 231 475 395 232 477 minecraft:lime_concrete
fill 394 231 479 395 231 479 minecraft:cyan_concrete
fill 394 231 483 397 231 483 minecraft:cyan_concrete
fill 394 231 487 401 232 489 minecraft:cyan_concrete
fill 394 231 490 395 232 492 minecraft:lime_concrete
fill 394 231 493 395 232 504 minecraft:cyan_concrete
setblock 395 231 480 minecraft:cyan_concrete
fill 395 231 482 397 231 482 minecraft:cyan_concrete
fill 396 231 464 397 232 465 minecraft:lime_concrete
fill 396 231 475 403 232 477 minecraft:cyan_concrete
fill 396 231 478 397 231 480 minecraft:lime_concrete
fill 396 231 481 397 231 481 minecraft:cyan_concrete
fill 396 231 490 403 232 492 minecraft:cyan_concrete
fill 396 231 493 397 232 495 minecraft:lime_concrete
fill 396 231 496 397 232 504 minecraft:cyan_concrete
fill 398 231 464 405 232 465 minecraft:cyan_concrete
fill 398 231 466 399 232 468 minecraft:lime_concrete
fill 398 231 478 405 232 480 minecraft:cyan_concrete
fill 398 231 481 399 232 483 minecraft:lime_concrete
fill 398 231 493 405 232 495 minecraft:cyan_concrete
fill 398 231 496 399 232 498 minecraft:lime_concrete
fill 398 231 499 399 232 504 minecraft:cyan_concrete
fill 399 231 505 399 232 505 minecraft:black_concrete
fill 400 231 466 407 232 468 minecraft:cyan_concrete
fill 400 231 469 401 232 471 minecraft:lime_concrete
fill 400 231 481 407 232 483 minecraft:cyan_concrete
fill 400 231 484 401 232 486 minecraft:lime_concrete
fill 400 231 496 407 232 498 minecraft:cyan_concrete
fill 400 231 499 401 232 501 minecraft:lime_concrete
fill 400 231 502 401 232 504 minecraft:cyan_concrete
fill 402 231 469 409 232 471 minecraft:cyan_concrete
fill 402 231 472 403 232 474 minecraft:lime_concrete
fill 402 231 484 409 232 486 minecraft:cyan_concrete
fill 402 231 487 403 232 489 minecraft:lime_concrete
fill 402 231 499 409 232 501 minecraft:cyan_concrete
fill 402 231 502 403 232 504 minecraft:lime_concrete
fill 404 231 472 411 232 474 minecraft:cyan_concrete
fill 404 231 475 405 232 477 minecraft:lime_concrete
fill 404 231 487 411 232 489 minecraft:cyan_concrete
fill 404 231 490 405 232 492 minecraft:lime_concrete
fill 404 231 502 411 232 504 minecraft:cyan_concrete
fill 405 231 463 405 232 463 minecraft:black_concrete
fill 406 231 464 407 232 465 minecraft:lime_concrete
fill 406 231 475 413 232 477 minecraft:cyan_concrete
fill 406 231 478 407 232 480 minecraft:lime_concrete
fill 406 231 490 413 232 492 minecraft:cyan_concrete
fill 406 231 493 407 232 495 minecraft:lime_concrete
fill 408 231 464 415 232 465 minecraft:cyan_concrete
fill 408 231 466 409 232 468 minecraft:lime_concrete
fill 408 231 478 415 232 480 minecraft:cyan_concrete
fill 408 231 481 409 232 483 minecraft:lime_concrete
fill 408 231 493 415 232 495 minecraft:cyan_concrete
fill 408 231 496 409 232 498 minecraft:lime_concrete
fill 408 231 505 408 233 505 minecraft:black_concrete
setblock 409 231 505 minecraft:magenta_concrete
fill 410 231 466 417 232 468 minecraft:cyan_concrete
fill 410 231 469 411 232 471 minecraft:lime_concrete
fill 410 231 481 417 232 483 minecraft:cyan_concrete
fill 410 231 484 411 232 486 minecraft:lime_concrete
fill 410 231 496 417 232 498 minecraft:cyan_concrete
fill 410 231 499 411 232 501 minecraft:lime_concrete
fill 412 231 469 417 232 471 minecraft:cyan_concrete
fill 412 231 472 413 232 474 minecraft:lime_concrete
fill 412 231 484 417 232 486 minecraft:cyan_concrete
fill 412 231 487 413 232 489 minecraft:lime_concrete
fill 412 231 499 417 232 501 minecraft:cyan_concrete
fill 412 231 502 413 232 504 minecraft:lime_concrete
fill 414 231 472 417 232 474 minecraft:cyan_concrete
fill 414 231 475 415 232 477 minecraft:lime_concrete
fill 414 231 487 417 232 489 minecraft:cyan_concrete
fill 414 231 490 415 232 492 minecraft:lime_concrete
fill 414 231 502 417 232 504 minecraft:cyan_concrete
fill 415 231 463 415 232 463 minecraft:black_concrete
fill 416 231 464 417 232 465 minecraft:lime_concrete
fill 416 231 475 417 232 477 minecraft:cyan_concrete
fill 416 231 478 417 232 480 minecraft:lime_concrete
fill 416 231 490 417 232 492 minecraft:cyan_concrete
fill 416 231 493 417 232 495 minecraft:lime_concrete
fill 418 231 463 418 232 463 minecraft:black_concrete
setblock 418 231 466 minecraft:magenta_concrete
fill 418 231 467 418 233 467 minecraft:black_concrete
setblock 418 231 472 minecraft:magenta_concrete
fill 418 231 473 418 232 473 minecraft:black_concrete
setblock 418 231 474 minecraft:magenta_concrete
setblock 418 231 492 minecraft:magenta_concrete
fill 418 231 494 418 232 494 minecraft:black_concrete
fill 418 231 500 418 232 500 minecraft:black_concrete
fill 376 232 463 376 232 464 minecraft:black_concrete
setblock 376 232 480 minecraft:black_concrete
setblock 376 232 490 minecraft:black_concrete
setblock 376 232 504 minecraft:black_concrete
setblock 383 232 463 minecraft:black_concrete
setblock 387 232 505 minecraft:black_concrete
fill 388 232 478 389 232 480 minecraft:cyan_concrete
fill 390 232 478 390 232 479 minecraft:cyan_concrete
fill 390 232 480 390 232 482 minecraft:sea_lantern
setblock 390 232 483 minecraft:cyan_concrete
setblock 391 232 478 minecraft:cyan_concrete
fill 391 232 479 391 232 480 minecraft:sea_lantern
fill 391 232 482 391 232 483 minecraft:sea_lantern
setblock 391 232 505 minecraft:black_concrete
fill 392 232 478 392 232 479 minecraft:sea_lantern
fill 392 232 483 392 232 484 minecraft:sea_lantern
fill 392 232 485 399 232 486 minecraft:cyan_concrete
fill 393 232 478 394 232 478 minecraft:sea_lantern
fill 393 232 484 394 232 484 minecraft:sea_lantern
fill 394 232 479 395 232 479 minecraft:sea_lantern
fill 394 232 483 395 232 483 minecraft:sea_lantern
setblock 395 232 478 minecraft:cyan_concrete
fill 395 232 480 396 232 480 minecraft:sea_lantern
fill 395 232 482 396 232 482 minecraft:sea_lantern
fill 395 232 484 399 232 484 minecraft:cyan_concrete
fill 396 232 478 397 232 479 minecraft:lime_concrete
setblock 396 232 481 minecraft:sea_lantern
fill 396 232 483 397 232 483 minecraft:cyan_concrete
setblock 397 232 463 minecraft:black_concrete
setblock 397 232 480 minecraft:lime_concrete
fill 397 232 481 397 232 482 minecraft:cyan_concrete
setblock 402 232 505 minecraft:black_concrete
fill 409 232 505 410 232 505 minecraft:black_concrete
setblock 418 232 466 minecraft:black_concrete
setblock 418 232 472 minecraft:black_concrete
setblock 418 232 474 minecraft:black_concrete
setblock 418 232 492 minecraft:black_concrete
fill 376 233 463 376 241 469 minecraft:magenta_concrete
fill 376 233 472 376 233 485 minecraft:magenta_concrete
fill 376 233 487 376 233 496 minecraft:magenta_concrete
setblock 376 233 497 minecraft:black_concrete
fill 376 233 498 376 307 499 minecraft:magenta_concrete
fill 376 233 501 376 307 502 minecraft:magenta_concrete
fill 376 233 504 376 307 505 minecraft:magenta_concrete
fill 377 233 463 395 233 463 minecraft:magenta_concrete
setblock 377 233 505 minecraft:black_concrete
fill 378 233 505 384 241 505 minecraft:magenta_concrete
setblock 385 233 505 minecraft:black_concrete
fill 386 233 505 388 234 505 minecraft:magenta_concrete
fill 390 233 505 393 307 505 minecraft:magenta_concrete
fill 395 233 505 405 234 505 minecraft:magenta_concrete
setblock 396 233 463 minecraft:black_concrete
fill 397 233 463 397 307 463 minecraft:magenta_concrete
fill 399 233 463 405 234 463 minecraft:magenta_concrete
fill 407 233 463 410 233 463 minecraft:magenta_concrete
fill 407 233 505 407 307 505 minecraft:magenta_concrete
fill 409 233 505 418 234 505 minecraft:magenta_concrete
setblock 411 233 463 minecraft:black_concrete
fill 412 233 463 418 233 463 minecraft:magenta_concrete
fill 418 233 464 418 307 466 minecraft:magenta_concrete
fill 418 233 468 418 234 477 minecraft:magenta_concrete
setblock 418 233 478 minecraft:black_concrete
fill 418 233 479 418 233 504 minecraft:magenta_concrete
fill 376 234 470 376 234 477 minecraft:magenta_concrete
setblock 376 234 478 minecraft:black_concrete
fill 376 234 479 376 234 490 minecraft:magenta_concrete
setblock 376 234 491 minecraft:black_concrete
fill 376 234 492 376 241 497 minecraft:magenta_concrete
fill 376 234 500 376 241 500 minecraft:magenta_concrete
fill 376 234 503 376 307 503 minecraft:magenta_concrete
fill 377 234 463 378 234 463 minecraft:magenta_concrete
fill 377 234 505 377 307 505 minecraft:magenta_concrete
setblock 379 234 463 minecraft:black_concrete
setblock 379 234 466 minecraft:light[level=14]
setblock 379 234 474 minecraft:light[level=14]
setblock 379 234 482 minecraft:light[level=14]
setblock 379 234 490 minecraft:light[level=14]
setblock 379 234 498 minecraft:light[level=14]
fill 380 234 463 385 234 463 minecraft:magenta_concrete
fill 385 234 505 385 307 505 minecraft:magenta_concrete
setblock 386 234 463 minecraft:black_concrete
fill 387 234 463 391 241 463 minecraft:magenta_concrete
setblock 387 234 466 minecraft:light[level=14]
setblock 387 234 474 minecraft:light[level=14]
setblock 387 234 482 minecraft:light[level=14]
setblock 387 234 490 minecraft:light[level=14]
setblock 387 234 498 minecraft:light[level=14]
fill 389 234 505 389 307 505 minecraft:magenta_concrete
setblock 392 234 463 minecraft:black_concrete
fill 393 234 463 396 234 463 minecraft:magenta_concrete
fill 394 234 505 394 307 505 minecraft:magenta_concrete
setblock 395 234 466 minecraft:light[level=14]
setblock 395 234 474 minecraft:light[level=14]
setblock 395 234 482 minecraft:light[level=14]
setblock 395 234 490 minecraft:light[level=14]
setblock 395 234 498 minecraft:light[level=14]
setblock 398 234 463 minecraft:magenta_concrete
setblock 403 234 466 minecraft:light[level=14]
setblock 403 234 474 minecraft:light[level=14]
setblock 403 234 482 minecraft:light[level=14]
setblock 403 234 490 minecraft:light[level=14]
setblock 403 234 498 minecraft:light[level=14]
fill 406 234 463 406 307 463 minecraft:magenta_concrete
fill 406 234 505 406 307 505 minecraft:magenta_concrete
setblock 407 234 463 minecraft:black_concrete
fill 408 234 463 409 307 463 minecraft:magenta_concrete
fill 408 234 505 408 307 505 minecraft:magenta_concrete
setblock 410 234 463 minecraft:black_concrete
fill 411 234 463 417 241 463 minecraft:magenta_concrete
setblock 411 234 466 minecraft:light[level=14]
setblock 411 234 474 minecraft:light[level=14]
setblock 411 234 482 minecraft:light[level=14]
setblock 411 234 490 minecraft:light[level=14]
setblock 411 234 498 minecraft:light[level=14]
setblock 418 234 463 minecraft:black_concrete
setblock 418 234 467 minecraft:magenta_concrete
fill 418 234 478 418 234 481 minecraft:magenta_concrete
setblock 418 234 482 minecraft:black_concrete
fill 418 234 483 418 234 495 minecraft:magenta_concrete
fill 418 234 496 418 235 496 minecraft:black_concrete
fill 418 234 497 418 234 504 minecraft:magenta_concrete
setblock 376 235 470 minecraft:black_concrete
fill 376 235 471 376 307 471 minecraft:magenta_concrete
setblock 376 235 472 minecraft:black_concrete
fill 376 235 473 376 241 482 minecraft:magenta_concrete
setblock 376 235 483 minecraft:black_concrete
fill 376 235 484 376 241 488 minecraft:magenta_concrete
setblock 376 235 489 minecraft:black_concrete
fill 376 235 490 376 307 491 minecraft:magenta_concrete
setblock 377 235 463 minecraft:black_concrete
fill 378 235 463 380 307 463 minecraft:magenta_concrete
setblock 381 235 463 minecraft:black_concrete
fill 382 235 463 386 241 463 minecraft:magenta_concrete
setblock 386 235 505 minecraft:black_concrete
fill 387 235 505 388 241 505 minecraft:magenta_concrete
fill 392 235 463 392 307 463 minecraft:magenta_concrete
setblock 393 235 463 minecraft:black_concrete
fill 394 235 463 394 307 463 minecraft:magenta_concrete
setblock 395 235 463 minecraft:black_concrete
fill 395 235 505 396 241 505 minecraft:magenta_concrete
fill 396 235 463 396 307 463 minecraft:magenta_concrete
setblock 397 235 505 minecraft:black_concrete
setblock 398 235 463 minecraft:black_concrete
fill 398 235 505 402 307 505 minecraft:magenta_concrete
fill 399 235 463 404 241 463 minecraft:magenta_concrete
setblock 403 235 505 minecraft:black_concrete
fill 404 235 505 405 307 505 minecraft:magenta_concrete
setblock 405 235 463 minecraft:black_concrete
fill 407 235 463 407 241 463 minecraft:magenta_concrete
fill 409 235 505 410 307 505 minecraft:magenta_concrete
fill 410 235 463 410 307 463 minecraft:magenta_concrete
setblock 411 235 505 minecraft:black_concrete
fill 412 235 505 418 307 505 minecraft:magenta_concrete
fill 418 235 463 418 307 463 minecraft:magenta_concrete
setblock 418 235 467 minecraft:black_concrete
fill 418 235 468 418 241 469 minecraft:magenta_concrete
setblock 418 235 470 minecraft:black_concrete
fill 418 235 471 418 307 474 minecraft:magenta_concrete
setblock 418 235 475 minecraft:black_concrete
fill 418 235 476 418 241 480 minecraft:magenta_concrete
setblock 418 235 481 minecraft:black_concrete
fill 418 235 482 418 241 486 minecraft:magenta_concrete
fill 418 235 487 418 235 488 minecraft:black_concrete
fill 418 235 489 418 241 495 minecraft:magenta_concrete
fill 418 235 497 418 241 501 minecraft:magenta_concrete
setblock 418 235 502 minecraft:black_concrete
fill 418 235 503 418 307 504 minecraft:magenta_concrete
fill 376 236 470 376 307 470 minecraft:magenta_concrete
fill 376 236 472 376 307 472 minecraft:magenta_concrete
fill 376 236 483 376 307 483 minecraft:magenta_concrete
fill 376 236 489 376 307 489 minecraft:magenta_concrete
fill 377 236 463 377 307 463 minecraft:magenta_concrete
fill 377 236 470 377 273 471 minecraft:black_concrete
fill 377 236 478 377 273 479 minecraft:black_concrete
fill 377 236 486 377 273 487 minecraft:black_concrete
fill 377 236 494 377 273 495 minecraft:black_concrete
fill 377 236 502 377 273 503 minecraft:black_concrete
fill 378 236 464 379 273 464 minecraft:black_concrete
fill 381 236 463 381 307 463 minecraft:magenta_concrete
fill 383 236 504 384 273 504 minecraft:black_concrete
fill 386 236 464 387 273 464 minecraft:black_concrete
fill 386 236 505 386 307 505 minecraft:magenta_concrete
fill 391 236 504 392 273 504 minecraft:black_concrete
fill 393 236 463 393 307 463 minecraft:magenta_concrete
fill 394 236 464 395 273 464 minecraft:black_concrete
fill 395 236 463 395 307 463 minecraft:magenta_concrete
fill 397 236 505 397 307 505 minecraft:magenta_concrete
fill 398 236 463 398 307 463 minecraft:magenta_concrete
fill 399 236 504 400 273 504 minecraft:black_concrete
fill 402 236 464 403 273 464 minecraft:black_concrete
fill 403 236 505 403 241 505 minecraft:magenta_concrete
fill 405 236 463 405 307 463 minecraft:magenta_concrete
fill 407 236 504 408 261 504 minecraft:black_concrete
fill 410 236 464 411 273 464 minecraft:black_concrete
fill 411 236 505 411 241 505 minecraft:magenta_concrete
fill 415 236 504 416 273 504 minecraft:black_concrete
fill 417 236 465 417 273 466 minecraft:black_concrete
fill 417 236 473 417 273 474 minecraft:black_concrete
fill 417 236 481 417 273 482 minecraft:black_concrete
fill 417 236 489 417 273 490 minecraft:black_concrete
fill 417 236 497 417 273 498 minecraft:black_concrete
fill 418 236 467 418 307 467 minecraft:magenta_concrete
fill 418 236 470 418 307 470 minecraft:magenta_concrete
fill 418 236 475 418 307 475 minecraft:magenta_concrete
fill 418 236 481 418 307 481 minecraft:magenta_concrete
fill 418 236 487 418 307 488 minecraft:magenta_concrete
fill 418 236 496 418 307 496 minecraft:magenta_concrete
fill 418 236 502 418 307 502 minecraft:magenta_concrete
fill 377 238 464 377 239 469 minecraft:black_concrete
fill 377 238 472 378 238 477 minecraft:black_concrete
fill 377 238 480 378 238 485 minecraft:black_concrete
fill 377 238 488 378 238 493 minecraft:black_concrete
fill 377 238 496 378 238 501 minecraft:black_concrete
fill 377 238 504 382 239 504 minecraft:black_concrete
fill 378 238 465 378 238 471 minecraft:black_concrete
fill 378 238 478 378 238 479 minecraft:black_concrete
fill 378 238 486 378 238 487 minecraft:black_concrete
fill 378 238 494 378 238 495 minecraft:black_concrete
fill 378 238 502 378 238 503 minecraft:black_concrete
fill 379 238 465 416 238 465 minecraft:black_concrete
fill 379 238 503 417 238 503 minecraft:black_concrete
fill 380 238 464 385 239 464 minecraft:black_concrete
fill 385 238 504 390 239 504 minecraft:black_concrete
fill 388 238 464 393 239 464 minecraft:black_concrete
fill 393 238 504 398 239 504 minecraft:black_concrete
fill 396 238 464 401 239 464 minecraft:black_concrete
fill 401 238 504 406 239 504 minecraft:black_concrete
fill 404 238 464 409 239 464 minecraft:black_concrete
fill 409 238 504 414 239 504 minecraft:black_concrete
fill 412 238 464 417 239 464 minecraft:black_concrete
fill 416 238 466 416 238 502 minecraft:black_concrete
fill 417 238 467 417 239 472 minecraft:black_concrete
fill 417 238 475 417 239 480 minecraft:black_concrete
fill 417 238 483 417 239 488 minecraft:black_concrete
fill 417 238 491 417 239 496 minecraft:black_concrete
fill 417 238 499 417 239 502 minecraft:black_concrete
fill 417 238 504 417 239 504 minecraft:black_concrete
fill 377 239 472 377 239 477 minecraft:black_concrete
fill 377 239 480 377 239 485 minecraft:black_concrete
fill 377 239 488 377 239 493 minecraft:black_concrete
fill 377 239 496 377 239 501 minecraft:black_concrete
setblock 417 239 503 minecraft:black_concrete
fill 376 242 463 376 307 467 minecraft:magenta_concrete
fill 376 242 468 376 247 468 minecraft:sea_lantern
fill 376 242 469 376 307 469 minecraft:magenta_concrete
fill 376 242 473 376 307 475 minecraft:magenta_concrete
fill 376 242 476 376 247 476 minecraft:sea_lantern
fill 376 242 477 376 307 482 minecraft:magenta_concrete
fill 376 242 484 376 247 484 minecraft:sea_lantern
fill 376 242 485 376 307 488 minecraft:magenta_concrete
fill 376 242 492 376 247 492 minecraft:sea_lantern
fill 376 242 493 376 307 497 minecraft:magenta_concrete
fill 376 242 500 376 247 500 minecraft:sea_lantern
fill 378 242 505 378 307 505 minecraft:magenta_concrete
setblock 379 242 466 minecraft:light[level=14]
setblock 379 242 474 minecraft:light[level=14]
setblock 379 242 482 minecraft:light[level=14]
setblock 379 242 490 minecraft:light[level=14]
setblock 379 242 498 minecraft:light[level=14]
fill 379 242 505 379 247 505 minecraft:sea_lantern
fill 380 242 505 384 307 505 minecraft:magenta_concrete
fill 382 242 463 382 307 463 minecraft:magenta_concrete
fill 383 242 463 383 247 463 minecraft:sea_lantern
fill 384 242 463 390 307 463 minecraft:magenta_concrete
setblock 387 242 466 minecraft:light[level=14]
setblock 387 242 474 minecraft:light[level=14]
setblock 387 242 482 minecraft:light[level=14]
setblock 387 242 490 minecraft:light[level=14]
setblock 387 242 498 minecraft:light[level=14]
fill 387 242 505 387 247 505 minecraft:sea_lantern
fill 388 242 505 388 307 505 minecraft:magenta_concrete
fill 391 242 463 391 247 463 minecraft:sea_lantern
setblock 395 242 466 minecraft:light[level=14]
setblock 395 242 474 minecraft:light[level=14]
setblock 395 242 482 minecraft:light[level=14]
setblock 395 242 490 minecraft:light[level=14]
setblock 395 242 498 minecraft:light[level=14]
fill 395 242 505 395 247 505 minecraft:sea_lantern
fill 396 242 505 396 307 505 minecraft:magenta_concrete
fill 399 242 463 399 247 463 minecraft:sea_lantern
fill 400 242 463 404 307 463 minecraft:magenta_concrete
setblock 403 242 466 minecraft:light[level=14]
setblock 403 242 474 minecraft:light[level=14]
setblock 403 242 482 minecraft:light[level=14]
setblock 403 242 490 minecraft:light[level=14]
setblock 403 242 498 minecraft:light[level=14]
fill 403 242 505 403 247 505 minecraft:sea_lantern
fill 407 242 463 407 247 463 minecraft:sea_lantern
fill 411 242 463 414 307 463 minecraft:magenta_concrete
setblock 411 242 466 minecraft:light[level=14]
setblock 411 242 474 minecraft:light[level=14]
setblock 411 242 482 minecraft:light[level=14]
setblock 411 242 490 minecraft:light[level=14]
setblock 411 242 498 minecraft:light[level=14]
fill 411 242 505 411 247 505 minecraft:sea_lantern
fill 415 242 463 415 247 463 minecraft:sea_lantern
fill 416 242 463 417 307 463 minecraft:magenta_concrete
fill 418 242 468 418 247 468 minecraft:sea_lantern
fill 418 242 469 418 307 469 minecraft:magenta_concrete
fill 418 242 476 418 247 476 minecraft:sea_lantern
fill 418 242 477 418 307 480 minecraft:magenta_concrete
fill 418 242 482 418 307 483 minecraft:magenta_concrete
fill 418 242 484 418 247 484 minecraft:sea_lantern
fill 418 242 485 418 307 486 minecraft:magenta_concrete
fill 418 242 489 418 307 491 minecraft:magenta_concrete
fill 418 242 492 418 247 492 minecraft:sea_lantern
fill 418 242 493 418 307 495 minecraft:magenta_concrete
fill 418 242 497 418 307 499 minecraft:magenta_concrete
fill 418 242 500 418 247 500 minecraft:sea_lantern
fill 418 242 501 418 307 501 minecraft:magenta_concrete
fill 393 243 469 396 246 472 minecraft:lime_concrete
fill 398 247 469 401 250 472 minecraft:cyan_concrete
fill 376 248 468 376 255 468 minecraft:magenta_concrete
fill 376 248 476 376 255 476 minecraft:magenta_concrete
fill 376 248 484 376 255 484 minecraft:magenta_concrete
fill 376 248 492 376 255 492 minecraft:magenta_concrete
fill 376 248 500 376 255 500 minecraft:magenta_concrete
fill 379 248 505 379 255 505 minecraft:magenta_concrete
fill 383 248 463 383 255 463 minecraft:magenta_concrete
fill 387 248 505 387 255 505 minecraft:magenta_concrete
fill 391 248 463 391 255 463 minecraft:magenta_concrete
fill 395 248 505 395 255 505 minecraft:magenta_concrete
fill 399 248 463 399 255 463 minecraft:magenta_concrete
fill 403 248 505 403 255 505 minecraft:magenta_concrete
fill 407 248 463 407 255 463 minecraft:magenta_concrete
fill 411 248 505 411 255 505 minecraft:magenta_concrete
fill 415 248 463 415 255 463 minecraft:magenta_concrete
fill 418 248 468 418 255 468 minecraft:magenta_concrete
fill 418 248 476 418 255 476 minecraft:magenta_concrete
fill 418 248 484 418 255 484 minecraft:magenta_concrete
fill 418 248 492 418 255 492 minecraft:magenta_concrete
fill 418 248 500 418 255 500 minecraft:magenta_concrete
setblock 379 250 466 minecraft:light[level=14]
setblock 379 250 474 minecraft:light[level=14]
setblock 379 250 482 minecraft:light[level=14]
setblock 379 250 490 minecraft:light[level=14]
setblock 379 250 498 minecraft:light[level=14]
setblock 387 250 466 minecraft:light[level=14]
setblock 387 250 474 minecraft:light[level=14]
setblock 387 250 482 minecraft:light[level=14]
setblock 387 250 490 minecraft:light[level=14]
setblock 387 250 498 minecraft:light[level=14]
setblock 395 250 466 minecraft:light[level=14]
setblock 395 250 474 minecraft:light[level=14]
setblock 395 250 482 minecraft:light[level=14]
setblock 395 250 490 minecraft:light[level=14]
setblock 395 250 498 minecraft:light[level=14]
setblock 403 250 466 minecraft:light[level=14]
setblock 403 250 474 minecraft:light[level=14]
setblock 403 250 482 minecraft:light[level=14]
setblock 403 250 490 minecraft:light[level=14]
setblock 403 250 498 minecraft:light[level=14]
setblock 411 250 466 minecraft:light[level=14]
setblock 411 250 474 minecraft:light[level=14]
setblock 411 250 482 minecraft:light[level=14]
setblock 411 250 490 minecraft:light[level=14]
setblock 411 250 498 minecraft:light[level=14]
fill 377 252 464 377 253 469 minecraft:black_concrete
fill 377 252 472 378 252 477 minecraft:black_concrete
fill 377 252 480 378 252 485 minecraft:black_concrete
fill 377 252 488 378 252 493 minecraft:black_concrete
fill 377 252 496 378 252 501 minecraft:black_concrete
fill 377 252 504 382 253 504 minecraft:black_concrete
fill 378 252 465 378 252 471 minecraft:black_concrete
fill 378 252 478 378 252 479 minecraft:black_concrete
fill 378 252 486 378 252 487 minecraft:black_concrete
fill 378 252 494 378 252 495 minecraft:black_concrete
fill 378 252 502 378 252 503 minecraft:black_concrete
fill 379 252 465 416 252 465 minecraft:black_concrete
fill 379 252 503 417 252 503 minecraft:black_concrete
fill 380 252 464 385 253 464 minecraft:black_concrete
fill 385 252 504 390 253 504 minecraft:black_concrete
fill 388 252 464 393 253 464 minecraft:black_concrete
fill 393 252 504 398 253 504 minecraft:black_concrete
fill 396 252 464 401 253 464 minecraft:black_concrete
fill 401 252 504 406 253 504 minecraft:black_concrete
fill 404 252 464 409 253 464 minecraft:black_concrete
fill 409 252 504 414 253 504 minecraft:black_concrete
fill 412 252 464 417 253 464 minecraft:black_concrete
fill 416 252 466 416 252 502 minecraft:black_concrete
fill 417 252 467 417 253 472 minecraft:black_concrete
fill 417 252 475 417 253 480 minecraft:black_concrete
fill 417 252 483 417 253 488 minecraft:black_concrete
fill 417 252 491 417 253 496 minecraft:black_concrete
fill 417 252 499 417 253 502 minecraft:black_concrete
fill 417 252 504 417 253 504 minecraft:black_concrete
fill 377 253 472 377 253 477 minecraft:black_concrete
fill 377 253 480 377 253 485 minecraft:black_concrete
fill 377 253 488 377 253 493 minecraft:black_concrete
fill 377 253 496 377 253 501 minecraft:black_concrete
setblock 417 253 503 minecraft:black_concrete
fill 409 255 499 409 260 499 minecraft:magenta_concrete
fill 411 255 469 414 258 472 minecraft:gold_block
fill 376 256 468 376 261 468 minecraft:sea_lantern
fill 376 256 476 376 261 476 minecraft:sea_lantern
fill 376 256 484 376 261 484 minecraft:sea_lantern
fill 376 256 492 376 261 492 minecraft:sea_lantern
fill 376 256 500 376 261 500 minecraft:sea_lantern
fill 379 256 505 379 261 505 minecraft:sea_lantern
fill 380 256 501 381 257 502 minecraft:white_concrete
fill 383 256 463 383 261 463 minecraft:sea_lantern
fill 387 256 505 387 261 505 minecraft:sea_lantern
fill 391 256 463 391 261 463 minecraft:sea_lantern
fill 395 256 505 395 261 505 minecraft:sea_lantern
fill 399 256 463 399 261 463 minecraft:sea_lantern
fill 403 256 505 403 261 505 minecraft:sea_lantern
fill 407 256 463 407 261 463 minecraft:sea_lantern
fill 411 256 505 411 261 505 minecraft:sea_lantern
fill 415 256 463 415 261 463 minecraft:sea_lantern
fill 418 256 468 418 261 468 minecraft:sea_lantern
fill 418 256 476 418 261 476 minecraft:sea_lantern
fill 418 256 484 418 261 484 minecraft:sea_lantern
fill 418 256 492 418 261 492 minecraft:sea_lantern
fill 418 256 500 418 261 500 minecraft:sea_lantern
fill 408 257 499 408 260 499 minecraft:magenta_concrete
fill 409 257 498 409 260 498 minecraft:magenta_concrete
fill 410 257 499 410 260 499 minecraft:magenta_concrete
setblock 379 258 466 minecraft:light[level=14]
setblock 379 258 474 minecraft:light[level=14]
setblock 379 258 482 minecraft:light[level=14]
setblock 379 258 490 minecraft:light[level=14]
setblock 379 258 498 minecraft:light[level=14]
fill 380 258 481 382 260 483 minecraft:moss_block
setblock 387 258 466 minecraft:light[level=14]
setblock 387 258 474 minecraft:light[level=14]
setblock 387 258 482 minecraft:light[level=14]
setblock 387 258 490 minecraft:light[level=14]
setblock 387 258 498 minecraft:light[level=14]
setblock 395 258 466 minecraft:light[level=14]
setblock 395 258 474 minecraft:light[level=14]
setblock 395 258 482 minecraft:light[level=14]
setblock 395 258 490 minecraft:light[level=14]
setblock 395 258 498 minecraft:light[level=14]
setblock 403 258 466 minecraft:light[level=14]
setblock 403 258 474 minecraft:light[level=14]
setblock 403 258 482 minecraft:light[level=14]
setblock 403 258 490 minecraft:light[level=14]
setblock 403 258 498 minecraft:light[level=14]
fill 408 258 498 408 260 498 minecraft:magenta_concrete
fill 408 258 500 410 260 500 minecraft:magenta_concrete
fill 410 258 498 410 260 498 minecraft:magenta_concrete
setblock 411 258 466 minecraft:light[level=14]
setblock 411 258 474 minecraft:light[level=14]
setblock 411 258 482 minecraft:light[level=14]
setblock 411 258 490 minecraft:light[level=14]
setblock 411 258 498 minecraft:light[level=14]
fill 407 259 492 410 261 495 minecraft:moss_block
fill 407 259 499 407 260 499 minecraft:magenta_concrete
fill 408 259 497 410 260 497 minecraft:magenta_concrete
fill 411 259 499 411 260 499 minecraft:magenta_concrete
setblock 407 260 498 minecraft:magenta_concrete
setblock 407 260 500 minecraft:magenta_concrete
fill 408 260 501 410 260 501 minecraft:magenta_concrete
setblock 411 260 498 minecraft:magenta_concrete
setblock 411 260 500 minecraft:magenta_concrete
fill 389 261 489 392 264 492 minecraft:cyan_concrete
fill 406 261 494 406 261 504 minecraft:black_concrete
fill 407 261 496 412 261 503 minecraft:black_concrete
fill 409 261 504 412 261 504 minecraft:black_concrete
fill 411 261 494 412 261 495 minecraft:black_concrete
fill 376 262 468 376 269 468 minecraft:magenta_concrete
fill 376 262 476 376 269 476 minecraft:magenta_concrete
fill 376 262 484 376 269 484 minecraft:magenta_concrete
fill 376 262 492 376 269 492 minecraft:magenta_concrete
fill 376 262 500 376 269 500 minecraft:magenta_concrete
fill 379 262 505 379 269 505 minecraft:magenta_concrete
fill 383 262 463 383 269 463 minecraft:magenta_concrete
fill 387 262 505 387 269 505 minecraft:magenta_concrete
fill 391 262 463 391 269 463 minecraft:magenta_concrete
fill 395 262 505 395 269 505 minecraft:magenta_concrete
fill 399 262 463 399 269 463 minecraft:magenta_concrete
fill 403 262 505 403 269 505 minecraft:magenta_concrete
fill 406 262 494 406 273 494 minecraft:black_concrete
setblock 406 262 495 minecraft:sea_lantern
fill 406 262 496 406 273 496 minecraft:black_concrete
setblock 406 262 497 minecraft:sea_lantern
fill 406 262 498 406 273 498 minecraft:black_concrete
setblock 406 262 499 minecraft:sea_lantern
fill 406 262 500 406 273 500 minecraft:black_concrete
setblock 406 262 501 minecraft:sea_lantern
fill 406 262 502 406 273 502 minecraft:black_concrete
setblock 406 262 503 minecraft:sea_lantern
fill 406 262 504 406 273 504 minecraft:black_concrete
fill 407 262 463 407 269 463 minecraft:magenta_concrete
fill 407 262 492 410 262 493 minecraft:moss_block
setblock 407 262 494 minecraft:sea_lantern
setblock 407 262 495 minecraft:moss_block
setblock 407 262 496 minecraft:sea_lantern
fill 407 262 497 407 273 497 minecraft:black_concrete
setblock 407 262 498 minecraft:sea_lantern
fill 407 262 499 407 273 499 minecraft:black_concrete
setblock 407 262 500 minecraft:sea_lantern
fill 407 262 501 407 273 501 minecraft:black_concrete
setblock 407 262 502 minecraft:sea_lantern
fill 407 262 503 407 273 503 minecraft:black_concrete
setblock 407 262 504 minecraft:sea_lantern
setblock 408 262 494 minecraft:moss_block
setblock 408 262 495 minecraft:sea_lantern
fill 408 262 496 408 273 496 minecraft:black_concrete
setblock 408 262 497 minecraft:sea_lantern
fill 408 262 498 408 273 498 minecraft:black_concrete
setblock 408 262 499 minecraft:sea_lantern
fill 408 262 500 408 273 500 minecraft:black_concrete
setblock 408 262 501 minecraft:sea_lantern
fill 408 262 502 408 273 502 minecraft:black_concrete
setblock 408 262 503 minecraft:sea_lantern
fill 408 262 504 408 273 504 minecraft:black_concrete
setblock 409 262 494 minecraft:sea_lantern
setblock 409 262 495 minecraft:moss_block
setblock 409 262 496 minecraft:sea_lantern
fill 409 262 497 409 273 497 minecraft:black_concrete
setblock 409 262 498 minecraft:sea_lantern
fill 409 262 499 409 273 499 minecraft:black_concrete
setblock 409 262 500 minecraft:sea_lantern
fill 409 262 501 409 273 501 minecraft:black_concrete
setblock 409 262 502 minecraft:sea_lantern
fill 409 262 503 409 273 503 minecraft:black_concrete
setblock 409 262 504 minecraft:sea_lantern
setblock 410 262 494 minecraft:moss_block
setblock 410 262 495 minecraft:sea_lantern
fill 410 262 496 410 273 496 minecraft:black_concrete
setblock 410 262 497 minecraft:sea_lantern
fill 410 262 498 410 273 498 minecraft:black_concrete
setblock 410 262 499 minecraft:sea_lantern
fill 410 262 500 410 273 500 minecraft:black_concrete
setblock 410 262 501 minecraft:sea_lantern
fill 410 262 502 410 273 502 minecraft:black_concrete
setblock 410 262 503 minecraft:sea_lantern
fill 410 262 504 410 273 504 minecraft:black_concrete
setblock 411 262 494 minecraft:sea_lantern
fill 411 262 495 411 273 495 minecraft:black_concrete
setblock 411 262 496 minecraft:sea_lantern
fill 411 262 497 411 273 497 minecraft:black_concrete
setblock 411 262 498 minecraft:sea_lantern
fill 411 262 499 411 273 499 minecraft:black_concrete
setblock 411 262 500 minecraft:sea_lantern
fill 411 262 501 411 273 501 minecraft:black_concrete
setblock 411 262 502 minecraft:sea_lantern
fill 411 262 503 411 273 503 minecraft:black_concrete
setblock 411 262 504 minecraft:sea_lantern
fill 411 262 505 411 269 505 minecraft:magenta_concrete
fill 412 262 494 412 273 494 minecraft:black_concrete
setblock 412 262 495 minecraft:sea_lantern
fill 412 262 496 412 273 496 minecraft:black_concrete
setblock 412 262 497 minecraft:sea_lantern
fill 412 262 498 412 273 498 minecraft:black_concrete
setblock 412 262 499 minecraft:sea_lantern
fill 412 262 500 412 273 500 minecraft:black_concrete
setblock 412 262 501 minecraft:sea_lantern
fill 412 262 502 412 273 502 minecraft:black_concrete
setblock 412 262 503 minecraft:sea_lantern
fill 412 262 504 412 273 504 minecraft:black_concrete
fill 415 262 463 415 269 463 minecraft:magenta_concrete
fill 418 262 468 418 269 468 minecraft:magenta_concrete
fill 418 262 476 418 269 476 minecraft:magenta_concrete
fill 418 262 484 418 269 484 minecraft:magenta_concrete
fill 418 262 492 418 269 492 minecraft:magenta_concrete
fill 418 262 500 418 269 500 minecraft:magenta_concrete
fill 406 263 495 410 264 495 minecraft:black_concrete
fill 406 263 497 406 264 497 minecraft:black_concrete
fill 406 263 499 406 264 499 minecraft:black_concrete
fill 406 263 501 406 264 501 minecraft:black_concrete
fill 406 263 503 406 264 503 minecraft:black_concrete
fill 407 263 494 411 264 494 minecraft:black_concrete
fill 407 263 496 407 264 496 minecraft:black_concrete
fill 407 263 498 407 264 498 minecraft:black_concrete
fill 407 263 500 407 264 500 minecraft:black_concrete
fill 407 263 502 407 264 502 minecraft:black_concrete
fill 407 263 504 407 264 504 minecraft:black_concrete
fill 408 263 497 408 264 497 minecraft:black_concrete
fill 408 263 499 408 264 499 minecraft:black_concrete
fill 408 263 501 408 264 501 minecraft:black_concrete
fill 408 263 503 408 264 503 minecraft:black_concrete
fill 409 263 496 409 264 496 minecraft:black_concrete
fill 409 263 498 409 264 498 minecraft:black_concrete
fill 409 263 500 409 264 500 minecraft:black_concrete
fill 409 263 502 409 264 502 minecraft:black_concrete
fill 409 263 504 409 264 504 minecraft:black_concrete
fill 410 263 497 410 264 497 minecraft:black_concrete
fill 410 263 499 410 264 499 minecraft:black_concrete
fill 410 263 501 410 264 501 minecraft:black_concrete
fill 410 263 503 410 264 503 minecraft:black_concrete
fill 411 263 496 411 264 496 minecraft:black_concrete
fill 411 263 498 411 264 498 minecraft:black_concrete
fill 411 263 500 411 264 500 minecraft:black_concrete
fill 411 263 502 411 264 502 minecraft:black_concrete
fill 411 263 504 411 264 504 minecraft:black_concrete
fill 412 263 495 412 264 495 minecraft:black_concrete
fill 412 263 497 412 264 497 minecraft:black_concrete
fill 412 263 499 412 264 499 minecraft:black_concrete
fill 412 263 501 412 264 501 minecraft:black_concrete
fill 412 263 503 412 264 503 minecraft:black_concrete
fill 407 264 471 409 266 473 minecraft:white_concrete
setblock 406 265 495 minecraft:sea_lantern
setblock 406 265 497 minecraft:sea_lantern
setblock 406 265 499 minecraft:sea_lantern
setblock 406 265 501 minecraft:sea_lantern
setblock 406 265 503 minecraft:sea_lantern
setblock 407 265 494 minecraft:sea_lantern
fill 407 265 495 407 273 495 minecraft:black_concrete
setblock 407 265 496 minecraft:sea_lantern
setblock 407 265 498 minecraft:sea_lantern
setblock 407 265 500 minecraft:sea_lantern
setblock 407 265 502 minecraft:sea_lantern
setblock 407 265 504 minecraft:sea_lantern
fill 408 265 494 408 273 494 minecraft:black_concrete
setblock 408 265 495 minecraft:sea_lantern
setblock 408 265 497 minecraft:sea_lantern
setblock 408 265 499 minecraft:sea_lantern
setblock 408 265 501 minecraft:sea_lantern
setblock 408 265 503 minecraft:sea_lantern
setblock 409 265 494 minecraft:sea_lantern
fill 409 265 495 409 273 495 minecraft:black_concrete
setblock 409 265 496 minecraft:sea_lantern
setblock 409 265 498 minecraft:sea_lantern
setblock 409 265 500 minecraft:sea_lantern
setblock 409 265 502 minecraft:sea_lantern
setblock 409 265 504 minecraft:sea_lantern
fill 410 265 494 410 273 494 minecraft:black_concrete
setblock 410 265 495 minecraft:sea_lantern
setblock 410 265 497 minecraft:sea_lantern
setblock 410 265 499 minecraft:sea_lantern
setblock 410 265 501 minecraft:sea_lantern
setblock 410 265 503 minecraft:sea_lantern
setblock 411 265 494 minecraft:sea_lantern
setblock 411 265 496 minecraft:sea_lantern
setblock 411 265 498 minecraft:sea_lantern
setblock 411 265 500 minecraft:sea_lantern
setblock 411 265 502 minecraft:sea_lantern
setblock 411 265 504 minecraft:sea_lantern
setblock 412 265 495 minecraft:sea_lantern
setblock 412 265 497 minecraft:sea_lantern
setblock 412 265 499 minecraft:sea_lantern
setblock 412 265 501 minecraft:sea_lantern
setblock 412 265 503 minecraft:sea_lantern
fill 377 266 464 377 267 469 minecraft:black_concrete
fill 377 266 472 378 266 477 minecraft:black_concrete
fill 377 266 480 378 266 485 minecraft:black_concrete
fill 377 266 488 378 266 493 minecraft:black_concrete
fill 377 266 496 378 266 501 minecraft:black_concrete
fill 377 266 504 382 267 504 minecraft:black_concrete
fill 378 266 465 378 266 471 minecraft:black_concrete
fill 378 266 478 378 266 479 minecraft:black_concrete
fill 378 266 486 378 266 487 minecraft:black_concrete
fill 378 266 494 378 266 495 minecraft:black_concrete
fill 378 266 502 378 266 503 minecraft:black_concrete
fill 379 266 465 416 266 465 minecraft:black_concrete
setblock 379 266 466 minecraft:light[level=14]
setblock 379 266 474 minecraft:light[level=14]
setblock 379 266 482 minecraft:light[level=14]
setblock 379 266 490 minecraft:light[level=14]
setblock 379 266 498 minecraft:light[level=14]
fill 379 266 503 406 266 503 minecraft:black_concrete
fill 380 266 464 385 267 464 minecraft:black_concrete
fill 385 266 504 390 267 504 minecraft:black_concrete
setblock 387 266 466 minecraft:light[level=14]
setblock 387 266 474 minecraft:light[level=14]
setblock 387 266 482 minecraft:light[level=14]
setblock 387 266 490 minecraft:light[level=14]
setblock 387 266 498 minecraft:light[level=14]
fill 388 266 464 393 267 464 minecraft:black_concrete
fill 393 266 504 398 267 504 minecraft:black_concrete
setblock 395 266 466 minecraft:light[level=14]
setblock 395 266 474 minecraft:light[level=14]
setblock 395 266 482 minecraft:light[level=14]
setblock 395 266 490 minecraft:light[level=14]
setblock 395 266 498 minecraft:light[level=14]
fill 396 266 464 401 267 464 minecraft:black_concrete
fill 401 266 504 405 267 504 minecraft:black_concrete
setblock 403 266 466 minecraft:light[level=14]
setblock 403 266 474 minecraft:light[level=14]
setblock 403 266 482 minecraft:light[level=14]
setblock 403 266 490 minecraft:light[level=14]
setblock 403 266 498 minecraft:light[level=14]
fill 404 266 464 409 267 464 minecraft:black_concrete
fill 406 266 495 406 267 495 minecraft:black_concrete
fill 406 266 497 406 267 497 minecraft:black_concrete
fill 406 266 499 406 267 499 minecraft:black_concrete
fill 406 266 501 406 267 501 minecraft:black_concrete
fill 407 266 494 407 267 494 minecraft:black_concrete
fill 407 266 496 407 267 496 minecraft:black_concrete
fill 407 266 498 407 267 498 minecraft:black_concrete
fill 407 266 500 407 267 500 minecraft:black_concrete
fill 407 266 502 407 267 502 minecraft:black_concrete
fill 407 266 504 407 267 504 minecraft:black_concrete
fill 408 266 495 408 267 495 minecraft:black_concrete
fill 408 266 497 408 267 497 minecraft:black_concrete
fill 408 266 499 408 267 499 minecraft:black_concrete
fill 408 266 501 408 267 501 minecraft:black_concrete
fill 408 266 503 408 267 503 minecraft:black_concrete
fill 409 266 494 409 267 494 minecraft:black_concrete
fill 409 266 496 409 267 496 minecraft:black_concrete
fill 409 266 498 409 267 498 minecraft:black_concrete
fill 409 266 500 409 267 500 minecraft:black_concrete
fill 409 266 502 409 267 502 minecraft:black_concrete
fill 409 266 504 409 267 504 minecraft:black_concrete
fill 410 266 495 410 267 495 minecraft:black_concrete
fill 410 266 497 410 267 497 minecraft:black_concrete
fill 410 266 499 410 267 499 minecraft:black_concrete
fill 410 266 501 410 267 501 minecraft:black_concrete
fill 410 266 503 410 267 503 minecraft:black_concrete
setblock 411 266 466 minecraft:light[level=14]
setblock 411 266 474 minecraft:light[level=14]
setblock 411 266 482 minecraft:light[level=14]
setblock 411 266 490 minecraft:light[level=14]
fill 411 266 494 411 267 494 minecraft:black_concrete
fill 411 266 496 411 267 496 minecraft:black_concrete
fill 411 266 498 411 267 498 minecraft:black_concrete
fill 411 266 500 411 267 500 minecraft:black_concrete
fill 411 266 502 411 267 502 minecraft:black_concrete
fill 411 266 504 411 267 504 minecraft:black_concrete
fill 412 266 464 417 267 464 minecraft:black_concrete
fill 412 266 495 412 267 495 minecraft:black_concrete
fill 412 266 497 412 267 497 minecraft:black_concrete
fill 412 266 499 412 267 499 minecraft:black_concrete
fill 412 266 501 412 267 501 minecraft:black_concrete
fill 412 266 503 417 266 503 minecraft:black_concrete
fill 413 266 504 414 267 504 minecraft:black_concrete
fill 416 266 466 416 266 502 minecraft:black_concrete
fill 417 266 467 417 267 472 minecraft:black_concrete
fill 417 266 475 417 267 480 minecraft:black_concrete
fill 417 266 483 417 267 488 minecraft:black_concrete
fill 417 266 491 417 267 496 minecraft:black_concrete
fill 417 266 499 417 267 502 minecraft:black_concrete
fill 417 266 504 417 267 504 minecraft:black_concrete
fill 377 267 472 377 267 477 minecraft:black_concrete
fill 377 267 480 377 267 485 minecraft:black_concrete
fill 377 267 488 377 267 493 minecraft:black_concrete
fill 377 267 496 377 267 501 minecraft:black_concrete
fill 402 267 489 403 268 490 minecraft:lime_concrete
setblock 406 267 503 minecraft:black_concrete
setblock 412 267 503 minecraft:black_concrete
setblock 417 267 503 minecraft:black_concrete
setblock 406 268 495 minecraft:sea_lantern
setblock 406 268 497 minecraft:sea_lantern
setblock 406 268 499 minecraft:sea_lantern
setblock 406 268 501 minecraft:sea_lantern
setblock 406 268 503 minecraft:sea_lantern
setblock 407 268 494 minecraft:sea_lantern
setblock 407 268 496 minecraft:sea_lantern
setblock 407 268 498 minecraft:sea_lantern
setblock 407 268 500 minecraft:sea_lantern
setblock 407 268 502 minecraft:sea_lantern
setblock 407 268 504 minecraft:sea_lantern
setblock 408 268 495 minecraft:sea_lantern
setblock 408 268 497 minecraft:sea_lantern
setblock 408 268 499 minecraft:sea_lantern
setblock 408 268 501 minecraft:sea_lantern
setblock 408 268 503 minecraft:sea_lantern
setblock 409 268 494 minecraft:sea_lantern
setblock 409 268 496 minecraft:sea_lantern
setblock 409 268 498 minecraft:sea_lantern
setblock 409 268 500 minecraft:sea_lantern
setblock 409 268 502 minecraft:sea_lantern
setblock 409 268 504 minecraft:sea_lantern
setblock 410 268 495 minecraft:sea_lantern
setblock 410 268 497 minecraft:sea_lantern
setblock 410 268 499 minecraft:sea_lantern
setblock 410 268 501 minecraft:sea_lantern
setblock 410 268 503 minecraft:sea_lantern
setblock 411 268 494 minecraft:sea_lantern
setblock 411 268 496 minecraft:sea_lantern
setblock 411 268 498 minecraft:sea_lantern
setblock 411 268 500 minecraft:sea_lantern
setblock 411 268 502 minecraft:sea_lantern
setblock 411 268 504 minecraft:sea_lantern
setblock 412 268 495 minecraft:sea_lantern
setblock 412 268 497 minecraft:sea_lantern
setblock 412 268 499 minecraft:sea_lantern
setblock 412 268 501 minecraft:sea_lantern
setblock 412 268 503 minecraft:sea_lantern
fill 406 269 495 406 270 495 minecraft:black_concrete
fill 406 269 497 406 270 497 minecraft:black_concrete
fill 406 269 499 406 270 499 minecraft:black_concrete
fill 406 269 501 406 270 501 minecraft:black_concrete
fill 406 269 503 406 270 503 minecraft:black_concrete
fill 407 269 494 407 270 494 minecraft:black_concrete
fill 407 269 496 407 270 496 minecraft:black_concrete
fill 407 269 498 407 270 498 minecraft:black_concrete
fill 407 269 500 407 270 500 minecraft:black_concrete
fill 407 269 502 407 270 502 minecraft:black_concrete
fill 407 269 504 407 270 504 minecraft:black_concrete
fill 408 269 495 408 270 495 minecraft:black_concrete
fill 408 269 497 408 270 497 minecraft:black_concrete
fill 408 269 499 408 270 499 minecraft:black_concrete
fill 408 269 501 408 270 501 minecraft:black_concrete
fill 408 269 503 408 270 503 minecraft:black_concrete
fill 409 269 494 409 270 494 minecraft:black_concrete
fill 409 269 496 409 270 496 minecraft:black_concrete
fill 409 269 498 409 270 498 minecraft:black_concrete
fill 409 269 500 409 270 500 minecraft:black_concrete
fill 409 269 502 409 270 502 minecraft:black_concrete
fill 409 269 504 409 270 504 minecraft:black_concrete
fill 410 269 495 410 270 495 minecraft:black_concrete
fill 410 269 497 410 270 497 minecraft:black_concrete
fill 410 269 499 410 270 499 minecraft:black_concrete
fill 410 269 501 410 270 501 minecraft:black_concrete
fill 410 269 503 410 270 503 minecraft:black_concrete
fill 411 269 494 411 270 494 minecraft:black_concrete
fill 411 269 496 411 270 496 minecraft:black_concrete
fill 411 269 498 411 270 498 minecraft:black_concrete
fill 411 269 500 411 270 500 minecraft:black_concrete
fill 411 269 502 411 270 502 minecraft:black_concrete
fill 411 269 504 411 270 504 minecraft:black_concrete
fill 412 269 495 412 270 495 minecraft:black_concrete
fill 412 269 497 412 270 497 minecraft:black_concrete
fill 412 269 499 412 270 499 minecraft:black_concrete
fill 412 269 501 412 270 501 minecraft:black_concrete
fill 412 269 503 412 270 503 minecraft:black_concrete
fill 376 270 468 376 273 468 minecraft:sea_lantern
fill 376 270 476 376 273 476 minecraft:sea_lantern
fill 376 270 484 376 273 484 minecraft:sea_lantern
fill 376 270 492 376 273 492 minecraft:sea_lantern
fill 376 270 500 376 273 500 minecraft:sea_lantern
fill 379 270 505 379 273 505 minecraft:sea_lantern
fill 383 270 463 383 273 463 minecraft:sea_lantern
fill 387 270 505 387 273 505 minecraft:sea_lantern
fill 391 270 463 391 273 463 minecraft:sea_lantern
fill 395 270 505 395 273 505 minecraft:sea_lantern
fill 399 270 463 399 273 463 minecraft:sea_lantern
fill 403 270 505 403 273 505 minecraft:sea_lantern
fill 407 270 463 407 273 463 minecraft:sea_lantern
fill 411 270 505 411 273 505 minecraft:sea_lantern
fill 415 270 463 415 273 463 minecraft:sea_lantern
fill 418 270 468 418 273 468 minecraft:sea_lantern
fill 418 270 476 418 273 476 minecraft:sea_lantern
fill 418 270 484 418 273 484 minecraft:sea_lantern
fill 418 270 492 418 273 492 minecraft:sea_lantern
fill 418 270 500 418 273 500 minecraft:sea_lantern
setblock 406 271 495 minecraft:sea_lantern
setblock 406 271 497 minecraft:sea_lantern
setblock 406 271 499 minecraft:sea_lantern
setblock 406 271 501 minecraft:sea_lantern
setblock 406 271 503 minecraft:sea_lantern
setblock 407 271 494 minecraft:sea_lantern
setblock 407 271 496 minecraft:sea_lantern
setblock 407 271 498 minecraft:sea_lantern
setblock 407 271 500 minecraft:sea_lantern
setblock 407 271 502 minecraft:sea_lantern
setblock 407 271 504 minecraft:sea_lantern
setblock 408 271 495 minecraft:sea_lantern
setblock 408 271 497 minecraft:sea_lantern
setblock 408 271 499 minecraft:sea_lantern
setblock 408 271 501 minecraft:sea_lantern
setblock 408 271 503 minecraft:sea_lantern
setblock 409 271 494 minecraft:sea_lantern
setblock 409 271 496 minecraft:sea_lantern
setblock 409 271 498 minecraft:sea_lantern
setblock 409 271 500 minecraft:sea_lantern
setblock 409 271 502 minecraft:sea_lantern
setblock 409 271 504 minecraft:sea_lantern
setblock 410 271 495 minecraft:sea_lantern
setblock 410 271 497 minecraft:sea_lantern
setblock 410 271 499 minecraft:sea_lantern
setblock 410 271 501 minecraft:sea_lantern
setblock 410 271 503 minecraft:sea_lantern
setblock 411 271 494 minecraft:sea_lantern
setblock 411 271 496 minecraft:sea_lantern
setblock 411 271 498 minecraft:sea_lantern
setblock 411 271 500 minecraft:sea_lantern
setblock 411 271 502 minecraft:sea_lantern
setblock 411 271 504 minecraft:sea_lantern
setblock 412 271 495 minecraft:sea_lantern
setblock 412 271 497 minecraft:sea_lantern
setblock 412 271 499 minecraft:sea_lantern
setblock 412 271 501 minecraft:sea_lantern
setblock 412 271 503 minecraft:sea_lantern
fill 406 272 495 406 273 495 minecraft:black_concrete
fill 406 272 497 406 273 497 minecraft:black_concrete
fill 406 272 499 406 273 499 minecraft:black_concrete
fill 406 272 501 406 273 501 minecraft:black_concrete
fill 406 272 503 406 273 503 minecraft:black_concrete
fill 407 272 494 407 273 494 minecraft:black_concrete
fill 407 272 496 407 273 496 minecraft:black_concrete
fill 407 272 498 407 273 498 minecraft:black_concrete
fill 407 272 500 407 273 500 minecraft:black_concrete
fill 407 272 502 407 273 502 minecraft:black_concrete
fill 407 272 504 407 273 504 minecraft:black_concrete
fill 408 272 495 408 273 495 minecraft:black_concrete
fill 408 272 497 408 273 497 minecraft:black_concrete
fill 408 272 499 408 273 499 minecraft:black_concrete
fill 408 272 501 408 273 501 minecraft:black_concrete
fill 408 272 503 408 273 503 minecraft:black_concrete
fill 409 272 494 409 273 494 minecraft:black_concrete
fill 409 272 496 409 273 496 minecraft:black_concrete
fill 409 272 498 409 273 498 minecraft:black_concrete
fill 409 272 500 409 273 500 minecraft:black_concrete
fill 409 272 502 409 273 502 minecraft:black_concrete
fill 409 272 504 409 273 504 minecraft:black_concrete
fill 410 272 495 410 273 495 minecraft:black_concrete
fill 410 272 497 410 273 497 minecraft:black_concrete
fill 410 272 499 410 273 499 minecraft:black_concrete
fill 410 272 501 410 273 501 minecraft:black_concrete
fill 410 272 503 410 273 503 minecraft:black_concrete
fill 411 272 494 411 273 494 minecraft:black_concrete
fill 411 272 496 411 273 496 minecraft:black_concrete
fill 411 272 498 411 273 498 minecraft:black_concrete
fill 411 272 500 411 273 500 minecraft:black_concrete
fill 411 272 502 411 273 502 minecraft:black_concrete
fill 411 272 504 411 273 504 minecraft:black_concrete
fill 412 272 495 412 273 495 minecraft:black_concrete
fill 412 272 497 412 273 497 minecraft:black_concrete
fill 412 272 499 412 273 499 minecraft:black_concrete
fill 412 272 501 412 273 501 minecraft:black_concrete
fill 412 272 503 412 273 503 minecraft:black_concrete
fill 376 274 468 376 283 468 minecraft:magenta_concrete
fill 376 274 476 376 283 476 minecraft:magenta_concrete
fill 376 274 484 376 283 484 minecraft:magenta_concrete
fill 376 274 492 376 283 492 minecraft:magenta_concrete
fill 376 274 500 376 283 500 minecraft:magenta_concrete
setblock 379 274 466 minecraft:light[level=14]
setblock 379 274 474 minecraft:light[level=14]
setblock 379 274 482 minecraft:light[level=14]
setblock 379 274 490 minecraft:light[level=14]
setblock 379 274 498 minecraft:light[level=14]
fill 379 274 505 379 283 505 minecraft:magenta_concrete
fill 383 274 463 383 283 463 minecraft:magenta_concrete
setblock 387 274 466 minecraft:light[level=14]
setblock 387 274 474 minecraft:light[level=14]
setblock 387 274 482 minecraft:light[level=14]
setblock 387 274 490 minecraft:light[level=14]
setblock 387 274 498 minecraft:light[level=14]
fill 387 274 505 387 283 505 minecraft:magenta_concrete
fill 391 274 463 391 283 463 minecraft:magenta_concrete
setblock 395 274 466 minecraft:light[level=14]
setblock 395 274 474 minecraft:light[level=14]
setblock 395 274 482 minecraft:light[level=14]
setblock 395 274 490 minecraft:light[level=14]
setblock 395 274 498 minecraft:light[level=14]
fill 395 274 505 395 283 505 minecraft:magenta_concrete
fill 399 274 463 399 283 463 minecraft:magenta_concrete
setblock 403 274 466 minecraft:light[level=14]
setblock 403 274 474 minecraft:light[level=14]
setblock 403 274 482 minecraft:light[level=14]
setblock 403 274 490 minecraft:light[level=14]
setblock 403 274 498 minecraft:light[level=14]
fill 403 274 505 403 283 505 minecraft:magenta_concrete
fill 407 274 463 407 283 463 minecraft:magenta_concrete
setblock 411 274 466 minecraft:light[level=14]
setblock 411 274 474 minecraft:light[level=14]
setblock 411 274 482 minecraft:light[level=14]
setblock 411 274 490 minecraft:light[level=14]
setblock 411 274 498 minecraft:light[level=14]
fill 411 274 505 411 283 505 minecraft:magenta_concrete
fill 415 274 463 415 283 463 minecraft:magenta_concrete
fill 418 274 468 418 283 468 minecraft:magenta_concrete
fill 418 274 476 418 283 476 minecraft:magenta_concrete
fill 418 274 484 418 283 484 minecraft:magenta_concrete
fill 418 274 492 418 283 492 minecraft:magenta_concrete
fill 418 274 500 418 283 500 minecraft:magenta_concrete
fill 377 279 464 377 280 466 minecraft:black_concrete
fill 377 279 467 377 280 470 minecraft:magenta_concrete
fill 377 279 471 377 280 474 minecraft:black_concrete
fill 377 279 475 377 280 478 minecraft:magenta_concrete
fill 377 279 479 377 280 482 minecraft:black_concrete
fill 377 279 483 377 280 486 minecraft:magenta_concrete
fill 377 279 487 377 280 490 minecraft:black_concrete
fill 377 279 491 377 280 494 minecraft:magenta_concrete
fill 377 279 495 377 280 498 minecraft:black_concrete
fill 377 279 499 377 280 502 minecraft:magenta_concrete
fill 377 279 503 377 280 504 minecraft:black_concrete
fill 378 279 464 381 280 466 minecraft:magenta_concrete
fill 378 279 467 381 280 470 minecraft:black_concrete
fill 378 279 471 381 280 474 minecraft:magenta_concrete
fill 378 279 475 381 280 478 minecraft:black_concrete
fill 378 279 479 381 280 482 minecraft:magenta_concrete
fill 378 279 483 381 280 486 minecraft:black_concrete
fill 378 279 487 381 280 490 minecraft:magenta_concrete
fill 378 279 491 381 280 494 minecraft:black_concrete
fill 378 279 495 381 280 498 minecraft:magenta_concrete
fill 378 279 499 381 280 502 minecraft:black_concrete
fill 378 279 503 381 280 504 minecraft:magenta_concrete
fill 382 279 464 385 280 466 minecraft:black_concrete
fill 382 279 467 385 280 470 minecraft:magenta_concrete
fill 382 279 471 385 280 474 minecraft:black_concrete
fill 382 279 475 385 280 478 minecraft:magenta_concrete
fill 382 279 479 385 280 482 minecraft:black_concrete
fill 382 279 483 385 280 486 minecraft:magenta_concrete
fill 382 279 487 385 280 490 minecraft:black_concrete
fill 382 279 491 385 280 494 minecraft:magenta_concrete
fill 382 279 495 385 280 498 minecraft:black_concrete
fill 382 279 499 385 280 502 minecraft:magenta_concrete
fill 382 279 503 385 280 504 minecraft:black_concrete
fill 386 279 464 389 280 466 minecraft:magenta_concrete
fill 386 279 467 389 280 470 minecraft:black_concrete
fill 386 279 471 389 280 474 minecraft:magenta_concrete
fill 386 279 475 389 280 478 minecraft:black_concrete
fill 386 279 479 389 280 482 minecraft:magenta_concrete
fill 386 279 483 389 280 486 minecraft:black_concrete
fill 386 279 487 389 280 490 minecraft:magenta_concrete
fill 386 279 491 389 280 494 minecraft:black_concrete
fill 386 279 495 389 280 498 minecraft:magenta_concrete
fill 386 279 499 389 280 502 minecraft:black_concrete
fill 386 279 503 389 280 504 minecraft:magenta_concrete
fill 390 279 464 393 280 466 minecraft:black_concrete
fill 390 279 467 393 280 470 minecraft:magenta_concrete
fill 390 279 471 393 280 474 minecraft:black_concrete
fill 390 279 475 393 280 478 minecraft:magenta_concrete
fill 390 279 479 392 279 482 minecraft:black_concrete
fill 390 279 483 391 279 486 minecraft:magenta_concrete
fill 390 279 487 393 280 490 minecraft:black_concrete
fill 390 279 491 393 280 494 minecraft:magenta_concrete
fill 390 279 495 393 280 498 minecraft:black_concrete
fill 390 279 499 393 280 502 minecraft:magenta_concrete
fill 390 279 503 393 280 504 minecraft:black_concrete
fill 392 279 484 392 279 486 minecraft:magenta_concrete
fill 393 279 479 393 279 481 minecraft:black_concrete
fill 393 279 485 393 279 486 minecraft:magenta_concrete
fill 394 279 464 397 280 466 minecraft:magenta_concrete
fill 394 279 467 397 280 470 minecraft:black_concrete
fill 394 279 471 397 280 474 minecraft:magenta_concrete
fill 394 279 475 397 280 478 minecraft:black_concrete
fill 394 279 479 397 279 480 minecraft:magenta_concrete
fill 394 279 486 397 279 486 minecraft:black_concrete
fill 394 279 487 397 280 490 minecraft:magenta_concrete
fill 394 279 491 397 280 494 minecraft:black_concrete
fill 394 279 495 397 280 498 minecraft:magenta_concrete
fill 394 279 499 397 280 502 minecraft:black_concrete
fill 394 279 503 397 280 504 minecraft:magenta_concrete
fill 395 279 481 397 279 481 minecraft:magenta_concrete
fill 395 279 485 397 279 485 minecraft:black_concrete
fill 396 279 482 397 279 482 minecraft:magenta_concrete
fill 396 279 484 397 279 484 minecraft:black_concrete
setblock 397 279 483 minecraft:black_concrete
fill 398 279 464 401 280 466 minecraft:black_concrete
fill 398 279 467 401 280 470 minecraft:magenta_concrete
fill 398 279 471 401 280 474 minecraft:black_concrete
fill 398 279 475 401 280 478 minecraft:magenta_concrete
fill 398 279 479 401 280 482 minecraft:black_concrete
fill 398 279 483 401 280 486 minecraft:magenta_concrete
fill 398 279 487 401 280 490 minecraft:black_concrete
fill 398 279 491 401 280 494 minecraft:magenta_concrete
fill 398 279 495 401 280 498 minecraft:black_concrete
fill 398 279 499 401 280 502 minecraft:magenta_concrete
fill 398 279 503 401 280 504 minecraft:black_concrete
fill 402 279 464 405 280 466 minecraft:magenta_concrete
fill 402 279 467 405 280 470 minecraft:black_concrete
fill 402 279 471 405 280 474 minecraft:magenta_concrete
fill 402 279 475 405 280 478 minecraft:black_concrete
fill 402 279 479 405 280 482 minecraft:magenta_concrete
fill 402 279 483 405 280 486 minecraft:black_concrete
fill 402 279 487 405 280 490 minecraft:magenta_concrete
fill 402 279 491 405 280 494 minecraft:black_concrete
fill 402 279 495 405 280 498 minecraft:magenta_concrete
fill 402 279 499 405 280 502 minecraft:black_concrete
fill 402 279 503 405 280 504 minecraft:magenta_concrete
fill 406 279 464 409 280 466 minecraft:black_concrete
fill 406 279 467 409 280 470 minecraft:magenta_concrete
fill 406 279 471 409 280 474 minecraft:black_concrete
fill 406 279 475 409 280 478 minecraft:magenta_concrete
fill 406 279 479 409 280 482 minecraft:black_concrete
fill 406 279 483 409 280 486 minecraft:magenta_concrete
fill 406 279 487 409 280 490 minecraft:black_concrete
fill 406 279 491 409 280 494 minecraft:magenta_concrete
fill 406 279 495 409 280 498 minecraft:black_concrete
fill 406 279 499 409 280 502 minecraft:magenta_concrete
fill 406 279 503 409 280 504 minecraft:black_concrete
fill 410 279 464 413 280 466 minecraft:magenta_concrete
fill 410 279 467 413 280 470 minecraft:black_concrete
fill 410 279 471 413 280 474 minecraft:magenta_concrete
fill 410 279 475 413 280 478 minecraft:black_concrete
fill 410 279 479 413 280 482 minecraft:magenta_concrete
fill 410 279 483 413 280 486 minecraft:black_concrete
fill 410 279 487 413 280 490 minecraft:magenta_concrete
fill 410 279 491 413 280 494 minecraft:black_concrete
fill 410 279 495 413 280 498 minecraft:magenta_concrete
fill 410 279 499 413 280 502 minecraft:black_concrete
fill 410 279 503 413 280 504 minecraft:magenta_concrete
fill 414 279 464 417 280 466 minecraft:black_concrete
fill 414 279 467 417 280 470 minecraft:magenta_concrete
fill 414 279 471 417 280 474 minecraft:black_concrete
fill 414 279 475 417 280 478 minecraft:magenta_concrete
fill 414 279 479 417 280 482 minecraft:black_concrete
fill 414 279 483 417 280 486 minecraft:magenta_concrete
fill 414 279 487 417 280 490 minecraft:black_concrete
fill 414 279 491 417 280 494 minecraft:magenta_concrete
fill 414 279 495 417 280 498 minecraft:black_concrete
fill 414 279 499 417 280 502 minecraft:magenta_concrete
fill 414 279 503 417 280 504 minecraft:black_concrete
fill 390 280 479 390 280 482 minecraft:black_concrete
fill 390 280 483 390 280 486 minecraft:magenta_concrete
fill 391 280 479 391 280 481 minecraft:black_concrete
fill 391 280 482 391 280 484 minecraft:sea_lantern
fill 391 280 485 391 280 486 minecraft:magenta_concrete
fill 392 280 479 392 280 480 minecraft:black_concrete
fill 392 280 481 392 280 482 minecraft:sea_lantern
fill 392 280 484 392 280 485 minecraft:sea_lantern
setblock 392 280 486 minecraft:magenta_concrete
setblock 393 280 479 minecraft:black_concrete
fill 393 280 480 393 280 481 minecraft:sea_lantern
fill 393 280 485 393 280 486 minecraft:sea_lantern
fill 394 280 479 397 280 479 minecraft:magenta_concrete
fill 394 280 480 395 280 480 minecraft:sea_lantern
fill 394 280 486 395 280 486 minecraft:sea_lantern
fill 395 280 481 396 280 481 minecraft:sea_lantern
fill 395 280 485 396 280 485 minecraft:sea_lantern
fill 396 280 480 397 280 480 minecraft:magenta_concrete
fill 396 280 482 397 280 482 minecraft:sea_lantern
fill 396 280 484 397 280 484 minecraft:sea_lantern
fill 396 280 486 397 280 486 minecraft:black_concrete
setblock 397 280 481 minecraft:magenta_concrete
setblock 397 280 483 minecraft:sea_lantern
setblock 397 280 485 minecraft:black_concrete
setblock 379 282 466 minecraft:light[level=14]
setblock 379 282 474 minecraft:light[level=14]
setblock 379 282 482 minecraft:light[level=14]
setblock 379 282 490 minecraft:light[level=14]
setblock 379 282 498 minecraft:light[level=14]
setblock 387 282 466 minecraft:light[level=14]
setblock 387 282 474 minecraft:light[level=14]
setblock 387 282 482 minecraft:light[level=14]
setblock 387 282 490 minecraft:light[level=14]
setblock 387 282 498 minecraft:light[level=14]
setblock 395 282 466 minecraft:light[level=14]
setblock 395 282 474 minecraft:light[level=14]
setblock 395 282 490 minecraft:light[level=14]
setblock 395 282 498 minecraft:light[level=14]
setblock 403 282 466 minecraft:light[level=14]
setblock 403 282 474 minecraft:light[level=14]
setblock 403 282 482 minecraft:light[level=14]
setblock 403 282 490 minecraft:light[level=14]
setblock 403 282 498 minecraft:light[level=14]
setblock 411 282 466 minecraft:light[level=14]
setblock 411 282 474 minecraft:light[level=14]
setblock 411 282 482 minecraft:light[level=14]
setblock 411 282 490 minecraft:light[level=14]
setblock 411 282 498 minecraft:light[level=14]
fill 376 284 468 376 289 468 minecraft:sea_lantern
fill 376 284 476 376 289 476 minecraft:sea_lantern
fill 376 284 484 376 289 484 minecraft:sea_lantern
fill 376 284 492 376 289 492 minecraft:sea_lantern
fill 376 284 500 376 289 500 minecraft:sea_lantern
fill 377 284 470 385 285 476 minecraft:black_concrete
fill 377 284 478 377 300 479 minecraft:black_concrete
fill 377 284 486 377 300 487 minecraft:black_concrete
fill 377 284 494 377 300 495 minecraft:black_concrete
fill 377 284 502 377 300 503 minecraft:black_concrete
fill 378 284 464 379 300 464 minecraft:black_concrete
fill 379 284 505 379 289 505 minecraft:sea_lantern
fill 383 284 463 383 289 463 minecraft:sea_lantern
fill 383 284 504 384 300 504 minecraft:black_concrete
fill 386 284 464 387 300 464 minecraft:black_concrete
fill 387 284 505 387 289 505 minecraft:sea_lantern
fill 391 284 463 391 289 463 minecraft:sea_lantern
fill 391 284 504 392 288 504 minecraft:black_concrete
fill 394 284 464 395 300 464 minecraft:black_concrete
fill 394 284 500 396 286 501 minecraft:magenta_concrete
fill 395 284 502 395 286 502 minecraft:magenta_concrete
fill 395 284 505 395 289 505 minecraft:sea_lantern
fill 399 284 463 399 289 463 minecraft:sea_lantern
fill 399 284 504 400 288 504 minecraft:black_concrete
fill 402 284 464 403 300 464 minecraft:black_concrete
fill 403 284 505 403 289 505 minecraft:sea_lantern
fill 407 284 463 407 289 463 minecraft:sea_lantern
fill 407 284 504 408 300 504 minecraft:black_concrete
fill 410 284 464 411 300 464 minecraft:black_concrete
fill 411 284 505 411 289 505 minecraft:sea_lantern
fill 415 284 463 415 289 463 minecraft:sea_lantern
fill 415 284 504 416 300 504 minecraft:black_concrete
fill 417 284 465 417 300 466 minecraft:black_concrete
fill 417 284 473 417 300 474 minecraft:black_concrete
fill 417 284 481 417 300 482 minecraft:black_concrete
fill 417 284 489 417 300 490 minecraft:black_concrete
fill 417 284 497 417 300 498 minecraft:black_concrete
fill 418 284 468 418 289 468 minecraft:sea_lantern
fill 418 284 476 418 289 476 minecraft:sea_lantern
fill 418 284 484 418 289 484 minecraft:sea_lantern
fill 418 284 492 418 289 492 minecraft:sea_lantern
fill 418 284 500 418 289 500 minecraft:sea_lantern
fill 394 285 502 394 286 502 minecraft:magenta_concrete
fill 395 285 499 395 286 499 minecraft:magenta_concrete
fill 396 285 502 396 286 502 minecraft:magenta_concrete
setblock 377 286 470 minecraft:sea_lantern
fill 377 286 471 377 300 471 minecraft:black_concrete
setblock 377 286 472 minecraft:sea_lantern
fill 377 286 473 377 300 473 minecraft:black_concrete
setblock 377 286 474 minecraft:sea_lantern
fill 377 286 475 377 300 475 minecraft:black_concrete
setblock 377 286 476 minecraft:sea_lantern
fill 378 286 470 378 300 470 minecraft:black_concrete
setblock 378 286 471 minecraft:sea_lantern
fill 378 286 472 378 300 472 minecraft:black_concrete
setblock 378 286 473 minecraft:sea_lantern
fill 378 286 474 378 300 474 minecraft:black_concrete
setblock 378 286 475 minecraft:sea_lantern
fill 378 286 476 378 300 476 minecraft:black_concrete
setblock 379 286 470 minecraft:sea_lantern
fill 379 286 471 379 300 471 minecraft:black_concrete
setblock 379 286 472 minecraft:sea_lantern
fill 379 286 473 379 300 473 minecraft:black_concrete
setblock 379 286 474 minecraft:sea_lantern
fill 379 286 475 379 300 475 minecraft:black_concrete
setblock 379 286 476 minecraft:sea_lantern
fill 380 286 470 380 300 470 minecraft:black_concrete
setblock 380 286 471 minecraft:sea_lantern
fill 380 286 472 380 300 472 minecraft:black_concrete
setblock 380 286 473 minecraft:sea_lantern
fill 380 286 474 380 300 474 minecraft:black_concrete
setblock 380 286 475 minecraft:sea_lantern
fill 380 286 476 380 300 476 minecraft:black_concrete
setblock 381 286 470 minecraft:sea_lantern
fill 381 286 471 381 300 471 minecraft:black_concrete
setblock 381 286 472 minecraft:sea_lantern
fill 381 286 473 381 300 473 minecraft:black_concrete
setblock 381 286 474 minecraft:sea_lantern
fill 381 286 475 381 300 475 minecraft:black_concrete
setblock 381 286 476 minecraft:sea_lantern
fill 382 286 470 382 300 470 minecraft:black_concrete
setblock 382 286 471 minecraft:sea_lantern
fill 382 286 472 382 300 472 minecraft:black_concrete
setblock 382 286 473 minecraft:sea_lantern
fill 382 286 474 382 300 474 minecraft:black_concrete
setblock 382 286 475 minecraft:sea_lantern
fill 382 286 476 382 300 476 minecraft:black_concrete
setblock 383 286 470 minecraft:sea_lantern
fill 383 286 471 383 300 471 minecraft:black_concrete
setblock 383 286 472 minecraft:sea_lantern
fill 383 286 473 383 300 473 minecraft:black_concrete
setblock 383 286 474 minecraft:sea_lantern
fill 383 286 475 383 287 475 minecraft:black_concrete
setblock 383 286 476 minecraft:sea_lantern
fill 384 286 470 384 300 470 minecraft:black_concrete
setblock 384 286 471 minecraft:sea_lantern
fill 384 286 472 384 300 472 minecraft:black_concrete
setblock 384 286 473 minecraft:sea_lantern
fill 384 286 474 384 287 474 minecraft:black_concrete
setblock 384 286 475 minecraft:sea_lantern
fill 384 286 476 384 287 476 minecraft:black_concrete
setblock 385 286 470 minecraft:sea_lantern
fill 385 286 471 385 300 471 minecraft:black_concrete
setblock 385 286 472 minecraft:sea_lantern
fill 385 286 473 385 300 473 minecraft:black_concrete
setblock 385 286 474 minecraft:sea_lantern
fill 385 286 475 385 287 475 minecraft:black_concrete
setblock 385 286 476 minecraft:sea_lantern
fill 393 286 500 393 286 501 minecraft:magenta_concrete
setblock 394 286 499 minecraft:magenta_concrete
setblock 395 286 503 minecraft:magenta_concrete
setblock 396 286 499 minecraft:magenta_concrete
fill 397 286 500 397 286 501 minecraft:magenta_concrete
fill 407 286 480 410 289 483 minecraft:black_concrete
fill 377 287 470 377 288 470 minecraft:black_concrete
fill 377 287 472 377 288 472 minecraft:black_concrete
fill 377 287 474 377 288 474 minecraft:black_concrete
fill 377 287 476 377 288 476 minecraft:black_concrete
fill 378 287 471 378 288 471 minecraft:black_concrete
fill 378 287 473 378 288 473 minecraft:black_concrete
fill 378 287 475 378 288 475 minecraft:black_concrete
fill 379 287 470 379 288 470 minecraft:black_concrete
fill 379 287 472 379 288 472 minecraft:black_concrete
fill 379 287 474 379 288 474 minecraft:black_concrete
fill 379 287 476 379 288 476 minecraft:black_concrete
fill 380 287 471 380 288 471 minecraft:black_concrete
fill 380 287 473 380 288 473 minecraft:black_concrete
fill 380 287 475 380 288 475 minecraft:black_concrete
fill 381 287 470 381 288 470 minecraft:black_concrete
fill 381 287 472 381 288 472 minecraft:black_concrete
fill 381 287 474 381 288 474 minecraft:black_concrete
fill 381 287 476 381 288 476 minecraft:black_concrete
fill 382 287 471 382 288 471 minecraft:black_concrete
fill 382 287 473 382 288 473 minecraft:black_concrete
fill 382 287 475 382 288 475 minecraft:black_concrete
fill 383 287 470 383 288 470 minecraft:black_concrete
fill 383 287 472 383 288 472 minecraft:black_concrete
setblock 383 287 474 minecraft:black_concrete
setblock 383 287 476 minecraft:black_concrete
fill 384 287 471 384 288 471 minecraft:black_concrete
fill 384 287 473 384 288 473 minecraft:black_concrete
setblock 384 287 475 minecraft:black_concrete
fill 385 287 470 385 288 470 minecraft:black_concrete
fill 385 287 472 385 288 472 minecraft:black_concrete
setblock 385 287 474 minecraft:black_concrete
setblock 385 287 476 minecraft:black_concrete
fill 391 287 498 399 288 503 minecraft:black_concrete
fill 393 287 504 398 288 504 minecraft:black_concrete
fill 383 288 474 385 288 476 minecraft:cyan_concrete
fill 406 288 469 409 291 472 minecraft:lime_concrete
setblock 377 289 470 minecraft:sea_lantern
setblock 377 289 472 minecraft:sea_lantern
setblock 377 289 474 minecraft:sea_lantern
setblock 377 289 476 minecraft:sea_lantern
setblock 378 289 471 minecraft:sea_lantern
setblock 378 289 473 minecraft:sea_lantern
setblock 378 289 475 minecraft:sea_lantern
setblock 379 289 470 minecraft:sea_lantern
setblock 379 289 472 minecraft:sea_lantern
setblock 379 289 474 minecraft:sea_lantern
setblock 379 289 476 minecraft:sea_lantern
setblock 380 289 471 minecraft:sea_lantern
setblock 380 289 473 minecraft:sea_lantern
setblock 380 289 475 minecraft:sea_lantern
setblock 381 289 470 minecraft:sea_lantern
setblock 381 289 472 minecraft:sea_lantern
setblock 381 289 474 minecraft:sea_lantern
setblock 381 289 476 minecraft:sea_lantern
setblock 382 289 471 minecraft:sea_lantern
setblock 382 289 473 minecraft:sea_lantern
setblock 382 289 475 minecraft:sea_lantern
setblock 383 289 470 minecraft:sea_lantern
setblock 383 289 472 minecraft:sea_lantern
setblock 383 289 474 minecraft:sea_lantern
fill 383 289 475 383 290 475 minecraft:cyan_concrete
setblock 383 289 476 minecraft:sea_lantern
setblock 384 289 471 minecraft:sea_lantern
setblock 384 289 473 minecraft:sea_lantern
fill 384 289 474 384 290 474 minecraft:cyan_concrete
setblock 384 289 475 minecraft:sea_lantern
fill 384 289 476 384 290 476 minecraft:cyan_concrete
setblock 385 289 470 minecraft:sea_lantern
setblock 385 289 472 minecraft:sea_lantern
setblock 385 289 474 minecraft:sea_lantern
fill 385 289 475 385 290 475 minecraft:cyan_concrete
setblock 385 289 476 minecraft:sea_lantern
setblock 391 289 498 minecraft:sea_lantern
fill 391 289 499 391 300 499 minecraft:black_concrete
setblock 391 289 500 minecraft:sea_lantern
fill 391 289 501 391 300 501 minecraft:black_concrete
setblock 391 289 502 minecraft:sea_lantern
fill 391 289 503 391 300 503 minecraft:black_concrete
setblock 391 289 504 minecraft:sea_lantern
fill 392 289 498 392 300 498 minecraft:black_concrete
setblock 392 289 499 minecraft:sea_lantern
fill 392 289 500 392 300 500 minecraft:black_concrete
setblock 392 289 501 minecraft:sea_lantern
fill 392 289 502 392 300 502 minecraft:black_concrete
setblock 392 289 503 minecraft:sea_lantern
fill 392 289 504 392 300 504 minecraft:black_concrete
setblock 393 289 498 minecraft:sea_lantern
fill 393 289 499 393 300 499 minecraft:black_concrete
setblock 393 289 500 minecraft:sea_lantern
fill 393 289 501 393 300 501 minecraft:black_concrete
setblock 393 289 502 minecraft:sea_lantern
fill 393 289 503 393 300 503 minecraft:black_concrete
setblock 393 289 504 minecraft:sea_lantern
fill 394 289 498 394 300 498 minecraft:black_concrete
setblock 394 289 499 minecraft:sea_lantern
fill 394 289 500 394 300 500 minecraft:black_concrete
setblock 394 289 501 minecraft:sea_lantern
fill 394 289 502 394 300 502 minecraft:black_concrete
setblock 394 289 503 minecraft:sea_lantern
fill 394 289 504 394 300 504 minecraft:black_concrete
setblock 395 289 498 minecraft:sea_lantern
fill 395 289 499 395 300 499 minecraft:black_concrete
setblock 395 289 500 minecraft:sea_lantern
fill 395 289 501 395 300 501 minecraft:black_concrete
setblock 395 289 502 minecraft:sea_lantern
fill 395 289 503 395 300 503 minecraft:black_concrete
setblock 395 289 504 minecraft:sea_lantern
fill 396 289 498 396 300 498 minecraft:black_concrete
setblock 396 289 499 minecraft:sea_lantern
fill 396 289 500 396 300 500 minecraft:black_concrete
setblock 396 289 501 minecraft:sea_lantern
fill 396 289 502 396 300 502 minecraft:black_concrete
setblock 396 289 503 minecraft:sea_lantern
fill 396 289 504 396 300 504 minecraft:black_concrete
setblock 397 289 498 minecraft:sea_lantern
fill 397 289 499 397 300 499 minecraft:black_concrete
setblock 397 289 500 minecraft:sea_lantern
fill 397 289 501 397 300 501 minecraft:black_concrete
setblock 397 289 502 minecraft:sea_lantern
fill 397 289 503 397 300 503 minecraft:black_concrete
setblock 397 289 504 minecraft:sea_lantern
fill 398 289 498 398 300 498 minecraft:black_concrete
setblock 398 289 499 minecraft:sea_lantern
fill 398 289 500 398 300 500 minecraft:black_concrete
setblock 398 289 501 minecraft:sea_lantern
fill 398 289 502 398 300 502 minecraft:black_concrete
setblock 398 289 503 minecraft:sea_lantern
fill 398 289 504 398 300 504 minecraft:black_concrete
setblock 399 289 498 minecraft:sea_lantern
fill 399 289 499 399 300 499 minecraft:black_concrete
setblock 399 289 500 minecraft:sea_lantern
fill 399 289 501 399 300 501 minecraft:black_concrete
setblock 399 289 502 minecraft:sea_lantern
fill 399 289 503 399 300 503 minecraft:black_concrete
setblock 399 289 504 minecraft:sea_lantern
fill 400 289 504 400 300 504 minecraft:black_concrete
fill 409 289 496 411 291 498 minecraft:lime_concrete
fill 376 290 468 376 297 468 minecraft:magenta_concrete
fill 376 290 476 376 297 476 minecraft:magenta_concrete
fill 376 290 484 376 297 484 minecraft:magenta_concrete
fill 376 290 492 376 297 492 minecraft:magenta_concrete
fill 376 290 500 376 297 500 minecraft:magenta_concrete
fill 377 290 470 377 291 470 minecraft:black_concrete
fill 377 290 472 377 291 472 minecraft:black_concrete
fill 377 290 474 377 291 474 minecraft:black_concrete
fill 377 290 476 377 291 476 minecraft:black_concrete
fill 378 290 471 378 291 471 minecraft:black_concrete
fill 378 290 473 378 291 473 minecraft:black_concrete
fill 378 290 475 378 291 475 minecraft:black_concrete
setblock 379 290 466 minecraft:light[level=14]
fill 379 290 470 379 291 470 minecraft:black_concrete
fill 379 290 472 379 291 472 minecraft:black_concrete
fill 379 290 474 379 291 474 minecraft:black_concrete
fill 379 290 476 379 291 476 minecraft:black_concrete
setblock 379 290 482 minecraft:light[level=14]
setblock 379 290 490 minecraft:light[level=14]
setblock 379 290 498 minecraft:light[level=14]
fill 379 290 505 379 297 505 minecraft:magenta_concrete
fill 380 290 471 380 291 471 minecraft:black_concrete
fill 380 290 473 380 291 473 minecraft:black_concrete
fill 380 290 475 380 291 475 minecraft:black_concrete
fill 381 290 470 381 291 470 minecraft:black_concrete
fill 381 290 472 381 291 472 minecraft:black_concrete
fill 381 290 474 381 291 474 minecraft:black_concrete
fill 381 290 476 381 291 476 minecraft:black_concrete
fill 382 290 471 382 291 471 minecraft:black_concrete
fill 382 290 473 382 291 473 minecraft:black_concrete
fill 382 290 475 382 291 475 minecraft:black_concrete
fill 383 290 463 383 297 463 minecraft:magenta_concrete
fill 383 290 470 383 291 470 minecraft:black_concrete
fill 383 290 472 383 291 472 minecraft:black_concrete
setblock 383 290 474 minecraft:cyan_concrete
setblock 383 290 476 minecraft:cyan_concrete
fill 384 290 471 384 291 471 minecraft:black_concrete
fill 384 290 473 384 291 473 minecraft:black_concrete
setblock 384 290 475 minecraft:cyan_concrete
fill 385 290 470 385 291 470 minecraft:black_concrete
fill 385 290 472 385 291 472 minecraft:black_concrete
setblock 385 290 474 minecraft:cyan_concrete
setblock 385 290 476 minecraft:cyan_concrete
setblock 387 290 466 minecraft:light[level=14]
setblock 387 290 474 minecraft:light[level=14]
setblock 387 290 482 minecraft:light[level=14]
setblock 387 290 490 minecraft:light[level=14]
setblock 387 290 498 minecraft:light[level=14]
fill 387 290 505 387 297 505 minecraft:magenta_concrete
fill 391 290 463 391 297 463 minecraft:magenta_concrete
fill 391 290 498 391 291 498 minecraft:black_concrete
fill 391 290 500 391 291 500 minecraft:black_concrete
fill 391 290 502 391 291 502 minecraft:black_concrete
fill 391 290 504 391 291 504 minecraft:black_concrete
fill 392 290 499 392 291 499 minecraft:black_concrete
fill 392 290 501 392 291 501 minecraft:black_concrete
fill 392 290 503 392 291 503 minecraft:black_concrete
fill 393 290 498 393 291 498 minecraft:black_concrete
fill 393 290 500 393 291 500 minecraft:black_concrete
fill 393 290 502 393 291 502 minecraft:black_concrete
fill 393 290 504 393 291 504 minecraft:black_concrete
fill 394 290 499 394 291 499 minecraft:black_concrete
fill 394 290 501 394 291 501 minecraft:black_concrete
fill 394 290 503 394 291 503 minecraft:black_concrete
setblock 395 290 466 minecraft:light[level=14]
setblock 395 290 474 minecraft:light[level=14]
setblock 395 290 482 minecraft:light[level=14]
setblock 395 290 490 minecraft:light[level=14]
fill 395 290 498 395 291 498 minecraft:black_concrete
fill 395 290 500 395 291 500 minecraft:black_concrete
fill 395 290 502 395 291 502 minecraft:black_concrete
fill 395 290 504 395 291 504 minecraft:black_concrete
fill 395 290 505 395 297 505 minecraft:magenta_concrete
fill 396 290 499 396 291 499 minecraft:black_concrete
fill 396 290 501 396 291 501 minecraft:black_concrete
fill 396 290 503 396 291 503 minecraft:black_concrete
fill 397 290 498 397 291 498 minecraft:black_concrete
fill 397 290 500 397 291 500 minecraft:black_concrete
fill 397 290 502 397 291 502 minecraft:black_concrete
fill 397 290 504 397 291 504 minecraft:black_concrete
fill 398 290 499 398 291 499 minecraft:black_concrete
fill 398 290 501 398 291 501 minecraft:black_concrete
fill 398 290 503 398 291 503 minecraft:black_concrete
fill 399 290 463 399 297 463 minecraft:magenta_concrete
fill 399 290 498 399 291 498 minecraft:black_concrete
fill 399 290 500 399 291 500 minecraft:black_concrete
fill 399 290 502 399 291 502 minecraft:black_concrete
fill 399 290 504 399 291 504 minecraft:black_concrete
setblock 403 290 466 minecraft:light[level=14]
setblock 403 290 474 minecraft:light[level=14]
setblock 403 290 482 minecraft:light[level=14]
setblock 403 290 490 minecraft:light[level=14]
setblock 403 290 498 minecraft:light[level=14]
fill 403 290 505 403 297 505 minecraft:magenta_concrete
fill 407 290 463 407 297 463 minecraft:magenta_concrete
setblock 411 290 466 minecraft:light[level=14]
setblock 411 290 474 minecraft:light[level=14]
setblock 411 290 482 minecraft:light[level=14]
setblock 411 290 490 minecraft:light[level=14]
fill 411 290 505 411 297 505 minecraft:magenta_concrete
fill 415 290 463 415 297 463 minecraft:magenta_concrete
fill 418 290 468 418 297 468 minecraft:magenta_concrete
fill 418 290 476 418 297 476 minecraft:magenta_concrete
fill 418 290 484 418 297 484 minecraft:magenta_concrete
fill 418 290 492 418 297 492 minecraft:magenta_concrete
fill 418 290 500 418 297 500 minecraft:magenta_concrete
fill 383 291 474 385 291 476 minecraft:black_concrete
setblock 377 292 470 minecraft:sea_lantern
setblock 377 292 472 minecraft:sea_lantern
setblock 377 292 474 minecraft:sea_lantern
setblock 377 292 476 minecraft:sea_lantern
setblock 378 292 471 minecraft:sea_lantern
setblock 378 292 473 minecraft:sea_lantern
setblock 378 292 475 minecraft:sea_lantern
setblock 379 292 470 minecraft:sea_lantern
setblock 379 292 472 minecraft:sea_lantern
setblock 379 292 474 minecraft:sea_lantern
setblock 379 292 476 minecraft:sea_lantern
setblock 380 292 471 minecraft:sea_lantern
setblock 380 292 473 minecraft:sea_lantern
setblock 380 292 475 minecraft:sea_lantern
setblock 381 292 470 minecraft:sea_lantern
setblock 381 292 472 minecraft:sea_lantern
setblock 381 292 474 minecraft:sea_lantern
setblock 381 292 476 minecraft:sea_lantern
setblock 382 292 471 minecraft:sea_lantern
setblock 382 292 473 minecraft:sea_lantern
setblock 382 292 475 minecraft:sea_lantern
setblock 383 292 470 minecraft:sea_lantern
setblock 383 292 472 minecraft:sea_lantern
setblock 383 292 474 minecraft:sea_lantern
fill 383 292 475 383 300 475 minecraft:black_concrete
setblock 383 292 476 minecraft:sea_lantern
setblock 384 292 471 minecraft:sea_lantern
setblock 384 292 473 minecraft:sea_lantern
fill 384 292 474 384 300 474 minecraft:black_concrete
setblock 384 292 475 minecraft:sea_lantern
fill 384 292 476 384 300 476 minecraft:black_concrete
setblock 385 292 470 minecraft:sea_lantern
setblock 385 292 472 minecraft:sea_lantern
setblock 385 292 474 minecraft:sea_lantern
fill 385 292 475 385 300 475 minecraft:black_concrete
setblock 385 292 476 minecraft:sea_lantern
setblock 391 292 498 minecraft:sea_lantern
setblock 391 292 500 minecraft:sea_lantern
setblock 391 292 502 minecraft:sea_lantern
setblock 391 292 504 minecraft:sea_lantern
setblock 392 292 499 minecraft:sea_lantern
setblock 392 292 501 minecraft:sea_lantern
setblock 392 292 503 minecraft:sea_lantern
setblock 393 292 498 minecraft:sea_lantern
setblock 393 292 500 minecraft:sea_lantern
setblock 393 292 502 minecraft:sea_lantern
setblock 393 292 504 minecraft:sea_lantern
setblock 394 292 499 minecraft:sea_lantern
setblock 394 292 501 minecraft:sea_lantern
setblock 394 292 503 minecraft:sea_lantern
setblock 395 292 498 minecraft:sea_lantern
setblock 395 292 500 minecraft:sea_lantern
setblock 395 292 502 minecraft:sea_lantern
setblock 395 292 504 minecraft:sea_lantern
setblock 396 292 499 minecraft:sea_lantern
setblock 396 292 501 minecraft:sea_lantern
setblock 396 292 503 minecraft:sea_lantern
setblock 397 292 498 minecraft:sea_lantern
setblock 397 292 500 minecraft:sea_lantern
setblock 397 292 502 minecraft:sea_lantern
setblock 397 292 504 minecraft:sea_lantern
setblock 398 292 499 minecraft:sea_lantern
setblock 398 292 501 minecraft:sea_lantern
setblock 398 292 503 minecraft:sea_lantern
setblock 399 292 498 minecraft:sea_lantern
setblock 399 292 500 minecraft:sea_lantern
setblock 399 292 502 minecraft:sea_lantern
setblock 399 292 504 minecraft:sea_lantern
fill 377 293 470 377 294 470 minecraft:black_concrete
fill 377 293 472 377 294 472 minecraft:black_concrete
fill 377 293 474 377 294 474 minecraft:black_concrete
fill 377 293 476 377 294 476 minecraft:black_concrete
fill 378 293 471 378 294 471 minecraft:black_concrete
fill 378 293 473 378 294 473 minecraft:black_concrete
fill 378 293 475 378 294 475 minecraft:black_concrete
fill 379 293 470 379 294 470 minecraft:black_concrete
fill 379 293 472 379 294 472 minecraft:black_concrete
fill 379 293 474 379 294 474 minecraft:black_concrete
fill 379 293 476 379 294 476 minecraft:black_concrete
fill 380 293 471 380 294 471 minecraft:black_concrete
fill 380 293 473 380 294 473 minecraft:black_concrete
fill 380 293 475 380 294 475 minecraft:black_concrete
fill 381 293 470 381 294 470 minecraft:black_concrete
fill 381 293 472 381 294 472 minecraft:black_concrete
fill 381 293 474 381 294 474 minecraft:black_concrete
fill 381 293 476 381 294 476 minecraft:black_concrete
fill 382 293 471 382 294 471 minecraft:black_concrete
fill 382 293 473 382 294 473 minecraft:black_concrete
fill 382 293 475 382 294 475 minecraft:black_concrete
fill 383 293 470 383 294 470 minecraft:black_concrete
fill 383 293 472 383 294 472 minecraft:black_concrete
fill 383 293 474 383 294 474 minecraft:black_concrete
fill 383 293 476 383 294 476 minecraft:black_concrete
fill 384 293 471 384 294 471 minecraft:black_concrete
fill 384 293 473 384 294 473 minecraft:black_concrete
fill 384 293 475 384 294 475 minecraft:black_concrete
fill 385 293 470 385 294 470 minecraft:black_concrete
fill 385 293 472 385 294 472 minecraft:black_concrete
fill 385 293 474 385 294 474 minecraft:black_concrete
fill 385 293 476 385 294 476 minecraft:black_concrete
fill 391 293 498 391 294 498 minecraft:black_concrete
fill 391 293 500 391 294 500 minecraft:black_concrete
fill 391 293 502 391 294 502 minecraft:black_concrete
fill 391 293 504 391 294 504 minecraft:black_concrete
fill 392 293 499 392 294 499 minecraft:black_concrete
fill 392 293 501 392 294 501 minecraft:black_concrete
fill 392 293 503 392 294 503 minecraft:black_concrete
fill 393 293 498 393 294 498 minecraft:black_concrete
fill 393 293 500 393 294 500 minecraft:black_concrete
fill 393 293 502 393 294 502 minecraft:black_concrete
fill 393 293 504 393 294 504 minecraft:black_concrete
fill 394 293 499 394 294 499 minecraft:black_concrete
fill 394 293 501 394 294 501 minecraft:black_concrete
fill 394 293 503 394 294 503 minecraft:black_concrete
fill 395 293 498 395 294 498 minecraft:black_concrete
fill 395 293 500 395 294 500 minecraft:black_concrete
fill 395 293 502 395 294 502 minecraft:black_concrete
fill 395 293 504 395 294 504 minecraft:black_concrete
fill 396 293 499 396 294 499 minecraft:black_concrete
fill 396 293 501 396 294 501 minecraft:black_concrete
fill 396 293 503 396 294 503 minecraft:black_concrete
fill 397 293 498 397 294 498 minecraft:black_concrete
fill 397 293 500 397 294 500 minecraft:black_concrete
fill 397 293 502 397 294 502 minecraft:black_concrete
fill 397 293 504 397 294 504 minecraft:black_concrete
fill 398 293 499 398 294 499 minecraft:black_concrete
fill 398 293 501 398 294 501 minecraft:black_concrete
fill 398 293 503 398 294 503 minecraft:black_concrete
fill 399 293 498 399 294 498 minecraft:black_concrete
fill 399 293 500 399 294 500 minecraft:black_concrete
fill 399 293 502 399 294 502 minecraft:black_concrete
fill 399 293 504 399 294 504 minecraft:black_concrete
fill 377 294 464 377 295 469 minecraft:black_concrete
fill 377 294 477 378 294 477 minecraft:black_concrete
fill 377 294 480 378 294 485 minecraft:black_concrete
fill 377 294 488 378 294 493 minecraft:black_concrete
fill 377 294 496 378 294 501 minecraft:black_concrete
fill 377 294 504 382 295 504 minecraft:black_concrete
fill 378 294 465 378 294 469 minecraft:black_concrete
fill 378 294 478 378 294 479 minecraft:black_concrete
fill 378 294 486 378 294 487 minecraft:black_concrete
fill 378 294 494 378 294 495 minecraft:black_concrete
fill 378 294 502 378 294 503 minecraft:black_concrete
fill 379 294 465 416 294 465 minecraft:black_concrete
fill 379 294 503 390 294 503 minecraft:black_concrete
fill 380 294 464 385 295 464 minecraft:black_concrete
fill 385 294 504 390 295 504 minecraft:black_concrete
fill 388 294 464 393 295 464 minecraft:black_concrete
fill 396 294 464 401 295 464 minecraft:black_concrete
fill 400 294 503 417 294 503 minecraft:black_concrete
fill 401 294 504 406 295 504 minecraft:black_concrete
fill 404 294 464 409 295 464 minecraft:black_concrete
fill 409 294 504 414 295 504 minecraft:black_concrete
fill 412 294 464 417 295 464 minecraft:black_concrete
fill 416 294 466 416 294 502 minecraft:black_concrete
fill 417 294 467 417 295 472 minecraft:black_concrete
fill 417 294 475 417 295 480 minecraft:black_concrete
fill 417 294 483 417 295 488 minecraft:black_concrete
fill 417 294 491 417 295 496 minecraft:black_concrete
fill 417 294 499 417 295 502 minecraft:black_concrete
fill 417 294 504 417 295 504 minecraft:black_concrete
setblock 377 295 470 minecraft:sea_lantern
setblock 377 295 472 minecraft:sea_lantern
setblock 377 295 474 minecraft:sea_lantern
setblock 377 295 476 minecraft:sea_lantern
setblock 377 295 477 minecraft:black_concrete
fill 377 295 480 377 295 485 minecraft:black_concrete
fill 377 295 488 377 295 493 minecraft:black_concrete
fill 377 295 496 377 295 501 minecraft:black_concrete
setblock 378 295 471 minecraft:sea_lantern
setblock 378 295 473 minecraft:sea_lantern
setblock 378 295 475 minecraft:sea_lantern
setblock 379 295 470 minecraft:sea_lantern
setblock 379 295 472 minecraft:sea_lantern
setblock 379 295 474 minecraft:sea_lantern
setblock 379 295 476 minecraft:sea_lantern
setblock 380 295 471 minecraft:sea_lantern
setblock 380 295 473 minecraft:sea_lantern
setblock 380 295 475 minecraft:sea_lantern
setblock 381 295 470 minecraft:sea_lantern
setblock 381 295 472 minecraft:sea_lantern
setblock 381 295 474 minecraft:sea_lantern
setblock 381 295 476 minecraft:sea_lantern
setblock 382 295 471 minecraft:sea_lantern
setblock 382 295 473 minecraft:sea_lantern
setblock 382 295 475 minecraft:sea_lantern
setblock 383 295 470 minecraft:sea_lantern
setblock 383 295 472 minecraft:sea_lantern
setblock 383 295 474 minecraft:sea_lantern
setblock 383 295 476 minecraft:sea_lantern
setblock 384 295 471 minecraft:sea_lantern
setblock 384 295 473 minecraft:sea_lantern
setblock 384 295 475 minecraft:sea_lantern
setblock 385 295 470 minecraft:sea_lantern
setblock 385 295 472 minecraft:sea_lantern
setblock 385 295 474 minecraft:sea_lantern
setblock 385 295 476 minecraft:sea_lantern
setblock 391 295 498 minecraft:sea_lantern
setblock 391 295 500 minecraft:sea_lantern
setblock 391 295 502 minecraft:sea_lantern
schedule function dropper:buildpart/116_3 1t
