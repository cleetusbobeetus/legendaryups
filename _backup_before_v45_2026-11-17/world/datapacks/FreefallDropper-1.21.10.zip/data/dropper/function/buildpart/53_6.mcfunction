fill 272 226 255 276 228 265 minecraft:gray_concrete
fill 274 226 232 274 227 238 minecraft:iron_block
setblock 274 226 270 minecraft:sea_lantern
fill 235 227 246 235 251 246 minecraft:black_concrete
fill 235 227 253 235 304 253 minecraft:black_concrete
fill 235 227 261 235 308 261 minecraft:black_concrete
setblock 236 227 243 minecraft:ochre_froglight
setblock 236 227 245 minecraft:magenta_stained_glass
setblock 236 227 247 minecraft:magenta_stained_glass
setblock 236 227 249 minecraft:sea_lantern
setblock 236 227 251 minecraft:sea_lantern
setblock 236 227 253 minecraft:black_stained_glass
setblock 237 227 242 minecraft:sea_lantern
setblock 237 227 255 minecraft:black_stained_glass
setblock 238 227 231 minecraft:light[level=15]
setblock 238 227 239 minecraft:light[level=15]
setblock 239 227 242 minecraft:pearlescent_froglight
setblock 239 227 255 minecraft:sea_lantern
setblock 241 227 243 minecraft:black_stained_glass
setblock 241 227 245 minecraft:magenta_stained_glass
setblock 241 227 247 minecraft:sea_lantern
setblock 241 227 249 minecraft:black_stained_glass
setblock 241 227 251 minecraft:light_blue_stained_glass
setblock 241 227 253 minecraft:light_blue_stained_glass
fill 243 227 270 243 259 270 minecraft:black_concrete
setblock 246 227 231 minecraft:light[level=15]
setblock 246 227 239 minecraft:light[level=15]
setblock 246 227 247 minecraft:light[level=15]
setblock 246 227 255 minecraft:light[level=15]
setblock 249 227 265 minecraft:black_stained_glass
setblock 250 227 264 minecraft:black_stained_glass
setblock 250 227 269 minecraft:cyan_stained_glass
setblock 252 227 269 minecraft:ochre_froglight
setblock 254 227 231 minecraft:light[level=15]
setblock 254 227 239 minecraft:light[level=15]
setblock 254 227 263 minecraft:light[level=15]
setblock 254 227 264 minecraft:ochre_froglight
setblock 254 227 269 minecraft:ochre_froglight
fill 255 227 264 255 282 264 minecraft:gray_concrete
setblock 256 227 264 minecraft:black_stained_glass
setblock 256 227 269 minecraft:black_stained_glass
setblock 258 227 264 minecraft:pearlescent_froglight
setblock 258 227 269 minecraft:black_stained_glass
setblock 260 227 264 minecraft:magenta_stained_glass
setblock 260 227 269 minecraft:ochre_froglight
fill 261 227 229 261 228 231 minecraft:iron_block
setblock 262 227 231 minecraft:light[level=15]
setblock 262 227 239 minecraft:light[level=15]
setblock 262 227 263 minecraft:light[level=15]
setblock 262 227 265 minecraft:black_stained_glass
setblock 262 227 267 minecraft:ochre_froglight
setblock 270 227 239 minecraft:light[level=15]
setblock 270 227 255 minecraft:light[level=15]
setblock 270 227 263 minecraft:light[level=15]
setblock 274 227 228 minecraft:verdant_froglight
fill 274 227 270 274 277 270 minecraft:black_concrete
fill 236 228 243 236 229 243 minecraft:black_concrete
fill 236 228 245 236 229 245 minecraft:black_concrete
fill 236 228 247 236 229 247 minecraft:black_concrete
fill 236 228 249 236 229 249 minecraft:black_concrete
fill 236 228 251 236 229 251 minecraft:black_concrete
fill 236 228 253 236 229 253 minecraft:black_concrete
fill 237 228 242 237 229 242 minecraft:black_concrete
fill 237 228 255 237 229 255 minecraft:black_concrete
fill 239 228 242 239 229 242 minecraft:black_concrete
fill 239 228 255 239 229 255 minecraft:black_concrete
fill 241 228 243 241 229 243 minecraft:black_concrete
fill 241 228 245 241 229 245 minecraft:black_concrete
fill 241 228 247 241 229 247 minecraft:black_concrete
fill 241 228 249 241 229 249 minecraft:black_concrete
fill 241 228 251 241 229 251 minecraft:black_concrete
fill 241 228 253 241 229 253 minecraft:black_concrete
setblock 249 228 247 minecraft:black_stained_glass
setblock 249 228 249 minecraft:black_stained_glass
setblock 249 228 251 minecraft:sea_lantern
setblock 249 228 253 minecraft:light_blue_stained_glass
setblock 249 228 255 minecraft:black_stained_glass
setblock 249 228 257 minecraft:sea_lantern
setblock 249 228 259 minecraft:sea_lantern
fill 249 228 265 249 229 265 minecraft:gray_concrete
setblock 250 228 246 minecraft:sea_lantern
setblock 250 228 261 minecraft:black_stained_glass
fill 250 228 264 250 229 264 minecraft:gray_concrete
setblock 250 228 269 minecraft:gray_concrete
setblock 252 228 246 minecraft:light_blue_stained_glass
setblock 252 228 261 minecraft:sea_lantern
setblock 252 228 269 minecraft:gray_concrete
setblock 254 228 246 minecraft:sea_lantern
setblock 254 228 261 minecraft:black_stained_glass
fill 254 228 264 254 229 264 minecraft:gray_concrete
fill 254 228 269 254 229 269 minecraft:gray_concrete
setblock 256 228 246 minecraft:light_blue_stained_glass
setblock 256 228 261 minecraft:sea_lantern
fill 256 228 264 256 229 264 minecraft:gray_concrete
fill 256 228 269 256 229 269 minecraft:gray_concrete
setblock 258 228 246 minecraft:sea_lantern
setblock 258 228 261 minecraft:sea_lantern
fill 258 228 264 258 229 264 minecraft:gray_concrete
fill 258 228 269 258 229 269 minecraft:gray_concrete
setblock 260 228 246 minecraft:sea_lantern
setblock 260 228 261 minecraft:black_stained_glass
fill 260 228 264 260 229 264 minecraft:gray_concrete
fill 260 228 269 260 229 269 minecraft:gray_concrete
setblock 260 228 270 minecraft:cyan_concrete
setblock 262 228 246 minecraft:black_stained_glass
setblock 262 228 261 minecraft:sea_lantern
fill 262 228 265 262 229 265 minecraft:gray_concrete
fill 262 228 267 262 229 267 minecraft:gray_concrete
setblock 264 228 247 minecraft:sea_lantern
setblock 264 228 249 minecraft:black_stained_glass
setblock 264 228 251 minecraft:sea_lantern
setblock 264 228 253 minecraft:light_blue_stained_glass
setblock 264 228 255 minecraft:sea_lantern
setblock 264 228 257 minecraft:black_stained_glass
setblock 264 228 259 minecraft:light_blue_stained_glass
fill 274 228 228 274 270 228 minecraft:black_concrete
setblock 277 228 230 minecraft:pearlescent_froglight
setblock 277 228 239 minecraft:cyan_concrete
setblock 235 229 262 minecraft:sea_lantern
setblock 235 229 264 minecraft:sea_lantern
setblock 235 229 266 minecraft:sea_lantern
setblock 235 229 268 minecraft:sea_lantern
fill 236 229 262 236 240 262 minecraft:gray_concrete
setblock 236 229 263 minecraft:sea_lantern
fill 236 229 264 236 240 264 minecraft:gray_concrete
setblock 236 229 265 minecraft:sea_lantern
fill 236 229 266 236 240 266 minecraft:gray_concrete
setblock 236 229 267 minecraft:sea_lantern
fill 236 229 268 236 240 268 minecraft:gray_concrete
setblock 236 229 269 minecraft:sea_lantern
setblock 237 229 262 minecraft:sea_lantern
fill 237 229 263 237 240 263 minecraft:gray_concrete
setblock 237 229 264 minecraft:sea_lantern
fill 237 229 265 237 240 265 minecraft:gray_concrete
setblock 237 229 266 minecraft:sea_lantern
fill 237 229 267 237 240 267 minecraft:gray_concrete
setblock 237 229 268 minecraft:sea_lantern
fill 237 229 269 237 240 269 minecraft:gray_concrete
setblock 238 229 231 minecraft:light[level=12]
setblock 238 229 238 minecraft:light[level=12]
setblock 238 229 259 minecraft:light[level=12]
fill 238 229 262 238 240 262 minecraft:gray_concrete
setblock 238 229 263 minecraft:sea_lantern
fill 238 229 264 238 240 264 minecraft:gray_concrete
setblock 238 229 265 minecraft:sea_lantern
fill 238 229 266 238 240 266 minecraft:gray_concrete
setblock 238 229 267 minecraft:sea_lantern
fill 238 229 268 238 240 268 minecraft:gray_concrete
setblock 238 229 269 minecraft:sea_lantern
fill 239 229 261 239 239 261 minecraft:gray_concrete
setblock 239 229 262 minecraft:sea_lantern
fill 239 229 263 239 240 263 minecraft:gray_concrete
setblock 239 229 264 minecraft:sea_lantern
fill 239 229 265 239 240 265 minecraft:gray_concrete
setblock 239 229 266 minecraft:sea_lantern
fill 239 229 267 239 240 267 minecraft:gray_concrete
setblock 239 229 268 minecraft:sea_lantern
fill 239 229 269 239 240 269 minecraft:gray_concrete
setblock 240 229 261 minecraft:sea_lantern
fill 240 229 262 240 240 262 minecraft:gray_concrete
setblock 240 229 263 minecraft:sea_lantern
fill 240 229 264 240 240 264 minecraft:gray_concrete
setblock 240 229 265 minecraft:sea_lantern
fill 240 229 266 240 240 266 minecraft:gray_concrete
setblock 240 229 267 minecraft:sea_lantern
fill 240 229 268 240 240 268 minecraft:gray_concrete
setblock 240 229 269 minecraft:sea_lantern
fill 241 229 261 241 239 261 minecraft:gray_concrete
setblock 241 229 262 minecraft:sea_lantern
fill 241 229 263 241 240 263 minecraft:gray_concrete
setblock 241 229 264 minecraft:sea_lantern
fill 241 229 265 241 240 265 minecraft:gray_concrete
setblock 241 229 266 minecraft:sea_lantern
fill 241 229 267 241 240 267 minecraft:gray_concrete
setblock 241 229 268 minecraft:sea_lantern
fill 241 229 269 241 240 269 minecraft:gray_concrete
setblock 241 229 270 minecraft:purple_concrete
setblock 242 229 261 minecraft:sea_lantern
fill 242 229 262 242 240 262 minecraft:gray_concrete
setblock 242 229 263 minecraft:sea_lantern
fill 242 229 264 242 240 264 minecraft:gray_concrete
setblock 242 229 265 minecraft:sea_lantern
fill 242 229 266 242 240 266 minecraft:gray_concrete
setblock 242 229 267 minecraft:sea_lantern
fill 242 229 268 242 240 268 minecraft:gray_concrete
setblock 242 229 269 minecraft:sea_lantern
fill 243 229 261 243 240 261 minecraft:gray_concrete
setblock 243 229 262 minecraft:sea_lantern
fill 243 229 263 243 240 263 minecraft:gray_concrete
setblock 243 229 264 minecraft:sea_lantern
fill 243 229 265 243 240 265 minecraft:gray_concrete
setblock 243 229 266 minecraft:sea_lantern
fill 243 229 267 243 240 267 minecraft:gray_concrete
setblock 243 229 268 minecraft:sea_lantern
fill 243 229 269 243 240 269 minecraft:gray_concrete
setblock 244 229 261 minecraft:sea_lantern
fill 244 229 262 244 240 262 minecraft:gray_concrete
setblock 244 229 263 minecraft:sea_lantern
fill 244 229 264 244 240 264 minecraft:gray_concrete
setblock 244 229 265 minecraft:sea_lantern
fill 244 229 266 244 240 266 minecraft:gray_concrete
setblock 244 229 267 minecraft:sea_lantern
fill 244 229 268 244 240 268 minecraft:gray_concrete
setblock 244 229 269 minecraft:sea_lantern
setblock 245 229 231 minecraft:light[level=12]
setblock 245 229 238 minecraft:light[level=12]
setblock 245 229 245 minecraft:light[level=12]
setblock 245 229 252 minecraft:light[level=12]
setblock 245 229 259 minecraft:light[level=12]
fill 245 229 261 245 240 261 minecraft:gray_concrete
setblock 245 229 262 minecraft:sea_lantern
fill 245 229 263 245 240 263 minecraft:gray_concrete
setblock 245 229 264 minecraft:sea_lantern
fill 245 229 265 245 240 265 minecraft:gray_concrete
setblock 245 229 266 minecraft:sea_lantern
fill 245 229 267 245 240 267 minecraft:gray_concrete
setblock 245 229 268 minecraft:sea_lantern
fill 245 229 269 245 240 269 minecraft:gray_concrete
setblock 246 229 228 minecraft:purple_concrete
setblock 246 229 261 minecraft:sea_lantern
fill 246 229 262 246 240 262 minecraft:gray_concrete
setblock 246 229 263 minecraft:sea_lantern
fill 246 229 264 246 240 264 minecraft:gray_concrete
setblock 246 229 265 minecraft:sea_lantern
fill 246 229 266 246 240 266 minecraft:gray_concrete
setblock 246 229 267 minecraft:sea_lantern
fill 246 229 268 246 240 268 minecraft:gray_concrete
setblock 246 229 269 minecraft:sea_lantern
fill 247 229 261 247 240 261 minecraft:gray_concrete
setblock 247 229 262 minecraft:sea_lantern
fill 247 229 263 247 240 263 minecraft:gray_concrete
setblock 247 229 264 minecraft:sea_lantern
fill 247 229 265 247 240 265 minecraft:gray_concrete
setblock 247 229 266 minecraft:sea_lantern
fill 247 229 267 247 240 267 minecraft:gray_concrete
setblock 247 229 268 minecraft:sea_lantern
fill 247 229 269 247 240 269 minecraft:gray_concrete
setblock 248 229 261 minecraft:sea_lantern
fill 248 229 262 248 240 262 minecraft:gray_concrete
setblock 248 229 263 minecraft:sea_lantern
fill 248 229 264 248 240 264 minecraft:gray_concrete
setblock 248 229 265 minecraft:sea_lantern
fill 248 229 266 248 240 266 minecraft:gray_concrete
setblock 248 229 267 minecraft:sea_lantern
fill 248 229 268 248 240 268 minecraft:gray_concrete
setblock 248 229 269 minecraft:sea_lantern
fill 249 229 247 249 230 247 minecraft:gray_concrete
fill 249 229 249 249 230 249 minecraft:gray_concrete
fill 249 229 251 249 230 251 minecraft:gray_concrete
fill 249 229 253 249 230 253 minecraft:gray_concrete
fill 249 229 255 249 230 255 minecraft:gray_concrete
fill 249 229 257 249 230 257 minecraft:gray_concrete
fill 249 229 259 249 230 259 minecraft:gray_concrete
setblock 249 229 262 minecraft:sea_lantern
fill 249 229 263 249 240 263 minecraft:gray_concrete
setblock 249 229 264 minecraft:sea_lantern
setblock 249 229 266 minecraft:sea_lantern
setblock 249 229 268 minecraft:sea_lantern
setblock 250 229 228 minecraft:verdant_froglight
fill 250 229 246 250 230 246 minecraft:gray_concrete
fill 250 229 261 250 230 262 minecraft:gray_concrete
setblock 250 229 263 minecraft:sea_lantern
setblock 250 229 265 minecraft:sea_lantern
fill 250 229 266 250 282 266 minecraft:gray_concrete
setblock 250 229 267 minecraft:sea_lantern
setblock 250 229 269 minecraft:sea_lantern
setblock 251 229 262 minecraft:sea_lantern
fill 251 229 263 251 240 263 minecraft:gray_concrete
setblock 251 229 264 minecraft:sea_lantern
fill 251 229 265 251 282 265 minecraft:gray_concrete
setblock 251 229 266 minecraft:sea_lantern
fill 251 229 267 251 282 267 minecraft:gray_concrete
setblock 251 229 268 minecraft:sea_lantern
setblock 252 229 231 minecraft:light[level=12]
setblock 252 229 238 minecraft:light[level=12]
setblock 252 229 245 minecraft:light[level=12]
fill 252 229 246 252 230 246 minecraft:gray_concrete
fill 252 229 261 252 230 262 minecraft:gray_concrete
setblock 252 229 263 minecraft:sea_lantern
setblock 252 229 265 minecraft:sea_lantern
fill 252 229 266 252 282 266 minecraft:gray_concrete
setblock 252 229 267 minecraft:sea_lantern
fill 252 229 268 252 282 268 minecraft:gray_concrete
setblock 252 229 269 minecraft:sea_lantern
setblock 253 229 262 minecraft:sea_lantern
fill 253 229 263 253 240 263 minecraft:gray_concrete
setblock 253 229 264 minecraft:sea_lantern
fill 253 229 265 253 282 265 minecraft:gray_concrete
setblock 253 229 266 minecraft:sea_lantern
fill 253 229 267 256 282 267 minecraft:gray_concrete
setblock 253 229 268 minecraft:sea_lantern
fill 254 229 246 254 230 246 minecraft:gray_concrete
fill 254 229 261 254 230 261 minecraft:gray_concrete
fill 254 229 266 256 282 266 minecraft:gray_concrete
fill 254 229 268 254 282 268 minecraft:gray_concrete
fill 256 229 246 256 230 246 minecraft:gray_concrete
fill 256 229 261 256 230 261 minecraft:gray_concrete
fill 258 229 246 258 230 246 minecraft:gray_concrete
fill 258 229 261 258 230 261 minecraft:gray_concrete
setblock 259 229 231 minecraft:light[level=12]
setblock 259 229 238 minecraft:light[level=12]
setblock 259 229 245 minecraft:light[level=12]
fill 260 229 246 260 230 246 minecraft:gray_concrete
fill 260 229 261 260 230 261 minecraft:gray_concrete
fill 260 229 270 260 262 270 minecraft:black_concrete
fill 262 229 246 262 230 246 minecraft:gray_concrete
fill 262 229 261 262 230 261 minecraft:gray_concrete
fill 264 229 247 264 230 247 minecraft:gray_concrete
fill 264 229 249 264 230 249 minecraft:gray_concrete
fill 264 229 251 264 230 251 minecraft:gray_concrete
fill 264 229 253 264 230 253 minecraft:gray_concrete
fill 264 229 255 264 230 255 minecraft:gray_concrete
fill 264 229 257 264 230 257 minecraft:gray_concrete
fill 264 229 259 264 230 259 minecraft:gray_concrete
setblock 266 229 231 minecraft:light[level=12]
setblock 266 229 238 minecraft:light[level=12]
setblock 266 229 245 minecraft:light[level=12]
setblock 266 229 252 minecraft:light[level=12]
setblock 266 229 259 minecraft:light[level=12]
setblock 266 229 266 minecraft:light[level=12]
fill 267 229 229 267 244 229 minecraft:gray_concrete
setblock 267 229 230 minecraft:sea_lantern
fill 267 229 231 267 244 231 minecraft:gray_concrete
setblock 267 229 232 minecraft:sea_lantern
fill 267 229 233 267 244 233 minecraft:gray_concrete
setblock 268 229 229 minecraft:sea_lantern
fill 268 229 230 268 244 230 minecraft:gray_concrete
setblock 268 229 231 minecraft:sea_lantern
fill 268 229 232 268 244 232 minecraft:gray_concrete
setblock 268 229 233 minecraft:sea_lantern
setblock 268 229 241 minecraft:sea_lantern
fill 268 229 242 268 253 242 minecraft:gray_concrete
setblock 268 229 243 minecraft:sea_lantern
fill 268 229 244 268 253 244 minecraft:gray_concrete
setblock 268 229 245 minecraft:sea_lantern
fill 268 229 246 268 253 246 minecraft:gray_concrete
setblock 268 229 247 minecraft:sea_lantern
fill 268 229 248 268 253 248 minecraft:gray_concrete
setblock 268 229 249 minecraft:sea_lantern
fill 269 229 229 269 244 229 minecraft:gray_concrete
setblock 269 229 230 minecraft:sea_lantern
fill 269 229 231 269 244 231 minecraft:gray_concrete
setblock 269 229 232 minecraft:sea_lantern
fill 269 229 233 269 244 233 minecraft:gray_concrete
fill 269 229 241 269 253 241 minecraft:gray_concrete
setblock 269 229 242 minecraft:sea_lantern
fill 269 229 243 269 253 243 minecraft:gray_concrete
setblock 269 229 244 minecraft:sea_lantern
fill 269 229 245 269 253 245 minecraft:gray_concrete
setblock 269 229 246 minecraft:sea_lantern
fill 269 229 247 269 253 247 minecraft:gray_concrete
setblock 269 229 248 minecraft:sea_lantern
fill 269 229 249 269 253 249 minecraft:gray_concrete
setblock 270 229 229 minecraft:sea_lantern
fill 270 229 230 270 244 230 minecraft:gray_concrete
setblock 270 229 231 minecraft:sea_lantern
fill 270 229 232 270 244 232 minecraft:gray_concrete
setblock 270 229 233 minecraft:sea_lantern
setblock 270 229 241 minecraft:sea_lantern
fill 270 229 242 270 253 242 minecraft:gray_concrete
setblock 270 229 243 minecraft:sea_lantern
fill 270 229 244 270 253 244 minecraft:gray_concrete
setblock 270 229 245 minecraft:sea_lantern
fill 270 229 246 270 253 246 minecraft:gray_concrete
setblock 270 229 247 minecraft:sea_lantern
fill 270 229 248 270 253 248 minecraft:gray_concrete
setblock 270 229 249 minecraft:sea_lantern
fill 271 229 229 271 244 229 minecraft:gray_concrete
setblock 271 229 230 minecraft:sea_lantern
fill 271 229 231 271 244 231 minecraft:gray_concrete
setblock 271 229 232 minecraft:sea_lantern
fill 271 229 233 271 244 233 minecraft:gray_concrete
fill 271 229 241 271 253 241 minecraft:gray_concrete
setblock 271 229 242 minecraft:sea_lantern
fill 271 229 243 271 253 243 minecraft:gray_concrete
setblock 271 229 244 minecraft:sea_lantern
fill 271 229 245 271 253 245 minecraft:gray_concrete
setblock 271 229 246 minecraft:sea_lantern
fill 271 229 247 271 253 247 minecraft:gray_concrete
setblock 271 229 248 minecraft:sea_lantern
fill 271 229 249 271 253 249 minecraft:gray_concrete
setblock 272 229 229 minecraft:sea_lantern
fill 272 229 230 272 244 230 minecraft:gray_concrete
setblock 272 229 231 minecraft:sea_lantern
fill 272 229 232 272 244 232 minecraft:gray_concrete
setblock 272 229 233 minecraft:sea_lantern
setblock 272 229 241 minecraft:sea_lantern
fill 272 229 242 272 253 242 minecraft:gray_concrete
setblock 272 229 243 minecraft:sea_lantern
fill 272 229 244 272 253 244 minecraft:gray_concrete
setblock 272 229 245 minecraft:sea_lantern
fill 272 229 246 272 253 246 minecraft:gray_concrete
setblock 272 229 247 minecraft:sea_lantern
fill 272 229 248 272 253 248 minecraft:gray_concrete
setblock 272 229 249 minecraft:sea_lantern
setblock 272 229 255 minecraft:sea_lantern
fill 272 229 256 272 241 256 minecraft:gray_concrete
setblock 272 229 257 minecraft:sea_lantern
fill 272 229 258 272 241 258 minecraft:gray_concrete
setblock 272 229 259 minecraft:sea_lantern
fill 272 229 260 272 241 260 minecraft:gray_concrete
setblock 272 229 261 minecraft:sea_lantern
fill 272 229 262 272 241 262 minecraft:gray_concrete
setblock 272 229 263 minecraft:sea_lantern
fill 272 229 264 272 241 264 minecraft:gray_concrete
setblock 272 229 265 minecraft:sea_lantern
fill 273 229 229 273 244 229 minecraft:gray_concrete
setblock 273 229 230 minecraft:sea_lantern
fill 273 229 231 273 244 231 minecraft:gray_concrete
setblock 273 229 232 minecraft:sea_lantern
fill 273 229 233 273 244 233 minecraft:gray_concrete
setblock 273 229 238 minecraft:light[level=12]
fill 273 229 241 273 253 241 minecraft:gray_concrete
setblock 273 229 242 minecraft:sea_lantern
fill 273 229 243 273 253 243 minecraft:gray_concrete
setblock 273 229 244 minecraft:sea_lantern
fill 273 229 245 273 253 245 minecraft:gray_concrete
setblock 273 229 246 minecraft:sea_lantern
fill 273 229 247 273 253 247 minecraft:gray_concrete
setblock 273 229 248 minecraft:sea_lantern
fill 273 229 249 273 253 249 minecraft:gray_concrete
setblock 273 229 252 minecraft:light[level=12]
fill 273 229 255 273 241 255 minecraft:gray_concrete
setblock 273 229 256 minecraft:sea_lantern
fill 273 229 257 273 241 257 minecraft:gray_concrete
setblock 273 229 258 minecraft:sea_lantern
fill 273 229 259 273 241 259 minecraft:gray_concrete
setblock 273 229 260 minecraft:sea_lantern
fill 273 229 261 273 241 261 minecraft:gray_concrete
setblock 273 229 262 minecraft:sea_lantern
fill 273 229 263 273 241 263 minecraft:gray_concrete
setblock 273 229 264 minecraft:sea_lantern
fill 273 229 265 273 241 265 minecraft:gray_concrete
setblock 273 229 266 minecraft:light[level=12]
setblock 274 229 241 minecraft:sea_lantern
fill 274 229 242 274 253 242 minecraft:gray_concrete
setblock 274 229 243 minecraft:sea_lantern
fill 274 229 244 274 253 244 minecraft:gray_concrete
setblock 274 229 245 minecraft:sea_lantern
fill 274 229 246 274 253 246 minecraft:gray_concrete
setblock 274 229 247 minecraft:sea_lantern
fill 274 229 248 274 253 248 minecraft:gray_concrete
setblock 274 229 249 minecraft:sea_lantern
setblock 274 229 255 minecraft:sea_lantern
fill 274 229 256 274 241 256 minecraft:gray_concrete
setblock 274 229 257 minecraft:sea_lantern
fill 274 229 258 274 241 258 minecraft:gray_concrete
setblock 274 229 259 minecraft:sea_lantern
fill 274 229 260 274 241 260 minecraft:gray_concrete
setblock 274 229 261 minecraft:sea_lantern
fill 274 229 262 274 241 262 minecraft:gray_concrete
setblock 274 229 263 minecraft:sea_lantern
fill 274 229 264 274 241 264 minecraft:gray_concrete
setblock 274 229 265 minecraft:sea_lantern
fill 275 229 241 275 253 241 minecraft:gray_concrete
setblock 275 229 242 minecraft:sea_lantern
fill 275 229 243 275 253 243 minecraft:gray_concrete
setblock 275 229 244 minecraft:sea_lantern
fill 275 229 245 275 253 245 minecraft:gray_concrete
setblock 275 229 246 minecraft:sea_lantern
fill 275 229 247 275 253 247 minecraft:gray_concrete
setblock 275 229 248 minecraft:sea_lantern
fill 275 229 249 275 253 249 minecraft:gray_concrete
fill 275 229 255 275 241 255 minecraft:gray_concrete
setblock 275 229 256 minecraft:sea_lantern
fill 275 229 257 275 241 257 minecraft:gray_concrete
setblock 275 229 258 minecraft:sea_lantern
fill 275 229 259 275 241 259 minecraft:gray_concrete
setblock 275 229 260 minecraft:sea_lantern
fill 275 229 261 275 241 261 minecraft:gray_concrete
setblock 275 229 262 minecraft:sea_lantern
fill 275 229 263 275 241 263 minecraft:gray_concrete
setblock 275 229 264 minecraft:sea_lantern
fill 275 229 265 275 241 265 minecraft:gray_concrete
setblock 276 229 241 minecraft:sea_lantern
fill 276 229 242 276 253 242 minecraft:gray_concrete
setblock 276 229 243 minecraft:sea_lantern
fill 276 229 244 276 253 244 minecraft:gray_concrete
setblock 276 229 245 minecraft:sea_lantern
fill 276 229 246 276 253 246 minecraft:gray_concrete
setblock 276 229 247 minecraft:sea_lantern
fill 276 229 248 276 253 248 minecraft:gray_concrete
setblock 276 229 249 minecraft:sea_lantern
setblock 276 229 255 minecraft:sea_lantern
fill 276 229 256 276 241 256 minecraft:gray_concrete
setblock 276 229 257 minecraft:sea_lantern
fill 276 229 258 276 241 258 minecraft:gray_concrete
setblock 276 229 259 minecraft:sea_lantern
fill 276 229 260 276 241 260 minecraft:gray_concrete
setblock 276 229 261 minecraft:sea_lantern
fill 276 229 262 276 241 262 minecraft:gray_concrete
setblock 276 229 263 minecraft:sea_lantern
fill 276 229 264 276 241 264 minecraft:gray_concrete
setblock 276 229 265 minecraft:sea_lantern
setblock 276 229 270 minecraft:magenta_concrete
fill 277 229 230 277 275 230 minecraft:black_concrete
fill 277 229 239 277 308 239 minecraft:black_concrete
setblock 235 230 232 minecraft:verdant_froglight
fill 235 230 262 235 231 262 minecraft:black_concrete
fill 235 230 264 235 231 264 minecraft:black_concrete
fill 235 230 266 235 231 266 minecraft:black_concrete
fill 235 230 268 235 231 268 minecraft:black_concrete
setblock 236 230 243 minecraft:sea_lantern
setblock 236 230 245 minecraft:light_blue_stained_glass
setblock 236 230 247 minecraft:pearlescent_froglight
setblock 236 230 249 minecraft:black_stained_glass
setblock 236 230 251 minecraft:magenta_stained_glass
setblock 236 230 253 minecraft:pearlescent_froglight
fill 236 230 263 236 231 263 minecraft:gray_concrete
fill 236 230 265 236 231 265 minecraft:gray_concrete
fill 236 230 267 236 231 267 minecraft:gray_concrete
fill 236 230 269 236 231 269 minecraft:gray_concrete
setblock 237 230 242 minecraft:magenta_stained_glass
setblock 237 230 255 minecraft:light_blue_stained_glass
fill 237 230 262 237 231 262 minecraft:gray_concrete
fill 237 230 264 237 231 264 minecraft:gray_concrete
fill 237 230 266 237 231 266 minecraft:gray_concrete
fill 237 230 268 237 231 268 minecraft:gray_concrete
fill 238 230 263 238 231 263 minecraft:gray_concrete
fill 238 230 265 238 231 265 minecraft:gray_concrete
fill 238 230 267 238 231 267 minecraft:gray_concrete
fill 238 230 269 238 231 269 minecraft:gray_concrete
setblock 239 230 242 minecraft:ochre_froglight
setblock 239 230 255 minecraft:sea_lantern
fill 239 230 262 239 231 262 minecraft:gray_concrete
fill 239 230 264 239 231 264 minecraft:gray_concrete
fill 239 230 266 239 231 266 minecraft:gray_concrete
fill 239 230 268 239 231 268 minecraft:gray_concrete
fill 240 230 261 240 231 261 minecraft:gray_concrete
fill 240 230 263 240 231 263 minecraft:gray_concrete
fill 240 230 265 240 231 265 minecraft:gray_concrete
fill 240 230 267 240 231 267 minecraft:gray_concrete
fill 240 230 269 240 231 269 minecraft:gray_concrete
setblock 241 230 243 minecraft:ochre_froglight
setblock 241 230 245 minecraft:black_stained_glass
setblock 241 230 247 minecraft:pearlescent_froglight
setblock 241 230 249 minecraft:ochre_froglight
setblock 241 230 251 minecraft:magenta_stained_glass
setblock 241 230 253 minecraft:black_stained_glass
fill 241 230 262 241 231 262 minecraft:gray_concrete
fill 241 230 264 241 231 264 minecraft:gray_concrete
fill 241 230 266 241 231 266 minecraft:gray_concrete
fill 241 230 268 241 231 268 minecraft:gray_concrete
fill 241 230 270 241 246 270 minecraft:black_concrete
fill 242 230 261 242 231 261 minecraft:gray_concrete
fill 242 230 263 242 231 263 minecraft:gray_concrete
fill 242 230 265 242 231 265 minecraft:gray_concrete
fill 242 230 267 242 231 267 minecraft:gray_concrete
fill 242 230 269 242 231 269 minecraft:gray_concrete
fill 243 230 262 243 231 262 minecraft:gray_concrete
fill 243 230 264 243 231 264 minecraft:gray_concrete
fill 243 230 266 243 231 266 minecraft:gray_concrete
fill 243 230 268 243 231 268 minecraft:gray_concrete
fill 244 230 261 244 231 261 minecraft:gray_concrete
fill 244 230 263 244 231 263 minecraft:gray_concrete
fill 244 230 265 244 231 265 minecraft:gray_concrete
fill 244 230 267 244 231 267 minecraft:gray_concrete
fill 244 230 269 244 231 269 minecraft:gray_concrete
fill 245 230 262 245 231 262 minecraft:gray_concrete
fill 245 230 264 245 231 264 minecraft:gray_concrete
fill 245 230 266 245 231 266 minecraft:gray_concrete
fill 245 230 268 245 231 268 minecraft:gray_concrete
fill 246 230 228 246 290 228 minecraft:black_concrete
fill 246 230 261 246 231 261 minecraft:gray_concrete
fill 246 230 263 246 231 263 minecraft:gray_concrete
fill 246 230 265 246 231 265 minecraft:gray_concrete
fill 246 230 267 246 231 267 minecraft:gray_concrete
fill 246 230 269 246 231 269 minecraft:gray_concrete
fill 247 230 262 247 231 262 minecraft:gray_concrete
fill 247 230 264 247 231 264 minecraft:gray_concrete
fill 247 230 266 247 231 266 minecraft:gray_concrete
fill 247 230 268 247 231 268 minecraft:gray_concrete
fill 248 230 261 248 231 261 minecraft:gray_concrete
fill 248 230 263 248 231 263 minecraft:gray_concrete
fill 248 230 265 248 231 265 minecraft:gray_concrete
fill 248 230 267 248 231 267 minecraft:gray_concrete
fill 248 230 269 248 231 269 minecraft:gray_concrete
fill 249 230 262 249 231 262 minecraft:gray_concrete
fill 249 230 264 249 231 264 minecraft:gray_concrete
setblock 249 230 265 minecraft:magenta_stained_glass
fill 249 230 266 249 231 266 minecraft:gray_concrete
setblock 249 230 267 minecraft:ochre_froglight
fill 249 230 268 249 231 268 minecraft:gray_concrete
fill 250 230 228 250 308 228 minecraft:black_concrete
fill 250 230 263 250 231 263 minecraft:gray_concrete
setblock 250 230 264 minecraft:sea_lantern
fill 250 230 265 250 231 265 minecraft:gray_concrete
fill 250 230 267 250 231 267 minecraft:gray_concrete
setblock 250 230 269 minecraft:ochre_froglight
fill 251 230 262 251 231 262 minecraft:gray_concrete
fill 251 230 264 251 231 264 minecraft:gray_concrete
fill 251 230 266 251 231 266 minecraft:gray_concrete
fill 251 230 268 251 231 268 minecraft:gray_concrete
fill 252 230 263 252 231 263 minecraft:gray_concrete
setblock 252 230 264 minecraft:black_stained_glass
fill 252 230 265 252 231 265 minecraft:gray_concrete
fill 252 230 267 252 231 267 minecraft:gray_concrete
setblock 252 230 269 minecraft:magenta_stained_glass
fill 253 230 262 253 231 262 minecraft:gray_concrete
fill 253 230 264 253 231 264 minecraft:gray_concrete
fill 253 230 266 253 231 266 minecraft:gray_concrete
fill 253 230 268 253 231 268 minecraft:gray_concrete
setblock 254 230 264 minecraft:cyan_stained_glass
setblock 254 230 269 minecraft:light_blue_stained_glass
setblock 256 230 264 minecraft:black_stained_glass
setblock 256 230 269 minecraft:pearlescent_froglight
setblock 258 230 264 minecraft:pearlescent_froglight
setblock 258 230 269 minecraft:pearlescent_froglight
setblock 260 230 264 minecraft:black_stained_glass
setblock 260 230 269 minecraft:black_stained_glass
setblock 262 230 265 minecraft:black_stained_glass
setblock 262 230 267 minecraft:cyan_stained_glass
fill 267 230 230 267 231 230 minecraft:gray_concrete
fill 267 230 232 267 231 232 minecraft:gray_concrete
fill 268 230 229 268 231 229 minecraft:gray_concrete
fill 268 230 231 268 231 231 minecraft:gray_concrete
fill 268 230 233 268 231 233 minecraft:gray_concrete
fill 268 230 241 268 231 241 minecraft:gray_concrete
fill 268 230 243 268 231 243 minecraft:gray_concrete
fill 268 230 245 268 231 245 minecraft:gray_concrete
fill 268 230 247 268 231 247 minecraft:gray_concrete
fill 268 230 249 268 231 249 minecraft:gray_concrete
fill 269 230 230 269 231 230 minecraft:gray_concrete
fill 269 230 232 269 231 232 minecraft:gray_concrete
fill 269 230 242 269 231 242 minecraft:gray_concrete
fill 269 230 244 269 231 244 minecraft:gray_concrete
fill 269 230 246 269 231 246 minecraft:gray_concrete
fill 269 230 248 269 231 248 minecraft:gray_concrete
fill 270 230 229 270 231 229 minecraft:gray_concrete
fill 270 230 231 270 231 231 minecraft:gray_concrete
fill 270 230 233 270 231 233 minecraft:gray_concrete
fill 270 230 241 270 231 241 minecraft:gray_concrete
fill 270 230 243 270 231 243 minecraft:gray_concrete
fill 270 230 245 270 231 245 minecraft:gray_concrete
fill 270 230 247 270 231 247 minecraft:gray_concrete
fill 270 230 249 270 231 249 minecraft:gray_concrete
fill 271 230 230 271 231 230 minecraft:gray_concrete
fill 271 230 232 271 231 232 minecraft:gray_concrete
fill 271 230 242 271 231 242 minecraft:gray_concrete
fill 271 230 244 271 231 244 minecraft:gray_concrete
fill 271 230 246 271 231 246 minecraft:gray_concrete
fill 271 230 248 271 231 248 minecraft:gray_concrete
fill 272 230 229 272 231 229 minecraft:gray_concrete
fill 272 230 231 272 231 231 minecraft:gray_concrete
fill 272 230 233 272 231 233 minecraft:gray_concrete
fill 272 230 241 272 231 241 minecraft:gray_concrete
fill 272 230 243 272 231 243 minecraft:gray_concrete
fill 272 230 245 272 231 245 minecraft:gray_concrete
fill 272 230 247 272 231 247 minecraft:gray_concrete
fill 272 230 249 272 231 249 minecraft:gray_concrete
fill 272 230 255 272 231 255 minecraft:gray_concrete
fill 272 230 257 272 231 257 minecraft:gray_concrete
fill 272 230 259 272 231 259 minecraft:gray_concrete
fill 272 230 261 272 231 261 minecraft:gray_concrete
fill 272 230 263 272 231 263 minecraft:gray_concrete
fill 272 230 265 272 231 265 minecraft:gray_concrete
fill 273 230 230 273 231 230 minecraft:gray_concrete
fill 273 230 232 273 231 232 minecraft:gray_concrete
fill 273 230 242 273 231 242 minecraft:gray_concrete
fill 273 230 244 273 231 244 minecraft:gray_concrete
fill 273 230 246 273 231 246 minecraft:gray_concrete
fill 273 230 248 273 231 248 minecraft:gray_concrete
fill 273 230 256 273 231 256 minecraft:gray_concrete
fill 273 230 258 273 231 258 minecraft:gray_concrete
fill 273 230 260 273 231 260 minecraft:gray_concrete
fill 273 230 262 273 231 262 minecraft:gray_concrete
fill 273 230 264 273 231 264 minecraft:gray_concrete
fill 274 230 241 274 231 241 minecraft:gray_concrete
fill 274 230 243 274 231 243 minecraft:gray_concrete
fill 274 230 245 274 231 245 minecraft:gray_concrete
fill 274 230 247 274 231 247 minecraft:gray_concrete
fill 274 230 249 274 231 249 minecraft:gray_concrete
fill 274 230 255 274 231 255 minecraft:gray_concrete
fill 274 230 257 274 231 257 minecraft:gray_concrete
fill 274 230 259 274 231 259 minecraft:gray_concrete
fill 274 230 261 274 231 261 minecraft:gray_concrete
fill 274 230 263 274 231 263 minecraft:gray_concrete
fill 274 230 265 274 231 265 minecraft:gray_concrete
fill 275 230 242 275 231 242 minecraft:gray_concrete
fill 275 230 244 275 231 244 minecraft:gray_concrete
fill 275 230 246 275 231 246 minecraft:gray_concrete
fill 275 230 248 275 231 248 minecraft:gray_concrete
fill 275 230 256 275 231 256 minecraft:gray_concrete
fill 275 230 258 275 231 258 minecraft:gray_concrete
fill 275 230 260 275 231 260 minecraft:gray_concrete
fill 275 230 262 275 231 262 minecraft:gray_concrete
fill 275 230 264 275 231 264 minecraft:gray_concrete
fill 276 230 241 276 231 241 minecraft:gray_concrete
fill 276 230 243 276 231 243 minecraft:gray_concrete
fill 276 230 245 276 231 245 minecraft:gray_concrete
fill 276 230 247 276 231 247 minecraft:gray_concrete
fill 276 230 249 276 231 249 minecraft:gray_concrete
fill 276 230 255 276 231 255 minecraft:gray_concrete
fill 276 230 257 276 231 257 minecraft:gray_concrete
fill 276 230 259 276 231 259 minecraft:gray_concrete
fill 276 230 261 276 231 261 minecraft:gray_concrete
fill 276 230 263 276 231 263 minecraft:gray_concrete
fill 276 230 265 276 231 265 minecraft:gray_concrete
fill 276 230 270 276 282 270 minecraft:black_concrete
fill 235 231 232 235 250 232 minecraft:black_concrete
fill 236 231 243 236 232 243 minecraft:black_concrete
fill 236 231 245 236 232 245 minecraft:black_concrete
fill 236 231 247 236 232 247 minecraft:black_concrete
fill 236 231 249 236 232 249 minecraft:black_concrete
fill 236 231 251 236 232 251 minecraft:black_concrete
fill 236 231 253 236 232 253 minecraft:black_concrete
fill 237 231 242 237 232 242 minecraft:black_concrete
fill 237 231 255 237 232 255 minecraft:black_concrete
fill 239 231 242 239 232 242 minecraft:black_concrete
fill 239 231 255 239 232 255 minecraft:black_concrete
fill 241 231 243 241 232 243 minecraft:black_concrete
fill 241 231 245 241 232 245 minecraft:black_concrete
fill 241 231 247 241 232 247 minecraft:black_concrete
fill 241 231 249 241 232 249 minecraft:black_concrete
fill 241 231 251 241 232 251 minecraft:black_concrete
fill 241 231 253 241 232 253 minecraft:black_concrete
setblock 249 231 247 minecraft:black_stained_glass
setblock 249 231 249 minecraft:black_stained_glass
setblock 249 231 251 minecraft:light_blue_stained_glass
setblock 249 231 253 minecraft:black_stained_glass
setblock 249 231 255 minecraft:light_blue_stained_glass
setblock 249 231 257 minecraft:black_stained_glass
setblock 249 231 259 minecraft:sea_lantern
fill 249 231 265 249 232 265 minecraft:gray_concrete
fill 249 231 267 249 232 267 minecraft:gray_concrete
setblock 250 231 246 minecraft:sea_lantern
setblock 250 231 261 minecraft:sea_lantern
fill 250 231 262 250 240 262 minecraft:gray_concrete
fill 250 231 264 250 232 264 minecraft:gray_concrete
setblock 250 231 269 minecraft:gray_concrete
setblock 252 231 246 minecraft:black_stained_glass
setblock 252 231 261 minecraft:black_stained_glass
fill 252 231 262 252 240 262 minecraft:gray_concrete
fill 252 231 264 252 232 264 minecraft:gray_concrete
setblock 252 231 269 minecraft:gray_concrete
setblock 254 231 246 minecraft:black_stained_glass
setblock 254 231 261 minecraft:black_stained_glass
fill 254 231 264 254 232 264 minecraft:gray_concrete
fill 254 231 269 254 232 269 minecraft:gray_concrete
setblock 256 231 246 minecraft:light_blue_stained_glass
setblock 256 231 261 minecraft:light_blue_stained_glass
fill 256 231 264 256 232 264 minecraft:gray_concrete
fill 256 231 269 256 232 269 minecraft:gray_concrete
setblock 258 231 246 minecraft:black_stained_glass
setblock 258 231 261 minecraft:light_blue_stained_glass
fill 258 231 264 258 232 264 minecraft:gray_concrete
fill 258 231 269 258 232 269 minecraft:gray_concrete
setblock 260 231 246 minecraft:sea_lantern
setblock 260 231 261 minecraft:sea_lantern
fill 260 231 264 260 232 264 minecraft:gray_concrete
fill 260 231 269 260 232 269 minecraft:gray_concrete
setblock 262 231 246 minecraft:light_blue_stained_glass
setblock 262 231 261 minecraft:black_stained_glass
fill 262 231 265 262 232 265 minecraft:gray_concrete
fill 262 231 267 262 232 267 minecraft:gray_concrete
setblock 264 231 247 minecraft:sea_lantern
setblock 264 231 249 minecraft:black_stained_glass
setblock 264 231 251 minecraft:sea_lantern
setblock 264 231 253 minecraft:black_stained_glass
setblock 264 231 255 minecraft:black_stained_glass
setblock 264 231 257 minecraft:sea_lantern
setblock 264 231 259 minecraft:black_stained_glass
setblock 235 232 262 minecraft:sea_lantern
setblock 235 232 264 minecraft:sea_lantern
setblock 235 232 266 minecraft:sea_lantern
setblock 235 232 268 minecraft:sea_lantern
setblock 236 232 263 minecraft:sea_lantern
setblock 236 232 265 minecraft:sea_lantern
setblock 236 232 267 minecraft:sea_lantern
setblock 236 232 269 minecraft:sea_lantern
setblock 237 232 262 minecraft:sea_lantern
setblock 237 232 264 minecraft:sea_lantern
setblock 237 232 266 minecraft:sea_lantern
setblock 237 232 268 minecraft:sea_lantern
setblock 238 232 263 minecraft:sea_lantern
setblock 238 232 265 minecraft:sea_lantern
setblock 238 232 267 minecraft:sea_lantern
setblock 238 232 269 minecraft:sea_lantern
setblock 239 232 262 minecraft:sea_lantern
setblock 239 232 264 minecraft:sea_lantern
setblock 239 232 266 minecraft:sea_lantern
setblock 239 232 268 minecraft:sea_lantern
setblock 240 232 261 minecraft:sea_lantern
setblock 240 232 263 minecraft:sea_lantern
setblock 240 232 265 minecraft:sea_lantern
setblock 240 232 267 minecraft:sea_lantern
setblock 240 232 269 minecraft:sea_lantern
setblock 241 232 262 minecraft:sea_lantern
setblock 241 232 264 minecraft:sea_lantern
setblock 241 232 266 minecraft:sea_lantern
setblock 241 232 268 minecraft:sea_lantern
setblock 242 232 261 minecraft:sea_lantern
setblock 242 232 263 minecraft:sea_lantern
setblock 242 232 265 minecraft:sea_lantern
setblock 242 232 267 minecraft:sea_lantern
setblock 242 232 269 minecraft:sea_lantern
setblock 243 232 262 minecraft:sea_lantern
setblock 243 232 264 minecraft:sea_lantern
setblock 243 232 266 minecraft:sea_lantern
setblock 243 232 268 minecraft:sea_lantern
setblock 244 232 261 minecraft:sea_lantern
setblock 244 232 263 minecraft:sea_lantern
setblock 244 232 265 minecraft:sea_lantern
setblock 244 232 267 minecraft:sea_lantern
setblock 244 232 269 minecraft:sea_lantern
setblock 245 232 262 minecraft:sea_lantern
setblock 245 232 264 minecraft:sea_lantern
setblock 245 232 266 minecraft:sea_lantern
setblock 245 232 268 minecraft:sea_lantern
setblock 246 232 261 minecraft:sea_lantern
setblock 246 232 263 minecraft:sea_lantern
setblock 246 232 265 minecraft:sea_lantern
setblock 246 232 267 minecraft:sea_lantern
setblock 246 232 269 minecraft:sea_lantern
setblock 247 232 262 minecraft:sea_lantern
setblock 247 232 264 minecraft:sea_lantern
setblock 247 232 266 minecraft:sea_lantern
setblock 247 232 268 minecraft:sea_lantern
setblock 248 232 261 minecraft:sea_lantern
setblock 248 232 263 minecraft:sea_lantern
setblock 248 232 265 minecraft:sea_lantern
setblock 248 232 267 minecraft:sea_lantern
setblock 248 232 269 minecraft:sea_lantern
fill 249 232 247 249 233 247 minecraft:gray_concrete
fill 249 232 249 249 233 249 minecraft:gray_concrete
fill 249 232 251 249 233 251 minecraft:gray_concrete
fill 249 232 253 249 233 253 minecraft:gray_concrete
fill 249 232 255 249 233 255 minecraft:gray_concrete
fill 249 232 257 249 233 257 minecraft:gray_concrete
fill 249 232 259 249 233 259 minecraft:gray_concrete
setblock 249 232 262 minecraft:sea_lantern
setblock 249 232 264 minecraft:sea_lantern
setblock 249 232 266 minecraft:sea_lantern
setblock 249 232 268 minecraft:sea_lantern
fill 250 232 246 250 233 246 minecraft:gray_concrete
fill 250 232 261 250 233 261 minecraft:gray_concrete
setblock 250 232 263 minecraft:sea_lantern
setblock 250 232 265 minecraft:sea_lantern
setblock 250 232 267 minecraft:sea_lantern
setblock 250 232 269 minecraft:sea_lantern
setblock 251 232 262 minecraft:sea_lantern
setblock 251 232 264 minecraft:sea_lantern
setblock 251 232 266 minecraft:sea_lantern
setblock 251 232 268 minecraft:sea_lantern
fill 252 232 246 252 233 246 minecraft:gray_concrete
fill 252 232 261 252 233 261 minecraft:gray_concrete
setblock 252 232 263 minecraft:sea_lantern
setblock 252 232 265 minecraft:sea_lantern
setblock 252 232 267 minecraft:sea_lantern
setblock 252 232 269 minecraft:sea_lantern
setblock 253 232 262 minecraft:sea_lantern
setblock 253 232 264 minecraft:sea_lantern
setblock 253 232 266 minecraft:sea_lantern
setblock 253 232 268 minecraft:sea_lantern
fill 254 232 246 254 233 246 minecraft:gray_concrete
fill 254 232 261 254 233 261 minecraft:gray_concrete
fill 256 232 246 256 233 246 minecraft:gray_concrete
fill 256 232 261 256 233 261 minecraft:gray_concrete
fill 258 232 246 258 233 246 minecraft:gray_concrete
fill 258 232 261 258 233 261 minecraft:gray_concrete
fill 260 232 246 260 233 246 minecraft:gray_concrete
fill 260 232 261 260 233 261 minecraft:gray_concrete
setblock 261 232 270 minecraft:blue_concrete
fill 262 232 246 262 233 246 minecraft:gray_concrete
fill 262 232 261 262 233 261 minecraft:gray_concrete
fill 264 232 247 264 233 247 minecraft:gray_concrete
fill 264 232 249 264 233 249 minecraft:gray_concrete
fill 264 232 251 264 233 251 minecraft:gray_concrete
fill 264 232 253 264 233 253 minecraft:gray_concrete
fill 264 232 255 264 233 255 minecraft:gray_concrete
fill 264 232 257 264 233 257 minecraft:gray_concrete
fill 264 232 259 264 233 259 minecraft:gray_concrete
setblock 267 232 230 minecraft:sea_lantern
setblock 267 232 232 minecraft:sea_lantern
setblock 268 232 229 minecraft:sea_lantern
setblock 268 232 231 minecraft:sea_lantern
setblock 268 232 233 minecraft:sea_lantern
setblock 268 232 241 minecraft:sea_lantern
setblock 268 232 243 minecraft:sea_lantern
setblock 268 232 245 minecraft:sea_lantern
setblock 268 232 247 minecraft:sea_lantern
setblock 268 232 249 minecraft:sea_lantern
setblock 269 232 230 minecraft:sea_lantern
setblock 269 232 232 minecraft:sea_lantern
setblock 269 232 242 minecraft:sea_lantern
setblock 269 232 244 minecraft:sea_lantern
setblock 269 232 246 minecraft:sea_lantern
setblock 269 232 248 minecraft:sea_lantern
setblock 270 232 229 minecraft:sea_lantern
setblock 270 232 231 minecraft:sea_lantern
setblock 270 232 233 minecraft:sea_lantern
setblock 270 232 241 minecraft:sea_lantern
setblock 270 232 243 minecraft:sea_lantern
setblock 270 232 245 minecraft:sea_lantern
setblock 270 232 247 minecraft:sea_lantern
setblock 270 232 249 minecraft:sea_lantern
setblock 271 232 230 minecraft:sea_lantern
setblock 271 232 232 minecraft:sea_lantern
setblock 271 232 242 minecraft:sea_lantern
setblock 271 232 244 minecraft:sea_lantern
setblock 271 232 246 minecraft:sea_lantern
setblock 271 232 248 minecraft:sea_lantern
setblock 272 232 229 minecraft:sea_lantern
setblock 272 232 231 minecraft:sea_lantern
setblock 272 232 233 minecraft:sea_lantern
setblock 272 232 241 minecraft:sea_lantern
setblock 272 232 243 minecraft:sea_lantern
setblock 272 232 245 minecraft:sea_lantern
setblock 272 232 247 minecraft:sea_lantern
setblock 272 232 249 minecraft:sea_lantern
setblock 272 232 255 minecraft:sea_lantern
setblock 272 232 257 minecraft:sea_lantern
setblock 272 232 259 minecraft:sea_lantern
setblock 272 232 261 minecraft:sea_lantern
setblock 272 232 263 minecraft:sea_lantern
setblock 272 232 265 minecraft:sea_lantern
setblock 273 232 230 minecraft:sea_lantern
setblock 273 232 232 minecraft:sea_lantern
setblock 273 232 242 minecraft:sea_lantern
setblock 273 232 244 minecraft:sea_lantern
setblock 273 232 246 minecraft:sea_lantern
setblock 273 232 248 minecraft:sea_lantern
setblock 273 232 256 minecraft:sea_lantern
setblock 273 232 258 minecraft:sea_lantern
setblock 273 232 260 minecraft:sea_lantern
setblock 273 232 262 minecraft:sea_lantern
setblock 273 232 264 minecraft:sea_lantern
setblock 274 232 241 minecraft:sea_lantern
setblock 274 232 243 minecraft:sea_lantern
setblock 274 232 245 minecraft:sea_lantern
setblock 274 232 247 minecraft:sea_lantern
setblock 274 232 249 minecraft:sea_lantern
setblock 274 232 255 minecraft:sea_lantern
setblock 274 232 257 minecraft:sea_lantern
setblock 274 232 259 minecraft:sea_lantern
setblock 274 232 261 minecraft:sea_lantern
setblock 274 232 263 minecraft:sea_lantern
setblock 274 232 265 minecraft:sea_lantern
setblock 275 232 242 minecraft:sea_lantern
setblock 275 232 244 minecraft:sea_lantern
setblock 275 232 246 minecraft:sea_lantern
setblock 275 232 248 minecraft:sea_lantern
setblock 275 232 256 minecraft:sea_lantern
setblock 275 232 258 minecraft:sea_lantern
setblock 275 232 260 minecraft:sea_lantern
setblock 275 232 262 minecraft:sea_lantern
setblock 275 232 264 minecraft:sea_lantern
setblock 276 232 241 minecraft:sea_lantern
setblock 276 232 243 minecraft:sea_lantern
setblock 276 232 245 minecraft:sea_lantern
setblock 276 232 247 minecraft:sea_lantern
setblock 276 232 249 minecraft:sea_lantern
setblock 276 232 255 minecraft:sea_lantern
setblock 276 232 257 minecraft:sea_lantern
setblock 276 232 259 minecraft:sea_lantern
setblock 276 232 261 minecraft:sea_lantern
setblock 276 232 263 minecraft:sea_lantern
setblock 276 232 265 minecraft:sea_lantern
setblock 277 232 241 minecraft:cyan_concrete
setblock 277 232 267 minecraft:ochre_froglight
fill 235 233 262 235 234 262 minecraft:black_concrete
fill 235 233 264 235 234 264 minecraft:black_concrete
fill 235 233 266 235 234 266 minecraft:black_concrete
fill 235 233 268 235 234 268 minecraft:black_concrete
setblock 236 233 243 minecraft:cyan_stained_glass
setblock 236 233 245 minecraft:sea_lantern
setblock 236 233 247 minecraft:black_stained_glass
setblock 236 233 249 minecraft:sea_lantern
setblock 236 233 251 minecraft:cyan_stained_glass
setblock 236 233 253 minecraft:black_stained_glass
fill 236 233 263 236 234 263 minecraft:gray_concrete
fill 236 233 265 236 234 265 minecraft:gray_concrete
fill 236 233 267 236 234 267 minecraft:gray_concrete
fill 236 233 269 236 234 269 minecraft:gray_concrete
setblock 237 233 242 minecraft:black_stained_glass
setblock 237 233 255 minecraft:pearlescent_froglight
fill 237 233 262 237 234 262 minecraft:gray_concrete
fill 237 233 264 237 234 264 minecraft:gray_concrete
fill 237 233 266 237 234 266 minecraft:gray_concrete
fill 237 233 268 237 234 268 minecraft:gray_concrete
fill 238 233 263 238 234 263 minecraft:gray_concrete
fill 238 233 265 238 234 265 minecraft:gray_concrete
fill 238 233 267 238 234 267 minecraft:gray_concrete
fill 238 233 269 238 234 269 minecraft:gray_concrete
setblock 239 233 242 minecraft:ochre_froglight
setblock 239 233 255 minecraft:cyan_stained_glass
fill 239 233 262 239 234 262 minecraft:gray_concrete
fill 239 233 264 239 234 264 minecraft:gray_concrete
fill 239 233 266 239 234 266 minecraft:gray_concrete
fill 239 233 268 239 234 268 minecraft:gray_concrete
fill 240 233 261 240 234 261 minecraft:gray_concrete
fill 240 233 263 240 234 263 minecraft:gray_concrete
fill 240 233 265 240 234 265 minecraft:gray_concrete
fill 240 233 267 240 234 267 minecraft:gray_concrete
fill 240 233 269 240 234 269 minecraft:gray_concrete
setblock 241 233 243 minecraft:light_blue_stained_glass
setblock 241 233 245 minecraft:cyan_stained_glass
setblock 241 233 247 minecraft:black_stained_glass
setblock 241 233 249 minecraft:black_stained_glass
setblock 241 233 251 minecraft:magenta_stained_glass
setblock 241 233 253 minecraft:magenta_stained_glass
fill 241 233 262 241 234 262 minecraft:gray_concrete
fill 241 233 264 241 234 264 minecraft:gray_concrete
fill 241 233 266 241 234 266 minecraft:gray_concrete
fill 241 233 268 241 234 268 minecraft:gray_concrete
fill 242 233 261 242 234 261 minecraft:gray_concrete
fill 242 233 263 242 234 263 minecraft:gray_concrete
fill 242 233 265 242 234 265 minecraft:gray_concrete
fill 242 233 267 242 234 267 minecraft:gray_concrete
fill 242 233 269 242 234 269 minecraft:gray_concrete
fill 243 233 262 243 234 262 minecraft:gray_concrete
fill 243 233 264 243 234 264 minecraft:gray_concrete
fill 243 233 266 243 234 266 minecraft:gray_concrete
fill 243 233 268 243 234 268 minecraft:gray_concrete
fill 244 233 261 244 234 261 minecraft:gray_concrete
fill 244 233 263 244 234 263 minecraft:gray_concrete
fill 244 233 265 244 234 265 minecraft:gray_concrete
fill 244 233 267 244 234 267 minecraft:gray_concrete
fill 244 233 269 244 234 269 minecraft:gray_concrete
fill 245 233 262 245 234 262 minecraft:gray_concrete
fill 245 233 264 245 234 264 minecraft:gray_concrete
fill 245 233 266 245 234 266 minecraft:gray_concrete
fill 245 233 268 245 234 268 minecraft:gray_concrete
fill 246 233 261 246 234 261 minecraft:gray_concrete
fill 246 233 263 246 234 263 minecraft:gray_concrete
fill 246 233 265 246 234 265 minecraft:gray_concrete
fill 246 233 267 246 234 267 minecraft:gray_concrete
fill 246 233 269 246 234 269 minecraft:gray_concrete
fill 247 233 262 247 234 262 minecraft:gray_concrete
fill 247 233 264 247 234 264 minecraft:gray_concrete
fill 247 233 266 247 234 266 minecraft:gray_concrete
fill 247 233 268 247 234 268 minecraft:gray_concrete
fill 248 233 261 248 234 261 minecraft:gray_concrete
fill 248 233 263 248 234 263 minecraft:gray_concrete
fill 248 233 265 248 234 265 minecraft:gray_concrete
fill 248 233 267 248 234 267 minecraft:gray_concrete
fill 248 233 269 248 234 269 minecraft:gray_concrete
fill 249 233 262 249 234 262 minecraft:gray_concrete
fill 249 233 264 249 234 264 minecraft:gray_concrete
setblock 249 233 265 minecraft:cyan_stained_glass
fill 249 233 266 249 234 266 minecraft:gray_concrete
setblock 249 233 267 minecraft:sea_lantern
fill 249 233 268 249 234 268 minecraft:gray_concrete
fill 250 233 263 250 234 263 minecraft:gray_concrete
setblock 250 233 264 minecraft:ochre_froglight
fill 250 233 265 250 234 265 minecraft:gray_concrete
fill 250 233 267 250 234 267 minecraft:gray_concrete
setblock 250 233 269 minecraft:magenta_stained_glass
fill 251 233 262 251 234 262 minecraft:gray_concrete
fill 251 233 264 251 234 264 minecraft:gray_concrete
fill 251 233 266 251 234 266 minecraft:gray_concrete
fill 251 233 268 251 234 268 minecraft:gray_concrete
fill 252 233 263 252 234 263 minecraft:gray_concrete
setblock 252 233 264 minecraft:cyan_stained_glass
fill 252 233 265 252 234 265 minecraft:gray_concrete
fill 252 233 267 252 234 267 minecraft:gray_concrete
setblock 252 233 269 minecraft:black_stained_glass
fill 253 233 262 253 234 262 minecraft:gray_concrete
fill 253 233 264 253 234 264 minecraft:gray_concrete
fill 253 233 266 253 234 266 minecraft:gray_concrete
fill 253 233 268 253 234 268 minecraft:gray_concrete
setblock 254 233 264 minecraft:pearlescent_froglight
setblock 254 233 269 minecraft:pearlescent_froglight
setblock 256 233 264 minecraft:pearlescent_froglight
setblock 256 233 269 minecraft:black_stained_glass
setblock 258 233 228 minecraft:cyan_concrete
setblock 258 233 264 minecraft:light_blue_stained_glass
setblock 258 233 269 minecraft:black_stained_glass
setblock 260 233 264 minecraft:pearlescent_froglight
setblock 260 233 269 minecraft:pearlescent_froglight
fill 261 233 270 261 282 270 minecraft:black_concrete
setblock 262 233 265 minecraft:light_blue_stained_glass
setblock 262 233 267 minecraft:black_stained_glass
fill 267 233 230 267 234 230 minecraft:gray_concrete
fill 267 233 232 267 234 232 minecraft:gray_concrete
fill 268 233 229 268 234 229 minecraft:gray_concrete
fill 268 233 231 268 234 231 minecraft:gray_concrete
fill 268 233 233 268 234 233 minecraft:gray_concrete
fill 268 233 241 268 234 241 minecraft:gray_concrete
fill 268 233 243 268 234 243 minecraft:gray_concrete
fill 268 233 245 268 234 245 minecraft:gray_concrete
fill 268 233 247 268 234 247 minecraft:gray_concrete
fill 268 233 249 268 234 249 minecraft:gray_concrete
setblock 269 233 228 minecraft:ochre_froglight
fill 269 233 230 269 234 230 minecraft:gray_concrete
fill 269 233 232 269 234 232 minecraft:gray_concrete
fill 269 233 242 269 234 242 minecraft:gray_concrete
fill 269 233 244 269 234 244 minecraft:gray_concrete
fill 269 233 246 269 234 246 minecraft:gray_concrete
fill 269 233 248 269 234 248 minecraft:gray_concrete
fill 270 233 229 270 234 229 minecraft:gray_concrete
fill 270 233 231 270 234 231 minecraft:gray_concrete
fill 270 233 233 270 234 233 minecraft:gray_concrete
fill 270 233 241 270 234 241 minecraft:gray_concrete
fill 270 233 243 270 234 243 minecraft:gray_concrete
fill 270 233 245 270 234 245 minecraft:gray_concrete
fill 270 233 247 270 234 247 minecraft:gray_concrete
fill 270 233 249 270 234 249 minecraft:gray_concrete
fill 271 233 230 271 234 230 minecraft:gray_concrete
fill 271 233 232 271 234 232 minecraft:gray_concrete
fill 271 233 242 271 234 242 minecraft:gray_concrete
fill 271 233 244 271 234 244 minecraft:gray_concrete
fill 271 233 246 271 234 246 minecraft:gray_concrete
fill 271 233 248 271 234 248 minecraft:gray_concrete
fill 272 233 229 272 234 229 minecraft:gray_concrete
fill 272 233 231 272 234 231 minecraft:gray_concrete
fill 272 233 233 272 234 233 minecraft:gray_concrete
fill 272 233 241 272 234 241 minecraft:gray_concrete
fill 272 233 243 272 234 243 minecraft:gray_concrete
fill 272 233 245 272 234 245 minecraft:gray_concrete
fill 272 233 247 272 234 247 minecraft:gray_concrete
fill 272 233 249 272 234 249 minecraft:gray_concrete
fill 272 233 255 272 234 255 minecraft:gray_concrete
fill 272 233 257 272 234 257 minecraft:gray_concrete
fill 272 233 259 272 234 259 minecraft:gray_concrete
fill 272 233 261 272 234 261 minecraft:gray_concrete
fill 272 233 263 272 234 263 minecraft:gray_concrete
fill 272 233 265 272 234 265 minecraft:gray_concrete
setblock 273 233 228 minecraft:pearlescent_froglight
fill 273 233 230 273 234 230 minecraft:gray_concrete
fill 273 233 232 273 234 232 minecraft:gray_concrete
fill 273 233 242 273 234 242 minecraft:gray_concrete
fill 273 233 244 273 234 244 minecraft:gray_concrete
fill 273 233 246 273 234 246 minecraft:gray_concrete
fill 273 233 248 273 234 248 minecraft:gray_concrete
fill 273 233 256 273 234 256 minecraft:gray_concrete
fill 273 233 258 273 234 258 minecraft:gray_concrete
fill 273 233 260 273 234 260 minecraft:gray_concrete
fill 273 233 262 273 234 262 minecraft:gray_concrete
fill 273 233 264 273 234 264 minecraft:gray_concrete
fill 274 233 241 274 234 241 minecraft:gray_concrete
fill 274 233 243 274 234 243 minecraft:gray_concrete
fill 274 233 245 274 234 245 minecraft:gray_concrete
fill 274 233 247 274 234 247 minecraft:gray_concrete
fill 274 233 249 274 234 249 minecraft:gray_concrete
fill 274 233 255 274 234 255 minecraft:gray_concrete
fill 274 233 257 274 234 257 minecraft:gray_concrete
fill 274 233 259 274 234 259 minecraft:gray_concrete
fill 274 233 261 274 234 261 minecraft:gray_concrete
fill 274 233 263 274 234 263 minecraft:gray_concrete
fill 274 233 265 274 234 265 minecraft:gray_concrete
fill 275 233 242 275 234 242 minecraft:gray_concrete
fill 275 233 244 275 234 244 minecraft:gray_concrete
fill 275 233 246 275 234 246 minecraft:gray_concrete
fill 275 233 248 275 234 248 minecraft:gray_concrete
fill 275 233 256 275 234 256 minecraft:gray_concrete
fill 275 233 258 275 234 258 minecraft:gray_concrete
fill 275 233 260 275 234 260 minecraft:gray_concrete
fill 275 233 262 275 234 262 minecraft:gray_concrete
fill 275 233 264 275 234 264 minecraft:gray_concrete
fill 276 233 241 276 234 241 minecraft:gray_concrete
fill 276 233 243 276 234 243 minecraft:gray_concrete
fill 276 233 245 276 234 245 minecraft:gray_concrete
fill 276 233 247 276 234 247 minecraft:gray_concrete
fill 276 233 249 276 234 249 minecraft:gray_concrete
fill 276 233 255 276 234 255 minecraft:gray_concrete
fill 276 233 257 276 234 257 minecraft:gray_concrete
fill 276 233 259 276 234 259 minecraft:gray_concrete
fill 276 233 261 276 234 261 minecraft:gray_concrete
fill 276 233 263 276 234 263 minecraft:gray_concrete
fill 276 233 265 276 234 265 minecraft:gray_concrete
fill 277 233 241 277 269 241 minecraft:black_concrete
fill 277 233 267 277 293 267 minecraft:black_concrete
fill 236 234 243 236 235 243 minecraft:black_concrete
fill 236 234 245 236 235 245 minecraft:black_concrete
fill 236 234 247 236 235 247 minecraft:black_concrete
fill 236 234 249 236 235 249 minecraft:black_concrete
fill 236 234 251 236 235 251 minecraft:black_concrete
fill 236 234 253 236 235 253 minecraft:black_concrete
fill 237 234 242 237 235 242 minecraft:black_concrete
fill 237 234 255 237 235 255 minecraft:black_concrete
setblock 238 234 231 minecraft:light[level=15]
setblock 238 234 239 minecraft:light[level=15]
fill 239 234 242 239 235 242 minecraft:black_concrete
fill 239 234 255 239 235 255 minecraft:black_concrete
fill 241 234 243 241 235 243 minecraft:black_concrete
fill 241 234 245 241 235 245 minecraft:black_concrete
fill 241 234 247 241 235 247 minecraft:black_concrete
fill 241 234 249 241 235 249 minecraft:black_concrete
fill 241 234 251 241 235 251 minecraft:black_concrete
fill 241 234 253 241 235 253 minecraft:black_concrete
setblock 246 234 231 minecraft:light[level=15]
setblock 246 234 239 minecraft:light[level=15]
setblock 246 234 247 minecraft:light[level=15]
setblock 246 234 255 minecraft:light[level=15]
setblock 249 234 247 minecraft:black_stained_glass
setblock 249 234 249 minecraft:sea_lantern
setblock 249 234 251 minecraft:black_stained_glass
setblock 249 234 253 minecraft:sea_lantern
setblock 249 234 255 minecraft:sea_lantern
setblock 249 234 257 minecraft:light_blue_stained_glass
setblock 249 234 259 minecraft:light_blue_stained_glass
fill 249 234 265 249 235 265 minecraft:gray_concrete
fill 249 234 267 249 238 267 minecraft:gray_concrete
setblock 250 234 246 minecraft:black_stained_glass
setblock 250 234 261 minecraft:light_blue_stained_glass
fill 250 234 264 250 235 264 minecraft:gray_concrete
setblock 250 234 269 minecraft:gray_concrete
setblock 252 234 246 minecraft:sea_lantern
setblock 252 234 261 minecraft:black_stained_glass
fill 252 234 264 252 235 264 minecraft:gray_concrete
setblock 252 234 269 minecraft:gray_concrete
setblock 254 234 231 minecraft:light[level=15]
setblock 254 234 239 minecraft:light[level=15]
setblock 254 234 246 minecraft:sea_lantern
setblock 254 234 261 minecraft:light_blue_stained_glass
setblock 254 234 263 minecraft:light[level=15]
fill 254 234 264 254 235 264 minecraft:gray_concrete
fill 254 234 269 254 235 269 minecraft:gray_concrete
setblock 256 234 246 minecraft:black_stained_glass
setblock 256 234 261 minecraft:light_blue_stained_glass
fill 256 234 264 256 235 264 minecraft:gray_concrete
fill 256 234 269 256 235 269 minecraft:gray_concrete
fill 258 234 228 258 238 228 minecraft:black_concrete
setblock 258 234 246 minecraft:black_stained_glass
setblock 258 234 261 minecraft:black_stained_glass
fill 258 234 264 258 235 264 minecraft:gray_concrete
fill 258 234 269 258 235 269 minecraft:gray_concrete
setblock 260 234 246 minecraft:light_blue_stained_glass
setblock 260 234 261 minecraft:sea_lantern
fill 260 234 264 260 235 264 minecraft:gray_concrete
fill 260 234 269 260 235 269 minecraft:gray_concrete
setblock 262 234 231 minecraft:light[level=15]
setblock 262 234 239 minecraft:light[level=15]
setblock 262 234 246 minecraft:sea_lantern
setblock 262 234 261 minecraft:sea_lantern
setblock 262 234 263 minecraft:light[level=15]
fill 262 234 265 262 235 265 minecraft:gray_concrete
fill 262 234 267 262 235 267 minecraft:gray_concrete
setblock 264 234 247 minecraft:black_stained_glass
setblock 264 234 249 minecraft:sea_lantern
setblock 264 234 251 minecraft:sea_lantern
setblock 264 234 253 minecraft:black_stained_glass
setblock 264 234 255 minecraft:light_blue_stained_glass
setblock 264 234 257 minecraft:black_stained_glass
setblock 264 234 259 minecraft:black_stained_glass
setblock 264 234 270 minecraft:sea_lantern
fill 269 234 228 269 308 228 minecraft:black_concrete
setblock 270 234 239 minecraft:light[level=15]
setblock 270 234 255 minecraft:light[level=15]
setblock 270 234 263 minecraft:light[level=15]
fill 273 234 228 273 238 228 minecraft:black_concrete
setblock 235 235 233 minecraft:verdant_froglight
setblock 235 235 262 minecraft:sea_lantern
setblock 235 235 264 minecraft:sea_lantern
setblock 235 235 266 minecraft:sea_lantern
setblock 235 235 268 minecraft:sea_lantern
setblock 236 235 263 minecraft:sea_lantern
setblock 236 235 265 minecraft:sea_lantern
setblock 236 235 267 minecraft:sea_lantern
setblock 236 235 269 minecraft:sea_lantern
setblock 237 235 262 minecraft:sea_lantern
setblock 237 235 264 minecraft:sea_lantern
setblock 237 235 266 minecraft:sea_lantern
setblock 237 235 268 minecraft:sea_lantern
setblock 238 235 231 minecraft:light[level=12]
setblock 238 235 238 minecraft:light[level=12]
setblock 238 235 259 minecraft:light[level=12]
setblock 238 235 263 minecraft:sea_lantern
setblock 238 235 265 minecraft:sea_lantern
setblock 238 235 267 minecraft:sea_lantern
setblock 238 235 269 minecraft:sea_lantern
setblock 239 235 262 minecraft:sea_lantern
setblock 239 235 264 minecraft:sea_lantern
setblock 239 235 266 minecraft:sea_lantern
setblock 239 235 268 minecraft:sea_lantern
setblock 240 235 261 minecraft:sea_lantern
setblock 240 235 263 minecraft:sea_lantern
setblock 240 235 265 minecraft:sea_lantern
setblock 240 235 267 minecraft:sea_lantern
setblock 240 235 269 minecraft:sea_lantern
setblock 241 235 262 minecraft:sea_lantern
setblock 241 235 264 minecraft:sea_lantern
setblock 241 235 266 minecraft:sea_lantern
setblock 241 235 268 minecraft:sea_lantern
setblock 242 235 261 minecraft:sea_lantern
setblock 242 235 263 minecraft:sea_lantern
setblock 242 235 265 minecraft:sea_lantern
setblock 242 235 267 minecraft:sea_lantern
setblock 242 235 269 minecraft:sea_lantern
setblock 243 235 262 minecraft:sea_lantern
setblock 243 235 264 minecraft:sea_lantern
setblock 243 235 266 minecraft:sea_lantern
setblock 243 235 268 minecraft:sea_lantern
setblock 244 235 261 minecraft:sea_lantern
setblock 244 235 263 minecraft:sea_lantern
setblock 244 235 265 minecraft:sea_lantern
setblock 244 235 267 minecraft:sea_lantern
setblock 244 235 269 minecraft:sea_lantern
setblock 245 235 231 minecraft:light[level=12]
setblock 245 235 238 minecraft:light[level=12]
setblock 245 235 245 minecraft:light[level=12]
setblock 245 235 252 minecraft:light[level=12]
setblock 245 235 259 minecraft:light[level=12]
setblock 245 235 262 minecraft:sea_lantern
setblock 245 235 264 minecraft:sea_lantern
setblock 245 235 266 minecraft:sea_lantern
setblock 245 235 268 minecraft:sea_lantern
setblock 246 235 261 minecraft:sea_lantern
setblock 246 235 263 minecraft:sea_lantern
setblock 246 235 265 minecraft:sea_lantern
setblock 246 235 267 minecraft:sea_lantern
setblock 246 235 269 minecraft:sea_lantern
setblock 247 235 262 minecraft:sea_lantern
setblock 247 235 264 minecraft:sea_lantern
setblock 247 235 266 minecraft:sea_lantern
setblock 247 235 268 minecraft:sea_lantern
setblock 248 235 261 minecraft:sea_lantern
setblock 248 235 263 minecraft:sea_lantern
setblock 248 235 265 minecraft:sea_lantern
setblock 248 235 267 minecraft:sea_lantern
setblock 248 235 269 minecraft:sea_lantern
fill 249 235 247 249 238 247 minecraft:gray_concrete
fill 249 235 249 249 238 249 minecraft:gray_concrete
fill 249 235 251 249 238 251 minecraft:gray_concrete
fill 249 235 253 249 238 253 minecraft:gray_concrete
fill 249 235 255 249 238 255 minecraft:gray_concrete
fill 249 235 257 249 238 257 minecraft:gray_concrete
fill 249 235 259 249 238 259 minecraft:gray_concrete
setblock 249 235 262 minecraft:sea_lantern
setblock 249 235 264 minecraft:sea_lantern
setblock 249 235 266 minecraft:sea_lantern
setblock 249 235 268 minecraft:sea_lantern
fill 250 235 246 250 237 246 minecraft:gray_concrete
fill 250 235 261 250 240 261 minecraft:gray_concrete
setblock 250 235 263 minecraft:sea_lantern
setblock 250 235 265 minecraft:sea_lantern
setblock 250 235 267 minecraft:sea_lantern
setblock 250 235 269 minecraft:sea_lantern
setblock 251 235 262 minecraft:sea_lantern
setblock 251 235 264 minecraft:sea_lantern
setblock 251 235 266 minecraft:sea_lantern
setblock 251 235 268 minecraft:sea_lantern
setblock 252 235 231 minecraft:light[level=12]
setblock 252 235 238 minecraft:light[level=12]
setblock 252 235 245 minecraft:light[level=12]
fill 252 235 246 252 237 246 minecraft:gray_concrete
fill 252 235 261 252 240 261 minecraft:gray_concrete
setblock 252 235 263 minecraft:sea_lantern
setblock 252 235 265 minecraft:sea_lantern
setblock 252 235 267 minecraft:sea_lantern
setblock 252 235 269 minecraft:sea_lantern
setblock 253 235 262 minecraft:sea_lantern
setblock 253 235 264 minecraft:sea_lantern
setblock 253 235 266 minecraft:sea_lantern
setblock 253 235 268 minecraft:sea_lantern
fill 254 235 246 254 237 246 minecraft:gray_concrete
fill 254 235 261 254 238 261 minecraft:gray_concrete
fill 256 235 246 256 237 246 minecraft:gray_concrete
fill 256 235 261 256 238 261 minecraft:gray_concrete
fill 258 235 246 258 237 246 minecraft:gray_concrete
fill 258 235 261 258 238 261 minecraft:gray_concrete
setblock 259 235 231 minecraft:light[level=12]
setblock 259 235 238 minecraft:light[level=12]
setblock 259 235 245 minecraft:light[level=12]
fill 260 235 246 260 237 246 minecraft:gray_concrete
fill 260 235 261 260 238 261 minecraft:gray_concrete
fill 262 235 246 262 237 246 minecraft:gray_concrete
fill 262 235 261 262 238 261 minecraft:gray_concrete
fill 264 235 247 264 238 247 minecraft:gray_concrete
fill 264 235 249 264 238 249 minecraft:gray_concrete
fill 264 235 251 264 238 251 minecraft:gray_concrete
fill 264 235 253 264 238 253 minecraft:gray_concrete
fill 264 235 255 264 238 255 minecraft:gray_concrete
fill 264 235 257 264 238 257 minecraft:gray_concrete
fill 264 235 259 264 238 259 minecraft:gray_concrete
fill 264 235 270 264 308 270 minecraft:black_concrete
setblock 266 235 231 minecraft:light[level=12]
setblock 266 235 238 minecraft:light[level=12]
setblock 266 235 245 minecraft:light[level=12]
setblock 266 235 252 minecraft:light[level=12]
setblock 266 235 259 minecraft:light[level=12]
setblock 266 235 266 minecraft:light[level=12]
setblock 267 235 228 minecraft:magenta_concrete
setblock 267 235 230 minecraft:sea_lantern
setblock 267 235 232 minecraft:sea_lantern
setblock 268 235 229 minecraft:sea_lantern
setblock 268 235 231 minecraft:sea_lantern
setblock 268 235 233 minecraft:sea_lantern
setblock 268 235 241 minecraft:sea_lantern
setblock 268 235 243 minecraft:sea_lantern
setblock 268 235 245 minecraft:sea_lantern
setblock 268 235 247 minecraft:sea_lantern
setblock 268 235 249 minecraft:sea_lantern
setblock 269 235 230 minecraft:sea_lantern
setblock 269 235 232 minecraft:sea_lantern
setblock 269 235 242 minecraft:sea_lantern
setblock 269 235 244 minecraft:sea_lantern
setblock 269 235 246 minecraft:sea_lantern
setblock 269 235 248 minecraft:sea_lantern
setblock 270 235 229 minecraft:sea_lantern
setblock 270 235 231 minecraft:sea_lantern
setblock 270 235 233 minecraft:sea_lantern
setblock 270 235 241 minecraft:sea_lantern
setblock 270 235 243 minecraft:sea_lantern
setblock 270 235 245 minecraft:sea_lantern
setblock 270 235 247 minecraft:sea_lantern
setblock 270 235 249 minecraft:sea_lantern
setblock 271 235 230 minecraft:sea_lantern
setblock 271 235 232 minecraft:sea_lantern
setblock 271 235 242 minecraft:sea_lantern
setblock 271 235 244 minecraft:sea_lantern
setblock 271 235 246 minecraft:sea_lantern
setblock 271 235 248 minecraft:sea_lantern
setblock 272 235 229 minecraft:sea_lantern
setblock 272 235 231 minecraft:sea_lantern
setblock 272 235 233 minecraft:sea_lantern
setblock 272 235 241 minecraft:sea_lantern
setblock 272 235 243 minecraft:sea_lantern
setblock 272 235 245 minecraft:sea_lantern
setblock 272 235 247 minecraft:sea_lantern
setblock 272 235 249 minecraft:sea_lantern
setblock 272 235 255 minecraft:sea_lantern
setblock 272 235 257 minecraft:sea_lantern
setblock 272 235 259 minecraft:sea_lantern
setblock 272 235 261 minecraft:sea_lantern
setblock 272 235 263 minecraft:sea_lantern
setblock 272 235 265 minecraft:sea_lantern
setblock 273 235 230 minecraft:sea_lantern
setblock 273 235 232 minecraft:sea_lantern
setblock 273 235 238 minecraft:light[level=12]
setblock 273 235 242 minecraft:sea_lantern
setblock 273 235 244 minecraft:sea_lantern
setblock 273 235 246 minecraft:sea_lantern
setblock 273 235 248 minecraft:sea_lantern
setblock 273 235 252 minecraft:light[level=12]
setblock 273 235 256 minecraft:sea_lantern
setblock 273 235 258 minecraft:sea_lantern
setblock 273 235 260 minecraft:sea_lantern
setblock 273 235 262 minecraft:sea_lantern
setblock 273 235 264 minecraft:sea_lantern
setblock 273 235 266 minecraft:light[level=12]
setblock 274 235 241 minecraft:sea_lantern
setblock 274 235 243 minecraft:sea_lantern
setblock 274 235 245 minecraft:sea_lantern
setblock 274 235 247 minecraft:sea_lantern
setblock 274 235 249 minecraft:sea_lantern
setblock 274 235 255 minecraft:sea_lantern
setblock 274 235 257 minecraft:sea_lantern
setblock 274 235 259 minecraft:sea_lantern
setblock 274 235 261 minecraft:sea_lantern
setblock 274 235 263 minecraft:sea_lantern
setblock 274 235 265 minecraft:sea_lantern
setblock 275 235 242 minecraft:sea_lantern
setblock 275 235 244 minecraft:sea_lantern
setblock 275 235 246 minecraft:sea_lantern
setblock 275 235 248 minecraft:sea_lantern
setblock 275 235 256 minecraft:sea_lantern
setblock 275 235 258 minecraft:sea_lantern
setblock 275 235 260 minecraft:sea_lantern
setblock 275 235 262 minecraft:sea_lantern
setblock 275 235 264 minecraft:sea_lantern
setblock 276 235 241 minecraft:sea_lantern
setblock 276 235 243 minecraft:sea_lantern
setblock 276 235 245 minecraft:sea_lantern
setblock 276 235 247 minecraft:sea_lantern
setblock 276 235 249 minecraft:sea_lantern
setblock 276 235 255 minecraft:sea_lantern
setblock 276 235 257 minecraft:sea_lantern
setblock 276 235 259 minecraft:sea_lantern
setblock 276 235 261 minecraft:sea_lantern
setblock 276 235 263 minecraft:sea_lantern
setblock 276 235 265 minecraft:sea_lantern
fill 235 236 233 235 239 233 minecraft:black_concrete
fill 235 236 262 235 237 262 minecraft:black_concrete
fill 235 236 264 235 237 264 minecraft:black_concrete
fill 235 236 266 235 237 266 minecraft:black_concrete
fill 235 236 268 235 237 268 minecraft:black_concrete
setblock 236 236 243 minecraft:black_stained_glass
setblock 236 236 245 minecraft:ochre_froglight
setblock 236 236 247 minecraft:sea_lantern
setblock 236 236 249 minecraft:ochre_froglight
setblock 236 236 251 minecraft:black_stained_glass
setblock 236 236 253 minecraft:black_stained_glass
fill 236 236 263 236 237 263 minecraft:gray_concrete
fill 236 236 265 236 237 265 minecraft:gray_concrete
fill 236 236 267 236 237 267 minecraft:gray_concrete
fill 236 236 269 236 237 269 minecraft:gray_concrete
setblock 237 236 242 minecraft:black_stained_glass
setblock 237 236 255 minecraft:sea_lantern
fill 237 236 262 237 237 262 minecraft:gray_concrete
fill 237 236 264 237 237 264 minecraft:gray_concrete
fill 237 236 266 237 237 266 minecraft:gray_concrete
fill 237 236 268 237 237 268 minecraft:gray_concrete
fill 238 236 263 238 237 263 minecraft:gray_concrete
fill 238 236 265 238 237 265 minecraft:gray_concrete
fill 238 236 267 238 237 267 minecraft:gray_concrete
fill 238 236 269 238 237 269 minecraft:gray_concrete
setblock 239 236 242 minecraft:black_stained_glass
setblock 239 236 255 minecraft:black_stained_glass
fill 239 236 262 239 237 262 minecraft:gray_concrete
fill 239 236 264 239 237 264 minecraft:gray_concrete
fill 239 236 266 239 237 266 minecraft:gray_concrete
fill 239 236 268 239 237 268 minecraft:gray_concrete
fill 240 236 261 240 237 261 minecraft:gray_concrete
fill 240 236 263 240 237 263 minecraft:gray_concrete
fill 240 236 265 240 237 265 minecraft:gray_concrete
fill 240 236 267 240 237 267 minecraft:gray_concrete
fill 240 236 269 240 237 269 minecraft:gray_concrete
setblock 241 236 243 minecraft:magenta_stained_glass
setblock 241 236 245 minecraft:black_stained_glass
setblock 241 236 247 minecraft:ochre_froglight
setblock 241 236 249 minecraft:black_stained_glass
setblock 241 236 251 minecraft:black_stained_glass
setblock 241 236 253 minecraft:black_stained_glass
fill 241 236 262 241 237 262 minecraft:gray_concrete
fill 241 236 264 241 237 264 minecraft:gray_concrete
fill 241 236 266 241 237 266 minecraft:gray_concrete
fill 241 236 268 241 237 268 minecraft:gray_concrete
fill 242 236 261 242 237 261 minecraft:gray_concrete
fill 242 236 263 242 237 263 minecraft:gray_concrete
fill 242 236 265 242 237 265 minecraft:gray_concrete
fill 242 236 267 242 237 267 minecraft:gray_concrete
fill 242 236 269 242 237 269 minecraft:gray_concrete
fill 243 236 262 243 237 262 minecraft:gray_concrete
fill 243 236 264 243 237 264 minecraft:gray_concrete
fill 243 236 266 243 237 266 minecraft:gray_concrete
fill 243 236 268 243 237 268 minecraft:gray_concrete
fill 244 236 261 244 237 261 minecraft:gray_concrete
fill 244 236 263 244 237 263 minecraft:gray_concrete
fill 244 236 265 244 237 265 minecraft:gray_concrete
fill 244 236 267 244 237 267 minecraft:gray_concrete
fill 244 236 269 244 237 269 minecraft:gray_concrete
fill 245 236 262 245 237 262 minecraft:gray_concrete
fill 245 236 264 245 237 264 minecraft:gray_concrete
fill 245 236 266 245 237 266 minecraft:gray_concrete
fill 245 236 268 245 237 268 minecraft:gray_concrete
fill 246 236 261 246 237 261 minecraft:gray_concrete
fill 246 236 263 246 237 263 minecraft:gray_concrete
fill 246 236 265 246 237 265 minecraft:gray_concrete
fill 246 236 267 246 237 267 minecraft:gray_concrete
fill 246 236 269 246 237 269 minecraft:gray_concrete
fill 247 236 262 247 237 262 minecraft:gray_concrete
fill 247 236 264 247 237 264 minecraft:gray_concrete
fill 247 236 266 247 237 266 minecraft:gray_concrete
fill 247 236 268 247 237 268 minecraft:gray_concrete
fill 248 236 261 248 237 261 minecraft:gray_concrete
fill 248 236 263 248 237 263 minecraft:gray_concrete
fill 248 236 265 248 237 265 minecraft:gray_concrete
fill 248 236 267 248 237 267 minecraft:gray_concrete
fill 248 236 269 248 237 269 minecraft:gray_concrete
fill 249 236 262 249 237 262 minecraft:gray_concrete
fill 249 236 264 249 237 264 minecraft:gray_concrete
setblock 249 236 265 minecraft:sea_lantern
fill 249 236 266 249 237 266 minecraft:gray_concrete
fill 249 236 268 249 237 268 minecraft:gray_concrete
fill 250 236 263 250 237 263 minecraft:gray_concrete
setblock 250 236 264 minecraft:black_stained_glass
fill 250 236 265 250 237 265 minecraft:gray_concrete
fill 250 236 267 250 237 267 minecraft:gray_concrete
setblock 250 236 269 minecraft:black_stained_glass
fill 251 236 262 251 237 262 minecraft:gray_concrete
fill 251 236 264 251 237 264 minecraft:gray_concrete
fill 251 236 266 251 237 266 minecraft:gray_concrete
fill 251 236 268 251 237 268 minecraft:gray_concrete
fill 252 236 263 252 237 263 minecraft:gray_concrete
setblock 252 236 264 minecraft:cyan_stained_glass
fill 252 236 265 252 237 265 minecraft:gray_concrete
fill 252 236 267 252 237 267 minecraft:gray_concrete
fill 252 236 269 252 237 269 minecraft:gray_concrete
fill 253 236 262 253 237 262 minecraft:gray_concrete
fill 253 236 264 253 237 264 minecraft:gray_concrete
fill 253 236 266 253 237 266 minecraft:gray_concrete
fill 253 236 268 253 237 268 minecraft:gray_concrete
setblock 254 236 264 minecraft:sea_lantern
setblock 254 236 269 minecraft:cyan_stained_glass
setblock 256 236 235 minecraft:sea_lantern
setblock 256 236 264 minecraft:black_stained_glass
setblock 256 236 269 minecraft:black_stained_glass
setblock 258 236 264 minecraft:light_blue_stained_glass
setblock 258 236 269 minecraft:light_blue_stained_glass
setblock 260 236 264 minecraft:sea_lantern
setblock 260 236 269 minecraft:black_stained_glass
setblock 262 236 265 minecraft:black_stained_glass
setblock 262 236 267 minecraft:black_stained_glass
fill 267 236 228 267 308 228 minecraft:black_concrete
fill 267 236 230 267 237 230 minecraft:gray_concrete
fill 267 236 232 267 237 232 minecraft:gray_concrete
fill 268 236 229 268 237 229 minecraft:gray_concrete
fill 268 236 231 268 237 231 minecraft:gray_concrete
fill 268 236 233 268 237 233 minecraft:gray_concrete
fill 268 236 241 268 237 241 minecraft:gray_concrete
fill 268 236 243 268 237 243 minecraft:gray_concrete
fill 268 236 245 268 237 245 minecraft:gray_concrete
fill 268 236 247 268 237 247 minecraft:gray_concrete
fill 268 236 249 268 237 249 minecraft:gray_concrete
fill 269 236 230 269 237 230 minecraft:gray_concrete
fill 269 236 232 269 237 232 minecraft:gray_concrete
fill 269 236 242 269 237 242 minecraft:gray_concrete
fill 269 236 244 269 237 244 minecraft:gray_concrete
fill 269 236 246 269 237 246 minecraft:gray_concrete
fill 269 236 248 269 237 248 minecraft:gray_concrete
fill 270 236 229 270 237 229 minecraft:gray_concrete
fill 270 236 231 270 237 231 minecraft:gray_concrete
fill 270 236 233 270 237 233 minecraft:gray_concrete
fill 270 236 241 270 237 241 minecraft:gray_concrete
fill 270 236 243 270 237 243 minecraft:gray_concrete
fill 270 236 245 270 237 245 minecraft:gray_concrete
fill 270 236 247 270 237 247 minecraft:gray_concrete
fill 270 236 249 270 237 249 minecraft:gray_concrete
fill 271 236 230 271 237 230 minecraft:gray_concrete
fill 271 236 232 271 237 232 minecraft:gray_concrete
fill 271 236 242 271 237 242 minecraft:gray_concrete
fill 271 236 244 271 237 244 minecraft:gray_concrete
fill 271 236 246 271 237 246 minecraft:gray_concrete
fill 271 236 248 271 237 248 minecraft:gray_concrete
fill 272 236 229 272 237 229 minecraft:gray_concrete
fill 272 236 231 272 237 231 minecraft:gray_concrete
fill 272 236 233 272 237 233 minecraft:gray_concrete
fill 272 236 241 272 237 241 minecraft:gray_concrete
fill 272 236 243 272 237 243 minecraft:gray_concrete
fill 272 236 245 272 237 245 minecraft:gray_concrete
fill 272 236 247 272 237 247 minecraft:gray_concrete
fill 272 236 249 272 237 249 minecraft:gray_concrete
fill 272 236 255 272 237 255 minecraft:gray_concrete
fill 272 236 257 272 237 257 minecraft:gray_concrete
fill 272 236 259 272 237 259 minecraft:gray_concrete
fill 272 236 261 272 237 261 minecraft:gray_concrete
fill 272 236 263 272 237 263 minecraft:gray_concrete
fill 272 236 265 272 237 265 minecraft:gray_concrete
fill 273 236 230 273 237 230 minecraft:gray_concrete
fill 273 236 232 273 237 232 minecraft:gray_concrete
fill 273 236 242 273 237 242 minecraft:gray_concrete
fill 273 236 244 273 237 244 minecraft:gray_concrete
fill 273 236 246 273 237 246 minecraft:gray_concrete
fill 273 236 248 273 237 248 minecraft:gray_concrete
fill 273 236 256 273 237 256 minecraft:gray_concrete
fill 273 236 258 273 237 258 minecraft:gray_concrete
fill 273 236 260 273 237 260 minecraft:gray_concrete
fill 273 236 262 273 237 262 minecraft:gray_concrete
fill 273 236 264 273 237 264 minecraft:gray_concrete
fill 274 236 241 274 237 241 minecraft:gray_concrete
fill 274 236 243 274 237 243 minecraft:gray_concrete
fill 274 236 245 274 237 245 minecraft:gray_concrete
fill 274 236 247 274 237 247 minecraft:gray_concrete
fill 274 236 249 274 237 249 minecraft:gray_concrete
fill 274 236 255 274 237 255 minecraft:gray_concrete
fill 274 236 257 274 237 257 minecraft:gray_concrete
fill 274 236 259 274 237 259 minecraft:gray_concrete
fill 274 236 261 274 237 261 minecraft:gray_concrete
fill 274 236 263 274 237 263 minecraft:gray_concrete
fill 274 236 265 274 237 265 minecraft:gray_concrete
fill 275 236 242 275 237 242 minecraft:gray_concrete
fill 275 236 244 275 237 244 minecraft:gray_concrete
fill 275 236 246 275 237 246 minecraft:gray_concrete
fill 275 236 248 275 237 248 minecraft:gray_concrete
fill 275 236 256 275 237 256 minecraft:gray_concrete
fill 275 236 258 275 237 258 minecraft:gray_concrete
fill 275 236 260 275 237 260 minecraft:gray_concrete
fill 275 236 262 275 237 262 minecraft:gray_concrete
fill 275 236 264 275 237 264 minecraft:gray_concrete
fill 276 236 241 276 237 241 minecraft:gray_concrete
fill 276 236 243 276 237 243 minecraft:gray_concrete
fill 276 236 245 276 237 245 minecraft:gray_concrete
fill 276 236 247 276 237 247 minecraft:gray_concrete
fill 276 236 249 276 237 249 minecraft:gray_concrete
fill 276 236 255 276 237 255 minecraft:gray_concrete
fill 276 236 257 276 237 257 minecraft:gray_concrete
fill 276 236 259 276 237 259 minecraft:gray_concrete
fill 276 236 261 276 237 261 minecraft:gray_concrete
fill 276 236 263 276 237 263 minecraft:gray_concrete
fill 276 236 265 276 237 265 minecraft:gray_concrete
setblock 277 236 251 minecraft:blue_concrete
fill 236 237 243 236 238 243 minecraft:black_concrete
fill 236 237 245 236 238 245 minecraft:black_concrete
fill 236 237 247 236 238 247 minecraft:black_concrete
fill 236 237 249 236 238 249 minecraft:black_concrete
fill 236 237 251 236 238 251 minecraft:black_concrete
fill 236 237 253 236 238 253 minecraft:black_concrete
fill 237 237 242 237 238 242 minecraft:black_concrete
fill 237 237 255 237 238 255 minecraft:black_concrete
fill 239 237 242 239 238 242 minecraft:black_concrete
fill 239 237 255 239 238 255 minecraft:black_concrete
fill 241 237 243 241 238 243 minecraft:black_concrete
fill 241 237 245 241 238 245 minecraft:black_concrete
fill 241 237 247 241 238 247 minecraft:black_concrete
fill 241 237 249 241 238 249 minecraft:black_concrete
fill 241 237 251 241 238 251 minecraft:black_concrete
fill 241 237 253 241 238 253 minecraft:black_concrete
fill 249 237 265 249 238 265 minecraft:gray_concrete
fill 250 237 264 250 238 264 minecraft:gray_concrete
setblock 250 237 269 minecraft:gray_concrete
fill 252 237 264 252 238 264 minecraft:gray_concrete
fill 254 237 235 258 237 235 minecraft:lime_concrete
fill 254 237 264 254 238 264 minecraft:gray_concrete
fill 254 237 269 254 238 269 minecraft:gray_concrete
setblock 255 237 228 minecraft:verdant_froglight
fill 255 237 234 257 237 234 minecraft:lime_concrete
fill 255 237 236 257 237 236 minecraft:lime_concrete
fill 256 237 264 256 238 264 minecraft:gray_concrete
fill 256 237 269 256 238 269 minecraft:gray_concrete
fill 258 237 264 258 238 264 minecraft:gray_concrete
fill 258 237 269 258 238 269 minecraft:gray_concrete
fill 260 237 264 260 238 264 minecraft:gray_concrete
fill 260 237 269 260 238 269 minecraft:gray_concrete
fill 262 237 265 262 238 265 minecraft:gray_concrete
fill 262 237 267 262 238 267 minecraft:gray_concrete
setblock 271 237 270 minecraft:ochre_froglight
fill 277 237 251 277 280 251 minecraft:black_concrete
setblock 277 237 268 minecraft:purple_concrete
setblock 235 238 245 minecraft:sea_lantern
setblock 235 238 262 minecraft:sea_lantern
setblock 235 238 264 minecraft:sea_lantern
setblock 235 238 266 minecraft:sea_lantern
setblock 235 238 268 minecraft:sea_lantern
setblock 236 238 263 minecraft:sea_lantern
setblock 236 238 265 minecraft:sea_lantern
setblock 236 238 267 minecraft:sea_lantern
setblock 236 238 269 minecraft:sea_lantern
setblock 237 238 262 minecraft:sea_lantern
setblock 237 238 264 minecraft:sea_lantern
setblock 237 238 266 minecraft:sea_lantern
setblock 237 238 268 minecraft:sea_lantern
setblock 238 238 263 minecraft:sea_lantern
setblock 238 238 265 minecraft:sea_lantern
setblock 238 238 267 minecraft:sea_lantern
setblock 238 238 269 minecraft:sea_lantern
setblock 239 238 262 minecraft:sea_lantern
setblock 239 238 264 minecraft:sea_lantern
setblock 239 238 266 minecraft:sea_lantern
setblock 239 238 268 minecraft:sea_lantern
setblock 240 238 261 minecraft:sea_lantern
setblock 240 238 263 minecraft:sea_lantern
setblock 240 238 265 minecraft:sea_lantern
setblock 240 238 267 minecraft:sea_lantern
setblock 240 238 269 minecraft:sea_lantern
setblock 241 238 262 minecraft:sea_lantern
setblock 241 238 264 minecraft:sea_lantern
setblock 241 238 266 minecraft:sea_lantern
setblock 241 238 268 minecraft:sea_lantern
setblock 242 238 261 minecraft:sea_lantern
setblock 242 238 263 minecraft:sea_lantern
setblock 242 238 265 minecraft:sea_lantern
setblock 242 238 267 minecraft:sea_lantern
setblock 242 238 269 minecraft:sea_lantern
setblock 243 238 262 minecraft:sea_lantern
setblock 243 238 264 minecraft:sea_lantern
setblock 243 238 266 minecraft:sea_lantern
setblock 243 238 268 minecraft:sea_lantern
setblock 244 238 261 minecraft:sea_lantern
setblock 244 238 263 minecraft:sea_lantern
setblock 244 238 265 minecraft:sea_lantern
setblock 244 238 267 minecraft:sea_lantern
setblock 244 238 269 minecraft:sea_lantern
setblock 245 238 262 minecraft:sea_lantern
setblock 245 238 264 minecraft:sea_lantern
setblock 245 238 266 minecraft:sea_lantern
setblock 245 238 268 minecraft:sea_lantern
setblock 246 238 261 minecraft:sea_lantern
setblock 246 238 263 minecraft:sea_lantern
setblock 246 238 265 minecraft:sea_lantern
setblock 246 238 267 minecraft:sea_lantern
setblock 246 238 269 minecraft:sea_lantern
setblock 247 238 262 minecraft:sea_lantern
setblock 247 238 264 minecraft:sea_lantern
setblock 247 238 266 minecraft:sea_lantern
setblock 247 238 268 minecraft:sea_lantern
setblock 248 238 261 minecraft:sea_lantern
setblock 248 238 263 minecraft:sea_lantern
setblock 248 238 265 minecraft:sea_lantern
setblock 248 238 267 minecraft:sea_lantern
setblock 248 238 269 minecraft:sea_lantern
fill 249 238 246 264 238 246 minecraft:yellow_concrete
setblock 249 238 262 minecraft:sea_lantern
setblock 249 238 264 minecraft:sea_lantern
setblock 249 238 266 minecraft:sea_lantern
setblock 249 238 268 minecraft:sea_lantern
setblock 250 238 263 minecraft:sea_lantern
setblock 250 238 265 minecraft:sea_lantern
setblock 250 238 267 minecraft:sea_lantern
setblock 250 238 269 minecraft:sea_lantern
setblock 251 238 262 minecraft:sea_lantern
setblock 251 238 264 minecraft:sea_lantern
setblock 251 238 266 minecraft:sea_lantern
setblock 251 238 268 minecraft:sea_lantern
setblock 252 238 263 minecraft:sea_lantern
setblock 252 238 265 minecraft:sea_lantern
setblock 252 238 267 minecraft:sea_lantern
setblock 252 238 269 minecraft:sea_lantern
setblock 253 238 262 minecraft:sea_lantern
setblock 253 238 264 minecraft:sea_lantern
setblock 253 238 266 minecraft:sea_lantern
setblock 253 238 268 minecraft:sea_lantern
fill 255 238 228 255 308 228 minecraft:black_concrete
fill 255 238 235 257 238 235 minecraft:light_blue_stained_glass
setblock 261 238 228 minecraft:sea_lantern
setblock 267 238 230 minecraft:sea_lantern
setblock 267 238 232 minecraft:sea_lantern
setblock 268 238 229 minecraft:sea_lantern
setblock 268 238 231 minecraft:sea_lantern
setblock 268 238 233 minecraft:sea_lantern
setblock 268 238 241 minecraft:sea_lantern
setblock 268 238 243 minecraft:sea_lantern
setblock 268 238 245 minecraft:sea_lantern
setblock 268 238 247 minecraft:sea_lantern
setblock 268 238 249 minecraft:sea_lantern
setblock 269 238 230 minecraft:sea_lantern
setblock 269 238 232 minecraft:sea_lantern
setblock 269 238 242 minecraft:sea_lantern
setblock 269 238 244 minecraft:sea_lantern
setblock 269 238 246 minecraft:sea_lantern
setblock 269 238 248 minecraft:sea_lantern
setblock 270 238 229 minecraft:sea_lantern
setblock 270 238 231 minecraft:sea_lantern
setblock 270 238 233 minecraft:sea_lantern
setblock 270 238 241 minecraft:sea_lantern
setblock 270 238 243 minecraft:sea_lantern
setblock 270 238 245 minecraft:sea_lantern
setblock 270 238 247 minecraft:sea_lantern
setblock 270 238 249 minecraft:sea_lantern
setblock 271 238 230 minecraft:sea_lantern
setblock 271 238 232 minecraft:sea_lantern
setblock 271 238 242 minecraft:sea_lantern
setblock 271 238 244 minecraft:sea_lantern
setblock 271 238 246 minecraft:sea_lantern
setblock 271 238 248 minecraft:sea_lantern
fill 271 238 270 271 308 270 minecraft:black_concrete
setblock 272 238 229 minecraft:sea_lantern
setblock 272 238 231 minecraft:sea_lantern
setblock 272 238 233 minecraft:sea_lantern
setblock 272 238 241 minecraft:sea_lantern
setblock 272 238 243 minecraft:sea_lantern
setblock 272 238 245 minecraft:sea_lantern
setblock 272 238 247 minecraft:sea_lantern
setblock 272 238 249 minecraft:sea_lantern
setblock 272 238 255 minecraft:sea_lantern
setblock 272 238 257 minecraft:sea_lantern
setblock 272 238 259 minecraft:sea_lantern
setblock 272 238 261 minecraft:sea_lantern
setblock 272 238 263 minecraft:sea_lantern
setblock 272 238 265 minecraft:sea_lantern
setblock 273 238 230 minecraft:sea_lantern
setblock 273 238 232 minecraft:sea_lantern
setblock 273 238 242 minecraft:sea_lantern
setblock 273 238 244 minecraft:sea_lantern
setblock 273 238 246 minecraft:sea_lantern
setblock 273 238 248 minecraft:sea_lantern
setblock 273 238 256 minecraft:sea_lantern
setblock 273 238 258 minecraft:sea_lantern
setblock 273 238 260 minecraft:sea_lantern
setblock 273 238 262 minecraft:sea_lantern
setblock 273 238 264 minecraft:sea_lantern
setblock 274 238 241 minecraft:sea_lantern
setblock 274 238 243 minecraft:sea_lantern
setblock 274 238 245 minecraft:sea_lantern
setblock 274 238 247 minecraft:sea_lantern
setblock 274 238 249 minecraft:sea_lantern
setblock 274 238 255 minecraft:sea_lantern
setblock 274 238 257 minecraft:sea_lantern
setblock 274 238 259 minecraft:sea_lantern
setblock 274 238 261 minecraft:sea_lantern
setblock 274 238 263 minecraft:sea_lantern
setblock 274 238 265 minecraft:sea_lantern
setblock 275 238 242 minecraft:sea_lantern
setblock 275 238 244 minecraft:sea_lantern
setblock 275 238 246 minecraft:sea_lantern
setblock 275 238 248 minecraft:sea_lantern
setblock 275 238 256 minecraft:sea_lantern
setblock 275 238 258 minecraft:sea_lantern
setblock 275 238 260 minecraft:sea_lantern
setblock 275 238 262 minecraft:sea_lantern
setblock 275 238 264 minecraft:sea_lantern
setblock 276 238 241 minecraft:sea_lantern
setblock 276 238 243 minecraft:sea_lantern
setblock 276 238 245 minecraft:sea_lantern
setblock 276 238 247 minecraft:sea_lantern
setblock 276 238 249 minecraft:sea_lantern
setblock 276 238 255 minecraft:sea_lantern
setblock 276 238 257 minecraft:sea_lantern
setblock 276 238 259 minecraft:sea_lantern
setblock 276 238 261 minecraft:sea_lantern
setblock 276 238 263 minecraft:sea_lantern
setblock 276 238 265 minecraft:sea_lantern
fill 277 238 268 277 269 268 minecraft:black_concrete
fill 235 239 245 235 247 245 minecraft:black_concrete
fill 235 239 262 235 280 262 minecraft:black_concrete
fill 235 239 264 235 243 264 minecraft:black_concrete
fill 235 239 266 235 279 266 minecraft:black_concrete
fill 235 239 268 235 245 268 minecraft:black_concrete
setblock 236 239 243 minecraft:black_stained_glass
setblock 236 239 245 minecraft:ochre_froglight
setblock 236 239 247 minecraft:pearlescent_froglight
setblock 236 239 249 minecraft:sea_lantern
setblock 236 239 251 minecraft:sea_lantern
setblock 236 239 253 minecraft:black_stained_glass
fill 236 239 263 236 240 263 minecraft:gray_concrete
fill 236 239 265 236 240 265 minecraft:gray_concrete
fill 236 239 267 236 240 267 minecraft:gray_concrete
fill 236 239 269 236 240 269 minecraft:gray_concrete
setblock 237 239 242 minecraft:black_stained_glass
setblock 237 239 255 minecraft:black_stained_glass
fill 237 239 262 237 240 262 minecraft:gray_concrete
fill 237 239 264 237 240 264 minecraft:gray_concrete
fill 237 239 266 237 240 266 minecraft:gray_concrete
fill 237 239 268 237 240 268 minecraft:gray_concrete
fill 238 239 263 238 240 263 minecraft:gray_concrete
fill 238 239 265 238 240 265 minecraft:gray_concrete
fill 238 239 267 238 240 267 minecraft:gray_concrete
fill 238 239 269 238 240 269 minecraft:gray_concrete
setblock 239 239 242 minecraft:black_stained_glass
setblock 239 239 255 minecraft:black_stained_glass
fill 239 239 262 239 240 262 minecraft:gray_concrete
fill 239 239 264 239 240 264 minecraft:gray_concrete
fill 239 239 266 239 240 266 minecraft:gray_concrete
fill 239 239 268 239 240 268 minecraft:gray_concrete
setblock 240 239 261 minecraft:gray_concrete
fill 240 239 263 240 240 263 minecraft:gray_concrete
fill 240 239 265 240 240 265 minecraft:gray_concrete
fill 240 239 267 240 240 267 minecraft:gray_concrete
fill 240 239 269 240 240 269 minecraft:gray_concrete
setblock 241 239 243 minecraft:light_blue_stained_glass
setblock 241 239 245 minecraft:sea_lantern
setblock 241 239 247 minecraft:light_blue_stained_glass
setblock 241 239 249 minecraft:sea_lantern
setblock 241 239 251 minecraft:light_blue_stained_glass
setblock 241 239 253 minecraft:black_stained_glass
fill 241 239 262 241 240 262 minecraft:gray_concrete
fill 241 239 264 241 240 264 minecraft:gray_concrete
fill 241 239 266 241 240 266 minecraft:gray_concrete
fill 241 239 268 241 240 268 minecraft:gray_concrete
setblock 242 239 261 minecraft:gray_concrete
fill 242 239 263 242 240 263 minecraft:gray_concrete
fill 242 239 265 242 240 265 minecraft:gray_concrete
fill 242 239 267 242 240 267 minecraft:gray_concrete
fill 242 239 269 242 240 269 minecraft:gray_concrete
fill 243 239 262 243 240 262 minecraft:gray_concrete
fill 243 239 264 243 240 264 minecraft:gray_concrete
fill 243 239 266 243 240 266 minecraft:gray_concrete
fill 243 239 268 243 240 268 minecraft:gray_concrete
fill 244 239 261 244 240 261 minecraft:gray_concrete
fill 244 239 263 244 240 263 minecraft:gray_concrete
fill 244 239 265 244 240 265 minecraft:gray_concrete
fill 244 239 267 244 240 267 minecraft:gray_concrete
fill 244 239 269 244 240 269 minecraft:gray_concrete
fill 245 239 262 245 240 262 minecraft:gray_concrete
fill 245 239 264 245 240 264 minecraft:gray_concrete
fill 245 239 266 245 240 266 minecraft:gray_concrete
fill 245 239 268 245 240 268 minecraft:gray_concrete
fill 246 239 261 246 240 261 minecraft:gray_concrete
fill 246 239 263 246 240 263 minecraft:gray_concrete
fill 246 239 265 246 240 265 minecraft:gray_concrete
fill 246 239 267 246 240 267 minecraft:gray_concrete
fill 246 239 269 246 240 269 minecraft:gray_concrete
fill 247 239 262 247 240 262 minecraft:gray_concrete
fill 247 239 264 247 240 264 minecraft:gray_concrete
fill 247 239 266 247 240 266 minecraft:gray_concrete
fill 247 239 268 247 240 268 minecraft:gray_concrete
fill 248 239 261 249 240 261 minecraft:gray_concrete
fill 248 239 263 248 240 263 minecraft:gray_concrete
fill 248 239 265 248 240 265 minecraft:gray_concrete
fill 248 239 267 248 240 267 minecraft:gray_concrete
fill 248 239 269 248 240 269 minecraft:gray_concrete
fill 249 239 262 249 240 262 minecraft:gray_concrete
fill 249 239 264 249 259 264 minecraft:gray_concrete
setblock 249 239 265 minecraft:black_stained_glass
fill 249 239 266 249 282 266 minecraft:gray_concrete
setblock 249 239 267 minecraft:ochre_froglight
fill 249 239 268 249 282 268 minecraft:gray_concrete
fill 250 239 263 250 240 263 minecraft:gray_concrete
setblock 250 239 264 minecraft:magenta_stained_glass
fill 250 239 265 250 282 265 minecraft:gray_concrete
fill 250 239 267 250 282 267 minecraft:gray_concrete
setblock 250 239 269 minecraft:ochre_froglight
fill 251 239 262 251 240 262 minecraft:gray_concrete
fill 251 239 264 251 282 264 minecraft:gray_concrete
fill 251 239 266 251 282 266 minecraft:gray_concrete
fill 251 239 268 251 282 268 minecraft:gray_concrete
fill 252 239 263 252 240 263 minecraft:gray_concrete
setblock 252 239 264 minecraft:cyan_stained_glass
fill 252 239 265 252 282 265 minecraft:gray_concrete
fill 252 239 267 252 282 267 minecraft:gray_concrete
setblock 252 239 269 minecraft:pearlescent_froglight
fill 253 239 262 253 240 262 minecraft:gray_concrete
fill 253 239 264 253 282 264 minecraft:gray_concrete
fill 253 239 266 253 282 266 minecraft:gray_concrete
fill 253 239 268 253 282 268 minecraft:gray_concrete
setblock 254 239 264 minecraft:magenta_stained_glass
setblock 254 239 269 minecraft:black_stained_glass
setblock 256 239 264 minecraft:black_stained_glass
setblock 256 239 269 minecraft:ochre_froglight
setblock 258 239 228 minecraft:sea_lantern
setblock 258 239 264 minecraft:light_blue_stained_glass
setblock 258 239 269 minecraft:pearlescent_froglight
setblock 260 239 264 minecraft:ochre_froglight
setblock 260 239 269 minecraft:black_stained_glass
fill 261 239 228 261 308 228 minecraft:black_concrete
setblock 262 239 265 minecraft:black_stained_glass
setblock 262 239 267 minecraft:ochre_froglight
fill 267 239 230 267 240 230 minecraft:gray_concrete
fill 267 239 232 267 240 232 minecraft:gray_concrete
fill 268 239 229 268 240 229 minecraft:gray_concrete
fill 268 239 231 268 240 231 minecraft:gray_concrete
fill 268 239 233 268 240 233 minecraft:gray_concrete
fill 268 239 241 268 240 241 minecraft:gray_concrete
fill 268 239 243 268 240 243 minecraft:gray_concrete
fill 268 239 245 268 240 245 minecraft:gray_concrete
fill 268 239 247 268 240 247 minecraft:gray_concrete
fill 268 239 249 268 240 249 minecraft:gray_concrete
fill 269 239 230 269 240 230 minecraft:gray_concrete
fill 269 239 232 269 240 232 minecraft:gray_concrete
fill 269 239 242 269 240 242 minecraft:gray_concrete
fill 269 239 244 269 240 244 minecraft:gray_concrete
fill 269 239 246 269 240 246 minecraft:gray_concrete
fill 269 239 248 269 240 248 minecraft:gray_concrete
fill 270 239 229 270 240 229 minecraft:gray_concrete
fill 270 239 231 270 240 231 minecraft:gray_concrete
fill 270 239 233 270 240 233 minecraft:gray_concrete
fill 270 239 241 270 240 241 minecraft:gray_concrete
fill 270 239 243 270 240 243 minecraft:gray_concrete
fill 270 239 245 270 240 245 minecraft:gray_concrete
fill 270 239 247 270 240 247 minecraft:gray_concrete
fill 270 239 249 270 240 249 minecraft:gray_concrete
fill 271 239 230 271 240 230 minecraft:gray_concrete
fill 271 239 232 271 240 232 minecraft:gray_concrete
fill 271 239 242 271 240 242 minecraft:gray_concrete
fill 271 239 244 271 240 244 minecraft:gray_concrete
fill 271 239 246 271 240 246 minecraft:gray_concrete
fill 271 239 248 271 240 248 minecraft:gray_concrete
fill 272 239 229 272 240 229 minecraft:gray_concrete
fill 272 239 231 272 240 231 minecraft:gray_concrete
fill 272 239 233 272 240 233 minecraft:gray_concrete
fill 272 239 241 272 240 241 minecraft:gray_concrete
fill 272 239 243 272 240 243 minecraft:gray_concrete
fill 272 239 245 272 240 245 minecraft:gray_concrete
fill 272 239 247 272 240 247 minecraft:gray_concrete
fill 272 239 249 272 240 249 minecraft:gray_concrete
fill 272 239 255 272 241 255 minecraft:gray_concrete
fill 272 239 257 272 241 257 minecraft:gray_concrete
fill 272 239 259 272 241 259 minecraft:gray_concrete
fill 272 239 261 272 241 261 minecraft:gray_concrete
fill 272 239 263 272 241 263 minecraft:gray_concrete
fill 272 239 265 272 241 265 minecraft:gray_concrete
setblock 273 239 228 minecraft:blue_concrete
fill 273 239 230 273 240 230 minecraft:gray_concrete
fill 273 239 232 273 240 232 minecraft:gray_concrete
fill 273 239 242 273 240 242 minecraft:gray_concrete
fill 273 239 244 273 240 244 minecraft:gray_concrete
fill 273 239 246 273 240 246 minecraft:gray_concrete
fill 273 239 248 273 240 248 minecraft:gray_concrete
fill 273 239 256 273 241 256 minecraft:gray_concrete
fill 273 239 258 273 241 258 minecraft:gray_concrete
fill 273 239 260 273 241 260 minecraft:gray_concrete
fill 273 239 262 273 241 262 minecraft:gray_concrete
fill 273 239 264 273 241 264 minecraft:gray_concrete
fill 274 239 241 274 240 241 minecraft:gray_concrete
fill 274 239 243 274 240 243 minecraft:gray_concrete
fill 274 239 245 274 240 245 minecraft:gray_concrete
fill 274 239 247 274 240 247 minecraft:gray_concrete
fill 274 239 249 274 240 249 minecraft:gray_concrete
fill 274 239 255 274 241 255 minecraft:gray_concrete
fill 274 239 257 274 241 257 minecraft:gray_concrete
fill 274 239 259 274 241 259 minecraft:gray_concrete
fill 274 239 261 274 241 261 minecraft:gray_concrete
fill 274 239 263 274 241 263 minecraft:gray_concrete
fill 274 239 265 274 241 265 minecraft:gray_concrete
fill 275 239 242 275 240 242 minecraft:gray_concrete
fill 275 239 244 275 240 244 minecraft:gray_concrete
fill 275 239 246 275 240 246 minecraft:gray_concrete
fill 275 239 248 275 240 248 minecraft:gray_concrete
fill 275 239 256 275 241 256 minecraft:gray_concrete
fill 275 239 258 275 241 258 minecraft:gray_concrete
fill 275 239 260 275 241 260 minecraft:gray_concrete
fill 275 239 262 275 241 262 minecraft:gray_concrete
fill 275 239 264 275 241 264 minecraft:gray_concrete
fill 276 239 241 276 240 241 minecraft:gray_concrete
fill 276 239 243 276 240 243 minecraft:gray_concrete
fill 276 239 245 276 240 245 minecraft:gray_concrete
fill 276 239 247 276 240 247 minecraft:gray_concrete
fill 276 239 249 276 240 249 minecraft:gray_concrete
fill 276 239 255 276 241 255 minecraft:gray_concrete
fill 276 239 257 276 241 257 minecraft:gray_concrete
fill 276 239 259 276 241 259 minecraft:gray_concrete
fill 276 239 261 276 241 261 minecraft:gray_concrete
fill 276 239 263 276 241 263 minecraft:gray_concrete
fill 276 239 265 276 241 265 minecraft:gray_concrete
setblock 277 239 232 minecraft:ochre_froglight
setblock 235 240 233 minecraft:purple_concrete
setblock 235 240 265 minecraft:magenta_concrete
fill 236 240 243 236 241 243 minecraft:black_concrete
fill 236 240 245 236 241 245 minecraft:black_concrete
fill 236 240 247 236 241 247 minecraft:black_concrete
fill 236 240 249 236 241 249 minecraft:black_concrete
fill 236 240 251 236 241 251 minecraft:black_concrete
fill 236 240 253 236 241 253 minecraft:black_concrete
fill 237 240 242 237 241 242 minecraft:black_concrete
fill 237 240 255 237 241 255 minecraft:black_concrete
fill 239 240 242 239 241 242 minecraft:black_concrete
fill 239 240 255 239 241 255 minecraft:black_concrete
fill 241 240 243 241 241 243 minecraft:black_concrete
fill 241 240 245 241 241 245 minecraft:black_concrete
fill 241 240 247 241 241 247 minecraft:black_concrete
fill 241 240 249 241 241 249 minecraft:black_concrete
fill 241 240 251 241 241 251 minecraft:black_concrete
fill 241 240 253 241 241 253 minecraft:black_concrete
fill 249 240 265 249 241 265 minecraft:gray_concrete
fill 249 240 267 249 241 267 minecraft:gray_concrete
fill 250 240 264 250 241 264 minecraft:gray_concrete
fill 250 240 269 250 241 269 minecraft:gray_concrete
fill 252 240 264 252 241 264 minecraft:gray_concrete
fill 252 240 269 252 241 269 minecraft:gray_concrete
setblock 254 240 228 minecraft:blue_concrete
fill 254 240 264 254 241 264 minecraft:gray_concrete
fill 254 240 269 254 241 269 minecraft:gray_concrete
fill 256 240 264 256 241 264 minecraft:gray_concrete
fill 256 240 269 256 241 269 minecraft:gray_concrete
fill 258 240 228 258 308 228 minecraft:black_concrete
fill 258 240 264 258 241 264 minecraft:gray_concrete
fill 258 240 269 258 241 269 minecraft:gray_concrete
fill 260 240 264 260 241 264 minecraft:gray_concrete
fill 260 240 269 260 241 269 minecraft:gray_concrete
fill 262 240 265 262 241 265 minecraft:gray_concrete
fill 262 240 267 262 241 267 minecraft:gray_concrete
setblock 269 240 270 minecraft:blue_concrete
fill 273 240 228 273 284 228 minecraft:black_concrete
fill 277 240 232 277 308 232 minecraft:black_concrete
setblock 277 240 260 minecraft:pearlescent_froglight
fill 235 241 233 235 308 233 minecraft:black_concrete
fill 235 241 265 235 308 265 minecraft:black_concrete
setblock 238 241 231 minecraft:light[level=15]
setblock 238 241 238 minecraft:light[level=12]
setblock 238 241 239 minecraft:light[level=15]
setblock 238 241 259 minecraft:light[level=12]
setblock 238 241 263 minecraft:light[level=15]
setblock 238 241 266 minecraft:light[level=12]
setblock 245 241 231 minecraft:light[level=12]
setblock 245 241 238 minecraft:light[level=12]
setblock 245 241 245 minecraft:light[level=12]
setblock 245 241 252 minecraft:light[level=12]
setblock 245 241 259 minecraft:light[level=12]
setblock 245 241 266 minecraft:light[level=12]
setblock 246 241 231 minecraft:light[level=15]
setblock 246 241 239 minecraft:light[level=15]
setblock 246 241 247 minecraft:light[level=15]
setblock 246 241 255 minecraft:light[level=15]
setblock 246 241 263 minecraft:light[level=15]
setblock 252 241 231 minecraft:light[level=12]
setblock 252 241 238 minecraft:light[level=12]
setblock 252 241 245 minecraft:light[level=12]
setblock 252 241 252 minecraft:light[level=12]
setblock 252 241 259 minecraft:light[level=12]
fill 254 241 228 254 256 228 minecraft:black_concrete
setblock 254 241 231 minecraft:light[level=15]
setblock 254 241 239 minecraft:light[level=15]
setblock 254 241 247 minecraft:light[level=15]
setblock 254 241 255 minecraft:light[level=15]
setblock 254 241 263 minecraft:light[level=15]
setblock 259 241 231 minecraft:light[level=12]
setblock 259 241 238 minecraft:light[level=12]
setblock 259 241 245 minecraft:light[level=12]
setblock 259 241 252 minecraft:light[level=12]
setblock 259 241 259 minecraft:light[level=12]
setblock 262 241 231 minecraft:light[level=15]
setblock 262 241 239 minecraft:light[level=15]
setblock 262 241 247 minecraft:light[level=15]
setblock 262 241 255 minecraft:light[level=15]
setblock 262 241 263 minecraft:light[level=15]
setblock 266 241 231 minecraft:light[level=12]
setblock 266 241 238 minecraft:light[level=12]
setblock 266 241 245 minecraft:light[level=12]
setblock 266 241 252 minecraft:light[level=12]
setblock 266 241 259 minecraft:light[level=12]
setblock 266 241 266 minecraft:light[level=12]
setblock 267 241 230 minecraft:sea_lantern
setblock 267 241 232 minecraft:sea_lantern
setblock 268 241 229 minecraft:sea_lantern
setblock 268 241 231 minecraft:sea_lantern
setblock 268 241 233 minecraft:sea_lantern
setblock 268 241 241 minecraft:sea_lantern
setblock 268 241 243 minecraft:sea_lantern
setblock 268 241 245 minecraft:sea_lantern
setblock 268 241 247 minecraft:sea_lantern
setblock 268 241 249 minecraft:sea_lantern
setblock 269 241 230 minecraft:sea_lantern
setblock 269 241 232 minecraft:sea_lantern
setblock 269 241 242 minecraft:sea_lantern
setblock 269 241 244 minecraft:sea_lantern
setblock 269 241 246 minecraft:sea_lantern
setblock 269 241 248 minecraft:sea_lantern
fill 269 241 270 269 255 270 minecraft:black_concrete
setblock 270 241 229 minecraft:sea_lantern
setblock 270 241 231 minecraft:sea_lantern
setblock 270 241 233 minecraft:sea_lantern
setblock 270 241 239 minecraft:light[level=15]
setblock 270 241 241 minecraft:sea_lantern
setblock 270 241 243 minecraft:sea_lantern
setblock 270 241 245 minecraft:sea_lantern
setblock 270 241 247 minecraft:sea_lantern
setblock 270 241 249 minecraft:sea_lantern
setblock 270 241 255 minecraft:light[level=15]
setblock 270 241 263 minecraft:light[level=15]
setblock 271 241 230 minecraft:sea_lantern
setblock 271 241 232 minecraft:sea_lantern
setblock 271 241 242 minecraft:sea_lantern
setblock 271 241 244 minecraft:sea_lantern
setblock 271 241 246 minecraft:sea_lantern
setblock 271 241 248 minecraft:sea_lantern
setblock 272 241 229 minecraft:sea_lantern
setblock 272 241 231 minecraft:sea_lantern
setblock 272 241 233 minecraft:sea_lantern
setblock 272 241 241 minecraft:sea_lantern
setblock 272 241 243 minecraft:sea_lantern
setblock 272 241 245 minecraft:sea_lantern
setblock 272 241 247 minecraft:sea_lantern
setblock 272 241 249 minecraft:sea_lantern
setblock 273 241 230 minecraft:sea_lantern
setblock 273 241 232 minecraft:sea_lantern
setblock 273 241 238 minecraft:light[level=12]
setblock 273 241 242 minecraft:sea_lantern
setblock 273 241 244 minecraft:sea_lantern
setblock 273 241 246 minecraft:sea_lantern
setblock 273 241 248 minecraft:sea_lantern
setblock 273 241 252 minecraft:light[level=12]
setblock 273 241 266 minecraft:light[level=12]
setblock 274 241 241 minecraft:sea_lantern
setblock 274 241 243 minecraft:sea_lantern
setblock 274 241 245 minecraft:sea_lantern
setblock 274 241 247 minecraft:sea_lantern
setblock 274 241 249 minecraft:sea_lantern
setblock 275 241 242 minecraft:sea_lantern
setblock 275 241 244 minecraft:sea_lantern
setblock 275 241 246 minecraft:sea_lantern
setblock 275 241 248 minecraft:sea_lantern
setblock 276 241 241 minecraft:sea_lantern
setblock 276 241 243 minecraft:sea_lantern
setblock 276 241 245 minecraft:sea_lantern
setblock 276 241 247 minecraft:sea_lantern
setblock 276 241 249 minecraft:sea_lantern
fill 277 241 260 277 308 260 minecraft:black_concrete
setblock 235 242 243 minecraft:blue_concrete
setblock 235 242 251 minecraft:sea_lantern
setblock 236 242 243 minecraft:cyan_stained_glass
setblock 236 242 245 minecraft:magenta_stained_glass
setblock 236 242 247 minecraft:black_stained_glass
setblock 236 242 249 minecraft:magenta_stained_glass
setblock 236 242 251 minecraft:black_stained_glass
setblock 236 242 253 minecraft:black_stained_glass
setblock 237 242 242 minecraft:sea_lantern
setblock 237 242 255 minecraft:light_blue_stained_glass
setblock 239 242 242 minecraft:pearlescent_froglight
setblock 239 242 255 minecraft:cyan_stained_glass
setblock 241 242 243 minecraft:sea_lantern
setblock 241 242 245 minecraft:black_stained_glass
setblock 241 242 247 minecraft:sea_lantern
setblock 241 242 249 minecraft:magenta_stained_glass
setblock 241 242 251 minecraft:ochre_froglight
setblock 241 242 253 minecraft:black_stained_glass
setblock 249 242 265 minecraft:ochre_froglight
setblock 249 242 267 minecraft:pearlescent_froglight
setblock 250 242 264 minecraft:sea_lantern
setblock 250 242 269 minecraft:cyan_stained_glass
setblock 252 242 264 minecraft:black_stained_glass
setblock 252 242 269 minecraft:black_stained_glass
setblock 254 242 264 minecraft:cyan_stained_glass
setblock 254 242 269 minecraft:ochre_froglight
setblock 256 242 264 minecraft:magenta_stained_glass
setblock 256 242 269 minecraft:black_stained_glass
setblock 258 242 264 minecraft:ochre_froglight
setblock 258 242 269 minecraft:light_blue_stained_glass
setblock 260 242 264 minecraft:black_stained_glass
setblock 260 242 269 minecraft:black_stained_glass
setblock 262 242 265 minecraft:sea_lantern
setblock 262 242 267 minecraft:pearlescent_froglight
fill 264 242 237 268 242 239 minecraft:cyan_stained_glass
fill 265 242 236 267 242 236 minecraft:cyan_stained_glass
fill 265 242 240 267 242 240 minecraft:cyan_stained_glass
fill 267 242 230 267 244 230 minecraft:gray_concrete
fill 267 242 232 267 244 232 minecraft:gray_concrete
fill 268 242 229 268 244 229 minecraft:gray_concrete
fill 268 242 231 268 244 231 minecraft:gray_concrete
fill 268 242 233 268 244 233 minecraft:gray_concrete
fill 268 242 241 268 243 241 minecraft:gray_concrete
fill 268 242 243 268 243 243 minecraft:gray_concrete
fill 268 242 245 268 243 245 minecraft:gray_concrete
fill 268 242 247 268 243 247 minecraft:gray_concrete
fill 268 242 249 268 243 249 minecraft:gray_concrete
fill 269 242 230 269 244 230 minecraft:gray_concrete
fill 269 242 232 269 244 232 minecraft:gray_concrete
fill 269 242 242 269 243 242 minecraft:gray_concrete
fill 269 242 244 269 243 244 minecraft:gray_concrete
fill 269 242 246 269 243 246 minecraft:gray_concrete
fill 269 242 248 269 243 248 minecraft:gray_concrete
fill 270 242 229 270 244 229 minecraft:gray_concrete
fill 270 242 231 270 244 231 minecraft:gray_concrete
fill 270 242 233 270 244 233 minecraft:gray_concrete
fill 270 242 241 270 243 241 minecraft:gray_concrete
fill 270 242 243 270 243 243 minecraft:gray_concrete
fill 270 242 245 270 243 245 minecraft:gray_concrete
fill 270 242 247 270 243 247 minecraft:gray_concrete
fill 270 242 249 270 243 249 minecraft:gray_concrete
fill 271 242 230 271 244 230 minecraft:gray_concrete
fill 271 242 232 271 244 232 minecraft:gray_concrete
fill 271 242 242 271 243 242 minecraft:gray_concrete
fill 271 242 244 271 243 244 minecraft:gray_concrete
fill 271 242 246 271 243 246 minecraft:gray_concrete
fill 271 242 248 271 243 248 minecraft:gray_concrete
fill 272 242 229 272 244 229 minecraft:gray_concrete
fill 272 242 231 272 244 231 minecraft:gray_concrete
fill 272 242 233 272 244 233 minecraft:gray_concrete
fill 272 242 241 272 243 241 minecraft:gray_concrete
fill 272 242 243 272 243 243 minecraft:gray_concrete
fill 272 242 245 272 243 245 minecraft:gray_concrete
fill 272 242 247 272 243 247 minecraft:gray_concrete
fill 272 242 249 272 243 249 minecraft:gray_concrete
fill 273 242 230 273 244 230 minecraft:gray_concrete
fill 273 242 232 273 244 232 minecraft:gray_concrete
fill 273 242 242 273 243 242 minecraft:gray_concrete
fill 273 242 244 273 243 244 minecraft:gray_concrete
fill 273 242 246 273 243 246 minecraft:gray_concrete
fill 273 242 248 273 243 248 minecraft:gray_concrete
fill 274 242 241 274 243 241 minecraft:gray_concrete
fill 274 242 243 274 243 243 minecraft:gray_concrete
fill 274 242 245 274 243 245 minecraft:gray_concrete
fill 274 242 247 274 243 247 minecraft:gray_concrete
fill 274 242 249 274 243 249 minecraft:gray_concrete
fill 275 242 242 275 243 242 minecraft:gray_concrete
fill 275 242 244 275 243 244 minecraft:gray_concrete
fill 275 242 246 275 243 246 minecraft:gray_concrete
fill 275 242 248 275 243 248 minecraft:gray_concrete
fill 276 242 241 276 243 241 minecraft:gray_concrete
fill 276 242 243 276 243 243 minecraft:gray_concrete
fill 276 242 245 276 243 245 minecraft:gray_concrete
fill 276 242 247 276 243 247 minecraft:gray_concrete
fill 276 242 249 276 243 249 minecraft:gray_concrete
setblock 235 243 229 minecraft:sea_lantern
setblock 235 243 230 minecraft:ochre_froglight
fill 235 243 243 236 244 243 minecraft:black_concrete
fill 235 243 251 236 244 251 minecraft:black_concrete
fill 236 243 245 236 244 245 minecraft:black_concrete
fill 236 243 247 236 244 247 minecraft:black_concrete
fill 236 243 249 236 244 249 minecraft:black_concrete
fill 236 243 253 236 244 253 minecraft:black_concrete
fill 237 243 242 237 244 242 minecraft:black_concrete
fill 237 243 255 237 244 255 minecraft:black_concrete
fill 239 243 242 239 244 242 minecraft:black_concrete
fill 239 243 255 239 244 255 minecraft:black_concrete
fill 241 243 243 241 244 243 minecraft:black_concrete
fill 241 243 245 241 244 245 minecraft:black_concrete
fill 241 243 247 241 244 247 minecraft:black_concrete
fill 241 243 249 241 244 249 minecraft:black_concrete
fill 241 243 251 241 244 251 minecraft:black_concrete
fill 241 243 253 241 244 253 minecraft:black_concrete
fill 249 243 265 249 244 265 minecraft:gray_concrete
fill 249 243 267 249 244 267 minecraft:gray_concrete
fill 250 243 264 250 244 264 minecraft:gray_concrete
fill 250 243 269 250 244 269 minecraft:gray_concrete
setblock 250 243 270 minecraft:pearlescent_froglight
fill 252 243 264 252 244 264 minecraft:gray_concrete
fill 252 243 269 252 244 269 minecraft:gray_concrete
fill 254 243 264 254 244 264 minecraft:gray_concrete
fill 254 243 269 254 244 269 minecraft:gray_concrete
fill 256 243 264 256 244 264 minecraft:gray_concrete
fill 256 243 269 256 244 269 minecraft:gray_concrete
fill 258 243 264 258 244 264 minecraft:gray_concrete
fill 258 243 269 258 244 269 minecraft:gray_concrete
fill 260 243 264 260 244 264 minecraft:gray_concrete
fill 260 243 269 260 244 269 minecraft:gray_concrete
fill 262 243 265 262 244 265 minecraft:gray_concrete
fill 262 243 267 262 244 267 minecraft:gray_concrete
fill 263 243 237 263 244 239 minecraft:cyan_stained_glass
fill 264 243 236 264 243 237 minecraft:cyan_stained_glass
fill 264 243 239 264 243 240 minecraft:cyan_stained_glass
fill 265 243 235 265 243 236 minecraft:cyan_stained_glass
fill 265 243 240 265 243 241 minecraft:cyan_stained_glass
fill 266 243 235 267 244 235 minecraft:cyan_stained_glass
fill 266 243 241 267 244 241 minecraft:cyan_stained_glass
fill 267 243 236 268 243 236 minecraft:cyan_stained_glass
fill 267 243 240 268 243 240 minecraft:cyan_stained_glass
fill 268 243 237 269 243 237 minecraft:cyan_stained_glass
fill 268 243 239 269 243 239 minecraft:cyan_stained_glass
fill 269 243 238 269 244 238 minecraft:cyan_stained_glass
fill 235 244 229 235 283 230 minecraft:black_concrete
setblock 235 244 264 minecraft:purple_concrete
setblock 245 244 228 minecraft:magenta_concrete
fill 250 244 270 250 308 270 minecraft:black_concrete
fill 263 244 236 263 247 236 minecraft:cyan_stained_glass
fill 263 244 240 263 247 240 minecraft:cyan_stained_glass
fill 264 244 235 265 244 235 minecraft:cyan_stained_glass
fill 264 244 241 265 244 241 minecraft:cyan_stained_glass
fill 268 244 235 268 247 235 minecraft:cyan_stained_glass
setblock 268 244 241 minecraft:sea_lantern
setblock 268 244 243 minecraft:sea_lantern
setblock 268 244 245 minecraft:sea_lantern
setblock 268 244 247 minecraft:sea_lantern
setblock 268 244 249 minecraft:sea_lantern
fill 269 244 236 269 244 237 minecraft:cyan_stained_glass
fill 269 244 239 269 244 240 minecraft:cyan_stained_glass
setblock 269 244 242 minecraft:sea_lantern
setblock 269 244 244 minecraft:sea_lantern
setblock 269 244 246 minecraft:sea_lantern
setblock 269 244 248 minecraft:sea_lantern
setblock 270 244 241 minecraft:sea_lantern
setblock 270 244 243 minecraft:sea_lantern
setblock 270 244 245 minecraft:sea_lantern
setblock 270 244 247 minecraft:sea_lantern
setblock 270 244 249 minecraft:sea_lantern
setblock 271 244 242 minecraft:sea_lantern
setblock 271 244 244 minecraft:sea_lantern
setblock 271 244 246 minecraft:sea_lantern
setblock 271 244 248 minecraft:sea_lantern
setblock 272 244 241 minecraft:sea_lantern
setblock 272 244 243 minecraft:sea_lantern
setblock 272 244 245 minecraft:sea_lantern
setblock 272 244 247 minecraft:sea_lantern
setblock 272 244 249 minecraft:sea_lantern
setblock 273 244 242 minecraft:sea_lantern
setblock 273 244 244 minecraft:sea_lantern
setblock 273 244 246 minecraft:sea_lantern
setblock 273 244 248 minecraft:sea_lantern
setblock 274 244 241 minecraft:sea_lantern
setblock 274 244 243 minecraft:sea_lantern
setblock 274 244 245 minecraft:sea_lantern
setblock 274 244 247 minecraft:sea_lantern
setblock 274 244 249 minecraft:sea_lantern
setblock 275 244 242 minecraft:sea_lantern
setblock 275 244 244 minecraft:sea_lantern
setblock 275 244 246 minecraft:sea_lantern
setblock 275 244 248 minecraft:sea_lantern
setblock 276 244 241 minecraft:sea_lantern
setblock 276 244 243 minecraft:sea_lantern
setblock 276 244 245 minecraft:sea_lantern
setblock 276 244 247 minecraft:sea_lantern
setblock 276 244 249 minecraft:sea_lantern
setblock 277 244 231 minecraft:purple_concrete
fill 235 245 243 235 308 243 minecraft:black_concrete
fill 235 245 251 235 265 251 minecraft:black_concrete
fill 235 245 264 235 300 264 minecraft:black_concrete
setblock 236 245 243 minecraft:black_stained_glass
setblock 236 245 245 minecraft:sea_lantern
setblock 236 245 247 minecraft:light_blue_stained_glass
setblock 236 245 249 minecraft:black_stained_glass
setblock 236 245 251 minecraft:black_stained_glass
setblock 236 245 253 minecraft:black_stained_glass
setblock 237 245 242 minecraft:sea_lantern
setblock 237 245 255 minecraft:light_blue_stained_glass
setblock 239 245 242 minecraft:black_stained_glass
setblock 239 245 255 minecraft:magenta_stained_glass
setblock 240 245 228 minecraft:blue_concrete
setblock 241 245 243 minecraft:light_blue_stained_glass
setblock 241 245 245 minecraft:sea_lantern
setblock 241 245 247 minecraft:ochre_froglight
setblock 241 245 249 minecraft:pearlescent_froglight
setblock 241 245 251 minecraft:pearlescent_froglight
setblock 241 245 253 minecraft:magenta_stained_glass
fill 245 245 228 245 259 228 minecraft:black_concrete
setblock 249 245 265 minecraft:cyan_stained_glass
setblock 249 245 267 minecraft:pearlescent_froglight
setblock 250 245 264 minecraft:black_stained_glass
setblock 250 245 269 minecraft:black_stained_glass
setblock 252 245 264 minecraft:black_stained_glass
setblock 252 245 269 minecraft:black_stained_glass
setblock 254 245 264 minecraft:pearlescent_froglight
setblock 254 245 269 minecraft:black_stained_glass
setblock 256 245 264 minecraft:black_stained_glass
setblock 256 245 269 minecraft:black_stained_glass
setblock 258 245 264 minecraft:light_blue_stained_glass
setblock 258 245 269 minecraft:light_blue_stained_glass
setblock 260 245 264 minecraft:black_stained_glass
setblock 260 245 269 minecraft:black_stained_glass
fill 262 245 237 262 246 239 minecraft:cyan_stained_glass
setblock 262 245 265 minecraft:sea_lantern
setblock 262 245 267 minecraft:light_blue_stained_glass
fill 264 245 235 264 247 235 minecraft:cyan_stained_glass
fill 264 245 241 264 247 241 minecraft:cyan_stained_glass
fill 265 245 234 267 246 234 minecraft:cyan_stained_glass
fill 265 245 238 267 246 238 minecraft:pearlescent_froglight
fill 265 245 242 267 246 242 minecraft:cyan_stained_glass
fill 266 245 237 266 246 237 minecraft:pearlescent_froglight
fill 266 245 239 266 246 239 minecraft:pearlescent_froglight
fill 268 245 241 268 246 241 minecraft:cyan_stained_glass
fill 268 245 243 268 246 243 minecraft:gray_concrete
fill 268 245 245 268 246 245 minecraft:gray_concrete
fill 268 245 247 268 246 247 minecraft:gray_concrete
fill 268 245 249 268 246 249 minecraft:gray_concrete
fill 269 245 236 269 247 236 minecraft:cyan_stained_glass
fill 269 245 240 269 247 240 minecraft:cyan_stained_glass
fill 269 245 242 269 246 242 minecraft:gray_concrete
fill 269 245 244 269 246 244 minecraft:gray_concrete
fill 269 245 246 269 246 246 minecraft:gray_concrete
fill 269 245 248 269 246 248 minecraft:gray_concrete
fill 270 245 237 270 246 239 minecraft:cyan_stained_glass
fill 270 245 241 270 246 241 minecraft:gray_concrete
fill 270 245 243 270 246 243 minecraft:gray_concrete
fill 270 245 245 270 246 245 minecraft:gray_concrete
fill 270 245 247 270 246 247 minecraft:gray_concrete
fill 270 245 249 270 246 249 minecraft:gray_concrete
fill 271 245 242 271 246 242 minecraft:gray_concrete
fill 271 245 244 271 246 244 minecraft:gray_concrete
fill 271 245 246 271 246 246 minecraft:gray_concrete
fill 271 245 248 271 246 248 minecraft:gray_concrete
fill 272 245 241 272 246 241 minecraft:gray_concrete
fill 272 245 243 272 246 243 minecraft:gray_concrete
fill 272 245 245 272 246 245 minecraft:gray_concrete
fill 272 245 247 272 246 247 minecraft:gray_concrete
fill 272 245 249 272 246 249 minecraft:gray_concrete
fill 273 245 242 273 246 242 minecraft:gray_concrete
fill 273 245 244 273 246 244 minecraft:gray_concrete
fill 273 245 246 273 246 246 minecraft:gray_concrete
fill 273 245 248 273 246 248 minecraft:gray_concrete
fill 274 245 241 274 246 241 minecraft:gray_concrete
fill 274 245 243 274 246 243 minecraft:gray_concrete
schedule function dropper:buildpart/53_7 1t
