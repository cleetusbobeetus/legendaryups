setblock 1 240 392 minecraft:gray_concrete
setblock 1 240 402 minecraft:gray_concrete
setblock 3 240 410 minecraft:gray_concrete
setblock 7 240 370 minecraft:gray_concrete
setblock 8 240 395 minecraft:black_concrete
setblock 8 240 399 minecraft:black_concrete
fill 9 240 394 10 240 394 minecraft:black_concrete
fill 10 240 401 12 240 401 minecraft:black_concrete
setblock 13 240 394 minecraft:black_concrete
setblock 13 240 410 minecraft:gray_concrete
setblock 14 240 395 minecraft:black_concrete
setblock 14 240 400 minecraft:black_concrete
fill 15 240 397 15 240 398 minecraft:black_concrete
setblock 17 240 370 minecraft:gray_concrete
setblock 23 240 410 minecraft:gray_concrete
setblock 27 240 370 minecraft:gray_concrete
setblock 33 240 410 minecraft:gray_concrete
setblock 37 240 370 minecraft:gray_concrete
setblock 41 240 376 minecraft:gray_concrete
setblock 41 240 386 minecraft:gray_concrete
setblock 41 240 396 minecraft:gray_concrete
setblock 41 240 406 minecraft:gray_concrete
fill 10 241 398 10 244 398 minecraft:gray_concrete
fill 11 241 396 11 244 396 minecraft:gray_concrete
fill 13 241 398 13 245 398 minecraft:gray_concrete
setblock 36 241 396 minecraft:gray_concrete
setblock 36 241 398 minecraft:gray_concrete
setblock 38 241 396 minecraft:gray_concrete
setblock 38 241 398 minecraft:gray_concrete
fill 1 243 374 1 243 377 minecraft:gray_concrete
fill 1 243 384 1 243 387 minecraft:gray_concrete
fill 1 243 394 1 243 397 minecraft:gray_concrete
fill 1 243 404 1 243 407 minecraft:gray_concrete
fill 2 243 370 5 243 370 minecraft:gray_concrete
fill 5 243 410 8 243 410 minecraft:gray_concrete
fill 12 243 370 15 243 370 minecraft:gray_concrete
fill 15 243 410 18 243 410 minecraft:gray_concrete
fill 22 243 370 25 243 370 minecraft:gray_concrete
fill 25 243 410 28 243 410 minecraft:gray_concrete
fill 32 243 370 35 243 370 minecraft:gray_concrete
fill 35 243 406 35 243 408 minecraft:gray_concrete
fill 35 243 410 38 243 410 minecraft:gray_concrete
fill 36 243 406 37 243 406 minecraft:gray_concrete
fill 36 243 408 37 243 408 minecraft:gray_concrete
setblock 37 243 407 minecraft:gray_concrete
fill 39 243 397 40 244 397 minecraft:iron_block
fill 41 243 371 41 243 374 minecraft:gray_concrete
fill 41 243 381 41 243 384 minecraft:gray_concrete
fill 41 243 391 41 243 394 minecraft:gray_concrete
fill 41 243 401 41 243 404 minecraft:gray_concrete
fill 3 244 388 3 245 388 minecraft:light_blue_stained_glass
setblock 35 244 397 minecraft:sea_lantern
setblock 3 245 372 minecraft:light[level=14]
setblock 3 245 380 minecraft:light[level=14]
setblock 3 245 396 minecraft:light[level=14]
setblock 3 245 404 minecraft:light[level=14]
setblock 11 245 372 minecraft:light[level=14]
setblock 11 245 380 minecraft:light[level=14]
setblock 11 245 388 minecraft:light[level=14]
setblock 11 245 396 minecraft:light[level=14]
setblock 11 245 404 minecraft:light[level=14]
setblock 19 245 372 minecraft:light[level=14]
setblock 19 245 380 minecraft:light[level=14]
setblock 19 245 388 minecraft:light[level=14]
setblock 19 245 396 minecraft:light[level=14]
setblock 19 245 404 minecraft:light[level=14]
setblock 27 245 380 minecraft:light[level=14]
setblock 27 245 388 minecraft:light[level=14]
setblock 27 245 396 minecraft:light[level=14]
setblock 27 245 404 minecraft:light[level=14]
setblock 35 245 372 minecraft:light[level=14]
setblock 35 245 380 minecraft:light[level=14]
setblock 35 245 388 minecraft:light[level=14]
setblock 35 245 396 minecraft:light[level=14]
setblock 35 245 404 minecraft:light[level=14]
setblock 1 246 372 minecraft:gray_concrete
setblock 1 246 382 minecraft:gray_concrete
setblock 1 246 392 minecraft:gray_concrete
setblock 1 246 402 minecraft:gray_concrete
setblock 3 246 410 minecraft:gray_concrete
setblock 7 246 370 minecraft:gray_concrete
setblock 13 246 410 minecraft:gray_concrete
setblock 17 246 370 minecraft:gray_concrete
setblock 23 246 410 minecraft:gray_concrete
setblock 27 246 370 minecraft:gray_concrete
setblock 33 246 410 minecraft:gray_concrete
setblock 37 246 370 minecraft:gray_concrete
setblock 41 246 376 minecraft:gray_concrete
setblock 41 246 386 minecraft:gray_concrete
setblock 41 246 396 minecraft:gray_concrete
setblock 41 246 406 minecraft:gray_concrete
fill 0 247 375 0 247 378 minecraft:sea_lantern
fill 0 247 385 0 247 388 minecraft:sea_lantern
fill 0 247 395 0 247 398 minecraft:sea_lantern
fill 0 247 405 0 247 408 minecraft:sea_lantern
fill 3 247 369 6 247 369 minecraft:sea_lantern
fill 4 247 411 7 247 411 minecraft:sea_lantern
fill 13 247 369 16 247 369 minecraft:sea_lantern
fill 14 247 411 17 247 411 minecraft:sea_lantern
fill 23 247 369 26 247 369 minecraft:sea_lantern
fill 24 247 411 27 247 411 minecraft:sea_lantern
fill 33 247 369 36 247 369 minecraft:sea_lantern
fill 34 247 411 37 247 411 minecraft:sea_lantern
fill 42 247 370 42 247 373 minecraft:sea_lantern
fill 42 247 380 42 247 383 minecraft:sea_lantern
fill 42 247 390 42 247 393 minecraft:sea_lantern
fill 42 247 400 42 247 403 minecraft:sea_lantern
setblock 42 247 410 minecraft:sea_lantern
fill 0 248 375 0 255 378 minecraft:blue_concrete
fill 0 248 385 0 255 388 minecraft:blue_concrete
fill 0 248 395 0 255 398 minecraft:blue_concrete
fill 0 248 405 0 255 408 minecraft:blue_concrete
fill 3 248 369 6 255 369 minecraft:blue_concrete
fill 4 248 411 7 255 411 minecraft:blue_concrete
fill 13 248 369 16 255 369 minecraft:blue_concrete
fill 14 248 411 17 255 411 minecraft:blue_concrete
fill 23 248 369 26 255 369 minecraft:blue_concrete
fill 24 248 411 27 255 411 minecraft:blue_concrete
fill 33 248 369 36 255 369 minecraft:blue_concrete
fill 34 248 411 37 255 411 minecraft:blue_concrete
fill 42 248 370 42 255 373 minecraft:blue_concrete
fill 42 248 380 42 255 383 minecraft:blue_concrete
fill 42 248 390 42 255 393 minecraft:blue_concrete
fill 42 248 400 42 255 403 minecraft:blue_concrete
fill 42 248 410 42 255 410 minecraft:blue_concrete
fill 35 249 406 35 249 408 minecraft:gray_concrete
setblock 36 249 396 minecraft:gray_concrete
setblock 36 249 398 minecraft:gray_concrete
fill 36 249 406 37 249 406 minecraft:gray_concrete
fill 36 249 408 37 249 408 minecraft:gray_concrete
setblock 37 249 407 minecraft:gray_concrete
setblock 38 249 396 minecraft:gray_concrete
setblock 38 249 398 minecraft:gray_concrete
setblock 1 252 372 minecraft:gray_concrete
fill 1 252 374 1 252 377 minecraft:gray_concrete
setblock 1 252 382 minecraft:gray_concrete
fill 1 252 384 1 252 387 minecraft:gray_concrete
setblock 1 252 392 minecraft:gray_concrete
fill 1 252 394 1 252 397 minecraft:gray_concrete
setblock 1 252 402 minecraft:gray_concrete
fill 1 252 404 1 252 407 minecraft:gray_concrete
fill 2 252 370 5 252 370 minecraft:gray_concrete
setblock 3 252 410 minecraft:gray_concrete
fill 5 252 410 8 252 410 minecraft:gray_concrete
setblock 7 252 370 minecraft:gray_concrete
fill 12 252 370 15 252 370 minecraft:gray_concrete
setblock 13 252 410 minecraft:gray_concrete
fill 15 252 410 18 252 410 minecraft:gray_concrete
setblock 17 252 370 minecraft:gray_concrete
fill 22 252 370 25 252 370 minecraft:gray_concrete
setblock 23 252 410 minecraft:gray_concrete
fill 25 252 410 28 252 410 minecraft:gray_concrete
setblock 27 252 370 minecraft:gray_concrete
fill 32 252 370 35 252 370 minecraft:gray_concrete
setblock 33 252 410 minecraft:gray_concrete
fill 35 252 410 38 252 410 minecraft:gray_concrete
setblock 37 252 370 minecraft:gray_concrete
fill 41 252 371 41 252 374 minecraft:gray_concrete
setblock 41 252 376 minecraft:gray_concrete
fill 41 252 381 41 252 384 minecraft:gray_concrete
setblock 41 252 386 minecraft:gray_concrete
fill 41 252 391 41 252 394 minecraft:gray_concrete
setblock 41 252 396 minecraft:gray_concrete
fill 41 252 401 41 252 404 minecraft:gray_concrete
setblock 41 252 406 minecraft:gray_concrete
setblock 3 253 372 minecraft:light[level=14]
setblock 3 253 380 minecraft:light[level=14]
setblock 3 253 388 minecraft:light[level=14]
setblock 3 253 396 minecraft:light[level=14]
setblock 3 253 404 minecraft:light[level=14]
setblock 11 253 372 minecraft:light[level=14]
setblock 11 253 380 minecraft:light[level=14]
setblock 11 253 388 minecraft:light[level=14]
setblock 11 253 396 minecraft:light[level=14]
setblock 11 253 404 minecraft:light[level=14]
setblock 19 253 372 minecraft:light[level=14]
setblock 19 253 380 minecraft:light[level=14]
setblock 19 253 388 minecraft:light[level=14]
setblock 19 253 396 minecraft:light[level=14]
setblock 19 253 404 minecraft:light[level=14]
setblock 27 253 372 minecraft:light[level=14]
setblock 27 253 380 minecraft:light[level=14]
setblock 27 253 388 minecraft:light[level=14]
setblock 27 253 396 minecraft:light[level=14]
setblock 27 253 404 minecraft:light[level=14]
setblock 35 253 372 minecraft:light[level=14]
setblock 35 253 380 minecraft:light[level=14]
setblock 35 253 388 minecraft:light[level=14]
setblock 35 253 396 minecraft:light[level=14]
setblock 35 253 404 minecraft:light[level=14]
fill 35 255 406 35 255 408 minecraft:gray_concrete
fill 36 255 406 37 255 406 minecraft:gray_concrete
fill 36 255 408 37 255 408 minecraft:gray_concrete
setblock 37 255 407 minecraft:gray_concrete
fill 0 256 375 0 256 378 minecraft:sea_lantern
fill 0 256 385 0 256 388 minecraft:sea_lantern
fill 0 256 395 0 256 398 minecraft:sea_lantern
fill 0 256 405 0 256 408 minecraft:sea_lantern
fill 3 256 369 6 256 369 minecraft:sea_lantern
fill 4 256 411 7 256 411 minecraft:sea_lantern
fill 13 256 369 16 256 369 minecraft:sea_lantern
fill 14 256 411 17 256 411 minecraft:sea_lantern
fill 23 256 369 26 256 369 minecraft:sea_lantern
fill 24 256 411 27 256 411 minecraft:sea_lantern
fill 33 256 369 36 256 369 minecraft:sea_lantern
fill 34 256 411 37 256 411 minecraft:sea_lantern
fill 42 256 370 42 256 373 minecraft:sea_lantern
fill 42 256 380 42 256 383 minecraft:sea_lantern
fill 42 256 390 42 256 393 minecraft:sea_lantern
fill 42 256 400 42 256 403 minecraft:sea_lantern
setblock 42 256 410 minecraft:sea_lantern
fill 0 257 375 0 264 378 minecraft:blue_concrete
fill 0 257 385 0 264 388 minecraft:blue_concrete
fill 0 257 395 0 264 398 minecraft:blue_concrete
fill 0 257 405 0 264 408 minecraft:blue_concrete
fill 3 257 369 6 264 369 minecraft:blue_concrete
fill 4 257 411 7 264 411 minecraft:blue_concrete
fill 13 257 369 16 264 369 minecraft:blue_concrete
fill 14 257 411 17 264 411 minecraft:blue_concrete
fill 23 257 369 26 264 369 minecraft:blue_concrete
fill 24 257 411 27 264 411 minecraft:blue_concrete
fill 33 257 369 36 264 369 minecraft:blue_concrete
fill 34 257 411 37 264 411 minecraft:blue_concrete
setblock 36 257 396 minecraft:gray_concrete
setblock 36 257 398 minecraft:gray_concrete
setblock 38 257 396 minecraft:gray_concrete
setblock 38 257 398 minecraft:gray_concrete
fill 42 257 370 42 264 373 minecraft:blue_concrete
fill 42 257 380 42 264 383 minecraft:blue_concrete
fill 42 257 390 42 264 393 minecraft:blue_concrete
fill 42 257 400 42 264 403 minecraft:blue_concrete
fill 42 257 410 42 264 410 minecraft:blue_concrete
setblock 1 258 372 minecraft:gray_concrete
setblock 1 258 382 minecraft:gray_concrete
setblock 1 258 392 minecraft:gray_concrete
setblock 1 258 402 minecraft:gray_concrete
setblock 3 258 410 minecraft:gray_concrete
setblock 7 258 370 minecraft:gray_concrete
setblock 13 258 410 minecraft:gray_concrete
setblock 17 258 370 minecraft:gray_concrete
setblock 23 258 410 minecraft:gray_concrete
setblock 27 258 370 minecraft:gray_concrete
setblock 33 258 410 minecraft:gray_concrete
setblock 37 258 370 minecraft:gray_concrete
setblock 41 258 376 minecraft:gray_concrete
setblock 41 258 386 minecraft:gray_concrete
setblock 41 258 396 minecraft:gray_concrete
setblock 41 258 406 minecraft:gray_concrete
fill 1 261 374 1 261 377 minecraft:gray_concrete
fill 1 261 384 1 261 387 minecraft:gray_concrete
fill 1 261 394 1 261 397 minecraft:gray_concrete
fill 1 261 404 1 261 407 minecraft:gray_concrete
fill 2 261 370 5 261 370 minecraft:gray_concrete
setblock 3 261 372 minecraft:light[level=14]
setblock 3 261 380 minecraft:light[level=14]
setblock 3 261 388 minecraft:light[level=14]
setblock 3 261 396 minecraft:light[level=14]
setblock 3 261 404 minecraft:light[level=14]
fill 5 261 410 8 261 410 minecraft:gray_concrete
setblock 11 261 372 minecraft:light[level=14]
setblock 11 261 380 minecraft:light[level=14]
setblock 11 261 388 minecraft:light[level=14]
setblock 11 261 396 minecraft:light[level=14]
setblock 11 261 404 minecraft:light[level=14]
fill 12 261 370 15 261 370 minecraft:gray_concrete
fill 15 261 410 18 261 410 minecraft:gray_concrete
fill 16 261 374 17 262 375 minecraft:light_blue_stained_glass
setblock 19 261 372 minecraft:light[level=14]
setblock 19 261 380 minecraft:light[level=14]
setblock 19 261 388 minecraft:light[level=14]
setblock 19 261 396 minecraft:light[level=14]
setblock 19 261 404 minecraft:light[level=14]
fill 22 261 370 25 261 370 minecraft:gray_concrete
fill 25 261 410 28 261 410 minecraft:gray_concrete
setblock 27 261 372 minecraft:light[level=14]
setblock 27 261 380 minecraft:light[level=14]
setblock 27 261 388 minecraft:light[level=14]
setblock 27 261 396 minecraft:light[level=14]
setblock 27 261 404 minecraft:light[level=14]
fill 29 261 403 31 262 403 minecraft:light_blue_stained_glass
fill 30 261 402 31 262 402 minecraft:light_blue_stained_glass
fill 32 261 370 35 261 370 minecraft:gray_concrete
setblock 35 261 372 minecraft:light[level=14]
setblock 35 261 380 minecraft:light[level=14]
setblock 35 261 388 minecraft:light[level=14]
setblock 35 261 396 minecraft:light[level=14]
setblock 35 261 404 minecraft:light[level=14]
fill 35 261 406 35 261 408 minecraft:gray_concrete
fill 35 261 410 38 261 410 minecraft:gray_concrete
fill 36 261 406 37 261 406 minecraft:gray_concrete
fill 36 261 408 37 261 408 minecraft:gray_concrete
setblock 37 261 407 minecraft:gray_concrete
fill 41 261 371 41 261 374 minecraft:gray_concrete
fill 41 261 381 41 261 384 minecraft:gray_concrete
fill 41 261 391 41 261 394 minecraft:gray_concrete
fill 41 261 401 41 261 404 minecraft:gray_concrete
setblock 1 264 372 minecraft:gray_concrete
setblock 1 264 382 minecraft:gray_concrete
setblock 1 264 392 minecraft:gray_concrete
setblock 1 264 402 minecraft:gray_concrete
setblock 3 264 410 minecraft:gray_concrete
setblock 7 264 370 minecraft:gray_concrete
setblock 13 264 410 minecraft:gray_concrete
setblock 17 264 370 minecraft:gray_concrete
setblock 23 264 410 minecraft:gray_concrete
setblock 27 264 370 minecraft:gray_concrete
setblock 33 264 410 minecraft:gray_concrete
setblock 37 264 370 minecraft:gray_concrete
setblock 41 264 376 minecraft:gray_concrete
setblock 41 264 386 minecraft:gray_concrete
setblock 41 264 396 minecraft:gray_concrete
setblock 41 264 406 minecraft:gray_concrete
fill 0 265 375 0 265 378 minecraft:sea_lantern
fill 0 265 385 0 265 388 minecraft:sea_lantern
fill 0 265 395 0 265 398 minecraft:sea_lantern
fill 0 265 405 0 265 408 minecraft:sea_lantern
fill 3 265 369 6 265 369 minecraft:sea_lantern
fill 4 265 411 7 265 411 minecraft:sea_lantern
fill 13 265 369 16 265 369 minecraft:sea_lantern
fill 14 265 411 17 265 411 minecraft:sea_lantern
fill 23 265 369 26 265 369 minecraft:sea_lantern
fill 24 265 411 27 265 411 minecraft:sea_lantern
fill 33 265 369 36 265 369 minecraft:sea_lantern
fill 34 265 411 37 265 411 minecraft:sea_lantern
setblock 36 265 396 minecraft:gray_concrete
setblock 36 265 398 minecraft:gray_concrete
setblock 38 265 396 minecraft:gray_concrete
setblock 38 265 398 minecraft:gray_concrete
fill 42 265 370 42 265 373 minecraft:sea_lantern
fill 42 265 380 42 265 383 minecraft:sea_lantern
fill 42 265 390 42 265 393 minecraft:sea_lantern
fill 42 265 400 42 265 403 minecraft:sea_lantern
setblock 42 265 410 minecraft:sea_lantern
fill 0 266 375 0 282 378 minecraft:blue_concrete
fill 0 266 385 0 282 388 minecraft:blue_concrete
fill 0 266 395 0 282 398 minecraft:blue_concrete
fill 0 266 405 0 282 408 minecraft:blue_concrete
fill 3 266 369 6 282 369 minecraft:blue_concrete
fill 4 266 411 7 282 411 minecraft:blue_concrete
fill 13 266 369 16 282 369 minecraft:blue_concrete
fill 14 266 411 17 282 411 minecraft:blue_concrete
fill 23 266 369 26 282 369 minecraft:blue_concrete
fill 24 266 411 27 282 411 minecraft:blue_concrete
fill 25 266 396 25 267 398 minecraft:light_blue_stained_glass
fill 26 266 396 26 267 397 minecraft:light_blue_stained_glass
fill 33 266 369 36 282 369 minecraft:blue_concrete
fill 34 266 411 37 282 411 minecraft:blue_concrete
fill 42 266 370 42 282 373 minecraft:blue_concrete
fill 42 266 380 42 282 383 minecraft:blue_concrete
fill 42 266 390 42 282 393 minecraft:blue_concrete
fill 42 266 400 42 282 403 minecraft:blue_concrete
fill 42 266 410 42 282 410 minecraft:blue_concrete
fill 35 267 406 35 267 408 minecraft:gray_concrete
fill 36 267 406 37 267 406 minecraft:gray_concrete
fill 36 267 408 37 267 408 minecraft:gray_concrete
setblock 37 267 407 minecraft:gray_concrete
fill 20 268 378 21 269 379 minecraft:white_stained_glass
fill 21 268 380 21 269 380 minecraft:white_stained_glass
setblock 3 269 372 minecraft:light[level=14]
setblock 3 269 380 minecraft:light[level=14]
setblock 3 269 388 minecraft:light[level=14]
setblock 3 269 396 minecraft:light[level=14]
setblock 3 269 404 minecraft:light[level=14]
setblock 11 269 372 minecraft:light[level=14]
setblock 11 269 380 minecraft:light[level=14]
setblock 11 269 388 minecraft:light[level=14]
setblock 11 269 396 minecraft:light[level=14]
setblock 11 269 404 minecraft:light[level=14]
setblock 19 269 372 minecraft:light[level=14]
setblock 19 269 380 minecraft:light[level=14]
setblock 19 269 396 minecraft:light[level=14]
setblock 19 269 404 minecraft:light[level=14]
setblock 27 269 372 minecraft:light[level=14]
setblock 27 269 380 minecraft:light[level=14]
setblock 27 269 388 minecraft:light[level=14]
setblock 27 269 396 minecraft:light[level=14]
setblock 27 269 404 minecraft:light[level=14]
setblock 35 269 372 minecraft:light[level=14]
setblock 35 269 380 minecraft:light[level=14]
setblock 35 269 388 minecraft:light[level=14]
setblock 35 269 396 minecraft:light[level=14]
setblock 35 269 404 minecraft:light[level=14]
setblock 1 270 372 minecraft:gray_concrete
fill 1 270 374 1 270 377 minecraft:gray_concrete
setblock 1 270 382 minecraft:gray_concrete
fill 1 270 384 1 270 387 minecraft:gray_concrete
setblock 1 270 392 minecraft:gray_concrete
fill 1 270 394 1 270 397 minecraft:gray_concrete
setblock 1 270 402 minecraft:gray_concrete
fill 1 270 404 1 270 407 minecraft:gray_concrete
fill 2 270 370 5 270 370 minecraft:gray_concrete
setblock 3 270 410 minecraft:gray_concrete
fill 5 270 410 8 270 410 minecraft:gray_concrete
setblock 7 270 370 minecraft:gray_concrete
fill 12 270 370 15 270 370 minecraft:gray_concrete
setblock 13 270 410 minecraft:gray_concrete
fill 15 270 410 18 270 410 minecraft:gray_concrete
setblock 17 270 370 minecraft:gray_concrete
fill 22 270 370 25 270 370 minecraft:gray_concrete
setblock 23 270 410 minecraft:gray_concrete
fill 25 270 410 28 270 410 minecraft:gray_concrete
setblock 27 270 370 minecraft:gray_concrete
fill 32 270 370 35 270 370 minecraft:gray_concrete
setblock 33 270 410 minecraft:gray_concrete
fill 35 270 410 38 270 410 minecraft:gray_concrete
setblock 37 270 370 minecraft:gray_concrete
fill 41 270 371 41 270 374 minecraft:gray_concrete
setblock 41 270 376 minecraft:gray_concrete
fill 41 270 381 41 270 384 minecraft:gray_concrete
setblock 41 270 386 minecraft:gray_concrete
fill 41 270 391 41 270 394 minecraft:gray_concrete
setblock 41 270 396 minecraft:gray_concrete
fill 41 270 401 41 270 404 minecraft:gray_concrete
setblock 41 270 406 minecraft:gray_concrete
setblock 3 277 372 minecraft:light[level=14]
setblock 3 277 380 minecraft:light[level=14]
setblock 3 277 388 minecraft:light[level=14]
setblock 3 277 396 minecraft:light[level=14]
setblock 3 277 404 minecraft:light[level=14]
setblock 11 277 372 minecraft:light[level=14]
setblock 11 277 380 minecraft:light[level=14]
setblock 11 277 388 minecraft:light[level=14]
setblock 11 277 396 minecraft:light[level=14]
setblock 11 277 404 minecraft:light[level=14]
fill 14 277 386 14 279 387 minecraft:gray_concrete
fill 14 277 388 14 279 388 minecraft:black_concrete
fill 14 277 389 14 279 390 minecraft:gray_concrete
fill 15 277 384 15 279 384 minecraft:black_concrete
fill 15 277 385 15 279 386 minecraft:gray_concrete
fill 15 277 387 15 279 387 minecraft:black_concrete
fill 15 277 388 15 279 389 minecraft:gray_concrete
fill 15 277 390 15 279 390 minecraft:black_concrete
fill 15 277 391 15 279 392 minecraft:gray_concrete
fill 16 277 383 16 279 383 minecraft:black_concrete
fill 16 277 384 16 279 385 minecraft:gray_concrete
fill 16 277 386 16 279 386 minecraft:black_concrete
fill 16 277 387 16 278 388 minecraft:gray_concrete
fill 16 277 389 16 278 389 minecraft:black_concrete
fill 16 277 390 16 279 391 minecraft:gray_concrete
fill 16 277 392 16 279 392 minecraft:black_concrete
fill 16 277 393 17 279 393 minecraft:gray_concrete
fill 17 277 383 17 279 384 minecraft:gray_concrete
fill 17 277 385 17 278 385 minecraft:black_concrete
fill 17 277 386 17 278 387 minecraft:gray_concrete
fill 17 277 389 17 278 390 minecraft:gray_concrete
fill 17 277 391 17 278 391 minecraft:black_concrete
fill 17 277 392 18 279 392 minecraft:gray_concrete
fill 18 277 382 18 279 383 minecraft:gray_concrete
fill 18 277 384 18 279 384 minecraft:black_concrete
fill 18 277 385 19 278 385 minecraft:gray_concrete
fill 18 277 391 19 278 391 minecraft:gray_concrete
fill 18 277 393 18 279 393 minecraft:black_concrete
fill 18 277 394 19 279 394 minecraft:gray_concrete
setblock 19 277 372 minecraft:light[level=14]
setblock 19 277 380 minecraft:light[level=14]
fill 19 277 382 19 279 382 minecraft:gray_concrete
fill 19 277 383 19 279 383 minecraft:black_concrete
fill 19 277 384 20 278 384 minecraft:gray_concrete
fill 19 277 392 19 278 392 minecraft:black_concrete
fill 19 277 393 20 279 393 minecraft:gray_concrete
setblock 19 277 396 minecraft:light[level=14]
setblock 19 277 404 minecraft:light[level=14]
fill 20 277 382 20 279 382 minecraft:black_concrete
fill 20 277 383 21 279 383 minecraft:gray_concrete
fill 20 277 392 21 278 392 minecraft:gray_concrete
fill 20 277 394 20 279 394 minecraft:black_concrete
fill 21 277 382 22 279 382 minecraft:gray_concrete
fill 21 277 384 21 278 384 minecraft:black_concrete
fill 21 277 385 22 278 385 minecraft:gray_concrete
fill 21 277 391 22 278 391 minecraft:gray_concrete
fill 21 277 393 21 279 393 minecraft:black_concrete
fill 21 277 394 22 279 394 minecraft:gray_concrete
fill 22 277 383 22 279 383 minecraft:black_concrete
fill 22 277 384 23 279 384 minecraft:gray_concrete
fill 22 277 392 22 279 392 minecraft:black_concrete
fill 22 277 393 23 279 393 minecraft:gray_concrete
fill 23 277 383 24 279 383 minecraft:gray_concrete
fill 23 277 385 23 278 385 minecraft:black_concrete
fill 23 277 386 23 278 387 minecraft:gray_concrete
fill 23 277 389 23 278 390 minecraft:gray_concrete
fill 23 277 391 23 278 391 minecraft:black_concrete
fill 23 277 392 24 279 392 minecraft:gray_concrete
fill 24 277 384 24 279 384 minecraft:black_concrete
fill 24 277 385 24 279 386 minecraft:gray_concrete
fill 24 277 387 24 278 387 minecraft:black_concrete
fill 24 277 388 24 278 389 minecraft:gray_concrete
fill 24 277 390 24 279 390 minecraft:black_concrete
fill 24 277 391 25 279 391 minecraft:gray_concrete
fill 24 277 393 24 279 393 minecraft:black_concrete
fill 25 277 384 25 279 385 minecraft:gray_concrete
fill 25 277 386 25 279 386 minecraft:black_concrete
fill 25 277 387 25 279 388 minecraft:gray_concrete
fill 25 277 389 25 279 389 minecraft:black_concrete
fill 25 277 390 26 279 390 minecraft:gray_concrete
fill 25 277 392 25 279 392 minecraft:black_concrete
fill 26 277 386 26 279 387 minecraft:gray_concrete
fill 26 277 388 26 279 388 minecraft:black_concrete
fill 26 277 389 26 279 389 minecraft:gray_concrete
setblock 27 277 372 minecraft:light[level=14]
setblock 27 277 380 minecraft:light[level=14]
setblock 27 277 388 minecraft:light[level=14]
setblock 27 277 396 minecraft:light[level=14]
setblock 27 277 404 minecraft:light[level=14]
setblock 35 277 372 minecraft:light[level=14]
setblock 35 277 380 minecraft:light[level=14]
setblock 35 277 388 minecraft:light[level=14]
setblock 35 277 396 minecraft:light[level=14]
setblock 35 277 404 minecraft:light[level=14]
fill 12 278 387 13 280 389 minecraft:yellow_concrete
fill 13 278 384 13 280 386 minecraft:yellow_concrete
fill 13 278 390 13 280 392 minecraft:yellow_concrete
fill 14 278 383 14 280 385 minecraft:yellow_concrete
fill 14 278 391 14 280 393 minecraft:yellow_concrete
fill 15 278 382 15 280 383 minecraft:yellow_concrete
fill 15 278 393 15 280 394 minecraft:yellow_concrete
fill 16 278 381 17 280 382 minecraft:yellow_concrete
fill 16 278 394 17 280 395 minecraft:yellow_concrete
fill 18 278 381 24 280 381 minecraft:yellow_concrete
fill 18 278 395 24 280 395 minecraft:yellow_concrete
fill 19 278 380 21 280 380 minecraft:yellow_concrete
fill 19 278 396 21 280 396 minecraft:yellow_concrete
fill 23 278 382 25 280 382 minecraft:yellow_concrete
fill 23 278 394 25 280 394 minecraft:yellow_concrete
fill 25 278 383 26 280 383 minecraft:yellow_concrete
fill 25 278 393 26 280 393 minecraft:yellow_concrete
fill 26 278 384 27 280 385 minecraft:yellow_concrete
fill 26 278 391 27 280 392 minecraft:yellow_concrete
fill 27 278 386 27 280 390 minecraft:yellow_concrete
fill 28 278 387 28 280 389 minecraft:yellow_concrete
fill 1 279 370 1 279 371 minecraft:blue_terracotta
setblock 1 279 372 minecraft:light_blue_stained_glass
fill 1 279 373 1 279 375 minecraft:blue_terracotta
setblock 1 279 376 minecraft:light_blue_stained_glass
fill 1 279 377 1 279 379 minecraft:blue_terracotta
setblock 1 279 380 minecraft:light_blue_stained_glass
fill 1 279 381 1 279 383 minecraft:blue_terracotta
setblock 1 279 384 minecraft:light_blue_stained_glass
fill 1 279 385 1 279 387 minecraft:blue_terracotta
setblock 1 279 388 minecraft:light_blue_stained_glass
fill 1 279 389 1 279 391 minecraft:blue_terracotta
setblock 1 279 392 minecraft:light_blue_stained_glass
fill 1 279 393 1 279 395 minecraft:blue_terracotta
setblock 1 279 396 minecraft:light_blue_stained_glass
fill 1 279 397 1 279 399 minecraft:blue_terracotta
setblock 1 279 400 minecraft:light_blue_stained_glass
fill 1 279 401 1 279 403 minecraft:blue_terracotta
setblock 1 279 404 minecraft:light_blue_stained_glass
fill 1 279 405 1 279 407 minecraft:blue_terracotta
setblock 1 279 408 minecraft:light_blue_stained_glass
fill 1 279 409 2 279 410 minecraft:blue_terracotta
setblock 2 279 370 minecraft:blue_terracotta
setblock 2 279 371 minecraft:light_blue_stained_glass
fill 2 279 372 2 279 374 minecraft:blue_terracotta
setblock 2 279 375 minecraft:light_blue_stained_glass
fill 2 279 376 2 279 378 minecraft:blue_terracotta
setblock 2 279 379 minecraft:light_blue_stained_glass
fill 2 279 380 2 279 382 minecraft:blue_terracotta
setblock 2 279 383 minecraft:light_blue_stained_glass
fill 2 279 384 2 279 386 minecraft:blue_terracotta
setblock 2 279 387 minecraft:light_blue_stained_glass
fill 2 279 388 2 279 390 minecraft:blue_terracotta
setblock 2 279 391 minecraft:light_blue_stained_glass
fill 2 279 392 2 279 394 minecraft:blue_terracotta
setblock 2 279 395 minecraft:light_blue_stained_glass
fill 2 279 396 2 279 398 minecraft:blue_terracotta
setblock 2 279 399 minecraft:light_blue_stained_glass
fill 2 279 400 2 279 402 minecraft:blue_terracotta
setblock 2 279 403 minecraft:light_blue_stained_glass
fill 2 279 404 2 279 406 minecraft:blue_terracotta
setblock 2 279 407 minecraft:light_blue_stained_glass
fill 2 279 408 4 279 408 minecraft:blue_terracotta
setblock 3 279 370 minecraft:light_blue_stained_glass
fill 3 279 371 3 279 373 minecraft:blue_terracotta
setblock 3 279 374 minecraft:light_blue_stained_glass
fill 3 279 375 3 279 377 minecraft:blue_terracotta
setblock 3 279 378 minecraft:light_blue_stained_glass
fill 3 279 379 3 279 381 minecraft:blue_terracotta
setblock 3 279 382 minecraft:light_blue_stained_glass
fill 3 279 383 3 279 385 minecraft:blue_terracotta
setblock 3 279 386 minecraft:light_blue_stained_glass
fill 3 279 387 3 279 389 minecraft:blue_terracotta
setblock 3 279 390 minecraft:light_blue_stained_glass
fill 3 279 391 3 279 393 minecraft:blue_terracotta
setblock 3 279 394 minecraft:light_blue_stained_glass
fill 3 279 395 3 279 397 minecraft:blue_terracotta
setblock 3 279 398 minecraft:light_blue_stained_glass
fill 3 279 399 3 279 401 minecraft:blue_terracotta
setblock 3 279 402 minecraft:light_blue_stained_glass
fill 3 279 403 3 279 405 minecraft:blue_terracotta
setblock 3 279 406 minecraft:light_blue_stained_glass
fill 3 279 407 5 279 407 minecraft:blue_terracotta
setblock 3 279 409 minecraft:blue_terracotta
setblock 3 279 410 minecraft:light_blue_stained_glass
fill 4 279 370 4 279 372 minecraft:blue_terracotta
setblock 4 279 373 minecraft:light_blue_stained_glass
fill 4 279 374 4 279 376 minecraft:blue_terracotta
setblock 4 279 377 minecraft:light_blue_stained_glass
fill 4 279 378 4 279 380 minecraft:blue_terracotta
setblock 4 279 381 minecraft:light_blue_stained_glass
fill 4 279 382 4 279 384 minecraft:blue_terracotta
setblock 4 279 385 minecraft:light_blue_stained_glass
fill 4 279 386 4 279 388 minecraft:blue_terracotta
setblock 4 279 389 minecraft:light_blue_stained_glass
fill 4 279 390 4 279 392 minecraft:blue_terracotta
setblock 4 279 393 minecraft:light_blue_stained_glass
fill 4 279 394 4 279 396 minecraft:blue_terracotta
setblock 4 279 397 minecraft:light_blue_stained_glass
fill 4 279 398 4 279 400 minecraft:blue_terracotta
setblock 4 279 401 minecraft:light_blue_stained_glass
fill 4 279 402 4 279 404 minecraft:blue_terracotta
setblock 4 279 405 minecraft:light_blue_stained_glass
fill 4 279 406 6 279 406 minecraft:blue_terracotta
setblock 4 279 409 minecraft:light_blue_stained_glass
fill 4 279 410 6 279 410 minecraft:blue_terracotta
fill 5 279 370 5 279 371 minecraft:blue_terracotta
setblock 5 279 372 minecraft:light_blue_stained_glass
fill 5 279 373 5 279 375 minecraft:blue_terracotta
setblock 5 279 376 minecraft:light_blue_stained_glass
fill 5 279 377 5 279 379 minecraft:blue_terracotta
setblock 5 279 380 minecraft:light_blue_stained_glass
fill 5 279 381 5 279 383 minecraft:blue_terracotta
setblock 5 279 384 minecraft:light_blue_stained_glass
fill 5 279 385 5 279 387 minecraft:blue_terracotta
setblock 5 279 388 minecraft:light_blue_stained_glass
fill 5 279 389 5 279 391 minecraft:blue_terracotta
setblock 5 279 392 minecraft:light_blue_stained_glass
fill 5 279 393 5 279 395 minecraft:blue_terracotta
setblock 5 279 396 minecraft:light_blue_stained_glass
fill 5 279 397 5 279 399 minecraft:blue_terracotta
setblock 5 279 400 minecraft:light_blue_stained_glass
fill 5 279 401 5 279 403 minecraft:blue_terracotta
setblock 5 279 404 minecraft:light_blue_stained_glass
fill 5 279 405 7 279 405 minecraft:blue_terracotta
setblock 5 279 408 minecraft:light_blue_stained_glass
fill 5 279 409 7 279 409 minecraft:blue_terracotta
setblock 6 279 370 minecraft:blue_terracotta
setblock 6 279 371 minecraft:light_blue_stained_glass
fill 6 279 372 6 279 374 minecraft:blue_terracotta
setblock 6 279 375 minecraft:light_blue_stained_glass
fill 6 279 376 6 279 378 minecraft:blue_terracotta
setblock 6 279 379 minecraft:light_blue_stained_glass
fill 6 279 380 6 279 382 minecraft:blue_terracotta
setblock 6 279 383 minecraft:light_blue_stained_glass
fill 6 279 384 6 279 386 minecraft:blue_terracotta
setblock 6 279 387 minecraft:light_blue_stained_glass
fill 6 279 388 6 279 390 minecraft:blue_terracotta
setblock 6 279 391 minecraft:light_blue_stained_glass
fill 6 279 392 6 279 394 minecraft:blue_terracotta
setblock 6 279 395 minecraft:light_blue_stained_glass
fill 6 279 396 6 279 398 minecraft:blue_terracotta
setblock 6 279 399 minecraft:light_blue_stained_glass
fill 6 279 400 6 279 402 minecraft:blue_terracotta
setblock 6 279 403 minecraft:light_blue_stained_glass
fill 6 279 404 8 279 404 minecraft:blue_terracotta
setblock 6 279 407 minecraft:light_blue_stained_glass
fill 6 279 408 8 279 408 minecraft:blue_terracotta
setblock 7 279 370 minecraft:light_blue_stained_glass
fill 7 279 371 7 279 373 minecraft:blue_terracotta
setblock 7 279 374 minecraft:light_blue_stained_glass
fill 7 279 375 7 279 377 minecraft:blue_terracotta
setblock 7 279 378 minecraft:light_blue_stained_glass
fill 7 279 379 7 279 381 minecraft:blue_terracotta
setblock 7 279 382 minecraft:light_blue_stained_glass
fill 7 279 383 7 279 385 minecraft:blue_terracotta
setblock 7 279 386 minecraft:light_blue_stained_glass
fill 7 279 387 7 279 389 minecraft:blue_terracotta
setblock 7 279 390 minecraft:light_blue_stained_glass
fill 7 279 391 7 279 393 minecraft:blue_terracotta
setblock 7 279 394 minecraft:light_blue_stained_glass
fill 7 279 395 7 279 397 minecraft:blue_terracotta
setblock 7 279 398 minecraft:light_blue_stained_glass
fill 7 279 399 7 279 401 minecraft:blue_terracotta
setblock 7 279 402 minecraft:light_blue_stained_glass
fill 7 279 403 9 279 403 minecraft:blue_terracotta
setblock 7 279 406 minecraft:light_blue_stained_glass
fill 7 279 407 9 279 407 minecraft:blue_terracotta
setblock 7 279 410 minecraft:light_blue_stained_glass
fill 8 279 370 8 279 372 minecraft:blue_terracotta
setblock 8 279 373 minecraft:light_blue_stained_glass
fill 8 279 374 8 279 376 minecraft:blue_terracotta
setblock 8 279 377 minecraft:light_blue_stained_glass
fill 8 279 378 8 279 380 minecraft:blue_terracotta
setblock 8 279 381 minecraft:light_blue_stained_glass
fill 8 279 382 8 279 384 minecraft:blue_terracotta
setblock 8 279 385 minecraft:light_blue_stained_glass
fill 8 279 386 8 279 388 minecraft:blue_terracotta
setblock 8 279 389 minecraft:light_blue_stained_glass
fill 8 279 390 8 279 392 minecraft:blue_terracotta
setblock 8 279 393 minecraft:light_blue_stained_glass
fill 8 279 394 8 279 396 minecraft:blue_terracotta
setblock 8 279 397 minecraft:light_blue_stained_glass
fill 8 279 398 8 279 400 minecraft:blue_terracotta
setblock 8 279 401 minecraft:light_blue_stained_glass
fill 8 279 402 10 279 402 minecraft:blue_terracotta
setblock 8 279 405 minecraft:light_blue_stained_glass
fill 8 279 406 10 279 406 minecraft:blue_terracotta
setblock 8 279 409 minecraft:light_blue_stained_glass
fill 8 279 410 10 279 410 minecraft:blue_terracotta
fill 9 279 370 9 279 371 minecraft:blue_terracotta
setblock 9 279 372 minecraft:light_blue_stained_glass
fill 9 279 373 9 279 375 minecraft:blue_terracotta
setblock 9 279 376 minecraft:light_blue_stained_glass
fill 9 279 377 9 279 379 minecraft:blue_terracotta
setblock 9 279 380 minecraft:light_blue_stained_glass
fill 9 279 381 9 279 383 minecraft:blue_terracotta
setblock 9 279 384 minecraft:light_blue_stained_glass
fill 9 279 385 9 279 387 minecraft:blue_terracotta
setblock 9 279 388 minecraft:light_blue_stained_glass
fill 9 279 389 9 279 391 minecraft:blue_terracotta
setblock 9 279 392 minecraft:light_blue_stained_glass
fill 9 279 393 9 279 395 minecraft:blue_terracotta
setblock 9 279 396 minecraft:light_blue_stained_glass
fill 9 279 397 9 279 399 minecraft:blue_terracotta
setblock 9 279 400 minecraft:light_blue_stained_glass
fill 9 279 401 11 279 401 minecraft:blue_terracotta
setblock 9 279 404 minecraft:light_blue_stained_glass
fill 9 279 405 11 279 405 minecraft:blue_terracotta
setblock 9 279 408 minecraft:light_blue_stained_glass
fill 9 279 409 11 279 409 minecraft:blue_terracotta
setblock 10 279 370 minecraft:blue_terracotta
setblock 10 279 371 minecraft:light_blue_stained_glass
fill 10 279 372 10 279 374 minecraft:blue_terracotta
setblock 10 279 375 minecraft:light_blue_stained_glass
fill 10 279 376 10 279 378 minecraft:blue_terracotta
setblock 10 279 379 minecraft:light_blue_stained_glass
fill 10 279 380 10 279 382 minecraft:blue_terracotta
setblock 10 279 383 minecraft:light_blue_stained_glass
fill 10 279 384 10 279 386 minecraft:blue_terracotta
setblock 10 279 387 minecraft:light_blue_stained_glass
fill 10 279 388 10 279 390 minecraft:blue_terracotta
setblock 10 279 391 minecraft:light_blue_stained_glass
fill 10 279 392 10 279 394 minecraft:blue_terracotta
setblock 10 279 395 minecraft:light_blue_stained_glass
fill 10 279 396 10 279 398 minecraft:blue_terracotta
setblock 10 279 399 minecraft:light_blue_stained_glass
fill 10 279 400 12 279 400 minecraft:blue_terracotta
setblock 10 279 403 minecraft:light_blue_stained_glass
fill 10 279 404 12 279 404 minecraft:blue_terracotta
setblock 10 279 407 minecraft:light_blue_stained_glass
fill 10 279 408 12 279 408 minecraft:blue_terracotta
setblock 11 279 370 minecraft:light_blue_stained_glass
fill 11 279 371 11 279 373 minecraft:blue_terracotta
setblock 11 279 374 minecraft:light_blue_stained_glass
fill 11 279 375 11 279 377 minecraft:blue_terracotta
setblock 11 279 378 minecraft:light_blue_stained_glass
fill 11 279 379 11 279 381 minecraft:blue_terracotta
setblock 11 279 382 minecraft:light_blue_stained_glass
fill 11 279 383 11 279 385 minecraft:blue_terracotta
setblock 11 279 386 minecraft:light_blue_stained_glass
fill 11 279 387 11 279 389 minecraft:blue_terracotta
setblock 11 279 390 minecraft:light_blue_stained_glass
fill 11 279 391 11 279 393 minecraft:blue_terracotta
setblock 11 279 394 minecraft:light_blue_stained_glass
fill 11 279 395 11 279 397 minecraft:blue_terracotta
setblock 11 279 398 minecraft:light_blue_stained_glass
fill 11 279 399 13 279 399 minecraft:blue_terracotta
setblock 11 279 402 minecraft:light_blue_stained_glass
fill 11 279 403 13 279 403 minecraft:blue_terracotta
setblock 11 279 406 minecraft:light_blue_stained_glass
fill 11 279 407 13 279 407 minecraft:blue_terracotta
setblock 11 279 410 minecraft:light_blue_stained_glass
fill 12 279 370 12 279 372 minecraft:blue_terracotta
setblock 12 279 373 minecraft:light_blue_stained_glass
fill 12 279 374 12 279 376 minecraft:blue_terracotta
setblock 12 279 377 minecraft:light_blue_stained_glass
fill 12 279 378 12 279 380 minecraft:blue_terracotta
setblock 12 279 381 minecraft:light_blue_stained_glass
fill 12 279 382 12 279 384 minecraft:blue_terracotta
setblock 12 279 385 minecraft:light_blue_stained_glass
setblock 12 279 386 minecraft:yellow_concrete
setblock 12 279 390 minecraft:yellow_concrete
fill 12 279 391 12 279 392 minecraft:blue_terracotta
setblock 12 279 393 minecraft:light_blue_stained_glass
fill 12 279 394 12 279 396 minecraft:blue_terracotta
setblock 12 279 397 minecraft:light_blue_stained_glass
fill 12 279 398 14 279 398 minecraft:blue_terracotta
setblock 12 279 401 minecraft:light_blue_stained_glass
fill 12 279 402 14 279 402 minecraft:blue_terracotta
setblock 12 279 405 minecraft:light_blue_stained_glass
fill 12 279 406 14 279 406 minecraft:blue_terracotta
setblock 12 279 409 minecraft:light_blue_stained_glass
fill 12 279 410 14 279 410 minecraft:blue_terracotta
fill 13 279 370 13 279 371 minecraft:blue_terracotta
setblock 13 279 372 minecraft:light_blue_stained_glass
fill 13 279 373 13 279 375 minecraft:blue_terracotta
setblock 13 279 376 minecraft:light_blue_stained_glass
fill 13 279 377 13 279 379 minecraft:blue_terracotta
setblock 13 279 380 minecraft:light_blue_stained_glass
fill 13 279 381 13 279 383 minecraft:blue_terracotta
fill 13 279 393 13 279 395 minecraft:blue_terracotta
setblock 13 279 396 minecraft:light_blue_stained_glass
fill 13 279 397 15 279 397 minecraft:blue_terracotta
setblock 13 279 400 minecraft:light_blue_stained_glass
fill 13 279 401 15 279 401 minecraft:blue_terracotta
setblock 13 279 404 minecraft:light_blue_stained_glass
fill 13 279 405 15 279 405 minecraft:blue_terracotta
setblock 13 279 408 minecraft:light_blue_stained_glass
fill 13 279 409 15 279 409 minecraft:blue_terracotta
setblock 14 279 370 minecraft:blue_terracotta
setblock 14 279 371 minecraft:light_blue_stained_glass
fill 14 279 372 14 279 374 minecraft:blue_terracotta
setblock 14 279 375 minecraft:light_blue_stained_glass
fill 14 279 376 14 279 378 minecraft:blue_terracotta
setblock 14 279 379 minecraft:light_blue_stained_glass
fill 14 279 380 15 279 381 minecraft:blue_terracotta
setblock 14 279 382 minecraft:yellow_concrete
setblock 14 279 394 minecraft:yellow_concrete
setblock 14 279 395 minecraft:light_blue_stained_glass
fill 14 279 396 16 279 396 minecraft:blue_terracotta
setblock 14 279 399 minecraft:light_blue_stained_glass
fill 14 279 400 16 279 400 minecraft:blue_terracotta
setblock 14 279 403 minecraft:light_blue_stained_glass
fill 14 279 404 16 279 404 minecraft:blue_terracotta
setblock 14 279 407 minecraft:light_blue_stained_glass
fill 14 279 408 16 279 408 minecraft:blue_terracotta
setblock 15 279 370 minecraft:light_blue_stained_glass
fill 15 279 371 15 279 373 minecraft:blue_terracotta
setblock 15 279 374 minecraft:light_blue_stained_glass
fill 15 279 375 15 279 377 minecraft:blue_terracotta
setblock 15 279 378 minecraft:light_blue_stained_glass
fill 15 279 379 17 279 379 minecraft:blue_terracotta
setblock 15 279 395 minecraft:blue_terracotta
setblock 15 279 398 minecraft:light_blue_stained_glass
fill 15 279 399 17 279 399 minecraft:blue_terracotta
setblock 15 279 402 minecraft:light_blue_stained_glass
fill 15 279 403 17 279 403 minecraft:blue_terracotta
setblock 15 279 406 minecraft:light_blue_stained_glass
fill 15 279 407 17 279 407 minecraft:blue_terracotta
setblock 15 279 410 minecraft:light_blue_stained_glass
fill 16 279 370 16 279 372 minecraft:blue_terracotta
setblock 16 279 373 minecraft:light_blue_stained_glass
fill 16 279 374 16 279 376 minecraft:blue_terracotta
setblock 16 279 377 minecraft:light_blue_stained_glass
fill 16 279 378 18 279 378 minecraft:blue_terracotta
setblock 16 279 380 minecraft:blue_terracotta
fill 16 279 387 16 279 389 minecraft:sea_lantern
setblock 16 279 397 minecraft:light_blue_stained_glass
fill 16 279 398 18 279 398 minecraft:blue_terracotta
setblock 16 279 401 minecraft:light_blue_stained_glass
fill 16 279 402 18 279 402 minecraft:blue_terracotta
setblock 16 279 405 minecraft:light_blue_stained_glass
fill 16 279 406 18 279 406 minecraft:blue_terracotta
setblock 16 279 409 minecraft:light_blue_stained_glass
fill 16 279 410 18 279 410 minecraft:blue_terracotta
fill 17 279 370 17 279 371 minecraft:blue_terracotta
setblock 17 279 372 minecraft:light_blue_stained_glass
fill 17 279 373 17 279 375 minecraft:blue_terracotta
setblock 17 279 376 minecraft:light_blue_stained_glass
fill 17 279 377 19 279 377 minecraft:blue_terracotta
setblock 17 279 380 minecraft:light_blue_stained_glass
fill 17 279 385 17 279 387 minecraft:sea_lantern
fill 17 279 389 17 279 391 minecraft:sea_lantern
setblock 17 279 396 minecraft:light_blue_stained_glass
fill 17 279 397 19 279 397 minecraft:blue_terracotta
setblock 17 279 400 minecraft:light_blue_stained_glass
fill 17 279 401 19 279 401 minecraft:blue_terracotta
setblock 17 279 404 minecraft:light_blue_stained_glass
fill 17 279 405 19 279 405 minecraft:blue_terracotta
setblock 17 279 408 minecraft:light_blue_stained_glass
fill 17 279 409 19 279 409 minecraft:blue_terracotta
setblock 18 279 370 minecraft:blue_terracotta
setblock 18 279 371 minecraft:light_blue_stained_glass
fill 18 279 372 18 279 374 minecraft:blue_terracotta
setblock 18 279 375 minecraft:light_blue_stained_glass
fill 18 279 376 20 279 376 minecraft:blue_terracotta
setblock 18 279 379 minecraft:light_blue_stained_glass
setblock 18 279 380 minecraft:yellow_concrete
fill 18 279 385 19 279 385 minecraft:sea_lantern
fill 18 279 391 19 279 391 minecraft:sea_lantern
setblock 18 279 396 minecraft:yellow_concrete
setblock 18 279 399 minecraft:light_blue_stained_glass
fill 18 279 400 20 279 400 minecraft:blue_terracotta
setblock 18 279 403 minecraft:light_blue_stained_glass
fill 18 279 404 20 279 404 minecraft:blue_terracotta
setblock 18 279 407 minecraft:light_blue_stained_glass
fill 18 279 408 20 279 408 minecraft:blue_terracotta
setblock 19 279 370 minecraft:light_blue_stained_glass
fill 19 279 371 19 279 373 minecraft:blue_terracotta
setblock 19 279 374 minecraft:light_blue_stained_glass
fill 19 279 375 21 279 375 minecraft:blue_terracotta
setblock 19 279 378 minecraft:light_blue_stained_glass
fill 19 279 379 21 279 379 minecraft:blue_terracotta
fill 19 279 384 21 279 384 minecraft:sea_lantern
fill 19 279 392 21 279 392 minecraft:sea_lantern
setblock 19 279 398 minecraft:light_blue_stained_glass
fill 19 279 399 21 279 399 minecraft:blue_terracotta
setblock 19 279 402 minecraft:light_blue_stained_glass
fill 19 279 403 21 279 403 minecraft:blue_terracotta
setblock 19 279 406 minecraft:light_blue_stained_glass
fill 19 279 407 21 279 407 minecraft:blue_terracotta
setblock 19 279 410 minecraft:light_blue_stained_glass
fill 20 279 370 20 279 372 minecraft:blue_terracotta
setblock 20 279 373 minecraft:light_blue_stained_glass
fill 20 279 374 22 279 374 minecraft:blue_terracotta
setblock 20 279 377 minecraft:light_blue_stained_glass
fill 20 279 378 22 279 378 minecraft:blue_terracotta
setblock 20 279 397 minecraft:light_blue_stained_glass
fill 20 279 398 22 279 398 minecraft:blue_terracotta
setblock 20 279 401 minecraft:light_blue_stained_glass
fill 20 279 402 22 279 402 minecraft:blue_terracotta
setblock 20 279 405 minecraft:light_blue_stained_glass
fill 20 279 406 22 279 406 minecraft:blue_terracotta
setblock 20 279 409 minecraft:light_blue_stained_glass
fill 20 279 410 22 279 410 minecraft:blue_terracotta
fill 21 279 370 21 279 371 minecraft:blue_terracotta
setblock 21 279 372 minecraft:light_blue_stained_glass
fill 21 279 373 23 279 373 minecraft:blue_terracotta
setblock 21 279 376 minecraft:light_blue_stained_glass
fill 21 279 377 23 279 377 minecraft:blue_terracotta
fill 21 279 385 23 279 385 minecraft:sea_lantern
fill 21 279 391 23 279 391 minecraft:sea_lantern
fill 21 279 397 23 279 397 minecraft:blue_terracotta
setblock 21 279 400 minecraft:light_blue_stained_glass
fill 21 279 401 23 279 401 minecraft:blue_terracotta
setblock 21 279 404 minecraft:light_blue_stained_glass
fill 21 279 405 23 279 405 minecraft:blue_terracotta
setblock 21 279 408 minecraft:light_blue_stained_glass
fill 21 279 409 23 279 409 minecraft:blue_terracotta
setblock 22 279 370 minecraft:blue_terracotta
setblock 22 279 371 minecraft:light_blue_stained_glass
fill 22 279 372 24 279 372 minecraft:blue_terracotta
setblock 22 279 375 minecraft:light_blue_stained_glass
fill 22 279 376 24 279 376 minecraft:blue_terracotta
setblock 22 279 379 minecraft:light_blue_stained_glass
setblock 22 279 380 minecraft:yellow_concrete
setblock 22 279 396 minecraft:yellow_concrete
setblock 22 279 399 minecraft:light_blue_stained_glass
fill 22 279 400 24 279 400 minecraft:blue_terracotta
setblock 22 279 403 minecraft:light_blue_stained_glass
fill 22 279 404 24 279 404 minecraft:blue_terracotta
setblock 22 279 407 minecraft:light_blue_stained_glass
fill 22 279 408 24 279 408 minecraft:blue_terracotta
setblock 23 279 370 minecraft:light_blue_stained_glass
fill 23 279 371 25 279 371 minecraft:blue_terracotta
setblock 23 279 374 minecraft:light_blue_stained_glass
fill 23 279 375 25 279 375 minecraft:blue_terracotta
setblock 23 279 378 minecraft:light_blue_stained_glass
fill 23 279 379 24 279 380 minecraft:blue_terracotta
fill 23 279 386 23 279 387 minecraft:sea_lantern
fill 23 279 389 23 279 390 minecraft:sea_lantern
fill 23 279 396 24 279 396 minecraft:blue_terracotta
setblock 23 279 398 minecraft:light_blue_stained_glass
fill 23 279 399 25 279 399 minecraft:blue_terracotta
setblock 23 279 402 minecraft:light_blue_stained_glass
fill 23 279 403 25 279 403 minecraft:blue_terracotta
setblock 23 279 406 minecraft:light_blue_stained_glass
fill 23 279 407 25 279 407 minecraft:blue_terracotta
setblock 23 279 410 minecraft:light_blue_stained_glass
fill 24 279 370 26 279 370 minecraft:blue_terracotta
setblock 24 279 373 minecraft:light_blue_stained_glass
fill 24 279 374 26 279 374 minecraft:blue_terracotta
setblock 24 279 377 minecraft:light_blue_stained_glass
fill 24 279 378 26 279 378 minecraft:blue_terracotta
fill 24 279 387 24 279 389 minecraft:sea_lantern
setblock 24 279 397 minecraft:light_blue_stained_glass
fill 24 279 398 26 279 398 minecraft:blue_terracotta
setblock 24 279 401 minecraft:light_blue_stained_glass
fill 24 279 402 26 279 402 minecraft:blue_terracotta
setblock 24 279 405 minecraft:light_blue_stained_glass
fill 24 279 406 26 279 406 minecraft:blue_terracotta
setblock 24 279 409 minecraft:light_blue_stained_glass
fill 24 279 410 26 279 410 minecraft:blue_terracotta
setblock 25 279 372 minecraft:light_blue_stained_glass
fill 25 279 373 27 279 373 minecraft:blue_terracotta
setblock 25 279 376 minecraft:light_blue_stained_glass
fill 25 279 377 27 279 377 minecraft:blue_terracotta
setblock 25 279 379 minecraft:blue_terracotta
setblock 25 279 380 minecraft:light_blue_stained_glass
fill 25 279 381 27 279 381 minecraft:blue_terracotta
setblock 25 279 395 minecraft:blue_terracotta
setblock 25 279 396 minecraft:light_blue_stained_glass
fill 25 279 397 27 279 397 minecraft:blue_terracotta
setblock 25 279 400 minecraft:light_blue_stained_glass
fill 25 279 401 27 279 401 minecraft:blue_terracotta
setblock 25 279 404 minecraft:light_blue_stained_glass
fill 25 279 405 27 279 405 minecraft:blue_terracotta
setblock 25 279 408 minecraft:light_blue_stained_glass
fill 25 279 409 27 279 409 minecraft:blue_terracotta
setblock 26 279 371 minecraft:light_blue_stained_glass
fill 26 279 372 28 279 372 minecraft:blue_terracotta
setblock 26 279 375 minecraft:light_blue_stained_glass
fill 26 279 376 28 279 376 minecraft:blue_terracotta
setblock 26 279 379 minecraft:light_blue_stained_glass
fill 26 279 380 28 279 380 minecraft:blue_terracotta
setblock 26 279 382 minecraft:yellow_concrete
setblock 26 279 394 minecraft:yellow_concrete
setblock 26 279 395 minecraft:light_blue_stained_glass
fill 26 279 396 28 279 396 minecraft:blue_terracotta
setblock 26 279 399 minecraft:light_blue_stained_glass
fill 26 279 400 28 279 400 minecraft:blue_terracotta
setblock 26 279 403 minecraft:light_blue_stained_glass
fill 26 279 404 28 279 404 minecraft:blue_terracotta
setblock 26 279 407 minecraft:light_blue_stained_glass
fill 26 279 408 28 279 408 minecraft:blue_terracotta
setblock 27 279 370 minecraft:light_blue_stained_glass
fill 27 279 371 29 279 371 minecraft:blue_terracotta
setblock 27 279 374 minecraft:light_blue_stained_glass
fill 27 279 375 29 279 375 minecraft:blue_terracotta
setblock 27 279 378 minecraft:light_blue_stained_glass
fill 27 279 379 29 279 379 minecraft:blue_terracotta
setblock 27 279 382 minecraft:light_blue_stained_glass
fill 27 279 383 29 279 383 minecraft:blue_terracotta
setblock 27 279 393 minecraft:blue_terracotta
setblock 27 279 394 minecraft:light_blue_stained_glass
fill 27 279 395 29 279 395 minecraft:blue_terracotta
setblock 27 279 398 minecraft:light_blue_stained_glass
fill 27 279 399 29 279 399 minecraft:blue_terracotta
setblock 27 279 402 minecraft:light_blue_stained_glass
fill 27 279 403 29 279 403 minecraft:blue_terracotta
setblock 27 279 406 minecraft:light_blue_stained_glass
fill 27 279 407 29 279 407 minecraft:blue_terracotta
setblock 27 279 410 minecraft:light_blue_stained_glass
fill 28 279 370 30 279 370 minecraft:blue_terracotta
setblock 28 279 373 minecraft:light_blue_stained_glass
fill 28 279 374 30 279 374 minecraft:blue_terracotta
setblock 28 279 377 minecraft:light_blue_stained_glass
fill 28 279 378 30 279 378 minecraft:blue_terracotta
setblock 28 279 381 minecraft:light_blue_stained_glass
fill 28 279 382 30 279 382 minecraft:blue_terracotta
setblock 28 279 384 minecraft:blue_terracotta
setblock 28 279 385 minecraft:light_blue_stained_glass
setblock 28 279 386 minecraft:yellow_concrete
setblock 28 279 390 minecraft:yellow_concrete
fill 28 279 391 28 279 392 minecraft:blue_terracotta
setblock 28 279 393 minecraft:light_blue_stained_glass
fill 28 279 394 30 279 394 minecraft:blue_terracotta
setblock 28 279 397 minecraft:light_blue_stained_glass
fill 28 279 398 30 279 398 minecraft:blue_terracotta
setblock 28 279 401 minecraft:light_blue_stained_glass
fill 28 279 402 30 279 402 minecraft:blue_terracotta
setblock 28 279 405 minecraft:light_blue_stained_glass
fill 28 279 406 30 279 406 minecraft:blue_terracotta
setblock 28 279 409 minecraft:light_blue_stained_glass
fill 28 279 410 30 279 410 minecraft:blue_terracotta
setblock 29 279 372 minecraft:light_blue_stained_glass
fill 29 279 373 31 279 373 minecraft:blue_terracotta
setblock 29 279 376 minecraft:light_blue_stained_glass
fill 29 279 377 31 279 377 minecraft:blue_terracotta
setblock 29 279 380 minecraft:light_blue_stained_glass
fill 29 279 381 31 279 381 minecraft:blue_terracotta
setblock 29 279 384 minecraft:light_blue_stained_glass
fill 29 279 385 29 279 387 minecraft:blue_terracotta
setblock 29 279 388 minecraft:light_blue_stained_glass
fill 29 279 389 29 279 391 minecraft:blue_terracotta
setblock 29 279 392 minecraft:light_blue_stained_glass
fill 29 279 393 31 279 393 minecraft:blue_terracotta
setblock 29 279 396 minecraft:light_blue_stained_glass
fill 29 279 397 31 279 397 minecraft:blue_terracotta
setblock 29 279 400 minecraft:light_blue_stained_glass
fill 29 279 401 31 279 401 minecraft:blue_terracotta
setblock 29 279 404 minecraft:light_blue_stained_glass
fill 29 279 405 31 279 405 minecraft:blue_terracotta
setblock 29 279 408 minecraft:light_blue_stained_glass
fill 29 279 409 31 279 409 minecraft:blue_terracotta
setblock 30 279 371 minecraft:light_blue_stained_glass
fill 30 279 372 32 279 372 minecraft:blue_terracotta
setblock 30 279 375 minecraft:light_blue_stained_glass
fill 30 279 376 32 279 376 minecraft:blue_terracotta
setblock 30 279 379 minecraft:light_blue_stained_glass
fill 30 279 380 32 279 380 minecraft:blue_terracotta
setblock 30 279 383 minecraft:light_blue_stained_glass
fill 30 279 384 30 279 386 minecraft:blue_terracotta
setblock 30 279 387 minecraft:light_blue_stained_glass
fill 30 279 388 30 279 390 minecraft:blue_terracotta
setblock 30 279 391 minecraft:light_blue_stained_glass
fill 30 279 392 32 279 392 minecraft:blue_terracotta
setblock 30 279 395 minecraft:light_blue_stained_glass
fill 30 279 396 32 279 396 minecraft:blue_terracotta
setblock 30 279 399 minecraft:light_blue_stained_glass
fill 30 279 400 32 279 400 minecraft:blue_terracotta
setblock 30 279 403 minecraft:light_blue_stained_glass
fill 30 279 404 32 279 404 minecraft:blue_terracotta
setblock 30 279 407 minecraft:light_blue_stained_glass
fill 30 279 408 32 279 408 minecraft:blue_terracotta
setblock 31 279 370 minecraft:light_blue_stained_glass
fill 31 279 371 33 279 371 minecraft:blue_terracotta
setblock 31 279 374 minecraft:light_blue_stained_glass
fill 31 279 375 33 279 375 minecraft:blue_terracotta
setblock 31 279 378 minecraft:light_blue_stained_glass
fill 31 279 379 33 279 379 minecraft:blue_terracotta
setblock 31 279 382 minecraft:light_blue_stained_glass
fill 31 279 383 31 279 385 minecraft:blue_terracotta
setblock 31 279 386 minecraft:light_blue_stained_glass
fill 31 279 387 31 279 389 minecraft:blue_terracotta
setblock 31 279 390 minecraft:light_blue_stained_glass
fill 31 279 391 33 279 391 minecraft:blue_terracotta
setblock 31 279 394 minecraft:light_blue_stained_glass
fill 31 279 395 33 279 395 minecraft:blue_terracotta
setblock 31 279 398 minecraft:light_blue_stained_glass
fill 31 279 399 33 279 399 minecraft:blue_terracotta
setblock 31 279 402 minecraft:light_blue_stained_glass
fill 31 279 403 33 279 403 minecraft:blue_terracotta
setblock 31 279 406 minecraft:light_blue_stained_glass
fill 31 279 407 33 279 407 minecraft:blue_terracotta
setblock 31 279 410 minecraft:light_blue_stained_glass
fill 32 279 370 34 279 370 minecraft:blue_terracotta
setblock 32 279 373 minecraft:light_blue_stained_glass
fill 32 279 374 34 279 374 minecraft:blue_terracotta
setblock 32 279 377 minecraft:light_blue_stained_glass
fill 32 279 378 34 279 378 minecraft:blue_terracotta
setblock 32 279 381 minecraft:light_blue_stained_glass
fill 32 279 382 32 279 384 minecraft:blue_terracotta
setblock 32 279 385 minecraft:light_blue_stained_glass
fill 32 279 386 32 279 388 minecraft:blue_terracotta
setblock 32 279 389 minecraft:light_blue_stained_glass
fill 32 279 390 34 279 390 minecraft:blue_terracotta
setblock 32 279 393 minecraft:light_blue_stained_glass
fill 32 279 394 34 279 394 minecraft:blue_terracotta
setblock 32 279 397 minecraft:light_blue_stained_glass
fill 32 279 398 34 279 398 minecraft:blue_terracotta
setblock 32 279 401 minecraft:light_blue_stained_glass
fill 32 279 402 34 279 402 minecraft:blue_terracotta
setblock 32 279 405 minecraft:light_blue_stained_glass
fill 32 279 406 34 279 406 minecraft:blue_terracotta
setblock 32 279 409 minecraft:light_blue_stained_glass
fill 32 279 410 34 279 410 minecraft:blue_terracotta
setblock 33 279 372 minecraft:light_blue_stained_glass
fill 33 279 373 35 279 373 minecraft:blue_terracotta
setblock 33 279 376 minecraft:light_blue_stained_glass
fill 33 279 377 35 279 377 minecraft:blue_terracotta
setblock 33 279 380 minecraft:light_blue_stained_glass
fill 33 279 381 33 279 383 minecraft:blue_terracotta
setblock 33 279 384 minecraft:light_blue_stained_glass
fill 33 279 385 33 279 387 minecraft:blue_terracotta
setblock 33 279 388 minecraft:light_blue_stained_glass
fill 33 279 389 35 279 389 minecraft:blue_terracotta
setblock 33 279 392 minecraft:light_blue_stained_glass
fill 33 279 393 35 279 393 minecraft:blue_terracotta
setblock 33 279 396 minecraft:light_blue_stained_glass
fill 33 279 397 35 279 397 minecraft:blue_terracotta
setblock 33 279 400 minecraft:light_blue_stained_glass
fill 33 279 401 35 279 401 minecraft:blue_terracotta
setblock 33 279 404 minecraft:light_blue_stained_glass
fill 33 279 405 35 279 405 minecraft:blue_terracotta
setblock 33 279 408 minecraft:light_blue_stained_glass
fill 33 279 409 35 279 409 minecraft:blue_terracotta
setblock 34 279 371 minecraft:light_blue_stained_glass
fill 34 279 372 36 279 372 minecraft:blue_terracotta
setblock 34 279 375 minecraft:light_blue_stained_glass
fill 34 279 376 36 279 376 minecraft:blue_terracotta
setblock 34 279 379 minecraft:light_blue_stained_glass
fill 34 279 380 34 279 382 minecraft:blue_terracotta
setblock 34 279 383 minecraft:light_blue_stained_glass
fill 34 279 384 34 279 386 minecraft:blue_terracotta
setblock 34 279 387 minecraft:light_blue_stained_glass
fill 34 279 388 36 279 388 minecraft:blue_terracotta
setblock 34 279 391 minecraft:light_blue_stained_glass
fill 34 279 392 36 279 392 minecraft:blue_terracotta
setblock 34 279 395 minecraft:light_blue_stained_glass
fill 34 279 396 36 279 396 minecraft:blue_terracotta
setblock 34 279 399 minecraft:light_blue_stained_glass
fill 34 279 400 36 279 400 minecraft:blue_terracotta
setblock 34 279 403 minecraft:light_blue_stained_glass
fill 34 279 404 36 279 404 minecraft:blue_terracotta
setblock 34 279 407 minecraft:light_blue_stained_glass
fill 34 279 408 36 279 408 minecraft:blue_terracotta
setblock 35 279 370 minecraft:light_blue_stained_glass
fill 35 279 371 37 279 371 minecraft:blue_terracotta
setblock 35 279 374 minecraft:light_blue_stained_glass
fill 35 279 375 37 279 375 minecraft:blue_terracotta
setblock 35 279 378 minecraft:light_blue_stained_glass
fill 35 279 379 35 279 381 minecraft:blue_terracotta
setblock 35 279 382 minecraft:light_blue_stained_glass
fill 35 279 383 35 279 385 minecraft:blue_terracotta
setblock 35 279 386 minecraft:light_blue_stained_glass
fill 35 279 387 37 279 387 minecraft:blue_terracotta
setblock 35 279 390 minecraft:light_blue_stained_glass
fill 35 279 391 37 279 391 minecraft:blue_terracotta
setblock 35 279 394 minecraft:light_blue_stained_glass
fill 35 279 395 37 279 395 minecraft:blue_terracotta
setblock 35 279 398 minecraft:light_blue_stained_glass
fill 35 279 399 37 279 399 minecraft:blue_terracotta
setblock 35 279 402 minecraft:light_blue_stained_glass
fill 35 279 403 37 279 403 minecraft:blue_terracotta
setblock 35 279 406 minecraft:light_blue_stained_glass
fill 35 279 407 37 279 407 minecraft:blue_terracotta
setblock 35 279 410 minecraft:light_blue_stained_glass
fill 36 279 370 38 279 370 minecraft:blue_terracotta
setblock 36 279 373 minecraft:light_blue_stained_glass
fill 36 279 374 38 279 374 minecraft:blue_terracotta
setblock 36 279 377 minecraft:light_blue_stained_glass
fill 36 279 378 36 279 380 minecraft:blue_terracotta
setblock 36 279 381 minecraft:light_blue_stained_glass
fill 36 279 382 36 279 384 minecraft:blue_terracotta
setblock 36 279 385 minecraft:light_blue_stained_glass
fill 36 279 386 38 279 386 minecraft:blue_terracotta
setblock 36 279 389 minecraft:light_blue_stained_glass
fill 36 279 390 38 279 390 minecraft:blue_terracotta
setblock 36 279 393 minecraft:light_blue_stained_glass
fill 36 279 394 38 279 394 minecraft:blue_terracotta
setblock 36 279 397 minecraft:light_blue_stained_glass
fill 36 279 398 38 279 398 minecraft:blue_terracotta
setblock 36 279 401 minecraft:light_blue_stained_glass
fill 36 279 402 38 279 402 minecraft:blue_terracotta
setblock 36 279 405 minecraft:light_blue_stained_glass
fill 36 279 406 38 279 406 minecraft:blue_terracotta
setblock 36 279 409 minecraft:light_blue_stained_glass
fill 36 279 410 38 279 410 minecraft:blue_terracotta
setblock 37 279 372 minecraft:light_blue_stained_glass
fill 37 279 373 39 279 373 minecraft:blue_terracotta
setblock 37 279 376 minecraft:light_blue_stained_glass
fill 37 279 377 37 279 379 minecraft:blue_terracotta
setblock 37 279 380 minecraft:light_blue_stained_glass
fill 37 279 381 37 279 383 minecraft:blue_terracotta
setblock 37 279 384 minecraft:light_blue_stained_glass
fill 37 279 385 39 279 385 minecraft:blue_terracotta
setblock 37 279 388 minecraft:light_blue_stained_glass
fill 37 279 389 39 279 389 minecraft:blue_terracotta
setblock 37 279 392 minecraft:light_blue_stained_glass
fill 37 279 393 39 279 393 minecraft:blue_terracotta
setblock 37 279 396 minecraft:light_blue_stained_glass
fill 37 279 397 39 279 397 minecraft:blue_terracotta
setblock 37 279 400 minecraft:light_blue_stained_glass
fill 37 279 401 39 279 401 minecraft:blue_terracotta
setblock 37 279 404 minecraft:light_blue_stained_glass
fill 37 279 405 39 279 405 minecraft:blue_terracotta
setblock 37 279 408 minecraft:light_blue_stained_glass
fill 37 279 409 39 279 409 minecraft:blue_terracotta
setblock 38 279 371 minecraft:light_blue_stained_glass
fill 38 279 372 40 279 372 minecraft:blue_terracotta
setblock 38 279 375 minecraft:light_blue_stained_glass
fill 38 279 376 38 279 378 minecraft:blue_terracotta
setblock 38 279 379 minecraft:light_blue_stained_glass
fill 38 279 380 38 279 382 minecraft:blue_terracotta
setblock 38 279 383 minecraft:light_blue_stained_glass
fill 38 279 384 40 279 384 minecraft:blue_terracotta
setblock 38 279 387 minecraft:light_blue_stained_glass
fill 38 279 388 40 279 388 minecraft:blue_terracotta
setblock 38 279 391 minecraft:light_blue_stained_glass
fill 38 279 392 40 279 392 minecraft:blue_terracotta
setblock 38 279 395 minecraft:light_blue_stained_glass
fill 38 279 396 40 279 396 minecraft:blue_terracotta
setblock 38 279 399 minecraft:light_blue_stained_glass
fill 38 279 400 40 279 400 minecraft:blue_terracotta
setblock 38 279 403 minecraft:light_blue_stained_glass
fill 38 279 404 40 279 404 minecraft:blue_terracotta
setblock 38 279 407 minecraft:light_blue_stained_glass
fill 38 279 408 40 279 408 minecraft:blue_terracotta
setblock 39 279 370 minecraft:light_blue_stained_glass
fill 39 279 371 41 279 371 minecraft:blue_terracotta
setblock 39 279 374 minecraft:light_blue_stained_glass
fill 39 279 375 39 279 377 minecraft:blue_terracotta
setblock 39 279 378 minecraft:light_blue_stained_glass
fill 39 279 379 39 279 381 minecraft:blue_terracotta
setblock 39 279 382 minecraft:light_blue_stained_glass
fill 39 279 383 41 279 383 minecraft:blue_terracotta
setblock 39 279 386 minecraft:light_blue_stained_glass
fill 39 279 387 41 279 387 minecraft:blue_terracotta
setblock 39 279 390 minecraft:light_blue_stained_glass
fill 39 279 391 41 279 391 minecraft:blue_terracotta
setblock 39 279 394 minecraft:light_blue_stained_glass
fill 39 279 395 41 279 395 minecraft:blue_terracotta
setblock 39 279 398 minecraft:light_blue_stained_glass
fill 39 279 399 41 279 399 minecraft:blue_terracotta
setblock 39 279 402 minecraft:light_blue_stained_glass
fill 39 279 403 41 279 403 minecraft:blue_terracotta
setblock 39 279 406 minecraft:light_blue_stained_glass
fill 39 279 407 41 279 407 minecraft:blue_terracotta
setblock 39 279 410 minecraft:light_blue_stained_glass
fill 40 279 370 41 279 370 minecraft:blue_terracotta
setblock 40 279 373 minecraft:light_blue_stained_glass
fill 40 279 374 40 279 376 minecraft:blue_terracotta
setblock 40 279 377 minecraft:light_blue_stained_glass
fill 40 279 378 40 279 380 minecraft:blue_terracotta
setblock 40 279 381 minecraft:light_blue_stained_glass
fill 40 279 382 41 279 382 minecraft:blue_terracotta
setblock 40 279 385 minecraft:light_blue_stained_glass
fill 40 279 386 41 279 386 minecraft:blue_terracotta
setblock 40 279 389 minecraft:light_blue_stained_glass
fill 40 279 390 41 279 390 minecraft:blue_terracotta
setblock 40 279 393 minecraft:light_blue_stained_glass
fill 40 279 394 41 279 394 minecraft:blue_terracotta
setblock 40 279 397 minecraft:light_blue_stained_glass
fill 40 279 398 41 279 398 minecraft:blue_terracotta
setblock 40 279 401 minecraft:light_blue_stained_glass
fill 40 279 402 41 279 402 minecraft:blue_terracotta
setblock 40 279 405 minecraft:light_blue_stained_glass
fill 40 279 406 41 279 406 minecraft:blue_terracotta
setblock 40 279 409 minecraft:light_blue_stained_glass
fill 40 279 410 41 279 410 minecraft:blue_terracotta
setblock 41 279 372 minecraft:light_blue_stained_glass
fill 41 279 373 41 279 375 minecraft:blue_terracotta
setblock 41 279 376 minecraft:light_blue_stained_glass
fill 41 279 377 41 279 379 minecraft:blue_terracotta
setblock 41 279 380 minecraft:light_blue_stained_glass
setblock 41 279 381 minecraft:blue_terracotta
setblock 41 279 384 minecraft:light_blue_stained_glass
setblock 41 279 385 minecraft:blue_terracotta
setblock 41 279 388 minecraft:light_blue_stained_glass
setblock 41 279 389 minecraft:blue_terracotta
setblock 41 279 392 minecraft:light_blue_stained_glass
setblock 41 279 393 minecraft:blue_terracotta
setblock 41 279 396 minecraft:light_blue_stained_glass
setblock 41 279 397 minecraft:blue_terracotta
setblock 41 279 400 minecraft:light_blue_stained_glass
setblock 41 279 401 minecraft:blue_terracotta
setblock 41 279 404 minecraft:light_blue_stained_glass
setblock 41 279 405 minecraft:blue_terracotta
setblock 41 279 408 minecraft:light_blue_stained_glass
setblock 41 279 409 minecraft:blue_terracotta
fill 14 280 386 15 280 390 minecraft:yellow_concrete
fill 15 280 384 16 280 385 minecraft:yellow_concrete
fill 15 280 391 16 280 392 minecraft:yellow_concrete
fill 16 280 383 24 280 383 minecraft:yellow_concrete
fill 16 280 393 24 280 393 minecraft:yellow_concrete
setblock 17 280 384 minecraft:yellow_concrete
setblock 17 280 392 minecraft:yellow_concrete
fill 18 280 382 22 280 382 minecraft:yellow_concrete
fill 18 280 394 22 280 394 minecraft:yellow_concrete
fill 23 280 384 25 280 384 minecraft:yellow_concrete
fill 23 280 392 25 280 392 minecraft:yellow_concrete
fill 24 280 385 25 280 385 minecraft:yellow_concrete
fill 24 280 391 25 280 391 minecraft:yellow_concrete
fill 25 280 386 26 280 390 minecraft:yellow_concrete
fill 0 283 375 0 283 378 minecraft:sea_lantern
fill 0 283 385 0 283 388 minecraft:sea_lantern
fill 0 283 395 0 283 398 minecraft:sea_lantern
fill 0 283 405 0 283 408 minecraft:sea_lantern
fill 1 283 371 1 300 371 minecraft:iron_block
fill 1 283 381 1 300 381 minecraft:iron_block
fill 1 283 391 1 300 391 minecraft:iron_block
fill 1 283 401 1 300 401 minecraft:iron_block
fill 2 283 410 2 300 410 minecraft:iron_block
fill 3 283 369 6 283 369 minecraft:sea_lantern
fill 4 283 383 4 284 384 minecraft:light_blue_stained_glass
fill 4 283 411 7 283 411 minecraft:sea_lantern
fill 8 283 370 8 300 370 minecraft:iron_block
fill 12 283 410 12 300 410 minecraft:iron_block
fill 13 283 369 16 283 369 minecraft:sea_lantern
fill 13 283 372 15 300 374 minecraft:iron_block
fill 14 283 411 17 283 411 minecraft:sea_lantern
fill 18 283 370 18 300 370 minecraft:iron_block
fill 22 283 410 22 300 410 minecraft:iron_block
fill 23 283 369 26 283 369 minecraft:sea_lantern
fill 24 283 411 27 283 411 minecraft:sea_lantern
fill 28 283 370 28 300 370 minecraft:iron_block
fill 32 283 410 32 300 410 minecraft:iron_block
fill 33 283 369 36 283 369 minecraft:sea_lantern
fill 34 283 411 37 283 411 minecraft:sea_lantern
fill 38 283 370 38 300 370 minecraft:iron_block
fill 41 283 377 41 300 377 minecraft:iron_block
fill 41 283 387 41 300 387 minecraft:iron_block
fill 41 283 397 41 300 397 minecraft:iron_block
fill 41 283 407 41 300 407 minecraft:iron_block
fill 42 283 370 42 283 373 minecraft:sea_lantern
fill 42 283 380 42 283 383 minecraft:sea_lantern
fill 42 283 390 42 283 393 minecraft:sea_lantern
fill 42 283 400 42 283 403 minecraft:sea_lantern
setblock 42 283 410 minecraft:sea_lantern
fill 0 284 375 0 291 378 minecraft:blue_concrete
fill 0 284 385 0 291 388 minecraft:blue_concrete
fill 0 284 395 0 291 398 minecraft:blue_concrete
fill 0 284 405 0 291 408 minecraft:blue_concrete
fill 3 284 369 6 291 369 minecraft:blue_concrete
fill 4 284 411 7 291 411 minecraft:blue_concrete
fill 13 284 369 16 291 369 minecraft:blue_concrete
fill 14 284 411 17 291 411 minecraft:blue_concrete
fill 23 284 369 26 291 369 minecraft:blue_concrete
fill 24 284 411 27 291 411 minecraft:blue_concrete
fill 33 284 369 36 291 369 minecraft:blue_concrete
fill 34 284 411 37 291 411 minecraft:blue_concrete
fill 42 284 370 42 291 373 minecraft:blue_concrete
fill 42 284 380 42 291 383 minecraft:blue_concrete
fill 42 284 390 42 291 393 minecraft:blue_concrete
fill 42 284 400 42 291 403 minecraft:blue_concrete
fill 42 284 410 42 291 410 minecraft:blue_concrete
setblock 3 285 372 minecraft:light[level=14]
setblock 3 285 380 minecraft:light[level=14]
setblock 3 285 388 minecraft:light[level=14]
setblock 3 285 396 minecraft:light[level=14]
setblock 3 285 404 minecraft:light[level=14]
setblock 11 285 372 minecraft:light[level=14]
setblock 11 285 380 minecraft:light[level=14]
setblock 11 285 388 minecraft:light[level=14]
setblock 11 285 396 minecraft:light[level=14]
setblock 11 285 404 minecraft:light[level=14]
fill 12 285 372 12 285 374 minecraft:gray_concrete
fill 13 285 371 15 285 371 minecraft:gray_concrete
fill 13 285 375 15 285 375 minecraft:gray_concrete
fill 16 285 372 16 285 374 minecraft:gray_concrete
setblock 19 285 372 minecraft:light[level=14]
setblock 19 285 380 minecraft:light[level=14]
setblock 19 285 396 minecraft:light[level=14]
setblock 19 285 404 minecraft:light[level=14]
setblock 27 285 372 minecraft:light[level=14]
setblock 27 285 380 minecraft:light[level=14]
setblock 27 285 388 minecraft:light[level=14]
setblock 27 285 396 minecraft:light[level=14]
setblock 27 285 404 minecraft:light[level=14]
setblock 35 285 372 minecraft:light[level=14]
setblock 35 285 380 minecraft:light[level=14]
setblock 35 285 388 minecraft:light[level=14]
setblock 35 285 396 minecraft:light[level=14]
setblock 35 285 404 minecraft:light[level=14]
fill 28 287 402 28 288 402 minecraft:sea_lantern
fill 29 287 372 29 298 372 minecraft:iron_block
setblock 1 288 372 minecraft:gray_concrete
fill 1 288 374 1 288 377 minecraft:gray_concrete
setblock 1 288 382 minecraft:gray_concrete
fill 1 288 384 1 288 387 minecraft:gray_concrete
setblock 1 288 392 minecraft:gray_concrete
fill 1 288 394 1 288 397 minecraft:gray_concrete
setblock 1 288 402 minecraft:gray_concrete
fill 1 288 404 1 288 407 minecraft:gray_concrete
fill 2 288 370 5 288 370 minecraft:gray_concrete
setblock 3 288 410 minecraft:gray_concrete
fill 5 288 410 8 288 410 minecraft:gray_concrete
setblock 7 288 370 minecraft:gray_concrete
fill 12 288 370 15 288 370 minecraft:gray_concrete
setblock 13 288 410 minecraft:gray_concrete
fill 15 288 410 18 288 410 minecraft:gray_concrete
setblock 17 288 370 minecraft:gray_concrete
fill 22 288 370 25 288 370 minecraft:gray_concrete
setblock 23 288 410 minecraft:gray_concrete
fill 25 288 410 28 288 410 minecraft:gray_concrete
setblock 27 288 370 minecraft:gray_concrete
fill 32 288 370 35 288 370 minecraft:gray_concrete
setblock 33 288 410 minecraft:gray_concrete
fill 35 288 410 38 288 410 minecraft:gray_concrete
setblock 37 288 370 minecraft:gray_concrete
fill 41 288 371 41 288 374 minecraft:gray_concrete
setblock 41 288 376 minecraft:gray_concrete
fill 41 288 381 41 288 384 minecraft:gray_concrete
setblock 41 288 386 minecraft:gray_concrete
fill 41 288 391 41 288 394 minecraft:gray_concrete
setblock 41 288 396 minecraft:gray_concrete
fill 41 288 401 41 288 404 minecraft:gray_concrete
setblock 41 288 406 minecraft:gray_concrete
fill 27 289 402 28 298 402 minecraft:black_concrete
fill 27 291 401 28 298 401 minecraft:black_concrete
fill 27 291 403 28 298 403 minecraft:black_concrete
fill 0 292 375 0 292 378 minecraft:sea_lantern
fill 0 292 385 0 292 388 minecraft:sea_lantern
fill 0 292 395 0 292 398 minecraft:sea_lantern
fill 0 292 405 0 292 408 minecraft:sea_lantern
fill 3 292 369 6 292 369 minecraft:sea_lantern
fill 4 292 411 7 292 411 minecraft:sea_lantern
fill 13 292 369 16 292 369 minecraft:sea_lantern
fill 14 292 411 17 292 411 minecraft:sea_lantern
fill 23 292 369 26 292 369 minecraft:sea_lantern
fill 24 292 411 27 292 411 minecraft:sea_lantern
fill 26 292 402 26 298 402 minecraft:black_concrete
fill 29 292 401 29 298 402 minecraft:black_concrete
fill 33 292 369 36 292 369 minecraft:sea_lantern
fill 34 292 411 37 292 411 minecraft:sea_lantern
fill 42 292 370 42 292 373 minecraft:sea_lantern
fill 42 292 380 42 292 383 minecraft:sea_lantern
fill 42 292 390 42 292 393 minecraft:sea_lantern
fill 42 292 400 42 292 403 minecraft:sea_lantern
setblock 42 292 410 minecraft:sea_lantern
fill 0 293 375 0 307 378 minecraft:blue_concrete
fill 0 293 385 0 307 388 minecraft:blue_concrete
fill 0 293 395 0 307 398 minecraft:blue_concrete
fill 0 293 405 0 307 408 minecraft:blue_concrete
fill 3 293 369 6 307 369 minecraft:blue_concrete
setblock 3 293 372 minecraft:light[level=14]
setblock 3 293 380 minecraft:light[level=14]
setblock 3 293 388 minecraft:light[level=14]
setblock 3 293 396 minecraft:light[level=14]
setblock 3 293 404 minecraft:light[level=14]
fill 4 293 411 7 307 411 minecraft:blue_concrete
setblock 11 293 372 minecraft:light[level=14]
setblock 11 293 380 minecraft:light[level=14]
setblock 11 293 388 minecraft:light[level=14]
setblock 11 293 396 minecraft:light[level=14]
setblock 11 293 404 minecraft:light[level=14]
fill 12 293 372 12 293 374 minecraft:gray_concrete
fill 13 293 369 16 307 369 minecraft:blue_concrete
fill 13 293 371 15 293 371 minecraft:gray_concrete
fill 13 293 375 15 293 375 minecraft:gray_concrete
fill 14 293 411 17 307 411 minecraft:blue_concrete
fill 16 293 372 16 293 374 minecraft:gray_concrete
setblock 19 293 372 minecraft:light[level=14]
setblock 19 293 380 minecraft:light[level=14]
setblock 19 293 388 minecraft:light[level=14]
setblock 19 293 396 minecraft:light[level=14]
setblock 19 293 404 minecraft:light[level=14]
fill 23 293 369 26 307 369 minecraft:blue_concrete
fill 24 293 411 27 307 411 minecraft:blue_concrete
fill 26 293 401 26 298 401 minecraft:black_concrete
fill 26 293 403 26 298 403 minecraft:black_concrete
setblock 27 293 372 minecraft:light[level=14]
setblock 27 293 380 minecraft:light[level=14]
setblock 27 293 388 minecraft:light[level=14]
setblock 27 293 396 minecraft:light[level=14]
fill 27 293 400 28 298 400 minecraft:black_concrete
fill 27 293 404 28 298 404 minecraft:black_concrete
fill 29 293 403 29 298 403 minecraft:black_concrete
fill 33 293 369 36 307 369 minecraft:blue_concrete
fill 34 293 411 37 307 411 minecraft:blue_concrete
setblock 35 293 372 minecraft:light[level=14]
setblock 35 293 380 minecraft:light[level=14]
setblock 35 293 388 minecraft:light[level=14]
setblock 35 293 396 minecraft:light[level=14]
setblock 35 293 404 minecraft:light[level=14]
fill 42 293 370 42 307 373 minecraft:blue_concrete
fill 42 293 380 42 307 383 minecraft:blue_concrete
fill 42 293 390 42 307 393 minecraft:blue_concrete
fill 42 293 400 42 307 403 minecraft:blue_concrete
fill 42 293 410 42 307 410 minecraft:blue_concrete
setblock 1 294 372 minecraft:gray_concrete
setblock 1 294 382 minecraft:gray_concrete
setblock 1 294 392 minecraft:gray_concrete
setblock 1 294 402 minecraft:gray_concrete
setblock 3 294 410 minecraft:gray_concrete
setblock 7 294 370 minecraft:gray_concrete
setblock 13 294 410 minecraft:gray_concrete
setblock 17 294 370 minecraft:gray_concrete
setblock 23 294 410 minecraft:gray_concrete
fill 25 294 402 25 298 402 minecraft:black_concrete
fill 26 294 400 26 298 400 minecraft:black_concrete
fill 26 294 404 26 298 404 minecraft:black_concrete
setblock 27 294 370 minecraft:gray_concrete
fill 29 294 400 29 298 400 minecraft:black_concrete
fill 29 294 404 29 298 404 minecraft:black_concrete
fill 30 294 401 30 298 403 minecraft:black_concrete
setblock 33 294 410 minecraft:gray_concrete
setblock 37 294 370 minecraft:gray_concrete
setblock 41 294 376 minecraft:gray_concrete
setblock 41 294 386 minecraft:gray_concrete
setblock 41 294 396 minecraft:gray_concrete
setblock 41 294 406 minecraft:gray_concrete
fill 25 295 401 25 298 401 minecraft:black_concrete
fill 25 295 403 25 298 403 minecraft:black_concrete
fill 27 295 399 28 298 399 minecraft:black_concrete
fill 27 295 405 28 298 405 minecraft:black_concrete
fill 30 295 400 30 298 400 minecraft:black_concrete
fill 24 296 402 24 298 402 minecraft:black_concrete
fill 25 296 400 25 298 400 minecraft:black_concrete
fill 25 296 404 25 298 404 minecraft:black_concrete
fill 26 296 399 26 298 399 minecraft:black_concrete
fill 26 296 405 26 298 405 minecraft:black_concrete
fill 29 296 399 29 298 399 minecraft:black_concrete
fill 29 296 405 29 298 405 minecraft:black_concrete
fill 30 296 404 30 298 404 minecraft:black_concrete
fill 31 296 401 31 298 403 minecraft:black_concrete
fill 1 297 374 1 297 377 minecraft:gray_concrete
fill 1 297 384 1 297 387 minecraft:gray_concrete
fill 1 297 394 1 297 397 minecraft:gray_concrete
fill 1 297 404 1 297 407 minecraft:gray_concrete
fill 2 297 370 5 297 370 minecraft:gray_concrete
fill 5 297 410 8 297 410 minecraft:gray_concrete
fill 12 297 370 15 297 370 minecraft:gray_concrete
fill 13 297 371 15 298 371 minecraft:iron_block
fill 15 297 410 18 297 410 minecraft:gray_concrete
fill 22 297 370 25 297 370 minecraft:gray_concrete
fill 24 297 400 24 298 401 minecraft:black_concrete
fill 24 297 403 24 298 404 minecraft:black_concrete
fill 25 297 399 25 298 399 minecraft:black_concrete
fill 25 297 405 25 298 405 minecraft:black_concrete
fill 25 297 410 28 297 410 minecraft:gray_concrete
fill 27 297 398 28 298 398 minecraft:black_concrete
fill 27 297 406 28 298 406 minecraft:black_concrete
fill 30 297 399 30 298 399 minecraft:black_concrete
fill 30 297 405 30 298 405 minecraft:black_concrete
fill 31 297 400 31 298 400 minecraft:black_concrete
fill 31 297 404 31 298 404 minecraft:black_concrete
fill 32 297 370 35 297 370 minecraft:gray_concrete
fill 35 297 410 38 297 410 minecraft:gray_concrete
fill 41 297 371 41 297 374 minecraft:gray_concrete
fill 41 297 381 41 297 384 minecraft:gray_concrete
fill 41 297 391 41 297 394 minecraft:gray_concrete
fill 41 297 401 41 297 404 minecraft:gray_concrete
fill 13 298 370 15 298 370 minecraft:iron_block
setblock 14 298 375 minecraft:sea_lantern
setblock 23 298 402 minecraft:black_concrete
setblock 24 298 399 minecraft:black_concrete
setblock 26 298 398 minecraft:black_concrete
setblock 26 298 406 minecraft:black_concrete
fill 29 298 398 30 298 398 minecraft:black_concrete
setblock 29 298 406 minecraft:black_concrete
setblock 31 298 399 minecraft:black_concrete
setblock 31 298 405 minecraft:black_concrete
fill 32 298 401 32 298 403 minecraft:black_concrete
fill 26 299 402 26 300 402 minecraft:gray_concrete
fill 28 299 401 28 300 401 minecraft:gray_concrete
fill 28 299 403 28 300 403 minecraft:gray_concrete
setblock 1 300 372 minecraft:gray_concrete
setblock 1 300 382 minecraft:gray_concrete
setblock 1 300 392 minecraft:gray_concrete
setblock 1 300 402 minecraft:gray_concrete
setblock 3 300 410 minecraft:gray_concrete
setblock 7 300 370 minecraft:gray_concrete
setblock 13 300 410 minecraft:gray_concrete
setblock 17 300 370 minecraft:gray_concrete
setblock 23 300 410 minecraft:gray_concrete
setblock 27 300 370 minecraft:gray_concrete
setblock 33 300 410 minecraft:gray_concrete
setblock 37 300 370 minecraft:gray_concrete
setblock 41 300 376 minecraft:gray_concrete
setblock 41 300 386 minecraft:gray_concrete
setblock 41 300 396 minecraft:gray_concrete
setblock 41 300 406 minecraft:gray_concrete
setblock 3 301 372 minecraft:light[level=14]
setblock 3 301 380 minecraft:light[level=14]
setblock 3 301 388 minecraft:light[level=14]
setblock 3 301 396 minecraft:light[level=14]
setblock 3 301 404 minecraft:light[level=14]
setblock 11 301 372 minecraft:light[level=14]
setblock 11 301 380 minecraft:light[level=14]
setblock 11 301 388 minecraft:light[level=14]
setblock 11 301 396 minecraft:light[level=14]
setblock 11 301 404 minecraft:light[level=14]
setblock 19 301 372 minecraft:light[level=14]
setblock 19 301 380 minecraft:light[level=14]
setblock 19 301 388 minecraft:light[level=14]
setblock 19 301 396 minecraft:light[level=14]
setblock 19 301 404 minecraft:light[level=14]
setblock 27 301 372 minecraft:light[level=14]
setblock 27 301 380 minecraft:light[level=14]
setblock 27 301 388 minecraft:light[level=14]
setblock 27 301 396 minecraft:light[level=14]
setblock 27 301 404 minecraft:light[level=14]
setblock 35 301 372 minecraft:light[level=14]
setblock 35 301 380 minecraft:light[level=14]
setblock 35 301 388 minecraft:light[level=14]
setblock 35 301 396 minecraft:light[level=14]
setblock 35 301 404 minecraft:light[level=14]
