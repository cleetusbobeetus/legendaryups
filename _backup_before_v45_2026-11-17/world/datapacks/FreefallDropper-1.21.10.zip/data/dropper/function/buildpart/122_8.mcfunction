setblock 96 212 549 minecraft:blackstone
setblock 96 212 550 minecraft:smooth_basalt
fill 96 212 551 96 215 551 minecraft:blackstone
setblock 97 212 514 minecraft:smooth_basalt
fill 97 212 515 97 213 515 minecraft:blackstone
setblock 97 212 519 minecraft:smooth_basalt
fill 97 212 520 97 215 520 minecraft:blackstone
setblock 97 212 524 minecraft:smooth_basalt
fill 97 212 525 97 215 525 minecraft:blackstone
setblock 97 212 543 minecraft:blackstone
setblock 97 212 544 minecraft:smooth_basalt
fill 97 212 545 97 215 545 minecraft:blackstone
setblock 97 212 548 minecraft:blackstone
setblock 97 212 549 minecraft:smooth_basalt
fill 97 212 550 97 215 550 minecraft:blackstone
fill 98 212 549 101 212 549 minecraft:blackstone
setblock 99 212 512 minecraft:smooth_basalt
setblock 100 212 511 minecraft:smooth_basalt
fill 100 212 512 100 214 512 minecraft:blackstone
setblock 100 212 551 minecraft:smooth_basalt
fill 101 212 511 101 215 511 minecraft:blackstone
setblock 101 212 550 minecraft:smooth_basalt
fill 101 212 551 101 215 551 minecraft:blackstone
fill 102 212 550 103 214 550 minecraft:blackstone
setblock 105 212 551 minecraft:smooth_basalt
fill 106 212 551 109 212 551 minecraft:blackstone
setblock 110 212 551 minecraft:smooth_basalt
fill 111 212 551 114 212 551 minecraft:blackstone
fill 113 212 550 115 212 550 minecraft:blackstone
setblock 115 212 551 minecraft:smooth_basalt
setblock 116 212 550 minecraft:smooth_basalt
fill 116 212 551 116 215 551 minecraft:blackstone
fill 117 212 550 117 215 550 minecraft:blackstone
fill 119 212 550 119 213 550 minecraft:blackstone
setblock 120 212 551 minecraft:smooth_basalt
fill 133 212 511 133 213 511 minecraft:blackstone
setblock 133 212 517 minecraft:blackstone
setblock 133 212 518 minecraft:smooth_basalt
fill 133 212 519 133 215 519 minecraft:blackstone
fill 133 212 521 133 212 522 minecraft:blackstone
setblock 133 212 523 minecraft:smooth_basalt
fill 133 212 524 133 215 524 minecraft:blackstone
fill 133 212 526 133 213 526 minecraft:blackstone
fill 134 212 514 134 214 514 minecraft:blackstone
setblock 134 212 517 minecraft:smooth_basalt
fill 134 212 518 134 215 518 minecraft:blackstone
setblock 134 212 522 minecraft:smooth_basalt
fill 134 212 523 134 215 523 minecraft:blackstone
setblock 134 212 527 minecraft:smooth_basalt
fill 134 212 528 134 214 529 minecraft:blackstone
setblock 134 212 541 minecraft:blackstone
setblock 134 212 542 minecraft:smooth_basalt
fill 134 212 543 134 212 546 minecraft:blackstone
setblock 135 212 511 minecraft:smooth_basalt
fill 135 212 512 135 215 512 minecraft:blackstone
setblock 135 212 516 minecraft:smooth_basalt
fill 135 212 517 135 215 517 minecraft:blackstone
setblock 135 212 521 minecraft:smooth_basalt
fill 135 212 522 135 215 522 minecraft:blackstone
setblock 135 212 526 minecraft:smooth_basalt
fill 135 212 527 135 215 527 minecraft:blackstone
setblock 135 212 531 minecraft:smooth_basalt
fill 135 212 532 135 213 534 minecraft:blackstone
setblock 135 212 536 minecraft:smooth_basalt
fill 135 212 537 135 215 537 minecraft:blackstone
setblock 135 212 541 minecraft:smooth_basalt
fill 135 212 542 135 215 542 minecraft:blackstone
fill 135 212 544 135 212 545 minecraft:blackstone
setblock 135 212 546 minecraft:smooth_basalt
fill 135 212 547 135 215 547 minecraft:blackstone
setblock 135 212 550 minecraft:blackstone
setblock 135 212 551 minecraft:smooth_basalt
fill 95 213 511 95 216 511 minecraft:blackstone
setblock 95 213 515 minecraft:smooth_basalt
fill 95 213 516 95 216 516 minecraft:blackstone
setblock 95 213 520 minecraft:smooth_basalt
fill 95 213 521 95 216 521 minecraft:blackstone
setblock 95 213 525 minecraft:smooth_basalt
fill 95 213 526 95 216 526 minecraft:blackstone
setblock 95 213 529 minecraft:blackstone
setblock 95 213 530 minecraft:smooth_basalt
fill 95 213 531 95 216 531 minecraft:blackstone
fill 95 213 536 95 216 536 minecraft:blackstone
setblock 95 213 540 minecraft:smooth_basalt
fill 95 213 541 95 216 541 minecraft:blackstone
setblock 95 213 545 minecraft:smooth_basalt
fill 95 213 546 95 216 546 minecraft:blackstone
setblock 95 213 549 minecraft:blackstone
setblock 95 213 550 minecraft:smooth_basalt
fill 95 213 551 95 216 551 minecraft:blackstone
setblock 96 213 514 minecraft:smooth_basalt
fill 96 213 515 96 216 515 minecraft:blackstone
setblock 96 213 519 minecraft:smooth_basalt
fill 96 213 520 96 216 520 minecraft:blackstone
setblock 96 213 523 minecraft:blackstone
setblock 96 213 524 minecraft:smooth_basalt
fill 96 213 525 96 216 525 minecraft:blackstone
setblock 96 213 528 minecraft:blackstone
setblock 96 213 539 minecraft:smooth_basalt
fill 96 213 540 96 216 540 minecraft:blackstone
setblock 96 213 544 minecraft:smooth_basalt
fill 96 213 545 96 216 545 minecraft:blackstone
setblock 96 213 549 minecraft:smooth_basalt
fill 96 213 550 96 216 550 minecraft:blackstone
setblock 97 213 514 minecraft:blackstone
setblock 97 213 518 minecraft:smooth_basalt
fill 97 213 519 97 215 519 minecraft:blackstone
setblock 97 213 523 minecraft:smooth_basalt
fill 97 213 524 97 216 524 minecraft:blackstone
setblock 97 213 543 minecraft:smooth_basalt
fill 97 213 544 98 215 544 minecraft:blackstone
setblock 97 213 548 minecraft:smooth_basalt
fill 97 213 549 100 213 549 minecraft:blackstone
setblock 98 213 512 minecraft:smooth_basalt
fill 98 213 545 98 213 546 minecraft:blackstone
setblock 98 213 547 minecraft:smooth_basalt
fill 98 213 548 99 215 548 minecraft:blackstone
setblock 99 213 511 minecraft:smooth_basalt
fill 99 213 512 99 216 512 minecraft:blackstone
setblock 99 213 551 minecraft:smooth_basalt
fill 100 213 511 100 216 511 minecraft:blackstone
setblock 100 213 550 minecraft:smooth_basalt
fill 100 213 551 100 216 551 minecraft:blackstone
setblock 101 213 549 minecraft:smooth_basalt
fill 101 213 550 101 216 550 minecraft:blackstone
fill 102 213 549 102 216 549 minecraft:blackstone
setblock 104 213 550 minecraft:blackstone
setblock 104 213 551 minecraft:smooth_basalt
setblock 105 213 550 minecraft:smooth_basalt
fill 105 213 551 108 213 551 minecraft:blackstone
setblock 109 213 551 minecraft:smooth_basalt
setblock 110 213 550 minecraft:smooth_basalt
fill 110 213 551 113 213 551 minecraft:blackstone
fill 111 213 550 114 213 550 minecraft:blackstone
fill 113 213 549 115 213 549 minecraft:blackstone
setblock 114 213 551 minecraft:smooth_basalt
setblock 115 213 550 minecraft:smooth_basalt
fill 115 213 551 115 216 551 minecraft:blackstone
setblock 116 213 549 minecraft:smooth_basalt
fill 116 213 550 116 216 550 minecraft:blackstone
fill 117 213 549 118 215 549 minecraft:blackstone
setblock 119 213 551 minecraft:smooth_basalt
fill 120 213 551 121 215 551 minecraft:blackstone
fill 132 213 511 132 214 511 minecraft:blackstone
fill 132 213 521 132 213 522 minecraft:blackstone
setblock 132 213 523 minecraft:smooth_basalt
fill 132 213 524 132 216 524 minecraft:blackstone
setblock 133 213 517 minecraft:smooth_basalt
fill 133 213 518 133 216 518 minecraft:blackstone
setblock 133 213 521 minecraft:blackstone
setblock 133 213 522 minecraft:smooth_basalt
fill 133 213 523 133 216 523 minecraft:blackstone
setblock 133 213 527 minecraft:smooth_basalt
setblock 133 213 551 minecraft:blackstone
setblock 134 213 511 minecraft:smooth_basalt
fill 134 213 512 134 215 513 minecraft:blackstone
setblock 134 213 516 minecraft:smooth_basalt
fill 134 213 517 134 216 517 minecraft:blackstone
setblock 134 213 521 minecraft:smooth_basalt
fill 134 213 522 134 216 522 minecraft:blackstone
setblock 134 213 525 minecraft:blackstone
setblock 134 213 526 minecraft:smooth_basalt
fill 134 213 527 134 216 527 minecraft:blackstone
setblock 134 213 530 minecraft:blackstone
setblock 134 213 540 minecraft:blackstone
setblock 134 213 541 minecraft:smooth_basalt
fill 134 213 542 134 213 545 minecraft:blackstone
setblock 134 213 546 minecraft:smooth_basalt
fill 134 213 547 134 215 548 minecraft:blackstone
setblock 134 213 551 minecraft:smooth_basalt
fill 135 213 511 135 216 511 minecraft:blackstone
setblock 135 213 515 minecraft:smooth_basalt
fill 135 213 516 135 216 516 minecraft:blackstone
setblock 135 213 520 minecraft:smooth_basalt
fill 135 213 521 135 216 521 minecraft:blackstone
setblock 135 213 525 minecraft:smooth_basalt
fill 135 213 526 135 216 526 minecraft:blackstone
setblock 135 213 529 minecraft:blackstone
setblock 135 213 530 minecraft:smooth_basalt
fill 135 213 531 135 216 531 minecraft:blackstone
setblock 135 213 535 minecraft:smooth_basalt
fill 135 213 536 135 216 536 minecraft:blackstone
setblock 135 213 540 minecraft:smooth_basalt
fill 135 213 541 135 216 541 minecraft:blackstone
setblock 135 213 544 minecraft:blackstone
setblock 135 213 545 minecraft:smooth_basalt
fill 135 213 546 135 216 546 minecraft:blackstone
setblock 135 213 550 minecraft:smooth_basalt
fill 135 213 551 135 216 551 minecraft:blackstone
setblock 95 214 514 minecraft:smooth_basalt
fill 95 214 515 95 217 515 minecraft:blackstone
setblock 95 214 519 minecraft:smooth_basalt
fill 95 214 520 95 217 520 minecraft:blackstone
setblock 95 214 524 minecraft:smooth_basalt
fill 95 214 525 95 217 525 minecraft:blackstone
setblock 95 214 529 minecraft:smooth_basalt
fill 95 214 530 95 217 530 minecraft:blackstone
fill 95 214 532 95 214 533 minecraft:blackstone
fill 95 214 535 95 216 535 minecraft:blackstone
setblock 95 214 539 minecraft:smooth_basalt
fill 95 214 540 95 217 540 minecraft:blackstone
setblock 95 214 544 minecraft:smooth_basalt
fill 95 214 545 95 217 545 minecraft:blackstone
setblock 95 214 549 minecraft:smooth_basalt
fill 95 214 550 95 217 550 minecraft:blackstone
setblock 96 214 513 minecraft:smooth_basalt
fill 96 214 514 96 217 514 minecraft:blackstone
setblock 96 214 518 minecraft:smooth_basalt
fill 96 214 519 96 217 519 minecraft:blackstone
setblock 96 214 523 minecraft:smooth_basalt
fill 96 214 524 96 217 524 minecraft:blackstone
setblock 96 214 528 minecraft:smooth_basalt
fill 96 214 529 96 217 529 minecraft:blackstone
fill 96 214 539 96 215 539 minecraft:blackstone
setblock 96 214 542 minecraft:blackstone
setblock 96 214 543 minecraft:smooth_basalt
fill 96 214 544 96 217 544 minecraft:blackstone
setblock 96 214 547 minecraft:blackstone
setblock 96 214 548 minecraft:smooth_basalt
fill 96 214 549 99 214 549 minecraft:blackstone
setblock 97 214 512 minecraft:smooth_basalt
fill 97 214 514 97 221 515 minecraft:smooth_basalt
setblock 97 214 517 minecraft:smooth_basalt
fill 97 214 518 97 215 518 minecraft:blackstone
setblock 97 214 522 minecraft:smooth_basalt
fill 97 214 523 97 216 523 minecraft:blackstone
setblock 97 214 526 minecraft:blackstone
setblock 97 214 542 minecraft:smooth_basalt
fill 97 214 543 97 217 543 minecraft:blackstone
setblock 97 214 547 minecraft:smooth_basalt
fill 97 214 548 97 217 548 minecraft:blackstone
setblock 98 214 511 minecraft:smooth_basalt
fill 98 214 512 98 217 512 minecraft:blackstone
setblock 98 214 545 minecraft:blackstone
setblock 98 214 546 minecraft:smooth_basalt
fill 98 214 547 98 217 547 minecraft:blackstone
setblock 98 214 551 minecraft:smooth_basalt
fill 99 214 511 99 217 511 minecraft:blackstone
setblock 99 214 550 minecraft:smooth_basalt
fill 99 214 551 99 217 551 minecraft:blackstone
setblock 100 214 548 minecraft:blackstone
setblock 100 214 549 minecraft:smooth_basalt
fill 100 214 550 100 217 550 minecraft:blackstone
fill 101 214 549 101 217 549 minecraft:blackstone
fill 103 214 549 103 215 549 minecraft:blackstone
setblock 103 214 551 minecraft:smooth_basalt
setblock 104 214 550 minecraft:smooth_basalt
fill 104 214 551 107 214 551 minecraft:blackstone
fill 105 214 550 108 214 550 minecraft:blackstone
setblock 108 214 551 minecraft:smooth_basalt
setblock 109 214 550 minecraft:smooth_basalt
fill 109 214 551 112 214 551 minecraft:blackstone
fill 110 214 550 113 214 550 minecraft:blackstone
fill 111 214 549 114 214 549 minecraft:blackstone
setblock 113 214 551 minecraft:smooth_basalt
fill 114 214 548 115 214 548 minecraft:blackstone
setblock 114 214 550 minecraft:smooth_basalt
fill 114 214 551 114 217 551 minecraft:blackstone
fill 115 214 511 117 214 511 minecraft:blackstone
setblock 115 214 549 minecraft:smooth_basalt
fill 115 214 550 115 217 550 minecraft:blackstone
setblock 116 214 548 minecraft:smooth_basalt
fill 116 214 549 116 217 549 minecraft:blackstone
setblock 118 214 551 minecraft:smooth_basalt
setblock 119 214 550 minecraft:smooth_basalt
fill 119 214 551 119 217 551 minecraft:blackstone
fill 120 214 550 120 215 550 minecraft:blackstone
fill 131 214 511 131 215 511 minecraft:blackstone
fill 132 214 520 132 214 521 minecraft:blackstone
setblock 132 214 522 minecraft:smooth_basalt
fill 132 214 523 132 217 523 minecraft:blackstone
fill 132 214 525 132 215 525 minecraft:blackstone
setblock 132 214 551 minecraft:blackstone
setblock 133 214 511 minecraft:smooth_basalt
fill 133 214 512 133 217 512 minecraft:blackstone
fill 133 214 517 133 217 517 minecraft:blackstone
setblock 133 214 521 minecraft:smooth_basalt
fill 133 214 522 133 217 522 minecraft:blackstone
setblock 133 214 526 minecraft:smooth_basalt
fill 133 214 527 133 216 528 minecraft:blackstone
setblock 133 214 551 minecraft:smooth_basalt
fill 134 214 511 134 217 511 minecraft:blackstone
setblock 134 214 515 minecraft:smooth_basalt
fill 134 214 516 134 217 516 minecraft:blackstone
setblock 134 214 520 minecraft:smooth_basalt
fill 134 214 521 134 217 521 minecraft:blackstone
setblock 134 214 525 minecraft:smooth_basalt
fill 134 214 526 134 217 526 minecraft:blackstone
setblock 134 214 530 minecraft:smooth_basalt
fill 134 214 531 134 217 531 minecraft:blackstone
setblock 134 214 540 minecraft:smooth_basalt
fill 134 214 541 134 214 544 minecraft:blackstone
setblock 134 214 545 minecraft:smooth_basalt
fill 134 214 546 134 217 546 minecraft:blackstone
setblock 134 214 549 minecraft:blackstone
setblock 134 214 550 minecraft:smooth_basalt
fill 134 214 551 134 217 551 minecraft:blackstone
setblock 135 214 514 minecraft:smooth_basalt
fill 135 214 515 135 217 515 minecraft:blackstone
setblock 135 214 519 minecraft:smooth_basalt
fill 135 214 520 135 217 520 minecraft:blackstone
setblock 135 214 524 minecraft:smooth_basalt
fill 135 214 525 135 217 525 minecraft:blackstone
setblock 135 214 529 minecraft:smooth_basalt
fill 135 214 530 135 217 530 minecraft:blackstone
fill 135 214 532 135 214 533 minecraft:blackstone
setblock 135 214 534 minecraft:smooth_basalt
fill 135 214 535 135 217 535 minecraft:blackstone
setblock 135 214 539 minecraft:smooth_basalt
fill 135 214 540 135 217 540 minecraft:blackstone
setblock 135 214 544 minecraft:smooth_basalt
fill 135 214 545 135 217 545 minecraft:blackstone
setblock 135 214 548 minecraft:blackstone
setblock 135 214 549 minecraft:smooth_basalt
fill 135 214 550 135 217 550 minecraft:blackstone
setblock 95 215 513 minecraft:smooth_basalt
fill 95 215 514 95 218 514 minecraft:blackstone
setblock 95 215 518 minecraft:smooth_basalt
fill 95 215 519 95 218 519 minecraft:blackstone
setblock 95 215 523 minecraft:smooth_basalt
fill 95 215 524 95 218 524 minecraft:blackstone
setblock 95 215 527 minecraft:blackstone
setblock 95 215 528 minecraft:smooth_basalt
fill 95 215 529 95 218 529 minecraft:blackstone
setblock 95 215 532 minecraft:blackstone
setblock 95 215 533 minecraft:smooth_basalt
fill 95 215 534 95 218 534 minecraft:blackstone
setblock 95 215 538 minecraft:smooth_basalt
fill 95 215 539 95 218 539 minecraft:blackstone
setblock 95 215 543 minecraft:smooth_basalt
fill 95 215 544 95 218 544 minecraft:blackstone
setblock 95 215 548 minecraft:smooth_basalt
fill 95 215 549 98 215 549 minecraft:blackstone
setblock 96 215 512 minecraft:smooth_basalt
fill 96 215 513 96 218 513 minecraft:blackstone
setblock 96 215 517 minecraft:smooth_basalt
fill 96 215 518 96 217 518 minecraft:blackstone
setblock 96 215 522 minecraft:smooth_basalt
fill 96 215 523 96 218 523 minecraft:blackstone
setblock 96 215 527 minecraft:smooth_basalt
fill 96 215 528 96 218 528 minecraft:blackstone
fill 96 215 530 96 216 530 minecraft:blackstone
setblock 96 215 541 minecraft:blackstone
setblock 96 215 542 minecraft:smooth_basalt
fill 96 215 543 96 218 543 minecraft:blackstone
setblock 96 215 547 minecraft:smooth_basalt
fill 96 215 548 96 218 548 minecraft:blackstone
setblock 97 215 511 minecraft:smooth_basalt
fill 97 215 512 97 218 512 minecraft:blackstone
setblock 97 215 521 minecraft:smooth_basalt
fill 97 215 522 97 216 522 minecraft:blackstone
setblock 97 215 526 minecraft:smooth_basalt
setblock 97 215 541 minecraft:smooth_basalt
fill 97 215 542 97 216 542 minecraft:blackstone
setblock 97 215 546 minecraft:smooth_basalt
fill 97 215 547 97 218 547 minecraft:blackstone
setblock 97 215 551 minecraft:smooth_basalt
fill 98 215 511 98 218 511 minecraft:blackstone
setblock 98 215 545 minecraft:smooth_basalt
fill 98 215 546 98 217 546 minecraft:blackstone
setblock 98 215 550 minecraft:smooth_basalt
fill 98 215 551 98 218 551 minecraft:blackstone
setblock 99 215 549 minecraft:smooth_basalt
fill 99 215 550 99 218 550 minecraft:blackstone
setblock 100 215 548 minecraft:smooth_basalt
fill 100 215 549 100 218 549 minecraft:blackstone
setblock 102 215 511 minecraft:smooth_basalt
setblock 102 215 550 minecraft:blackstone
setblock 102 215 551 minecraft:smooth_basalt
setblock 103 215 550 minecraft:smooth_basalt
fill 103 215 551 106 215 551 minecraft:blackstone
fill 104 215 550 107 215 550 minecraft:blackstone
setblock 107 215 551 minecraft:smooth_basalt
setblock 108 215 550 minecraft:smooth_basalt
fill 108 215 551 111 215 551 minecraft:blackstone
setblock 109 215 549 minecraft:smooth_basalt
fill 109 215 550 112 215 550 minecraft:blackstone
fill 110 215 549 113 215 549 minecraft:blackstone
fill 112 215 548 114 215 548 minecraft:blackstone
setblock 112 215 551 minecraft:smooth_basalt
fill 113 215 511 116 215 511 minecraft:blackstone
setblock 113 215 550 minecraft:smooth_basalt
fill 113 215 551 113 218 551 minecraft:blackstone
setblock 114 215 549 minecraft:smooth_basalt
fill 114 215 550 114 218 550 minecraft:blackstone
setblock 115 215 548 minecraft:smooth_basalt
fill 115 215 549 115 218 549 minecraft:blackstone
fill 116 215 548 116 216 548 minecraft:blackstone
setblock 117 215 511 minecraft:smooth_basalt
setblock 117 215 551 minecraft:smooth_basalt
setblock 118 215 511 minecraft:blackstone
setblock 118 215 550 minecraft:smooth_basalt
fill 118 215 551 118 218 551 minecraft:blackstone
fill 119 215 550 119 217 550 minecraft:blackstone
fill 130 215 511 130 216 511 minecraft:blackstone
setblock 131 215 551 minecraft:blackstone
setblock 132 215 511 minecraft:smooth_basalt
setblock 132 215 520 minecraft:blackstone
setblock 132 215 521 minecraft:smooth_basalt
fill 132 215 522 132 217 522 minecraft:blackstone
setblock 132 215 526 minecraft:smooth_basalt
setblock 132 215 550 minecraft:blackstone
setblock 132 215 551 minecraft:smooth_basalt
fill 133 215 511 133 218 511 minecraft:blackstone
fill 133 215 516 133 216 516 minecraft:blackstone
setblock 133 215 520 minecraft:smooth_basalt
fill 133 215 521 133 218 521 minecraft:blackstone
setblock 133 215 525 minecraft:smooth_basalt
fill 133 215 526 133 218 526 minecraft:blackstone
setblock 133 215 529 minecraft:blackstone
setblock 133 215 550 minecraft:smooth_basalt
fill 133 215 551 133 218 551 minecraft:blackstone
setblock 134 215 514 minecraft:smooth_basalt
fill 134 215 515 134 218 515 minecraft:blackstone
setblock 134 215 519 minecraft:smooth_basalt
fill 134 215 520 134 218 520 minecraft:blackstone
setblock 134 215 524 minecraft:smooth_basalt
fill 134 215 525 134 218 525 minecraft:blackstone
setblock 134 215 528 minecraft:blackstone
setblock 134 215 529 minecraft:smooth_basalt
fill 134 215 530 134 218 530 minecraft:blackstone
fill 134 215 532 135 215 532 minecraft:blackstone
fill 134 215 541 134 215 543 minecraft:blackstone
setblock 134 215 544 minecraft:smooth_basalt
fill 134 215 545 134 218 545 minecraft:blackstone
setblock 134 215 549 minecraft:smooth_basalt
fill 134 215 550 134 218 550 minecraft:blackstone
setblock 135 215 513 minecraft:smooth_basalt
fill 135 215 514 135 218 514 minecraft:blackstone
setblock 135 215 518 minecraft:smooth_basalt
fill 135 215 519 135 218 519 minecraft:blackstone
setblock 135 215 523 minecraft:smooth_basalt
fill 135 215 524 135 218 524 minecraft:blackstone
setblock 135 215 528 minecraft:smooth_basalt
fill 135 215 529 135 218 529 minecraft:blackstone
setblock 135 215 533 minecraft:smooth_basalt
fill 135 215 534 135 218 534 minecraft:blackstone
setblock 135 215 538 minecraft:smooth_basalt
fill 135 215 539 135 217 539 minecraft:blackstone
setblock 135 215 543 minecraft:smooth_basalt
fill 135 215 544 135 218 544 minecraft:blackstone
setblock 135 215 548 minecraft:smooth_basalt
fill 135 215 549 135 218 549 minecraft:blackstone
setblock 95 216 512 minecraft:smooth_basalt
fill 95 216 513 95 219 513 minecraft:blackstone
setblock 95 216 517 minecraft:smooth_basalt
fill 95 216 518 95 219 518 minecraft:blackstone
setblock 95 216 522 minecraft:smooth_basalt
fill 95 216 523 95 219 523 minecraft:blackstone
setblock 95 216 527 minecraft:smooth_basalt
fill 95 216 528 95 219 528 minecraft:blackstone
setblock 95 216 532 minecraft:smooth_basalt
fill 95 216 533 95 219 533 minecraft:blackstone
setblock 95 216 537 minecraft:smooth_basalt
fill 95 216 538 95 217 538 minecraft:blackstone
setblock 95 216 542 minecraft:smooth_basalt
fill 95 216 543 95 219 543 minecraft:blackstone
setblock 95 216 547 minecraft:smooth_basalt
fill 95 216 548 95 218 549 minecraft:blackstone
setblock 96 216 511 minecraft:smooth_basalt
fill 96 216 512 96 219 512 minecraft:blackstone
setblock 96 216 516 minecraft:smooth_basalt
fill 96 216 517 96 217 517 minecraft:blackstone
setblock 96 216 521 minecraft:smooth_basalt
fill 96 216 522 96 218 522 minecraft:blackstone
setblock 96 216 526 minecraft:smooth_basalt
fill 96 216 527 96 219 527 minecraft:blackstone
setblock 96 216 541 minecraft:smooth_basalt
fill 96 216 542 96 218 542 minecraft:blackstone
setblock 96 216 546 minecraft:smooth_basalt
fill 96 216 547 96 219 547 minecraft:blackstone
fill 96 216 549 97 216 549 minecraft:blackstone
setblock 96 216 551 minecraft:smooth_basalt
fill 97 216 511 97 219 511 minecraft:blackstone
setblock 97 216 521 minecraft:blackstone
setblock 97 216 525 minecraft:smooth_basalt
setblock 97 216 526 minecraft:blackstone
setblock 97 216 529 minecraft:light[level=12]
setblock 97 216 537 minecraft:light[level=12]
setblock 97 216 544 minecraft:blackstone
setblock 97 216 545 minecraft:smooth_basalt
fill 97 216 546 97 219 546 minecraft:blackstone
setblock 97 216 550 minecraft:smooth_basalt
fill 97 216 551 97 219 551 minecraft:blackstone
setblock 98 216 545 minecraft:blackstone
setblock 98 216 548 minecraft:blackstone
setblock 98 216 549 minecraft:smooth_basalt
fill 98 216 550 98 219 550 minecraft:blackstone
setblock 99 216 548 minecraft:smooth_basalt
fill 99 216 549 99 219 549 minecraft:blackstone
setblock 100 216 548 minecraft:blackstone
setblock 101 216 511 minecraft:smooth_basalt
setblock 101 216 551 minecraft:smooth_basalt
setblock 102 216 511 minecraft:blackstone
setblock 102 216 550 minecraft:smooth_basalt
fill 102 216 551 105 216 551 minecraft:blackstone
setblock 103 216 549 minecraft:smooth_basalt
fill 103 216 550 106 216 550 minecraft:blackstone
setblock 105 216 513 minecraft:light[level=12]
setblock 105 216 521 minecraft:light[level=12]
setblock 105 216 529 minecraft:light[level=12]
setblock 105 216 537 minecraft:light[level=12]
setblock 105 216 545 minecraft:light[level=12]
setblock 106 216 551 minecraft:smooth_basalt
setblock 107 216 550 minecraft:smooth_basalt
fill 107 216 551 110 216 551 minecraft:blackstone
setblock 108 216 549 minecraft:smooth_basalt
fill 108 216 550 111 216 550 minecraft:blackstone
fill 109 216 549 112 216 549 minecraft:blackstone
fill 111 216 548 113 216 548 minecraft:blackstone
setblock 111 216 551 minecraft:smooth_basalt
fill 112 216 511 115 216 511 minecraft:blackstone
setblock 112 216 550 minecraft:smooth_basalt
fill 112 216 551 112 219 551 minecraft:blackstone
setblock 113 216 513 minecraft:light[level=12]
setblock 113 216 521 minecraft:light[level=12]
setblock 113 216 529 minecraft:light[level=12]
setblock 113 216 537 minecraft:light[level=12]
setblock 113 216 545 minecraft:light[level=12]
setblock 113 216 549 minecraft:smooth_basalt
fill 113 216 550 113 219 550 minecraft:blackstone
setblock 114 216 548 minecraft:smooth_basalt
fill 114 216 549 114 219 549 minecraft:blackstone
fill 115 216 548 115 217 548 minecraft:blackstone
setblock 116 216 511 minecraft:smooth_basalt
setblock 116 216 551 minecraft:smooth_basalt
fill 117 216 511 117 218 511 minecraft:blackstone
setblock 117 216 549 minecraft:blackstone
setblock 117 216 550 minecraft:smooth_basalt
fill 117 216 551 117 219 551 minecraft:blackstone
setblock 118 216 549 minecraft:smooth_basalt
fill 118 216 550 118 218 550 minecraft:blackstone
setblock 120 216 551 minecraft:blackstone
setblock 121 216 513 minecraft:light[level=12]
setblock 121 216 521 minecraft:light[level=12]
setblock 121 216 529 minecraft:light[level=12]
setblock 121 216 537 minecraft:light[level=12]
setblock 121 216 545 minecraft:light[level=12]
setblock 121 216 551 minecraft:smooth_basalt
setblock 129 216 513 minecraft:light[level=12]
setblock 129 216 521 minecraft:light[level=12]
setblock 129 216 529 minecraft:light[level=12]
setblock 129 216 537 minecraft:light[level=12]
setblock 129 216 545 minecraft:light[level=12]
setblock 130 216 551 minecraft:blackstone
setblock 131 216 511 minecraft:smooth_basalt
setblock 131 216 551 minecraft:smooth_basalt
fill 132 216 511 132 218 512 minecraft:blackstone
setblock 132 216 521 minecraft:blackstone
setblock 132 216 525 minecraft:smooth_basalt
fill 132 216 526 132 218 527 minecraft:blackstone
setblock 132 216 550 minecraft:smooth_basalt
fill 132 216 551 132 219 551 minecraft:blackstone
setblock 133 216 519 minecraft:smooth_basalt
fill 133 216 520 133 219 520 minecraft:blackstone
setblock 133 216 524 minecraft:smooth_basalt
fill 133 216 525 133 219 525 minecraft:blackstone
setblock 133 216 529 minecraft:smooth_basalt
fill 133 216 530 133 219 530 minecraft:blackstone
fill 133 216 547 134 216 547 minecraft:blackstone
fill 133 216 550 133 219 550 minecraft:blackstone
setblock 134 216 512 minecraft:blackstone
setblock 134 216 513 minecraft:smooth_basalt
fill 134 216 514 134 219 514 minecraft:blackstone
setblock 134 216 518 minecraft:smooth_basalt
fill 134 216 519 134 219 519 minecraft:blackstone
setblock 134 216 523 minecraft:smooth_basalt
fill 134 216 524 134 219 524 minecraft:blackstone
setblock 134 216 528 minecraft:smooth_basalt
fill 134 216 529 134 219 529 minecraft:blackstone
setblock 134 216 532 minecraft:blackstone
setblock 134 216 542 minecraft:blackstone
setblock 134 216 543 minecraft:smooth_basalt
fill 134 216 544 134 218 544 minecraft:blackstone
setblock 134 216 548 minecraft:smooth_basalt
fill 134 216 549 134 219 549 minecraft:blackstone
setblock 135 216 512 minecraft:smooth_basalt
fill 135 216 513 135 219 513 minecraft:blackstone
setblock 135 216 517 minecraft:smooth_basalt
fill 135 216 518 135 219 518 minecraft:blackstone
setblock 135 216 522 minecraft:smooth_basalt
fill 135 216 523 135 219 523 minecraft:blackstone
setblock 135 216 527 minecraft:smooth_basalt
fill 135 216 528 135 219 528 minecraft:blackstone
setblock 135 216 532 minecraft:smooth_basalt
fill 135 216 533 135 219 533 minecraft:blackstone
setblock 135 216 537 minecraft:smooth_basalt
fill 135 216 538 135 217 538 minecraft:blackstone
setblock 135 216 542 minecraft:smooth_basalt
fill 135 216 543 135 219 543 minecraft:blackstone
setblock 135 216 547 minecraft:smooth_basalt
fill 135 216 548 135 219 548 minecraft:blackstone
setblock 95 217 511 minecraft:smooth_basalt
fill 95 217 512 95 220 512 minecraft:blackstone
setblock 95 217 516 minecraft:smooth_basalt
fill 95 217 517 95 220 517 minecraft:blackstone
setblock 95 217 521 minecraft:smooth_basalt
fill 95 217 522 95 220 522 minecraft:blackstone
setblock 95 217 526 minecraft:smooth_basalt
fill 95 217 527 95 220 527 minecraft:blackstone
setblock 95 217 531 minecraft:smooth_basalt
fill 95 217 532 95 220 532 minecraft:blackstone
setblock 95 217 537 minecraft:blackstone
setblock 95 217 541 minecraft:smooth_basalt
fill 95 217 542 95 220 542 minecraft:blackstone
setblock 95 217 546 minecraft:smooth_basalt
fill 95 217 547 95 220 547 minecraft:blackstone
setblock 95 217 551 minecraft:smooth_basalt
fill 96 217 511 96 220 511 minecraft:blackstone
setblock 96 217 515 minecraft:smooth_basalt
setblock 96 217 516 minecraft:blackstone
setblock 96 217 520 minecraft:smooth_basalt
fill 96 217 521 96 218 521 minecraft:blackstone
setblock 96 217 525 minecraft:smooth_basalt
fill 96 217 526 96 219 526 minecraft:blackstone
setblock 96 217 530 minecraft:smooth_basalt
setblock 96 217 541 minecraft:blackstone
setblock 96 217 545 minecraft:smooth_basalt
fill 96 217 546 96 220 546 minecraft:blackstone
setblock 96 217 549 minecraft:blackstone
setblock 96 217 550 minecraft:smooth_basalt
fill 96 217 551 96 220 551 minecraft:blackstone
setblock 97 217 544 minecraft:smooth_basalt
fill 97 217 545 97 219 545 minecraft:blackstone
setblock 97 217 549 minecraft:smooth_basalt
fill 97 217 550 97 220 550 minecraft:blackstone
setblock 98 217 548 minecraft:smooth_basalt
fill 98 217 549 98 220 549 minecraft:blackstone
fill 99 217 512 99 221 512 minecraft:smooth_basalt
setblock 99 217 548 minecraft:blackstone
setblock 100 217 511 minecraft:smooth_basalt
setblock 100 217 551 minecraft:smooth_basalt
fill 101 217 511 101 218 511 minecraft:blackstone
setblock 101 217 550 minecraft:smooth_basalt
fill 101 217 551 104 217 551 minecraft:blackstone
setblock 102 217 549 minecraft:smooth_basalt
fill 102 217 550 105 217 550 minecraft:blackstone
setblock 105 217 551 minecraft:smooth_basalt
setblock 106 217 550 minecraft:smooth_basalt
fill 106 217 551 109 217 551 minecraft:blackstone
fill 107 217 550 110 217 550 minecraft:blackstone
fill 108 217 549 111 217 549 minecraft:blackstone
setblock 110 217 551 minecraft:smooth_basalt
fill 111 217 548 112 217 548 minecraft:blackstone
setblock 111 217 550 minecraft:smooth_basalt
fill 111 217 551 111 220 551 minecraft:blackstone
fill 112 217 511 114 217 511 minecraft:blackstone
setblock 112 217 549 minecraft:smooth_basalt
fill 112 217 550 112 220 550 minecraft:blackstone
setblock 113 217 548 minecraft:smooth_basalt
fill 113 217 549 113 220 549 minecraft:blackstone
setblock 114 217 548 minecraft:blackstone
setblock 115 217 511 minecraft:smooth_basalt
setblock 115 217 551 minecraft:smooth_basalt
fill 116 217 511 116 220 511 minecraft:blackstone
setblock 116 217 550 minecraft:smooth_basalt
fill 116 217 551 116 220 551 minecraft:blackstone
setblock 117 217 549 minecraft:smooth_basalt
fill 117 217 550 117 219 550 minecraft:blackstone
setblock 120 217 551 minecraft:smooth_basalt
setblock 129 217 511 minecraft:blackstone
setblock 129 217 551 minecraft:blackstone
setblock 130 217 511 minecraft:smooth_basalt
setblock 130 217 551 minecraft:smooth_basalt
fill 131 217 511 131 219 512 minecraft:blackstone
setblock 131 217 550 minecraft:smooth_basalt
fill 131 217 551 131 220 551 minecraft:blackstone
setblock 132 217 524 minecraft:smooth_basalt
fill 132 217 525 132 218 525 minecraft:blackstone
fill 132 217 550 132 220 550 minecraft:blackstone
setblock 133 217 518 minecraft:smooth_basalt
fill 133 217 519 133 218 519 minecraft:blackstone
setblock 133 217 523 minecraft:smooth_basalt
fill 133 217 524 133 220 524 minecraft:blackstone
setblock 133 217 527 minecraft:blackstone
setblock 133 217 528 minecraft:smooth_basalt
fill 133 217 529 133 220 529 minecraft:blackstone
setblock 133 217 547 minecraft:blackstone
setblock 133 217 548 minecraft:smooth_basalt
fill 133 217 549 133 220 549 minecraft:blackstone
setblock 134 217 512 minecraft:smooth_basalt
fill 134 217 513 134 220 513 minecraft:blackstone
setblock 134 217 517 minecraft:smooth_basalt
fill 134 217 518 134 220 518 minecraft:blackstone
setblock 134 217 522 minecraft:smooth_basalt
fill 134 217 523 134 220 523 minecraft:blackstone
setblock 134 217 527 minecraft:smooth_basalt
fill 134 217 528 134 220 528 minecraft:blackstone
setblock 134 217 532 minecraft:smooth_basalt
setblock 134 217 543 minecraft:blackstone
setblock 134 217 547 minecraft:smooth_basalt
fill 134 217 548 134 220 548 minecraft:blackstone
setblock 135 217 511 minecraft:smooth_basalt
fill 135 217 512 135 220 512 minecraft:blackstone
setblock 135 217 516 minecraft:smooth_basalt
fill 135 217 517 135 220 517 minecraft:blackstone
setblock 135 217 521 minecraft:smooth_basalt
fill 135 217 522 135 220 522 minecraft:blackstone
setblock 135 217 526 minecraft:smooth_basalt
fill 135 217 527 135 220 527 minecraft:blackstone
setblock 135 217 531 minecraft:smooth_basalt
fill 135 217 532 135 220 532 minecraft:blackstone
setblock 135 217 541 minecraft:smooth_basalt
fill 135 217 542 135 219 542 minecraft:blackstone
setblock 135 217 546 minecraft:smooth_basalt
fill 135 217 547 135 220 547 minecraft:blackstone
setblock 135 217 551 minecraft:smooth_basalt
fill 95 218 511 95 221 511 minecraft:blackstone
setblock 95 218 515 minecraft:smooth_basalt
fill 95 218 516 95 220 516 minecraft:blackstone
setblock 95 218 520 minecraft:smooth_basalt
fill 95 218 521 95 220 521 minecraft:blackstone
setblock 95 218 525 minecraft:smooth_basalt
fill 95 218 526 95 221 526 minecraft:blackstone
setblock 95 218 530 minecraft:smooth_basalt
fill 95 218 531 95 221 531 minecraft:blackstone
setblock 95 218 540 minecraft:smooth_basalt
fill 95 218 541 95 220 541 minecraft:blackstone
setblock 95 218 545 minecraft:smooth_basalt
fill 95 218 546 95 221 546 minecraft:blackstone
setblock 95 218 550 minecraft:smooth_basalt
fill 95 218 551 95 221 551 minecraft:blackstone
fill 96 218 514 96 221 514 minecraft:smooth_basalt
fill 96 218 515 96 218 517 minecraft:gold_block
setblock 96 218 520 minecraft:blackstone
setblock 96 218 524 minecraft:smooth_basalt
fill 96 218 525 96 219 525 minecraft:blackstone
setblock 96 218 529 minecraft:smooth_basalt
setblock 96 218 544 minecraft:smooth_basalt
fill 96 218 545 96 221 545 minecraft:blackstone
setblock 96 218 549 minecraft:smooth_basalt
fill 96 218 550 96 221 550 minecraft:blackstone
fill 97 218 516 99 218 517 minecraft:gold_block
setblock 97 218 544 minecraft:blackstone
setblock 97 218 548 minecraft:smooth_basalt
fill 97 218 549 97 221 549 minecraft:blackstone
fill 98 218 512 98 221 512 minecraft:smooth_basalt
setblock 98 218 548 minecraft:blackstone
setblock 99 218 511 minecraft:smooth_basalt
fill 99 218 515 101 218 515 minecraft:gold_block
setblock 99 218 551 minecraft:smooth_basalt
fill 100 218 511 100 219 511 minecraft:blackstone
fill 100 218 512 101 218 514 minecraft:gold_block
setblock 100 218 516 minecraft:gold_block
setblock 100 218 550 minecraft:smooth_basalt
fill 100 218 551 103 218 551 minecraft:blackstone
setblock 101 218 549 minecraft:smooth_basalt
fill 101 218 550 104 218 550 minecraft:blackstone
setblock 104 218 551 minecraft:smooth_basalt
setblock 105 218 550 minecraft:smooth_basalt
fill 105 218 551 108 218 551 minecraft:blackstone
fill 106 218 550 109 218 550 minecraft:blackstone
fill 108 218 549 110 218 549 minecraft:blackstone
setblock 109 218 551 minecraft:smooth_basalt
setblock 110 218 550 minecraft:smooth_basalt
fill 110 218 551 110 221 551 minecraft:blackstone
fill 111 218 511 113 218 511 minecraft:blackstone
setblock 111 218 549 minecraft:smooth_basalt
fill 111 218 550 111 221 550 minecraft:blackstone
setblock 112 218 548 minecraft:smooth_basalt
fill 112 218 549 112 221 549 minecraft:blackstone
setblock 113 218 548 minecraft:blackstone
setblock 114 218 511 minecraft:smooth_basalt
setblock 114 218 551 minecraft:smooth_basalt
fill 115 218 511 115 221 511 minecraft:blackstone
fill 115 218 525 116 218 527 minecraft:gold_block
setblock 115 218 550 minecraft:smooth_basalt
fill 115 218 551 115 221 551 minecraft:blackstone
fill 116 218 523 117 218 524 minecraft:gold_block
fill 116 218 528 121 218 528 minecraft:gold_block
setblock 116 218 549 minecraft:smooth_basalt
fill 116 218 550 116 220 550 minecraft:blackstone
fill 117 218 529 121 218 529 minecraft:gold_block
fill 118 218 522 119 218 523 minecraft:gold_block
setblock 119 218 551 minecraft:smooth_basalt
fill 120 218 523 121 218 524 minecraft:gold_block
setblock 120 218 551 minecraft:blackstone
fill 121 218 525 122 218 527 minecraft:gold_block
setblock 122 218 524 minecraft:gold_block
setblock 128 218 511 minecraft:blackstone
setblock 128 218 551 minecraft:blackstone
setblock 129 218 511 minecraft:smooth_basalt
setblock 129 218 551 minecraft:smooth_basalt
fill 130 218 511 130 221 511 minecraft:blackstone
setblock 130 218 550 minecraft:smooth_basalt
fill 130 218 551 130 221 551 minecraft:blackstone
fill 131 218 550 131 221 550 minecraft:blackstone
setblock 132 218 523 minecraft:smooth_basalt
setblock 132 218 524 minecraft:blackstone
setblock 133 218 512 minecraft:smooth_basalt
setblock 133 218 518 minecraft:blackstone
setblock 133 218 522 minecraft:smooth_basalt
fill 133 218 523 133 220 523 minecraft:blackstone
setblock 133 218 527 minecraft:smooth_basalt
fill 133 218 528 133 221 528 minecraft:blackstone
setblock 133 218 548 minecraft:blackstone
setblock 134 218 511 minecraft:smooth_basalt
fill 134 218 512 134 221 512 minecraft:blackstone
setblock 134 218 516 minecraft:smooth_basalt
fill 134 218 517 134 221 517 minecraft:blackstone
setblock 134 218 521 minecraft:smooth_basalt
fill 134 218 522 134 221 522 minecraft:blackstone
setblock 134 218 526 minecraft:smooth_basalt
fill 134 218 527 134 221 527 minecraft:blackstone
setblock 134 218 531 minecraft:smooth_basalt
fill 134 218 532 134 220 532 minecraft:blackstone
setblock 134 218 546 minecraft:smooth_basalt
fill 134 218 547 134 221 547 minecraft:blackstone
setblock 134 218 551 minecraft:smooth_basalt
fill 135 218 511 135 221 511 minecraft:blackstone
setblock 135 218 515 minecraft:smooth_basalt
fill 135 218 516 135 221 516 minecraft:blackstone
setblock 135 218 520 minecraft:smooth_basalt
fill 135 218 521 135 221 521 minecraft:blackstone
setblock 135 218 525 minecraft:smooth_basalt
fill 135 218 526 135 221 526 minecraft:blackstone
setblock 135 218 530 minecraft:smooth_basalt
fill 135 218 531 135 221 531 minecraft:blackstone
setblock 135 218 541 minecraft:blackstone
setblock 135 218 545 minecraft:smooth_basalt
fill 135 218 546 135 221 546 minecraft:blackstone
setblock 135 218 550 minecraft:smooth_basalt
fill 135 218 551 135 221 551 minecraft:blackstone
setblock 95 219 514 minecraft:smooth_basalt
fill 95 219 515 95 221 515 minecraft:blackstone
setblock 95 219 519 minecraft:smooth_basalt
fill 95 219 520 95 220 520 minecraft:blackstone
setblock 95 219 524 minecraft:smooth_basalt
fill 95 219 525 95 221 525 minecraft:blackstone
setblock 95 219 529 minecraft:smooth_basalt
fill 95 219 530 95 221 530 minecraft:blackstone
setblock 95 219 540 minecraft:blackstone
setblock 95 219 544 minecraft:smooth_basalt
fill 95 219 545 95 221 545 minecraft:blackstone
setblock 95 219 548 minecraft:blackstone
setblock 95 219 549 minecraft:smooth_basalt
fill 95 219 550 95 221 550 minecraft:blackstone
fill 96 219 513 96 221 513 minecraft:smooth_basalt
fill 96 219 515 96 219 516 minecraft:gold_block
setblock 96 219 524 minecraft:blackstone
setblock 96 219 528 minecraft:smooth_basalt
setblock 96 219 529 minecraft:blackstone
setblock 96 219 543 minecraft:smooth_basalt
fill 96 219 544 96 220 544 minecraft:blackstone
setblock 96 219 548 minecraft:smooth_basalt
fill 96 219 549 96 221 549 minecraft:blackstone
fill 97 219 512 97 221 512 minecraft:smooth_basalt
fill 97 219 516 99 219 516 minecraft:gold_block
setblock 97 219 547 minecraft:smooth_basalt
fill 97 219 548 97 221 548 minecraft:blackstone
setblock 98 219 511 minecraft:smooth_basalt
setblock 98 219 551 minecraft:smooth_basalt
fill 99 219 511 99 221 511 minecraft:blackstone
fill 99 219 515 100 219 515 minecraft:gold_block
setblock 99 219 550 minecraft:smooth_basalt
fill 99 219 551 102 219 551 minecraft:blackstone
fill 100 219 512 100 220 514 minecraft:gold_block
setblock 100 219 549 minecraft:smooth_basalt
fill 100 219 550 103 219 550 minecraft:blackstone
setblock 103 219 551 minecraft:smooth_basalt
setblock 104 219 550 minecraft:smooth_basalt
fill 104 219 551 107 219 551 minecraft:blackstone
fill 105 219 550 108 219 550 minecraft:blackstone
fill 108 219 549 109 219 549 minecraft:blackstone
setblock 108 219 551 minecraft:smooth_basalt
setblock 109 219 550 minecraft:smooth_basalt
fill 109 219 551 109 221 551 minecraft:blackstone
setblock 110 219 549 minecraft:smooth_basalt
fill 110 219 550 110 221 550 minecraft:blackstone
fill 111 219 511 112 219 511 minecraft:blackstone
fill 111 219 549 111 221 549 minecraft:blackstone
setblock 113 219 511 minecraft:smooth_basalt
setblock 113 219 551 minecraft:smooth_basalt
fill 114 219 511 114 221 511 minecraft:blackstone
setblock 114 219 550 minecraft:smooth_basalt
fill 114 219 551 114 221 551 minecraft:blackstone
setblock 115 219 549 minecraft:smooth_basalt
fill 115 219 550 115 221 550 minecraft:blackstone
fill 116 219 524 116 219 527 minecraft:gold_block
fill 117 219 523 117 219 524 minecraft:gold_block
fill 117 219 528 121 219 528 minecraft:gold_block
fill 118 219 523 120 219 523 minecraft:gold_block
fill 118 219 529 119 219 529 minecraft:gold_block
setblock 118 219 551 minecraft:smooth_basalt
setblock 119 219 551 minecraft:blackstone
fill 120 219 524 121 219 524 minecraft:gold_block
fill 121 219 525 121 220 527 minecraft:gold_block
setblock 128 219 511 minecraft:smooth_basalt
setblock 128 219 551 minecraft:smooth_basalt
fill 129 219 511 129 221 511 minecraft:blackstone
fill 129 219 551 129 221 551 minecraft:blackstone
fill 130 219 512 130 220 512 minecraft:blackstone
fill 130 219 550 130 221 550 minecraft:blackstone
setblock 132 219 511 minecraft:blackstone
setblock 132 219 512 minecraft:smooth_basalt
setblock 133 219 511 minecraft:smooth_basalt
fill 133 219 512 133 221 512 minecraft:blackstone
setblock 133 219 521 minecraft:smooth_basalt
fill 133 219 522 133 220 522 minecraft:blackstone
setblock 133 219 526 minecraft:smooth_basalt
fill 133 219 527 133 221 527 minecraft:blackstone
setblock 133 219 551 minecraft:smooth_basalt
fill 134 219 511 134 221 511 minecraft:blackstone
setblock 134 219 515 minecraft:smooth_basalt
fill 134 219 516 134 221 516 minecraft:blackstone
setblock 134 219 520 minecraft:smooth_basalt
fill 134 219 521 134 221 521 minecraft:blackstone
setblock 134 219 525 minecraft:smooth_basalt
fill 134 219 526 134 221 526 minecraft:blackstone
setblock 134 219 530 minecraft:smooth_basalt
fill 134 219 531 134 221 531 minecraft:blackstone
setblock 134 219 545 minecraft:smooth_basalt
fill 134 219 546 134 220 546 minecraft:blackstone
setblock 134 219 550 minecraft:smooth_basalt
fill 134 219 551 134 221 551 minecraft:blackstone
setblock 135 219 514 minecraft:smooth_basalt
fill 135 219 515 135 221 515 minecraft:blackstone
setblock 135 219 519 minecraft:smooth_basalt
fill 135 219 520 135 221 520 minecraft:blackstone
setblock 135 219 524 minecraft:smooth_basalt
fill 135 219 525 135 221 525 minecraft:blackstone
setblock 135 219 529 minecraft:smooth_basalt
fill 135 219 530 135 221 530 minecraft:blackstone
setblock 135 219 534 minecraft:smooth_basalt
setblock 135 219 544 minecraft:smooth_basalt
fill 135 219 545 135 221 545 minecraft:blackstone
setblock 135 219 549 minecraft:smooth_basalt
fill 135 219 550 135 221 550 minecraft:blackstone
setblock 95 220 513 minecraft:smooth_basalt
fill 95 220 514 95 221 514 minecraft:blackstone
setblock 95 220 518 minecraft:smooth_basalt
setblock 95 220 519 minecraft:blackstone
setblock 95 220 523 minecraft:smooth_basalt
fill 95 220 524 95 221 524 minecraft:blackstone
setblock 95 220 528 minecraft:smooth_basalt
fill 95 220 529 95 221 529 minecraft:blackstone
setblock 95 220 533 minecraft:smooth_basalt
setblock 95 220 543 minecraft:smooth_basalt
fill 95 220 544 95 221 544 minecraft:blackstone
setblock 95 220 548 minecraft:smooth_basalt
fill 95 220 549 95 221 549 minecraft:blackstone
setblock 96 220 512 minecraft:smooth_basalt
setblock 96 220 515 minecraft:gold_block
setblock 96 220 547 minecraft:smooth_basalt
fill 96 220 548 96 221 548 minecraft:blackstone
setblock 97 220 511 minecraft:smooth_basalt
fill 97 220 516 98 220 516 minecraft:gold_block
setblock 97 220 547 minecraft:blackstone
setblock 97 220 551 minecraft:smooth_basalt
fill 98 220 511 98 221 511 minecraft:blackstone
setblock 98 220 550 minecraft:smooth_basalt
fill 98 220 551 101 220 551 minecraft:blackstone
setblock 99 220 515 minecraft:gold_block
setblock 99 220 549 minecraft:smooth_basalt
fill 99 220 550 102 220 550 minecraft:blackstone
setblock 102 220 551 minecraft:smooth_basalt
setblock 103 220 550 minecraft:smooth_basalt
fill 103 220 551 106 220 551 minecraft:blackstone
fill 104 220 550 107 220 550 minecraft:blackstone
setblock 107 220 551 minecraft:smooth_basalt
setblock 108 220 550 minecraft:smooth_basalt
fill 108 220 551 108 221 551 minecraft:blackstone
setblock 109 220 549 minecraft:smooth_basalt
fill 109 220 550 109 221 550 minecraft:blackstone
fill 110 220 511 111 220 511 minecraft:blackstone
fill 110 220 549 110 221 549 minecraft:blackstone
setblock 112 220 511 minecraft:smooth_basalt
setblock 112 220 551 minecraft:smooth_basalt
fill 113 220 511 113 221 511 minecraft:blackstone
setblock 113 220 550 minecraft:smooth_basalt
fill 113 220 551 113 221 551 minecraft:blackstone
setblock 114 220 549 minecraft:smooth_basalt
fill 114 220 550 114 221 550 minecraft:blackstone
setblock 116 220 526 minecraft:gold_block
setblock 117 220 524 minecraft:gold_block
fill 117 220 528 120 220 528 minecraft:gold_block
setblock 117 220 551 minecraft:smooth_basalt
fill 118 220 551 118 221 551 minecraft:blackstone
setblock 120 220 524 minecraft:gold_block
setblock 127 220 511 minecraft:smooth_basalt
fill 128 220 511 128 221 511 minecraft:blackstone
fill 128 220 551 128 221 551 minecraft:blackstone
setblock 131 220 511 minecraft:blackstone
setblock 131 220 512 minecraft:smooth_basalt
setblock 132 220 511 minecraft:smooth_basalt
fill 132 220 512 132 221 512 minecraft:blackstone
setblock 132 220 551 minecraft:smooth_basalt
fill 133 220 511 133 221 511 minecraft:blackstone
setblock 133 220 525 minecraft:smooth_basalt
fill 133 220 526 133 221 526 minecraft:blackstone
setblock 133 220 550 minecraft:smooth_basalt
fill 133 220 551 133 221 551 minecraft:blackstone
setblock 134 220 514 minecraft:smooth_basalt
fill 134 220 515 134 221 515 minecraft:blackstone
setblock 134 220 519 minecraft:smooth_basalt
fill 134 220 520 134 221 520 minecraft:blackstone
setblock 134 220 524 minecraft:smooth_basalt
fill 134 220 525 134 221 525 minecraft:blackstone
setblock 134 220 529 minecraft:smooth_basalt
fill 134 220 530 134 221 530 minecraft:blackstone
setblock 134 220 549 minecraft:smooth_basalt
fill 134 220 550 134 221 550 minecraft:blackstone
setblock 135 220 513 minecraft:smooth_basalt
fill 135 220 514 135 221 514 minecraft:blackstone
setblock 135 220 518 minecraft:smooth_basalt
fill 135 220 519 135 221 519 minecraft:blackstone
setblock 135 220 523 minecraft:smooth_basalt
fill 135 220 524 135 221 524 minecraft:blackstone
setblock 135 220 528 minecraft:smooth_basalt
fill 135 220 529 135 221 529 minecraft:blackstone
setblock 135 220 533 minecraft:smooth_basalt
setblock 135 220 543 minecraft:smooth_basalt
fill 135 220 544 135 221 544 minecraft:blackstone
setblock 135 220 548 minecraft:smooth_basalt
fill 135 220 549 135 221 549 minecraft:blackstone
setblock 95 221 512 minecraft:smooth_basalt
setblock 95 221 513 minecraft:blackstone
setblock 95 221 523 minecraft:blackstone
setblock 95 221 527 minecraft:smooth_basalt
setblock 95 221 528 minecraft:blackstone
setblock 95 221 532 minecraft:smooth_basalt
setblock 95 221 533 minecraft:blackstone
setblock 95 221 542 minecraft:smooth_basalt
setblock 95 221 543 minecraft:blackstone
setblock 95 221 547 minecraft:smooth_basalt
setblock 95 221 548 minecraft:blackstone
setblock 96 221 511 minecraft:smooth_basalt
setblock 96 221 512 minecraft:blackstone
setblock 96 221 546 minecraft:smooth_basalt
setblock 96 221 547 minecraft:blackstone
setblock 96 221 551 minecraft:smooth_basalt
setblock 97 221 511 minecraft:blackstone
setblock 97 221 550 minecraft:smooth_basalt
fill 97 221 551 100 221 551 minecraft:blackstone
fill 98 221 550 101 221 550 minecraft:blackstone
setblock 101 221 551 minecraft:smooth_basalt
setblock 102 221 550 minecraft:smooth_basalt
fill 102 221 551 105 221 551 minecraft:blackstone
fill 103 221 550 106 221 550 minecraft:blackstone
setblock 106 221 551 minecraft:smooth_basalt
setblock 107 221 550 minecraft:smooth_basalt
setblock 107 221 551 minecraft:blackstone
setblock 108 221 550 minecraft:blackstone
fill 109 221 511 110 221 511 minecraft:blackstone
setblock 109 221 549 minecraft:blackstone
setblock 111 221 511 minecraft:smooth_basalt
setblock 111 221 551 minecraft:smooth_basalt
setblock 112 221 511 minecraft:blackstone
setblock 112 221 550 minecraft:smooth_basalt
setblock 112 221 551 minecraft:blackstone
setblock 113 221 549 minecraft:smooth_basalt
setblock 113 221 550 minecraft:blackstone
setblock 116 221 551 minecraft:smooth_basalt
setblock 117 221 551 minecraft:blackstone
setblock 126 221 511 minecraft:smooth_basalt
setblock 127 221 511 minecraft:blackstone
setblock 127 221 551 minecraft:blackstone
setblock 129 221 512 minecraft:blackstone
setblock 130 221 512 minecraft:smooth_basalt
setblock 131 221 511 minecraft:smooth_basalt
setblock 131 221 512 minecraft:blackstone
setblock 131 221 551 minecraft:smooth_basalt
setblock 132 221 511 minecraft:blackstone
setblock 132 221 550 minecraft:smooth_basalt
setblock 132 221 551 minecraft:blackstone
setblock 133 221 525 minecraft:blackstone
setblock 133 221 529 minecraft:smooth_basalt
setblock 133 221 550 minecraft:blackstone
setblock 134 221 513 minecraft:smooth_basalt
setblock 134 221 514 minecraft:blackstone
setblock 134 221 518 minecraft:smooth_basalt
setblock 134 221 519 minecraft:blackstone
setblock 134 221 523 minecraft:smooth_basalt
setblock 134 221 524 minecraft:blackstone
setblock 134 221 528 minecraft:smooth_basalt
setblock 134 221 529 minecraft:blackstone
setblock 134 221 548 minecraft:smooth_basalt
setblock 134 221 549 minecraft:blackstone
setblock 135 221 512 minecraft:smooth_basalt
setblock 135 221 513 minecraft:blackstone
setblock 135 221 517 minecraft:smooth_basalt
setblock 135 221 518 minecraft:blackstone
setblock 135 221 522 minecraft:smooth_basalt
setblock 135 221 523 minecraft:blackstone
setblock 135 221 527 minecraft:smooth_basalt
setblock 135 221 528 minecraft:blackstone
setblock 135 221 532 minecraft:smooth_basalt
setblock 135 221 533 minecraft:blackstone
setblock 135 221 547 minecraft:smooth_basalt
setblock 135 221 548 minecraft:blackstone
setblock 97 224 513 minecraft:light[level=12]
setblock 97 224 521 minecraft:light[level=12]
setblock 97 224 529 minecraft:light[level=12]
setblock 97 224 537 minecraft:light[level=12]
setblock 97 224 545 minecraft:light[level=12]
setblock 105 224 513 minecraft:light[level=12]
setblock 105 224 521 minecraft:light[level=12]
setblock 105 224 529 minecraft:light[level=12]
setblock 105 224 537 minecraft:light[level=12]
setblock 105 224 545 minecraft:light[level=12]
setblock 113 224 513 minecraft:light[level=12]
setblock 113 224 521 minecraft:light[level=12]
setblock 113 224 529 minecraft:light[level=12]
setblock 113 224 537 minecraft:light[level=12]
setblock 113 224 545 minecraft:light[level=12]
setblock 121 224 513 minecraft:light[level=12]
setblock 121 224 521 minecraft:light[level=12]
setblock 121 224 529 minecraft:light[level=12]
setblock 121 224 537 minecraft:light[level=12]
setblock 121 224 545 minecraft:light[level=12]
setblock 129 224 513 minecraft:light[level=12]
setblock 129 224 521 minecraft:light[level=12]
setblock 129 224 529 minecraft:light[level=12]
setblock 129 224 537 minecraft:light[level=12]
setblock 129 224 545 minecraft:light[level=12]
fill 106 227 530 106 229 534 minecraft:gold_block
fill 107 227 528 107 229 531 minecraft:gold_block
fill 107 227 532 111 227 532 minecraft:blackstone
fill 107 227 533 107 229 536 minecraft:gold_block
fill 108 227 526 108 229 528 minecraft:gold_block
fill 108 227 529 112 227 531 minecraft:blackstone
fill 108 227 533 112 227 535 minecraft:blackstone
fill 108 227 536 108 229 538 minecraft:gold_block
fill 109 227 526 109 229 527 minecraft:gold_block
fill 109 227 528 119 228 528 minecraft:blackstone
fill 109 227 536 119 228 536 minecraft:blackstone
fill 109 227 537 109 229 538 minecraft:gold_block
fill 110 227 525 110 229 526 minecraft:gold_block
fill 110 227 527 118 228 527 minecraft:blackstone
fill 110 227 537 118 228 537 minecraft:blackstone
fill 110 227 538 110 229 539 minecraft:gold_block
fill 111 227 525 113 229 525 minecraft:gold_block
fill 111 227 526 117 228 526 minecraft:blackstone
fill 111 227 538 117 228 538 minecraft:blackstone
fill 111 227 539 113 229 539 minecraft:gold_block
fill 112 227 524 116 229 524 minecraft:gold_block
fill 112 227 540 116 229 540 minecraft:gold_block
fill 113 227 529 113 227 530 minecraft:blackstone
fill 113 227 534 113 227 535 minecraft:blackstone
fill 114 227 525 114 228 525 minecraft:blackstone
fill 114 227 529 120 227 529 minecraft:blackstone
fill 114 227 535 120 227 535 minecraft:blackstone
fill 114 227 539 114 228 539 minecraft:blackstone
fill 115 227 525 118 229 525 minecraft:gold_block
fill 115 227 530 120 227 530 minecraft:blackstone
fill 115 227 534 120 227 534 minecraft:blackstone
fill 115 227 539 118 229 539 minecraft:gold_block
fill 116 227 531 120 227 531 minecraft:blackstone
fill 116 227 533 120 227 533 minecraft:blackstone
fill 117 227 532 121 227 532 minecraft:blackstone
fill 118 227 526 120 229 526 minecraft:gold_block
fill 118 227 538 120 229 538 minecraft:gold_block
fill 119 227 527 120 229 527 minecraft:gold_block
fill 119 227 537 120 229 537 minecraft:gold_block
fill 120 227 528 121 229 528 minecraft:gold_block
fill 120 227 536 121 229 536 minecraft:gold_block
fill 121 227 529 121 229 531 minecraft:gold_block
fill 121 227 533 121 229 535 minecraft:gold_block
fill 122 227 530 122 229 534 minecraft:gold_block
fill 95 228 511 105 228 551 minecraft:smooth_basalt
fill 106 228 511 106 228 528 minecraft:smooth_basalt
setblock 106 228 529 minecraft:gold_block
setblock 106 228 535 minecraft:gold_block
fill 106 228 536 106 228 551 minecraft:smooth_basalt
fill 107 228 511 107 228 526 minecraft:smooth_basalt
setblock 107 228 527 minecraft:gold_block
fill 107 228 532 110 228 532 minecraft:blackstone
setblock 107 228 537 minecraft:gold_block
fill 107 228 538 107 228 551 minecraft:smooth_basalt
fill 108 228 511 108 228 525 minecraft:smooth_basalt
fill 108 228 529 110 228 531 minecraft:blackstone
fill 108 228 533 110 228 535 minecraft:blackstone
fill 108 228 539 108 228 551 minecraft:smooth_basalt
fill 109 228 511 110 228 524 minecraft:smooth_basalt
setblock 109 228 525 minecraft:gold_block
setblock 109 228 539 minecraft:gold_block
fill 109 228 540 110 228 551 minecraft:smooth_basalt
fill 111 228 511 135 228 523 minecraft:smooth_basalt
setblock 111 228 524 minecraft:gold_block
fill 111 228 529 111 228 530 minecraft:blackstone
fill 111 228 531 111 228 533 minecraft:shroomlight
fill 111 228 534 111 228 535 minecraft:blackstone
setblock 111 228 540 minecraft:gold_block
fill 111 228 541 135 228 551 minecraft:smooth_basalt
setblock 112 228 529 minecraft:blackstone
fill 112 228 530 112 228 531 minecraft:shroomlight
fill 112 228 533 112 228 534 minecraft:shroomlight
setblock 112 228 535 minecraft:blackstone
fill 113 228 529 113 228 530 minecraft:shroomlight
fill 113 228 534 113 228 535 minecraft:shroomlight
fill 114 228 529 115 228 529 minecraft:shroomlight
fill 114 228 535 115 228 535 minecraft:shroomlight
fill 115 228 530 116 228 530 minecraft:shroomlight
fill 115 228 534 116 228 534 minecraft:shroomlight
fill 116 228 529 120 228 529 minecraft:blackstone
fill 116 228 531 117 228 531 minecraft:shroomlight
fill 116 228 533 117 228 533 minecraft:shroomlight
fill 116 228 535 120 228 535 minecraft:blackstone
setblock 117 228 524 minecraft:gold_block
fill 117 228 530 120 228 530 minecraft:blackstone
setblock 117 228 532 minecraft:shroomlight
fill 117 228 534 120 228 534 minecraft:blackstone
setblock 117 228 540 minecraft:gold_block
fill 118 228 524 135 228 524 minecraft:smooth_basalt
fill 118 228 531 120 228 533 minecraft:blackstone
fill 118 228 540 135 228 540 minecraft:smooth_basalt
setblock 119 228 525 minecraft:gold_block
setblock 119 228 539 minecraft:gold_block
fill 120 228 525 135 228 525 minecraft:smooth_basalt
fill 120 228 539 135 228 539 minecraft:smooth_basalt
fill 121 228 526 135 228 526 minecraft:smooth_basalt
setblock 121 228 527 minecraft:gold_block
setblock 121 228 532 minecraft:blackstone
setblock 121 228 537 minecraft:gold_block
fill 121 228 538 135 228 538 minecraft:smooth_basalt
fill 122 228 527 135 228 528 minecraft:smooth_basalt
setblock 122 228 529 minecraft:gold_block
setblock 122 228 535 minecraft:gold_block
fill 122 228 536 135 228 537 minecraft:smooth_basalt
fill 123 228 529 135 228 535 minecraft:smooth_basalt
fill 107 229 532 108 229 532 minecraft:gold_block
fill 108 229 529 108 229 531 minecraft:gold_block
fill 108 229 533 108 229 535 minecraft:gold_block
fill 109 229 528 109 229 529 minecraft:gold_block
fill 109 229 535 109 229 536 minecraft:gold_block
fill 110 229 527 110 229 528 minecraft:gold_block
fill 110 229 536 110 229 537 minecraft:gold_block
fill 111 229 526 111 229 527 minecraft:gold_block
fill 111 229 537 111 229 538 minecraft:gold_block
fill 112 229 526 117 229 526 minecraft:gold_block
fill 112 229 538 117 229 538 minecraft:gold_block
setblock 114 229 525 minecraft:gold_block
setblock 114 229 539 minecraft:gold_block
fill 117 229 527 118 229 527 minecraft:gold_block
fill 117 229 537 118 229 537 minecraft:gold_block
fill 118 229 528 119 229 528 minecraft:gold_block
fill 118 229 536 119 229 536 minecraft:gold_block
fill 119 229 529 120 229 529 minecraft:gold_block
fill 119 229 535 120 229 535 minecraft:gold_block
fill 120 229 530 120 229 534 minecraft:gold_block
setblock 121 229 532 minecraft:gold_block
setblock 95 232 511 minecraft:smooth_basalt
fill 95 232 512 95 232 515 minecraft:blackstone
setblock 95 232 516 minecraft:smooth_basalt
fill 95 232 533 95 232 535 minecraft:blackstone
setblock 95 232 536 minecraft:smooth_basalt
fill 95 232 537 95 232 540 minecraft:blackstone
setblock 95 232 541 minecraft:smooth_basalt
fill 95 232 542 95 232 545 minecraft:blackstone
setblock 95 232 550 minecraft:blackstone
setblock 95 232 551 minecraft:smooth_basalt
setblock 96 232 535 minecraft:smooth_basalt
fill 96 232 536 96 232 539 minecraft:blackstone
setblock 96 232 540 minecraft:smooth_basalt
setblock 96 232 551 minecraft:blackstone
setblock 97 232 513 minecraft:light[level=12]
setblock 97 232 521 minecraft:light[level=12]
setblock 97 232 529 minecraft:light[level=12]
setblock 97 232 537 minecraft:light[level=12]
setblock 97 232 545 minecraft:light[level=12]
setblock 99 232 551 minecraft:blackstone
setblock 100 232 511 minecraft:smooth_basalt
setblock 100 232 551 minecraft:smooth_basalt
fill 101 232 511 104 232 511 minecraft:blackstone
fill 101 232 551 104 232 551 minecraft:blackstone
setblock 103 232 512 minecraft:blackstone
setblock 104 232 512 minecraft:smooth_basalt
setblock 105 232 511 minecraft:smooth_basalt
fill 105 232 512 108 232 512 minecraft:blackstone
setblock 105 232 513 minecraft:light[level=12]
setblock 105 232 521 minecraft:light[level=12]
setblock 105 232 529 minecraft:light[level=12]
setblock 105 232 537 minecraft:light[level=12]
setblock 105 232 545 minecraft:light[level=12]
setblock 105 232 551 minecraft:smooth_basalt
fill 106 232 511 109 232 511 minecraft:blackstone
fill 106 232 551 109 232 551 minecraft:blackstone
setblock 109 232 512 minecraft:smooth_basalt
setblock 110 232 511 minecraft:smooth_basalt
fill 110 232 512 111 232 512 minecraft:blackstone
fill 111 232 511 114 232 511 minecraft:blackstone
setblock 113 232 513 minecraft:light[level=12]
setblock 113 232 521 minecraft:light[level=12]
setblock 113 232 529 minecraft:light[level=12]
setblock 113 232 537 minecraft:light[level=12]
setblock 113 232 545 minecraft:light[level=12]
setblock 115 232 511 minecraft:smooth_basalt
fill 116 232 511 119 232 511 minecraft:blackstone
setblock 119 232 512 minecraft:smooth_basalt
setblock 120 232 511 minecraft:smooth_basalt
fill 120 232 512 123 232 512 minecraft:blackstone
fill 121 232 511 124 232 511 minecraft:blackstone
fill 121 232 513 122 232 513 minecraft:blackstone
setblock 121 232 521 minecraft:light[level=12]
setblock 121 232 529 minecraft:light[level=12]
setblock 121 232 537 minecraft:light[level=12]
setblock 121 232 545 minecraft:light[level=12]
setblock 123 232 513 minecraft:smooth_basalt
fill 123 232 514 126 232 514 minecraft:blackstone
fill 123 232 551 124 232 551 minecraft:blackstone
setblock 124 232 512 minecraft:smooth_basalt
fill 124 232 513 127 232 513 minecraft:blackstone
setblock 125 232 511 minecraft:smooth_basalt
fill 125 232 512 128 232 512 minecraft:blackstone
setblock 125 232 551 minecraft:smooth_basalt
fill 126 232 511 129 232 511 minecraft:blackstone
setblock 126 232 515 minecraft:smooth_basalt
setblock 126 232 550 minecraft:smooth_basalt
fill 126 232 551 129 232 551 minecraft:blackstone
setblock 127 232 514 minecraft:smooth_basalt
fill 127 232 515 128 232 515 minecraft:blackstone
fill 127 232 550 130 232 550 minecraft:blackstone
setblock 128 232 513 minecraft:smooth_basalt
fill 128 232 514 131 232 514 minecraft:blackstone
setblock 129 232 512 minecraft:smooth_basalt
fill 129 232 513 132 232 513 minecraft:blackstone
setblock 129 232 521 minecraft:light[level=12]
setblock 129 232 529 minecraft:light[level=12]
setblock 129 232 537 minecraft:light[level=12]
setblock 129 232 545 minecraft:light[level=12]
setblock 130 232 511 minecraft:smooth_basalt
fill 130 232 512 133 232 512 minecraft:blackstone
setblock 130 232 551 minecraft:smooth_basalt
fill 131 232 511 134 232 511 minecraft:blackstone
fill 131 232 551 134 232 551 minecraft:blackstone
setblock 133 232 513 minecraft:smooth_basalt
fill 133 232 514 135 232 515 minecraft:blackstone
setblock 134 232 512 minecraft:smooth_basalt
fill 134 232 513 135 233 513 minecraft:blackstone
setblock 134 232 516 minecraft:blackstone
setblock 134 232 517 minecraft:smooth_basalt
setblock 135 232 511 minecraft:smooth_basalt
fill 135 232 512 135 234 512 minecraft:blackstone
setblock 135 232 516 minecraft:smooth_basalt
fill 135 232 517 135 232 519 minecraft:blackstone
setblock 135 232 535 minecraft:blackstone
setblock 135 232 536 minecraft:smooth_basalt
fill 135 232 537 135 232 540 minecraft:blackstone
setblock 135 232 541 minecraft:smooth_basalt
setblock 135 232 550 minecraft:blackstone
setblock 135 232 551 minecraft:smooth_basalt
setblock 95 233 534 minecraft:blackstone
setblock 95 233 535 minecraft:smooth_basalt
fill 95 233 536 95 233 539 minecraft:blackstone
setblock 95 233 540 minecraft:smooth_basalt
fill 95 233 541 95 233 544 minecraft:blackstone
fill 96 233 536 96 233 538 minecraft:blackstone
setblock 96 233 539 minecraft:smooth_basalt
fill 96 233 540 96 235 541 minecraft:blackstone
fill 101 233 511 103 233 511 minecraft:blackstone
fill 101 233 551 103 233 551 minecraft:blackstone
setblock 104 233 511 minecraft:smooth_basalt
fill 104 233 512 107 233 512 minecraft:blackstone
setblock 104 233 551 minecraft:smooth_basalt
fill 105 233 511 108 233 511 minecraft:blackstone
fill 105 233 551 107 233 551 minecraft:blackstone
setblock 108 233 512 minecraft:smooth_basalt
setblock 109 233 511 minecraft:smooth_basalt
fill 110 233 511 111 233 511 minecraft:blackstone
setblock 118 233 511 minecraft:blackstone
setblock 119 233 511 minecraft:smooth_basalt
fill 119 233 512 122 233 512 minecraft:blackstone
fill 120 233 511 123 233 511 minecraft:blackstone
setblock 121 233 513 minecraft:blackstone
setblock 122 233 513 minecraft:smooth_basalt
setblock 123 233 512 minecraft:smooth_basalt
fill 123 233 513 125 233 514 minecraft:blackstone
setblock 123 233 551 minecraft:blackstone
setblock 124 233 511 minecraft:smooth_basalt
fill 124 233 512 127 233 512 minecraft:blackstone
setblock 124 233 551 minecraft:smooth_basalt
fill 125 233 511 128 233 511 minecraft:blackstone
fill 125 233 551 128 233 551 minecraft:blackstone
setblock 126 233 513 minecraft:blackstone
setblock 126 233 514 minecraft:smooth_basalt
setblock 127 233 513 minecraft:smooth_basalt
fill 127 233 514 129 233 514 minecraft:blackstone
setblock 128 233 512 minecraft:smooth_basalt
fill 128 233 513 131 233 513 minecraft:blackstone
setblock 129 233 511 minecraft:smooth_basalt
fill 129 233 512 132 233 512 minecraft:blackstone
setblock 129 233 551 minecraft:smooth_basalt
fill 130 233 511 133 233 511 minecraft:blackstone
fill 130 233 551 133 233 551 minecraft:blackstone
setblock 132 233 513 minecraft:smooth_basalt
setblock 133 233 512 minecraft:smooth_basalt
setblock 134 233 511 minecraft:smooth_basalt
setblock 134 233 512 minecraft:blackstone
fill 134 233 514 134 233 515 minecraft:blackstone
setblock 134 233 516 minecraft:smooth_basalt
setblock 134 233 551 minecraft:smooth_basalt
fill 135 233 511 135 234 511 minecraft:blackstone
setblock 135 233 514 minecraft:blackstone
setblock 135 233 515 minecraft:smooth_basalt
fill 135 233 516 135 234 518 minecraft:blackstone
fill 135 233 537 135 233 539 minecraft:blackstone
setblock 135 233 540 minecraft:smooth_basalt
fill 135 233 541 135 236 541 minecraft:blackstone
setblock 95 234 534 minecraft:smooth_basalt
fill 95 234 535 95 234 538 minecraft:blackstone
setblock 95 234 539 minecraft:smooth_basalt
fill 95 234 540 95 234 543 minecraft:blackstone
setblock 95 234 544 minecraft:smooth_basalt
setblock 96 234 537 minecraft:blackstone
setblock 96 234 538 minecraft:smooth_basalt
fill 96 234 539 96 237 539 minecraft:blackstone
setblock 103 234 511 minecraft:smooth_basalt
fill 104 234 511 107 234 511 minecraft:blackstone
fill 104 234 551 105 234 551 minecraft:blackstone
setblock 108 234 511 minecraft:smooth_basalt
setblock 109 234 511 minecraft:blackstone
fill 119 234 511 122 234 511 minecraft:blackstone
fill 120 234 512 121 234 512 minecraft:blackstone
setblock 121 234 513 minecraft:smooth_basalt
setblock 122 234 512 minecraft:smooth_basalt
fill 122 234 513 125 234 513 minecraft:blackstone
setblock 123 234 511 minecraft:smooth_basalt
fill 123 234 512 126 234 512 minecraft:blackstone
fill 123 234 514 124 234 514 minecraft:blackstone
setblock 123 234 551 minecraft:smooth_basalt
fill 124 234 511 127 234 511 minecraft:blackstone
fill 124 234 551 127 234 551 minecraft:blackstone
setblock 125 234 514 minecraft:smooth_basalt
setblock 126 234 513 minecraft:smooth_basalt
fill 126 234 514 128 234 514 minecraft:blackstone
setblock 127 234 512 minecraft:smooth_basalt
fill 127 234 513 130 234 513 minecraft:blackstone
setblock 128 234 511 minecraft:smooth_basalt
fill 128 234 512 131 234 512 minecraft:blackstone
setblock 128 234 551 minecraft:smooth_basalt
fill 129 234 511 132 234 511 minecraft:blackstone
fill 129 234 551 132 234 551 minecraft:blackstone
fill 132 234 512 132 254 512 minecraft:smooth_basalt
setblock 133 234 511 minecraft:smooth_basalt
setblock 134 234 511 minecraft:blackstone
setblock 135 234 513 minecraft:blackstone
setblock 135 234 514 minecraft:smooth_basalt
fill 135 234 515 135 235 515 minecraft:blackstone
setblock 135 234 538 minecraft:blackstone
setblock 135 234 539 minecraft:smooth_basalt
fill 135 234 540 135 237 540 minecraft:blackstone
fill 95 235 535 95 235 537 minecraft:blackstone
setblock 95 235 538 minecraft:smooth_basalt
fill 95 235 539 95 235 542 minecraft:blackstone
setblock 95 235 543 minecraft:smooth_basalt
fill 95 235 544 95 238 544 minecraft:blackstone
setblock 96 235 537 minecraft:smooth_basalt
fill 96 235 538 96 238 538 minecraft:blackstone
fill 104 235 511 106 235 511 minecraft:blackstone
fill 119 235 511 121 235 511 minecraft:blackstone
setblock 120 235 512 minecraft:blackstone
setblock 121 235 512 minecraft:smooth_basalt
setblock 122 235 511 minecraft:smooth_basalt
fill 122 235 512 124 235 513 minecraft:blackstone
fill 123 235 511 126 235 511 minecraft:blackstone
setblock 124 235 514 minecraft:smooth_basalt
fill 124 235 551 126 235 551 minecraft:blackstone
setblock 125 235 512 minecraft:blackstone
setblock 125 235 513 minecraft:smooth_basalt
fill 125 235 514 126 235 514 minecraft:blackstone
setblock 126 235 512 minecraft:smooth_basalt
fill 126 235 513 129 235 513 minecraft:blackstone
setblock 127 235 511 minecraft:smooth_basalt
fill 127 235 512 130 235 512 minecraft:blackstone
setblock 127 235 551 minecraft:smooth_basalt
fill 128 235 511 131 235 511 minecraft:blackstone
fill 128 235 551 130 235 551 minecraft:blackstone
fill 129 235 514 132 273 514 minecraft:smooth_basalt
fill 130 235 513 132 257 513 minecraft:smooth_basalt
fill 130 235 515 132 273 515 minecraft:smooth_basalt
fill 131 235 512 131 255 512 minecraft:smooth_basalt
setblock 132 235 511 minecraft:smooth_basalt
setblock 133 235 511 minecraft:blackstone
setblock 135 235 514 minecraft:blackstone
fill 135 235 516 135 235 517 minecraft:blackstone
fill 135 235 539 135 238 539 minecraft:blackstone
setblock 95 236 536 minecraft:blackstone
setblock 95 236 537 minecraft:smooth_basalt
fill 95 236 538 95 236 541 minecraft:blackstone
setblock 95 236 542 minecraft:smooth_basalt
fill 95 236 543 95 239 543 minecraft:blackstone
setblock 96 236 540 minecraft:blackstone
setblock 96 236 541 minecraft:smooth_basalt
fill 96 236 542 96 239 542 minecraft:blackstone
fill 119 236 511 120 236 511 minecraft:blackstone
setblock 120 236 512 minecraft:smooth_basalt
setblock 121 236 511 minecraft:smooth_basalt
fill 121 236 512 124 236 512 minecraft:blackstone
fill 122 236 511 125 236 511 minecraft:blackstone
fill 122 236 513 123 236 513 minecraft:blackstone
setblock 124 236 513 minecraft:smooth_basalt
fill 124 236 551 125 236 551 minecraft:blackstone
setblock 125 236 512 minecraft:smooth_basalt
fill 125 236 513 128 237 513 minecraft:blackstone
setblock 126 236 511 minecraft:smooth_basalt
fill 126 236 512 129 237 512 minecraft:blackstone
setblock 126 236 551 minecraft:smooth_basalt
fill 127 236 511 130 236 511 minecraft:blackstone
fill 127 236 551 128 237 551 minecraft:blackstone
fill 128 236 514 128 237 514 minecraft:blackstone
fill 129 236 513 129 273 513 minecraft:smooth_basalt
fill 129 236 515 129 237 515 minecraft:blackstone
fill 130 236 512 130 254 512 minecraft:smooth_basalt
fill 130 236 516 132 237 516 minecraft:blackstone
setblock 131 236 511 minecraft:smooth_basalt
fill 132 236 511 132 237 511 minecraft:blackstone
fill 133 236 512 133 237 515 minecraft:blackstone
setblock 135 236 542 minecraft:smooth_basalt
fill 135 236 543 135 239 543 minecraft:blackstone
setblock 95 237 536 minecraft:smooth_basalt
fill 95 237 537 95 237 540 minecraft:blackstone
setblock 95 237 541 minecraft:smooth_basalt
fill 95 237 542 95 240 542 minecraft:blackstone
setblock 95 237 545 minecraft:blackstone
setblock 96 237 540 minecraft:smooth_basalt
fill 96 237 541 96 240 541 minecraft:blackstone
fill 96 237 543 96 238 543 minecraft:blackstone
setblock 119 237 511 minecraft:blackstone
setblock 120 237 511 minecraft:smooth_basalt
fill 120 237 512 123 237 512 minecraft:blackstone
fill 121 237 511 124 237 511 minecraft:blackstone
setblock 122 237 513 minecraft:blackstone
setblock 123 237 513 minecraft:smooth_basalt
fill 123 237 551 124 237 551 minecraft:blackstone
setblock 124 237 512 minecraft:smooth_basalt
fill 124 237 513 124 238 513 minecraft:blackstone
setblock 125 237 511 minecraft:smooth_basalt
fill 125 237 512 125 240 512 minecraft:blackstone
setblock 125 237 551 minecraft:smooth_basalt
fill 126 237 511 129 237 511 minecraft:blackstone
fill 126 237 551 126 240 551 minecraft:blackstone
fill 128 237 515 128 237 516 minecraft:blackstone
setblock 129 237 516 minecraft:blackstone
setblock 130 237 511 minecraft:smooth_basalt
fill 130 237 517 132 237 517 minecraft:blackstone
setblock 131 237 511 minecraft:blackstone
setblock 133 237 511 minecraft:blackstone
setblock 133 237 516 minecraft:blackstone
fill 134 237 512 134 237 515 minecraft:blackstone
setblock 135 237 541 minecraft:smooth_basalt
fill 135 237 542 135 240 542 minecraft:blackstone
fill 135 237 544 135 238 544 minecraft:blackstone
fill 95 238 536 95 238 539 minecraft:blackstone
setblock 95 238 540 minecraft:smooth_basalt
fill 95 238 541 95 241 541 minecraft:blackstone
setblock 95 238 545 minecraft:smooth_basalt
fill 95 238 546 95 241 546 minecraft:blackstone
setblock 96 238 539 minecraft:smooth_basalt
fill 96 238 540 96 241 540 minecraft:blackstone
setblock 96 238 544 minecraft:smooth_basalt
setblock 119 238 511 minecraft:smooth_basalt
fill 120 238 511 122 238 512 minecraft:blackstone
setblock 122 238 513 minecraft:smooth_basalt
fill 122 238 551 123 238 551 minecraft:blackstone
setblock 123 238 511 minecraft:blackstone
setblock 123 238 512 minecraft:smooth_basalt
fill 123 238 513 123 241 513 minecraft:blackstone
setblock 124 238 511 minecraft:smooth_basalt
fill 124 238 512 124 241 512 minecraft:blackstone
setblock 124 238 551 minecraft:smooth_basalt
fill 125 238 511 128 238 511 minecraft:blackstone
fill 125 238 551 125 241 551 minecraft:blackstone
fill 126 238 512 127 238 512 minecraft:blackstone
fill 127 238 551 127 239 551 minecraft:blackstone
setblock 129 238 511 minecraft:smooth_basalt
setblock 135 238 540 minecraft:smooth_basalt
fill 135 238 541 135 241 541 minecraft:blackstone
setblock 135 238 545 minecraft:smooth_basalt
fill 135 238 546 135 241 546 minecraft:blackstone
fill 95 239 536 95 239 538 minecraft:blackstone
setblock 95 239 539 minecraft:smooth_basalt
fill 95 239 540 95 242 540 minecraft:blackstone
setblock 95 239 544 minecraft:smooth_basalt
fill 95 239 545 96 241 545 minecraft:blackstone
fill 95 239 547 95 240 547 minecraft:blackstone
setblock 96 239 537 minecraft:blackstone
setblock 96 239 538 minecraft:smooth_basalt
fill 96 239 539 97 241 539 minecraft:blackstone
setblock 96 239 543 minecraft:smooth_basalt
fill 96 239 544 96 242 544 minecraft:blackstone
fill 97 239 540 97 239 541 minecraft:blackstone
setblock 97 239 542 minecraft:smooth_basalt
fill 97 239 543 97 242 543 minecraft:blackstone
setblock 118 239 511 minecraft:smooth_basalt
fill 119 239 511 122 239 511 minecraft:blackstone
fill 120 239 512 121 239 512 minecraft:blackstone
fill 121 239 551 122 239 551 minecraft:blackstone
setblock 122 239 512 minecraft:smooth_basalt
fill 122 239 513 122 242 513 minecraft:blackstone
setblock 123 239 511 minecraft:smooth_basalt
fill 123 239 512 123 242 512 minecraft:blackstone
setblock 123 239 551 minecraft:smooth_basalt
fill 124 239 511 127 239 511 minecraft:blackstone
fill 124 239 551 124 242 551 minecraft:blackstone
setblock 126 239 512 minecraft:blackstone
setblock 128 239 511 minecraft:smooth_basalt
setblock 128 239 551 minecraft:smooth_basalt
setblock 135 239 538 minecraft:blackstone
setblock 135 239 539 minecraft:smooth_basalt
fill 135 239 540 135 242 540 minecraft:blackstone
setblock 135 239 544 minecraft:smooth_basalt
fill 135 239 545 135 242 545 minecraft:blackstone
fill 135 239 547 135 239 548 minecraft:blackstone
fill 95 240 520 95 240 522 minecraft:blackstone
setblock 95 240 523 minecraft:smooth_basalt
fill 95 240 535 95 240 537 minecraft:blackstone
setblock 95 240 538 minecraft:smooth_basalt
fill 95 240 539 95 243 539 minecraft:blackstone
setblock 95 240 543 minecraft:smooth_basalt
fill 95 240 544 95 243 544 minecraft:blackstone
setblock 95 240 548 minecraft:smooth_basalt
setblock 96 240 537 minecraft:smooth_basalt
fill 96 240 538 97 242 538 minecraft:blackstone
setblock 96 240 542 minecraft:smooth_basalt
fill 96 240 543 96 243 543 minecraft:blackstone
setblock 96 240 546 minecraft:blackstone
setblock 97 240 513 minecraft:light[level=12]
setblock 97 240 521 minecraft:light[level=12]
setblock 97 240 529 minecraft:light[level=12]
setblock 97 240 537 minecraft:light[level=12]
setblock 97 240 540 minecraft:blackstone
setblock 97 240 541 minecraft:smooth_basalt
fill 97 240 542 97 243 542 minecraft:blackstone
fill 97 240 544 97 241 544 minecraft:blackstone
setblock 97 240 545 minecraft:light[level=12]
setblock 105 240 513 minecraft:light[level=12]
setblock 105 240 521 minecraft:light[level=12]
setblock 105 240 529 minecraft:light[level=12]
setblock 105 240 537 minecraft:light[level=12]
setblock 105 240 545 minecraft:light[level=12]
setblock 113 240 513 minecraft:light[level=12]
setblock 113 240 521 minecraft:light[level=12]
setblock 113 240 529 minecraft:light[level=12]
setblock 113 240 537 minecraft:light[level=12]
setblock 113 240 545 minecraft:light[level=12]
setblock 117 240 511 minecraft:smooth_basalt
fill 118 240 511 121 240 511 minecraft:blackstone
fill 119 240 512 120 240 512 minecraft:blackstone
fill 120 240 551 121 240 551 minecraft:blackstone
setblock 121 240 512 minecraft:smooth_basalt
setblock 121 240 513 minecraft:light[level=12]
setblock 121 240 521 minecraft:light[level=12]
setblock 121 240 529 minecraft:light[level=12]
setblock 121 240 537 minecraft:light[level=12]
setblock 121 240 545 minecraft:light[level=12]
setblock 122 240 511 minecraft:smooth_basalt
fill 122 240 512 122 243 512 minecraft:blackstone
setblock 122 240 551 minecraft:smooth_basalt
fill 123 240 511 126 240 511 minecraft:blackstone
setblock 123 240 550 minecraft:smooth_basalt
fill 123 240 551 123 243 551 minecraft:blackstone
fill 124 240 550 125 242 550 minecraft:blackstone
setblock 126 240 512 minecraft:smooth_basalt
setblock 127 240 511 minecraft:smooth_basalt
setblock 127 240 551 minecraft:smooth_basalt
fill 128 240 511 128 243 511 minecraft:blackstone
fill 128 240 551 129 242 551 minecraft:blackstone
setblock 129 240 521 minecraft:light[level=12]
setblock 129 240 529 minecraft:light[level=12]
setblock 129 240 537 minecraft:light[level=12]
setblock 129 240 545 minecraft:light[level=12]
fill 134 240 541 134 240 543 minecraft:blackstone
setblock 134 240 544 minecraft:smooth_basalt
fill 134 240 545 134 242 546 minecraft:blackstone
setblock 135 240 538 minecraft:smooth_basalt
fill 135 240 539 135 243 539 minecraft:blackstone
setblock 135 240 543 minecraft:smooth_basalt
fill 135 240 544 135 243 544 minecraft:blackstone
setblock 135 240 547 minecraft:blackstone
setblock 135 240 548 minecraft:smooth_basalt
fill 135 240 549 135 242 550 minecraft:blackstone
fill 95 241 519 95 241 521 minecraft:blackstone
setblock 95 241 522 minecraft:smooth_basalt
fill 95 241 523 95 241 526 minecraft:blackstone
setblock 95 241 527 minecraft:smooth_basalt
fill 95 241 534 95 241 536 minecraft:blackstone
setblock 95 241 537 minecraft:smooth_basalt
fill 95 241 538 95 244 538 minecraft:blackstone
setblock 95 241 542 minecraft:smooth_basalt
fill 95 241 543 95 244 543 minecraft:blackstone
setblock 95 241 547 minecraft:smooth_basalt
fill 95 241 548 95 243 549 minecraft:blackstone
fill 96 241 522 96 242 524 minecraft:blackstone
setblock 96 241 536 minecraft:smooth_basalt
fill 96 241 537 96 244 537 minecraft:blackstone
setblock 96 241 541 minecraft:smooth_basalt
fill 96 241 542 96 244 542 minecraft:blackstone
setblock 96 241 546 minecraft:smooth_basalt
fill 96 241 547 96 243 548 minecraft:blackstone
setblock 97 241 540 minecraft:smooth_basalt
fill 97 241 541 98 243 541 minecraft:blackstone
setblock 97 241 545 minecraft:smooth_basalt
fill 97 241 546 97 244 546 minecraft:blackstone
fill 98 241 542 98 241 543 minecraft:blackstone
fill 98 241 551 100 241 551 minecraft:blackstone
setblock 101 241 551 minecraft:smooth_basalt
fill 102 241 551 103 243 551 minecraft:blackstone
setblock 116 241 511 minecraft:smooth_basalt
fill 117 241 511 120 241 511 minecraft:blackstone
fill 118 241 512 119 241 512 minecraft:blackstone
fill 118 241 551 120 241 551 minecraft:blackstone
setblock 120 241 512 minecraft:smooth_basalt
fill 120 241 550 121 241 550 minecraft:blackstone
setblock 121 241 511 minecraft:smooth_basalt
fill 121 241 512 121 243 513 minecraft:blackstone
setblock 121 241 551 minecraft:smooth_basalt
fill 122 241 511 125 241 511 minecraft:blackstone
setblock 122 241 550 minecraft:smooth_basalt
fill 122 241 551 122 244 551 minecraft:blackstone
fill 123 241 550 123 244 550 minecraft:blackstone
setblock 125 241 512 minecraft:smooth_basalt
setblock 126 241 511 minecraft:smooth_basalt
setblock 126 241 512 minecraft:blackstone
setblock 126 241 550 minecraft:blackstone
setblock 126 241 551 minecraft:smooth_basalt
fill 127 241 511 127 244 511 minecraft:blackstone
fill 127 241 551 127 244 551 minecraft:blackstone
setblock 130 241 551 minecraft:blackstone
fill 133 241 551 135 241 551 minecraft:blackstone
fill 134 241 540 134 241 542 minecraft:blackstone
setblock 134 241 543 minecraft:smooth_basalt
fill 134 241 544 134 244 544 minecraft:blackstone
setblock 134 241 547 minecraft:blackstone
setblock 134 241 548 minecraft:smooth_basalt
fill 135 241 519 135 241 521 minecraft:blackstone
setblock 135 241 522 minecraft:smooth_basalt
setblock 135 241 537 minecraft:smooth_basalt
fill 135 241 538 135 244 538 minecraft:blackstone
setblock 135 241 542 minecraft:smooth_basalt
fill 135 241 543 135 244 543 minecraft:blackstone
setblock 135 241 547 minecraft:smooth_basalt
fill 135 241 548 135 244 548 minecraft:blackstone
fill 95 242 518 95 242 520 minecraft:blackstone
setblock 95 242 521 minecraft:smooth_basalt
fill 95 242 522 95 242 525 minecraft:blackstone
setblock 95 242 526 minecraft:smooth_basalt
fill 95 242 527 95 242 530 minecraft:blackstone
setblock 95 242 531 minecraft:smooth_basalt
fill 95 242 532 95 242 535 minecraft:blackstone
setblock 95 242 536 minecraft:smooth_basalt
fill 95 242 537 95 245 537 minecraft:blackstone
setblock 95 242 541 minecraft:smooth_basalt
fill 95 242 542 95 245 542 minecraft:blackstone
setblock 95 242 545 minecraft:blackstone
setblock 95 242 546 minecraft:smooth_basalt
fill 95 242 547 95 245 547 minecraft:blackstone
setblock 95 242 550 minecraft:blackstone
setblock 95 242 551 minecraft:smooth_basalt
setblock 96 242 520 minecraft:smooth_basalt
fill 96 242 521 96 245 521 minecraft:blackstone
setblock 96 242 525 minecraft:smooth_basalt
fill 96 242 526 96 243 528 minecraft:blackstone
setblock 96 242 535 minecraft:smooth_basalt
fill 96 242 536 96 245 536 minecraft:blackstone
setblock 96 242 539 minecraft:blackstone
setblock 96 242 540 minecraft:smooth_basalt
fill 96 242 541 96 245 541 minecraft:blackstone
setblock 96 242 545 minecraft:smooth_basalt
fill 96 242 546 96 245 546 minecraft:blackstone
setblock 96 242 549 minecraft:blackstone
fill 96 242 551 99 242 551 minecraft:blackstone
fill 97 242 522 97 242 523 minecraft:blackstone
setblock 97 242 524 minecraft:smooth_basalt
fill 97 242 525 97 245 525 minecraft:blackstone
fill 97 242 537 97 243 537 minecraft:blackstone
setblock 97 242 539 minecraft:smooth_basalt
fill 97 242 540 98 244 540 minecraft:blackstone
setblock 97 242 544 minecraft:smooth_basalt
fill 97 242 545 98 244 545 minecraft:blackstone
fill 97 242 547 97 243 547 minecraft:blackstone
setblock 98 242 542 minecraft:blackstone
setblock 98 242 543 minecraft:smooth_basalt
fill 98 242 544 98 245 544 minecraft:blackstone
fill 99 242 550 100 242 550 minecraft:blackstone
setblock 100 242 551 minecraft:smooth_basalt
setblock 101 242 550 minecraft:smooth_basalt
fill 101 242 551 101 245 551 minecraft:blackstone
setblock 115 242 511 minecraft:smooth_basalt
fill 116 242 511 119 242 511 minecraft:blackstone
fill 117 242 512 118 242 512 minecraft:blackstone
fill 117 242 551 119 242 551 minecraft:blackstone
setblock 119 242 512 minecraft:smooth_basalt
fill 119 242 550 120 242 550 minecraft:blackstone
setblock 120 242 511 minecraft:smooth_basalt
fill 120 242 512 120 244 513 minecraft:blackstone
setblock 120 242 551 minecraft:smooth_basalt
fill 121 242 511 124 242 511 minecraft:blackstone
setblock 121 242 549 minecraft:blackstone
setblock 121 242 550 minecraft:smooth_basalt
fill 121 242 551 121 245 551 minecraft:blackstone
setblock 122 242 549 minecraft:smooth_basalt
fill 122 242 550 122 245 550 minecraft:blackstone
fill 123 242 549 124 244 549 minecraft:blackstone
setblock 124 242 512 minecraft:smooth_basalt
setblock 125 242 511 minecraft:smooth_basalt
fill 125 242 512 125 244 512 minecraft:blackstone
setblock 125 242 551 minecraft:smooth_basalt
fill 126 242 511 126 245 511 minecraft:blackstone
setblock 126 242 550 minecraft:smooth_basalt
fill 126 242 551 126 245 551 minecraft:blackstone
fill 127 242 550 128 244 550 minecraft:blackstone
setblock 130 242 551 minecraft:smooth_basalt
fill 131 242 551 134 242 551 minecraft:blackstone
fill 134 242 540 134 242 541 minecraft:blackstone
setblock 134 242 542 minecraft:smooth_basalt
fill 134 242 543 134 245 543 minecraft:blackstone
setblock 134 242 547 minecraft:smooth_basalt
fill 134 242 548 134 244 549 minecraft:blackstone
fill 135 242 518 135 242 520 minecraft:blackstone
setblock 135 242 521 minecraft:smooth_basalt
fill 135 242 522 135 242 525 minecraft:blackstone
fill 135 242 537 135 245 537 minecraft:blackstone
setblock 135 242 541 minecraft:smooth_basalt
fill 135 242 542 135 245 542 minecraft:blackstone
setblock 135 242 546 minecraft:smooth_basalt
fill 135 242 547 135 245 547 minecraft:blackstone
setblock 135 242 551 minecraft:smooth_basalt
fill 95 243 518 95 243 519 minecraft:blackstone
setblock 95 243 520 minecraft:smooth_basalt
fill 95 243 521 95 243 524 minecraft:blackstone
setblock 95 243 525 minecraft:smooth_basalt
fill 95 243 526 95 243 529 minecraft:blackstone
setblock 95 243 530 minecraft:smooth_basalt
fill 95 243 531 95 243 534 minecraft:blackstone
setblock 95 243 535 minecraft:smooth_basalt
fill 95 243 536 95 246 536 minecraft:blackstone
setblock 95 243 540 minecraft:smooth_basalt
fill 95 243 541 95 246 541 minecraft:blackstone
setblock 95 243 545 minecraft:smooth_basalt
fill 95 243 546 95 246 546 minecraft:blackstone
setblock 95 243 550 minecraft:smooth_basalt
fill 95 243 551 98 243 551 minecraft:blackstone
setblock 96 243 519 minecraft:smooth_basalt
fill 96 243 520 96 246 520 minecraft:blackstone
fill 96 243 522 96 243 523 minecraft:blackstone
setblock 96 243 524 minecraft:smooth_basalt
fill 96 243 525 96 246 525 minecraft:blackstone
setblock 96 243 529 minecraft:smooth_basalt
fill 96 243 530 96 243 533 minecraft:blackstone
setblock 96 243 534 minecraft:smooth_basalt
fill 96 243 535 96 246 535 minecraft:blackstone
setblock 96 243 538 minecraft:blackstone
setblock 96 243 539 minecraft:smooth_basalt
fill 96 243 540 96 246 540 minecraft:blackstone
setblock 96 243 544 minecraft:smooth_basalt
fill 96 243 545 96 246 545 minecraft:blackstone
setblock 96 243 549 minecraft:smooth_basalt
fill 96 243 550 99 243 550 minecraft:blackstone
fill 97 243 521 97 243 522 minecraft:blackstone
setblock 97 243 523 minecraft:smooth_basalt
fill 97 243 524 98 245 524 minecraft:blackstone
fill 97 243 526 97 243 527 minecraft:blackstone
setblock 97 243 528 minecraft:smooth_basalt
fill 97 243 529 97 246 529 minecraft:blackstone
setblock 97 243 538 minecraft:smooth_basalt
fill 97 243 539 97 246 539 minecraft:blackstone
setblock 97 243 543 minecraft:smooth_basalt
fill 97 243 544 97 246 544 minecraft:blackstone
setblock 97 243 548 minecraft:smooth_basalt
fill 98 243 523 98 246 523 minecraft:blackstone
fill 98 243 525 98 244 525 minecraft:blackstone
setblock 98 243 542 minecraft:smooth_basalt
fill 98 243 543 98 245 543 minecraft:blackstone
setblock 98 243 546 minecraft:blackstone
setblock 99 243 551 minecraft:smooth_basalt
fill 100 243 511 102 244 511 minecraft:blackstone
setblock 100 243 550 minecraft:smooth_basalt
fill 100 243 551 100 246 551 minecraft:blackstone
fill 101 243 550 102 245 550 minecraft:blackstone
setblock 104 243 551 minecraft:smooth_basalt
setblock 114 243 511 minecraft:smooth_basalt
fill 115 243 511 118 243 511 minecraft:blackstone
fill 115 243 551 118 243 551 minecraft:blackstone
fill 116 243 512 117 243 512 minecraft:blackstone
fill 117 243 550 119 243 550 minecraft:blackstone
setblock 118 243 512 minecraft:smooth_basalt
setblock 119 243 511 minecraft:smooth_basalt
fill 119 243 512 119 245 513 minecraft:blackstone
fill 119 243 549 120 243 549 minecraft:blackstone
setblock 119 243 551 minecraft:smooth_basalt
fill 120 243 511 123 243 511 minecraft:blackstone
setblock 120 243 550 minecraft:smooth_basalt
fill 120 243 551 120 246 551 minecraft:blackstone
setblock 121 243 549 minecraft:smooth_basalt
fill 121 243 550 121 246 550 minecraft:blackstone
setblock 122 243 513 minecraft:smooth_basalt
fill 122 243 549 122 246 549 minecraft:blackstone
setblock 123 243 512 minecraft:smooth_basalt
setblock 124 243 511 minecraft:smooth_basalt
fill 124 243 512 124 245 512 minecraft:blackstone
setblock 124 243 550 minecraft:blackstone
setblock 124 243 551 minecraft:smooth_basalt
fill 125 243 511 125 246 511 minecraft:blackstone
setblock 125 243 549 minecraft:blackstone
setblock 125 243 550 minecraft:smooth_basalt
fill 125 243 551 125 246 551 minecraft:blackstone
fill 126 243 550 126 246 550 minecraft:blackstone
setblock 128 243 551 minecraft:blackstone
setblock 129 243 550 minecraft:blackstone
setblock 129 243 551 minecraft:smooth_basalt
setblock 130 243 550 minecraft:smooth_basalt
fill 130 243 551 133 243 551 minecraft:blackstone
fill 131 243 550 134 243 550 minecraft:blackstone
fill 133 243 543 133 243 546 minecraft:blackstone
setblock 133 243 547 minecraft:smooth_basalt
fill 134 243 539 134 243 540 minecraft:blackstone
setblock 134 243 541 minecraft:smooth_basalt
fill 134 243 542 134 246 542 minecraft:blackstone
setblock 134 243 545 minecraft:blackstone
setblock 134 243 546 minecraft:smooth_basalt
fill 134 243 547 134 246 547 minecraft:blackstone
setblock 134 243 551 minecraft:smooth_basalt
fill 135 243 518 135 243 519 minecraft:blackstone
setblock 135 243 520 minecraft:smooth_basalt
fill 135 243 521 135 243 524 minecraft:blackstone
setblock 135 243 525 minecraft:smooth_basalt
fill 135 243 526 135 244 528 minecraft:blackstone
fill 135 243 536 135 246 536 minecraft:blackstone
setblock 135 243 540 minecraft:smooth_basalt
fill 135 243 541 135 246 541 minecraft:blackstone
setblock 135 243 545 minecraft:smooth_basalt
fill 135 243 546 135 246 546 minecraft:blackstone
setblock 135 243 549 minecraft:blackstone
setblock 135 243 550 minecraft:smooth_basalt
fill 135 243 551 135 246 551 minecraft:blackstone
setblock 95 244 518 minecraft:blackstone
setblock 95 244 519 minecraft:smooth_basalt
fill 95 244 520 95 244 523 minecraft:blackstone
setblock 95 244 524 minecraft:smooth_basalt
fill 95 244 525 95 244 528 minecraft:blackstone
setblock 95 244 529 minecraft:smooth_basalt
fill 95 244 530 95 244 533 minecraft:blackstone
setblock 95 244 534 minecraft:smooth_basalt
fill 95 244 535 95 247 535 minecraft:blackstone
setblock 95 244 539 minecraft:smooth_basalt
fill 95 244 540 95 247 540 minecraft:blackstone
setblock 95 244 544 minecraft:smooth_basalt
fill 95 244 545 95 247 545 minecraft:blackstone
setblock 95 244 548 minecraft:blackstone
setblock 95 244 549 minecraft:smooth_basalt
fill 95 244 550 97 244 551 minecraft:blackstone
fill 96 244 512 98 253 514 minecraft:smooth_basalt
fill 96 244 519 96 246 519 minecraft:blackstone
setblock 96 244 522 minecraft:blackstone
setblock 96 244 523 minecraft:smooth_basalt
fill 96 244 524 96 247 524 minecraft:blackstone
fill 96 244 526 96 244 527 minecraft:blackstone
setblock 96 244 528 minecraft:smooth_basalt
fill 96 244 529 96 244 532 minecraft:blackstone
setblock 96 244 533 minecraft:smooth_basalt
fill 96 244 534 96 247 534 minecraft:blackstone
setblock 96 244 538 minecraft:smooth_basalt
fill 96 244 539 96 247 539 minecraft:blackstone
setblock 96 244 543 minecraft:smooth_basalt
fill 96 244 544 96 247 544 minecraft:blackstone
setblock 96 244 547 minecraft:blackstone
setblock 96 244 548 minecraft:smooth_basalt
fill 96 244 549 99 244 549 minecraft:blackstone
fill 97 244 520 97 244 521 minecraft:blackstone
setblock 97 244 522 minecraft:smooth_basalt
fill 97 244 523 97 247 523 minecraft:blackstone
setblock 97 244 526 minecraft:blackstone
setblock 97 244 527 minecraft:smooth_basalt
fill 97 244 528 98 246 528 minecraft:blackstone
fill 97 244 530 97 244 531 minecraft:blackstone
setblock 97 244 537 minecraft:smooth_basalt
fill 97 244 538 97 246 538 minecraft:blackstone
setblock 97 244 541 minecraft:blackstone
setblock 97 244 542 minecraft:smooth_basalt
fill 97 244 543 97 247 543 minecraft:blackstone
setblock 97 244 547 minecraft:smooth_basalt
fill 97 244 548 97 247 548 minecraft:blackstone
fill 98 244 522 98 245 522 minecraft:blackstone
setblock 98 244 526 minecraft:smooth_basalt
fill 98 244 527 98 247 527 minecraft:blackstone
setblock 98 244 541 minecraft:smooth_basalt
fill 98 244 542 98 245 542 minecraft:blackstone
setblock 98 244 546 minecraft:smooth_basalt
setblock 98 244 550 minecraft:blackstone
setblock 98 244 551 minecraft:smooth_basalt
fill 99 244 511 99 247 511 minecraft:blackstone
fill 99 244 513 99 273 513 minecraft:smooth_basalt
setblock 99 244 550 minecraft:smooth_basalt
fill 99 244 551 99 247 551 minecraft:blackstone
setblock 100 244 549 minecraft:smooth_basalt
fill 100 244 550 100 247 550 minecraft:blackstone
setblock 102 244 551 minecraft:blackstone
setblock 103 244 551 minecraft:smooth_basalt
fill 104 244 551 104 246 551 minecraft:blackstone
setblock 113 244 511 minecraft:smooth_basalt
fill 114 244 511 117 244 511 minecraft:blackstone
fill 114 244 551 117 244 551 minecraft:blackstone
setblock 116 244 512 minecraft:blackstone
fill 116 244 550 118 244 550 minecraft:blackstone
setblock 117 244 512 minecraft:smooth_basalt
setblock 118 244 511 minecraft:smooth_basalt
fill 118 244 512 118 246 513 minecraft:blackstone
fill 118 244 549 119 244 549 minecraft:blackstone
setblock 118 244 551 minecraft:smooth_basalt
fill 119 244 511 122 244 511 minecraft:blackstone
setblock 119 244 550 minecraft:smooth_basalt
fill 119 244 551 119 247 551 minecraft:blackstone
setblock 120 244 549 minecraft:smooth_basalt
fill 120 244 550 120 247 550 minecraft:blackstone
setblock 121 244 512 minecraft:blackstone
setblock 121 244 513 minecraft:smooth_basalt
fill 121 244 549 121 247 549 minecraft:blackstone
setblock 122 244 512 minecraft:smooth_basalt
setblock 122 244 513 minecraft:blackstone
setblock 123 244 511 minecraft:smooth_basalt
fill 123 244 512 123 247 512 minecraft:blackstone
setblock 123 244 551 minecraft:smooth_basalt
fill 124 244 511 124 247 511 minecraft:blackstone
setblock 124 244 550 minecraft:smooth_basalt
fill 124 244 551 124 247 551 minecraft:blackstone
setblock 125 244 549 minecraft:smooth_basalt
fill 125 244 550 125 247 550 minecraft:blackstone
fill 126 244 549 126 246 549 minecraft:blackstone
setblock 128 244 511 minecraft:smooth_basalt
setblock 128 244 551 minecraft:smooth_basalt
setblock 129 244 550 minecraft:smooth_basalt
fill 129 244 551 132 244 551 minecraft:blackstone
fill 130 244 550 133 244 550 minecraft:blackstone
fill 133 244 543 133 244 545 minecraft:blackstone
setblock 133 244 546 minecraft:smooth_basalt
fill 133 244 547 133 246 548 minecraft:blackstone
setblock 133 244 551 minecraft:smooth_basalt
setblock 134 244 539 minecraft:blackstone
setblock 134 244 540 minecraft:smooth_basalt
fill 134 244 541 134 247 541 minecraft:blackstone
setblock 134 244 545 minecraft:smooth_basalt
fill 134 244 546 134 247 546 minecraft:blackstone
setblock 134 244 550 minecraft:smooth_basalt
fill 134 244 551 134 247 551 minecraft:blackstone
setblock 135 244 518 minecraft:blackstone
setblock 135 244 519 minecraft:smooth_basalt
fill 135 244 520 135 244 523 minecraft:blackstone
setblock 135 244 524 minecraft:smooth_basalt
fill 135 244 525 135 247 525 minecraft:blackstone
setblock 135 244 529 minecraft:smooth_basalt
fill 135 244 530 135 246 531 minecraft:blackstone
setblock 135 244 534 minecraft:smooth_basalt
fill 135 244 535 135 247 535 minecraft:blackstone
setblock 135 244 539 minecraft:smooth_basalt
fill 135 244 540 135 247 540 minecraft:blackstone
setblock 135 244 544 minecraft:smooth_basalt
fill 135 244 545 135 247 545 minecraft:blackstone
setblock 135 244 549 minecraft:smooth_basalt
fill 135 244 550 135 247 550 minecraft:blackstone
fill 95 245 513 95 246 514 minecraft:blackstone
setblock 95 245 518 minecraft:smooth_basalt
fill 95 245 519 95 245 522 minecraft:blackstone
setblock 95 245 523 minecraft:smooth_basalt
fill 95 245 524 95 245 527 minecraft:blackstone
setblock 95 245 528 minecraft:smooth_basalt
fill 95 245 529 95 245 532 minecraft:blackstone
setblock 95 245 533 minecraft:smooth_basalt
fill 95 245 534 95 248 534 minecraft:blackstone
setblock 95 245 538 minecraft:smooth_basalt
fill 95 245 539 95 248 539 minecraft:blackstone
setblock 95 245 543 minecraft:smooth_basalt
fill 95 245 544 95 248 544 minecraft:blackstone
setblock 95 245 548 minecraft:smooth_basalt
fill 95 245 549 96 245 551 minecraft:blackstone
fill 96 245 515 99 246 515 minecraft:blackstone
setblock 96 245 522 minecraft:smooth_basalt
fill 96 245 523 96 248 523 minecraft:blackstone
setblock 96 245 526 minecraft:blackstone
setblock 96 245 527 minecraft:smooth_basalt
fill 96 245 528 96 245 531 minecraft:blackstone
setblock 96 245 532 minecraft:smooth_basalt
fill 96 245 533 97 247 533 minecraft:blackstone
setblock 96 245 537 minecraft:smooth_basalt
fill 96 245 538 96 248 538 minecraft:blackstone
setblock 96 245 542 minecraft:smooth_basalt
fill 96 245 543 96 248 543 minecraft:blackstone
setblock 96 245 547 minecraft:smooth_basalt
fill 96 245 548 96 248 548 minecraft:blackstone
fill 97 245 511 98 248 511 minecraft:blackstone
setblock 97 245 521 minecraft:smooth_basalt
fill 97 245 522 97 248 522 minecraft:blackstone
setblock 97 245 526 minecraft:smooth_basalt
fill 97 245 527 97 248 527 minecraft:blackstone
setblock 97 245 530 minecraft:blackstone
setblock 97 245 531 minecraft:smooth_basalt
fill 97 245 532 97 248 532 minecraft:blackstone
setblock 97 245 537 minecraft:blackstone
setblock 97 245 540 minecraft:blackstone
setblock 97 245 541 minecraft:smooth_basalt
fill 97 245 542 97 247 542 minecraft:blackstone
setblock 97 245 545 minecraft:blackstone
setblock 97 245 546 minecraft:smooth_basalt
fill 97 245 547 97 248 547 minecraft:blackstone
fill 97 245 549 97 245 550 minecraft:blackstone
setblock 97 245 551 minecraft:smooth_basalt
setblock 98 245 525 minecraft:smooth_basalt
fill 98 245 526 98 248 526 minecraft:blackstone
setblock 98 245 529 minecraft:blackstone
setblock 98 245 545 minecraft:smooth_basalt
setblock 98 245 546 minecraft:blackstone
setblock 98 245 549 minecraft:blackstone
setblock 98 245 550 minecraft:smooth_basalt
fill 98 245 551 98 248 551 minecraft:blackstone
fill 99 245 512 99 246 512 minecraft:blackstone
fill 99 245 514 99 246 514 minecraft:blackstone
setblock 99 245 549 minecraft:smooth_basalt
fill 99 245 550 99 248 550 minecraft:blackstone
fill 100 245 511 101 245 511 minecraft:blackstone
fill 100 245 549 100 246 549 minecraft:blackstone
setblock 102 245 511 minecraft:smooth_basalt
setblock 102 245 551 minecraft:smooth_basalt
fill 103 245 551 103 248 551 minecraft:blackstone
fill 113 245 511 116 245 511 minecraft:blackstone
fill 113 245 551 116 245 551 minecraft:blackstone
setblock 115 245 512 minecraft:blackstone
fill 115 245 550 117 245 550 minecraft:blackstone
setblock 116 245 512 minecraft:smooth_basalt
setblock 117 245 511 minecraft:smooth_basalt
fill 117 245 512 117 248 512 minecraft:blackstone
fill 117 245 549 118 245 549 minecraft:blackstone
setblock 117 245 551 minecraft:smooth_basalt
fill 118 245 511 121 245 511 minecraft:blackstone
setblock 118 245 550 minecraft:smooth_basalt
fill 118 245 551 118 248 551 minecraft:blackstone
setblock 119 245 549 minecraft:smooth_basalt
fill 119 245 550 119 248 550 minecraft:blackstone
setblock 120 245 512 minecraft:blackstone
setblock 120 245 513 minecraft:smooth_basalt
setblock 120 245 548 minecraft:smooth_basalt
fill 120 245 549 120 248 549 minecraft:blackstone
setblock 121 245 512 minecraft:smooth_basalt
setblock 121 245 513 minecraft:blackstone
fill 121 245 548 122 246 548 minecraft:blackstone
setblock 122 245 511 minecraft:smooth_basalt
fill 122 245 512 122 248 512 minecraft:blackstone
setblock 122 245 551 minecraft:smooth_basalt
fill 123 245 511 123 248 511 minecraft:blackstone
setblock 123 245 549 minecraft:blackstone
setblock 123 245 550 minecraft:smooth_basalt
fill 123 245 551 123 248 551 minecraft:blackstone
setblock 124 245 549 minecraft:smooth_basalt
fill 124 245 550 124 248 550 minecraft:blackstone
fill 125 245 549 125 247 549 minecraft:blackstone
setblock 127 245 511 minecraft:smooth_basalt
setblock 127 245 550 minecraft:blackstone
setblock 127 245 551 minecraft:smooth_basalt
setblock 128 245 550 minecraft:smooth_basalt
fill 128 245 551 131 245 551 minecraft:blackstone
fill 129 245 550 132 245 550 minecraft:blackstone
fill 132 245 549 133 245 549 minecraft:blackstone
setblock 132 245 551 minecraft:smooth_basalt
fill 133 245 543 133 245 544 minecraft:blackstone
setblock 133 245 545 minecraft:smooth_basalt
fill 133 245 546 133 248 546 minecraft:blackstone
setblock 133 245 550 minecraft:smooth_basalt
fill 133 245 551 133 248 551 minecraft:blackstone
setblock 134 245 539 minecraft:smooth_basalt
fill 134 245 540 134 248 540 minecraft:blackstone
setblock 134 245 544 minecraft:smooth_basalt
fill 134 245 545 134 248 545 minecraft:blackstone
setblock 134 245 548 minecraft:blackstone
setblock 134 245 549 minecraft:smooth_basalt
fill 134 245 550 134 248 550 minecraft:blackstone
fill 135 245 519 135 245 522 minecraft:blackstone
setblock 135 245 523 minecraft:smooth_basalt
fill 135 245 524 135 248 524 minecraft:blackstone
fill 135 245 526 135 245 527 minecraft:blackstone
setblock 135 245 528 minecraft:smooth_basalt
fill 135 245 529 135 248 529 minecraft:blackstone
setblock 135 245 532 minecraft:blackstone
setblock 135 245 533 minecraft:smooth_basalt
fill 135 245 534 135 248 534 minecraft:blackstone
setblock 135 245 538 minecraft:smooth_basalt
fill 135 245 539 135 248 539 minecraft:blackstone
setblock 135 245 543 minecraft:smooth_basalt
fill 135 245 544 135 248 544 minecraft:blackstone
setblock 135 245 548 minecraft:smooth_basalt
fill 135 245 549 135 248 549 minecraft:blackstone
fill 95 246 511 95 246 512 minecraft:blackstone
setblock 95 246 515 minecraft:blackstone
fill 95 246 518 95 246 521 minecraft:blackstone
setblock 95 246 522 minecraft:smooth_basalt
fill 95 246 523 95 246 526 minecraft:blackstone
setblock 95 246 527 minecraft:smooth_basalt
fill 95 246 528 95 246 531 minecraft:blackstone
setblock 95 246 532 minecraft:smooth_basalt
fill 95 246 533 95 249 533 minecraft:blackstone
setblock 95 246 537 minecraft:smooth_basalt
fill 95 246 538 95 249 538 minecraft:blackstone
setblock 95 246 542 minecraft:smooth_basalt
fill 95 246 543 95 249 543 minecraft:blackstone
setblock 95 246 547 minecraft:smooth_basalt
fill 95 246 548 95 246 551 minecraft:blackstone
fill 96 246 511 96 250 511 minecraft:blackstone
fill 96 246 516 98 246 516 minecraft:blackstone
setblock 96 246 521 minecraft:smooth_basalt
fill 96 246 522 96 249 522 minecraft:blackstone
setblock 96 246 526 minecraft:smooth_basalt
fill 96 246 527 96 246 530 minecraft:blackstone
setblock 96 246 531 minecraft:smooth_basalt
fill 96 246 532 96 249 532 minecraft:blackstone
setblock 96 246 536 minecraft:smooth_basalt
fill 96 246 537 96 249 537 minecraft:blackstone
setblock 96 246 541 minecraft:smooth_basalt
fill 96 246 542 96 249 542 minecraft:blackstone
setblock 96 246 546 minecraft:smooth_basalt
fill 96 246 547 96 249 547 minecraft:blackstone
fill 96 246 549 96 246 550 minecraft:blackstone
setblock 96 246 551 minecraft:smooth_basalt
fill 97 246 521 97 247 521 minecraft:blackstone
setblock 97 246 524 minecraft:blackstone
setblock 97 246 525 minecraft:smooth_basalt
fill 97 246 526 97 249 526 minecraft:blackstone
setblock 97 246 530 minecraft:smooth_basalt
fill 97 246 531 97 249 531 minecraft:blackstone
setblock 97 246 534 minecraft:blackstone
setblock 97 246 540 minecraft:smooth_basalt
fill 97 246 541 97 247 541 minecraft:blackstone
setblock 97 246 545 minecraft:smooth_basalt
fill 97 246 546 97 248 546 minecraft:blackstone
setblock 97 246 549 minecraft:blackstone
setblock 97 246 550 minecraft:smooth_basalt
fill 97 246 551 97 249 551 minecraft:blackstone
setblock 98 246 524 minecraft:smooth_basalt
fill 98 246 525 98 249 525 minecraft:blackstone
setblock 98 246 529 minecraft:smooth_basalt
fill 98 246 530 98 249 530 minecraft:blackstone
setblock 98 246 544 minecraft:smooth_basalt
setblock 98 246 545 minecraft:blackstone
setblock 98 246 549 minecraft:smooth_basalt
fill 98 246 550 98 249 550 minecraft:blackstone
fill 99 246 549 99 247 549 minecraft:blackstone
fill 100 246 511 100 246 514 minecraft:blackstone
setblock 101 246 511 minecraft:smooth_basalt
setblock 101 246 550 minecraft:blackstone
setblock 101 246 551 minecraft:smooth_basalt
setblock 102 246 511 minecraft:blackstone
setblock 102 246 550 minecraft:smooth_basalt
fill 102 246 551 102 249 551 minecraft:blackstone
fill 112 246 511 115 246 511 minecraft:blackstone
fill 112 246 551 115 246 551 minecraft:blackstone
fill 114 246 550 116 246 550 minecraft:blackstone
setblock 115 246 512 minecraft:smooth_basalt
fill 115 246 521 116 247 521 minecraft:gold_block
setblock 116 246 511 minecraft:smooth_basalt
fill 116 246 512 116 249 512 minecraft:blackstone
fill 116 246 549 117 246 549 minecraft:blackstone
setblock 116 246 551 minecraft:smooth_basalt
fill 117 246 511 120 246 511 minecraft:blackstone
setblock 117 246 550 minecraft:smooth_basalt
fill 117 246 551 117 249 551 minecraft:blackstone
setblock 118 246 549 minecraft:smooth_basalt
fill 118 246 550 118 249 550 minecraft:blackstone
setblock 119 246 512 minecraft:blackstone
setblock 119 246 513 minecraft:smooth_basalt
setblock 119 246 548 minecraft:smooth_basalt
fill 119 246 549 119 249 549 minecraft:blackstone
setblock 120 246 512 minecraft:smooth_basalt
setblock 120 246 513 minecraft:blackstone
fill 120 246 548 120 247 548 minecraft:blackstone
setblock 121 246 511 minecraft:smooth_basalt
fill 121 246 512 121 249 512 minecraft:blackstone
setblock 121 246 551 minecraft:smooth_basalt
fill 122 246 511 122 249 511 minecraft:blackstone
setblock 122 246 550 minecraft:smooth_basalt
fill 122 246 551 122 249 551 minecraft:blackstone
setblock 123 246 549 minecraft:smooth_basalt
fill 123 246 550 123 249 550 minecraft:blackstone
fill 124 246 549 124 248 549 minecraft:blackstone
setblock 126 246 511 minecraft:smooth_basalt
setblock 126 246 551 minecraft:smooth_basalt
setblock 127 246 511 minecraft:blackstone
setblock 127 246 550 minecraft:smooth_basalt
fill 127 246 551 130 246 551 minecraft:blackstone
fill 128 246 550 131 246 550 minecraft:blackstone
setblock 131 246 551 minecraft:smooth_basalt
setblock 132 246 549 minecraft:blackstone
setblock 132 246 550 minecraft:smooth_basalt
fill 132 246 551 132 249 551 minecraft:blackstone
setblock 133 246 543 minecraft:blackstone
setblock 133 246 544 minecraft:smooth_basalt
fill 133 246 545 133 249 545 minecraft:blackstone
setblock 133 246 549 minecraft:smooth_basalt
fill 133 246 550 133 249 550 minecraft:blackstone
fill 134 246 525 134 247 526 minecraft:blackstone
setblock 134 246 539 minecraft:blackstone
setblock 134 246 543 minecraft:smooth_basalt
fill 134 246 544 134 249 544 minecraft:blackstone
setblock 134 246 548 minecraft:smooth_basalt
fill 134 246 549 134 249 549 minecraft:blackstone
setblock 135 246 511 minecraft:blackstone
fill 135 246 519 135 246 521 minecraft:blackstone
setblock 135 246 522 minecraft:smooth_basalt
fill 135 246 523 135 249 523 minecraft:blackstone
setblock 135 246 526 minecraft:blackstone
setblock 135 246 527 minecraft:smooth_basalt
fill 135 246 528 135 249 528 minecraft:blackstone
setblock 135 246 532 minecraft:smooth_basalt
fill 135 246 533 135 249 533 minecraft:blackstone
setblock 135 246 537 minecraft:smooth_basalt
fill 135 246 538 135 249 538 minecraft:blackstone
setblock 135 246 542 minecraft:smooth_basalt
fill 135 246 543 135 249 543 minecraft:blackstone
setblock 135 246 547 minecraft:smooth_basalt
fill 135 246 548 135 249 548 minecraft:blackstone
fill 95 247 518 95 247 520 minecraft:blackstone
setblock 95 247 521 minecraft:smooth_basalt
fill 95 247 522 95 247 525 minecraft:blackstone
setblock 95 247 526 minecraft:smooth_basalt
fill 95 247 527 95 247 530 minecraft:blackstone
setblock 95 247 531 minecraft:smooth_basalt
fill 95 247 532 95 250 532 minecraft:blackstone
setblock 95 247 536 minecraft:smooth_basalt
fill 95 247 537 95 250 537 minecraft:blackstone
setblock 95 247 541 minecraft:smooth_basalt
fill 95 247 542 95 250 542 minecraft:blackstone
setblock 95 247 546 minecraft:smooth_basalt
fill 95 247 547 95 247 550 minecraft:blackstone
setblock 95 247 551 minecraft:smooth_basalt
setblock 96 247 520 minecraft:smooth_basalt
fill 96 247 521 96 249 521 minecraft:blackstone
setblock 96 247 525 minecraft:smooth_basalt
fill 96 247 526 96 247 529 minecraft:blackstone
setblock 96 247 530 minecraft:smooth_basalt
fill 96 247 531 96 250 531 minecraft:blackstone
setblock 96 247 535 minecraft:smooth_basalt
fill 96 247 536 96 250 536 minecraft:blackstone
setblock 96 247 540 minecraft:smooth_basalt
fill 96 247 541 96 249 541 minecraft:blackstone
setblock 96 247 545 minecraft:smooth_basalt
fill 96 247 546 96 250 546 minecraft:blackstone
setblock 96 247 549 minecraft:blackstone
setblock 96 247 550 minecraft:smooth_basalt
fill 96 247 551 96 250 551 minecraft:blackstone
setblock 97 247 524 minecraft:smooth_basalt
fill 97 247 525 97 250 525 minecraft:blackstone
setblock 97 247 528 minecraft:blackstone
setblock 97 247 529 minecraft:smooth_basalt
fill 97 247 530 97 250 530 minecraft:blackstone
setblock 97 247 534 minecraft:smooth_basalt
setblock 97 247 544 minecraft:smooth_basalt
fill 97 247 545 97 248 545 minecraft:blackstone
setblock 97 247 549 minecraft:smooth_basalt
fill 97 247 550 97 250 550 minecraft:blackstone
setblock 98 247 523 minecraft:smooth_basalt
fill 98 247 524 98 248 524 minecraft:blackstone
setblock 98 247 528 minecraft:smooth_basalt
fill 98 247 529 98 250 529 minecraft:blackstone
setblock 98 247 549 minecraft:blackstone
setblock 100 247 511 minecraft:smooth_basalt
setblock 100 247 551 minecraft:smooth_basalt
fill 101 247 511 101 248 511 minecraft:blackstone
setblock 101 247 550 minecraft:smooth_basalt
fill 101 247 551 101 250 551 minecraft:blackstone
fill 111 247 511 114 247 511 minecraft:blackstone
fill 112 247 551 114 247 551 minecraft:blackstone
setblock 114 247 512 minecraft:smooth_basalt
fill 114 247 550 115 247 550 minecraft:blackstone
setblock 115 247 511 minecraft:smooth_basalt
fill 115 247 512 115 250 512 minecraft:blackstone
setblock 115 247 551 minecraft:smooth_basalt
fill 116 247 511 119 247 511 minecraft:blackstone
setblock 116 247 549 minecraft:blackstone
setblock 116 247 550 minecraft:smooth_basalt
fill 116 247 551 116 250 551 minecraft:blackstone
setblock 117 247 549 minecraft:smooth_basalt
fill 117 247 550 117 250 550 minecraft:blackstone
setblock 118 247 512 minecraft:blackstone
fill 118 247 549 118 250 549 minecraft:blackstone
setblock 119 247 512 minecraft:smooth_basalt
setblock 120 247 511 minecraft:smooth_basalt
fill 120 247 512 120 250 512 minecraft:blackstone
setblock 120 247 551 minecraft:smooth_basalt
fill 121 247 511 121 250 511 minecraft:blackstone
setblock 121 247 550 minecraft:smooth_basalt
fill 121 247 551 121 250 551 minecraft:blackstone
setblock 122 247 549 minecraft:smooth_basalt
fill 122 247 550 122 250 550 minecraft:blackstone
fill 123 247 549 123 249 549 minecraft:blackstone
setblock 125 247 511 minecraft:smooth_basalt
setblock 125 247 551 minecraft:smooth_basalt
setblock 126 247 511 minecraft:blackstone
setblock 126 247 550 minecraft:smooth_basalt
fill 126 247 551 129 247 551 minecraft:blackstone
fill 127 247 550 130 247 550 minecraft:blackstone
setblock 130 247 551 minecraft:smooth_basalt
setblock 131 247 550 minecraft:smooth_basalt
fill 131 247 551 131 250 551 minecraft:blackstone
setblock 132 247 549 minecraft:smooth_basalt
fill 132 247 550 132 250 550 minecraft:blackstone
fill 133 247 544 133 248 544 minecraft:blackstone
setblock 133 247 547 minecraft:blackstone
setblock 133 247 548 minecraft:smooth_basalt
fill 133 247 549 133 250 549 minecraft:blackstone
setblock 134 247 527 minecraft:smooth_basalt
fill 134 247 528 134 250 528 minecraft:blackstone
setblock 134 247 542 minecraft:smooth_basalt
fill 134 247 543 134 250 543 minecraft:blackstone
setblock 134 247 547 minecraft:smooth_basalt
fill 134 247 548 134 250 548 minecraft:blackstone
setblock 135 247 511 minecraft:smooth_basalt
setblock 135 247 520 minecraft:blackstone
setblock 135 247 521 minecraft:smooth_basalt
fill 135 247 522 135 250 522 minecraft:blackstone
setblock 135 247 526 minecraft:smooth_basalt
fill 135 247 527 135 250 527 minecraft:blackstone
setblock 135 247 530 minecraft:blackstone
setblock 135 247 531 minecraft:smooth_basalt
fill 135 247 532 135 250 532 minecraft:blackstone
setblock 135 247 536 minecraft:smooth_basalt
fill 135 247 537 135 250 537 minecraft:blackstone
setblock 135 247 541 minecraft:smooth_basalt
fill 135 247 542 135 250 542 minecraft:blackstone
setblock 135 247 546 minecraft:smooth_basalt
fill 135 247 547 135 250 547 minecraft:blackstone
setblock 135 247 551 minecraft:smooth_basalt
setblock 95 248 519 minecraft:blackstone
setblock 95 248 520 minecraft:smooth_basalt
fill 95 248 521 95 248 524 minecraft:blackstone
setblock 95 248 525 minecraft:smooth_basalt
fill 95 248 526 95 248 529 minecraft:blackstone
setblock 95 248 530 minecraft:smooth_basalt
fill 95 248 531 95 251 531 minecraft:blackstone
setblock 95 248 535 minecraft:smooth_basalt
fill 95 248 536 95 251 536 minecraft:blackstone
setblock 95 248 540 minecraft:smooth_basalt
fill 95 248 541 95 251 541 minecraft:blackstone
setblock 95 248 545 minecraft:smooth_basalt
fill 95 248 546 95 248 549 minecraft:blackstone
setblock 95 248 550 minecraft:smooth_basalt
fill 95 248 551 95 251 551 minecraft:blackstone
setblock 96 248 520 minecraft:blackstone
setblock 96 248 524 minecraft:smooth_basalt
fill 96 248 525 96 248 528 minecraft:blackstone
setblock 96 248 529 minecraft:smooth_basalt
fill 96 248 530 96 251 530 minecraft:blackstone
setblock 96 248 533 minecraft:blackstone
setblock 96 248 534 minecraft:smooth_basalt
fill 96 248 535 96 251 535 minecraft:blackstone
setblock 96 248 539 minecraft:smooth_basalt
fill 96 248 540 96 249 540 minecraft:blackstone
setblock 96 248 544 minecraft:smooth_basalt
fill 96 248 545 96 251 545 minecraft:blackstone
setblock 96 248 549 minecraft:smooth_basalt
fill 96 248 550 96 251 550 minecraft:blackstone
setblock 97 248 521 minecraft:light[level=12]
setblock 97 248 523 minecraft:smooth_basalt
fill 97 248 524 97 251 524 minecraft:blackstone
setblock 97 248 528 minecraft:smooth_basalt
fill 97 248 529 97 251 529 minecraft:blackstone
setblock 97 248 533 minecraft:smooth_basalt
setblock 97 248 534 minecraft:blackstone
setblock 97 248 537 minecraft:light[level=12]
setblock 97 248 544 minecraft:blackstone
setblock 97 248 548 minecraft:smooth_basalt
setblock 97 248 549 minecraft:blackstone
setblock 98 248 527 minecraft:smooth_basalt
fill 98 248 528 98 251 528 minecraft:blackstone
setblock 99 248 511 minecraft:smooth_basalt
setblock 99 248 551 minecraft:smooth_basalt
fill 100 248 511 100 251 511 minecraft:blackstone
setblock 100 248 550 minecraft:smooth_basalt
fill 100 248 551 100 251 551 minecraft:blackstone
setblock 105 248 513 minecraft:light[level=12]
setblock 105 248 521 minecraft:light[level=12]
setblock 105 248 529 minecraft:light[level=12]
setblock 105 248 537 minecraft:light[level=12]
setblock 105 248 545 minecraft:light[level=12]
fill 111 248 511 113 248 511 minecraft:blackstone
fill 111 248 551 113 248 551 minecraft:blackstone
setblock 113 248 513 minecraft:light[level=12]
setblock 113 248 521 minecraft:light[level=12]
setblock 113 248 529 minecraft:light[level=12]
setblock 113 248 537 minecraft:light[level=12]
setblock 113 248 545 minecraft:light[level=12]
fill 113 248 550 114 248 550 minecraft:blackstone
setblock 114 248 511 minecraft:smooth_basalt
fill 114 248 512 114 251 512 minecraft:blackstone
setblock 114 248 551 minecraft:smooth_basalt
fill 115 248 511 118 248 511 minecraft:blackstone
setblock 115 248 549 minecraft:blackstone
setblock 115 248 550 minecraft:smooth_basalt
fill 115 248 551 115 251 551 minecraft:blackstone
setblock 116 248 549 minecraft:smooth_basalt
fill 116 248 550 116 251 550 minecraft:blackstone
fill 117 248 549 117 251 549 minecraft:blackstone
setblock 118 248 512 minecraft:smooth_basalt
setblock 119 248 511 minecraft:smooth_basalt
fill 119 248 512 119 251 512 minecraft:blackstone
setblock 119 248 551 minecraft:smooth_basalt
fill 120 248 511 120 251 511 minecraft:blackstone
setblock 120 248 550 minecraft:smooth_basalt
fill 120 248 551 120 251 551 minecraft:blackstone
setblock 121 248 513 minecraft:light[level=12]
setblock 121 248 521 minecraft:light[level=12]
setblock 121 248 529 minecraft:light[level=12]
setblock 121 248 537 minecraft:light[level=12]
setblock 121 248 545 minecraft:light[level=12]
setblock 121 248 549 minecraft:smooth_basalt
fill 121 248 550 121 251 550 minecraft:blackstone
schedule function dropper:buildpart/122_9 1t
