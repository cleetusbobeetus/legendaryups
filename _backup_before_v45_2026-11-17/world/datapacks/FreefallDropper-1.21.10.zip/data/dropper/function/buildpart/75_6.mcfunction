fill 142 104 333 142 104 353 minecraft:purple_terracotta
fill 143 104 331 143 104 332 minecraft:purple_terracotta
fill 143 104 333 157 104 353 minecraft:magenta_terracotta
fill 143 104 354 143 104 355 minecraft:purple_terracotta
setblock 144 104 330 minecraft:purple_terracotta
fill 144 104 331 180 104 332 minecraft:magenta_terracotta
fill 144 104 354 180 104 355 minecraft:magenta_terracotta
setblock 144 104 356 minecraft:purple_terracotta
fill 145 104 329 145 105 329 minecraft:purple_terracotta
fill 145 104 330 179 104 330 minecraft:magenta_terracotta
fill 145 104 356 179 104 356 minecraft:magenta_terracotta
fill 145 104 357 145 105 357 minecraft:purple_terracotta
fill 146 104 328 146 105 328 minecraft:purple_terracotta
fill 146 104 329 178 105 329 minecraft:magenta_terracotta
fill 146 104 357 178 105 357 minecraft:magenta_terracotta
fill 146 104 358 146 105 358 minecraft:purple_terracotta
fill 147 104 327 147 105 327 minecraft:purple_terracotta
fill 147 104 328 177 105 328 minecraft:magenta_terracotta
fill 147 104 358 177 105 358 minecraft:magenta_terracotta
fill 147 104 359 147 105 359 minecraft:purple_terracotta
fill 148 104 326 148 105 326 minecraft:purple_terracotta
fill 148 104 327 176 105 327 minecraft:magenta_terracotta
fill 148 104 359 176 105 359 minecraft:magenta_terracotta
fill 148 104 360 148 105 360 minecraft:purple_terracotta
setblock 149 104 325 minecraft:purple_terracotta
fill 149 104 326 175 104 326 minecraft:magenta_terracotta
fill 149 104 360 175 104 360 minecraft:magenta_terracotta
setblock 149 104 361 minecraft:purple_terracotta
fill 150 104 324 151 104 324 minecraft:purple_terracotta
fill 150 104 325 174 104 325 minecraft:magenta_terracotta
fill 150 104 361 174 104 361 minecraft:magenta_terracotta
fill 150 104 362 151 104 362 minecraft:purple_terracotta
fill 152 104 323 172 104 323 minecraft:purple_terracotta
fill 152 104 324 172 104 324 minecraft:magenta_terracotta
fill 152 104 362 172 104 362 minecraft:magenta_terracotta
fill 152 104 363 172 104 363 minecraft:purple_terracotta
fill 158 104 333 158 104 342 minecraft:magenta_terracotta
fill 158 104 346 158 104 353 minecraft:magenta_terracotta
fill 159 104 333 181 104 341 minecraft:magenta_terracotta
fill 159 104 347 181 104 353 minecraft:magenta_terracotta
fill 162 104 342 181 104 342 minecraft:magenta_terracotta
fill 162 104 346 181 104 346 minecraft:magenta_terracotta
fill 163 104 343 181 104 345 minecraft:magenta_terracotta
fill 173 104 324 174 104 324 minecraft:purple_terracotta
fill 173 104 362 174 104 362 minecraft:purple_terracotta
setblock 175 104 325 minecraft:purple_terracotta
setblock 175 104 361 minecraft:purple_terracotta
fill 176 104 326 176 105 326 minecraft:purple_terracotta
fill 176 104 360 176 105 360 minecraft:purple_terracotta
fill 177 104 327 177 105 327 minecraft:purple_terracotta
fill 177 104 359 177 105 359 minecraft:purple_terracotta
fill 178 104 328 178 105 328 minecraft:purple_terracotta
fill 178 104 358 178 105 358 minecraft:purple_terracotta
fill 179 104 329 179 105 329 minecraft:purple_terracotta
fill 179 104 357 179 105 357 minecraft:purple_terracotta
setblock 180 104 330 minecraft:purple_terracotta
setblock 180 104 356 minecraft:purple_terracotta
fill 181 104 331 181 104 332 minecraft:purple_terracotta
fill 181 104 354 181 104 355 minecraft:purple_terracotta
fill 182 104 333 182 104 353 minecraft:purple_terracotta
setblock 183 104 349 minecraft:cyan_concrete
fill 141 105 333 141 127 334 minecraft:black_concrete
setblock 141 105 335 minecraft:light_blue_wool
fill 142 105 334 142 105 352 minecraft:purple_terracotta
fill 143 105 332 143 105 333 minecraft:purple_terracotta
fill 143 105 334 157 105 352 minecraft:magenta_terracotta
fill 143 105 353 143 105 354 minecraft:purple_terracotta
fill 144 105 331 144 106 331 minecraft:purple_terracotta
fill 144 105 332 180 105 333 minecraft:magenta_terracotta
fill 144 105 353 180 105 354 minecraft:magenta_terracotta
fill 144 105 355 144 106 355 minecraft:purple_terracotta
fill 145 105 330 145 106 330 minecraft:purple_terracotta
fill 145 105 331 179 106 331 minecraft:magenta_terracotta
fill 145 105 355 179 106 355 minecraft:magenta_terracotta
fill 145 105 356 145 106 356 minecraft:purple_terracotta
fill 146 105 330 178 106 330 minecraft:magenta_terracotta
fill 146 105 356 178 106 356 minecraft:magenta_terracotta
fill 149 105 326 149 106 326 minecraft:purple_terracotta
fill 149 105 360 149 106 360 minecraft:purple_terracotta
fill 150 105 325 150 106 325 minecraft:purple_terracotta
fill 150 105 326 174 106 326 minecraft:magenta_terracotta
fill 150 105 360 174 106 360 minecraft:magenta_terracotta
fill 150 105 361 150 106 361 minecraft:purple_terracotta
fill 151 105 324 152 105 324 minecraft:purple_terracotta
fill 151 105 325 173 105 325 minecraft:magenta_terracotta
fill 151 105 361 173 105 361 minecraft:magenta_terracotta
fill 151 105 362 152 105 362 minecraft:purple_terracotta
fill 153 105 323 171 105 323 minecraft:purple_terracotta
fill 153 105 324 171 105 324 minecraft:magenta_terracotta
fill 153 105 362 171 105 362 minecraft:magenta_terracotta
fill 153 105 363 171 105 363 minecraft:purple_terracotta
fill 158 105 334 159 105 341 minecraft:magenta_terracotta
setblock 158 105 342 minecraft:gray_concrete
setblock 158 105 346 minecraft:gray_concrete
fill 158 105 347 159 105 352 minecraft:magenta_terracotta
fill 160 105 334 181 105 340 minecraft:magenta_terracotta
setblock 160 105 341 minecraft:gray_concrete
setblock 160 105 347 minecraft:gray_concrete
fill 160 105 348 181 105 352 minecraft:magenta_terracotta
fill 161 105 341 181 105 341 minecraft:magenta_terracotta
fill 161 105 347 181 105 347 minecraft:magenta_terracotta
setblock 162 105 342 minecraft:gray_concrete
setblock 162 105 346 minecraft:gray_concrete
fill 163 105 342 181 105 343 minecraft:magenta_terracotta
setblock 163 105 344 minecraft:gray_concrete
fill 163 105 345 181 105 346 minecraft:magenta_terracotta
fill 164 105 344 181 105 344 minecraft:magenta_terracotta
fill 172 105 324 173 105 324 minecraft:purple_terracotta
fill 172 105 362 173 105 362 minecraft:purple_terracotta
fill 174 105 325 174 106 325 minecraft:purple_terracotta
fill 174 105 361 174 106 361 minecraft:purple_terracotta
fill 175 105 326 175 106 326 minecraft:purple_terracotta
fill 175 105 360 175 106 360 minecraft:purple_terracotta
fill 179 105 330 179 106 330 minecraft:purple_terracotta
fill 179 105 356 179 106 356 minecraft:purple_terracotta
fill 180 105 331 180 106 331 minecraft:purple_terracotta
fill 180 105 355 180 106 355 minecraft:purple_terracotta
fill 181 105 332 181 105 333 minecraft:purple_terracotta
fill 181 105 353 181 105 354 minecraft:purple_terracotta
fill 182 105 334 182 105 352 minecraft:purple_terracotta
fill 183 105 349 183 131 349 minecraft:black_concrete
fill 141 106 335 141 127 335 minecraft:black_concrete
fill 142 106 323 142 106 334 minecraft:magenta_terracotta
fill 142 106 335 142 106 351 minecraft:purple_terracotta
fill 142 106 352 142 106 363 minecraft:magenta_terracotta
fill 143 106 323 143 106 332 minecraft:magenta_terracotta
fill 143 106 333 143 106 334 minecraft:purple_terracotta
fill 143 106 335 153 106 351 minecraft:magenta_terracotta
fill 143 106 352 143 106 353 minecraft:purple_terracotta
fill 143 106 354 143 106 363 minecraft:magenta_terracotta
fill 144 106 323 144 106 330 minecraft:magenta_terracotta
fill 144 106 332 144 107 332 minecraft:purple_terracotta
fill 144 106 333 180 106 334 minecraft:magenta_terracotta
fill 144 106 352 180 106 353 minecraft:magenta_terracotta
fill 144 106 354 144 107 354 minecraft:purple_terracotta
fill 144 106 356 144 106 363 minecraft:magenta_terracotta
fill 145 106 323 145 106 329 minecraft:magenta_terracotta
fill 145 106 332 179 107 332 minecraft:magenta_terracotta
fill 145 106 354 179 107 354 minecraft:magenta_terracotta
fill 145 106 357 145 106 363 minecraft:magenta_terracotta
fill 146 106 323 146 106 328 minecraft:magenta_terracotta
setblock 146 106 329 minecraft:purple_terracotta
setblock 146 106 357 minecraft:purple_terracotta
fill 146 106 358 146 106 363 minecraft:magenta_terracotta
fill 147 106 323 147 106 327 minecraft:magenta_terracotta
setblock 147 106 328 minecraft:purple_terracotta
fill 147 106 329 177 106 329 minecraft:magenta_terracotta
fill 147 106 357 177 106 357 minecraft:magenta_terracotta
setblock 147 106 358 minecraft:purple_terracotta
fill 147 106 359 147 106 363 minecraft:magenta_terracotta
fill 148 106 323 148 106 326 minecraft:magenta_terracotta
setblock 148 106 327 minecraft:purple_terracotta
fill 148 106 328 176 106 328 minecraft:magenta_terracotta
fill 148 106 358 176 106 358 minecraft:magenta_terracotta
setblock 148 106 359 minecraft:purple_terracotta
fill 148 106 360 148 106 363 minecraft:magenta_terracotta
fill 149 106 323 149 106 325 minecraft:magenta_terracotta
fill 149 106 327 175 106 327 minecraft:magenta_terracotta
fill 149 106 359 175 106 359 minecraft:magenta_terracotta
fill 149 106 361 149 106 363 minecraft:magenta_terracotta
fill 150 106 323 151 106 324 minecraft:magenta_terracotta
fill 150 106 362 151 106 363 minecraft:magenta_terracotta
fill 151 106 325 151 107 325 minecraft:purple_terracotta
fill 151 106 361 151 107 361 minecraft:purple_terracotta
fill 152 106 323 153 106 323 minecraft:magenta_terracotta
fill 152 106 324 153 106 324 minecraft:purple_terracotta
fill 152 106 325 172 106 325 minecraft:magenta_terracotta
fill 152 106 361 172 106 361 minecraft:magenta_terracotta
fill 152 106 362 153 106 362 minecraft:purple_terracotta
fill 152 106 363 153 106 363 minecraft:magenta_terracotta
fill 154 106 323 170 106 323 minecraft:purple_terracotta
fill 154 106 324 170 106 324 minecraft:magenta_terracotta
fill 154 106 335 154 106 341 minecraft:magenta_terracotta
fill 154 106 342 157 106 346 minecraft:mossy_stone_bricks
fill 154 106 347 154 106 351 minecraft:magenta_terracotta
fill 154 106 362 170 106 362 minecraft:magenta_terracotta
fill 154 106 363 170 106 363 minecraft:purple_terracotta
fill 155 106 335 155 106 339 minecraft:magenta_terracotta
fill 155 106 340 165 106 341 minecraft:mossy_stone_bricks
fill 155 106 347 165 106 348 minecraft:mossy_stone_bricks
fill 155 106 349 155 106 351 minecraft:magenta_terracotta
fill 156 106 335 157 106 338 minecraft:magenta_terracotta
fill 156 106 339 164 106 339 minecraft:mossy_stone_bricks
fill 156 106 349 164 106 349 minecraft:mossy_stone_bricks
fill 156 106 350 157 106 351 minecraft:magenta_terracotta
fill 158 106 335 181 106 337 minecraft:magenta_terracotta
fill 158 106 338 162 106 338 minecraft:mossy_stone_bricks
setblock 158 106 342 minecraft:mossy_stone_bricks
setblock 158 106 346 minecraft:mossy_stone_bricks
fill 158 106 350 162 106 350 minecraft:mossy_stone_bricks
fill 158 106 351 181 106 351 minecraft:magenta_terracotta
fill 162 106 342 166 106 342 minecraft:mossy_stone_bricks
fill 162 106 346 166 106 346 minecraft:mossy_stone_bricks
fill 163 106 338 181 106 338 minecraft:magenta_terracotta
fill 163 106 343 166 106 345 minecraft:mossy_stone_bricks
fill 163 106 350 181 106 350 minecraft:magenta_terracotta
fill 165 106 339 181 106 339 minecraft:magenta_terracotta
fill 165 106 349 181 106 349 minecraft:magenta_terracotta
fill 166 106 340 181 106 341 minecraft:magenta_terracotta
fill 166 106 347 181 106 348 minecraft:magenta_terracotta
fill 167 106 342 181 106 346 minecraft:magenta_terracotta
fill 171 106 323 182 106 323 minecraft:magenta_terracotta
fill 171 106 324 172 106 324 minecraft:purple_terracotta
fill 171 106 362 172 106 362 minecraft:purple_terracotta
fill 171 106 363 182 106 363 minecraft:magenta_terracotta
fill 173 106 324 182 106 324 minecraft:magenta_terracotta
fill 173 106 325 173 107 325 minecraft:purple_terracotta
fill 173 106 361 173 107 361 minecraft:purple_terracotta
fill 173 106 362 182 106 362 minecraft:magenta_terracotta
fill 175 106 325 182 106 325 minecraft:magenta_terracotta
fill 175 106 361 182 106 361 minecraft:magenta_terracotta
fill 176 106 326 182 106 326 minecraft:magenta_terracotta
setblock 176 106 327 minecraft:purple_terracotta
setblock 176 106 359 minecraft:purple_terracotta
fill 176 106 360 182 106 360 minecraft:magenta_terracotta
fill 177 106 327 182 106 327 minecraft:magenta_terracotta
setblock 177 106 328 minecraft:purple_terracotta
setblock 177 106 358 minecraft:purple_terracotta
fill 177 106 359 182 106 359 minecraft:magenta_terracotta
fill 178 106 328 182 106 328 minecraft:magenta_terracotta
setblock 178 106 329 minecraft:purple_terracotta
setblock 178 106 357 minecraft:purple_terracotta
fill 178 106 358 182 106 358 minecraft:magenta_terracotta
fill 179 106 329 182 106 329 minecraft:magenta_terracotta
fill 179 106 357 182 106 357 minecraft:magenta_terracotta
fill 180 106 330 182 106 330 minecraft:magenta_terracotta
fill 180 106 332 180 107 332 minecraft:purple_terracotta
fill 180 106 354 180 107 354 minecraft:purple_terracotta
fill 180 106 356 182 106 356 minecraft:magenta_terracotta
fill 181 106 331 182 106 332 minecraft:magenta_terracotta
fill 181 106 333 181 106 334 minecraft:purple_terracotta
fill 181 106 352 181 106 353 minecraft:purple_terracotta
fill 181 106 354 182 106 355 minecraft:magenta_terracotta
fill 182 106 333 182 106 334 minecraft:magenta_terracotta
fill 182 106 335 182 106 351 minecraft:purple_terracotta
fill 182 106 352 182 106 353 minecraft:magenta_terracotta
setblock 141 107 340 minecraft:cyan_concrete
fill 141 107 341 141 131 341 minecraft:black_concrete
fill 142 107 337 142 107 349 minecraft:purple_terracotta
fill 143 107 334 143 107 336 minecraft:purple_terracotta
fill 143 107 337 151 107 349 minecraft:magenta_terracotta
fill 143 107 350 143 107 352 minecraft:purple_terracotta
setblock 144 107 325 minecraft:light[level=12]
fill 144 107 333 144 108 333 minecraft:purple_terracotta
fill 144 107 334 157 107 336 minecraft:magenta_terracotta
fill 144 107 350 152 107 352 minecraft:magenta_terracotta
fill 144 107 353 144 108 353 minecraft:purple_terracotta
setblock 144 107 360 minecraft:light[level=12]
setblock 145 107 331 minecraft:purple_terracotta
fill 145 107 333 179 108 333 minecraft:magenta_terracotta
fill 145 107 353 179 108 353 minecraft:magenta_terracotta
setblock 145 107 355 minecraft:purple_terracotta
fill 146 107 330 146 108 330 minecraft:purple_terracotta
fill 146 107 331 178 107 331 minecraft:magenta_terracotta
fill 146 107 355 178 107 355 minecraft:magenta_terracotta
fill 146 107 356 146 108 356 minecraft:purple_terracotta
fill 147 107 329 147 108 329 minecraft:purple_terracotta
fill 147 107 330 177 108 330 minecraft:magenta_terracotta
fill 147 107 356 177 108 356 minecraft:magenta_terracotta
fill 147 107 357 147 108 357 minecraft:purple_terracotta
fill 148 107 328 148 108 328 minecraft:purple_terracotta
fill 148 107 329 176 108 329 minecraft:magenta_terracotta
fill 148 107 357 176 108 357 minecraft:magenta_terracotta
fill 148 107 358 148 108 358 minecraft:purple_terracotta
fill 149 107 327 149 108 327 minecraft:purple_terracotta
fill 149 107 328 175 108 328 minecraft:magenta_terracotta
fill 149 107 358 175 108 358 minecraft:magenta_terracotta
fill 149 107 359 149 108 359 minecraft:purple_terracotta
setblock 150 107 326 minecraft:purple_terracotta
fill 150 107 327 174 107 327 minecraft:magenta_terracotta
fill 150 107 359 174 107 359 minecraft:magenta_terracotta
setblock 150 107 360 minecraft:purple_terracotta
fill 151 107 326 173 107 326 minecraft:magenta_terracotta
fill 151 107 360 173 107 360 minecraft:magenta_terracotta
fill 152 107 325 152 108 325 minecraft:purple_terracotta
fill 152 107 337 152 114 341 minecraft:magenta_terracotta
fill 152 107 342 153 116 346 minecraft:stone_bricks
fill 152 107 347 152 115 349 minecraft:magenta_terracotta
fill 152 107 361 152 108 361 minecraft:purple_terracotta
fill 153 107 324 155 107 324 minecraft:purple_terracotta
fill 153 107 325 171 107 325 minecraft:magenta_terracotta
fill 153 107 337 155 119 340 minecraft:cobblestone
fill 153 107 341 154 116 341 minecraft:stone_bricks
fill 153 107 347 154 117 347 minecraft:stone_bricks
fill 153 107 348 155 119 351 minecraft:cobblestone
fill 153 107 352 157 114 352 minecraft:magenta_terracotta
fill 153 107 361 171 107 361 minecraft:magenta_terracotta
fill 153 107 362 155 107 362 minecraft:purple_terracotta
fill 154 107 342 155 107 346 minecraft:magenta_terracotta
fill 155 107 341 156 107 341 minecraft:magenta_terracotta
fill 155 107 347 157 107 347 minecraft:magenta_terracotta
fill 156 107 323 168 107 323 minecraft:purple_terracotta
fill 156 107 324 168 107 324 minecraft:magenta_terracotta
fill 156 107 337 156 119 339 minecraft:cobblestone
fill 156 107 340 157 107 340 minecraft:magenta_terracotta
setblock 156 107 342 minecraft:magenta_terracotta
fill 156 107 343 156 107 345 minecraft:black_concrete
setblock 156 107 346 minecraft:magenta_terracotta
fill 156 107 348 158 107 348 minecraft:magenta_terracotta
fill 156 107 349 156 119 351 minecraft:cobblestone
fill 156 107 362 168 107 362 minecraft:magenta_terracotta
fill 156 107 363 168 107 363 minecraft:purple_terracotta
fill 157 107 337 157 116 338 minecraft:stone_bricks
fill 157 107 339 163 107 339 minecraft:magenta_terracotta
fill 157 107 341 157 107 342 minecraft:black_concrete
setblock 157 107 346 minecraft:black_concrete
fill 157 107 349 163 107 349 minecraft:magenta_terracotta
fill 157 107 350 157 116 351 minecraft:stone_bricks
fill 158 107 334 180 107 335 minecraft:magenta_terracotta
fill 158 107 336 162 116 337 minecraft:stone_bricks
fill 158 107 338 162 108 338 minecraft:magenta_terracotta
fill 158 107 340 162 107 340 minecraft:black_concrete
setblock 158 107 346 minecraft:light[level=12]
setblock 158 107 347 minecraft:black_concrete
fill 158 107 350 162 109 350 minecraft:magenta_terracotta
fill 158 107 351 162 116 352 minecraft:stone_bricks
fill 159 107 348 162 107 348 minecraft:black_concrete
fill 163 107 336 180 108 336 minecraft:magenta_terracotta
fill 163 107 337 163 116 338 minecraft:stone_bricks
fill 163 107 340 164 107 340 minecraft:magenta_terracotta
setblock 163 107 341 minecraft:black_concrete
setblock 163 107 347 minecraft:black_concrete
fill 163 107 348 164 107 348 minecraft:magenta_terracotta
fill 163 107 350 163 117 351 minecraft:stone_bricks
fill 163 107 352 180 107 352 minecraft:magenta_terracotta
fill 164 107 337 167 119 339 minecraft:cobblestone
fill 164 107 341 165 107 341 minecraft:magenta_terracotta
fill 164 107 342 164 107 343 minecraft:black_concrete
fill 164 107 345 164 107 346 minecraft:black_concrete
fill 164 107 347 165 107 347 minecraft:magenta_terracotta
fill 164 107 349 167 119 351 minecraft:cobblestone
fill 165 107 340 167 119 340 minecraft:cobblestone
fill 165 107 342 166 107 343 minecraft:magenta_terracotta
setblock 165 107 344 minecraft:black_concrete
fill 165 107 345 166 107 346 minecraft:magenta_terracotta
fill 165 107 348 167 119 348 minecraft:cobblestone
fill 166 107 341 167 117 341 minecraft:stone_bricks
fill 166 107 344 166 108 344 minecraft:magenta_terracotta
fill 166 107 347 167 116 347 minecraft:stone_bricks
fill 167 107 342 168 116 346 minecraft:stone_bricks
fill 168 107 337 181 107 341 minecraft:magenta_terracotta
fill 168 107 347 180 108 351 minecraft:magenta_terracotta
fill 169 107 324 171 107 324 minecraft:purple_terracotta
fill 169 107 342 181 108 346 minecraft:magenta_terracotta
fill 169 107 362 171 107 362 minecraft:purple_terracotta
fill 172 107 325 172 108 325 minecraft:purple_terracotta
fill 172 107 361 172 108 361 minecraft:purple_terracotta
setblock 174 107 326 minecraft:purple_terracotta
setblock 174 107 360 minecraft:purple_terracotta
fill 175 107 327 175 108 327 minecraft:purple_terracotta
fill 175 107 359 175 108 359 minecraft:purple_terracotta
fill 176 107 328 176 108 328 minecraft:purple_terracotta
fill 176 107 358 176 108 358 minecraft:purple_terracotta
fill 177 107 329 177 108 329 minecraft:purple_terracotta
fill 177 107 357 177 108 357 minecraft:purple_terracotta
fill 178 107 330 178 108 330 minecraft:purple_terracotta
fill 178 107 356 178 108 356 minecraft:purple_terracotta
setblock 179 107 325 minecraft:light[level=12]
setblock 179 107 331 minecraft:purple_terracotta
setblock 179 107 355 minecraft:purple_terracotta
setblock 179 107 360 minecraft:light[level=12]
fill 180 107 333 180 108 333 minecraft:purple_terracotta
fill 180 107 353 180 108 353 minecraft:purple_terracotta
fill 181 107 334 181 107 336 minecraft:purple_terracotta
fill 181 107 347 181 107 349 minecraft:magenta_terracotta
fill 181 107 350 181 107 352 minecraft:purple_terracotta
fill 182 107 337 182 107 349 minecraft:purple_terracotta
fill 141 108 340 141 131 340 minecraft:black_concrete
fill 142 108 338 142 108 348 minecraft:purple_terracotta
fill 143 108 335 143 108 337 minecraft:purple_terracotta
fill 143 108 338 151 108 348 minecraft:magenta_terracotta
fill 143 108 349 143 108 351 minecraft:purple_terracotta
setblock 144 108 334 minecraft:purple_terracotta
fill 144 108 335 151 108 337 minecraft:magenta_terracotta
fill 144 108 349 151 108 351 minecraft:magenta_terracotta
setblock 144 108 352 minecraft:purple_terracotta
setblock 145 108 332 minecraft:purple_terracotta
fill 145 108 334 179 108 334 minecraft:magenta_terracotta
fill 145 108 352 152 108 352 minecraft:magenta_terracotta
setblock 145 108 354 minecraft:purple_terracotta
fill 146 108 331 146 109 331 minecraft:purple_terracotta
fill 146 108 332 178 108 332 minecraft:magenta_terracotta
fill 146 108 354 178 108 354 minecraft:magenta_terracotta
fill 146 108 355 146 109 355 minecraft:purple_terracotta
fill 147 108 331 177 109 331 minecraft:magenta_terracotta
fill 147 108 355 177 109 355 minecraft:magenta_terracotta
fill 150 108 327 150 109 327 minecraft:purple_terracotta
fill 150 108 359 150 109 359 minecraft:purple_terracotta
setblock 151 108 326 minecraft:purple_terracotta
fill 151 108 327 173 108 327 minecraft:magenta_terracotta
fill 151 108 359 173 108 359 minecraft:magenta_terracotta
setblock 151 108 360 minecraft:purple_terracotta
fill 152 108 326 172 108 326 minecraft:magenta_terracotta
fill 152 108 335 157 112 336 minecraft:magenta_terracotta
fill 152 108 350 152 115 351 minecraft:magenta_terracotta
fill 152 108 360 172 108 360 minecraft:magenta_terracotta
setblock 153 108 325 minecraft:purple_terracotta
setblock 153 108 361 minecraft:purple_terracotta
fill 154 108 324 156 108 324 minecraft:purple_terracotta
fill 154 108 325 170 108 325 minecraft:magenta_terracotta
fill 154 108 342 154 109 346 minecraft:magenta_terracotta
fill 154 108 361 170 108 361 minecraft:magenta_terracotta
fill 154 108 362 156 108 362 minecraft:purple_terracotta
fill 155 108 341 155 108 343 minecraft:magenta_terracotta
setblock 155 108 344 minecraft:gray_concrete
fill 155 108 345 155 108 347 minecraft:magenta_terracotta
setblock 156 108 340 minecraft:magenta_terracotta
fill 156 108 341 156 108 343 minecraft:gray_concrete
fill 156 108 345 156 108 346 minecraft:gray_concrete
fill 156 108 347 156 108 348 minecraft:magenta_terracotta
fill 157 108 323 167 108 323 minecraft:purple_terracotta
fill 157 108 324 167 108 324 minecraft:magenta_terracotta
fill 157 108 339 158 108 339 minecraft:magenta_terracotta
fill 157 108 340 158 108 340 minecraft:gray_concrete
setblock 157 108 347 minecraft:gray_concrete
fill 157 108 348 157 108 349 minecraft:magenta_terracotta
fill 157 108 362 167 108 362 minecraft:magenta_terracotta
fill 157 108 363 167 108 363 minecraft:purple_terracotta
fill 158 108 335 180 108 335 minecraft:magenta_terracotta
setblock 158 108 348 minecraft:gray_concrete
setblock 158 108 349 minecraft:magenta_terracotta
fill 159 108 339 162 108 339 minecraft:gray_concrete
fill 159 108 349 161 108 349 minecraft:gray_concrete
fill 162 108 348 163 108 348 minecraft:gray_concrete
fill 162 108 349 163 108 349 minecraft:magenta_terracotta
setblock 163 108 339 minecraft:magenta_terracotta
fill 163 108 340 164 108 340 minecraft:gray_concrete
fill 163 108 352 179 108 352 minecraft:magenta_terracotta
fill 164 108 341 165 108 341 minecraft:gray_concrete
setblock 164 108 347 minecraft:gray_concrete
setblock 164 108 348 minecraft:magenta_terracotta
fill 165 108 342 165 108 346 minecraft:gray_concrete
setblock 165 108 347 minecraft:magenta_terracotta
fill 166 108 342 166 108 343 minecraft:magenta_terracotta
fill 166 108 345 166 108 346 minecraft:magenta_terracotta
fill 168 108 324 170 108 324 minecraft:purple_terracotta
fill 168 108 337 180 109 341 minecraft:magenta_terracotta
fill 168 108 362 170 108 362 minecraft:purple_terracotta
setblock 171 108 325 minecraft:purple_terracotta
setblock 171 108 361 minecraft:purple_terracotta
setblock 173 108 326 minecraft:purple_terracotta
setblock 173 108 360 minecraft:purple_terracotta
fill 174 108 327 174 109 327 minecraft:purple_terracotta
fill 174 108 359 174 109 359 minecraft:purple_terracotta
fill 178 108 331 178 109 331 minecraft:purple_terracotta
fill 178 108 355 178 109 355 minecraft:purple_terracotta
setblock 179 108 332 minecraft:purple_terracotta
setblock 179 108 354 minecraft:purple_terracotta
setblock 180 108 334 minecraft:purple_terracotta
setblock 180 108 352 minecraft:purple_terracotta
fill 181 108 335 181 108 337 minecraft:purple_terracotta
fill 181 108 338 181 108 341 minecraft:magenta_terracotta
fill 181 108 347 181 108 348 minecraft:magenta_terracotta
fill 181 108 349 181 108 351 minecraft:purple_terracotta
fill 182 108 338 182 108 348 minecraft:purple_terracotta
fill 142 109 342 142 109 344 minecraft:purple_terracotta
fill 143 109 337 143 109 341 minecraft:purple_terracotta
fill 143 109 342 151 109 344 minecraft:magenta_terracotta
fill 143 109 345 143 109 349 minecraft:purple_terracotta
setblock 144 109 325 minecraft:light[level=13]
setblock 144 109 333 minecraft:light[level=13]
fill 144 109 335 144 109 336 minecraft:purple_terracotta
fill 144 109 337 151 109 341 minecraft:magenta_terracotta
fill 144 109 345 151 109 349 minecraft:magenta_terracotta
fill 144 109 350 144 109 351 minecraft:purple_terracotta
setblock 144 109 357 minecraft:light[level=13]
fill 145 109 333 145 109 334 minecraft:purple_terracotta
fill 145 109 335 151 109 336 minecraft:magenta_terracotta
fill 145 109 350 151 109 351 minecraft:magenta_terracotta
fill 145 109 352 145 109 353 minecraft:purple_terracotta
fill 146 109 332 146 110 332 minecraft:purple_terracotta
fill 146 109 333 178 109 334 minecraft:magenta_terracotta
fill 146 109 352 152 109 353 minecraft:magenta_terracotta
fill 146 109 354 146 110 354 minecraft:purple_terracotta
setblock 147 109 330 minecraft:purple_terracotta
fill 147 109 332 177 110 332 minecraft:magenta_terracotta
fill 147 109 354 177 110 354 minecraft:magenta_terracotta
setblock 147 109 356 minecraft:purple_terracotta
setblock 148 109 329 minecraft:purple_terracotta
fill 148 109 330 176 109 330 minecraft:magenta_terracotta
fill 148 109 356 176 109 356 minecraft:magenta_terracotta
setblock 148 109 357 minecraft:purple_terracotta
setblock 149 109 328 minecraft:purple_terracotta
fill 149 109 329 175 109 329 minecraft:magenta_terracotta
fill 149 109 357 175 109 357 minecraft:magenta_terracotta
setblock 149 109 358 minecraft:purple_terracotta
fill 150 109 328 174 109 328 minecraft:magenta_terracotta
fill 150 109 358 174 109 358 minecraft:magenta_terracotta
fill 151 109 327 151 110 327 minecraft:purple_terracotta
fill 151 109 359 151 110 359 minecraft:purple_terracotta
setblock 152 109 325 minecraft:light[level=13]
fill 152 109 326 153 109 326 minecraft:purple_terracotta
fill 152 109 327 172 109 327 minecraft:magenta_terracotta
fill 152 109 359 172 109 359 minecraft:magenta_terracotta
fill 152 109 360 153 109 360 minecraft:purple_terracotta
fill 153 109 353 178 109 353 minecraft:magenta_terracotta
fill 154 109 325 155 109 325 minecraft:purple_terracotta
fill 154 109 326 170 109 326 minecraft:magenta_terracotta
fill 154 109 360 170 109 360 minecraft:magenta_terracotta
fill 154 109 361 155 109 361 minecraft:purple_terracotta
setblock 155 109 341 minecraft:magenta_terracotta
fill 155 109 342 155 109 345 minecraft:black_concrete
fill 155 109 346 155 109 347 minecraft:magenta_terracotta
fill 156 109 324 160 109 324 minecraft:purple_terracotta
fill 156 109 325 168 109 325 minecraft:magenta_terracotta
fill 156 109 340 156 109 341 minecraft:black_concrete
fill 156 109 346 156 109 347 minecraft:black_concrete
setblock 156 109 348 minecraft:magenta_terracotta
fill 156 109 361 168 109 361 minecraft:magenta_terracotta
fill 156 109 362 160 109 362 minecraft:purple_terracotta
fill 157 109 339 158 109 339 minecraft:black_concrete
setblock 157 109 348 minecraft:black_concrete
setblock 157 109 349 minecraft:magenta_terracotta
fill 158 109 335 179 109 335 minecraft:magenta_terracotta
setblock 158 109 338 minecraft:magenta_terracotta
fill 158 109 349 163 109 349 minecraft:black_concrete
fill 159 109 338 162 109 338 minecraft:black_concrete
setblock 160 109 341 minecraft:light[level=13]
fill 161 109 323 163 109 323 minecraft:purple_terracotta
fill 161 109 324 163 109 324 minecraft:magenta_terracotta
fill 161 109 362 163 109 362 minecraft:magenta_terracotta
fill 161 109 363 163 109 363 minecraft:purple_terracotta
fill 163 109 336 179 110 336 minecraft:magenta_terracotta
setblock 163 109 339 minecraft:black_concrete
fill 163 109 352 178 110 352 minecraft:magenta_terracotta
fill 164 109 324 168 109 324 minecraft:purple_terracotta
setblock 164 109 348 minecraft:black_concrete
fill 164 109 362 168 109 362 minecraft:purple_terracotta
setblock 165 109 347 minecraft:black_concrete
fill 166 109 342 166 109 346 minecraft:black_concrete
fill 168 109 347 179 109 351 minecraft:magenta_terracotta
fill 169 109 325 170 109 325 minecraft:purple_terracotta
fill 169 109 342 180 110 346 minecraft:magenta_terracotta
fill 169 109 361 170 109 361 minecraft:purple_terracotta
fill 171 109 326 172 109 326 minecraft:purple_terracotta
fill 171 109 360 172 109 360 minecraft:purple_terracotta
fill 173 109 327 173 110 327 minecraft:purple_terracotta
fill 173 109 359 173 110 359 minecraft:purple_terracotta
setblock 175 109 328 minecraft:purple_terracotta
setblock 175 109 358 minecraft:purple_terracotta
setblock 176 109 325 minecraft:light[level=13]
setblock 176 109 329 minecraft:purple_terracotta
setblock 176 109 357 minecraft:purple_terracotta
setblock 177 109 330 minecraft:purple_terracotta
setblock 177 109 356 minecraft:purple_terracotta
fill 178 109 332 178 110 332 minecraft:purple_terracotta
fill 178 109 354 178 110 354 minecraft:purple_terracotta
fill 179 109 333 179 109 334 minecraft:purple_terracotta
fill 179 109 352 179 109 353 minecraft:purple_terracotta
fill 180 109 335 180 109 336 minecraft:purple_terracotta
fill 180 109 347 180 109 349 minecraft:magenta_terracotta
fill 180 109 350 180 109 351 minecraft:purple_terracotta
fill 181 109 337 181 109 341 minecraft:purple_terracotta
fill 181 109 342 181 109 344 minecraft:magenta_terracotta
fill 181 109 345 181 109 349 minecraft:purple_terracotta
fill 182 109 342 182 109 344 minecraft:purple_terracotta
fill 142 110 332 142 110 334 minecraft:blue_terracotta
setblock 142 110 335 minecraft:dark_prismarine
fill 142 110 336 142 110 339 minecraft:blue_terracotta
setblock 142 110 340 minecraft:dark_prismarine
fill 142 110 341 142 112 342 minecraft:blue_terracotta
setblock 142 110 357 minecraft:purple_concrete
setblock 143 110 322 minecraft:light_blue_wool
setblock 143 110 334 minecraft:dark_prismarine
fill 143 110 335 143 110 338 minecraft:blue_terracotta
fill 143 110 339 143 110 347 minecraft:purple_terracotta
setblock 144 110 323 minecraft:purple_concrete
fill 144 110 336 144 110 338 minecraft:purple_terracotta
fill 144 110 339 151 110 347 minecraft:magenta_terracotta
fill 144 110 348 144 110 350 minecraft:purple_terracotta
fill 145 110 334 145 110 335 minecraft:purple_terracotta
fill 145 110 336 151 110 338 minecraft:magenta_terracotta
fill 145 110 348 151 110 350 minecraft:magenta_terracotta
fill 145 110 351 145 110 352 minecraft:purple_terracotta
setblock 146 110 333 minecraft:purple_terracotta
fill 146 110 334 151 110 335 minecraft:magenta_terracotta
fill 146 110 351 151 110 352 minecraft:magenta_terracotta
setblock 146 110 353 minecraft:purple_terracotta
setblock 147 110 331 minecraft:purple_terracotta
fill 147 110 333 177 110 333 minecraft:magenta_terracotta
fill 147 110 353 177 110 353 minecraft:magenta_terracotta
setblock 147 110 355 minecraft:purple_terracotta
setblock 148 110 323 minecraft:blue_terracotta
setblock 148 110 330 minecraft:purple_terracotta
fill 148 110 331 176 110 331 minecraft:magenta_terracotta
fill 148 110 355 176 110 355 minecraft:magenta_terracotta
setblock 148 110 356 minecraft:purple_terracotta
setblock 148 110 363 minecraft:blue_terracotta
setblock 149 110 323 minecraft:dark_prismarine
setblock 149 110 329 minecraft:purple_terracotta
fill 149 110 330 175 110 330 minecraft:magenta_terracotta
fill 149 110 356 175 110 356 minecraft:magenta_terracotta
setblock 149 110 357 minecraft:purple_terracotta
setblock 149 110 363 minecraft:dark_prismarine
fill 150 110 323 152 110 324 minecraft:blue_terracotta
setblock 150 110 328 minecraft:purple_terracotta
fill 150 110 329 174 110 329 minecraft:magenta_terracotta
fill 150 110 357 174 110 357 minecraft:magenta_terracotta
setblock 150 110 358 minecraft:purple_terracotta
setblock 150 110 362 minecraft:dark_prismarine
fill 150 110 363 153 110 363 minecraft:blue_terracotta
fill 151 110 328 173 110 328 minecraft:magenta_terracotta
fill 151 110 358 173 110 358 minecraft:magenta_terracotta
fill 151 110 362 154 110 362 minecraft:blue_terracotta
setblock 152 110 327 minecraft:purple_terracotta
fill 152 110 334 178 110 334 minecraft:magenta_terracotta
fill 152 110 352 152 115 352 minecraft:magenta_terracotta
setblock 152 110 359 minecraft:purple_terracotta
setblock 153 110 323 minecraft:blue_terracotta
setblock 153 110 324 minecraft:dark_prismarine
fill 153 110 326 154 110 326 minecraft:purple_terracotta
fill 153 110 327 171 110 327 minecraft:magenta_terracotta
fill 153 110 359 171 110 359 minecraft:magenta_terracotta
fill 153 110 360 154 110 360 minecraft:purple_terracotta
setblock 154 110 323 minecraft:dark_prismarine
setblock 154 110 342 minecraft:magenta_terracotta
fill 154 110 343 154 110 344 minecraft:black_concrete
fill 154 110 345 154 110 346 minecraft:magenta_terracotta
setblock 154 110 363 minecraft:dark_prismarine
fill 155 110 323 157 111 323 minecraft:blue_terracotta
fill 155 110 325 157 110 325 minecraft:purple_terracotta
fill 155 110 326 169 110 326 minecraft:magenta_terracotta
fill 155 110 341 155 110 342 minecraft:black_concrete
fill 155 110 345 155 110 346 minecraft:black_concrete
setblock 155 110 347 minecraft:magenta_terracotta
fill 155 110 360 169 110 360 minecraft:magenta_terracotta
fill 155 110 361 157 110 361 minecraft:purple_terracotta
setblock 155 110 362 minecraft:dark_prismarine
fill 155 110 363 158 110 363 minecraft:blue_terracotta
setblock 156 110 340 minecraft:black_concrete
fill 156 110 347 156 110 348 minecraft:black_concrete
setblock 157 110 339 minecraft:black_concrete
fill 157 110 349 158 110 349 minecraft:black_concrete
fill 158 110 324 166 110 324 minecraft:purple_terracotta
fill 158 110 325 166 110 325 minecraft:magenta_terracotta
fill 158 110 335 178 111 335 minecraft:magenta_terracotta
setblock 158 110 338 minecraft:black_concrete
setblock 158 110 350 minecraft:magenta_terracotta
fill 158 110 361 166 110 361 minecraft:magenta_terracotta
fill 158 110 362 166 110 362 minecraft:purple_terracotta
fill 159 110 350 162 110 350 minecraft:black_concrete
setblock 159 110 363 minecraft:dark_prismarine
fill 160 110 363 163 110 363 minecraft:blue_terracotta
setblock 163 110 323 minecraft:purple_concrete
setblock 164 110 363 minecraft:dark_prismarine
fill 165 110 363 168 110 363 minecraft:blue_terracotta
fill 167 110 323 168 110 323 minecraft:blue_terracotta
fill 167 110 325 169 110 325 minecraft:purple_terracotta
fill 167 110 361 169 110 361 minecraft:purple_terracotta
fill 167 110 362 169 110 362 minecraft:blue_terracotta
fill 168 110 337 179 110 341 minecraft:magenta_terracotta
fill 168 110 347 178 111 351 minecraft:magenta_terracotta
setblock 169 110 323 minecraft:dark_prismarine
setblock 169 110 363 minecraft:dark_prismarine
fill 170 110 323 172 111 323 minecraft:blue_terracotta
fill 170 110 326 171 110 326 minecraft:purple_terracotta
fill 170 110 360 171 110 360 minecraft:purple_terracotta
setblock 170 110 361 minecraft:blue_terracotta
setblock 170 110 362 minecraft:dark_prismarine
fill 170 110 363 173 110 363 minecraft:blue_terracotta
setblock 171 110 361 minecraft:dark_prismarine
fill 171 110 362 174 110 362 minecraft:blue_terracotta
setblock 172 110 327 minecraft:purple_terracotta
setblock 172 110 359 minecraft:purple_terracotta
setblock 172 110 360 minecraft:dark_prismarine
fill 172 110 361 175 110 361 minecraft:blue_terracotta
setblock 173 110 360 minecraft:blue_terracotta
setblock 174 110 328 minecraft:purple_terracotta
setblock 174 110 358 minecraft:purple_terracotta
setblock 174 110 363 minecraft:dark_prismarine
setblock 175 110 329 minecraft:purple_terracotta
setblock 175 110 357 minecraft:purple_terracotta
setblock 175 110 362 minecraft:dark_prismarine
fill 175 110 363 177 111 363 minecraft:blue_terracotta
setblock 176 110 330 minecraft:purple_terracotta
setblock 176 110 356 minecraft:purple_terracotta
fill 176 110 362 176 111 362 minecraft:blue_terracotta
setblock 177 110 331 minecraft:purple_terracotta
setblock 177 110 355 minecraft:purple_terracotta
setblock 178 110 333 minecraft:purple_terracotta
setblock 178 110 353 minecraft:purple_terracotta
fill 179 110 334 179 110 335 minecraft:purple_terracotta
fill 179 110 347 179 110 350 minecraft:magenta_terracotta
fill 179 110 351 179 110 352 minecraft:purple_terracotta
fill 180 110 336 180 110 338 minecraft:purple_terracotta
fill 180 110 339 180 110 341 minecraft:magenta_terracotta
setblock 180 110 347 minecraft:magenta_terracotta
fill 180 110 348 180 110 350 minecraft:purple_terracotta
setblock 180 110 363 minecraft:purple_concrete
fill 181 110 339 181 110 347 minecraft:purple_terracotta
setblock 182 110 329 minecraft:purple_concrete
setblock 182 110 335 minecraft:dark_prismarine
fill 182 110 336 182 110 339 minecraft:blue_terracotta
setblock 182 110 340 minecraft:dark_prismarine
fill 182 110 341 182 112 342 minecraft:blue_terracotta
setblock 182 110 348 minecraft:purple_concrete
setblock 182 110 354 minecraft:blue_terracotta
setblock 182 110 355 minecraft:dark_prismarine
fill 182 110 356 182 110 359 minecraft:blue_terracotta
setblock 142 111 333 minecraft:blue_terracotta
setblock 142 111 334 minecraft:dark_prismarine
fill 142 111 335 142 111 338 minecraft:blue_terracotta
setblock 142 111 339 minecraft:dark_prismarine
fill 142 111 340 143 113 340 minecraft:blue_terracotta
setblock 142 111 344 minecraft:purple_concrete
setblock 142 111 363 minecraft:purple_concrete
fill 143 111 322 143 131 322 minecraft:black_concrete
fill 143 111 335 143 111 337 minecraft:blue_terracotta
setblock 143 111 338 minecraft:dark_prismarine
fill 143 111 339 143 114 339 minecraft:blue_terracotta
fill 144 111 338 144 111 348 minecraft:purple_terracotta
fill 145 111 335 145 111 337 minecraft:purple_terracotta
fill 145 111 338 151 111 348 minecraft:magenta_terracotta
fill 145 111 349 145 111 351 minecraft:purple_terracotta
setblock 146 111 334 minecraft:purple_terracotta
fill 146 111 335 151 111 337 minecraft:magenta_terracotta
fill 146 111 349 151 111 351 minecraft:magenta_terracotta
setblock 146 111 352 minecraft:purple_terracotta
setblock 147 111 323 minecraft:blue_terracotta
fill 147 111 332 147 111 333 minecraft:purple_terracotta
fill 147 111 334 177 111 334 minecraft:magenta_terracotta
fill 147 111 352 151 111 352 minecraft:magenta_terracotta
fill 147 111 353 147 111 354 minecraft:purple_terracotta
setblock 147 111 363 minecraft:blue_terracotta
setblock 148 111 323 minecraft:dark_prismarine
setblock 148 111 331 minecraft:purple_terracotta
fill 148 111 332 176 111 333 minecraft:magenta_terracotta
fill 148 111 353 176 111 354 minecraft:magenta_terracotta
setblock 148 111 355 minecraft:purple_terracotta
setblock 148 111 363 minecraft:dark_prismarine
fill 149 111 323 152 111 323 minecraft:blue_terracotta
setblock 149 111 330 minecraft:purple_terracotta
fill 149 111 331 175 111 331 minecraft:magenta_terracotta
fill 149 111 355 175 111 355 minecraft:magenta_terracotta
setblock 149 111 356 minecraft:purple_terracotta
setblock 149 111 362 minecraft:dark_prismarine
fill 149 111 363 152 111 363 minecraft:blue_terracotta
fill 150 111 324 151 111 324 minecraft:blue_terracotta
setblock 150 111 329 minecraft:purple_terracotta
fill 150 111 330 174 111 330 minecraft:magenta_terracotta
fill 150 111 356 174 111 356 minecraft:magenta_terracotta
setblock 150 111 357 minecraft:purple_terracotta
fill 150 111 362 153 111 362 minecraft:blue_terracotta
fill 151 111 328 152 111 328 minecraft:purple_terracotta
fill 151 111 329 173 111 329 minecraft:magenta_terracotta
fill 151 111 357 173 111 357 minecraft:magenta_terracotta
fill 151 111 358 152 111 358 minecraft:purple_terracotta
setblock 152 111 324 minecraft:dark_prismarine
setblock 153 111 323 minecraft:dark_prismarine
fill 153 111 324 153 114 324 minecraft:blue_terracotta
setblock 153 111 327 minecraft:purple_terracotta
fill 153 111 328 171 111 328 minecraft:magenta_terracotta
fill 153 111 358 171 111 358 minecraft:magenta_terracotta
setblock 153 111 359 minecraft:purple_terracotta
setblock 153 111 363 minecraft:dark_prismarine
fill 154 111 323 154 114 323 minecraft:blue_terracotta
fill 154 111 326 156 111 326 minecraft:purple_terracotta
fill 154 111 327 170 111 327 minecraft:magenta_terracotta
fill 154 111 342 154 111 346 minecraft:gray_concrete
fill 154 111 359 170 111 359 minecraft:magenta_terracotta
fill 154 111 360 156 111 360 minecraft:purple_terracotta
setblock 154 111 362 minecraft:dark_prismarine
fill 154 111 363 157 111 363 minecraft:blue_terracotta
setblock 155 111 347 minecraft:gray_concrete
fill 155 111 362 155 114 362 minecraft:blue_terracotta
setblock 155 111 364 minecraft:cyan_concrete
setblock 156 111 348 minecraft:gray_concrete
fill 157 111 325 167 111 325 minecraft:purple_terracotta
fill 157 111 326 167 111 326 minecraft:magenta_terracotta
setblock 157 111 349 minecraft:gray_concrete
fill 157 111 360 167 111 360 minecraft:magenta_terracotta
fill 157 111 361 167 111 361 minecraft:purple_terracotta
fill 158 111 350 159 111 350 minecraft:gray_concrete
setblock 158 111 363 minecraft:dark_prismarine
fill 159 111 363 162 111 363 minecraft:blue_terracotta
fill 163 111 336 178 111 336 minecraft:magenta_terracotta
fill 163 111 352 177 111 352 minecraft:magenta_terracotta
setblock 163 111 363 minecraft:dark_prismarine
setblock 164 111 362 minecraft:dark_prismarine
fill 164 111 363 167 111 363 minecraft:blue_terracotta
fill 165 111 362 168 111 362 minecraft:blue_terracotta
fill 166 111 323 167 111 323 minecraft:blue_terracotta
setblock 168 111 323 minecraft:dark_prismarine
fill 168 111 326 170 111 326 minecraft:purple_terracotta
fill 168 111 337 178 111 340 minecraft:magenta_terracotta
setblock 168 111 341 minecraft:gray_concrete
fill 168 111 360 170 111 360 minecraft:purple_terracotta
fill 168 111 361 169 111 361 minecraft:blue_terracotta
setblock 168 111 363 minecraft:dark_prismarine
fill 169 111 323 169 114 323 minecraft:blue_terracotta
fill 169 111 341 179 111 346 minecraft:magenta_terracotta
setblock 169 111 362 minecraft:dark_prismarine
fill 169 111 363 172 111 363 minecraft:blue_terracotta
setblock 170 111 361 minecraft:dark_prismarine
fill 170 111 362 173 111 362 minecraft:blue_terracotta
setblock 171 111 327 minecraft:purple_terracotta
setblock 171 111 359 minecraft:purple_terracotta
setblock 171 111 360 minecraft:dark_prismarine
fill 171 111 361 174 111 361 minecraft:blue_terracotta
fill 172 111 328 173 111 328 minecraft:purple_terracotta
fill 172 111 358 173 111 358 minecraft:purple_terracotta
fill 172 111 360 172 112 360 minecraft:blue_terracotta
setblock 173 111 363 minecraft:dark_prismarine
setblock 174 111 329 minecraft:purple_terracotta
setblock 174 111 357 minecraft:purple_terracotta
setblock 174 111 362 minecraft:dark_prismarine
fill 174 111 363 174 114 363 minecraft:blue_terracotta
setblock 175 111 330 minecraft:purple_terracotta
setblock 175 111 356 minecraft:purple_terracotta
fill 175 111 362 175 114 362 minecraft:blue_terracotta
setblock 176 111 331 minecraft:purple_terracotta
setblock 176 111 355 minecraft:purple_terracotta
fill 177 111 332 177 111 333 minecraft:purple_terracotta
fill 177 111 353 177 111 354 minecraft:purple_terracotta
setblock 178 111 334 minecraft:purple_terracotta
setblock 178 111 352 minecraft:purple_terracotta
fill 179 111 335 179 111 337 minecraft:purple_terracotta
fill 179 111 338 179 111 340 minecraft:magenta_terracotta
fill 179 111 347 179 111 348 minecraft:magenta_terracotta
fill 179 111 349 179 111 351 minecraft:purple_terracotta
fill 180 111 338 180 111 348 minecraft:purple_terracotta
setblock 182 111 323 minecraft:purple_concrete
fill 182 111 335 182 111 338 minecraft:blue_terracotta
setblock 182 111 339 minecraft:dark_prismarine
fill 182 111 340 182 114 340 minecraft:blue_terracotta
fill 182 111 356 182 111 358 minecraft:blue_terracotta
setblock 182 111 359 minecraft:dark_prismarine
setblock 142 112 325 minecraft:purple_concrete
setblock 142 112 333 minecraft:dark_prismarine
fill 142 112 334 142 112 337 minecraft:blue_terracotta
setblock 142 112 338 minecraft:dark_prismarine
fill 142 112 339 142 115 339 minecraft:blue_terracotta
setblock 142 112 343 minecraft:dark_prismarine
setblock 142 112 350 minecraft:purple_concrete
fill 143 112 335 143 112 336 minecraft:blue_terracotta
setblock 143 112 337 minecraft:dark_prismarine
fill 143 112 338 143 115 338 minecraft:blue_terracotta
setblock 143 112 341 minecraft:blue_terracotta
fill 144 112 341 144 112 345 minecraft:purple_terracotta
fill 145 112 337 145 112 340 minecraft:purple_terracotta
fill 145 112 341 151 112 345 minecraft:magenta_terracotta
fill 145 112 346 145 112 349 minecraft:purple_terracotta
fill 145 112 350 145 128 350 minecraft:magenta_terracotta
setblock 146 112 323 minecraft:blue_terracotta
fill 146 112 335 146 112 336 minecraft:purple_terracotta
fill 146 112 337 151 112 340 minecraft:magenta_terracotta
fill 146 112 346 151 112 349 minecraft:magenta_terracotta
fill 146 112 350 146 112 351 minecraft:purple_terracotta
setblock 146 112 363 minecraft:blue_terracotta
setblock 147 112 323 minecraft:dark_prismarine
fill 147 112 333 147 112 334 minecraft:purple_terracotta
fill 147 112 335 151 112 336 minecraft:magenta_terracotta
fill 147 112 350 151 112 351 minecraft:magenta_terracotta
fill 147 112 352 147 112 353 minecraft:purple_terracotta
setblock 147 112 363 minecraft:dark_prismarine
fill 148 112 323 151 112 323 minecraft:blue_terracotta
setblock 148 112 332 minecraft:purple_terracotta
fill 148 112 333 176 112 334 minecraft:magenta_terracotta
fill 148 112 352 151 112 353 minecraft:magenta_terracotta
setblock 148 112 354 minecraft:purple_terracotta
setblock 148 112 362 minecraft:dark_prismarine
fill 148 112 363 151 112 363 minecraft:blue_terracotta
fill 149 112 324 150 112 324 minecraft:blue_terracotta
setblock 149 112 331 minecraft:purple_terracotta
fill 149 112 332 175 112 332 minecraft:magenta_terracotta
fill 149 112 354 175 112 354 minecraft:magenta_terracotta
setblock 149 112 355 minecraft:purple_terracotta
fill 149 112 362 152 112 362 minecraft:blue_terracotta
setblock 150 112 330 minecraft:purple_terracotta
fill 150 112 331 174 112 331 minecraft:magenta_terracotta
fill 150 112 355 174 112 355 minecraft:magenta_terracotta
setblock 150 112 356 minecraft:purple_terracotta
setblock 151 112 324 minecraft:dark_prismarine
setblock 151 112 329 minecraft:purple_terracotta
fill 151 112 330 173 112 330 minecraft:magenta_terracotta
fill 151 112 356 173 112 356 minecraft:magenta_terracotta
setblock 151 112 357 minecraft:purple_terracotta
setblock 152 112 323 minecraft:dark_prismarine
fill 152 112 324 152 115 324 minecraft:blue_terracotta
fill 152 112 328 153 112 328 minecraft:purple_terracotta
fill 152 112 329 172 112 329 minecraft:magenta_terracotta
fill 152 112 353 176 112 353 minecraft:magenta_terracotta
fill 152 112 357 172 112 357 minecraft:magenta_terracotta
fill 152 112 358 153 112 358 minecraft:purple_terracotta
setblock 152 112 363 minecraft:dark_prismarine
fill 153 112 323 153 115 323 minecraft:blue_terracotta
setblock 153 112 362 minecraft:dark_prismarine
fill 153 112 363 156 112 363 minecraft:blue_terracotta
fill 154 112 327 155 112 327 minecraft:purple_terracotta
fill 154 112 328 170 112 328 minecraft:magenta_terracotta
setblock 154 112 342 minecraft:black_concrete
fill 154 112 345 154 112 346 minecraft:black_concrete
fill 154 112 358 170 112 358 minecraft:magenta_terracotta
fill 154 112 359 155 112 359 minecraft:purple_terracotta
fill 154 112 362 154 115 362 minecraft:blue_terracotta
fill 155 112 323 156 112 323 minecraft:blue_terracotta
fill 155 112 364 155 127 364 minecraft:black_concrete
fill 156 112 326 159 112 326 minecraft:purple_terracotta
fill 156 112 327 168 112 327 minecraft:magenta_terracotta
fill 156 112 359 168 112 359 minecraft:magenta_terracotta
fill 156 112 360 159 112 360 minecraft:purple_terracotta
setblock 157 112 323 minecraft:dark_prismarine
setblock 157 112 363 minecraft:dark_prismarine
fill 158 112 335 177 112 335 minecraft:magenta_terracotta
setblock 158 112 350 minecraft:black_concrete
fill 158 112 363 161 112 363 minecraft:blue_terracotta
fill 160 112 325 164 112 325 minecraft:purple_terracotta
fill 160 112 326 164 112 326 minecraft:magenta_terracotta
fill 160 112 360 164 112 360 minecraft:magenta_terracotta
fill 160 112 361 164 112 361 minecraft:purple_terracotta
setblock 162 112 363 minecraft:dark_prismarine
fill 163 112 336 164 112 336 minecraft:black_concrete
fill 163 112 352 176 112 352 minecraft:magenta_terracotta
setblock 163 112 362 minecraft:dark_prismarine
fill 163 112 363 166 112 363 minecraft:blue_terracotta
fill 164 112 362 167 112 362 minecraft:blue_terracotta
fill 165 112 323 166 112 323 minecraft:blue_terracotta
fill 165 112 326 168 112 326 minecraft:purple_terracotta
fill 165 112 336 177 112 336 minecraft:magenta_terracotta
fill 165 112 360 168 112 360 minecraft:purple_terracotta
fill 165 112 361 168 112 361 minecraft:blue_terracotta
setblock 167 112 323 minecraft:dark_prismarine
setblock 167 112 363 minecraft:dark_prismarine
fill 168 112 323 168 115 323 minecraft:blue_terracotta
fill 168 112 337 178 112 338 minecraft:magenta_terracotta
fill 168 112 339 168 112 340 minecraft:black_concrete
setblock 168 112 347 minecraft:black_concrete
fill 168 112 348 177 112 351 minecraft:magenta_terracotta
setblock 168 112 362 minecraft:dark_prismarine
fill 168 112 363 171 112 363 minecraft:blue_terracotta
fill 169 112 327 170 112 327 minecraft:purple_terracotta
fill 169 112 339 178 112 340 minecraft:magenta_terracotta
fill 169 112 341 169 112 346 minecraft:black_concrete
fill 169 112 347 178 112 347 minecraft:magenta_terracotta
fill 169 112 359 170 112 359 minecraft:purple_terracotta
setblock 169 112 360 minecraft:blue_terracotta
setblock 169 112 361 minecraft:dark_prismarine
fill 169 112 362 172 112 362 minecraft:blue_terracotta
fill 170 112 323 171 112 323 minecraft:blue_terracotta
fill 170 112 341 178 112 346 minecraft:magenta_terracotta
setblock 170 112 360 minecraft:dark_prismarine
fill 170 112 361 173 112 361 minecraft:blue_terracotta
fill 171 112 328 172 112 328 minecraft:purple_terracotta
fill 171 112 358 172 112 358 minecraft:purple_terracotta
fill 171 112 360 171 115 360 minecraft:blue_terracotta
setblock 172 112 323 minecraft:dark_prismarine
setblock 172 112 363 minecraft:dark_prismarine
setblock 173 112 329 minecraft:purple_terracotta
setblock 173 112 357 minecraft:purple_terracotta
setblock 173 112 362 minecraft:dark_prismarine
fill 173 112 363 173 115 363 minecraft:blue_terracotta
setblock 174 112 330 minecraft:purple_terracotta
setblock 174 112 356 minecraft:purple_terracotta
setblock 174 112 361 minecraft:dark_prismarine
fill 174 112 362 174 115 362 minecraft:blue_terracotta
setblock 175 112 331 minecraft:purple_terracotta
setblock 175 112 355 minecraft:purple_terracotta
fill 175 112 363 176 112 363 minecraft:blue_terracotta
setblock 176 112 323 minecraft:purple_concrete
setblock 176 112 332 minecraft:purple_terracotta
setblock 176 112 354 minecraft:purple_terracotta
fill 177 112 333 177 112 334 minecraft:purple_terracotta
fill 177 112 352 177 112 353 minecraft:purple_terracotta
setblock 177 112 363 minecraft:dark_prismarine
fill 178 112 335 178 112 336 minecraft:purple_terracotta
fill 178 112 348 178 112 349 minecraft:magenta_terracotta
fill 178 112 350 178 112 351 minecraft:purple_terracotta
fill 179 112 337 179 112 340 minecraft:purple_terracotta
fill 179 112 341 179 112 345 minecraft:magenta_terracotta
fill 179 112 346 179 112 349 minecraft:purple_terracotta
fill 180 112 341 180 112 345 minecraft:purple_terracotta
fill 182 112 336 182 112 337 minecraft:blue_terracotta
setblock 182 112 338 minecraft:dark_prismarine
fill 182 112 339 182 115 339 minecraft:blue_terracotta
setblock 182 112 343 minecraft:dark_prismarine
setblock 182 112 358 minecraft:dark_prismarine
setblock 182 112 361 minecraft:purple_concrete
setblock 142 113 331 minecraft:purple_concrete
fill 142 113 333 142 113 336 minecraft:blue_terracotta
setblock 142 113 337 minecraft:dark_prismarine
fill 142 113 338 142 116 338 minecraft:blue_terracotta
setblock 142 113 341 minecraft:blue_terracotta
setblock 142 113 342 minecraft:dark_prismarine
fill 142 113 343 142 115 344 minecraft:blue_terracotta
setblock 142 113 356 minecraft:purple_concrete
setblock 143 113 335 minecraft:blue_terracotta
setblock 143 113 336 minecraft:dark_prismarine
fill 143 113 337 144 115 337 minecraft:blue_terracotta
setblock 143 113 341 minecraft:dark_prismarine
fill 143 113 342 143 116 342 minecraft:blue_terracotta
setblock 144 113 325 minecraft:light[level=12]
setblock 144 113 332 minecraft:light[level=12]
fill 144 113 338 144 113 339 minecraft:blue_terracotta
setblock 144 113 346 minecraft:light[level=12]
setblock 144 113 353 minecraft:light[level=12]
setblock 144 113 360 minecraft:light[level=12]
setblock 145 113 323 minecraft:blue_terracotta
fill 145 113 340 145 113 346 minecraft:purple_terracotta
fill 145 113 348 145 145 349 minecraft:magenta_terracotta
setblock 145 113 363 minecraft:blue_terracotta
setblock 146 113 323 minecraft:dark_prismarine
fill 146 113 329 146 114 329 minecraft:black_concrete
fill 146 113 337 146 113 339 minecraft:purple_terracotta
fill 146 113 340 151 113 346 minecraft:magenta_terracotta
fill 146 113 347 146 113 349 minecraft:purple_terracotta
fill 146 113 350 146 160 350 minecraft:magenta_terracotta
fill 146 113 351 146 114 351 minecraft:black_concrete
fill 146 113 358 146 114 358 minecraft:black_concrete
setblock 146 113 363 minecraft:dark_prismarine
fill 147 113 323 149 113 324 minecraft:blue_terracotta
fill 147 113 335 147 113 336 minecraft:purple_terracotta
fill 147 113 337 151 113 339 minecraft:magenta_terracotta
fill 147 113 347 151 113 349 minecraft:magenta_terracotta
fill 147 113 350 147 113 351 minecraft:purple_terracotta
setblock 147 113 362 minecraft:dark_prismarine
fill 147 113 363 150 113 363 minecraft:blue_terracotta
fill 148 113 333 148 113 334 minecraft:purple_terracotta
fill 148 113 335 156 113 336 minecraft:magenta_terracotta
fill 148 113 350 151 113 351 minecraft:magenta_terracotta
fill 148 113 352 148 113 353 minecraft:purple_terracotta
fill 148 113 362 151 113 362 minecraft:blue_terracotta
setblock 149 113 332 minecraft:purple_terracotta
fill 149 113 333 175 113 334 minecraft:magenta_terracotta
fill 149 113 352 151 113 353 minecraft:magenta_terracotta
setblock 149 113 354 minecraft:purple_terracotta
setblock 150 113 323 minecraft:blue_terracotta
setblock 150 113 324 minecraft:dark_prismarine
setblock 150 113 331 minecraft:purple_terracotta
fill 150 113 332 174 113 332 minecraft:magenta_terracotta
fill 150 113 354 174 113 354 minecraft:magenta_terracotta
setblock 150 113 355 minecraft:purple_terracotta
setblock 151 113 323 minecraft:dark_prismarine
fill 151 113 324 151 116 324 minecraft:blue_terracotta
setblock 151 113 325 minecraft:light[level=12]
setblock 151 113 330 minecraft:purple_terracotta
fill 151 113 331 173 113 331 minecraft:magenta_terracotta
fill 151 113 355 173 113 355 minecraft:magenta_terracotta
setblock 151 113 356 minecraft:purple_terracotta
fill 151 113 358 151 114 358 minecraft:black_concrete
setblock 151 113 360 minecraft:light[level=12]
setblock 151 113 363 minecraft:dark_prismarine
fill 152 113 323 152 116 323 minecraft:blue_terracotta
fill 152 113 329 153 113 329 minecraft:purple_terracotta
fill 152 113 330 172 113 330 minecraft:magenta_terracotta
fill 152 113 353 175 113 353 minecraft:magenta_terracotta
fill 152 113 356 172 113 356 minecraft:magenta_terracotta
fill 152 113 357 153 113 357 minecraft:purple_terracotta
setblock 152 113 362 minecraft:dark_prismarine
fill 152 113 363 155 113 363 minecraft:blue_terracotta
fill 153 113 362 153 116 362 minecraft:blue_terracotta
fill 154 113 328 155 113 328 minecraft:purple_terracotta
fill 154 113 329 170 113 329 minecraft:magenta_terracotta
fill 154 113 357 170 113 357 minecraft:magenta_terracotta
fill 154 113 358 155 113 358 minecraft:purple_terracotta
setblock 155 113 323 minecraft:blue_terracotta
setblock 156 113 323 minecraft:dark_prismarine
fill 156 113 327 158 113 327 minecraft:purple_terracotta
fill 156 113 328 168 113 328 minecraft:magenta_terracotta
fill 156 113 358 168 113 358 minecraft:magenta_terracotta
fill 156 113 359 158 113 359 minecraft:purple_terracotta
setblock 156 113 362 minecraft:blue_terracotta
setblock 156 113 363 minecraft:dark_prismarine
fill 157 113 323 158 115 323 minecraft:blue_terracotta
fill 157 113 335 158 113 335 minecraft:magenta_terracotta
setblock 157 113 336 minecraft:black_concrete
fill 157 113 363 160 113 363 minecraft:blue_terracotta
setblock 158 113 325 minecraft:light[level=12]
setblock 158 113 339 minecraft:light[level=12]
setblock 158 113 346 minecraft:light[level=12]
setblock 158 113 360 minecraft:light[level=12]
fill 159 113 326 165 113 326 minecraft:purple_terracotta
fill 159 113 327 165 113 327 minecraft:magenta_terracotta
fill 159 113 335 164 113 335 minecraft:black_concrete
fill 159 113 359 165 113 359 minecraft:magenta_terracotta
fill 159 113 360 165 113 360 minecraft:purple_terracotta
setblock 161 113 362 minecraft:blue_terracotta
setblock 161 113 363 minecraft:dark_prismarine
setblock 162 113 362 minecraft:dark_prismarine
fill 162 113 363 165 113 363 minecraft:blue_terracotta
fill 163 113 323 165 113 323 minecraft:blue_terracotta
setblock 163 113 352 minecraft:black_concrete
fill 163 113 362 166 113 362 minecraft:blue_terracotta
fill 164 113 352 175 113 352 minecraft:magenta_terracotta
fill 164 113 361 167 113 361 minecraft:blue_terracotta
setblock 165 113 325 minecraft:light[level=12]
fill 165 113 335 176 113 335 minecraft:magenta_terracotta
fill 165 113 336 166 113 336 minecraft:black_concrete
setblock 165 113 346 minecraft:light[level=12]
setblock 166 113 323 minecraft:dark_prismarine
fill 166 113 327 168 113 327 minecraft:purple_terracotta
fill 166 113 359 168 113 359 minecraft:purple_terracotta
setblock 166 113 363 minecraft:dark_prismarine
fill 167 113 323 167 116 323 minecraft:blue_terracotta
fill 167 113 336 176 113 336 minecraft:magenta_terracotta
fill 167 113 360 168 113 360 minecraft:blue_terracotta
setblock 167 113 362 minecraft:dark_prismarine
fill 167 113 363 170 113 363 minecraft:blue_terracotta
fill 168 113 337 177 113 337 minecraft:magenta_terracotta
setblock 168 113 338 minecraft:black_concrete
fill 168 113 348 168 113 349 minecraft:black_concrete
fill 168 113 350 176 113 351 minecraft:magenta_terracotta
setblock 168 113 361 minecraft:dark_prismarine
fill 168 113 362 171 113 362 minecraft:blue_terracotta
fill 169 113 328 170 113 328 minecraft:purple_terracotta
fill 169 113 338 177 113 338 minecraft:magenta_terracotta
fill 169 113 339 169 113 340 minecraft:black_concrete
fill 169 113 346 169 113 347 minecraft:black_concrete
fill 169 113 348 177 113 349 minecraft:magenta_terracotta
fill 169 113 358 170 113 358 minecraft:purple_terracotta
setblock 169 113 360 minecraft:dark_prismarine
fill 169 113 361 172 113 361 minecraft:blue_terracotta
setblock 170 113 323 minecraft:blue_terracotta
fill 170 113 339 177 113 340 minecraft:magenta_terracotta
fill 170 113 341 170 113 345 minecraft:black_concrete
fill 170 113 346 177 113 347 minecraft:magenta_terracotta
fill 170 113 360 170 116 360 minecraft:blue_terracotta
setblock 171 113 323 minecraft:dark_prismarine
fill 171 113 329 172 113 329 minecraft:purple_terracotta
fill 171 113 341 178 113 345 minecraft:magenta_terracotta
fill 171 113 357 172 113 357 minecraft:purple_terracotta
setblock 171 113 363 minecraft:dark_prismarine
fill 172 113 323 172 116 323 minecraft:blue_terracotta
setblock 172 113 325 minecraft:light[level=12]
setblock 172 113 360 minecraft:light[level=12]
setblock 172 113 362 minecraft:dark_prismarine
fill 172 113 363 172 116 363 minecraft:blue_terracotta
fill 173 113 329 173 114 329 minecraft:iron_bars
setblock 173 113 330 minecraft:purple_terracotta
setblock 173 113 356 minecraft:purple_terracotta
setblock 173 113 361 minecraft:dark_prismarine
fill 173 113 362 173 116 362 minecraft:blue_terracotta
setblock 174 113 331 minecraft:purple_terracotta
setblock 174 113 355 minecraft:purple_terracotta
setblock 175 113 332 minecraft:purple_terracotta
setblock 175 113 354 minecraft:purple_terracotta
setblock 175 113 363 minecraft:blue_terracotta
fill 176 113 333 176 113 334 minecraft:purple_terracotta
fill 176 113 352 176 113 353 minecraft:purple_terracotta
setblock 176 113 363 minecraft:dark_prismarine
fill 177 113 335 177 113 336 minecraft:purple_terracotta
fill 177 113 350 177 113 351 minecraft:purple_terracotta
fill 177 113 355 177 114 355 minecraft:black_concrete
fill 177 113 363 177 116 363 minecraft:blue_terracotta
fill 178 113 336 178 156 336 minecraft:magenta_terracotta
fill 178 113 337 178 113 339 minecraft:purple_terracotta
setblock 178 113 340 minecraft:magenta_terracotta
setblock 178 113 346 minecraft:magenta_terracotta
fill 178 113 347 178 113 349 minecraft:purple_terracotta
setblock 179 113 325 minecraft:light[level=12]
setblock 179 113 332 minecraft:light[level=12]
fill 179 113 337 179 160 338 minecraft:magenta_terracotta
setblock 179 113 339 minecraft:light[level=12]
fill 179 113 340 179 113 346 minecraft:purple_terracotta
setblock 179 113 353 minecraft:light[level=12]
setblock 179 113 360 minecraft:light[level=12]
setblock 179 113 363 minecraft:purple_concrete
setblock 182 113 330 minecraft:purple_concrete
fill 182 113 335 182 113 336 minecraft:blue_terracotta
setblock 182 113 337 minecraft:dark_prismarine
fill 182 113 338 182 116 338 minecraft:blue_terracotta
setblock 182 113 341 minecraft:blue_terracotta
setblock 182 113 342 minecraft:dark_prismarine
fill 182 113 343 182 114 345 minecraft:blue_terracotta
setblock 182 113 355 minecraft:purple_concrete
fill 142 114 332 142 114 335 minecraft:blue_terracotta
setblock 142 114 336 minecraft:dark_prismarine
fill 142 114 337 142 117 337 minecraft:blue_terracotta
setblock 142 114 340 minecraft:blue_terracotta
setblock 142 114 341 minecraft:dark_prismarine
fill 142 114 342 142 117 342 minecraft:blue_terracotta
setblock 142 114 345 minecraft:blue_terracotta
setblock 142 114 362 minecraft:purple_concrete
fill 143 114 323 144 114 323 minecraft:blue_terracotta
setblock 143 114 334 minecraft:blue_terracotta
setblock 143 114 335 minecraft:dark_prismarine
fill 143 114 336 143 117 336 minecraft:blue_terracotta
setblock 143 114 340 minecraft:dark_prismarine
fill 143 114 341 143 117 341 minecraft:blue_terracotta
fill 143 114 343 143 115 343 minecraft:blue_terracotta
setblock 144 114 338 minecraft:blue_terracotta
setblock 144 114 339 minecraft:dark_prismarine
fill 144 114 340 144 117 340 minecraft:blue_terracotta
setblock 144 114 363 minecraft:blue_terracotta
setblock 145 114 323 minecraft:dark_prismarine
fill 145 114 329 145 115 329 minecraft:black_concrete
fill 145 114 342 145 115 342 minecraft:black_concrete
fill 145 114 351 145 115 351 minecraft:black_concrete
setblock 145 114 363 minecraft:dark_prismarine
fill 146 114 323 148 114 324 minecraft:blue_terracotta
fill 146 114 340 146 114 346 minecraft:purple_terracotta
fill 146 114 348 146 134 349 minecraft:magenta_terracotta
fill 146 114 359 146 115 359 minecraft:black_concrete
setblock 146 114 362 minecraft:dark_prismarine
fill 146 114 363 149 114 363 minecraft:blue_terracotta
fill 147 114 337 147 114 339 minecraft:purple_terracotta
fill 147 114 340 151 114 346 minecraft:magenta_terracotta
fill 147 114 347 147 114 349 minecraft:purple_terracotta
fill 147 114 350 147 164 350 minecraft:magenta_terracotta
fill 147 114 362 150 114 362 minecraft:blue_terracotta
fill 148 114 335 148 114 336 minecraft:purple_terracotta
fill 148 114 337 151 114 339 minecraft:magenta_terracotta
fill 148 114 347 151 114 349 minecraft:magenta_terracotta
fill 148 114 350 148 114 351 minecraft:purple_terracotta
setblock 149 114 323 minecraft:blue_terracotta
setblock 149 114 324 minecraft:dark_prismarine
fill 149 114 333 149 114 334 minecraft:purple_terracotta
fill 149 114 335 155 114 336 minecraft:magenta_terracotta
fill 149 114 350 151 114 351 minecraft:magenta_terracotta
fill 149 114 352 149 114 353 minecraft:purple_terracotta
setblock 150 114 323 minecraft:dark_prismarine
fill 150 114 324 150 117 324 minecraft:blue_terracotta
fill 150 114 332 150 114 333 minecraft:purple_terracotta
fill 150 114 334 158 114 334 minecraft:magenta_terracotta
fill 150 114 352 151 114 352 minecraft:magenta_terracotta
fill 150 114 353 150 114 354 minecraft:purple_terracotta
setblock 150 114 363 minecraft:dark_prismarine
fill 151 114 323 151 117 323 minecraft:blue_terracotta
fill 151 114 331 151 114 332 minecraft:purple_terracotta
fill 151 114 333 173 114 333 minecraft:magenta_terracotta
fill 151 114 353 173 114 353 minecraft:magenta_terracotta
fill 151 114 354 151 114 355 minecraft:purple_terracotta
fill 151 114 359 151 115 359 minecraft:black_concrete
setblock 151 114 362 minecraft:dark_prismarine
fill 151 114 363 154 114 363 minecraft:blue_terracotta
fill 152 114 330 152 114 331 minecraft:purple_terracotta
fill 152 114 332 172 114 332 minecraft:magenta_terracotta
fill 152 114 354 172 114 354 minecraft:magenta_terracotta
fill 152 114 355 152 114 356 minecraft:purple_terracotta
fill 152 114 362 152 117 362 minecraft:blue_terracotta
setblock 153 114 330 minecraft:purple_terracotta
fill 153 114 331 171 114 331 minecraft:magenta_terracotta
fill 153 114 355 171 114 355 minecraft:magenta_terracotta
setblock 153 114 356 minecraft:purple_terracotta
setblock 154 114 324 minecraft:dark_prismarine
fill 154 114 329 155 114 329 minecraft:purple_terracotta
fill 154 114 330 170 114 330 minecraft:magenta_terracotta
fill 154 114 343 154 115 343 minecraft:bone_block
fill 154 114 345 155 114 345 minecraft:bone_block
fill 154 114 356 170 114 356 minecraft:magenta_terracotta
fill 154 114 357 155 114 357 minecraft:purple_terracotta
setblock 155 114 323 minecraft:dark_prismarine
setblock 155 114 341 minecraft:bone_block
fill 155 114 347 156 114 347 minecraft:bone_block
setblock 155 114 363 minecraft:dark_prismarine
fill 156 114 323 156 117 323 minecraft:blue_terracotta
fill 156 114 328 158 114 328 minecraft:purple_terracotta
fill 156 114 329 168 114 329 minecraft:magenta_terracotta
setblock 156 114 335 minecraft:magenta_terracotta
setblock 156 114 336 minecraft:gray_concrete
fill 156 114 357 168 114 357 minecraft:magenta_terracotta
fill 156 114 358 158 114 358 minecraft:purple_terracotta
setblock 156 114 362 minecraft:dark_prismarine
fill 156 114 363 159 114 363 minecraft:blue_terracotta
fill 157 114 335 158 114 335 minecraft:gray_concrete
fill 157 114 349 157 115 349 minecraft:bone_block
fill 157 114 362 160 114 362 minecraft:blue_terracotta
setblock 159 114 323 minecraft:blue_terracotta
fill 159 114 327 165 114 327 minecraft:purple_terracotta
fill 159 114 328 165 114 328 minecraft:magenta_terracotta
fill 159 114 334 164 114 334 minecraft:gray_concrete
fill 159 114 350 159 115 350 minecraft:bone_block
fill 159 114 358 165 114 358 minecraft:magenta_terracotta
fill 159 114 359 165 114 359 minecraft:purple_terracotta
setblock 160 114 323 minecraft:dark_prismarine
setblock 160 114 363 minecraft:dark_prismarine
fill 161 114 323 164 114 323 minecraft:blue_terracotta
fill 161 114 335 161 115 335 minecraft:bone_block
setblock 161 114 350 minecraft:bone_block
setblock 161 114 362 minecraft:dark_prismarine
fill 161 114 363 164 114 363 minecraft:blue_terracotta
fill 162 114 362 165 114 362 minecraft:blue_terracotta
fill 163 114 335 163 114 336 minecraft:bone_block
fill 163 114 352 165 114 352 minecraft:gray_concrete
fill 163 114 361 166 114 361 minecraft:blue_terracotta
setblock 165 114 323 minecraft:dark_prismarine
fill 165 114 334 174 114 334 minecraft:magenta_terracotta
fill 165 114 335 166 114 335 minecraft:gray_concrete
fill 165 114 336 165 115 336 minecraft:bone_block
setblock 165 114 363 minecraft:dark_prismarine
fill 166 114 323 166 117 323 minecraft:blue_terracotta
fill 166 114 328 168 114 328 minecraft:purple_terracotta
fill 166 114 352 174 114 352 minecraft:magenta_terracotta
fill 166 114 358 168 114 358 minecraft:purple_terracotta
fill 166 114 360 167 114 360 minecraft:blue_terracotta
setblock 166 114 362 minecraft:dark_prismarine
fill 166 114 363 169 114 363 minecraft:blue_terracotta
fill 167 114 335 175 114 335 minecraft:magenta_terracotta
setblock 167 114 336 minecraft:gray_concrete
setblock 167 114 361 minecraft:dark_prismarine
fill 167 114 362 170 114 362 minecraft:blue_terracotta
fill 168 114 336 175 114 336 minecraft:magenta_terracotta
setblock 168 114 337 minecraft:gray_concrete
fill 168 114 339 169 114 339 minecraft:bone_block
fill 168 114 347 169 114 347 minecraft:bone_block
setblock 168 114 350 minecraft:gray_concrete
fill 168 114 351 175 114 351 minecraft:magenta_terracotta
setblock 168 114 360 minecraft:dark_prismarine
fill 168 114 361 171 114 361 minecraft:blue_terracotta
fill 169 114 328 170 119 328 minecraft:black_concrete
fill 169 114 329 170 114 329 minecraft:purple_terracotta
fill 169 114 337 176 114 337 minecraft:magenta_terracotta
fill 169 114 338 169 117 338 minecraft:bone_block
fill 169 114 341 170 114 341 minecraft:bone_block
fill 169 114 345 170 114 345 minecraft:bone_block
fill 169 114 348 169 117 348 minecraft:bone_block
setblock 169 114 349 minecraft:gray_concrete
fill 169 114 350 175 114 350 minecraft:magenta_terracotta
fill 169 114 357 170 114 357 minecraft:purple_terracotta
fill 169 114 360 169 117 360 minecraft:blue_terracotta
setblock 170 114 323 minecraft:dark_prismarine
fill 170 114 338 176 114 338 minecraft:magenta_terracotta
fill 170 114 339 170 114 340 minecraft:gray_concrete
fill 170 114 343 170 115 343 minecraft:bone_block
fill 170 114 346 170 114 347 minecraft:gray_concrete
fill 170 114 348 176 114 349 minecraft:magenta_terracotta
setblock 170 114 363 minecraft:dark_prismarine
fill 171 114 323 171 117 323 minecraft:blue_terracotta
fill 171 114 330 172 114 330 minecraft:purple_terracotta
fill 171 114 339 176 114 341 minecraft:magenta_terracotta
fill 171 114 342 171 114 345 minecraft:gray_concrete
fill 171 114 346 176 114 347 minecraft:magenta_terracotta
fill 171 114 356 172 114 356 minecraft:purple_terracotta
setblock 171 114 362 minecraft:dark_prismarine
fill 171 114 363 171 117 363 minecraft:blue_terracotta
fill 172 114 331 173 114 331 minecraft:purple_terracotta
fill 172 114 342 177 114 345 minecraft:magenta_terracotta
fill 172 114 355 173 114 355 minecraft:purple_terracotta
setblock 172 114 361 minecraft:dark_prismarine
fill 172 114 362 172 117 362 minecraft:blue_terracotta
fill 173 114 332 174 114 332 minecraft:purple_terracotta
fill 173 114 354 174 114 354 minecraft:purple_terracotta
fill 173 114 361 173 116 361 minecraft:blue_terracotta
fill 174 114 333 175 114 333 minecraft:purple_terracotta
fill 174 114 353 175 114 353 minecraft:purple_terracotta
setblock 175 114 334 minecraft:purple_terracotta
setblock 175 114 352 minecraft:purple_terracotta
setblock 175 114 363 minecraft:dark_prismarine
fill 176 114 322 180 115 322 minecraft:black_concrete
fill 176 114 335 176 114 336 minecraft:purple_terracotta
fill 176 114 350 176 114 351 minecraft:purple_terracotta
fill 176 114 363 176 117 363 minecraft:blue_terracotta
fill 177 114 336 177 153 336 minecraft:magenta_terracotta
fill 177 114 337 177 114 339 minecraft:purple_terracotta
fill 177 114 340 177 114 341 minecraft:magenta_terracotta
setblock 177 114 346 minecraft:magenta_terracotta
fill 177 114 347 177 114 349 minecraft:purple_terracotta
fill 178 114 337 178 128 339 minecraft:magenta_terracotta
fill 178 114 340 178 114 346 minecraft:purple_terracotta
fill 178 114 355 178 115 355 minecraft:black_concrete
setblock 181 114 322 minecraft:cyan_concrete
fill 181 114 339 181 114 341 minecraft:blue_terracotta
setblock 181 114 342 minecraft:dark_prismarine
fill 182 114 322 183 128 322 minecraft:black_concrete
setblock 182 114 324 minecraft:purple_concrete
setblock 182 114 335 minecraft:blue_terracotta
setblock 182 114 336 minecraft:dark_prismarine
fill 182 114 337 182 117 337 minecraft:blue_terracotta
setblock 182 114 341 minecraft:dark_prismarine
fill 182 114 342 182 117 342 minecraft:blue_terracotta
setblock 182 114 346 minecraft:dark_prismarine
setblock 182 114 349 minecraft:purple_concrete
fill 182 114 359 182 114 360 minecraft:blue_terracotta
setblock 182 114 361 minecraft:dark_prismarine
setblock 141 115 343 minecraft:light_blue_wool
fill 142 115 323 142 115 324 minecraft:blue_terracotta
fill 142 115 331 142 115 334 minecraft:blue_terracotta
setblock 142 115 335 minecraft:dark_prismarine
fill 142 115 336 142 118 336 minecraft:blue_terracotta
setblock 142 115 340 minecraft:dark_prismarine
fill 142 115 341 142 118 341 minecraft:blue_terracotta
setblock 142 115 345 minecraft:dark_prismarine
fill 142 115 346 142 118 346 minecraft:blue_terracotta
fill 142 115 361 142 116 363 minecraft:blue_terracotta
setblock 143 115 323 minecraft:blue_terracotta
setblock 143 115 334 minecraft:dark_prismarine
fill 143 115 335 143 118 335 minecraft:blue_terracotta
setblock 143 115 339 minecraft:dark_prismarine
fill 143 115 340 143 118 340 minecraft:blue_terracotta
setblock 143 115 344 minecraft:dark_prismarine
setblock 143 115 363 minecraft:blue_terracotta
setblock 144 115 323 minecraft:dark_prismarine
fill 144 115 324 147 115 324 minecraft:blue_terracotta
fill 144 115 329 144 116 329 minecraft:black_concrete
fill 144 115 336 144 116 336 minecraft:blue_terracotta
setblock 144 115 338 minecraft:dark_prismarine
fill 144 115 339 144 118 339 minecraft:blue_terracotta
fill 144 115 341 144 115 342 minecraft:blue_terracotta
fill 144 115 351 144 116 351 minecraft:black_concrete
setblock 144 115 363 minecraft:dark_prismarine
fill 145 115 323 148 115 323 minecraft:blue_terracotta
setblock 145 115 362 minecraft:dark_prismarine
fill 145 115 363 148 115 363 minecraft:blue_terracotta
fill 146 115 360 146 116 360 minecraft:black_concrete
fill 146 115 362 149 115 362 minecraft:blue_terracotta
fill 147 115 340 148 115 346 minecraft:purple_terracotta
fill 147 115 348 147 160 349 minecraft:magenta_terracotta
setblock 148 115 324 minecraft:dark_prismarine
fill 148 115 325 150 116 325 minecraft:blue_terracotta
fill 148 115 335 148 119 336 minecraft:magenta_terracotta
fill 148 115 337 148 115 339 minecraft:purple_terracotta
fill 148 115 347 148 115 349 minecraft:purple_terracotta
fill 148 115 361 150 115 361 minecraft:blue_terracotta
setblock 149 115 323 minecraft:dark_prismarine
fill 149 115 324 149 118 324 minecraft:blue_terracotta
fill 149 115 334 149 128 334 minecraft:magenta_terracotta
fill 149 115 335 149 115 338 minecraft:purple_terracotta
fill 149 115 339 151 115 347 minecraft:magenta_terracotta
fill 149 115 348 149 115 351 minecraft:purple_terracotta
setblock 149 115 363 minecraft:dark_prismarine
fill 150 115 323 150 118 323 minecraft:blue_terracotta
fill 150 115 334 150 115 336 minecraft:purple_terracotta
fill 150 115 337 152 115 338 minecraft:magenta_terracotta
fill 150 115 348 151 115 349 minecraft:magenta_terracotta
fill 150 115 350 150 115 352 minecraft:purple_terracotta
setblock 150 115 362 minecraft:dark_prismarine
fill 150 115 363 153 115 363 minecraft:blue_terracotta
setblock 151 115 322 minecraft:cyan_concrete
fill 151 115 333 151 115 334 minecraft:purple_terracotta
fill 151 115 335 154 115 336 minecraft:magenta_terracotta
fill 151 115 350 151 115 351 minecraft:magenta_terracotta
fill 151 115 352 151 115 353 minecraft:purple_terracotta
fill 151 115 360 151 116 360 minecraft:black_concrete
setblock 151 115 361 minecraft:dark_prismarine
fill 151 115 362 151 118 362 minecraft:blue_terracotta
fill 152 115 332 152 115 333 minecraft:purple_terracotta
fill 152 115 334 156 115 334 minecraft:magenta_terracotta
setblock 152 115 339 minecraft:magenta_terracotta
fill 152 115 340 152 115 341 minecraft:black_concrete
fill 152 115 353 152 115 354 minecraft:purple_terracotta
setblock 153 115 324 minecraft:dark_prismarine
fill 153 115 331 153 115 332 minecraft:purple_terracotta
fill 153 115 333 159 115 333 minecraft:magenta_terracotta
fill 153 115 352 156 115 353 minecraft:magenta_terracotta
fill 153 115 354 153 115 355 minecraft:purple_terracotta
setblock 154 115 323 minecraft:dark_prismarine
fill 154 115 324 154 118 324 minecraft:blue_terracotta
fill 154 115 330 155 115 331 minecraft:purple_terracotta
fill 154 115 332 170 115 332 minecraft:magenta_terracotta
fill 154 115 345 154 116 346 minecraft:bone_block
fill 154 115 354 170 115 354 minecraft:magenta_terracotta
fill 154 115 355 155 115 356 minecraft:purple_terracotta
setblock 154 115 363 minecraft:dark_prismarine
fill 155 115 323 155 118 323 minecraft:blue_terracotta
setblock 155 115 335 minecraft:magenta_terracotta
setblock 155 115 336 minecraft:black_concrete
setblock 155 115 347 minecraft:bone_block
setblock 155 115 362 minecraft:dark_prismarine
fill 155 115 363 158 115 363 minecraft:blue_terracotta
fill 156 115 329 157 115 330 minecraft:purple_terracotta
fill 156 115 331 168 115 331 minecraft:magenta_terracotta
setblock 156 115 335 minecraft:black_concrete
fill 156 115 336 157 116 336 minecraft:bone_block
fill 156 115 355 168 115 355 minecraft:magenta_terracotta
fill 156 115 356 157 115 357 minecraft:purple_terracotta
fill 156 115 362 159 115 362 minecraft:blue_terracotta
fill 157 115 334 159 115 334 minecraft:black_concrete
setblock 157 115 352 minecraft:black_concrete
fill 157 115 353 158 115 353 minecraft:magenta_terracotta
fill 158 115 329 168 115 329 minecraft:purple_terracotta
fill 158 115 330 166 115 330 minecraft:magenta_terracotta
fill 158 115 335 159 116 335 minecraft:bone_block
fill 158 115 356 166 115 356 minecraft:magenta_terracotta
fill 158 115 357 168 115 357 minecraft:purple_terracotta
fill 158 115 358 158 160 358 minecraft:magenta_terracotta
setblock 159 115 323 minecraft:dark_prismarine
fill 159 115 328 165 115 328 minecraft:purple_terracotta
fill 159 115 353 164 115 353 minecraft:black_concrete
fill 159 115 358 165 115 358 minecraft:purple_terracotta
setblock 159 115 363 minecraft:dark_prismarine
fill 160 115 323 163 115 323 minecraft:blue_terracotta
fill 160 115 333 164 115 333 minecraft:black_concrete
setblock 160 115 362 minecraft:dark_prismarine
fill 160 115 363 163 115 363 minecraft:blue_terracotta
fill 161 115 334 161 117 334 minecraft:bone_block
fill 161 115 362 164 115 362 minecraft:blue_terracotta
fill 162 115 361 165 115 361 minecraft:blue_terracotta
fill 163 115 334 163 115 335 minecraft:bone_block
fill 163 115 352 163 117 352 minecraft:bone_block
setblock 164 115 323 minecraft:dark_prismarine
setblock 164 115 363 minecraft:dark_prismarine
fill 165 115 323 165 118 323 minecraft:blue_terracotta
fill 165 115 333 171 115 333 minecraft:magenta_terracotta
fill 165 115 334 166 115 334 minecraft:black_concrete
fill 165 115 335 166 116 335 minecraft:bone_block
fill 165 115 352 166 115 352 minecraft:black_concrete
fill 165 115 353 171 115 353 minecraft:magenta_terracotta
setblock 165 115 362 minecraft:dark_prismarine
fill 165 115 363 168 115 363 minecraft:blue_terracotta
fill 166 115 324 167 115 324 minecraft:blue_terracotta
setblock 166 115 360 minecraft:blue_terracotta
setblock 166 115 361 minecraft:dark_prismarine
fill 166 115 362 169 115 362 minecraft:blue_terracotta
fill 167 115 328 168 119 328 minecraft:black_concrete
fill 167 115 330 170 115 330 minecraft:purple_terracotta
fill 167 115 334 172 115 334 minecraft:magenta_terracotta
fill 167 115 335 168 115 335 minecraft:black_concrete
fill 167 115 336 168 116 336 minecraft:bone_block
fill 167 115 352 172 115 352 minecraft:magenta_terracotta
fill 167 115 356 170 115 356 minecraft:purple_terracotta
setblock 167 115 360 minecraft:dark_prismarine
fill 167 115 361 170 115 361 minecraft:blue_terracotta
setblock 168 115 324 minecraft:dark_prismarine
fill 168 115 337 168 116 337 minecraft:bone_block
fill 168 115 349 168 116 350 minecraft:bone_block
setblock 168 115 351 minecraft:black_concrete
fill 168 115 360 168 118 360 minecraft:blue_terracotta
setblock 169 115 323 minecraft:dark_prismarine
fill 169 115 324 169 118 324 minecraft:blue_terracotta
fill 169 115 329 171 119 329 minecraft:black_concrete
fill 169 115 331 171 115 331 minecraft:purple_terracotta
fill 169 115 335 173 115 335 minecraft:magenta_terracotta
fill 169 115 336 169 115 337 minecraft:black_concrete
setblock 169 115 339 minecraft:bone_block
setblock 169 115 347 minecraft:bone_block
setblock 169 115 350 minecraft:black_concrete
fill 169 115 351 173 115 351 minecraft:magenta_terracotta
fill 169 115 355 171 115 355 minecraft:purple_terracotta
setblock 169 115 363 minecraft:dark_prismarine
fill 170 115 323 170 118 323 minecraft:blue_terracotta
fill 170 115 336 173 115 336 minecraft:magenta_terracotta
setblock 170 115 337 minecraft:black_concrete
fill 170 115 338 170 117 338 minecraft:bone_block
fill 170 115 340 170 116 341 minecraft:bone_block
fill 170 115 345 170 116 346 minecraft:bone_block
fill 170 115 348 170 117 348 minecraft:bone_block
setblock 170 115 349 minecraft:black_concrete
fill 170 115 350 173 115 350 minecraft:magenta_terracotta
setblock 170 115 362 minecraft:dark_prismarine
fill 170 115 363 170 118 363 minecraft:blue_terracotta
fill 171 115 330 171 119 330 minecraft:black_concrete
fill 171 115 332 172 115 332 minecraft:purple_terracotta
fill 171 115 337 174 115 338 minecraft:magenta_terracotta
fill 171 115 339 171 115 340 minecraft:black_concrete
fill 171 115 341 171 117 341 minecraft:bone_block
fill 171 115 343 171 117 343 minecraft:bone_block
fill 171 115 345 171 117 345 minecraft:bone_block
fill 171 115 346 171 115 347 minecraft:black_concrete
fill 171 115 348 174 115 349 minecraft:magenta_terracotta
fill 171 115 354 172 115 354 minecraft:purple_terracotta
setblock 171 115 361 minecraft:dark_prismarine
fill 171 115 362 171 118 362 minecraft:blue_terracotta
fill 172 115 333 173 115 333 minecraft:purple_terracotta
fill 172 115 339 175 115 341 minecraft:magenta_terracotta
fill 172 115 342 172 115 344 minecraft:black_concrete
fill 172 115 345 175 115 347 minecraft:magenta_terracotta
fill 172 115 353 173 115 353 minecraft:purple_terracotta
fill 172 115 361 172 118 361 minecraft:blue_terracotta
setblock 173 115 323 minecraft:blue_terracotta
fill 173 115 334 174 115 334 minecraft:purple_terracotta
fill 173 115 342 175 115 344 minecraft:magenta_terracotta
fill 173 115 352 174 115 352 minecraft:purple_terracotta
fill 174 115 335 175 115 336 minecraft:purple_terracotta
fill 174 115 350 175 115 351 minecraft:purple_terracotta
setblock 174 115 363 minecraft:dark_prismarine
fill 175 115 337 176 115 338 minecraft:purple_terracotta
fill 175 115 348 176 115 349 minecraft:purple_terracotta
fill 175 115 352 175 120 352 minecraft:magenta_terracotta
setblock 175 115 362 minecraft:dark_prismarine
fill 175 115 363 175 118 363 minecraft:blue_terracotta
fill 176 115 339 176 115 347 minecraft:purple_terracotta
fill 176 115 350 176 115 351 minecraft:magenta_terracotta
setblock 177 115 323 minecraft:purple_concrete
fill 177 115 337 177 160 338 minecraft:magenta_terracotta
fill 177 115 340 177 115 346 minecraft:purple_terracotta
fill 179 115 355 179 116 355 minecraft:black_concrete
fill 181 115 322 181 131 322 minecraft:black_concrete
fill 181 115 338 181 115 340 minecraft:blue_terracotta
setblock 181 115 341 minecraft:dark_prismarine
fill 181 115 342 181 116 344 minecraft:blue_terracotta
setblock 182 115 335 minecraft:dark_prismarine
fill 182 115 336 182 118 336 minecraft:blue_terracotta
setblock 182 115 340 minecraft:dark_prismarine
fill 182 115 341 182 118 341 minecraft:blue_terracotta
fill 182 115 343 182 115 344 minecraft:blue_terracotta
setblock 182 115 345 minecraft:dark_prismarine
fill 182 115 346 182 116 348 minecraft:blue_terracotta
fill 182 115 358 182 115 359 minecraft:blue_terracotta
setblock 182 115 360 minecraft:dark_prismarine
fill 182 115 361 182 116 363 minecraft:blue_terracotta
fill 141 116 343 141 127 343 minecraft:black_concrete
setblock 142 116 323 minecraft:blue_terracotta
setblock 142 116 324 minecraft:dark_prismarine
fill 142 116 325 142 116 328 minecraft:blue_terracotta
setblock 142 116 329 minecraft:dark_prismarine
fill 142 116 330 142 116 333 minecraft:blue_terracotta
setblock 142 116 334 minecraft:dark_prismarine
fill 142 116 335 142 119 335 minecraft:blue_terracotta
setblock 142 116 339 minecraft:dark_prismarine
fill 142 116 340 142 119 340 minecraft:blue_terracotta
setblock 142 116 343 minecraft:blue_terracotta
setblock 142 116 344 minecraft:dark_prismarine
fill 142 116 345 143 118 345 minecraft:blue_terracotta
fill 142 116 347 142 117 347 minecraft:blue_terracotta
setblock 142 116 349 minecraft:purple_concrete
fill 142 116 360 142 119 360 minecraft:blue_terracotta
setblock 143 116 323 minecraft:dark_prismarine
fill 143 116 324 143 118 325 minecraft:blue_terracotta
setblock 143 116 329 minecraft:black_concrete
setblock 143 116 333 minecraft:dark_prismarine
fill 143 116 334 143 119 334 minecraft:blue_terracotta
setblock 143 116 337 minecraft:blue_terracotta
setblock 143 116 338 minecraft:dark_prismarine
fill 143 116 339 143 119 339 minecraft:blue_terracotta
setblock 143 116 343 minecraft:dark_prismarine
fill 143 116 344 143 119 344 minecraft:blue_terracotta
fill 143 116 351 143 117 351 minecraft:black_concrete
setblock 143 116 363 minecraft:dark_prismarine
fill 144 116 323 146 116 324 minecraft:blue_terracotta
fill 144 116 335 144 117 335 minecraft:blue_terracotta
setblock 144 116 337 minecraft:dark_prismarine
fill 144 116 338 144 119 338 minecraft:blue_terracotta
setblock 144 116 341 minecraft:blue_terracotta
setblock 144 116 342 minecraft:dark_prismarine
fill 144 116 343 144 119 343 minecraft:blue_terracotta
setblock 144 116 362 minecraft:dark_prismarine
fill 144 116 363 147 116 363 minecraft:blue_terracotta
setblock 145 116 325 minecraft:blue_terracotta
fill 145 116 362 148 116 362 minecraft:blue_terracotta
setblock 146 116 325 minecraft:dark_prismarine
setblock 146 116 361 minecraft:black_concrete
setblock 147 116 323 minecraft:blue_terracotta
setblock 147 116 324 minecraft:dark_prismarine
fill 147 116 325 147 119 325 minecraft:blue_terracotta
fill 147 116 361 149 116 361 minecraft:blue_terracotta
setblock 148 116 323 minecraft:dark_prismarine
fill 148 116 324 148 119 324 minecraft:blue_terracotta
fill 148 116 349 148 188 349 minecraft:magenta_terracotta
setblock 148 116 363 minecraft:dark_prismarine
fill 149 116 323 149 119 323 minecraft:blue_terracotta
fill 149 116 335 149 120 337 minecraft:magenta_terracotta
fill 149 116 339 150 116 347 minecraft:purple_terracotta
setblock 149 116 362 minecraft:dark_prismarine
fill 149 116 363 152 116 363 minecraft:blue_terracotta
fill 150 116 334 150 143 336 minecraft:magenta_terracotta
fill 150 116 337 152 116 338 minecraft:purple_terracotta
fill 150 116 348 152 116 349 minecraft:purple_terracotta
setblock 150 116 361 minecraft:dark_prismarine
fill 150 116 362 150 119 362 minecraft:blue_terracotta
fill 151 116 322 151 131 322 minecraft:black_concrete
setblock 151 116 325 minecraft:dark_prismarine
fill 151 116 335 153 116 336 minecraft:purple_terracotta
fill 151 116 339 151 116 340 minecraft:purple_terracotta
fill 151 116 341 151 116 345 minecraft:black_concrete
fill 151 116 346 151 116 347 minecraft:purple_terracotta
fill 151 116 350 152 116 351 minecraft:purple_terracotta
fill 151 116 361 151 118 361 minecraft:blue_terracotta
setblock 152 116 324 minecraft:dark_prismarine
fill 152 116 334 155 116 334 minecraft:purple_terracotta
setblock 152 116 339 minecraft:black_concrete
fill 152 116 340 152 117 341 minecraft:bone_block
setblock 152 116 347 minecraft:black_concrete
fill 152 116 352 155 116 352 minecraft:purple_terracotta
setblock 153 116 323 minecraft:dark_prismarine
fill 153 116 324 153 119 324 minecraft:blue_terracotta
fill 153 116 333 157 116 333 minecraft:purple_terracotta
fill 153 116 353 157 116 353 minecraft:purple_terracotta
setblock 153 116 363 minecraft:dark_prismarine
fill 154 116 323 154 119 323 minecraft:blue_terracotta
fill 154 116 332 160 116 332 minecraft:purple_terracotta
setblock 154 116 335 minecraft:purple_terracotta
setblock 154 116 336 minecraft:black_concrete
fill 154 116 354 159 116 354 minecraft:purple_terracotta
setblock 154 116 362 minecraft:dark_prismarine
fill 154 116 363 157 116 363 minecraft:blue_terracotta
fill 155 116 324 155 117 324 minecraft:blue_terracotta
fill 155 116 335 155 117 336 minecraft:bone_block
fill 155 116 362 158 116 362 minecraft:blue_terracotta
fill 156 116 331 168 116 331 minecraft:purple_terracotta
setblock 156 116 334 minecraft:black_concrete
fill 156 116 335 156 117 335 minecraft:bone_block
setblock 156 116 352 minecraft:black_concrete
fill 156 116 355 168 116 355 minecraft:purple_terracotta
setblock 157 116 323 minecraft:blue_terracotta
fill 157 116 334 160 117 334 minecraft:bone_block
fill 157 116 352 157 117 352 minecraft:bone_block
fill 157 116 356 157 135 357 minecraft:magenta_terracotta
setblock 158 116 323 minecraft:dark_prismarine
fill 158 116 330 166 116 330 minecraft:purple_terracotta
fill 158 116 333 158 117 333 minecraft:bone_block
fill 158 116 353 158 117 353 minecraft:bone_block
fill 158 116 356 166 116 356 minecraft:purple_terracotta
fill 158 116 357 160 122 357 minecraft:magenta_terracotta
setblock 158 116 363 minecraft:dark_prismarine
fill 159 116 323 162 116 323 minecraft:blue_terracotta
setblock 159 116 333 minecraft:black_concrete
setblock 159 116 353 minecraft:black_concrete
fill 159 116 358 159 132 358 minecraft:magenta_terracotta
setblock 159 116 362 minecraft:dark_prismarine
fill 159 116 363 162 116 363 minecraft:blue_terracotta
fill 160 116 333 161 117 333 minecraft:bone_block
fill 160 116 353 161 117 353 minecraft:bone_block
fill 160 116 354 163 116 354 minecraft:black_concrete
fill 160 116 362 163 116 362 minecraft:blue_terracotta
fill 161 116 332 163 116 332 minecraft:black_concrete
fill 161 116 361 164 116 361 minecraft:blue_terracotta
setblock 163 116 323 minecraft:dark_prismarine
fill 163 116 324 166 116 324 minecraft:blue_terracotta
fill 163 116 333 164 117 334 minecraft:bone_block
fill 163 116 353 164 117 353 minecraft:bone_block
setblock 163 116 363 minecraft:dark_prismarine
fill 164 116 323 164 119 323 minecraft:blue_terracotta
fill 164 116 329 166 124 329 minecraft:magenta_terracotta
fill 164 116 332 170 116 332 minecraft:purple_terracotta
fill 164 116 352 167 117 352 minecraft:bone_block
fill 164 116 354 170 116 354 minecraft:purple_terracotta
setblock 164 116 362 minecraft:dark_prismarine
fill 164 116 363 167 116 363 minecraft:blue_terracotta
fill 165 116 328 165 129 328 minecraft:magenta_terracotta
setblock 165 116 333 minecraft:black_concrete
fill 165 116 334 167 117 334 minecraft:bone_block
setblock 165 116 353 minecraft:black_concrete
setblock 165 116 360 minecraft:blue_terracotta
setblock 165 116 361 minecraft:dark_prismarine
fill 165 116 362 168 116 362 minecraft:blue_terracotta
setblock 166 116 328 minecraft:black_concrete
fill 166 116 333 166 117 333 minecraft:bone_block
fill 166 116 353 166 117 353 minecraft:bone_block
setblock 166 116 360 minecraft:dark_prismarine
fill 166 116 361 169 116 361 minecraft:blue_terracotta
setblock 167 116 324 minecraft:dark_prismarine
fill 167 116 327 170 118 327 minecraft:black_concrete
fill 167 116 329 168 118 330 minecraft:black_concrete
fill 167 116 333 171 116 333 minecraft:purple_terracotta
fill 167 116 353 171 116 353 minecraft:purple_terracotta
fill 167 116 360 167 119 360 minecraft:blue_terracotta
setblock 168 116 323 minecraft:dark_prismarine
fill 168 116 324 168 119 324 minecraft:blue_terracotta
fill 168 116 334 168 119 334 minecraft:black_concrete
fill 168 116 335 169 117 335 minecraft:bone_block
fill 168 116 351 169 117 351 minecraft:bone_block
setblock 168 116 352 minecraft:black_concrete
setblock 168 116 363 minecraft:dark_prismarine
fill 169 116 323 169 119 323 minecraft:blue_terracotta
fill 169 116 330 170 119 331 minecraft:black_concrete
fill 169 116 334 172 116 334 minecraft:purple_terracotta
fill 169 116 336 169 117 336 minecraft:bone_block
fill 169 116 350 169 117 350 minecraft:bone_block
fill 169 116 352 172 116 352 minecraft:purple_terracotta
setblock 169 116 362 minecraft:dark_prismarine
fill 169 116 363 169 119 363 minecraft:blue_terracotta
fill 170 116 324 170 117 324 minecraft:blue_terracotta
fill 170 116 335 173 116 335 minecraft:purple_terracotta
setblock 170 116 336 minecraft:black_concrete
fill 170 116 337 171 117 337 minecraft:bone_block
setblock 170 116 339 minecraft:bone_block
setblock 170 116 347 minecraft:bone_block
fill 170 116 349 171 117 349 minecraft:bone_block
setblock 170 116 350 minecraft:black_concrete
fill 170 116 351 173 116 351 minecraft:purple_terracotta
setblock 170 116 361 minecraft:dark_prismarine
fill 170 116 362 170 119 362 minecraft:blue_terracotta
fill 171 116 328 171 119 328 minecraft:black_concrete
fill 171 116 331 171 119 332 minecraft:black_concrete
fill 171 116 336 173 116 336 minecraft:purple_terracotta
fill 171 116 338 171 117 338 minecraft:bone_block
fill 171 116 340 172 117 340 minecraft:bone_block
fill 171 116 342 172 117 342 minecraft:bone_block
fill 171 116 344 172 117 344 minecraft:bone_block
fill 171 116 346 172 117 346 minecraft:bone_block
fill 171 116 348 171 117 348 minecraft:bone_block
fill 171 116 350 173 116 350 minecraft:purple_terracotta
fill 171 116 361 171 119 361 minecraft:blue_terracotta
fill 172 116 329 172 119 331 minecraft:black_concrete
fill 172 116 337 174 116 338 minecraft:purple_terracotta
setblock 172 116 339 minecraft:black_concrete
fill 172 116 341 172 117 341 minecraft:bone_block
fill 172 116 343 172 117 343 minecraft:bone_block
fill 172 116 345 172 117 345 minecraft:bone_block
setblock 172 116 347 minecraft:black_concrete
fill 172 116 348 174 116 349 minecraft:purple_terracotta
setblock 173 116 323 minecraft:dark_prismarine
fill 173 116 339 175 116 341 minecraft:purple_terracotta
fill 173 116 342 173 116 344 minecraft:black_concrete
fill 173 116 345 175 116 347 minecraft:purple_terracotta
setblock 173 116 363 minecraft:dark_prismarine
fill 174 116 342 175 116 344 minecraft:purple_terracotta
fill 174 116 350 174 140 352 minecraft:magenta_terracotta
setblock 174 116 362 minecraft:dark_prismarine
fill 174 116 363 174 119 363 minecraft:blue_terracotta
fill 175 116 349 175 118 351 minecraft:magenta_terracotta
fill 175 116 362 175 117 362 minecraft:blue_terracotta
fill 176 116 322 179 128 322 minecraft:black_concrete
fill 176 116 337 176 120 337 minecraft:magenta_terracotta
setblock 178 116 363 minecraft:dark_prismarine
fill 179 116 363 181 117 363 minecraft:blue_terracotta
setblock 180 116 322 minecraft:light_blue_wool
fill 180 116 355 180 117 355 minecraft:black_concrete
fill 181 116 337 181 116 339 minecraft:blue_terracotta
setblock 181 116 340 minecraft:dark_prismarine
fill 181 116 341 181 119 341 minecraft:blue_terracotta
setblock 181 116 345 minecraft:dark_prismarine
fill 181 116 346 181 119 346 minecraft:blue_terracotta
setblock 182 116 331 minecraft:purple_concrete
setblock 182 116 334 minecraft:dark_prismarine
fill 182 116 335 182 119 335 minecraft:blue_terracotta
setblock 182 116 339 minecraft:dark_prismarine
fill 182 116 340 182 119 340 minecraft:blue_terracotta
setblock 182 116 343 minecraft:blue_terracotta
setblock 182 116 344 minecraft:dark_prismarine
fill 182 116 345 182 119 345 minecraft:blue_terracotta
setblock 182 116 349 minecraft:dark_prismarine
setblock 182 116 356 minecraft:purple_concrete
setblock 182 116 358 minecraft:blue_terracotta
setblock 182 116 359 minecraft:dark_prismarine
fill 182 116 360 182 119 360 minecraft:blue_terracotta
setblock 141 117 328 minecraft:light_blue_wool
setblock 142 117 323 minecraft:dark_prismarine
fill 142 117 324 142 117 327 minecraft:blue_terracotta
setblock 142 117 328 minecraft:dark_prismarine
fill 142 117 329 142 117 332 minecraft:blue_terracotta
setblock 142 117 333 minecraft:dark_prismarine
fill 142 117 334 142 120 334 minecraft:blue_terracotta
setblock 142 117 338 minecraft:dark_prismarine
fill 142 117 339 142 120 339 minecraft:blue_terracotta
setblock 142 117 343 minecraft:dark_prismarine
fill 142 117 344 142 120 344 minecraft:blue_terracotta
setblock 142 117 348 minecraft:dark_prismarine
fill 142 117 351 142 118 351 minecraft:black_concrete
setblock 142 117 355 minecraft:purple_concrete
fill 142 117 359 142 120 359 minecraft:blue_terracotta
fill 142 117 361 142 117 362 minecraft:blue_terracotta
setblock 142 117 363 minecraft:dark_prismarine
fill 143 117 323 146 117 323 minecraft:blue_terracotta
setblock 143 117 326 minecraft:blue_terracotta
setblock 143 117 327 minecraft:dark_prismarine
fill 143 117 328 143 117 331 minecraft:blue_terracotta
setblock 143 117 332 minecraft:dark_prismarine
fill 143 117 333 143 120 333 minecraft:blue_terracotta
setblock 143 117 337 minecraft:dark_prismarine
fill 143 117 338 143 120 338 minecraft:blue_terracotta
setblock 143 117 342 minecraft:dark_prismarine
fill 143 117 343 143 120 343 minecraft:blue_terracotta
setblock 143 117 346 minecraft:blue_terracotta
setblock 143 117 361 minecraft:blue_terracotta
setblock 143 117 362 minecraft:dark_prismarine
fill 143 117 363 146 117 363 minecraft:blue_terracotta
fill 144 117 324 144 117 325 minecraft:blue_terracotta
setblock 144 117 326 minecraft:dark_prismarine
setblock 144 117 333 minecraft:light[level=13]
setblock 144 117 336 minecraft:dark_prismarine
fill 144 117 337 144 120 337 minecraft:blue_terracotta
setblock 144 117 341 minecraft:dark_prismarine
fill 144 117 342 144 120 342 minecraft:blue_terracotta
fill 144 117 344 144 118 344 minecraft:blue_terracotta
setblock 144 117 349 minecraft:light[level=13]
setblock 144 117 357 minecraft:light[level=13]
fill 144 117 362 147 117 362 minecraft:blue_terracotta
setblock 144 117 364 minecraft:cyan_concrete
setblock 145 117 324 minecraft:blue_terracotta
setblock 145 117 325 minecraft:dark_prismarine
setblock 145 117 339 minecraft:blue_terracotta
setblock 145 117 340 minecraft:dark_prismarine
fill 145 117 341 145 119 341 minecraft:blue_terracotta
fill 145 117 364 145 128 364 minecraft:black_concrete
setblock 146 117 324 minecraft:dark_prismarine
fill 146 117 325 146 120 325 minecraft:blue_terracotta
fill 146 117 361 148 117 361 minecraft:blue_terracotta
setblock 147 117 323 minecraft:dark_prismarine
fill 147 117 324 147 120 324 minecraft:blue_terracotta
setblock 147 117 363 minecraft:dark_prismarine
fill 148 117 323 148 120 323 minecraft:blue_terracotta
fill 148 117 325 149 117 325 minecraft:blue_terracotta
setblock 148 117 362 minecraft:dark_prismarine
fill 148 117 363 151 117 363 minecraft:blue_terracotta
setblock 149 117 361 minecraft:dark_prismarine
fill 149 117 362 149 120 362 minecraft:blue_terracotta
setblock 150 117 325 minecraft:dark_prismarine
fill 150 117 337 150 126 337 minecraft:magenta_terracotta
fill 150 117 361 150 119 361 minecraft:blue_terracotta
setblock 151 117 324 minecraft:dark_prismarine
fill 151 117 325 152 119 325 minecraft:blue_terracotta
fill 151 117 335 151 134 336 minecraft:magenta_terracotta
setblock 151 117 340 minecraft:bone_block
fill 151 117 342 151 117 344 minecraft:bone_block
fill 151 117 346 153 117 346 minecraft:bone_block
setblock 152 117 323 minecraft:dark_prismarine
fill 152 117 324 152 120 324 minecraft:blue_terracotta
setblock 152 117 333 minecraft:light[level=13]
setblock 152 117 339 minecraft:bone_block
fill 152 117 342 153 117 342 minecraft:stone_bricks
setblock 152 117 343 minecraft:bone_block
fill 152 117 344 152 117 345 minecraft:stone_bricks
setblock 152 117 347 minecraft:bone_block
setblock 152 117 349 minecraft:light[level=13]
setblock 152 117 357 minecraft:light[level=13]
setblock 152 117 363 minecraft:dark_prismarine
fill 153 117 323 153 120 323 minecraft:blue_terracotta
setblock 153 117 341 minecraft:bone_block
fill 153 117 343 153 117 344 minecraft:stone_bricks
setblock 153 117 345 minecraft:bone_block
setblock 153 117 362 minecraft:dark_prismarine
fill 153 117 363 156 117 363 minecraft:blue_terracotta
setblock 154 117 335 minecraft:bone_block
fill 154 117 362 157 117 362 minecraft:blue_terracotta
setblock 155 117 334 minecraft:bone_block
setblock 155 117 352 minecraft:bone_block
setblock 156 117 324 minecraft:dark_prismarine
setblock 156 117 336 minecraft:bone_block
setblock 157 117 323 minecraft:dark_prismarine
fill 157 117 324 160 117 324 minecraft:blue_terracotta
setblock 157 117 333 minecraft:bone_block
fill 157 117 337 158 117 337 minecraft:stone_bricks
setblock 157 117 350 minecraft:stone_bricks
setblock 157 117 353 minecraft:bone_block
setblock 157 117 363 minecraft:dark_prismarine
fill 158 117 323 161 117 323 minecraft:blue_terracotta
setblock 158 117 335 minecraft:bone_block
setblock 158 117 336 minecraft:stone_bricks
fill 158 117 351 158 117 352 minecraft:bone_block
fill 158 117 355 159 120 356 minecraft:magenta_terracotta
setblock 158 117 362 minecraft:dark_prismarine
fill 158 117 363 161 117 363 minecraft:blue_terracotta
setblock 159 117 333 minecraft:bone_block
fill 159 117 351 160 117 352 minecraft:stone_bricks
setblock 159 117 353 minecraft:bone_block
fill 159 117 362 162 117 362 minecraft:blue_terracotta
setblock 160 117 325 minecraft:light[level=13]
fill 160 117 332 161 117 332 minecraft:bone_block
setblock 160 117 341 minecraft:light[level=13]
setblock 160 117 349 minecraft:light[level=13]
fill 160 117 354 161 117 354 minecraft:bone_block
fill 160 117 356 160 121 356 minecraft:magenta_terracotta
fill 160 117 361 163 117 361 minecraft:blue_terracotta
setblock 161 117 324 minecraft:dark_prismarine
fill 161 117 336 162 117 337 minecraft:stone_bricks
setblock 161 117 352 minecraft:bone_block
setblock 162 117 323 minecraft:dark_prismarine
fill 162 117 324 165 117 324 minecraft:blue_terracotta
setblock 162 117 363 minecraft:dark_prismarine
fill 163 117 323 163 120 323 minecraft:blue_terracotta
fill 163 117 332 164 117 332 minecraft:bone_block
fill 163 117 354 164 117 354 minecraft:bone_block
setblock 163 117 362 minecraft:dark_prismarine
fill 163 117 363 166 117 363 minecraft:blue_terracotta
fill 164 117 330 166 124 330 minecraft:magenta_terracotta
setblock 164 117 360 minecraft:blue_terracotta
setblock 164 117 361 minecraft:dark_prismarine
fill 164 117 362 167 117 362 minecraft:blue_terracotta
fill 165 117 331 166 126 331 minecraft:magenta_terracotta
fill 165 117 332 170 119 332 minecraft:black_concrete
setblock 165 117 333 minecraft:bone_block
setblock 165 117 353 minecraft:bone_block
setblock 165 117 360 minecraft:dark_prismarine
fill 165 117 361 168 117 361 minecraft:blue_terracotta
setblock 166 117 324 minecraft:dark_prismarine
fill 166 117 328 166 157 328 minecraft:magenta_terracotta
setblock 166 117 335 minecraft:bone_block
fill 166 117 360 166 120 360 minecraft:blue_terracotta
setblock 167 117 323 minecraft:dark_prismarine
fill 167 117 324 167 120 324 minecraft:blue_terracotta
fill 167 117 331 168 119 331 minecraft:black_concrete
setblock 167 117 333 minecraft:bone_block
setblock 167 117 342 minecraft:stone_bricks
fill 167 117 344 168 117 345 minecraft:stone_bricks
setblock 167 117 353 minecraft:bone_block
setblock 167 117 363 minecraft:dark_prismarine
fill 168 117 323 168 120 323 minecraft:blue_terracotta
setblock 168 117 325 minecraft:light[level=13]
fill 168 117 333 171 119 333 minecraft:black_concrete
setblock 168 117 336 minecraft:bone_block
setblock 168 117 341 minecraft:light[level=13]
setblock 168 117 346 minecraft:stone_bricks
setblock 168 117 349 minecraft:light[level=13]
setblock 168 117 350 minecraft:bone_block
setblock 168 117 357 minecraft:light[level=13]
setblock 168 117 362 minecraft:dark_prismarine
fill 168 117 363 168 120 363 minecraft:blue_terracotta
setblock 169 117 334 minecraft:bone_block
setblock 169 117 352 minecraft:bone_block
setblock 169 117 361 minecraft:dark_prismarine
fill 169 117 362 169 120 362 minecraft:blue_terracotta
fill 170 117 334 170 119 334 minecraft:black_concrete
setblock 170 117 335 minecraft:bone_block
setblock 170 117 351 minecraft:bone_block
setblock 170 117 360 minecraft:dark_prismarine
fill 170 117 361 170 120 361 minecraft:blue_terracotta
fill 171 117 327 171 118 327 minecraft:black_concrete
fill 171 117 339 172 117 339 minecraft:bone_block
fill 171 117 347 172 117 347 minecraft:bone_block
setblock 172 117 323 minecraft:dark_prismarine
fill 172 117 328 172 119 328 minecraft:black_concrete
fill 172 117 332 172 119 332 minecraft:black_concrete
setblock 172 117 363 minecraft:dark_prismarine
fill 173 117 323 174 119 323 minecraft:blue_terracotta
setblock 173 117 340 minecraft:bone_block
fill 173 117 342 173 117 344 minecraft:bone_block
setblock 173 117 346 minecraft:bone_block
fill 173 117 350 173 134 351 minecraft:magenta_terracotta
setblock 173 117 362 minecraft:dark_prismarine
fill 173 117 363 173 120 363 minecraft:blue_terracotta
fill 174 117 349 174 126 349 minecraft:magenta_terracotta
fill 174 117 362 174 118 362 minecraft:blue_terracotta
setblock 176 117 325 minecraft:light[level=13]
setblock 176 117 333 minecraft:light[level=13]
setblock 176 117 341 minecraft:light[level=13]
setblock 176 117 349 minecraft:light[level=13]
setblock 176 117 357 minecraft:light[level=13]
setblock 177 117 363 minecraft:dark_prismarine
fill 178 117 363 178 120 363 minecraft:blue_terracotta
fill 180 117 322 180 129 322 minecraft:black_concrete
setblock 180 117 340 minecraft:dark_prismarine
fill 180 117 341 180 117 344 minecraft:blue_terracotta
setblock 181 117 323 minecraft:blue_terracotta
fill 181 117 337 181 117 338 minecraft:blue_terracotta
setblock 181 117 339 minecraft:dark_prismarine
fill 181 117 340 181 120 340 minecraft:blue_terracotta
fill 181 117 342 181 117 343 minecraft:blue_terracotta
setblock 181 117 344 minecraft:dark_prismarine
fill 181 117 345 181 120 345 minecraft:blue_terracotta
fill 181 117 347 182 117 347 minecraft:blue_terracotta
fill 181 117 355 181 118 355 minecraft:black_concrete
setblock 182 117 323 minecraft:dark_prismarine
fill 182 117 324 182 119 325 minecraft:blue_terracotta
setblock 182 117 333 minecraft:dark_prismarine
fill 182 117 334 182 120 334 minecraft:blue_terracotta
setblock 182 117 338 minecraft:dark_prismarine
fill 182 117 339 182 120 339 minecraft:blue_terracotta
setblock 182 117 343 minecraft:dark_prismarine
fill 182 117 344 182 120 344 minecraft:blue_terracotta
fill 182 117 346 182 118 346 minecraft:blue_terracotta
setblock 182 117 348 minecraft:dark_prismarine
fill 182 117 349 182 118 351 minecraft:blue_terracotta
setblock 182 117 357 minecraft:blue_terracotta
setblock 182 117 358 minecraft:dark_prismarine
fill 182 117 359 182 120 359 minecraft:blue_terracotta
fill 182 117 361 182 117 362 minecraft:blue_terracotta
setblock 182 117 363 minecraft:dark_prismarine
fill 141 118 328 141 127 328 minecraft:black_concrete
fill 142 118 323 142 118 326 minecraft:blue_terracotta
setblock 142 118 327 minecraft:dark_prismarine
fill 142 118 328 142 118 331 minecraft:blue_terracotta
setblock 142 118 332 minecraft:dark_prismarine
fill 142 118 333 142 121 333 minecraft:blue_terracotta
setblock 142 118 337 minecraft:dark_prismarine
fill 142 118 338 142 121 338 minecraft:blue_terracotta
setblock 142 118 342 minecraft:dark_prismarine
fill 142 118 343 142 121 343 minecraft:blue_terracotta
setblock 142 118 347 minecraft:dark_prismarine
fill 142 118 348 142 120 349 minecraft:blue_terracotta
setblock 142 118 361 minecraft:blue_terracotta
setblock 142 118 362 minecraft:dark_prismarine
fill 142 118 363 145 118 363 minecraft:blue_terracotta
fill 143 118 323 145 118 323 minecraft:blue_terracotta
setblock 143 118 326 minecraft:dark_prismarine
fill 143 118 327 143 118 330 minecraft:blue_terracotta
setblock 143 118 331 minecraft:dark_prismarine
fill 143 118 332 143 121 332 minecraft:blue_terracotta
setblock 143 118 336 minecraft:dark_prismarine
fill 143 118 337 143 121 337 minecraft:blue_terracotta
setblock 143 118 341 minecraft:dark_prismarine
fill 143 118 342 143 121 342 minecraft:blue_terracotta
setblock 143 118 346 minecraft:dark_prismarine
fill 143 118 347 143 121 347 minecraft:blue_terracotta
setblock 143 118 361 minecraft:dark_prismarine
fill 143 118 362 146 118 362 minecraft:blue_terracotta
setblock 144 118 324 minecraft:blue_terracotta
setblock 144 118 325 minecraft:dark_prismarine
fill 144 118 326 144 118 329 minecraft:blue_terracotta
setblock 144 118 334 minecraft:blue_terracotta
setblock 144 118 335 minecraft:dark_prismarine
fill 144 118 336 144 120 336 minecraft:blue_terracotta
setblock 144 118 340 minecraft:dark_prismarine
fill 144 118 341 144 121 341 minecraft:blue_terracotta
setblock 144 118 345 minecraft:dark_prismarine
fill 144 118 364 144 119 364 minecraft:black_concrete
setblock 145 118 324 minecraft:dark_prismarine
fill 145 118 325 145 120 326 minecraft:blue_terracotta
fill 145 118 339 145 119 339 minecraft:dark_prismarine
fill 145 118 340 145 119 340 minecraft:blue_terracotta
fill 145 118 342 145 118 343 minecraft:blue_terracotta
fill 145 118 361 147 118 361 minecraft:blue_terracotta
setblock 146 118 323 minecraft:dark_prismarine
fill 146 118 324 146 121 324 minecraft:blue_terracotta
fill 146 118 326 147 118 326 minecraft:blue_terracotta
setblock 146 118 329 minecraft:sea_lantern
setblock 146 118 335 minecraft:sea_lantern
setblock 146 118 341 minecraft:sea_lantern
setblock 146 118 347 minecraft:sea_lantern
setblock 146 118 353 minecraft:sea_lantern
setblock 146 118 359 minecraft:sea_lantern
setblock 146 118 363 minecraft:dark_prismarine
fill 147 118 323 147 121 323 minecraft:blue_terracotta
setblock 147 118 362 minecraft:dark_prismarine
fill 147 118 363 150 118 363 minecraft:blue_terracotta
setblock 148 118 325 minecraft:blue_terracotta
setblock 148 118 326 minecraft:dark_prismarine
setblock 148 118 327 minecraft:sea_lantern
setblock 148 118 361 minecraft:dark_prismarine
fill 148 118 362 148 121 362 minecraft:blue_terracotta
setblock 149 118 325 minecraft:dark_prismarine
fill 149 118 326 149 121 326 minecraft:blue_terracotta
fill 149 118 361 149 119 361 minecraft:blue_terracotta
setblock 150 118 324 minecraft:dark_prismarine
fill 150 118 325 150 121 325 minecraft:blue_terracotta
setblock 151 118 323 minecraft:dark_prismarine
fill 151 118 324 151 121 324 minecraft:blue_terracotta
setblock 151 118 363 minecraft:dark_prismarine
fill 152 118 323 152 121 323 minecraft:blue_terracotta
setblock 152 118 359 minecraft:sea_lantern
setblock 152 118 362 minecraft:dark_prismarine
fill 152 118 363 155 118 363 minecraft:blue_terracotta
setblock 153 118 325 minecraft:blue_terracotta
fill 153 118 362 156 118 362 minecraft:blue_terracotta
setblock 154 118 327 minecraft:sea_lantern
setblock 155 118 324 minecraft:dark_prismarine
setblock 156 118 323 minecraft:dark_prismarine
fill 156 118 324 159 118 324 minecraft:blue_terracotta
setblock 156 118 363 minecraft:dark_prismarine
fill 157 118 323 160 118 323 minecraft:blue_terracotta
setblock 157 118 362 minecraft:dark_prismarine
fill 157 118 363 160 118 363 minecraft:blue_terracotta
setblock 158 118 359 minecraft:sea_lantern
fill 158 118 362 161 118 362 minecraft:blue_terracotta
setblock 158 118 364 minecraft:cyan_concrete
setblock 160 118 324 minecraft:dark_prismarine
setblock 160 118 327 minecraft:sea_lantern
fill 160 118 361 162 118 361 minecraft:blue_terracotta
setblock 161 118 323 minecraft:dark_prismarine
fill 161 118 324 164 118 324 minecraft:blue_terracotta
setblock 161 118 363 minecraft:dark_prismarine
fill 162 118 323 162 121 323 minecraft:blue_terracotta
setblock 162 118 362 minecraft:dark_prismarine
fill 162 118 363 165 118 363 minecraft:blue_terracotta
setblock 163 118 361 minecraft:dark_prismarine
fill 163 118 362 166 118 362 minecraft:blue_terracotta
setblock 164 118 359 minecraft:sea_lantern
setblock 164 118 360 minecraft:dark_prismarine
fill 164 118 361 167 118 361 minecraft:blue_terracotta
setblock 165 118 324 minecraft:dark_prismarine
fill 165 118 360 165 120 360 minecraft:blue_terracotta
setblock 166 118 323 minecraft:dark_prismarine
fill 166 118 324 166 121 324 minecraft:blue_terracotta
setblock 166 118 327 minecraft:sea_lantern
fill 166 118 333 167 119 333 minecraft:black_concrete
setblock 166 118 363 minecraft:dark_prismarine
fill 167 118 323 167 121 323 minecraft:blue_terracotta
fill 167 118 326 170 118 326 minecraft:black_concrete
fill 167 118 334 167 119 334 minecraft:black_concrete
setblock 167 118 362 minecraft:dark_prismarine
fill 167 118 363 167 121 363 minecraft:blue_terracotta
setblock 168 118 361 minecraft:dark_prismarine
fill 168 118 362 168 121 362 minecraft:blue_terracotta
fill 169 118 334 169 119 334 minecraft:black_concrete
fill 169 118 360 169 119 360 minecraft:dark_prismarine
fill 169 118 361 169 121 361 minecraft:blue_terracotta
setblock 170 118 324 minecraft:dark_prismarine
setblock 170 118 359 minecraft:sea_lantern
setblock 171 118 323 minecraft:dark_prismarine
fill 171 118 324 171 120 324 minecraft:blue_terracotta
fill 171 118 334 171 119 334 minecraft:black_concrete
setblock 171 118 363 minecraft:dark_prismarine
fill 172 118 323 172 121 323 minecraft:blue_terracotta
setblock 172 118 327 minecraft:sea_lantern
fill 172 118 333 172 119 333 minecraft:black_concrete
setblock 172 118 362 minecraft:dark_prismarine
fill 172 118 363 172 121 363 minecraft:blue_terracotta
fill 173 118 329 173 119 331 minecraft:black_concrete
fill 173 118 362 173 119 362 minecraft:blue_terracotta
setblock 176 118 359 minecraft:sea_lantern
setblock 176 118 363 minecraft:dark_prismarine
fill 177 118 363 177 120 363 minecraft:blue_terracotta
setblock 178 118 323 minecraft:purple_concrete
setblock 178 118 327 minecraft:sea_lantern
setblock 178 118 333 minecraft:sea_lantern
setblock 178 118 345 minecraft:sea_lantern
setblock 178 118 351 minecraft:sea_lantern
setblock 178 118 357 minecraft:sea_lantern
fill 179 118 363 180 118 363 minecraft:blue_terracotta
setblock 180 118 323 minecraft:blue_terracotta
fill 180 118 340 180 118 343 minecraft:blue_terracotta
setblock 180 118 344 minecraft:dark_prismarine
fill 180 118 345 180 121 345 minecraft:blue_terracotta
setblock 181 118 323 minecraft:dark_prismarine
fill 181 118 336 181 118 337 minecraft:blue_terracotta
setblock 181 118 338 minecraft:dark_prismarine
fill 181 118 339 181 121 339 minecraft:blue_terracotta
setblock 181 118 342 minecraft:blue_terracotta
setblock 181 118 343 minecraft:dark_prismarine
fill 181 118 344 181 121 344 minecraft:blue_terracotta
setblock 181 118 347 minecraft:blue_terracotta
setblock 181 118 348 minecraft:dark_prismarine
fill 181 118 349 181 121 349 minecraft:blue_terracotta
setblock 181 118 363 minecraft:dark_prismarine
fill 182 118 323 182 121 323 minecraft:blue_terracotta
setblock 182 118 326 minecraft:blue_terracotta
setblock 182 118 327 minecraft:dark_prismarine
fill 182 118 328 182 118 331 minecraft:blue_terracotta
setblock 182 118 332 minecraft:dark_prismarine
fill 182 118 333 182 121 333 minecraft:blue_terracotta
setblock 182 118 337 minecraft:dark_prismarine
fill 182 118 338 182 121 338 minecraft:blue_terracotta
setblock 182 118 342 minecraft:dark_prismarine
fill 182 118 343 182 121 343 minecraft:blue_terracotta
setblock 182 118 347 minecraft:dark_prismarine
fill 182 118 348 182 121 348 minecraft:blue_terracotta
setblock 182 118 352 minecraft:dark_prismarine
fill 182 118 353 182 121 353 minecraft:blue_terracotta
setblock 182 118 357 minecraft:dark_prismarine
fill 182 118 358 182 120 358 minecraft:blue_terracotta
setblock 182 118 361 minecraft:blue_terracotta
setblock 182 118 362 minecraft:dark_prismarine
fill 182 118 363 182 121 363 minecraft:blue_terracotta
fill 142 119 323 142 119 325 minecraft:blue_terracotta
setblock 142 119 326 minecraft:dark_prismarine
fill 142 119 327 142 119 330 minecraft:blue_terracotta
setblock 142 119 331 minecraft:dark_prismarine
fill 142 119 332 142 122 332 minecraft:blue_terracotta
setblock 142 119 336 minecraft:dark_prismarine
fill 142 119 337 142 122 337 minecraft:blue_terracotta
setblock 142 119 341 minecraft:dark_prismarine
fill 142 119 342 142 122 342 minecraft:blue_terracotta
setblock 142 119 345 minecraft:blue_terracotta
setblock 142 119 346 minecraft:dark_prismarine
fill 142 119 347 142 122 347 minecraft:blue_terracotta
setblock 142 119 350 minecraft:blue_terracotta
fill 142 119 351 146 119 358 minecraft:dark_prismarine
setblock 142 119 361 minecraft:dark_prismarine
fill 142 119 362 144 119 363 minecraft:blue_terracotta
fill 143 119 323 143 119 324 minecraft:blue_terracotta
setblock 143 119 325 minecraft:dark_prismarine
fill 143 119 326 143 119 329 minecraft:blue_terracotta
setblock 143 119 330 minecraft:dark_prismarine
fill 143 119 331 144 121 331 minecraft:blue_terracotta
setblock 143 119 335 minecraft:dark_prismarine
fill 143 119 336 143 122 336 minecraft:blue_terracotta
setblock 143 119 340 minecraft:dark_prismarine
fill 143 119 341 143 122 341 minecraft:blue_terracotta
setblock 143 119 345 minecraft:dark_prismarine
fill 143 119 346 144 121 346 minecraft:blue_terracotta
fill 143 119 348 143 120 348 minecraft:blue_terracotta
fill 143 119 349 144 119 350 minecraft:dark_prismarine
fill 143 119 359 163 119 360 minecraft:dark_prismarine
fill 143 119 361 143 122 361 minecraft:blue_terracotta
setblock 144 119 323 minecraft:blue_terracotta
setblock 144 119 324 minecraft:dark_prismarine
fill 144 119 325 144 119 328 minecraft:blue_terracotta
fill 144 119 329 146 119 329 minecraft:dark_prismarine
fill 144 119 330 144 122 330 minecraft:blue_terracotta
fill 144 119 332 144 120 332 minecraft:blue_terracotta
fill 144 119 333 146 119 334 minecraft:dark_prismarine
fill 144 119 335 144 120 335 minecraft:blue_terracotta
setblock 144 119 339 minecraft:dark_prismarine
fill 144 119 340 144 122 340 minecraft:blue_terracotta
fill 144 119 344 146 119 344 minecraft:dark_prismarine
fill 144 119 345 144 122 345 minecraft:blue_terracotta
fill 144 119 347 144 119 348 minecraft:dark_prismarine
setblock 144 119 361 minecraft:dark_prismarine
setblock 145 119 323 minecraft:dark_prismarine
fill 145 119 324 145 122 324 minecraft:blue_terracotta
setblock 145 119 327 minecraft:blue_terracotta
fill 145 119 328 146 119 328 minecraft:dark_prismarine
fill 145 119 330 146 119 332 minecraft:dark_prismarine
fill 145 119 335 146 119 338 minecraft:dark_prismarine
setblock 145 119 342 minecraft:blue_terracotta
fill 145 119 343 146 119 343 minecraft:dark_prismarine
fill 145 119 345 146 119 347 minecraft:dark_prismarine
fill 145 119 361 145 119 362 minecraft:blue_terracotta
setblock 145 119 363 minecraft:dark_prismarine
fill 146 119 323 146 122 323 minecraft:blue_terracotta
setblock 146 119 326 minecraft:blue_terracotta
fill 146 119 327 181 119 327 minecraft:dark_prismarine
fill 146 119 339 146 119 342 minecraft:dark_prismarine
setblock 146 119 361 minecraft:blue_terracotta
setblock 146 119 362 minecraft:dark_prismarine
fill 146 119 363 149 119 363 minecraft:blue_terracotta
setblock 147 119 326 minecraft:dark_prismarine
setblock 147 119 361 minecraft:dark_prismarine
fill 147 119 362 147 122 362 minecraft:blue_terracotta
setblock 148 119 325 minecraft:dark_prismarine
fill 148 119 326 148 122 326 minecraft:blue_terracotta
fill 148 119 361 148 120 361 minecraft:blue_terracotta
setblock 149 119 324 minecraft:dark_prismarine
fill 149 119 325 149 122 325 minecraft:blue_terracotta
setblock 150 119 323 minecraft:dark_prismarine
fill 150 119 324 150 122 324 minecraft:blue_terracotta
fill 150 119 326 182 119 326 minecraft:dark_prismarine
setblock 150 119 363 minecraft:dark_prismarine
fill 151 119 323 151 122 323 minecraft:blue_terracotta
setblock 151 119 332 minecraft:light[level=12]
setblock 151 119 339 minecraft:light[level=12]
setblock 151 119 346 minecraft:light[level=12]
setblock 151 119 353 minecraft:light[level=12]
fill 151 119 361 151 119 362 minecraft:dark_prismarine
fill 151 119 363 154 119 363 minecraft:blue_terracotta
fill 152 119 361 159 119 361 minecraft:dark_prismarine
fill 152 119 362 155 119 362 minecraft:blue_terracotta
fill 153 119 325 163 119 325 minecraft:dark_prismarine
setblock 154 119 324 minecraft:dark_prismarine
setblock 155 119 323 minecraft:dark_prismarine
fill 155 119 324 158 119 324 minecraft:blue_terracotta
setblock 155 119 363 minecraft:dark_prismarine
fill 156 119 323 159 119 323 minecraft:blue_terracotta
setblock 156 119 362 minecraft:dark_prismarine
fill 156 119 363 159 119 363 minecraft:blue_terracotta
fill 157 119 362 160 119 362 minecraft:blue_terracotta
setblock 158 119 332 minecraft:light[level=12]
setblock 158 119 339 minecraft:light[level=12]
setblock 158 119 346 minecraft:light[level=12]
setblock 158 119 353 minecraft:light[level=12]
fill 158 119 364 158 131 364 minecraft:black_concrete
setblock 159 119 324 minecraft:dark_prismarine
setblock 160 119 323 minecraft:dark_prismarine
fill 160 119 324 163 119 324 minecraft:blue_terracotta
fill 160 119 361 161 119 361 minecraft:blue_terracotta
setblock 160 119 363 minecraft:dark_prismarine
fill 161 119 323 161 122 323 minecraft:blue_terracotta
setblock 161 119 362 minecraft:dark_prismarine
fill 161 119 363 164 119 363 minecraft:blue_terracotta
setblock 162 119 361 minecraft:dark_prismarine
fill 162 119 362 165 119 362 minecraft:blue_terracotta
fill 163 119 361 166 119 361 minecraft:blue_terracotta
setblock 164 119 324 minecraft:dark_prismarine
fill 164 119 325 167 119 325 minecraft:blue_terracotta
fill 164 119 331 164 119 332 minecraft:black_concrete
fill 164 119 359 181 119 359 minecraft:dark_prismarine
fill 164 119 360 164 120 360 minecraft:blue_terracotta
setblock 165 119 323 minecraft:dark_prismarine
fill 165 119 324 165 122 324 minecraft:blue_terracotta
setblock 165 119 333 minecraft:black_concrete
setblock 165 119 346 minecraft:light[level=12]
setblock 165 119 353 minecraft:light[level=12]
setblock 165 119 363 minecraft:dark_prismarine
fill 166 119 323 166 122 323 minecraft:blue_terracotta
setblock 166 119 334 minecraft:black_concrete
setblock 166 119 362 minecraft:dark_prismarine
fill 166 119 363 166 122 363 minecraft:blue_terracotta
fill 167 119 329 167 160 330 minecraft:magenta_terracotta
setblock 167 119 361 minecraft:dark_prismarine
fill 167 119 362 167 122 362 minecraft:blue_terracotta
fill 168 119 325 181 119 325 minecraft:dark_prismarine
fill 168 119 329 168 119 330 minecraft:black_concrete
fill 168 119 335 170 119 335 minecraft:black_concrete
setblock 168 119 360 minecraft:dark_prismarine
fill 168 119 361 168 121 361 minecraft:blue_terracotta
setblock 169 119 324 minecraft:dark_prismarine
setblock 170 119 323 minecraft:dark_prismarine
fill 170 119 324 170 121 324 minecraft:blue_terracotta
fill 170 119 360 181 119 360 minecraft:dark_prismarine
setblock 170 119 363 minecraft:dark_prismarine
fill 171 119 323 171 122 323 minecraft:blue_terracotta
setblock 171 119 362 minecraft:dark_prismarine
fill 171 119 363 171 122 363 minecraft:blue_terracotta
fill 172 119 324 180 119 324 minecraft:dark_prismarine
setblock 172 119 339 minecraft:light[level=12]
setblock 172 119 346 minecraft:light[level=12]
setblock 172 119 353 minecraft:light[level=12]
fill 172 119 361 182 119 361 minecraft:dark_prismarine
fill 172 119 362 172 120 362 minecraft:blue_terracotta
setblock 173 119 328 minecraft:black_concrete
setblock 173 119 332 minecraft:black_concrete
fill 174 119 362 181 119 362 minecraft:dark_prismarine
fill 175 119 323 177 119 323 minecraft:dark_prismarine
fill 175 119 350 175 128 351 minecraft:magenta_terracotta
setblock 175 119 363 minecraft:dark_prismarine
fill 176 119 363 176 120 363 minecraft:blue_terracotta
fill 178 119 323 179 119 323 minecraft:blue_terracotta
fill 178 119 328 181 119 335 minecraft:dark_prismarine
fill 178 119 340 179 119 358 minecraft:dark_prismarine
fill 179 119 336 180 119 336 minecraft:dark_prismarine
setblock 179 119 339 minecraft:dark_prismarine
setblock 179 119 363 minecraft:blue_terracotta
setblock 180 119 323 minecraft:dark_prismarine
fill 180 119 337 180 119 338 minecraft:dark_prismarine
fill 180 119 339 180 119 342 minecraft:blue_terracotta
setblock 180 119 343 minecraft:dark_prismarine
fill 180 119 344 180 122 344 minecraft:blue_terracotta
fill 180 119 346 180 119 347 minecraft:blue_terracotta
fill 180 119 348 180 119 358 minecraft:dark_prismarine
setblock 180 119 363 minecraft:dark_prismarine
fill 181 119 323 181 121 324 minecraft:blue_terracotta
setblock 181 119 336 minecraft:blue_terracotta
setblock 181 119 337 minecraft:dark_prismarine
fill 181 119 338 181 122 338 minecraft:blue_terracotta
setblock 181 119 342 minecraft:dark_prismarine
fill 181 119 343 181 122 343 minecraft:blue_terracotta
setblock 181 119 347 minecraft:dark_prismarine
fill 181 119 348 181 122 348 minecraft:blue_terracotta
fill 181 119 350 182 119 350 minecraft:blue_terracotta
fill 181 119 351 181 119 358 minecraft:dark_prismarine
fill 181 119 363 181 122 363 minecraft:blue_terracotta
fill 182 119 327 182 119 330 minecraft:blue_terracotta
setblock 182 119 331 minecraft:dark_prismarine
fill 182 119 332 182 122 332 minecraft:blue_terracotta
setblock 182 119 336 minecraft:dark_prismarine
fill 182 119 337 182 122 337 minecraft:blue_terracotta
setblock 182 119 341 minecraft:dark_prismarine
fill 182 119 342 182 122 342 minecraft:blue_terracotta
setblock 182 119 346 minecraft:dark_prismarine
fill 182 119 347 182 122 347 minecraft:blue_terracotta
fill 182 119 349 182 120 349 minecraft:blue_terracotta
setblock 182 119 351 minecraft:dark_prismarine
fill 182 119 352 182 122 352 minecraft:blue_terracotta
fill 182 119 354 182 120 354 minecraft:blue_terracotta
fill 182 119 355 182 119 356 minecraft:dark_prismarine
setblock 182 119 357 minecraft:blue_terracotta
fill 182 119 362 182 122 362 minecraft:blue_terracotta
setblock 183 119 338 minecraft:light_blue_wool
setblock 183 119 344 minecraft:light_blue_wool
fill 142 120 323 142 120 324 minecraft:blue_terracotta
setblock 142 120 325 minecraft:dark_prismarine
fill 142 120 326 142 120 329 minecraft:blue_terracotta
setblock 142 120 330 minecraft:dark_prismarine
fill 142 120 331 142 123 331 minecraft:blue_terracotta
setblock 142 120 335 minecraft:dark_prismarine
fill 142 120 336 142 123 336 minecraft:blue_terracotta
setblock 142 120 340 minecraft:dark_prismarine
fill 142 120 341 142 123 341 minecraft:blue_terracotta
setblock 142 120 345 minecraft:dark_prismarine
fill 142 120 346 142 123 346 minecraft:blue_terracotta
setblock 142 120 350 minecraft:dark_prismarine
fill 142 120 351 142 123 351 minecraft:blue_terracotta
setblock 142 120 354 minecraft:purple_concrete
setblock 142 120 360 minecraft:dark_prismarine
fill 142 120 361 142 121 363 minecraft:blue_terracotta
setblock 143 120 323 minecraft:blue_terracotta
setblock 143 120 324 minecraft:dark_prismarine
fill 143 120 325 143 120 328 minecraft:blue_terracotta
setblock 143 120 329 minecraft:dark_prismarine
fill 143 120 330 143 123 330 minecraft:blue_terracotta
setblock 143 120 334 minecraft:dark_prismarine
fill 143 120 335 143 123 335 minecraft:blue_terracotta
setblock 143 120 339 minecraft:dark_prismarine
fill 143 120 340 143 123 340 minecraft:blue_terracotta
setblock 143 120 344 minecraft:dark_prismarine
fill 143 120 345 143 123 345 minecraft:blue_terracotta
setblock 143 120 349 minecraft:dark_prismarine
fill 143 120 362 143 120 363 minecraft:blue_terracotta
setblock 144 120 323 minecraft:dark_prismarine
fill 144 120 324 144 120 327 minecraft:blue_terracotta
setblock 144 120 328 minecraft:dark_prismarine
fill 144 120 329 144 123 329 minecraft:blue_terracotta
setblock 144 120 333 minecraft:dark_prismarine
setblock 144 120 338 minecraft:dark_prismarine
fill 144 120 339 144 121 339 minecraft:blue_terracotta
setblock 144 120 343 minecraft:dark_prismarine
fill 144 120 344 144 123 344 minecraft:blue_terracotta
setblock 144 120 347 minecraft:blue_terracotta
setblock 144 120 362 minecraft:blue_terracotta
setblock 144 120 363 minecraft:dark_prismarine
setblock 144 120 364 minecraft:cyan_concrete
fill 145 120 323 145 123 323 minecraft:blue_terracotta
setblock 145 120 327 minecraft:dark_prismarine
fill 145 120 328 145 123 328 minecraft:blue_terracotta
setblock 145 120 342 minecraft:dark_prismarine
setblock 145 120 362 minecraft:dark_prismarine
fill 145 120 363 148 120 363 minecraft:blue_terracotta
setblock 146 120 326 minecraft:dark_prismarine
fill 146 120 327 146 120 347 minecraft:purple_concrete
fill 146 120 351 146 120 359 minecraft:purple_concrete
setblock 146 120 361 minecraft:dark_prismarine
fill 146 120 362 146 123 362 minecraft:blue_terracotta
setblock 147 120 325 minecraft:dark_prismarine
fill 147 120 326 147 123 326 minecraft:blue_terracotta
fill 147 120 327 178 120 327 minecraft:purple_concrete
fill 147 120 359 178 120 359 minecraft:purple_concrete
setblock 147 120 361 minecraft:blue_terracotta
setblock 148 120 324 minecraft:dark_prismarine
fill 148 120 325 148 123 325 minecraft:blue_terracotta
setblock 148 120 335 minecraft:magenta_terracotta
setblock 149 120 323 minecraft:dark_prismarine
fill 149 120 324 149 123 324 minecraft:blue_terracotta
setblock 149 120 363 minecraft:dark_prismarine
fill 150 120 323 150 123 323 minecraft:blue_terracotta
setblock 150 120 362 minecraft:dark_prismarine
fill 150 120 363 153 120 363 minecraft:blue_terracotta
setblock 151 120 325 minecraft:blue_terracotta
fill 151 120 362 154 120 362 minecraft:blue_terracotta
setblock 152 120 325 minecraft:dark_prismarine
fill 152 120 338 156 120 339 minecraft:dark_oak_planks
fill 152 120 349 156 120 350 minecraft:dark_oak_planks
fill 153 120 322 153 131 322 minecraft:black_concrete
setblock 153 120 324 minecraft:dark_prismarine
setblock 153 120 325 minecraft:blue_terracotta
fill 153 120 337 156 120 337 minecraft:dark_oak_planks
fill 153 120 340 156 120 340 minecraft:dark_oak_planks
fill 153 120 348 156 120 348 minecraft:dark_oak_planks
fill 153 120 351 156 120 351 minecraft:dark_oak_planks
setblock 154 120 322 minecraft:cyan_concrete
setblock 154 120 323 minecraft:dark_prismarine
fill 154 120 324 157 120 324 minecraft:blue_terracotta
fill 154 120 336 155 120 336 minecraft:dark_oak_planks
fill 154 120 352 155 120 352 minecraft:dark_oak_planks
setblock 154 120 363 minecraft:dark_prismarine
fill 155 120 323 158 120 323 minecraft:blue_terracotta
setblock 155 120 362 minecraft:dark_prismarine
fill 155 120 363 158 120 363 minecraft:blue_terracotta
fill 156 120 362 159 120 362 minecraft:blue_terracotta
setblock 158 120 324 minecraft:dark_prismarine
setblock 159 120 323 minecraft:dark_prismarine
fill 159 120 324 162 120 324 minecraft:blue_terracotta
setblock 159 120 363 minecraft:dark_prismarine
fill 160 120 323 160 123 323 minecraft:blue_terracotta
setblock 160 120 361 minecraft:blue_terracotta
setblock 160 120 362 minecraft:dark_prismarine
fill 160 120 363 163 120 363 minecraft:blue_terracotta
setblock 161 120 361 minecraft:dark_prismarine
fill 161 120 362 164 120 362 minecraft:blue_terracotta
setblock 162 120 325 minecraft:dark_prismarine
fill 162 120 361 165 120 361 minecraft:blue_terracotta
setblock 163 120 324 minecraft:dark_prismarine
schedule function dropper:buildpart/75_7 1t
