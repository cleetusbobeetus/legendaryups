setblock 423 209 265 minecraft:ochre_froglight
fill 432 209 228 432 218 228 minecraft:black_concrete
setblock 434 209 249 minecraft:tuff
setblock 434 209 251 minecraft:tuff
setblock 434 209 252 minecraft:andesite
setblock 435 209 245 minecraft:andesite
setblock 435 209 246 minecraft:cobbled_deepslate
setblock 435 209 248 minecraft:tuff
setblock 435 209 249 minecraft:andesite
setblock 435 209 252 minecraft:tuff
setblock 435 209 253 minecraft:andesite
setblock 436 209 245 minecraft:tuff
setblock 436 209 246 minecraft:andesite
setblock 436 209 248 minecraft:cobbled_deepslate
fill 436 209 249 436 211 249 minecraft:tuff
setblock 436 209 250 minecraft:andesite
setblock 436 209 251 minecraft:tuff
fill 436 209 253 437 210 253 minecraft:tuff
setblock 436 209 254 minecraft:andesite
setblock 436 209 270 minecraft:white_concrete
setblock 437 209 241 minecraft:cobbled_deepslate
fill 437 209 242 437 210 242 minecraft:tuff
setblock 437 209 243 minecraft:andesite
setblock 437 209 244 minecraft:tuff
fill 437 209 246 438 210 246 minecraft:tuff
setblock 437 209 247 minecraft:andesite
setblock 437 209 250 minecraft:cobbled_deepslate
setblock 437 209 251 minecraft:andesite
setblock 437 209 252 minecraft:tuff
fill 437 209 254 437 210 254 minecraft:tuff
setblock 437 209 255 minecraft:andesite
setblock 437 209 256 minecraft:tuff
setblock 438 209 243 minecraft:cobbled_deepslate
setblock 438 209 244 minecraft:andesite
setblock 438 209 245 minecraft:tuff
fill 438 209 247 438 211 247 minecraft:tuff
setblock 438 209 248 minecraft:andesite
fill 438 209 251 438 211 251 minecraft:tuff
setblock 438 209 252 minecraft:cobbled_deepslate
fill 438 209 255 438 210 255 minecraft:tuff
setblock 438 209 256 minecraft:andesite
fill 439 209 228 439 291 228 minecraft:black_concrete
setblock 439 209 240 minecraft:tuff
setblock 439 209 241 minecraft:andesite
fill 439 209 244 439 211 244 minecraft:tuff
setblock 439 209 245 minecraft:cobbled_deepslate
fill 439 209 248 439 210 248 minecraft:tuff
setblock 439 209 249 minecraft:andesite
fill 439 209 252 439 211 252 minecraft:tuff
setblock 439 209 253 minecraft:andesite
setblock 439 209 254 minecraft:cobbled_deepslate
fill 439 209 256 439 210 256 minecraft:tuff
setblock 439 209 257 minecraft:andesite
fill 440 209 241 440 210 241 minecraft:tuff
setblock 440 209 242 minecraft:andesite
fill 440 209 245 440 211 245 minecraft:tuff
setblock 440 209 246 minecraft:andesite
setblock 440 209 247 minecraft:cobbled_deepslate
fill 440 209 249 440 211 249 minecraft:tuff
setblock 440 209 253 minecraft:tuff
setblock 440 209 254 minecraft:andesite
setblock 440 209 256 minecraft:cobbled_deepslate
fill 440 209 257 440 210 257 minecraft:tuff
setblock 440 209 258 minecraft:andesite
setblock 440 209 259 minecraft:tuff
setblock 441 209 228 minecraft:black_concrete
setblock 441 209 240 minecraft:cobbled_deepslate
fill 441 209 242 441 211 242 minecraft:tuff
setblock 441 209 243 minecraft:andesite
setblock 441 209 246 minecraft:tuff
setblock 441 209 247 minecraft:andesite
setblock 441 209 255 minecraft:andesite
setblock 441 209 258 minecraft:cobbled_deepslate
setblock 441 209 259 minecraft:andesite
setblock 442 209 240 minecraft:andesite
setblock 442 209 242 minecraft:cobbled_deepslate
fill 442 209 243 442 211 243 minecraft:tuff
setblock 442 209 244 minecraft:andesite
setblock 442 209 245 minecraft:tuff
fill 442 209 247 442 211 247 minecraft:tuff
fill 442 209 255 442 211 255 minecraft:tuff
setblock 442 209 256 minecraft:andesite
setblock 442 209 259 minecraft:tuff
fill 443 209 240 444 210 240 minecraft:tuff
setblock 443 209 241 minecraft:andesite
setblock 443 209 242 minecraft:tuff
setblock 443 209 244 minecraft:cobbled_deepslate
setblock 443 209 245 minecraft:andesite
setblock 443 209 246 minecraft:tuff
fill 443 209 256 443 210 256 minecraft:tuff
setblock 443 209 257 minecraft:andesite
setblock 443 209 270 minecraft:sea_lantern
setblock 444 209 239 minecraft:tuff
fill 444 209 241 444 211 241 minecraft:tuff
setblock 444 209 242 minecraft:andesite
fill 444 209 245 444 211 245 minecraft:tuff
setblock 444 209 246 minecraft:cobbled_deepslate
fill 444 209 257 444 211 257 minecraft:tuff
setblock 444 209 258 minecraft:andesite
fill 445 209 242 445 210 242 minecraft:tuff
setblock 445 209 243 minecraft:andesite
fill 445 209 246 445 211 246 minecraft:tuff
setblock 445 209 257 minecraft:cobbled_deepslate
fill 445 209 258 445 210 258 minecraft:tuff
setblock 445 209 259 minecraft:andesite
setblock 446 209 240 minecraft:andesite
setblock 446 209 241 minecraft:cobbled_deepslate
fill 446 209 243 446 211 243 minecraft:tuff
setblock 446 209 244 minecraft:andesite
fill 446 209 247 448 209 247 minecraft:tuff
fill 446 209 255 448 209 255 minecraft:tuff
setblock 446 209 256 minecraft:andesite
setblock 446 209 259 minecraft:cobbled_deepslate
setblock 447 209 240 minecraft:tuff
setblock 447 209 241 minecraft:andesite
setblock 447 209 243 minecraft:cobbled_deepslate
fill 447 209 244 447 211 244 minecraft:tuff
setblock 447 209 245 minecraft:andesite
setblock 447 209 246 minecraft:tuff
fill 447 209 256 448 210 256 minecraft:tuff
setblock 447 209 257 minecraft:andesite
fill 448 209 241 449 210 241 minecraft:tuff
setblock 448 209 242 minecraft:andesite
setblock 448 209 245 minecraft:cobbled_deepslate
setblock 448 209 246 minecraft:andesite
fill 448 209 248 448 210 249 minecraft:tuff
fill 448 209 253 449 209 253 minecraft:tuff
setblock 448 209 254 minecraft:cobbled_deepslate
setblock 448 209 257 minecraft:tuff
setblock 448 209 258 minecraft:andesite
setblock 449 209 240 minecraft:tuff
fill 449 209 242 449 211 242 minecraft:tuff
setblock 449 209 243 minecraft:andesite
fill 449 209 246 449 211 246 minecraft:tuff
setblock 449 209 247 minecraft:cobbled_deepslate
fill 449 209 250 449 210 250 minecraft:tuff
setblock 449 209 251 minecraft:andesite
setblock 449 209 252 minecraft:tuff
fill 449 209 254 449 211 254 minecraft:tuff
setblock 449 209 255 minecraft:andesite
setblock 449 209 256 minecraft:cobbled_deepslate
fill 450 209 243 450 210 243 minecraft:tuff
setblock 450 209 244 minecraft:andesite
fill 450 209 247 450 211 247 minecraft:tuff
setblock 450 209 248 minecraft:andesite
setblock 450 209 249 minecraft:cobbled_deepslate
fill 450 209 251 450 211 251 minecraft:tuff
setblock 450 209 252 minecraft:andesite
setblock 450 209 255 minecraft:tuff
setblock 450 209 270 minecraft:sea_lantern
setblock 451 209 241 minecraft:andesite
setblock 451 209 242 minecraft:cobbled_deepslate
fill 451 209 244 451 211 244 minecraft:tuff
setblock 451 209 245 minecraft:andesite
setblock 451 209 248 minecraft:tuff
setblock 451 209 249 minecraft:andesite
setblock 451 209 251 minecraft:cobbled_deepslate
fill 451 209 252 452 209 252 minecraft:tuff
setblock 451 209 253 minecraft:andesite
setblock 451 209 254 minecraft:tuff
setblock 452 209 242 minecraft:andesite
setblock 452 209 244 minecraft:cobbled_deepslate
fill 452 209 245 452 211 245 minecraft:tuff
setblock 452 209 246 minecraft:andesite
setblock 452 209 247 minecraft:tuff
fill 452 209 249 453 210 249 minecraft:tuff
setblock 452 209 250 minecraft:andesite
setblock 453 209 243 minecraft:andesite
setblock 453 209 246 minecraft:cobbled_deepslate
setblock 453 209 247 minecraft:andesite
setblock 453 209 248 minecraft:tuff
setblock 453 209 250 minecraft:tuff
setblock 453 209 251 minecraft:andesite
setblock 454 209 244 minecraft:andesite
setblock 454 209 247 minecraft:tuff
setblock 454 209 248 minecraft:cobbled_deepslate
setblock 457 209 228 minecraft:white_concrete
fill 461 209 228 461 308 228 minecraft:black_concrete
setblock 465 209 230 minecraft:blue_concrete
setblock 465 209 252 minecraft:purple_terracotta
fill 465 209 267 465 209 268 minecraft:ochre_froglight
fill 423 210 236 423 221 236 minecraft:black_concrete
fill 423 210 265 423 239 265 minecraft:black_concrete
setblock 424 210 228 minecraft:ochre_froglight
setblock 425 210 228 minecraft:white_concrete
setblock 426 210 231 minecraft:light[level=12]
setblock 426 210 238 minecraft:light[level=12]
setblock 426 210 245 minecraft:light[level=12]
setblock 426 210 252 minecraft:light[level=12]
setblock 426 210 259 minecraft:light[level=12]
setblock 426 210 266 minecraft:light[level=12]
setblock 432 210 270 minecraft:sea_lantern
setblock 433 210 231 minecraft:light[level=12]
setblock 433 210 238 minecraft:light[level=12]
setblock 433 210 245 minecraft:light[level=12]
setblock 433 210 252 minecraft:light[level=12]
setblock 433 210 259 minecraft:light[level=12]
setblock 433 210 266 minecraft:light[level=12]
setblock 434 210 249 minecraft:andesite
setblock 434 210 250 minecraft:cobbled_deepslate
setblock 435 210 228 minecraft:ochre_froglight
setblock 435 210 249 minecraft:tuff
setblock 435 210 250 minecraft:andesite
setblock 435 210 252 minecraft:cobbled_deepslate
setblock 436 210 245 minecraft:cobbled_deepslate
setblock 436 210 246 minecraft:tuff
setblock 436 210 247 minecraft:andesite
setblock 436 210 248 minecraft:tuff
fill 436 210 250 437 211 250 minecraft:tuff
setblock 436 210 251 minecraft:andesite
setblock 436 210 254 minecraft:cobbled_deepslate
fill 436 210 270 436 282 270 minecraft:black_concrete
fill 437 210 243 438 210 243 minecraft:tuff
setblock 437 210 244 minecraft:andesite
setblock 437 210 247 minecraft:cobbled_deepslate
setblock 437 210 248 minecraft:andesite
setblock 437 210 249 minecraft:tuff
fill 437 210 251 437 213 251 minecraft:tuff
setblock 437 210 252 minecraft:andesite
setblock 437 210 255 minecraft:tuff
setblock 438 210 242 minecraft:tuff
fill 438 210 244 438 211 244 minecraft:tuff
setblock 438 210 245 minecraft:andesite
fill 438 210 248 438 213 248 minecraft:tuff
setblock 438 210 249 minecraft:cobbled_deepslate
fill 438 210 252 438 211 252 minecraft:tuff
setblock 438 210 253 minecraft:andesite
setblock 438 210 256 minecraft:tuff
setblock 439 210 241 minecraft:tuff
setblock 439 210 242 minecraft:cobbled_deepslate
fill 439 210 245 439 211 245 minecraft:tuff
setblock 439 210 246 minecraft:andesite
fill 439 210 249 439 213 249 minecraft:tuff
setblock 439 210 250 minecraft:andesite
setblock 439 210 251 minecraft:cobbled_deepslate
fill 439 210 253 439 213 253 minecraft:tuff
setblock 439 210 254 minecraft:andesite
setblock 439 210 257 minecraft:tuff
setblock 440 210 231 minecraft:light[level=12]
setblock 440 210 238 minecraft:light[level=12]
fill 440 210 242 440 211 242 minecraft:tuff
setblock 440 210 243 minecraft:andesite
setblock 440 210 244 minecraft:cobbled_deepslate
fill 440 210 246 440 212 246 minecraft:tuff
setblock 440 210 247 minecraft:andesite
setblock 440 210 253 minecraft:cobbled_deepslate
fill 440 210 254 440 213 254 minecraft:tuff
setblock 440 210 255 minecraft:andesite
setblock 440 210 256 minecraft:tuff
fill 440 210 258 441 210 258 minecraft:tuff
setblock 440 210 259 minecraft:light[level=12]
setblock 440 210 266 minecraft:light[level=12]
setblock 441 210 228 minecraft:sea_lantern
setblock 441 210 240 minecraft:andesite
setblock 441 210 243 minecraft:tuff
setblock 441 210 244 minecraft:andesite
setblock 441 210 246 minecraft:cobbled_deepslate
fill 441 210 247 441 213 247 minecraft:tuff
setblock 441 210 255 minecraft:cobbled_deepslate
setblock 441 210 256 minecraft:andesite
setblock 441 210 257 minecraft:tuff
setblock 442 210 240 minecraft:tuff
setblock 442 210 241 minecraft:andesite
setblock 442 210 242 minecraft:tuff
fill 442 210 244 443 211 244 minecraft:tuff
setblock 442 210 245 minecraft:andesite
fill 442 210 256 442 211 256 minecraft:tuff
setblock 442 210 257 minecraft:cobbled_deepslate
setblock 443 210 241 minecraft:cobbled_deepslate
setblock 443 210 242 minecraft:andesite
setblock 443 210 243 minecraft:tuff
fill 443 210 245 443 213 245 minecraft:tuff
setblock 443 210 246 minecraft:andesite
fill 443 210 257 443 211 257 minecraft:tuff
setblock 443 210 258 minecraft:andesite
setblock 443 210 259 minecraft:cobbled_deepslate
fill 443 210 270 443 220 270 minecraft:black_concrete
fill 444 210 242 444 213 242 minecraft:tuff
setblock 444 210 243 minecraft:cobbled_deepslate
fill 444 210 246 444 211 246 minecraft:tuff
setblock 444 210 258 minecraft:tuff
setblock 444 210 259 minecraft:andesite
setblock 445 210 240 minecraft:andesite
fill 445 210 243 445 213 243 minecraft:tuff
setblock 445 210 244 minecraft:andesite
setblock 445 210 245 minecraft:cobbled_deepslate
setblock 445 210 256 minecraft:andesite
setblock 445 210 257 minecraft:tuff
setblock 446 210 240 minecraft:tuff
setblock 446 210 241 minecraft:andesite
setblock 446 210 244 minecraft:tuff
setblock 446 210 245 minecraft:andesite
setblock 446 210 247 minecraft:cobbled_deepslate
fill 446 210 255 447 210 255 minecraft:tuff
setblock 446 210 256 minecraft:cobbled_deepslate
setblock 446 210 257 minecraft:andesite
setblock 446 210 258 minecraft:tuff
setblock 447 210 231 minecraft:light[level=12]
setblock 447 210 238 minecraft:light[level=12]
setblock 447 210 240 minecraft:cobbled_deepslate
fill 447 210 241 447 211 241 minecraft:tuff
setblock 447 210 242 minecraft:andesite
setblock 447 210 243 minecraft:tuff
fill 447 210 245 448 211 245 minecraft:tuff
setblock 447 210 246 minecraft:andesite
setblock 447 210 247 minecraft:tuff
setblock 447 210 257 minecraft:tuff
setblock 447 210 259 minecraft:light[level=12]
setblock 447 210 266 minecraft:light[level=12]
setblock 448 210 242 minecraft:cobbled_deepslate
setblock 448 210 243 minecraft:andesite
setblock 448 210 244 minecraft:tuff
fill 448 210 246 448 213 246 minecraft:tuff
setblock 448 210 247 minecraft:andesite
fill 448 210 253 448 211 254 minecraft:tuff
setblock 448 210 255 minecraft:andesite
fill 449 210 243 449 211 243 minecraft:tuff
setblock 449 210 244 minecraft:cobbled_deepslate
fill 449 210 247 449 211 247 minecraft:tuff
setblock 449 210 248 minecraft:andesite
fill 449 210 251 449 213 251 minecraft:tuff
setblock 449 210 252 minecraft:andesite
setblock 449 210 253 minecraft:cobbled_deepslate
setblock 449 210 255 minecraft:tuff
setblock 450 210 241 minecraft:andesite
fill 450 210 244 450 211 244 minecraft:tuff
setblock 450 210 245 minecraft:andesite
setblock 450 210 246 minecraft:cobbled_deepslate
fill 450 210 248 450 213 248 minecraft:tuff
setblock 450 210 249 minecraft:andesite
fill 450 210 252 451 210 252 minecraft:tuff
setblock 450 210 253 minecraft:andesite
fill 450 210 270 450 224 270 minecraft:black_concrete
setblock 451 210 242 minecraft:andesite
setblock 451 210 245 minecraft:tuff
setblock 451 210 246 minecraft:andesite
setblock 451 210 248 minecraft:cobbled_deepslate
fill 451 210 249 451 211 249 minecraft:tuff
setblock 451 210 250 minecraft:andesite
setblock 451 210 251 minecraft:tuff
setblock 452 210 242 minecraft:tuff
setblock 452 210 243 minecraft:andesite
setblock 452 210 244 minecraft:tuff
fill 452 210 246 453 210 246 minecraft:tuff
setblock 452 210 247 minecraft:andesite
setblock 452 210 250 minecraft:cobbled_deepslate
setblock 452 210 251 minecraft:andesite
setblock 453 210 244 minecraft:andesite
setblock 453 210 245 minecraft:tuff
setblock 453 210 247 minecraft:tuff
setblock 453 210 248 minecraft:andesite
setblock 454 210 231 minecraft:light[level=12]
setblock 454 210 238 minecraft:light[level=12]
setblock 454 210 245 minecraft:light[level=12]
setblock 454 210 252 minecraft:light[level=12]
setblock 454 210 259 minecraft:light[level=12]
setblock 454 210 266 minecraft:light[level=12]
fill 457 210 228 457 255 228 minecraft:black_concrete
setblock 460 210 228 minecraft:pearlescent_froglight
setblock 461 210 231 minecraft:light[level=12]
setblock 461 210 238 minecraft:light[level=12]
setblock 461 210 245 minecraft:light[level=12]
setblock 461 210 252 minecraft:light[level=12]
setblock 461 210 259 minecraft:light[level=12]
setblock 461 210 266 minecraft:light[level=12]
fill 465 210 230 465 308 230 minecraft:black_concrete
setblock 465 210 237 minecraft:white_concrete
setblock 465 210 242 minecraft:ochre_froglight
fill 465 210 252 465 224 252 minecraft:black_concrete
fill 465 210 267 465 223 267 minecraft:black_concrete
setblock 465 210 268 minecraft:sea_lantern
fill 424 211 228 425 218 228 minecraft:black_concrete
fill 432 211 270 432 215 270 minecraft:black_concrete
fill 435 211 228 435 225 228 minecraft:black_concrete
setblock 435 211 249 minecraft:cobbled_deepslate
setblock 435 211 250 minecraft:tuff
setblock 436 211 251 minecraft:cobbled_deepslate
setblock 436 211 252 minecraft:andesite
setblock 437 211 245 minecraft:andesite
fill 437 211 246 437 211 248 minecraft:tuff
setblock 437 211 249 minecraft:andesite
setblock 437 211 252 minecraft:tuff
setblock 437 211 253 minecraft:cobbled_deepslate
setblock 438 211 243 minecraft:tuff
setblock 438 211 245 minecraft:tuff
setblock 438 211 246 minecraft:cobbled_deepslate
fill 438 211 249 438 212 249 minecraft:tuff
setblock 438 211 250 minecraft:andesite
fill 438 211 253 438 213 253 minecraft:tuff
setblock 438 211 254 minecraft:andesite
setblock 438 211 255 minecraft:cobbled_deepslate
setblock 439 211 242 minecraft:tuff
setblock 439 211 243 minecraft:andesite
fill 439 211 246 439 212 246 minecraft:tuff
setblock 439 211 247 minecraft:andesite
setblock 439 211 248 minecraft:cobbled_deepslate
fill 439 211 250 439 213 250 minecraft:tuff
setblock 439 211 251 minecraft:andesite
setblock 439 211 254 minecraft:tuff
setblock 439 211 255 minecraft:andesite
fill 440 211 243 440 212 243 minecraft:tuff
setblock 440 211 244 minecraft:andesite
setblock 440 211 247 minecraft:tuff
setblock 440 211 248 minecraft:andesite
setblock 440 211 253 minecraft:tuff
fill 440 211 255 441 211 255 minecraft:tuff
setblock 440 211 256 minecraft:andesite
fill 441 211 228 441 270 228 minecraft:black_concrete
setblock 441 211 241 minecraft:andesite
setblock 441 211 243 minecraft:cobbled_deepslate
fill 441 211 244 441 213 244 minecraft:tuff
setblock 441 211 245 minecraft:andesite
setblock 441 211 246 minecraft:tuff
setblock 441 211 256 minecraft:tuff
setblock 441 211 257 minecraft:andesite
fill 442 211 241 443 211 241 minecraft:tuff
setblock 442 211 242 minecraft:andesite
setblock 442 211 245 minecraft:cobbled_deepslate
setblock 442 211 246 minecraft:andesite
setblock 442 211 257 minecraft:tuff
fill 443 211 242 443 213 242 minecraft:tuff
setblock 443 211 243 minecraft:andesite
fill 443 211 246 443 213 246 minecraft:tuff
setblock 443 211 256 minecraft:cobbled_deepslate
fill 444 211 243 444 213 243 minecraft:tuff
setblock 444 211 244 minecraft:andesite
setblock 444 211 256 minecraft:andesite
setblock 445 211 241 minecraft:andesite
setblock 445 211 242 minecraft:cobbled_deepslate
fill 445 211 244 445 213 244 minecraft:tuff
setblock 445 211 245 minecraft:andesite
fill 445 211 256 447 211 256 minecraft:tuff
setblock 445 211 257 minecraft:andesite
setblock 446 211 241 minecraft:tuff
setblock 446 211 242 minecraft:andesite
setblock 446 211 244 minecraft:cobbled_deepslate
fill 446 211 245 446 213 245 minecraft:tuff
setblock 446 211 246 minecraft:andesite
setblock 446 211 247 minecraft:tuff
setblock 446 211 255 minecraft:tuff
fill 447 211 242 448 211 242 minecraft:tuff
setblock 447 211 243 minecraft:andesite
setblock 447 211 246 minecraft:cobbled_deepslate
setblock 447 211 247 minecraft:andesite
setblock 447 211 255 minecraft:cobbled_deepslate
setblock 448 211 241 minecraft:tuff
setblock 448 211 243 minecraft:tuff
setblock 448 211 244 minecraft:andesite
fill 448 211 247 448 213 247 minecraft:tuff
setblock 448 211 248 minecraft:cobbled_deepslate
setblock 448 211 249 minecraft:tuff
setblock 448 211 255 minecraft:tuff
setblock 449 211 244 minecraft:tuff
setblock 449 211 245 minecraft:andesite
fill 449 211 248 449 213 248 minecraft:tuff
setblock 449 211 249 minecraft:andesite
setblock 449 211 250 minecraft:cobbled_deepslate
fill 449 211 252 449 212 252 minecraft:tuff
setblock 449 211 253 minecraft:andesite
setblock 450 211 242 minecraft:andesite
setblock 450 211 243 minecraft:cobbled_deepslate
setblock 450 211 245 minecraft:tuff
setblock 450 211 246 minecraft:andesite
setblock 450 211 249 minecraft:tuff
setblock 450 211 250 minecraft:andesite
setblock 450 211 252 minecraft:cobbled_deepslate
setblock 451 211 243 minecraft:andesite
setblock 451 211 245 minecraft:cobbled_deepslate
fill 451 211 246 452 211 246 minecraft:tuff
setblock 451 211 247 minecraft:andesite
setblock 451 211 248 minecraft:tuff
setblock 451 211 250 minecraft:tuff
setblock 451 211 251 minecraft:andesite
setblock 452 211 244 minecraft:andesite
setblock 452 211 247 minecraft:cobbled_deepslate
setblock 452 211 248 minecraft:andesite
setblock 452 211 249 minecraft:tuff
fill 460 211 228 460 232 228 minecraft:black_concrete
setblock 463 211 228 minecraft:ochre_froglight
fill 465 211 237 465 220 237 minecraft:black_concrete
fill 465 211 242 465 247 242 minecraft:black_concrete
setblock 465 211 262 minecraft:pearlescent_froglight
fill 465 211 268 465 216 268 minecraft:black_concrete
setblock 426 212 231 minecraft:light[level=15]
setblock 426 212 239 minecraft:light[level=15]
setblock 426 212 247 minecraft:light[level=15]
setblock 426 212 255 minecraft:light[level=15]
setblock 426 212 263 minecraft:light[level=15]
setblock 427 212 228 minecraft:purple_terracotta
setblock 428 212 228 minecraft:ochre_froglight
setblock 434 212 231 minecraft:light[level=15]
setblock 434 212 239 minecraft:light[level=15]
setblock 434 212 247 minecraft:light[level=15]
setblock 434 212 255 minecraft:light[level=15]
setblock 434 212 263 minecraft:light[level=15]
setblock 434 212 270 minecraft:pearlescent_froglight
fill 436 212 249 436 213 249 minecraft:andesite
setblock 437 212 249 minecraft:tuff
setblock 437 212 250 minecraft:cobbled_deepslate
fill 438 212 250 438 213 250 minecraft:tuff
setblock 438 212 251 minecraft:andesite
setblock 438 212 252 minecraft:cobbled_deepslate
fill 439 212 247 439 213 247 minecraft:tuff
setblock 439 212 248 minecraft:andesite
fill 439 212 251 439 213 251 minecraft:tuff
fill 439 212 252 439 213 252 minecraft:andesite
setblock 439 212 254 minecraft:cobbled_deepslate
setblock 440 212 247 minecraft:cobbled_deepslate
fill 440 212 248 440 213 248 minecraft:tuff
setblock 440 212 249 minecraft:andesite
setblock 440 212 253 minecraft:andesite
setblock 441 212 243 minecraft:tuff
fill 441 212 245 442 213 245 minecraft:tuff
fill 441 212 246 441 213 246 minecraft:andesite
setblock 441 212 255 minecraft:tuff
setblock 442 212 231 minecraft:light[level=15]
setblock 442 212 239 minecraft:light[level=15]
setblock 442 212 242 minecraft:cobbled_deepslate
fill 442 212 243 442 213 243 minecraft:andesite
fill 442 212 244 442 213 244 minecraft:tuff
fill 442 212 246 442 213 246 minecraft:tuff
setblock 442 212 247 minecraft:andesite
fill 442 212 255 442 213 255 minecraft:andesite
setblock 442 212 263 minecraft:light[level=15]
setblock 443 212 243 minecraft:tuff
setblock 443 212 244 minecraft:cobbled_deepslate
setblock 444 212 228 minecraft:pearlescent_froglight
fill 444 212 244 444 213 244 minecraft:tuff
setblock 444 212 245 minecraft:andesite
setblock 444 212 246 minecraft:cobbled_deepslate
setblock 445 212 242 minecraft:andesite
fill 445 212 245 445 213 245 minecraft:tuff
setblock 445 212 246 minecraft:andesite
fill 446 212 242 447 213 242 minecraft:tuff
fill 446 212 243 446 213 243 minecraft:andesite
fill 446 212 244 446 213 244 minecraft:tuff
fill 446 212 246 447 213 246 minecraft:tuff
setblock 446 212 247 minecraft:andesite
setblock 447 212 243 minecraft:cobbled_deepslate
setblock 447 212 244 minecraft:andesite
fill 447 212 245 447 213 245 minecraft:tuff
fill 447 212 247 447 213 247 minecraft:tuff
setblock 448 212 245 minecraft:cobbled_deepslate
fill 448 212 248 448 213 248 minecraft:tuff
setblock 448 212 249 minecraft:andesite
setblock 448 212 253 minecraft:andesite
fill 449 212 246 449 213 246 minecraft:andesite
setblock 449 212 247 minecraft:cobbled_deepslate
setblock 449 212 249 minecraft:tuff
setblock 449 212 250 minecraft:andesite
setblock 450 212 231 minecraft:light[level=15]
setblock 450 212 239 minecraft:light[level=15]
fill 450 212 246 451 212 246 minecraft:tuff
setblock 450 212 247 minecraft:andesite
setblock 450 212 249 minecraft:cobbled_deepslate
fill 450 212 250 450 213 250 minecraft:tuff
setblock 450 212 251 minecraft:andesite
setblock 450 212 255 minecraft:light[level=15]
setblock 450 212 263 minecraft:light[level=15]
fill 451 212 245 451 213 245 minecraft:tuff
fill 451 212 247 451 213 247 minecraft:tuff
setblock 451 212 248 minecraft:andesite
setblock 458 212 231 minecraft:light[level=15]
setblock 458 212 239 minecraft:light[level=15]
setblock 458 212 247 minecraft:light[level=15]
setblock 458 212 255 minecraft:light[level=15]
setblock 458 212 263 minecraft:light[level=15]
fill 463 212 228 463 225 228 minecraft:black_concrete
setblock 463 212 270 minecraft:pearlescent_froglight
fill 465 212 262 465 228 262 minecraft:black_concrete
setblock 423 213 245 minecraft:sea_lantern
fill 424 213 229 464 213 230 minecraft:tuff
fill 424 213 231 464 213 231 minecraft:andesite
fill 424 213 232 464 213 233 minecraft:tuff
fill 424 213 234 464 213 234 minecraft:andesite
fill 424 213 235 464 213 236 minecraft:tuff
fill 424 213 237 464 213 237 minecraft:andesite
fill 424 213 238 464 213 239 minecraft:tuff
fill 424 213 240 464 213 240 minecraft:andesite
fill 424 213 241 442 213 242 minecraft:tuff
fill 424 213 243 441 213 243 minecraft:andesite
fill 424 213 244 440 213 245 minecraft:tuff
fill 424 213 246 440 213 246 minecraft:andesite
fill 424 213 247 437 213 248 minecraft:tuff
fill 424 213 249 435 213 249 minecraft:andesite
fill 424 213 250 436 213 251 minecraft:tuff
fill 424 213 252 438 213 252 minecraft:andesite
fill 424 213 253 437 213 254 minecraft:tuff
fill 424 213 255 441 213 255 minecraft:andesite
fill 424 213 256 464 213 257 minecraft:tuff
fill 424 213 258 464 213 258 minecraft:andesite
fill 424 213 259 464 213 260 minecraft:tuff
fill 424 213 261 464 213 261 minecraft:andesite
fill 424 213 262 464 213 263 minecraft:tuff
fill 424 213 264 464 213 264 minecraft:andesite
fill 424 213 265 464 213 266 minecraft:tuff
fill 424 213 267 464 213 267 minecraft:andesite
fill 424 213 268 464 213 269 minecraft:tuff
fill 427 213 228 428 239 228 minecraft:black_concrete
fill 434 213 270 434 235 270 minecraft:black_concrete
setblock 436 213 228 minecraft:sea_lantern
fill 437 213 228 437 219 228 minecraft:black_concrete
fill 437 213 249 438 213 249 minecraft:andesite
setblock 437 213 250 minecraft:tuff
setblock 438 213 247 minecraft:tuff
setblock 438 213 251 minecraft:tuff
fill 438 213 254 439 213 254 minecraft:tuff
setblock 439 213 248 minecraft:tuff
setblock 440 213 247 minecraft:tuff
setblock 440 213 249 minecraft:tuff
fill 440 213 250 440 213 252 minecraft:verdant_froglight
setblock 440 213 253 minecraft:tuff
fill 441 213 248 441 213 250 minecraft:verdant_froglight
fill 441 213 252 441 213 254 minecraft:verdant_froglight
setblock 442 213 247 minecraft:tuff
fill 442 213 248 443 213 248 minecraft:verdant_froglight
fill 442 213 254 443 213 254 minecraft:verdant_froglight
fill 443 213 241 464 213 241 minecraft:tuff
setblock 443 213 243 minecraft:andesite
setblock 443 213 244 minecraft:tuff
fill 443 213 247 445 213 247 minecraft:verdant_froglight
fill 443 213 255 445 213 255 minecraft:verdant_froglight
setblock 444 213 228 minecraft:sea_lantern
fill 444 213 245 444 213 246 minecraft:tuff
setblock 445 213 242 minecraft:tuff
setblock 445 213 246 minecraft:tuff
fill 445 213 248 447 213 248 minecraft:verdant_froglight
fill 445 213 254 447 213 254 minecraft:verdant_froglight
setblock 446 213 247 minecraft:tuff
fill 446 213 255 464 213 255 minecraft:andesite
fill 447 213 243 464 213 243 minecraft:andesite
fill 447 213 244 464 213 244 minecraft:tuff
fill 447 213 249 447 213 250 minecraft:verdant_froglight
fill 447 213 252 447 213 253 minecraft:verdant_froglight
fill 448 213 242 464 213 242 minecraft:tuff
fill 448 213 245 450 213 245 minecraft:tuff
setblock 448 213 249 minecraft:tuff
fill 448 213 250 448 213 252 minecraft:verdant_froglight
fill 448 213 253 464 213 254 minecraft:tuff
fill 449 213 247 450 213 247 minecraft:tuff
fill 449 213 249 464 213 249 minecraft:andesite
setblock 449 213 250 minecraft:tuff
fill 449 213 252 464 213 252 minecraft:andesite
fill 450 213 246 464 213 246 minecraft:andesite
fill 450 213 251 464 213 251 minecraft:tuff
fill 451 213 248 464 213 248 minecraft:tuff
fill 451 213 250 464 213 250 minecraft:tuff
fill 452 213 245 464 213 245 minecraft:tuff
fill 452 213 247 464 213 247 minecraft:tuff
fill 463 213 270 463 266 270 minecraft:black_concrete
fill 423 214 245 423 217 245 minecraft:black_concrete
setblock 423 214 255 minecraft:pearlescent_froglight
setblock 423 214 263 minecraft:sea_lantern
fill 436 214 228 436 307 228 minecraft:black_concrete
fill 440 214 250 440 214 252 minecraft:lime_stained_glass
setblock 441 214 249 minecraft:lime_stained_glass
setblock 441 214 253 minecraft:lime_stained_glass
setblock 442 214 248 minecraft:lime_stained_glass
setblock 442 214 254 minecraft:lime_stained_glass
fill 443 214 247 445 214 247 minecraft:lime_stained_glass
fill 443 214 255 445 214 255 minecraft:lime_stained_glass
fill 444 214 228 444 274 228 minecraft:black_concrete
setblock 446 214 248 minecraft:lime_stained_glass
setblock 446 214 254 minecraft:lime_stained_glass
setblock 447 214 249 minecraft:lime_stained_glass
setblock 447 214 253 minecraft:lime_stained_glass
fill 448 214 250 448 214 252 minecraft:lime_stained_glass
setblock 448 214 270 minecraft:white_concrete
setblock 455 214 228 minecraft:magenta_terracotta
setblock 457 214 270 minecraft:sea_lantern
setblock 459 214 228 minecraft:pearlescent_froglight
setblock 459 214 270 minecraft:sea_lantern
setblock 465 214 255 minecraft:sea_lantern
setblock 465 214 261 minecraft:pearlescent_froglight
setblock 423 215 235 minecraft:purple_terracotta
setblock 423 215 242 minecraft:white_concrete
fill 423 215 255 423 216 255 minecraft:black_concrete
fill 423 215 263 423 230 263 minecraft:black_concrete
fill 433 215 249 440 216 253 minecraft:light_gray_concrete
fill 434 215 246 441 216 248 minecraft:light_gray_concrete
fill 434 215 254 441 216 256 minecraft:light_gray_concrete
fill 435 215 245 453 218 245 minecraft:light_gray_concrete
fill 435 215 257 453 218 257 minecraft:light_gray_concrete
fill 436 215 244 452 218 244 minecraft:light_gray_concrete
fill 436 215 258 452 218 258 minecraft:light_gray_concrete
fill 437 215 243 451 218 243 minecraft:light_gray_concrete
fill 437 215 259 451 218 259 minecraft:light_gray_concrete
fill 438 215 242 450 218 242 minecraft:light_gray_concrete
fill 438 215 260 450 218 260 minecraft:light_gray_concrete
setblock 438 215 270 minecraft:pearlescent_froglight
fill 439 215 241 449 218 241 minecraft:light_gray_concrete
fill 439 215 261 449 218 261 minecraft:light_gray_concrete
fill 442 215 240 446 218 240 minecraft:light_gray_concrete
fill 442 215 246 454 216 247 minecraft:light_gray_concrete
fill 442 215 255 454 216 256 minecraft:light_gray_concrete
fill 442 215 262 446 218 262 minecraft:light_gray_concrete
fill 447 215 248 454 216 248 minecraft:light_gray_concrete
fill 447 215 254 454 216 254 minecraft:light_gray_concrete
setblock 447 215 270 minecraft:white_concrete
fill 448 215 249 455 216 253 minecraft:light_gray_concrete
fill 448 215 270 448 218 270 minecraft:black_concrete
setblock 455 215 228 minecraft:black_concrete
fill 457 215 270 457 256 270 minecraft:black_concrete
fill 459 215 228 459 234 228 minecraft:black_concrete
fill 459 215 270 459 246 270 minecraft:black_concrete
setblock 465 215 229 minecraft:white_concrete
fill 465 215 255 465 256 255 minecraft:black_concrete
fill 465 215 261 465 239 261 minecraft:black_concrete
setblock 423 216 234 minecraft:white_concrete
fill 423 216 235 423 225 235 minecraft:black_concrete
fill 423 216 242 423 308 242 minecraft:black_concrete
setblock 423 216 256 minecraft:white_concrete
setblock 426 216 231 minecraft:light[level=12]
setblock 426 216 238 minecraft:light[level=12]
setblock 426 216 245 minecraft:light[level=12]
setblock 426 216 252 minecraft:light[level=12]
setblock 426 216 259 minecraft:light[level=12]
setblock 426 216 266 minecraft:light[level=12]
fill 431 216 247 431 217 255 minecraft:sea_lantern
fill 432 216 245 432 217 248 minecraft:sea_lantern
fill 432 216 249 432 217 253 minecraft:light_gray_concrete
fill 432 216 254 432 217 257 minecraft:sea_lantern
setblock 432 216 270 minecraft:purple_terracotta
setblock 433 216 231 minecraft:light[level=12]
setblock 433 216 238 minecraft:light[level=12]
fill 433 216 243 433 217 245 minecraft:sea_lantern
fill 433 216 246 433 217 248 minecraft:light_gray_concrete
fill 433 216 254 433 217 256 minecraft:light_gray_concrete
fill 433 216 257 433 217 259 minecraft:sea_lantern
setblock 433 216 266 minecraft:light[level=12]
fill 434 216 242 434 217 243 minecraft:sea_lantern
fill 434 216 244 434 217 245 minecraft:light_gray_concrete
fill 434 216 257 434 217 258 minecraft:light_gray_concrete
fill 434 216 259 434 217 260 minecraft:sea_lantern
fill 435 216 241 435 217 242 minecraft:sea_lantern
fill 435 216 243 435 217 244 minecraft:light_gray_concrete
fill 435 216 258 435 217 259 minecraft:light_gray_concrete
fill 435 216 260 435 217 261 minecraft:sea_lantern
fill 436 216 240 436 217 241 minecraft:sea_lantern
fill 436 216 242 436 217 243 minecraft:light_gray_concrete
fill 436 216 259 436 217 260 minecraft:light_gray_concrete
fill 436 216 261 436 217 262 minecraft:sea_lantern
fill 437 216 240 438 217 240 minecraft:sea_lantern
fill 437 216 241 437 217 242 minecraft:light_gray_concrete
fill 437 216 260 437 217 261 minecraft:light_gray_concrete
fill 437 216 262 438 217 262 minecraft:sea_lantern
setblock 438 216 228 minecraft:blue_concrete
fill 438 216 239 441 217 239 minecraft:sea_lantern
fill 438 216 241 438 217 241 minecraft:light_gray_concrete
fill 438 216 261 438 217 261 minecraft:light_gray_concrete
fill 438 216 263 441 217 263 minecraft:sea_lantern
fill 438 216 270 438 250 270 minecraft:black_concrete
fill 439 216 240 441 217 240 minecraft:light_gray_concrete
fill 439 216 262 441 217 262 minecraft:light_gray_concrete
setblock 440 216 231 minecraft:light[level=12]
fill 440 216 238 448 217 238 minecraft:sea_lantern
fill 440 216 264 448 217 264 minecraft:sea_lantern
setblock 440 216 266 minecraft:light[level=12]
fill 442 216 239 446 217 239 minecraft:light_gray_concrete
fill 442 216 263 446 217 263 minecraft:light_gray_concrete
setblock 446 216 270 minecraft:sea_lantern
setblock 447 216 231 minecraft:light[level=12]
fill 447 216 239 450 217 239 minecraft:sea_lantern
fill 447 216 240 449 217 240 minecraft:light_gray_concrete
fill 447 216 262 449 217 262 minecraft:light_gray_concrete
fill 447 216 263 450 217 263 minecraft:sea_lantern
setblock 447 216 266 minecraft:light[level=12]
setblock 447 216 270 minecraft:black_concrete
fill 450 216 240 452 217 240 minecraft:sea_lantern
fill 450 216 241 451 217 241 minecraft:light_gray_concrete
fill 450 216 261 451 217 261 minecraft:light_gray_concrete
fill 450 216 262 452 217 262 minecraft:sea_lantern
fill 451 216 242 452 217 242 minecraft:light_gray_concrete
fill 451 216 260 452 217 260 minecraft:light_gray_concrete
fill 452 216 241 453 217 241 minecraft:sea_lantern
fill 452 216 243 453 217 243 minecraft:light_gray_concrete
fill 452 216 259 453 217 259 minecraft:light_gray_concrete
fill 452 216 261 453 217 261 minecraft:sea_lantern
fill 453 216 242 454 217 242 minecraft:sea_lantern
fill 453 216 244 454 217 244 minecraft:light_gray_concrete
fill 453 216 258 454 217 258 minecraft:light_gray_concrete
fill 453 216 260 454 217 260 minecraft:sea_lantern
setblock 453 216 270 minecraft:pearlescent_froglight
setblock 454 216 231 minecraft:light[level=12]
setblock 454 216 238 minecraft:light[level=12]
fill 454 216 243 455 217 243 minecraft:sea_lantern
fill 454 216 245 454 217 245 minecraft:light_gray_concrete
fill 454 216 257 454 217 257 minecraft:light_gray_concrete
fill 454 216 259 455 217 259 minecraft:sea_lantern
setblock 454 216 266 minecraft:light[level=12]
setblock 455 216 228 minecraft:ochre_froglight
fill 455 216 244 455 217 245 minecraft:sea_lantern
fill 455 216 246 455 217 248 minecraft:light_gray_concrete
fill 455 216 254 455 217 256 minecraft:light_gray_concrete
fill 455 216 257 455 217 258 minecraft:sea_lantern
fill 456 216 245 456 217 248 minecraft:sea_lantern
fill 456 216 249 456 217 253 minecraft:light_gray_concrete
fill 456 216 254 456 217 257 minecraft:sea_lantern
fill 457 216 247 457 217 255 minecraft:sea_lantern
setblock 461 216 231 minecraft:light[level=12]
setblock 461 216 238 minecraft:light[level=12]
setblock 461 216 245 minecraft:light[level=12]
setblock 461 216 252 minecraft:light[level=12]
setblock 461 216 259 minecraft:light[level=12]
setblock 461 216 266 minecraft:light[level=12]
fill 465 216 229 465 245 229 minecraft:black_concrete
setblock 465 216 245 minecraft:white_concrete
fill 423 217 234 423 237 234 minecraft:black_concrete
setblock 423 217 255 minecraft:white_concrete
fill 423 217 256 423 292 256 minecraft:black_concrete
setblock 429 217 270 minecraft:sea_lantern
fill 432 217 270 432 237 270 minecraft:black_concrete
fill 433 217 249 439 217 253 minecraft:light_gray_concrete
fill 434 217 246 440 217 248 minecraft:light_gray_concrete
fill 434 217 254 440 217 256 minecraft:light_gray_concrete
fill 438 217 228 438 263 228 minecraft:black_concrete
fill 440 217 249 440 217 250 minecraft:light_blue_stained_glass
fill 440 217 252 440 217 253 minecraft:light_blue_stained_glass
fill 441 217 246 441 217 247 minecraft:light_gray_concrete
setblock 441 217 248 minecraft:light_blue_stained_glass
setblock 441 217 254 minecraft:light_blue_stained_glass
fill 441 217 255 441 217 256 minecraft:light_gray_concrete
fill 442 217 246 454 217 246 minecraft:light_gray_concrete
fill 442 217 247 443 217 247 minecraft:light_blue_stained_glass
fill 442 217 255 443 217 255 minecraft:light_blue_stained_glass
fill 442 217 256 454 217 256 minecraft:light_gray_concrete
fill 445 217 247 446 217 247 minecraft:light_blue_stained_glass
fill 445 217 255 446 217 255 minecraft:light_blue_stained_glass
fill 446 217 270 446 258 270 minecraft:black_concrete
fill 447 217 247 454 217 247 minecraft:light_gray_concrete
setblock 447 217 248 minecraft:light_blue_stained_glass
setblock 447 217 254 minecraft:light_blue_stained_glass
fill 447 217 255 454 217 255 minecraft:light_gray_concrete
setblock 447 217 270 minecraft:pearlescent_froglight
fill 448 217 248 454 217 248 minecraft:light_gray_concrete
fill 448 217 249 448 217 250 minecraft:light_blue_stained_glass
fill 448 217 252 448 217 253 minecraft:light_blue_stained_glass
fill 448 217 254 454 217 254 minecraft:light_gray_concrete
fill 449 217 249 455 217 253 minecraft:light_gray_concrete
setblock 451 217 270 minecraft:white_concrete
fill 453 217 270 453 238 270 minecraft:black_concrete
fill 455 217 228 455 291 228 minecraft:black_concrete
setblock 465 217 233 minecraft:white_concrete
fill 465 217 245 465 268 245 minecraft:black_concrete
setblock 465 217 247 minecraft:sea_lantern
setblock 465 217 249 minecraft:pearlescent_froglight
setblock 465 217 268 minecraft:blue_concrete
setblock 423 218 245 minecraft:pearlescent_froglight
fill 423 218 255 423 231 255 minecraft:black_concrete
fill 429 218 270 429 236 270 minecraft:black_concrete
fill 432 218 252 432 219 253 minecraft:gray_concrete
fill 433 218 249 438 218 253 minecraft:light_gray_concrete
fill 434 218 246 439 218 248 minecraft:light_gray_concrete
fill 434 218 254 439 218 256 minecraft:light_gray_concrete
fill 439 218 249 439 220 253 minecraft:light_blue_stained_glass
fill 440 218 246 441 218 246 minecraft:light_gray_concrete
fill 440 218 247 440 219 249 minecraft:light_blue_stained_glass
fill 440 218 253 440 219 255 minecraft:light_blue_stained_glass
fill 440 218 256 441 218 256 minecraft:light_gray_concrete
fill 441 218 247 442 219 247 minecraft:light_blue_stained_glass
fill 441 218 255 442 219 255 minecraft:light_blue_stained_glass
fill 442 218 246 446 220 246 minecraft:light_blue_stained_glass
fill 442 218 256 446 220 256 minecraft:light_blue_stained_glass
fill 446 218 247 448 219 247 minecraft:light_blue_stained_glass
fill 446 218 255 448 219 255 minecraft:light_blue_stained_glass
fill 447 218 246 454 218 246 minecraft:light_gray_concrete
fill 447 218 256 454 218 256 minecraft:light_gray_concrete
fill 447 218 270 447 250 270 minecraft:black_concrete
fill 448 218 248 448 219 249 minecraft:light_blue_stained_glass
fill 448 218 253 448 219 254 minecraft:light_blue_stained_glass
fill 449 218 247 454 218 248 minecraft:light_gray_concrete
fill 449 218 249 449 220 253 minecraft:light_blue_stained_glass
fill 449 218 254 454 218 255 minecraft:light_gray_concrete
fill 450 218 249 455 218 253 minecraft:light_gray_concrete
fill 451 218 270 451 219 270 minecraft:black_concrete
fill 465 218 233 465 244 233 minecraft:black_concrete
fill 465 218 247 465 244 247 minecraft:black_concrete
fill 465 218 249 465 299 249 minecraft:black_concrete
setblock 465 218 256 minecraft:pearlescent_froglight
fill 465 218 268 465 307 268 minecraft:black_concrete
fill 423 219 245 423 241 245 minecraft:black_concrete
setblock 424 219 228 minecraft:purple_terracotta
fill 425 219 228 425 222 228 minecraft:black_concrete
setblock 426 219 231 minecraft:light[level=15]
setblock 426 219 239 minecraft:light[level=15]
setblock 426 219 247 minecraft:light[level=15]
setblock 426 219 255 minecraft:light[level=15]
setblock 426 219 263 minecraft:light[level=15]
setblock 428 219 270 minecraft:pearlescent_froglight
setblock 432 219 228 minecraft:pearlescent_froglight
fill 433 219 252 434 219 253 minecraft:gray_concrete
setblock 434 219 231 minecraft:light[level=15]
setblock 434 219 239 minecraft:light[level=15]
setblock 434 219 247 minecraft:light[level=15]
setblock 434 219 255 minecraft:light[level=15]
setblock 434 219 263 minecraft:light[level=15]
setblock 438 219 251 minecraft:light_blue_stained_glass
setblock 439 219 248 minecraft:light_blue_stained_glass
setblock 439 219 254 minecraft:light_blue_stained_glass
setblock 439 219 270 minecraft:magenta_terracotta
setblock 440 219 228 minecraft:purple_terracotta
setblock 441 219 246 minecraft:light_blue_stained_glass
setblock 441 219 256 minecraft:light_blue_stained_glass
setblock 442 219 231 minecraft:light[level=15]
setblock 442 219 239 minecraft:light[level=15]
setblock 442 219 263 minecraft:light[level=15]
setblock 444 219 245 minecraft:light_blue_stained_glass
setblock 444 219 257 minecraft:light_blue_stained_glass
setblock 447 219 246 minecraft:light_blue_stained_glass
setblock 447 219 256 minecraft:light_blue_stained_glass
setblock 448 219 270 minecraft:pearlescent_froglight
setblock 449 219 248 minecraft:light_blue_stained_glass
setblock 449 219 254 minecraft:light_blue_stained_glass
setblock 450 219 231 minecraft:light[level=15]
setblock 450 219 239 minecraft:light[level=15]
setblock 450 219 247 minecraft:light[level=15]
setblock 450 219 251 minecraft:light_blue_stained_glass
setblock 450 219 255 minecraft:light[level=15]
setblock 450 219 263 minecraft:light[level=15]
fill 451 219 251 452 219 251 minecraft:andesite
setblock 452 219 250 minecraft:andesite
setblock 458 219 231 minecraft:light[level=15]
setblock 458 219 239 minecraft:light[level=15]
setblock 458 219 247 minecraft:light[level=15]
setblock 458 219 255 minecraft:light[level=15]
setblock 458 219 263 minecraft:light[level=15]
fill 465 219 256 465 261 256 minecraft:black_concrete
fill 424 220 228 424 238 228 minecraft:black_concrete
fill 428 220 270 428 276 270 minecraft:black_concrete
setblock 430 220 270 minecraft:ochre_froglight
fill 432 220 228 432 229 228 minecraft:black_concrete
setblock 437 220 228 minecraft:blue_concrete
fill 439 220 270 439 236 270 minecraft:black_concrete
fill 440 220 228 440 236 228 minecraft:black_concrete
fill 440 220 247 440 220 248 minecraft:light_blue_stained_glass
fill 440 220 254 440 220 255 minecraft:light_blue_stained_glass
setblock 440 220 270 minecraft:white_concrete
setblock 441 220 247 minecraft:light_blue_stained_glass
setblock 441 220 255 minecraft:light_blue_stained_glass
fill 447 220 247 448 220 247 minecraft:light_blue_stained_glass
fill 447 220 255 448 220 255 minecraft:light_blue_stained_glass
setblock 448 220 228 minecraft:pearlescent_froglight
setblock 448 220 248 minecraft:light_blue_stained_glass
setblock 448 220 254 minecraft:light_blue_stained_glass
fill 448 220 270 448 253 270 minecraft:black_concrete
setblock 451 220 270 minecraft:white_concrete
setblock 423 221 250 minecraft:ochre_froglight
setblock 426 221 270 minecraft:sea_lantern
fill 430 221 270 430 240 270 minecraft:black_concrete
fill 437 221 228 437 270 228 minecraft:black_concrete
fill 440 221 270 440 241 270 minecraft:black_concrete
setblock 443 221 270 minecraft:ochre_froglight
fill 448 221 228 448 250 228 minecraft:black_concrete
fill 451 221 270 451 242 270 minecraft:black_concrete
setblock 452 221 270 minecraft:sea_lantern
setblock 458 221 270 minecraft:sea_lantern
setblock 465 221 237 minecraft:ochre_froglight
setblock 423 222 236 minecraft:sea_lantern
fill 423 222 250 423 232 250 minecraft:black_concrete
setblock 426 222 231 minecraft:light[level=12]
setblock 426 222 238 minecraft:light[level=12]
setblock 426 222 245 minecraft:light[level=12]
setblock 426 222 252 minecraft:light[level=12]
setblock 426 222 259 minecraft:light[level=12]
setblock 426 222 266 minecraft:light[level=12]
fill 426 222 270 426 264 270 minecraft:black_concrete
setblock 433 222 231 minecraft:light[level=12]
setblock 433 222 238 minecraft:light[level=12]
setblock 433 222 245 minecraft:light[level=12]
setblock 433 222 252 minecraft:light[level=12]
setblock 433 222 259 minecraft:light[level=12]
setblock 433 222 266 minecraft:light[level=12]
setblock 435 222 270 minecraft:ochre_froglight
setblock 440 222 231 minecraft:light[level=12]
setblock 440 222 238 minecraft:light[level=12]
setblock 440 222 245 minecraft:light[level=12]
setblock 440 222 259 minecraft:light[level=12]
setblock 440 222 266 minecraft:light[level=12]
fill 443 222 270 443 256 270 minecraft:black_concrete
setblock 447 222 231 minecraft:light[level=12]
setblock 447 222 238 minecraft:light[level=12]
setblock 447 222 245 minecraft:light[level=12]
setblock 447 222 259 minecraft:light[level=12]
setblock 447 222 266 minecraft:light[level=12]
fill 452 222 270 452 283 270 minecraft:black_concrete
setblock 454 222 231 minecraft:light[level=12]
setblock 454 222 238 minecraft:light[level=12]
setblock 454 222 245 minecraft:light[level=12]
setblock 454 222 252 minecraft:light[level=12]
setblock 454 222 259 minecraft:light[level=12]
setblock 454 222 266 minecraft:light[level=12]
setblock 458 222 270 minecraft:black_concrete
setblock 461 222 231 minecraft:light[level=12]
setblock 461 222 238 minecraft:light[level=12]
setblock 461 222 245 minecraft:light[level=12]
setblock 461 222 252 minecraft:light[level=12]
setblock 461 222 259 minecraft:light[level=12]
setblock 461 222 266 minecraft:light[level=12]
fill 465 222 237 465 253 237 minecraft:black_concrete
fill 423 223 236 423 240 236 minecraft:black_concrete
setblock 423 223 241 minecraft:sea_lantern
setblock 425 223 228 minecraft:sea_lantern
setblock 431 223 270 minecraft:magenta_terracotta
fill 435 223 270 435 295 270 minecraft:black_concrete
setblock 458 223 270 minecraft:magenta_terracotta
fill 423 224 231 423 231 231 minecraft:black_concrete
setblock 423 224 232 minecraft:pearlescent_froglight
fill 423 224 241 423 228 241 minecraft:black_concrete
fill 425 224 228 425 234 228 minecraft:black_concrete
fill 431 224 270 431 275 270 minecraft:black_concrete
setblock 445 224 228 minecraft:purple_concrete
setblock 450 224 228 minecraft:white_concrete
fill 458 224 270 458 239 270 minecraft:black_concrete
setblock 462 224 228 minecraft:pearlescent_froglight
setblock 465 224 259 minecraft:ochre_froglight
setblock 465 224 267 minecraft:purple_terracotta
fill 423 225 232 423 230 232 minecraft:black_concrete
setblock 423 225 269 minecraft:white_concrete
fill 445 225 228 445 296 228 minecraft:black_concrete
setblock 445 225 270 minecraft:purple_concrete
fill 450 225 228 450 248 228 minecraft:black_concrete
setblock 450 225 270 minecraft:ochre_froglight
setblock 461 225 270 minecraft:ochre_froglight
fill 462 225 228 462 241 228 minecraft:black_concrete
setblock 465 225 252 minecraft:white_concrete
fill 465 225 259 465 255 259 minecraft:black_concrete
fill 465 225 267 465 234 267 minecraft:black_concrete
setblock 423 226 235 minecraft:ochre_froglight
setblock 423 226 237 minecraft:sea_lantern
fill 423 226 269 423 251 269 minecraft:black_concrete
setblock 426 226 231 minecraft:light[level=15]
setblock 426 226 239 minecraft:light[level=15]
setblock 426 226 247 minecraft:light[level=15]
setblock 426 226 255 minecraft:light[level=15]
setblock 426 226 263 minecraft:light[level=15]
setblock 434 226 231 minecraft:light[level=15]
setblock 434 226 239 minecraft:light[level=15]
setblock 434 226 247 minecraft:light[level=15]
setblock 434 226 255 minecraft:light[level=15]
setblock 434 226 263 minecraft:light[level=15]
setblock 435 226 228 minecraft:white_concrete
setblock 442 226 231 minecraft:light[level=15]
setblock 442 226 239 minecraft:light[level=15]
setblock 442 226 247 minecraft:light[level=15]
setblock 442 226 255 minecraft:light[level=15]
setblock 442 226 263 minecraft:light[level=15]
fill 445 226 270 445 297 270 minecraft:black_concrete
setblock 446 226 228 minecraft:ochre_froglight
setblock 450 226 231 minecraft:light[level=15]
setblock 450 226 239 minecraft:light[level=15]
setblock 450 226 247 minecraft:light[level=15]
setblock 450 226 255 minecraft:light[level=15]
setblock 450 226 263 minecraft:light[level=15]
fill 450 226 270 450 242 270 minecraft:black_concrete
setblock 458 226 228 minecraft:pearlescent_froglight
setblock 458 226 231 minecraft:light[level=15]
setblock 458 226 239 minecraft:light[level=15]
setblock 458 226 247 minecraft:light[level=15]
setblock 458 226 255 minecraft:light[level=15]
setblock 458 226 263 minecraft:light[level=15]
fill 461 226 270 461 252 270 minecraft:black_concrete
setblock 463 226 228 minecraft:white_concrete
fill 465 226 252 465 267 252 minecraft:black_concrete
setblock 465 226 258 minecraft:ochre_froglight
fill 423 227 235 423 263 235 minecraft:black_concrete
fill 423 227 237 423 240 237 minecraft:black_concrete
fill 435 227 228 435 299 228 minecraft:black_concrete
fill 446 227 228 446 228 228 minecraft:black_concrete
fill 458 227 228 458 241 228 minecraft:black_concrete
fill 463 227 228 463 252 228 minecraft:black_concrete
fill 465 227 258 465 301 258 minecraft:black_concrete
setblock 426 228 231 minecraft:light[level=12]
setblock 426 228 238 minecraft:light[level=12]
setblock 426 228 245 minecraft:light[level=12]
setblock 426 228 252 minecraft:light[level=12]
setblock 426 228 259 minecraft:light[level=12]
setblock 426 228 266 minecraft:light[level=12]
setblock 433 228 231 minecraft:light[level=12]
setblock 433 228 238 minecraft:light[level=12]
setblock 433 228 245 minecraft:light[level=12]
setblock 433 228 252 minecraft:light[level=12]
setblock 433 228 259 minecraft:light[level=12]
setblock 433 228 266 minecraft:light[level=12]
setblock 440 228 231 minecraft:light[level=12]
setblock 440 228 238 minecraft:light[level=12]
setblock 440 228 245 minecraft:light[level=12]
setblock 440 228 252 minecraft:light[level=12]
setblock 440 228 259 minecraft:light[level=12]
setblock 440 228 266 minecraft:light[level=12]
setblock 447 228 231 minecraft:light[level=12]
setblock 447 228 238 minecraft:light[level=12]
setblock 447 228 245 minecraft:light[level=12]
setblock 447 228 252 minecraft:light[level=12]
setblock 447 228 259 minecraft:light[level=12]
setblock 447 228 266 minecraft:light[level=12]
setblock 454 228 231 minecraft:light[level=12]
setblock 454 228 238 minecraft:light[level=12]
setblock 454 228 245 minecraft:light[level=12]
setblock 454 228 252 minecraft:light[level=12]
setblock 454 228 259 minecraft:light[level=12]
setblock 454 228 266 minecraft:light[level=12]
setblock 461 228 231 minecraft:light[level=12]
setblock 461 228 238 minecraft:light[level=12]
setblock 461 228 245 minecraft:light[level=12]
setblock 461 228 252 minecraft:light[level=12]
setblock 461 228 259 minecraft:light[level=12]
setblock 461 228 266 minecraft:light[level=12]
setblock 465 228 236 minecraft:pearlescent_froglight
setblock 423 229 230 minecraft:ochre_froglight
setblock 423 229 241 minecraft:white_concrete
setblock 442 229 270 minecraft:sea_lantern
setblock 446 229 228 minecraft:purple_terracotta
setblock 465 229 234 minecraft:purple_terracotta
fill 465 229 236 465 232 236 minecraft:black_concrete
setblock 465 229 262 minecraft:pearlescent_froglight
setblock 423 230 229 minecraft:ochre_froglight
fill 423 230 230 423 243 230 minecraft:black_concrete
fill 423 230 241 423 239 241 minecraft:black_concrete
setblock 432 230 228 minecraft:pearlescent_froglight
fill 442 230 270 442 246 270 minecraft:black_concrete
fill 446 230 228 446 244 228 minecraft:black_concrete
fill 465 230 234 465 235 234 minecraft:black_concrete
fill 465 230 262 465 308 262 minecraft:black_concrete
fill 423 231 229 423 236 229 minecraft:black_concrete
setblock 423 231 232 minecraft:sea_lantern
setblock 423 231 251 minecraft:blue_concrete
setblock 423 231 263 minecraft:purple_terracotta
setblock 424 231 270 minecraft:pearlescent_froglight
fill 428 231 245 428 232 246 minecraft:gray_concrete
fill 432 231 228 432 254 228 minecraft:black_concrete
setblock 452 231 228 minecraft:pearlescent_froglight
setblock 423 232 231 minecraft:white_concrete
fill 423 232 232 423 246 232 minecraft:black_concrete
fill 423 232 251 423 247 251 minecraft:black_concrete
setblock 423 232 255 minecraft:sea_lantern
fill 423 232 263 423 260 263 minecraft:black_concrete
fill 424 232 270 424 253 270 minecraft:black_concrete
setblock 444 232 270 minecraft:ochre_froglight
fill 452 232 228 452 259 228 minecraft:black_concrete
setblock 465 232 253 minecraft:ochre_froglight
fill 423 233 231 423 308 231 minecraft:black_concrete
setblock 423 233 250 minecraft:white_concrete
fill 423 233 255 423 308 255 minecraft:black_concrete
setblock 425 233 230 minecraft:yellow_terracotta
setblock 426 233 231 minecraft:light[level=15]
setblock 426 233 239 minecraft:light[level=15]
setblock 426 233 247 minecraft:light[level=15]
setblock 426 233 255 minecraft:light[level=15]
setblock 426 233 263 minecraft:light[level=15]
setblock 434 233 231 minecraft:light[level=15]
setblock 434 233 239 minecraft:light[level=15]
setblock 434 233 247 minecraft:light[level=15]
setblock 434 233 255 minecraft:light[level=15]
setblock 434 233 263 minecraft:light[level=15]
setblock 442 233 231 minecraft:light[level=15]
setblock 442 233 239 minecraft:light[level=15]
setblock 442 233 247 minecraft:light[level=15]
setblock 442 233 255 minecraft:light[level=15]
setblock 442 233 263 minecraft:light[level=15]
setblock 443 233 228 minecraft:purple_terracotta
fill 444 233 270 444 284 270 minecraft:black_concrete
setblock 450 233 231 minecraft:light[level=15]
setblock 450 233 239 minecraft:light[level=15]
setblock 450 233 247 minecraft:light[level=15]
setblock 450 233 255 minecraft:light[level=15]
setblock 450 233 263 minecraft:light[level=15]
setblock 456 233 228 minecraft:magenta_terracotta
setblock 458 233 231 minecraft:light[level=15]
setblock 458 233 239 minecraft:light[level=15]
setblock 458 233 247 minecraft:light[level=15]
setblock 458 233 255 minecraft:light[level=15]
setblock 458 233 263 minecraft:light[level=15]
setblock 460 233 228 minecraft:white_concrete
setblock 464 233 228 minecraft:pearlescent_froglight
setblock 465 233 236 minecraft:sea_lantern
fill 465 233 253 465 235 253 minecraft:black_concrete
setblock 465 233 264 minecraft:pearlescent_froglight
setblock 423 234 246 minecraft:pearlescent_froglight
fill 423 234 250 423 308 250 minecraft:black_concrete
setblock 423 234 267 minecraft:magenta_terracotta
fill 424 234 229 427 235 234 minecraft:orange_terracotta
setblock 426 234 238 minecraft:light[level=12]
setblock 426 234 245 minecraft:light[level=12]
setblock 426 234 252 minecraft:light[level=12]
setblock 426 234 259 minecraft:light[level=12]
setblock 426 234 266 minecraft:light[level=12]
fill 428 234 229 428 235 233 minecraft:orange_terracotta
fill 429 234 229 429 235 232 minecraft:orange_terracotta
setblock 433 234 231 minecraft:light[level=12]
setblock 433 234 238 minecraft:light[level=12]
setblock 433 234 245 minecraft:light[level=12]
setblock 433 234 252 minecraft:light[level=12]
setblock 433 234 259 minecraft:light[level=12]
setblock 433 234 266 minecraft:light[level=12]
setblock 440 234 231 minecraft:light[level=12]
setblock 440 234 238 minecraft:light[level=12]
setblock 440 234 245 minecraft:light[level=12]
setblock 440 234 252 minecraft:light[level=12]
setblock 440 234 259 minecraft:light[level=12]
setblock 440 234 266 minecraft:light[level=12]
fill 443 234 228 443 240 228 minecraft:black_concrete
setblock 447 234 231 minecraft:light[level=12]
setblock 447 234 238 minecraft:light[level=12]
setblock 447 234 245 minecraft:light[level=12]
setblock 447 234 252 minecraft:light[level=12]
setblock 447 234 259 minecraft:light[level=12]
setblock 447 234 266 minecraft:light[level=12]
setblock 454 234 231 minecraft:light[level=12]
setblock 454 234 238 minecraft:light[level=12]
setblock 454 234 245 minecraft:light[level=12]
setblock 454 234 252 minecraft:light[level=12]
setblock 454 234 259 minecraft:light[level=12]
setblock 454 234 266 minecraft:light[level=12]
fill 456 234 228 456 265 228 minecraft:black_concrete
fill 460 234 228 460 281 228 minecraft:black_concrete
setblock 461 234 231 minecraft:light[level=12]
setblock 461 234 238 minecraft:light[level=12]
setblock 461 234 245 minecraft:light[level=12]
setblock 461 234 252 minecraft:light[level=12]
setblock 461 234 259 minecraft:light[level=12]
setblock 461 234 266 minecraft:light[level=12]
fill 464 234 228 464 248 228 minecraft:black_concrete
fill 465 234 236 465 238 236 minecraft:black_concrete
fill 465 234 264 465 308 264 minecraft:black_concrete
fill 423 235 246 423 237 246 minecraft:black_concrete
setblock 423 235 259 minecraft:sea_lantern
fill 423 235 267 423 262 267 minecraft:black_concrete
fill 424 235 235 426 235 236 minecraft:orange_terracotta
setblock 425 235 228 minecraft:ochre_froglight
fill 427 235 235 428 235 235 minecraft:orange_terracotta
fill 428 235 234 429 235 234 minecraft:orange_terracotta
fill 429 235 233 430 235 233 minecraft:orange_terracotta
fill 430 235 229 430 235 232 minecraft:orange_terracotta
fill 431 235 229 431 235 231 minecraft:orange_terracotta
fill 447 235 262 451 236 266 minecraft:gray_concrete
fill 449 235 267 449 235 268 minecraft:gray_concrete
setblock 459 235 228 minecraft:ochre_froglight
setblock 465 235 267 minecraft:pearlescent_froglight
fill 423 236 259 423 244 259 minecraft:black_concrete
fill 424 236 229 427 237 237 minecraft:yellow_terracotta
fill 425 236 228 425 253 228 minecraft:black_concrete
fill 428 236 229 429 237 236 minecraft:yellow_terracotta
fill 430 236 229 430 237 235 minecraft:yellow_terracotta
fill 431 236 229 431 237 234 minecraft:yellow_terracotta
fill 432 236 229 432 237 232 minecraft:yellow_terracotta
setblock 434 236 270 minecraft:pearlescent_froglight
setblock 447 236 228 minecraft:sea_lantern
fill 459 236 228 459 308 228 minecraft:black_concrete
setblock 465 236 234 minecraft:sea_lantern
setblock 465 236 253 minecraft:magenta_terracotta
fill 465 236 267 465 293 267 minecraft:black_concrete
setblock 423 237 229 minecraft:purple_terracotta
fill 424 237 238 427 237 238 minecraft:yellow_terracotta
fill 428 237 237 429 237 237 minecraft:yellow_terracotta
setblock 429 237 270 minecraft:blue_concrete
setblock 430 237 236 minecraft:yellow_terracotta
setblock 431 237 235 minecraft:yellow_terracotta
fill 432 237 233 432 237 234 minecraft:yellow_terracotta
fill 433 237 229 433 237 232 minecraft:yellow_terracotta
fill 434 237 270 434 240 270 minecraft:black_concrete
setblock 439 237 270 minecraft:purple_terracotta
setblock 440 237 228 minecraft:pearlescent_froglight
setblock 447 237 228 minecraft:black_concrete
setblock 464 237 270 minecraft:pearlescent_froglight
fill 465 237 234 465 242 234 minecraft:black_concrete
fill 465 237 253 465 278 253 minecraft:black_concrete
setblock 465 237 265 minecraft:white_concrete
fill 423 238 229 423 289 229 minecraft:black_concrete
setblock 423 238 234 minecraft:ochre_froglight
setblock 423 238 246 minecraft:white_concrete
fill 424 238 229 429 238 238 minecraft:brown_terracotta
fill 429 238 270 429 245 270 minecraft:black_concrete
fill 430 238 229 430 238 237 minecraft:brown_terracotta
fill 431 238 229 431 238 236 minecraft:brown_terracotta
fill 432 238 229 432 238 235 minecraft:brown_terracotta
setblock 432 238 270 minecraft:ochre_froglight
fill 433 238 229 433 238 234 minecraft:brown_terracotta
fill 439 238 270 439 260 270 minecraft:black_concrete
fill 440 238 228 440 249 228 minecraft:black_concrete
setblock 447 238 228 minecraft:blue_concrete
fill 449 238 264 449 245 264 minecraft:orange_concrete
fill 464 238 270 464 261 270 minecraft:black_concrete
fill 465 238 265 465 308 265 minecraft:black_concrete
fill 423 239 234 423 308 234 minecraft:black_concrete
fill 423 239 246 423 295 246 minecraft:black_concrete
setblock 423 239 264 minecraft:sea_lantern
setblock 424 239 228 minecraft:sea_lantern
fill 424 239 229 428 239 239 minecraft:orange_terracotta
fill 429 239 229 430 239 238 minecraft:orange_terracotta
fill 431 239 229 431 239 237 minecraft:orange_terracotta
fill 432 239 229 432 239 236 minecraft:orange_terracotta
fill 432 239 270 432 259 270 minecraft:black_concrete
fill 433 239 229 433 239 235 minecraft:orange_terracotta
fill 434 239 229 434 239 233 minecraft:orange_terracotta
fill 447 239 228 447 308 228 minecraft:black_concrete
fill 447 239 263 448 244 265 minecraft:orange_concrete
fill 448 239 262 450 244 262 minecraft:orange_concrete
fill 448 239 266 450 244 266 minecraft:orange_concrete
fill 449 239 263 451 244 263 minecraft:orange_concrete
fill 449 239 265 451 244 265 minecraft:orange_concrete
fill 450 239 264 451 244 264 minecraft:orange_concrete
setblock 453 239 270 minecraft:white_concrete
setblock 465 239 236 minecraft:sea_lantern
setblock 465 239 240 minecraft:white_concrete
setblock 423 240 241 minecraft:ochre_froglight
fill 423 240 264 423 272 264 minecraft:black_concrete
setblock 423 240 265 minecraft:ochre_froglight
fill 424 240 228 424 259 228 minecraft:black_concrete
fill 424 240 229 429 241 239 minecraft:yellow_terracotta
setblock 426 240 245 minecraft:light[level=12]
setblock 426 240 247 minecraft:light[level=15]
setblock 426 240 252 minecraft:light[level=12]
setblock 426 240 255 minecraft:light[level=15]
setblock 426 240 259 minecraft:light[level=12]
setblock 426 240 263 minecraft:light[level=15]
setblock 426 240 266 minecraft:light[level=12]
fill 427 240 228 427 257 228 minecraft:black_concrete
setblock 428 240 228 minecraft:sea_lantern
fill 430 240 229 430 241 238 minecraft:yellow_terracotta
fill 431 240 229 432 241 237 minecraft:yellow_terracotta
fill 433 240 229 433 241 235 minecraft:yellow_terracotta
setblock 433 240 238 minecraft:light[level=12]
setblock 433 240 245 minecraft:light[level=12]
setblock 433 240 252 minecraft:light[level=12]
setblock 433 240 259 minecraft:light[level=12]
setblock 433 240 266 minecraft:light[level=12]
fill 434 240 229 434 241 234 minecraft:yellow_terracotta
setblock 434 240 239 minecraft:light[level=15]
setblock 434 240 247 minecraft:light[level=15]
setblock 434 240 255 minecraft:light[level=15]
setblock 434 240 263 minecraft:light[level=15]
setblock 440 240 231 minecraft:light[level=12]
setblock 440 240 238 minecraft:light[level=12]
setblock 440 240 245 minecraft:light[level=12]
setblock 440 240 252 minecraft:light[level=12]
setblock 440 240 259 minecraft:light[level=12]
setblock 440 240 266 minecraft:light[level=12]
setblock 442 240 231 minecraft:light[level=15]
setblock 442 240 239 minecraft:light[level=15]
setblock 442 240 247 minecraft:light[level=15]
setblock 442 240 255 minecraft:light[level=15]
setblock 442 240 263 minecraft:light[level=15]
fill 446 240 263 446 243 265 minecraft:orange_concrete
setblock 447 240 231 minecraft:light[level=12]
setblock 447 240 238 minecraft:light[level=12]
setblock 447 240 245 minecraft:light[level=12]
setblock 447 240 252 minecraft:light[level=12]
setblock 447 240 259 minecraft:light[level=12]
fill 447 240 262 447 243 262 minecraft:orange_concrete
fill 447 240 266 447 243 266 minecraft:orange_concrete
fill 448 240 261 450 243 261 minecraft:orange_concrete
fill 448 240 267 450 243 267 minecraft:orange_concrete
setblock 450 240 231 minecraft:light[level=15]
setblock 450 240 239 minecraft:light[level=15]
setblock 450 240 247 minecraft:light[level=15]
setblock 450 240 255 minecraft:light[level=15]
fill 451 240 262 451 243 262 minecraft:orange_concrete
fill 451 240 266 451 243 266 minecraft:orange_concrete
fill 452 240 263 452 243 265 minecraft:orange_concrete
fill 453 240 270 453 293 270 minecraft:black_concrete
setblock 454 240 231 minecraft:light[level=12]
setblock 454 240 238 minecraft:light[level=12]
setblock 454 240 245 minecraft:light[level=12]
setblock 454 240 252 minecraft:light[level=12]
setblock 454 240 259 minecraft:light[level=12]
setblock 454 240 266 minecraft:light[level=12]
setblock 454 240 270 minecraft:ochre_froglight
setblock 458 240 231 minecraft:light[level=15]
setblock 458 240 239 minecraft:light[level=15]
setblock 458 240 247 minecraft:light[level=15]
setblock 458 240 255 minecraft:light[level=15]
setblock 458 240 263 minecraft:light[level=15]
setblock 458 240 270 minecraft:white_concrete
setblock 461 240 231 minecraft:light[level=12]
setblock 461 240 238 minecraft:light[level=12]
setblock 461 240 245 minecraft:light[level=12]
setblock 461 240 252 minecraft:light[level=12]
setblock 461 240 259 minecraft:light[level=12]
setblock 461 240 266 minecraft:light[level=12]
fill 465 240 236 465 255 236 minecraft:black_concrete
setblock 465 240 238 minecraft:white_concrete
fill 465 240 240 465 252 240 minecraft:black_concrete
setblock 465 240 261 minecraft:ochre_froglight
fill 423 241 236 423 241 237 minecraft:ochre_froglight
fill 423 241 241 423 308 241 minecraft:black_concrete
fill 423 241 265 423 276 265 minecraft:black_concrete
fill 424 241 240 427 241 240 minecraft:yellow_terracotta
fill 428 241 228 428 264 228 minecraft:black_concrete
setblock 430 241 270 minecraft:purple_concrete
setblock 431 241 238 minecraft:yellow_terracotta
setblock 433 241 236 minecraft:yellow_terracotta
setblock 434 241 270 minecraft:sea_lantern
fill 435 241 229 435 241 232 minecraft:yellow_terracotta
setblock 443 241 228 minecraft:ochre_froglight
fill 454 241 270 454 246 270 minecraft:black_concrete
fill 458 241 270 458 265 270 minecraft:black_concrete
fill 465 241 238 465 275 238 minecraft:black_concrete
fill 465 241 261 465 250 261 minecraft:black_concrete
fill 423 242 236 423 258 237 minecraft:black_concrete
setblock 423 242 245 minecraft:white_concrete
fill 424 242 229 427 243 240 minecraft:orange_terracotta
fill 428 242 229 430 243 239 minecraft:orange_terracotta
setblock 430 242 270 minecraft:black_concrete
fill 431 242 229 431 243 238 minecraft:orange_terracotta
fill 432 242 229 432 243 237 minecraft:orange_terracotta
fill 433 242 229 433 243 236 minecraft:orange_terracotta
fill 434 242 229 434 243 235 minecraft:orange_terracotta
fill 434 242 270 434 250 270 minecraft:black_concrete
fill 435 242 229 435 243 232 minecraft:orange_terracotta
fill 435 242 238 436 242 241 minecraft:white_terracotta
fill 436 242 236 438 242 237 minecraft:white_terracotta
fill 437 242 234 439 242 235 minecraft:white_terracotta
fill 437 242 238 437 242 239 minecraft:white_terracotta
fill 438 242 229 440 242 233 minecraft:white_terracotta
setblock 438 242 238 minecraft:white_terracotta
setblock 439 242 236 minecraft:white_terracotta
setblock 440 242 234 minecraft:white_terracotta
setblock 440 242 270 minecraft:ochre_froglight
fill 443 242 228 443 250 228 minecraft:black_concrete
setblock 453 242 228 minecraft:ochre_froglight
setblock 458 242 228 minecraft:sea_lantern
setblock 462 242 228 minecraft:pearlescent_froglight
fill 423 243 245 423 267 245 minecraft:black_concrete
setblock 423 243 252 minecraft:purple_terracotta
setblock 427 243 270 minecraft:sea_lantern
setblock 428 243 240 minecraft:orange_terracotta
fill 428 243 243 429 243 245 minecraft:white_terracotta
fill 429 243 242 434 243 242 minecraft:white_terracotta
fill 430 243 243 431 243 244 minecraft:white_terracotta
setblock 430 243 270 minecraft:pearlescent_froglight
fill 431 243 241 435 243 241 minecraft:white_terracotta
fill 432 243 243 433 243 243 minecraft:white_terracotta
fill 433 243 240 435 243 240 minecraft:white_terracotta
fill 434 243 239 435 243 239 minecraft:white_terracotta
setblock 435 243 233 minecraft:orange_terracotta
setblock 435 243 238 minecraft:white_terracotta
fill 440 243 270 440 290 270 minecraft:black_concrete
setblock 450 243 270 minecraft:sea_lantern
setblock 451 243 270 minecraft:pearlescent_froglight
fill 453 243 228 453 248 228 minecraft:black_concrete
fill 458 243 228 458 301 228 minecraft:black_concrete
fill 462 243 228 462 250 228 minecraft:black_concrete
setblock 465 243 234 minecraft:white_concrete
setblock 465 243 241 minecraft:ochre_froglight
setblock 465 243 248 minecraft:white_concrete
setblock 423 244 230 minecraft:pearlescent_froglight
fill 423 244 252 423 260 252 minecraft:black_concrete
fill 424 244 229 428 244 240 minecraft:yellow_terracotta
fill 424 244 243 428 244 245 minecraft:white_terracotta
fill 427 244 270 427 254 270 minecraft:black_concrete
fill 429 244 229 430 244 239 minecraft:yellow_terracotta
fill 430 244 270 430 277 270 minecraft:black_concrete
fill 431 244 229 431 244 238 minecraft:yellow_terracotta
fill 432 244 229 432 244 237 minecraft:yellow_terracotta
fill 433 244 229 433 244 236 minecraft:yellow_terracotta
fill 434 244 229 434 244 235 minecraft:yellow_terracotta
fill 435 244 229 435 244 233 minecraft:yellow_terracotta
fill 450 244 270 451 244 270 minecraft:black_concrete
fill 465 244 234 465 308 234 minecraft:black_concrete
fill 465 244 241 465 262 241 minecraft:black_concrete
setblock 465 244 248 minecraft:black_concrete
fill 423 245 230 423 308 230 minecraft:black_concrete
setblock 423 245 259 minecraft:pearlescent_froglight
fill 424 245 229 427 245 240 minecraft:brown_terracotta
fill 428 245 229 430 245 239 minecraft:brown_terracotta
fill 431 245 229 431 245 238 minecraft:brown_terracotta
fill 432 245 229 432 245 237 minecraft:brown_terracotta
fill 433 245 229 433 245 236 minecraft:brown_terracotta
fill 434 245 229 434 245 235 minecraft:brown_terracotta
fill 435 245 229 435 245 232 minecraft:brown_terracotta
setblock 442 245 228 minecraft:sea_lantern
setblock 446 245 228 minecraft:ochre_froglight
fill 450 245 270 450 248 270 minecraft:black_concrete
setblock 451 245 270 minecraft:sea_lantern
fill 460 245 245 462 247 247 minecraft:gold_block
setblock 465 245 233 minecraft:ochre_froglight
setblock 465 245 247 minecraft:ochre_froglight
setblock 465 245 248 minecraft:white_concrete
setblock 465 245 269 minecraft:purple_terracotta
fill 423 246 259 423 266 259 minecraft:black_concrete
fill 424 246 229 427 246 240 minecraft:orange_terracotta
setblock 426 246 245 minecraft:light[level=12]
setblock 426 246 252 minecraft:light[level=12]
setblock 426 246 259 minecraft:light[level=12]
setblock 426 246 266 minecraft:light[level=12]
fill 428 246 229 429 247 239 minecraft:orange_terracotta
setblock 429 246 270 minecraft:pearlescent_froglight
fill 430 246 229 431 246 238 minecraft:orange_terracotta
fill 432 246 229 432 247 237 minecraft:orange_terracotta
fill 433 246 229 433 246 236 minecraft:orange_terracotta
setblock 433 246 238 minecraft:light[level=12]
setblock 433 246 245 minecraft:light[level=12]
setblock 433 246 252 minecraft:light[level=12]
setblock 433 246 259 minecraft:light[level=12]
setblock 433 246 266 minecraft:light[level=12]
fill 434 246 229 434 247 234 minecraft:orange_terracotta
fill 435 246 229 435 246 232 minecraft:orange_terracotta
setblock 440 246 231 minecraft:light[level=12]
setblock 440 246 238 minecraft:light[level=12]
setblock 440 246 245 minecraft:light[level=12]
setblock 440 246 252 minecraft:light[level=12]
setblock 440 246 259 minecraft:light[level=12]
setblock 440 246 266 minecraft:light[level=12]
setblock 441 246 270 minecraft:white_concrete
fill 442 246 228 442 258 228 minecraft:black_concrete
fill 446 246 228 446 308 228 minecraft:black_concrete
setblock 447 246 231 minecraft:light[level=12]
setblock 447 246 238 minecraft:light[level=12]
setblock 447 246 245 minecraft:light[level=12]
setblock 447 246 252 minecraft:light[level=12]
setblock 447 246 259 minecraft:light[level=12]
setblock 447 246 266 minecraft:light[level=12]
fill 451 246 270 451 308 270 minecraft:black_concrete
setblock 454 246 231 minecraft:light[level=12]
setblock 454 246 238 minecraft:light[level=12]
setblock 454 246 245 minecraft:light[level=12]
setblock 454 246 252 minecraft:light[level=12]
setblock 454 246 259 minecraft:light[level=12]
setblock 454 246 266 minecraft:light[level=12]
fill 460 246 240 462 246 244 minecraft:blue_stained_glass
fill 460 246 248 462 246 252 minecraft:blue_stained_glass
setblock 461 246 231 minecraft:light[level=12]
setblock 461 246 238 minecraft:light[level=12]
setblock 461 246 259 minecraft:light[level=12]
setblock 461 246 266 minecraft:light[level=12]
setblock 465 246 229 minecraft:purple_concrete
fill 465 246 233 465 259 233 minecraft:black_concrete
fill 465 246 247 465 255 248 minecraft:black_concrete
fill 465 246 269 465 281 269 minecraft:black_concrete
setblock 423 247 232 minecraft:sea_lantern
setblock 423 247 248 minecraft:pearlescent_froglight
fill 423 247 249 423 287 249 minecraft:black_concrete
fill 424 247 229 427 247 239 minecraft:orange_terracotta
setblock 426 247 247 minecraft:light[level=15]
setblock 426 247 255 minecraft:light[level=15]
setblock 426 247 263 minecraft:light[level=15]
fill 429 247 270 429 308 270 minecraft:black_concrete
fill 430 247 229 430 247 238 minecraft:orange_terracotta
fill 431 247 229 431 247 237 minecraft:orange_terracotta
fill 433 247 229 433 247 235 minecraft:orange_terracotta
setblock 434 247 239 minecraft:light[level=15]
setblock 434 247 247 minecraft:light[level=15]
setblock 434 247 255 minecraft:light[level=15]
setblock 434 247 263 minecraft:light[level=15]
fill 441 247 270 441 308 270 minecraft:black_concrete
setblock 442 247 231 minecraft:light[level=15]
setblock 442 247 239 minecraft:light[level=15]
setblock 442 247 247 minecraft:light[level=15]
setblock 442 247 255 minecraft:light[level=15]
setblock 442 247 263 minecraft:light[level=15]
setblock 442 247 270 minecraft:blue_concrete
setblock 450 247 231 minecraft:light[level=15]
setblock 450 247 239 minecraft:light[level=15]
setblock 450 247 247 minecraft:light[level=15]
setblock 450 247 255 minecraft:light[level=15]
setblock 450 247 263 minecraft:light[level=15]
setblock 454 247 270 minecraft:white_concrete
setblock 458 247 231 minecraft:light[level=15]
setblock 458 247 239 minecraft:light[level=15]
setblock 458 247 247 minecraft:light[level=15]
setblock 458 247 255 minecraft:light[level=15]
setblock 458 247 263 minecraft:light[level=15]
setblock 459 247 270 minecraft:pearlescent_froglight
fill 465 247 229 465 308 229 minecraft:black_concrete
setblock 423 248 232 minecraft:pearlescent_froglight
fill 423 248 248 423 306 248 minecraft:black_concrete
setblock 423 248 251 minecraft:ochre_froglight
setblock 423 248 260 minecraft:pearlescent_froglight
setblock 423 248 262 minecraft:pearlescent_froglight
fill 424 248 229 428 248 239 minecraft:yellow_terracotta
fill 429 248 229 430 248 238 minecraft:yellow_terracotta
fill 431 248 229 431 248 237 minecraft:yellow_terracotta
fill 432 248 229 432 248 236 minecraft:yellow_terracotta
fill 433 248 229 433 248 235 minecraft:yellow_terracotta
fill 434 248 229 434 248 233 minecraft:yellow_terracotta
fill 442 248 270 442 298 270 minecraft:black_concrete
setblock 454 248 270 minecraft:sea_lantern
fill 459 248 270 459 252 270 minecraft:black_concrete
fill 461 248 246 461 249 246 minecraft:iron_bars
setblock 465 248 242 minecraft:pearlescent_froglight
fill 423 249 232 423 258 232 minecraft:black_concrete
fill 423 249 251 423 260 251 minecraft:black_concrete
fill 423 249 260 423 253 260 minecraft:black_concrete
fill 423 249 262 423 263 262 minecraft:black_concrete
fill 424 249 229 429 249 238 minecraft:yellow_terracotta
fill 430 249 229 430 249 237 minecraft:yellow_terracotta
fill 431 249 229 431 249 236 minecraft:yellow_terracotta
fill 432 249 229 432 249 235 minecraft:yellow_terracotta
fill 433 249 229 433 249 234 minecraft:yellow_terracotta
setblock 450 249 228 minecraft:white_concrete
setblock 450 249 270 minecraft:magenta_terracotta
setblock 453 249 228 minecraft:pearlescent_froglight
fill 454 249 270 454 267 270 minecraft:black_concrete
setblock 464 249 228 minecraft:ochre_froglight
fill 465 249 242 465 283 242 minecraft:black_concrete
fill 424 250 229 427 250 238 minecraft:orange_terracotta
fill 428 250 229 429 250 237 minecraft:orange_terracotta
fill 430 250 229 430 250 236 minecraft:orange_terracotta
fill 431 250 229 431 250 235 minecraft:orange_terracotta
fill 432 250 229 432 250 234 minecraft:orange_terracotta
fill 433 250 229 433 250 232 minecraft:orange_terracotta
setblock 440 250 228 minecraft:pearlescent_froglight
setblock 450 250 228 minecraft:black_concrete
fill 450 250 270 450 262 270 minecraft:black_concrete
fill 453 250 228 453 256 228 minecraft:black_concrete
fill 464 250 228 464 308 228 minecraft:black_concrete
setblock 465 250 243 minecraft:ochre_froglight
setblock 423 251 254 minecraft:white_concrete
fill 424 251 229 427 251 237 minecraft:orange_terracotta
fill 428 251 229 429 251 236 minecraft:orange_terracotta
fill 430 251 229 430 251 235 minecraft:orange_terracotta
fill 431 251 229 431 251 234 minecraft:orange_terracotta
fill 432 251 229 432 251 232 minecraft:orange_terracotta
setblock 434 251 270 minecraft:ochre_froglight
setblock 438 251 270 minecraft:ochre_froglight
fill 440 251 228 440 267 228 minecraft:black_concrete
setblock 443 251 228 minecraft:pearlescent_froglight
setblock 447 251 270 minecraft:pearlescent_froglight
setblock 448 251 228 minecraft:pearlescent_froglight
setblock 450 251 228 minecraft:purple_concrete
setblock 462 251 228 minecraft:purple_concrete
fill 465 251 243 465 270 243 minecraft:black_concrete
setblock 465 251 261 minecraft:purple_terracotta
setblock 423 252 247 minecraft:pearlescent_froglight
fill 423 252 254 423 308 254 minecraft:black_concrete
setblock 423 252 269 minecraft:pearlescent_froglight
fill 424 252 229 426 252 236 minecraft:brown_terracotta
setblock 425 252 270 minecraft:purple_concrete
setblock 426 252 238 minecraft:light[level=12]
setblock 426 252 245 minecraft:light[level=12]
setblock 426 252 252 minecraft:light[level=12]
setblock 426 252 259 minecraft:light[level=12]
setblock 426 252 266 minecraft:light[level=12]
fill 427 252 229 428 252 235 minecraft:brown_terracotta
fill 429 252 229 429 252 234 minecraft:brown_terracotta
fill 430 252 229 430 252 233 minecraft:brown_terracotta
fill 431 252 229 431 252 231 minecraft:brown_terracotta
setblock 433 252 231 minecraft:light[level=12]
setblock 433 252 238 minecraft:light[level=12]
setblock 433 252 245 minecraft:light[level=12]
setblock 433 252 252 minecraft:light[level=12]
setblock 433 252 259 minecraft:light[level=12]
setblock 433 252 266 minecraft:light[level=12]
fill 434 252 270 434 280 270 minecraft:black_concrete
fill 438 252 270 438 284 270 minecraft:black_concrete
setblock 440 252 231 minecraft:light[level=12]
setblock 440 252 238 minecraft:light[level=12]
setblock 440 252 245 minecraft:light[level=12]
setblock 440 252 252 minecraft:light[level=12]
setblock 440 252 259 minecraft:light[level=12]
setblock 440 252 266 minecraft:light[level=12]
fill 443 252 228 443 257 228 minecraft:black_concrete
setblock 447 252 231 minecraft:light[level=12]
setblock 447 252 238 minecraft:light[level=12]
setblock 447 252 245 minecraft:light[level=12]
setblock 447 252 252 minecraft:light[level=12]
fill 447 252 254 447 254 254 minecraft:cobbled_deepslate
setblock 447 252 259 minecraft:light[level=12]
setblock 447 252 266 minecraft:light[level=12]
fill 447 252 270 447 255 270 minecraft:black_concrete
fill 448 252 228 448 278 228 minecraft:black_concrete
fill 450 252 228 450 308 228 minecraft:black_concrete
setblock 454 252 231 minecraft:light[level=12]
setblock 454 252 238 minecraft:light[level=12]
setblock 454 252 245 minecraft:light[level=12]
setblock 454 252 252 minecraft:light[level=12]
setblock 454 252 259 minecraft:light[level=12]
setblock 454 252 266 minecraft:light[level=12]
setblock 461 252 231 minecraft:light[level=12]
setblock 461 252 238 minecraft:light[level=12]
setblock 461 252 245 minecraft:light[level=12]
setblock 461 252 252 minecraft:light[level=12]
setblock 461 252 259 minecraft:light[level=12]
setblock 461 252 266 minecraft:light[level=12]
fill 462 252 228 462 308 228 minecraft:black_concrete
fill 465 252 261 465 275 261 minecraft:black_concrete
setblock 423 253 243 minecraft:ochre_froglight
fill 423 253 247 423 272 247 minecraft:black_concrete
fill 423 253 269 423 263 269 minecraft:black_concrete
fill 424 253 229 427 253 234 minecraft:yellow_terracotta
fill 425 253 270 425 268 270 minecraft:black_concrete
fill 428 253 229 428 253 233 minecraft:yellow_terracotta
fill 429 253 229 429 253 232 minecraft:yellow_terracotta
fill 446 253 253 446 253 254 minecraft:cobbled_deepslate
fill 447 253 253 448 254 253 minecraft:cobbled_deepslate
fill 447 253 255 448 253 255 minecraft:cobbled_deepslate
fill 448 253 254 448 254 254 minecraft:cobbled_deepslate
setblock 459 253 270 minecraft:purple_concrete
setblock 461 253 270 minecraft:ochre_froglight
setblock 463 253 228 minecraft:white_concrete
setblock 465 253 240 minecraft:ochre_froglight
fill 423 254 243 423 261 243 minecraft:black_concrete
setblock 423 254 260 minecraft:sea_lantern
setblock 424 254 270 minecraft:pearlescent_froglight
setblock 425 254 228 minecraft:magenta_terracotta
setblock 425 254 230 minecraft:orange_terracotta
setblock 426 254 231 minecraft:light[level=15]
setblock 426 254 239 minecraft:light[level=15]
setblock 426 254 247 minecraft:light[level=15]
setblock 426 254 255 minecraft:light[level=15]
setblock 426 254 263 minecraft:light[level=15]
setblock 434 254 231 minecraft:light[level=15]
setblock 434 254 239 minecraft:light[level=15]
setblock 434 254 247 minecraft:light[level=15]
setblock 434 254 255 minecraft:light[level=15]
setblock 434 254 263 minecraft:light[level=15]
setblock 437 254 270 minecraft:white_concrete
setblock 442 254 231 minecraft:light[level=15]
setblock 442 254 239 minecraft:light[level=15]
setblock 442 254 255 minecraft:light[level=15]
setblock 442 254 263 minecraft:light[level=15]
setblock 446 254 254 minecraft:cobbled_deepslate
setblock 447 254 255 minecraft:cobbled_deepslate
setblock 448 254 270 minecraft:pearlescent_froglight
setblock 450 254 231 minecraft:light[level=15]
setblock 450 254 239 minecraft:light[level=15]
setblock 450 254 247 minecraft:light[level=15]
setblock 450 254 255 minecraft:light[level=15]
setblock 450 254 263 minecraft:light[level=15]
setblock 456 254 270 minecraft:purple_terracotta
setblock 458 254 231 minecraft:light[level=15]
setblock 458 254 239 minecraft:light[level=15]
setblock 458 254 247 minecraft:light[level=15]
setblock 458 254 255 minecraft:light[level=15]
setblock 458 254 263 minecraft:light[level=15]
fill 459 254 270 459 268 270 minecraft:black_concrete
fill 461 254 270 461 272 270 minecraft:black_concrete
fill 463 254 228 463 308 228 minecraft:black_concrete
setblock 465 254 237 minecraft:sea_lantern
fill 465 254 240 465 281 240 minecraft:black_concrete
fill 423 255 260 423 308 260 minecraft:black_concrete
fill 424 255 270 424 308 270 minecraft:black_concrete
fill 425 255 228 425 292 228 minecraft:black_concrete
setblock 427 255 270 minecraft:sea_lantern
setblock 432 255 228 minecraft:magenta_terracotta
fill 437 255 270 437 256 270 minecraft:black_concrete
fill 439 255 235 440 256 236 minecraft:end_stone
fill 441 255 235 441 256 235 minecraft:end_stone
fill 445 255 235 445 256 235 minecraft:end_stone
fill 448 255 270 448 308 270 minecraft:black_concrete
fill 456 255 270 456 308 270 minecraft:black_concrete
fill 460 255 243 461 256 244 minecraft:end_stone
fill 465 255 237 465 264 237 minecraft:black_concrete
setblock 465 255 250 minecraft:magenta_terracotta
fill 427 256 270 427 287 270 minecraft:black_concrete
fill 432 256 228 432 265 228 minecraft:black_concrete
setblock 447 256 270 minecraft:magenta_terracotta
setblock 454 256 228 minecraft:sea_lantern
setblock 457 256 228 minecraft:ochre_froglight
fill 459 256 253 459 257 254 minecraft:gray_concrete
setblock 465 256 232 minecraft:sea_lantern
setblock 465 256 236 minecraft:white_concrete
setblock 465 256 247 minecraft:blue_concrete
fill 465 256 248 465 260 248 minecraft:black_concrete
fill 465 256 250 465 263 250 minecraft:black_concrete
setblock 465 256 259 minecraft:purple_terracotta
setblock 423 257 258 minecraft:sea_lantern
setblock 423 257 261 minecraft:sea_lantern
setblock 437 257 270 minecraft:sea_lantern
setblock 443 257 270 minecraft:sea_lantern
fill 447 257 270 447 265 270 minecraft:black_concrete
setblock 453 257 228 minecraft:sea_lantern
fill 454 257 228 454 297 228 minecraft:black_concrete
fill 457 257 228 457 258 228 minecraft:black_concrete
setblock 457 257 270 minecraft:ochre_froglight
setblock 465 257 231 minecraft:ochre_froglight
fill 465 257 232 465 299 232 minecraft:black_concrete
fill 465 257 236 465 308 236 minecraft:black_concrete
fill 465 257 247 465 308 247 minecraft:black_concrete
setblock 465 257 255 minecraft:white_concrete
fill 465 257 259 465 277 259 minecraft:black_concrete
fill 423 258 258 423 308 258 minecraft:black_concrete
setblock 423 258 261 minecraft:white_concrete
setblock 426 258 231 minecraft:light[level=12]
setblock 426 258 238 minecraft:light[level=12]
setblock 426 258 245 minecraft:light[level=12]
setblock 426 258 252 minecraft:light[level=12]
setblock 426 258 259 minecraft:light[level=12]
setblock 426 258 266 minecraft:light[level=12]
setblock 427 258 228 minecraft:sea_lantern
setblock 433 258 231 minecraft:light[level=12]
setblock 433 258 238 minecraft:light[level=12]
setblock 433 258 245 minecraft:light[level=12]
setblock 433 258 252 minecraft:light[level=12]
setblock 433 258 259 minecraft:light[level=12]
setblock 433 258 266 minecraft:light[level=12]
fill 437 258 270 437 297 270 minecraft:black_concrete
setblock 440 258 231 minecraft:light[level=12]
setblock 440 258 238 minecraft:light[level=12]
setblock 440 258 245 minecraft:light[level=12]
setblock 440 258 252 minecraft:light[level=12]
setblock 440 258 259 minecraft:light[level=12]
setblock 440 258 266 minecraft:light[level=12]
setblock 443 258 228 minecraft:white_concrete
fill 443 258 270 443 262 270 minecraft:black_concrete
setblock 447 258 231 minecraft:light[level=12]
setblock 447 258 238 minecraft:light[level=12]
setblock 447 258 245 minecraft:light[level=12]
setblock 447 258 252 minecraft:light[level=12]
setblock 447 258 259 minecraft:light[level=12]
setblock 447 258 266 minecraft:light[level=12]
fill 453 258 228 453 267 228 minecraft:black_concrete
setblock 454 258 231 minecraft:light[level=12]
setblock 454 258 238 minecraft:light[level=12]
setblock 454 258 245 minecraft:light[level=12]
setblock 454 258 252 minecraft:light[level=12]
setblock 454 258 259 minecraft:light[level=12]
setblock 454 258 266 minecraft:light[level=12]
setblock 455 258 270 minecraft:ochre_froglight
fill 457 258 270 457 266 270 minecraft:black_concrete
setblock 461 258 231 minecraft:light[level=12]
setblock 461 258 238 minecraft:light[level=12]
setblock 461 258 245 minecraft:light[level=12]
setblock 461 258 252 minecraft:light[level=12]
setblock 461 258 259 minecraft:light[level=12]
setblock 461 258 266 minecraft:light[level=12]
fill 465 258 231 465 308 231 minecraft:black_concrete
fill 465 258 255 465 277 255 minecraft:black_concrete
setblock 423 259 232 minecraft:magenta_terracotta
fill 423 259 236 423 281 236 minecraft:black_concrete
setblock 423 259 237 minecraft:ochre_froglight
fill 423 259 261 423 274 261 minecraft:black_concrete
setblock 427 259 228 minecraft:purple_terracotta
setblock 442 259 228 minecraft:pearlescent_froglight
fill 443 259 228 443 295 228 minecraft:black_concrete
setblock 446 259 270 minecraft:sea_lantern
fill 455 259 270 455 308 270 minecraft:black_concrete
setblock 457 259 228 minecraft:sea_lantern
fill 423 260 232 423 272 232 minecraft:black_concrete
fill 423 260 237 423 267 237 minecraft:black_concrete
setblock 424 260 228 minecraft:blue_concrete
fill 427 260 228 427 264 228 minecraft:black_concrete
setblock 432 260 270 minecraft:white_concrete
fill 435 260 254 435 261 254 minecraft:gray_concrete
fill 442 260 228 442 262 228 minecraft:black_concrete
fill 446 260 255 446 262 255 minecraft:andesite
fill 446 260 270 446 276 270 minecraft:black_concrete
setblock 452 260 228 minecraft:sea_lantern
setblock 457 260 228 minecraft:black_concrete
setblock 465 260 233 minecraft:blue_concrete
setblock 423 261 251 minecraft:white_concrete
setblock 423 261 252 minecraft:sea_lantern
setblock 423 261 263 minecraft:ochre_froglight
fill 424 261 228 424 308 228 minecraft:black_concrete
setblock 426 261 228 minecraft:blue_concrete
setblock 426 261 231 minecraft:light[level=15]
setblock 426 261 239 minecraft:light[level=15]
setblock 426 261 247 minecraft:light[level=15]
setblock 426 261 255 minecraft:light[level=15]
setblock 426 261 263 minecraft:light[level=15]
fill 432 261 270 432 276 270 minecraft:black_concrete
setblock 434 261 231 minecraft:light[level=15]
setblock 434 261 239 minecraft:light[level=15]
setblock 434 261 247 minecraft:light[level=15]
setblock 434 261 255 minecraft:light[level=15]
setblock 434 261 263 minecraft:light[level=15]
setblock 439 261 270 minecraft:magenta_terracotta
setblock 442 261 231 minecraft:light[level=15]
setblock 442 261 239 minecraft:light[level=15]
setblock 442 261 255 minecraft:light[level=15]
setblock 442 261 263 minecraft:light[level=15]
fill 444 261 255 445 262 255 minecraft:andesite
fill 445 261 254 446 262 254 minecraft:andesite
fill 445 261 256 446 262 256 minecraft:andesite
fill 447 261 255 447 262 255 minecraft:andesite
setblock 450 261 231 minecraft:light[level=15]
setblock 450 261 239 minecraft:light[level=15]
setblock 450 261 247 minecraft:light[level=15]
setblock 450 261 255 minecraft:light[level=15]
setblock 450 261 263 minecraft:light[level=15]
fill 452 261 228 452 308 228 minecraft:black_concrete
setblock 457 261 228 minecraft:pearlescent_froglight
setblock 458 261 231 minecraft:light[level=15]
setblock 458 261 239 minecraft:light[level=15]
setblock 458 261 247 minecraft:light[level=15]
setblock 458 261 255 minecraft:light[level=15]
setblock 458 261 263 minecraft:light[level=15]
fill 465 261 233 465 284 233 minecraft:black_concrete
setblock 465 261 248 minecraft:ochre_froglight
setblock 423 262 243 minecraft:white_concrete
fill 423 262 251 423 304 252 minecraft:black_concrete
fill 423 262 263 423 268 263 minecraft:black_concrete
fill 426 262 228 426 277 228 minecraft:black_concrete
fill 439 262 270 439 297 270 minecraft:black_concrete
fill 450 262 262 450 263 264 minecraft:gray_concrete
fill 451 262 262 451 263 263 minecraft:gray_concrete
setblock 457 262 228 minecraft:black_concrete
setblock 464 262 270 minecraft:sea_lantern
fill 465 262 248 465 268 248 minecraft:black_concrete
setblock 465 262 256 minecraft:purple_terracotta
fill 423 263 243 423 308 243 minecraft:black_concrete
setblock 423 263 267 minecraft:white_concrete
setblock 442 263 228 minecraft:ochre_froglight
setblock 443 263 270 minecraft:pearlescent_froglight
fill 450 263 270 450 264 270 minecraft:white_concrete
setblock 457 263 228 minecraft:sea_lantern
fill 464 263 270 464 266 270 minecraft:black_concrete
setblock 465 263 241 minecraft:white_concrete
fill 465 263 256 465 273 256 minecraft:black_concrete
setblock 423 264 235 minecraft:ochre_froglight
setblock 423 264 262 minecraft:pearlescent_froglight
fill 423 264 267 423 308 267 minecraft:black_concrete
setblock 423 264 269 minecraft:white_concrete
setblock 426 264 231 minecraft:light[level=12]
setblock 426 264 238 minecraft:light[level=12]
setblock 426 264 245 minecraft:light[level=12]
setblock 426 264 252 minecraft:light[level=12]
setblock 426 264 259 minecraft:light[level=12]
setblock 426 264 266 minecraft:light[level=12]
setblock 433 264 231 minecraft:light[level=12]
setblock 433 264 238 minecraft:light[level=12]
setblock 433 264 245 minecraft:light[level=12]
setblock 433 264 252 minecraft:light[level=12]
setblock 433 264 259 minecraft:light[level=12]
setblock 433 264 266 minecraft:light[level=12]
setblock 438 264 228 minecraft:sea_lantern
setblock 440 264 231 minecraft:light[level=12]
setblock 440 264 238 minecraft:light[level=12]
setblock 440 264 245 minecraft:light[level=12]
setblock 440 264 252 minecraft:light[level=12]
setblock 440 264 259 minecraft:light[level=12]
setblock 440 264 266 minecraft:light[level=12]
fill 442 264 228 442 308 228 minecraft:black_concrete
fill 443 264 270 443 275 270 minecraft:black_concrete
setblock 447 264 231 minecraft:light[level=12]
setblock 447 264 238 minecraft:light[level=12]
setblock 447 264 245 minecraft:light[level=12]
setblock 447 264 252 minecraft:light[level=12]
setblock 447 264 259 minecraft:light[level=12]
setblock 447 264 266 minecraft:light[level=12]
setblock 454 264 231 minecraft:light[level=12]
setblock 454 264 238 minecraft:light[level=12]
setblock 454 264 245 minecraft:light[level=12]
setblock 454 264 252 minecraft:light[level=12]
setblock 454 264 259 minecraft:light[level=12]
setblock 454 264 266 minecraft:light[level=12]
fill 457 264 228 457 293 228 minecraft:black_concrete
setblock 461 264 231 minecraft:light[level=12]
setblock 461 264 238 minecraft:light[level=12]
setblock 461 264 245 minecraft:light[level=12]
setblock 461 264 252 minecraft:light[level=12]
setblock 461 264 259 minecraft:light[level=12]
setblock 461 264 266 minecraft:light[level=12]
setblock 465 264 239 minecraft:white_concrete
fill 465 264 241 465 303 241 minecraft:black_concrete
setblock 465 264 244 minecraft:pearlescent_froglight
setblock 465 264 250 minecraft:ochre_froglight
fill 423 265 235 423 296 235 minecraft:black_concrete
setblock 423 265 238 minecraft:blue_concrete
fill 423 265 262 423 278 262 minecraft:black_concrete
fill 423 265 269 423 308 269 minecraft:black_concrete
setblock 426 265 270 minecraft:ochre_froglight
setblock 427 265 228 minecraft:sea_lantern
setblock 428 265 228 minecraft:white_concrete
fill 438 265 228 438 292 228 minecraft:black_concrete
fill 450 265 270 450 292 270 minecraft:black_concrete
setblock 465 265 237 minecraft:pearlescent_froglight
fill 465 265 239 465 308 239 minecraft:black_concrete
fill 465 265 244 465 292 244 minecraft:black_concrete
fill 465 265 250 465 274 250 minecraft:black_concrete
fill 423 266 238 423 271 238 minecraft:black_concrete
setblock 423 266 266 minecraft:sea_lantern
fill 426 266 270 426 308 270 minecraft:black_concrete
fill 427 266 228 428 270 228 minecraft:black_concrete
setblock 432 266 228 minecraft:sea_lantern
setblock 447 266 270 minecraft:white_concrete
setblock 456 266 228 minecraft:white_concrete
fill 457 266 254 461 267 258 minecraft:gray_concrete
setblock 458 266 270 minecraft:pearlescent_froglight
fill 462 266 256 463 266 256 minecraft:gray_concrete
fill 465 266 237 465 308 237 minecraft:black_concrete
setblock 423 267 259 minecraft:ochre_froglight
fill 423 267 266 423 280 266 minecraft:black_concrete
fill 432 267 228 432 308 228 minecraft:black_concrete
fill 436 267 236 436 268 236 minecraft:end_stone
fill 447 267 270 447 273 270 minecraft:black_concrete
fill 449 267 241 450 268 242 minecraft:end_stone
fill 456 267 228 456 308 228 minecraft:black_concrete
fill 456 267 256 456 268 256 minecraft:orange_concrete
setblock 457 267 270 minecraft:purple_concrete
fill 458 267 270 458 307 270 minecraft:black_concrete
fill 459 267 253 459 268 253 minecraft:orange_concrete
fill 459 267 259 459 268 259 minecraft:orange_concrete
fill 462 267 256 462 268 256 minecraft:orange_concrete
setblock 463 267 270 minecraft:purple_terracotta
setblock 464 267 270 minecraft:sea_lantern
setblock 423 268 237 minecraft:ochre_froglight
setblock 423 268 240 minecraft:sea_lantern
setblock 423 268 245 minecraft:sea_lantern
fill 423 268 259 423 308 259 minecraft:black_concrete
setblock 426 268 231 minecraft:light[level=15]
setblock 426 268 239 minecraft:light[level=15]
setblock 426 268 247 minecraft:light[level=15]
setblock 426 268 255 minecraft:light[level=15]
setblock 426 268 263 minecraft:light[level=15]
setblock 434 268 231 minecraft:light[level=15]
setblock 434 268 239 minecraft:light[level=15]
setblock 434 268 247 minecraft:light[level=15]
setblock 434 268 255 minecraft:light[level=15]
setblock 434 268 263 minecraft:light[level=15]
setblock 440 268 228 minecraft:pearlescent_froglight
setblock 442 268 231 minecraft:light[level=15]
setblock 442 268 239 minecraft:light[level=15]
setblock 442 268 255 minecraft:light[level=15]
setblock 442 268 263 minecraft:light[level=15]
setblock 450 268 231 minecraft:light[level=15]
setblock 450 268 239 minecraft:light[level=15]
setblock 450 268 247 minecraft:light[level=15]
setblock 450 268 255 minecraft:light[level=15]
setblock 450 268 263 minecraft:light[level=15]
setblock 453 268 228 minecraft:pearlescent_froglight
setblock 454 268 270 minecraft:white_concrete
fill 457 268 270 457 298 270 minecraft:black_concrete
setblock 458 268 231 minecraft:light[level=15]
setblock 458 268 239 minecraft:light[level=15]
setblock 458 268 247 minecraft:light[level=15]
fill 458 268 255 460 269 257 minecraft:light_gray_concrete
setblock 458 268 263 minecraft:light[level=15]
fill 463 268 270 464 308 270 minecraft:black_concrete
setblock 465 268 252 minecraft:ochre_froglight
setblock 465 268 257 minecraft:sea_lantern
fill 423 269 237 423 273 237 minecraft:black_concrete
fill 423 269 240 423 290 240 minecraft:black_concrete
fill 423 269 245 423 273 245 minecraft:black_concrete
setblock 423 269 263 minecraft:ochre_froglight
setblock 425 269 270 minecraft:white_concrete
fill 440 269 228 440 288 228 minecraft:black_concrete
fill 453 269 228 453 308 228 minecraft:black_concrete
fill 454 269 270 454 289 270 minecraft:black_concrete
setblock 457 269 256 minecraft:orange_concrete
setblock 459 269 254 minecraft:orange_concrete
setblock 459 269 258 minecraft:orange_concrete
setblock 459 269 270 minecraft:ochre_froglight
setblock 461 269 256 minecraft:orange_concrete
setblock 465 269 245 minecraft:sea_lantern
setblock 465 269 248 minecraft:blue_concrete
setblock 465 269 252 minecraft:blue_concrete
fill 465 269 257 465 308 257 minecraft:black_concrete
fill 423 270 263 423 281 263 minecraft:black_concrete
setblock 425 270 270 minecraft:ochre_froglight
setblock 426 270 231 minecraft:light[level=12]
setblock 426 270 238 minecraft:light[level=12]
setblock 426 270 245 minecraft:light[level=12]
setblock 426 270 252 minecraft:light[level=12]
setblock 426 270 259 minecraft:light[level=12]
setblock 426 270 266 minecraft:light[level=12]
setblock 433 270 231 minecraft:light[level=12]
setblock 433 270 238 minecraft:light[level=12]
setblock 433 270 245 minecraft:light[level=12]
setblock 433 270 252 minecraft:light[level=12]
setblock 433 270 259 minecraft:light[level=12]
setblock 433 270 266 minecraft:light[level=12]
setblock 440 270 231 minecraft:light[level=12]
setblock 440 270 238 minecraft:light[level=12]
setblock 440 270 245 minecraft:light[level=12]
setblock 440 270 252 minecraft:light[level=12]
setblock 440 270 259 minecraft:light[level=12]
setblock 440 270 266 minecraft:light[level=12]
setblock 447 270 231 minecraft:light[level=12]
setblock 447 270 238 minecraft:light[level=12]
setblock 447 270 245 minecraft:light[level=12]
setblock 447 270 252 minecraft:light[level=12]
setblock 447 270 259 minecraft:light[level=12]
setblock 447 270 266 minecraft:light[level=12]
setblock 454 270 231 minecraft:light[level=12]
setblock 454 270 238 minecraft:light[level=12]
setblock 454 270 245 minecraft:light[level=12]
setblock 454 270 252 minecraft:light[level=12]
setblock 454 270 259 minecraft:light[level=12]
setblock 454 270 266 minecraft:light[level=12]
fill 459 270 270 459 308 270 minecraft:black_concrete
setblock 461 270 231 minecraft:light[level=12]
setblock 461 270 238 minecraft:light[level=12]
setblock 461 270 245 minecraft:light[level=12]
setblock 461 270 252 minecraft:light[level=12]
setblock 461 270 259 minecraft:light[level=12]
setblock 461 270 266 minecraft:light[level=12]
fill 465 270 245 465 272 245 minecraft:black_concrete
fill 465 270 248 465 305 248 minecraft:black_concrete
fill 465 270 252 465 308 252 minecraft:black_concrete
fill 425 271 270 425 281 270 minecraft:black_concrete
fill 427 271 228 427 286 228 minecraft:black_concrete
setblock 428 271 228 minecraft:sea_lantern
setblock 437 271 228 minecraft:sea_lantern
setblock 441 271 228 minecraft:sea_lantern
setblock 465 271 243 minecraft:magenta_terracotta
setblock 423 272 233 minecraft:sea_lantern
setblock 423 272 238 minecraft:sea_lantern
fill 428 272 228 428 308 228 minecraft:black_concrete
fill 437 272 228 437 273 228 minecraft:black_concrete
fill 441 272 228 441 308 228 minecraft:black_concrete
fill 465 272 243 465 295 243 minecraft:black_concrete
setblock 423 273 232 minecraft:purple_concrete
fill 423 273 233 423 275 233 minecraft:black_concrete
fill 423 273 238 423 308 238 minecraft:black_concrete
setblock 423 273 247 minecraft:pearlescent_froglight
setblock 423 273 264 minecraft:white_concrete
setblock 461 273 270 minecraft:pearlescent_froglight
setblock 465 273 245 minecraft:magenta_terracotta
fill 423 274 232 423 308 232 minecraft:black_concrete
setblock 423 274 237 minecraft:sea_lantern
setblock 423 274 245 minecraft:sea_lantern
fill 423 274 247 423 280 247 minecraft:black_concrete
setblock 423 274 257 minecraft:magenta_terracotta
fill 423 274 264 423 296 264 minecraft:black_concrete
setblock 429 274 228 minecraft:pearlescent_froglight
setblock 437 274 228 minecraft:pearlescent_froglight
setblock 447 274 270 minecraft:pearlescent_froglight
setblock 460 274 270 minecraft:ochre_froglight
fill 461 274 270 461 280 270 minecraft:black_concrete
fill 465 274 245 465 275 245 minecraft:black_concrete
setblock 465 274 256 minecraft:ochre_froglight
fill 423 275 237 423 282 237 minecraft:black_concrete
fill 423 275 245 423 308 245 minecraft:black_concrete
fill 423 275 257 423 278 257 minecraft:black_concrete
setblock 423 275 261 minecraft:magenta_terracotta
setblock 426 275 231 minecraft:light[level=15]
setblock 426 275 239 minecraft:light[level=15]
setblock 426 275 247 minecraft:light[level=15]
setblock 426 275 255 minecraft:light[level=15]
setblock 426 275 263 minecraft:light[level=15]
fill 427 275 247 430 275 251 minecraft:white_concrete
fill 428 275 243 430 275 246 minecraft:white_concrete
fill 428 275 252 430 275 255 minecraft:white_concrete
fill 429 275 228 429 308 228 minecraft:black_concrete
fill 429 275 241 432 275 242 minecraft:white_concrete
fill 429 275 256 432 275 257 minecraft:white_concrete
fill 430 275 239 433 275 240 minecraft:white_concrete
fill 430 275 258 433 275 259 minecraft:white_concrete
fill 431 275 238 435 275 238 minecraft:white_concrete
fill 431 275 243 431 278 244 minecraft:white_concrete
fill 431 275 254 431 275 255 minecraft:white_concrete
fill 431 275 260 435 275 260 minecraft:white_concrete
fill 432 275 237 437 275 237 minecraft:white_concrete
fill 432 275 261 437 275 261 minecraft:white_concrete
fill 433 275 236 439 275 236 minecraft:white_concrete
fill 433 275 262 439 275 262 minecraft:white_concrete
setblock 434 275 231 minecraft:light[level=15]
fill 434 275 235 454 275 235 minecraft:white_concrete
setblock 434 275 239 minecraft:white_concrete
setblock 434 275 247 minecraft:light[level=15]
setblock 434 275 255 minecraft:light[level=15]
setblock 434 275 259 minecraft:white_concrete
fill 434 275 263 454 275 263 minecraft:white_concrete
fill 436 275 234 452 275 234 minecraft:white_concrete
fill 436 275 264 452 275 264 minecraft:white_concrete
fill 437 275 228 437 278 228 minecraft:black_concrete
fill 437 275 247 438 275 251 minecraft:white_concrete
fill 438 275 233 450 275 233 minecraft:white_concrete
fill 438 275 245 439 275 246 minecraft:white_concrete
fill 438 275 252 450 275 253 minecraft:white_concrete
fill 438 275 265 450 275 265 minecraft:white_concrete
fill 439 275 244 441 275 244 minecraft:white_concrete
fill 439 275 248 439 278 251 minecraft:white_concrete
fill 439 275 254 449 275 254 minecraft:white_concrete
fill 440 275 243 448 275 243 minecraft:white_concrete
fill 440 275 250 441 278 251 minecraft:white_concrete
fill 440 275 255 448 275 255 minecraft:white_concrete
setblock 442 275 231 minecraft:light[level=15]
fill 442 275 232 446 275 232 minecraft:white_concrete
setblock 442 275 239 minecraft:light[level=15]
fill 442 275 242 446 275 242 minecraft:white_concrete
fill 442 275 251 451 275 251 minecraft:white_concrete
fill 442 275 256 446 275 256 minecraft:white_concrete
fill 442 275 266 446 275 266 minecraft:white_concrete
fill 443 275 244 449 275 244 minecraft:white_concrete
fill 443 275 250 451 275 250 minecraft:white_concrete
setblock 444 275 228 minecraft:pearlescent_froglight
fill 445 275 245 450 275 246 minecraft:white_concrete
fill 445 275 248 451 275 249 minecraft:white_concrete
fill 446 275 247 451 275 247 minecraft:white_concrete
fill 447 275 270 447 308 270 minecraft:black_concrete
fill 449 275 236 455 275 236 minecraft:white_concrete
fill 449 275 262 455 275 262 minecraft:white_concrete
setblock 450 275 231 minecraft:light[level=15]
setblock 450 275 239 minecraft:light[level=15]
setblock 450 275 255 minecraft:light[level=15]
fill 451 275 237 456 275 237 minecraft:white_concrete
fill 451 275 261 456 275 261 minecraft:white_concrete
fill 453 275 238 457 275 238 minecraft:white_concrete
fill 453 275 260 457 275 260 minecraft:white_concrete
fill 454 275 239 458 275 239 minecraft:white_concrete
fill 454 275 259 458 275 259 minecraft:white_concrete
fill 455 275 240 458 275 240 minecraft:white_concrete
fill 455 275 258 458 275 258 minecraft:white_concrete
fill 456 275 241 459 275 242 minecraft:white_concrete
fill 456 275 256 459 275 257 minecraft:white_concrete
fill 457 275 243 460 275 244 minecraft:white_concrete
fill 457 275 254 460 275 255 minecraft:white_concrete
setblock 458 275 231 minecraft:light[level=15]
fill 458 275 245 460 275 253 minecraft:white_concrete
setblock 458 275 263 minecraft:light[level=15]
setblock 460 275 270 minecraft:pearlescent_froglight
fill 461 275 247 461 275 251 minecraft:white_concrete
setblock 465 275 250 minecraft:ochre_froglight
fill 465 275 256 465 308 256 minecraft:black_concrete
setblock 423 276 233 minecraft:ochre_froglight
fill 423 276 261 423 308 261 minecraft:black_concrete
setblock 426 276 231 minecraft:light[level=12]
setblock 426 276 238 minecraft:light[level=12]
setblock 426 276 245 minecraft:light[level=12]
setblock 426 276 252 minecraft:light[level=12]
setblock 426 276 259 minecraft:light[level=12]
setblock 426 276 266 minecraft:light[level=12]
fill 427 276 244 430 277 244 minecraft:sea_lantern
setblock 427 276 245 minecraft:blue_stained_glass
setblock 427 276 246 minecraft:black_stained_glass
fill 427 276 247 427 276 248 minecraft:blue_stained_glass
setblock 427 276 249 minecraft:black_stained_glass
fill 427 276 250 427 276 251 minecraft:blue_stained_glass
setblock 427 276 252 minecraft:black_stained_glass
setblock 427 276 253 minecraft:blue_stained_glass
fill 427 276 254 430 277 254 minecraft:white_concrete
fill 428 276 242 430 277 242 minecraft:white_concrete
fill 428 276 243 428 277 243 minecraft:sea_lantern
fill 428 276 245 428 278 246 minecraft:white_concrete
fill 428 276 247 429 277 249 minecraft:sea_lantern
fill 428 276 250 429 278 251 minecraft:white_concrete
fill 428 276 252 428 277 253 minecraft:sea_lantern
fill 428 276 255 428 278 255 minecraft:white_concrete
fill 428 276 256 430 277 256 minecraft:sea_lantern
fill 429 276 240 430 277 241 minecraft:sea_lantern
fill 429 276 243 430 278 243 minecraft:white_concrete
fill 429 276 245 431 277 245 minecraft:sea_lantern
fill 429 276 246 431 277 246 minecraft:white_concrete
fill 429 276 252 431 277 252 minecraft:sea_lantern
fill 429 276 253 431 277 253 minecraft:white_concrete
fill 429 276 255 432 277 255 minecraft:sea_lantern
fill 429 276 257 430 277 258 minecraft:white_concrete
fill 430 276 239 432 278 239 minecraft:white_concrete
fill 430 276 247 430 278 247 minecraft:white_concrete
fill 430 276 248 430 277 249 minecraft:sea_lantern
fill 430 276 250 430 278 250 minecraft:white_concrete
fill 430 276 251 430 277 251 minecraft:sea_lantern
fill 430 276 259 432 277 259 minecraft:sea_lantern
fill 431 276 237 432 277 238 minecraft:sea_lantern
fill 431 276 240 433 278 240 minecraft:white_concrete
fill 431 276 241 431 277 242 minecraft:sea_lantern
fill 431 276 254 431 277 254 minecraft:sea_lantern
fill 431 276 256 431 278 257 minecraft:white_concrete
fill 431 276 258 433 277 258 minecraft:sea_lantern
fill 431 276 260 432 277 261 minecraft:white_concrete
setblock 431 276 270 minecraft:ochre_froglight
fill 432 276 236 434 277 236 minecraft:white_concrete
fill 432 276 241 433 277 241 minecraft:white_concrete
fill 432 276 242 432 277 242 minecraft:sea_lantern
fill 432 276 243 432 277 243 minecraft:white_concrete
fill 432 276 256 432 278 256 minecraft:white_concrete
fill 432 276 257 433 277 257 minecraft:sea_lantern
fill 432 276 262 434 277 262 minecraft:sea_lantern
setblock 433 276 231 minecraft:light[level=12]
fill 433 276 237 434 278 237 minecraft:white_concrete
fill 433 276 238 434 277 239 minecraft:light_gray_concrete
setblock 433 276 245 minecraft:light[level=12]
setblock 433 276 252 minecraft:light[level=12]
fill 433 276 259 434 277 260 minecraft:light_gray_concrete
fill 433 276 261 434 277 261 minecraft:sea_lantern
setblock 433 276 266 minecraft:light[level=12]
fill 434 276 235 435 277 235 minecraft:sea_lantern
fill 434 276 240 436 277 240 minecraft:light_gray_concrete
fill 434 276 258 436 277 258 minecraft:light_gray_concrete
fill 434 276 263 435 278 263 minecraft:white_concrete
fill 435 276 234 435 277 234 minecraft:sea_lantern
fill 435 276 236 436 277 237 minecraft:sea_lantern
fill 435 276 238 435 278 238 minecraft:white_concrete
fill 435 276 239 435 277 239 minecraft:light_gray_concrete
fill 435 276 241 437 277 241 minecraft:light_gray_concrete
fill 435 276 257 437 277 257 minecraft:light_gray_concrete
fill 435 276 259 435 277 259 minecraft:light_gray_concrete
fill 435 276 260 435 277 260 minecraft:sea_lantern
fill 435 276 261 436 278 262 minecraft:white_concrete
fill 435 276 264 435 277 264 minecraft:white_concrete
fill 436 276 234 437 278 235 minecraft:white_concrete
fill 436 276 238 436 277 238 minecraft:sea_lantern
fill 436 276 242 438 277 242 minecraft:light_gray_concrete
fill 436 276 256 438 277 256 minecraft:light_gray_concrete
fill 436 276 260 436 277 260 minecraft:white_concrete
fill 436 276 263 437 277 264 minecraft:sea_lantern
fill 437 276 233 438 277 233 minecraft:sea_lantern
fill 437 276 236 438 277 237 minecraft:white_concrete
fill 437 276 243 439 277 243 minecraft:light_gray_concrete
fill 437 276 247 437 276 251 minecraft:light_blue_stained_glass
fill 437 276 255 439 277 255 minecraft:light_gray_concrete
fill 437 276 261 438 277 262 minecraft:sea_lantern
fill 437 276 265 438 277 265 minecraft:white_concrete
fill 438 276 234 439 277 235 minecraft:sea_lantern
fill 438 276 244 440 277 244 minecraft:light_gray_concrete
fill 438 276 245 438 276 246 minecraft:light_blue_stained_glass
fill 438 276 247 438 278 251 minecraft:white_concrete
fill 438 276 252 438 276 253 minecraft:light_blue_stained_glass
fill 438 276 254 440 277 254 minecraft:light_gray_concrete
fill 438 276 263 439 278 264 minecraft:white_concrete
fill 439 276 232 439 277 233 minecraft:white_concrete
fill 439 276 236 439 277 236 minecraft:sea_lantern
fill 439 276 245 439 277 245 minecraft:light_gray_concrete
fill 439 276 246 439 278 246 minecraft:white_concrete
fill 439 276 252 449 278 252 minecraft:white_concrete
fill 439 276 253 439 277 253 minecraft:light_gray_concrete
fill 439 276 262 439 278 262 minecraft:white_concrete
fill 439 276 265 440 277 266 minecraft:sea_lantern
setblock 440 276 231 minecraft:light[level=12]
setblock 440 276 232 minecraft:blue_stained_glass
fill 440 276 233 440 277 236 minecraft:white_concrete
setblock 440 276 238 minecraft:light[level=12]
fill 440 276 243 441 276 243 minecraft:light_blue_stained_glass
fill 440 276 253 448 278 253 minecraft:white_concrete
fill 440 276 255 441 276 255 minecraft:light_blue_stained_glass
setblock 440 276 259 minecraft:light[level=12]
fill 440 276 262 440 277 264 minecraft:sea_lantern
setblock 440 276 267 minecraft:blue_stained_glass
setblock 441 276 232 minecraft:black_stained_glass
fill 441 276 233 442 277 234 minecraft:sea_lantern
fill 441 276 235 441 277 236 minecraft:white_concrete
fill 441 276 244 441 278 244 minecraft:white_concrete
fill 441 276 254 447 278 254 minecraft:white_concrete
fill 441 276 262 441 277 263 minecraft:sea_lantern
fill 441 276 264 442 277 266 minecraft:white_concrete
setblock 441 276 267 minecraft:black_stained_glass
fill 442 276 232 443 276 232 minecraft:blue_stained_glass
fill 442 276 235 442 277 235 minecraft:sea_lantern
fill 442 276 242 446 276 242 minecraft:light_blue_stained_glass
fill 442 276 243 446 278 243 minecraft:white_concrete
fill 442 276 251 450 278 251 minecraft:white_concrete
fill 442 276 255 446 278 255 minecraft:white_concrete
fill 442 276 256 446 276 256 minecraft:light_blue_stained_glass
fill 442 276 263 442 278 263 minecraft:white_concrete
fill 442 276 267 443 276 267 minecraft:blue_stained_glass
fill 443 276 233 444 278 235 minecraft:white_concrete
fill 443 276 244 447 278 244 minecraft:white_concrete
fill 443 276 250 450 278 250 minecraft:white_concrete
fill 443 276 263 444 277 266 minecraft:sea_lantern
setblock 443 276 270 minecraft:white_concrete
setblock 444 276 228 minecraft:purple_terracotta
fill 444 276 231 446 278 231 minecraft:gold_block
setblock 444 276 232 minecraft:black_stained_glass
setblock 444 276 267 minecraft:black_stained_glass
fill 445 276 232 446 276 232 minecraft:blue_stained_glass
fill 445 276 233 445 277 235 minecraft:sea_lantern
fill 445 276 245 448 278 246 minecraft:white_concrete
fill 445 276 248 450 278 249 minecraft:white_concrete
fill 445 276 263 445 278 266 minecraft:white_concrete
fill 445 276 267 446 276 267 minecraft:blue_stained_glass
fill 446 276 233 446 277 233 minecraft:sea_lantern
fill 446 276 234 447 278 235 minecraft:white_concrete
fill 446 276 247 450 278 247 minecraft:white_concrete
fill 446 276 263 447 277 264 minecraft:sea_lantern
fill 446 276 265 446 278 266 minecraft:white_concrete
setblock 447 276 231 minecraft:light[level=12]
setblock 447 276 232 minecraft:black_stained_glass
fill 447 276 233 447 278 233 minecraft:white_concrete
fill 447 276 236 447 277 236 minecraft:white_concrete
setblock 447 276 238 minecraft:light[level=12]
fill 447 276 243 448 276 243 minecraft:light_blue_stained_glass
fill 447 276 255 448 276 255 minecraft:light_blue_stained_glass
setblock 447 276 259 minecraft:light[level=12]
fill 447 276 262 447 277 262 minecraft:sea_lantern
fill 447 276 265 447 277 266 minecraft:sea_lantern
setblock 447 276 267 minecraft:black_stained_glass
setblock 448 276 232 minecraft:blue_stained_glass
fill 448 276 233 448 277 236 minecraft:sea_lantern
fill 448 276 244 450 277 244 minecraft:light_gray_concrete
fill 448 276 254 450 277 254 minecraft:light_gray_concrete
fill 448 276 262 448 277 265 minecraft:white_concrete
fill 448 276 266 448 277 266 minecraft:sea_lantern
setblock 448 276 267 minecraft:blue_stained_glass
fill 449 276 232 449 277 235 minecraft:sea_lantern
fill 449 276 236 450 278 236 minecraft:white_concrete
fill 449 276 243 451 277 243 minecraft:light_gray_concrete
fill 449 276 245 449 277 245 minecraft:light_gray_concrete
fill 449 276 246 449 278 246 minecraft:white_concrete
fill 449 276 253 449 277 253 minecraft:light_gray_concrete
fill 449 276 255 451 277 255 minecraft:light_gray_concrete
fill 449 276 262 450 277 262 minecraft:sea_lantern
fill 449 276 263 449 277 266 minecraft:white_concrete
fill 450 276 233 450 278 235 minecraft:white_concrete
fill 450 276 237 451 277 237 minecraft:sea_lantern
fill 450 276 242 452 277 242 minecraft:light_gray_concrete
fill 450 276 245 450 276 246 minecraft:light_blue_stained_glass
fill 450 276 252 450 276 253 minecraft:light_blue_stained_glass
fill 450 276 256 452 277 256 minecraft:light_gray_concrete
fill 450 276 261 451 277 261 minecraft:white_concrete
fill 450 276 263 450 277 265 minecraft:sea_lantern
fill 451 276 233 451 277 234 minecraft:white_concrete
fill 451 276 235 452 277 236 minecraft:sea_lantern
fill 451 276 241 453 277 241 minecraft:light_gray_concrete
fill 451 276 247 451 276 251 minecraft:light_blue_stained_glass
fill 451 276 257 453 277 257 minecraft:light_gray_concrete
fill 451 276 262 452 278 263 minecraft:white_concrete
fill 451 276 264 451 277 265 minecraft:sea_lantern
fill 452 276 234 453 277 234 minecraft:sea_lantern
fill 452 276 237 452 277 238 minecraft:white_concrete
fill 452 276 240 454 277 240 minecraft:light_gray_concrete
fill 452 276 258 454 277 258 minecraft:light_gray_concrete
fill 452 276 260 452 277 261 minecraft:sea_lantern
fill 452 276 264 453 277 264 minecraft:white_concrete
fill 453 276 235 453 278 237 minecraft:white_concrete
fill 453 276 238 453 277 238 minecraft:sea_lantern
fill 453 276 239 455 277 239 minecraft:light_gray_concrete
fill 453 276 259 455 277 259 minecraft:light_gray_concrete
fill 453 276 260 453 278 260 minecraft:white_concrete
fill 453 276 261 453 277 263 minecraft:sea_lantern
setblock 454 276 231 minecraft:light[level=12]
fill 454 276 235 454 278 236 minecraft:white_concrete
fill 454 276 237 456 277 237 minecraft:sea_lantern
fill 454 276 238 455 277 238 minecraft:light_gray_concrete
setblock 454 276 245 minecraft:light[level=12]
setblock 454 276 252 minecraft:light[level=12]
fill 454 276 260 455 277 260 minecraft:light_gray_concrete
fill 454 276 261 456 278 261 minecraft:white_concrete
fill 454 276 262 454 277 263 minecraft:sea_lantern
setblock 454 276 266 minecraft:light[level=12]
fill 455 276 236 456 277 236 minecraft:sea_lantern
fill 455 276 240 455 278 240 minecraft:white_concrete
fill 455 276 241 456 277 241 minecraft:sea_lantern
fill 455 276 257 456 277 257 minecraft:white_concrete
fill 455 276 258 455 277 258 minecraft:sea_lantern
fill 455 276 262 456 277 262 minecraft:white_concrete
fill 456 276 238 456 278 239 minecraft:white_concrete
fill 456 276 240 458 277 240 minecraft:sea_lantern
fill 456 276 242 456 277 243 minecraft:white_concrete
fill 456 276 255 456 277 256 minecraft:sea_lantern
fill 456 276 258 458 278 258 minecraft:white_concrete
fill 456 276 259 456 277 260 minecraft:sea_lantern
fill 457 276 237 457 277 238 minecraft:white_concrete
fill 457 276 239 458 277 239 minecraft:sea_lantern
fill 457 276 241 458 278 242 minecraft:white_concrete
fill 457 276 243 458 277 244 minecraft:sea_lantern
fill 457 276 245 457 277 246 minecraft:white_concrete
fill 457 276 252 457 277 253 minecraft:sea_lantern
fill 457 276 254 458 278 255 minecraft:white_concrete
fill 457 276 256 458 277 257 minecraft:sea_lantern
fill 457 276 259 458 278 259 minecraft:white_concrete
fill 457 276 260 457 277 261 minecraft:sea_lantern
fill 458 276 245 461 277 245 minecraft:white_concrete
fill 458 276 246 461 277 247 minecraft:sea_lantern
fill 458 276 248 461 278 248 minecraft:white_concrete
fill 458 276 249 461 277 250 minecraft:sea_lantern
fill 458 276 251 461 277 252 minecraft:white_concrete
fill 458 276 253 461 277 253 minecraft:sea_lantern
fill 459 276 240 459 277 241 minecraft:white_concrete
fill 459 276 242 460 277 243 minecraft:sea_lantern
fill 459 276 244 461 277 244 minecraft:white_concrete
fill 459 276 254 461 277 254 minecraft:sea_lantern
fill 459 276 255 460 277 256 minecraft:white_concrete
fill 459 276 257 459 277 258 minecraft:sea_lantern
fill 460 276 270 460 308 270 minecraft:black_concrete
setblock 461 276 231 minecraft:light[level=12]
setblock 461 276 238 minecraft:light[level=12]
setblock 461 276 259 minecraft:light[level=12]
setblock 461 276 266 minecraft:light[level=12]
setblock 462 276 245 minecraft:blue_stained_glass
setblock 462 276 246 minecraft:black_stained_glass
fill 462 276 247 462 276 248 minecraft:blue_stained_glass
setblock 462 276 249 minecraft:black_stained_glass
fill 462 276 250 462 276 251 minecraft:blue_stained_glass
setblock 462 276 252 minecraft:black_stained_glass
setblock 462 276 253 minecraft:blue_stained_glass
setblock 465 276 238 minecraft:pearlescent_froglight
setblock 465 276 245 minecraft:purple_terracotta
fill 465 276 250 465 308 250 minecraft:black_concrete
setblock 465 276 261 minecraft:sea_lantern
fill 423 277 233 423 278 233 minecraft:black_concrete
setblock 423 277 265 minecraft:pearlescent_froglight
fill 427 277 245 427 277 246 minecraft:white_concrete
fill 427 277 247 427 277 249 minecraft:sea_lantern
fill 427 277 250 427 277 251 minecraft:white_concrete
fill 427 277 252 427 277 253 minecraft:sea_lantern
setblock 428 277 270 minecraft:blue_concrete
fill 431 277 270 431 279 270 minecraft:black_concrete
setblock 432 277 270 minecraft:white_concrete
setblock 433 277 270 minecraft:pearlescent_froglight
fill 437 277 247 437 277 251 minecraft:white_concrete
fill 438 277 245 438 277 246 minecraft:white_concrete
fill 438 277 252 438 277 253 minecraft:white_concrete
fill 439 277 231 443 277 231 minecraft:blue_stained_glass
setblock 440 277 232 minecraft:white_concrete
fill 440 277 243 441 277 243 minecraft:white_concrete
fill 440 277 255 441 277 255 minecraft:white_concrete
fill 441 277 232 442 277 232 minecraft:sea_lantern
fill 442 277 242 446 277 242 minecraft:white_concrete
fill 442 277 256 446 277 256 minecraft:white_concrete
fill 443 277 232 444 277 232 minecraft:white_concrete
fill 443 277 270 443 308 270 minecraft:black_concrete
fill 444 277 228 444 303 228 minecraft:black_concrete
fill 445 277 232 446 277 232 minecraft:sea_lantern
setblock 446 277 270 minecraft:sea_lantern
fill 447 277 231 451 277 231 minecraft:blue_stained_glass
fill 447 277 232 448 277 232 minecraft:white_concrete
fill 447 277 243 448 277 243 minecraft:white_concrete
fill 447 277 255 448 277 255 minecraft:white_concrete
fill 450 277 232 451 277 232 minecraft:blue_stained_glass
fill 450 277 245 450 277 246 minecraft:white_concrete
fill 450 277 252 450 277 253 minecraft:white_concrete
fill 451 277 247 451 277 251 minecraft:white_concrete
fill 465 277 238 465 305 238 minecraft:black_concrete
fill 465 277 245 465 283 245 minecraft:black_concrete
fill 465 277 261 465 308 261 minecraft:black_concrete
setblock 465 277 263 minecraft:white_concrete
fill 423 278 265 423 300 265 minecraft:black_concrete
setblock 426 278 228 minecraft:white_concrete
schedule function dropper:buildpart/57_4 1t
