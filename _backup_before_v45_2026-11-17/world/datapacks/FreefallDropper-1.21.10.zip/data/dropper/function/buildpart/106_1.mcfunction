setblock 505 0 451 minecraft:light[level=14]
fill 505 0 457 507 0 457 minecraft:red_nether_bricks
fill 506 0 458 506 5 458 minecraft:blackstone
fill 507 0 417 509 0 417 minecraft:red_nether_bricks
fill 509 0 457 511 0 457 minecraft:red_nether_bricks
fill 511 0 416 512 5 416 minecraft:blackstone
fill 511 0 417 511 0 419 minecraft:red_nether_bricks
fill 511 0 421 511 0 423 minecraft:red_nether_bricks
fill 511 0 425 511 0 427 minecraft:red_nether_bricks
fill 511 0 429 511 0 431 minecraft:red_nether_bricks
fill 511 0 433 511 0 435 minecraft:red_nether_bricks
fill 511 0 437 511 0 439 minecraft:red_nether_bricks
fill 511 0 441 511 0 443 minecraft:red_nether_bricks
fill 511 0 445 511 0 447 minecraft:red_nether_bricks
fill 511 0 449 511 0 451 minecraft:red_nether_bricks
fill 511 0 453 511 0 455 minecraft:red_nether_bricks
fill 512 0 417 512 0 418 minecraft:orange_concrete
fill 512 0 419 512 5 419 minecraft:blackstone
fill 512 0 427 512 5 428 minecraft:blackstone
fill 512 0 429 512 1 430 minecraft:orange_concrete
fill 512 0 436 512 5 436 minecraft:blackstone
setblock 512 0 438 minecraft:orange_concrete
fill 512 0 439 512 5 440 minecraft:blackstone
fill 512 0 441 512 1 441 minecraft:orange_concrete
fill 512 0 447 512 5 448 minecraft:blackstone
fill 512 0 449 512 0 450 minecraft:orange_concrete
fill 512 0 458 512 1 458 minecraft:orange_concrete
fill 470 1 420 470 4 420 minecraft:blackstone
setblock 470 1 425 minecraft:orange_concrete
setblock 470 1 436 minecraft:orange_concrete
fill 470 1 440 470 4 441 minecraft:blackstone
fill 470 1 456 470 1 457 minecraft:orange_concrete
setblock 472 1 458 minecraft:orange_concrete
fill 473 1 458 473 4 458 minecraft:blackstone
fill 481 1 416 482 4 416 minecraft:blackstone
fill 484 1 458 484 4 458 minecraft:blackstone
setblock 486 1 416 minecraft:orange_concrete
fill 488 1 458 488 3 458 minecraft:blackstone
setblock 489 1 458 minecraft:orange_concrete
setblock 497 1 416 minecraft:orange_concrete
setblock 500 1 458 minecraft:orange_concrete
fill 502 1 416 502 4 416 minecraft:blackstone
fill 504 1 458 505 4 458 minecraft:blackstone
fill 512 1 417 512 4 417 minecraft:blackstone
setblock 512 1 418 minecraft:orange_concrete
fill 512 1 421 512 1 422 minecraft:orange_concrete
fill 512 1 438 512 4 438 minecraft:blackstone
setblock 512 1 442 minecraft:orange_concrete
fill 512 1 449 512 4 449 minecraft:blackstone
setblock 512 1 450 minecraft:orange_concrete
setblock 512 1 453 minecraft:orange_concrete
fill 470 2 416 470 7 417 minecraft:blackstone
fill 470 2 425 470 7 425 minecraft:blackstone
fill 470 2 426 470 2 427 minecraft:orange_concrete
fill 470 2 428 470 7 429 minecraft:blackstone
fill 470 2 434 470 3 435 minecraft:orange_concrete
fill 470 2 436 470 7 437 minecraft:blackstone
setblock 470 2 438 minecraft:orange_concrete
fill 470 2 446 470 3 447 minecraft:orange_concrete
fill 470 2 448 470 7 449 minecraft:blackstone
fill 470 2 455 470 3 455 minecraft:orange_concrete
fill 470 2 456 470 3 457 minecraft:blackstone
fill 470 2 458 471 2 458 minecraft:orange_concrete
fill 472 2 458 472 7 458 minecraft:blackstone
fill 473 2 416 474 7 416 minecraft:blackstone
fill 475 2 416 476 3 416 minecraft:orange_concrete
fill 478 2 458 479 3 458 minecraft:orange_concrete
fill 480 2 458 481 7 458 minecraft:blackstone
setblock 484 2 416 minecraft:orange_concrete
fill 485 2 416 486 7 416 minecraft:blackstone
fill 487 2 416 488 3 416 minecraft:orange_concrete
fill 489 2 458 489 7 458 minecraft:blackstone
fill 490 2 458 491 2 458 minecraft:orange_concrete
fill 492 2 458 493 7 458 minecraft:blackstone
fill 493 2 416 494 7 416 minecraft:blackstone
fill 495 2 416 496 2 416 minecraft:orange_concrete
fill 497 2 416 497 7 416 minecraft:blackstone
fill 498 2 458 499 3 458 minecraft:orange_concrete
fill 500 2 458 501 7 458 minecraft:blackstone
setblock 502 2 458 minecraft:orange_concrete
fill 505 2 416 506 7 416 minecraft:blackstone
fill 507 2 416 508 3 416 minecraft:orange_concrete
fill 510 2 458 511 3 458 minecraft:orange_concrete
fill 512 2 418 512 7 418 minecraft:blackstone
setblock 512 2 420 minecraft:orange_concrete
fill 512 2 421 512 7 422 minecraft:blackstone
fill 512 2 423 512 3 423 minecraft:orange_concrete
fill 512 2 429 512 7 430 minecraft:blackstone
fill 512 2 431 512 2 432 minecraft:orange_concrete
fill 512 2 441 512 7 442 minecraft:blackstone
fill 512 2 443 512 3 444 minecraft:orange_concrete
fill 512 2 450 512 7 450 minecraft:blackstone
fill 512 2 451 512 2 452 minecraft:orange_concrete
fill 512 2 453 512 7 453 minecraft:blackstone
fill 512 2 455 512 3 455 minecraft:orange_concrete
fill 512 2 458 512 7 458 minecraft:blackstone
fill 470 3 422 470 3 423 minecraft:orange_concrete
setblock 470 3 426 minecraft:orange_concrete
fill 470 3 427 470 6 427 minecraft:blackstone
fill 470 3 438 470 6 438 minecraft:blackstone
setblock 470 3 443 minecraft:orange_concrete
setblock 470 3 454 minecraft:orange_concrete
fill 470 3 458 471 5 458 minecraft:blackstone
setblock 479 3 416 minecraft:orange_concrete
fill 484 3 416 484 6 416 minecraft:blackstone
fill 486 3 458 487 3 458 minecraft:orange_concrete
setblock 490 3 458 minecraft:orange_concrete
fill 491 3 458 491 6 458 minecraft:blackstone
fill 495 3 416 495 6 416 minecraft:blackstone
setblock 496 3 416 minecraft:orange_concrete
fill 499 3 416 500 3 416 minecraft:orange_concrete
fill 502 3 458 502 6 458 minecraft:blackstone
setblock 507 3 458 minecraft:orange_concrete
fill 512 3 420 512 6 420 minecraft:blackstone
setblock 512 3 424 minecraft:orange_concrete
fill 512 3 431 512 6 431 minecraft:blackstone
setblock 512 3 432 minecraft:orange_concrete
setblock 512 3 435 minecraft:orange_concrete
fill 512 3 451 512 6 452 minecraft:blackstone
setblock 512 3 456 minecraft:orange_concrete
fill 470 4 421 470 5 421 minecraft:orange_concrete
fill 470 4 422 470 9 423 minecraft:blackstone
setblock 470 4 424 minecraft:orange_concrete
fill 470 4 426 470 9 426 minecraft:blackstone
fill 470 4 432 470 5 433 minecraft:orange_concrete
fill 470 4 434 470 9 435 minecraft:blackstone
fill 470 4 443 470 9 443 minecraft:blackstone
fill 470 4 444 470 4 445 minecraft:orange_concrete
fill 470 4 446 470 6 447 minecraft:blackstone
fill 470 4 452 470 5 453 minecraft:orange_concrete
fill 470 4 454 470 9 455 minecraft:blackstone
setblock 470 4 456 minecraft:orange_concrete
fill 470 4 457 470 7 457 minecraft:blackstone
fill 475 4 416 476 9 416 minecraft:blackstone
fill 476 4 458 477 5 458 minecraft:orange_concrete
fill 477 4 416 478 4 416 minecraft:orange_concrete
fill 478 4 458 479 9 458 minecraft:blackstone
fill 479 4 416 479 9 416 minecraft:blackstone
fill 485 4 458 485 5 458 minecraft:orange_concrete
fill 486 4 458 487 9 458 minecraft:blackstone
fill 487 4 416 488 9 416 minecraft:blackstone
setblock 488 4 458 minecraft:orange_concrete
fill 489 4 416 490 5 416 minecraft:orange_concrete
fill 490 4 458 490 9 458 minecraft:blackstone
fill 496 4 416 496 9 416 minecraft:blackstone
fill 496 4 458 497 5 458 minecraft:orange_concrete
setblock 498 4 416 minecraft:orange_concrete
fill 498 4 458 499 9 458 minecraft:blackstone
fill 499 4 416 500 9 416 minecraft:blackstone
fill 501 4 416 501 5 416 minecraft:orange_concrete
fill 507 4 416 508 9 416 minecraft:blackstone
fill 507 4 458 507 9 458 minecraft:blackstone
fill 508 4 458 509 4 458 minecraft:orange_concrete
fill 509 4 416 510 4 416 minecraft:orange_concrete
fill 510 4 458 511 9 458 minecraft:blackstone
fill 512 4 423 512 9 424 minecraft:blackstone
fill 512 4 425 512 5 426 minecraft:orange_concrete
fill 512 4 432 512 9 432 minecraft:blackstone
fill 512 4 433 512 4 434 minecraft:orange_concrete
fill 512 4 435 512 9 435 minecraft:blackstone
fill 512 4 437 512 5 437 minecraft:orange_concrete
fill 512 4 443 512 9 444 minecraft:blackstone
fill 512 4 445 512 5 446 minecraft:orange_concrete
setblock 512 4 454 minecraft:orange_concrete
fill 512 4 455 512 9 456 minecraft:blackstone
fill 512 4 457 512 5 457 minecraft:orange_concrete
setblock 470 5 420 minecraft:orange_concrete
fill 470 5 424 470 8 424 minecraft:blackstone
fill 470 5 440 470 5 441 minecraft:orange_concrete
setblock 470 5 444 minecraft:orange_concrete
fill 470 5 445 470 8 445 minecraft:blackstone
fill 470 5 456 470 7 456 minecraft:blackstone
setblock 473 5 458 minecraft:orange_concrete
fill 477 5 416 477 8 416 minecraft:blackstone
setblock 478 5 416 minecraft:orange_concrete
fill 481 5 416 482 5 416 minecraft:orange_concrete
setblock 484 5 458 minecraft:orange_concrete
fill 488 5 458 488 8 458 minecraft:blackstone
fill 498 5 416 498 8 416 minecraft:blackstone
setblock 502 5 416 minecraft:orange_concrete
fill 504 5 458 505 5 458 minecraft:orange_concrete
setblock 508 5 458 minecraft:orange_concrete
fill 509 5 416 509 8 416 minecraft:blackstone
fill 509 5 458 509 8 458 minecraft:blackstone
setblock 510 5 416 minecraft:orange_concrete
setblock 512 5 417 minecraft:orange_concrete
fill 512 5 433 512 8 434 minecraft:blackstone
setblock 512 5 438 minecraft:orange_concrete
setblock 512 5 449 minecraft:orange_concrete
fill 512 5 454 512 8 454 minecraft:blackstone
fill 470 6 418 470 7 419 minecraft:orange_concrete
fill 470 6 420 470 11 421 minecraft:blackstone
fill 470 6 430 470 6 431 minecraft:orange_concrete
fill 470 6 432 470 11 433 minecraft:blackstone
fill 470 6 439 470 7 439 minecraft:orange_concrete
fill 470 6 440 470 11 441 minecraft:blackstone
setblock 470 6 442 minecraft:orange_concrete
fill 470 6 444 470 8 444 minecraft:blackstone
fill 470 6 450 470 7 451 minecraft:orange_concrete
fill 470 6 452 470 11 453 minecraft:blackstone
setblock 470 6 458 minecraft:blackstone
fill 471 6 416 472 7 416 minecraft:orange_concrete
fill 471 6 417 473 6 417 minecraft:red_nether_bricks
fill 471 6 419 471 6 421 minecraft:red_nether_bricks
fill 471 6 423 471 6 425 minecraft:red_nether_bricks
fill 471 6 427 471 6 429 minecraft:red_nether_bricks
fill 471 6 431 471 6 433 minecraft:red_nether_bricks
fill 471 6 435 471 6 437 minecraft:red_nether_bricks
fill 471 6 439 471 6 441 minecraft:red_nether_bricks
fill 471 6 443 471 6 445 minecraft:red_nether_bricks
fill 471 6 447 471 6 449 minecraft:red_nether_bricks
fill 471 6 451 471 6 453 minecraft:red_nether_bricks
fill 471 6 455 471 6 457 minecraft:red_nether_bricks
fill 471 6 458 471 7 458 minecraft:orange_concrete
fill 473 6 457 475 6 457 minecraft:red_nether_bricks
fill 473 6 458 473 11 458 minecraft:blackstone
fill 474 6 458 475 6 458 minecraft:orange_concrete
fill 475 6 417 477 6 417 minecraft:red_nether_bricks
fill 476 6 458 477 8 458 minecraft:blackstone
fill 477 6 457 479 6 457 minecraft:red_nether_bricks
fill 478 6 416 478 11 416 minecraft:blackstone
fill 479 6 417 481 6 417 minecraft:red_nether_bricks
setblock 480 6 416 minecraft:orange_concrete
fill 481 6 416 482 11 416 minecraft:blackstone
fill 481 6 457 483 6 457 minecraft:red_nether_bricks
fill 482 6 458 483 7 458 minecraft:orange_concrete
fill 483 6 416 483 7 416 minecraft:orange_concrete
fill 483 6 417 485 6 417 minecraft:red_nether_bricks
fill 484 6 458 485 11 458 minecraft:blackstone
fill 485 6 457 487 6 457 minecraft:red_nether_bricks
fill 487 6 417 489 6 417 minecraft:red_nether_bricks
fill 489 6 416 490 11 416 minecraft:blackstone
fill 489 6 457 491 6 457 minecraft:red_nether_bricks
fill 491 6 416 492 6 416 minecraft:orange_concrete
fill 491 6 417 493 6 417 minecraft:red_nether_bricks
fill 493 6 457 495 6 457 minecraft:red_nether_bricks
fill 494 6 458 495 6 458 minecraft:orange_concrete
fill 495 6 417 497 6 417 minecraft:red_nether_bricks
fill 496 6 458 497 11 458 minecraft:blackstone
fill 497 6 457 499 6 457 minecraft:red_nether_bricks
fill 499 6 417 501 6 417 minecraft:red_nether_bricks
fill 501 6 416 502 11 416 minecraft:blackstone
fill 501 6 457 503 6 457 minecraft:red_nether_bricks
fill 503 6 416 504 7 416 minecraft:orange_concrete
fill 503 6 417 505 6 417 minecraft:red_nether_bricks
fill 503 6 458 503 7 458 minecraft:orange_concrete
fill 504 6 458 505 11 458 minecraft:blackstone
fill 505 6 457 507 6 457 minecraft:red_nether_bricks
setblock 506 6 458 minecraft:orange_concrete
fill 507 6 417 509 6 417 minecraft:red_nether_bricks
fill 508 6 458 508 11 458 minecraft:blackstone
fill 509 6 457 511 6 457 minecraft:red_nether_bricks
fill 510 6 416 510 11 416 minecraft:blackstone
fill 511 6 416 512 6 416 minecraft:orange_concrete
fill 511 6 417 511 6 419 minecraft:red_nether_bricks
fill 511 6 421 511 6 423 minecraft:red_nether_bricks
fill 511 6 425 511 6 427 minecraft:red_nether_bricks
fill 511 6 429 511 6 431 minecraft:red_nether_bricks
fill 511 6 433 511 6 435 minecraft:red_nether_bricks
fill 511 6 437 511 6 439 minecraft:red_nether_bricks
fill 511 6 441 511 6 443 minecraft:red_nether_bricks
fill 511 6 445 511 6 447 minecraft:red_nether_bricks
fill 511 6 449 511 6 451 minecraft:red_nether_bricks
fill 511 6 453 511 6 455 minecraft:red_nether_bricks
fill 512 6 417 512 11 417 minecraft:blackstone
fill 512 6 419 512 7 419 minecraft:orange_concrete
fill 512 6 425 512 11 426 minecraft:blackstone
fill 512 6 427 512 7 428 minecraft:orange_concrete
setblock 512 6 436 minecraft:orange_concrete
fill 512 6 437 512 11 438 minecraft:blackstone
fill 512 6 439 512 7 440 minecraft:orange_concrete
fill 512 6 445 512 11 446 minecraft:blackstone
fill 512 6 447 512 6 448 minecraft:orange_concrete
fill 512 6 449 512 11 449 minecraft:blackstone
fill 512 6 457 512 11 457 minecraft:blackstone
setblock 470 7 427 minecraft:orange_concrete
setblock 470 7 430 minecraft:orange_concrete
fill 470 7 431 470 10 431 minecraft:blackstone
setblock 470 7 438 minecraft:orange_concrete
fill 470 7 442 470 10 442 minecraft:blackstone
fill 470 7 446 470 9 446 minecraft:blackstone
setblock 470 7 447 minecraft:orange_concrete
setblock 470 7 458 minecraft:orange_concrete
setblock 474 7 458 minecraft:orange_concrete
fill 475 7 458 475 10 458 minecraft:blackstone
fill 480 7 416 480 10 416 minecraft:blackstone
setblock 484 7 416 minecraft:orange_concrete
fill 491 7 416 491 10 416 minecraft:blackstone
setblock 491 7 458 minecraft:orange_concrete
setblock 492 7 416 minecraft:orange_concrete
setblock 494 7 458 minecraft:orange_concrete
setblock 495 7 416 minecraft:orange_concrete
fill 495 7 458 495 10 458 minecraft:blackstone
setblock 502 7 458 minecraft:orange_concrete
fill 506 7 458 506 10 458 minecraft:blackstone
fill 511 7 416 512 10 416 minecraft:blackstone
setblock 512 7 420 minecraft:orange_concrete
setblock 512 7 431 minecraft:orange_concrete
fill 512 7 436 512 10 436 minecraft:blackstone
fill 512 7 447 512 10 447 minecraft:blackstone
setblock 512 7 448 minecraft:orange_concrete
fill 512 7 451 512 7 452 minecraft:orange_concrete
fill 470 8 416 470 9 417 minecraft:orange_concrete
fill 470 8 418 470 13 419 minecraft:blackstone
fill 470 8 425 470 9 425 minecraft:orange_concrete
fill 470 8 427 470 13 427 minecraft:blackstone
fill 470 8 428 470 8 429 minecraft:orange_concrete
fill 470 8 430 470 13 430 minecraft:blackstone
fill 470 8 436 470 9 437 minecraft:orange_concrete
fill 470 8 438 470 13 439 minecraft:blackstone
fill 470 8 447 470 9 447 minecraft:blackstone
fill 470 8 448 470 8 449 minecraft:orange_concrete
fill 470 8 450 470 13 451 minecraft:blackstone
fill 470 8 456 470 9 457 minecraft:orange_concrete
fill 470 8 458 471 13 458 minecraft:blackstone
fill 471 8 416 472 13 416 minecraft:blackstone
setblock 472 8 458 minecraft:orange_concrete
fill 473 8 416 474 8 416 minecraft:orange_concrete
setblock 473 8 419 minecraft:light[level=14]
setblock 473 8 427 minecraft:light[level=14]
setblock 473 8 435 minecraft:light[level=14]
setblock 473 8 443 minecraft:light[level=14]
setblock 473 8 451 minecraft:light[level=14]
fill 474 8 458 474 10 458 minecraft:blackstone
fill 480 8 458 481 9 458 minecraft:orange_concrete
setblock 481 8 419 minecraft:light[level=14]
setblock 481 8 427 minecraft:light[level=14]
setblock 481 8 435 minecraft:light[level=14]
setblock 481 8 443 minecraft:light[level=14]
setblock 481 8 451 minecraft:light[level=14]
fill 482 8 458 483 13 458 minecraft:blackstone
fill 483 8 416 484 13 416 minecraft:blackstone
fill 485 8 416 486 9 416 minecraft:orange_concrete
setblock 489 8 419 minecraft:light[level=14]
setblock 489 8 427 minecraft:light[level=14]
setblock 489 8 443 minecraft:light[level=14]
fill 489 8 458 489 9 458 minecraft:orange_concrete
fill 491 8 458 491 13 458 minecraft:blackstone
fill 492 8 416 492 13 416 minecraft:blackstone
fill 492 8 458 493 8 458 minecraft:orange_concrete
fill 493 8 416 494 8 416 minecraft:orange_concrete
fill 494 8 458 494 13 458 minecraft:blackstone
fill 495 8 416 495 13 416 minecraft:blackstone
fill 497 8 416 497 9 416 minecraft:orange_concrete
setblock 497 8 419 minecraft:light[level=14]
setblock 497 8 427 minecraft:light[level=14]
setblock 497 8 435 minecraft:light[level=14]
setblock 497 8 443 minecraft:light[level=14]
setblock 497 8 451 minecraft:light[level=14]
fill 500 8 458 501 9 458 minecraft:orange_concrete
fill 502 8 458 503 13 458 minecraft:blackstone
fill 503 8 416 504 13 416 minecraft:blackstone
fill 505 8 416 506 9 416 minecraft:orange_concrete
setblock 505 8 419 minecraft:light[level=14]
setblock 505 8 427 minecraft:light[level=14]
setblock 505 8 435 minecraft:light[level=14]
setblock 505 8 443 minecraft:light[level=14]
setblock 505 8 451 minecraft:light[level=14]
setblock 512 8 418 minecraft:orange_concrete
fill 512 8 419 512 13 420 minecraft:blackstone
fill 512 8 421 512 9 422 minecraft:orange_concrete
fill 512 8 427 512 13 428 minecraft:blackstone
fill 512 8 429 512 8 430 minecraft:orange_concrete
fill 512 8 431 512 13 431 minecraft:blackstone
fill 512 8 439 512 13 440 minecraft:blackstone
fill 512 8 441 512 9 442 minecraft:orange_concrete
fill 512 8 448 512 13 448 minecraft:blackstone
setblock 512 8 450 minecraft:orange_concrete
fill 512 8 451 512 13 452 minecraft:blackstone
fill 512 8 453 512 9 453 minecraft:orange_concrete
fill 512 8 458 512 9 458 minecraft:orange_concrete
setblock 470 9 424 minecraft:orange_concrete
fill 470 9 428 470 12 429 minecraft:blackstone
fill 470 9 444 470 9 445 minecraft:orange_concrete
setblock 470 9 448 minecraft:orange_concrete
fill 470 9 449 470 12 449 minecraft:blackstone
fill 472 9 458 472 12 458 minecraft:blackstone
fill 473 9 416 473 12 416 minecraft:blackstone
setblock 474 9 416 minecraft:orange_concrete
fill 476 9 458 476 11 458 minecraft:blackstone
setblock 477 9 416 minecraft:orange_concrete
setblock 477 9 458 minecraft:orange_concrete
setblock 488 9 458 minecraft:orange_concrete
fill 492 9 458 493 12 458 minecraft:blackstone
fill 493 9 416 494 12 416 minecraft:blackstone
setblock 498 9 416 minecraft:orange_concrete
setblock 509 9 416 minecraft:orange_concrete
setblock 509 9 458 minecraft:orange_concrete
fill 512 9 418 512 12 418 minecraft:blackstone
fill 512 9 429 512 12 429 minecraft:blackstone
setblock 512 9 430 minecraft:orange_concrete
fill 512 9 433 512 9 434 minecraft:orange_concrete
fill 512 9 450 512 12 450 minecraft:blackstone
setblock 512 9 454 minecraft:orange_concrete
fill 470 10 416 470 15 417 minecraft:blackstone
fill 470 10 422 470 11 423 minecraft:orange_concrete
fill 470 10 424 470 15 425 minecraft:blackstone
setblock 470 10 426 minecraft:orange_concrete
fill 470 10 434 470 11 435 minecraft:orange_concrete
fill 470 10 436 470 15 437 minecraft:blackstone
fill 470 10 443 470 11 443 minecraft:orange_concrete
fill 470 10 444 470 11 445 minecraft:blackstone
fill 470 10 446 470 10 447 minecraft:orange_concrete
fill 470 10 448 470 15 448 minecraft:blackstone
fill 470 10 454 470 11 455 minecraft:orange_concrete
fill 470 10 456 470 15 457 minecraft:blackstone
fill 474 10 416 474 15 416 minecraft:blackstone
fill 475 10 416 476 10 416 minecraft:orange_concrete
fill 477 10 416 477 15 416 minecraft:blackstone
fill 477 10 458 477 15 458 minecraft:blackstone
fill 478 10 458 479 10 458 minecraft:orange_concrete
fill 479 10 416 479 11 416 minecraft:orange_concrete
fill 480 10 458 481 15 458 minecraft:blackstone
fill 485 10 416 486 15 416 minecraft:blackstone
fill 486 10 458 487 11 458 minecraft:orange_concrete
fill 487 10 416 488 11 416 minecraft:orange_concrete
fill 488 10 458 489 15 458 minecraft:blackstone
setblock 490 10 458 minecraft:orange_concrete
setblock 496 10 416 minecraft:orange_concrete
fill 497 10 416 498 15 416 minecraft:blackstone
fill 498 10 458 499 11 458 minecraft:orange_concrete
fill 499 10 416 500 11 416 minecraft:orange_concrete
fill 500 10 458 501 15 458 minecraft:blackstone
fill 505 10 416 506 15 416 minecraft:blackstone
fill 507 10 416 508 10 416 minecraft:orange_concrete
fill 507 10 458 507 11 458 minecraft:orange_concrete
fill 509 10 416 509 15 416 minecraft:blackstone
fill 509 10 458 509 15 458 minecraft:blackstone
fill 510 10 458 511 10 458 minecraft:orange_concrete
fill 512 10 421 512 15 422 minecraft:blackstone
fill 512 10 423 512 11 424 minecraft:orange_concrete
fill 512 10 430 512 15 430 minecraft:blackstone
setblock 512 10 432 minecraft:orange_concrete
fill 512 10 433 512 15 434 minecraft:blackstone
fill 512 10 435 512 11 435 minecraft:orange_concrete
fill 512 10 441 512 15 442 minecraft:blackstone
fill 512 10 443 512 10 444 minecraft:orange_concrete
fill 512 10 453 512 15 454 minecraft:blackstone
fill 512 10 455 512 11 456 minecraft:orange_concrete
fill 512 10 458 512 15 458 minecraft:blackstone
fill 470 11 426 470 14 426 minecraft:blackstone
setblock 470 11 431 minecraft:orange_concrete
setblock 470 11 442 minecraft:orange_concrete
fill 470 11 446 470 13 447 minecraft:blackstone
fill 474 11 458 475 11 458 minecraft:orange_concrete
fill 475 11 416 476 14 416 minecraft:blackstone
setblock 478 11 458 minecraft:orange_concrete
fill 479 11 458 479 14 458 minecraft:blackstone
setblock 480 11 416 minecraft:orange_concrete
fill 490 11 458 490 14 458 minecraft:blackstone
setblock 491 11 416 minecraft:orange_concrete
setblock 495 11 458 minecraft:orange_concrete
fill 496 11 416 496 14 416 minecraft:blackstone
setblock 506 11 458 minecraft:orange_concrete
fill 507 11 416 507 14 416 minecraft:blackstone
setblock 508 11 416 minecraft:orange_concrete
fill 510 11 458 511 14 458 minecraft:blackstone
fill 511 11 416 512 11 416 minecraft:orange_concrete
fill 512 11 432 512 14 432 minecraft:blackstone
setblock 512 11 436 minecraft:orange_concrete
fill 512 11 443 512 14 443 minecraft:blackstone
setblock 512 11 444 minecraft:orange_concrete
setblock 512 11 447 minecraft:orange_concrete
fill 470 12 420 470 13 421 minecraft:orange_concrete
fill 470 12 422 470 17 423 minecraft:blackstone
fill 470 12 431 470 17 431 minecraft:blackstone
fill 470 12 432 470 12 433 minecraft:orange_concrete
fill 470 12 434 470 14 435 minecraft:blackstone
fill 470 12 440 470 13 441 minecraft:orange_concrete
fill 470 12 442 470 17 443 minecraft:blackstone
setblock 470 12 444 minecraft:orange_concrete
fill 470 12 445 470 15 445 minecraft:blackstone
fill 470 12 452 470 13 453 minecraft:orange_concrete
fill 470 12 454 470 17 455 minecraft:blackstone
fill 471 12 417 473 12 417 minecraft:red_nether_bricks
fill 471 12 419 471 12 421 minecraft:red_nether_bricks
fill 471 12 423 471 12 425 minecraft:red_nether_bricks
fill 471 12 427 471 12 429 minecraft:red_nether_bricks
fill 471 12 431 471 12 433 minecraft:red_nether_bricks
fill 471 12 435 471 12 437 minecraft:red_nether_bricks
fill 471 12 439 471 12 441 minecraft:red_nether_bricks
fill 471 12 443 471 12 445 minecraft:red_nether_bricks
fill 471 12 447 471 12 449 minecraft:red_nether_bricks
fill 471 12 451 471 12 453 minecraft:red_nether_bricks
fill 471 12 455 471 12 457 minecraft:red_nether_bricks
fill 473 12 457 475 12 457 minecraft:red_nether_bricks
fill 473 12 458 473 13 458 minecraft:orange_concrete
fill 474 12 458 475 17 458 minecraft:blackstone
fill 475 12 417 477 12 417 minecraft:red_nether_bricks
setblock 476 12 458 minecraft:orange_concrete
fill 477 12 457 479 12 457 minecraft:red_nether_bricks
setblock 478 12 416 minecraft:orange_concrete
fill 478 12 458 478 17 458 minecraft:blackstone
fill 479 12 416 480 17 416 minecraft:blackstone
fill 479 12 417 481 12 417 minecraft:red_nether_bricks
fill 481 12 416 482 13 416 minecraft:orange_concrete
fill 481 12 457 483 12 457 minecraft:red_nether_bricks
fill 483 12 417 485 12 417 minecraft:red_nether_bricks
fill 484 12 458 485 13 458 minecraft:orange_concrete
fill 485 12 457 487 12 457 minecraft:red_nether_bricks
fill 486 12 458 487 17 458 minecraft:blackstone
fill 487 12 416 488 17 416 minecraft:blackstone
fill 487 12 417 489 12 417 minecraft:red_nether_bricks
fill 489 12 416 490 12 416 minecraft:orange_concrete
fill 489 12 457 491 12 457 minecraft:red_nether_bricks
fill 491 12 416 491 17 416 minecraft:blackstone
fill 491 12 417 493 12 417 minecraft:red_nether_bricks
fill 493 12 457 495 12 457 minecraft:red_nether_bricks
fill 495 12 417 497 12 417 minecraft:red_nether_bricks
fill 495 12 458 495 17 458 minecraft:blackstone
fill 496 12 458 497 12 458 minecraft:orange_concrete
fill 497 12 457 499 12 457 minecraft:red_nether_bricks
fill 498 12 458 499 17 458 minecraft:blackstone
fill 499 12 416 500 17 416 minecraft:blackstone
fill 499 12 417 501 12 417 minecraft:red_nether_bricks
fill 501 12 416 502 13 416 minecraft:orange_concrete
fill 501 12 457 503 12 457 minecraft:red_nether_bricks
fill 503 12 417 505 12 417 minecraft:red_nether_bricks
fill 504 12 458 505 13 458 minecraft:orange_concrete
fill 505 12 457 507 12 457 minecraft:red_nether_bricks
fill 506 12 458 507 17 458 minecraft:blackstone
fill 507 12 417 509 12 417 minecraft:red_nether_bricks
fill 508 12 416 508 17 416 minecraft:blackstone
setblock 508 12 458 minecraft:orange_concrete
fill 509 12 457 511 12 457 minecraft:red_nether_bricks
setblock 510 12 416 minecraft:orange_concrete
fill 511 12 416 512 17 416 minecraft:blackstone
fill 511 12 417 511 12 419 minecraft:red_nether_bricks
fill 511 12 421 511 12 423 minecraft:red_nether_bricks
fill 511 12 425 511 12 427 minecraft:red_nether_bricks
fill 511 12 429 511 12 431 minecraft:red_nether_bricks
fill 511 12 433 511 12 435 minecraft:red_nether_bricks
fill 511 12 437 511 12 439 minecraft:red_nether_bricks
fill 511 12 441 511 12 443 minecraft:red_nether_bricks
fill 511 12 445 511 12 447 minecraft:red_nether_bricks
fill 511 12 449 511 12 451 minecraft:red_nether_bricks
fill 511 12 453 511 12 455 minecraft:red_nether_bricks
fill 512 12 417 512 13 417 minecraft:orange_concrete
fill 512 12 423 512 17 424 minecraft:blackstone
fill 512 12 425 512 12 426 minecraft:orange_concrete
fill 512 12 435 512 17 436 minecraft:blackstone
fill 512 12 437 512 13 438 minecraft:orange_concrete
fill 512 12 444 512 17 444 minecraft:blackstone
fill 512 12 445 512 12 446 minecraft:orange_concrete
fill 512 12 447 512 17 447 minecraft:blackstone
fill 512 12 449 512 13 449 minecraft:orange_concrete
fill 512 12 455 512 17 456 minecraft:blackstone
fill 512 12 457 512 13 457 minecraft:orange_concrete
fill 470 13 428 470 13 429 minecraft:orange_concrete
setblock 470 13 432 minecraft:orange_concrete
fill 470 13 433 470 16 433 minecraft:blackstone
fill 470 13 444 470 15 444 minecraft:blackstone
setblock 470 13 449 minecraft:orange_concrete
setblock 472 13 458 minecraft:orange_concrete
setblock 473 13 416 minecraft:orange_concrete
fill 476 13 458 476 16 458 minecraft:blackstone
fill 478 13 416 478 16 416 minecraft:blackstone
fill 489 13 416 489 16 416 minecraft:blackstone
setblock 490 13 416 minecraft:orange_concrete
fill 492 13 458 493 13 458 minecraft:orange_concrete
fill 493 13 416 494 13 416 minecraft:orange_concrete
setblock 496 13 458 minecraft:orange_concrete
fill 497 13 458 497 16 458 minecraft:blackstone
fill 508 13 458 508 16 458 minecraft:blackstone
fill 510 13 416 510 16 416 minecraft:blackstone
setblock 512 13 418 minecraft:orange_concrete
fill 512 13 425 512 16 425 minecraft:blackstone
setblock 512 13 426 minecraft:orange_concrete
setblock 512 13 429 minecraft:orange_concrete
fill 512 13 445 512 16 446 minecraft:blackstone
setblock 512 13 450 minecraft:orange_concrete
fill 470 14 418 470 14 419 minecraft:orange_concrete
fill 470 14 420 470 19 421 minecraft:blackstone
fill 470 14 427 470 15 427 minecraft:orange_concrete
fill 470 14 428 470 19 429 minecraft:blackstone
setblock 470 14 430 minecraft:orange_concrete
fill 470 14 432 470 16 432 minecraft:blackstone
fill 470 14 438 470 15 439 minecraft:orange_concrete
fill 470 14 440 470 19 441 minecraft:blackstone
setblock 470 14 446 minecraft:blackstone
fill 470 14 447 470 15 447 minecraft:orange_concrete
fill 470 14 449 470 19 449 minecraft:blackstone
fill 470 14 450 470 14 451 minecraft:orange_concrete
fill 470 14 452 470 16 453 minecraft:blackstone
fill 470 14 458 471 15 458 minecraft:orange_concrete
fill 471 14 416 472 14 416 minecraft:orange_concrete
fill 472 14 458 473 19 458 minecraft:blackstone
fill 473 14 416 473 19 416 minecraft:blackstone
fill 481 14 416 482 19 416 minecraft:blackstone
fill 482 14 458 483 14 458 minecraft:orange_concrete
fill 483 14 416 484 15 416 minecraft:orange_concrete
fill 484 14 458 485 19 458 minecraft:blackstone
fill 490 14 416 490 19 416 minecraft:blackstone
fill 491 14 458 491 15 458 minecraft:orange_concrete
setblock 492 14 416 minecraft:orange_concrete
fill 492 14 458 493 19 458 minecraft:blackstone
fill 493 14 416 494 19 416 minecraft:blackstone
setblock 494 14 458 minecraft:orange_concrete
fill 495 14 416 495 15 416 minecraft:orange_concrete
fill 496 14 458 496 19 458 minecraft:blackstone
fill 501 14 416 502 19 416 minecraft:blackstone
fill 502 14 458 503 15 458 minecraft:orange_concrete
fill 503 14 416 504 14 416 minecraft:orange_concrete
fill 504 14 458 505 19 458 minecraft:blackstone
fill 512 14 417 512 19 418 minecraft:blackstone
fill 512 14 419 512 15 420 minecraft:orange_concrete
fill 512 14 426 512 19 426 minecraft:blackstone
fill 512 14 427 512 14 428 minecraft:orange_concrete
fill 512 14 429 512 19 429 minecraft:blackstone
fill 512 14 431 512 15 431 minecraft:orange_concrete
fill 512 14 437 512 19 438 minecraft:blackstone
fill 512 14 439 512 15 440 minecraft:orange_concrete
setblock 512 14 448 minecraft:orange_concrete
fill 512 14 449 512 19 450 minecraft:blackstone
fill 512 14 451 512 15 452 minecraft:orange_concrete
fill 512 14 457 512 19 457 minecraft:blackstone
setblock 470 15 418 minecraft:orange_concrete
fill 470 15 419 470 18 419 minecraft:blackstone
setblock 470 15 426 minecraft:orange_concrete
fill 470 15 430 470 18 430 minecraft:blackstone
fill 470 15 434 470 17 434 minecraft:blackstone
setblock 470 15 435 minecraft:orange_concrete
setblock 470 15 446 minecraft:orange_concrete
setblock 470 15 450 minecraft:orange_concrete
fill 470 15 451 470 18 451 minecraft:blackstone
fill 471 15 416 471 18 416 minecraft:blackstone
setblock 472 15 416 minecraft:orange_concrete
fill 475 15 416 476 15 416 minecraft:orange_concrete
setblock 479 15 458 minecraft:orange_concrete
setblock 482 15 458 minecraft:orange_concrete
fill 483 15 458 483 18 458 minecraft:blackstone
setblock 490 15 458 minecraft:orange_concrete
fill 492 15 416 492 18 416 minecraft:blackstone
fill 494 15 458 494 18 458 minecraft:blackstone
setblock 496 15 416 minecraft:orange_concrete
fill 503 15 416 503 18 416 minecraft:blackstone
setblock 504 15 416 minecraft:orange_concrete
setblock 507 15 416 minecraft:orange_concrete
fill 510 15 458 511 15 458 minecraft:orange_concrete
fill 512 15 427 512 18 428 minecraft:blackstone
setblock 512 15 432 minecraft:orange_concrete
setblock 512 15 443 minecraft:orange_concrete
fill 512 15 448 512 18 448 minecraft:blackstone
fill 470 16 416 470 16 417 minecraft:orange_concrete
fill 470 16 418 470 21 418 minecraft:blackstone
fill 470 16 424 470 17 425 minecraft:orange_concrete
fill 470 16 426 470 21 427 minecraft:blackstone
fill 470 16 435 470 17 435 minecraft:blackstone
fill 470 16 436 470 16 437 minecraft:orange_concrete
fill 470 16 438 470 21 439 minecraft:blackstone
fill 470 16 444 470 17 445 minecraft:orange_concrete
fill 470 16 446 470 21 447 minecraft:blackstone
setblock 470 16 448 minecraft:orange_concrete
fill 470 16 450 470 18 450 minecraft:blackstone
fill 470 16 456 470 17 457 minecraft:orange_concrete
fill 470 16 458 471 21 458 minecraft:blackstone
fill 472 16 416 472 21 416 minecraft:blackstone
setblock 473 16 419 minecraft:light[level=14]
setblock 473 16 427 minecraft:light[level=14]
setblock 473 16 435 minecraft:light[level=14]
setblock 473 16 443 minecraft:light[level=14]
setblock 473 16 451 minecraft:light[level=14]
setblock 474 16 416 minecraft:orange_concrete
fill 475 16 416 476 21 416 minecraft:blackstone
fill 477 16 416 477 17 416 minecraft:orange_concrete
fill 477 16 458 477 17 458 minecraft:orange_concrete
fill 479 16 458 479 21 458 minecraft:blackstone
fill 480 16 458 481 16 458 minecraft:orange_concrete
setblock 481 16 419 minecraft:light[level=14]
setblock 481 16 427 minecraft:light[level=14]
setblock 481 16 435 minecraft:light[level=14]
setblock 481 16 443 minecraft:light[level=14]
setblock 481 16 451 minecraft:light[level=14]
fill 482 16 458 482 21 458 minecraft:blackstone
fill 483 16 416 484 21 416 minecraft:blackstone
fill 485 16 416 486 16 416 minecraft:orange_concrete
fill 488 16 458 489 17 458 minecraft:orange_concrete
setblock 489 16 419 minecraft:light[level=14]
setblock 489 16 427 minecraft:light[level=14]
setblock 489 16 435 minecraft:light[level=14]
setblock 489 16 443 minecraft:light[level=14]
fill 490 16 458 491 21 458 minecraft:blackstone
fill 495 16 416 496 21 416 minecraft:blackstone
fill 497 16 416 498 17 416 minecraft:orange_concrete
setblock 497 16 419 minecraft:light[level=14]
setblock 497 16 427 minecraft:light[level=14]
setblock 497 16 435 minecraft:light[level=14]
setblock 497 16 443 minecraft:light[level=14]
setblock 497 16 451 minecraft:light[level=14]
fill 500 16 458 501 16 458 minecraft:orange_concrete
fill 502 16 458 503 21 458 minecraft:blackstone
fill 504 16 416 504 21 416 minecraft:blackstone
fill 505 16 416 506 16 416 minecraft:orange_concrete
setblock 505 16 419 minecraft:light[level=14]
setblock 505 16 427 minecraft:light[level=14]
setblock 505 16 435 minecraft:light[level=14]
setblock 505 16 443 minecraft:light[level=14]
setblock 505 16 451 minecraft:light[level=14]
fill 507 16 416 507 21 416 minecraft:blackstone
fill 509 16 416 509 17 416 minecraft:orange_concrete
fill 509 16 458 509 17 458 minecraft:orange_concrete
fill 510 16 458 511 21 458 minecraft:blackstone
fill 512 16 419 512 21 420 minecraft:blackstone
fill 512 16 421 512 17 422 minecraft:orange_concrete
setblock 512 16 430 minecraft:orange_concrete
fill 512 16 431 512 21 432 minecraft:blackstone
fill 512 16 433 512 17 434 minecraft:orange_concrete
fill 512 16 439 512 21 440 minecraft:blackstone
fill 512 16 441 512 16 442 minecraft:orange_concrete
fill 512 16 443 512 21 443 minecraft:blackstone
fill 512 16 451 512 21 452 minecraft:blackstone
fill 512 16 453 512 17 454 minecraft:orange_concrete
setblock 512 16 458 minecraft:orange_concrete
fill 470 17 416 470 20 417 minecraft:blackstone
fill 470 17 432 470 17 433 minecraft:orange_concrete
setblock 470 17 436 minecraft:orange_concrete
fill 470 17 437 470 20 437 minecraft:blackstone
fill 470 17 448 470 20 448 minecraft:blackstone
fill 470 17 452 470 19 452 minecraft:blackstone
setblock 470 17 453 minecraft:orange_concrete
fill 474 17 416 474 20 416 minecraft:blackstone
setblock 476 17 458 minecraft:orange_concrete
setblock 478 17 416 minecraft:orange_concrete
fill 480 17 458 481 20 458 minecraft:blackstone
fill 485 17 416 485 20 416 minecraft:blackstone
setblock 486 17 416 minecraft:orange_concrete
setblock 489 17 416 minecraft:orange_concrete
setblock 497 17 458 minecraft:orange_concrete
setblock 500 17 458 minecraft:orange_concrete
fill 501 17 458 501 20 458 minecraft:blackstone
fill 505 17 416 506 20 416 minecraft:blackstone
setblock 508 17 458 minecraft:orange_concrete
setblock 510 17 416 minecraft:orange_concrete
setblock 512 17 425 minecraft:orange_concrete
fill 512 17 430 512 20 430 minecraft:blackstone
fill 512 17 441 512 20 441 minecraft:blackstone
setblock 512 17 442 minecraft:orange_concrete
fill 512 17 445 512 17 446 minecraft:orange_concrete
fill 512 17 458 512 20 458 minecraft:blackstone
fill 470 18 422 470 19 423 minecraft:orange_concrete
fill 470 18 424 470 23 425 minecraft:blackstone
fill 470 18 431 470 19 431 minecraft:orange_concrete
fill 470 18 432 470 19 433 minecraft:blackstone
fill 470 18 434 470 18 435 minecraft:orange_concrete
fill 470 18 436 470 23 436 minecraft:blackstone
fill 470 18 442 470 19 443 minecraft:orange_concrete
fill 470 18 444 470 23 445 minecraft:blackstone
fill 470 18 453 470 23 453 minecraft:blackstone
fill 470 18 454 470 18 455 minecraft:orange_concrete
fill 470 18 456 470 23 457 minecraft:blackstone
fill 471 18 417 473 18 417 minecraft:red_nether_bricks
fill 471 18 419 471 18 421 minecraft:red_nether_bricks
fill 471 18 423 471 18 425 minecraft:red_nether_bricks
fill 471 18 427 471 18 429 minecraft:red_nether_bricks
fill 471 18 431 471 18 433 minecraft:red_nether_bricks
fill 471 18 435 471 18 437 minecraft:red_nether_bricks
fill 471 18 439 471 18 441 minecraft:red_nether_bricks
fill 471 18 443 471 18 445 minecraft:red_nether_bricks
fill 471 18 447 471 18 449 minecraft:red_nether_bricks
fill 471 18 451 471 18 453 minecraft:red_nether_bricks
fill 471 18 455 471 18 457 minecraft:red_nether_bricks
fill 473 18 457 475 18 457 minecraft:red_nether_bricks
fill 474 18 458 475 19 458 minecraft:orange_concrete
fill 475 18 417 477 18 417 minecraft:red_nether_bricks
fill 476 18 458 477 23 458 minecraft:blackstone
fill 477 18 416 478 23 416 minecraft:blackstone
fill 477 18 457 479 18 457 minecraft:red_nether_bricks
setblock 478 18 458 minecraft:orange_concrete
fill 479 18 416 480 19 416 minecraft:orange_concrete
fill 479 18 417 481 18 417 minecraft:red_nether_bricks
fill 481 18 457 483 18 457 minecraft:red_nether_bricks
fill 483 18 417 485 18 417 minecraft:red_nether_bricks
fill 485 18 457 487 18 457 minecraft:red_nether_bricks
fill 486 18 416 486 23 416 minecraft:blackstone
fill 486 18 458 487 19 458 minecraft:orange_concrete
fill 487 18 416 488 18 416 minecraft:orange_concrete
fill 487 18 417 489 18 417 minecraft:red_nether_bricks
fill 488 18 458 489 23 458 minecraft:blackstone
fill 489 18 416 489 23 416 minecraft:blackstone
fill 489 18 457 491 18 457 minecraft:red_nether_bricks
fill 491 18 416 491 19 416 minecraft:orange_concrete
fill 491 18 417 493 18 417 minecraft:red_nether_bricks
fill 493 18 457 495 18 457 minecraft:red_nether_bricks
fill 495 18 417 497 18 417 minecraft:red_nether_bricks
fill 495 18 458 495 19 458 minecraft:orange_concrete
fill 497 18 416 498 23 416 minecraft:blackstone
fill 497 18 457 499 18 457 minecraft:red_nether_bricks
fill 497 18 458 497 23 458 minecraft:blackstone
fill 498 18 458 499 18 458 minecraft:orange_concrete
fill 499 18 416 500 19 416 minecraft:orange_concrete
fill 499 18 417 501 18 417 minecraft:red_nether_bricks
fill 500 18 458 500 23 458 minecraft:blackstone
fill 501 18 457 503 18 457 minecraft:red_nether_bricks
fill 503 18 417 505 18 417 minecraft:red_nether_bricks
fill 505 18 457 507 18 457 minecraft:red_nether_bricks
fill 506 18 458 507 19 458 minecraft:orange_concrete
fill 507 18 417 509 18 417 minecraft:red_nether_bricks
setblock 508 18 416 minecraft:orange_concrete
fill 508 18 458 509 23 458 minecraft:blackstone
fill 509 18 416 510 23 416 minecraft:blackstone
fill 509 18 457 511 18 457 minecraft:red_nether_bricks
fill 511 18 416 512 19 416 minecraft:orange_concrete
fill 511 18 417 511 18 419 minecraft:red_nether_bricks
fill 511 18 421 511 18 423 minecraft:red_nether_bricks
fill 511 18 425 511 18 427 minecraft:red_nether_bricks
fill 511 18 429 511 18 431 minecraft:red_nether_bricks
fill 511 18 433 511 18 435 minecraft:red_nether_bricks
fill 511 18 437 511 18 439 minecraft:red_nether_bricks
fill 511 18 441 511 18 443 minecraft:red_nether_bricks
fill 511 18 445 511 18 447 minecraft:red_nether_bricks
fill 511 18 449 511 18 451 minecraft:red_nether_bricks
fill 511 18 453 511 18 455 minecraft:red_nether_bricks
fill 512 18 421 512 23 422 minecraft:blackstone
fill 512 18 423 512 18 424 minecraft:orange_concrete
fill 512 18 425 512 23 425 minecraft:blackstone
fill 512 18 433 512 23 434 minecraft:blackstone
fill 512 18 435 512 19 436 minecraft:orange_concrete
fill 512 18 442 512 23 442 minecraft:blackstone
setblock 512 18 444 minecraft:orange_concrete
fill 512 18 445 512 23 446 minecraft:blackstone
fill 512 18 447 512 19 447 minecraft:orange_concrete
fill 512 18 453 512 23 454 minecraft:blackstone
fill 512 18 455 512 18 456 minecraft:orange_concrete
setblock 470 19 419 minecraft:orange_concrete
setblock 470 19 430 minecraft:orange_concrete
fill 470 19 434 470 21 435 minecraft:blackstone
fill 470 19 450 470 19 451 minecraft:orange_concrete
setblock 470 19 454 minecraft:orange_concrete
fill 470 19 455 470 22 455 minecraft:blackstone
setblock 471 19 416 minecraft:orange_concrete
fill 478 19 458 478 22 458 minecraft:blackstone
setblock 483 19 458 minecraft:orange_concrete
fill 487 19 416 488 22 416 minecraft:blackstone
setblock 492 19 416 minecraft:orange_concrete
setblock 494 19 458 minecraft:orange_concrete
fill 498 19 458 499 22 458 minecraft:blackstone
setblock 503 19 416 minecraft:orange_concrete
fill 508 19 416 508 22 416 minecraft:blackstone
fill 512 19 423 512 22 423 minecraft:blackstone
setblock 512 19 424 minecraft:orange_concrete
fill 512 19 427 512 19 428 minecraft:orange_concrete
fill 512 19 444 512 22 444 minecraft:blackstone
setblock 512 19 448 minecraft:orange_concrete
fill 512 19 455 512 22 455 minecraft:blackstone
setblock 512 19 456 minecraft:orange_concrete
fill 470 20 419 470 25 419 minecraft:blackstone
fill 470 20 420 470 20 421 minecraft:orange_concrete
fill 470 20 422 470 22 423 minecraft:blackstone
fill 470 20 428 470 21 429 minecraft:orange_concrete
fill 470 20 430 470 25 431 minecraft:blackstone
setblock 470 20 432 minecraft:orange_concrete
fill 470 20 433 470 23 433 minecraft:blackstone
fill 470 20 440 470 21 441 minecraft:orange_concrete
fill 470 20 442 470 25 443 minecraft:blackstone
fill 470 20 449 470 21 449 minecraft:orange_concrete
fill 470 20 450 470 25 451 minecraft:blackstone
setblock 470 20 452 minecraft:orange_concrete
fill 470 20 454 470 25 454 minecraft:blackstone
fill 471 20 416 471 25 416 minecraft:blackstone
fill 472 20 458 473 21 458 minecraft:orange_concrete
fill 473 20 416 473 21 416 minecraft:orange_concrete
fill 474 20 458 475 25 458 minecraft:blackstone
fill 479 20 416 480 25 416 minecraft:blackstone
fill 481 20 416 482 21 416 minecraft:orange_concrete
fill 483 20 458 483 25 458 minecraft:blackstone
fill 484 20 458 485 20 458 minecraft:orange_concrete
fill 486 20 458 487 25 458 minecraft:blackstone
setblock 490 20 416 minecraft:orange_concrete
fill 491 20 416 492 25 416 minecraft:blackstone
fill 492 20 458 493 21 458 minecraft:orange_concrete
fill 493 20 416 494 21 416 minecraft:orange_concrete
fill 494 20 458 495 25 458 minecraft:blackstone
setblock 496 20 458 minecraft:orange_concrete
fill 499 20 416 500 25 416 minecraft:blackstone
fill 500 20 442 500 21 442 minecraft:netherrack
fill 501 20 416 502 20 416 minecraft:orange_concrete
fill 503 20 416 503 25 416 minecraft:blackstone
fill 504 20 458 505 21 458 minecraft:orange_concrete
fill 506 20 458 507 25 458 minecraft:blackstone
fill 511 20 416 512 25 416 minecraft:blackstone
fill 512 20 417 512 21 418 minecraft:orange_concrete
fill 512 20 424 512 25 424 minecraft:blackstone
setblock 512 20 426 minecraft:orange_concrete
fill 512 20 427 512 25 428 minecraft:blackstone
fill 512 20 429 512 21 429 minecraft:orange_concrete
fill 512 20 435 512 25 436 minecraft:blackstone
fill 512 20 437 512 20 438 minecraft:orange_concrete
fill 512 20 447 512 25 448 minecraft:blackstone
fill 512 20 449 512 21 450 minecraft:orange_concrete
fill 512 20 456 512 25 456 minecraft:blackstone
setblock 512 20 457 minecraft:orange_concrete
fill 470 21 416 470 21 417 minecraft:orange_concrete
setblock 470 21 420 minecraft:orange_concrete
fill 470 21 421 470 24 421 minecraft:blackstone
fill 470 21 432 470 23 432 minecraft:blackstone
setblock 470 21 437 minecraft:orange_concrete
setblock 470 21 448 minecraft:orange_concrete
fill 470 21 452 470 24 452 minecraft:blackstone
setblock 474 21 416 minecraft:orange_concrete
fill 480 21 458 481 21 458 minecraft:orange_concrete
setblock 484 21 458 minecraft:orange_concrete
setblock 485 21 416 minecraft:orange_concrete
fill 485 21 458 485 24 458 minecraft:blackstone
fill 490 21 416 490 24 416 minecraft:blackstone
fill 496 21 458 496 24 458 minecraft:blackstone
fill 501 21 416 501 24 416 minecraft:blackstone
setblock 501 21 458 minecraft:orange_concrete
setblock 502 21 416 minecraft:orange_concrete
fill 505 21 416 506 21 416 minecraft:orange_concrete
fill 512 21 426 512 24 426 minecraft:blackstone
setblock 512 21 430 minecraft:orange_concrete
fill 512 21 437 512 24 437 minecraft:blackstone
setblock 512 21 438 minecraft:orange_concrete
setblock 512 21 441 minecraft:orange_concrete
fill 512 21 457 512 24 457 minecraft:blackstone
setblock 512 21 458 minecraft:orange_concrete
fill 470 22 416 470 27 417 minecraft:blackstone
setblock 470 22 418 minecraft:orange_concrete
fill 470 22 420 470 24 420 minecraft:blackstone
fill 470 22 426 470 23 427 minecraft:orange_concrete
fill 470 22 428 470 27 429 minecraft:blackstone
setblock 470 22 434 minecraft:blackstone
fill 470 22 435 470 23 435 minecraft:orange_concrete
fill 470 22 437 470 27 437 minecraft:blackstone
fill 470 22 438 470 22 439 minecraft:orange_concrete
fill 470 22 440 470 24 441 minecraft:blackstone
fill 470 22 446 470 23 447 minecraft:orange_concrete
fill 470 22 448 470 27 449 minecraft:blackstone
fill 470 22 458 471 22 458 minecraft:orange_concrete
setblock 472 22 416 minecraft:orange_concrete
fill 472 22 458 473 27 458 minecraft:blackstone
fill 473 22 416 474 27 416 minecraft:blackstone
fill 475 22 416 476 23 416 minecraft:orange_concrete
fill 479 22 458 479 23 458 minecraft:orange_concrete
fill 480 22 458 481 27 458 minecraft:blackstone
fill 481 22 416 482 27 416 minecraft:blackstone
setblock 482 22 458 minecraft:orange_concrete
fill 483 22 416 484 22 416 minecraft:orange_concrete
fill 484 22 458 484 27 458 minecraft:blackstone
fill 485 22 416 485 27 416 minecraft:blackstone
fill 490 22 458 491 23 458 minecraft:orange_concrete
fill 492 22 458 493 27 458 minecraft:blackstone
fill 493 22 416 494 27 416 minecraft:blackstone
fill 495 22 416 496 23 416 minecraft:orange_concrete
fill 501 22 458 501 27 458 minecraft:blackstone
fill 502 22 416 502 27 416 minecraft:blackstone
fill 502 22 458 503 22 458 minecraft:orange_concrete
setblock 504 22 416 minecraft:orange_concrete
fill 504 22 458 505 27 458 minecraft:blackstone
fill 505 22 416 506 27 416 minecraft:blackstone
fill 507 22 416 507 23 416 minecraft:orange_concrete
fill 510 22 458 511 23 458 minecraft:orange_concrete
fill 512 22 417 512 27 418 minecraft:blackstone
fill 512 22 419 512 22 420 minecraft:orange_concrete
fill 512 22 429 512 27 430 minecraft:blackstone
fill 512 22 431 512 23 432 minecraft:orange_concrete
fill 512 22 438 512 27 438 minecraft:blackstone
fill 512 22 439 512 22 440 minecraft:orange_concrete
fill 512 22 441 512 27 441 minecraft:blackstone
fill 512 22 443 512 23 443 minecraft:orange_concrete
fill 512 22 449 512 27 450 minecraft:blackstone
fill 512 22 451 512 23 452 minecraft:orange_concrete
fill 512 22 458 512 27 458 minecraft:blackstone
fill 470 23 418 470 26 418 minecraft:blackstone
fill 470 23 422 470 25 422 minecraft:blackstone
setblock 470 23 423 minecraft:orange_concrete
setblock 470 23 434 minecraft:orange_concrete
setblock 470 23 438 minecraft:orange_concrete
fill 470 23 439 470 26 439 minecraft:blackstone
setblock 470 23 455 minecraft:orange_concrete
setblock 470 23 458 minecraft:orange_concrete
fill 471 23 458 471 26 458 minecraft:blackstone
fill 472 23 416 472 26 416 minecraft:blackstone
fill 474 23 436 476 24 436 minecraft:magma_block
fill 475 23 435 475 24 435 minecraft:magma_block
fill 475 23 437 475 24 437 minecraft:magma_block
setblock 478 23 458 minecraft:orange_concrete
fill 482 23 458 482 26 458 minecraft:blackstone
fill 483 23 416 483 26 416 minecraft:blackstone
setblock 484 23 416 minecraft:orange_concrete
fill 484 23 422 484 24 423 minecraft:magma_block
fill 487 23 416 488 23 416 minecraft:orange_concrete
fill 498 23 458 499 23 458 minecraft:orange_concrete
setblock 502 23 458 minecraft:orange_concrete
fill 503 23 458 503 26 458 minecraft:blackstone
fill 504 23 416 504 26 416 minecraft:blackstone
setblock 508 23 416 minecraft:orange_concrete
fill 512 23 419 512 26 419 minecraft:blackstone
setblock 512 23 420 minecraft:orange_concrete
setblock 512 23 423 minecraft:orange_concrete
fill 512 23 439 512 26 440 minecraft:blackstone
setblock 512 23 444 minecraft:orange_concrete
setblock 512 23 455 minecraft:orange_concrete
fill 470 24 423 470 25 423 minecraft:blackstone
fill 470 24 424 470 24 425 minecraft:orange_concrete
fill 470 24 426 470 29 427 minecraft:blackstone
fill 470 24 432 470 25 433 minecraft:orange_concrete
fill 470 24 434 470 29 435 minecraft:blackstone
setblock 470 24 436 minecraft:orange_concrete
fill 470 24 438 470 26 438 minecraft:blackstone
fill 470 24 444 470 25 445 minecraft:orange_concrete
fill 470 24 446 470 29 447 minecraft:blackstone
fill 470 24 453 470 25 453 minecraft:orange_concrete
fill 470 24 455 470 29 455 minecraft:blackstone
fill 470 24 456 470 24 457 minecraft:orange_concrete
fill 470 24 458 470 29 458 minecraft:blackstone
fill 471 24 417 473 24 417 minecraft:red_nether_bricks
fill 471 24 419 471 24 421 minecraft:red_nether_bricks
fill 471 24 423 471 24 425 minecraft:red_nether_bricks
fill 471 24 427 471 24 429 minecraft:red_nether_bricks
fill 471 24 431 471 24 433 minecraft:red_nether_bricks
fill 471 24 435 471 24 437 minecraft:red_nether_bricks
fill 471 24 439 471 24 441 minecraft:red_nether_bricks
fill 471 24 443 471 24 445 minecraft:red_nether_bricks
fill 471 24 447 471 24 449 minecraft:red_nether_bricks
fill 471 24 451 471 24 453 minecraft:red_nether_bricks
fill 471 24 455 471 24 457 minecraft:red_nether_bricks
setblock 473 24 419 minecraft:light[level=14]
setblock 473 24 427 minecraft:light[level=14]
setblock 473 24 435 minecraft:light[level=14]
setblock 473 24 443 minecraft:light[level=14]
setblock 473 24 451 minecraft:light[level=14]
fill 473 24 457 475 24 457 minecraft:red_nether_bricks
fill 475 24 416 476 29 416 minecraft:blackstone
fill 475 24 417 477 24 417 minecraft:red_nether_bricks
fill 476 24 458 477 25 458 minecraft:orange_concrete
fill 477 24 416 478 25 416 minecraft:orange_concrete
fill 477 24 457 479 24 457 minecraft:red_nether_bricks
fill 478 24 458 479 29 458 minecraft:blackstone
fill 479 24 417 481 24 417 minecraft:red_nether_bricks
setblock 481 24 419 minecraft:light[level=14]
setblock 481 24 427 minecraft:light[level=14]
setblock 481 24 435 minecraft:light[level=14]
setblock 481 24 443 minecraft:light[level=14]
setblock 481 24 451 minecraft:light[level=14]
fill 481 24 457 483 24 457 minecraft:red_nether_bricks
fill 483 24 417 485 24 417 minecraft:red_nether_bricks
fill 484 24 416 484 29 416 minecraft:blackstone
fill 485 24 457 487 24 457 minecraft:red_nether_bricks
setblock 486 24 416 minecraft:orange_concrete
fill 487 24 416 488 29 416 minecraft:blackstone
fill 487 24 417 489 24 417 minecraft:red_nether_bricks
fill 488 24 458 489 24 458 minecraft:orange_concrete
fill 489 24 416 489 25 416 minecraft:orange_concrete
setblock 489 24 419 minecraft:light[level=14]
setblock 489 24 427 minecraft:light[level=14]
setblock 489 24 435 minecraft:light[level=14]
setblock 489 24 443 minecraft:light[level=14]
fill 489 24 457 491 24 457 minecraft:red_nether_bricks
fill 490 24 458 491 29 458 minecraft:blackstone
fill 491 24 417 493 24 417 minecraft:red_nether_bricks
fill 493 24 457 495 24 457 minecraft:red_nether_bricks
fill 495 24 416 496 29 416 minecraft:blackstone
fill 495 24 417 497 24 417 minecraft:red_nether_bricks
fill 497 24 416 498 24 416 minecraft:orange_concrete
setblock 497 24 419 minecraft:light[level=14]
setblock 497 24 427 minecraft:light[level=14]
setblock 497 24 435 minecraft:light[level=14]
setblock 497 24 443 minecraft:light[level=14]
setblock 497 24 451 minecraft:light[level=14]
fill 497 24 457 499 24 457 minecraft:red_nether_bricks
fill 497 24 458 497 25 458 minecraft:orange_concrete
fill 498 24 458 499 29 458 minecraft:blackstone
fill 499 24 417 501 24 417 minecraft:red_nether_bricks
setblock 500 24 458 minecraft:orange_concrete
fill 501 24 457 503 24 457 minecraft:red_nether_bricks
fill 502 24 458 502 29 458 minecraft:blackstone
fill 503 24 417 505 24 417 minecraft:red_nether_bricks
setblock 505 24 419 minecraft:light[level=14]
setblock 505 24 427 minecraft:light[level=14]
setblock 505 24 435 minecraft:light[level=14]
setblock 505 24 443 minecraft:light[level=14]
setblock 505 24 451 minecraft:light[level=14]
fill 505 24 457 507 24 457 minecraft:red_nether_bricks
fill 507 24 416 508 29 416 minecraft:blackstone
fill 507 24 417 509 24 417 minecraft:red_nether_bricks
fill 508 24 458 509 25 458 minecraft:orange_concrete
fill 509 24 416 510 25 416 minecraft:orange_concrete
fill 509 24 457 511 24 457 minecraft:red_nether_bricks
fill 510 24 458 511 29 458 minecraft:blackstone
fill 511 24 417 511 24 419 minecraft:red_nether_bricks
fill 511 24 421 511 24 423 minecraft:red_nether_bricks
fill 511 24 425 511 24 427 minecraft:red_nether_bricks
fill 511 24 429 511 24 431 minecraft:red_nether_bricks
fill 511 24 433 511 24 435 minecraft:red_nether_bricks
fill 511 24 437 511 24 439 minecraft:red_nether_bricks
fill 511 24 441 511 24 443 minecraft:red_nether_bricks
fill 511 24 445 511 24 447 minecraft:red_nether_bricks
fill 511 24 449 511 24 451 minecraft:red_nether_bricks
fill 511 24 453 511 24 455 minecraft:red_nether_bricks
fill 512 24 420 512 29 420 minecraft:blackstone
fill 512 24 421 512 24 422 minecraft:orange_concrete
fill 512 24 423 512 29 423 minecraft:blackstone
fill 512 24 425 512 25 425 minecraft:orange_concrete
fill 512 24 431 512 29 432 minecraft:blackstone
fill 512 24 433 512 25 434 minecraft:orange_concrete
setblock 512 24 442 minecraft:orange_concrete
fill 512 24 443 512 29 444 minecraft:blackstone
fill 512 24 445 512 25 446 minecraft:orange_concrete
fill 512 24 451 512 29 452 minecraft:blackstone
fill 512 24 453 512 24 454 minecraft:orange_concrete
fill 512 24 455 512 29 455 minecraft:blackstone
fill 470 25 420 470 25 421 minecraft:orange_concrete
setblock 470 25 424 minecraft:orange_concrete
fill 470 25 425 470 28 425 minecraft:blackstone
fill 470 25 436 470 28 436 minecraft:blackstone
fill 470 25 440 470 27 440 minecraft:blackstone
setblock 470 25 441 minecraft:orange_concrete
setblock 470 25 452 minecraft:orange_concrete
fill 470 25 456 470 28 457 minecraft:blackstone
setblock 485 25 458 minecraft:orange_concrete
fill 486 25 416 486 28 416 minecraft:blackstone
setblock 488 25 458 minecraft:orange_concrete
fill 489 25 458 489 28 458 minecraft:blackstone
setblock 490 25 416 minecraft:orange_concrete
setblock 496 25 458 minecraft:orange_concrete
fill 497 25 416 497 28 416 minecraft:blackstone
setblock 498 25 416 minecraft:orange_concrete
fill 500 25 458 500 28 458 minecraft:blackstone
setblock 501 25 416 minecraft:orange_concrete
fill 512 25 421 512 28 422 minecraft:blackstone
setblock 512 25 426 minecraft:orange_concrete
setblock 512 25 437 minecraft:orange_concrete
fill 512 25 442 512 28 442 minecraft:blackstone
fill 512 25 453 512 28 453 minecraft:blackstone
setblock 512 25 454 minecraft:orange_concrete
setblock 512 25 457 minecraft:orange_concrete
fill 470 26 419 470 27 419 minecraft:orange_concrete
fill 470 26 420 470 27 421 minecraft:blackstone
fill 470 26 422 470 26 423 minecraft:orange_concrete
fill 470 26 424 470 31 424 minecraft:blackstone
fill 470 26 430 470 27 431 minecraft:orange_concrete
fill 470 26 432 470 31 433 minecraft:blackstone
fill 470 26 441 470 31 441 minecraft:blackstone
fill 470 26 442 470 26 443 minecraft:orange_concrete
fill 470 26 444 470 31 445 minecraft:blackstone
fill 470 26 450 470 27 451 minecraft:orange_concrete
fill 470 26 452 470 31 453 minecraft:blackstone
setblock 470 26 454 minecraft:orange_concrete
fill 471 26 416 471 27 416 minecraft:orange_concrete
fill 474 26 458 475 27 458 minecraft:orange_concrete
fill 476 26 458 477 31 458 minecraft:blackstone
fill 477 26 416 478 31 416 minecraft:blackstone
fill 478 26 444 478 27 445 minecraft:shroomlight
fill 479 26 416 480 26 416 minecraft:orange_concrete
fill 483 26 458 483 27 458 minecraft:orange_concrete
fill 485 26 458 485 31 458 minecraft:blackstone
fill 486 26 458 487 26 458 minecraft:orange_concrete
fill 488 26 458 488 31 458 minecraft:blackstone
fill 489 26 416 490 31 416 minecraft:blackstone
fill 491 26 416 492 27 416 minecraft:orange_concrete
fill 494 26 458 495 27 458 minecraft:orange_concrete
fill 496 26 458 497 31 458 minecraft:blackstone
fill 498 26 416 498 31 416 minecraft:blackstone
fill 499 26 416 500 26 416 minecraft:orange_concrete
fill 501 26 416 501 31 416 minecraft:blackstone
fill 503 26 416 503 27 416 minecraft:orange_concrete
fill 506 26 458 507 26 458 minecraft:orange_concrete
fill 508 26 458 509 31 458 minecraft:blackstone
fill 509 26 416 510 31 416 minecraft:blackstone
fill 511 26 416 512 27 416 minecraft:orange_concrete
setblock 512 26 424 minecraft:orange_concrete
fill 512 26 425 512 31 426 minecraft:blackstone
fill 512 26 427 512 27 428 minecraft:orange_concrete
fill 512 26 433 512 31 434 minecraft:blackstone
fill 512 26 435 512 26 436 minecraft:orange_concrete
fill 512 26 437 512 31 437 minecraft:blackstone
fill 512 26 445 512 31 446 minecraft:blackstone
fill 512 26 447 512 27 448 minecraft:orange_concrete
fill 512 26 454 512 31 454 minecraft:blackstone
setblock 512 26 456 minecraft:orange_concrete
fill 512 26 457 512 31 457 minecraft:blackstone
setblock 470 27 418 minecraft:orange_concrete
fill 470 27 422 470 29 423 minecraft:blackstone
fill 470 27 438 470 27 439 minecraft:orange_concrete
setblock 470 27 442 minecraft:orange_concrete
fill 470 27 443 470 30 443 minecraft:blackstone
fill 470 27 454 470 30 454 minecraft:blackstone
setblock 471 27 458 minecraft:orange_concrete
setblock 472 27 416 minecraft:orange_concrete
fill 478 27 440 479 28 441 minecraft:shroomlight
fill 479 27 416 479 30 416 minecraft:blackstone
setblock 480 27 416 minecraft:orange_concrete
setblock 482 27 458 minecraft:orange_concrete
setblock 483 27 416 minecraft:orange_concrete
fill 486 27 458 487 30 458 minecraft:blackstone
fill 499 27 416 500 30 416 minecraft:blackstone
setblock 503 27 458 minecraft:orange_concrete
setblock 504 27 416 minecraft:orange_concrete
setblock 506 27 458 minecraft:orange_concrete
fill 507 27 458 507 30 458 minecraft:blackstone
setblock 512 27 419 minecraft:orange_concrete
fill 512 27 424 512 30 424 minecraft:blackstone
fill 512 27 435 512 30 435 minecraft:blackstone
setblock 512 27 436 minecraft:orange_concrete
fill 512 27 439 512 27 440 minecraft:orange_concrete
fill 512 27 456 512 30 456 minecraft:blackstone
fill 470 28 416 470 29 417 minecraft:orange_concrete
fill 470 28 418 470 33 419 minecraft:blackstone
setblock 470 28 420 minecraft:orange_concrete
fill 470 28 421 470 31 421 minecraft:blackstone
fill 470 28 428 470 29 429 minecraft:orange_concrete
fill 470 28 430 470 33 431 minecraft:blackstone
fill 470 28 437 470 29 437 minecraft:orange_concrete
fill 470 28 438 470 33 439 minecraft:blackstone
setblock 470 28 440 minecraft:orange_concrete
fill 470 28 442 470 33 442 minecraft:blackstone
fill 470 28 448 470 29 449 minecraft:orange_concrete
fill 470 28 450 470 33 451 minecraft:blackstone
fill 471 28 416 472 33 416 minecraft:blackstone
fill 471 28 458 471 33 458 minecraft:blackstone
fill 472 28 458 473 28 458 minecraft:orange_concrete
fill 473 28 416 474 29 416 minecraft:orange_concrete
fill 474 28 458 475 33 458 minecraft:blackstone
fill 480 28 416 480 33 416 minecraft:blackstone
fill 480 28 458 481 29 458 minecraft:orange_concrete
fill 481 28 416 482 28 416 minecraft:orange_concrete
fill 482 28 458 483 33 458 minecraft:blackstone
fill 483 28 416 483 33 416 minecraft:blackstone
setblock 484 28 458 minecraft:orange_concrete
fill 485 28 416 485 29 416 minecraft:orange_concrete
fill 491 28 416 492 33 416 minecraft:blackstone
fill 492 28 458 493 29 458 minecraft:orange_concrete
fill 493 28 416 494 29 416 minecraft:orange_concrete
fill 494 28 458 495 33 458 minecraft:blackstone
fill 501 28 458 501 29 458 minecraft:orange_concrete
setblock 502 28 416 minecraft:orange_concrete
fill 503 28 416 504 33 416 minecraft:blackstone
fill 503 28 458 503 33 458 minecraft:blackstone
fill 504 28 458 505 28 458 minecraft:orange_concrete
fill 505 28 416 506 29 416 minecraft:orange_concrete
fill 506 28 458 506 33 458 minecraft:blackstone
fill 511 28 416 512 33 416 minecraft:blackstone
fill 512 28 417 512 28 418 minecraft:orange_concrete
fill 512 28 419 512 33 419 minecraft:blackstone
fill 512 28 427 512 33 428 minecraft:blackstone
fill 512 28 429 512 29 430 minecraft:orange_concrete
fill 512 28 436 512 33 436 minecraft:blackstone
setblock 512 28 438 minecraft:orange_concrete
fill 512 28 439 512 33 440 minecraft:blackstone
fill 512 28 441 512 29 441 minecraft:orange_concrete
fill 512 28 447 512 33 448 minecraft:blackstone
fill 512 28 449 512 28 450 minecraft:orange_concrete
fill 512 28 458 512 29 458 minecraft:orange_concrete
fill 470 29 420 470 31 420 minecraft:blackstone
setblock 470 29 425 minecraft:orange_concrete
setblock 470 29 436 minecraft:orange_concrete
fill 470 29 440 470 32 440 minecraft:blackstone
fill 470 29 456 470 29 457 minecraft:orange_concrete
setblock 472 29 458 minecraft:orange_concrete
fill 473 29 458 473 32 458 minecraft:blackstone
fill 481 29 416 482 32 416 minecraft:blackstone
fill 484 29 458 484 32 458 minecraft:blackstone
setblock 486 29 416 minecraft:orange_concrete
setblock 489 29 458 minecraft:orange_concrete
setblock 497 29 416 minecraft:orange_concrete
setblock 500 29 458 minecraft:orange_concrete
fill 502 29 416 502 32 416 minecraft:blackstone
fill 504 29 458 505 32 458 minecraft:blackstone
fill 512 29 417 512 32 417 minecraft:blackstone
setblock 512 29 418 minecraft:orange_concrete
fill 512 29 421 512 29 422 minecraft:orange_concrete
fill 512 29 438 512 32 438 minecraft:blackstone
setblock 512 29 442 minecraft:orange_concrete
fill 512 29 449 512 32 449 minecraft:blackstone
setblock 512 29 450 minecraft:orange_concrete
setblock 512 29 453 minecraft:orange_concrete
fill 470 30 416 470 35 417 minecraft:blackstone
setblock 470 30 422 minecraft:blackstone
fill 470 30 423 470 31 423 minecraft:orange_concrete
fill 470 30 425 470 35 425 minecraft:blackstone
fill 470 30 426 470 30 427 minecraft:orange_concrete
fill 470 30 428 470 32 429 minecraft:blackstone
fill 470 30 434 470 31 435 minecraft:orange_concrete
fill 470 30 436 470 35 437 minecraft:blackstone
fill 470 30 446 470 30 447 minecraft:orange_concrete
fill 470 30 448 470 35 449 minecraft:blackstone
fill 470 30 455 470 31 455 minecraft:orange_concrete
fill 470 30 456 470 35 457 minecraft:blackstone
setblock 470 30 458 minecraft:orange_concrete
fill 471 30 417 473 30 417 minecraft:red_nether_bricks
fill 471 30 419 471 30 421 minecraft:red_nether_bricks
fill 471 30 423 471 30 425 minecraft:red_nether_bricks
fill 471 30 427 471 30 429 minecraft:red_nether_bricks
fill 471 30 431 471 30 433 minecraft:red_nether_bricks
fill 471 30 435 471 30 437 minecraft:red_nether_bricks
fill 471 30 439 471 30 441 minecraft:red_nether_bricks
fill 471 30 443 471 30 445 minecraft:red_nether_bricks
fill 471 30 447 471 30 449 minecraft:red_nether_bricks
fill 471 30 451 471 30 453 minecraft:red_nether_bricks
fill 471 30 455 471 30 457 minecraft:red_nether_bricks
fill 472 30 458 472 35 458 minecraft:blackstone
fill 473 30 416 474 35 416 minecraft:blackstone
fill 473 30 457 475 30 457 minecraft:red_nether_bricks
fill 475 30 416 476 31 416 minecraft:orange_concrete
fill 475 30 417 477 30 417 minecraft:red_nether_bricks
fill 477 30 457 479 30 457 minecraft:red_nether_bricks
fill 478 30 458 479 31 458 minecraft:orange_concrete
fill 479 30 417 481 30 417 minecraft:red_nether_bricks
fill 480 30 458 481 35 458 minecraft:blackstone
fill 481 30 457 483 30 457 minecraft:red_nether_bricks
fill 483 30 417 485 30 417 minecraft:red_nether_bricks
setblock 484 30 416 minecraft:orange_concrete
fill 485 30 416 486 35 416 minecraft:blackstone
fill 485 30 457 487 30 457 minecraft:red_nether_bricks
fill 487 30 416 488 31 416 minecraft:orange_concrete
fill 487 30 417 489 30 417 minecraft:red_nether_bricks
fill 489 30 457 491 30 457 minecraft:red_nether_bricks
fill 489 30 458 489 35 458 minecraft:blackstone
fill 490 30 458 491 30 458 minecraft:orange_concrete
fill 491 30 417 493 30 417 minecraft:red_nether_bricks
fill 492 30 458 493 35 458 minecraft:blackstone
fill 493 30 416 494 35 416 minecraft:blackstone
fill 493 30 457 495 30 457 minecraft:red_nether_bricks
fill 495 30 416 496 30 416 minecraft:orange_concrete
fill 495 30 417 497 30 417 minecraft:red_nether_bricks
fill 497 30 416 497 35 416 minecraft:blackstone
fill 497 30 457 499 30 457 minecraft:red_nether_bricks
fill 498 30 458 499 31 458 minecraft:orange_concrete
fill 499 30 417 501 30 417 minecraft:red_nether_bricks
fill 500 30 458 501 35 458 minecraft:blackstone
fill 501 30 457 503 30 457 minecraft:red_nether_bricks
setblock 502 30 458 minecraft:orange_concrete
fill 503 30 417 505 30 417 minecraft:red_nether_bricks
fill 505 30 416 506 35 416 minecraft:blackstone
fill 505 30 457 507 30 457 minecraft:red_nether_bricks
fill 507 30 416 508 31 416 minecraft:orange_concrete
fill 507 30 417 509 30 417 minecraft:red_nether_bricks
fill 509 30 457 511 30 457 minecraft:red_nether_bricks
fill 510 30 458 511 31 458 minecraft:orange_concrete
fill 511 30 417 511 30 419 minecraft:red_nether_bricks
fill 511 30 421 511 30 423 minecraft:red_nether_bricks
fill 511 30 425 511 30 427 minecraft:red_nether_bricks
fill 511 30 429 511 30 431 minecraft:red_nether_bricks
fill 511 30 433 511 30 435 minecraft:red_nether_bricks
fill 511 30 437 511 30 439 minecraft:red_nether_bricks
fill 511 30 441 511 30 443 minecraft:red_nether_bricks
fill 511 30 445 511 30 447 minecraft:red_nether_bricks
fill 511 30 449 511 30 451 minecraft:red_nether_bricks
fill 511 30 453 511 30 455 minecraft:red_nether_bricks
fill 512 30 418 512 35 418 minecraft:blackstone
setblock 512 30 420 minecraft:orange_concrete
fill 512 30 421 512 35 422 minecraft:blackstone
fill 512 30 423 512 31 423 minecraft:orange_concrete
fill 512 30 429 512 35 430 minecraft:blackstone
fill 512 30 431 512 30 432 minecraft:orange_concrete
fill 512 30 441 512 35 442 minecraft:blackstone
fill 512 30 443 512 31 444 minecraft:orange_concrete
fill 512 30 450 512 35 450 minecraft:blackstone
fill 512 30 451 512 30 452 minecraft:orange_concrete
fill 512 30 453 512 35 453 minecraft:blackstone
fill 512 30 455 512 31 455 minecraft:orange_concrete
fill 512 30 458 512 35 458 minecraft:blackstone
setblock 470 31 422 minecraft:orange_concrete
setblock 470 31 426 minecraft:orange_concrete
fill 470 31 427 470 34 427 minecraft:blackstone
setblock 470 31 443 minecraft:orange_concrete
setblock 470 31 446 minecraft:orange_concrete
fill 470 31 447 470 34 447 minecraft:blackstone
setblock 470 31 454 minecraft:orange_concrete
fill 470 31 458 470 34 458 minecraft:blackstone
setblock 479 31 416 minecraft:orange_concrete
fill 484 31 416 484 34 416 minecraft:blackstone
fill 486 31 458 487 31 458 minecraft:orange_concrete
setblock 490 31 458 minecraft:orange_concrete
fill 491 31 458 491 34 458 minecraft:blackstone
fill 495 31 416 495 34 416 minecraft:blackstone
setblock 496 31 416 minecraft:orange_concrete
fill 499 31 416 500 31 416 minecraft:orange_concrete
fill 502 31 458 502 34 458 minecraft:blackstone
setblock 507 31 458 minecraft:orange_concrete
fill 512 31 420 512 34 420 minecraft:blackstone
setblock 512 31 424 minecraft:orange_concrete
fill 512 31 431 512 34 431 minecraft:blackstone
setblock 512 31 432 minecraft:orange_concrete
setblock 512 31 435 minecraft:orange_concrete
fill 512 31 451 512 34 452 minecraft:blackstone
setblock 512 31 456 minecraft:orange_concrete
fill 470 32 420 470 33 421 minecraft:orange_concrete
fill 470 32 422 470 50 423 minecraft:blackstone
setblock 470 32 424 minecraft:orange_concrete
fill 470 32 426 470 34 426 minecraft:blackstone
fill 470 32 432 470 33 433 minecraft:orange_concrete
fill 470 32 434 470 49 435 minecraft:blackstone
fill 470 32 441 470 33 441 minecraft:orange_concrete
fill 470 32 443 470 53 443 minecraft:blackstone
fill 470 32 444 470 32 445 minecraft:orange_concrete
fill 470 32 446 470 49 446 minecraft:blackstone
fill 470 32 452 470 33 453 minecraft:orange_concrete
fill 470 32 454 470 50 455 minecraft:blackstone
setblock 473 32 419 minecraft:light[level=14]
setblock 473 32 427 minecraft:light[level=14]
setblock 473 32 435 minecraft:light[level=14]
setblock 473 32 443 minecraft:light[level=14]
setblock 473 32 451 minecraft:light[level=14]
fill 475 32 416 476 34 416 minecraft:blackstone
fill 476 32 458 477 32 458 minecraft:orange_concrete
fill 477 32 416 478 32 416 minecraft:orange_concrete
fill 478 32 458 479 49 458 minecraft:blackstone
fill 479 32 416 479 53 416 minecraft:blackstone
setblock 481 32 419 minecraft:light[level=14]
setblock 481 32 427 minecraft:light[level=14]
setblock 481 32 435 minecraft:light[level=14]
setblock 481 32 443 minecraft:light[level=14]
setblock 481 32 451 minecraft:light[level=14]
fill 484 32 430 484 33 430 minecraft:shroomlight
fill 485 32 458 485 33 458 minecraft:orange_concrete
fill 486 32 458 487 53 458 minecraft:blackstone
fill 487 32 416 488 49 416 minecraft:blackstone
setblock 488 32 458 minecraft:orange_concrete
fill 489 32 416 490 33 416 minecraft:orange_concrete
setblock 489 32 419 minecraft:light[level=14]
setblock 489 32 427 minecraft:light[level=14]
setblock 489 32 435 minecraft:light[level=14]
setblock 489 32 443 minecraft:light[level=14]
fill 490 32 458 490 49 458 minecraft:blackstone
fill 496 32 416 496 49 416 minecraft:blackstone
fill 496 32 458 497 33 458 minecraft:orange_concrete
setblock 497 32 419 minecraft:light[level=14]
setblock 497 32 427 minecraft:light[level=14]
setblock 497 32 435 minecraft:light[level=14]
setblock 497 32 443 minecraft:light[level=14]
setblock 497 32 451 minecraft:light[level=14]
setblock 498 32 416 minecraft:orange_concrete
fill 498 32 458 499 50 458 minecraft:blackstone
fill 499 32 416 500 50 416 minecraft:blackstone
fill 501 32 416 501 33 416 minecraft:orange_concrete
setblock 505 32 419 minecraft:light[level=14]
setblock 505 32 427 minecraft:light[level=14]
setblock 505 32 435 minecraft:light[level=14]
setblock 505 32 443 minecraft:light[level=14]
setblock 505 32 451 minecraft:light[level=14]
fill 507 32 416 508 49 416 minecraft:blackstone
fill 507 32 458 507 53 458 minecraft:blackstone
fill 508 32 458 509 32 458 minecraft:orange_concrete
fill 509 32 416 510 32 416 minecraft:orange_concrete
fill 510 32 458 511 49 458 minecraft:blackstone
fill 512 32 423 512 50 424 minecraft:blackstone
fill 512 32 425 512 33 426 minecraft:orange_concrete
fill 512 32 432 512 49 432 minecraft:blackstone
fill 512 32 433 512 32 434 minecraft:orange_concrete
fill 512 32 435 512 53 435 minecraft:blackstone
fill 512 32 437 512 33 437 minecraft:orange_concrete
fill 512 32 443 512 49 444 minecraft:blackstone
fill 512 32 445 512 33 446 minecraft:orange_concrete
setblock 512 32 454 minecraft:orange_concrete
fill 512 32 455 512 50 456 minecraft:blackstone
fill 512 32 457 512 33 457 minecraft:orange_concrete
fill 470 33 424 470 36 424 minecraft:blackstone
fill 470 33 428 470 35 428 minecraft:blackstone
setblock 470 33 429 minecraft:orange_concrete
setblock 470 33 440 minecraft:orange_concrete
fill 470 33 444 470 36 445 minecraft:blackstone
setblock 473 33 458 minecraft:orange_concrete
setblock 476 33 458 minecraft:orange_concrete
fill 477 33 416 477 36 416 minecraft:blackstone
fill 477 33 458 477 36 458 minecraft:blackstone
setblock 478 33 416 minecraft:orange_concrete
fill 481 33 416 482 33 416 minecraft:orange_concrete
setblock 484 33 458 minecraft:orange_concrete
fill 488 33 458 488 36 458 minecraft:blackstone
fill 498 33 416 498 36 416 minecraft:blackstone
setblock 502 33 416 minecraft:orange_concrete
fill 504 33 458 505 33 458 minecraft:orange_concrete
setblock 508 33 458 minecraft:orange_concrete
fill 509 33 416 509 36 416 minecraft:blackstone
fill 509 33 458 509 36 458 minecraft:blackstone
setblock 510 33 416 minecraft:orange_concrete
setblock 512 33 417 minecraft:orange_concrete
fill 512 33 433 512 36 434 minecraft:blackstone
setblock 512 33 438 minecraft:orange_concrete
setblock 512 33 449 minecraft:orange_concrete
fill 512 33 454 512 36 454 minecraft:blackstone
fill 470 34 418 470 35 419 minecraft:orange_concrete
fill 470 34 420 470 47 421 minecraft:blackstone
fill 470 34 429 470 47 429 minecraft:blackstone
fill 470 34 430 470 34 431 minecraft:orange_concrete
fill 470 34 432 470 51 433 minecraft:blackstone
fill 470 34 438 470 35 439 minecraft:orange_concrete
fill 470 34 440 470 47 441 minecraft:blackstone
setblock 470 34 442 minecraft:orange_concrete
fill 470 34 450 470 35 451 minecraft:orange_concrete
fill 470 34 452 470 47 453 minecraft:blackstone
fill 471 34 416 472 35 416 minecraft:orange_concrete
fill 471 34 458 471 35 458 minecraft:orange_concrete
fill 473 34 458 473 47 458 minecraft:blackstone
fill 474 34 458 475 34 458 minecraft:orange_concrete
fill 476 34 458 476 51 458 minecraft:blackstone
fill 478 34 416 478 36 416 minecraft:blackstone
setblock 480 34 416 minecraft:orange_concrete
fill 481 34 416 482 47 416 minecraft:blackstone
fill 482 34 458 483 35 458 minecraft:orange_concrete
fill 483 34 416 483 35 416 minecraft:orange_concrete
fill 484 34 458 485 47 458 minecraft:blackstone
fill 487 34 450 488 34 454 minecraft:orange_concrete
fill 488 34 449 492 34 449 minecraft:orange_concrete
fill 488 34 455 495 34 455 minecraft:orange_concrete
fill 489 34 416 490 47 416 minecraft:blackstone
fill 489 34 450 489 36 450 minecraft:orange_concrete
fill 489 34 454 489 36 454 minecraft:orange_concrete
fill 491 34 416 492 34 416 minecraft:orange_concrete
fill 491 34 450 493 34 450 minecraft:orange_concrete
fill 491 34 454 493 35 454 minecraft:orange_concrete
fill 492 34 451 492 35 453 minecraft:orange_concrete
fill 493 34 451 496 34 451 minecraft:orange_concrete
fill 494 34 458 495 34 458 minecraft:orange_concrete
fill 495 34 454 496 34 454 minecraft:orange_concrete
fill 496 34 452 496 35 453 minecraft:orange_concrete
fill 496 34 458 497 47 458 minecraft:blackstone
fill 501 34 416 502 47 416 minecraft:blackstone
fill 503 34 416 504 35 416 minecraft:orange_concrete
fill 503 34 458 503 35 458 minecraft:orange_concrete
fill 504 34 458 505 47 458 minecraft:blackstone
setblock 506 34 458 minecraft:orange_concrete
fill 508 34 458 508 51 458 minecraft:blackstone
fill 510 34 416 510 51 416 minecraft:blackstone
fill 511 34 416 512 34 416 minecraft:orange_concrete
fill 512 34 417 512 47 417 minecraft:blackstone
fill 512 34 419 512 35 419 minecraft:orange_concrete
fill 512 34 425 512 47 426 minecraft:blackstone
fill 512 34 427 512 35 428 minecraft:orange_concrete
setblock 512 34 436 minecraft:orange_concrete
fill 512 34 437 512 47 438 minecraft:blackstone
fill 512 34 439 512 35 440 minecraft:orange_concrete
fill 512 34 445 512 51 446 minecraft:blackstone
fill 512 34 447 512 34 448 minecraft:orange_concrete
fill 512 34 449 512 47 449 minecraft:blackstone
fill 512 34 457 512 47 457 minecraft:blackstone
fill 470 35 426 470 35 427 minecraft:orange_concrete
setblock 470 35 430 minecraft:orange_concrete
fill 470 35 431 470 53 431 minecraft:blackstone
fill 470 35 442 470 53 442 minecraft:blackstone
setblock 470 35 447 minecraft:orange_concrete
setblock 470 35 458 minecraft:orange_concrete
fill 474 35 458 475 53 458 minecraft:blackstone
setblock 475 35 416 minecraft:orange_concrete
fill 476 35 416 476 49 416 minecraft:blackstone
fill 480 35 416 480 53 416 minecraft:blackstone
setblock 484 35 416 minecraft:orange_concrete
fill 487 35 452 488 35 452 minecraft:orange_concrete
fill 488 35 450 488 35 451 minecraft:orange_concrete
fill 488 35 453 488 35 454 minecraft:orange_concrete
fill 489 35 449 491 35 449 minecraft:orange_concrete
fill 489 35 455 491 35 455 minecraft:orange_concrete
fill 491 35 416 491 53 416 minecraft:blackstone
fill 491 35 450 492 35 450 minecraft:orange_concrete
setblock 491 35 458 minecraft:orange_concrete
setblock 492 35 416 minecraft:orange_concrete
fill 493 35 451 495 35 451 minecraft:orange_concrete
setblock 494 35 455 minecraft:orange_concrete
setblock 494 35 458 minecraft:orange_concrete
setblock 495 35 416 minecraft:orange_concrete
fill 495 35 454 495 36 454 minecraft:orange_concrete
fill 495 35 458 495 53 458 minecraft:blackstone
setblock 502 35 458 minecraft:orange_concrete
fill 506 35 458 506 53 458 minecraft:blackstone
fill 511 35 416 512 53 416 minecraft:blackstone
setblock 512 35 420 minecraft:orange_concrete
setblock 512 35 431 minecraft:orange_concrete
fill 512 35 436 512 53 436 minecraft:blackstone
fill 512 35 447 512 53 447 minecraft:blackstone
setblock 512 35 448 minecraft:orange_concrete
fill 512 35 451 512 35 452 minecraft:orange_concrete
fill 470 36 416 470 37 417 minecraft:orange_concrete
fill 470 36 418 470 49 419 minecraft:blackstone
fill 470 36 425 470 37 425 minecraft:orange_concrete
fill 470 36 426 470 49 427 minecraft:blackstone
setblock 470 36 428 minecraft:orange_concrete
fill 470 36 430 470 53 430 minecraft:blackstone
fill 470 36 436 470 37 437 minecraft:orange_concrete
fill 470 36 438 470 49 439 minecraft:blackstone
fill 470 36 447 470 49 447 minecraft:blackstone
fill 470 36 448 470 36 449 minecraft:orange_concrete
fill 470 36 450 470 53 451 minecraft:blackstone
fill 470 36 456 470 37 457 minecraft:orange_concrete
fill 470 36 458 471 49 458 minecraft:blackstone
fill 471 36 416 472 49 416 minecraft:blackstone
fill 471 36 417 473 36 417 minecraft:red_nether_bricks
fill 471 36 419 471 36 421 minecraft:red_nether_bricks
fill 471 36 423 471 36 425 minecraft:red_nether_bricks
fill 471 36 427 471 36 429 minecraft:red_nether_bricks
fill 471 36 431 471 36 433 minecraft:red_nether_bricks
fill 471 36 435 471 36 437 minecraft:red_nether_bricks
fill 471 36 439 471 36 441 minecraft:red_nether_bricks
fill 471 36 443 471 36 445 minecraft:red_nether_bricks
fill 471 36 447 471 36 449 minecraft:red_nether_bricks
fill 471 36 451 471 36 453 minecraft:red_nether_bricks
fill 471 36 455 471 36 457 minecraft:red_nether_bricks
setblock 472 36 458 minecraft:orange_concrete
fill 473 36 416 474 36 416 minecraft:orange_concrete
fill 473 36 457 475 36 457 minecraft:red_nether_bricks
fill 475 36 416 475 49 416 minecraft:blackstone
fill 475 36 417 477 36 417 minecraft:red_nether_bricks
fill 477 36 457 479 36 457 minecraft:red_nether_bricks
fill 479 36 417 481 36 417 minecraft:red_nether_bricks
fill 480 36 458 481 37 458 minecraft:orange_concrete
fill 481 36 457 483 36 457 minecraft:red_nether_bricks
fill 482 36 458 483 49 458 minecraft:blackstone
fill 483 36 416 484 49 416 minecraft:blackstone
fill 483 36 417 485 36 417 minecraft:red_nether_bricks
fill 485 36 416 486 37 416 minecraft:orange_concrete
fill 485 36 457 487 36 457 minecraft:red_nether_bricks
fill 487 36 417 489 36 417 minecraft:red_nether_bricks
fill 488 36 451 488 36 453 minecraft:orange_concrete
fill 489 36 457 491 36 457 minecraft:red_nether_bricks
fill 489 36 458 489 37 458 minecraft:orange_concrete
fill 491 36 417 493 36 417 minecraft:red_nether_bricks
setblock 491 36 450 minecraft:orange_concrete
setblock 491 36 454 minecraft:orange_concrete
fill 491 36 458 491 49 458 minecraft:blackstone
fill 492 36 416 492 53 416 minecraft:blackstone
setblock 492 36 451 minecraft:orange_concrete
fill 492 36 452 492 37 452 minecraft:red_nether_bricks
setblock 492 36 453 minecraft:orange_concrete
fill 492 36 458 493 36 458 minecraft:orange_concrete
fill 493 36 416 494 36 416 minecraft:orange_concrete
setblock 493 36 454 minecraft:orange_concrete
fill 493 36 457 495 36 457 minecraft:red_nether_bricks
setblock 494 36 451 minecraft:orange_concrete
fill 494 36 458 494 53 458 minecraft:blackstone
fill 495 36 416 495 49 416 minecraft:blackstone
fill 495 36 417 497 36 417 minecraft:red_nether_bricks
fill 497 36 416 497 37 416 minecraft:orange_concrete
fill 497 36 457 499 36 457 minecraft:red_nether_bricks
fill 499 36 417 501 36 417 minecraft:red_nether_bricks
fill 500 36 458 501 37 458 minecraft:orange_concrete
fill 501 36 457 503 36 457 minecraft:red_nether_bricks
fill 502 36 458 503 49 458 minecraft:blackstone
fill 503 36 416 504 49 416 minecraft:blackstone
fill 503 36 417 505 36 417 minecraft:red_nether_bricks
fill 505 36 416 506 37 416 minecraft:orange_concrete
fill 505 36 457 507 36 457 minecraft:red_nether_bricks
fill 507 36 417 509 36 417 minecraft:red_nether_bricks
fill 509 36 457 511 36 457 minecraft:red_nether_bricks
fill 511 36 417 511 36 419 minecraft:red_nether_bricks
fill 511 36 421 511 36 423 minecraft:red_nether_bricks
fill 511 36 425 511 36 427 minecraft:red_nether_bricks
fill 511 36 429 511 36 431 minecraft:red_nether_bricks
fill 511 36 433 511 36 435 minecraft:red_nether_bricks
fill 511 36 437 511 36 439 minecraft:red_nether_bricks
fill 511 36 441 511 36 443 minecraft:red_nether_bricks
fill 511 36 445 511 36 447 minecraft:red_nether_bricks
fill 511 36 449 511 36 451 minecraft:red_nether_bricks
fill 511 36 453 511 36 455 minecraft:red_nether_bricks
setblock 512 36 418 minecraft:orange_concrete
fill 512 36 419 512 49 420 minecraft:blackstone
fill 512 36 421 512 37 422 minecraft:orange_concrete
fill 512 36 427 512 53 428 minecraft:blackstone
fill 512 36 429 512 36 430 minecraft:orange_concrete
fill 512 36 431 512 49 431 minecraft:blackstone
fill 512 36 439 512 49 440 minecraft:blackstone
fill 512 36 441 512 37 442 minecraft:orange_concrete
fill 512 36 448 512 53 448 minecraft:blackstone
setblock 512 36 450 minecraft:orange_concrete
fill 512 36 451 512 49 452 minecraft:blackstone
fill 512 36 453 512 37 453 minecraft:orange_concrete
fill 512 36 458 512 37 458 minecraft:orange_concrete
setblock 470 37 424 minecraft:orange_concrete
fill 470 37 428 470 47 428 minecraft:blackstone
fill 470 37 444 470 37 445 minecraft:orange_concrete
setblock 470 37 448 minecraft:orange_concrete
fill 470 37 449 470 47 449 minecraft:blackstone
fill 472 37 458 472 47 458 minecraft:blackstone
fill 473 37 416 473 47 416 minecraft:blackstone
setblock 474 37 416 minecraft:orange_concrete
fill 477 37 416 478 37 416 minecraft:orange_concrete
setblock 477 37 458 minecraft:orange_concrete
setblock 488 37 458 minecraft:orange_concrete
fill 492 37 458 493 47 458 minecraft:blackstone
fill 493 37 416 494 47 416 minecraft:blackstone
setblock 498 37 416 minecraft:orange_concrete
setblock 509 37 416 minecraft:orange_concrete
setblock 509 37 458 minecraft:orange_concrete
fill 512 37 418 512 47 418 minecraft:blackstone
fill 512 37 429 512 47 429 minecraft:blackstone
setblock 512 37 430 minecraft:orange_concrete
fill 512 37 433 512 37 434 minecraft:orange_concrete
fill 512 37 450 512 47 450 minecraft:blackstone
setblock 512 37 454 minecraft:orange_concrete
fill 470 38 416 470 47 417 minecraft:blackstone
fill 470 38 424 470 51 425 minecraft:blackstone
fill 470 38 436 470 48 437 minecraft:blackstone
fill 470 38 444 470 51 445 minecraft:blackstone
fill 470 38 448 470 48 448 minecraft:blackstone
fill 470 38 456 470 51 457 minecraft:blackstone
fill 474 38 416 474 48 416 minecraft:blackstone
fill 477 38 416 478 51 416 minecraft:blackstone
fill 477 38 458 477 51 458 minecraft:blackstone
fill 480 38 458 481 48 458 minecraft:blackstone
fill 485 38 416 486 48 416 minecraft:blackstone
fill 488 38 458 489 51 458 minecraft:blackstone
fill 497 38 416 498 51 416 minecraft:blackstone
fill 500 38 458 501 48 458 minecraft:blackstone
fill 505 38 416 506 48 416 minecraft:blackstone
fill 509 38 416 509 51 416 minecraft:blackstone
fill 509 38 458 509 51 458 minecraft:blackstone
fill 512 38 421 512 51 422 minecraft:blackstone
fill 512 38 430 512 48 430 minecraft:blackstone
fill 512 38 433 512 51 434 minecraft:blackstone
fill 512 38 441 512 48 442 minecraft:blackstone
fill 512 38 453 512 51 454 minecraft:blackstone
fill 512 38 458 512 48 458 minecraft:blackstone
setblock 473 40 419 minecraft:light[level=14]
setblock 473 40 427 minecraft:light[level=14]
setblock 473 40 435 minecraft:light[level=14]
setblock 473 40 443 minecraft:light[level=14]
setblock 473 40 451 minecraft:light[level=14]
setblock 481 40 419 minecraft:light[level=14]
setblock 481 40 427 minecraft:light[level=14]
setblock 481 40 435 minecraft:light[level=14]
setblock 481 40 443 minecraft:light[level=14]
setblock 481 40 451 minecraft:light[level=14]
setblock 489 40 419 minecraft:light[level=14]
setblock 489 40 427 minecraft:light[level=14]
setblock 489 40 435 minecraft:light[level=14]
setblock 489 40 443 minecraft:light[level=14]
setblock 489 40 451 minecraft:light[level=14]
setblock 497 40 419 minecraft:light[level=14]
setblock 497 40 427 minecraft:light[level=14]
setblock 497 40 435 minecraft:light[level=14]
setblock 497 40 443 minecraft:light[level=14]
setblock 497 40 451 minecraft:light[level=14]
setblock 505 40 419 minecraft:light[level=14]
setblock 505 40 427 minecraft:light[level=14]
setblock 505 40 435 minecraft:light[level=14]
setblock 505 40 443 minecraft:light[level=14]
setblock 505 40 451 minecraft:light[level=14]
fill 486 42 432 488 42 434 minecraft:redstone_block
fill 492 42 432 494 42 434 minecraft:redstone_block
fill 493 42 439 495 42 441 minecraft:redstone_block
fill 475 43 437 479 44 437 minecraft:red_nether_bricks
fill 476 43 432 479 44 436 minecraft:red_nether_bricks
fill 476 43 438 479 44 442 minecraft:red_nether_bricks
fill 477 43 430 482 44 431 minecraft:red_nether_bricks
fill 477 43 443 479 44 444 minecraft:red_nether_bricks
fill 478 43 428 486 44 429 minecraft:red_nether_bricks
fill 478 43 445 480 44 446 minecraft:red_nether_bricks
fill 479 43 427 499 44 427 minecraft:red_nether_bricks
fill 479 43 447 482 44 447 minecraft:red_nether_bricks
fill 480 43 426 498 44 426 minecraft:red_nether_bricks
fill 480 43 432 480 44 434 minecraft:red_nether_bricks
fill 480 43 435 483 44 443 minecraft:magma_block
fill 480 43 444 480 44 444 minecraft:red_nether_bricks
fill 480 43 448 483 44 448 minecraft:red_nether_bricks
fill 481 43 425 497 44 425 minecraft:red_nether_bricks
fill 481 43 432 481 44 432 minecraft:red_nether_bricks
fill 481 43 433 485 43 434 minecraft:magma_block
fill 481 43 444 485 44 445 minecraft:magma_block
fill 481 43 446 481 44 446 minecraft:red_nether_bricks
fill 481 43 449 485 44 449 minecraft:red_nether_bricks
fill 482 43 432 485 43 432 minecraft:magma_block
fill 482 43 446 489 44 446 minecraft:magma_block
fill 483 43 424 495 44 424 minecraft:red_nether_bricks
fill 483 43 430 484 44 430 minecraft:red_nether_bricks
fill 483 43 431 493 43 431 minecraft:magma_block
fill 483 43 447 501 44 447 minecraft:magma_block
fill 483 43 450 487 44 450 minecraft:red_nether_bricks
fill 484 43 435 484 44 436 minecraft:magma_block
fill 484 43 437 486 44 441 minecraft:red_nether_bricks
fill 484 43 442 484 44 443 minecraft:magma_block
fill 484 43 448 500 44 448 minecraft:magma_block
fill 485 43 423 493 44 423 minecraft:red_nether_bricks
fill 485 43 430 492 44 430 minecraft:magma_block
fill 485 43 435 486 43 436 minecraft:red_nether_bricks
fill 485 43 442 499 43 443 minecraft:red_nether_bricks
fill 485 43 451 495 44 451 minecraft:red_nether_bricks
fill 486 43 444 498 44 444 minecraft:red_nether_bricks
fill 486 43 445 486 44 445 minecraft:magma_block
fill 486 43 449 498 44 449 minecraft:magma_block
fill 487 43 428 499 44 428 minecraft:red_nether_bricks
fill 487 43 429 489 44 429 minecraft:magma_block
setblock 487 43 435 minecraft:red_nether_bricks
fill 487 43 436 488 43 438 minecraft:obsidian
fill 487 43 439 487 44 441 minecraft:red_nether_bricks
fill 487 43 445 496 44 445 minecraft:red_nether_bricks
fill 488 43 435 492 43 435 minecraft:obsidian
fill 488 43 439 492 43 439 minecraft:obsidian
fill 488 43 440 488 44 441 minecraft:red_nether_bricks
fill 488 43 450 496 44 450 minecraft:magma_block
fill 489 43 432 491 43 433 minecraft:magma_block
fill 489 43 434 491 43 434 minecraft:obsidian
fill 489 43 440 491 44 440 minecraft:obsidian
fill 489 43 441 492 43 441 minecraft:red_nether_bricks
fill 490 43 422 490 44 422 minecraft:magma_block
fill 490 43 429 500 44 429 minecraft:red_nether_bricks
fill 490 43 446 494 44 446 minecraft:red_nether_bricks
fill 490 43 452 490 44 452 minecraft:red_nether_bricks
fill 492 43 436 493 43 438 minecraft:obsidian
setblock 492 43 440 minecraft:red_nether_bricks
fill 493 43 430 501 44 430 minecraft:red_nether_bricks
fill 493 43 435 495 43 435 minecraft:magma_block
fill 494 43 423 495 44 423 minecraft:magma_block
fill 494 43 431 501 43 431 minecraft:red_nether_bricks
fill 494 43 436 494 43 438 minecraft:magma_block
fill 495 43 432 501 43 433 minecraft:red_nether_bricks
setblock 495 43 434 minecraft:magma_block
fill 495 43 436 495 44 437 minecraft:magma_block
fill 495 43 438 501 43 438 minecraft:red_nether_bricks
fill 495 43 446 502 44 446 minecraft:magma_block
fill 496 43 424 497 44 424 minecraft:magma_block
fill 496 43 434 502 44 437 minecraft:red_nether_bricks
fill 496 43 439 500 43 441 minecraft:red_nether_bricks
fill 497 43 445 502 44 445 minecraft:magma_block
fill 497 43 450 497 44 450 minecraft:red_nether_bricks
fill 498 43 425 499 44 425 minecraft:magma_block
fill 499 43 426 500 44 426 minecraft:magma_block
fill 499 43 444 503 44 444 minecraft:magma_block
fill 499 43 449 499 44 449 minecraft:red_nether_bricks
fill 500 43 427 501 44 428 minecraft:magma_block
fill 500 43 442 500 44 442 minecraft:red_nether_bricks
fill 500 43 443 503 44 443 minecraft:magma_block
fill 501 43 429 502 44 429 minecraft:magma_block
fill 501 43 439 501 44 440 minecraft:red_nether_bricks
fill 501 43 441 504 44 442 minecraft:magma_block
fill 502 43 428 502 44 428 minecraft:magma_block
fill 502 43 430 503 44 432 minecraft:magma_block
fill 502 43 433 502 44 433 minecraft:red_nether_bricks
fill 502 43 438 504 44 440 minecraft:magma_block
fill 503 43 433 504 44 437 minecraft:magma_block
fill 504 43 432 504 44 432 minecraft:magma_block
fill 505 43 437 505 44 437 minecraft:magma_block
fill 471 44 417 474 44 457 minecraft:blackstone
fill 475 44 417 475 44 436 minecraft:blackstone
fill 475 44 438 475 44 457 minecraft:blackstone
fill 476 44 417 476 44 431 minecraft:blackstone
fill 476 44 443 476 44 457 minecraft:blackstone
fill 477 44 417 477 44 429 minecraft:blackstone
fill 477 44 445 477 44 457 minecraft:blackstone
fill 478 44 417 478 44 427 minecraft:blackstone
fill 478 44 447 478 44 457 minecraft:blackstone
fill 479 44 417 479 44 426 minecraft:blackstone
fill 479 44 448 479 44 457 minecraft:blackstone
fill 480 44 417 480 44 425 minecraft:blackstone
fill 480 44 449 480 44 457 minecraft:blackstone
fill 481 44 417 482 44 424 minecraft:blackstone
fill 481 44 433 484 44 434 minecraft:magma_block
fill 481 44 450 482 44 457 minecraft:blackstone
fill 482 44 432 484 44 432 minecraft:magma_block
fill 483 44 417 484 44 423 minecraft:blackstone
fill 483 44 431 484 44 431 minecraft:magma_block
fill 483 44 451 484 44 457 minecraft:blackstone
fill 485 44 417 489 44 422 minecraft:blackstone
fill 485 44 431 485 44 435 minecraft:shroomlight
fill 485 44 436 486 44 436 minecraft:red_nether_bricks
fill 485 44 442 491 44 443 minecraft:red_nether_bricks
fill 485 44 452 489 44 457 minecraft:blackstone
fill 486 44 431 489 44 431 minecraft:shroomlight
fill 486 44 432 488 44 434 minecraft:blackstone
fill 486 44 435 495 44 435 minecraft:shroomlight
fill 487 44 436 487 44 438 minecraft:obsidian
fill 488 44 436 488 44 439 minecraft:shroomlight
fill 489 44 432 489 44 434 minecraft:shroomlight
fill 489 44 439 492 44 439 minecraft:shroomlight
fill 489 44 441 491 44 441 minecraft:red_nether_bricks
fill 490 44 417 511 44 421 minecraft:blackstone
fill 490 44 431 490 44 433 minecraft:magma_block
setblock 490 44 434 minecraft:obsidian
fill 490 44 453 511 44 457 minecraft:blackstone
fill 491 44 422 511 44 422 minecraft:blackstone
fill 491 44 431 491 44 434 minecraft:shroomlight
fill 491 44 452 511 44 452 minecraft:blackstone
fill 492 44 431 495 44 431 minecraft:shroomlight
fill 492 44 432 494 44 434 minecraft:blackstone
fill 492 44 436 492 44 438 minecraft:shroomlight
fill 492 44 440 492 44 442 minecraft:shroomlight
fill 492 44 443 499 44 443 minecraft:red_nether_bricks
fill 493 44 436 493 44 437 minecraft:obsidian
fill 493 44 438 496 44 438 minecraft:shroomlight
fill 493 44 439 495 44 441 minecraft:blackstone
fill 493 44 442 496 44 442 minecraft:shroomlight
fill 494 44 436 494 44 437 minecraft:magma_block
fill 495 44 432 495 44 434 minecraft:shroomlight
fill 496 44 423 511 44 423 minecraft:blackstone
fill 496 44 431 501 44 433 minecraft:red_nether_bricks
fill 496 44 439 496 44 441 minecraft:shroomlight
fill 496 44 451 511 44 451 minecraft:blackstone
fill 497 44 438 499 44 442 minecraft:red_nether_bricks
fill 498 44 424 511 44 424 minecraft:blackstone
fill 498 44 450 511 44 450 minecraft:blackstone
fill 500 44 425 511 44 425 minecraft:blackstone
fill 500 44 438 500 44 441 minecraft:red_nether_bricks
fill 500 44 449 511 44 449 minecraft:blackstone
fill 501 44 426 511 44 426 minecraft:blackstone
setblock 501 44 438 minecraft:red_nether_bricks
fill 501 44 448 511 44 448 minecraft:blackstone
fill 502 44 427 511 44 427 minecraft:blackstone
fill 502 44 447 511 44 447 minecraft:blackstone
fill 503 44 428 511 44 429 minecraft:blackstone
fill 503 44 445 511 44 446 minecraft:blackstone
fill 504 44 430 511 44 431 minecraft:blackstone
fill 504 44 443 511 44 444 minecraft:blackstone
fill 505 44 432 511 44 436 minecraft:blackstone
fill 505 44 438 511 44 442 minecraft:blackstone
fill 506 44 437 511 44 437 minecraft:blackstone
setblock 470 48 416 minecraft:blackstone
fill 470 48 417 470 49 417 minecraft:orange_concrete
fill 470 48 420 470 48 421 minecraft:orange_concrete
fill 470 48 428 470 49 429 minecraft:orange_concrete
fill 470 48 440 470 48 441 minecraft:orange_concrete
fill 470 48 449 470 49 449 minecraft:orange_concrete
setblock 470 48 452 minecraft:orange_concrete
fill 470 48 453 470 51 453 minecraft:blackstone
fill 471 48 417 473 48 417 minecraft:red_nether_bricks
fill 471 48 419 471 48 421 minecraft:red_nether_bricks
fill 471 48 423 471 48 425 minecraft:red_nether_bricks
fill 471 48 427 471 48 429 minecraft:red_nether_bricks
fill 471 48 431 471 48 433 minecraft:red_nether_bricks
fill 471 48 435 471 48 437 minecraft:red_nether_bricks
fill 471 48 439 471 48 441 minecraft:red_nether_bricks
fill 471 48 443 471 48 445 minecraft:red_nether_bricks
fill 471 48 447 471 48 449 minecraft:red_nether_bricks
fill 471 48 451 471 48 453 minecraft:red_nether_bricks
fill 471 48 455 471 48 457 minecraft:red_nether_bricks
fill 472 48 458 473 49 458 minecraft:orange_concrete
fill 473 48 416 473 49 416 minecraft:orange_concrete
setblock 473 48 419 minecraft:light[level=14]
setblock 473 48 427 minecraft:light[level=14]
setblock 473 48 435 minecraft:light[level=14]
setblock 473 48 443 minecraft:light[level=14]
setblock 473 48 451 minecraft:light[level=14]
fill 473 48 457 475 48 457 minecraft:red_nether_bricks
fill 475 48 417 477 48 417 minecraft:red_nether_bricks
fill 477 48 457 479 48 457 minecraft:red_nether_bricks
fill 479 48 417 481 48 417 minecraft:red_nether_bricks
fill 481 48 416 482 49 416 minecraft:orange_concrete
setblock 481 48 419 minecraft:light[level=14]
setblock 481 48 427 minecraft:light[level=14]
setblock 481 48 435 minecraft:light[level=14]
setblock 481 48 443 minecraft:light[level=14]
setblock 481 48 451 minecraft:light[level=14]
fill 481 48 457 483 48 457 minecraft:red_nether_bricks
fill 483 48 417 485 48 417 minecraft:red_nether_bricks
fill 484 48 458 485 48 458 minecraft:orange_concrete
fill 485 48 457 487 48 457 minecraft:red_nether_bricks
fill 487 48 417 489 48 417 minecraft:red_nether_bricks
fill 489 48 416 489 51 416 minecraft:blackstone
setblock 489 48 419 minecraft:light[level=14]
setblock 489 48 427 minecraft:light[level=14]
setblock 489 48 435 minecraft:light[level=14]
setblock 489 48 443 minecraft:light[level=14]
setblock 489 48 451 minecraft:light[level=14]
fill 489 48 457 491 48 457 minecraft:red_nether_bricks
setblock 490 48 416 minecraft:orange_concrete
fill 491 48 417 493 48 417 minecraft:red_nether_bricks
fill 492 48 458 493 49 458 minecraft:orange_concrete
fill 493 48 416 494 49 416 minecraft:orange_concrete
fill 493 48 457 495 48 457 minecraft:red_nether_bricks
fill 495 48 417 497 48 417 minecraft:red_nether_bricks
setblock 496 48 458 minecraft:orange_concrete
setblock 497 48 419 minecraft:light[level=14]
setblock 497 48 427 minecraft:light[level=14]
setblock 497 48 435 minecraft:light[level=14]
setblock 497 48 443 minecraft:light[level=14]
setblock 497 48 451 minecraft:light[level=14]
fill 497 48 457 499 48 457 minecraft:red_nether_bricks
fill 497 48 458 497 51 458 minecraft:blackstone
fill 499 48 417 501 48 417 minecraft:red_nether_bricks
fill 501 48 416 502 48 416 minecraft:orange_concrete
fill 501 48 457 503 48 457 minecraft:red_nether_bricks
fill 503 48 417 505 48 417 minecraft:red_nether_bricks
fill 504 48 458 505 49 458 minecraft:orange_concrete
setblock 505 48 419 minecraft:light[level=14]
setblock 505 48 427 minecraft:light[level=14]
setblock 505 48 435 minecraft:light[level=14]
setblock 505 48 443 minecraft:light[level=14]
setblock 505 48 451 minecraft:light[level=14]
fill 505 48 457 507 48 457 minecraft:red_nether_bricks
fill 507 48 417 509 48 417 minecraft:red_nether_bricks
fill 509 48 457 511 48 457 minecraft:red_nether_bricks
fill 511 48 417 511 48 419 minecraft:red_nether_bricks
fill 511 48 421 511 48 423 minecraft:red_nether_bricks
fill 511 48 425 511 48 427 minecraft:red_nether_bricks
fill 511 48 429 511 48 431 minecraft:red_nether_bricks
fill 511 48 433 511 48 435 minecraft:red_nether_bricks
fill 511 48 437 511 48 439 minecraft:red_nether_bricks
fill 511 48 441 511 48 443 minecraft:red_nether_bricks
fill 511 48 445 511 48 447 minecraft:red_nether_bricks
fill 511 48 449 511 48 451 minecraft:red_nether_bricks
fill 511 48 453 511 48 455 minecraft:red_nether_bricks
fill 512 48 417 512 49 418 minecraft:orange_concrete
fill 512 48 425 512 51 425 minecraft:blackstone
setblock 512 48 426 minecraft:orange_concrete
fill 512 48 429 512 49 429 minecraft:orange_concrete
fill 512 48 437 512 48 438 minecraft:orange_concrete
fill 512 48 449 512 49 450 minecraft:orange_concrete
setblock 512 48 457 minecraft:orange_concrete
setblock 470 49 416 minecraft:orange_concrete
fill 470 49 420 470 52 421 minecraft:blackstone
fill 470 49 436 470 51 436 minecraft:blackstone
setblock 470 49 437 minecraft:orange_concrete
setblock 470 49 440 minecraft:orange_concrete
fill 470 49 441 470 52 441 minecraft:blackstone
setblock 470 49 448 minecraft:orange_concrete
fill 470 49 452 470 52 452 minecraft:blackstone
setblock 474 49 416 minecraft:orange_concrete
fill 480 49 458 481 49 458 minecraft:orange_concrete
setblock 484 49 458 minecraft:orange_concrete
setblock 485 49 416 minecraft:orange_concrete
fill 485 49 458 485 52 458 minecraft:blackstone
fill 486 49 416 486 51 416 minecraft:blackstone
fill 490 49 416 490 51 416 minecraft:blackstone
fill 496 49 458 496 52 458 minecraft:blackstone
fill 500 49 458 500 51 458 minecraft:blackstone
fill 501 49 416 501 52 416 minecraft:blackstone
setblock 501 49 458 minecraft:orange_concrete
setblock 502 49 416 minecraft:orange_concrete
fill 505 49 416 506 49 416 minecraft:orange_concrete
fill 512 49 426 512 52 426 minecraft:blackstone
setblock 512 49 430 minecraft:orange_concrete
fill 512 49 437 512 52 437 minecraft:blackstone
setblock 512 49 438 minecraft:orange_concrete
setblock 512 49 441 minecraft:orange_concrete
fill 512 49 442 512 51 442 minecraft:blackstone
fill 512 49 457 512 52 457 minecraft:blackstone
setblock 512 49 458 minecraft:orange_concrete
fill 470 50 416 470 55 417 minecraft:blackstone
setblock 470 50 418 minecraft:orange_concrete
fill 470 50 419 470 53 419 minecraft:blackstone
fill 470 50 426 470 51 427 minecraft:orange_concrete
fill 470 50 428 470 55 429 minecraft:blackstone
setblock 470 50 434 minecraft:blackstone
fill 470 50 435 470 51 435 minecraft:orange_concrete
fill 470 50 437 470 55 437 minecraft:blackstone
fill 470 50 438 470 50 439 minecraft:orange_concrete
fill 470 50 440 470 55 440 minecraft:blackstone
fill 470 50 446 470 51 447 minecraft:orange_concrete
fill 470 50 448 470 55 449 minecraft:blackstone
fill 470 50 458 471 50 458 minecraft:orange_concrete
fill 471 50 416 471 53 416 minecraft:blackstone
fill 471 50 445 472 53 447 minecraft:magma_block
setblock 472 50 416 minecraft:orange_concrete
fill 472 50 458 473 55 458 minecraft:blackstone
fill 473 50 416 474 55 416 minecraft:blackstone
fill 475 50 416 476 51 416 minecraft:orange_concrete
setblock 478 50 458 minecraft:blackstone
fill 479 50 458 479 51 458 minecraft:orange_concrete
fill 480 50 458 481 55 458 minecraft:blackstone
fill 481 50 416 482 52 416 minecraft:blackstone
setblock 482 50 458 minecraft:orange_concrete
fill 483 50 416 484 50 416 minecraft:orange_concrete
fill 483 50 458 484 53 458 minecraft:blackstone
fill 485 50 416 485 55 416 minecraft:blackstone
fill 487 50 416 487 51 416 minecraft:orange_concrete
setblock 488 50 416 minecraft:blackstone
fill 490 50 458 491 51 458 minecraft:orange_concrete
fill 492 50 458 493 55 458 minecraft:blackstone
fill 493 50 416 494 55 416 minecraft:blackstone
fill 495 50 416 496 51 416 minecraft:orange_concrete
fill 501 50 458 501 55 458 minecraft:blackstone
fill 502 50 416 503 52 416 minecraft:blackstone
fill 502 50 458 503 50 458 minecraft:orange_concrete
setblock 504 50 416 minecraft:orange_concrete
fill 504 50 458 505 55 458 minecraft:blackstone
fill 505 50 416 506 55 416 minecraft:blackstone
fill 507 50 416 507 51 416 minecraft:orange_concrete
setblock 508 50 416 minecraft:blackstone
fill 510 50 458 511 51 458 minecraft:orange_concrete
fill 512 50 417 512 55 418 minecraft:blackstone
fill 512 50 419 512 50 420 minecraft:orange_concrete
fill 512 50 429 512 55 430 minecraft:blackstone
fill 512 50 431 512 51 432 minecraft:orange_concrete
fill 512 50 438 512 55 438 minecraft:blackstone
fill 512 50 439 512 50 440 minecraft:orange_concrete
fill 512 50 441 512 55 441 minecraft:blackstone
fill 512 50 443 512 51 443 minecraft:orange_concrete
setblock 512 50 444 minecraft:blackstone
fill 512 50 449 512 55 450 minecraft:blackstone
fill 512 50 451 512 51 452 minecraft:orange_concrete
fill 512 50 458 512 55 458 minecraft:blackstone
fill 470 51 418 470 54 418 minecraft:blackstone
fill 470 51 422 470 53 422 minecraft:blackstone
setblock 470 51 423 minecraft:orange_concrete
setblock 470 51 434 minecraft:orange_concrete
fill 470 51 438 470 54 439 minecraft:blackstone
fill 470 51 454 470 53 454 minecraft:blackstone
setblock 470 51 455 minecraft:orange_concrete
setblock 470 51 458 minecraft:orange_concrete
fill 471 51 444 471 52 444 minecraft:magma_block
fill 471 51 448 471 52 448 minecraft:magma_block
fill 471 51 458 471 54 458 minecraft:blackstone
fill 472 51 416 472 53 416 minecraft:blackstone
fill 473 51 445 473 53 447 minecraft:magma_block
setblock 478 51 458 minecraft:orange_concrete
fill 482 51 458 482 54 458 minecraft:blackstone
fill 483 51 416 483 54 416 minecraft:blackstone
setblock 484 51 416 minecraft:orange_concrete
setblock 488 51 416 minecraft:orange_concrete
fill 498 51 458 499 51 458 minecraft:orange_concrete
setblock 499 51 416 minecraft:orange_concrete
fill 500 51 416 500 53 416 minecraft:blackstone
setblock 502 51 458 minecraft:orange_concrete
fill 503 51 458 503 54 458 minecraft:blackstone
fill 504 51 416 504 54 416 minecraft:blackstone
setblock 508 51 416 minecraft:orange_concrete
fill 512 51 419 512 54 419 minecraft:blackstone
setblock 512 51 420 minecraft:orange_concrete
setblock 512 51 423 minecraft:orange_concrete
fill 512 51 424 512 53 424 minecraft:blackstone
fill 512 51 439 512 54 440 minecraft:blackstone
setblock 512 51 444 minecraft:orange_concrete
setblock 512 51 455 minecraft:orange_concrete
fill 512 51 456 512 53 456 minecraft:blackstone
fill 470 52 423 470 57 423 minecraft:blackstone
fill 470 52 424 470 52 425 minecraft:orange_concrete
fill 470 52 426 470 57 427 minecraft:blackstone
fill 470 52 432 470 53 433 minecraft:orange_concrete
fill 470 52 434 470 57 435 minecraft:blackstone
setblock 470 52 436 minecraft:orange_concrete
fill 470 52 444 470 53 445 minecraft:orange_concrete
fill 470 52 446 470 57 447 minecraft:blackstone
fill 470 52 453 470 53 453 minecraft:orange_concrete
fill 470 52 455 470 57 455 minecraft:blackstone
fill 470 52 456 470 52 457 minecraft:orange_concrete
fill 470 52 458 470 57 458 minecraft:blackstone
fill 474 52 445 474 53 447 minecraft:magma_block
fill 475 52 416 476 57 416 minecraft:blackstone
fill 476 52 458 477 53 458 minecraft:orange_concrete
fill 477 52 416 478 53 416 minecraft:orange_concrete
fill 478 52 458 479 57 458 minecraft:blackstone
fill 484 52 416 484 54 416 minecraft:blackstone
setblock 486 52 416 minecraft:orange_concrete
fill 487 52 416 488 57 416 minecraft:blackstone
fill 488 52 458 489 52 458 minecraft:orange_concrete
fill 489 52 416 490 53 416 minecraft:orange_concrete
fill 490 52 458 491 57 458 minecraft:blackstone
fill 493 52 418 494 53 419 minecraft:magma_block
fill 495 52 416 496 57 416 minecraft:blackstone
fill 497 52 416 498 52 416 minecraft:orange_concrete
fill 497 52 458 497 53 458 minecraft:orange_concrete
fill 498 52 458 499 57 458 minecraft:blackstone
fill 499 52 416 499 53 416 minecraft:blackstone
setblock 500 52 458 minecraft:orange_concrete
fill 502 52 458 502 57 458 minecraft:blackstone
fill 507 52 416 508 57 416 minecraft:blackstone
fill 508 52 458 509 53 458 minecraft:orange_concrete
fill 509 52 416 510 53 416 minecraft:orange_concrete
fill 510 52 458 511 57 458 minecraft:blackstone
fill 512 52 420 512 57 420 minecraft:blackstone
fill 512 52 421 512 52 422 minecraft:orange_concrete
fill 512 52 423 512 57 423 minecraft:blackstone
fill 512 52 425 512 53 425 minecraft:orange_concrete
fill 512 52 431 512 57 432 minecraft:blackstone
fill 512 52 433 512 53 434 minecraft:orange_concrete
setblock 512 52 442 minecraft:orange_concrete
fill 512 52 443 512 57 444 minecraft:blackstone
fill 512 52 445 512 53 446 minecraft:orange_concrete
fill 512 52 451 512 57 452 minecraft:blackstone
fill 512 52 453 512 52 454 minecraft:orange_concrete
fill 512 52 455 512 57 455 minecraft:blackstone
fill 470 53 420 470 53 421 minecraft:orange_concrete
setblock 470 53 424 minecraft:orange_concrete
fill 470 53 425 470 56 425 minecraft:blackstone
fill 470 53 436 470 56 436 minecraft:blackstone
setblock 470 53 441 minecraft:orange_concrete
setblock 470 53 452 minecraft:orange_concrete
fill 470 53 456 470 56 457 minecraft:blackstone
fill 475 53 446 475 54 446 minecraft:magma_block
setblock 481 53 416 minecraft:orange_concrete
fill 482 53 416 482 55 416 minecraft:blackstone
setblock 485 53 458 minecraft:orange_concrete
fill 486 53 416 486 56 416 minecraft:blackstone
setblock 488 53 458 minecraft:orange_concrete
fill 489 53 458 489 56 458 minecraft:blackstone
setblock 496 53 458 minecraft:orange_concrete
fill 497 53 416 497 56 416 minecraft:blackstone
setblock 498 53 416 minecraft:orange_concrete
fill 500 53 458 500 56 458 minecraft:blackstone
fill 501 53 416 502 53 416 minecraft:orange_concrete
setblock 503 53 416 minecraft:blackstone
fill 512 53 421 512 56 422 minecraft:blackstone
setblock 512 53 426 minecraft:orange_concrete
setblock 512 53 437 minecraft:orange_concrete
fill 512 53 442 512 56 442 minecraft:blackstone
fill 512 53 453 512 56 453 minecraft:blackstone
setblock 512 53 454 minecraft:orange_concrete
setblock 512 53 457 minecraft:orange_concrete
fill 470 54 419 470 55 419 minecraft:orange_concrete
fill 470 54 420 470 59 421 minecraft:blackstone
setblock 470 54 422 minecraft:orange_concrete
fill 470 54 424 470 59 424 minecraft:blackstone
fill 470 54 430 470 55 431 minecraft:orange_concrete
fill 470 54 432 470 59 433 minecraft:blackstone
fill 470 54 441 470 59 441 minecraft:blackstone
fill 470 54 442 470 54 443 minecraft:orange_concrete
fill 470 54 444 470 59 445 minecraft:blackstone
fill 470 54 450 470 55 451 minecraft:orange_concrete
fill 470 54 452 470 59 453 minecraft:blackstone
setblock 470 54 454 minecraft:orange_concrete
fill 471 54 416 472 55 416 minecraft:orange_concrete
fill 471 54 417 473 54 417 minecraft:red_nether_bricks
fill 471 54 419 471 54 421 minecraft:red_nether_bricks
fill 471 54 423 471 54 425 minecraft:red_nether_bricks
fill 471 54 427 471 54 429 minecraft:red_nether_bricks
fill 471 54 431 471 54 433 minecraft:red_nether_bricks
fill 471 54 435 471 54 437 minecraft:red_nether_bricks
fill 471 54 439 471 54 441 minecraft:red_nether_bricks
fill 471 54 443 471 54 445 minecraft:red_nether_bricks
fill 471 54 447 471 54 449 minecraft:red_nether_bricks
fill 471 54 451 471 54 453 minecraft:red_nether_bricks
fill 471 54 455 471 54 457 minecraft:red_nether_bricks
fill 473 54 446 474 54 446 minecraft:magma_block
fill 473 54 457 475 54 457 minecraft:red_nether_bricks
fill 474 54 458 475 55 458 minecraft:orange_concrete
fill 475 54 417 477 54 417 minecraft:red_nether_bricks
setblock 476 54 446 minecraft:magma_block
fill 476 54 458 477 59 458 minecraft:blackstone
fill 477 54 416 478 59 416 minecraft:blackstone
fill 477 54 457 479 54 457 minecraft:red_nether_bricks
fill 479 54 416 480 54 416 minecraft:orange_concrete
fill 479 54 417 481 54 417 minecraft:red_nether_bricks
fill 481 54 416 481 55 416 minecraft:blackstone
fill 481 54 457 483 54 457 minecraft:red_nether_bricks
fill 483 54 417 485 54 417 minecraft:red_nether_bricks
fill 483 54 458 483 55 458 minecraft:orange_concrete
fill 484 54 458 485 55 458 minecraft:blackstone
fill 485 54 457 487 54 457 minecraft:red_nether_bricks
fill 486 54 458 487 54 458 minecraft:orange_concrete
fill 487 54 417 489 54 417 minecraft:red_nether_bricks
fill 488 54 458 488 59 458 minecraft:blackstone
fill 489 54 416 490 59 416 minecraft:blackstone
fill 489 54 457 491 54 457 minecraft:red_nether_bricks
fill 491 54 416 492 55 416 minecraft:orange_concrete
fill 491 54 417 493 54 417 minecraft:red_nether_bricks
fill 493 54 457 495 54 457 minecraft:red_nether_bricks
fill 494 54 458 495 55 458 minecraft:orange_concrete
fill 495 54 417 497 54 417 minecraft:red_nether_bricks
fill 496 54 458 497 59 458 minecraft:blackstone
fill 497 54 457 499 54 457 minecraft:red_nether_bricks
fill 498 54 416 498 59 416 minecraft:blackstone
fill 499 54 416 500 54 416 minecraft:orange_concrete
fill 499 54 417 501 54 417 minecraft:red_nether_bricks
fill 501 54 416 502 55 416 minecraft:blackstone
fill 501 54 457 503 54 457 minecraft:red_nether_bricks
fill 503 54 416 503 55 416 minecraft:orange_concrete
fill 503 54 417 505 54 417 minecraft:red_nether_bricks
fill 505 54 457 507 54 457 minecraft:red_nether_bricks
fill 506 54 458 507 54 458 minecraft:orange_concrete
fill 507 54 417 509 54 417 minecraft:red_nether_bricks
fill 508 54 458 509 59 458 minecraft:blackstone
fill 509 54 416 510 59 416 minecraft:blackstone
fill 509 54 457 511 54 457 minecraft:red_nether_bricks
fill 511 54 416 512 55 416 minecraft:orange_concrete
fill 511 54 417 511 54 419 minecraft:red_nether_bricks
fill 511 54 421 511 54 423 minecraft:red_nether_bricks
fill 511 54 425 511 54 427 minecraft:red_nether_bricks
fill 511 54 429 511 54 431 minecraft:red_nether_bricks
fill 511 54 433 511 54 435 minecraft:red_nether_bricks
fill 511 54 437 511 54 439 minecraft:red_nether_bricks
fill 511 54 441 511 54 443 minecraft:red_nether_bricks
fill 511 54 445 511 54 447 minecraft:red_nether_bricks
fill 511 54 449 511 54 451 minecraft:red_nether_bricks
fill 511 54 453 511 54 455 minecraft:red_nether_bricks
setblock 512 54 424 minecraft:orange_concrete
fill 512 54 425 512 59 426 minecraft:blackstone
fill 512 54 427 512 55 428 minecraft:orange_concrete
fill 512 54 433 512 59 434 minecraft:blackstone
fill 512 54 435 512 54 436 minecraft:orange_concrete
fill 512 54 437 512 59 437 minecraft:blackstone
fill 512 54 445 512 59 446 minecraft:blackstone
fill 512 54 447 512 55 448 minecraft:orange_concrete
fill 512 54 454 512 59 454 minecraft:blackstone
setblock 512 54 456 minecraft:orange_concrete
fill 512 54 457 512 59 457 minecraft:blackstone
setblock 470 55 418 minecraft:orange_concrete
fill 470 55 422 470 58 422 minecraft:blackstone
fill 470 55 438 470 55 439 minecraft:orange_concrete
setblock 470 55 442 minecraft:orange_concrete
fill 470 55 443 470 58 443 minecraft:blackstone
fill 470 55 454 470 58 454 minecraft:blackstone
setblock 471 55 458 minecraft:orange_concrete
fill 479 55 416 479 58 416 minecraft:blackstone
setblock 480 55 416 minecraft:orange_concrete
setblock 482 55 458 minecraft:orange_concrete
fill 483 55 416 484 55 416 minecraft:orange_concrete
fill 486 55 458 487 58 458 minecraft:blackstone
fill 499 55 416 500 57 416 minecraft:blackstone
setblock 503 55 458 minecraft:orange_concrete
setblock 504 55 416 minecraft:orange_concrete
setblock 506 55 458 minecraft:orange_concrete
fill 507 55 458 507 58 458 minecraft:blackstone
setblock 512 55 419 minecraft:orange_concrete
fill 512 55 424 512 58 424 minecraft:blackstone
fill 512 55 435 512 58 435 minecraft:blackstone
setblock 512 55 436 minecraft:orange_concrete
fill 512 55 439 512 55 440 minecraft:orange_concrete
fill 512 55 456 512 58 456 minecraft:blackstone
fill 470 56 416 470 57 417 minecraft:orange_concrete
fill 470 56 418 470 61 419 minecraft:blackstone
fill 470 56 428 470 56 429 minecraft:orange_concrete
fill 470 56 430 470 61 431 minecraft:blackstone
fill 470 56 437 470 57 437 minecraft:orange_concrete
fill 470 56 438 470 61 439 minecraft:blackstone
setblock 470 56 440 minecraft:orange_concrete
fill 470 56 442 470 61 442 minecraft:blackstone
fill 470 56 448 470 57 449 minecraft:orange_concrete
fill 470 56 450 470 61 451 minecraft:blackstone
fill 471 56 416 472 61 416 minecraft:blackstone
fill 471 56 458 471 61 458 minecraft:blackstone
fill 472 56 458 473 56 458 minecraft:orange_concrete
fill 473 56 416 474 57 416 minecraft:orange_concrete
setblock 473 56 419 minecraft:light[level=14]
setblock 473 56 427 minecraft:light[level=14]
setblock 473 56 435 minecraft:light[level=14]
setblock 473 56 443 minecraft:light[level=14]
setblock 473 56 451 minecraft:light[level=14]
fill 474 56 458 475 61 458 minecraft:blackstone
fill 480 56 416 480 61 416 minecraft:blackstone
fill 480 56 458 481 57 458 minecraft:orange_concrete
fill 481 56 416 482 56 416 minecraft:orange_concrete
setblock 481 56 419 minecraft:light[level=14]
setblock 481 56 427 minecraft:light[level=14]
setblock 481 56 435 minecraft:light[level=14]
setblock 481 56 443 minecraft:light[level=14]
setblock 481 56 451 minecraft:light[level=14]
fill 482 56 458 483 61 458 minecraft:blackstone
fill 483 56 416 484 57 416 minecraft:blackstone
setblock 484 56 458 minecraft:orange_concrete
fill 485 56 416 485 57 416 minecraft:orange_concrete
fill 485 56 458 485 59 458 minecraft:blackstone
setblock 489 56 419 minecraft:light[level=14]
setblock 489 56 427 minecraft:light[level=14]
setblock 489 56 435 minecraft:light[level=14]
setblock 489 56 443 minecraft:light[level=14]
setblock 489 56 451 minecraft:light[level=14]
fill 491 56 416 492 61 416 minecraft:blackstone
fill 492 56 458 493 57 458 minecraft:orange_concrete
fill 493 56 416 494 57 416 minecraft:orange_concrete
fill 494 56 458 495 61 458 minecraft:blackstone
setblock 497 56 419 minecraft:light[level=14]
setblock 497 56 427 minecraft:light[level=14]
setblock 497 56 435 minecraft:light[level=14]
setblock 497 56 443 minecraft:light[level=14]
setblock 497 56 451 minecraft:light[level=14]
fill 501 56 416 501 59 416 minecraft:blackstone
fill 501 56 458 501 57 458 minecraft:orange_concrete
setblock 502 56 416 minecraft:orange_concrete
fill 503 56 416 504 61 416 minecraft:blackstone
fill 503 56 458 503 61 458 minecraft:blackstone
fill 504 56 458 505 56 458 minecraft:orange_concrete
fill 505 56 416 506 57 416 minecraft:orange_concrete
setblock 505 56 419 minecraft:light[level=14]
setblock 505 56 427 minecraft:light[level=14]
setblock 505 56 435 minecraft:light[level=14]
setblock 505 56 443 minecraft:light[level=14]
setblock 505 56 451 minecraft:light[level=14]
fill 506 56 458 506 61 458 minecraft:blackstone
fill 511 56 416 512 58 416 minecraft:blackstone
fill 512 56 417 512 56 418 minecraft:orange_concrete
fill 512 56 419 512 61 419 minecraft:blackstone
fill 512 56 427 512 61 428 minecraft:blackstone
fill 512 56 429 512 57 430 minecraft:orange_concrete
fill 512 56 436 512 61 436 minecraft:blackstone
setblock 512 56 438 minecraft:orange_concrete
fill 512 56 439 512 61 440 minecraft:blackstone
fill 512 56 441 512 57 441 minecraft:orange_concrete
fill 512 56 447 512 61 448 minecraft:blackstone
fill 512 56 449 512 56 450 minecraft:orange_concrete
fill 512 56 458 512 57 458 minecraft:orange_concrete
setblock 470 57 425 minecraft:orange_concrete
setblock 470 57 428 minecraft:orange_concrete
fill 470 57 429 470 60 429 minecraft:blackstone
setblock 470 57 436 minecraft:orange_concrete
fill 470 57 440 470 60 440 minecraft:blackstone
fill 470 57 456 470 57 457 minecraft:orange_concrete
setblock 472 57 458 minecraft:orange_concrete
fill 473 57 458 473 60 458 minecraft:blackstone
fill 481 57 416 482 59 416 minecraft:blackstone
fill 484 57 458 484 60 458 minecraft:blackstone
setblock 486 57 416 minecraft:orange_concrete
setblock 489 57 458 minecraft:orange_concrete
setblock 497 57 416 minecraft:orange_concrete
setblock 500 57 458 minecraft:orange_concrete
fill 502 57 416 502 59 416 minecraft:blackstone
fill 504 57 458 505 60 458 minecraft:blackstone
fill 512 57 417 512 60 417 minecraft:blackstone
setblock 512 57 418 minecraft:orange_concrete
fill 512 57 421 512 57 422 minecraft:orange_concrete
fill 512 57 438 512 60 438 minecraft:blackstone
setblock 512 57 442 minecraft:orange_concrete
fill 512 57 449 512 60 449 minecraft:blackstone
setblock 512 57 450 minecraft:orange_concrete
setblock 512 57 453 minecraft:orange_concrete
fill 470 58 416 470 63 417 minecraft:blackstone
fill 470 58 423 470 59 423 minecraft:orange_concrete
fill 470 58 425 470 63 425 minecraft:blackstone
fill 470 58 426 470 58 427 minecraft:orange_concrete
fill 470 58 428 470 63 428 minecraft:blackstone
fill 470 58 434 470 59 435 minecraft:orange_concrete
fill 470 58 436 470 63 437 minecraft:blackstone
fill 470 58 446 470 58 447 minecraft:orange_concrete
fill 470 58 448 470 63 449 minecraft:blackstone
fill 470 58 455 470 59 455 minecraft:orange_concrete
fill 470 58 456 470 63 457 minecraft:blackstone
setblock 470 58 458 minecraft:orange_concrete
fill 472 58 458 472 63 458 minecraft:blackstone
fill 473 58 416 474 63 416 minecraft:blackstone
fill 475 58 416 476 58 416 minecraft:orange_concrete
fill 478 58 458 479 59 458 minecraft:orange_concrete
fill 480 58 458 481 63 458 minecraft:blackstone
fill 483 58 416 483 61 416 minecraft:blackstone
setblock 484 58 416 minecraft:orange_concrete
fill 485 58 416 486 63 416 minecraft:blackstone
fill 487 58 416 488 59 416 minecraft:orange_concrete
fill 489 58 458 489 63 458 minecraft:blackstone
fill 490 58 458 491 58 458 minecraft:orange_concrete
fill 492 58 458 493 63 458 minecraft:blackstone
fill 493 58 416 494 60 416 minecraft:blackstone
fill 495 58 416 496 58 416 minecraft:orange_concrete
fill 497 58 416 497 63 416 minecraft:blackstone
fill 498 58 458 499 59 458 minecraft:orange_concrete
fill 499 58 416 499 59 416 minecraft:orange_concrete
setblock 500 58 416 minecraft:blackstone
fill 500 58 458 501 63 458 minecraft:blackstone
setblock 502 58 458 minecraft:orange_concrete
fill 505 58 416 506 63 416 minecraft:blackstone
fill 507 58 416 508 59 416 minecraft:orange_concrete
fill 510 58 458 511 59 458 minecraft:orange_concrete
fill 512 58 418 512 60 418 minecraft:blackstone
setblock 512 58 420 minecraft:orange_concrete
fill 512 58 421 512 63 422 minecraft:blackstone
fill 512 58 423 512 59 423 minecraft:orange_concrete
fill 512 58 429 512 63 430 minecraft:blackstone
fill 512 58 431 512 58 432 minecraft:orange_concrete
fill 512 58 441 512 63 442 minecraft:blackstone
fill 512 58 443 512 59 444 minecraft:orange_concrete
fill 512 58 450 512 63 450 minecraft:blackstone
fill 512 58 451 512 58 452 minecraft:orange_concrete
fill 512 58 453 512 63 453 minecraft:blackstone
fill 512 58 455 512 59 455 minecraft:orange_concrete
fill 512 58 458 512 63 458 minecraft:blackstone
setblock 470 59 422 minecraft:orange_concrete
fill 470 59 426 470 62 427 minecraft:blackstone
setblock 470 59 443 minecraft:orange_concrete
setblock 470 59 446 minecraft:orange_concrete
fill 470 59 447 470 62 447 minecraft:blackstone
setblock 470 59 454 minecraft:orange_concrete
fill 470 59 458 470 62 458 minecraft:blackstone
fill 475 59 416 475 62 416 minecraft:blackstone
setblock 476 59 416 minecraft:orange_concrete
setblock 479 59 416 minecraft:orange_concrete
fill 484 59 416 484 61 416 minecraft:blackstone
fill 486 59 458 487 59 458 minecraft:orange_concrete
setblock 490 59 458 minecraft:orange_concrete
fill 491 59 458 491 62 458 minecraft:blackstone
fill 495 59 416 495 62 416 minecraft:blackstone
setblock 496 59 416 minecraft:orange_concrete
setblock 500 59 416 minecraft:orange_concrete
fill 502 59 458 502 62 458 minecraft:blackstone
setblock 507 59 458 minecraft:orange_concrete
setblock 511 59 416 minecraft:orange_concrete
fill 512 59 416 512 61 416 minecraft:blackstone
fill 512 59 420 512 62 420 minecraft:blackstone
setblock 512 59 424 minecraft:orange_concrete
fill 512 59 431 512 62 431 minecraft:blackstone
setblock 512 59 432 minecraft:orange_concrete
setblock 512 59 435 minecraft:orange_concrete
fill 512 59 451 512 62 452 minecraft:blackstone
setblock 512 59 456 minecraft:orange_concrete
fill 470 60 420 470 61 421 minecraft:orange_concrete
fill 470 60 422 470 65 423 minecraft:blackstone
setblock 470 60 424 minecraft:orange_concrete
fill 470 60 432 470 61 433 minecraft:orange_concrete
fill 470 60 434 470 65 435 minecraft:blackstone
fill 470 60 441 470 61 441 minecraft:orange_concrete
fill 470 60 443 470 65 443 minecraft:blackstone
fill 470 60 444 470 60 445 minecraft:orange_concrete
fill 470 60 446 470 65 446 minecraft:blackstone
fill 470 60 452 470 61 453 minecraft:orange_concrete
fill 470 60 454 470 65 455 minecraft:blackstone
fill 471 60 417 473 60 417 minecraft:red_nether_bricks
fill 471 60 419 471 60 421 minecraft:red_nether_bricks
fill 471 60 423 471 60 425 minecraft:red_nether_bricks
fill 471 60 427 471 60 429 minecraft:red_nether_bricks
fill 471 60 431 471 60 433 minecraft:red_nether_bricks
fill 471 60 435 471 60 437 minecraft:red_nether_bricks
fill 471 60 439 471 60 441 minecraft:red_nether_bricks
fill 471 60 443 471 60 445 minecraft:red_nether_bricks
fill 471 60 447 471 60 449 minecraft:red_nether_bricks
fill 471 60 451 471 60 453 minecraft:red_nether_bricks
fill 471 60 455 471 60 457 minecraft:red_nether_bricks
fill 473 60 457 475 60 457 minecraft:red_nether_bricks
fill 475 60 417 477 60 417 minecraft:red_nether_bricks
fill 476 60 416 476 65 416 minecraft:blackstone
fill 476 60 458 477 60 458 minecraft:orange_concrete
fill 477 60 416 478 60 416 minecraft:orange_concrete
fill 477 60 457 479 60 457 minecraft:red_nether_bricks
fill 478 60 458 479 65 458 minecraft:blackstone
fill 479 60 416 479 65 416 minecraft:blackstone
fill 479 60 417 481 60 417 minecraft:red_nether_bricks
fill 481 60 416 481 61 416 minecraft:orange_concrete
fill 481 60 457 483 60 457 minecraft:red_nether_bricks
setblock 482 60 416 minecraft:blackstone
fill 483 60 417 485 60 417 minecraft:red_nether_bricks
fill 485 60 457 487 60 457 minecraft:red_nether_bricks
fill 485 60 458 485 61 458 minecraft:orange_concrete
fill 486 60 458 487 65 458 minecraft:blackstone
fill 487 60 416 488 65 416 minecraft:blackstone
fill 487 60 417 489 60 417 minecraft:red_nether_bricks
setblock 488 60 458 minecraft:orange_concrete
fill 489 60 416 490 61 416 minecraft:orange_concrete
schedule function dropper:buildpart/106_2 1t
