fill 225 126 370 227 126 370 minecraft:mud
fill 227 126 410 229 126 410 minecraft:mud
fill 229 126 370 229 126 372 minecraft:mud
fill 229 126 374 229 126 376 minecraft:mud
fill 229 126 378 229 126 380 minecraft:mud
fill 229 126 382 229 126 384 minecraft:mud
fill 229 126 386 229 126 388 minecraft:mud
fill 229 126 390 229 126 392 minecraft:mud
fill 229 126 394 229 126 396 minecraft:mud
fill 229 126 398 229 126 400 minecraft:mud
fill 229 126 402 229 126 404 minecraft:mud
fill 229 126 406 229 126 408 minecraft:mud
fill 229 126 411 229 127 411 minecraft:lime_terracotta
fill 230 126 370 230 131 371 minecraft:moss_block
fill 230 126 372 230 127 373 minecraft:lime_terracotta
fill 230 126 379 230 131 379 minecraft:moss_block
setblock 230 126 381 minecraft:lime_terracotta
fill 230 126 382 230 131 383 minecraft:moss_block
fill 230 126 384 230 127 384 minecraft:lime_terracotta
fill 230 126 390 230 131 391 minecraft:moss_block
fill 230 126 392 230 126 393 minecraft:lime_terracotta
fill 230 126 402 230 131 403 minecraft:moss_block
fill 230 126 404 230 127 405 minecraft:lime_terracotta
setblock 188 127 371 minecraft:lime_terracotta
fill 188 127 372 188 130 372 minecraft:moss_block
fill 188 127 383 188 130 383 minecraft:moss_block
setblock 188 127 388 minecraft:lime_terracotta
setblock 188 127 399 minecraft:lime_terracotta
fill 188 127 403 188 129 404 minecraft:moss_block
fill 189 127 369 190 130 369 minecraft:moss_block
setblock 191 127 372 minecraft:light[level=14]
setblock 191 127 388 minecraft:light[level=14]
setblock 191 127 396 minecraft:light[level=14]
setblock 191 127 404 minecraft:light[level=14]
setblock 194 127 369 minecraft:lime_terracotta
fill 196 127 411 197 127 411 minecraft:lime_terracotta
setblock 199 127 372 minecraft:light[level=14]
setblock 199 127 380 minecraft:light[level=14]
setblock 199 127 388 minecraft:light[level=14]
setblock 199 127 396 minecraft:light[level=14]
setblock 199 127 404 minecraft:light[level=14]
setblock 200 127 411 minecraft:lime_terracotta
fill 201 127 411 201 130 411 minecraft:moss_block
setblock 205 127 369 minecraft:lime_terracotta
setblock 207 127 372 minecraft:light[level=14]
setblock 207 127 380 minecraft:light[level=14]
setblock 207 127 388 minecraft:light[level=14]
setblock 207 127 396 minecraft:light[level=14]
setblock 207 127 404 minecraft:light[level=14]
fill 210 127 369 210 130 369 minecraft:moss_block
fill 212 127 411 212 130 411 minecraft:moss_block
setblock 215 127 372 minecraft:light[level=14]
setblock 215 127 380 minecraft:light[level=14]
setblock 215 127 388 minecraft:light[level=14]
setblock 215 127 396 minecraft:light[level=14]
setblock 215 127 404 minecraft:light[level=14]
setblock 217 127 411 minecraft:lime_terracotta
fill 221 127 369 221 130 369 minecraft:moss_block
setblock 222 127 369 minecraft:lime_terracotta
setblock 223 127 372 minecraft:light[level=14]
setblock 223 127 380 minecraft:light[level=14]
setblock 223 127 388 minecraft:light[level=14]
setblock 223 127 396 minecraft:light[level=14]
setblock 223 127 404 minecraft:light[level=14]
fill 225 127 369 226 127 369 minecraft:lime_terracotta
setblock 228 127 411 minecraft:lime_terracotta
fill 230 127 381 230 130 381 minecraft:moss_block
setblock 230 127 385 minecraft:lime_terracotta
fill 230 127 392 230 130 392 minecraft:moss_block
setblock 230 127 393 minecraft:lime_terracotta
setblock 230 127 396 minecraft:lime_terracotta
setblock 188 128 369 minecraft:lime_terracotta
fill 188 128 371 188 145 371 minecraft:moss_block
fill 188 128 377 188 129 378 minecraft:lime_terracotta
fill 188 128 379 188 145 380 minecraft:moss_block
fill 188 128 388 188 149 388 minecraft:moss_block
fill 188 128 389 188 128 390 minecraft:lime_terracotta
fill 188 128 391 188 130 392 minecraft:moss_block
fill 188 128 397 188 129 398 minecraft:lime_terracotta
fill 188 128 399 188 146 400 minecraft:moss_block
setblock 188 128 401 minecraft:lime_terracotta
fill 188 128 402 188 131 402 minecraft:moss_block
fill 188 128 409 188 129 410 minecraft:lime_terracotta
fill 188 128 411 189 145 411 minecraft:moss_block
setblock 192 128 369 minecraft:lime_terracotta
fill 193 128 369 194 146 369 minecraft:moss_block
fill 195 128 369 196 129 369 minecraft:lime_terracotta
fill 195 128 411 195 129 411 minecraft:lime_terracotta
fill 196 128 411 197 129 411 minecraft:moss_block
fill 198 128 411 199 128 411 minecraft:lime_terracotta
fill 200 128 411 200 145 411 minecraft:moss_block
fill 201 128 369 202 145 369 minecraft:moss_block
fill 203 128 369 204 128 369 minecraft:lime_terracotta
fill 205 128 369 205 149 369 minecraft:moss_block
fill 206 128 411 207 129 411 minecraft:lime_terracotta
fill 208 128 411 209 146 411 minecraft:moss_block
fill 213 128 369 214 146 369 minecraft:moss_block
fill 215 128 369 216 129 369 minecraft:lime_terracotta
fill 217 128 411 217 149 411 minecraft:moss_block
fill 218 128 411 219 128 411 minecraft:lime_terracotta
fill 220 128 411 221 145 411 minecraft:moss_block
fill 222 128 369 222 145 369 minecraft:moss_block
setblock 224 128 369 minecraft:lime_terracotta
fill 225 128 369 226 149 369 minecraft:moss_block
fill 226 128 411 227 129 411 minecraft:lime_terracotta
fill 227 128 369 227 129 369 minecraft:lime_terracotta
fill 228 128 411 229 146 411 minecraft:moss_block
fill 230 128 372 230 145 373 minecraft:moss_block
fill 230 128 374 230 128 375 minecraft:lime_terracotta
fill 230 128 384 230 146 385 minecraft:moss_block
fill 230 128 386 230 129 387 minecraft:lime_terracotta
fill 230 128 393 230 145 393 minecraft:moss_block
fill 230 128 394 230 128 395 minecraft:lime_terracotta
fill 230 128 396 230 149 396 minecraft:moss_block
fill 230 128 398 230 129 398 minecraft:lime_terracotta
fill 230 128 404 230 145 405 minecraft:moss_block
fill 230 128 406 230 129 407 minecraft:lime_terracotta
setblock 230 128 411 minecraft:lime_terracotta
fill 188 129 369 188 132 369 minecraft:moss_block
fill 188 129 385 188 129 386 minecraft:lime_terracotta
setblock 188 129 389 minecraft:lime_terracotta
fill 188 129 390 188 132 390 minecraft:moss_block
fill 188 129 401 188 131 401 minecraft:moss_block
setblock 188 129 406 minecraft:lime_terracotta
fill 192 129 369 192 132 369 minecraft:moss_block
setblock 194 129 411 minecraft:lime_terracotta
fill 198 129 411 199 131 411 minecraft:moss_block
fill 203 129 369 203 132 369 minecraft:moss_block
setblock 204 129 369 minecraft:lime_terracotta
fill 207 129 369 208 129 369 minecraft:lime_terracotta
fill 214 129 411 215 129 411 minecraft:lime_terracotta
setblock 218 129 411 minecraft:lime_terracotta
fill 219 129 411 219 132 411 minecraft:moss_block
fill 224 129 369 224 132 369 minecraft:moss_block
setblock 228 129 369 minecraft:lime_terracotta
fill 230 129 374 230 132 374 minecraft:moss_block
setblock 230 129 375 minecraft:lime_terracotta
setblock 230 129 378 minecraft:lime_terracotta
fill 230 129 394 230 132 395 minecraft:moss_block
setblock 230 129 399 minecraft:lime_terracotta
setblock 230 129 410 minecraft:lime_terracotta
fill 230 129 411 230 132 411 minecraft:moss_block
fill 188 130 375 193 130 376 minecraft:lime_terracotta
fill 188 130 377 188 143 378 minecraft:moss_block
fill 188 130 384 188 131 384 minecraft:lime_terracotta
fill 188 130 385 188 143 386 minecraft:moss_block
setblock 188 130 387 minecraft:lime_terracotta
fill 188 130 389 188 132 389 minecraft:moss_block
fill 188 130 395 188 131 396 minecraft:lime_terracotta
fill 188 130 397 188 143 398 minecraft:moss_block
setblock 188 130 403 minecraft:moss_block
fill 188 130 404 188 131 404 minecraft:lime_terracotta
fill 188 130 406 188 143 406 minecraft:moss_block
fill 188 130 407 188 130 408 minecraft:lime_terracotta
fill 188 130 409 188 132 410 minecraft:moss_block
fill 189 130 377 189 131 377 minecraft:lime_terracotta
fill 189 130 379 189 130 381 minecraft:lime_terracotta
fill 190 130 380 190 131 381 minecraft:lime_terracotta
fill 191 130 381 193 130 381 minecraft:lime_terracotta
fill 192 130 380 194 130 380 minecraft:lime_terracotta
fill 192 130 411 193 131 411 minecraft:lime_terracotta
fill 193 130 377 194 130 379 minecraft:lime_terracotta
setblock 194 130 376 minecraft:lime_terracotta
fill 194 130 411 195 143 411 minecraft:moss_block
fill 195 130 369 196 143 369 minecraft:moss_block
fill 196 130 385 197 130 386 minecraft:lime_terracotta
setblock 196 130 411 minecraft:lime_terracotta
fill 197 130 369 198 131 369 minecraft:lime_terracotta
fill 197 130 383 198 130 384 minecraft:lime_terracotta
fill 197 130 387 198 130 388 minecraft:lime_terracotta
fill 197 130 411 197 149 411 minecraft:moss_block
fill 198 130 382 202 130 382 minecraft:lime_terracotta
fill 199 130 383 203 130 383 minecraft:lime_terracotta
fill 199 130 388 201 130 389 minecraft:lime_terracotta
fill 202 130 384 203 131 384 minecraft:lime_terracotta
fill 202 130 386 202 130 388 minecraft:lime_terracotta
fill 203 130 385 203 130 387 minecraft:lime_terracotta
fill 204 130 369 204 147 369 minecraft:moss_block
fill 204 130 411 205 130 411 minecraft:lime_terracotta
setblock 206 130 369 minecraft:lime_terracotta
fill 206 130 411 207 143 411 minecraft:moss_block
fill 207 130 369 208 143 369 minecraft:moss_block
fill 209 130 369 209 131 369 minecraft:lime_terracotta
fill 213 130 411 213 131 411 minecraft:lime_terracotta
fill 214 130 411 215 143 411 minecraft:moss_block
fill 215 130 369 216 143 369 minecraft:moss_block
setblock 216 130 411 minecraft:lime_terracotta
fill 217 130 369 218 130 369 minecraft:lime_terracotta
fill 218 130 411 218 147 411 minecraft:moss_block
fill 224 130 372 224 130 374 minecraft:lime_terracotta
fill 224 130 411 225 131 411 minecraft:lime_terracotta
fill 225 130 371 228 130 371 minecraft:lime_terracotta
fill 225 130 374 225 130 375 minecraft:lime_terracotta
fill 226 130 375 227 130 375 minecraft:lime_terracotta
fill 226 130 411 227 143 411 minecraft:moss_block
fill 227 130 369 228 143 369 minecraft:moss_block
fill 227 130 374 228 131 374 minecraft:lime_terracotta
fill 228 130 372 228 131 373 minecraft:lime_terracotta
fill 229 130 369 230 131 369 minecraft:lime_terracotta
fill 230 130 375 230 147 375 minecraft:moss_block
fill 230 130 376 230 130 377 minecraft:lime_terracotta
fill 230 130 378 230 143 378 minecraft:moss_block
fill 230 130 380 230 131 380 minecraft:lime_terracotta
fill 230 130 386 230 143 387 minecraft:moss_block
fill 230 130 388 230 131 389 minecraft:lime_terracotta
setblock 230 130 397 minecraft:lime_terracotta
fill 230 130 398 230 143 399 minecraft:moss_block
fill 230 130 400 230 131 401 minecraft:lime_terracotta
fill 230 130 406 230 147 407 minecraft:moss_block
fill 230 130 408 230 130 409 minecraft:lime_terracotta
fill 230 130 410 230 143 410 minecraft:moss_block
setblock 188 131 372 minecraft:lime_terracotta
setblock 188 131 375 minecraft:lime_terracotta
fill 188 131 376 188 149 376 minecraft:moss_block
setblock 188 131 383 minecraft:lime_terracotta
fill 188 131 387 188 149 387 minecraft:moss_block
fill 188 131 391 188 145 391 minecraft:moss_block
setblock 188 131 392 minecraft:lime_terracotta
setblock 188 131 403 minecraft:lime_terracotta
setblock 188 131 407 minecraft:lime_terracotta
fill 188 131 408 188 149 408 minecraft:moss_block
fill 189 131 369 190 131 369 minecraft:lime_terracotta
fill 189 131 376 193 131 376 minecraft:lime_terracotta
fill 189 131 379 189 131 380 minecraft:lime_terracotta
fill 190 131 375 191 131 375 minecraft:lime_terracotta
fill 191 131 381 192 131 381 minecraft:lime_terracotta
fill 192 131 380 193 131 380 minecraft:lime_terracotta
fill 193 131 377 193 132 379 minecraft:lime_terracotta
fill 194 131 378 194 131 379 minecraft:lime_terracotta
fill 196 131 411 196 149 411 minecraft:moss_block
fill 197 131 384 197 131 386 minecraft:lime_terracotta
fill 198 131 383 198 131 384 minecraft:lime_terracotta
fill 198 131 387 198 131 388 minecraft:lime_terracotta
fill 199 131 383 202 131 383 minecraft:lime_terracotta
fill 199 131 388 201 131 388 minecraft:lime_terracotta
setblock 200 131 382 minecraft:lime_terracotta
setblock 201 131 411 minecraft:lime_terracotta
fill 202 131 386 202 132 387 minecraft:lime_terracotta
fill 203 131 385 203 131 386 minecraft:lime_terracotta
setblock 204 131 411 minecraft:lime_terracotta
fill 205 131 411 205 149 411 minecraft:moss_block
fill 206 131 369 206 149 369 minecraft:moss_block
setblock 210 131 369 minecraft:lime_terracotta
setblock 212 131 411 minecraft:lime_terracotta
fill 216 131 411 216 149 411 minecraft:moss_block
fill 217 131 369 217 149 369 minecraft:moss_block
setblock 218 131 369 minecraft:lime_terracotta
setblock 221 131 369 minecraft:lime_terracotta
fill 224 131 372 224 131 373 minecraft:lime_terracotta
fill 225 131 371 227 131 371 minecraft:lime_terracotta
fill 225 131 374 225 132 374 minecraft:lime_terracotta
setblock 226 131 375 minecraft:lime_terracotta
fill 230 131 376 230 149 377 minecraft:moss_block
setblock 230 131 381 minecraft:lime_terracotta
setblock 230 131 392 minecraft:lime_terracotta
fill 230 131 397 230 149 397 minecraft:moss_block
fill 230 131 408 230 149 408 minecraft:moss_block
setblock 230 131 409 minecraft:lime_terracotta
fill 188 132 370 188 133 370 minecraft:lime_terracotta
fill 188 132 372 188 145 372 minecraft:moss_block
fill 188 132 373 188 132 374 minecraft:lime_terracotta
fill 188 132 375 188 149 375 minecraft:moss_block
fill 188 132 381 188 133 382 minecraft:lime_terracotta
fill 188 132 383 188 145 384 minecraft:moss_block
fill 188 132 392 188 145 392 minecraft:moss_block
fill 188 132 393 188 132 394 minecraft:lime_terracotta
fill 188 132 395 188 145 396 minecraft:moss_block
fill 188 132 401 188 133 402 minecraft:lime_terracotta
fill 188 132 403 188 145 404 minecraft:moss_block
setblock 188 132 405 minecraft:lime_terracotta
fill 188 132 407 188 149 407 minecraft:moss_block
fill 189 132 369 190 145 369 minecraft:moss_block
fill 189 132 370 191 132 370 minecraft:mud
fill 189 132 372 189 132 374 minecraft:mud
fill 189 132 376 189 132 377 minecraft:mud
setblock 189 132 379 minecraft:lime_terracotta
fill 189 132 380 189 132 382 minecraft:mud
fill 189 132 384 189 132 386 minecraft:mud
fill 189 132 388 189 132 390 minecraft:mud
fill 189 132 392 189 132 394 minecraft:mud
fill 189 132 396 189 132 398 minecraft:mud
fill 189 132 400 189 132 402 minecraft:mud
fill 189 132 404 189 132 406 minecraft:mud
fill 189 132 408 189 132 410 minecraft:mud
fill 190 132 376 192 132 376 minecraft:lime_terracotta
setblock 190 132 380 minecraft:lime_terracotta
fill 190 132 411 191 133 411 minecraft:lime_terracotta
fill 191 132 369 191 133 369 minecraft:lime_terracotta
fill 191 132 410 193 132 410 minecraft:mud
setblock 192 132 380 minecraft:lime_terracotta
fill 192 132 411 193 145 411 minecraft:moss_block
fill 193 132 370 195 132 370 minecraft:mud
fill 195 132 410 197 132 410 minecraft:mud
fill 197 132 369 198 145 369 minecraft:moss_block
fill 197 132 370 199 132 370 minecraft:mud
setblock 198 132 384 minecraft:lime_terracotta
setblock 198 132 387 minecraft:lime_terracotta
setblock 198 132 411 minecraft:moss_block
fill 199 132 369 200 132 369 minecraft:lime_terracotta
fill 199 132 383 201 132 383 minecraft:lime_terracotta
fill 199 132 410 201 132 410 minecraft:mud
fill 199 132 411 199 133 411 minecraft:lime_terracotta
setblock 200 132 388 minecraft:lime_terracotta
fill 201 132 370 203 132 370 minecraft:mud
fill 201 132 411 201 145 411 minecraft:moss_block
setblock 202 132 384 minecraft:lime_terracotta
fill 202 132 411 203 132 411 minecraft:lime_terracotta
fill 203 132 410 205 132 410 minecraft:mud
fill 204 132 411 204 149 411 minecraft:moss_block
fill 205 132 370 207 132 370 minecraft:mud
fill 207 132 410 209 132 410 minecraft:mud
fill 209 132 369 210 145 369 minecraft:moss_block
fill 209 132 370 211 132 370 minecraft:mud
fill 210 132 411 211 133 411 minecraft:lime_terracotta
fill 211 132 369 212 133 369 minecraft:lime_terracotta
fill 211 132 410 213 132 410 minecraft:mud
fill 212 132 411 213 145 411 minecraft:moss_block
fill 213 132 370 215 132 370 minecraft:mud
fill 215 132 410 217 132 410 minecraft:mud
fill 217 132 370 219 132 370 minecraft:mud
fill 218 132 369 218 149 369 minecraft:moss_block
fill 219 132 369 220 132 369 minecraft:lime_terracotta
fill 219 132 410 221 132 410 minecraft:mud
fill 221 132 369 221 145 369 minecraft:moss_block
fill 221 132 370 223 132 370 minecraft:mud
fill 222 132 411 223 132 411 minecraft:lime_terracotta
fill 223 132 369 223 133 369 minecraft:lime_terracotta
fill 223 132 410 225 132 410 minecraft:mud
fill 224 132 411 225 145 411 minecraft:moss_block
fill 225 132 370 227 132 370 minecraft:mud
setblock 226 132 371 minecraft:lime_terracotta
setblock 227 132 374 minecraft:lime_terracotta
fill 227 132 410 229 132 410 minecraft:mud
fill 229 132 369 230 145 369 minecraft:moss_block
fill 229 132 370 229 132 372 minecraft:mud
fill 229 132 374 229 132 376 minecraft:mud
fill 229 132 378 229 132 380 minecraft:mud
fill 229 132 382 229 132 384 minecraft:mud
fill 229 132 386 229 132 388 minecraft:mud
fill 229 132 390 229 132 392 minecraft:mud
fill 229 132 394 229 132 396 minecraft:mud
fill 229 132 398 229 132 400 minecraft:mud
fill 229 132 402 229 132 404 minecraft:mud
fill 229 132 406 229 132 408 minecraft:mud
fill 230 132 370 230 133 371 minecraft:lime_terracotta
setblock 230 132 379 minecraft:lime_terracotta
fill 230 132 380 230 145 381 minecraft:moss_block
fill 230 132 382 230 133 383 minecraft:lime_terracotta
fill 230 132 388 230 149 389 minecraft:moss_block
fill 230 132 390 230 132 391 minecraft:lime_terracotta
fill 230 132 392 230 145 392 minecraft:moss_block
fill 230 132 400 230 145 401 minecraft:moss_block
fill 230 132 402 230 133 403 minecraft:lime_terracotta
fill 230 132 409 230 149 409 minecraft:moss_block
setblock 188 133 369 minecraft:lime_terracotta
fill 188 133 373 188 143 374 minecraft:moss_block
fill 188 133 389 188 133 390 minecraft:lime_terracotta
setblock 188 133 393 minecraft:lime_terracotta
fill 188 133 394 188 143 394 minecraft:moss_block
fill 188 133 405 188 143 405 minecraft:moss_block
fill 188 133 409 188 147 409 minecraft:moss_block
setblock 188 133 410 minecraft:lime_terracotta
setblock 192 133 369 minecraft:lime_terracotta
setblock 198 133 411 minecraft:lime_terracotta
fill 199 133 369 199 143 369 minecraft:moss_block
setblock 200 133 369 minecraft:lime_terracotta
fill 202 133 411 203 143 411 minecraft:moss_block
setblock 203 133 369 minecraft:lime_terracotta
fill 219 133 369 220 143 369 minecraft:moss_block
setblock 219 133 411 minecraft:lime_terracotta
setblock 222 133 411 minecraft:lime_terracotta
fill 223 133 411 223 143 411 minecraft:moss_block
setblock 224 133 369 minecraft:lime_terracotta
setblock 230 133 374 minecraft:lime_terracotta
fill 230 133 379 230 143 379 minecraft:moss_block
fill 230 133 390 230 143 390 minecraft:moss_block
setblock 230 133 391 minecraft:lime_terracotta
fill 230 133 394 230 133 395 minecraft:lime_terracotta
setblock 230 133 411 minecraft:lime_terracotta
fill 188 134 369 188 147 370 minecraft:moss_block
fill 188 134 381 188 144 382 minecraft:moss_block
fill 188 134 389 188 147 390 minecraft:moss_block
fill 188 134 393 188 144 393 minecraft:moss_block
fill 188 134 401 188 147 402 minecraft:moss_block
fill 188 134 410 188 147 410 minecraft:moss_block
fill 190 134 411 191 144 411 minecraft:moss_block
fill 191 134 369 192 147 369 minecraft:moss_block
fill 198 134 411 199 147 411 minecraft:moss_block
fill 200 134 369 200 144 369 minecraft:moss_block
fill 203 134 369 203 147 369 minecraft:moss_block
fill 210 134 411 211 144 411 minecraft:moss_block
fill 211 134 369 212 144 369 minecraft:moss_block
fill 219 134 411 219 147 411 minecraft:moss_block
fill 222 134 411 222 144 411 minecraft:moss_block
fill 223 134 369 224 147 369 minecraft:moss_block
fill 230 134 370 230 144 371 minecraft:moss_block
fill 230 134 374 230 147 374 minecraft:moss_block
fill 230 134 382 230 147 383 minecraft:moss_block
fill 230 134 391 230 144 391 minecraft:moss_block
fill 230 134 394 230 147 395 minecraft:moss_block
fill 230 134 402 230 144 403 minecraft:moss_block
fill 230 134 411 230 147 411 minecraft:moss_block
setblock 191 135 372 minecraft:light[level=14]
setblock 191 135 380 minecraft:light[level=14]
setblock 191 135 388 minecraft:light[level=14]
setblock 191 135 396 minecraft:light[level=14]
setblock 191 135 404 minecraft:light[level=14]
setblock 199 135 372 minecraft:light[level=14]
setblock 199 135 380 minecraft:light[level=14]
setblock 199 135 388 minecraft:light[level=14]
setblock 199 135 396 minecraft:light[level=14]
setblock 199 135 404 minecraft:light[level=14]
setblock 207 135 372 minecraft:light[level=14]
setblock 207 135 380 minecraft:light[level=14]
setblock 207 135 388 minecraft:light[level=14]
setblock 207 135 396 minecraft:light[level=14]
setblock 207 135 404 minecraft:light[level=14]
setblock 215 135 372 minecraft:light[level=14]
setblock 215 135 380 minecraft:light[level=14]
setblock 215 135 388 minecraft:light[level=14]
setblock 215 135 396 minecraft:light[level=14]
setblock 215 135 404 minecraft:light[level=14]
setblock 223 135 372 minecraft:light[level=14]
setblock 223 135 380 minecraft:light[level=14]
setblock 223 135 388 minecraft:light[level=14]
setblock 223 135 396 minecraft:light[level=14]
setblock 223 135 404 minecraft:light[level=14]
fill 189 139 370 203 139 410 minecraft:lime_terracotta
fill 204 139 370 204 139 390 minecraft:lime_terracotta
fill 204 139 391 207 139 391 minecraft:dark_oak_planks
fill 204 139 392 204 139 410 minecraft:lime_terracotta
fill 205 139 370 205 139 389 minecraft:lime_terracotta
fill 205 139 390 207 139 390 minecraft:dark_oak_planks
fill 205 139 392 207 139 392 minecraft:dark_oak_planks
fill 205 139 393 205 139 410 minecraft:lime_terracotta
fill 206 139 370 208 139 388 minecraft:lime_terracotta
fill 206 139 389 208 139 389 minecraft:dark_oak_planks
fill 206 139 393 208 139 393 minecraft:dark_oak_planks
fill 206 139 394 208 139 410 minecraft:lime_terracotta
fill 209 139 370 229 139 387 minecraft:lime_terracotta
fill 209 139 388 211 139 388 minecraft:dark_oak_planks
fill 209 139 394 211 139 394 minecraft:dark_oak_planks
fill 209 139 395 229 139 410 minecraft:lime_terracotta
fill 212 139 388 229 139 388 minecraft:lime_terracotta
fill 212 139 389 214 139 389 minecraft:dark_oak_planks
fill 212 139 393 214 139 393 minecraft:dark_oak_planks
fill 212 139 394 229 139 394 minecraft:lime_terracotta
fill 213 139 390 215 139 392 minecraft:dark_oak_planks
fill 215 139 389 229 139 389 minecraft:lime_terracotta
fill 215 139 393 229 139 393 minecraft:lime_terracotta
fill 216 139 390 229 139 390 minecraft:lime_terracotta
fill 216 139 391 216 140 391 minecraft:dark_oak_planks
fill 216 139 392 229 139 392 minecraft:lime_terracotta
fill 217 139 391 229 139 391 minecraft:lime_terracotta
fill 189 140 370 189 140 373 minecraft:green_terracotta
fill 189 140 374 190 140 376 minecraft:lime_terracotta
fill 189 140 377 189 140 380 minecraft:green_terracotta
fill 189 140 381 190 140 383 minecraft:lime_terracotta
fill 189 140 384 189 140 387 minecraft:green_terracotta
fill 189 140 388 190 140 390 minecraft:lime_terracotta
fill 189 140 391 189 140 394 minecraft:green_terracotta
fill 189 140 395 190 140 397 minecraft:lime_terracotta
fill 189 140 398 189 140 401 minecraft:green_terracotta
fill 189 140 402 190 140 404 minecraft:lime_terracotta
fill 189 140 405 189 140 408 minecraft:green_terracotta
fill 189 140 409 190 140 410 minecraft:lime_terracotta
fill 190 140 370 229 140 370 minecraft:green_terracotta
fill 190 140 371 195 140 373 minecraft:lime_terracotta
fill 190 140 377 229 140 377 minecraft:green_terracotta
fill 190 140 378 195 140 380 minecraft:lime_terracotta
fill 190 140 384 229 140 384 minecraft:green_terracotta
fill 190 140 385 195 140 387 minecraft:lime_terracotta
fill 190 140 391 200 140 391 minecraft:green_terracotta
fill 190 140 392 195 140 394 minecraft:lime_terracotta
fill 190 140 398 229 140 398 minecraft:green_terracotta
fill 190 140 399 195 140 401 minecraft:lime_terracotta
fill 190 140 405 229 140 405 minecraft:green_terracotta
fill 190 140 406 195 140 408 minecraft:lime_terracotta
fill 191 140 374 191 140 376 minecraft:green_terracotta
fill 191 140 381 191 140 383 minecraft:green_terracotta
fill 191 140 388 191 140 390 minecraft:green_terracotta
fill 191 140 395 191 140 397 minecraft:green_terracotta
fill 191 140 402 191 140 404 minecraft:green_terracotta
fill 191 140 409 191 140 410 minecraft:green_terracotta
fill 192 140 374 193 140 376 minecraft:lime_terracotta
fill 192 140 381 193 140 383 minecraft:lime_terracotta
fill 192 140 388 193 140 390 minecraft:lime_terracotta
fill 192 140 395 193 140 397 minecraft:lime_terracotta
fill 192 140 402 193 140 404 minecraft:lime_terracotta
fill 192 140 409 193 140 410 minecraft:lime_terracotta
fill 194 140 374 194 140 376 minecraft:green_terracotta
fill 194 140 381 194 140 383 minecraft:green_terracotta
fill 194 140 388 194 140 390 minecraft:green_terracotta
fill 194 140 395 194 140 397 minecraft:green_terracotta
fill 194 140 402 194 140 404 minecraft:green_terracotta
fill 194 140 409 194 140 410 minecraft:green_terracotta
fill 195 140 374 197 140 376 minecraft:lime_terracotta
fill 195 140 381 197 140 383 minecraft:lime_terracotta
fill 195 140 388 197 140 390 minecraft:lime_terracotta
fill 195 140 395 197 140 397 minecraft:lime_terracotta
fill 195 140 402 197 140 404 minecraft:lime_terracotta
fill 195 140 409 197 140 410 minecraft:lime_terracotta
fill 196 140 371 196 140 373 minecraft:green_terracotta
fill 196 140 378 196 140 380 minecraft:green_terracotta
fill 196 140 385 196 140 387 minecraft:green_terracotta
fill 196 140 392 196 140 394 minecraft:green_terracotta
fill 196 140 399 196 140 401 minecraft:green_terracotta
fill 196 140 406 196 140 408 minecraft:green_terracotta
fill 197 140 371 202 140 373 minecraft:lime_terracotta
fill 197 140 378 202 140 380 minecraft:lime_terracotta
fill 197 140 385 202 140 387 minecraft:lime_terracotta
fill 197 140 392 200 140 394 minecraft:lime_terracotta
fill 197 140 399 202 140 401 minecraft:lime_terracotta
fill 197 140 406 202 140 408 minecraft:lime_terracotta
fill 198 140 374 198 140 376 minecraft:green_terracotta
fill 198 140 381 198 140 383 minecraft:green_terracotta
fill 198 140 388 198 140 390 minecraft:green_terracotta
fill 198 140 395 198 140 397 minecraft:green_terracotta
fill 198 140 402 198 140 404 minecraft:green_terracotta
fill 198 140 409 198 140 410 minecraft:green_terracotta
fill 199 140 374 200 140 376 minecraft:lime_terracotta
fill 199 140 381 200 140 383 minecraft:lime_terracotta
fill 199 140 388 200 140 390 minecraft:lime_terracotta
fill 199 140 395 200 140 397 minecraft:lime_terracotta
fill 199 140 402 200 140 404 minecraft:lime_terracotta
fill 199 140 409 200 140 410 minecraft:lime_terracotta
fill 201 140 374 201 140 376 minecraft:green_terracotta
fill 201 140 381 201 140 383 minecraft:green_terracotta
setblock 201 140 388 minecraft:green_terracotta
fill 201 140 389 206 140 393 minecraft:dark_oak_planks
fill 201 140 394 202 140 394 minecraft:lime_terracotta
fill 201 140 395 201 140 397 minecraft:green_terracotta
fill 201 140 402 201 140 404 minecraft:green_terracotta
fill 201 140 409 201 140 410 minecraft:green_terracotta
fill 202 140 374 204 140 376 minecraft:lime_terracotta
fill 202 140 381 204 140 383 minecraft:lime_terracotta
setblock 202 140 388 minecraft:lime_terracotta
fill 202 140 395 204 140 397 minecraft:lime_terracotta
fill 202 140 402 204 140 404 minecraft:lime_terracotta
fill 202 140 409 204 140 410 minecraft:lime_terracotta
fill 203 140 371 203 140 373 minecraft:green_terracotta
fill 203 140 378 203 140 380 minecraft:green_terracotta
fill 203 140 385 203 140 387 minecraft:green_terracotta
fill 203 140 388 208 140 388 minecraft:dark_oak_planks
fill 203 140 394 208 140 394 minecraft:dark_oak_planks
fill 203 140 399 203 140 401 minecraft:green_terracotta
fill 203 140 406 203 140 408 minecraft:green_terracotta
fill 204 140 371 209 140 373 minecraft:lime_terracotta
fill 204 140 378 209 140 380 minecraft:lime_terracotta
fill 204 140 385 204 140 387 minecraft:lime_terracotta
fill 204 140 399 209 140 401 minecraft:lime_terracotta
fill 204 140 406 209 140 408 minecraft:lime_terracotta
fill 205 140 374 205 140 376 minecraft:green_terracotta
fill 205 140 381 205 140 383 minecraft:green_terracotta
fill 205 140 385 209 140 386 minecraft:lime_terracotta
fill 205 140 387 215 140 387 minecraft:dark_oak_planks
fill 205 140 395 215 140 395 minecraft:dark_oak_planks
fill 205 140 396 205 140 397 minecraft:green_terracotta
fill 205 140 402 205 140 404 minecraft:green_terracotta
fill 205 140 409 205 140 410 minecraft:green_terracotta
fill 206 140 374 207 140 376 minecraft:lime_terracotta
fill 206 140 381 207 140 383 minecraft:lime_terracotta
fill 206 140 396 207 140 397 minecraft:lime_terracotta
fill 206 140 402 207 140 404 minecraft:lime_terracotta
fill 206 140 409 207 140 410 minecraft:lime_terracotta
setblock 207 140 389 minecraft:dark_oak_planks
fill 207 140 390 207 140 392 minecraft:sea_lantern
setblock 207 140 393 minecraft:dark_oak_planks
fill 208 140 374 208 140 376 minecraft:green_terracotta
fill 208 140 381 208 140 383 minecraft:green_terracotta
setblock 208 140 389 minecraft:sea_lantern
setblock 208 140 393 minecraft:sea_lantern
fill 208 140 396 208 140 397 minecraft:green_terracotta
fill 208 140 402 208 140 404 minecraft:green_terracotta
fill 208 140 409 208 140 410 minecraft:green_terracotta
fill 209 140 374 211 140 376 minecraft:lime_terracotta
fill 209 140 381 211 140 383 minecraft:lime_terracotta
fill 209 140 388 211 140 388 minecraft:sea_lantern
fill 209 140 394 211 140 394 minecraft:sea_lantern
fill 209 140 396 211 140 397 minecraft:lime_terracotta
fill 209 140 402 211 140 404 minecraft:lime_terracotta
fill 209 140 409 211 140 410 minecraft:lime_terracotta
fill 210 140 371 210 140 373 minecraft:green_terracotta
fill 210 140 378 210 140 380 minecraft:green_terracotta
fill 210 140 385 210 140 386 minecraft:green_terracotta
fill 210 140 399 210 140 401 minecraft:green_terracotta
fill 210 140 406 210 140 408 minecraft:green_terracotta
fill 211 140 371 216 140 373 minecraft:lime_terracotta
fill 211 140 378 216 140 380 minecraft:lime_terracotta
fill 211 140 385 216 140 386 minecraft:lime_terracotta
fill 211 140 399 216 140 401 minecraft:lime_terracotta
fill 211 140 406 216 140 408 minecraft:lime_terracotta
fill 212 140 374 212 140 376 minecraft:green_terracotta
fill 212 140 381 212 140 383 minecraft:green_terracotta
fill 212 140 388 217 140 388 minecraft:dark_oak_planks
setblock 212 140 389 minecraft:sea_lantern
setblock 212 140 393 minecraft:sea_lantern
fill 212 140 394 217 140 394 minecraft:dark_oak_planks
fill 212 140 396 212 140 397 minecraft:green_terracotta
fill 212 140 402 212 140 404 minecraft:green_terracotta
fill 212 140 409 212 140 410 minecraft:green_terracotta
fill 213 140 374 214 140 376 minecraft:lime_terracotta
fill 213 140 381 214 140 383 minecraft:lime_terracotta
fill 213 140 389 219 140 389 minecraft:dark_oak_planks
fill 213 140 390 213 140 392 minecraft:sea_lantern
fill 213 140 393 219 140 393 minecraft:dark_oak_planks
fill 213 140 396 214 140 397 minecraft:lime_terracotta
fill 213 140 402 214 140 404 minecraft:lime_terracotta
fill 213 140 409 214 140 410 minecraft:lime_terracotta
fill 214 140 390 215 140 392 minecraft:dark_oak_planks
fill 215 140 374 215 140 376 minecraft:green_terracotta
fill 215 140 381 215 140 383 minecraft:green_terracotta
fill 215 140 396 215 140 397 minecraft:green_terracotta
fill 215 140 402 215 140 404 minecraft:green_terracotta
fill 215 140 409 215 140 410 minecraft:green_terracotta
fill 216 140 374 218 140 376 minecraft:lime_terracotta
fill 216 140 381 218 140 383 minecraft:lime_terracotta
setblock 216 140 387 minecraft:lime_terracotta
fill 216 140 390 219 140 390 minecraft:dark_oak_planks
fill 216 140 392 219 140 392 minecraft:dark_oak_planks
fill 216 140 395 218 140 397 minecraft:lime_terracotta
fill 216 140 402 218 140 404 minecraft:lime_terracotta
fill 216 140 409 218 140 410 minecraft:lime_terracotta
fill 217 140 371 217 140 373 minecraft:green_terracotta
fill 217 140 378 217 140 380 minecraft:green_terracotta
fill 217 140 385 217 140 387 minecraft:green_terracotta
fill 217 140 391 219 140 391 minecraft:dark_oak_planks
fill 217 140 399 217 140 401 minecraft:green_terracotta
fill 217 140 406 217 140 408 minecraft:green_terracotta
fill 218 140 371 223 140 373 minecraft:lime_terracotta
fill 218 140 378 223 140 380 minecraft:lime_terracotta
fill 218 140 385 218 140 388 minecraft:lime_terracotta
fill 218 140 394 223 140 394 minecraft:lime_terracotta
fill 218 140 399 223 140 401 minecraft:lime_terracotta
fill 218 140 406 223 140 408 minecraft:lime_terracotta
fill 219 140 374 219 140 376 minecraft:green_terracotta
fill 219 140 381 219 140 383 minecraft:green_terracotta
fill 219 140 385 223 140 387 minecraft:lime_terracotta
setblock 219 140 388 minecraft:green_terracotta
fill 219 140 395 219 140 397 minecraft:green_terracotta
fill 219 140 402 219 140 404 minecraft:green_terracotta
fill 219 140 409 219 140 410 minecraft:green_terracotta
fill 220 140 374 221 140 376 minecraft:lime_terracotta
fill 220 140 381 221 140 383 minecraft:lime_terracotta
fill 220 140 388 221 140 390 minecraft:lime_terracotta
fill 220 140 391 229 140 391 minecraft:green_terracotta
fill 220 140 392 223 140 393 minecraft:lime_terracotta
fill 220 140 395 221 140 397 minecraft:lime_terracotta
fill 220 140 402 221 140 404 minecraft:lime_terracotta
fill 220 140 409 221 140 410 minecraft:lime_terracotta
fill 222 140 374 222 140 376 minecraft:green_terracotta
fill 222 140 381 222 140 383 minecraft:green_terracotta
fill 222 140 388 222 140 390 minecraft:green_terracotta
fill 222 140 395 222 140 397 minecraft:green_terracotta
fill 222 140 402 222 140 404 minecraft:green_terracotta
fill 222 140 409 222 140 410 minecraft:green_terracotta
fill 223 140 374 225 140 376 minecraft:lime_terracotta
fill 223 140 381 225 140 383 minecraft:lime_terracotta
fill 223 140 388 225 140 390 minecraft:lime_terracotta
fill 223 140 395 225 140 397 minecraft:lime_terracotta
fill 223 140 402 225 140 404 minecraft:lime_terracotta
fill 223 140 409 225 140 410 minecraft:lime_terracotta
fill 224 140 371 224 140 373 minecraft:green_terracotta
fill 224 140 378 224 140 380 minecraft:green_terracotta
fill 224 140 385 224 140 387 minecraft:green_terracotta
fill 224 140 392 224 140 394 minecraft:green_terracotta
fill 224 140 399 224 140 401 minecraft:green_terracotta
fill 224 140 406 224 140 408 minecraft:green_terracotta
fill 225 140 371 229 140 373 minecraft:lime_terracotta
fill 225 140 378 229 140 380 minecraft:lime_terracotta
fill 225 140 385 229 140 387 minecraft:lime_terracotta
fill 225 140 392 229 140 394 minecraft:lime_terracotta
fill 225 140 399 229 140 401 minecraft:lime_terracotta
fill 225 140 406 229 140 408 minecraft:lime_terracotta
fill 226 140 374 226 140 376 minecraft:green_terracotta
fill 226 140 381 226 140 383 minecraft:green_terracotta
fill 226 140 388 226 140 390 minecraft:green_terracotta
fill 226 140 395 226 140 397 minecraft:green_terracotta
fill 226 140 402 226 140 404 minecraft:green_terracotta
fill 226 140 409 226 140 410 minecraft:green_terracotta
fill 227 140 374 228 140 376 minecraft:lime_terracotta
fill 227 140 381 228 140 383 minecraft:lime_terracotta
fill 227 140 388 228 140 390 minecraft:lime_terracotta
fill 227 140 395 228 140 397 minecraft:lime_terracotta
fill 227 140 402 228 140 404 minecraft:lime_terracotta
fill 227 140 409 228 140 410 minecraft:lime_terracotta
fill 229 140 374 229 140 376 minecraft:green_terracotta
fill 229 140 381 229 140 383 minecraft:green_terracotta
fill 229 140 388 229 140 390 minecraft:green_terracotta
fill 229 140 395 229 140 397 minecraft:green_terracotta
fill 229 140 402 229 140 404 minecraft:green_terracotta
fill 229 140 409 229 140 410 minecraft:green_terracotta
fill 198 141 391 200 141 391 minecraft:dark_oak_planks
fill 199 141 389 200 141 390 minecraft:dark_oak_planks
fill 199 141 392 200 141 393 minecraft:dark_oak_planks
fill 200 141 388 202 141 388 minecraft:dark_oak_planks
fill 200 141 394 202 141 394 minecraft:dark_oak_planks
fill 201 141 387 204 141 387 minecraft:dark_oak_planks
fill 201 141 395 204 141 395 minecraft:dark_oak_planks
fill 204 141 386 216 141 386 minecraft:dark_oak_planks
fill 204 141 396 216 141 396 minecraft:dark_oak_planks
fill 209 141 385 211 143 385 minecraft:dark_oak_planks
fill 209 141 397 211 143 397 minecraft:dark_oak_planks
fill 216 141 387 219 141 387 minecraft:dark_oak_planks
fill 216 141 395 219 141 395 minecraft:dark_oak_planks
fill 218 141 388 220 141 388 minecraft:dark_oak_planks
fill 218 141 394 220 141 394 minecraft:dark_oak_planks
fill 220 141 389 221 141 393 minecraft:dark_oak_planks
setblock 222 141 391 minecraft:dark_oak_planks
fill 197 142 390 197 143 392 minecraft:dark_oak_planks
fill 198 142 389 198 142 390 minecraft:dark_oak_planks
fill 198 142 392 198 142 393 minecraft:dark_oak_planks
setblock 199 142 388 minecraft:dark_oak_planks
setblock 199 142 394 minecraft:dark_oak_planks
fill 200 142 387 201 142 387 minecraft:dark_oak_planks
fill 200 142 395 201 142 395 minecraft:dark_oak_planks
fill 202 142 386 204 142 386 minecraft:dark_oak_planks
fill 202 142 396 204 142 396 minecraft:dark_oak_planks
fill 205 142 385 208 143 385 minecraft:dark_oak_planks
fill 205 142 397 208 143 397 minecraft:dark_oak_planks
fill 212 142 385 215 143 385 minecraft:dark_oak_planks
fill 212 142 397 215 143 397 minecraft:dark_oak_planks
fill 216 142 386 218 142 386 minecraft:dark_oak_planks
fill 216 142 396 218 142 396 minecraft:dark_oak_planks
fill 219 142 387 220 142 387 minecraft:dark_oak_planks
fill 219 142 395 220 142 395 minecraft:dark_oak_planks
setblock 221 142 388 minecraft:dark_oak_planks
setblock 221 142 394 minecraft:dark_oak_planks
fill 222 142 389 222 142 390 minecraft:dark_oak_planks
fill 222 142 392 222 142 393 minecraft:dark_oak_planks
fill 223 142 390 223 143 392 minecraft:dark_oak_planks
setblock 191 143 372 minecraft:light[level=14]
setblock 191 143 380 minecraft:light[level=14]
setblock 191 143 388 minecraft:light[level=14]
setblock 191 143 396 minecraft:light[level=14]
setblock 191 143 404 minecraft:light[level=14]
setblock 197 143 389 minecraft:dark_oak_planks
setblock 197 143 393 minecraft:dark_oak_planks
setblock 198 143 388 minecraft:dark_oak_planks
setblock 198 143 394 minecraft:dark_oak_planks
setblock 199 143 372 minecraft:light[level=14]
setblock 199 143 380 minecraft:light[level=14]
fill 199 143 387 200 143 387 minecraft:dark_oak_planks
setblock 199 143 388 minecraft:light[level=14]
fill 199 143 395 200 143 395 minecraft:dark_oak_planks
setblock 199 143 396 minecraft:light[level=14]
setblock 199 143 404 minecraft:light[level=14]
fill 201 143 386 202 143 386 minecraft:dark_oak_planks
fill 201 143 396 202 143 396 minecraft:dark_oak_planks
fill 203 143 385 204 143 385 minecraft:dark_oak_planks
fill 203 143 397 204 143 397 minecraft:dark_oak_planks
setblock 207 143 372 minecraft:light[level=14]
setblock 207 143 380 minecraft:light[level=14]
setblock 207 143 388 minecraft:light[level=14]
setblock 207 143 396 minecraft:light[level=14]
setblock 207 143 404 minecraft:light[level=14]
setblock 215 143 372 minecraft:light[level=14]
setblock 215 143 380 minecraft:light[level=14]
setblock 215 143 388 minecraft:light[level=14]
setblock 215 143 396 minecraft:light[level=14]
setblock 215 143 404 minecraft:light[level=14]
fill 216 143 385 217 143 385 minecraft:dark_oak_planks
fill 216 143 397 217 143 397 minecraft:dark_oak_planks
fill 218 143 386 219 143 386 minecraft:dark_oak_planks
fill 218 143 396 219 143 396 minecraft:dark_oak_planks
fill 220 143 387 221 143 387 minecraft:dark_oak_planks
fill 220 143 395 221 143 395 minecraft:dark_oak_planks
setblock 222 143 388 minecraft:dark_oak_planks
setblock 222 143 394 minecraft:dark_oak_planks
setblock 223 143 372 minecraft:light[level=14]
setblock 223 143 380 minecraft:light[level=14]
setblock 223 143 388 minecraft:light[level=14]
setblock 223 143 389 minecraft:dark_oak_planks
setblock 223 143 393 minecraft:dark_oak_planks
setblock 223 143 396 minecraft:light[level=14]
setblock 223 143 404 minecraft:light[level=14]
fill 188 144 373 188 145 374 minecraft:lime_terracotta
setblock 188 144 377 minecraft:lime_terracotta
fill 188 144 378 188 147 378 minecraft:moss_block
fill 188 144 385 188 145 386 minecraft:lime_terracotta
fill 188 144 394 188 145 394 minecraft:lime_terracotta
fill 188 144 397 188 144 398 minecraft:lime_terracotta
fill 188 144 405 188 145 406 minecraft:lime_terracotta
fill 189 144 370 191 144 370 minecraft:mud
fill 189 144 372 189 144 374 minecraft:mud
fill 189 144 376 189 144 378 minecraft:mud
fill 189 144 380 189 144 382 minecraft:mud
fill 189 144 384 189 144 386 minecraft:mud
fill 189 144 388 189 144 390 minecraft:mud
fill 189 144 392 189 144 394 minecraft:mud
fill 189 144 396 189 144 398 minecraft:mud
fill 189 144 400 189 144 402 minecraft:mud
fill 189 144 404 189 144 406 minecraft:mud
fill 189 144 408 189 144 410 minecraft:mud
setblock 191 144 388 minecraft:moss_block
fill 191 144 410 193 144 410 minecraft:mud
fill 193 144 370 195 144 370 minecraft:mud
fill 194 144 411 195 144 411 minecraft:lime_terracotta
fill 195 144 369 196 144 369 minecraft:lime_terracotta
fill 195 144 410 197 144 410 minecraft:mud
fill 197 144 370 199 144 370 minecraft:mud
fill 197 144 389 205 144 393 minecraft:spruce_planks
fill 198 144 388 206 144 388 minecraft:spruce_planks
fill 198 144 394 206 144 394 minecraft:spruce_planks
fill 199 144 369 199 145 369 minecraft:lime_terracotta
fill 199 144 387 208 144 387 minecraft:spruce_planks
fill 199 144 395 208 144 395 minecraft:spruce_planks
fill 199 144 410 201 144 410 minecraft:mud
fill 201 144 370 203 144 370 minecraft:mud
fill 201 144 386 219 144 386 minecraft:spruce_planks
fill 201 144 396 219 144 396 minecraft:spruce_planks
fill 202 144 411 203 145 411 minecraft:lime_terracotta
fill 203 144 385 217 144 385 minecraft:spruce_planks
fill 203 144 397 217 144 397 minecraft:spruce_planks
fill 203 144 410 205 144 410 minecraft:mud
fill 205 144 370 207 144 370 minecraft:mud
setblock 206 144 389 minecraft:spruce_planks
setblock 206 144 393 minecraft:spruce_planks
setblock 206 144 411 minecraft:lime_terracotta
fill 207 144 369 208 145 369 minecraft:lime_terracotta
fill 207 144 410 209 144 410 minecraft:mud
fill 207 144 411 207 147 411 minecraft:moss_block
fill 209 144 370 211 144 370 minecraft:mud
fill 211 144 410 213 144 410 minecraft:mud
fill 212 144 387 221 144 387 minecraft:spruce_planks
fill 212 144 395 221 144 395 minecraft:spruce_planks
fill 213 144 370 215 144 370 minecraft:mud
fill 214 144 388 222 144 389 minecraft:spruce_planks
fill 214 144 393 222 144 394 minecraft:spruce_planks
fill 214 144 411 215 145 411 minecraft:lime_terracotta
fill 215 144 369 215 147 369 minecraft:moss_block
fill 215 144 390 223 144 392 minecraft:spruce_planks
fill 215 144 410 217 144 410 minecraft:mud
setblock 216 144 369 minecraft:lime_terracotta
fill 217 144 370 219 144 370 minecraft:mud
fill 219 144 369 220 145 369 minecraft:lime_terracotta
fill 219 144 410 221 144 410 minecraft:mud
fill 221 144 370 223 144 370 minecraft:mud
setblock 223 144 389 minecraft:spruce_planks
setblock 223 144 393 minecraft:spruce_planks
fill 223 144 410 225 144 410 minecraft:mud
fill 223 144 411 223 145 411 minecraft:lime_terracotta
fill 225 144 370 227 144 370 minecraft:mud
fill 226 144 411 227 144 411 minecraft:lime_terracotta
fill 227 144 369 228 144 369 minecraft:lime_terracotta
fill 227 144 410 229 144 410 minecraft:mud
fill 229 144 370 229 144 372 minecraft:mud
fill 229 144 374 229 144 376 minecraft:mud
fill 229 144 378 229 144 380 minecraft:mud
fill 229 144 382 229 144 384 minecraft:mud
fill 229 144 386 229 144 388 minecraft:mud
fill 229 144 390 229 144 392 minecraft:mud
fill 229 144 394 229 144 396 minecraft:mud
fill 229 144 398 229 144 400 minecraft:mud
fill 229 144 402 229 144 404 minecraft:mud
fill 229 144 406 229 144 408 minecraft:mud
fill 230 144 378 230 145 379 minecraft:lime_terracotta
fill 230 144 386 230 147 386 minecraft:moss_block
setblock 230 144 387 minecraft:lime_terracotta
fill 230 144 390 230 145 390 minecraft:lime_terracotta
fill 230 144 398 230 144 399 minecraft:lime_terracotta
fill 230 144 410 230 145 410 minecraft:lime_terracotta
fill 188 145 377 188 147 377 minecraft:moss_block
fill 188 145 381 188 147 381 minecraft:moss_block
setblock 188 145 382 minecraft:lime_terracotta
setblock 188 145 393 minecraft:lime_terracotta
fill 188 145 397 188 147 398 minecraft:moss_block
fill 190 145 411 191 145 411 minecraft:lime_terracotta
setblock 194 145 411 minecraft:lime_terracotta
fill 195 145 369 196 148 369 minecraft:moss_block
fill 195 145 411 195 148 411 minecraft:moss_block
setblock 200 145 369 minecraft:lime_terracotta
fill 206 145 411 206 148 411 minecraft:moss_block
fill 210 145 411 210 147 411 minecraft:moss_block
setblock 211 145 369 minecraft:lime_terracotta
setblock 211 145 411 minecraft:lime_terracotta
fill 212 145 369 212 147 369 minecraft:moss_block
fill 216 145 369 216 148 369 minecraft:moss_block
fill 217 145 391 217 148 391 minecraft:stripped_dark_oak_log
setblock 222 145 411 minecraft:lime_terracotta
fill 226 145 411 227 148 411 minecraft:moss_block
fill 227 145 369 227 148 369 minecraft:moss_block
setblock 228 145 369 minecraft:lime_terracotta
fill 230 145 370 230 145 371 minecraft:lime_terracotta
fill 230 145 387 230 148 387 minecraft:moss_block
setblock 230 145 391 minecraft:lime_terracotta
fill 230 145 398 230 148 398 minecraft:moss_block
setblock 230 145 399 minecraft:lime_terracotta
setblock 230 145 402 minecraft:lime_terracotta
fill 230 145 403 230 147 403 minecraft:moss_block
fill 188 146 371 188 147 372 minecraft:lime_terracotta
fill 188 146 373 188 151 374 minecraft:moss_block
setblock 188 146 379 minecraft:moss_block
fill 188 146 380 188 147 380 minecraft:lime_terracotta
fill 188 146 382 188 151 382 minecraft:moss_block
fill 188 146 383 188 146 384 minecraft:lime_terracotta
fill 188 146 385 188 148 386 minecraft:moss_block
fill 188 146 391 188 147 392 minecraft:lime_terracotta
fill 188 146 393 188 151 394 minecraft:moss_block
setblock 188 146 395 minecraft:lime_terracotta
fill 188 146 396 188 149 396 minecraft:moss_block
fill 188 146 403 188 146 404 minecraft:lime_terracotta
fill 188 146 405 188 151 406 minecraft:moss_block
setblock 188 146 411 minecraft:moss_block
fill 189 146 369 190 147 369 minecraft:lime_terracotta
fill 189 146 411 189 147 411 minecraft:lime_terracotta
fill 190 146 411 191 151 411 minecraft:moss_block
setblock 192 146 411 minecraft:lime_terracotta
fill 193 146 411 194 149 411 minecraft:moss_block
fill 197 146 369 197 149 369 minecraft:moss_block
setblock 198 146 369 minecraft:lime_terracotta
fill 199 146 369 200 151 369 minecraft:moss_block
fill 200 146 411 201 147 411 minecraft:lime_terracotta
fill 201 146 369 202 147 369 minecraft:lime_terracotta
fill 202 146 411 203 151 411 minecraft:moss_block
fill 207 146 369 208 151 369 minecraft:moss_block
fill 209 146 369 210 146 369 minecraft:lime_terracotta
fill 211 146 369 211 151 369 minecraft:moss_block
fill 211 146 411 211 151 411 minecraft:moss_block
fill 212 146 411 213 146 411 minecraft:lime_terracotta
fill 214 146 411 215 151 411 minecraft:moss_block
fill 219 146 369 220 151 369 minecraft:moss_block
fill 220 146 411 221 147 411 minecraft:lime_terracotta
fill 221 146 369 222 147 369 minecraft:lime_terracotta
fill 222 146 411 223 151 411 minecraft:moss_block
setblock 224 146 411 minecraft:lime_terracotta
fill 225 146 411 225 149 411 minecraft:moss_block
fill 226 146 392 226 163 392 minecraft:iron_block
fill 228 146 369 229 149 369 minecraft:moss_block
setblock 230 146 369 minecraft:lime_terracotta
fill 230 146 370 230 151 371 minecraft:moss_block
fill 230 146 372 230 147 372 minecraft:lime_terracotta
setblock 230 146 373 minecraft:moss_block
fill 230 146 378 230 151 379 minecraft:moss_block
fill 230 146 380 230 146 381 minecraft:lime_terracotta
fill 230 146 390 230 151 391 minecraft:moss_block
fill 230 146 392 230 147 393 minecraft:lime_terracotta
fill 230 146 399 230 151 399 minecraft:moss_block
fill 230 146 400 230 146 401 minecraft:lime_terracotta
fill 230 146 402 230 151 402 minecraft:moss_block
fill 230 146 404 230 147 404 minecraft:lime_terracotta
setblock 230 146 405 minecraft:moss_block
fill 230 146 410 230 151 410 minecraft:moss_block
setblock 188 147 379 minecraft:lime_terracotta
setblock 188 147 383 minecraft:lime_terracotta
fill 188 147 384 188 150 384 minecraft:moss_block
fill 188 147 395 188 149 395 minecraft:moss_block
fill 188 147 399 188 149 399 minecraft:moss_block
setblock 188 147 400 minecraft:lime_terracotta
setblock 188 147 403 minecraft:lime_terracotta
fill 188 147 404 188 150 404 minecraft:moss_block
setblock 188 147 411 minecraft:lime_terracotta
fill 192 147 411 192 150 411 minecraft:moss_block
setblock 193 147 369 minecraft:lime_terracotta
fill 194 147 369 194 149 369 minecraft:moss_block
fill 198 147 369 198 150 369 minecraft:moss_block
fill 208 147 411 209 147 411 minecraft:lime_terracotta
fill 209 147 369 209 150 369 minecraft:moss_block
setblock 210 147 369 minecraft:lime_terracotta
setblock 212 147 411 minecraft:lime_terracotta
fill 213 147 369 214 147 369 minecraft:lime_terracotta
fill 213 147 411 213 150 411 minecraft:moss_block
fill 224 147 411 224 150 411 minecraft:moss_block
fill 228 147 411 228 149 411 minecraft:moss_block
setblock 229 147 411 minecraft:lime_terracotta
fill 230 147 369 230 150 369 minecraft:moss_block
setblock 230 147 373 minecraft:lime_terracotta
fill 230 147 380 230 150 380 minecraft:moss_block
setblock 230 147 381 minecraft:lime_terracotta
setblock 230 147 384 minecraft:lime_terracotta
fill 230 147 385 230 149 385 minecraft:moss_block
fill 230 147 400 230 150 401 minecraft:moss_block
setblock 230 147 405 minecraft:lime_terracotta
fill 188 148 369 188 148 370 minecraft:lime_terracotta
fill 188 148 371 188 153 372 minecraft:moss_block
fill 188 148 377 188 149 378 minecraft:lime_terracotta
fill 188 148 379 188 153 380 minecraft:moss_block
setblock 188 148 381 minecraft:lime_terracotta
fill 188 148 383 188 150 383 minecraft:moss_block
fill 188 148 389 188 149 390 minecraft:lime_terracotta
fill 188 148 391 188 153 392 minecraft:moss_block
setblock 188 148 397 minecraft:moss_block
fill 188 148 398 188 149 398 minecraft:lime_terracotta
fill 188 148 400 188 153 400 minecraft:moss_block
fill 188 148 401 188 148 402 minecraft:lime_terracotta
fill 188 148 403 188 153 403 minecraft:moss_block
fill 188 148 409 188 149 410 minecraft:lime_terracotta
fill 188 148 411 189 153 411 minecraft:moss_block
fill 189 148 369 190 153 369 minecraft:moss_block
fill 191 148 369 192 148 369 minecraft:lime_terracotta
fill 193 148 369 193 153 369 minecraft:moss_block
fill 193 148 388 193 149 388 minecraft:verdant_froglight
fill 198 148 411 199 148 411 minecraft:lime_terracotta
fill 200 148 411 201 153 411 minecraft:moss_block
fill 201 148 369 202 153 369 minecraft:moss_block
fill 203 148 369 204 149 369 minecraft:lime_terracotta
fill 207 148 411 207 149 411 minecraft:lime_terracotta
fill 208 148 411 209 153 411 minecraft:moss_block
fill 210 148 369 210 153 369 minecraft:moss_block
setblock 210 148 411 minecraft:lime_terracotta
setblock 212 148 369 minecraft:lime_terracotta
fill 212 148 411 212 153 411 minecraft:moss_block
fill 213 148 369 214 153 369 minecraft:moss_block
fill 215 148 369 215 149 369 minecraft:lime_terracotta
fill 218 148 411 219 149 411 minecraft:lime_terracotta
fill 220 148 411 221 153 411 minecraft:moss_block
fill 221 148 369 222 153 369 minecraft:moss_block
fill 223 148 369 224 148 369 minecraft:lime_terracotta
fill 229 148 411 229 153 411 minecraft:moss_block
fill 230 148 372 230 153 373 minecraft:moss_block
fill 230 148 374 230 149 375 minecraft:lime_terracotta
fill 230 148 381 230 153 381 minecraft:moss_block
fill 230 148 382 230 148 383 minecraft:lime_terracotta
fill 230 148 384 230 153 384 minecraft:moss_block
fill 230 148 386 230 149 386 minecraft:lime_terracotta
fill 230 148 392 230 153 393 minecraft:moss_block
fill 230 148 394 230 149 395 minecraft:lime_terracotta
setblock 230 148 403 minecraft:lime_terracotta
fill 230 148 404 230 153 405 minecraft:moss_block
fill 230 148 406 230 149 407 minecraft:lime_terracotta
fill 230 148 411 230 149 411 minecraft:lime_terracotta
setblock 188 149 369 minecraft:lime_terracotta
fill 188 149 370 188 152 370 minecraft:moss_block
fill 188 149 381 188 152 381 minecraft:moss_block
fill 188 149 385 188 151 385 minecraft:moss_block
setblock 188 149 386 minecraft:lime_terracotta
setblock 188 149 397 minecraft:lime_terracotta
fill 188 149 401 188 152 402 minecraft:moss_block
fill 191 149 369 191 152 369 minecraft:moss_block
setblock 192 149 369 minecraft:lime_terracotta
fill 195 149 369 196 149 369 minecraft:lime_terracotta
setblock 195 149 411 minecraft:lime_terracotta
setblock 198 149 411 minecraft:lime_terracotta
fill 199 149 411 199 152 411 minecraft:moss_block
setblock 206 149 411 minecraft:lime_terracotta
fill 210 149 411 210 152 411 minecraft:moss_block
fill 212 149 369 212 152 369 minecraft:moss_block
setblock 216 149 369 minecraft:lime_terracotta
fill 217 149 387 217 158 395 minecraft:white_wool
fill 223 149 369 223 152 369 minecraft:moss_block
setblock 224 149 369 minecraft:lime_terracotta
fill 226 149 411 227 149 411 minecraft:lime_terracotta
setblock 227 149 369 minecraft:lime_terracotta
fill 230 149 382 230 152 383 minecraft:moss_block
setblock 230 149 387 minecraft:lime_terracotta
setblock 230 149 398 minecraft:lime_terracotta
fill 230 149 403 230 152 403 minecraft:moss_block
fill 188 150 369 188 155 369 minecraft:moss_block
fill 188 150 375 188 151 376 minecraft:lime_terracotta
fill 188 150 377 188 155 378 minecraft:moss_block
fill 188 150 386 188 151 386 minecraft:moss_block
fill 188 150 387 188 150 388 minecraft:lime_terracotta
fill 188 150 389 188 155 390 minecraft:moss_block
fill 188 150 395 188 151 396 minecraft:lime_terracotta
fill 188 150 397 188 155 398 minecraft:moss_block
setblock 188 150 399 minecraft:lime_terracotta
fill 188 150 407 188 151 408 minecraft:lime_terracotta
fill 188 150 409 188 155 410 minecraft:moss_block
fill 189 150 370 191 150 370 minecraft:mud
fill 189 150 372 189 150 374 minecraft:mud
fill 189 150 376 189 150 378 minecraft:mud
fill 189 150 380 189 150 382 minecraft:mud
fill 189 150 384 189 150 386 minecraft:mud
fill 189 150 388 189 150 390 minecraft:mud
fill 189 150 392 189 150 394 minecraft:mud
fill 189 150 396 189 150 398 minecraft:mud
fill 189 150 400 189 150 402 minecraft:mud
fill 189 150 404 189 150 406 minecraft:mud
fill 189 150 408 189 150 410 minecraft:mud
fill 191 150 410 193 150 410 minecraft:mud
fill 192 150 369 192 155 369 minecraft:moss_block
fill 193 150 370 195 150 370 minecraft:mud
fill 193 150 388 193 162 388 minecraft:mud
fill 193 150 411 193 151 411 minecraft:lime_terracotta
setblock 194 150 369 minecraft:lime_terracotta
fill 194 150 411 195 151 411 minecraft:moss_block
fill 195 150 369 196 155 369 minecraft:moss_block
fill 195 150 410 197 150 410 minecraft:mud
fill 196 150 411 197 150 411 minecraft:lime_terracotta
fill 197 150 369 197 151 369 minecraft:lime_terracotta
fill 197 150 370 199 150 370 minecraft:mud
fill 198 150 411 198 155 411 minecraft:moss_block
fill 199 150 410 201 150 410 minecraft:mud
fill 201 150 370 203 150 370 minecraft:mud
fill 203 150 369 204 155 369 minecraft:moss_block
fill 203 150 410 205 150 410 minecraft:mud
fill 204 150 411 205 151 411 minecraft:lime_terracotta
fill 205 150 369 206 150 369 minecraft:lime_terracotta
fill 205 150 370 207 150 370 minecraft:mud
fill 206 150 411 207 155 411 minecraft:moss_block
fill 207 150 410 209 150 410 minecraft:mud
fill 209 150 370 211 150 370 minecraft:mud
fill 211 150 410 213 150 410 minecraft:mud
fill 213 150 370 215 150 370 minecraft:mud
fill 215 150 369 216 155 369 minecraft:moss_block
fill 215 150 410 217 150 410 minecraft:mud
fill 216 150 411 217 150 411 minecraft:lime_terracotta
fill 217 150 369 218 151 369 minecraft:lime_terracotta
fill 217 150 370 219 150 370 minecraft:mud
fill 218 150 411 219 155 411 minecraft:moss_block
fill 219 150 410 221 150 410 minecraft:mud
fill 221 150 370 223 150 370 minecraft:mud
fill 223 150 410 225 150 410 minecraft:mud
fill 224 150 369 224 155 369 minecraft:moss_block
fill 225 150 369 226 150 369 minecraft:lime_terracotta
fill 225 150 370 227 150 370 minecraft:mud
fill 225 150 411 225 151 411 minecraft:lime_terracotta
fill 226 150 411 227 155 411 minecraft:moss_block
fill 227 150 369 228 151 369 minecraft:moss_block
fill 227 150 410 229 150 410 minecraft:mud
setblock 228 150 411 minecraft:lime_terracotta
fill 229 150 369 229 151 369 minecraft:lime_terracotta
fill 229 150 370 229 150 372 minecraft:mud
fill 229 150 374 229 150 376 minecraft:mud
fill 229 150 378 229 150 380 minecraft:mud
fill 229 150 382 229 150 384 minecraft:mud
fill 229 150 386 229 150 388 minecraft:mud
fill 229 150 390 229 150 392 minecraft:mud
fill 229 150 394 229 150 396 minecraft:mud
fill 229 150 398 229 150 400 minecraft:mud
fill 229 150 402 229 150 404 minecraft:mud
fill 229 150 406 229 150 408 minecraft:mud
fill 230 150 374 230 155 375 minecraft:moss_block
fill 230 150 376 230 151 377 minecraft:lime_terracotta
setblock 230 150 385 minecraft:lime_terracotta
fill 230 150 386 230 155 387 minecraft:moss_block
fill 230 150 388 230 151 389 minecraft:lime_terracotta
fill 230 150 394 230 155 395 minecraft:moss_block
fill 230 150 396 230 150 397 minecraft:lime_terracotta
fill 230 150 398 230 155 398 minecraft:moss_block
fill 230 150 406 230 155 407 minecraft:moss_block
fill 230 150 408 230 151 409 minecraft:lime_terracotta
fill 230 150 411 230 155 411 minecraft:moss_block
fill 188 151 383 188 151 384 minecraft:lime_terracotta
setblock 188 151 387 minecraft:lime_terracotta
fill 188 151 388 188 154 388 minecraft:moss_block
fill 188 151 399 188 154 399 minecraft:moss_block
setblock 188 151 404 minecraft:lime_terracotta
setblock 191 151 372 minecraft:light[level=14]
setblock 191 151 380 minecraft:light[level=14]
setblock 191 151 388 minecraft:light[level=14]
setblock 191 151 396 minecraft:light[level=14]
setblock 191 151 404 minecraft:light[level=14]
fill 192 151 388 192 158 388 minecraft:mud
setblock 192 151 411 minecraft:lime_terracotta
fill 193 151 389 193 158 389 minecraft:mud
fill 194 151 369 194 154 369 minecraft:moss_block
fill 196 151 411 197 154 411 minecraft:moss_block
setblock 198 151 369 minecraft:lime_terracotta
setblock 199 151 372 minecraft:light[level=14]
setblock 199 151 380 minecraft:light[level=14]
setblock 199 151 388 minecraft:light[level=14]
setblock 199 151 396 minecraft:light[level=14]
setblock 199 151 404 minecraft:light[level=14]
fill 205 151 369 205 154 369 minecraft:moss_block
setblock 206 151 369 minecraft:lime_terracotta
setblock 207 151 372 minecraft:light[level=14]
setblock 207 151 380 minecraft:light[level=14]
setblock 207 151 388 minecraft:light[level=14]
setblock 207 151 396 minecraft:light[level=14]
setblock 207 151 404 minecraft:light[level=14]
setblock 209 151 369 minecraft:lime_terracotta
setblock 213 151 411 minecraft:lime_terracotta
setblock 215 151 372 minecraft:light[level=14]
setblock 215 151 380 minecraft:light[level=14]
setblock 215 151 388 minecraft:light[level=14]
setblock 215 151 396 minecraft:light[level=14]
setblock 215 151 404 minecraft:light[level=14]
setblock 216 151 411 minecraft:lime_terracotta
fill 217 151 411 217 154 411 minecraft:moss_block
setblock 223 151 372 minecraft:light[level=14]
setblock 223 151 380 minecraft:light[level=14]
setblock 223 151 388 minecraft:light[level=14]
setblock 223 151 396 minecraft:light[level=14]
setblock 223 151 404 minecraft:light[level=14]
setblock 224 151 411 minecraft:lime_terracotta
fill 225 151 369 226 154 369 minecraft:moss_block
fill 228 151 411 228 154 411 minecraft:moss_block
setblock 230 151 369 minecraft:lime_terracotta
setblock 230 151 380 minecraft:lime_terracotta
fill 230 151 385 230 154 385 minecraft:moss_block
fill 230 151 396 230 154 396 minecraft:moss_block
setblock 230 151 397 minecraft:lime_terracotta
fill 230 151 400 230 151 401 minecraft:lime_terracotta
fill 188 152 373 188 153 374 minecraft:lime_terracotta
fill 188 152 375 188 157 376 minecraft:moss_block
fill 188 152 382 188 153 382 minecraft:lime_terracotta
fill 188 152 383 188 153 384 minecraft:moss_block
fill 188 152 385 188 152 386 minecraft:lime_terracotta
fill 188 152 387 188 157 387 minecraft:moss_block
fill 188 152 393 188 153 394 minecraft:lime_terracotta
fill 188 152 395 188 157 396 minecraft:moss_block
fill 188 152 404 188 157 404 minecraft:moss_block
fill 188 152 405 188 152 406 minecraft:lime_terracotta
fill 188 152 407 188 157 408 minecraft:moss_block
fill 190 152 411 191 153 411 minecraft:lime_terracotta
fill 192 152 387 193 158 387 minecraft:mud
fill 192 152 389 192 158 389 minecraft:mud
fill 192 152 411 193 157 411 minecraft:moss_block
fill 194 152 388 194 158 389 minecraft:mud
setblock 194 152 411 minecraft:lime_terracotta
fill 195 152 411 195 155 411 minecraft:moss_block
fill 196 152 381 197 153 382 minecraft:lime_concrete
fill 197 152 369 198 157 369 minecraft:moss_block
fill 199 152 369 200 153 369 minecraft:lime_terracotta
fill 202 152 411 203 153 411 minecraft:lime_terracotta
fill 204 152 411 205 157 411 minecraft:moss_block
fill 206 152 369 206 157 369 minecraft:moss_block
fill 207 152 369 208 152 369 minecraft:lime_terracotta
fill 209 152 369 209 157 369 minecraft:moss_block
fill 211 152 369 211 153 369 minecraft:lime_terracotta
fill 211 152 411 211 153 411 minecraft:lime_terracotta
fill 213 152 411 213 157 411 minecraft:moss_block
fill 214 152 411 215 152 411 minecraft:lime_terracotta
fill 216 152 411 216 157 411 minecraft:moss_block
fill 217 152 369 218 157 369 minecraft:moss_block
fill 219 152 369 220 153 369 minecraft:lime_terracotta
fill 222 152 411 223 153 411 minecraft:lime_terracotta
fill 224 152 411 225 157 411 minecraft:moss_block
fill 227 152 369 227 155 369 minecraft:moss_block
setblock 228 152 369 minecraft:lime_terracotta
fill 229 152 369 230 157 369 minecraft:moss_block
fill 230 152 370 230 153 371 minecraft:lime_terracotta
fill 230 152 376 230 157 377 minecraft:moss_block
fill 230 152 378 230 152 379 minecraft:lime_terracotta
fill 230 152 380 230 157 380 minecraft:moss_block
fill 230 152 388 230 157 389 minecraft:moss_block
fill 230 152 390 230 153 391 minecraft:lime_terracotta
fill 230 152 397 230 157 397 minecraft:moss_block
setblock 230 152 399 minecraft:lime_terracotta
fill 230 152 400 230 157 401 minecraft:moss_block
fill 230 152 402 230 153 402 minecraft:lime_terracotta
fill 230 152 408 230 157 409 minecraft:moss_block
setblock 230 152 410 minecraft:lime_terracotta
setblock 188 153 370 minecraft:lime_terracotta
setblock 188 153 381 minecraft:lime_terracotta
fill 188 153 385 188 155 386 minecraft:moss_block
fill 188 153 401 188 153 402 minecraft:lime_terracotta
setblock 188 153 405 minecraft:lime_terracotta
fill 188 153 406 188 156 406 minecraft:moss_block
setblock 191 153 369 minecraft:lime_terracotta
fill 191 153 388 191 158 388 minecraft:mud
fill 191 153 391 191 155 391 minecraft:iron_block
fill 193 153 390 193 158 390 minecraft:mud
fill 194 153 387 194 158 387 minecraft:mud
fill 194 153 411 194 156 411 minecraft:moss_block
setblock 199 153 411 minecraft:lime_terracotta
fill 207 153 369 208 156 369 minecraft:moss_block
setblock 210 153 411 minecraft:lime_terracotta
setblock 212 153 369 minecraft:lime_terracotta
fill 214 153 411 215 156 411 minecraft:moss_block
setblock 223 153 369 minecraft:lime_terracotta
fill 228 153 369 228 156 369 minecraft:moss_block
fill 230 153 378 230 156 378 minecraft:moss_block
setblock 230 153 379 minecraft:lime_terracotta
fill 230 153 382 230 153 383 minecraft:lime_terracotta
fill 230 153 399 230 156 399 minecraft:moss_block
setblock 230 153 403 minecraft:lime_terracotta
fill 230 153 410 230 156 410 minecraft:moss_block
fill 188 154 370 188 159 370 minecraft:moss_block
fill 188 154 371 188 154 372 minecraft:lime_terracotta
fill 188 154 373 188 156 374 minecraft:moss_block
fill 188 154 379 188 155 380 minecraft:lime_terracotta
fill 188 154 381 188 159 382 minecraft:moss_block
setblock 188 154 383 minecraft:lime_terracotta
fill 188 154 384 188 157 384 minecraft:moss_block
fill 188 154 391 188 154 392 minecraft:lime_terracotta
fill 188 154 393 188 159 394 minecraft:moss_block
fill 188 154 400 188 155 400 minecraft:lime_terracotta
fill 188 154 401 188 159 402 minecraft:moss_block
setblock 188 154 403 minecraft:lime_terracotta
fill 188 154 405 188 159 405 minecraft:moss_block
fill 188 154 411 189 155 411 minecraft:lime_terracotta
fill 189 154 369 190 154 369 minecraft:lime_terracotta
fill 190 154 411 191 159 411 minecraft:moss_block
fill 191 154 369 191 159 369 minecraft:moss_block
fill 191 154 387 191 158 387 minecraft:mud
fill 191 154 389 191 158 389 minecraft:mud
fill 192 154 386 194 158 386 minecraft:mud
fill 192 154 390 192 158 390 minecraft:mud
fill 193 154 369 193 155 369 minecraft:lime_terracotta
fill 194 154 390 194 158 390 minecraft:mud
fill 195 154 387 195 158 389 minecraft:mud
fill 199 154 369 200 159 369 minecraft:moss_block
fill 199 154 411 199 159 411 minecraft:moss_block
fill 200 154 411 201 154 411 minecraft:lime_terracotta
fill 201 154 369 202 155 369 minecraft:lime_terracotta
fill 202 154 411 203 159 411 minecraft:moss_block
fill 208 154 411 209 155 411 minecraft:lime_terracotta
setblock 210 154 369 minecraft:lime_terracotta
fill 210 154 407 210 155 407 minecraft:moss_block
fill 210 154 411 211 159 411 minecraft:moss_block
fill 211 154 369 212 159 369 minecraft:moss_block
setblock 212 154 411 minecraft:lime_terracotta
fill 213 154 369 214 155 369 minecraft:lime_terracotta
fill 219 154 369 220 159 369 minecraft:moss_block
fill 220 154 411 221 155 411 minecraft:lime_terracotta
fill 221 154 369 222 154 369 minecraft:lime_terracotta
fill 222 154 411 223 159 411 minecraft:moss_block
fill 223 154 369 223 159 369 minecraft:moss_block
fill 229 154 411 229 155 411 minecraft:lime_terracotta
fill 230 154 370 230 159 371 minecraft:moss_block
fill 230 154 372 230 155 373 minecraft:lime_terracotta
fill 230 154 379 230 159 379 minecraft:moss_block
setblock 230 154 381 minecraft:lime_terracotta
fill 230 154 382 230 159 383 minecraft:moss_block
fill 230 154 384 230 155 384 minecraft:lime_terracotta
fill 230 154 390 230 159 391 minecraft:moss_block
fill 230 154 392 230 154 393 minecraft:lime_terracotta
fill 230 154 402 230 159 403 minecraft:moss_block
fill 230 154 404 230 155 405 minecraft:lime_terracotta
setblock 188 155 371 minecraft:lime_terracotta
fill 188 155 372 188 158 372 minecraft:moss_block
fill 188 155 383 188 157 383 minecraft:moss_block
setblock 188 155 388 minecraft:lime_terracotta
setblock 188 155 391 minecraft:lime_terracotta
fill 188 155 392 188 158 392 minecraft:moss_block
setblock 188 155 399 minecraft:lime_terracotta
fill 188 155 403 188 158 403 minecraft:moss_block
fill 189 155 369 190 157 369 minecraft:moss_block
fill 190 155 388 190 158 388 minecraft:mud
fill 191 155 386 191 158 386 minecraft:mud
fill 191 155 390 191 158 390 minecraft:mud
fill 193 155 391 193 158 391 minecraft:mud
setblock 194 155 369 minecraft:lime_terracotta
fill 195 155 390 195 158 390 minecraft:mud
fill 196 155 411 197 155 411 minecraft:lime_terracotta
setblock 200 155 411 minecraft:lime_terracotta
fill 201 155 411 201 158 411 minecraft:moss_block
setblock 205 155 369 minecraft:lime_terracotta
fill 210 155 369 210 158 369 minecraft:moss_block
fill 212 155 411 212 158 411 minecraft:moss_block
setblock 217 155 411 minecraft:lime_terracotta
fill 221 155 369 221 158 369 minecraft:moss_block
setblock 222 155 369 minecraft:lime_terracotta
fill 225 155 369 226 155 369 minecraft:lime_terracotta
setblock 228 155 411 minecraft:lime_terracotta
fill 230 155 381 230 158 381 minecraft:moss_block
setblock 230 155 385 minecraft:lime_terracotta
fill 230 155 392 230 158 392 minecraft:moss_block
setblock 230 155 393 minecraft:lime_terracotta
setblock 230 155 396 minecraft:lime_terracotta
setblock 188 156 369 minecraft:lime_terracotta
fill 188 156 371 188 158 371 minecraft:moss_block
fill 188 156 377 188 157 378 minecraft:lime_terracotta
fill 188 156 379 188 161 380 minecraft:moss_block
setblock 188 156 385 minecraft:moss_block
fill 188 156 386 188 157 386 minecraft:lime_terracotta
fill 188 156 388 188 161 388 minecraft:moss_block
fill 188 156 389 188 156 390 minecraft:lime_terracotta
fill 188 156 391 188 161 391 minecraft:moss_block
fill 188 156 397 188 157 398 minecraft:lime_terracotta
fill 188 156 399 188 161 400 minecraft:moss_block
fill 188 156 409 188 156 410 minecraft:lime_terracotta
fill 188 156 411 189 161 411 minecraft:moss_block
fill 189 156 370 191 156 370 minecraft:mud
fill 189 156 372 189 156 374 minecraft:mud
fill 189 156 376 189 156 378 minecraft:mud
fill 189 156 380 189 156 382 minecraft:mud
fill 189 156 384 189 156 386 minecraft:mud
fill 189 156 388 189 156 390 minecraft:mud
fill 189 156 392 189 156 394 minecraft:mud
fill 189 156 396 189 156 398 minecraft:mud
fill 189 156 400 189 156 402 minecraft:mud
fill 189 156 404 189 156 406 minecraft:mud
fill 189 156 408 189 156 410 minecraft:mud
fill 190 156 387 190 158 387 minecraft:mud
fill 190 156 389 190 158 390 minecraft:mud
fill 191 156 391 192 158 391 minecraft:mud
fill 191 156 410 193 156 410 minecraft:mud
setblock 192 156 369 minecraft:lime_terracotta
fill 192 156 385 194 158 385 minecraft:mud
fill 193 156 369 194 161 369 minecraft:moss_block
fill 193 156 370 195 156 370 minecraft:mud
fill 194 156 391 194 158 391 minecraft:mud
fill 195 156 369 196 157 369 minecraft:lime_terracotta
fill 195 156 386 195 158 386 minecraft:mud
fill 195 156 410 197 156 410 minecraft:mud
fill 195 156 411 195 157 411 minecraft:lime_terracotta
fill 196 156 387 196 158 389 minecraft:mud
fill 196 156 411 197 161 411 minecraft:moss_block
fill 197 156 370 199 156 370 minecraft:mud
setblock 198 156 411 minecraft:lime_terracotta
fill 199 156 410 201 156 410 minecraft:mud
fill 200 156 411 200 161 411 minecraft:moss_block
fill 201 156 369 202 161 369 minecraft:moss_block
fill 201 156 370 203 156 370 minecraft:mud
fill 203 156 369 204 156 369 minecraft:lime_terracotta
fill 203 156 410 205 156 410 minecraft:mud
fill 205 156 369 205 161 369 minecraft:moss_block
fill 205 156 370 207 156 370 minecraft:mud
fill 206 156 411 207 157 411 minecraft:lime_terracotta
fill 207 156 410 209 156 410 minecraft:mud
fill 208 156 411 209 161 411 minecraft:moss_block
fill 209 156 370 211 156 370 minecraft:mud
fill 211 156 410 213 156 410 minecraft:mud
fill 213 156 369 214 161 369 minecraft:moss_block
fill 213 156 370 215 156 370 minecraft:mud
fill 215 156 369 216 157 369 minecraft:lime_terracotta
fill 215 156 410 217 156 410 minecraft:mud
fill 217 156 370 219 156 370 minecraft:mud
fill 217 156 411 217 161 411 minecraft:moss_block
fill 218 156 411 219 156 411 minecraft:lime_terracotta
fill 219 156 410 221 156 410 minecraft:mud
fill 220 156 411 221 161 411 minecraft:moss_block
fill 221 156 370 223 156 370 minecraft:mud
fill 222 156 369 222 161 369 minecraft:moss_block
fill 223 156 410 225 156 410 minecraft:mud
setblock 224 156 369 minecraft:lime_terracotta
fill 225 156 369 226 161 369 minecraft:moss_block
fill 225 156 370 227 156 370 minecraft:mud
fill 226 156 411 227 157 411 minecraft:lime_terracotta
fill 227 156 369 227 157 369 minecraft:lime_terracotta
fill 227 156 410 229 156 410 minecraft:mud
fill 228 156 411 229 161 411 minecraft:moss_block
fill 229 156 370 229 156 372 minecraft:mud
fill 229 156 374 229 156 376 minecraft:mud
fill 229 156 378 229 156 380 minecraft:mud
fill 229 156 382 229 156 384 minecraft:mud
fill 229 156 386 229 156 388 minecraft:mud
fill 229 156 390 229 156 392 minecraft:mud
fill 229 156 394 229 156 396 minecraft:mud
fill 229 156 398 229 156 400 minecraft:mud
fill 229 156 402 229 156 404 minecraft:mud
fill 229 156 406 229 156 408 minecraft:mud
fill 230 156 372 230 161 373 minecraft:moss_block
fill 230 156 374 230 156 375 minecraft:lime_terracotta
fill 230 156 384 230 161 385 minecraft:moss_block
fill 230 156 386 230 157 387 minecraft:lime_terracotta
fill 230 156 393 230 161 393 minecraft:moss_block
fill 230 156 394 230 156 395 minecraft:lime_terracotta
fill 230 156 396 230 161 396 minecraft:moss_block
fill 230 156 398 230 157 398 minecraft:lime_terracotta
fill 230 156 404 230 161 405 minecraft:moss_block
fill 230 156 406 230 157 407 minecraft:lime_terracotta
setblock 230 156 411 minecraft:lime_terracotta
fill 188 157 369 188 160 369 minecraft:moss_block
fill 188 157 373 188 159 373 minecraft:moss_block
setblock 188 157 374 minecraft:lime_terracotta
setblock 188 157 385 minecraft:lime_terracotta
fill 188 157 389 188 160 390 minecraft:moss_block
setblock 188 157 406 minecraft:lime_terracotta
setblock 188 157 409 minecraft:lime_terracotta
fill 188 157 410 188 160 410 minecraft:moss_block
fill 189 157 388 189 158 388 minecraft:mud
fill 190 157 386 190 158 386 minecraft:mud
fill 191 157 385 191 158 385 minecraft:mud
fill 192 157 369 192 159 369 minecraft:moss_block
fill 193 157 392 193 158 392 minecraft:mud
setblock 194 157 411 minecraft:lime_terracotta
fill 195 157 385 195 158 385 minecraft:mud
fill 195 157 391 195 158 391 minecraft:mud
fill 196 157 386 196 158 386 minecraft:mud
fill 196 157 390 196 158 390 minecraft:mud
fill 198 157 411 198 160 411 minecraft:moss_block
fill 203 157 369 203 160 369 minecraft:moss_block
setblock 204 157 369 minecraft:lime_terracotta
fill 207 157 369 208 157 369 minecraft:lime_terracotta
fill 214 157 411 215 157 411 minecraft:lime_terracotta
setblock 218 157 411 minecraft:lime_terracotta
fill 219 157 411 219 160 411 minecraft:moss_block
fill 224 157 369 224 160 369 minecraft:moss_block
setblock 228 157 369 minecraft:lime_terracotta
fill 230 157 374 230 160 374 minecraft:moss_block
setblock 230 157 375 minecraft:lime_terracotta
setblock 230 157 378 minecraft:lime_terracotta
fill 230 157 394 230 160 395 minecraft:moss_block
setblock 230 157 399 minecraft:lime_terracotta
setblock 230 157 410 minecraft:lime_terracotta
fill 230 157 411 230 160 411 minecraft:moss_block
fill 188 158 374 188 159 374 minecraft:moss_block
fill 188 158 375 188 158 376 minecraft:lime_terracotta
fill 188 158 377 188 163 378 minecraft:moss_block
fill 188 158 383 188 159 384 minecraft:lime_terracotta
fill 188 158 385 188 163 386 minecraft:moss_block
setblock 188 158 387 minecraft:lime_terracotta
fill 188 158 395 188 159 396 minecraft:lime_terracotta
fill 188 158 397 188 163 398 minecraft:moss_block
fill 188 158 404 188 159 404 minecraft:lime_terracotta
fill 188 158 406 188 163 406 minecraft:moss_block
fill 188 158 407 188 158 408 minecraft:lime_terracotta
fill 188 158 409 188 163 409 minecraft:moss_block
fill 189 158 369 189 159 369 minecraft:lime_terracotta
setblock 189 158 387 minecraft:mud
fill 189 158 389 189 158 390 minecraft:mud
setblock 190 158 369 minecraft:moss_block
setblock 190 158 385 minecraft:mud
setblock 190 158 391 minecraft:mud
fill 191 158 392 192 158 392 minecraft:mud
fill 192 158 384 194 158 384 minecraft:mud
fill 192 158 411 193 159 411 minecraft:lime_terracotta
fill 194 158 392 195 158 392 minecraft:mud
fill 194 158 411 195 163 411 minecraft:moss_block
fill 195 158 369 196 163 369 minecraft:moss_block
setblock 196 158 391 minecraft:mud
fill 197 158 369 198 159 369 minecraft:lime_terracotta
fill 197 158 387 197 158 389 minecraft:mud
fill 204 158 369 204 163 369 minecraft:moss_block
fill 204 158 411 205 158 411 minecraft:lime_terracotta
setblock 206 158 369 minecraft:lime_terracotta
fill 206 158 411 207 163 411 minecraft:moss_block
fill 207 158 369 208 163 369 minecraft:moss_block
fill 209 158 369 209 159 369 minecraft:lime_terracotta
fill 211 158 372 212 159 372 minecraft:moss_block
fill 213 158 411 213 159 411 minecraft:lime_terracotta
fill 214 158 411 215 163 411 minecraft:moss_block
fill 215 158 369 216 163 369 minecraft:moss_block
setblock 216 158 411 minecraft:lime_terracotta
fill 217 158 369 218 158 369 minecraft:lime_terracotta
fill 218 158 411 218 163 411 minecraft:moss_block
fill 224 158 411 225 159 411 minecraft:lime_terracotta
fill 226 158 411 227 163 411 minecraft:moss_block
fill 227 158 369 228 163 369 minecraft:moss_block
fill 229 158 369 230 159 369 minecraft:lime_terracotta
fill 230 158 375 230 163 375 minecraft:moss_block
fill 230 158 376 230 158 377 minecraft:lime_terracotta
fill 230 158 378 230 163 378 minecraft:moss_block
fill 230 158 380 230 159 380 minecraft:lime_terracotta
fill 230 158 386 230 163 387 minecraft:moss_block
fill 230 158 388 230 159 389 minecraft:lime_terracotta
setblock 230 158 397 minecraft:lime_terracotta
fill 230 158 398 230 163 399 minecraft:moss_block
fill 230 158 400 230 159 401 minecraft:lime_terracotta
fill 230 158 406 230 163 407 minecraft:moss_block
fill 230 158 408 230 158 409 minecraft:lime_terracotta
fill 230 158 410 230 163 410 minecraft:moss_block
fill 188 159 371 188 159 372 minecraft:lime_terracotta
setblock 188 159 375 minecraft:lime_terracotta
fill 188 159 376 188 162 376 minecraft:moss_block
fill 188 159 387 188 162 387 minecraft:moss_block
setblock 188 159 392 minecraft:lime_terracotta
setblock 188 159 403 minecraft:lime_terracotta
fill 188 159 407 188 162 408 minecraft:moss_block
setblock 190 159 369 minecraft:lime_terracotta
setblock 191 159 372 minecraft:light[level=14]
setblock 191 159 380 minecraft:light[level=14]
setblock 191 159 388 minecraft:light[level=14]
fill 191 159 391 191 160 391 minecraft:iron_block
setblock 191 159 396 minecraft:light[level=14]
setblock 191 159 404 minecraft:light[level=14]
setblock 199 159 372 minecraft:light[level=14]
setblock 199 159 380 minecraft:light[level=14]
setblock 199 159 388 minecraft:light[level=14]
setblock 199 159 396 minecraft:light[level=14]
setblock 199 159 404 minecraft:light[level=14]
setblock 201 159 411 minecraft:lime_terracotta
setblock 204 159 411 minecraft:lime_terracotta
fill 205 159 411 205 162 411 minecraft:moss_block
fill 206 159 369 206 162 369 minecraft:moss_block
setblock 207 159 372 minecraft:light[level=14]
setblock 207 159 380 minecraft:light[level=14]
setblock 207 159 388 minecraft:light[level=14]
setblock 207 159 396 minecraft:light[level=14]
setblock 207 159 404 minecraft:light[level=14]
setblock 210 159 369 minecraft:lime_terracotta
setblock 212 159 411 minecraft:lime_terracotta
setblock 215 159 372 minecraft:light[level=14]
setblock 215 159 380 minecraft:light[level=14]
setblock 215 159 388 minecraft:light[level=14]
setblock 215 159 396 minecraft:light[level=14]
setblock 215 159 404 minecraft:light[level=14]
fill 216 159 411 216 162 411 minecraft:moss_block
fill 217 159 369 217 162 369 minecraft:moss_block
fill 217 159 391 217 160 391 minecraft:stripped_dark_oak_log
setblock 218 159 369 minecraft:lime_terracotta
setblock 221 159 369 minecraft:lime_terracotta
setblock 223 159 372 minecraft:light[level=14]
setblock 223 159 380 minecraft:light[level=14]
setblock 223 159 388 minecraft:light[level=14]
setblock 223 159 396 minecraft:light[level=14]
setblock 223 159 404 minecraft:light[level=14]
fill 230 159 376 230 162 377 minecraft:moss_block
setblock 230 159 381 minecraft:lime_terracotta
setblock 230 159 392 minecraft:lime_terracotta
fill 230 159 397 230 162 397 minecraft:moss_block
fill 230 159 408 230 162 408 minecraft:moss_block
setblock 230 159 409 minecraft:lime_terracotta
fill 188 160 370 188 161 370 minecraft:lime_terracotta
fill 188 160 371 188 161 372 minecraft:moss_block
fill 188 160 373 188 160 374 minecraft:lime_terracotta
fill 188 160 375 188 165 375 minecraft:moss_block
fill 188 160 381 188 161 382 minecraft:lime_terracotta
fill 188 160 383 188 165 384 minecraft:moss_block
fill 188 160 392 188 165 392 minecraft:moss_block
fill 188 160 393 188 160 394 minecraft:lime_terracotta
fill 188 160 395 188 165 396 minecraft:moss_block
fill 188 160 401 188 161 402 minecraft:lime_terracotta
fill 188 160 403 188 165 404 minecraft:moss_block
setblock 188 160 405 minecraft:lime_terracotta
fill 189 160 369 190 165 369 minecraft:moss_block
fill 190 160 411 191 161 411 minecraft:lime_terracotta
fill 191 160 369 192 161 369 minecraft:lime_terracotta
fill 192 160 411 193 165 411 minecraft:moss_block
fill 197 160 369 198 165 369 minecraft:moss_block
fill 199 160 369 200 160 369 minecraft:lime_terracotta
fill 199 160 411 199 161 411 minecraft:lime_terracotta
fill 201 160 411 201 165 411 minecraft:moss_block
fill 202 160 411 203 160 411 minecraft:lime_terracotta
fill 204 160 411 204 165 411 minecraft:moss_block
fill 209 160 369 210 165 369 minecraft:moss_block
fill 210 160 411 211 161 411 minecraft:lime_terracotta
fill 211 160 369 212 161 369 minecraft:lime_terracotta
fill 212 160 411 213 165 411 minecraft:moss_block
fill 218 160 369 218 165 369 minecraft:moss_block
fill 219 160 369 220 160 369 minecraft:lime_terracotta
fill 221 160 369 221 165 369 minecraft:moss_block
fill 222 160 411 223 160 411 minecraft:lime_terracotta
fill 223 160 369 223 161 369 minecraft:lime_terracotta
fill 224 160 411 225 165 411 minecraft:moss_block
fill 229 160 369 230 165 369 minecraft:moss_block
fill 230 160 370 230 161 371 minecraft:lime_terracotta
setblock 230 160 379 minecraft:lime_terracotta
fill 230 160 380 230 165 381 minecraft:moss_block
fill 230 160 382 230 161 383 minecraft:lime_terracotta
fill 230 160 388 230 165 389 minecraft:moss_block
fill 230 160 390 230 160 391 minecraft:lime_terracotta
fill 230 160 392 230 165 392 minecraft:moss_block
fill 230 160 400 230 165 401 minecraft:moss_block
fill 230 160 402 230 161 403 minecraft:lime_terracotta
fill 230 160 409 230 165 409 minecraft:moss_block
setblock 188 161 369 minecraft:lime_terracotta
fill 188 161 373 188 163 374 minecraft:moss_block
fill 188 161 389 188 161 390 minecraft:lime_terracotta
setblock 188 161 393 minecraft:lime_terracotta
fill 188 161 394 188 164 394 minecraft:moss_block
fill 188 161 405 188 164 405 minecraft:moss_block
setblock 188 161 410 minecraft:lime_terracotta
fill 198 161 376 201 203 378 minecraft:mud
setblock 198 161 411 minecraft:lime_terracotta
fill 199 161 369 199 164 369 minecraft:moss_block
fill 199 161 375 200 203 375 minecraft:mud
setblock 200 161 369 minecraft:lime_terracotta
fill 202 161 411 203 164 411 minecraft:moss_block
setblock 203 161 369 minecraft:lime_terracotta
fill 219 161 369 220 164 369 minecraft:moss_block
setblock 219 161 411 minecraft:lime_terracotta
setblock 222 161 411 minecraft:lime_terracotta
fill 223 161 411 223 164 411 minecraft:moss_block
setblock 224 161 369 minecraft:lime_terracotta
setblock 230 161 374 minecraft:lime_terracotta
fill 230 161 379 230 164 379 minecraft:moss_block
fill 230 161 390 230 164 390 minecraft:moss_block
setblock 230 161 391 minecraft:lime_terracotta
fill 230 161 394 230 161 395 minecraft:lime_terracotta
setblock 230 161 411 minecraft:lime_terracotta
fill 188 162 369 188 167 370 minecraft:moss_block
setblock 188 162 371 minecraft:lime_terracotta
fill 188 162 372 188 165 372 minecraft:moss_block
fill 188 162 379 188 162 380 minecraft:lime_terracotta
fill 188 162 381 188 167 382 minecraft:moss_block
fill 188 162 388 188 163 388 minecraft:lime_terracotta
fill 188 162 389 188 167 390 minecraft:moss_block
setblock 188 162 391 minecraft:lime_terracotta
fill 188 162 393 188 167 393 minecraft:moss_block
fill 188 162 399 188 163 400 minecraft:lime_terracotta
fill 188 162 401 188 167 402 minecraft:moss_block
fill 188 162 410 188 167 410 minecraft:moss_block
fill 188 162 411 189 162 411 minecraft:lime_terracotta
fill 189 162 370 191 162 370 minecraft:mud
fill 189 162 372 189 162 374 minecraft:mud
fill 189 162 376 189 162 378 minecraft:mud
fill 189 162 380 189 162 382 minecraft:mud
fill 189 162 384 189 162 386 minecraft:mud
fill 189 162 388 189 162 390 minecraft:mud
fill 189 162 392 189 162 394 minecraft:mud
fill 189 162 396 189 162 398 minecraft:mud
fill 189 162 400 189 162 402 minecraft:mud
fill 189 162 404 189 162 406 minecraft:mud
fill 189 162 408 189 162 410 minecraft:mud
fill 190 162 411 191 167 411 minecraft:moss_block
fill 191 162 369 192 167 369 minecraft:moss_block
fill 191 162 388 192 164 388 minecraft:mangrove_leaves[persistent=true]
fill 191 162 410 193 162 410 minecraft:mud
fill 192 162 387 194 164 387 minecraft:mangrove_leaves[persistent=true]
fill 192 162 389 194 164 389 minecraft:mangrove_leaves[persistent=true]
fill 193 162 369 194 163 369 minecraft:lime_terracotta
fill 193 162 370 195 162 370 minecraft:mud
fill 193 162 390 193 164 390 minecraft:mangrove_leaves[persistent=true]
fill 194 162 388 194 164 388 minecraft:mangrove_leaves[persistent=true]
fill 195 162 410 197 162 410 minecraft:mud
fill 196 162 379 200 199 381 minecraft:mud
fill 196 162 411 197 163 411 minecraft:lime_terracotta
fill 197 162 370 199 162 370 minecraft:mud
fill 197 162 376 197 164 378 minecraft:mud
fill 197 162 382 199 203 382 minecraft:mud
fill 198 162 375 198 163 375 minecraft:mud
fill 198 162 411 199 167 411 minecraft:moss_block
fill 199 162 374 199 163 374 minecraft:mud
fill 199 162 410 201 162 410 minecraft:mud
fill 200 162 369 200 167 369 minecraft:moss_block
setblock 200 162 411 minecraft:lime_terracotta
fill 201 162 369 202 162 369 minecraft:lime_terracotta
fill 201 162 370 203 162 370 minecraft:mud
fill 201 162 375 201 163 375 minecraft:mud
fill 201 162 379 201 164 379 minecraft:mud
fill 202 162 376 202 163 377 minecraft:mud
fill 203 162 369 203 167 369 minecraft:moss_block
fill 203 162 410 205 162 410 minecraft:mud
fill 205 162 369 205 163 369 minecraft:lime_terracotta
fill 205 162 370 207 162 370 minecraft:mud
fill 207 162 410 209 162 410 minecraft:mud
fill 208 162 411 209 163 411 minecraft:lime_terracotta
fill 209 162 370 211 162 370 minecraft:mud
fill 210 162 411 211 167 411 minecraft:moss_block
fill 211 162 369 212 167 369 minecraft:moss_block
fill 211 162 410 213 162 410 minecraft:mud
fill 213 162 369 214 163 369 minecraft:lime_terracotta
fill 213 162 370 215 162 370 minecraft:mud
fill 215 162 410 217 162 410 minecraft:mud
fill 217 162 370 219 162 370 minecraft:mud
fill 217 162 411 217 163 411 minecraft:lime_terracotta
fill 219 162 410 221 162 410 minecraft:mud
fill 219 162 411 219 167 411 minecraft:moss_block
fill 220 162 411 221 162 411 minecraft:lime_terracotta
fill 221 162 370 223 162 370 minecraft:mud
setblock 222 162 369 minecraft:lime_terracotta
fill 222 162 411 222 167 411 minecraft:moss_block
fill 223 162 369 224 167 369 minecraft:moss_block
fill 223 162 410 225 162 410 minecraft:mud
fill 225 162 369 226 163 369 minecraft:lime_terracotta
fill 225 162 370 227 162 370 minecraft:mud
fill 227 162 410 229 162 410 minecraft:mud
fill 228 162 411 229 163 411 minecraft:lime_terracotta
fill 229 162 370 229 162 372 minecraft:mud
fill 229 162 374 229 162 376 minecraft:mud
fill 229 162 378 229 162 380 minecraft:mud
fill 229 162 382 229 162 384 minecraft:mud
fill 229 162 386 229 162 388 minecraft:mud
fill 229 162 390 229 162 392 minecraft:mud
fill 229 162 394 229 162 396 minecraft:mud
fill 229 162 398 229 162 400 minecraft:mud
fill 229 162 402 229 162 404 minecraft:mud
fill 229 162 406 229 162 408 minecraft:mud
fill 230 162 370 230 167 371 minecraft:moss_block
fill 230 162 372 230 162 373 minecraft:lime_terracotta
fill 230 162 374 230 167 374 minecraft:moss_block
fill 230 162 382 230 167 383 minecraft:moss_block
fill 230 162 384 230 163 385 minecraft:lime_terracotta
fill 230 162 391 230 167 391 minecraft:moss_block
setblock 230 162 393 minecraft:lime_terracotta
fill 230 162 394 230 167 395 minecraft:moss_block
fill 230 162 396 230 163 396 minecraft:lime_terracotta
fill 230 162 402 230 167 403 minecraft:moss_block
fill 230 162 404 230 162 405 minecraft:lime_terracotta
fill 230 162 411 230 167 411 minecraft:moss_block
fill 188 163 371 188 165 371 minecraft:moss_block
setblock 188 163 376 minecraft:lime_terracotta
setblock 188 163 379 minecraft:lime_terracotta
fill 188 163 380 188 166 380 minecraft:moss_block
setblock 188 163 387 minecraft:lime_terracotta
fill 188 163 391 188 166 391 minecraft:moss_block
fill 188 163 407 188 163 408 minecraft:lime_terracotta
setblock 188 163 411 minecraft:lime_terracotta
fill 189 163 411 189 166 411 minecraft:moss_block
setblock 191 163 387 minecraft:mangrove_leaves[persistent=true]
setblock 191 163 389 minecraft:mangrove_leaves[persistent=true]
fill 192 163 386 193 163 386 minecraft:mangrove_leaves[persistent=true]
setblock 192 163 390 minecraft:mangrove_leaves[persistent=true]
fill 193 163 388 193 164 388 minecraft:mangrove_leaves[persistent=true]
setblock 194 163 390 minecraft:mangrove_leaves[persistent=true]
fill 195 163 379 195 164 381 minecraft:mud
fill 195 163 388 195 163 389 minecraft:mangrove_leaves[persistent=true]
fill 196 163 376 196 163 378 minecraft:mud
fill 196 163 382 196 164 383 minecraft:mud
fill 197 163 374 197 163 375 minecraft:mud
fill 197 163 383 199 164 383 minecraft:mud
setblock 198 163 374 minecraft:mud
fill 200 163 374 201 163 374 minecraft:mud
fill 200 163 382 200 164 382 minecraft:mud
fill 200 163 411 200 166 411 minecraft:moss_block
fill 201 163 369 202 165 369 minecraft:moss_block
fill 201 163 380 201 164 381 minecraft:mud
setblock 202 163 375 minecraft:mud
fill 202 163 378 202 163 379 minecraft:mud
setblock 203 163 377 minecraft:mud
setblock 205 163 411 minecraft:lime_terracotta
setblock 206 163 369 minecraft:lime_terracotta
fill 208 163 405 208 164 406 minecraft:lime_concrete
fill 214 163 404 215 164 405 minecraft:moss_block
setblock 216 163 411 minecraft:lime_terracotta
setblock 217 163 369 minecraft:lime_terracotta
fill 220 163 411 221 166 411 minecraft:moss_block
fill 222 163 369 222 166 369 minecraft:moss_block
fill 230 163 372 230 166 372 minecraft:moss_block
setblock 230 163 373 minecraft:lime_terracotta
fill 230 163 376 230 163 377 minecraft:lime_terracotta
fill 230 163 393 230 166 393 minecraft:moss_block
setblock 230 163 397 minecraft:lime_terracotta
fill 230 163 404 230 166 404 minecraft:moss_block
setblock 230 163 405 minecraft:lime_terracotta
setblock 230 163 408 minecraft:lime_terracotta
setblock 188 164 373 minecraft:moss_block
fill 188 164 374 188 165 374 minecraft:lime_terracotta
fill 188 164 376 188 169 376 minecraft:moss_block
fill 188 164 377 188 164 378 minecraft:lime_terracotta
fill 188 164 379 188 169 379 minecraft:moss_block
fill 188 164 385 188 165 386 minecraft:lime_terracotta
fill 188 164 387 188 169 388 minecraft:moss_block
fill 188 164 397 188 164 398 minecraft:lime_terracotta
fill 188 164 399 188 169 400 minecraft:moss_block
fill 188 164 406 188 165 406 minecraft:lime_terracotta
fill 188 164 407 188 169 408 minecraft:moss_block
setblock 188 164 409 minecraft:lime_terracotta
fill 188 164 411 188 169 411 minecraft:moss_block
fill 193 164 369 194 169 369 minecraft:moss_block
fill 194 164 379 194 164 382 minecraft:mud
fill 194 164 411 195 165 411 minecraft:lime_terracotta
fill 195 164 369 196 165 369 minecraft:lime_terracotta
fill 195 164 377 196 164 378 minecraft:mud
fill 195 164 382 195 164 383 minecraft:mud
fill 196 164 384 200 164 384 minecraft:mud
fill 196 164 411 197 169 411 minecraft:moss_block
fill 200 164 383 201 164 383 minecraft:mud
fill 201 164 382 202 164 382 minecraft:mud
fill 202 164 379 202 164 381 minecraft:mud
setblock 204 164 369 minecraft:lime_terracotta
fill 205 164 369 206 169 369 minecraft:moss_block
fill 205 164 411 205 169 411 minecraft:moss_block
fill 206 164 411 207 164 411 minecraft:lime_terracotta
fill 207 164 369 208 165 369 minecraft:lime_terracotta
fill 208 164 411 209 169 411 minecraft:moss_block
fill 213 164 369 214 169 369 minecraft:moss_block
fill 214 164 411 215 165 411 minecraft:lime_terracotta
fill 215 164 369 216 164 369 minecraft:lime_terracotta
fill 216 164 411 217 169 411 minecraft:moss_block
fill 217 164 369 217 169 369 minecraft:moss_block
setblock 218 164 411 minecraft:lime_terracotta
fill 225 164 369 226 169 369 minecraft:moss_block
fill 226 164 411 227 165 411 minecraft:lime_terracotta
fill 227 164 369 228 165 369 minecraft:lime_terracotta
fill 228 164 411 229 169 411 minecraft:moss_block
fill 230 164 373 230 169 373 minecraft:moss_block
setblock 230 164 375 minecraft:lime_terracotta
fill 230 164 376 230 169 377 minecraft:moss_block
fill 230 164 378 230 165 378 minecraft:lime_terracotta
fill 230 164 384 230 169 385 minecraft:moss_block
fill 230 164 386 230 164 387 minecraft:lime_terracotta
fill 230 164 396 230 169 397 minecraft:moss_block
fill 230 164 398 230 165 399 minecraft:lime_terracotta
fill 230 164 405 230 169 405 minecraft:moss_block
fill 230 164 406 230 164 407 minecraft:lime_terracotta
fill 230 164 408 230 169 408 minecraft:moss_block
fill 230 164 410 230 165 410 minecraft:lime_terracotta
setblock 188 165 373 minecraft:lime_terracotta
fill 188 165 377 188 168 378 minecraft:moss_block
setblock 188 165 394 minecraft:lime_terracotta
setblock 188 165 397 minecraft:lime_terracotta
fill 188 165 398 188 168 398 minecraft:moss_block
setblock 188 165 405 minecraft:lime_terracotta
fill 188 165 409 188 168 409 minecraft:moss_block
fill 197 165 378 197 199 378 minecraft:mud
setblock 199 165 369 minecraft:lime_terracotta
fill 202 165 411 203 165 411 minecraft:lime_terracotta
fill 204 165 369 204 167 369 minecraft:moss_block
setblock 206 165 411 minecraft:lime_terracotta
fill 207 165 411 207 168 411 minecraft:moss_block
fill 215 165 369 215 168 369 minecraft:moss_block
setblock 216 165 369 minecraft:lime_terracotta
fill 218 165 411 218 168 411 minecraft:moss_block
fill 219 165 369 220 165 369 minecraft:lime_terracotta
setblock 223 165 411 minecraft:lime_terracotta
fill 230 165 375 230 168 375 minecraft:moss_block
setblock 230 165 379 minecraft:lime_terracotta
fill 230 165 386 230 168 386 minecraft:moss_block
setblock 230 165 387 minecraft:lime_terracotta
setblock 230 165 390 minecraft:lime_terracotta
fill 230 165 406 230 168 407 minecraft:moss_block
fill 188 166 371 188 167 372 minecraft:lime_terracotta
fill 188 166 373 188 171 374 minecraft:moss_block
setblock 188 166 375 minecraft:lime_terracotta
fill 188 166 383 188 167 384 minecraft:lime_terracotta
fill 188 166 385 188 171 386 minecraft:moss_block
fill 188 166 392 188 167 392 minecraft:lime_terracotta
fill 188 166 394 188 171 394 minecraft:moss_block
fill 188 166 395 188 166 396 minecraft:lime_terracotta
fill 188 166 397 188 171 397 minecraft:moss_block
fill 188 166 403 188 167 404 minecraft:lime_terracotta
fill 188 166 405 188 171 406 minecraft:moss_block
fill 189 166 369 190 167 369 minecraft:lime_terracotta
fill 192 166 411 193 166 411 minecraft:lime_terracotta
fill 194 166 411 195 171 411 minecraft:moss_block
fill 195 166 369 196 168 369 minecraft:moss_block
fill 197 166 369 198 166 369 minecraft:lime_terracotta
fill 199 166 369 199 171 369 minecraft:moss_block
fill 201 166 369 201 167 369 minecraft:lime_terracotta
fill 201 166 411 201 167 411 minecraft:lime_terracotta
setblock 202 166 369 minecraft:moss_block
fill 202 166 411 203 171 411 minecraft:moss_block
setblock 204 166 411 minecraft:lime_terracotta
fill 206 166 411 206 171 411 minecraft:moss_block
fill 207 166 369 208 171 369 minecraft:moss_block
fill 209 166 369 210 167 369 minecraft:lime_terracotta
fill 212 166 411 213 167 411 minecraft:lime_terracotta
fill 214 166 411 215 171 411 minecraft:moss_block
fill 216 166 369 216 171 369 minecraft:moss_block
setblock 218 166 369 minecraft:lime_terracotta
fill 219 166 369 220 171 369 minecraft:moss_block
fill 221 166 369 221 167 369 minecraft:lime_terracotta
fill 223 166 411 223 171 411 minecraft:moss_block
fill 224 166 411 225 166 411 minecraft:lime_terracotta
fill 226 166 411 227 171 411 minecraft:moss_block
fill 227 166 369 228 171 369 minecraft:moss_block
fill 229 166 369 230 166 369 minecraft:lime_terracotta
fill 230 166 378 230 171 379 minecraft:moss_block
fill 230 166 380 230 167 381 minecraft:lime_terracotta
fill 230 166 387 230 171 387 minecraft:moss_block
fill 230 166 388 230 166 389 minecraft:lime_terracotta
fill 230 166 390 230 171 390 minecraft:moss_block
fill 230 166 392 230 167 392 minecraft:lime_terracotta
fill 230 166 398 230 171 399 minecraft:moss_block
fill 230 166 400 230 167 401 minecraft:lime_terracotta
setblock 230 166 409 minecraft:lime_terracotta
fill 230 166 410 230 171 410 minecraft:moss_block
fill 188 167 375 188 170 375 minecraft:moss_block
setblock 188 167 380 minecraft:lime_terracotta
setblock 188 167 391 minecraft:lime_terracotta
fill 188 167 395 188 170 396 minecraft:moss_block
setblock 189 167 411 minecraft:lime_terracotta
setblock 191 167 372 minecraft:light[level=14]
setblock 191 167 380 minecraft:light[level=14]
setblock 191 167 388 minecraft:light[level=14]
setblock 191 167 396 minecraft:light[level=14]
setblock 191 167 404 minecraft:light[level=14]
setblock 192 167 411 minecraft:lime_terracotta
fill 193 167 411 193 170 411 minecraft:moss_block
fill 197 167 369 197 170 369 minecraft:moss_block
setblock 198 167 369 minecraft:lime_terracotta
setblock 199 167 372 minecraft:light[level=14]
setblock 199 167 388 minecraft:light[level=14]
setblock 199 167 396 minecraft:light[level=14]
setblock 199 167 404 minecraft:light[level=14]
setblock 200 167 411 minecraft:lime_terracotta
setblock 202 167 369 minecraft:lime_terracotta
fill 204 167 411 204 170 411 minecraft:moss_block
setblock 207 167 372 minecraft:light[level=14]
setblock 207 167 380 minecraft:light[level=14]
setblock 207 167 388 minecraft:light[level=14]
setblock 207 167 396 minecraft:light[level=14]
setblock 207 167 404 minecraft:light[level=14]
setblock 215 167 372 minecraft:light[level=14]
setblock 215 167 380 minecraft:light[level=14]
setblock 215 167 388 minecraft:light[level=14]
setblock 215 167 396 minecraft:light[level=14]
setblock 215 167 404 minecraft:light[level=14]
fill 218 167 369 218 170 369 minecraft:moss_block
fill 220 167 411 221 167 411 minecraft:lime_terracotta
setblock 222 167 369 minecraft:lime_terracotta
setblock 223 167 372 minecraft:light[level=14]
setblock 223 167 380 minecraft:light[level=14]
setblock 223 167 388 minecraft:light[level=14]
setblock 223 167 396 minecraft:light[level=14]
setblock 223 167 404 minecraft:light[level=14]
setblock 224 167 411 minecraft:lime_terracotta
fill 225 167 411 225 170 411 minecraft:moss_block
fill 229 167 369 229 170 369 minecraft:moss_block
setblock 230 167 369 minecraft:lime_terracotta
setblock 230 167 372 minecraft:lime_terracotta
fill 230 167 388 230 170 389 minecraft:moss_block
setblock 230 167 393 minecraft:lime_terracotta
setblock 230 167 404 minecraft:lime_terracotta
fill 230 167 409 230 170 409 minecraft:moss_block
fill 188 168 369 188 169 370 minecraft:lime_terracotta
fill 188 168 371 188 173 372 minecraft:moss_block
fill 188 168 380 188 173 380 minecraft:moss_block
fill 188 168 381 188 168 382 minecraft:lime_terracotta
fill 188 168 383 188 173 384 minecraft:moss_block
fill 188 168 389 188 169 390 minecraft:lime_terracotta
fill 188 168 391 188 173 392 minecraft:moss_block
setblock 188 168 393 minecraft:lime_terracotta
fill 188 168 401 188 169 402 minecraft:lime_terracotta
fill 188 168 403 188 173 404 minecraft:moss_block
fill 188 168 410 188 169 410 minecraft:lime_terracotta
fill 189 168 369 190 173 369 minecraft:moss_block
fill 189 168 370 191 168 370 minecraft:mud
fill 189 168 372 189 168 374 minecraft:mud
fill 189 168 376 189 168 378 minecraft:mud
fill 189 168 380 189 168 382 minecraft:mud
fill 189 168 384 189 168 386 minecraft:mud
fill 189 168 388 189 168 390 minecraft:mud
fill 189 168 392 189 168 394 minecraft:mud
fill 189 168 396 189 168 398 minecraft:mud
fill 189 168 400 189 168 402 minecraft:mud
fill 189 168 404 189 168 406 minecraft:mud
fill 189 168 408 189 168 410 minecraft:mud
fill 189 168 411 189 173 411 minecraft:moss_block
fill 190 168 411 191 168 411 minecraft:lime_terracotta
fill 191 168 369 192 169 369 minecraft:lime_terracotta
fill 191 168 410 193 168 410 minecraft:mud
fill 192 168 411 192 173 411 minecraft:moss_block
fill 193 168 370 195 168 370 minecraft:mud
fill 195 168 410 197 168 410 minecraft:mud
fill 197 168 370 199 168 370 minecraft:mud
fill 198 168 369 198 170 369 minecraft:moss_block
fill 198 168 411 199 169 411 minecraft:lime_terracotta
fill 199 168 410 201 168 410 minecraft:mud
setblock 200 168 369 minecraft:lime_terracotta
fill 200 168 411 201 173 411 minecraft:moss_block
fill 201 168 369 202 173 369 minecraft:moss_block
fill 201 168 370 203 168 370 minecraft:mud
fill 203 168 369 204 169 369 minecraft:lime_terracotta
fill 203 168 410 205 168 410 minecraft:mud
fill 205 168 370 207 168 370 minecraft:mud
fill 207 168 410 209 168 410 minecraft:mud
fill 209 168 369 210 173 369 minecraft:moss_block
fill 209 168 370 211 168 370 minecraft:mud
fill 210 168 411 211 168 411 minecraft:lime_terracotta
fill 211 168 369 212 168 369 minecraft:lime_terracotta
fill 211 168 410 213 168 410 minecraft:mud
fill 212 168 411 213 173 411 minecraft:moss_block
fill 213 168 370 215 168 370 minecraft:mud
fill 215 168 410 217 168 410 minecraft:mud
fill 217 168 370 219 168 370 minecraft:mud
fill 219 168 410 221 168 410 minecraft:mud
fill 219 168 411 219 169 411 minecraft:lime_terracotta
fill 220 168 411 221 173 411 minecraft:moss_block
fill 221 168 369 222 173 369 minecraft:moss_block
fill 221 168 370 223 168 370 minecraft:mud
setblock 222 168 411 minecraft:lime_terracotta
fill 223 168 369 224 169 369 minecraft:lime_terracotta
fill 223 168 410 225 168 410 minecraft:mud
fill 224 168 411 224 173 411 minecraft:moss_block
fill 225 168 370 227 168 370 minecraft:mud
fill 227 168 410 229 168 410 minecraft:mud
fill 229 168 370 229 168 372 minecraft:mud
fill 229 168 374 229 168 376 minecraft:mud
fill 229 168 378 229 168 380 minecraft:mud
fill 229 168 382 229 168 384 minecraft:mud
fill 229 168 386 229 168 388 minecraft:mud
fill 229 168 390 229 168 392 minecraft:mud
fill 229 168 394 229 168 396 minecraft:mud
fill 229 168 398 229 168 400 minecraft:mud
fill 229 168 402 229 168 404 minecraft:mud
fill 229 168 406 229 168 408 minecraft:mud
fill 230 168 369 230 173 369 minecraft:moss_block
fill 230 168 370 230 168 371 minecraft:lime_terracotta
fill 230 168 372 230 173 372 minecraft:moss_block
fill 230 168 374 230 169 374 minecraft:lime_terracotta
fill 230 168 380 230 173 381 minecraft:moss_block
fill 230 168 382 230 169 383 minecraft:lime_terracotta
setblock 230 168 391 minecraft:lime_terracotta
fill 230 168 392 230 173 393 minecraft:moss_block
fill 230 168 394 230 169 395 minecraft:lime_terracotta
fill 230 168 400 230 173 401 minecraft:moss_block
fill 230 168 402 230 168 403 minecraft:lime_terracotta
fill 230 168 404 230 173 404 minecraft:moss_block
fill 230 168 411 230 169 411 minecraft:lime_terracotta
fill 188 169 377 188 169 378 minecraft:lime_terracotta
setblock 188 169 381 minecraft:lime_terracotta
fill 188 169 382 188 172 382 minecraft:moss_block
fill 188 169 393 188 172 393 minecraft:moss_block
setblock 188 169 398 minecraft:lime_terracotta
setblock 188 169 409 minecraft:lime_terracotta
fill 190 169 411 191 172 411 minecraft:moss_block
setblock 195 169 369 minecraft:lime_terracotta
fill 196 169 369 196 171 369 minecraft:moss_block
fill 200 169 369 200 172 369 minecraft:moss_block
setblock 207 169 411 minecraft:lime_terracotta
setblock 210 169 411 minecraft:lime_terracotta
fill 211 169 369 211 172 369 minecraft:moss_block
fill 211 169 411 211 172 411 minecraft:moss_block
setblock 212 169 369 minecraft:lime_terracotta
setblock 215 169 369 minecraft:lime_terracotta
setblock 218 169 411 minecraft:lime_terracotta
fill 222 169 411 222 172 411 minecraft:moss_block
fill 230 169 370 230 172 371 minecraft:moss_block
setblock 230 169 375 minecraft:lime_terracotta
setblock 230 169 386 minecraft:lime_terracotta
fill 230 169 391 230 172 391 minecraft:moss_block
fill 230 169 402 230 172 402 minecraft:moss_block
setblock 230 169 403 minecraft:lime_terracotta
fill 230 169 406 230 169 407 minecraft:lime_terracotta
fill 188 170 369 188 175 370 minecraft:moss_block
fill 188 170 376 188 171 376 minecraft:lime_terracotta
fill 188 170 377 188 175 378 minecraft:moss_block
setblock 188 170 379 minecraft:lime_terracotta
fill 188 170 381 188 175 381 minecraft:moss_block
fill 188 170 387 188 171 388 minecraft:lime_terracotta
fill 188 170 389 188 175 390 minecraft:moss_block
fill 188 170 398 188 175 398 minecraft:moss_block
fill 188 170 399 188 170 400 minecraft:lime_terracotta
fill 188 170 401 188 175 402 minecraft:moss_block
fill 188 170 407 188 171 408 minecraft:lime_terracotta
fill 188 170 409 188 175 410 minecraft:moss_block
setblock 188 170 411 minecraft:lime_terracotta
fill 191 170 369 192 175 369 minecraft:moss_block
fill 193 170 369 194 170 369 minecraft:lime_terracotta
fill 195 170 369 195 171 369 minecraft:moss_block
fill 196 170 411 197 171 411 minecraft:lime_terracotta
fill 198 170 411 199 175 411 minecraft:moss_block
fill 203 170 369 204 175 369 minecraft:moss_block
fill 205 170 369 206 171 369 minecraft:lime_terracotta
fill 205 170 411 205 171 411 minecraft:lime_terracotta
fill 207 170 401 208 171 403 minecraft:spruce_log
fill 207 170 411 207 175 411 minecraft:moss_block
fill 208 170 411 209 170 411 minecraft:lime_terracotta
fill 209 170 402 210 171 403 minecraft:spruce_log
fill 210 170 411 210 175 411 minecraft:moss_block
fill 211 170 402 211 172 402 minecraft:spruce_log
fill 212 170 369 212 175 369 minecraft:moss_block
fill 213 170 369 214 170 369 minecraft:lime_terracotta
fill 215 170 369 215 175 369 minecraft:moss_block
fill 216 170 411 217 171 411 minecraft:lime_terracotta
fill 217 170 369 217 171 369 minecraft:lime_terracotta
fill 218 170 411 219 175 411 minecraft:moss_block
fill 223 170 369 224 175 369 minecraft:moss_block
fill 225 170 369 226 171 369 minecraft:lime_terracotta
fill 228 170 411 229 170 411 minecraft:lime_terracotta
setblock 230 170 373 minecraft:lime_terracotta
fill 230 170 374 230 175 375 minecraft:moss_block
fill 230 170 376 230 171 377 minecraft:lime_terracotta
fill 230 170 382 230 175 383 minecraft:moss_block
fill 230 170 384 230 170 385 minecraft:lime_terracotta
fill 230 170 386 230 175 386 minecraft:moss_block
fill 230 170 394 230 175 395 minecraft:moss_block
fill 230 170 396 230 171 397 minecraft:lime_terracotta
fill 230 170 403 230 175 403 minecraft:moss_block
setblock 230 170 405 minecraft:lime_terracotta
fill 230 170 406 230 175 407 minecraft:moss_block
fill 230 170 408 230 171 408 minecraft:lime_terracotta
fill 230 170 411 230 175 411 minecraft:moss_block
setblock 188 171 375 minecraft:lime_terracotta
fill 188 171 379 188 174 379 minecraft:moss_block
fill 188 171 395 188 171 396 minecraft:lime_terracotta
setblock 188 171 399 minecraft:lime_terracotta
fill 188 171 400 188 174 400 minecraft:moss_block
fill 188 171 411 188 174 411 minecraft:moss_block
fill 193 171 369 193 174 369 minecraft:moss_block
setblock 193 171 411 minecraft:lime_terracotta
setblock 194 171 369 minecraft:lime_terracotta
fill 197 171 369 198 171 369 minecraft:lime_terracotta
setblock 204 171 411 minecraft:lime_terracotta
fill 208 171 411 209 174 411 minecraft:moss_block
fill 209 171 401 210 171 401 minecraft:spruce_log
fill 211 171 403 216 172 403 minecraft:spruce_log
fill 212 171 402 214 172 402 minecraft:spruce_log
fill 213 171 369 214 173 369 minecraft:moss_block
setblock 218 171 369 minecraft:lime_terracotta
setblock 225 171 411 minecraft:lime_terracotta
setblock 228 171 411 minecraft:lime_terracotta
setblock 229 171 369 minecraft:lime_terracotta
fill 229 171 411 229 174 411 minecraft:moss_block
fill 230 171 373 230 174 373 minecraft:moss_block
fill 230 171 384 230 174 384 minecraft:moss_block
setblock 230 171 385 minecraft:lime_terracotta
fill 230 171 388 230 171 389 minecraft:lime_terracotta
fill 230 171 405 230 174 405 minecraft:moss_block
setblock 230 171 409 minecraft:lime_terracotta
fill 188 172 373 188 173 374 minecraft:lime_terracotta
fill 188 172 375 188 177 376 minecraft:moss_block
fill 188 172 385 188 172 386 minecraft:lime_terracotta
fill 188 172 387 188 177 388 minecraft:moss_block
fill 188 172 394 188 173 394 minecraft:lime_terracotta
fill 188 172 395 188 177 396 minecraft:moss_block
setblock 188 172 397 minecraft:lime_terracotta
fill 188 172 399 188 177 399 minecraft:moss_block
fill 188 172 405 188 173 406 minecraft:lime_terracotta
fill 188 172 407 188 177 408 minecraft:moss_block
fill 193 172 411 193 177 411 minecraft:moss_block
fill 194 172 369 194 177 369 minecraft:moss_block
fill 194 172 411 195 172 411 minecraft:lime_terracotta
fill 195 172 369 196 172 369 minecraft:lime_terracotta
fill 196 172 411 197 177 411 minecraft:moss_block
fill 197 172 369 198 173 369 minecraft:moss_block
fill 199 172 369 199 173 369 minecraft:lime_terracotta
fill 202 172 411 203 173 411 minecraft:lime_terracotta
fill 204 172 411 205 177 411 minecraft:moss_block
fill 205 172 369 206 177 369 minecraft:moss_block
setblock 206 172 411 minecraft:lime_terracotta
fill 207 172 369 208 173 369 minecraft:lime_terracotta
fill 209 172 402 210 172 402 minecraft:spruce_log
setblock 210 172 403 minecraft:spruce_log
fill 213 172 404 218 172 404 minecraft:spruce_log
fill 214 172 411 215 173 411 minecraft:lime_terracotta
fill 215 172 402 216 172 402 minecraft:spruce_log
setblock 216 172 369 minecraft:lime_terracotta
fill 216 172 411 217 177 411 minecraft:moss_block
fill 217 172 369 218 177 369 minecraft:moss_block
fill 217 172 403 218 173 403 minecraft:spruce_log
fill 219 172 369 220 173 369 minecraft:lime_terracotta
fill 223 172 411 223 173 411 minecraft:lime_terracotta
fill 225 172 369 226 177 369 minecraft:moss_block
fill 225 172 411 225 177 411 minecraft:moss_block
fill 226 172 411 227 172 411 minecraft:lime_terracotta
fill 227 172 369 228 172 369 minecraft:lime_terracotta
fill 228 172 411 228 177 411 minecraft:moss_block
fill 229 172 369 229 177 369 minecraft:moss_block
fill 230 172 376 230 177 377 minecraft:moss_block
fill 230 172 378 230 173 379 minecraft:lime_terracotta
fill 230 172 385 230 177 385 minecraft:moss_block
setblock 230 172 387 minecraft:lime_terracotta
fill 230 172 388 230 177 389 minecraft:moss_block
fill 230 172 390 230 173 390 minecraft:lime_terracotta
fill 230 172 396 230 177 397 minecraft:moss_block
fill 230 172 398 230 172 399 minecraft:lime_terracotta
fill 230 172 408 230 177 409 minecraft:moss_block
fill 230 172 410 230 173 410 minecraft:lime_terracotta
setblock 188 173 382 minecraft:lime_terracotta
setblock 188 173 385 minecraft:lime_terracotta
fill 188 173 386 188 176 386 minecraft:moss_block
setblock 188 173 393 minecraft:lime_terracotta
fill 188 173 397 188 176 397 minecraft:moss_block
fill 190 173 411 191 173 411 minecraft:lime_terracotta
fill 194 173 399 197 173 401 minecraft:lime_concrete
setblock 194 173 411 minecraft:lime_terracotta
fill 195 173 369 196 175 369 minecraft:moss_block
setblock 195 173 398 minecraft:lime_concrete
fill 195 173 402 196 173 402 minecraft:lime_concrete
fill 195 173 411 195 176 411 minecraft:moss_block
setblock 200 173 369 minecraft:lime_terracotta
fill 206 173 411 206 176 411 minecraft:moss_block
setblock 211 173 369 minecraft:lime_terracotta
setblock 211 173 411 minecraft:lime_terracotta
fill 214 173 403 216 173 403 minecraft:spruce_log
fill 216 173 369 216 175 369 minecraft:moss_block
fill 216 173 404 218 173 404 minecraft:spruce_log
setblock 222 173 411 minecraft:lime_terracotta
fill 226 173 411 227 176 411 minecraft:moss_block
fill 227 173 369 227 176 369 minecraft:moss_block
setblock 228 173 369 minecraft:lime_terracotta
fill 230 173 370 230 173 371 minecraft:lime_terracotta
fill 230 173 387 230 176 387 minecraft:moss_block
setblock 230 173 391 minecraft:lime_terracotta
fill 230 173 398 230 176 398 minecraft:moss_block
setblock 230 173 399 minecraft:lime_terracotta
setblock 230 173 402 minecraft:lime_terracotta
fill 188 174 371 188 175 372 minecraft:lime_terracotta
fill 188 174 373 188 179 374 minecraft:moss_block
fill 188 174 380 188 175 380 minecraft:lime_terracotta
fill 188 174 382 188 179 382 minecraft:moss_block
fill 188 174 383 188 174 384 minecraft:lime_terracotta
fill 188 174 385 188 179 385 minecraft:moss_block
fill 188 174 391 188 175 392 minecraft:lime_terracotta
fill 188 174 393 188 179 394 minecraft:moss_block
fill 188 174 403 188 174 404 minecraft:lime_terracotta
fill 188 174 405 188 179 406 minecraft:moss_block
fill 189 174 369 190 175 369 minecraft:lime_terracotta
fill 189 174 370 191 174 370 minecraft:mud
fill 189 174 372 189 174 374 minecraft:mud
fill 189 174 376 189 174 378 minecraft:mud
fill 189 174 380 189 174 382 minecraft:mud
fill 189 174 384 189 174 386 minecraft:mud
fill 189 174 388 189 174 390 minecraft:mud
fill 189 174 392 189 174 394 minecraft:mud
fill 189 174 396 189 174 398 minecraft:mud
fill 189 174 400 189 174 402 minecraft:mud
fill 189 174 404 189 174 406 minecraft:mud
fill 189 174 408 189 174 410 minecraft:mud
fill 189 174 411 189 175 411 minecraft:lime_terracotta
fill 190 174 411 191 179 411 minecraft:moss_block
fill 191 174 410 193 174 410 minecraft:mud
setblock 192 174 411 minecraft:lime_terracotta
fill 193 174 370 195 174 370 minecraft:mud
fill 194 174 411 194 179 411 minecraft:moss_block
fill 195 174 410 197 174 410 minecraft:mud
fill 197 174 369 197 177 369 minecraft:moss_block
fill 197 174 370 199 174 370 minecraft:mud
setblock 198 174 369 minecraft:lime_terracotta
fill 199 174 369 200 179 369 minecraft:moss_block
fill 199 174 410 201 174 410 minecraft:mud
fill 200 174 411 201 175 411 minecraft:lime_terracotta
fill 201 174 369 202 175 369 minecraft:lime_terracotta
fill 201 174 370 203 174 370 minecraft:mud
fill 202 174 411 203 179 411 minecraft:moss_block
fill 203 174 410 205 174 410 minecraft:mud
fill 205 174 370 207 174 370 minecraft:mud
fill 207 174 369 208 176 369 minecraft:moss_block
fill 207 174 410 209 174 410 minecraft:mud
fill 209 174 369 210 174 369 minecraft:lime_terracotta
fill 209 174 370 211 174 370 minecraft:mud
fill 211 174 369 211 179 369 minecraft:moss_block
fill 211 174 410 213 174 410 minecraft:mud
fill 211 174 411 211 179 411 minecraft:moss_block
fill 212 174 411 213 174 411 minecraft:lime_terracotta
fill 213 174 369 213 175 369 minecraft:lime_terracotta
fill 213 174 370 215 174 370 minecraft:mud
setblock 214 174 369 minecraft:moss_block
fill 214 174 411 215 179 411 minecraft:moss_block
fill 215 174 410 217 174 410 minecraft:mud
fill 217 174 370 219 174 370 minecraft:mud
fill 219 174 369 220 179 369 minecraft:moss_block
fill 219 174 410 221 174 410 minecraft:mud
fill 220 174 411 221 175 411 minecraft:lime_terracotta
fill 221 174 369 222 175 369 minecraft:lime_terracotta
fill 221 174 370 223 174 370 minecraft:mud
fill 222 174 411 223 179 411 minecraft:moss_block
fill 223 174 410 225 174 410 minecraft:mud
setblock 224 174 411 minecraft:lime_terracotta
fill 225 174 370 227 174 370 minecraft:mud
fill 227 174 410 229 174 410 minecraft:mud
fill 228 174 369 228 179 369 minecraft:moss_block
fill 229 174 370 229 174 372 minecraft:mud
fill 229 174 374 229 174 376 minecraft:mud
fill 229 174 378 229 174 380 minecraft:mud
fill 229 174 382 229 174 384 minecraft:mud
fill 229 174 386 229 174 388 minecraft:mud
fill 229 174 390 229 174 392 minecraft:mud
fill 229 174 394 229 174 396 minecraft:mud
fill 229 174 398 229 174 400 minecraft:mud
fill 229 174 402 229 174 404 minecraft:mud
fill 229 174 406 229 174 408 minecraft:mud
setblock 230 174 369 minecraft:lime_terracotta
fill 230 174 370 230 179 371 minecraft:moss_block
fill 230 174 372 230 175 372 minecraft:lime_terracotta
fill 230 174 378 230 179 379 minecraft:moss_block
fill 230 174 380 230 174 381 minecraft:lime_terracotta
fill 230 174 390 230 179 391 minecraft:moss_block
fill 230 174 392 230 175 393 minecraft:lime_terracotta
fill 230 174 399 230 179 399 minecraft:moss_block
fill 230 174 400 230 174 401 minecraft:lime_terracotta
fill 230 174 402 230 179 402 minecraft:moss_block
fill 230 174 404 230 175 404 minecraft:lime_terracotta
fill 230 174 410 230 179 410 minecraft:moss_block
setblock 188 175 379 minecraft:lime_terracotta
fill 188 175 383 188 178 384 minecraft:moss_block
setblock 188 175 400 minecraft:lime_terracotta
setblock 188 175 403 minecraft:lime_terracotta
fill 188 175 404 188 178 404 minecraft:moss_block
setblock 188 175 411 minecraft:lime_terracotta
setblock 191 175 372 minecraft:light[level=14]
setblock 191 175 380 minecraft:light[level=14]
setblock 191 175 388 minecraft:light[level=14]
setblock 191 175 396 minecraft:light[level=14]
setblock 191 175 404 minecraft:light[level=14]
fill 192 175 411 192 178 411 minecraft:moss_block
setblock 193 175 369 minecraft:lime_terracotta
fill 198 175 369 198 177 369 minecraft:moss_block
setblock 199 175 372 minecraft:light[level=14]
setblock 199 175 388 minecraft:light[level=14]
setblock 199 175 396 minecraft:light[level=14]
setblock 199 175 404 minecraft:light[level=14]
setblock 207 175 372 minecraft:light[level=14]
setblock 207 175 380 minecraft:light[level=14]
setblock 207 175 388 minecraft:light[level=14]
setblock 207 175 396 minecraft:light[level=14]
setblock 207 175 404 minecraft:light[level=14]
fill 208 175 411 209 175 411 minecraft:lime_terracotta
fill 209 175 369 209 178 369 minecraft:moss_block
setblock 210 175 369 minecraft:lime_terracotta
setblock 212 175 411 minecraft:lime_terracotta
fill 213 175 411 213 178 411 minecraft:moss_block
setblock 214 175 369 minecraft:lime_terracotta
setblock 215 175 372 minecraft:light[level=14]
setblock 215 175 380 minecraft:light[level=14]
setblock 215 175 388 minecraft:light[level=14]
setblock 215 175 396 minecraft:light[level=14]
setblock 215 175 404 minecraft:light[level=14]
setblock 223 175 372 minecraft:light[level=14]
setblock 223 175 380 minecraft:light[level=14]
setblock 223 175 388 minecraft:light[level=14]
setblock 223 175 396 minecraft:light[level=14]
setblock 223 175 404 minecraft:light[level=14]
fill 224 175 411 224 178 411 minecraft:moss_block
setblock 229 175 411 minecraft:lime_terracotta
fill 230 175 369 230 178 369 minecraft:moss_block
setblock 230 175 373 minecraft:lime_terracotta
fill 230 175 380 230 178 380 minecraft:moss_block
setblock 230 175 381 minecraft:lime_terracotta
setblock 230 175 384 minecraft:lime_terracotta
fill 230 175 400 230 178 401 minecraft:moss_block
setblock 230 175 405 minecraft:lime_terracotta
fill 188 176 369 188 176 370 minecraft:lime_terracotta
fill 188 176 371 188 181 372 minecraft:moss_block
fill 188 176 377 188 177 378 minecraft:lime_terracotta
fill 188 176 379 188 181 380 minecraft:moss_block
setblock 188 176 381 minecraft:lime_terracotta
fill 188 176 389 188 177 390 minecraft:lime_terracotta
fill 188 176 391 188 181 392 minecraft:moss_block
fill 188 176 398 188 177 398 minecraft:lime_terracotta
fill 188 176 400 188 181 400 minecraft:moss_block
fill 188 176 401 188 176 402 minecraft:lime_terracotta
fill 188 176 403 188 181 403 minecraft:moss_block
fill 188 176 409 188 177 410 minecraft:lime_terracotta
fill 188 176 411 189 181 411 minecraft:moss_block
fill 189 176 369 190 178 369 minecraft:moss_block
fill 191 176 369 192 176 369 minecraft:lime_terracotta
fill 193 176 369 193 181 369 minecraft:moss_block
fill 195 176 369 195 177 369 minecraft:lime_terracotta
setblock 196 176 369 minecraft:moss_block
fill 198 176 411 199 176 411 minecraft:lime_terracotta
fill 200 176 411 201 181 411 minecraft:moss_block
fill 201 176 369 202 181 369 minecraft:moss_block
fill 203 176 369 204 177 369 minecraft:lime_terracotta
fill 207 176 411 207 177 411 minecraft:lime_terracotta
fill 208 176 411 209 181 411 minecraft:moss_block
fill 210 176 369 210 178 369 minecraft:moss_block
setblock 210 176 411 minecraft:lime_terracotta
setblock 212 176 369 minecraft:lime_terracotta
fill 212 176 411 212 181 411 minecraft:moss_block
fill 213 176 369 214 181 369 minecraft:moss_block
fill 215 176 369 216 177 369 minecraft:lime_terracotta
fill 218 176 411 219 177 411 minecraft:lime_terracotta
fill 220 176 411 221 181 411 minecraft:moss_block
fill 221 176 369 222 181 369 minecraft:moss_block
fill 223 176 369 224 176 369 minecraft:lime_terracotta
fill 229 176 411 229 181 411 minecraft:moss_block
fill 230 176 372 230 181 373 minecraft:moss_block
fill 230 176 374 230 177 375 minecraft:lime_terracotta
fill 230 176 381 230 181 381 minecraft:moss_block
fill 230 176 382 230 176 383 minecraft:lime_terracotta
fill 230 176 384 230 181 384 minecraft:moss_block
fill 230 176 386 230 177 386 minecraft:lime_terracotta
fill 230 176 392 230 181 393 minecraft:moss_block
fill 230 176 394 230 177 395 minecraft:lime_terracotta
setblock 230 176 403 minecraft:lime_terracotta
fill 230 176 404 230 181 405 minecraft:moss_block
fill 230 176 406 230 177 407 minecraft:lime_terracotta
fill 230 176 411 230 177 411 minecraft:lime_terracotta
setblock 188 177 369 minecraft:lime_terracotta
fill 188 177 370 188 180 370 minecraft:moss_block
fill 188 177 381 188 180 381 minecraft:moss_block
setblock 188 177 386 minecraft:lime_terracotta
setblock 188 177 397 minecraft:lime_terracotta
fill 188 177 401 188 180 402 minecraft:moss_block
fill 191 177 369 191 180 369 minecraft:moss_block
setblock 192 177 369 minecraft:lime_terracotta
setblock 195 177 411 minecraft:lime_terracotta
setblock 196 177 369 minecraft:lime_terracotta
setblock 198 177 411 minecraft:lime_terracotta
fill 199 177 411 199 180 411 minecraft:moss_block
setblock 206 177 411 minecraft:lime_terracotta
setblock 207 177 369 minecraft:lime_terracotta
fill 208 177 369 208 179 369 minecraft:moss_block
fill 210 177 411 210 180 411 minecraft:moss_block
fill 212 177 369 212 180 369 minecraft:moss_block
fill 223 177 369 223 180 369 minecraft:moss_block
setblock 224 177 369 minecraft:lime_terracotta
fill 226 177 411 227 177 411 minecraft:lime_terracotta
setblock 227 177 369 minecraft:lime_terracotta
fill 230 177 382 230 180 383 minecraft:moss_block
setblock 230 177 387 minecraft:lime_terracotta
setblock 230 177 398 minecraft:lime_terracotta
fill 230 177 403 230 180 403 minecraft:moss_block
fill 188 178 369 188 183 369 minecraft:moss_block
fill 188 178 375 188 179 376 minecraft:lime_terracotta
fill 188 178 377 188 183 378 minecraft:moss_block
fill 188 178 386 188 183 386 minecraft:moss_block
fill 188 178 387 188 178 388 minecraft:lime_terracotta
fill 188 178 389 188 183 390 minecraft:moss_block
fill 188 178 395 188 179 396 minecraft:lime_terracotta
fill 188 178 397 188 183 398 minecraft:moss_block
setblock 188 178 399 minecraft:lime_terracotta
fill 188 178 407 188 179 408 minecraft:lime_terracotta
fill 188 178 409 188 183 410 minecraft:moss_block
fill 192 178 369 192 180 369 minecraft:moss_block
fill 193 178 411 193 179 411 minecraft:lime_terracotta
setblock 194 178 369 minecraft:lime_terracotta
fill 195 178 369 196 183 369 minecraft:moss_block
fill 195 178 411 195 183 411 minecraft:moss_block
fill 196 178 411 197 178 411 minecraft:lime_terracotta
fill 197 178 369 198 179 369 minecraft:lime_terracotta
fill 198 178 411 198 183 411 minecraft:moss_block
fill 203 178 369 204 183 369 minecraft:moss_block
fill 204 178 411 205 179 411 minecraft:lime_terracotta
fill 205 178 369 206 178 369 minecraft:lime_terracotta
fill 206 178 411 207 183 411 minecraft:moss_block
fill 207 178 369 207 179 369 minecraft:moss_block
fill 215 178 369 216 183 369 minecraft:moss_block
fill 216 178 411 217 178 411 minecraft:lime_terracotta
fill 217 178 369 218 179 369 minecraft:lime_terracotta
fill 218 178 411 219 183 411 minecraft:moss_block
fill 224 178 369 224 183 369 minecraft:moss_block
fill 225 178 369 226 178 369 minecraft:lime_terracotta
fill 225 178 411 225 179 411 minecraft:lime_terracotta
fill 226 178 411 227 183 411 minecraft:moss_block
fill 227 178 369 227 183 369 minecraft:moss_block
setblock 228 178 411 minecraft:lime_terracotta
fill 229 178 369 229 179 369 minecraft:lime_terracotta
fill 230 178 374 230 183 375 minecraft:moss_block
fill 230 178 376 230 179 377 minecraft:lime_terracotta
setblock 230 178 385 minecraft:lime_terracotta
fill 230 178 386 230 183 387 minecraft:moss_block
fill 230 178 388 230 179 389 minecraft:lime_terracotta
fill 230 178 394 230 183 395 minecraft:moss_block
fill 230 178 396 230 178 397 minecraft:lime_terracotta
fill 230 178 398 230 183 398 minecraft:moss_block
fill 230 178 406 230 183 407 minecraft:moss_block
fill 230 178 408 230 179 409 minecraft:lime_terracotta
fill 230 178 411 230 183 411 minecraft:moss_block
fill 188 179 383 188 179 384 minecraft:lime_terracotta
setblock 188 179 387 minecraft:lime_terracotta
fill 188 179 388 188 182 388 minecraft:moss_block
fill 188 179 399 188 182 399 minecraft:moss_block
setblock 188 179 404 minecraft:lime_terracotta
setblock 189 179 369 minecraft:lime_terracotta
fill 190 179 369 190 181 369 minecraft:moss_block
setblock 192 179 411 minecraft:lime_terracotta
fill 194 179 369 194 182 369 minecraft:moss_block
fill 196 179 411 197 182 411 minecraft:moss_block
fill 205 179 369 205 182 369 minecraft:moss_block
setblock 206 179 369 minecraft:lime_terracotta
fill 209 179 369 210 179 369 minecraft:lime_terracotta
setblock 213 179 411 minecraft:lime_terracotta
setblock 216 179 411 minecraft:lime_terracotta
fill 217 179 411 217 182 411 minecraft:moss_block
setblock 224 179 411 minecraft:lime_terracotta
fill 225 179 369 226 181 369 minecraft:moss_block
fill 228 179 411 228 182 411 minecraft:moss_block
setblock 230 179 369 minecraft:lime_terracotta
setblock 230 179 380 minecraft:lime_terracotta
fill 230 179 385 230 182 385 minecraft:moss_block
schedule function dropper:buildpart/88_4 1t
