setblock 88 133 275 minecraft:blue_terracotta
fill 89 133 276 89 134 276 minecraft:blue_terracotta
fill 89 133 278 89 136 278 minecraft:blue_terracotta
setblock 89 133 279 minecraft:blue_concrete
fill 89 133 290 89 134 290 minecraft:blue_concrete
setblock 89 133 297 minecraft:blue_concrete
fill 89 133 302 89 133 303 minecraft:blue_concrete
fill 89 133 304 89 136 304 minecraft:blue_terracotta
fill 89 133 314 89 134 314 minecraft:blue_terracotta
setblock 89 133 315 minecraft:blue_concrete
setblock 47 134 281 minecraft:blue_concrete
fill 47 134 287 47 136 288 minecraft:blue_terracotta
setblock 47 134 289 minecraft:blue_concrete
fill 47 134 290 47 136 291 minecraft:blue_terracotta
fill 47 134 295 47 136 295 minecraft:blue_terracotta
setblock 47 134 299 minecraft:blue_concrete
fill 47 134 300 47 136 300 minecraft:blue_terracotta
fill 47 134 305 47 136 306 minecraft:blue_terracotta
fill 47 134 314 47 136 314 minecraft:blue_terracotta
setblock 48 134 282 minecraft:spruce_planks
setblock 48 134 289 minecraft:spruce_planks
setblock 48 134 296 minecraft:spruce_planks
setblock 48 134 303 minecraft:spruce_planks
setblock 48 134 310 minecraft:spruce_planks
setblock 49 134 276 minecraft:spruce_planks
setblock 49 134 316 minecraft:spruce_planks
fill 53 134 295 53 136 295 minecraft:dark_oak_planks
fill 53 134 298 53 136 298 minecraft:dark_oak_planks
setblock 54 134 317 minecraft:blue_terracotta
fill 55 134 294 56 136 294 minecraft:dark_oak_planks
fill 55 134 300 56 136 300 minecraft:dark_oak_planks
setblock 55 134 317 minecraft:blue_concrete
setblock 56 134 276 minecraft:spruce_planks
setblock 56 134 316 minecraft:spruce_planks
fill 58 134 295 58 136 295 minecraft:dark_oak_planks
fill 58 134 298 58 136 298 minecraft:dark_oak_planks
fill 60 134 275 61 136 275 minecraft:blue_terracotta
setblock 63 134 276 minecraft:spruce_planks
setblock 63 134 316 minecraft:spruce_planks
fill 64 134 317 64 135 317 minecraft:blue_concrete
setblock 65 134 275 minecraft:blue_concrete
fill 68 134 317 68 136 317 minecraft:blue_terracotta
setblock 70 134 276 minecraft:spruce_planks
setblock 70 134 316 minecraft:spruce_planks
fill 73 134 317 73 136 317 minecraft:blue_terracotta
setblock 74 134 317 minecraft:blue_concrete
setblock 77 134 276 minecraft:spruce_planks
setblock 77 134 316 minecraft:spruce_planks
fill 78 134 275 78 136 275 minecraft:blue_terracotta
fill 80 134 317 80 136 317 minecraft:blue_terracotta
fill 81 134 317 82 134 317 minecraft:white_wool
fill 83 134 317 83 136 317 minecraft:blue_terracotta
setblock 84 134 276 minecraft:spruce_planks
setblock 84 134 316 minecraft:spruce_planks
fill 86 134 317 87 134 317 minecraft:blue_concrete
fill 87 134 275 87 136 275 minecraft:blue_terracotta
setblock 88 134 275 minecraft:blue_concrete
setblock 88 134 279 minecraft:spruce_planks
setblock 88 134 286 minecraft:spruce_planks
setblock 88 134 293 minecraft:spruce_planks
setblock 88 134 300 minecraft:spruce_planks
setblock 88 134 307 minecraft:spruce_planks
setblock 88 134 314 minecraft:spruce_planks
setblock 89 134 277 minecraft:blue_concrete
fill 89 134 279 89 136 279 minecraft:blue_terracotta
setblock 89 134 281 minecraft:blue_concrete
fill 89 134 282 89 136 282 minecraft:blue_terracotta
fill 89 134 285 89 134 286 minecraft:blue_concrete
setblock 89 134 291 minecraft:blue_concrete
fill 89 134 297 89 136 297 minecraft:blue_terracotta
setblock 89 134 300 minecraft:blue_concrete
fill 89 134 302 89 136 303 minecraft:blue_terracotta
setblock 89 134 305 minecraft:blue_concrete
fill 89 134 315 89 136 315 minecraft:blue_terracotta
setblock 89 134 317 minecraft:blue_concrete
fill 47 135 281 47 136 281 minecraft:blue_terracotta
fill 47 135 289 47 136 289 minecraft:blue_terracotta
fill 47 135 299 47 138 299 minecraft:blue_terracotta
setblock 47 135 307 minecraft:blue_concrete
fill 47 135 308 47 136 309 minecraft:blue_terracotta
setblock 47 135 315 minecraft:blue_concrete
fill 48 135 275 49 135 275 minecraft:blue_concrete
setblock 48 135 276 minecraft:spruce_planks
setblock 48 135 283 minecraft:spruce_planks
setblock 48 135 290 minecraft:spruce_planks
setblock 48 135 297 minecraft:spruce_planks
setblock 48 135 304 minecraft:spruce_planks
setblock 48 135 311 minecraft:spruce_planks
setblock 48 135 317 minecraft:blue_concrete
fill 49 135 317 49 136 317 minecraft:blue_terracotta
setblock 50 135 278 minecraft:light[level=12]
setblock 50 135 285 minecraft:light[level=12]
setblock 50 135 292 minecraft:light[level=12]
setblock 50 135 299 minecraft:light[level=12]
setblock 50 135 306 minecraft:light[level=12]
setblock 50 135 313 minecraft:light[level=12]
setblock 50 135 316 minecraft:spruce_planks
setblock 50 135 317 minecraft:blue_concrete
setblock 52 135 275 minecraft:blue_concrete
fill 52 135 296 52 136 298 minecraft:dark_oak_planks
fill 52 135 317 52 138 317 minecraft:blue_terracotta
fill 53 135 275 55 136 275 minecraft:blue_terracotta
fill 53 135 299 53 136 299 minecraft:dark_oak_planks
fill 54 135 294 54 136 294 minecraft:dark_oak_planks
fill 54 135 300 54 136 300 minecraft:dark_oak_planks
setblock 54 135 317 minecraft:blue_concrete
setblock 55 135 276 minecraft:spruce_planks
fill 55 135 317 55 136 317 minecraft:blue_terracotta
setblock 57 135 278 minecraft:light[level=12]
setblock 57 135 285 minecraft:light[level=12]
setblock 57 135 292 minecraft:light[level=12]
fill 57 135 294 57 136 294 minecraft:dark_oak_planks
fill 57 135 300 57 136 300 minecraft:dark_oak_planks
setblock 57 135 306 minecraft:light[level=12]
setblock 57 135 313 minecraft:light[level=12]
setblock 57 135 316 minecraft:spruce_planks
fill 58 135 299 58 136 299 minecraft:dark_oak_planks
fill 59 135 296 59 136 298 minecraft:dark_oak_planks
setblock 60 135 317 minecraft:blue_concrete
setblock 62 135 276 minecraft:spruce_planks
setblock 64 135 278 minecraft:light[level=12]
setblock 64 135 285 minecraft:light[level=12]
setblock 64 135 299 minecraft:light[level=12]
setblock 64 135 306 minecraft:light[level=12]
setblock 64 135 313 minecraft:light[level=12]
setblock 64 135 316 minecraft:spruce_planks
fill 65 135 275 65 136 275 minecraft:blue_terracotta
setblock 66 135 317 minecraft:blue_concrete
setblock 69 135 276 minecraft:spruce_planks
setblock 71 135 278 minecraft:light[level=12]
setblock 71 135 285 minecraft:light[level=12]
setblock 71 135 292 minecraft:light[level=12]
setblock 71 135 299 minecraft:light[level=12]
setblock 71 135 306 minecraft:light[level=12]
setblock 71 135 313 minecraft:light[level=12]
setblock 71 135 316 minecraft:spruce_planks
fill 74 135 317 74 137 317 minecraft:blue_terracotta
setblock 76 135 276 minecraft:spruce_planks
setblock 78 135 278 minecraft:light[level=12]
setblock 78 135 285 minecraft:light[level=12]
setblock 78 135 292 minecraft:light[level=12]
setblock 78 135 299 minecraft:light[level=12]
setblock 78 135 306 minecraft:light[level=12]
setblock 78 135 313 minecraft:light[level=12]
setblock 78 135 316 minecraft:spruce_planks
fill 79 135 275 79 136 275 minecraft:blue_terracotta
setblock 80 135 275 minecraft:blue_concrete
fill 81 135 275 81 136 275 minecraft:blue_terracotta
fill 81 135 317 81 136 317 minecraft:blue_terracotta
setblock 82 135 317 minecraft:blue_concrete
setblock 83 135 275 minecraft:blue_concrete
setblock 83 135 276 minecraft:spruce_planks
setblock 85 135 278 minecraft:light[level=12]
setblock 85 135 285 minecraft:light[level=12]
setblock 85 135 292 minecraft:light[level=12]
setblock 85 135 299 minecraft:light[level=12]
setblock 85 135 306 minecraft:light[level=12]
setblock 85 135 313 minecraft:light[level=12]
setblock 85 135 316 minecraft:spruce_planks
fill 86 135 317 87 136 317 minecraft:blue_terracotta
fill 88 135 275 88 136 275 minecraft:blue_terracotta
setblock 88 135 278 minecraft:spruce_planks
setblock 88 135 285 minecraft:spruce_planks
setblock 88 135 292 minecraft:spruce_planks
setblock 88 135 299 minecraft:spruce_planks
setblock 88 135 306 minecraft:spruce_planks
setblock 88 135 313 minecraft:spruce_planks
setblock 89 135 276 minecraft:blue_concrete
fill 89 135 277 89 136 277 minecraft:blue_terracotta
fill 89 135 281 89 136 281 minecraft:blue_terracotta
fill 89 135 285 89 136 286 minecraft:blue_terracotta
fill 89 135 290 89 136 291 minecraft:blue_terracotta
setblock 89 135 293 minecraft:white_wool
setblock 89 135 295 minecraft:blue_concrete
fill 89 135 298 89 137 298 minecraft:blue_terracotta
setblock 89 135 299 minecraft:blue_concrete
fill 89 135 300 89 136 300 minecraft:blue_terracotta
fill 89 135 305 89 136 305 minecraft:blue_terracotta
setblock 89 135 308 minecraft:blue_concrete
setblock 89 135 314 minecraft:blue_concrete
fill 89 135 317 89 136 317 minecraft:blue_terracotta
setblock 47 136 307 minecraft:blue_terracotta
setblock 47 136 315 minecraft:blue_terracotta
fill 48 136 275 49 136 275 minecraft:blue_terracotta
setblock 48 136 277 minecraft:spruce_planks
setblock 48 136 284 minecraft:spruce_planks
setblock 48 136 291 minecraft:spruce_planks
setblock 48 136 298 minecraft:spruce_planks
setblock 48 136 305 minecraft:spruce_planks
setblock 48 136 312 minecraft:spruce_planks
setblock 48 136 317 minecraft:blue_terracotta
setblock 50 136 317 minecraft:blue_terracotta
setblock 51 136 316 minecraft:spruce_planks
fill 52 136 275 52 137 275 minecraft:blue_terracotta
setblock 52 136 295 minecraft:dark_oak_planks
setblock 52 136 299 minecraft:dark_oak_planks
setblock 53 136 294 minecraft:dark_oak_planks
setblock 53 136 300 minecraft:dark_oak_planks
setblock 54 136 276 minecraft:spruce_planks
fill 54 136 293 57 136 293 minecraft:dark_oak_planks
setblock 54 136 317 minecraft:blue_terracotta
fill 57 136 317 57 137 317 minecraft:blue_terracotta
setblock 58 136 294 minecraft:dark_oak_planks
setblock 58 136 300 minecraft:dark_oak_planks
setblock 58 136 316 minecraft:spruce_planks
setblock 58 136 317 minecraft:light_blue_wool
setblock 59 136 295 minecraft:dark_oak_planks
setblock 59 136 299 minecraft:dark_oak_planks
setblock 60 136 317 minecraft:blue_terracotta
setblock 61 136 276 minecraft:spruce_planks
setblock 64 136 317 minecraft:blue_terracotta
setblock 65 136 316 minecraft:spruce_planks
setblock 66 136 317 minecraft:blue_terracotta
setblock 68 136 276 minecraft:spruce_planks
setblock 72 136 316 minecraft:spruce_planks
setblock 75 136 276 minecraft:spruce_planks
setblock 79 136 316 minecraft:spruce_planks
setblock 80 136 275 minecraft:blue_terracotta
setblock 82 136 276 minecraft:spruce_planks
setblock 82 136 317 minecraft:blue_terracotta
setblock 83 136 275 minecraft:blue_terracotta
setblock 86 136 316 minecraft:spruce_planks
setblock 88 136 277 minecraft:spruce_planks
setblock 88 136 284 minecraft:spruce_planks
setblock 88 136 291 minecraft:spruce_planks
setblock 88 136 298 minecraft:spruce_planks
setblock 88 136 305 minecraft:spruce_planks
setblock 88 136 312 minecraft:spruce_planks
setblock 89 136 276 minecraft:blue_terracotta
setblock 89 136 293 minecraft:blue_terracotta
setblock 89 136 295 minecraft:blue_terracotta
setblock 89 136 299 minecraft:blue_terracotta
setblock 89 136 308 minecraft:blue_terracotta
setblock 89 136 314 minecraft:blue_terracotta
fill 47 137 275 47 137 298 minecraft:blue_concrete
fill 47 137 300 47 191 301 minecraft:blue_concrete
fill 47 137 303 47 139 304 minecraft:blue_concrete
setblock 47 137 305 minecraft:blue_terracotta
fill 47 137 306 47 137 317 minecraft:blue_concrete
fill 48 137 275 49 138 275 minecraft:blue_concrete
setblock 48 137 278 minecraft:spruce_planks
setblock 48 137 285 minecraft:spruce_planks
setblock 48 137 292 minecraft:spruce_planks
setblock 48 137 299 minecraft:spruce_planks
setblock 48 137 306 minecraft:spruce_planks
setblock 48 137 313 minecraft:spruce_planks
fill 48 137 317 50 189 317 minecraft:blue_concrete
setblock 50 137 278 minecraft:light[level=15]
setblock 50 137 286 minecraft:light[level=15]
setblock 50 137 294 minecraft:light[level=15]
setblock 50 137 302 minecraft:light[level=15]
setblock 50 137 310 minecraft:light[level=15]
fill 51 137 275 51 154 275 minecraft:blue_concrete
setblock 52 137 316 minecraft:spruce_planks
fill 53 137 275 60 149 275 minecraft:blue_concrete
setblock 53 137 276 minecraft:spruce_planks
fill 53 137 317 56 137 317 minecraft:blue_concrete
fill 54 137 297 54 139 297 minecraft:spruce_planks
fill 56 137 295 56 138 295 minecraft:spruce_planks
fill 56 137 298 56 140 298 minecraft:spruce_planks
setblock 58 137 278 minecraft:light[level=15]
setblock 58 137 286 minecraft:light[level=15]
setblock 58 137 294 minecraft:light[level=15]
setblock 58 137 302 minecraft:light[level=15]
setblock 58 137 310 minecraft:light[level=15]
fill 58 137 317 62 138 317 minecraft:blue_concrete
setblock 59 137 316 minecraft:spruce_planks
setblock 60 137 276 minecraft:spruce_planks
setblock 61 137 275 minecraft:blue_terracotta
fill 62 137 275 66 137 275 minecraft:blue_concrete
fill 64 137 317 73 137 317 minecraft:blue_concrete
setblock 66 137 278 minecraft:light[level=15]
setblock 66 137 286 minecraft:light[level=15]
setblock 66 137 294 minecraft:light[level=15]
setblock 66 137 302 minecraft:light[level=15]
setblock 66 137 310 minecraft:light[level=15]
setblock 66 137 316 minecraft:spruce_planks
setblock 67 137 275 minecraft:blue_terracotta
setblock 67 137 276 minecraft:spruce_planks
fill 68 137 275 81 137 275 minecraft:blue_concrete
setblock 73 137 316 minecraft:spruce_planks
setblock 74 137 276 minecraft:spruce_planks
setblock 74 137 278 minecraft:light[level=15]
setblock 74 137 286 minecraft:light[level=15]
setblock 74 137 294 minecraft:light[level=15]
setblock 74 137 302 minecraft:light[level=15]
setblock 74 137 310 minecraft:light[level=15]
fill 75 137 317 75 146 317 minecraft:blue_concrete
fill 76 137 317 76 138 317 minecraft:blue_terracotta
fill 77 137 317 77 194 317 minecraft:blue_concrete
fill 79 137 317 84 137 317 minecraft:blue_concrete
setblock 80 137 316 minecraft:spruce_planks
setblock 81 137 276 minecraft:spruce_planks
setblock 82 137 278 minecraft:light[level=15]
setblock 82 137 286 minecraft:light[level=15]
setblock 82 137 294 minecraft:light[level=15]
setblock 82 137 302 minecraft:light[level=15]
setblock 82 137 310 minecraft:light[level=15]
fill 83 137 275 83 193 275 minecraft:blue_concrete
fill 85 137 275 89 190 275 minecraft:blue_concrete
setblock 86 137 317 minecraft:blue_terracotta
setblock 87 137 316 minecraft:spruce_planks
fill 87 137 317 89 177 317 minecraft:blue_concrete
setblock 88 137 276 minecraft:spruce_planks
setblock 88 137 283 minecraft:spruce_planks
setblock 88 137 290 minecraft:spruce_planks
setblock 88 137 297 minecraft:spruce_planks
setblock 88 137 304 minecraft:spruce_planks
setblock 88 137 311 minecraft:spruce_planks
fill 89 137 276 89 137 279 minecraft:blue_concrete
fill 89 137 281 89 137 297 minecraft:blue_concrete
fill 89 137 299 89 137 316 minecraft:blue_concrete
fill 47 138 275 47 139 275 minecraft:blue_terracotta
fill 47 138 276 47 138 280 minecraft:blue_concrete
setblock 47 138 281 minecraft:blue_terracotta
fill 47 138 282 47 160 284 minecraft:blue_concrete
fill 47 138 285 47 139 285 minecraft:blue_terracotta
fill 47 138 286 47 138 298 minecraft:blue_concrete
fill 47 138 305 47 138 309 minecraft:blue_concrete
setblock 47 138 310 minecraft:blue_terracotta
fill 47 138 311 47 148 312 minecraft:blue_concrete
setblock 47 138 313 minecraft:blue_terracotta
fill 47 138 314 47 152 317 minecraft:blue_concrete
setblock 48 138 279 minecraft:spruce_planks
setblock 48 138 286 minecraft:spruce_planks
setblock 48 138 293 minecraft:spruce_planks
setblock 48 138 300 minecraft:spruce_planks
setblock 48 138 307 minecraft:spruce_planks
setblock 48 138 314 minecraft:spruce_planks
fill 50 138 275 50 191 275 minecraft:blue_concrete
fill 51 138 317 51 193 317 minecraft:blue_concrete
fill 52 138 275 52 191 275 minecraft:blue_concrete
setblock 52 138 276 minecraft:spruce_planks
setblock 53 138 316 minecraft:spruce_planks
fill 53 138 317 55 150 317 minecraft:blue_concrete
setblock 56 138 317 minecraft:white_wool
fill 57 138 317 57 194 317 minecraft:blue_concrete
setblock 59 138 276 minecraft:spruce_planks
setblock 60 138 316 minecraft:spruce_planks
fill 61 138 275 61 191 275 minecraft:blue_concrete
setblock 62 138 275 minecraft:blue_terracotta
fill 63 138 275 67 138 275 minecraft:blue_concrete
fill 63 138 317 70 142 317 minecraft:blue_concrete
setblock 66 138 276 minecraft:spruce_planks
setblock 67 138 316 minecraft:spruce_planks
setblock 68 138 275 minecraft:blue_terracotta
fill 69 138 275 70 147 275 minecraft:blue_concrete
fill 71 138 275 71 139 275 minecraft:blue_terracotta
setblock 71 138 317 minecraft:blue_terracotta
fill 72 138 275 82 138 275 minecraft:blue_concrete
fill 72 138 317 74 182 317 minecraft:blue_concrete
setblock 73 138 276 minecraft:spruce_planks
setblock 74 138 316 minecraft:spruce_planks
fill 78 138 282 78 155 282 minecraft:green_terracotta
fill 78 138 317 79 171 317 minecraft:blue_concrete
setblock 80 138 276 minecraft:spruce_planks
setblock 80 138 317 minecraft:white_wool
setblock 81 138 316 minecraft:spruce_planks
fill 81 138 317 86 138 317 minecraft:blue_concrete
fill 84 138 275 84 194 275 minecraft:blue_concrete
setblock 87 138 276 minecraft:spruce_planks
setblock 88 138 282 minecraft:spruce_planks
setblock 88 138 289 minecraft:spruce_planks
setblock 88 138 296 minecraft:spruce_planks
setblock 88 138 303 minecraft:spruce_planks
setblock 88 138 310 minecraft:spruce_planks
setblock 88 138 316 minecraft:spruce_planks
fill 89 138 276 89 157 277 minecraft:blue_concrete
setblock 89 138 278 minecraft:blue_terracotta
fill 89 138 279 89 140 283 minecraft:blue_concrete
setblock 89 138 284 minecraft:blue_terracotta
fill 89 138 285 89 152 286 minecraft:blue_concrete
setblock 89 138 287 minecraft:blue_terracotta
fill 89 138 288 89 177 292 minecraft:blue_concrete
setblock 89 138 293 minecraft:white_wool
setblock 89 138 294 minecraft:blue_terracotta
fill 89 138 295 89 138 298 minecraft:blue_concrete
setblock 89 138 299 minecraft:blue_terracotta
fill 89 138 300 89 169 301 minecraft:blue_concrete
fill 89 138 302 89 138 303 minecraft:blue_terracotta
fill 89 138 304 89 143 316 minecraft:blue_concrete
setblock 47 139 276 minecraft:blue_terracotta
fill 47 139 277 47 172 277 minecraft:blue_concrete
fill 47 139 278 47 139 279 minecraft:blue_terracotta
fill 47 139 280 47 143 281 minecraft:blue_concrete
fill 47 139 286 47 144 295 minecraft:blue_concrete
setblock 47 139 296 minecraft:blue_terracotta
fill 47 139 297 47 149 299 minecraft:blue_concrete
fill 47 139 302 47 193 302 minecraft:blue_concrete
fill 47 139 305 47 151 308 minecraft:blue_concrete
setblock 47 139 309 minecraft:blue_terracotta
fill 47 139 310 47 193 310 minecraft:blue_concrete
fill 47 139 313 47 186 313 minecraft:blue_concrete
setblock 48 139 275 minecraft:blue_terracotta
fill 48 139 280 48 140 280 minecraft:spruce_planks
fill 48 139 287 48 140 287 minecraft:spruce_planks
fill 48 139 294 48 140 294 minecraft:spruce_planks
fill 48 139 301 48 140 301 minecraft:spruce_planks
fill 48 139 308 48 140 308 minecraft:spruce_planks
fill 48 139 315 48 140 315 minecraft:spruce_planks
fill 49 139 275 49 186 275 minecraft:blue_concrete
fill 51 139 276 51 140 276 minecraft:spruce_planks
fill 52 139 317 52 193 317 minecraft:blue_concrete
fill 54 139 316 54 140 316 minecraft:spruce_planks
fill 56 139 317 56 189 317 minecraft:blue_concrete
fill 58 139 276 58 140 276 minecraft:spruce_planks
fill 58 139 317 59 139 317 minecraft:blue_concrete
setblock 60 139 317 minecraft:blue_terracotta
fill 61 139 316 61 140 316 minecraft:spruce_planks
fill 61 139 317 62 193 317 minecraft:blue_concrete
fill 62 139 275 63 187 275 minecraft:blue_concrete
setblock 64 139 275 minecraft:blue_terracotta
fill 65 139 275 68 157 275 minecraft:blue_concrete
fill 65 139 276 65 140 276 minecraft:spruce_planks
fill 68 139 316 68 140 316 minecraft:spruce_planks
fill 71 139 317 71 159 317 minecraft:blue_concrete
fill 72 139 275 72 193 275 minecraft:blue_concrete
fill 72 139 276 72 140 276 minecraft:spruce_planks
fill 73 139 275 74 139 275 minecraft:blue_terracotta
fill 75 139 275 79 145 275 minecraft:blue_concrete
fill 75 139 316 75 140 316 minecraft:spruce_planks
fill 76 139 317 76 143 317 minecraft:blue_concrete
fill 79 139 276 79 140 276 minecraft:spruce_planks
setblock 80 139 275 minecraft:blue_terracotta
fill 80 139 317 84 150 317 minecraft:blue_concrete
fill 81 139 275 82 158 275 minecraft:blue_concrete
fill 82 139 316 82 140 316 minecraft:spruce_planks
setblock 85 139 317 minecraft:blue_terracotta
fill 86 139 276 86 140 276 minecraft:spruce_planks
fill 86 139 317 86 193 317 minecraft:blue_concrete
fill 88 139 281 88 140 281 minecraft:spruce_planks
fill 88 139 288 88 140 288 minecraft:spruce_planks
fill 88 139 295 88 140 295 minecraft:spruce_planks
fill 88 139 302 88 140 302 minecraft:spruce_planks
fill 88 139 309 88 140 309 minecraft:spruce_planks
fill 89 139 278 89 194 278 minecraft:blue_concrete
fill 89 139 284 89 151 284 minecraft:blue_concrete
fill 89 139 287 89 164 287 minecraft:blue_concrete
fill 89 139 293 89 161 294 minecraft:blue_concrete
setblock 89 139 295 minecraft:blue_terracotta
fill 89 139 296 89 150 299 minecraft:blue_concrete
setblock 89 139 302 minecraft:blue_terracotta
setblock 89 139 303 minecraft:light_blue_wool
fill 47 140 275 47 193 276 minecraft:blue_concrete
fill 47 140 278 47 191 279 minecraft:blue_concrete
fill 47 140 285 47 193 285 minecraft:blue_concrete
fill 47 140 296 47 189 296 minecraft:blue_concrete
fill 47 140 303 47 193 303 minecraft:blue_concrete
setblock 47 140 304 minecraft:white_wool
setblock 47 140 309 minecraft:white_wool
fill 48 140 275 48 193 275 minecraft:blue_concrete
fill 48 140 276 48 140 279 minecraft:spruce_planks
fill 48 140 282 48 140 286 minecraft:spruce_planks
fill 48 140 289 48 140 293 minecraft:spruce_planks
fill 48 140 296 48 140 300 minecraft:spruce_planks
fill 48 140 303 48 140 307 minecraft:spruce_planks
fill 48 140 310 48 140 314 minecraft:spruce_planks
fill 49 140 276 49 141 276 minecraft:spruce_planks
fill 49 140 307 49 147 307 minecraft:iron_bars
fill 49 140 316 53 140 316 minecraft:spruce_planks
fill 52 140 276 56 140 276 minecraft:spruce_planks
fill 56 140 316 60 140 316 minecraft:spruce_planks
setblock 58 140 317 minecraft:white_wool
fill 59 140 276 63 140 276 minecraft:spruce_planks
fill 59 140 317 60 142 317 minecraft:blue_concrete
fill 63 140 316 67 140 316 minecraft:spruce_planks
fill 64 140 275 64 148 275 minecraft:blue_concrete
fill 66 140 276 70 140 276 minecraft:spruce_planks
fill 70 140 316 74 140 316 minecraft:spruce_planks
fill 71 140 275 71 175 275 minecraft:blue_concrete
fill 73 140 275 74 193 275 minecraft:blue_concrete
fill 73 140 276 77 140 276 minecraft:spruce_planks
fill 77 140 316 81 140 316 minecraft:spruce_planks
fill 80 140 275 80 191 275 minecraft:blue_concrete
fill 80 140 276 84 140 276 minecraft:spruce_planks
fill 84 140 316 88 140 316 minecraft:spruce_planks
fill 85 140 317 85 179 317 minecraft:blue_concrete
fill 87 140 276 88 140 276 minecraft:spruce_planks
fill 88 140 277 88 140 279 minecraft:spruce_planks
fill 88 140 282 88 140 286 minecraft:spruce_planks
fill 88 140 289 88 140 293 minecraft:spruce_planks
fill 88 140 296 88 140 300 minecraft:spruce_planks
fill 88 140 303 88 140 307 minecraft:spruce_planks
fill 88 140 310 88 140 314 minecraft:spruce_planks
fill 89 140 295 89 169 295 minecraft:blue_concrete
fill 89 140 302 89 166 303 minecraft:blue_concrete
fill 47 141 304 47 191 304 minecraft:blue_concrete
fill 47 141 309 47 193 309 minecraft:blue_concrete
setblock 48 141 282 minecraft:spruce_planks
setblock 48 141 289 minecraft:spruce_planks
setblock 48 141 296 minecraft:spruce_planks
setblock 48 141 303 minecraft:spruce_planks
setblock 48 141 310 minecraft:spruce_planks
setblock 49 141 316 minecraft:spruce_planks
setblock 50 141 278 minecraft:light[level=12]
setblock 50 141 285 minecraft:light[level=12]
setblock 50 141 292 minecraft:light[level=12]
setblock 50 141 299 minecraft:light[level=12]
setblock 50 141 306 minecraft:light[level=12]
setblock 50 141 313 minecraft:light[level=12]
setblock 56 141 276 minecraft:spruce_planks
setblock 56 141 316 minecraft:spruce_planks
setblock 57 141 278 minecraft:light[level=12]
setblock 57 141 285 minecraft:light[level=12]
setblock 57 141 292 minecraft:light[level=12]
setblock 57 141 299 minecraft:light[level=12]
setblock 57 141 306 minecraft:light[level=12]
setblock 57 141 313 minecraft:light[level=12]
fill 58 141 317 58 193 317 minecraft:blue_concrete
setblock 63 141 276 minecraft:spruce_planks
setblock 63 141 316 minecraft:spruce_planks
setblock 64 141 278 minecraft:light[level=12]
setblock 64 141 285 minecraft:light[level=12]
setblock 64 141 299 minecraft:light[level=12]
setblock 64 141 306 minecraft:light[level=12]
setblock 64 141 313 minecraft:light[level=12]
setblock 70 141 276 minecraft:spruce_planks
setblock 70 141 316 minecraft:spruce_planks
setblock 71 141 278 minecraft:light[level=12]
setblock 71 141 285 minecraft:light[level=12]
setblock 71 141 292 minecraft:light[level=12]
setblock 71 141 299 minecraft:light[level=12]
setblock 71 141 306 minecraft:light[level=12]
setblock 71 141 313 minecraft:light[level=12]
setblock 77 141 276 minecraft:spruce_planks
setblock 77 141 316 minecraft:spruce_planks
setblock 78 141 278 minecraft:light[level=12]
setblock 78 141 285 minecraft:light[level=12]
setblock 78 141 292 minecraft:light[level=12]
setblock 78 141 299 minecraft:light[level=12]
setblock 78 141 306 minecraft:light[level=12]
setblock 78 141 313 minecraft:light[level=12]
setblock 84 141 276 minecraft:spruce_planks
setblock 84 141 316 minecraft:spruce_planks
setblock 85 141 278 minecraft:light[level=12]
setblock 85 141 285 minecraft:light[level=12]
setblock 85 141 292 minecraft:light[level=12]
setblock 85 141 299 minecraft:light[level=12]
setblock 85 141 306 minecraft:light[level=12]
setblock 85 141 313 minecraft:light[level=12]
setblock 88 141 279 minecraft:spruce_planks
setblock 88 141 286 minecraft:spruce_planks
setblock 88 141 293 minecraft:spruce_planks
setblock 88 141 300 minecraft:spruce_planks
setblock 88 141 307 minecraft:spruce_planks
setblock 88 141 314 minecraft:spruce_planks
fill 89 141 279 89 176 280 minecraft:blue_concrete
setblock 89 141 281 minecraft:white_wool
fill 89 141 282 89 148 283 minecraft:blue_concrete
setblock 48 142 276 minecraft:spruce_planks
setblock 48 142 283 minecraft:spruce_planks
setblock 48 142 290 minecraft:spruce_planks
setblock 48 142 297 minecraft:spruce_planks
setblock 48 142 304 minecraft:spruce_planks
setblock 48 142 311 minecraft:spruce_planks
setblock 50 142 316 minecraft:spruce_planks
setblock 55 142 276 minecraft:spruce_planks
setblock 57 142 316 minecraft:spruce_planks
setblock 62 142 276 minecraft:spruce_planks
setblock 64 142 316 minecraft:spruce_planks
setblock 69 142 276 minecraft:spruce_planks
setblock 71 142 316 minecraft:spruce_planks
setblock 76 142 276 minecraft:spruce_planks
setblock 78 142 316 minecraft:spruce_planks
setblock 83 142 276 minecraft:spruce_planks
setblock 85 142 316 minecraft:spruce_planks
setblock 88 142 278 minecraft:spruce_planks
setblock 88 142 285 minecraft:spruce_planks
setblock 88 142 292 minecraft:spruce_planks
setblock 88 142 299 minecraft:spruce_planks
setblock 88 142 306 minecraft:spruce_planks
setblock 88 142 313 minecraft:spruce_planks
fill 89 142 281 89 191 281 minecraft:blue_concrete
setblock 48 143 277 minecraft:spruce_planks
fill 48 143 280 56 149 280 minecraft:white_wool
setblock 48 143 284 minecraft:spruce_planks
setblock 48 143 291 minecraft:spruce_planks
setblock 48 143 298 minecraft:spruce_planks
setblock 48 143 305 minecraft:spruce_planks
setblock 48 143 312 minecraft:spruce_planks
fill 51 143 303 51 144 303 minecraft:dark_oak_planks
fill 51 143 312 51 144 313 minecraft:dark_oak_planks
setblock 51 143 316 minecraft:spruce_planks
setblock 54 143 276 minecraft:spruce_planks
setblock 58 143 316 minecraft:spruce_planks
fill 59 143 317 59 185 317 minecraft:blue_concrete
setblock 60 143 317 minecraft:light_blue_wool
setblock 61 143 276 minecraft:spruce_planks
fill 63 143 317 68 160 317 minecraft:blue_concrete
setblock 65 143 316 minecraft:spruce_planks
setblock 68 143 276 minecraft:spruce_planks
setblock 69 143 317 minecraft:white_wool
fill 70 143 317 70 193 317 minecraft:blue_concrete
setblock 72 143 316 minecraft:spruce_planks
setblock 75 143 276 minecraft:spruce_planks
fill 75 143 312 75 144 312 minecraft:dark_oak_planks
setblock 79 143 316 minecraft:spruce_planks
fill 80 143 312 88 143 312 minecraft:white_wool
setblock 82 143 276 minecraft:spruce_planks
fill 84 143 307 84 144 307 minecraft:dark_oak_planks
setblock 86 143 316 minecraft:spruce_planks
setblock 88 143 277 minecraft:spruce_planks
setblock 88 143 284 minecraft:spruce_planks
setblock 88 143 291 minecraft:spruce_planks
setblock 88 143 298 minecraft:spruce_planks
setblock 88 143 305 minecraft:spruce_planks
setblock 47 144 280 minecraft:light_blue_wool
fill 47 144 281 47 150 281 minecraft:blue_concrete
setblock 48 144 278 minecraft:spruce_planks
setblock 48 144 285 minecraft:spruce_planks
setblock 48 144 292 minecraft:spruce_planks
setblock 48 144 299 minecraft:spruce_planks
setblock 48 144 306 minecraft:spruce_planks
setblock 48 144 313 minecraft:spruce_planks
fill 50 144 303 50 145 303 minecraft:dark_oak_planks
fill 50 144 312 50 145 313 minecraft:dark_oak_planks
setblock 52 144 316 minecraft:spruce_planks
setblock 53 144 276 minecraft:spruce_planks
fill 55 144 295 55 145 295 minecraft:shroomlight
setblock 59 144 316 minecraft:spruce_planks
setblock 60 144 276 minecraft:spruce_planks
fill 60 144 317 60 193 317 minecraft:blue_concrete
fill 63 144 280 64 144 280 minecraft:white_concrete
setblock 66 144 316 minecraft:spruce_planks
setblock 67 144 276 minecraft:spruce_planks
fill 69 144 317 69 193 317 minecraft:blue_concrete
setblock 73 144 316 minecraft:spruce_planks
setblock 74 144 276 minecraft:spruce_planks
fill 75 144 313 75 145 313 minecraft:dark_oak_planks
setblock 76 144 317 minecraft:light_blue_wool
fill 80 144 312 81 144 312 minecraft:white_concrete
setblock 80 144 316 minecraft:spruce_planks
setblock 81 144 276 minecraft:spruce_planks
fill 82 144 312 88 149 312 minecraft:white_wool
fill 85 144 307 85 145 307 minecraft:dark_oak_planks
setblock 87 144 316 minecraft:spruce_planks
setblock 88 144 276 minecraft:spruce_planks
setblock 88 144 283 minecraft:spruce_planks
setblock 88 144 290 minecraft:spruce_planks
setblock 88 144 297 minecraft:spruce_planks
setblock 88 144 304 minecraft:spruce_planks
setblock 88 144 311 minecraft:spruce_planks
fill 89 144 304 89 168 309 minecraft:blue_concrete
setblock 89 144 310 minecraft:white_wool
fill 89 144 311 89 160 316 minecraft:blue_concrete
fill 47 145 280 47 193 280 minecraft:blue_concrete
fill 47 145 286 47 146 293 minecraft:blue_concrete
setblock 47 145 294 minecraft:white_wool
fill 47 145 295 47 190 295 minecraft:blue_concrete
setblock 48 145 279 minecraft:spruce_planks
setblock 48 145 286 minecraft:spruce_planks
setblock 48 145 293 minecraft:spruce_planks
setblock 48 145 300 minecraft:spruce_planks
setblock 48 145 307 minecraft:spruce_planks
setblock 48 145 314 minecraft:spruce_planks
fill 49 145 303 49 146 303 minecraft:dark_oak_planks
fill 49 145 312 49 146 313 minecraft:dark_oak_planks
setblock 50 145 278 minecraft:light[level=15]
setblock 50 145 286 minecraft:light[level=15]
setblock 50 145 294 minecraft:light[level=15]
setblock 50 145 302 minecraft:light[level=15]
setblock 50 145 310 minecraft:light[level=15]
setblock 52 145 276 minecraft:spruce_planks
setblock 53 145 316 minecraft:spruce_planks
setblock 58 145 278 minecraft:light[level=15]
setblock 58 145 286 minecraft:light[level=15]
setblock 58 145 294 minecraft:light[level=15]
setblock 58 145 302 minecraft:light[level=15]
setblock 58 145 310 minecraft:light[level=15]
setblock 59 145 276 minecraft:spruce_planks
setblock 60 145 316 minecraft:spruce_planks
setblock 66 145 276 minecraft:spruce_planks
setblock 66 145 278 minecraft:light[level=15]
setblock 66 145 286 minecraft:light[level=15]
setblock 66 145 294 minecraft:light[level=15]
setblock 66 145 302 minecraft:light[level=15]
setblock 66 145 310 minecraft:light[level=15]
setblock 67 145 316 minecraft:spruce_planks
setblock 73 145 276 minecraft:spruce_planks
setblock 74 145 278 minecraft:light[level=15]
setblock 74 145 286 minecraft:light[level=15]
setblock 74 145 294 minecraft:light[level=15]
setblock 74 145 302 minecraft:light[level=15]
setblock 74 145 310 minecraft:light[level=15]
setblock 74 145 316 minecraft:spruce_planks
fill 75 145 314 75 146 314 minecraft:dark_oak_planks
fill 76 145 317 76 193 317 minecraft:blue_concrete
setblock 80 145 276 minecraft:spruce_planks
fill 80 145 312 81 149 312 minecraft:white_wool
setblock 81 145 316 minecraft:spruce_planks
setblock 82 145 278 minecraft:light[level=15]
setblock 82 145 286 minecraft:light[level=15]
setblock 82 145 294 minecraft:light[level=15]
setblock 82 145 302 minecraft:light[level=15]
setblock 82 145 310 minecraft:light[level=15]
fill 86 145 307 86 146 307 minecraft:dark_oak_planks
setblock 87 145 276 minecraft:spruce_planks
setblock 88 145 282 minecraft:spruce_planks
setblock 88 145 289 minecraft:spruce_planks
setblock 88 145 296 minecraft:spruce_planks
setblock 88 145 303 minecraft:spruce_planks
setblock 88 145 310 minecraft:spruce_planks
setblock 88 145 316 minecraft:spruce_planks
fill 89 145 310 89 177 310 minecraft:blue_concrete
fill 47 146 294 47 184 294 minecraft:blue_concrete
setblock 48 146 287 minecraft:spruce_planks
setblock 48 146 294 minecraft:spruce_planks
setblock 48 146 301 minecraft:spruce_planks
fill 48 146 303 48 147 303 minecraft:dark_oak_planks
setblock 48 146 308 minecraft:spruce_planks
fill 48 146 312 48 147 313 minecraft:dark_oak_planks
setblock 48 146 315 minecraft:spruce_planks
setblock 51 146 276 minecraft:spruce_planks
setblock 54 146 316 minecraft:spruce_planks
fill 55 146 295 55 154 295 minecraft:dark_oak_planks
setblock 58 146 276 minecraft:spruce_planks
setblock 61 146 316 minecraft:spruce_planks
setblock 65 146 276 minecraft:spruce_planks
setblock 68 146 316 minecraft:spruce_planks
setblock 72 146 276 minecraft:spruce_planks
fill 75 146 275 76 154 275 minecraft:blue_concrete
fill 75 146 315 75 147 315 minecraft:dark_oak_planks
setblock 75 146 316 minecraft:spruce_planks
setblock 77 146 275 minecraft:white_wool
fill 78 146 275 79 191 275 minecraft:blue_concrete
setblock 79 146 276 minecraft:spruce_planks
setblock 82 146 316 minecraft:spruce_planks
setblock 86 146 276 minecraft:spruce_planks
fill 87 146 307 87 147 307 minecraft:dark_oak_planks
setblock 88 146 281 minecraft:spruce_planks
setblock 88 146 288 minecraft:spruce_planks
setblock 88 146 295 minecraft:spruce_planks
setblock 88 146 302 minecraft:spruce_planks
setblock 88 146 309 minecraft:spruce_planks
fill 47 147 286 47 157 292 minecraft:blue_concrete
setblock 47 147 293 minecraft:light_blue_wool
setblock 50 147 278 minecraft:light[level=12]
setblock 50 147 285 minecraft:light[level=12]
setblock 50 147 292 minecraft:light[level=12]
setblock 50 147 299 minecraft:light[level=12]
setblock 50 147 306 minecraft:light[level=12]
setblock 50 147 313 minecraft:light[level=12]
setblock 51 147 283 minecraft:shroomlight
setblock 51 147 289 minecraft:shroomlight
setblock 51 147 295 minecraft:shroomlight
setblock 51 147 301 minecraft:shroomlight
setblock 51 147 307 minecraft:shroomlight
setblock 51 147 313 minecraft:shroomlight
fill 54 147 295 54 154 295 minecraft:dark_oak_planks
setblock 55 147 279 minecraft:shroomlight
fill 55 147 294 55 154 294 minecraft:dark_oak_planks
setblock 57 147 278 minecraft:light[level=12]
setblock 57 147 285 minecraft:light[level=12]
setblock 57 147 292 minecraft:light[level=12]
setblock 57 147 299 minecraft:light[level=12]
setblock 57 147 306 minecraft:light[level=12]
setblock 57 147 313 minecraft:shroomlight
setblock 61 147 279 minecraft:shroomlight
setblock 63 147 313 minecraft:shroomlight
setblock 64 147 278 minecraft:light[level=12]
setblock 64 147 285 minecraft:light[level=12]
setblock 64 147 299 minecraft:light[level=12]
setblock 64 147 306 minecraft:light[level=12]
setblock 64 147 313 minecraft:light[level=12]
fill 67 147 276 67 147 278 minecraft:iron_bars
setblock 67 147 279 minecraft:shroomlight
setblock 69 147 313 minecraft:shroomlight
setblock 71 147 278 minecraft:light[level=12]
setblock 71 147 285 minecraft:light[level=12]
setblock 71 147 292 minecraft:light[level=12]
setblock 71 147 299 minecraft:light[level=12]
setblock 71 147 306 minecraft:light[level=12]
setblock 71 147 313 minecraft:light[level=12]
setblock 73 147 279 minecraft:shroomlight
setblock 75 147 313 minecraft:shroomlight
setblock 75 147 317 minecraft:white_wool
fill 77 147 275 77 190 275 minecraft:blue_concrete
setblock 78 147 278 minecraft:light[level=12]
setblock 78 147 285 minecraft:light[level=12]
setblock 78 147 292 minecraft:light[level=12]
setblock 78 147 299 minecraft:light[level=12]
setblock 78 147 306 minecraft:light[level=12]
setblock 78 147 313 minecraft:light[level=12]
setblock 79 147 279 minecraft:shroomlight
setblock 81 147 313 minecraft:shroomlight
setblock 85 147 278 minecraft:light[level=12]
setblock 85 147 279 minecraft:shroomlight
setblock 85 147 285 minecraft:shroomlight
setblock 85 147 291 minecraft:shroomlight
setblock 85 147 292 minecraft:light[level=12]
setblock 85 147 297 minecraft:shroomlight
setblock 85 147 299 minecraft:light[level=12]
setblock 85 147 303 minecraft:shroomlight
setblock 85 147 306 minecraft:light[level=12]
setblock 85 147 309 minecraft:shroomlight
setblock 85 147 313 minecraft:light[level=12]
fill 47 148 293 47 168 293 minecraft:blue_concrete
fill 48 148 276 49 148 279 minecraft:spruce_planks
fill 48 148 282 51 148 287 minecraft:spruce_planks
fill 48 148 289 51 148 294 minecraft:spruce_planks
fill 48 148 296 51 148 301 minecraft:spruce_planks
fill 48 148 303 51 148 308 minecraft:spruce_planks
fill 48 148 310 51 148 315 minecraft:spruce_planks
fill 49 148 281 51 148 281 minecraft:spruce_planks
fill 49 148 288 51 148 288 minecraft:spruce_planks
fill 49 148 295 51 148 295 minecraft:spruce_planks
fill 49 148 302 51 148 302 minecraft:spruce_planks
fill 49 148 309 51 148 309 minecraft:spruce_planks
fill 49 148 316 54 148 316 minecraft:spruce_planks
fill 50 148 277 51 148 279 minecraft:spruce_planks
fill 51 148 276 56 148 276 minecraft:spruce_planks
fill 52 148 277 88 148 278 minecraft:spruce_planks
fill 52 148 313 83 148 315 minecraft:spruce_planks
fill 53 148 279 88 148 279 minecraft:spruce_planks
fill 54 148 294 54 154 294 minecraft:dark_oak_planks
fill 55 148 296 55 154 296 minecraft:dark_oak_planks
fill 56 148 295 56 154 295 minecraft:dark_oak_planks
fill 56 148 316 61 148 316 minecraft:spruce_planks
fill 58 148 276 63 148 276 minecraft:spruce_planks
fill 63 148 316 68 148 316 minecraft:spruce_planks
fill 65 148 276 70 148 276 minecraft:spruce_planks
setblock 69 148 275 minecraft:white_wool
fill 70 148 275 70 151 275 minecraft:blue_concrete
fill 70 148 316 75 148 316 minecraft:spruce_planks
fill 72 148 276 77 148 276 minecraft:spruce_planks
fill 75 148 317 75 193 317 minecraft:blue_concrete
fill 77 148 316 82 148 316 minecraft:spruce_planks
fill 79 148 276 84 148 276 minecraft:spruce_planks
fill 84 148 314 87 148 316 minecraft:spruce_planks
fill 85 148 280 87 148 311 minecraft:spruce_planks
fill 85 148 313 88 148 313 minecraft:spruce_planks
fill 86 148 276 88 148 276 minecraft:spruce_planks
fill 88 148 281 88 148 286 minecraft:spruce_planks
fill 88 148 288 88 148 293 minecraft:spruce_planks
fill 88 148 295 88 148 300 minecraft:spruce_planks
fill 88 148 302 88 148 307 minecraft:spruce_planks
fill 88 148 309 88 148 311 minecraft:spruce_planks
setblock 88 148 314 minecraft:spruce_planks
setblock 88 148 316 minecraft:spruce_planks
fill 47 149 311 47 191 311 minecraft:blue_concrete
setblock 47 149 312 minecraft:white_wool
fill 48 149 276 48 150 276 minecraft:spruce_planks
fill 48 149 283 48 150 283 minecraft:spruce_planks
fill 48 149 290 48 150 290 minecraft:spruce_planks
fill 48 149 297 48 150 297 minecraft:spruce_planks
fill 48 149 304 48 150 304 minecraft:spruce_planks
fill 48 149 311 48 150 311 minecraft:spruce_planks
setblock 49 149 307 minecraft:iron_bars
fill 50 149 316 50 150 316 minecraft:spruce_planks
setblock 51 149 279 minecraft:dark_oak_planks
fill 51 149 281 51 149 313 minecraft:dark_oak_planks
fill 52 149 313 83 149 313 minecraft:dark_oak_planks
fill 53 149 279 85 149 279 minecraft:dark_oak_planks
fill 53 149 294 53 154 295 minecraft:dark_oak_planks
fill 54 149 293 55 154 293 minecraft:dark_oak_planks
fill 54 149 296 54 154 296 minecraft:dark_oak_planks
fill 55 149 276 55 150 276 minecraft:spruce_planks
fill 56 149 294 56 154 294 minecraft:dark_oak_planks
fill 57 149 316 57 150 316 minecraft:spruce_planks
fill 62 149 276 62 150 276 minecraft:spruce_planks
fill 62 149 310 62 152 310 minecraft:iron_bars
setblock 64 149 275 minecraft:white_wool
fill 64 149 316 64 150 316 minecraft:spruce_planks
fill 66 149 314 66 149 315 minecraft:iron_bars
fill 69 149 275 69 186 275 minecraft:blue_concrete
fill 69 149 276 69 150 276 minecraft:spruce_planks
fill 71 149 316 71 150 316 minecraft:spruce_planks
fill 76 149 276 76 150 276 minecraft:spruce_planks
fill 78 149 316 78 150 316 minecraft:spruce_planks
fill 83 149 276 83 150 276 minecraft:spruce_planks
fill 85 149 280 85 149 311 minecraft:dark_oak_planks
setblock 85 149 313 minecraft:dark_oak_planks
fill 85 149 316 85 150 316 minecraft:spruce_planks
fill 88 149 278 88 150 278 minecraft:spruce_planks
fill 88 149 285 88 150 285 minecraft:spruce_planks
fill 88 149 292 88 150 292 minecraft:spruce_planks
fill 88 149 299 88 150 299 minecraft:spruce_planks
fill 88 149 306 88 150 306 minecraft:spruce_planks
fill 88 149 313 88 150 313 minecraft:spruce_planks
setblock 89 149 282 minecraft:white_wool
fill 89 149 283 89 179 283 minecraft:blue_concrete
fill 47 150 297 47 193 297 minecraft:blue_concrete
setblock 47 150 298 minecraft:light_blue_wool
fill 47 150 299 47 193 299 minecraft:blue_concrete
fill 47 150 312 47 194 312 minecraft:blue_concrete
fill 48 150 277 48 150 279 minecraft:spruce_planks
fill 48 150 280 56 150 280 minecraft:spruce_log
setblock 48 150 282 minecraft:spruce_planks
fill 48 150 284 48 150 287 minecraft:spruce_planks
setblock 48 150 289 minecraft:spruce_planks
fill 48 150 291 48 150 294 minecraft:spruce_planks
setblock 48 150 296 minecraft:spruce_planks
fill 48 150 298 48 150 301 minecraft:spruce_planks
setblock 48 150 303 minecraft:spruce_planks
fill 48 150 305 48 150 308 minecraft:spruce_planks
setblock 48 150 310 minecraft:spruce_planks
fill 48 150 312 48 150 315 minecraft:spruce_planks
setblock 49 150 276 minecraft:spruce_planks
setblock 49 150 316 minecraft:spruce_planks
fill 51 150 276 54 150 276 minecraft:spruce_planks
fill 51 150 281 51 155 281 minecraft:iron_bars
fill 51 150 316 54 150 316 minecraft:spruce_planks
fill 53 150 275 56 165 275 minecraft:blue_concrete
fill 53 150 293 53 154 293 minecraft:dark_oak_planks
fill 53 150 296 53 154 296 minecraft:dark_oak_planks
setblock 56 150 276 minecraft:spruce_planks
fill 56 150 293 56 154 293 minecraft:dark_oak_planks
fill 56 150 296 56 154 296 minecraft:dark_oak_planks
setblock 56 150 316 minecraft:spruce_planks
setblock 57 150 275 minecraft:light_blue_wool
fill 57 150 295 57 154 295 minecraft:dark_oak_planks
fill 58 150 275 60 150 275 minecraft:blue_concrete
fill 58 150 276 61 150 276 minecraft:spruce_planks
fill 58 150 316 61 150 316 minecraft:spruce_planks
setblock 63 150 276 minecraft:spruce_planks
setblock 63 150 316 minecraft:spruce_planks
fill 64 150 275 64 193 275 minecraft:blue_concrete
fill 65 150 276 68 150 276 minecraft:spruce_planks
fill 65 150 316 68 150 316 minecraft:spruce_planks
setblock 70 150 276 minecraft:spruce_planks
setblock 70 150 316 minecraft:spruce_planks
fill 72 150 276 75 150 276 minecraft:spruce_planks
fill 72 150 316 75 150 316 minecraft:spruce_planks
fill 76 150 277 76 151 278 minecraft:iron_bars
setblock 77 150 276 minecraft:spruce_planks
setblock 77 150 316 minecraft:spruce_planks
fill 79 150 276 82 150 276 minecraft:spruce_planks
fill 79 150 316 82 150 316 minecraft:spruce_planks
fill 80 150 312 88 150 312 minecraft:spruce_log
setblock 84 150 276 minecraft:spruce_planks
setblock 84 150 316 minecraft:spruce_planks
fill 86 150 276 88 150 276 minecraft:spruce_planks
fill 86 150 316 88 150 316 minecraft:spruce_planks
setblock 88 150 277 minecraft:spruce_planks
setblock 88 150 279 minecraft:spruce_planks
fill 88 150 281 88 150 284 minecraft:spruce_planks
setblock 88 150 286 minecraft:spruce_planks
fill 88 150 288 88 150 291 minecraft:spruce_planks
setblock 88 150 293 minecraft:spruce_planks
fill 88 150 295 88 150 298 minecraft:spruce_planks
setblock 88 150 300 minecraft:spruce_planks
fill 88 150 302 88 150 305 minecraft:spruce_planks
setblock 88 150 307 minecraft:spruce_planks
fill 88 150 309 88 150 311 minecraft:spruce_planks
setblock 88 150 314 minecraft:spruce_planks
fill 89 150 282 89 193 282 minecraft:blue_concrete
setblock 47 151 281 minecraft:light_blue_wool
fill 47 151 298 47 191 298 minecraft:blue_concrete
setblock 48 151 278 minecraft:spruce_planks
setblock 48 151 285 minecraft:spruce_planks
setblock 48 151 292 minecraft:spruce_planks
setblock 48 151 299 minecraft:spruce_planks
setblock 48 151 306 minecraft:spruce_planks
setblock 48 151 313 minecraft:spruce_planks
fill 51 151 280 53 162 280 minecraft:spruce_log
fill 52 151 294 52 154 295 minecraft:dark_oak_planks
setblock 52 151 316 minecraft:spruce_planks
setblock 53 151 276 minecraft:spruce_planks
fill 53 151 317 53 189 317 minecraft:blue_concrete
fill 54 151 292 55 154 292 minecraft:dark_oak_planks
fill 54 151 297 56 154 297 minecraft:dark_oak_planks
setblock 54 151 317 minecraft:white_wool
fill 55 151 317 55 189 317 minecraft:blue_concrete
fill 57 151 275 59 168 275 minecraft:blue_concrete
fill 57 151 294 57 154 294 minecraft:dark_oak_planks
fill 57 151 296 57 154 296 minecraft:dark_oak_planks
setblock 59 151 316 minecraft:spruce_planks
setblock 60 151 275 minecraft:white_wool
setblock 60 151 276 minecraft:spruce_planks
setblock 66 151 316 minecraft:spruce_planks
setblock 67 151 276 minecraft:spruce_planks
setblock 73 151 316 minecraft:spruce_planks
setblock 74 151 276 minecraft:spruce_planks
setblock 76 151 276 minecraft:iron_bars
setblock 80 151 316 minecraft:spruce_planks
fill 80 151 317 83 151 317 minecraft:blue_concrete
setblock 81 151 276 minecraft:spruce_planks
fill 83 151 312 85 162 312 minecraft:spruce_log
setblock 84 151 317 minecraft:light_blue_wool
setblock 87 151 316 minecraft:spruce_planks
setblock 88 151 276 minecraft:spruce_planks
setblock 88 151 283 minecraft:spruce_planks
setblock 88 151 290 minecraft:spruce_planks
setblock 88 151 297 minecraft:spruce_planks
setblock 88 151 304 minecraft:spruce_planks
setblock 88 151 311 minecraft:spruce_planks
fill 89 151 296 89 184 297 minecraft:blue_concrete
setblock 89 151 298 minecraft:light_blue_wool
fill 89 151 299 89 190 299 minecraft:blue_concrete
fill 47 152 281 47 193 281 minecraft:blue_concrete
fill 47 152 305 47 179 305 minecraft:blue_concrete
setblock 47 152 306 minecraft:white_wool
fill 47 152 307 47 152 308 minecraft:blue_concrete
setblock 48 152 279 minecraft:spruce_planks
setblock 48 152 286 minecraft:spruce_planks
setblock 48 152 293 minecraft:spruce_planks
setblock 48 152 300 minecraft:spruce_planks
setblock 48 152 307 minecraft:spruce_planks
setblock 48 152 314 minecraft:spruce_planks
setblock 52 152 276 minecraft:spruce_planks
fill 52 152 293 52 154 293 minecraft:dark_oak_planks
fill 52 152 296 52 154 296 minecraft:dark_oak_planks
fill 53 152 292 53 154 292 minecraft:dark_oak_planks
fill 53 152 297 53 154 297 minecraft:dark_oak_planks
setblock 53 152 316 minecraft:spruce_planks
fill 54 152 317 54 193 317 minecraft:blue_concrete
fill 56 152 292 56 154 292 minecraft:dark_oak_planks
fill 57 152 293 57 154 293 minecraft:dark_oak_planks
fill 57 152 297 57 154 297 minecraft:dark_oak_planks
setblock 59 152 276 minecraft:spruce_planks
fill 60 152 275 60 194 275 minecraft:blue_concrete
setblock 60 152 316 minecraft:spruce_planks
setblock 66 152 276 minecraft:spruce_planks
setblock 67 152 316 minecraft:spruce_planks
setblock 70 152 275 minecraft:white_wool
setblock 73 152 276 minecraft:spruce_planks
setblock 74 152 316 minecraft:spruce_planks
setblock 80 152 276 minecraft:spruce_planks
setblock 80 152 317 minecraft:white_wool
setblock 81 152 316 minecraft:spruce_planks
fill 81 152 317 84 179 317 minecraft:blue_concrete
setblock 87 152 276 minecraft:spruce_planks
setblock 88 152 282 minecraft:spruce_planks
setblock 88 152 289 minecraft:spruce_planks
setblock 88 152 296 minecraft:spruce_planks
setblock 88 152 303 minecraft:spruce_planks
setblock 88 152 310 minecraft:spruce_planks
setblock 88 152 316 minecraft:spruce_planks
setblock 89 152 284 minecraft:white_wool
fill 89 152 298 89 171 298 minecraft:blue_concrete
fill 47 153 306 47 193 306 minecraft:blue_concrete
setblock 47 153 307 minecraft:light_blue_wool
fill 47 153 308 47 174 308 minecraft:blue_concrete
fill 47 153 314 47 193 314 minecraft:blue_concrete
setblock 47 153 315 minecraft:light_blue_wool
fill 47 153 316 47 193 317 minecraft:blue_concrete
setblock 48 153 280 minecraft:spruce_planks
setblock 48 153 287 minecraft:spruce_planks
setblock 48 153 294 minecraft:spruce_planks
setblock 48 153 301 minecraft:spruce_planks
setblock 48 153 308 minecraft:spruce_planks
setblock 48 153 315 minecraft:spruce_planks
setblock 50 153 278 minecraft:light[level=15]
setblock 50 153 285 minecraft:light[level=12]
setblock 50 153 286 minecraft:light[level=15]
setblock 50 153 292 minecraft:light[level=12]
setblock 50 153 294 minecraft:light[level=15]
setblock 50 153 299 minecraft:light[level=12]
setblock 50 153 302 minecraft:light[level=15]
setblock 50 153 306 minecraft:light[level=12]
setblock 50 153 310 minecraft:light[level=15]
setblock 50 153 313 minecraft:light[level=12]
setblock 51 153 276 minecraft:spruce_planks
fill 51 153 294 51 154 295 minecraft:dark_oak_planks
fill 52 153 292 52 154 292 minecraft:dark_oak_planks
fill 52 153 297 52 154 297 minecraft:dark_oak_planks
fill 53 153 285 53 153 286 minecraft:white_concrete
fill 53 153 298 56 154 298 minecraft:dark_oak_planks
fill 54 153 291 55 154 291 minecraft:dark_oak_planks
setblock 54 153 316 minecraft:spruce_planks
setblock 57 153 278 minecraft:light[level=12]
setblock 57 153 285 minecraft:light[level=12]
fill 57 153 292 57 154 292 minecraft:dark_oak_planks
setblock 57 153 299 minecraft:light[level=12]
setblock 57 153 306 minecraft:light[level=12]
setblock 57 153 313 minecraft:light[level=12]
setblock 58 153 276 minecraft:spruce_planks
setblock 58 153 278 minecraft:light[level=15]
setblock 58 153 286 minecraft:light[level=15]
fill 58 153 293 58 154 296 minecraft:dark_oak_planks
setblock 58 153 302 minecraft:light[level=15]
setblock 58 153 310 minecraft:light[level=15]
fill 59 153 310 65 153 315 minecraft:dark_oak_planks
setblock 61 153 316 minecraft:spruce_planks
setblock 64 153 278 minecraft:light[level=12]
setblock 64 153 285 minecraft:light[level=12]
setblock 64 153 299 minecraft:light[level=12]
setblock 64 153 306 minecraft:light[level=12]
setblock 65 153 276 minecraft:spruce_planks
setblock 66 153 278 minecraft:light[level=15]
setblock 66 153 286 minecraft:light[level=15]
setblock 66 153 294 minecraft:light[level=15]
setblock 66 153 302 minecraft:light[level=15]
setblock 66 153 310 minecraft:light[level=15]
setblock 68 153 316 minecraft:spruce_planks
fill 70 153 275 70 171 275 minecraft:blue_concrete
setblock 71 153 278 minecraft:light[level=12]
setblock 71 153 285 minecraft:light[level=12]
setblock 71 153 292 minecraft:light[level=12]
setblock 71 153 299 minecraft:light[level=12]
setblock 71 153 306 minecraft:light[level=12]
setblock 71 153 313 minecraft:light[level=12]
setblock 72 153 276 minecraft:spruce_planks
setblock 74 153 278 minecraft:light[level=15]
setblock 74 153 286 minecraft:light[level=15]
setblock 74 153 294 minecraft:light[level=15]
setblock 74 153 302 minecraft:light[level=15]
setblock 74 153 310 minecraft:light[level=15]
setblock 75 153 316 minecraft:spruce_planks
setblock 78 153 278 minecraft:light[level=12]
setblock 78 153 285 minecraft:light[level=12]
setblock 78 153 292 minecraft:light[level=12]
setblock 78 153 299 minecraft:light[level=12]
setblock 78 153 306 minecraft:light[level=12]
setblock 78 153 313 minecraft:light[level=12]
setblock 79 153 276 minecraft:spruce_planks
fill 80 153 317 80 168 317 minecraft:blue_concrete
setblock 82 153 278 minecraft:light[level=15]
setblock 82 153 286 minecraft:light[level=15]
setblock 82 153 294 minecraft:light[level=15]
setblock 82 153 302 minecraft:light[level=15]
setblock 82 153 310 minecraft:light[level=15]
setblock 82 153 316 minecraft:spruce_planks
setblock 85 153 278 minecraft:light[level=12]
setblock 85 153 285 minecraft:light[level=12]
setblock 85 153 292 minecraft:light[level=12]
setblock 85 153 299 minecraft:light[level=12]
setblock 85 153 306 minecraft:light[level=12]
setblock 85 153 313 minecraft:light[level=12]
setblock 86 153 276 minecraft:spruce_planks
setblock 88 153 281 minecraft:spruce_planks
setblock 88 153 288 minecraft:spruce_planks
setblock 88 153 295 minecraft:spruce_planks
setblock 88 153 302 minecraft:spruce_planks
setblock 88 153 309 minecraft:spruce_planks
fill 89 153 284 89 189 285 minecraft:blue_concrete
setblock 89 153 286 minecraft:white_wool
fill 47 154 307 47 157 307 minecraft:blue_concrete
fill 47 154 315 47 171 315 minecraft:blue_concrete
setblock 51 154 293 minecraft:dark_oak_planks
setblock 51 154 296 minecraft:dark_oak_planks
setblock 53 154 291 minecraft:dark_oak_planks
setblock 56 154 291 minecraft:dark_oak_planks
setblock 57 154 298 minecraft:dark_oak_planks
setblock 58 154 292 minecraft:dark_oak_planks
setblock 58 154 297 minecraft:dark_oak_planks
fill 59 154 310 65 154 315 minecraft:spruce_planks
fill 74 154 277 74 157 277 minecraft:white_wool
fill 89 154 286 89 193 286 minecraft:blue_concrete
setblock 48 155 282 minecraft:spruce_planks
setblock 48 155 289 minecraft:spruce_planks
setblock 48 155 296 minecraft:spruce_planks
setblock 48 155 303 minecraft:spruce_planks
setblock 48 155 310 minecraft:spruce_planks
setblock 49 155 276 minecraft:spruce_planks
setblock 49 155 316 minecraft:spruce_planks
setblock 51 155 275 minecraft:white_wool
fill 53 155 294 53 156 294 minecraft:spruce_planks
fill 55 155 296 55 157 296 minecraft:spruce_planks
setblock 56 155 276 minecraft:spruce_planks
fill 56 155 293 56 157 293 minecraft:spruce_planks
setblock 56 155 316 minecraft:spruce_planks
fill 59 155 310 65 155 310 minecraft:dark_oak_planks
fill 61 155 316 63 158 316 minecraft:shroomlight
setblock 63 155 276 minecraft:spruce_planks
setblock 70 155 276 minecraft:spruce_planks
setblock 70 155 316 minecraft:spruce_planks
fill 72 155 277 73 157 277 minecraft:white_wool
setblock 75 155 275 minecraft:light_blue_wool
fill 75 155 277 76 157 277 minecraft:white_wool
setblock 76 155 275 minecraft:white_wool
setblock 77 155 276 minecraft:spruce_planks
setblock 77 155 316 minecraft:spruce_planks
setblock 84 155 276 minecraft:spruce_planks
setblock 84 155 316 minecraft:spruce_planks
setblock 88 155 279 minecraft:spruce_planks
setblock 88 155 286 minecraft:spruce_planks
setblock 88 155 293 minecraft:spruce_planks
setblock 88 155 300 minecraft:spruce_planks
setblock 88 155 307 minecraft:spruce_planks
setblock 88 155 314 minecraft:spruce_planks
setblock 48 156 276 minecraft:spruce_planks
setblock 48 156 283 minecraft:spruce_planks
setblock 48 156 290 minecraft:spruce_planks
fill 48 156 291 50 156 291 minecraft:iron_bars
setblock 48 156 297 minecraft:spruce_planks
setblock 48 156 304 minecraft:spruce_planks
setblock 48 156 311 minecraft:spruce_planks
setblock 50 156 316 minecraft:spruce_planks
fill 51 156 275 51 193 275 minecraft:blue_concrete
setblock 55 156 276 minecraft:spruce_planks
setblock 57 156 316 minecraft:spruce_planks
setblock 59 156 310 minecraft:spruce_planks
setblock 62 156 276 minecraft:spruce_planks
setblock 62 156 310 minecraft:spruce_planks
setblock 64 156 316 minecraft:spruce_planks
setblock 65 156 310 minecraft:spruce_planks
setblock 69 156 276 minecraft:spruce_planks
setblock 71 156 316 minecraft:spruce_planks
fill 75 156 275 76 185 275 minecraft:blue_concrete
setblock 76 156 276 minecraft:spruce_planks
setblock 78 156 316 minecraft:spruce_planks
setblock 83 156 276 minecraft:spruce_planks
setblock 85 156 316 minecraft:spruce_planks
setblock 88 156 278 minecraft:spruce_planks
setblock 88 156 285 minecraft:spruce_planks
setblock 88 156 292 minecraft:spruce_planks
setblock 88 156 299 minecraft:spruce_planks
setblock 88 156 306 minecraft:spruce_planks
setblock 88 156 313 minecraft:spruce_planks
setblock 48 157 277 minecraft:spruce_planks
setblock 48 157 284 minecraft:spruce_planks
setblock 48 157 291 minecraft:spruce_planks
setblock 48 157 298 minecraft:spruce_planks
setblock 48 157 305 minecraft:spruce_planks
setblock 48 157 312 minecraft:spruce_planks
fill 49 157 291 50 157 291 minecraft:iron_bars
setblock 51 157 316 minecraft:spruce_planks
setblock 54 157 276 minecraft:spruce_planks
setblock 58 157 316 minecraft:spruce_planks
setblock 61 157 276 minecraft:spruce_planks
setblock 65 157 316 minecraft:spruce_planks
setblock 68 157 276 minecraft:spruce_planks
setblock 72 157 316 minecraft:spruce_planks
setblock 75 157 276 minecraft:spruce_planks
setblock 79 157 316 minecraft:spruce_planks
setblock 82 157 276 minecraft:spruce_planks
setblock 86 157 316 minecraft:spruce_planks
setblock 88 157 277 minecraft:spruce_planks
setblock 88 157 284 minecraft:spruce_planks
setblock 88 157 291 minecraft:spruce_planks
setblock 88 157 298 minecraft:spruce_planks
setblock 88 157 305 minecraft:spruce_planks
setblock 88 157 312 minecraft:spruce_planks
fill 47 158 286 47 176 288 minecraft:blue_concrete
setblock 47 158 289 minecraft:white_wool
fill 47 158 290 47 193 292 minecraft:blue_concrete
setblock 47 158 307 minecraft:white_wool
setblock 65 158 275 minecraft:white_wool
fill 66 158 275 68 168 275 minecraft:blue_concrete
fill 82 158 314 83 158 314 minecraft:white_concrete
fill 89 158 276 89 189 276 minecraft:blue_concrete
setblock 89 158 277 minecraft:light_blue_wool
fill 47 159 289 47 170 289 minecraft:blue_concrete
fill 47 159 307 47 194 307 minecraft:blue_concrete
setblock 50 159 278 minecraft:light[level=12]
setblock 50 159 285 minecraft:light[level=12]
setblock 50 159 292 minecraft:light[level=12]
setblock 50 159 299 minecraft:light[level=12]
setblock 50 159 306 minecraft:light[level=12]
setblock 50 159 313 minecraft:light[level=12]
setblock 57 159 278 minecraft:light[level=12]
setblock 57 159 285 minecraft:light[level=12]
setblock 57 159 292 minecraft:light[level=12]
setblock 57 159 299 minecraft:light[level=12]
setblock 57 159 306 minecraft:light[level=12]
setblock 57 159 313 minecraft:light[level=12]
setblock 64 159 278 minecraft:light[level=12]
setblock 64 159 285 minecraft:light[level=12]
setblock 64 159 299 minecraft:light[level=12]
setblock 64 159 306 minecraft:light[level=12]
setblock 64 159 313 minecraft:light[level=12]
fill 65 159 275 65 190 275 minecraft:blue_concrete
setblock 71 159 278 minecraft:light[level=12]
setblock 71 159 285 minecraft:light[level=12]
setblock 71 159 292 minecraft:light[level=12]
setblock 71 159 299 minecraft:light[level=12]
setblock 71 159 306 minecraft:light[level=12]
setblock 71 159 313 minecraft:light[level=12]
setblock 78 159 278 minecraft:light[level=12]
setblock 78 159 285 minecraft:light[level=12]
setblock 78 159 292 minecraft:light[level=12]
setblock 78 159 299 minecraft:light[level=12]
setblock 78 159 306 minecraft:light[level=12]
setblock 78 159 313 minecraft:light[level=12]
fill 81 159 275 81 193 275 minecraft:blue_concrete
setblock 82 159 275 minecraft:white_wool
setblock 85 159 278 minecraft:light[level=12]
setblock 85 159 285 minecraft:light[level=12]
setblock 85 159 292 minecraft:light[level=12]
setblock 85 159 299 minecraft:light[level=12]
setblock 85 159 306 minecraft:light[level=12]
setblock 85 159 313 minecraft:light[level=12]
fill 89 159 277 89 190 277 minecraft:blue_concrete
setblock 71 160 317 minecraft:light_blue_wool
fill 82 160 275 82 193 275 minecraft:blue_concrete
fill 47 161 282 47 173 283 minecraft:blue_concrete
setblock 47 161 284 minecraft:white_wool
setblock 50 161 278 minecraft:light[level=15]
setblock 50 161 286 minecraft:light[level=15]
setblock 50 161 294 minecraft:light[level=15]
setblock 50 161 302 minecraft:light[level=15]
setblock 50 161 310 minecraft:light[level=15]
setblock 58 161 278 minecraft:light[level=15]
setblock 58 161 286 minecraft:light[level=15]
setblock 58 161 294 minecraft:light[level=15]
setblock 58 161 302 minecraft:light[level=15]
setblock 58 161 310 minecraft:light[level=15]
fill 63 161 317 67 189 317 minecraft:blue_concrete
setblock 66 161 278 minecraft:light[level=15]
setblock 66 161 286 minecraft:light[level=15]
setblock 66 161 294 minecraft:light[level=15]
setblock 66 161 302 minecraft:light[level=15]
setblock 66 161 310 minecraft:light[level=15]
setblock 68 161 317 minecraft:white_wool
fill 71 161 317 71 187 317 minecraft:blue_concrete
setblock 74 161 278 minecraft:light[level=15]
setblock 74 161 286 minecraft:light[level=15]
setblock 74 161 294 minecraft:light[level=15]
setblock 74 161 302 minecraft:light[level=15]
setblock 74 161 310 minecraft:light[level=15]
setblock 82 161 278 minecraft:light[level=15]
setblock 82 161 286 minecraft:light[level=15]
setblock 82 161 294 minecraft:light[level=15]
setblock 82 161 302 minecraft:light[level=15]
setblock 82 161 310 minecraft:light[level=15]
fill 89 161 311 89 167 315 minecraft:blue_concrete
setblock 89 161 316 minecraft:white_wool
fill 47 162 284 47 189 284 minecraft:blue_concrete
fill 68 162 317 68 190 317 minecraft:blue_concrete
setblock 89 162 293 minecraft:white_wool
fill 89 162 294 89 193 294 minecraft:blue_concrete
fill 89 162 316 89 180 316 minecraft:blue_concrete
fill 48 163 276 50 164 316 minecraft:spruce_planks
fill 51 163 276 51 164 316 minecraft:dark_oak_planks
fill 52 163 276 54 164 316 minecraft:spruce_planks
fill 55 163 276 55 164 316 minecraft:dark_oak_planks
fill 56 163 276 58 164 316 minecraft:spruce_planks
fill 59 163 276 59 164 316 minecraft:dark_oak_planks
fill 60 163 276 61 163 316 minecraft:spruce_planks
fill 62 163 276 62 163 291 minecraft:spruce_planks
fill 62 163 293 62 163 316 minecraft:spruce_planks
fill 63 163 276 63 163 289 minecraft:dark_oak_planks
fill 63 163 295 63 163 316 minecraft:dark_oak_planks
fill 64 163 276 64 163 289 minecraft:spruce_planks
fill 64 163 295 64 163 316 minecraft:spruce_planks
fill 65 163 276 66 163 288 minecraft:spruce_planks
fill 65 163 296 66 163 316 minecraft:spruce_planks
setblock 66 163 289 minecraft:spruce_planks
setblock 66 163 295 minecraft:spruce_planks
fill 67 163 276 67 163 289 minecraft:dark_oak_planks
fill 67 163 295 67 163 316 minecraft:dark_oak_planks
fill 68 163 276 70 163 291 minecraft:spruce_planks
fill 68 163 293 70 163 316 minecraft:spruce_planks
fill 69 163 292 70 163 292 minecraft:spruce_planks
fill 71 163 276 71 164 316 minecraft:dark_oak_planks
fill 72 163 276 74 164 316 minecraft:spruce_planks
fill 75 163 276 75 164 316 minecraft:dark_oak_planks
fill 76 163 276 78 164 316 minecraft:spruce_planks
fill 79 163 276 79 164 316 minecraft:dark_oak_planks
fill 80 163 276 82 164 316 minecraft:spruce_planks
fill 83 163 276 83 164 316 minecraft:dark_oak_planks
fill 84 163 276 86 164 316 minecraft:spruce_planks
fill 87 163 276 87 164 316 minecraft:dark_oak_planks
fill 88 163 276 88 164 316 minecraft:spruce_planks
fill 89 163 293 89 193 293 minecraft:blue_concrete
fill 60 164 276 60 164 316 minecraft:spruce_planks
fill 61 164 276 61 164 290 minecraft:spruce_planks
fill 61 164 291 61 164 293 minecraft:gold_block
fill 61 164 294 61 164 316 minecraft:spruce_planks
fill 62 164 276 62 164 288 minecraft:spruce_planks
fill 62 164 289 62 164 291 minecraft:gold_block
fill 62 164 293 62 164 295 minecraft:gold_block
fill 62 164 296 62 164 316 minecraft:spruce_planks
fill 63 164 276 63 164 288 minecraft:dark_oak_planks
fill 63 164 289 64 164 289 minecraft:gold_block
fill 63 164 295 64 164 295 minecraft:gold_block
fill 63 164 296 63 164 316 minecraft:dark_oak_planks
fill 64 164 276 66 164 287 minecraft:spruce_planks
fill 64 164 288 66 164 288 minecraft:gold_block
fill 64 164 296 66 164 296 minecraft:gold_block
fill 64 164 297 66 164 316 minecraft:spruce_planks
fill 66 164 289 68 164 289 minecraft:gold_block
fill 66 164 295 68 164 295 minecraft:gold_block
fill 67 164 276 67 164 288 minecraft:dark_oak_planks
fill 67 164 296 67 164 316 minecraft:dark_oak_planks
fill 68 164 276 70 164 288 minecraft:spruce_planks
fill 68 164 290 68 164 291 minecraft:gold_block
fill 68 164 293 68 164 294 minecraft:gold_block
fill 68 164 296 70 164 316 minecraft:spruce_planks
fill 69 164 289 70 164 290 minecraft:spruce_planks
fill 69 164 291 69 164 293 minecraft:gold_block
fill 69 164 294 70 164 295 minecraft:spruce_planks
fill 70 164 291 70 164 293 minecraft:spruce_planks
setblock 50 165 278 minecraft:light[level=12]
setblock 50 165 285 minecraft:light[level=12]
setblock 50 165 292 minecraft:light[level=12]
setblock 50 165 299 minecraft:light[level=12]
setblock 50 165 306 minecraft:light[level=12]
setblock 50 165 313 minecraft:light[level=12]
fill 51 165 280 51 166 280 minecraft:spruce_log
fill 52 165 277 53 165 281 minecraft:black_concrete
fill 52 165 310 53 165 314 minecraft:black_concrete
setblock 57 165 278 minecraft:light[level=12]
setblock 57 165 285 minecraft:light[level=12]
setblock 57 165 292 minecraft:light[level=12]
setblock 57 165 299 minecraft:light[level=12]
setblock 57 165 306 minecraft:light[level=12]
setblock 57 165 313 minecraft:light[level=12]
fill 58 165 277 59 165 281 minecraft:black_concrete
fill 58 165 310 59 165 314 minecraft:black_concrete
fill 64 165 277 65 165 281 minecraft:black_concrete
setblock 64 165 285 minecraft:light[level=12]
setblock 64 165 299 minecraft:light[level=12]
setblock 64 165 306 minecraft:light[level=12]
fill 64 165 310 65 165 314 minecraft:black_concrete
fill 70 165 277 71 165 281 minecraft:black_concrete
fill 70 165 310 71 165 314 minecraft:black_concrete
setblock 71 165 285 minecraft:light[level=12]
setblock 71 165 292 minecraft:light[level=12]
setblock 71 165 299 minecraft:light[level=12]
setblock 71 165 306 minecraft:light[level=12]
fill 76 165 277 77 165 281 minecraft:black_concrete
fill 76 165 310 77 165 314 minecraft:black_concrete
setblock 78 165 278 minecraft:light[level=12]
setblock 78 165 285 minecraft:light[level=12]
setblock 78 165 292 minecraft:light[level=12]
setblock 78 165 299 minecraft:light[level=12]
setblock 78 165 306 minecraft:light[level=12]
setblock 78 165 313 minecraft:light[level=12]
fill 82 165 277 83 165 281 minecraft:black_concrete
fill 82 165 310 83 165 314 minecraft:black_concrete
fill 84 165 311 84 166 313 minecraft:spruce_log
setblock 85 165 278 minecraft:light[level=12]
setblock 85 165 285 minecraft:light[level=12]
setblock 85 165 292 minecraft:light[level=12]
setblock 85 165 299 minecraft:light[level=12]
setblock 85 165 306 minecraft:light[level=12]
fill 85 165 312 85 166 312 minecraft:spruce_log
setblock 85 165 313 minecraft:light[level=12]
setblock 89 165 287 minecraft:light_blue_wool
fill 52 166 279 52 166 281 minecraft:spruce_log
setblock 53 166 275 minecraft:white_wool
setblock 53 166 280 minecraft:spruce_log
fill 54 166 275 56 190 275 minecraft:blue_concrete
setblock 83 166 312 minecraft:spruce_log
fill 89 166 287 89 182 287 minecraft:blue_concrete
fill 48 167 280 56 173 280 minecraft:white_wool
fill 52 167 279 52 277 279 minecraft:spruce_log
fill 52 167 281 52 277 281 minecraft:spruce_log
fill 53 167 275 53 182 275 minecraft:blue_concrete
fill 80 167 312 88 168 312 minecraft:white_wool
fill 84 167 311 84 277 311 minecraft:spruce_log
fill 84 167 313 84 277 313 minecraft:spruce_log
fill 89 167 302 89 193 302 minecraft:blue_concrete
setblock 89 167 303 minecraft:white_wool
fill 48 168 281 48 222 281 minecraft:spruce_planks
fill 48 168 288 48 222 288 minecraft:spruce_planks
fill 48 168 295 48 222 295 minecraft:spruce_planks
fill 48 168 302 48 222 302 minecraft:spruce_planks
fill 48 168 309 48 222 309 minecraft:spruce_planks
fill 48 168 316 48 222 316 minecraft:spruce_planks
fill 50 168 276 50 222 276 minecraft:spruce_planks
fill 50 168 310 51 168 310 minecraft:dark_oak_planks
fill 50 168 311 53 222 312 minecraft:spruce_planks
setblock 50 168 313 minecraft:dark_oak_planks
fill 51 168 313 52 222 313 minecraft:spruce_planks
fill 51 168 314 52 168 314 minecraft:dark_oak_planks
fill 52 168 310 52 222 310 minecraft:spruce_planks
setblock 53 168 310 minecraft:dark_oak_planks
setblock 53 168 313 minecraft:dark_oak_planks
fill 54 168 311 54 168 312 minecraft:dark_oak_planks
fill 55 168 316 55 222 316 minecraft:spruce_planks
fill 57 168 276 57 222 276 minecraft:spruce_planks
fill 62 168 316 62 222 316 minecraft:spruce_planks
fill 64 168 276 64 222 276 minecraft:spruce_planks
fill 69 168 310 79 168 316 minecraft:spruce_planks
fill 71 168 276 71 222 276 minecraft:spruce_planks
fill 71 168 277 77 169 277 minecraft:iron_bars
fill 78 168 276 78 222 276 minecraft:spruce_planks
fill 80 168 310 81 168 311 minecraft:spruce_planks
fill 80 168 313 81 168 316 minecraft:spruce_planks
fill 82 168 290 82 169 290 minecraft:iron_bars
setblock 82 168 311 minecraft:dark_oak_planks
fill 83 168 310 86 168 310 minecraft:dark_oak_planks
fill 83 168 311 83 222 311 minecraft:spruce_planks
fill 83 168 313 83 168 314 minecraft:dark_oak_planks
fill 83 168 316 83 222 316 minecraft:spruce_planks
fill 84 168 314 85 168 314 minecraft:dark_oak_planks
fill 85 168 276 85 222 276 minecraft:spruce_planks
fill 85 168 292 85 169 292 minecraft:green_terracotta
fill 85 168 311 85 222 311 minecraft:spruce_planks
fill 85 168 313 85 222 313 minecraft:spruce_planks
fill 86 168 283 86 181 283 minecraft:white_wool
setblock 86 168 311 minecraft:dark_oak_planks
setblock 86 168 313 minecraft:dark_oak_planks
fill 88 168 280 88 222 280 minecraft:spruce_planks
fill 88 168 287 88 222 287 minecraft:spruce_planks
fill 88 168 294 88 222 294 minecraft:spruce_planks
fill 88 168 301 88 222 301 minecraft:spruce_planks
fill 88 168 308 88 222 308 minecraft:spruce_planks
fill 88 168 315 88 222 315 minecraft:spruce_planks
fill 89 168 303 89 192 303 minecraft:blue_concrete
fill 89 168 311 89 175 312 minecraft:blue_concrete
setblock 89 168 313 minecraft:white_wool
fill 89 168 314 89 193 315 minecraft:blue_concrete
setblock 47 169 293 minecraft:white_wool
fill 48 169 282 48 170 282 minecraft:spruce_planks
fill 48 169 289 48 170 289 minecraft:spruce_planks
fill 48 169 296 48 170 296 minecraft:spruce_planks
fill 48 169 303 48 170 303 minecraft:spruce_planks
fill 48 169 310 48 170 310 minecraft:spruce_planks
fill 49 169 276 49 170 276 minecraft:spruce_planks
fill 49 169 316 49 170 316 minecraft:spruce_planks
setblock 50 169 278 minecraft:light[level=15]
setblock 50 169 286 minecraft:light[level=15]
setblock 50 169 294 minecraft:light[level=15]
setblock 50 169 302 minecraft:light[level=15]
setblock 50 169 310 minecraft:light[level=15]
fill 56 169 276 56 170 276 minecraft:spruce_planks
fill 56 169 316 56 170 316 minecraft:spruce_planks
fill 57 169 275 58 191 275 minecraft:blue_concrete
setblock 58 169 278 minecraft:light[level=15]
setblock 58 169 286 minecraft:light[level=15]
setblock 58 169 294 minecraft:light[level=15]
setblock 58 169 302 minecraft:light[level=15]
setblock 58 169 310 minecraft:light[level=15]
setblock 59 169 275 minecraft:white_wool
fill 59 169 277 59 177 277 minecraft:white_wool
fill 63 169 276 63 170 276 minecraft:spruce_planks
fill 63 169 316 63 170 316 minecraft:spruce_planks
fill 66 169 275 67 169 275 minecraft:blue_concrete
setblock 66 169 278 minecraft:light[level=15]
setblock 66 169 286 minecraft:light[level=15]
setblock 66 169 294 minecraft:light[level=15]
setblock 66 169 302 minecraft:light[level=15]
setblock 66 169 310 minecraft:light[level=15]
setblock 68 169 275 minecraft:light_blue_wool
fill 69 169 310 69 187 310 minecraft:spruce_planks
setblock 69 169 311 minecraft:shroomlight
fill 69 169 312 69 187 312 minecraft:spruce_planks
setblock 69 169 313 minecraft:shroomlight
fill 69 169 314 69 187 314 minecraft:spruce_planks
setblock 69 169 315 minecraft:shroomlight
fill 69 169 316 69 222 316 minecraft:spruce_planks
fill 70 169 276 70 170 276 minecraft:spruce_planks
setblock 70 169 310 minecraft:shroomlight
fill 70 169 311 70 187 311 minecraft:spruce_planks
setblock 70 169 312 minecraft:shroomlight
fill 70 169 313 70 187 313 minecraft:spruce_planks
setblock 70 169 314 minecraft:shroomlight
fill 70 169 315 70 187 315 minecraft:spruce_planks
setblock 70 169 316 minecraft:shroomlight
fill 71 169 310 71 187 310 minecraft:spruce_planks
setblock 71 169 311 minecraft:shroomlight
fill 71 169 312 71 187 312 minecraft:spruce_planks
setblock 71 169 313 minecraft:shroomlight
fill 71 169 314 71 187 314 minecraft:spruce_planks
setblock 71 169 315 minecraft:shroomlight
fill 71 169 316 71 187 316 minecraft:spruce_planks
setblock 72 169 310 minecraft:shroomlight
fill 72 169 311 72 187 311 minecraft:spruce_planks
setblock 72 169 312 minecraft:shroomlight
fill 72 169 313 72 187 313 minecraft:spruce_planks
setblock 72 169 314 minecraft:shroomlight
fill 72 169 315 72 187 315 minecraft:spruce_planks
setblock 72 169 316 minecraft:shroomlight
fill 73 169 310 73 187 310 minecraft:spruce_planks
setblock 73 169 311 minecraft:shroomlight
fill 73 169 312 73 187 312 minecraft:spruce_planks
setblock 73 169 313 minecraft:shroomlight
fill 73 169 314 73 187 314 minecraft:spruce_planks
setblock 73 169 315 minecraft:shroomlight
fill 73 169 316 73 187 316 minecraft:spruce_planks
setblock 74 169 278 minecraft:light[level=15]
setblock 74 169 286 minecraft:light[level=15]
setblock 74 169 294 minecraft:light[level=15]
setblock 74 169 302 minecraft:light[level=15]
setblock 74 169 310 minecraft:shroomlight
fill 74 169 311 74 187 311 minecraft:spruce_planks
setblock 74 169 312 minecraft:shroomlight
fill 74 169 313 74 187 313 minecraft:spruce_planks
setblock 74 169 314 minecraft:shroomlight
fill 74 169 315 74 187 315 minecraft:spruce_planks
setblock 74 169 316 minecraft:shroomlight
fill 75 169 310 75 187 310 minecraft:spruce_planks
setblock 75 169 311 minecraft:shroomlight
fill 75 169 312 75 187 312 minecraft:spruce_planks
setblock 75 169 313 minecraft:shroomlight
fill 75 169 314 75 187 314 minecraft:spruce_planks
setblock 75 169 315 minecraft:shroomlight
fill 75 169 316 75 188 316 minecraft:spruce_planks
setblock 76 169 310 minecraft:shroomlight
fill 76 169 311 76 187 311 minecraft:spruce_planks
setblock 76 169 312 minecraft:shroomlight
fill 76 169 313 76 187 313 minecraft:spruce_planks
setblock 76 169 314 minecraft:shroomlight
fill 76 169 315 76 187 315 minecraft:spruce_planks
setblock 76 169 316 minecraft:shroomlight
fill 77 169 276 77 170 276 minecraft:spruce_planks
fill 77 169 310 77 187 310 minecraft:spruce_planks
setblock 77 169 311 minecraft:shroomlight
fill 77 169 312 77 187 312 minecraft:spruce_planks
setblock 77 169 313 minecraft:shroomlight
fill 77 169 314 77 187 314 minecraft:spruce_planks
setblock 77 169 315 minecraft:shroomlight
fill 77 169 316 77 187 316 minecraft:spruce_planks
setblock 78 169 310 minecraft:shroomlight
fill 78 169 311 78 187 311 minecraft:spruce_planks
setblock 78 169 312 minecraft:shroomlight
fill 78 169 313 78 187 313 minecraft:spruce_planks
setblock 78 169 314 minecraft:shroomlight
fill 78 169 315 78 187 315 minecraft:spruce_planks
setblock 78 169 316 minecraft:shroomlight
fill 79 169 310 79 187 310 minecraft:spruce_planks
setblock 79 169 311 minecraft:shroomlight
fill 79 169 312 79 187 312 minecraft:spruce_planks
setblock 79 169 313 minecraft:shroomlight
fill 79 169 314 79 187 314 minecraft:spruce_planks
setblock 79 169 315 minecraft:shroomlight
fill 79 169 316 79 187 316 minecraft:spruce_planks
setblock 80 169 310 minecraft:shroomlight
fill 80 169 311 80 187 311 minecraft:spruce_planks
setblock 80 169 312 minecraft:shroomlight
fill 80 169 313 80 187 313 minecraft:spruce_planks
setblock 80 169 314 minecraft:shroomlight
fill 80 169 315 80 187 315 minecraft:spruce_planks
setblock 80 169 316 minecraft:shroomlight
setblock 80 169 317 minecraft:white_wool
fill 81 169 310 81 187 310 minecraft:spruce_planks
setblock 81 169 311 minecraft:shroomlight
fill 81 169 312 88 173 312 minecraft:white_wool
setblock 81 169 313 minecraft:shroomlight
fill 81 169 314 81 187 314 minecraft:spruce_planks
setblock 81 169 315 minecraft:shroomlight
fill 81 169 316 81 187 316 minecraft:spruce_planks
setblock 82 169 278 minecraft:light[level=15]
setblock 82 169 286 minecraft:light[level=15]
setblock 82 169 294 minecraft:light[level=15]
setblock 82 169 302 minecraft:light[level=15]
setblock 82 169 310 minecraft:light[level=15]
fill 84 169 276 84 170 276 minecraft:spruce_planks
fill 84 169 316 84 170 316 minecraft:spruce_planks
fill 86 169 281 86 181 282 minecraft:white_wool
fill 86 169 284 86 181 285 minecraft:white_wool
fill 88 169 279 88 170 279 minecraft:spruce_planks
fill 88 169 286 88 170 286 minecraft:spruce_planks
fill 88 169 293 88 170 293 minecraft:spruce_planks
fill 88 169 300 88 170 300 minecraft:spruce_planks
fill 88 169 307 88 170 307 minecraft:spruce_planks
fill 88 169 314 88 170 314 minecraft:spruce_planks
fill 89 169 304 89 193 304 minecraft:blue_concrete
setblock 89 169 305 minecraft:white_wool
fill 89 169 306 89 189 309 minecraft:blue_concrete
fill 89 169 313 89 193 313 minecraft:blue_concrete
fill 47 170 293 47 191 293 minecraft:blue_concrete
fill 48 170 276 48 170 279 minecraft:spruce_planks
fill 48 170 283 48 170 287 minecraft:spruce_planks
fill 48 170 290 48 170 294 minecraft:spruce_planks
fill 48 170 297 48 170 301 minecraft:spruce_planks
fill 48 170 304 48 170 308 minecraft:spruce_planks
fill 48 170 311 48 170 315 minecraft:spruce_planks
fill 50 170 316 54 170 316 minecraft:spruce_planks
fill 51 170 276 55 170 276 minecraft:spruce_planks
fill 57 170 277 58 177 277 minecraft:white_wool
fill 57 170 316 61 170 316 minecraft:spruce_planks
fill 58 170 276 62 170 276 minecraft:spruce_planks
fill 59 170 275 59 193 275 minecraft:blue_concrete
fill 60 170 277 61 177 277 minecraft:white_wool
fill 64 170 316 68 170 316 minecraft:spruce_planks
fill 65 170 276 69 170 276 minecraft:spruce_planks
fill 66 170 275 66 193 275 minecraft:blue_concrete
setblock 67 170 275 minecraft:light_blue_wool
fill 68 170 275 68 183 275 minecraft:blue_concrete
fill 69 170 311 69 171 311 minecraft:spruce_planks
fill 69 170 313 69 171 313 minecraft:spruce_planks
fill 69 170 315 69 171 315 minecraft:spruce_planks
fill 70 170 310 70 171 310 minecraft:spruce_planks
fill 70 170 312 70 171 312 minecraft:spruce_planks
fill 70 170 314 70 171 314 minecraft:spruce_planks
fill 70 170 316 70 171 316 minecraft:spruce_planks
fill 71 170 311 71 171 311 minecraft:spruce_planks
fill 71 170 313 71 171 313 minecraft:spruce_planks
fill 71 170 315 71 171 315 minecraft:spruce_planks
fill 72 170 276 76 170 276 minecraft:spruce_planks
fill 72 170 310 72 171 310 minecraft:spruce_planks
fill 72 170 312 72 171 312 minecraft:spruce_planks
fill 72 170 314 72 171 314 minecraft:spruce_planks
fill 72 170 316 72 171 316 minecraft:spruce_planks
fill 73 170 311 73 171 311 minecraft:spruce_planks
fill 73 170 313 73 171 313 minecraft:spruce_planks
fill 73 170 315 73 171 315 minecraft:spruce_planks
fill 74 170 310 74 171 310 minecraft:spruce_planks
fill 74 170 312 74 171 312 minecraft:spruce_planks
fill 74 170 314 74 171 314 minecraft:spruce_planks
fill 74 170 316 74 171 316 minecraft:spruce_planks
fill 75 170 311 75 171 311 minecraft:spruce_planks
fill 75 170 313 75 171 313 minecraft:spruce_planks
fill 75 170 315 75 171 315 minecraft:spruce_planks
fill 76 170 310 76 171 310 minecraft:spruce_planks
fill 76 170 312 76 171 312 minecraft:spruce_planks
fill 76 170 314 76 171 314 minecraft:spruce_planks
fill 76 170 316 76 171 316 minecraft:spruce_planks
fill 77 170 311 77 171 311 minecraft:spruce_planks
fill 77 170 313 77 171 313 minecraft:spruce_planks
fill 77 170 315 77 171 315 minecraft:spruce_planks
fill 78 170 310 78 171 310 minecraft:spruce_planks
fill 78 170 312 78 171 312 minecraft:spruce_planks
fill 78 170 314 78 171 314 minecraft:spruce_planks
fill 78 170 316 78 171 316 minecraft:spruce_planks
fill 79 170 276 83 170 276 minecraft:spruce_planks
fill 79 170 311 79 171 311 minecraft:spruce_planks
fill 79 170 313 79 171 313 minecraft:spruce_planks
fill 79 170 315 79 171 315 minecraft:spruce_planks
fill 80 170 310 80 171 310 minecraft:spruce_planks
fill 80 170 312 80 171 312 minecraft:white_wool
fill 80 170 314 80 171 314 minecraft:spruce_planks
fill 80 170 316 80 171 316 minecraft:spruce_planks
fill 80 170 317 80 193 317 minecraft:blue_concrete
fill 81 170 311 81 171 311 minecraft:spruce_planks
fill 81 170 313 81 171 313 minecraft:spruce_planks
fill 81 170 315 81 171 315 minecraft:spruce_planks
fill 82 170 287 87 170 293 minecraft:dark_oak_planks
setblock 82 170 316 minecraft:spruce_planks
fill 85 170 316 88 170 316 minecraft:spruce_planks
fill 86 170 276 88 170 276 minecraft:spruce_planks
fill 88 170 277 88 170 278 minecraft:spruce_planks
fill 88 170 281 88 170 285 minecraft:spruce_planks
fill 88 170 288 88 170 292 minecraft:spruce_planks
fill 88 170 295 88 170 299 minecraft:spruce_planks
fill 88 170 302 88 170 306 minecraft:spruce_planks
fill 88 170 309 88 170 311 minecraft:spruce_planks
setblock 88 170 313 minecraft:spruce_planks
setblock 89 170 295 minecraft:white_wool
setblock 89 170 300 minecraft:light_blue_wool
fill 89 170 301 89 193 301 minecraft:blue_concrete
setblock 89 170 305 minecraft:blue_concrete
setblock 47 171 289 minecraft:light_blue_wool
setblock 48 171 277 minecraft:spruce_planks
setblock 48 171 284 minecraft:spruce_planks
setblock 48 171 291 minecraft:spruce_planks
setblock 48 171 298 minecraft:spruce_planks
setblock 48 171 305 minecraft:spruce_planks
setblock 48 171 312 minecraft:spruce_planks
setblock 50 171 278 minecraft:light[level=12]
setblock 50 171 285 minecraft:light[level=12]
setblock 50 171 292 minecraft:light[level=12]
setblock 50 171 299 minecraft:light[level=12]
setblock 50 171 306 minecraft:light[level=12]
setblock 50 171 313 minecraft:light[level=12]
setblock 51 171 316 minecraft:spruce_planks
setblock 54 171 276 minecraft:spruce_planks
setblock 57 171 278 minecraft:light[level=12]
setblock 57 171 285 minecraft:light[level=12]
setblock 57 171 292 minecraft:light[level=12]
setblock 57 171 299 minecraft:light[level=12]
setblock 57 171 306 minecraft:light[level=12]
setblock 57 171 313 minecraft:light[level=12]
setblock 58 171 316 minecraft:spruce_planks
setblock 61 171 276 minecraft:spruce_planks
setblock 64 171 278 minecraft:light[level=12]
setblock 64 171 285 minecraft:light[level=12]
setblock 64 171 299 minecraft:light[level=12]
setblock 64 171 306 minecraft:light[level=12]
setblock 64 171 313 minecraft:light[level=12]
setblock 65 171 316 minecraft:spruce_planks
fill 67 171 275 67 193 275 minecraft:blue_concrete
setblock 68 171 276 minecraft:spruce_planks
setblock 71 171 278 minecraft:light[level=12]
setblock 71 171 285 minecraft:light[level=12]
setblock 71 171 292 minecraft:light[level=12]
setblock 71 171 299 minecraft:light[level=12]
setblock 71 171 306 minecraft:light[level=12]
setblock 75 171 276 minecraft:spruce_planks
setblock 78 171 278 minecraft:light[level=12]
setblock 78 171 285 minecraft:light[level=12]
setblock 78 171 292 minecraft:light[level=12]
setblock 78 171 299 minecraft:light[level=12]
setblock 78 171 306 minecraft:light[level=12]
setblock 82 171 276 minecraft:spruce_planks
fill 82 171 287 87 171 293 minecraft:spruce_planks
setblock 85 171 278 minecraft:light[level=12]
setblock 85 171 285 minecraft:light[level=12]
setblock 85 171 299 minecraft:light[level=12]
setblock 85 171 306 minecraft:light[level=12]
setblock 86 171 316 minecraft:spruce_planks
setblock 88 171 277 minecraft:spruce_planks
setblock 88 171 284 minecraft:spruce_planks
setblock 88 171 291 minecraft:spruce_planks
setblock 88 171 298 minecraft:spruce_planks
setblock 88 171 305 minecraft:spruce_planks
fill 89 171 295 89 193 295 minecraft:blue_concrete
fill 89 171 300 89 190 300 minecraft:blue_concrete
setblock 89 171 305 minecraft:white_wool
fill 47 172 289 47 194 289 minecraft:blue_concrete
setblock 47 172 315 minecraft:white_wool
setblock 48 172 278 minecraft:spruce_planks
setblock 48 172 285 minecraft:spruce_planks
setblock 48 172 292 minecraft:spruce_planks
setblock 48 172 299 minecraft:spruce_planks
setblock 48 172 306 minecraft:spruce_planks
setblock 48 172 313 minecraft:spruce_planks
setblock 52 172 316 minecraft:spruce_planks
setblock 53 172 276 minecraft:spruce_planks
setblock 59 172 316 minecraft:spruce_planks
setblock 60 172 276 minecraft:spruce_planks
setblock 66 172 316 minecraft:spruce_planks
setblock 67 172 276 minecraft:spruce_planks
setblock 69 172 311 minecraft:shroomlight
setblock 69 172 313 minecraft:shroomlight
setblock 69 172 315 minecraft:shroomlight
setblock 70 172 275 minecraft:white_wool
setblock 70 172 310 minecraft:shroomlight
setblock 70 172 312 minecraft:shroomlight
setblock 70 172 314 minecraft:shroomlight
setblock 70 172 316 minecraft:shroomlight
setblock 71 172 311 minecraft:shroomlight
setblock 71 172 313 minecraft:shroomlight
setblock 71 172 315 minecraft:shroomlight
setblock 72 172 310 minecraft:shroomlight
setblock 72 172 312 minecraft:shroomlight
setblock 72 172 314 minecraft:shroomlight
setblock 72 172 316 minecraft:shroomlight
setblock 73 172 311 minecraft:shroomlight
setblock 73 172 313 minecraft:shroomlight
setblock 73 172 315 minecraft:shroomlight
setblock 74 172 276 minecraft:spruce_planks
setblock 74 172 310 minecraft:shroomlight
setblock 74 172 312 minecraft:shroomlight
setblock 74 172 314 minecraft:shroomlight
setblock 74 172 316 minecraft:shroomlight
setblock 75 172 311 minecraft:shroomlight
setblock 75 172 313 minecraft:shroomlight
setblock 75 172 315 minecraft:shroomlight
setblock 76 172 310 minecraft:shroomlight
setblock 76 172 312 minecraft:shroomlight
setblock 76 172 314 minecraft:shroomlight
setblock 76 172 316 minecraft:shroomlight
setblock 77 172 311 minecraft:shroomlight
setblock 77 172 313 minecraft:shroomlight
setblock 77 172 315 minecraft:shroomlight
setblock 78 172 310 minecraft:shroomlight
setblock 78 172 312 minecraft:shroomlight
setblock 78 172 314 minecraft:shroomlight
setblock 78 172 316 minecraft:shroomlight
fill 78 172 317 78 193 317 minecraft:blue_concrete
setblock 79 172 311 minecraft:shroomlight
setblock 79 172 313 minecraft:shroomlight
setblock 79 172 315 minecraft:shroomlight
setblock 79 172 317 minecraft:white_wool
setblock 80 172 310 minecraft:shroomlight
setblock 80 172 312 minecraft:shroomlight
setblock 80 172 314 minecraft:shroomlight
setblock 80 172 316 minecraft:shroomlight
setblock 81 172 276 minecraft:spruce_planks
setblock 81 172 311 minecraft:shroomlight
setblock 81 172 313 minecraft:shroomlight
setblock 81 172 315 minecraft:shroomlight
fill 82 172 287 82 172 293 minecraft:dark_oak_planks
setblock 85 172 292 minecraft:green_terracotta
setblock 87 172 316 minecraft:spruce_planks
setblock 88 172 276 minecraft:spruce_planks
setblock 88 172 283 minecraft:spruce_planks
fill 88 172 289 88 175 291 minecraft:shroomlight
setblock 88 172 297 minecraft:spruce_planks
setblock 88 172 304 minecraft:spruce_planks
setblock 88 172 311 minecraft:spruce_planks
setblock 89 172 298 minecraft:white_wool
fill 89 172 305 89 193 305 minecraft:blue_concrete
setblock 47 173 277 minecraft:white_wool
setblock 47 173 315 minecraft:light_blue_wool
setblock 48 173 279 minecraft:spruce_planks
setblock 48 173 286 minecraft:spruce_planks
setblock 48 173 293 minecraft:spruce_planks
setblock 48 173 300 minecraft:spruce_planks
setblock 48 173 307 minecraft:spruce_planks
setblock 48 173 314 minecraft:spruce_planks
setblock 52 173 276 minecraft:spruce_planks
setblock 53 173 316 minecraft:spruce_planks
setblock 59 173 276 minecraft:spruce_planks
setblock 60 173 316 minecraft:spruce_planks
setblock 66 173 276 minecraft:spruce_planks
setblock 67 173 316 minecraft:spruce_planks
fill 69 173 311 69 174 311 minecraft:spruce_planks
fill 69 173 313 69 174 313 minecraft:spruce_planks
fill 69 173 315 69 174 315 minecraft:spruce_planks
fill 70 173 275 70 186 275 minecraft:blue_concrete
fill 70 173 310 70 174 310 minecraft:spruce_planks
fill 70 173 312 70 174 312 minecraft:spruce_planks
fill 70 173 314 70 174 314 minecraft:spruce_planks
fill 70 173 316 70 174 316 minecraft:spruce_planks
fill 71 173 311 71 174 311 minecraft:spruce_planks
fill 71 173 313 71 174 313 minecraft:spruce_planks
fill 71 173 315 71 174 315 minecraft:spruce_planks
fill 72 173 310 72 174 310 minecraft:spruce_planks
fill 72 173 312 72 174 312 minecraft:spruce_planks
fill 72 173 314 72 174 314 minecraft:spruce_planks
fill 72 173 316 72 174 316 minecraft:spruce_planks
setblock 73 173 276 minecraft:spruce_planks
fill 73 173 311 73 174 311 minecraft:spruce_planks
fill 73 173 313 73 174 313 minecraft:spruce_planks
fill 73 173 315 73 174 315 minecraft:spruce_planks
fill 74 173 310 74 174 310 minecraft:spruce_planks
fill 74 173 312 74 174 312 minecraft:spruce_planks
fill 74 173 314 74 174 314 minecraft:spruce_planks
fill 74 173 316 74 174 316 minecraft:spruce_planks
fill 75 173 311 75 174 311 minecraft:spruce_planks
fill 75 173 313 75 174 313 minecraft:spruce_planks
fill 75 173 315 75 174 315 minecraft:spruce_planks
fill 76 173 310 76 174 310 minecraft:spruce_planks
fill 76 173 312 76 174 312 minecraft:spruce_planks
fill 76 173 314 76 174 314 minecraft:spruce_planks
fill 76 173 316 76 174 316 minecraft:spruce_planks
fill 77 173 311 77 174 311 minecraft:spruce_planks
fill 77 173 313 77 174 313 minecraft:spruce_planks
fill 77 173 315 77 174 315 minecraft:spruce_planks
fill 78 173 310 78 174 310 minecraft:spruce_planks
fill 78 173 312 78 174 312 minecraft:spruce_planks
fill 78 173 314 78 174 314 minecraft:spruce_planks
fill 78 173 316 78 174 316 minecraft:spruce_planks
fill 79 173 311 79 174 311 minecraft:spruce_planks
fill 79 173 313 79 174 313 minecraft:spruce_planks
fill 79 173 315 79 174 315 minecraft:spruce_planks
fill 79 173 317 79 175 317 minecraft:blue_concrete
setblock 80 173 276 minecraft:spruce_planks
fill 80 173 310 80 174 310 minecraft:spruce_planks
setblock 80 173 312 minecraft:white_wool
fill 80 173 314 80 174 314 minecraft:spruce_planks
fill 80 173 316 80 174 316 minecraft:spruce_planks
fill 81 173 311 81 174 311 minecraft:spruce_planks
fill 81 173 313 81 174 313 minecraft:spruce_planks
fill 81 173 315 81 174 315 minecraft:spruce_planks
setblock 82 173 287 minecraft:spruce_planks
setblock 82 173 290 minecraft:spruce_planks
setblock 82 173 293 minecraft:spruce_planks
setblock 87 173 276 minecraft:spruce_planks
setblock 88 173 282 minecraft:spruce_planks
setblock 88 173 296 minecraft:spruce_planks
setblock 88 173 303 minecraft:spruce_planks
setblock 88 173 310 minecraft:spruce_planks
setblock 88 173 316 minecraft:spruce_planks
fill 89 173 298 89 193 298 minecraft:blue_concrete
fill 47 174 277 47 193 277 minecraft:blue_concrete
fill 47 174 282 47 179 282 minecraft:blue_concrete
setblock 47 174 283 minecraft:white_wool
fill 47 174 315 47 193 315 minecraft:blue_concrete
fill 48 174 280 56 174 280 minecraft:spruce_log
setblock 48 174 287 minecraft:spruce_planks
setblock 48 174 294 minecraft:spruce_planks
setblock 48 174 301 minecraft:spruce_planks
setblock 48 174 308 minecraft:spruce_planks
setblock 48 174 315 minecraft:spruce_planks
setblock 51 174 276 minecraft:spruce_planks
setblock 54 174 316 minecraft:spruce_planks
setblock 58 174 276 minecraft:spruce_planks
setblock 61 174 316 minecraft:spruce_planks
setblock 65 174 276 minecraft:spruce_planks
setblock 68 174 316 minecraft:spruce_planks
setblock 72 174 276 minecraft:spruce_planks
setblock 79 174 276 minecraft:spruce_planks
fill 80 174 312 88 174 312 minecraft:spruce_log
setblock 82 174 316 minecraft:spruce_planks
setblock 86 174 276 minecraft:spruce_planks
setblock 88 174 281 minecraft:spruce_planks
setblock 88 174 288 minecraft:spruce_planks
setblock 88 174 295 minecraft:spruce_planks
setblock 88 174 302 minecraft:spruce_planks
setblock 88 174 309 minecraft:spruce_planks
fill 47 175 283 47 189 283 minecraft:blue_concrete
setblock 47 175 308 minecraft:white_wool
fill 51 175 280 53 190 280 minecraft:spruce_log
setblock 69 175 311 minecraft:shroomlight
setblock 69 175 313 minecraft:shroomlight
setblock 69 175 315 minecraft:shroomlight
setblock 70 175 310 minecraft:shroomlight
setblock 70 175 312 minecraft:shroomlight
setblock 70 175 314 minecraft:shroomlight
setblock 70 175 316 minecraft:shroomlight
setblock 71 175 311 minecraft:shroomlight
setblock 71 175 313 minecraft:shroomlight
setblock 71 175 315 minecraft:shroomlight
setblock 72 175 310 minecraft:shroomlight
setblock 72 175 312 minecraft:shroomlight
setblock 72 175 314 minecraft:shroomlight
setblock 72 175 316 minecraft:shroomlight
setblock 73 175 311 minecraft:shroomlight
setblock 73 175 313 minecraft:shroomlight
setblock 73 175 315 minecraft:shroomlight
setblock 74 175 310 minecraft:shroomlight
setblock 74 175 312 minecraft:shroomlight
setblock 74 175 314 minecraft:shroomlight
setblock 74 175 316 minecraft:shroomlight
setblock 75 175 311 minecraft:shroomlight
setblock 75 175 313 minecraft:shroomlight
setblock 75 175 315 minecraft:shroomlight
setblock 76 175 310 minecraft:shroomlight
setblock 76 175 312 minecraft:shroomlight
setblock 76 175 314 minecraft:shroomlight
setblock 76 175 316 minecraft:shroomlight
setblock 77 175 311 minecraft:shroomlight
setblock 77 175 313 minecraft:shroomlight
setblock 77 175 315 minecraft:shroomlight
setblock 78 175 310 minecraft:shroomlight
setblock 78 175 312 minecraft:shroomlight
setblock 78 175 314 minecraft:shroomlight
setblock 78 175 316 minecraft:shroomlight
setblock 79 175 311 minecraft:shroomlight
setblock 79 175 313 minecraft:shroomlight
setblock 79 175 315 minecraft:shroomlight
setblock 80 175 310 minecraft:shroomlight
setblock 80 175 312 minecraft:shroomlight
setblock 80 175 314 minecraft:shroomlight
setblock 80 175 316 minecraft:shroomlight
setblock 81 175 311 minecraft:shroomlight
fill 81 175 312 81 187 312 minecraft:spruce_planks
setblock 81 175 313 minecraft:shroomlight
setblock 81 175 315 minecraft:shroomlight
fill 82 175 298 82 184 298 minecraft:iron_bars
fill 83 175 312 85 190 312 minecraft:spruce_log
fill 86 175 312 86 190 312 minecraft:spruce_planks
fill 47 176 308 47 190 308 minecraft:blue_concrete
setblock 48 176 282 minecraft:spruce_planks
setblock 48 176 289 minecraft:spruce_planks
setblock 48 176 296 minecraft:spruce_planks
setblock 48 176 303 minecraft:spruce_planks
setblock 48 176 310 minecraft:spruce_planks
setblock 49 176 276 minecraft:spruce_planks
setblock 49 176 316 minecraft:spruce_planks
fill 50 176 310 51 176 310 minecraft:dark_oak_planks
setblock 50 176 313 minecraft:dark_oak_planks
fill 51 176 314 52 176 314 minecraft:dark_oak_planks
setblock 53 176 310 minecraft:dark_oak_planks
setblock 53 176 313 minecraft:dark_oak_planks
fill 54 176 311 54 176 312 minecraft:dark_oak_planks
setblock 56 176 276 minecraft:spruce_planks
setblock 56 176 316 minecraft:spruce_planks
setblock 63 176 276 minecraft:spruce_planks
setblock 63 176 316 minecraft:spruce_planks
fill 69 176 311 69 177 311 minecraft:spruce_planks
fill 69 176 313 69 177 313 minecraft:spruce_planks
fill 69 176 315 69 177 315 minecraft:spruce_planks
setblock 70 176 276 minecraft:spruce_planks
fill 70 176 310 70 177 310 minecraft:spruce_planks
fill 70 176 312 70 177 312 minecraft:spruce_planks
fill 70 176 314 70 177 314 minecraft:spruce_planks
fill 70 176 316 70 177 316 minecraft:spruce_planks
setblock 71 176 275 minecraft:white_wool
fill 71 176 311 71 177 311 minecraft:spruce_planks
fill 71 176 313 71 177 313 minecraft:spruce_planks
fill 71 176 315 71 177 315 minecraft:spruce_planks
fill 72 176 310 72 177 310 minecraft:spruce_planks
fill 72 176 312 72 177 312 minecraft:spruce_planks
fill 72 176 314 72 177 314 minecraft:spruce_planks
fill 72 176 316 72 177 316 minecraft:spruce_planks
fill 73 176 311 73 177 311 minecraft:spruce_planks
fill 73 176 313 73 177 313 minecraft:spruce_planks
fill 73 176 315 73 177 315 minecraft:spruce_planks
fill 74 176 310 74 177 310 minecraft:spruce_planks
fill 74 176 312 74 177 312 minecraft:spruce_planks
fill 74 176 314 74 177 314 minecraft:spruce_planks
fill 74 176 316 74 177 316 minecraft:spruce_planks
fill 75 176 311 75 177 311 minecraft:spruce_planks
fill 75 176 313 75 177 313 minecraft:spruce_planks
fill 75 176 315 75 177 315 minecraft:spruce_planks
fill 76 176 310 76 177 310 minecraft:spruce_planks
fill 76 176 312 76 177 312 minecraft:spruce_planks
fill 76 176 314 76 177 314 minecraft:spruce_planks
fill 76 176 316 76 177 316 minecraft:spruce_planks
setblock 77 176 276 minecraft:spruce_planks
fill 77 176 311 77 177 311 minecraft:spruce_planks
fill 77 176 313 77 177 313 minecraft:spruce_planks
fill 77 176 315 77 177 315 minecraft:spruce_planks
fill 78 176 310 78 177 310 minecraft:spruce_planks
fill 78 176 312 78 177 312 minecraft:spruce_planks
fill 78 176 314 78 177 314 minecraft:spruce_planks
fill 78 176 316 78 177 316 minecraft:spruce_planks
fill 79 176 311 79 177 311 minecraft:spruce_planks
fill 79 176 313 79 177 313 minecraft:spruce_planks
fill 79 176 315 79 177 315 minecraft:spruce_planks
setblock 79 176 317 minecraft:light_blue_wool
fill 80 176 310 80 177 310 minecraft:spruce_planks
fill 80 176 312 80 177 312 minecraft:spruce_planks
fill 80 176 314 80 177 314 minecraft:spruce_planks
fill 80 176 316 80 177 316 minecraft:spruce_planks
fill 81 176 311 81 177 311 minecraft:spruce_planks
fill 81 176 313 81 177 313 minecraft:spruce_planks
fill 81 176 315 81 177 315 minecraft:spruce_planks
fill 82 176 311 82 176 312 minecraft:dark_oak_planks
fill 83 176 310 86 176 310 minecraft:dark_oak_planks
fill 83 176 313 83 176 314 minecraft:dark_oak_planks
setblock 84 176 276 minecraft:spruce_planks
fill 84 176 314 85 176 314 minecraft:dark_oak_planks
setblock 84 176 316 minecraft:spruce_planks
setblock 86 176 311 minecraft:dark_oak_planks
setblock 86 176 313 minecraft:dark_oak_planks
setblock 88 176 279 minecraft:spruce_planks
setblock 88 176 286 minecraft:spruce_planks
setblock 88 176 293 minecraft:spruce_planks
setblock 88 176 300 minecraft:spruce_planks
setblock 88 176 307 minecraft:spruce_planks
setblock 88 176 314 minecraft:spruce_planks
fill 89 176 311 89 193 311 minecraft:blue_concrete
setblock 89 176 312 minecraft:white_wool
fill 47 177 286 47 194 286 minecraft:blue_concrete
setblock 47 177 287 minecraft:white_wool
fill 47 177 288 47 189 288 minecraft:blue_concrete
setblock 48 177 276 minecraft:spruce_planks
setblock 48 177 283 minecraft:spruce_planks
setblock 48 177 290 minecraft:spruce_planks
setblock 48 177 297 minecraft:spruce_planks
setblock 48 177 304 minecraft:spruce_planks
setblock 48 177 311 minecraft:spruce_planks
setblock 50 177 278 minecraft:light[level=15]
setblock 50 177 285 minecraft:light[level=12]
setblock 50 177 286 minecraft:light[level=15]
setblock 50 177 292 minecraft:light[level=12]
setblock 50 177 294 minecraft:light[level=15]
setblock 50 177 299 minecraft:light[level=12]
setblock 50 177 302 minecraft:light[level=15]
setblock 50 177 306 minecraft:light[level=12]
setblock 50 177 310 minecraft:light[level=15]
setblock 50 177 313 minecraft:light[level=12]
setblock 50 177 316 minecraft:spruce_planks
setblock 55 177 276 minecraft:spruce_planks
setblock 57 177 278 minecraft:light[level=12]
setblock 57 177 285 minecraft:light[level=12]
setblock 57 177 292 minecraft:light[level=12]
setblock 57 177 299 minecraft:light[level=12]
setblock 57 177 306 minecraft:light[level=12]
setblock 57 177 313 minecraft:light[level=12]
setblock 57 177 316 minecraft:spruce_planks
setblock 58 177 278 minecraft:light[level=15]
setblock 58 177 286 minecraft:light[level=15]
setblock 58 177 294 minecraft:light[level=15]
setblock 58 177 302 minecraft:light[level=15]
setblock 58 177 310 minecraft:light[level=15]
setblock 62 177 276 minecraft:spruce_planks
setblock 64 177 278 minecraft:light[level=12]
setblock 64 177 285 minecraft:light[level=12]
setblock 64 177 292 minecraft:light[level=12]
setblock 64 177 299 minecraft:light[level=12]
setblock 64 177 306 minecraft:light[level=12]
setblock 64 177 313 minecraft:light[level=12]
setblock 64 177 316 minecraft:spruce_planks
setblock 66 177 278 minecraft:light[level=15]
setblock 66 177 286 minecraft:light[level=15]
setblock 66 177 294 minecraft:light[level=15]
setblock 66 177 302 minecraft:light[level=15]
setblock 66 177 310 minecraft:light[level=15]
setblock 69 177 276 minecraft:spruce_planks
fill 71 177 275 71 186 275 minecraft:blue_concrete
setblock 71 177 278 minecraft:light[level=12]
setblock 71 177 285 minecraft:light[level=12]
setblock 71 177 292 minecraft:light[level=12]
setblock 71 177 299 minecraft:light[level=12]
setblock 71 177 306 minecraft:light[level=12]
setblock 74 177 278 minecraft:light[level=15]
setblock 74 177 286 minecraft:light[level=15]
setblock 74 177 294 minecraft:light[level=15]
setblock 74 177 302 minecraft:light[level=15]
setblock 76 177 276 minecraft:spruce_planks
setblock 78 177 278 minecraft:light[level=12]
setblock 78 177 285 minecraft:light[level=12]
setblock 78 177 292 minecraft:light[level=12]
setblock 78 177 299 minecraft:light[level=12]
setblock 78 177 306 minecraft:light[level=12]
fill 79 177 317 79 189 317 minecraft:blue_concrete
setblock 82 177 278 minecraft:light[level=15]
setblock 82 177 286 minecraft:light[level=15]
setblock 82 177 294 minecraft:light[level=15]
setblock 82 177 302 minecraft:light[level=15]
setblock 82 177 310 minecraft:light[level=15]
setblock 83 177 276 minecraft:spruce_planks
setblock 85 177 278 minecraft:light[level=12]
setblock 85 177 285 minecraft:light[level=12]
setblock 85 177 292 minecraft:light[level=12]
setblock 85 177 299 minecraft:light[level=12]
setblock 85 177 306 minecraft:light[level=12]
setblock 85 177 316 minecraft:spruce_planks
setblock 88 177 278 minecraft:spruce_planks
setblock 88 177 285 minecraft:spruce_planks
setblock 88 177 292 minecraft:spruce_planks
setblock 88 177 299 minecraft:spruce_planks
setblock 88 177 306 minecraft:spruce_planks
setblock 88 177 313 minecraft:spruce_planks
fill 89 177 279 89 193 279 minecraft:blue_concrete
setblock 89 177 280 minecraft:white_wool
fill 89 177 312 89 193 312 minecraft:blue_concrete
fill 47 178 287 47 193 287 minecraft:blue_concrete
setblock 48 178 277 minecraft:spruce_planks
setblock 48 178 284 minecraft:spruce_planks
setblock 48 178 291 minecraft:spruce_planks
setblock 48 178 298 minecraft:spruce_planks
setblock 48 178 305 minecraft:spruce_planks
setblock 48 178 312 minecraft:spruce_planks
setblock 51 178 316 minecraft:spruce_planks
setblock 54 178 276 minecraft:spruce_planks
fill 56 178 277 62 179 277 minecraft:iron_bars
setblock 58 178 316 minecraft:spruce_planks
setblock 61 178 276 minecraft:spruce_planks
setblock 65 178 316 minecraft:spruce_planks
setblock 68 178 276 minecraft:spruce_planks
setblock 69 178 311 minecraft:shroomlight
setblock 69 178 313 minecraft:shroomlight
setblock 69 178 315 minecraft:shroomlight
setblock 70 178 310 minecraft:shroomlight
setblock 70 178 312 minecraft:shroomlight
setblock 70 178 314 minecraft:shroomlight
setblock 70 178 316 minecraft:shroomlight
setblock 71 178 311 minecraft:shroomlight
setblock 71 178 313 minecraft:shroomlight
setblock 71 178 315 minecraft:shroomlight
setblock 72 178 310 minecraft:shroomlight
setblock 72 178 312 minecraft:shroomlight
setblock 72 178 314 minecraft:shroomlight
setblock 72 178 316 minecraft:shroomlight
setblock 73 178 311 minecraft:shroomlight
setblock 73 178 313 minecraft:shroomlight
setblock 73 178 315 minecraft:shroomlight
setblock 74 178 310 minecraft:shroomlight
setblock 74 178 312 minecraft:shroomlight
setblock 74 178 314 minecraft:shroomlight
setblock 74 178 316 minecraft:shroomlight
setblock 75 178 276 minecraft:spruce_planks
setblock 75 178 311 minecraft:shroomlight
setblock 75 178 313 minecraft:shroomlight
setblock 75 178 315 minecraft:shroomlight
setblock 76 178 310 minecraft:shroomlight
setblock 76 178 312 minecraft:shroomlight
setblock 76 178 314 minecraft:shroomlight
setblock 76 178 316 minecraft:shroomlight
setblock 77 178 311 minecraft:shroomlight
setblock 77 178 313 minecraft:shroomlight
setblock 77 178 315 minecraft:shroomlight
setblock 78 178 310 minecraft:shroomlight
setblock 78 178 312 minecraft:shroomlight
setblock 78 178 314 minecraft:shroomlight
setblock 78 178 316 minecraft:shroomlight
setblock 79 178 311 minecraft:shroomlight
setblock 79 178 313 minecraft:shroomlight
setblock 79 178 315 minecraft:shroomlight
setblock 80 178 310 minecraft:shroomlight
setblock 80 178 312 minecraft:shroomlight
setblock 80 178 314 minecraft:shroomlight
setblock 80 178 316 minecraft:shroomlight
setblock 81 178 311 minecraft:shroomlight
setblock 81 178 313 minecraft:shroomlight
setblock 81 178 315 minecraft:shroomlight
setblock 82 178 276 minecraft:spruce_planks
setblock 86 178 316 minecraft:spruce_planks
fill 87 178 317 87 193 317 minecraft:blue_concrete
setblock 88 178 277 minecraft:spruce_planks
setblock 88 178 284 minecraft:spruce_planks
setblock 88 178 291 minecraft:spruce_planks
setblock 88 178 298 minecraft:spruce_planks
setblock 88 178 305 minecraft:spruce_planks
setblock 88 178 312 minecraft:spruce_planks
setblock 88 178 317 minecraft:white_wool
fill 89 178 280 89 193 280 minecraft:blue_concrete
fill 89 178 288 89 190 288 minecraft:blue_concrete
setblock 89 178 289 minecraft:light_blue_wool
fill 89 178 290 89 186 292 minecraft:blue_concrete
setblock 89 178 310 minecraft:light_blue_wool
fill 89 178 317 89 190 317 minecraft:blue_concrete
fill 48 179 278 48 180 278 minecraft:spruce_planks
fill 48 179 285 48 180 285 minecraft:spruce_planks
fill 48 179 289 48 180 290 minecraft:spruce_planks
fill 48 179 292 48 180 292 minecraft:spruce_planks
fill 48 179 299 48 180 299 minecraft:spruce_planks
fill 48 179 306 48 180 306 minecraft:spruce_planks
fill 48 179 313 48 180 313 minecraft:spruce_planks
fill 52 179 316 52 180 316 minecraft:spruce_planks
fill 53 179 276 53 180 276 minecraft:spruce_planks
fill 59 179 316 59 180 316 minecraft:spruce_planks
fill 60 179 276 60 180 276 minecraft:spruce_planks
fill 66 179 316 66 180 316 minecraft:spruce_planks
fill 67 179 276 67 180 276 minecraft:spruce_planks
fill 69 179 311 69 180 311 minecraft:spruce_planks
fill 69 179 313 69 180 313 minecraft:spruce_planks
fill 69 179 315 69 180 315 minecraft:spruce_planks
fill 70 179 310 70 180 310 minecraft:spruce_planks
fill 70 179 312 70 180 312 minecraft:spruce_planks
fill 70 179 314 70 180 314 minecraft:spruce_planks
fill 70 179 316 70 180 316 minecraft:spruce_planks
fill 71 179 311 71 180 311 minecraft:spruce_planks
fill 71 179 313 71 180 313 minecraft:spruce_planks
fill 71 179 315 71 180 315 minecraft:spruce_planks
fill 72 179 310 72 180 310 minecraft:spruce_planks
fill 72 179 312 72 180 312 minecraft:spruce_planks
fill 72 179 314 72 180 314 minecraft:spruce_planks
fill 72 179 316 72 180 316 minecraft:spruce_planks
fill 73 179 311 73 180 311 minecraft:spruce_planks
fill 73 179 313 73 180 313 minecraft:spruce_planks
fill 73 179 315 73 180 315 minecraft:spruce_planks
fill 74 179 276 74 180 276 minecraft:spruce_planks
fill 74 179 310 74 180 310 minecraft:spruce_planks
fill 74 179 312 74 180 312 minecraft:spruce_planks
fill 74 179 314 74 180 314 minecraft:spruce_planks
fill 74 179 316 74 180 316 minecraft:spruce_planks
fill 75 179 311 75 180 311 minecraft:spruce_planks
fill 75 179 313 75 180 313 minecraft:spruce_planks
fill 75 179 315 75 180 315 minecraft:spruce_planks
fill 76 179 310 76 180 310 minecraft:spruce_planks
fill 76 179 312 76 180 312 minecraft:spruce_planks
fill 76 179 314 76 180 314 minecraft:spruce_planks
fill 76 179 316 76 180 316 minecraft:spruce_planks
fill 77 179 311 77 180 311 minecraft:spruce_planks
fill 77 179 313 77 180 313 minecraft:spruce_planks
fill 77 179 315 77 180 315 minecraft:spruce_planks
fill 78 179 310 78 180 310 minecraft:spruce_planks
fill 78 179 312 78 180 312 minecraft:spruce_planks
fill 78 179 314 78 180 314 minecraft:spruce_planks
fill 78 179 316 78 180 316 minecraft:spruce_planks
fill 79 179 311 79 180 311 minecraft:spruce_planks
fill 79 179 313 79 180 313 minecraft:spruce_planks
fill 79 179 315 79 180 315 minecraft:spruce_planks
fill 80 179 310 80 180 310 minecraft:spruce_planks
fill 80 179 312 80 180 312 minecraft:spruce_planks
fill 80 179 314 80 180 314 minecraft:spruce_planks
fill 80 179 316 80 180 316 minecraft:spruce_planks
fill 81 179 276 81 180 276 minecraft:spruce_planks
fill 81 179 311 81 180 311 minecraft:spruce_planks
fill 81 179 313 81 180 313 minecraft:spruce_planks
fill 81 179 315 81 180 315 minecraft:spruce_planks
fill 87 179 288 88 180 290 minecraft:spruce_planks
fill 87 179 316 87 180 316 minecraft:spruce_planks
fill 88 179 276 88 180 276 minecraft:spruce_planks
fill 88 179 283 88 180 283 minecraft:spruce_planks
fill 88 179 297 88 180 297 minecraft:spruce_planks
fill 88 179 304 88 180 304 minecraft:spruce_planks
fill 88 179 311 88 180 311 minecraft:spruce_planks
fill 88 179 317 88 193 317 minecraft:blue_concrete
fill 89 179 289 89 191 289 minecraft:blue_concrete
fill 89 179 310 89 193 310 minecraft:blue_concrete
setblock 47 180 282 minecraft:light_blue_wool
setblock 47 180 305 minecraft:light_blue_wool
fill 48 180 276 48 180 277 minecraft:spruce_planks
fill 48 180 279 48 180 280 minecraft:spruce_planks
fill 48 180 282 48 180 284 minecraft:spruce_planks
fill 48 180 286 48 180 287 minecraft:spruce_planks
setblock 48 180 291 minecraft:spruce_planks
fill 48 180 293 48 180 294 minecraft:spruce_planks
fill 48 180 296 48 180 298 minecraft:spruce_planks
fill 48 180 300 48 180 301 minecraft:spruce_planks
fill 48 180 303 48 180 305 minecraft:spruce_planks
fill 48 180 307 48 180 308 minecraft:spruce_planks
fill 48 180 310 48 180 312 minecraft:spruce_planks
fill 48 180 314 48 180 315 minecraft:spruce_planks
setblock 49 180 276 minecraft:spruce_planks
fill 49 180 288 49 181 290 minecraft:spruce_planks
fill 49 180 316 51 180 316 minecraft:spruce_planks
fill 50 180 289 50 182 289 minecraft:spruce_planks
fill 51 180 276 52 180 276 minecraft:spruce_planks
fill 53 180 316 54 180 316 minecraft:spruce_planks
fill 54 180 276 56 180 276 minecraft:spruce_planks
fill 56 180 316 58 180 316 minecraft:spruce_planks
fill 58 180 276 59 180 276 minecraft:spruce_planks
fill 60 180 316 61 180 316 minecraft:spruce_planks
fill 61 180 276 63 180 276 minecraft:spruce_planks
fill 63 180 316 65 180 316 minecraft:spruce_planks
fill 65 180 276 66 180 276 minecraft:spruce_planks
fill 67 180 316 68 180 316 minecraft:spruce_planks
fill 68 180 276 70 180 276 minecraft:spruce_planks
fill 72 180 276 73 180 276 minecraft:spruce_planks
fill 75 180 276 77 180 276 minecraft:spruce_planks
fill 79 180 276 80 180 276 minecraft:spruce_planks
fill 81 180 317 81 189 317 minecraft:blue_concrete
fill 82 180 276 84 180 276 minecraft:spruce_planks
fill 82 180 316 82 181 316 minecraft:spruce_planks
setblock 82 180 317 minecraft:white_wool
fill 83 180 317 84 184 317 minecraft:blue_concrete
fill 84 180 316 86 180 316 minecraft:spruce_planks
fill 85 180 289 86 182 289 minecraft:spruce_planks
setblock 85 180 317 minecraft:white_wool
fill 86 180 276 87 180 276 minecraft:spruce_planks
fill 86 180 288 86 181 288 minecraft:spruce_planks
fill 86 180 290 86 181 290 minecraft:spruce_planks
fill 88 180 277 88 180 279 minecraft:spruce_planks
fill 88 180 281 88 180 282 minecraft:spruce_planks
fill 88 180 284 88 180 286 minecraft:spruce_planks
fill 88 180 291 88 180 293 minecraft:spruce_planks
fill 88 180 295 88 180 296 minecraft:spruce_planks
fill 88 180 298 88 180 300 minecraft:spruce_planks
fill 88 180 302 88 180 303 minecraft:spruce_planks
fill 88 180 305 88 180 307 minecraft:spruce_planks
fill 88 180 309 88 180 310 minecraft:spruce_planks
fill 88 180 312 88 180 314 minecraft:spruce_planks
setblock 88 180 316 minecraft:spruce_planks
setblock 89 180 283 minecraft:light_blue_wool
fill 47 181 282 47 193 282 minecraft:blue_concrete
fill 47 181 305 47 193 305 minecraft:blue_concrete
setblock 48 181 280 minecraft:spruce_planks
setblock 48 181 287 minecraft:spruce_planks
setblock 48 181 289 minecraft:spruce_planks
setblock 48 181 294 minecraft:spruce_planks
setblock 48 181 301 minecraft:spruce_planks
setblock 48 181 308 minecraft:spruce_planks
setblock 48 181 315 minecraft:spruce_planks
fill 50 181 288 50 182 288 minecraft:spruce_planks
fill 50 181 290 50 182 290 minecraft:spruce_planks
setblock 51 181 276 minecraft:spruce_planks
fill 51 181 289 51 183 289 minecraft:spruce_planks
setblock 54 181 316 minecraft:spruce_planks
setblock 58 181 276 minecraft:spruce_planks
setblock 61 181 316 minecraft:spruce_planks
setblock 65 181 276 minecraft:spruce_planks
setblock 68 181 316 minecraft:spruce_planks
fill 69 181 279 69 184 279 minecraft:iron_bars
setblock 69 181 311 minecraft:shroomlight
setblock 69 181 313 minecraft:shroomlight
setblock 69 181 315 minecraft:shroomlight
setblock 70 181 310 minecraft:shroomlight
setblock 70 181 312 minecraft:shroomlight
setblock 70 181 314 minecraft:shroomlight
setblock 70 181 316 minecraft:shroomlight
setblock 71 181 311 minecraft:shroomlight
setblock 71 181 313 minecraft:shroomlight
setblock 71 181 315 minecraft:shroomlight
setblock 72 181 276 minecraft:spruce_planks
setblock 72 181 310 minecraft:shroomlight
setblock 72 181 312 minecraft:shroomlight
setblock 72 181 314 minecraft:shroomlight
setblock 72 181 316 minecraft:shroomlight
setblock 73 181 311 minecraft:shroomlight
setblock 73 181 313 minecraft:shroomlight
setblock 73 181 315 minecraft:shroomlight
setblock 74 181 310 minecraft:shroomlight
setblock 74 181 312 minecraft:shroomlight
setblock 74 181 314 minecraft:shroomlight
setblock 74 181 316 minecraft:shroomlight
setblock 75 181 311 minecraft:shroomlight
setblock 75 181 313 minecraft:shroomlight
setblock 75 181 315 minecraft:shroomlight
setblock 76 181 310 minecraft:shroomlight
setblock 76 181 312 minecraft:shroomlight
setblock 76 181 314 minecraft:shroomlight
setblock 76 181 316 minecraft:shroomlight
setblock 77 181 311 minecraft:shroomlight
setblock 77 181 313 minecraft:shroomlight
setblock 77 181 315 minecraft:shroomlight
setblock 78 181 310 minecraft:shroomlight
setblock 78 181 312 minecraft:shroomlight
setblock 78 181 314 minecraft:shroomlight
setblock 78 181 316 minecraft:shroomlight
setblock 79 181 276 minecraft:spruce_planks
setblock 79 181 311 minecraft:shroomlight
setblock 79 181 313 minecraft:shroomlight
setblock 79 181 315 minecraft:shroomlight
setblock 80 181 310 minecraft:shroomlight
setblock 80 181 312 minecraft:shroomlight
setblock 80 181 314 minecraft:shroomlight
setblock 80 181 316 minecraft:shroomlight
setblock 81 181 311 minecraft:shroomlight
setblock 81 181 313 minecraft:shroomlight
setblock 81 181 315 minecraft:shroomlight
fill 82 181 317 82 193 317 minecraft:blue_concrete
fill 84 181 289 84 183 289 minecraft:spruce_planks
fill 85 181 288 85 182 288 minecraft:spruce_planks
fill 85 181 290 85 182 290 minecraft:spruce_planks
fill 85 181 317 85 193 317 minecraft:blue_concrete
setblock 86 181 276 minecraft:spruce_planks
setblock 87 181 289 minecraft:spruce_planks
setblock 88 181 281 minecraft:spruce_planks
setblock 88 181 288 minecraft:spruce_planks
setblock 88 181 289 minecraft:dark_oak_planks
setblock 88 181 295 minecraft:spruce_planks
setblock 88 181 302 minecraft:spruce_planks
setblock 88 181 309 minecraft:spruce_planks
fill 89 181 283 89 193 283 minecraft:blue_concrete
setblock 89 181 316 minecraft:white_wool
setblock 48 182 289 minecraft:dark_oak_planks
setblock 49 182 289 minecraft:spruce_planks
fill 51 182 288 52 183 288 minecraft:spruce_planks
fill 51 182 290 52 183 290 minecraft:spruce_planks
fill 52 182 289 52 184 289 minecraft:spruce_planks
fill 69 182 311 69 183 311 minecraft:spruce_planks
fill 69 182 313 69 183 313 minecraft:spruce_planks
fill 69 182 315 69 183 315 minecraft:spruce_planks
fill 70 182 310 70 183 310 minecraft:spruce_planks
fill 70 182 312 70 183 312 minecraft:spruce_planks
fill 70 182 314 70 183 314 minecraft:spruce_planks
fill 70 182 316 70 183 316 minecraft:spruce_planks
fill 71 182 311 71 183 311 minecraft:spruce_planks
fill 71 182 313 71 183 313 minecraft:spruce_planks
fill 71 182 315 71 183 315 minecraft:spruce_planks
fill 72 182 310 72 183 310 minecraft:spruce_planks
fill 72 182 312 72 183 312 minecraft:spruce_planks
fill 72 182 314 72 183 314 minecraft:spruce_planks
fill 72 182 316 72 183 316 minecraft:spruce_planks
fill 73 182 311 73 183 311 minecraft:spruce_planks
fill 73 182 313 73 183 313 minecraft:spruce_planks
fill 73 182 315 73 183 315 minecraft:spruce_planks
fill 74 182 310 74 183 310 minecraft:spruce_planks
fill 74 182 312 74 183 312 minecraft:spruce_planks
fill 74 182 314 74 183 314 minecraft:spruce_planks
fill 74 182 316 74 183 316 minecraft:spruce_planks
fill 75 182 311 75 183 311 minecraft:spruce_planks
fill 75 182 313 75 183 313 minecraft:spruce_planks
fill 75 182 315 75 183 315 minecraft:spruce_planks
fill 76 182 310 76 183 310 minecraft:spruce_planks
fill 76 182 312 76 183 312 minecraft:spruce_planks
fill 76 182 314 76 183 314 minecraft:spruce_planks
fill 76 182 316 76 183 316 minecraft:spruce_planks
fill 77 182 311 77 183 311 minecraft:spruce_planks
fill 77 182 313 77 183 313 minecraft:spruce_planks
fill 77 182 315 77 183 315 minecraft:spruce_planks
fill 78 182 310 78 183 310 minecraft:spruce_planks
fill 78 182 312 78 183 312 minecraft:spruce_planks
fill 78 182 314 78 183 314 minecraft:spruce_planks
fill 78 182 316 78 183 316 minecraft:spruce_planks
fill 79 182 311 79 183 311 minecraft:spruce_planks
fill 79 182 313 79 183 313 minecraft:spruce_planks
fill 79 182 315 79 183 315 minecraft:spruce_planks
fill 80 182 310 80 183 310 minecraft:spruce_planks
fill 80 182 312 80 183 312 minecraft:spruce_planks
fill 80 182 314 80 183 314 minecraft:spruce_planks
fill 80 182 316 80 183 316 minecraft:spruce_planks
fill 81 182 311 81 183 311 minecraft:spruce_planks
fill 81 182 313 81 183 313 minecraft:spruce_planks
fill 81 182 315 81 183 315 minecraft:spruce_planks
schedule function dropper:buildpart/61_2 1t
