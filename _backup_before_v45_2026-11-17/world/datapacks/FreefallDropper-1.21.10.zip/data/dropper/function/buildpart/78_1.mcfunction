fill 309 116 355 309 117 355 minecraft:polished_andesite
fill 309 116 357 309 117 357 minecraft:polished_andesite
fill 309 116 359 309 117 359 minecraft:polished_andesite
fill 309 116 361 309 117 361 minecraft:polished_andesite
fill 309 116 363 309 117 363 minecraft:polished_andesite
fill 310 116 354 310 117 354 minecraft:polished_andesite
fill 310 116 356 310 117 356 minecraft:polished_andesite
fill 310 116 358 310 117 358 minecraft:polished_andesite
fill 310 116 360 310 117 360 minecraft:polished_andesite
fill 310 116 362 310 117 362 minecraft:polished_andesite
fill 311 116 355 311 117 355 minecraft:polished_andesite
fill 311 116 357 311 117 357 minecraft:polished_andesite
fill 311 116 359 311 117 359 minecraft:polished_andesite
fill 311 116 361 311 117 361 minecraft:polished_andesite
fill 311 116 363 311 117 363 minecraft:polished_andesite
setblock 285 117 325 minecraft:light[level=12]
setblock 285 117 332 minecraft:light[level=12]
setblock 285 117 339 minecraft:light[level=12]
setblock 285 117 346 minecraft:light[level=12]
setblock 285 117 353 minecraft:light[level=12]
setblock 285 117 360 minecraft:light[level=12]
setblock 292 117 325 minecraft:light[level=12]
setblock 292 117 332 minecraft:light[level=12]
setblock 292 117 339 minecraft:light[level=12]
setblock 292 117 346 minecraft:light[level=12]
setblock 292 117 353 minecraft:light[level=12]
setblock 292 117 360 minecraft:light[level=12]
setblock 299 117 325 minecraft:light[level=12]
setblock 299 117 332 minecraft:light[level=12]
setblock 299 117 339 minecraft:light[level=12]
setblock 299 117 346 minecraft:light[level=12]
setblock 299 117 353 minecraft:light[level=12]
setblock 299 117 360 minecraft:light[level=12]
setblock 306 117 325 minecraft:light[level=12]
setblock 306 117 332 minecraft:light[level=12]
setblock 306 117 339 minecraft:light[level=12]
setblock 306 117 346 minecraft:light[level=12]
setblock 306 117 353 minecraft:light[level=12]
setblock 313 117 325 minecraft:light[level=12]
setblock 313 117 332 minecraft:light[level=12]
setblock 313 117 339 minecraft:light[level=12]
setblock 313 117 346 minecraft:light[level=12]
setblock 313 117 353 minecraft:light[level=12]
setblock 313 117 360 minecraft:light[level=12]
setblock 320 117 325 minecraft:light[level=12]
setblock 320 117 332 minecraft:light[level=12]
setblock 320 117 339 minecraft:light[level=12]
setblock 320 117 346 minecraft:light[level=12]
setblock 320 117 353 minecraft:light[level=12]
setblock 320 117 360 minecraft:light[level=12]
fill 300 118 358 304 135 358 minecraft:polished_andesite
fill 301 118 326 301 121 326 minecraft:iron_bars
fill 301 118 357 303 135 357 minecraft:polished_andesite
fill 301 118 359 303 135 359 minecraft:polished_andesite
fill 302 118 356 302 135 356 minecraft:polished_andesite
fill 302 118 360 302 135 360 minecraft:polished_andesite
fill 306 118 355 310 118 362 minecraft:red_wool
fill 316 118 323 317 119 341 minecraft:polished_andesite
fill 317 118 342 317 119 363 minecraft:polished_andesite
fill 318 118 351 318 119 363 minecraft:polished_andesite
fill 283 119 339 285 120 339 minecraft:iron_bars
setblock 285 119 325 minecraft:light[level=15]
setblock 285 119 333 minecraft:light[level=15]
setblock 285 119 341 minecraft:light[level=15]
setblock 285 119 349 minecraft:light[level=15]
setblock 285 119 357 minecraft:light[level=15]
setblock 293 119 325 minecraft:light[level=15]
setblock 293 119 333 minecraft:light[level=15]
setblock 293 119 341 minecraft:light[level=15]
setblock 293 119 349 minecraft:light[level=15]
setblock 293 119 357 minecraft:light[level=15]
fill 298 119 357 299 134 359 minecraft:polished_andesite
fill 299 119 356 301 134 356 minecraft:polished_andesite
fill 299 119 360 301 134 360 minecraft:polished_andesite
fill 300 119 355 304 134 355 minecraft:polished_andesite
fill 300 119 357 300 134 357 minecraft:polished_andesite
fill 300 119 359 300 134 359 minecraft:polished_andesite
fill 300 119 361 304 134 361 minecraft:polished_andesite
setblock 301 119 325 minecraft:light[level=15]
setblock 301 119 333 minecraft:light[level=15]
setblock 301 119 349 minecraft:light[level=15]
fill 301 119 354 303 134 354 minecraft:polished_andesite
fill 301 119 362 303 134 362 minecraft:polished_andesite
fill 303 119 356 305 134 356 minecraft:polished_andesite
fill 303 119 360 305 134 360 minecraft:polished_andesite
fill 304 119 357 306 132 357 minecraft:polished_andesite
fill 304 119 359 306 133 359 minecraft:polished_andesite
fill 305 119 358 306 132 358 minecraft:polished_andesite
fill 307 119 356 309 119 361 minecraft:red_wool
setblock 309 119 325 minecraft:light[level=15]
setblock 309 119 333 minecraft:light[level=15]
setblock 309 119 341 minecraft:light[level=15]
setblock 309 119 349 minecraft:light[level=15]
fill 284 120 332 284 125 334 minecraft:polished_andesite
fill 284 120 344 284 125 346 minecraft:polished_andesite
fill 284 120 356 284 125 358 minecraft:polished_andesite
fill 290 120 362 292 125 362 minecraft:polished_andesite
fill 294 120 324 296 125 324 minecraft:polished_andesite
fill 297 120 356 297 133 360 minecraft:polished_andesite
fill 298 120 355 298 133 356 minecraft:polished_andesite
fill 298 120 360 298 133 361 minecraft:polished_andesite
fill 299 120 354 299 133 355 minecraft:polished_andesite
fill 299 120 361 299 133 362 minecraft:polished_andesite
fill 300 120 353 300 133 354 minecraft:polished_andesite
fill 300 120 362 300 133 363 minecraft:polished_andesite
fill 301 120 353 304 133 353 minecraft:polished_andesite
fill 304 120 354 305 133 354 minecraft:polished_andesite
fill 304 120 362 304 133 363 minecraft:polished_andesite
fill 305 120 355 306 133 355 minecraft:polished_andesite
fill 305 120 361 305 133 362 minecraft:polished_andesite
fill 306 120 324 308 125 324 minecraft:polished_andesite
fill 306 120 356 307 133 356 minecraft:polished_andesite
fill 306 120 360 306 133 361 minecraft:polished_andesite
fill 307 120 357 307 120 360 minecraft:polished_andesite
fill 308 120 357 308 120 360 minecraft:red_wool
fill 314 120 362 316 125 362 minecraft:polished_andesite
fill 316 120 323 316 120 331 minecraft:red_wool
fill 317 120 329 317 120 362 minecraft:red_wool
fill 318 120 324 320 125 324 minecraft:polished_andesite
fill 318 120 361 318 120 362 minecraft:red_wool
fill 322 120 332 322 125 334 minecraft:polished_andesite
fill 322 120 344 322 125 346 minecraft:polished_andesite
fill 322 120 356 322 125 358 minecraft:polished_andesite
fill 296 121 357 296 132 359 minecraft:polished_andesite
fill 297 121 355 297 132 355 minecraft:polished_andesite
fill 297 121 361 297 132 361 minecraft:polished_andesite
fill 298 121 354 298 132 354 minecraft:polished_andesite
fill 298 121 362 298 132 362 minecraft:polished_andesite
fill 299 121 353 299 132 353 minecraft:polished_andesite
fill 299 121 363 299 124 363 minecraft:polished_andesite
fill 301 121 352 303 132 352 minecraft:polished_andesite
fill 305 121 353 305 132 353 minecraft:polished_andesite
fill 305 121 363 305 132 363 minecraft:polished_andesite
fill 306 121 354 306 132 354 minecraft:polished_andesite
fill 306 121 362 306 132 362 minecraft:polished_andesite
fill 307 121 355 307 132 355 minecraft:polished_andesite
fill 307 121 357 308 132 357 minecraft:polished_andesite
fill 307 121 358 309 121 359 minecraft:red_wool
fill 307 121 360 307 133 361 minecraft:polished_andesite
fill 296 122 355 296 131 356 minecraft:polished_andesite
fill 296 122 360 296 131 361 minecraft:polished_andesite
fill 297 122 354 297 131 354 minecraft:polished_andesite
fill 297 122 362 297 131 362 minecraft:polished_andesite
fill 298 122 323 304 122 326 minecraft:cobblestone
fill 298 122 353 298 131 353 minecraft:polished_andesite
fill 298 122 363 298 124 363 minecraft:polished_andesite
fill 299 122 352 300 131 352 minecraft:polished_andesite
fill 304 122 352 305 131 352 minecraft:polished_andesite
fill 306 122 353 306 131 353 minecraft:polished_andesite
fill 306 122 363 306 124 363 minecraft:polished_andesite
fill 307 122 354 307 131 354 minecraft:polished_andesite
fill 307 122 358 308 133 359 minecraft:polished_andesite
fill 307 122 362 307 131 362 minecraft:polished_andesite
fill 308 122 355 308 131 356 minecraft:polished_andesite
fill 308 122 360 308 131 361 minecraft:polished_andesite
fill 313 122 324 313 129 324 minecraft:red_wool
setblock 285 123 325 minecraft:light[level=12]
setblock 285 123 332 minecraft:light[level=12]
setblock 285 123 339 minecraft:light[level=12]
setblock 285 123 346 minecraft:light[level=12]
setblock 285 123 353 minecraft:light[level=12]
setblock 285 123 360 minecraft:light[level=12]
fill 288 123 341 288 124 341 minecraft:cobblestone
fill 288 123 344 288 124 344 minecraft:cobblestone
setblock 292 123 325 minecraft:light[level=12]
setblock 292 123 332 minecraft:light[level=12]
setblock 292 123 339 minecraft:light[level=12]
setblock 292 123 346 minecraft:light[level=12]
setblock 292 123 353 minecraft:light[level=12]
setblock 292 123 360 minecraft:light[level=12]
fill 295 123 356 295 130 360 minecraft:polished_andesite
fill 296 123 354 296 130 354 minecraft:polished_andesite
fill 296 123 362 296 130 362 minecraft:polished_andesite
fill 297 123 353 297 130 353 minecraft:polished_andesite
fill 297 123 363 297 124 363 minecraft:polished_andesite
fill 298 123 323 304 123 326 minecraft:polished_andesite
fill 298 123 352 298 130 352 minecraft:polished_andesite
setblock 299 123 332 minecraft:light[level=12]
setblock 299 123 339 minecraft:light[level=12]
setblock 299 123 346 minecraft:light[level=12]
setblock 299 123 351 minecraft:cobblestone
fill 300 123 328 300 124 328 minecraft:cobblestone
fill 300 123 351 304 130 351 minecraft:polished_andesite
setblock 305 123 351 minecraft:cobblestone
setblock 306 123 325 minecraft:light[level=12]
fill 306 123 328 306 124 328 minecraft:cobblestone
setblock 306 123 332 minecraft:light[level=12]
setblock 306 123 339 minecraft:light[level=12]
setblock 306 123 346 minecraft:light[level=12]
fill 306 123 352 306 130 352 minecraft:polished_andesite
fill 307 123 353 307 130 353 minecraft:polished_andesite
fill 307 123 363 307 124 363 minecraft:polished_andesite
fill 308 123 354 308 130 354 minecraft:polished_andesite
fill 308 123 362 308 130 362 minecraft:polished_andesite
fill 309 123 356 309 130 360 minecraft:polished_andesite
fill 311 123 324 312 129 324 minecraft:red_wool
setblock 313 123 325 minecraft:light[level=12]
setblock 313 123 332 minecraft:light[level=12]
setblock 313 123 339 minecraft:light[level=12]
setblock 313 123 346 minecraft:light[level=12]
setblock 313 123 353 minecraft:light[level=12]
setblock 313 123 360 minecraft:light[level=12]
fill 314 123 324 315 129 324 minecraft:red_wool
fill 317 123 335 317 124 335 minecraft:cobblestone
fill 317 123 346 317 124 346 minecraft:cobblestone
setblock 320 123 325 minecraft:light[level=12]
setblock 320 123 332 minecraft:light[level=12]
setblock 320 123 339 minecraft:light[level=12]
setblock 320 123 346 minecraft:light[level=12]
setblock 320 123 353 minecraft:light[level=12]
setblock 320 123 360 minecraft:light[level=12]
fill 287 124 341 287 125 341 minecraft:cobblestone
fill 287 124 344 287 125 344 minecraft:cobblestone
fill 293 124 322 299 136 322 minecraft:cobblestone
fill 295 124 355 295 129 355 minecraft:polished_andesite
fill 295 124 361 295 130 361 minecraft:polished_andesite
fill 298 124 326 304 124 326 minecraft:red_wool
fill 299 124 351 299 129 351 minecraft:polished_andesite
fill 300 124 322 302 127 322 minecraft:shroomlight
fill 300 124 327 300 125 327 minecraft:cobblestone
fill 303 124 322 303 125 322 minecraft:cobblestone
fill 305 124 351 305 129 351 minecraft:polished_andesite
fill 306 124 327 306 125 327 minecraft:cobblestone
fill 309 124 355 309 129 355 minecraft:polished_andesite
fill 309 124 361 309 130 361 minecraft:polished_andesite
fill 318 124 335 318 125 335 minecraft:cobblestone
fill 318 124 346 318 125 346 minecraft:cobblestone
fill 283 125 326 283 125 331 minecraft:cobblestone
fill 283 125 338 283 125 343 minecraft:cobblestone
fill 283 125 350 283 125 355 minecraft:cobblestone
fill 283 125 362 283 125 363 minecraft:cobblestone
fill 284 125 363 287 125 363 minecraft:cobblestone
fill 286 125 341 286 126 341 minecraft:cobblestone
fill 286 125 344 286 126 344 minecraft:cobblestone
fill 287 125 323 292 125 323 minecraft:cobblestone
fill 294 125 363 299 125 363 minecraft:cobblestone
fill 296 125 353 296 128 353 minecraft:polished_andesite
fill 297 125 352 297 128 352 minecraft:polished_andesite
setblock 298 125 326 minecraft:polished_andesite
fill 299 125 323 304 125 323 minecraft:cobblestone
fill 300 125 326 300 126 326 minecraft:cobblestone
setblock 301 125 326 minecraft:polished_andesite
setblock 304 125 326 minecraft:polished_andesite
fill 306 125 326 306 126 326 minecraft:cobblestone
fill 306 125 363 311 125 363 minecraft:cobblestone
fill 307 125 352 307 128 352 minecraft:polished_andesite
fill 308 125 353 308 128 353 minecraft:polished_andesite
fill 311 125 323 316 125 323 minecraft:cobblestone
fill 318 125 363 323 125 363 minecraft:cobblestone
fill 319 125 335 319 126 335 minecraft:cobblestone
fill 319 125 346 319 126 346 minecraft:cobblestone
fill 323 125 323 323 125 328 minecraft:cobblestone
fill 323 125 335 323 125 340 minecraft:cobblestone
fill 323 125 347 323 125 352 minecraft:cobblestone
fill 323 125 359 323 125 362 minecraft:cobblestone
fill 282 126 328 282 131 331 minecraft:shroomlight
fill 282 126 340 282 131 343 minecraft:shroomlight
fill 282 126 352 282 131 355 minecraft:shroomlight
fill 282 126 364 285 131 364 minecraft:shroomlight
fill 285 126 341 285 127 341 minecraft:cobblestone
fill 285 126 344 285 127 344 minecraft:cobblestone
fill 289 126 322 292 131 322 minecraft:shroomlight
fill 294 126 364 297 131 364 minecraft:shroomlight
fill 296 126 363 299 128 363 minecraft:polished_andesite
fill 300 126 325 300 127 325 minecraft:cobblestone
fill 303 126 322 304 131 322 minecraft:shroomlight
fill 306 126 325 306 127 325 minecraft:cobblestone
fill 306 126 363 308 128 363 minecraft:polished_andesite
fill 306 126 364 309 131 364 minecraft:shroomlight
fill 313 126 322 316 131 322 minecraft:shroomlight
fill 318 126 364 321 131 364 minecraft:shroomlight
fill 320 126 335 320 127 335 minecraft:cobblestone
fill 320 126 346 320 127 346 minecraft:cobblestone
fill 324 126 323 324 131 326 minecraft:shroomlight
fill 324 126 335 324 131 338 minecraft:shroomlight
fill 324 126 347 324 131 350 minecraft:shroomlight
fill 324 126 359 324 131 362 minecraft:shroomlight
fill 284 127 341 284 128 341 minecraft:cobblestone
fill 284 127 344 284 128 344 minecraft:cobblestone
setblock 285 127 325 minecraft:light[level=15]
setblock 285 127 333 minecraft:light[level=15]
setblock 285 127 349 minecraft:light[level=15]
setblock 285 127 357 minecraft:light[level=15]
setblock 293 127 325 minecraft:light[level=15]
setblock 293 127 333 minecraft:light[level=15]
setblock 293 127 341 minecraft:light[level=15]
setblock 293 127 349 minecraft:light[level=15]
setblock 293 127 357 minecraft:light[level=15]
fill 298 127 351 298 129 351 minecraft:shroomlight
fill 300 127 324 300 128 324 minecraft:cobblestone
setblock 301 127 325 minecraft:light[level=15]
setblock 301 127 333 minecraft:light[level=15]
setblock 301 127 349 minecraft:light[level=15]
fill 306 127 324 306 128 324 minecraft:cobblestone
fill 306 127 351 306 129 351 minecraft:shroomlight
setblock 309 127 325 minecraft:light[level=15]
setblock 309 127 333 minecraft:light[level=15]
setblock 309 127 341 minecraft:light[level=15]
setblock 309 127 349 minecraft:light[level=15]
setblock 317 127 325 minecraft:light[level=15]
setblock 317 127 333 minecraft:light[level=15]
setblock 317 127 341 minecraft:light[level=15]
setblock 317 127 349 minecraft:light[level=15]
setblock 317 127 357 minecraft:light[level=15]
fill 321 127 335 321 128 335 minecraft:cobblestone
fill 321 127 346 321 128 346 minecraft:cobblestone
fill 283 128 341 283 129 341 minecraft:cobblestone
fill 283 128 344 283 129 344 minecraft:cobblestone
setblock 299 128 350 minecraft:shroomlight
fill 300 128 322 300 129 323 minecraft:cobblestone
fill 301 128 322 302 131 322 minecraft:shroomlight
setblock 305 128 350 minecraft:shroomlight
fill 306 128 323 306 129 323 minecraft:cobblestone
fill 311 128 357 311 131 357 minecraft:iron_bars
fill 322 128 335 322 129 335 minecraft:cobblestone
fill 322 128 346 322 129 346 minecraft:cobblestone
setblock 285 129 325 minecraft:light[level=12]
setblock 285 129 332 minecraft:light[level=12]
setblock 285 129 339 minecraft:light[level=12]
setblock 285 129 346 minecraft:light[level=12]
setblock 285 129 353 minecraft:light[level=12]
setblock 285 129 360 minecraft:light[level=12]
setblock 288 129 328 minecraft:shroomlight
setblock 288 129 334 minecraft:shroomlight
setblock 288 129 340 minecraft:shroomlight
setblock 288 129 346 minecraft:shroomlight
setblock 288 129 352 minecraft:shroomlight
setblock 288 129 358 minecraft:shroomlight
setblock 292 129 325 minecraft:light[level=12]
setblock 292 129 332 minecraft:light[level=12]
setblock 292 129 339 minecraft:light[level=12]
setblock 292 129 346 minecraft:light[level=12]
setblock 292 129 353 minecraft:light[level=12]
setblock 292 129 360 minecraft:light[level=12]
setblock 294 129 328 minecraft:shroomlight
setblock 294 129 358 minecraft:shroomlight
fill 297 129 363 299 130 363 minecraft:polished_andesite
setblock 299 129 325 minecraft:light[level=12]
setblock 299 129 332 minecraft:light[level=12]
setblock 299 129 339 minecraft:light[level=12]
setblock 299 129 346 minecraft:light[level=12]
setblock 300 129 328 minecraft:shroomlight
setblock 306 129 325 minecraft:light[level=12]
setblock 306 129 328 minecraft:shroomlight
setblock 306 129 332 minecraft:light[level=12]
setblock 306 129 339 minecraft:light[level=12]
setblock 306 129 346 minecraft:light[level=12]
fill 306 129 363 307 130 363 minecraft:polished_andesite
setblock 312 129 328 minecraft:shroomlight
setblock 312 129 358 minecraft:shroomlight
setblock 313 129 325 minecraft:light[level=12]
setblock 313 129 332 minecraft:light[level=12]
setblock 313 129 339 minecraft:light[level=12]
setblock 313 129 346 minecraft:light[level=12]
setblock 313 129 353 minecraft:light[level=12]
setblock 313 129 360 minecraft:light[level=12]
setblock 318 129 328 minecraft:shroomlight
setblock 318 129 334 minecraft:shroomlight
setblock 318 129 340 minecraft:shroomlight
setblock 318 129 346 minecraft:shroomlight
setblock 318 129 352 minecraft:shroomlight
setblock 318 129 358 minecraft:shroomlight
setblock 320 129 325 minecraft:light[level=12]
setblock 320 129 332 minecraft:light[level=12]
setblock 320 129 339 minecraft:light[level=12]
setblock 320 129 346 minecraft:light[level=12]
setblock 320 129 353 minecraft:light[level=12]
setblock 320 129 360 minecraft:light[level=12]
fill 283 130 324 288 130 332 minecraft:polished_andesite
fill 283 130 336 288 130 344 minecraft:polished_andesite
fill 283 130 348 288 130 356 minecraft:polished_andesite
fill 283 130 360 288 130 363 minecraft:polished_andesite
fill 284 130 333 288 130 335 minecraft:polished_andesite
fill 284 130 345 288 130 347 minecraft:polished_andesite
fill 284 130 357 288 130 359 minecraft:polished_andesite
fill 286 130 323 294 130 323 minecraft:polished_andesite
fill 289 130 324 323 130 328 minecraft:polished_andesite
fill 289 130 358 294 130 362 minecraft:polished_andesite
fill 292 130 363 296 130 363 minecraft:polished_andesite
setblock 295 130 362 minecraft:polished_andesite
fill 298 130 323 306 130 323 minecraft:polished_andesite
fill 300 130 322 300 137 322 minecraft:cobblestone
fill 308 130 363 312 130 363 minecraft:polished_andesite
fill 309 130 362 323 130 362 minecraft:polished_andesite
fill 310 130 323 318 130 323 minecraft:polished_andesite
fill 310 130 358 323 130 361 minecraft:polished_andesite
fill 316 130 363 323 130 363 minecraft:polished_andesite
fill 318 130 329 322 130 357 minecraft:polished_andesite
fill 322 130 323 323 130 323 minecraft:polished_andesite
fill 323 130 329 323 131 330 minecraft:polished_andesite
fill 323 130 334 323 130 342 minecraft:polished_andesite
fill 323 130 346 323 130 354 minecraft:polished_andesite
fill 283 131 328 284 131 330 minecraft:polished_andesite
fill 285 131 329 285 134 329 minecraft:polished_andesite
fill 288 131 328 288 131 358 minecraft:red_wool
fill 289 131 328 318 131 328 minecraft:red_wool
fill 289 131 358 295 131 358 minecraft:red_wool
fill 298 131 363 299 131 363 minecraft:polished_andesite
setblock 306 131 363 minecraft:polished_andesite
fill 309 131 358 318 131 358 minecraft:red_wool
fill 310 131 324 316 132 324 minecraft:iron_bars
fill 318 131 323 318 131 325 minecraft:iron_bars
fill 318 131 329 318 131 357 minecraft:red_wool
fill 320 131 329 322 132 329 minecraft:polished_andesite
fill 321 131 328 323 131 328 minecraft:polished_andesite
fill 321 131 330 322 131 330 minecraft:polished_andesite
fill 282 132 328 282 136 328 minecraft:cobblestone
fill 282 132 329 282 132 330 minecraft:shroomlight
fill 282 132 331 282 136 331 minecraft:cobblestone
fill 282 132 340 282 138 340 minecraft:cobblestone
fill 282 132 341 282 132 342 minecraft:shroomlight
fill 282 132 343 282 140 343 minecraft:cobblestone
fill 282 132 352 282 136 352 minecraft:cobblestone
fill 282 132 353 282 132 354 minecraft:shroomlight
fill 282 132 355 282 140 355 minecraft:cobblestone
fill 282 132 364 282 136 364 minecraft:cobblestone
fill 283 132 329 284 132 329 minecraft:polished_andesite
fill 283 132 364 284 132 364 minecraft:shroomlight
fill 284 132 328 285 132 328 minecraft:polished_andesite
fill 284 132 330 285 132 330 minecraft:polished_andesite
fill 285 132 364 285 140 364 minecraft:cobblestone
fill 286 132 329 286 134 329 minecraft:polished_andesite
fill 289 132 322 289 140 322 minecraft:cobblestone
fill 290 132 322 291 132 322 minecraft:shroomlight
fill 292 132 322 292 137 322 minecraft:cobblestone
fill 294 132 364 294 140 364 minecraft:cobblestone
fill 295 132 364 296 132 364 minecraft:shroomlight
fill 297 132 364 297 140 364 minecraft:cobblestone
setblock 299 132 363 minecraft:polished_andesite
fill 301 132 322 301 140 322 minecraft:cobblestone
fill 302 132 322 303 132 322 minecraft:shroomlight
fill 304 132 322 304 140 322 minecraft:cobblestone
fill 306 132 364 306 138 364 minecraft:cobblestone
fill 307 132 362 315 132 362 minecraft:cobblestone
fill 307 132 364 308 132 364 minecraft:shroomlight
fill 308 132 360 315 132 361 minecraft:cobblestone
fill 309 132 357 315 132 359 minecraft:cobblestone
fill 309 132 364 309 138 364 minecraft:cobblestone
fill 313 132 322 313 142 322 minecraft:cobblestone
fill 314 132 322 315 132 322 minecraft:shroomlight
fill 316 132 322 316 136 322 minecraft:cobblestone
fill 318 132 364 318 140 364 minecraft:cobblestone
fill 319 132 329 319 134 329 minecraft:polished_andesite
fill 319 132 364 320 132 364 minecraft:shroomlight
fill 320 132 328 321 132 328 minecraft:polished_andesite
fill 320 132 330 321 132 330 minecraft:polished_andesite
fill 321 132 364 321 137 364 minecraft:cobblestone
setblock 323 132 329 minecraft:red_wool
fill 324 132 323 324 140 323 minecraft:cobblestone
fill 324 132 324 324 132 325 minecraft:shroomlight
fill 324 132 326 324 141 326 minecraft:cobblestone
fill 324 132 335 324 137 335 minecraft:cobblestone
fill 324 132 336 324 132 337 minecraft:shroomlight
fill 324 132 338 324 141 338 minecraft:cobblestone
fill 324 132 347 324 136 347 minecraft:cobblestone
fill 324 132 348 324 132 349 minecraft:shroomlight
fill 324 132 350 324 140 350 minecraft:cobblestone
fill 324 132 359 324 136 359 minecraft:cobblestone
fill 324 132 360 324 132 361 minecraft:shroomlight
fill 324 132 362 324 140 362 minecraft:cobblestone
fill 282 133 329 282 136 330 minecraft:cobblestone
fill 282 133 341 282 137 342 minecraft:cobblestone
fill 282 133 353 282 137 354 minecraft:cobblestone
setblock 283 133 329 minecraft:red_wool
fill 283 133 364 284 136 364 minecraft:cobblestone
setblock 284 133 329 minecraft:polished_andesite
fill 285 133 328 286 133 328 minecraft:polished_andesite
fill 285 133 330 286 133 330 minecraft:polished_andesite
fill 287 133 329 287 134 329 minecraft:polished_andesite
fill 290 133 322 291 136 322 minecraft:cobblestone
fill 295 133 364 296 137 364 minecraft:cobblestone
fill 302 133 322 303 137 322 minecraft:cobblestone
fill 304 133 357 304 134 357 minecraft:polished_andesite
fill 305 133 357 306 135 358 minecraft:cobblestone
fill 307 133 357 307 136 357 minecraft:cobblestone
fill 307 133 362 315 133 362 minecraft:polished_andesite
fill 307 133 364 308 136 364 minecraft:cobblestone
fill 308 133 357 315 133 357 minecraft:polished_andesite
fill 308 133 360 315 133 361 minecraft:polished_andesite
fill 309 133 358 315 133 359 minecraft:polished_andesite
fill 314 133 322 315 136 322 minecraft:cobblestone
fill 318 133 329 318 135 329 minecraft:polished_andesite
fill 319 133 328 320 133 328 minecraft:polished_andesite
fill 319 133 330 320 133 330 minecraft:polished_andesite
fill 319 133 364 320 140 364 minecraft:cobblestone
fill 320 133 329 321 133 329 minecraft:polished_andesite
setblock 322 133 329 minecraft:red_wool
fill 324 133 324 324 136 325 minecraft:cobblestone
fill 324 133 336 324 140 337 minecraft:cobblestone
fill 324 133 348 324 140 349 minecraft:cobblestone
fill 324 133 360 324 140 361 minecraft:cobblestone
setblock 284 134 329 minecraft:red_wool
fill 286 134 328 288 134 328 minecraft:polished_andesite
fill 286 134 330 288 134 330 minecraft:polished_andesite
fill 288 134 329 289 136 329 minecraft:polished_andesite
fill 304 134 359 305 134 359 minecraft:polished_andesite
fill 306 134 356 307 135 356 minecraft:cobblestone
fill 306 134 359 307 135 359 minecraft:cobblestone
fill 307 134 358 307 135 358 minecraft:cobblestone
fill 308 134 357 315 134 357 minecraft:red_wool
fill 310 134 363 312 137 363 minecraft:shroomlight
fill 316 134 329 317 136 329 minecraft:polished_andesite
fill 317 134 328 319 134 328 minecraft:polished_andesite
fill 317 134 330 319 134 330 minecraft:polished_andesite
setblock 320 134 329 minecraft:polished_andesite
setblock 321 134 329 minecraft:red_wool
setblock 285 135 325 minecraft:light[level=15]
setblock 285 135 332 minecraft:light[level=12]
setblock 285 135 333 minecraft:light[level=15]
setblock 285 135 339 minecraft:light[level=12]
setblock 285 135 341 minecraft:light[level=15]
setblock 285 135 346 minecraft:light[level=12]
setblock 285 135 349 minecraft:light[level=15]
setblock 285 135 353 minecraft:light[level=12]
setblock 285 135 357 minecraft:light[level=15]
setblock 285 135 360 minecraft:light[level=12]
fill 286 135 329 287 135 329 minecraft:red_wool
fill 288 135 328 289 135 328 minecraft:polished_andesite
fill 288 135 330 289 135 330 minecraft:polished_andesite
fill 290 135 329 290 137 329 minecraft:polished_andesite
setblock 292 135 325 minecraft:light[level=12]
setblock 292 135 332 minecraft:light[level=12]
setblock 292 135 339 minecraft:light[level=12]
setblock 292 135 346 minecraft:light[level=12]
setblock 292 135 353 minecraft:light[level=12]
setblock 292 135 360 minecraft:light[level=12]
setblock 293 135 325 minecraft:light[level=15]
setblock 293 135 333 minecraft:light[level=15]
setblock 293 135 341 minecraft:light[level=15]
setblock 293 135 349 minecraft:light[level=15]
setblock 293 135 357 minecraft:light[level=15]
setblock 299 135 325 minecraft:light[level=12]
setblock 299 135 332 minecraft:light[level=12]
setblock 299 135 339 minecraft:light[level=12]
setblock 299 135 346 minecraft:light[level=12]
setblock 299 135 353 minecraft:light[level=12]
setblock 299 135 360 minecraft:light[level=12]
setblock 301 135 325 minecraft:light[level=15]
setblock 301 135 333 minecraft:light[level=15]
setblock 301 135 349 minecraft:light[level=15]
setblock 306 135 325 minecraft:light[level=12]
setblock 306 135 332 minecraft:light[level=12]
setblock 306 135 339 minecraft:light[level=12]
setblock 306 135 346 minecraft:light[level=12]
setblock 306 135 353 minecraft:light[level=12]
setblock 306 135 360 minecraft:light[level=12]
setblock 309 135 325 minecraft:light[level=15]
setblock 309 135 333 minecraft:light[level=15]
setblock 309 135 341 minecraft:light[level=15]
setblock 309 135 349 minecraft:light[level=15]
setblock 309 135 357 minecraft:light[level=15]
setblock 311 135 357 minecraft:polished_andesite
setblock 313 135 325 minecraft:light[level=12]
setblock 313 135 332 minecraft:light[level=12]
setblock 313 135 339 minecraft:light[level=12]
setblock 313 135 346 minecraft:light[level=12]
setblock 313 135 353 minecraft:light[level=12]
setblock 313 135 360 minecraft:light[level=12]
fill 315 135 329 315 137 329 minecraft:polished_andesite
setblock 315 135 357 minecraft:polished_andesite
fill 316 135 328 317 135 328 minecraft:polished_andesite
fill 316 135 330 317 135 330 minecraft:polished_andesite
setblock 317 135 325 minecraft:light[level=15]
setblock 317 135 333 minecraft:light[level=15]
setblock 317 135 341 minecraft:light[level=15]
setblock 317 135 349 minecraft:light[level=15]
setblock 317 135 357 minecraft:light[level=15]
setblock 319 135 329 minecraft:red_wool
setblock 320 135 325 minecraft:light[level=12]
setblock 320 135 332 minecraft:light[level=12]
setblock 320 135 339 minecraft:light[level=12]
setblock 320 135 346 minecraft:light[level=12]
setblock 320 135 353 minecraft:light[level=12]
setblock 320 135 360 minecraft:light[level=12]
setblock 287 136 329 minecraft:red_wool
fill 289 136 328 291 136 328 minecraft:polished_andesite
fill 289 136 330 291 136 330 minecraft:polished_andesite
fill 291 136 329 292 137 329 minecraft:polished_andesite
setblock 305 136 357 minecraft:cobblestone
setblock 306 136 358 minecraft:cobblestone
fill 313 136 329 314 138 329 minecraft:polished_andesite
fill 314 136 328 316 136 328 minecraft:polished_andesite
fill 314 136 330 316 136 330 minecraft:polished_andesite
setblock 318 136 329 minecraft:red_wool
fill 282 137 322 282 137 324 minecraft:cobblestone
fill 282 137 325 282 137 326 minecraft:stone_bricks
fill 282 137 327 282 140 327 minecraft:cobblestone
setblock 282 137 328 minecraft:stone_bricks
fill 282 137 329 282 140 329 minecraft:cobblestone
fill 282 137 330 282 137 331 minecraft:stone_bricks
fill 282 137 332 282 140 336 minecraft:cobblestone
setblock 282 137 337 minecraft:stone_bricks
fill 282 137 338 282 140 339 minecraft:cobblestone
setblock 282 137 352 minecraft:stone_bricks
fill 282 137 356 282 140 356 minecraft:cobblestone
setblock 282 137 357 minecraft:stone_bricks
fill 282 137 358 282 140 363 minecraft:cobblestone
fill 282 137 364 283 137 364 minecraft:stone_bricks
setblock 283 137 322 minecraft:stone_bricks
fill 284 137 322 288 137 322 minecraft:cobblestone
fill 284 137 364 284 140 364 minecraft:cobblestone
setblock 289 137 329 minecraft:red_wool
fill 290 137 322 290 140 322 minecraft:cobblestone
setblock 291 137 322 minecraft:stone_bricks
fill 291 137 328 293 137 328 minecraft:polished_andesite
fill 291 137 330 293 137 330 minecraft:polished_andesite
fill 293 137 322 296 137 322 minecraft:cobblestone
fill 293 137 329 294 139 329 minecraft:polished_andesite
setblock 297 137 322 minecraft:stone_bricks
fill 298 137 322 299 140 322 minecraft:cobblestone
fill 298 137 364 302 138 364 minecraft:cobblestone
setblock 303 137 364 minecraft:stone_bricks
fill 304 137 364 305 140 364 minecraft:cobblestone
fill 307 137 364 307 140 364 minecraft:cobblestone
setblock 308 137 364 minecraft:stone_bricks
fill 310 137 364 314 137 364 minecraft:cobblestone
fill 311 137 329 312 139 329 minecraft:polished_andesite
fill 312 137 328 314 137 328 minecraft:polished_andesite
fill 312 137 330 314 137 330 minecraft:polished_andesite
setblock 314 137 322 minecraft:stone_bricks
fill 315 137 322 315 140 322 minecraft:cobblestone
setblock 315 137 364 minecraft:stone_bricks
setblock 316 137 322 minecraft:stone_bricks
setblock 316 137 329 minecraft:red_wool
fill 316 137 364 316 140 364 minecraft:cobblestone
setblock 317 137 364 minecraft:stone_bricks
fill 322 137 364 323 140 364 minecraft:cobblestone
fill 324 137 324 324 140 324 minecraft:cobblestone
fill 324 137 325 324 138 325 minecraft:stone_bricks
setblock 324 137 347 minecraft:stone_bricks
setblock 324 137 359 minecraft:stone_bricks
setblock 324 137 364 minecraft:stone_bricks
setblock 282 138 322 minecraft:stone_bricks
fill 282 138 323 282 140 325 minecraft:cobblestone
setblock 282 138 326 minecraft:stone_bricks
fill 282 138 328 282 142 328 minecraft:cobblestone
fill 282 138 330 282 141 331 minecraft:cobblestone
fill 282 138 337 282 140 337 minecraft:cobblestone
setblock 282 138 341 minecraft:stone_bricks
fill 282 138 342 282 141 342 minecraft:cobblestone
fill 282 138 352 282 140 352 minecraft:cobblestone
setblock 282 138 353 minecraft:stone_bricks
fill 282 138 354 282 141 354 minecraft:cobblestone
fill 282 138 357 282 140 357 minecraft:cobblestone
setblock 282 138 364 minecraft:stone_bricks
fill 283 138 322 287 138 322 minecraft:cobblestone
fill 283 138 364 283 140 364 minecraft:cobblestone
fill 288 138 322 288 139 322 minecraft:stone_bricks
fill 290 138 329 291 138 329 minecraft:red_wool
fill 291 138 322 291 141 322 minecraft:cobblestone
fill 292 138 322 293 138 322 minecraft:stone_bricks
fill 292 138 328 292 138 330 minecraft:polished_andesite
fill 293 138 328 295 138 328 minecraft:polished_andesite
fill 293 138 330 295 138 330 minecraft:polished_andesite
fill 294 138 322 297 140 322 minecraft:cobblestone
fill 295 138 329 296 139 329 minecraft:polished_andesite
setblock 295 138 364 minecraft:stone_bricks
fill 296 138 364 296 140 364 minecraft:cobblestone
setblock 300 138 322 minecraft:stone_bricks
setblock 302 138 322 minecraft:cobblestone
setblock 303 138 322 minecraft:stone_bricks
fill 303 138 364 303 140 364 minecraft:cobblestone
setblock 308 138 364 minecraft:cobblestone
fill 309 138 329 310 140 329 minecraft:polished_andesite
fill 310 138 328 313 138 328 minecraft:polished_andesite
fill 310 138 330 313 138 330 minecraft:polished_andesite
fill 310 138 364 311 140 364 minecraft:cobblestone
setblock 312 138 364 minecraft:stone_bricks
fill 313 138 364 315 140 364 minecraft:cobblestone
fill 314 138 322 314 140 322 minecraft:cobblestone
setblock 315 138 329 minecraft:red_wool
fill 316 138 322 318 140 322 minecraft:cobblestone
fill 317 138 364 317 140 364 minecraft:cobblestone
fill 319 138 322 320 138 322 minecraft:stone_bricks
fill 321 138 322 322 138 322 minecraft:cobblestone
setblock 321 138 364 minecraft:stone_bricks
setblock 323 138 322 minecraft:stone_bricks
fill 324 138 322 324 140 322 minecraft:cobblestone
setblock 324 138 335 minecraft:stone_bricks
setblock 324 138 339 minecraft:cobblestone
fill 324 138 340 324 139 340 minecraft:stone_bricks
fill 324 138 341 324 140 343 minecraft:cobblestone
setblock 324 138 344 minecraft:stone_bricks
fill 324 138 345 324 140 347 minecraft:cobblestone
setblock 324 138 351 minecraft:cobblestone
setblock 324 138 352 minecraft:stone_bricks
fill 324 138 353 324 140 353 minecraft:cobblestone
setblock 324 138 354 minecraft:stone_bricks
fill 324 138 355 324 140 359 minecraft:cobblestone
fill 324 138 364 324 140 364 minecraft:cobblestone
fill 282 139 322 285 140 322 minecraft:cobblestone
fill 282 139 326 282 140 326 minecraft:cobblestone
setblock 282 139 340 minecraft:stone_bricks
fill 282 139 341 282 140 341 minecraft:cobblestone
fill 282 139 353 282 140 353 minecraft:cobblestone
fill 282 139 364 282 140 364 minecraft:cobblestone
setblock 286 139 322 minecraft:stone_bricks
fill 286 139 364 289 140 364 minecraft:cobblestone
fill 287 139 322 287 140 322 minecraft:cobblestone
setblock 290 139 364 minecraft:stone_bricks
fill 291 139 364 293 140 364 minecraft:cobblestone
fill 292 139 322 293 140 322 minecraft:cobblestone
setblock 292 139 329 minecraft:red_wool
fill 294 139 328 297 139 328 minecraft:polished_andesite
fill 294 139 330 297 139 330 minecraft:polished_andesite
fill 295 139 364 295 140 364 minecraft:cobblestone
fill 297 139 329 300 140 329 minecraft:polished_andesite
fill 298 139 364 300 140 364 minecraft:cobblestone
fill 300 139 322 300 140 322 minecraft:cobblestone
fill 301 139 364 302 139 364 minecraft:stone_bricks
setblock 302 139 322 minecraft:stone_bricks
fill 303 139 322 303 140 322 minecraft:cobblestone
setblock 305 139 322 minecraft:stone_bricks
fill 305 139 329 308 140 329 minecraft:polished_andesite
fill 306 139 322 312 140 322 minecraft:cobblestone
setblock 306 139 364 minecraft:stone_bricks
fill 308 139 328 311 139 328 minecraft:polished_andesite
fill 308 139 330 311 139 330 minecraft:polished_andesite
fill 308 139 364 309 139 364 minecraft:stone_bricks
fill 312 139 364 312 140 364 minecraft:cobblestone
setblock 313 139 329 minecraft:red_wool
fill 319 139 322 320 140 322 minecraft:cobblestone
setblock 321 139 322 minecraft:stone_bricks
fill 321 139 364 321 140 364 minecraft:cobblestone
fill 322 139 322 323 140 322 minecraft:cobblestone
fill 324 139 325 324 141 325 minecraft:cobblestone
fill 324 139 335 324 140 335 minecraft:cobblestone
setblock 324 139 339 minecraft:stone_bricks
fill 324 139 344 324 140 344 minecraft:cobblestone
setblock 324 139 351 minecraft:stone_bricks
fill 324 139 352 324 140 352 minecraft:cobblestone
fill 324 139 354 324 141 354 minecraft:cobblestone
setblock 282 140 340 minecraft:cobblestone
fill 283 140 351 283 142 353 minecraft:yellow_wool
fill 284 140 332 284 145 334 minecraft:polished_andesite
fill 284 140 344 284 145 346 minecraft:polished_andesite
fill 284 140 356 284 145 358 minecraft:polished_andesite
setblock 286 140 322 minecraft:cobblestone
setblock 288 140 322 minecraft:cobblestone
fill 290 140 362 292 145 362 minecraft:polished_andesite
setblock 290 140 364 minecraft:cobblestone
fill 293 140 323 295 142 323 minecraft:red_wool
fill 293 140 329 295 140 329 minecraft:red_wool
fill 294 140 324 296 145 324 minecraft:polished_andesite
fill 295 140 363 297 142 363 minecraft:blue_wool
setblock 296 140 329 minecraft:polished_andesite
fill 297 140 328 308 140 328 minecraft:polished_andesite
fill 297 140 330 308 140 330 minecraft:polished_andesite
fill 301 140 329 304 141 329 minecraft:polished_andesite
fill 301 140 364 302 140 364 minecraft:cobblestone
setblock 302 140 322 minecraft:cobblestone
fill 302 140 362 304 145 362 minecraft:polished_andesite
setblock 305 140 322 minecraft:cobblestone
fill 306 140 324 308 145 324 minecraft:polished_andesite
setblock 306 140 364 minecraft:cobblestone
fill 308 140 364 309 140 364 minecraft:cobblestone
fill 311 140 329 312 140 329 minecraft:red_wool
fill 314 140 362 316 145 362 minecraft:polished_andesite
fill 318 140 324 320 145 324 minecraft:polished_andesite
setblock 321 140 322 minecraft:cobblestone
fill 322 140 332 322 145 334 minecraft:polished_andesite
fill 322 140 344 322 145 346 minecraft:polished_andesite
fill 322 140 356 322 145 358 minecraft:polished_andesite
fill 323 140 349 323 142 351 minecraft:red_wool
fill 324 140 339 324 140 340 minecraft:cobblestone
fill 324 140 351 324 141 351 minecraft:cobblestone
fill 282 141 322 282 141 327 minecraft:stone_bricks
fill 282 141 329 282 145 329 minecraft:stone_bricks
fill 282 141 332 282 141 341 minecraft:stone_bricks
fill 282 141 343 282 142 353 minecraft:stone_bricks
fill 282 141 355 282 145 358 minecraft:stone_bricks
setblock 282 141 359 minecraft:cobblestone
fill 282 141 360 282 145 364 minecraft:stone_bricks
fill 283 141 322 290 142 322 minecraft:stone_bricks
fill 283 141 364 287 141 364 minecraft:stone_bricks
setblock 285 141 325 minecraft:light[level=12]
setblock 285 141 332 minecraft:light[level=12]
setblock 285 141 339 minecraft:light[level=12]
setblock 285 141 346 minecraft:light[level=12]
setblock 285 141 353 minecraft:light[level=12]
setblock 285 141 360 minecraft:light[level=12]
setblock 288 141 364 minecraft:cobblestone
fill 289 141 364 304 141 364 minecraft:stone_bricks
fill 292 141 322 309 141 322 minecraft:stone_bricks
setblock 292 141 325 minecraft:light[level=12]
setblock 292 141 332 minecraft:light[level=12]
setblock 292 141 339 minecraft:light[level=12]
setblock 292 141 346 minecraft:light[level=12]
setblock 292 141 353 minecraft:light[level=12]
setblock 292 141 360 minecraft:light[level=12]
fill 295 141 329 297 141 329 minecraft:red_wool
fill 298 141 329 300 141 329 minecraft:polished_andesite
setblock 299 141 325 minecraft:light[level=12]
setblock 299 141 332 minecraft:light[level=12]
setblock 299 141 339 minecraft:light[level=12]
setblock 299 141 346 minecraft:light[level=12]
setblock 299 141 353 minecraft:light[level=12]
setblock 299 141 360 minecraft:light[level=12]
fill 301 141 328 304 141 328 minecraft:polished_andesite
fill 301 141 330 304 141 330 minecraft:polished_andesite
fill 305 141 329 307 141 329 minecraft:polished_andesite
setblock 305 141 364 minecraft:cobblestone
setblock 306 141 325 minecraft:light[level=12]
setblock 306 141 332 minecraft:light[level=12]
setblock 306 141 339 minecraft:light[level=12]
setblock 306 141 346 minecraft:light[level=12]
setblock 306 141 353 minecraft:light[level=12]
setblock 306 141 360 minecraft:light[level=12]
fill 306 141 364 324 141 364 minecraft:stone_bricks
fill 308 141 329 310 141 329 minecraft:red_wool
setblock 310 141 322 minecraft:cobblestone
fill 311 141 322 312 196 322 minecraft:stone_bricks
setblock 313 141 325 minecraft:light[level=12]
setblock 313 141 332 minecraft:light[level=12]
setblock 313 141 339 minecraft:light[level=12]
setblock 313 141 346 minecraft:light[level=12]
setblock 313 141 353 minecraft:light[level=12]
setblock 313 141 360 minecraft:light[level=12]
fill 314 141 322 315 145 322 minecraft:stone_bricks
fill 316 141 322 317 141 322 minecraft:cobblestone
fill 318 141 322 322 141 322 minecraft:stone_bricks
setblock 320 141 325 minecraft:light[level=12]
setblock 320 141 332 minecraft:light[level=12]
setblock 320 141 339 minecraft:light[level=12]
setblock 320 141 346 minecraft:light[level=12]
setblock 320 141 353 minecraft:light[level=12]
setblock 320 141 360 minecraft:light[level=12]
fill 323 141 322 323 142 322 minecraft:cobblestone
fill 324 141 322 324 145 324 minecraft:stone_bricks
fill 324 141 327 324 196 327 minecraft:stone_bricks
fill 324 141 328 324 141 330 minecraft:cobblestone
fill 324 141 331 324 142 333 minecraft:stone_bricks
setblock 324 141 334 minecraft:cobblestone
fill 324 141 335 324 145 336 minecraft:stone_bricks
setblock 324 141 337 minecraft:cobblestone
fill 324 141 339 324 142 348 minecraft:stone_bricks
setblock 324 141 349 minecraft:cobblestone
fill 324 141 350 324 145 350 minecraft:stone_bricks
fill 324 141 352 324 196 353 minecraft:stone_bricks
fill 324 141 355 324 141 363 minecraft:stone_bricks
fill 282 142 322 282 142 324 minecraft:stone_bricks
setblock 282 142 325 minecraft:cobblestone
fill 282 142 326 282 192 327 minecraft:stone_bricks
fill 282 142 330 282 142 339 minecraft:stone_bricks
setblock 282 142 340 minecraft:cobblestone
fill 282 142 341 282 145 342 minecraft:stone_bricks
fill 282 142 354 282 145 354 minecraft:stone_bricks
fill 282 142 359 282 196 359 minecraft:stone_bricks
fill 283 142 364 284 142 364 minecraft:stone_bricks
setblock 285 142 364 minecraft:cobblestone
fill 286 142 345 286 145 345 minecraft:iron_bars
fill 286 142 364 288 192 364 minecraft:stone_bricks
setblock 289 142 364 minecraft:cobblestone
fill 290 142 364 299 145 364 minecraft:stone_bricks
fill 291 142 322 295 142 322 minecraft:stone_bricks
fill 296 142 322 298 142 322 minecraft:cobblestone
fill 298 142 329 307 142 329 minecraft:red_wool
fill 299 142 322 304 142 322 minecraft:stone_bricks
setblock 300 142 364 minecraft:cobblestone
fill 301 142 364 313 142 364 minecraft:stone_bricks
setblock 305 142 322 minecraft:cobblestone
fill 306 142 322 310 142 322 minecraft:stone_bricks
fill 314 142 364 315 142 364 minecraft:cobblestone
fill 316 142 322 317 145 322 minecraft:stone_bricks
fill 316 142 364 317 196 364 minecraft:stone_bricks
setblock 318 142 322 minecraft:cobblestone
setblock 318 142 364 minecraft:cobblestone
fill 319 142 322 322 192 322 minecraft:stone_bricks
fill 319 142 364 324 142 364 minecraft:stone_bricks
fill 324 142 325 324 142 326 minecraft:stone_bricks
fill 324 142 328 324 193 330 minecraft:stone_bricks
fill 324 142 334 324 196 334 minecraft:stone_bricks
fill 324 142 337 324 142 338 minecraft:stone_bricks
fill 324 142 349 324 145 349 minecraft:stone_bricks
fill 324 142 351 324 197 351 minecraft:stone_bricks
fill 324 142 354 324 142 359 minecraft:stone_bricks
setblock 324 142 360 minecraft:cobblestone
fill 324 142 361 324 142 363 minecraft:stone_bricks
fill 282 143 322 282 192 322 minecraft:stone_bricks
fill 282 143 323 282 143 324 minecraft:cobblestone
fill 282 143 325 282 196 325 minecraft:stone_bricks
fill 282 143 328 282 145 328 minecraft:stone_bricks
fill 282 143 330 282 145 338 minecraft:stone_bricks
setblock 282 143 339 minecraft:cobblestone
fill 282 143 340 282 145 340 minecraft:stone_bricks
fill 282 143 343 282 145 346 minecraft:stone_bricks
setblock 282 143 347 minecraft:cobblestone
fill 282 143 348 282 145 353 minecraft:stone_bricks
fill 283 143 322 284 143 322 minecraft:cobblestone
fill 283 143 351 283 148 351 minecraft:yellow_wool
fill 283 143 352 283 145 352 minecraft:gold_block
fill 283 143 353 283 148 353 minecraft:yellow_wool
fill 283 143 364 283 145 364 minecraft:stone_bricks
setblock 284 143 364 minecraft:cobblestone
fill 285 143 322 290 145 322 minecraft:stone_bricks
setblock 285 143 325 minecraft:light[level=15]
setblock 285 143 333 minecraft:light[level=15]
setblock 285 143 341 minecraft:light[level=15]
setblock 285 143 349 minecraft:light[level=15]
setblock 285 143 357 minecraft:light[level=15]
fill 285 143 364 285 145 364 minecraft:stone_bricks
fill 289 143 364 289 196 364 minecraft:stone_bricks
setblock 291 143 322 minecraft:cobblestone
fill 292 143 322 299 145 322 minecraft:stone_bricks
fill 293 143 323 293 148 323 minecraft:red_wool
setblock 293 143 325 minecraft:light[level=15]
setblock 293 143 333 minecraft:light[level=15]
setblock 293 143 341 minecraft:light[level=15]
setblock 293 143 349 minecraft:light[level=15]
setblock 293 143 357 minecraft:light[level=15]
fill 294 143 323 294 145 323 minecraft:gold_block
fill 295 143 323 295 148 323 minecraft:red_wool
fill 295 143 363 295 148 363 minecraft:blue_wool
fill 296 143 363 296 145 363 minecraft:gold_block
fill 297 143 363 297 148 363 minecraft:blue_wool
fill 299 143 324 299 154 324 minecraft:red_wool
setblock 300 143 322 minecraft:cobblestone
fill 300 143 364 302 194 364 minecraft:stone_bricks
fill 301 143 322 302 145 322 minecraft:stone_bricks
setblock 301 143 325 minecraft:light[level=15]
setblock 301 143 333 minecraft:light[level=15]
setblock 301 143 349 minecraft:light[level=15]
setblock 301 143 357 minecraft:light[level=15]
setblock 303 143 322 minecraft:cobblestone
setblock 303 143 364 minecraft:cobblestone
fill 304 143 322 308 145 322 minecraft:stone_bricks
fill 304 143 364 304 197 364 minecraft:stone_bricks
setblock 305 143 364 minecraft:cobblestone
fill 306 143 364 315 145 364 minecraft:stone_bricks
setblock 309 143 322 minecraft:cobblestone
setblock 309 143 325 minecraft:light[level=15]
setblock 309 143 333 minecraft:light[level=15]
setblock 309 143 341 minecraft:light[level=15]
setblock 309 143 349 minecraft:light[level=15]
setblock 309 143 357 minecraft:light[level=15]
fill 310 143 322 310 193 322 minecraft:stone_bricks
fill 313 143 322 313 145 322 minecraft:stone_bricks
setblock 317 143 325 minecraft:light[level=15]
setblock 317 143 333 minecraft:light[level=15]
setblock 317 143 341 minecraft:light[level=15]
setblock 317 143 349 minecraft:light[level=15]
setblock 317 143 357 minecraft:light[level=15]
fill 318 143 322 318 196 322 minecraft:stone_bricks
fill 318 143 364 323 145 364 minecraft:stone_bricks
fill 323 143 322 323 196 322 minecraft:stone_bricks
fill 323 143 349 323 148 349 minecraft:red_wool
fill 323 143 350 323 145 350 minecraft:gold_block
fill 323 143 351 323 148 351 minecraft:red_wool
setblock 324 143 325 minecraft:cobblestone
fill 324 143 326 324 145 326 minecraft:stone_bricks
setblock 324 143 331 minecraft:cobblestone
fill 324 143 332 324 196 333 minecraft:stone_bricks
fill 324 143 337 324 145 337 minecraft:stone_bricks
setblock 324 143 338 minecraft:cobblestone
fill 324 143 339 324 192 346 minecraft:stone_bricks
setblock 324 143 347 minecraft:cobblestone
fill 324 143 348 324 145 348 minecraft:stone_bricks
setblock 324 143 354 minecraft:cobblestone
fill 324 143 355 324 145 362 minecraft:stone_bricks
fill 324 143 363 324 143 364 minecraft:cobblestone
fill 282 144 323 282 196 324 minecraft:stone_bricks
fill 282 144 339 282 196 339 minecraft:stone_bricks
fill 282 144 347 282 196 347 minecraft:stone_bricks
fill 283 144 322 284 192 322 minecraft:stone_bricks
fill 284 144 364 284 145 364 minecraft:stone_bricks
fill 291 144 322 291 145 322 minecraft:stone_bricks
fill 297 144 324 298 154 324 minecraft:red_wool
fill 300 144 322 300 196 322 minecraft:stone_bricks
fill 300 144 324 301 154 324 minecraft:red_wool
fill 303 144 322 303 145 322 minecraft:stone_bricks
fill 303 144 364 303 196 364 minecraft:stone_bricks
fill 305 144 364 305 196 364 minecraft:stone_bricks
fill 309 144 322 309 196 322 minecraft:stone_bricks
fill 324 144 325 324 145 325 minecraft:stone_bricks
fill 324 144 331 324 196 331 minecraft:stone_bricks
fill 324 144 338 324 145 338 minecraft:stone_bricks
fill 324 144 347 324 145 347 minecraft:stone_bricks
fill 324 144 354 324 196 354 minecraft:stone_bricks
fill 324 144 363 324 193 364 minecraft:stone_bricks
fill 283 145 326 283 145 331 minecraft:cobblestone
fill 283 145 338 283 145 343 minecraft:cobblestone
setblock 283 145 350 minecraft:cobblestone
fill 283 145 354 283 145 355 minecraft:cobblestone
fill 283 145 362 283 145 363 minecraft:cobblestone
fill 284 145 363 287 145 363 minecraft:cobblestone
fill 287 145 323 292 145 323 minecraft:cobblestone
fill 290 145 360 290 146 361 minecraft:iron_bars
setblock 294 145 363 minecraft:cobblestone
fill 298 145 363 299 145 363 minecraft:cobblestone
fill 299 145 323 304 145 323 minecraft:cobblestone
fill 306 145 363 311 145 363 minecraft:cobblestone
fill 311 145 323 316 145 323 minecraft:cobblestone
fill 318 145 363 323 145 363 minecraft:cobblestone
fill 323 145 323 323 145 328 minecraft:cobblestone
fill 323 145 335 323 145 340 minecraft:cobblestone
fill 323 145 347 323 145 348 minecraft:cobblestone
setblock 323 145 352 minecraft:cobblestone
fill 323 145 359 323 145 362 minecraft:cobblestone
fill 282 146 328 282 151 331 minecraft:shroomlight
fill 282 146 332 282 193 338 minecraft:stone_bricks
fill 282 146 340 282 151 343 minecraft:shroomlight
fill 282 146 344 282 147 346 minecraft:stone_bricks
fill 282 146 348 282 194 351 minecraft:stone_bricks
fill 282 146 352 282 151 355 minecraft:shroomlight
fill 282 146 356 282 196 358 minecraft:stone_bricks
fill 282 146 360 282 192 363 minecraft:stone_bricks
fill 282 146 364 285 151 364 minecraft:shroomlight
fill 283 146 342 286 146 344 minecraft:cobblestone
fill 283 146 348 286 146 348 minecraft:cobblestone
fill 283 146 352 283 148 352 minecraft:yellow_wool
fill 284 146 345 286 146 347 minecraft:cobblestone
fill 285 146 322 288 192 322 minecraft:stone_bricks
fill 289 146 322 292 151 322 minecraft:shroomlight
setblock 290 146 362 minecraft:iron_bars
fill 290 146 364 293 192 364 minecraft:stone_bricks
fill 293 146 322 299 192 322 minecraft:stone_bricks
fill 294 146 323 294 148 323 minecraft:red_wool
fill 294 146 364 297 151 364 minecraft:shroomlight
fill 296 146 363 296 148 363 minecraft:blue_wool
fill 298 146 364 299 193 364 minecraft:stone_bricks
fill 301 146 322 304 151 322 minecraft:shroomlight
fill 305 146 322 308 192 322 minecraft:stone_bricks
fill 306 146 364 309 151 364 minecraft:shroomlight
fill 310 146 364 315 192 364 minecraft:stone_bricks
fill 313 146 322 316 151 322 minecraft:shroomlight
fill 317 146 322 317 196 322 minecraft:stone_bricks
fill 318 146 364 321 151 364 minecraft:shroomlight
fill 322 146 364 323 196 364 minecraft:stone_bricks
fill 323 146 350 323 148 350 minecraft:red_wool
fill 324 146 322 324 193 322 minecraft:stone_bricks
fill 324 146 323 324 151 326 minecraft:shroomlight
fill 324 146 335 324 151 338 minecraft:shroomlight
fill 324 146 347 324 151 350 minecraft:shroomlight
fill 324 146 355 324 192 358 minecraft:stone_bricks
fill 324 146 359 324 151 362 minecraft:shroomlight
fill 283 147 342 286 147 344 minecraft:polished_andesite
fill 283 147 348 286 147 348 minecraft:polished_andesite
fill 284 147 345 286 147 347 minecraft:polished_andesite
setblock 285 147 325 minecraft:light[level=12]
setblock 285 147 332 minecraft:light[level=12]
setblock 285 147 339 minecraft:light[level=12]
setblock 285 147 353 minecraft:light[level=12]
setblock 285 147 360 minecraft:light[level=12]
setblock 292 147 325 minecraft:light[level=12]
setblock 292 147 332 minecraft:light[level=12]
setblock 292 147 339 minecraft:light[level=12]
setblock 292 147 346 minecraft:light[level=12]
setblock 292 147 353 minecraft:light[level=12]
setblock 292 147 360 minecraft:light[level=12]
setblock 299 147 325 minecraft:light[level=12]
setblock 299 147 332 minecraft:light[level=12]
setblock 299 147 339 minecraft:light[level=12]
setblock 299 147 346 minecraft:light[level=12]
setblock 299 147 353 minecraft:light[level=12]
setblock 299 147 360 minecraft:light[level=12]
setblock 306 147 325 minecraft:light[level=12]
setblock 306 147 332 minecraft:light[level=12]
setblock 306 147 339 minecraft:light[level=12]
setblock 306 147 346 minecraft:light[level=12]
setblock 306 147 353 minecraft:light[level=12]
setblock 306 147 360 minecraft:light[level=12]
setblock 313 147 325 minecraft:light[level=12]
setblock 313 147 332 minecraft:light[level=12]
setblock 313 147 339 minecraft:light[level=12]
setblock 313 147 346 minecraft:light[level=12]
setblock 313 147 353 minecraft:light[level=12]
setblock 313 147 360 minecraft:light[level=12]
setblock 320 147 325 minecraft:light[level=12]
setblock 320 147 332 minecraft:light[level=12]
setblock 320 147 339 minecraft:light[level=12]
setblock 320 147 346 minecraft:light[level=12]
setblock 320 147 353 minecraft:light[level=12]
setblock 320 147 360 minecraft:light[level=12]
fill 282 148 344 282 151 346 minecraft:shroomlight
fill 286 148 342 286 148 348 minecraft:red_wool
setblock 286 149 342 minecraft:polished_andesite
setblock 286 149 345 minecraft:polished_andesite
setblock 286 149 348 minecraft:polished_andesite
fill 295 149 323 295 163 323 minecraft:polished_andesite
setblock 285 151 325 minecraft:light[level=15]
setblock 285 151 333 minecraft:light[level=15]
setblock 285 151 341 minecraft:light[level=15]
setblock 285 151 349 minecraft:light[level=15]
setblock 285 151 357 minecraft:light[level=15]
setblock 293 151 325 minecraft:light[level=15]
setblock 293 151 333 minecraft:light[level=15]
setblock 293 151 341 minecraft:light[level=15]
setblock 293 151 349 minecraft:light[level=15]
setblock 293 151 357 minecraft:light[level=15]
setblock 301 151 325 minecraft:light[level=15]
setblock 301 151 333 minecraft:light[level=15]
setblock 301 151 349 minecraft:light[level=15]
setblock 301 151 357 minecraft:light[level=15]
setblock 309 151 325 minecraft:light[level=15]
setblock 309 151 333 minecraft:light[level=15]
setblock 309 151 341 minecraft:light[level=15]
setblock 309 151 349 minecraft:light[level=15]
setblock 309 151 357 minecraft:light[level=15]
setblock 317 151 325 minecraft:light[level=15]
setblock 317 151 333 minecraft:light[level=15]
setblock 317 151 341 minecraft:light[level=15]
setblock 317 151 349 minecraft:light[level=15]
setblock 317 151 357 minecraft:light[level=15]
fill 282 152 328 282 185 328 minecraft:stone_bricks
fill 282 152 329 282 152 330 minecraft:shroomlight
fill 282 152 331 282 185 331 minecraft:stone_bricks
fill 282 152 340 282 185 340 minecraft:stone_bricks
fill 282 152 341 282 152 342 minecraft:shroomlight
fill 282 152 343 282 185 346 minecraft:stone_bricks
fill 282 152 352 282 185 352 minecraft:stone_bricks
fill 282 152 353 282 152 354 minecraft:shroomlight
fill 282 152 355 282 185 355 minecraft:stone_bricks
fill 282 152 364 282 185 364 minecraft:stone_bricks
fill 283 152 364 284 152 364 minecraft:shroomlight
fill 285 152 364 285 185 364 minecraft:stone_bricks
fill 289 152 322 289 185 322 minecraft:stone_bricks
fill 290 152 322 291 152 322 minecraft:shroomlight
fill 292 152 322 292 185 322 minecraft:stone_bricks
fill 294 152 364 294 185 364 minecraft:stone_bricks
fill 295 152 364 296 152 364 minecraft:shroomlight
fill 297 152 364 297 185 364 minecraft:stone_bricks
fill 301 152 322 301 185 322 minecraft:stone_bricks
fill 302 152 322 303 152 322 minecraft:shroomlight
fill 304 152 322 304 185 322 minecraft:stone_bricks
fill 306 152 364 306 185 364 minecraft:stone_bricks
fill 307 152 364 308 152 364 minecraft:shroomlight
fill 309 152 364 309 185 364 minecraft:stone_bricks
fill 313 152 322 313 185 322 minecraft:stone_bricks
fill 314 152 322 315 152 322 minecraft:shroomlight
fill 316 152 322 316 185 322 minecraft:stone_bricks
fill 318 152 364 318 185 364 minecraft:stone_bricks
fill 319 152 364 320 152 364 minecraft:shroomlight
fill 321 152 364 321 185 364 minecraft:stone_bricks
fill 324 152 323 324 185 323 minecraft:stone_bricks
fill 324 152 324 324 152 325 minecraft:shroomlight
fill 324 152 326 324 185 326 minecraft:stone_bricks
fill 324 152 335 324 185 335 minecraft:stone_bricks
fill 324 152 336 324 152 337 minecraft:shroomlight
fill 324 152 338 324 185 338 minecraft:stone_bricks
fill 324 152 347 324 185 347 minecraft:stone_bricks
fill 324 152 348 324 152 349 minecraft:shroomlight
fill 324 152 350 324 185 350 minecraft:stone_bricks
fill 324 152 359 324 185 359 minecraft:stone_bricks
fill 324 152 360 324 152 361 minecraft:shroomlight
fill 324 152 362 324 185 362 minecraft:stone_bricks
fill 282 153 329 282 185 330 minecraft:stone_bricks
fill 282 153 341 282 185 342 minecraft:stone_bricks
fill 282 153 353 282 185 354 minecraft:stone_bricks
fill 283 153 364 284 185 364 minecraft:stone_bricks
setblock 285 153 325 minecraft:light[level=12]
setblock 285 153 332 minecraft:light[level=12]
setblock 285 153 339 minecraft:light[level=12]
setblock 285 153 346 minecraft:light[level=12]
setblock 285 153 353 minecraft:light[level=12]
setblock 285 153 360 minecraft:light[level=12]
fill 290 153 322 291 185 322 minecraft:stone_bricks
setblock 292 153 325 minecraft:light[level=12]
setblock 292 153 332 minecraft:light[level=12]
setblock 292 153 339 minecraft:light[level=12]
setblock 292 153 346 minecraft:light[level=12]
setblock 292 153 353 minecraft:light[level=12]
setblock 292 153 360 minecraft:light[level=12]
fill 295 153 364 296 185 364 minecraft:stone_bricks
setblock 299 153 325 minecraft:light[level=12]
setblock 299 153 332 minecraft:light[level=12]
setblock 299 153 339 minecraft:light[level=12]
setblock 299 153 346 minecraft:light[level=12]
setblock 299 153 353 minecraft:light[level=12]
setblock 299 153 360 minecraft:light[level=12]
fill 302 153 322 303 185 322 minecraft:stone_bricks
setblock 306 153 325 minecraft:light[level=12]
setblock 306 153 332 minecraft:light[level=12]
setblock 306 153 339 minecraft:light[level=12]
setblock 306 153 346 minecraft:light[level=12]
setblock 306 153 353 minecraft:light[level=12]
setblock 306 153 360 minecraft:light[level=12]
fill 307 153 364 308 185 364 minecraft:stone_bricks
setblock 313 153 325 minecraft:light[level=12]
setblock 313 153 332 minecraft:light[level=12]
setblock 313 153 339 minecraft:light[level=12]
setblock 313 153 346 minecraft:light[level=12]
setblock 313 153 353 minecraft:light[level=12]
setblock 313 153 360 minecraft:light[level=12]
fill 314 153 322 315 185 322 minecraft:stone_bricks
fill 319 153 364 320 185 364 minecraft:stone_bricks
setblock 320 153 325 minecraft:light[level=12]
setblock 320 153 332 minecraft:light[level=12]
setblock 320 153 339 minecraft:light[level=12]
setblock 320 153 346 minecraft:light[level=12]
setblock 320 153 353 minecraft:light[level=12]
setblock 320 153 360 minecraft:light[level=12]
fill 324 153 324 324 185 325 minecraft:stone_bricks
fill 324 153 336 324 185 337 minecraft:stone_bricks
fill 324 153 348 324 185 349 minecraft:stone_bricks
fill 324 153 360 324 185 361 minecraft:stone_bricks
fill 296 155 324 302 156 324 minecraft:iron_bars
fill 304 157 359 304 160 359 minecraft:iron_bars
fill 313 157 323 313 158 325 minecraft:iron_bars
setblock 285 159 325 minecraft:light[level=15]
setblock 285 159 332 minecraft:light[level=12]
setblock 285 159 333 minecraft:light[level=15]
setblock 285 159 339 minecraft:light[level=12]
setblock 285 159 341 minecraft:light[level=15]
setblock 285 159 346 minecraft:light[level=12]
setblock 285 159 349 minecraft:light[level=15]
setblock 285 159 353 minecraft:light[level=12]
setblock 285 159 357 minecraft:light[level=15]
setblock 285 159 360 minecraft:light[level=12]
setblock 292 159 325 minecraft:light[level=12]
setblock 292 159 332 minecraft:light[level=12]
setblock 292 159 339 minecraft:light[level=12]
setblock 292 159 346 minecraft:light[level=12]
setblock 292 159 353 minecraft:light[level=12]
setblock 292 159 360 minecraft:light[level=12]
setblock 293 159 325 minecraft:light[level=15]
setblock 293 159 333 minecraft:light[level=15]
setblock 293 159 341 minecraft:light[level=15]
setblock 293 159 349 minecraft:light[level=15]
setblock 293 159 357 minecraft:light[level=15]
setblock 299 159 325 minecraft:light[level=12]
setblock 299 159 332 minecraft:light[level=12]
setblock 299 159 339 minecraft:light[level=12]
setblock 299 159 346 minecraft:light[level=12]
setblock 299 159 353 minecraft:light[level=12]
setblock 299 159 360 minecraft:light[level=12]
setblock 301 159 325 minecraft:light[level=15]
setblock 301 159 333 minecraft:light[level=15]
setblock 301 159 349 minecraft:light[level=15]
setblock 301 159 357 minecraft:light[level=15]
setblock 306 159 325 minecraft:light[level=12]
setblock 306 159 332 minecraft:light[level=12]
setblock 306 159 339 minecraft:light[level=12]
setblock 306 159 346 minecraft:light[level=12]
setblock 306 159 353 minecraft:light[level=12]
setblock 306 159 360 minecraft:light[level=12]
setblock 309 159 325 minecraft:light[level=15]
setblock 309 159 333 minecraft:light[level=15]
setblock 309 159 341 minecraft:light[level=15]
setblock 309 159 349 minecraft:light[level=15]
setblock 309 159 357 minecraft:light[level=15]
setblock 313 159 325 minecraft:light[level=12]
setblock 313 159 332 minecraft:light[level=12]
setblock 313 159 339 minecraft:light[level=12]
setblock 313 159 346 minecraft:light[level=12]
setblock 313 159 353 minecraft:light[level=12]
setblock 313 159 360 minecraft:light[level=12]
setblock 317 159 325 minecraft:light[level=15]
setblock 317 159 333 minecraft:light[level=15]
setblock 317 159 341 minecraft:light[level=15]
setblock 317 159 349 minecraft:light[level=15]
setblock 317 159 357 minecraft:light[level=15]
setblock 320 159 325 minecraft:light[level=12]
setblock 320 159 332 minecraft:light[level=12]
setblock 320 159 339 minecraft:light[level=12]
setblock 320 159 346 minecraft:light[level=12]
setblock 320 159 353 minecraft:light[level=12]
setblock 320 159 360 minecraft:light[level=12]
fill 284 160 332 284 163 334 minecraft:polished_andesite
fill 284 160 344 284 163 346 minecraft:polished_andesite
fill 284 160 356 284 163 358 minecraft:polished_andesite
fill 290 160 362 292 163 362 minecraft:polished_andesite
fill 294 160 324 296 163 324 minecraft:polished_andesite
fill 302 160 362 304 163 362 minecraft:polished_andesite
fill 306 160 324 308 163 324 minecraft:polished_andesite
fill 314 160 362 316 163 362 minecraft:polished_andesite
fill 318 160 324 320 163 324 minecraft:polished_andesite
fill 322 160 332 322 163 334 minecraft:polished_andesite
fill 322 160 344 322 163 346 minecraft:polished_andesite
fill 322 160 356 322 163 358 minecraft:polished_andesite
fill 285 161 345 285 162 345 minecraft:iron_bars
fill 301 161 359 301 161 362 minecraft:cobblestone
fill 302 161 359 307 161 361 minecraft:cobblestone
fill 305 161 362 307 161 362 minecraft:cobblestone
fill 301 162 359 301 162 362 minecraft:polished_andesite
fill 302 162 359 307 162 361 minecraft:polished_andesite
fill 305 162 362 307 162 362 minecraft:polished_andesite
fill 301 163 359 307 163 359 minecraft:red_wool
fill 301 163 363 302 163 363 minecraft:polished_andesite
fill 303 163 363 305 166 363 minecraft:shroomlight
setblock 285 165 325 minecraft:light[level=12]
setblock 285 165 332 minecraft:light[level=12]
setblock 285 165 339 minecraft:light[level=12]
setblock 285 165 346 minecraft:light[level=12]
setblock 285 165 353 minecraft:light[level=12]
setblock 285 165 360 minecraft:light[level=12]
setblock 292 165 325 minecraft:light[level=12]
setblock 292 165 332 minecraft:light[level=12]
setblock 292 165 339 minecraft:light[level=12]
setblock 292 165 346 minecraft:light[level=12]
setblock 292 165 353 minecraft:light[level=12]
setblock 292 165 360 minecraft:light[level=12]
setblock 299 165 325 minecraft:light[level=12]
setblock 299 165 332 minecraft:light[level=12]
setblock 299 165 339 minecraft:light[level=12]
setblock 299 165 346 minecraft:light[level=12]
setblock 299 165 353 minecraft:light[level=12]
setblock 299 165 360 minecraft:light[level=12]
setblock 306 165 325 minecraft:light[level=12]
setblock 306 165 332 minecraft:light[level=12]
setblock 306 165 339 minecraft:light[level=12]
setblock 306 165 346 minecraft:light[level=12]
setblock 306 165 353 minecraft:light[level=12]
setblock 306 165 360 minecraft:light[level=12]
setblock 313 165 325 minecraft:light[level=12]
setblock 313 165 332 minecraft:light[level=12]
setblock 313 165 339 minecraft:light[level=12]
setblock 313 165 346 minecraft:light[level=12]
setblock 313 165 353 minecraft:light[level=12]
setblock 313 165 360 minecraft:light[level=12]
setblock 320 165 325 minecraft:light[level=12]
setblock 320 165 332 minecraft:light[level=12]
setblock 320 165 339 minecraft:light[level=12]
setblock 320 165 346 minecraft:light[level=12]
setblock 320 165 353 minecraft:light[level=12]
setblock 320 165 360 minecraft:light[level=12]
setblock 285 167 325 minecraft:light[level=15]
setblock 285 167 333 minecraft:light[level=15]
setblock 285 167 341 minecraft:light[level=15]
setblock 285 167 349 minecraft:light[level=15]
setblock 285 167 357 minecraft:light[level=15]
setblock 293 167 325 minecraft:light[level=15]
setblock 293 167 333 minecraft:light[level=15]
setblock 293 167 341 minecraft:light[level=15]
setblock 293 167 349 minecraft:light[level=15]
setblock 293 167 357 minecraft:light[level=15]
setblock 301 167 325 minecraft:light[level=15]
setblock 301 167 333 minecraft:light[level=15]
setblock 301 167 349 minecraft:light[level=15]
setblock 301 167 357 minecraft:light[level=15]
setblock 309 167 325 minecraft:light[level=15]
setblock 309 167 333 minecraft:light[level=15]
setblock 309 167 341 minecraft:light[level=15]
setblock 309 167 349 minecraft:light[level=15]
setblock 309 167 357 minecraft:light[level=15]
setblock 317 167 325 minecraft:light[level=15]
setblock 317 167 333 minecraft:light[level=15]
setblock 317 167 341 minecraft:light[level=15]
setblock 317 167 349 minecraft:light[level=15]
setblock 317 167 357 minecraft:light[level=15]
fill 293 169 337 293 171 343 minecraft:cobblestone
fill 294 169 336 294 171 337 minecraft:cobblestone
fill 294 169 338 297 169 342 minecraft:blue_stained_glass
fill 294 169 343 294 171 344 minecraft:cobblestone
fill 295 169 335 295 171 335 minecraft:cobblestone
fill 295 169 336 305 169 337 minecraft:blue_stained_glass
fill 295 169 343 305 169 344 minecraft:blue_stained_glass
fill 295 169 345 295 171 345 minecraft:cobblestone
fill 296 169 334 297 171 334 minecraft:cobblestone
fill 296 169 335 304 170 335 minecraft:blue_stained_glass
fill 296 169 345 304 170 345 minecraft:blue_stained_glass
fill 296 169 346 297 171 346 minecraft:cobblestone
fill 297 169 333 303 171 333 minecraft:cobblestone
fill 297 169 347 303 171 347 minecraft:cobblestone
fill 298 169 334 302 170 334 minecraft:blue_stained_glass
setblock 298 169 338 minecraft:blue_stained_glass
setblock 298 169 342 minecraft:blue_stained_glass
fill 298 169 346 302 170 346 minecraft:blue_stained_glass
fill 302 169 338 306 169 338 minecraft:blue_stained_glass
fill 302 169 342 306 169 342 minecraft:blue_stained_glass
fill 303 169 334 304 171 334 minecraft:cobblestone
fill 303 169 339 306 169 341 minecraft:blue_stained_glass
fill 303 169 346 304 171 346 minecraft:cobblestone
fill 305 169 335 305 171 335 minecraft:cobblestone
fill 305 169 345 305 171 345 minecraft:cobblestone
fill 306 169 336 306 171 337 minecraft:cobblestone
fill 306 169 343 306 171 344 minecraft:cobblestone
fill 307 169 337 307 171 343 minecraft:cobblestone
fill 283 170 323 283 170 324 minecraft:cobblestone
setblock 283 170 325 minecraft:moss_block
fill 283 170 326 283 170 328 minecraft:cobblestone
setblock 283 170 329 minecraft:moss_block
fill 283 170 330 283 170 332 minecraft:cobblestone
setblock 283 170 333 minecraft:moss_block
fill 283 170 334 283 170 336 minecraft:cobblestone
setblock 283 170 337 minecraft:moss_block
fill 283 170 338 283 170 340 minecraft:cobblestone
setblock 283 170 341 minecraft:moss_block
fill 283 170 342 283 170 344 minecraft:cobblestone
setblock 283 170 345 minecraft:moss_block
fill 283 170 346 283 170 348 minecraft:cobblestone
setblock 283 170 349 minecraft:moss_block
fill 283 170 350 283 170 352 minecraft:cobblestone
setblock 283 170 353 minecraft:moss_block
fill 283 170 354 283 170 356 minecraft:cobblestone
setblock 283 170 357 minecraft:moss_block
fill 283 170 358 283 170 360 minecraft:cobblestone
setblock 283 170 361 minecraft:moss_block
fill 283 170 362 284 170 363 minecraft:cobblestone
setblock 284 170 323 minecraft:cobblestone
setblock 284 170 324 minecraft:moss_block
fill 284 170 325 284 170 327 minecraft:cobblestone
setblock 284 170 328 minecraft:moss_block
fill 284 170 329 284 170 331 minecraft:cobblestone
setblock 284 170 332 minecraft:moss_block
fill 284 170 333 284 170 335 minecraft:cobblestone
setblock 284 170 336 minecraft:moss_block
fill 284 170 337 284 170 339 minecraft:cobblestone
setblock 284 170 340 minecraft:moss_block
fill 284 170 341 284 170 343 minecraft:cobblestone
setblock 284 170 344 minecraft:moss_block
fill 284 170 345 284 170 347 minecraft:cobblestone
setblock 284 170 348 minecraft:moss_block
fill 284 170 349 284 170 351 minecraft:cobblestone
setblock 284 170 352 minecraft:moss_block
fill 284 170 353 284 170 355 minecraft:cobblestone
setblock 284 170 356 minecraft:moss_block
fill 284 170 357 284 170 359 minecraft:cobblestone
setblock 284 170 360 minecraft:moss_block
fill 284 170 361 286 170 361 minecraft:cobblestone
setblock 285 170 323 minecraft:moss_block
fill 285 170 324 285 170 326 minecraft:cobblestone
setblock 285 170 327 minecraft:moss_block
fill 285 170 328 285 170 330 minecraft:cobblestone
setblock 285 170 331 minecraft:moss_block
fill 285 170 332 285 170 334 minecraft:cobblestone
setblock 285 170 335 minecraft:moss_block
fill 285 170 336 285 170 338 minecraft:cobblestone
setblock 285 170 339 minecraft:moss_block
fill 285 170 340 285 170 342 minecraft:cobblestone
setblock 285 170 343 minecraft:moss_block
fill 285 170 344 285 170 346 minecraft:cobblestone
setblock 285 170 347 minecraft:moss_block
fill 285 170 348 285 170 350 minecraft:cobblestone
setblock 285 170 351 minecraft:moss_block
fill 285 170 352 285 170 354 minecraft:cobblestone
setblock 285 170 355 minecraft:moss_block
fill 285 170 356 285 170 358 minecraft:cobblestone
setblock 285 170 359 minecraft:moss_block
fill 285 170 360 287 170 360 minecraft:cobblestone
setblock 285 170 362 minecraft:cobblestone
setblock 285 170 363 minecraft:moss_block
fill 286 170 323 286 170 325 minecraft:cobblestone
setblock 286 170 326 minecraft:moss_block
fill 286 170 327 286 170 329 minecraft:cobblestone
setblock 286 170 330 minecraft:moss_block
fill 286 170 331 286 170 333 minecraft:cobblestone
setblock 286 170 334 minecraft:moss_block
fill 286 170 335 286 170 337 minecraft:cobblestone
setblock 286 170 338 minecraft:moss_block
fill 286 170 339 286 170 341 minecraft:cobblestone
setblock 286 170 342 minecraft:moss_block
fill 286 170 343 286 170 345 minecraft:cobblestone
setblock 286 170 346 minecraft:moss_block
fill 286 170 347 286 170 349 minecraft:cobblestone
setblock 286 170 350 minecraft:moss_block
fill 286 170 351 286 170 353 minecraft:cobblestone
setblock 286 170 354 minecraft:moss_block
fill 286 170 355 286 170 357 minecraft:cobblestone
setblock 286 170 358 minecraft:moss_block
fill 286 170 359 288 170 359 minecraft:cobblestone
setblock 286 170 362 minecraft:moss_block
fill 286 170 363 288 170 363 minecraft:cobblestone
fill 287 170 323 287 170 324 minecraft:cobblestone
setblock 287 170 325 minecraft:moss_block
fill 287 170 326 287 170 328 minecraft:cobblestone
setblock 287 170 329 minecraft:moss_block
fill 287 170 330 287 170 332 minecraft:cobblestone
setblock 287 170 333 minecraft:moss_block
fill 287 170 334 287 170 336 minecraft:cobblestone
setblock 287 170 337 minecraft:moss_block
fill 287 170 338 287 170 340 minecraft:cobblestone
setblock 287 170 341 minecraft:moss_block
fill 287 170 342 287 170 344 minecraft:cobblestone
setblock 287 170 345 minecraft:moss_block
fill 287 170 346 287 170 348 minecraft:cobblestone
setblock 287 170 349 minecraft:moss_block
fill 287 170 350 287 170 352 minecraft:cobblestone
setblock 287 170 353 minecraft:moss_block
fill 287 170 354 287 170 356 minecraft:cobblestone
setblock 287 170 357 minecraft:moss_block
fill 287 170 358 289 170 358 minecraft:cobblestone
setblock 287 170 361 minecraft:moss_block
fill 287 170 362 289 170 362 minecraft:cobblestone
setblock 288 170 323 minecraft:cobblestone
setblock 288 170 324 minecraft:moss_block
fill 288 170 325 288 170 327 minecraft:cobblestone
setblock 288 170 328 minecraft:moss_block
fill 288 170 329 288 170 331 minecraft:cobblestone
setblock 288 170 332 minecraft:moss_block
fill 288 170 333 288 170 335 minecraft:cobblestone
setblock 288 170 336 minecraft:moss_block
fill 288 170 337 288 170 339 minecraft:cobblestone
setblock 288 170 340 minecraft:moss_block
fill 288 170 341 288 170 343 minecraft:cobblestone
setblock 288 170 344 minecraft:moss_block
fill 288 170 345 288 170 347 minecraft:cobblestone
setblock 288 170 348 minecraft:moss_block
fill 288 170 349 288 170 351 minecraft:cobblestone
setblock 288 170 352 minecraft:moss_block
fill 288 170 353 288 170 355 minecraft:cobblestone
setblock 288 170 356 minecraft:moss_block
fill 288 170 357 290 170 357 minecraft:cobblestone
setblock 288 170 360 minecraft:moss_block
fill 288 170 361 290 170 361 minecraft:cobblestone
setblock 289 170 323 minecraft:moss_block
fill 289 170 324 289 170 326 minecraft:cobblestone
setblock 289 170 327 minecraft:moss_block
fill 289 170 328 289 170 330 minecraft:cobblestone
setblock 289 170 331 minecraft:moss_block
fill 289 170 332 289 170 334 minecraft:cobblestone
setblock 289 170 335 minecraft:moss_block
fill 289 170 336 289 170 338 minecraft:cobblestone
setblock 289 170 339 minecraft:moss_block
fill 289 170 340 289 170 342 minecraft:cobblestone
setblock 289 170 343 minecraft:moss_block
fill 289 170 344 289 170 346 minecraft:cobblestone
setblock 289 170 347 minecraft:moss_block
fill 289 170 348 289 170 350 minecraft:cobblestone
setblock 289 170 351 minecraft:moss_block
fill 289 170 352 289 170 354 minecraft:cobblestone
setblock 289 170 355 minecraft:moss_block
fill 289 170 356 291 170 356 minecraft:cobblestone
setblock 289 170 359 minecraft:moss_block
fill 289 170 360 291 170 360 minecraft:cobblestone
setblock 289 170 363 minecraft:moss_block
fill 290 170 323 290 170 325 minecraft:cobblestone
setblock 290 170 326 minecraft:moss_block
fill 290 170 327 290 170 329 minecraft:cobblestone
setblock 290 170 330 minecraft:moss_block
fill 290 170 331 290 170 333 minecraft:cobblestone
setblock 290 170 334 minecraft:moss_block
fill 290 170 335 290 170 337 minecraft:cobblestone
setblock 290 170 338 minecraft:moss_block
fill 290 170 339 290 170 341 minecraft:cobblestone
setblock 290 170 342 minecraft:moss_block
fill 290 170 343 290 170 345 minecraft:cobblestone
setblock 290 170 346 minecraft:moss_block
fill 290 170 347 290 170 349 minecraft:cobblestone
setblock 290 170 350 minecraft:moss_block
fill 290 170 351 290 170 353 minecraft:cobblestone
setblock 290 170 354 minecraft:moss_block
fill 290 170 355 292 170 355 minecraft:cobblestone
setblock 290 170 358 minecraft:moss_block
fill 290 170 359 292 170 359 minecraft:cobblestone
setblock 290 170 362 minecraft:moss_block
fill 290 170 363 292 170 363 minecraft:cobblestone
fill 291 170 323 291 170 324 minecraft:cobblestone
setblock 291 170 325 minecraft:moss_block
fill 291 170 326 291 170 328 minecraft:cobblestone
setblock 291 170 329 minecraft:moss_block
fill 291 170 330 291 170 332 minecraft:cobblestone
setblock 291 170 333 minecraft:moss_block
fill 291 170 334 291 170 336 minecraft:cobblestone
setblock 291 170 337 minecraft:moss_block
fill 291 170 338 292 170 340 minecraft:cobblestone
setblock 291 170 341 minecraft:moss_block
fill 291 170 342 291 170 344 minecraft:cobblestone
setblock 291 170 345 minecraft:moss_block
fill 291 170 346 291 170 348 minecraft:cobblestone
setblock 291 170 349 minecraft:moss_block
fill 291 170 350 291 170 352 minecraft:cobblestone
setblock 291 170 353 minecraft:moss_block
fill 291 170 354 293 170 354 minecraft:cobblestone
setblock 291 170 357 minecraft:moss_block
fill 291 170 358 293 170 358 minecraft:cobblestone
setblock 291 170 361 minecraft:moss_block
fill 291 170 362 293 170 362 minecraft:cobblestone
setblock 292 170 323 minecraft:cobblestone
setblock 292 170 324 minecraft:moss_block
fill 292 170 325 292 170 327 minecraft:cobblestone
setblock 292 170 328 minecraft:moss_block
fill 292 170 329 292 170 331 minecraft:cobblestone
setblock 292 170 332 minecraft:moss_block
fill 292 170 333 292 170 335 minecraft:cobblestone
setblock 292 170 336 minecraft:moss_block
setblock 292 170 337 minecraft:cobblestone
fill 292 170 341 292 170 343 minecraft:cobblestone
setblock 292 170 344 minecraft:moss_block
fill 292 170 345 292 170 347 minecraft:cobblestone
setblock 292 170 348 minecraft:moss_block
fill 292 170 349 292 170 351 minecraft:cobblestone
setblock 292 170 352 minecraft:moss_block
fill 292 170 353 294 170 353 minecraft:cobblestone
setblock 292 170 356 minecraft:moss_block
fill 292 170 357 294 170 357 minecraft:cobblestone
setblock 292 170 360 minecraft:moss_block
fill 292 170 361 294 170 361 minecraft:cobblestone
setblock 293 170 323 minecraft:moss_block
fill 293 170 324 293 170 326 minecraft:cobblestone
setblock 293 170 327 minecraft:moss_block
fill 293 170 328 293 170 330 minecraft:cobblestone
setblock 293 170 331 minecraft:moss_block
fill 293 170 332 293 170 334 minecraft:cobblestone
setblock 293 170 335 minecraft:moss_block
setblock 293 170 336 minecraft:cobblestone
fill 293 170 344 293 170 346 minecraft:cobblestone
setblock 293 170 347 minecraft:moss_block
fill 293 170 348 293 170 350 minecraft:cobblestone
setblock 293 170 351 minecraft:moss_block
fill 293 170 352 295 170 352 minecraft:cobblestone
setblock 293 170 355 minecraft:moss_block
fill 293 170 356 295 170 356 minecraft:cobblestone
setblock 293 170 359 minecraft:moss_block
fill 293 170 360 295 170 360 minecraft:cobblestone
setblock 293 170 363 minecraft:moss_block
fill 294 170 323 294 170 325 minecraft:cobblestone
setblock 294 170 326 minecraft:moss_block
fill 294 170 327 294 170 329 minecraft:cobblestone
setblock 294 170 330 minecraft:moss_block
fill 294 170 331 294 170 333 minecraft:cobblestone
setblock 294 170 334 minecraft:moss_block
setblock 294 170 335 minecraft:cobblestone
fill 294 170 338 296 170 342 minecraft:blue_stained_glass
setblock 294 170 345 minecraft:cobblestone
setblock 294 170 346 minecraft:moss_block
fill 294 170 347 294 170 349 minecraft:cobblestone
setblock 294 170 350 minecraft:moss_block
fill 294 170 351 296 170 351 minecraft:cobblestone
setblock 294 170 354 minecraft:moss_block
fill 294 170 355 296 170 355 minecraft:cobblestone
setblock 294 170 358 minecraft:moss_block
fill 294 170 359 296 170 359 minecraft:cobblestone
setblock 294 170 362 minecraft:moss_block
fill 294 170 363 296 170 363 minecraft:cobblestone
fill 295 170 323 295 170 324 minecraft:cobblestone
setblock 295 170 325 minecraft:moss_block
fill 295 170 326 295 170 328 minecraft:cobblestone
setblock 295 170 329 minecraft:moss_block
fill 295 170 330 295 170 332 minecraft:cobblestone
setblock 295 170 333 minecraft:moss_block
setblock 295 170 334 minecraft:cobblestone
fill 295 170 336 297 170 337 minecraft:blue_stained_glass
fill 295 170 343 297 170 344 minecraft:blue_stained_glass
fill 295 170 346 295 170 348 minecraft:cobblestone
setblock 295 170 349 minecraft:moss_block
fill 295 170 350 297 170 350 minecraft:cobblestone
setblock 295 170 353 minecraft:moss_block
fill 295 170 354 297 170 354 minecraft:cobblestone
setblock 295 170 357 minecraft:moss_block
fill 295 170 358 297 170 358 minecraft:cobblestone
setblock 295 170 361 minecraft:moss_block
fill 295 170 362 297 170 362 minecraft:cobblestone
setblock 296 170 323 minecraft:cobblestone
setblock 296 170 324 minecraft:moss_block
fill 296 170 325 296 170 327 minecraft:cobblestone
setblock 296 170 328 minecraft:moss_block
fill 296 170 329 296 170 331 minecraft:cobblestone
setblock 296 170 332 minecraft:moss_block
setblock 296 170 333 minecraft:cobblestone
setblock 296 170 347 minecraft:cobblestone
setblock 296 170 348 minecraft:moss_block
fill 296 170 349 298 170 349 minecraft:cobblestone
setblock 296 170 352 minecraft:moss_block
fill 296 170 353 298 170 353 minecraft:cobblestone
setblock 296 170 356 minecraft:moss_block
fill 296 170 357 298 170 357 minecraft:cobblestone
setblock 296 170 360 minecraft:moss_block
fill 296 170 361 298 170 361 minecraft:cobblestone
setblock 297 170 323 minecraft:moss_block
fill 297 170 324 297 170 326 minecraft:cobblestone
setblock 297 170 327 minecraft:moss_block
fill 297 170 328 297 170 330 minecraft:cobblestone
setblock 297 170 331 minecraft:moss_block
fill 297 170 332 303 170 332 minecraft:cobblestone
fill 297 170 338 297 170 342 minecraft:sea_lantern
fill 297 170 348 303 170 348 minecraft:cobblestone
setblock 297 170 351 minecraft:moss_block
fill 297 170 352 299 170 352 minecraft:cobblestone
setblock 297 170 355 minecraft:moss_block
fill 297 170 356 299 170 356 minecraft:cobblestone
setblock 297 170 359 minecraft:moss_block
fill 297 170 360 299 170 360 minecraft:cobblestone
setblock 297 170 363 minecraft:moss_block
fill 298 170 323 298 170 325 minecraft:cobblestone
setblock 298 170 326 minecraft:moss_block
fill 298 170 327 298 170 329 minecraft:cobblestone
setblock 298 170 330 minecraft:moss_block
fill 298 170 331 300 170 331 minecraft:cobblestone
fill 298 170 336 305 170 336 minecraft:blue_stained_glass
fill 298 170 337 298 170 338 minecraft:sea_lantern
fill 298 170 342 298 170 343 minecraft:sea_lantern
fill 298 170 344 305 170 344 minecraft:blue_stained_glass
setblock 298 170 350 minecraft:moss_block
fill 298 170 351 300 170 351 minecraft:cobblestone
setblock 298 170 354 minecraft:moss_block
fill 298 170 355 300 170 355 minecraft:cobblestone
setblock 298 170 358 minecraft:moss_block
fill 298 170 359 300 170 359 minecraft:cobblestone
setblock 298 170 362 minecraft:moss_block
fill 298 170 363 300 170 363 minecraft:cobblestone
fill 299 170 323 299 170 324 minecraft:cobblestone
setblock 299 170 325 minecraft:moss_block
fill 299 170 326 299 170 328 minecraft:cobblestone
setblock 299 170 329 minecraft:moss_block
fill 299 170 330 301 170 330 minecraft:cobblestone
fill 299 170 337 302 170 337 minecraft:sea_lantern
fill 299 170 343 302 170 343 minecraft:sea_lantern
setblock 299 170 349 minecraft:moss_block
fill 299 170 350 301 170 350 minecraft:cobblestone
setblock 299 170 353 minecraft:moss_block
fill 299 170 354 301 170 354 minecraft:cobblestone
setblock 299 170 357 minecraft:moss_block
fill 299 170 358 301 170 358 minecraft:cobblestone
setblock 299 170 361 minecraft:moss_block
fill 299 170 362 301 170 362 minecraft:cobblestone
setblock 300 170 323 minecraft:cobblestone
setblock 300 170 324 minecraft:moss_block
fill 300 170 325 300 170 327 minecraft:cobblestone
setblock 300 170 328 minecraft:moss_block
fill 300 170 329 302 170 329 minecraft:cobblestone
fill 300 170 349 302 170 349 minecraft:cobblestone
setblock 300 170 352 minecraft:moss_block
fill 300 170 353 302 170 353 minecraft:cobblestone
setblock 300 170 356 minecraft:moss_block
fill 300 170 357 302 170 357 minecraft:cobblestone
setblock 300 170 360 minecraft:moss_block
fill 300 170 361 302 170 361 minecraft:cobblestone
setblock 301 170 323 minecraft:moss_block
fill 301 170 324 301 170 326 minecraft:cobblestone
setblock 301 170 327 minecraft:moss_block
fill 301 170 328 303 170 328 minecraft:cobblestone
setblock 301 170 331 minecraft:moss_block
setblock 301 170 351 minecraft:moss_block
fill 301 170 352 303 170 352 minecraft:cobblestone
setblock 301 170 355 minecraft:moss_block
fill 301 170 356 303 170 356 minecraft:cobblestone
setblock 301 170 359 minecraft:moss_block
fill 301 170 360 303 170 360 minecraft:cobblestone
setblock 301 170 363 minecraft:moss_block
fill 302 170 323 302 170 325 minecraft:cobblestone
setblock 302 170 326 minecraft:moss_block
fill 302 170 327 304 170 327 minecraft:cobblestone
setblock 302 170 330 minecraft:moss_block
fill 302 170 331 304 170 331 minecraft:cobblestone
fill 302 170 338 303 170 338 minecraft:sea_lantern
fill 302 170 342 303 170 342 minecraft:sea_lantern
setblock 302 170 350 minecraft:moss_block
fill 302 170 351 304 170 351 minecraft:cobblestone
setblock 302 170 354 minecraft:moss_block
fill 302 170 355 304 170 355 minecraft:cobblestone
setblock 302 170 358 minecraft:moss_block
fill 302 170 359 304 170 359 minecraft:cobblestone
setblock 302 170 362 minecraft:moss_block
fill 302 170 363 304 170 363 minecraft:cobblestone
fill 303 170 323 303 170 324 minecraft:cobblestone
setblock 303 170 325 minecraft:moss_block
fill 303 170 326 305 170 326 minecraft:cobblestone
setblock 303 170 329 minecraft:moss_block
fill 303 170 330 305 170 330 minecraft:cobblestone
fill 303 170 337 305 170 337 minecraft:blue_stained_glass
fill 303 170 339 303 170 341 minecraft:sea_lantern
fill 303 170 343 305 170 343 minecraft:blue_stained_glass
setblock 303 170 349 minecraft:moss_block
fill 303 170 350 305 170 350 minecraft:cobblestone
setblock 303 170 353 minecraft:moss_block
fill 303 170 354 305 170 354 minecraft:cobblestone
setblock 303 170 357 minecraft:moss_block
fill 303 170 358 305 170 358 minecraft:cobblestone
setblock 303 170 361 minecraft:moss_block
fill 303 170 362 305 170 362 minecraft:cobblestone
setblock 304 170 323 minecraft:cobblestone
setblock 304 170 324 minecraft:moss_block
fill 304 170 325 306 170 325 minecraft:cobblestone
setblock 304 170 328 minecraft:moss_block
fill 304 170 329 306 170 329 minecraft:cobblestone
setblock 304 170 332 minecraft:moss_block
fill 304 170 333 306 170 333 minecraft:cobblestone
fill 304 170 338 306 170 342 minecraft:blue_stained_glass
setblock 304 170 347 minecraft:cobblestone
setblock 304 170 348 minecraft:moss_block
fill 304 170 349 306 170 349 minecraft:cobblestone
setblock 304 170 352 minecraft:moss_block
fill 304 170 353 306 170 353 minecraft:cobblestone
setblock 304 170 356 minecraft:moss_block
fill 304 170 357 306 170 357 minecraft:cobblestone
setblock 304 170 360 minecraft:moss_block
fill 304 170 361 306 170 361 minecraft:cobblestone
setblock 305 170 323 minecraft:moss_block
fill 305 170 324 307 170 324 minecraft:cobblestone
setblock 305 170 327 minecraft:moss_block
fill 305 170 328 307 170 328 minecraft:cobblestone
setblock 305 170 331 minecraft:moss_block
fill 305 170 332 307 170 332 minecraft:cobblestone
setblock 305 170 334 minecraft:cobblestone
setblock 305 170 346 minecraft:cobblestone
setblock 305 170 347 minecraft:moss_block
fill 305 170 348 307 170 348 minecraft:cobblestone
setblock 305 170 351 minecraft:moss_block
fill 305 170 352 307 170 352 minecraft:cobblestone
setblock 305 170 355 minecraft:moss_block
fill 305 170 356 307 170 356 minecraft:cobblestone
setblock 305 170 359 minecraft:moss_block
fill 305 170 360 307 170 360 minecraft:cobblestone
setblock 305 170 363 minecraft:moss_block
fill 306 170 323 308 170 323 minecraft:cobblestone
setblock 306 170 326 minecraft:moss_block
fill 306 170 327 308 170 327 minecraft:cobblestone
setblock 306 170 330 minecraft:moss_block
fill 306 170 331 308 170 331 minecraft:cobblestone
setblock 306 170 334 minecraft:moss_block
fill 306 170 335 308 170 335 minecraft:cobblestone
setblock 306 170 345 minecraft:cobblestone
setblock 306 170 346 minecraft:moss_block
fill 306 170 347 308 170 347 minecraft:cobblestone
setblock 306 170 350 minecraft:moss_block
fill 306 170 351 308 170 351 minecraft:cobblestone
setblock 306 170 354 minecraft:moss_block
fill 306 170 355 308 170 355 minecraft:cobblestone
setblock 306 170 358 minecraft:moss_block
fill 306 170 359 308 170 359 minecraft:cobblestone
setblock 306 170 362 minecraft:moss_block
fill 306 170 363 308 170 363 minecraft:cobblestone
setblock 307 170 325 minecraft:moss_block
fill 307 170 326 309 170 326 minecraft:cobblestone
setblock 307 170 329 minecraft:moss_block
fill 307 170 330 309 170 330 minecraft:cobblestone
setblock 307 170 333 minecraft:moss_block
fill 307 170 334 309 170 334 minecraft:cobblestone
setblock 307 170 336 minecraft:cobblestone
setblock 307 170 344 minecraft:cobblestone
setblock 307 170 345 minecraft:moss_block
fill 307 170 346 309 170 346 minecraft:cobblestone
setblock 307 170 349 minecraft:moss_block
fill 307 170 350 309 170 350 minecraft:cobblestone
setblock 307 170 353 minecraft:moss_block
fill 307 170 354 309 170 354 minecraft:cobblestone
setblock 307 170 357 minecraft:moss_block
fill 307 170 358 309 170 358 minecraft:cobblestone
setblock 307 170 361 minecraft:moss_block
fill 307 170 362 309 170 362 minecraft:cobblestone
setblock 308 170 324 minecraft:moss_block
fill 308 170 325 310 170 325 minecraft:cobblestone
setblock 308 170 328 minecraft:moss_block
fill 308 170 329 310 170 329 minecraft:cobblestone
setblock 308 170 332 minecraft:moss_block
fill 308 170 333 310 170 333 minecraft:cobblestone
setblock 308 170 336 minecraft:moss_block
fill 308 170 337 308 170 343 minecraft:cobblestone
setblock 308 170 344 minecraft:moss_block
fill 308 170 345 310 170 345 minecraft:cobblestone
setblock 308 170 348 minecraft:moss_block
fill 308 170 349 310 170 349 minecraft:cobblestone
setblock 308 170 352 minecraft:moss_block
fill 308 170 353 310 170 353 minecraft:cobblestone
setblock 308 170 356 minecraft:moss_block
fill 308 170 357 310 170 357 minecraft:cobblestone
setblock 308 170 360 minecraft:moss_block
fill 308 170 361 310 170 361 minecraft:cobblestone
setblock 309 170 323 minecraft:moss_block
fill 309 170 324 311 170 324 minecraft:cobblestone
setblock 309 170 327 minecraft:moss_block
fill 309 170 328 311 170 328 minecraft:cobblestone
setblock 309 170 331 minecraft:moss_block
fill 309 170 332 311 170 332 minecraft:cobblestone
setblock 309 170 335 minecraft:moss_block
fill 309 170 336 309 170 338 minecraft:cobblestone
setblock 309 170 339 minecraft:moss_block
fill 309 170 340 309 170 342 minecraft:cobblestone
setblock 309 170 343 minecraft:moss_block
fill 309 170 344 311 170 344 minecraft:cobblestone
setblock 309 170 347 minecraft:moss_block
fill 309 170 348 311 170 348 minecraft:cobblestone
setblock 309 170 351 minecraft:moss_block
fill 309 170 352 311 170 352 minecraft:cobblestone
setblock 309 170 355 minecraft:moss_block
fill 309 170 356 311 170 356 minecraft:cobblestone
setblock 309 170 359 minecraft:moss_block
fill 309 170 360 311 170 360 minecraft:cobblestone
setblock 309 170 363 minecraft:moss_block
fill 310 170 323 312 170 323 minecraft:cobblestone
setblock 310 170 326 minecraft:moss_block
fill 310 170 327 312 170 327 minecraft:cobblestone
setblock 310 170 330 minecraft:moss_block
fill 310 170 331 312 170 331 minecraft:cobblestone
setblock 310 170 334 minecraft:moss_block
fill 310 170 335 310 170 337 minecraft:cobblestone
setblock 310 170 338 minecraft:moss_block
fill 310 170 339 310 170 341 minecraft:cobblestone
setblock 310 170 342 minecraft:moss_block
fill 310 170 343 312 170 343 minecraft:cobblestone
setblock 310 170 346 minecraft:moss_block
fill 310 170 347 312 170 347 minecraft:cobblestone
setblock 310 170 350 minecraft:moss_block
fill 310 170 351 312 170 351 minecraft:cobblestone
setblock 310 170 354 minecraft:moss_block
fill 310 170 355 312 170 355 minecraft:cobblestone
setblock 310 170 358 minecraft:moss_block
fill 310 170 359 312 170 359 minecraft:cobblestone
setblock 310 170 362 minecraft:moss_block
fill 310 170 363 312 170 363 minecraft:cobblestone
setblock 311 170 325 minecraft:moss_block
fill 311 170 326 313 170 326 minecraft:cobblestone
setblock 311 170 329 minecraft:moss_block
fill 311 170 330 313 170 330 minecraft:cobblestone
setblock 311 170 333 minecraft:moss_block
fill 311 170 334 311 170 336 minecraft:cobblestone
setblock 311 170 337 minecraft:moss_block
fill 311 170 338 311 170 340 minecraft:cobblestone
setblock 311 170 341 minecraft:moss_block
fill 311 170 342 313 170 342 minecraft:cobblestone
setblock 311 170 345 minecraft:moss_block
fill 311 170 346 313 170 346 minecraft:cobblestone
setblock 311 170 349 minecraft:moss_block
fill 311 170 350 313 170 350 minecraft:cobblestone
setblock 311 170 353 minecraft:moss_block
fill 311 170 354 313 170 354 minecraft:cobblestone
setblock 311 170 357 minecraft:moss_block
fill 311 170 358 313 170 358 minecraft:cobblestone
setblock 311 170 361 minecraft:moss_block
fill 311 170 362 313 170 362 minecraft:cobblestone
setblock 312 170 324 minecraft:moss_block
fill 312 170 325 314 170 325 minecraft:cobblestone
setblock 312 170 328 minecraft:moss_block
fill 312 170 329 314 170 329 minecraft:cobblestone
setblock 312 170 332 minecraft:moss_block
fill 312 170 333 312 170 335 minecraft:cobblestone
setblock 312 170 336 minecraft:moss_block
fill 312 170 337 312 170 339 minecraft:cobblestone
setblock 312 170 340 minecraft:moss_block
fill 312 170 341 314 170 341 minecraft:cobblestone
setblock 312 170 344 minecraft:moss_block
fill 312 170 345 314 170 345 minecraft:cobblestone
setblock 312 170 348 minecraft:moss_block
fill 312 170 349 314 170 349 minecraft:cobblestone
setblock 312 170 352 minecraft:moss_block
fill 312 170 353 314 170 353 minecraft:cobblestone
setblock 312 170 356 minecraft:moss_block
fill 312 170 357 314 170 357 minecraft:cobblestone
setblock 312 170 360 minecraft:moss_block
fill 312 170 361 314 170 361 minecraft:cobblestone
setblock 313 170 323 minecraft:moss_block
fill 313 170 324 315 170 324 minecraft:cobblestone
setblock 313 170 327 minecraft:moss_block
fill 313 170 328 315 170 328 minecraft:cobblestone
setblock 313 170 331 minecraft:moss_block
fill 313 170 332 313 170 334 minecraft:cobblestone
setblock 313 170 335 minecraft:moss_block
fill 313 170 336 313 170 338 minecraft:cobblestone
setblock 313 170 339 minecraft:moss_block
fill 313 170 340 315 170 340 minecraft:cobblestone
setblock 313 170 343 minecraft:moss_block
fill 313 170 344 315 170 344 minecraft:cobblestone
setblock 313 170 347 minecraft:moss_block
fill 313 170 348 315 170 348 minecraft:cobblestone
setblock 313 170 351 minecraft:moss_block
fill 313 170 352 315 170 352 minecraft:cobblestone
setblock 313 170 355 minecraft:moss_block
fill 313 170 356 315 170 356 minecraft:cobblestone
setblock 313 170 359 minecraft:moss_block
fill 313 170 360 315 170 360 minecraft:cobblestone
setblock 313 170 363 minecraft:moss_block
fill 314 170 323 316 170 323 minecraft:cobblestone
setblock 314 170 326 minecraft:moss_block
fill 314 170 327 316 170 327 minecraft:cobblestone
setblock 314 170 330 minecraft:moss_block
fill 314 170 331 314 170 333 minecraft:cobblestone
setblock 314 170 334 minecraft:moss_block
fill 314 170 335 314 170 337 minecraft:cobblestone
setblock 314 170 338 minecraft:moss_block
fill 314 170 339 316 170 339 minecraft:cobblestone
setblock 314 170 342 minecraft:moss_block
fill 314 170 343 316 170 343 minecraft:cobblestone
setblock 314 170 346 minecraft:moss_block
fill 314 170 347 316 170 347 minecraft:cobblestone
setblock 314 170 350 minecraft:moss_block
fill 314 170 351 316 170 351 minecraft:cobblestone
setblock 314 170 354 minecraft:moss_block
fill 314 170 355 316 170 355 minecraft:cobblestone
setblock 314 170 358 minecraft:moss_block
fill 314 170 359 316 170 359 minecraft:cobblestone
setblock 314 170 362 minecraft:moss_block
fill 314 170 363 316 170 363 minecraft:cobblestone
setblock 315 170 325 minecraft:moss_block
fill 315 170 326 317 170 326 minecraft:cobblestone
setblock 315 170 329 minecraft:moss_block
fill 315 170 330 315 170 332 minecraft:cobblestone
setblock 315 170 333 minecraft:moss_block
fill 315 170 334 315 170 336 minecraft:cobblestone
setblock 315 170 337 minecraft:moss_block
fill 315 170 338 317 170 338 minecraft:cobblestone
setblock 315 170 341 minecraft:moss_block
fill 315 170 342 317 170 342 minecraft:cobblestone
setblock 315 170 345 minecraft:moss_block
fill 315 170 346 317 170 346 minecraft:cobblestone
setblock 315 170 349 minecraft:moss_block
fill 315 170 350 317 170 350 minecraft:cobblestone
setblock 315 170 353 minecraft:moss_block
fill 315 170 354 317 170 354 minecraft:cobblestone
setblock 315 170 357 minecraft:moss_block
fill 315 170 358 317 170 358 minecraft:cobblestone
setblock 315 170 361 minecraft:moss_block
fill 315 170 362 317 170 362 minecraft:cobblestone
setblock 316 170 324 minecraft:moss_block
fill 316 170 325 318 170 325 minecraft:cobblestone
setblock 316 170 328 minecraft:moss_block
fill 316 170 329 316 170 331 minecraft:cobblestone
setblock 316 170 332 minecraft:moss_block
fill 316 170 333 316 170 335 minecraft:cobblestone
setblock 316 170 336 minecraft:moss_block
fill 316 170 337 318 170 337 minecraft:cobblestone
setblock 316 170 340 minecraft:moss_block
fill 316 170 341 318 170 341 minecraft:cobblestone
setblock 316 170 344 minecraft:moss_block
fill 316 170 345 318 170 345 minecraft:cobblestone
setblock 316 170 348 minecraft:moss_block
fill 316 170 349 318 170 349 minecraft:cobblestone
setblock 316 170 352 minecraft:moss_block
fill 316 170 353 318 170 353 minecraft:cobblestone
setblock 316 170 356 minecraft:moss_block
fill 316 170 357 318 170 357 minecraft:cobblestone
setblock 316 170 360 minecraft:moss_block
fill 316 170 361 318 170 361 minecraft:cobblestone
setblock 317 170 323 minecraft:moss_block
fill 317 170 324 319 170 324 minecraft:cobblestone
setblock 317 170 327 minecraft:moss_block
fill 317 170 328 317 170 330 minecraft:cobblestone
setblock 317 170 331 minecraft:moss_block
fill 317 170 332 317 170 334 minecraft:cobblestone
setblock 317 170 335 minecraft:moss_block
fill 317 170 336 319 170 336 minecraft:cobblestone
setblock 317 170 339 minecraft:moss_block
fill 317 170 340 319 170 340 minecraft:cobblestone
setblock 317 170 343 minecraft:moss_block
fill 317 170 344 319 170 344 minecraft:cobblestone
setblock 317 170 347 minecraft:moss_block
fill 317 170 348 319 170 348 minecraft:cobblestone
setblock 317 170 351 minecraft:moss_block
fill 317 170 352 319 170 352 minecraft:cobblestone
setblock 317 170 355 minecraft:moss_block
fill 317 170 356 319 170 356 minecraft:cobblestone
setblock 317 170 359 minecraft:moss_block
fill 317 170 360 319 170 360 minecraft:cobblestone
setblock 317 170 363 minecraft:moss_block
fill 318 170 323 320 170 323 minecraft:cobblestone
setblock 318 170 326 minecraft:moss_block
fill 318 170 327 318 170 329 minecraft:cobblestone
setblock 318 170 330 minecraft:moss_block
fill 318 170 331 318 170 333 minecraft:cobblestone
setblock 318 170 334 minecraft:moss_block
fill 318 170 335 320 170 335 minecraft:cobblestone
setblock 318 170 338 minecraft:moss_block
fill 318 170 339 320 170 339 minecraft:cobblestone
setblock 318 170 342 minecraft:moss_block
fill 318 170 343 320 170 343 minecraft:cobblestone
setblock 318 170 346 minecraft:moss_block
fill 318 170 347 320 170 347 minecraft:cobblestone
setblock 318 170 350 minecraft:moss_block
fill 318 170 351 320 170 351 minecraft:cobblestone
setblock 318 170 354 minecraft:moss_block
fill 318 170 355 320 170 355 minecraft:cobblestone
setblock 318 170 358 minecraft:moss_block
fill 318 170 359 320 170 359 minecraft:cobblestone
setblock 318 170 362 minecraft:moss_block
fill 318 170 363 320 170 363 minecraft:cobblestone
setblock 319 170 325 minecraft:moss_block
fill 319 170 326 319 170 328 minecraft:cobblestone
setblock 319 170 329 minecraft:moss_block
fill 319 170 330 319 170 332 minecraft:cobblestone
setblock 319 170 333 minecraft:moss_block
fill 319 170 334 321 170 334 minecraft:cobblestone
setblock 319 170 337 minecraft:moss_block
fill 319 170 338 321 170 338 minecraft:cobblestone
setblock 319 170 341 minecraft:moss_block
fill 319 170 342 321 170 342 minecraft:cobblestone
setblock 319 170 345 minecraft:moss_block
fill 319 170 346 321 170 346 minecraft:cobblestone
setblock 319 170 349 minecraft:moss_block
fill 319 170 350 321 170 350 minecraft:cobblestone
setblock 319 170 353 minecraft:moss_block
fill 319 170 354 321 170 354 minecraft:cobblestone
setblock 319 170 357 minecraft:moss_block
fill 319 170 358 321 170 358 minecraft:cobblestone
setblock 319 170 361 minecraft:moss_block
fill 319 170 362 321 170 362 minecraft:cobblestone
setblock 320 170 324 minecraft:moss_block
fill 320 170 325 320 170 327 minecraft:cobblestone
setblock 320 170 328 minecraft:moss_block
fill 320 170 329 320 170 331 minecraft:cobblestone
setblock 320 170 332 minecraft:moss_block
fill 320 170 333 322 170 333 minecraft:cobblestone
setblock 320 170 336 minecraft:moss_block
fill 320 170 337 322 170 337 minecraft:cobblestone
setblock 320 170 340 minecraft:moss_block
fill 320 170 341 322 170 341 minecraft:cobblestone
setblock 320 170 344 minecraft:moss_block
fill 320 170 345 322 170 345 minecraft:cobblestone
setblock 320 170 348 minecraft:moss_block
fill 320 170 349 322 170 349 minecraft:cobblestone
setblock 320 170 352 minecraft:moss_block
fill 320 170 353 322 170 353 minecraft:cobblestone
setblock 320 170 356 minecraft:moss_block
fill 320 170 357 322 170 357 minecraft:cobblestone
setblock 320 170 360 minecraft:moss_block
fill 320 170 361 322 170 361 minecraft:cobblestone
setblock 321 170 323 minecraft:moss_block
fill 321 170 324 321 170 326 minecraft:cobblestone
setblock 321 170 327 minecraft:moss_block
fill 321 170 328 321 170 330 minecraft:cobblestone
setblock 321 170 331 minecraft:moss_block
fill 321 170 332 323 170 332 minecraft:cobblestone
setblock 321 170 335 minecraft:moss_block
fill 321 170 336 323 170 336 minecraft:cobblestone
setblock 321 170 339 minecraft:moss_block
fill 321 170 340 323 170 340 minecraft:cobblestone
setblock 321 170 343 minecraft:moss_block
fill 321 170 344 323 170 344 minecraft:cobblestone
setblock 321 170 347 minecraft:moss_block
fill 321 170 348 323 170 348 minecraft:cobblestone
setblock 321 170 351 minecraft:moss_block
fill 321 170 352 323 170 352 minecraft:cobblestone
setblock 321 170 355 minecraft:moss_block
fill 321 170 356 323 170 356 minecraft:cobblestone
setblock 321 170 359 minecraft:moss_block
fill 321 170 360 323 170 360 minecraft:cobblestone
setblock 321 170 363 minecraft:moss_block
fill 322 170 323 322 170 325 minecraft:cobblestone
setblock 322 170 326 minecraft:moss_block
fill 322 170 327 322 170 329 minecraft:cobblestone
setblock 322 170 330 minecraft:moss_block
fill 322 170 331 323 170 331 minecraft:cobblestone
setblock 322 170 334 minecraft:moss_block
fill 322 170 335 323 170 335 minecraft:cobblestone
setblock 322 170 338 minecraft:moss_block
fill 322 170 339 323 170 339 minecraft:cobblestone
setblock 322 170 342 minecraft:moss_block
fill 322 170 343 323 170 343 minecraft:cobblestone
setblock 322 170 346 minecraft:moss_block
fill 322 170 347 323 170 347 minecraft:cobblestone
setblock 322 170 350 minecraft:moss_block
fill 322 170 351 323 170 351 minecraft:cobblestone
setblock 322 170 354 minecraft:moss_block
fill 322 170 355 323 170 355 minecraft:cobblestone
setblock 322 170 358 minecraft:moss_block
fill 322 170 359 323 170 359 minecraft:cobblestone
setblock 322 170 362 minecraft:moss_block
fill 322 170 363 323 170 363 minecraft:cobblestone
fill 323 170 323 323 170 324 minecraft:cobblestone
setblock 323 170 325 minecraft:moss_block
fill 323 170 326 323 170 328 minecraft:cobblestone
setblock 323 170 329 minecraft:moss_block
setblock 323 170 330 minecraft:cobblestone
setblock 323 170 333 minecraft:moss_block
setblock 323 170 334 minecraft:cobblestone
setblock 323 170 337 minecraft:moss_block
setblock 323 170 338 minecraft:cobblestone
setblock 323 170 341 minecraft:moss_block
setblock 323 170 342 minecraft:cobblestone
setblock 323 170 345 minecraft:moss_block
setblock 323 170 346 minecraft:cobblestone
setblock 323 170 349 minecraft:moss_block
setblock 323 170 350 minecraft:cobblestone
setblock 323 170 353 minecraft:moss_block
setblock 323 170 354 minecraft:cobblestone
setblock 323 170 357 minecraft:moss_block
setblock 323 170 358 minecraft:cobblestone
setblock 323 170 361 minecraft:moss_block
setblock 323 170 362 minecraft:cobblestone
setblock 285 171 325 minecraft:light[level=12]
setblock 285 171 332 minecraft:light[level=12]
setblock 285 171 339 minecraft:light[level=12]
setblock 285 171 346 minecraft:light[level=12]
setblock 285 171 353 minecraft:light[level=12]
setblock 285 171 360 minecraft:light[level=12]
setblock 292 171 325 minecraft:light[level=12]
setblock 292 171 332 minecraft:light[level=12]
setblock 292 171 339 minecraft:light[level=12]
setblock 292 171 346 minecraft:light[level=12]
setblock 292 171 353 minecraft:light[level=12]
setblock 292 171 360 minecraft:light[level=12]
fill 294 171 338 294 171 342 minecraft:cobblestone
fill 295 171 336 295 171 338 minecraft:cobblestone
fill 295 171 342 295 171 344 minecraft:cobblestone
fill 296 171 335 296 171 336 minecraft:cobblestone
fill 296 171 344 296 171 345 minecraft:cobblestone
fill 297 171 335 298 171 335 minecraft:cobblestone
fill 297 171 345 298 171 345 minecraft:cobblestone
fill 298 171 334 302 171 334 minecraft:cobblestone
fill 298 171 346 302 171 346 minecraft:cobblestone
setblock 299 171 325 minecraft:light[level=12]
setblock 299 171 332 minecraft:light[level=12]
setblock 299 171 353 minecraft:light[level=12]
setblock 299 171 360 minecraft:light[level=12]
fill 302 171 335 304 171 335 minecraft:cobblestone
fill 302 171 345 304 171 345 minecraft:cobblestone
fill 304 171 336 305 171 336 minecraft:cobblestone
fill 304 171 344 305 171 344 minecraft:cobblestone
fill 305 171 337 305 171 338 minecraft:cobblestone
fill 305 171 342 305 171 343 minecraft:cobblestone
setblock 306 171 325 minecraft:light[level=12]
setblock 306 171 332 minecraft:light[level=12]
fill 306 171 338 306 171 342 minecraft:cobblestone
setblock 306 171 346 minecraft:light[level=12]
setblock 306 171 353 minecraft:light[level=12]
setblock 306 171 360 minecraft:light[level=12]
setblock 313 171 325 minecraft:light[level=12]
setblock 313 171 332 minecraft:light[level=12]
setblock 313 171 339 minecraft:light[level=12]
setblock 313 171 346 minecraft:light[level=12]
setblock 313 171 353 minecraft:light[level=12]
setblock 313 171 360 minecraft:light[level=12]
setblock 320 171 325 minecraft:light[level=12]
setblock 320 171 332 minecraft:light[level=12]
setblock 320 171 339 minecraft:light[level=12]
setblock 320 171 346 minecraft:light[level=12]
setblock 320 171 353 minecraft:light[level=12]
setblock 320 171 360 minecraft:light[level=12]
fill 283 174 323 285 225 323 minecraft:polished_andesite
fill 283 174 331 290 174 339 minecraft:polished_andesite
fill 283 174 342 288 174 354 minecraft:polished_andesite
fill 283 174 357 283 225 359 minecraft:polished_andesite
fill 288 174 356 296 174 363 minecraft:polished_andesite
fill 295 174 323 297 179 323 minecraft:polished_andesite
fill 301 174 363 303 225 363 minecraft:polished_andesite
fill 304 174 323 312 184 329 minecraft:polished_andesite
fill 313 174 363 315 195 363 minecraft:polished_andesite
fill 319 174 323 321 225 323 minecraft:polished_andesite
fill 323 174 331 323 225 333 minecraft:polished_andesite
fill 323 174 343 323 225 345 minecraft:polished_andesite
fill 323 174 355 323 225 357 minecraft:polished_andesite
setblock 283 175 331 minecraft:shroomlight
fill 283 175 332 283 188 332 minecraft:polished_andesite
setblock 283 175 333 minecraft:shroomlight
fill 283 175 334 283 225 334 minecraft:polished_andesite
setblock 283 175 335 minecraft:shroomlight
fill 283 175 336 283 188 336 minecraft:polished_andesite
setblock 283 175 337 minecraft:shroomlight
fill 283 175 338 283 184 338 minecraft:polished_andesite
setblock 283 175 339 minecraft:shroomlight
fill 283 175 342 283 184 342 minecraft:polished_andesite
setblock 283 175 343 minecraft:shroomlight
fill 283 175 344 283 195 344 minecraft:polished_andesite
setblock 283 175 345 minecraft:shroomlight
fill 283 175 346 283 225 346 minecraft:polished_andesite
setblock 283 175 347 minecraft:shroomlight
fill 283 175 348 283 195 348 minecraft:polished_andesite
setblock 283 175 349 minecraft:shroomlight
fill 283 175 350 283 184 350 minecraft:polished_andesite
setblock 283 175 351 minecraft:shroomlight
fill 283 175 352 283 179 352 minecraft:polished_andesite
setblock 283 175 353 minecraft:shroomlight
fill 283 175 354 283 184 354 minecraft:polished_andesite
fill 284 175 331 284 188 331 minecraft:polished_andesite
setblock 284 175 332 minecraft:shroomlight
fill 284 175 333 284 188 333 minecraft:polished_andesite
setblock 284 175 334 minecraft:shroomlight
fill 284 175 335 284 188 335 minecraft:polished_andesite
setblock 284 175 336 minecraft:shroomlight
fill 284 175 337 284 188 337 minecraft:polished_andesite
setblock 284 175 338 minecraft:shroomlight
fill 284 175 339 284 188 339 minecraft:polished_andesite
setblock 284 175 342 minecraft:shroomlight
fill 284 175 343 284 195 343 minecraft:polished_andesite
setblock 284 175 344 minecraft:shroomlight
fill 284 175 345 284 195 345 minecraft:polished_andesite
setblock 284 175 346 minecraft:shroomlight
fill 284 175 347 284 195 347 minecraft:polished_andesite
setblock 284 175 348 minecraft:shroomlight
fill 284 175 349 284 195 349 minecraft:polished_andesite
setblock 284 175 350 minecraft:shroomlight
fill 284 175 351 284 195 351 minecraft:polished_andesite
setblock 284 175 352 minecraft:shroomlight
fill 284 175 353 284 195 353 minecraft:polished_andesite
setblock 284 175 354 minecraft:shroomlight
setblock 285 175 325 minecraft:light[level=15]
setblock 285 175 331 minecraft:shroomlight
fill 285 175 332 285 188 332 minecraft:polished_andesite
setblock 285 175 333 minecraft:shroomlight
fill 285 175 334 285 188 334 minecraft:polished_andesite
setblock 285 175 335 minecraft:shroomlight
fill 285 175 336 285 188 336 minecraft:polished_andesite
setblock 285 175 337 minecraft:shroomlight
fill 285 175 338 285 188 338 minecraft:polished_andesite
setblock 285 175 339 minecraft:shroomlight
setblock 285 175 341 minecraft:light[level=15]
fill 285 175 342 285 195 342 minecraft:polished_andesite
setblock 285 175 343 minecraft:shroomlight
fill 285 175 344 285 195 344 minecraft:polished_andesite
setblock 285 175 345 minecraft:shroomlight
fill 285 175 346 285 195 346 minecraft:polished_andesite
setblock 285 175 347 minecraft:shroomlight
fill 285 175 348 285 195 348 minecraft:polished_andesite
setblock 285 175 349 minecraft:shroomlight
fill 285 175 350 285 195 350 minecraft:polished_andesite
setblock 285 175 351 minecraft:shroomlight
fill 285 175 352 285 195 352 minecraft:polished_andesite
setblock 285 175 353 minecraft:shroomlight
fill 285 175 354 285 195 354 minecraft:polished_andesite
setblock 285 175 357 minecraft:light[level=15]
fill 286 175 331 286 188 331 minecraft:polished_andesite
setblock 286 175 332 minecraft:shroomlight
fill 286 175 333 286 188 333 minecraft:polished_andesite
setblock 286 175 334 minecraft:shroomlight
fill 286 175 335 286 188 335 minecraft:polished_andesite
setblock 286 175 336 minecraft:shroomlight
fill 286 175 337 286 188 337 minecraft:polished_andesite
setblock 286 175 338 minecraft:shroomlight
fill 286 175 339 286 188 339 minecraft:polished_andesite
setblock 286 175 342 minecraft:shroomlight
fill 286 175 343 286 195 343 minecraft:polished_andesite
setblock 286 175 344 minecraft:shroomlight
fill 286 175 345 286 195 345 minecraft:polished_andesite
setblock 286 175 346 minecraft:shroomlight
fill 286 175 347 286 195 347 minecraft:polished_andesite
setblock 286 175 348 minecraft:shroomlight
fill 286 175 349 286 195 349 minecraft:polished_andesite
setblock 286 175 350 minecraft:shroomlight
fill 286 175 351 286 195 351 minecraft:polished_andesite
setblock 286 175 352 minecraft:shroomlight
fill 286 175 353 286 195 353 minecraft:polished_andesite
setblock 286 175 354 minecraft:shroomlight
setblock 287 175 331 minecraft:shroomlight
fill 287 175 332 287 188 332 minecraft:polished_andesite
setblock 287 175 333 minecraft:shroomlight
fill 287 175 334 287 188 334 minecraft:polished_andesite
setblock 287 175 335 minecraft:shroomlight
fill 287 175 336 287 188 336 minecraft:polished_andesite
setblock 287 175 337 minecraft:shroomlight
fill 287 175 338 287 188 338 minecraft:polished_andesite
setblock 287 175 339 minecraft:shroomlight
fill 287 175 342 287 195 342 minecraft:polished_andesite
setblock 287 175 343 minecraft:shroomlight
fill 287 175 344 287 195 344 minecraft:polished_andesite
setblock 287 175 345 minecraft:shroomlight
fill 287 175 346 287 195 346 minecraft:polished_andesite
setblock 287 175 347 minecraft:shroomlight
fill 287 175 348 287 195 348 minecraft:polished_andesite
setblock 287 175 349 minecraft:shroomlight
fill 287 175 350 287 195 350 minecraft:polished_andesite
setblock 287 175 351 minecraft:shroomlight
fill 287 175 352 287 195 352 minecraft:polished_andesite
setblock 287 175 353 minecraft:shroomlight
fill 287 175 354 287 195 354 minecraft:polished_andesite
fill 288 175 331 288 188 331 minecraft:polished_andesite
setblock 288 175 332 minecraft:shroomlight
fill 288 175 333 288 188 333 minecraft:polished_andesite
setblock 288 175 334 minecraft:shroomlight
fill 288 175 335 288 188 335 minecraft:polished_andesite
setblock 288 175 336 minecraft:shroomlight
fill 288 175 337 288 188 337 minecraft:polished_andesite
setblock 288 175 338 minecraft:shroomlight
fill 288 175 339 288 188 339 minecraft:polished_andesite
setblock 288 175 342 minecraft:shroomlight
fill 288 175 343 288 195 343 minecraft:polished_andesite
setblock 288 175 344 minecraft:shroomlight
fill 288 175 345 288 195 345 minecraft:polished_andesite
setblock 288 175 346 minecraft:shroomlight
fill 288 175 347 288 195 347 minecraft:polished_andesite
setblock 288 175 348 minecraft:shroomlight
fill 288 175 349 288 195 349 minecraft:polished_andesite
setblock 288 175 350 minecraft:shroomlight
fill 288 175 351 288 195 351 minecraft:polished_andesite
setblock 288 175 352 minecraft:shroomlight
fill 288 175 353 288 195 353 minecraft:polished_andesite
setblock 288 175 354 minecraft:shroomlight
setblock 288 175 356 minecraft:shroomlight
fill 288 175 357 288 193 357 minecraft:polished_andesite
setblock 288 175 358 minecraft:shroomlight
fill 288 175 359 288 193 359 minecraft:polished_andesite
setblock 288 175 360 minecraft:shroomlight
fill 288 175 361 288 193 361 minecraft:polished_andesite
setblock 288 175 362 minecraft:shroomlight
fill 288 175 363 288 193 363 minecraft:polished_andesite
setblock 289 175 331 minecraft:shroomlight
fill 289 175 332 289 188 332 minecraft:polished_andesite
setblock 289 175 333 minecraft:shroomlight
fill 289 175 334 289 188 334 minecraft:polished_andesite
setblock 289 175 335 minecraft:shroomlight
fill 289 175 336 289 188 336 minecraft:polished_andesite
setblock 289 175 337 minecraft:shroomlight
fill 289 175 338 289 188 338 minecraft:polished_andesite
setblock 289 175 339 minecraft:shroomlight
fill 289 175 356 289 193 356 minecraft:polished_andesite
setblock 289 175 357 minecraft:shroomlight
fill 289 175 358 289 193 358 minecraft:polished_andesite
setblock 289 175 359 minecraft:shroomlight
fill 289 175 360 289 193 360 minecraft:polished_andesite
setblock 289 175 361 minecraft:shroomlight
fill 289 175 362 289 193 362 minecraft:polished_andesite
setblock 289 175 363 minecraft:shroomlight
fill 290 175 331 290 188 331 minecraft:polished_andesite
setblock 290 175 332 minecraft:shroomlight
fill 290 175 333 290 188 333 minecraft:polished_andesite
setblock 290 175 334 minecraft:shroomlight
fill 290 175 335 290 188 335 minecraft:polished_andesite
setblock 290 175 336 minecraft:shroomlight
fill 290 175 337 290 188 337 minecraft:polished_andesite
setblock 290 175 338 minecraft:shroomlight
fill 290 175 339 290 188 339 minecraft:polished_andesite
setblock 290 175 356 minecraft:shroomlight
fill 290 175 357 290 193 357 minecraft:polished_andesite
setblock 290 175 358 minecraft:shroomlight
fill 290 175 359 290 193 359 minecraft:polished_andesite
setblock 290 175 360 minecraft:shroomlight
fill 290 175 361 290 193 361 minecraft:polished_andesite
setblock 290 175 362 minecraft:shroomlight
fill 290 175 363 290 225 363 minecraft:polished_andesite
fill 291 175 356 291 193 356 minecraft:polished_andesite
setblock 291 175 357 minecraft:shroomlight
fill 291 175 358 291 193 358 minecraft:polished_andesite
setblock 291 175 359 minecraft:shroomlight
fill 291 175 360 291 193 360 minecraft:polished_andesite
setblock 291 175 361 minecraft:shroomlight
fill 291 175 362 291 193 362 minecraft:polished_andesite
setblock 291 175 363 minecraft:shroomlight
setblock 292 175 356 minecraft:shroomlight
fill 292 175 357 292 193 357 minecraft:polished_andesite
setblock 292 175 358 minecraft:shroomlight
fill 292 175 359 292 193 359 minecraft:polished_andesite
setblock 292 175 360 minecraft:shroomlight
fill 292 175 361 292 193 361 minecraft:polished_andesite
setblock 292 175 362 minecraft:shroomlight
fill 292 175 363 292 193 363 minecraft:polished_andesite
setblock 293 175 325 minecraft:light[level=15]
setblock 293 175 333 minecraft:light[level=15]
setblock 293 175 341 minecraft:light[level=15]
setblock 293 175 349 minecraft:light[level=15]
fill 293 175 356 293 193 356 minecraft:polished_andesite
setblock 293 175 357 minecraft:shroomlight
fill 293 175 358 293 193 358 minecraft:polished_andesite
setblock 293 175 359 minecraft:shroomlight
fill 293 175 360 293 193 360 minecraft:polished_andesite
setblock 293 175 361 minecraft:shroomlight
fill 293 175 362 293 193 362 minecraft:polished_andesite
setblock 293 175 363 minecraft:shroomlight
setblock 294 175 356 minecraft:shroomlight
fill 294 175 357 294 193 357 minecraft:polished_andesite
setblock 294 175 358 minecraft:shroomlight
fill 294 175 359 294 193 359 minecraft:polished_andesite
setblock 294 175 360 minecraft:shroomlight
fill 294 175 361 294 193 361 minecraft:polished_andesite
setblock 294 175 362 minecraft:shroomlight
fill 294 175 363 294 184 363 minecraft:polished_andesite
fill 295 175 356 295 193 356 minecraft:polished_andesite
setblock 295 175 357 minecraft:shroomlight
fill 295 175 358 295 193 358 minecraft:polished_andesite
setblock 295 175 359 minecraft:shroomlight
fill 295 175 360 295 193 360 minecraft:polished_andesite
setblock 295 175 361 minecraft:shroomlight
fill 295 175 362 295 193 362 minecraft:polished_andesite
setblock 295 175 363 minecraft:shroomlight
setblock 296 175 356 minecraft:shroomlight
fill 296 175 357 296 178 357 minecraft:polished_andesite
setblock 296 175 358 minecraft:shroomlight
fill 296 175 359 296 193 359 minecraft:polished_andesite
setblock 296 175 360 minecraft:shroomlight
fill 296 175 361 296 193 361 minecraft:polished_andesite
setblock 296 175 362 minecraft:shroomlight
fill 296 175 363 296 179 363 minecraft:polished_andesite
setblock 301 175 325 minecraft:light[level=15]
setblock 301 175 333 minecraft:light[level=15]
setblock 301 175 349 minecraft:light[level=15]
setblock 301 175 357 minecraft:light[level=15]
setblock 309 175 333 minecraft:light[level=15]
setblock 309 175 341 minecraft:light[level=15]
setblock 309 175 349 minecraft:light[level=15]
setblock 309 175 357 minecraft:light[level=15]
setblock 317 175 325 minecraft:light[level=15]
setblock 317 175 333 minecraft:light[level=15]
setblock 317 175 341 minecraft:light[level=15]
setblock 317 175 349 minecraft:light[level=15]
setblock 317 175 357 minecraft:light[level=15]
fill 283 176 331 283 177 331 minecraft:polished_andesite
fill 283 176 333 283 177 333 minecraft:polished_andesite
fill 283 176 335 283 177 335 minecraft:polished_andesite
fill 283 176 337 283 177 337 minecraft:polished_andesite
fill 283 176 339 283 177 339 minecraft:polished_andesite
fill 283 176 343 283 177 343 minecraft:polished_andesite
fill 283 176 345 283 177 345 minecraft:polished_andesite
fill 283 176 347 283 177 347 minecraft:polished_andesite
fill 283 176 349 283 177 349 minecraft:polished_andesite
fill 283 176 351 283 177 351 minecraft:polished_andesite
fill 283 176 353 283 177 353 minecraft:polished_andesite
fill 284 176 332 284 177 332 minecraft:polished_andesite
fill 284 176 334 284 177 334 minecraft:polished_andesite
fill 284 176 336 284 177 336 minecraft:polished_andesite
fill 284 176 338 284 177 338 minecraft:polished_andesite
fill 284 176 342 284 177 342 minecraft:polished_andesite
fill 284 176 344 284 177 344 minecraft:polished_andesite
fill 284 176 346 284 177 346 minecraft:polished_andesite
fill 284 176 348 284 177 348 minecraft:polished_andesite
fill 284 176 350 284 177 350 minecraft:polished_andesite
fill 284 176 352 284 177 352 minecraft:polished_andesite
fill 284 176 354 284 177 354 minecraft:polished_andesite
fill 285 176 331 285 177 331 minecraft:polished_andesite
fill 285 176 333 285 177 333 minecraft:polished_andesite
fill 285 176 335 285 177 335 minecraft:polished_andesite
fill 285 176 337 285 177 337 minecraft:polished_andesite
fill 285 176 339 285 177 339 minecraft:polished_andesite
fill 285 176 343 285 177 343 minecraft:polished_andesite
fill 285 176 345 285 177 345 minecraft:polished_andesite
fill 285 176 347 285 177 347 minecraft:polished_andesite
fill 285 176 349 285 177 349 minecraft:polished_andesite
fill 285 176 351 285 177 351 minecraft:polished_andesite
fill 285 176 353 285 177 353 minecraft:polished_andesite
fill 286 176 332 286 177 332 minecraft:polished_andesite
fill 286 176 334 286 177 334 minecraft:polished_andesite
fill 286 176 336 286 177 336 minecraft:polished_andesite
fill 286 176 338 286 177 338 minecraft:polished_andesite
fill 286 176 342 286 177 342 minecraft:polished_andesite
fill 286 176 344 286 177 344 minecraft:polished_andesite
fill 286 176 346 286 177 346 minecraft:polished_andesite
fill 286 176 348 286 177 348 minecraft:polished_andesite
fill 286 176 350 286 177 350 minecraft:polished_andesite
fill 286 176 352 286 177 352 minecraft:polished_andesite
fill 286 176 354 286 177 354 minecraft:polished_andesite
fill 287 176 331 287 177 331 minecraft:polished_andesite
fill 287 176 333 287 177 333 minecraft:polished_andesite
fill 287 176 335 287 177 335 minecraft:polished_andesite
fill 287 176 337 287 177 337 minecraft:polished_andesite
fill 287 176 339 287 177 339 minecraft:polished_andesite
schedule function dropper:buildpart/78_2 1t
