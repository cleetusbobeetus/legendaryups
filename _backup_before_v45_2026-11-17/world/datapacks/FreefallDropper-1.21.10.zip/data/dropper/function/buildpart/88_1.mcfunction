setblock 188 16 401 minecraft:lime_terracotta
fill 188 16 403 188 18 403 minecraft:green_concrete
fill 188 16 409 188 17 410 minecraft:lime_terracotta
fill 188 16 411 189 21 411 minecraft:green_concrete
fill 190 16 369 190 21 369 minecraft:green_concrete
setblock 192 16 369 minecraft:lime_terracotta
fill 193 16 369 194 21 369 minecraft:green_concrete
fill 195 16 369 195 17 369 minecraft:lime_terracotta
fill 195 16 411 195 17 411 minecraft:lime_terracotta
fill 197 16 411 197 21 411 minecraft:green_concrete
fill 198 16 411 199 16 411 minecraft:lime_terracotta
fill 200 16 411 200 21 411 minecraft:green_concrete
fill 201 16 369 202 21 369 minecraft:green_concrete
fill 203 16 369 204 16 369 minecraft:lime_terracotta
fill 206 16 411 207 17 411 minecraft:lime_terracotta
fill 208 16 411 209 21 411 minecraft:green_concrete
fill 213 16 369 214 21 369 minecraft:green_concrete
fill 215 16 369 216 17 369 minecraft:lime_terracotta
fill 218 16 411 219 16 411 minecraft:lime_terracotta
fill 220 16 411 221 21 411 minecraft:green_concrete
fill 222 16 369 222 21 369 minecraft:green_concrete
fill 223 16 369 224 16 369 minecraft:lime_terracotta
fill 225 16 369 225 21 369 minecraft:green_concrete
fill 227 16 369 227 17 369 minecraft:lime_terracotta
fill 227 16 411 227 17 411 minecraft:lime_terracotta
fill 228 16 411 229 21 411 minecraft:green_concrete
fill 230 16 372 230 21 373 minecraft:green_concrete
fill 230 16 374 230 17 375 minecraft:lime_terracotta
setblock 230 16 383 minecraft:lime_terracotta
fill 230 16 384 230 21 385 minecraft:green_concrete
fill 230 16 386 230 17 387 minecraft:lime_terracotta
fill 230 16 392 230 21 393 minecraft:green_concrete
fill 230 16 394 230 16 395 minecraft:lime_terracotta
fill 230 16 396 230 21 396 minecraft:green_concrete
fill 230 16 404 230 21 405 minecraft:green_concrete
fill 230 16 406 230 17 407 minecraft:lime_terracotta
setblock 230 16 411 minecraft:lime_terracotta
fill 188 17 369 188 20 370 minecraft:green_concrete
fill 188 17 385 188 17 386 minecraft:lime_terracotta
setblock 188 17 389 minecraft:lime_terracotta
fill 188 17 390 188 20 390 minecraft:green_concrete
fill 188 17 401 188 20 401 minecraft:green_concrete
fill 188 17 405 188 19 405 minecraft:green_concrete
setblock 188 17 406 minecraft:lime_terracotta
fill 192 17 369 192 20 369 minecraft:green_concrete
setblock 194 17 411 minecraft:lime_terracotta
setblock 196 17 369 minecraft:lime_terracotta
fill 198 17 411 199 20 411 minecraft:green_concrete
fill 203 17 369 203 20 369 minecraft:green_concrete
setblock 204 17 369 minecraft:lime_terracotta
setblock 207 17 369 minecraft:lime_terracotta
setblock 215 17 411 minecraft:lime_terracotta
setblock 218 17 411 minecraft:lime_terracotta
fill 219 17 411 219 20 411 minecraft:green_concrete
fill 223 17 369 224 20 369 minecraft:green_concrete
setblock 226 17 411 minecraft:lime_terracotta
setblock 228 17 369 minecraft:lime_terracotta
setblock 230 17 378 minecraft:lime_terracotta
fill 230 17 383 230 20 383 minecraft:green_concrete
fill 230 17 394 230 20 394 minecraft:green_concrete
setblock 230 17 395 minecraft:lime_terracotta
fill 230 17 398 230 17 399 minecraft:lime_terracotta
fill 230 17 411 230 20 411 minecraft:green_concrete
fill 188 18 375 188 19 376 minecraft:lime_terracotta
fill 188 18 377 188 23 378 minecraft:green_concrete
fill 188 18 384 188 19 384 minecraft:lime_terracotta
fill 188 18 385 188 19 386 minecraft:green_concrete
fill 188 18 387 188 18 388 minecraft:lime_terracotta
fill 188 18 389 188 23 389 minecraft:green_concrete
fill 188 18 395 188 19 396 minecraft:lime_terracotta
fill 188 18 397 188 23 398 minecraft:green_concrete
fill 188 18 406 188 23 406 minecraft:green_concrete
fill 188 18 407 188 18 408 minecraft:lime_terracotta
fill 188 18 409 188 23 410 minecraft:green_concrete
fill 189 18 370 191 18 370 minecraft:mud
fill 189 18 372 189 18 374 minecraft:mud
fill 189 18 376 189 18 378 minecraft:mud
fill 189 18 380 189 18 382 minecraft:mud
fill 189 18 384 189 18 386 minecraft:mud
fill 189 18 388 189 18 390 minecraft:mud
fill 189 18 392 189 18 394 minecraft:mud
fill 189 18 396 189 18 398 minecraft:mud
fill 189 18 400 189 18 402 minecraft:mud
fill 189 18 404 189 18 406 minecraft:mud
fill 189 18 408 189 18 410 minecraft:mud
fill 191 18 410 193 18 410 minecraft:mud
fill 192 18 411 193 19 411 minecraft:lime_terracotta
fill 193 18 370 195 18 370 minecraft:mud
fill 194 18 411 195 23 411 minecraft:green_concrete
fill 195 18 369 196 23 369 minecraft:green_concrete
fill 195 18 410 197 18 410 minecraft:mud
setblock 196 18 411 minecraft:lime_terracotta
fill 197 18 369 198 19 369 minecraft:lime_terracotta
fill 197 18 370 199 18 370 minecraft:mud
fill 199 18 410 201 18 410 minecraft:mud
fill 201 18 370 203 18 370 minecraft:mud
fill 203 18 410 205 18 410 minecraft:mud
fill 204 18 369 204 23 369 minecraft:green_concrete
fill 204 18 411 205 19 411 minecraft:lime_terracotta
fill 205 18 369 206 18 369 minecraft:lime_terracotta
fill 205 18 370 207 18 370 minecraft:mud
fill 206 18 411 207 23 411 minecraft:green_concrete
fill 207 18 369 207 23 369 minecraft:green_concrete
fill 207 18 410 209 18 410 minecraft:mud
fill 209 18 369 209 19 369 minecraft:lime_terracotta
fill 209 18 370 211 18 370 minecraft:mud
fill 211 18 410 213 18 410 minecraft:mud
fill 213 18 370 215 18 370 minecraft:mud
fill 213 18 411 213 19 411 minecraft:lime_terracotta
fill 215 18 369 216 23 369 minecraft:green_concrete
fill 215 18 410 217 18 410 minecraft:mud
fill 215 18 411 215 23 411 minecraft:green_concrete
fill 216 18 411 217 18 411 minecraft:lime_terracotta
fill 217 18 369 218 19 369 minecraft:lime_terracotta
fill 217 18 370 219 18 370 minecraft:mud
fill 218 18 411 218 23 411 minecraft:green_concrete
fill 219 18 410 221 18 410 minecraft:mud
fill 221 18 370 223 18 370 minecraft:mud
fill 223 18 410 225 18 410 minecraft:mud
fill 224 18 411 225 19 411 minecraft:lime_terracotta
fill 225 18 370 227 18 370 minecraft:mud
setblock 226 18 369 minecraft:lime_terracotta
fill 226 18 411 227 23 411 minecraft:green_concrete
fill 227 18 369 228 23 369 minecraft:green_concrete
fill 227 18 410 229 18 410 minecraft:mud
fill 229 18 369 230 19 369 minecraft:lime_terracotta
fill 229 18 370 229 18 372 minecraft:mud
fill 229 18 374 229 18 376 minecraft:mud
fill 229 18 378 229 18 380 minecraft:mud
fill 229 18 382 229 18 384 minecraft:mud
fill 229 18 386 229 18 388 minecraft:mud
fill 229 18 390 229 18 392 minecraft:mud
fill 229 18 394 229 18 396 minecraft:mud
fill 229 18 398 229 18 400 minecraft:mud
fill 229 18 402 229 18 404 minecraft:mud
fill 229 18 406 229 18 408 minecraft:mud
fill 230 18 374 230 23 375 minecraft:green_concrete
fill 230 18 376 230 18 377 minecraft:lime_terracotta
fill 230 18 378 230 23 378 minecraft:green_concrete
fill 230 18 386 230 23 387 minecraft:green_concrete
fill 230 18 388 230 19 389 minecraft:lime_terracotta
fill 230 18 395 230 23 395 minecraft:green_concrete
setblock 230 18 397 minecraft:lime_terracotta
fill 230 18 398 230 23 399 minecraft:green_concrete
fill 230 18 400 230 19 400 minecraft:lime_terracotta
fill 230 18 406 230 23 407 minecraft:green_concrete
fill 230 18 408 230 18 409 minecraft:lime_terracotta
setblock 188 19 372 minecraft:lime_terracotta
setblock 188 19 383 minecraft:lime_terracotta
fill 188 19 387 188 21 388 minecraft:green_concrete
fill 188 19 403 188 19 404 minecraft:lime_terracotta
setblock 188 19 407 minecraft:lime_terracotta
fill 188 19 408 188 22 408 minecraft:green_concrete
setblock 189 19 369 minecraft:lime_terracotta
fill 196 19 411 196 22 411 minecraft:green_concrete
setblock 201 19 411 minecraft:lime_terracotta
fill 205 19 369 206 22 369 minecraft:green_concrete
setblock 210 19 369 minecraft:lime_terracotta
setblock 212 19 411 minecraft:lime_terracotta
fill 216 19 411 217 22 411 minecraft:green_concrete
setblock 221 19 369 minecraft:lime_terracotta
fill 226 19 369 226 22 369 minecraft:green_concrete
fill 230 19 376 230 22 376 minecraft:green_concrete
setblock 230 19 377 minecraft:lime_terracotta
fill 230 19 380 230 19 381 minecraft:lime_terracotta
fill 230 19 397 230 22 397 minecraft:green_concrete
setblock 230 19 401 minecraft:lime_terracotta
fill 230 19 408 230 22 408 minecraft:green_concrete
setblock 230 19 409 minecraft:lime_terracotta
fill 188 20 372 188 25 372 minecraft:green_concrete
fill 188 20 373 188 20 374 minecraft:lime_terracotta
fill 188 20 375 188 22 376 minecraft:green_concrete
fill 188 20 381 188 21 382 minecraft:lime_terracotta
fill 188 20 383 188 25 384 minecraft:green_concrete
setblock 188 20 385 minecraft:lime_terracotta
fill 188 20 386 188 23 386 minecraft:green_concrete
fill 188 20 393 188 21 394 minecraft:lime_terracotta
fill 188 20 395 188 25 396 minecraft:green_concrete
fill 188 20 402 188 21 402 minecraft:lime_terracotta
fill 188 20 403 188 25 404 minecraft:green_concrete
setblock 188 20 405 minecraft:lime_terracotta
fill 188 20 407 188 25 407 minecraft:green_concrete
fill 189 20 369 189 25 369 minecraft:green_concrete
fill 190 20 411 191 21 411 minecraft:lime_terracotta
fill 191 20 369 191 21 369 minecraft:lime_terracotta
fill 192 20 411 193 25 411 minecraft:green_concrete
fill 197 20 369 198 25 369 minecraft:green_concrete
fill 199 20 369 200 21 369 minecraft:lime_terracotta
fill 201 20 411 201 25 411 minecraft:green_concrete
fill 202 20 411 203 20 411 minecraft:lime_terracotta
fill 204 20 411 205 25 411 minecraft:green_concrete
setblock 208 20 369 minecraft:lime_terracotta
fill 209 20 369 210 25 369 minecraft:green_concrete
fill 210 20 411 211 21 411 minecraft:lime_terracotta
fill 211 20 369 212 21 369 minecraft:lime_terracotta
fill 212 20 411 213 25 411 minecraft:green_concrete
setblock 214 20 411 minecraft:lime_terracotta
fill 217 20 369 218 25 369 minecraft:green_concrete
fill 219 20 369 220 20 369 minecraft:lime_terracotta
fill 221 20 369 221 25 369 minecraft:green_concrete
fill 222 20 411 223 21 411 minecraft:lime_terracotta
fill 224 20 411 225 25 411 minecraft:green_concrete
fill 229 20 369 230 25 369 minecraft:green_concrete
fill 230 20 370 230 21 371 minecraft:lime_terracotta
fill 230 20 377 230 25 377 minecraft:green_concrete
setblock 230 20 379 minecraft:lime_terracotta
fill 230 20 380 230 25 381 minecraft:green_concrete
fill 230 20 382 230 21 382 minecraft:lime_terracotta
fill 230 20 388 230 25 389 minecraft:green_concrete
fill 230 20 390 230 20 391 minecraft:lime_terracotta
fill 230 20 400 230 25 401 minecraft:green_concrete
fill 230 20 402 230 21 403 minecraft:lime_terracotta
fill 230 20 409 230 25 409 minecraft:green_concrete
setblock 230 20 410 minecraft:lime_terracotta
fill 188 21 369 188 21 370 minecraft:lime_terracotta
setblock 188 21 373 minecraft:lime_terracotta
fill 188 21 374 188 24 374 minecraft:green_concrete
fill 188 21 385 188 23 385 minecraft:green_concrete
setblock 188 21 390 minecraft:lime_terracotta
setblock 188 21 401 minecraft:lime_terracotta
fill 188 21 405 188 24 405 minecraft:green_concrete
setblock 192 21 369 minecraft:lime_terracotta
fill 198 21 411 199 21 411 minecraft:lime_terracotta
setblock 202 21 411 minecraft:lime_terracotta
setblock 203 21 369 minecraft:lime_terracotta
fill 203 21 411 203 24 411 minecraft:green_concrete
fill 208 21 369 208 24 369 minecraft:green_concrete
fill 214 21 411 214 24 411 minecraft:green_concrete
fill 219 21 369 219 24 369 minecraft:green_concrete
setblock 219 21 411 minecraft:lime_terracotta
setblock 220 21 369 minecraft:lime_terracotta
fill 223 21 369 224 21 369 minecraft:lime_terracotta
fill 230 21 379 230 24 379 minecraft:green_concrete
setblock 230 21 383 minecraft:lime_terracotta
fill 230 21 390 230 24 390 minecraft:green_concrete
setblock 230 21 391 minecraft:lime_terracotta
setblock 230 21 394 minecraft:lime_terracotta
fill 230 21 410 230 24 410 minecraft:green_concrete
setblock 230 21 411 minecraft:lime_terracotta
fill 188 22 369 188 27 370 minecraft:green_concrete
setblock 188 22 371 minecraft:lime_terracotta
fill 188 22 373 188 24 373 minecraft:green_concrete
fill 188 22 379 188 23 380 minecraft:lime_terracotta
fill 188 22 381 188 27 382 minecraft:green_concrete
setblock 188 22 387 minecraft:green_concrete
fill 188 22 388 188 23 388 minecraft:lime_terracotta
fill 188 22 390 188 27 390 minecraft:green_concrete
fill 188 22 391 188 22 392 minecraft:lime_terracotta
fill 188 22 393 188 24 394 minecraft:green_concrete
fill 188 22 399 188 23 400 minecraft:lime_terracotta
fill 188 22 401 188 27 402 minecraft:green_concrete
fill 188 22 411 189 22 411 minecraft:lime_terracotta
setblock 190 22 369 minecraft:lime_terracotta
fill 190 22 411 191 27 411 minecraft:green_concrete
fill 191 22 369 192 27 369 minecraft:green_concrete
fill 193 22 369 194 23 369 minecraft:lime_terracotta
fill 197 22 411 197 23 411 minecraft:lime_terracotta
fill 198 22 411 199 27 411 minecraft:green_concrete
fill 199 22 369 200 27 369 minecraft:green_concrete
setblock 200 22 411 minecraft:lime_terracotta
fill 201 22 369 202 22 369 minecraft:lime_terracotta
fill 202 22 411 202 27 411 minecraft:green_concrete
fill 203 22 369 203 27 369 minecraft:green_concrete
fill 208 22 411 209 23 411 minecraft:lime_terracotta
fill 210 22 411 211 27 411 minecraft:green_concrete
fill 211 22 369 212 27 369 minecraft:green_concrete
fill 213 22 369 214 23 369 minecraft:lime_terracotta
fill 219 22 411 219 27 411 minecraft:green_concrete
fill 220 22 369 220 27 369 minecraft:green_concrete
fill 220 22 411 221 22 411 minecraft:lime_terracotta
setblock 222 22 369 minecraft:lime_terracotta
fill 222 22 411 223 27 411 minecraft:green_concrete
fill 223 22 369 224 27 369 minecraft:green_concrete
fill 225 22 369 225 23 369 minecraft:lime_terracotta
fill 228 22 411 229 23 411 minecraft:lime_terracotta
fill 230 22 370 230 27 371 minecraft:green_concrete
fill 230 22 372 230 22 373 minecraft:lime_terracotta
fill 230 22 382 230 27 383 minecraft:green_concrete
fill 230 22 384 230 23 385 minecraft:lime_terracotta
fill 230 22 391 230 27 391 minecraft:green_concrete
fill 230 22 392 230 22 393 minecraft:lime_terracotta
fill 230 22 394 230 27 394 minecraft:green_concrete
fill 230 22 396 230 23 396 minecraft:lime_terracotta
fill 230 22 402 230 27 403 minecraft:green_concrete
fill 230 22 404 230 23 405 minecraft:lime_terracotta
fill 230 22 411 230 27 411 minecraft:green_concrete
fill 188 23 371 188 26 371 minecraft:green_concrete
fill 188 23 375 188 25 375 minecraft:green_concrete
setblock 188 23 376 minecraft:lime_terracotta
setblock 188 23 387 minecraft:lime_terracotta
setblock 188 23 391 minecraft:lime_terracotta
fill 188 23 392 188 26 392 minecraft:green_concrete
setblock 188 23 408 minecraft:lime_terracotta
setblock 188 23 411 minecraft:lime_terracotta
fill 189 23 411 189 26 411 minecraft:green_concrete
fill 190 23 369 190 26 369 minecraft:green_concrete
setblock 191 23 372 minecraft:light[level=14]
setblock 191 23 380 minecraft:light[level=14]
setblock 191 23 388 minecraft:light[level=14]
setblock 191 23 396 minecraft:light[level=14]
setblock 191 23 404 minecraft:light[level=14]
setblock 196 23 411 minecraft:lime_terracotta
setblock 199 23 380 minecraft:light[level=14]
setblock 199 23 388 minecraft:light[level=14]
setblock 199 23 396 minecraft:light[level=14]
setblock 199 23 404 minecraft:light[level=14]
fill 200 23 411 200 26 411 minecraft:green_concrete
fill 201 23 369 201 26 369 minecraft:green_concrete
setblock 202 23 369 minecraft:lime_terracotta
fill 205 23 369 206 23 369 minecraft:lime_terracotta
setblock 207 23 372 minecraft:light[level=14]
setblock 207 23 380 minecraft:light[level=14]
setblock 207 23 388 minecraft:light[level=14]
setblock 207 23 396 minecraft:light[level=14]
setblock 207 23 404 minecraft:light[level=14]
setblock 215 23 372 minecraft:light[level=14]
setblock 215 23 380 minecraft:light[level=14]
setblock 215 23 388 minecraft:light[level=14]
setblock 215 23 396 minecraft:light[level=14]
setblock 215 23 404 minecraft:light[level=14]
fill 216 23 411 217 23 411 minecraft:lime_terracotta
setblock 220 23 411 minecraft:lime_terracotta
fill 221 23 411 221 26 411 minecraft:green_concrete
fill 222 23 369 222 26 369 minecraft:green_concrete
setblock 223 23 372 minecraft:light[level=14]
setblock 223 23 380 minecraft:light[level=14]
setblock 223 23 388 minecraft:light[level=14]
setblock 223 23 396 minecraft:light[level=14]
setblock 223 23 404 minecraft:light[level=14]
setblock 226 23 369 minecraft:lime_terracotta
fill 230 23 372 230 26 372 minecraft:green_concrete
setblock 230 23 373 minecraft:lime_terracotta
setblock 230 23 376 minecraft:lime_terracotta
fill 230 23 392 230 26 393 minecraft:green_concrete
setblock 230 23 397 minecraft:lime_terracotta
setblock 230 23 408 minecraft:lime_terracotta
fill 188 24 376 188 25 376 minecraft:green_concrete
fill 188 24 377 188 24 378 minecraft:lime_terracotta
fill 188 24 379 188 29 380 minecraft:green_concrete
fill 188 24 385 188 25 386 minecraft:lime_terracotta
fill 188 24 387 188 29 388 minecraft:green_concrete
setblock 188 24 389 minecraft:lime_terracotta
fill 188 24 391 188 26 391 minecraft:green_concrete
fill 188 24 397 188 25 398 minecraft:lime_terracotta
fill 188 24 399 188 29 400 minecraft:green_concrete
fill 188 24 406 188 25 406 minecraft:lime_terracotta
fill 188 24 408 188 29 408 minecraft:green_concrete
fill 188 24 409 188 24 410 minecraft:lime_terracotta
fill 188 24 411 188 29 411 minecraft:green_concrete
fill 189 24 370 191 24 370 minecraft:mud
fill 189 24 372 189 24 374 minecraft:mud
fill 189 24 376 189 24 378 minecraft:mud
fill 189 24 380 189 24 382 minecraft:mud
fill 189 24 384 189 24 386 minecraft:mud
fill 189 24 388 189 24 390 minecraft:mud
fill 189 24 392 189 24 394 minecraft:mud
fill 189 24 396 189 24 398 minecraft:mud
fill 189 24 400 189 24 402 minecraft:mud
fill 189 24 404 189 24 406 minecraft:mud
fill 189 24 408 189 24 410 minecraft:mud
fill 191 24 410 193 24 410 minecraft:mud
fill 193 24 369 194 29 369 minecraft:green_concrete
fill 193 24 370 195 24 370 minecraft:mud
fill 194 24 411 195 25 411 minecraft:lime_terracotta
fill 195 24 369 196 25 369 minecraft:lime_terracotta
fill 195 24 410 197 24 410 minecraft:mud
fill 196 24 411 197 29 411 minecraft:green_concrete
fill 197 24 370 199 24 370 minecraft:mud
fill 199 24 410 201 24 410 minecraft:mud
fill 201 24 370 203 24 370 minecraft:mud
fill 202 24 369 202 29 369 minecraft:green_concrete
fill 203 24 410 205 24 410 minecraft:mud
setblock 204 24 369 minecraft:lime_terracotta
fill 205 24 369 206 29 369 minecraft:green_concrete
fill 205 24 370 207 24 370 minecraft:mud
fill 206 24 411 207 24 411 minecraft:lime_terracotta
fill 207 24 369 207 25 369 minecraft:lime_terracotta
fill 207 24 410 209 24 410 minecraft:mud
fill 208 24 411 209 29 411 minecraft:green_concrete
fill 209 24 370 211 24 370 minecraft:mud
fill 211 24 410 213 24 410 minecraft:mud
fill 213 24 369 214 29 369 minecraft:green_concrete
fill 213 24 370 215 24 370 minecraft:mud
fill 215 24 369 216 24 369 minecraft:lime_terracotta
fill 215 24 410 217 24 410 minecraft:mud
fill 215 24 411 215 25 411 minecraft:lime_terracotta
fill 216 24 411 217 29 411 minecraft:green_concrete
fill 217 24 370 219 24 370 minecraft:mud
setblock 218 24 411 minecraft:lime_terracotta
fill 219 24 410 221 24 410 minecraft:mud
fill 220 24 411 220 29 411 minecraft:green_concrete
fill 221 24 370 223 24 370 minecraft:mud
fill 223 24 399 224 25 400 minecraft:lime_concrete
fill 223 24 410 225 24 410 minecraft:mud
fill 225 24 369 226 29 369 minecraft:green_concrete
fill 225 24 370 227 24 370 minecraft:mud
fill 226 24 411 227 25 411 minecraft:lime_terracotta
fill 227 24 369 228 25 369 minecraft:lime_terracotta
fill 227 24 410 229 24 410 minecraft:mud
fill 228 24 411 229 29 411 minecraft:green_concrete
fill 229 24 370 229 24 372 minecraft:mud
fill 229 24 374 229 24 376 minecraft:mud
fill 229 24 378 229 24 380 minecraft:mud
fill 229 24 382 229 24 384 minecraft:mud
fill 229 24 386 229 24 388 minecraft:mud
fill 229 24 390 229 24 392 minecraft:mud
fill 229 24 394 229 24 396 minecraft:mud
fill 229 24 398 229 24 400 minecraft:mud
fill 229 24 402 229 24 404 minecraft:mud
fill 229 24 406 229 24 408 minecraft:mud
fill 230 24 373 230 29 373 minecraft:green_concrete
fill 230 24 374 230 24 375 minecraft:lime_terracotta
fill 230 24 376 230 29 376 minecraft:green_concrete
fill 230 24 378 230 25 378 minecraft:lime_terracotta
fill 230 24 384 230 29 385 minecraft:green_concrete
fill 230 24 386 230 25 387 minecraft:lime_terracotta
setblock 230 24 395 minecraft:lime_terracotta
fill 230 24 396 230 29 397 minecraft:green_concrete
fill 230 24 398 230 25 399 minecraft:lime_terracotta
fill 230 24 404 230 29 405 minecraft:green_concrete
fill 230 24 406 230 24 407 minecraft:lime_terracotta
fill 230 24 408 230 29 408 minecraft:green_concrete
fill 188 25 373 188 25 374 minecraft:lime_terracotta
setblock 188 25 377 minecraft:lime_terracotta
fill 188 25 378 188 28 378 minecraft:green_concrete
fill 188 25 389 188 28 389 minecraft:green_concrete
fill 188 25 393 188 27 393 minecraft:green_concrete
setblock 188 25 394 minecraft:lime_terracotta
setblock 188 25 405 minecraft:lime_terracotta
fill 188 25 409 188 28 410 minecraft:green_concrete
setblock 203 25 411 minecraft:lime_terracotta
fill 204 25 369 204 28 369 minecraft:green_concrete
setblock 206 25 411 minecraft:lime_terracotta
fill 207 25 411 207 28 411 minecraft:green_concrete
setblock 208 25 369 minecraft:lime_terracotta
setblock 214 25 411 minecraft:lime_terracotta
fill 215 25 369 215 28 369 minecraft:green_concrete
setblock 216 25 369 minecraft:lime_terracotta
fill 218 25 411 218 28 411 minecraft:green_concrete
setblock 219 25 369 minecraft:lime_terracotta
fill 230 25 374 230 28 375 minecraft:green_concrete
setblock 230 25 379 minecraft:lime_terracotta
setblock 230 25 390 minecraft:lime_terracotta
fill 230 25 395 230 28 395 minecraft:green_concrete
fill 230 25 406 230 28 406 minecraft:green_concrete
setblock 230 25 407 minecraft:lime_terracotta
setblock 230 25 410 minecraft:lime_terracotta
fill 188 26 372 188 27 372 minecraft:lime_terracotta
fill 188 26 373 188 27 374 minecraft:green_concrete
fill 188 26 375 188 26 376 minecraft:lime_terracotta
fill 188 26 377 188 31 377 minecraft:green_concrete
fill 188 26 383 188 27 384 minecraft:lime_terracotta
fill 188 26 385 188 31 386 minecraft:green_concrete
fill 188 26 394 188 31 394 minecraft:green_concrete
fill 188 26 395 188 26 396 minecraft:lime_terracotta
fill 188 26 397 188 31 398 minecraft:green_concrete
fill 188 26 403 188 27 404 minecraft:lime_terracotta
fill 188 26 405 188 31 406 minecraft:green_concrete
setblock 188 26 407 minecraft:lime_terracotta
fill 189 26 369 189 27 369 minecraft:lime_terracotta
fill 192 26 411 193 27 411 minecraft:lime_terracotta
fill 194 26 411 195 31 411 minecraft:green_concrete
fill 195 26 369 196 31 369 minecraft:green_concrete
fill 197 26 369 198 26 369 minecraft:lime_terracotta
fill 201 26 411 201 27 411 minecraft:lime_terracotta
fill 203 26 411 203 31 411 minecraft:green_concrete
fill 204 26 411 205 26 411 minecraft:lime_terracotta
fill 206 26 411 206 31 411 minecraft:green_concrete
fill 207 26 369 208 31 369 minecraft:green_concrete
fill 209 26 369 210 27 369 minecraft:lime_terracotta
fill 212 26 411 213 27 411 minecraft:lime_terracotta
fill 214 26 411 215 31 411 minecraft:green_concrete
fill 216 26 369 216 31 369 minecraft:green_concrete
fill 217 26 369 218 26 369 minecraft:lime_terracotta
fill 219 26 369 219 31 369 minecraft:green_concrete
fill 221 26 369 221 27 369 minecraft:lime_terracotta
fill 224 26 411 225 26 411 minecraft:lime_terracotta
fill 226 26 411 227 31 411 minecraft:green_concrete
fill 227 26 369 228 31 369 minecraft:green_concrete
fill 229 26 369 230 27 369 minecraft:lime_terracotta
setblock 230 26 377 minecraft:lime_terracotta
fill 230 26 378 230 31 379 minecraft:green_concrete
fill 230 26 380 230 27 381 minecraft:lime_terracotta
fill 230 26 386 230 31 387 minecraft:green_concrete
fill 230 26 388 230 26 389 minecraft:lime_terracotta
fill 230 26 390 230 31 390 minecraft:green_concrete
fill 230 26 398 230 31 399 minecraft:green_concrete
fill 230 26 400 230 27 401 minecraft:lime_terracotta
fill 230 26 407 230 31 407 minecraft:green_concrete
setblock 230 26 409 minecraft:lime_terracotta
fill 230 26 410 230 31 410 minecraft:green_concrete
setblock 188 27 371 minecraft:lime_terracotta
fill 188 27 375 188 29 376 minecraft:green_concrete
fill 188 27 391 188 27 392 minecraft:lime_terracotta
setblock 188 27 395 minecraft:lime_terracotta
fill 188 27 396 188 30 396 minecraft:green_concrete
fill 188 27 407 188 30 407 minecraft:green_concrete
setblock 189 27 411 minecraft:lime_terracotta
setblock 190 27 369 minecraft:lime_terracotta
fill 197 27 369 197 30 369 minecraft:green_concrete
setblock 198 27 369 minecraft:lime_terracotta
setblock 200 27 411 minecraft:lime_terracotta
setblock 201 27 369 minecraft:lime_terracotta
fill 204 27 411 205 30 411 minecraft:green_concrete
fill 217 27 369 218 30 369 minecraft:green_concrete
setblock 221 27 411 minecraft:lime_terracotta
setblock 222 27 369 minecraft:lime_terracotta
setblock 224 27 411 minecraft:lime_terracotta
fill 225 27 411 225 30 411 minecraft:green_concrete
setblock 230 27 372 minecraft:lime_terracotta
fill 230 27 377 230 30 377 minecraft:green_concrete
fill 230 27 388 230 30 388 minecraft:green_concrete
setblock 230 27 389 minecraft:lime_terracotta
fill 230 27 392 230 27 393 minecraft:lime_terracotta
fill 230 27 409 230 30 409 minecraft:green_concrete
fill 188 28 369 188 29 370 minecraft:lime_terracotta
fill 188 28 371 188 33 372 minecraft:green_concrete
setblock 188 28 373 minecraft:lime_terracotta
fill 188 28 374 188 31 374 minecraft:green_concrete
fill 188 28 381 188 29 382 minecraft:lime_terracotta
fill 188 28 383 188 33 384 minecraft:green_concrete
fill 188 28 390 188 29 390 minecraft:lime_terracotta
fill 188 28 391 188 33 392 minecraft:green_concrete
setblock 188 28 393 minecraft:lime_terracotta
fill 188 28 395 188 33 395 minecraft:green_concrete
fill 188 28 401 188 29 402 minecraft:lime_terracotta
fill 188 28 403 188 33 404 minecraft:green_concrete
fill 189 28 369 190 33 369 minecraft:green_concrete
fill 189 28 411 189 33 411 minecraft:green_concrete
fill 190 28 411 191 28 411 minecraft:lime_terracotta
fill 191 28 369 192 29 369 minecraft:lime_terracotta
fill 192 28 411 193 33 411 minecraft:green_concrete
fill 198 28 369 198 33 369 minecraft:green_concrete
fill 198 28 411 199 29 411 minecraft:lime_terracotta
fill 199 28 369 200 28 369 minecraft:lime_terracotta
fill 200 28 411 201 33 411 minecraft:green_concrete
fill 201 28 369 201 33 369 minecraft:green_concrete
setblock 202 28 411 minecraft:lime_terracotta
fill 203 28 369 203 29 369 minecraft:lime_terracotta
fill 209 28 369 210 33 369 minecraft:green_concrete
fill 210 28 411 211 29 411 minecraft:lime_terracotta
fill 211 28 369 212 29 369 minecraft:lime_terracotta
fill 212 28 411 213 33 411 minecraft:green_concrete
fill 219 28 411 219 29 411 minecraft:lime_terracotta
setblock 220 28 369 minecraft:lime_terracotta
fill 221 28 369 222 33 369 minecraft:green_concrete
fill 221 28 411 221 33 411 minecraft:green_concrete
fill 222 28 411 223 28 411 minecraft:lime_terracotta
fill 223 28 369 224 29 369 minecraft:lime_terracotta
fill 224 28 411 224 33 411 minecraft:green_concrete
fill 229 28 369 230 33 369 minecraft:green_concrete
fill 230 28 370 230 28 371 minecraft:lime_terracotta
fill 230 28 372 230 33 372 minecraft:green_concrete
fill 230 28 380 230 33 381 minecraft:green_concrete
fill 230 28 382 230 29 383 minecraft:lime_terracotta
fill 230 28 389 230 33 389 minecraft:green_concrete
setblock 230 28 391 minecraft:lime_terracotta
fill 230 28 392 230 33 393 minecraft:green_concrete
fill 230 28 394 230 29 394 minecraft:lime_terracotta
fill 230 28 400 230 33 401 minecraft:green_concrete
fill 230 28 402 230 28 403 minecraft:lime_terracotta
fill 230 28 411 230 29 411 minecraft:lime_terracotta
fill 188 29 373 188 31 373 minecraft:green_concrete
setblock 188 29 378 minecraft:lime_terracotta
setblock 188 29 389 minecraft:lime_terracotta
fill 188 29 393 188 32 393 minecraft:green_concrete
fill 188 29 409 188 29 410 minecraft:lime_terracotta
setblock 190 29 411 minecraft:lime_terracotta
fill 191 29 411 191 32 411 minecraft:green_concrete
fill 199 29 369 200 32 369 minecraft:green_concrete
fill 202 29 411 202 32 411 minecraft:green_concrete
setblock 204 29 369 minecraft:lime_terracotta
setblock 207 29 411 minecraft:lime_terracotta
setblock 215 29 369 minecraft:lime_terracotta
setblock 218 29 411 minecraft:lime_terracotta
fill 220 29 369 220 32 369 minecraft:green_concrete
fill 222 29 411 223 32 411 minecraft:green_concrete
fill 230 29 370 230 32 370 minecraft:green_concrete
setblock 230 29 371 minecraft:lime_terracotta
fill 230 29 374 230 29 375 minecraft:lime_terracotta
fill 230 29 391 230 32 391 minecraft:green_concrete
setblock 230 29 395 minecraft:lime_terracotta
fill 230 29 402 230 32 402 minecraft:green_concrete
setblock 230 29 403 minecraft:lime_terracotta
setblock 230 29 406 minecraft:lime_terracotta
fill 188 30 369 188 35 370 minecraft:green_concrete
setblock 188 30 375 minecraft:green_concrete
fill 188 30 376 188 31 376 minecraft:lime_terracotta
fill 188 30 378 188 35 378 minecraft:green_concrete
fill 188 30 379 188 30 380 minecraft:lime_terracotta
fill 188 30 381 188 32 382 minecraft:green_concrete
fill 188 30 387 188 31 388 minecraft:lime_terracotta
fill 188 30 389 188 35 390 minecraft:green_concrete
fill 188 30 399 188 30 400 minecraft:lime_terracotta
fill 188 30 401 188 35 402 minecraft:green_concrete
fill 188 30 408 188 31 408 minecraft:lime_terracotta
fill 188 30 409 188 35 410 minecraft:green_concrete
setblock 188 30 411 minecraft:lime_terracotta
fill 189 30 370 191 30 370 minecraft:mud
fill 189 30 372 189 30 374 minecraft:mud
fill 189 30 376 189 30 378 minecraft:mud
fill 189 30 380 189 30 382 minecraft:mud
fill 189 30 384 189 30 386 minecraft:mud
fill 189 30 388 189 30 390 minecraft:mud
fill 189 30 392 189 30 394 minecraft:mud
fill 189 30 396 189 30 398 minecraft:mud
fill 189 30 400 189 30 402 minecraft:mud
fill 189 30 404 189 30 406 minecraft:mud
fill 189 30 408 189 30 410 minecraft:mud
fill 190 30 411 190 35 411 minecraft:green_concrete
fill 191 30 369 192 35 369 minecraft:green_concrete
fill 191 30 410 193 30 410 minecraft:mud
fill 193 30 369 194 31 369 minecraft:lime_terracotta
fill 193 30 370 195 30 370 minecraft:mud
fill 195 30 410 197 30 410 minecraft:mud
fill 196 30 411 197 31 411 minecraft:lime_terracotta
fill 197 30 370 199 30 370 minecraft:mud
fill 198 30 411 199 35 411 minecraft:green_concrete
fill 199 30 410 201 30 410 minecraft:mud
fill 201 30 370 203 30 370 minecraft:mud
setblock 202 30 369 minecraft:lime_terracotta
fill 203 30 369 204 35 369 minecraft:green_concrete
fill 203 30 410 205 30 410 minecraft:mud
fill 205 30 369 206 31 369 minecraft:lime_terracotta
fill 205 30 370 207 30 370 minecraft:mud
fill 207 30 410 209 30 410 minecraft:mud
fill 207 30 411 207 35 411 minecraft:green_concrete
fill 208 30 411 209 30 411 minecraft:lime_terracotta
fill 209 30 370 211 30 370 minecraft:mud
fill 210 30 411 211 35 411 minecraft:green_concrete
fill 211 30 369 212 35 369 minecraft:green_concrete
fill 211 30 410 213 30 410 minecraft:mud
fill 213 30 369 214 30 369 minecraft:lime_terracotta
fill 213 30 370 215 30 370 minecraft:mud
fill 215 30 369 215 35 369 minecraft:green_concrete
fill 215 30 410 217 30 410 minecraft:mud
fill 216 30 411 217 31 411 minecraft:lime_terracotta
fill 217 30 370 219 30 370 minecraft:mud
fill 218 30 411 219 35 411 minecraft:green_concrete
fill 219 30 410 221 30 410 minecraft:mud
setblock 220 30 411 minecraft:lime_terracotta
fill 221 30 370 223 30 370 minecraft:mud
fill 223 30 369 224 35 369 minecraft:green_concrete
fill 223 30 410 225 30 410 minecraft:mud
fill 225 30 369 226 31 369 minecraft:lime_terracotta
fill 225 30 370 227 30 370 minecraft:mud
fill 227 30 410 229 30 410 minecraft:mud
fill 228 30 411 229 31 411 minecraft:lime_terracotta
fill 229 30 370 229 30 372 minecraft:mud
fill 229 30 374 229 30 376 minecraft:mud
fill 229 30 378 229 30 380 minecraft:mud
fill 229 30 382 229 30 384 minecraft:mud
fill 229 30 386 229 30 388 minecraft:mud
fill 229 30 390 229 30 392 minecraft:mud
fill 229 30 394 229 30 396 minecraft:mud
fill 229 30 398 229 30 400 minecraft:mud
fill 229 30 402 229 30 404 minecraft:mud
fill 229 30 406 229 30 408 minecraft:mud
fill 230 30 371 230 35 371 minecraft:green_concrete
setblock 230 30 373 minecraft:lime_terracotta
fill 230 30 374 230 35 375 minecraft:green_concrete
fill 230 30 376 230 31 376 minecraft:lime_terracotta
fill 230 30 382 230 35 383 minecraft:green_concrete
fill 230 30 384 230 30 385 minecraft:lime_terracotta
fill 230 30 394 230 35 395 minecraft:green_concrete
fill 230 30 396 230 31 397 minecraft:lime_terracotta
fill 230 30 403 230 35 403 minecraft:green_concrete
fill 230 30 404 230 30 405 minecraft:lime_terracotta
fill 230 30 406 230 35 406 minecraft:green_concrete
fill 230 30 408 230 31 408 minecraft:lime_terracotta
fill 230 30 411 230 35 411 minecraft:green_concrete
setblock 188 31 375 minecraft:lime_terracotta
setblock 188 31 379 minecraft:lime_terracotta
fill 188 31 380 188 34 380 minecraft:green_concrete
setblock 188 31 396 minecraft:lime_terracotta
setblock 188 31 399 minecraft:lime_terracotta
fill 188 31 400 188 34 400 minecraft:green_concrete
setblock 188 31 407 minecraft:lime_terracotta
fill 188 31 411 188 34 411 minecraft:green_concrete
setblock 191 31 372 minecraft:light[level=14]
setblock 191 31 380 minecraft:light[level=14]
setblock 191 31 388 minecraft:light[level=14]
setblock 191 31 396 minecraft:light[level=14]
setblock 191 31 404 minecraft:light[level=14]
setblock 197 31 369 minecraft:lime_terracotta
setblock 199 31 380 minecraft:light[level=14]
setblock 199 31 388 minecraft:light[level=14]
setblock 199 31 396 minecraft:light[level=14]
setblock 199 31 404 minecraft:light[level=14]
fill 202 31 369 202 34 369 minecraft:green_concrete
fill 204 31 411 205 31 411 minecraft:lime_terracotta
setblock 207 31 372 minecraft:light[level=14]
setblock 207 31 380 minecraft:light[level=14]
setblock 207 31 388 minecraft:light[level=14]
setblock 207 31 396 minecraft:light[level=14]
setblock 207 31 404 minecraft:light[level=14]
setblock 208 31 411 minecraft:lime_terracotta
fill 209 31 411 209 34 411 minecraft:green_concrete
fill 213 31 369 213 34 369 minecraft:green_concrete
setblock 214 31 369 minecraft:lime_terracotta
setblock 215 31 372 minecraft:light[level=14]
setblock 215 31 380 minecraft:light[level=14]
setblock 215 31 388 minecraft:light[level=14]
setblock 215 31 396 minecraft:light[level=14]
setblock 215 31 404 minecraft:light[level=14]
fill 217 31 369 218 31 369 minecraft:lime_terracotta
fill 220 31 411 220 34 411 minecraft:green_concrete
setblock 223 31 372 minecraft:light[level=14]
setblock 223 31 380 minecraft:light[level=14]
setblock 223 31 388 minecraft:light[level=14]
setblock 223 31 396 minecraft:light[level=14]
setblock 223 31 404 minecraft:light[level=14]
setblock 225 31 411 minecraft:lime_terracotta
fill 230 31 373 230 34 373 minecraft:green_concrete
setblock 230 31 377 minecraft:lime_terracotta
fill 230 31 384 230 34 384 minecraft:green_concrete
setblock 230 31 385 minecraft:lime_terracotta
setblock 230 31 388 minecraft:lime_terracotta
fill 230 31 404 230 34 405 minecraft:green_concrete
setblock 230 31 409 minecraft:lime_terracotta
fill 188 32 373 188 33 374 minecraft:lime_terracotta
fill 188 32 375 188 37 376 minecraft:green_concrete
setblock 188 32 377 minecraft:lime_terracotta
fill 188 32 379 188 34 379 minecraft:green_concrete
fill 188 32 385 188 33 386 minecraft:lime_terracotta
fill 188 32 387 188 37 388 minecraft:green_concrete
fill 188 32 394 188 33 394 minecraft:lime_terracotta
fill 188 32 396 188 37 396 minecraft:green_concrete
fill 188 32 397 188 32 398 minecraft:lime_terracotta
fill 188 32 399 188 37 399 minecraft:green_concrete
fill 188 32 405 188 33 406 minecraft:lime_terracotta
fill 188 32 407 188 37 408 minecraft:green_concrete
fill 193 32 369 194 34 369 minecraft:green_concrete
fill 194 32 411 195 32 411 minecraft:lime_terracotta
fill 195 32 369 196 32 369 minecraft:lime_terracotta
fill 196 32 411 197 37 411 minecraft:green_concrete
fill 197 32 369 197 37 369 minecraft:green_concrete
fill 203 32 411 203 33 411 minecraft:lime_terracotta
fill 204 32 411 205 37 411 minecraft:green_concrete
fill 205 32 369 206 37 369 minecraft:green_concrete
setblock 206 32 411 minecraft:lime_terracotta
fill 207 32 369 208 33 369 minecraft:lime_terracotta
fill 208 32 411 208 37 411 minecraft:green_concrete
fill 214 32 369 214 37 369 minecraft:green_concrete
fill 214 32 411 215 33 411 minecraft:lime_terracotta
setblock 216 32 369 minecraft:lime_terracotta
fill 216 32 411 217 37 411 minecraft:green_concrete
fill 217 32 369 218 37 369 minecraft:green_concrete
fill 219 32 369 219 33 369 minecraft:lime_terracotta
fill 225 32 369 226 37 369 minecraft:green_concrete
fill 225 32 411 225 37 411 minecraft:green_concrete
fill 226 32 411 227 32 411 minecraft:lime_terracotta
fill 227 32 369 228 32 369 minecraft:lime_terracotta
fill 228 32 411 229 37 411 minecraft:green_concrete
fill 230 32 376 230 37 377 minecraft:green_concrete
fill 230 32 378 230 33 379 minecraft:lime_terracotta
fill 230 32 385 230 37 385 minecraft:green_concrete
fill 230 32 386 230 32 387 minecraft:lime_terracotta
fill 230 32 388 230 37 388 minecraft:green_concrete
fill 230 32 390 230 33 390 minecraft:lime_terracotta
fill 230 32 396 230 37 397 minecraft:green_concrete
fill 230 32 398 230 33 399 minecraft:lime_terracotta
setblock 230 32 407 minecraft:lime_terracotta
fill 230 32 408 230 37 409 minecraft:green_concrete
fill 230 32 410 230 33 410 minecraft:lime_terracotta
fill 188 33 377 188 36 377 minecraft:green_concrete
fill 188 33 381 188 35 381 minecraft:green_concrete
setblock 188 33 382 minecraft:lime_terracotta
setblock 188 33 393 minecraft:lime_terracotta
fill 188 33 397 188 36 398 minecraft:green_concrete
setblock 191 33 411 minecraft:lime_terracotta
setblock 194 33 411 minecraft:lime_terracotta
fill 195 33 369 195 36 369 minecraft:green_concrete
fill 195 33 411 195 36 411 minecraft:green_concrete
setblock 196 33 369 minecraft:lime_terracotta
fill 199 33 369 200 33 369 minecraft:lime_terracotta
setblock 202 33 411 minecraft:lime_terracotta
fill 206 33 411 206 36 411 minecraft:green_concrete
fill 216 33 369 216 36 369 minecraft:green_concrete
setblock 220 33 369 minecraft:lime_terracotta
fill 222 33 411 223 33 411 minecraft:lime_terracotta
setblock 226 33 411 minecraft:lime_terracotta
fill 227 33 369 227 36 369 minecraft:green_concrete
fill 227 33 411 227 36 411 minecraft:green_concrete
setblock 228 33 369 minecraft:lime_terracotta
setblock 230 33 370 minecraft:lime_terracotta
fill 230 33 386 230 36 387 minecraft:green_concrete
setblock 230 33 391 minecraft:lime_terracotta
setblock 230 33 402 minecraft:lime_terracotta
fill 230 33 407 230 36 407 minecraft:green_concrete
fill 188 34 371 188 35 372 minecraft:lime_terracotta
fill 188 34 373 188 39 374 minecraft:green_concrete
fill 188 34 382 188 39 382 minecraft:green_concrete
fill 188 34 383 188 34 384 minecraft:lime_terracotta
fill 188 34 385 188 39 386 minecraft:green_concrete
fill 188 34 391 188 35 392 minecraft:lime_terracotta
fill 188 34 393 188 39 394 minecraft:green_concrete
setblock 188 34 395 minecraft:lime_terracotta
fill 188 34 403 188 35 404 minecraft:lime_terracotta
fill 188 34 405 188 39 406 minecraft:green_concrete
fill 189 34 369 190 35 369 minecraft:lime_terracotta
fill 189 34 411 189 35 411 minecraft:lime_terracotta
fill 191 34 411 191 39 411 minecraft:green_concrete
fill 192 34 411 193 34 411 minecraft:lime_terracotta
fill 194 34 411 194 39 411 minecraft:green_concrete
fill 196 34 369 196 36 369 minecraft:green_concrete
setblock 198 34 369 minecraft:lime_terracotta
fill 199 34 369 200 39 369 minecraft:green_concrete
fill 200 34 411 201 35 411 minecraft:lime_terracotta
fill 201 34 369 201 35 369 minecraft:lime_terracotta
fill 202 34 411 203 39 411 minecraft:green_concrete
fill 207 34 369 208 39 369 minecraft:green_concrete
fill 209 34 369 210 34 369 minecraft:lime_terracotta
fill 212 34 411 213 34 411 minecraft:lime_terracotta
fill 214 34 411 215 39 411 minecraft:green_concrete
fill 219 34 369 220 39 369 minecraft:green_concrete
fill 221 34 369 222 35 369 minecraft:lime_terracotta
fill 221 34 411 221 35 411 minecraft:lime_terracotta
fill 222 34 411 223 39 411 minecraft:green_concrete
setblock 224 34 411 minecraft:lime_terracotta
fill 226 34 411 226 39 411 minecraft:green_concrete
fill 228 34 369 228 39 369 minecraft:green_concrete
fill 229 34 369 230 34 369 minecraft:lime_terracotta
fill 230 34 370 230 39 370 minecraft:green_concrete
fill 230 34 372 230 35 372 minecraft:lime_terracotta
fill 230 34 378 230 39 379 minecraft:green_concrete
fill 230 34 380 230 35 381 minecraft:lime_terracotta
setblock 230 34 389 minecraft:lime_terracotta
fill 230 34 390 230 39 391 minecraft:green_concrete
fill 230 34 392 230 35 393 minecraft:lime_terracotta
fill 230 34 398 230 39 399 minecraft:green_concrete
fill 230 34 400 230 34 401 minecraft:lime_terracotta
fill 230 34 402 230 39 402 minecraft:green_concrete
fill 230 34 410 230 39 410 minecraft:green_concrete
fill 188 35 379 188 35 380 minecraft:lime_terracotta
setblock 188 35 383 minecraft:lime_terracotta
fill 188 35 384 188 38 384 minecraft:green_concrete
fill 188 35 395 188 38 395 minecraft:green_concrete
setblock 188 35 400 minecraft:lime_terracotta
setblock 188 35 411 minecraft:lime_terracotta
fill 192 35 411 193 38 411 minecraft:green_concrete
setblock 193 35 369 minecraft:lime_terracotta
fill 194 35 369 194 37 369 minecraft:green_concrete
fill 198 35 369 198 38 369 minecraft:green_concrete
setblock 202 35 369 minecraft:lime_terracotta
fill 208 35 404 208 49 404 minecraft:iron_block
fill 209 35 369 209 38 369 minecraft:green_concrete
setblock 209 35 411 minecraft:lime_terracotta
setblock 210 35 369 minecraft:lime_terracotta
setblock 212 35 411 minecraft:lime_terracotta
setblock 213 35 369 minecraft:lime_terracotta
fill 213 35 411 213 38 411 minecraft:green_concrete
setblock 220 35 411 minecraft:lime_terracotta
fill 224 35 411 224 38 411 minecraft:green_concrete
fill 229 35 369 230 38 369 minecraft:green_concrete
setblock 230 35 373 minecraft:lime_terracotta
setblock 230 35 384 minecraft:lime_terracotta
fill 230 35 389 230 38 389 minecraft:green_concrete
fill 230 35 400 230 38 400 minecraft:green_concrete
setblock 230 35 401 minecraft:lime_terracotta
fill 230 35 404 230 35 405 minecraft:lime_terracotta
fill 188 36 369 188 37 370 minecraft:lime_terracotta
fill 188 36 371 188 41 372 minecraft:green_concrete
fill 188 36 378 188 37 378 minecraft:lime_terracotta
fill 188 36 379 188 41 380 minecraft:green_concrete
setblock 188 36 381 minecraft:lime_terracotta
fill 188 36 383 188 41 383 minecraft:green_concrete
fill 188 36 389 188 37 390 minecraft:lime_terracotta
fill 188 36 391 188 41 392 minecraft:green_concrete
fill 188 36 400 188 41 400 minecraft:green_concrete
fill 188 36 401 188 36 402 minecraft:lime_terracotta
fill 188 36 403 188 41 404 minecraft:green_concrete
fill 188 36 409 188 37 410 minecraft:lime_terracotta
fill 188 36 411 189 41 411 minecraft:green_concrete
fill 189 36 369 190 41 369 minecraft:green_concrete
fill 189 36 370 191 36 370 minecraft:mud
fill 189 36 372 189 36 374 minecraft:mud
fill 189 36 376 189 36 378 minecraft:mud
fill 189 36 380 189 36 382 minecraft:mud
fill 189 36 384 189 36 386 minecraft:mud
fill 189 36 388 189 36 390 minecraft:mud
fill 189 36 392 189 36 394 minecraft:mud
fill 189 36 396 189 36 398 minecraft:mud
fill 189 36 400 189 36 402 minecraft:mud
fill 189 36 404 189 36 406 minecraft:mud
fill 189 36 408 189 36 410 minecraft:mud
setblock 190 36 411 minecraft:lime_terracotta
fill 191 36 369 192 36 369 minecraft:lime_terracotta
fill 191 36 410 193 36 410 minecraft:mud
fill 193 36 369 193 37 369 minecraft:green_concrete
fill 193 36 370 195 36 370 minecraft:mud
fill 195 36 410 197 36 410 minecraft:mud
fill 197 36 370 199 36 370 minecraft:mud
fill 198 36 411 199 37 411 minecraft:lime_terracotta
fill 199 36 410 201 36 410 minecraft:mud
fill 200 36 411 201 41 411 minecraft:green_concrete
fill 201 36 369 202 41 369 minecraft:green_concrete
fill 201 36 370 203 36 370 minecraft:mud
fill 203 36 369 204 37 369 minecraft:lime_terracotta
fill 203 36 410 205 36 410 minecraft:mud
fill 205 36 370 207 36 370 minecraft:mud
fill 207 36 410 209 36 410 minecraft:mud
fill 207 36 411 207 37 411 minecraft:lime_terracotta
fill 209 36 370 211 36 370 minecraft:mud
fill 209 36 411 209 41 411 minecraft:green_concrete
fill 210 36 369 210 41 369 minecraft:green_concrete
fill 210 36 411 211 36 411 minecraft:lime_terracotta
fill 211 36 369 212 36 369 minecraft:lime_terracotta
fill 211 36 410 213 36 410 minecraft:mud
fill 212 36 411 212 41 411 minecraft:green_concrete
fill 213 36 369 213 41 369 minecraft:green_concrete
fill 213 36 370 215 36 370 minecraft:mud
fill 215 36 369 215 37 369 minecraft:lime_terracotta
fill 215 36 410 217 36 410 minecraft:mud
fill 217 36 370 219 36 370 minecraft:mud
fill 218 36 411 219 37 411 minecraft:lime_terracotta
fill 219 36 410 221 36 410 minecraft:mud
fill 220 36 411 221 41 411 minecraft:green_concrete
fill 221 36 369 222 41 369 minecraft:green_concrete
fill 221 36 370 223 36 370 minecraft:mud
fill 223 36 369 224 37 369 minecraft:lime_terracotta
fill 223 36 410 225 36 410 minecraft:mud
fill 225 36 370 227 36 370 minecraft:mud
fill 227 36 410 229 36 410 minecraft:mud
fill 229 36 370 229 36 372 minecraft:mud
fill 229 36 374 229 36 376 minecraft:mud
fill 229 36 378 229 36 380 minecraft:mud
fill 229 36 382 229 36 384 minecraft:mud
fill 229 36 386 229 36 388 minecraft:mud
fill 229 36 390 229 36 392 minecraft:mud
fill 229 36 394 229 36 396 minecraft:mud
fill 229 36 398 229 36 400 minecraft:mud
fill 229 36 402 229 36 404 minecraft:mud
fill 229 36 406 229 36 408 minecraft:mud
setblock 230 36 371 minecraft:lime_terracotta
fill 230 36 372 230 41 373 minecraft:green_concrete
fill 230 36 374 230 37 375 minecraft:lime_terracotta
fill 230 36 380 230 41 381 minecraft:green_concrete
fill 230 36 382 230 36 383 minecraft:lime_terracotta
fill 230 36 384 230 41 384 minecraft:green_concrete
fill 230 36 392 230 41 393 minecraft:green_concrete
fill 230 36 394 230 37 395 minecraft:lime_terracotta
fill 230 36 401 230 41 401 minecraft:green_concrete
setblock 230 36 403 minecraft:lime_terracotta
fill 230 36 404 230 41 405 minecraft:green_concrete
fill 230 36 406 230 37 406 minecraft:lime_terracotta
fill 230 36 411 230 37 411 minecraft:lime_terracotta
setblock 188 37 377 minecraft:lime_terracotta
fill 188 37 381 188 40 381 minecraft:green_concrete
fill 188 37 397 188 37 398 minecraft:lime_terracotta
setblock 188 37 401 minecraft:lime_terracotta
fill 188 37 402 188 40 402 minecraft:green_concrete
fill 190 37 411 190 40 411 minecraft:green_concrete
fill 191 37 369 191 40 369 minecraft:green_concrete
setblock 192 37 369 minecraft:lime_terracotta
fill 195 37 369 196 37 369 minecraft:lime_terracotta
setblock 195 37 411 minecraft:lime_terracotta
setblock 206 37 411 minecraft:lime_terracotta
fill 210 37 411 211 40 411 minecraft:green_concrete
fill 211 37 369 212 40 369 minecraft:green_concrete
setblock 216 37 369 minecraft:lime_terracotta
setblock 227 37 369 minecraft:lime_terracotta
setblock 227 37 411 minecraft:lime_terracotta
fill 230 37 371 230 40 371 minecraft:green_concrete
fill 230 37 382 230 40 382 minecraft:green_concrete
setblock 230 37 383 minecraft:lime_terracotta
fill 230 37 386 230 37 387 minecraft:lime_terracotta
fill 230 37 403 230 40 403 minecraft:green_concrete
setblock 230 37 407 minecraft:lime_terracotta
fill 188 38 369 188 40 370 minecraft:green_concrete
fill 188 38 375 188 39 376 minecraft:lime_terracotta
fill 188 38 377 188 43 378 minecraft:green_concrete
fill 188 38 387 188 38 388 minecraft:lime_terracotta
fill 188 38 389 188 43 390 minecraft:green_concrete
fill 188 38 396 188 39 396 minecraft:lime_terracotta
fill 188 38 397 188 43 398 minecraft:green_concrete
setblock 188 38 399 minecraft:lime_terracotta
fill 188 38 401 188 43 401 minecraft:green_concrete
fill 188 38 407 188 39 408 minecraft:lime_terracotta
fill 188 38 409 188 43 410 minecraft:green_concrete
fill 192 38 369 192 43 369 minecraft:green_concrete
fill 193 38 369 194 38 369 minecraft:lime_terracotta
fill 195 38 369 196 39 369 minecraft:green_concrete
fill 195 38 411 195 43 411 minecraft:green_concrete
fill 196 38 411 197 38 411 minecraft:lime_terracotta
fill 197 38 369 197 39 369 minecraft:lime_terracotta
fill 198 38 411 199 43 411 minecraft:green_concrete
fill 203 38 369 204 43 369 minecraft:green_concrete
fill 204 38 411 205 39 411 minecraft:lime_terracotta
fill 205 38 369 206 39 369 minecraft:lime_terracotta
fill 206 38 411 207 43 411 minecraft:green_concrete
setblock 208 38 411 minecraft:lime_terracotta
setblock 214 38 369 minecraft:lime_terracotta
fill 215 38 369 216 43 369 minecraft:green_concrete
fill 216 38 411 217 39 411 minecraft:lime_terracotta
fill 217 38 369 218 39 369 minecraft:lime_terracotta
fill 218 38 411 219 43 411 minecraft:green_concrete
fill 223 38 369 224 43 369 minecraft:green_concrete
fill 225 38 369 226 38 369 minecraft:lime_terracotta
fill 225 38 411 225 39 411 minecraft:lime_terracotta
fill 227 38 369 227 43 369 minecraft:green_concrete
fill 227 38 411 227 43 411 minecraft:green_concrete
fill 228 38 411 229 38 411 minecraft:lime_terracotta
fill 230 38 374 230 43 375 minecraft:green_concrete
fill 230 38 376 230 39 377 minecraft:lime_terracotta
fill 230 38 383 230 43 383 minecraft:green_concrete
setblock 230 38 385 minecraft:lime_terracotta
fill 230 38 386 230 43 387 minecraft:green_concrete
fill 230 38 388 230 39 388 minecraft:lime_terracotta
fill 230 38 394 230 43 395 minecraft:green_concrete
fill 230 38 396 230 38 397 minecraft:lime_terracotta
fill 230 38 406 230 43 407 minecraft:green_concrete
fill 230 38 408 230 39 409 minecraft:lime_terracotta
fill 230 38 411 230 43 411 minecraft:green_concrete
setblock 188 39 384 minecraft:lime_terracotta
setblock 188 39 387 minecraft:lime_terracotta
fill 188 39 388 188 42 388 minecraft:green_concrete
setblock 188 39 395 minecraft:lime_terracotta
fill 188 39 399 188 42 399 minecraft:green_concrete
setblock 191 39 372 minecraft:light[level=14]
setblock 191 39 380 minecraft:light[level=14]
setblock 191 39 388 minecraft:light[level=14]
setblock 191 39 396 minecraft:light[level=14]
setblock 191 39 404 minecraft:light[level=14]
fill 192 39 411 193 39 411 minecraft:lime_terracotta
fill 193 39 369 194 41 369 minecraft:green_concrete
setblock 196 39 411 minecraft:lime_terracotta
fill 197 39 411 197 42 411 minecraft:green_concrete
setblock 198 39 369 minecraft:lime_terracotta
setblock 199 39 380 minecraft:light[level=14]
setblock 199 39 388 minecraft:light[level=14]
setblock 199 39 396 minecraft:light[level=14]
setblock 199 39 404 minecraft:light[level=14]
setblock 207 39 372 minecraft:light[level=14]
setblock 207 39 380 minecraft:light[level=14]
setblock 207 39 388 minecraft:light[level=14]
setblock 207 39 396 minecraft:light[level=14]
setblock 207 39 404 minecraft:light[level=14]
fill 208 39 411 208 42 411 minecraft:green_concrete
setblock 209 39 369 minecraft:lime_terracotta
setblock 213 39 411 minecraft:lime_terracotta
fill 214 39 369 214 42 369 minecraft:green_concrete
setblock 215 39 372 minecraft:light[level=14]
setblock 215 39 380 minecraft:light[level=14]
setblock 215 39 388 minecraft:light[level=14]
setblock 215 39 396 minecraft:light[level=14]
setblock 215 39 404 minecraft:light[level=14]
setblock 223 39 372 minecraft:light[level=14]
setblock 223 39 380 minecraft:light[level=14]
setblock 223 39 388 minecraft:light[level=14]
setblock 223 39 396 minecraft:light[level=14]
setblock 223 39 404 minecraft:light[level=14]
setblock 224 39 411 minecraft:lime_terracotta
fill 225 39 369 225 42 369 minecraft:green_concrete
setblock 226 39 369 minecraft:lime_terracotta
fill 228 39 411 229 42 411 minecraft:green_concrete
fill 229 39 369 230 39 369 minecraft:lime_terracotta
fill 230 39 385 230 42 385 minecraft:green_concrete
setblock 230 39 389 minecraft:lime_terracotta
fill 230 39 396 230 42 396 minecraft:green_concrete
setblock 230 39 397 minecraft:lime_terracotta
setblock 230 39 400 minecraft:lime_terracotta
fill 188 40 373 188 41 374 minecraft:lime_terracotta
fill 188 40 375 188 45 376 minecraft:green_concrete
fill 188 40 382 188 41 382 minecraft:lime_terracotta
fill 188 40 384 188 45 384 minecraft:green_concrete
fill 188 40 385 188 40 386 minecraft:lime_terracotta
fill 188 40 387 188 45 387 minecraft:green_concrete
fill 188 40 393 188 41 394 minecraft:lime_terracotta
fill 188 40 395 188 45 396 minecraft:green_concrete
fill 188 40 405 188 40 406 minecraft:lime_terracotta
fill 188 40 407 188 45 408 minecraft:green_concrete
fill 191 40 411 191 41 411 minecraft:lime_terracotta
fill 192 40 411 193 45 411 minecraft:green_concrete
setblock 194 40 411 minecraft:lime_terracotta
fill 195 40 369 195 43 369 minecraft:green_concrete
setblock 196 40 369 minecraft:lime_terracotta
fill 196 40 411 196 45 411 minecraft:green_concrete
fill 197 40 369 198 45 369 minecraft:green_concrete
fill 199 40 369 200 41 369 minecraft:lime_terracotta
fill 202 40 411 203 41 411 minecraft:lime_terracotta
fill 204 40 411 205 45 411 minecraft:green_concrete
fill 205 40 369 206 42 369 minecraft:green_concrete
fill 207 40 369 208 40 369 minecraft:lime_terracotta
fill 209 40 369 209 45 369 minecraft:green_concrete
fill 213 40 411 213 45 411 minecraft:green_concrete
fill 214 40 411 215 40 411 minecraft:lime_terracotta
fill 216 40 411 217 45 411 minecraft:green_concrete
fill 217 40 369 218 45 369 minecraft:green_concrete
fill 219 40 369 220 41 369 minecraft:lime_terracotta
fill 222 40 411 223 41 411 minecraft:lime_terracotta
fill 224 40 411 225 45 411 minecraft:green_concrete
fill 226 40 369 226 45 369 minecraft:green_concrete
setblock 226 40 411 minecraft:lime_terracotta
setblock 228 40 369 minecraft:lime_terracotta
fill 229 40 369 230 45 369 minecraft:green_concrete
fill 230 40 370 230 41 370 minecraft:lime_terracotta
fill 230 40 376 230 45 377 minecraft:green_concrete
fill 230 40 378 230 40 379 minecraft:lime_terracotta
fill 230 40 388 230 45 389 minecraft:green_concrete
fill 230 40 390 230 41 391 minecraft:lime_terracotta
fill 230 40 397 230 45 397 minecraft:green_concrete
fill 230 40 398 230 40 399 minecraft:lime_terracotta
fill 230 40 400 230 45 400 minecraft:green_concrete
fill 230 40 402 230 41 402 minecraft:lime_terracotta
fill 230 40 408 230 45 409 minecraft:green_concrete
fill 230 40 410 230 41 410 minecraft:lime_terracotta
fill 188 41 369 188 43 369 minecraft:green_concrete
setblock 188 41 370 minecraft:lime_terracotta
setblock 188 41 381 minecraft:lime_terracotta
fill 188 41 385 188 44 386 minecraft:green_concrete
setblock 188 41 402 minecraft:lime_terracotta
setblock 188 41 405 minecraft:lime_terracotta
fill 188 41 406 188 44 406 minecraft:green_concrete
setblock 190 41 411 minecraft:lime_terracotta
setblock 191 41 369 minecraft:lime_terracotta
fill 194 41 411 194 44 411 minecraft:green_concrete
fill 196 41 369 196 43 369 minecraft:green_concrete
fill 207 41 369 207 44 369 minecraft:green_concrete
setblock 208 41 369 minecraft:lime_terracotta
fill 210 41 411 211 41 411 minecraft:lime_terracotta
fill 211 41 369 212 41 369 minecraft:lime_terracotta
setblock 214 41 411 minecraft:lime_terracotta
fill 215 41 411 215 44 411 minecraft:green_concrete
fill 226 41 411 226 44 411 minecraft:green_concrete
fill 228 41 369 228 44 369 minecraft:green_concrete
setblock 230 41 371 minecraft:lime_terracotta
fill 230 41 378 230 44 378 minecraft:green_concrete
setblock 230 41 379 minecraft:lime_terracotta
setblock 230 41 382 minecraft:lime_terracotta
fill 230 41 398 230 44 399 minecraft:green_concrete
setblock 230 41 403 minecraft:lime_terracotta
fill 188 42 370 188 47 370 minecraft:green_concrete
fill 188 42 371 188 42 372 minecraft:lime_terracotta
fill 188 42 373 188 47 374 minecraft:green_concrete
fill 188 42 379 188 43 380 minecraft:lime_terracotta
fill 188 42 381 188 47 382 minecraft:green_concrete
setblock 188 42 383 minecraft:lime_terracotta
fill 188 42 391 188 43 392 minecraft:lime_terracotta
fill 188 42 393 188 47 394 minecraft:green_concrete
fill 188 42 400 188 43 400 minecraft:lime_terracotta
fill 188 42 402 188 47 402 minecraft:green_concrete
fill 188 42 403 188 42 404 minecraft:lime_terracotta
fill 188 42 405 188 47 405 minecraft:green_concrete
fill 188 42 411 189 43 411 minecraft:lime_terracotta
fill 189 42 369 190 42 369 minecraft:lime_terracotta
fill 189 42 370 191 42 370 minecraft:mud
fill 189 42 372 189 42 374 minecraft:mud
fill 189 42 376 189 42 378 minecraft:mud
fill 189 42 380 189 42 382 minecraft:mud
fill 189 42 384 189 42 386 minecraft:mud
fill 189 42 388 189 42 390 minecraft:mud
fill 189 42 392 189 42 394 minecraft:mud
fill 189 42 396 189 42 398 minecraft:mud
fill 189 42 400 189 42 402 minecraft:mud
fill 189 42 404 189 42 406 minecraft:mud
fill 189 42 408 189 42 410 minecraft:mud
fill 190 42 411 191 47 411 minecraft:green_concrete
fill 191 42 369 191 47 369 minecraft:green_concrete
fill 191 42 410 193 42 410 minecraft:mud
fill 193 42 369 193 43 369 minecraft:lime_terracotta
fill 193 42 370 195 42 370 minecraft:mud
setblock 194 42 369 minecraft:green_concrete
fill 195 42 410 197 42 410 minecraft:mud
fill 197 42 370 199 42 370 minecraft:mud
fill 199 42 369 200 47 369 minecraft:green_concrete
fill 199 42 410 201 42 410 minecraft:mud
fill 200 42 411 201 42 411 minecraft:lime_terracotta
fill 201 42 369 202 43 369 minecraft:lime_terracotta
fill 201 42 370 203 42 370 minecraft:mud
fill 202 42 411 203 47 411 minecraft:green_concrete
fill 203 42 410 205 42 410 minecraft:mud
fill 205 42 370 207 42 370 minecraft:mud
fill 207 42 410 209 42 410 minecraft:mud
fill 208 42 369 208 44 369 minecraft:green_concrete
fill 209 42 370 211 42 370 minecraft:mud
fill 209 42 411 209 43 411 minecraft:lime_terracotta
setblock 210 42 369 minecraft:lime_terracotta
fill 210 42 411 211 47 411 minecraft:green_concrete
fill 211 42 369 212 47 369 minecraft:green_concrete
fill 211 42 410 213 42 410 minecraft:mud
setblock 212 42 411 minecraft:lime_terracotta
fill 213 42 369 213 43 369 minecraft:lime_terracotta
fill 213 42 370 215 42 370 minecraft:mud
fill 214 42 411 214 47 411 minecraft:green_concrete
fill 215 42 410 217 42 410 minecraft:mud
fill 217 42 370 219 42 370 minecraft:mud
fill 219 42 369 220 47 369 minecraft:green_concrete
fill 219 42 410 221 42 410 minecraft:mud
fill 220 42 411 221 43 411 minecraft:lime_terracotta
fill 221 42 369 222 42 369 minecraft:lime_terracotta
fill 221 42 370 223 42 370 minecraft:mud
fill 222 42 411 223 47 411 minecraft:green_concrete
fill 223 42 410 225 42 410 minecraft:mud
fill 225 42 370 227 42 370 minecraft:mud
fill 227 42 410 229 42 410 minecraft:mud
fill 229 42 370 229 42 372 minecraft:mud
fill 229 42 374 229 42 376 minecraft:mud
fill 229 42 378 229 42 380 minecraft:mud
fill 229 42 382 229 42 384 minecraft:mud
fill 229 42 386 229 42 388 minecraft:mud
fill 229 42 390 229 42 392 minecraft:mud
fill 229 42 394 229 42 396 minecraft:mud
fill 229 42 398 229 42 400 minecraft:mud
fill 229 42 402 229 42 404 minecraft:mud
fill 229 42 406 229 42 408 minecraft:mud
fill 230 42 370 230 47 371 minecraft:green_concrete
fill 230 42 372 230 43 373 minecraft:lime_terracotta
fill 230 42 379 230 47 379 minecraft:green_concrete
fill 230 42 380 230 42 381 minecraft:lime_terracotta
fill 230 42 382 230 47 382 minecraft:green_concrete
fill 230 42 384 230 43 384 minecraft:lime_terracotta
fill 230 42 390 230 47 391 minecraft:green_concrete
fill 230 42 392 230 43 393 minecraft:lime_terracotta
setblock 230 42 401 minecraft:lime_terracotta
fill 230 42 402 230 47 403 minecraft:green_concrete
fill 230 42 404 230 43 405 minecraft:lime_terracotta
fill 230 42 410 230 47 410 minecraft:green_concrete
setblock 188 43 371 minecraft:lime_terracotta
fill 188 43 372 188 46 372 minecraft:green_concrete
fill 188 43 383 188 46 383 minecraft:green_concrete
setblock 188 43 388 minecraft:lime_terracotta
setblock 188 43 399 minecraft:lime_terracotta
fill 188 43 403 188 46 404 minecraft:green_concrete
fill 189 43 369 189 46 369 minecraft:green_concrete
setblock 190 43 369 minecraft:lime_terracotta
setblock 194 43 369 minecraft:lime_terracotta
setblock 197 43 411 minecraft:lime_terracotta
setblock 200 43 411 minecraft:lime_terracotta
fill 201 43 411 201 46 411 minecraft:green_concrete
setblock 205 43 369 minecraft:lime_terracotta
fill 206 43 369 206 45 369 minecraft:green_concrete
setblock 208 43 411 minecraft:lime_terracotta
fill 210 43 369 210 46 369 minecraft:green_concrete
fill 212 43 411 212 46 411 minecraft:green_concrete
setblock 214 43 369 minecraft:lime_terracotta
fill 221 43 369 221 46 369 minecraft:green_concrete
setblock 222 43 369 minecraft:lime_terracotta
setblock 225 43 369 minecraft:lime_terracotta
fill 228 43 411 229 43 411 minecraft:lime_terracotta
fill 230 43 380 230 46 381 minecraft:green_concrete
setblock 230 43 385 minecraft:lime_terracotta
setblock 230 43 396 minecraft:lime_terracotta
fill 230 43 401 230 46 401 minecraft:green_concrete
setblock 188 44 369 minecraft:lime_terracotta
fill 188 44 371 188 49 371 minecraft:green_concrete
fill 188 44 377 188 45 378 minecraft:lime_terracotta
fill 188 44 379 188 49 380 minecraft:green_concrete
fill 188 44 388 188 49 388 minecraft:green_concrete
fill 188 44 389 188 44 390 minecraft:lime_terracotta
fill 188 44 391 188 49 392 minecraft:green_concrete
fill 188 44 397 188 45 398 minecraft:lime_terracotta
fill 188 44 399 188 49 400 minecraft:green_concrete
setblock 188 44 401 minecraft:lime_terracotta
fill 188 44 409 188 45 410 minecraft:lime_terracotta
fill 188 44 411 189 49 411 minecraft:green_concrete
fill 190 44 369 190 46 369 minecraft:green_concrete
setblock 192 44 369 minecraft:lime_terracotta
fill 193 44 369 194 49 369 minecraft:green_concrete
fill 195 44 369 196 45 369 minecraft:lime_terracotta
fill 195 44 411 195 45 411 minecraft:lime_terracotta
fill 197 44 411 197 49 411 minecraft:green_concrete
fill 198 44 411 199 44 411 minecraft:lime_terracotta
fill 200 44 411 200 49 411 minecraft:green_concrete
fill 201 44 369 202 49 369 minecraft:green_concrete
fill 203 44 369 204 44 369 minecraft:lime_terracotta
fill 205 44 369 205 45 369 minecraft:green_concrete
fill 206 44 411 207 45 411 minecraft:lime_terracotta
fill 208 44 411 209 49 411 minecraft:green_concrete
fill 213 44 369 214 49 369 minecraft:green_concrete
fill 215 44 369 216 45 369 minecraft:lime_terracotta
fill 218 44 411 219 44 411 minecraft:lime_terracotta
fill 220 44 411 221 49 411 minecraft:green_concrete
fill 222 44 369 222 49 369 minecraft:green_concrete
fill 223 44 369 224 44 369 minecraft:lime_terracotta
fill 225 44 369 225 49 369 minecraft:green_concrete
fill 227 44 369 227 45 369 minecraft:lime_terracotta
fill 227 44 411 227 45 411 minecraft:lime_terracotta
fill 228 44 411 229 49 411 minecraft:green_concrete
fill 230 44 372 230 49 373 minecraft:green_concrete
fill 230 44 374 230 45 375 minecraft:lime_terracotta
setblock 230 44 383 minecraft:lime_terracotta
fill 230 44 384 230 49 385 minecraft:green_concrete
fill 230 44 386 230 45 387 minecraft:lime_terracotta
fill 230 44 392 230 49 393 minecraft:green_concrete
fill 230 44 394 230 44 395 minecraft:lime_terracotta
fill 230 44 396 230 49 396 minecraft:green_concrete
fill 230 44 404 230 49 405 minecraft:green_concrete
fill 230 44 406 230 45 407 minecraft:lime_terracotta
setblock 230 44 411 minecraft:lime_terracotta
fill 188 45 369 188 48 369 minecraft:green_concrete
fill 188 45 385 188 45 386 minecraft:lime_terracotta
setblock 188 45 389 minecraft:lime_terracotta
fill 188 45 390 188 48 390 minecraft:green_concrete
fill 188 45 401 188 48 401 minecraft:green_concrete
setblock 188 45 406 minecraft:lime_terracotta
fill 192 45 369 192 48 369 minecraft:green_concrete
setblock 194 45 411 minecraft:lime_terracotta
fill 198 45 411 199 48 411 minecraft:green_concrete
fill 203 45 369 203 48 369 minecraft:green_concrete
setblock 204 45 369 minecraft:lime_terracotta
fill 207 45 369 208 45 369 minecraft:lime_terracotta
setblock 215 45 411 minecraft:lime_terracotta
setblock 218 45 411 minecraft:lime_terracotta
fill 219 45 411 219 48 411 minecraft:green_concrete
fill 223 45 369 224 48 369 minecraft:green_concrete
setblock 226 45 411 minecraft:lime_terracotta
setblock 228 45 369 minecraft:lime_terracotta
setblock 230 45 378 minecraft:lime_terracotta
fill 230 45 383 230 48 383 minecraft:green_concrete
fill 230 45 394 230 48 394 minecraft:green_concrete
setblock 230 45 395 minecraft:lime_terracotta
fill 230 45 398 230 45 399 minecraft:lime_terracotta
fill 230 45 411 230 48 411 minecraft:green_concrete
fill 188 46 375 188 46 376 minecraft:lime_terracotta
fill 188 46 377 188 51 378 minecraft:green_concrete
fill 188 46 384 188 47 384 minecraft:lime_terracotta
fill 188 46 385 188 51 386 minecraft:green_concrete
setblock 188 46 387 minecraft:lime_terracotta
fill 188 46 389 188 51 389 minecraft:green_concrete
fill 188 46 395 188 47 396 minecraft:lime_terracotta
fill 188 46 397 188 51 398 minecraft:green_concrete
fill 188 46 406 188 51 406 minecraft:green_concrete
fill 188 46 407 188 46 408 minecraft:lime_terracotta
fill 188 46 409 188 51 410 minecraft:green_concrete
fill 192 46 411 193 47 411 minecraft:lime_terracotta
fill 194 46 411 195 51 411 minecraft:green_concrete
fill 195 46 369 196 51 369 minecraft:green_concrete
setblock 196 46 411 minecraft:lime_terracotta
fill 197 46 369 198 47 369 minecraft:lime_terracotta
fill 204 46 369 204 51 369 minecraft:green_concrete
fill 204 46 411 205 47 411 minecraft:lime_terracotta
fill 205 46 369 206 46 369 minecraft:lime_terracotta
fill 206 46 411 207 51 411 minecraft:green_concrete
fill 207 46 369 208 47 369 minecraft:green_concrete
fill 209 46 369 209 47 369 minecraft:lime_terracotta
fill 213 46 411 213 47 411 minecraft:lime_terracotta
fill 215 46 369 216 51 369 minecraft:green_concrete
fill 215 46 411 215 51 411 minecraft:green_concrete
fill 216 46 411 217 46 411 minecraft:lime_terracotta
fill 217 46 369 218 47 369 minecraft:lime_terracotta
fill 218 46 411 218 51 411 minecraft:green_concrete
fill 224 46 411 225 47 411 minecraft:lime_terracotta
setblock 226 46 369 minecraft:lime_terracotta
fill 226 46 411 227 51 411 minecraft:green_concrete
fill 227 46 369 228 51 369 minecraft:green_concrete
fill 229 46 369 230 47 369 minecraft:lime_terracotta
fill 230 46 374 230 51 375 minecraft:green_concrete
fill 230 46 376 230 46 377 minecraft:lime_terracotta
fill 230 46 378 230 51 378 minecraft:green_concrete
fill 230 46 386 230 51 387 minecraft:green_concrete
fill 230 46 388 230 47 389 minecraft:lime_terracotta
fill 230 46 395 230 51 395 minecraft:green_concrete
setblock 230 46 397 minecraft:lime_terracotta
fill 230 46 398 230 51 399 minecraft:green_concrete
fill 230 46 400 230 47 400 minecraft:lime_terracotta
fill 230 46 406 230 51 407 minecraft:green_concrete
fill 230 46 408 230 46 409 minecraft:lime_terracotta
setblock 188 47 372 minecraft:lime_terracotta
setblock 188 47 375 minecraft:lime_terracotta
fill 188 47 376 188 50 376 minecraft:green_concrete
setblock 188 47 383 minecraft:lime_terracotta
fill 188 47 387 188 50 387 minecraft:green_concrete
fill 188 47 403 188 47 404 minecraft:lime_terracotta
setblock 188 47 407 minecraft:lime_terracotta
fill 188 47 408 188 50 408 minecraft:green_concrete
fill 189 47 369 190 47 369 minecraft:lime_terracotta
setblock 191 47 372 minecraft:light[level=14]
setblock 191 47 380 minecraft:light[level=14]
setblock 191 47 388 minecraft:light[level=14]
setblock 191 47 396 minecraft:light[level=14]
setblock 191 47 404 minecraft:light[level=14]
fill 196 47 411 196 50 411 minecraft:green_concrete
setblock 199 47 380 minecraft:light[level=14]
setblock 199 47 388 minecraft:light[level=14]
setblock 199 47 396 minecraft:light[level=14]
setblock 199 47 404 minecraft:light[level=14]
setblock 201 47 411 minecraft:lime_terracotta
fill 205 47 369 206 49 369 minecraft:green_concrete
setblock 207 47 372 minecraft:light[level=14]
setblock 207 47 380 minecraft:light[level=14]
setblock 207 47 388 minecraft:light[level=14]
setblock 207 47 396 minecraft:light[level=14]
setblock 207 47 404 minecraft:light[level=14]
setblock 210 47 369 minecraft:lime_terracotta
setblock 212 47 411 minecraft:lime_terracotta
setblock 215 47 372 minecraft:light[level=14]
setblock 215 47 380 minecraft:light[level=14]
setblock 215 47 388 minecraft:light[level=14]
setblock 215 47 396 minecraft:light[level=14]
setblock 215 47 404 minecraft:light[level=14]
fill 216 47 411 217 50 411 minecraft:green_concrete
setblock 221 47 369 minecraft:lime_terracotta
setblock 223 47 372 minecraft:light[level=14]
setblock 223 47 380 minecraft:light[level=14]
setblock 223 47 388 minecraft:light[level=14]
setblock 223 47 396 minecraft:light[level=14]
setblock 223 47 404 minecraft:light[level=14]
fill 226 47 369 226 50 369 minecraft:green_concrete
fill 230 47 376 230 50 376 minecraft:green_concrete
setblock 230 47 377 minecraft:lime_terracotta
fill 230 47 380 230 47 381 minecraft:lime_terracotta
fill 230 47 397 230 50 397 minecraft:green_concrete
setblock 230 47 401 minecraft:lime_terracotta
fill 230 47 408 230 50 408 minecraft:green_concrete
setblock 230 47 409 minecraft:lime_terracotta
fill 188 48 370 188 49 370 minecraft:lime_terracotta
fill 188 48 372 188 69 372 minecraft:green_concrete
fill 188 48 373 188 48 374 minecraft:lime_terracotta
fill 188 48 375 188 65 375 minecraft:green_concrete
fill 188 48 381 188 49 382 minecraft:lime_terracotta
fill 188 48 383 188 66 384 minecraft:green_concrete
fill 188 48 393 188 48 394 minecraft:lime_terracotta
fill 188 48 395 188 65 396 minecraft:green_concrete
fill 188 48 402 188 49 402 minecraft:lime_terracotta
fill 188 48 403 188 69 404 minecraft:green_concrete
setblock 188 48 405 minecraft:lime_terracotta
fill 188 48 407 188 65 407 minecraft:green_concrete
fill 189 48 369 190 49 369 minecraft:green_concrete
fill 189 48 370 191 48 370 minecraft:mud
fill 189 48 372 189 48 374 minecraft:mud
fill 189 48 376 189 48 378 minecraft:mud
fill 189 48 380 189 48 382 minecraft:mud
fill 189 48 384 189 48 386 minecraft:mud
fill 189 48 388 189 48 390 minecraft:mud
fill 189 48 392 189 48 394 minecraft:mud
fill 189 48 396 189 48 398 minecraft:mud
fill 189 48 400 189 48 402 minecraft:mud
fill 189 48 404 189 48 406 minecraft:mud
fill 189 48 408 189 48 410 minecraft:mud
fill 190 48 411 191 49 411 minecraft:lime_terracotta
fill 191 48 369 191 49 369 minecraft:lime_terracotta
fill 191 48 410 193 48 410 minecraft:mud
fill 192 48 411 193 66 411 minecraft:green_concrete
fill 193 48 370 195 48 370 minecraft:mud
fill 195 48 410 197 48 410 minecraft:mud
fill 197 48 369 198 65 369 minecraft:green_concrete
fill 197 48 370 199 48 370 minecraft:mud
fill 199 48 369 200 49 369 minecraft:lime_terracotta
fill 199 48 410 201 48 410 minecraft:mud
fill 201 48 370 203 48 370 minecraft:mud
fill 201 48 411 201 69 411 minecraft:green_concrete
fill 202 48 411 203 48 411 minecraft:lime_terracotta
fill 203 48 410 205 48 410 minecraft:mud
fill 204 48 411 205 65 411 minecraft:green_concrete
fill 205 48 370 207 48 370 minecraft:mud
fill 207 48 369 207 51 369 minecraft:green_concrete
fill 207 48 410 209 48 410 minecraft:mud
setblock 208 48 369 minecraft:lime_terracotta
fill 209 48 369 210 66 369 minecraft:green_concrete
fill 209 48 370 211 48 370 minecraft:mud
fill 210 48 411 211 49 411 minecraft:lime_terracotta
fill 211 48 369 212 49 369 minecraft:lime_terracotta
fill 211 48 410 213 48 410 minecraft:mud
fill 212 48 411 213 66 411 minecraft:green_concrete
fill 213 48 370 215 48 370 minecraft:mud
setblock 214 48 411 minecraft:lime_terracotta
fill 215 48 410 217 48 410 minecraft:mud
fill 217 48 369 218 50 369 minecraft:green_concrete
fill 217 48 370 219 48 370 minecraft:mud
fill 219 48 369 220 48 369 minecraft:lime_terracotta
fill 219 48 410 221 48 410 minecraft:mud
fill 221 48 369 221 69 369 minecraft:green_concrete
fill 221 48 370 223 48 370 minecraft:mud
fill 222 48 411 223 49 411 minecraft:lime_terracotta
fill 223 48 410 225 48 410 minecraft:mud
fill 224 48 411 225 65 411 minecraft:green_concrete
fill 225 48 370 227 48 370 minecraft:mud
fill 227 48 410 229 48 410 minecraft:mud
fill 229 48 369 230 65 369 minecraft:green_concrete
fill 229 48 370 229 48 372 minecraft:mud
fill 229 48 374 229 48 376 minecraft:mud
fill 229 48 378 229 48 380 minecraft:mud
fill 229 48 382 229 48 384 minecraft:mud
fill 229 48 386 229 48 388 minecraft:mud
fill 229 48 390 229 48 392 minecraft:mud
fill 229 48 394 229 48 396 minecraft:mud
fill 229 48 398 229 48 400 minecraft:mud
fill 229 48 402 229 48 404 minecraft:mud
fill 229 48 406 229 48 408 minecraft:mud
fill 230 48 370 230 49 371 minecraft:lime_terracotta
fill 230 48 377 230 65 377 minecraft:green_concrete
setblock 230 48 379 minecraft:lime_terracotta
fill 230 48 380 230 66 381 minecraft:green_concrete
fill 230 48 382 230 49 382 minecraft:lime_terracotta
fill 230 48 388 230 65 389 minecraft:green_concrete
fill 230 48 390 230 48 391 minecraft:lime_terracotta
fill 230 48 400 230 66 401 minecraft:green_concrete
fill 230 48 402 230 49 403 minecraft:lime_terracotta
fill 230 48 409 230 65 409 minecraft:green_concrete
setblock 230 48 410 minecraft:lime_terracotta
setblock 188 49 369 minecraft:lime_terracotta
fill 188 49 373 188 52 374 minecraft:green_concrete
setblock 188 49 390 minecraft:lime_terracotta
setblock 188 49 393 minecraft:lime_terracotta
fill 188 49 394 188 52 394 minecraft:green_concrete
setblock 188 49 401 minecraft:lime_terracotta
fill 188 49 405 188 52 405 minecraft:green_concrete
setblock 192 49 369 minecraft:lime_terracotta
fill 198 49 411 199 49 411 minecraft:lime_terracotta
setblock 202 49 411 minecraft:lime_terracotta
setblock 203 49 369 minecraft:lime_terracotta
fill 203 49 411 203 52 411 minecraft:green_concrete
fill 208 49 369 208 51 369 minecraft:green_concrete
fill 214 49 411 214 52 411 minecraft:green_concrete
fill 219 49 369 219 52 369 minecraft:green_concrete
setblock 219 49 411 minecraft:lime_terracotta
setblock 220 49 369 minecraft:lime_terracotta
fill 223 49 369 224 49 369 minecraft:lime_terracotta
fill 230 49 379 230 52 379 minecraft:green_concrete
setblock 230 49 383 minecraft:lime_terracotta
fill 230 49 390 230 52 390 minecraft:green_concrete
setblock 230 49 391 minecraft:lime_terracotta
setblock 230 49 394 minecraft:lime_terracotta
fill 230 49 410 230 52 410 minecraft:green_concrete
setblock 230 49 411 minecraft:lime_terracotta
fill 188 50 369 188 63 370 minecraft:green_concrete
setblock 188 50 371 minecraft:lime_terracotta
fill 188 50 379 188 51 380 minecraft:lime_terracotta
fill 188 50 381 188 63 382 minecraft:green_concrete
fill 188 50 388 188 51 388 minecraft:lime_terracotta
fill 188 50 390 188 63 390 minecraft:green_concrete
fill 188 50 391 188 50 392 minecraft:lime_terracotta
fill 188 50 393 188 67 393 minecraft:green_concrete
fill 188 50 399 188 51 400 minecraft:lime_terracotta
fill 188 50 401 188 63 402 minecraft:green_concrete
fill 188 50 411 189 50 411 minecraft:lime_terracotta
fill 189 50 369 189 69 369 minecraft:green_concrete
setblock 190 50 369 minecraft:lime_terracotta
fill 190 50 411 191 63 411 minecraft:green_concrete
fill 191 50 369 192 63 369 minecraft:green_concrete
fill 193 50 369 194 51 369 minecraft:lime_terracotta
fill 194 50 373 196 50 374 minecraft:lime_terracotta
fill 195 50 371 196 50 372 minecraft:lime_terracotta
fill 195 50 375 196 50 376 minecraft:lime_terracotta
fill 196 50 370 201 50 370 minecraft:lime_terracotta
fill 196 50 377 201 50 377 minecraft:lime_terracotta
fill 197 50 371 202 50 371 minecraft:lime_terracotta
fill 197 50 376 202 50 376 minecraft:lime_terracotta
fill 197 50 411 197 51 411 minecraft:lime_terracotta
setblock 198 50 378 minecraft:lime_terracotta
fill 198 50 411 199 63 411 minecraft:green_concrete
fill 199 50 369 200 52 369 minecraft:green_concrete
setblock 200 50 411 minecraft:lime_terracotta
fill 201 50 369 202 50 369 minecraft:lime_terracotta
fill 201 50 372 202 51 375 minecraft:lime_terracotta
fill 202 50 411 202 67 411 minecraft:green_concrete
fill 203 50 369 203 63 369 minecraft:green_concrete
fill 203 50 373 203 50 374 minecraft:lime_terracotta
fill 205 50 369 205 51 369 minecraft:lime_terracotta
setblock 206 50 369 minecraft:green_concrete
fill 208 50 411 209 51 411 minecraft:lime_terracotta
fill 210 50 411 211 63 411 minecraft:green_concrete
fill 211 50 369 212 63 369 minecraft:green_concrete
fill 213 50 369 214 51 369 minecraft:lime_terracotta
fill 219 50 411 219 63 411 minecraft:green_concrete
fill 220 50 369 220 52 369 minecraft:green_concrete
fill 220 50 411 221 50 411 minecraft:lime_terracotta
setblock 222 50 369 minecraft:lime_terracotta
fill 222 50 411 223 67 411 minecraft:green_concrete
fill 223 50 369 224 63 369 minecraft:green_concrete
fill 225 50 369 225 51 369 minecraft:lime_terracotta
fill 228 50 411 229 51 411 minecraft:lime_terracotta
fill 230 50 370 230 63 371 minecraft:green_concrete
fill 230 50 372 230 50 373 minecraft:lime_terracotta
fill 230 50 382 230 63 383 minecraft:green_concrete
fill 230 50 384 230 51 385 minecraft:lime_terracotta
fill 230 50 391 230 67 391 minecraft:green_concrete
fill 230 50 392 230 50 393 minecraft:lime_terracotta
fill 230 50 394 230 63 394 minecraft:green_concrete
fill 230 50 396 230 51 396 minecraft:lime_terracotta
fill 230 50 402 230 63 403 minecraft:green_concrete
fill 230 50 404 230 51 405 minecraft:lime_terracotta
fill 230 50 411 230 63 411 minecraft:green_concrete
fill 188 51 371 188 69 371 minecraft:green_concrete
setblock 188 51 376 minecraft:lime_terracotta
setblock 188 51 387 minecraft:lime_terracotta
fill 188 51 391 188 69 392 minecraft:green_concrete
setblock 188 51 408 minecraft:lime_terracotta
setblock 188 51 411 minecraft:lime_terracotta
fill 189 51 411 189 69 411 minecraft:green_concrete
fill 190 51 369 190 69 369 minecraft:green_concrete
fill 195 51 372 196 51 375 minecraft:lime_terracotta
fill 196 51 371 201 51 371 minecraft:lime_terracotta
fill 196 51 376 201 51 376 minecraft:lime_terracotta
setblock 196 51 411 minecraft:lime_terracotta
fill 197 51 370 200 51 370 minecraft:lime_terracotta
fill 197 51 377 199 51 377 minecraft:lime_terracotta
fill 200 51 411 200 69 411 minecraft:green_concrete
fill 201 51 369 201 69 369 minecraft:green_concrete
setblock 202 51 369 minecraft:lime_terracotta
setblock 206 51 369 minecraft:lime_terracotta
fill 216 51 411 217 51 411 minecraft:lime_terracotta
setblock 217 51 369 minecraft:lime_terracotta
fill 218 51 369 218 65 369 minecraft:green_concrete
setblock 220 51 411 minecraft:lime_terracotta
fill 221 51 411 221 69 411 minecraft:green_concrete
fill 222 51 369 222 69 369 minecraft:green_concrete
setblock 226 51 369 minecraft:lime_terracotta
fill 230 51 372 230 69 372 minecraft:green_concrete
setblock 230 51 373 minecraft:lime_terracotta
setblock 230 51 376 minecraft:lime_terracotta
fill 230 51 392 230 69 393 minecraft:green_concrete
setblock 230 51 397 minecraft:lime_terracotta
setblock 230 51 408 minecraft:lime_terracotta
fill 188 52 376 188 65 376 minecraft:green_concrete
fill 188 52 377 188 52 378 minecraft:lime_terracotta
fill 188 52 379 188 69 380 minecraft:green_concrete
fill 188 52 385 188 53 386 minecraft:lime_terracotta
fill 188 52 387 188 65 388 minecraft:green_concrete
setblock 188 52 389 minecraft:lime_terracotta
fill 188 52 397 188 53 398 minecraft:lime_terracotta
fill 188 52 399 188 65 400 minecraft:green_concrete
fill 188 52 406 188 53 406 minecraft:lime_terracotta
fill 188 52 408 188 65 408 minecraft:green_concrete
fill 188 52 409 188 52 410 minecraft:lime_terracotta
fill 188 52 411 188 69 411 minecraft:green_concrete
fill 193 52 369 194 65 369 minecraft:green_concrete
fill 194 52 411 195 53 411 minecraft:lime_terracotta
fill 195 52 369 196 53 369 minecraft:lime_terracotta
fill 196 52 372 196 52 375 minecraft:lime_terracotta
fill 196 52 411 197 65 411 minecraft:green_concrete
fill 197 52 371 200 52 371 minecraft:lime_terracotta
fill 197 52 376 200 52 376 minecraft:lime_terracotta
fill 201 52 372 201 52 375 minecraft:lime_terracotta
fill 202 52 369 202 69 369 minecraft:green_concrete
setblock 204 52 369 minecraft:lime_terracotta
fill 205 52 369 206 65 369 minecraft:green_concrete
fill 206 52 411 207 52 411 minecraft:lime_terracotta
fill 207 52 369 208 53 369 minecraft:lime_terracotta
fill 208 52 411 209 65 411 minecraft:green_concrete
fill 213 52 369 214 65 369 minecraft:green_concrete
fill 215 52 369 216 52 369 minecraft:lime_terracotta
fill 215 52 411 215 53 411 minecraft:lime_terracotta
fill 216 52 411 217 65 411 minecraft:green_concrete
fill 217 52 369 217 65 369 minecraft:green_concrete
setblock 218 52 411 minecraft:lime_terracotta
fill 220 52 411 220 69 411 minecraft:green_concrete
fill 225 52 369 226 65 369 minecraft:green_concrete
fill 226 52 411 227 53 411 minecraft:lime_terracotta
fill 227 52 369 228 53 369 minecraft:lime_terracotta
fill 228 52 411 229 65 411 minecraft:green_concrete
fill 230 52 373 230 69 373 minecraft:green_concrete
fill 230 52 374 230 52 375 minecraft:lime_terracotta
fill 230 52 376 230 65 376 minecraft:green_concrete
fill 230 52 378 230 53 378 minecraft:lime_terracotta
fill 230 52 384 230 65 385 minecraft:green_concrete
fill 230 52 386 230 53 387 minecraft:lime_terracotta
setblock 230 52 395 minecraft:lime_terracotta
fill 230 52 396 230 65 397 minecraft:green_concrete
fill 230 52 398 230 53 399 minecraft:lime_terracotta
fill 230 52 404 230 69 405 minecraft:green_concrete
fill 230 52 406 230 52 407 minecraft:lime_terracotta
fill 230 52 408 230 65 408 minecraft:green_concrete
fill 188 53 373 188 53 374 minecraft:lime_terracotta
setblock 188 53 377 minecraft:lime_terracotta
fill 188 53 378 188 63 378 minecraft:green_concrete
fill 188 53 389 188 63 389 minecraft:green_concrete
setblock 188 53 394 minecraft:lime_terracotta
setblock 188 53 405 minecraft:lime_terracotta
fill 188 53 409 188 63 410 minecraft:green_concrete
setblock 199 53 369 minecraft:lime_terracotta
fill 200 53 369 200 67 369 minecraft:green_concrete
setblock 203 53 411 minecraft:lime_terracotta
fill 204 53 369 204 63 369 minecraft:green_concrete
setblock 206 53 411 minecraft:lime_terracotta
fill 207 53 411 207 63 411 minecraft:green_concrete
setblock 214 53 411 minecraft:lime_terracotta
fill 215 53 369 215 63 369 minecraft:green_concrete
setblock 216 53 369 minecraft:lime_terracotta
fill 218 53 411 218 63 411 minecraft:green_concrete
fill 219 53 369 220 53 369 minecraft:lime_terracotta
fill 230 53 374 230 63 375 minecraft:green_concrete
setblock 230 53 379 minecraft:lime_terracotta
setblock 230 53 390 minecraft:lime_terracotta
fill 230 53 395 230 63 395 minecraft:green_concrete
fill 230 53 406 230 63 406 minecraft:green_concrete
setblock 230 53 407 minecraft:lime_terracotta
setblock 230 53 410 minecraft:lime_terracotta
fill 188 54 373 188 67 374 minecraft:green_concrete
fill 188 54 377 188 64 377 minecraft:green_concrete
fill 188 54 385 188 67 386 minecraft:green_concrete
fill 188 54 394 188 67 394 minecraft:green_concrete
fill 188 54 397 188 64 398 minecraft:green_concrete
fill 188 54 405 188 67 406 minecraft:green_concrete
fill 194 54 411 195 64 411 minecraft:green_concrete
fill 195 54 369 196 64 369 minecraft:green_concrete
fill 199 54 369 199 67 369 minecraft:green_concrete
fill 203 54 411 203 67 411 minecraft:green_concrete
fill 206 54 411 206 64 411 minecraft:green_concrete
fill 207 54 369 208 67 369 minecraft:green_concrete
fill 214 54 411 215 67 411 minecraft:green_concrete
fill 216 54 369 216 64 369 minecraft:green_concrete
fill 219 54 369 220 67 369 minecraft:green_concrete
fill 226 54 411 227 64 411 minecraft:green_concrete
fill 227 54 369 228 64 369 minecraft:green_concrete
fill 230 54 378 230 67 379 minecraft:green_concrete
fill 230 54 386 230 64 387 minecraft:green_concrete
fill 230 54 390 230 67 390 minecraft:green_concrete
fill 230 54 398 230 67 399 minecraft:green_concrete
fill 230 54 407 230 64 407 minecraft:green_concrete
fill 230 54 410 230 67 410 minecraft:green_concrete
setblock 191 55 372 minecraft:light[level=14]
setblock 191 55 380 minecraft:light[level=14]
setblock 191 55 388 minecraft:light[level=14]
setblock 191 55 396 minecraft:light[level=14]
setblock 191 55 404 minecraft:light[level=14]
setblock 199 55 372 minecraft:light[level=14]
setblock 199 55 380 minecraft:light[level=14]
setblock 199 55 388 minecraft:light[level=14]
setblock 199 55 396 minecraft:light[level=14]
setblock 199 55 404 minecraft:light[level=14]
setblock 207 55 372 minecraft:light[level=14]
setblock 207 55 380 minecraft:light[level=14]
setblock 207 55 388 minecraft:light[level=14]
setblock 207 55 396 minecraft:light[level=14]
setblock 207 55 404 minecraft:light[level=14]
setblock 215 55 372 minecraft:light[level=14]
setblock 215 55 380 minecraft:light[level=14]
setblock 215 55 388 minecraft:light[level=14]
setblock 215 55 396 minecraft:light[level=14]
setblock 215 55 404 minecraft:light[level=14]
setblock 223 55 372 minecraft:light[level=14]
setblock 223 55 380 minecraft:light[level=14]
setblock 223 55 388 minecraft:light[level=14]
setblock 223 55 396 minecraft:light[level=14]
setblock 223 55 404 minecraft:light[level=14]
fill 192 59 393 197 60 393 minecraft:mud
fill 193 59 388 197 60 392 minecraft:mud
fill 193 59 394 196 60 398 minecraft:mud
fill 194 59 386 194 60 386 minecraft:lime_terracotta
fill 194 59 387 210 60 387 minecraft:mud
fill 194 59 399 196 60 400 minecraft:mud
fill 195 59 384 195 60 385 minecraft:lime_terracotta
fill 195 59 386 210 60 386 minecraft:mud
fill 195 59 401 196 60 402 minecraft:mud
fill 196 59 383 197 60 384 minecraft:lime_terracotta
fill 196 59 385 209 60 385 minecraft:mud
fill 196 59 403 197 60 403 minecraft:mud
fill 197 59 382 212 60 382 minecraft:lime_terracotta
fill 197 59 394 200 60 402 minecraft:lime_terracotta
fill 197 59 404 197 60 404 minecraft:mud
fill 198 59 381 210 60 381 minecraft:lime_terracotta
fill 198 59 383 199 60 383 minecraft:lime_terracotta
fill 198 59 384 208 60 384 minecraft:mud
fill 198 59 388 198 60 391 minecraft:mud
fill 198 59 392 201 60 393 minecraft:lime_terracotta
fill 198 59 403 201 60 404 minecraft:lime_terracotta
fill 198 59 405 198 60 405 minecraft:mud
fill 199 59 380 209 60 380 minecraft:lime_terracotta
fill 199 59 388 199 60 390 minecraft:mud
fill 199 59 391 205 60 391 minecraft:lime_terracotta
fill 199 59 405 203 60 406 minecraft:lime_terracotta
fill 200 59 383 206 60 383 minecraft:mud
fill 200 59 388 201 60 389 minecraft:mud
fill 200 59 390 206 60 390 minecraft:lime_terracotta
fill 201 59 379 206 60 379 minecraft:lime_terracotta
fill 201 59 394 204 60 401 minecraft:mud
fill 201 59 402 201 60 402 minecraft:lime_terracotta
fill 201 59 407 205 60 407 minecraft:lime_terracotta
fill 202 59 388 211 60 388 minecraft:mud
fill 202 59 389 206 60 389 minecraft:lime_terracotta
fill 202 59 392 202 60 392 minecraft:lime_terracotta
fill 202 59 393 204 60 393 minecraft:mud
fill 202 59 402 210 60 403 minecraft:mud
fill 202 59 404 202 60 404 minecraft:lime_terracotta
fill 203 59 378 213 60 378 minecraft:mud
fill 203 59 392 204 60 392 minecraft:mud
fill 203 59 404 219 60 404 minecraft:mud
fill 203 59 408 208 60 408 minecraft:lime_terracotta
fill 204 59 405 218 60 405 minecraft:mud
fill 204 59 406 204 60 406 minecraft:lime_terracotta
fill 205 59 392 205 60 394 minecraft:verdant_froglight
fill 205 59 395 205 60 401 minecraft:mud
fill 205 59 406 217 60 406 minecraft:mud
fill 206 59 391 206 60 392 minecraft:verdant_froglight
fill 206 59 394 206 60 395 minecraft:verdant_froglight
fill 206 59 396 206 60 398 minecraft:lime_terracotta
fill 206 59 399 206 60 401 minecraft:mud
fill 206 59 407 215 60 407 minecraft:mud
fill 207 59 379 215 60 379 minecraft:mud
fill 207 59 383 212 60 383 minecraft:lime_terracotta
fill 207 59 389 211 60 389 minecraft:mud
fill 207 59 390 207 60 391 minecraft:verdant_froglight
fill 207 59 395 207 60 396 minecraft:verdant_froglight
fill 207 59 397 208 60 400 minecraft:lime_terracotta
fill 207 59 401 208 60 401 minecraft:mud
fill 208 59 377 208 60 377 minecraft:mud
fill 208 59 390 209 60 390 minecraft:verdant_froglight
fill 208 59 396 209 60 396 minecraft:verdant_froglight
fill 208 59 409 208 60 409 minecraft:lime_terracotta
fill 209 59 384 213 60 384 minecraft:lime_terracotta
fill 209 59 391 210 60 391 minecraft:verdant_froglight
fill 209 59 395 210 60 395 minecraft:verdant_froglight
fill 209 59 397 216 60 397 minecraft:mud
fill 209 59 398 209 60 401 minecraft:lime_terracotta
fill 209 59 408 213 60 408 minecraft:mud
fill 210 59 380 217 60 380 minecraft:mud
fill 210 59 385 214 60 385 minecraft:lime_terracotta
fill 210 59 390 211 60 390 minecraft:mud
fill 210 59 392 211 60 392 minecraft:verdant_froglight
fill 210 59 394 211 60 394 minecraft:verdant_froglight
fill 210 59 396 218 60 396 minecraft:mud
fill 210 59 398 215 60 398 minecraft:mud
fill 210 59 399 217 60 401 minecraft:lime_terracotta
fill 211 59 381 218 60 381 minecraft:mud
fill 211 59 386 214 60 387 minecraft:lime_terracotta
fill 211 59 391 211 60 391 minecraft:mud
fill 211 59 393 211 60 393 minecraft:verdant_froglight
fill 211 59 395 218 60 395 minecraft:mud
fill 211 59 402 215 60 402 minecraft:lime_terracotta
fill 211 59 403 220 60 403 minecraft:mud
fill 212 59 388 213 60 393 minecraft:lime_terracotta
fill 212 59 394 219 60 394 minecraft:mud
fill 213 59 382 219 60 383 minecraft:mud
fill 214 59 384 220 60 384 minecraft:mud
fill 214 59 388 214 60 391 minecraft:lime_terracotta
fill 214 59 392 220 60 393 minecraft:mud
fill 215 59 385 220 60 391 minecraft:mud
fill 216 59 398 221 60 398 minecraft:lime_terracotta
fill 216 59 402 221 60 402 minecraft:mud
fill 217 59 397 222 60 397 minecraft:lime_terracotta
fill 218 59 399 219 60 400 minecraft:lime_terracotta
fill 218 59 401 221 60 401 minecraft:mud
fill 219 59 395 223 60 396 minecraft:lime_terracotta
fill 220 59 383 220 60 383 minecraft:mud
fill 220 59 394 223 60 394 minecraft:lime_terracotta
fill 220 59 399 220 60 399 minecraft:lime_terracotta
fill 220 59 400 222 60 400 minecraft:mud
fill 221 59 384 221 60 385 minecraft:lime_terracotta
fill 221 59 386 221 60 389 minecraft:mud
fill 221 59 390 223 60 393 minecraft:lime_terracotta
fill 221 59 399 222 60 399 minecraft:mud
fill 222 59 386 222 60 389 minecraft:lime_terracotta
fill 222 59 398 223 60 398 minecraft:mud
fill 223 59 388 223 60 389 minecraft:lime_terracotta
fill 223 59 397 223 60 397 minecraft:mud
fill 224 59 393 224 60 393 minecraft:lime_terracotta
fill 189 60 370 191 60 410 minecraft:mud
fill 192 60 370 192 60 392 minecraft:mud
fill 192 60 394 192 60 410 minecraft:mud
fill 193 60 370 193 60 387 minecraft:mud
fill 193 60 399 193 60 410 minecraft:mud
fill 194 60 370 194 60 385 minecraft:mud
fill 194 60 401 194 60 410 minecraft:mud
fill 195 60 370 195 60 383 minecraft:mud
fill 195 60 403 195 60 410 minecraft:mud
fill 196 60 370 196 60 382 minecraft:mud
fill 196 60 404 196 60 410 minecraft:mud
fill 197 60 370 197 60 381 minecraft:mud
fill 197 60 405 197 60 410 minecraft:mud
fill 198 60 370 198 60 380 minecraft:mud
fill 198 60 406 198 60 410 minecraft:mud
fill 199 60 370 200 60 379 minecraft:mud
fill 199 60 407 200 60 410 minecraft:mud
fill 201 60 370 202 60 378 minecraft:mud
fill 201 60 408 202 60 410 minecraft:mud
fill 203 60 370 207 60 377 minecraft:mud
fill 203 60 409 207 60 410 minecraft:mud
fill 208 60 370 229 60 376 minecraft:mud
fill 208 60 410 229 60 410 minecraft:mud
fill 209 60 377 229 60 377 minecraft:mud
fill 209 60 409 229 60 409 minecraft:mud
fill 214 60 378 229 60 378 minecraft:mud
fill 214 60 408 229 60 408 minecraft:mud
fill 216 60 379 229 60 379 minecraft:mud
fill 216 60 407 229 60 407 minecraft:mud
fill 218 60 380 229 60 380 minecraft:mud
fill 218 60 406 229 60 406 minecraft:mud
fill 219 60 381 229 60 381 minecraft:mud
fill 219 60 405 229 60 405 minecraft:mud
fill 220 60 382 229 60 382 minecraft:mud
fill 220 60 404 229 60 404 minecraft:mud
fill 221 60 383 229 60 383 minecraft:mud
fill 221 60 403 229 60 403 minecraft:mud
fill 222 60 384 229 60 385 minecraft:mud
fill 222 60 401 229 60 402 minecraft:mud
fill 223 60 386 229 60 387 minecraft:mud
fill 223 60 399 229 60 400 minecraft:mud
fill 224 60 388 229 60 392 minecraft:mud
fill 224 60 394 229 60 398 minecraft:mud
fill 225 60 393 229 60 393 minecraft:mud
setblock 191 63 372 minecraft:light[level=14]
setblock 191 63 380 minecraft:light[level=14]
setblock 191 63 388 minecraft:light[level=14]
setblock 191 63 396 minecraft:light[level=14]
setblock 191 63 404 minecraft:light[level=14]
setblock 199 63 372 minecraft:light[level=14]
setblock 199 63 380 minecraft:light[level=14]
setblock 199 63 388 minecraft:light[level=14]
setblock 199 63 396 minecraft:light[level=14]
setblock 199 63 404 minecraft:light[level=14]
setblock 207 63 372 minecraft:light[level=14]
setblock 207 63 380 minecraft:light[level=14]
setblock 207 63 388 minecraft:light[level=14]
setblock 207 63 396 minecraft:light[level=14]
setblock 207 63 404 minecraft:light[level=14]
setblock 215 63 372 minecraft:light[level=14]
setblock 215 63 380 minecraft:light[level=14]
setblock 215 63 388 minecraft:light[level=14]
setblock 215 63 396 minecraft:light[level=14]
setblock 215 63 404 minecraft:light[level=14]
setblock 223 63 372 minecraft:light[level=14]
setblock 223 63 380 minecraft:light[level=14]
setblock 223 63 388 minecraft:light[level=14]
setblock 223 63 396 minecraft:light[level=14]
setblock 223 63 404 minecraft:light[level=14]
fill 188 64 369 188 64 370 minecraft:lime_terracotta
fill 188 64 378 188 65 378 minecraft:lime_terracotta
setblock 188 64 381 minecraft:lime_terracotta
fill 188 64 382 188 67 382 minecraft:green_concrete
fill 188 64 389 188 65 390 minecraft:lime_terracotta
fill 188 64 401 188 64 402 minecraft:lime_terracotta
fill 188 64 409 188 65 410 minecraft:lime_terracotta
setblock 190 64 411 minecraft:lime_terracotta
fill 191 64 369 192 64 369 minecraft:lime_terracotta
fill 191 64 411 191 67 411 minecraft:green_concrete
fill 198 64 411 199 65 411 minecraft:lime_terracotta
fill 203 64 369 204 65 369 minecraft:lime_terracotta
fill 207 64 411 207 65 411 minecraft:lime_terracotta
fill 210 64 411 211 64 411 minecraft:lime_terracotta
fill 211 64 369 212 64 369 minecraft:lime_terracotta
fill 215 64 369 215 65 369 minecraft:lime_terracotta
fill 218 64 411 219 65 411 minecraft:lime_terracotta
fill 223 64 369 224 65 369 minecraft:lime_terracotta
fill 230 64 370 230 67 370 minecraft:green_concrete
setblock 230 64 371 minecraft:lime_terracotta
fill 230 64 374 230 65 375 minecraft:lime_terracotta
fill 230 64 382 230 64 383 minecraft:lime_terracotta
fill 230 64 394 230 65 395 minecraft:lime_terracotta
fill 230 64 402 230 67 402 minecraft:green_concrete
setblock 230 64 403 minecraft:lime_terracotta
fill 230 64 406 230 65 406 minecraft:lime_terracotta
fill 230 64 411 230 65 411 minecraft:lime_terracotta
setblock 188 65 369 minecraft:lime_terracotta
fill 188 65 370 188 68 370 minecraft:green_concrete
setblock 188 65 377 minecraft:lime_terracotta
fill 188 65 381 188 68 381 minecraft:green_concrete
fill 188 65 397 188 65 398 minecraft:lime_terracotta
setblock 188 65 401 minecraft:lime_terracotta
fill 188 65 402 188 68 402 minecraft:green_concrete
fill 190 65 411 190 68 411 minecraft:green_concrete
fill 191 65 369 191 68 369 minecraft:green_concrete
setblock 192 65 369 minecraft:lime_terracotta
fill 194 65 411 194 67 411 minecraft:green_concrete
fill 195 65 369 196 65 369 minecraft:lime_terracotta
setblock 195 65 411 minecraft:lime_terracotta
setblock 206 65 411 minecraft:lime_terracotta
fill 210 65 411 211 68 411 minecraft:green_concrete
fill 211 65 369 212 67 369 minecraft:green_concrete
setblock 216 65 369 minecraft:lime_terracotta
fill 226 65 411 226 67 411 minecraft:green_concrete
setblock 227 65 369 minecraft:lime_terracotta
setblock 227 65 411 minecraft:lime_terracotta
fill 228 65 369 228 67 369 minecraft:green_concrete
fill 230 65 371 230 67 371 minecraft:green_concrete
fill 230 65 382 230 68 382 minecraft:green_concrete
setblock 230 65 383 minecraft:lime_terracotta
fill 230 65 386 230 65 387 minecraft:lime_terracotta
fill 230 65 403 230 68 403 minecraft:green_concrete
setblock 230 65 407 minecraft:lime_terracotta
fill 188 66 369 188 71 369 minecraft:green_concrete
fill 188 66 375 188 67 376 minecraft:lime_terracotta
fill 188 66 377 188 71 378 minecraft:green_concrete
fill 188 66 387 188 66 388 minecraft:lime_terracotta
fill 188 66 389 188 71 390 minecraft:green_concrete
setblock 188 66 395 minecraft:green_concrete
fill 188 66 396 188 67 396 minecraft:lime_terracotta
fill 188 66 397 188 71 398 minecraft:green_concrete
setblock 188 66 399 minecraft:lime_terracotta
fill 188 66 400 188 69 401 minecraft:green_concrete
fill 188 66 407 188 67 408 minecraft:lime_terracotta
fill 188 66 409 188 71 410 minecraft:green_concrete
fill 189 66 370 191 66 370 minecraft:mud
fill 189 66 372 189 66 374 minecraft:mud
fill 189 66 376 189 66 378 minecraft:mud
fill 189 66 380 189 66 382 minecraft:mud
fill 189 66 384 189 66 386 minecraft:mud
fill 189 66 388 189 66 390 minecraft:mud
fill 189 66 392 189 66 394 minecraft:mud
fill 189 66 396 189 66 398 minecraft:mud
fill 189 66 400 189 66 402 minecraft:mud
fill 189 66 404 189 66 406 minecraft:mud
fill 189 66 408 189 66 410 minecraft:mud
fill 191 66 410 193 66 410 minecraft:mud
fill 192 66 369 193 69 369 minecraft:green_concrete
fill 193 66 370 195 66 370 minecraft:mud
setblock 194 66 369 minecraft:lime_terracotta
fill 195 66 369 196 71 369 minecraft:green_concrete
fill 195 66 410 197 66 410 minecraft:mud
fill 195 66 411 195 71 411 minecraft:green_concrete
fill 196 66 411 197 66 411 minecraft:lime_terracotta
fill 197 66 369 197 67 369 minecraft:lime_terracotta
fill 197 66 370 199 66 370 minecraft:mud
setblock 198 66 369 minecraft:green_concrete
fill 198 66 411 199 71 411 minecraft:green_concrete
fill 199 66 410 201 66 410 minecraft:mud
fill 201 66 370 203 66 370 minecraft:mud
fill 203 66 369 204 71 369 minecraft:green_concrete
fill 203 66 410 205 66 410 minecraft:mud
fill 204 66 411 205 67 411 minecraft:lime_terracotta
fill 205 66 369 206 66 369 minecraft:lime_terracotta
fill 205 66 370 207 66 370 minecraft:mud
fill 206 66 411 207 71 411 minecraft:green_concrete
fill 207 66 410 209 66 410 minecraft:mud
setblock 208 66 411 minecraft:lime_terracotta
fill 209 66 370 211 66 370 minecraft:mud
fill 209 66 411 209 69 411 minecraft:green_concrete
fill 211 66 410 213 66 410 minecraft:mud
fill 213 66 369 213 69 369 minecraft:green_concrete
fill 213 66 370 215 66 370 minecraft:mud
setblock 214 66 369 minecraft:lime_terracotta
fill 215 66 369 216 71 369 minecraft:green_concrete
fill 215 66 410 217 66 410 minecraft:mud
fill 216 66 411 217 67 411 minecraft:lime_terracotta
fill 217 66 369 218 67 369 minecraft:lime_terracotta
fill 217 66 370 219 66 370 minecraft:mud
fill 218 66 411 219 71 411 minecraft:green_concrete
fill 219 66 410 221 66 410 minecraft:mud
fill 221 66 370 223 66 370 minecraft:mud
fill 223 66 369 224 68 369 minecraft:green_concrete
fill 223 66 410 225 66 410 minecraft:mud
setblock 224 66 411 minecraft:green_concrete
fill 225 66 369 226 66 369 minecraft:lime_terracotta
fill 225 66 370 227 66 370 minecraft:mud
fill 225 66 411 225 67 411 minecraft:lime_terracotta
fill 227 66 369 227 71 369 minecraft:green_concrete
fill 227 66 410 229 66 410 minecraft:mud
fill 227 66 411 227 71 411 minecraft:green_concrete
fill 228 66 411 229 66 411 minecraft:lime_terracotta
fill 229 66 369 229 67 369 minecraft:lime_terracotta
fill 229 66 370 229 66 372 minecraft:mud
fill 229 66 374 229 66 376 minecraft:mud
fill 229 66 378 229 66 380 minecraft:mud
fill 229 66 382 229 66 384 minecraft:mud
fill 229 66 386 229 66 388 minecraft:mud
fill 229 66 390 229 66 392 minecraft:mud
fill 229 66 394 229 66 396 minecraft:mud
fill 229 66 398 229 66 400 minecraft:mud
fill 229 66 402 229 66 404 minecraft:mud
fill 229 66 406 229 66 408 minecraft:mud
setblock 230 66 369 minecraft:green_concrete
fill 230 66 374 230 71 375 minecraft:green_concrete
fill 230 66 376 230 67 377 minecraft:lime_terracotta
fill 230 66 383 230 68 384 minecraft:green_concrete
setblock 230 66 385 minecraft:lime_terracotta
fill 230 66 386 230 71 387 minecraft:green_concrete
fill 230 66 388 230 67 388 minecraft:lime_terracotta
setblock 230 66 389 minecraft:green_concrete
fill 230 66 394 230 71 395 minecraft:green_concrete
fill 230 66 396 230 66 397 minecraft:lime_terracotta
fill 230 66 406 230 71 407 minecraft:green_concrete
fill 230 66 408 230 67 409 minecraft:lime_terracotta
fill 230 66 411 230 71 411 minecraft:green_concrete
fill 188 67 383 188 69 383 minecraft:green_concrete
setblock 188 67 384 minecraft:lime_terracotta
setblock 188 67 387 minecraft:lime_terracotta
fill 188 67 388 188 70 388 minecraft:green_concrete
setblock 188 67 395 minecraft:lime_terracotta
fill 188 67 399 188 70 399 minecraft:green_concrete
fill 192 67 411 193 67 411 minecraft:lime_terracotta
fill 194 67 369 194 70 369 minecraft:green_concrete
setblock 196 67 411 minecraft:lime_terracotta
fill 197 67 411 197 70 411 minecraft:green_concrete
setblock 198 67 369 minecraft:lime_terracotta
fill 205 67 369 205 70 369 minecraft:green_concrete
setblock 206 67 369 minecraft:lime_terracotta
fill 208 67 411 208 70 411 minecraft:green_concrete
setblock 209 67 369 minecraft:lime_terracotta
fill 210 67 369 210 69 369 minecraft:green_concrete
fill 212 67 411 212 69 411 minecraft:green_concrete
setblock 213 67 411 minecraft:lime_terracotta
fill 214 67 369 214 69 369 minecraft:green_concrete
setblock 224 67 411 minecraft:lime_terracotta
fill 225 67 369 225 70 369 minecraft:green_concrete
setblock 226 67 369 minecraft:lime_terracotta
fill 228 67 411 229 70 411 minecraft:green_concrete
setblock 230 67 369 minecraft:lime_terracotta
setblock 230 67 380 minecraft:lime_terracotta
fill 230 67 381 230 69 381 minecraft:green_concrete
fill 230 67 385 230 70 385 minecraft:green_concrete
setblock 230 67 389 minecraft:lime_terracotta
fill 230 67 396 230 70 396 minecraft:green_concrete
setblock 230 67 397 minecraft:lime_terracotta
setblock 230 67 400 minecraft:lime_terracotta
fill 230 67 401 230 69 401 minecraft:green_concrete
fill 188 68 373 188 69 374 minecraft:lime_terracotta
fill 188 68 375 188 73 376 minecraft:green_concrete
fill 188 68 382 188 69 382 minecraft:lime_terracotta
fill 188 68 384 188 73 384 minecraft:green_concrete
fill 188 68 385 188 68 386 minecraft:lime_terracotta
fill 188 68 387 188 73 387 minecraft:green_concrete
fill 188 68 393 188 69 394 minecraft:lime_terracotta
fill 188 68 395 188 73 396 minecraft:green_concrete
fill 188 68 405 188 68 406 minecraft:lime_terracotta
fill 188 68 407 188 73 408 minecraft:green_concrete
fill 191 68 411 191 69 411 minecraft:lime_terracotta
fill 192 68 411 193 73 411 minecraft:green_concrete
setblock 194 68 411 minecraft:lime_terracotta
fill 196 68 411 196 73 411 minecraft:green_concrete
fill 197 68 369 198 73 369 minecraft:green_concrete
fill 199 68 369 200 69 369 minecraft:lime_terracotta
fill 202 68 411 203 69 411 minecraft:lime_terracotta
fill 204 68 411 205 73 411 minecraft:green_concrete
fill 206 68 369 206 73 369 minecraft:green_concrete
fill 207 68 369 208 68 369 minecraft:lime_terracotta
fill 209 68 369 209 73 369 minecraft:green_concrete
fill 211 68 369 211 69 369 minecraft:lime_terracotta
setblock 212 68 369 minecraft:green_concrete
fill 213 68 411 213 73 411 minecraft:green_concrete
fill 214 68 411 215 68 411 minecraft:lime_terracotta
fill 216 68 411 217 73 411 minecraft:green_concrete
fill 217 68 369 218 73 369 minecraft:green_concrete
fill 219 68 369 220 69 369 minecraft:lime_terracotta
fill 222 68 411 223 69 411 minecraft:lime_terracotta
fill 224 68 411 225 73 411 minecraft:green_concrete
fill 226 68 369 226 70 369 minecraft:green_concrete
setblock 226 68 411 minecraft:lime_terracotta
setblock 228 68 369 minecraft:lime_terracotta
fill 229 68 369 230 73 369 minecraft:green_concrete
fill 230 68 370 230 69 371 minecraft:lime_terracotta
fill 230 68 376 230 73 377 minecraft:green_concrete
fill 230 68 378 230 68 379 minecraft:lime_terracotta
fill 230 68 380 230 69 380 minecraft:green_concrete
fill 230 68 388 230 73 389 minecraft:green_concrete
fill 230 68 390 230 69 391 minecraft:lime_terracotta
fill 230 68 397 230 73 397 minecraft:green_concrete
fill 230 68 398 230 68 399 minecraft:lime_terracotta
fill 230 68 400 230 73 400 minecraft:green_concrete
fill 230 68 402 230 69 402 minecraft:lime_terracotta
fill 230 68 408 230 73 409 minecraft:green_concrete
fill 230 68 410 230 69 410 minecraft:lime_terracotta
setblock 188 69 370 minecraft:lime_terracotta
setblock 188 69 381 minecraft:lime_terracotta
fill 188 69 385 188 72 386 minecraft:green_concrete
setblock 188 69 402 minecraft:lime_terracotta
setblock 188 69 405 minecraft:lime_terracotta
fill 188 69 406 188 72 406 minecraft:green_concrete
setblock 190 69 411 minecraft:lime_terracotta
setblock 191 69 369 minecraft:lime_terracotta
fill 194 69 411 194 72 411 minecraft:green_concrete
fill 207 69 369 208 72 369 minecraft:green_concrete
fill 210 69 411 211 69 411 minecraft:lime_terracotta
setblock 212 69 369 minecraft:lime_terracotta
setblock 214 69 411 minecraft:lime_terracotta
fill 215 69 411 215 72 411 minecraft:green_concrete
setblock 223 69 369 minecraft:lime_terracotta
fill 224 69 369 224 71 369 minecraft:green_concrete
fill 226 69 411 226 72 411 minecraft:green_concrete
fill 228 69 369 228 72 369 minecraft:green_concrete
fill 230 69 378 230 72 378 minecraft:green_concrete
setblock 230 69 379 minecraft:lime_terracotta
fill 230 69 382 230 69 383 minecraft:lime_terracotta
setblock 230 69 384 minecraft:green_concrete
fill 230 69 398 230 72 399 minecraft:green_concrete
setblock 230 69 403 minecraft:lime_terracotta
fill 188 70 370 188 75 370 minecraft:green_concrete
fill 188 70 371 188 70 372 minecraft:lime_terracotta
fill 188 70 373 188 75 374 minecraft:green_concrete
fill 188 70 379 188 71 380 minecraft:lime_terracotta
fill 188 70 381 188 75 382 minecraft:green_concrete
setblock 188 70 383 minecraft:lime_terracotta
fill 188 70 391 188 71 392 minecraft:lime_terracotta
fill 188 70 393 188 75 394 minecraft:green_concrete
fill 188 70 400 188 71 400 minecraft:lime_terracotta
fill 188 70 401 188 71 402 minecraft:green_concrete
fill 188 70 403 188 70 404 minecraft:lime_terracotta
fill 188 70 405 188 75 405 minecraft:green_concrete
fill 188 70 411 189 71 411 minecraft:lime_terracotta
fill 189 70 369 190 70 369 minecraft:lime_terracotta
fill 190 70 411 191 75 411 minecraft:green_concrete
fill 191 70 369 192 71 369 minecraft:green_concrete
fill 193 70 369 193 71 369 minecraft:lime_terracotta
fill 199 70 369 200 75 369 minecraft:green_concrete
fill 200 70 411 201 70 411 minecraft:lime_terracotta
fill 201 70 369 202 71 369 minecraft:lime_terracotta
fill 202 70 411 203 75 411 minecraft:green_concrete
fill 209 70 411 209 71 411 minecraft:lime_terracotta
setblock 210 70 369 minecraft:lime_terracotta
fill 210 70 411 211 75 411 minecraft:green_concrete
fill 211 70 369 212 75 369 minecraft:green_concrete
setblock 212 70 411 minecraft:lime_terracotta
fill 213 70 369 214 71 369 minecraft:lime_terracotta
fill 214 70 411 214 75 411 minecraft:green_concrete
fill 219 70 369 220 75 369 minecraft:green_concrete
fill 220 70 411 221 71 411 minecraft:lime_terracotta
fill 221 70 369 222 70 369 minecraft:lime_terracotta
fill 222 70 411 223 75 411 minecraft:green_concrete
fill 223 70 369 223 71 369 minecraft:green_concrete
fill 230 70 370 230 75 371 minecraft:green_concrete
fill 230 70 372 230 71 373 minecraft:lime_terracotta
fill 230 70 379 230 75 379 minecraft:green_concrete
fill 230 70 380 230 70 381 minecraft:lime_terracotta
fill 230 70 382 230 71 383 minecraft:green_concrete
fill 230 70 384 230 71 384 minecraft:lime_terracotta
fill 230 70 390 230 75 391 minecraft:green_concrete
fill 230 70 392 230 71 393 minecraft:lime_terracotta
setblock 230 70 401 minecraft:lime_terracotta
fill 230 70 402 230 75 403 minecraft:green_concrete
fill 230 70 404 230 71 405 minecraft:lime_terracotta
fill 230 70 410 230 75 410 minecraft:green_concrete
setblock 188 71 371 minecraft:lime_terracotta
fill 188 71 372 188 74 372 minecraft:green_concrete
fill 188 71 383 188 74 383 minecraft:green_concrete
setblock 188 71 388 minecraft:lime_terracotta
setblock 188 71 399 minecraft:lime_terracotta
fill 188 71 403 188 74 404 minecraft:green_concrete
fill 189 71 369 190 74 369 minecraft:green_concrete
setblock 191 71 372 minecraft:light[level=14]
setblock 191 71 380 minecraft:light[level=14]
setblock 191 71 388 minecraft:light[level=14]
setblock 191 71 396 minecraft:light[level=14]
setblock 191 71 404 minecraft:light[level=14]
setblock 194 71 369 minecraft:lime_terracotta
setblock 197 71 411 minecraft:lime_terracotta
setblock 199 71 372 minecraft:light[level=14]
setblock 199 71 380 minecraft:light[level=14]
setblock 199 71 388 minecraft:light[level=14]
setblock 199 71 396 minecraft:light[level=14]
setblock 199 71 404 minecraft:light[level=14]
setblock 200 71 411 minecraft:lime_terracotta
fill 201 71 411 201 74 411 minecraft:green_concrete
setblock 205 71 369 minecraft:lime_terracotta
setblock 207 71 372 minecraft:light[level=14]
setblock 207 71 380 minecraft:light[level=14]
setblock 207 71 388 minecraft:light[level=14]
setblock 207 71 396 minecraft:light[level=14]
setblock 207 71 404 minecraft:light[level=14]
setblock 208 71 411 minecraft:lime_terracotta
fill 210 71 369 210 74 369 minecraft:green_concrete
fill 212 71 411 212 74 411 minecraft:green_concrete
setblock 215 71 372 minecraft:light[level=14]
setblock 215 71 380 minecraft:light[level=14]
setblock 215 71 388 minecraft:light[level=14]
setblock 215 71 396 minecraft:light[level=14]
setblock 215 71 404 minecraft:light[level=14]
fill 221 71 369 221 74 369 minecraft:green_concrete
setblock 222 71 369 minecraft:lime_terracotta
setblock 223 71 372 minecraft:light[level=14]
setblock 223 71 380 minecraft:light[level=14]
setblock 223 71 388 minecraft:light[level=14]
setblock 223 71 396 minecraft:light[level=14]
setblock 223 71 404 minecraft:light[level=14]
fill 225 71 369 226 71 369 minecraft:lime_terracotta
fill 228 71 411 229 71 411 minecraft:lime_terracotta
fill 230 71 380 230 73 381 minecraft:green_concrete
setblock 230 71 385 minecraft:lime_terracotta
setblock 230 71 396 minecraft:lime_terracotta
fill 230 71 401 230 74 401 minecraft:green_concrete
setblock 188 72 369 minecraft:lime_terracotta
fill 188 72 371 188 77 371 minecraft:green_concrete
fill 188 72 377 188 73 378 minecraft:lime_terracotta
fill 188 72 379 188 77 380 minecraft:green_concrete
fill 188 72 388 188 77 388 minecraft:green_concrete
fill 188 72 389 188 72 390 minecraft:lime_terracotta
fill 188 72 391 188 75 392 minecraft:green_concrete
fill 188 72 397 188 73 398 minecraft:lime_terracotta
fill 188 72 399 188 77 400 minecraft:green_concrete
setblock 188 72 401 minecraft:lime_terracotta
fill 188 72 402 188 75 402 minecraft:green_concrete
fill 188 72 409 188 73 410 minecraft:lime_terracotta
fill 188 72 411 189 75 411 minecraft:green_concrete
fill 189 72 370 191 72 370 minecraft:mud
fill 189 72 372 189 72 374 minecraft:mud
fill 189 72 376 189 72 378 minecraft:mud
fill 189 72 380 189 72 382 minecraft:mud
fill 189 72 384 189 72 386 minecraft:mud
fill 189 72 388 189 72 390 minecraft:mud
fill 189 72 392 189 72 394 minecraft:mud
fill 189 72 396 189 72 398 minecraft:mud
fill 189 72 400 189 72 402 minecraft:mud
fill 189 72 404 189 72 406 minecraft:mud
fill 189 72 408 189 72 410 minecraft:mud
fill 191 72 369 191 75 369 minecraft:green_concrete
fill 191 72 410 193 72 410 minecraft:mud
setblock 192 72 369 minecraft:lime_terracotta
fill 193 72 369 194 76 369 minecraft:green_concrete
fill 193 72 370 195 72 370 minecraft:mud
fill 195 72 369 196 73 369 minecraft:lime_terracotta
fill 195 72 410 197 72 410 minecraft:mud
fill 195 72 411 195 73 411 minecraft:lime_terracotta
fill 197 72 370 199 72 370 minecraft:mud
fill 197 72 411 197 77 411 minecraft:green_concrete
fill 198 72 411 199 72 411 minecraft:lime_terracotta
fill 199 72 410 201 72 410 minecraft:mud
fill 200 72 411 200 77 411 minecraft:green_concrete
fill 201 72 369 202 77 369 minecraft:green_concrete
fill 201 72 370 203 72 370 minecraft:mud
fill 203 72 369 204 72 369 minecraft:lime_terracotta
fill 203 72 410 205 72 410 minecraft:mud
fill 205 72 369 205 77 369 minecraft:green_concrete
fill 205 72 370 207 72 370 minecraft:mud
fill 206 72 411 207 73 411 minecraft:lime_terracotta
fill 207 72 410 209 72 410 minecraft:mud
fill 208 72 411 209 75 411 minecraft:green_concrete
fill 209 72 370 211 72 370 minecraft:mud
fill 211 72 410 213 72 410 minecraft:mud
fill 213 72 369 214 77 369 minecraft:green_concrete
fill 213 72 370 215 72 370 minecraft:mud
fill 215 72 369 216 73 369 minecraft:lime_terracotta
fill 215 72 410 217 72 410 minecraft:mud
fill 217 72 370 219 72 370 minecraft:mud
fill 218 72 411 219 72 411 minecraft:lime_terracotta
fill 219 72 410 221 72 410 minecraft:mud
fill 220 72 411 221 77 411 minecraft:green_concrete
fill 221 72 370 223 72 370 minecraft:mud
fill 222 72 369 222 77 369 minecraft:green_concrete
fill 223 72 369 224 72 369 minecraft:lime_terracotta
fill 223 72 410 225 72 410 minecraft:mud
fill 225 72 369 226 73 369 minecraft:green_concrete
fill 225 72 370 227 72 370 minecraft:mud
fill 227 72 369 227 73 369 minecraft:lime_terracotta
fill 227 72 410 229 72 410 minecraft:mud
fill 227 72 411 227 73 411 minecraft:lime_terracotta
fill 228 72 411 229 77 411 minecraft:green_concrete
fill 229 72 370 229 72 372 minecraft:mud
fill 229 72 374 229 72 376 minecraft:mud
fill 229 72 378 229 72 380 minecraft:mud
fill 229 72 382 229 72 384 minecraft:mud
fill 229 72 386 229 72 388 minecraft:mud
fill 229 72 390 229 72 392 minecraft:mud
fill 229 72 394 229 72 396 minecraft:mud
fill 229 72 398 229 72 400 minecraft:mud
fill 229 72 402 229 72 404 minecraft:mud
fill 229 72 406 229 72 408 minecraft:mud
fill 230 72 372 230 77 373 minecraft:green_concrete
fill 230 72 374 230 73 375 minecraft:lime_terracotta
fill 230 72 382 230 75 382 minecraft:green_concrete
setblock 230 72 383 minecraft:lime_terracotta
fill 230 72 384 230 77 385 minecraft:green_concrete
fill 230 72 386 230 73 387 minecraft:lime_terracotta
fill 230 72 392 230 74 393 minecraft:green_concrete
fill 230 72 394 230 72 395 minecraft:lime_terracotta
fill 230 72 396 230 77 396 minecraft:green_concrete
fill 230 72 404 230 76 405 minecraft:green_concrete
fill 230 72 406 230 73 407 minecraft:lime_terracotta
setblock 230 72 411 minecraft:lime_terracotta
fill 188 73 369 188 75 369 minecraft:green_concrete
fill 188 73 385 188 73 386 minecraft:lime_terracotta
setblock 188 73 389 minecraft:lime_terracotta
fill 188 73 390 188 76 390 minecraft:green_concrete
fill 188 73 401 188 75 401 minecraft:green_concrete
setblock 188 73 406 minecraft:lime_terracotta
fill 192 73 369 192 75 369 minecraft:green_concrete
setblock 194 73 411 minecraft:lime_terracotta
fill 198 73 411 199 76 411 minecraft:green_concrete
fill 203 73 369 203 76 369 minecraft:green_concrete
setblock 204 73 369 minecraft:lime_terracotta
fill 207 73 369 208 73 369 minecraft:lime_terracotta
setblock 215 73 411 minecraft:lime_terracotta
setblock 218 73 411 minecraft:lime_terracotta
fill 219 73 411 219 76 411 minecraft:green_concrete
fill 223 73 369 224 75 369 minecraft:green_concrete
setblock 226 73 411 minecraft:lime_terracotta
setblock 228 73 369 minecraft:lime_terracotta
setblock 230 73 378 minecraft:lime_terracotta
fill 230 73 383 230 75 383 minecraft:green_concrete
fill 230 73 394 230 76 394 minecraft:green_concrete
setblock 230 73 395 minecraft:lime_terracotta
fill 230 73 398 230 73 399 minecraft:lime_terracotta
fill 230 73 411 230 76 411 minecraft:green_concrete
fill 188 74 375 188 74 376 minecraft:lime_terracotta
fill 188 74 377 188 79 378 minecraft:green_concrete
fill 188 74 384 188 75 384 minecraft:lime_terracotta
fill 188 74 385 188 79 386 minecraft:green_concrete
setblock 188 74 387 minecraft:lime_terracotta
fill 188 74 389 188 79 389 minecraft:green_concrete
fill 188 74 395 188 75 396 minecraft:lime_terracotta
fill 188 74 397 188 79 398 minecraft:green_concrete
fill 188 74 406 188 79 406 minecraft:green_concrete
fill 188 74 407 188 74 408 minecraft:lime_terracotta
fill 188 74 409 188 77 410 minecraft:green_concrete
fill 192 74 411 193 75 411 minecraft:lime_terracotta
fill 194 74 411 195 76 411 minecraft:green_concrete
fill 195 74 369 196 76 369 minecraft:green_concrete
setblock 196 74 411 minecraft:lime_terracotta
fill 197 74 369 198 75 369 minecraft:lime_terracotta
fill 204 74 369 204 79 369 minecraft:green_concrete
fill 204 74 411 205 75 411 minecraft:lime_terracotta
setblock 206 74 369 minecraft:lime_terracotta
fill 206 74 411 207 75 411 minecraft:green_concrete
fill 207 74 369 208 75 369 minecraft:green_concrete
fill 209 74 369 209 75 369 minecraft:lime_terracotta
fill 213 74 411 213 75 411 minecraft:lime_terracotta
fill 215 74 369 216 75 369 minecraft:green_concrete
fill 215 74 411 215 75 411 minecraft:green_concrete
fill 216 74 411 217 74 411 minecraft:lime_terracotta
fill 217 74 369 218 74 369 minecraft:lime_terracotta
fill 218 74 411 218 76 411 minecraft:green_concrete
fill 224 74 411 225 75 411 minecraft:lime_terracotta
fill 225 74 369 225 75 369 minecraft:green_concrete
fill 225 74 372 227 133 373 minecraft:mud
setblock 226 74 369 minecraft:lime_terracotta
fill 226 74 374 226 133 374 minecraft:mud
fill 226 74 411 227 77 411 minecraft:green_concrete
fill 227 74 369 228 79 369 minecraft:green_concrete
fill 229 74 369 230 75 369 minecraft:lime_terracotta
fill 230 74 374 230 76 375 minecraft:green_concrete
fill 230 74 376 230 74 377 minecraft:lime_terracotta
fill 230 74 378 230 79 378 minecraft:green_concrete
fill 230 74 380 230 75 380 minecraft:lime_terracotta
setblock 230 74 381 minecraft:green_concrete
fill 230 74 386 230 77 387 minecraft:green_concrete
fill 230 74 388 230 75 389 minecraft:lime_terracotta
fill 230 74 395 230 75 395 minecraft:green_concrete
setblock 230 74 397 minecraft:lime_terracotta
fill 230 74 398 230 77 399 minecraft:green_concrete
fill 230 74 400 230 75 400 minecraft:lime_terracotta
fill 230 74 406 230 76 407 minecraft:green_concrete
fill 230 74 408 230 74 409 minecraft:lime_terracotta
setblock 188 75 372 minecraft:lime_terracotta
setblock 188 75 375 minecraft:lime_terracotta
fill 188 75 376 188 78 376 minecraft:green_concrete
setblock 188 75 383 minecraft:lime_terracotta
fill 188 75 387 188 78 387 minecraft:green_concrete
fill 188 75 403 188 75 404 minecraft:lime_terracotta
setblock 188 75 407 minecraft:lime_terracotta
fill 188 75 408 188 78 408 minecraft:green_concrete
fill 189 75 369 190 75 369 minecraft:lime_terracotta
setblock 196 75 411 minecraft:green_concrete
setblock 201 75 411 minecraft:lime_terracotta
fill 206 75 369 206 78 369 minecraft:green_concrete
setblock 210 75 369 minecraft:lime_terracotta
setblock 212 75 411 minecraft:lime_terracotta
fill 216 75 411 217 76 411 minecraft:green_concrete
fill 217 75 369 217 77 369 minecraft:green_concrete
setblock 218 75 369 minecraft:lime_terracotta
setblock 221 75 369 minecraft:lime_terracotta
fill 225 75 374 225 76 374 minecraft:mud
fill 226 75 369 226 77 369 minecraft:green_concrete
fill 226 75 371 226 76 371 minecraft:mud
fill 227 75 374 227 76 374 minecraft:mud
fill 228 75 373 228 76 373 minecraft:mud
fill 230 75 376 230 78 376 minecraft:green_concrete
setblock 230 75 377 minecraft:lime_terracotta
setblock 230 75 381 minecraft:lime_terracotta
setblock 230 75 392 minecraft:lime_terracotta
fill 230 75 393 230 77 393 minecraft:green_concrete
fill 230 75 397 230 77 397 minecraft:green_concrete
setblock 230 75 401 minecraft:lime_terracotta
fill 230 75 408 230 78 408 minecraft:green_concrete
setblock 230 75 409 minecraft:lime_terracotta
setblock 188 76 369 minecraft:moss_block
fill 188 76 370 188 77 370 minecraft:lime_terracotta
setblock 188 76 372 minecraft:green_concrete
fill 188 76 373 188 76 374 minecraft:lime_terracotta
fill 188 76 375 188 79 375 minecraft:green_concrete
fill 188 76 381 188 77 382 minecraft:lime_terracotta
fill 188 76 383 188 79 384 minecraft:green_concrete
fill 188 76 391 188 77 391 minecraft:green_concrete
setblock 188 76 392 minecraft:moss_block
fill 188 76 393 188 76 394 minecraft:lime_terracotta
fill 188 76 395 188 79 396 minecraft:green_concrete
setblock 188 76 401 minecraft:moss_block
fill 188 76 402 188 77 402 minecraft:lime_terracotta
setblock 188 76 403 minecraft:moss_block
fill 188 76 404 188 79 404 minecraft:green_concrete
setblock 188 76 405 minecraft:lime_terracotta
fill 188 76 407 188 80 407 minecraft:green_concrete
setblock 188 76 411 minecraft:moss_block
fill 189 76 369 190 79 369 minecraft:green_concrete
fill 189 76 411 189 77 411 minecraft:green_concrete
fill 190 76 411 191 77 411 minecraft:lime_terracotta
fill 191 76 369 191 77 369 minecraft:lime_terracotta
setblock 192 76 369 minecraft:moss_block
fill 192 76 411 193 79 411 minecraft:green_concrete
setblock 196 76 411 minecraft:moss_block
fill 197 76 369 198 79 369 minecraft:green_concrete
fill 199 76 369 200 76 369 minecraft:lime_terracotta
fill 201 76 411 201 79 411 minecraft:green_concrete
fill 202 76 411 203 76 411 minecraft:lime_terracotta
fill 204 76 411 206 77 411 minecraft:green_concrete
setblock 207 76 369 minecraft:green_concrete
fill 207 76 411 208 76 411 minecraft:moss_block
fill 208 76 369 208 77 369 minecraft:moss_block
fill 209 76 369 210 76 369 minecraft:green_concrete
fill 209 76 411 209 77 411 minecraft:green_concrete
fill 210 76 411 211 77 411 minecraft:lime_terracotta
fill 211 76 369 212 77 369 minecraft:lime_terracotta
fill 212 76 411 213 79 411 minecraft:green_concrete
setblock 214 76 411 minecraft:lime_terracotta
setblock 215 76 369 minecraft:moss_block
setblock 215 76 411 minecraft:moss_block
fill 216 76 369 216 79 369 minecraft:green_concrete
setblock 218 76 369 minecraft:green_concrete
fill 219 76 369 220 76 369 minecraft:lime_terracotta
fill 221 76 369 221 79 369 minecraft:green_concrete
fill 222 76 411 223 77 411 minecraft:lime_terracotta
fill 223 76 369 223 77 369 minecraft:lime_terracotta
setblock 224 76 369 minecraft:green_concrete
fill 224 76 372 224 76 374 minecraft:mud
fill 224 76 411 225 77 411 minecraft:green_concrete
setblock 225 76 369 minecraft:moss_block
setblock 225 76 371 minecraft:mud
fill 225 76 375 227 76 375 minecraft:mud
setblock 227 76 371 minecraft:mud
setblock 228 76 372 minecraft:mud
setblock 228 76 374 minecraft:mud
fill 229 76 369 230 76 369 minecraft:green_concrete
fill 230 76 370 230 77 371 minecraft:lime_terracotta
schedule function dropper:buildpart/88_2 1t
