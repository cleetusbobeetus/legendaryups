setblock 317 253 231 minecraft:light[level=12]
setblock 317 253 239 minecraft:light[level=12]
setblock 317 253 247 minecraft:light[level=12]
setblock 317 253 255 minecraft:light[level=12]
setblock 317 253 263 minecraft:light[level=12]
setblock 324 253 256 minecraft:crying_obsidian
fill 282 254 243 282 283 243 minecraft:blackstone
fill 282 254 245 282 283 245 minecraft:blackstone
fill 284 254 231 284 254 233 minecraft:orange_concrete
setblock 286 254 228 minecraft:shroomlight
fill 286 254 235 288 254 235 minecraft:orange_concrete
fill 288 254 230 289 254 230 minecraft:orange_concrete
setblock 289 254 231 minecraft:orange_concrete
setblock 289 254 234 minecraft:orange_concrete
fill 293 254 270 293 283 270 minecraft:blackstone
setblock 295 254 241 minecraft:orange_concrete
fill 296 254 240 297 254 240 minecraft:orange_concrete
fill 296 254 245 297 254 245 minecraft:orange_concrete
fill 297 254 258 297 260 258 minecraft:dripstone_block
fill 299 254 242 299 254 244 minecraft:orange_concrete
fill 301 254 237 301 260 237 minecraft:dripstone_block
setblock 308 254 270 minecraft:crying_obsidian
fill 312 254 245 312 260 245 minecraft:dripstone_block
fill 315 254 241 315 260 241 minecraft:dripstone_block
fill 324 254 231 324 278 232 minecraft:blackstone
setblock 324 254 233 minecraft:shroomlight
fill 324 254 256 324 260 256 minecraft:blackstone
setblock 282 255 258 minecraft:crying_obsidian
setblock 285 255 238 minecraft:light[level=12]
setblock 285 255 245 minecraft:light[level=12]
setblock 285 255 252 minecraft:light[level=12]
setblock 285 255 259 minecraft:light[level=12]
setblock 285 255 266 minecraft:light[level=12]
fill 286 255 228 286 272 228 minecraft:blackstone
setblock 292 255 231 minecraft:light[level=12]
setblock 292 255 238 minecraft:light[level=12]
setblock 292 255 245 minecraft:light[level=12]
setblock 292 255 252 minecraft:light[level=12]
setblock 292 255 259 minecraft:light[level=12]
setblock 292 255 266 minecraft:light[level=12]
setblock 299 255 231 minecraft:light[level=12]
setblock 299 255 238 minecraft:light[level=12]
setblock 299 255 245 minecraft:light[level=12]
setblock 299 255 252 minecraft:light[level=12]
setblock 299 255 259 minecraft:light[level=12]
setblock 299 255 266 minecraft:light[level=12]
setblock 306 255 231 minecraft:light[level=12]
setblock 306 255 238 minecraft:light[level=12]
setblock 306 255 245 minecraft:light[level=12]
setblock 306 255 252 minecraft:light[level=12]
setblock 306 255 259 minecraft:light[level=12]
setblock 306 255 266 minecraft:light[level=12]
fill 308 255 265 308 260 265 minecraft:dripstone_block
fill 308 255 270 308 279 270 minecraft:blackstone
fill 311 255 236 311 260 236 minecraft:dripstone_block
setblock 313 255 231 minecraft:light[level=12]
setblock 313 255 238 minecraft:light[level=12]
setblock 313 255 245 minecraft:light[level=12]
setblock 313 255 252 minecraft:light[level=12]
setblock 313 255 259 minecraft:light[level=12]
setblock 313 255 266 minecraft:light[level=12]
setblock 319 255 228 minecraft:shroomlight
setblock 320 255 231 minecraft:light[level=12]
setblock 320 255 238 minecraft:light[level=12]
setblock 320 255 245 minecraft:light[level=12]
setblock 320 255 252 minecraft:light[level=12]
setblock 320 255 259 minecraft:light[level=12]
setblock 320 255 266 minecraft:light[level=12]
fill 324 255 233 324 283 235 minecraft:blackstone
setblock 324 255 236 minecraft:shroomlight
fill 324 255 237 324 283 238 minecraft:blackstone
setblock 324 255 252 minecraft:magma_block
fill 282 256 258 282 283 258 minecraft:blackstone
fill 292 256 237 292 260 237 minecraft:dripstone_block
fill 294 256 250 294 260 250 minecraft:dripstone_block
fill 296 256 260 296 260 260 minecraft:dripstone_block
fill 298 256 258 298 260 258 minecraft:dripstone_block
fill 307 256 238 307 260 238 minecraft:dripstone_block
fill 312 256 254 312 260 254 minecraft:dripstone_block
fill 313 256 236 313 260 236 minecraft:dripstone_block
fill 313 256 250 313 260 250 minecraft:dripstone_block
fill 319 256 228 319 260 228 minecraft:blackstone
fill 324 256 236 324 283 236 minecraft:blackstone
fill 324 256 252 324 265 252 minecraft:blackstone
fill 290 257 240 290 260 240 minecraft:dripstone_block
fill 292 257 254 292 260 254 minecraft:dripstone_block
fill 293 257 237 293 260 237 minecraft:dripstone_block
fill 295 257 246 295 260 246 minecraft:dripstone_block
fill 295 257 249 295 260 249 minecraft:dripstone_block
fill 295 257 251 295 260 251 minecraft:dripstone_block
fill 302 257 237 302 260 237 minecraft:dripstone_block
fill 305 257 263 305 260 263 minecraft:dripstone_block
fill 306 257 233 306 260 233 minecraft:dripstone_block
fill 307 257 234 307 260 234 minecraft:dripstone_block
fill 307 257 265 307 260 265 minecraft:dripstone_block
fill 310 257 245 310 260 245 minecraft:dripstone_block
fill 311 257 237 311 260 237 minecraft:dripstone_block
fill 311 257 255 311 260 256 minecraft:dripstone_block
fill 312 257 236 312 260 236 minecraft:dripstone_block
fill 312 257 244 312 260 244 minecraft:dripstone_block
fill 312 257 250 312 260 250 minecraft:dripstone_block
fill 314 257 248 314 260 248 minecraft:dripstone_block
fill 315 257 242 315 260 242 minecraft:dripstone_block
fill 291 258 241 291 260 241 minecraft:dripstone_block
fill 292 258 238 293 260 238 minecraft:dripstone_block
fill 292 258 255 292 260 255 minecraft:dripstone_block
fill 294 258 245 294 260 245 minecraft:dripstone_block
fill 294 258 248 294 260 248 minecraft:dripstone_block
fill 295 258 250 295 260 250 minecraft:dripstone_block
fill 297 258 257 297 260 257 minecraft:dripstone_block
setblock 299 258 270 minecraft:magma_block
fill 301 258 238 301 260 238 minecraft:dripstone_block
fill 307 258 239 307 260 239 minecraft:dripstone_block
fill 310 258 255 310 260 256 minecraft:dripstone_block
fill 311 258 245 311 260 245 minecraft:dripstone_block
fill 312 258 237 312 260 237 minecraft:dripstone_block
fill 313 258 248 313 260 248 minecraft:dripstone_block
fill 313 258 251 313 260 251 minecraft:dripstone_block
fill 313 258 254 313 260 254 minecraft:dripstone_block
fill 314 258 236 314 260 236 minecraft:dripstone_block
fill 314 258 247 314 260 247 minecraft:dripstone_block
fill 315 258 244 315 260 244 minecraft:dripstone_block
setblock 319 258 270 minecraft:magma_block
fill 290 259 241 290 260 241 minecraft:dripstone_block
fill 291 259 239 291 260 239 minecraft:dripstone_block
fill 291 259 254 291 260 254 minecraft:dripstone_block
fill 294 259 251 294 260 252 minecraft:dripstone_block
fill 295 259 244 295 260 244 minecraft:dripstone_block
fill 295 259 248 295 260 248 minecraft:dripstone_block
fill 295 259 252 295 260 252 minecraft:dripstone_block
fill 295 259 260 295 260 260 minecraft:dripstone_block
fill 296 259 245 296 260 245 minecraft:dripstone_block
fill 296 259 259 296 260 259 minecraft:dripstone_block
fill 296 259 261 296 260 261 minecraft:dripstone_block
fill 297 259 260 297 260 260 minecraft:dripstone_block
fill 299 259 270 299 283 270 minecraft:blackstone
fill 301 259 236 301 260 236 minecraft:dripstone_block
fill 302 259 238 302 260 238 minecraft:dripstone_block
fill 305 259 262 305 260 262 minecraft:dripstone_block
fill 306 259 234 306 260 234 minecraft:dripstone_block
fill 306 259 238 306 260 239 minecraft:dripstone_block
fill 306 259 263 306 260 263 minecraft:dripstone_block
setblock 306 259 270 minecraft:magma_block
fill 307 259 264 308 260 264 minecraft:dripstone_block
fill 308 259 233 308 260 233 minecraft:dripstone_block
fill 308 259 266 308 260 266 minecraft:dripstone_block
fill 310 259 246 311 260 246 minecraft:dripstone_block
fill 311 259 244 311 260 244 minecraft:dripstone_block
fill 312 259 249 312 260 249 minecraft:dripstone_block
fill 312 259 251 312 260 251 minecraft:dripstone_block
fill 312 259 253 312 260 253 minecraft:dripstone_block
fill 312 259 255 312 260 255 minecraft:dripstone_block
fill 313 259 235 314 260 235 minecraft:dripstone_block
fill 313 259 244 313 260 245 minecraft:dripstone_block
fill 313 259 247 313 260 247 minecraft:dripstone_block
fill 314 259 241 314 260 241 minecraft:dripstone_block
fill 315 259 243 315 260 243 minecraft:dripstone_block
fill 316 259 241 316 260 242 minecraft:dripstone_block
fill 319 259 270 319 271 270 minecraft:blackstone
setblock 324 259 257 minecraft:crying_obsidian
setblock 282 260 233 minecraft:shroomlight
setblock 282 260 234 minecraft:crying_obsidian
setblock 285 260 231 minecraft:light[level=12]
setblock 285 260 239 minecraft:light[level=12]
setblock 285 260 247 minecraft:light[level=12]
setblock 285 260 255 minecraft:light[level=12]
setblock 285 260 263 minecraft:light[level=12]
setblock 290 260 239 minecraft:dripstone_block
setblock 291 260 255 minecraft:dripstone_block
fill 292 260 236 293 260 236 minecraft:dripstone_block
setblock 292 260 240 minecraft:dripstone_block
setblock 292 260 253 minecraft:dripstone_block
setblock 293 260 231 minecraft:light[level=12]
setblock 293 260 239 minecraft:light[level=12]
setblock 293 260 247 minecraft:light[level=12]
fill 293 260 248 293 260 249 minecraft:dripstone_block
fill 293 260 254 293 260 255 minecraft:dripstone_block
setblock 293 260 263 minecraft:light[level=12]
setblock 294 260 246 minecraft:dripstone_block
setblock 295 260 259 minecraft:dripstone_block
setblock 296 260 246 minecraft:dripstone_block
setblock 296 260 251 minecraft:dripstone_block
setblock 296 260 258 minecraft:dripstone_block
setblock 297 260 259 minecraft:dripstone_block
fill 299 260 257 299 260 258 minecraft:dripstone_block
setblock 300 260 237 minecraft:dripstone_block
setblock 301 260 231 minecraft:light[level=12]
setblock 301 260 239 minecraft:light[level=12]
setblock 301 260 255 minecraft:light[level=12]
setblock 301 260 263 minecraft:light[level=12]
setblock 302 260 236 minecraft:dripstone_block
setblock 304 260 263 minecraft:dripstone_block
setblock 305 260 264 minecraft:dripstone_block
setblock 306 260 262 minecraft:dripstone_block
fill 306 260 270 306 283 270 minecraft:blackstone
setblock 307 260 232 minecraft:dripstone_block
setblock 307 260 237 minecraft:dripstone_block
setblock 307 260 266 minecraft:dripstone_block
setblock 308 260 234 minecraft:dripstone_block
fill 308 260 238 308 260 239 minecraft:dripstone_block
setblock 309 260 231 minecraft:light[level=12]
setblock 309 260 239 minecraft:light[level=12]
setblock 309 260 247 minecraft:light[level=12]
setblock 309 260 255 minecraft:light[level=12]
setblock 309 260 263 minecraft:light[level=12]
setblock 310 260 244 minecraft:dripstone_block
setblock 311 260 235 minecraft:dripstone_block
setblock 311 260 250 minecraft:dripstone_block
setblock 311 260 254 minecraft:dripstone_block
setblock 312 260 246 minecraft:dripstone_block
fill 313 260 237 314 260 237 minecraft:dripstone_block
setblock 313 260 249 minecraft:dripstone_block
setblock 313 260 253 minecraft:dripstone_block
setblock 313 260 255 minecraft:dripstone_block
fill 314 260 242 314 260 244 minecraft:dripstone_block
fill 314 260 250 314 260 251 minecraft:dripstone_block
setblock 315 260 240 minecraft:dripstone_block
fill 316 260 243 316 260 244 minecraft:dripstone_block
setblock 317 260 231 minecraft:light[level=12]
setblock 317 260 239 minecraft:light[level=12]
setblock 317 260 247 minecraft:light[level=12]
setblock 317 260 255 minecraft:light[level=12]
setblock 317 260 263 minecraft:light[level=12]
fill 324 260 257 324 283 257 minecraft:blackstone
fill 282 261 233 282 283 234 minecraft:blackstone
fill 283 261 229 293 261 229 minecraft:basalt
fill 283 261 230 287 261 232 minecraft:blackstone
setblock 283 261 233 minecraft:tuff
fill 283 261 234 289 261 234 minecraft:basalt
fill 283 261 235 283 261 238 minecraft:blackstone
fill 283 261 239 285 261 239 minecraft:basalt
fill 283 261 240 286 261 243 minecraft:blackstone
fill 283 261 244 287 261 244 minecraft:basalt
fill 283 261 245 286 261 245 minecraft:blackstone
setblock 283 261 246 minecraft:tuff
fill 283 261 247 283 263 248 minecraft:blackstone
fill 283 261 249 286 261 249 minecraft:basalt
fill 283 261 250 284 261 253 minecraft:blackstone
fill 283 261 254 286 261 254 minecraft:basalt
fill 283 261 255 287 261 258 minecraft:blackstone
setblock 283 261 259 minecraft:tuff
fill 283 261 260 283 261 263 minecraft:blackstone
fill 283 261 264 291 261 264 minecraft:basalt
fill 283 261 265 285 261 268 minecraft:blackstone
fill 283 261 269 287 261 269 minecraft:basalt
fill 284 261 233 295 261 233 minecraft:blackstone
setblock 284 261 235 minecraft:tuff
fill 284 261 236 284 261 238 minecraft:blackstone
fill 284 261 246 286 262 247 minecraft:blackstone
setblock 284 261 248 minecraft:tuff
fill 284 261 259 289 261 259 minecraft:basalt
fill 284 261 260 289 261 260 minecraft:blackstone
setblock 284 261 261 minecraft:tuff
fill 284 261 262 284 263 263 minecraft:blackstone
fill 285 261 235 290 261 236 minecraft:blackstone
setblock 285 261 237 minecraft:tuff
fill 285 261 238 290 262 238 minecraft:blackstone
fill 285 261 248 286 263 248 minecraft:blackstone
setblock 285 261 250 minecraft:tuff
fill 285 261 251 285 261 253 minecraft:blackstone
fill 285 261 261 290 261 262 minecraft:blackstone
setblock 285 261 263 minecraft:tuff
fill 286 261 237 291 261 237 minecraft:blackstone
setblock 286 261 239 minecraft:tuff
fill 286 261 250 286 261 251 minecraft:blackstone
setblock 286 261 252 minecraft:tuff
fill 286 261 253 286 264 253 minecraft:blackstone
fill 286 261 263 294 261 263 minecraft:blackstone
setblock 286 261 265 minecraft:tuff
fill 286 261 266 286 261 268 minecraft:blackstone
fill 287 261 239 289 261 239 minecraft:basalt
fill 287 261 240 289 261 240 minecraft:blackstone
setblock 287 261 241 minecraft:tuff
fill 287 261 242 287 263 243 minecraft:blackstone
fill 287 261 245 289 261 245 minecraft:shroomlight
fill 287 261 246 290 261 250 minecraft:netherrack
fill 287 261 251 289 261 251 minecraft:shroomlight
fill 287 261 252 294 261 253 minecraft:netherrack
setblock 287 261 254 minecraft:tuff
fill 287 261 265 292 261 266 minecraft:blackstone
setblock 287 261 267 minecraft:tuff
fill 287 261 268 293 262 268 minecraft:blackstone
setblock 288 261 230 minecraft:tuff
fill 288 261 231 288 262 232 minecraft:blackstone
fill 288 261 241 288 262 242 minecraft:blackstone
fill 288 261 243 294 261 244 minecraft:netherrack
fill 288 261 254 291 261 255 minecraft:netherrack
setblock 288 261 256 minecraft:tuff
fill 288 261 257 288 263 258 minecraft:blackstone
fill 288 261 267 299 261 267 minecraft:blackstone
setblock 288 261 269 minecraft:tuff
fill 289 261 230 294 261 231 minecraft:blackstone
setblock 289 261 232 minecraft:tuff
fill 289 261 241 291 261 242 minecraft:netherrack
fill 289 261 256 290 261 256 minecraft:netherrack
fill 289 261 257 290 261 257 minecraft:shroomlight
setblock 289 261 258 minecraft:tuff
fill 289 261 269 300 261 269 minecraft:basalt
fill 290 261 232 301 261 232 minecraft:blackstone
setblock 290 261 234 minecraft:tuff
setblock 290 261 239 minecraft:shroomlight
setblock 290 261 240 minecraft:netherrack
fill 290 261 245 296 261 245 minecraft:netherrack
fill 290 261 251 296 261 251 minecraft:netherrack
fill 290 261 258 295 261 259 minecraft:netherrack
setblock 290 261 260 minecraft:tuff
fill 291 261 234 296 261 234 minecraft:basalt
fill 291 261 235 294 261 235 minecraft:blackstone
setblock 291 261 236 minecraft:tuff
fill 291 261 238 295 261 239 minecraft:netherrack
setblock 291 261 240 minecraft:shroomlight
fill 291 261 246 293 261 246 minecraft:shroomlight
fill 291 261 247 295 261 249 minecraft:netherrack
fill 291 261 250 293 261 250 minecraft:shroomlight
setblock 291 261 256 minecraft:shroomlight
fill 291 261 257 296 261 257 minecraft:netherrack
fill 291 261 260 294 261 260 minecraft:netherrack
fill 291 261 261 291 262 261 minecraft:blackstone
setblock 291 261 262 minecraft:tuff
fill 292 261 236 292 262 236 minecraft:blackstone
fill 292 261 237 295 261 237 minecraft:netherrack
fill 292 261 240 296 261 240 minecraft:netherrack
setblock 292 261 241 minecraft:shroomlight
setblock 292 261 242 minecraft:netherrack
setblock 292 261 254 minecraft:netherrack
setblock 292 261 255 minecraft:shroomlight
fill 292 261 256 296 261 256 minecraft:netherrack
fill 292 261 261 294 261 261 minecraft:netherrack
fill 292 261 262 292 263 262 minecraft:blackstone
setblock 292 261 264 minecraft:tuff
fill 293 261 236 294 261 236 minecraft:netherrack
fill 293 261 241 300 261 241 minecraft:netherrack
setblock 293 261 242 minecraft:shroomlight
setblock 293 261 254 minecraft:shroomlight
fill 293 261 255 300 261 255 minecraft:netherrack
setblock 293 261 262 minecraft:netherrack
fill 293 261 264 296 261 264 minecraft:basalt
fill 293 261 265 298 261 265 minecraft:blackstone
setblock 293 261 266 minecraft:tuff
setblock 294 261 229 minecraft:tuff
fill 294 261 242 297 261 242 minecraft:netherrack
fill 294 261 246 298 261 246 minecraft:netherrack
fill 294 261 250 298 261 250 minecraft:netherrack
fill 294 261 254 297 261 254 minecraft:netherrack
setblock 294 261 262 minecraft:shroomlight
fill 294 261 266 305 261 266 minecraft:blackstone
setblock 294 261 268 minecraft:tuff
fill 295 261 229 306 261 229 minecraft:basalt
fill 295 261 230 300 261 230 minecraft:blackstone
setblock 295 261 231 minecraft:tuff
fill 295 261 235 295 261 236 minecraft:shroomlight
setblock 295 261 243 minecraft:shroomlight
setblock 295 261 244 minecraft:netherrack
setblock 295 261 252 minecraft:netherrack
setblock 295 261 253 minecraft:shroomlight
fill 295 261 260 295 261 261 minecraft:shroomlight
fill 295 261 262 300 261 263 minecraft:netherrack
fill 295 261 268 306 261 268 minecraft:blackstone
fill 296 261 231 307 261 231 minecraft:blackstone
setblock 296 261 233 minecraft:tuff
fill 296 261 235 300 261 236 minecraft:netherrack
fill 296 261 237 296 261 238 minecraft:shroomlight
setblock 296 261 239 minecraft:netherrack
fill 296 261 243 300 261 243 minecraft:netherrack
setblock 296 261 244 minecraft:shroomlight
fill 296 261 247 297 261 247 minecraft:shroomlight
fill 296 261 248 297 261 248 minecraft:netherrack
fill 296 261 249 297 261 249 minecraft:shroomlight
setblock 296 261 252 minecraft:shroomlight
fill 296 261 253 300 261 253 minecraft:netherrack
fill 296 261 258 296 261 259 minecraft:shroomlight
fill 296 261 260 300 261 261 minecraft:netherrack
fill 297 261 233 298 263 233 minecraft:blackstone
fill 297 261 234 300 261 234 minecraft:netherrack
fill 297 261 237 300 261 238 minecraft:netherrack
fill 297 261 239 297 261 240 minecraft:shroomlight
fill 297 261 244 298 261 244 minecraft:netherrack
setblock 297 261 245 minecraft:shroomlight
setblock 297 261 251 minecraft:shroomlight
fill 297 261 252 298 261 252 minecraft:netherrack
fill 297 261 256 297 261 257 minecraft:shroomlight
fill 297 261 258 300 261 259 minecraft:netherrack
fill 297 261 264 300 261 264 minecraft:netherrack
fill 298 261 239 300 261 240 minecraft:netherrack
setblock 298 261 242 minecraft:shroomlight
fill 298 261 245 299 261 245 minecraft:netherrack
fill 298 261 251 299 261 251 minecraft:netherrack
setblock 298 261 254 minecraft:shroomlight
fill 298 261 256 300 261 257 minecraft:netherrack
fill 299 261 233 300 261 233 minecraft:netherrack
fill 299 261 242 300 261 242 minecraft:netherrack
setblock 299 261 244 minecraft:shroomlight
setblock 299 261 252 minecraft:shroomlight
fill 299 261 254 300 261 254 minecraft:netherrack
fill 299 261 265 300 261 265 minecraft:netherrack
setblock 300 261 244 minecraft:netherrack
setblock 300 261 252 minecraft:netherrack
setblock 300 261 267 minecraft:tuff
setblock 301 261 230 minecraft:tuff
fill 301 261 233 301 261 244 minecraft:shroomlight
fill 301 261 252 301 261 265 minecraft:shroomlight
fill 301 261 267 312 261 267 minecraft:blackstone
setblock 301 261 269 minecraft:tuff
fill 302 261 230 313 261 230 minecraft:blackstone
setblock 302 261 232 minecraft:tuff
fill 302 261 233 302 261 244 minecraft:netherrack
fill 302 261 252 302 261 265 minecraft:netherrack
fill 302 261 269 313 261 269 minecraft:basalt
fill 303 261 232 314 261 232 minecraft:blackstone
fill 303 261 233 303 261 243 minecraft:netherrack
setblock 303 261 244 minecraft:shroomlight
fill 303 261 245 304 261 245 minecraft:netherrack
fill 303 261 251 304 261 251 minecraft:netherrack
setblock 303 261 252 minecraft:shroomlight
fill 303 261 253 303 261 265 minecraft:netherrack
setblock 303 261 270 minecraft:shroomlight
fill 304 261 233 304 261 241 minecraft:netherrack
setblock 304 261 242 minecraft:shroomlight
fill 304 261 243 305 261 244 minecraft:netherrack
fill 304 261 246 308 261 246 minecraft:netherrack
fill 304 261 250 308 261 250 minecraft:netherrack
fill 304 261 252 305 261 253 minecraft:netherrack
setblock 304 261 254 minecraft:shroomlight
fill 304 261 255 304 261 265 minecraft:netherrack
fill 305 261 233 305 261 238 minecraft:netherrack
fill 305 261 239 305 261 240 minecraft:shroomlight
fill 305 261 241 308 261 242 minecraft:netherrack
setblock 305 261 245 minecraft:shroomlight
fill 305 261 247 306 261 247 minecraft:shroomlight
fill 305 261 248 319 261 248 minecraft:netherrack
fill 305 261 249 306 261 249 minecraft:shroomlight
setblock 305 261 251 minecraft:shroomlight
fill 305 261 254 308 261 255 minecraft:netherrack
fill 305 261 256 305 261 257 minecraft:shroomlight
fill 305 261 258 305 261 265 minecraft:netherrack
fill 306 261 233 306 261 236 minecraft:netherrack
fill 306 261 237 306 261 238 minecraft:shroomlight
fill 306 261 239 310 261 240 minecraft:netherrack
setblock 306 261 243 minecraft:netherrack
setblock 306 261 244 minecraft:shroomlight
fill 306 261 245 312 261 245 minecraft:netherrack
fill 306 261 251 312 261 251 minecraft:netherrack
setblock 306 261 252 minecraft:shroomlight
setblock 306 261 253 minecraft:netherrack
fill 306 261 256 310 261 257 minecraft:netherrack
fill 306 261 258 306 261 259 minecraft:shroomlight
fill 306 261 260 306 261 265 minecraft:netherrack
setblock 306 261 266 minecraft:tuff
setblock 307 261 229 minecraft:tuff
fill 307 261 233 307 261 234 minecraft:netherrack
fill 307 261 235 307 261 236 minecraft:shroomlight
fill 307 261 237 312 261 238 minecraft:netherrack
setblock 307 261 243 minecraft:shroomlight
fill 307 261 244 316 261 244 minecraft:netherrack
fill 307 261 247 319 261 247 minecraft:netherrack
fill 307 261 249 319 261 249 minecraft:netherrack
fill 307 261 252 316 261 252 minecraft:netherrack
setblock 307 261 253 minecraft:shroomlight
fill 307 261 258 312 261 259 minecraft:netherrack
fill 307 261 260 307 261 261 minecraft:shroomlight
fill 307 261 262 307 261 265 minecraft:netherrack
fill 307 261 266 318 261 266 minecraft:blackstone
setblock 307 261 268 minecraft:tuff
fill 308 261 229 319 261 229 minecraft:basalt
setblock 308 261 231 minecraft:tuff
fill 308 261 233 308 264 233 minecraft:blackstone
setblock 308 261 234 minecraft:shroomlight
fill 308 261 235 311 261 236 minecraft:netherrack
fill 308 261 243 318 261 243 minecraft:netherrack
fill 308 261 253 319 261 253 minecraft:netherrack
fill 308 261 260 314 261 261 minecraft:netherrack
fill 308 261 262 308 261 263 minecraft:shroomlight
setblock 308 261 264 minecraft:netherrack
fill 308 261 265 311 261 265 minecraft:blackstone
fill 308 261 268 319 261 268 minecraft:blackstone
fill 309 261 231 320 261 231 minecraft:blackstone
setblock 309 261 233 minecraft:tuff
setblock 309 261 234 minecraft:netherrack
setblock 309 261 241 minecraft:netherrack
setblock 309 261 242 minecraft:shroomlight
fill 309 261 246 311 261 246 minecraft:shroomlight
fill 309 261 250 311 261 250 minecraft:shroomlight
setblock 309 261 254 minecraft:shroomlight
setblock 309 261 255 minecraft:netherrack
fill 309 261 262 311 261 263 minecraft:netherrack
setblock 309 261 264 minecraft:shroomlight
fill 310 261 233 321 261 233 minecraft:blackstone
fill 310 261 234 315 261 234 minecraft:basalt
setblock 310 261 241 minecraft:shroomlight
fill 310 261 242 317 261 242 minecraft:netherrack
fill 310 261 254 318 261 254 minecraft:netherrack
setblock 310 261 255 minecraft:shroomlight
fill 310 261 264 317 261 264 minecraft:basalt
setblock 311 261 239 minecraft:netherrack
setblock 311 261 240 minecraft:shroomlight
fill 311 261 241 317 261 241 minecraft:netherrack
fill 311 261 255 318 261 255 minecraft:netherrack
setblock 311 261 256 minecraft:shroomlight
setblock 311 261 257 minecraft:netherrack
fill 312 261 235 322 261 235 minecraft:blackstone
fill 312 261 236 313 261 236 minecraft:netherrack
fill 312 261 239 313 261 239 minecraft:shroomlight
fill 312 261 240 316 261 240 minecraft:netherrack
fill 312 261 246 319 261 246 minecraft:netherrack
fill 312 261 250 319 261 250 minecraft:netherrack
fill 312 261 256 317 261 256 minecraft:netherrack
fill 312 261 257 313 261 257 minecraft:shroomlight
fill 312 261 262 313 261 262 minecraft:netherrack
fill 312 261 263 323 261 263 minecraft:blackstone
setblock 312 261 265 minecraft:tuff
setblock 313 261 237 minecraft:netherrack
fill 313 261 238 314 261 238 minecraft:shroomlight
fill 313 261 245 316 261 245 minecraft:shroomlight
fill 313 261 251 316 261 251 minecraft:shroomlight
fill 313 261 258 314 261 258 minecraft:shroomlight
setblock 313 261 259 minecraft:netherrack
fill 313 261 265 323 261 265 minecraft:blackstone
setblock 313 261 267 minecraft:tuff
setblock 314 261 230 minecraft:tuff
fill 314 261 236 316 262 236 minecraft:blackstone
setblock 314 261 237 minecraft:shroomlight
fill 314 261 239 316 261 239 minecraft:netherrack
fill 314 261 257 317 261 257 minecraft:netherrack
fill 314 261 259 315 261 259 minecraft:shroomlight
fill 314 261 262 316 262 262 minecraft:blackstone
fill 314 261 267 323 261 267 minecraft:blackstone
setblock 314 261 269 minecraft:tuff
fill 315 261 230 323 261 230 minecraft:blackstone
setblock 315 261 232 minecraft:tuff
fill 315 261 237 323 261 237 minecraft:blackstone
setblock 315 261 238 minecraft:netherrack
fill 315 261 258 316 261 258 minecraft:netherrack
setblock 315 261 260 minecraft:netherrack
fill 315 261 261 322 261 261 minecraft:blackstone
fill 315 261 269 323 261 269 minecraft:basalt
fill 316 261 232 323 261 232 minecraft:blackstone
setblock 316 261 234 minecraft:tuff
fill 316 261 238 317 264 238 minecraft:blackstone
setblock 316 261 259 minecraft:netherrack
setblock 316 261 260 minecraft:tuff
fill 317 261 234 323 261 234 minecraft:basalt
setblock 317 261 236 minecraft:tuff
fill 317 261 239 323 261 239 minecraft:basalt
fill 317 261 240 318 261 240 minecraft:blackstone
fill 317 261 244 318 261 244 minecraft:shroomlight
fill 317 261 245 319 261 245 minecraft:netherrack
fill 317 261 251 319 261 251 minecraft:netherrack
fill 317 261 252 319 261 252 minecraft:shroomlight
fill 317 261 258 323 261 258 minecraft:blackstone
fill 317 261 259 321 261 259 minecraft:basalt
fill 317 261 260 323 261 260 minecraft:blackstone
setblock 317 261 262 minecraft:tuff
fill 318 261 236 323 261 236 minecraft:blackstone
setblock 318 261 238 minecraft:tuff
fill 318 261 241 319 261 242 minecraft:blackstone
fill 318 261 256 320 261 257 minecraft:blackstone
fill 318 261 262 323 261 262 minecraft:blackstone
setblock 318 261 264 minecraft:tuff
setblock 319 261 228 minecraft:magma_block
fill 319 261 238 323 261 238 minecraft:blackstone
setblock 319 261 240 minecraft:tuff
fill 319 261 243 323 261 243 minecraft:blackstone
fill 319 261 244 320 261 244 minecraft:basalt
fill 319 261 254 323 261 254 minecraft:basalt
setblock 319 261 255 minecraft:blackstone
fill 319 261 264 323 261 264 minecraft:basalt
setblock 319 261 266 minecraft:tuff
setblock 320 261 229 minecraft:tuff
fill 320 261 240 323 261 241 minecraft:blackstone
setblock 320 261 242 minecraft:tuff
fill 320 261 245 321 261 248 minecraft:blackstone
fill 320 261 249 323 261 249 minecraft:basalt
fill 320 261 250 323 261 253 minecraft:blackstone
setblock 320 261 255 minecraft:tuff
fill 320 261 266 323 262 266 minecraft:blackstone
setblock 320 261 268 minecraft:tuff
fill 321 261 229 323 261 229 minecraft:basalt
setblock 321 261 231 minecraft:tuff
fill 321 261 242 323 263 242 minecraft:blackstone
setblock 321 261 244 minecraft:tuff
fill 321 261 255 323 261 256 minecraft:blackstone
setblock 321 261 257 minecraft:tuff
fill 321 261 268 323 263 268 minecraft:blackstone
fill 322 261 231 323 262 231 minecraft:blackstone
setblock 322 261 233 minecraft:tuff
fill 322 261 244 323 261 244 minecraft:basalt
fill 322 261 245 323 261 245 minecraft:blackstone
setblock 322 261 246 minecraft:tuff
fill 322 261 247 322 263 248 minecraft:blackstone
fill 322 261 257 323 263 257 minecraft:blackstone
setblock 322 261 259 minecraft:tuff
fill 323 261 233 323 264 233 minecraft:blackstone
setblock 323 261 235 minecraft:tuff
fill 323 261 246 323 262 247 minecraft:blackstone
setblock 323 261 248 minecraft:tuff
setblock 323 261 259 minecraft:basalt
setblock 323 261 261 minecraft:tuff
setblock 324 261 256 minecraft:magma_block
setblock 282 262 230 minecraft:magma_block
fill 282 262 255 282 282 256 minecraft:blackstone
setblock 282 262 257 minecraft:magma_block
fill 283 262 229 285 263 229 minecraft:blackstone
fill 283 262 230 292 262 230 minecraft:basalt
fill 283 262 231 286 262 234 minecraft:blackstone
fill 283 262 235 288 262 235 minecraft:basalt
setblock 283 262 236 minecraft:tuff
fill 283 262 237 283 262 239 minecraft:blackstone
fill 283 262 240 284 262 240 minecraft:basalt
fill 283 262 241 285 262 244 minecraft:blackstone
fill 283 262 245 293 262 245 minecraft:basalt
setblock 283 262 246 minecraft:blackstone
setblock 283 262 249 minecraft:tuff
fill 283 262 250 289 262 250 minecraft:basalt
fill 283 262 251 283 262 254 minecraft:blackstone
fill 283 262 255 285 262 255 minecraft:basalt
fill 283 262 256 286 262 259 minecraft:blackstone
fill 283 262 260 294 262 260 minecraft:basalt
fill 283 262 261 288 262 261 minecraft:blackstone
setblock 283 262 262 minecraft:tuff
fill 283 262 263 283 264 264 minecraft:blackstone
fill 283 262 265 290 262 265 minecraft:basalt
fill 283 262 266 284 262 269 minecraft:blackstone
fill 284 262 236 289 262 237 minecraft:blackstone
setblock 284 262 238 minecraft:tuff
fill 284 262 239 290 263 239 minecraft:blackstone
fill 284 262 248 284 264 249 minecraft:blackstone
setblock 284 262 251 minecraft:tuff
fill 284 262 252 284 262 254 minecraft:blackstone
setblock 284 262 264 minecraft:tuff
setblock 285 262 240 minecraft:tuff
fill 285 262 249 295 262 249 minecraft:blackstone
fill 285 262 251 290 262 252 minecraft:blackstone
setblock 285 262 253 minecraft:tuff
fill 285 262 254 291 263 254 minecraft:blackstone
fill 285 262 262 289 262 264 minecraft:blackstone
setblock 285 262 266 minecraft:tuff
fill 285 262 267 285 262 269 minecraft:blackstone
setblock 286 262 229 minecraft:tuff
fill 286 262 240 297 262 240 minecraft:basalt
fill 286 262 241 287 262 241 minecraft:blackstone
setblock 286 262 242 minecraft:tuff
fill 286 262 243 286 264 244 minecraft:blackstone
setblock 286 262 255 minecraft:tuff
fill 286 262 266 291 262 267 minecraft:blackstone
setblock 286 262 268 minecraft:tuff
fill 286 262 269 292 263 269 minecraft:blackstone
fill 287 262 229 298 262 229 minecraft:blackstone
setblock 287 262 231 minecraft:tuff
fill 287 262 232 287 262 234 minecraft:blackstone
setblock 287 262 244 minecraft:tuff
fill 287 262 246 287 262 248 minecraft:blackstone
fill 287 262 253 297 262 253 minecraft:blackstone
fill 287 262 255 298 262 255 minecraft:basalt
fill 287 262 256 292 262 256 minecraft:blackstone
setblock 287 262 257 minecraft:tuff
fill 287 262 258 287 264 259 minecraft:blackstone
setblock 288 262 233 minecraft:tuff
fill 288 262 234 294 263 234 minecraft:blackstone
fill 288 262 243 292 262 244 minecraft:blackstone
setblock 288 262 246 minecraft:tuff
fill 288 262 247 288 263 248 minecraft:blackstone
setblock 288 262 259 minecraft:tuff
fill 289 262 231 293 262 233 minecraft:blackstone
setblock 289 262 235 minecraft:tuff
fill 289 262 241 291 262 242 minecraft:blackstone
fill 289 262 246 294 262 247 minecraft:blackstone
setblock 289 262 248 minecraft:tuff
fill 289 262 257 293 262 259 minecraft:blackstone
setblock 289 262 261 minecraft:tuff
fill 290 262 235 301 262 235 minecraft:basalt
fill 290 262 236 291 262 236 minecraft:blackstone
setblock 290 262 237 minecraft:tuff
fill 290 262 248 297 262 248 minecraft:blackstone
setblock 290 262 250 minecraft:tuff
fill 290 262 261 290 262 262 minecraft:blackstone
setblock 290 262 263 minecraft:tuff
fill 290 262 264 296 263 264 minecraft:blackstone
fill 291 262 237 296 262 238 minecraft:blackstone
setblock 291 262 239 minecraft:tuff
fill 291 262 250 298 262 250 minecraft:basalt
fill 291 262 251 296 262 251 minecraft:blackstone
setblock 291 262 252 minecraft:tuff
fill 291 262 262 291 263 263 minecraft:blackstone
setblock 291 262 265 minecraft:tuff
fill 292 262 239 303 262 239 minecraft:blackstone
setblock 292 262 241 minecraft:tuff
fill 292 262 242 298 263 242 minecraft:blackstone
fill 292 262 252 303 262 252 minecraft:blackstone
setblock 292 262 254 minecraft:tuff
fill 292 262 261 301 262 261 minecraft:blackstone
fill 292 262 263 302 262 263 minecraft:blackstone
fill 292 262 265 303 262 265 minecraft:basalt
fill 292 262 266 297 262 266 minecraft:blackstone
setblock 292 262 267 minecraft:tuff
setblock 293 262 230 minecraft:tuff
fill 293 262 236 295 262 236 minecraft:blackstone
fill 293 262 241 304 262 241 minecraft:blackstone
setblock 293 262 243 minecraft:tuff
fill 293 262 244 299 263 244 minecraft:blackstone
fill 293 262 254 304 262 254 minecraft:blackstone
setblock 293 262 256 minecraft:tuff
fill 293 262 262 295 263 262 minecraft:blackstone
fill 293 262 267 304 262 267 minecraft:blackstone
setblock 293 262 269 minecraft:tuff
fill 294 262 230 305 262 230 minecraft:basalt
fill 294 262 231 299 262 231 minecraft:blackstone
setblock 294 262 232 minecraft:tuff
fill 294 262 233 296 264 233 minecraft:blackstone
fill 294 262 243 305 262 243 minecraft:blackstone
setblock 294 262 245 minecraft:tuff
fill 294 262 256 299 262 257 minecraft:blackstone
setblock 294 262 258 minecraft:tuff
fill 294 262 259 300 263 259 minecraft:blackstone
fill 294 262 268 298 262 269 minecraft:blackstone
fill 295 262 232 306 262 232 minecraft:blackstone
setblock 295 262 234 minecraft:tuff
fill 295 262 245 299 262 245 minecraft:basalt
fill 295 262 246 298 262 246 minecraft:blackstone
setblock 295 262 247 minecraft:tuff
fill 295 262 258 306 262 258 minecraft:blackstone
setblock 295 262 260 minecraft:tuff
fill 296 262 234 307 262 234 minecraft:blackstone
setblock 296 262 236 minecraft:tuff
fill 296 262 247 297 263 247 minecraft:blackstone
setblock 296 262 249 minecraft:tuff
fill 296 262 260 307 262 260 minecraft:basalt
setblock 296 262 262 minecraft:tuff
setblock 297 262 228 minecraft:crying_obsidian
fill 297 262 236 302 262 237 minecraft:blackstone
setblock 297 262 238 minecraft:tuff
fill 297 262 249 297 263 249 minecraft:blackstone
setblock 297 262 251 minecraft:tuff
fill 297 262 262 308 262 262 minecraft:blackstone
setblock 297 262 264 minecraft:tuff
fill 298 262 238 309 262 238 minecraft:blackstone
setblock 298 262 240 minecraft:tuff
fill 298 262 251 299 262 251 minecraft:blackstone
setblock 298 262 253 minecraft:tuff
fill 298 262 264 309 262 264 minecraft:blackstone
setblock 298 262 266 minecraft:tuff
setblock 299 262 229 minecraft:tuff
fill 299 262 233 300 264 233 minecraft:blackstone
fill 299 262 240 310 262 240 minecraft:basalt
setblock 299 262 242 minecraft:tuff
fill 299 262 253 310 262 253 minecraft:blackstone
setblock 299 262 255 minecraft:tuff
fill 299 262 266 310 262 266 minecraft:blackstone
setblock 299 262 268 minecraft:tuff
fill 299 262 269 305 263 269 minecraft:blackstone
fill 300 262 229 311 262 229 minecraft:blackstone
setblock 300 262 231 minecraft:tuff
fill 300 262 242 311 262 242 minecraft:blackstone
setblock 300 262 244 minecraft:tuff
fill 300 262 255 311 262 255 minecraft:basalt
fill 300 262 256 305 262 256 minecraft:blackstone
setblock 300 262 257 minecraft:tuff
fill 300 262 268 311 262 268 minecraft:blackstone
fill 301 262 231 312 262 231 minecraft:blackstone
setblock 301 262 233 minecraft:tuff
fill 301 262 244 312 262 244 minecraft:blackstone
fill 301 262 257 312 262 257 minecraft:blackstone
setblock 301 262 259 minecraft:tuff
fill 302 262 233 307 262 233 minecraft:blackstone
setblock 302 262 235 minecraft:tuff
fill 302 262 259 313 262 259 minecraft:blackstone
setblock 302 262 261 minecraft:tuff
fill 303 262 235 314 262 235 minecraft:basalt
fill 303 262 236 308 262 236 minecraft:blackstone
setblock 303 262 237 minecraft:tuff
fill 303 262 245 306 262 245 minecraft:basalt
fill 303 262 251 309 262 251 minecraft:blackstone
fill 303 262 261 314 262 261 minecraft:blackstone
setblock 303 262 263 minecraft:tuff
fill 303 262 270 303 283 270 minecraft:blackstone
fill 304 262 237 315 262 237 minecraft:blackstone
setblock 304 262 239 minecraft:tuff
fill 304 262 246 313 262 246 minecraft:blackstone
fill 304 262 250 315 262 250 minecraft:basalt
setblock 304 262 252 minecraft:tuff
fill 304 262 263 315 262 263 minecraft:blackstone
setblock 304 262 265 minecraft:tuff
fill 305 262 239 316 262 239 minecraft:blackstone
setblock 305 262 241 minecraft:tuff
fill 305 262 247 307 262 249 minecraft:blackstone
fill 305 262 252 316 262 252 minecraft:blackstone
setblock 305 262 254 minecraft:tuff
fill 305 262 265 316 262 265 minecraft:basalt
setblock 305 262 267 minecraft:tuff
setblock 306 262 230 minecraft:tuff
fill 306 262 241 317 262 241 minecraft:blackstone
setblock 306 262 243 minecraft:tuff
fill 306 262 254 317 262 254 minecraft:blackstone
setblock 306 262 256 minecraft:tuff
fill 306 262 267 317 262 267 minecraft:blackstone
setblock 306 262 269 minecraft:tuff
fill 307 262 230 318 262 230 minecraft:basalt
setblock 307 262 232 minecraft:tuff
fill 307 262 243 318 262 243 minecraft:blackstone
setblock 307 262 245 minecraft:tuff
fill 307 262 256 318 262 256 minecraft:blackstone
setblock 307 262 258 minecraft:tuff
fill 307 262 269 318 262 269 minecraft:blackstone
fill 308 262 232 319 262 232 minecraft:blackstone
setblock 308 262 234 minecraft:tuff
fill 308 262 245 319 262 245 minecraft:basalt
setblock 308 262 247 minecraft:tuff
fill 308 262 248 308 264 249 minecraft:blackstone
fill 308 262 258 319 262 258 minecraft:blackstone
setblock 308 262 260 minecraft:tuff
fill 309 262 233 313 262 234 minecraft:blackstone
setblock 309 262 236 minecraft:tuff
fill 309 262 247 314 262 248 minecraft:blackstone
setblock 309 262 249 minecraft:tuff
fill 309 262 260 320 262 260 minecraft:basalt
setblock 309 262 262 minecraft:tuff
fill 310 262 236 313 262 236 minecraft:blackstone
setblock 310 262 238 minecraft:tuff
fill 310 262 249 321 262 249 minecraft:blackstone
setblock 310 262 251 minecraft:tuff
fill 310 262 262 313 263 262 minecraft:blackstone
setblock 310 262 264 minecraft:tuff
fill 311 262 238 315 262 238 minecraft:blackstone
setblock 311 262 240 minecraft:tuff
fill 311 262 251 322 262 251 minecraft:blackstone
setblock 311 262 253 minecraft:tuff
fill 311 262 264 322 262 264 minecraft:blackstone
setblock 311 262 266 minecraft:tuff
setblock 312 262 229 minecraft:tuff
fill 312 262 240 323 262 240 minecraft:basalt
setblock 312 262 242 minecraft:tuff
fill 312 262 253 323 262 253 minecraft:blackstone
setblock 312 262 255 minecraft:tuff
fill 312 262 266 319 262 266 minecraft:blackstone
setblock 312 262 268 minecraft:tuff
fill 313 262 229 323 262 229 minecraft:blackstone
setblock 313 262 231 minecraft:tuff
fill 313 262 242 320 262 242 minecraft:blackstone
setblock 313 262 244 minecraft:tuff
fill 313 262 255 323 262 255 minecraft:basalt
setblock 313 262 257 minecraft:tuff
fill 313 262 268 320 262 268 minecraft:blackstone
fill 314 262 231 321 262 231 minecraft:blackstone
setblock 314 262 233 minecraft:tuff
fill 314 262 234 320 263 234 minecraft:blackstone
fill 314 262 244 323 262 244 minecraft:blackstone
setblock 314 262 246 minecraft:tuff
fill 314 262 257 321 262 257 minecraft:blackstone
setblock 314 262 259 minecraft:tuff
fill 315 262 233 322 262 233 minecraft:blackstone
setblock 315 262 235 minecraft:tuff
fill 315 262 246 320 262 247 minecraft:blackstone
setblock 315 262 248 minecraft:tuff
fill 315 262 259 323 262 259 minecraft:blackstone
setblock 315 262 261 minecraft:tuff
fill 316 262 235 323 262 235 minecraft:basalt
setblock 316 262 237 minecraft:tuff
fill 316 262 248 321 262 248 minecraft:blackstone
setblock 316 262 250 minecraft:tuff
fill 316 262 261 323 262 261 minecraft:blackstone
setblock 316 262 263 minecraft:tuff
fill 317 262 236 321 262 237 minecraft:blackstone
setblock 317 262 239 minecraft:tuff
fill 317 262 250 323 262 250 minecraft:basalt
setblock 317 262 252 minecraft:tuff
fill 317 262 262 321 262 263 minecraft:blackstone
setblock 317 262 265 minecraft:tuff
fill 318 262 238 322 262 239 minecraft:blackstone
setblock 318 262 241 minecraft:tuff
fill 318 262 252 323 262 252 minecraft:blackstone
setblock 318 262 254 minecraft:tuff
fill 318 262 265 323 262 265 minecraft:basalt
setblock 318 262 267 minecraft:tuff
fill 319 262 228 319 283 228 minecraft:blackstone
setblock 319 262 230 minecraft:tuff
fill 319 262 241 323 262 241 minecraft:blackstone
setblock 319 262 243 minecraft:tuff
fill 319 262 254 323 262 254 minecraft:blackstone
setblock 319 262 256 minecraft:tuff
fill 319 262 267 323 262 267 minecraft:blackstone
setblock 319 262 269 minecraft:tuff
fill 320 262 230 323 262 230 minecraft:basalt
setblock 320 262 232 minecraft:tuff
fill 320 262 243 323 264 243 minecraft:blackstone
setblock 320 262 245 minecraft:tuff
fill 320 262 256 324 262 256 minecraft:blackstone
setblock 320 262 258 minecraft:tuff
fill 320 262 269 323 264 269 minecraft:blackstone
fill 321 262 232 323 263 232 minecraft:blackstone
setblock 321 262 234 minecraft:tuff
fill 321 262 245 323 262 245 minecraft:basalt
fill 321 262 246 322 262 246 minecraft:blackstone
setblock 321 262 247 minecraft:tuff
fill 321 262 258 323 264 258 minecraft:blackstone
setblock 321 262 260 minecraft:tuff
fill 322 262 234 323 264 234 minecraft:blackstone
setblock 322 262 236 minecraft:tuff
fill 322 262 237 323 263 237 minecraft:blackstone
setblock 322 262 249 minecraft:tuff
fill 322 262 260 323 262 260 minecraft:basalt
setblock 322 262 262 minecraft:tuff
fill 322 262 263 323 264 263 minecraft:blackstone
setblock 323 262 236 minecraft:blackstone
setblock 323 262 238 minecraft:tuff
fill 323 262 239 323 265 239 minecraft:blackstone
fill 323 262 248 323 264 249 minecraft:blackstone
setblock 323 262 251 minecraft:tuff
fill 323 262 262 323 263 262 minecraft:blackstone
setblock 323 262 264 minecraft:tuff
fill 282 263 230 284 266 230 minecraft:blackstone
fill 282 263 257 287 263 257 minecraft:blackstone
fill 283 263 231 291 263 231 minecraft:basalt
fill 283 263 232 285 263 235 minecraft:blackstone
fill 283 263 236 287 263 236 minecraft:basalt
fill 283 263 237 288 263 238 minecraft:blackstone
setblock 283 263 239 minecraft:tuff
fill 283 263 240 289 264 240 minecraft:blackstone
setblock 283 263 241 minecraft:basalt
fill 283 263 242 284 263 245 minecraft:blackstone
fill 283 263 246 292 263 246 minecraft:basalt
fill 283 263 249 283 265 250 minecraft:blackstone
fill 283 263 251 288 263 251 minecraft:basalt
setblock 283 263 252 minecraft:tuff
fill 283 263 253 283 263 255 minecraft:blackstone
fill 283 263 256 284 263 256 minecraft:basalt
fill 283 263 258 285 263 260 minecraft:blackstone
fill 283 263 261 293 263 261 minecraft:basalt
setblock 283 263 262 minecraft:blackstone
setblock 283 263 265 minecraft:tuff
fill 283 263 266 289 263 266 minecraft:basalt
fill 283 263 267 283 263 269 minecraft:blackstone
setblock 284 263 241 minecraft:tuff
fill 284 263 247 286 263 247 minecraft:blackstone
fill 284 263 250 294 263 250 minecraft:blackstone
fill 284 263 252 285 263 253 minecraft:blackstone
setblock 284 263 254 minecraft:tuff
fill 284 263 255 290 264 255 minecraft:blackstone
fill 284 263 264 288 263 265 minecraft:blackstone
setblock 284 263 267 minecraft:tuff
fill 284 263 268 284 264 269 minecraft:blackstone
setblock 285 263 230 minecraft:tuff
fill 285 263 241 296 263 241 minecraft:basalt
fill 285 263 242 286 263 242 minecraft:blackstone
setblock 285 263 243 minecraft:tuff
fill 285 263 244 285 265 245 minecraft:blackstone
fill 285 263 249 287 264 249 minecraft:blackstone
setblock 285 263 256 minecraft:tuff
fill 285 263 262 287 263 263 minecraft:blackstone
fill 285 263 267 290 263 268 minecraft:blackstone
setblock 285 263 269 minecraft:tuff
fill 286 263 229 290 263 230 minecraft:blackstone
setblock 286 263 232 minecraft:tuff
fill 286 263 233 286 263 235 minecraft:blackstone
setblock 286 263 245 minecraft:tuff
fill 286 263 252 295 263 252 minecraft:blackstone
fill 286 263 256 297 263 256 minecraft:basalt
setblock 286 263 258 minecraft:tuff
fill 286 263 259 286 265 260 minecraft:blackstone
fill 287 263 232 292 263 233 minecraft:blackstone
setblock 287 263 234 minecraft:tuff
fill 287 263 235 293 264 235 minecraft:blackstone
fill 287 263 244 291 263 245 minecraft:blackstone
setblock 287 263 247 minecraft:tuff
fill 287 263 248 287 264 248 minecraft:blackstone
fill 287 263 253 289 264 253 minecraft:blackstone
setblock 287 263 260 minecraft:tuff
setblock 288 263 236 minecraft:tuff
fill 288 263 242 290 263 243 minecraft:blackstone
setblock 288 263 249 minecraft:tuff
fill 288 263 259 292 263 260 minecraft:blackstone
setblock 288 263 262 minecraft:tuff
fill 288 263 263 290 264 263 minecraft:blackstone
fill 289 263 236 300 263 236 minecraft:basalt
fill 289 263 237 294 263 237 minecraft:blackstone
setblock 289 263 238 minecraft:tuff
fill 289 263 247 293 263 249 minecraft:blackstone
setblock 289 263 251 minecraft:tuff
fill 289 263 257 291 263 258 minecraft:blackstone
fill 289 263 262 290 263 262 minecraft:blackstone
setblock 289 263 264 minecraft:tuff
fill 289 263 265 295 264 265 minecraft:blackstone
fill 290 263 238 301 263 238 minecraft:blackstone
setblock 290 263 240 minecraft:tuff
fill 290 263 251 299 263 251 minecraft:basalt
setblock 290 263 253 minecraft:tuff
setblock 290 263 266 minecraft:tuff
setblock 291 263 229 minecraft:tuff
fill 291 263 230 297 264 230 minecraft:blackstone
fill 291 263 239 295 263 240 minecraft:blackstone
setblock 291 263 242 minecraft:tuff
fill 291 263 243 297 264 243 minecraft:blackstone
fill 291 263 253 302 263 253 minecraft:blackstone
setblock 291 263 255 minecraft:tuff
fill 291 263 266 302 263 266 minecraft:basalt
fill 291 263 267 296 263 267 minecraft:blackstone
setblock 291 263 268 minecraft:tuff
fill 292 263 229 303 263 229 minecraft:blackstone
setblock 292 263 231 minecraft:tuff
setblock 292 263 244 minecraft:tuff
fill 292 263 245 298 263 245 minecraft:blackstone
fill 292 263 254 296 263 255 minecraft:blackstone
setblock 292 263 257 minecraft:tuff
fill 292 263 258 298 264 258 minecraft:blackstone
fill 292 263 263 294 264 263 minecraft:blackstone
fill 292 263 268 303 263 268 minecraft:blackstone
fill 293 263 231 304 263 231 minecraft:basalt
fill 293 263 232 298 263 232 minecraft:blackstone
setblock 293 263 233 minecraft:tuff
setblock 293 263 246 minecraft:tuff
fill 293 263 257 304 263 257 minecraft:blackstone
setblock 293 263 259 minecraft:tuff
fill 293 263 260 299 264 260 minecraft:blackstone
fill 293 263 269 297 264 269 minecraft:blackstone
setblock 294 263 235 minecraft:tuff
fill 294 263 246 298 263 246 minecraft:basalt
fill 294 263 247 295 263 247 minecraft:blackstone
setblock 294 263 248 minecraft:tuff
fill 294 263 249 296 264 249 minecraft:blackstone
setblock 294 263 261 minecraft:tuff
fill 295 263 234 299 263 235 minecraft:blackstone
setblock 295 263 237 minecraft:tuff
fill 295 263 248 297 263 248 minecraft:blackstone
setblock 295 263 250 minecraft:tuff
fill 295 263 261 306 263 261 minecraft:basalt
setblock 295 263 263 minecraft:tuff
fill 296 263 237 307 263 237 minecraft:blackstone
setblock 296 263 239 minecraft:tuff
fill 296 263 240 302 264 240 minecraft:blackstone
fill 296 263 250 298 263 250 minecraft:blackstone
setblock 296 263 252 minecraft:tuff
fill 296 263 262 300 263 263 minecraft:blackstone
setblock 296 263 265 minecraft:tuff
fill 297 263 228 297 283 228 minecraft:blackstone
fill 297 263 239 308 263 239 minecraft:blackstone
setblock 297 263 241 minecraft:tuff
fill 297 263 252 308 263 252 minecraft:blackstone
setblock 297 263 254 minecraft:tuff
fill 297 263 255 303 264 255 minecraft:blackstone
fill 297 263 264 301 263 265 minecraft:blackstone
setblock 297 263 267 minecraft:tuff
setblock 298 263 230 minecraft:tuff
fill 298 263 241 309 263 241 minecraft:basalt
setblock 298 263 243 minecraft:tuff
fill 298 263 254 309 263 254 minecraft:blackstone
setblock 298 263 256 minecraft:tuff
fill 298 263 267 309 263 267 minecraft:blackstone
setblock 298 263 269 minecraft:tuff
fill 299 263 230 310 263 230 minecraft:blackstone
setblock 299 263 232 minecraft:tuff
fill 299 263 242 303 263 243 minecraft:blackstone
setblock 299 263 245 minecraft:tuff
fill 299 263 256 310 263 256 minecraft:basalt
setblock 299 263 258 minecraft:tuff
fill 300 263 232 311 263 232 minecraft:blackstone
setblock 300 263 234 minecraft:tuff
fill 300 263 235 306 264 235 minecraft:blackstone
fill 300 263 244 304 263 244 minecraft:blackstone
fill 300 263 258 311 263 258 minecraft:blackstone
setblock 300 263 260 minecraft:tuff
fill 301 263 233 305 263 234 minecraft:blackstone
setblock 301 263 236 minecraft:tuff
fill 301 263 259 305 263 260 minecraft:blackstone
setblock 301 263 262 minecraft:tuff
fill 301 263 263 307 264 263 minecraft:blackstone
fill 302 263 236 313 263 236 minecraft:basalt
setblock 302 263 238 minecraft:tuff
fill 302 263 262 309 263 262 minecraft:blackstone
setblock 302 263 264 minecraft:tuff
fill 302 263 265 308 264 265 minecraft:blackstone
fill 303 263 238 314 263 238 minecraft:blackstone
setblock 303 263 240 minecraft:tuff
fill 303 263 245 311 263 245 minecraft:blackstone
fill 303 263 251 314 263 251 minecraft:basalt
setblock 303 263 253 minecraft:tuff
fill 303 263 264 314 263 264 minecraft:blackstone
setblock 303 263 266 minecraft:tuff
setblock 304 263 229 minecraft:tuff
fill 304 263 240 315 263 240 minecraft:blackstone
setblock 304 263 242 minecraft:tuff
fill 304 263 243 310 264 243 minecraft:blackstone
fill 304 263 246 305 263 246 minecraft:basalt
fill 304 263 250 307 263 250 minecraft:blackstone
fill 304 263 253 315 263 253 minecraft:blackstone
setblock 304 263 255 minecraft:tuff
fill 304 263 266 315 263 266 minecraft:basalt
setblock 304 263 268 minecraft:tuff
fill 305 263 229 316 263 229 minecraft:blackstone
setblock 305 263 231 minecraft:tuff
fill 305 263 242 316 263 242 minecraft:blackstone
setblock 305 263 244 minecraft:tuff
fill 305 263 247 306 263 249 minecraft:blackstone
fill 305 263 255 316 263 255 minecraft:blackstone
setblock 305 263 257 minecraft:tuff
fill 305 263 268 316 263 268 minecraft:blackstone
fill 306 263 231 317 263 231 minecraft:basalt
setblock 306 263 233 minecraft:tuff
fill 306 263 234 312 264 234 minecraft:blackstone
fill 306 263 244 317 263 244 minecraft:blackstone
setblock 306 263 246 minecraft:tuff
fill 306 263 257 317 263 257 minecraft:blackstone
setblock 306 263 259 minecraft:tuff
fill 306 263 260 312 264 260 minecraft:blackstone
fill 306 263 269 310 264 269 minecraft:blackstone
fill 307 263 233 307 264 233 minecraft:blackstone
setblock 307 263 235 minecraft:tuff
fill 307 263 246 318 263 246 minecraft:basalt
fill 307 263 247 312 263 247 minecraft:blackstone
setblock 307 263 248 minecraft:tuff
fill 307 263 249 307 265 249 minecraft:blackstone
fill 307 263 259 318 263 259 minecraft:blackstone
setblock 307 263 261 minecraft:tuff
fill 308 263 235 319 263 235 minecraft:blackstone
setblock 308 263 237 minecraft:tuff
setblock 308 263 250 minecraft:tuff
fill 308 263 261 319 263 261 minecraft:basalt
setblock 308 263 263 minecraft:tuff
fill 309 263 233 318 263 233 minecraft:blackstone
fill 309 263 237 320 263 237 minecraft:blackstone
setblock 309 263 239 minecraft:tuff
fill 309 263 248 313 263 250 minecraft:blackstone
setblock 309 263 252 minecraft:tuff
fill 309 263 263 320 263 263 minecraft:blackstone
setblock 309 263 265 minecraft:tuff
fill 310 263 239 321 263 239 minecraft:blackstone
setblock 310 263 241 minecraft:tuff
fill 310 263 252 321 263 252 minecraft:blackstone
setblock 310 263 254 minecraft:tuff
fill 310 263 265 321 263 265 minecraft:blackstone
setblock 310 263 267 minecraft:tuff
setblock 311 263 230 minecraft:tuff
fill 311 263 241 322 263 241 minecraft:basalt
setblock 311 263 243 minecraft:tuff
fill 311 263 254 322 263 254 minecraft:blackstone
setblock 311 263 256 minecraft:tuff
fill 311 263 267 322 263 267 minecraft:blackstone
setblock 311 263 269 minecraft:tuff
fill 312 263 230 323 263 230 minecraft:blackstone
setblock 312 263 232 minecraft:tuff
fill 312 263 243 319 263 243 minecraft:blackstone
setblock 312 263 245 minecraft:tuff
fill 312 263 256 323 263 256 minecraft:basalt
setblock 312 263 258 minecraft:tuff
fill 312 263 269 319 263 269 minecraft:blackstone
fill 313 263 232 320 263 232 minecraft:blackstone
setblock 313 263 234 minecraft:tuff
fill 313 263 245 323 263 245 minecraft:blackstone
setblock 313 263 247 minecraft:tuff
fill 313 263 258 320 263 258 minecraft:blackstone
setblock 313 263 260 minecraft:tuff
setblock 314 263 236 minecraft:tuff
fill 314 263 247 319 263 248 minecraft:blackstone
setblock 314 263 249 minecraft:tuff
fill 314 263 250 320 264 250 minecraft:blackstone
fill 314 263 260 323 263 260 minecraft:blackstone
setblock 314 263 262 minecraft:tuff
fill 315 263 236 323 263 236 minecraft:basalt
setblock 315 263 238 minecraft:tuff
fill 315 263 249 322 263 249 minecraft:blackstone
setblock 315 263 251 minecraft:tuff
fill 315 263 262 322 263 262 minecraft:blackstone
setblock 315 263 264 minecraft:tuff
setblock 316 263 240 minecraft:tuff
fill 316 263 251 323 263 251 minecraft:basalt
setblock 316 263 253 minecraft:tuff
fill 316 263 264 323 263 264 minecraft:blackstone
setblock 316 263 266 minecraft:tuff
setblock 317 263 229 minecraft:tuff
fill 317 263 240 323 263 240 minecraft:blackstone
setblock 317 263 242 minecraft:tuff
fill 317 263 253 323 263 253 minecraft:blackstone
setblock 317 263 255 minecraft:tuff
fill 317 263 266 323 263 266 minecraft:basalt
setblock 317 263 268 minecraft:tuff
fill 318 263 229 323 263 229 minecraft:blackstone
setblock 318 263 231 minecraft:tuff
fill 318 263 238 323 263 238 minecraft:blackstone
fill 318 263 242 320 263 242 minecraft:blackstone
setblock 318 263 244 minecraft:tuff
fill 318 263 255 323 263 255 minecraft:blackstone
setblock 318 263 257 minecraft:tuff
fill 318 263 268 320 264 268 minecraft:blackstone
fill 319 263 231 323 263 231 minecraft:basalt
setblock 319 263 233 minecraft:tuff
fill 319 263 244 323 263 244 minecraft:blackstone
setblock 319 263 246 minecraft:tuff
fill 319 263 257 321 263 257 minecraft:blackstone
setblock 319 263 259 minecraft:tuff
fill 320 263 233 322 264 233 minecraft:blackstone
setblock 320 263 235 minecraft:tuff
fill 320 263 246 323 263 246 minecraft:basalt
fill 320 263 247 321 263 247 minecraft:blackstone
setblock 320 263 248 minecraft:tuff
fill 320 263 259 323 265 259 minecraft:blackstone
setblock 320 263 261 minecraft:tuff
fill 321 263 234 321 265 235 minecraft:blackstone
setblock 321 263 237 minecraft:tuff
fill 321 263 248 321 264 248 minecraft:blackstone
setblock 321 263 250 minecraft:tuff
fill 321 263 261 323 263 261 minecraft:basalt
setblock 321 263 263 minecraft:tuff
fill 322 263 235 323 265 235 minecraft:blackstone
setblock 322 263 239 minecraft:tuff
fill 322 263 250 323 265 250 minecraft:blackstone
setblock 322 263 252 minecraft:tuff
setblock 322 263 265 minecraft:tuff
setblock 323 263 241 minecraft:tuff
setblock 323 263 247 minecraft:blackstone
setblock 323 263 252 minecraft:blackstone
setblock 323 263 254 minecraft:tuff
fill 323 263 265 323 266 265 minecraft:blackstone
setblock 323 263 267 minecraft:tuff
fill 324 263 256 324 283 256 minecraft:blackstone
fill 282 264 257 282 283 257 minecraft:blackstone
setblock 283 264 229 minecraft:tuff
fill 283 264 231 283 267 231 minecraft:blackstone
fill 283 264 232 290 264 232 minecraft:basalt
fill 283 264 233 284 264 236 minecraft:blackstone
fill 283 264 237 286 264 237 minecraft:basalt
fill 283 264 238 287 264 239 minecraft:blackstone
fill 283 264 241 288 265 241 minecraft:blackstone
setblock 283 264 242 minecraft:tuff
fill 283 264 243 283 264 246 minecraft:blackstone
fill 283 264 247 291 264 247 minecraft:basalt
setblock 283 264 248 minecraft:blackstone
fill 283 264 251 293 264 251 minecraft:blackstone
fill 283 264 252 287 264 252 minecraft:basalt
fill 283 264 253 285 264 254 minecraft:blackstone
setblock 283 264 255 minecraft:tuff
fill 283 264 256 289 265 256 minecraft:blackstone
setblock 283 264 257 minecraft:basalt
fill 283 264 258 284 264 261 minecraft:blackstone
fill 283 264 262 292 264 262 minecraft:basalt
fill 283 264 265 287 264 266 minecraft:blackstone
fill 283 264 267 288 264 267 minecraft:basalt
setblock 283 264 268 minecraft:tuff
fill 283 264 269 283 265 269 minecraft:blackstone
fill 284 264 229 295 264 229 minecraft:blackstone
setblock 284 264 231 minecraft:tuff
fill 284 264 242 295 264 242 minecraft:basalt
fill 284 264 243 285 264 243 minecraft:blackstone
setblock 284 264 244 minecraft:tuff
fill 284 264 245 284 266 246 minecraft:blackstone
fill 284 264 250 286 265 250 minecraft:blackstone
setblock 284 264 257 minecraft:tuff
fill 284 264 263 286 264 264 minecraft:blackstone
fill 285 264 230 289 264 231 minecraft:blackstone
setblock 285 264 233 minecraft:tuff
fill 285 264 234 285 264 236 minecraft:blackstone
setblock 285 264 246 minecraft:tuff
setblock 285 264 248 minecraft:blackstone
fill 285 264 257 296 264 257 minecraft:basalt
fill 285 264 258 286 264 258 minecraft:blackstone
setblock 285 264 259 minecraft:tuff
fill 285 264 260 285 266 261 minecraft:blackstone
fill 285 264 268 289 264 269 minecraft:blackstone
fill 286 264 233 291 264 234 minecraft:blackstone
setblock 286 264 235 minecraft:tuff
fill 286 264 236 292 265 236 minecraft:blackstone
fill 286 264 245 290 264 246 minecraft:blackstone
setblock 286 264 248 minecraft:tuff
fill 286 264 254 288 265 254 minecraft:blackstone
setblock 286 264 261 minecraft:tuff
setblock 287 264 237 minecraft:tuff
fill 287 264 243 289 264 244 minecraft:blackstone
setblock 287 264 250 minecraft:tuff
fill 287 264 260 291 264 261 minecraft:blackstone
setblock 287 264 263 minecraft:tuff
fill 287 264 264 293 265 264 minecraft:blackstone
fill 288 264 237 299 264 237 minecraft:basalt
fill 288 264 238 293 264 238 minecraft:blackstone
setblock 288 264 239 minecraft:tuff
fill 288 264 248 292 264 250 minecraft:blackstone
setblock 288 264 252 minecraft:tuff
fill 288 264 258 290 264 259 minecraft:blackstone
setblock 288 264 265 minecraft:tuff
fill 288 264 266 294 265 266 minecraft:blackstone
fill 289 264 239 300 264 239 minecraft:blackstone
setblock 289 264 241 minecraft:tuff
fill 289 264 252 298 264 252 minecraft:basalt
setblock 289 264 254 minecraft:tuff
setblock 289 264 267 minecraft:tuff
setblock 290 264 230 minecraft:tuff
fill 290 264 231 296 265 231 minecraft:blackstone
fill 290 264 240 294 264 241 minecraft:blackstone
setblock 290 264 243 minecraft:tuff
fill 290 264 244 296 265 244 minecraft:blackstone
fill 290 264 253 294 264 254 minecraft:blackstone
setblock 290 264 256 minecraft:tuff
fill 290 264 267 301 264 267 minecraft:basalt
fill 290 264 268 295 264 268 minecraft:blackstone
setblock 290 264 269 minecraft:tuff
setblock 291 264 232 minecraft:tuff
setblock 291 264 245 minecraft:tuff
fill 291 264 246 296 264 246 minecraft:blackstone
fill 291 264 255 295 264 256 minecraft:blackstone
setblock 291 264 258 minecraft:tuff
fill 291 264 259 297 265 259 minecraft:blackstone
setblock 291 264 263 minecraft:blackstone
fill 291 264 269 292 265 269 minecraft:blackstone
setblock 291 264 270 minecraft:magma_block
fill 292 264 232 303 264 232 minecraft:basalt
fill 292 264 233 293 264 233 minecraft:blackstone
setblock 292 264 234 minecraft:tuff
fill 292 264 245 297 264 245 minecraft:blackstone
setblock 292 264 247 minecraft:tuff
setblock 292 264 260 minecraft:tuff
fill 292 264 261 298 265 261 minecraft:blackstone
fill 293 264 234 304 264 234 minecraft:blackstone
setblock 293 264 236 minecraft:tuff
fill 293 264 247 296 264 247 minecraft:basalt
fill 293 264 248 296 264 248 minecraft:blackstone
setblock 293 264 249 minecraft:tuff
fill 293 264 250 296 264 250 minecraft:blackstone
setblock 293 264 262 minecraft:tuff
fill 294 264 235 298 264 236 minecraft:blackstone
setblock 294 264 238 minecraft:tuff
setblock 294 264 251 minecraft:tuff
fill 294 264 262 305 264 262 minecraft:basalt
setblock 294 264 264 minecraft:tuff
fill 295 264 238 306 264 238 minecraft:blackstone
setblock 295 264 240 minecraft:tuff
fill 295 264 241 301 265 241 minecraft:blackstone
fill 295 264 251 297 264 251 minecraft:blackstone
setblock 295 264 253 minecraft:tuff
fill 295 264 254 301 265 254 minecraft:blackstone
fill 295 264 263 299 264 264 minecraft:blackstone
setblock 295 264 266 minecraft:tuff
setblock 296 264 228 minecraft:magma_block
setblock 296 264 229 minecraft:tuff
setblock 296 264 242 minecraft:tuff
fill 296 264 253 307 264 253 minecraft:blackstone
setblock 296 264 255 minecraft:tuff
fill 296 264 256 302 265 256 minecraft:blackstone
fill 296 264 265 300 264 266 minecraft:blackstone
setblock 296 264 268 minecraft:tuff
fill 297 264 229 308 264 229 minecraft:blackstone
setblock 297 264 231 minecraft:tuff
setblock 297 264 233 minecraft:blackstone
fill 297 264 242 308 264 242 minecraft:basalt
setblock 297 264 244 minecraft:tuff
fill 297 264 246 297 264 250 minecraft:shroomlight
setblock 297 264 257 minecraft:tuff
fill 297 264 268 308 264 268 minecraft:blackstone
fill 298 264 230 302 264 231 minecraft:blackstone
setblock 298 264 233 minecraft:tuff
fill 298 264 243 298 264 244 minecraft:blackstone
fill 298 264 245 298 264 246 minecraft:shroomlight
fill 298 264 250 298 264 251 minecraft:shroomlight
fill 298 264 257 309 264 257 minecraft:basalt
setblock 298 264 259 minecraft:tuff
fill 298 264 269 302 265 269 minecraft:blackstone
setblock 299 264 235 minecraft:tuff
fill 299 264 236 305 265 236 minecraft:blackstone
fill 299 264 243 302 264 243 minecraft:blackstone
fill 299 264 244 299 264 245 minecraft:shroomlight
fill 299 264 251 299 264 252 minecraft:shroomlight
fill 299 264 258 303 264 259 minecraft:blackstone
setblock 299 264 261 minecraft:tuff
setblock 300 264 237 minecraft:tuff
fill 300 264 244 303 264 244 minecraft:shroomlight
fill 300 264 252 303 264 252 minecraft:shroomlight
fill 300 264 260 304 264 261 minecraft:blackstone
setblock 300 264 263 minecraft:tuff
fill 300 264 264 306 265 264 minecraft:blackstone
fill 301 264 233 306 264 233 minecraft:blackstone
fill 301 264 237 312 264 237 minecraft:basalt
setblock 301 264 239 minecraft:tuff
setblock 301 264 265 minecraft:tuff
fill 301 264 266 307 265 266 minecraft:blackstone
fill 302 264 239 313 264 239 minecraft:blackstone
setblock 302 264 241 minecraft:tuff
setblock 302 264 254 minecraft:tuff
setblock 302 264 267 minecraft:tuff
setblock 303 264 230 minecraft:tuff
fill 303 264 231 309 265 231 minecraft:blackstone
fill 303 264 240 307 264 241 minecraft:blackstone
setblock 303 264 243 minecraft:tuff
fill 303 264 245 304 264 245 minecraft:shroomlight
fill 303 264 251 304 264 251 minecraft:shroomlight
fill 303 264 254 314 264 254 minecraft:blackstone
setblock 303 264 256 minecraft:tuff
fill 303 264 267 314 264 267 minecraft:basalt
setblock 303 264 269 minecraft:tuff
fill 304 264 230 315 264 230 minecraft:blackstone
setblock 304 264 232 minecraft:tuff
fill 304 264 244 309 264 244 minecraft:blackstone
fill 304 264 246 305 264 246 minecraft:shroomlight
fill 304 264 250 305 264 250 minecraft:shroomlight
fill 304 264 252 313 264 252 minecraft:basalt
fill 304 264 255 308 264 256 minecraft:blackstone
setblock 304 264 258 minecraft:tuff
fill 304 264 259 310 265 259 minecraft:blackstone
fill 304 264 269 305 265 269 minecraft:blackstone
fill 305 264 232 316 264 232 minecraft:basalt
setblock 305 264 234 minecraft:tuff
fill 305 264 245 316 264 245 minecraft:blackstone
fill 305 264 247 305 264 249 minecraft:shroomlight
fill 305 264 251 306 264 251 minecraft:blackstone
fill 305 264 258 316 264 258 minecraft:blackstone
setblock 305 264 260 minecraft:tuff
fill 305 264 261 311 265 261 minecraft:blackstone
setblock 306 264 228 minecraft:shroomlight
setblock 306 264 236 minecraft:tuff
fill 306 264 246 310 264 246 minecraft:blackstone
fill 306 264 247 317 264 247 minecraft:basalt
fill 306 264 248 307 264 248 minecraft:blackstone
setblock 306 264 249 minecraft:tuff
fill 306 264 250 312 264 250 minecraft:blackstone
setblock 306 264 262 minecraft:tuff
fill 307 264 235 311 264 236 minecraft:blackstone
setblock 307 264 238 minecraft:tuff
setblock 307 264 251 minecraft:tuff
fill 307 264 262 318 264 262 minecraft:basalt
setblock 307 264 264 minecraft:tuff
fill 308 264 238 315 264 238 minecraft:blackstone
setblock 308 264 240 minecraft:tuff
fill 308 264 241 314 265 241 minecraft:blackstone
fill 308 264 251 319 264 251 minecraft:blackstone
setblock 308 264 253 minecraft:tuff
fill 308 264 263 312 264 264 minecraft:blackstone
setblock 308 264 266 minecraft:tuff
setblock 309 264 229 minecraft:tuff
fill 309 264 233 310 264 233 minecraft:blackstone
fill 309 264 240 320 264 240 minecraft:blackstone
setblock 309 264 242 minecraft:tuff
fill 309 264 248 311 264 249 minecraft:blackstone
fill 309 264 253 320 264 253 minecraft:blackstone
setblock 309 264 255 minecraft:tuff
fill 309 264 256 315 265 256 minecraft:blackstone
fill 309 264 265 313 264 266 minecraft:blackstone
setblock 309 264 268 minecraft:tuff
fill 310 264 229 321 264 229 minecraft:blackstone
setblock 310 264 231 minecraft:tuff
fill 310 264 242 321 264 242 minecraft:basalt
setblock 310 264 244 minecraft:tuff
fill 310 264 255 321 264 255 minecraft:blackstone
setblock 310 264 257 minecraft:tuff
fill 310 264 268 317 264 268 minecraft:blackstone
fill 311 264 231 322 264 231 minecraft:blackstone
setblock 311 264 233 minecraft:tuff
fill 311 264 243 315 264 244 minecraft:blackstone
setblock 311 264 246 minecraft:tuff
fill 311 264 257 322 264 257 minecraft:basalt
setblock 311 264 259 minecraft:tuff
fill 311 264 269 315 265 269 minecraft:blackstone
fill 312 264 233 319 264 233 minecraft:blackstone
setblock 312 264 235 minecraft:tuff
fill 312 264 236 318 265 236 minecraft:blackstone
fill 312 264 246 323 264 246 minecraft:blackstone
setblock 312 264 248 minecraft:tuff
fill 312 264 249 318 265 249 minecraft:blackstone
fill 312 264 259 319 264 259 minecraft:blackstone
setblock 312 264 261 minecraft:tuff
fill 313 264 234 317 264 235 minecraft:blackstone
setblock 313 264 237 minecraft:tuff
fill 313 264 248 320 264 248 minecraft:blackstone
setblock 313 264 250 minecraft:tuff
fill 313 264 260 317 264 261 minecraft:blackstone
setblock 313 264 263 minecraft:tuff
fill 313 264 264 319 265 264 minecraft:blackstone
fill 314 264 237 323 264 237 minecraft:basalt
setblock 314 264 239 minecraft:tuff
setblock 314 264 252 minecraft:tuff
fill 314 264 263 321 264 263 minecraft:blackstone
setblock 314 264 265 minecraft:tuff
fill 314 264 266 320 265 266 minecraft:blackstone
fill 315 264 239 322 264 239 minecraft:blackstone
setblock 315 264 241 minecraft:tuff
fill 315 264 252 323 264 252 minecraft:basalt
setblock 315 264 254 minecraft:tuff
fill 315 264 265 322 264 265 minecraft:blackstone
setblock 315 264 267 minecraft:tuff
setblock 316 264 230 minecraft:tuff
fill 316 264 241 323 264 241 minecraft:blackstone
setblock 316 264 243 minecraft:tuff
fill 316 264 244 322 265 244 minecraft:blackstone
fill 316 264 254 323 264 254 minecraft:blackstone
setblock 316 264 256 minecraft:tuff
fill 316 264 267 323 264 267 minecraft:basalt
setblock 316 264 269 minecraft:tuff
fill 317 264 230 323 264 230 minecraft:blackstone
setblock 317 264 232 minecraft:tuff
fill 317 264 243 319 264 243 minecraft:blackstone
setblock 317 264 245 minecraft:tuff
fill 317 264 256 323 264 256 minecraft:blackstone
setblock 317 264 258 minecraft:tuff
fill 317 264 269 319 265 269 minecraft:blackstone
fill 318 264 232 323 264 232 minecraft:basalt
setblock 318 264 234 minecraft:tuff
fill 318 264 235 320 266 235 minecraft:blackstone
fill 318 264 238 319 264 238 minecraft:blackstone
fill 318 264 245 323 264 245 minecraft:blackstone
setblock 318 264 247 minecraft:tuff
fill 318 264 258 320 264 258 minecraft:blackstone
setblock 318 264 260 minecraft:tuff
fill 318 264 261 323 265 261 minecraft:blackstone
fill 319 264 234 320 265 234 minecraft:blackstone
setblock 319 264 236 minecraft:tuff
fill 319 264 247 323 264 247 minecraft:basalt
setblock 319 264 249 minecraft:tuff
fill 319 264 260 323 264 260 minecraft:blackstone
setblock 319 264 262 minecraft:tuff
setblock 320 264 228 minecraft:shroomlight
fill 320 264 236 323 266 236 minecraft:blackstone
setblock 320 264 238 minecraft:tuff
fill 320 264 249 322 265 249 minecraft:blackstone
setblock 320 264 251 minecraft:tuff
fill 320 264 262 323 264 262 minecraft:basalt
setblock 320 264 264 minecraft:tuff
fill 321 264 238 323 264 238 minecraft:blackstone
setblock 321 264 240 minecraft:tuff
fill 321 264 250 321 266 251 minecraft:blackstone
setblock 321 264 253 minecraft:tuff
fill 321 264 264 323 265 264 minecraft:blackstone
setblock 321 264 266 minecraft:tuff
setblock 321 264 268 minecraft:blackstone
setblock 322 264 229 minecraft:tuff
fill 322 264 240 323 266 240 minecraft:blackstone
setblock 322 264 242 minecraft:tuff
setblock 322 264 248 minecraft:blackstone
fill 322 264 251 323 266 251 minecraft:blackstone
fill 322 264 253 323 264 253 minecraft:blackstone
setblock 322 264 255 minecraft:tuff
fill 322 264 266 323 266 266 minecraft:blackstone
setblock 322 264 268 minecraft:tuff
fill 323 264 229 323 265 229 minecraft:blackstone
setblock 323 264 231 minecraft:tuff
setblock 323 264 242 minecraft:basalt
setblock 323 264 244 minecraft:tuff
fill 323 264 255 323 266 255 minecraft:blackstone
setblock 323 264 257 minecraft:tuff
setblock 323 264 268 minecraft:blackstone
setblock 324 264 247 minecraft:magma_block
fill 283 265 229 287 265 229 minecraft:blackstone
setblock 283 265 232 minecraft:tuff
fill 283 265 233 289 265 233 minecraft:basalt
fill 283 265 234 283 265 237 minecraft:blackstone
fill 283 265 238 285 265 238 minecraft:basalt
fill 283 265 239 286 265 240 minecraft:blackstone
fill 283 265 242 287 266 242 minecraft:blackstone
fill 283 265 243 294 265 243 minecraft:basalt
fill 283 265 244 284 265 244 minecraft:blackstone
setblock 283 265 245 minecraft:tuff
fill 283 265 246 283 267 247 minecraft:blackstone
fill 283 265 248 290 265 248 minecraft:basalt
fill 283 265 251 285 265 252 minecraft:blackstone
fill 283 265 253 286 265 253 minecraft:basalt
fill 283 265 254 285 265 255 minecraft:blackstone
fill 283 265 257 288 266 257 minecraft:blackstone
setblock 283 265 258 minecraft:tuff
fill 283 265 259 283 265 262 minecraft:blackstone
fill 283 265 263 291 265 263 minecraft:basalt
fill 283 265 264 285 265 267 minecraft:blackstone
fill 283 265 268 287 265 268 minecraft:basalt
fill 284 265 231 288 265 232 minecraft:blackstone
setblock 284 265 234 minecraft:tuff
fill 284 265 235 284 265 237 minecraft:blackstone
setblock 284 265 247 minecraft:tuff
setblock 284 265 249 minecraft:blackstone
fill 284 265 258 295 265 258 minecraft:basalt
fill 284 265 259 285 265 259 minecraft:blackstone
setblock 284 265 260 minecraft:tuff
fill 284 265 261 284 267 262 minecraft:blackstone
fill 284 265 269 290 265 269 minecraft:blackstone
fill 285 265 230 294 265 230 minecraft:blackstone
fill 285 265 234 290 265 235 minecraft:blackstone
setblock 285 265 236 minecraft:tuff
fill 285 265 237 291 266 237 minecraft:blackstone
fill 285 265 246 289 265 247 minecraft:blackstone
setblock 285 265 249 minecraft:tuff
setblock 285 265 262 minecraft:tuff
setblock 286 265 238 minecraft:tuff
fill 286 265 244 288 265 245 minecraft:blackstone
fill 286 265 249 295 265 249 minecraft:blackstone
setblock 286 265 251 minecraft:tuff
fill 286 265 252 292 266 252 minecraft:blackstone
fill 286 265 255 287 266 255 minecraft:blackstone
fill 286 265 261 290 265 262 minecraft:blackstone
setblock 286 265 264 minecraft:tuff
fill 286 265 265 286 265 267 minecraft:blackstone
fill 287 265 238 298 265 238 minecraft:basalt
fill 287 265 239 292 265 239 minecraft:blackstone
setblock 287 265 240 minecraft:tuff
fill 287 265 250 291 265 251 minecraft:blackstone
setblock 287 265 253 minecraft:tuff
fill 287 265 259 289 265 260 minecraft:blackstone
fill 287 265 265 292 266 265 minecraft:blackstone
setblock 287 265 266 minecraft:tuff
fill 287 265 267 293 266 267 minecraft:blackstone
setblock 288 265 229 minecraft:tuff
fill 288 265 240 299 265 240 minecraft:blackstone
setblock 288 265 242 minecraft:tuff
fill 288 265 253 298 265 253 minecraft:basalt
setblock 288 265 255 minecraft:tuff
setblock 288 265 268 minecraft:tuff
fill 289 265 229 300 265 229 minecraft:blackstone
setblock 289 265 231 minecraft:tuff
fill 289 265 232 295 266 232 minecraft:blackstone
fill 289 265 241 293 265 242 minecraft:blackstone
setblock 289 265 244 minecraft:tuff
fill 289 265 245 295 266 245 minecraft:blackstone
fill 289 265 254 293 265 255 minecraft:blackstone
setblock 289 265 257 minecraft:tuff
fill 289 265 268 300 265 268 minecraft:basalt
setblock 290 265 233 minecraft:tuff
setblock 290 265 246 minecraft:tuff
fill 290 265 247 295 265 247 minecraft:blackstone
fill 290 265 256 294 265 257 minecraft:blackstone
setblock 290 265 259 minecraft:tuff
fill 290 265 260 296 266 260 minecraft:blackstone
fill 291 265 233 302 265 233 minecraft:basalt
fill 291 265 234 296 265 234 minecraft:blackstone
setblock 291 265 235 minecraft:tuff
fill 291 265 246 295 265 246 minecraft:blackstone
setblock 291 265 248 minecraft:tuff
setblock 291 265 261 minecraft:tuff
fill 291 265 262 297 266 262 minecraft:blackstone
fill 291 265 270 291 283 270 minecraft:blackstone
fill 292 265 235 303 265 235 minecraft:blackstone
setblock 292 265 237 minecraft:tuff
fill 292 265 248 295 265 248 minecraft:basalt
setblock 292 265 250 minecraft:tuff
fill 292 265 251 296 265 251 minecraft:blackstone
setblock 292 265 263 minecraft:tuff
fill 293 265 236 297 265 237 minecraft:blackstone
setblock 293 265 239 minecraft:tuff
fill 293 265 250 295 266 250 minecraft:blackstone
setblock 293 265 252 minecraft:tuff
fill 293 265 263 304 265 263 minecraft:basalt
setblock 293 265 265 minecraft:tuff
fill 293 265 269 294 265 269 minecraft:blackstone
fill 294 265 239 305 265 239 minecraft:blackstone
setblock 294 265 241 minecraft:tuff
fill 294 265 242 300 265 242 minecraft:blackstone
fill 294 265 252 297 265 252 minecraft:blackstone
setblock 294 265 254 minecraft:tuff
fill 294 265 255 300 266 255 minecraft:blackstone
fill 294 265 264 298 265 265 minecraft:blackstone
setblock 294 265 267 minecraft:tuff
setblock 295 265 230 minecraft:tuff
setblock 295 265 243 minecraft:tuff
setblock 295 265 256 minecraft:tuff
fill 295 265 257 301 266 257 minecraft:blackstone
fill 295 265 266 299 265 267 minecraft:blackstone
setblock 295 265 269 minecraft:tuff
fill 296 265 228 296 283 228 minecraft:blackstone
fill 296 265 230 307 265 230 minecraft:blackstone
setblock 296 265 232 minecraft:tuff
fill 296 265 243 298 265 243 minecraft:basalt
setblock 296 265 245 minecraft:tuff
fill 296 265 246 296 266 246 minecraft:netherrack
setblock 296 265 247 minecraft:shroomlight
setblock 296 265 248 minecraft:netherrack
setblock 296 265 249 minecraft:shroomlight
fill 296 265 250 296 266 250 minecraft:netherrack
setblock 296 265 258 minecraft:tuff
fill 296 265 269 297 265 269 minecraft:blackstone
fill 297 265 231 301 265 232 minecraft:blackstone
setblock 297 265 234 minecraft:tuff
setblock 297 265 244 minecraft:blackstone
setblock 297 265 245 minecraft:shroomlight
setblock 297 265 251 minecraft:shroomlight
fill 297 265 258 308 265 258 minecraft:basalt
setblock 297 265 260 minecraft:tuff
fill 298 265 234 309 265 234 minecraft:blackstone
setblock 298 265 236 minecraft:tuff
fill 298 265 237 304 266 237 minecraft:blackstone
setblock 298 265 244 minecraft:netherrack
setblock 298 265 252 minecraft:netherrack
fill 298 265 259 302 265 260 minecraft:blackstone
setblock 298 265 262 minecraft:tuff
setblock 299 265 238 minecraft:tuff
fill 299 265 243 300 265 243 minecraft:netherrack
fill 299 265 253 300 265 253 minecraft:netherrack
fill 299 265 261 303 265 262 minecraft:blackstone
setblock 299 265 264 minecraft:tuff
fill 299 265 265 305 266 265 minecraft:blackstone
fill 300 265 238 311 265 238 minecraft:basalt
setblock 300 265 240 minecraft:tuff
setblock 300 265 266 minecraft:tuff
fill 300 265 267 306 266 267 minecraft:blackstone
setblock 301 265 229 minecraft:tuff
fill 301 265 240 312 265 240 minecraft:blackstone
setblock 301 265 242 minecraft:tuff
setblock 301 265 243 minecraft:shroomlight
setblock 301 265 253 minecraft:shroomlight
setblock 301 265 255 minecraft:tuff
setblock 301 265 268 minecraft:tuff
fill 302 265 229 313 265 229 minecraft:blackstone
setblock 302 265 231 minecraft:tuff
fill 302 265 232 308 266 232 minecraft:blackstone
fill 302 265 241 306 265 242 minecraft:blackstone
fill 302 265 243 303 265 243 minecraft:netherrack
fill 302 265 253 303 265 253 minecraft:netherrack
fill 302 265 254 306 265 255 minecraft:blackstone
setblock 302 265 257 minecraft:tuff
fill 302 265 268 313 265 268 minecraft:basalt
setblock 303 265 233 minecraft:tuff
fill 303 265 256 307 265 257 minecraft:blackstone
setblock 303 265 259 minecraft:tuff
fill 303 265 260 309 266 260 minecraft:blackstone
setblock 303 265 269 minecraft:blackstone
fill 304 265 233 315 265 233 minecraft:basalt
setblock 304 265 235 minecraft:tuff
fill 304 265 243 307 265 243 minecraft:basalt
setblock 304 265 244 minecraft:netherrack
setblock 304 265 252 minecraft:netherrack
fill 304 265 253 312 265 253 minecraft:basalt
setblock 304 265 261 minecraft:tuff
fill 304 265 262 310 266 262 minecraft:blackstone
fill 305 265 235 316 265 235 minecraft:blackstone
setblock 305 265 237 minecraft:tuff
fill 305 265 244 314 265 244 minecraft:blackstone
setblock 305 265 245 minecraft:shroomlight
setblock 305 265 251 minecraft:shroomlight
setblock 305 265 252 minecraft:blackstone
setblock 305 265 263 minecraft:tuff
fill 306 265 228 306 279 228 minecraft:blackstone
fill 306 265 236 310 265 237 minecraft:blackstone
setblock 306 265 239 minecraft:tuff
fill 306 265 245 308 265 245 minecraft:blackstone
fill 306 265 246 306 266 246 minecraft:netherrack
setblock 306 265 247 minecraft:shroomlight
setblock 306 265 248 minecraft:netherrack
setblock 306 265 249 minecraft:shroomlight
fill 306 265 250 306 266 250 minecraft:netherrack
fill 306 265 251 311 265 251 minecraft:blackstone
setblock 306 265 252 minecraft:tuff
fill 306 265 263 317 265 263 minecraft:basalt
setblock 306 265 265 minecraft:tuff
fill 306 265 269 307 265 269 minecraft:blackstone
fill 307 265 239 318 265 239 minecraft:blackstone
setblock 307 265 241 minecraft:tuff
fill 307 265 242 313 266 242 minecraft:blackstone
fill 307 265 246 309 265 247 minecraft:blackstone
fill 307 265 248 316 265 248 minecraft:basalt
fill 307 265 250 317 265 250 minecraft:blackstone
fill 307 265 252 318 265 252 minecraft:blackstone
setblock 307 265 254 minecraft:tuff
fill 307 265 255 313 266 255 minecraft:blackstone
fill 307 265 264 311 265 265 minecraft:blackstone
setblock 307 265 267 minecraft:tuff
setblock 308 265 228 minecraft:magma_block
setblock 308 265 230 minecraft:tuff
setblock 308 265 243 minecraft:tuff
fill 308 265 249 310 265 249 minecraft:blackstone
fill 308 265 254 319 265 254 minecraft:blackstone
setblock 308 265 256 minecraft:tuff
fill 308 265 257 314 266 257 minecraft:blackstone
fill 308 265 266 312 265 267 minecraft:blackstone
setblock 308 265 269 minecraft:tuff
fill 309 265 230 320 265 230 minecraft:blackstone
setblock 309 265 232 minecraft:tuff
fill 309 265 243 320 265 243 minecraft:basalt
setblock 309 265 245 minecraft:tuff
setblock 309 265 258 minecraft:tuff
fill 309 265 269 310 265 269 minecraft:blackstone
fill 310 265 231 314 265 232 minecraft:blackstone
setblock 310 265 234 minecraft:tuff
fill 310 265 245 315 265 246 minecraft:blackstone
setblock 310 265 247 minecraft:tuff
fill 310 265 258 321 265 258 minecraft:basalt
setblock 310 265 260 minecraft:tuff
fill 311 265 234 318 265 234 minecraft:blackstone
setblock 311 265 236 minecraft:tuff
fill 311 265 237 317 266 237 minecraft:blackstone
fill 311 265 247 322 265 247 minecraft:blackstone
setblock 311 265 249 minecraft:tuff
fill 311 265 259 315 265 260 minecraft:blackstone
setblock 311 265 262 minecraft:tuff
setblock 312 265 238 minecraft:tuff
setblock 312 265 251 minecraft:tuff
fill 312 265 261 316 265 262 minecraft:blackstone
setblock 312 265 264 minecraft:tuff
fill 312 265 265 318 266 265 minecraft:blackstone
fill 313 265 238 323 265 238 minecraft:basalt
setblock 313 265 240 minecraft:tuff
fill 313 265 251 320 265 251 minecraft:blackstone
setblock 313 265 253 minecraft:tuff
setblock 313 265 266 minecraft:tuff
fill 313 265 267 319 266 267 minecraft:blackstone
setblock 314 265 229 minecraft:tuff
fill 314 265 240 321 265 240 minecraft:blackstone
setblock 314 265 242 minecraft:tuff
fill 314 265 253 323 265 253 minecraft:basalt
setblock 314 265 255 minecraft:tuff
setblock 314 265 268 minecraft:tuff
fill 315 265 229 322 265 229 minecraft:blackstone
setblock 315 265 231 minecraft:tuff
fill 315 265 232 321 266 232 minecraft:blackstone
fill 315 265 241 319 265 242 minecraft:blackstone
setblock 315 265 244 minecraft:tuff
fill 315 265 255 322 265 255 minecraft:blackstone
setblock 315 265 257 minecraft:tuff
fill 315 265 268 323 265 268 minecraft:basalt
fill 316 265 231 323 265 231 minecraft:blackstone
setblock 316 265 233 minecraft:tuff
fill 316 265 245 321 266 245 minecraft:blackstone
setblock 316 265 246 minecraft:tuff
fill 316 265 256 320 265 257 minecraft:blackstone
setblock 316 265 259 minecraft:tuff
fill 316 265 260 322 266 260 minecraft:blackstone
setblock 316 265 269 minecraft:blackstone
fill 317 265 233 323 265 233 minecraft:basalt
setblock 317 265 235 minecraft:tuff
fill 317 265 246 323 265 246 minecraft:blackstone
setblock 317 265 248 minecraft:tuff
fill 317 265 259 319 265 259 minecraft:blackstone
setblock 317 265 261 minecraft:tuff
fill 317 265 262 323 266 262 minecraft:blackstone
setblock 318 265 237 minecraft:tuff
fill 318 265 248 323 265 248 minecraft:basalt
setblock 318 265 250 minecraft:tuff
setblock 318 265 263 minecraft:tuff
fill 319 265 236 319 267 237 minecraft:blackstone
setblock 319 265 239 minecraft:tuff
fill 319 265 249 319 265 250 minecraft:blackstone
setblock 319 265 252 minecraft:tuff
fill 319 265 263 323 265 263 minecraft:basalt
setblock 319 265 265 minecraft:tuff
fill 320 265 228 320 283 228 minecraft:blackstone
fill 320 265 237 323 265 237 minecraft:blackstone
fill 320 265 239 322 265 239 minecraft:blackstone
setblock 320 265 241 minecraft:tuff
fill 320 265 242 323 268 242 minecraft:blackstone
fill 320 265 250 320 266 250 minecraft:blackstone
fill 320 265 252 323 267 252 minecraft:blackstone
setblock 320 265 254 minecraft:tuff
fill 320 265 264 320 265 265 minecraft:blackstone
setblock 320 265 267 minecraft:tuff
setblock 320 265 269 minecraft:blackstone
setblock 321 265 230 minecraft:tuff
fill 321 265 241 323 267 241 minecraft:blackstone
setblock 321 265 243 minecraft:tuff
fill 321 265 254 323 265 254 minecraft:blackstone
setblock 321 265 256 minecraft:tuff
fill 321 265 257 323 268 257 minecraft:blackstone
fill 321 265 265 321 266 267 minecraft:blackstone
setblock 321 265 269 minecraft:tuff
fill 322 265 230 323 266 230 minecraft:blackstone
setblock 322 265 232 minecraft:tuff
setblock 322 265 234 minecraft:blackstone
fill 322 265 243 323 265 243 minecraft:basalt
setblock 322 265 245 minecraft:tuff
fill 322 265 256 323 267 256 minecraft:blackstone
setblock 322 265 258 minecraft:tuff
fill 322 265 265 322 266 265 minecraft:blackstone
fill 322 265 267 323 267 267 minecraft:blackstone
fill 322 265 269 323 265 269 minecraft:blackstone
fill 323 265 232 323 268 232 minecraft:blackstone
setblock 323 265 234 minecraft:tuff
fill 323 265 244 323 265 245 minecraft:blackstone
setblock 323 265 247 minecraft:tuff
setblock 323 265 249 minecraft:blackstone
setblock 323 265 258 minecraft:basalt
setblock 323 265 260 minecraft:tuff
fill 324 265 247 324 283 247 minecraft:blackstone
setblock 324 265 250 minecraft:magma_block
fill 324 265 251 324 283 251 minecraft:blackstone
setblock 282 266 240 minecraft:crying_obsidian
fill 283 266 229 292 266 229 minecraft:basalt
fill 283 266 232 287 266 233 minecraft:blackstone
fill 283 266 234 288 266 234 minecraft:basalt
setblock 283 266 235 minecraft:tuff
fill 283 266 236 283 266 238 minecraft:blackstone
fill 283 266 239 284 266 239 minecraft:basalt
fill 283 266 240 285 266 241 minecraft:blackstone
fill 283 266 243 286 267 243 minecraft:blackstone
fill 283 266 244 293 266 244 minecraft:basalt
setblock 283 266 245 minecraft:blackstone
setblock 283 266 248 minecraft:tuff
fill 283 266 249 289 266 249 minecraft:basalt
fill 283 266 250 283 266 253 minecraft:blackstone
fill 283 266 254 285 266 254 minecraft:basalt
fill 283 266 255 285 266 256 minecraft:blackstone
fill 283 266 258 287 267 258 minecraft:blackstone
fill 283 266 259 294 266 259 minecraft:basalt
fill 283 266 260 284 266 260 minecraft:blackstone
setblock 283 266 261 minecraft:tuff
fill 283 266 262 283 268 263 minecraft:blackstone
fill 283 266 264 290 266 264 minecraft:basalt
fill 283 266 265 284 266 268 minecraft:blackstone
fill 283 266 269 286 266 269 minecraft:basalt
fill 284 266 231 293 266 231 minecraft:blackstone
fill 284 266 235 289 266 236 minecraft:blackstone
setblock 284 266 237 minecraft:tuff
fill 284 266 238 290 267 238 minecraft:blackstone
fill 284 266 247 288 266 248 minecraft:blackstone
setblock 284 266 250 minecraft:tuff
fill 284 266 251 284 266 253 minecraft:blackstone
setblock 284 266 263 minecraft:tuff
fill 285 266 230 286 266 230 minecraft:blackstone
setblock 285 266 239 minecraft:tuff
fill 285 266 245 287 266 246 minecraft:blackstone
fill 285 266 250 290 266 251 minecraft:blackstone
setblock 285 266 252 minecraft:tuff
fill 285 266 253 291 267 253 minecraft:blackstone
fill 285 266 262 289 266 263 minecraft:blackstone
setblock 285 266 265 minecraft:tuff
fill 285 266 266 285 266 268 minecraft:blackstone
fill 286 266 239 297 266 239 minecraft:basalt
fill 286 266 240 291 266 240 minecraft:blackstone
setblock 286 266 241 minecraft:tuff
setblock 286 266 254 minecraft:tuff
fill 286 266 256 286 267 256 minecraft:blackstone
fill 286 266 260 288 266 261 minecraft:blackstone
fill 286 266 265 286 266 266 minecraft:blackstone
setblock 286 266 267 minecraft:tuff
fill 286 266 268 292 267 268 minecraft:blackstone
setblock 287 266 230 minecraft:tuff
fill 287 266 241 298 266 241 minecraft:blackstone
setblock 287 266 243 minecraft:tuff
fill 287 266 254 298 266 254 minecraft:basalt
setblock 287 266 256 minecraft:tuff
fill 287 266 266 291 267 266 minecraft:blackstone
setblock 287 266 269 minecraft:tuff
fill 288 266 230 299 266 230 minecraft:blackstone
setblock 288 266 232 minecraft:tuff
fill 288 266 233 294 267 233 minecraft:blackstone
fill 288 266 242 292 266 243 minecraft:blackstone
setblock 288 266 245 minecraft:tuff
fill 288 266 246 294 267 246 minecraft:blackstone
fill 288 266 255 292 266 256 minecraft:blackstone
setblock 288 266 258 minecraft:tuff
fill 288 266 269 299 266 269 minecraft:basalt
setblock 289 266 234 minecraft:tuff
setblock 289 266 247 minecraft:tuff
fill 289 266 248 294 267 248 minecraft:blackstone
fill 289 266 257 293 266 258 minecraft:blackstone
setblock 289 266 260 minecraft:tuff
fill 289 266 261 295 267 261 minecraft:blackstone
fill 290 266 234 301 266 234 minecraft:basalt
fill 290 266 235 295 266 235 minecraft:blackstone
setblock 290 266 236 minecraft:tuff
fill 290 266 247 294 266 247 minecraft:blackstone
setblock 290 266 249 minecraft:tuff
setblock 290 266 262 minecraft:tuff
fill 290 266 263 296 267 263 minecraft:blackstone
fill 291 266 228 291 283 228 minecraft:blackstone
fill 291 266 236 302 266 236 minecraft:blackstone
setblock 291 266 238 minecraft:tuff
fill 291 266 249 294 266 249 minecraft:basalt
fill 291 266 250 292 266 250 minecraft:blackstone
setblock 291 266 251 minecraft:tuff
setblock 291 266 264 minecraft:tuff
setblock 292 266 228 minecraft:magma_block
fill 292 266 237 296 266 238 minecraft:blackstone
setblock 292 266 240 minecraft:tuff
fill 292 266 251 295 266 251 minecraft:blackstone
setblock 292 266 253 minecraft:tuff
fill 292 266 264 303 266 264 minecraft:basalt
setblock 292 266 266 minecraft:tuff
setblock 293 266 229 minecraft:tuff
fill 293 266 240 304 266 240 minecraft:blackstone
setblock 293 266 242 minecraft:tuff
fill 293 266 243 297 266 243 minecraft:blackstone
fill 293 266 252 296 266 253 minecraft:blackstone
setblock 293 266 255 minecraft:tuff
fill 293 266 256 299 267 256 minecraft:blackstone
fill 293 266 265 297 266 266 minecraft:blackstone
setblock 293 266 268 minecraft:tuff
fill 294 266 229 305 266 229 minecraft:basalt
setblock 294 266 231 minecraft:tuff
fill 294 266 242 299 266 242 minecraft:blackstone
setblock 294 266 244 minecraft:tuff
setblock 294 266 257 minecraft:tuff
fill 294 266 258 300 267 258 minecraft:blackstone
fill 294 266 267 298 266 268 minecraft:blackstone
fill 295 266 231 306 266 231 minecraft:blackstone
setblock 295 266 233 minecraft:tuff
fill 295 266 244 296 266 244 minecraft:basalt
setblock 295 266 246 minecraft:tuff
fill 295 266 247 295 267 249 minecraft:netherrack
setblock 295 266 259 minecraft:tuff
fill 296 266 232 300 266 233 minecraft:blackstone
setblock 296 266 235 minecraft:tuff
setblock 296 266 245 minecraft:netherrack
setblock 296 266 251 minecraft:netherrack
fill 296 266 259 307 266 259 minecraft:basalt
setblock 296 266 261 minecraft:tuff
fill 297 266 235 308 266 235 minecraft:blackstone
setblock 297 266 237 minecraft:tuff
fill 297 266 238 303 267 238 minecraft:blackstone
setblock 297 266 244 minecraft:netherrack
setblock 297 266 252 minecraft:netherrack
setblock 297 266 253 minecraft:blackstone
fill 297 266 260 301 266 261 minecraft:blackstone
setblock 297 266 263 minecraft:tuff
setblock 298 266 239 minecraft:tuff
fill 298 266 243 299 266 243 minecraft:netherrack
fill 298 266 253 299 266 253 minecraft:netherrack
fill 298 266 262 302 266 263 minecraft:blackstone
setblock 298 266 265 minecraft:tuff
fill 298 266 266 304 267 266 minecraft:blackstone
fill 299 266 239 310 266 239 minecraft:basalt
setblock 299 266 241 minecraft:tuff
setblock 299 266 254 minecraft:tuff
setblock 299 266 267 minecraft:tuff
fill 299 266 268 305 267 268 minecraft:blackstone
setblock 300 266 230 minecraft:tuff
fill 300 266 241 311 266 241 minecraft:blackstone
fill 300 266 242 300 267 242 minecraft:netherrack
fill 300 266 254 300 267 254 minecraft:netherrack
setblock 300 266 256 minecraft:tuff
setblock 300 266 269 minecraft:tuff
fill 301 266 230 312 266 230 minecraft:blackstone
setblock 301 266 232 minecraft:tuff
fill 301 266 233 307 267 233 minecraft:blackstone
fill 301 266 242 301 267 242 minecraft:shroomlight
fill 301 266 254 301 267 254 minecraft:shroomlight
fill 301 266 255 305 266 256 minecraft:blackstone
setblock 301 266 258 minecraft:tuff
fill 301 266 269 312 266 269 minecraft:basalt
setblock 302 266 234 minecraft:tuff
fill 302 266 242 302 267 242 minecraft:netherrack
fill 302 266 254 302 267 254 minecraft:netherrack
fill 302 266 257 306 266 258 minecraft:blackstone
setblock 302 266 260 minecraft:tuff
fill 302 266 261 308 267 261 minecraft:blackstone
fill 303 266 234 314 266 234 minecraft:basalt
setblock 303 266 236 minecraft:tuff
fill 303 266 242 305 266 242 minecraft:blackstone
fill 303 266 243 304 266 243 minecraft:netherrack
fill 303 266 253 304 266 253 minecraft:netherrack
fill 303 266 254 311 266 254 minecraft:basalt
setblock 303 266 262 minecraft:tuff
fill 303 266 263 309 267 263 minecraft:blackstone
fill 304 266 236 315 266 236 minecraft:blackstone
setblock 304 266 238 minecraft:tuff
setblock 304 266 264 minecraft:tuff
fill 305 266 237 309 266 238 minecraft:blackstone
setblock 305 266 240 minecraft:tuff
fill 305 266 243 312 266 243 minecraft:blackstone
setblock 305 266 244 minecraft:netherrack
setblock 305 266 252 minecraft:netherrack
setblock 305 266 253 minecraft:tuff
fill 305 266 264 316 266 264 minecraft:basalt
setblock 305 266 266 minecraft:tuff
setblock 306 266 229 minecraft:tuff
fill 306 266 240 317 266 240 minecraft:blackstone
setblock 306 266 242 minecraft:tuff
setblock 306 266 244 minecraft:basalt
setblock 306 266 245 minecraft:netherrack
setblock 306 266 251 minecraft:netherrack
fill 306 266 252 310 266 253 minecraft:blackstone
setblock 306 266 255 minecraft:tuff
fill 306 266 256 312 267 256 minecraft:blackstone
fill 306 266 265 310 266 266 minecraft:blackstone
setblock 306 266 268 minecraft:tuff
fill 307 266 229 318 266 229 minecraft:basalt
setblock 307 266 231 minecraft:tuff
setblock 307 266 244 minecraft:tuff
fill 307 266 245 307 266 246 minecraft:blackstone
fill 307 266 247 307 267 249 minecraft:netherrack
fill 307 266 250 309 266 251 minecraft:blackstone
setblock 307 266 257 minecraft:tuff
fill 307 266 258 313 267 258 minecraft:blackstone
fill 307 266 267 311 266 268 minecraft:blackstone
fill 308 266 228 308 283 228 minecraft:blackstone
fill 308 266 231 319 266 231 minecraft:blackstone
setblock 308 266 233 minecraft:tuff
fill 308 266 244 319 266 244 minecraft:basalt
fill 308 266 245 313 266 245 minecraft:blackstone
setblock 308 266 246 minecraft:tuff
fill 308 266 247 308 267 248 minecraft:blackstone
fill 308 266 249 315 266 249 minecraft:basalt
setblock 308 266 259 minecraft:tuff
fill 309 266 232 313 266 233 minecraft:blackstone
setblock 309 266 235 minecraft:tuff
fill 309 266 246 314 266 247 minecraft:blackstone
setblock 309 266 248 minecraft:tuff
fill 309 266 259 320 266 259 minecraft:basalt
setblock 309 266 261 minecraft:tuff
fill 310 266 235 317 266 235 minecraft:blackstone
setblock 310 266 237 minecraft:tuff
fill 310 266 238 316 267 238 minecraft:blackstone
fill 310 266 248 321 266 248 minecraft:blackstone
setblock 310 266 250 minecraft:tuff
fill 310 266 251 316 267 251 minecraft:blackstone
fill 310 266 260 314 266 261 minecraft:blackstone
setblock 310 266 263 minecraft:tuff
setblock 311 266 239 minecraft:tuff
fill 311 266 250 319 266 250 minecraft:blackstone
setblock 311 266 252 minecraft:tuff
fill 311 266 253 317 267 253 minecraft:blackstone
fill 311 266 262 315 266 263 minecraft:blackstone
setblock 311 266 265 minecraft:tuff
fill 311 266 266 317 267 266 minecraft:blackstone
fill 312 266 239 323 266 239 minecraft:basalt
setblock 312 266 241 minecraft:tuff
fill 312 266 252 319 266 252 minecraft:blackstone
setblock 312 266 254 minecraft:tuff
setblock 312 266 267 minecraft:tuff
fill 312 266 268 318 267 268 minecraft:blackstone
setblock 313 266 230 minecraft:tuff
fill 313 266 241 320 266 241 minecraft:blackstone
setblock 313 266 243 minecraft:tuff
fill 313 266 254 323 266 254 minecraft:basalt
setblock 313 266 256 minecraft:tuff
setblock 313 266 269 minecraft:tuff
fill 314 266 230 321 266 230 minecraft:blackstone
setblock 314 266 232 minecraft:tuff
fill 314 266 233 320 267 233 minecraft:blackstone
fill 314 266 242 318 266 243 minecraft:blackstone
setblock 314 266 245 minecraft:tuff
fill 314 266 255 318 266 256 minecraft:blackstone
setblock 314 266 258 minecraft:tuff
fill 314 266 269 323 266 269 minecraft:basalt
setblock 315 266 234 minecraft:tuff
fill 315 266 245 315 266 246 minecraft:blackstone
setblock 315 266 247 minecraft:tuff
fill 315 266 257 319 266 258 minecraft:blackstone
setblock 315 266 260 minecraft:tuff
fill 315 266 261 321 267 261 minecraft:blackstone
fill 316 266 234 323 266 234 minecraft:basalt
setblock 316 266 236 minecraft:tuff
fill 316 266 246 320 266 247 minecraft:blackstone
setblock 316 266 249 minecraft:tuff
setblock 316 266 262 minecraft:tuff
fill 316 266 263 322 267 263 minecraft:blackstone
fill 317 266 236 318 267 236 minecraft:blackstone
setblock 317 266 238 minecraft:tuff
fill 317 266 249 323 266 249 minecraft:basalt
setblock 317 266 251 minecraft:tuff
setblock 317 266 264 minecraft:tuff
fill 318 266 237 318 268 238 minecraft:blackstone
setblock 318 266 240 minecraft:tuff
fill 318 266 251 320 267 251 minecraft:blackstone
setblock 318 266 253 minecraft:tuff
fill 318 266 264 323 266 264 minecraft:basalt
setblock 318 266 266 minecraft:tuff
setblock 319 266 229 minecraft:tuff
fill 319 266 238 323 266 238 minecraft:blackstone
fill 319 266 240 321 266 240 minecraft:blackstone
setblock 319 266 242 minecraft:tuff
fill 319 266 243 323 267 243 minecraft:blackstone
fill 319 266 253 323 266 253 minecraft:blackstone
setblock 319 266 255 minecraft:tuff
fill 319 266 256 321 267 256 minecraft:blackstone
fill 319 266 265 320 266 266 minecraft:blackstone
setblock 319 266 268 minecraft:tuff
fill 320 266 229 323 266 229 minecraft:basalt
setblock 320 266 231 minecraft:tuff
fill 320 266 237 322 267 237 minecraft:blackstone
setblock 320 266 244 minecraft:tuff
fill 320 266 255 322 266 255 minecraft:blackstone
setblock 320 266 257 minecraft:tuff
fill 320 266 258 323 269 258 minecraft:blackstone
fill 320 266 267 320 268 268 minecraft:blackstone
fill 321 266 231 323 267 231 minecraft:blackstone
setblock 321 266 233 minecraft:tuff
setblock 321 266 235 minecraft:blackstone
fill 321 266 244 323 266 244 minecraft:basalt
setblock 321 266 246 minecraft:tuff
fill 321 266 247 323 268 247 minecraft:blackstone
setblock 321 266 259 minecraft:tuff
fill 321 266 268 323 268 268 minecraft:blackstone
fill 322 266 232 322 268 233 minecraft:blackstone
setblock 322 266 235 minecraft:tuff
fill 322 266 245 323 266 246 minecraft:blackstone
setblock 322 266 248 minecraft:tuff
setblock 322 266 250 minecraft:blackstone
fill 322 266 259 323 266 259 minecraft:basalt
setblock 322 266 261 minecraft:tuff
fill 323 266 233 323 268 233 minecraft:blackstone
setblock 323 266 235 minecraft:blackstone
setblock 323 266 237 minecraft:tuff
fill 323 266 248 323 269 248 minecraft:blackstone
setblock 323 266 250 minecraft:tuff
fill 323 266 260 323 266 261 minecraft:blackstone
setblock 323 266 263 minecraft:tuff
setblock 324 266 250 minecraft:crying_obsidian
setblock 324 266 252 minecraft:crying_obsidian
setblock 282 267 230 minecraft:crying_obsidian
fill 282 267 240 282 283 240 minecraft:blackstone
fill 283 267 229 284 270 229 minecraft:blackstone
fill 283 267 230 291 267 230 minecraft:basalt
fill 283 267 232 286 267 234 minecraft:blackstone
fill 283 267 235 287 267 235 minecraft:basalt
fill 283 267 236 288 267 237 minecraft:blackstone
setblock 283 267 238 minecraft:tuff
fill 283 267 239 289 268 239 minecraft:blackstone
setblock 283 267 240 minecraft:basalt
fill 283 267 241 284 267 242 minecraft:blackstone
fill 283 267 244 285 268 244 minecraft:blackstone
fill 283 267 245 292 267 245 minecraft:basalt
fill 283 267 248 287 267 249 minecraft:blackstone
fill 283 267 250 288 267 250 minecraft:basalt
setblock 283 267 251 minecraft:tuff
fill 283 267 252 283 267 254 minecraft:blackstone
fill 283 267 255 284 267 255 minecraft:basalt
fill 283 267 256 285 267 257 minecraft:blackstone
fill 283 267 259 286 268 259 minecraft:blackstone
fill 283 267 260 293 267 260 minecraft:basalt
setblock 283 267 261 minecraft:blackstone
setblock 283 267 264 minecraft:tuff
fill 283 267 265 289 267 265 minecraft:basalt
fill 283 267 266 283 267 269 minecraft:blackstone
fill 284 267 231 285 267 231 minecraft:blackstone
setblock 284 267 240 minecraft:tuff
fill 284 267 246 286 267 247 minecraft:blackstone
fill 284 267 251 289 267 252 minecraft:blackstone
setblock 284 267 253 minecraft:tuff
fill 284 267 254 290 268 254 minecraft:blackstone
fill 284 267 263 288 267 264 minecraft:blackstone
setblock 284 267 266 minecraft:tuff
fill 284 267 267 284 267 269 minecraft:blackstone
setblock 285 267 229 minecraft:tuff
fill 285 267 240 296 267 240 minecraft:basalt
fill 285 267 241 290 267 241 minecraft:blackstone
setblock 285 267 242 minecraft:tuff
setblock 285 267 255 minecraft:tuff
fill 285 267 261 287 267 262 minecraft:blackstone
fill 285 267 266 286 267 267 minecraft:blackstone
setblock 285 267 268 minecraft:tuff
fill 285 267 269 291 268 269 minecraft:blackstone
fill 286 267 229 297 267 229 minecraft:blackstone
setblock 286 267 231 minecraft:tuff
fill 286 267 242 297 267 242 minecraft:blackstone
setblock 286 267 244 minecraft:tuff
fill 286 267 255 297 267 255 minecraft:basalt
setblock 286 267 257 minecraft:tuff
fill 287 267 231 292 267 232 minecraft:blackstone
setblock 287 267 233 minecraft:tuff
fill 287 267 234 293 268 234 minecraft:blackstone
fill 287 267 243 291 267 244 minecraft:blackstone
setblock 287 267 246 minecraft:tuff
fill 287 267 247 293 268 247 minecraft:blackstone
fill 287 267 256 291 267 257 minecraft:blackstone
setblock 287 267 259 minecraft:tuff
fill 287 267 267 290 268 267 minecraft:blackstone
setblock 288 267 235 minecraft:tuff
setblock 288 267 248 minecraft:tuff
fill 288 267 249 294 267 249 minecraft:blackstone
fill 288 267 258 292 267 259 minecraft:blackstone
setblock 288 267 261 minecraft:tuff
fill 288 267 262 294 268 262 minecraft:blackstone
fill 289 267 235 300 267 235 minecraft:basalt
fill 289 267 236 294 267 236 minecraft:blackstone
setblock 289 267 237 minecraft:tuff
setblock 289 267 250 minecraft:tuff
setblock 289 267 263 minecraft:tuff
fill 289 267 264 295 268 264 minecraft:blackstone
fill 290 267 237 301 267 237 minecraft:blackstone
setblock 290 267 239 minecraft:tuff
fill 290 267 250 294 267 250 minecraft:basalt
fill 290 267 251 294 267 251 minecraft:blackstone
setblock 290 267 252 minecraft:tuff
setblock 290 267 265 minecraft:tuff
fill 291 267 238 295 267 239 minecraft:blackstone
setblock 291 267 241 minecraft:tuff
fill 291 267 252 295 267 252 minecraft:blackstone
setblock 291 267 254 minecraft:tuff
fill 291 267 265 302 267 265 minecraft:basalt
setblock 291 267 267 minecraft:tuff
fill 292 267 228 292 271 228 minecraft:blackstone
setblock 292 267 230 minecraft:tuff
fill 292 267 241 303 267 241 minecraft:blackstone
setblock 292 267 243 minecraft:tuff
fill 292 267 244 295 267 244 minecraft:blackstone
fill 292 267 253 296 267 254 minecraft:blackstone
setblock 292 267 256 minecraft:tuff
fill 292 267 257 298 268 257 minecraft:blackstone
fill 292 267 266 296 267 267 minecraft:blackstone
setblock 292 267 269 minecraft:tuff
fill 293 267 230 304 267 230 minecraft:basalt
fill 293 267 231 298 267 231 minecraft:blackstone
setblock 293 267 232 minecraft:tuff
fill 293 267 243 296 267 243 minecraft:blackstone
setblock 293 267 245 minecraft:tuff
setblock 293 267 258 minecraft:tuff
fill 293 267 259 299 268 259 minecraft:blackstone
fill 293 267 268 297 267 269 minecraft:blackstone
fill 294 267 232 305 267 232 minecraft:blackstone
setblock 294 267 234 minecraft:tuff
setblock 294 267 245 minecraft:basalt
setblock 294 267 247 minecraft:tuff
setblock 294 267 260 minecraft:tuff
fill 295 267 233 299 267 234 minecraft:blackstone
setblock 295 267 236 minecraft:tuff
fill 295 267 245 295 267 246 minecraft:netherrack
fill 295 267 250 295 267 251 minecraft:netherrack
fill 295 267 260 306 267 260 minecraft:basalt
setblock 295 267 262 minecraft:tuff
fill 296 267 236 307 267 236 minecraft:blackstone
setblock 296 267 238 minecraft:tuff
fill 296 267 239 302 268 239 minecraft:blackstone
setblock 296 267 244 minecraft:shroomlight
setblock 296 267 252 minecraft:shroomlight
fill 296 267 261 300 267 262 minecraft:blackstone
setblock 296 267 264 minecraft:tuff
setblock 297 267 240 minecraft:tuff
setblock 297 267 243 minecraft:netherrack
setblock 297 267 253 minecraft:netherrack
setblock 297 267 254 minecraft:blackstone
fill 297 267 263 301 267 264 minecraft:blackstone
setblock 297 267 266 minecraft:tuff
fill 297 267 267 303 268 267 minecraft:blackstone
setblock 298 267 229 minecraft:tuff
fill 298 267 240 309 267 240 minecraft:basalt
fill 298 267 242 298 268 242 minecraft:shroomlight
fill 298 267 254 298 268 254 minecraft:shroomlight
setblock 298 267 255 minecraft:tuff
setblock 298 267 268 minecraft:tuff
fill 298 267 269 304 268 269 minecraft:blackstone
fill 299 267 229 310 267 229 minecraft:blackstone
setblock 299 267 231 minecraft:tuff
setblock 299 267 242 minecraft:netherrack
setblock 299 267 245 minecraft:light[level=12]
setblock 299 267 252 minecraft:light[level=12]
setblock 299 267 254 minecraft:netherrack
fill 299 267 255 310 267 255 minecraft:basalt
setblock 299 267 257 minecraft:tuff
fill 300 267 231 311 267 231 minecraft:blackstone
setblock 300 267 233 minecraft:tuff
fill 300 267 234 306 268 234 minecraft:blackstone
fill 300 267 256 304 267 257 minecraft:blackstone
setblock 300 267 259 minecraft:tuff
setblock 301 267 235 minecraft:tuff
fill 301 267 258 305 267 259 minecraft:blackstone
setblock 301 267 261 minecraft:tuff
fill 301 267 262 307 268 262 minecraft:blackstone
fill 302 267 235 313 267 235 minecraft:basalt
setblock 302 267 237 minecraft:tuff
setblock 302 267 263 minecraft:tuff
fill 302 267 264 308 268 264 minecraft:blackstone
fill 303 267 237 314 267 237 minecraft:blackstone
setblock 303 267 239 minecraft:tuff
setblock 303 267 242 minecraft:netherrack
setblock 303 267 254 minecraft:netherrack
setblock 303 267 265 minecraft:tuff
fill 304 267 238 308 267 239 minecraft:blackstone
setblock 304 267 241 minecraft:tuff
fill 304 267 242 304 268 242 minecraft:shroomlight
fill 304 267 254 304 268 254 minecraft:shroomlight
fill 304 267 265 315 267 265 minecraft:basalt
setblock 304 267 267 minecraft:tuff
setblock 305 267 230 minecraft:tuff
fill 305 267 241 310 267 242 minecraft:blackstone
setblock 305 267 243 minecraft:netherrack
setblock 305 267 253 minecraft:netherrack
fill 305 267 254 316 267 254 minecraft:blackstone
setblock 305 267 256 minecraft:tuff
fill 305 267 257 311 268 257 minecraft:blackstone
fill 305 267 266 309 267 267 minecraft:blackstone
setblock 305 267 269 minecraft:tuff
fill 306 267 230 317 267 230 minecraft:basalt
setblock 306 267 232 minecraft:tuff
fill 306 267 243 317 267 243 minecraft:blackstone
setblock 306 267 244 minecraft:shroomlight
setblock 306 267 245 minecraft:light[level=12]
setblock 306 267 252 minecraft:shroomlight
fill 306 267 253 309 267 253 minecraft:blackstone
setblock 306 267 258 minecraft:tuff
fill 306 267 259 312 268 259 minecraft:blackstone
fill 306 267 268 310 267 269 minecraft:blackstone
fill 307 267 232 318 267 232 minecraft:blackstone
setblock 307 267 234 minecraft:tuff
fill 307 267 244 311 267 244 minecraft:blackstone
fill 307 267 245 307 267 246 minecraft:netherrack
fill 307 267 250 307 267 251 minecraft:netherrack
fill 307 267 252 315 267 252 minecraft:blackstone
setblock 307 267 260 minecraft:tuff
fill 308 267 233 312 267 234 minecraft:blackstone
setblock 308 267 236 minecraft:tuff
fill 308 267 245 318 267 245 minecraft:basalt
fill 308 267 246 312 267 246 minecraft:blackstone
setblock 308 267 249 minecraft:tuff
fill 308 267 250 314 267 250 minecraft:basalt
setblock 308 267 251 minecraft:blackstone
fill 308 267 260 319 267 260 minecraft:basalt
setblock 308 267 262 minecraft:tuff
fill 309 267 236 316 267 236 minecraft:blackstone
setblock 309 267 238 minecraft:tuff
fill 309 267 239 315 268 239 minecraft:blackstone
fill 309 267 247 313 267 249 minecraft:blackstone
setblock 309 267 251 minecraft:tuff
fill 309 267 261 313 267 262 minecraft:blackstone
setblock 309 267 264 minecraft:tuff
setblock 310 267 240 minecraft:tuff
setblock 310 267 253 minecraft:tuff
fill 310 267 263 314 267 264 minecraft:blackstone
setblock 310 267 266 minecraft:tuff
fill 310 267 267 316 268 267 minecraft:blackstone
setblock 311 267 229 minecraft:tuff
fill 311 267 240 322 267 240 minecraft:basalt
fill 311 267 241 316 267 241 minecraft:blackstone
setblock 311 267 242 minecraft:tuff
setblock 311 267 255 minecraft:tuff
setblock 311 267 268 minecraft:tuff
fill 311 267 269 317 268 269 minecraft:blackstone
fill 312 267 229 323 267 229 minecraft:blackstone
setblock 312 267 231 minecraft:tuff
fill 312 267 242 319 267 242 minecraft:blackstone
setblock 312 267 244 minecraft:tuff
fill 312 267 255 323 267 255 minecraft:basalt
setblock 312 267 257 minecraft:tuff
fill 313 267 231 320 267 231 minecraft:blackstone
setblock 313 267 233 minecraft:tuff
fill 313 267 234 319 268 234 minecraft:blackstone
fill 313 267 244 323 267 244 minecraft:blackstone
setblock 313 267 246 minecraft:tuff
fill 313 267 256 317 267 257 minecraft:blackstone
setblock 313 267 259 minecraft:tuff
setblock 314 267 235 minecraft:tuff
fill 314 267 246 319 267 247 minecraft:blackstone
setblock 314 267 248 minecraft:tuff
fill 314 267 249 320 268 249 minecraft:blackstone
fill 314 267 258 318 267 259 minecraft:blackstone
setblock 314 267 261 minecraft:tuff
fill 314 267 262 320 268 262 minecraft:blackstone
fill 315 267 235 323 267 235 minecraft:basalt
setblock 315 267 237 minecraft:tuff
fill 315 267 248 322 267 248 minecraft:blackstone
setblock 315 267 250 minecraft:tuff
setblock 315 267 263 minecraft:tuff
fill 315 267 264 321 268 264 minecraft:blackstone
fill 316 267 237 317 268 237 minecraft:blackstone
setblock 316 267 239 minecraft:tuff
fill 316 267 250 323 267 250 minecraft:basalt
setblock 316 267 252 minecraft:tuff
setblock 316 267 265 minecraft:tuff
fill 317 267 238 317 269 239 minecraft:blackstone
setblock 317 267 241 minecraft:tuff
fill 317 267 251 317 267 252 minecraft:blackstone
setblock 317 267 254 minecraft:tuff
fill 317 267 265 323 267 265 minecraft:basalt
setblock 317 267 267 minecraft:tuff
setblock 318 267 230 minecraft:tuff
fill 318 267 239 323 267 239 minecraft:blackstone
fill 318 267 241 320 267 241 minecraft:blackstone
setblock 318 267 243 minecraft:tuff
fill 318 267 252 319 268 254 minecraft:blackstone
setblock 318 267 256 minecraft:tuff
fill 318 267 257 320 268 257 minecraft:blackstone
fill 318 267 266 319 267 267 minecraft:blackstone
setblock 318 267 269 minecraft:tuff
fill 319 267 230 323 267 230 minecraft:basalt
setblock 319 267 232 minecraft:tuff
fill 319 267 238 321 268 238 minecraft:blackstone
setblock 319 267 245 minecraft:tuff
setblock 319 267 258 minecraft:tuff
fill 319 267 259 323 268 259 minecraft:blackstone
fill 319 267 268 319 269 269 minecraft:blackstone
fill 320 267 232 321 268 232 minecraft:blackstone
setblock 320 267 234 minecraft:tuff
setblock 320 267 236 minecraft:blackstone
fill 320 267 245 323 267 245 minecraft:basalt
fill 320 267 246 323 267 246 minecraft:blackstone
setblock 320 267 247 minecraft:tuff
fill 320 267 253 322 267 254 minecraft:blackstone
setblock 320 267 260 minecraft:tuff
fill 320 267 266 322 267 266 minecraft:blackstone
fill 320 267 269 323 267 269 minecraft:blackstone
fill 321 267 233 321 269 234 minecraft:blackstone
setblock 321 267 236 minecraft:tuff
setblock 321 267 249 minecraft:tuff
setblock 321 267 251 minecraft:blackstone
fill 321 267 260 323 267 260 minecraft:basalt
setblock 321 267 262 minecraft:tuff
fill 321 267 267 321 268 267 minecraft:blackstone
fill 322 267 234 323 269 234 minecraft:blackstone
fill 322 267 236 323 267 236 minecraft:blackstone
setblock 322 267 238 minecraft:tuff
fill 322 267 249 323 269 249 minecraft:blackstone
setblock 322 267 251 minecraft:tuff
fill 322 267 261 323 267 262 minecraft:blackstone
setblock 322 267 264 minecraft:tuff
fill 323 267 237 323 268 238 minecraft:blackstone
setblock 323 267 240 minecraft:tuff
setblock 323 267 251 minecraft:blackstone
setblock 323 267 253 minecraft:tuff
fill 323 267 254 323 270 254 minecraft:blackstone
fill 323 267 263 323 269 264 minecraft:blackstone
setblock 323 267 266 minecraft:tuff
fill 324 267 250 324 283 250 minecraft:blackstone
fill 324 267 252 324 283 252 minecraft:blackstone
fill 282 268 230 283 271 230 minecraft:blackstone
fill 283 268 231 290 268 231 minecraft:basalt
fill 283 268 232 284 268 235 minecraft:blackstone
fill 283 268 236 286 268 236 minecraft:basalt
fill 283 268 237 287 268 238 minecraft:blackstone
fill 283 268 240 288 269 240 minecraft:blackstone
setblock 283 268 241 minecraft:tuff
fill 283 268 242 283 268 243 minecraft:blackstone
fill 283 268 245 284 271 245 minecraft:blackstone
fill 283 268 246 291 268 246 minecraft:basalt
fill 283 268 247 285 268 250 minecraft:blackstone
fill 283 268 251 287 268 251 minecraft:basalt
fill 283 268 252 288 268 253 minecraft:blackstone
setblock 283 268 254 minecraft:tuff
fill 283 268 255 289 269 255 minecraft:blackstone
setblock 283 268 256 minecraft:basalt
fill 283 268 257 284 268 258 minecraft:blackstone
fill 283 268 260 285 269 260 minecraft:blackstone
fill 283 268 261 292 268 261 minecraft:basalt
fill 283 268 264 287 268 265 minecraft:blackstone
fill 283 268 266 288 268 266 minecraft:basalt
setblock 283 268 267 minecraft:tuff
fill 283 268 268 283 269 269 minecraft:blackstone
setblock 284 268 230 minecraft:tuff
schedule function dropper:buildpart/54_4 1t
