setblock 463 150 482 minecraft:polished_blackstone_bricks
setblock 463 150 493 minecraft:blackstone
setblock 463 150 497 minecraft:polished_blackstone_bricks
fill 463 150 498 463 153 498 minecraft:blackstone
setblock 463 150 502 minecraft:polished_blackstone_bricks
fill 463 150 503 463 153 503 minecraft:blackstone
setblock 464 150 466 minecraft:polished_blackstone_bricks
fill 464 150 467 464 153 467 minecraft:blackstone
setblock 464 150 471 minecraft:polished_blackstone_bricks
fill 464 150 472 464 153 472 minecraft:blackstone
setblock 464 150 476 minecraft:polished_blackstone_bricks
fill 464 150 477 464 153 477 minecraft:blackstone
setblock 464 150 481 minecraft:polished_blackstone_bricks
fill 464 150 482 464 153 482 minecraft:blackstone
setblock 464 150 486 minecraft:polished_blackstone_bricks
fill 464 150 487 464 152 488 minecraft:blackstone
setblock 464 150 490 minecraft:blackstone
setblock 464 150 491 minecraft:polished_blackstone_bricks
fill 464 150 492 464 153 492 minecraft:blackstone
setblock 464 150 496 minecraft:polished_blackstone_bricks
fill 464 150 497 464 153 497 minecraft:blackstone
setblock 464 150 501 minecraft:polished_blackstone_bricks
fill 464 150 502 464 153 502 minecraft:blackstone
setblock 424 151 465 minecraft:polished_blackstone_bricks
fill 424 151 466 424 154 466 minecraft:blackstone
setblock 424 151 470 minecraft:polished_blackstone_bricks
setblock 424 151 471 minecraft:blackstone
setblock 424 151 475 minecraft:polished_blackstone_bricks
fill 424 151 476 424 154 476 minecraft:blackstone
setblock 424 151 480 minecraft:polished_blackstone_bricks
fill 424 151 481 424 154 481 minecraft:blackstone
setblock 424 151 484 minecraft:blackstone
setblock 424 151 485 minecraft:polished_blackstone_bricks
fill 424 151 486 424 154 486 minecraft:blackstone
setblock 424 151 490 minecraft:polished_blackstone_bricks
fill 424 151 491 424 154 491 minecraft:blackstone
setblock 424 151 495 minecraft:polished_blackstone_bricks
fill 424 151 496 424 154 496 minecraft:blackstone
setblock 424 151 500 minecraft:polished_blackstone_bricks
fill 424 151 501 424 154 501 minecraft:blackstone
setblock 425 151 464 minecraft:polished_blackstone_bricks
setblock 425 151 474 minecraft:polished_blackstone_bricks
fill 425 151 475 425 152 475 minecraft:blackstone
setblock 425 151 478 minecraft:blackstone
setblock 425 151 479 minecraft:polished_blackstone_bricks
fill 425 151 480 425 154 480 minecraft:blackstone
setblock 425 151 484 minecraft:polished_blackstone_bricks
fill 425 151 485 425 154 485 minecraft:blackstone
setblock 425 151 489 minecraft:polished_blackstone_bricks
fill 425 151 490 425 154 490 minecraft:blackstone
setblock 425 151 494 minecraft:polished_blackstone_bricks
fill 425 151 495 425 154 495 minecraft:blackstone
setblock 425 151 499 minecraft:polished_blackstone_bricks
fill 425 151 500 425 154 500 minecraft:blackstone
setblock 425 151 504 minecraft:polished_blackstone_bricks
fill 426 151 464 426 154 464 minecraft:blackstone
setblock 426 151 478 minecraft:polished_blackstone_bricks
fill 426 151 479 426 152 479 minecraft:blackstone
setblock 426 151 482 minecraft:blackstone
setblock 426 151 483 minecraft:polished_blackstone_bricks
setblock 426 151 493 minecraft:polished_blackstone_bricks
fill 426 151 494 426 152 494 minecraft:blackstone
setblock 426 151 498 minecraft:polished_blackstone_bricks
fill 426 151 499 426 154 499 minecraft:blackstone
setblock 426 151 503 minecraft:polished_blackstone_bricks
fill 426 151 504 426 154 504 minecraft:blackstone
setblock 427 151 497 minecraft:polished_blackstone_bricks
fill 427 151 498 427 152 498 minecraft:blackstone
setblock 427 151 502 minecraft:polished_blackstone_bricks
fill 427 151 503 427 154 503 minecraft:blackstone
setblock 428 151 501 minecraft:polished_blackstone_bricks
fill 428 151 502 428 153 502 minecraft:blackstone
setblock 430 151 504 minecraft:polished_blackstone_bricks
setblock 431 151 503 minecraft:polished_blackstone_bricks
fill 431 151 504 431 153 504 minecraft:blackstone
setblock 439 151 504 minecraft:blackstone
setblock 440 151 504 minecraft:polished_blackstone_bricks
fill 441 151 464 441 154 464 minecraft:blackstone
fill 441 151 504 444 151 504 minecraft:blackstone
fill 442 151 503 445 151 503 minecraft:blackstone
setblock 444 151 465 minecraft:polished_blackstone_bricks
setblock 445 151 464 minecraft:polished_blackstone_bricks
fill 445 151 465 445 154 465 minecraft:blackstone
setblock 445 151 504 minecraft:polished_blackstone_bricks
fill 446 151 464 446 154 464 minecraft:blackstone
setblock 446 151 503 minecraft:polished_blackstone_bricks
fill 446 151 504 446 154 504 minecraft:blackstone
fill 447 151 503 447 154 503 minecraft:blackstone
setblock 449 151 465 minecraft:polished_blackstone_bricks
setblock 450 151 464 minecraft:polished_blackstone_bricks
setblock 450 151 504 minecraft:polished_blackstone_bricks
fill 451 151 464 454 151 464 minecraft:blackstone
fill 451 151 504 454 151 504 minecraft:blackstone
fill 454 151 466 455 154 470 minecraft:warped_wart_block
setblock 455 151 464 minecraft:polished_blackstone_bricks
setblock 455 151 504 minecraft:polished_blackstone_bricks
fill 456 151 464 456 154 464 minecraft:blackstone
fill 456 151 466 458 154 467 minecraft:warped_wart_block
setblock 456 151 468 minecraft:polished_blackstone_bricks
fill 456 151 469 458 154 470 minecraft:warped_wart_block
fill 456 151 504 456 154 504 minecraft:blackstone
fill 457 151 468 458 154 468 minecraft:warped_wart_block
fill 457 151 503 457 154 503 minecraft:blackstone
fill 459 151 490 459 152 490 minecraft:polished_blackstone_bricks
fill 459 151 492 459 152 492 minecraft:polished_blackstone_bricks
setblock 460 151 464 minecraft:polished_blackstone_bricks
fill 460 151 465 460 154 465 minecraft:blackstone
setblock 460 151 503 minecraft:blackstone
setblock 460 151 504 minecraft:polished_blackstone_bricks
fill 461 151 464 461 154 464 minecraft:blackstone
setblock 461 151 503 minecraft:polished_blackstone_bricks
fill 461 151 504 461 154 504 minecraft:blackstone
setblock 462 151 497 minecraft:polished_blackstone_bricks
fill 462 151 498 462 154 498 minecraft:blackstone
setblock 462 151 501 minecraft:blackstone
setblock 462 151 502 minecraft:polished_blackstone_bricks
fill 462 151 503 462 154 503 minecraft:blackstone
setblock 463 151 466 minecraft:polished_blackstone_bricks
fill 463 151 467 463 152 467 minecraft:blackstone
setblock 463 151 471 minecraft:polished_blackstone_bricks
setblock 463 151 472 minecraft:blackstone
setblock 463 151 476 minecraft:polished_blackstone_bricks
fill 463 151 477 463 153 477 minecraft:blackstone
setblock 463 151 481 minecraft:polished_blackstone_bricks
fill 463 151 482 463 154 482 minecraft:blackstone
setblock 463 151 496 minecraft:polished_blackstone_bricks
fill 463 151 497 463 154 497 minecraft:blackstone
setblock 463 151 501 minecraft:polished_blackstone_bricks
fill 463 151 502 463 154 502 minecraft:blackstone
setblock 464 151 465 minecraft:polished_blackstone_bricks
fill 464 151 466 464 154 466 minecraft:blackstone
setblock 464 151 470 minecraft:polished_blackstone_bricks
fill 464 151 471 464 153 471 minecraft:blackstone
setblock 464 151 475 minecraft:polished_blackstone_bricks
fill 464 151 476 464 154 476 minecraft:blackstone
setblock 464 151 480 minecraft:polished_blackstone_bricks
fill 464 151 481 464 154 481 minecraft:blackstone
setblock 464 151 485 minecraft:polished_blackstone_bricks
fill 464 151 486 464 154 486 minecraft:blackstone
setblock 464 151 490 minecraft:polished_blackstone_bricks
fill 464 151 491 464 154 491 minecraft:blackstone
setblock 464 151 495 minecraft:polished_blackstone_bricks
fill 464 151 496 464 154 496 minecraft:blackstone
setblock 464 151 500 minecraft:polished_blackstone_bricks
fill 464 151 501 464 154 501 minecraft:blackstone
setblock 424 152 464 minecraft:polished_blackstone_bricks
fill 424 152 465 424 155 465 minecraft:blackstone
setblock 424 152 474 minecraft:polished_blackstone_bricks
fill 424 152 475 424 154 475 minecraft:blackstone
setblock 424 152 479 minecraft:polished_blackstone_bricks
fill 424 152 480 424 155 480 minecraft:blackstone
setblock 424 152 484 minecraft:polished_blackstone_bricks
fill 424 152 485 424 155 485 minecraft:blackstone
setblock 424 152 489 minecraft:polished_blackstone_bricks
fill 424 152 490 424 155 490 minecraft:blackstone
setblock 424 152 494 minecraft:polished_blackstone_bricks
fill 424 152 495 424 155 495 minecraft:blackstone
setblock 424 152 499 minecraft:polished_blackstone_bricks
fill 424 152 500 424 155 500 minecraft:blackstone
setblock 424 152 504 minecraft:polished_blackstone_bricks
fill 425 152 464 425 155 464 minecraft:blackstone
setblock 425 152 478 minecraft:polished_blackstone_bricks
fill 425 152 479 425 155 479 minecraft:blackstone
setblock 425 152 483 minecraft:polished_blackstone_bricks
fill 425 152 484 425 155 484 minecraft:blackstone
setblock 425 152 488 minecraft:polished_blackstone_bricks
fill 425 152 489 425 155 489 minecraft:blackstone
setblock 425 152 493 minecraft:polished_blackstone_bricks
fill 425 152 494 425 155 494 minecraft:blackstone
setblock 425 152 498 minecraft:polished_blackstone_bricks
fill 425 152 499 425 155 499 minecraft:blackstone
setblock 425 152 503 minecraft:polished_blackstone_bricks
fill 425 152 504 425 155 504 minecraft:blackstone
setblock 426 152 466 minecraft:light[level=11]
setblock 426 152 474 minecraft:light[level=11]
setblock 426 152 482 minecraft:polished_blackstone_bricks
fill 426 152 483 426 153 483 minecraft:blackstone
setblock 426 152 490 minecraft:light[level=11]
setblock 426 152 497 minecraft:polished_blackstone_bricks
fill 426 152 498 426 154 498 minecraft:blackstone
setblock 426 152 502 minecraft:polished_blackstone_bricks
fill 426 152 503 426 155 503 minecraft:blackstone
setblock 427 152 501 minecraft:polished_blackstone_bricks
fill 427 152 502 427 154 502 minecraft:blackstone
setblock 429 152 504 minecraft:polished_blackstone_bricks
setblock 430 152 503 minecraft:polished_blackstone_bricks
fill 430 152 504 430 155 504 minecraft:blackstone
setblock 434 152 466 minecraft:light[level=11]
setblock 434 152 474 minecraft:light[level=11]
setblock 434 152 482 minecraft:light[level=11]
setblock 434 152 490 minecraft:light[level=11]
setblock 434 152 498 minecraft:light[level=11]
setblock 439 152 504 minecraft:polished_blackstone_bricks
fill 440 152 504 443 152 504 minecraft:blackstone
fill 441 152 503 444 152 503 minecraft:blackstone
setblock 442 152 466 minecraft:light[level=11]
setblock 442 152 474 minecraft:light[level=11]
setblock 442 152 482 minecraft:light[level=11]
setblock 442 152 490 minecraft:light[level=11]
setblock 442 152 498 minecraft:light[level=11]
setblock 444 152 464 minecraft:polished_blackstone_bricks
fill 444 152 465 444 155 465 minecraft:blackstone
setblock 444 152 504 minecraft:polished_blackstone_bricks
fill 445 152 464 445 155 464 minecraft:blackstone
setblock 445 152 503 minecraft:polished_blackstone_bricks
fill 445 152 504 445 155 504 minecraft:blackstone
fill 446 152 503 446 154 503 minecraft:blackstone
setblock 448 152 465 minecraft:polished_blackstone_bricks
setblock 449 152 464 minecraft:polished_blackstone_bricks
setblock 449 152 503 minecraft:blackstone
setblock 449 152 504 minecraft:polished_blackstone_bricks
fill 450 152 464 453 152 464 minecraft:blackstone
setblock 450 152 466 minecraft:light[level=11]
setblock 450 152 474 minecraft:light[level=11]
setblock 450 152 482 minecraft:light[level=11]
setblock 450 152 490 minecraft:light[level=11]
setblock 450 152 498 minecraft:light[level=11]
fill 450 152 504 453 152 504 minecraft:blackstone
fill 453 152 467 453 153 469 minecraft:warped_wart_block
setblock 454 152 464 minecraft:polished_blackstone_bricks
setblock 454 152 504 minecraft:polished_blackstone_bricks
fill 455 152 464 455 155 464 minecraft:blackstone
fill 455 152 465 457 153 465 minecraft:warped_wart_block
fill 455 152 471 457 153 471 minecraft:warped_wart_block
fill 455 152 504 455 155 504 minecraft:blackstone
fill 456 152 468 456 155 468 minecraft:warped_wart_block
setblock 458 152 474 minecraft:light[level=11]
setblock 458 152 482 minecraft:light[level=11]
setblock 458 152 490 minecraft:light[level=11]
setblock 458 152 498 minecraft:light[level=11]
setblock 459 152 464 minecraft:polished_blackstone_bricks
fill 459 152 467 459 153 469 minecraft:warped_wart_block
setblock 459 152 504 minecraft:polished_blackstone_bricks
fill 460 152 464 460 155 464 minecraft:blackstone
setblock 460 152 503 minecraft:polished_blackstone_bricks
fill 460 152 504 460 155 504 minecraft:blackstone
setblock 461 152 502 minecraft:polished_blackstone_bricks
fill 461 152 503 461 155 503 minecraft:blackstone
setblock 462 152 497 minecraft:blackstone
setblock 462 152 501 minecraft:polished_blackstone_bricks
fill 462 152 502 462 155 502 minecraft:blackstone
setblock 463 152 465 minecraft:polished_blackstone_bricks
fill 463 152 466 463 155 466 minecraft:blackstone
setblock 463 152 475 minecraft:polished_blackstone_bricks
fill 463 152 476 463 153 476 minecraft:blackstone
setblock 463 152 480 minecraft:polished_blackstone_bricks
fill 463 152 481 463 155 481 minecraft:blackstone
fill 463 152 483 463 153 483 minecraft:blackstone
setblock 463 152 495 minecraft:polished_blackstone_bricks
fill 463 152 496 463 155 496 minecraft:blackstone
setblock 463 152 500 minecraft:polished_blackstone_bricks
fill 463 152 501 463 155 501 minecraft:blackstone
setblock 464 152 464 minecraft:polished_blackstone_bricks
fill 464 152 465 464 155 465 minecraft:blackstone
setblock 464 152 469 minecraft:polished_blackstone_bricks
fill 464 152 470 464 153 470 minecraft:blackstone
setblock 464 152 474 minecraft:polished_blackstone_bricks
fill 464 152 475 464 154 475 minecraft:blackstone
setblock 464 152 479 minecraft:polished_blackstone_bricks
fill 464 152 480 464 155 480 minecraft:blackstone
setblock 464 152 484 minecraft:polished_blackstone_bricks
fill 464 152 485 464 155 485 minecraft:blackstone
setblock 464 152 489 minecraft:polished_blackstone_bricks
fill 464 152 490 464 155 490 minecraft:blackstone
setblock 464 152 494 minecraft:polished_blackstone_bricks
fill 464 152 495 464 155 495 minecraft:blackstone
setblock 464 152 499 minecraft:polished_blackstone_bricks
fill 464 152 500 464 155 500 minecraft:blackstone
setblock 464 152 504 minecraft:polished_blackstone_bricks
fill 424 153 464 424 156 464 minecraft:blackstone
setblock 424 153 474 minecraft:blackstone
setblock 424 153 478 minecraft:polished_blackstone_bricks
fill 424 153 479 424 156 479 minecraft:blackstone
setblock 424 153 483 minecraft:polished_blackstone_bricks
fill 424 153 484 424 156 484 minecraft:blackstone
setblock 424 153 488 minecraft:polished_blackstone_bricks
fill 424 153 489 424 156 489 minecraft:blackstone
setblock 424 153 493 minecraft:polished_blackstone_bricks
fill 424 153 494 424 156 494 minecraft:blackstone
setblock 424 153 498 minecraft:polished_blackstone_bricks
fill 424 153 499 424 156 499 minecraft:blackstone
setblock 424 153 503 minecraft:polished_blackstone_bricks
fill 424 153 504 424 156 504 minecraft:blackstone
setblock 425 153 477 minecraft:polished_blackstone_bricks
fill 425 153 478 425 154 478 minecraft:blackstone
setblock 425 153 482 minecraft:polished_blackstone_bricks
fill 425 153 483 425 156 483 minecraft:blackstone
setblock 425 153 487 minecraft:polished_blackstone_bricks
fill 425 153 488 425 156 488 minecraft:blackstone
setblock 425 153 492 minecraft:polished_blackstone_bricks
fill 425 153 493 425 154 493 minecraft:blackstone
setblock 425 153 497 minecraft:polished_blackstone_bricks
fill 425 153 498 425 156 498 minecraft:blackstone
setblock 425 153 502 minecraft:polished_blackstone_bricks
fill 425 153 503 425 156 503 minecraft:blackstone
setblock 426 153 481 minecraft:polished_blackstone_bricks
setblock 426 153 482 minecraft:blackstone
setblock 426 153 496 minecraft:polished_blackstone_bricks
setblock 426 153 497 minecraft:blackstone
setblock 426 153 501 minecraft:polished_blackstone_bricks
fill 426 153 502 426 155 502 minecraft:blackstone
setblock 428 153 504 minecraft:polished_blackstone_bricks
setblock 429 153 503 minecraft:polished_blackstone_bricks
fill 429 153 504 429 156 504 minecraft:blackstone
fill 439 153 504 442 153 504 minecraft:blackstone
fill 440 153 464 440 155 464 minecraft:blackstone
fill 441 153 503 443 153 503 minecraft:blackstone
setblock 443 153 464 minecraft:polished_blackstone_bricks
fill 443 153 465 443 156 465 minecraft:blackstone
setblock 443 153 504 minecraft:polished_blackstone_bricks
fill 444 153 464 444 156 464 minecraft:blackstone
setblock 444 153 503 minecraft:polished_blackstone_bricks
fill 444 153 504 444 156 504 minecraft:blackstone
fill 445 153 503 445 156 503 minecraft:blackstone
setblock 447 153 465 minecraft:polished_blackstone_bricks
setblock 448 153 464 minecraft:polished_blackstone_bricks
setblock 448 153 465 minecraft:blackstone
setblock 448 153 504 minecraft:polished_blackstone_bricks
fill 449 153 464 452 153 464 minecraft:blackstone
fill 449 153 504 452 153 504 minecraft:blackstone
setblock 453 153 464 minecraft:polished_blackstone_bricks
setblock 453 153 504 minecraft:polished_blackstone_bricks
fill 454 153 464 454 156 464 minecraft:blackstone
fill 454 153 504 454 156 504 minecraft:blackstone
setblock 458 153 464 minecraft:polished_blackstone_bricks
setblock 458 153 504 minecraft:polished_blackstone_bricks
fill 459 153 464 459 155 465 minecraft:blackstone
setblock 459 153 502 minecraft:blackstone
setblock 459 153 503 minecraft:polished_blackstone_bricks
fill 459 153 504 459 156 504 minecraft:blackstone
setblock 460 153 502 minecraft:polished_blackstone_bricks
fill 460 153 503 460 156 503 minecraft:blackstone
fill 461 153 502 461 156 502 minecraft:blackstone
setblock 462 153 465 minecraft:polished_blackstone_bricks
setblock 462 153 500 minecraft:polished_blackstone_bricks
fill 462 153 501 462 156 501 minecraft:blackstone
setblock 463 153 464 minecraft:polished_blackstone_bricks
fill 463 153 465 463 156 465 minecraft:blackstone
setblock 463 153 479 minecraft:polished_blackstone_bricks
fill 463 153 480 463 155 480 minecraft:blackstone
setblock 463 153 495 minecraft:blackstone
setblock 463 153 499 minecraft:polished_blackstone_bricks
fill 463 153 500 463 156 500 minecraft:blackstone
setblock 463 153 504 minecraft:polished_blackstone_bricks
fill 464 153 464 464 156 464 minecraft:blackstone
setblock 464 153 468 minecraft:polished_blackstone_bricks
fill 464 153 469 464 154 469 minecraft:blackstone
setblock 464 153 473 minecraft:polished_blackstone_bricks
fill 464 153 474 464 154 474 minecraft:blackstone
setblock 464 153 478 minecraft:polished_blackstone_bricks
fill 464 153 479 464 156 479 minecraft:blackstone
setblock 464 153 483 minecraft:polished_blackstone_bricks
fill 464 153 484 464 156 484 minecraft:blackstone
setblock 464 153 487 minecraft:blackstone
setblock 464 153 488 minecraft:polished_blackstone_bricks
fill 464 153 489 464 156 489 minecraft:blackstone
setblock 464 153 493 minecraft:polished_blackstone_bricks
fill 464 153 494 464 156 494 minecraft:blackstone
setblock 464 153 498 minecraft:polished_blackstone_bricks
fill 464 153 499 464 156 499 minecraft:blackstone
setblock 464 153 503 minecraft:polished_blackstone_bricks
fill 464 153 504 464 156 504 minecraft:blackstone
setblock 424 154 477 minecraft:polished_blackstone_bricks
fill 424 154 478 424 157 478 minecraft:blackstone
setblock 424 154 482 minecraft:polished_blackstone_bricks
fill 424 154 483 424 157 483 minecraft:blackstone
setblock 424 154 487 minecraft:polished_blackstone_bricks
fill 424 154 488 424 157 488 minecraft:blackstone
setblock 424 154 492 minecraft:polished_blackstone_bricks
fill 424 154 493 424 157 493 minecraft:blackstone
setblock 424 154 497 minecraft:polished_blackstone_bricks
fill 424 154 498 424 157 498 minecraft:blackstone
setblock 424 154 502 minecraft:polished_blackstone_bricks
fill 424 154 503 424 157 503 minecraft:blackstone
setblock 425 154 481 minecraft:polished_blackstone_bricks
fill 425 154 482 425 157 482 minecraft:blackstone
setblock 425 154 486 minecraft:polished_blackstone_bricks
fill 425 154 487 425 157 487 minecraft:blackstone
setblock 425 154 491 minecraft:polished_blackstone_bricks
setblock 425 154 492 minecraft:blackstone
setblock 425 154 496 minecraft:polished_blackstone_bricks
fill 425 154 497 425 156 497 minecraft:blackstone
setblock 425 154 501 minecraft:polished_blackstone_bricks
fill 425 154 502 425 157 502 minecraft:blackstone
setblock 426 154 500 minecraft:polished_blackstone_bricks
fill 426 154 501 426 155 501 minecraft:blackstone
setblock 427 154 504 minecraft:polished_blackstone_bricks
setblock 428 154 503 minecraft:polished_blackstone_bricks
fill 428 154 504 428 157 504 minecraft:blackstone
setblock 429 154 503 minecraft:blackstone
fill 438 154 504 441 154 504 minecraft:blackstone
fill 439 154 464 439 156 464 minecraft:blackstone
fill 441 154 503 442 154 503 minecraft:blackstone
setblock 442 154 464 minecraft:polished_blackstone_bricks
setblock 442 154 504 minecraft:polished_blackstone_bricks
fill 443 154 464 443 157 464 minecraft:blackstone
setblock 443 154 503 minecraft:polished_blackstone_bricks
fill 443 154 504 443 157 504 minecraft:blackstone
fill 444 154 503 444 157 503 minecraft:blackstone
setblock 446 154 465 minecraft:polished_blackstone_bricks
setblock 447 154 464 minecraft:polished_blackstone_bricks
fill 447 154 465 447 157 465 minecraft:blackstone
setblock 447 154 504 minecraft:polished_blackstone_bricks
fill 448 154 464 451 154 464 minecraft:blackstone
fill 448 154 504 451 154 504 minecraft:blackstone
setblock 452 154 464 minecraft:polished_blackstone_bricks
setblock 452 154 504 minecraft:polished_blackstone_bricks
fill 453 154 464 453 157 464 minecraft:blackstone
fill 453 154 504 453 157 504 minecraft:blackstone
setblock 457 154 464 minecraft:polished_blackstone_bricks
setblock 457 154 504 minecraft:polished_blackstone_bricks
fill 458 154 464 458 157 464 minecraft:blackstone
setblock 458 154 503 minecraft:polished_blackstone_bricks
fill 458 154 504 458 157 504 minecraft:blackstone
setblock 459 154 502 minecraft:polished_blackstone_bricks
fill 459 154 503 459 157 503 minecraft:blackstone
fill 460 154 502 460 157 502 minecraft:blackstone
setblock 461 154 465 minecraft:polished_blackstone_bricks
setblock 462 154 464 minecraft:polished_blackstone_bricks
fill 462 154 465 462 157 465 minecraft:blackstone
setblock 462 154 499 minecraft:polished_blackstone_bricks
fill 462 154 500 462 157 500 minecraft:blackstone
setblock 462 154 504 minecraft:polished_blackstone_bricks
fill 463 154 464 463 157 464 minecraft:blackstone
setblock 463 154 478 minecraft:polished_blackstone_bricks
setblock 463 154 479 minecraft:blackstone
setblock 463 154 483 minecraft:polished_blackstone_bricks
setblock 463 154 498 minecraft:polished_blackstone_bricks
fill 463 154 499 463 157 499 minecraft:blackstone
setblock 463 154 503 minecraft:polished_blackstone_bricks
fill 463 154 504 463 157 504 minecraft:blackstone
setblock 464 154 467 minecraft:polished_blackstone_bricks
fill 464 154 468 464 157 468 minecraft:blackstone
setblock 464 154 477 minecraft:polished_blackstone_bricks
fill 464 154 478 464 157 478 minecraft:blackstone
setblock 464 154 482 minecraft:polished_blackstone_bricks
fill 464 154 483 464 157 483 minecraft:blackstone
setblock 464 154 487 minecraft:polished_blackstone_bricks
fill 464 154 488 464 157 488 minecraft:blackstone
setblock 464 154 492 minecraft:polished_blackstone_bricks
fill 464 154 493 464 157 493 minecraft:blackstone
setblock 464 154 497 minecraft:polished_blackstone_bricks
fill 464 154 498 464 157 498 minecraft:blackstone
setblock 464 154 502 minecraft:polished_blackstone_bricks
fill 464 154 503 464 157 503 minecraft:blackstone
setblock 424 155 476 minecraft:polished_blackstone_bricks
fill 424 155 477 424 157 477 minecraft:blackstone
setblock 424 155 481 minecraft:polished_blackstone_bricks
fill 424 155 482 424 158 482 minecraft:blackstone
setblock 424 155 486 minecraft:polished_blackstone_bricks
fill 424 155 487 424 158 487 minecraft:blackstone
setblock 424 155 491 minecraft:polished_blackstone_bricks
fill 424 155 492 424 158 492 minecraft:blackstone
setblock 424 155 496 minecraft:polished_blackstone_bricks
fill 424 155 497 424 158 497 minecraft:blackstone
setblock 424 155 501 minecraft:polished_blackstone_bricks
fill 424 155 502 424 158 502 minecraft:blackstone
setblock 425 155 480 minecraft:polished_blackstone_bricks
fill 425 155 481 425 158 481 minecraft:blackstone
setblock 425 155 485 minecraft:polished_blackstone_bricks
fill 425 155 486 425 158 486 minecraft:blackstone
setblock 425 155 495 minecraft:polished_blackstone_bricks
fill 425 155 496 425 156 496 minecraft:blackstone
setblock 425 155 500 minecraft:polished_blackstone_bricks
fill 425 155 501 425 158 501 minecraft:blackstone
setblock 426 155 464 minecraft:polished_blackstone_bricks
setblock 426 155 504 minecraft:polished_blackstone_bricks
setblock 427 155 503 minecraft:polished_blackstone_bricks
fill 427 155 504 427 158 504 minecraft:blackstone
setblock 428 155 503 minecraft:blackstone
fill 438 155 504 440 155 504 minecraft:blackstone
setblock 441 155 464 minecraft:polished_blackstone_bricks
setblock 441 155 503 minecraft:blackstone
setblock 441 155 504 minecraft:polished_blackstone_bricks
fill 442 155 464 442 157 465 minecraft:blackstone
setblock 442 155 503 minecraft:polished_blackstone_bricks
fill 442 155 504 442 158 504 minecraft:blackstone
fill 443 155 503 443 158 503 minecraft:blackstone
setblock 445 155 465 minecraft:polished_blackstone_bricks
setblock 446 155 464 minecraft:polished_blackstone_bricks
fill 446 155 465 446 158 465 minecraft:blackstone
setblock 446 155 504 minecraft:polished_blackstone_bricks
fill 447 155 464 450 155 464 minecraft:blackstone
fill 447 155 504 450 155 504 minecraft:blackstone
setblock 451 155 464 minecraft:polished_blackstone_bricks
setblock 451 155 504 minecraft:polished_blackstone_bricks
fill 452 155 464 452 158 464 minecraft:blackstone
fill 452 155 504 452 158 504 minecraft:blackstone
setblock 456 155 464 minecraft:polished_blackstone_bricks
setblock 456 155 503 minecraft:blackstone
setblock 456 155 504 minecraft:polished_blackstone_bricks
fill 457 155 464 457 158 464 minecraft:blackstone
setblock 457 155 503 minecraft:polished_blackstone_bricks
fill 457 155 504 457 158 504 minecraft:blackstone
fill 458 155 465 458 156 465 minecraft:blackstone
fill 458 155 503 458 158 503 minecraft:blackstone
fill 459 155 502 459 158 502 minecraft:blackstone
setblock 460 155 465 minecraft:polished_blackstone_bricks
setblock 461 155 464 minecraft:polished_blackstone_bricks
fill 461 155 465 461 158 465 minecraft:blackstone
setblock 461 155 504 minecraft:polished_blackstone_bricks
fill 462 155 464 462 158 464 minecraft:blackstone
fill 462 155 499 462 157 499 minecraft:blackstone
setblock 462 155 503 minecraft:polished_blackstone_bricks
fill 462 155 504 462 158 504 minecraft:blackstone
setblock 463 155 482 minecraft:polished_blackstone_bricks
fill 463 155 483 463 157 484 minecraft:blackstone
setblock 463 155 497 minecraft:polished_blackstone_bricks
fill 463 155 498 463 158 498 minecraft:blackstone
setblock 463 155 502 minecraft:polished_blackstone_bricks
fill 463 155 503 463 158 503 minecraft:blackstone
setblock 464 155 466 minecraft:polished_blackstone_bricks
fill 464 155 467 464 158 467 minecraft:blackstone
setblock 464 155 476 minecraft:polished_blackstone_bricks
fill 464 155 477 464 156 477 minecraft:blackstone
setblock 464 155 481 minecraft:polished_blackstone_bricks
fill 464 155 482 464 158 482 minecraft:blackstone
setblock 464 155 486 minecraft:polished_blackstone_bricks
fill 464 155 487 464 158 487 minecraft:blackstone
setblock 464 155 491 minecraft:polished_blackstone_bricks
fill 464 155 492 464 158 492 minecraft:blackstone
setblock 464 155 496 minecraft:polished_blackstone_bricks
fill 464 155 497 464 158 497 minecraft:blackstone
setblock 464 155 501 minecraft:polished_blackstone_bricks
fill 464 155 502 464 158 502 minecraft:blackstone
setblock 424 156 465 minecraft:polished_blackstone_bricks
fill 424 156 466 424 159 466 minecraft:blackstone
setblock 424 156 480 minecraft:polished_blackstone_bricks
fill 424 156 481 424 159 481 minecraft:blackstone
setblock 424 156 485 minecraft:polished_blackstone_bricks
fill 424 156 486 424 159 486 minecraft:blackstone
setblock 424 156 490 minecraft:polished_blackstone_bricks
fill 424 156 491 424 159 491 minecraft:blackstone
setblock 424 156 495 minecraft:polished_blackstone_bricks
fill 424 156 496 424 159 496 minecraft:blackstone
setblock 424 156 500 minecraft:polished_blackstone_bricks
fill 424 156 501 424 159 501 minecraft:blackstone
setblock 425 156 464 minecraft:polished_blackstone_bricks
setblock 425 156 479 minecraft:polished_blackstone_bricks
fill 425 156 480 425 159 480 minecraft:blackstone
setblock 425 156 484 minecraft:polished_blackstone_bricks
fill 425 156 485 425 159 485 minecraft:blackstone
setblock 425 156 489 minecraft:polished_blackstone_bricks
fill 425 156 490 425 159 490 minecraft:blackstone
setblock 425 156 499 minecraft:polished_blackstone_bricks
fill 425 156 500 425 158 500 minecraft:blackstone
setblock 425 156 504 minecraft:polished_blackstone_bricks
fill 426 156 464 426 159 464 minecraft:blackstone
setblock 426 156 503 minecraft:polished_blackstone_bricks
fill 426 156 504 426 159 504 minecraft:blackstone
setblock 427 156 503 minecraft:blackstone
fill 437 156 504 439 156 504 minecraft:blackstone
fill 438 156 464 438 157 464 minecraft:blackstone
setblock 440 156 464 minecraft:polished_blackstone_bricks
fill 440 156 465 441 158 465 minecraft:blackstone
setblock 440 156 504 minecraft:polished_blackstone_bricks
fill 441 156 464 441 159 464 minecraft:blackstone
setblock 441 156 503 minecraft:polished_blackstone_bricks
fill 441 156 504 441 159 504 minecraft:blackstone
fill 442 156 468 444 157 468 minecraft:cyan_stained_glass
fill 442 156 503 442 159 503 minecraft:blackstone
fill 443 156 467 443 157 467 minecraft:cyan_stained_glass
fill 443 156 469 443 157 469 minecraft:cyan_stained_glass
setblock 444 156 465 minecraft:polished_blackstone_bricks
setblock 445 156 464 minecraft:polished_blackstone_bricks
fill 445 156 465 445 159 465 minecraft:blackstone
setblock 445 156 504 minecraft:polished_blackstone_bricks
fill 446 156 464 449 156 464 minecraft:blackstone
fill 446 156 504 449 156 504 minecraft:blackstone
setblock 450 156 464 minecraft:polished_blackstone_bricks
setblock 450 156 504 minecraft:polished_blackstone_bricks
fill 451 156 464 451 159 464 minecraft:blackstone
fill 451 156 504 451 159 504 minecraft:blackstone
setblock 455 156 464 minecraft:polished_blackstone_bricks
setblock 455 156 504 minecraft:polished_blackstone_bricks
fill 456 156 464 456 159 464 minecraft:blackstone
setblock 456 156 503 minecraft:polished_blackstone_bricks
fill 456 156 504 456 159 504 minecraft:blackstone
fill 457 156 465 457 157 465 minecraft:blackstone
fill 457 156 503 457 159 503 minecraft:blackstone
setblock 459 156 464 minecraft:blackstone
setblock 459 156 465 minecraft:polished_blackstone_bricks
setblock 460 156 464 minecraft:polished_blackstone_bricks
fill 460 156 465 460 159 465 minecraft:blackstone
setblock 460 156 504 minecraft:polished_blackstone_bricks
fill 461 156 464 461 159 464 minecraft:blackstone
setblock 461 156 503 minecraft:polished_blackstone_bricks
fill 461 156 504 461 159 504 minecraft:blackstone
setblock 462 156 502 minecraft:polished_blackstone_bricks
fill 462 156 503 462 159 503 minecraft:blackstone
setblock 463 156 466 minecraft:polished_blackstone_bricks
setblock 463 156 481 minecraft:polished_blackstone_bricks
fill 463 156 482 463 159 482 minecraft:blackstone
setblock 463 156 485 minecraft:blackstone
fill 463 156 497 463 159 497 minecraft:blackstone
setblock 463 156 501 minecraft:polished_blackstone_bricks
fill 463 156 502 463 159 502 minecraft:blackstone
setblock 464 156 465 minecraft:polished_blackstone_bricks
fill 464 156 466 464 159 466 minecraft:blackstone
setblock 464 156 480 minecraft:polished_blackstone_bricks
fill 464 156 481 464 159 481 minecraft:blackstone
setblock 464 156 485 minecraft:polished_blackstone_bricks
fill 464 156 486 464 159 486 minecraft:blackstone
setblock 464 156 490 minecraft:polished_blackstone_bricks
fill 464 156 491 464 159 491 minecraft:blackstone
setblock 464 156 495 minecraft:polished_blackstone_bricks
fill 464 156 496 464 159 496 minecraft:blackstone
setblock 464 156 500 minecraft:polished_blackstone_bricks
fill 464 156 501 464 159 501 minecraft:blackstone
setblock 424 157 464 minecraft:polished_blackstone_bricks
fill 424 157 465 424 160 465 minecraft:blackstone
setblock 424 157 479 minecraft:polished_blackstone_bricks
fill 424 157 480 424 160 480 minecraft:blackstone
setblock 424 157 484 minecraft:polished_blackstone_bricks
fill 424 157 485 424 160 485 minecraft:blackstone
setblock 424 157 489 minecraft:polished_blackstone_bricks
fill 424 157 490 424 160 490 minecraft:blackstone
setblock 424 157 494 minecraft:polished_blackstone_bricks
fill 424 157 495 424 160 495 minecraft:blackstone
setblock 424 157 499 minecraft:polished_blackstone_bricks
fill 424 157 500 424 160 500 minecraft:blackstone
setblock 424 157 504 minecraft:polished_blackstone_bricks
fill 425 157 464 425 160 464 minecraft:blackstone
setblock 425 157 483 minecraft:polished_blackstone_bricks
fill 425 157 484 425 160 484 minecraft:blackstone
setblock 425 157 488 minecraft:polished_blackstone_bricks
fill 425 157 489 425 160 489 minecraft:blackstone
setblock 425 157 498 minecraft:polished_blackstone_bricks
setblock 425 157 499 minecraft:blackstone
setblock 425 157 503 minecraft:polished_blackstone_bricks
fill 425 157 504 425 160 504 minecraft:blackstone
fill 426 157 503 426 158 503 minecraft:blackstone
fill 437 157 464 437 158 464 minecraft:blackstone
fill 437 157 504 438 157 504 minecraft:blackstone
setblock 439 157 464 minecraft:polished_blackstone_bricks
fill 439 157 465 439 160 465 minecraft:blackstone
setblock 439 157 504 minecraft:polished_blackstone_bricks
fill 440 157 464 440 160 464 minecraft:blackstone
fill 440 157 504 440 160 504 minecraft:blackstone
fill 441 157 503 441 160 503 minecraft:blackstone
setblock 443 157 465 minecraft:polished_blackstone_bricks
setblock 444 157 464 minecraft:polished_blackstone_bricks
fill 444 157 465 444 160 465 minecraft:blackstone
setblock 444 157 504 minecraft:polished_blackstone_bricks
fill 445 157 464 448 157 464 minecraft:blackstone
fill 445 157 504 448 157 504 minecraft:blackstone
setblock 448 157 465 minecraft:polished_blackstone_bricks
setblock 449 157 464 minecraft:polished_blackstone_bricks
setblock 449 157 504 minecraft:polished_blackstone_bricks
fill 450 157 464 450 160 464 minecraft:blackstone
fill 450 157 504 450 160 504 minecraft:blackstone
setblock 454 157 464 minecraft:polished_blackstone_bricks
setblock 454 157 504 minecraft:polished_blackstone_bricks
fill 455 157 464 455 159 465 minecraft:blackstone
setblock 455 157 503 minecraft:polished_blackstone_bricks
fill 455 157 504 455 160 504 minecraft:blackstone
fill 456 157 465 456 158 465 minecraft:blackstone
fill 456 157 503 456 160 503 minecraft:blackstone
setblock 458 157 465 minecraft:polished_blackstone_bricks
fill 458 157 502 458 159 502 minecraft:blackstone
setblock 459 157 464 minecraft:polished_blackstone_bricks
fill 459 157 465 459 160 465 minecraft:blackstone
setblock 459 157 504 minecraft:polished_blackstone_bricks
fill 460 157 464 460 160 464 minecraft:blackstone
setblock 460 157 503 minecraft:polished_blackstone_bricks
fill 460 157 504 460 160 504 minecraft:blackstone
setblock 461 157 502 minecraft:polished_blackstone_bricks
fill 461 157 503 461 160 503 minecraft:blackstone
setblock 462 157 501 minecraft:polished_blackstone_bricks
fill 462 157 502 462 160 502 minecraft:blackstone
setblock 463 157 465 minecraft:polished_blackstone_bricks
fill 463 157 466 463 159 467 minecraft:blackstone
setblock 463 157 481 minecraft:blackstone
setblock 463 157 485 minecraft:polished_blackstone_bricks
fill 463 157 486 463 159 487 minecraft:blackstone
setblock 463 157 500 minecraft:polished_blackstone_bricks
fill 463 157 501 463 160 501 minecraft:blackstone
setblock 464 157 464 minecraft:polished_blackstone_bricks
fill 464 157 465 464 160 465 minecraft:blackstone
setblock 464 157 479 minecraft:polished_blackstone_bricks
fill 464 157 480 464 160 480 minecraft:blackstone
setblock 464 157 484 minecraft:polished_blackstone_bricks
fill 464 157 485 464 160 485 minecraft:blackstone
setblock 464 157 489 minecraft:polished_blackstone_bricks
fill 464 157 490 464 160 490 minecraft:blackstone
setblock 464 157 494 minecraft:polished_blackstone_bricks
fill 464 157 495 464 160 495 minecraft:blackstone
setblock 464 157 499 minecraft:polished_blackstone_bricks
fill 464 157 500 464 160 500 minecraft:blackstone
setblock 464 157 504 minecraft:polished_blackstone_bricks
fill 424 158 464 424 161 464 minecraft:blackstone
setblock 424 158 478 minecraft:polished_blackstone_bricks
fill 424 158 479 424 161 479 minecraft:blackstone
setblock 424 158 483 minecraft:polished_blackstone_bricks
fill 424 158 484 424 161 484 minecraft:blackstone
setblock 424 158 488 minecraft:polished_blackstone_bricks
fill 424 158 489 424 161 489 minecraft:blackstone
setblock 424 158 493 minecraft:polished_blackstone_bricks
fill 424 158 494 424 161 494 minecraft:blackstone
setblock 424 158 498 minecraft:polished_blackstone_bricks
fill 424 158 499 424 161 499 minecraft:blackstone
setblock 424 158 503 minecraft:polished_blackstone_bricks
fill 424 158 504 424 161 504 minecraft:blackstone
setblock 425 158 482 minecraft:polished_blackstone_bricks
fill 425 158 483 425 161 483 minecraft:blackstone
setblock 425 158 487 minecraft:polished_blackstone_bricks
fill 425 158 488 425 161 488 minecraft:blackstone
setblock 425 158 491 minecraft:blackstone
setblock 425 158 502 minecraft:polished_blackstone_bricks
fill 425 158 503 425 160 503 minecraft:blackstone
setblock 426 158 485 minecraft:blackstone
setblock 428 158 504 minecraft:polished_blackstone_bricks
fill 435 158 464 436 159 464 minecraft:blackstone
fill 436 158 504 437 158 504 minecraft:blackstone
setblock 438 158 464 minecraft:polished_blackstone_bricks
fill 438 158 465 438 161 465 minecraft:blackstone
setblock 438 158 504 minecraft:polished_blackstone_bricks
fill 439 158 464 439 161 464 minecraft:blackstone
fill 439 158 504 439 161 504 minecraft:blackstone
fill 440 158 503 440 161 503 minecraft:blackstone
setblock 441 158 466 minecraft:polished_blackstone_bricks
setblock 442 158 464 minecraft:blackstone
setblock 442 158 465 minecraft:polished_blackstone_bricks
fill 442 158 466 444 159 466 minecraft:blackstone
setblock 443 158 464 minecraft:polished_blackstone_bricks
fill 443 158 465 443 161 465 minecraft:blackstone
setblock 443 158 504 minecraft:polished_blackstone_bricks
fill 444 158 464 447 158 464 minecraft:blackstone
fill 444 158 504 447 158 504 minecraft:blackstone
setblock 447 158 465 minecraft:polished_blackstone_bricks
setblock 448 158 464 minecraft:polished_blackstone_bricks
fill 448 158 465 450 159 465 minecraft:blackstone
setblock 448 158 504 minecraft:polished_blackstone_bricks
fill 449 158 464 449 161 464 minecraft:blackstone
fill 449 158 504 449 161 504 minecraft:blackstone
setblock 453 158 464 minecraft:polished_blackstone_bricks
fill 453 158 465 454 160 465 minecraft:blackstone
setblock 453 158 504 minecraft:polished_blackstone_bricks
fill 454 158 464 454 161 464 minecraft:blackstone
fill 454 158 504 454 161 504 minecraft:blackstone
fill 455 158 503 455 161 503 minecraft:blackstone
setblock 457 158 465 minecraft:polished_blackstone_bricks
setblock 458 158 464 minecraft:polished_blackstone_bricks
fill 458 158 465 458 161 465 minecraft:blackstone
setblock 458 158 504 minecraft:polished_blackstone_bricks
fill 459 158 464 459 161 464 minecraft:blackstone
fill 459 158 466 460 158 466 minecraft:blackstone
setblock 459 158 503 minecraft:polished_blackstone_bricks
fill 459 158 504 459 161 504 minecraft:blackstone
setblock 460 158 502 minecraft:polished_blackstone_bricks
fill 460 158 503 460 161 503 minecraft:blackstone
setblock 461 158 466 minecraft:polished_blackstone_bricks
fill 461 158 502 461 161 502 minecraft:blackstone
setblock 462 158 465 minecraft:polished_blackstone_bricks
setblock 462 158 500 minecraft:polished_blackstone_bricks
fill 462 158 501 462 161 501 minecraft:blackstone
setblock 463 158 464 minecraft:polished_blackstone_bricks
fill 463 158 465 463 161 465 minecraft:blackstone
setblock 463 158 483 minecraft:blackstone
setblock 463 158 484 minecraft:polished_blackstone_bricks
fill 463 158 485 463 161 485 minecraft:blackstone
setblock 463 158 488 minecraft:blackstone
setblock 463 158 489 minecraft:polished_blackstone_bricks
setblock 463 158 499 minecraft:polished_blackstone_bricks
fill 463 158 500 463 161 500 minecraft:blackstone
setblock 463 158 504 minecraft:polished_blackstone_bricks
fill 464 158 464 464 161 464 minecraft:blackstone
setblock 464 158 468 minecraft:polished_blackstone_bricks
fill 464 158 469 464 161 469 minecraft:blackstone
fill 464 158 479 464 159 479 minecraft:blackstone
setblock 464 158 483 minecraft:polished_blackstone_bricks
fill 464 158 484 464 161 484 minecraft:blackstone
setblock 464 158 488 minecraft:polished_blackstone_bricks
fill 464 158 489 464 161 489 minecraft:blackstone
setblock 464 158 493 minecraft:polished_blackstone_bricks
fill 464 158 494 464 161 494 minecraft:blackstone
setblock 464 158 498 minecraft:polished_blackstone_bricks
fill 464 158 499 464 161 499 minecraft:blackstone
setblock 464 158 503 minecraft:polished_blackstone_bricks
fill 464 158 504 464 161 504 minecraft:blackstone
setblock 424 159 467 minecraft:polished_blackstone_bricks
fill 424 159 478 424 162 478 minecraft:blackstone
setblock 424 159 482 minecraft:polished_blackstone_bricks
fill 424 159 483 424 162 483 minecraft:blackstone
setblock 424 159 487 minecraft:polished_blackstone_bricks
fill 424 159 488 424 162 488 minecraft:blackstone
setblock 424 159 492 minecraft:polished_blackstone_bricks
fill 424 159 493 424 162 493 minecraft:blackstone
setblock 424 159 497 minecraft:polished_blackstone_bricks
fill 424 159 498 424 162 498 minecraft:blackstone
setblock 424 159 502 minecraft:polished_blackstone_bricks
fill 424 159 503 424 162 503 minecraft:blackstone
setblock 425 159 481 minecraft:polished_blackstone_bricks
fill 425 159 482 425 162 482 minecraft:blackstone
setblock 425 159 486 minecraft:polished_blackstone_bricks
fill 425 159 487 426 161 487 minecraft:blackstone
setblock 425 159 491 minecraft:polished_blackstone_bricks
fill 425 159 492 425 162 492 minecraft:blackstone
setblock 425 159 501 minecraft:polished_blackstone_bricks
setblock 425 159 502 minecraft:blackstone
setblock 426 159 484 minecraft:blackstone
setblock 426 159 485 minecraft:polished_blackstone_bricks
fill 426 159 486 426 162 486 minecraft:blackstone
setblock 427 159 504 minecraft:polished_blackstone_bricks
setblock 428 159 504 minecraft:blackstone
fill 434 159 464 434 161 464 minecraft:blackstone
fill 435 159 504 436 159 504 minecraft:blackstone
setblock 436 159 465 minecraft:polished_blackstone_bricks
setblock 437 159 464 minecraft:polished_blackstone_bricks
fill 437 159 465 437 162 465 minecraft:blackstone
setblock 437 159 504 minecraft:polished_blackstone_bricks
fill 438 159 464 438 162 464 minecraft:blackstone
fill 438 159 504 438 162 504 minecraft:blackstone
setblock 439 159 466 minecraft:blackstone
fill 439 159 503 439 162 503 minecraft:blackstone
setblock 440 159 465 minecraft:blackstone
setblock 440 159 466 minecraft:polished_blackstone_bricks
setblock 441 159 465 minecraft:polished_blackstone_bricks
fill 441 159 466 441 162 466 minecraft:blackstone
setblock 442 159 464 minecraft:polished_blackstone_bricks
fill 442 159 465 442 162 465 minecraft:blackstone
setblock 442 159 504 minecraft:polished_blackstone_bricks
fill 443 159 464 446 159 464 minecraft:blackstone
setblock 443 159 503 minecraft:polished_blackstone_bricks
fill 443 159 504 446 159 504 minecraft:blackstone
setblock 445 159 466 minecraft:polished_blackstone_bricks
setblock 446 159 465 minecraft:polished_blackstone_bricks
setblock 447 159 464 minecraft:polished_blackstone_bricks
fill 447 159 465 447 162 465 minecraft:blackstone
setblock 447 159 504 minecraft:polished_blackstone_bricks
fill 448 159 464 448 162 464 minecraft:blackstone
fill 448 159 504 448 162 504 minecraft:blackstone
setblock 451 159 465 minecraft:polished_blackstone_bricks
setblock 452 159 464 minecraft:polished_blackstone_bricks
fill 452 159 465 452 162 465 minecraft:blackstone
setblock 452 159 504 minecraft:polished_blackstone_bricks
fill 453 159 464 453 162 464 minecraft:blackstone
fill 453 159 504 453 162 504 minecraft:blackstone
fill 454 159 503 454 162 503 minecraft:blackstone
setblock 456 159 465 minecraft:polished_blackstone_bricks
setblock 457 159 464 minecraft:polished_blackstone_bricks
fill 457 159 465 457 161 466 minecraft:blackstone
fill 457 159 502 457 160 502 minecraft:blackstone
setblock 457 159 504 minecraft:polished_blackstone_bricks
fill 458 159 464 458 162 464 minecraft:blackstone
fill 458 159 466 459 159 466 minecraft:blackstone
setblock 458 159 503 minecraft:polished_blackstone_bricks
fill 458 159 504 458 162 504 minecraft:blackstone
setblock 459 159 502 minecraft:polished_blackstone_bricks
fill 459 159 503 459 162 503 minecraft:blackstone
setblock 460 159 466 minecraft:polished_blackstone_bricks
fill 460 159 502 460 162 502 minecraft:blackstone
setblock 461 159 465 minecraft:polished_blackstone_bricks
fill 461 159 466 462 161 466 minecraft:blackstone
setblock 462 159 464 minecraft:polished_blackstone_bricks
fill 462 159 465 462 162 465 minecraft:blackstone
fill 462 159 500 462 162 500 minecraft:blackstone
setblock 462 159 504 minecraft:polished_blackstone_bricks
fill 463 159 464 463 162 464 minecraft:blackstone
setblock 463 159 468 minecraft:polished_blackstone_bricks
setblock 463 159 483 minecraft:polished_blackstone_bricks
fill 463 159 484 463 162 484 minecraft:blackstone
setblock 463 159 488 minecraft:polished_blackstone_bricks
fill 463 159 489 463 159 492 minecraft:blackstone
fill 463 159 496 463 160 496 minecraft:blackstone
setblock 463 159 498 minecraft:polished_blackstone_bricks
fill 463 159 499 463 162 499 minecraft:blackstone
setblock 463 159 503 minecraft:polished_blackstone_bricks
fill 463 159 504 463 162 504 minecraft:blackstone
setblock 464 159 467 minecraft:polished_blackstone_bricks
fill 464 159 468 464 162 468 minecraft:blackstone
setblock 464 159 482 minecraft:polished_blackstone_bricks
fill 464 159 483 464 162 483 minecraft:blackstone
setblock 464 159 487 minecraft:polished_blackstone_bricks
fill 464 159 488 464 162 488 minecraft:blackstone
setblock 464 159 492 minecraft:polished_blackstone_bricks
fill 464 159 493 464 162 493 minecraft:blackstone
setblock 464 159 497 minecraft:polished_blackstone_bricks
fill 464 159 498 464 162 498 minecraft:blackstone
setblock 464 159 502 minecraft:polished_blackstone_bricks
fill 464 159 503 464 162 503 minecraft:blackstone
setblock 424 160 466 minecraft:polished_blackstone_bricks
fill 424 160 467 424 162 468 minecraft:blackstone
setblock 424 160 481 minecraft:polished_blackstone_bricks
fill 424 160 482 424 163 482 minecraft:blackstone
setblock 424 160 486 minecraft:polished_blackstone_bricks
fill 424 160 487 424 163 487 minecraft:blackstone
setblock 424 160 491 minecraft:polished_blackstone_bricks
fill 424 160 492 424 163 492 minecraft:blackstone
setblock 424 160 496 minecraft:polished_blackstone_bricks
fill 424 160 497 424 163 497 minecraft:blackstone
setblock 424 160 501 minecraft:polished_blackstone_bricks
fill 424 160 502 424 163 502 minecraft:blackstone
fill 425 160 481 425 162 481 minecraft:blackstone
setblock 425 160 485 minecraft:polished_blackstone_bricks
fill 425 160 486 425 163 486 minecraft:blackstone
setblock 425 160 490 minecraft:polished_blackstone_bricks
fill 425 160 491 425 163 491 minecraft:blackstone
setblock 426 160 464 minecraft:polished_blackstone_bricks
setblock 426 160 466 minecraft:light[level=11]
setblock 426 160 474 minecraft:light[level=11]
setblock 426 160 482 minecraft:light[level=11]
setblock 426 160 484 minecraft:polished_blackstone_bricks
fill 426 160 485 426 163 485 minecraft:blackstone
setblock 426 160 488 minecraft:blackstone
setblock 426 160 490 minecraft:light[level=11]
setblock 426 160 498 minecraft:light[level=11]
setblock 426 160 504 minecraft:polished_blackstone_bricks
fill 427 160 504 427 161 504 minecraft:blackstone
fill 433 160 464 433 162 464 minecraft:blackstone
setblock 434 160 466 minecraft:light[level=11]
setblock 434 160 474 minecraft:light[level=11]
setblock 434 160 482 minecraft:light[level=11]
setblock 434 160 490 minecraft:light[level=11]
setblock 434 160 498 minecraft:light[level=11]
fill 434 160 504 435 160 504 minecraft:blackstone
setblock 435 160 464 minecraft:blackstone
setblock 435 160 465 minecraft:polished_blackstone_bricks
setblock 436 160 464 minecraft:polished_blackstone_bricks
fill 436 160 465 436 163 465 minecraft:blackstone
setblock 436 160 504 minecraft:polished_blackstone_bricks
fill 437 160 464 437 163 464 minecraft:blackstone
fill 437 160 466 438 160 466 minecraft:blackstone
fill 437 160 504 437 163 504 minecraft:blackstone
setblock 439 160 466 minecraft:polished_blackstone_bricks
setblock 440 160 465 minecraft:polished_blackstone_bricks
fill 440 160 466 440 163 466 minecraft:blackstone
setblock 441 160 464 minecraft:polished_blackstone_bricks
fill 441 160 465 441 163 465 minecraft:blackstone
setblock 441 160 504 minecraft:polished_blackstone_bricks
fill 442 160 464 445 160 464 minecraft:blackstone
fill 442 160 466 443 160 466 minecraft:blackstone
setblock 442 160 474 minecraft:light[level=11]
setblock 442 160 482 minecraft:light[level=11]
setblock 442 160 490 minecraft:light[level=11]
setblock 442 160 498 minecraft:light[level=11]
setblock 442 160 503 minecraft:polished_blackstone_bricks
fill 442 160 504 445 160 504 minecraft:blackstone
fill 443 160 503 443 161 503 minecraft:blackstone
setblock 444 160 466 minecraft:polished_blackstone_bricks
setblock 445 160 465 minecraft:polished_blackstone_bricks
fill 445 160 466 446 162 466 minecraft:blackstone
setblock 446 160 464 minecraft:polished_blackstone_bricks
fill 446 160 465 446 163 465 minecraft:blackstone
setblock 446 160 504 minecraft:polished_blackstone_bricks
fill 447 160 464 447 163 464 minecraft:blackstone
fill 447 160 504 447 163 504 minecraft:blackstone
fill 448 160 465 449 160 465 minecraft:blackstone
setblock 450 160 465 minecraft:polished_blackstone_bricks
setblock 450 160 466 minecraft:light[level=11]
setblock 450 160 474 minecraft:light[level=11]
setblock 450 160 482 minecraft:light[level=11]
setblock 450 160 490 minecraft:light[level=11]
setblock 450 160 498 minecraft:light[level=11]
setblock 451 160 464 minecraft:polished_blackstone_bricks
fill 451 160 465 451 163 465 minecraft:blackstone
setblock 451 160 504 minecraft:polished_blackstone_bricks
fill 452 160 464 452 163 464 minecraft:blackstone
fill 452 160 504 452 163 504 minecraft:blackstone
fill 453 160 503 453 163 503 minecraft:blackstone
setblock 454 160 466 minecraft:polished_blackstone_bricks
setblock 455 160 464 minecraft:blackstone
setblock 455 160 465 minecraft:polished_blackstone_bricks
fill 455 160 466 456 162 466 minecraft:blackstone
setblock 456 160 464 minecraft:polished_blackstone_bricks
fill 456 160 465 456 163 465 minecraft:blackstone
setblock 456 160 504 minecraft:polished_blackstone_bricks
fill 457 160 464 457 163 464 minecraft:blackstone
setblock 457 160 503 minecraft:polished_blackstone_bricks
fill 457 160 504 457 163 504 minecraft:blackstone
setblock 458 160 466 minecraft:blackstone
setblock 458 160 474 minecraft:light[level=11]
setblock 458 160 482 minecraft:light[level=11]
setblock 458 160 490 minecraft:light[level=11]
setblock 458 160 498 minecraft:light[level=11]
setblock 458 160 502 minecraft:polished_blackstone_bricks
fill 458 160 503 458 163 503 minecraft:blackstone
setblock 459 160 466 minecraft:polished_blackstone_bricks
fill 459 160 502 459 163 502 minecraft:blackstone
setblock 460 160 465 minecraft:polished_blackstone_bricks
fill 460 160 466 460 163 466 minecraft:blackstone
setblock 461 160 464 minecraft:polished_blackstone_bricks
fill 461 160 465 461 163 465 minecraft:blackstone
setblock 461 160 504 minecraft:polished_blackstone_bricks
fill 462 160 464 462 163 464 minecraft:blackstone
setblock 462 160 467 minecraft:blackstone
fill 462 160 485 462 160 487 minecraft:blackstone
setblock 462 160 488 minecraft:polished_blackstone_bricks
setblock 462 160 503 minecraft:polished_blackstone_bricks
fill 462 160 504 462 163 504 minecraft:blackstone
setblock 463 160 466 minecraft:blackstone
setblock 463 160 467 minecraft:polished_blackstone_bricks
fill 463 160 468 463 163 468 minecraft:blackstone
setblock 463 160 482 minecraft:polished_blackstone_bricks
fill 463 160 483 463 163 483 minecraft:blackstone
setblock 463 160 486 minecraft:blackstone
setblock 463 160 487 minecraft:polished_blackstone_bricks
fill 463 160 488 463 160 491 minecraft:blackstone
setblock 463 160 492 minecraft:polished_blackstone_bricks
fill 463 160 493 463 161 495 minecraft:blackstone
setblock 463 160 497 minecraft:polished_blackstone_bricks
fill 463 160 498 463 163 498 minecraft:blackstone
setblock 463 160 502 minecraft:polished_blackstone_bricks
fill 463 160 503 463 163 503 minecraft:blackstone
setblock 464 160 466 minecraft:polished_blackstone_bricks
fill 464 160 467 464 163 467 minecraft:blackstone
setblock 464 160 470 minecraft:blackstone
setblock 464 160 481 minecraft:polished_blackstone_bricks
fill 464 160 482 464 163 482 minecraft:blackstone
setblock 464 160 486 minecraft:polished_blackstone_bricks
fill 464 160 487 464 163 487 minecraft:blackstone
setblock 464 160 491 minecraft:polished_blackstone_bricks
fill 464 160 492 464 163 492 minecraft:blackstone
setblock 464 160 496 minecraft:polished_blackstone_bricks
fill 464 160 497 464 163 497 minecraft:blackstone
setblock 464 160 501 minecraft:polished_blackstone_bricks
fill 464 160 502 464 163 502 minecraft:blackstone
setblock 424 161 465 minecraft:polished_blackstone_bricks
fill 424 161 466 424 164 466 minecraft:blackstone
setblock 424 161 469 minecraft:blackstone
setblock 424 161 480 minecraft:polished_blackstone_bricks
fill 424 161 481 424 164 481 minecraft:blackstone
setblock 424 161 485 minecraft:polished_blackstone_bricks
fill 424 161 486 424 164 486 minecraft:blackstone
setblock 424 161 490 minecraft:polished_blackstone_bricks
fill 424 161 491 424 164 491 minecraft:blackstone
setblock 424 161 495 minecraft:polished_blackstone_bricks
fill 424 161 496 424 164 496 minecraft:blackstone
setblock 424 161 500 minecraft:polished_blackstone_bricks
fill 424 161 501 424 163 501 minecraft:blackstone
setblock 425 161 464 minecraft:polished_blackstone_bricks
setblock 425 161 484 minecraft:polished_blackstone_bricks
fill 425 161 485 425 164 485 minecraft:blackstone
setblock 425 161 489 minecraft:polished_blackstone_bricks
fill 425 161 490 425 164 490 minecraft:blackstone
setblock 425 161 493 minecraft:blackstone
setblock 425 161 504 minecraft:polished_blackstone_bricks
fill 426 161 464 427 163 464 minecraft:blackstone
fill 426 161 484 426 162 484 minecraft:blackstone
setblock 426 161 488 minecraft:polished_blackstone_bricks
fill 426 161 489 426 164 489 minecraft:blackstone
fill 426 161 504 426 162 504 minecraft:blackstone
fill 431 161 464 432 163 464 minecraft:blackstone
setblock 434 161 465 minecraft:polished_blackstone_bricks
setblock 434 161 504 minecraft:blackstone
setblock 435 161 464 minecraft:polished_blackstone_bricks
fill 435 161 465 435 164 465 minecraft:blackstone
setblock 435 161 504 minecraft:polished_blackstone_bricks
fill 436 161 464 436 164 464 minecraft:blackstone
fill 436 161 466 437 161 466 minecraft:blackstone
fill 436 161 504 436 164 504 minecraft:blackstone
setblock 438 161 466 minecraft:polished_blackstone_bricks
fill 438 161 503 438 163 503 minecraft:blackstone
setblock 439 161 465 minecraft:polished_blackstone_bricks
fill 439 161 466 439 163 467 minecraft:blackstone
setblock 440 161 464 minecraft:polished_blackstone_bricks
fill 440 161 465 440 164 465 minecraft:blackstone
fill 440 161 467 441 161 467 minecraft:blackstone
setblock 440 161 504 minecraft:polished_blackstone_bricks
fill 441 161 464 444 161 464 minecraft:blackstone
setblock 441 161 503 minecraft:polished_blackstone_bricks
fill 441 161 504 444 161 504 minecraft:blackstone
setblock 442 161 466 minecraft:blackstone
setblock 442 161 467 minecraft:polished_blackstone_bricks
fill 442 161 503 442 162 503 minecraft:blackstone
setblock 443 161 466 minecraft:polished_blackstone_bricks
fill 443 161 467 443 164 467 minecraft:blackstone
setblock 444 161 465 minecraft:polished_blackstone_bricks
fill 444 161 466 444 164 466 minecraft:blackstone
setblock 445 161 464 minecraft:polished_blackstone_bricks
fill 445 161 465 445 164 465 minecraft:blackstone
setblock 445 161 504 minecraft:polished_blackstone_bricks
fill 446 161 464 446 164 464 minecraft:blackstone
fill 446 161 504 446 164 504 minecraft:blackstone
setblock 447 161 466 minecraft:blackstone
setblock 448 161 465 minecraft:blackstone
setblock 449 161 465 minecraft:polished_blackstone_bricks
setblock 450 161 464 minecraft:polished_blackstone_bricks
fill 450 161 465 450 164 465 minecraft:blackstone
setblock 450 161 504 minecraft:polished_blackstone_bricks
fill 451 161 464 451 164 464 minecraft:blackstone
fill 451 161 504 451 164 504 minecraft:blackstone
setblock 452 161 466 minecraft:blackstone
setblock 453 161 465 minecraft:blackstone
setblock 453 161 466 minecraft:polished_blackstone_bricks
setblock 454 161 465 minecraft:polished_blackstone_bricks
fill 454 161 466 454 164 466 minecraft:blackstone
setblock 455 161 464 minecraft:polished_blackstone_bricks
fill 455 161 465 455 164 465 minecraft:blackstone
setblock 455 161 504 minecraft:polished_blackstone_bricks
fill 456 161 464 456 164 464 minecraft:blackstone
setblock 456 161 502 minecraft:blackstone
setblock 456 161 503 minecraft:polished_blackstone_bricks
fill 456 161 504 456 164 504 minecraft:blackstone
setblock 457 161 502 minecraft:polished_blackstone_bricks
fill 457 161 503 457 164 503 minecraft:blackstone
setblock 458 161 466 minecraft:polished_blackstone_bricks
fill 458 161 502 458 164 502 minecraft:blackstone
setblock 459 161 465 minecraft:polished_blackstone_bricks
fill 459 161 466 459 164 466 minecraft:blackstone
setblock 460 161 464 minecraft:polished_blackstone_bricks
fill 460 161 465 460 164 465 minecraft:blackstone
setblock 460 161 504 minecraft:polished_blackstone_bricks
fill 461 161 464 461 164 464 minecraft:blackstone
setblock 461 161 503 minecraft:polished_blackstone_bricks
fill 461 161 504 461 164 504 minecraft:blackstone
setblock 462 161 467 minecraft:polished_blackstone_bricks
fill 462 161 484 462 161 486 minecraft:blackstone
setblock 462 161 487 minecraft:polished_blackstone_bricks
fill 462 161 488 462 161 491 minecraft:blackstone
setblock 462 161 502 minecraft:polished_blackstone_bricks
fill 462 161 503 462 164 503 minecraft:blackstone
setblock 463 161 466 minecraft:polished_blackstone_bricks
fill 463 161 467 463 164 467 minecraft:blackstone
fill 463 161 469 463 162 469 minecraft:blackstone
fill 463 161 482 463 162 482 minecraft:blackstone
setblock 463 161 486 minecraft:polished_blackstone_bricks
fill 463 161 487 463 161 490 minecraft:blackstone
setblock 463 161 491 minecraft:polished_blackstone_bricks
fill 463 161 492 463 164 492 minecraft:blackstone
setblock 463 161 496 minecraft:polished_blackstone_bricks
fill 463 161 497 463 164 497 minecraft:blackstone
setblock 463 161 501 minecraft:polished_blackstone_bricks
fill 463 161 502 463 164 502 minecraft:blackstone
setblock 464 161 465 minecraft:polished_blackstone_bricks
fill 464 161 466 464 164 466 minecraft:blackstone
setblock 464 161 470 minecraft:polished_blackstone_bricks
setblock 464 161 480 minecraft:polished_blackstone_bricks
fill 464 161 481 464 163 481 minecraft:blackstone
setblock 464 161 485 minecraft:polished_blackstone_bricks
fill 464 161 486 464 164 486 minecraft:blackstone
setblock 464 161 490 minecraft:polished_blackstone_bricks
fill 464 161 491 464 164 491 minecraft:blackstone
setblock 464 161 495 minecraft:polished_blackstone_bricks
fill 464 161 496 464 164 496 minecraft:blackstone
setblock 464 161 500 minecraft:polished_blackstone_bricks
fill 464 161 501 464 164 501 minecraft:blackstone
setblock 424 162 464 minecraft:polished_blackstone_bricks
fill 424 162 465 424 165 465 minecraft:blackstone
setblock 424 162 469 minecraft:polished_blackstone_bricks
fill 424 162 470 424 165 470 minecraft:blackstone
setblock 424 162 479 minecraft:polished_blackstone_bricks
fill 424 162 480 424 165 480 minecraft:blackstone
setblock 424 162 484 minecraft:polished_blackstone_bricks
fill 424 162 485 424 165 485 minecraft:blackstone
setblock 424 162 489 minecraft:polished_blackstone_bricks
fill 424 162 490 424 165 490 minecraft:blackstone
setblock 424 162 494 minecraft:polished_blackstone_bricks
fill 424 162 495 424 165 495 minecraft:blackstone
setblock 424 162 499 minecraft:polished_blackstone_bricks
fill 424 162 500 424 163 500 minecraft:blackstone
setblock 424 162 504 minecraft:polished_blackstone_bricks
fill 425 162 464 425 164 464 minecraft:blackstone
setblock 425 162 483 minecraft:polished_blackstone_bricks
fill 425 162 484 425 165 484 minecraft:blackstone
setblock 425 162 487 minecraft:blackstone
setblock 425 162 488 minecraft:polished_blackstone_bricks
fill 425 162 489 425 165 489 minecraft:blackstone
setblock 425 162 493 minecraft:polished_blackstone_bricks
fill 425 162 504 425 163 504 minecraft:blackstone
setblock 426 162 487 minecraft:polished_blackstone_bricks
fill 426 162 488 426 167 488 minecraft:blackstone
fill 426 162 490 426 163 490 minecraft:blackstone
setblock 429 162 464 minecraft:polished_blackstone_bricks
fill 430 162 464 430 165 464 minecraft:blackstone
setblock 433 162 465 minecraft:polished_blackstone_bricks
setblock 433 162 504 minecraft:blackstone
setblock 434 162 464 minecraft:polished_blackstone_bricks
fill 434 162 465 434 165 465 minecraft:blackstone
setblock 434 162 504 minecraft:polished_blackstone_bricks
fill 435 162 464 435 165 464 minecraft:blackstone
fill 435 162 466 436 162 466 minecraft:blackstone
fill 435 162 504 435 165 504 minecraft:blackstone
setblock 437 162 466 minecraft:polished_blackstone_bricks
fill 437 162 467 438 164 467 minecraft:blackstone
setblock 438 162 465 minecraft:polished_blackstone_bricks
fill 438 162 466 438 165 466 minecraft:blackstone
setblock 439 162 464 minecraft:polished_blackstone_bricks
fill 439 162 465 439 165 465 minecraft:blackstone
setblock 439 162 504 minecraft:polished_blackstone_bricks
fill 440 162 464 443 162 464 minecraft:blackstone
setblock 440 162 467 minecraft:blackstone
setblock 440 162 503 minecraft:polished_blackstone_bricks
fill 440 162 504 443 162 504 minecraft:blackstone
setblock 441 162 467 minecraft:polished_blackstone_bricks
setblock 441 162 503 minecraft:blackstone
setblock 442 162 466 minecraft:polished_blackstone_bricks
fill 442 162 467 442 165 467 minecraft:blackstone
setblock 443 162 465 minecraft:polished_blackstone_bricks
fill 443 162 466 443 165 466 minecraft:blackstone
setblock 444 162 464 minecraft:polished_blackstone_bricks
fill 444 162 465 444 165 465 minecraft:blackstone
setblock 444 162 504 minecraft:polished_blackstone_bricks
fill 445 162 464 445 165 464 minecraft:blackstone
fill 445 162 504 445 164 504 minecraft:blackstone
setblock 447 162 466 minecraft:polished_blackstone_bricks
setblock 448 162 465 minecraft:polished_blackstone_bricks
fill 448 162 466 451 162 466 minecraft:blackstone
setblock 449 162 464 minecraft:polished_blackstone_bricks
fill 449 162 465 449 165 465 minecraft:blackstone
setblock 449 162 504 minecraft:polished_blackstone_bricks
fill 450 162 464 450 165 464 minecraft:blackstone
fill 450 162 504 450 165 504 minecraft:blackstone
setblock 452 162 466 minecraft:polished_blackstone_bricks
fill 452 162 503 452 164 503 minecraft:blackstone
setblock 453 162 465 minecraft:polished_blackstone_bricks
fill 453 162 466 453 165 466 minecraft:blackstone
setblock 454 162 464 minecraft:polished_blackstone_bricks
fill 454 162 465 454 165 465 minecraft:blackstone
setblock 454 162 504 minecraft:polished_blackstone_bricks
fill 455 162 464 455 165 464 minecraft:blackstone
setblock 455 162 503 minecraft:polished_blackstone_bricks
fill 455 162 504 455 165 504 minecraft:blackstone
setblock 456 162 467 minecraft:polished_blackstone_bricks
setblock 456 162 502 minecraft:polished_blackstone_bricks
fill 456 162 503 456 165 503 minecraft:blackstone
setblock 457 162 465 minecraft:blackstone
setblock 457 162 466 minecraft:polished_blackstone_bricks
fill 457 162 467 459 163 467 minecraft:blackstone
fill 457 162 502 457 165 502 minecraft:blackstone
setblock 458 162 465 minecraft:polished_blackstone_bricks
fill 458 162 466 458 165 466 minecraft:blackstone
setblock 459 162 464 minecraft:polished_blackstone_bricks
fill 459 162 465 459 165 465 minecraft:blackstone
setblock 459 162 504 minecraft:polished_blackstone_bricks
fill 460 162 464 460 165 464 minecraft:blackstone
setblock 460 162 503 minecraft:polished_blackstone_bricks
fill 460 162 504 460 165 504 minecraft:blackstone
setblock 461 162 466 minecraft:blackstone
setblock 461 162 502 minecraft:polished_blackstone_bricks
fill 461 162 503 461 165 503 minecraft:blackstone
setblock 462 162 466 minecraft:polished_blackstone_bricks
fill 462 162 467 462 164 467 minecraft:blackstone
setblock 462 162 485 minecraft:blackstone
setblock 462 162 486 minecraft:polished_blackstone_bricks
fill 462 162 487 462 162 490 minecraft:blackstone
setblock 462 162 491 minecraft:polished_blackstone_bricks
fill 462 162 492 462 164 493 minecraft:blackstone
setblock 462 162 501 minecraft:polished_blackstone_bricks
fill 462 162 502 462 163 502 minecraft:blackstone
setblock 463 162 465 minecraft:polished_blackstone_bricks
fill 463 162 466 463 165 466 minecraft:blackstone
setblock 463 162 485 minecraft:polished_blackstone_bricks
fill 463 162 486 463 162 489 minecraft:blackstone
setblock 463 162 490 minecraft:polished_blackstone_bricks
fill 463 162 491 463 165 491 minecraft:blackstone
fill 463 162 493 463 162 494 minecraft:blackstone
setblock 463 162 495 minecraft:polished_blackstone_bricks
fill 463 162 496 463 165 496 minecraft:blackstone
setblock 463 162 500 minecraft:polished_blackstone_bricks
fill 463 162 501 463 164 501 minecraft:blackstone
setblock 464 162 464 minecraft:polished_blackstone_bricks
fill 464 162 465 464 165 465 minecraft:blackstone
setblock 464 162 469 minecraft:polished_blackstone_bricks
fill 464 162 470 464 165 470 minecraft:blackstone
setblock 464 162 484 minecraft:polished_blackstone_bricks
fill 464 162 485 464 165 485 minecraft:blackstone
setblock 464 162 489 minecraft:polished_blackstone_bricks
fill 464 162 490 464 165 490 minecraft:blackstone
setblock 464 162 494 minecraft:polished_blackstone_bricks
fill 464 162 495 464 165 495 minecraft:blackstone
setblock 464 162 499 minecraft:polished_blackstone_bricks
fill 464 162 500 464 165 500 minecraft:blackstone
setblock 464 162 504 minecraft:polished_blackstone_bricks
fill 424 163 464 424 164 464 minecraft:blackstone
setblock 424 163 467 minecraft:blackstone
setblock 424 163 468 minecraft:polished_blackstone_bricks
fill 424 163 469 424 166 469 minecraft:blackstone
fill 424 163 471 424 164 471 minecraft:blackstone
fill 424 163 479 424 164 479 minecraft:blackstone
setblock 424 163 483 minecraft:polished_blackstone_bricks
fill 424 163 484 424 166 484 minecraft:blackstone
setblock 424 163 488 minecraft:polished_blackstone_bricks
fill 424 163 489 424 166 489 minecraft:blackstone
setblock 424 163 493 minecraft:polished_blackstone_bricks
fill 424 163 494 425 163 494 minecraft:blackstone
setblock 424 163 498 minecraft:polished_blackstone_bricks
setblock 424 163 499 minecraft:blackstone
setblock 424 163 503 minecraft:polished_blackstone_bricks
fill 424 163 504 424 164 504 minecraft:blackstone
setblock 425 163 482 minecraft:polished_blackstone_bricks
fill 425 163 483 425 164 483 minecraft:blackstone
setblock 425 163 487 minecraft:polished_blackstone_bricks
fill 425 163 488 425 166 488 minecraft:blackstone
setblock 425 163 492 minecraft:polished_blackstone_bricks
fill 425 163 493 425 166 493 minecraft:blackstone
setblock 426 163 486 minecraft:polished_blackstone_bricks
fill 426 163 487 426 167 487 minecraft:blackstone
fill 429 163 464 429 164 464 minecraft:blackstone
setblock 432 163 465 minecraft:polished_blackstone_bricks
setblock 433 163 464 minecraft:polished_blackstone_bricks
fill 433 163 465 433 166 465 minecraft:blackstone
setblock 433 163 504 minecraft:polished_blackstone_bricks
fill 434 163 464 434 166 464 minecraft:blackstone
fill 434 163 466 435 163 466 minecraft:blackstone
fill 434 163 504 434 165 504 minecraft:blackstone
setblock 436 163 466 minecraft:polished_blackstone_bricks
fill 436 163 467 436 166 467 minecraft:blackstone
setblock 437 163 465 minecraft:polished_blackstone_bricks
fill 437 163 466 437 166 466 minecraft:blackstone
setblock 438 163 464 minecraft:polished_blackstone_bricks
fill 438 163 465 438 166 465 minecraft:blackstone
setblock 438 163 504 minecraft:polished_blackstone_bricks
fill 439 163 464 442 163 464 minecraft:blackstone
setblock 439 163 503 minecraft:polished_blackstone_bricks
fill 439 163 504 442 163 504 minecraft:blackstone
setblock 440 163 467 minecraft:polished_blackstone_bricks
setblock 440 163 503 minecraft:blackstone
setblock 441 163 466 minecraft:polished_blackstone_bricks
fill 441 163 467 441 166 467 minecraft:blackstone
setblock 442 163 465 minecraft:polished_blackstone_bricks
fill 442 163 466 442 166 466 minecraft:blackstone
setblock 443 163 464 minecraft:polished_blackstone_bricks
fill 443 163 465 443 166 465 minecraft:blackstone
setblock 443 163 504 minecraft:polished_blackstone_bricks
fill 444 163 464 444 166 464 minecraft:blackstone
setblock 444 163 467 minecraft:blackstone
fill 444 163 504 444 165 504 minecraft:blackstone
setblock 445 163 466 minecraft:blackstone
setblock 446 163 466 minecraft:polished_blackstone_bricks
setblock 447 163 465 minecraft:polished_blackstone_bricks
fill 447 163 466 450 163 466 minecraft:blackstone
setblock 448 163 464 minecraft:polished_blackstone_bricks
fill 448 163 465 448 166 465 minecraft:blackstone
setblock 448 163 504 minecraft:polished_blackstone_bricks
fill 449 163 464 449 166 464 minecraft:blackstone
fill 449 163 504 449 166 504 minecraft:blackstone
setblock 451 163 466 minecraft:polished_blackstone_bricks
setblock 452 163 465 minecraft:polished_blackstone_bricks
fill 452 163 466 452 166 466 minecraft:blackstone
setblock 453 163 464 minecraft:polished_blackstone_bricks
fill 453 163 465 453 166 465 minecraft:blackstone
setblock 453 163 504 minecraft:polished_blackstone_bricks
fill 454 163 464 454 166 464 minecraft:blackstone
setblock 454 163 503 minecraft:polished_blackstone_bricks
fill 454 163 504 454 166 504 minecraft:blackstone
setblock 455 163 466 minecraft:blackstone
setblock 455 163 467 minecraft:polished_blackstone_bricks
fill 455 163 503 455 166 503 minecraft:blackstone
setblock 456 163 466 minecraft:polished_blackstone_bricks
fill 456 163 467 456 166 467 minecraft:blackstone
fill 456 163 502 456 165 502 minecraft:blackstone
setblock 457 163 465 minecraft:polished_blackstone_bricks
fill 457 163 466 457 166 466 minecraft:blackstone
setblock 458 163 464 minecraft:polished_blackstone_bricks
fill 458 163 465 458 166 465 minecraft:blackstone
setblock 458 163 504 minecraft:polished_blackstone_bricks
fill 459 163 464 459 166 464 minecraft:blackstone
setblock 459 163 503 minecraft:polished_blackstone_bricks
fill 459 163 504 459 166 504 minecraft:blackstone
setblock 460 163 502 minecraft:polished_blackstone_bricks
fill 460 163 503 460 166 503 minecraft:blackstone
setblock 461 163 466 minecraft:polished_blackstone_bricks
fill 461 163 502 461 164 502 minecraft:blackstone
setblock 462 163 465 minecraft:polished_blackstone_bricks
fill 462 163 466 462 164 466 minecraft:blackstone
setblock 462 163 485 minecraft:polished_blackstone_bricks
fill 462 163 486 462 163 489 minecraft:blackstone
setblock 462 163 490 minecraft:polished_blackstone_bricks
fill 462 163 491 462 166 491 minecraft:blackstone
setblock 462 163 494 minecraft:blackstone
setblock 462 163 501 minecraft:blackstone
setblock 463 163 464 minecraft:polished_blackstone_bricks
fill 463 163 465 463 165 465 minecraft:blackstone
setblock 463 163 469 minecraft:polished_blackstone_bricks
setblock 463 163 484 minecraft:polished_blackstone_bricks
fill 463 163 485 463 163 488 minecraft:blackstone
setblock 463 163 489 minecraft:polished_blackstone_bricks
fill 463 163 490 463 166 490 minecraft:blackstone
setblock 463 163 493 minecraft:blackstone
setblock 463 163 494 minecraft:polished_blackstone_bricks
fill 463 163 495 463 166 495 minecraft:blackstone
setblock 463 163 499 minecraft:polished_blackstone_bricks
fill 463 163 500 463 164 500 minecraft:blackstone
setblock 463 163 504 minecraft:polished_blackstone_bricks
fill 464 163 464 464 166 464 minecraft:blackstone
setblock 464 163 468 minecraft:polished_blackstone_bricks
fill 464 163 469 464 166 469 minecraft:blackstone
fill 464 163 471 464 164 471 minecraft:blackstone
setblock 464 163 483 minecraft:polished_blackstone_bricks
fill 464 163 484 464 166 484 minecraft:blackstone
setblock 464 163 488 minecraft:polished_blackstone_bricks
fill 464 163 489 464 166 489 minecraft:blackstone
setblock 464 163 493 minecraft:polished_blackstone_bricks
fill 464 163 494 464 166 494 minecraft:blackstone
setblock 464 163 498 minecraft:polished_blackstone_bricks
fill 464 163 499 464 166 499 minecraft:blackstone
setblock 464 163 503 minecraft:polished_blackstone_bricks
fill 464 163 504 464 166 504 minecraft:blackstone
setblock 424 164 467 minecraft:polished_blackstone_bricks
fill 424 164 468 424 166 468 minecraft:blackstone
setblock 424 164 482 minecraft:polished_blackstone_bricks
fill 424 164 483 424 167 483 minecraft:blackstone
setblock 424 164 487 minecraft:polished_blackstone_bricks
fill 424 164 488 424 167 488 minecraft:blackstone
setblock 424 164 492 minecraft:polished_blackstone_bricks
fill 424 164 493 424 166 494 minecraft:blackstone
setblock 424 164 497 minecraft:polished_blackstone_bricks
setblock 424 164 498 minecraft:blackstone
setblock 424 164 503 minecraft:blackstone
setblock 425 164 486 minecraft:polished_blackstone_bricks
fill 425 164 487 425 167 487 minecraft:blackstone
setblock 425 164 491 minecraft:polished_blackstone_bricks
fill 425 164 492 425 167 492 minecraft:blackstone
setblock 426 164 486 minecraft:blackstone
setblock 426 164 490 minecraft:polished_blackstone_bricks
setblock 431 164 464 minecraft:blackstone
setblock 432 164 464 minecraft:polished_blackstone_bricks
fill 432 164 465 432 167 465 minecraft:blackstone
fill 433 164 464 433 167 464 minecraft:blackstone
fill 433 164 466 434 164 466 minecraft:blackstone
setblock 433 164 504 minecraft:blackstone
setblock 435 164 466 minecraft:polished_blackstone_bricks
fill 435 164 467 435 167 467 minecraft:blackstone
setblock 436 164 465 minecraft:polished_blackstone_bricks
fill 436 164 466 436 167 466 minecraft:blackstone
setblock 437 164 464 minecraft:polished_blackstone_bricks
fill 437 164 465 437 167 465 minecraft:blackstone
setblock 437 164 504 minecraft:polished_blackstone_bricks
fill 438 164 464 441 164 464 minecraft:blackstone
fill 438 164 504 441 164 504 minecraft:blackstone
setblock 439 164 466 minecraft:blackstone
setblock 439 164 467 minecraft:polished_blackstone_bricks
setblock 440 164 466 minecraft:polished_blackstone_bricks
fill 440 164 467 440 166 467 minecraft:blackstone
setblock 441 164 465 minecraft:polished_blackstone_bricks
fill 441 164 466 441 167 466 minecraft:blackstone
setblock 442 164 464 minecraft:polished_blackstone_bricks
fill 442 164 465 442 167 465 minecraft:blackstone
setblock 442 164 504 minecraft:polished_blackstone_bricks
fill 443 164 464 443 167 464 minecraft:blackstone
fill 443 164 504 443 165 504 minecraft:blackstone
setblock 445 164 466 minecraft:polished_blackstone_bricks
setblock 446 164 465 minecraft:polished_blackstone_bricks
fill 446 164 466 449 164 466 minecraft:blackstone
setblock 447 164 464 minecraft:polished_blackstone_bricks
fill 447 164 465 447 167 465 minecraft:blackstone
setblock 447 164 504 minecraft:polished_blackstone_bricks
fill 448 164 464 448 167 464 minecraft:blackstone
fill 448 164 504 448 165 504 minecraft:blackstone
setblock 450 164 466 minecraft:polished_blackstone_bricks
setblock 451 164 465 minecraft:polished_blackstone_bricks
fill 451 164 466 451 167 466 minecraft:blackstone
setblock 452 164 464 minecraft:polished_blackstone_bricks
fill 452 164 465 452 167 465 minecraft:blackstone
setblock 452 164 504 minecraft:polished_blackstone_bricks
fill 453 164 464 453 167 464 minecraft:blackstone
setblock 453 164 503 minecraft:polished_blackstone_bricks
fill 453 164 504 453 167 504 minecraft:blackstone
setblock 454 164 467 minecraft:polished_blackstone_bricks
fill 454 164 503 454 167 503 minecraft:blackstone
setblock 455 164 466 minecraft:polished_blackstone_bricks
fill 455 164 467 455 166 467 minecraft:blackstone
setblock 455 164 502 minecraft:blackstone
setblock 456 164 465 minecraft:polished_blackstone_bricks
fill 456 164 466 456 167 466 minecraft:blackstone
setblock 457 164 464 minecraft:polished_blackstone_bricks
fill 457 164 465 457 167 465 minecraft:blackstone
fill 457 164 467 458 164 467 minecraft:blackstone
setblock 457 164 504 minecraft:polished_blackstone_bricks
fill 458 164 464 458 167 464 minecraft:blackstone
setblock 458 164 503 minecraft:polished_blackstone_bricks
fill 458 164 504 458 167 504 minecraft:blackstone
setblock 459 164 467 minecraft:polished_blackstone_bricks
setblock 459 164 502 minecraft:polished_blackstone_bricks
fill 459 164 503 459 167 503 minecraft:blackstone
setblock 460 164 466 minecraft:polished_blackstone_bricks
fill 460 164 502 460 165 502 minecraft:blackstone
setblock 461 164 465 minecraft:polished_blackstone_bricks
fill 461 164 466 461 165 466 minecraft:blackstone
setblock 461 164 490 minecraft:polished_blackstone_bricks
setblock 462 164 464 minecraft:polished_blackstone_bricks
fill 462 164 465 462 166 465 minecraft:blackstone
fill 462 164 486 462 164 488 minecraft:blackstone
setblock 462 164 489 minecraft:polished_blackstone_bricks
fill 462 164 490 462 167 490 minecraft:blackstone
setblock 462 164 494 minecraft:polished_blackstone_bricks
setblock 462 164 504 minecraft:polished_blackstone_bricks
fill 463 164 464 463 166 464 minecraft:blackstone
setblock 463 164 468 minecraft:polished_blackstone_bricks
setblock 463 164 469 minecraft:blackstone
fill 463 164 484 463 164 487 minecraft:blackstone
setblock 463 164 488 minecraft:polished_blackstone_bricks
fill 463 164 489 463 167 489 minecraft:blackstone
setblock 463 164 493 minecraft:polished_blackstone_bricks
fill 463 164 494 463 167 494 minecraft:blackstone
setblock 463 164 498 minecraft:polished_blackstone_bricks
setblock 463 164 499 minecraft:blackstone
setblock 463 164 503 minecraft:polished_blackstone_bricks
fill 463 164 504 463 166 504 minecraft:blackstone
setblock 464 164 467 minecraft:polished_blackstone_bricks
fill 464 164 468 464 166 468 minecraft:blackstone
setblock 464 164 482 minecraft:polished_blackstone_bricks
fill 464 164 483 464 165 483 minecraft:blackstone
setblock 464 164 487 minecraft:polished_blackstone_bricks
fill 464 164 488 464 167 488 minecraft:blackstone
setblock 464 164 492 minecraft:polished_blackstone_bricks
fill 464 164 493 464 167 493 minecraft:blackstone
setblock 464 164 497 minecraft:polished_blackstone_bricks
fill 464 164 498 464 167 498 minecraft:blackstone
setblock 464 164 502 minecraft:polished_blackstone_bricks
fill 464 164 503 464 166 503 minecraft:blackstone
setblock 424 165 466 minecraft:polished_blackstone_bricks
fill 424 165 467 424 166 467 minecraft:blackstone
setblock 424 165 471 minecraft:polished_blackstone_bricks
setblock 424 165 472 minecraft:blackstone
setblock 424 165 481 minecraft:polished_blackstone_bricks
fill 424 165 482 424 166 482 minecraft:blackstone
setblock 424 165 486 minecraft:polished_blackstone_bricks
fill 424 165 487 424 168 487 minecraft:blackstone
setblock 424 165 491 minecraft:polished_blackstone_bricks
fill 424 165 492 424 168 492 minecraft:blackstone
setblock 424 165 496 minecraft:polished_blackstone_bricks
setblock 424 165 497 minecraft:blackstone
setblock 425 165 485 minecraft:polished_blackstone_bricks
fill 425 165 486 425 167 486 minecraft:blackstone
setblock 425 165 490 minecraft:polished_blackstone_bricks
fill 425 165 491 425 168 491 minecraft:blackstone
setblock 426 165 489 minecraft:polished_blackstone_bricks
setblock 431 165 464 minecraft:polished_blackstone_bricks
fill 432 165 464 432 168 464 minecraft:blackstone
setblock 433 165 466 minecraft:blackstone
setblock 434 165 466 minecraft:polished_blackstone_bricks
setblock 435 165 465 minecraft:polished_blackstone_bricks
fill 435 165 466 435 168 466 minecraft:blackstone
setblock 436 165 464 minecraft:polished_blackstone_bricks
fill 436 165 465 436 168 465 minecraft:blackstone
setblock 436 165 504 minecraft:polished_blackstone_bricks
fill 437 165 464 440 165 464 minecraft:blackstone
setblock 437 165 467 minecraft:blackstone
fill 437 165 504 440 165 504 minecraft:blackstone
setblock 438 165 467 minecraft:polished_blackstone_bricks
setblock 439 165 466 minecraft:polished_blackstone_bricks
fill 439 165 467 439 167 467 minecraft:blackstone
setblock 440 165 465 minecraft:polished_blackstone_bricks
fill 440 165 466 440 168 466 minecraft:blackstone
setblock 441 165 464 minecraft:polished_blackstone_bricks
fill 441 165 465 441 168 465 minecraft:blackstone
setblock 441 165 504 minecraft:polished_blackstone_bricks
fill 442 165 464 442 168 464 minecraft:blackstone
setblock 442 165 504 minecraft:blackstone
setblock 444 165 466 minecraft:polished_blackstone_bricks
setblock 445 165 465 minecraft:polished_blackstone_bricks
fill 445 165 466 448 165 466 minecraft:blackstone
setblock 446 165 464 minecraft:polished_blackstone_bricks
fill 446 165 465 446 167 465 minecraft:blackstone
fill 447 165 464 447 168 464 minecraft:blackstone
setblock 449 165 466 minecraft:polished_blackstone_bricks
setblock 450 165 465 minecraft:polished_blackstone_bricks
fill 450 165 466 450 166 466 minecraft:blackstone
setblock 451 165 464 minecraft:polished_blackstone_bricks
fill 451 165 465 451 168 465 minecraft:blackstone
setblock 451 165 504 minecraft:polished_blackstone_bricks
fill 452 165 464 452 168 464 minecraft:blackstone
setblock 452 165 503 minecraft:polished_blackstone_bricks
fill 452 165 504 452 168 504 minecraft:blackstone
fill 453 165 503 453 168 503 minecraft:blackstone
setblock 454 165 466 minecraft:polished_blackstone_bricks
setblock 454 165 467 minecraft:blackstone
setblock 455 165 465 minecraft:polished_blackstone_bricks
fill 455 165 466 455 168 466 minecraft:blackstone
setblock 456 165 464 minecraft:polished_blackstone_bricks
fill 456 165 465 456 168 465 minecraft:blackstone
setblock 456 165 504 minecraft:polished_blackstone_bricks
fill 457 165 464 457 168 464 minecraft:blackstone
setblock 457 165 467 minecraft:blackstone
setblock 457 165 503 minecraft:polished_blackstone_bricks
fill 457 165 504 457 168 504 minecraft:blackstone
setblock 458 165 467 minecraft:polished_blackstone_bricks
setblock 458 165 502 minecraft:polished_blackstone_bricks
fill 458 165 503 458 168 503 minecraft:blackstone
setblock 459 165 466 minecraft:polished_blackstone_bricks
setblock 459 165 502 minecraft:blackstone
setblock 460 165 465 minecraft:polished_blackstone_bricks
fill 460 165 466 460 166 466 minecraft:blackstone
setblock 461 165 464 minecraft:polished_blackstone_bricks
fill 461 165 465 461 166 465 minecraft:blackstone
setblock 461 165 504 minecraft:polished_blackstone_bricks
fill 462 165 464 462 167 464 minecraft:blackstone
setblock 462 165 487 minecraft:blackstone
setblock 462 165 488 minecraft:polished_blackstone_bricks
fill 462 165 489 462 167 489 minecraft:blackstone
setblock 462 165 492 minecraft:blackstone
setblock 462 165 493 minecraft:polished_blackstone_bricks
fill 462 165 494 462 166 494 minecraft:blackstone
setblock 462 165 503 minecraft:polished_blackstone_bricks
fill 462 165 504 462 167 504 minecraft:blackstone
setblock 463 165 467 minecraft:polished_blackstone_bricks
setblock 463 165 468 minecraft:blackstone
fill 463 165 485 463 165 486 minecraft:blackstone
setblock 463 165 487 minecraft:polished_blackstone_bricks
fill 463 165 488 463 168 488 minecraft:blackstone
setblock 463 165 492 minecraft:polished_blackstone_bricks
fill 463 165 493 463 168 493 minecraft:blackstone
setblock 463 165 497 minecraft:polished_blackstone_bricks
setblock 463 165 498 minecraft:blackstone
setblock 463 165 503 minecraft:blackstone
setblock 464 165 466 minecraft:polished_blackstone_bricks
fill 464 165 467 464 166 467 minecraft:blackstone
setblock 464 165 486 minecraft:polished_blackstone_bricks
fill 464 165 487 464 168 487 minecraft:blackstone
setblock 464 165 491 minecraft:polished_blackstone_bricks
fill 464 165 492 464 168 492 minecraft:blackstone
setblock 464 165 496 minecraft:polished_blackstone_bricks
fill 464 165 497 464 168 497 minecraft:blackstone
setblock 464 165 501 minecraft:polished_blackstone_bricks
fill 464 165 502 464 166 502 minecraft:blackstone
setblock 424 166 470 minecraft:polished_blackstone_bricks
fill 424 166 471 424 167 471 minecraft:blackstone
setblock 424 166 485 minecraft:polished_blackstone_bricks
fill 424 166 486 424 169 486 minecraft:blackstone
setblock 424 166 490 minecraft:polished_blackstone_bricks
fill 424 166 491 424 169 491 minecraft:blackstone
setblock 424 166 495 minecraft:polished_blackstone_bricks
fill 424 166 496 424 167 496 minecraft:blackstone
fill 425 166 485 430 166 485 minecraft:blackstone
setblock 425 166 489 minecraft:polished_blackstone_bricks
fill 425 166 490 425 168 490 minecraft:blackstone
fill 426 166 484 430 167 484 minecraft:blackstone
fill 426 166 486 430 167 486 minecraft:blackstone
fill 427 166 487 430 167 488 minecraft:blackstone
setblock 430 166 464 minecraft:polished_blackstone_bricks
fill 431 166 464 431 168 464 minecraft:blackstone
setblock 433 166 466 minecraft:polished_blackstone_bricks
setblock 434 166 465 minecraft:polished_blackstone_bricks
fill 434 166 466 434 169 466 minecraft:blackstone
setblock 435 166 464 minecraft:polished_blackstone_bricks
fill 435 166 465 435 169 465 minecraft:blackstone
setblock 435 166 504 minecraft:polished_blackstone_bricks
fill 436 166 464 439 166 464 minecraft:blackstone
fill 436 166 504 439 166 504 minecraft:blackstone
setblock 437 166 467 minecraft:polished_blackstone_bricks
setblock 438 166 466 minecraft:polished_blackstone_bricks
fill 438 166 467 438 167 467 minecraft:blackstone
setblock 439 166 465 minecraft:polished_blackstone_bricks
fill 439 166 466 439 168 466 minecraft:blackstone
setblock 440 166 464 minecraft:polished_blackstone_bricks
fill 440 166 465 440 169 465 minecraft:blackstone
setblock 440 166 504 minecraft:polished_blackstone_bricks
fill 441 166 464 441 169 464 minecraft:blackstone
setblock 441 166 504 minecraft:blackstone
setblock 443 166 466 minecraft:polished_blackstone_bricks
setblock 444 166 465 minecraft:polished_blackstone_bricks
setblock 444 166 466 minecraft:blackstone
setblock 445 166 464 minecraft:polished_blackstone_bricks
fill 445 166 465 445 167 465 minecraft:blackstone
fill 446 166 464 446 169 464 minecraft:blackstone
setblock 449 166 465 minecraft:polished_blackstone_bricks
setblock 450 166 464 minecraft:polished_blackstone_bricks
fill 450 166 465 450 169 465 minecraft:blackstone
setblock 450 166 504 minecraft:polished_blackstone_bricks
fill 451 166 464 451 169 464 minecraft:blackstone
fill 451 166 504 451 169 504 minecraft:blackstone
setblock 453 166 466 minecraft:polished_blackstone_bricks
setblock 454 166 465 minecraft:polished_blackstone_bricks
fill 454 166 466 454 168 466 minecraft:blackstone
setblock 455 166 464 minecraft:polished_blackstone_bricks
fill 455 166 465 455 169 465 minecraft:blackstone
setblock 455 166 504 minecraft:polished_blackstone_bricks
fill 456 166 464 456 169 464 minecraft:blackstone
setblock 456 166 503 minecraft:polished_blackstone_bricks
fill 456 166 504 456 169 504 minecraft:blackstone
setblock 457 166 502 minecraft:polished_blackstone_bricks
fill 457 166 503 457 169 503 minecraft:blackstone
setblock 458 166 466 minecraft:polished_blackstone_bricks
setblock 458 166 502 minecraft:blackstone
setblock 459 166 465 minecraft:polished_blackstone_bricks
setblock 459 166 466 minecraft:blackstone
setblock 460 166 464 minecraft:polished_blackstone_bricks
fill 460 166 465 460 167 465 minecraft:blackstone
setblock 460 166 504 minecraft:polished_blackstone_bricks
fill 461 166 464 461 168 464 minecraft:blackstone
setblock 461 166 503 minecraft:polished_blackstone_bricks
fill 461 166 504 461 168 504 minecraft:blackstone
setblock 462 166 488 minecraft:blackstone
setblock 462 166 492 minecraft:polished_blackstone_bricks
fill 462 166 493 462 167 493 minecraft:blackstone
setblock 463 166 486 minecraft:polished_blackstone_bricks
fill 463 166 487 463 167 487 minecraft:blackstone
setblock 463 166 491 minecraft:polished_blackstone_bricks
fill 463 166 492 463 169 492 minecraft:blackstone
setblock 463 166 496 minecraft:polished_blackstone_bricks
setblock 464 166 465 minecraft:polished_blackstone_bricks
setblock 464 166 466 minecraft:blackstone
setblock 464 166 470 minecraft:polished_blackstone_bricks
setblock 464 166 485 minecraft:polished_blackstone_bricks
fill 464 166 486 464 168 486 minecraft:blackstone
setblock 464 166 490 minecraft:polished_blackstone_bricks
fill 464 166 491 464 169 491 minecraft:blackstone
setblock 464 166 495 minecraft:polished_blackstone_bricks
fill 464 166 496 464 169 496 minecraft:blackstone
setblock 464 166 500 minecraft:polished_blackstone_bricks
setblock 464 166 501 minecraft:blackstone
setblock 424 167 469 minecraft:polished_blackstone_bricks
setblock 424 167 470 minecraft:blackstone
setblock 424 167 484 minecraft:polished_blackstone_bricks
fill 424 167 485 424 168 485 minecraft:blackstone
setblock 424 167 489 minecraft:polished_blackstone_bricks
fill 424 167 490 424 170 490 minecraft:blackstone
setblock 424 167 493 minecraft:blackstone
setblock 424 167 494 minecraft:polished_blackstone_bricks
fill 424 167 495 424 170 495 minecraft:blackstone
setblock 425 167 488 minecraft:polished_blackstone_bricks
fill 425 167 489 425 168 489 minecraft:blackstone
fill 426 167 485 430 167 485 minecraft:blackstone
setblock 433 167 465 minecraft:polished_blackstone_bricks
setblock 433 167 466 minecraft:blackstone
setblock 434 167 464 minecraft:polished_blackstone_bricks
fill 434 167 465 434 170 465 minecraft:blackstone
fill 435 167 464 438 167 464 minecraft:blackstone
setblock 436 167 467 minecraft:polished_blackstone_bricks
fill 436 167 504 438 167 504 minecraft:blackstone
setblock 437 167 466 minecraft:polished_blackstone_bricks
fill 437 167 467 437 168 467 minecraft:blackstone
setblock 438 167 465 minecraft:polished_blackstone_bricks
fill 438 167 466 438 169 466 minecraft:blackstone
setblock 439 167 464 minecraft:polished_blackstone_bricks
fill 439 167 465 439 170 465 minecraft:blackstone
setblock 439 167 504 minecraft:polished_blackstone_bricks
fill 440 167 464 440 170 464 minecraft:blackstone
setblock 442 167 466 minecraft:polished_blackstone_bricks
setblock 443 167 465 minecraft:polished_blackstone_bricks
setblock 444 167 464 minecraft:polished_blackstone_bricks
setblock 444 167 465 minecraft:blackstone
fill 445 167 464 445 168 464 minecraft:blackstone
setblock 448 167 465 minecraft:polished_blackstone_bricks
setblock 449 167 464 minecraft:polished_blackstone_bricks
fill 449 167 465 449 168 465 minecraft:blackstone
fill 450 167 464 450 170 464 minecraft:blackstone
fill 450 167 504 450 170 504 minecraft:blackstone
setblock 452 167 466 minecraft:polished_blackstone_bricks
setblock 453 167 465 minecraft:polished_blackstone_bricks
fill 453 167 466 453 168 466 minecraft:blackstone
setblock 454 167 464 minecraft:polished_blackstone_bricks
fill 454 167 465 454 170 465 minecraft:blackstone
setblock 454 167 504 minecraft:polished_blackstone_bricks
fill 455 167 464 455 170 464 minecraft:blackstone
setblock 455 167 503 minecraft:polished_blackstone_bricks
fill 455 167 504 455 170 504 minecraft:blackstone
fill 456 167 503 456 170 503 minecraft:blackstone
setblock 457 167 466 minecraft:polished_blackstone_bricks
setblock 458 167 465 minecraft:polished_blackstone_bricks
setblock 458 167 466 minecraft:blackstone
setblock 459 167 464 minecraft:polished_blackstone_bricks
fill 459 167 465 459 168 465 minecraft:blackstone
setblock 459 167 504 minecraft:polished_blackstone_bricks
fill 460 167 464 460 168 464 minecraft:blackstone
setblock 460 167 503 minecraft:polished_blackstone_bricks
fill 460 167 504 460 169 504 minecraft:blackstone
setblock 462 167 491 minecraft:polished_blackstone_bricks
setblock 462 167 492 minecraft:blackstone
setblock 463 167 490 minecraft:polished_blackstone_bricks
fill 463 167 491 463 170 491 minecraft:blackstone
setblock 463 167 495 minecraft:polished_blackstone_bricks
setblock 463 167 496 minecraft:blackstone
setblock 464 167 485 minecraft:blackstone
setblock 464 167 489 minecraft:polished_blackstone_bricks
fill 464 167 490 464 170 490 minecraft:blackstone
setblock 464 167 494 minecraft:polished_blackstone_bricks
fill 464 167 495 464 170 495 minecraft:blackstone
setblock 424 168 488 minecraft:polished_blackstone_bricks
fill 424 168 489 424 171 489 minecraft:blackstone
setblock 424 168 493 minecraft:polished_blackstone_bricks
fill 424 168 494 424 171 494 minecraft:blackstone
setblock 425 168 488 minecraft:blackstone
setblock 425 168 492 minecraft:polished_blackstone_bricks
setblock 426 168 466 minecraft:light[level=11]
setblock 426 168 474 minecraft:light[level=11]
setblock 426 168 482 minecraft:light[level=11]
setblock 426 168 490 minecraft:light[level=11]
setblock 426 168 498 minecraft:light[level=11]
fill 427 168 486 429 174 486 minecraft:polished_blackstone_bricks
fill 428 168 485 428 174 485 minecraft:polished_blackstone_bricks
fill 428 168 487 428 174 487 minecraft:polished_blackstone_bricks
setblock 432 168 465 minecraft:polished_blackstone_bricks
setblock 433 168 464 minecraft:polished_blackstone_bricks
fill 433 168 465 433 171 465 minecraft:blackstone
fill 434 168 464 437 168 464 minecraft:blackstone
setblock 434 168 474 minecraft:light[level=11]
setblock 434 168 482 minecraft:light[level=11]
setblock 434 168 490 minecraft:light[level=11]
setblock 434 168 498 minecraft:light[level=11]
setblock 436 168 466 minecraft:polished_blackstone_bricks
setblock 437 168 465 minecraft:polished_blackstone_bricks
fill 437 168 466 437 169 466 minecraft:blackstone
setblock 438 168 464 minecraft:polished_blackstone_bricks
fill 438 168 465 438 170 465 minecraft:blackstone
fill 439 168 464 439 171 464 minecraft:blackstone
setblock 442 168 465 minecraft:polished_blackstone_bricks
setblock 442 168 466 minecraft:light[level=11]
setblock 442 168 474 minecraft:light[level=11]
setblock 442 168 482 minecraft:light[level=11]
setblock 442 168 490 minecraft:light[level=11]
setblock 442 168 498 minecraft:light[level=11]
setblock 443 168 464 minecraft:polished_blackstone_bricks
setblock 443 168 465 minecraft:blackstone
fill 444 168 464 444 169 464 minecraft:blackstone
setblock 448 168 464 minecraft:polished_blackstone_bricks
fill 449 168 464 449 171 464 minecraft:blackstone
setblock 450 168 466 minecraft:light[level=11]
setblock 450 168 474 minecraft:light[level=11]
setblock 450 168 482 minecraft:light[level=11]
setblock 450 168 490 minecraft:light[level=11]
setblock 450 168 498 minecraft:light[level=11]
setblock 452 168 465 minecraft:polished_blackstone_bricks
setblock 453 168 464 minecraft:polished_blackstone_bricks
fill 453 168 465 453 171 465 minecraft:blackstone
setblock 453 168 504 minecraft:polished_blackstone_bricks
fill 454 168 464 454 171 464 minecraft:blackstone
setblock 454 168 503 minecraft:polished_blackstone_bricks
fill 454 168 504 454 171 504 minecraft:blackstone
fill 455 168 503 455 171 503 minecraft:blackstone
setblock 456 168 466 minecraft:polished_blackstone_bricks
setblock 457 168 465 minecraft:polished_blackstone_bricks
setblock 458 168 464 minecraft:polished_blackstone_bricks
setblock 458 168 465 minecraft:blackstone
setblock 458 168 466 minecraft:light[level=11]
setblock 458 168 474 minecraft:light[level=11]
setblock 458 168 482 minecraft:light[level=11]
setblock 458 168 490 minecraft:light[level=11]
setblock 458 168 498 minecraft:light[level=11]
setblock 458 168 504 minecraft:polished_blackstone_bricks
fill 459 168 464 459 169 464 minecraft:blackstone
fill 459 168 504 459 170 504 minecraft:blackstone
setblock 463 168 489 minecraft:polished_blackstone_bricks
fill 463 168 490 463 169 490 minecraft:blackstone
setblock 463 168 494 minecraft:polished_blackstone_bricks
fill 463 168 495 463 171 495 minecraft:blackstone
setblock 464 168 488 minecraft:polished_blackstone_bricks
fill 464 168 489 464 171 489 minecraft:blackstone
setblock 464 168 493 minecraft:polished_blackstone_bricks
fill 464 168 494 464 171 494 minecraft:blackstone
setblock 424 169 487 minecraft:polished_blackstone_bricks
fill 424 169 488 424 171 488 minecraft:blackstone
setblock 424 169 492 minecraft:polished_blackstone_bricks
fill 424 169 493 424 172 493 minecraft:blackstone
setblock 432 169 464 minecraft:polished_blackstone_bricks
fill 433 169 464 436 169 464 minecraft:blackstone
setblock 435 169 466 minecraft:polished_blackstone_bricks
setblock 436 169 465 minecraft:polished_blackstone_bricks
setblock 436 169 466 minecraft:blackstone
setblock 437 169 464 minecraft:polished_blackstone_bricks
fill 437 169 465 437 171 465 minecraft:blackstone
fill 438 169 464 438 172 464 minecraft:blackstone
setblock 441 169 465 minecraft:polished_blackstone_bricks
setblock 442 169 464 minecraft:polished_blackstone_bricks
setblock 443 169 464 minecraft:blackstone
setblock 447 169 464 minecraft:polished_blackstone_bricks
fill 448 169 464 448 170 464 minecraft:blackstone
setblock 451 169 465 minecraft:polished_blackstone_bricks
setblock 452 169 464 minecraft:polished_blackstone_bricks
fill 452 169 465 452 171 465 minecraft:blackstone
setblock 452 169 504 minecraft:polished_blackstone_bricks
fill 453 169 464 453 172 464 minecraft:blackstone
fill 453 169 504 453 172 504 minecraft:blackstone
fill 454 169 503 454 172 503 minecraft:blackstone
setblock 456 169 465 minecraft:polished_blackstone_bricks
setblock 457 169 464 minecraft:polished_blackstone_bricks
setblock 457 169 465 minecraft:blackstone
setblock 457 169 504 minecraft:polished_blackstone_bricks
fill 458 169 464 458 170 464 minecraft:blackstone
fill 458 169 504 458 172 504 minecraft:blackstone
setblock 463 169 493 minecraft:polished_blackstone_bricks
fill 463 169 494 463 172 494 minecraft:blackstone
setblock 464 169 487 minecraft:polished_blackstone_bricks
fill 464 169 488 464 170 488 minecraft:blackstone
setblock 464 169 492 minecraft:polished_blackstone_bricks
fill 464 169 493 464 172 493 minecraft:blackstone
setblock 464 169 497 minecraft:polished_blackstone_bricks
setblock 424 170 487 minecraft:blackstone
setblock 424 170 491 minecraft:polished_blackstone_bricks
fill 424 170 492 424 173 492 minecraft:blackstone
fill 432 170 464 435 170 464 minecraft:blackstone
setblock 435 170 465 minecraft:polished_blackstone_bricks
setblock 436 170 464 minecraft:polished_blackstone_bricks
fill 436 170 465 436 173 465 minecraft:blackstone
fill 437 170 464 437 173 464 minecraft:blackstone
setblock 441 170 464 minecraft:polished_blackstone_bricks
setblock 451 170 464 minecraft:polished_blackstone_bricks
setblock 451 170 465 minecraft:blackstone
setblock 451 170 504 minecraft:polished_blackstone_bricks
fill 452 170 464 452 173 464 minecraft:blackstone
fill 452 170 504 452 173 504 minecraft:blackstone
setblock 455 170 465 minecraft:polished_blackstone_bricks
setblock 456 170 464 minecraft:polished_blackstone_bricks
setblock 456 170 504 minecraft:polished_blackstone_bricks
fill 457 170 464 457 171 464 minecraft:blackstone
fill 457 170 504 457 173 504 minecraft:blackstone
setblock 463 170 492 minecraft:polished_blackstone_bricks
fill 463 170 493 463 173 493 minecraft:blackstone
setblock 464 170 491 minecraft:polished_blackstone_bricks
fill 464 170 492 464 173 492 minecraft:blackstone
setblock 464 170 496 minecraft:polished_blackstone_bricks
fill 464 170 497 464 173 497 minecraft:blackstone
fill 424 171 472 424 171 474 minecraft:blackstone
setblock 424 171 490 minecraft:polished_blackstone_bricks
fill 424 171 491 424 174 491 minecraft:blackstone
setblock 424 171 495 minecraft:polished_blackstone_bricks
fill 432 171 464 434 171 464 minecraft:blackstone
setblock 434 171 465 minecraft:polished_blackstone_bricks
setblock 435 171 464 minecraft:polished_blackstone_bricks
fill 435 171 465 435 174 465 minecraft:blackstone
fill 436 171 464 436 174 464 minecraft:blackstone
setblock 440 171 464 minecraft:polished_blackstone_bricks
setblock 450 171 464 minecraft:polished_blackstone_bricks
setblock 450 171 504 minecraft:polished_blackstone_bricks
fill 451 171 464 451 174 464 minecraft:blackstone
fill 451 171 504 451 174 504 minecraft:blackstone
fill 453 171 503 453 173 503 minecraft:blackstone
setblock 455 171 464 minecraft:polished_blackstone_bricks
setblock 455 171 504 minecraft:polished_blackstone_bricks
fill 456 171 464 456 172 464 minecraft:blackstone
fill 456 171 504 456 174 504 minecraft:blackstone
setblock 463 171 491 minecraft:polished_blackstone_bricks
fill 463 171 492 463 174 492 minecraft:blackstone
setblock 464 171 490 minecraft:polished_blackstone_bricks
fill 464 171 491 464 174 491 minecraft:blackstone
setblock 464 171 495 minecraft:polished_blackstone_bricks
fill 464 171 496 464 174 496 minecraft:blackstone
fill 424 172 471 424 172 473 minecraft:blackstone
setblock 424 172 474 minecraft:polished_blackstone_bricks
fill 424 172 475 424 174 476 minecraft:blackstone
setblock 424 172 489 minecraft:polished_blackstone_bricks
fill 424 172 490 424 175 490 minecraft:blackstone
setblock 424 172 494 minecraft:polished_blackstone_bricks
fill 424 172 495 424 175 495 minecraft:blackstone
fill 431 172 464 433 172 464 minecraft:blackstone
setblock 433 172 465 minecraft:polished_blackstone_bricks
setblock 434 172 464 minecraft:polished_blackstone_bricks
fill 434 172 465 434 175 465 minecraft:blackstone
fill 435 172 464 435 175 464 minecraft:blackstone
setblock 439 172 464 minecraft:polished_blackstone_bricks
setblock 448 172 464 minecraft:blackstone
setblock 449 172 464 minecraft:polished_blackstone_bricks
setblock 449 172 504 minecraft:polished_blackstone_bricks
fill 450 172 464 450 175 464 minecraft:blackstone
fill 450 172 504 450 175 504 minecraft:blackstone
fill 452 172 503 452 174 503 minecraft:blackstone
setblock 454 172 464 minecraft:polished_blackstone_bricks
setblock 454 172 504 minecraft:polished_blackstone_bricks
fill 455 172 464 455 175 464 minecraft:blackstone
setblock 455 172 503 minecraft:polished_blackstone_bricks
fill 455 172 504 455 175 504 minecraft:blackstone
fill 456 172 503 456 175 503 minecraft:blackstone
setblock 463 172 495 minecraft:polished_blackstone_bricks
setblock 464 172 489 minecraft:polished_blackstone_bricks
fill 464 172 490 464 175 490 minecraft:blackstone
setblock 464 172 494 minecraft:polished_blackstone_bricks
fill 464 172 495 464 175 495 minecraft:blackstone
setblock 464 172 498 minecraft:blackstone
fill 424 173 471 424 173 472 minecraft:blackstone
setblock 424 173 473 minecraft:polished_blackstone_bricks
fill 424 173 474 425 175 474 minecraft:blackstone
setblock 424 173 477 minecraft:blackstone
setblock 424 173 478 minecraft:polished_blackstone_bricks
fill 424 173 479 424 176 479 minecraft:blackstone
fill 424 173 489 424 176 489 minecraft:blackstone
setblock 424 173 493 minecraft:polished_blackstone_bricks
fill 424 173 494 424 176 494 minecraft:blackstone
fill 424 173 496 424 174 496 minecraft:blackstone
fill 425 173 473 425 176 473 minecraft:blackstone
fill 425 173 475 425 174 475 minecraft:blackstone
fill 431 173 464 432 173 464 minecraft:blackstone
setblock 433 173 464 minecraft:polished_blackstone_bricks
fill 433 173 465 433 176 465 minecraft:blackstone
fill 434 173 464 434 176 464 minecraft:blackstone
fill 435 173 481 436 173 484 minecraft:cyan_concrete
fill 436 173 480 441 173 480 minecraft:cyan_concrete
fill 436 173 485 441 173 485 minecraft:cyan_concrete
fill 437 173 479 440 173 479 minecraft:cyan_concrete
fill 437 173 486 439 173 486 minecraft:cyan_concrete
setblock 438 173 464 minecraft:polished_blackstone_bricks
fill 439 173 464 439 176 464 minecraft:blackstone
fill 439 173 468 439 174 470 minecraft:cyan_concrete
fill 440 173 467 441 173 467 minecraft:cyan_concrete
fill 440 173 470 441 173 471 minecraft:cyan_concrete
fill 440 173 481 441 174 481 minecraft:cyan_concrete
fill 440 173 484 441 174 484 minecraft:cyan_concrete
fill 441 173 482 441 174 483 minecraft:cyan_concrete
fill 442 173 468 442 173 470 minecraft:cyan_concrete
setblock 448 173 464 minecraft:polished_blackstone_bricks
setblock 448 173 504 minecraft:polished_blackstone_bricks
fill 449 173 464 449 176 464 minecraft:blackstone
fill 449 173 504 449 176 504 minecraft:blackstone
fill 450 173 503 451 175 503 minecraft:blackstone
setblock 453 173 464 minecraft:polished_blackstone_bricks
setblock 453 173 504 minecraft:polished_blackstone_bricks
fill 454 173 464 454 176 464 minecraft:blackstone
setblock 454 173 503 minecraft:polished_blackstone_bricks
fill 454 173 504 454 176 504 minecraft:blackstone
fill 455 173 503 455 176 503 minecraft:blackstone
setblock 458 173 504 minecraft:polished_blackstone_bricks
setblock 463 173 494 minecraft:polished_blackstone_bricks
fill 463 173 495 463 175 496 minecraft:blackstone
fill 464 173 489 464 176 489 minecraft:blackstone
setblock 464 173 493 minecraft:polished_blackstone_bricks
fill 464 173 494 464 176 494 minecraft:blackstone
setblock 464 173 498 minecraft:polished_blackstone_bricks
fill 464 173 499 464 176 499 minecraft:blackstone
fill 424 174 470 424 174 471 minecraft:blackstone
setblock 424 174 472 minecraft:polished_blackstone_bricks
fill 424 174 473 424 176 473 minecraft:blackstone
setblock 424 174 477 minecraft:polished_blackstone_bricks
fill 424 174 478 425 176 478 minecraft:blackstone
fill 424 174 480 424 174 481 minecraft:blackstone
setblock 424 174 492 minecraft:polished_blackstone_bricks
fill 424 174 493 424 176 493 minecraft:blackstone
setblock 424 174 497 minecraft:polished_blackstone_bricks
fill 425 174 472 425 176 472 minecraft:blackstone
setblock 425 174 476 minecraft:polished_blackstone_bricks
fill 425 174 477 425 176 477 minecraft:blackstone
fill 430 174 464 431 174 464 minecraft:blackstone
setblock 432 174 464 minecraft:polished_blackstone_bricks
fill 432 174 465 432 176 465 minecraft:blackstone
fill 433 174 464 433 176 464 minecraft:blackstone
fill 433 174 504 434 176 504 minecraft:blackstone
fill 435 174 482 436 174 483 minecraft:cyan_concrete
setblock 436 174 465 minecraft:polished_blackstone_bricks
fill 436 174 480 436 174 481 minecraft:cyan_concrete
setblock 436 174 484 minecraft:cyan_concrete
setblock 437 174 464 minecraft:polished_blackstone_bricks
fill 437 174 480 440 174 480 minecraft:cyan_concrete
fill 437 174 485 440 174 485 minecraft:cyan_concrete
fill 438 174 464 438 176 464 minecraft:blackstone
setblock 440 174 467 minecraft:cyan_concrete
fill 440 174 470 441 175 470 minecraft:cyan_concrete
fill 442 174 468 442 174 469 minecraft:cyan_concrete
setblock 446 174 504 minecraft:blackstone
setblock 447 174 464 minecraft:polished_blackstone_bricks
setblock 447 174 504 minecraft:polished_blackstone_bricks
fill 448 174 464 448 176 464 minecraft:blackstone
fill 448 174 504 448 176 504 minecraft:blackstone
fill 449 174 503 449 176 503 minecraft:blackstone
fill 451 174 502 453 174 502 minecraft:blackstone
setblock 452 174 464 minecraft:polished_blackstone_bricks
setblock 452 174 504 minecraft:polished_blackstone_bricks
fill 453 174 464 453 176 464 minecraft:blackstone
setblock 453 174 503 minecraft:polished_blackstone_bricks
fill 453 174 504 453 176 504 minecraft:blackstone
setblock 454 174 502 minecraft:polished_blackstone_bricks
fill 454 174 503 454 176 503 minecraft:blackstone
fill 457 174 491 461 175 495 minecraft:blackstone
setblock 457 174 504 minecraft:polished_blackstone_bricks
fill 458 174 504 458 176 504 minecraft:blackstone
setblock 462 174 493 minecraft:blackstone
setblock 463 174 493 minecraft:polished_blackstone_bricks
fill 463 174 494 463 176 494 minecraft:blackstone
setblock 463 174 497 minecraft:blackstone
fill 464 174 474 464 174 476 minecraft:blackstone
fill 464 174 488 464 176 488 minecraft:blackstone
setblock 464 174 492 minecraft:polished_blackstone_bricks
fill 464 174 493 464 176 493 minecraft:blackstone
setblock 464 174 497 minecraft:polished_blackstone_bricks
fill 464 174 498 464 176 498 minecraft:blackstone
fill 464 174 500 464 175 500 minecraft:blackstone
setblock 424 175 470 minecraft:blackstone
setblock 424 175 471 minecraft:polished_blackstone_bricks
fill 424 175 472 424 176 472 minecraft:blackstone
setblock 424 175 475 minecraft:blackstone
setblock 424 175 476 minecraft:polished_blackstone_bricks
fill 424 175 477 424 176 477 minecraft:blackstone
setblock 424 175 480 minecraft:blackstone
setblock 424 175 481 minecraft:polished_blackstone_bricks
fill 424 175 482 424 176 483 minecraft:blackstone
setblock 424 175 491 minecraft:polished_blackstone_bricks
fill 424 175 492 424 176 492 minecraft:blackstone
setblock 424 175 496 minecraft:polished_blackstone_bricks
fill 424 175 497 424 176 498 minecraft:blackstone
fill 425 175 471 425 176 471 minecraft:blackstone
setblock 425 175 475 minecraft:polished_blackstone_bricks
fill 425 175 476 426 176 476 minecraft:blackstone
setblock 425 175 479 minecraft:blackstone
setblock 425 175 480 minecraft:polished_blackstone_bricks
fill 426 175 472 426 175 473 minecraft:blackstone
setblock 426 175 474 minecraft:polished_blackstone_bricks
fill 426 175 475 426 176 475 minecraft:blackstone
fill 426 175 477 426 175 478 minecraft:blackstone
fill 426 175 484 427 176 488 minecraft:warped_wart_block
fill 428 175 484 430 176 485 minecraft:warped_wart_block
setblock 428 175 486 minecraft:polished_blackstone_bricks
fill 428 175 487 430 176 488 minecraft:warped_wart_block
fill 429 175 464 430 175 464 minecraft:blackstone
fill 429 175 486 430 176 486 minecraft:warped_wart_block
setblock 430 175 504 minecraft:blackstone
setblock 431 175 464 minecraft:polished_blackstone_bricks
fill 431 175 465 431 176 465 minecraft:blackstone
setblock 431 175 504 minecraft:polished_blackstone_bricks
fill 432 175 464 432 176 464 minecraft:blackstone
fill 432 175 504 432 176 504 minecraft:blackstone
setblock 435 175 465 minecraft:polished_blackstone_bricks
setblock 435 175 504 minecraft:blackstone
setblock 436 175 464 minecraft:polished_blackstone_bricks
fill 436 175 465 436 176 465 minecraft:blackstone
fill 436 175 481 436 175 483 minecraft:cyan_concrete
setblock 436 175 504 minecraft:polished_blackstone_bricks
fill 437 175 464 437 176 464 minecraft:blackstone
fill 438 175 480 439 175 480 minecraft:cyan_concrete
setblock 438 175 485 minecraft:cyan_concrete
setblock 439 175 469 minecraft:cyan_concrete
setblock 440 175 481 minecraft:cyan_concrete
setblock 440 175 484 minecraft:cyan_concrete
setblock 445 175 464 minecraft:blackstone
setblock 445 175 504 minecraft:blackstone
setblock 446 175 464 minecraft:polished_blackstone_bricks
setblock 446 175 504 minecraft:polished_blackstone_bricks
fill 447 175 464 447 176 464 minecraft:blackstone
setblock 447 175 503 minecraft:polished_blackstone_bricks
fill 447 175 504 447 176 504 minecraft:blackstone
fill 448 175 503 448 176 503 minecraft:blackstone
fill 449 175 502 452 175 502 minecraft:blackstone
setblock 451 175 464 minecraft:polished_blackstone_bricks
fill 451 175 465 451 176 465 minecraft:blackstone
fill 451 175 501 453 175 501 minecraft:blackstone
setblock 451 175 504 minecraft:polished_blackstone_bricks
fill 452 175 464 452 176 464 minecraft:blackstone
setblock 452 175 503 minecraft:polished_blackstone_bricks
fill 452 175 504 452 176 504 minecraft:blackstone
setblock 453 175 502 minecraft:polished_blackstone_bricks
fill 453 175 503 453 176 503 minecraft:blackstone
fill 454 175 502 455 176 502 minecraft:blackstone
setblock 456 175 504 minecraft:polished_blackstone_bricks
setblock 457 175 503 minecraft:polished_blackstone_bricks
fill 457 175 504 457 176 504 minecraft:blackstone
setblock 463 175 492 minecraft:polished_blackstone_bricks
fill 463 175 493 463 176 493 minecraft:blackstone
setblock 463 175 497 minecraft:polished_blackstone_bricks
fill 463 175 498 463 176 498 minecraft:blackstone
fill 464 175 473 464 175 475 minecraft:blackstone
setblock 464 175 476 minecraft:polished_blackstone_bricks
fill 464 175 477 464 175 480 minecraft:blackstone
setblock 464 175 491 minecraft:polished_blackstone_bricks
fill 464 175 492 464 176 492 minecraft:blackstone
setblock 464 175 496 minecraft:polished_blackstone_bricks
fill 464 175 497 464 176 497 minecraft:blackstone
setblock 464 175 501 minecraft:polished_blackstone_bricks
setblock 424 176 469 minecraft:blackstone
setblock 424 176 470 minecraft:polished_blackstone_bricks
setblock 424 176 471 minecraft:blackstone
setblock 424 176 474 minecraft:blackstone
setblock 424 176 475 minecraft:polished_blackstone_bricks
setblock 424 176 476 minecraft:blackstone
setblock 424 176 480 minecraft:polished_blackstone_bricks
fill 424 176 481 425 176 481 minecraft:blackstone
setblock 424 176 484 minecraft:blackstone
setblock 424 176 485 minecraft:polished_blackstone_bricks
setblock 424 176 486 minecraft:blackstone
setblock 424 176 488 minecraft:blackstone
setblock 424 176 490 minecraft:polished_blackstone_bricks
setblock 424 176 491 minecraft:blackstone
setblock 424 176 495 minecraft:polished_blackstone_bricks
fill 424 176 496 425 176 496 minecraft:blackstone
setblock 424 176 499 minecraft:blackstone
setblock 424 176 500 minecraft:polished_blackstone_bricks
setblock 425 176 470 minecraft:blackstone
setblock 425 176 474 minecraft:polished_blackstone_bricks
setblock 425 176 475 minecraft:blackstone
setblock 425 176 479 minecraft:polished_blackstone_bricks
fill 425 176 480 426 176 480 minecraft:blackstone
setblock 425 176 482 minecraft:blackstone
fill 425 176 485 425 176 487 minecraft:warped_wart_block
setblock 425 176 494 minecraft:polished_blackstone_bricks
setblock 425 176 495 minecraft:blackstone
setblock 426 176 466 minecraft:light[level=11]
setblock 426 176 472 minecraft:blackstone
setblock 426 176 473 minecraft:polished_blackstone_bricks
fill 426 176 474 427 176 474 minecraft:blackstone
setblock 426 176 477 minecraft:blackstone
setblock 426 176 478 minecraft:polished_blackstone_bricks
setblock 426 176 479 minecraft:blackstone
setblock 426 176 482 minecraft:light[level=11]
setblock 426 176 490 minecraft:light[level=11]
setblock 426 176 498 minecraft:light[level=11]
setblock 427 176 473 minecraft:blackstone
fill 427 176 475 427 176 476 minecraft:blackstone
setblock 427 176 477 minecraft:polished_blackstone_bricks
setblock 427 176 478 minecraft:blackstone
fill 427 176 483 429 176 483 minecraft:warped_wart_block
fill 427 176 489 429 176 489 minecraft:warped_wart_block
fill 428 176 464 429 176 464 minecraft:blackstone
setblock 428 176 486 minecraft:warped_wart_block
setblock 429 176 504 minecraft:blackstone
setblock 430 176 464 minecraft:polished_blackstone_bricks
setblock 430 176 465 minecraft:blackstone
setblock 430 176 504 minecraft:polished_blackstone_bricks
setblock 431 176 464 minecraft:blackstone
fill 431 176 485 431 176 487 minecraft:warped_wart_block
setblock 431 176 504 minecraft:blackstone
fill 432 176 503 433 176 503 minecraft:blackstone
setblock 434 176 465 minecraft:polished_blackstone_bricks
setblock 434 176 466 minecraft:light[level=11]
setblock 434 176 474 minecraft:light[level=11]
setblock 434 176 482 minecraft:light[level=11]
setblock 434 176 490 minecraft:light[level=11]
setblock 434 176 498 minecraft:light[level=11]
setblock 435 176 464 minecraft:polished_blackstone_bricks
setblock 435 176 465 minecraft:blackstone
setblock 435 176 504 minecraft:polished_blackstone_bricks
setblock 436 176 464 minecraft:blackstone
fill 436 176 504 438 176 504 minecraft:blackstone
setblock 442 176 466 minecraft:light[level=11]
setblock 442 176 474 minecraft:light[level=11]
setblock 442 176 482 minecraft:light[level=11]
setblock 442 176 490 minecraft:light[level=11]
setblock 442 176 498 minecraft:light[level=11]
fill 442 176 504 444 176 504 minecraft:blackstone
setblock 444 176 464 minecraft:blackstone
setblock 445 176 464 minecraft:polished_blackstone_bricks
setblock 445 176 503 minecraft:blackstone
setblock 445 176 504 minecraft:polished_blackstone_bricks
setblock 446 176 464 minecraft:blackstone
setblock 446 176 503 minecraft:polished_blackstone_bricks
setblock 446 176 504 minecraft:blackstone
setblock 447 176 502 minecraft:polished_blackstone_bricks
setblock 447 176 503 minecraft:blackstone
fill 448 176 502 451 176 502 minecraft:blackstone
setblock 449 176 465 minecraft:polished_blackstone_bricks
fill 449 176 501 452 176 501 minecraft:blackstone
setblock 450 176 464 minecraft:polished_blackstone_bricks
setblock 450 176 465 minecraft:blackstone
setblock 450 176 466 minecraft:light[level=11]
setblock 450 176 474 minecraft:light[level=11]
setblock 450 176 482 minecraft:light[level=11]
setblock 450 176 490 minecraft:light[level=11]
setblock 450 176 498 minecraft:light[level=11]
setblock 450 176 503 minecraft:blackstone
setblock 450 176 504 minecraft:polished_blackstone_bricks
setblock 451 176 464 minecraft:blackstone
setblock 451 176 503 minecraft:polished_blackstone_bricks
setblock 451 176 504 minecraft:blackstone
setblock 452 176 502 minecraft:polished_blackstone_bricks
setblock 452 176 503 minecraft:blackstone
setblock 453 176 501 minecraft:polished_blackstone_bricks
setblock 453 176 502 minecraft:blackstone
setblock 454 176 501 minecraft:blackstone
setblock 455 176 464 minecraft:polished_blackstone_bricks
setblock 455 176 504 minecraft:polished_blackstone_bricks
setblock 456 176 502 minecraft:blackstone
setblock 456 176 503 minecraft:polished_blackstone_bricks
setblock 456 176 504 minecraft:blackstone
setblock 457 176 503 minecraft:blackstone
setblock 458 176 466 minecraft:light[level=11]
setblock 458 176 474 minecraft:light[level=11]
setblock 458 176 482 minecraft:light[level=11]
setblock 458 176 490 minecraft:light[level=11]
fill 458 176 493 460 176 493 minecraft:polished_blackstone_bricks
setblock 458 176 498 minecraft:light[level=11]
setblock 463 176 492 minecraft:blackstone
setblock 463 176 495 minecraft:blackstone
setblock 463 176 496 minecraft:polished_blackstone_bricks
setblock 463 176 497 minecraft:blackstone
setblock 463 176 499 minecraft:blackstone
fill 464 176 472 464 176 474 minecraft:blackstone
setblock 464 176 475 minecraft:polished_blackstone_bricks
fill 464 176 476 464 176 479 minecraft:blackstone
setblock 464 176 480 minecraft:polished_blackstone_bricks
fill 464 176 481 464 176 484 minecraft:blackstone
setblock 464 176 485 minecraft:polished_blackstone_bricks
fill 464 176 486 464 176 487 minecraft:blackstone
setblock 464 176 490 minecraft:polished_blackstone_bricks
setblock 464 176 491 minecraft:blackstone
setblock 464 176 495 minecraft:polished_blackstone_bricks
setblock 464 176 496 minecraft:blackstone
setblock 464 176 500 minecraft:polished_blackstone_bricks
fill 464 176 501 464 176 502 minecraft:blackstone
fill 440 181 478 442 181 480 minecraft:redstone_block
fill 442 181 487 444 181 489 minecraft:redstone_block
fill 446 181 478 448 181 480 minecraft:redstone_block
fill 436 182 481 436 183 485 minecraft:cyan_concrete
fill 437 182 479 437 183 482 minecraft:cyan_concrete
fill 437 182 483 438 183 483 minecraft:soul_soil
fill 437 182 484 437 183 487 minecraft:cyan_concrete
fill 438 182 478 438 183 479 minecraft:cyan_concrete
fill 438 182 480 438 183 480 minecraft:soul_soil
fill 438 182 481 438 183 481 minecraft:light_blue_concrete
fill 438 182 482 439 183 482 minecraft:soul_soil
fill 438 182 484 438 183 484 minecraft:light_blue_concrete
fill 438 182 485 438 183 486 minecraft:soul_soil
fill 438 182 487 438 183 488 minecraft:cyan_concrete
fill 439 182 477 439 182 478 minecraft:cyan_concrete
setblock 439 182 479 minecraft:soul_soil
setblock 439 182 480 minecraft:light_blue_concrete
fill 439 182 481 440 182 481 minecraft:soul_soil
fill 439 182 483 439 183 483 minecraft:light_blue_concrete
fill 439 182 484 439 183 485 minecraft:soul_soil
fill 439 182 486 439 183 486 minecraft:light_blue_concrete
fill 439 182 487 440 183 487 minecraft:soul_soil
fill 439 182 488 439 183 489 minecraft:cyan_concrete
fill 440 182 476 440 182 477 minecraft:cyan_concrete
fill 440 182 482 440 183 482 minecraft:light_blue_concrete
fill 440 182 483 440 183 484 minecraft:soul_soil
fill 440 182 485 440 183 485 minecraft:light_blue_concrete
fill 440 182 486 441 182 486 minecraft:soul_soil
fill 440 182 488 440 183 488 minecraft:light_blue_concrete
fill 440 182 489 440 183 490 minecraft:cyan_concrete
fill 441 182 476 443 183 476 minecraft:cyan_concrete
setblock 441 182 477 minecraft:soul_soil
setblock 441 182 481 minecraft:light_blue_concrete
fill 441 182 482 441 183 483 minecraft:soul_soil
fill 441 182 484 441 183 484 minecraft:light_blue_concrete
fill 441 182 485 442 182 485 minecraft:soul_soil
setblock 441 182 487 minecraft:light_blue_concrete
fill 441 182 488 441 182 489 minecraft:soul_soil
fill 441 182 490 443 182 490 minecraft:cyan_concrete
fill 442 182 475 446 184 475 minecraft:cyan_concrete
setblock 442 182 477 minecraft:light_blue_concrete
fill 442 182 481 442 182 482 minecraft:soul_soil
setblock 442 182 483 minecraft:light_blue_concrete
setblock 442 182 484 minecraft:soul_soil
setblock 442 182 486 minecraft:light_blue_concrete
fill 442 182 491 446 184 491 minecraft:cyan_concrete
fill 443 182 477 443 182 478 minecraft:soul_soil
setblock 443 182 479 minecraft:light_blue_concrete
fill 443 182 480 443 182 481 minecraft:soul_soil
setblock 443 182 485 minecraft:light_blue_concrete
fill 443 182 486 444 182 486 minecraft:soul_soil
fill 444 182 476 444 183 477 minecraft:soul_soil
fill 444 182 478 444 183 478 minecraft:light_blue_concrete
fill 444 182 479 444 183 480 minecraft:soul_soil
setblock 444 182 481 minecraft:light_blue_concrete
fill 444 182 485 445 182 485 minecraft:soul_soil
setblock 444 182 490 minecraft:light_blue_concrete
fill 445 182 476 448 183 476 minecraft:cyan_concrete
setblock 445 182 477 minecraft:light_blue_concrete
fill 445 182 478 445 182 479 minecraft:soul_soil
setblock 445 182 480 minecraft:light_blue_concrete
fill 445 182 481 446 182 481 minecraft:soul_soil
setblock 445 182 486 minecraft:light_blue_concrete
fill 445 182 487 445 182 488 minecraft:soul_soil
setblock 445 182 489 minecraft:light_blue_concrete
fill 445 182 490 448 182 490 minecraft:cyan_concrete
fill 446 182 477 447 182 477 minecraft:soul_soil
setblock 446 182 482 minecraft:light_blue_concrete
fill 446 182 483 446 182 484 minecraft:soul_soil
setblock 446 182 485 minecraft:light_blue_concrete
fill 446 182 486 446 183 487 minecraft:soul_soil
fill 446 182 488 446 183 488 minecraft:light_blue_concrete
fill 446 182 489 447 183 489 minecraft:soul_soil
setblock 447 182 481 minecraft:light_blue_concrete
fill 447 182 482 447 183 483 minecraft:soul_soil
fill 447 182 484 447 183 484 minecraft:light_blue_concrete
fill 447 182 485 447 183 486 minecraft:soul_soil
fill 447 182 487 447 183 487 minecraft:light_blue_concrete
fill 447 182 488 448 183 488 minecraft:soul_soil
fill 448 182 477 449 182 477 minecraft:cyan_concrete
fill 448 182 481 448 182 482 minecraft:soul_soil
fill 448 182 483 448 183 483 minecraft:light_blue_concrete
fill 448 182 484 448 183 485 minecraft:soul_soil
fill 448 182 486 448 183 486 minecraft:light_blue_concrete
fill 448 182 487 449 183 487 minecraft:soul_soil
fill 448 182 489 449 183 489 minecraft:cyan_concrete
fill 449 182 478 450 182 478 minecraft:cyan_concrete
setblock 449 182 479 minecraft:light_blue_concrete
fill 449 182 480 449 182 481 minecraft:soul_soil
fill 449 182 482 449 183 482 minecraft:light_blue_concrete
fill 449 182 483 449 183 484 minecraft:soul_soil
fill 449 182 485 449 183 485 minecraft:light_blue_concrete
fill 449 182 486 450 183 486 minecraft:soul_soil
fill 449 182 488 450 183 488 minecraft:cyan_concrete
fill 450 182 479 451 183 479 minecraft:cyan_concrete
fill 450 182 480 450 183 480 minecraft:soul_soil
fill 450 182 481 450 183 481 minecraft:light_blue_concrete
fill 450 182 482 450 183 483 minecraft:soul_soil
fill 450 182 484 450 183 484 minecraft:light_blue_concrete
fill 450 182 485 450 183 485 minecraft:soul_soil
fill 450 182 487 451 183 487 minecraft:cyan_concrete
fill 451 182 480 451 183 482 minecraft:cyan_concrete
fill 451 182 483 451 183 483 minecraft:light_blue_concrete
fill 451 182 484 451 183 486 minecraft:cyan_concrete
fill 452 182 481 452 183 485 minecraft:cyan_concrete
fill 424 183 464 435 183 504 minecraft:basalt
fill 436 183 464 436 183 479 minecraft:basalt
setblock 436 183 480 minecraft:cyan_concrete
setblock 436 183 486 minecraft:cyan_concrete
fill 436 183 487 436 183 504 minecraft:basalt
fill 437 183 464 437 183 478 minecraft:basalt
fill 437 183 488 437 183 504 minecraft:basalt
fill 438 183 464 439 183 476 minecraft:basalt
setblock 438 183 477 minecraft:cyan_concrete
setblock 438 183 489 minecraft:cyan_concrete
fill 438 183 490 439 183 504 minecraft:basalt
fill 439 183 477 439 183 481 minecraft:sea_lantern
fill 440 183 464 440 183 475 minecraft:basalt
setblock 440 183 476 minecraft:cyan_concrete
fill 440 183 477 443 183 477 minecraft:sea_lantern
fill 440 183 478 442 183 480 minecraft:basalt
fill 440 183 481 442 183 481 minecraft:sea_lantern
setblock 440 183 486 minecraft:soul_soil
fill 440 183 491 440 183 504 minecraft:basalt
fill 441 183 464 464 183 474 minecraft:basalt
setblock 441 183 475 minecraft:cyan_concrete
setblock 441 183 485 minecraft:soul_soil
fill 441 183 486 441 183 490 minecraft:sea_lantern
setblock 441 183 491 minecraft:cyan_concrete
fill 441 183 492 464 183 504 minecraft:basalt
fill 442 183 482 442 183 484 minecraft:pearlescent_froglight
fill 442 183 485 442 183 486 minecraft:sea_lantern
fill 442 183 487 444 183 489 minecraft:basalt
fill 442 183 490 445 183 490 minecraft:sea_lantern
fill 443 183 478 443 183 480 minecraft:sea_lantern
fill 443 183 481 445 183 481 minecraft:pearlescent_froglight
fill 443 183 485 445 183 485 minecraft:pearlescent_froglight
fill 443 183 486 445 183 486 minecraft:sea_lantern
fill 445 183 477 445 183 480 minecraft:sea_lantern
fill 445 183 487 445 183 489 minecraft:sea_lantern
fill 446 183 477 449 183 477 minecraft:sea_lantern
fill 446 183 478 448 183 480 minecraft:basalt
fill 446 183 481 449 183 481 minecraft:sea_lantern
fill 446 183 482 446 183 484 minecraft:pearlescent_froglight
setblock 446 183 485 minecraft:sea_lantern
fill 446 183 490 448 183 490 minecraft:cyan_concrete
setblock 447 183 475 minecraft:cyan_concrete
setblock 447 183 491 minecraft:cyan_concrete
fill 448 183 475 464 183 475 minecraft:basalt
setblock 448 183 482 minecraft:soul_soil
fill 448 183 491 464 183 491 minecraft:basalt
fill 449 183 476 464 183 476 minecraft:basalt
fill 449 183 478 449 183 480 minecraft:sea_lantern
fill 449 183 490 464 183 490 minecraft:basalt
fill 450 183 477 450 183 478 minecraft:cyan_concrete
setblock 450 183 489 minecraft:cyan_concrete
fill 451 183 477 464 183 478 minecraft:basalt
fill 451 183 488 464 183 489 minecraft:basalt
fill 452 183 479 464 183 479 minecraft:basalt
setblock 452 183 480 minecraft:cyan_concrete
setblock 452 183 486 minecraft:cyan_concrete
fill 452 183 487 464 183 487 minecraft:basalt
fill 453 183 480 464 183 486 minecraft:basalt
setblock 426 184 466 minecraft:light[level=11]
setblock 426 184 474 minecraft:light[level=11]
setblock 426 184 482 minecraft:light[level=11]
setblock 426 184 490 minecraft:light[level=11]
setblock 426 184 498 minecraft:light[level=11]
fill 432 184 483 432 185 484 minecraft:cobblestone
setblock 434 184 466 minecraft:light[level=11]
setblock 434 184 474 minecraft:light[level=11]
fill 434 184 476 434 185 477 minecraft:cobblestone
setblock 434 184 482 minecraft:light[level=11]
setblock 434 184 490 minecraft:light[level=11]
fill 434 184 491 434 185 492 minecraft:cobblestone
setblock 434 184 498 minecraft:light[level=11]
fill 435 184 476 440 184 490 minecraft:dark_oak_planks
fill 441 184 472 441 185 473 minecraft:cobblestone
fill 441 184 476 453 184 479 minecraft:dark_oak_planks
fill 441 184 488 453 184 490 minecraft:dark_oak_planks
fill 441 184 495 441 185 496 minecraft:cobblestone
setblock 442 184 466 minecraft:light[level=11]
setblock 442 184 474 minecraft:light[level=11]
setblock 442 184 498 minecraft:light[level=11]
fill 448 184 472 448 185 473 minecraft:cobblestone
fill 448 184 495 448 185 496 minecraft:cobblestone
fill 449 184 480 453 184 487 minecraft:dark_oak_planks
setblock 450 184 466 minecraft:light[level=11]
setblock 450 184 474 minecraft:light[level=11]
setblock 450 184 498 minecraft:light[level=11]
fill 455 184 476 455 185 477 minecraft:cobblestone
fill 455 184 491 455 185 492 minecraft:cobblestone
fill 457 184 483 457 185 484 minecraft:cobblestone
setblock 458 184 466 minecraft:light[level=11]
setblock 458 184 474 minecraft:light[level=11]
setblock 458 184 482 minecraft:light[level=11]
setblock 458 184 490 minecraft:light[level=11]
setblock 458 184 498 minecraft:light[level=11]
fill 435 185 476 435 185 490 minecraft:dark_oak_planks
fill 436 185 476 453 185 476 minecraft:dark_oak_planks
fill 436 185 490 453 185 490 minecraft:dark_oak_planks
fill 453 185 477 453 185 489 minecraft:dark_oak_planks
fill 435 186 476 435 191 476 minecraft:dark_oak_planks
setblock 435 186 477 minecraft:ochre_froglight
fill 435 186 478 435 191 479 minecraft:dark_oak_planks
setblock 435 186 480 minecraft:ochre_froglight
fill 435 186 481 435 191 482 minecraft:dark_oak_planks
setblock 435 186 483 minecraft:ochre_froglight
fill 435 186 484 435 191 485 minecraft:dark_oak_planks
setblock 435 186 486 minecraft:ochre_froglight
fill 435 186 487 435 191 488 minecraft:dark_oak_planks
setblock 435 186 489 minecraft:ochre_froglight
fill 435 186 490 436 191 490 minecraft:dark_oak_planks
setblock 436 186 476 minecraft:ochre_froglight
fill 437 186 476 438 191 476 minecraft:dark_oak_planks
setblock 437 186 490 minecraft:ochre_froglight
fill 438 186 490 439 191 490 minecraft:dark_oak_planks
setblock 439 186 476 minecraft:ochre_froglight
fill 440 186 476 441 191 476 minecraft:dark_oak_planks
setblock 440 186 490 minecraft:ochre_froglight
fill 441 186 490 442 191 490 minecraft:dark_oak_planks
setblock 442 186 476 minecraft:ochre_froglight
fill 443 186 476 444 191 476 minecraft:dark_oak_planks
setblock 443 186 490 minecraft:ochre_froglight
fill 444 186 490 445 191 490 minecraft:dark_oak_planks
setblock 445 186 476 minecraft:ochre_froglight
fill 446 186 476 447 191 476 minecraft:dark_oak_planks
setblock 446 186 490 minecraft:ochre_froglight
fill 447 186 490 448 191 490 minecraft:dark_oak_planks
setblock 448 186 476 minecraft:ochre_froglight
fill 449 186 476 450 191 476 minecraft:dark_oak_planks
setblock 449 186 490 minecraft:ochre_froglight
fill 450 186 490 451 191 490 minecraft:dark_oak_planks
setblock 451 186 476 minecraft:ochre_froglight
fill 452 186 476 453 191 476 minecraft:dark_oak_planks
setblock 452 186 490 minecraft:ochre_froglight
schedule function dropper:buildpart/117_5 1t
