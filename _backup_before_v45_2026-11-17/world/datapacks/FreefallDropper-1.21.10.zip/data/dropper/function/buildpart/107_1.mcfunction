setblock 558 91 452 minecraft:white_wool
setblock 558 91 455 minecraft:light_gray_wool
setblock 558 91 456 minecraft:white_wool
fill 518 95 417 518 98 441 minecraft:black_concrete
fill 518 95 446 518 95 457 minecraft:black_concrete
fill 519 95 417 519 95 438 minecraft:black_concrete
fill 519 95 448 519 95 457 minecraft:black_concrete
fill 520 95 417 520 95 419 minecraft:black_concrete
fill 520 95 431 520 95 433 minecraft:black_concrete
fill 520 95 450 520 95 457 minecraft:black_concrete
fill 521 95 417 524 95 418 minecraft:black_concrete
fill 521 95 453 521 95 457 minecraft:black_concrete
fill 522 95 454 523 95 457 minecraft:black_concrete
fill 524 95 455 527 95 457 minecraft:black_concrete
fill 525 95 417 527 96 417 minecraft:black_concrete
fill 528 95 456 544 95 457 minecraft:black_concrete
fill 532 95 455 542 95 455 minecraft:black_concrete
fill 534 95 417 543 96 417 minecraft:black_concrete
fill 537 95 454 539 95 454 minecraft:black_concrete
fill 545 95 457 546 95 457 minecraft:black_concrete
fill 551 95 433 551 98 433 minecraft:white_wool
fill 553 95 417 558 111 417 minecraft:black_concrete
fill 553 95 457 558 110 457 minecraft:black_concrete
fill 555 95 418 558 111 418 minecraft:black_concrete
fill 555 95 456 558 107 456 minecraft:black_concrete
fill 556 95 427 558 95 436 minecraft:black_concrete
fill 557 95 419 558 99 426 minecraft:black_concrete
fill 557 95 437 558 106 439 minecraft:black_concrete
fill 557 95 452 558 95 455 minecraft:black_concrete
fill 558 95 440 558 96 442 minecraft:black_concrete
fill 558 95 448 558 95 451 minecraft:black_concrete
fill 518 96 447 518 96 457 minecraft:black_concrete
fill 519 96 417 519 96 423 minecraft:black_concrete
fill 519 96 427 519 96 438 minecraft:black_concrete
fill 519 96 449 519 96 457 minecraft:black_concrete
fill 520 96 417 523 97 418 minecraft:black_concrete
fill 520 96 451 520 96 457 minecraft:black_concrete
fill 521 96 454 521 96 457 minecraft:black_concrete
fill 522 96 455 526 96 457 minecraft:black_concrete
fill 524 96 417 524 108 417 minecraft:black_concrete
fill 527 96 456 543 96 457 minecraft:black_concrete
fill 533 96 455 541 96 455 minecraft:black_concrete
fill 544 96 457 545 96 457 minecraft:black_concrete
fill 552 96 417 552 127 417 minecraft:black_concrete
fill 556 96 428 558 96 436 minecraft:black_concrete
fill 557 96 427 558 99 427 minecraft:black_concrete
fill 557 96 453 558 97 455 minecraft:black_concrete
fill 558 96 449 558 96 452 minecraft:black_concrete
fill 518 97 448 518 98 457 minecraft:black_concrete
fill 519 97 417 519 108 421 minecraft:black_concrete
fill 519 97 430 519 97 437 minecraft:black_concrete
fill 519 97 450 519 97 457 minecraft:black_concrete
setblock 520 97 419 minecraft:light[level=12]
setblock 520 97 427 minecraft:light[level=12]
setblock 520 97 435 minecraft:light[level=12]
setblock 520 97 443 minecraft:light[level=12]
setblock 520 97 451 minecraft:light[level=12]
fill 520 97 452 520 97 457 minecraft:black_concrete
fill 521 97 455 524 97 457 minecraft:black_concrete
fill 525 97 417 526 97 417 minecraft:black_concrete
fill 525 97 456 542 97 457 minecraft:black_concrete
setblock 528 97 419 minecraft:light[level=12]
setblock 528 97 427 minecraft:light[level=12]
setblock 528 97 435 minecraft:light[level=12]
setblock 528 97 443 minecraft:light[level=12]
setblock 528 97 451 minecraft:light[level=12]
fill 534 97 417 542 108 417 minecraft:black_concrete
fill 534 97 455 540 97 455 minecraft:black_concrete
setblock 536 97 419 minecraft:light[level=12]
setblock 536 97 427 minecraft:light[level=12]
setblock 536 97 435 minecraft:light[level=12]
setblock 536 97 443 minecraft:light[level=12]
setblock 536 97 451 minecraft:light[level=12]
fill 543 97 457 544 97 457 minecraft:black_concrete
setblock 544 97 419 minecraft:light[level=12]
setblock 544 97 427 minecraft:light[level=12]
setblock 544 97 435 minecraft:light[level=12]
setblock 544 97 443 minecraft:light[level=12]
setblock 544 97 451 minecraft:light[level=12]
setblock 552 97 419 minecraft:light[level=12]
setblock 552 97 427 minecraft:light[level=12]
setblock 552 97 435 minecraft:light[level=12]
setblock 552 97 443 minecraft:light[level=12]
setblock 552 97 451 minecraft:light[level=12]
fill 554 97 418 554 113 418 minecraft:black_concrete
fill 556 97 430 558 97 436 minecraft:black_concrete
fill 557 97 428 558 99 429 minecraft:black_concrete
fill 558 97 440 558 109 441 minecraft:black_concrete
fill 558 97 450 558 97 452 minecraft:black_concrete
fill 517 98 416 517 99 424 minecraft:cobbled_deepslate
setblock 517 98 425 minecraft:black_concrete
fill 517 98 426 517 98 449 minecraft:cobbled_deepslate
setblock 517 98 450 minecraft:black_concrete
fill 517 98 451 517 98 456 minecraft:cobbled_deepslate
fill 517 98 457 517 98 458 minecraft:black_concrete
setblock 518 98 458 minecraft:cobbled_deepslate
fill 519 98 433 519 98 437 minecraft:black_concrete
fill 519 98 451 519 98 458 minecraft:black_concrete
fill 520 98 417 522 100 418 minecraft:black_concrete
fill 520 98 453 520 98 457 minecraft:black_concrete
fill 520 98 458 526 98 458 minecraft:cobbled_deepslate
fill 521 98 455 522 98 457 minecraft:black_concrete
fill 523 98 417 523 108 417 minecraft:black_concrete
fill 523 98 456 541 98 457 minecraft:black_concrete
fill 525 98 417 525 108 417 minecraft:black_concrete
setblock 527 98 458 minecraft:black_concrete
fill 528 98 458 532 98 458 minecraft:cobbled_deepslate
fill 533 98 417 533 111 417 minecraft:black_concrete
setblock 533 98 458 minecraft:black_concrete
fill 534 98 458 553 98 458 minecraft:cobbled_deepslate
fill 535 98 455 538 98 455 minecraft:black_concrete
fill 542 98 457 543 98 457 minecraft:black_concrete
fill 551 98 417 551 140 417 minecraft:black_concrete
fill 552 98 457 552 142 457 minecraft:black_concrete
setblock 554 98 458 minecraft:black_concrete
fill 555 98 458 558 98 458 minecraft:cobbled_deepslate
fill 556 98 431 558 98 436 minecraft:black_concrete
fill 557 98 430 558 101 430 minecraft:black_concrete
fill 557 98 454 558 99 455 minecraft:black_concrete
fill 558 98 451 558 98 453 minecraft:black_concrete
fill 559 98 417 559 98 430 minecraft:cobbled_deepslate
fill 559 98 431 559 99 431 minecraft:black_concrete
fill 559 98 432 559 101 433 minecraft:cobbled_deepslate
setblock 559 98 434 minecraft:black_concrete
fill 559 98 435 559 99 450 minecraft:cobbled_deepslate
fill 559 98 451 559 99 451 minecraft:black_concrete
fill 559 98 452 559 99 457 minecraft:cobbled_deepslate
setblock 559 98 458 minecraft:black_concrete
fill 517 99 425 517 101 425 minecraft:cobbled_deepslate
setblock 517 99 426 minecraft:black_concrete
fill 517 99 427 517 101 427 minecraft:cobbled_deepslate
fill 517 99 428 517 99 429 minecraft:black_concrete
fill 517 99 430 517 99 439 minecraft:cobbled_deepslate
fill 517 99 440 518 99 440 minecraft:black_concrete
fill 517 99 441 517 99 447 minecraft:cobbled_deepslate
fill 517 99 448 517 99 449 minecraft:black_concrete
setblock 517 99 450 minecraft:cobbled_deepslate
fill 517 99 451 518 99 451 minecraft:black_concrete
fill 517 99 452 517 101 454 minecraft:cobbled_deepslate
fill 517 99 455 521 99 455 minecraft:black_concrete
fill 517 99 456 517 101 458 minecraft:cobbled_deepslate
fill 518 99 416 528 99 416 minecraft:cobbled_deepslate
fill 518 99 417 518 99 425 minecraft:black_concrete
fill 518 99 429 518 99 439 minecraft:black_concrete
fill 518 99 441 518 111 442 minecraft:black_concrete
fill 518 99 449 518 141 450 minecraft:black_concrete
fill 518 99 452 519 100 454 minecraft:black_concrete
fill 518 99 456 518 99 458 minecraft:black_concrete
fill 519 99 456 526 99 457 minecraft:black_concrete
fill 519 99 458 524 101 458 minecraft:cobbled_deepslate
setblock 520 99 454 minecraft:black_concrete
setblock 525 99 458 minecraft:black_concrete
fill 526 99 458 527 101 458 minecraft:cobbled_deepslate
fill 527 99 457 542 100 457 minecraft:black_concrete
setblock 528 99 458 minecraft:black_concrete
fill 529 99 416 530 99 416 minecraft:black_concrete
fill 529 99 458 540 99 458 minecraft:cobbled_deepslate
fill 530 99 456 540 99 456 minecraft:black_concrete
fill 531 99 416 531 101 416 minecraft:cobbled_deepslate
fill 532 99 416 532 99 417 minecraft:black_concrete
fill 533 99 416 537 99 416 minecraft:cobbled_deepslate
setblock 538 99 416 minecraft:black_concrete
fill 539 99 416 545 101 416 minecraft:cobbled_deepslate
setblock 541 99 458 minecraft:black_concrete
fill 542 99 458 557 99 458 minecraft:cobbled_deepslate
setblock 546 99 416 minecraft:black_concrete
fill 547 99 416 554 99 416 minecraft:cobbled_deepslate
fill 550 99 417 550 139 417 minecraft:black_concrete
fill 553 99 418 553 113 418 minecraft:black_concrete
setblock 555 99 416 minecraft:black_concrete
fill 556 99 416 559 99 416 minecraft:cobbled_deepslate
fill 556 99 419 556 110 420 minecraft:black_concrete
fill 556 99 433 558 99 436 minecraft:black_concrete
fill 557 99 431 558 101 432 minecraft:black_concrete
fill 558 99 442 558 110 442 minecraft:black_concrete
fill 558 99 452 558 100 453 minecraft:black_concrete
setblock 558 99 458 minecraft:black_concrete
fill 559 99 417 559 101 419 minecraft:cobbled_deepslate
setblock 559 99 420 minecraft:black_concrete
fill 559 99 421 559 101 424 minecraft:cobbled_deepslate
setblock 559 99 425 minecraft:black_concrete
fill 559 99 426 559 99 430 minecraft:cobbled_deepslate
setblock 559 99 434 minecraft:cobbled_deepslate
fill 559 99 458 559 101 458 minecraft:cobbled_deepslate
fill 517 100 416 517 101 421 minecraft:cobbled_deepslate
fill 517 100 422 518 100 422 minecraft:black_concrete
fill 517 100 423 517 101 424 minecraft:cobbled_deepslate
fill 517 100 426 517 101 426 minecraft:cobbled_deepslate
fill 517 100 428 517 101 431 minecraft:cobbled_deepslate
fill 517 100 432 518 100 432 minecraft:black_concrete
fill 517 100 433 517 101 435 minecraft:cobbled_deepslate
fill 517 100 436 518 100 436 minecraft:black_concrete
fill 517 100 437 517 101 441 minecraft:cobbled_deepslate
fill 517 100 442 517 100 443 minecraft:black_concrete
fill 517 100 444 517 101 448 minecraft:cobbled_deepslate
fill 517 100 449 517 100 450 minecraft:black_concrete
fill 517 100 451 517 101 451 minecraft:cobbled_deepslate
fill 517 100 455 517 101 455 minecraft:cobbled_deepslate
fill 518 100 416 521 101 416 minecraft:cobbled_deepslate
fill 518 100 417 518 110 421 minecraft:black_concrete
fill 518 100 423 518 110 424 minecraft:black_concrete
setblock 518 100 431 minecraft:black_concrete
fill 518 100 433 518 102 435 minecraft:black_concrete
fill 518 100 437 518 107 440 minecraft:black_concrete
fill 518 100 443 518 113 443 minecraft:black_concrete
fill 518 100 451 518 139 451 minecraft:black_concrete
fill 518 100 455 520 100 457 minecraft:black_concrete
fill 518 100 458 518 101 458 minecraft:cobbled_deepslate
fill 521 100 456 524 100 457 minecraft:black_concrete
setblock 522 100 416 minecraft:black_concrete
fill 523 100 416 527 101 416 minecraft:cobbled_deepslate
fill 525 100 457 526 108 457 minecraft:black_concrete
fill 525 100 458 525 101 458 minecraft:cobbled_deepslate
setblock 528 100 416 minecraft:black_concrete
fill 528 100 458 528 101 458 minecraft:cobbled_deepslate
fill 529 100 416 530 101 416 minecraft:cobbled_deepslate
setblock 529 100 458 minecraft:black_concrete
fill 530 100 458 534 101 458 minecraft:cobbled_deepslate
fill 531 100 417 532 111 417 minecraft:black_concrete
fill 531 100 456 539 100 456 minecraft:black_concrete
fill 532 100 416 533 101 416 minecraft:cobbled_deepslate
setblock 534 100 416 minecraft:black_concrete
fill 535 100 416 538 101 416 minecraft:cobbled_deepslate
setblock 535 100 458 minecraft:black_concrete
fill 536 100 458 544 101 458 minecraft:cobbled_deepslate
setblock 545 100 458 minecraft:black_concrete
fill 546 100 416 546 101 416 minecraft:cobbled_deepslate
fill 546 100 458 552 101 458 minecraft:cobbled_deepslate
setblock 547 100 416 minecraft:black_concrete
fill 548 100 416 550 101 416 minecraft:cobbled_deepslate
fill 549 100 417 549 139 417 minecraft:black_concrete
setblock 551 100 416 minecraft:black_concrete
fill 552 100 416 555 101 416 minecraft:cobbled_deepslate
fill 552 100 418 552 114 418 minecraft:black_concrete
setblock 553 100 458 minecraft:black_concrete
fill 554 100 419 555 111 419 minecraft:black_concrete
fill 554 100 458 554 101 458 minecraft:cobbled_deepslate
setblock 555 100 458 minecraft:black_concrete
fill 556 100 416 557 100 416 minecraft:black_concrete
fill 556 100 421 558 111 421 minecraft:black_concrete
fill 556 100 435 558 100 435 minecraft:black_concrete
fill 556 100 458 558 101 458 minecraft:cobbled_deepslate
fill 557 100 419 558 111 420 minecraft:black_concrete
fill 557 100 422 558 111 425 minecraft:black_concrete
fill 557 100 429 559 100 429 minecraft:black_concrete
fill 557 100 433 558 103 434 minecraft:black_concrete
fill 557 100 436 558 105 436 minecraft:black_concrete
fill 557 100 440 557 107 440 minecraft:black_concrete
fill 557 100 455 558 106 455 minecraft:black_concrete
fill 558 100 416 559 101 416 minecraft:cobbled_deepslate
fill 558 100 426 558 109 428 minecraft:black_concrete
fill 558 100 454 559 100 454 minecraft:black_concrete
fill 559 100 420 559 101 420 minecraft:cobbled_deepslate
fill 559 100 425 559 101 427 minecraft:cobbled_deepslate
setblock 559 100 428 minecraft:black_concrete
fill 559 100 430 559 101 431 minecraft:cobbled_deepslate
setblock 559 100 434 minecraft:black_concrete
fill 559 100 435 559 101 442 minecraft:cobbled_deepslate
setblock 559 100 443 minecraft:black_concrete
fill 559 100 444 559 101 449 minecraft:cobbled_deepslate
setblock 559 100 450 minecraft:black_concrete
fill 559 100 451 559 101 453 minecraft:cobbled_deepslate
fill 559 100 455 559 101 455 minecraft:cobbled_deepslate
setblock 559 100 456 minecraft:black_concrete
fill 559 100 457 559 101 457 minecraft:cobbled_deepslate
setblock 517 101 422 minecraft:cobbled_deepslate
setblock 517 101 432 minecraft:cobbled_deepslate
setblock 517 101 436 minecraft:cobbled_deepslate
fill 517 101 442 517 101 443 minecraft:cobbled_deepslate
fill 517 101 449 517 101 450 minecraft:cobbled_deepslate
fill 518 101 422 518 111 422 minecraft:black_concrete
fill 518 101 436 518 106 436 minecraft:black_concrete
fill 518 101 444 518 145 445 minecraft:black_concrete
fill 518 101 452 518 110 457 minecraft:black_concrete
fill 519 101 453 519 104 457 minecraft:black_concrete
fill 520 101 417 521 106 418 minecraft:black_concrete
fill 520 101 456 523 102 457 minecraft:black_concrete
fill 522 101 416 522 102 416 minecraft:cobbled_deepslate
fill 522 101 417 522 108 417 minecraft:black_concrete
fill 524 101 457 524 108 457 minecraft:black_concrete
fill 527 101 457 541 101 457 minecraft:black_concrete
setblock 528 101 416 minecraft:cobbled_deepslate
setblock 529 101 458 minecraft:cobbled_deepslate
fill 530 101 417 530 111 417 minecraft:black_concrete
fill 531 101 456 538 101 456 minecraft:black_concrete
setblock 534 101 416 minecraft:cobbled_deepslate
fill 535 101 418 537 108 418 minecraft:black_concrete
setblock 535 101 458 minecraft:cobbled_deepslate
fill 545 101 458 545 102 458 minecraft:cobbled_deepslate
setblock 547 101 416 minecraft:cobbled_deepslate
fill 548 101 417 548 138 417 minecraft:black_concrete
setblock 551 101 416 minecraft:cobbled_deepslate
fill 551 101 418 551 117 418 minecraft:black_concrete
fill 551 101 457 551 141 457 minecraft:black_concrete
fill 553 101 419 553 112 419 minecraft:black_concrete
setblock 553 101 458 minecraft:cobbled_deepslate
fill 554 101 456 554 109 456 minecraft:black_concrete
setblock 555 101 458 minecraft:cobbled_deepslate
fill 556 101 416 557 101 416 minecraft:cobbled_deepslate
fill 556 101 422 556 111 422 minecraft:black_concrete
fill 557 101 426 557 110 426 minecraft:black_concrete
fill 557 101 435 558 105 435 minecraft:black_concrete
fill 558 101 429 558 107 429 minecraft:black_concrete
fill 558 101 443 558 110 443 minecraft:black_concrete
fill 558 101 453 558 108 454 minecraft:black_concrete
fill 559 101 428 559 101 429 minecraft:cobbled_deepslate
setblock 559 101 434 minecraft:cobbled_deepslate
setblock 559 101 443 minecraft:cobbled_deepslate
setblock 559 101 450 minecraft:cobbled_deepslate
setblock 559 101 454 minecraft:cobbled_deepslate
setblock 559 101 456 minecraft:cobbled_deepslate
fill 517 102 416 517 102 434 minecraft:black_concrete
setblock 517 102 435 minecraft:cobbled_deepslate
fill 517 102 436 517 102 448 minecraft:black_concrete
setblock 517 102 449 minecraft:cobbled_deepslate
fill 517 102 450 517 103 452 minecraft:black_concrete
setblock 517 102 453 minecraft:cobbled_deepslate
fill 517 102 454 517 103 458 minecraft:black_concrete
fill 518 102 416 521 103 416 minecraft:black_concrete
fill 518 102 446 518 146 448 minecraft:black_concrete
fill 518 102 458 526 102 458 minecraft:black_concrete
fill 523 102 416 526 202 416 minecraft:black_concrete
fill 526 102 417 529 109 417 minecraft:black_concrete
setblock 527 102 416 minecraft:cobbled_deepslate
fill 527 102 457 540 103 457 minecraft:black_concrete
setblock 527 102 458 minecraft:cobbled_deepslate
fill 528 102 416 553 102 416 minecraft:black_concrete
fill 528 102 458 530 201 458 minecraft:black_concrete
fill 530 102 456 537 103 456 minecraft:black_concrete
setblock 531 102 458 minecraft:cobbled_deepslate
fill 532 102 458 533 204 458 minecraft:black_concrete
fill 533 102 418 534 109 418 minecraft:black_concrete
setblock 534 102 458 minecraft:cobbled_deepslate
fill 535 102 458 544 103 458 minecraft:black_concrete
fill 538 102 418 538 107 418 minecraft:black_concrete
fill 543 102 417 543 109 417 minecraft:black_concrete
fill 546 102 417 547 138 417 minecraft:black_concrete
fill 546 102 458 556 102 458 minecraft:black_concrete
fill 549 102 418 550 123 418 minecraft:black_concrete
fill 552 102 419 552 112 419 minecraft:black_concrete
setblock 554 102 416 minecraft:cobbled_deepslate
fill 555 102 416 557 200 416 minecraft:black_concrete
fill 555 102 420 555 110 420 minecraft:black_concrete
fill 556 102 423 556 111 423 minecraft:black_concrete
fill 557 102 432 559 102 432 minecraft:black_concrete
fill 557 102 441 557 108 441 minecraft:black_concrete
setblock 557 102 458 minecraft:cobbled_deepslate
setblock 558 102 416 minecraft:cobbled_deepslate
fill 558 102 430 558 105 431 minecraft:black_concrete
fill 558 102 444 559 111 444 minecraft:black_concrete
fill 558 102 458 559 102 458 minecraft:black_concrete
fill 559 102 416 559 102 429 minecraft:black_concrete
setblock 559 102 430 minecraft:cobbled_deepslate
fill 559 102 431 559 204 431 minecraft:black_concrete
fill 559 102 433 559 102 438 minecraft:black_concrete
setblock 559 102 439 minecraft:cobbled_deepslate
fill 559 102 440 559 102 443 minecraft:black_concrete
fill 559 102 445 559 103 451 minecraft:black_concrete
setblock 559 102 452 minecraft:cobbled_deepslate
fill 559 102 453 559 102 457 minecraft:black_concrete
fill 517 103 416 517 200 421 minecraft:black_concrete
setblock 517 103 422 minecraft:cobbled_deepslate
fill 517 103 423 517 200 427 minecraft:black_concrete
fill 517 103 428 517 104 428 minecraft:cobbled_deepslate
setblock 517 103 429 minecraft:black_concrete
setblock 517 103 430 minecraft:cobbled_deepslate
fill 517 103 431 517 103 436 minecraft:black_concrete
setblock 517 103 437 minecraft:cobbled_deepslate
fill 517 103 438 517 103 441 minecraft:black_concrete
setblock 517 103 442 minecraft:cobbled_deepslate
fill 517 103 443 517 200 449 minecraft:black_concrete
fill 517 103 453 517 201 453 minecraft:black_concrete
fill 518 103 425 518 109 425 minecraft:black_concrete
fill 518 103 434 518 104 435 minecraft:black_concrete
fill 518 103 458 520 103 458 minecraft:black_concrete
fill 519 103 422 519 107 422 minecraft:black_concrete
fill 519 103 439 519 106 442 minecraft:black_concrete
fill 520 103 456 522 104 457 minecraft:black_concrete
setblock 521 103 458 minecraft:cobbled_deepslate
fill 522 103 416 522 201 416 minecraft:black_concrete
fill 522 103 418 522 104 418 minecraft:black_concrete
fill 522 103 458 527 200 458 minecraft:black_concrete
fill 523 103 457 523 108 457 minecraft:black_concrete
fill 527 103 416 552 103 416 minecraft:black_concrete
fill 531 103 458 531 204 458 minecraft:black_concrete
fill 532 103 418 532 110 418 minecraft:black_concrete
fill 534 103 458 534 204 458 minecraft:black_concrete
fill 539 103 418 539 107 418 minecraft:black_concrete
fill 544 103 417 545 110 417 minecraft:black_concrete
fill 545 103 458 550 201 458 minecraft:black_concrete
fill 548 103 418 548 126 418 minecraft:black_concrete
fill 549 103 423 555 103 423 minecraft:black_concrete
fill 550 103 419 551 113 419 minecraft:black_concrete
fill 550 103 457 550 140 457 minecraft:black_concrete
fill 551 103 458 552 103 458 minecraft:cobbled_deepslate
setblock 553 103 416 minecraft:cobbled_deepslate
fill 553 103 420 554 110 420 minecraft:black_concrete
fill 553 103 456 553 109 456 minecraft:black_concrete
fill 553 103 458 555 103 458 minecraft:black_concrete
fill 554 103 416 554 201 416 minecraft:black_concrete
fill 555 103 421 555 110 422 minecraft:black_concrete
fill 556 103 424 556 110 424 minecraft:black_concrete
setblock 556 103 458 minecraft:cobbled_deepslate
fill 557 103 427 557 109 427 minecraft:black_concrete
fill 557 103 442 557 108 442 minecraft:black_concrete
fill 557 103 458 558 103 458 minecraft:black_concrete
fill 558 103 416 559 103 416 minecraft:black_concrete
fill 558 103 432 559 103 432 minecraft:black_concrete
fill 558 103 445 558 112 445 minecraft:black_concrete
fill 558 103 452 559 108 452 minecraft:black_concrete
fill 559 103 417 559 103 422 minecraft:black_concrete
setblock 559 103 423 minecraft:cobbled_deepslate
fill 559 103 424 559 103 430 minecraft:black_concrete
fill 559 103 433 559 103 437 minecraft:black_concrete
setblock 559 103 438 minecraft:cobbled_deepslate
fill 559 103 439 559 200 442 minecraft:black_concrete
setblock 559 103 443 minecraft:cobbled_deepslate
fill 559 103 453 559 201 456 minecraft:black_concrete
fill 559 103 457 559 103 458 minecraft:cobbled_deepslate
fill 517 104 422 517 201 422 minecraft:black_concrete
setblock 517 104 429 minecraft:cobbled_deepslate
fill 517 104 430 517 204 432 minecraft:black_concrete
fill 517 104 433 517 104 434 minecraft:cobbled_deepslate
fill 517 104 435 517 204 435 minecraft:black_concrete
setblock 517 104 436 minecraft:cobbled_deepslate
fill 517 104 437 517 200 440 minecraft:black_concrete
setblock 517 104 441 minecraft:cobbled_deepslate
fill 517 104 442 517 200 442 minecraft:black_concrete
setblock 517 104 450 minecraft:cobbled_deepslate
fill 517 104 451 517 202 452 minecraft:black_concrete
fill 517 104 454 517 204 457 minecraft:black_concrete
setblock 517 104 458 minecraft:cobbled_deepslate
setblock 518 104 416 minecraft:cobbled_deepslate
fill 518 104 427 519 105 427 minecraft:black_concrete
fill 518 104 431 528 105 431 minecraft:black_concrete
fill 518 104 458 518 205 458 minecraft:black_concrete
fill 519 104 416 519 204 416 minecraft:black_concrete
fill 519 104 423 551 104 423 minecraft:black_concrete
fill 519 104 435 556 104 435 minecraft:black_concrete
fill 519 104 443 519 110 444 minecraft:black_concrete
fill 519 104 447 559 104 447 minecraft:black_concrete
fill 519 104 451 519 105 451 minecraft:black_concrete
setblock 519 104 458 minecraft:cobbled_deepslate
setblock 520 104 416 minecraft:cobbled_deepslate
fill 520 104 439 520 105 439 minecraft:black_concrete
fill 520 104 443 557 104 443 minecraft:black_concrete
fill 520 104 455 520 105 455 minecraft:black_concrete
fill 520 104 458 521 202 458 minecraft:black_concrete
fill 521 104 416 521 204 416 minecraft:black_concrete
fill 527 104 416 539 201 416 minecraft:black_concrete
fill 527 104 457 539 105 457 minecraft:black_concrete
fill 529 104 456 536 105 456 minecraft:black_concrete
fill 530 104 418 531 109 418 minecraft:black_concrete
fill 535 104 458 543 200 458 minecraft:black_concrete
setblock 540 104 416 minecraft:cobbled_deepslate
fill 541 104 416 543 204 416 minecraft:black_concrete
setblock 544 104 416 minecraft:cobbled_deepslate
setblock 544 104 458 minecraft:cobbled_deepslate
fill 545 104 416 547 204 416 minecraft:black_concrete
fill 547 104 418 547 136 418 minecraft:black_concrete
setblock 548 104 416 minecraft:cobbled_deepslate
fill 549 104 416 553 200 416 minecraft:black_concrete
fill 549 104 419 549 113 419 minecraft:black_concrete
fill 549 104 457 549 139 457 minecraft:black_concrete
fill 551 104 420 552 111 420 minecraft:black_concrete
fill 551 104 458 552 200 458 minecraft:black_concrete
setblock 553 104 458 minecraft:cobbled_deepslate
fill 554 104 453 554 129 453 minecraft:white_wool
fill 554 104 458 556 200 458 minecraft:black_concrete
fill 555 104 423 555 110 423 minecraft:black_concrete
fill 556 104 425 556 110 425 minecraft:black_concrete
fill 556 104 439 556 105 439 minecraft:black_concrete
fill 557 104 428 557 107 428 minecraft:black_concrete
fill 557 104 434 559 104 434 minecraft:black_concrete
setblock 557 104 458 minecraft:cobbled_deepslate
setblock 558 104 416 minecraft:cobbled_deepslate
fill 558 104 432 558 105 433 minecraft:black_concrete
fill 558 104 446 559 113 446 minecraft:black_concrete
fill 558 104 458 559 204 458 minecraft:black_concrete
fill 559 104 416 559 205 416 minecraft:black_concrete
setblock 559 104 417 minecraft:cobbled_deepslate
fill 559 104 418 559 202 420 minecraft:black_concrete
setblock 559 104 421 minecraft:cobbled_deepslate
fill 559 104 422 559 200 426 minecraft:black_concrete
setblock 559 104 427 minecraft:cobbled_deepslate
fill 559 104 428 559 201 429 minecraft:black_concrete
setblock 559 104 430 minecraft:cobbled_deepslate
fill 559 104 432 559 104 433 minecraft:cobbled_deepslate
fill 559 104 435 559 201 435 minecraft:black_concrete
setblock 559 104 436 minecraft:cobbled_deepslate
fill 559 104 437 559 201 438 minecraft:black_concrete
fill 559 104 443 559 204 443 minecraft:black_concrete
fill 559 104 445 559 204 445 minecraft:black_concrete
fill 559 104 448 559 201 449 minecraft:black_concrete
setblock 559 104 450 minecraft:cobbled_deepslate
fill 559 104 451 559 204 451 minecraft:black_concrete
fill 559 104 457 559 204 457 minecraft:black_concrete
fill 517 105 428 517 202 429 minecraft:black_concrete
fill 517 105 433 517 204 434 minecraft:black_concrete
fill 517 105 436 517 204 436 minecraft:black_concrete
fill 517 105 441 517 204 441 minecraft:black_concrete
fill 517 105 450 517 204 450 minecraft:black_concrete
fill 517 105 458 517 204 458 minecraft:black_concrete
fill 518 105 416 518 204 416 minecraft:black_concrete
fill 518 105 426 518 108 426 minecraft:black_concrete
fill 518 105 435 520 105 435 minecraft:black_concrete
setblock 519 105 423 minecraft:black_concrete
fill 519 105 445 519 112 447 minecraft:black_concrete
fill 519 105 454 519 105 458 minecraft:black_concrete
fill 520 105 416 520 201 416 minecraft:black_concrete
fill 520 105 419 548 105 419 minecraft:black_concrete
fill 520 105 427 555 105 427 minecraft:black_concrete
setblock 520 105 443 minecraft:black_concrete
fill 520 105 447 521 105 447 minecraft:black_concrete
fill 520 105 451 535 105 451 minecraft:black_concrete
fill 520 105 456 521 105 457 minecraft:black_concrete
fill 521 105 439 537 105 439 minecraft:black_concrete
fill 521 105 455 535 105 455 minecraft:black_concrete
fill 522 105 457 522 108 457 minecraft:black_concrete
setblock 528 105 435 minecraft:light[level=12]
setblock 528 105 443 minecraft:light[level=12]
fill 529 105 418 529 109 418 minecraft:black_concrete
fill 529 105 431 557 105 431 minecraft:black_concrete
setblock 536 105 435 minecraft:light[level=12]
fill 536 105 443 536 105 455 minecraft:white_wool
fill 537 105 451 557 105 451 minecraft:black_concrete
fill 537 105 455 556 105 455 minecraft:black_concrete
fill 540 105 416 540 204 416 minecraft:black_concrete
fill 540 105 418 540 106 418 minecraft:black_concrete
fill 544 105 416 544 204 416 minecraft:black_concrete
setblock 544 105 435 minecraft:light[level=12]
fill 544 105 439 555 105 439 minecraft:black_concrete
setblock 544 105 443 minecraft:light[level=12]
fill 544 105 458 544 204 458 minecraft:black_concrete
fill 546 105 418 546 112 418 minecraft:black_concrete
fill 548 105 416 548 204 416 minecraft:black_concrete
fill 550 105 420 550 111 420 minecraft:black_concrete
setblock 552 105 435 minecraft:light[level=12]
setblock 552 105 443 minecraft:light[level=12]
fill 552 105 456 552 108 456 minecraft:black_concrete
fill 553 105 458 553 200 458 minecraft:black_concrete
fill 554 105 421 554 108 421 minecraft:black_concrete
fill 555 105 424 555 109 424 minecraft:black_concrete
fill 556 105 426 556 109 426 minecraft:black_concrete
setblock 556 105 440 minecraft:black_concrete
fill 557 105 443 557 109 444 minecraft:black_concrete
fill 557 105 458 557 204 458 minecraft:black_concrete
fill 558 105 416 558 201 416 minecraft:black_concrete
fill 558 105 434 559 106 434 minecraft:black_concrete
fill 558 105 447 558 151 448 minecraft:black_concrete
fill 559 105 417 559 204 417 minecraft:black_concrete
fill 559 105 421 559 204 421 minecraft:black_concrete
fill 559 105 427 559 204 427 minecraft:black_concrete
fill 559 105 430 559 204 430 minecraft:black_concrete
fill 559 105 432 559 201 433 minecraft:black_concrete
fill 559 105 436 559 204 436 minecraft:black_concrete
fill 559 105 447 559 204 447 minecraft:black_concrete
fill 559 105 450 559 204 450 minecraft:black_concrete
fill 519 106 448 519 125 448 minecraft:black_concrete
fill 519 106 455 519 106 458 minecraft:black_concrete
fill 520 106 419 520 106 455 minecraft:white_wool
fill 520 106 456 520 106 457 minecraft:black_concrete
fill 521 106 457 521 108 457 minecraft:black_concrete
fill 524 106 418 524 107 425 minecraft:white_wool
fill 527 106 457 538 106 457 minecraft:black_concrete
fill 528 106 418 528 108 418 minecraft:black_concrete
fill 528 106 419 528 107 421 minecraft:white_wool
fill 529 106 456 535 106 456 minecraft:black_concrete
fill 532 106 419 536 106 419 minecraft:black_concrete
fill 532 106 420 532 106 455 minecraft:white_wool
fill 536 106 420 536 106 444 minecraft:white_wool
fill 540 106 419 540 106 435 minecraft:white_wool
fill 540 106 442 540 106 456 minecraft:white_wool
fill 544 106 418 544 106 457 minecraft:white_wool
fill 545 106 418 545 109 418 minecraft:black_concrete
fill 547 106 419 548 111 419 minecraft:black_concrete
fill 548 106 420 548 106 456 minecraft:white_wool
fill 549 106 420 549 111 420 minecraft:black_concrete
fill 551 106 451 551 128 451 minecraft:white_wool
fill 552 106 421 553 109 421 minecraft:black_concrete
fill 553 106 427 556 106 427 minecraft:black_concrete
fill 554 106 422 554 108 422 minecraft:black_concrete
fill 556 106 428 556 107 455 minecraft:white_wool
fill 557 106 445 557 109 445 minecraft:black_concrete
setblock 558 106 430 minecraft:black_concrete
fill 558 106 435 558 106 436 minecraft:black_concrete
fill 558 106 449 558 109 451 minecraft:black_concrete
fill 519 107 440 519 107 442 minecraft:black_concrete
fill 519 107 449 519 109 449 minecraft:black_concrete
fill 519 107 456 519 107 458 minecraft:black_concrete
fill 520 107 417 520 107 418 minecraft:black_concrete
fill 520 107 457 520 109 457 minecraft:black_concrete
fill 521 107 417 521 108 417 minecraft:black_concrete
fill 524 107 426 524 107 456 minecraft:white_wool
fill 527 107 457 537 107 457 minecraft:black_concrete
fill 528 107 422 528 107 456 minecraft:white_wool
fill 529 107 456 533 107 456 minecraft:black_concrete
fill 532 107 419 535 107 419 minecraft:black_concrete
fill 532 107 420 532 107 424 minecraft:white_wool
setblock 540 107 418 minecraft:white_wool
fill 544 107 418 544 107 419 minecraft:white_wool
fill 548 107 420 548 110 420 minecraft:black_concrete
fill 548 107 421 548 107 456 minecraft:white_wool
fill 548 107 457 548 108 457 minecraft:black_concrete
fill 551 107 421 551 109 421 minecraft:black_concrete
fill 552 107 422 552 107 455 minecraft:white_wool
fill 555 107 425 555 108 425 minecraft:black_concrete
setblock 556 107 427 minecraft:white_wool
fill 557 107 439 558 107 439 minecraft:black_concrete
fill 557 107 446 557 109 446 minecraft:black_concrete
fill 558 107 436 558 107 438 minecraft:black_concrete
fill 558 107 455 558 109 455 minecraft:black_concrete
fill 559 107 434 559 204 434 minecraft:black_concrete
fill 518 108 438 518 108 440 minecraft:black_concrete
fill 519 108 441 519 108 442 minecraft:black_concrete
fill 519 108 457 519 109 458 minecraft:black_concrete
fill 520 108 417 520 109 417 minecraft:black_concrete
fill 527 108 457 536 108 457 minecraft:black_concrete
setblock 531 108 456 minecraft:black_concrete
fill 532 108 419 534 108 419 minecraft:black_concrete
setblock 546 108 419 minecraft:black_concrete
setblock 550 108 421 minecraft:black_concrete
fill 555 108 456 556 108 456 minecraft:black_concrete
fill 558 108 438 558 108 439 minecraft:black_concrete
fill 558 108 456 558 109 456 minecraft:black_concrete
fill 518 109 439 518 109 440 minecraft:black_concrete
setblock 519 109 417 minecraft:black_concrete
setblock 519 109 442 minecraft:black_concrete
fill 526 109 457 534 109 457 minecraft:black_concrete
fill 534 109 417 538 109 417 minecraft:black_concrete
setblock 535 109 418 minecraft:black_concrete
fill 559 109 452 559 204 452 minecraft:black_concrete
setblock 518 110 440 minecraft:black_concrete
fill 519 110 458 519 204 458 minecraft:black_concrete
fill 527 110 457 532 110 457 minecraft:black_concrete
fill 528 110 417 529 110 417 minecraft:black_concrete
setblock 531 110 418 minecraft:black_concrete
fill 534 110 417 535 110 417 minecraft:black_concrete
fill 558 110 426 558 111 427 minecraft:black_concrete
fill 558 110 449 558 151 450 minecraft:black_concrete
setblock 518 111 421 minecraft:black_concrete
setblock 518 111 423 minecraft:black_concrete
fill 518 111 452 518 111 453 minecraft:black_concrete
setblock 519 111 444 minecraft:black_concrete
setblock 529 111 417 minecraft:black_concrete
fill 529 111 457 530 111 457 minecraft:black_concrete
fill 545 111 417 545 139 417 minecraft:black_concrete
setblock 553 111 420 minecraft:black_concrete
fill 553 111 457 556 111 457 minecraft:black_concrete
setblock 556 111 420 minecraft:black_concrete
setblock 518 112 442 minecraft:black_concrete
fill 518 112 452 518 138 452 minecraft:black_concrete
setblock 548 112 419 minecraft:black_concrete
fill 553 112 417 557 112 417 minecraft:black_concrete
fill 553 112 457 555 112 457 minecraft:black_concrete
setblock 555 112 418 minecraft:black_concrete
fill 557 112 421 558 112 424 minecraft:black_concrete
fill 558 112 418 558 112 420 minecraft:black_concrete
fill 558 112 425 558 112 426 minecraft:black_concrete
fill 559 112 444 559 204 444 minecraft:black_concrete
fill 519 113 446 519 113 447 minecraft:black_concrete
setblock 520 113 419 minecraft:light[level=12]
setblock 520 113 427 minecraft:light[level=12]
setblock 520 113 435 minecraft:light[level=12]
setblock 520 113 443 minecraft:light[level=12]
setblock 520 113 451 minecraft:light[level=12]
setblock 528 113 419 minecraft:light[level=12]
setblock 528 113 427 minecraft:light[level=12]
setblock 528 113 435 minecraft:light[level=12]
setblock 528 113 443 minecraft:light[level=12]
setblock 528 113 451 minecraft:light[level=12]
setblock 536 113 419 minecraft:light[level=12]
setblock 536 113 427 minecraft:light[level=12]
setblock 536 113 435 minecraft:light[level=12]
setblock 536 113 443 minecraft:light[level=12]
setblock 536 113 451 minecraft:light[level=12]
setblock 544 113 419 minecraft:light[level=12]
setblock 544 113 427 minecraft:light[level=12]
setblock 544 113 435 minecraft:light[level=12]
setblock 544 113 443 minecraft:light[level=12]
setblock 544 113 451 minecraft:light[level=12]
setblock 552 113 419 minecraft:light[level=12]
setblock 552 113 427 minecraft:light[level=12]
setblock 552 113 435 minecraft:light[level=12]
setblock 552 113 443 minecraft:light[level=12]
setblock 552 113 451 minecraft:light[level=12]
fill 553 113 417 556 113 417 minecraft:black_concrete
fill 553 113 457 554 113 457 minecraft:black_concrete
fill 558 113 421 558 113 425 minecraft:black_concrete
fill 519 114 447 519 125 447 minecraft:black_concrete
fill 553 114 417 555 114 417 minecraft:black_concrete
fill 553 114 457 553 142 457 minecraft:black_concrete
fill 558 114 451 558 152 451 minecraft:black_concrete
fill 559 114 446 559 204 446 minecraft:black_concrete
fill 518 115 453 518 137 453 minecraft:black_concrete
fill 519 115 449 519 126 449 minecraft:black_concrete
fill 548 115 457 548 139 457 minecraft:black_concrete
fill 553 115 417 554 115 417 minecraft:black_concrete
fill 558 115 452 558 152 452 minecraft:black_concrete
fill 518 116 454 518 137 454 minecraft:black_concrete
fill 519 116 446 519 125 446 minecraft:black_concrete
fill 519 116 450 519 126 451 minecraft:black_concrete
fill 544 116 417 544 139 417 minecraft:black_concrete
fill 546 116 418 546 137 418 minecraft:black_concrete
fill 546 116 457 547 138 457 minecraft:black_concrete
fill 553 116 417 553 125 417 minecraft:black_concrete
fill 558 116 453 558 140 454 minecraft:black_concrete
fill 519 117 452 519 128 452 minecraft:black_concrete
fill 520 117 419 520 126 419 minecraft:black_concrete
fill 525 117 457 528 126 457 minecraft:black_concrete
fill 543 117 417 543 140 417 minecraft:black_concrete
fill 545 117 418 545 137 418 minecraft:black_concrete
fill 545 117 457 545 138 457 minecraft:black_concrete
fill 547 117 456 551 128 456 minecraft:black_concrete
fill 554 117 457 555 141 457 minecraft:black_concrete
fill 558 117 446 558 150 446 minecraft:black_concrete
fill 558 117 455 558 139 455 minecraft:black_concrete
fill 518 118 443 518 144 443 minecraft:black_concrete
fill 518 118 455 518 137 456 minecraft:black_concrete
fill 519 118 445 519 124 445 minecraft:black_concrete
fill 519 118 453 519 128 453 minecraft:black_concrete
fill 520 118 448 520 123 451 minecraft:black_concrete
fill 522 118 457 524 133 457 minecraft:black_concrete
fill 529 118 457 529 125 457 minecraft:black_concrete
fill 542 118 417 542 140 417 minecraft:black_concrete
fill 543 118 457 544 139 457 minecraft:black_concrete
fill 544 118 418 544 138 418 minecraft:black_concrete
fill 545 118 456 546 135 456 minecraft:black_concrete
fill 552 118 456 552 129 456 minecraft:black_concrete
fill 556 118 457 558 139 457 minecraft:black_concrete
fill 557 118 449 557 124 453 minecraft:black_concrete
fill 558 118 456 558 139 456 minecraft:black_concrete
fill 518 119 428 518 126 433 minecraft:black_concrete
fill 518 119 457 521 136 457 minecraft:black_concrete
fill 519 119 454 519 129 455 minecraft:black_concrete
fill 520 119 447 520 122 447 minecraft:black_concrete
fill 520 119 452 520 125 452 minecraft:black_concrete
fill 522 119 456 528 123 456 minecraft:black_concrete
fill 541 119 417 541 141 417 minecraft:black_concrete
fill 542 119 457 542 140 457 minecraft:black_concrete
fill 543 119 418 543 138 418 minecraft:black_concrete
fill 543 119 456 544 136 456 minecraft:black_concrete
fill 546 119 455 550 125 455 minecraft:black_concrete
fill 553 119 456 554 138 456 minecraft:black_concrete
fill 557 119 448 557 122 448 minecraft:black_concrete
fill 557 119 454 557 138 455 minecraft:black_concrete
fill 518 120 427 518 123 427 minecraft:black_concrete
fill 518 120 434 518 142 436 minecraft:black_concrete
fill 518 120 442 518 144 442 minecraft:black_concrete
fill 519 120 430 519 139 433 minecraft:black_concrete
fill 519 120 456 521 130 456 minecraft:black_concrete
fill 520 120 453 520 125 454 minecraft:black_concrete
fill 522 120 455 526 123 455 minecraft:black_concrete
fill 525 120 417 528 125 417 minecraft:black_concrete
fill 530 120 418 530 128 418 minecraft:black_concrete
fill 530 120 457 530 124 457 minecraft:black_concrete
fill 540 120 417 540 141 417 minecraft:black_concrete
fill 540 120 457 541 140 457 minecraft:black_concrete
fill 542 120 418 542 139 418 minecraft:black_concrete
fill 542 120 456 542 137 456 minecraft:black_concrete
fill 544 120 455 545 128 455 minecraft:black_concrete
fill 545 120 419 547 122 419 minecraft:black_concrete
fill 551 120 455 552 124 455 minecraft:black_concrete
fill 554 120 417 554 123 417 minecraft:black_concrete
fill 555 120 456 557 138 456 minecraft:black_concrete
fill 558 120 428 558 122 431 minecraft:black_concrete
fill 558 120 445 558 150 445 minecraft:black_concrete
fill 518 121 437 518 142 441 minecraft:black_concrete
fill 519 121 429 519 125 429 minecraft:black_concrete
fill 519 121 434 519 139 436 minecraft:black_concrete
fill 519 121 444 519 124 444 minecraft:black_concrete
setblock 520 121 427 minecraft:light[level=12]
fill 520 121 431 520 127 433 minecraft:black_concrete
setblock 520 121 435 minecraft:light[level=12]
setblock 520 121 443 minecraft:light[level=12]
fill 520 121 455 521 125 455 minecraft:black_concrete
fill 521 121 450 521 121 451 minecraft:black_concrete
fill 523 121 417 524 139 417 minecraft:black_concrete
fill 527 121 455 527 122 455 minecraft:black_concrete
setblock 528 121 419 minecraft:light[level=12]
setblock 528 121 427 minecraft:light[level=12]
setblock 528 121 435 minecraft:light[level=12]
setblock 528 121 443 minecraft:light[level=12]
setblock 528 121 451 minecraft:light[level=12]
fill 529 121 456 529 122 456 minecraft:black_concrete
setblock 536 121 419 minecraft:light[level=12]
setblock 536 121 427 minecraft:light[level=12]
setblock 536 121 435 minecraft:light[level=12]
setblock 536 121 443 minecraft:light[level=12]
setblock 536 121 451 minecraft:light[level=12]
fill 538 121 417 539 142 417 minecraft:black_concrete
fill 539 121 457 539 142 457 minecraft:black_concrete
fill 541 121 418 541 140 418 minecraft:black_concrete
fill 541 121 456 541 138 456 minecraft:black_concrete
fill 543 121 455 543 129 455 minecraft:black_concrete
fill 544 121 419 544 126 419 minecraft:black_concrete
setblock 544 121 427 minecraft:light[level=12]
setblock 544 121 435 minecraft:light[level=12]
setblock 544 121 443 minecraft:light[level=12]
setblock 544 121 451 minecraft:light[level=12]
fill 546 121 454 548 123 454 minecraft:black_concrete
setblock 552 121 419 minecraft:light[level=12]
setblock 552 121 427 minecraft:light[level=12]
setblock 552 121 435 minecraft:light[level=12]
setblock 552 121 443 minecraft:light[level=12]
setblock 552 121 451 minecraft:light[level=12]
fill 553 121 455 553 123 455 minecraft:black_concrete
fill 556 121 452 556 123 454 minecraft:black_concrete
fill 558 121 432 558 158 433 minecraft:black_concrete
fill 519 122 419 519 126 419 minecraft:black_concrete
setblock 519 122 428 minecraft:black_concrete
fill 519 122 437 519 140 439 minecraft:black_concrete
fill 520 122 418 520 126 418 minecraft:black_concrete
fill 520 122 420 520 126 420 minecraft:black_concrete
fill 520 122 430 520 125 430 minecraft:black_concrete
fill 520 122 434 520 136 436 minecraft:black_concrete
fill 521 122 419 521 126 419 minecraft:black_concrete
fill 521 122 451 521 122 452 minecraft:black_concrete
fill 522 122 417 522 139 417 minecraft:black_concrete
fill 529 122 417 529 123 417 minecraft:black_concrete
setblock 531 122 457 minecraft:black_concrete
fill 537 122 417 537 145 417 minecraft:black_concrete
fill 538 122 457 538 158 457 minecraft:black_concrete
fill 540 122 418 540 140 418 minecraft:black_concrete
fill 540 122 456 540 138 456 minecraft:black_concrete
fill 542 122 455 542 131 455 minecraft:black_concrete
fill 543 122 419 543 137 419 minecraft:black_concrete
fill 545 122 454 545 124 454 minecraft:black_concrete
fill 554 122 455 554 123 455 minecraft:black_concrete
fill 556 122 455 556 125 455 minecraft:black_concrete
fill 558 122 434 558 158 435 minecraft:black_concrete
fill 519 123 440 519 141 443 minecraft:black_concrete
fill 520 123 437 520 138 438 minecraft:black_concrete
fill 521 123 417 521 139 417 minecraft:black_concrete
fill 521 123 432 521 125 435 minecraft:black_concrete
fill 537 123 457 537 158 457 minecraft:black_concrete
fill 539 123 418 539 141 418 minecraft:black_concrete
fill 539 123 456 539 139 456 minecraft:black_concrete
fill 541 123 455 541 133 455 minecraft:black_concrete
fill 542 123 419 542 138 419 minecraft:black_concrete
fill 544 123 454 544 124 454 minecraft:black_concrete
fill 545 123 419 546 123 419 minecraft:black_concrete
setblock 555 123 455 minecraft:black_concrete
fill 558 123 417 558 140 417 minecraft:black_concrete
fill 558 123 429 558 123 431 minecraft:black_concrete
fill 558 123 436 558 158 437 minecraft:black_concrete
fill 519 124 418 519 126 418 minecraft:black_concrete
fill 519 124 420 519 126 420 minecraft:black_concrete
fill 520 124 417 520 140 417 minecraft:black_concrete
fill 520 124 439 520 138 439 minecraft:black_concrete
fill 520 124 449 520 124 451 minecraft:black_concrete
fill 521 124 418 521 126 418 minecraft:black_concrete
fill 521 124 420 521 126 420 minecraft:black_concrete
fill 521 124 436 521 134 436 minecraft:black_concrete
fill 522 124 455 525 124 456 minecraft:black_concrete
fill 526 124 456 527 124 456 minecraft:black_concrete
fill 529 124 418 529 128 418 minecraft:black_concrete
fill 530 124 417 530 128 417 minecraft:black_concrete
fill 530 124 419 530 128 419 minecraft:black_concrete
fill 531 124 418 531 128 418 minecraft:black_concrete
fill 536 124 417 536 151 417 minecraft:black_concrete
fill 536 124 457 536 158 457 minecraft:black_concrete
fill 545 124 419 545 125 419 minecraft:black_concrete
setblock 546 124 454 minecraft:black_concrete
setblock 549 124 418 minecraft:black_concrete
fill 556 124 453 556 124 454 minecraft:black_concrete
fill 557 124 417 557 140 417 minecraft:black_concrete
fill 558 124 430 558 125 431 minecraft:black_concrete
fill 558 124 438 558 153 439 minecraft:black_concrete
setblock 520 125 451 minecraft:black_concrete
fill 521 125 437 521 135 437 minecraft:black_concrete
fill 522 125 455 524 125 456 minecraft:black_concrete
fill 525 125 456 526 125 456 minecraft:black_concrete
fill 535 125 417 535 153 417 minecraft:black_concrete
fill 538 125 418 538 142 418 minecraft:black_concrete
fill 538 125 456 538 139 456 minecraft:black_concrete
setblock 556 125 454 minecraft:black_concrete
fill 557 125 450 557 126 453 minecraft:black_concrete
fill 558 125 440 558 149 440 minecraft:black_concrete
fill 519 126 417 519 140 417 minecraft:black_concrete
fill 520 126 440 520 139 440 minecraft:black_concrete
fill 521 126 433 521 126 435 minecraft:black_concrete
setblock 521 126 455 minecraft:black_concrete
fill 522 126 456 525 126 456 minecraft:black_concrete
fill 525 126 417 527 139 417 minecraft:black_concrete
fill 529 126 417 529 128 417 minecraft:black_concrete
fill 529 126 419 529 128 419 minecraft:black_concrete
fill 531 126 417 531 158 417 minecraft:black_concrete
fill 531 126 419 531 128 419 minecraft:black_concrete
fill 541 126 419 541 138 419 minecraft:black_concrete
fill 546 126 455 548 126 455 minecraft:black_concrete
fill 558 126 431 558 127 431 minecraft:black_concrete
fill 558 126 441 558 148 444 minecraft:black_concrete
fill 518 127 429 518 156 433 minecraft:black_concrete
setblock 519 127 451 minecraft:black_concrete
fill 521 127 434 521 129 435 minecraft:black_concrete
fill 521 127 438 521 135 438 minecraft:black_concrete
fill 522 127 456 524 127 456 minecraft:black_concrete
fill 525 127 457 527 127 457 minecraft:black_concrete
fill 534 127 417 534 155 417 minecraft:black_concrete
fill 535 127 457 535 158 457 minecraft:black_concrete
fill 537 127 418 537 142 418 minecraft:black_concrete
fill 540 127 419 540 139 419 minecraft:black_concrete
fill 546 127 455 547 127 455 minecraft:black_concrete
fill 556 127 417 556 140 417 minecraft:black_concrete
fill 557 127 451 557 127 453 minecraft:black_concrete
fill 558 127 418 558 140 418 minecraft:black_concrete
fill 518 128 417 518 141 417 minecraft:black_concrete
fill 519 128 444 519 141 444 minecraft:black_concrete
fill 520 128 432 520 135 433 minecraft:black_concrete
fill 520 128 441 520 139 441 minecraft:black_concrete
fill 522 128 456 523 128 456 minecraft:black_concrete
fill 525 128 457 526 128 457 minecraft:black_concrete
fill 533 128 417 533 157 417 minecraft:black_concrete
fill 536 128 418 536 143 418 minecraft:black_concrete
fill 555 128 417 555 141 417 minecraft:black_concrete
fill 557 128 452 557 139 453 minecraft:black_concrete
fill 518 129 418 518 142 419 minecraft:black_concrete
setblock 520 129 419 minecraft:light[level=12]
setblock 520 129 427 minecraft:light[level=12]
fill 520 129 442 520 139 442 minecraft:black_concrete
setblock 520 129 443 minecraft:light[level=12]
setblock 520 129 451 minecraft:light[level=12]
setblock 522 129 456 minecraft:black_concrete
fill 525 129 457 525 130 457 minecraft:black_concrete
fill 528 129 417 528 158 417 minecraft:black_concrete
setblock 528 129 419 minecraft:light[level=12]
setblock 528 129 427 minecraft:light[level=12]
setblock 528 129 435 minecraft:light[level=12]
setblock 528 129 443 minecraft:light[level=12]
setblock 528 129 451 minecraft:light[level=12]
fill 532 129 417 532 158 417 minecraft:black_concrete
fill 535 129 418 535 144 418 minecraft:black_concrete
setblock 536 129 419 minecraft:light[level=12]
setblock 536 129 427 minecraft:light[level=12]
setblock 536 129 435 minecraft:light[level=12]
setblock 536 129 443 minecraft:light[level=12]
setblock 536 129 451 minecraft:light[level=12]
fill 537 129 456 537 140 456 minecraft:black_concrete
fill 538 129 419 539 140 419 minecraft:black_concrete
setblock 544 129 419 minecraft:light[level=12]
setblock 544 129 427 minecraft:light[level=12]
setblock 544 129 435 minecraft:light[level=12]
setblock 544 129 443 minecraft:light[level=12]
setblock 544 129 451 minecraft:light[level=12]
setblock 544 129 455 minecraft:black_concrete
fill 547 129 456 550 129 456 minecraft:black_concrete
fill 552 129 417 554 140 417 minecraft:black_concrete
setblock 552 129 419 minecraft:light[level=12]
setblock 552 129 427 minecraft:light[level=12]
setblock 552 129 435 minecraft:light[level=12]
setblock 552 129 443 minecraft:light[level=12]
setblock 552 129 451 minecraft:light[level=12]
fill 557 129 436 557 141 440 minecraft:black_concrete
fill 558 129 419 558 141 419 minecraft:black_concrete
fill 518 130 420 518 145 421 minecraft:black_concrete
fill 518 130 428 518 155 428 minecraft:black_concrete
fill 519 130 445 519 141 445 minecraft:black_concrete
fill 519 130 455 519 132 455 minecraft:black_concrete
fill 520 130 418 522 138 418 minecraft:black_concrete
fill 521 130 435 521 133 435 minecraft:black_concrete
fill 521 130 439 521 136 439 minecraft:black_concrete
fill 529 130 417 530 158 417 minecraft:black_concrete
fill 534 130 418 534 148 418 minecraft:black_concrete
fill 534 130 457 534 158 457 minecraft:black_concrete
fill 537 130 419 537 141 419 minecraft:black_concrete
fill 544 130 419 544 136 419 minecraft:black_concrete
fill 547 130 456 549 130 456 minecraft:black_concrete
fill 557 130 435 557 140 435 minecraft:black_concrete
fill 557 130 441 557 145 443 minecraft:black_concrete
fill 558 130 420 558 142 420 minecraft:black_concrete
fill 518 131 422 518 152 424 minecraft:black_concrete
fill 518 131 426 518 154 427 minecraft:black_concrete
fill 519 131 418 519 139 420 minecraft:black_concrete
fill 519 131 446 519 141 446 minecraft:black_concrete
fill 519 131 456 520 132 456 minecraft:black_concrete
fill 520 131 443 520 139 443 minecraft:black_concrete
fill 521 131 440 521 136 440 minecraft:black_concrete
fill 523 131 418 524 138 418 minecraft:black_concrete
fill 533 131 418 533 151 418 minecraft:black_concrete
fill 533 131 457 533 158 457 minecraft:black_concrete
fill 535 131 419 536 142 419 minecraft:black_concrete
fill 536 131 456 536 140 456 minecraft:black_concrete
fill 547 131 456 548 132 456 minecraft:black_concrete
fill 552 131 456 552 137 456 minecraft:black_concrete
fill 557 131 418 557 139 418 minecraft:black_concrete
fill 557 131 434 557 139 434 minecraft:black_concrete
fill 557 131 444 557 147 446 minecraft:black_concrete
fill 557 131 451 557 151 451 minecraft:black_concrete
fill 558 131 421 558 143 421 minecraft:black_concrete
fill 558 131 431 558 158 431 minecraft:black_concrete
fill 518 132 425 518 154 425 minecraft:black_concrete
fill 519 132 421 519 142 422 minecraft:black_concrete
fill 519 132 429 519 153 429 minecraft:black_concrete
fill 519 132 447 519 140 447 minecraft:black_concrete
fill 520 132 444 520 138 444 minecraft:black_concrete
fill 521 132 441 521 136 441 minecraft:black_concrete
fill 525 132 418 525 137 418 minecraft:black_concrete
fill 531 132 418 532 153 418 minecraft:black_concrete
fill 534 132 419 534 142 419 minecraft:black_concrete
fill 537 132 420 541 137 420 minecraft:black_concrete
fill 540 132 455 540 134 455 minecraft:black_concrete
fill 555 132 418 556 139 418 minecraft:black_concrete
fill 556 132 438 556 140 443 minecraft:black_concrete
fill 557 132 419 557 139 419 minecraft:black_concrete
fill 557 132 447 557 149 450 minecraft:black_concrete
fill 558 132 422 558 144 423 minecraft:black_concrete
fill 519 133 423 519 145 428 minecraft:black_concrete
fill 519 133 448 519 139 448 minecraft:black_concrete
fill 519 133 456 519 134 456 minecraft:black_concrete
fill 520 133 419 520 138 420 minecraft:black_concrete
fill 520 133 445 520 138 445 minecraft:black_concrete
fill 521 133 419 521 137 419 minecraft:black_concrete
fill 526 133 418 530 138 418 minecraft:black_concrete
fill 532 133 419 533 143 419 minecraft:black_concrete
fill 532 133 457 532 158 457 minecraft:black_concrete
fill 535 133 420 536 140 420 minecraft:black_concrete
fill 535 133 456 535 140 456 minecraft:black_concrete
fill 547 133 456 547 134 456 minecraft:black_concrete
fill 548 133 418 548 136 418 minecraft:black_concrete
fill 551 133 456 551 136 456 minecraft:black_concrete
fill 553 133 418 554 139 418 minecraft:black_concrete
fill 556 133 436 556 138 437 minecraft:black_concrete
fill 556 133 444 556 145 445 minecraft:black_concrete
fill 557 133 420 557 140 421 minecraft:black_concrete
fill 557 133 433 557 138 433 minecraft:black_concrete
fill 558 133 424 558 151 425 minecraft:black_concrete
fill 558 133 429 558 157 430 minecraft:black_concrete
fill 520 134 421 520 139 423 minecraft:black_concrete
fill 521 134 442 521 135 442 minecraft:black_concrete
fill 522 134 419 522 136 419 minecraft:black_concrete
fill 522 134 457 523 134 457 minecraft:black_concrete
fill 531 134 419 531 142 419 minecraft:black_concrete
fill 531 134 457 531 158 457 minecraft:black_concrete
fill 534 134 420 534 141 420 minecraft:black_concrete
fill 539 134 455 539 135 455 minecraft:black_concrete
fill 542 134 420 542 135 420 minecraft:black_concrete
fill 551 134 418 552 137 418 minecraft:black_concrete
fill 555 134 440 555 139 442 minecraft:black_concrete
fill 556 134 446 556 147 448 minecraft:black_concrete
fill 557 134 422 557 141 423 minecraft:black_concrete
fill 558 134 426 558 154 428 minecraft:black_concrete
fill 519 135 449 519 136 449 minecraft:black_concrete
fill 520 135 424 520 140 425 minecraft:black_concrete
setblock 522 135 457 minecraft:black_concrete
setblock 523 135 419 minecraft:black_concrete
fill 530 135 419 530 140 419 minecraft:black_concrete
fill 533 135 420 533 140 420 minecraft:black_concrete
fill 534 135 456 534 139 456 minecraft:black_concrete
fill 537 135 421 538 136 421 minecraft:black_concrete
fill 549 135 418 550 135 418 minecraft:black_concrete
fill 555 135 439 555 138 439 minecraft:black_concrete
fill 555 135 443 555 142 445 minecraft:black_concrete
fill 556 135 419 556 137 419 minecraft:black_concrete
fill 556 135 449 556 148 449 minecraft:black_concrete
fill 557 135 424 557 143 424 minecraft:black_concrete
fill 557 135 432 557 138 432 minecraft:black_concrete
fill 520 136 426 520 139 426 minecraft:black_concrete
setblock 520 136 433 minecraft:black_concrete
setblock 520 136 446 minecraft:black_concrete
fill 529 136 419 529 138 419 minecraft:black_concrete
fill 532 136 420 532 140 420 minecraft:black_concrete
fill 535 136 421 536 138 421 minecraft:black_concrete
setblock 550 136 418 minecraft:black_concrete
fill 555 136 419 555 137 419 minecraft:black_concrete
fill 555 136 446 555 143 446 minecraft:black_concrete
fill 556 136 420 556 138 421 minecraft:black_concrete
fill 556 136 450 556 141 450 minecraft:black_concrete
fill 557 136 425 557 149 426 minecraft:black_concrete
fill 518 137 457 520 137 457 minecraft:black_concrete
setblock 520 137 427 minecraft:light[level=12]
fill 520 137 435 520 137 436 minecraft:black_concrete
setblock 520 137 451 minecraft:light[level=12]
setblock 528 137 419 minecraft:light[level=12]
setblock 528 137 427 minecraft:light[level=12]
setblock 528 137 435 minecraft:light[level=12]
setblock 528 137 443 minecraft:light[level=12]
setblock 528 137 451 minecraft:light[level=12]
fill 531 137 420 531 138 420 minecraft:black_concrete
setblock 536 137 427 minecraft:light[level=12]
setblock 536 137 435 minecraft:light[level=12]
setblock 536 137 443 minecraft:light[level=12]
setblock 536 137 451 minecraft:light[level=12]
setblock 537 137 421 minecraft:black_concrete
setblock 543 137 456 minecraft:black_concrete
setblock 544 137 419 minecraft:light[level=12]
setblock 544 137 427 minecraft:light[level=12]
setblock 544 137 435 minecraft:light[level=12]
setblock 544 137 443 minecraft:light[level=12]
setblock 544 137 451 minecraft:light[level=12]
setblock 552 137 419 minecraft:light[level=12]
setblock 552 137 427 minecraft:light[level=12]
setblock 552 137 435 minecraft:light[level=12]
setblock 552 137 443 minecraft:light[level=12]
setblock 552 137 451 minecraft:light[level=12]
fill 555 137 447 555 143 447 minecraft:black_concrete
fill 556 137 422 556 138 422 minecraft:black_concrete
fill 556 137 451 556 138 451 minecraft:black_concrete
fill 557 137 427 557 152 427 minecraft:black_concrete
setblock 518 138 457 minecraft:black_concrete
fill 537 138 420 540 138 420 minecraft:black_concrete
setblock 552 138 418 minecraft:black_concrete
fill 555 138 448 555 141 448 minecraft:black_concrete
fill 557 138 428 557 153 428 minecraft:black_concrete
setblock 520 139 418 minecraft:black_concrete
fill 528 139 418 530 140 418 minecraft:black_concrete
fill 537 139 420 538 139 420 minecraft:black_concrete
fill 554 139 456 555 139 456 minecraft:black_concrete
setblock 556 139 437 minecraft:black_concrete
fill 519 140 419 519 140 420 minecraft:black_concrete
fill 519 140 430 519 140 431 minecraft:black_concrete
setblock 520 140 423 minecraft:black_concrete
fill 526 140 417 527 140 417 minecraft:black_concrete
setblock 537 140 420 minecraft:black_concrete
fill 555 140 441 555 140 442 minecraft:black_concrete
fill 556 140 457 557 140 457 minecraft:black_concrete
setblock 557 140 452 minecraft:black_concrete
setblock 519 141 420 minecraft:black_concrete
setblock 519 141 430 minecraft:black_concrete
setblock 527 141 417 minecraft:black_concrete
fill 529 141 418 530 142 418 minecraft:black_concrete
setblock 540 141 457 minecraft:black_concrete
fill 553 141 417 554 141 417 minecraft:black_concrete
fill 555 141 442 556 141 442 minecraft:black_concrete
fill 556 141 439 556 141 441 minecraft:black_concrete
fill 556 141 443 556 144 443 minecraft:black_concrete
setblock 557 141 421 minecraft:black_concrete
setblock 558 141 453 minecraft:black_concrete
fill 518 142 449 518 149 449 minecraft:black_concrete
fill 524 142 428 524 154 428 minecraft:white_wool
setblock 554 142 457 minecraft:black_concrete
fill 556 142 440 556 142 442 minecraft:black_concrete
setblock 557 142 423 minecraft:black_concrete
fill 557 142 429 557 154 429 minecraft:black_concrete
fill 557 142 438 557 142 440 minecraft:black_concrete
setblock 518 143 419 minecraft:black_concrete
fill 518 143 434 518 158 434 minecraft:black_concrete
fill 518 143 439 518 143 441 minecraft:black_concrete
setblock 519 143 422 minecraft:black_concrete
fill 530 143 418 530 157 418 minecraft:black_concrete
setblock 538 143 417 minecraft:black_concrete
setblock 555 143 445 minecraft:black_concrete
setblock 556 143 442 minecraft:black_concrete
fill 557 143 439 557 143 440 minecraft:black_concrete
fill 530 144 457 530 158 457 minecraft:black_concrete
fill 557 144 430 557 155 430 minecraft:black_concrete
setblock 557 144 440 minecraft:black_concrete
fill 519 145 430 519 154 430 minecraft:black_concrete
setblock 520 145 419 minecraft:light[level=12]
setblock 520 145 427 minecraft:light[level=12]
setblock 520 145 435 minecraft:light[level=12]
setblock 520 145 443 minecraft:light[level=12]
setblock 520 145 451 minecraft:light[level=12]
fill 527 145 417 527 158 417 minecraft:black_concrete
setblock 528 145 419 minecraft:light[level=12]
setblock 528 145 427 minecraft:light[level=12]
setblock 528 145 435 minecraft:light[level=12]
setblock 528 145 443 minecraft:light[level=12]
setblock 528 145 451 minecraft:light[level=12]
fill 529 145 418 529 158 418 minecraft:black_concrete
fill 529 145 457 529 158 457 minecraft:black_concrete
fill 532 145 456 535 157 456 minecraft:black_concrete
setblock 536 145 419 minecraft:light[level=12]
setblock 536 145 427 minecraft:light[level=12]
setblock 536 145 435 minecraft:light[level=12]
setblock 536 145 443 minecraft:light[level=12]
setblock 536 145 451 minecraft:light[level=12]
fill 536 145 454 536 150 454 minecraft:black_concrete
setblock 544 145 419 minecraft:light[level=12]
setblock 544 145 427 minecraft:light[level=12]
setblock 544 145 435 minecraft:light[level=12]
setblock 544 145 443 minecraft:light[level=12]
setblock 544 145 451 minecraft:light[level=12]
fill 550 145 457 553 155 457 minecraft:black_concrete
setblock 552 145 419 minecraft:light[level=12]
setblock 552 145 427 minecraft:light[level=12]
setblock 552 145 435 minecraft:light[level=12]
setblock 552 145 443 minecraft:light[level=12]
setblock 552 145 451 minecraft:light[level=12]
fill 557 145 431 557 155 431 minecraft:black_concrete
fill 558 145 423 558 149 423 minecraft:black_concrete
fill 518 146 421 518 150 421 minecraft:black_concrete
fill 519 146 424 519 150 428 minecraft:black_concrete
fill 519 146 431 519 154 431 minecraft:black_concrete
fill 526 146 417 526 158 417 minecraft:black_concrete
fill 528 146 457 528 158 457 minecraft:black_concrete
fill 530 146 456 531 158 456 minecraft:black_concrete
fill 536 146 456 536 157 456 minecraft:black_concrete
fill 548 146 457 549 158 457 minecraft:black_concrete
setblock 556 146 445 minecraft:black_concrete
fill 557 146 432 557 156 433 minecraft:black_concrete
fill 557 146 442 557 146 443 minecraft:black_concrete
fill 518 147 435 518 158 435 minecraft:black_concrete
setblock 518 147 448 minecraft:black_concrete
fill 525 147 417 525 158 417 minecraft:black_concrete
fill 527 147 457 527 158 457 minecraft:black_concrete
fill 528 147 418 528 158 418 minecraft:black_concrete
fill 528 147 456 529 158 456 minecraft:black_concrete
fill 531 147 455 534 154 455 minecraft:black_concrete
fill 537 147 456 537 156 456 minecraft:black_concrete
fill 539 147 457 539 158 457 minecraft:black_concrete
fill 545 147 457 547 158 457 minecraft:black_concrete
fill 548 147 456 552 154 456 minecraft:black_concrete
fill 554 147 457 554 154 457 minecraft:black_concrete
fill 556 147 428 556 151 431 minecraft:black_concrete
fill 557 147 434 557 157 434 minecraft:black_concrete
setblock 557 147 443 minecraft:black_concrete
fill 558 147 453 558 152 453 minecraft:black_concrete
fill 518 148 450 518 150 451 minecraft:black_concrete
fill 519 148 432 519 154 432 minecraft:black_concrete
fill 524 148 417 524 158 417 minecraft:black_concrete
fill 525 148 457 526 158 457 minecraft:black_concrete
fill 527 148 418 527 158 418 minecraft:black_concrete
fill 527 148 456 527 158 456 minecraft:black_concrete
fill 529 148 455 530 158 455 minecraft:black_concrete
fill 535 148 454 535 150 455 minecraft:black_concrete
fill 536 148 453 536 150 453 minecraft:black_concrete
fill 536 148 455 536 153 455 minecraft:black_concrete
fill 537 148 454 537 150 454 minecraft:black_concrete
fill 538 148 456 538 157 456 minecraft:black_concrete
fill 540 148 457 544 158 457 minecraft:black_concrete
fill 546 148 456 547 158 456 minecraft:black_concrete
fill 547 148 439 557 148 439 minecraft:black_concrete
fill 548 148 455 551 153 455 minecraft:black_concrete
fill 553 148 456 553 152 456 minecraft:black_concrete
fill 556 148 427 556 150 427 minecraft:black_concrete
fill 556 148 432 556 153 432 minecraft:black_concrete
setblock 556 148 448 minecraft:black_concrete
fill 557 148 435 557 158 435 minecraft:black_concrete
fill 557 148 445 557 148 446 minecraft:black_concrete
fill 518 149 419 520 150 419 minecraft:black_concrete
fill 518 149 436 518 155 436 minecraft:black_concrete
fill 518 149 439 537 149 439 minecraft:black_concrete
fill 518 149 443 519 150 443 minecraft:black_concrete
fill 518 149 447 556 149 447 minecraft:black_concrete
fill 518 149 452 518 152 452 minecraft:black_concrete
fill 518 149 455 519 150 455 minecraft:black_concrete
fill 519 149 423 557 149 423 minecraft:black_concrete
fill 519 149 433 519 154 433 minecraft:black_concrete
fill 519 149 435 519 150 435 minecraft:black_concrete
fill 519 149 451 519 150 451 minecraft:black_concrete
fill 520 149 427 520 150 427 minecraft:black_concrete
fill 520 149 431 521 150 431 minecraft:black_concrete
fill 523 149 417 523 158 417 minecraft:black_concrete
fill 524 149 457 524 158 457 minecraft:black_concrete
fill 525 149 456 526 158 456 minecraft:black_concrete
fill 526 149 418 526 158 418 minecraft:black_concrete
fill 527 149 455 528 158 455 minecraft:black_concrete
fill 530 149 454 533 152 454 minecraft:black_concrete
fill 535 149 453 535 150 453 minecraft:black_concrete
fill 537 149 453 537 150 453 minecraft:black_concrete
fill 537 149 455 537 152 455 minecraft:black_concrete
fill 539 149 456 539 158 456 minecraft:black_concrete
fill 543 149 439 549 149 439 minecraft:black_concrete
fill 543 149 456 545 158 456 minecraft:black_concrete
fill 546 149 455 547 156 455 minecraft:black_concrete
fill 550 149 417 550 156 417 minecraft:black_concrete
fill 552 149 455 552 152 455 minecraft:black_concrete
setblock 555 149 419 minecraft:white_wool
fill 555 149 457 555 152 457 minecraft:black_concrete
fill 556 149 433 556 153 433 minecraft:black_concrete
fill 557 149 436 557 155 436 minecraft:black_concrete
setblock 557 149 446 minecraft:black_concrete
setblock 557 149 452 minecraft:black_concrete
fill 558 149 442 558 149 444 minecraft:black_concrete
fill 558 149 454 558 152 454 minecraft:black_concrete
fill 518 150 439 519 150 439 minecraft:black_concrete
fill 518 150 447 519 150 447 minecraft:black_concrete
fill 518 150 453 518 152 453 minecraft:black_concrete
fill 519 150 423 531 150 423 minecraft:black_concrete
fill 520 150 435 537 150 435 minecraft:black_concrete
fill 520 150 443 523 150 443 minecraft:black_concrete
fill 520 150 446 520 150 457 minecraft:white_wool
fill 521 150 419 558 150 419 minecraft:black_concrete
fill 521 150 427 555 150 427 minecraft:black_concrete
fill 521 150 447 523 150 447 minecraft:black_concrete
fill 521 150 451 523 150 451 minecraft:black_concrete
fill 521 150 455 523 150 455 minecraft:black_concrete
fill 522 150 417 522 158 417 minecraft:black_concrete
fill 522 150 431 555 150 431 minecraft:black_concrete
fill 522 150 457 523 158 457 minecraft:black_concrete
fill 524 150 443 524 150 455 minecraft:white_wool
fill 524 150 456 524 158 456 minecraft:black_concrete
fill 525 150 418 525 158 418 minecraft:black_concrete
fill 525 150 443 557 150 443 minecraft:black_concrete
fill 525 150 451 551 150 451 minecraft:black_concrete
fill 525 150 455 526 158 455 minecraft:black_concrete
fill 528 150 454 529 155 454 minecraft:black_concrete
fill 534 150 454 534 151 454 minecraft:black_concrete
setblock 536 150 452 minecraft:black_concrete
fill 538 150 454 538 150 455 minecraft:black_concrete
fill 539 150 455 545 150 455 minecraft:black_concrete
fill 540 150 456 542 158 456 minecraft:black_concrete
fill 543 150 435 556 150 435 minecraft:black_concrete
fill 547 150 454 550 151 454 minecraft:black_concrete
fill 548 150 417 549 158 417 minecraft:black_concrete
fill 551 150 417 551 154 417 minecraft:black_concrete
fill 553 150 455 557 150 455 minecraft:black_concrete
fill 556 150 434 556 153 434 minecraft:black_concrete
fill 557 150 426 557 151 426 minecraft:black_concrete
fill 557 150 449 557 150 450 minecraft:black_concrete
setblock 518 151 451 minecraft:black_concrete
fill 518 151 454 518 153 454 minecraft:black_concrete
fill 519 151 425 519 151 428 minecraft:black_concrete
fill 520 151 417 521 158 417 minecraft:black_concrete
fill 520 151 418 520 151 448 minecraft:white_wool
fill 521 151 457 521 158 457 minecraft:black_concrete
fill 523 151 456 523 158 456 minecraft:black_concrete
fill 524 151 418 524 158 418 minecraft:black_concrete
fill 524 151 419 524 151 427 minecraft:white_wool
fill 524 151 429 524 151 445 minecraft:white_wool
fill 527 151 454 527 155 454 minecraft:black_concrete
fill 528 151 419 529 151 419 minecraft:black_concrete
fill 528 151 420 528 151 453 minecraft:white_wool
fill 535 151 455 535 154 455 minecraft:black_concrete
fill 536 151 418 536 151 454 minecraft:white_wool
fill 540 151 417 540 152 422 minecraft:white_wool
fill 542 151 455 545 155 455 minecraft:black_concrete
fill 544 151 417 544 152 418 minecraft:white_wool
fill 546 151 417 547 158 417 minecraft:black_concrete
fill 546 151 454 546 153 454 minecraft:black_concrete
fill 548 151 418 548 152 453 minecraft:white_wool
fill 549 151 451 556 151 451 minecraft:black_concrete
setblock 552 151 417 minecraft:black_concrete
fill 552 151 418 552 152 419 minecraft:white_wool
fill 555 151 419 556 151 419 minecraft:white_wool
setblock 555 151 455 minecraft:black_concrete
fill 556 151 417 556 152 418 minecraft:white_wool
fill 556 151 420 556 151 427 minecraft:white_wool
fill 556 151 435 556 151 450 minecraft:white_wool
fill 556 151 452 556 151 456 minecraft:white_wool
fill 557 151 437 557 152 437 minecraft:black_concrete
setblock 557 151 455 minecraft:black_concrete
fill 518 152 455 518 155 455 minecraft:black_concrete
fill 519 152 417 519 158 417 minecraft:black_concrete
fill 519 152 426 519 152 428 minecraft:black_concrete
setblock 520 152 418 minecraft:white_wool
fill 520 152 457 520 158 457 minecraft:black_concrete
fill 522 152 456 522 158 456 minecraft:black_concrete
fill 523 152 418 523 158 418 minecraft:black_concrete
fill 524 152 455 524 158 455 minecraft:black_concrete
fill 526 152 454 526 154 454 minecraft:black_concrete
fill 527 152 419 528 152 419 minecraft:black_concrete
fill 532 152 419 532 152 446 minecraft:white_wool
fill 536 152 417 536 152 423 minecraft:white_wool
fill 540 152 423 540 152 434 minecraft:white_wool
fill 540 152 441 540 152 455 minecraft:white_wool
fill 541 152 455 541 153 455 minecraft:black_concrete
fill 544 152 419 544 152 454 minecraft:white_wool
fill 545 152 417 545 158 417 minecraft:black_concrete
fill 545 152 454 545 153 454 minecraft:black_concrete
fill 547 152 454 549 152 454 minecraft:black_concrete
setblock 552 152 417 minecraft:white_wool
fill 552 152 420 552 152 454 minecraft:white_wool
fill 555 152 419 555 158 419 minecraft:white_wool
fill 556 152 429 556 152 431 minecraft:black_concrete
setblock 558 152 425 minecraft:black_concrete
setblock 558 152 450 minecraft:black_concrete
fill 518 153 417 518 158 417 minecraft:black_concrete
setblock 518 153 424 minecraft:black_concrete
fill 518 153 456 518 158 456 minecraft:black_concrete
fill 519 153 426 519 158 426 minecraft:white_wool
setblock 519 153 428 minecraft:black_concrete
fill 519 153 457 519 158 457 minecraft:black_concrete
setblock 520 153 419 minecraft:light[level=12]
setblock 520 153 427 minecraft:light[level=12]
setblock 520 153 435 minecraft:light[level=12]
setblock 520 153 443 minecraft:light[level=12]
setblock 520 153 451 minecraft:light[level=12]
setblock 527 153 419 minecraft:black_concrete
setblock 528 153 419 minecraft:light[level=12]
setblock 528 153 427 minecraft:light[level=12]
setblock 528 153 435 minecraft:light[level=12]
setblock 528 153 443 minecraft:light[level=12]
setblock 528 153 451 minecraft:light[level=12]
fill 530 153 454 532 153 454 minecraft:black_concrete
fill 532 153 444 532 153 453 minecraft:white_wool
setblock 536 153 419 minecraft:light[level=12]
setblock 536 153 427 minecraft:light[level=12]
setblock 536 153 435 minecraft:light[level=12]
setblock 536 153 443 minecraft:light[level=12]
setblock 536 153 451 minecraft:light[level=12]
setblock 544 153 419 minecraft:light[level=12]
setblock 544 153 427 minecraft:light[level=12]
setblock 544 153 435 minecraft:light[level=12]
setblock 544 153 443 minecraft:light[level=12]
setblock 544 153 451 minecraft:light[level=12]
fill 544 153 452 544 153 454 minecraft:white_wool
fill 547 153 454 548 153 454 minecraft:black_concrete
setblock 552 153 419 minecraft:light[level=12]
setblock 552 153 427 minecraft:light[level=12]
setblock 552 153 435 minecraft:light[level=12]
setblock 552 153 443 minecraft:light[level=12]
setblock 552 153 451 minecraft:light[level=12]
setblock 556 153 431 minecraft:black_concrete
fill 518 154 457 518 158 457 minecraft:black_concrete
fill 521 154 456 521 158 456 minecraft:black_concrete
fill 522 154 418 522 158 418 minecraft:black_concrete
fill 523 154 455 523 158 455 minecraft:black_concrete
fill 530 154 454 531 154 454 minecraft:black_concrete
setblock 531 154 418 minecraft:black_concrete
fill 544 154 417 544 158 417 minecraft:black_concrete
fill 548 154 455 550 154 455 minecraft:black_concrete
fill 558 154 438 558 158 438 minecraft:black_concrete
fill 518 155 418 518 158 418 minecraft:black_concrete
setblock 518 155 427 minecraft:black_concrete
fill 531 155 455 533 155 455 minecraft:black_concrete
fill 548 155 455 549 155 456 minecraft:black_concrete
fill 550 155 456 551 155 456 minecraft:black_concrete
fill 558 155 427 558 155 428 minecraft:black_concrete
fill 521 156 418 521 158 418 minecraft:black_concrete
fill 531 156 455 532 156 455 minecraft:black_concrete
fill 543 156 417 543 158 417 minecraft:black_concrete
fill 543 156 455 545 156 455 minecraft:black_concrete
fill 548 156 456 550 156 456 minecraft:black_concrete
fill 550 156 457 552 156 457 minecraft:black_concrete
setblock 558 156 428 minecraft:black_concrete
fill 518 157 419 518 158 419 minecraft:black_concrete
fill 518 157 431 518 157 433 minecraft:black_concrete
fill 520 157 418 520 158 418 minecraft:black_concrete
fill 520 157 456 520 158 456 minecraft:black_concrete
setblock 531 157 455 minecraft:black_concrete
fill 542 157 417 542 158 417 minecraft:black_concrete
fill 544 157 455 546 157 455 minecraft:black_concrete
fill 548 157 456 549 157 456 minecraft:black_concrete
fill 550 157 457 551 157 457 minecraft:black_concrete
setblock 557 157 433 minecraft:black_concrete
setblock 518 158 420 minecraft:black_concrete
fill 518 158 432 518 158 433 minecraft:black_concrete
setblock 518 158 436 minecraft:black_concrete
setblock 518 158 455 minecraft:black_concrete
setblock 519 158 418 minecraft:black_concrete
fill 524 158 419 525 158 419 minecraft:black_concrete
fill 532 158 456 534 158 456 minecraft:black_concrete
setblock 541 158 417 minecraft:black_concrete
setblock 548 158 456 minecraft:black_concrete
setblock 550 158 457 minecraft:black_concrete
setblock 558 158 430 minecraft:black_concrete
setblock 558 158 439 minecraft:black_concrete
setblock 520 161 419 minecraft:light[level=12]
setblock 520 161 427 minecraft:light[level=12]
setblock 520 161 435 minecraft:light[level=12]
setblock 520 161 443 minecraft:light[level=12]
setblock 520 161 451 minecraft:light[level=12]
setblock 528 161 419 minecraft:light[level=12]
setblock 528 161 427 minecraft:light[level=12]
setblock 528 161 435 minecraft:light[level=12]
setblock 528 161 443 minecraft:light[level=12]
setblock 528 161 451 minecraft:light[level=12]
setblock 536 161 419 minecraft:light[level=12]
setblock 536 161 427 minecraft:light[level=12]
setblock 536 161 435 minecraft:light[level=12]
setblock 536 161 443 minecraft:light[level=12]
setblock 536 161 451 minecraft:light[level=12]
setblock 544 161 419 minecraft:light[level=12]
setblock 544 161 427 minecraft:light[level=12]
setblock 544 161 435 minecraft:light[level=12]
setblock 544 161 443 minecraft:light[level=12]
setblock 544 161 451 minecraft:light[level=12]
setblock 552 161 419 minecraft:light[level=12]
setblock 552 161 427 minecraft:light[level=12]
setblock 552 161 435 minecraft:light[level=12]
setblock 552 161 443 minecraft:light[level=12]
setblock 552 161 451 minecraft:light[level=12]
fill 519 164 435 537 164 439 minecraft:black_concrete
fill 520 164 431 556 164 434 minecraft:black_concrete
fill 520 164 440 556 164 443 minecraft:black_concrete
fill 521 164 429 555 164 430 minecraft:black_concrete
fill 521 164 444 555 164 445 minecraft:black_concrete
fill 522 164 427 554 164 428 minecraft:black_concrete
fill 522 164 446 554 164 447 minecraft:black_concrete
fill 523 164 426 553 164 426 minecraft:black_concrete
fill 523 164 448 553 164 448 minecraft:black_concrete
fill 524 164 424 552 164 425 minecraft:black_concrete
fill 524 164 449 552 164 450 minecraft:black_concrete
fill 525 164 423 551 164 423 minecraft:black_concrete
fill 525 164 451 551 164 451 minecraft:black_concrete
fill 527 164 422 549 164 422 minecraft:black_concrete
fill 527 164 452 549 164 452 minecraft:black_concrete
fill 528 164 421 548 164 421 minecraft:black_concrete
fill 528 164 453 548 164 453 minecraft:black_concrete
fill 530 164 420 546 164 420 minecraft:black_concrete
fill 530 164 454 546 164 454 minecraft:black_concrete
fill 532 164 419 544 164 419 minecraft:black_concrete
fill 532 164 455 544 164 455 minecraft:black_concrete
fill 536 164 418 540 164 418 minecraft:black_concrete
fill 536 164 456 540 164 456 minecraft:black_concrete
setblock 538 164 435 minecraft:black_concrete
setblock 538 164 436 minecraft:red_concrete
setblock 538 164 438 minecraft:red_concrete
setblock 538 164 439 minecraft:black_concrete
setblock 539 164 435 minecraft:red_concrete
setblock 539 164 439 minecraft:red_concrete
setblock 541 164 435 minecraft:red_concrete
setblock 541 164 439 minecraft:red_concrete
fill 542 164 435 557 164 435 minecraft:black_concrete
setblock 542 164 436 minecraft:red_concrete
setblock 542 164 438 minecraft:red_concrete
fill 542 164 439 557 164 439 minecraft:black_concrete
fill 543 164 436 557 164 438 minecraft:black_concrete
fill 518 165 417 519 165 457 minecraft:cobbled_deepslate
fill 520 165 417 520 165 432 minecraft:cobbled_deepslate
fill 520 165 433 536 165 441 minecraft:black_concrete
fill 520 165 442 520 165 457 minecraft:cobbled_deepslate
fill 521 165 417 521 165 429 minecraft:cobbled_deepslate
fill 521 165 430 535 165 432 minecraft:black_concrete
fill 521 165 442 535 165 444 minecraft:black_concrete
fill 521 165 445 521 165 457 minecraft:cobbled_deepslate
fill 522 165 417 522 165 427 minecraft:cobbled_deepslate
fill 522 165 428 537 165 429 minecraft:black_concrete
fill 522 165 445 537 165 446 minecraft:black_concrete
fill 522 165 447 522 165 457 minecraft:cobbled_deepslate
fill 523 165 417 523 165 426 minecraft:cobbled_deepslate
fill 523 165 427 553 165 427 minecraft:black_concrete
fill 523 165 447 553 165 447 minecraft:black_concrete
fill 523 165 448 523 165 457 minecraft:cobbled_deepslate
fill 524 165 417 524 165 424 minecraft:cobbled_deepslate
fill 524 165 425 552 165 426 minecraft:black_concrete
fill 524 165 448 552 165 449 minecraft:black_concrete
fill 524 165 450 524 165 457 minecraft:cobbled_deepslate
fill 525 165 417 525 165 423 minecraft:cobbled_deepslate
fill 525 165 424 551 165 424 minecraft:black_concrete
fill 525 165 450 551 165 450 minecraft:black_concrete
fill 525 165 451 525 165 457 minecraft:cobbled_deepslate
fill 526 165 417 527 165 422 minecraft:cobbled_deepslate
fill 526 165 423 550 165 423 minecraft:black_concrete
fill 526 165 451 550 165 451 minecraft:black_concrete
fill 526 165 452 527 165 457 minecraft:cobbled_deepslate
fill 528 165 417 528 165 421 minecraft:cobbled_deepslate
fill 528 165 422 548 165 422 minecraft:black_concrete
fill 528 165 452 548 165 452 minecraft:black_concrete
fill 528 165 453 528 165 457 minecraft:cobbled_deepslate
fill 529 165 417 530 165 420 minecraft:cobbled_deepslate
fill 529 165 421 547 165 421 minecraft:black_concrete
fill 529 165 453 547 165 453 minecraft:black_concrete
fill 529 165 454 530 165 457 minecraft:cobbled_deepslate
fill 531 165 417 533 165 419 minecraft:cobbled_deepslate
fill 531 165 420 545 165 420 minecraft:black_concrete
fill 531 165 454 545 165 454 minecraft:black_concrete
fill 531 165 455 533 165 457 minecraft:cobbled_deepslate
fill 534 165 417 558 165 418 minecraft:cobbled_deepslate
fill 534 165 419 542 165 419 minecraft:black_concrete
fill 534 165 455 542 165 455 minecraft:black_concrete
fill 534 165 456 558 165 457 minecraft:cobbled_deepslate
fill 536 165 430 544 176 431 minecraft:green_terracotta
fill 536 165 432 537 165 432 minecraft:black_concrete
fill 536 165 442 537 165 442 minecraft:black_concrete
fill 536 165 443 544 176 444 minecraft:lime_terracotta
fill 537 165 433 537 165 434 minecraft:black_concrete
setblock 537 165 435 minecraft:red_concrete
fill 537 165 436 537 165 438 minecraft:crying_obsidian
setblock 537 165 439 minecraft:red_concrete
fill 537 165 440 537 165 441 minecraft:black_concrete
fill 538 165 428 554 165 428 minecraft:black_concrete
fill 538 165 429 542 176 429 minecraft:green_terracotta
fill 538 165 432 542 175 432 minecraft:green_terracotta
fill 538 165 433 556 165 433 minecraft:black_concrete
setblock 538 165 434 minecraft:red_concrete
fill 538 165 435 538 165 436 minecraft:verdant_froglight
fill 538 165 438 538 165 439 minecraft:verdant_froglight
setblock 538 165 440 minecraft:red_concrete
fill 538 165 441 556 165 441 minecraft:black_concrete
fill 538 165 442 542 175 442 minecraft:lime_terracotta
fill 538 165 445 542 176 445 minecraft:lime_terracotta
fill 538 165 446 554 165 446 minecraft:black_concrete
fill 539 165 434 541 165 434 minecraft:crying_obsidian
setblock 539 165 435 minecraft:verdant_froglight
setblock 539 165 439 minecraft:verdant_froglight
fill 539 165 440 541 165 440 minecraft:crying_obsidian
fill 541 165 435 542 165 435 minecraft:verdant_froglight
fill 541 165 439 542 165 439 minecraft:verdant_froglight
fill 542 165 434 556 165 434 minecraft:black_concrete
setblock 542 165 436 minecraft:verdant_froglight
setblock 542 165 438 minecraft:verdant_froglight
fill 542 165 440 556 165 440 minecraft:black_concrete
fill 543 165 419 558 165 419 minecraft:cobbled_deepslate
fill 543 165 429 554 165 429 minecraft:black_concrete
fill 543 165 432 555 165 432 minecraft:black_concrete
fill 543 165 435 556 165 435 minecraft:black_concrete
fill 543 165 436 543 165 438 minecraft:crying_obsidian
fill 543 165 439 556 165 439 minecraft:black_concrete
fill 543 165 442 555 165 442 minecraft:black_concrete
fill 543 165 445 554 165 445 minecraft:black_concrete
fill 543 165 455 558 165 455 minecraft:cobbled_deepslate
fill 544 165 436 556 165 438 minecraft:black_concrete
fill 545 165 430 555 165 431 minecraft:black_concrete
fill 545 165 443 555 165 444 minecraft:black_concrete
fill 546 165 420 558 165 420 minecraft:cobbled_deepslate
fill 546 165 454 558 165 454 minecraft:cobbled_deepslate
fill 548 165 421 558 165 421 minecraft:cobbled_deepslate
fill 548 165 453 558 165 453 minecraft:cobbled_deepslate
fill 549 165 422 558 165 422 minecraft:cobbled_deepslate
fill 549 165 452 558 165 452 minecraft:cobbled_deepslate
fill 551 165 423 558 165 423 minecraft:cobbled_deepslate
fill 551 165 451 558 165 451 minecraft:cobbled_deepslate
fill 552 165 424 558 165 424 minecraft:cobbled_deepslate
fill 552 165 450 558 165 450 minecraft:cobbled_deepslate
fill 553 165 425 558 165 426 minecraft:cobbled_deepslate
fill 553 165 448 558 165 449 minecraft:cobbled_deepslate
fill 554 165 427 558 165 427 minecraft:cobbled_deepslate
fill 554 165 447 558 165 447 minecraft:cobbled_deepslate
fill 555 165 428 558 165 429 minecraft:cobbled_deepslate
fill 555 165 445 558 165 446 minecraft:cobbled_deepslate
fill 556 165 430 558 165 432 minecraft:cobbled_deepslate
fill 556 165 442 558 165 444 minecraft:cobbled_deepslate
fill 557 165 433 558 165 441 minecraft:cobbled_deepslate
fill 521 166 432 533 166 442 minecraft:black_concrete
fill 522 166 429 533 166 431 minecraft:black_concrete
fill 522 166 443 533 166 445 minecraft:black_concrete
fill 523 166 428 536 166 428 minecraft:black_concrete
fill 523 166 446 536 166 446 minecraft:black_concrete
fill 524 166 426 552 166 427 minecraft:black_concrete
fill 524 166 447 552 166 448 minecraft:black_concrete
fill 525 166 425 551 166 425 minecraft:black_concrete
fill 525 166 449 551 166 449 minecraft:black_concrete
fill 526 166 424 550 166 424 minecraft:black_concrete
fill 526 166 450 550 166 450 minecraft:black_concrete
fill 527 166 423 549 166 423 minecraft:black_concrete
fill 527 166 451 549 166 451 minecraft:black_concrete
fill 529 166 422 547 166 422 minecraft:black_concrete
fill 529 166 452 547 166 452 minecraft:black_concrete
fill 530 166 421 546 166 421 minecraft:black_concrete
fill 530 166 453 546 166 453 minecraft:black_concrete
fill 533 166 420 543 166 420 minecraft:black_concrete
fill 533 166 454 543 166 454 minecraft:black_concrete
fill 534 166 429 535 175 432 minecraft:green_terracotta
fill 534 166 433 535 166 441 minecraft:black_concrete
fill 534 166 442 535 175 445 minecraft:lime_terracotta
fill 536 166 429 537 176 429 minecraft:green_terracotta
fill 536 166 432 537 176 432 minecraft:green_terracotta
fill 536 166 433 536 166 434 minecraft:black_concrete
fill 536 166 435 536 166 439 minecraft:red_concrete
fill 536 166 440 536 166 441 minecraft:black_concrete
fill 536 166 442 537 176 442 minecraft:lime_terracotta
fill 536 166 445 537 176 445 minecraft:lime_terracotta
fill 537 166 428 543 175 428 minecraft:green_terracotta
fill 537 166 433 543 170 433 minecraft:green_terracotta
setblock 537 166 434 minecraft:red_concrete
setblock 537 166 440 minecraft:red_concrete
fill 537 166 441 543 170 441 minecraft:lime_terracotta
fill 537 166 446 543 175 446 minecraft:lime_terracotta
setblock 542 166 434 minecraft:red_concrete
setblock 542 166 440 minecraft:red_concrete
fill 543 166 429 546 175 429 minecraft:green_terracotta
fill 543 166 432 546 175 432 minecraft:green_terracotta
fill 543 166 434 555 166 434 minecraft:black_concrete
fill 543 166 435 543 166 436 minecraft:red_concrete
fill 543 166 438 543 166 439 minecraft:red_concrete
fill 543 166 440 555 166 440 minecraft:black_concrete
fill 543 166 442 546 175 442 minecraft:lime_terracotta
fill 543 166 445 546 175 445 minecraft:lime_terracotta
fill 544 166 428 553 166 428 minecraft:black_concrete
fill 544 166 433 555 166 433 minecraft:black_concrete
fill 544 166 435 555 166 436 minecraft:black_concrete
fill 544 166 437 544 167 437 minecraft:red_concrete
fill 544 166 438 555 166 439 minecraft:black_concrete
fill 544 166 441 555 166 441 minecraft:black_concrete
fill 544 166 446 553 166 446 minecraft:black_concrete
fill 545 166 430 546 176 431 minecraft:green_terracotta
fill 545 166 437 555 167 437 minecraft:black_concrete
fill 545 166 443 546 176 444 minecraft:lime_terracotta
fill 547 166 429 554 166 432 minecraft:black_concrete
fill 547 166 442 554 166 445 minecraft:black_concrete
setblock 555 166 432 minecraft:black_concrete
setblock 555 166 442 minecraft:black_concrete
fill 521 167 434 533 167 440 minecraft:black_concrete
fill 522 167 431 531 167 433 minecraft:black_concrete
fill 522 167 441 531 167 443 minecraft:black_concrete
fill 523 167 429 531 167 430 minecraft:black_concrete
fill 523 167 444 531 167 445 minecraft:black_concrete
fill 524 167 427 533 167 428 minecraft:black_concrete
fill 524 167 446 533 167 447 minecraft:black_concrete
fill 525 167 426 551 167 426 minecraft:black_concrete
fill 525 167 448 551 167 448 minecraft:black_concrete
fill 526 167 425 550 167 425 minecraft:black_concrete
fill 526 167 449 550 167 449 minecraft:black_concrete
fill 527 167 424 549 167 424 minecraft:black_concrete
fill 527 167 450 549 167 450 minecraft:black_concrete
fill 528 167 423 548 167 423 minecraft:black_concrete
fill 528 167 451 548 167 451 minecraft:black_concrete
fill 530 167 422 546 167 422 minecraft:black_concrete
fill 530 167 452 546 167 452 minecraft:black_concrete
fill 532 167 421 544 167 421 minecraft:black_concrete
setblock 532 167 429 minecraft:black_concrete
fill 532 167 430 533 175 431 minecraft:green_terracotta
fill 532 167 432 532 167 433 minecraft:black_concrete
fill 532 167 441 532 167 442 minecraft:black_concrete
fill 532 167 443 533 175 444 minecraft:lime_terracotta
setblock 532 167 445 minecraft:black_concrete
fill 532 167 453 544 167 453 minecraft:black_concrete
fill 533 167 429 533 175 429 minecraft:green_terracotta
fill 533 167 432 533 175 432 minecraft:green_terracotta
setblock 533 167 433 minecraft:black_concrete
setblock 533 167 441 minecraft:black_concrete
fill 533 167 442 533 175 442 minecraft:lime_terracotta
fill 533 167 445 533 175 445 minecraft:lime_terracotta
fill 534 167 427 538 167 427 minecraft:black_concrete
fill 534 167 428 536 174 428 minecraft:green_terracotta
fill 534 167 433 536 171 433 minecraft:green_terracotta
fill 534 167 434 534 167 436 minecraft:black_concrete
fill 534 167 437 535 167 437 minecraft:red_concrete
fill 534 167 438 534 167 440 minecraft:black_concrete
fill 534 167 441 536 171 441 minecraft:lime_terracotta
fill 534 167 446 536 174 446 minecraft:lime_terracotta
fill 534 167 447 538 167 447 minecraft:black_concrete
fill 535 167 420 541 167 420 minecraft:black_concrete
fill 535 167 434 535 167 436 minecraft:red_concrete
fill 535 167 438 535 167 440 minecraft:red_concrete
fill 535 167 454 541 167 454 minecraft:black_concrete
setblock 536 167 434 minecraft:red_concrete
setblock 536 167 440 minecraft:red_concrete
fill 539 167 427 541 174 427 minecraft:green_terracotta
fill 539 167 434 541 167 434 minecraft:green_terracotta
fill 539 167 440 541 167 440 minecraft:lime_terracotta
fill 539 167 447 541 174 447 minecraft:lime_terracotta
fill 542 167 427 552 167 427 minecraft:black_concrete
fill 542 167 447 552 167 447 minecraft:black_concrete
setblock 543 167 434 minecraft:red_concrete
setblock 543 167 440 minecraft:red_concrete
fill 544 167 428 546 174 428 minecraft:green_terracotta
fill 544 167 433 546 170 433 minecraft:green_terracotta
fill 544 167 434 555 167 434 minecraft:black_concrete
fill 544 167 435 544 167 436 minecraft:red_concrete
fill 544 167 438 544 167 439 minecraft:red_concrete
fill 544 167 440 555 167 440 minecraft:black_concrete
fill 544 167 441 546 170 441 minecraft:lime_terracotta
fill 544 167 446 546 174 446 minecraft:lime_terracotta
fill 545 167 435 555 167 436 minecraft:black_concrete
fill 545 167 438 555 167 439 minecraft:black_concrete
fill 547 167 428 552 167 428 minecraft:black_concrete
fill 547 167 429 547 175 432 minecraft:green_terracotta
fill 547 167 433 554 167 433 minecraft:black_concrete
fill 547 167 441 554 167 441 minecraft:black_concrete
fill 547 167 442 547 175 445 minecraft:lime_terracotta
fill 547 167 446 552 167 446 minecraft:black_concrete
fill 548 167 429 553 167 429 minecraft:black_concrete
fill 548 167 430 548 175 431 minecraft:green_terracotta
fill 548 167 432 554 167 432 minecraft:black_concrete
fill 548 167 442 554 167 442 minecraft:black_concrete
fill 548 167 443 548 175 444 minecraft:lime_terracotta
fill 548 167 445 553 167 445 minecraft:black_concrete
fill 549 167 430 553 167 431 minecraft:black_concrete
fill 549 167 443 553 167 444 minecraft:black_concrete
setblock 554 167 431 minecraft:black_concrete
setblock 554 167 443 minecraft:black_concrete
fill 522 168 433 532 168 441 minecraft:black_concrete
fill 523 168 430 530 168 432 minecraft:black_concrete
fill 523 168 442 530 168 444 minecraft:black_concrete
fill 524 168 429 530 168 429 minecraft:black_concrete
fill 524 168 445 530 168 445 minecraft:black_concrete
fill 525 168 427 532 168 428 minecraft:black_concrete
fill 525 168 446 532 168 447 minecraft:black_concrete
fill 526 168 426 550 168 426 minecraft:black_concrete
fill 526 168 448 550 168 448 minecraft:black_concrete
fill 527 168 425 549 168 425 minecraft:black_concrete
fill 527 168 449 549 168 449 minecraft:black_concrete
fill 528 168 424 548 168 424 minecraft:black_concrete
fill 528 168 450 548 168 450 minecraft:black_concrete
fill 530 168 423 546 168 423 minecraft:black_concrete
fill 530 168 451 546 168 451 minecraft:black_concrete
fill 531 168 422 545 168 422 minecraft:black_concrete
fill 531 168 429 531 173 432 minecraft:green_terracotta
fill 531 168 442 531 173 445 minecraft:lime_terracotta
fill 531 168 452 545 168 452 minecraft:black_concrete
fill 532 168 429 532 174 429 minecraft:green_terracotta
fill 532 168 432 532 174 432 minecraft:green_terracotta
fill 532 168 442 532 174 442 minecraft:lime_terracotta
fill 532 168 445 532 174 445 minecraft:lime_terracotta
fill 533 168 427 535 168 427 minecraft:black_concrete
fill 533 168 428 533 174 428 minecraft:green_terracotta
fill 533 168 433 533 174 433 minecraft:green_terracotta
fill 533 168 434 533 168 435 minecraft:black_concrete
fill 533 168 436 533 168 438 minecraft:red_concrete
fill 533 168 439 533 168 440 minecraft:black_concrete
fill 533 168 441 533 174 441 minecraft:lime_terracotta
fill 533 168 446 533 174 446 minecraft:lime_terracotta
fill 533 168 447 535 168 447 minecraft:black_concrete
fill 534 168 421 542 168 421 minecraft:black_concrete
fill 534 168 434 534 168 436 minecraft:red_concrete
fill 534 168 438 534 168 440 minecraft:red_concrete
fill 534 168 453 542 168 453 minecraft:black_concrete
fill 536 168 427 538 174 427 minecraft:green_terracotta
fill 536 168 434 539 168 434 minecraft:green_terracotta
fill 536 168 440 539 168 440 minecraft:lime_terracotta
fill 536 168 447 538 174 447 minecraft:lime_terracotta
fill 541 168 434 544 168 434 minecraft:green_terracotta
fill 541 168 440 544 168 440 minecraft:lime_terracotta
fill 542 168 427 544 174 427 minecraft:green_terracotta
fill 542 168 447 544 174 447 minecraft:lime_terracotta
setblock 544 168 435 minecraft:red_concrete
setblock 544 168 439 minecraft:red_concrete
fill 545 168 427 551 168 427 minecraft:black_concrete
fill 545 168 434 554 168 435 minecraft:black_concrete
fill 545 168 436 545 169 438 minecraft:red_concrete
fill 545 168 439 554 168 440 minecraft:black_concrete
fill 545 168 447 551 168 447 minecraft:black_concrete
fill 546 168 436 554 168 438 minecraft:black_concrete
fill 547 168 428 547 174 428 minecraft:green_terracotta
fill 547 168 433 547 172 433 minecraft:green_terracotta
fill 547 168 441 547 172 441 minecraft:lime_terracotta
fill 547 168 446 547 174 446 minecraft:lime_terracotta
fill 548 168 428 551 168 428 minecraft:black_concrete
fill 548 168 429 549 173 429 minecraft:green_terracotta
fill 548 168 432 549 173 432 minecraft:green_terracotta
fill 548 168 433 554 168 433 minecraft:black_concrete
fill 548 168 441 554 168 441 minecraft:black_concrete
fill 548 168 442 549 173 442 minecraft:lime_terracotta
fill 548 168 445 549 173 445 minecraft:lime_terracotta
fill 548 168 446 551 168 446 minecraft:black_concrete
fill 549 168 430 549 174 431 minecraft:green_terracotta
fill 549 168 443 549 174 444 minecraft:lime_terracotta
fill 550 168 429 552 168 432 minecraft:black_concrete
fill 550 168 442 552 168 445 minecraft:black_concrete
fill 553 168 430 553 168 432 minecraft:black_concrete
fill 553 168 442 553 168 444 minecraft:black_concrete
fill 518 169 417 518 179 430 minecraft:black_concrete
fill 518 169 437 518 169 457 minecraft:black_concrete
fill 519 169 417 519 172 427 minecraft:black_concrete
fill 519 169 440 519 169 457 minecraft:black_concrete
fill 520 169 417 520 169 425 minecraft:black_concrete
setblock 520 169 427 minecraft:light[level=12]
setblock 520 169 435 minecraft:light[level=12]
fill 520 169 443 520 169 448 minecraft:black_concrete
setblock 520 169 451 minecraft:light[level=12]
fill 520 169 456 523 169 457 minecraft:black_concrete
fill 521 169 417 522 169 419 minecraft:black_concrete
fill 523 169 417 524 169 418 minecraft:black_concrete
fill 523 169 432 530 169 442 minecraft:black_concrete
fill 524 169 430 529 169 431 minecraft:black_concrete
fill 524 169 443 529 169 444 minecraft:black_concrete
fill 524 169 457 526 169 457 minecraft:black_concrete
fill 525 169 417 526 169 417 minecraft:black_concrete
fill 525 169 428 530 169 429 minecraft:black_concrete
fill 525 169 445 530 169 446 minecraft:black_concrete
fill 526 169 427 533 169 427 minecraft:black_concrete
fill 526 169 447 533 169 447 minecraft:black_concrete
fill 527 169 426 549 169 426 minecraft:black_concrete
fill 527 169 448 549 169 448 minecraft:black_concrete
setblock 528 169 419 minecraft:light[level=12]
fill 528 169 425 548 169 425 minecraft:black_concrete
fill 528 169 449 548 169 449 minecraft:black_concrete
setblock 528 169 451 minecraft:light[level=12]
fill 529 169 424 547 169 424 minecraft:black_concrete
fill 529 169 450 547 169 450 minecraft:black_concrete
fill 530 169 430 530 173 431 minecraft:green_terracotta
fill 530 169 443 530 173 444 minecraft:lime_terracotta
fill 531 169 423 545 169 423 minecraft:black_concrete
setblock 531 169 428 minecraft:black_concrete
fill 531 169 433 531 169 441 minecraft:black_concrete
setblock 531 169 446 minecraft:black_concrete
fill 531 169 451 545 169 451 minecraft:black_concrete
fill 532 169 428 532 173 428 minecraft:green_terracotta
fill 532 169 433 532 173 433 minecraft:green_terracotta
fill 532 169 434 532 169 435 minecraft:black_concrete
fill 532 169 436 532 169 438 minecraft:red_concrete
fill 532 169 439 532 169 440 minecraft:black_concrete
fill 532 169 441 532 173 441 minecraft:lime_terracotta
fill 532 169 446 532 173 446 minecraft:lime_terracotta
fill 533 169 422 543 169 422 minecraft:black_concrete
fill 533 169 434 533 169 435 minecraft:red_concrete
fill 533 169 439 533 169 440 minecraft:red_concrete
fill 533 169 452 543 169 452 minecraft:black_concrete
fill 534 169 427 535 172 427 minecraft:green_terracotta
fill 534 169 434 538 170 434 minecraft:green_terracotta
fill 534 169 440 538 170 440 minecraft:lime_terracotta
fill 534 169 447 535 172 447 minecraft:lime_terracotta
fill 536 169 417 544 169 417 minecraft:black_concrete
setblock 536 169 419 minecraft:light[level=12]
setblock 536 169 435 minecraft:light[level=12]
fill 536 169 457 540 169 457 minecraft:black_concrete
fill 539 169 418 541 169 418 minecraft:black_concrete
fill 542 169 434 546 170 434 minecraft:green_terracotta
fill 542 169 440 546 170 440 minecraft:lime_terracotta
setblock 544 169 419 minecraft:light[level=12]
setblock 544 169 435 minecraft:light[level=12]
fill 545 169 427 546 172 427 minecraft:green_terracotta
setblock 545 169 435 minecraft:red_concrete
setblock 545 169 439 minecraft:red_concrete
fill 545 169 447 546 172 447 minecraft:lime_terracotta
fill 546 169 435 553 169 439 minecraft:black_concrete
fill 547 169 427 550 169 427 minecraft:black_concrete
fill 547 169 434 553 169 434 minecraft:black_concrete
fill 547 169 440 553 169 440 minecraft:black_concrete
fill 547 169 447 550 169 447 minecraft:black_concrete
fill 548 169 428 548 173 428 minecraft:green_terracotta
fill 548 169 433 548 173 433 minecraft:green_terracotta
fill 548 169 441 548 173 441 minecraft:lime_terracotta
fill 548 169 446 548 173 446 minecraft:lime_terracotta
fill 549 169 428 551 169 428 minecraft:black_concrete
fill 549 169 433 553 169 433 minecraft:black_concrete
fill 549 169 441 553 169 441 minecraft:black_concrete
fill 549 169 446 551 169 446 minecraft:black_concrete
fill 550 169 429 551 169 429 minecraft:black_concrete
fill 550 169 430 550 173 431 minecraft:green_terracotta
fill 550 169 432 553 169 432 minecraft:black_concrete
fill 550 169 442 553 169 442 minecraft:black_concrete
fill 550 169 443 550 173 444 minecraft:lime_terracotta
fill 550 169 445 551 169 445 minecraft:black_concrete
fill 551 169 430 552 169 431 minecraft:black_concrete
fill 551 169 443 552 169 444 minecraft:black_concrete
fill 552 169 417 558 169 417 minecraft:black_concrete
setblock 552 169 419 minecraft:light[level=12]
setblock 552 169 427 minecraft:light[level=12]
setblock 552 169 451 minecraft:light[level=12]
fill 553 169 418 558 169 418 minecraft:black_concrete
fill 555 169 419 558 170 419 minecraft:black_concrete
fill 555 169 439 555 173 439 minecraft:black_concrete
fill 556 169 420 558 179 427 minecraft:black_concrete
fill 557 169 428 558 182 430 minecraft:black_concrete
fill 557 169 440 558 169 446 minecraft:black_concrete
fill 557 169 457 558 198 457 minecraft:black_concrete
fill 558 169 431 558 170 439 minecraft:black_concrete
fill 558 169 447 558 182 451 minecraft:black_concrete
fill 558 169 455 558 198 456 minecraft:black_concrete
fill 518 170 438 518 170 457 minecraft:black_concrete
fill 519 170 441 519 170 457 minecraft:black_concrete
fill 520 170 417 520 170 424 minecraft:black_concrete
fill 520 170 444 520 170 448 minecraft:black_concrete
fill 520 170 456 521 170 457 minecraft:black_concrete
fill 521 170 417 521 170 419 minecraft:black_concrete
fill 522 170 417 523 170 418 minecraft:black_concrete
fill 522 170 457 524 170 457 minecraft:black_concrete
setblock 524 170 417 minecraft:black_concrete
fill 524 170 432 529 170 442 minecraft:black_concrete
fill 525 170 430 529 170 431 minecraft:black_concrete
fill 525 170 443 529 170 444 minecraft:black_concrete
fill 526 170 429 529 170 429 minecraft:black_concrete
fill 526 170 445 529 170 445 minecraft:black_concrete
fill 527 170 427 530 170 428 minecraft:black_concrete
fill 527 170 446 530 170 447 minecraft:black_concrete
fill 528 170 426 548 170 426 minecraft:black_concrete
fill 528 170 448 548 170 448 minecraft:black_concrete
fill 530 170 425 546 170 425 minecraft:black_concrete
fill 530 170 429 530 172 429 minecraft:green_terracotta
fill 530 170 432 530 172 432 minecraft:green_terracotta
fill 530 170 433 530 170 441 minecraft:black_concrete
fill 530 170 442 530 172 442 minecraft:lime_terracotta
fill 530 170 445 530 172 445 minecraft:lime_terracotta
fill 530 170 449 546 170 449 minecraft:black_concrete
fill 531 170 424 545 170 424 minecraft:black_concrete
fill 531 170 427 533 172 427 minecraft:black_concrete
fill 531 170 428 531 171 428 minecraft:green_terracotta
fill 531 170 433 531 171 433 minecraft:green_terracotta
setblock 531 170 434 minecraft:black_concrete
fill 531 170 435 531 170 439 minecraft:red_concrete
setblock 531 170 440 minecraft:black_concrete
fill 531 170 441 531 171 441 minecraft:lime_terracotta
fill 531 170 446 531 171 446 minecraft:lime_terracotta
fill 531 170 447 533 172 447 minecraft:black_concrete
fill 531 170 450 545 170 450 minecraft:black_concrete
fill 532 170 434 532 170 435 minecraft:red_concrete
fill 532 170 439 532 170 440 minecraft:red_concrete
fill 533 170 423 543 170 423 minecraft:black_concrete
fill 533 170 451 543 170 451 minecraft:black_concrete
fill 534 170 437 535 170 437 minecraft:white_concrete
fill 537 170 417 542 170 417 minecraft:black_concrete
fill 546 170 435 546 170 439 minecraft:red_concrete
fill 547 170 427 549 170 427 minecraft:black_concrete
fill 547 170 434 552 170 440 minecraft:black_concrete
fill 547 170 447 549 170 447 minecraft:black_concrete
fill 549 170 428 549 171 428 minecraft:green_terracotta
fill 549 170 433 549 171 433 minecraft:green_terracotta
fill 549 170 441 549 171 441 minecraft:lime_terracotta
fill 549 170 446 549 171 446 minecraft:lime_terracotta
fill 550 170 429 550 172 429 minecraft:green_terracotta
fill 550 170 432 550 172 432 minecraft:green_terracotta
fill 550 170 433 552 170 433 minecraft:black_concrete
fill 550 170 441 552 170 441 minecraft:black_concrete
fill 550 170 442 550 172 442 minecraft:lime_terracotta
fill 550 170 445 550 172 445 minecraft:lime_terracotta
fill 551 170 430 551 170 432 minecraft:black_concrete
fill 551 170 442 551 170 444 minecraft:black_concrete
setblock 552 170 432 minecraft:black_concrete
setblock 552 170 442 minecraft:black_concrete
fill 553 170 417 558 197 417 minecraft:black_concrete
fill 554 170 418 558 182 418 minecraft:black_concrete
fill 557 170 442 558 170 446 minecraft:black_concrete
fill 558 170 440 558 172 441 minecraft:black_concrete
fill 558 170 452 558 188 452 minecraft:black_concrete
fill 518 171 439 518 171 457 minecraft:black_concrete
fill 519 171 442 519 172 457 minecraft:black_concrete
fill 520 171 417 521 171 418 minecraft:black_concrete
fill 520 171 421 520 171 422 minecraft:black_concrete
fill 520 171 445 520 171 448 minecraft:black_concrete
fill 520 171 456 520 171 457 minecraft:black_concrete
fill 521 171 457 523 171 457 minecraft:black_concrete
fill 522 171 417 523 171 417 minecraft:black_concrete
fill 525 171 433 529 171 441 minecraft:black_concrete
fill 526 171 431 529 171 432 minecraft:black_concrete
fill 526 171 442 529 171 443 minecraft:black_concrete
fill 527 171 429 529 171 430 minecraft:black_concrete
fill 527 171 444 529 171 445 minecraft:black_concrete
fill 528 171 428 530 171 428 minecraft:black_concrete
fill 528 171 446 530 171 446 minecraft:black_concrete
fill 529 171 427 530 171 427 minecraft:black_concrete
fill 529 171 447 530 171 447 minecraft:black_concrete
fill 530 171 426 546 171 426 minecraft:black_concrete
fill 530 171 433 530 171 434 minecraft:black_concrete
fill 530 171 435 530 171 439 minecraft:red_concrete
fill 530 171 440 530 171 441 minecraft:black_concrete
fill 530 171 448 546 171 448 minecraft:black_concrete
setblock 531 171 434 minecraft:red_concrete
setblock 531 171 440 minecraft:red_concrete
fill 532 171 425 544 171 425 minecraft:black_concrete
fill 532 171 437 534 171 437 minecraft:white_concrete
fill 532 171 449 544 171 449 minecraft:black_concrete
fill 534 171 424 542 171 424 minecraft:black_concrete
fill 534 171 434 534 173 434 minecraft:white_concrete
fill 534 171 440 534 173 440 minecraft:white_concrete
fill 534 171 450 542 171 450 minecraft:black_concrete
fill 535 171 434 537 172 434 minecraft:green_terracotta
fill 535 171 440 537 172 440 minecraft:lime_terracotta
fill 537 171 433 537 175 433 minecraft:green_terracotta
fill 537 171 441 537 175 441 minecraft:lime_terracotta
fill 538 171 433 538 173 434 minecraft:white_concrete
fill 538 171 440 538 173 441 minecraft:white_concrete
fill 539 171 433 543 171 433 minecraft:green_terracotta
fill 539 171 441 543 171 441 minecraft:lime_terracotta
fill 543 171 434 543 172 434 minecraft:green_terracotta
fill 543 171 440 543 172 440 minecraft:lime_terracotta
fill 544 171 433 544 173 434 minecraft:white_concrete
setblock 544 171 437 minecraft:white_concrete
fill 544 171 440 544 173 441 minecraft:white_concrete
fill 545 171 433 546 171 434 minecraft:green_terracotta
fill 545 171 440 546 171 441 minecraft:lime_terracotta
setblock 546 171 435 minecraft:red_concrete
setblock 546 171 439 minecraft:red_concrete
setblock 547 171 427 minecraft:black_concrete
fill 547 171 434 547 173 434 minecraft:white_concrete
fill 547 171 435 551 171 435 minecraft:black_concrete
fill 547 171 436 547 172 438 minecraft:red_concrete
fill 547 171 439 551 171 439 minecraft:black_concrete
fill 547 171 440 547 173 440 minecraft:white_concrete
setblock 547 171 447 minecraft:black_concrete
fill 548 171 434 551 171 434 minecraft:black_concrete
fill 548 171 436 551 171 438 minecraft:black_concrete
fill 548 171 440 551 171 440 minecraft:black_concrete
fill 550 171 433 551 171 433 minecraft:black_concrete
fill 550 171 441 551 171 441 minecraft:black_concrete
fill 554 171 439 554 173 439 minecraft:black_concrete
setblock 555 171 419 minecraft:white_wool
fill 555 171 438 555 173 438 minecraft:black_concrete
fill 555 171 440 555 173 440 minecraft:black_concrete
fill 556 171 419 558 173 419 minecraft:black_concrete
fill 556 171 439 556 173 439 minecraft:black_concrete
fill 557 171 443 558 171 446 minecraft:black_concrete
fill 558 171 431 558 171 433 minecraft:black_concrete
setblock 558 171 439 minecraft:black_concrete
fill 558 171 442 558 175 442 minecraft:black_concrete
fill 558 171 453 558 217 454 minecraft:black_concrete
fill 518 172 440 518 172 457 minecraft:black_concrete
fill 520 172 417 520 172 418 minecraft:black_concrete
fill 520 172 446 520 173 449 minecraft:black_concrete
fill 520 172 457 522 173 457 minecraft:black_concrete
fill 521 172 417 522 172 417 minecraft:black_concrete
fill 526 172 435 528 172 439 minecraft:black_concrete
fill 527 172 432 529 172 434 minecraft:black_concrete
fill 527 172 440 529 172 442 minecraft:black_concrete
fill 528 172 430 529 172 431 minecraft:black_concrete
fill 528 172 443 529 172 444 minecraft:black_concrete
setblock 529 172 429 minecraft:black_concrete
fill 529 172 435 529 172 439 minecraft:red_concrete
setblock 529 172 445 minecraft:black_concrete
fill 530 172 428 531 172 428 minecraft:black_concrete
fill 530 172 433 530 172 434 minecraft:red_concrete
fill 530 172 436 532 172 438 minecraft:white_concrete
fill 530 172 440 530 172 441 minecraft:red_concrete
fill 530 172 446 531 172 446 minecraft:black_concrete
fill 533 172 426 543 172 426 minecraft:black_concrete
fill 533 172 434 533 173 434 minecraft:white_concrete
setblock 533 172 437 minecraft:white_concrete
fill 533 172 440 533 173 440 minecraft:white_concrete
fill 533 172 448 543 172 448 minecraft:black_concrete
fill 534 172 433 534 173 433 minecraft:white_concrete
fill 534 172 441 534 173 441 minecraft:white_concrete
fill 535 172 433 536 175 433 minecraft:green_terracotta
fill 535 172 441 536 175 441 minecraft:lime_terracotta
fill 536 172 425 540 172 425 minecraft:black_concrete
fill 536 172 449 540 172 449 minecraft:black_concrete
fill 539 172 433 539 173 434 minecraft:white_concrete
fill 539 172 440 539 173 441 minecraft:white_concrete
fill 541 172 433 543 172 433 minecraft:green_terracotta
fill 541 172 441 543 172 441 minecraft:lime_terracotta
fill 544 172 436 546 172 436 minecraft:white_concrete
fill 544 172 438 546 172 438 minecraft:white_concrete
fill 545 172 433 546 172 433 minecraft:green_terracotta
fill 545 172 434 545 173 434 minecraft:white_concrete
fill 545 172 437 546 173 437 minecraft:white_concrete
fill 545 172 440 545 173 440 minecraft:white_concrete
fill 545 172 441 546 172 441 minecraft:lime_terracotta
setblock 546 172 434 minecraft:green_terracotta
setblock 546 172 440 minecraft:lime_terracotta
setblock 547 172 435 minecraft:red_concrete
setblock 547 172 439 minecraft:red_concrete
fill 548 172 434 549 172 440 minecraft:black_concrete
setblock 549 172 433 minecraft:black_concrete
setblock 549 172 441 minecraft:black_concrete
fill 550 172 435 550 172 439 minecraft:black_concrete
fill 554 172 438 554 173 438 minecraft:black_concrete
fill 554 172 440 554 173 440 minecraft:black_concrete
fill 556 172 428 556 181 428 minecraft:black_concrete
fill 556 172 438 556 173 438 minecraft:black_concrete
fill 556 172 440 556 173 440 minecraft:black_concrete
fill 557 172 445 557 178 447 minecraft:black_concrete
fill 558 172 431 558 184 432 minecraft:black_concrete
fill 558 172 443 558 178 446 minecraft:black_concrete
fill 518 173 441 518 180 457 minecraft:black_concrete
fill 519 173 417 521 173 417 minecraft:black_concrete
fill 519 173 419 519 173 427 minecraft:black_concrete
fill 519 173 443 519 174 455 minecraft:black_concrete
fill 519 173 457 519 196 457 minecraft:black_concrete
fill 528 173 437 531 173 437 minecraft:white_concrete
fill 529 173 436 531 173 436 minecraft:white_concrete
fill 529 173 438 531 173 438 minecraft:white_concrete
setblock 535 173 427 minecraft:green_terracotta
fill 535 173 434 536 173 434 minecraft:green_terracotta
fill 535 173 440 536 173 440 minecraft:lime_terracotta
setblock 535 173 447 minecraft:lime_terracotta
setblock 538 173 435 minecraft:white_concrete
setblock 538 173 439 minecraft:white_concrete
fill 542 173 433 543 173 433 minecraft:green_terracotta
fill 542 173 441 543 173 441 minecraft:lime_terracotta
setblock 544 173 435 minecraft:white_concrete
setblock 544 173 439 minecraft:white_concrete
setblock 545 173 427 minecraft:green_terracotta
setblock 545 173 433 minecraft:white_concrete
fill 545 173 436 547 173 436 minecraft:white_concrete
fill 545 173 438 547 173 438 minecraft:white_concrete
setblock 545 173 441 minecraft:white_concrete
setblock 545 173 447 minecraft:lime_terracotta
fill 546 173 433 546 174 433 minecraft:green_terracotta
fill 546 173 441 546 174 441 minecraft:lime_terracotta
setblock 547 173 433 minecraft:white_concrete
fill 547 173 437 548 173 437 minecraft:white_concrete
setblock 547 173 441 minecraft:white_concrete
fill 557 173 448 557 182 449 minecraft:black_concrete
setblock 558 173 441 minecraft:black_concrete
fill 518 174 431 518 183 431 minecraft:black_concrete
fill 519 174 417 520 174 417 minecraft:black_concrete
fill 519 174 421 519 174 427 minecraft:black_concrete
fill 519 174 456 519 185 456 minecraft:black_concrete
fill 520 174 447 520 179 451 minecraft:black_concrete
fill 520 174 457 521 197 457 minecraft:black_concrete
fill 531 174 430 531 174 431 minecraft:green_terracotta
fill 531 174 443 531 174 444 minecraft:lime_terracotta
setblock 534 174 433 minecraft:green_terracotta
setblock 534 174 441 minecraft:lime_terracotta
setblock 536 174 434 minecraft:green_terracotta
setblock 536 174 440 minecraft:lime_terracotta
fill 543 174 433 545 175 433 minecraft:green_terracotta
fill 543 174 441 545 175 441 minecraft:lime_terracotta
setblock 544 174 434 minecraft:green_terracotta
setblock 544 174 440 minecraft:lime_terracotta
setblock 547 174 433 minecraft:green_terracotta
setblock 547 174 441 minecraft:lime_terracotta
setblock 548 174 429 minecraft:green_terracotta
setblock 548 174 432 minecraft:green_terracotta
setblock 548 174 442 minecraft:lime_terracotta
setblock 548 174 445 minecraft:lime_terracotta
fill 552 174 417 552 198 417 minecraft:black_concrete
fill 555 174 424 555 178 425 minecraft:black_concrete
fill 555 174 428 555 175 428 minecraft:white_wool
fill 556 174 429 556 181 429 minecraft:black_concrete
fill 556 174 457 556 197 457 minecraft:black_concrete
fill 557 174 419 558 181 419 minecraft:black_concrete
fill 557 174 431 557 182 431 minecraft:black_concrete
fill 557 174 450 557 183 452 minecraft:black_concrete
fill 558 174 433 558 184 433 minecraft:black_concrete
fill 519 175 417 519 179 417 minecraft:black_concrete
fill 519 175 422 519 175 427 minecraft:black_concrete
fill 519 175 444 519 178 455 minecraft:black_concrete
fill 520 175 452 520 182 452 minecraft:black_concrete
fill 535 175 428 536 175 428 minecraft:green_terracotta
fill 535 175 446 536 175 446 minecraft:lime_terracotta
fill 544 175 428 545 175 428 minecraft:green_terracotta
fill 544 175 446 545 175 446 minecraft:lime_terracotta
fill 553 175 418 553 196 418 minecraft:black_concrete
fill 554 175 457 555 197 457 minecraft:black_concrete
fill 555 175 426 555 180 427 minecraft:black_concrete
fill 556 175 430 556 181 430 minecraft:black_concrete
fill 557 175 432 557 182 432 minecraft:black_concrete
fill 557 175 453 557 186 454 minecraft:black_concrete
fill 518 176 432 518 184 432 minecraft:black_concrete
fill 519 176 424 519 176 428 minecraft:black_concrete
fill 520 176 453 520 182 453 minecraft:black_concrete
fill 520 176 456 520 184 456 minecraft:black_concrete
fill 522 176 457 522 198 457 minecraft:black_concrete
fill 533 176 431 535 177 431 minecraft:pearlescent_froglight
fill 533 176 443 535 177 443 minecraft:pearlescent_froglight
fill 534 176 430 534 177 430 minecraft:pearlescent_froglight
fill 534 176 432 534 177 432 minecraft:pearlescent_froglight
fill 534 176 442 534 177 442 minecraft:pearlescent_froglight
fill 534 176 444 534 177 444 minecraft:pearlescent_froglight
fill 534 176 457 535 186 457 minecraft:black_concrete
fill 535 176 429 535 176 430 minecraft:green_terracotta
setblock 535 176 432 minecraft:green_terracotta
setblock 535 176 442 minecraft:lime_terracotta
fill 535 176 444 535 176 445 minecraft:lime_terracotta
fill 538 176 428 542 176 428 minecraft:green_terracotta
fill 538 176 432 539 176 432 minecraft:green_terracotta
fill 538 176 442 539 176 442 minecraft:lime_terracotta
fill 538 176 446 542 176 446 minecraft:lime_terracotta
fill 541 176 432 545 176 432 minecraft:green_terracotta
fill 541 176 442 545 176 442 minecraft:lime_terracotta
fill 543 176 429 545 176 429 minecraft:green_terracotta
fill 543 176 445 545 176 445 minecraft:lime_terracotta
fill 551 176 417 551 199 417 minecraft:black_concrete
fill 553 176 457 553 197 457 minecraft:black_concrete
fill 555 176 423 555 177 423 minecraft:black_concrete
fill 555 176 428 555 180 428 minecraft:black_concrete
fill 555 176 456 557 194 456 minecraft:black_concrete
fill 556 176 419 556 179 419 minecraft:black_concrete
fill 556 176 450 556 182 450 minecraft:black_concrete
fill 557 176 455 557 189 455 minecraft:black_concrete
fill 558 176 434 558 183 434 minecraft:black_concrete
fill 518 177 433 518 184 434 minecraft:black_concrete
fill 519 177 425 519 177 428 minecraft:black_concrete
setblock 520 177 419 minecraft:light[level=12]
setblock 520 177 427 minecraft:light[level=12]
setblock 520 177 435 minecraft:light[level=12]
setblock 520 177 443 minecraft:light[level=12]
fill 520 177 454 520 182 454 minecraft:black_concrete
setblock 528 177 419 minecraft:light[level=12]
setblock 528 177 427 minecraft:light[level=12]
setblock 528 177 435 minecraft:light[level=12]
setblock 528 177 443 minecraft:light[level=12]
setblock 528 177 451 minecraft:light[level=12]
fill 531 177 457 533 192 457 minecraft:black_concrete
setblock 536 177 419 minecraft:light[level=12]
setblock 536 177 427 minecraft:light[level=12]
setblock 536 177 443 minecraft:light[level=12]
setblock 536 177 451 minecraft:light[level=12]
fill 536 177 457 537 183 457 minecraft:black_concrete
fill 537 177 430 543 177 431 minecraft:green_terracotta
fill 537 177 443 543 177 444 minecraft:lime_terracotta
setblock 544 177 419 minecraft:light[level=12]
setblock 544 177 427 minecraft:light[level=12]
setblock 544 177 443 minecraft:light[level=12]
setblock 544 177 451 minecraft:light[level=12]
fill 550 177 417 550 199 417 minecraft:black_concrete
fill 551 177 457 552 198 457 minecraft:black_concrete
fill 552 177 418 552 197 418 minecraft:black_concrete
setblock 552 177 419 minecraft:light[level=12]
setblock 552 177 427 minecraft:light[level=12]
setblock 552 177 435 minecraft:light[level=12]
setblock 552 177 443 minecraft:light[level=12]
setblock 552 177 451 minecraft:light[level=12]
fill 553 177 456 554 194 456 minecraft:black_concrete
fill 555 177 419 555 180 419 minecraft:black_concrete
fill 555 177 429 555 180 429 minecraft:black_concrete
fill 556 177 431 556 181 431 minecraft:black_concrete
fill 556 177 448 556 180 449 minecraft:black_concrete
fill 556 177 451 556 183 454 minecraft:black_concrete
fill 557 177 433 557 182 433 minecraft:black_concrete
fill 558 177 435 558 183 435 minecraft:black_concrete
fill 518 178 435 518 185 435 minecraft:black_concrete
fill 519 178 427 519 178 429 minecraft:black_concrete
fill 521 178 456 521 183 456 minecraft:black_concrete
fill 523 178 457 523 198 457 minecraft:black_concrete
fill 528 178 457 530 195 457 minecraft:black_concrete
fill 531 178 456 535 183 456 minecraft:black_concrete
fill 549 178 417 549 200 417 minecraft:black_concrete
fill 550 178 457 550 199 457 minecraft:black_concrete
fill 551 178 418 551 197 418 minecraft:black_concrete
fill 552 178 456 552 195 456 minecraft:black_concrete
fill 553 178 419 554 181 419 minecraft:black_concrete
fill 554 178 455 556 185 455 minecraft:black_concrete
fill 555 178 430 555 180 430 minecraft:black_concrete
fill 556 178 432 556 181 432 minecraft:black_concrete
fill 518 179 436 518 185 436 minecraft:black_concrete
setblock 519 179 429 minecraft:black_concrete
fill 519 179 445 519 180 455 minecraft:black_concrete
fill 520 179 455 520 181 455 minecraft:black_concrete
fill 522 179 456 522 182 456 minecraft:black_concrete
fill 524 179 457 527 197 457 minecraft:black_concrete
fill 529 179 456 530 190 456 minecraft:black_concrete
fill 532 179 455 533 182 455 minecraft:black_concrete
fill 533 179 417 536 183 417 minecraft:black_concrete
fill 536 179 456 536 182 456 minecraft:black_concrete
fill 538 179 457 538 182 457 minecraft:black_concrete
fill 548 179 417 548 201 417 minecraft:black_concrete
fill 549 179 457 549 199 457 minecraft:black_concrete
fill 550 179 418 550 198 418 minecraft:black_concrete
fill 550 179 456 551 196 456 minecraft:black_concrete
fill 552 179 455 553 188 455 minecraft:black_concrete
setblock 555 179 425 minecraft:black_concrete
fill 557 179 434 557 181 434 minecraft:black_concrete
fill 557 179 446 557 180 447 minecraft:black_concrete
fill 558 179 436 558 181 436 minecraft:black_concrete
fill 558 179 444 558 180 446 minecraft:black_concrete
fill 518 180 417 518 180 418 minecraft:black_concrete
fill 518 180 423 518 180 430 minecraft:black_concrete
fill 518 180 437 518 183 437 minecraft:black_concrete
fill 520 180 448 520 180 451 minecraft:black_concrete
fill 527 180 456 528 193 456 minecraft:black_concrete
fill 530 180 455 531 184 455 minecraft:black_concrete
fill 532 180 417 532 198 417 minecraft:black_concrete
fill 534 180 455 534 181 455 minecraft:black_concrete
fill 547 180 417 547 202 417 minecraft:black_concrete
fill 547 180 457 548 200 457 minecraft:black_concrete
fill 549 180 418 549 199 418 minecraft:black_concrete
fill 549 180 456 549 197 456 minecraft:black_concrete
fill 551 180 455 551 192 455 minecraft:black_concrete
fill 552 180 419 552 183 419 minecraft:black_concrete
fill 554 180 454 555 182 454 minecraft:black_concrete
fill 555 180 452 555 181 453 minecraft:black_concrete
fill 556 180 422 558 180 427 minecraft:black_concrete
fill 557 180 420 558 181 421 minecraft:black_concrete
setblock 518 181 417 minecraft:black_concrete
fill 518 181 426 518 181 430 minecraft:black_concrete
fill 518 181 442 518 181 457 minecraft:black_concrete
fill 519 181 446 519 181 455 minecraft:black_concrete
fill 520 181 449 520 181 451 minecraft:black_concrete
fill 523 181 456 526 182 456 minecraft:black_concrete
fill 529 181 455 529 184 455 minecraft:black_concrete
fill 531 181 417 531 198 417 minecraft:black_concrete
fill 546 181 417 546 203 417 minecraft:black_concrete
fill 546 181 457 546 223 457 minecraft:black_concrete
fill 548 181 456 548 198 456 minecraft:black_concrete
fill 550 181 455 550 193 455 minecraft:black_concrete
fill 553 181 454 553 183 454 minecraft:black_concrete
fill 555 181 428 555 188 428 minecraft:white_wool
fill 556 181 425 558 181 427 minecraft:black_concrete
setblock 556 181 449 minecraft:black_concrete
fill 557 181 422 558 181 424 minecraft:black_concrete
setblock 557 181 447 minecraft:black_concrete
fill 558 181 445 558 181 446 minecraft:black_concrete
fill 518 182 428 518 182 430 minecraft:black_concrete
fill 518 182 444 518 182 457 minecraft:black_concrete
fill 519 182 447 519 182 455 minecraft:black_concrete
setblock 520 182 451 minecraft:black_concrete
setblock 528 182 455 minecraft:black_concrete
fill 530 182 417 530 199 417 minecraft:black_concrete
fill 545 182 417 545 205 417 minecraft:black_concrete
fill 548 182 418 548 199 418 minecraft:black_concrete
setblock 551 182 419 minecraft:black_concrete
setblock 552 182 454 minecraft:black_concrete
setblock 553 182 419 minecraft:black_concrete
setblock 555 182 453 minecraft:black_concrete
fill 557 182 426 558 182 427 minecraft:black_concrete
fill 558 182 419 558 182 425 minecraft:black_concrete
setblock 518 183 430 minecraft:black_concrete
fill 518 183 445 518 183 457 minecraft:black_concrete
fill 519 183 449 519 183 455 minecraft:black_concrete
fill 524 183 456 526 183 456 minecraft:black_concrete
setblock 532 183 455 minecraft:black_concrete
fill 545 183 457 545 223 457 minecraft:black_concrete
fill 547 183 456 547 198 456 minecraft:black_concrete
fill 549 183 455 549 194 455 minecraft:black_concrete
fill 554 183 418 556 184 418 minecraft:black_concrete
setblock 554 183 454 minecraft:black_concrete
fill 557 183 449 558 183 449 minecraft:black_concrete
fill 558 183 418 558 183 419 minecraft:black_concrete
fill 558 183 427 558 183 430 minecraft:black_concrete
setblock 558 183 448 minecraft:black_concrete
fill 558 183 450 558 185 451 minecraft:black_concrete
fill 518 184 447 518 184 457 minecraft:black_concrete
fill 519 184 450 519 184 455 minecraft:black_concrete
fill 525 184 456 526 194 456 minecraft:black_concrete
fill 529 184 417 529 199 417 minecraft:black_concrete
fill 531 184 456 534 184 456 minecraft:black_concrete
fill 533 184 417 535 185 417 minecraft:black_concrete
fill 536 184 457 536 185 457 minecraft:black_concrete
fill 544 184 417 544 209 417 minecraft:black_concrete
fill 547 184 418 547 200 418 minecraft:black_concrete
fill 556 184 453 556 184 454 minecraft:black_concrete
fill 557 184 451 557 184 452 minecraft:black_concrete
setblock 558 184 418 minecraft:black_concrete
setblock 558 184 449 minecraft:black_concrete
setblock 518 185 434 minecraft:black_concrete
fill 518 185 448 518 185 457 minecraft:black_concrete
fill 519 185 452 519 185 455 minecraft:black_concrete
setblock 520 185 419 minecraft:light[level=12]
setblock 520 185 427 minecraft:light[level=12]
setblock 520 185 435 minecraft:light[level=12]
setblock 520 185 443 minecraft:light[level=12]
setblock 520 185 451 minecraft:light[level=12]
fill 528 185 417 528 199 417 minecraft:black_concrete
setblock 528 185 419 minecraft:light[level=12]
setblock 528 185 427 minecraft:light[level=12]
setblock 528 185 435 minecraft:light[level=12]
setblock 528 185 443 minecraft:light[level=12]
setblock 528 185 451 minecraft:light[level=12]
fill 531 185 456 533 185 456 minecraft:black_concrete
setblock 536 185 419 minecraft:light[level=12]
setblock 536 185 427 minecraft:light[level=12]
setblock 536 185 435 minecraft:light[level=12]
setblock 536 185 443 minecraft:light[level=12]
setblock 536 185 451 minecraft:light[level=12]
fill 543 185 417 543 211 417 minecraft:black_concrete
setblock 544 185 419 minecraft:light[level=12]
setblock 544 185 427 minecraft:light[level=12]
setblock 544 185 435 minecraft:light[level=12]
setblock 544 185 443 minecraft:light[level=12]
setblock 544 185 451 minecraft:light[level=12]
fill 544 185 457 544 223 457 minecraft:black_concrete
fill 546 185 418 546 201 418 minecraft:black_concrete
fill 546 185 456 546 199 456 minecraft:black_concrete
setblock 552 185 419 minecraft:light[level=12]
setblock 552 185 427 minecraft:light[level=12]
setblock 552 185 435 minecraft:light[level=12]
setblock 552 185 443 minecraft:light[level=12]
setblock 552 185 451 minecraft:light[level=12]
fill 554 185 418 555 186 418 minecraft:black_concrete
setblock 556 185 454 minecraft:black_concrete
setblock 557 185 452 minecraft:black_concrete
fill 518 186 450 518 186 457 minecraft:black_concrete
fill 524 186 440 524 201 440 minecraft:white_wool
fill 531 186 456 532 186 456 minecraft:black_concrete
fill 533 186 417 534 198 417 minecraft:black_concrete
fill 554 186 455 555 186 455 minecraft:black_concrete
setblock 558 186 451 minecraft:black_concrete
fill 518 187 436 518 223 437 minecraft:black_concrete
fill 518 187 451 518 187 457 minecraft:black_concrete
fill 527 187 417 527 200 417 minecraft:black_concrete
setblock 531 187 456 minecraft:black_concrete
fill 534 187 457 534 189 457 minecraft:black_concrete
fill 535 187 417 535 200 417 minecraft:black_concrete
fill 541 187 417 542 212 417 minecraft:black_concrete
fill 543 187 457 543 223 457 minecraft:black_concrete
fill 545 187 418 545 202 418 minecraft:black_concrete
fill 549 187 419 550 197 419 minecraft:black_concrete
fill 554 187 418 554 196 418 minecraft:black_concrete
setblock 554 187 455 minecraft:black_concrete
setblock 557 187 454 minecraft:black_concrete
fill 518 188 438 518 223 439 minecraft:black_concrete
fill 518 188 452 518 188 457 minecraft:black_concrete
fill 525 188 417 526 200 417 minecraft:black_concrete
fill 536 188 417 536 223 417 minecraft:black_concrete
fill 540 188 417 540 223 417 minecraft:black_concrete
fill 542 188 457 542 223 457 minecraft:black_concrete
fill 544 188 418 544 203 418 minecraft:black_concrete
fill 545 188 456 545 199 456 minecraft:black_concrete
fill 547 188 419 548 198 419 minecraft:black_concrete
fill 548 188 455 548 195 455 minecraft:black_concrete
fill 551 188 419 551 196 419 minecraft:black_concrete
fill 518 189 435 518 223 435 minecraft:black_concrete
fill 518 189 440 518 215 441 minecraft:black_concrete
fill 518 189 453 518 189 457 minecraft:black_concrete
fill 524 189 417 524 201 417 minecraft:black_concrete
fill 528 189 418 531 197 418 minecraft:black_concrete
fill 537 189 417 539 223 417 minecraft:black_concrete
fill 542 189 418 543 205 418 minecraft:black_concrete
fill 544 189 456 544 199 456 minecraft:black_concrete
fill 545 189 419 546 199 419 minecraft:black_concrete
fill 552 189 455 552 191 455 minecraft:black_concrete
fill 555 189 418 555 195 418 minecraft:black_concrete
fill 518 190 442 518 213 443 minecraft:black_concrete
fill 518 190 454 518 193 457 minecraft:black_concrete
fill 519 190 438 519 212 439 minecraft:black_concrete
fill 522 190 417 523 201 417 minecraft:black_concrete
fill 524 190 456 524 195 456 minecraft:black_concrete
fill 526 190 418 527 199 418 minecraft:black_concrete
fill 532 190 418 532 197 418 minecraft:black_concrete
fill 540 190 418 541 210 418 minecraft:black_concrete
fill 541 190 457 541 223 457 minecraft:black_concrete
fill 544 190 419 544 201 419 minecraft:black_concrete
fill 547 190 455 547 195 455 minecraft:black_concrete
fill 552 190 419 552 195 419 minecraft:black_concrete
fill 558 190 418 558 199 418 minecraft:black_concrete
fill 518 191 434 518 223 434 minecraft:black_concrete
fill 518 191 444 518 213 445 minecraft:black_concrete
fill 519 191 436 519 199 437 minecraft:black_concrete
fill 519 191 440 519 210 442 minecraft:black_concrete
fill 521 191 417 521 200 417 minecraft:black_concrete
fill 523 191 456 523 194 456 minecraft:black_concrete
fill 524 191 418 525 199 418 minecraft:black_concrete
fill 529 191 456 529 192 456 minecraft:black_concrete
fill 533 191 418 534 197 418 minecraft:black_concrete
fill 538 191 418 539 212 418 minecraft:black_concrete
fill 540 191 457 540 223 457 minecraft:black_concrete
fill 542 191 419 543 201 419 minecraft:black_concrete
fill 543 191 456 543 199 456 minecraft:black_concrete
fill 546 191 420 548 196 420 minecraft:black_concrete
fill 546 191 455 546 195 455 minecraft:black_concrete
fill 558 191 419 558 199 419 minecraft:black_concrete
fill 558 191 438 558 223 441 minecraft:black_concrete
fill 518 192 417 520 197 417 minecraft:black_concrete
fill 518 192 446 518 213 447 minecraft:black_concrete
fill 519 192 443 519 210 444 minecraft:black_concrete
fill 520 192 437 520 198 441 minecraft:black_concrete
fill 523 192 418 523 199 418 minecraft:black_concrete
fill 526 192 419 530 196 419 minecraft:black_concrete
fill 535 192 418 537 198 418 minecraft:black_concrete
fill 539 192 457 539 199 457 minecraft:black_concrete
fill 540 192 419 541 203 419 minecraft:black_concrete
fill 542 192 456 542 198 456 minecraft:black_concrete
fill 544 192 420 545 199 420 minecraft:black_concrete
fill 549 192 420 549 195 420 minecraft:black_concrete
fill 556 192 418 556 195 418 minecraft:black_concrete
fill 558 192 420 558 200 420 minecraft:black_concrete
fill 558 192 437 558 198 437 minecraft:black_concrete
fill 558 192 442 558 216 444 minecraft:black_concrete
fill 558 192 452 558 217 452 minecraft:black_concrete
fill 518 193 418 518 198 419 minecraft:black_concrete
fill 518 193 448 518 213 449 minecraft:black_concrete
fill 519 193 435 519 197 435 minecraft:black_concrete
fill 519 193 445 519 210 445 minecraft:black_concrete
setblock 520 193 419 minecraft:light[level=12]
setblock 520 193 427 minecraft:light[level=12]
schedule function dropper:buildpart/107_2 1t
