setblock 348 273 623 minecraft:light[level=12]
setblock 348 273 631 minecraft:light[level=12]
setblock 348 273 639 minecraft:light[level=12]
fill 349 273 604 349 287 604 minecraft:purple_concrete
setblock 356 273 607 minecraft:light[level=12]
setblock 356 273 615 minecraft:light[level=12]
setblock 356 273 623 minecraft:light[level=12]
setblock 356 273 631 minecraft:light[level=12]
setblock 356 273 639 minecraft:light[level=12]
fill 359 273 646 359 287 646 minecraft:purple_concrete
fill 363 273 646 363 307 646 minecraft:purple_concrete
setblock 364 273 607 minecraft:light[level=12]
setblock 364 273 615 minecraft:light[level=12]
setblock 364 273 623 minecraft:light[level=12]
setblock 364 273 631 minecraft:light[level=12]
setblock 364 273 639 minecraft:light[level=12]
setblock 364 273 646 minecraft:crying_obsidian
fill 365 273 604 365 280 604 minecraft:purple_concrete
fill 371 273 610 371 307 611 minecraft:purple_concrete
setblock 371 273 612 minecraft:crying_obsidian
fill 371 273 614 371 287 614 minecraft:purple_concrete
fill 371 273 630 371 287 630 minecraft:purple_concrete
fill 371 273 643 371 282 643 minecraft:purple_concrete
setblock 329 274 627 minecraft:magenta_stained_glass
setblock 329 274 628 minecraft:white_concrete
fill 364 274 646 364 300 646 minecraft:purple_concrete
fill 371 274 612 371 281 612 minecraft:purple_concrete
fill 329 275 627 329 287 628 minecraft:purple_concrete
setblock 329 275 643 minecraft:white_concrete
setblock 359 275 604 minecraft:magenta_stained_glass
setblock 369 275 646 minecraft:white_concrete
fill 371 275 604 371 307 604 minecraft:purple_concrete
setblock 371 275 605 minecraft:white_concrete
setblock 371 275 644 minecraft:white_concrete
fill 371 275 645 371 307 645 minecraft:purple_concrete
fill 329 276 643 329 288 643 minecraft:purple_concrete
fill 359 276 604 359 285 604 minecraft:purple_concrete
fill 369 276 646 369 307 646 minecraft:purple_concrete
fill 371 276 605 371 307 605 minecraft:purple_concrete
fill 371 276 644 371 307 644 minecraft:purple_concrete
setblock 371 277 627 minecraft:white_concrete
setblock 371 277 641 minecraft:crying_obsidian
setblock 329 278 631 minecraft:magenta_stained_glass
fill 329 278 636 329 307 636 minecraft:purple_concrete
setblock 329 278 637 minecraft:white_concrete
setblock 348 278 646 minecraft:crying_obsidian
setblock 351 278 646 minecraft:white_concrete
setblock 353 278 604 minecraft:magenta_stained_glass
setblock 370 278 646 minecraft:crying_obsidian
fill 371 278 627 371 307 627 minecraft:purple_concrete
fill 371 278 641 371 307 641 minecraft:purple_concrete
fill 371 278 646 371 307 646 minecraft:purple_concrete
setblock 329 279 620 minecraft:white_concrete
fill 329 279 631 329 307 631 minecraft:purple_concrete
fill 329 279 637 329 280 637 minecraft:purple_concrete
fill 339 279 618 345 280 618 minecraft:magenta_concrete
fill 339 279 632 345 280 632 minecraft:magenta_concrete
fill 340 279 619 347 279 620 minecraft:magenta_concrete
fill 340 279 630 347 279 631 minecraft:magenta_concrete
fill 341 279 621 360 279 621 minecraft:magenta_concrete
fill 341 279 629 360 279 629 minecraft:magenta_concrete
fill 342 279 622 362 279 622 minecraft:magenta_concrete
fill 342 279 628 362 279 628 minecraft:magenta_concrete
fill 343 279 623 352 279 623 minecraft:magenta_concrete
fill 343 279 627 352 279 627 minecraft:magenta_concrete
fill 344 279 624 351 279 624 minecraft:magenta_concrete
fill 344 279 626 351 279 626 minecraft:magenta_concrete
fill 346 279 625 350 279 625 minecraft:magenta_concrete
fill 348 279 615 353 279 617 minecraft:magenta_concrete
fill 348 279 620 360 279 620 minecraft:magenta_concrete
fill 348 279 630 360 279 630 minecraft:magenta_concrete
fill 348 279 633 353 279 635 minecraft:magenta_concrete
fill 348 279 646 348 293 646 minecraft:purple_concrete
fill 349 279 611 351 280 614 minecraft:magenta_concrete
fill 349 279 618 361 279 619 minecraft:magenta_concrete
fill 349 279 631 361 279 632 minecraft:magenta_concrete
fill 349 279 636 351 280 639 minecraft:magenta_concrete
fill 350 279 610 350 280 610 minecraft:magenta_concrete
fill 350 279 640 350 280 640 minecraft:magenta_concrete
fill 351 279 646 351 307 646 minecraft:purple_concrete
fill 352 279 612 352 280 614 minecraft:magenta_concrete
fill 352 279 636 352 280 638 minecraft:magenta_concrete
fill 353 279 604 353 307 604 minecraft:purple_concrete
fill 353 279 614 353 280 614 minecraft:magenta_concrete
fill 353 279 636 353 280 636 minecraft:magenta_concrete
setblock 354 279 604 minecraft:white_concrete
fill 354 279 616 354 280 617 minecraft:magenta_concrete
fill 354 279 623 365 279 623 minecraft:magenta_concrete
fill 354 279 627 365 279 627 minecraft:magenta_concrete
fill 354 279 633 354 280 634 minecraft:magenta_concrete
fill 355 279 604 355 307 604 minecraft:purple_concrete
fill 355 279 624 367 279 624 minecraft:magenta_concrete
fill 355 279 626 367 279 626 minecraft:magenta_concrete
setblock 356 279 604 minecraft:magenta_stained_glass
fill 356 279 617 362 279 617 minecraft:magenta_concrete
fill 356 279 625 369 279 625 minecraft:magenta_concrete
fill 356 279 633 362 279 633 minecraft:magenta_concrete
fill 357 279 604 357 289 604 minecraft:purple_concrete
fill 357 279 616 362 280 616 minecraft:magenta_concrete
fill 357 279 634 362 280 634 minecraft:magenta_concrete
fill 358 279 615 362 280 615 minecraft:magenta_concrete
fill 358 279 635 362 280 635 minecraft:magenta_concrete
fill 359 279 614 362 280 614 minecraft:magenta_concrete
fill 359 279 636 362 280 636 minecraft:magenta_concrete
fill 362 279 613 362 280 613 minecraft:magenta_concrete
fill 362 279 637 362 280 637 minecraft:magenta_concrete
fill 370 279 646 370 307 646 minecraft:purple_concrete
setblock 371 279 609 minecraft:magenta_stained_glass
fill 329 280 620 329 303 620 minecraft:purple_concrete
setblock 330 280 604 minecraft:magenta_stained_glass
fill 330 280 605 338 280 645 minecraft:black_concrete
fill 331 280 604 331 307 604 minecraft:purple_concrete
fill 339 280 605 347 280 617 minecraft:black_concrete
fill 339 280 619 339 280 631 minecraft:black_concrete
fill 339 280 633 347 280 645 minecraft:black_concrete
fill 340 280 619 343 280 620 minecraft:magenta_concrete
fill 340 280 621 340 280 629 minecraft:black_concrete
fill 340 280 630 343 280 631 minecraft:magenta_concrete
fill 341 280 621 343 280 621 minecraft:magenta_concrete
fill 341 280 622 341 280 628 minecraft:black_concrete
fill 341 280 629 343 280 629 minecraft:magenta_concrete
fill 342 280 622 344 280 622 minecraft:magenta_concrete
fill 342 280 623 342 280 627 minecraft:black_concrete
fill 342 280 628 344 280 628 minecraft:magenta_concrete
fill 343 280 623 344 280 623 minecraft:magenta_concrete
fill 343 280 624 343 280 626 minecraft:black_concrete
fill 343 280 627 344 280 627 minecraft:magenta_concrete
fill 344 280 619 347 280 619 minecraft:magenta_concrete
fill 344 280 620 347 280 621 minecraft:purple_concrete
fill 344 280 624 346 280 624 minecraft:magenta_concrete
fill 344 280 625 345 280 625 minecraft:black_concrete
fill 344 280 626 346 280 626 minecraft:magenta_concrete
fill 344 280 629 347 280 630 minecraft:purple_concrete
fill 344 280 631 347 280 631 minecraft:magenta_concrete
fill 345 280 622 349 280 623 minecraft:purple_concrete
fill 345 280 627 349 280 628 minecraft:purple_concrete
fill 346 280 618 348 280 618 minecraft:black_concrete
fill 346 280 625 347 280 625 minecraft:magenta_concrete
fill 346 280 632 348 280 632 minecraft:black_concrete
fill 347 280 624 349 280 624 minecraft:purple_concrete
fill 347 280 626 349 280 626 minecraft:purple_concrete
fill 348 280 605 348 280 614 minecraft:black_concrete
fill 348 280 615 349 280 617 minecraft:magenta_concrete
setblock 348 280 619 minecraft:black_concrete
fill 348 280 620 349 280 620 minecraft:magenta_concrete
fill 348 280 621 352 280 621 minecraft:purple_concrete
setblock 348 280 625 minecraft:purple_concrete
fill 348 280 629 352 280 629 minecraft:purple_concrete
fill 348 280 630 349 280 630 minecraft:magenta_concrete
setblock 348 280 631 minecraft:black_concrete
fill 348 280 633 349 280 635 minecraft:magenta_concrete
fill 348 280 636 348 280 645 minecraft:black_concrete
fill 349 280 605 349 280 610 minecraft:black_concrete
fill 349 280 618 349 280 619 minecraft:magenta_concrete
fill 349 280 625 350 280 625 minecraft:crying_obsidian
fill 349 280 631 349 280 632 minecraft:magenta_concrete
fill 349 280 640 349 280 645 minecraft:black_concrete
fill 350 280 605 370 280 609 minecraft:black_concrete
setblock 350 280 615 minecraft:magenta_concrete
fill 350 280 616 352 280 620 minecraft:purple_concrete
setblock 350 280 622 minecraft:purple_concrete
fill 350 280 623 351 280 624 minecraft:crying_obsidian
fill 350 280 626 351 280 627 minecraft:crying_obsidian
setblock 350 280 628 minecraft:purple_concrete
fill 350 280 630 352 280 634 minecraft:purple_concrete
setblock 350 280 635 minecraft:magenta_concrete
fill 350 280 641 370 280 645 minecraft:black_concrete
fill 351 280 610 370 280 610 minecraft:black_concrete
setblock 351 280 615 minecraft:purple_concrete
fill 351 280 622 355 280 622 minecraft:crying_obsidian
fill 351 280 628 355 280 628 minecraft:crying_obsidian
setblock 351 280 635 minecraft:purple_concrete
fill 351 280 640 370 280 640 minecraft:black_concrete
fill 352 280 611 370 280 611 minecraft:black_concrete
fill 352 280 615 353 280 615 minecraft:magenta_concrete
setblock 352 280 623 minecraft:crying_obsidian
setblock 352 280 627 minecraft:crying_obsidian
fill 352 280 635 353 280 635 minecraft:magenta_concrete
fill 352 280 639 370 280 639 minecraft:black_concrete
fill 353 280 612 361 280 613 minecraft:black_concrete
setblock 353 280 616 minecraft:magenta_concrete
fill 353 280 617 353 280 620 minecraft:purple_concrete
setblock 353 280 621 minecraft:crying_obsidian
setblock 353 280 629 minecraft:crying_obsidian
fill 353 280 630 353 280 633 minecraft:purple_concrete
setblock 353 280 634 minecraft:magenta_concrete
fill 353 280 637 361 280 638 minecraft:black_concrete
fill 354 280 604 354 290 604 minecraft:purple_concrete
fill 354 280 614 357 280 615 minecraft:black_concrete
fill 354 280 618 354 280 619 minecraft:magenta_concrete
fill 354 280 620 358 280 621 minecraft:purple_concrete
fill 354 280 623 356 280 623 minecraft:crying_obsidian
fill 354 280 627 356 280 627 minecraft:crying_obsidian
fill 354 280 629 358 280 630 minecraft:purple_concrete
fill 354 280 631 354 280 632 minecraft:magenta_concrete
fill 354 280 635 357 280 636 minecraft:black_concrete
fill 355 280 616 355 280 617 minecraft:black_concrete
fill 355 280 618 356 280 618 minecraft:magenta_concrete
fill 355 280 619 359 280 619 minecraft:purple_concrete
fill 355 280 624 356 280 624 minecraft:crying_obsidian
fill 355 280 626 356 280 626 minecraft:crying_obsidian
fill 355 280 631 359 280 631 minecraft:purple_concrete
fill 355 280 632 356 280 632 minecraft:magenta_concrete
fill 355 280 633 355 280 634 minecraft:black_concrete
fill 356 280 604 356 307 604 minecraft:purple_concrete
setblock 356 280 616 minecraft:black_concrete
fill 356 280 617 357 280 617 minecraft:magenta_concrete
fill 356 280 622 358 280 622 minecraft:purple_concrete
fill 356 280 625 357 280 625 minecraft:crying_obsidian
fill 356 280 628 358 280 628 minecraft:purple_concrete
fill 356 280 633 357 280 633 minecraft:magenta_concrete
setblock 356 280 634 minecraft:black_concrete
fill 357 280 618 359 280 618 minecraft:purple_concrete
fill 357 280 623 360 280 624 minecraft:purple_concrete
fill 357 280 626 360 280 627 minecraft:purple_concrete
fill 357 280 632 359 280 632 minecraft:purple_concrete
setblock 358 280 614 minecraft:black_concrete
fill 358 280 617 359 280 617 minecraft:purple_concrete
fill 358 280 625 364 280 625 minecraft:purple_concrete
fill 358 280 633 359 280 633 minecraft:purple_concrete
setblock 358 280 636 minecraft:black_concrete
setblock 359 280 620 minecraft:purple_concrete
fill 359 280 621 360 280 622 minecraft:magenta_concrete
fill 359 280 628 360 280 629 minecraft:magenta_concrete
setblock 359 280 630 minecraft:purple_concrete
fill 360 280 617 360 280 620 minecraft:magenta_concrete
fill 360 280 630 360 280 633 minecraft:magenta_concrete
fill 361 280 617 361 280 619 minecraft:magenta_concrete
fill 361 280 620 370 280 621 minecraft:black_concrete
fill 361 280 622 362 280 623 minecraft:magenta_concrete
fill 361 280 624 362 280 624 minecraft:purple_concrete
fill 361 280 626 362 280 626 minecraft:purple_concrete
fill 361 280 627 362 280 628 minecraft:magenta_concrete
fill 361 280 629 370 280 630 minecraft:black_concrete
fill 361 280 631 361 280 633 minecraft:magenta_concrete
fill 362 280 612 370 280 612 minecraft:black_concrete
setblock 362 280 617 minecraft:magenta_concrete
fill 362 280 618 370 280 619 minecraft:black_concrete
fill 362 280 631 370 280 632 minecraft:black_concrete
setblock 362 280 633 minecraft:magenta_concrete
fill 362 280 638 370 280 638 minecraft:black_concrete
fill 363 280 613 370 280 617 minecraft:black_concrete
fill 363 280 622 370 280 622 minecraft:black_concrete
fill 363 280 623 365 280 624 minecraft:magenta_concrete
fill 363 280 626 365 280 627 minecraft:magenta_concrete
fill 363 280 628 370 280 628 minecraft:black_concrete
fill 363 280 633 370 280 637 minecraft:black_concrete
fill 365 280 625 369 280 625 minecraft:magenta_concrete
fill 366 280 623 370 280 623 minecraft:black_concrete
fill 366 280 624 367 280 624 minecraft:magenta_concrete
fill 366 280 626 367 280 626 minecraft:magenta_concrete
fill 366 280 627 370 280 627 minecraft:black_concrete
fill 368 280 624 370 280 624 minecraft:black_concrete
fill 368 280 626 370 280 626 minecraft:black_concrete
setblock 370 280 604 minecraft:crying_obsidian
setblock 370 280 625 minecraft:black_concrete
setblock 371 280 609 minecraft:purple_concrete
fill 371 280 617 371 307 617 minecraft:purple_concrete
setblock 371 280 618 minecraft:magenta_stained_glass
fill 371 280 619 371 307 619 minecraft:purple_concrete
fill 371 280 635 371 293 636 minecraft:purple_concrete
setblock 371 280 637 minecraft:white_concrete
setblock 329 281 625 minecraft:crying_obsidian
setblock 329 281 637 minecraft:white_concrete
fill 330 281 604 330 286 604 minecraft:purple_concrete
setblock 332 281 607 minecraft:light[level=12]
setblock 332 281 615 minecraft:light[level=12]
setblock 332 281 623 minecraft:light[level=12]
setblock 332 281 631 minecraft:light[level=12]
setblock 332 281 639 minecraft:light[level=12]
setblock 340 281 607 minecraft:light[level=12]
setblock 340 281 615 minecraft:light[level=12]
setblock 340 281 623 minecraft:light[level=12]
setblock 340 281 631 minecraft:light[level=12]
setblock 340 281 639 minecraft:light[level=12]
setblock 348 281 607 minecraft:light[level=12]
setblock 348 281 615 minecraft:light[level=12]
setblock 348 281 623 minecraft:light[level=12]
setblock 348 281 631 minecraft:light[level=12]
setblock 348 281 639 minecraft:light[level=12]
setblock 356 281 607 minecraft:light[level=12]
setblock 356 281 615 minecraft:light[level=12]
setblock 356 281 623 minecraft:light[level=12]
setblock 356 281 631 minecraft:light[level=12]
setblock 356 281 639 minecraft:light[level=12]
setblock 364 281 607 minecraft:light[level=12]
setblock 364 281 615 minecraft:light[level=12]
setblock 364 281 623 minecraft:light[level=12]
setblock 364 281 631 minecraft:light[level=12]
setblock 364 281 639 minecraft:light[level=12]
setblock 365 281 604 minecraft:white_concrete
fill 370 281 604 370 283 604 minecraft:purple_concrete
setblock 371 281 609 minecraft:magenta_stained_glass
fill 371 281 618 371 303 618 minecraft:purple_concrete
fill 371 281 637 371 307 637 minecraft:purple_concrete
fill 329 282 625 329 293 625 minecraft:purple_concrete
fill 329 282 637 329 307 637 minecraft:purple_concrete
fill 340 282 646 340 307 646 minecraft:purple_concrete
setblock 341 282 646 minecraft:crying_obsidian
fill 365 282 604 365 287 604 minecraft:purple_concrete
fill 371 282 609 371 293 609 minecraft:purple_concrete
setblock 371 282 612 minecraft:magenta_stained_glass
setblock 371 282 640 minecraft:white_concrete
setblock 338 283 646 minecraft:magenta_stained_glass
fill 341 283 646 341 287 646 minecraft:purple_concrete
fill 371 283 612 371 307 612 minecraft:purple_concrete
fill 371 283 640 371 295 640 minecraft:purple_concrete
setblock 371 283 643 minecraft:white_concrete
setblock 329 284 607 minecraft:crying_obsidian
fill 335 284 623 335 285 624 minecraft:crying_obsidian
fill 336 284 622 336 284 623 minecraft:crying_obsidian
fill 338 284 646 338 307 646 minecraft:purple_concrete
setblock 342 284 646 minecraft:crying_obsidian
fill 357 284 610 358 290 611 minecraft:black_concrete
fill 361 284 604 361 307 604 minecraft:purple_concrete
setblock 362 284 604 minecraft:crying_obsidian
setblock 366 284 646 minecraft:white_concrete
setblock 370 284 604 minecraft:white_concrete
fill 371 284 643 371 307 643 minecraft:purple_concrete
fill 329 285 607 329 289 607 minecraft:purple_concrete
fill 334 285 624 334 286 625 minecraft:crying_obsidian
setblock 337 285 646 minecraft:white_concrete
setblock 342 285 646 minecraft:white_concrete
fill 362 285 604 362 291 604 minecraft:purple_concrete
fill 363 285 623 363 286 624 minecraft:crying_obsidian
fill 366 285 646 366 307 646 minecraft:purple_concrete
fill 370 285 604 370 307 604 minecraft:purple_concrete
setblock 371 285 616 minecraft:crying_obsidian
setblock 371 285 632 minecraft:white_concrete
setblock 329 286 615 minecraft:magenta_stained_glass
fill 332 286 626 333 286 626 minecraft:crying_obsidian
setblock 333 286 625 minecraft:crying_obsidian
fill 337 286 646 337 295 646 minecraft:purple_concrete
fill 342 286 646 342 307 646 minecraft:purple_concrete
setblock 345 286 604 minecraft:magenta_stained_glass
fill 356 286 610 356 290 611 minecraft:black_concrete
fill 357 286 609 358 290 609 minecraft:black_concrete
fill 357 286 612 358 290 612 minecraft:black_concrete
setblock 359 286 604 minecraft:crying_obsidian
fill 359 286 610 359 290 611 minecraft:black_concrete
fill 363 286 622 364 286 622 minecraft:crying_obsidian
setblock 364 286 623 minecraft:crying_obsidian
setblock 368 286 604 minecraft:magenta_stained_glass
fill 371 286 616 371 290 616 minecraft:purple_concrete
fill 371 286 632 371 291 632 minecraft:purple_concrete
fill 329 287 615 329 307 615 minecraft:purple_concrete
setblock 330 287 604 minecraft:magenta_stained_glass
fill 331 287 626 332 287 627 minecraft:crying_obsidian
fill 345 287 604 345 307 604 minecraft:purple_concrete
setblock 351 287 604 minecraft:white_concrete
fill 352 287 604 352 307 604 minecraft:purple_concrete
fill 356 287 609 356 290 609 minecraft:black_concrete
fill 356 287 612 356 290 612 minecraft:black_concrete
fill 359 287 604 359 305 604 minecraft:purple_concrete
fill 359 287 609 359 290 609 minecraft:black_concrete
fill 359 287 612 359 290 612 minecraft:black_concrete
fill 361 287 630 363 292 632 minecraft:light_blue_concrete
fill 364 287 621 364 287 622 minecraft:crying_obsidian
setblock 365 287 621 minecraft:crying_obsidian
fill 368 287 604 368 307 604 minecraft:purple_concrete
setblock 371 287 629 minecraft:white_concrete
fill 329 288 612 329 290 612 minecraft:magenta_concrete
setblock 329 288 617 minecraft:crying_obsidian
fill 329 288 618 329 307 618 minecraft:purple_concrete
fill 329 288 627 329 307 627 minecraft:purple_concrete
fill 329 288 628 329 290 628 minecraft:magenta_concrete
fill 329 288 644 329 290 644 minecraft:magenta_concrete
fill 330 288 604 330 307 604 minecraft:purple_concrete
setblock 331 288 627 minecraft:crying_obsidian
fill 333 288 604 333 290 604 minecraft:magenta_concrete
setblock 341 288 646 minecraft:white_concrete
fill 343 288 646 343 290 646 minecraft:magenta_concrete
fill 349 288 604 349 290 604 minecraft:magenta_concrete
fill 351 288 604 351 307 604 minecraft:purple_concrete
fill 355 288 609 355 290 611 minecraft:black_concrete
fill 356 288 608 358 290 608 minecraft:black_concrete
fill 357 288 613 358 290 613 minecraft:black_concrete
fill 359 288 646 359 290 646 minecraft:magenta_concrete
fill 360 288 610 360 290 611 minecraft:black_concrete
fill 360 288 630 360 291 632 minecraft:light_blue_concrete
fill 361 288 629 364 291 629 minecraft:light_blue_concrete
fill 361 288 633 363 291 633 minecraft:light_blue_concrete
fill 364 288 620 364 288 621 minecraft:crying_obsidian
fill 364 288 630 364 291 632 minecraft:light_blue_concrete
fill 365 288 604 365 290 604 minecraft:magenta_concrete
fill 365 288 619 365 288 620 minecraft:crying_obsidian
fill 371 288 614 371 290 614 minecraft:magenta_concrete
fill 371 288 629 371 307 629 minecraft:purple_concrete
fill 371 288 630 371 290 630 minecraft:magenta_concrete
fill 329 289 617 329 300 617 minecraft:purple_concrete
setblock 329 289 643 minecraft:white_concrete
setblock 332 289 607 minecraft:light[level=12]
setblock 332 289 615 minecraft:light[level=12]
setblock 332 289 623 minecraft:light[level=12]
setblock 332 289 631 minecraft:light[level=12]
setblock 332 289 639 minecraft:light[level=12]
setblock 340 289 607 minecraft:light[level=12]
setblock 340 289 615 minecraft:light[level=12]
setblock 340 289 623 minecraft:light[level=12]
setblock 340 289 631 minecraft:light[level=12]
setblock 340 289 639 minecraft:light[level=12]
fill 341 289 646 341 290 646 minecraft:purple_concrete
setblock 348 289 607 minecraft:light[level=12]
setblock 348 289 615 minecraft:light[level=12]
setblock 348 289 623 minecraft:light[level=12]
setblock 348 289 631 minecraft:light[level=12]
setblock 348 289 639 minecraft:light[level=12]
fill 355 289 612 355 290 612 minecraft:black_concrete
setblock 356 289 607 minecraft:light[level=12]
fill 356 289 613 356 290 613 minecraft:black_concrete
setblock 356 289 615 minecraft:light[level=12]
setblock 356 289 623 minecraft:light[level=12]
setblock 356 289 631 minecraft:light[level=12]
setblock 356 289 639 minecraft:light[level=12]
fill 359 289 608 359 290 608 minecraft:black_concrete
fill 359 289 613 359 290 613 minecraft:black_concrete
fill 360 289 609 360 290 609 minecraft:black_concrete
fill 360 289 612 360 290 612 minecraft:black_concrete
fill 360 289 629 360 290 629 minecraft:light_blue_concrete
fill 360 289 633 360 290 633 minecraft:light_blue_concrete
fill 362 289 628 363 290 628 minecraft:light_blue_concrete
setblock 364 289 607 minecraft:light[level=12]
setblock 364 289 615 minecraft:light[level=12]
setblock 364 289 623 minecraft:light[level=12]
fill 364 289 633 364 290 633 minecraft:light_blue_concrete
setblock 364 289 639 minecraft:light[level=12]
fill 365 289 618 366 289 619 minecraft:crying_obsidian
fill 365 289 630 365 290 631 minecraft:light_blue_concrete
fill 366 289 617 366 290 617 minecraft:crying_obsidian
setblock 371 289 613 minecraft:crying_obsidian
setblock 371 289 622 minecraft:magenta_stained_glass
setblock 329 290 607 minecraft:crying_obsidian
fill 329 290 643 329 307 643 minecraft:purple_concrete
setblock 335 290 646 minecraft:crying_obsidian
fill 354 290 609 354 290 611 minecraft:black_concrete
setblock 355 290 608 minecraft:black_concrete
setblock 355 290 613 minecraft:black_concrete
fill 356 290 607 359 290 607 minecraft:black_concrete
setblock 357 290 604 minecraft:crying_obsidian
fill 357 290 614 358 290 614 minecraft:black_concrete
setblock 360 290 608 minecraft:black_concrete
setblock 360 290 613 minecraft:black_concrete
fill 361 290 610 361 290 611 minecraft:black_concrete
fill 366 290 616 367 290 616 minecraft:crying_obsidian
setblock 366 290 618 minecraft:crying_obsidian
setblock 367 290 617 minecraft:crying_obsidian
fill 371 290 613 371 307 613 minecraft:purple_concrete
fill 371 290 622 371 307 622 minecraft:purple_concrete
fill 329 291 607 329 301 607 minecraft:purple_concrete
fill 329 291 612 329 296 612 minecraft:purple_concrete
fill 329 291 628 329 296 628 minecraft:purple_concrete
fill 329 291 644 329 296 644 minecraft:purple_concrete
fill 333 291 604 333 296 604 minecraft:purple_concrete
fill 335 291 646 335 307 646 minecraft:purple_concrete
setblock 341 291 646 minecraft:magenta_stained_glass
fill 343 291 646 343 295 646 minecraft:purple_concrete
fill 349 291 604 349 296 604 minecraft:purple_concrete
setblock 354 291 604 minecraft:magenta_stained_glass
fill 357 291 604 357 307 604 minecraft:purple_concrete
fill 357 291 610 358 292 611 minecraft:magenta_stained_glass
fill 359 291 646 359 296 646 minecraft:purple_concrete
fill 365 291 604 365 296 604 minecraft:purple_concrete
setblock 367 291 616 minecraft:crying_obsidian
fill 371 291 614 371 296 614 minecraft:purple_concrete
setblock 371 291 616 minecraft:crying_obsidian
fill 371 291 630 371 296 630 minecraft:purple_concrete
fill 341 292 646 341 305 646 minecraft:purple_concrete
setblock 342 292 604 minecraft:crying_obsidian
fill 354 292 604 354 307 604 minecraft:purple_concrete
setblock 362 292 604 minecraft:white_concrete
fill 371 292 616 371 307 616 minecraft:purple_concrete
setblock 371 292 632 minecraft:magenta_stained_glass
fill 342 293 604 342 307 604 minecraft:purple_concrete
fill 357 293 610 357 293 611 minecraft:magenta_stained_glass
setblock 358 293 610 minecraft:magenta_stained_glass
fill 362 293 604 362 307 604 minecraft:purple_concrete
fill 371 293 632 371 296 632 minecraft:purple_concrete
setblock 329 294 625 minecraft:crying_obsidian
setblock 336 294 646 minecraft:white_concrete
setblock 348 294 646 minecraft:magenta_stained_glass
setblock 357 294 610 minecraft:magenta_stained_glass
setblock 371 294 609 minecraft:magenta_stained_glass
setblock 371 294 634 minecraft:magenta_stained_glass
setblock 371 294 635 minecraft:crying_obsidian
fill 371 294 636 371 307 636 minecraft:purple_concrete
setblock 329 295 608 minecraft:magenta_stained_glass
fill 329 295 609 329 307 609 minecraft:purple_concrete
fill 329 295 625 329 299 625 minecraft:purple_concrete
fill 336 295 646 336 307 646 minecraft:purple_concrete
setblock 346 295 646 minecraft:magenta_stained_glass
fill 348 295 646 348 307 646 minecraft:purple_concrete
fill 371 295 609 371 307 609 minecraft:purple_concrete
setblock 371 295 620 minecraft:white_concrete
fill 371 295 634 371 307 635 minecraft:purple_concrete
fill 329 296 608 329 307 608 minecraft:purple_concrete
setblock 337 296 646 minecraft:magenta_stained_glass
setblock 343 296 646 minecraft:white_concrete
setblock 346 296 646 minecraft:crying_obsidian
setblock 369 296 604 minecraft:magenta_stained_glass
fill 371 296 620 371 307 620 minecraft:purple_concrete
setblock 371 296 638 minecraft:magenta_stained_glass
setblock 371 296 640 minecraft:crying_obsidian
fill 329 297 612 329 299 612 minecraft:magenta_concrete
fill 329 297 628 329 299 628 minecraft:magenta_concrete
fill 329 297 644 329 299 644 minecraft:magenta_concrete
setblock 330 297 646 minecraft:magenta_stained_glass
setblock 332 297 607 minecraft:light[level=12]
setblock 332 297 615 minecraft:light[level=12]
setblock 332 297 623 minecraft:light[level=12]
setblock 332 297 631 minecraft:light[level=12]
setblock 332 297 639 minecraft:light[level=12]
fill 333 297 604 333 299 604 minecraft:magenta_concrete
fill 337 297 646 337 307 646 minecraft:purple_concrete
setblock 340 297 607 minecraft:light[level=12]
setblock 340 297 615 minecraft:light[level=12]
setblock 340 297 623 minecraft:light[level=12]
setblock 340 297 631 minecraft:light[level=12]
setblock 340 297 639 minecraft:light[level=12]
fill 343 297 646 343 299 646 minecraft:magenta_concrete
fill 346 297 646 346 307 646 minecraft:purple_concrete
setblock 348 297 607 minecraft:light[level=12]
setblock 348 297 615 minecraft:light[level=12]
setblock 348 297 623 minecraft:light[level=12]
setblock 348 297 631 minecraft:light[level=12]
setblock 348 297 639 minecraft:light[level=12]
fill 349 297 604 349 299 604 minecraft:magenta_concrete
setblock 356 297 607 minecraft:light[level=12]
setblock 356 297 615 minecraft:light[level=12]
setblock 356 297 623 minecraft:light[level=12]
setblock 356 297 631 minecraft:light[level=12]
setblock 356 297 639 minecraft:light[level=12]
fill 359 297 646 359 299 646 minecraft:magenta_concrete
setblock 364 297 607 minecraft:light[level=12]
setblock 364 297 615 minecraft:light[level=12]
setblock 364 297 623 minecraft:light[level=12]
setblock 364 297 631 minecraft:light[level=12]
setblock 364 297 639 minecraft:light[level=12]
fill 365 297 604 365 299 604 minecraft:magenta_concrete
fill 369 297 604 369 307 604 minecraft:purple_concrete
fill 371 297 614 371 299 614 minecraft:magenta_concrete
fill 371 297 630 371 299 630 minecraft:magenta_concrete
setblock 371 297 632 minecraft:magenta_stained_glass
fill 371 297 638 371 307 638 minecraft:purple_concrete
fill 371 297 640 371 307 640 minecraft:purple_concrete
fill 330 298 646 330 307 646 minecraft:purple_concrete
setblock 371 298 615 minecraft:magenta_stained_glass
fill 371 298 632 371 307 632 minecraft:purple_concrete
setblock 358 299 604 minecraft:white_concrete
fill 371 299 615 371 307 615 minecraft:purple_concrete
fill 329 300 612 329 307 612 minecraft:purple_concrete
setblock 329 300 625 minecraft:crying_obsidian
fill 329 300 628 329 307 628 minecraft:purple_concrete
fill 329 300 639 329 307 639 minecraft:purple_concrete
setblock 329 300 640 minecraft:white_concrete
fill 329 300 644 329 307 644 minecraft:purple_concrete
setblock 333 300 604 minecraft:purple_concrete
setblock 336 300 604 minecraft:crying_obsidian
fill 343 300 646 343 307 646 minecraft:purple_concrete
fill 349 300 604 349 307 604 minecraft:purple_concrete
fill 358 300 604 358 307 604 minecraft:purple_concrete
fill 359 300 646 359 307 646 minecraft:purple_concrete
fill 365 300 604 365 307 604 minecraft:purple_concrete
fill 371 300 614 371 307 614 minecraft:purple_concrete
fill 371 300 630 371 307 630 minecraft:purple_concrete
setblock 329 301 617 minecraft:white_concrete
fill 329 301 625 329 307 625 minecraft:purple_concrete
fill 329 301 640 329 307 640 minecraft:purple_concrete
setblock 333 301 604 minecraft:crying_obsidian
fill 336 301 604 336 303 604 minecraft:purple_concrete
setblock 364 301 646 minecraft:magenta_stained_glass
setblock 329 302 607 minecraft:white_concrete
fill 329 302 617 329 307 617 minecraft:purple_concrete
fill 329 302 622 329 307 622 minecraft:purple_concrete
setblock 329 302 623 minecraft:white_concrete
fill 329 302 624 329 307 624 minecraft:purple_concrete
fill 333 302 604 333 307 604 minecraft:purple_concrete
fill 364 302 646 364 305 646 minecraft:purple_concrete
fill 329 303 607 329 304 607 minecraft:purple_concrete
fill 329 303 623 329 307 623 minecraft:purple_concrete
setblock 329 304 620 minecraft:crying_obsidian
setblock 336 304 604 minecraft:white_concrete
setblock 344 304 604 minecraft:white_concrete
fill 347 304 604 347 307 604 minecraft:purple_concrete
setblock 348 304 604 minecraft:white_concrete
setblock 371 304 618 minecraft:white_concrete
setblock 329 305 607 minecraft:crying_obsidian
fill 329 305 620 329 307 620 minecraft:purple_concrete
fill 336 305 604 336 307 604 minecraft:purple_concrete
setblock 338 305 604 minecraft:magenta_stained_glass
setblock 340 305 604 minecraft:crying_obsidian
fill 344 305 604 344 307 604 minecraft:purple_concrete
fill 348 305 604 348 307 604 minecraft:purple_concrete
fill 371 305 618 371 307 618 minecraft:purple_concrete
fill 329 306 607 329 307 607 minecraft:purple_concrete
fill 338 306 604 338 307 604 minecraft:purple_concrete
fill 340 306 604 340 307 604 minecraft:purple_concrete
setblock 341 306 646 minecraft:white_concrete
setblock 359 306 604 minecraft:magenta_stained_glass
setblock 364 306 646 minecraft:white_concrete
setblock 341 307 646 minecraft:purple_concrete
setblock 359 307 604 minecraft:purple_concrete
setblock 364 307 646 minecraft:purple_concrete
setblock 367 307 646 minecraft:purple_concrete
setblock 368 307 646 minecraft:magenta_stained_glass
setblock 371 307 625 minecraft:magenta_stained_glass
setblock 371 307 626 minecraft:purple_concrete
