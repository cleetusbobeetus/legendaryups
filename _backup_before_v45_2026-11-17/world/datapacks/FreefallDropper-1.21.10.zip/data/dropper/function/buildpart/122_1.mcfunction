setblock 95 22 551 minecraft:smooth_basalt
fill 96 22 511 96 25 511 minecraft:blackstone
setblock 96 22 514 minecraft:blackstone
setblock 96 22 515 minecraft:smooth_basalt
fill 96 22 516 96 25 516 minecraft:blackstone
fill 96 22 531 96 25 531 minecraft:blackstone
setblock 96 22 535 minecraft:smooth_basalt
fill 96 22 536 96 25 536 minecraft:blackstone
setblock 96 22 539 minecraft:blackstone
setblock 96 22 540 minecraft:smooth_basalt
fill 96 22 541 97 24 541 minecraft:blackstone
setblock 96 22 544 minecraft:blackstone
fill 96 22 546 96 25 546 minecraft:blackstone
fill 96 22 548 96 23 548 minecraft:blackstone
setblock 96 22 550 minecraft:smooth_basalt
fill 96 22 551 96 25 551 minecraft:blackstone
setblock 97 22 533 minecraft:blackstone
setblock 97 22 534 minecraft:smooth_basalt
fill 97 22 535 98 24 535 minecraft:blackstone
setblock 97 22 538 minecraft:blackstone
setblock 97 22 539 minecraft:smooth_basalt
fill 97 22 540 98 24 540 minecraft:blackstone
fill 97 22 542 97 22 543 minecraft:blackstone
fill 97 22 544 99 22 544 minecraft:smooth_basalt
fill 97 22 550 97 25 550 minecraft:blackstone
fill 98 22 534 98 25 534 minecraft:blackstone
fill 98 22 536 98 22 537 minecraft:blackstone
setblock 98 22 538 minecraft:smooth_basalt
fill 98 22 539 98 25 539 minecraft:blackstone
fill 98 22 541 98 22 543 minecraft:smooth_basalt
setblock 99 22 512 minecraft:smooth_basalt
fill 99 22 542 99 77 543 minecraft:smooth_basalt
setblock 100 22 511 minecraft:smooth_basalt
fill 100 22 512 100 25 512 minecraft:blackstone
setblock 100 22 551 minecraft:smooth_basalt
fill 101 22 511 101 25 511 minecraft:blackstone
setblock 101 22 550 minecraft:smooth_basalt
fill 101 22 551 101 25 551 minecraft:blackstone
setblock 102 22 550 minecraft:blackstone
setblock 105 22 511 minecraft:smooth_basalt
setblock 105 22 551 minecraft:smooth_basalt
fill 113 22 511 113 23 511 minecraft:blackstone
setblock 115 22 511 minecraft:smooth_basalt
fill 115 22 512 115 25 512 minecraft:blackstone
fill 116 22 511 116 25 511 minecraft:blackstone
fill 116 22 513 116 23 513 minecraft:blackstone
setblock 118 22 513 minecraft:smooth_basalt
fill 118 22 514 118 25 514 minecraft:blackstone
setblock 119 22 512 minecraft:smooth_basalt
fill 119 22 513 119 25 513 minecraft:blackstone
setblock 120 22 511 minecraft:smooth_basalt
fill 120 22 512 120 25 512 minecraft:blackstone
setblock 120 22 551 minecraft:smooth_basalt
fill 121 22 511 121 25 511 minecraft:blackstone
fill 121 22 551 121 25 551 minecraft:blackstone
setblock 122 22 514 minecraft:smooth_basalt
setblock 123 22 513 minecraft:smooth_basalt
fill 123 22 514 123 25 514 minecraft:blackstone
setblock 124 22 512 minecraft:smooth_basalt
fill 124 22 513 124 25 513 minecraft:blackstone
setblock 125 22 511 minecraft:smooth_basalt
fill 125 22 512 125 25 512 minecraft:blackstone
fill 125 22 514 125 23 514 minecraft:blackstone
setblock 125 22 551 minecraft:smooth_basalt
fill 126 22 511 126 25 511 minecraft:blackstone
fill 126 22 551 126 23 551 minecraft:blackstone
setblock 128 22 513 minecraft:smooth_basalt
setblock 129 22 512 minecraft:smooth_basalt
setblock 130 22 511 minecraft:smooth_basalt
fill 130 22 512 130 25 512 minecraft:blackstone
fill 131 22 511 131 25 511 minecraft:blackstone
setblock 134 22 512 minecraft:smooth_basalt
fill 134 22 513 134 25 513 minecraft:blackstone
setblock 134 22 517 minecraft:smooth_basalt
setblock 135 22 511 minecraft:smooth_basalt
fill 135 22 512 135 25 512 minecraft:blackstone
setblock 135 22 516 minecraft:smooth_basalt
fill 135 22 517 135 25 517 minecraft:blackstone
setblock 135 22 520 minecraft:blackstone
fill 135 22 532 135 22 535 minecraft:blackstone
setblock 135 22 536 minecraft:smooth_basalt
fill 135 22 537 135 25 537 minecraft:blackstone
setblock 135 22 541 minecraft:smooth_basalt
fill 135 22 542 135 22 545 minecraft:blackstone
setblock 135 22 546 minecraft:smooth_basalt
fill 135 22 547 135 24 548 minecraft:blackstone
setblock 135 22 551 minecraft:smooth_basalt
fill 95 23 511 95 26 511 minecraft:blackstone
setblock 95 23 514 minecraft:blackstone
setblock 95 23 515 minecraft:smooth_basalt
fill 95 23 516 95 26 516 minecraft:blackstone
setblock 95 23 520 minecraft:smooth_basalt
setblock 95 23 530 minecraft:smooth_basalt
fill 95 23 531 95 26 531 minecraft:blackstone
setblock 95 23 534 minecraft:blackstone
setblock 95 23 535 minecraft:smooth_basalt
fill 95 23 536 95 26 536 minecraft:blackstone
setblock 95 23 539 minecraft:blackstone
setblock 95 23 540 minecraft:smooth_basalt
fill 95 23 541 95 26 541 minecraft:blackstone
setblock 95 23 545 minecraft:smooth_basalt
fill 95 23 546 95 26 546 minecraft:blackstone
setblock 95 23 550 minecraft:smooth_basalt
fill 95 23 551 95 26 551 minecraft:blackstone
setblock 96 23 514 minecraft:smooth_basalt
fill 96 23 515 96 26 515 minecraft:blackstone
fill 96 23 517 96 23 518 minecraft:blackstone
setblock 96 23 534 minecraft:smooth_basalt
fill 96 23 535 96 26 535 minecraft:blackstone
setblock 96 23 539 minecraft:smooth_basalt
fill 96 23 540 96 26 540 minecraft:blackstone
setblock 96 23 544 minecraft:smooth_basalt
fill 96 23 545 97 25 545 minecraft:blackstone
setblock 96 23 549 minecraft:smooth_basalt
fill 96 23 550 96 26 550 minecraft:blackstone
setblock 97 23 532 minecraft:blackstone
setblock 97 23 533 minecraft:smooth_basalt
fill 97 23 534 97 26 534 minecraft:blackstone
setblock 97 23 538 minecraft:smooth_basalt
fill 97 23 539 97 26 539 minecraft:blackstone
setblock 97 23 542 minecraft:blackstone
fill 97 23 543 98 23 543 minecraft:smooth_basalt
fill 97 23 544 97 26 544 minecraft:blackstone
setblock 98 23 512 minecraft:smooth_basalt
fill 98 23 513 99 23 513 minecraft:blackstone
setblock 98 23 536 minecraft:blackstone
setblock 98 23 537 minecraft:smooth_basalt
fill 98 23 538 99 25 538 minecraft:blackstone
setblock 98 23 541 minecraft:blackstone
setblock 98 23 542 minecraft:smooth_basalt
fill 98 23 544 99 24 545 minecraft:smooth_basalt
setblock 99 23 511 minecraft:smooth_basalt
fill 99 23 512 99 26 512 minecraft:blackstone
fill 99 23 537 99 26 537 minecraft:blackstone
setblock 99 23 551 minecraft:smooth_basalt
fill 100 23 511 100 26 511 minecraft:blackstone
setblock 100 23 550 minecraft:smooth_basalt
fill 100 23 551 100 26 551 minecraft:blackstone
fill 101 23 550 101 24 550 minecraft:blackstone
setblock 103 23 512 minecraft:smooth_basalt
setblock 104 23 511 minecraft:smooth_basalt
setblock 104 23 551 minecraft:smooth_basalt
setblock 105 23 511 minecraft:blackstone
setblock 114 23 511 minecraft:smooth_basalt
fill 114 23 512 114 26 512 minecraft:blackstone
fill 115 23 511 115 26 511 minecraft:blackstone
setblock 117 23 513 minecraft:smooth_basalt
fill 117 23 514 117 26 514 minecraft:blackstone
fill 117 23 551 117 24 551 minecraft:blackstone
setblock 118 23 512 minecraft:smooth_basalt
fill 118 23 513 118 26 513 minecraft:blackstone
setblock 119 23 511 minecraft:smooth_basalt
fill 119 23 512 119 26 512 minecraft:blackstone
setblock 119 23 551 minecraft:smooth_basalt
fill 120 23 511 120 26 511 minecraft:blackstone
setblock 120 23 515 minecraft:smooth_basalt
fill 120 23 551 120 26 551 minecraft:blackstone
setblock 121 23 513 minecraft:blackstone
setblock 121 23 514 minecraft:smooth_basalt
fill 121 23 515 121 24 515 minecraft:blackstone
setblock 122 23 513 minecraft:smooth_basalt
fill 122 23 514 122 26 514 minecraft:blackstone
setblock 123 23 512 minecraft:smooth_basalt
fill 123 23 513 123 26 513 minecraft:blackstone
setblock 124 23 511 minecraft:smooth_basalt
fill 124 23 512 124 26 512 minecraft:blackstone
setblock 124 23 551 minecraft:smooth_basalt
fill 125 23 511 125 26 511 minecraft:blackstone
fill 125 23 551 125 24 551 minecraft:blackstone
setblock 127 23 513 minecraft:smooth_basalt
setblock 128 23 512 minecraft:smooth_basalt
setblock 128 23 513 minecraft:blackstone
setblock 129 23 511 minecraft:smooth_basalt
fill 129 23 512 129 26 512 minecraft:blackstone
fill 130 23 511 130 26 511 minecraft:blackstone
fill 131 23 551 131 25 551 minecraft:blackstone
setblock 133 23 512 minecraft:smooth_basalt
fill 133 23 513 133 24 515 minecraft:blackstone
setblock 134 23 511 minecraft:smooth_basalt
fill 134 23 512 134 26 512 minecraft:blackstone
setblock 134 23 516 minecraft:smooth_basalt
fill 134 23 517 134 24 519 minecraft:blackstone
fill 134 23 537 134 24 539 minecraft:blackstone
setblock 134 23 551 minecraft:smooth_basalt
fill 135 23 511 135 26 511 minecraft:blackstone
setblock 135 23 515 minecraft:smooth_basalt
fill 135 23 516 135 26 516 minecraft:blackstone
setblock 135 23 520 minecraft:smooth_basalt
fill 135 23 521 135 26 521 minecraft:blackstone
fill 135 23 532 135 23 534 minecraft:blackstone
setblock 135 23 535 minecraft:smooth_basalt
fill 135 23 536 135 26 536 minecraft:blackstone
fill 135 23 538 135 23 539 minecraft:blackstone
setblock 135 23 540 minecraft:smooth_basalt
fill 135 23 541 135 23 544 minecraft:blackstone
setblock 135 23 545 minecraft:smooth_basalt
fill 135 23 546 135 26 546 minecraft:blackstone
setblock 135 23 550 minecraft:smooth_basalt
fill 135 23 551 135 26 551 minecraft:blackstone
setblock 95 24 514 minecraft:smooth_basalt
fill 95 24 515 95 27 515 minecraft:blackstone
fill 95 24 517 95 24 518 minecraft:blackstone
setblock 95 24 519 minecraft:smooth_basalt
fill 95 24 520 95 25 522 minecraft:blackstone
setblock 95 24 529 minecraft:smooth_basalt
fill 95 24 530 95 27 530 minecraft:blackstone
setblock 95 24 534 minecraft:smooth_basalt
fill 95 24 535 95 27 535 minecraft:blackstone
setblock 95 24 539 minecraft:smooth_basalt
fill 95 24 540 95 27 540 minecraft:blackstone
setblock 95 24 543 minecraft:blackstone
setblock 95 24 544 minecraft:smooth_basalt
fill 95 24 545 95 27 545 minecraft:blackstone
setblock 95 24 549 minecraft:smooth_basalt
fill 95 24 550 95 27 550 minecraft:blackstone
setblock 96 24 513 minecraft:smooth_basalt
fill 96 24 514 97 25 514 minecraft:blackstone
setblock 96 24 517 minecraft:blackstone
setblock 96 24 518 minecraft:smooth_basalt
fill 96 24 519 96 26 520 minecraft:blackstone
setblock 96 24 533 minecraft:smooth_basalt
fill 96 24 534 96 27 534 minecraft:blackstone
setblock 96 24 537 minecraft:blackstone
setblock 96 24 538 minecraft:smooth_basalt
fill 96 24 539 96 27 539 minecraft:blackstone
setblock 96 24 542 minecraft:blackstone
setblock 96 24 543 minecraft:smooth_basalt
fill 96 24 544 96 27 544 minecraft:blackstone
setblock 96 24 548 minecraft:smooth_basalt
fill 96 24 549 96 27 549 minecraft:blackstone
setblock 97 24 512 minecraft:smooth_basalt
setblock 97 24 513 minecraft:light[level=12]
fill 97 24 515 97 24 516 minecraft:blackstone
setblock 97 24 521 minecraft:light[level=12]
setblock 97 24 529 minecraft:light[level=12]
setblock 97 24 532 minecraft:smooth_basalt
fill 97 24 533 97 27 533 minecraft:blackstone
setblock 97 24 537 minecraft:smooth_basalt
fill 97 24 538 97 27 538 minecraft:blackstone
setblock 97 24 542 minecraft:smooth_basalt
fill 97 24 543 98 26 543 minecraft:blackstone
setblock 97 24 546 minecraft:blackstone
setblock 98 24 511 minecraft:smooth_basalt
fill 98 24 512 98 24 513 minecraft:blackstone
setblock 98 24 536 minecraft:smooth_basalt
fill 98 24 537 98 27 537 minecraft:blackstone
setblock 98 24 541 minecraft:smooth_basalt
fill 98 24 542 98 27 542 minecraft:blackstone
setblock 98 24 551 minecraft:smooth_basalt
fill 99 24 511 99 27 511 minecraft:blackstone
fill 99 24 536 99 25 536 minecraft:blackstone
setblock 99 24 539 minecraft:blackstone
setblock 99 24 540 minecraft:smooth_basalt
setblock 99 24 550 minecraft:smooth_basalt
fill 99 24 551 99 27 551 minecraft:blackstone
fill 100 24 550 100 25 550 minecraft:blackstone
setblock 102 24 512 minecraft:smooth_basalt
setblock 103 24 511 minecraft:smooth_basalt
setblock 103 24 551 minecraft:smooth_basalt
setblock 104 24 511 minecraft:blackstone
setblock 105 24 513 minecraft:light[level=12]
setblock 105 24 521 minecraft:light[level=12]
setblock 105 24 529 minecraft:light[level=12]
setblock 105 24 537 minecraft:light[level=12]
setblock 105 24 545 minecraft:light[level=12]
setblock 112 24 511 minecraft:blackstone
setblock 113 24 511 minecraft:smooth_basalt
setblock 113 24 513 minecraft:light[level=12]
setblock 113 24 521 minecraft:light[level=12]
setblock 113 24 529 minecraft:light[level=12]
setblock 113 24 537 minecraft:light[level=12]
setblock 113 24 545 minecraft:light[level=12]
fill 114 24 511 114 27 511 minecraft:blackstone
setblock 115 24 513 minecraft:blackstone
setblock 116 24 513 minecraft:smooth_basalt
fill 116 24 514 116 26 514 minecraft:blackstone
setblock 117 24 512 minecraft:smooth_basalt
fill 117 24 513 117 27 513 minecraft:blackstone
setblock 118 24 511 minecraft:smooth_basalt
fill 118 24 512 118 27 512 minecraft:blackstone
setblock 118 24 551 minecraft:smooth_basalt
fill 119 24 511 119 27 511 minecraft:blackstone
setblock 119 24 514 minecraft:blackstone
setblock 119 24 515 minecraft:smooth_basalt
fill 119 24 551 119 27 551 minecraft:blackstone
setblock 120 24 514 minecraft:smooth_basalt
fill 120 24 515 120 25 515 minecraft:blackstone
setblock 121 24 513 minecraft:smooth_basalt
fill 121 24 514 121 26 514 minecraft:blackstone
setblock 121 24 521 minecraft:light[level=12]
setblock 121 24 529 minecraft:light[level=12]
setblock 121 24 537 minecraft:light[level=12]
setblock 121 24 545 minecraft:light[level=12]
setblock 122 24 512 minecraft:smooth_basalt
fill 122 24 513 122 27 513 minecraft:blackstone
setblock 123 24 511 minecraft:smooth_basalt
fill 123 24 512 123 27 512 minecraft:blackstone
setblock 123 24 551 minecraft:smooth_basalt
fill 124 24 511 124 27 511 minecraft:blackstone
fill 124 24 551 124 25 551 minecraft:blackstone
setblock 126 24 513 minecraft:smooth_basalt
setblock 127 24 512 minecraft:smooth_basalt
setblock 127 24 513 minecraft:blackstone
setblock 128 24 511 minecraft:smooth_basalt
fill 128 24 512 128 26 512 minecraft:blackstone
fill 129 24 511 129 27 511 minecraft:blackstone
setblock 129 24 513 minecraft:light[level=12]
setblock 129 24 521 minecraft:light[level=12]
setblock 129 24 529 minecraft:light[level=12]
setblock 129 24 537 minecraft:light[level=12]
setblock 129 24 545 minecraft:light[level=12]
setblock 132 24 512 minecraft:smooth_basalt
setblock 133 24 511 minecraft:smooth_basalt
fill 133 24 512 133 27 512 minecraft:blackstone
setblock 133 24 516 minecraft:smooth_basalt
setblock 133 24 551 minecraft:smooth_basalt
fill 134 24 511 134 27 511 minecraft:blackstone
setblock 134 24 515 minecraft:smooth_basalt
fill 134 24 516 134 27 516 minecraft:blackstone
setblock 134 24 520 minecraft:smooth_basalt
fill 134 24 536 134 27 536 minecraft:blackstone
setblock 134 24 540 minecraft:smooth_basalt
fill 134 24 541 135 24 543 minecraft:blackstone
fill 134 24 551 134 27 551 minecraft:blackstone
setblock 135 24 514 minecraft:smooth_basalt
fill 135 24 515 135 27 515 minecraft:blackstone
setblock 135 24 518 minecraft:blackstone
setblock 135 24 519 minecraft:smooth_basalt
fill 135 24 520 135 27 520 minecraft:blackstone
fill 135 24 522 135 25 522 minecraft:blackstone
fill 135 24 532 135 24 533 minecraft:blackstone
setblock 135 24 534 minecraft:smooth_basalt
fill 135 24 535 135 27 535 minecraft:blackstone
setblock 135 24 538 minecraft:blackstone
setblock 135 24 539 minecraft:smooth_basalt
fill 135 24 540 135 27 540 minecraft:blackstone
setblock 135 24 544 minecraft:smooth_basalt
fill 135 24 545 135 27 545 minecraft:blackstone
setblock 135 24 549 minecraft:smooth_basalt
fill 135 24 550 135 27 550 minecraft:blackstone
setblock 95 25 513 minecraft:smooth_basalt
fill 95 25 514 95 28 514 minecraft:blackstone
setblock 95 25 517 minecraft:blackstone
setblock 95 25 518 minecraft:smooth_basalt
fill 95 25 519 95 28 519 minecraft:blackstone
setblock 95 25 523 minecraft:smooth_basalt
fill 95 25 524 95 28 524 minecraft:blackstone
setblock 95 25 528 minecraft:smooth_basalt
fill 95 25 529 95 28 529 minecraft:blackstone
setblock 95 25 533 minecraft:smooth_basalt
fill 95 25 534 95 28 534 minecraft:blackstone
setblock 95 25 538 minecraft:smooth_basalt
fill 95 25 539 95 28 539 minecraft:blackstone
setblock 95 25 543 minecraft:smooth_basalt
fill 95 25 544 95 28 544 minecraft:blackstone
setblock 95 25 547 minecraft:blackstone
setblock 95 25 548 minecraft:smooth_basalt
fill 95 25 549 95 28 549 minecraft:blackstone
setblock 96 25 512 minecraft:smooth_basalt
fill 96 25 513 96 27 513 minecraft:blackstone
setblock 96 25 517 minecraft:smooth_basalt
fill 96 25 518 97 27 518 minecraft:blackstone
setblock 96 25 521 minecraft:blackstone
fill 96 25 530 96 26 530 minecraft:blackstone
setblock 96 25 532 minecraft:smooth_basalt
fill 96 25 533 96 28 533 minecraft:blackstone
setblock 96 25 537 minecraft:smooth_basalt
fill 96 25 538 96 28 538 minecraft:blackstone
setblock 96 25 541 minecraft:blackstone
setblock 96 25 542 minecraft:smooth_basalt
fill 96 25 543 96 28 543 minecraft:blackstone
setblock 96 25 547 minecraft:smooth_basalt
fill 96 25 548 96 28 548 minecraft:blackstone
setblock 97 25 511 minecraft:smooth_basalt
fill 97 25 512 98 26 512 minecraft:blackstone
setblock 97 25 515 minecraft:blackstone
setblock 97 25 516 minecraft:smooth_basalt
fill 97 25 517 97 27 517 minecraft:blackstone
fill 97 25 532 97 26 532 minecraft:blackstone
setblock 97 25 535 minecraft:blackstone
setblock 97 25 536 minecraft:smooth_basalt
fill 97 25 537 97 28 537 minecraft:blackstone
setblock 97 25 540 minecraft:blackstone
setblock 97 25 541 minecraft:smooth_basalt
fill 97 25 542 97 28 542 minecraft:blackstone
setblock 97 25 546 minecraft:smooth_basalt
fill 97 25 547 97 28 547 minecraft:blackstone
setblock 97 25 551 minecraft:smooth_basalt
fill 98 25 511 98 28 511 minecraft:blackstone
setblock 98 25 535 minecraft:smooth_basalt
fill 98 25 536 98 28 536 minecraft:blackstone
setblock 98 25 540 minecraft:smooth_basalt
fill 98 25 541 99 26 541 minecraft:blackstone
setblock 98 25 544 minecraft:blackstone
fill 98 25 545 99 77 545 minecraft:smooth_basalt
setblock 98 25 550 minecraft:smooth_basalt
fill 98 25 551 98 28 551 minecraft:blackstone
setblock 99 25 539 minecraft:smooth_basalt
fill 99 25 540 99 27 540 minecraft:blackstone
fill 99 25 544 99 77 544 minecraft:smooth_basalt
fill 99 25 550 99 26 550 minecraft:blackstone
setblock 101 25 512 minecraft:smooth_basalt
fill 101 25 526 101 47 526 minecraft:smooth_basalt
setblock 102 25 511 minecraft:smooth_basalt
setblock 102 25 551 minecraft:smooth_basalt
setblock 103 25 511 minecraft:blackstone
setblock 112 25 511 minecraft:smooth_basalt
fill 113 25 511 113 26 512 minecraft:blackstone
setblock 115 25 513 minecraft:smooth_basalt
setblock 116 25 512 minecraft:smooth_basalt
fill 116 25 513 116 28 513 minecraft:blackstone
setblock 116 25 551 minecraft:blackstone
setblock 117 25 511 minecraft:smooth_basalt
fill 117 25 512 117 28 512 minecraft:blackstone
setblock 117 25 551 minecraft:smooth_basalt
fill 118 25 511 118 28 511 minecraft:blackstone
setblock 118 25 515 minecraft:smooth_basalt
fill 118 25 551 118 28 551 minecraft:blackstone
setblock 119 25 514 minecraft:smooth_basalt
setblock 119 25 515 minecraft:blackstone
setblock 120 25 513 minecraft:smooth_basalt
fill 120 25 514 120 27 514 minecraft:blackstone
setblock 121 25 512 minecraft:smooth_basalt
fill 121 25 513 121 28 513 minecraft:blackstone
setblock 122 25 511 minecraft:smooth_basalt
fill 122 25 512 122 28 512 minecraft:blackstone
setblock 122 25 551 minecraft:smooth_basalt
fill 123 25 511 123 28 511 minecraft:blackstone
fill 123 25 551 123 26 551 minecraft:blackstone
setblock 125 25 513 minecraft:smooth_basalt
setblock 126 25 512 minecraft:smooth_basalt
setblock 126 25 513 minecraft:blackstone
setblock 127 25 511 minecraft:smooth_basalt
fill 127 25 512 127 26 512 minecraft:blackstone
fill 128 25 511 128 28 511 minecraft:blackstone
setblock 131 25 512 minecraft:smooth_basalt
setblock 132 25 511 minecraft:smooth_basalt
fill 132 25 512 132 27 512 minecraft:blackstone
setblock 132 25 551 minecraft:smooth_basalt
fill 133 25 511 133 28 511 minecraft:blackstone
fill 133 25 513 133 25 514 minecraft:blackstone
setblock 133 25 515 minecraft:smooth_basalt
fill 133 25 516 133 27 517 minecraft:blackstone
fill 133 25 551 133 28 551 minecraft:blackstone
setblock 134 25 514 minecraft:smooth_basalt
fill 134 25 515 134 28 515 minecraft:blackstone
fill 134 25 517 134 25 518 minecraft:blackstone
setblock 134 25 519 minecraft:smooth_basalt
fill 134 25 520 134 28 520 minecraft:blackstone
fill 134 25 535 134 26 535 minecraft:blackstone
fill 134 25 537 134 25 538 minecraft:blackstone
setblock 134 25 539 minecraft:smooth_basalt
fill 134 25 540 134 25 543 minecraft:blackstone
setblock 134 25 544 minecraft:smooth_basalt
fill 134 25 545 134 25 548 minecraft:blackstone
setblock 134 25 549 minecraft:smooth_basalt
fill 134 25 550 134 28 550 minecraft:blackstone
setblock 135 25 513 minecraft:smooth_basalt
fill 135 25 514 135 28 514 minecraft:blackstone
setblock 135 25 518 minecraft:smooth_basalt
fill 135 25 519 135 28 519 minecraft:blackstone
setblock 135 25 523 minecraft:smooth_basalt
fill 135 25 531 135 25 532 minecraft:blackstone
setblock 135 25 533 minecraft:smooth_basalt
fill 135 25 534 135 28 534 minecraft:blackstone
setblock 135 25 538 minecraft:smooth_basalt
fill 135 25 539 135 28 539 minecraft:blackstone
fill 135 25 541 135 25 542 minecraft:blackstone
setblock 135 25 543 minecraft:smooth_basalt
fill 135 25 544 135 28 544 minecraft:blackstone
setblock 135 25 547 minecraft:blackstone
setblock 135 25 548 minecraft:smooth_basalt
fill 135 25 549 135 28 549 minecraft:blackstone
setblock 95 26 512 minecraft:smooth_basalt
fill 95 26 513 95 29 513 minecraft:blackstone
setblock 95 26 517 minecraft:smooth_basalt
fill 95 26 518 95 29 518 minecraft:blackstone
fill 95 26 520 95 26 521 minecraft:blackstone
setblock 95 26 522 minecraft:smooth_basalt
fill 95 26 523 96 28 523 minecraft:blackstone
fill 95 26 525 95 26 526 minecraft:blackstone
setblock 95 26 527 minecraft:smooth_basalt
fill 95 26 528 95 29 528 minecraft:blackstone
setblock 95 26 532 minecraft:smooth_basalt
fill 95 26 533 95 29 533 minecraft:blackstone
setblock 95 26 537 minecraft:smooth_basalt
fill 95 26 538 95 29 538 minecraft:blackstone
setblock 95 26 542 minecraft:smooth_basalt
fill 95 26 543 95 29 543 minecraft:blackstone
setblock 95 26 547 minecraft:smooth_basalt
fill 95 26 548 95 29 548 minecraft:blackstone
setblock 96 26 511 minecraft:smooth_basalt
setblock 96 26 512 minecraft:blackstone
fill 96 26 514 96 27 514 minecraft:blackstone
setblock 96 26 516 minecraft:smooth_basalt
fill 96 26 517 96 29 517 minecraft:blackstone
setblock 96 26 521 minecraft:smooth_basalt
fill 96 26 522 96 29 522 minecraft:blackstone
setblock 96 26 531 minecraft:smooth_basalt
fill 96 26 532 96 29 532 minecraft:blackstone
setblock 96 26 536 minecraft:smooth_basalt
fill 96 26 537 96 29 537 minecraft:blackstone
setblock 96 26 541 minecraft:smooth_basalt
fill 96 26 542 96 29 542 minecraft:blackstone
setblock 96 26 545 minecraft:blackstone
setblock 96 26 546 minecraft:smooth_basalt
fill 96 26 547 96 29 547 minecraft:blackstone
setblock 96 26 551 minecraft:smooth_basalt
fill 97 26 511 97 28 511 minecraft:blackstone
setblock 97 26 516 minecraft:blackstone
setblock 97 26 519 minecraft:blackstone
fill 97 26 525 100 34 527 minecraft:smooth_basalt
setblock 97 26 535 minecraft:smooth_basalt
fill 97 26 536 97 29 536 minecraft:blackstone
setblock 97 26 540 minecraft:smooth_basalt
fill 97 26 541 97 29 541 minecraft:blackstone
setblock 97 26 545 minecraft:smooth_basalt
fill 97 26 546 97 29 546 minecraft:blackstone
setblock 97 26 550 minecraft:smooth_basalt
fill 97 26 551 97 29 551 minecraft:blackstone
fill 98 26 524 104 46 524 minecraft:smooth_basalt
fill 98 26 528 104 46 528 minecraft:smooth_basalt
setblock 98 26 534 minecraft:smooth_basalt
fill 98 26 535 98 27 535 minecraft:blackstone
setblock 98 26 538 minecraft:blackstone
setblock 98 26 539 minecraft:smooth_basalt
fill 98 26 540 98 29 540 minecraft:blackstone
setblock 98 26 544 minecraft:smooth_basalt
fill 98 26 550 98 27 550 minecraft:blackstone
fill 99 26 523 103 46 523 minecraft:smooth_basalt
fill 99 26 529 103 46 529 minecraft:smooth_basalt
setblock 99 26 538 minecraft:smooth_basalt
fill 99 26 539 99 27 539 minecraft:blackstone
fill 100 26 522 102 46 522 minecraft:smooth_basalt
fill 100 26 530 102 46 530 minecraft:smooth_basalt
setblock 101 26 511 minecraft:smooth_basalt
fill 101 26 525 105 46 525 minecraft:smooth_basalt
fill 101 26 527 105 46 527 minecraft:smooth_basalt
setblock 101 26 551 minecraft:smooth_basalt
setblock 102 26 511 minecraft:blackstone
fill 102 26 526 105 46 526 minecraft:smooth_basalt
setblock 112 26 511 minecraft:blackstone
setblock 115 26 512 minecraft:smooth_basalt
fill 115 26 513 115 28 513 minecraft:blackstone
setblock 116 26 511 minecraft:smooth_basalt
fill 116 26 512 116 29 512 minecraft:blackstone
setblock 116 26 551 minecraft:smooth_basalt
fill 117 26 511 117 29 511 minecraft:blackstone
fill 117 26 551 117 28 551 minecraft:blackstone
setblock 118 26 514 minecraft:smooth_basalt
setblock 119 26 513 minecraft:smooth_basalt
fill 119 26 514 119 27 514 minecraft:blackstone
setblock 120 26 512 minecraft:smooth_basalt
fill 120 26 513 120 28 513 minecraft:blackstone
setblock 121 26 511 minecraft:smooth_basalt
fill 121 26 512 121 29 512 minecraft:blackstone
setblock 121 26 551 minecraft:smooth_basalt
fill 122 26 511 122 29 511 minecraft:blackstone
setblock 122 26 551 minecraft:blackstone
setblock 124 26 513 minecraft:smooth_basalt
setblock 125 26 512 minecraft:smooth_basalt
setblock 126 26 511 minecraft:smooth_basalt
setblock 126 26 512 minecraft:blackstone
fill 127 26 511 127 28 511 minecraft:blackstone
setblock 130 26 512 minecraft:smooth_basalt
setblock 131 26 511 minecraft:smooth_basalt
fill 131 26 512 131 27 512 minecraft:blackstone
setblock 131 26 551 minecraft:smooth_basalt
fill 132 26 511 132 29 511 minecraft:blackstone
fill 132 26 551 132 29 551 minecraft:blackstone
setblock 133 26 514 minecraft:smooth_basalt
fill 133 26 515 133 27 515 minecraft:blackstone
setblock 134 26 513 minecraft:smooth_basalt
fill 134 26 514 134 29 514 minecraft:blackstone
setblock 134 26 517 minecraft:blackstone
setblock 134 26 518 minecraft:smooth_basalt
fill 134 26 519 134 29 519 minecraft:blackstone
fill 134 26 521 134 27 521 minecraft:blackstone
setblock 134 26 537 minecraft:blackstone
setblock 134 26 538 minecraft:smooth_basalt
fill 134 26 539 134 26 542 minecraft:blackstone
setblock 134 26 543 minecraft:smooth_basalt
fill 134 26 544 134 26 547 minecraft:blackstone
setblock 134 26 548 minecraft:smooth_basalt
fill 134 26 549 134 29 549 minecraft:blackstone
setblock 135 26 512 minecraft:smooth_basalt
fill 135 26 513 135 29 513 minecraft:blackstone
setblock 135 26 517 minecraft:smooth_basalt
fill 135 26 518 135 29 518 minecraft:blackstone
setblock 135 26 522 minecraft:smooth_basalt
fill 135 26 523 135 28 524 minecraft:blackstone
setblock 135 26 532 minecraft:smooth_basalt
fill 135 26 533 135 29 533 minecraft:blackstone
setblock 135 26 537 minecraft:smooth_basalt
fill 135 26 538 135 29 538 minecraft:blackstone
setblock 135 26 541 minecraft:blackstone
setblock 135 26 542 minecraft:smooth_basalt
fill 135 26 543 135 29 543 minecraft:blackstone
setblock 135 26 547 minecraft:smooth_basalt
fill 135 26 548 135 29 548 minecraft:blackstone
setblock 95 27 511 minecraft:smooth_basalt
fill 95 27 512 95 29 512 minecraft:blackstone
setblock 95 27 516 minecraft:smooth_basalt
fill 95 27 517 95 30 517 minecraft:blackstone
setblock 95 27 520 minecraft:blackstone
setblock 95 27 521 minecraft:smooth_basalt
fill 95 27 522 95 30 522 minecraft:blackstone
setblock 95 27 525 minecraft:blackstone
fill 95 27 526 96 27 526 minecraft:smooth_basalt
fill 95 27 527 95 30 527 minecraft:blackstone
setblock 95 27 531 minecraft:smooth_basalt
fill 95 27 532 95 30 532 minecraft:blackstone
setblock 95 27 536 minecraft:smooth_basalt
fill 95 27 537 95 30 537 minecraft:blackstone
setblock 95 27 541 minecraft:smooth_basalt
fill 95 27 542 95 30 542 minecraft:blackstone
setblock 95 27 546 minecraft:smooth_basalt
fill 95 27 547 95 30 547 minecraft:blackstone
setblock 95 27 551 minecraft:smooth_basalt
fill 96 27 511 96 28 511 minecraft:blackstone
setblock 96 27 515 minecraft:smooth_basalt
fill 96 27 516 96 29 516 minecraft:blackstone
setblock 96 27 519 minecraft:blackstone
setblock 96 27 520 minecraft:smooth_basalt
fill 96 27 521 96 30 521 minecraft:blackstone
setblock 96 27 524 minecraft:blackstone
fill 96 27 525 96 28 525 minecraft:smooth_basalt
fill 96 27 527 96 31 528 minecraft:smooth_basalt
fill 96 27 530 99 33 530 minecraft:smooth_basalt
fill 96 27 531 96 28 531 minecraft:blackstone
setblock 96 27 535 minecraft:smooth_basalt
fill 96 27 536 96 30 536 minecraft:blackstone
setblock 96 27 540 minecraft:smooth_basalt
fill 96 27 541 96 30 541 minecraft:blackstone
setblock 96 27 545 minecraft:smooth_basalt
fill 96 27 546 96 30 546 minecraft:blackstone
setblock 96 27 550 minecraft:smooth_basalt
fill 96 27 551 96 30 551 minecraft:blackstone
setblock 97 27 519 minecraft:smooth_basalt
fill 97 27 522 97 35 524 minecraft:smooth_basalt
fill 97 27 528 97 35 529 minecraft:smooth_basalt
setblock 97 27 534 minecraft:smooth_basalt
fill 97 27 535 97 29 535 minecraft:blackstone
setblock 97 27 539 minecraft:smooth_basalt
fill 97 27 540 97 30 540 minecraft:blackstone
setblock 97 27 543 minecraft:blackstone
setblock 97 27 544 minecraft:smooth_basalt
fill 97 27 545 97 30 545 minecraft:blackstone
fill 97 27 550 97 28 550 minecraft:blackstone
fill 98 27 522 98 45 523 minecraft:smooth_basalt
fill 98 27 529 98 45 529 minecraft:smooth_basalt
setblock 98 27 538 minecraft:smooth_basalt
fill 98 27 539 98 29 539 minecraft:blackstone
fill 98 27 541 98 28 541 minecraft:blackstone
setblock 98 27 543 minecraft:smooth_basalt
fill 98 27 544 98 28 544 minecraft:blackstone
fill 99 27 521 99 45 522 minecraft:smooth_basalt
fill 99 27 531 103 45 531 minecraft:smooth_basalt
setblock 100 27 511 minecraft:smooth_basalt
fill 100 27 521 103 45 521 minecraft:smooth_basalt
setblock 100 27 551 minecraft:smooth_basalt
fill 103 27 522 105 45 522 minecraft:smooth_basalt
fill 103 27 530 105 45 530 minecraft:smooth_basalt
fill 104 27 523 105 45 523 minecraft:smooth_basalt
fill 104 27 529 105 45 529 minecraft:smooth_basalt
fill 105 27 524 106 45 524 minecraft:smooth_basalt
fill 105 27 528 106 45 528 minecraft:smooth_basalt
fill 106 27 525 106 45 527 minecraft:smooth_basalt
fill 113 27 511 113 28 511 minecraft:blackstone
setblock 114 27 512 minecraft:smooth_basalt
setblock 115 27 511 minecraft:smooth_basalt
fill 115 27 512 115 30 512 minecraft:blackstone
fill 116 27 511 116 30 511 minecraft:blackstone
setblock 117 27 514 minecraft:smooth_basalt
setblock 118 27 513 minecraft:smooth_basalt
setblock 118 27 514 minecraft:blackstone
setblock 119 27 512 minecraft:smooth_basalt
fill 119 27 513 119 28 513 minecraft:blackstone
setblock 120 27 511 minecraft:smooth_basalt
fill 120 27 512 120 29 512 minecraft:blackstone
setblock 120 27 551 minecraft:smooth_basalt
fill 121 27 511 121 30 511 minecraft:blackstone
setblock 121 27 551 minecraft:blackstone
setblock 123 27 513 minecraft:smooth_basalt
setblock 124 27 512 minecraft:smooth_basalt
setblock 125 27 511 minecraft:smooth_basalt
setblock 125 27 512 minecraft:blackstone
fill 126 27 511 126 28 511 minecraft:blackstone
setblock 130 27 511 minecraft:smooth_basalt
fill 131 27 511 131 30 511 minecraft:blackstone
fill 131 27 551 131 30 551 minecraft:blackstone
fill 133 27 540 133 27 542 minecraft:blackstone
setblock 134 27 512 minecraft:smooth_basalt
fill 134 27 513 134 29 513 minecraft:blackstone
setblock 134 27 517 minecraft:smooth_basalt
fill 134 27 518 134 30 518 minecraft:blackstone
setblock 134 27 537 minecraft:smooth_basalt
fill 134 27 538 134 27 541 minecraft:blackstone
setblock 134 27 542 minecraft:smooth_basalt
fill 134 27 543 134 27 546 minecraft:blackstone
setblock 134 27 547 minecraft:smooth_basalt
fill 134 27 548 134 30 548 minecraft:blackstone
setblock 135 27 511 minecraft:smooth_basalt
fill 135 27 512 135 30 512 minecraft:blackstone
setblock 135 27 516 minecraft:smooth_basalt
fill 135 27 517 135 30 517 minecraft:blackstone
setblock 135 27 521 minecraft:smooth_basalt
fill 135 27 522 135 30 522 minecraft:blackstone
setblock 135 27 525 minecraft:blackstone
setblock 135 27 532 minecraft:blackstone
setblock 135 27 536 minecraft:smooth_basalt
fill 135 27 537 135 30 537 minecraft:blackstone
setblock 135 27 541 minecraft:smooth_basalt
fill 135 27 542 135 30 542 minecraft:blackstone
setblock 135 27 546 minecraft:smooth_basalt
fill 135 27 547 135 30 547 minecraft:blackstone
setblock 135 27 551 minecraft:smooth_basalt
setblock 95 28 511 minecraft:blackstone
setblock 95 28 515 minecraft:smooth_basalt
fill 95 28 516 95 31 516 minecraft:blackstone
setblock 95 28 520 minecraft:smooth_basalt
fill 95 28 521 95 31 521 minecraft:blackstone
setblock 95 28 525 minecraft:smooth_basalt
fill 95 28 526 95 31 526 minecraft:blackstone
setblock 95 28 530 minecraft:smooth_basalt
fill 95 28 531 95 31 531 minecraft:blackstone
setblock 95 28 535 minecraft:smooth_basalt
fill 95 28 536 95 31 536 minecraft:blackstone
setblock 95 28 540 minecraft:smooth_basalt
fill 95 28 541 95 31 541 minecraft:blackstone
setblock 95 28 545 minecraft:smooth_basalt
fill 95 28 546 95 31 546 minecraft:blackstone
setblock 95 28 550 minecraft:smooth_basalt
fill 95 28 551 95 31 551 minecraft:blackstone
setblock 96 28 514 minecraft:smooth_basalt
setblock 96 28 515 minecraft:blackstone
setblock 96 28 518 minecraft:blackstone
setblock 96 28 519 minecraft:smooth_basalt
fill 96 28 520 96 31 520 minecraft:blackstone
setblock 96 28 524 minecraft:smooth_basalt
fill 96 28 526 96 29 526 minecraft:smooth_basalt
fill 96 28 529 96 33 529 minecraft:smooth_basalt
setblock 96 28 534 minecraft:smooth_basalt
fill 96 28 535 96 31 535 minecraft:blackstone
setblock 96 28 539 minecraft:smooth_basalt
fill 96 28 540 96 31 540 minecraft:blackstone
setblock 96 28 544 minecraft:smooth_basalt
fill 96 28 545 96 31 545 minecraft:blackstone
setblock 96 28 549 minecraft:smooth_basalt
setblock 96 28 550 minecraft:blackstone
fill 97 28 521 98 44 521 minecraft:smooth_basalt
fill 97 28 531 98 38 531 minecraft:smooth_basalt
setblock 97 28 534 minecraft:blackstone
setblock 97 28 538 minecraft:smooth_basalt
fill 97 28 539 97 31 539 minecraft:blackstone
setblock 97 28 543 minecraft:smooth_basalt
fill 97 28 544 97 31 544 minecraft:blackstone
fill 98 28 520 104 44 520 minecraft:smooth_basalt
fill 98 28 532 104 44 532 minecraft:smooth_basalt
setblock 98 28 537 minecraft:smooth_basalt
fill 98 28 538 98 29 538 minecraft:blackstone
setblock 98 28 542 minecraft:smooth_basalt
fill 98 28 543 98 29 543 minecraft:blackstone
setblock 99 28 551 minecraft:smooth_basalt
fill 104 28 521 105 44 521 minecraft:smooth_basalt
fill 104 28 531 105 44 531 minecraft:smooth_basalt
fill 106 28 522 106 44 523 minecraft:smooth_basalt
fill 106 28 529 106 44 530 minecraft:smooth_basalt
fill 107 28 523 107 44 529 minecraft:smooth_basalt
setblock 114 28 511 minecraft:smooth_basalt
setblock 114 28 512 minecraft:blackstone
fill 115 28 511 115 31 511 minecraft:blackstone
setblock 117 28 513 minecraft:smooth_basalt
setblock 118 28 512 minecraft:smooth_basalt
fill 118 28 513 118 29 513 minecraft:blackstone
setblock 119 28 511 minecraft:smooth_basalt
fill 119 28 512 119 30 512 minecraft:blackstone
setblock 119 28 551 minecraft:smooth_basalt
fill 120 28 511 120 31 511 minecraft:blackstone
setblock 123 28 512 minecraft:smooth_basalt
setblock 124 28 511 minecraft:smooth_basalt
setblock 125 28 511 minecraft:blackstone
setblock 129 28 511 minecraft:smooth_basalt
fill 130 28 511 130 29 511 minecraft:blackstone
setblock 133 28 512 minecraft:smooth_basalt
fill 133 28 540 133 28 541 minecraft:blackstone
setblock 133 28 542 minecraft:smooth_basalt
fill 133 28 543 134 29 544 minecraft:blackstone
fill 133 28 550 133 29 550 minecraft:blackstone
setblock 134 28 511 minecraft:smooth_basalt
setblock 134 28 512 minecraft:blackstone
setblock 134 28 516 minecraft:smooth_basalt
fill 134 28 517 134 31 517 minecraft:blackstone
setblock 134 28 521 minecraft:smooth_basalt
fill 134 28 522 134 31 522 minecraft:blackstone
setblock 134 28 536 minecraft:smooth_basalt
fill 134 28 537 134 28 540 minecraft:blackstone
setblock 134 28 541 minecraft:smooth_basalt
fill 134 28 542 134 31 542 minecraft:blackstone
setblock 134 28 545 minecraft:blackstone
setblock 134 28 546 minecraft:smooth_basalt
fill 134 28 547 134 31 547 minecraft:blackstone
setblock 134 28 551 minecraft:smooth_basalt
fill 135 28 511 135 31 511 minecraft:blackstone
setblock 135 28 515 minecraft:smooth_basalt
fill 135 28 516 135 31 516 minecraft:blackstone
setblock 135 28 520 minecraft:smooth_basalt
fill 135 28 521 135 31 521 minecraft:blackstone
setblock 135 28 525 minecraft:smooth_basalt
setblock 135 28 535 minecraft:smooth_basalt
fill 135 28 536 135 31 536 minecraft:blackstone
setblock 135 28 540 minecraft:smooth_basalt
fill 135 28 541 135 31 541 minecraft:blackstone
setblock 135 28 545 minecraft:smooth_basalt
fill 135 28 546 135 31 546 minecraft:blackstone
setblock 135 28 550 minecraft:smooth_basalt
fill 135 28 551 135 31 551 minecraft:blackstone
setblock 95 29 514 minecraft:smooth_basalt
fill 95 29 515 95 31 515 minecraft:blackstone
setblock 95 29 519 minecraft:smooth_basalt
fill 95 29 520 95 32 520 minecraft:blackstone
setblock 95 29 523 minecraft:blackstone
setblock 95 29 524 minecraft:smooth_basalt
fill 95 29 525 96 31 525 minecraft:blackstone
setblock 95 29 529 minecraft:smooth_basalt
fill 95 29 530 95 32 530 minecraft:blackstone
setblock 95 29 534 minecraft:smooth_basalt
fill 95 29 535 95 32 535 minecraft:blackstone
setblock 95 29 539 minecraft:smooth_basalt
fill 95 29 540 95 32 540 minecraft:blackstone
setblock 95 29 544 minecraft:smooth_basalt
fill 95 29 545 95 32 545 minecraft:blackstone
setblock 95 29 549 minecraft:smooth_basalt
fill 95 29 550 95 32 550 minecraft:blackstone
setblock 96 29 518 minecraft:smooth_basalt
fill 96 29 519 96 31 519 minecraft:blackstone
setblock 96 29 523 minecraft:smooth_basalt
fill 96 29 524 96 32 524 minecraft:blackstone
fill 96 29 531 96 33 531 minecraft:smooth_basalt
setblock 96 29 533 minecraft:smooth_basalt
fill 96 29 534 96 32 534 minecraft:blackstone
setblock 96 29 538 minecraft:smooth_basalt
fill 96 29 539 96 32 539 minecraft:blackstone
setblock 96 29 543 minecraft:smooth_basalt
fill 96 29 544 96 32 544 minecraft:blackstone
setblock 96 29 548 minecraft:smooth_basalt
fill 96 29 549 96 32 549 minecraft:blackstone
fill 97 29 520 97 43 520 minecraft:smooth_basalt
fill 97 29 532 97 43 532 minecraft:smooth_basalt
setblock 97 29 537 minecraft:smooth_basalt
fill 97 29 538 97 32 538 minecraft:blackstone
setblock 97 29 542 minecraft:smooth_basalt
fill 97 29 543 97 32 543 minecraft:blackstone
fill 98 29 519 104 43 519 minecraft:smooth_basalt
fill 98 29 533 104 43 533 minecraft:smooth_basalt
setblock 98 29 541 minecraft:smooth_basalt
fill 98 29 542 98 30 542 minecraft:blackstone
fill 98 29 544 98 77 544 minecraft:smooth_basalt
setblock 98 29 551 minecraft:smooth_basalt
fill 105 29 520 105 43 520 minecraft:smooth_basalt
fill 105 29 532 105 43 532 minecraft:smooth_basalt
fill 106 29 521 106 43 521 minecraft:smooth_basalt
fill 106 29 531 106 43 531 minecraft:smooth_basalt
fill 107 29 522 107 43 522 minecraft:smooth_basalt
fill 107 29 530 107 43 530 minecraft:smooth_basalt
fill 108 29 523 108 43 529 minecraft:smooth_basalt
setblock 113 29 511 minecraft:smooth_basalt
fill 114 29 511 114 32 511 minecraft:blackstone
setblock 117 29 512 minecraft:smooth_basalt
setblock 117 29 513 minecraft:blackstone
setblock 118 29 511 minecraft:smooth_basalt
fill 118 29 512 118 30 512 minecraft:blackstone
fill 119 29 511 119 32 511 minecraft:blackstone
fill 119 29 513 120 29 513 minecraft:gilded_blackstone
setblock 123 29 511 minecraft:smooth_basalt
setblock 133 29 511 minecraft:smooth_basalt
setblock 133 29 540 minecraft:blackstone
setblock 133 29 541 minecraft:smooth_basalt
fill 133 29 542 133 32 542 minecraft:blackstone
setblock 133 29 545 minecraft:blackstone
setblock 133 29 551 minecraft:smooth_basalt
fill 134 29 511 134 32 511 minecraft:blackstone
setblock 134 29 515 minecraft:smooth_basalt
fill 134 29 516 134 30 516 minecraft:blackstone
setblock 134 29 520 minecraft:smooth_basalt
fill 134 29 521 134 32 521 minecraft:blackstone
fill 134 29 536 134 29 539 minecraft:blackstone
setblock 134 29 540 minecraft:smooth_basalt
fill 134 29 541 134 32 541 minecraft:blackstone
setblock 134 29 545 minecraft:smooth_basalt
fill 134 29 546 134 32 546 minecraft:blackstone
setblock 134 29 550 minecraft:smooth_basalt
fill 134 29 551 134 32 551 minecraft:blackstone
setblock 135 29 514 minecraft:smooth_basalt
fill 135 29 515 135 32 515 minecraft:blackstone
setblock 135 29 519 minecraft:smooth_basalt
fill 135 29 520 135 32 520 minecraft:blackstone
setblock 135 29 523 minecraft:blackstone
setblock 135 29 524 minecraft:smooth_basalt
fill 135 29 525 135 32 525 minecraft:blackstone
setblock 135 29 534 minecraft:smooth_basalt
fill 135 29 535 135 32 535 minecraft:blackstone
setblock 135 29 539 minecraft:smooth_basalt
fill 135 29 540 135 32 540 minecraft:blackstone
setblock 135 29 544 minecraft:smooth_basalt
fill 135 29 545 135 32 545 minecraft:blackstone
setblock 135 29 549 minecraft:smooth_basalt
fill 135 29 550 135 32 550 minecraft:blackstone
setblock 95 30 514 minecraft:blackstone
setblock 95 30 518 minecraft:smooth_basalt
fill 95 30 519 95 33 519 minecraft:blackstone
setblock 95 30 523 minecraft:smooth_basalt
fill 95 30 524 95 33 524 minecraft:blackstone
setblock 95 30 528 minecraft:smooth_basalt
fill 95 30 529 95 33 529 minecraft:blackstone
setblock 95 30 533 minecraft:smooth_basalt
fill 95 30 534 95 33 534 minecraft:blackstone
setblock 95 30 538 minecraft:smooth_basalt
fill 95 30 539 95 33 539 minecraft:blackstone
setblock 95 30 543 minecraft:smooth_basalt
fill 95 30 544 95 33 544 minecraft:blackstone
setblock 95 30 548 minecraft:smooth_basalt
fill 95 30 549 95 33 549 minecraft:blackstone
setblock 96 30 518 minecraft:blackstone
setblock 96 30 522 minecraft:smooth_basalt
fill 96 30 523 96 33 523 minecraft:blackstone
setblock 96 30 526 minecraft:blackstone
fill 96 30 532 96 35 532 minecraft:smooth_basalt
setblock 96 30 533 minecraft:blackstone
setblock 96 30 537 minecraft:smooth_basalt
fill 96 30 538 96 33 538 minecraft:blackstone
setblock 96 30 542 minecraft:smooth_basalt
fill 96 30 543 96 33 543 minecraft:blackstone
setblock 96 30 547 minecraft:smooth_basalt
fill 96 30 548 96 33 548 minecraft:blackstone
fill 97 30 519 97 42 519 minecraft:smooth_basalt
fill 97 30 533 97 42 533 minecraft:smooth_basalt
setblock 97 30 536 minecraft:smooth_basalt
fill 97 30 537 97 31 537 minecraft:blackstone
setblock 97 30 541 minecraft:smooth_basalt
fill 97 30 542 97 33 542 minecraft:blackstone
setblock 97 30 546 minecraft:smooth_basalt
setblock 97 30 551 minecraft:smooth_basalt
setblock 98 30 540 minecraft:smooth_basalt
setblock 98 30 541 minecraft:blackstone
fill 98 30 543 98 77 543 minecraft:smooth_basalt
fill 99 30 518 103 42 518 minecraft:smooth_basalt
fill 99 30 534 103 42 534 minecraft:smooth_basalt
fill 105 30 519 105 42 519 minecraft:smooth_basalt
fill 105 30 533 105 42 533 minecraft:smooth_basalt
fill 106 30 520 106 42 520 minecraft:smooth_basalt
fill 106 30 532 106 42 532 minecraft:smooth_basalt
fill 107 30 521 107 42 521 minecraft:smooth_basalt
fill 107 30 531 107 42 531 minecraft:smooth_basalt
fill 108 30 522 108 42 522 minecraft:smooth_basalt
fill 108 30 530 108 42 530 minecraft:smooth_basalt
fill 109 30 524 109 42 528 minecraft:smooth_basalt
fill 113 30 511 113 33 511 minecraft:blackstone
setblock 116 30 512 minecraft:smooth_basalt
setblock 117 30 511 minecraft:smooth_basalt
setblock 117 30 512 minecraft:blackstone
fill 118 30 511 118 33 511 minecraft:blackstone
setblock 132 30 511 minecraft:smooth_basalt
setblock 132 30 551 minecraft:smooth_basalt
fill 133 30 511 133 33 511 minecraft:blackstone
setblock 133 30 540 minecraft:smooth_basalt
fill 133 30 541 133 33 541 minecraft:blackstone
fill 133 30 543 133 30 544 minecraft:blackstone
setblock 133 30 545 minecraft:smooth_basalt
fill 133 30 546 133 33 546 minecraft:blackstone
setblock 133 30 550 minecraft:smooth_basalt
fill 133 30 551 133 33 551 minecraft:blackstone
setblock 134 30 515 minecraft:blackstone
setblock 134 30 519 minecraft:smooth_basalt
fill 134 30 520 134 33 520 minecraft:blackstone
fill 134 30 537 134 30 538 minecraft:blackstone
setblock 134 30 539 minecraft:smooth_basalt
fill 134 30 540 134 33 540 minecraft:blackstone
setblock 134 30 543 minecraft:blackstone
setblock 134 30 544 minecraft:smooth_basalt
fill 134 30 545 134 33 545 minecraft:blackstone
setblock 134 30 549 minecraft:smooth_basalt
fill 134 30 550 134 33 550 minecraft:blackstone
setblock 135 30 513 minecraft:smooth_basalt
fill 135 30 514 135 32 514 minecraft:blackstone
setblock 135 30 518 minecraft:smooth_basalt
fill 135 30 519 135 33 519 minecraft:blackstone
setblock 135 30 523 minecraft:smooth_basalt
fill 135 30 524 135 33 524 minecraft:blackstone
fill 135 30 526 135 31 526 minecraft:blackstone
fill 135 30 534 135 31 534 minecraft:blackstone
setblock 135 30 538 minecraft:smooth_basalt
fill 135 30 539 135 33 539 minecraft:blackstone
setblock 135 30 543 minecraft:smooth_basalt
fill 135 30 544 135 33 544 minecraft:blackstone
setblock 135 30 548 minecraft:smooth_basalt
fill 135 30 549 135 33 549 minecraft:blackstone
setblock 95 31 517 minecraft:smooth_basalt
fill 95 31 518 95 34 518 minecraft:blackstone
setblock 95 31 522 minecraft:smooth_basalt
fill 95 31 523 95 34 523 minecraft:blackstone
setblock 95 31 527 minecraft:smooth_basalt
fill 95 31 528 95 34 528 minecraft:blackstone
setblock 95 31 532 minecraft:smooth_basalt
fill 95 31 533 95 34 533 minecraft:blackstone
setblock 95 31 537 minecraft:smooth_basalt
fill 95 31 538 95 34 538 minecraft:blackstone
setblock 95 31 542 minecraft:smooth_basalt
fill 95 31 543 95 34 543 minecraft:blackstone
setblock 95 31 547 minecraft:smooth_basalt
fill 95 31 548 95 34 548 minecraft:blackstone
setblock 96 31 521 minecraft:smooth_basalt
fill 96 31 522 96 34 522 minecraft:blackstone
setblock 96 31 526 minecraft:smooth_basalt
fill 96 31 533 96 34 533 minecraft:smooth_basalt
setblock 96 31 536 minecraft:smooth_basalt
fill 96 31 537 96 34 537 minecraft:blackstone
setblock 96 31 541 minecraft:smooth_basalt
fill 96 31 542 96 34 542 minecraft:blackstone
setblock 96 31 546 minecraft:smooth_basalt
fill 96 31 547 96 34 547 minecraft:blackstone
setblock 96 31 551 minecraft:smooth_basalt
setblock 97 31 540 minecraft:smooth_basalt
fill 97 31 541 97 34 541 minecraft:blackstone
setblock 97 31 545 minecraft:smooth_basalt
fill 97 31 546 97 32 546 minecraft:blackstone
fill 98 31 518 98 41 518 minecraft:smooth_basalt
fill 98 31 534 98 41 534 minecraft:smooth_basalt
fill 98 31 541 98 77 542 minecraft:smooth_basalt
fill 104 31 518 104 41 518 minecraft:smooth_basalt
fill 104 31 534 104 41 534 minecraft:smooth_basalt
fill 106 31 519 106 41 519 minecraft:smooth_basalt
fill 106 31 533 106 41 533 minecraft:smooth_basalt
fill 107 31 520 107 41 520 minecraft:smooth_basalt
fill 107 31 532 107 41 532 minecraft:smooth_basalt
fill 108 31 521 108 41 521 minecraft:smooth_basalt
fill 108 31 531 108 41 531 minecraft:smooth_basalt
fill 109 31 523 109 41 523 minecraft:smooth_basalt
fill 109 31 529 109 41 529 minecraft:smooth_basalt
fill 110 31 523 110 31 524 minecraft:blackstone
fill 110 31 528 110 31 529 minecraft:blackstone
setblock 116 31 511 minecraft:smooth_basalt
fill 117 31 511 117 34 511 minecraft:blackstone
setblock 130 31 551 minecraft:blackstone
setblock 131 31 551 minecraft:smooth_basalt
fill 132 31 511 132 34 511 minecraft:blackstone
setblock 132 31 550 minecraft:smooth_basalt
fill 132 31 551 132 34 551 minecraft:blackstone
setblock 133 31 543 minecraft:blackstone
setblock 133 31 544 minecraft:smooth_basalt
fill 133 31 545 133 34 545 minecraft:blackstone
fill 133 31 547 133 32 547 minecraft:blackstone
fill 133 31 550 133 34 550 minecraft:blackstone
setblock 134 31 518 minecraft:smooth_basalt
fill 134 31 519 134 32 519 minecraft:blackstone
setblock 134 31 537 minecraft:blackstone
setblock 134 31 538 minecraft:smooth_basalt
fill 134 31 539 134 34 539 minecraft:blackstone
setblock 134 31 543 minecraft:smooth_basalt
fill 134 31 544 134 34 544 minecraft:blackstone
setblock 134 31 548 minecraft:smooth_basalt
fill 134 31 549 134 34 549 minecraft:blackstone
setblock 135 31 512 minecraft:smooth_basalt
fill 135 31 513 135 32 513 minecraft:blackstone
setblock 135 31 517 minecraft:smooth_basalt
fill 135 31 518 135 34 518 minecraft:blackstone
setblock 135 31 522 minecraft:smooth_basalt
fill 135 31 523 135 34 523 minecraft:blackstone
setblock 135 31 537 minecraft:smooth_basalt
fill 135 31 538 135 34 538 minecraft:blackstone
setblock 135 31 542 minecraft:smooth_basalt
fill 135 31 543 135 34 543 minecraft:blackstone
setblock 135 31 547 minecraft:smooth_basalt
fill 135 31 548 135 34 548 minecraft:blackstone
setblock 95 32 516 minecraft:smooth_basalt
fill 95 32 517 95 34 517 minecraft:blackstone
setblock 95 32 521 minecraft:smooth_basalt
fill 95 32 522 95 35 522 minecraft:blackstone
setblock 95 32 525 minecraft:blackstone
setblock 95 32 526 minecraft:smooth_basalt
fill 95 32 527 96 34 527 minecraft:blackstone
setblock 95 32 531 minecraft:smooth_basalt
fill 95 32 532 95 35 532 minecraft:blackstone
setblock 95 32 536 minecraft:smooth_basalt
fill 95 32 537 95 35 537 minecraft:blackstone
setblock 95 32 541 minecraft:smooth_basalt
fill 95 32 542 95 35 542 minecraft:blackstone
setblock 95 32 546 minecraft:smooth_basalt
fill 95 32 547 95 35 547 minecraft:blackstone
setblock 95 32 551 minecraft:smooth_basalt
fill 96 32 519 96 32 520 minecraft:smooth_basalt
fill 96 32 521 96 35 521 minecraft:blackstone
setblock 96 32 525 minecraft:smooth_basalt
fill 96 32 526 96 35 526 minecraft:blackstone
setblock 96 32 528 minecraft:smooth_basalt
setblock 96 32 535 minecraft:smooth_basalt
fill 96 32 536 96 35 536 minecraft:blackstone
setblock 96 32 540 minecraft:smooth_basalt
fill 96 32 541 96 35 541 minecraft:blackstone
setblock 96 32 545 minecraft:smooth_basalt
fill 96 32 546 96 35 546 minecraft:blackstone
fill 96 32 551 96 35 551 minecraft:blackstone
setblock 97 32 513 minecraft:light[level=12]
fill 97 32 518 97 40 518 minecraft:smooth_basalt
fill 97 32 534 97 40 534 minecraft:smooth_basalt
setblock 97 32 537 minecraft:light[level=12]
setblock 97 32 539 minecraft:smooth_basalt
fill 97 32 540 97 33 540 minecraft:blackstone
setblock 97 32 544 minecraft:smooth_basalt
fill 97 32 545 97 35 545 minecraft:blackstone
fill 99 32 517 103 40 517 minecraft:smooth_basalt
fill 99 32 535 103 40 535 minecraft:smooth_basalt
setblock 105 32 513 minecraft:light[level=12]
fill 105 32 518 105 40 518 minecraft:smooth_basalt
fill 105 32 534 105 40 534 minecraft:smooth_basalt
setblock 105 32 537 minecraft:light[level=12]
setblock 105 32 545 minecraft:light[level=12]
fill 106 32 540 107 33 541 minecraft:gold_block
fill 107 32 519 107 40 519 minecraft:smooth_basalt
fill 107 32 533 107 40 533 minecraft:smooth_basalt
fill 108 32 520 108 40 520 minecraft:smooth_basalt
fill 108 32 532 108 40 532 minecraft:smooth_basalt
fill 109 32 522 109 40 522 minecraft:smooth_basalt
fill 109 32 530 109 40 530 minecraft:smooth_basalt
setblock 110 32 523 minecraft:blackstone
fill 110 32 524 110 40 524 minecraft:smooth_basalt
fill 110 32 528 110 40 528 minecraft:smooth_basalt
setblock 110 32 529 minecraft:blackstone
setblock 113 32 513 minecraft:light[level=12]
setblock 113 32 521 minecraft:light[level=12]
setblock 113 32 529 minecraft:light[level=12]
setblock 113 32 537 minecraft:light[level=12]
setblock 113 32 545 minecraft:light[level=12]
setblock 115 32 511 minecraft:smooth_basalt
fill 116 32 511 116 35 511 minecraft:blackstone
setblock 121 32 513 minecraft:light[level=12]
setblock 121 32 521 minecraft:light[level=12]
setblock 121 32 529 minecraft:light[level=12]
setblock 121 32 537 minecraft:light[level=12]
setblock 121 32 545 minecraft:light[level=12]
setblock 129 32 513 minecraft:light[level=12]
setblock 129 32 521 minecraft:light[level=12]
setblock 129 32 529 minecraft:light[level=12]
setblock 129 32 537 minecraft:light[level=12]
setblock 129 32 545 minecraft:light[level=12]
setblock 129 32 551 minecraft:blackstone
setblock 130 32 551 minecraft:smooth_basalt
setblock 131 32 550 minecraft:smooth_basalt
fill 131 32 551 131 35 551 minecraft:blackstone
fill 132 32 550 132 35 550 minecraft:blackstone
setblock 133 32 543 minecraft:smooth_basalt
fill 133 32 544 133 35 544 minecraft:blackstone
setblock 133 32 548 minecraft:smooth_basalt
setblock 134 32 522 minecraft:smooth_basalt
fill 134 32 523 134 35 523 minecraft:blackstone
fill 134 32 538 134 35 538 minecraft:blackstone
setblock 134 32 542 minecraft:smooth_basalt
fill 134 32 543 134 35 543 minecraft:blackstone
setblock 134 32 547 minecraft:smooth_basalt
fill 134 32 548 134 35 548 minecraft:blackstone
setblock 135 32 511 minecraft:smooth_basalt
setblock 135 32 512 minecraft:blackstone
setblock 135 32 516 minecraft:smooth_basalt
fill 135 32 517 135 35 517 minecraft:blackstone
setblock 135 32 521 minecraft:smooth_basalt
fill 135 32 522 135 35 522 minecraft:blackstone
setblock 135 32 526 minecraft:smooth_basalt
fill 135 32 527 135 35 527 minecraft:blackstone
setblock 135 32 536 minecraft:smooth_basalt
fill 135 32 537 135 35 537 minecraft:blackstone
setblock 135 32 541 minecraft:smooth_basalt
fill 135 32 542 135 35 542 minecraft:blackstone
setblock 135 32 546 minecraft:smooth_basalt
fill 135 32 547 135 35 547 minecraft:blackstone
setblock 135 32 551 minecraft:smooth_basalt
setblock 95 33 520 minecraft:smooth_basalt
fill 95 33 521 95 36 521 minecraft:blackstone
setblock 95 33 525 minecraft:smooth_basalt
fill 95 33 526 95 36 526 minecraft:blackstone
setblock 95 33 530 minecraft:smooth_basalt
fill 95 33 531 95 36 531 minecraft:blackstone
setblock 95 33 535 minecraft:smooth_basalt
fill 95 33 536 95 36 536 minecraft:blackstone
setblock 95 33 540 minecraft:smooth_basalt
fill 95 33 541 95 36 541 minecraft:blackstone
setblock 95 33 545 minecraft:smooth_basalt
fill 95 33 546 95 36 546 minecraft:blackstone
setblock 95 33 550 minecraft:smooth_basalt
fill 95 33 551 95 36 551 minecraft:blackstone
fill 96 33 518 96 39 519 minecraft:smooth_basalt
fill 96 33 520 96 35 520 minecraft:blackstone
setblock 96 33 524 minecraft:smooth_basalt
fill 96 33 525 96 36 525 minecraft:blackstone
setblock 96 33 528 minecraft:blackstone
fill 96 33 534 96 35 534 minecraft:smooth_basalt
fill 96 33 535 96 36 535 minecraft:blackstone
setblock 96 33 539 minecraft:smooth_basalt
fill 96 33 540 96 36 540 minecraft:blackstone
setblock 96 33 544 minecraft:smooth_basalt
fill 96 33 545 96 36 545 minecraft:blackstone
setblock 96 33 549 minecraft:smooth_basalt
setblock 97 33 543 minecraft:smooth_basalt
fill 97 33 544 97 36 544 minecraft:blackstone
fill 98 33 517 98 39 517 minecraft:smooth_basalt
fill 98 33 535 98 39 535 minecraft:smooth_basalt
fill 104 33 517 104 39 517 minecraft:smooth_basalt
fill 104 33 535 104 39 535 minecraft:smooth_basalt
fill 106 33 518 106 39 518 minecraft:smooth_basalt
fill 106 33 534 106 39 534 minecraft:smooth_basalt
fill 109 33 521 109 39 521 minecraft:smooth_basalt
fill 109 33 531 109 39 531 minecraft:smooth_basalt
fill 110 33 523 110 39 523 minecraft:smooth_basalt
fill 110 33 529 110 39 529 minecraft:smooth_basalt
fill 112 33 511 112 34 511 minecraft:blackstone
setblock 114 33 511 minecraft:smooth_basalt
setblock 114 33 551 minecraft:smooth_basalt
fill 115 33 511 115 36 511 minecraft:blackstone
fill 115 33 551 117 34 551 minecraft:blackstone
setblock 119 33 511 minecraft:smooth_basalt
setblock 128 33 551 minecraft:blackstone
setblock 129 33 551 minecraft:smooth_basalt
setblock 130 33 550 minecraft:smooth_basalt
fill 130 33 551 130 36 551 minecraft:blackstone
fill 131 33 550 131 36 550 minecraft:blackstone
fill 132 33 549 133 35 549 minecraft:blackstone
setblock 133 33 542 minecraft:smooth_basalt
fill 133 33 543 133 36 543 minecraft:blackstone
setblock 133 33 547 minecraft:smooth_basalt
fill 133 33 548 133 36 548 minecraft:blackstone
setblock 134 33 511 minecraft:smooth_basalt
setblock 134 33 521 minecraft:smooth_basalt
fill 134 33 522 134 36 522 minecraft:blackstone
fill 134 33 524 134 34 524 minecraft:blackstone
setblock 134 33 541 minecraft:smooth_basalt
fill 134 33 542 134 36 542 minecraft:blackstone
setblock 134 33 546 minecraft:smooth_basalt
fill 134 33 547 134 36 547 minecraft:blackstone
setblock 134 33 551 minecraft:smooth_basalt
fill 135 33 511 135 36 511 minecraft:blackstone
setblock 135 33 515 minecraft:smooth_basalt
setblock 135 33 516 minecraft:blackstone
setblock 135 33 520 minecraft:smooth_basalt
fill 135 33 521 135 36 521 minecraft:blackstone
setblock 135 33 525 minecraft:smooth_basalt
fill 135 33 526 135 36 526 minecraft:blackstone
fill 135 33 528 135 33 529 minecraft:blackstone
setblock 135 33 534 minecraft:blackstone
setblock 135 33 535 minecraft:smooth_basalt
fill 135 33 536 135 36 536 minecraft:blackstone
setblock 135 33 540 minecraft:smooth_basalt
fill 135 33 541 135 36 541 minecraft:blackstone
setblock 135 33 545 minecraft:smooth_basalt
fill 135 33 546 135 36 546 minecraft:blackstone
setblock 135 33 550 minecraft:smooth_basalt
fill 135 33 551 135 36 551 minecraft:blackstone
setblock 95 34 519 minecraft:smooth_basalt
fill 95 34 520 95 37 520 minecraft:blackstone
setblock 95 34 524 minecraft:smooth_basalt
fill 95 34 525 95 37 525 minecraft:blackstone
setblock 95 34 529 minecraft:smooth_basalt
fill 95 34 530 96 36 530 minecraft:blackstone
setblock 95 34 534 minecraft:smooth_basalt
fill 95 34 535 95 37 535 minecraft:blackstone
setblock 95 34 539 minecraft:smooth_basalt
fill 95 34 540 95 37 540 minecraft:blackstone
setblock 95 34 544 minecraft:smooth_basalt
fill 95 34 545 95 37 545 minecraft:blackstone
setblock 95 34 549 minecraft:smooth_basalt
fill 95 34 550 95 37 550 minecraft:blackstone
setblock 96 34 523 minecraft:smooth_basalt
fill 96 34 524 96 37 524 minecraft:blackstone
setblock 96 34 528 minecraft:smooth_basalt
fill 96 34 529 96 37 529 minecraft:blackstone
fill 96 34 531 96 35 531 minecraft:blackstone
setblock 96 34 538 minecraft:smooth_basalt
fill 96 34 539 96 37 539 minecraft:blackstone
setblock 96 34 543 minecraft:smooth_basalt
fill 96 34 544 96 37 544 minecraft:blackstone
setblock 96 34 548 minecraft:smooth_basalt
fill 96 34 549 96 37 549 minecraft:blackstone
fill 97 34 530 99 37 530 minecraft:smooth_basalt
setblock 97 34 542 minecraft:smooth_basalt
fill 97 34 543 97 35 543 minecraft:blackstone
fill 111 34 511 111 35 511 minecraft:blackstone
setblock 112 34 551 minecraft:blackstone
setblock 113 34 511 minecraft:smooth_basalt
setblock 113 34 551 minecraft:smooth_basalt
fill 114 34 511 114 37 511 minecraft:blackstone
fill 114 34 551 114 37 551 minecraft:blackstone
setblock 118 34 511 minecraft:smooth_basalt
setblock 118 34 551 minecraft:smooth_basalt
fill 119 34 511 119 37 511 minecraft:blackstone
fill 126 34 551 127 34 551 minecraft:blackstone
setblock 128 34 551 minecraft:smooth_basalt
setblock 129 34 550 minecraft:smooth_basalt
fill 129 34 551 129 37 551 minecraft:blackstone
fill 130 34 511 131 35 511 minecraft:blackstone
fill 130 34 550 130 37 550 minecraft:blackstone
fill 131 34 549 131 37 549 minecraft:blackstone
fill 132 34 544 132 34 546 minecraft:blackstone
setblock 132 34 547 minecraft:smooth_basalt
setblock 133 34 511 minecraft:smooth_basalt
setblock 133 34 540 minecraft:blackstone
setblock 133 34 541 minecraft:smooth_basalt
fill 133 34 542 133 37 542 minecraft:blackstone
setblock 133 34 546 minecraft:smooth_basalt
fill 133 34 547 133 37 547 minecraft:blackstone
setblock 133 34 551 minecraft:smooth_basalt
fill 134 34 511 134 37 511 minecraft:blackstone
setblock 134 34 520 minecraft:smooth_basalt
fill 134 34 521 134 37 521 minecraft:blackstone
setblock 134 34 525 minecraft:smooth_basalt
setblock 134 34 540 minecraft:smooth_basalt
fill 134 34 541 134 37 541 minecraft:blackstone
setblock 134 34 545 minecraft:smooth_basalt
fill 134 34 546 134 37 546 minecraft:blackstone
setblock 134 34 550 minecraft:smooth_basalt
fill 134 34 551 134 37 551 minecraft:blackstone
setblock 135 34 519 minecraft:smooth_basalt
fill 135 34 520 135 37 520 minecraft:blackstone
setblock 135 34 524 minecraft:smooth_basalt
fill 135 34 525 135 37 525 minecraft:blackstone
setblock 135 34 528 minecraft:blackstone
setblock 135 34 529 minecraft:smooth_basalt
fill 135 34 530 135 34 533 minecraft:blackstone
setblock 135 34 534 minecraft:smooth_basalt
fill 135 34 535 135 37 535 minecraft:blackstone
setblock 135 34 539 minecraft:smooth_basalt
fill 135 34 540 135 37 540 minecraft:blackstone
setblock 135 34 544 minecraft:smooth_basalt
fill 135 34 545 135 37 545 minecraft:blackstone
setblock 135 34 549 minecraft:smooth_basalt
fill 135 34 550 135 37 550 minecraft:blackstone
setblock 95 35 518 minecraft:smooth_basalt
fill 95 35 519 95 38 519 minecraft:blackstone
setblock 95 35 523 minecraft:smooth_basalt
fill 95 35 524 95 38 524 minecraft:blackstone
setblock 95 35 527 minecraft:blackstone
setblock 95 35 528 minecraft:smooth_basalt
fill 95 35 529 95 38 529 minecraft:blackstone
setblock 95 35 533 minecraft:smooth_basalt
fill 95 35 534 95 38 534 minecraft:blackstone
setblock 95 35 538 minecraft:smooth_basalt
fill 95 35 539 95 38 539 minecraft:blackstone
setblock 95 35 543 minecraft:smooth_basalt
fill 95 35 544 95 38 544 minecraft:blackstone
setblock 95 35 548 minecraft:smooth_basalt
fill 95 35 549 95 38 549 minecraft:blackstone
setblock 96 35 522 minecraft:smooth_basalt
fill 96 35 523 96 38 523 minecraft:blackstone
fill 96 35 527 100 35 527 minecraft:smooth_basalt
fill 96 35 528 96 38 528 minecraft:blackstone
fill 96 35 533 96 38 533 minecraft:blackstone
setblock 96 35 537 minecraft:smooth_basalt
fill 96 35 538 96 38 538 minecraft:blackstone
setblock 96 35 542 minecraft:smooth_basalt
fill 96 35 543 96 38 543 minecraft:blackstone
setblock 96 35 547 minecraft:smooth_basalt
fill 96 35 548 96 38 548 minecraft:blackstone
fill 97 35 517 97 37 517 minecraft:smooth_basalt
setblock 97 35 525 minecraft:blackstone
fill 97 35 526 100 35 526 minecraft:smooth_basalt
fill 97 35 535 97 37 535 minecraft:smooth_basalt
fill 97 35 541 97 77 541 minecraft:smooth_basalt
setblock 97 35 542 minecraft:blackstone
setblock 97 35 551 minecraft:smooth_basalt
fill 98 35 525 100 46 525 minecraft:smooth_basalt
fill 105 35 517 105 37 517 minecraft:smooth_basalt
fill 105 35 535 105 37 535 minecraft:smooth_basalt
fill 108 35 519 108 37 519 minecraft:smooth_basalt
fill 108 35 533 108 37 533 minecraft:smooth_basalt
fill 110 35 511 110 36 511 minecraft:blackstone
fill 110 35 522 110 37 522 minecraft:smooth_basalt
fill 110 35 530 110 37 530 minecraft:smooth_basalt
fill 110 35 551 111 35 551 minecraft:blackstone
setblock 112 35 511 minecraft:smooth_basalt
setblock 112 35 551 minecraft:smooth_basalt
fill 113 35 511 113 37 512 minecraft:blackstone
setblock 113 35 550 minecraft:smooth_basalt
fill 113 35 551 113 38 551 minecraft:blackstone
fill 114 35 512 115 35 512 minecraft:blackstone
fill 114 35 550 116 36 550 minecraft:blackstone
fill 115 35 551 116 35 551 minecraft:blackstone
setblock 117 35 511 minecraft:smooth_basalt
setblock 117 35 551 minecraft:smooth_basalt
fill 118 35 511 118 38 511 minecraft:blackstone
fill 118 35 551 121 35 551 minecraft:blackstone
fill 124 35 551 126 35 551 minecraft:blackstone
setblock 127 35 550 minecraft:blackstone
setblock 127 35 551 minecraft:smooth_basalt
fill 128 35 511 129 37 511 minecraft:blackstone
setblock 128 35 550 minecraft:smooth_basalt
fill 128 35 551 128 38 551 minecraft:blackstone
setblock 129 35 549 minecraft:smooth_basalt
fill 129 35 550 129 38 550 minecraft:blackstone
fill 130 35 549 130 38 549 minecraft:blackstone
fill 131 35 548 132 37 548 minecraft:blackstone
setblock 132 35 511 minecraft:smooth_basalt
fill 132 35 543 132 35 545 minecraft:blackstone
setblock 132 35 546 minecraft:smooth_basalt
fill 132 35 547 132 38 547 minecraft:blackstone
setblock 132 35 551 minecraft:smooth_basalt
fill 133 35 511 133 38 511 minecraft:blackstone
setblock 133 35 540 minecraft:smooth_basalt
fill 133 35 541 133 38 541 minecraft:blackstone
setblock 133 35 545 minecraft:smooth_basalt
fill 133 35 546 133 38 546 minecraft:blackstone
setblock 133 35 550 minecraft:smooth_basalt
fill 133 35 551 133 38 551 minecraft:blackstone
setblock 134 35 524 minecraft:smooth_basalt
fill 134 35 525 134 35 528 minecraft:blackstone
fill 134 35 537 134 36 537 minecraft:blackstone
setblock 134 35 539 minecraft:smooth_basalt
fill 134 35 540 134 38 540 minecraft:blackstone
setblock 134 35 544 minecraft:smooth_basalt
fill 134 35 545 134 38 545 minecraft:blackstone
setblock 134 35 549 minecraft:smooth_basalt
fill 134 35 550 134 38 550 minecraft:blackstone
setblock 135 35 518 minecraft:smooth_basalt
fill 135 35 519 135 38 519 minecraft:blackstone
setblock 135 35 523 minecraft:smooth_basalt
fill 135 35 524 135 38 524 minecraft:blackstone
setblock 135 35 528 minecraft:smooth_basalt
fill 135 35 529 135 35 532 minecraft:blackstone
setblock 135 35 533 minecraft:smooth_basalt
fill 135 35 534 135 38 534 minecraft:blackstone
setblock 135 35 538 minecraft:smooth_basalt
fill 135 35 539 135 38 539 minecraft:blackstone
setblock 135 35 543 minecraft:smooth_basalt
fill 135 35 544 135 38 544 minecraft:blackstone
setblock 135 35 548 minecraft:smooth_basalt
fill 135 35 549 135 38 549 minecraft:blackstone
fill 95 36 518 95 38 518 minecraft:blackstone
setblock 95 36 522 minecraft:smooth_basalt
fill 95 36 523 95 39 523 minecraft:blackstone
setblock 95 36 527 minecraft:smooth_basalt
fill 95 36 528 95 39 528 minecraft:blackstone
setblock 95 36 532 minecraft:smooth_basalt
fill 95 36 533 95 39 533 minecraft:blackstone
setblock 95 36 537 minecraft:smooth_basalt
fill 95 36 538 95 39 538 minecraft:blackstone
setblock 95 36 542 minecraft:smooth_basalt
fill 95 36 543 95 39 543 minecraft:blackstone
setblock 95 36 547 minecraft:smooth_basalt
fill 95 36 548 95 39 548 minecraft:blackstone
fill 96 36 520 96 36 521 minecraft:smooth_basalt
fill 96 36 522 96 39 522 minecraft:blackstone
setblock 96 36 526 minecraft:smooth_basalt
fill 96 36 527 97 38 527 minecraft:blackstone
setblock 96 36 531 minecraft:smooth_basalt
fill 96 36 532 96 39 532 minecraft:blackstone
fill 96 36 534 96 37 534 minecraft:blackstone
setblock 96 36 536 minecraft:smooth_basalt
fill 96 36 537 96 38 537 minecraft:blackstone
setblock 96 36 541 minecraft:smooth_basalt
fill 96 36 542 96 39 542 minecraft:blackstone
setblock 96 36 546 minecraft:smooth_basalt
fill 96 36 547 96 39 547 minecraft:blackstone
setblock 96 36 550 minecraft:blackstone
setblock 96 36 551 minecraft:smooth_basalt
fill 97 36 522 97 45 523 minecraft:smooth_basalt
setblock 97 36 524 minecraft:blackstone
setblock 97 36 525 minecraft:smooth_basalt
fill 97 36 526 97 39 526 minecraft:blackstone
fill 97 36 528 97 37 528 minecraft:blackstone
fill 97 36 529 97 37 529 minecraft:smooth_basalt
fill 97 36 542 97 77 543 minecraft:smooth_basalt
fill 97 36 545 97 64 545 minecraft:smooth_basalt
fill 97 36 551 97 39 551 minecraft:blackstone
fill 98 36 526 100 46 527 minecraft:smooth_basalt
setblock 101 36 516 minecraft:smooth_basalt
setblock 101 36 536 minecraft:smooth_basalt
setblock 107 36 518 minecraft:smooth_basalt
setblock 107 36 534 minecraft:smooth_basalt
fill 109 36 511 109 37 511 minecraft:blackstone
setblock 109 36 520 minecraft:smooth_basalt
setblock 109 36 532 minecraft:smooth_basalt
fill 109 36 551 110 36 551 minecraft:blackstone
setblock 111 36 511 minecraft:smooth_basalt
fill 111 36 512 112 38 512 minecraft:blackstone
setblock 111 36 550 minecraft:blackstone
setblock 111 36 551 minecraft:smooth_basalt
fill 112 36 511 112 39 511 minecraft:blackstone
setblock 112 36 550 minecraft:smooth_basalt
fill 112 36 551 112 39 551 minecraft:blackstone
fill 113 36 550 113 39 550 minecraft:blackstone
setblock 114 36 512 minecraft:blackstone
setblock 115 36 512 minecraft:smooth_basalt
setblock 115 36 551 minecraft:blackstone
setblock 116 36 511 minecraft:smooth_basalt
fill 116 36 512 116 39 512 minecraft:blackstone
setblock 116 36 551 minecraft:smooth_basalt
fill 117 36 511 117 39 511 minecraft:blackstone
setblock 117 36 550 minecraft:smooth_basalt
fill 117 36 551 120 36 551 minecraft:blackstone
fill 118 36 550 118 39 550 minecraft:blackstone
setblock 120 36 511 minecraft:blackstone
setblock 121 36 551 minecraft:smooth_basalt
fill 122 36 535 123 37 535 minecraft:gold_block
fill 122 36 551 125 36 551 minecraft:blackstone
fill 125 36 550 126 36 550 minecraft:blackstone
setblock 126 36 511 minecraft:smooth_basalt
setblock 126 36 551 minecraft:smooth_basalt
fill 127 36 511 127 39 511 minecraft:blackstone
setblock 127 36 549 minecraft:blackstone
setblock 127 36 550 minecraft:smooth_basalt
fill 127 36 551 127 39 551 minecraft:blackstone
setblock 128 36 549 minecraft:smooth_basalt
fill 128 36 550 128 39 550 minecraft:blackstone
setblock 129 36 548 minecraft:smooth_basalt
fill 129 36 549 129 39 549 minecraft:blackstone
setblock 130 36 511 minecraft:blackstone
fill 130 36 548 130 39 548 minecraft:blackstone
setblock 131 36 511 minecraft:smooth_basalt
setblock 131 36 551 minecraft:smooth_basalt
fill 132 36 511 132 39 511 minecraft:blackstone
fill 132 36 543 132 36 544 minecraft:blackstone
setblock 132 36 545 minecraft:smooth_basalt
fill 132 36 546 132 39 546 minecraft:blackstone
setblock 132 36 549 minecraft:blackstone
setblock 132 36 550 minecraft:smooth_basalt
fill 132 36 551 132 39 551 minecraft:blackstone
fill 133 36 540 133 39 540 minecraft:blackstone
setblock 133 36 544 minecraft:smooth_basalt
fill 133 36 545 133 39 545 minecraft:blackstone
setblock 133 36 549 minecraft:smooth_basalt
fill 133 36 550 133 39 550 minecraft:blackstone
setblock 134 36 523 minecraft:smooth_basalt
fill 134 36 524 134 36 527 minecraft:blackstone
setblock 134 36 528 minecraft:smooth_basalt
fill 134 36 529 135 37 530 minecraft:blackstone
setblock 134 36 538 minecraft:smooth_basalt
fill 134 36 539 134 39 539 minecraft:blackstone
setblock 134 36 543 minecraft:smooth_basalt
fill 134 36 544 134 39 544 minecraft:blackstone
setblock 134 36 548 minecraft:smooth_basalt
fill 134 36 549 134 39 549 minecraft:blackstone
setblock 135 36 512 minecraft:smooth_basalt
setblock 135 36 518 minecraft:blackstone
setblock 135 36 522 minecraft:smooth_basalt
fill 135 36 523 135 39 523 minecraft:blackstone
setblock 135 36 527 minecraft:smooth_basalt
fill 135 36 528 135 39 528 minecraft:blackstone
setblock 135 36 531 minecraft:blackstone
setblock 135 36 532 minecraft:smooth_basalt
fill 135 36 533 135 39 533 minecraft:blackstone
setblock 135 36 537 minecraft:smooth_basalt
fill 135 36 538 135 39 538 minecraft:blackstone
setblock 135 36 542 minecraft:smooth_basalt
fill 135 36 543 135 39 543 minecraft:blackstone
setblock 135 36 547 minecraft:smooth_basalt
fill 135 36 548 135 39 548 minecraft:blackstone
setblock 95 37 521 minecraft:smooth_basalt
fill 95 37 522 95 40 522 minecraft:blackstone
setblock 95 37 526 minecraft:smooth_basalt
fill 95 37 527 95 40 527 minecraft:blackstone
setblock 95 37 530 minecraft:blackstone
setblock 95 37 531 minecraft:smooth_basalt
fill 95 37 532 95 40 532 minecraft:blackstone
setblock 95 37 536 minecraft:smooth_basalt
fill 95 37 537 95 40 537 minecraft:blackstone
setblock 95 37 541 minecraft:smooth_basalt
fill 95 37 542 95 40 542 minecraft:blackstone
setblock 95 37 546 minecraft:smooth_basalt
fill 95 37 547 95 40 547 minecraft:blackstone
setblock 95 37 551 minecraft:smooth_basalt
fill 96 37 520 96 42 520 minecraft:smooth_basalt
fill 96 37 521 96 38 521 minecraft:blackstone
setblock 96 37 525 minecraft:smooth_basalt
fill 96 37 526 96 40 526 minecraft:blackstone
setblock 96 37 530 minecraft:smooth_basalt
fill 96 37 531 96 40 531 minecraft:blackstone
setblock 96 37 535 minecraft:smooth_basalt
fill 96 37 536 96 39 536 minecraft:blackstone
setblock 96 37 540 minecraft:smooth_basalt
fill 96 37 541 96 39 541 minecraft:blackstone
setblock 96 37 545 minecraft:smooth_basalt
fill 96 37 546 96 40 546 minecraft:blackstone
setblock 96 37 550 minecraft:smooth_basalt
fill 96 37 551 96 40 551 minecraft:blackstone
setblock 97 37 524 minecraft:smooth_basalt
fill 97 37 525 97 40 525 minecraft:blackstone
fill 97 37 544 97 65 544 minecraft:smooth_basalt
fill 98 37 551 98 38 551 minecraft:blackstone
fill 107 37 511 108 38 511 minecraft:blackstone
fill 107 37 516 108 38 517 minecraft:gold_block
fill 107 37 551 109 37 551 minecraft:blackstone
fill 109 37 550 110 37 550 minecraft:blackstone
setblock 110 37 511 minecraft:smooth_basalt
fill 110 37 512 110 40 512 minecraft:blackstone
fill 110 37 521 110 39 521 minecraft:shroomlight
fill 110 37 531 110 39 531 minecraft:shroomlight
setblock 110 37 551 minecraft:smooth_basalt
fill 111 37 511 111 40 511 minecraft:blackstone
setblock 111 37 550 minecraft:smooth_basalt
fill 111 37 551 111 40 551 minecraft:blackstone
setblock 112 37 549 minecraft:smooth_basalt
fill 112 37 550 112 40 550 minecraft:blackstone
fill 113 37 549 115 38 549 minecraft:blackstone
setblock 114 37 512 minecraft:smooth_basalt
fill 114 37 550 115 37 550 minecraft:blackstone
setblock 115 37 511 minecraft:smooth_basalt
fill 115 37 512 115 40 512 minecraft:blackstone
setblock 115 37 551 minecraft:smooth_basalt
fill 116 37 511 116 40 511 minecraft:blackstone
setblock 116 37 550 minecraft:smooth_basalt
fill 116 37 551 119 37 551 minecraft:blackstone
fill 117 37 512 117 38 512 minecraft:blackstone
fill 117 37 550 117 40 550 minecraft:blackstone
fill 119 37 550 120 37 550 minecraft:blackstone
setblock 120 37 511 minecraft:smooth_basalt
setblock 120 37 551 minecraft:smooth_basalt
fill 121 37 511 124 37 511 minecraft:blackstone
setblock 121 37 550 minecraft:smooth_basalt
fill 121 37 551 124 37 551 minecraft:blackstone
fill 122 37 550 125 37 550 minecraft:blackstone
setblock 125 37 511 minecraft:smooth_basalt
setblock 125 37 551 minecraft:smooth_basalt
fill 126 37 511 126 40 511 minecraft:blackstone
setblock 126 37 549 minecraft:blackstone
setblock 126 37 550 minecraft:smooth_basalt
fill 126 37 551 126 40 551 minecraft:blackstone
setblock 127 37 549 minecraft:smooth_basalt
fill 127 37 550 127 40 550 minecraft:blackstone
setblock 128 37 548 minecraft:smooth_basalt
fill 128 37 549 128 40 549 minecraft:blackstone
fill 129 37 548 129 40 548 minecraft:blackstone
setblock 130 37 511 minecraft:smooth_basalt
setblock 130 37 551 minecraft:smooth_basalt
fill 131 37 511 131 40 511 minecraft:blackstone
fill 131 37 546 131 39 547 minecraft:blackstone
setblock 131 37 550 minecraft:smooth_basalt
fill 131 37 551 131 40 551 minecraft:blackstone
fill 132 37 542 132 37 543 minecraft:blackstone
setblock 132 37 544 minecraft:smooth_basalt
fill 132 37 545 132 40 545 minecraft:blackstone
setblock 132 37 549 minecraft:smooth_basalt
fill 132 37 550 132 40 550 minecraft:blackstone
fill 133 37 525 133 37 527 minecraft:blackstone
setblock 133 37 543 minecraft:smooth_basalt
fill 133 37 544 133 40 544 minecraft:blackstone
setblock 133 37 548 minecraft:smooth_basalt
fill 133 37 549 133 40 549 minecraft:blackstone
setblock 134 37 522 minecraft:smooth_basalt
fill 134 37 523 134 37 526 minecraft:blackstone
setblock 134 37 527 minecraft:smooth_basalt
fill 134 37 528 134 40 528 minecraft:blackstone
setblock 134 37 531 minecraft:blackstone
setblock 134 37 532 minecraft:smooth_basalt
fill 134 37 533 134 37 536 minecraft:blackstone
setblock 134 37 537 minecraft:smooth_basalt
fill 134 37 538 134 40 538 minecraft:blackstone
setblock 134 37 542 minecraft:smooth_basalt
fill 134 37 543 134 40 543 minecraft:blackstone
setblock 134 37 547 minecraft:smooth_basalt
fill 134 37 548 134 40 548 minecraft:blackstone
setblock 135 37 511 minecraft:smooth_basalt
fill 135 37 512 135 40 512 minecraft:blackstone
setblock 135 37 521 minecraft:smooth_basalt
fill 135 37 522 135 40 522 minecraft:blackstone
setblock 135 37 526 minecraft:smooth_basalt
fill 135 37 527 135 40 527 minecraft:blackstone
setblock 135 37 531 minecraft:smooth_basalt
fill 135 37 532 135 40 532 minecraft:blackstone
setblock 135 37 536 minecraft:smooth_basalt
fill 135 37 537 135 40 537 minecraft:blackstone
setblock 135 37 541 minecraft:smooth_basalt
fill 135 37 542 135 40 542 minecraft:blackstone
setblock 135 37 546 minecraft:smooth_basalt
fill 135 37 547 135 40 547 minecraft:blackstone
setblock 135 37 551 minecraft:smooth_basalt
setblock 95 38 520 minecraft:smooth_basalt
fill 95 38 521 95 41 521 minecraft:blackstone
setblock 95 38 525 minecraft:smooth_basalt
fill 95 38 526 95 41 526 minecraft:blackstone
setblock 95 38 530 minecraft:smooth_basalt
fill 95 38 531 95 41 531 minecraft:blackstone
setblock 95 38 535 minecraft:smooth_basalt
fill 95 38 536 95 41 536 minecraft:blackstone
setblock 95 38 540 minecraft:smooth_basalt
fill 95 38 541 95 41 541 minecraft:blackstone
setblock 95 38 545 minecraft:smooth_basalt
fill 95 38 546 95 41 546 minecraft:blackstone
setblock 95 38 550 minecraft:smooth_basalt
fill 95 38 551 95 41 551 minecraft:blackstone
setblock 96 38 524 minecraft:smooth_basalt
fill 96 38 525 96 41 525 minecraft:blackstone
setblock 96 38 529 minecraft:smooth_basalt
fill 96 38 530 97 40 530 minecraft:blackstone
setblock 96 38 534 minecraft:smooth_basalt
fill 96 38 535 96 41 535 minecraft:blackstone
setblock 96 38 539 minecraft:smooth_basalt
setblock 96 38 540 minecraft:blackstone
setblock 96 38 544 minecraft:smooth_basalt
fill 96 38 545 96 40 545 minecraft:blackstone
setblock 96 38 549 minecraft:smooth_basalt
fill 96 38 550 96 40 550 minecraft:blackstone
fill 97 38 524 97 39 524 minecraft:blackstone
setblock 97 38 528 minecraft:smooth_basalt
fill 97 38 529 97 41 529 minecraft:blackstone
fill 98 38 530 99 45 530 minecraft:smooth_basalt
fill 105 38 551 108 38 551 minecraft:blackstone
fill 106 38 511 106 40 511 minecraft:blackstone
fill 107 38 550 109 38 550 minecraft:blackstone
setblock 108 38 512 minecraft:smooth_basalt
setblock 109 38 511 minecraft:smooth_basalt
fill 109 38 512 109 41 512 minecraft:blackstone
setblock 109 38 520 minecraft:shroomlight
setblock 109 38 532 minecraft:shroomlight
setblock 109 38 551 minecraft:smooth_basalt
fill 110 38 511 110 41 511 minecraft:blackstone
fill 110 38 522 111 38 522 minecraft:shroomlight
fill 110 38 530 111 38 530 minecraft:shroomlight
setblock 110 38 549 minecraft:blackstone
setblock 110 38 550 minecraft:smooth_basalt
fill 110 38 551 110 41 551 minecraft:blackstone
setblock 111 38 513 minecraft:blackstone
setblock 111 38 523 minecraft:shroomlight
setblock 111 38 529 minecraft:shroomlight
setblock 111 38 549 minecraft:smooth_basalt
fill 111 38 550 111 41 550 minecraft:blackstone
setblock 112 38 513 minecraft:smooth_basalt
fill 112 38 549 112 41 549 minecraft:blackstone
setblock 113 38 511 minecraft:blackstone
setblock 113 38 512 minecraft:smooth_basalt
fill 113 38 513 113 41 513 minecraft:blackstone
setblock 114 38 511 minecraft:smooth_basalt
fill 114 38 512 114 41 512 minecraft:blackstone
setblock 114 38 550 minecraft:blackstone
setblock 114 38 551 minecraft:smooth_basalt
fill 115 38 511 115 41 511 minecraft:blackstone
setblock 115 38 550 minecraft:smooth_basalt
fill 115 38 551 118 38 551 minecraft:blackstone
setblock 116 38 549 minecraft:smooth_basalt
fill 116 38 550 116 41 550 minecraft:blackstone
setblock 119 38 511 minecraft:smooth_basalt
setblock 119 38 550 minecraft:blackstone
setblock 119 38 551 minecraft:smooth_basalt
fill 120 38 511 123 38 511 minecraft:blackstone
setblock 120 38 550 minecraft:smooth_basalt
fill 120 38 551 123 38 551 minecraft:blackstone
fill 121 38 550 124 38 550 minecraft:blackstone
setblock 124 38 511 minecraft:smooth_basalt
fill 124 38 549 125 38 549 minecraft:blackstone
setblock 124 38 551 minecraft:smooth_basalt
fill 125 38 511 125 41 511 minecraft:blackstone
setblock 125 38 550 minecraft:smooth_basalt
fill 125 38 551 125 41 551 minecraft:blackstone
setblock 126 38 549 minecraft:smooth_basalt
fill 126 38 550 126 41 550 minecraft:blackstone
setblock 127 38 548 minecraft:smooth_basalt
fill 127 38 549 127 41 549 minecraft:blackstone
setblock 128 38 511 minecraft:blackstone
setblock 128 38 512 minecraft:smooth_basalt
fill 128 38 548 128 41 548 minecraft:blackstone
setblock 129 38 511 minecraft:smooth_basalt
fill 129 38 512 132 38 512 minecraft:blackstone
setblock 129 38 551 minecraft:smooth_basalt
fill 130 38 511 130 41 511 minecraft:blackstone
fill 130 38 547 130 40 547 minecraft:blackstone
setblock 130 38 550 minecraft:smooth_basalt
fill 130 38 551 130 41 551 minecraft:blackstone
setblock 131 38 548 minecraft:blackstone
setblock 131 38 549 minecraft:smooth_basalt
fill 131 38 550 131 41 550 minecraft:blackstone
setblock 132 38 542 minecraft:blackstone
setblock 132 38 543 minecraft:smooth_basalt
fill 132 38 544 132 40 544 minecraft:blackstone
setblock 132 38 548 minecraft:smooth_basalt
fill 132 38 549 132 41 549 minecraft:blackstone
fill 133 38 525 133 38 526 minecraft:blackstone
setblock 133 38 527 minecraft:smooth_basalt
fill 133 38 528 133 39 530 minecraft:blackstone
setblock 133 38 542 minecraft:smooth_basalt
fill 133 38 543 133 41 543 minecraft:blackstone
setblock 133 38 547 minecraft:smooth_basalt
fill 133 38 548 133 41 548 minecraft:blackstone
setblock 134 38 511 minecraft:smooth_basalt
fill 134 38 522 134 38 525 minecraft:blackstone
setblock 134 38 526 minecraft:smooth_basalt
fill 134 38 527 134 41 527 minecraft:blackstone
fill 134 38 529 134 38 530 minecraft:blackstone
setblock 134 38 531 minecraft:smooth_basalt
fill 134 38 532 134 38 535 minecraft:blackstone
setblock 134 38 536 minecraft:smooth_basalt
fill 134 38 537 134 41 537 minecraft:blackstone
setblock 134 38 541 minecraft:smooth_basalt
fill 134 38 542 134 41 542 minecraft:blackstone
setblock 134 38 546 minecraft:smooth_basalt
fill 134 38 547 134 41 547 minecraft:blackstone
setblock 134 38 551 minecraft:smooth_basalt
fill 135 38 511 135 41 511 minecraft:blackstone
setblock 135 38 520 minecraft:smooth_basalt
fill 135 38 521 135 40 521 minecraft:blackstone
setblock 135 38 525 minecraft:smooth_basalt
fill 135 38 526 135 41 526 minecraft:blackstone
setblock 135 38 529 minecraft:blackstone
setblock 135 38 530 minecraft:smooth_basalt
fill 135 38 531 135 41 531 minecraft:blackstone
setblock 135 38 535 minecraft:smooth_basalt
fill 135 38 536 135 41 536 minecraft:blackstone
setblock 135 38 540 minecraft:smooth_basalt
fill 135 38 541 135 41 541 minecraft:blackstone
setblock 135 38 545 minecraft:smooth_basalt
fill 135 38 546 135 41 546 minecraft:blackstone
setblock 135 38 550 minecraft:smooth_basalt
fill 135 38 551 135 41 551 minecraft:blackstone
fill 95 39 511 95 41 511 minecraft:blackstone
setblock 95 39 519 minecraft:smooth_basalt
fill 95 39 520 95 41 520 minecraft:blackstone
setblock 95 39 524 minecraft:smooth_basalt
fill 95 39 525 95 42 525 minecraft:blackstone
setblock 95 39 529 minecraft:smooth_basalt
fill 95 39 530 95 42 530 minecraft:blackstone
setblock 95 39 534 minecraft:smooth_basalt
fill 95 39 535 95 42 535 minecraft:blackstone
setblock 95 39 539 minecraft:smooth_basalt
fill 95 39 540 95 42 540 minecraft:blackstone
setblock 95 39 544 minecraft:smooth_basalt
fill 95 39 545 95 42 545 minecraft:blackstone
setblock 95 39 549 minecraft:smooth_basalt
fill 95 39 550 95 42 550 minecraft:blackstone
fill 96 39 521 96 43 521 minecraft:smooth_basalt
setblock 96 39 523 minecraft:smooth_basalt
fill 96 39 524 96 42 524 minecraft:blackstone
setblock 96 39 527 minecraft:blackstone
setblock 96 39 528 minecraft:smooth_basalt
fill 96 39 529 96 42 529 minecraft:blackstone
setblock 96 39 533 minecraft:smooth_basalt
fill 96 39 534 96 42 534 minecraft:blackstone
fill 96 39 543 96 62 543 minecraft:smooth_basalt
fill 96 39 544 96 40 544 minecraft:blackstone
setblock 96 39 548 minecraft:smooth_basalt
fill 96 39 549 96 40 549 minecraft:blackstone
setblock 97 39 527 minecraft:smooth_basalt
fill 97 39 528 97 42 528 minecraft:blackstone
setblock 97 39 531 minecraft:blackstone
fill 98 39 531 98 44 531 minecraft:smooth_basalt
setblock 98 39 551 minecraft:smooth_basalt
fill 104 39 511 105 41 511 minecraft:blackstone
fill 104 39 551 107 39 551 minecraft:blackstone
fill 106 39 550 108 39 550 minecraft:blackstone
setblock 107 39 511 minecraft:blackstone
setblock 107 39 512 minecraft:smooth_basalt
setblock 108 39 511 minecraft:smooth_basalt
fill 108 39 512 108 42 512 minecraft:blackstone
setblock 108 39 551 minecraft:smooth_basalt
fill 109 39 511 109 42 511 minecraft:blackstone
setblock 109 39 549 minecraft:blackstone
setblock 109 39 550 minecraft:smooth_basalt
fill 109 39 551 109 42 551 minecraft:blackstone
setblock 110 39 513 minecraft:blackstone
setblock 110 39 522 minecraft:shroomlight
setblock 110 39 530 minecraft:shroomlight
setblock 110 39 549 minecraft:smooth_basalt
fill 110 39 550 110 42 550 minecraft:blackstone
setblock 111 39 512 minecraft:blackstone
setblock 111 39 513 minecraft:smooth_basalt
fill 111 39 549 111 42 549 minecraft:blackstone
setblock 112 39 512 minecraft:smooth_basalt
fill 112 39 513 112 42 513 minecraft:blackstone
setblock 113 39 511 minecraft:smooth_basalt
fill 113 39 512 113 42 512 minecraft:blackstone
fill 113 39 549 114 39 549 minecraft:blackstone
setblock 113 39 551 minecraft:smooth_basalt
fill 114 39 511 114 42 511 minecraft:blackstone
fill 114 39 513 114 40 513 minecraft:blackstone
setblock 114 39 550 minecraft:smooth_basalt
fill 114 39 551 117 39 551 minecraft:blackstone
setblock 115 39 549 minecraft:smooth_basalt
fill 115 39 550 115 42 550 minecraft:blackstone
fill 116 39 549 116 40 549 minecraft:blackstone
setblock 117 39 512 minecraft:smooth_basalt
setblock 118 39 511 minecraft:smooth_basalt
fill 118 39 512 118 42 512 minecraft:blackstone
setblock 118 39 551 minecraft:smooth_basalt
fill 119 39 511 122 39 511 minecraft:blackstone
setblock 119 39 550 minecraft:smooth_basalt
fill 119 39 551 122 39 551 minecraft:blackstone
fill 120 39 550 123 39 550 minecraft:blackstone
setblock 123 39 511 minecraft:smooth_basalt
fill 123 39 549 124 39 549 minecraft:blackstone
setblock 123 39 551 minecraft:smooth_basalt
fill 124 39 511 124 42 511 minecraft:blackstone
setblock 124 39 550 minecraft:smooth_basalt
fill 124 39 551 124 42 551 minecraft:blackstone
setblock 125 39 549 minecraft:smooth_basalt
fill 125 39 550 125 42 550 minecraft:blackstone
setblock 126 39 512 minecraft:blackstone
setblock 126 39 548 minecraft:smooth_basalt
fill 126 39 549 126 42 549 minecraft:blackstone
setblock 127 39 512 minecraft:smooth_basalt
fill 127 39 548 127 42 548 minecraft:blackstone
setblock 128 39 511 minecraft:smooth_basalt
fill 128 39 512 131 39 512 minecraft:blackstone
setblock 128 39 551 minecraft:smooth_basalt
fill 129 39 511 129 42 511 minecraft:blackstone
fill 129 39 547 129 40 547 minecraft:blackstone
setblock 129 39 550 minecraft:smooth_basalt
fill 129 39 551 129 42 551 minecraft:blackstone
setblock 130 39 549 minecraft:smooth_basalt
fill 130 39 550 130 42 550 minecraft:blackstone
setblock 131 39 548 minecraft:smooth_basalt
fill 131 39 549 131 42 549 minecraft:blackstone
setblock 132 39 512 minecraft:smooth_basalt
fill 132 39 543 132 40 543 minecraft:blackstone
setblock 132 39 547 minecraft:smooth_basalt
fill 132 39 548 132 42 548 minecraft:blackstone
setblock 133 39 511 minecraft:smooth_basalt
fill 133 39 512 133 40 512 minecraft:blackstone
setblock 133 39 525 minecraft:blackstone
setblock 133 39 526 minecraft:smooth_basalt
fill 133 39 527 133 41 527 minecraft:blackstone
setblock 133 39 531 minecraft:smooth_basalt
setblock 133 39 541 minecraft:smooth_basalt
fill 133 39 542 133 41 542 minecraft:blackstone
setblock 133 39 546 minecraft:smooth_basalt
fill 133 39 547 133 42 547 minecraft:blackstone
setblock 133 39 551 minecraft:smooth_basalt
fill 134 39 511 134 42 511 minecraft:blackstone
fill 134 39 522 134 39 524 minecraft:blackstone
setblock 134 39 525 minecraft:smooth_basalt
fill 134 39 526 134 42 526 minecraft:blackstone
setblock 134 39 529 minecraft:blackstone
setblock 134 39 530 minecraft:smooth_basalt
fill 134 39 531 134 39 534 minecraft:blackstone
setblock 134 39 535 minecraft:smooth_basalt
fill 134 39 536 134 42 536 minecraft:blackstone
setblock 134 39 540 minecraft:smooth_basalt
fill 134 39 541 134 42 541 minecraft:blackstone
setblock 134 39 545 minecraft:smooth_basalt
fill 134 39 546 134 42 546 minecraft:blackstone
setblock 134 39 550 minecraft:smooth_basalt
fill 134 39 551 134 42 551 minecraft:blackstone
setblock 135 39 520 minecraft:blackstone
setblock 135 39 524 minecraft:smooth_basalt
fill 135 39 525 135 42 525 minecraft:blackstone
setblock 135 39 529 minecraft:smooth_basalt
fill 135 39 530 135 42 530 minecraft:blackstone
setblock 135 39 534 minecraft:smooth_basalt
fill 135 39 535 135 42 535 minecraft:blackstone
setblock 135 39 539 minecraft:smooth_basalt
fill 135 39 540 135 42 540 minecraft:blackstone
setblock 135 39 544 minecraft:smooth_basalt
fill 135 39 545 135 42 545 minecraft:blackstone
setblock 135 39 549 minecraft:smooth_basalt
fill 135 39 550 135 42 550 minecraft:blackstone
setblock 95 40 519 minecraft:blackstone
setblock 95 40 523 minecraft:smooth_basalt
fill 95 40 524 95 43 524 minecraft:blackstone
setblock 95 40 528 minecraft:smooth_basalt
fill 95 40 529 95 43 529 minecraft:blackstone
setblock 95 40 533 minecraft:smooth_basalt
fill 95 40 534 95 43 534 minecraft:blackstone
setblock 95 40 538 minecraft:smooth_basalt
fill 95 40 539 95 42 539 minecraft:blackstone
setblock 95 40 543 minecraft:smooth_basalt
fill 95 40 544 95 42 544 minecraft:blackstone
setblock 95 40 548 minecraft:smooth_basalt
fill 95 40 549 95 43 549 minecraft:blackstone
fill 96 40 519 96 41 519 minecraft:smooth_basalt
fill 96 40 522 96 44 522 minecraft:smooth_basalt
fill 96 40 523 96 41 523 minecraft:blackstone
setblock 96 40 527 minecraft:smooth_basalt
fill 96 40 528 96 43 528 minecraft:blackstone
setblock 96 40 532 minecraft:smooth_basalt
fill 96 40 533 96 43 533 minecraft:blackstone
fill 96 40 542 96 63 542 minecraft:smooth_basalt
setblock 96 40 547 minecraft:smooth_basalt
fill 96 40 548 96 41 548 minecraft:blackstone
setblock 97 40 513 minecraft:light[level=12]
fill 97 40 524 97 45 524 minecraft:smooth_basalt
setblock 97 40 526 minecraft:smooth_basalt
fill 97 40 527 97 41 527 minecraft:blackstone
setblock 97 40 531 minecraft:smooth_basalt
setblock 97 40 537 minecraft:light[level=12]
setblock 97 40 551 minecraft:smooth_basalt
fill 98 40 551 99 40 551 minecraft:blackstone
setblock 102 40 551 minecraft:smooth_basalt
fill 103 40 511 103 43 511 minecraft:blackstone
fill 103 40 551 106 40 551 minecraft:blackstone
setblock 105 40 513 minecraft:light[level=12]
setblock 105 40 537 minecraft:light[level=12]
setblock 105 40 545 minecraft:light[level=12]
fill 105 40 550 107 40 550 minecraft:blackstone
setblock 106 40 512 minecraft:smooth_basalt
setblock 107 40 511 minecraft:smooth_basalt
fill 107 40 512 107 43 512 minecraft:blackstone
setblock 107 40 551 minecraft:smooth_basalt
fill 108 40 511 108 43 511 minecraft:blackstone
setblock 108 40 549 minecraft:blackstone
setblock 108 40 550 minecraft:smooth_basalt
fill 108 40 551 108 43 551 minecraft:blackstone
setblock 109 40 513 minecraft:blackstone
setblock 109 40 549 minecraft:smooth_basalt
fill 109 40 550 109 43 550 minecraft:blackstone
setblock 110 40 513 minecraft:smooth_basalt
fill 110 40 549 110 43 549 minecraft:blackstone
setblock 111 40 512 minecraft:smooth_basalt
fill 111 40 513 111 43 513 minecraft:blackstone
setblock 112 40 511 minecraft:smooth_basalt
fill 112 40 512 112 43 512 minecraft:blackstone
setblock 112 40 551 minecraft:smooth_basalt
fill 113 40 511 113 43 511 minecraft:blackstone
setblock 113 40 521 minecraft:light[level=12]
setblock 113 40 529 minecraft:light[level=12]
setblock 113 40 537 minecraft:light[level=12]
setblock 113 40 545 minecraft:light[level=12]
setblock 113 40 549 minecraft:blackstone
setblock 113 40 550 minecraft:smooth_basalt
fill 113 40 551 116 40 551 minecraft:blackstone
setblock 114 40 549 minecraft:smooth_basalt
fill 114 40 550 114 43 550 minecraft:blackstone
fill 115 40 549 115 41 549 minecraft:blackstone
setblock 116 40 512 minecraft:smooth_basalt
setblock 117 40 511 minecraft:smooth_basalt
fill 117 40 512 117 43 512 minecraft:blackstone
setblock 117 40 551 minecraft:smooth_basalt
fill 118 40 511 121 40 511 minecraft:blackstone
setblock 118 40 550 minecraft:smooth_basalt
fill 118 40 551 121 40 551 minecraft:blackstone
fill 119 40 550 122 40 550 minecraft:blackstone
setblock 121 40 513 minecraft:light[level=12]
setblock 121 40 521 minecraft:light[level=12]
setblock 121 40 529 minecraft:light[level=12]
setblock 121 40 537 minecraft:light[level=12]
setblock 121 40 545 minecraft:light[level=12]
setblock 122 40 511 minecraft:smooth_basalt
fill 122 40 549 123 40 549 minecraft:blackstone
setblock 122 40 551 minecraft:smooth_basalt
fill 123 40 511 123 43 511 minecraft:blackstone
setblock 123 40 550 minecraft:smooth_basalt
fill 123 40 551 123 43 551 minecraft:blackstone
setblock 124 40 549 minecraft:smooth_basalt
fill 124 40 550 124 43 550 minecraft:blackstone
setblock 125 40 512 minecraft:blackstone
fill 125 40 549 125 43 549 minecraft:blackstone
setblock 126 40 512 minecraft:smooth_basalt
fill 126 40 548 126 43 548 minecraft:blackstone
setblock 127 40 511 minecraft:smooth_basalt
fill 127 40 512 130 40 512 minecraft:blackstone
setblock 127 40 551 minecraft:smooth_basalt
fill 128 40 511 128 43 511 minecraft:blackstone
setblock 128 40 550 minecraft:smooth_basalt
fill 128 40 551 128 43 551 minecraft:blackstone
setblock 129 40 513 minecraft:light[level=12]
setblock 129 40 521 minecraft:light[level=12]
setblock 129 40 529 minecraft:light[level=12]
setblock 129 40 537 minecraft:light[level=12]
setblock 129 40 545 minecraft:light[level=12]
setblock 129 40 549 minecraft:smooth_basalt
fill 129 40 550 129 43 550 minecraft:blackstone
setblock 130 40 548 minecraft:smooth_basalt
fill 130 40 549 130 43 549 minecraft:blackstone
setblock 131 40 512 minecraft:smooth_basalt
setblock 131 40 546 minecraft:blackstone
setblock 131 40 547 minecraft:smooth_basalt
fill 131 40 548 131 43 548 minecraft:blackstone
setblock 132 40 511 minecraft:smooth_basalt
fill 132 40 512 132 42 512 minecraft:blackstone
setblock 132 40 546 minecraft:smooth_basalt
fill 132 40 547 132 42 547 minecraft:blackstone
setblock 132 40 551 minecraft:smooth_basalt
fill 133 40 511 133 43 511 minecraft:blackstone
setblock 133 40 526 minecraft:blackstone
fill 133 40 528 133 40 529 minecraft:blackstone
setblock 133 40 530 minecraft:smooth_basalt
fill 133 40 531 134 40 533 minecraft:blackstone
setblock 133 40 541 minecraft:blackstone
setblock 133 40 545 minecraft:smooth_basalt
fill 133 40 546 133 43 546 minecraft:blackstone
setblock 133 40 550 minecraft:smooth_basalt
fill 133 40 551 133 43 551 minecraft:blackstone
setblock 134 40 523 minecraft:blackstone
setblock 134 40 524 minecraft:smooth_basalt
fill 134 40 525 134 41 525 minecraft:blackstone
setblock 134 40 529 minecraft:smooth_basalt
fill 134 40 530 134 43 530 minecraft:blackstone
setblock 134 40 534 minecraft:smooth_basalt
fill 134 40 535 134 43 535 minecraft:blackstone
setblock 134 40 539 minecraft:smooth_basalt
fill 134 40 540 134 42 540 minecraft:blackstone
setblock 134 40 544 minecraft:smooth_basalt
fill 134 40 545 134 43 545 minecraft:blackstone
setblock 134 40 549 minecraft:smooth_basalt
fill 134 40 550 134 43 550 minecraft:blackstone
setblock 135 40 523 minecraft:smooth_basalt
fill 135 40 524 135 42 524 minecraft:blackstone
setblock 135 40 528 minecraft:smooth_basalt
fill 135 40 529 135 43 529 minecraft:blackstone
setblock 135 40 533 minecraft:smooth_basalt
fill 135 40 534 135 43 534 minecraft:blackstone
setblock 135 40 538 minecraft:smooth_basalt
fill 135 40 539 135 43 539 minecraft:blackstone
setblock 135 40 543 minecraft:smooth_basalt
fill 135 40 544 135 43 544 minecraft:blackstone
setblock 135 40 548 minecraft:smooth_basalt
fill 135 40 549 135 43 549 minecraft:blackstone
setblock 95 41 522 minecraft:smooth_basalt
fill 95 41 523 95 43 523 minecraft:blackstone
setblock 95 41 527 minecraft:smooth_basalt
fill 95 41 528 95 44 528 minecraft:blackstone
setblock 95 41 532 minecraft:smooth_basalt
fill 95 41 533 95 44 533 minecraft:blackstone
setblock 95 41 537 minecraft:smooth_basalt
fill 95 41 538 95 43 538 minecraft:blackstone
setblock 95 41 542 minecraft:smooth_basalt
fill 95 41 543 95 42 543 minecraft:blackstone
setblock 95 41 547 minecraft:smooth_basalt
fill 95 41 548 95 43 548 minecraft:blackstone
setblock 96 41 526 minecraft:smooth_basalt
fill 96 41 527 96 44 527 minecraft:blackstone
setblock 96 41 530 minecraft:blackstone
setblock 96 41 531 minecraft:smooth_basalt
fill 96 41 532 96 44 532 minecraft:blackstone
fill 96 41 544 96 62 545 minecraft:smooth_basalt
setblock 96 41 551 minecraft:smooth_basalt
fill 97 41 525 97 46 525 minecraft:smooth_basalt
setblock 97 41 526 minecraft:blackstone
setblock 97 41 530 minecraft:smooth_basalt
setblock 97 41 531 minecraft:blackstone
fill 97 41 551 98 41 551 minecraft:blackstone
fill 102 41 511 102 44 511 minecraft:blackstone
fill 102 41 551 105 41 551 minecraft:blackstone
setblock 105 41 512 minecraft:smooth_basalt
fill 105 41 550 106 41 550 minecraft:blackstone
setblock 106 41 511 minecraft:smooth_basalt
fill 106 41 512 106 44 512 minecraft:blackstone
setblock 106 41 551 minecraft:smooth_basalt
fill 107 41 511 107 44 511 minecraft:blackstone
setblock 107 41 550 minecraft:smooth_basalt
fill 107 41 551 107 44 551 minecraft:blackstone
setblock 108 41 513 minecraft:blackstone
setblock 108 41 549 minecraft:smooth_basalt
fill 108 41 550 108 44 550 minecraft:blackstone
setblock 109 41 513 minecraft:smooth_basalt
fill 109 41 549 109 42 549 minecraft:blackstone
setblock 110 41 512 minecraft:smooth_basalt
fill 110 41 513 110 44 513 minecraft:blackstone
setblock 111 41 511 minecraft:smooth_basalt
fill 111 41 512 111 44 512 minecraft:blackstone
setblock 111 41 551 minecraft:smooth_basalt
fill 112 41 511 112 44 511 minecraft:blackstone
setblock 112 41 550 minecraft:smooth_basalt
fill 112 41 551 115 41 551 minecraft:blackstone
setblock 113 41 549 minecraft:smooth_basalt
fill 113 41 550 113 44 550 minecraft:blackstone
setblock 114 41 513 minecraft:smooth_basalt
setblock 114 41 549 minecraft:blackstone
setblock 115 41 512 minecraft:smooth_basalt
setblock 116 41 511 minecraft:smooth_basalt
fill 116 41 512 116 44 512 minecraft:blackstone
setblock 116 41 551 minecraft:smooth_basalt
fill 117 41 511 120 41 511 minecraft:blackstone
setblock 117 41 550 minecraft:smooth_basalt
fill 117 41 551 120 41 551 minecraft:blackstone
fill 118 41 550 121 41 550 minecraft:blackstone
setblock 121 41 511 minecraft:smooth_basalt
setblock 121 41 551 minecraft:smooth_basalt
fill 122 41 511 122 44 511 minecraft:blackstone
setblock 122 41 549 minecraft:blackstone
setblock 122 41 550 minecraft:smooth_basalt
fill 122 41 551 122 44 551 minecraft:blackstone
setblock 123 41 549 minecraft:smooth_basalt
fill 123 41 550 123 44 550 minecraft:blackstone
setblock 124 41 512 minecraft:blackstone
fill 124 41 549 124 44 549 minecraft:blackstone
setblock 125 41 512 minecraft:smooth_basalt
setblock 125 41 548 minecraft:blackstone
setblock 126 41 511 minecraft:smooth_basalt
fill 126 41 512 129 41 512 minecraft:blackstone
setblock 126 41 551 minecraft:smooth_basalt
fill 127 41 511 127 44 511 minecraft:blackstone
setblock 127 41 550 minecraft:smooth_basalt
fill 127 41 551 127 44 551 minecraft:blackstone
setblock 128 41 549 minecraft:smooth_basalt
fill 128 41 550 128 44 550 minecraft:blackstone
setblock 129 41 548 minecraft:smooth_basalt
fill 129 41 549 129 44 549 minecraft:blackstone
setblock 130 41 512 minecraft:smooth_basalt
setblock 130 41 547 minecraft:smooth_basalt
fill 130 41 548 130 43 548 minecraft:blackstone
setblock 131 41 511 minecraft:smooth_basalt
fill 131 41 512 131 44 512 minecraft:blackstone
setblock 131 41 551 minecraft:smooth_basalt
fill 132 41 511 132 44 511 minecraft:blackstone
setblock 132 41 545 minecraft:smooth_basalt
fill 132 41 546 132 42 546 minecraft:blackstone
setblock 132 41 550 minecraft:smooth_basalt
fill 132 41 551 132 44 551 minecraft:blackstone
setblock 133 41 528 minecraft:blackstone
setblock 133 41 529 minecraft:smooth_basalt
fill 133 41 530 133 41 533 minecraft:blackstone
setblock 133 41 544 minecraft:smooth_basalt
fill 133 41 545 133 42 545 minecraft:blackstone
setblock 133 41 549 minecraft:smooth_basalt
fill 133 41 550 133 44 550 minecraft:blackstone
setblock 134 41 524 minecraft:blackstone
setblock 134 41 528 minecraft:smooth_basalt
fill 134 41 529 134 44 529 minecraft:blackstone
fill 134 41 531 134 41 532 minecraft:blackstone
setblock 134 41 533 minecraft:smooth_basalt
fill 134 41 534 134 44 534 minecraft:blackstone
setblock 134 41 538 minecraft:smooth_basalt
fill 134 41 539 134 42 539 minecraft:blackstone
setblock 134 41 543 minecraft:smooth_basalt
fill 134 41 544 134 43 544 minecraft:blackstone
setblock 134 41 548 minecraft:smooth_basalt
fill 134 41 549 134 44 549 minecraft:blackstone
setblock 135 41 512 minecraft:smooth_basalt
setblock 135 41 522 minecraft:smooth_basalt
setblock 135 41 523 minecraft:blackstone
setblock 135 41 527 minecraft:smooth_basalt
fill 135 41 528 135 44 528 minecraft:blackstone
setblock 135 41 532 minecraft:smooth_basalt
fill 135 41 533 135 44 533 minecraft:blackstone
setblock 135 41 537 minecraft:smooth_basalt
fill 135 41 538 135 44 538 minecraft:blackstone
setblock 135 41 542 minecraft:smooth_basalt
fill 135 41 543 135 43 543 minecraft:blackstone
setblock 135 41 547 minecraft:smooth_basalt
fill 135 41 548 135 44 548 minecraft:blackstone
setblock 95 42 521 minecraft:smooth_basalt
setblock 95 42 522 minecraft:blackstone
setblock 95 42 526 minecraft:smooth_basalt
fill 95 42 527 95 45 527 minecraft:blackstone
setblock 95 42 531 minecraft:smooth_basalt
fill 95 42 532 95 45 532 minecraft:blackstone
setblock 95 42 536 minecraft:smooth_basalt
fill 95 42 537 95 44 537 minecraft:blackstone
setblock 95 42 542 minecraft:blackstone
setblock 95 42 546 minecraft:smooth_basalt
fill 95 42 547 95 43 547 minecraft:blackstone
setblock 95 42 551 minecraft:smooth_basalt
fill 96 42 523 96 44 523 minecraft:smooth_basalt
fill 96 42 525 96 45 525 minecraft:smooth_basalt
fill 96 42 526 96 43 526 minecraft:blackstone
setblock 96 42 530 minecraft:smooth_basalt
fill 96 42 531 96 45 531 minecraft:blackstone
fill 96 42 551 97 42 551 minecraft:blackstone
fill 97 42 526 97 46 527 minecraft:smooth_basalt
fill 97 42 529 97 45 529 minecraft:smooth_basalt
setblock 97 42 530 minecraft:blackstone
fill 97 42 531 97 44 531 minecraft:smooth_basalt
fill 102 42 551 104 42 551 minecraft:blackstone
setblock 104 42 511 minecraft:blackstone
setblock 104 42 512 minecraft:smooth_basalt
setblock 105 42 511 minecraft:smooth_basalt
fill 105 42 512 105 45 512 minecraft:blackstone
setblock 105 42 550 minecraft:blackstone
setblock 105 42 551 minecraft:smooth_basalt
fill 106 42 511 106 45 511 minecraft:blackstone
setblock 106 42 550 minecraft:smooth_basalt
fill 106 42 551 106 45 551 minecraft:blackstone
setblock 107 42 513 minecraft:blackstone
fill 107 42 550 107 45 550 minecraft:blackstone
setblock 108 42 513 minecraft:smooth_basalt
setblock 108 42 549 minecraft:blackstone
setblock 109 42 512 minecraft:smooth_basalt
fill 109 42 513 109 45 513 minecraft:blackstone
setblock 110 42 511 minecraft:smooth_basalt
fill 110 42 512 110 45 512 minecraft:blackstone
setblock 110 42 551 minecraft:smooth_basalt
fill 111 42 511 111 45 511 minecraft:blackstone
setblock 111 42 550 minecraft:smooth_basalt
fill 111 42 551 114 42 551 minecraft:blackstone
setblock 112 42 549 minecraft:smooth_basalt
fill 112 42 550 112 45 550 minecraft:blackstone
setblock 113 42 513 minecraft:smooth_basalt
setblock 113 42 549 minecraft:blackstone
setblock 114 42 512 minecraft:smooth_basalt
setblock 115 42 511 minecraft:smooth_basalt
fill 115 42 512 115 45 512 minecraft:blackstone
setblock 115 42 551 minecraft:smooth_basalt
fill 116 42 511 119 42 511 minecraft:blackstone
setblock 116 42 550 minecraft:smooth_basalt
fill 116 42 551 119 42 551 minecraft:blackstone
fill 117 42 550 120 42 550 minecraft:blackstone
setblock 120 42 511 minecraft:smooth_basalt
setblock 120 42 551 minecraft:smooth_basalt
fill 121 42 511 121 45 511 minecraft:blackstone
setblock 121 42 550 minecraft:smooth_basalt
fill 121 42 551 121 45 551 minecraft:blackstone
fill 122 42 522 122 43 522 minecraft:gilded_blackstone
setblock 122 42 549 minecraft:smooth_basalt
fill 122 42 550 122 45 550 minecraft:blackstone
setblock 123 42 512 minecraft:blackstone
fill 123 42 549 123 44 549 minecraft:blackstone
setblock 124 42 512 minecraft:smooth_basalt
setblock 125 42 511 minecraft:smooth_basalt
fill 125 42 512 128 42 512 minecraft:blackstone
setblock 125 42 551 minecraft:smooth_basalt
fill 126 42 511 126 45 511 minecraft:blackstone
setblock 126 42 550 minecraft:smooth_basalt
fill 126 42 551 126 45 551 minecraft:blackstone
setblock 127 42 549 minecraft:smooth_basalt
fill 127 42 550 127 45 550 minecraft:blackstone
setblock 128 42 548 minecraft:smooth_basalt
fill 128 42 549 128 45 549 minecraft:blackstone
setblock 129 42 512 minecraft:smooth_basalt
fill 129 42 548 129 43 548 minecraft:blackstone
setblock 130 42 511 minecraft:smooth_basalt
fill 130 42 512 130 45 512 minecraft:blackstone
setblock 130 42 551 minecraft:smooth_basalt
fill 131 42 511 131 45 511 minecraft:blackstone
setblock 131 42 550 minecraft:smooth_basalt
fill 131 42 551 131 45 551 minecraft:blackstone
setblock 132 42 549 minecraft:smooth_basalt
fill 132 42 550 132 45 550 minecraft:blackstone
setblock 133 42 528 minecraft:smooth_basalt
fill 133 42 529 133 42 532 minecraft:blackstone
setblock 133 42 533 minecraft:smooth_basalt
setblock 133 42 544 minecraft:blackstone
setblock 133 42 548 minecraft:smooth_basalt
fill 133 42 549 133 43 549 minecraft:blackstone
setblock 134 42 527 minecraft:smooth_basalt
fill 134 42 528 134 44 528 minecraft:blackstone
setblock 134 42 531 minecraft:blackstone
setblock 134 42 532 minecraft:smooth_basalt
fill 134 42 533 134 45 533 minecraft:blackstone
setblock 134 42 537 minecraft:smooth_basalt
setblock 134 42 538 minecraft:blackstone
setblock 134 42 542 minecraft:smooth_basalt
setblock 134 42 543 minecraft:blackstone
setblock 134 42 547 minecraft:smooth_basalt
fill 134 42 548 134 44 548 minecraft:blackstone
setblock 135 42 511 minecraft:smooth_basalt
setblock 135 42 526 minecraft:smooth_basalt
fill 135 42 527 135 45 527 minecraft:blackstone
setblock 135 42 531 minecraft:smooth_basalt
fill 135 42 532 135 45 532 minecraft:blackstone
setblock 135 42 536 minecraft:smooth_basalt
fill 135 42 537 135 45 537 minecraft:blackstone
setblock 135 42 541 minecraft:smooth_basalt
fill 135 42 542 135 43 542 minecraft:blackstone
setblock 135 42 546 minecraft:smooth_basalt
fill 135 42 547 135 44 547 minecraft:blackstone
setblock 135 42 551 minecraft:smooth_basalt
setblock 95 43 522 minecraft:smooth_basalt
setblock 95 43 525 minecraft:smooth_basalt
fill 95 43 526 95 46 526 minecraft:blackstone
setblock 95 43 530 minecraft:smooth_basalt
fill 95 43 531 95 46 531 minecraft:blackstone
setblock 95 43 535 minecraft:smooth_basalt
fill 95 43 536 95 46 536 minecraft:blackstone
fill 95 43 543 95 56 544 minecraft:smooth_basalt
setblock 95 43 550 minecraft:smooth_basalt
setblock 95 43 551 minecraft:blackstone
fill 96 43 524 96 45 524 minecraft:smooth_basalt
setblock 96 43 529 minecraft:smooth_basalt
fill 96 43 530 96 46 530 minecraft:blackstone
setblock 96 43 534 minecraft:smooth_basalt
fill 97 43 528 97 45 528 minecraft:smooth_basalt
fill 97 43 530 97 45 530 minecraft:smooth_basalt
fill 101 43 511 101 45 511 minecraft:blackstone
fill 102 43 551 103 43 551 minecraft:blackstone
setblock 104 43 511 minecraft:smooth_basalt
fill 104 43 512 104 46 512 minecraft:blackstone
setblock 104 43 551 minecraft:smooth_basalt
fill 105 43 511 105 46 511 minecraft:blackstone
setblock 105 43 550 minecraft:smooth_basalt
fill 105 43 551 105 46 551 minecraft:blackstone
setblock 106 43 513 minecraft:blackstone
fill 106 43 550 106 46 550 minecraft:blackstone
setblock 107 43 513 minecraft:smooth_basalt
setblock 108 43 512 minecraft:smooth_basalt
fill 108 43 513 108 46 513 minecraft:blackstone
setblock 109 43 511 minecraft:smooth_basalt
fill 109 43 512 109 46 512 minecraft:blackstone
setblock 109 43 551 minecraft:smooth_basalt
fill 110 43 511 110 46 511 minecraft:blackstone
setblock 110 43 550 minecraft:smooth_basalt
fill 110 43 551 113 43 551 minecraft:blackstone
fill 111 43 550 111 46 550 minecraft:blackstone
setblock 112 43 513 minecraft:smooth_basalt
setblock 113 43 512 minecraft:smooth_basalt
setblock 113 43 513 minecraft:blackstone
setblock 114 43 511 minecraft:smooth_basalt
fill 114 43 512 114 46 512 minecraft:blackstone
setblock 114 43 551 minecraft:smooth_basalt
fill 115 43 511 118 43 511 minecraft:blackstone
setblock 115 43 550 minecraft:smooth_basalt
fill 115 43 551 118 43 551 minecraft:blackstone
fill 116 43 550 119 43 550 minecraft:blackstone
setblock 119 43 511 minecraft:smooth_basalt
setblock 119 43 551 minecraft:smooth_basalt
fill 120 43 511 120 46 511 minecraft:blackstone
setblock 120 43 550 minecraft:smooth_basalt
fill 120 43 551 120 46 551 minecraft:blackstone
fill 121 43 550 121 46 550 minecraft:blackstone
setblock 122 43 512 minecraft:blackstone
setblock 123 43 512 minecraft:smooth_basalt
setblock 124 43 511 minecraft:smooth_basalt
fill 124 43 512 127 43 512 minecraft:blackstone
setblock 124 43 551 minecraft:smooth_basalt
fill 125 43 511 125 46 511 minecraft:blackstone
setblock 125 43 550 minecraft:smooth_basalt
fill 125 43 551 125 46 551 minecraft:blackstone
setblock 126 43 549 minecraft:smooth_basalt
fill 126 43 550 126 46 550 minecraft:blackstone
setblock 127 43 548 minecraft:smooth_basalt
fill 127 43 549 127 46 549 minecraft:blackstone
setblock 128 43 512 minecraft:smooth_basalt
fill 128 43 548 128 44 548 minecraft:blackstone
setblock 129 43 511 minecraft:smooth_basalt
fill 129 43 512 129 46 512 minecraft:blackstone
setblock 129 43 551 minecraft:smooth_basalt
fill 130 43 511 130 46 511 minecraft:blackstone
setblock 130 43 550 minecraft:smooth_basalt
fill 130 43 551 130 46 551 minecraft:blackstone
setblock 131 43 549 minecraft:smooth_basalt
fill 131 43 550 131 46 550 minecraft:blackstone
fill 132 43 549 132 44 549 minecraft:blackstone
fill 133 43 530 133 43 531 minecraft:blackstone
setblock 133 43 532 minecraft:smooth_basalt
setblock 133 43 533 minecraft:blackstone
setblock 133 43 547 minecraft:smooth_basalt
setblock 133 43 548 minecraft:blackstone
setblock 134 43 511 minecraft:smooth_basalt
setblock 134 43 527 minecraft:blackstone
setblock 134 43 531 minecraft:smooth_basalt
fill 134 43 532 134 46 532 minecraft:blackstone
setblock 134 43 536 minecraft:smooth_basalt
setblock 134 43 546 minecraft:smooth_basalt
fill 134 43 547 134 44 547 minecraft:blackstone
setblock 134 43 551 minecraft:smooth_basalt
setblock 135 43 511 minecraft:blackstone
setblock 135 43 525 minecraft:smooth_basalt
fill 135 43 526 135 44 526 minecraft:blackstone
setblock 135 43 530 minecraft:smooth_basalt
fill 135 43 531 135 46 531 minecraft:blackstone
setblock 135 43 535 minecraft:smooth_basalt
fill 135 43 536 135 46 536 minecraft:blackstone
setblock 135 43 540 minecraft:smooth_basalt
setblock 135 43 541 minecraft:blackstone
setblock 135 43 545 minecraft:smooth_basalt
fill 135 43 546 135 44 546 minecraft:blackstone
setblock 135 43 550 minecraft:smooth_basalt
fill 135 43 551 135 45 551 minecraft:blackstone
fill 95 44 523 95 44 524 minecraft:smooth_basalt
fill 95 44 525 95 45 525 minecraft:blackstone
setblock 95 44 529 minecraft:smooth_basalt
fill 95 44 530 95 47 530 minecraft:blackstone
setblock 95 44 534 minecraft:smooth_basalt
fill 95 44 535 95 47 535 minecraft:blackstone
fill 96 44 526 96 45 526 minecraft:smooth_basalt
setblock 96 44 528 minecraft:smooth_basalt
fill 96 44 529 96 45 529 minecraft:blackstone
setblock 96 44 533 minecraft:smooth_basalt
setblock 102 44 551 minecraft:blackstone
setblock 103 44 511 minecraft:smooth_basalt
fill 103 44 512 103 47 512 minecraft:blackstone
setblock 103 44 551 minecraft:smooth_basalt
fill 104 44 511 104 47 511 minecraft:blackstone
fill 104 44 551 104 47 551 minecraft:blackstone
setblock 105 44 550 minecraft:blackstone
setblock 106 44 513 minecraft:smooth_basalt
setblock 107 44 512 minecraft:smooth_basalt
fill 107 44 513 107 47 513 minecraft:blackstone
setblock 108 44 511 minecraft:smooth_basalt
fill 108 44 512 108 47 512 minecraft:blackstone
setblock 108 44 551 minecraft:smooth_basalt
fill 109 44 511 109 47 511 minecraft:blackstone
setblock 109 44 550 minecraft:smooth_basalt
fill 109 44 551 112 44 551 minecraft:blackstone
fill 110 44 550 110 47 550 minecraft:blackstone
setblock 111 44 513 minecraft:smooth_basalt
setblock 112 44 512 minecraft:smooth_basalt
fill 112 44 513 112 45 513 minecraft:blackstone
setblock 113 44 511 minecraft:smooth_basalt
fill 113 44 512 113 47 512 minecraft:blackstone
setblock 113 44 551 minecraft:smooth_basalt
fill 114 44 511 117 44 511 minecraft:blackstone
setblock 114 44 550 minecraft:smooth_basalt
fill 114 44 551 117 44 551 minecraft:blackstone
fill 115 44 550 116 44 550 minecraft:blackstone
setblock 118 44 511 minecraft:smooth_basalt
setblock 118 44 550 minecraft:blackstone
setblock 118 44 551 minecraft:smooth_basalt
fill 119 44 511 119 47 511 minecraft:blackstone
setblock 119 44 550 minecraft:smooth_basalt
fill 119 44 551 119 47 551 minecraft:blackstone
fill 120 44 550 120 46 550 minecraft:blackstone
setblock 122 44 512 minecraft:smooth_basalt
setblock 123 44 511 minecraft:smooth_basalt
fill 123 44 512 126 44 512 minecraft:blackstone
setblock 123 44 551 minecraft:smooth_basalt
fill 124 44 511 124 47 511 minecraft:blackstone
setblock 124 44 550 minecraft:smooth_basalt
fill 124 44 551 124 47 551 minecraft:blackstone
setblock 125 44 549 minecraft:smooth_basalt
fill 125 44 550 125 47 550 minecraft:blackstone
fill 126 44 549 126 47 549 minecraft:blackstone
setblock 127 44 512 minecraft:smooth_basalt
setblock 128 44 511 minecraft:smooth_basalt
fill 128 44 512 128 47 512 minecraft:blackstone
setblock 128 44 551 minecraft:smooth_basalt
fill 129 44 511 129 47 511 minecraft:blackstone
setblock 129 44 550 minecraft:smooth_basalt
fill 129 44 551 129 47 551 minecraft:blackstone
schedule function dropper:buildpart/122_2 1t
