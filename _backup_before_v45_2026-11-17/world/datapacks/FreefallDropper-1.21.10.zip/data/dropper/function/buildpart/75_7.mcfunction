fill 163 120 325 166 120 325 minecraft:blue_terracotta
setblock 164 120 323 minecraft:dark_prismarine
fill 164 120 324 164 123 324 minecraft:blue_terracotta
fill 164 120 337 167 120 340 minecraft:dark_oak_planks
fill 164 120 348 167 120 351 minecraft:dark_oak_planks
setblock 164 120 363 minecraft:dark_prismarine
fill 165 120 323 165 123 323 minecraft:blue_terracotta
fill 165 120 336 166 120 336 minecraft:dark_oak_planks
fill 165 120 352 166 120 352 minecraft:dark_oak_planks
setblock 165 120 362 minecraft:dark_prismarine
fill 165 120 363 165 123 363 minecraft:blue_terracotta
setblock 166 120 361 minecraft:dark_prismarine
fill 166 120 362 166 123 362 minecraft:blue_terracotta
setblock 167 120 325 minecraft:dark_prismarine
setblock 167 120 360 minecraft:dark_prismarine
fill 167 120 361 167 122 361 minecraft:blue_terracotta
setblock 168 120 324 minecraft:dark_prismarine
fill 168 120 338 168 120 339 minecraft:dark_oak_planks
fill 168 120 349 168 120 350 minecraft:dark_oak_planks
setblock 169 120 323 minecraft:dark_prismarine
fill 169 120 324 169 122 324 minecraft:blue_terracotta
fill 169 120 329 169 122 329 minecraft:dark_prismarine
fill 169 120 332 169 122 332 minecraft:dark_prismarine
setblock 169 120 363 minecraft:dark_prismarine
fill 170 120 323 170 123 323 minecraft:blue_terracotta
setblock 170 120 362 minecraft:dark_prismarine
fill 170 120 363 170 123 363 minecraft:blue_terracotta
fill 171 120 362 171 121 362 minecraft:blue_terracotta
setblock 173 120 323 minecraft:blue_terracotta
fill 173 120 352 173 164 352 minecraft:magenta_terracotta
setblock 174 120 323 minecraft:dark_prismarine
setblock 174 120 363 minecraft:dark_prismarine
setblock 175 120 323 minecraft:blue_terracotta
setblock 175 120 363 minecraft:blue_terracotta
fill 177 120 323 178 120 323 minecraft:blue_terracotta
fill 178 120 328 178 120 335 minecraft:purple_concrete
fill 178 120 340 178 120 358 minecraft:purple_concrete
setblock 179 120 323 minecraft:dark_prismarine
setblock 179 120 363 minecraft:dark_prismarine
fill 180 120 323 180 123 323 minecraft:blue_terracotta
fill 180 120 340 180 120 341 minecraft:blue_terracotta
setblock 180 120 342 minecraft:dark_prismarine
fill 180 120 343 180 123 343 minecraft:blue_terracotta
setblock 180 120 346 minecraft:blue_terracotta
setblock 180 120 347 minecraft:dark_prismarine
fill 180 120 363 180 122 363 minecraft:blue_terracotta
setblock 181 120 325 minecraft:blue_terracotta
setblock 181 120 326 minecraft:dark_prismarine
setblock 181 120 336 minecraft:dark_prismarine
fill 181 120 337 181 123 337 minecraft:blue_terracotta
setblock 181 120 341 minecraft:dark_prismarine
fill 181 120 342 181 123 342 minecraft:blue_terracotta
setblock 181 120 346 minecraft:dark_prismarine
fill 181 120 347 181 123 347 minecraft:blue_terracotta
setblock 181 120 350 minecraft:blue_terracotta
setblock 182 120 324 minecraft:blue_terracotta
setblock 182 120 325 minecraft:dark_prismarine
fill 182 120 326 182 120 329 minecraft:blue_terracotta
setblock 182 120 330 minecraft:dark_prismarine
fill 182 120 331 182 123 331 minecraft:blue_terracotta
setblock 182 120 335 minecraft:dark_prismarine
fill 182 120 336 182 123 336 minecraft:blue_terracotta
setblock 182 120 340 minecraft:dark_prismarine
fill 182 120 341 182 123 341 minecraft:blue_terracotta
setblock 182 120 345 minecraft:dark_prismarine
fill 182 120 346 182 123 346 minecraft:blue_terracotta
setblock 182 120 350 minecraft:dark_prismarine
fill 182 120 351 182 123 351 minecraft:blue_terracotta
setblock 182 120 360 minecraft:dark_prismarine
fill 182 120 361 182 122 361 minecraft:blue_terracotta
fill 183 120 338 183 131 338 minecraft:black_concrete
fill 183 120 344 183 127 344 minecraft:black_concrete
setblock 142 121 323 minecraft:blue_terracotta
setblock 142 121 324 minecraft:dark_prismarine
fill 142 121 325 142 121 328 minecraft:blue_terracotta
setblock 142 121 329 minecraft:dark_prismarine
fill 142 121 330 142 124 330 minecraft:blue_terracotta
setblock 142 121 334 minecraft:dark_prismarine
fill 142 121 335 142 124 335 minecraft:blue_terracotta
setblock 142 121 339 minecraft:dark_prismarine
fill 142 121 340 142 124 340 minecraft:blue_terracotta
setblock 142 121 344 minecraft:dark_prismarine
fill 142 121 345 142 124 345 minecraft:blue_terracotta
setblock 142 121 348 minecraft:blue_terracotta
setblock 142 121 349 minecraft:dark_prismarine
fill 142 121 350 142 124 350 minecraft:blue_terracotta
fill 142 121 352 142 122 352 minecraft:blue_terracotta
setblock 142 121 359 minecraft:dark_prismarine
fill 142 121 360 142 123 360 minecraft:blue_terracotta
setblock 143 121 323 minecraft:dark_prismarine
fill 143 121 324 143 121 327 minecraft:blue_terracotta
setblock 143 121 328 minecraft:dark_prismarine
fill 143 121 329 143 124 329 minecraft:blue_terracotta
setblock 143 121 333 minecraft:dark_prismarine
fill 143 121 334 143 124 334 minecraft:blue_terracotta
setblock 143 121 338 minecraft:dark_prismarine
fill 143 121 339 143 123 339 minecraft:blue_terracotta
setblock 143 121 343 minecraft:dark_prismarine
fill 143 121 344 143 124 344 minecraft:blue_terracotta
setblock 143 121 348 minecraft:dark_prismarine
fill 143 121 349 143 124 349 minecraft:blue_terracotta
setblock 143 121 362 minecraft:blue_terracotta
setblock 143 121 363 minecraft:dark_prismarine
fill 144 121 323 144 121 326 minecraft:blue_terracotta
setblock 144 121 327 minecraft:dark_prismarine
fill 144 121 328 144 124 328 minecraft:blue_terracotta
setblock 144 121 332 minecraft:dark_prismarine
setblock 144 121 338 minecraft:blue_terracotta
setblock 144 121 342 minecraft:dark_prismarine
fill 144 121 343 144 122 343 minecraft:blue_terracotta
setblock 144 121 347 minecraft:dark_prismarine
setblock 144 121 362 minecraft:dark_prismarine
fill 144 121 363 147 121 363 minecraft:blue_terracotta
fill 144 121 364 144 131 364 minecraft:black_concrete
setblock 145 121 325 minecraft:blue_terracotta
setblock 145 121 326 minecraft:dark_prismarine
fill 145 121 327 145 124 327 minecraft:blue_terracotta
fill 145 121 362 145 123 362 minecraft:blue_terracotta
setblock 146 121 325 minecraft:dark_prismarine
fill 146 121 326 146 124 326 minecraft:blue_terracotta
setblock 147 121 324 minecraft:dark_prismarine
fill 147 121 325 147 124 325 minecraft:blue_terracotta
setblock 148 121 323 minecraft:dark_prismarine
fill 148 121 324 148 124 324 minecraft:blue_terracotta
setblock 148 121 363 minecraft:dark_prismarine
fill 149 121 323 149 124 323 minecraft:blue_terracotta
fill 149 121 335 149 132 336 minecraft:magenta_terracotta
setblock 149 121 362 minecraft:dark_prismarine
fill 149 121 363 152 121 363 minecraft:blue_terracotta
fill 150 121 362 153 121 362 minecraft:blue_terracotta
setblock 151 121 325 minecraft:dark_prismarine
setblock 152 121 324 minecraft:dark_prismarine
setblock 152 121 325 minecraft:blue_terracotta
setblock 153 121 323 minecraft:dark_prismarine
fill 153 121 324 156 121 324 minecraft:blue_terracotta
fill 153 121 337 155 121 339 minecraft:dark_oak_planks
fill 153 121 349 155 121 351 minecraft:dark_oak_planks
setblock 153 121 363 minecraft:dark_prismarine
fill 154 121 322 154 129 322 minecraft:black_concrete
fill 154 121 323 157 121 323 minecraft:blue_terracotta
fill 154 121 340 155 121 340 minecraft:dark_oak_planks
fill 154 121 348 155 121 348 minecraft:dark_oak_planks
setblock 154 121 362 minecraft:dark_prismarine
fill 154 121 363 157 121 363 minecraft:blue_terracotta
fill 155 121 362 158 121 362 minecraft:blue_terracotta
fill 156 121 338 156 121 339 minecraft:dark_oak_planks
fill 156 121 349 156 121 350 minecraft:dark_oak_planks
setblock 157 121 324 minecraft:dark_prismarine
setblock 158 121 323 minecraft:dark_prismarine
fill 158 121 324 161 121 324 minecraft:blue_terracotta
fill 158 121 355 158 126 356 minecraft:magenta_terracotta
setblock 158 121 363 minecraft:dark_prismarine
fill 159 121 323 159 124 323 minecraft:blue_terracotta
fill 159 121 356 159 135 356 minecraft:magenta_terracotta
setblock 159 121 362 minecraft:dark_prismarine
fill 159 121 363 162 121 363 minecraft:blue_terracotta
setblock 160 121 361 minecraft:dark_prismarine
fill 160 121 362 163 121 362 minecraft:blue_terracotta
setblock 161 121 325 minecraft:dark_prismarine
fill 161 121 361 164 121 361 minecraft:blue_terracotta
setblock 162 121 324 minecraft:dark_prismarine
fill 162 121 325 165 121 325 minecraft:blue_terracotta
setblock 163 121 323 minecraft:dark_prismarine
fill 163 121 324 163 124 324 minecraft:blue_terracotta
setblock 163 121 363 minecraft:dark_prismarine
fill 164 121 323 164 124 323 minecraft:blue_terracotta
fill 164 121 338 167 121 339 minecraft:dark_oak_planks
fill 164 121 349 167 121 350 minecraft:dark_oak_planks
setblock 164 121 362 minecraft:dark_prismarine
fill 164 121 363 164 124 363 minecraft:blue_terracotta
fill 165 121 337 167 121 337 minecraft:dark_oak_planks
fill 165 121 340 166 121 340 minecraft:dark_oak_planks
fill 165 121 348 166 121 348 minecraft:dark_oak_planks
fill 165 121 351 167 121 351 minecraft:dark_oak_planks
setblock 165 121 361 minecraft:dark_prismarine
fill 165 121 362 165 124 362 minecraft:blue_terracotta
setblock 166 121 325 minecraft:dark_prismarine
fill 166 121 361 166 122 361 minecraft:blue_terracotta
setblock 167 121 324 minecraft:dark_prismarine
setblock 168 121 323 minecraft:dark_prismarine
fill 168 121 324 168 123 324 minecraft:blue_terracotta
setblock 168 121 363 minecraft:dark_prismarine
fill 169 121 323 169 124 323 minecraft:blue_terracotta
setblock 169 121 362 minecraft:dark_prismarine
fill 169 121 363 169 124 363 minecraft:blue_terracotta
fill 170 121 362 170 122 362 minecraft:blue_terracotta
setblock 173 121 323 minecraft:dark_prismarine
setblock 173 121 363 minecraft:dark_prismarine
setblock 174 121 323 minecraft:blue_terracotta
setblock 174 121 363 minecraft:blue_terracotta
setblock 177 121 323 minecraft:blue_terracotta
setblock 178 121 323 minecraft:dark_prismarine
fill 179 121 323 179 124 323 minecraft:blue_terracotta
setblock 179 121 363 minecraft:blue_terracotta
fill 180 121 324 180 122 324 minecraft:blue_terracotta
setblock 180 121 340 minecraft:blue_terracotta
setblock 180 121 341 minecraft:dark_prismarine
fill 180 121 342 180 123 342 minecraft:blue_terracotta
setblock 180 121 346 minecraft:dark_prismarine
fill 180 121 347 180 123 348 minecraft:blue_terracotta
setblock 181 121 325 minecraft:dark_prismarine
fill 181 121 326 181 121 329 minecraft:blue_terracotta
fill 181 121 336 181 123 336 minecraft:blue_terracotta
setblock 181 121 340 minecraft:dark_prismarine
fill 181 121 341 181 124 341 minecraft:blue_terracotta
setblock 181 121 345 minecraft:dark_prismarine
fill 181 121 346 181 124 346 minecraft:blue_terracotta
setblock 181 121 350 minecraft:dark_prismarine
fill 181 121 351 181 124 351 minecraft:blue_terracotta
setblock 182 121 324 minecraft:dark_prismarine
fill 182 121 325 182 121 328 minecraft:blue_terracotta
setblock 182 121 329 minecraft:dark_prismarine
fill 182 121 330 182 124 330 minecraft:blue_terracotta
setblock 182 121 334 minecraft:dark_prismarine
fill 182 121 335 182 124 335 minecraft:blue_terracotta
setblock 182 121 339 minecraft:dark_prismarine
fill 182 121 340 182 124 340 minecraft:blue_terracotta
setblock 182 121 344 minecraft:dark_prismarine
fill 182 121 345 182 124 345 minecraft:blue_terracotta
setblock 182 121 349 minecraft:dark_prismarine
fill 182 121 350 182 124 350 minecraft:blue_terracotta
setblock 182 121 354 minecraft:dark_prismarine
setblock 182 121 359 minecraft:dark_prismarine
setblock 182 121 360 minecraft:blue_terracotta
setblock 141 122 352 minecraft:light_blue_wool
fill 141 122 353 141 131 353 minecraft:black_concrete
setblock 142 122 323 minecraft:dark_prismarine
fill 142 122 324 142 122 327 minecraft:blue_terracotta
setblock 142 122 328 minecraft:dark_prismarine
fill 142 122 329 142 125 329 minecraft:blue_terracotta
setblock 142 122 333 minecraft:dark_prismarine
fill 142 122 334 142 125 334 minecraft:blue_terracotta
setblock 142 122 338 minecraft:dark_prismarine
fill 142 122 339 142 125 339 minecraft:blue_terracotta
setblock 142 122 343 minecraft:dark_prismarine
fill 142 122 344 142 125 344 minecraft:blue_terracotta
setblock 142 122 348 minecraft:dark_prismarine
fill 142 122 349 142 125 349 minecraft:blue_terracotta
fill 142 122 361 142 122 362 minecraft:blue_terracotta
setblock 142 122 363 minecraft:dark_prismarine
fill 143 122 323 143 122 326 minecraft:blue_terracotta
setblock 143 122 327 minecraft:dark_prismarine
fill 143 122 328 143 125 328 minecraft:blue_terracotta
setblock 143 122 331 minecraft:blue_terracotta
setblock 143 122 332 minecraft:dark_prismarine
fill 143 122 333 143 125 333 minecraft:blue_terracotta
setblock 143 122 337 minecraft:dark_prismarine
fill 143 122 338 143 123 338 minecraft:blue_terracotta
setblock 143 122 342 minecraft:dark_prismarine
fill 143 122 343 143 125 343 minecraft:blue_terracotta
setblock 143 122 346 minecraft:blue_terracotta
setblock 143 122 347 minecraft:dark_prismarine
fill 143 122 348 143 125 348 minecraft:blue_terracotta
fill 143 122 350 143 123 350 minecraft:blue_terracotta
setblock 143 122 362 minecraft:dark_prismarine
fill 143 122 363 146 122 363 minecraft:blue_terracotta
fill 144 122 323 144 122 325 minecraft:blue_terracotta
setblock 144 122 326 minecraft:dark_prismarine
fill 144 122 327 144 125 327 minecraft:blue_terracotta
setblock 144 122 331 minecraft:dark_prismarine
setblock 144 122 332 minecraft:blue_terracotta
setblock 144 122 341 minecraft:dark_prismarine
setblock 144 122 342 minecraft:blue_terracotta
setblock 144 122 346 minecraft:dark_prismarine
setblock 144 122 347 minecraft:blue_terracotta
fill 144 122 362 144 123 362 minecraft:blue_terracotta
setblock 145 122 325 minecraft:dark_prismarine
fill 145 122 326 145 125 326 minecraft:blue_terracotta
setblock 146 122 324 minecraft:dark_prismarine
fill 146 122 325 146 125 325 minecraft:blue_terracotta
setblock 147 122 323 minecraft:dark_prismarine
fill 147 122 324 147 125 324 minecraft:blue_terracotta
setblock 147 122 363 minecraft:dark_prismarine
fill 148 122 323 148 125 323 minecraft:blue_terracotta
setblock 148 122 362 minecraft:dark_prismarine
fill 148 122 363 151 122 363 minecraft:blue_terracotta
fill 149 122 362 151 122 362 minecraft:blue_terracotta
setblock 150 122 325 minecraft:dark_prismarine
setblock 151 122 324 minecraft:dark_prismarine
setblock 151 122 325 minecraft:blue_terracotta
setblock 152 122 323 minecraft:dark_prismarine
fill 152 122 324 155 122 324 minecraft:blue_terracotta
setblock 152 122 363 minecraft:dark_prismarine
fill 153 122 323 156 122 323 minecraft:blue_terracotta
fill 153 122 338 155 122 339 minecraft:dark_oak_planks
fill 153 122 349 155 122 350 minecraft:dark_oak_planks
fill 153 122 363 156 122 363 minecraft:blue_terracotta
fill 154 122 337 155 122 337 minecraft:dark_oak_planks
fill 154 122 351 155 122 351 minecraft:dark_oak_planks
setblock 156 122 324 minecraft:dark_prismarine
setblock 157 122 323 minecraft:dark_prismarine
fill 157 122 324 160 122 324 minecraft:blue_terracotta
setblock 157 122 362 minecraft:blue_terracotta
setblock 157 122 363 minecraft:dark_prismarine
fill 158 122 323 158 125 323 minecraft:blue_terracotta
setblock 158 122 362 minecraft:dark_prismarine
fill 158 122 363 161 122 363 minecraft:blue_terracotta
fill 159 122 362 162 122 362 minecraft:blue_terracotta
setblock 161 122 324 minecraft:dark_prismarine
fill 161 122 325 164 122 325 minecraft:blue_terracotta
fill 161 122 361 163 122 361 minecraft:blue_terracotta
setblock 162 122 323 minecraft:dark_prismarine
fill 162 122 324 162 125 324 minecraft:blue_terracotta
setblock 162 122 363 minecraft:dark_prismarine
fill 163 122 323 163 125 323 minecraft:blue_terracotta
setblock 163 122 362 minecraft:dark_prismarine
fill 163 122 363 163 125 363 minecraft:blue_terracotta
setblock 164 122 361 minecraft:dark_prismarine
fill 164 122 362 164 125 362 minecraft:blue_terracotta
setblock 165 122 325 minecraft:dark_prismarine
fill 165 122 337 166 122 339 minecraft:dark_oak_planks
fill 165 122 349 166 122 351 minecraft:dark_oak_planks
fill 165 122 361 165 123 361 minecraft:blue_terracotta
setblock 166 122 324 minecraft:dark_prismarine
setblock 166 122 325 minecraft:blue_terracotta
setblock 167 122 323 minecraft:dark_prismarine
fill 167 122 324 167 124 324 minecraft:blue_terracotta
fill 167 122 338 167 122 339 minecraft:dark_oak_planks
fill 167 122 349 167 122 350 minecraft:dark_oak_planks
setblock 167 122 363 minecraft:dark_prismarine
fill 168 122 323 168 125 323 minecraft:blue_terracotta
setblock 168 122 362 minecraft:dark_prismarine
fill 168 122 363 168 124 363 minecraft:blue_terracotta
fill 169 122 339 170 123 340 minecraft:black_concrete
setblock 169 122 362 minecraft:blue_terracotta
fill 171 122 333 171 123 333 minecraft:spruce_planks
setblock 172 122 323 minecraft:dark_prismarine
setblock 172 122 363 minecraft:dark_prismarine
setblock 177 122 323 minecraft:dark_prismarine
fill 178 122 323 178 125 323 minecraft:blue_terracotta
fill 180 122 341 180 123 341 minecraft:blue_terracotta
setblock 180 122 345 minecraft:dark_prismarine
fill 180 122 346 180 125 346 minecraft:blue_terracotta
setblock 181 122 323 minecraft:blue_terracotta
setblock 181 122 324 minecraft:dark_prismarine
fill 181 122 325 181 122 328 minecraft:blue_terracotta
setblock 181 122 329 minecraft:dark_prismarine
fill 181 122 330 181 124 331 minecraft:blue_terracotta
setblock 181 122 339 minecraft:dark_prismarine
fill 181 122 340 181 125 340 minecraft:blue_terracotta
setblock 181 122 344 minecraft:dark_prismarine
fill 181 122 345 181 125 345 minecraft:blue_terracotta
setblock 181 122 349 minecraft:dark_prismarine
fill 181 122 350 181 125 350 minecraft:blue_terracotta
setblock 182 122 323 minecraft:dark_prismarine
fill 182 122 324 182 122 327 minecraft:blue_terracotta
setblock 182 122 328 minecraft:dark_prismarine
fill 182 122 329 182 125 329 minecraft:blue_terracotta
setblock 182 122 333 minecraft:dark_prismarine
fill 182 122 334 182 125 334 minecraft:blue_terracotta
setblock 182 122 338 minecraft:dark_prismarine
fill 182 122 339 182 125 339 minecraft:blue_terracotta
setblock 182 122 343 minecraft:dark_prismarine
fill 182 122 344 182 125 344 minecraft:blue_terracotta
setblock 182 122 348 minecraft:dark_prismarine
fill 182 122 349 182 125 349 minecraft:blue_terracotta
setblock 182 122 353 minecraft:dark_prismarine
fill 182 122 354 182 125 354 minecraft:blue_terracotta
setblock 182 122 363 minecraft:dark_prismarine
fill 141 123 352 141 131 352 minecraft:black_concrete
fill 142 123 323 142 123 326 minecraft:blue_terracotta
setblock 142 123 327 minecraft:dark_prismarine
fill 142 123 328 142 126 328 minecraft:blue_terracotta
setblock 142 123 332 minecraft:dark_prismarine
fill 142 123 333 142 126 333 minecraft:blue_terracotta
setblock 142 123 337 minecraft:dark_prismarine
fill 142 123 338 142 126 338 minecraft:blue_terracotta
setblock 142 123 342 minecraft:dark_prismarine
fill 142 123 343 142 126 343 minecraft:blue_terracotta
setblock 142 123 347 minecraft:dark_prismarine
fill 142 123 348 142 126 348 minecraft:blue_terracotta
setblock 142 123 352 minecraft:dark_prismarine
setblock 142 123 353 minecraft:purple_concrete
setblock 142 123 361 minecraft:blue_terracotta
setblock 142 123 362 minecraft:dark_prismarine
fill 142 123 363 145 123 363 minecraft:blue_terracotta
fill 143 123 323 143 123 325 minecraft:blue_terracotta
setblock 143 123 326 minecraft:dark_prismarine
fill 143 123 327 143 126 327 minecraft:blue_terracotta
setblock 143 123 331 minecraft:dark_prismarine
fill 143 123 332 143 126 332 minecraft:blue_terracotta
setblock 143 123 336 minecraft:dark_prismarine
setblock 143 123 337 minecraft:blue_terracotta
setblock 143 123 341 minecraft:dark_prismarine
fill 143 123 342 143 124 342 minecraft:blue_terracotta
setblock 143 123 346 minecraft:dark_prismarine
fill 143 123 347 143 126 347 minecraft:blue_terracotta
setblock 143 123 362 minecraft:blue_terracotta
fill 144 123 323 144 123 324 minecraft:blue_terracotta
setblock 144 123 325 minecraft:dark_prismarine
fill 144 123 326 144 126 326 minecraft:blue_terracotta
setblock 144 123 330 minecraft:dark_prismarine
fill 144 123 331 144 126 331 minecraft:blue_terracotta
setblock 144 123 345 minecraft:dark_prismarine
setblock 145 123 324 minecraft:dark_prismarine
fill 145 123 325 145 126 325 minecraft:blue_terracotta
setblock 146 123 323 minecraft:dark_prismarine
fill 146 123 324 146 126 324 minecraft:blue_terracotta
setblock 146 123 363 minecraft:dark_prismarine
fill 147 123 323 147 126 323 minecraft:blue_terracotta
setblock 147 123 362 minecraft:dark_prismarine
fill 147 123 363 150 123 363 minecraft:blue_terracotta
setblock 148 123 362 minecraft:blue_terracotta
setblock 149 123 325 minecraft:dark_prismarine
setblock 150 123 324 minecraft:dark_prismarine
setblock 150 123 325 minecraft:blue_terracotta
setblock 151 123 323 minecraft:dark_prismarine
fill 151 123 324 154 123 324 minecraft:blue_terracotta
fill 151 123 334 151 168 334 minecraft:magenta_terracotta
setblock 151 123 363 minecraft:dark_prismarine
fill 152 123 323 155 123 323 minecraft:blue_terracotta
fill 152 123 363 155 123 363 minecraft:blue_terracotta
fill 154 123 338 155 123 339 minecraft:dark_oak_planks
fill 154 123 349 155 123 350 minecraft:dark_oak_planks
setblock 155 123 324 minecraft:dark_prismarine
setblock 156 123 323 minecraft:dark_prismarine
fill 156 123 324 159 123 324 minecraft:blue_terracotta
setblock 156 123 363 minecraft:dark_prismarine
fill 157 123 323 157 126 323 minecraft:blue_terracotta
fill 157 123 363 160 123 363 minecraft:blue_terracotta
fill 158 123 357 159 135 357 minecraft:magenta_terracotta
fill 158 123 362 161 123 362 minecraft:blue_terracotta
setblock 160 123 324 minecraft:dark_prismarine
setblock 161 123 323 minecraft:dark_prismarine
fill 161 123 324 161 126 324 minecraft:blue_terracotta
setblock 161 123 363 minecraft:dark_prismarine
fill 162 123 323 162 126 323 minecraft:blue_terracotta
fill 162 123 325 163 123 325 minecraft:blue_terracotta
setblock 162 123 361 minecraft:blue_terracotta
setblock 162 123 362 minecraft:dark_prismarine
fill 162 123 363 162 126 363 minecraft:blue_terracotta
setblock 163 123 361 minecraft:dark_prismarine
fill 163 123 362 163 126 362 minecraft:blue_terracotta
setblock 164 123 325 minecraft:dark_prismarine
setblock 164 123 361 minecraft:blue_terracotta
setblock 165 123 324 minecraft:dark_prismarine
fill 165 123 338 166 123 339 minecraft:dark_oak_planks
fill 165 123 349 166 123 350 minecraft:dark_oak_planks
setblock 166 123 323 minecraft:dark_prismarine
fill 166 123 324 166 124 324 minecraft:blue_terracotta
setblock 166 123 363 minecraft:dark_prismarine
fill 167 123 323 167 125 323 minecraft:blue_terracotta
setblock 167 123 362 minecraft:dark_prismarine
fill 167 123 363 167 125 363 minecraft:blue_terracotta
setblock 168 123 362 minecraft:blue_terracotta
setblock 168 123 364 minecraft:light_blue_wool
setblock 173 123 323 minecraft:purple_concrete
setblock 176 123 363 minecraft:purple_concrete
setblock 180 123 324 minecraft:dark_prismarine
setblock 180 123 344 minecraft:dark_prismarine
fill 180 123 345 180 126 345 minecraft:blue_terracotta
setblock 181 123 323 minecraft:dark_prismarine
fill 181 123 324 181 123 327 minecraft:blue_terracotta
setblock 181 123 328 minecraft:dark_prismarine
fill 181 123 329 181 126 329 minecraft:blue_terracotta
setblock 181 123 332 minecraft:blue_terracotta
setblock 181 123 338 minecraft:dark_prismarine
fill 181 123 339 181 126 339 minecraft:blue_terracotta
setblock 181 123 343 minecraft:dark_prismarine
fill 181 123 344 181 126 344 minecraft:blue_terracotta
setblock 181 123 348 minecraft:dark_prismarine
fill 181 123 349 181 126 349 minecraft:blue_terracotta
setblock 181 123 363 minecraft:dark_prismarine
fill 182 123 323 182 123 326 minecraft:blue_terracotta
setblock 182 123 327 minecraft:dark_prismarine
fill 182 123 328 182 126 328 minecraft:blue_terracotta
setblock 182 123 332 minecraft:dark_prismarine
fill 182 123 333 182 126 333 minecraft:blue_terracotta
setblock 182 123 337 minecraft:dark_prismarine
fill 182 123 338 182 126 338 minecraft:blue_terracotta
setblock 182 123 342 minecraft:dark_prismarine
fill 182 123 343 182 126 343 minecraft:blue_terracotta
setblock 182 123 347 minecraft:dark_prismarine
fill 182 123 348 182 126 348 minecraft:blue_terracotta
setblock 182 123 352 minecraft:dark_prismarine
fill 182 123 353 182 126 353 minecraft:blue_terracotta
setblock 182 123 358 minecraft:purple_concrete
setblock 182 123 362 minecraft:dark_prismarine
fill 182 123 363 182 124 363 minecraft:blue_terracotta
fill 142 124 323 142 124 325 minecraft:blue_terracotta
setblock 142 124 326 minecraft:dark_prismarine
fill 142 124 327 142 127 327 minecraft:blue_terracotta
setblock 142 124 331 minecraft:dark_prismarine
fill 142 124 332 142 127 332 minecraft:blue_terracotta
setblock 142 124 336 minecraft:dark_prismarine
fill 142 124 337 142 127 337 minecraft:blue_terracotta
setblock 142 124 341 minecraft:dark_prismarine
fill 142 124 342 142 127 342 minecraft:blue_terracotta
setblock 142 124 346 minecraft:dark_prismarine
fill 142 124 347 142 127 347 minecraft:blue_terracotta
setblock 142 124 351 minecraft:dark_prismarine
fill 142 124 352 142 127 352 minecraft:blue_terracotta
setblock 142 124 359 minecraft:purple_concrete
setblock 142 124 361 minecraft:dark_prismarine
fill 142 124 362 142 126 363 minecraft:blue_terracotta
fill 143 124 323 143 124 324 minecraft:blue_terracotta
setblock 143 124 325 minecraft:dark_prismarine
fill 143 124 326 143 127 326 minecraft:blue_terracotta
setblock 143 124 330 minecraft:dark_prismarine
fill 143 124 331 143 127 331 minecraft:blue_terracotta
setblock 143 124 335 minecraft:dark_prismarine
setblock 143 124 340 minecraft:dark_prismarine
setblock 143 124 341 minecraft:blue_terracotta
setblock 143 124 345 minecraft:dark_prismarine
fill 143 124 346 143 126 346 minecraft:blue_terracotta
setblock 143 124 350 minecraft:dark_prismarine
fill 143 124 363 144 124 363 minecraft:blue_terracotta
setblock 144 124 323 minecraft:blue_terracotta
setblock 144 124 324 minecraft:dark_prismarine
fill 144 124 325 144 127 325 minecraft:blue_terracotta
setblock 144 124 329 minecraft:dark_prismarine
fill 144 124 330 144 127 330 minecraft:blue_terracotta
setblock 145 124 323 minecraft:dark_prismarine
fill 145 124 324 145 127 324 minecraft:blue_terracotta
setblock 145 124 328 minecraft:dark_prismarine
setblock 145 124 363 minecraft:dark_prismarine
fill 146 124 323 146 127 323 minecraft:blue_terracotta
fill 146 124 363 149 124 363 minecraft:blue_terracotta
fill 147 124 326 147 132 326 minecraft:black_concrete
setblock 148 124 325 minecraft:dark_prismarine
setblock 149 124 324 minecraft:dark_prismarine
setblock 149 124 325 minecraft:blue_terracotta
setblock 150 124 323 minecraft:dark_prismarine
fill 150 124 324 153 124 324 minecraft:blue_terracotta
setblock 150 124 363 minecraft:dark_prismarine
fill 151 124 323 154 124 323 minecraft:blue_terracotta
fill 151 124 363 154 124 363 minecraft:blue_terracotta
fill 153 124 344 155 162 344 minecraft:dark_prismarine
setblock 154 124 338 minecraft:dark_oak_planks
fill 154 124 343 155 141 343 minecraft:dark_prismarine
fill 154 124 345 155 162 345 minecraft:dark_prismarine
setblock 154 124 350 minecraft:dark_oak_planks
setblock 155 124 323 minecraft:dark_prismarine
setblock 155 124 363 minecraft:dark_prismarine
fill 156 124 323 156 124 324 minecraft:blue_terracotta
fill 156 124 363 159 124 363 minecraft:blue_terracotta
fill 157 124 324 158 124 324 minecraft:blue_terracotta
setblock 159 124 324 minecraft:dark_prismarine
fill 159 124 362 160 124 362 minecraft:blue_terracotta
setblock 160 124 323 minecraft:dark_prismarine
fill 160 124 324 160 127 324 minecraft:blue_terracotta
setblock 160 124 363 minecraft:dark_prismarine
fill 161 124 323 161 127 323 minecraft:blue_terracotta
setblock 161 124 362 minecraft:dark_prismarine
fill 161 124 363 161 127 363 minecraft:blue_terracotta
fill 162 124 362 162 127 362 minecraft:blue_terracotta
setblock 164 124 324 minecraft:dark_prismarine
setblock 165 124 323 minecraft:dark_prismarine
fill 165 124 324 165 125 324 minecraft:blue_terracotta
setblock 165 124 363 minecraft:dark_prismarine
fill 166 124 323 166 126 323 minecraft:blue_terracotta
setblock 166 124 338 minecraft:dark_oak_planks
setblock 166 124 350 minecraft:dark_oak_planks
setblock 166 124 362 minecraft:dark_prismarine
fill 166 124 363 166 126 363 minecraft:blue_terracotta
fill 168 124 364 168 131 364 minecraft:black_concrete
setblock 180 124 323 minecraft:dark_prismarine
fill 180 124 324 182 125 324 minecraft:blue_terracotta
setblock 180 124 343 minecraft:dark_prismarine
fill 180 124 344 180 125 344 minecraft:blue_terracotta
setblock 180 124 347 minecraft:blue_terracotta
setblock 180 124 348 minecraft:dark_prismarine
fill 181 124 323 182 126 323 minecraft:blue_terracotta
fill 181 124 325 181 124 326 minecraft:blue_terracotta
setblock 181 124 327 minecraft:dark_prismarine
fill 181 124 328 181 127 328 minecraft:blue_terracotta
setblock 181 124 332 minecraft:dark_prismarine
fill 181 124 333 181 126 334 minecraft:blue_terracotta
setblock 181 124 337 minecraft:dark_prismarine
fill 181 124 338 181 127 338 minecraft:blue_terracotta
setblock 181 124 342 minecraft:dark_prismarine
fill 181 124 343 181 127 343 minecraft:blue_terracotta
setblock 181 124 347 minecraft:dark_prismarine
fill 181 124 348 181 127 348 minecraft:blue_terracotta
setblock 182 124 325 minecraft:blue_terracotta
setblock 182 124 326 minecraft:dark_prismarine
fill 182 124 327 182 127 327 minecraft:blue_terracotta
setblock 182 124 331 minecraft:dark_prismarine
fill 182 124 332 182 127 332 minecraft:blue_terracotta
setblock 182 124 336 minecraft:dark_prismarine
fill 182 124 337 182 127 337 minecraft:blue_terracotta
setblock 182 124 341 minecraft:dark_prismarine
fill 182 124 342 182 127 342 minecraft:blue_terracotta
setblock 182 124 346 minecraft:dark_prismarine
fill 182 124 347 182 127 347 minecraft:blue_terracotta
setblock 182 124 351 minecraft:dark_prismarine
fill 182 124 352 182 127 352 minecraft:blue_terracotta
fill 142 125 323 142 125 324 minecraft:blue_terracotta
setblock 142 125 325 minecraft:dark_prismarine
fill 142 125 326 142 128 326 minecraft:blue_terracotta
setblock 142 125 330 minecraft:dark_prismarine
fill 142 125 331 142 128 331 minecraft:blue_terracotta
setblock 142 125 335 minecraft:dark_prismarine
fill 142 125 336 142 128 336 minecraft:blue_terracotta
setblock 142 125 340 minecraft:dark_prismarine
fill 142 125 341 142 127 341 minecraft:blue_terracotta
setblock 142 125 345 minecraft:dark_prismarine
fill 142 125 346 142 128 346 minecraft:blue_terracotta
setblock 142 125 350 minecraft:dark_prismarine
fill 142 125 351 142 128 351 minecraft:blue_terracotta
fill 142 125 353 142 126 353 minecraft:blue_terracotta
setblock 143 125 323 minecraft:blue_terracotta
setblock 143 125 324 minecraft:dark_prismarine
fill 143 125 325 143 128 325 minecraft:blue_terracotta
setblock 143 125 329 minecraft:dark_prismarine
fill 143 125 330 143 128 330 minecraft:blue_terracotta
setblock 143 125 334 minecraft:dark_prismarine
setblock 143 125 344 minecraft:dark_prismarine
fill 143 125 345 143 126 345 minecraft:blue_terracotta
setblock 143 125 349 minecraft:dark_prismarine
setblock 143 125 363 minecraft:blue_terracotta
setblock 144 125 322 minecraft:light_blue_wool
setblock 144 125 323 minecraft:dark_prismarine
fill 144 125 324 144 128 324 minecraft:blue_terracotta
setblock 144 125 328 minecraft:dark_prismarine
fill 144 125 329 144 128 329 minecraft:blue_terracotta
setblock 144 125 332 minecraft:light[level=12]
setblock 144 125 333 minecraft:light[level=13]
setblock 144 125 339 minecraft:light[level=12]
setblock 144 125 341 minecraft:light[level=13]
setblock 144 125 346 minecraft:light[level=12]
setblock 144 125 349 minecraft:light[level=13]
setblock 144 125 353 minecraft:light[level=12]
setblock 144 125 357 minecraft:light[level=13]
setblock 144 125 360 minecraft:light[level=12]
setblock 144 125 363 minecraft:dark_prismarine
fill 145 125 323 145 128 323 minecraft:blue_terracotta
setblock 145 125 327 minecraft:dark_prismarine
fill 145 125 363 148 125 363 minecraft:blue_terracotta
setblock 147 125 325 minecraft:dark_prismarine
setblock 148 125 324 minecraft:dark_prismarine
setblock 148 125 325 minecraft:blue_terracotta
setblock 149 125 323 minecraft:dark_prismarine
fill 149 125 324 151 125 324 minecraft:blue_terracotta
setblock 149 125 363 minecraft:dark_prismarine
fill 150 125 323 153 125 323 minecraft:blue_terracotta
setblock 150 125 363 minecraft:blue_terracotta
setblock 151 125 325 minecraft:light[level=12]
setblock 151 125 332 minecraft:light[level=12]
setblock 151 125 339 minecraft:light[level=12]
setblock 151 125 346 minecraft:light[level=12]
setblock 151 125 353 minecraft:light[level=12]
setblock 151 125 360 minecraft:light[level=12]
setblock 152 125 325 minecraft:light[level=13]
setblock 152 125 333 minecraft:light[level=13]
setblock 152 125 341 minecraft:light[level=13]
setblock 152 125 349 minecraft:light[level=13]
setblock 152 125 357 minecraft:light[level=13]
fill 153 125 342 153 126 343 minecraft:black_concrete
fill 153 125 345 153 126 345 minecraft:black_concrete
setblock 154 125 323 minecraft:dark_prismarine
fill 154 125 342 155 126 342 minecraft:black_concrete
fill 154 125 346 156 126 346 minecraft:black_concrete
fill 155 125 323 156 127 323 minecraft:blue_terracotta
fill 155 125 363 158 125 363 minecraft:blue_terracotta
fill 157 125 358 157 193 358 minecraft:magenta_terracotta
setblock 158 125 322 minecraft:light_blue_wool
setblock 158 125 324 minecraft:dark_prismarine
setblock 158 125 325 minecraft:light[level=12]
setblock 158 125 332 minecraft:light[level=12]
setblock 158 125 339 minecraft:light[level=12]
setblock 158 125 346 minecraft:light[level=12]
setblock 158 125 353 minecraft:light[level=12]
setblock 158 125 360 minecraft:light[level=12]
setblock 159 125 323 minecraft:dark_prismarine
fill 159 125 324 159 128 324 minecraft:blue_terracotta
setblock 159 125 362 minecraft:blue_terracotta
setblock 159 125 363 minecraft:dark_prismarine
fill 160 125 323 160 128 323 minecraft:blue_terracotta
setblock 160 125 325 minecraft:light[level=13]
setblock 160 125 333 minecraft:light[level=13]
setblock 160 125 341 minecraft:light[level=13]
setblock 160 125 349 minecraft:light[level=13]
setblock 160 125 357 minecraft:light[level=13]
setblock 160 125 362 minecraft:dark_prismarine
fill 160 125 363 160 128 363 minecraft:blue_terracotta
fill 161 125 362 161 127 362 minecraft:blue_terracotta
setblock 163 125 324 minecraft:dark_prismarine
setblock 164 125 323 minecraft:dark_prismarine
fill 164 125 324 164 126 324 minecraft:blue_terracotta
setblock 164 125 363 minecraft:dark_prismarine
fill 165 125 323 165 127 323 minecraft:blue_terracotta
setblock 165 125 325 minecraft:light[level=12]
fill 165 125 329 166 135 330 minecraft:magenta_terracotta
setblock 165 125 332 minecraft:light[level=12]
setblock 165 125 339 minecraft:light[level=12]
setblock 165 125 346 minecraft:light[level=12]
setblock 165 125 353 minecraft:light[level=12]
setblock 165 125 360 minecraft:light[level=12]
setblock 165 125 362 minecraft:dark_prismarine
fill 165 125 363 165 127 363 minecraft:blue_terracotta
setblock 168 125 325 minecraft:light[level=13]
setblock 168 125 333 minecraft:light[level=13]
setblock 168 125 341 minecraft:light[level=13]
setblock 168 125 349 minecraft:light[level=13]
setblock 168 125 357 minecraft:light[level=13]
setblock 172 125 325 minecraft:light[level=12]
setblock 172 125 332 minecraft:light[level=12]
setblock 172 125 339 minecraft:light[level=12]
setblock 172 125 346 minecraft:light[level=12]
fill 172 125 351 172 168 351 minecraft:magenta_terracotta
setblock 172 125 353 minecraft:light[level=12]
setblock 172 125 360 minecraft:light[level=12]
setblock 176 125 325 minecraft:light[level=13]
setblock 176 125 333 minecraft:light[level=13]
setblock 176 125 341 minecraft:light[level=13]
setblock 176 125 349 minecraft:light[level=13]
setblock 176 125 357 minecraft:light[level=13]
setblock 179 125 323 minecraft:dark_prismarine
setblock 179 125 325 minecraft:light[level=12]
setblock 179 125 332 minecraft:light[level=12]
setblock 179 125 339 minecraft:light[level=12]
setblock 179 125 346 minecraft:light[level=12]
setblock 179 125 353 minecraft:light[level=12]
setblock 179 125 360 minecraft:light[level=12]
fill 180 125 323 180 128 323 minecraft:blue_terracotta
setblock 180 125 347 minecraft:dark_prismarine
fill 180 125 348 180 128 348 minecraft:blue_terracotta
setblock 181 125 325 minecraft:blue_terracotta
setblock 181 125 326 minecraft:dark_prismarine
fill 181 125 327 181 128 327 minecraft:blue_terracotta
setblock 181 125 330 minecraft:blue_terracotta
setblock 181 125 331 minecraft:dark_prismarine
fill 181 125 332 181 128 332 minecraft:blue_terracotta
setblock 181 125 335 minecraft:blue_terracotta
setblock 181 125 341 minecraft:dark_prismarine
fill 181 125 342 181 128 342 minecraft:blue_terracotta
setblock 181 125 346 minecraft:dark_prismarine
fill 181 125 347 181 128 347 minecraft:blue_terracotta
setblock 181 125 351 minecraft:dark_prismarine
setblock 182 125 325 minecraft:dark_prismarine
fill 182 125 326 182 128 326 minecraft:blue_terracotta
setblock 182 125 330 minecraft:dark_prismarine
fill 182 125 331 182 128 331 minecraft:blue_terracotta
setblock 182 125 335 minecraft:dark_prismarine
fill 182 125 336 182 128 336 minecraft:blue_terracotta
setblock 182 125 340 minecraft:dark_prismarine
fill 182 125 341 182 128 341 minecraft:blue_terracotta
setblock 182 125 345 minecraft:dark_prismarine
fill 182 125 346 182 128 346 minecraft:blue_terracotta
setblock 182 125 350 minecraft:dark_prismarine
fill 182 125 351 182 128 351 minecraft:blue_terracotta
fill 141 126 357 141 131 357 minecraft:black_concrete
setblock 141 126 358 minecraft:cyan_concrete
fill 141 126 359 141 128 359 minecraft:black_concrete
setblock 142 126 323 minecraft:blue_terracotta
setblock 142 126 324 minecraft:dark_prismarine
fill 142 126 325 142 129 325 minecraft:blue_terracotta
setblock 142 126 329 minecraft:dark_prismarine
fill 142 126 330 142 129 330 minecraft:blue_terracotta
setblock 142 126 334 minecraft:dark_prismarine
fill 142 126 335 142 129 335 minecraft:blue_terracotta
setblock 142 126 339 minecraft:dark_prismarine
fill 142 126 340 142 127 340 minecraft:blue_terracotta
setblock 142 126 344 minecraft:dark_prismarine
fill 142 126 345 142 129 345 minecraft:blue_terracotta
setblock 142 126 349 minecraft:dark_prismarine
fill 142 126 350 142 129 350 minecraft:blue_terracotta
setblock 143 126 323 minecraft:dark_prismarine
fill 143 126 324 143 129 324 minecraft:blue_terracotta
setblock 143 126 328 minecraft:dark_prismarine
fill 143 126 329 143 129 329 minecraft:blue_terracotta
setblock 143 126 333 minecraft:dark_prismarine
fill 143 126 334 143 129 334 minecraft:blue_terracotta
setblock 143 126 348 minecraft:dark_prismarine
fill 143 126 349 143 129 349 minecraft:blue_terracotta
setblock 143 126 363 minecraft:dark_prismarine
fill 144 126 322 144 131 322 minecraft:black_concrete
fill 144 126 323 144 129 323 minecraft:blue_terracotta
setblock 144 126 327 minecraft:dark_prismarine
fill 144 126 328 144 129 328 minecraft:blue_terracotta
fill 144 126 363 147 126 363 minecraft:blue_terracotta
setblock 146 126 325 minecraft:dark_prismarine
setblock 147 126 324 minecraft:dark_prismarine
setblock 147 126 325 minecraft:blue_terracotta
setblock 148 126 323 minecraft:dark_prismarine
fill 148 126 324 150 126 324 minecraft:blue_terracotta
setblock 148 126 363 minecraft:dark_prismarine
fill 149 126 323 152 126 323 minecraft:blue_terracotta
setblock 150 126 363 minecraft:purple_concrete
fill 152 126 342 152 126 345 minecraft:black_concrete
setblock 153 126 323 minecraft:dark_prismarine
setblock 153 126 346 minecraft:black_concrete
fill 154 126 323 154 129 323 minecraft:blue_terracotta
fill 154 126 341 156 126 341 minecraft:black_concrete
fill 154 126 347 156 126 347 minecraft:black_concrete
fill 156 126 363 157 126 363 minecraft:blue_terracotta
fill 158 126 322 158 131 322 minecraft:black_concrete
setblock 158 126 323 minecraft:dark_prismarine
setblock 158 126 324 minecraft:blue_terracotta
setblock 158 126 363 minecraft:dark_prismarine
fill 159 126 323 159 129 323 minecraft:blue_terracotta
fill 159 126 363 159 129 363 minecraft:blue_terracotta
setblock 160 126 362 minecraft:blue_terracotta
setblock 162 126 324 minecraft:dark_prismarine
setblock 163 126 323 minecraft:dark_prismarine
setblock 163 126 324 minecraft:blue_terracotta
setblock 163 126 363 minecraft:dark_prismarine
fill 164 126 323 164 128 323 minecraft:blue_terracotta
fill 164 126 363 164 129 363 minecraft:blue_terracotta
setblock 169 126 363 minecraft:purple_concrete
setblock 174 126 323 minecraft:purple_concrete
fill 175 126 363 175 127 363 minecraft:purple_concrete
setblock 178 126 323 minecraft:dark_prismarine
fill 179 126 323 179 129 323 minecraft:blue_terracotta
fill 180 126 324 181 126 324 minecraft:blue_terracotta
fill 180 126 327 180 127 329 minecraft:blue_terracotta
setblock 180 126 346 minecraft:dark_prismarine
fill 180 126 347 180 129 347 minecraft:blue_terracotta
setblock 181 126 325 minecraft:dark_prismarine
fill 181 126 326 181 129 326 minecraft:blue_terracotta
setblock 181 126 330 minecraft:dark_prismarine
fill 181 126 331 181 129 331 minecraft:blue_terracotta
setblock 181 126 335 minecraft:dark_prismarine
fill 181 126 336 181 128 337 minecraft:blue_terracotta
setblock 181 126 340 minecraft:dark_prismarine
fill 181 126 341 181 129 341 minecraft:blue_terracotta
setblock 181 126 345 minecraft:dark_prismarine
fill 181 126 346 181 129 346 minecraft:blue_terracotta
setblock 181 126 350 minecraft:dark_prismarine
fill 181 126 351 181 128 352 minecraft:blue_terracotta
setblock 182 126 324 minecraft:dark_prismarine
fill 182 126 325 182 129 325 minecraft:blue_terracotta
setblock 182 126 329 minecraft:dark_prismarine
fill 182 126 330 182 129 330 minecraft:blue_terracotta
setblock 182 126 334 minecraft:dark_prismarine
fill 182 126 335 182 129 335 minecraft:blue_terracotta
setblock 182 126 339 minecraft:dark_prismarine
fill 182 126 340 182 129 340 minecraft:blue_terracotta
setblock 182 126 344 minecraft:dark_prismarine
fill 182 126 345 182 129 345 minecraft:blue_terracotta
setblock 182 126 349 minecraft:dark_prismarine
fill 182 126 350 182 129 350 minecraft:blue_terracotta
setblock 182 126 354 minecraft:dark_prismarine
setblock 182 126 359 minecraft:purple_concrete
setblock 183 126 332 minecraft:cyan_concrete
setblock 183 126 343 minecraft:cyan_concrete
fill 141 127 358 141 131 358 minecraft:black_concrete
setblock 142 127 323 minecraft:dark_prismarine
fill 142 127 324 142 130 324 minecraft:blue_terracotta
setblock 142 127 328 minecraft:dark_prismarine
fill 142 127 329 142 130 329 minecraft:blue_terracotta
setblock 142 127 333 minecraft:dark_prismarine
fill 142 127 334 142 130 334 minecraft:blue_terracotta
setblock 142 127 338 minecraft:dark_prismarine
fill 142 127 339 142 130 339 minecraft:blue_terracotta
setblock 142 127 343 minecraft:dark_prismarine
fill 142 127 344 142 130 344 minecraft:blue_terracotta
setblock 142 127 348 minecraft:dark_prismarine
fill 142 127 349 142 130 349 minecraft:blue_terracotta
setblock 142 127 353 minecraft:dark_prismarine
fill 142 127 354 142 130 354 minecraft:blue_terracotta
fill 142 127 358 142 128 358 minecraft:purple_concrete
setblock 142 127 362 minecraft:blue_terracotta
setblock 142 127 363 minecraft:dark_prismarine
fill 143 127 323 143 130 323 minecraft:blue_terracotta
setblock 143 127 327 minecraft:dark_prismarine
fill 143 127 328 143 130 328 minecraft:blue_terracotta
setblock 143 127 332 minecraft:dark_prismarine
fill 143 127 333 143 130 333 minecraft:blue_terracotta
setblock 143 127 347 minecraft:dark_prismarine
setblock 143 127 348 minecraft:blue_terracotta
fill 143 127 350 143 128 350 minecraft:blue_terracotta
fill 143 127 363 146 127 363 minecraft:blue_terracotta
setblock 144 127 326 minecraft:dark_prismarine
fill 144 127 327 144 130 327 minecraft:blue_terracotta
setblock 144 127 331 minecraft:dark_prismarine
setblock 145 127 325 minecraft:dark_prismarine
setblock 146 127 324 minecraft:dark_prismarine
setblock 146 127 325 minecraft:blue_terracotta
setblock 147 127 323 minecraft:dark_prismarine
fill 147 127 324 148 128 324 minecraft:blue_terracotta
fill 148 127 323 151 127 323 minecraft:blue_terracotta
setblock 152 127 323 minecraft:dark_prismarine
setblock 153 127 323 minecraft:blue_terracotta
setblock 156 127 363 minecraft:blue_terracotta
setblock 157 127 323 minecraft:dark_prismarine
setblock 157 127 363 minecraft:dark_prismarine
fill 158 127 323 158 130 323 minecraft:blue_terracotta
fill 158 127 356 158 148 356 minecraft:magenta_terracotta
fill 158 127 363 158 130 363 minecraft:blue_terracotta
setblock 161 127 324 minecraft:dark_prismarine
setblock 162 127 323 minecraft:dark_prismarine
setblock 162 127 324 minecraft:blue_terracotta
setblock 162 127 363 minecraft:dark_prismarine
fill 163 127 323 163 130 323 minecraft:blue_terracotta
fill 163 127 363 163 130 363 minecraft:blue_terracotta
fill 166 127 331 166 134 331 minecraft:magenta_terracotta
setblock 168 127 323 minecraft:purple_concrete
fill 178 127 323 178 130 323 minecraft:blue_terracotta
setblock 180 127 324 minecraft:blue_terracotta
fill 180 127 326 180 130 326 minecraft:blue_terracotta
setblock 180 127 330 minecraft:dark_prismarine
fill 180 127 331 180 130 331 minecraft:blue_terracotta
fill 180 127 346 180 128 346 minecraft:blue_terracotta
setblock 180 127 349 minecraft:blue_terracotta
setblock 181 127 323 minecraft:blue_terracotta
setblock 181 127 324 minecraft:dark_prismarine
fill 181 127 325 181 130 325 minecraft:blue_terracotta
setblock 181 127 329 minecraft:dark_prismarine
fill 181 127 330 181 130 330 minecraft:blue_terracotta
setblock 181 127 333 minecraft:blue_terracotta
setblock 181 127 334 minecraft:dark_prismarine
fill 181 127 335 181 130 335 minecraft:blue_terracotta
setblock 181 127 339 minecraft:dark_prismarine
fill 181 127 340 181 130 340 minecraft:blue_terracotta
setblock 181 127 344 minecraft:dark_prismarine
fill 181 127 345 181 130 345 minecraft:blue_terracotta
setblock 181 127 349 minecraft:dark_prismarine
fill 181 127 350 181 130 350 minecraft:blue_terracotta
setblock 181 127 363 minecraft:purple_concrete
setblock 182 127 323 minecraft:dark_prismarine
fill 182 127 324 182 130 324 minecraft:blue_terracotta
setblock 182 127 328 minecraft:dark_prismarine
fill 182 127 329 182 130 329 minecraft:blue_terracotta
setblock 182 127 333 minecraft:dark_prismarine
fill 182 127 334 182 130 334 minecraft:blue_terracotta
setblock 182 127 338 minecraft:dark_prismarine
fill 182 127 339 182 130 339 minecraft:blue_terracotta
setblock 182 127 343 minecraft:dark_prismarine
fill 182 127 344 182 130 344 minecraft:blue_terracotta
setblock 182 127 348 minecraft:dark_prismarine
fill 182 127 349 182 130 349 minecraft:blue_terracotta
setblock 182 127 353 minecraft:dark_prismarine
fill 182 127 354 182 129 355 minecraft:blue_terracotta
fill 183 127 332 183 131 332 minecraft:black_concrete
fill 183 127 343 183 131 343 minecraft:black_concrete
fill 141 128 328 142 128 328 minecraft:blue_terracotta
fill 141 128 333 141 131 333 minecraft:black_concrete
fill 141 128 334 141 128 335 minecraft:blue_terracotta
fill 141 128 343 142 128 343 minecraft:blue_terracotta
fill 141 128 356 142 128 356 minecraft:blue_terracotta
fill 141 128 361 141 128 362 minecraft:blue_terracotta
setblock 141 128 364 minecraft:blue_terracotta
fill 142 128 323 142 131 323 minecraft:blue_terracotta
setblock 142 128 327 minecraft:dark_prismarine
setblock 142 128 332 minecraft:dark_prismarine
fill 142 128 333 142 131 333 minecraft:blue_terracotta
setblock 142 128 337 minecraft:dark_prismarine
fill 142 128 338 142 131 338 minecraft:blue_terracotta
setblock 142 128 342 minecraft:dark_prismarine
setblock 142 128 347 minecraft:dark_prismarine
fill 142 128 348 142 131 348 minecraft:blue_terracotta
setblock 142 128 352 minecraft:dark_prismarine
fill 142 128 353 142 131 353 minecraft:blue_terracotta
fill 142 128 355 142 129 355 minecraft:blue_terracotta
setblock 142 128 362 minecraft:dark_prismarine
fill 142 128 363 145 128 363 minecraft:blue_terracotta
setblock 143 128 326 minecraft:dark_prismarine
fill 143 128 327 143 131 327 minecraft:blue_terracotta
setblock 143 128 331 minecraft:dark_prismarine
fill 143 128 332 143 131 332 minecraft:blue_terracotta
setblock 143 128 351 minecraft:dark_prismarine
setblock 144 128 325 minecraft:dark_prismarine
fill 144 128 326 144 131 326 minecraft:blue_terracotta
setblock 144 128 330 minecraft:dark_prismarine
fill 144 128 331 144 131 331 minecraft:blue_terracotta
setblock 145 128 324 minecraft:dark_prismarine
fill 145 128 325 145 129 325 minecraft:blue_terracotta
setblock 146 128 323 minecraft:dark_prismarine
fill 146 128 324 146 131 324 minecraft:blue_terracotta
setblock 146 128 363 minecraft:dark_prismarine
setblock 147 128 322 minecraft:cyan_concrete
fill 147 128 323 150 128 323 minecraft:blue_terracotta
setblock 147 128 364 minecraft:blue_terracotta
setblock 149 128 322 minecraft:blue_terracotta
setblock 151 128 323 minecraft:dark_prismarine
fill 153 128 364 155 128 364 minecraft:blue_terracotta
setblock 155 128 323 minecraft:blue_terracotta
setblock 156 128 322 minecraft:blue_terracotta
setblock 156 128 323 minecraft:dark_prismarine
setblock 156 128 363 minecraft:dark_prismarine
fill 157 128 323 157 131 323 minecraft:blue_terracotta
fill 157 128 363 157 130 364 minecraft:blue_terracotta
setblock 160 128 324 minecraft:dark_prismarine
setblock 161 128 323 minecraft:dark_prismarine
setblock 161 128 324 minecraft:blue_terracotta
setblock 161 128 363 minecraft:dark_prismarine
fill 162 128 323 162 131 323 minecraft:blue_terracotta
fill 162 128 363 162 131 363 minecraft:blue_terracotta
fill 165 128 364 165 132 364 minecraft:black_concrete
fill 166 128 364 166 130 364 minecraft:blue_terracotta
fill 167 128 364 167 131 364 minecraft:black_concrete
fill 172 128 322 172 129 322 minecraft:blue_terracotta
fill 172 128 350 172 152 350 minecraft:magenta_terracotta
setblock 179 128 324 minecraft:blue_terracotta
setblock 180 128 324 minecraft:dark_prismarine
fill 180 128 327 180 128 328 minecraft:blue_terracotta
setblock 180 128 329 minecraft:dark_prismarine
fill 180 128 330 180 131 330 minecraft:blue_terracotta
fill 180 128 332 180 128 333 minecraft:blue_terracotta
setblock 180 128 349 minecraft:dark_prismarine
fill 180 128 350 180 131 350 minecraft:blue_terracotta
setblock 181 128 323 minecraft:dark_prismarine
fill 181 128 324 181 131 324 minecraft:blue_terracotta
setblock 181 128 328 minecraft:dark_prismarine
fill 181 128 329 181 131 329 minecraft:blue_terracotta
setblock 181 128 333 minecraft:dark_prismarine
fill 181 128 334 181 131 334 minecraft:blue_terracotta
setblock 181 128 338 minecraft:dark_prismarine
fill 181 128 339 181 131 339 minecraft:blue_terracotta
setblock 181 128 343 minecraft:dark_prismarine
fill 181 128 344 181 131 344 minecraft:blue_terracotta
setblock 181 128 348 minecraft:dark_prismarine
fill 181 128 349 181 131 349 minecraft:blue_terracotta
setblock 181 128 353 minecraft:dark_prismarine
fill 182 128 323 183 128 323 minecraft:blue_terracotta
setblock 182 128 327 minecraft:dark_prismarine
fill 182 128 328 182 131 328 minecraft:blue_terracotta
setblock 182 128 332 minecraft:dark_prismarine
fill 182 128 333 182 131 333 minecraft:blue_terracotta
setblock 182 128 337 minecraft:dark_prismarine
fill 182 128 338 182 131 338 minecraft:blue_terracotta
setblock 182 128 342 minecraft:dark_prismarine
fill 182 128 343 182 131 343 minecraft:blue_terracotta
setblock 182 128 347 minecraft:dark_prismarine
fill 182 128 348 182 131 348 minecraft:blue_terracotta
setblock 182 128 352 minecraft:dark_prismarine
fill 182 128 353 182 131 353 minecraft:blue_terracotta
fill 183 128 325 183 131 326 minecraft:black_concrete
setblock 183 128 327 minecraft:blue_terracotta
setblock 183 128 330 minecraft:blue_terracotta
setblock 183 128 344 minecraft:blue_terracotta
fill 183 128 346 183 131 346 minecraft:black_concrete
fill 183 128 347 183 129 347 minecraft:blue_terracotta
fill 183 128 348 183 131 348 minecraft:black_concrete
setblock 183 128 351 minecraft:blue_terracotta
fill 183 128 358 183 128 359 minecraft:blue_terracotta
fill 183 128 360 183 131 360 minecraft:black_concrete
setblock 141 129 322 minecraft:blue_terracotta
fill 141 129 323 141 131 323 minecraft:black_concrete
fill 141 129 328 141 133 328 minecraft:black_concrete
fill 141 129 334 141 131 335 minecraft:black_concrete
fill 141 129 343 141 132 343 minecraft:black_concrete
fill 141 129 356 141 131 356 minecraft:black_concrete
fill 141 129 359 142 129 360 minecraft:blue_terracotta
fill 141 129 361 141 131 362 minecraft:black_concrete
fill 141 129 364 141 131 364 minecraft:black_concrete
setblock 142 129 326 minecraft:dark_prismarine
fill 142 129 327 142 131 328 minecraft:blue_terracotta
setblock 142 129 331 minecraft:dark_prismarine
fill 142 129 332 142 132 332 minecraft:blue_terracotta
setblock 142 129 336 minecraft:dark_prismarine
fill 142 129 337 142 132 337 minecraft:blue_terracotta
setblock 142 129 343 minecraft:blue_terracotta
setblock 142 129 346 minecraft:dark_prismarine
fill 142 129 347 142 132 347 minecraft:blue_terracotta
setblock 142 129 351 minecraft:dark_prismarine
fill 142 129 352 143 131 352 minecraft:blue_terracotta
setblock 142 129 356 minecraft:dark_prismarine
fill 142 129 357 142 131 358 minecraft:blue_terracotta
setblock 142 129 361 minecraft:dark_prismarine
fill 142 129 362 142 131 363 minecraft:blue_terracotta
setblock 143 129 325 minecraft:dark_prismarine
fill 143 129 326 143 132 326 minecraft:blue_terracotta
setblock 143 129 330 minecraft:dark_prismarine
fill 143 129 331 143 132 331 minecraft:blue_terracotta
setblock 143 129 335 minecraft:dark_prismarine
setblock 143 129 350 minecraft:dark_prismarine
fill 143 129 351 143 132 351 minecraft:blue_terracotta
fill 143 129 363 144 129 363 minecraft:blue_terracotta
setblock 144 129 324 minecraft:dark_prismarine
fill 144 129 325 144 131 325 minecraft:blue_terracotta
setblock 144 129 329 minecraft:dark_prismarine
fill 144 129 330 144 132 330 minecraft:blue_terracotta
fill 144 129 332 144 130 332 minecraft:blue_terracotta
setblock 145 129 323 minecraft:dark_prismarine
fill 145 129 324 145 132 324 minecraft:blue_terracotta
setblock 145 129 363 minecraft:dark_prismarine
setblock 145 129 364 minecraft:blue_terracotta
fill 146 129 323 149 129 323 minecraft:blue_terracotta
setblock 147 129 322 minecraft:black_concrete
setblock 147 129 324 minecraft:blue_terracotta
fill 147 129 364 147 131 364 minecraft:black_concrete
setblock 148 129 364 minecraft:blue_terracotta
fill 149 129 322 149 131 322 minecraft:black_concrete
setblock 149 129 363 minecraft:purple_concrete
setblock 150 129 323 minecraft:dark_prismarine
setblock 151 129 364 minecraft:blue_terracotta
fill 153 129 364 155 131 364 minecraft:black_concrete
setblock 155 129 323 minecraft:dark_prismarine
setblock 155 129 363 minecraft:dark_prismarine
fill 156 129 322 156 131 322 minecraft:black_concrete
fill 156 129 323 156 132 323 minecraft:blue_terracotta
fill 156 129 363 156 132 363 minecraft:blue_terracotta
setblock 159 129 324 minecraft:dark_prismarine
fill 159 129 362 160 129 362 minecraft:blue_terracotta
setblock 160 129 323 minecraft:dark_prismarine
setblock 160 129 324 minecraft:blue_terracotta
setblock 160 129 363 minecraft:dark_prismarine
fill 161 129 323 161 132 323 minecraft:blue_terracotta
setblock 161 129 362 minecraft:dark_prismarine
fill 161 129 363 161 132 363 minecraft:blue_terracotta
setblock 162 129 364 minecraft:blue_terracotta
setblock 164 129 364 minecraft:blue_terracotta
setblock 168 129 363 minecraft:purple_concrete
setblock 170 129 364 minecraft:blue_terracotta
fill 171 129 364 171 131 364 minecraft:black_concrete
setblock 174 129 364 minecraft:blue_terracotta
setblock 175 129 323 minecraft:purple_concrete
fill 175 129 351 175 132 351 minecraft:magenta_terracotta
fill 176 129 322 176 131 322 minecraft:black_concrete
fill 177 129 322 177 129 323 minecraft:blue_terracotta
fill 178 129 322 179 129 322 minecraft:black_concrete
fill 178 129 337 178 135 338 minecraft:magenta_terracotta
setblock 179 129 324 minecraft:dark_prismarine
setblock 180 129 323 minecraft:dark_prismarine
fill 180 129 324 180 131 325 minecraft:blue_terracotta
setblock 180 129 327 minecraft:blue_terracotta
setblock 180 129 328 minecraft:dark_prismarine
fill 180 129 329 180 132 329 minecraft:blue_terracotta
setblock 180 129 332 minecraft:blue_terracotta
setblock 180 129 333 minecraft:dark_prismarine
fill 180 129 334 180 131 335 minecraft:blue_terracotta
setblock 180 129 348 minecraft:dark_prismarine
fill 180 129 349 180 132 349 minecraft:blue_terracotta
fill 180 129 351 181 129 351 minecraft:blue_terracotta
fill 181 129 323 182 131 323 minecraft:blue_terracotta
setblock 181 129 327 minecraft:dark_prismarine
fill 181 129 328 181 132 328 minecraft:blue_terracotta
setblock 181 129 332 minecraft:dark_prismarine
fill 181 129 333 181 132 333 minecraft:blue_terracotta
setblock 181 129 336 minecraft:blue_terracotta
setblock 181 129 337 minecraft:dark_prismarine
fill 181 129 338 181 132 338 minecraft:blue_terracotta
setblock 181 129 342 minecraft:dark_prismarine
fill 181 129 343 181 132 343 minecraft:blue_terracotta
setblock 181 129 347 minecraft:dark_prismarine
fill 181 129 348 181 132 348 minecraft:blue_terracotta
setblock 181 129 352 minecraft:dark_prismarine
fill 181 129 353 181 131 354 minecraft:blue_terracotta
setblock 182 129 322 minecraft:blue_terracotta
setblock 182 129 326 minecraft:dark_prismarine
fill 182 129 327 182 132 327 minecraft:blue_terracotta
setblock 182 129 331 minecraft:dark_prismarine
fill 182 129 332 182 132 332 minecraft:blue_terracotta
setblock 182 129 336 minecraft:dark_prismarine
fill 182 129 337 183 129 337 minecraft:blue_terracotta
setblock 182 129 341 minecraft:dark_prismarine
fill 182 129 342 182 132 342 minecraft:blue_terracotta
setblock 182 129 346 minecraft:dark_prismarine
fill 182 129 347 182 132 347 minecraft:blue_terracotta
setblock 182 129 351 minecraft:dark_prismarine
fill 182 129 352 182 132 352 minecraft:blue_terracotta
setblock 182 129 356 minecraft:dark_prismarine
setblock 182 129 360 minecraft:purple_concrete
fill 183 129 322 183 131 323 minecraft:black_concrete
fill 183 129 327 183 132 327 minecraft:black_concrete
fill 183 129 330 183 131 330 minecraft:black_concrete
fill 183 129 344 183 131 344 minecraft:black_concrete
fill 183 129 351 183 131 351 minecraft:black_concrete
fill 183 129 358 183 131 359 minecraft:black_concrete
fill 141 130 322 141 131 322 minecraft:black_concrete
setblock 141 130 338 minecraft:blue_terracotta
setblock 141 130 345 minecraft:blue_terracotta
fill 141 130 359 141 131 360 minecraft:black_concrete
setblock 142 130 325 minecraft:dark_prismarine
fill 142 130 326 142 133 326 minecraft:blue_terracotta
setblock 142 130 330 minecraft:dark_prismarine
fill 142 130 331 142 133 331 minecraft:blue_terracotta
setblock 142 130 335 minecraft:dark_prismarine
fill 142 130 336 142 133 336 minecraft:blue_terracotta
setblock 142 130 345 minecraft:dark_prismarine
fill 142 130 346 142 132 346 minecraft:blue_terracotta
setblock 142 130 350 minecraft:dark_prismarine
fill 142 130 351 142 133 351 minecraft:blue_terracotta
setblock 142 130 355 minecraft:dark_prismarine
fill 142 130 356 142 133 356 minecraft:blue_terracotta
setblock 142 130 359 minecraft:blue_terracotta
setblock 142 130 360 minecraft:dark_prismarine
fill 142 130 361 142 133 361 minecraft:blue_terracotta
setblock 143 130 324 minecraft:dark_prismarine
fill 143 130 325 143 133 325 minecraft:blue_terracotta
setblock 143 130 329 minecraft:dark_prismarine
fill 143 130 330 143 133 330 minecraft:blue_terracotta
setblock 143 130 334 minecraft:dark_prismarine
fill 143 130 335 143 133 335 minecraft:blue_terracotta
setblock 143 130 349 minecraft:dark_prismarine
fill 143 130 350 143 132 350 minecraft:blue_terracotta
setblock 143 130 353 minecraft:blue_terracotta
setblock 143 130 354 minecraft:dark_prismarine
fill 143 130 355 143 133 355 minecraft:blue_terracotta
setblock 143 130 363 minecraft:blue_terracotta
setblock 144 130 323 minecraft:dark_prismarine
fill 144 130 324 144 133 324 minecraft:blue_terracotta
setblock 144 130 328 minecraft:dark_prismarine
fill 144 130 329 144 133 329 minecraft:blue_terracotta
setblock 144 130 363 minecraft:dark_prismarine
fill 145 130 323 148 130 323 minecraft:blue_terracotta
fill 145 130 363 145 133 363 minecraft:blue_terracotta
fill 145 130 364 145 131 364 minecraft:black_concrete
fill 146 130 326 146 132 326 minecraft:black_concrete
fill 147 130 322 148 130 322 minecraft:blue_terracotta
fill 147 130 325 147 132 325 minecraft:black_concrete
fill 147 130 327 147 132 327 minecraft:black_concrete
fill 148 130 326 148 132 326 minecraft:black_concrete
fill 148 130 364 148 131 364 minecraft:black_concrete
setblock 149 130 323 minecraft:dark_prismarine
setblock 150 130 323 minecraft:purple_concrete
setblock 150 130 364 minecraft:blue_terracotta
fill 151 130 364 151 131 364 minecraft:black_concrete
setblock 152 130 322 minecraft:blue_terracotta
fill 152 130 335 152 171 335 minecraft:magenta_terracotta
setblock 154 130 322 minecraft:blue_terracotta
setblock 154 130 323 minecraft:dark_prismarine
setblock 154 130 363 minecraft:dark_prismarine
fill 155 130 323 155 133 323 minecraft:blue_terracotta
fill 155 130 363 155 133 363 minecraft:blue_terracotta
fill 158 130 362 159 130 362 minecraft:blue_terracotta
setblock 159 130 322 minecraft:blue_terracotta
setblock 159 130 323 minecraft:dark_prismarine
setblock 159 130 324 minecraft:blue_terracotta
setblock 159 130 363 minecraft:dark_prismarine
fill 160 130 322 160 131 322 minecraft:black_concrete
fill 160 130 323 160 133 323 minecraft:blue_terracotta
setblock 160 130 362 minecraft:dark_prismarine
fill 160 130 363 160 133 363 minecraft:blue_terracotta
fill 161 130 362 161 133 362 minecraft:blue_terracotta
fill 162 130 364 162 132 364 minecraft:black_concrete
setblock 164 130 322 minecraft:blue_terracotta
setblock 164 130 363 minecraft:dark_prismarine
fill 164 130 364 164 131 364 minecraft:black_concrete
setblock 169 130 323 minecraft:purple_concrete
fill 170 130 364 170 131 364 minecraft:black_concrete
fill 172 130 322 172 131 322 minecraft:black_concrete
setblock 174 130 363 minecraft:purple_concrete
fill 174 130 364 174 131 364 minecraft:black_concrete
fill 177 130 322 177 131 322 minecraft:black_concrete
fill 177 130 323 177 131 323 minecraft:blue_terracotta
setblock 178 130 322 minecraft:blue_terracotta
setblock 178 130 324 minecraft:dark_prismarine
fill 179 130 322 179 131 322 minecraft:black_concrete
setblock 179 130 323 minecraft:dark_prismarine
fill 179 130 324 179 133 324 minecraft:blue_terracotta
setblock 179 130 328 minecraft:dark_prismarine
fill 179 130 329 179 130 332 minecraft:blue_terracotta
setblock 179 130 333 minecraft:dark_prismarine
fill 180 130 322 180 130 323 minecraft:blue_terracotta
setblock 180 130 327 minecraft:dark_prismarine
fill 180 130 328 180 133 328 minecraft:blue_terracotta
setblock 180 130 332 minecraft:dark_prismarine
fill 180 130 333 180 133 333 minecraft:blue_terracotta
setblock 180 130 336 minecraft:blue_terracotta
setblock 180 130 337 minecraft:dark_prismarine
setblock 180 130 347 minecraft:dark_prismarine
fill 180 130 348 180 132 348 minecraft:blue_terracotta
setblock 180 130 351 minecraft:blue_terracotta
setblock 180 130 352 minecraft:dark_prismarine
setblock 180 130 364 minecraft:blue_terracotta
setblock 181 130 326 minecraft:dark_prismarine
fill 181 130 327 181 133 327 minecraft:blue_terracotta
setblock 181 130 331 minecraft:dark_prismarine
fill 181 130 332 181 133 332 minecraft:blue_terracotta
setblock 181 130 336 minecraft:dark_prismarine
fill 181 130 337 182 132 337 minecraft:blue_terracotta
setblock 181 130 341 minecraft:dark_prismarine
fill 181 130 342 181 133 342 minecraft:blue_terracotta
setblock 181 130 346 minecraft:dark_prismarine
fill 181 130 347 181 133 347 minecraft:blue_terracotta
setblock 181 130 351 minecraft:dark_prismarine
fill 181 130 352 181 133 352 minecraft:blue_terracotta
setblock 181 130 355 minecraft:blue_terracotta
fill 182 130 322 182 131 322 minecraft:black_concrete
setblock 182 130 325 minecraft:dark_prismarine
fill 182 130 326 182 133 326 minecraft:blue_terracotta
setblock 182 130 330 minecraft:dark_prismarine
fill 182 130 331 182 133 331 minecraft:blue_terracotta
setblock 182 130 335 minecraft:dark_prismarine
fill 182 130 336 182 133 336 minecraft:blue_terracotta
setblock 182 130 340 minecraft:dark_prismarine
fill 182 130 341 182 133 341 minecraft:blue_terracotta
setblock 182 130 345 minecraft:dark_prismarine
fill 182 130 346 182 133 346 minecraft:blue_terracotta
setblock 182 130 350 minecraft:dark_prismarine
fill 182 130 351 182 133 351 minecraft:blue_terracotta
setblock 182 130 354 minecraft:blue_terracotta
setblock 182 130 355 minecraft:dark_prismarine
fill 182 130 356 182 132 357 minecraft:blue_terracotta
fill 183 130 337 183 131 337 minecraft:black_concrete
setblock 183 130 340 minecraft:blue_terracotta
fill 183 130 341 183 131 342 minecraft:black_concrete
setblock 183 130 345 minecraft:light_blue_wool
fill 183 130 347 183 131 347 minecraft:black_concrete
setblock 141 131 338 minecraft:black_concrete
fill 141 131 345 141 132 345 minecraft:black_concrete
setblock 142 131 324 minecraft:dark_prismarine
fill 142 131 325 142 134 325 minecraft:blue_terracotta
setblock 142 131 329 minecraft:dark_prismarine
fill 142 131 330 142 134 330 minecraft:blue_terracotta
setblock 142 131 334 minecraft:dark_prismarine
fill 142 131 335 142 134 335 minecraft:blue_terracotta
setblock 142 131 339 minecraft:dark_prismarine
fill 142 131 340 142 134 340 minecraft:blue_terracotta
setblock 142 131 345 minecraft:blue_terracotta
setblock 142 131 349 minecraft:dark_prismarine
fill 142 131 350 142 134 350 minecraft:blue_terracotta
setblock 142 131 354 minecraft:dark_prismarine
fill 142 131 355 142 134 355 minecraft:blue_terracotta
setblock 142 131 359 minecraft:dark_prismarine
fill 142 131 360 142 134 360 minecraft:blue_terracotta
setblock 143 131 323 minecraft:dark_prismarine
fill 143 131 324 143 134 324 minecraft:blue_terracotta
setblock 143 131 328 minecraft:dark_prismarine
fill 143 131 329 143 134 329 minecraft:blue_terracotta
setblock 143 131 333 minecraft:dark_prismarine
fill 143 131 334 143 134 334 minecraft:blue_terracotta
fill 143 131 336 143 132 336 minecraft:blue_terracotta
setblock 143 131 353 minecraft:dark_prismarine
fill 143 131 354 143 134 354 minecraft:blue_terracotta
fill 143 131 356 143 131 357 minecraft:blue_terracotta
setblock 143 131 363 minecraft:dark_prismarine
fill 144 131 323 147 131 323 minecraft:blue_terracotta
setblock 144 131 327 minecraft:dark_prismarine
fill 144 131 328 144 133 328 minecraft:blue_terracotta
setblock 144 131 332 minecraft:dark_prismarine
setblock 144 131 339 minecraft:light[level=12]
setblock 144 131 346 minecraft:light[level=12]
setblock 144 131 353 minecraft:light[level=12]
setblock 144 131 360 minecraft:light[level=12]
fill 144 131 363 144 134 363 minecraft:blue_terracotta
fill 146 131 363 146 132 363 minecraft:blue_terracotta
fill 147 131 322 148 131 322 minecraft:black_concrete
setblock 148 131 323 minecraft:dark_prismarine
setblock 150 131 364 minecraft:black_concrete
setblock 151 131 325 minecraft:light[level=12]
setblock 151 131 332 minecraft:light[level=12]
setblock 151 131 339 minecraft:light[level=12]
setblock 151 131 346 minecraft:light[level=12]
setblock 151 131 353 minecraft:light[level=12]
setblock 151 131 360 minecraft:light[level=12]
setblock 152 131 322 minecraft:black_concrete
setblock 153 131 323 minecraft:dark_prismarine
setblock 153 131 363 minecraft:dark_prismarine
setblock 154 131 322 minecraft:black_concrete
fill 154 131 323 154 134 323 minecraft:blue_terracotta
fill 154 131 363 154 134 363 minecraft:blue_terracotta
fill 156 131 362 158 131 362 minecraft:blue_terracotta
setblock 157 131 363 minecraft:blue_terracotta
setblock 157 131 364 minecraft:black_concrete
setblock 158 131 323 minecraft:dark_prismarine
setblock 158 131 325 minecraft:light[level=12]
setblock 158 131 332 minecraft:light[level=12]
setblock 158 131 339 minecraft:light[level=12]
setblock 158 131 346 minecraft:light[level=12]
setblock 158 131 353 minecraft:light[level=12]
setblock 158 131 360 minecraft:light[level=12]
setblock 158 131 363 minecraft:dark_prismarine
setblock 159 131 322 minecraft:black_concrete
fill 159 131 323 159 134 323 minecraft:blue_terracotta
setblock 159 131 362 minecraft:dark_prismarine
fill 159 131 363 159 134 363 minecraft:blue_terracotta
fill 160 131 362 160 134 362 minecraft:blue_terracotta
setblock 163 131 323 minecraft:purple_concrete
setblock 163 131 363 minecraft:dark_prismarine
setblock 164 131 322 minecraft:black_concrete
setblock 165 131 325 minecraft:light[level=12]
setblock 165 131 332 minecraft:light[level=12]
setblock 165 131 339 minecraft:light[level=12]
setblock 165 131 346 minecraft:light[level=12]
setblock 165 131 353 minecraft:light[level=12]
setblock 165 131 360 minecraft:light[level=12]
setblock 166 131 364 minecraft:black_concrete
fill 167 131 328 167 188 328 minecraft:magenta_terracotta
setblock 172 131 325 minecraft:light[level=12]
setblock 172 131 332 minecraft:light[level=12]
setblock 172 131 339 minecraft:light[level=12]
setblock 172 131 346 minecraft:light[level=12]
setblock 172 131 353 minecraft:light[level=12]
setblock 172 131 360 minecraft:light[level=12]
fill 176 131 323 176 132 323 minecraft:blue_terracotta
setblock 178 131 322 minecraft:black_concrete
setblock 178 131 323 minecraft:dark_prismarine
fill 178 131 324 178 134 324 minecraft:blue_terracotta
fill 178 131 339 178 137 339 minecraft:magenta_terracotta
fill 179 131 323 180 133 323 minecraft:blue_terracotta
fill 179 131 325 179 132 325 minecraft:blue_terracotta
fill 179 131 328 179 131 331 minecraft:blue_terracotta
setblock 179 131 332 minecraft:dark_prismarine
fill 179 131 333 179 132 335 minecraft:blue_terracotta
setblock 179 131 339 minecraft:light[level=12]
setblock 179 131 346 minecraft:light[level=12]
setblock 179 131 353 minecraft:light[level=12]
setblock 179 131 360 minecraft:light[level=12]
setblock 180 131 322 minecraft:black_concrete
setblock 180 131 326 minecraft:dark_prismarine
fill 180 131 327 180 134 327 minecraft:blue_terracotta
setblock 180 131 331 minecraft:dark_prismarine
fill 180 131 332 180 134 332 minecraft:blue_terracotta
setblock 180 131 336 minecraft:dark_prismarine
fill 180 131 337 180 133 338 minecraft:blue_terracotta
setblock 180 131 347 minecraft:blue_terracotta
setblock 180 131 351 minecraft:dark_prismarine
fill 180 131 352 180 133 353 minecraft:blue_terracotta
setblock 180 131 363 minecraft:purple_concrete
setblock 180 131 364 minecraft:black_concrete
setblock 181 131 325 minecraft:dark_prismarine
fill 181 131 326 181 134 326 minecraft:blue_terracotta
setblock 181 131 330 minecraft:dark_prismarine
fill 181 131 331 181 134 331 minecraft:blue_terracotta
setblock 181 131 335 minecraft:dark_prismarine
fill 181 131 336 181 134 336 minecraft:blue_terracotta
setblock 181 131 340 minecraft:dark_prismarine
fill 181 131 341 181 134 341 minecraft:blue_terracotta
setblock 181 131 345 minecraft:dark_prismarine
fill 181 131 346 181 133 346 minecraft:blue_terracotta
setblock 181 131 350 minecraft:dark_prismarine
fill 181 131 351 181 134 351 minecraft:blue_terracotta
setblock 181 131 355 minecraft:dark_prismarine
fill 181 131 356 181 134 356 minecraft:blue_terracotta
setblock 182 131 324 minecraft:dark_prismarine
fill 182 131 325 182 134 325 minecraft:blue_terracotta
setblock 182 131 329 minecraft:dark_prismarine
fill 182 131 330 182 134 330 minecraft:blue_terracotta
setblock 182 131 334 minecraft:dark_prismarine
fill 182 131 335 182 134 335 minecraft:blue_terracotta
setblock 182 131 339 minecraft:dark_prismarine
fill 182 131 340 182 134 340 minecraft:blue_terracotta
setblock 182 131 344 minecraft:dark_prismarine
fill 182 131 345 182 134 345 minecraft:blue_terracotta
setblock 182 131 349 minecraft:dark_prismarine
fill 182 131 350 182 134 350 minecraft:blue_terracotta
setblock 182 131 354 minecraft:dark_prismarine
fill 182 131 355 182 134 355 minecraft:blue_terracotta
setblock 182 131 358 minecraft:blue_terracotta
setblock 182 131 359 minecraft:dark_prismarine
setblock 183 131 340 minecraft:black_concrete
setblock 183 131 345 minecraft:black_concrete
fill 141 132 322 141 133 327 minecraft:blue_terracotta
fill 141 132 329 141 160 335 minecraft:blue_terracotta
fill 141 132 337 141 133 342 minecraft:blue_terracotta
fill 141 132 344 141 220 344 minecraft:blue_terracotta
fill 141 132 346 141 132 364 minecraft:blue_terracotta
fill 142 132 322 146 133 322 minecraft:blue_terracotta
setblock 142 132 323 minecraft:dark_prismarine
fill 142 132 324 142 135 324 minecraft:blue_terracotta
setblock 142 132 327 minecraft:blue_terracotta
setblock 142 132 328 minecraft:dark_prismarine
fill 142 132 329 142 135 329 minecraft:blue_terracotta
setblock 142 132 333 minecraft:dark_prismarine
fill 142 132 334 142 135 334 minecraft:blue_terracotta
setblock 142 132 338 minecraft:dark_prismarine
fill 142 132 339 142 135 339 minecraft:blue_terracotta
setblock 142 132 344 minecraft:purple_concrete
setblock 142 132 348 minecraft:dark_prismarine
fill 142 132 349 142 135 349 minecraft:blue_terracotta
setblock 142 132 352 minecraft:blue_terracotta
setblock 142 132 353 minecraft:dark_prismarine
fill 142 132 354 142 135 354 minecraft:blue_terracotta
setblock 142 132 357 minecraft:blue_terracotta
setblock 142 132 358 minecraft:dark_prismarine
fill 142 132 359 143 134 359 minecraft:blue_terracotta
setblock 142 132 362 minecraft:blue_terracotta
setblock 142 132 363 minecraft:dark_prismarine
fill 143 132 323 146 132 323 minecraft:blue_terracotta
setblock 143 132 327 minecraft:dark_prismarine
fill 143 132 328 143 135 328 minecraft:blue_terracotta
setblock 143 132 332 minecraft:dark_prismarine
fill 143 132 333 143 135 333 minecraft:blue_terracotta
setblock 143 132 352 minecraft:dark_prismarine
fill 143 132 353 143 135 353 minecraft:blue_terracotta
setblock 143 132 356 minecraft:blue_terracotta
setblock 143 132 357 minecraft:dark_prismarine
fill 143 132 358 143 135 358 minecraft:blue_terracotta
fill 143 132 363 143 132 364 minecraft:blue_terracotta
setblock 144 132 326 minecraft:dark_prismarine
setblock 144 132 327 minecraft:blue_terracotta
setblock 144 132 331 minecraft:dark_prismarine
fill 144 132 332 144 133 332 minecraft:blue_terracotta
fill 144 132 364 155 132 364 minecraft:blue_terracotta
setblock 147 132 322 minecraft:black_concrete
setblock 147 132 323 minecraft:dark_prismarine
fill 148 132 322 148 132 323 minecraft:blue_terracotta
fill 149 132 322 183 132 322 minecraft:blue_terracotta
setblock 151 132 363 minecraft:blue_terracotta
setblock 152 132 363 minecraft:dark_prismarine
fill 153 132 323 153 135 323 minecraft:blue_terracotta
fill 153 132 363 153 135 363 minecraft:blue_terracotta
fill 155 132 362 157 132 362 minecraft:blue_terracotta
setblock 157 132 323 minecraft:dark_prismarine
setblock 157 132 363 minecraft:dark_prismarine
fill 157 132 364 160 132 364 minecraft:blue_terracotta
fill 158 132 323 158 135 323 minecraft:blue_terracotta
setblock 158 132 361 minecraft:blue_terracotta
setblock 158 132 362 minecraft:dark_prismarine
fill 158 132 363 158 135 363 minecraft:blue_terracotta
fill 159 132 362 159 135 362 minecraft:blue_terracotta
setblock 162 132 323 minecraft:dark_prismarine
setblock 162 132 363 minecraft:dark_prismarine
fill 163 132 363 163 134 364 minecraft:blue_terracotta
fill 164 132 364 164 220 364 minecraft:blue_terracotta
fill 166 132 364 176 132 364 minecraft:blue_terracotta
setblock 167 132 363 minecraft:purple_concrete
setblock 177 132 323 minecraft:dark_prismarine
fill 177 132 324 177 135 324 minecraft:blue_terracotta
fill 177 132 364 177 133 364 minecraft:black_concrete
fill 178 132 323 178 135 323 minecraft:blue_terracotta
fill 178 132 325 178 133 325 minecraft:blue_terracotta
setblock 178 132 364 minecraft:light_blue_wool
fill 179 132 327 179 132 330 minecraft:blue_terracotta
setblock 179 132 331 minecraft:dark_prismarine
fill 179 132 332 179 135 332 minecraft:blue_terracotta
setblock 179 132 336 minecraft:dark_prismarine
fill 179 132 363 181 132 364 minecraft:blue_terracotta
setblock 180 132 324 minecraft:blue_terracotta
setblock 180 132 325 minecraft:dark_prismarine
fill 180 132 326 180 135 326 minecraft:blue_terracotta
setblock 180 132 330 minecraft:dark_prismarine
fill 180 132 331 180 135 331 minecraft:blue_terracotta
setblock 180 132 334 minecraft:blue_terracotta
setblock 180 132 335 minecraft:dark_prismarine
fill 180 132 336 180 135 336 minecraft:blue_terracotta
setblock 180 132 339 minecraft:blue_terracotta
setblock 180 132 350 minecraft:dark_prismarine
fill 180 132 351 180 134 351 minecraft:blue_terracotta
setblock 180 132 354 minecraft:blue_terracotta
setblock 181 132 323 minecraft:blue_terracotta
setblock 181 132 324 minecraft:dark_prismarine
fill 181 132 325 181 135 325 minecraft:blue_terracotta
setblock 181 132 329 minecraft:dark_prismarine
fill 181 132 330 181 135 330 minecraft:blue_terracotta
setblock 181 132 334 minecraft:dark_prismarine
fill 181 132 335 181 135 335 minecraft:blue_terracotta
setblock 181 132 339 minecraft:dark_prismarine
fill 181 132 340 181 135 340 minecraft:blue_terracotta
setblock 181 132 344 minecraft:dark_prismarine
fill 181 132 345 181 133 345 minecraft:blue_terracotta
setblock 181 132 349 minecraft:dark_prismarine
fill 181 132 350 181 135 350 minecraft:blue_terracotta
setblock 181 132 353 minecraft:blue_terracotta
setblock 181 132 354 minecraft:dark_prismarine
fill 181 132 355 181 135 355 minecraft:blue_terracotta
fill 181 132 357 181 133 357 minecraft:blue_terracotta
setblock 182 132 323 minecraft:dark_prismarine
fill 182 132 324 182 135 324 minecraft:blue_terracotta
setblock 182 132 328 minecraft:dark_prismarine
fill 182 132 329 183 135 329 minecraft:blue_terracotta
setblock 182 132 333 minecraft:dark_prismarine
fill 182 132 334 183 135 334 minecraft:blue_terracotta
setblock 182 132 338 minecraft:dark_prismarine
fill 182 132 339 183 135 339 minecraft:blue_terracotta
setblock 182 132 343 minecraft:dark_prismarine
fill 182 132 344 183 135 344 minecraft:blue_terracotta
setblock 182 132 348 minecraft:dark_prismarine
fill 182 132 349 183 135 349 minecraft:blue_terracotta
setblock 182 132 353 minecraft:dark_prismarine
fill 182 132 354 183 133 354 minecraft:blue_terracotta
setblock 182 132 358 minecraft:dark_prismarine
fill 182 132 359 182 133 361 minecraft:blue_terracotta
setblock 182 132 363 minecraft:dark_prismarine
fill 182 132 364 182 220 364 minecraft:blue_terracotta
setblock 183 132 323 minecraft:black_concrete
fill 183 132 325 183 220 326 minecraft:blue_terracotta
fill 183 132 328 183 220 328 minecraft:blue_terracotta
fill 183 132 330 183 191 333 minecraft:blue_terracotta
fill 183 132 335 183 132 338 minecraft:blue_terracotta
fill 183 132 340 183 132 343 minecraft:blue_terracotta
fill 183 132 345 183 133 348 minecraft:blue_terracotta
fill 183 132 350 183 218 351 minecraft:blue_terracotta
fill 183 132 355 183 133 356 minecraft:blue_terracotta
fill 183 132 358 183 218 360 minecraft:blue_terracotta
fill 183 132 362 183 205 363 minecraft:blue_terracotta
fill 141 133 336 141 220 336 minecraft:blue_terracotta
fill 141 133 343 141 220 343 minecraft:blue_terracotta
fill 141 133 345 141 133 360 minecraft:blue_terracotta
fill 141 133 361 141 133 363 minecraft:black_concrete
fill 141 133 364 142 133 364 minecraft:blue_terracotta
fill 142 133 323 145 133 323 minecraft:blue_terracotta
setblock 142 133 327 minecraft:dark_prismarine
fill 142 133 328 142 136 328 minecraft:blue_terracotta
setblock 142 133 332 minecraft:dark_prismarine
fill 142 133 333 142 136 333 minecraft:blue_terracotta
setblock 142 133 337 minecraft:dark_prismarine
fill 142 133 338 142 136 338 minecraft:blue_terracotta
setblock 142 133 347 minecraft:dark_prismarine
fill 142 133 348 142 134 348 minecraft:blue_terracotta
setblock 142 133 352 minecraft:dark_prismarine
fill 142 133 353 142 136 353 minecraft:blue_terracotta
setblock 142 133 357 minecraft:dark_prismarine
fill 142 133 358 142 136 358 minecraft:blue_terracotta
setblock 142 133 362 minecraft:dark_prismarine
fill 142 133 363 143 135 363 minecraft:blue_terracotta
setblock 143 133 326 minecraft:dark_prismarine
fill 143 133 327 143 135 327 minecraft:blue_terracotta
setblock 143 133 331 minecraft:dark_prismarine
fill 143 133 332 143 136 332 minecraft:blue_terracotta
setblock 143 133 336 minecraft:dark_prismarine
setblock 143 133 351 minecraft:dark_prismarine
fill 143 133 352 143 135 352 minecraft:blue_terracotta
setblock 143 133 356 minecraft:dark_prismarine
fill 143 133 357 143 136 357 minecraft:blue_terracotta
setblock 143 133 360 minecraft:blue_terracotta
setblock 143 133 364 minecraft:black_concrete
setblock 144 133 325 minecraft:light[level=13]
setblock 144 133 330 minecraft:dark_prismarine
setblock 144 133 331 minecraft:blue_terracotta
setblock 144 133 333 minecraft:light[level=13]
setblock 144 133 341 minecraft:light[level=13]
setblock 144 133 349 minecraft:light[level=13]
setblock 144 133 357 minecraft:light[level=13]
fill 144 133 364 144 220 364 minecraft:blue_terracotta
setblock 145 133 364 minecraft:black_concrete
setblock 146 133 323 minecraft:dark_prismarine
setblock 146 133 363 minecraft:dark_prismarine
fill 146 133 364 146 210 364 minecraft:blue_terracotta
fill 147 133 322 147 133 323 minecraft:blue_terracotta
fill 147 133 363 150 133 363 minecraft:blue_terracotta
fill 147 133 364 148 133 364 minecraft:black_concrete
fill 148 133 322 153 159 322 minecraft:blue_terracotta
fill 149 133 335 149 136 335 minecraft:magenta_terracotta
fill 149 133 364 156 170 364 minecraft:blue_terracotta
setblock 151 133 323 minecraft:purple_concrete
setblock 151 133 363 minecraft:dark_prismarine
setblock 152 133 325 minecraft:light[level=13]
setblock 152 133 333 minecraft:light[level=13]
setblock 152 133 341 minecraft:light[level=13]
setblock 152 133 349 minecraft:light[level=13]
setblock 152 133 357 minecraft:light[level=13]
fill 152 133 363 152 136 363 minecraft:blue_terracotta
fill 153 133 362 156 133 362 minecraft:blue_terracotta
fill 154 133 322 155 133 322 minecraft:black_concrete
fill 156 133 322 167 133 322 minecraft:blue_terracotta
setblock 156 133 323 minecraft:dark_prismarine
fill 156 133 361 157 133 361 minecraft:blue_terracotta
setblock 156 133 363 minecraft:dark_prismarine
fill 157 133 323 157 136 323 minecraft:blue_terracotta
setblock 157 133 362 minecraft:dark_prismarine
fill 157 133 363 157 136 363 minecraft:blue_terracotta
setblock 157 133 364 minecraft:black_concrete
setblock 158 133 361 minecraft:dark_prismarine
fill 158 133 362 158 136 362 minecraft:blue_terracotta
fill 158 133 364 159 217 364 minecraft:blue_terracotta
fill 159 133 361 160 135 361 minecraft:blue_terracotta
setblock 160 133 325 minecraft:light[level=13]
setblock 160 133 333 minecraft:light[level=13]
setblock 160 133 341 minecraft:light[level=13]
setblock 160 133 349 minecraft:light[level=13]
setblock 160 133 357 minecraft:light[level=13]
setblock 160 133 364 minecraft:black_concrete
setblock 161 133 323 minecraft:dark_prismarine
setblock 161 133 363 minecraft:dark_prismarine
fill 161 133 364 162 156 364 minecraft:blue_terracotta
fill 162 133 363 162 136 363 minecraft:blue_terracotta
fill 165 133 364 165 220 364 minecraft:blue_terracotta
setblock 166 133 364 minecraft:black_concrete
fill 167 133 364 170 220 364 minecraft:blue_terracotta
fill 168 133 322 168 134 322 minecraft:black_concrete
setblock 168 133 325 minecraft:light[level=13]
setblock 168 133 333 minecraft:light[level=13]
setblock 168 133 341 minecraft:light[level=13]
setblock 168 133 349 minecraft:light[level=13]
setblock 168 133 357 minecraft:light[level=13]
fill 169 133 322 182 133 322 minecraft:blue_terracotta
setblock 171 133 364 minecraft:black_concrete
fill 172 133 352 172 160 352 minecraft:magenta_terracotta
fill 172 133 364 172 220 364 minecraft:blue_terracotta
setblock 173 133 363 minecraft:purple_concrete
setblock 173 133 364 minecraft:black_concrete
fill 174 133 364 176 218 364 minecraft:blue_terracotta
setblock 175 133 323 minecraft:blue_terracotta
setblock 176 133 323 minecraft:dark_prismarine
setblock 176 133 325 minecraft:light[level=13]
setblock 176 133 333 minecraft:light[level=13]
setblock 176 133 341 minecraft:light[level=13]
setblock 176 133 349 minecraft:light[level=13]
setblock 176 133 357 minecraft:light[level=13]
fill 177 133 323 177 136 323 minecraft:blue_terracotta
setblock 178 133 330 minecraft:blue_terracotta
setblock 178 133 331 minecraft:dark_prismarine
fill 178 133 332 178 134 334 minecraft:blue_terracotta
fill 178 133 363 180 133 364 minecraft:blue_terracotta
setblock 179 133 325 minecraft:dark_prismarine
fill 179 133 327 179 133 329 minecraft:blue_terracotta
setblock 179 133 330 minecraft:dark_prismarine
fill 179 133 331 179 136 331 minecraft:blue_terracotta
fill 179 133 333 179 133 334 minecraft:blue_terracotta
setblock 179 133 335 minecraft:dark_prismarine
fill 179 133 336 179 136 336 minecraft:blue_terracotta
setblock 180 133 324 minecraft:dark_prismarine
fill 180 133 325 180 134 325 minecraft:blue_terracotta
setblock 180 133 329 minecraft:dark_prismarine
fill 180 133 330 180 136 330 minecraft:blue_terracotta
setblock 180 133 334 minecraft:dark_prismarine
fill 180 133 335 180 136 335 minecraft:blue_terracotta
setblock 180 133 339 minecraft:dark_prismarine
fill 180 133 340 180 135 340 minecraft:blue_terracotta
setblock 180 133 349 minecraft:dark_prismarine
setblock 180 133 350 minecraft:blue_terracotta
setblock 180 133 354 minecraft:dark_prismarine
fill 180 133 355 180 134 355 minecraft:blue_terracotta
setblock 181 133 323 minecraft:dark_prismarine
fill 181 133 324 181 136 324 minecraft:blue_terracotta
setblock 181 133 328 minecraft:dark_prismarine
fill 181 133 329 181 136 329 minecraft:blue_terracotta
setblock 181 133 333 minecraft:dark_prismarine
fill 181 133 334 181 136 334 minecraft:blue_terracotta
setblock 181 133 337 minecraft:blue_terracotta
setblock 181 133 338 minecraft:dark_prismarine
fill 181 133 339 181 136 339 minecraft:blue_terracotta
setblock 181 133 343 minecraft:dark_prismarine
setblock 181 133 344 minecraft:blue_terracotta
setblock 181 133 348 minecraft:dark_prismarine
fill 181 133 349 181 134 349 minecraft:blue_terracotta
setblock 181 133 353 minecraft:dark_prismarine
fill 181 133 354 181 136 354 minecraft:blue_terracotta
setblock 181 133 358 minecraft:dark_prismarine
setblock 181 133 363 minecraft:dark_prismarine
fill 181 133 364 181 222 364 minecraft:blue_terracotta
fill 182 133 323 183 136 323 minecraft:blue_terracotta
setblock 182 133 327 minecraft:dark_prismarine
fill 182 133 328 182 136 328 minecraft:blue_terracotta
setblock 182 133 332 minecraft:dark_prismarine
fill 182 133 333 182 136 333 minecraft:blue_terracotta
setblock 182 133 337 minecraft:dark_prismarine
fill 182 133 338 182 136 338 minecraft:blue_terracotta
setblock 182 133 342 minecraft:dark_prismarine
fill 182 133 343 183 135 343 minecraft:blue_terracotta
setblock 182 133 347 minecraft:dark_prismarine
fill 182 133 348 182 135 348 minecraft:blue_terracotta
setblock 182 133 352 minecraft:dark_prismarine
fill 182 133 353 183 136 353 minecraft:blue_terracotta
setblock 182 133 356 minecraft:blue_terracotta
setblock 182 133 357 minecraft:dark_prismarine
fill 182 133 358 182 136 358 minecraft:blue_terracotta
setblock 182 133 362 minecraft:dark_prismarine
fill 182 133 363 182 136 363 minecraft:blue_terracotta
setblock 183 133 322 minecraft:black_concrete
setblock 183 133 324 minecraft:blue_terracotta
fill 183 133 327 183 220 327 minecraft:blue_terracotta
fill 183 133 335 183 151 335 minecraft:blue_terracotta
setblock 183 133 336 minecraft:black_concrete
fill 183 133 337 183 170 337 minecraft:blue_terracotta
setblock 183 133 338 minecraft:black_concrete
fill 183 133 340 183 220 340 minecraft:blue_terracotta
setblock 183 133 341 minecraft:black_concrete
fill 183 133 342 183 220 342 minecraft:blue_terracotta
fill 183 133 352 183 220 352 minecraft:blue_terracotta
fill 183 133 357 183 221 357 minecraft:blue_terracotta
fill 183 133 361 183 220 361 minecraft:blue_terracotta
fill 183 133 364 183 217 364 minecraft:blue_terracotta
setblock 141 134 322 minecraft:black_concrete
fill 141 134 323 141 139 328 minecraft:blue_terracotta
fill 141 134 337 141 217 339 minecraft:blue_terracotta
setblock 141 134 340 minecraft:black_concrete
fill 141 134 341 141 180 342 minecraft:blue_terracotta
fill 141 134 345 141 144 352 minecraft:blue_terracotta
setblock 141 134 353 minecraft:black_concrete
fill 141 134 354 141 189 356 minecraft:blue_terracotta
setblock 141 134 357 minecraft:black_concrete
fill 141 134 358 141 153 360 minecraft:blue_terracotta
setblock 141 134 361 minecraft:black_concrete
fill 141 134 362 141 217 363 minecraft:blue_terracotta
setblock 141 134 364 minecraft:black_concrete
fill 142 134 322 142 136 323 minecraft:blue_terracotta
setblock 142 134 326 minecraft:dark_prismarine
fill 142 134 327 142 137 327 minecraft:blue_terracotta
setblock 142 134 331 minecraft:dark_prismarine
fill 142 134 332 142 137 332 minecraft:blue_terracotta
setblock 142 134 336 minecraft:dark_prismarine
fill 142 134 337 142 137 337 minecraft:blue_terracotta
setblock 142 134 351 minecraft:dark_prismarine
fill 142 134 352 142 137 352 minecraft:blue_terracotta
setblock 142 134 356 minecraft:dark_prismarine
fill 142 134 357 142 137 357 minecraft:blue_terracotta
setblock 142 134 361 minecraft:dark_prismarine
fill 142 134 362 142 137 362 minecraft:blue_terracotta
fill 142 134 364 143 153 364 minecraft:blue_terracotta
setblock 143 134 322 minecraft:black_concrete
fill 143 134 323 144 134 323 minecraft:blue_terracotta
setblock 143 134 325 minecraft:dark_prismarine
fill 143 134 326 143 135 326 minecraft:blue_terracotta
setblock 143 134 330 minecraft:dark_prismarine
fill 143 134 331 143 136 331 minecraft:blue_terracotta
setblock 143 134 335 minecraft:dark_prismarine
fill 143 134 336 143 135 336 minecraft:blue_terracotta
setblock 143 134 351 minecraft:blue_terracotta
setblock 143 134 355 minecraft:dark_prismarine
fill 143 134 356 143 137 356 minecraft:blue_terracotta
setblock 143 134 360 minecraft:dark_prismarine
fill 143 134 361 143 137 361 minecraft:blue_terracotta
fill 144 134 322 147 146 322 minecraft:blue_terracotta
setblock 145 134 323 minecraft:dark_prismarine
setblock 145 134 363 minecraft:dark_prismarine
fill 145 134 364 145 221 364 minecraft:blue_terracotta
setblock 146 134 323 minecraft:blue_terracotta
fill 146 134 363 149 134 363 minecraft:blue_terracotta
fill 147 134 364 148 220 364 minecraft:blue_terracotta
setblock 150 134 363 minecraft:dark_prismarine
fill 151 134 363 151 137 363 minecraft:blue_terracotta
fill 152 134 362 155 134 362 minecraft:blue_terracotta
fill 154 134 322 166 157 322 minecraft:blue_terracotta
setblock 155 134 323 minecraft:dark_prismarine
fill 155 134 361 156 134 361 minecraft:blue_terracotta
setblock 155 134 363 minecraft:dark_prismarine
fill 156 134 323 156 137 323 minecraft:blue_terracotta
fill 156 134 357 156 194 357 minecraft:magenta_terracotta
setblock 156 134 362 minecraft:dark_prismarine
fill 156 134 363 156 137 363 minecraft:blue_terracotta
setblock 157 134 361 minecraft:dark_prismarine
fill 157 134 362 157 137 362 minecraft:blue_terracotta
setblock 157 134 364 minecraft:light_blue_wool
fill 158 134 361 158 137 361 minecraft:blue_terracotta
setblock 160 134 323 minecraft:dark_prismarine
setblock 160 134 363 minecraft:dark_prismarine
fill 160 134 364 160 220 364 minecraft:blue_terracotta
setblock 161 134 362 minecraft:dark_prismarine
fill 161 134 363 161 137 363 minecraft:blue_terracotta
fill 164 134 323 164 135 323 minecraft:purple_concrete
fill 166 134 364 166 220 364 minecraft:blue_terracotta
setblock 167 134 322 minecraft:black_concrete
fill 169 134 322 170 202 322 minecraft:blue_terracotta
setblock 170 134 323 minecraft:purple_concrete
setblock 171 134 322 minecraft:black_concrete
fill 171 134 364 171 155 364 minecraft:blue_terracotta
fill 172 134 322 173 220 322 minecraft:blue_terracotta
fill 173 134 364 173 220 364 minecraft:blue_terracotta
fill 174 134 322 175 134 322 minecraft:black_concrete
setblock 175 134 323 minecraft:dark_prismarine
fill 176 134 322 176 136 324 minecraft:blue_terracotta
fill 177 134 322 183 138 322 minecraft:blue_terracotta
fill 177 134 363 178 135 364 minecraft:blue_terracotta
setblock 178 134 325 minecraft:dark_prismarine
setblock 178 134 330 minecraft:dark_prismarine
fill 178 134 331 178 135 331 minecraft:blue_terracotta
setblock 178 134 335 minecraft:dark_prismarine
setblock 179 134 323 minecraft:blue_terracotta
setblock 179 134 324 minecraft:dark_prismarine
setblock 179 134 325 minecraft:blue_terracotta
fill 179 134 327 179 134 328 minecraft:blue_terracotta
setblock 179 134 329 minecraft:dark_prismarine
fill 179 134 330 179 136 330 minecraft:blue_terracotta
setblock 179 134 333 minecraft:blue_terracotta
setblock 179 134 334 minecraft:dark_prismarine
fill 179 134 335 179 137 335 minecraft:blue_terracotta
setblock 179 134 363 minecraft:blue_terracotta
setblock 179 134 364 minecraft:black_concrete
setblock 180 134 323 minecraft:dark_prismarine
fill 180 134 324 180 136 324 minecraft:blue_terracotta
setblock 180 134 328 minecraft:dark_prismarine
fill 180 134 329 180 137 329 minecraft:blue_terracotta
setblock 180 134 333 minecraft:dark_prismarine
fill 180 134 334 180 137 334 minecraft:blue_terracotta
setblock 180 134 337 minecraft:blue_terracotta
setblock 180 134 338 minecraft:dark_prismarine
fill 180 134 339 180 137 339 minecraft:blue_terracotta
setblock 180 134 352 minecraft:blue_terracotta
setblock 180 134 353 minecraft:dark_prismarine
setblock 180 134 354 minecraft:blue_terracotta
setblock 180 134 363 minecraft:dark_prismarine
fill 180 134 364 180 220 364 minecraft:blue_terracotta
fill 181 134 323 181 137 323 minecraft:blue_terracotta
setblock 181 134 327 minecraft:dark_prismarine
fill 181 134 328 181 137 328 minecraft:blue_terracotta
setblock 181 134 332 minecraft:dark_prismarine
fill 181 134 333 181 137 333 minecraft:blue_terracotta
setblock 181 134 337 minecraft:dark_prismarine
fill 181 134 338 181 137 338 minecraft:blue_terracotta
setblock 181 134 342 minecraft:dark_prismarine
setblock 181 134 348 minecraft:blue_terracotta
setblock 181 134 352 minecraft:dark_prismarine
fill 181 134 353 181 136 353 minecraft:blue_terracotta
setblock 181 134 357 minecraft:dark_prismarine
fill 181 134 358 181 136 359 minecraft:blue_terracotta
fill 181 134 363 181 137 363 minecraft:blue_terracotta
setblock 182 134 326 minecraft:dark_prismarine
fill 182 134 327 182 137 327 minecraft:blue_terracotta
setblock 182 134 331 minecraft:dark_prismarine
fill 182 134 332 182 137 332 minecraft:blue_terracotta
setblock 182 134 336 minecraft:dark_prismarine
fill 182 134 337 182 137 337 minecraft:blue_terracotta
setblock 182 134 341 minecraft:dark_prismarine
fill 182 134 342 182 136 342 minecraft:blue_terracotta
setblock 182 134 346 minecraft:dark_prismarine
fill 182 134 347 183 135 347 minecraft:blue_terracotta
setblock 182 134 351 minecraft:dark_prismarine
fill 182 134 352 182 136 352 minecraft:blue_terracotta
fill 182 134 354 182 135 354 minecraft:blue_terracotta
setblock 182 134 356 minecraft:dark_prismarine
fill 182 134 357 182 137 357 minecraft:blue_terracotta
fill 182 134 359 182 134 360 minecraft:blue_terracotta
setblock 182 134 361 minecraft:dark_prismarine
fill 182 134 362 182 137 362 minecraft:blue_terracotta
setblock 183 134 324 minecraft:black_concrete
fill 183 134 336 183 189 336 minecraft:blue_terracotta
fill 183 134 338 183 139 338 minecraft:blue_terracotta
fill 183 134 341 183 220 341 minecraft:blue_terracotta
setblock 183 134 345 minecraft:black_concrete
fill 183 134 346 183 142 346 minecraft:blue_terracotta
setblock 183 134 348 minecraft:black_concrete
setblock 183 134 354 minecraft:black_concrete
setblock 183 134 355 minecraft:cyan_concrete
fill 183 134 356 183 193 356 minecraft:blue_terracotta
fill 141 135 322 141 220 322 minecraft:blue_terracotta
fill 141 135 340 141 221 340 minecraft:blue_terracotta
fill 141 135 353 141 220 353 minecraft:blue_terracotta
fill 141 135 357 141 216 357 minecraft:blue_terracotta
fill 141 135 361 142 138 361 minecraft:blue_terracotta
fill 141 135 364 141 217 364 minecraft:blue_terracotta
setblock 142 135 325 minecraft:dark_prismarine
fill 142 135 326 142 137 326 minecraft:blue_terracotta
setblock 142 135 330 minecraft:dark_prismarine
fill 142 135 331 142 138 331 minecraft:blue_terracotta
setblock 142 135 335 minecraft:dark_prismarine
fill 142 135 336 142 138 336 minecraft:blue_terracotta
setblock 142 135 350 minecraft:dark_prismarine
fill 142 135 351 142 136 351 minecraft:blue_terracotta
setblock 142 135 355 minecraft:dark_prismarine
fill 142 135 356 142 138 356 minecraft:blue_terracotta
setblock 142 135 359 minecraft:blue_terracotta
setblock 142 135 360 minecraft:dark_prismarine
fill 143 135 322 143 135 323 minecraft:blue_terracotta
setblock 143 135 325 minecraft:blue_terracotta
setblock 143 135 329 minecraft:dark_prismarine
fill 143 135 330 143 136 330 minecraft:blue_terracotta
setblock 143 135 334 minecraft:dark_prismarine
fill 143 135 335 143 136 335 minecraft:blue_terracotta
setblock 143 135 354 minecraft:dark_prismarine
fill 143 135 355 143 137 355 minecraft:blue_terracotta
setblock 143 135 359 minecraft:dark_prismarine
fill 143 135 360 143 138 360 minecraft:blue_terracotta
setblock 143 135 362 minecraft:blue_terracotta
setblock 144 135 323 minecraft:dark_prismarine
setblock 144 135 363 minecraft:dark_prismarine
setblock 145 135 323 minecraft:blue_terracotta
fill 145 135 363 148 135 363 minecraft:blue_terracotta
fill 146 135 348 146 193 348 minecraft:magenta_terracotta
fill 146 135 349 146 136 349 minecraft:pink_terracotta
setblock 149 135 363 minecraft:dark_prismarine
fill 150 135 363 150 138 363 minecraft:blue_terracotta
fill 151 135 335 151 136 335 minecraft:pink_terracotta
fill 151 135 336 152 151 336 minecraft:magenta_terracotta
fill 151 135 362 154 135 362 minecraft:blue_terracotta
fill 153 135 361 155 135 361 minecraft:blue_terracotta
setblock 154 135 323 minecraft:dark_prismarine
setblock 154 135 363 minecraft:dark_prismarine
fill 155 135 323 155 137 323 minecraft:blue_terracotta
setblock 155 135 362 minecraft:dark_prismarine
fill 155 135 363 155 138 363 minecraft:blue_terracotta
setblock 156 135 360 minecraft:blue_terracotta
setblock 156 135 361 minecraft:dark_prismarine
fill 156 135 362 156 138 362 minecraft:blue_terracotta
setblock 157 135 360 minecraft:dark_prismarine
fill 157 135 361 157 138 361 minecraft:blue_terracotta
fill 157 135 364 157 220 364 minecraft:blue_terracotta
setblock 159 135 323 minecraft:dark_prismarine
setblock 159 135 363 minecraft:dark_prismarine
setblock 160 135 362 minecraft:dark_prismarine
fill 160 135 363 160 138 363 minecraft:blue_terracotta
setblock 161 135 362 minecraft:blue_terracotta
fill 163 135 364 163 155 364 minecraft:blue_terracotta
fill 167 135 322 168 216 322 minecraft:blue_terracotta
fill 171 135 322 171 216 322 minecraft:blue_terracotta
fill 173 135 350 173 148 350 minecraft:magenta_terracotta
fill 173 135 351 173 136 351 minecraft:pink_terracotta
fill 174 135 322 175 139 322 minecraft:blue_terracotta
setblock 174 135 323 minecraft:dark_prismarine
fill 175 135 323 175 138 323 minecraft:blue_terracotta
fill 176 135 363 176 137 363 minecraft:blue_terracotta
setblock 178 135 324 minecraft:dark_prismarine
fill 178 135 332 178 135 333 minecraft:blue_terracotta
setblock 178 135 334 minecraft:dark_prismarine
fill 178 135 335 178 136 335 minecraft:blue_terracotta
setblock 179 135 323 minecraft:dark_prismarine
fill 179 135 324 179 137 324 minecraft:blue_terracotta
setblock 179 135 328 minecraft:dark_prismarine
fill 179 135 329 179 136 329 minecraft:blue_terracotta
setblock 179 135 333 minecraft:dark_prismarine
fill 179 135 334 179 138 334 minecraft:blue_terracotta
setblock 179 135 363 minecraft:dark_prismarine
fill 179 135 364 179 202 364 minecraft:blue_terracotta
fill 180 135 323 180 138 323 minecraft:blue_terracotta
setblock 180 135 327 minecraft:dark_prismarine
fill 180 135 328 180 137 328 minecraft:blue_terracotta
setblock 180 135 332 minecraft:dark_prismarine
fill 180 135 333 180 138 333 minecraft:blue_terracotta
setblock 180 135 337 minecraft:dark_prismarine
fill 180 135 338 180 138 338 minecraft:blue_terracotta
fill 180 135 363 180 138 363 minecraft:blue_terracotta
setblock 181 135 326 minecraft:dark_prismarine
fill 181 135 327 181 137 327 minecraft:blue_terracotta
setblock 181 135 331 minecraft:dark_prismarine
fill 181 135 332 181 138 332 minecraft:blue_terracotta
setblock 181 135 336 minecraft:dark_prismarine
fill 181 135 337 181 138 337 minecraft:blue_terracotta
setblock 181 135 341 minecraft:dark_prismarine
setblock 181 135 351 minecraft:dark_prismarine
setblock 181 135 352 minecraft:blue_terracotta
setblock 181 135 356 minecraft:dark_prismarine
fill 181 135 357 181 137 357 minecraft:blue_terracotta
setblock 182 135 325 minecraft:dark_prismarine
fill 182 135 326 182 138 326 minecraft:blue_terracotta
setblock 182 135 330 minecraft:dark_prismarine
fill 182 135 331 182 138 331 minecraft:blue_terracotta
setblock 182 135 335 minecraft:dark_prismarine
fill 182 135 336 182 138 336 minecraft:blue_terracotta
setblock 182 135 340 minecraft:dark_prismarine
fill 182 135 341 182 137 341 minecraft:blue_terracotta
setblock 182 135 350 minecraft:dark_prismarine
fill 182 135 351 182 136 351 minecraft:blue_terracotta
setblock 182 135 355 minecraft:dark_prismarine
fill 182 135 356 182 138 356 minecraft:blue_terracotta
setblock 182 135 359 minecraft:blue_terracotta
setblock 182 135 360 minecraft:dark_prismarine
fill 182 135 361 182 138 361 minecraft:blue_terracotta
fill 183 135 324 183 206 324 minecraft:blue_terracotta
fill 183 135 345 183 220 345 minecraft:blue_terracotta
fill 183 135 348 183 210 348 minecraft:blue_terracotta
fill 183 135 354 183 220 355 minecraft:blue_terracotta
setblock 142 136 324 minecraft:dark_prismarine
fill 142 136 325 142 137 325 minecraft:blue_terracotta
setblock 142 136 329 minecraft:dark_prismarine
fill 142 136 330 142 138 330 minecraft:blue_terracotta
setblock 142 136 334 minecraft:dark_prismarine
fill 142 136 335 142 139 335 minecraft:blue_terracotta
setblock 142 136 339 minecraft:dark_prismarine
setblock 142 136 343 minecraft:purple_concrete
setblock 142 136 350 minecraft:blue_terracotta
setblock 142 136 354 minecraft:dark_prismarine
fill 142 136 355 142 139 355 minecraft:blue_terracotta
setblock 142 136 359 minecraft:dark_prismarine
fill 142 136 360 142 139 360 minecraft:blue_terracotta
setblock 142 136 363 minecraft:blue_terracotta
fill 143 136 322 143 216 322 minecraft:blue_terracotta
setblock 143 136 323 minecraft:dark_prismarine
setblock 143 136 329 minecraft:blue_terracotta
setblock 143 136 333 minecraft:dark_prismarine
setblock 143 136 334 minecraft:blue_terracotta
setblock 143 136 354 minecraft:blue_terracotta
setblock 143 136 358 minecraft:dark_prismarine
fill 143 136 359 143 139 359 minecraft:blue_terracotta
setblock 143 136 363 minecraft:dark_prismarine
setblock 144 136 323 minecraft:blue_terracotta
fill 144 136 363 147 136 363 minecraft:blue_terracotta
setblock 148 136 363 minecraft:dark_prismarine
fill 149 136 363 149 139 363 minecraft:blue_terracotta
fill 150 136 362 153 136 362 minecraft:blue_terracotta
setblock 152 136 323 minecraft:purple_concrete
fill 152 136 334 152 160 334 minecraft:magenta_terracotta
setblock 153 136 323 minecraft:dark_prismarine
fill 153 136 345 153 137 345 minecraft:black_concrete
fill 153 136 361 154 136 361 minecraft:blue_terracotta
setblock 153 136 363 minecraft:dark_prismarine
fill 154 136 323 154 137 323 minecraft:blue_terracotta
setblock 154 136 362 minecraft:dark_prismarine
fill 154 136 363 154 139 363 minecraft:blue_terracotta
setblock 155 136 360 minecraft:blue_terracotta
setblock 155 136 361 minecraft:dark_prismarine
fill 155 136 362 155 139 362 minecraft:blue_terracotta
setblock 156 136 360 minecraft:dark_prismarine
fill 156 136 361 156 139 361 minecraft:blue_terracotta
fill 157 136 356 157 158 356 minecraft:magenta_terracotta
fill 157 136 357 158 136 357 minecraft:pink_terracotta
fill 157 136 360 157 137 360 minecraft:blue_terracotta
setblock 158 136 323 minecraft:dark_prismarine
setblock 158 136 363 minecraft:dark_prismarine
fill 159 136 357 159 140 357 minecraft:magenta_terracotta
setblock 159 136 361 minecraft:blue_terracotta
setblock 159 136 362 minecraft:dark_prismarine
fill 159 136 363 159 139 363 minecraft:blue_terracotta
fill 160 136 362 160 137 362 minecraft:blue_terracotta
fill 165 136 329 165 138 330 minecraft:magenta_terracotta
setblock 166 136 329 minecraft:pink_terracotta
fill 166 136 330 166 153 330 minecraft:magenta_terracotta
setblock 166 136 363 minecraft:purple_concrete
fill 172 136 363 172 137 363 minecraft:purple_concrete
fill 174 136 323 174 139 323 minecraft:blue_terracotta
fill 175 136 363 175 138 363 minecraft:blue_terracotta
setblock 177 136 324 minecraft:dark_prismarine
fill 177 136 363 177 136 364 minecraft:blue_terracotta
setblock 178 136 323 minecraft:dark_prismarine
fill 178 136 324 178 137 324 minecraft:blue_terracotta
setblock 178 136 332 minecraft:blue_terracotta
setblock 178 136 333 minecraft:dark_prismarine
setblock 178 136 334 minecraft:blue_terracotta
setblock 178 136 337 minecraft:pink_terracotta
fill 178 136 338 178 160 338 minecraft:magenta_terracotta
setblock 178 136 363 minecraft:dark_prismarine
fill 178 136 364 178 164 364 minecraft:blue_terracotta
fill 179 136 323 179 139 323 minecraft:blue_terracotta
setblock 179 136 332 minecraft:dark_prismarine
fill 179 136 333 179 138 333 minecraft:blue_terracotta
fill 179 136 363 179 139 363 minecraft:blue_terracotta
setblock 180 136 327 minecraft:blue_terracotta
setblock 180 136 331 minecraft:dark_prismarine
fill 180 136 332 180 139 332 minecraft:blue_terracotta
setblock 180 136 336 minecraft:dark_prismarine
fill 180 136 337 180 139 337 minecraft:blue_terracotta
setblock 181 136 325 minecraft:dark_prismarine
fill 181 136 326 181 137 326 minecraft:blue_terracotta
setblock 181 136 330 minecraft:dark_prismarine
fill 181 136 331 181 139 331 minecraft:blue_terracotta
setblock 181 136 335 minecraft:dark_prismarine
fill 181 136 336 181 139 336 minecraft:blue_terracotta
setblock 181 136 340 minecraft:dark_prismarine
setblock 181 136 341 minecraft:blue_terracotta
setblock 181 136 355 minecraft:dark_prismarine
fill 181 136 356 181 137 356 minecraft:blue_terracotta
setblock 182 136 324 minecraft:dark_prismarine
fill 182 136 325 182 138 325 minecraft:blue_terracotta
setblock 182 136 329 minecraft:dark_prismarine
fill 182 136 330 182 139 330 minecraft:blue_terracotta
setblock 182 136 334 minecraft:dark_prismarine
fill 182 136 335 182 139 335 minecraft:blue_terracotta
setblock 182 136 339 minecraft:dark_prismarine
fill 182 136 340 182 139 340 minecraft:blue_terracotta
setblock 182 136 343 minecraft:purple_concrete
setblock 182 136 350 minecraft:blue_terracotta
setblock 182 136 354 minecraft:dark_prismarine
fill 182 136 355 182 138 355 minecraft:blue_terracotta
setblock 182 136 359 minecraft:dark_prismarine
fill 182 136 360 182 139 360 minecraft:blue_terracotta
fill 183 136 329 183 216 329 minecraft:blue_terracotta
fill 183 136 334 183 177 334 minecraft:blue_terracotta
fill 183 136 339 183 218 339 minecraft:blue_terracotta
fill 183 136 343 183 178 344 minecraft:blue_terracotta
fill 183 136 347 183 220 347 minecraft:blue_terracotta
fill 183 136 349 183 147 349 minecraft:blue_terracotta
fill 142 137 322 142 220 322 minecraft:blue_terracotta
setblock 142 137 323 minecraft:dark_prismarine
setblock 142 137 324 minecraft:blue_terracotta
setblock 142 137 328 minecraft:dark_prismarine
fill 142 137 329 142 138 329 minecraft:blue_terracotta
setblock 142 137 333 minecraft:dark_prismarine
fill 142 137 334 142 139 334 minecraft:blue_terracotta
setblock 142 137 338 minecraft:dark_prismarine
setblock 142 137 349 minecraft:purple_concrete
setblock 142 137 353 minecraft:dark_prismarine
fill 142 137 354 142 139 354 minecraft:blue_terracotta
setblock 142 137 358 minecraft:dark_prismarine
fill 142 137 359 142 140 359 minecraft:blue_terracotta
setblock 142 137 363 minecraft:dark_prismarine
setblock 143 137 323 minecraft:blue_terracotta
setblock 143 137 357 minecraft:dark_prismarine
fill 143 137 358 143 139 358 minecraft:blue_terracotta
fill 143 137 363 146 137 363 minecraft:blue_terracotta
setblock 144 137 325 minecraft:light[level=12]
setblock 144 137 332 minecraft:light[level=12]
setblock 144 137 339 minecraft:light[level=12]
setblock 144 137 346 minecraft:light[level=12]
setblock 144 137 353 minecraft:light[level=12]
setblock 144 137 360 minecraft:light[level=12]
setblock 146 137 323 minecraft:purple_concrete
fill 146 137 349 146 181 349 minecraft:magenta_terracotta
setblock 147 137 363 minecraft:dark_prismarine
fill 148 137 363 148 140 363 minecraft:blue_terracotta
fill 150 137 362 152 137 362 minecraft:blue_terracotta
setblock 151 137 325 minecraft:light[level=12]
setblock 151 137 332 minecraft:light[level=12]
fill 151 137 335 151 162 335 minecraft:magenta_terracotta
setblock 151 137 339 minecraft:light[level=12]
setblock 151 137 346 minecraft:light[level=12]
setblock 151 137 353 minecraft:light[level=12]
setblock 151 137 360 minecraft:light[level=12]
fill 152 137 361 153 137 361 minecraft:blue_terracotta
setblock 152 137 363 minecraft:dark_prismarine
setblock 153 137 362 minecraft:dark_prismarine
fill 153 137 363 153 140 363 minecraft:blue_terracotta
setblock 154 137 361 minecraft:dark_prismarine
fill 154 137 362 154 140 362 minecraft:blue_terracotta
setblock 155 137 360 minecraft:dark_prismarine
fill 155 137 361 155 140 361 minecraft:blue_terracotta
fill 156 137 360 156 138 360 minecraft:blue_terracotta
fill 157 137 357 158 159 357 minecraft:magenta_terracotta
setblock 157 137 363 minecraft:dark_prismarine
setblock 158 137 325 minecraft:light[level=12]
setblock 158 137 332 minecraft:light[level=12]
setblock 158 137 339 minecraft:light[level=12]
setblock 158 137 346 minecraft:light[level=12]
setblock 158 137 353 minecraft:light[level=12]
setblock 158 137 360 minecraft:light[level=12]
setblock 158 137 362 minecraft:dark_prismarine
fill 158 137 363 158 140 363 minecraft:blue_terracotta
setblock 159 137 361 minecraft:dark_prismarine
fill 159 137 362 159 139 362 minecraft:blue_terracotta
setblock 165 137 325 minecraft:light[level=12]
setblock 165 137 332 minecraft:light[level=12]
setblock 165 137 339 minecraft:light[level=12]
setblock 165 137 346 minecraft:light[level=12]
setblock 165 137 353 minecraft:light[level=12]
setblock 165 137 360 minecraft:light[level=12]
fill 166 137 329 166 161 329 minecraft:magenta_terracotta
fill 168 137 329 168 160 329 minecraft:magenta_terracotta
fill 168 137 336 168 138 337 minecraft:black_concrete
setblock 171 137 323 minecraft:purple_concrete
setblock 172 137 325 minecraft:light[level=12]
setblock 172 137 332 minecraft:light[level=12]
setblock 172 137 339 minecraft:light[level=12]
setblock 172 137 346 minecraft:light[level=12]
setblock 172 137 353 minecraft:light[level=12]
setblock 172 137 360 minecraft:light[level=12]
fill 173 137 351 173 159 351 minecraft:magenta_terracotta
fill 176 137 322 176 137 323 minecraft:blue_terracotta
setblock 177 137 323 minecraft:dark_prismarine
setblock 177 137 324 minecraft:blue_terracotta
setblock 177 137 363 minecraft:dark_prismarine
fill 177 137 364 177 220 364 minecraft:blue_terracotta
fill 178 137 323 178 140 323 minecraft:blue_terracotta
fill 178 137 337 178 185 337 minecraft:magenta_terracotta
fill 178 137 363 178 140 363 minecraft:blue_terracotta
setblock 179 137 325 minecraft:light[level=12]
setblock 179 137 331 minecraft:dark_prismarine
setblock 179 137 332 minecraft:blue_terracotta
setblock 179 137 336 minecraft:dark_prismarine
setblock 179 137 339 minecraft:light[level=12]
setblock 179 137 346 minecraft:light[level=12]
setblock 179 137 353 minecraft:light[level=12]
setblock 179 137 360 minecraft:light[level=12]
setblock 180 137 330 minecraft:dark_prismarine
fill 180 137 331 180 138 331 minecraft:blue_terracotta
setblock 180 137 335 minecraft:dark_prismarine
fill 180 137 336 180 139 336 minecraft:blue_terracotta
setblock 181 137 329 minecraft:dark_prismarine
fill 181 137 330 181 139 330 minecraft:blue_terracotta
setblock 181 137 334 minecraft:dark_prismarine
fill 181 137 335 181 140 335 minecraft:blue_terracotta
setblock 181 137 339 minecraft:dark_prismarine
setblock 181 137 340 minecraft:blue_terracotta
setblock 181 137 358 minecraft:blue_terracotta
setblock 182 137 323 minecraft:dark_prismarine
fill 182 137 324 182 138 324 minecraft:blue_terracotta
setblock 182 137 328 minecraft:dark_prismarine
fill 182 137 329 182 139 329 minecraft:blue_terracotta
setblock 182 137 333 minecraft:dark_prismarine
fill 182 137 334 182 140 334 minecraft:blue_terracotta
setblock 182 137 338 minecraft:dark_prismarine
fill 182 137 339 182 140 339 minecraft:blue_terracotta
setblock 182 137 353 minecraft:dark_prismarine
setblock 182 137 354 minecraft:blue_terracotta
setblock 182 137 358 minecraft:dark_prismarine
fill 182 137 359 182 140 359 minecraft:blue_terracotta
fill 183 137 323 183 216 323 minecraft:blue_terracotta
fill 183 137 353 183 217 353 minecraft:blue_terracotta
setblock 142 138 323 minecraft:blue_terracotta
setblock 142 138 328 minecraft:blue_terracotta
setblock 142 138 332 minecraft:dark_prismarine
fill 142 138 333 142 139 333 minecraft:blue_terracotta
setblock 142 138 337 minecraft:dark_prismarine
setblock 142 138 338 minecraft:blue_terracotta
setblock 142 138 353 minecraft:blue_terracotta
setblock 142 138 357 minecraft:dark_prismarine
fill 142 138 358 142 141 358 minecraft:blue_terracotta
setblock 142 138 362 minecraft:dark_prismarine
fill 142 138 363 145 138 363 minecraft:blue_terracotta
setblock 143 138 356 minecraft:dark_prismarine
setblock 143 138 357 minecraft:blue_terracotta
setblock 146 138 363 minecraft:dark_prismarine
fill 147 138 363 147 141 363 minecraft:blue_terracotta
fill 149 138 362 151 138 362 minecraft:blue_terracotta
setblock 151 138 363 minecraft:dark_prismarine
setblock 152 138 361 minecraft:blue_terracotta
setblock 152 138 362 minecraft:dark_prismarine
fill 152 138 363 152 141 363 minecraft:blue_terracotta
setblock 153 138 361 minecraft:dark_prismarine
fill 153 138 362 153 141 362 minecraft:blue_terracotta
fill 154 138 361 154 141 361 minecraft:blue_terracotta
setblock 155 138 360 minecraft:blue_terracotta
setblock 156 138 363 minecraft:dark_prismarine
setblock 157 138 362 minecraft:dark_prismarine
fill 157 138 363 157 141 363 minecraft:blue_terracotta
setblock 158 138 361 minecraft:dark_prismarine
fill 158 138 362 158 141 362 minecraft:blue_terracotta
setblock 165 138 323 minecraft:purple_concrete
fill 165 138 358 165 143 358 minecraft:purple_concrete
fill 174 138 363 174 139 363 minecraft:blue_terracotta
fill 176 138 322 176 220 322 minecraft:blue_terracotta
setblock 176 138 323 minecraft:dark_prismarine
setblock 176 138 363 minecraft:dark_prismarine
fill 177 138 323 177 141 323 minecraft:blue_terracotta
fill 177 138 363 177 141 363 minecraft:blue_terracotta
setblock 179 138 335 minecraft:dark_prismarine
setblock 179 138 336 minecraft:blue_terracotta
setblock 180 138 330 minecraft:blue_terracotta
setblock 180 138 334 minecraft:dark_prismarine
fill 180 138 335 180 139 335 minecraft:blue_terracotta
setblock 181 138 323 minecraft:dark_prismarine
setblock 181 138 328 minecraft:dark_prismarine
setblock 181 138 329 minecraft:blue_terracotta
setblock 181 138 333 minecraft:dark_prismarine
fill 181 138 334 181 140 334 minecraft:blue_terracotta
setblock 181 138 338 minecraft:dark_prismarine
fill 181 138 339 181 139 339 minecraft:blue_terracotta
setblock 181 138 363 minecraft:dark_prismarine
setblock 182 138 323 minecraft:blue_terracotta
setblock 182 138 327 minecraft:dark_prismarine
fill 182 138 328 182 139 328 minecraft:blue_terracotta
setblock 182 138 332 minecraft:dark_prismarine
fill 182 138 333 182 141 333 minecraft:blue_terracotta
setblock 182 138 337 minecraft:dark_prismarine
fill 182 138 338 182 141 338 minecraft:blue_terracotta
setblock 182 138 350 minecraft:purple_concrete
setblock 182 138 357 minecraft:dark_prismarine
fill 182 138 358 182 140 358 minecraft:blue_terracotta
setblock 182 138 362 minecraft:dark_prismarine
fill 141 139 361 141 220 361 minecraft:blue_terracotta
setblock 142 139 323 minecraft:purple_concrete
setblock 142 139 336 minecraft:dark_prismarine
setblock 142 139 342 minecraft:purple_concrete
setblock 142 139 356 minecraft:dark_prismarine
fill 142 139 357 142 142 357 minecraft:blue_terracotta
setblock 142 139 361 minecraft:dark_prismarine
fill 142 139 362 142 141 363 minecraft:blue_terracotta
setblock 143 139 360 minecraft:dark_prismarine
fill 143 139 363 144 139 363 minecraft:blue_terracotta
setblock 145 139 363 minecraft:dark_prismarine
fill 146 139 336 146 156 336 minecraft:green_terracotta
fill 146 139 363 146 142 363 minecraft:blue_terracotta
fill 149 139 362 150 139 362 minecraft:blue_terracotta
setblock 150 139 363 minecraft:dark_prismarine
setblock 151 139 361 minecraft:blue_terracotta
setblock 151 139 362 minecraft:dark_prismarine
fill 151 139 363 151 142 363 minecraft:blue_terracotta
setblock 152 139 361 minecraft:dark_prismarine
fill 152 139 362 152 142 362 minecraft:blue_terracotta
fill 153 139 361 153 142 361 minecraft:blue_terracotta
setblock 155 139 363 minecraft:dark_prismarine
setblock 156 139 362 minecraft:dark_prismarine
fill 156 139 363 156 142 363 minecraft:blue_terracotta
setblock 157 139 361 minecraft:dark_prismarine
fill 157 139 362 157 142 362 minecraft:blue_terracotta
setblock 159 139 323 minecraft:purple_concrete
setblock 160 139 363 minecraft:dark_prismarine
fill 165 139 329 165 142 329 minecraft:magenta_terracotta
fill 165 139 359 165 143 359 minecraft:purple_concrete
setblock 165 139 363 minecraft:purple_concrete
setblock 175 139 323 minecraft:dark_prismarine
setblock 175 139 363 minecraft:dark_prismarine
fill 176 139 323 176 142 323 minecraft:blue_terracotta
fill 176 139 363 176 142 363 minecraft:blue_terracotta
fill 177 139 322 177 196 322 minecraft:blue_terracotta
setblock 178 139 322 minecraft:cyan_concrete
fill 179 139 322 183 157 322 minecraft:blue_terracotta
setblock 180 139 323 minecraft:dark_prismarine
setblock 180 139 333 minecraft:dark_prismarine
setblock 180 139 334 minecraft:blue_terracotta
setblock 180 139 363 minecraft:dark_prismarine
fill 181 139 323 181 142 323 minecraft:blue_terracotta
setblock 181 139 332 minecraft:dark_prismarine
fill 181 139 333 181 140 333 minecraft:blue_terracotta
setblock 181 139 337 minecraft:dark_prismarine
fill 181 139 338 181 140 338 minecraft:blue_terracotta
setblock 181 139 363 minecraft:blue_terracotta
setblock 182 139 327 minecraft:blue_terracotta
setblock 182 139 331 minecraft:dark_prismarine
fill 182 139 332 182 141 332 minecraft:blue_terracotta
setblock 182 139 336 minecraft:dark_prismarine
fill 182 139 337 182 142 337 minecraft:blue_terracotta
setblock 182 139 344 minecraft:purple_concrete
setblock 182 139 357 minecraft:blue_terracotta
setblock 182 139 361 minecraft:dark_prismarine
fill 141 140 323 141 194 325 minecraft:blue_terracotta
setblock 141 140 326 minecraft:light_blue_wool
fill 141 140 327 141 149 328 minecraft:blue_terracotta
setblock 142 140 329 minecraft:purple_concrete
setblock 142 140 348 minecraft:purple_concrete
setblock 142 140 355 minecraft:dark_prismarine
fill 142 140 356 142 142 356 minecraft:blue_terracotta
setblock 142 140 360 minecraft:dark_prismarine
fill 142 140 361 142 143 361 minecraft:blue_terracotta
setblock 143 140 363 minecraft:blue_terracotta
setblock 144 140 363 minecraft:dark_prismarine
fill 145 140 363 145 143 363 minecraft:blue_terracotta
fill 148 140 362 149 140 362 minecraft:blue_terracotta
setblock 149 140 363 minecraft:dark_prismarine
setblock 150 140 362 minecraft:dark_prismarine
fill 150 140 363 150 143 363 minecraft:blue_terracotta
setblock 151 140 361 minecraft:dark_prismarine
fill 151 140 362 151 143 362 minecraft:blue_terracotta
fill 152 140 361 152 143 361 minecraft:blue_terracotta
setblock 153 140 323 minecraft:purple_concrete
setblock 154 140 363 minecraft:dark_prismarine
setblock 155 140 362 minecraft:dark_prismarine
fill 155 140 363 155 143 363 minecraft:blue_terracotta
setblock 156 140 361 minecraft:dark_prismarine
fill 156 140 362 156 143 362 minecraft:blue_terracotta
setblock 157 140 361 minecraft:blue_terracotta
setblock 159 140 363 minecraft:dark_prismarine
fill 164 140 358 164 143 359 minecraft:purple_concrete
fill 165 140 357 165 143 357 minecraft:purple_concrete
fill 166 140 358 166 143 359 minecraft:purple_concrete
setblock 171 140 363 minecraft:purple_concrete
setblock 172 140 323 minecraft:purple_concrete
setblock 173 140 323 minecraft:blue_terracotta
setblock 173 140 363 minecraft:blue_terracotta
fill 174 140 322 174 220 322 minecraft:blue_terracotta
setblock 174 140 323 minecraft:dark_prismarine
setblock 174 140 363 minecraft:dark_prismarine
setblock 175 140 322 minecraft:light_blue_wool
fill 175 140 323 175 143 323 minecraft:blue_terracotta
fill 175 140 363 175 143 363 minecraft:blue_terracotta
fill 178 140 322 178 146 322 minecraft:blue_terracotta
setblock 179 140 323 minecraft:dark_prismarine
setblock 179 140 363 minecraft:dark_prismarine
fill 180 140 323 180 143 323 minecraft:blue_terracotta
fill 180 140 363 180 143 363 minecraft:blue_terracotta
setblock 181 140 336 minecraft:dark_prismarine
setblock 181 140 337 minecraft:blue_terracotta
setblock 182 140 330 minecraft:dark_prismarine
setblock 182 140 331 minecraft:blue_terracotta
setblock 182 140 335 minecraft:dark_prismarine
fill 182 140 336 182 143 336 minecraft:blue_terracotta
setblock 182 140 357 minecraft:purple_concrete
setblock 182 140 360 minecraft:dark_prismarine
fill 182 140 361 182 143 361 minecraft:blue_terracotta
setblock 183 140 338 minecraft:light_blue_wool
fill 141 141 326 141 220 326 minecraft:blue_terracotta
setblock 142 141 335 minecraft:purple_concrete
setblock 142 141 354 minecraft:purple_concrete
setblock 142 141 359 minecraft:dark_prismarine
fill 142 141 360 142 144 360 minecraft:blue_terracotta
setblock 143 141 363 minecraft:dark_prismarine
setblock 144 141 325 minecraft:light[level=13]
setblock 144 141 333 minecraft:light[level=13]
setblock 144 141 341 minecraft:light[level=13]
setblock 144 141 349 minecraft:light[level=13]
setblock 144 141 357 minecraft:light[level=13]
fill 144 141 363 144 144 363 minecraft:blue_terracotta
setblock 147 141 323 minecraft:purple_concrete
fill 147 141 362 148 141 362 minecraft:blue_terracotta
setblock 148 141 363 minecraft:dark_prismarine
setblock 149 141 362 minecraft:dark_prismarine
fill 149 141 363 149 144 363 minecraft:blue_terracotta
setblock 150 141 361 minecraft:dark_prismarine
fill 150 141 362 150 144 362 minecraft:blue_terracotta
fill 151 141 361 151 144 361 minecraft:blue_terracotta
setblock 152 141 325 minecraft:light[level=13]
setblock 152 141 333 minecraft:light[level=13]
setblock 152 141 341 minecraft:light[level=13]
setblock 152 141 349 minecraft:light[level=13]
setblock 152 141 357 minecraft:light[level=13]
setblock 153 141 363 minecraft:dark_prismarine
setblock 154 141 362 minecraft:dark_prismarine
fill 154 141 363 154 144 363 minecraft:blue_terracotta
setblock 155 141 361 minecraft:dark_prismarine
fill 155 141 362 155 144 362 minecraft:blue_terracotta
fill 156 141 358 156 160 358 minecraft:magenta_terracotta
fill 156 141 361 156 144 361 minecraft:blue_terracotta
setblock 158 141 363 minecraft:dark_prismarine
fill 159 141 363 159 144 363 minecraft:blue_terracotta
setblock 160 141 325 minecraft:light[level=13]
setblock 160 141 333 minecraft:light[level=13]
setblock 160 141 341 minecraft:light[level=13]
setblock 160 141 349 minecraft:light[level=13]
setblock 160 141 357 minecraft:light[level=13]
fill 163 141 358 163 143 359 minecraft:purple_concrete
fill 164 141 357 164 143 357 minecraft:purple_concrete
fill 164 141 360 166 143 360 minecraft:purple_concrete
setblock 166 141 323 minecraft:purple_concrete
fill 166 141 357 166 143 357 minecraft:purple_concrete
fill 167 141 358 167 143 359 minecraft:purple_concrete
setblock 168 141 325 minecraft:light[level=13]
fill 168 141 330 168 169 330 minecraft:magenta_terracotta
setblock 168 141 333 minecraft:light[level=13]
setblock 168 141 341 minecraft:light[level=13]
setblock 168 141 349 minecraft:light[level=13]
setblock 168 141 357 minecraft:light[level=13]
setblock 172 141 323 minecraft:blue_terracotta
setblock 172 141 363 minecraft:blue_terracotta
setblock 173 141 323 minecraft:dark_prismarine
setblock 173 141 363 minecraft:dark_prismarine
fill 174 141 323 174 144 323 minecraft:blue_terracotta
fill 174 141 351 174 145 352 minecraft:magenta_terracotta
fill 174 141 363 174 144 363 minecraft:blue_terracotta
fill 175 141 322 175 216 322 minecraft:blue_terracotta
fill 175 141 362 176 143 362 minecraft:blue_terracotta
setblock 176 141 325 minecraft:light[level=13]
setblock 176 141 333 minecraft:light[level=13]
setblock 176 141 341 minecraft:light[level=13]
setblock 176 141 349 minecraft:light[level=13]
setblock 176 141 357 minecraft:light[level=13]
setblock 178 141 323 minecraft:dark_prismarine
fill 178 141 339 178 145 339 minecraft:magenta_terracotta
setblock 178 141 363 minecraft:dark_prismarine
fill 179 141 323 179 144 323 minecraft:blue_terracotta
fill 179 141 363 179 144 363 minecraft:blue_terracotta
setblock 181 141 336 minecraft:blue_terracotta
fill 181 141 363 181 142 363 minecraft:blue_terracotta
setblock 182 141 334 minecraft:dark_prismarine
fill 182 141 335 182 142 335 minecraft:blue_terracotta
setblock 182 141 339 minecraft:dark_prismarine
setblock 182 141 351 minecraft:purple_concrete
setblock 182 141 359 minecraft:dark_prismarine
fill 182 141 360 182 144 360 minecraft:blue_terracotta
fill 182 141 362 182 142 362 minecraft:blue_terracotta
fill 183 141 338 183 186 338 minecraft:blue_terracotta
setblock 142 142 341 minecraft:purple_concrete
setblock 142 142 358 minecraft:dark_prismarine
fill 142 142 359 142 145 359 minecraft:blue_terracotta
setblock 142 142 362 minecraft:blue_terracotta
setblock 142 142 363 minecraft:dark_prismarine
fill 143 142 360 143 142 361 minecraft:blue_terracotta
fill 143 142 363 143 145 363 minecraft:blue_terracotta
fill 145 142 362 147 142 362 minecraft:blue_terracotta
setblock 147 142 363 minecraft:dark_prismarine
setblock 148 142 362 minecraft:dark_prismarine
fill 148 142 363 148 145 363 minecraft:blue_terracotta
setblock 149 142 361 minecraft:dark_prismarine
fill 149 142 362 149 145 362 minecraft:blue_terracotta
fill 150 142 361 150 145 361 minecraft:blue_terracotta
setblock 152 142 323 minecraft:dark_prismarine
setblock 152 142 363 minecraft:dark_prismarine
fill 153 142 323 154 144 323 minecraft:blue_terracotta
schedule function dropper:buildpart/75_8 1t
