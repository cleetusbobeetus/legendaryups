fill 512 158 455 512 158 456 minecraft:orange_concrete
fill 512 158 457 512 163 457 minecraft:red_nether_bricks
fill 470 159 418 470 159 419 minecraft:orange_concrete
setblock 470 159 422 minecraft:orange_concrete
fill 470 159 423 470 162 423 minecraft:red_nether_bricks
fill 470 159 434 470 162 434 minecraft:red_nether_bricks
setblock 470 159 439 minecraft:orange_concrete
setblock 470 159 450 minecraft:orange_concrete
fill 470 159 454 470 162 455 minecraft:red_nether_bricks
setblock 472 159 416 minecraft:orange_concrete
setblock 483 159 458 minecraft:orange_concrete
setblock 486 159 458 minecraft:orange_concrete
fill 487 159 458 487 162 458 minecraft:red_nether_bricks
fill 488 159 416 488 162 416 minecraft:red_nether_bricks
fill 488 159 443 488 159 445 minecraft:blackstone
setblock 489 159 446 minecraft:blackstone
setblock 491 159 446 minecraft:blackstone
setblock 492 159 416 minecraft:orange_concrete
fill 492 159 444 492 159 445 minecraft:blackstone
setblock 494 159 458 minecraft:orange_concrete
fill 498 159 450 499 159 450 minecraft:red_nether_bricks
fill 498 159 458 498 162 458 minecraft:red_nether_bricks
fill 499 159 416 499 162 416 minecraft:red_nether_bricks
setblock 500 159 416 minecraft:orange_concrete
setblock 503 159 416 minecraft:orange_concrete
fill 503 159 446 503 166 446 minecraft:red_nether_bricks
fill 503 159 449 503 162 449 minecraft:red_nether_bricks
fill 512 159 423 512 162 424 minecraft:red_nether_bricks
setblock 512 159 428 minecraft:orange_concrete
setblock 512 159 439 minecraft:orange_concrete
fill 512 159 444 512 162 444 minecraft:red_nether_bricks
fill 512 159 455 512 162 455 minecraft:red_nether_bricks
setblock 512 159 456 minecraft:orange_concrete
fill 470 160 417 470 161 417 minecraft:orange_concrete
fill 470 160 418 470 161 419 minecraft:red_nether_bricks
fill 470 160 420 470 160 421 minecraft:orange_concrete
fill 470 160 422 470 165 422 minecraft:red_nether_bricks
fill 470 160 428 470 161 429 minecraft:orange_concrete
fill 470 160 430 470 165 431 minecraft:red_nether_bricks
fill 470 160 439 470 165 439 minecraft:red_nether_bricks
fill 470 160 440 470 160 441 minecraft:orange_concrete
fill 470 160 442 470 165 443 minecraft:red_nether_bricks
fill 470 160 448 470 161 449 minecraft:orange_concrete
fill 470 160 450 470 165 451 minecraft:red_nether_bricks
setblock 470 160 452 minecraft:orange_concrete
fill 471 160 416 472 165 416 minecraft:red_nether_bricks
fill 472 160 458 473 161 458 minecraft:orange_concrete
fill 473 160 416 474 161 416 minecraft:orange_concrete
setblock 473 160 419 minecraft:light[level=14]
setblock 473 160 427 minecraft:light[level=14]
setblock 473 160 435 minecraft:light[level=14]
setblock 473 160 443 minecraft:light[level=14]
setblock 473 160 451 minecraft:light[level=14]
fill 474 160 458 475 165 458 minecraft:red_nether_bricks
fill 475 160 416 476 161 416 minecraft:red_nether_bricks
fill 479 160 416 480 165 416 minecraft:red_nether_bricks
fill 481 160 416 482 160 416 minecraft:orange_concrete
setblock 481 160 419 minecraft:light[level=14]
setblock 481 160 427 minecraft:light[level=14]
setblock 481 160 435 minecraft:light[level=14]
setblock 481 160 443 minecraft:light[level=14]
setblock 481 160 451 minecraft:light[level=14]
fill 481 160 458 481 161 458 minecraft:orange_concrete
fill 483 160 458 483 165 458 minecraft:red_nether_bricks
fill 484 160 458 485 160 458 minecraft:orange_concrete
fill 486 160 458 486 165 458 minecraft:red_nether_bricks
setblock 489 160 419 minecraft:light[level=14]
setblock 489 160 427 minecraft:light[level=14]
setblock 489 160 435 minecraft:light[level=14]
setblock 489 160 443 minecraft:light[level=14]
setblock 489 160 451 minecraft:light[level=14]
fill 491 160 416 492 165 416 minecraft:red_nether_bricks
fill 492 160 458 493 161 458 minecraft:orange_concrete
fill 493 160 416 494 161 416 minecraft:orange_concrete
fill 494 160 458 495 165 458 minecraft:red_nether_bricks
setblock 497 160 419 minecraft:light[level=14]
setblock 497 160 427 minecraft:light[level=14]
setblock 497 160 435 minecraft:light[level=14]
setblock 497 160 443 minecraft:light[level=14]
setblock 497 160 451 minecraft:light[level=14]
fill 499 160 450 500 160 450 minecraft:red_nether_bricks
fill 500 160 416 500 165 416 minecraft:red_nether_bricks
fill 501 160 416 502 160 416 minecraft:orange_concrete
fill 501 160 445 503 164 445 minecraft:red_nether_bricks
fill 503 160 416 503 165 416 minecraft:red_nether_bricks
fill 504 160 446 504 163 448 minecraft:red_nether_bricks
fill 504 160 458 505 160 458 minecraft:orange_concrete
fill 505 160 416 505 161 416 minecraft:orange_concrete
setblock 505 160 419 minecraft:light[level=14]
setblock 505 160 435 minecraft:light[level=14]
setblock 505 160 443 minecraft:light[level=14]
setblock 505 160 451 minecraft:light[level=14]
fill 506 160 458 507 165 458 minecraft:red_nether_bricks
fill 511 160 416 512 165 416 minecraft:red_nether_bricks
fill 512 160 417 512 161 418 minecraft:orange_concrete
setblock 512 160 426 minecraft:orange_concrete
fill 512 160 427 512 165 428 minecraft:red_nether_bricks
fill 512 160 429 512 161 430 minecraft:orange_concrete
fill 512 160 435 512 165 436 minecraft:red_nether_bricks
fill 512 160 437 512 160 438 minecraft:orange_concrete
fill 512 160 439 512 165 439 minecraft:red_nether_bricks
fill 512 160 447 512 165 448 minecraft:red_nether_bricks
fill 512 160 449 512 161 450 minecraft:orange_concrete
fill 512 160 456 512 165 456 minecraft:red_nether_bricks
setblock 470 161 416 minecraft:orange_concrete
fill 470 161 420 470 163 421 minecraft:red_nether_bricks
setblock 470 161 435 minecraft:red_nether_bricks
fill 470 161 436 470 161 437 minecraft:orange_concrete
setblock 470 161 440 minecraft:orange_concrete
fill 470 161 441 470 164 441 minecraft:red_nether_bricks
fill 470 161 452 470 164 452 minecraft:red_nether_bricks
setblock 470 161 457 minecraft:orange_concrete
setblock 480 161 458 minecraft:orange_concrete
fill 481 161 416 481 164 416 minecraft:red_nether_bricks
setblock 482 161 416 minecraft:orange_concrete
fill 483 161 416 484 161 416 minecraft:red_nether_bricks
fill 484 161 458 485 164 458 minecraft:red_nether_bricks
setblock 485 161 416 minecraft:orange_concrete
fill 500 161 447 500 162 447 minecraft:red_nether_bricks
fill 500 161 449 502 161 449 minecraft:red_nether_bricks
fill 501 161 416 502 164 416 minecraft:red_nether_bricks
setblock 501 161 458 minecraft:orange_concrete
fill 502 161 444 504 166 444 minecraft:red_nether_bricks
fill 502 161 448 502 163 448 minecraft:red_nether_bricks
fill 504 161 445 504 167 445 minecraft:red_nether_bricks
setblock 504 161 458 minecraft:orange_concrete
fill 505 161 446 505 164 447 minecraft:red_nether_bricks
fill 505 161 458 505 164 458 minecraft:red_nether_bricks
setblock 506 161 416 minecraft:orange_concrete
fill 507 161 416 508 161 416 minecraft:red_nether_bricks
setblock 512 161 421 minecraft:orange_concrete
fill 512 161 426 512 164 426 minecraft:red_nether_bricks
fill 512 161 437 512 164 437 minecraft:red_nether_bricks
setblock 512 161 438 minecraft:orange_concrete
fill 512 161 441 512 161 442 minecraft:orange_concrete
setblock 512 161 458 minecraft:orange_concrete
fill 470 162 416 470 167 417 minecraft:red_nether_bricks
setblock 470 162 418 minecraft:orange_concrete
fill 470 162 419 471 162 419 minecraft:red_nether_bricks
fill 470 162 426 470 162 427 minecraft:orange_concrete
fill 470 162 428 471 162 429 minecraft:red_nether_bricks
fill 470 162 435 470 163 435 minecraft:orange_concrete
fill 470 162 436 471 162 437 minecraft:red_nether_bricks
setblock 470 162 438 minecraft:orange_concrete
fill 470 162 440 471 162 440 minecraft:red_nether_bricks
fill 470 162 446 470 163 447 minecraft:orange_concrete
fill 470 162 448 471 162 449 minecraft:red_nether_bricks
fill 470 162 457 471 162 457 minecraft:red_nether_bricks
fill 470 162 458 471 162 458 minecraft:orange_concrete
fill 471 162 417 473 162 417 minecraft:red_nether_bricks
fill 471 162 420 471 162 421 minecraft:red_nether_bricks
fill 471 162 423 471 162 425 minecraft:red_nether_bricks
setblock 471 162 427 minecraft:red_nether_bricks
fill 471 162 431 471 162 433 minecraft:red_nether_bricks
setblock 471 162 435 minecraft:red_nether_bricks
setblock 471 162 439 minecraft:red_nether_bricks
setblock 471 162 441 minecraft:red_nether_bricks
fill 471 162 443 471 162 445 minecraft:red_nether_bricks
setblock 471 162 447 minecraft:red_nether_bricks
fill 471 162 451 471 162 453 minecraft:red_nether_bricks
fill 471 162 455 471 162 456 minecraft:red_nether_bricks
fill 472 162 458 473 167 458 minecraft:red_nether_bricks
fill 473 162 416 474 167 416 minecraft:red_nether_bricks
fill 473 162 457 475 162 457 minecraft:red_nether_bricks
fill 475 162 416 476 163 416 minecraft:orange_concrete
fill 475 162 417 477 162 417 minecraft:red_nether_bricks
fill 477 162 457 479 162 457 minecraft:red_nether_bricks
fill 478 162 458 479 163 458 minecraft:orange_concrete
fill 479 162 417 481 162 417 minecraft:red_nether_bricks
fill 480 162 458 481 167 458 minecraft:red_nether_bricks
fill 481 162 457 483 162 457 minecraft:red_nether_bricks
fill 482 162 416 482 167 416 minecraft:red_nether_bricks
setblock 482 162 458 minecraft:orange_concrete
fill 483 162 416 484 162 416 minecraft:orange_concrete
fill 483 162 417 485 162 417 minecraft:red_nether_bricks
fill 485 162 416 485 167 416 minecraft:red_nether_bricks
fill 485 162 457 487 162 457 minecraft:red_nether_bricks
fill 487 162 416 487 163 416 minecraft:orange_concrete
fill 487 162 417 489 162 417 minecraft:red_nether_bricks
fill 489 162 457 491 162 457 minecraft:red_nether_bricks
fill 490 162 458 491 163 458 minecraft:orange_concrete
fill 491 162 417 493 162 417 minecraft:red_nether_bricks
fill 492 162 458 493 167 458 minecraft:red_nether_bricks
fill 493 162 416 494 167 416 minecraft:red_nether_bricks
fill 493 162 457 495 162 457 minecraft:red_nether_bricks
fill 495 162 416 496 163 416 minecraft:orange_concrete
fill 495 162 417 497 162 417 minecraft:red_nether_bricks
fill 497 162 457 499 162 457 minecraft:red_nether_bricks
fill 499 162 417 501 162 417 minecraft:red_nether_bricks
fill 499 162 458 499 163 458 minecraft:orange_concrete
setblock 500 162 448 minecraft:red_nether_bricks
fill 501 162 449 502 162 449 minecraft:red_nether_bricks
fill 501 162 457 501 162 458 minecraft:red_nether_bricks
fill 502 162 457 503 162 457 minecraft:red_nether_bricks
fill 502 162 458 503 162 458 minecraft:orange_concrete
fill 503 162 417 505 162 417 minecraft:red_nether_bricks
fill 503 162 443 504 168 443 minecraft:red_nether_bricks
setblock 504 162 416 minecraft:orange_concrete
fill 504 162 458 504 167 458 minecraft:red_nether_bricks
fill 505 162 416 506 167 416 minecraft:red_nether_bricks
fill 505 162 444 505 167 445 minecraft:red_nether_bricks
fill 505 162 457 507 162 457 minecraft:red_nether_bricks
fill 507 162 416 508 163 416 minecraft:orange_concrete
fill 507 162 417 509 162 417 minecraft:red_nether_bricks
fill 509 162 457 511 162 457 minecraft:red_nether_bricks
fill 510 162 458 511 163 458 minecraft:orange_concrete
fill 511 162 417 511 162 419 minecraft:red_nether_bricks
fill 511 162 421 511 162 423 minecraft:red_nether_bricks
fill 511 162 425 511 162 427 minecraft:red_nether_bricks
fill 511 162 429 511 162 431 minecraft:red_nether_bricks
fill 511 162 433 511 162 435 minecraft:red_nether_bricks
fill 511 162 437 511 162 439 minecraft:red_nether_bricks
fill 511 162 441 511 162 443 minecraft:red_nether_bricks
fill 511 162 445 511 162 447 minecraft:red_nether_bricks
fill 511 162 449 511 162 451 minecraft:red_nether_bricks
fill 511 162 453 511 162 455 minecraft:red_nether_bricks
fill 512 162 417 512 167 418 minecraft:red_nether_bricks
fill 512 162 419 512 162 420 minecraft:orange_concrete
fill 512 162 421 512 167 421 minecraft:red_nether_bricks
fill 512 162 429 512 167 430 minecraft:red_nether_bricks
fill 512 162 431 512 163 432 minecraft:orange_concrete
fill 512 162 438 512 167 438 minecraft:red_nether_bricks
setblock 512 162 440 minecraft:orange_concrete
fill 512 162 441 512 167 442 minecraft:red_nether_bricks
fill 512 162 443 512 163 443 minecraft:orange_concrete
fill 512 162 449 512 167 450 minecraft:red_nether_bricks
fill 512 162 451 512 162 452 minecraft:orange_concrete
fill 512 162 458 512 167 458 minecraft:red_nether_bricks
fill 470 163 418 470 165 419 minecraft:red_nether_bricks
setblock 470 163 423 minecraft:orange_concrete
setblock 470 163 426 minecraft:orange_concrete
fill 470 163 427 470 166 429 minecraft:red_nether_bricks
setblock 470 163 434 minecraft:orange_concrete
fill 470 163 436 470 166 438 minecraft:red_nether_bricks
fill 470 163 440 470 167 440 minecraft:red_nether_bricks
fill 470 163 448 470 167 449 minecraft:red_nether_bricks
fill 470 163 454 470 163 455 minecraft:orange_concrete
fill 470 163 457 470 167 457 minecraft:red_nether_bricks
setblock 470 163 458 minecraft:orange_concrete
fill 471 163 458 471 166 458 minecraft:red_nether_bricks
fill 482 163 458 482 166 458 minecraft:red_nether_bricks
fill 483 163 416 484 165 416 minecraft:red_nether_bricks
setblock 487 163 458 minecraft:orange_concrete
setblock 488 163 416 minecraft:orange_concrete
setblock 498 163 458 minecraft:orange_concrete
setblock 499 163 416 minecraft:orange_concrete
setblock 501 163 444 minecraft:red_nether_bricks
fill 501 163 446 502 164 446 minecraft:red_nether_bricks
fill 501 163 458 503 166 458 minecraft:red_nether_bricks
fill 502 163 443 502 166 443 minecraft:red_nether_bricks
fill 504 163 416 504 166 416 minecraft:red_nether_bricks
fill 505 163 443 505 170 443 minecraft:red_nether_bricks
fill 506 163 444 506 166 445 minecraft:red_nether_bricks
fill 512 163 419 512 166 419 minecraft:red_nether_bricks
setblock 512 163 420 minecraft:orange_concrete
fill 512 163 423 512 163 424 minecraft:orange_concrete
fill 512 163 440 512 166 440 minecraft:red_nether_bricks
setblock 512 163 444 minecraft:orange_concrete
fill 512 163 451 512 166 451 minecraft:red_nether_bricks
setblock 512 163 452 minecraft:orange_concrete
setblock 512 163 455 minecraft:orange_concrete
setblock 470 164 420 minecraft:red_nether_bricks
fill 470 164 421 470 165 421 minecraft:orange_concrete
fill 470 164 423 470 169 423 minecraft:red_nether_bricks
fill 470 164 424 470 164 425 minecraft:orange_concrete
fill 470 164 426 470 169 426 minecraft:red_nether_bricks
fill 470 164 432 470 165 433 minecraft:orange_concrete
fill 470 164 434 470 169 435 minecraft:red_nether_bricks
fill 470 164 444 470 164 445 minecraft:orange_concrete
fill 470 164 446 470 169 447 minecraft:red_nether_bricks
fill 470 164 453 470 165 453 minecraft:orange_concrete
fill 470 164 454 470 169 455 minecraft:red_nether_bricks
setblock 470 164 456 minecraft:orange_concrete
fill 470 164 458 470 169 458 minecraft:red_nether_bricks
fill 475 164 416 476 169 416 minecraft:red_nether_bricks
fill 476 164 458 477 165 458 minecraft:orange_concrete
fill 477 164 416 478 165 416 minecraft:orange_concrete
fill 478 164 458 479 169 458 minecraft:red_nether_bricks
fill 481 164 447 482 165 448 minecraft:magma_block
fill 482 164 446 482 165 446 minecraft:magma_block
setblock 486 164 416 minecraft:orange_concrete
fill 487 164 416 488 169 416 minecraft:red_nether_bricks
fill 487 164 458 487 169 458 minecraft:red_nether_bricks
fill 488 164 458 489 164 458 minecraft:orange_concrete
fill 489 164 416 490 165 416 minecraft:orange_concrete
fill 490 164 458 491 169 458 minecraft:red_nether_bricks
fill 495 164 416 496 169 416 minecraft:red_nether_bricks
fill 496 164 458 497 165 458 minecraft:orange_concrete
fill 497 164 416 498 164 416 minecraft:orange_concrete
fill 498 164 458 499 169 458 minecraft:red_nether_bricks
fill 499 164 416 499 169 416 minecraft:red_nether_bricks
setblock 500 164 458 minecraft:orange_concrete
fill 502 164 447 504 164 447 minecraft:red_nether_bricks
fill 503 164 442 505 169 442 minecraft:red_nether_bricks
fill 504 164 446 504 166 446 minecraft:red_nether_bricks
fill 506 164 443 506 169 443 minecraft:red_nether_bricks
fill 507 164 416 508 169 416 minecraft:red_nether_bricks
fill 508 164 458 509 165 458 minecraft:orange_concrete
fill 509 164 416 510 165 416 minecraft:orange_concrete
fill 510 164 458 511 169 458 minecraft:red_nether_bricks
fill 512 164 420 512 169 420 minecraft:red_nether_bricks
setblock 512 164 422 minecraft:orange_concrete
fill 512 164 423 512 169 424 minecraft:red_nether_bricks
fill 512 164 425 512 165 425 minecraft:orange_concrete
fill 512 164 431 512 169 432 minecraft:red_nether_bricks
fill 512 164 433 512 164 434 minecraft:orange_concrete
fill 512 164 443 512 169 444 minecraft:red_nether_bricks
fill 512 164 445 512 165 446 minecraft:orange_concrete
fill 512 164 452 512 169 452 minecraft:red_nether_bricks
fill 512 164 453 512 164 454 minecraft:orange_concrete
fill 512 164 455 512 169 455 minecraft:red_nether_bricks
fill 512 164 457 512 165 457 minecraft:orange_concrete
setblock 470 165 420 minecraft:orange_concrete
fill 470 165 424 470 168 425 minecraft:red_nether_bricks
setblock 470 165 441 minecraft:orange_concrete
setblock 470 165 444 minecraft:orange_concrete
fill 470 165 445 470 168 445 minecraft:red_nether_bricks
setblock 470 165 452 minecraft:orange_concrete
fill 470 165 456 470 168 456 minecraft:red_nether_bricks
setblock 481 165 416 minecraft:orange_concrete
fill 484 165 458 485 165 458 minecraft:orange_concrete
fill 486 165 416 486 167 416 minecraft:red_nether_bricks
setblock 488 165 458 minecraft:orange_concrete
fill 489 165 458 489 168 458 minecraft:red_nether_bricks
fill 497 165 416 497 168 416 minecraft:red_nether_bricks
setblock 498 165 416 minecraft:orange_concrete
fill 500 165 458 500 168 458 minecraft:red_nether_bricks
fill 501 165 416 502 165 416 minecraft:orange_concrete
fill 502 165 445 502 165 446 minecraft:red_nether_bricks
fill 502 165 447 502 167 447 minecraft:magma_block
fill 503 165 445 503 167 445 minecraft:red_nether_bricks
fill 503 165 447 504 165 447 minecraft:red_nether_bricks
fill 504 165 441 506 171 441 minecraft:red_nether_bricks
fill 505 165 446 505 166 446 minecraft:red_nether_bricks
setblock 505 165 458 minecraft:orange_concrete
fill 506 165 442 506 171 442 minecraft:red_nether_bricks
fill 507 165 443 507 168 443 minecraft:red_nether_bricks
fill 512 165 422 512 168 422 minecraft:red_nether_bricks
setblock 512 165 426 minecraft:orange_concrete
fill 512 165 433 512 168 433 minecraft:red_nether_bricks
setblock 512 165 434 minecraft:orange_concrete
setblock 512 165 437 minecraft:orange_concrete
fill 512 165 453 512 168 454 minecraft:red_nether_bricks
fill 470 166 418 470 167 419 minecraft:orange_concrete
fill 470 166 420 470 171 421 minecraft:red_nether_bricks
setblock 470 166 422 minecraft:orange_concrete
fill 470 166 430 470 167 431 minecraft:orange_concrete
fill 470 166 432 470 171 433 minecraft:red_nether_bricks
fill 470 166 439 470 167 439 minecraft:orange_concrete
fill 470 166 441 470 171 441 minecraft:red_nether_bricks
fill 470 166 442 470 166 443 minecraft:orange_concrete
fill 470 166 444 470 171 444 minecraft:red_nether_bricks
fill 470 166 450 470 167 451 minecraft:orange_concrete
fill 470 166 452 470 171 453 minecraft:red_nether_bricks
fill 471 166 416 472 167 416 minecraft:orange_concrete
fill 474 166 458 475 166 458 minecraft:orange_concrete
fill 476 166 458 477 171 458 minecraft:red_nether_bricks
fill 477 166 416 478 168 416 minecraft:red_nether_bricks
fill 479 166 416 480 166 416 minecraft:orange_concrete
fill 481 166 416 481 171 416 minecraft:red_nether_bricks
fill 483 166 416 483 167 416 minecraft:orange_concrete
fill 483 166 458 483 167 458 minecraft:orange_concrete
setblock 484 166 416 minecraft:red_nether_bricks
fill 484 166 458 485 171 458 minecraft:red_nether_bricks
setblock 486 166 458 minecraft:orange_concrete
fill 488 166 458 488 171 458 minecraft:red_nether_bricks
fill 489 166 416 490 171 416 minecraft:red_nether_bricks
fill 491 166 416 492 167 416 minecraft:orange_concrete
fill 494 166 458 495 167 458 minecraft:orange_concrete
fill 496 166 458 497 171 458 minecraft:red_nether_bricks
fill 498 166 416 498 171 416 minecraft:red_nether_bricks
setblock 500 166 416 minecraft:orange_concrete
fill 501 166 416 502 171 416 minecraft:red_nether_bricks
setblock 502 166 445 minecraft:red_nether_bricks
fill 503 166 416 503 167 416 minecraft:orange_concrete
fill 503 166 441 503 169 441 minecraft:red_nether_bricks
fill 503 166 447 503 167 447 minecraft:magma_block
fill 504 166 440 506 172 440 minecraft:red_nether_bricks
fill 505 166 458 505 171 458 minecraft:red_nether_bricks
fill 506 166 458 507 166 458 minecraft:orange_concrete
fill 507 166 441 507 170 442 minecraft:red_nether_bricks
fill 507 166 444 507 167 444 minecraft:red_nether_bricks
fill 508 166 458 509 171 458 minecraft:red_nether_bricks
fill 509 166 416 510 171 416 minecraft:red_nether_bricks
fill 511 166 416 512 166 416 minecraft:orange_concrete
fill 512 166 425 512 171 426 minecraft:red_nether_bricks
fill 512 166 427 512 167 428 minecraft:orange_concrete
fill 512 166 434 512 171 434 minecraft:red_nether_bricks
fill 512 166 435 512 166 436 minecraft:orange_concrete
fill 512 166 437 512 171 437 minecraft:red_nether_bricks
fill 512 166 439 512 167 439 minecraft:orange_concrete
fill 512 166 445 512 171 446 minecraft:red_nether_bricks
fill 512 166 447 512 167 448 minecraft:orange_concrete
setblock 512 166 456 minecraft:orange_concrete
fill 512 166 457 512 171 457 minecraft:red_nether_bricks
fill 470 167 422 470 170 422 minecraft:red_nether_bricks
setblock 470 167 427 minecraft:orange_concrete
fill 470 167 428 470 167 429 minecraft:red_nether_bricks
fill 470 167 436 470 167 437 minecraft:red_nether_bricks
setblock 470 167 438 minecraft:orange_concrete
fill 470 167 442 470 170 443 minecraft:red_nether_bricks
setblock 471 167 458 minecraft:orange_concrete
setblock 474 167 458 minecraft:orange_concrete
fill 475 167 458 475 170 458 minecraft:red_nether_bricks
fill 479 167 416 479 170 416 minecraft:red_nether_bricks
setblock 480 167 416 minecraft:orange_concrete
setblock 482 167 458 minecraft:orange_concrete
setblock 484 167 416 minecraft:orange_concrete
fill 486 167 458 486 170 458 minecraft:red_nether_bricks
fill 500 167 416 500 170 416 minecraft:red_nether_bricks
setblock 501 167 458 minecraft:red_nether_bricks
fill 502 167 458 503 167 458 minecraft:orange_concrete
fill 503 167 444 504 167 444 minecraft:red_nether_bricks
setblock 504 167 416 minecraft:orange_concrete
fill 505 167 439 506 174 439 minecraft:red_nether_bricks
fill 506 167 444 506 168 444 minecraft:red_nether_bricks
setblock 506 167 458 minecraft:orange_concrete
fill 507 167 440 507 172 440 minecraft:red_nether_bricks
fill 507 167 458 507 170 458 minecraft:red_nether_bricks
fill 511 167 416 511 170 416 minecraft:red_nether_bricks
setblock 512 167 416 minecraft:orange_concrete
setblock 512 167 419 minecraft:orange_concrete
fill 512 167 435 512 170 436 minecraft:red_nether_bricks
setblock 512 167 440 minecraft:orange_concrete
setblock 512 167 451 minecraft:orange_concrete
fill 512 167 456 512 170 456 minecraft:red_nether_bricks
fill 470 168 416 470 169 417 minecraft:orange_concrete
fill 470 168 418 470 173 419 minecraft:red_nether_bricks
fill 470 168 427 471 168 427 minecraft:red_nether_bricks
fill 470 168 428 470 168 429 minecraft:orange_concrete
fill 470 168 430 470 173 431 minecraft:red_nether_bricks
fill 470 168 436 470 169 437 minecraft:orange_concrete
fill 470 168 438 470 173 439 minecraft:red_nether_bricks
setblock 470 168 440 minecraft:orange_concrete
fill 470 168 448 470 169 449 minecraft:orange_concrete
fill 470 168 450 470 173 451 minecraft:red_nether_bricks
fill 470 168 457 470 169 457 minecraft:orange_concrete
fill 471 168 416 472 168 417 minecraft:red_nether_bricks
fill 471 168 419 471 168 421 minecraft:red_nether_bricks
fill 471 168 423 471 168 425 minecraft:red_nether_bricks
fill 471 168 428 471 168 429 minecraft:red_nether_bricks
fill 471 168 431 471 168 433 minecraft:red_nether_bricks
fill 471 168 435 471 168 437 minecraft:red_nether_bricks
fill 471 168 439 471 168 441 minecraft:red_nether_bricks
fill 471 168 443 471 168 445 minecraft:red_nether_bricks
fill 471 168 447 471 168 449 minecraft:red_nether_bricks
fill 471 168 451 471 168 453 minecraft:red_nether_bricks
fill 471 168 455 471 168 458 minecraft:red_nether_bricks
fill 472 168 458 473 168 458 minecraft:orange_concrete
fill 473 168 416 474 169 416 minecraft:orange_concrete
setblock 473 168 417 minecraft:red_nether_bricks
setblock 473 168 419 minecraft:light[level=14]
setblock 473 168 427 minecraft:light[level=14]
setblock 473 168 435 minecraft:light[level=14]
setblock 473 168 443 minecraft:light[level=14]
setblock 473 168 451 minecraft:light[level=14]
fill 473 168 457 475 168 457 minecraft:red_nether_bricks
fill 474 168 458 474 173 458 minecraft:red_nether_bricks
fill 475 168 417 477 168 417 minecraft:red_nether_bricks
fill 477 168 457 479 168 457 minecraft:red_nether_bricks
fill 479 168 417 481 168 417 minecraft:red_nether_bricks
fill 480 168 416 480 170 416 minecraft:red_nether_bricks
fill 480 168 458 481 169 458 minecraft:orange_concrete
setblock 481 168 419 minecraft:light[level=14]
setblock 481 168 427 minecraft:light[level=14]
setblock 481 168 435 minecraft:light[level=14]
setblock 481 168 443 minecraft:light[level=14]
setblock 481 168 451 minecraft:light[level=14]
fill 481 168 457 483 168 457 minecraft:red_nether_bricks
setblock 482 168 416 minecraft:orange_concrete
fill 482 168 458 483 173 458 minecraft:red_nether_bricks
fill 483 168 416 484 168 417 minecraft:red_nether_bricks
fill 485 168 416 486 169 416 minecraft:orange_concrete
setblock 485 168 417 minecraft:red_nether_bricks
fill 485 168 457 487 168 457 minecraft:red_nether_bricks
fill 487 168 417 489 168 417 minecraft:red_nether_bricks
setblock 489 168 419 minecraft:light[level=14]
setblock 489 168 427 minecraft:light[level=14]
setblock 489 168 435 minecraft:light[level=14]
setblock 489 168 443 minecraft:light[level=14]
setblock 489 168 451 minecraft:light[level=14]
fill 489 168 457 491 168 457 minecraft:red_nether_bricks
fill 491 168 416 492 168 417 minecraft:red_nether_bricks
fill 492 168 458 493 168 458 minecraft:orange_concrete
fill 493 168 416 494 168 416 minecraft:orange_concrete
setblock 493 168 417 minecraft:red_nether_bricks
fill 493 168 457 495 168 457 minecraft:red_nether_bricks
fill 494 168 458 495 173 458 minecraft:red_nether_bricks
fill 495 168 417 497 168 417 minecraft:red_nether_bricks
setblock 497 168 419 minecraft:light[level=14]
setblock 497 168 427 minecraft:light[level=14]
setblock 497 168 435 minecraft:light[level=14]
setblock 497 168 443 minecraft:light[level=14]
setblock 497 168 451 minecraft:light[level=14]
fill 497 168 457 499 168 457 minecraft:red_nether_bricks
fill 499 168 417 501 168 417 minecraft:red_nether_bricks
fill 501 168 457 503 168 457 minecraft:red_nether_bricks
fill 501 168 458 501 169 458 minecraft:orange_concrete
fill 502 168 458 503 173 458 minecraft:red_nether_bricks
fill 503 168 416 504 168 417 minecraft:red_nether_bricks
fill 503 168 440 503 170 440 minecraft:red_nether_bricks
fill 504 168 439 504 173 439 minecraft:red_nether_bricks
fill 504 168 444 505 168 444 minecraft:red_nether_bricks
setblock 504 168 458 minecraft:orange_concrete
fill 505 168 416 506 169 416 minecraft:orange_concrete
setblock 505 168 417 minecraft:red_nether_bricks
setblock 505 168 419 minecraft:light[level=14]
setblock 505 168 435 minecraft:light[level=14]
fill 505 168 438 506 175 438 minecraft:red_nether_bricks
setblock 505 168 451 minecraft:light[level=14]
fill 505 168 457 507 168 457 minecraft:red_nether_bricks
fill 506 168 458 506 173 458 minecraft:red_nether_bricks
fill 507 168 417 509 168 417 minecraft:red_nether_bricks
fill 507 168 439 507 174 439 minecraft:red_nether_bricks
fill 509 168 457 511 168 457 minecraft:red_nether_bricks
fill 511 168 417 511 168 419 minecraft:red_nether_bricks
fill 511 168 421 511 168 423 minecraft:red_nether_bricks
fill 511 168 425 511 168 427 minecraft:red_nether_bricks
fill 511 168 429 511 168 431 minecraft:red_nether_bricks
fill 511 168 433 511 168 435 minecraft:red_nether_bricks
fill 511 168 437 511 168 439 minecraft:red_nether_bricks
fill 511 168 441 511 168 443 minecraft:red_nether_bricks
fill 511 168 445 511 168 447 minecraft:red_nether_bricks
fill 511 168 449 511 168 451 minecraft:red_nether_bricks
fill 511 168 453 511 168 455 minecraft:red_nether_bricks
fill 512 168 416 512 173 416 minecraft:red_nether_bricks
fill 512 168 417 512 168 418 minecraft:orange_concrete
fill 512 168 419 512 173 419 minecraft:red_nether_bricks
fill 512 168 421 512 169 421 minecraft:orange_concrete
fill 512 168 427 512 173 428 minecraft:red_nether_bricks
fill 512 168 429 512 169 430 minecraft:orange_concrete
setblock 512 168 438 minecraft:orange_concrete
fill 512 168 439 512 173 440 minecraft:red_nether_bricks
fill 512 168 441 512 169 442 minecraft:orange_concrete
fill 512 168 447 512 173 448 minecraft:red_nether_bricks
fill 512 168 449 512 168 450 minecraft:orange_concrete
fill 512 168 451 512 173 451 minecraft:red_nether_bricks
fill 512 168 458 512 169 458 minecraft:orange_concrete
fill 470 169 424 470 169 425 minecraft:orange_concrete
fill 470 169 427 470 173 427 minecraft:red_nether_bricks
setblock 470 169 428 minecraft:orange_concrete
fill 470 169 429 470 172 429 minecraft:red_nether_bricks
fill 470 169 440 470 172 440 minecraft:red_nether_bricks
setblock 470 169 445 minecraft:orange_concrete
setblock 470 169 456 minecraft:orange_concrete
fill 471 169 416 472 173 416 minecraft:red_nether_bricks
fill 471 169 458 473 172 458 minecraft:red_nether_bricks
setblock 477 169 416 minecraft:orange_concrete
fill 478 169 416 478 171 416 minecraft:red_nether_bricks
fill 482 169 416 484 172 416 minecraft:red_nether_bricks
setblock 489 169 458 minecraft:orange_concrete
fill 491 169 416 493 172 416 minecraft:red_nether_bricks
setblock 492 169 458 minecraft:orange_concrete
fill 493 169 458 493 172 458 minecraft:red_nether_bricks
setblock 494 169 416 minecraft:orange_concrete
setblock 497 169 416 minecraft:orange_concrete
setblock 500 169 458 minecraft:orange_concrete
fill 503 169 416 504 173 416 minecraft:red_nether_bricks
fill 504 169 438 504 174 438 minecraft:red_nether_bricks
setblock 504 169 443 minecraft:red_nether_bricks
fill 504 169 458 504 172 458 minecraft:red_nether_bricks
fill 506 169 437 506 176 437 minecraft:red_nether_bricks
fill 507 169 438 507 175 438 minecraft:red_nether_bricks
fill 508 169 440 508 171 440 minecraft:red_nether_bricks
fill 512 169 417 512 172 418 minecraft:red_nether_bricks
setblock 512 169 422 minecraft:orange_concrete
setblock 512 169 433 minecraft:orange_concrete
fill 512 169 438 512 172 438 minecraft:red_nether_bricks
fill 512 169 449 512 172 449 minecraft:red_nether_bricks
setblock 512 169 450 minecraft:orange_concrete
fill 512 169 453 512 169 454 minecraft:orange_concrete
fill 470 170 416 470 175 417 minecraft:red_nether_bricks
fill 470 170 423 470 171 423 minecraft:orange_concrete
fill 470 170 424 470 175 425 minecraft:red_nether_bricks
setblock 470 170 426 minecraft:orange_concrete
fill 470 170 428 470 175 428 minecraft:red_nether_bricks
fill 470 170 434 470 171 435 minecraft:orange_concrete
fill 470 170 436 470 175 437 minecraft:red_nether_bricks
fill 470 170 445 470 175 445 minecraft:red_nether_bricks
fill 470 170 446 470 170 447 minecraft:orange_concrete
fill 470 170 448 470 175 449 minecraft:red_nether_bricks
fill 470 170 454 470 171 455 minecraft:orange_concrete
fill 470 170 456 470 175 457 minecraft:red_nether_bricks
setblock 470 170 458 minecraft:orange_concrete
fill 473 170 416 474 175 416 minecraft:red_nether_bricks
fill 475 170 416 476 170 416 minecraft:orange_concrete
fill 477 170 416 477 171 416 minecraft:red_nether_bricks
fill 478 170 458 479 171 458 minecraft:orange_concrete
fill 480 170 458 481 175 458 minecraft:red_nether_bricks
fill 485 170 416 486 175 416 minecraft:red_nether_bricks
fill 487 170 416 488 171 416 minecraft:orange_concrete
fill 487 170 458 487 171 458 minecraft:orange_concrete
fill 489 170 458 489 175 458 minecraft:red_nether_bricks
fill 490 170 458 491 170 458 minecraft:orange_concrete
fill 492 170 458 492 175 458 minecraft:red_nether_bricks
fill 494 170 416 494 175 416 minecraft:red_nether_bricks
fill 495 170 416 496 170 416 minecraft:orange_concrete
fill 497 170 416 497 175 416 minecraft:red_nether_bricks
fill 498 170 458 499 171 458 minecraft:orange_concrete
fill 499 170 416 499 171 416 minecraft:orange_concrete
fill 500 170 458 501 175 458 minecraft:red_nether_bricks
fill 504 170 437 505 175 437 minecraft:red_nether_bricks
fill 504 170 442 505 170 442 minecraft:red_nether_bricks
fill 505 170 416 506 175 416 minecraft:red_nether_bricks
fill 507 170 416 508 171 416 minecraft:orange_concrete
fill 507 170 437 507 176 437 minecraft:red_nether_bricks
fill 508 170 438 508 172 439 minecraft:red_nether_bricks
fill 510 170 458 511 170 458 minecraft:orange_concrete
setblock 512 170 420 minecraft:orange_concrete
fill 512 170 421 512 175 422 minecraft:red_nether_bricks
fill 512 170 423 512 171 424 minecraft:orange_concrete
fill 512 170 429 512 175 430 minecraft:red_nether_bricks
fill 512 170 431 512 170 432 minecraft:orange_concrete
fill 512 170 433 512 175 433 minecraft:red_nether_bricks
fill 512 170 441 512 175 442 minecraft:red_nether_bricks
fill 512 170 443 512 171 444 minecraft:orange_concrete
fill 512 170 450 512 175 450 minecraft:red_nether_bricks
setblock 512 170 452 minecraft:orange_concrete
fill 512 170 453 512 175 454 minecraft:red_nether_bricks
fill 512 170 455 512 171 455 minecraft:orange_concrete
fill 512 170 458 512 175 458 minecraft:red_nether_bricks
setblock 470 171 422 minecraft:orange_concrete
fill 470 171 426 470 174 426 minecraft:red_nether_bricks
fill 470 171 442 470 171 443 minecraft:orange_concrete
setblock 470 171 446 minecraft:orange_concrete
fill 470 171 447 470 174 447 minecraft:red_nether_bricks
fill 470 171 458 470 174 458 minecraft:red_nether_bricks
fill 475 171 416 475 174 416 minecraft:red_nether_bricks
setblock 475 171 458 minecraft:orange_concrete
setblock 476 171 416 minecraft:orange_concrete
fill 479 171 416 480 171 416 minecraft:orange_concrete
setblock 486 171 458 minecraft:orange_concrete
fill 490 171 458 491 174 458 minecraft:red_nether_bricks
fill 495 171 416 496 173 416 minecraft:red_nether_bricks
setblock 500 171 416 minecraft:orange_concrete
fill 505 171 436 507 177 436 minecraft:red_nether_bricks
setblock 505 171 442 minecraft:red_nether_bricks
setblock 507 171 441 minecraft:red_nether_bricks
setblock 507 171 458 minecraft:orange_concrete
fill 508 171 437 508 174 437 minecraft:red_nether_bricks
setblock 510 171 458 minecraft:orange_concrete
setblock 511 171 416 minecraft:orange_concrete
fill 511 171 458 511 174 458 minecraft:red_nether_bricks
fill 512 171 420 512 174 420 minecraft:red_nether_bricks
fill 512 171 431 512 174 431 minecraft:red_nether_bricks
setblock 512 171 432 minecraft:orange_concrete
fill 512 171 435 512 171 436 minecraft:orange_concrete
fill 512 171 452 512 174 452 minecraft:red_nether_bricks
setblock 512 171 456 minecraft:orange_concrete
fill 470 172 420 470 173 421 minecraft:orange_concrete
fill 470 172 422 470 177 423 minecraft:red_nether_bricks
fill 470 172 432 470 172 433 minecraft:orange_concrete
fill 470 172 434 470 177 435 minecraft:red_nether_bricks
fill 470 172 441 470 173 441 minecraft:orange_concrete
fill 470 172 442 470 177 443 minecraft:red_nether_bricks
setblock 470 172 444 minecraft:orange_concrete
fill 470 172 446 470 177 446 minecraft:red_nether_bricks
fill 470 172 452 470 173 453 minecraft:orange_concrete
fill 470 172 454 470 177 455 minecraft:red_nether_bricks
fill 475 172 458 475 177 458 minecraft:red_nether_bricks
fill 476 172 416 476 177 416 minecraft:red_nether_bricks
fill 476 172 458 477 172 458 minecraft:orange_concrete
fill 477 172 416 478 172 416 minecraft:orange_concrete
fill 478 172 458 479 177 458 minecraft:red_nether_bricks
fill 479 172 416 480 173 416 minecraft:red_nether_bricks
fill 481 172 416 481 173 416 minecraft:orange_concrete
fill 484 172 458 485 173 458 minecraft:orange_concrete
fill 486 172 458 487 177 458 minecraft:red_nether_bricks
fill 487 172 416 488 177 416 minecraft:red_nether_bricks
setblock 488 172 458 minecraft:orange_concrete
fill 489 172 416 490 173 416 minecraft:orange_concrete
fill 496 172 458 497 173 458 minecraft:orange_concrete
setblock 498 172 416 minecraft:orange_concrete
fill 498 172 458 499 177 458 minecraft:red_nether_bricks
fill 499 172 416 500 177 416 minecraft:red_nether_bricks
fill 501 172 416 502 173 416 minecraft:orange_concrete
fill 504 172 436 504 176 436 minecraft:red_nether_bricks
fill 505 172 435 507 178 435 minecraft:red_nether_bricks
fill 505 172 441 506 172 441 minecraft:red_nether_bricks
fill 505 172 458 505 173 458 minecraft:orange_concrete
fill 507 172 416 508 177 416 minecraft:red_nether_bricks
fill 507 172 458 507 177 458 minecraft:red_nether_bricks
fill 508 172 436 508 175 436 minecraft:red_nether_bricks
fill 508 172 458 509 172 458 minecraft:orange_concrete
fill 509 172 416 510 172 416 minecraft:orange_concrete
fill 510 172 458 510 177 458 minecraft:red_nether_bricks
fill 511 172 416 511 177 416 minecraft:red_nether_bricks
fill 512 172 423 512 177 424 minecraft:red_nether_bricks
fill 512 172 425 512 173 426 minecraft:orange_concrete
fill 512 172 432 512 177 432 minecraft:red_nether_bricks
setblock 512 172 434 minecraft:orange_concrete
fill 512 172 435 512 177 436 minecraft:red_nether_bricks
fill 512 172 437 512 173 437 minecraft:orange_concrete
fill 512 172 443 512 177 444 minecraft:red_nether_bricks
fill 512 172 445 512 172 446 minecraft:orange_concrete
fill 512 172 455 512 177 456 minecraft:red_nether_bricks
fill 512 172 457 512 173 457 minecraft:orange_concrete
setblock 470 173 429 minecraft:orange_concrete
setblock 470 173 432 minecraft:orange_concrete
fill 470 173 433 470 176 433 minecraft:red_nether_bricks
setblock 470 173 440 minecraft:orange_concrete
fill 470 173 444 470 176 444 minecraft:red_nether_bricks
setblock 471 173 458 minecraft:red_nether_bricks
fill 472 173 458 473 173 458 minecraft:orange_concrete
setblock 476 173 458 minecraft:orange_concrete
fill 477 173 416 478 175 416 minecraft:red_nether_bricks
fill 477 173 458 477 176 458 minecraft:red_nether_bricks
setblock 482 173 416 minecraft:orange_concrete
fill 483 173 416 484 173 416 minecraft:red_nether_bricks
fill 488 173 458 488 176 458 minecraft:red_nether_bricks
fill 491 173 416 492 173 416 minecraft:red_nether_bricks
setblock 493 173 416 minecraft:orange_concrete
setblock 493 173 458 minecraft:orange_concrete
fill 498 173 416 498 175 416 minecraft:red_nether_bricks
fill 504 173 435 504 178 435 minecraft:red_nether_bricks
setblock 504 173 458 minecraft:orange_concrete
fill 505 173 434 507 178 434 minecraft:red_nether_bricks
fill 505 173 440 506 173 440 minecraft:red_nether_bricks
fill 508 173 435 508 176 435 minecraft:red_nether_bricks
fill 508 173 438 508 174 438 minecraft:red_nether_bricks
fill 508 173 458 509 176 458 minecraft:red_nether_bricks
fill 509 173 416 509 176 416 minecraft:red_nether_bricks
setblock 510 173 416 minecraft:orange_concrete
fill 512 173 417 512 173 418 minecraft:orange_concrete
fill 512 173 434 512 176 434 minecraft:red_nether_bricks
setblock 512 173 438 minecraft:orange_concrete
fill 512 173 445 512 176 445 minecraft:red_nether_bricks
setblock 512 173 446 minecraft:orange_concrete
setblock 512 173 449 minecraft:orange_concrete
fill 470 174 418 470 175 419 minecraft:orange_concrete
fill 470 174 420 471 174 421 minecraft:red_nether_bricks
fill 470 174 427 470 175 427 minecraft:orange_concrete
fill 470 174 429 471 174 429 minecraft:red_nether_bricks
fill 470 174 430 470 174 431 minecraft:orange_concrete
fill 470 174 432 471 174 432 minecraft:red_nether_bricks
fill 470 174 438 470 175 439 minecraft:orange_concrete
fill 470 174 440 471 174 441 minecraft:red_nether_bricks
fill 470 174 450 470 174 451 minecraft:orange_concrete
fill 470 174 452 471 174 453 minecraft:red_nether_bricks
fill 471 174 416 472 175 416 minecraft:orange_concrete
fill 471 174 417 473 174 417 minecraft:red_nether_bricks
setblock 471 174 419 minecraft:red_nether_bricks
fill 471 174 423 471 174 425 minecraft:red_nether_bricks
fill 471 174 427 471 174 428 minecraft:red_nether_bricks
setblock 471 174 431 minecraft:red_nether_bricks
setblock 471 174 433 minecraft:red_nether_bricks
fill 471 174 435 471 174 437 minecraft:red_nether_bricks
setblock 471 174 439 minecraft:red_nether_bricks
fill 471 174 443 471 174 445 minecraft:red_nether_bricks
fill 471 174 447 471 174 449 minecraft:red_nether_bricks
setblock 471 174 451 minecraft:red_nether_bricks
fill 471 174 455 471 174 457 minecraft:red_nether_bricks
fill 471 174 458 471 175 458 minecraft:orange_concrete
fill 472 174 458 473 179 458 minecraft:red_nether_bricks
fill 473 174 457 475 174 457 minecraft:red_nether_bricks
setblock 474 174 458 minecraft:orange_concrete
fill 475 174 417 477 174 417 minecraft:red_nether_bricks
fill 476 174 458 476 179 458 minecraft:red_nether_bricks
fill 477 174 457 479 174 457 minecraft:red_nether_bricks
fill 479 174 416 479 174 417 minecraft:red_nether_bricks
setblock 480 174 416 minecraft:orange_concrete
fill 480 174 417 481 174 417 minecraft:red_nether_bricks
fill 481 174 416 482 179 416 minecraft:red_nether_bricks
fill 481 174 457 483 174 457 minecraft:red_nether_bricks
fill 482 174 458 483 175 458 minecraft:orange_concrete
fill 483 174 416 484 175 416 minecraft:orange_concrete
fill 483 174 417 485 174 417 minecraft:red_nether_bricks
fill 484 174 458 485 179 458 minecraft:red_nether_bricks
fill 485 174 457 487 174 457 minecraft:red_nether_bricks
fill 487 174 417 489 174 417 minecraft:red_nether_bricks
fill 489 174 416 490 176 416 minecraft:red_nether_bricks
fill 489 174 457 491 174 457 minecraft:red_nether_bricks
fill 491 174 416 492 174 416 minecraft:orange_concrete
fill 491 174 417 493 174 417 minecraft:red_nether_bricks
fill 493 174 416 493 179 416 minecraft:red_nether_bricks
fill 493 174 457 493 174 458 minecraft:red_nether_bricks
fill 494 174 457 495 174 457 minecraft:red_nether_bricks
fill 494 174 458 495 174 458 minecraft:orange_concrete
fill 495 174 416 495 175 416 minecraft:orange_concrete
fill 495 174 417 497 174 417 minecraft:red_nether_bricks
setblock 496 174 416 minecraft:red_nether_bricks
fill 496 174 458 497 179 458 minecraft:red_nether_bricks
fill 497 174 457 499 174 457 minecraft:red_nether_bricks
fill 499 174 417 501 174 417 minecraft:red_nether_bricks
fill 501 174 416 502 179 416 minecraft:red_nether_bricks
fill 501 174 457 503 174 457 minecraft:red_nether_bricks
fill 502 174 458 503 175 458 minecraft:orange_concrete
fill 503 174 416 504 175 416 minecraft:orange_concrete
fill 503 174 417 505 174 417 minecraft:red_nether_bricks
fill 504 174 434 504 179 434 minecraft:red_nether_bricks
fill 504 174 458 505 179 458 minecraft:red_nether_bricks
fill 505 174 433 507 179 433 minecraft:red_nether_bricks
fill 505 174 457 507 174 457 minecraft:red_nether_bricks
setblock 506 174 458 minecraft:orange_concrete
fill 507 174 417 509 174 417 minecraft:red_nether_bricks
fill 509 174 457 512 174 457 minecraft:red_nether_bricks
fill 510 174 416 510 179 416 minecraft:red_nether_bricks
fill 511 174 417 511 174 419 minecraft:red_nether_bricks
fill 511 174 421 511 174 423 minecraft:red_nether_bricks
fill 511 174 425 511 174 427 minecraft:red_nether_bricks
fill 511 174 429 511 174 431 minecraft:red_nether_bricks
fill 511 174 433 511 174 435 minecraft:red_nether_bricks
fill 511 174 437 511 174 439 minecraft:red_nether_bricks
fill 511 174 441 511 174 443 minecraft:red_nether_bricks
fill 511 174 445 511 174 447 minecraft:red_nether_bricks
fill 511 174 449 511 174 451 minecraft:red_nether_bricks
fill 511 174 453 511 174 455 minecraft:red_nether_bricks
setblock 512 174 416 minecraft:orange_concrete
fill 512 174 417 512 179 418 minecraft:red_nether_bricks
fill 512 174 419 512 175 419 minecraft:orange_concrete
fill 512 174 425 512 179 426 minecraft:red_nether_bricks
fill 512 174 427 512 174 428 minecraft:orange_concrete
fill 512 174 437 512 179 438 minecraft:red_nether_bricks
fill 512 174 439 512 175 440 minecraft:orange_concrete
fill 512 174 446 512 179 446 minecraft:red_nether_bricks
fill 512 174 447 512 174 448 minecraft:orange_concrete
fill 512 174 449 512 179 449 minecraft:red_nether_bricks
fill 512 174 451 512 175 451 minecraft:orange_concrete
fill 470 175 420 470 179 421 minecraft:red_nether_bricks
setblock 470 175 426 minecraft:orange_concrete
fill 470 175 429 470 178 432 minecraft:red_nether_bricks
fill 470 175 440 470 179 441 minecraft:red_nether_bricks
setblock 470 175 447 minecraft:orange_concrete
setblock 470 175 450 minecraft:orange_concrete
fill 470 175 451 470 178 453 minecraft:red_nether_bricks
setblock 470 175 458 minecraft:orange_concrete
fill 474 175 458 474 178 458 minecraft:red_nether_bricks
setblock 475 175 416 minecraft:orange_concrete
fill 479 175 416 480 177 416 minecraft:red_nether_bricks
fill 490 175 458 491 175 458 minecraft:orange_concrete
fill 491 175 416 491 178 416 minecraft:red_nether_bricks
setblock 492 175 416 minecraft:orange_concrete
fill 493 175 458 493 179 458 minecraft:red_nether_bricks
setblock 494 175 458 minecraft:orange_concrete
fill 495 175 458 495 178 458 minecraft:red_nether_bricks
setblock 496 175 416 minecraft:orange_concrete
fill 504 175 433 504 181 433 minecraft:red_nether_bricks
fill 505 175 432 506 181 432 minecraft:red_nether_bricks
fill 506 175 458 506 178 458 minecraft:red_nether_bricks
fill 508 175 434 508 176 434 minecraft:red_nether_bricks
setblock 511 175 458 minecraft:orange_concrete
fill 512 175 416 512 178 416 minecraft:red_nether_bricks
setblock 512 175 420 minecraft:orange_concrete
fill 512 175 427 512 178 427 minecraft:red_nether_bricks
setblock 512 175 428 minecraft:orange_concrete
setblock 512 175 431 minecraft:orange_concrete
fill 512 175 447 512 178 448 minecraft:red_nether_bricks
setblock 512 175 452 minecraft:orange_concrete
fill 512 175 457 512 179 457 minecraft:red_nether_bricks
fill 470 176 416 470 176 417 minecraft:orange_concrete
fill 470 176 418 470 181 419 minecraft:red_nether_bricks
fill 470 176 424 470 177 425 minecraft:orange_concrete
fill 470 176 426 470 181 427 minecraft:red_nether_bricks
setblock 470 176 428 minecraft:orange_concrete
fill 470 176 436 470 177 437 minecraft:orange_concrete
fill 470 176 438 470 181 439 minecraft:red_nether_bricks
fill 470 176 445 470 177 445 minecraft:orange_concrete
fill 470 176 447 470 181 447 minecraft:red_nether_bricks
fill 470 176 448 470 176 449 minecraft:orange_concrete
fill 470 176 450 470 181 450 minecraft:red_nether_bricks
fill 470 176 456 470 177 457 minecraft:orange_concrete
fill 470 176 458 471 181 458 minecraft:red_nether_bricks
fill 471 176 416 472 178 416 minecraft:red_nether_bricks
fill 473 176 416 474 176 416 minecraft:orange_concrete
setblock 473 176 419 minecraft:light[level=14]
setblock 473 176 427 minecraft:light[level=14]
setblock 473 176 435 minecraft:light[level=14]
setblock 473 176 443 minecraft:light[level=14]
setblock 473 176 451 minecraft:light[level=14]
fill 475 176 416 475 181 416 minecraft:red_nether_bricks
fill 477 176 416 477 177 416 minecraft:orange_concrete
setblock 478 176 416 minecraft:red_nether_bricks
fill 480 176 458 481 176 458 minecraft:orange_concrete
setblock 481 176 419 minecraft:light[level=14]
setblock 481 176 427 minecraft:light[level=14]
setblock 481 176 435 minecraft:light[level=14]
setblock 481 176 443 minecraft:light[level=14]
setblock 481 176 451 minecraft:light[level=14]
fill 482 176 458 483 181 458 minecraft:red_nether_bricks
fill 483 176 416 484 181 416 minecraft:red_nether_bricks
fill 485 176 416 486 177 416 minecraft:orange_concrete
setblock 489 176 419 minecraft:light[level=14]
setblock 489 176 427 minecraft:light[level=14]
setblock 489 176 435 minecraft:light[level=14]
setblock 489 176 443 minecraft:light[level=14]
setblock 489 176 451 minecraft:light[level=14]
fill 489 176 458 489 177 458 minecraft:orange_concrete
fill 490 176 458 491 181 458 minecraft:red_nether_bricks
fill 492 176 416 492 178 416 minecraft:red_nether_bricks
setblock 492 176 458 minecraft:orange_concrete
setblock 494 176 416 minecraft:orange_concrete
fill 494 176 458 494 181 458 minecraft:red_nether_bricks
fill 495 176 416 496 181 416 minecraft:red_nether_bricks
fill 497 176 416 498 177 416 minecraft:orange_concrete
setblock 497 176 419 minecraft:light[level=14]
setblock 497 176 427 minecraft:light[level=14]
setblock 497 176 435 minecraft:light[level=14]
setblock 497 176 443 minecraft:light[level=14]
setblock 497 176 451 minecraft:light[level=14]
fill 500 176 458 501 177 458 minecraft:orange_concrete
fill 502 176 458 503 181 458 minecraft:red_nether_bricks
fill 503 176 416 504 181 416 minecraft:red_nether_bricks
fill 503 176 433 503 177 434 minecraft:red_nether_bricks
fill 504 176 431 504 182 432 minecraft:red_nether_bricks
fill 505 176 416 506 176 416 minecraft:orange_concrete
setblock 505 176 419 minecraft:light[level=14]
fill 505 176 431 506 182 431 minecraft:red_nether_bricks
setblock 505 176 437 minecraft:red_nether_bricks
setblock 505 176 443 minecraft:light[level=14]
setblock 505 176 451 minecraft:light[level=14]
fill 506 176 438 506 178 438 minecraft:magma_block
fill 507 176 432 507 180 432 minecraft:red_nether_bricks
fill 511 176 458 511 181 458 minecraft:red_nether_bricks
fill 512 176 419 512 181 420 minecraft:red_nether_bricks
fill 512 176 421 512 177 422 minecraft:orange_concrete
fill 512 176 428 512 181 428 minecraft:red_nether_bricks
fill 512 176 429 512 176 430 minecraft:orange_concrete
fill 512 176 431 512 181 431 minecraft:red_nether_bricks
fill 512 176 433 512 177 433 minecraft:orange_concrete
fill 512 176 439 512 181 440 minecraft:red_nether_bricks
fill 512 176 441 512 177 442 minecraft:orange_concrete
setblock 512 176 450 minecraft:orange_concrete
fill 512 176 451 512 181 452 minecraft:red_nether_bricks
fill 512 176 453 512 177 454 minecraft:orange_concrete
fill 512 176 458 512 177 458 minecraft:orange_concrete
setblock 470 177 416 minecraft:orange_concrete
fill 470 177 417 470 180 417 minecraft:red_nether_bricks
fill 470 177 428 470 180 428 minecraft:red_nether_bricks
setblock 470 177 433 minecraft:orange_concrete
setblock 470 177 444 minecraft:orange_concrete
fill 470 177 448 470 180 449 minecraft:red_nether_bricks
fill 473 177 416 473 180 416 minecraft:red_nether_bricks
setblock 474 177 416 minecraft:orange_concrete
setblock 477 177 458 minecraft:orange_concrete
setblock 478 177 416 minecraft:orange_concrete
setblock 480 177 458 minecraft:orange_concrete
fill 481 177 458 481 180 458 minecraft:red_nether_bricks
setblock 488 177 458 minecraft:orange_concrete
setblock 489 177 416 minecraft:orange_concrete
fill 490 177 416 490 179 416 minecraft:red_nether_bricks
fill 492 177 458 492 180 458 minecraft:red_nether_bricks
fill 494 177 416 494 180 416 minecraft:red_nether_bricks
fill 503 177 432 503 182 432 minecraft:red_nether_bricks
fill 504 177 430 506 182 430 minecraft:red_nether_bricks
fill 505 177 416 505 180 416 minecraft:red_nether_bricks
setblock 506 177 416 minecraft:orange_concrete
fill 506 177 437 506 178 437 minecraft:magma_block
fill 507 177 431 507 180 431 minecraft:red_nether_bricks
fill 508 177 458 509 177 458 minecraft:orange_concrete
setblock 509 177 416 minecraft:orange_concrete
fill 512 177 429 512 180 430 minecraft:red_nether_bricks
setblock 512 177 434 minecraft:orange_concrete
setblock 512 177 445 minecraft:orange_concrete
fill 512 177 450 512 180 450 minecraft:red_nether_bricks
fill 470 178 416 470 183 416 minecraft:red_nether_bricks
fill 470 178 422 470 179 423 minecraft:orange_concrete
fill 470 178 424 470 183 425 minecraft:red_nether_bricks
fill 470 178 433 470 183 433 minecraft:red_nether_bricks
fill 470 178 434 470 178 435 minecraft:orange_concrete
fill 470 178 436 470 183 437 minecraft:red_nether_bricks
fill 470 178 442 470 179 443 minecraft:orange_concrete
fill 470 178 444 470 183 445 minecraft:red_nether_bricks
setblock 470 178 446 minecraft:orange_concrete
fill 470 178 454 470 179 455 minecraft:orange_concrete
fill 470 178 456 470 183 457 minecraft:red_nether_bricks
fill 474 178 416 474 180 416 minecraft:red_nether_bricks
fill 475 178 458 475 179 458 minecraft:orange_concrete
setblock 476 178 416 minecraft:orange_concrete
fill 477 178 416 478 183 416 minecraft:red_nether_bricks
fill 477 178 458 477 183 458 minecraft:red_nether_bricks
fill 478 178 458 479 178 458 minecraft:orange_concrete
fill 479 178 416 480 179 416 minecraft:orange_concrete
fill 480 178 458 480 183 458 minecraft:red_nether_bricks
fill 485 178 416 486 183 416 minecraft:red_nether_bricks
fill 486 178 458 487 179 458 minecraft:orange_concrete
fill 487 178 416 488 178 416 minecraft:orange_concrete
fill 488 178 458 489 183 458 minecraft:red_nether_bricks
fill 489 178 416 489 179 416 minecraft:red_nether_bricks
fill 497 178 416 498 183 416 minecraft:red_nether_bricks
fill 498 178 458 499 178 458 minecraft:orange_concrete
fill 499 178 416 500 179 416 minecraft:orange_concrete
fill 500 178 458 501 183 458 minecraft:red_nether_bricks
fill 503 178 430 503 183 431 minecraft:red_nether_bricks
fill 503 178 433 503 180 433 minecraft:red_nether_bricks
fill 504 178 429 505 184 429 minecraft:red_nether_bricks
fill 506 178 416 506 183 416 minecraft:red_nether_bricks
fill 507 178 416 508 178 416 minecraft:orange_concrete
fill 507 178 458 507 179 458 minecraft:orange_concrete
fill 508 178 458 509 183 458 minecraft:red_nether_bricks
fill 509 178 416 509 183 416 minecraft:red_nether_bricks
setblock 510 178 458 minecraft:orange_concrete
fill 511 178 416 511 179 416 minecraft:orange_concrete
fill 512 178 421 512 183 422 minecraft:red_nether_bricks
fill 512 178 423 512 179 424 minecraft:orange_concrete
setblock 512 178 432 minecraft:orange_concrete
fill 512 178 433 512 183 434 minecraft:red_nether_bricks
fill 512 178 435 512 179 436 minecraft:orange_concrete
fill 512 178 441 512 183 442 minecraft:red_nether_bricks
fill 512 178 443 512 178 444 minecraft:orange_concrete
fill 512 178 445 512 183 445 minecraft:red_nether_bricks
fill 512 178 453 512 183 454 minecraft:red_nether_bricks
fill 512 178 455 512 179 456 minecraft:orange_concrete
fill 512 178 458 512 183 458 minecraft:red_nether_bricks
setblock 470 179 429 minecraft:red_nether_bricks
fill 470 179 430 470 179 431 minecraft:orange_concrete
setblock 470 179 432 minecraft:red_nether_bricks
setblock 470 179 434 minecraft:orange_concrete
fill 470 179 435 470 182 435 minecraft:red_nether_bricks
fill 470 179 446 470 182 446 minecraft:red_nether_bricks
setblock 470 179 451 minecraft:orange_concrete
fill 470 179 452 470 179 453 minecraft:red_nether_bricks
setblock 471 179 416 minecraft:orange_concrete
fill 472 179 416 472 181 416 minecraft:red_nether_bricks
setblock 474 179 458 minecraft:orange_concrete
fill 476 179 416 476 182 416 minecraft:red_nether_bricks
fill 478 179 458 479 182 458 minecraft:red_nether_bricks
fill 487 179 416 487 182 416 minecraft:red_nether_bricks
setblock 488 179 416 minecraft:orange_concrete
fill 491 179 416 492 179 416 minecraft:orange_concrete
setblock 495 179 458 minecraft:orange_concrete
setblock 498 179 458 minecraft:orange_concrete
fill 499 179 458 499 182 458 minecraft:red_nether_bricks
fill 502 179 430 502 182 431 minecraft:red_nether_bricks
fill 503 179 429 503 186 429 minecraft:red_nether_bricks
fill 505 179 434 506 179 434 minecraft:red_nether_bricks
fill 506 179 429 506 182 429 minecraft:red_nether_bricks
setblock 506 179 458 minecraft:orange_concrete
fill 507 179 416 508 181 416 minecraft:red_nether_bricks
fill 510 179 458 510 182 458 minecraft:red_nether_bricks
setblock 512 179 416 minecraft:orange_concrete
setblock 512 179 427 minecraft:orange_concrete
fill 512 179 432 512 182 432 minecraft:red_nether_bricks
fill 512 179 443 512 182 443 minecraft:red_nether_bricks
setblock 512 179 444 minecraft:orange_concrete
fill 512 179 447 512 179 448 minecraft:orange_concrete
fill 470 180 420 470 180 421 minecraft:orange_concrete
fill 470 180 422 470 185 423 minecraft:red_nether_bricks
fill 470 180 429 470 181 429 minecraft:orange_concrete
fill 470 180 430 470 184 431 minecraft:red_nether_bricks
setblock 470 180 432 minecraft:orange_concrete
fill 470 180 434 470 185 434 minecraft:red_nether_bricks
fill 470 180 440 470 181 441 minecraft:orange_concrete
fill 470 180 442 470 185 443 minecraft:red_nether_bricks
fill 470 180 451 471 180 451 minecraft:red_nether_bricks
fill 470 180 452 470 180 453 minecraft:orange_concrete
fill 470 180 454 470 185 455 minecraft:red_nether_bricks
fill 471 180 416 471 180 417 minecraft:red_nether_bricks
fill 471 180 419 471 180 421 minecraft:red_nether_bricks
fill 471 180 423 471 180 425 minecraft:red_nether_bricks
fill 471 180 427 471 180 429 minecraft:red_nether_bricks
fill 471 180 431 471 180 433 minecraft:red_nether_bricks
fill 471 180 435 471 180 437 minecraft:red_nether_bricks
fill 471 180 439 471 180 441 minecraft:red_nether_bricks
fill 471 180 443 471 180 445 minecraft:red_nether_bricks
fill 471 180 447 471 180 449 minecraft:red_nether_bricks
fill 471 180 452 471 180 453 minecraft:red_nether_bricks
fill 471 180 455 471 180 457 minecraft:red_nether_bricks
fill 472 180 417 473 180 417 minecraft:red_nether_bricks
fill 472 180 458 473 181 458 minecraft:orange_concrete
fill 473 180 457 475 180 457 minecraft:red_nether_bricks
fill 474 180 458 475 185 458 minecraft:red_nether_bricks
fill 475 180 417 477 180 417 minecraft:red_nether_bricks
setblock 476 180 458 minecraft:orange_concrete
fill 477 180 457 479 180 457 minecraft:red_nether_bricks
fill 479 180 416 480 180 417 minecraft:red_nether_bricks
fill 481 180 416 482 181 416 minecraft:orange_concrete
setblock 481 180 417 minecraft:red_nether_bricks
fill 481 180 457 483 180 457 minecraft:red_nether_bricks
fill 483 180 417 485 180 417 minecraft:red_nether_bricks
fill 484 180 458 485 181 458 minecraft:orange_concrete
fill 485 180 457 487 180 457 minecraft:red_nether_bricks
fill 486 180 458 487 184 458 minecraft:red_nether_bricks
fill 487 180 417 489 180 417 minecraft:red_nether_bricks
fill 488 180 416 488 185 416 minecraft:red_nether_bricks
fill 489 180 416 490 180 416 minecraft:orange_concrete
fill 489 180 457 491 180 457 minecraft:red_nether_bricks
fill 491 180 416 492 180 417 minecraft:red_nether_bricks
fill 493 180 416 493 181 416 minecraft:orange_concrete
setblock 493 180 417 minecraft:red_nether_bricks
fill 493 180 457 495 180 457 minecraft:red_nether_bricks
fill 493 180 458 493 181 458 minecraft:orange_concrete
fill 495 180 417 497 180 417 minecraft:red_nether_bricks
fill 495 180 458 495 185 458 minecraft:red_nether_bricks
fill 496 180 458 497 180 458 minecraft:orange_concrete
fill 497 180 457 499 180 457 minecraft:red_nether_bricks
fill 498 180 458 498 184 458 minecraft:red_nether_bricks
fill 499 180 416 500 180 417 minecraft:red_nether_bricks
fill 501 180 416 502 181 416 minecraft:orange_concrete
setblock 501 180 417 minecraft:red_nether_bricks
fill 501 180 457 503 180 457 minecraft:red_nether_bricks
fill 502 180 429 502 186 429 minecraft:red_nether_bricks
fill 503 180 417 505 180 417 minecraft:red_nether_bricks
fill 503 180 428 505 184 428 minecraft:red_nether_bricks
fill 504 180 458 505 181 458 minecraft:orange_concrete
fill 505 180 433 506 180 433 minecraft:red_nether_bricks
fill 505 180 457 507 180 457 minecraft:red_nether_bricks
fill 506 180 458 507 185 458 minecraft:red_nether_bricks
fill 507 180 417 509 180 417 minecraft:red_nether_bricks
fill 509 180 457 511 180 457 minecraft:red_nether_bricks
setblock 510 180 416 minecraft:orange_concrete
fill 511 180 416 511 180 419 minecraft:red_nether_bricks
fill 511 180 421 511 180 423 minecraft:red_nether_bricks
fill 511 180 425 511 180 427 minecraft:red_nether_bricks
fill 511 180 429 511 180 431 minecraft:red_nether_bricks
fill 511 180 433 511 180 435 minecraft:red_nether_bricks
fill 511 180 437 511 180 439 minecraft:red_nether_bricks
fill 511 180 441 511 180 443 minecraft:red_nether_bricks
fill 511 180 445 511 180 447 minecraft:red_nether_bricks
fill 511 180 449 511 180 451 minecraft:red_nether_bricks
fill 511 180 453 511 180 455 minecraft:red_nether_bricks
fill 512 180 416 512 185 416 minecraft:red_nether_bricks
fill 512 180 417 512 181 418 minecraft:orange_concrete
fill 512 180 423 512 185 424 minecraft:red_nether_bricks
fill 512 180 425 512 180 426 minecraft:orange_concrete
fill 512 180 427 512 185 427 minecraft:red_nether_bricks
fill 512 180 435 512 185 436 minecraft:red_nether_bricks
fill 512 180 437 512 181 438 minecraft:orange_concrete
fill 512 180 444 512 185 444 minecraft:red_nether_bricks
setblock 512 180 446 minecraft:orange_concrete
fill 512 180 447 512 185 448 minecraft:red_nether_bricks
fill 512 180 449 512 181 449 minecraft:orange_concrete
fill 512 180 455 512 185 456 minecraft:red_nether_bricks
setblock 512 180 457 minecraft:orange_concrete
setblock 470 181 417 minecraft:orange_concrete
setblock 470 181 420 minecraft:orange_concrete
fill 470 181 421 470 184 421 minecraft:red_nether_bricks
setblock 470 181 428 minecraft:orange_concrete
fill 470 181 432 470 184 432 minecraft:red_nether_bricks
fill 470 181 448 470 181 449 minecraft:orange_concrete
fill 470 181 451 470 185 451 minecraft:red_nether_bricks
setblock 470 181 452 minecraft:orange_concrete
fill 470 181 453 470 184 453 minecraft:red_nether_bricks
fill 471 181 416 471 185 416 minecraft:red_nether_bricks
fill 473 181 416 474 181 416 minecraft:orange_concrete
fill 476 181 458 476 184 458 minecraft:red_nether_bricks
fill 479 181 416 480 185 416 minecraft:red_nether_bricks
setblock 481 181 458 minecraft:orange_concrete
fill 489 181 416 492 181 416 minecraft:red_nether_bricks
setblock 492 181 458 minecraft:orange_concrete
setblock 494 181 416 minecraft:orange_concrete
fill 496 181 458 497 184 458 minecraft:red_nether_bricks
fill 499 181 416 500 184 416 minecraft:red_nether_bricks
fill 502 181 427 502 187 428 minecraft:red_nether_bricks
fill 503 181 427 503 187 427 minecraft:red_nether_bricks
setblock 505 181 416 minecraft:orange_concrete
setblock 505 181 433 minecraft:red_nether_bricks
fill 510 181 416 511 183 416 minecraft:red_nether_bricks
fill 512 181 425 512 184 425 minecraft:red_nether_bricks
setblock 512 181 426 minecraft:orange_concrete
fill 512 181 429 512 181 430 minecraft:orange_concrete
fill 512 181 446 512 184 446 minecraft:red_nether_bricks
setblock 512 181 450 minecraft:orange_concrete
fill 512 181 457 512 184 457 minecraft:red_nether_bricks
fill 470 182 417 470 187 417 minecraft:red_nether_bricks
fill 470 182 418 470 182 419 minecraft:orange_concrete
fill 470 182 420 470 186 420 minecraft:red_nether_bricks
fill 470 182 426 470 183 427 minecraft:orange_concrete
fill 470 182 428 470 185 429 minecraft:red_nether_bricks
fill 470 182 438 470 182 439 minecraft:orange_concrete
fill 470 182 440 470 185 441 minecraft:red_nether_bricks
fill 470 182 447 470 183 447 minecraft:orange_concrete
fill 470 182 448 470 185 449 minecraft:red_nether_bricks
setblock 470 182 450 minecraft:orange_concrete
fill 470 182 452 470 184 452 minecraft:red_nether_bricks
fill 470 182 458 471 183 458 minecraft:orange_concrete
setblock 472 182 416 minecraft:orange_concrete
fill 472 182 458 473 184 458 minecraft:red_nether_bricks
fill 473 182 416 474 184 416 minecraft:red_nether_bricks
fill 475 182 416 475 183 416 minecraft:orange_concrete
fill 481 182 416 482 184 416 minecraft:red_nether_bricks
fill 481 182 458 481 187 458 minecraft:red_nether_bricks
fill 482 182 458 483 182 458 minecraft:orange_concrete
fill 483 182 416 484 183 416 minecraft:orange_concrete
fill 484 182 458 485 187 458 minecraft:red_nether_bricks
fill 489 182 416 491 183 416 minecraft:red_nether_bricks
fill 490 182 458 491 183 458 minecraft:orange_concrete
setblock 492 182 416 minecraft:orange_concrete
fill 492 182 458 493 184 458 minecraft:red_nether_bricks
fill 493 182 416 494 184 416 minecraft:red_nether_bricks
setblock 494 182 458 minecraft:orange_concrete
fill 495 182 416 496 183 416 minecraft:orange_concrete
fill 501 182 416 502 184 416 minecraft:red_nether_bricks
fill 501 182 427 501 186 429 minecraft:red_nether_bricks
fill 502 182 426 502 189 426 minecraft:red_nether_bricks
fill 502 182 458 503 183 458 minecraft:orange_concrete
fill 503 182 416 504 182 416 minecraft:orange_concrete
fill 504 182 458 505 184 458 minecraft:red_nether_bricks
fill 505 182 416 505 187 416 minecraft:red_nether_bricks
setblock 505 182 432 minecraft:red_nether_bricks
fill 507 182 416 507 183 416 minecraft:orange_concrete
setblock 508 182 416 minecraft:red_nether_bricks
fill 511 182 458 511 183 458 minecraft:orange_concrete
fill 512 182 417 512 185 418 minecraft:red_nether_bricks
fill 512 182 419 512 183 420 minecraft:orange_concrete
fill 512 182 426 512 187 426 minecraft:red_nether_bricks
setblock 512 182 428 minecraft:orange_concrete
fill 512 182 429 512 184 430 minecraft:red_nether_bricks
fill 512 182 431 512 183 431 minecraft:orange_concrete
fill 512 182 437 512 187 438 minecraft:red_nether_bricks
fill 512 182 439 512 182 440 minecraft:orange_concrete
fill 512 182 449 512 187 450 minecraft:red_nether_bricks
fill 512 182 451 512 183 452 minecraft:orange_concrete
fill 470 183 418 470 186 419 minecraft:red_nether_bricks
setblock 470 183 435 minecraft:orange_concrete
setblock 470 183 438 minecraft:orange_concrete
fill 470 183 439 470 186 439 minecraft:red_nether_bricks
setblock 470 183 446 minecraft:orange_concrete
fill 470 183 450 470 186 450 minecraft:red_nether_bricks
fill 472 183 416 472 186 416 minecraft:red_nether_bricks
setblock 476 183 416 minecraft:orange_concrete
fill 478 183 458 479 183 458 minecraft:orange_concrete
setblock 482 183 458 minecraft:orange_concrete
fill 483 183 458 483 186 458 minecraft:red_nether_bricks
setblock 487 183 416 minecraft:orange_concrete
fill 492 183 416 492 185 416 minecraft:red_nether_bricks
fill 494 183 458 494 186 458 minecraft:red_nether_bricks
setblock 499 183 458 minecraft:orange_concrete
fill 501 183 426 501 190 426 minecraft:red_nether_bricks
fill 502 183 430 502 184 430 minecraft:red_nether_bricks
fill 503 183 416 503 185 416 minecraft:red_nether_bricks
setblock 504 183 416 minecraft:orange_concrete
fill 504 183 430 505 183 431 minecraft:red_nether_bricks
setblock 508 183 416 minecraft:orange_concrete
setblock 510 183 458 minecraft:orange_concrete
fill 512 183 428 512 186 428 minecraft:red_nether_bricks
setblock 512 183 432 minecraft:orange_concrete
fill 512 183 439 512 185 439 minecraft:red_nether_bricks
setblock 512 183 440 minecraft:orange_concrete
setblock 512 183 443 minecraft:orange_concrete
setblock 470 184 416 minecraft:orange_concrete
fill 470 184 424 470 185 425 minecraft:orange_concrete
fill 470 184 426 470 188 427 minecraft:red_nether_bricks
fill 470 184 433 470 185 433 minecraft:orange_concrete
fill 470 184 435 470 188 435 minecraft:red_nether_bricks
fill 470 184 436 470 184 437 minecraft:orange_concrete
fill 470 184 438 470 188 438 minecraft:red_nether_bricks
fill 470 184 444 470 185 445 minecraft:orange_concrete
fill 470 184 446 470 184 447 minecraft:red_nether_bricks
fill 470 184 456 470 184 457 minecraft:orange_concrete
fill 470 184 458 471 188 458 minecraft:red_nether_bricks
setblock 473 184 419 minecraft:light[level=14]
setblock 473 184 427 minecraft:light[level=14]
setblock 473 184 435 minecraft:light[level=14]
setblock 473 184 443 minecraft:light[level=14]
setblock 473 184 451 minecraft:light[level=14]
fill 475 184 416 476 188 416 minecraft:red_nether_bricks
fill 477 184 416 478 185 416 minecraft:orange_concrete
fill 477 184 458 477 185 458 minecraft:orange_concrete
fill 478 184 458 479 185 458 minecraft:red_nether_bricks
setblock 480 184 458 minecraft:orange_concrete
setblock 481 184 419 minecraft:light[level=14]
setblock 481 184 427 minecraft:light[level=14]
setblock 481 184 435 minecraft:light[level=14]
setblock 481 184 443 minecraft:light[level=14]
setblock 481 184 451 minecraft:light[level=14]
fill 482 184 458 482 188 458 minecraft:red_nether_bricks
fill 483 184 416 484 185 416 minecraft:red_nether_bricks
fill 485 184 416 486 184 416 minecraft:orange_concrete
fill 487 184 416 487 188 416 minecraft:red_nether_bricks
fill 488 184 458 489 185 458 minecraft:orange_concrete
fill 489 184 416 489 185 416 minecraft:orange_concrete
setblock 489 184 419 minecraft:light[level=14]
setblock 489 184 427 minecraft:light[level=14]
setblock 489 184 435 minecraft:light[level=14]
setblock 489 184 443 minecraft:light[level=14]
setblock 489 184 451 minecraft:light[level=14]
fill 490 184 416 491 184 416 minecraft:red_nether_bricks
fill 490 184 458 491 186 458 minecraft:red_nether_bricks
fill 495 184 416 496 188 416 minecraft:red_nether_bricks
fill 497 184 416 498 185 416 minecraft:orange_concrete
setblock 497 184 419 minecraft:light[level=14]
setblock 497 184 427 minecraft:light[level=14]
setblock 497 184 435 minecraft:light[level=14]
setblock 497 184 443 minecraft:light[level=14]
setblock 497 184 451 minecraft:light[level=14]
fill 499 184 458 499 188 458 minecraft:red_nether_bricks
fill 500 184 425 500 187 428 minecraft:red_nether_bricks
fill 500 184 458 501 184 458 minecraft:orange_concrete
fill 501 184 425 502 189 425 minecraft:red_nether_bricks
fill 502 184 458 503 184 458 minecraft:red_nether_bricks
fill 503 184 430 504 184 430 minecraft:red_nether_bricks
fill 504 184 416 504 186 416 minecraft:red_nether_bricks
setblock 505 184 419 minecraft:light[level=14]
setblock 505 184 435 minecraft:light[level=14]
setblock 505 184 443 minecraft:light[level=14]
setblock 505 184 451 minecraft:light[level=14]
setblock 506 184 416 minecraft:orange_concrete
fill 507 184 416 508 188 416 minecraft:red_nether_bricks
fill 508 184 458 509 185 458 minecraft:orange_concrete
fill 509 184 416 510 185 416 minecraft:orange_concrete
fill 510 184 458 511 184 458 minecraft:red_nether_bricks
fill 511 184 416 511 185 416 minecraft:red_nether_bricks
fill 512 184 419 512 188 420 minecraft:red_nether_bricks
fill 512 184 421 512 184 422 minecraft:orange_concrete
fill 512 184 431 512 188 432 minecraft:red_nether_bricks
fill 512 184 433 512 185 434 minecraft:orange_concrete
fill 512 184 440 512 188 440 minecraft:red_nether_bricks
fill 512 184 441 512 184 442 minecraft:orange_concrete
fill 512 184 443 512 188 443 minecraft:red_nether_bricks
fill 512 184 445 512 185 445 minecraft:orange_concrete
fill 512 184 451 512 188 452 minecraft:red_nether_bricks
fill 512 184 453 512 185 454 minecraft:orange_concrete
setblock 512 184 458 minecraft:orange_concrete
fill 470 185 416 470 188 416 minecraft:red_nether_bricks
setblock 470 185 421 minecraft:orange_concrete
setblock 470 185 430 minecraft:netherrack
setblock 470 185 431 minecraft:red_nether_bricks
setblock 470 185 432 minecraft:orange_concrete
fill 470 185 436 470 185 437 minecraft:red_nether_bricks
fill 470 185 446 470 188 446 minecraft:red_nether_bricks
setblock 470 185 447 minecraft:netherrack
setblock 470 185 452 minecraft:netherrack
setblock 470 185 453 minecraft:orange_concrete
setblock 470 185 456 minecraft:orange_concrete
fill 470 185 457 470 188 457 minecraft:red_nether_bricks
fill 472 185 458 472 187 458 minecraft:red_nether_bricks
fill 473 185 416 473 187 416 minecraft:red_nether_bricks
fill 473 185 458 473 186 458 minecraft:netherrack
setblock 474 185 416 minecraft:netherrack
setblock 476 185 458 minecraft:orange_concrete
fill 480 185 458 480 188 458 minecraft:red_nether_bricks
fill 481 185 416 481 187 416 minecraft:red_nether_bricks
setblock 482 185 416 minecraft:netherrack
setblock 485 185 416 minecraft:red_nether_bricks
setblock 486 185 416 minecraft:orange_concrete
setblock 486 185 458 minecraft:netherrack
setblock 487 185 458 minecraft:red_nether_bricks
setblock 490 185 416 minecraft:orange_concrete
setblock 491 185 416 minecraft:red_nether_bricks
fill 492 185 458 492 187 458 minecraft:red_nether_bricks
fill 493 185 416 493 187 416 minecraft:red_nether_bricks
setblock 493 185 458 minecraft:netherrack
setblock 494 185 416 minecraft:netherrack
fill 496 185 458 497 185 458 minecraft:orange_concrete
setblock 498 185 458 minecraft:netherrack
setblock 499 185 416 minecraft:red_nether_bricks
fill 499 185 425 499 189 427 minecraft:red_nether_bricks
setblock 500 185 416 minecraft:netherrack
fill 500 185 424 502 188 424 minecraft:red_nether_bricks
setblock 500 185 458 minecraft:orange_concrete
setblock 501 185 416 minecraft:orange_concrete
fill 501 185 458 501 186 458 minecraft:red_nether_bricks
fill 502 185 416 502 186 416 minecraft:red_nether_bricks
fill 502 185 458 502 186 458 minecraft:netherrack
fill 503 185 428 504 186 428 minecraft:red_nether_bricks
setblock 503 185 458 minecraft:red_nether_bricks
setblock 504 185 429 minecraft:red_nether_bricks
setblock 504 185 458 minecraft:netherrack
fill 505 185 458 505 187 458 minecraft:red_nether_bricks
fill 506 185 416 506 188 416 minecraft:red_nether_bricks
setblock 510 185 458 minecraft:netherrack
fill 511 185 458 511 186 458 minecraft:red_nether_bricks
fill 512 185 421 512 188 421 minecraft:red_nether_bricks
setblock 512 185 422 minecraft:orange_concrete
setblock 512 185 425 minecraft:orange_concrete
fill 512 185 429 512 187 429 minecraft:red_nether_bricks
setblock 512 185 430 minecraft:netherrack
fill 512 185 441 512 188 442 minecraft:red_nether_bricks
setblock 512 185 446 minecraft:orange_concrete
setblock 512 185 457 minecraft:orange_concrete
setblock 512 185 458 minecraft:netherrack
fill 470 186 421 470 187 421 minecraft:netherrack
fill 470 186 422 470 186 423 minecraft:orange_concrete
fill 470 186 424 471 186 425 minecraft:red_nether_bricks
fill 470 186 428 471 186 428 minecraft:red_nether_bricks
setblock 470 186 429 minecraft:netherrack
fill 470 186 430 470 187 431 minecraft:orange_concrete
fill 470 186 432 471 186 433 minecraft:red_nether_bricks
setblock 470 186 434 minecraft:orange_concrete
fill 470 186 436 470 186 437 minecraft:netherrack
fill 470 186 440 470 187 440 minecraft:netherrack
fill 470 186 441 471 186 441 minecraft:red_nether_bricks
fill 470 186 442 470 187 443 minecraft:orange_concrete
fill 470 186 444 471 186 445 minecraft:red_nether_bricks
fill 470 186 447 471 186 447 minecraft:red_nether_bricks
fill 470 186 448 470 187 448 minecraft:netherrack
fill 470 186 449 471 186 449 minecraft:red_nether_bricks
fill 470 186 451 470 187 451 minecraft:orange_concrete
fill 470 186 452 471 186 453 minecraft:red_nether_bricks
fill 470 186 454 470 186 455 minecraft:orange_concrete
setblock 470 186 456 minecraft:netherrack
fill 471 186 416 471 187 416 minecraft:orange_concrete
fill 471 186 417 473 186 417 minecraft:red_nether_bricks
fill 471 186 419 471 186 421 minecraft:red_nether_bricks
setblock 471 186 423 minecraft:red_nether_bricks
setblock 471 186 427 minecraft:red_nether_bricks
setblock 471 186 429 minecraft:red_nether_bricks
setblock 471 186 431 minecraft:red_nether_bricks
fill 471 186 435 471 186 437 minecraft:red_nether_bricks
fill 471 186 439 471 186 440 minecraft:red_nether_bricks
setblock 471 186 443 minecraft:red_nether_bricks
setblock 471 186 448 minecraft:red_nether_bricks
setblock 471 186 451 minecraft:red_nether_bricks
fill 471 186 455 471 186 457 minecraft:red_nether_bricks
fill 473 186 457 475 186 457 minecraft:red_nether_bricks
fill 474 186 416 474 187 416 minecraft:red_nether_bricks
fill 474 186 458 475 187 458 minecraft:orange_concrete
fill 475 186 417 477 186 417 minecraft:red_nether_bricks
fill 476 186 458 477 188 458 minecraft:red_nether_bricks
fill 477 186 416 478 188 416 minecraft:red_nether_bricks
fill 477 186 457 479 186 457 minecraft:red_nether_bricks
setblock 478 186 458 minecraft:netherrack
fill 479 186 416 480 187 416 minecraft:orange_concrete
fill 479 186 417 481 186 417 minecraft:red_nether_bricks
fill 479 186 458 479 189 458 minecraft:red_nether_bricks
fill 481 186 457 483 186 457 minecraft:red_nether_bricks
fill 482 186 416 483 186 416 minecraft:red_nether_bricks
fill 483 186 417 485 186 417 minecraft:red_nether_bricks
fill 484 186 416 485 186 416 minecraft:netherrack
fill 485 186 457 487 186 457 minecraft:red_nether_bricks
setblock 486 186 416 minecraft:red_nether_bricks
fill 486 186 458 487 186 458 minecraft:orange_concrete
fill 487 186 417 489 186 417 minecraft:red_nether_bricks
setblock 488 186 416 minecraft:orange_concrete
fill 488 186 458 489 188 458 minecraft:red_nether_bricks
fill 489 186 416 489 188 416 minecraft:red_nether_bricks
fill 489 186 457 491 186 457 minecraft:red_nether_bricks
setblock 490 186 416 minecraft:netherrack
fill 491 186 416 492 187 416 minecraft:orange_concrete
fill 491 186 417 493 186 417 minecraft:red_nether_bricks
fill 493 186 457 493 186 458 minecraft:red_nether_bricks
fill 494 186 416 494 187 416 minecraft:red_nether_bricks
fill 494 186 457 495 186 457 minecraft:red_nether_bricks
fill 495 186 417 497 186 417 minecraft:red_nether_bricks
fill 495 186 458 495 187 458 minecraft:orange_concrete
fill 496 186 458 497 188 458 minecraft:red_nether_bricks
fill 497 186 416 498 188 416 minecraft:red_nether_bricks
fill 497 186 457 499 186 457 minecraft:red_nether_bricks
fill 498 186 425 498 193 425 minecraft:red_nether_bricks
setblock 498 186 458 minecraft:orange_concrete
fill 499 186 416 500 186 416 minecraft:orange_concrete
fill 499 186 417 501 186 417 minecraft:red_nether_bricks
fill 499 186 424 499 193 424 minecraft:red_nether_bricks
fill 500 186 458 500 188 458 minecraft:red_nether_bricks
setblock 501 186 416 minecraft:red_nether_bricks
fill 501 186 457 503 186 457 minecraft:red_nether_bricks
setblock 503 186 416 minecraft:netherrack
fill 503 186 417 505 186 417 minecraft:red_nether_bricks
fill 503 186 458 503 187 458 minecraft:netherrack
fill 504 186 458 504 187 458 minecraft:red_nether_bricks
fill 505 186 457 507 186 457 minecraft:red_nether_bricks
fill 506 186 458 507 187 458 minecraft:orange_concrete
fill 507 186 417 509 186 417 minecraft:red_nether_bricks
setblock 508 186 458 minecraft:netherrack
fill 509 186 416 510 188 416 minecraft:red_nether_bricks
fill 509 186 457 510 186 458 minecraft:red_nether_bricks
fill 511 186 416 512 187 416 minecraft:orange_concrete
fill 511 186 417 511 186 419 minecraft:red_nether_bricks
fill 511 186 421 511 186 423 minecraft:red_nether_bricks
fill 511 186 425 511 186 427 minecraft:red_nether_bricks
fill 511 186 429 511 186 431 minecraft:red_nether_bricks
fill 511 186 433 511 186 435 minecraft:red_nether_bricks
fill 511 186 437 511 186 439 minecraft:red_nether_bricks
fill 511 186 441 511 186 443 minecraft:red_nether_bricks
fill 511 186 445 511 186 447 minecraft:red_nether_bricks
fill 511 186 449 511 186 451 minecraft:red_nether_bricks
fill 511 186 453 511 186 455 minecraft:red_nether_bricks
fill 511 186 457 512 186 457 minecraft:red_nether_bricks
fill 512 186 417 512 187 417 minecraft:red_nether_bricks
setblock 512 186 418 minecraft:netherrack
fill 512 186 422 512 189 422 minecraft:red_nether_bricks
fill 512 186 423 512 186 424 minecraft:orange_concrete
fill 512 186 425 512 188 425 minecraft:red_nether_bricks
fill 512 186 427 512 187 427 minecraft:orange_concrete
setblock 512 186 430 minecraft:red_nether_bricks
setblock 512 186 433 minecraft:netherrack
setblock 512 186 434 minecraft:red_nether_bricks
fill 512 186 435 512 187 436 minecraft:orange_concrete
setblock 512 186 439 minecraft:netherrack
setblock 512 186 444 minecraft:orange_concrete
fill 512 186 445 512 188 446 minecraft:red_nether_bricks
fill 512 186 447 512 187 448 minecraft:orange_concrete
fill 512 186 453 512 188 454 minecraft:red_nether_bricks
fill 512 186 455 512 186 456 minecraft:orange_concrete
fill 512 186 458 512 188 458 minecraft:red_nether_bricks
fill 470 187 418 470 187 419 minecraft:orange_concrete
setblock 470 187 420 minecraft:netherrack
setblock 470 187 422 minecraft:orange_concrete
fill 470 187 423 470 189 424 minecraft:red_nether_bricks
setblock 470 187 425 minecraft:netherrack
fill 470 187 428 470 187 429 minecraft:red_nether_bricks
fill 470 187 432 470 188 434 minecraft:red_nether_bricks
fill 470 187 436 470 188 436 minecraft:red_nether_bricks
setblock 470 187 437 minecraft:netherrack
setblock 470 187 439 minecraft:orange_concrete
setblock 470 187 441 minecraft:red_nether_bricks
fill 470 187 444 470 189 445 minecraft:red_nether_bricks
fill 470 187 447 470 188 447 minecraft:red_nether_bricks
setblock 470 187 449 minecraft:red_nether_bricks
setblock 470 187 450 minecraft:orange_concrete
fill 470 187 452 470 187 456 minecraft:red_nether_bricks
setblock 472 187 416 minecraft:orange_concrete
setblock 473 187 458 minecraft:red_nether_bricks
fill 478 187 458 478 188 458 minecraft:red_nether_bricks
setblock 482 187 416 minecraft:netherrack
setblock 483 187 416 minecraft:orange_concrete
setblock 483 187 458 minecraft:orange_concrete
fill 484 187 416 485 188 416 minecraft:red_nether_bricks
setblock 486 187 416 minecraft:netherrack
setblock 486 187 458 minecraft:orange_concrete
fill 487 187 458 487 188 458 minecraft:red_nether_bricks
fill 488 187 416 488 188 416 minecraft:red_nether_bricks
fill 490 187 416 490 188 416 minecraft:red_nether_bricks
setblock 490 187 458 minecraft:netherrack
fill 491 187 458 491 188 458 minecraft:red_nether_bricks
setblock 493 187 458 minecraft:red_nether_bricks
setblock 494 187 458 minecraft:orange_concrete
fill 498 187 424 498 194 424 minecraft:red_nether_bricks
fill 498 187 426 498 191 426 minecraft:red_nether_bricks
setblock 498 187 458 minecraft:netherrack
fill 499 187 416 499 188 416 minecraft:red_nether_bricks
fill 499 187 423 501 189 423 minecraft:red_nether_bricks
setblock 500 187 416 minecraft:orange_concrete
fill 501 187 416 502 187 416 minecraft:netherrack
fill 501 187 427 501 188 428 minecraft:red_nether_bricks
setblock 501 187 458 minecraft:netherrack
fill 502 187 458 502 188 458 minecraft:red_nether_bricks
fill 503 187 416 504 187 416 minecraft:orange_concrete
setblock 503 187 428 minecraft:red_nether_bricks
fill 508 187 458 510 188 458 minecraft:red_nether_bricks
setblock 511 187 458 minecraft:netherrack
setblock 512 187 418 minecraft:red_nether_bricks
fill 512 187 423 512 188 424 minecraft:red_nether_bricks
setblock 512 187 428 minecraft:orange_concrete
setblock 512 187 430 minecraft:netherrack
fill 512 187 433 512 188 433 minecraft:red_nether_bricks
setblock 512 187 434 minecraft:netherrack
setblock 512 187 439 minecraft:orange_concrete
fill 512 187 444 512 188 444 minecraft:red_nether_bricks
fill 512 187 455 512 188 455 minecraft:red_nether_bricks
setblock 512 187 456 minecraft:orange_concrete
fill 512 187 457 512 188 457 minecraft:red_nether_bricks
fill 470 188 417 470 189 417 minecraft:orange_concrete
fill 470 188 418 470 188 419 minecraft:red_nether_bricks
setblock 470 188 420 minecraft:orange_concrete
fill 470 188 421 470 188 422 minecraft:red_nether_bricks
setblock 470 188 425 minecraft:red_nether_bricks
fill 470 188 428 470 189 429 minecraft:orange_concrete
fill 470 188 430 470 188 431 minecraft:red_nether_bricks
setblock 470 188 437 minecraft:red_nether_bricks
setblock 470 188 439 minecraft:red_nether_bricks
fill 470 188 440 470 188 441 minecraft:orange_concrete
fill 470 188 442 470 188 443 minecraft:red_nether_bricks
fill 470 188 448 470 189 449 minecraft:orange_concrete
fill 470 188 450 470 188 451 minecraft:red_nether_bricks
setblock 470 188 452 minecraft:orange_concrete
fill 470 188 453 470 188 456 minecraft:red_nether_bricks
fill 471 188 416 472 188 416 minecraft:red_nether_bricks
fill 472 188 458 473 189 458 minecraft:orange_concrete
fill 473 188 416 474 189 416 minecraft:orange_concrete
fill 474 188 458 475 188 458 minecraft:red_nether_bricks
fill 479 188 416 480 188 416 minecraft:red_nether_bricks
fill 481 188 416 482 188 416 minecraft:orange_concrete
fill 481 188 458 481 189 458 minecraft:orange_concrete
setblock 483 188 416 minecraft:red_nether_bricks
fill 483 188 458 483 189 458 minecraft:red_nether_bricks
fill 484 188 458 485 188 458 minecraft:orange_concrete
setblock 486 188 416 minecraft:red_nether_bricks
setblock 486 188 458 minecraft:red_nether_bricks
setblock 490 188 458 minecraft:red_nether_bricks
fill 491 188 416 492 188 416 minecraft:red_nether_bricks
fill 492 188 458 493 189 458 minecraft:orange_concrete
fill 493 188 416 494 189 416 minecraft:orange_concrete
fill 494 188 458 495 188 458 minecraft:red_nether_bricks
fill 497 188 423 497 194 425 minecraft:red_nether_bricks
fill 498 188 423 498 194 423 minecraft:red_nether_bricks
setblock 498 188 458 minecraft:red_nether_bricks
fill 499 188 422 499 192 422 minecraft:red_nether_bricks
setblock 500 188 416 minecraft:red_nether_bricks
fill 500 188 425 500 189 427 minecraft:red_nether_bricks
fill 501 188 416 502 188 416 minecraft:orange_concrete
setblock 501 188 458 minecraft:red_nether_bricks
setblock 502 188 427 minecraft:red_nether_bricks
fill 502 188 428 503 189 428 minecraft:magma_block
fill 503 188 416 504 188 416 minecraft:red_nether_bricks
fill 503 188 427 503 189 427 minecraft:magma_block
setblock 503 188 458 minecraft:red_nether_bricks
fill 504 188 458 505 188 458 minecraft:orange_concrete
fill 505 188 416 505 189 416 minecraft:orange_concrete
fill 506 188 458 507 188 458 minecraft:red_nether_bricks
fill 511 188 416 512 188 416 minecraft:red_nether_bricks
setblock 511 188 458 minecraft:red_nether_bricks
fill 512 188 417 512 189 418 minecraft:orange_concrete
setblock 512 188 426 minecraft:orange_concrete
fill 512 188 427 512 188 428 minecraft:red_nether_bricks
fill 512 188 429 512 189 430 minecraft:orange_concrete
fill 512 188 434 512 188 436 minecraft:red_nether_bricks
fill 512 188 437 512 188 438 minecraft:orange_concrete
setblock 512 188 439 minecraft:red_nether_bricks
fill 512 188 447 512 188 448 minecraft:red_nether_bricks
fill 512 188 449 512 189 450 minecraft:orange_concrete
setblock 512 188 456 minecraft:red_nether_bricks
setblock 470 189 416 minecraft:orange_concrete
fill 470 189 418 470 189 422 minecraft:netherrack
fill 470 189 425 470 189 427 minecraft:netherrack
fill 470 189 430 470 189 435 minecraft:netherrack
fill 470 189 436 470 189 437 minecraft:orange_concrete
fill 470 189 438 470 189 439 minecraft:netherrack
setblock 470 189 440 minecraft:orange_concrete
fill 470 189 441 470 192 443 minecraft:netherrack
fill 470 189 446 470 189 447 minecraft:netherrack
fill 470 189 450 470 189 456 minecraft:netherrack
setblock 470 189 457 minecraft:orange_concrete
fill 470 189 458 471 189 458 minecraft:netherrack
fill 471 189 416 472 190 416 minecraft:netherrack
fill 474 189 458 478 189 458 minecraft:netherrack
fill 475 189 416 481 189 416 minecraft:netherrack
setblock 480 189 458 minecraft:orange_concrete
setblock 482 189 416 minecraft:orange_concrete
setblock 482 189 458 minecraft:netherrack
fill 483 189 416 484 189 416 minecraft:netherrack
fill 484 189 458 491 189 458 minecraft:netherrack
fill 485 189 416 486 189 416 minecraft:orange_concrete
fill 487 189 416 491 189 416 minecraft:netherrack
setblock 492 189 416 minecraft:red_nether_bricks
fill 494 189 458 500 189 458 minecraft:netherrack
fill 495 189 416 501 189 416 minecraft:netherrack
fill 496 189 423 496 195 424 minecraft:red_nether_bricks
fill 497 189 422 498 193 422 minecraft:red_nether_bricks
fill 497 189 426 497 192 426 minecraft:red_nether_bricks
fill 500 189 422 500 190 422 minecraft:red_nether_bricks
fill 500 189 424 501 190 424 minecraft:red_nether_bricks
setblock 501 189 427 minecraft:red_nether_bricks
setblock 501 189 458 minecraft:orange_concrete
setblock 502 189 416 minecraft:red_nether_bricks
setblock 502 189 427 minecraft:magma_block
fill 502 189 458 503 189 458 minecraft:netherrack
fill 503 189 416 503 193 416 minecraft:netherrack
setblock 504 189 416 minecraft:red_nether_bricks
setblock 504 189 458 minecraft:orange_concrete
fill 505 189 458 511 189 458 minecraft:netherrack
setblock 506 189 416 minecraft:orange_concrete
fill 507 189 416 512 189 416 minecraft:netherrack
fill 512 189 419 512 189 420 minecraft:netherrack
setblock 512 189 421 minecraft:orange_concrete
fill 512 189 423 512 189 428 minecraft:netherrack
fill 512 189 431 512 189 437 minecraft:netherrack
setblock 512 189 438 minecraft:orange_concrete
fill 512 189 439 512 189 440 minecraft:netherrack
fill 512 189 441 512 189 442 minecraft:orange_concrete
fill 512 189 443 512 189 448 minecraft:netherrack
fill 512 189 451 512 189 453 minecraft:netherrack
setblock 512 189 454 minecraft:red_nether_bricks
fill 512 189 455 512 190 457 minecraft:netherrack
setblock 512 189 458 minecraft:orange_concrete
fill 470 190 416 470 191 421 minecraft:netherrack
setblock 470 190 422 minecraft:red_nether_bricks
fill 470 190 423 470 190 425 minecraft:netherrack
fill 470 190 426 470 190 427 minecraft:orange_concrete
fill 470 190 428 470 190 431 minecraft:netherrack
setblock 470 190 432 minecraft:red_nether_bricks
fill 470 190 433 470 190 434 minecraft:netherrack
fill 470 190 435 470 191 435 minecraft:orange_concrete
setblock 470 190 436 minecraft:red_nether_bricks
fill 470 190 437 470 195 437 minecraft:netherrack
setblock 470 190 438 minecraft:orange_concrete
fill 470 190 439 470 190 440 minecraft:netherrack
fill 470 190 444 470 190 445 minecraft:netherrack
fill 470 190 446 470 191 447 minecraft:orange_concrete
fill 470 190 448 470 190 454 minecraft:netherrack
setblock 470 190 455 minecraft:red_nether_bricks
fill 470 190 456 470 191 457 minecraft:netherrack
fill 470 190 458 471 190 458 minecraft:orange_concrete
fill 472 190 458 474 193 458 minecraft:netherrack
fill 473 190 416 473 191 416 minecraft:red_nether_bricks
fill 474 190 416 474 195 416 minecraft:netherrack
fill 475 190 416 476 191 416 minecraft:orange_concrete
setblock 475 190 458 minecraft:red_nether_bricks
fill 476 190 458 476 191 458 minecraft:netherrack
fill 477 190 416 477 191 416 minecraft:netherrack
setblock 477 190 458 minecraft:red_nether_bricks
fill 478 190 416 478 191 416 minecraft:red_nether_bricks
fill 478 190 458 479 191 458 minecraft:orange_concrete
fill 479 190 416 483 192 416 minecraft:netherrack
fill 480 190 458 481 195 458 minecraft:netherrack
setblock 482 190 458 minecraft:orange_concrete
fill 483 190 458 489 190 458 minecraft:netherrack
setblock 484 190 416 minecraft:orange_concrete
fill 485 190 416 486 195 416 minecraft:netherrack
fill 487 190 416 487 191 416 minecraft:orange_concrete
fill 488 190 416 494 190 416 minecraft:netherrack
fill 490 190 443 490 215 443 minecraft:red_nether_bricks
fill 490 190 458 491 191 458 minecraft:orange_concrete
fill 492 190 458 492 195 458 minecraft:netherrack
setblock 493 190 458 minecraft:red_nether_bricks
fill 494 190 458 494 193 458 minecraft:netherrack
fill 495 190 416 496 191 416 minecraft:orange_concrete
fill 495 190 423 495 196 424 minecraft:red_nether_bricks
fill 495 190 458 495 191 458 minecraft:red_nether_bricks
fill 496 190 422 496 196 422 minecraft:red_nether_bricks
fill 496 190 425 496 194 425 minecraft:red_nether_bricks
fill 496 190 458 498 190 458 minecraft:netherrack
fill 497 190 416 502 190 416 minecraft:netherrack
fill 499 190 423 500 191 423 minecraft:red_nether_bricks
fill 499 190 425 500 190 426 minecraft:red_nether_bricks
fill 499 190 458 499 191 458 minecraft:orange_concrete
fill 500 190 458 501 191 458 minecraft:netherrack
setblock 501 190 425 minecraft:red_nether_bricks
fill 502 190 458 503 190 458 minecraft:orange_concrete
setblock 503 190 428 minecraft:magma_block
setblock 504 190 416 minecraft:orange_concrete
fill 504 190 458 509 190 458 minecraft:netherrack
fill 505 190 416 506 190 416 minecraft:netherrack
fill 507 190 416 508 191 416 minecraft:orange_concrete
fill 509 190 416 512 190 416 minecraft:netherrack
fill 510 190 458 511 191 458 minecraft:orange_concrete
setblock 512 190 417 minecraft:red_nether_bricks
fill 512 190 418 512 195 418 minecraft:netherrack
fill 512 190 419 512 190 420 minecraft:orange_concrete
fill 512 190 421 512 191 422 minecraft:netherrack
fill 512 190 423 512 191 423 minecraft:orange_concrete
fill 512 190 424 512 190 430 minecraft:netherrack
fill 512 190 431 512 191 432 minecraft:orange_concrete
fill 512 190 433 512 191 438 minecraft:netherrack
setblock 512 190 439 minecraft:red_nether_bricks
setblock 512 190 440 minecraft:orange_concrete
fill 512 190 441 512 195 442 minecraft:netherrack
fill 512 190 443 512 191 443 minecraft:orange_concrete
fill 512 190 444 512 190 450 minecraft:netherrack
fill 512 190 451 512 190 452 minecraft:orange_concrete
fill 512 190 453 512 191 454 minecraft:netherrack
fill 512 190 458 512 195 458 minecraft:netherrack
fill 470 191 422 470 193 422 minecraft:netherrack
setblock 470 191 423 minecraft:orange_concrete
fill 470 191 424 470 191 425 minecraft:netherrack
setblock 470 191 426 minecraft:orange_concrete
fill 470 191 427 470 194 429 minecraft:netherrack
setblock 470 191 430 minecraft:red_nether_bricks
fill 470 191 431 470 191 433 minecraft:netherrack
setblock 470 191 434 minecraft:orange_concrete
fill 470 191 436 470 195 436 minecraft:netherrack
fill 470 191 438 470 194 438 minecraft:netherrack
setblock 470 191 439 minecraft:red_nether_bricks
fill 470 191 440 470 195 440 minecraft:netherrack
setblock 470 191 444 minecraft:netherrack
setblock 470 191 445 minecraft:red_nether_bricks
fill 470 191 448 470 192 452 minecraft:netherrack
setblock 470 191 453 minecraft:red_nether_bricks
fill 470 191 454 470 191 455 minecraft:orange_concrete
setblock 470 191 458 minecraft:orange_concrete
setblock 471 191 416 minecraft:red_nether_bricks
fill 471 191 458 471 194 458 minecraft:netherrack
fill 472 191 416 472 193 416 minecraft:netherrack
fill 475 191 458 475 193 458 minecraft:netherrack
setblock 477 191 458 minecraft:netherrack
fill 482 191 458 486 192 458 minecraft:netherrack
fill 484 191 416 484 194 416 minecraft:netherrack
setblock 487 191 458 minecraft:orange_concrete
setblock 488 191 416 minecraft:orange_concrete
fill 488 191 458 489 191 458 minecraft:netherrack
fill 489 191 416 494 191 416 minecraft:netherrack
fill 493 191 458 493 195 458 minecraft:netherrack
fill 494 191 423 494 198 423 minecraft:red_nether_bricks
fill 495 191 422 495 197 422 minecraft:red_nether_bricks
fill 495 191 425 495 195 425 minecraft:red_nether_bricks
fill 496 191 421 497 194 421 minecraft:red_nether_bricks
setblock 496 191 458 minecraft:red_nether_bricks
fill 497 191 416 498 191 416 minecraft:netherrack
setblock 497 191 458 minecraft:netherrack
setblock 498 191 458 minecraft:orange_concrete
setblock 499 191 416 minecraft:orange_concrete
fill 499 191 425 499 191 426 minecraft:red_nether_bricks
fill 500 191 416 501 191 416 minecraft:netherrack
fill 500 191 424 500 191 425 minecraft:red_nether_bricks
setblock 502 191 416 minecraft:red_nether_bricks
fill 502 191 458 505 192 458 minecraft:netherrack
fill 504 191 416 504 193 416 minecraft:netherrack
setblock 505 191 416 minecraft:red_nether_bricks
fill 506 191 416 506 195 416 minecraft:netherrack
setblock 506 191 458 minecraft:red_nether_bricks
fill 507 191 458 509 191 458 minecraft:netherrack
setblock 509 191 416 minecraft:red_nether_bricks
fill 510 191 416 512 191 416 minecraft:netherrack
fill 512 191 417 512 192 417 minecraft:netherrack
fill 512 191 419 512 194 419 minecraft:netherrack
setblock 512 191 420 minecraft:orange_concrete
setblock 512 191 424 minecraft:orange_concrete
fill 512 191 425 512 191 430 minecraft:netherrack
fill 512 191 439 512 193 440 minecraft:netherrack
setblock 512 191 444 minecraft:orange_concrete
fill 512 191 445 512 191 451 minecraft:netherrack
setblock 512 191 452 minecraft:orange_concrete
setblock 512 191 455 minecraft:orange_concrete
fill 512 191 456 512 191 457 minecraft:netherrack
fill 470 192 416 470 192 420 minecraft:netherrack
fill 470 192 421 470 193 421 minecraft:orange_concrete
fill 470 192 423 470 197 423 minecraft:netherrack
fill 470 192 424 470 192 425 minecraft:orange_concrete
fill 470 192 426 470 197 426 minecraft:netherrack
fill 470 192 430 470 193 431 minecraft:netherrack
fill 470 192 432 470 193 433 minecraft:orange_concrete
fill 470 192 434 470 197 435 minecraft:netherrack
fill 470 192 439 470 193 439 minecraft:netherrack
fill 470 192 444 470 192 445 minecraft:orange_concrete
fill 470 192 446 470 197 447 minecraft:netherrack
fill 470 192 453 470 193 453 minecraft:orange_concrete
fill 470 192 454 470 197 455 minecraft:netherrack
setblock 470 192 456 minecraft:orange_concrete
fill 470 192 457 470 195 458 minecraft:netherrack
fill 471 192 416 471 193 416 minecraft:netherrack
fill 471 192 417 473 192 417 minecraft:red_nether_bricks
fill 471 192 419 471 192 421 minecraft:red_nether_bricks
fill 471 192 423 471 192 425 minecraft:red_nether_bricks
fill 471 192 427 471 192 429 minecraft:red_nether_bricks
fill 471 192 431 471 192 433 minecraft:red_nether_bricks
fill 471 192 435 471 192 437 minecraft:red_nether_bricks
fill 471 192 439 471 192 441 minecraft:red_nether_bricks
fill 471 192 443 471 192 445 minecraft:red_nether_bricks
fill 471 192 447 471 192 449 minecraft:red_nether_bricks
fill 471 192 451 471 192 453 minecraft:red_nether_bricks
fill 471 192 455 471 192 457 minecraft:red_nether_bricks
fill 473 192 416 473 195 416 minecraft:netherrack
setblock 473 192 419 minecraft:light[level=14]
setblock 473 192 427 minecraft:light[level=14]
setblock 473 192 435 minecraft:light[level=14]
setblock 473 192 443 minecraft:light[level=14]
setblock 473 192 451 minecraft:light[level=14]
fill 473 192 457 475 192 457 minecraft:red_nether_bricks
fill 475 192 416 476 197 416 minecraft:netherrack
fill 475 192 417 477 192 417 minecraft:red_nether_bricks
fill 476 192 458 477 193 458 minecraft:orange_concrete
fill 477 192 416 478 192 416 minecraft:orange_concrete
fill 477 192 457 479 192 457 minecraft:red_nether_bricks
fill 478 192 458 479 197 458 minecraft:netherrack
fill 479 192 417 481 192 417 minecraft:red_nether_bricks
setblock 481 192 419 minecraft:light[level=14]
setblock 481 192 427 minecraft:light[level=14]
setblock 481 192 435 minecraft:light[level=14]
setblock 481 192 443 minecraft:light[level=14]
setblock 481 192 451 minecraft:light[level=14]
fill 481 192 457 483 192 457 minecraft:red_nether_bricks
fill 483 192 417 485 192 417 minecraft:red_nether_bricks
fill 485 192 457 487 192 457 minecraft:red_nether_bricks
fill 487 192 416 488 197 416 minecraft:netherrack
fill 487 192 417 489 192 417 minecraft:red_nether_bricks
fill 487 192 458 487 197 458 minecraft:netherrack
fill 488 192 458 489 192 458 minecraft:orange_concrete
fill 489 192 416 490 193 416 minecraft:orange_concrete
setblock 489 192 419 minecraft:light[level=14]
setblock 489 192 427 minecraft:light[level=14]
setblock 489 192 435 minecraft:light[level=14]
setblock 489 192 443 minecraft:light[level=14]
setblock 489 192 451 minecraft:light[level=14]
fill 489 192 457 491 192 457 minecraft:red_nether_bricks
fill 490 192 458 491 197 458 minecraft:netherrack
fill 491 192 416 496 193 416 minecraft:netherrack
fill 491 192 417 493 192 417 minecraft:red_nether_bricks
fill 493 192 457 495 192 457 minecraft:red_nether_bricks
fill 494 192 422 494 198 422 minecraft:red_nether_bricks
fill 494 192 424 494 197 424 minecraft:red_nether_bricks
fill 495 192 417 497 192 417 minecraft:red_nether_bricks
fill 495 192 421 495 197 421 minecraft:red_nether_bricks
fill 495 192 458 495 193 458 minecraft:netherrack
fill 496 192 458 497 193 458 minecraft:orange_concrete
fill 497 192 416 498 192 416 minecraft:orange_concrete
setblock 497 192 419 minecraft:light[level=14]
setblock 497 192 427 minecraft:light[level=14]
setblock 497 192 435 minecraft:light[level=14]
setblock 497 192 443 minecraft:light[level=14]
setblock 497 192 451 minecraft:light[level=14]
fill 497 192 457 499 192 457 minecraft:red_nether_bricks
fill 498 192 458 499 197 458 minecraft:netherrack
fill 499 192 416 500 193 416 minecraft:netherrack
fill 499 192 417 501 192 417 minecraft:red_nether_bricks
fill 499 192 423 499 193 423 minecraft:red_nether_bricks
setblock 499 192 425 minecraft:red_nether_bricks
setblock 500 192 458 minecraft:orange_concrete
fill 501 192 416 501 193 416 minecraft:orange_concrete
fill 501 192 457 503 192 457 minecraft:red_nether_bricks
fill 501 192 458 501 195 458 minecraft:netherrack
setblock 502 192 416 minecraft:netherrack
fill 503 192 417 505 192 417 minecraft:red_nether_bricks
fill 505 192 416 505 195 416 minecraft:netherrack
setblock 505 192 419 minecraft:light[level=14]
setblock 505 192 435 minecraft:light[level=14]
setblock 505 192 443 minecraft:light[level=14]
setblock 505 192 451 minecraft:light[level=14]
fill 505 192 457 507 192 457 minecraft:red_nether_bricks
fill 506 192 458 507 193 458 minecraft:netherrack
fill 507 192 416 508 197 416 minecraft:netherrack
fill 507 192 417 509 192 417 minecraft:red_nether_bricks
fill 508 192 458 509 193 458 minecraft:orange_concrete
fill 509 192 416 510 193 416 minecraft:orange_concrete
fill 509 192 457 511 192 457 minecraft:red_nether_bricks
fill 510 192 458 511 197 458 minecraft:netherrack
fill 511 192 416 512 193 416 minecraft:netherrack
fill 511 192 417 511 192 419 minecraft:red_nether_bricks
fill 511 192 421 511 192 423 minecraft:red_nether_bricks
fill 511 192 425 511 192 427 minecraft:red_nether_bricks
fill 511 192 429 511 192 431 minecraft:red_nether_bricks
fill 511 192 433 511 192 435 minecraft:red_nether_bricks
fill 511 192 437 511 192 439 minecraft:red_nether_bricks
fill 511 192 441 511 192 443 minecraft:red_nether_bricks
fill 511 192 445 511 192 447 minecraft:red_nether_bricks
fill 511 192 449 511 192 451 minecraft:red_nether_bricks
fill 511 192 453 511 192 455 minecraft:red_nether_bricks
fill 512 192 420 512 194 421 minecraft:netherrack
setblock 512 192 422 minecraft:orange_concrete
fill 512 192 423 512 197 424 minecraft:netherrack
fill 512 192 425 512 193 426 minecraft:orange_concrete
fill 512 192 427 512 193 432 minecraft:netherrack
fill 512 192 433 512 192 434 minecraft:orange_concrete
fill 512 192 435 512 192 438 minecraft:netherrack
fill 512 192 443 512 197 444 minecraft:netherrack
fill 512 192 445 512 193 446 minecraft:orange_concrete
fill 512 192 447 512 193 452 minecraft:netherrack
fill 512 192 453 512 192 454 minecraft:orange_concrete
fill 512 192 455 512 193 456 minecraft:netherrack
fill 512 192 457 512 193 457 minecraft:orange_concrete
fill 470 193 416 470 193 419 minecraft:netherrack
setblock 470 193 420 minecraft:orange_concrete
fill 470 193 424 470 196 425 minecraft:netherrack
setblock 470 193 441 minecraft:orange_concrete
fill 470 193 442 470 193 443 minecraft:netherrack
setblock 470 193 444 minecraft:orange_concrete
fill 470 193 445 470 196 445 minecraft:netherrack
fill 470 193 448 470 193 451 minecraft:netherrack
setblock 470 193 452 minecraft:orange_concrete
fill 470 193 456 470 196 456 minecraft:netherrack
fill 477 193 416 477 196 416 minecraft:netherrack
setblock 478 193 416 minecraft:orange_concrete
fill 479 193 416 480 193 416 minecraft:netherrack
setblock 481 193 416 minecraft:orange_concrete
fill 482 193 416 483 193 416 minecraft:netherrack
fill 482 193 458 483 193 458 minecraft:netherrack
fill 484 193 458 485 193 458 minecraft:orange_concrete
setblock 486 193 458 minecraft:netherrack
setblock 488 193 458 minecraft:orange_concrete
fill 489 193 458 489 196 458 minecraft:netherrack
fill 493 193 421 493 198 424 minecraft:red_nether_bricks
fill 494 193 421 494 198 421 minecraft:red_nether_bricks
fill 494 193 425 494 195 425 minecraft:red_nether_bricks
fill 497 193 416 497 196 416 minecraft:netherrack
setblock 498 193 416 minecraft:orange_concrete
fill 500 193 458 500 196 458 minecraft:netherrack
setblock 502 193 416 minecraft:orange_concrete
fill 502 193 458 504 194 458 minecraft:netherrack
setblock 505 193 458 minecraft:orange_concrete
setblock 512 193 417 minecraft:orange_concrete
fill 512 193 422 512 196 422 minecraft:netherrack
fill 512 193 433 512 196 433 minecraft:netherrack
setblock 512 193 434 minecraft:orange_concrete
fill 512 193 435 512 193 436 minecraft:netherrack
setblock 512 193 437 minecraft:orange_concrete
fill 512 193 438 512 195 438 minecraft:netherrack
fill 512 193 453 512 196 454 minecraft:netherrack
fill 470 194 416 470 195 417 minecraft:netherrack
fill 470 194 418 470 195 419 minecraft:orange_concrete
fill 470 194 420 470 199 421 minecraft:netherrack
setblock 470 194 422 minecraft:orange_concrete
fill 470 194 430 470 195 431 minecraft:orange_concrete
fill 470 194 432 470 199 433 minecraft:netherrack
fill 470 194 439 470 195 439 minecraft:orange_concrete
fill 470 194 441 470 199 441 minecraft:netherrack
fill 470 194 442 470 194 443 minecraft:orange_concrete
fill 470 194 444 470 199 444 minecraft:netherrack
fill 470 194 448 470 195 449 minecraft:netherrack
fill 470 194 450 470 195 451 minecraft:orange_concrete
fill 470 194 452 470 199 453 minecraft:netherrack
fill 471 194 416 472 195 416 minecraft:orange_concrete
fill 472 194 458 473 195 458 minecraft:netherrack
fill 474 194 458 475 194 458 minecraft:orange_concrete
fill 476 194 458 477 199 458 minecraft:netherrack
fill 478 194 416 478 199 416 minecraft:netherrack
fill 479 194 416 480 194 416 minecraft:orange_concrete
fill 481 194 416 482 195 416 minecraft:netherrack
setblock 482 194 458 minecraft:netherrack
fill 483 194 416 483 195 416 minecraft:orange_concrete
fill 483 194 458 483 195 458 minecraft:orange_concrete
fill 484 194 458 485 199 458 minecraft:netherrack
setblock 486 194 458 minecraft:orange_concrete
fill 488 194 458 488 199 458 minecraft:netherrack
fill 489 194 416 490 199 416 minecraft:netherrack
fill 491 194 416 492 195 416 minecraft:orange_concrete
fill 492 194 421 492 200 423 minecraft:red_nether_bricks
fill 493 194 416 496 194 416 minecraft:netherrack
fill 494 194 420 494 196 420 minecraft:red_nether_bricks
fill 494 194 458 495 195 458 minecraft:orange_concrete
fill 496 194 458 497 199 458 minecraft:netherrack
fill 497 194 422 497 195 422 minecraft:red_nether_bricks
fill 498 194 416 499 196 416 minecraft:netherrack
setblock 500 194 416 minecraft:orange_concrete
fill 501 194 416 502 199 416 minecraft:netherrack
fill 503 194 416 504 195 416 minecraft:orange_concrete
fill 505 194 458 505 199 458 minecraft:netherrack
fill 506 194 458 507 194 458 minecraft:orange_concrete
fill 508 194 458 509 199 458 minecraft:netherrack
fill 509 194 416 510 199 416 minecraft:netherrack
fill 511 194 416 512 194 416 minecraft:orange_concrete
fill 512 194 417 512 195 417 minecraft:netherrack
fill 512 194 425 512 199 426 minecraft:netherrack
fill 512 194 427 512 195 428 minecraft:orange_concrete
fill 512 194 429 512 195 432 minecraft:netherrack
fill 512 194 434 512 199 434 minecraft:netherrack
fill 512 194 435 512 194 436 minecraft:orange_concrete
fill 512 194 437 512 199 437 minecraft:netherrack
fill 512 194 439 512 195 439 minecraft:orange_concrete
setblock 512 194 440 minecraft:netherrack
fill 512 194 445 512 199 446 minecraft:netherrack
fill 512 194 447 512 195 448 minecraft:orange_concrete
fill 512 194 449 512 194 452 minecraft:netherrack
fill 512 194 455 512 197 455 minecraft:netherrack
setblock 512 194 456 minecraft:orange_concrete
fill 512 194 457 512 199 457 minecraft:netherrack
fill 470 195 422 470 198 422 minecraft:netherrack
setblock 470 195 427 minecraft:orange_concrete
fill 470 195 428 470 195 429 minecraft:netherrack
setblock 470 195 438 minecraft:orange_concrete
fill 470 195 442 470 198 443 minecraft:netherrack
setblock 471 195 458 minecraft:orange_concrete
setblock 474 195 458 minecraft:orange_concrete
fill 475 195 458 475 198 458 minecraft:netherrack
fill 479 195 416 480 198 416 minecraft:netherrack
setblock 482 195 458 minecraft:orange_concrete
setblock 484 195 416 minecraft:orange_concrete
fill 486 195 458 486 198 458 minecraft:netherrack
fill 491 195 421 491 201 423 minecraft:red_nether_bricks
fill 492 195 424 492 199 424 minecraft:red_nether_bricks
fill 493 195 416 494 195 416 minecraft:netherrack
fill 493 195 420 493 197 420 minecraft:red_nether_bricks
setblock 495 195 416 minecraft:orange_concrete
setblock 495 195 420 minecraft:red_nether_bricks
fill 496 195 416 496 197 416 minecraft:netherrack
setblock 496 195 421 minecraft:red_nether_bricks
fill 497 195 423 497 195 424 minecraft:red_nether_bricks
fill 500 195 416 500 198 416 minecraft:netherrack
fill 502 195 458 503 195 458 minecraft:orange_concrete
setblock 504 195 458 minecraft:netherrack
setblock 506 195 458 minecraft:orange_concrete
fill 507 195 458 507 198 458 minecraft:netherrack
fill 511 195 416 511 198 416 minecraft:netherrack
setblock 512 195 416 minecraft:orange_concrete
fill 512 195 419 512 195 420 minecraft:orange_concrete
setblock 512 195 421 minecraft:netherrack
fill 512 195 435 512 197 436 minecraft:netherrack
setblock 512 195 440 minecraft:orange_concrete
fill 512 195 449 512 195 450 minecraft:netherrack
setblock 512 195 451 minecraft:orange_concrete
fill 512 195 452 512 197 452 minecraft:netherrack
fill 512 195 456 512 198 456 minecraft:netherrack
fill 470 196 416 470 197 417 minecraft:orange_concrete
fill 470 196 418 470 201 419 minecraft:netherrack
fill 470 196 427 470 201 427 minecraft:netherrack
fill 470 196 428 470 196 429 minecraft:orange_concrete
fill 470 196 430 470 201 431 minecraft:netherrack
fill 470 196 436 470 197 437 minecraft:orange_concrete
fill 470 196 438 470 201 439 minecraft:netherrack
setblock 470 196 440 minecraft:orange_concrete
fill 470 196 448 470 197 449 minecraft:orange_concrete
fill 470 196 450 470 201 451 minecraft:netherrack
fill 470 196 457 470 197 457 minecraft:orange_concrete
fill 470 196 458 471 197 458 minecraft:netherrack
fill 471 196 416 472 201 416 minecraft:netherrack
fill 472 196 458 473 196 458 minecraft:orange_concrete
fill 473 196 416 474 197 416 minecraft:orange_concrete
fill 474 196 458 474 201 458 minecraft:netherrack
fill 480 196 458 481 197 458 minecraft:orange_concrete
fill 481 196 416 481 199 416 minecraft:netherrack
setblock 482 196 416 minecraft:orange_concrete
fill 482 196 458 483 201 458 minecraft:netherrack
fill 483 196 416 484 201 416 minecraft:netherrack
fill 485 196 416 486 197 416 minecraft:orange_concrete
fill 490 196 421 490 202 423 minecraft:red_nether_bricks
fill 491 196 416 492 201 416 minecraft:netherrack
fill 491 196 424 491 200 424 minecraft:red_nether_bricks
fill 492 196 420 492 199 420 minecraft:red_nether_bricks
fill 492 196 458 493 196 458 minecraft:orange_concrete
fill 493 196 416 494 196 416 minecraft:orange_concrete
fill 494 196 458 495 201 458 minecraft:netherrack
fill 495 196 416 495 201 416 minecraft:netherrack
setblock 496 196 423 minecraft:red_nether_bricks
fill 501 196 458 501 197 458 minecraft:orange_concrete
fill 502 196 458 503 201 458 minecraft:netherrack
fill 503 196 416 504 201 416 minecraft:netherrack
setblock 504 196 458 minecraft:orange_concrete
fill 505 196 416 506 197 416 minecraft:orange_concrete
fill 506 196 417 508 197 418 minecraft:magma_block
fill 506 196 458 506 201 458 minecraft:netherrack
fill 512 196 416 512 201 416 minecraft:netherrack
fill 512 196 417 512 196 418 minecraft:orange_concrete
fill 512 196 419 512 197 420 minecraft:netherrack
fill 512 196 421 512 197 421 minecraft:orange_concrete
fill 512 196 427 512 201 428 minecraft:netherrack
fill 512 196 429 512 197 430 minecraft:orange_concrete
fill 512 196 431 512 197 432 minecraft:netherrack
setblock 512 196 438 minecraft:orange_concrete
fill 512 196 439 512 201 440 minecraft:netherrack
fill 512 196 441 512 197 442 minecraft:orange_concrete
fill 512 196 447 512 201 448 minecraft:netherrack
fill 512 196 449 512 196 450 minecraft:orange_concrete
fill 512 196 451 512 201 451 minecraft:netherrack
fill 512 196 458 512 197 458 minecraft:orange_concrete
fill 470 197 424 470 197 425 minecraft:orange_concrete
setblock 470 197 428 minecraft:orange_concrete
fill 470 197 429 470 200 429 minecraft:netherrack
fill 470 197 440 470 200 440 minecraft:netherrack
setblock 470 197 445 minecraft:orange_concrete
setblock 470 197 456 minecraft:orange_concrete
fill 472 197 458 473 200 458 minecraft:netherrack
setblock 477 197 416 minecraft:orange_concrete
fill 482 197 416 482 200 416 minecraft:netherrack
fill 482 197 417 484 197 418 minecraft:magma_block
fill 489 197 421 489 203 423 minecraft:red_nether_bricks
setblock 489 197 458 minecraft:orange_concrete
fill 490 197 424 490 202 424 minecraft:red_nether_bricks
fill 491 197 420 491 200 420 minecraft:red_nether_bricks
setblock 492 197 458 minecraft:orange_concrete
fill 493 197 416 493 200 416 minecraft:netherrack
fill 493 197 458 493 200 458 minecraft:netherrack
setblock 494 197 416 minecraft:orange_concrete
setblock 495 197 423 minecraft:red_nether_bricks
fill 497 197 416 498 197 416 minecraft:orange_concrete
setblock 499 197 416 minecraft:netherrack
setblock 500 197 458 minecraft:orange_concrete
fill 504 197 458 504 200 458 minecraft:netherrack
setblock 505 197 417 minecraft:magma_block
fill 506 197 419 508 199 419 minecraft:magma_block
setblock 509 197 417 minecraft:magma_block
fill 512 197 417 512 199 418 minecraft:netherrack
setblock 512 197 422 minecraft:orange_concrete
setblock 512 197 433 minecraft:orange_concrete
fill 512 197 438 512 199 438 minecraft:netherrack
fill 512 197 449 512 200 449 minecraft:netherrack
setblock 512 197 450 minecraft:orange_concrete
fill 512 197 453 512 197 454 minecraft:orange_concrete
fill 470 198 416 470 203 417 minecraft:netherrack
fill 470 198 423 470 199 423 minecraft:orange_concrete
fill 470 198 424 470 203 425 minecraft:netherrack
setblock 470 198 426 minecraft:orange_concrete
fill 470 198 428 470 203 428 minecraft:netherrack
fill 470 198 434 470 199 435 minecraft:orange_concrete
fill 470 198 436 470 203 437 minecraft:netherrack
fill 470 198 445 470 203 445 minecraft:netherrack
fill 470 198 446 470 198 447 minecraft:orange_concrete
fill 470 198 448 470 203 449 minecraft:netherrack
fill 470 198 454 470 199 455 minecraft:orange_concrete
fill 470 198 456 470 203 457 minecraft:netherrack
setblock 470 198 458 minecraft:orange_concrete
fill 471 198 417 473 198 417 minecraft:red_nether_bricks
fill 471 198 419 471 198 421 minecraft:red_nether_bricks
fill 471 198 423 471 198 425 minecraft:red_nether_bricks
fill 471 198 427 471 198 429 minecraft:red_nether_bricks
fill 471 198 431 471 198 433 minecraft:red_nether_bricks
fill 471 198 435 471 198 437 minecraft:red_nether_bricks
fill 471 198 439 471 198 441 minecraft:red_nether_bricks
fill 471 198 443 471 198 445 minecraft:red_nether_bricks
fill 471 198 447 471 198 449 minecraft:red_nether_bricks
fill 471 198 451 471 198 453 minecraft:red_nether_bricks
fill 471 198 455 471 198 457 minecraft:red_nether_bricks
fill 471 198 458 471 201 458 minecraft:netherrack
fill 473 198 416 474 203 416 minecraft:netherrack
fill 473 198 457 475 198 457 minecraft:red_nether_bricks
fill 475 198 416 476 198 416 minecraft:orange_concrete
fill 475 198 417 477 198 417 minecraft:red_nether_bricks
fill 477 198 416 477 203 416 minecraft:netherrack
fill 477 198 457 479 198 457 minecraft:red_nether_bricks
fill 478 198 458 479 199 458 minecraft:orange_concrete
fill 479 198 417 481 198 417 minecraft:red_nether_bricks
fill 480 198 458 481 203 458 minecraft:netherrack
fill 481 198 418 485 199 418 minecraft:magma_block
fill 481 198 457 483 198 457 minecraft:red_nether_bricks
fill 482 198 417 482 200 417 minecraft:magma_block
fill 482 198 419 484 200 419 minecraft:magma_block
fill 483 198 417 485 198 417 minecraft:red_nether_bricks
fill 485 198 416 486 203 416 minecraft:netherrack
fill 485 198 457 487 198 457 minecraft:red_nether_bricks
fill 487 198 416 488 199 416 minecraft:orange_concrete
fill 487 198 417 489 198 417 minecraft:red_nether_bricks
fill 487 198 458 487 199 458 minecraft:orange_concrete
fill 488 198 422 488 205 423 minecraft:red_nether_bricks
fill 489 198 424 489 203 424 minecraft:red_nether_bricks
fill 489 198 457 491 198 457 minecraft:red_nether_bricks
fill 489 198 458 489 203 458 minecraft:netherrack
fill 490 198 420 490 201 420 minecraft:red_nether_bricks
fill 490 198 458 491 198 458 minecraft:orange_concrete
fill 491 198 417 493 198 417 minecraft:red_nether_bricks
fill 492 198 458 492 203 458 minecraft:netherrack
fill 493 198 457 495 198 457 minecraft:red_nether_bricks
fill 494 198 416 494 203 416 minecraft:netherrack
fill 495 198 417 497 198 417 minecraft:red_nether_bricks
setblock 496 198 416 minecraft:orange_concrete
fill 497 198 416 498 203 416 minecraft:netherrack
fill 497 198 457 499 198 457 minecraft:red_nether_bricks
fill 498 198 458 499 199 458 minecraft:orange_concrete
fill 499 198 416 499 199 416 minecraft:orange_concrete
fill 499 198 417 501 198 417 minecraft:red_nether_bricks
fill 500 198 458 501 203 458 minecraft:netherrack
fill 501 198 457 503 198 457 minecraft:red_nether_bricks
fill 503 198 417 505 198 417 minecraft:red_nether_bricks
fill 505 198 416 506 203 416 minecraft:netherrack
fill 505 198 457 507 198 457 minecraft:red_nether_bricks
fill 506 198 417 506 199 418 minecraft:magma_block
fill 506 198 420 508 199 420 minecraft:magma_block
fill 507 198 416 508 199 416 minecraft:orange_concrete
fill 507 198 417 509 198 417 minecraft:red_nether_bricks
fill 507 198 418 508 199 418 minecraft:magma_block
fill 509 198 457 511 198 457 minecraft:red_nether_bricks
fill 510 198 458 511 198 458 minecraft:orange_concrete
fill 511 198 417 511 198 419 minecraft:red_nether_bricks
fill 511 198 421 511 198 423 minecraft:red_nether_bricks
fill 511 198 425 511 198 427 minecraft:red_nether_bricks
fill 511 198 429 511 198 431 minecraft:red_nether_bricks
fill 511 198 433 511 198 435 minecraft:red_nether_bricks
fill 511 198 437 511 198 439 minecraft:red_nether_bricks
fill 511 198 441 511 198 443 minecraft:red_nether_bricks
fill 511 198 445 511 198 447 minecraft:red_nether_bricks
fill 511 198 449 511 198 451 minecraft:red_nether_bricks
fill 511 198 453 511 198 455 minecraft:red_nether_bricks
fill 512 198 419 512 201 419 minecraft:netherrack
setblock 512 198 420 minecraft:orange_concrete
fill 512 198 421 512 203 422 minecraft:netherrack
fill 512 198 423 512 199 424 minecraft:orange_concrete
fill 512 198 429 512 200 430 minecraft:netherrack
fill 512 198 431 512 198 432 minecraft:orange_concrete
fill 512 198 433 512 203 433 minecraft:netherrack
fill 512 198 435 512 199 435 minecraft:orange_concrete
setblock 512 198 436 minecraft:netherrack
fill 512 198 441 512 203 442 minecraft:netherrack
fill 512 198 443 512 199 444 minecraft:orange_concrete
fill 512 198 450 512 203 450 minecraft:netherrack
setblock 512 198 452 minecraft:orange_concrete
fill 512 198 453 512 203 454 minecraft:netherrack
fill 512 198 455 512 199 455 minecraft:orange_concrete
fill 512 198 458 512 203 458 minecraft:netherrack
setblock 470 199 422 minecraft:orange_concrete
fill 470 199 426 470 202 426 minecraft:netherrack
fill 470 199 442 470 199 443 minecraft:orange_concrete
setblock 470 199 446 minecraft:orange_concrete
fill 470 199 447 470 202 447 minecraft:netherrack
fill 470 199 458 470 202 458 minecraft:netherrack
fill 475 199 416 475 202 416 minecraft:netherrack
fill 475 199 436 477 200 436 minecraft:magma_block
setblock 475 199 458 minecraft:orange_concrete
setblock 476 199 416 minecraft:orange_concrete
fill 476 199 435 476 200 435 minecraft:magma_block
fill 476 199 437 476 200 437 minecraft:magma_block
fill 479 199 416 480 199 416 minecraft:orange_concrete
setblock 481 199 417 minecraft:magma_block
fill 482 199 420 484 200 420 minecraft:magma_block
fill 483 199 417 485 199 417 minecraft:magma_block
fill 483 199 421 483 201 421 minecraft:magma_block
setblock 486 199 458 minecraft:orange_concrete
fill 487 199 422 487 206 423 minecraft:red_nether_bricks
fill 488 199 421 488 204 421 minecraft:red_nether_bricks
fill 488 199 424 488 205 424 minecraft:red_nether_bricks
fill 489 199 420 489 202 420 minecraft:red_nether_bricks
fill 490 199 458 491 202 458 minecraft:netherrack
fill 493 199 421 493 199 423 minecraft:red_nether_bricks
fill 494 199 422 494 201 423 minecraft:magma_block
fill 496 199 416 496 202 416 minecraft:netherrack
setblock 500 199 416 minecraft:orange_concrete
fill 507 199 417 508 199 417 minecraft:magma_block
fill 507 199 421 507 200 422 minecraft:magma_block
setblock 507 199 458 minecraft:orange_concrete
setblock 510 199 458 minecraft:orange_concrete
setblock 511 199 416 minecraft:orange_concrete
fill 511 199 458 511 202 458 minecraft:netherrack
fill 512 199 420 512 201 420 minecraft:netherrack
fill 512 199 431 512 202 431 minecraft:netherrack
setblock 512 199 432 minecraft:orange_concrete
setblock 512 199 436 minecraft:orange_concrete
fill 512 199 452 512 202 452 minecraft:netherrack
setblock 512 199 456 minecraft:orange_concrete
fill 470 200 420 470 201 421 minecraft:orange_concrete
fill 470 200 422 470 205 423 minecraft:netherrack
fill 470 200 432 470 200 433 minecraft:orange_concrete
fill 470 200 434 470 205 435 minecraft:netherrack
fill 470 200 441 470 201 441 minecraft:orange_concrete
fill 470 200 442 470 205 443 minecraft:netherrack
setblock 470 200 444 minecraft:orange_concrete
fill 470 200 446 470 205 446 minecraft:netherrack
fill 470 200 452 470 201 453 minecraft:orange_concrete
fill 470 200 454 470 205 455 minecraft:netherrack
setblock 473 200 419 minecraft:light[level=14]
setblock 473 200 427 minecraft:light[level=14]
setblock 473 200 435 minecraft:light[level=14]
setblock 473 200 443 minecraft:light[level=14]
setblock 473 200 451 minecraft:light[level=14]
fill 475 200 458 475 205 458 minecraft:netherrack
fill 476 200 416 476 205 416 minecraft:netherrack
fill 476 200 458 477 200 458 minecraft:orange_concrete
setblock 478 200 416 minecraft:orange_concrete
fill 478 200 458 479 205 458 minecraft:netherrack
fill 479 200 416 480 205 416 minecraft:netherrack
fill 481 200 416 481 201 416 minecraft:orange_concrete
setblock 481 200 419 minecraft:light[level=14]
setblock 481 200 427 minecraft:light[level=14]
setblock 481 200 435 minecraft:light[level=14]
setblock 481 200 443 minecraft:light[level=14]
setblock 481 200 451 minecraft:light[level=14]
fill 482 200 418 484 200 418 minecraft:magma_block
setblock 482 200 421 minecraft:magma_block
fill 483 200 417 484 200 417 minecraft:magma_block
fill 483 200 422 483 201 422 minecraft:magma_block
setblock 484 200 421 minecraft:magma_block
fill 484 200 458 485 201 458 minecraft:orange_concrete
fill 486 200 422 486 206 423 minecraft:red_nether_bricks
fill 486 200 458 487 205 458 minecraft:netherrack
fill 487 200 416 488 205 416 minecraft:netherrack
fill 487 200 421 487 204 421 minecraft:red_nether_bricks
fill 487 200 424 487 206 424 minecraft:red_nether_bricks
fill 488 200 420 488 202 420 minecraft:red_nether_bricks
setblock 488 200 458 minecraft:orange_concrete
fill 489 200 416 490 200 416 minecraft:orange_concrete
setblock 489 200 419 minecraft:light[level=14]
setblock 489 200 427 minecraft:light[level=14]
setblock 489 200 435 minecraft:light[level=14]
setblock 489 200 443 minecraft:light[level=14]
setblock 489 200 451 minecraft:light[level=14]
setblock 493 200 422 minecraft:magma_block
fill 496 200 458 497 201 458 minecraft:orange_concrete
setblock 497 200 419 minecraft:light[level=14]
setblock 497 200 427 minecraft:light[level=14]
setblock 497 200 435 minecraft:light[level=14]
setblock 497 200 443 minecraft:light[level=14]
setblock 497 200 451 minecraft:light[level=14]
fill 498 200 458 499 205 458 minecraft:netherrack
fill 499 200 416 500 205 416 minecraft:netherrack
fill 501 200 416 502 201 416 minecraft:orange_concrete
setblock 505 200 419 minecraft:light[level=14]
setblock 505 200 435 minecraft:light[level=14]
setblock 505 200 443 minecraft:light[level=14]
setblock 505 200 451 minecraft:light[level=14]
fill 505 200 458 505 201 458 minecraft:orange_concrete
fill 507 200 416 508 202 416 minecraft:netherrack
fill 507 200 458 507 205 458 minecraft:netherrack
fill 508 200 458 509 200 458 minecraft:orange_concrete
fill 509 200 416 510 200 416 minecraft:orange_concrete
fill 510 200 458 510 205 458 minecraft:netherrack
fill 511 200 416 511 205 416 minecraft:netherrack
fill 512 200 417 512 201 417 minecraft:orange_concrete
setblock 512 200 418 minecraft:netherrack
fill 512 200 423 512 205 424 minecraft:netherrack
fill 512 200 425 512 201 426 minecraft:orange_concrete
fill 512 200 432 512 202 432 minecraft:netherrack
setblock 512 200 434 minecraft:orange_concrete
fill 512 200 435 512 205 436 minecraft:netherrack
fill 512 200 437 512 201 438 minecraft:orange_concrete
fill 512 200 443 512 205 444 minecraft:netherrack
fill 512 200 445 512 200 446 minecraft:orange_concrete
fill 512 200 455 512 205 456 minecraft:netherrack
fill 512 200 457 512 201 457 minecraft:orange_concrete
setblock 470 201 429 minecraft:orange_concrete
setblock 470 201 432 minecraft:orange_concrete
fill 470 201 433 470 204 433 minecraft:netherrack
setblock 470 201 440 minecraft:orange_concrete
fill 470 201 444 470 204 444 minecraft:netherrack
fill 472 201 458 473 201 458 minecraft:orange_concrete
setblock 476 201 458 minecraft:orange_concrete
fill 477 201 458 477 204 458 minecraft:netherrack
fill 478 201 416 478 204 416 minecraft:netherrack
setblock 482 201 416 minecraft:orange_concrete
fill 483 201 418 483 201 420 minecraft:magma_block
setblock 483 201 423 minecraft:magma_block
fill 485 201 423 485 208 423 minecraft:red_nether_bricks
fill 486 201 421 486 205 421 minecraft:red_nether_bricks
fill 486 201 424 486 207 424 minecraft:red_nether_bricks
fill 488 201 458 488 204 458 minecraft:netherrack
fill 489 201 416 489 204 416 minecraft:netherrack
setblock 490 201 416 minecraft:orange_concrete
setblock 493 201 416 minecraft:orange_concrete
setblock 493 201 458 minecraft:orange_concrete
setblock 504 201 458 minecraft:orange_concrete
fill 508 201 458 509 204 458 minecraft:netherrack
fill 509 201 416 509 204 416 minecraft:netherrack
setblock 510 201 416 minecraft:orange_concrete
setblock 512 201 418 minecraft:orange_concrete
setblock 512 201 429 minecraft:orange_concrete
fill 512 201 430 512 203 430 minecraft:netherrack
fill 512 201 434 512 204 434 minecraft:netherrack
fill 512 201 445 512 204 445 minecraft:netherrack
setblock 512 201 446 minecraft:orange_concrete
setblock 512 201 449 minecraft:orange_concrete
fill 470 202 418 470 203 419 minecraft:orange_concrete
fill 470 202 420 470 207 421 minecraft:netherrack
fill 470 202 427 470 203 427 minecraft:orange_concrete
fill 470 202 429 470 207 429 minecraft:netherrack
fill 470 202 430 470 202 431 minecraft:orange_concrete
fill 470 202 432 470 207 432 minecraft:netherrack
fill 470 202 438 470 203 439 minecraft:orange_concrete
fill 470 202 440 470 207 441 minecraft:netherrack
fill 470 202 450 470 202 451 minecraft:orange_concrete
fill 470 202 452 470 207 453 minecraft:netherrack
fill 471 202 416 472 202 416 minecraft:orange_concrete
fill 471 202 458 471 203 458 minecraft:orange_concrete
fill 472 202 458 473 207 458 minecraft:netherrack
setblock 474 202 458 minecraft:orange_concrete
fill 476 202 458 476 207 458 minecraft:netherrack
fill 481 202 416 482 207 416 minecraft:netherrack
fill 482 202 458 483 203 458 minecraft:orange_concrete
fill 483 202 416 484 203 416 minecraft:orange_concrete
fill 484 202 458 485 207 458 minecraft:netherrack
fill 485 202 422 485 207 422 minecraft:red_nether_bricks
fill 485 202 424 485 209 424 minecraft:red_nether_bricks
fill 486 202 425 488 203 425 minecraft:red_nether_bricks
fill 490 202 416 490 207 416 minecraft:netherrack
fill 491 202 416 492 202 416 minecraft:orange_concrete
setblock 491 202 422 minecraft:red_nether_bricks
fill 493 202 416 493 207 416 minecraft:netherrack
fill 493 202 458 493 207 458 minecraft:netherrack
fill 494 202 458 495 202 458 minecraft:orange_concrete
fill 495 202 416 495 203 416 minecraft:orange_concrete
fill 496 202 458 497 207 458 minecraft:netherrack
fill 501 202 416 502 207 416 minecraft:netherrack
fill 502 202 458 503 203 458 minecraft:orange_concrete
fill 503 202 416 504 203 416 minecraft:orange_concrete
fill 504 202 458 505 207 458 minecraft:netherrack
setblock 506 202 458 minecraft:orange_concrete
fill 510 202 416 510 204 416 minecraft:netherrack
setblock 512 202 416 minecraft:orange_concrete
fill 512 202 417 512 207 418 minecraft:netherrack
fill 512 202 419 512 203 420 minecraft:orange_concrete
fill 512 202 425 512 207 426 minecraft:netherrack
fill 512 202 427 512 202 428 minecraft:orange_concrete
fill 512 202 429 512 203 429 minecraft:netherrack
fill 512 202 437 512 207 438 minecraft:netherrack
fill 512 202 439 512 203 440 minecraft:orange_concrete
fill 512 202 446 512 207 446 minecraft:netherrack
fill 512 202 447 512 202 448 minecraft:orange_concrete
fill 512 202 449 512 207 449 minecraft:netherrack
fill 512 202 451 512 203 451 minecraft:orange_concrete
fill 512 202 457 512 207 457 minecraft:netherrack
setblock 470 203 426 minecraft:orange_concrete
fill 470 203 430 470 206 431 minecraft:netherrack
setblock 470 203 447 minecraft:orange_concrete
setblock 470 203 450 minecraft:orange_concrete
fill 470 203 451 470 206 451 minecraft:netherrack
setblock 470 203 458 minecraft:orange_concrete
fill 471 203 416 471 206 416 minecraft:netherrack
setblock 472 203 416 minecraft:orange_concrete
fill 474 203 458 474 206 458 minecraft:netherrack
setblock 475 203 416 minecraft:orange_concrete
fill 484 203 422 484 208 424 minecraft:red_nether_bricks
fill 485 203 421 485 205 421 minecraft:red_nether_bricks
fill 485 203 425 485 209 425 minecraft:red_nether_bricks
fill 490 203 422 490 203 423 minecraft:red_nether_bricks
fill 490 203 458 491 203 458 minecraft:orange_concrete
fill 491 203 416 492 206 416 minecraft:netherrack
setblock 494 203 458 minecraft:orange_concrete
fill 495 203 458 495 206 458 minecraft:netherrack
setblock 496 203 416 minecraft:orange_concrete
fill 506 203 458 506 206 458 minecraft:netherrack
setblock 507 203 416 minecraft:orange_concrete
fill 508 203 416 508 205 416 minecraft:netherrack
setblock 511 203 458 minecraft:orange_concrete
fill 512 203 416 512 206 416 minecraft:netherrack
fill 512 203 427 512 206 427 minecraft:netherrack
setblock 512 203 428 minecraft:orange_concrete
fill 512 203 431 512 203 432 minecraft:orange_concrete
fill 512 203 447 512 205 448 minecraft:netherrack
setblock 512 203 452 minecraft:orange_concrete
fill 470 204 416 470 204 417 minecraft:orange_concrete
fill 470 204 418 470 209 419 minecraft:netherrack
fill 470 204 424 470 205 425 minecraft:orange_concrete
fill 470 204 426 470 209 427 minecraft:netherrack
setblock 470 204 428 minecraft:orange_concrete
fill 470 204 436 470 205 437 minecraft:orange_concrete
fill 470 204 438 470 209 439 minecraft:netherrack
fill 470 204 445 470 205 445 minecraft:orange_concrete
fill 470 204 447 470 209 447 minecraft:netherrack
fill 470 204 448 470 204 449 minecraft:orange_concrete
fill 470 204 450 470 209 450 minecraft:netherrack
fill 470 204 456 470 205 457 minecraft:orange_concrete
fill 470 204 458 471 209 458 minecraft:netherrack
fill 471 204 417 473 204 417 minecraft:red_nether_bricks
fill 471 204 419 471 204 421 minecraft:red_nether_bricks
fill 471 204 423 471 204 425 minecraft:red_nether_bricks
fill 471 204 427 471 204 429 minecraft:red_nether_bricks
fill 471 204 431 471 204 433 minecraft:red_nether_bricks
fill 471 204 435 471 204 437 minecraft:red_nether_bricks
fill 471 204 439 471 204 441 minecraft:red_nether_bricks
fill 471 204 443 471 204 445 minecraft:red_nether_bricks
fill 471 204 447 471 204 449 minecraft:red_nether_bricks
fill 471 204 451 471 204 453 minecraft:red_nether_bricks
fill 471 204 455 471 204 457 minecraft:red_nether_bricks
fill 472 204 416 472 209 416 minecraft:netherrack
fill 473 204 416 474 204 416 minecraft:orange_concrete
fill 473 204 457 475 204 457 minecraft:red_nether_bricks
fill 475 204 416 475 209 416 minecraft:netherrack
fill 475 204 417 477 204 417 minecraft:red_nether_bricks
fill 477 204 416 477 205 416 minecraft:orange_concrete
fill 477 204 457 479 204 457 minecraft:red_nether_bricks
fill 479 204 417 481 204 417 minecraft:red_nether_bricks
fill 480 204 458 481 204 458 minecraft:orange_concrete
fill 481 204 457 483 204 457 minecraft:red_nether_bricks
fill 482 204 458 483 209 458 minecraft:netherrack
fill 483 204 416 484 209 416 minecraft:netherrack
fill 483 204 417 485 204 417 minecraft:red_nether_bricks
fill 483 204 423 483 209 425 minecraft:red_nether_bricks
fill 484 204 425 484 210 425 minecraft:red_nether_bricks
fill 485 204 416 486 205 416 minecraft:orange_concrete
fill 485 204 457 487 204 457 minecraft:red_nether_bricks
fill 486 204 425 487 205 425 minecraft:red_nether_bricks
fill 487 204 417 489 204 417 minecraft:red_nether_bricks
fill 489 204 422 489 204 423 minecraft:red_nether_bricks
fill 489 204 457 491 204 457 minecraft:red_nether_bricks
fill 489 204 458 489 205 458 minecraft:orange_concrete
fill 490 204 458 491 209 458 minecraft:netherrack
fill 491 204 417 493 204 417 minecraft:red_nether_bricks
setblock 492 204 458 minecraft:orange_concrete
schedule function dropper:buildpart/106_5 1t
