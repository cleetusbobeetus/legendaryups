fill 346 181 348 350 182 349 minecraft:gold_block
fill 351 181 338 351 182 339 minecraft:gold_block
fill 351 181 347 351 182 348 minecraft:gold_block
setblock 352 181 339 minecraft:raw_gold_block
fill 352 181 340 353 182 340 minecraft:gold_block
fill 352 181 346 353 182 346 minecraft:gold_block
setblock 352 181 347 minecraft:raw_gold_block
fill 353 181 341 354 182 345 minecraft:gold_block
fill 330 182 323 340 182 363 minecraft:bricks
fill 341 182 323 341 182 339 minecraft:bricks
fill 341 182 340 341 182 346 minecraft:gold_block
fill 341 182 347 341 182 363 minecraft:bricks
fill 342 182 323 342 182 338 minecraft:bricks
fill 342 182 339 342 182 340 minecraft:gold_block
fill 342 182 346 342 182 347 minecraft:gold_block
fill 342 182 348 342 182 363 minecraft:bricks
fill 343 182 323 343 182 337 minecraft:bricks
setblock 343 182 338 minecraft:gold_block
setblock 343 182 348 minecraft:gold_block
fill 343 182 349 343 182 363 minecraft:bricks
fill 344 182 323 344 182 336 minecraft:bricks
fill 344 182 337 345 182 337 minecraft:gold_block
setblock 344 182 339 minecraft:gold_block
fill 344 182 341 344 182 345 minecraft:gold_block
setblock 344 182 347 minecraft:gold_block
fill 344 182 349 345 182 349 minecraft:gold_block
fill 344 182 350 344 182 363 minecraft:bricks
fill 345 182 323 370 182 335 minecraft:bricks
fill 345 182 336 351 182 336 minecraft:gold_block
setblock 345 182 340 minecraft:gold_block
fill 345 182 341 345 182 345 minecraft:ochre_froglight
setblock 345 182 346 minecraft:gold_block
fill 345 182 350 351 182 350 minecraft:gold_block
fill 345 182 351 370 182 363 minecraft:bricks
fill 346 182 339 350 182 339 minecraft:gold_block
fill 346 182 340 346 182 341 minecraft:ochre_froglight
fill 346 182 345 346 182 346 minecraft:ochre_froglight
fill 346 182 347 350 182 347 minecraft:gold_block
fill 347 182 340 350 182 340 minecraft:ochre_froglight
fill 347 182 346 350 182 346 minecraft:ochre_froglight
fill 350 182 341 351 182 341 minecraft:ochre_froglight
fill 350 182 345 351 182 345 minecraft:ochre_froglight
fill 351 182 337 352 182 337 minecraft:gold_block
setblock 351 182 340 minecraft:gold_block
fill 351 182 342 351 182 344 minecraft:ochre_froglight
setblock 351 182 346 minecraft:gold_block
fill 351 182 349 352 182 349 minecraft:gold_block
fill 352 182 336 370 182 336 minecraft:bricks
setblock 352 182 339 minecraft:gold_block
fill 352 182 341 352 182 345 minecraft:gold_block
setblock 352 182 347 minecraft:gold_block
fill 352 182 350 370 182 350 minecraft:bricks
fill 353 182 337 370 182 337 minecraft:bricks
setblock 353 182 338 minecraft:gold_block
setblock 353 182 348 minecraft:gold_block
fill 353 182 349 370 182 349 minecraft:bricks
fill 354 182 338 370 182 338 minecraft:bricks
fill 354 182 339 354 182 340 minecraft:gold_block
fill 354 182 346 354 182 347 minecraft:gold_block
fill 354 182 348 370 182 348 minecraft:bricks
fill 355 182 339 370 182 339 minecraft:bricks
fill 355 182 340 355 182 346 minecraft:gold_block
fill 355 182 347 370 182 347 minecraft:bricks
fill 356 182 340 370 182 346 minecraft:bricks
setblock 345 183 343 minecraft:gold_block
setblock 346 183 341 minecraft:raw_gold_block
setblock 346 183 345 minecraft:raw_gold_block
setblock 348 183 340 minecraft:gold_block
setblock 348 183 346 minecraft:gold_block
setblock 350 183 341 minecraft:raw_gold_block
setblock 350 183 345 minecraft:raw_gold_block
setblock 351 183 343 minecraft:gold_block
setblock 332 184 325 minecraft:light[level=12]
setblock 332 184 332 minecraft:light[level=12]
setblock 332 184 339 minecraft:light[level=12]
setblock 332 184 346 minecraft:light[level=12]
setblock 332 184 353 minecraft:light[level=12]
setblock 332 184 360 minecraft:light[level=12]
setblock 339 184 325 minecraft:light[level=12]
setblock 339 184 332 minecraft:light[level=12]
setblock 339 184 339 minecraft:light[level=12]
setblock 339 184 346 minecraft:light[level=12]
setblock 339 184 353 minecraft:light[level=12]
setblock 339 184 360 minecraft:light[level=12]
setblock 346 184 325 minecraft:light[level=12]
setblock 346 184 332 minecraft:light[level=12]
setblock 346 184 339 minecraft:light[level=12]
setblock 346 184 346 minecraft:light[level=12]
setblock 346 184 353 minecraft:light[level=12]
setblock 346 184 360 minecraft:light[level=12]
setblock 353 184 325 minecraft:light[level=12]
setblock 353 184 332 minecraft:light[level=12]
setblock 353 184 339 minecraft:light[level=12]
setblock 353 184 346 minecraft:light[level=12]
setblock 353 184 353 minecraft:light[level=12]
setblock 353 184 360 minecraft:light[level=12]
setblock 360 184 325 minecraft:light[level=12]
setblock 360 184 332 minecraft:light[level=12]
setblock 360 184 339 minecraft:light[level=12]
setblock 360 184 346 minecraft:light[level=12]
setblock 360 184 353 minecraft:light[level=12]
setblock 360 184 360 minecraft:light[level=12]
setblock 367 184 325 minecraft:light[level=12]
setblock 367 184 332 minecraft:light[level=12]
setblock 367 184 339 minecraft:light[level=12]
setblock 367 184 346 minecraft:light[level=12]
setblock 367 184 353 minecraft:light[level=12]
setblock 367 184 360 minecraft:light[level=12]
fill 329 186 328 329 191 331 minecraft:ochre_froglight
fill 329 186 340 329 191 343 minecraft:ochre_froglight
fill 329 186 352 329 191 355 minecraft:ochre_froglight
fill 329 186 364 332 191 364 minecraft:ochre_froglight
fill 330 186 323 332 230 323 minecraft:polished_andesite
fill 330 186 333 330 230 335 minecraft:polished_andesite
fill 330 186 345 330 230 347 minecraft:polished_andesite
fill 330 186 357 330 230 359 minecraft:polished_andesite
fill 331 186 350 331 188 350 minecraft:iron_block
fill 336 186 322 339 191 322 minecraft:ochre_froglight
fill 336 186 363 338 230 363 minecraft:polished_andesite
fill 341 186 364 344 191 364 minecraft:ochre_froglight
fill 342 186 323 344 230 323 minecraft:polished_andesite
fill 342 186 363 342 192 363 minecraft:waxed_copper_block
fill 344 186 363 345 188 363 minecraft:waxed_copper_block
fill 348 186 322 351 191 322 minecraft:ochre_froglight
fill 348 186 363 350 187 363 minecraft:polished_andesite
fill 353 186 364 356 191 364 minecraft:ochre_froglight
fill 354 186 323 356 230 323 minecraft:polished_andesite
fill 358 186 357 358 199 357 minecraft:iron_block
fill 360 186 322 363 191 322 minecraft:ochre_froglight
fill 360 186 360 362 230 360 minecraft:iron_block
fill 360 186 363 362 230 363 minecraft:polished_andesite
fill 361 186 359 361 230 359 minecraft:iron_block
fill 361 186 361 361 230 361 minecraft:iron_block
fill 363 186 326 363 186 328 minecraft:stone_bricks
fill 364 186 325 366 186 325 minecraft:stone_bricks
fill 364 186 326 366 230 328 minecraft:polished_andesite
fill 364 186 329 366 186 329 minecraft:stone_bricks
fill 365 186 355 365 193 355 minecraft:iron_block
fill 365 186 364 368 191 364 minecraft:ochre_froglight
fill 366 186 323 368 230 323 minecraft:polished_andesite
setblock 367 186 326 minecraft:stone_bricks
fill 367 186 327 367 230 327 minecraft:polished_andesite
setblock 367 186 328 minecraft:stone_bricks
fill 370 186 331 370 230 333 minecraft:polished_andesite
fill 370 186 343 370 230 345 minecraft:polished_andesite
fill 370 186 355 370 230 357 minecraft:polished_andesite
fill 371 186 322 371 238 322 minecraft:stone_bricks
fill 371 186 323 371 191 326 minecraft:ochre_froglight
fill 371 186 335 371 191 338 minecraft:ochre_froglight
fill 371 186 346 371 234 346 minecraft:stone_bricks
fill 371 186 347 371 191 350 minecraft:ochre_froglight
fill 371 186 359 371 191 362 minecraft:ochre_froglight
fill 371 186 363 371 238 363 minecraft:stone_bricks
setblock 341 187 363 minecraft:waxed_copper_block
fill 343 187 363 343 189 363 minecraft:waxed_copper_block
fill 347 187 363 347 191 363 minecraft:waxed_copper_block
setblock 332 188 325 minecraft:light[level=15]
setblock 332 188 333 minecraft:light[level=15]
setblock 332 188 341 minecraft:light[level=15]
setblock 332 188 349 minecraft:light[level=15]
setblock 332 188 357 minecraft:light[level=15]
setblock 340 188 325 minecraft:light[level=15]
setblock 340 188 333 minecraft:light[level=15]
setblock 340 188 341 minecraft:light[level=15]
setblock 340 188 349 minecraft:light[level=15]
setblock 340 188 357 minecraft:light[level=15]
fill 346 188 363 346 194 363 minecraft:waxed_copper_block
setblock 348 188 325 minecraft:light[level=15]
setblock 348 188 333 minecraft:light[level=15]
setblock 348 188 349 minecraft:light[level=15]
setblock 348 188 357 minecraft:light[level=15]
setblock 348 188 363 minecraft:waxed_copper_block
fill 349 188 363 350 230 363 minecraft:polished_andesite
setblock 356 188 325 minecraft:light[level=15]
setblock 356 188 333 minecraft:light[level=15]
setblock 356 188 341 minecraft:light[level=15]
setblock 356 188 349 minecraft:light[level=15]
setblock 356 188 357 minecraft:light[level=15]
setblock 360 188 359 minecraft:polished_andesite
setblock 360 188 361 minecraft:polished_andesite
setblock 362 188 359 minecraft:polished_andesite
setblock 362 188 361 minecraft:polished_andesite
setblock 364 188 325 minecraft:light[level=15]
setblock 364 188 333 minecraft:light[level=15]
setblock 364 188 341 minecraft:light[level=15]
setblock 364 188 349 minecraft:light[level=15]
setblock 364 188 357 minecraft:light[level=15]
fill 340 189 363 341 190 363 minecraft:waxed_copper_block
setblock 345 189 363 minecraft:waxed_copper_block
setblock 348 189 363 minecraft:polished_andesite
setblock 332 190 325 minecraft:light[level=12]
setblock 332 190 332 minecraft:light[level=12]
setblock 332 190 339 minecraft:light[level=12]
setblock 332 190 346 minecraft:light[level=12]
setblock 332 190 353 minecraft:light[level=12]
setblock 332 190 360 minecraft:light[level=12]
setblock 339 190 325 minecraft:light[level=12]
setblock 339 190 332 minecraft:light[level=12]
setblock 339 190 339 minecraft:light[level=12]
setblock 339 190 346 minecraft:light[level=12]
setblock 339 190 353 minecraft:light[level=12]
setblock 339 190 360 minecraft:light[level=12]
setblock 346 190 325 minecraft:light[level=12]
setblock 346 190 332 minecraft:light[level=12]
setblock 346 190 339 minecraft:light[level=12]
setblock 346 190 346 minecraft:light[level=12]
setblock 346 190 353 minecraft:light[level=12]
setblock 346 190 360 minecraft:light[level=12]
fill 348 190 363 348 191 363 minecraft:waxed_copper_block
setblock 353 190 325 minecraft:light[level=12]
setblock 353 190 332 minecraft:light[level=12]
setblock 353 190 339 minecraft:light[level=12]
setblock 353 190 346 minecraft:light[level=12]
setblock 353 190 353 minecraft:light[level=12]
setblock 353 190 360 minecraft:light[level=12]
setblock 360 190 325 minecraft:light[level=12]
setblock 360 190 332 minecraft:light[level=12]
setblock 360 190 339 minecraft:light[level=12]
setblock 360 190 346 minecraft:light[level=12]
setblock 360 190 353 minecraft:light[level=12]
setblock 367 190 325 minecraft:light[level=12]
setblock 367 190 332 minecraft:light[level=12]
setblock 367 190 339 minecraft:light[level=12]
setblock 367 190 346 minecraft:light[level=12]
setblock 367 190 353 minecraft:light[level=12]
setblock 367 190 360 minecraft:light[level=12]
fill 341 191 363 341 193 363 minecraft:waxed_copper_block
fill 343 191 363 343 194 363 minecraft:waxed_copper_block
fill 345 191 363 345 193 363 minecraft:waxed_copper_block
fill 329 192 328 329 205 328 minecraft:stone_bricks
fill 329 192 329 329 192 330 minecraft:ochre_froglight
fill 329 192 331 329 205 331 minecraft:stone_bricks
fill 329 192 340 329 205 340 minecraft:stone_bricks
fill 329 192 341 329 192 342 minecraft:ochre_froglight
fill 329 192 343 329 205 343 minecraft:stone_bricks
fill 329 192 352 329 205 352 minecraft:stone_bricks
fill 329 192 353 329 192 354 minecraft:ochre_froglight
fill 329 192 355 329 205 355 minecraft:stone_bricks
fill 329 192 364 329 205 364 minecraft:stone_bricks
fill 330 192 364 331 192 364 minecraft:ochre_froglight
fill 332 192 364 332 205 364 minecraft:stone_bricks
fill 336 192 322 336 205 322 minecraft:stone_bricks
fill 337 192 322 338 192 322 minecraft:ochre_froglight
fill 339 192 322 339 205 322 minecraft:stone_bricks
setblock 340 192 363 minecraft:waxed_copper_block
fill 341 192 364 341 205 364 minecraft:stone_bricks
fill 342 192 364 343 192 364 minecraft:ochre_froglight
fill 344 192 363 344 194 363 minecraft:waxed_copper_block
fill 344 192 364 344 205 364 minecraft:stone_bricks
fill 348 192 322 348 205 322 minecraft:stone_bricks
fill 348 192 363 348 230 363 minecraft:polished_andesite
fill 349 192 322 350 192 322 minecraft:ochre_froglight
fill 351 192 322 351 205 322 minecraft:stone_bricks
fill 353 192 364 353 205 364 minecraft:stone_bricks
fill 354 192 364 355 192 364 minecraft:ochre_froglight
fill 356 192 364 356 205 364 minecraft:stone_bricks
fill 360 192 322 360 205 322 minecraft:stone_bricks
fill 361 192 322 362 192 322 minecraft:ochre_froglight
fill 363 192 322 363 205 322 minecraft:stone_bricks
fill 365 192 364 365 205 364 minecraft:stone_bricks
fill 366 192 364 367 192 364 minecraft:ochre_froglight
fill 368 192 364 368 205 364 minecraft:stone_bricks
fill 371 192 323 371 205 323 minecraft:stone_bricks
fill 371 192 324 371 192 325 minecraft:ochre_froglight
fill 371 192 326 371 205 326 minecraft:stone_bricks
fill 371 192 335 371 205 335 minecraft:stone_bricks
fill 371 192 336 371 192 337 minecraft:ochre_froglight
fill 371 192 338 371 205 338 minecraft:stone_bricks
fill 371 192 347 371 205 347 minecraft:stone_bricks
fill 371 192 348 371 192 349 minecraft:ochre_froglight
fill 371 192 350 371 205 350 minecraft:stone_bricks
fill 371 192 359 371 205 359 minecraft:stone_bricks
fill 371 192 360 371 192 361 minecraft:ochre_froglight
fill 371 192 362 371 205 362 minecraft:stone_bricks
fill 329 193 329 329 205 330 minecraft:stone_bricks
fill 329 193 341 329 205 342 minecraft:stone_bricks
fill 329 193 353 329 205 354 minecraft:stone_bricks
fill 330 193 364 331 205 364 minecraft:stone_bricks
fill 337 193 322 338 205 322 minecraft:stone_bricks
fill 342 193 364 343 205 364 minecraft:stone_bricks
setblock 347 193 363 minecraft:waxed_copper_block
fill 349 193 322 350 205 322 minecraft:stone_bricks
fill 354 193 364 355 205 364 minecraft:stone_bricks
fill 361 193 322 362 205 322 minecraft:stone_bricks
fill 366 193 364 367 205 364 minecraft:stone_bricks
fill 371 193 324 371 205 325 minecraft:stone_bricks
fill 371 193 336 371 205 337 minecraft:stone_bricks
fill 371 193 348 371 205 349 minecraft:stone_bricks
fill 371 193 360 371 205 361 minecraft:stone_bricks
fill 361 194 362 361 195 362 minecraft:iron_block
fill 363 194 326 363 194 328 minecraft:stone_bricks
fill 364 194 325 366 194 325 minecraft:stone_bricks
fill 364 194 329 366 194 329 minecraft:stone_bricks
setblock 367 194 326 minecraft:stone_bricks
setblock 367 194 328 minecraft:stone_bricks
setblock 361 195 358 minecraft:ochre_froglight
setblock 332 196 325 minecraft:light[level=15]
setblock 332 196 332 minecraft:light[level=12]
setblock 332 196 333 minecraft:light[level=15]
setblock 332 196 339 minecraft:light[level=12]
setblock 332 196 341 minecraft:light[level=15]
setblock 332 196 346 minecraft:light[level=12]
setblock 332 196 349 minecraft:light[level=15]
setblock 332 196 353 minecraft:light[level=12]
setblock 332 196 357 minecraft:light[level=15]
setblock 332 196 360 minecraft:light[level=12]
setblock 339 196 325 minecraft:light[level=12]
setblock 339 196 332 minecraft:light[level=12]
setblock 339 196 339 minecraft:light[level=12]
setblock 339 196 346 minecraft:light[level=12]
setblock 339 196 353 minecraft:light[level=12]
setblock 339 196 360 minecraft:light[level=12]
setblock 340 196 325 minecraft:light[level=15]
setblock 340 196 333 minecraft:light[level=15]
setblock 340 196 341 minecraft:light[level=15]
setblock 340 196 349 minecraft:light[level=15]
setblock 340 196 357 minecraft:light[level=15]
setblock 346 196 325 minecraft:light[level=12]
setblock 346 196 332 minecraft:light[level=12]
setblock 346 196 339 minecraft:light[level=12]
setblock 346 196 346 minecraft:light[level=12]
setblock 346 196 353 minecraft:light[level=12]
setblock 346 196 360 minecraft:light[level=12]
setblock 348 196 325 minecraft:light[level=15]
setblock 348 196 333 minecraft:light[level=15]
setblock 348 196 349 minecraft:light[level=15]
setblock 348 196 357 minecraft:light[level=15]
setblock 353 196 325 minecraft:light[level=12]
setblock 353 196 332 minecraft:light[level=12]
setblock 353 196 339 minecraft:light[level=12]
setblock 353 196 346 minecraft:light[level=12]
setblock 353 196 353 minecraft:light[level=12]
setblock 353 196 360 minecraft:light[level=12]
setblock 356 196 325 minecraft:light[level=15]
setblock 356 196 333 minecraft:light[level=15]
setblock 356 196 341 minecraft:light[level=15]
setblock 356 196 349 minecraft:light[level=15]
setblock 356 196 357 minecraft:light[level=15]
setblock 360 196 325 minecraft:light[level=12]
setblock 360 196 332 minecraft:light[level=12]
setblock 360 196 339 minecraft:light[level=12]
setblock 360 196 346 minecraft:light[level=12]
setblock 360 196 353 minecraft:light[level=12]
setblock 360 196 359 minecraft:polished_andesite
setblock 360 196 361 minecraft:polished_andesite
setblock 362 196 359 minecraft:polished_andesite
setblock 362 196 361 minecraft:polished_andesite
setblock 364 196 325 minecraft:light[level=15]
setblock 364 196 333 minecraft:light[level=15]
setblock 364 196 341 minecraft:light[level=15]
setblock 364 196 349 minecraft:light[level=15]
setblock 364 196 357 minecraft:light[level=15]
setblock 367 196 325 minecraft:light[level=12]
setblock 367 196 332 minecraft:light[level=12]
setblock 367 196 339 minecraft:light[level=12]
setblock 367 196 346 minecraft:light[level=12]
setblock 367 196 353 minecraft:light[level=12]
setblock 367 196 360 minecraft:light[level=12]
fill 370 196 337 370 198 338 minecraft:waxed_copper_block
fill 370 196 340 370 202 340 minecraft:waxed_copper_block
fill 370 197 335 370 201 335 minecraft:waxed_copper_block
fill 370 197 339 370 199 339 minecraft:waxed_copper_block
setblock 370 197 341 minecraft:waxed_copper_block
setblock 370 198 334 minecraft:waxed_copper_block
fill 370 198 336 370 204 336 minecraft:waxed_copper_block
setblock 370 199 337 minecraft:waxed_copper_block
fill 370 199 341 370 200 342 minecraft:waxed_copper_block
fill 331 200 332 331 205 334 minecraft:polished_andesite
fill 331 200 344 331 205 346 minecraft:polished_andesite
fill 331 200 356 331 205 358 minecraft:polished_andesite
fill 337 200 362 339 205 362 minecraft:polished_andesite
fill 341 200 324 343 205 324 minecraft:polished_andesite
fill 349 200 362 351 205 362 minecraft:polished_andesite
fill 353 200 324 355 205 324 minecraft:polished_andesite
fill 361 200 362 363 205 362 minecraft:polished_andesite
fill 362 200 327 362 209 327 minecraft:iron_block
fill 365 200 324 367 205 324 minecraft:polished_andesite
fill 369 200 332 369 205 334 minecraft:polished_andesite
fill 369 200 344 369 205 346 minecraft:polished_andesite
fill 369 200 356 369 205 358 minecraft:polished_andesite
fill 370 200 334 370 201 334 minecraft:waxed_copper_block
fill 370 201 337 370 203 337 minecraft:waxed_copper_block
fill 370 201 339 370 204 339 minecraft:waxed_copper_block
fill 370 201 341 370 203 341 minecraft:waxed_copper_block
setblock 332 202 325 minecraft:light[level=12]
setblock 332 202 332 minecraft:light[level=12]
setblock 332 202 339 minecraft:light[level=12]
setblock 332 202 346 minecraft:light[level=12]
setblock 332 202 353 minecraft:light[level=12]
setblock 332 202 360 minecraft:light[level=12]
setblock 339 202 325 minecraft:light[level=12]
setblock 339 202 332 minecraft:light[level=12]
setblock 339 202 339 minecraft:light[level=12]
setblock 339 202 346 minecraft:light[level=12]
setblock 339 202 353 minecraft:light[level=12]
setblock 339 202 360 minecraft:light[level=12]
setblock 346 202 325 minecraft:light[level=12]
setblock 346 202 332 minecraft:light[level=12]
setblock 346 202 339 minecraft:light[level=12]
setblock 346 202 346 minecraft:light[level=12]
setblock 346 202 353 minecraft:light[level=12]
setblock 346 202 360 minecraft:light[level=12]
setblock 353 202 325 minecraft:light[level=12]
setblock 353 202 332 minecraft:light[level=12]
setblock 353 202 339 minecraft:light[level=12]
setblock 353 202 346 minecraft:light[level=12]
setblock 353 202 353 minecraft:light[level=12]
setblock 353 202 360 minecraft:light[level=12]
setblock 360 202 325 minecraft:light[level=12]
setblock 360 202 332 minecraft:light[level=12]
setblock 360 202 339 minecraft:light[level=12]
setblock 360 202 346 minecraft:light[level=12]
setblock 360 202 353 minecraft:light[level=12]
fill 363 202 326 363 202 328 minecraft:stone_bricks
fill 364 202 325 366 202 325 minecraft:stone_bricks
fill 364 202 329 366 202 329 minecraft:stone_bricks
setblock 367 202 325 minecraft:light[level=12]
setblock 367 202 326 minecraft:stone_bricks
setblock 367 202 328 minecraft:stone_bricks
setblock 367 202 332 minecraft:light[level=12]
setblock 367 202 339 minecraft:light[level=12]
setblock 367 202 346 minecraft:light[level=12]
setblock 367 202 353 minecraft:light[level=12]
setblock 367 202 360 minecraft:light[level=12]
fill 370 202 338 370 204 338 minecraft:waxed_copper_block
setblock 370 202 342 minecraft:waxed_copper_block
setblock 370 203 335 minecraft:waxed_copper_block
setblock 332 204 325 minecraft:light[level=15]
setblock 332 204 333 minecraft:light[level=15]
setblock 332 204 341 minecraft:light[level=15]
setblock 332 204 349 minecraft:light[level=15]
setblock 332 204 357 minecraft:light[level=15]
setblock 340 204 325 minecraft:light[level=15]
setblock 340 204 333 minecraft:light[level=15]
setblock 340 204 341 minecraft:light[level=15]
setblock 340 204 349 minecraft:light[level=15]
setblock 340 204 357 minecraft:light[level=15]
setblock 348 204 325 minecraft:light[level=15]
setblock 348 204 333 minecraft:light[level=15]
setblock 348 204 349 minecraft:light[level=15]
setblock 348 204 357 minecraft:light[level=15]
setblock 356 204 325 minecraft:light[level=15]
setblock 356 204 333 minecraft:light[level=15]
setblock 356 204 341 minecraft:light[level=15]
setblock 356 204 349 minecraft:light[level=15]
setblock 356 204 357 minecraft:light[level=15]
setblock 360 204 359 minecraft:polished_andesite
setblock 360 204 361 minecraft:polished_andesite
setblock 362 204 359 minecraft:polished_andesite
setblock 362 204 361 minecraft:polished_andesite
setblock 364 204 325 minecraft:light[level=15]
setblock 364 204 333 minecraft:light[level=15]
setblock 364 204 341 minecraft:light[level=15]
setblock 364 204 349 minecraft:light[level=15]
setblock 364 204 357 minecraft:light[level=15]
fill 330 205 326 330 205 331 minecraft:stone_bricks
fill 330 205 338 330 205 343 minecraft:stone_bricks
fill 330 205 350 330 205 355 minecraft:stone_bricks
fill 330 205 362 330 205 363 minecraft:stone_bricks
fill 331 205 363 334 205 363 minecraft:stone_bricks
fill 334 205 323 339 205 323 minecraft:stone_bricks
fill 341 205 363 346 205 363 minecraft:stone_bricks
fill 346 205 323 351 205 323 minecraft:stone_bricks
fill 353 205 363 358 205 363 minecraft:stone_bricks
fill 358 205 323 363 205 323 minecraft:stone_bricks
fill 365 205 363 370 205 363 minecraft:stone_bricks
fill 370 205 323 370 205 328 minecraft:stone_bricks
fill 370 205 335 370 205 340 minecraft:stone_bricks
fill 370 205 347 370 205 352 minecraft:stone_bricks
fill 370 205 359 370 205 362 minecraft:stone_bricks
fill 329 206 328 329 211 331 minecraft:ochre_froglight
fill 329 206 340 329 211 343 minecraft:ochre_froglight
fill 329 206 352 329 211 355 minecraft:ochre_froglight
fill 329 206 364 332 211 364 minecraft:ochre_froglight
fill 336 206 322 339 211 322 minecraft:ochre_froglight
fill 341 206 364 344 211 364 minecraft:ochre_froglight
fill 348 206 322 351 211 322 minecraft:ochre_froglight
fill 353 206 364 356 211 364 minecraft:ochre_froglight
fill 360 206 322 363 211 322 minecraft:ochre_froglight
fill 365 206 364 368 211 364 minecraft:ochre_froglight
fill 371 206 323 371 211 326 minecraft:ochre_froglight
fill 371 206 335 371 211 338 minecraft:ochre_froglight
fill 371 206 347 371 211 350 minecraft:ochre_froglight
fill 371 206 359 371 211 362 minecraft:ochre_froglight
fill 356 207 355 356 208 363 minecraft:polished_andesite
fill 357 207 360 357 208 363 minecraft:polished_andesite
setblock 332 208 325 minecraft:light[level=12]
setblock 332 208 332 minecraft:light[level=12]
setblock 332 208 339 minecraft:light[level=12]
setblock 332 208 346 minecraft:light[level=12]
setblock 332 208 353 minecraft:light[level=12]
setblock 332 208 360 minecraft:light[level=12]
setblock 339 208 325 minecraft:light[level=12]
setblock 339 208 332 minecraft:light[level=12]
setblock 339 208 339 minecraft:light[level=12]
setblock 339 208 346 minecraft:light[level=12]
setblock 339 208 353 minecraft:light[level=12]
setblock 339 208 360 minecraft:light[level=12]
setblock 346 208 325 minecraft:light[level=12]
setblock 346 208 332 minecraft:light[level=12]
setblock 346 208 339 minecraft:light[level=12]
setblock 346 208 346 minecraft:light[level=12]
setblock 346 208 353 minecraft:light[level=12]
setblock 346 208 360 minecraft:light[level=12]
setblock 353 208 325 minecraft:light[level=12]
setblock 353 208 332 minecraft:light[level=12]
fill 353 208 333 353 209 336 minecraft:polished_andesite
setblock 353 208 339 minecraft:light[level=12]
setblock 353 208 346 minecraft:light[level=12]
setblock 353 208 353 minecraft:light[level=12]
setblock 353 208 360 minecraft:light[level=12]
fill 354 208 336 354 208 348 minecraft:polished_andesite
fill 355 208 342 355 208 357 minecraft:polished_andesite
fill 356 208 349 356 208 354 minecraft:polished_andesite
fill 357 208 358 357 208 359 minecraft:polished_andesite
setblock 360 208 325 minecraft:light[level=12]
setblock 360 208 332 minecraft:light[level=12]
setblock 360 208 339 minecraft:light[level=12]
setblock 360 208 346 minecraft:light[level=12]
setblock 360 208 353 minecraft:light[level=12]
setblock 367 208 325 minecraft:light[level=12]
setblock 367 208 332 minecraft:light[level=12]
setblock 367 208 339 minecraft:light[level=12]
setblock 367 208 346 minecraft:light[level=12]
setblock 367 208 353 minecraft:light[level=12]
setblock 367 208 360 minecraft:light[level=12]
fill 352 209 323 352 209 331 minecraft:polished_andesite
fill 353 209 324 353 209 332 minecraft:polished_andesite
fill 353 209 337 354 209 339 minecraft:polished_andesite
fill 354 209 332 354 209 336 minecraft:polished_andesite
fill 354 209 340 354 209 346 minecraft:polished_andesite
fill 355 209 341 355 209 351 minecraft:polished_andesite
fill 356 209 354 356 209 362 minecraft:gold_block
setblock 357 209 362 minecraft:gold_block
fill 352 210 323 352 210 328 minecraft:polished_andesite
fill 353 210 325 353 210 332 minecraft:polished_andesite
fill 353 210 333 353 210 335 minecraft:gold_block
fill 354 210 336 354 210 344 minecraft:gold_block
fill 355 210 345 355 210 350 minecraft:gold_block
fill 363 210 326 363 210 328 minecraft:stone_bricks
fill 364 210 325 366 210 325 minecraft:stone_bricks
fill 364 210 329 366 210 329 minecraft:stone_bricks
setblock 367 210 326 minecraft:stone_bricks
setblock 367 210 328 minecraft:stone_bricks
fill 352 211 323 352 211 326 minecraft:gold_block
fill 353 211 329 353 211 331 minecraft:gold_block
fill 329 212 328 329 225 328 minecraft:stone_bricks
fill 329 212 329 329 212 330 minecraft:ochre_froglight
fill 329 212 331 329 225 331 minecraft:stone_bricks
fill 329 212 340 329 225 340 minecraft:stone_bricks
fill 329 212 341 329 212 342 minecraft:ochre_froglight
fill 329 212 343 329 225 343 minecraft:stone_bricks
fill 329 212 352 329 225 352 minecraft:stone_bricks
fill 329 212 353 329 212 354 minecraft:ochre_froglight
fill 329 212 355 329 225 355 minecraft:stone_bricks
fill 329 212 364 329 225 364 minecraft:stone_bricks
fill 330 212 364 331 212 364 minecraft:ochre_froglight
setblock 332 212 325 minecraft:light[level=15]
setblock 332 212 333 minecraft:light[level=15]
setblock 332 212 341 minecraft:light[level=15]
setblock 332 212 349 minecraft:light[level=15]
setblock 332 212 357 minecraft:light[level=15]
fill 332 212 364 332 225 364 minecraft:stone_bricks
fill 336 212 322 336 225 322 minecraft:stone_bricks
fill 337 212 322 338 212 322 minecraft:ochre_froglight
fill 339 212 322 339 225 322 minecraft:stone_bricks
setblock 340 212 325 minecraft:light[level=15]
setblock 340 212 333 minecraft:light[level=15]
setblock 340 212 341 minecraft:light[level=15]
setblock 340 212 349 minecraft:light[level=15]
setblock 340 212 357 minecraft:light[level=15]
fill 341 212 364 341 225 364 minecraft:stone_bricks
fill 342 212 364 343 212 364 minecraft:ochre_froglight
fill 344 212 364 344 225 364 minecraft:stone_bricks
fill 348 212 322 348 225 322 minecraft:stone_bricks
setblock 348 212 325 minecraft:light[level=15]
setblock 348 212 333 minecraft:light[level=15]
setblock 348 212 349 minecraft:light[level=15]
setblock 348 212 357 minecraft:light[level=15]
fill 349 212 322 350 212 322 minecraft:ochre_froglight
fill 351 212 322 351 225 322 minecraft:stone_bricks
fill 353 212 364 353 225 364 minecraft:stone_bricks
fill 354 212 364 355 212 364 minecraft:ochre_froglight
setblock 356 212 325 minecraft:light[level=15]
setblock 356 212 333 minecraft:light[level=15]
setblock 356 212 341 minecraft:light[level=15]
setblock 356 212 349 minecraft:light[level=15]
setblock 356 212 357 minecraft:light[level=15]
fill 356 212 364 356 225 364 minecraft:stone_bricks
fill 360 212 322 360 225 322 minecraft:stone_bricks
setblock 360 212 359 minecraft:polished_andesite
setblock 360 212 361 minecraft:polished_andesite
fill 361 212 322 362 212 322 minecraft:ochre_froglight
setblock 362 212 359 minecraft:polished_andesite
setblock 362 212 361 minecraft:polished_andesite
fill 363 212 322 363 225 322 minecraft:stone_bricks
setblock 364 212 325 minecraft:light[level=15]
setblock 364 212 333 minecraft:light[level=15]
setblock 364 212 341 minecraft:light[level=15]
setblock 364 212 349 minecraft:light[level=15]
setblock 364 212 357 minecraft:light[level=15]
fill 365 212 364 365 225 364 minecraft:stone_bricks
fill 366 212 364 367 212 364 minecraft:ochre_froglight
fill 368 212 364 368 225 364 minecraft:stone_bricks
fill 371 212 323 371 225 323 minecraft:stone_bricks
fill 371 212 324 371 212 325 minecraft:ochre_froglight
fill 371 212 326 371 225 326 minecraft:stone_bricks
fill 371 212 335 371 225 335 minecraft:stone_bricks
fill 371 212 336 371 212 337 minecraft:ochre_froglight
fill 371 212 338 371 225 338 minecraft:stone_bricks
fill 371 212 347 371 225 347 minecraft:stone_bricks
fill 371 212 348 371 212 349 minecraft:ochre_froglight
fill 371 212 350 371 225 350 minecraft:stone_bricks
fill 371 212 359 371 225 359 minecraft:stone_bricks
fill 371 212 360 371 212 361 minecraft:ochre_froglight
fill 371 212 362 371 225 362 minecraft:stone_bricks
fill 329 213 329 329 225 330 minecraft:stone_bricks
fill 329 213 341 329 225 342 minecraft:stone_bricks
fill 329 213 353 329 225 354 minecraft:stone_bricks
fill 330 213 364 331 225 364 minecraft:stone_bricks
fill 337 213 322 338 225 322 minecraft:stone_bricks
fill 342 213 364 343 225 364 minecraft:stone_bricks
fill 346 213 356 350 214 360 minecraft:stone_bricks
fill 348 213 361 348 213 362 minecraft:stone_bricks
fill 349 213 322 350 225 322 minecraft:stone_bricks
fill 354 213 364 355 225 364 minecraft:stone_bricks
fill 361 213 322 362 225 322 minecraft:stone_bricks
fill 366 213 364 367 225 364 minecraft:stone_bricks
fill 371 213 324 371 225 325 minecraft:stone_bricks
fill 371 213 336 371 225 337 minecraft:stone_bricks
fill 371 213 348 371 225 349 minecraft:stone_bricks
fill 371 213 360 371 225 361 minecraft:stone_bricks
setblock 332 214 325 minecraft:light[level=12]
setblock 332 214 332 minecraft:light[level=12]
setblock 332 214 339 minecraft:light[level=12]
setblock 332 214 346 minecraft:light[level=12]
setblock 332 214 353 minecraft:light[level=12]
setblock 332 214 360 minecraft:light[level=12]
setblock 339 214 325 minecraft:light[level=12]
setblock 339 214 332 minecraft:light[level=12]
setblock 339 214 339 minecraft:light[level=12]
setblock 339 214 346 minecraft:light[level=12]
setblock 339 214 353 minecraft:light[level=12]
setblock 339 214 360 minecraft:light[level=12]
setblock 346 214 325 minecraft:light[level=12]
setblock 346 214 332 minecraft:light[level=12]
setblock 346 214 339 minecraft:light[level=12]
setblock 346 214 346 minecraft:light[level=12]
setblock 346 214 353 minecraft:light[level=12]
setblock 353 214 325 minecraft:light[level=12]
setblock 353 214 332 minecraft:light[level=12]
setblock 353 214 339 minecraft:light[level=12]
setblock 353 214 346 minecraft:light[level=12]
setblock 353 214 353 minecraft:light[level=12]
setblock 353 214 360 minecraft:light[level=12]
setblock 360 214 325 minecraft:light[level=12]
setblock 360 214 332 minecraft:light[level=12]
setblock 360 214 339 minecraft:light[level=12]
setblock 360 214 346 minecraft:light[level=12]
setblock 360 214 353 minecraft:light[level=12]
setblock 367 214 325 minecraft:light[level=12]
setblock 367 214 332 minecraft:light[level=12]
setblock 367 214 339 minecraft:light[level=12]
setblock 367 214 346 minecraft:light[level=12]
setblock 367 214 353 minecraft:light[level=12]
setblock 367 214 360 minecraft:light[level=12]
fill 343 215 356 347 216 360 minecraft:stone_bricks
fill 345 215 361 345 215 362 minecraft:stone_bricks
fill 345 218 356 345 219 360 minecraft:iron_block
fill 346 218 355 346 219 356 minecraft:iron_block
fill 346 218 358 350 219 358 minecraft:polished_andesite
fill 346 218 360 346 219 361 minecraft:iron_block
fill 347 218 355 350 219 355 minecraft:iron_block
fill 347 218 361 350 219 361 minecraft:iron_block
fill 348 218 356 348 219 357 minecraft:polished_andesite
fill 348 218 359 348 219 360 minecraft:polished_andesite
fill 350 218 356 351 219 356 minecraft:iron_block
fill 350 218 360 351 219 360 minecraft:iron_block
fill 351 218 357 351 219 359 minecraft:iron_block
fill 363 218 326 363 218 328 minecraft:stone_bricks
fill 364 218 325 366 218 325 minecraft:stone_bricks
fill 364 218 329 366 218 329 minecraft:stone_bricks
setblock 367 218 326 minecraft:stone_bricks
setblock 367 218 328 minecraft:stone_bricks
fill 331 220 332 331 225 334 minecraft:polished_andesite
fill 331 220 344 331 225 346 minecraft:polished_andesite
fill 331 220 356 331 225 358 minecraft:polished_andesite
setblock 332 220 325 minecraft:light[level=15]
setblock 332 220 332 minecraft:light[level=12]
setblock 332 220 333 minecraft:light[level=15]
setblock 332 220 339 minecraft:light[level=12]
setblock 332 220 341 minecraft:light[level=15]
setblock 332 220 346 minecraft:light[level=12]
setblock 332 220 349 minecraft:light[level=15]
setblock 332 220 353 minecraft:light[level=12]
setblock 332 220 357 minecraft:light[level=15]
setblock 332 220 360 minecraft:light[level=12]
fill 337 220 362 339 225 362 minecraft:polished_andesite
setblock 339 220 325 minecraft:light[level=12]
setblock 339 220 332 minecraft:light[level=12]
setblock 339 220 339 minecraft:light[level=12]
setblock 339 220 346 minecraft:light[level=12]
setblock 339 220 353 minecraft:light[level=12]
setblock 339 220 360 minecraft:light[level=12]
setblock 340 220 325 minecraft:light[level=15]
setblock 340 220 333 minecraft:light[level=15]
setblock 340 220 341 minecraft:light[level=15]
setblock 340 220 349 minecraft:light[level=15]
setblock 340 220 357 minecraft:light[level=15]
fill 341 220 324 343 225 324 minecraft:polished_andesite
fill 342 220 356 342 221 360 minecraft:iron_block
fill 343 220 355 343 221 356 minecraft:iron_block
fill 343 220 358 347 221 358 minecraft:polished_andesite
fill 343 220 360 343 221 361 minecraft:iron_block
fill 344 220 355 347 221 355 minecraft:iron_block
fill 344 220 361 347 221 361 minecraft:iron_block
fill 345 220 356 345 221 357 minecraft:polished_andesite
fill 345 220 359 345 221 360 minecraft:polished_andesite
setblock 346 220 325 minecraft:light[level=12]
setblock 346 220 332 minecraft:light[level=12]
setblock 346 220 339 minecraft:light[level=12]
setblock 346 220 346 minecraft:light[level=12]
setblock 346 220 353 minecraft:light[level=12]
setblock 346 220 360 minecraft:light[level=12]
fill 347 220 356 348 221 356 minecraft:iron_block
fill 347 220 360 348 221 360 minecraft:iron_block
setblock 348 220 325 minecraft:light[level=15]
setblock 348 220 333 minecraft:light[level=15]
setblock 348 220 349 minecraft:light[level=15]
fill 348 220 357 348 221 359 minecraft:iron_block
fill 349 220 362 351 225 362 minecraft:polished_andesite
fill 353 220 324 355 225 324 minecraft:polished_andesite
setblock 353 220 325 minecraft:light[level=12]
setblock 353 220 332 minecraft:light[level=12]
setblock 353 220 339 minecraft:light[level=12]
setblock 353 220 346 minecraft:light[level=12]
setblock 353 220 353 minecraft:light[level=12]
setblock 353 220 360 minecraft:light[level=12]
setblock 356 220 325 minecraft:light[level=15]
setblock 356 220 333 minecraft:light[level=15]
setblock 356 220 341 minecraft:light[level=15]
setblock 356 220 349 minecraft:light[level=15]
setblock 356 220 357 minecraft:light[level=15]
setblock 360 220 325 minecraft:light[level=12]
setblock 360 220 332 minecraft:light[level=12]
setblock 360 220 339 minecraft:light[level=12]
setblock 360 220 346 minecraft:light[level=12]
setblock 360 220 353 minecraft:light[level=12]
setblock 360 220 359 minecraft:polished_andesite
setblock 360 220 361 minecraft:polished_andesite
fill 361 220 362 363 225 362 minecraft:polished_andesite
setblock 362 220 359 minecraft:polished_andesite
setblock 362 220 361 minecraft:polished_andesite
setblock 364 220 325 minecraft:light[level=15]
setblock 364 220 333 minecraft:light[level=15]
setblock 364 220 341 minecraft:light[level=15]
setblock 364 220 349 minecraft:light[level=15]
setblock 364 220 357 minecraft:light[level=15]
fill 365 220 324 367 225 324 minecraft:polished_andesite
setblock 367 220 325 minecraft:light[level=12]
setblock 367 220 332 minecraft:light[level=12]
setblock 367 220 339 minecraft:light[level=12]
setblock 367 220 346 minecraft:light[level=12]
setblock 367 220 353 minecraft:light[level=12]
setblock 367 220 360 minecraft:light[level=12]
fill 369 220 332 369 225 334 minecraft:polished_andesite
fill 369 220 344 369 225 346 minecraft:polished_andesite
fill 369 220 356 369 225 358 minecraft:polished_andesite
fill 330 225 326 330 225 331 minecraft:stone_bricks
fill 330 225 338 330 225 343 minecraft:stone_bricks
fill 330 225 350 330 225 355 minecraft:stone_bricks
fill 330 225 362 330 225 363 minecraft:stone_bricks
fill 331 225 363 334 225 363 minecraft:stone_bricks
fill 334 225 323 339 225 323 minecraft:stone_bricks
fill 341 225 363 346 225 363 minecraft:stone_bricks
fill 346 225 323 351 225 323 minecraft:stone_bricks
fill 353 225 363 358 225 363 minecraft:stone_bricks
fill 358 225 323 363 225 323 minecraft:stone_bricks
fill 365 225 363 370 225 363 minecraft:stone_bricks
fill 370 225 323 370 225 328 minecraft:stone_bricks
fill 370 225 335 370 225 340 minecraft:stone_bricks
fill 370 225 347 370 225 352 minecraft:stone_bricks
fill 370 225 359 370 225 362 minecraft:stone_bricks
fill 329 226 328 329 230 331 minecraft:ochre_froglight
fill 329 226 340 329 230 343 minecraft:ochre_froglight
fill 329 226 352 329 230 355 minecraft:ochre_froglight
fill 329 226 364 332 230 364 minecraft:ochre_froglight
setblock 332 226 325 minecraft:light[level=12]
setblock 332 226 332 minecraft:light[level=12]
setblock 332 226 339 minecraft:light[level=12]
setblock 332 226 346 minecraft:light[level=12]
setblock 332 226 353 minecraft:light[level=12]
setblock 332 226 360 minecraft:light[level=12]
fill 336 226 322 339 230 322 minecraft:ochre_froglight
setblock 339 226 325 minecraft:light[level=12]
setblock 339 226 332 minecraft:light[level=12]
setblock 339 226 339 minecraft:light[level=12]
setblock 339 226 346 minecraft:light[level=12]
setblock 339 226 353 minecraft:light[level=12]
setblock 339 226 360 minecraft:light[level=12]
fill 341 226 364 344 230 364 minecraft:ochre_froglight
setblock 346 226 325 minecraft:light[level=12]
setblock 346 226 332 minecraft:light[level=12]
setblock 346 226 339 minecraft:light[level=12]
setblock 346 226 346 minecraft:light[level=12]
setblock 346 226 353 minecraft:light[level=12]
setblock 346 226 360 minecraft:light[level=12]
fill 348 226 322 351 230 322 minecraft:ochre_froglight
setblock 353 226 325 minecraft:light[level=12]
setblock 353 226 332 minecraft:light[level=12]
setblock 353 226 339 minecraft:light[level=12]
setblock 353 226 346 minecraft:light[level=12]
setblock 353 226 353 minecraft:light[level=12]
setblock 353 226 360 minecraft:light[level=12]
fill 353 226 364 356 230 364 minecraft:ochre_froglight
fill 360 226 322 363 230 322 minecraft:ochre_froglight
setblock 360 226 325 minecraft:light[level=12]
setblock 360 226 332 minecraft:light[level=12]
setblock 360 226 339 minecraft:light[level=12]
setblock 360 226 346 minecraft:light[level=12]
setblock 360 226 353 minecraft:light[level=12]
fill 363 226 326 363 226 328 minecraft:stone_bricks
fill 364 226 325 366 226 325 minecraft:stone_bricks
fill 364 226 329 366 226 329 minecraft:stone_bricks
fill 365 226 364 368 230 364 minecraft:ochre_froglight
setblock 367 226 325 minecraft:light[level=12]
setblock 367 226 326 minecraft:stone_bricks
setblock 367 226 328 minecraft:stone_bricks
setblock 367 226 332 minecraft:light[level=12]
setblock 367 226 339 minecraft:light[level=12]
setblock 367 226 346 minecraft:light[level=12]
setblock 367 226 353 minecraft:light[level=12]
setblock 367 226 360 minecraft:light[level=12]
fill 371 226 323 371 230 326 minecraft:ochre_froglight
fill 371 226 335 371 230 338 minecraft:ochre_froglight
fill 371 226 347 371 230 350 minecraft:ochre_froglight
fill 371 226 359 371 230 362 minecraft:ochre_froglight
fill 330 227 344 336 227 344 minecraft:stone_bricks
fill 332 227 342 336 228 343 minecraft:stone_bricks
fill 332 227 345 336 228 346 minecraft:stone_bricks
setblock 332 228 325 minecraft:light[level=15]
setblock 332 228 333 minecraft:light[level=15]
setblock 332 228 341 minecraft:light[level=15]
fill 332 228 344 336 228 344 minecraft:stone_bricks
setblock 332 228 349 minecraft:light[level=15]
setblock 332 228 357 minecraft:light[level=15]
setblock 340 228 325 minecraft:light[level=15]
setblock 340 228 333 minecraft:light[level=15]
setblock 340 228 341 minecraft:light[level=15]
setblock 340 228 349 minecraft:light[level=15]
setblock 340 228 357 minecraft:light[level=15]
setblock 348 228 325 minecraft:light[level=15]
setblock 348 228 333 minecraft:light[level=15]
setblock 348 228 349 minecraft:light[level=15]
setblock 348 228 357 minecraft:light[level=15]
setblock 356 228 325 minecraft:light[level=15]
setblock 356 228 333 minecraft:light[level=15]
setblock 356 228 341 minecraft:light[level=15]
setblock 356 228 349 minecraft:light[level=15]
setblock 356 228 357 minecraft:light[level=15]
setblock 360 228 359 minecraft:polished_andesite
setblock 360 228 361 minecraft:polished_andesite
setblock 362 228 359 minecraft:polished_andesite
setblock 362 228 361 minecraft:polished_andesite
setblock 364 228 325 minecraft:light[level=15]
setblock 364 228 333 minecraft:light[level=15]
setblock 364 228 341 minecraft:light[level=15]
setblock 364 228 349 minecraft:light[level=15]
setblock 364 228 357 minecraft:light[level=15]
fill 363 229 327 363 230 327 minecraft:gold_block
fill 364 229 325 366 230 325 minecraft:gold_block
fill 364 229 329 366 230 329 minecraft:gold_block
fill 367 229 326 367 230 326 minecraft:gold_block
fill 367 229 328 367 230 328 minecraft:gold_block
fill 329 231 328 329 234 331 minecraft:stone_bricks
fill 329 231 340 329 234 343 minecraft:stone_bricks
fill 329 231 352 329 236 355 minecraft:stone_bricks
fill 329 231 364 332 235 364 minecraft:stone_bricks
fill 336 231 322 339 236 322 minecraft:stone_bricks
fill 341 231 364 344 238 364 minecraft:stone_bricks
fill 348 231 322 351 238 322 minecraft:stone_bricks
fill 353 231 364 356 236 364 minecraft:stone_bricks
fill 360 231 322 363 234 322 minecraft:stone_bricks
fill 365 231 364 368 238 364 minecraft:stone_bricks
fill 371 231 323 371 234 326 minecraft:stone_bricks
fill 371 231 335 371 234 338 minecraft:stone_bricks
fill 371 231 347 371 236 350 minecraft:stone_bricks
fill 371 231 359 371 235 362 minecraft:stone_bricks
setblock 332 232 325 minecraft:light[level=12]
setblock 332 232 332 minecraft:light[level=12]
setblock 332 232 339 minecraft:light[level=12]
setblock 332 232 346 minecraft:light[level=12]
setblock 332 232 353 minecraft:light[level=12]
setblock 332 232 360 minecraft:light[level=12]
setblock 339 232 325 minecraft:light[level=12]
setblock 339 232 332 minecraft:light[level=12]
setblock 339 232 339 minecraft:light[level=12]
setblock 339 232 346 minecraft:light[level=12]
setblock 339 232 353 minecraft:light[level=12]
setblock 339 232 360 minecraft:light[level=12]
setblock 346 232 325 minecraft:light[level=12]
setblock 346 232 332 minecraft:light[level=12]
setblock 346 232 339 minecraft:light[level=12]
setblock 346 232 346 minecraft:light[level=12]
setblock 346 232 353 minecraft:light[level=12]
setblock 346 232 360 minecraft:light[level=12]
setblock 353 232 325 minecraft:light[level=12]
setblock 353 232 332 minecraft:light[level=12]
setblock 353 232 339 minecraft:light[level=12]
setblock 353 232 346 minecraft:light[level=12]
setblock 353 232 353 minecraft:light[level=12]
setblock 353 232 360 minecraft:light[level=12]
setblock 360 232 325 minecraft:light[level=12]
setblock 360 232 332 minecraft:light[level=12]
setblock 360 232 339 minecraft:light[level=12]
setblock 360 232 346 minecraft:light[level=12]
setblock 360 232 353 minecraft:light[level=12]
setblock 360 232 360 minecraft:light[level=12]
setblock 367 232 325 minecraft:light[level=12]
setblock 367 232 332 minecraft:light[level=12]
setblock 367 232 339 minecraft:light[level=12]
setblock 367 232 346 minecraft:light[level=12]
setblock 367 232 353 minecraft:light[level=12]
setblock 367 232 360 minecraft:light[level=12]
fill 329 235 328 329 238 329 minecraft:stone_bricks
setblock 329 235 330 minecraft:bricks
fill 329 235 331 329 238 331 minecraft:stone_bricks
setblock 329 235 332 minecraft:bricks
fill 329 235 340 329 238 341 minecraft:stone_bricks
setblock 329 235 342 minecraft:bricks
fill 329 235 343 329 238 343 minecraft:stone_bricks
setblock 329 235 350 minecraft:bricks
fill 330 235 322 331 238 322 minecraft:stone_bricks
setblock 332 235 322 minecraft:bricks
setblock 337 235 364 minecraft:bricks
fill 338 235 364 340 235 364 minecraft:stone_bricks
fill 350 235 364 351 236 364 minecraft:stone_bricks
setblock 352 235 364 minecraft:bricks
setblock 354 235 322 minecraft:stone_bricks
setblock 355 235 322 minecraft:bricks
fill 356 235 322 356 238 322 minecraft:stone_bricks
fill 357 235 322 357 236 322 minecraft:bricks
fill 358 235 322 362 235 322 minecraft:stone_bricks
setblock 363 235 322 minecraft:bricks
fill 368 235 322 369 235 322 minecraft:bricks
fill 370 235 322 370 238 322 minecraft:stone_bricks
setblock 371 235 323 minecraft:bricks
fill 371 235 324 371 236 328 minecraft:stone_bricks
setblock 371 235 329 minecraft:bricks
fill 371 235 330 371 238 330 minecraft:stone_bricks
setblock 371 235 332 minecraft:bricks
setblock 371 235 335 minecraft:bricks
fill 371 235 336 371 235 338 minecraft:stone_bricks
fill 371 235 339 371 235 340 minecraft:bricks
fill 371 235 341 371 238 341 minecraft:stone_bricks
setblock 371 235 346 minecraft:bricks
fill 371 235 357 371 238 357 minecraft:stone_bricks
fill 371 235 358 371 236 358 minecraft:bricks
fill 329 236 330 329 238 330 minecraft:stone_bricks
fill 329 236 332 329 238 332 minecraft:stone_bricks
fill 329 236 342 329 238 342 minecraft:stone_bricks
fill 329 236 344 329 238 344 minecraft:stone_bricks
fill 329 236 345 329 236 346 minecraft:bricks
setblock 329 236 350 minecraft:stone_bricks
fill 329 236 364 329 237 364 minecraft:bricks
fill 330 236 364 332 236 364 minecraft:stone_bricks
fill 332 236 322 332 239 322 minecraft:stone_bricks
setblock 332 236 325 minecraft:light[level=15]
setblock 332 236 333 minecraft:light[level=15]
setblock 332 236 341 minecraft:light[level=15]
setblock 332 236 349 minecraft:light[level=15]
setblock 332 236 357 minecraft:light[level=15]
setblock 333 236 322 minecraft:bricks
setblock 337 236 364 minecraft:stone_bricks
fill 338 236 340 346 236 340 minecraft:gold_block
setblock 338 236 364 minecraft:bricks
fill 339 236 336 357 236 336 minecraft:gold_block
fill 339 236 339 346 236 339 minecraft:gold_block
fill 339 236 342 339 237 343 minecraft:gold_block
fill 339 236 364 340 236 364 minecraft:stone_bricks
setblock 340 236 325 minecraft:light[level=15]
setblock 340 236 333 minecraft:light[level=15]
fill 340 236 337 357 236 337 minecraft:gold_block
setblock 340 236 341 minecraft:light[level=15]
fill 340 236 342 347 236 342 minecraft:gold_block
fill 340 236 345 340 237 346 minecraft:gold_block
setblock 340 236 349 minecraft:light[level=15]
setblock 340 236 357 minecraft:light[level=15]
fill 341 236 333 341 237 334 minecraft:gold_block
fill 341 236 338 347 236 338 minecraft:gold_block
fill 341 236 341 346 236 341 minecraft:gold_block
fill 341 236 343 356 236 345 minecraft:gold_block
fill 342 236 334 355 236 335 minecraft:gold_block
fill 342 236 348 343 237 348 minecraft:gold_block
fill 343 236 331 344 237 331 minecraft:gold_block
fill 343 236 346 354 237 347 minecraft:gold_block
fill 344 236 332 353 237 333 minecraft:gold_block
fill 345 236 348 345 237 350 minecraft:gold_block
fill 345 236 364 347 238 364 minecraft:stone_bricks
fill 346 236 330 347 237 330 minecraft:gold_block
fill 346 236 348 346 237 349 minecraft:gold_block
fill 347 236 331 347 237 331 minecraft:gold_block
fill 347 236 348 354 237 348 minecraft:gold_block
setblock 348 236 325 minecraft:light[level=15]
fill 348 236 349 349 237 350 minecraft:gold_block
setblock 348 236 357 minecraft:light[level=15]
setblock 348 236 364 minecraft:bricks
fill 349 236 329 349 237 331 minecraft:gold_block
fill 349 236 351 349 237 351 minecraft:gold_block
fill 350 236 330 350 237 331 minecraft:gold_block
fill 351 236 338 359 236 338 minecraft:gold_block
fill 351 236 342 357 236 342 minecraft:gold_block
fill 351 236 349 351 237 350 minecraft:gold_block
fill 352 236 331 353 237 331 minecraft:gold_block
fill 352 236 339 357 236 341 minecraft:gold_block
fill 352 236 350 352 237 350 minecraft:gold_block
fill 352 236 364 352 238 364 minecraft:stone_bricks
fill 353 236 330 353 237 330 minecraft:gold_block
setblock 354 236 322 minecraft:bricks
fill 354 236 333 355 237 333 minecraft:gold_block
fill 354 236 349 355 237 349 minecraft:gold_block
fill 355 236 322 355 238 322 minecraft:stone_bricks
fill 355 236 332 356 237 332 minecraft:gold_block
fill 355 236 346 357 237 346 minecraft:gold_block
setblock 356 236 325 minecraft:light[level=15]
setblock 356 236 333 minecraft:light[level=15]
fill 356 236 335 358 237 335 minecraft:gold_block
setblock 356 236 349 minecraft:light[level=15]
setblock 356 236 357 minecraft:light[level=15]
fill 357 236 343 358 237 344 minecraft:gold_block
fill 357 236 347 357 237 347 minecraft:gold_block
setblock 358 236 322 minecraft:bricks
fill 358 236 334 358 237 334 minecraft:gold_block
fill 358 236 340 359 237 341 minecraft:gold_block
fill 359 236 322 363 236 322 minecraft:stone_bricks
fill 359 236 337 359 237 337 minecraft:gold_block
fill 359 236 344 359 237 344 minecraft:gold_block
fill 360 236 340 360 237 340 minecraft:gold_block
setblock 364 236 325 minecraft:light[level=15]
setblock 364 236 333 minecraft:light[level=15]
setblock 364 236 341 minecraft:light[level=15]
setblock 364 236 349 minecraft:light[level=15]
setblock 364 236 357 minecraft:light[level=15]
fill 368 236 322 369 236 322 minecraft:stone_bricks
fill 371 236 323 371 238 323 minecraft:stone_bricks
fill 371 236 329 371 238 329 minecraft:stone_bricks
fill 371 236 332 371 238 332 minecraft:stone_bricks
setblock 371 236 334 minecraft:bricks
fill 371 236 335 371 238 335 minecraft:stone_bricks
setblock 371 236 336 minecraft:bricks
setblock 371 236 337 minecraft:stone_bricks
setblock 371 236 338 minecraft:bricks
fill 371 236 339 371 238 340 minecraft:stone_bricks
fill 371 236 346 371 238 346 minecraft:stone_bricks
fill 371 236 351 371 238 351 minecraft:stone_bricks
fill 371 236 352 371 236 353 minecraft:bricks
fill 371 236 359 371 238 359 minecraft:stone_bricks
setblock 371 236 360 minecraft:bricks
fill 371 236 361 371 238 362 minecraft:stone_bricks
setblock 329 237 322 minecraft:bricks
fill 329 237 323 370 237 323 minecraft:stone_bricks
setblock 329 237 324 minecraft:bricks
fill 329 237 325 371 237 327 minecraft:stone_bricks
setblock 329 237 333 minecraft:bricks
fill 329 237 345 339 237 346 minecraft:stone_bricks
setblock 329 237 350 minecraft:bricks
setblock 329 237 352 minecraft:bricks
fill 329 237 353 370 237 355 minecraft:stone_bricks
fill 330 237 324 370 237 324 minecraft:stone_bricks
fill 330 237 328 337 237 344 minecraft:stone_bricks
fill 330 237 347 341 237 352 minecraft:stone_bricks
fill 330 237 356 331 237 364 minecraft:stone_bricks
fill 332 237 356 370 237 363 minecraft:stone_bricks
setblock 332 237 364 minecraft:bricks
fill 333 237 322 333 238 322 minecraft:stone_bricks
fill 333 237 364 333 238 364 minecraft:stone_bricks
setblock 334 237 364 minecraft:bricks
fill 335 237 364 335 238 364 minecraft:stone_bricks
fill 336 237 322 338 238 322 minecraft:stone_bricks
setblock 337 237 364 minecraft:bricks
fill 338 237 328 338 237 339 minecraft:stone_bricks
fill 338 237 340 345 237 340 minecraft:gold_block
fill 338 237 341 338 237 344 minecraft:stone_bricks
fill 338 237 364 339 238 364 minecraft:stone_bricks
setblock 339 237 322 minecraft:bricks
fill 339 237 328 340 237 335 minecraft:stone_bricks
fill 339 237 336 346 237 336 minecraft:gold_block
fill 339 237 337 339 237 338 minecraft:stone_bricks
fill 339 237 339 345 237 339 minecraft:gold_block
fill 339 237 341 340 237 341 minecraft:stone_bricks
fill 339 237 344 340 237 344 minecraft:stone_bricks
fill 340 237 322 343 238 322 minecraft:stone_bricks
fill 340 237 337 346 237 337 minecraft:gold_block
setblock 340 237 338 minecraft:stone_bricks
fill 340 237 342 342 237 342 minecraft:gold_block
setblock 340 237 343 minecraft:stone_bricks
setblock 340 237 364 minecraft:bricks
fill 341 237 328 342 237 332 minecraft:stone_bricks
setblock 341 237 335 minecraft:stone_bricks
fill 341 237 338 345 237 338 minecraft:gold_block
fill 341 237 341 342 237 341 minecraft:gold_block
fill 341 237 343 343 237 345 minecraft:gold_block
fill 341 237 346 342 237 346 minecraft:stone_bricks
fill 342 237 333 343 237 333 minecraft:stone_bricks
fill 342 237 334 346 237 335 minecraft:gold_block
setblock 342 237 347 minecraft:stone_bricks
fill 342 237 349 344 237 352 minecraft:stone_bricks
fill 343 237 328 345 237 330 minecraft:stone_bricks
setblock 343 237 332 minecraft:stone_bricks
fill 343 237 341 345 237 342 minecraft:waxed_cut_copper
setblock 344 237 322 minecraft:bricks
fill 344 237 343 346 237 344 minecraft:waxed_cut_copper
setblock 344 237 345 minecraft:gold_block
setblock 344 237 348 minecraft:stone_bricks
fill 345 237 322 347 238 322 minecraft:stone_bricks
fill 345 237 331 346 237 331 minecraft:stone_bricks
fill 345 237 345 346 237 345 minecraft:waxed_cut_copper
fill 345 237 351 348 237 352 minecraft:stone_bricks
fill 346 237 328 348 237 329 minecraft:stone_bricks
setblock 346 237 338 minecraft:ochre_froglight
fill 346 237 339 346 237 341 minecraft:sea_lantern
setblock 346 237 342 minecraft:ochre_froglight
fill 346 237 350 347 237 350 minecraft:stone_bricks
fill 347 237 334 351 237 336 minecraft:waxed_cut_copper
setblock 347 237 337 minecraft:ochre_froglight
setblock 347 237 338 minecraft:sea_lantern
setblock 347 237 342 minecraft:sea_lantern
setblock 347 237 343 minecraft:ochre_froglight
fill 347 237 344 351 237 345 minecraft:gold_block
setblock 347 237 349 minecraft:stone_bricks
fill 348 237 330 348 237 331 minecraft:stone_bricks
fill 348 237 337 350 237 337 minecraft:sea_lantern
fill 348 237 343 350 237 343 minecraft:sea_lantern
fill 348 237 364 348 238 364 minecraft:stone_bricks
fill 349 237 328 371 237 328 minecraft:stone_bricks
fill 349 237 352 371 237 352 minecraft:stone_bricks
fill 350 237 329 370 237 329 minecraft:stone_bricks
fill 350 237 349 350 237 351 minecraft:stone_bricks
setblock 350 237 364 minecraft:bricks
fill 351 237 330 351 237 331 minecraft:stone_bricks
setblock 351 237 337 minecraft:ochre_froglight
setblock 351 237 338 minecraft:sea_lantern
setblock 351 237 342 minecraft:sea_lantern
setblock 351 237 343 minecraft:ochre_froglight
fill 351 237 351 370 237 351 minecraft:stone_bricks
fill 351 237 364 351 238 364 minecraft:stone_bricks
setblock 352 237 322 minecraft:bricks
setblock 352 237 330 minecraft:stone_bricks
fill 352 237 334 355 237 337 minecraft:gold_block
setblock 352 237 338 minecraft:ochre_froglight
fill 352 237 339 352 237 341 minecraft:sea_lantern
setblock 352 237 342 minecraft:ochre_froglight
fill 352 237 343 353 237 345 minecraft:waxed_cut_copper
fill 352 237 349 353 237 349 minecraft:stone_bricks
fill 353 237 338 357 237 339 minecraft:gold_block
fill 353 237 340 355 237 342 minecraft:waxed_cut_copper
fill 353 237 350 371 237 350 minecraft:stone_bricks
fill 353 237 364 353 238 364 minecraft:stone_bricks
fill 354 237 322 354 238 322 minecraft:stone_bricks
fill 354 237 330 354 237 332 minecraft:stone_bricks
fill 354 237 343 354 237 344 minecraft:waxed_cut_copper
fill 354 237 345 356 237 345 minecraft:gold_block
setblock 354 237 364 minecraft:bricks
fill 355 237 330 370 237 331 minecraft:stone_bricks
fill 355 237 343 356 237 344 minecraft:gold_block
fill 355 237 347 356 237 348 minecraft:stone_bricks
fill 355 237 364 356 238 364 minecraft:stone_bricks
fill 356 237 333 357 237 334 minecraft:stone_bricks
fill 356 237 336 357 237 337 minecraft:gold_block
fill 356 237 340 357 237 342 minecraft:gold_block
fill 356 237 349 371 237 349 minecraft:stone_bricks
fill 357 237 322 359 238 322 minecraft:stone_bricks
fill 357 237 332 370 237 332 minecraft:stone_bricks
fill 357 237 345 370 237 345 minecraft:stone_bricks
fill 357 237 348 370 237 348 minecraft:stone_bricks
fill 358 237 333 370 237 333 minecraft:stone_bricks
fill 358 237 336 358 237 337 minecraft:stone_bricks
fill 358 237 338 359 237 338 minecraft:gold_block
fill 358 237 339 370 237 339 minecraft:stone_bricks
fill 358 237 342 370 237 342 minecraft:stone_bricks
fill 358 237 346 370 237 347 minecraft:stone_bricks
fill 359 237 334 370 237 336 minecraft:stone_bricks
fill 359 237 343 370 237 343 minecraft:stone_bricks
fill 360 237 322 361 237 322 minecraft:bricks
fill 360 237 337 370 237 338 minecraft:stone_bricks
fill 360 237 341 370 237 341 minecraft:stone_bricks
fill 360 237 344 370 237 344 minecraft:stone_bricks
fill 361 237 340 370 237 340 minecraft:stone_bricks
fill 362 237 322 363 238 322 minecraft:stone_bricks
fill 367 237 322 368 237 322 minecraft:bricks
fill 369 237 322 369 238 322 minecraft:stone_bricks
fill 369 237 364 370 238 364 minecraft:stone_bricks
setblock 371 237 324 minecraft:bricks
fill 371 237 334 371 238 334 minecraft:stone_bricks
fill 371 237 336 371 238 336 minecraft:stone_bricks
setblock 371 237 337 minecraft:bricks
fill 371 237 338 371 238 338 minecraft:stone_bricks
fill 371 237 347 371 238 347 minecraft:stone_bricks
setblock 371 237 348 minecraft:bricks
fill 371 237 353 371 239 353 minecraft:stone_bricks
setblock 371 237 354 minecraft:bricks
fill 371 237 355 371 238 355 minecraft:stone_bricks
setblock 371 237 356 minecraft:bricks
fill 371 237 358 371 238 358 minecraft:stone_bricks
fill 371 237 360 371 238 360 minecraft:stone_bricks
setblock 371 237 364 minecraft:bricks
fill 329 238 322 329 238 327 minecraft:stone_bricks
setblock 329 238 333 minecraft:stone_bricks
fill 329 238 345 329 238 346 minecraft:stone_bricks
setblock 329 238 350 minecraft:stone_bricks
fill 329 238 352 329 238 355 minecraft:stone_bricks
fill 329 238 364 332 238 364 minecraft:stone_bricks
setblock 332 238 325 minecraft:light[level=12]
setblock 332 238 332 minecraft:light[level=12]
setblock 332 238 339 minecraft:light[level=12]
setblock 332 238 346 minecraft:light[level=12]
setblock 332 238 353 minecraft:light[level=12]
setblock 332 238 360 minecraft:light[level=12]
setblock 334 238 364 minecraft:stone_bricks
setblock 337 238 364 minecraft:stone_bricks
setblock 339 238 322 minecraft:stone_bricks
setblock 339 238 325 minecraft:light[level=12]
setblock 339 238 332 minecraft:light[level=12]
setblock 339 238 339 minecraft:light[level=12]
setblock 339 238 346 minecraft:light[level=12]
setblock 339 238 353 minecraft:light[level=12]
setblock 339 238 360 minecraft:light[level=12]
setblock 340 238 364 minecraft:stone_bricks
fill 342 238 333 344 239 348 minecraft:gray_concrete
setblock 344 238 322 minecraft:stone_bricks
fill 345 238 333 357 239 335 minecraft:gray_concrete
fill 345 238 345 357 239 348 minecraft:gray_concrete
setblock 346 238 325 minecraft:light[level=12]
setblock 346 238 332 minecraft:light[level=12]
setblock 346 238 353 minecraft:light[level=12]
setblock 346 238 360 minecraft:light[level=12]
setblock 350 238 364 minecraft:stone_bricks
setblock 352 238 322 minecraft:stone_bricks
setblock 353 238 325 minecraft:light[level=12]
setblock 353 238 332 minecraft:light[level=12]
setblock 353 238 353 minecraft:light[level=12]
setblock 353 238 360 minecraft:light[level=12]
fill 354 238 336 357 239 344 minecraft:gray_concrete
setblock 354 238 364 minecraft:stone_bricks
fill 360 238 322 361 238 322 minecraft:stone_bricks
setblock 360 238 325 minecraft:light[level=12]
setblock 360 238 332 minecraft:light[level=12]
setblock 360 238 339 minecraft:light[level=12]
setblock 360 238 346 minecraft:light[level=12]
setblock 360 238 353 minecraft:light[level=12]
setblock 360 238 360 minecraft:light[level=12]
fill 367 238 322 368 238 322 minecraft:stone_bricks
setblock 367 238 325 minecraft:light[level=12]
setblock 367 238 332 minecraft:light[level=12]
setblock 367 238 339 minecraft:light[level=12]
setblock 367 238 346 minecraft:light[level=12]
setblock 367 238 353 minecraft:light[level=12]
setblock 367 238 360 minecraft:light[level=12]
fill 371 238 324 371 238 328 minecraft:stone_bricks
setblock 371 238 337 minecraft:stone_bricks
fill 371 238 348 371 238 350 minecraft:stone_bricks
setblock 371 238 352 minecraft:stone_bricks
fill 371 238 354 371 239 354 minecraft:stone_bricks
setblock 371 238 356 minecraft:stone_bricks
setblock 371 238 364 minecraft:stone_bricks
fill 329 239 322 329 239 334 minecraft:bricks
fill 329 239 336 329 245 345 minecraft:bricks
setblock 329 239 346 minecraft:stone_bricks
fill 329 239 347 329 308 348 minecraft:bricks
setblock 329 239 349 minecraft:stone_bricks
fill 329 239 350 329 239 356 minecraft:bricks
setblock 329 239 357 minecraft:stone_bricks
fill 329 239 358 329 239 364 minecraft:bricks
setblock 330 239 322 minecraft:stone_bricks
fill 330 239 364 330 245 364 minecraft:bricks
setblock 331 239 322 minecraft:bricks
setblock 331 239 364 minecraft:stone_bricks
fill 332 239 364 338 239 364 minecraft:bricks
fill 333 239 322 344 240 322 minecraft:bricks
setblock 339 239 364 minecraft:stone_bricks
fill 340 239 364 354 239 364 minecraft:bricks
setblock 345 239 322 minecraft:stone_bricks
fill 346 239 322 362 239 322 minecraft:bricks
setblock 355 239 364 minecraft:stone_bricks
fill 356 239 364 371 239 364 minecraft:bricks
setblock 363 239 322 minecraft:stone_bricks
fill 364 239 322 371 239 322 minecraft:bricks
fill 371 239 323 371 239 324 minecraft:bricks
setblock 371 239 325 minecraft:stone_bricks
fill 371 239 326 371 239 348 minecraft:bricks
fill 371 239 349 371 241 349 minecraft:stone_bricks
fill 371 239 350 371 245 352 minecraft:bricks
fill 371 239 355 371 239 363 minecraft:bricks
fill 329 240 322 329 240 330 minecraft:bricks
setblock 329 240 331 minecraft:stone_bricks
fill 329 240 332 329 308 335 minecraft:bricks
fill 329 240 346 329 308 346 minecraft:bricks
fill 329 240 349 329 308 351 minecraft:bricks
setblock 329 240 352 minecraft:stone_bricks
fill 329 240 353 329 240 357 minecraft:bricks
setblock 329 240 358 minecraft:stone_bricks
fill 329 240 359 329 240 364 minecraft:bricks
fill 330 240 322 330 308 322 minecraft:bricks
setblock 331 240 322 minecraft:stone_bricks
fill 331 240 364 334 245 364 minecraft:bricks
fill 332 240 322 332 308 322 minecraft:bricks
setblock 335 240 364 minecraft:stone_bricks
fill 336 240 364 349 240 364 minecraft:bricks
fill 342 240 333 342 252 333 minecraft:gray_concrete
setblock 342 240 334 minecraft:sea_lantern
fill 342 240 335 357 253 335 minecraft:gray_concrete
setblock 342 240 336 minecraft:black_stained_glass
fill 342 240 337 344 253 337 minecraft:gray_concrete
setblock 342 240 338 minecraft:black_stained_glass
fill 342 240 339 344 253 339 minecraft:gray_concrete
setblock 342 240 340 minecraft:black_stained_glass
fill 342 240 341 344 253 341 minecraft:gray_concrete
setblock 342 240 342 minecraft:light_blue_stained_glass
fill 342 240 343 344 253 343 minecraft:gray_concrete
setblock 342 240 344 minecraft:sea_lantern
fill 342 240 345 357 253 345 minecraft:gray_concrete
setblock 342 240 346 minecraft:sea_lantern
fill 342 240 347 342 253 348 minecraft:gray_concrete
setblock 343 240 333 minecraft:sea_lantern
fill 343 240 334 356 253 334 minecraft:gray_concrete
fill 343 240 336 344 253 336 minecraft:gray_concrete
fill 343 240 338 344 253 338 minecraft:gray_concrete
fill 343 240 340 344 253 340 minecraft:gray_concrete
fill 343 240 342 344 253 342 minecraft:gray_concrete
fill 343 240 344 344 253 344 minecraft:gray_concrete
fill 343 240 346 356 253 347 minecraft:gray_concrete
setblock 343 240 348 minecraft:light_blue_stained_glass
fill 344 240 333 344 252 333 minecraft:gray_concrete
fill 344 240 348 344 253 348 minecraft:gray_concrete
fill 345 240 322 346 308 322 minecraft:bricks
setblock 345 240 333 minecraft:black_stained_glass
setblock 345 240 348 minecraft:sea_lantern
fill 346 240 333 346 252 333 minecraft:gray_concrete
fill 346 240 348 346 253 348 minecraft:gray_concrete
setblock 347 240 322 minecraft:stone_bricks
setblock 347 240 333 minecraft:sea_lantern
setblock 347 240 348 minecraft:light_blue_stained_glass
fill 348 240 322 360 240 322 minecraft:bricks
fill 348 240 333 348 252 333 minecraft:gray_concrete
fill 348 240 348 348 253 348 minecraft:gray_concrete
setblock 349 240 333 minecraft:black_stained_glass
setblock 349 240 348 minecraft:black_stained_glass
fill 350 240 333 350 252 333 minecraft:gray_concrete
fill 350 240 348 350 253 348 minecraft:gray_concrete
setblock 350 240 364 minecraft:stone_bricks
setblock 351 240 333 minecraft:light_blue_stained_glass
setblock 351 240 348 minecraft:black_stained_glass
fill 351 240 364 357 245 364 minecraft:bricks
fill 352 240 333 352 252 333 minecraft:gray_concrete
fill 352 240 348 352 253 348 minecraft:gray_concrete
setblock 353 240 333 minecraft:light_blue_stained_glass
setblock 353 240 348 minecraft:light_blue_stained_glass
fill 354 240 333 354 252 333 minecraft:gray_concrete
fill 354 240 336 356 253 344 minecraft:gray_concrete
fill 354 240 348 354 253 348 minecraft:gray_concrete
setblock 355 240 333 minecraft:light_blue_stained_glass
setblock 355 240 348 minecraft:light_blue_stained_glass
fill 356 240 333 357 252 333 minecraft:gray_concrete
fill 356 240 348 357 253 348 minecraft:gray_concrete
setblock 357 240 334 minecraft:sea_lantern
setblock 357 240 336 minecraft:light_blue_stained_glass
fill 357 240 337 357 253 337 minecraft:gray_concrete
setblock 357 240 338 minecraft:black_stained_glass
fill 357 240 339 357 253 339 minecraft:gray_concrete
setblock 357 240 340 minecraft:sea_lantern
fill 357 240 341 357 253 341 minecraft:gray_concrete
setblock 357 240 342 minecraft:black_stained_glass
fill 357 240 343 357 253 343 minecraft:gray_concrete
setblock 357 240 344 minecraft:black_stained_glass
setblock 357 240 346 minecraft:black_stained_glass
fill 357 240 347 357 253 347 minecraft:gray_concrete
setblock 358 240 364 minecraft:stone_bricks
fill 359 240 364 371 245 364 minecraft:bricks
setblock 361 240 322 minecraft:stone_bricks
fill 362 240 322 367 245 322 minecraft:bricks
setblock 368 240 322 minecraft:stone_bricks
fill 369 240 322 371 308 322 minecraft:bricks
setblock 371 240 323 minecraft:stone_bricks
fill 371 240 324 371 240 335 minecraft:bricks
setblock 371 240 336 minecraft:stone_bricks
fill 371 240 337 371 240 346 minecraft:bricks
setblock 371 240 347 minecraft:stone_bricks
fill 371 240 348 371 245 348 minecraft:bricks
fill 371 240 353 371 240 355 minecraft:bricks
setblock 371 240 356 minecraft:stone_bricks
fill 371 240 357 371 308 357 minecraft:bricks
setblock 371 240 358 minecraft:stone_bricks
fill 371 240 359 371 240 363 minecraft:bricks
fill 329 241 322 329 308 322 minecraft:bricks
setblock 329 241 323 minecraft:stone_bricks
fill 329 241 324 329 245 331 minecraft:bricks
fill 329 241 352 329 245 356 minecraft:bricks
setblock 329 241 357 minecraft:stone_bricks
fill 329 241 358 329 308 359 minecraft:bricks
setblock 329 241 360 minecraft:stone_bricks
fill 329 241 361 329 245 364 minecraft:bricks
fill 330 241 323 332 272 323 minecraft:polished_andesite
fill 330 241 333 330 272 335 minecraft:polished_andesite
fill 330 241 345 330 272 347 minecraft:polished_andesite
fill 330 241 357 330 272 359 minecraft:polished_andesite
fill 331 241 322 331 308 322 minecraft:bricks
fill 331 241 332 331 245 334 minecraft:polished_andesite
fill 331 241 344 331 245 346 minecraft:polished_andesite
fill 331 241 356 331 245 358 minecraft:polished_andesite
fill 333 241 322 341 245 322 minecraft:bricks
fill 333 241 355 333 272 355 minecraft:iron_block
fill 335 241 364 337 308 364 minecraft:bricks
fill 336 241 363 338 272 363 minecraft:polished_andesite
fill 337 241 362 339 245 362 minecraft:polished_andesite
fill 338 241 364 340 241 364 minecraft:stone_bricks
fill 341 241 324 343 245 324 minecraft:polished_andesite
fill 341 241 364 342 245 364 minecraft:bricks
setblock 342 241 322 minecraft:stone_bricks
fill 342 241 323 344 241 323 minecraft:polished_andesite
fill 342 241 334 342 242 334 minecraft:gray_concrete
fill 342 241 336 342 242 336 minecraft:gray_concrete
fill 342 241 338 342 242 338 minecraft:gray_concrete
fill 342 241 340 342 242 340 minecraft:gray_concrete
fill 342 241 342 342 242 342 minecraft:gray_concrete
fill 342 241 344 342 242 344 minecraft:gray_concrete
fill 342 241 346 342 242 346 minecraft:gray_concrete
fill 343 241 322 344 308 322 minecraft:bricks
fill 343 241 333 343 242 333 minecraft:gray_concrete
fill 343 241 348 343 242 348 minecraft:gray_concrete
setblock 343 241 364 minecraft:stone_bricks
fill 344 241 364 344 245 364 minecraft:bricks
fill 345 241 333 345 242 333 minecraft:gray_concrete
fill 345 241 348 345 242 348 minecraft:gray_concrete
setblock 345 241 364 minecraft:stone_bricks
fill 346 241 323 347 243 323 minecraft:waxed_copper_block
fill 346 241 364 350 308 364 minecraft:bricks
fill 347 241 322 353 245 322 minecraft:bricks
fill 347 241 333 347 242 333 minecraft:gray_concrete
fill 347 241 348 347 242 348 minecraft:gray_concrete
fill 348 241 363 350 272 363 minecraft:polished_andesite
fill 349 241 323 349 247 323 minecraft:waxed_copper_block
fill 349 241 333 349 242 333 minecraft:gray_concrete
fill 349 241 348 349 242 348 minecraft:gray_concrete
fill 349 241 362 351 245 362 minecraft:polished_andesite
fill 351 241 333 351 242 333 minecraft:gray_concrete
fill 351 241 348 351 242 348 minecraft:gray_concrete
fill 353 241 324 356 242 324 minecraft:polished_andesite
fill 353 241 333 353 242 333 minecraft:gray_concrete
fill 353 241 348 353 242 348 minecraft:gray_concrete
setblock 354 241 322 minecraft:stone_bricks
fill 354 241 323 356 249 323 minecraft:polished_andesite
fill 355 241 322 361 245 322 minecraft:bricks
fill 355 241 333 355 242 333 minecraft:gray_concrete
fill 355 241 348 355 242 348 minecraft:gray_concrete
fill 356 241 325 356 242 332 minecraft:polished_andesite
fill 357 241 324 357 257 324 minecraft:iron_block
fill 357 241 326 357 241 332 minecraft:polished_andesite
fill 357 241 334 357 242 334 minecraft:gray_concrete
fill 357 241 336 357 242 336 minecraft:gray_concrete
fill 357 241 338 357 242 338 minecraft:gray_concrete
fill 357 241 340 357 242 340 minecraft:gray_concrete
fill 357 241 342 357 242 342 minecraft:gray_concrete
fill 357 241 344 357 242 344 minecraft:gray_concrete
fill 357 241 346 357 242 346 minecraft:gray_concrete
fill 357 241 349 358 241 359 minecraft:polished_andesite
fill 358 241 343 358 241 348 minecraft:polished_andesite
fill 358 241 360 358 241 363 minecraft:polished_andesite
fill 358 241 364 358 308 364 minecraft:bricks
fill 359 241 358 359 254 358 minecraft:iron_block
fill 360 241 363 362 272 363 minecraft:polished_andesite
fill 361 241 362 363 245 362 minecraft:polished_andesite
fill 364 241 326 364 241 328 minecraft:stone_bricks
fill 365 241 324 367 245 324 minecraft:polished_andesite
fill 365 241 326 367 272 328 minecraft:polished_andesite
setblock 365 241 329 minecraft:stone_bricks
fill 366 241 323 368 272 323 minecraft:polished_andesite
fill 366 241 325 367 241 325 minecraft:stone_bricks
fill 366 241 329 366 272 329 minecraft:polished_andesite
fill 367 241 329 368 241 329 minecraft:stone_bricks
fill 368 241 322 368 308 322 minecraft:bricks
fill 368 241 326 368 241 328 minecraft:stone_bricks
fill 369 241 332 369 245 334 minecraft:polished_andesite
fill 369 241 344 369 245 346 minecraft:polished_andesite
fill 369 241 356 369 245 358 minecraft:polished_andesite
fill 370 241 331 370 272 333 minecraft:polished_andesite
fill 370 241 343 370 272 345 minecraft:polished_andesite
fill 370 241 355 370 272 357 minecraft:polished_andesite
fill 371 241 323 371 245 328 minecraft:bricks
setblock 371 241 329 minecraft:stone_bricks
fill 371 241 330 371 308 333 minecraft:bricks
setblock 371 241 334 minecraft:stone_bricks
fill 371 241 335 371 245 342 minecraft:bricks
setblock 371 241 343 minecraft:stone_bricks
fill 371 241 344 371 245 347 minecraft:bricks
setblock 371 241 353 minecraft:stone_bricks
fill 371 241 354 371 308 354 minecraft:bricks
setblock 371 241 355 minecraft:stone_bricks
fill 371 241 356 371 308 356 minecraft:bricks
fill 371 241 358 371 308 358 minecraft:bricks
setblock 371 241 359 minecraft:stone_bricks
fill 371 241 360 371 245 360 minecraft:bricks
setblock 371 241 361 minecraft:stone_bricks
fill 371 241 362 371 245 363 minecraft:bricks
fill 329 242 323 329 308 323 minecraft:bricks
fill 329 242 357 329 308 357 minecraft:bricks
fill 329 242 360 329 308 360 minecraft:bricks
fill 338 242 364 340 308 364 minecraft:bricks
fill 342 242 322 342 308 322 minecraft:bricks
fill 342 242 323 343 242 323 minecraft:polished_andesite
fill 343 242 364 343 245 364 minecraft:bricks
fill 344 242 323 344 246 323 minecraft:waxed_copper_block
fill 345 242 364 345 308 364 minecraft:bricks
fill 348 242 323 348 244 323 minecraft:waxed_copper_block
setblock 350 242 323 minecraft:waxed_copper_block
fill 354 242 322 354 308 322 minecraft:bricks
fill 357 242 329 357 242 332 minecraft:polished_andesite
fill 357 242 349 357 242 352 minecraft:gold_block
fill 358 242 352 358 242 363 minecraft:gold_block
fill 367 242 329 368 248 329 minecraft:iron_block
fill 368 242 327 368 248 328 minecraft:iron_block
fill 371 242 329 371 308 329 minecraft:bricks
fill 371 242 334 371 308 334 minecraft:bricks
fill 371 242 343 371 308 343 minecraft:bricks
fill 371 242 349 371 245 349 minecraft:bricks
fill 371 242 353 371 308 353 minecraft:bricks
fill 371 242 355 371 308 355 minecraft:bricks
fill 371 242 359 371 245 359 minecraft:bricks
fill 371 242 361 371 245 361 minecraft:bricks
fill 332 243 354 332 243 356 minecraft:polished_andesite
fill 333 243 354 334 243 354 minecraft:polished_andesite
fill 333 243 356 334 243 356 minecraft:polished_andesite
setblock 334 243 355 minecraft:polished_andesite
fill 342 243 323 342 249 323 minecraft:polished_andesite
setblock 342 243 334 minecraft:black_stained_glass
setblock 342 243 336 minecraft:light_blue_stained_glass
setblock 342 243 338 minecraft:light_blue_stained_glass
setblock 342 243 340 minecraft:sea_lantern
setblock 342 243 342 minecraft:black_stained_glass
setblock 342 243 344 minecraft:black_stained_glass
setblock 342 243 346 minecraft:light_blue_stained_glass
setblock 343 243 323 minecraft:waxed_copper_block
setblock 343 243 333 minecraft:light_blue_stained_glass
setblock 343 243 348 minecraft:light_blue_stained_glass
fill 345 243 323 345 249 323 minecraft:waxed_copper_block
setblock 345 243 333 minecraft:light_blue_stained_glass
setblock 345 243 348 minecraft:light_blue_stained_glass
setblock 347 243 333 minecraft:light_blue_stained_glass
setblock 347 243 348 minecraft:sea_lantern
setblock 349 243 333 minecraft:light_blue_stained_glass
setblock 349 243 348 minecraft:sea_lantern
setblock 351 243 333 minecraft:black_stained_glass
setblock 351 243 348 minecraft:black_stained_glass
fill 353 243 324 355 245 324 minecraft:polished_andesite
setblock 353 243 333 minecraft:light_blue_stained_glass
setblock 353 243 348 minecraft:sea_lantern
setblock 355 243 333 minecraft:black_stained_glass
setblock 355 243 348 minecraft:black_stained_glass
fill 356 243 324 356 243 331 minecraft:gold_block
setblock 357 243 334 minecraft:black_stained_glass
setblock 357 243 336 minecraft:black_stained_glass
setblock 357 243 338 minecraft:sea_lantern
setblock 357 243 340 minecraft:black_stained_glass
setblock 357 243 342 minecraft:black_stained_glass
setblock 357 243 344 minecraft:light_blue_stained_glass
setblock 357 243 346 minecraft:black_stained_glass
setblock 365 243 329 minecraft:polished_andesite
fill 366 243 330 368 243 330 minecraft:polished_andesite
setblock 368 243 326 minecraft:polished_andesite
fill 369 243 327 369 243 329 minecraft:polished_andesite
setblock 332 244 325 minecraft:light[level=15]
setblock 332 244 332 minecraft:light[level=12]
setblock 332 244 333 minecraft:light[level=15]
setblock 332 244 339 minecraft:light[level=12]
setblock 332 244 341 minecraft:light[level=15]
setblock 332 244 346 minecraft:light[level=12]
setblock 332 244 349 minecraft:light[level=15]
setblock 332 244 353 minecraft:light[level=12]
setblock 332 244 357 minecraft:light[level=15]
setblock 332 244 360 minecraft:light[level=12]
setblock 339 244 325 minecraft:light[level=12]
setblock 339 244 332 minecraft:light[level=12]
setblock 339 244 339 minecraft:light[level=12]
setblock 339 244 346 minecraft:light[level=12]
setblock 339 244 353 minecraft:light[level=12]
setblock 339 244 360 minecraft:light[level=12]
setblock 340 244 325 minecraft:light[level=15]
setblock 340 244 333 minecraft:light[level=15]
setblock 340 244 341 minecraft:light[level=15]
setblock 340 244 349 minecraft:light[level=15]
setblock 340 244 357 minecraft:light[level=15]
fill 342 244 334 342 245 334 minecraft:gray_concrete
fill 342 244 336 342 245 336 minecraft:gray_concrete
fill 342 244 338 342 245 338 minecraft:gray_concrete
fill 342 244 340 342 245 340 minecraft:gray_concrete
fill 342 244 342 342 245 342 minecraft:gray_concrete
fill 342 244 344 342 245 344 minecraft:gray_concrete
fill 342 244 346 342 245 346 minecraft:gray_concrete
setblock 343 244 323 minecraft:polished_andesite
fill 343 244 333 343 245 333 minecraft:gray_concrete
fill 343 244 348 343 245 348 minecraft:gray_concrete
fill 345 244 333 345 245 333 minecraft:gray_concrete
fill 345 244 348 345 245 348 minecraft:gray_concrete
setblock 346 244 323 minecraft:waxed_copper_block
setblock 346 244 325 minecraft:light[level=12]
setblock 346 244 332 minecraft:light[level=12]
setblock 346 244 353 minecraft:light[level=12]
setblock 346 244 360 minecraft:light[level=12]
fill 347 244 333 347 245 333 minecraft:gray_concrete
fill 347 244 348 347 245 348 minecraft:gray_concrete
setblock 348 244 325 minecraft:light[level=15]
setblock 348 244 349 minecraft:light[level=15]
setblock 348 244 357 minecraft:light[level=15]
fill 349 244 333 349 245 333 minecraft:gray_concrete
fill 349 244 348 349 245 348 minecraft:gray_concrete
fill 350 244 323 351 245 323 minecraft:waxed_copper_block
fill 351 244 333 351 245 333 minecraft:gray_concrete
fill 351 244 348 351 245 348 minecraft:gray_concrete
setblock 353 244 325 minecraft:light[level=12]
setblock 353 244 332 minecraft:light[level=12]
fill 353 244 333 353 245 333 minecraft:gray_concrete
fill 353 244 348 353 245 348 minecraft:gray_concrete
setblock 353 244 353 minecraft:light[level=12]
setblock 353 244 360 minecraft:light[level=12]
fill 355 244 333 355 245 333 minecraft:gray_concrete
fill 355 244 348 355 245 348 minecraft:gray_concrete
setblock 356 244 325 minecraft:light[level=15]
setblock 356 244 349 minecraft:light[level=15]
setblock 356 244 357 minecraft:light[level=15]
fill 357 244 334 357 245 334 minecraft:gray_concrete
fill 357 244 336 357 245 336 minecraft:gray_concrete
fill 357 244 338 357 245 338 minecraft:gray_concrete
fill 357 244 340 357 245 340 minecraft:gray_concrete
fill 357 244 342 357 245 342 minecraft:gray_concrete
fill 357 244 344 357 245 344 minecraft:gray_concrete
fill 357 244 346 357 245 346 minecraft:gray_concrete
setblock 360 244 325 minecraft:light[level=12]
setblock 360 244 332 minecraft:light[level=12]
setblock 360 244 339 minecraft:light[level=12]
setblock 360 244 346 minecraft:light[level=12]
setblock 360 244 353 minecraft:light[level=12]
setblock 360 244 360 minecraft:light[level=12]
setblock 364 244 325 minecraft:light[level=15]
setblock 364 244 333 minecraft:light[level=15]
setblock 364 244 341 minecraft:light[level=15]
setblock 364 244 349 minecraft:light[level=15]
setblock 364 244 357 minecraft:light[level=15]
setblock 367 244 325 minecraft:light[level=12]
setblock 367 244 332 minecraft:light[level=12]
setblock 367 244 339 minecraft:light[level=12]
setblock 367 244 346 minecraft:light[level=12]
setblock 367 244 353 minecraft:light[level=12]
setblock 367 244 360 minecraft:light[level=12]
fill 330 245 326 330 245 331 minecraft:stone_bricks
fill 330 245 338 330 245 343 minecraft:stone_bricks
fill 330 245 350 330 245 355 minecraft:stone_bricks
fill 330 245 362 330 245 363 minecraft:stone_bricks
fill 331 245 363 334 245 363 minecraft:stone_bricks
fill 334 245 323 339 245 323 minecraft:stone_bricks
fill 341 245 363 346 245 363 minecraft:stone_bricks
fill 343 245 323 343 246 323 minecraft:waxed_copper_block
fill 346 245 323 348 245 323 minecraft:stone_bricks
fill 353 245 363 358 245 363 minecraft:stone_bricks
fill 358 245 323 363 245 323 minecraft:stone_bricks
fill 365 245 363 370 245 363 minecraft:stone_bricks
fill 370 245 323 370 245 328 minecraft:stone_bricks
fill 370 245 335 370 245 340 minecraft:stone_bricks
fill 370 245 347 370 245 352 minecraft:stone_bricks
fill 370 245 359 370 245 362 minecraft:stone_bricks
fill 329 246 324 329 308 327 minecraft:bricks
fill 329 246 328 329 251 331 minecraft:ochre_froglight
fill 329 246 336 329 308 339 minecraft:bricks
fill 329 246 340 329 251 343 minecraft:ochre_froglight
fill 329 246 344 329 308 345 minecraft:bricks
fill 329 246 352 329 251 355 minecraft:ochre_froglight
fill 329 246 356 329 308 356 minecraft:bricks
fill 329 246 361 329 308 363 minecraft:bricks
fill 329 246 364 332 251 364 minecraft:ochre_froglight
fill 333 246 322 335 308 322 minecraft:bricks
fill 333 246 364 334 308 364 minecraft:bricks
fill 336 246 322 339 251 322 minecraft:ochre_froglight
fill 340 246 322 341 308 322 minecraft:bricks
fill 341 246 364 344 251 364 minecraft:ochre_froglight
setblock 342 246 334 minecraft:light_blue_stained_glass
setblock 342 246 336 minecraft:light_blue_stained_glass
setblock 342 246 338 minecraft:black_stained_glass
setblock 342 246 340 minecraft:sea_lantern
setblock 342 246 342 minecraft:sea_lantern
setblock 342 246 344 minecraft:black_stained_glass
setblock 342 246 346 minecraft:sea_lantern
setblock 343 246 333 minecraft:black_stained_glass
setblock 343 246 348 minecraft:sea_lantern
setblock 345 246 333 minecraft:sea_lantern
setblock 345 246 348 minecraft:black_stained_glass
fill 346 246 323 346 248 323 minecraft:waxed_copper_block
fill 347 246 322 347 308 322 minecraft:bricks
setblock 347 246 333 minecraft:light_blue_stained_glass
setblock 347 246 348 minecraft:black_stained_glass
fill 348 246 322 351 251 322 minecraft:ochre_froglight
fill 348 246 323 348 249 323 minecraft:waxed_copper_block
setblock 349 246 333 minecraft:black_stained_glass
setblock 349 246 348 minecraft:black_stained_glass
fill 350 246 323 350 248 323 minecraft:waxed_copper_block
setblock 351 246 333 minecraft:light_blue_stained_glass
setblock 351 246 348 minecraft:black_stained_glass
fill 351 246 364 352 308 364 minecraft:bricks
fill 352 246 322 353 308 322 minecraft:bricks
setblock 353 246 333 minecraft:light_blue_stained_glass
setblock 353 246 348 minecraft:light_blue_stained_glass
fill 353 246 364 356 251 364 minecraft:ochre_froglight
fill 355 246 322 359 308 322 minecraft:bricks
setblock 355 246 333 minecraft:light_blue_stained_glass
setblock 355 246 348 minecraft:black_stained_glass
setblock 357 246 334 minecraft:light_blue_stained_glass
setblock 357 246 336 minecraft:black_stained_glass
setblock 357 246 338 minecraft:sea_lantern
setblock 357 246 340 minecraft:black_stained_glass
setblock 357 246 342 minecraft:light_blue_stained_glass
setblock 357 246 344 minecraft:sea_lantern
setblock 357 246 346 minecraft:black_stained_glass
fill 357 246 364 357 308 364 minecraft:bricks
fill 359 246 364 364 308 364 minecraft:bricks
fill 360 246 322 363 251 322 minecraft:ochre_froglight
fill 364 246 322 367 308 322 minecraft:bricks
fill 365 246 364 368 251 364 minecraft:ochre_froglight
fill 369 246 364 371 308 364 minecraft:bricks
fill 371 246 323 371 251 326 minecraft:ochre_froglight
fill 371 246 327 371 308 328 minecraft:bricks
fill 371 246 335 371 251 338 minecraft:ochre_froglight
fill 371 246 339 371 308 342 minecraft:bricks
fill 371 246 344 371 308 346 minecraft:bricks
fill 371 246 347 371 251 350 minecraft:ochre_froglight
fill 371 246 351 371 308 352 minecraft:bricks
fill 371 246 359 371 251 362 minecraft:ochre_froglight
fill 371 246 363 371 308 363 minecraft:bricks
fill 342 247 334 342 248 334 minecraft:gray_concrete
fill 342 247 336 342 248 336 minecraft:gray_concrete
fill 342 247 338 342 248 338 minecraft:gray_concrete
fill 342 247 340 342 248 340 minecraft:gray_concrete
fill 342 247 342 342 248 342 minecraft:gray_concrete
fill 342 247 344 342 248 344 minecraft:gray_concrete
fill 342 247 346 342 248 346 minecraft:gray_concrete
fill 343 247 323 344 247 323 minecraft:polished_andesite
fill 343 247 333 343 248 333 minecraft:gray_concrete
fill 343 247 348 343 248 348 minecraft:gray_concrete
fill 345 247 333 345 248 333 minecraft:gray_concrete
fill 345 247 348 345 248 348 minecraft:gray_concrete
fill 347 247 323 347 249 323 minecraft:waxed_copper_block
fill 347 247 333 347 248 333 minecraft:gray_concrete
fill 347 247 348 347 248 348 minecraft:gray_concrete
fill 349 247 333 349 248 333 minecraft:gray_concrete
fill 349 247 348 349 248 348 minecraft:gray_concrete
setblock 351 247 323 minecraft:waxed_copper_block
fill 351 247 333 351 248 333 minecraft:gray_concrete
fill 351 247 348 351 248 348 minecraft:gray_concrete
fill 353 247 333 353 248 333 minecraft:gray_concrete
fill 353 247 348 353 248 348 minecraft:gray_concrete
fill 355 247 333 355 248 333 minecraft:gray_concrete
fill 355 247 348 355 248 348 minecraft:gray_concrete
fill 357 247 334 357 248 334 minecraft:gray_concrete
fill 357 247 336 357 248 336 minecraft:gray_concrete
fill 357 247 338 357 248 338 minecraft:gray_concrete
fill 357 247 340 357 248 340 minecraft:gray_concrete
fill 357 247 342 357 248 342 minecraft:gray_concrete
fill 357 247 344 357 248 344 minecraft:gray_concrete
fill 357 247 346 357 248 346 minecraft:gray_concrete
fill 332 248 354 332 248 356 minecraft:polished_andesite
fill 333 248 354 334 248 354 minecraft:polished_andesite
fill 333 248 356 334 248 356 minecraft:polished_andesite
setblock 334 248 355 minecraft:polished_andesite
fill 343 248 323 343 251 323 minecraft:polished_andesite
setblock 344 248 323 minecraft:waxed_copper_block
fill 330 249 355 332 250 355 minecraft:iron_block
fill 338 249 323 339 251 323 minecraft:waxed_copper_block
fill 341 249 323 341 255 323 minecraft:waxed_copper_block
setblock 342 249 334 minecraft:light_blue_stained_glass
setblock 342 249 336 minecraft:black_stained_glass
setblock 342 249 338 minecraft:black_stained_glass
setblock 342 249 340 minecraft:sea_lantern
setblock 342 249 342 minecraft:sea_lantern
setblock 342 249 344 minecraft:black_stained_glass
setblock 342 249 346 minecraft:sea_lantern
setblock 343 249 333 minecraft:sea_lantern
setblock 343 249 348 minecraft:light_blue_stained_glass
fill 344 249 323 344 272 323 minecraft:polished_andesite
setblock 345 249 333 minecraft:light_blue_stained_glass
setblock 345 249 348 minecraft:sea_lantern
setblock 347 249 333 minecraft:sea_lantern
setblock 347 249 348 minecraft:black_stained_glass
setblock 349 249 333 minecraft:black_stained_glass
setblock 349 249 348 minecraft:sea_lantern
setblock 351 249 333 minecraft:black_stained_glass
setblock 351 249 348 minecraft:light_blue_stained_glass
setblock 353 249 333 minecraft:black_stained_glass
setblock 353 249 348 minecraft:sea_lantern
setblock 355 249 333 minecraft:black_stained_glass
setblock 355 249 348 minecraft:sea_lantern
setblock 357 249 334 minecraft:black_stained_glass
setblock 357 249 336 minecraft:black_stained_glass
setblock 357 249 338 minecraft:black_stained_glass
setblock 357 249 340 minecraft:black_stained_glass
setblock 357 249 342 minecraft:black_stained_glass
setblock 357 249 344 minecraft:black_stained_glass
setblock 357 249 346 minecraft:black_stained_glass
fill 364 249 326 364 249 328 minecraft:stone_bricks
setblock 365 249 329 minecraft:stone_bricks
fill 366 249 325 367 249 325 minecraft:stone_bricks
fill 367 249 329 368 249 329 minecraft:stone_bricks
fill 368 249 326 368 249 328 minecraft:stone_bricks
setblock 332 250 325 minecraft:light[level=12]
setblock 332 250 332 minecraft:light[level=12]
setblock 332 250 339 minecraft:light[level=12]
setblock 332 250 346 minecraft:light[level=12]
setblock 332 250 353 minecraft:light[level=12]
setblock 332 250 360 minecraft:light[level=12]
fill 334 250 332 334 251 341 minecraft:polished_andesite
setblock 334 250 355 minecraft:ochre_froglight
fill 335 250 323 335 250 334 minecraft:polished_andesite
fill 336 250 323 336 254 323 minecraft:waxed_copper_block
fill 336 250 324 336 251 326 minecraft:polished_andesite
setblock 339 250 325 minecraft:light[level=12]
setblock 339 250 332 minecraft:light[level=12]
setblock 339 250 339 minecraft:light[level=12]
setblock 339 250 346 minecraft:light[level=12]
setblock 339 250 353 minecraft:light[level=12]
setblock 339 250 360 minecraft:light[level=12]
fill 340 250 323 340 252 323 minecraft:waxed_copper_block
setblock 342 250 323 minecraft:waxed_copper_block
fill 342 250 334 342 253 334 minecraft:gray_concrete
fill 342 250 336 342 253 336 minecraft:gray_concrete
fill 342 250 338 342 253 338 minecraft:gray_concrete
fill 342 250 340 342 253 340 minecraft:gray_concrete
fill 342 250 342 342 253 342 minecraft:gray_concrete
fill 342 250 344 342 253 344 minecraft:gray_concrete
fill 342 250 346 342 253 346 minecraft:gray_concrete
fill 343 250 333 343 252 333 minecraft:gray_concrete
fill 343 250 348 343 253 348 minecraft:gray_concrete
fill 345 250 333 345 252 333 minecraft:gray_concrete
fill 345 250 348 345 253 348 minecraft:gray_concrete
setblock 346 250 325 minecraft:light[level=12]
setblock 346 250 332 minecraft:light[level=12]
setblock 346 250 353 minecraft:light[level=12]
setblock 346 250 360 minecraft:light[level=12]
fill 347 250 333 347 252 333 minecraft:gray_concrete
fill 347 250 348 347 253 348 minecraft:gray_concrete
fill 349 250 333 349 252 333 minecraft:gray_concrete
fill 349 250 348 349 253 348 minecraft:gray_concrete
fill 351 250 323 352 252 323 minecraft:waxed_copper_block
fill 351 250 333 351 252 333 minecraft:gray_concrete
fill 351 250 348 351 253 348 minecraft:gray_concrete
setblock 353 250 325 minecraft:light[level=12]
setblock 353 250 332 minecraft:light[level=12]
fill 353 250 333 353 252 333 minecraft:gray_concrete
fill 353 250 348 353 253 348 minecraft:gray_concrete
setblock 353 250 353 minecraft:light[level=12]
setblock 353 250 360 minecraft:light[level=12]
fill 354 250 323 354 256 323 minecraft:waxed_copper_block
fill 355 250 323 356 250 323 minecraft:polished_andesite
fill 355 250 333 355 252 333 minecraft:gray_concrete
fill 355 250 348 355 253 348 minecraft:gray_concrete
fill 357 250 334 357 253 334 minecraft:gray_concrete
fill 357 250 336 357 253 336 minecraft:gray_concrete
fill 357 250 338 357 253 338 minecraft:gray_concrete
fill 357 250 340 357 253 340 minecraft:gray_concrete
fill 357 250 342 357 253 342 minecraft:gray_concrete
fill 357 250 344 357 253 344 minecraft:gray_concrete
fill 357 250 346 357 253 346 minecraft:gray_concrete
setblock 360 250 325 minecraft:light[level=12]
setblock 360 250 332 minecraft:light[level=12]
setblock 360 250 339 minecraft:light[level=12]
setblock 360 250 346 minecraft:light[level=12]
setblock 360 250 353 minecraft:light[level=12]
setblock 360 250 360 minecraft:light[level=12]
setblock 365 250 329 minecraft:polished_andesite
fill 366 250 330 368 250 330 minecraft:polished_andesite
setblock 367 250 325 minecraft:light[level=12]
fill 367 250 329 368 256 329 minecraft:iron_block
setblock 367 250 332 minecraft:light[level=12]
setblock 367 250 339 minecraft:light[level=12]
setblock 367 250 346 minecraft:light[level=12]
setblock 367 250 353 minecraft:light[level=12]
setblock 367 250 360 minecraft:light[level=12]
setblock 368 250 326 minecraft:polished_andesite
fill 368 250 327 368 256 328 minecraft:iron_block
fill 369 250 327 369 250 329 minecraft:polished_andesite
fill 332 251 352 332 251 363 minecraft:polished_andesite
fill 333 251 340 333 251 354 minecraft:polished_andesite
fill 333 251 356 333 251 361 minecraft:polished_andesite
fill 334 251 329 335 251 331 minecraft:polished_andesite
fill 334 251 342 334 251 350 minecraft:polished_andesite
setblock 335 251 323 minecraft:waxed_copper_block
fill 335 251 324 335 251 328 minecraft:polished_andesite
fill 335 251 332 335 251 339 minecraft:polished_andesite
setblock 336 251 327 minecraft:polished_andesite
fill 337 251 323 337 257 323 minecraft:waxed_copper_block
fill 340 251 356 344 252 360 minecraft:stone_bricks
setblock 342 251 323 minecraft:polished_andesite
fill 342 251 361 342 251 362 minecraft:stone_bricks
fill 349 251 323 349 255 323 minecraft:waxed_copper_block
fill 353 251 323 353 253 323 minecraft:waxed_copper_block
setblock 355 251 323 minecraft:waxed_copper_block
fill 356 251 323 356 252 323 minecraft:polished_andesite
fill 364 251 325 364 261 325 minecraft:iron_block
fill 329 252 328 329 265 328 minecraft:bricks
fill 329 252 329 329 252 330 minecraft:ochre_froglight
fill 329 252 331 329 265 331 minecraft:bricks
fill 329 252 340 329 265 340 minecraft:bricks
fill 329 252 341 329 252 342 minecraft:ochre_froglight
fill 329 252 343 329 265 343 minecraft:bricks
fill 329 252 352 329 265 352 minecraft:bricks
fill 329 252 353 329 252 354 minecraft:ochre_froglight
fill 329 252 355 329 265 355 minecraft:bricks
fill 329 252 364 329 265 364 minecraft:bricks
fill 330 252 364 331 252 364 minecraft:ochre_froglight
setblock 332 252 325 minecraft:light[level=15]
setblock 332 252 333 minecraft:light[level=15]
setblock 332 252 341 minecraft:light[level=15]
setblock 332 252 349 minecraft:light[level=15]
fill 332 252 355 332 252 363 minecraft:polished_andesite
fill 332 252 364 332 265 364 minecraft:bricks
fill 333 252 347 333 252 354 minecraft:polished_andesite
fill 333 252 356 333 252 360 minecraft:polished_andesite
fill 334 252 334 334 252 343 minecraft:gold_block
fill 335 252 323 335 252 334 minecraft:gold_block
fill 336 252 322 336 265 322 minecraft:bricks
fill 337 252 322 338 252 322 minecraft:ochre_froglight
setblock 338 252 323 minecraft:waxed_copper_block
fill 339 252 322 339 265 322 minecraft:bricks
setblock 340 252 325 minecraft:light[level=15]
setblock 340 252 333 minecraft:light[level=15]
setblock 340 252 341 minecraft:light[level=15]
setblock 340 252 349 minecraft:light[level=15]
fill 341 252 364 341 265 364 minecraft:bricks
fill 342 252 323 343 253 323 minecraft:waxed_copper_block
fill 342 252 364 343 252 364 minecraft:ochre_froglight
fill 344 252 364 344 265 364 minecraft:bricks
fill 348 252 322 348 265 322 minecraft:bricks
setblock 348 252 323 minecraft:waxed_copper_block
setblock 348 252 325 minecraft:light[level=15]
setblock 348 252 349 minecraft:light[level=15]
setblock 348 252 357 minecraft:light[level=15]
fill 349 252 322 350 252 322 minecraft:ochre_froglight
fill 350 252 323 350 258 323 minecraft:waxed_copper_block
fill 351 252 322 351 265 322 minecraft:bricks
fill 353 252 364 353 265 364 minecraft:bricks
fill 354 252 364 355 252 364 minecraft:ochre_froglight
setblock 355 252 323 minecraft:polished_andesite
setblock 356 252 325 minecraft:light[level=15]
setblock 356 252 349 minecraft:light[level=15]
setblock 356 252 357 minecraft:light[level=15]
fill 356 252 364 356 265 364 minecraft:bricks
fill 360 252 322 360 265 322 minecraft:bricks
fill 361 252 322 362 252 322 minecraft:ochre_froglight
fill 363 252 322 363 265 322 minecraft:bricks
setblock 364 252 333 minecraft:light[level=15]
setblock 364 252 341 minecraft:light[level=15]
setblock 364 252 349 minecraft:light[level=15]
setblock 364 252 357 minecraft:light[level=15]
fill 365 252 364 365 265 364 minecraft:bricks
fill 366 252 364 367 252 364 minecraft:ochre_froglight
fill 368 252 364 368 265 364 minecraft:bricks
fill 369 252 327 370 253 329 minecraft:iron_block
fill 371 252 323 371 265 323 minecraft:bricks
fill 371 252 324 371 252 325 minecraft:ochre_froglight
fill 371 252 326 371 265 326 minecraft:bricks
fill 371 252 335 371 265 335 minecraft:bricks
fill 371 252 336 371 252 337 minecraft:ochre_froglight
fill 371 252 338 371 265 338 minecraft:bricks
fill 371 252 347 371 265 347 minecraft:bricks
fill 371 252 348 371 252 349 minecraft:ochre_froglight
fill 371 252 350 371 265 350 minecraft:bricks
fill 371 252 359 371 265 359 minecraft:bricks
fill 371 252 360 371 252 361 minecraft:ochre_froglight
fill 371 252 362 371 265 362 minecraft:bricks
fill 329 253 329 329 265 330 minecraft:bricks
fill 329 253 341 329 265 342 minecraft:bricks
fill 329 253 353 329 265 354 minecraft:bricks
fill 330 253 364 331 265 364 minecraft:bricks
fill 332 253 354 332 253 356 minecraft:polished_andesite
fill 332 253 357 332 253 363 minecraft:gold_block
fill 333 253 348 333 253 353 minecraft:gold_block
fill 333 253 354 334 253 354 minecraft:polished_andesite
fill 333 253 356 334 253 356 minecraft:polished_andesite
setblock 334 253 355 minecraft:polished_andesite
fill 335 253 323 335 254 323 minecraft:waxed_copper_block
fill 337 253 322 338 265 322 minecraft:bricks
fill 342 253 333 357 253 333 minecraft:yellow_concrete
fill 342 253 364 343 265 364 minecraft:bricks
fill 349 253 322 350 265 322 minecraft:bricks
setblock 351 253 323 minecraft:waxed_copper_block
fill 354 253 364 355 265 364 minecraft:bricks
fill 355 253 323 356 254 323 minecraft:waxed_copper_block
fill 361 253 322 362 265 322 minecraft:bricks
fill 366 253 364 367 265 364 minecraft:bricks
fill 371 253 324 371 265 325 minecraft:bricks
fill 371 253 336 371 265 337 minecraft:bricks
fill 371 253 348 371 265 349 minecraft:bricks
fill 371 253 360 371 265 361 minecraft:bricks
fill 338 254 323 338 256 323 minecraft:waxed_copper_block
fill 340 254 323 340 257 323 minecraft:waxed_copper_block
fill 342 254 323 342 256 323 minecraft:waxed_copper_block
setblock 343 254 323 minecraft:polished_andesite
fill 348 254 323 348 255 323 minecraft:waxed_copper_block
fill 339 255 323 339 257 323 minecraft:waxed_copper_block
setblock 343 255 323 minecraft:waxed_copper_block
fill 351 255 323 351 257 323 minecraft:waxed_copper_block
fill 353 255 323 353 258 323 minecraft:waxed_copper_block
fill 355 255 323 355 257 323 minecraft:waxed_copper_block
setblock 356 255 323 minecraft:polished_andesite
setblock 332 256 325 minecraft:light[level=12]
setblock 332 256 332 minecraft:light[level=12]
setblock 332 256 339 minecraft:light[level=12]
setblock 332 256 346 minecraft:light[level=12]
setblock 332 256 353 minecraft:light[level=12]
setblock 332 256 360 minecraft:light[level=12]
setblock 336 256 323 minecraft:waxed_copper_block
setblock 339 256 325 minecraft:light[level=12]
setblock 339 256 332 minecraft:light[level=12]
setblock 339 256 339 minecraft:light[level=12]
setblock 339 256 346 minecraft:light[level=12]
setblock 339 256 353 minecraft:light[level=12]
fill 339 256 356 339 257 360 minecraft:iron_block
fill 340 256 355 340 257 356 minecraft:iron_block
fill 340 256 358 344 257 358 minecraft:polished_andesite
fill 340 256 360 340 257 361 minecraft:iron_block
fill 341 256 355 344 257 355 minecraft:iron_block
fill 341 256 361 344 257 361 minecraft:iron_block
fill 342 256 356 342 257 357 minecraft:polished_andesite
fill 342 256 359 342 257 360 minecraft:polished_andesite
fill 343 256 323 343 272 323 minecraft:polished_andesite
fill 344 256 356 345 257 356 minecraft:iron_block
fill 344 256 360 345 257 360 minecraft:iron_block
fill 345 256 357 345 257 359 minecraft:iron_block
setblock 346 256 325 minecraft:light[level=12]
setblock 346 256 332 minecraft:light[level=12]
setblock 346 256 339 minecraft:light[level=12]
setblock 346 256 346 minecraft:light[level=12]
setblock 346 256 353 minecraft:light[level=12]
setblock 346 256 360 minecraft:light[level=12]
fill 352 256 323 352 258 323 minecraft:waxed_copper_block
setblock 353 256 325 minecraft:light[level=12]
setblock 353 256 332 minecraft:light[level=12]
setblock 353 256 339 minecraft:light[level=12]
setblock 353 256 346 minecraft:light[level=12]
setblock 353 256 353 minecraft:light[level=12]
setblock 353 256 360 minecraft:light[level=12]
setblock 356 256 323 minecraft:waxed_copper_block
setblock 360 256 325 minecraft:light[level=12]
setblock 360 256 332 minecraft:light[level=12]
setblock 360 256 339 minecraft:light[level=12]
setblock 360 256 346 minecraft:light[level=12]
setblock 360 256 353 minecraft:light[level=12]
setblock 360 256 360 minecraft:light[level=12]
setblock 367 256 325 minecraft:light[level=12]
setblock 367 256 332 minecraft:light[level=12]
setblock 367 256 339 minecraft:light[level=12]
setblock 367 256 346 minecraft:light[level=12]
setblock 367 256 353 minecraft:light[level=12]
setblock 367 256 360 minecraft:light[level=12]
fill 342 257 323 342 272 323 minecraft:polished_andesite
setblock 349 257 323 minecraft:waxed_copper_block
fill 354 257 323 354 272 323 minecraft:polished_andesite
fill 356 257 323 356 272 323 minecraft:polished_andesite
fill 364 257 326 364 257 328 minecraft:stone_bricks
setblock 365 257 329 minecraft:stone_bricks
fill 366 257 325 367 257 325 minecraft:stone_bricks
fill 366 257 330 368 257 330 minecraft:polished_andesite
fill 367 257 329 368 257 329 minecraft:stone_bricks
fill 368 257 326 368 257 328 minecraft:stone_bricks
fill 369 257 327 369 257 329 minecraft:polished_andesite
fill 332 258 354 332 258 356 minecraft:polished_andesite
fill 333 258 354 334 258 354 minecraft:polished_andesite
fill 333 258 356 334 258 356 minecraft:polished_andesite
setblock 334 258 355 minecraft:polished_andesite
fill 355 258 323 355 272 323 minecraft:polished_andesite
fill 367 258 329 368 264 329 minecraft:iron_block
fill 368 258 327 368 264 328 minecraft:iron_block
fill 331 260 332 331 265 334 minecraft:polished_andesite
fill 331 260 344 331 265 346 minecraft:polished_andesite
fill 331 260 356 331 265 358 minecraft:polished_andesite
setblock 332 260 325 minecraft:light[level=15]
setblock 332 260 333 minecraft:light[level=15]
setblock 332 260 341 minecraft:light[level=15]
setblock 332 260 349 minecraft:light[level=15]
setblock 332 260 357 minecraft:light[level=15]
fill 337 260 362 339 265 362 minecraft:polished_andesite
setblock 340 260 325 minecraft:light[level=15]
setblock 340 260 333 minecraft:light[level=15]
setblock 340 260 341 minecraft:light[level=15]
setblock 340 260 349 minecraft:light[level=15]
setblock 340 260 357 minecraft:light[level=15]
fill 341 260 324 343 265 324 minecraft:polished_andesite
setblock 348 260 325 minecraft:light[level=15]
setblock 348 260 333 minecraft:light[level=15]
setblock 348 260 341 minecraft:light[level=15]
setblock 348 260 349 minecraft:light[level=15]
setblock 348 260 357 minecraft:light[level=15]
fill 349 260 362 351 265 362 minecraft:polished_andesite
fill 353 260 324 355 265 324 minecraft:polished_andesite
setblock 356 260 325 minecraft:light[level=15]
setblock 356 260 333 minecraft:light[level=15]
setblock 356 260 341 minecraft:light[level=15]
setblock 356 260 349 minecraft:light[level=15]
setblock 356 260 357 minecraft:light[level=15]
fill 361 260 362 363 265 362 minecraft:polished_andesite
setblock 364 260 333 minecraft:light[level=15]
setblock 364 260 341 minecraft:light[level=15]
setblock 364 260 349 minecraft:light[level=15]
setblock 364 260 357 minecraft:light[level=15]
fill 365 260 324 367 265 324 minecraft:polished_andesite
fill 369 260 332 369 265 334 minecraft:polished_andesite
fill 369 260 344 369 265 346 minecraft:polished_andesite
fill 369 260 356 369 265 358 minecraft:polished_andesite
setblock 332 262 325 minecraft:light[level=12]
setblock 332 262 332 minecraft:light[level=12]
setblock 332 262 339 minecraft:light[level=12]
setblock 332 262 346 minecraft:light[level=12]
setblock 332 262 353 minecraft:light[level=12]
setblock 332 262 360 minecraft:light[level=12]
setblock 339 262 325 minecraft:light[level=12]
setblock 339 262 332 minecraft:light[level=12]
setblock 339 262 339 minecraft:light[level=12]
setblock 339 262 346 minecraft:light[level=12]
setblock 339 262 353 minecraft:light[level=12]
setblock 339 262 360 minecraft:light[level=12]
setblock 346 262 325 minecraft:light[level=12]
setblock 346 262 332 minecraft:light[level=12]
setblock 346 262 339 minecraft:light[level=12]
setblock 346 262 346 minecraft:light[level=12]
setblock 346 262 353 minecraft:light[level=12]
setblock 346 262 360 minecraft:light[level=12]
setblock 353 262 325 minecraft:light[level=12]
setblock 353 262 332 minecraft:light[level=12]
setblock 353 262 339 minecraft:light[level=12]
setblock 353 262 346 minecraft:light[level=12]
setblock 353 262 353 minecraft:light[level=12]
setblock 353 262 360 minecraft:light[level=12]
setblock 360 262 325 minecraft:light[level=12]
setblock 360 262 332 minecraft:light[level=12]
setblock 360 262 339 minecraft:light[level=12]
setblock 360 262 346 minecraft:light[level=12]
setblock 360 262 353 minecraft:light[level=12]
setblock 360 262 360 minecraft:light[level=12]
setblock 367 262 325 minecraft:light[level=12]
setblock 367 262 332 minecraft:light[level=12]
setblock 367 262 339 minecraft:light[level=12]
setblock 367 262 346 minecraft:light[level=12]
setblock 367 262 353 minecraft:light[level=12]
setblock 367 262 360 minecraft:light[level=12]
fill 332 263 354 332 263 356 minecraft:polished_andesite
fill 333 263 354 334 263 354 minecraft:polished_andesite
fill 333 263 356 334 263 356 minecraft:polished_andesite
setblock 334 263 355 minecraft:polished_andesite
fill 341 264 323 341 265 323 minecraft:polished_andesite
fill 342 264 325 342 265 331 minecraft:polished_andesite
fill 343 264 327 343 265 339 minecraft:polished_andesite
fill 344 264 334 344 265 341 minecraft:polished_andesite
fill 344 264 345 344 265 346 minecraft:polished_andesite
fill 345 264 346 345 265 354 minecraft:polished_andesite
fill 346 264 349 346 265 361 minecraft:polished_andesite
fill 347 264 357 347 265 363 minecraft:polished_andesite
fill 363 264 340 367 265 344 minecraft:stone_bricks
setblock 365 264 329 minecraft:polished_andesite
fill 366 264 330 368 264 330 minecraft:polished_andesite
setblock 368 264 326 minecraft:polished_andesite
fill 368 264 342 369 264 342 minecraft:stone_bricks
fill 369 264 327 369 264 329 minecraft:polished_andesite
fill 330 265 326 330 265 331 minecraft:stone_bricks
fill 330 265 338 330 265 343 minecraft:stone_bricks
fill 330 265 350 330 265 355 minecraft:stone_bricks
fill 330 265 362 330 265 363 minecraft:stone_bricks
fill 331 265 363 334 265 363 minecraft:stone_bricks
fill 334 265 323 339 265 323 minecraft:stone_bricks
fill 341 265 363 346 265 363 minecraft:stone_bricks
fill 346 265 323 351 265 323 minecraft:stone_bricks
fill 353 265 363 358 265 363 minecraft:stone_bricks
fill 358 265 323 363 265 323 minecraft:stone_bricks
fill 364 265 326 364 265 328 minecraft:stone_bricks
setblock 365 265 329 minecraft:stone_bricks
fill 365 265 363 370 265 363 minecraft:stone_bricks
fill 366 265 325 367 265 325 minecraft:stone_bricks
fill 367 265 329 368 265 329 minecraft:stone_bricks
fill 368 265 326 368 265 328 minecraft:stone_bricks
fill 370 265 323 370 265 328 minecraft:stone_bricks
fill 370 265 335 370 265 340 minecraft:stone_bricks
fill 370 265 347 370 265 352 minecraft:stone_bricks
fill 370 265 359 370 265 362 minecraft:stone_bricks
fill 329 266 328 329 271 331 minecraft:ochre_froglight
fill 329 266 340 329 271 343 minecraft:ochre_froglight
fill 329 266 352 329 271 355 minecraft:ochre_froglight
fill 329 266 364 332 271 364 minecraft:ochre_froglight
fill 336 266 322 339 271 322 minecraft:ochre_froglight
fill 341 266 364 344 271 364 minecraft:ochre_froglight
fill 342 266 324 342 266 329 minecraft:gold_block
fill 343 266 329 343 266 336 minecraft:gold_block
fill 344 266 337 344 266 340 minecraft:gold_block
fill 345 266 346 345 266 351 minecraft:gold_block
fill 346 266 352 346 266 359 minecraft:gold_block
fill 347 266 359 347 266 363 minecraft:gold_block
fill 348 266 322 351 271 322 minecraft:ochre_froglight
fill 353 266 364 356 271 364 minecraft:ochre_froglight
fill 360 266 322 363 271 322 minecraft:ochre_froglight
fill 365 266 364 368 271 364 minecraft:ochre_froglight
fill 367 266 329 368 270 329 minecraft:iron_block
fill 368 266 327 368 270 328 minecraft:iron_block
fill 371 266 323 371 271 326 minecraft:ochre_froglight
fill 371 266 335 371 271 338 minecraft:ochre_froglight
fill 371 266 347 371 271 350 minecraft:ochre_froglight
fill 371 266 359 371 271 362 minecraft:ochre_froglight
fill 369 267 345 369 268 347 minecraft:polished_andesite
fill 370 267 346 370 268 347 minecraft:polished_andesite
fill 331 268 345 331 269 347 minecraft:polished_andesite
setblock 332 268 325 minecraft:light[level=15]
setblock 332 268 332 minecraft:light[level=12]
setblock 332 268 333 minecraft:light[level=15]
setblock 332 268 339 minecraft:light[level=12]
setblock 332 268 341 minecraft:light[level=15]
fill 332 268 346 332 271 346 minecraft:polished_andesite
setblock 332 268 349 minecraft:light[level=15]
setblock 332 268 353 minecraft:light[level=12]
fill 332 268 354 332 268 356 minecraft:polished_andesite
setblock 332 268 357 minecraft:light[level=15]
setblock 332 268 360 minecraft:light[level=12]
fill 333 268 354 334 268 354 minecraft:polished_andesite
fill 333 268 356 334 268 356 minecraft:polished_andesite
setblock 334 268 355 minecraft:polished_andesite
setblock 339 268 325 minecraft:light[level=12]
setblock 339 268 332 minecraft:light[level=12]
setblock 339 268 339 minecraft:light[level=12]
setblock 339 268 346 minecraft:light[level=12]
setblock 339 268 353 minecraft:light[level=12]
setblock 339 268 360 minecraft:light[level=12]
setblock 340 268 325 minecraft:light[level=15]
setblock 340 268 333 minecraft:light[level=15]
setblock 340 268 341 minecraft:light[level=15]
setblock 340 268 349 minecraft:light[level=15]
setblock 340 268 357 minecraft:light[level=15]
setblock 346 268 325 minecraft:light[level=12]
setblock 346 268 332 minecraft:light[level=12]
setblock 346 268 339 minecraft:light[level=12]
setblock 346 268 346 minecraft:light[level=12]
setblock 346 268 353 minecraft:light[level=12]
setblock 346 268 360 minecraft:light[level=12]
setblock 348 268 325 minecraft:light[level=15]
setblock 348 268 333 minecraft:light[level=15]
setblock 348 268 341 minecraft:light[level=15]
setblock 348 268 349 minecraft:light[level=15]
setblock 348 268 357 minecraft:light[level=15]
setblock 353 268 325 minecraft:light[level=12]
setblock 353 268 332 minecraft:light[level=12]
setblock 353 268 339 minecraft:light[level=12]
setblock 353 268 346 minecraft:light[level=12]
setblock 353 268 353 minecraft:light[level=12]
setblock 353 268 360 minecraft:light[level=12]
setblock 356 268 325 minecraft:light[level=15]
setblock 356 268 333 minecraft:light[level=15]
setblock 356 268 341 minecraft:light[level=15]
setblock 356 268 349 minecraft:light[level=15]
setblock 356 268 357 minecraft:light[level=15]
setblock 360 268 325 minecraft:light[level=12]
setblock 360 268 332 minecraft:light[level=12]
setblock 360 268 339 minecraft:light[level=12]
setblock 360 268 346 minecraft:light[level=12]
setblock 360 268 353 minecraft:light[level=12]
setblock 360 268 360 minecraft:light[level=12]
setblock 364 268 325 minecraft:light[level=15]
setblock 364 268 333 minecraft:light[level=15]
setblock 364 268 341 minecraft:light[level=15]
setblock 364 268 349 minecraft:light[level=15]
setblock 364 268 357 minecraft:light[level=15]
setblock 367 268 325 minecraft:light[level=12]
setblock 367 268 332 minecraft:light[level=12]
setblock 367 268 339 minecraft:light[level=12]
fill 367 268 346 368 270 346 minecraft:polished_andesite
setblock 367 268 353 minecraft:light[level=12]
setblock 367 268 360 minecraft:light[level=12]
fill 368 268 345 368 269 345 minecraft:polished_andesite
fill 368 268 347 368 269 347 minecraft:polished_andesite
fill 332 269 345 332 270 345 minecraft:polished_andesite
fill 332 269 347 332 270 347 minecraft:polished_andesite
fill 333 269 346 333 271 346 minecraft:polished_andesite
fill 362 269 340 362 270 344 minecraft:iron_block
fill 363 269 339 363 270 340 minecraft:iron_block
fill 363 269 342 367 270 342 minecraft:polished_andesite
fill 363 269 344 363 270 345 minecraft:iron_block
fill 364 269 339 367 270 339 minecraft:iron_block
fill 364 269 345 366 269 345 minecraft:iron_block
fill 365 269 340 365 270 341 minecraft:polished_andesite
fill 365 269 343 365 270 344 minecraft:polished_andesite
fill 366 269 346 366 271 346 minecraft:polished_andesite
fill 367 269 340 368 270 340 minecraft:iron_block
fill 367 269 344 368 270 344 minecraft:iron_block
fill 367 269 345 367 270 345 minecraft:polished_andesite
fill 367 269 347 367 270 347 minecraft:polished_andesite
fill 368 269 341 368 270 343 minecraft:iron_block
setblock 369 269 346 minecraft:polished_andesite
setblock 370 269 346 minecraft:gold_block
setblock 331 270 346 minecraft:polished_andesite
fill 333 270 345 334 271 345 minecraft:polished_andesite
fill 333 270 347 334 271 347 minecraft:polished_andesite
fill 334 270 346 334 272 346 minecraft:polished_andesite
setblock 364 270 345 minecraft:iron_block
fill 365 270 345 365 271 347 minecraft:polished_andesite
fill 366 270 345 366 271 345 minecraft:polished_andesite
fill 366 270 347 366 271 347 minecraft:polished_andesite
setblock 369 270 346 minecraft:gold_block
setblock 331 271 346 minecraft:gold_block
fill 332 271 329 332 272 329 minecraft:iron_block
fill 335 271 345 335 272 347 minecraft:polished_andesite
fill 336 271 346 336 272 346 minecraft:polished_andesite
fill 363 271 346 364 272 346 minecraft:polished_andesite
fill 364 271 327 364 272 328 minecraft:gold_block
fill 364 271 345 364 272 345 minecraft:polished_andesite
fill 364 271 347 364 272 347 minecraft:polished_andesite
fill 365 271 329 365 272 329 minecraft:gold_block
fill 366 271 325 366 272 325 minecraft:gold_block
fill 366 271 330 368 271 330 minecraft:polished_andesite
fill 367 271 329 367 272 329 minecraft:gold_block
setblock 367 271 346 minecraft:polished_andesite
fill 368 271 326 368 272 328 minecraft:gold_block
fill 368 271 329 368 272 329 minecraft:iron_block
setblock 368 271 346 minecraft:gold_block
fill 369 271 327 369 271 329 minecraft:polished_andesite
fill 329 272 328 329 285 328 minecraft:bricks
fill 329 272 329 329 272 330 minecraft:ochre_froglight
fill 329 272 331 329 285 331 minecraft:bricks
fill 329 272 340 329 285 340 minecraft:bricks
fill 329 272 341 329 272 342 minecraft:ochre_froglight
fill 329 272 343 329 285 343 minecraft:bricks
fill 329 272 352 329 285 352 minecraft:bricks
fill 329 272 353 329 272 354 minecraft:ochre_froglight
fill 329 272 355 329 285 355 minecraft:bricks
fill 329 272 364 329 285 364 minecraft:bricks
fill 330 272 364 331 272 364 minecraft:ochre_froglight
fill 332 272 364 332 285 364 minecraft:bricks
setblock 333 272 346 minecraft:gold_block
fill 336 272 322 336 285 322 minecraft:bricks
setblock 336 272 345 minecraft:polished_andesite
setblock 336 272 347 minecraft:polished_andesite
fill 337 272 322 338 272 322 minecraft:ochre_froglight
setblock 337 272 346 minecraft:polished_andesite
fill 339 272 322 339 285 322 minecraft:bricks
fill 341 272 364 341 285 364 minecraft:bricks
fill 342 272 364 343 272 364 minecraft:ochre_froglight
fill 344 272 364 344 285 364 minecraft:bricks
fill 348 272 322 348 285 322 minecraft:bricks
fill 349 272 322 350 272 322 minecraft:ochre_froglight
fill 351 272 322 351 285 322 minecraft:bricks
fill 353 272 364 353 285 364 minecraft:bricks
fill 354 272 364 355 272 364 minecraft:ochre_froglight
fill 356 272 364 356 285 364 minecraft:bricks
fill 360 272 322 360 285 322 minecraft:bricks
fill 361 272 322 362 272 322 minecraft:ochre_froglight
setblock 362 272 346 minecraft:polished_andesite
fill 363 272 322 363 285 322 minecraft:bricks
setblock 363 272 345 minecraft:polished_andesite
setblock 363 272 347 minecraft:polished_andesite
setblock 365 272 346 minecraft:polished_andesite
fill 365 272 364 365 285 364 minecraft:bricks
setblock 366 272 346 minecraft:gold_block
fill 366 272 364 367 272 364 minecraft:ochre_froglight
fill 368 272 364 368 285 364 minecraft:bricks
fill 371 272 323 371 285 323 minecraft:bricks
fill 371 272 324 371 272 325 minecraft:ochre_froglight
fill 371 272 326 371 285 326 minecraft:bricks
fill 371 272 335 371 285 335 minecraft:bricks
fill 371 272 336 371 272 337 minecraft:ochre_froglight
fill 371 272 338 371 285 338 minecraft:bricks
fill 371 272 347 371 285 347 minecraft:bricks
fill 371 272 348 371 272 349 minecraft:ochre_froglight
fill 371 272 350 371 285 350 minecraft:bricks
fill 371 272 359 371 285 359 minecraft:bricks
fill 371 272 360 371 272 361 minecraft:ochre_froglight
fill 371 272 362 371 285 362 minecraft:bricks
fill 329 273 329 329 285 330 minecraft:bricks
fill 329 273 341 329 285 342 minecraft:bricks
fill 329 273 353 329 285 354 minecraft:bricks
fill 330 273 364 331 285 364 minecraft:bricks
fill 337 273 322 338 285 322 minecraft:bricks
fill 342 273 364 343 285 364 minecraft:bricks
fill 349 273 322 350 285 322 minecraft:bricks
fill 354 273 364 355 285 364 minecraft:bricks
fill 361 273 322 362 285 322 minecraft:bricks
fill 366 273 364 367 285 364 minecraft:bricks
fill 371 273 324 371 285 325 minecraft:bricks
fill 371 273 336 371 285 337 minecraft:bricks
fill 371 273 348 371 285 349 minecraft:bricks
fill 371 273 360 371 285 361 minecraft:bricks
fill 330 274 338 330 280 338 minecraft:waxed_copper_block
fill 330 274 340 330 276 341 minecraft:waxed_copper_block
setblock 332 274 325 minecraft:light[level=12]
setblock 332 274 332 minecraft:light[level=12]
setblock 332 274 339 minecraft:light[level=12]
setblock 332 274 346 minecraft:light[level=12]
setblock 332 274 353 minecraft:light[level=12]
setblock 332 274 360 minecraft:light[level=12]
setblock 339 274 325 minecraft:light[level=12]
setblock 339 274 332 minecraft:light[level=12]
setblock 339 274 339 minecraft:light[level=12]
setblock 339 274 346 minecraft:light[level=12]
setblock 339 274 353 minecraft:light[level=12]
setblock 339 274 360 minecraft:light[level=12]
setblock 346 274 325 minecraft:light[level=12]
setblock 346 274 332 minecraft:light[level=12]
setblock 346 274 339 minecraft:light[level=12]
setblock 346 274 346 minecraft:light[level=12]
setblock 346 274 353 minecraft:light[level=12]
setblock 346 274 360 minecraft:light[level=12]
setblock 353 274 325 minecraft:light[level=12]
setblock 353 274 332 minecraft:light[level=12]
setblock 353 274 339 minecraft:light[level=12]
setblock 353 274 346 minecraft:light[level=12]
setblock 353 274 353 minecraft:light[level=12]
setblock 353 274 360 minecraft:light[level=12]
setblock 360 274 325 minecraft:light[level=12]
setblock 360 274 332 minecraft:light[level=12]
setblock 360 274 339 minecraft:light[level=12]
setblock 360 274 346 minecraft:light[level=12]
setblock 360 274 353 minecraft:light[level=12]
setblock 360 274 360 minecraft:light[level=12]
setblock 367 274 325 minecraft:light[level=12]
setblock 367 274 332 minecraft:light[level=12]
setblock 367 274 339 minecraft:light[level=12]
setblock 367 274 346 minecraft:light[level=12]
setblock 367 274 353 minecraft:light[level=12]
setblock 367 274 360 minecraft:light[level=12]
setblock 330 275 337 minecraft:waxed_copper_block
fill 330 275 339 330 277 339 minecraft:waxed_copper_block
fill 330 275 343 330 279 343 minecraft:waxed_copper_block
fill 330 276 342 330 282 342 minecraft:waxed_copper_block
setblock 330 276 344 minecraft:waxed_copper_block
setblock 332 276 325 minecraft:light[level=15]
setblock 332 276 333 minecraft:light[level=15]
setblock 332 276 341 minecraft:light[level=15]
setblock 332 276 349 minecraft:light[level=15]
setblock 332 276 357 minecraft:light[level=15]
setblock 340 276 325 minecraft:light[level=15]
setblock 340 276 333 minecraft:light[level=15]
setblock 340 276 341 minecraft:light[level=15]
setblock 340 276 349 minecraft:light[level=15]
setblock 340 276 357 minecraft:light[level=15]
setblock 348 276 325 minecraft:light[level=15]
setblock 348 276 333 minecraft:light[level=15]
setblock 348 276 341 minecraft:light[level=15]
setblock 348 276 349 minecraft:light[level=15]
setblock 348 276 357 minecraft:light[level=15]
setblock 356 276 325 minecraft:light[level=15]
setblock 356 276 333 minecraft:light[level=15]
setblock 356 276 341 minecraft:light[level=15]
setblock 356 276 349 minecraft:light[level=15]
setblock 356 276 357 minecraft:light[level=15]
setblock 364 276 325 minecraft:light[level=15]
setblock 364 276 333 minecraft:light[level=15]
setblock 364 276 341 minecraft:light[level=15]
setblock 364 276 349 minecraft:light[level=15]
setblock 364 276 357 minecraft:light[level=15]
fill 330 277 336 330 278 337 minecraft:waxed_copper_block
setblock 330 277 341 minecraft:waxed_copper_block
fill 330 278 344 330 279 344 minecraft:waxed_copper_block
fill 334 278 343 344 278 343 minecraft:quartz_block
fill 335 278 338 344 278 342 minecraft:quartz_block
fill 335 278 344 344 278 348 minecraft:quartz_block
fill 336 278 337 358 278 337 minecraft:quartz_block
fill 336 278 349 358 278 349 minecraft:quartz_block
fill 337 278 335 357 278 336 minecraft:quartz_block
fill 337 278 350 357 278 351 minecraft:quartz_block
fill 338 278 334 356 278 334 minecraft:quartz_block
fill 338 278 352 356 278 352 minecraft:quartz_block
fill 339 278 333 355 278 333 minecraft:quartz_block
fill 339 278 353 355 278 353 minecraft:quartz_block
fill 341 278 332 353 278 332 minecraft:quartz_block
fill 341 278 354 353 278 354 minecraft:quartz_block
fill 342 278 331 352 278 331 minecraft:quartz_block
fill 342 278 355 352 278 355 minecraft:quartz_block
fill 345 278 338 345 278 341 minecraft:quartz_block
fill 345 278 345 345 278 348 minecraft:quartz_block
fill 346 278 338 359 278 340 minecraft:quartz_block
fill 346 278 346 359 278 348 minecraft:quartz_block
setblock 347 278 330 minecraft:quartz_block
setblock 347 278 356 minecraft:quartz_block
fill 349 278 341 359 278 341 minecraft:quartz_block
fill 349 278 345 359 278 345 minecraft:quartz_block
fill 350 278 342 359 278 344 minecraft:quartz_block
setblock 360 278 343 minecraft:quartz_block
fill 330 279 323 336 279 336 minecraft:bricks
fill 330 279 337 330 281 337 minecraft:waxed_copper_block
fill 330 279 339 330 282 339 minecraft:waxed_copper_block
fill 330 279 340 334 279 340 minecraft:bricks
fill 330 279 341 330 281 341 minecraft:waxed_copper_block
fill 330 279 345 334 279 363 minecraft:bricks
fill 331 279 337 334 279 339 minecraft:bricks
fill 331 279 341 333 279 344 minecraft:bricks
fill 334 279 341 334 279 342 minecraft:bricks
fill 334 279 343 343 279 343 minecraft:smooth_quartz
setblock 334 279 344 minecraft:bricks
setblock 335 279 337 minecraft:bricks
setblock 335 279 338 minecraft:smooth_quartz
fill 335 279 339 335 279 342 minecraft:gold_block
fill 335 279 344 335 279 347 minecraft:gold_block
setblock 335 279 348 minecraft:smooth_quartz
fill 335 279 349 335 279 363 minecraft:bricks
schedule function dropper:buildpart/79_2 1t
