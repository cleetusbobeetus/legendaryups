setblock 175 144 276 minecraft:snow_block
fill 175 144 277 175 146 277 minecraft:packed_ice
setblock 175 144 316 minecraft:snow_block
fill 176 144 276 179 144 276 minecraft:packed_ice
setblock 176 144 315 minecraft:snow_block
fill 176 144 316 179 144 316 minecraft:packed_ice
fill 177 144 277 178 144 277 minecraft:packed_ice
setblock 180 144 276 minecraft:snow_block
setblock 180 144 316 minecraft:snow_block
fill 181 144 276 181 146 276 minecraft:packed_ice
setblock 181 144 299 minecraft:packed_ice
setblock 181 144 300 minecraft:snow_block
fill 181 144 301 181 144 304 minecraft:packed_ice
setblock 181 144 305 minecraft:snow_block
fill 181 144 306 181 147 306 minecraft:packed_ice
fill 181 144 316 181 147 316 minecraft:packed_ice
setblock 182 144 278 minecraft:packed_ice
setblock 182 144 279 minecraft:snow_block
fill 182 144 280 182 147 280 minecraft:packed_ice
fill 182 144 282 182 145 282 minecraft:packed_ice
fill 182 144 296 182 144 298 minecraft:packed_ice
setblock 182 144 299 minecraft:snow_block
fill 182 144 300 182 147 300 minecraft:packed_ice
fill 182 144 302 182 144 303 minecraft:packed_ice
setblock 182 144 304 minecraft:snow_block
fill 182 144 305 182 147 305 minecraft:packed_ice
setblock 182 144 309 minecraft:snow_block
fill 182 144 310 182 144 313 minecraft:packed_ice
setblock 182 144 314 minecraft:snow_block
fill 182 144 315 182 147 315 minecraft:packed_ice
fill 141 145 309 141 179 309 minecraft:blue_ice
fill 142 145 276 142 145 277 minecraft:packed_ice
setblock 142 145 278 minecraft:snow_block
fill 142 145 279 143 147 279 minecraft:packed_ice
setblock 142 145 282 minecraft:packed_ice
setblock 142 145 283 minecraft:snow_block
fill 142 145 284 142 146 286 minecraft:packed_ice
setblock 142 145 292 minecraft:packed_ice
setblock 142 145 293 minecraft:snow_block
fill 142 145 294 142 145 297 minecraft:packed_ice
setblock 142 145 298 minecraft:snow_block
fill 142 145 299 142 145 302 minecraft:packed_ice
setblock 142 145 303 minecraft:snow_block
fill 142 145 304 142 148 304 minecraft:packed_ice
setblock 142 145 307 minecraft:packed_ice
setblock 142 145 308 minecraft:snow_block
fill 142 145 309 142 148 309 minecraft:packed_ice
setblock 143 145 276 minecraft:packed_ice
fill 143 145 280 143 145 281 minecraft:packed_ice
setblock 143 145 282 minecraft:snow_block
fill 143 145 283 143 148 283 minecraft:packed_ice
fill 143 145 294 143 145 296 minecraft:packed_ice
setblock 143 145 297 minecraft:snow_block
fill 143 145 298 143 145 301 minecraft:packed_ice
setblock 143 145 302 minecraft:snow_block
fill 143 145 303 143 148 303 minecraft:packed_ice
setblock 143 145 307 minecraft:snow_block
fill 143 145 308 143 148 308 minecraft:packed_ice
setblock 144 145 276 minecraft:snow_block
fill 144 145 277 147 145 277 minecraft:packed_ice
fill 144 145 291 144 149 293 minecraft:packed_ice
setblock 144 145 295 minecraft:packed_ice
setblock 144 145 296 minecraft:snow_block
fill 144 145 297 144 145 300 minecraft:packed_ice
setblock 144 145 301 minecraft:snow_block
fill 144 145 302 144 148 302 minecraft:packed_ice
setblock 144 145 305 minecraft:packed_ice
setblock 144 145 306 minecraft:snow_block
setblock 144 145 316 minecraft:snow_block
fill 145 145 276 148 145 276 minecraft:packed_ice
setblock 145 145 278 minecraft:snow_block
fill 145 145 290 145 149 290 minecraft:packed_ice
fill 145 145 294 145 149 294 minecraft:packed_ice
setblock 145 145 299 minecraft:packed_ice
setblock 145 145 300 minecraft:snow_block
fill 145 145 301 145 148 301 minecraft:packed_ice
fill 145 145 316 148 145 316 minecraft:packed_ice
setblock 146 145 278 minecraft:packed_ice
setblock 147 145 278 minecraft:snow_block
setblock 148 145 277 minecraft:snow_block
fill 148 145 278 151 145 278 minecraft:packed_ice
fill 148 145 290 148 149 290 minecraft:packed_ice
fill 148 145 294 148 149 294 minecraft:packed_ice
setblock 149 145 276 minecraft:snow_block
fill 149 145 277 152 145 277 minecraft:packed_ice
fill 149 145 291 149 149 293 minecraft:packed_ice
setblock 149 145 316 minecraft:snow_block
fill 150 145 276 153 145 276 minecraft:packed_ice
fill 150 145 316 150 146 316 minecraft:packed_ice
fill 150 145 317 150 178 317 minecraft:blue_ice
setblock 152 145 278 minecraft:snow_block
setblock 153 145 277 minecraft:snow_block
setblock 153 145 278 minecraft:packed_ice
setblock 154 145 276 minecraft:snow_block
fill 154 145 277 157 145 277 minecraft:packed_ice
fill 155 145 276 158 145 276 minecraft:packed_ice
setblock 158 145 277 minecraft:snow_block
setblock 159 145 276 minecraft:snow_block
fill 159 145 277 162 145 277 minecraft:packed_ice
fill 160 145 276 163 145 276 minecraft:packed_ice
setblock 161 145 278 minecraft:packed_ice
setblock 162 145 278 minecraft:snow_block
fill 162 145 317 168 153 317 minecraft:blue_ice
setblock 163 145 277 minecraft:snow_block
fill 163 145 278 165 145 279 minecraft:packed_ice
setblock 163 145 316 minecraft:packed_ice
setblock 164 145 276 minecraft:snow_block
fill 164 145 277 167 145 277 minecraft:packed_ice
setblock 164 145 316 minecraft:snow_block
fill 165 145 275 165 179 275 minecraft:blue_ice
fill 165 145 276 168 145 276 minecraft:packed_ice
fill 165 145 316 168 145 316 minecraft:packed_ice
setblock 166 145 278 minecraft:packed_ice
setblock 166 145 279 minecraft:snow_block
fill 166 145 315 169 145 315 minecraft:packed_ice
setblock 167 145 278 minecraft:snow_block
fill 167 145 279 167 148 279 minecraft:packed_ice
setblock 168 145 277 minecraft:snow_block
fill 168 145 278 171 145 278 minecraft:packed_ice
setblock 169 145 276 minecraft:snow_block
fill 169 145 277 172 145 277 minecraft:packed_ice
setblock 169 145 316 minecraft:snow_block
setblock 169 145 317 minecraft:white_concrete
fill 170 145 276 173 145 276 minecraft:packed_ice
setblock 170 145 279 minecraft:packed_ice
setblock 170 145 315 minecraft:snow_block
fill 170 145 316 173 145 316 minecraft:packed_ice
setblock 171 145 279 minecraft:snow_block
fill 171 145 315 174 145 315 minecraft:packed_ice
fill 172 145 275 172 167 275 minecraft:blue_ice
setblock 172 145 278 minecraft:snow_block
setblock 172 145 279 minecraft:packed_ice
setblock 173 145 277 minecraft:snow_block
fill 173 145 278 173 146 278 minecraft:packed_ice
setblock 174 145 276 minecraft:snow_block
fill 174 145 277 174 147 277 minecraft:packed_ice
fill 174 145 293 175 146 294 minecraft:snow_block
setblock 174 145 316 minecraft:snow_block
fill 175 145 276 178 145 276 minecraft:packed_ice
fill 175 145 281 175 151 281 minecraft:packed_ice
fill 175 145 316 178 145 316 minecraft:packed_ice
fill 176 145 289 176 146 289 minecraft:packed_ice
setblock 177 145 277 minecraft:packed_ice
fill 177 145 288 177 146 288 minecraft:packed_ice
fill 177 145 290 177 146 290 minecraft:packed_ice
fill 177 145 310 177 150 310 minecraft:packed_ice
fill 178 145 289 178 146 289 minecraft:packed_ice
setblock 179 145 276 minecraft:snow_block
setblock 179 145 316 minecraft:snow_block
fill 180 145 276 180 146 276 minecraft:packed_ice
fill 180 145 316 180 146 316 minecraft:packed_ice
setblock 181 145 299 minecraft:snow_block
fill 181 145 300 181 145 303 minecraft:packed_ice
setblock 181 145 304 minecraft:snow_block
fill 181 145 305 181 148 305 minecraft:packed_ice
fill 181 145 307 181 145 308 minecraft:packed_ice
setblock 182 145 278 minecraft:snow_block
fill 182 145 279 182 148 279 minecraft:packed_ice
setblock 182 145 283 minecraft:snow_block
fill 182 145 296 182 145 297 minecraft:packed_ice
setblock 182 145 298 minecraft:snow_block
fill 182 145 299 182 148 299 minecraft:packed_ice
setblock 182 145 302 minecraft:packed_ice
setblock 182 145 303 minecraft:snow_block
fill 182 145 304 182 148 304 minecraft:packed_ice
setblock 182 145 307 minecraft:packed_ice
setblock 182 145 308 minecraft:snow_block
fill 182 145 309 182 145 312 minecraft:packed_ice
setblock 182 145 313 minecraft:snow_block
fill 182 145 314 182 148 314 minecraft:packed_ice
setblock 142 146 277 minecraft:snow_block
fill 142 146 278 142 148 278 minecraft:packed_ice
setblock 142 146 282 minecraft:snow_block
fill 142 146 283 142 149 283 minecraft:packed_ice
setblock 142 146 287 minecraft:snow_block
fill 142 146 288 142 146 291 minecraft:packed_ice
setblock 142 146 292 minecraft:snow_block
fill 142 146 293 142 146 296 minecraft:packed_ice
setblock 142 146 297 minecraft:snow_block
fill 142 146 298 142 146 301 minecraft:packed_ice
setblock 142 146 302 minecraft:snow_block
fill 142 146 303 142 149 303 minecraft:packed_ice
setblock 142 146 306 minecraft:packed_ice
setblock 142 146 307 minecraft:snow_block
fill 142 146 308 142 149 308 minecraft:packed_ice
setblock 142 146 311 minecraft:packed_ice
setblock 143 146 276 minecraft:snow_block
setblock 143 146 280 minecraft:packed_ice
setblock 143 146 281 minecraft:snow_block
fill 143 146 282 143 149 282 minecraft:packed_ice
fill 143 146 284 143 146 285 minecraft:packed_ice
fill 143 146 294 143 146 295 minecraft:packed_ice
setblock 143 146 296 minecraft:snow_block
fill 143 146 297 143 146 300 minecraft:packed_ice
setblock 143 146 301 minecraft:snow_block
fill 143 146 302 143 149 302 minecraft:packed_ice
setblock 143 146 306 minecraft:snow_block
fill 143 146 307 144 148 307 minecraft:packed_ice
fill 144 146 276 147 146 276 minecraft:packed_ice
fill 144 146 280 144 147 280 minecraft:snow_block
fill 144 146 290 144 149 290 minecraft:packed_ice
fill 144 146 294 144 149 294 minecraft:packed_ice
fill 144 146 296 144 146 299 minecraft:packed_ice
setblock 144 146 300 minecraft:snow_block
fill 144 146 301 144 149 301 minecraft:packed_ice
setblock 144 146 305 minecraft:snow_block
fill 144 146 306 144 149 306 minecraft:packed_ice
fill 145 146 277 146 146 277 minecraft:packed_ice
fill 145 146 279 145 147 279 minecraft:snow_block
fill 145 146 281 145 147 281 minecraft:snow_block
fill 145 146 289 148 149 289 minecraft:packed_ice
setblock 145 146 299 minecraft:snow_block
fill 145 146 300 145 147 300 minecraft:packed_ice
setblock 145 146 304 minecraft:snow_block
fill 145 146 305 145 147 305 minecraft:packed_ice
fill 145 146 316 147 146 316 minecraft:packed_ice
fill 146 146 280 146 147 280 minecraft:snow_block
fill 146 146 295 147 149 295 minecraft:packed_ice
setblock 147 146 277 minecraft:snow_block
fill 147 146 278 150 146 278 minecraft:packed_ice
setblock 148 146 276 minecraft:snow_block
fill 148 146 277 151 146 277 minecraft:packed_ice
setblock 148 146 316 minecraft:snow_block
fill 149 146 276 152 146 276 minecraft:packed_ice
fill 149 146 290 149 149 290 minecraft:packed_ice
setblock 149 146 316 minecraft:packed_ice
setblock 151 146 278 minecraft:snow_block
setblock 152 146 277 minecraft:snow_block
setblock 152 146 278 minecraft:packed_ice
setblock 153 146 276 minecraft:snow_block
fill 153 146 277 156 146 277 minecraft:packed_ice
fill 154 146 276 157 146 276 minecraft:packed_ice
setblock 157 146 277 minecraft:snow_block
setblock 158 146 276 minecraft:snow_block
fill 158 146 277 161 146 277 minecraft:packed_ice
fill 159 146 276 162 146 276 minecraft:packed_ice
setblock 161 146 278 minecraft:snow_block
setblock 162 146 277 minecraft:snow_block
fill 162 146 278 165 146 278 minecraft:packed_ice
setblock 163 146 276 minecraft:snow_block
fill 163 146 277 166 146 277 minecraft:packed_ice
fill 163 146 279 164 146 279 minecraft:packed_ice
setblock 163 146 316 minecraft:snow_block
fill 164 146 276 167 146 276 minecraft:packed_ice
fill 164 146 316 167 146 316 minecraft:packed_ice
setblock 165 146 279 minecraft:snow_block
setblock 166 146 278 minecraft:snow_block
fill 166 146 279 166 148 279 minecraft:packed_ice
fill 166 146 315 168 146 315 minecraft:packed_ice
setblock 167 146 277 minecraft:snow_block
fill 167 146 278 170 146 278 minecraft:packed_ice
setblock 168 146 276 minecraft:snow_block
fill 168 146 277 171 146 277 minecraft:packed_ice
setblock 168 146 316 minecraft:snow_block
fill 169 146 276 172 146 276 minecraft:packed_ice
setblock 169 146 279 minecraft:packed_ice
setblock 169 146 315 minecraft:snow_block
fill 169 146 316 172 146 316 minecraft:packed_ice
fill 169 146 317 169 179 317 minecraft:blue_ice
setblock 170 146 279 minecraft:snow_block
fill 170 146 315 173 146 315 minecraft:packed_ice
setblock 171 146 278 minecraft:snow_block
setblock 171 146 279 minecraft:packed_ice
setblock 172 146 277 minecraft:snow_block
fill 172 146 278 172 147 278 minecraft:packed_ice
setblock 173 146 276 minecraft:snow_block
fill 173 146 277 173 147 277 minecraft:packed_ice
setblock 173 146 316 minecraft:snow_block
fill 174 146 276 177 146 276 minecraft:packed_ice
fill 174 146 316 177 146 316 minecraft:packed_ice
setblock 175 146 275 minecraft:light_blue_concrete
setblock 178 146 276 minecraft:snow_block
setblock 178 146 316 minecraft:snow_block
setblock 179 146 276 minecraft:packed_ice
setblock 179 146 316 minecraft:packed_ice
fill 181 146 299 181 146 302 minecraft:packed_ice
setblock 181 146 303 minecraft:snow_block
fill 181 146 304 181 149 304 minecraft:packed_ice
setblock 181 146 307 minecraft:packed_ice
setblock 181 146 308 minecraft:snow_block
setblock 182 146 277 minecraft:snow_block
fill 182 146 278 182 148 278 minecraft:packed_ice
setblock 182 146 282 minecraft:snow_block
fill 182 146 283 182 148 284 minecraft:packed_ice
setblock 182 146 296 minecraft:packed_ice
setblock 182 146 297 minecraft:snow_block
fill 182 146 298 182 149 298 minecraft:packed_ice
setblock 182 146 302 minecraft:snow_block
fill 182 146 303 182 149 303 minecraft:packed_ice
setblock 182 146 307 minecraft:snow_block
fill 182 146 308 182 146 311 minecraft:packed_ice
setblock 182 146 312 minecraft:snow_block
fill 182 146 313 182 149 313 minecraft:packed_ice
setblock 141 147 316 minecraft:white_concrete
setblock 142 147 277 minecraft:packed_ice
setblock 142 147 281 minecraft:snow_block
fill 142 147 282 142 150 282 minecraft:packed_ice
fill 142 147 284 142 147 285 minecraft:packed_ice
setblock 142 147 286 minecraft:snow_block
fill 142 147 287 142 147 290 minecraft:packed_ice
setblock 142 147 291 minecraft:snow_block
fill 142 147 292 142 147 295 minecraft:packed_ice
setblock 142 147 296 minecraft:snow_block
fill 142 147 297 142 147 300 minecraft:packed_ice
setblock 142 147 301 minecraft:snow_block
fill 142 147 302 142 150 302 minecraft:packed_ice
setblock 142 147 306 minecraft:snow_block
fill 142 147 307 142 150 307 minecraft:packed_ice
setblock 142 147 311 minecraft:snow_block
fill 143 147 276 146 147 276 minecraft:packed_ice
setblock 143 147 280 minecraft:snow_block
fill 143 147 281 143 150 281 minecraft:packed_ice
setblock 143 147 284 minecraft:packed_ice
setblock 143 147 285 minecraft:snow_block
fill 143 147 286 143 149 287 minecraft:packed_ice
fill 143 147 291 143 149 294 minecraft:packed_ice
setblock 143 147 295 minecraft:snow_block
fill 143 147 296 143 147 299 minecraft:packed_ice
setblock 143 147 300 minecraft:snow_block
fill 143 147 301 143 150 301 minecraft:packed_ice
setblock 143 147 305 minecraft:snow_block
fill 143 147 306 143 150 306 minecraft:packed_ice
setblock 143 147 309 minecraft:packed_ice
fill 144 147 282 144 147 283 minecraft:packed_ice
setblock 144 147 284 minecraft:snow_block
fill 144 147 296 144 147 298 minecraft:packed_ice
setblock 144 147 299 minecraft:snow_block
fill 144 147 300 144 150 300 minecraft:packed_ice
setblock 144 147 303 minecraft:packed_ice
setblock 144 147 304 minecraft:snow_block
fill 144 147 305 144 150 305 minecraft:packed_ice
setblock 145 147 277 minecraft:packed_ice
fill 145 147 295 145 149 295 minecraft:packed_ice
setblock 145 147 299 minecraft:packed_ice
setblock 145 147 303 minecraft:snow_block
fill 145 147 304 145 148 304 minecraft:packed_ice
setblock 146 147 277 minecraft:snow_block
setblock 147 147 276 minecraft:snow_block
fill 147 147 277 150 147 277 minecraft:packed_ice
fill 148 147 276 151 147 276 minecraft:packed_ice
fill 148 147 278 149 147 278 minecraft:packed_ice
fill 148 147 295 148 149 295 minecraft:packed_ice
fill 149 147 294 149 149 294 minecraft:packed_ice
fill 150 147 291 150 149 293 minecraft:packed_ice
setblock 151 147 277 minecraft:snow_block
fill 151 147 317 151 180 317 minecraft:blue_ice
setblock 152 147 276 minecraft:snow_block
fill 152 147 277 153 147 277 minecraft:packed_ice
setblock 152 147 317 minecraft:white_concrete
fill 153 147 276 156 147 276 minecraft:packed_ice
setblock 157 147 276 minecraft:snow_block
fill 158 147 276 161 147 276 minecraft:packed_ice
fill 159 147 277 160 147 277 minecraft:packed_ice
setblock 161 147 277 minecraft:snow_block
fill 161 147 278 164 147 278 minecraft:packed_ice
setblock 162 147 276 minecraft:snow_block
fill 162 147 277 165 147 277 minecraft:packed_ice
fill 163 147 276 166 147 276 minecraft:packed_ice
fill 163 147 316 166 147 316 minecraft:packed_ice
setblock 164 147 279 minecraft:snow_block
setblock 165 147 278 minecraft:snow_block
fill 165 147 279 165 148 279 minecraft:packed_ice
setblock 166 147 277 minecraft:snow_block
fill 166 147 278 169 147 278 minecraft:packed_ice
fill 166 147 315 167 147 315 minecraft:packed_ice
setblock 167 147 276 minecraft:snow_block
fill 167 147 277 170 147 277 minecraft:packed_ice
setblock 167 147 316 minecraft:snow_block
fill 168 147 276 171 147 276 minecraft:packed_ice
setblock 168 147 315 minecraft:snow_block
fill 168 147 316 171 147 316 minecraft:packed_ice
setblock 169 147 279 minecraft:snow_block
fill 169 147 315 171 147 315 minecraft:packed_ice
setblock 170 147 278 minecraft:snow_block
setblock 170 147 279 minecraft:packed_ice
setblock 171 147 277 minecraft:snow_block
setblock 171 147 278 minecraft:packed_ice
setblock 172 147 276 minecraft:snow_block
fill 172 147 277 172 148 277 minecraft:packed_ice
fill 172 147 295 173 211 296 minecraft:snow_block
setblock 172 147 316 minecraft:snow_block
fill 173 147 276 176 147 276 minecraft:packed_ice
fill 173 147 316 175 147 316 minecraft:packed_ice
fill 175 147 275 175 179 275 minecraft:blue_ice
fill 181 147 299 181 147 301 minecraft:packed_ice
setblock 181 147 302 minecraft:snow_block
fill 181 147 303 181 150 303 minecraft:packed_ice
setblock 181 147 307 minecraft:snow_block
fill 181 147 308 182 148 309 minecraft:packed_ice
setblock 182 147 277 minecraft:packed_ice
setblock 182 147 281 minecraft:snow_block
fill 182 147 282 182 150 282 minecraft:packed_ice
setblock 182 147 285 minecraft:packed_ice
setblock 182 147 296 minecraft:snow_block
fill 182 147 297 182 150 297 minecraft:packed_ice
setblock 182 147 301 minecraft:snow_block
fill 182 147 302 182 150 302 minecraft:packed_ice
setblock 182 147 306 minecraft:snow_block
fill 182 147 307 182 150 307 minecraft:packed_ice
setblock 182 147 310 minecraft:packed_ice
setblock 182 147 311 minecraft:snow_block
fill 182 147 312 182 150 312 minecraft:packed_ice
setblock 182 147 316 minecraft:snow_block
fill 141 148 316 141 159 316 minecraft:blue_ice
setblock 142 148 275 minecraft:light_blue_concrete
setblock 142 148 279 minecraft:packed_ice
setblock 142 148 280 minecraft:snow_block
fill 142 148 281 142 151 281 minecraft:packed_ice
setblock 142 148 284 minecraft:packed_ice
setblock 142 148 285 minecraft:snow_block
fill 142 148 286 142 148 289 minecraft:packed_ice
setblock 142 148 290 minecraft:snow_block
fill 142 148 291 142 148 294 minecraft:packed_ice
setblock 142 148 295 minecraft:snow_block
fill 142 148 296 142 148 299 minecraft:packed_ice
setblock 142 148 300 minecraft:snow_block
fill 142 148 301 142 151 301 minecraft:packed_ice
setblock 142 148 305 minecraft:snow_block
fill 142 148 306 142 151 306 minecraft:packed_ice
setblock 142 148 310 minecraft:snow_block
fill 142 148 311 142 151 311 minecraft:packed_ice
fill 143 148 275 144 179 275 minecraft:blue_ice
fill 143 148 280 143 149 280 minecraft:packed_ice
setblock 143 148 284 minecraft:snow_block
fill 143 148 285 144 150 285 minecraft:packed_ice
setblock 143 148 288 minecraft:packed_ice
setblock 143 148 289 minecraft:snow_block
fill 143 148 290 143 151 290 minecraft:packed_ice
fill 143 148 295 143 148 298 minecraft:packed_ice
setblock 143 148 299 minecraft:snow_block
fill 143 148 300 143 151 300 minecraft:packed_ice
setblock 143 148 304 minecraft:snow_block
fill 143 148 305 143 151 305 minecraft:packed_ice
setblock 143 148 309 minecraft:snow_block
fill 144 148 276 145 148 276 minecraft:packed_ice
setblock 144 148 278 minecraft:light[level=15]
setblock 144 148 282 minecraft:packed_ice
setblock 144 148 283 minecraft:snow_block
fill 144 148 284 144 151 284 minecraft:packed_ice
setblock 144 148 286 minecraft:light[level=15]
fill 144 148 289 144 149 289 minecraft:packed_ice
fill 144 148 295 144 149 295 minecraft:packed_ice
setblock 144 148 297 minecraft:packed_ice
setblock 144 148 298 minecraft:snow_block
fill 144 148 299 144 149 299 minecraft:packed_ice
setblock 144 148 303 minecraft:snow_block
fill 144 148 304 144 151 304 minecraft:packed_ice
setblock 144 148 310 minecraft:light[level=15]
setblock 144 148 313 minecraft:light[level=12]
fill 145 148 288 148 149 288 minecraft:packed_ice
setblock 145 148 302 minecraft:snow_block
setblock 145 148 303 minecraft:packed_ice
setblock 146 148 276 minecraft:snow_block
fill 146 148 277 149 148 277 minecraft:packed_ice
fill 146 148 296 147 149 296 minecraft:packed_ice
fill 147 148 276 150 148 276 minecraft:packed_ice
fill 149 148 289 149 149 289 minecraft:packed_ice
fill 149 148 295 149 149 295 minecraft:packed_ice
setblock 150 148 277 minecraft:snow_block
fill 150 148 290 150 149 290 minecraft:packed_ice
fill 150 148 294 150 149 294 minecraft:packed_ice
setblock 151 148 276 minecraft:snow_block
setblock 151 148 278 minecraft:light[level=12]
setblock 151 148 285 minecraft:light[level=12]
setblock 151 148 292 minecraft:light[level=12]
setblock 151 148 299 minecraft:light[level=12]
setblock 151 148 306 minecraft:light[level=12]
setblock 151 148 313 minecraft:light[level=12]
fill 152 148 276 153 148 276 minecraft:packed_ice
setblock 152 148 278 minecraft:light[level=15]
setblock 152 148 286 minecraft:light[level=15]
setblock 152 148 294 minecraft:light[level=15]
setblock 152 148 302 minecraft:light[level=15]
setblock 152 148 310 minecraft:light[level=15]
fill 152 148 317 152 180 317 minecraft:blue_ice
fill 158 148 276 160 148 276 minecraft:packed_ice
setblock 158 148 278 minecraft:light[level=12]
setblock 158 148 285 minecraft:light[level=12]
setblock 158 148 292 minecraft:light[level=12]
setblock 158 148 299 minecraft:light[level=12]
setblock 158 148 306 minecraft:light[level=12]
setblock 158 148 313 minecraft:light[level=12]
setblock 160 148 277 minecraft:snow_block
setblock 160 148 278 minecraft:light[level=15]
setblock 160 148 286 minecraft:light[level=15]
setblock 160 148 294 minecraft:light[level=15]
setblock 160 148 302 minecraft:light[level=15]
setblock 160 148 310 minecraft:light[level=15]
setblock 161 148 276 minecraft:snow_block
fill 161 148 277 164 148 277 minecraft:packed_ice
fill 162 148 276 165 148 276 minecraft:packed_ice
fill 162 148 278 163 148 278 minecraft:packed_ice
fill 163 148 316 165 148 316 minecraft:packed_ice
setblock 164 148 278 minecraft:snow_block
setblock 165 148 277 minecraft:snow_block
fill 165 148 278 168 148 278 minecraft:packed_ice
setblock 165 148 285 minecraft:light[level=12]
setblock 165 148 292 minecraft:light[level=12]
setblock 165 148 299 minecraft:light[level=12]
setblock 165 148 306 minecraft:light[level=12]
setblock 165 148 313 minecraft:light[level=12]
setblock 166 148 276 minecraft:snow_block
fill 166 148 277 169 148 277 minecraft:packed_ice
setblock 166 148 315 minecraft:packed_ice
setblock 166 148 316 minecraft:snow_block
fill 167 148 276 170 148 276 minecraft:packed_ice
setblock 167 148 315 minecraft:snow_block
fill 167 148 316 170 148 316 minecraft:packed_ice
setblock 168 148 279 minecraft:snow_block
setblock 168 148 286 minecraft:light[level=15]
setblock 168 148 294 minecraft:light[level=15]
setblock 168 148 302 minecraft:light[level=15]
setblock 168 148 310 minecraft:light[level=15]
fill 168 148 315 170 148 315 minecraft:packed_ice
setblock 169 148 278 minecraft:snow_block
setblock 170 148 277 minecraft:snow_block
setblock 170 148 278 minecraft:packed_ice
setblock 171 148 275 minecraft:light_blue_concrete
setblock 171 148 276 minecraft:snow_block
setblock 171 148 277 minecraft:packed_ice
fill 171 148 295 171 149 296 minecraft:packed_ice
setblock 171 148 316 minecraft:snow_block
fill 172 148 276 174 148 276 minecraft:packed_ice
setblock 172 148 278 minecraft:light[level=12]
setblock 172 148 285 minecraft:light[level=12]
setblock 172 148 292 minecraft:light[level=12]
fill 172 148 294 173 149 294 minecraft:packed_ice
fill 172 148 297 173 149 297 minecraft:packed_ice
setblock 172 148 299 minecraft:light[level=12]
setblock 172 148 306 minecraft:light[level=12]
setblock 172 148 313 minecraft:light[level=12]
fill 172 148 316 174 148 316 minecraft:packed_ice
fill 174 148 295 174 149 296 minecraft:packed_ice
setblock 176 148 278 minecraft:light[level=15]
setblock 176 148 286 minecraft:light[level=15]
setblock 176 148 294 minecraft:light[level=15]
setblock 176 148 302 minecraft:light[level=15]
setblock 176 148 310 minecraft:light[level=15]
setblock 179 148 278 minecraft:light[level=12]
setblock 179 148 285 minecraft:light[level=12]
setblock 179 148 292 minecraft:light[level=12]
setblock 179 148 299 minecraft:light[level=12]
setblock 179 148 306 minecraft:light[level=12]
setblock 179 148 313 minecraft:light[level=12]
setblock 181 148 300 minecraft:packed_ice
setblock 181 148 301 minecraft:snow_block
fill 181 148 302 181 151 302 minecraft:packed_ice
setblock 181 148 306 minecraft:snow_block
fill 181 148 307 181 151 307 minecraft:packed_ice
setblock 182 148 280 minecraft:snow_block
fill 182 148 281 182 151 281 minecraft:packed_ice
setblock 182 148 285 minecraft:snow_block
setblock 182 148 296 minecraft:packed_ice
setblock 182 148 300 minecraft:snow_block
fill 182 148 301 182 151 301 minecraft:packed_ice
setblock 182 148 305 minecraft:snow_block
fill 182 148 306 182 151 306 minecraft:packed_ice
setblock 182 148 310 minecraft:snow_block
fill 182 148 311 182 151 311 minecraft:packed_ice
fill 142 149 275 142 175 275 minecraft:blue_ice
setblock 142 149 279 minecraft:snow_block
fill 142 149 280 142 152 280 minecraft:packed_ice
setblock 142 149 284 minecraft:snow_block
fill 142 149 285 142 149 288 minecraft:packed_ice
setblock 142 149 289 minecraft:snow_block
fill 142 149 290 142 149 293 minecraft:packed_ice
setblock 142 149 294 minecraft:snow_block
fill 142 149 295 142 149 298 minecraft:packed_ice
setblock 142 149 299 minecraft:snow_block
fill 142 149 300 142 152 300 minecraft:packed_ice
setblock 142 149 304 minecraft:snow_block
fill 142 149 305 142 152 305 minecraft:packed_ice
setblock 142 149 309 minecraft:snow_block
fill 142 149 310 142 152 310 minecraft:packed_ice
setblock 143 149 283 minecraft:snow_block
fill 143 149 284 143 152 284 minecraft:packed_ice
setblock 143 149 288 minecraft:snow_block
fill 143 149 289 143 152 289 minecraft:packed_ice
fill 143 149 295 143 149 297 minecraft:packed_ice
setblock 143 149 298 minecraft:snow_block
fill 143 149 299 143 152 299 minecraft:packed_ice
setblock 143 149 303 minecraft:snow_block
fill 143 149 304 143 152 304 minecraft:packed_ice
setblock 143 149 307 minecraft:packed_ice
setblock 143 149 308 minecraft:snow_block
fill 143 149 309 143 152 309 minecraft:packed_ice
setblock 144 149 282 minecraft:snow_block
fill 144 149 283 144 152 283 minecraft:packed_ice
setblock 144 149 286 minecraft:packed_ice
setblock 144 149 287 minecraft:snow_block
fill 144 149 288 144 152 288 minecraft:packed_ice
setblock 144 149 302 minecraft:snow_block
fill 144 149 303 144 152 303 minecraft:packed_ice
setblock 144 149 307 minecraft:snow_block
setblock 145 149 276 minecraft:snow_block
setblock 145 149 296 minecraft:packed_ice
fill 146 149 276 149 149 276 minecraft:packed_ice
setblock 148 149 296 minecraft:packed_ice
setblock 149 149 288 minecraft:packed_ice
setblock 150 149 276 minecraft:snow_block
setblock 150 149 289 minecraft:packed_ice
setblock 150 149 295 minecraft:packed_ice
fill 151 149 291 151 149 293 minecraft:packed_ice
setblock 159 149 276 minecraft:packed_ice
setblock 160 149 276 minecraft:snow_block
fill 161 149 276 163 149 277 minecraft:packed_ice
setblock 163 149 278 minecraft:snow_block
fill 163 149 316 164 149 316 minecraft:packed_ice
setblock 164 149 276 minecraft:packed_ice
setblock 164 149 277 minecraft:snow_block
fill 164 149 278 167 149 278 minecraft:packed_ice
setblock 165 149 276 minecraft:snow_block
fill 165 149 277 168 149 277 minecraft:packed_ice
setblock 165 149 316 minecraft:snow_block
fill 166 149 276 169 149 276 minecraft:packed_ice
fill 166 149 316 169 149 316 minecraft:packed_ice
fill 167 149 315 168 149 315 minecraft:packed_ice
setblock 168 149 278 minecraft:snow_block
setblock 169 149 277 minecraft:snow_block
setblock 170 149 276 minecraft:snow_block
setblock 170 149 277 minecraft:packed_ice
setblock 170 149 316 minecraft:snow_block
fill 171 149 275 171 179 275 minecraft:blue_ice
fill 171 149 276 172 149 276 minecraft:packed_ice
setblock 171 149 294 minecraft:packed_ice
setblock 171 149 297 minecraft:packed_ice
fill 171 149 316 172 149 316 minecraft:packed_ice
setblock 174 149 294 minecraft:packed_ice
setblock 174 149 297 minecraft:packed_ice
fill 181 149 298 181 155 298 minecraft:packed_ice
setblock 181 149 300 minecraft:snow_block
fill 181 149 301 181 152 301 minecraft:packed_ice
setblock 181 149 305 minecraft:snow_block
fill 181 149 306 181 152 306 minecraft:packed_ice
fill 181 149 308 181 149 309 minecraft:packed_ice
setblock 181 149 310 minecraft:snow_block
setblock 182 149 280 minecraft:packed_ice
setblock 182 149 283 minecraft:packed_ice
setblock 182 149 284 minecraft:snow_block
fill 182 149 285 182 151 286 minecraft:packed_ice
setblock 182 149 299 minecraft:snow_block
fill 182 149 300 182 152 300 minecraft:packed_ice
setblock 182 149 304 minecraft:snow_block
fill 182 149 305 182 152 305 minecraft:packed_ice
setblock 182 149 308 minecraft:packed_ice
setblock 182 149 309 minecraft:snow_block
fill 182 149 310 182 152 310 minecraft:packed_ice
setblock 182 149 314 minecraft:snow_block
fill 183 149 291 183 179 291 minecraft:blue_ice
setblock 183 149 292 minecraft:light_blue_concrete
setblock 141 150 299 minecraft:white_concrete
fill 142 150 279 142 153 279 minecraft:packed_ice
setblock 142 150 283 minecraft:snow_block
fill 142 150 284 142 150 287 minecraft:packed_ice
setblock 142 150 288 minecraft:snow_block
fill 142 150 289 142 150 292 minecraft:packed_ice
setblock 142 150 293 minecraft:snow_block
fill 142 150 294 142 150 297 minecraft:packed_ice
setblock 142 150 298 minecraft:snow_block
fill 142 150 299 142 153 299 minecraft:packed_ice
setblock 142 150 303 minecraft:snow_block
fill 142 150 304 142 153 304 minecraft:packed_ice
setblock 142 150 308 minecraft:snow_block
fill 142 150 309 142 153 309 minecraft:packed_ice
setblock 143 150 282 minecraft:snow_block
fill 143 150 283 143 153 283 minecraft:packed_ice
setblock 143 150 286 minecraft:packed_ice
setblock 143 150 287 minecraft:snow_block
fill 143 150 288 143 153 288 minecraft:packed_ice
setblock 143 150 291 minecraft:packed_ice
setblock 143 150 292 minecraft:snow_block
setblock 143 150 296 minecraft:packed_ice
setblock 143 150 297 minecraft:snow_block
fill 143 150 298 143 153 298 minecraft:packed_ice
setblock 143 150 302 minecraft:snow_block
fill 143 150 303 143 153 303 minecraft:packed_ice
setblock 143 150 307 minecraft:snow_block
fill 143 150 308 143 153 308 minecraft:packed_ice
setblock 144 150 286 minecraft:snow_block
fill 144 150 287 144 153 287 minecraft:packed_ice
setblock 144 150 301 minecraft:snow_block
fill 144 150 302 144 151 302 minecraft:packed_ice
setblock 144 150 306 minecraft:snow_block
fill 144 150 307 144 153 307 minecraft:packed_ice
fill 146 150 291 147 150 293 minecraft:blue_ice
setblock 159 150 317 minecraft:white_concrete
fill 160 150 276 163 150 276 minecraft:packed_ice
setblock 162 150 277 minecraft:packed_ice
setblock 163 150 277 minecraft:snow_block
setblock 163 150 316 minecraft:packed_ice
setblock 164 150 276 minecraft:snow_block
fill 164 150 277 166 150 278 minecraft:packed_ice
setblock 164 150 316 minecraft:snow_block
fill 165 150 276 168 150 276 minecraft:packed_ice
fill 165 150 316 168 150 316 minecraft:packed_ice
setblock 167 150 277 minecraft:packed_ice
setblock 168 150 277 minecraft:snow_block
setblock 169 150 276 minecraft:snow_block
setblock 169 150 277 minecraft:packed_ice
setblock 169 150 316 minecraft:snow_block
fill 170 150 276 171 150 276 minecraft:packed_ice
fill 170 150 316 171 150 316 minecraft:packed_ice
fill 174 150 281 174 151 281 minecraft:packed_ice
fill 175 150 280 175 151 280 minecraft:packed_ice
fill 175 150 282 175 151 282 minecraft:packed_ice
fill 176 150 281 176 151 281 minecraft:packed_ice
setblock 176 150 310 minecraft:packed_ice
fill 177 150 309 177 153 309 minecraft:packed_ice
setblock 177 150 311 minecraft:packed_ice
fill 178 150 310 178 153 310 minecraft:packed_ice
setblock 181 150 304 minecraft:snow_block
fill 181 150 305 181 153 305 minecraft:packed_ice
setblock 181 150 308 minecraft:packed_ice
setblock 181 150 309 minecraft:snow_block
fill 181 150 310 181 153 310 minecraft:packed_ice
setblock 182 150 283 minecraft:snow_block
fill 182 150 284 182 153 284 minecraft:packed_ice
setblock 182 150 287 minecraft:packed_ice
setblock 182 150 288 minecraft:snow_block
setblock 182 150 298 minecraft:snow_block
fill 182 150 299 182 153 299 minecraft:packed_ice
setblock 182 150 303 minecraft:snow_block
fill 182 150 304 182 153 304 minecraft:packed_ice
setblock 182 150 308 minecraft:snow_block
fill 182 150 309 182 153 309 minecraft:packed_ice
setblock 182 150 313 minecraft:snow_block
fill 182 150 314 182 153 314 minecraft:packed_ice
fill 183 150 292 183 162 292 minecraft:blue_ice
fill 141 151 299 141 179 299 minecraft:blue_ice
setblock 142 151 282 minecraft:snow_block
fill 142 151 283 142 151 286 minecraft:packed_ice
setblock 142 151 287 minecraft:snow_block
fill 142 151 288 142 151 291 minecraft:packed_ice
setblock 142 151 292 minecraft:snow_block
fill 142 151 293 142 151 296 minecraft:packed_ice
setblock 142 151 297 minecraft:snow_block
fill 142 151 298 142 154 298 minecraft:packed_ice
setblock 142 151 302 minecraft:snow_block
fill 142 151 303 142 154 303 minecraft:packed_ice
setblock 142 151 307 minecraft:snow_block
fill 142 151 308 142 154 308 minecraft:packed_ice
setblock 142 151 312 minecraft:snow_block
setblock 143 151 281 minecraft:snow_block
fill 143 151 282 143 154 282 minecraft:packed_ice
setblock 143 151 285 minecraft:packed_ice
setblock 143 151 286 minecraft:snow_block
fill 143 151 287 143 154 287 minecraft:packed_ice
setblock 143 151 291 minecraft:snow_block
fill 143 151 292 143 153 293 minecraft:packed_ice
fill 143 151 297 143 154 297 minecraft:packed_ice
setblock 143 151 301 minecraft:snow_block
fill 143 151 302 143 154 302 minecraft:packed_ice
setblock 143 151 306 minecraft:snow_block
fill 143 151 307 143 154 307 minecraft:packed_ice
setblock 143 151 310 minecraft:packed_ice
setblock 144 151 285 minecraft:snow_block
fill 144 151 286 144 154 286 minecraft:packed_ice
setblock 144 151 289 minecraft:packed_ice
setblock 144 151 301 minecraft:packed_ice
setblock 144 151 305 minecraft:snow_block
fill 144 151 306 144 154 306 minecraft:packed_ice
fill 146 151 291 147 151 292 minecraft:blue_ice
fill 156 151 305 157 211 306 minecraft:snow_block
fill 159 151 317 159 160 317 minecraft:blue_ice
fill 160 151 276 162 151 276 minecraft:packed_ice
fill 161 151 275 162 158 275 minecraft:blue_ice
setblock 162 151 277 minecraft:snow_block
setblock 162 151 316 minecraft:packed_ice
setblock 163 151 275 minecraft:light_blue_concrete
setblock 163 151 276 minecraft:snow_block
fill 163 151 277 166 151 277 minecraft:packed_ice
setblock 163 151 316 minecraft:snow_block
fill 164 151 275 164 175 275 minecraft:blue_ice
fill 164 151 276 167 151 276 minecraft:packed_ice
fill 164 151 316 167 151 316 minecraft:packed_ice
setblock 167 151 277 minecraft:snow_block
setblock 168 151 276 minecraft:snow_block
setblock 168 151 316 minecraft:snow_block
fill 169 151 276 170 151 276 minecraft:packed_ice
fill 169 151 316 170 153 316 minecraft:packed_ice
fill 175 151 311 178 159 313 minecraft:snow_block
fill 176 151 310 177 211 310 minecraft:snow_block
fill 180 151 305 180 152 307 minecraft:packed_ice
setblock 181 151 303 minecraft:snow_block
fill 181 151 304 181 154 304 minecraft:packed_ice
setblock 181 151 308 minecraft:snow_block
fill 181 151 309 181 154 309 minecraft:packed_ice
fill 181 151 311 181 152 311 minecraft:packed_ice
setblock 182 151 282 minecraft:snow_block
fill 182 151 283 182 154 283 minecraft:packed_ice
setblock 182 151 287 minecraft:snow_block
fill 182 151 288 182 152 290 minecraft:packed_ice
setblock 182 151 297 minecraft:snow_block
fill 182 151 298 182 159 298 minecraft:packed_ice
setblock 182 151 302 minecraft:snow_block
fill 182 151 303 182 154 303 minecraft:packed_ice
setblock 182 151 307 minecraft:snow_block
fill 182 151 308 182 154 308 minecraft:packed_ice
setblock 182 151 312 minecraft:snow_block
fill 182 151 313 182 154 313 minecraft:packed_ice
setblock 142 152 281 minecraft:snow_block
fill 142 152 282 142 152 285 minecraft:packed_ice
setblock 142 152 286 minecraft:snow_block
fill 142 152 287 142 152 290 minecraft:packed_ice
setblock 142 152 291 minecraft:snow_block
fill 142 152 292 142 152 295 minecraft:packed_ice
setblock 142 152 296 minecraft:snow_block
fill 142 152 297 142 155 297 minecraft:packed_ice
setblock 142 152 301 minecraft:snow_block
fill 142 152 302 142 155 302 minecraft:packed_ice
setblock 142 152 306 minecraft:snow_block
fill 142 152 307 142 155 307 minecraft:packed_ice
setblock 142 152 311 minecraft:snow_block
fill 142 152 312 142 155 312 minecraft:packed_ice
fill 143 152 281 143 155 281 minecraft:packed_ice
setblock 143 152 285 minecraft:snow_block
fill 143 152 286 143 155 286 minecraft:packed_ice
setblock 143 152 290 minecraft:snow_block
fill 143 152 291 143 155 291 minecraft:packed_ice
fill 143 152 294 143 152 296 minecraft:packed_ice
setblock 143 152 300 minecraft:snow_block
fill 143 152 301 143 155 301 minecraft:packed_ice
setblock 143 152 305 minecraft:snow_block
fill 143 152 306 143 155 306 minecraft:packed_ice
setblock 143 152 310 minecraft:snow_block
setblock 144 152 284 minecraft:snow_block
fill 144 152 285 144 155 285 minecraft:packed_ice
setblock 144 152 289 minecraft:snow_block
fill 144 152 290 144 155 290 minecraft:packed_ice
setblock 144 152 304 minecraft:snow_block
fill 144 152 305 144 154 305 minecraft:packed_ice
fill 146 152 292 147 153 292 minecraft:blue_ice
fill 155 152 306 155 153 306 minecraft:packed_ice
fill 156 152 304 157 153 304 minecraft:packed_ice
fill 156 152 307 157 153 307 minecraft:packed_ice
fill 158 152 305 158 153 306 minecraft:packed_ice
fill 160 152 276 161 152 276 minecraft:packed_ice
setblock 162 152 276 minecraft:snow_block
fill 162 152 277 165 152 277 minecraft:packed_ice
setblock 162 152 316 minecraft:snow_block
fill 163 152 275 163 176 275 minecraft:blue_ice
fill 163 152 276 166 152 276 minecraft:packed_ice
fill 163 152 316 166 152 316 minecraft:packed_ice
fill 164 152 312 164 158 312 minecraft:packed_ice
fill 165 152 315 167 152 315 minecraft:packed_ice
setblock 166 152 277 minecraft:snow_block
setblock 167 152 276 minecraft:snow_block
setblock 167 152 316 minecraft:snow_block
fill 168 152 276 169 152 276 minecraft:packed_ice
fill 168 152 316 168 155 316 minecraft:packed_ice
fill 174 152 311 174 153 313 minecraft:packed_ice
fill 175 152 279 175 158 279 minecraft:packed_ice
fill 175 152 310 175 153 310 minecraft:packed_ice
fill 175 152 314 178 153 314 minecraft:packed_ice
fill 179 152 311 179 153 313 minecraft:packed_ice
setblock 180 152 308 minecraft:snow_block
setblock 181 152 302 minecraft:snow_block
fill 181 152 303 181 155 303 minecraft:packed_ice
setblock 181 152 307 minecraft:snow_block
fill 181 152 308 181 155 308 minecraft:packed_ice
setblock 181 152 312 minecraft:snow_block
setblock 182 152 281 minecraft:snow_block
fill 182 152 282 182 155 282 minecraft:packed_ice
setblock 182 152 285 minecraft:packed_ice
setblock 182 152 286 minecraft:snow_block
fill 182 152 287 182 155 287 minecraft:packed_ice
setblock 182 152 291 minecraft:snow_block
fill 182 152 292 182 152 295 minecraft:packed_ice
setblock 182 152 296 minecraft:snow_block
fill 182 152 297 182 155 297 minecraft:packed_ice
setblock 182 152 301 minecraft:snow_block
fill 182 152 302 182 155 302 minecraft:packed_ice
setblock 182 152 306 minecraft:snow_block
fill 182 152 307 182 155 307 minecraft:packed_ice
setblock 182 152 311 minecraft:snow_block
fill 182 152 312 182 155 312 minecraft:packed_ice
setblock 182 152 315 minecraft:packed_ice
setblock 142 153 280 minecraft:snow_block
fill 142 153 281 142 153 284 minecraft:packed_ice
setblock 142 153 285 minecraft:snow_block
fill 142 153 286 142 153 289 minecraft:packed_ice
setblock 142 153 290 minecraft:snow_block
fill 142 153 291 142 153 294 minecraft:packed_ice
setblock 142 153 295 minecraft:snow_block
fill 142 153 296 143 155 296 minecraft:packed_ice
setblock 142 153 300 minecraft:snow_block
fill 142 153 301 142 156 301 minecraft:packed_ice
setblock 142 153 305 minecraft:snow_block
fill 142 153 306 142 156 306 minecraft:packed_ice
setblock 142 153 310 minecraft:snow_block
fill 142 153 311 143 155 311 minecraft:packed_ice
fill 142 153 313 142 154 313 minecraft:packed_ice
setblock 143 153 284 minecraft:snow_block
fill 143 153 285 143 156 285 minecraft:packed_ice
setblock 143 153 289 minecraft:snow_block
fill 143 153 290 143 156 290 minecraft:packed_ice
setblock 143 153 294 minecraft:snow_block
fill 143 153 295 143 161 295 minecraft:packed_ice
setblock 143 153 299 minecraft:snow_block
fill 143 153 300 143 156 300 minecraft:packed_ice
setblock 143 153 304 minecraft:snow_block
fill 143 153 305 143 156 305 minecraft:packed_ice
setblock 143 153 309 minecraft:snow_block
fill 143 153 310 143 156 310 minecraft:packed_ice
setblock 144 153 283 minecraft:snow_block
fill 144 153 284 144 156 284 minecraft:packed_ice
setblock 144 153 288 minecraft:snow_block
fill 144 153 289 144 156 289 minecraft:packed_ice
fill 144 153 291 144 153 292 minecraft:packed_ice
setblock 144 153 304 minecraft:packed_ice
setblock 145 153 286 minecraft:packed_ice
setblock 145 153 287 minecraft:snow_block
setblock 155 153 305 minecraft:packed_ice
setblock 158 153 307 minecraft:packed_ice
fill 159 153 276 160 153 276 minecraft:packed_ice
setblock 161 153 276 minecraft:snow_block
setblock 161 153 316 minecraft:snow_block
fill 162 153 276 164 153 277 minecraft:packed_ice
fill 162 153 316 165 153 316 minecraft:packed_ice
fill 163 153 315 166 153 315 minecraft:packed_ice
setblock 165 153 276 minecraft:packed_ice
setblock 165 153 277 minecraft:snow_block
setblock 166 153 275 minecraft:light_blue_concrete
setblock 166 153 276 minecraft:snow_block
setblock 166 153 316 minecraft:snow_block
fill 167 153 276 168 155 276 minecraft:packed_ice
setblock 167 153 315 minecraft:snow_block
fill 167 153 316 167 156 316 minecraft:packed_ice
fill 173 153 311 173 153 312 minecraft:packed_ice
setblock 174 153 310 minecraft:packed_ice
setblock 174 153 314 minecraft:packed_ice
fill 175 153 309 176 153 309 minecraft:packed_ice
fill 175 153 315 178 153 315 minecraft:packed_ice
setblock 178 153 309 minecraft:packed_ice
fill 179 153 310 180 153 310 minecraft:packed_ice
setblock 179 153 314 minecraft:packed_ice
fill 180 153 304 180 153 306 minecraft:packed_ice
setblock 180 153 307 minecraft:snow_block
fill 180 153 308 180 155 309 minecraft:packed_ice
fill 180 153 311 180 153 313 minecraft:packed_ice
setblock 181 153 300 minecraft:packed_ice
setblock 181 153 301 minecraft:snow_block
fill 181 153 302 181 156 302 minecraft:packed_ice
setblock 181 153 306 minecraft:snow_block
fill 181 153 307 181 156 307 minecraft:packed_ice
setblock 181 153 311 minecraft:snow_block
fill 181 153 312 181 155 313 minecraft:packed_ice
fill 182 153 281 182 156 281 minecraft:packed_ice
setblock 182 153 285 minecraft:snow_block
fill 182 153 286 182 156 286 minecraft:packed_ice
fill 182 153 288 182 153 289 minecraft:packed_ice
setblock 182 153 290 minecraft:snow_block
fill 182 153 291 182 153 294 minecraft:packed_ice
setblock 182 153 295 minecraft:snow_block
fill 182 153 296 182 156 296 minecraft:packed_ice
setblock 182 153 300 minecraft:snow_block
fill 182 153 301 182 156 301 minecraft:packed_ice
setblock 182 153 305 minecraft:snow_block
fill 182 153 306 182 156 306 minecraft:packed_ice
setblock 182 153 310 minecraft:snow_block
fill 182 153 311 182 156 311 minecraft:packed_ice
setblock 182 153 315 minecraft:snow_block
setblock 142 154 279 minecraft:snow_block
fill 142 154 280 142 154 283 minecraft:packed_ice
setblock 142 154 284 minecraft:snow_block
fill 142 154 285 142 154 288 minecraft:packed_ice
setblock 142 154 289 minecraft:snow_block
fill 142 154 290 142 154 293 minecraft:packed_ice
setblock 142 154 294 minecraft:snow_block
fill 142 154 295 142 162 295 minecraft:packed_ice
setblock 142 154 299 minecraft:snow_block
fill 142 154 300 142 157 300 minecraft:packed_ice
setblock 142 154 304 minecraft:snow_block
fill 142 154 305 142 157 305 minecraft:packed_ice
setblock 142 154 309 minecraft:snow_block
fill 142 154 310 142 157 310 minecraft:packed_ice
setblock 142 154 314 minecraft:snow_block
setblock 143 154 283 minecraft:snow_block
fill 143 154 284 143 157 284 minecraft:packed_ice
setblock 143 154 288 minecraft:snow_block
fill 143 154 289 143 157 289 minecraft:packed_ice
setblock 143 154 292 minecraft:packed_ice
setblock 143 154 293 minecraft:snow_block
fill 143 154 294 143 162 294 minecraft:packed_ice
setblock 143 154 298 minecraft:snow_block
fill 143 154 299 143 157 299 minecraft:packed_ice
setblock 143 154 303 minecraft:snow_block
fill 143 154 304 143 157 304 minecraft:packed_ice
setblock 143 154 308 minecraft:snow_block
fill 143 154 309 143 157 309 minecraft:packed_ice
setblock 143 154 312 minecraft:packed_ice
setblock 144 154 278 minecraft:light[level=12]
fill 144 154 283 144 157 283 minecraft:packed_ice
setblock 144 154 287 minecraft:snow_block
fill 144 154 288 145 156 288 minecraft:packed_ice
setblock 144 154 291 minecraft:packed_ice
setblock 144 154 292 minecraft:snow_block
fill 144 154 293 144 157 293 minecraft:packed_ice
setblock 144 154 299 minecraft:light[level=12]
setblock 144 154 307 minecraft:snow_block
fill 144 154 308 144 156 308 minecraft:packed_ice
setblock 144 154 313 minecraft:light[level=12]
setblock 145 154 285 minecraft:packed_ice
setblock 145 154 286 minecraft:snow_block
fill 145 154 287 145 157 287 minecraft:packed_ice
fill 145 154 289 145 155 289 minecraft:packed_ice
setblock 151 154 278 minecraft:light[level=12]
setblock 151 154 285 minecraft:light[level=12]
setblock 151 154 292 minecraft:light[level=12]
setblock 151 154 299 minecraft:light[level=12]
setblock 151 154 306 minecraft:light[level=12]
setblock 151 154 313 minecraft:light[level=12]
fill 158 154 276 159 154 276 minecraft:packed_ice
setblock 158 154 278 minecraft:light[level=12]
setblock 158 154 285 minecraft:light[level=12]
setblock 158 154 292 minecraft:light[level=12]
setblock 158 154 299 minecraft:light[level=12]
setblock 158 154 306 minecraft:light[level=12]
setblock 158 154 313 minecraft:light[level=12]
setblock 159 154 316 minecraft:packed_ice
setblock 160 154 276 minecraft:snow_block
setblock 160 154 316 minecraft:snow_block
fill 161 154 276 163 154 277 minecraft:packed_ice
setblock 161 154 315 minecraft:snow_block
fill 161 154 316 164 154 316 minecraft:packed_ice
fill 162 154 315 165 154 315 minecraft:packed_ice
fill 162 154 317 164 175 317 minecraft:blue_ice
setblock 164 154 276 minecraft:packed_ice
setblock 164 154 277 minecraft:snow_block
setblock 165 154 276 minecraft:snow_block
fill 165 154 277 165 157 277 minecraft:packed_ice
setblock 165 154 278 minecraft:light[level=12]
setblock 165 154 285 minecraft:light[level=12]
setblock 165 154 292 minecraft:light[level=12]
setblock 165 154 299 minecraft:light[level=12]
setblock 165 154 306 minecraft:light[level=12]
setblock 165 154 313 minecraft:light[level=12]
setblock 165 154 316 minecraft:snow_block
setblock 165 154 317 minecraft:light_blue_concrete
fill 166 154 275 166 179 275 minecraft:blue_ice
fill 166 154 276 166 157 276 minecraft:packed_ice
setblock 166 154 315 minecraft:snow_block
fill 166 154 316 166 157 316 minecraft:packed_ice
fill 166 154 317 168 176 317 minecraft:blue_ice
fill 167 154 315 168 156 315 minecraft:packed_ice
setblock 169 154 316 minecraft:packed_ice
setblock 170 154 316 minecraft:snow_block
setblock 172 154 278 minecraft:light[level=12]
setblock 172 154 285 minecraft:light[level=12]
setblock 172 154 292 minecraft:light[level=12]
setblock 172 154 299 minecraft:light[level=12]
setblock 172 154 306 minecraft:light[level=12]
setblock 172 154 313 minecraft:light[level=12]
fill 178 154 317 178 179 317 minecraft:blue_ice
setblock 179 154 278 minecraft:light[level=12]
setblock 179 154 285 minecraft:light[level=12]
setblock 179 154 292 minecraft:light[level=12]
setblock 179 154 299 minecraft:light[level=12]
setblock 179 154 306 minecraft:light[level=12]
setblock 179 154 313 minecraft:light[level=12]
setblock 179 154 317 minecraft:light_blue_concrete
fill 180 154 298 180 155 298 minecraft:packed_ice
fill 180 154 304 180 154 305 minecraft:packed_ice
setblock 180 154 306 minecraft:snow_block
fill 180 154 307 180 157 307 minecraft:packed_ice
setblock 180 154 310 minecraft:packed_ice
setblock 180 154 311 minecraft:snow_block
setblock 180 154 316 minecraft:snow_block
setblock 181 154 285 minecraft:snow_block
fill 181 154 286 181 154 289 minecraft:packed_ice
setblock 181 154 290 minecraft:snow_block
fill 181 154 291 182 156 291 minecraft:packed_ice
fill 181 154 297 181 156 297 minecraft:packed_ice
fill 181 154 299 181 159 299 minecraft:packed_ice
setblock 181 154 300 minecraft:snow_block
fill 181 154 301 181 157 301 minecraft:packed_ice
setblock 181 154 305 minecraft:snow_block
fill 181 154 306 181 157 306 minecraft:packed_ice
setblock 181 154 310 minecraft:snow_block
fill 181 154 311 181 157 311 minecraft:packed_ice
setblock 181 154 314 minecraft:packed_ice
fill 181 154 316 182 156 316 minecraft:packed_ice
setblock 182 154 284 minecraft:snow_block
fill 182 154 285 182 157 285 minecraft:packed_ice
setblock 182 154 288 minecraft:packed_ice
setblock 182 154 289 minecraft:snow_block
fill 182 154 290 182 157 290 minecraft:packed_ice
fill 182 154 292 182 154 293 minecraft:packed_ice
setblock 182 154 294 minecraft:snow_block
fill 182 154 295 182 157 295 minecraft:packed_ice
setblock 182 154 299 minecraft:snow_block
fill 182 154 300 182 157 300 minecraft:packed_ice
setblock 182 154 304 minecraft:snow_block
fill 182 154 305 182 157 305 minecraft:packed_ice
setblock 182 154 309 minecraft:snow_block
fill 182 154 310 182 157 310 minecraft:packed_ice
setblock 182 154 314 minecraft:snow_block
fill 182 154 315 182 157 315 minecraft:packed_ice
setblock 183 154 289 minecraft:white_concrete
setblock 141 155 312 minecraft:light_blue_concrete
setblock 142 155 278 minecraft:snow_block
fill 142 155 279 142 155 282 minecraft:packed_ice
setblock 142 155 283 minecraft:snow_block
fill 142 155 284 142 155 287 minecraft:packed_ice
setblock 142 155 288 minecraft:snow_block
fill 142 155 289 142 155 292 minecraft:packed_ice
setblock 142 155 293 minecraft:snow_block
fill 142 155 294 142 158 294 minecraft:packed_ice
setblock 142 155 298 minecraft:snow_block
fill 142 155 299 142 158 299 minecraft:packed_ice
setblock 142 155 303 minecraft:snow_block
fill 142 155 304 142 158 304 minecraft:packed_ice
setblock 142 155 308 minecraft:snow_block
fill 142 155 309 142 158 309 minecraft:packed_ice
setblock 142 155 313 minecraft:snow_block
fill 142 155 314 142 156 316 minecraft:packed_ice
fill 143 155 280 143 156 280 minecraft:packed_ice
setblock 143 155 282 minecraft:snow_block
fill 143 155 283 143 158 283 minecraft:packed_ice
setblock 143 155 287 minecraft:snow_block
fill 143 155 288 143 158 288 minecraft:packed_ice
setblock 143 155 292 minecraft:snow_block
fill 143 155 293 143 158 293 minecraft:packed_ice
setblock 143 155 297 minecraft:snow_block
fill 143 155 298 143 158 298 minecraft:packed_ice
setblock 143 155 302 minecraft:snow_block
fill 143 155 303 143 158 303 minecraft:packed_ice
setblock 143 155 307 minecraft:snow_block
fill 143 155 308 143 158 308 minecraft:packed_ice
setblock 143 155 312 minecraft:snow_block
fill 143 155 313 143 158 313 minecraft:packed_ice
setblock 143 155 316 minecraft:packed_ice
fill 144 155 282 144 156 282 minecraft:packed_ice
setblock 144 155 286 minecraft:snow_block
fill 144 155 287 144 158 287 minecraft:packed_ice
setblock 144 155 291 minecraft:snow_block
fill 144 155 292 144 158 292 minecraft:packed_ice
fill 144 155 294 144 156 294 minecraft:packed_ice
setblock 144 155 306 minecraft:snow_block
fill 144 155 307 144 156 307 minecraft:packed_ice
setblock 145 155 285 minecraft:snow_block
fill 145 155 286 145 158 286 minecraft:packed_ice
setblock 145 155 290 minecraft:snow_block
setblock 146 155 275 minecraft:light_blue_concrete
fill 157 155 276 158 155 276 minecraft:packed_ice
setblock 158 155 316 minecraft:packed_ice
setblock 159 155 276 minecraft:snow_block
setblock 159 155 316 minecraft:snow_block
fill 160 155 276 162 155 277 minecraft:packed_ice
setblock 160 155 315 minecraft:snow_block
fill 160 155 316 163 155 316 minecraft:packed_ice
fill 161 155 315 164 155 315 minecraft:packed_ice
fill 162 155 314 165 155 314 minecraft:packed_ice
setblock 163 155 276 minecraft:packed_ice
setblock 163 155 277 minecraft:snow_block
setblock 164 155 276 minecraft:snow_block
fill 164 155 277 164 158 277 minecraft:packed_ice
setblock 164 155 316 minecraft:snow_block
fill 165 155 276 165 158 276 minecraft:packed_ice
setblock 165 155 315 minecraft:snow_block
fill 165 155 316 165 158 316 minecraft:packed_ice
fill 165 155 317 165 179 317 minecraft:blue_ice
setblock 166 155 314 minecraft:snow_block
fill 166 155 315 166 158 315 minecraft:packed_ice
fill 167 155 314 167 158 314 minecraft:packed_ice
setblock 168 155 275 minecraft:white_concrete
fill 169 155 275 170 175 275 minecraft:blue_ice
setblock 169 155 315 minecraft:packed_ice
setblock 169 155 316 minecraft:snow_block
fill 170 155 316 171 157 316 minecraft:packed_ice
setblock 177 155 275 minecraft:white_concrete
fill 177 155 316 178 155 316 minecraft:packed_ice
setblock 179 155 316 minecraft:snow_block
fill 179 155 317 179 179 317 minecraft:blue_ice
fill 180 155 303 180 155 304 minecraft:packed_ice
setblock 180 155 305 minecraft:snow_block
fill 180 155 306 180 158 306 minecraft:packed_ice
setblock 180 155 310 minecraft:snow_block
fill 180 155 311 180 157 312 minecraft:packed_ice
setblock 180 155 315 minecraft:snow_block
fill 180 155 316 180 158 316 minecraft:packed_ice
setblock 181 155 284 minecraft:snow_block
fill 181 155 285 181 155 288 minecraft:packed_ice
setblock 181 155 289 minecraft:snow_block
fill 181 155 290 181 158 290 minecraft:packed_ice
fill 181 155 292 181 155 293 minecraft:packed_ice
setblock 181 155 294 minecraft:snow_block
fill 181 155 295 181 157 296 minecraft:packed_ice
fill 181 155 300 181 158 300 minecraft:packed_ice
setblock 181 155 304 minecraft:snow_block
fill 181 155 305 181 158 305 minecraft:packed_ice
setblock 181 155 309 minecraft:snow_block
fill 181 155 310 181 158 310 minecraft:packed_ice
setblock 181 155 314 minecraft:snow_block
fill 181 155 315 181 158 315 minecraft:packed_ice
setblock 182 155 283 minecraft:snow_block
fill 182 155 284 182 158 284 minecraft:packed_ice
setblock 182 155 288 minecraft:snow_block
fill 182 155 289 182 158 289 minecraft:packed_ice
setblock 182 155 292 minecraft:packed_ice
setblock 182 155 293 minecraft:snow_block
fill 182 155 294 182 158 294 minecraft:packed_ice
fill 182 155 299 182 158 299 minecraft:packed_ice
setblock 182 155 303 minecraft:snow_block
fill 182 155 304 182 158 304 minecraft:packed_ice
setblock 182 155 308 minecraft:snow_block
fill 182 155 309 182 158 309 minecraft:packed_ice
setblock 182 155 313 minecraft:snow_block
fill 182 155 314 182 158 314 minecraft:packed_ice
setblock 183 155 278 minecraft:white_concrete
fill 183 155 289 183 176 289 minecraft:blue_ice
fill 141 156 312 141 180 312 minecraft:blue_ice
setblock 142 156 276 minecraft:packed_ice
setblock 142 156 277 minecraft:snow_block
fill 142 156 278 142 156 281 minecraft:packed_ice
setblock 142 156 282 minecraft:snow_block
fill 142 156 283 142 156 286 minecraft:packed_ice
setblock 142 156 287 minecraft:snow_block
fill 142 156 288 142 156 291 minecraft:packed_ice
setblock 142 156 292 minecraft:snow_block
fill 142 156 293 142 159 293 minecraft:packed_ice
setblock 142 156 296 minecraft:packed_ice
setblock 142 156 297 minecraft:snow_block
fill 142 156 298 142 159 298 minecraft:packed_ice
setblock 142 156 302 minecraft:snow_block
fill 142 156 303 142 159 303 minecraft:packed_ice
setblock 142 156 307 minecraft:snow_block
fill 142 156 308 142 159 308 minecraft:packed_ice
setblock 142 156 311 minecraft:packed_ice
setblock 142 156 312 minecraft:snow_block
fill 142 156 313 142 159 313 minecraft:packed_ice
setblock 143 156 276 minecraft:snow_block
setblock 143 156 281 minecraft:snow_block
fill 143 156 282 143 159 282 minecraft:packed_ice
setblock 143 156 286 minecraft:snow_block
fill 143 156 287 143 159 287 minecraft:packed_ice
setblock 143 156 291 minecraft:snow_block
fill 143 156 292 143 159 292 minecraft:packed_ice
setblock 143 156 296 minecraft:snow_block
fill 143 156 297 143 159 297 minecraft:packed_ice
setblock 143 156 301 minecraft:snow_block
fill 143 156 302 143 158 302 minecraft:packed_ice
setblock 143 156 306 minecraft:snow_block
fill 143 156 307 143 159 307 minecraft:packed_ice
setblock 143 156 311 minecraft:snow_block
fill 143 156 312 143 159 312 minecraft:packed_ice
fill 143 156 314 143 157 314 minecraft:packed_ice
setblock 143 156 316 minecraft:snow_block
fill 144 156 276 146 157 276 minecraft:packed_ice
setblock 144 156 278 minecraft:light[level=15]
setblock 144 156 285 minecraft:snow_block
fill 144 156 286 144 159 286 minecraft:packed_ice
setblock 144 156 290 minecraft:snow_block
fill 144 156 291 145 158 291 minecraft:packed_ice
setblock 144 156 295 minecraft:snow_block
setblock 144 156 302 minecraft:light[level=15]
setblock 144 156 309 minecraft:packed_ice
setblock 144 156 310 minecraft:light[level=15]
fill 144 156 316 145 158 316 minecraft:packed_ice
fill 145 156 285 145 157 285 minecraft:packed_ice
setblock 145 156 289 minecraft:snow_block
fill 145 156 290 145 159 290 minecraft:packed_ice
fill 146 156 275 146 179 275 minecraft:blue_ice
setblock 152 156 278 minecraft:light[level=15]
setblock 152 156 286 minecraft:light[level=15]
setblock 152 156 294 minecraft:light[level=15]
setblock 152 156 302 minecraft:light[level=15]
setblock 152 156 310 minecraft:light[level=15]
setblock 153 156 275 minecraft:light_blue_concrete
fill 154 156 314 154 162 314 minecraft:packed_ice
fill 156 156 276 157 156 276 minecraft:packed_ice
fill 156 156 316 157 156 316 minecraft:packed_ice
setblock 158 156 276 minecraft:snow_block
setblock 158 156 315 minecraft:packed_ice
setblock 158 156 316 minecraft:snow_block
fill 159 156 276 161 156 277 minecraft:packed_ice
setblock 159 156 315 minecraft:snow_block
fill 159 156 316 162 156 316 minecraft:packed_ice
setblock 160 156 278 minecraft:light[level=15]
setblock 160 156 286 minecraft:light[level=15]
setblock 160 156 294 minecraft:light[level=15]
setblock 160 156 302 minecraft:light[level=15]
setblock 160 156 310 minecraft:light[level=15]
setblock 160 156 314 minecraft:snow_block
fill 160 156 315 163 156 315 minecraft:packed_ice
fill 161 156 314 164 156 314 minecraft:packed_ice
setblock 162 156 276 minecraft:packed_ice
setblock 162 156 277 minecraft:snow_block
setblock 163 156 276 minecraft:snow_block
fill 163 156 277 163 159 277 minecraft:packed_ice
fill 163 156 313 165 156 313 minecraft:packed_ice
setblock 163 156 316 minecraft:snow_block
fill 164 156 276 164 159 276 minecraft:packed_ice
setblock 164 156 315 minecraft:snow_block
fill 164 156 316 164 159 316 minecraft:packed_ice
setblock 165 156 314 minecraft:snow_block
fill 165 156 315 165 159 315 minecraft:packed_ice
fill 166 156 314 166 159 314 minecraft:packed_ice
setblock 167 156 276 minecraft:packed_ice
fill 168 156 275 168 176 275 minecraft:blue_ice
setblock 168 156 276 minecraft:snow_block
setblock 168 156 278 minecraft:light[level=15]
setblock 168 156 286 minecraft:light[level=15]
setblock 168 156 294 minecraft:light[level=15]
setblock 168 156 302 minecraft:light[level=15]
setblock 168 156 310 minecraft:light[level=15]
fill 168 156 314 168 157 314 minecraft:packed_ice
setblock 168 156 316 minecraft:snow_block
setblock 169 156 315 minecraft:snow_block
fill 169 156 316 169 159 316 minecraft:packed_ice
fill 170 156 315 170 159 315 minecraft:packed_ice
setblock 172 156 316 minecraft:packed_ice
setblock 173 156 316 minecraft:snow_block
fill 174 156 316 177 156 316 minecraft:packed_ice
setblock 176 156 278 minecraft:light[level=15]
setblock 176 156 286 minecraft:light[level=15]
setblock 176 156 294 minecraft:light[level=15]
setblock 176 156 302 minecraft:light[level=15]
fill 177 156 275 177 179 275 minecraft:blue_ice
setblock 178 156 315 minecraft:packed_ice
setblock 178 156 316 minecraft:snow_block
fill 179 156 307 179 156 309 minecraft:packed_ice
setblock 179 156 310 minecraft:snow_block
setblock 179 156 315 minecraft:snow_block
fill 179 156 316 179 159 316 minecraft:packed_ice
setblock 180 156 288 minecraft:packed_ice
setblock 180 156 289 minecraft:snow_block
fill 180 156 290 180 158 291 minecraft:packed_ice
setblock 180 156 303 minecraft:packed_ice
setblock 180 156 304 minecraft:snow_block
fill 180 156 305 180 159 305 minecraft:packed_ice
setblock 180 156 308 minecraft:packed_ice
setblock 180 156 309 minecraft:snow_block
fill 180 156 310 180 159 310 minecraft:packed_ice
setblock 180 156 313 minecraft:packed_ice
fill 180 156 315 180 159 315 minecraft:packed_ice
setblock 181 156 283 minecraft:snow_block
fill 181 156 284 181 156 287 minecraft:packed_ice
setblock 181 156 288 minecraft:snow_block
fill 181 156 289 181 159 289 minecraft:packed_ice
setblock 181 156 292 minecraft:packed_ice
setblock 181 156 293 minecraft:snow_block
fill 181 156 294 181 159 294 minecraft:packed_ice
setblock 181 156 298 minecraft:snow_block
setblock 181 156 303 minecraft:snow_block
fill 181 156 304 181 159 304 minecraft:packed_ice
setblock 181 156 308 minecraft:snow_block
fill 181 156 309 181 159 309 minecraft:packed_ice
setblock 181 156 312 minecraft:packed_ice
setblock 181 156 313 minecraft:snow_block
fill 181 156 314 181 159 314 minecraft:packed_ice
fill 182 156 280 182 157 280 minecraft:packed_ice
setblock 182 156 282 minecraft:snow_block
fill 182 156 283 182 159 283 minecraft:packed_ice
setblock 182 156 287 minecraft:snow_block
fill 182 156 288 182 159 288 minecraft:packed_ice
setblock 182 156 292 minecraft:snow_block
fill 182 156 293 182 159 293 minecraft:packed_ice
setblock 182 156 297 minecraft:snow_block
setblock 182 156 302 minecraft:snow_block
fill 182 156 303 182 159 303 minecraft:packed_ice
setblock 182 156 307 minecraft:snow_block
fill 182 156 308 182 159 308 minecraft:packed_ice
setblock 182 156 312 minecraft:snow_block
fill 182 156 313 182 159 313 minecraft:packed_ice
fill 183 156 278 183 174 278 minecraft:blue_ice
setblock 183 156 307 minecraft:white_concrete
setblock 141 157 293 minecraft:white_concrete
setblock 142 157 276 minecraft:snow_block
fill 142 157 277 142 157 280 minecraft:packed_ice
setblock 142 157 281 minecraft:snow_block
fill 142 157 282 142 157 285 minecraft:packed_ice
setblock 142 157 286 minecraft:snow_block
fill 142 157 287 142 157 290 minecraft:packed_ice
setblock 142 157 291 minecraft:snow_block
fill 142 157 292 142 160 292 minecraft:packed_ice
setblock 142 157 296 minecraft:snow_block
fill 142 157 297 142 160 297 minecraft:packed_ice
setblock 142 157 301 minecraft:snow_block
fill 142 157 302 142 160 302 minecraft:packed_ice
setblock 142 157 306 minecraft:snow_block
fill 142 157 307 142 160 307 minecraft:packed_ice
setblock 142 157 311 minecraft:snow_block
fill 142 157 312 142 160 312 minecraft:packed_ice
fill 142 157 314 142 157 315 minecraft:packed_ice
setblock 142 157 316 minecraft:snow_block
fill 143 157 276 143 160 276 minecraft:packed_ice
setblock 143 157 280 minecraft:snow_block
fill 143 157 281 143 160 281 minecraft:packed_ice
setblock 143 157 285 minecraft:snow_block
fill 143 157 286 143 160 286 minecraft:packed_ice
setblock 143 157 290 minecraft:snow_block
fill 143 157 291 143 160 291 minecraft:packed_ice
fill 143 157 296 144 159 296 minecraft:packed_ice
setblock 143 157 300 minecraft:snow_block
fill 143 157 301 143 159 301 minecraft:packed_ice
setblock 143 157 305 minecraft:snow_block
fill 143 157 306 143 159 306 minecraft:packed_ice
setblock 143 157 310 minecraft:snow_block
fill 143 157 311 143 160 311 minecraft:packed_ice
setblock 143 157 315 minecraft:snow_block
fill 143 157 316 143 160 316 minecraft:packed_ice
setblock 144 157 284 minecraft:snow_block
fill 144 157 285 144 160 285 minecraft:packed_ice
setblock 144 157 288 minecraft:packed_ice
setblock 144 157 289 minecraft:snow_block
fill 144 157 290 144 160 290 minecraft:packed_ice
setblock 144 157 294 minecraft:snow_block
fill 144 157 295 144 160 295 minecraft:packed_ice
setblock 144 157 309 minecraft:snow_block
setblock 144 157 310 minecraft:packed_ice
setblock 145 157 288 minecraft:snow_block
fill 145 157 289 145 160 289 minecraft:packed_ice
setblock 145 157 292 minecraft:packed_ice
setblock 146 157 316 minecraft:packed_ice
setblock 147 157 276 minecraft:snow_block
fill 153 157 275 153 179 275 minecraft:blue_ice
setblock 154 157 275 minecraft:white_concrete
fill 154 157 276 156 157 276 minecraft:packed_ice
fill 155 157 275 155 177 275 minecraft:blue_ice
fill 155 157 316 156 157 316 minecraft:packed_ice
setblock 157 157 276 minecraft:snow_block
fill 157 157 277 160 157 277 minecraft:packed_ice
setblock 157 157 315 minecraft:packed_ice
setblock 157 157 316 minecraft:snow_block
fill 158 157 276 161 157 276 minecraft:packed_ice
setblock 158 157 314 minecraft:packed_ice
setblock 158 157 315 minecraft:snow_block
fill 158 157 316 161 157 316 minecraft:packed_ice
setblock 159 157 314 minecraft:snow_block
fill 159 157 315 162 157 315 minecraft:packed_ice
fill 160 157 314 163 157 314 minecraft:packed_ice
setblock 161 157 277 minecraft:snow_block
fill 161 157 313 164 158 313 minecraft:packed_ice
setblock 162 157 276 minecraft:snow_block
fill 162 157 277 162 160 277 minecraft:packed_ice
setblock 162 157 316 minecraft:snow_block
fill 163 157 276 163 160 276 minecraft:packed_ice
fill 163 157 312 163 158 312 minecraft:packed_ice
setblock 163 157 315 minecraft:snow_block
fill 163 157 316 163 160 316 minecraft:packed_ice
fill 164 157 311 164 158 311 minecraft:packed_ice
setblock 164 157 314 minecraft:snow_block
fill 164 157 315 164 160 315 minecraft:packed_ice
fill 165 157 312 165 158 312 minecraft:packed_ice
setblock 165 157 313 minecraft:snow_block
fill 165 157 314 165 160 314 minecraft:packed_ice
fill 166 157 313 166 160 313 minecraft:packed_ice
setblock 167 157 276 minecraft:snow_block
setblock 167 157 315 minecraft:packed_ice
setblock 167 157 316 minecraft:snow_block
fill 168 157 276 168 158 276 minecraft:packed_ice
setblock 168 157 315 minecraft:snow_block
fill 168 157 316 168 160 316 minecraft:packed_ice
fill 169 157 315 169 160 315 minecraft:packed_ice
fill 171 157 315 172 157 315 minecraft:packed_ice
setblock 172 157 316 minecraft:snow_block
fill 173 157 316 176 157 316 minecraft:packed_ice
fill 174 157 279 174 158 279 minecraft:packed_ice
fill 174 157 315 177 157 315 minecraft:packed_ice
fill 175 157 278 175 158 278 minecraft:packed_ice
fill 175 157 280 175 158 280 minecraft:packed_ice
fill 176 157 279 176 158 279 minecraft:packed_ice
setblock 177 157 316 minecraft:snow_block
setblock 178 157 314 minecraft:packed_ice
setblock 178 157 315 minecraft:snow_block
fill 178 157 316 178 160 316 minecraft:packed_ice
fill 179 157 307 179 157 308 minecraft:packed_ice
setblock 179 157 309 minecraft:snow_block
fill 179 157 310 179 158 312 minecraft:packed_ice
setblock 179 157 314 minecraft:snow_block
fill 179 157 315 179 160 315 minecraft:packed_ice
fill 180 157 286 180 157 287 minecraft:packed_ice
setblock 180 157 288 minecraft:snow_block
fill 180 157 289 180 160 289 minecraft:packed_ice
setblock 180 157 292 minecraft:packed_ice
setblock 180 157 293 minecraft:snow_block
fill 180 157 294 180 159 295 minecraft:packed_ice
setblock 180 157 302 minecraft:packed_ice
setblock 180 157 303 minecraft:snow_block
fill 180 157 304 180 160 304 minecraft:packed_ice
setblock 180 157 308 minecraft:snow_block
fill 180 157 309 180 160 309 minecraft:packed_ice
setblock 180 157 313 minecraft:snow_block
fill 180 157 314 180 160 314 minecraft:packed_ice
fill 181 157 283 181 157 286 minecraft:packed_ice
setblock 181 157 287 minecraft:snow_block
fill 181 157 288 181 160 288 minecraft:packed_ice
setblock 181 157 291 minecraft:packed_ice
setblock 181 157 292 minecraft:snow_block
fill 181 157 293 181 160 293 minecraft:packed_ice
setblock 181 157 297 minecraft:snow_block
fill 181 157 298 181 160 298 minecraft:packed_ice
setblock 181 157 302 minecraft:snow_block
fill 181 157 303 181 160 303 minecraft:packed_ice
setblock 181 157 307 minecraft:snow_block
fill 181 157 308 181 160 308 minecraft:packed_ice
setblock 181 157 312 minecraft:snow_block
fill 181 157 313 181 160 313 minecraft:packed_ice
setblock 181 157 316 minecraft:packed_ice
setblock 182 157 276 minecraft:snow_block
fill 182 157 279 182 158 279 minecraft:packed_ice
setblock 182 157 281 minecraft:snow_block
fill 182 157 282 182 160 282 minecraft:packed_ice
setblock 182 157 286 minecraft:snow_block
fill 182 157 287 182 160 287 minecraft:packed_ice
setblock 182 157 291 minecraft:snow_block
fill 182 157 292 182 160 292 minecraft:packed_ice
setblock 182 157 296 minecraft:snow_block
fill 182 157 297 182 160 297 minecraft:packed_ice
setblock 182 157 301 minecraft:snow_block
fill 182 157 302 182 160 302 minecraft:packed_ice
setblock 182 157 306 minecraft:snow_block
fill 182 157 307 182 160 307 minecraft:packed_ice
setblock 182 157 311 minecraft:snow_block
fill 182 157 312 182 160 312 minecraft:packed_ice
setblock 182 157 316 minecraft:snow_block
setblock 183 157 299 minecraft:light_blue_concrete
fill 183 157 307 183 159 307 minecraft:blue_ice
fill 141 158 293 141 180 293 minecraft:blue_ice
setblock 141 158 308 minecraft:white_concrete
fill 142 158 276 142 158 279 minecraft:packed_ice
setblock 142 158 280 minecraft:snow_block
fill 142 158 281 142 158 284 minecraft:packed_ice
setblock 142 158 285 minecraft:snow_block
fill 142 158 286 142 158 289 minecraft:packed_ice
setblock 142 158 290 minecraft:snow_block
fill 142 158 291 142 161 291 minecraft:packed_ice
fill 142 158 296 142 161 296 minecraft:packed_ice
setblock 142 158 300 minecraft:snow_block
fill 142 158 301 142 161 301 minecraft:packed_ice
setblock 142 158 305 minecraft:snow_block
fill 142 158 306 142 161 306 minecraft:packed_ice
setblock 142 158 310 minecraft:snow_block
fill 142 158 311 142 161 311 minecraft:packed_ice
setblock 142 158 314 minecraft:packed_ice
setblock 142 158 315 minecraft:snow_block
fill 142 158 316 142 161 316 minecraft:packed_ice
setblock 143 158 279 minecraft:snow_block
fill 143 158 280 143 160 280 minecraft:packed_ice
setblock 143 158 284 minecraft:snow_block
fill 143 158 285 143 161 285 minecraft:packed_ice
setblock 143 158 289 minecraft:snow_block
fill 143 158 290 143 161 290 minecraft:packed_ice
setblock 143 158 299 minecraft:snow_block
fill 143 158 300 143 159 300 minecraft:packed_ice
setblock 143 158 304 minecraft:snow_block
fill 143 158 305 143 159 305 minecraft:packed_ice
setblock 143 158 309 minecraft:snow_block
fill 143 158 310 143 161 310 minecraft:packed_ice
setblock 143 158 314 minecraft:snow_block
fill 143 158 315 144 160 315 minecraft:packed_ice
fill 144 158 276 145 158 276 minecraft:packed_ice
setblock 144 158 283 minecraft:snow_block
fill 144 158 284 144 159 284 minecraft:packed_ice
setblock 144 158 288 minecraft:snow_block
fill 144 158 289 144 161 289 minecraft:packed_ice
setblock 144 158 293 minecraft:snow_block
fill 144 158 294 144 161 294 minecraft:packed_ice
setblock 145 158 287 minecraft:snow_block
fill 145 158 288 145 160 288 minecraft:packed_ice
setblock 145 158 292 minecraft:snow_block
setblock 146 158 276 minecraft:snow_block
setblock 146 158 316 minecraft:snow_block
fill 147 158 276 148 160 276 minecraft:packed_ice
fill 147 158 316 147 161 316 minecraft:packed_ice
fill 152 158 276 155 158 276 minecraft:packed_ice
fill 153 158 316 155 158 316 minecraft:packed_ice
fill 154 158 275 154 179 275 minecraft:blue_ice
fill 155 158 315 156 158 315 minecraft:packed_ice
setblock 156 158 276 minecraft:snow_block
fill 156 158 277 159 158 277 minecraft:packed_ice
setblock 156 158 316 minecraft:snow_block
fill 157 158 276 160 158 276 minecraft:packed_ice
setblock 157 158 314 minecraft:packed_ice
setblock 157 158 315 minecraft:snow_block
fill 157 158 316 160 158 316 minecraft:packed_ice
setblock 158 158 314 minecraft:snow_block
fill 158 158 315 161 158 315 minecraft:packed_ice
setblock 159 158 313 minecraft:snow_block
fill 159 158 314 162 158 314 minecraft:packed_ice
setblock 160 158 277 minecraft:snow_block
fill 160 158 313 160 161 313 minecraft:packed_ice
setblock 161 158 276 minecraft:snow_block
fill 161 158 277 161 161 277 minecraft:packed_ice
setblock 161 158 316 minecraft:snow_block
fill 162 158 276 162 161 276 minecraft:packed_ice
setblock 162 158 315 minecraft:snow_block
fill 162 158 316 162 161 316 minecraft:packed_ice
setblock 163 158 314 minecraft:snow_block
fill 163 158 315 163 161 315 minecraft:packed_ice
fill 164 158 314 164 161 314 minecraft:packed_ice
setblock 165 158 277 minecraft:snow_block
fill 165 158 313 165 161 313 minecraft:packed_ice
setblock 166 158 276 minecraft:snow_block
setblock 166 158 316 minecraft:snow_block
fill 167 158 276 167 161 276 minecraft:packed_ice
setblock 167 158 315 minecraft:snow_block
fill 167 158 316 167 161 316 minecraft:packed_ice
setblock 168 158 314 minecraft:snow_block
fill 168 158 315 168 161 315 minecraft:packed_ice
fill 169 158 314 169 160 314 minecraft:packed_ice
setblock 170 158 316 minecraft:packed_ice
setblock 171 158 315 minecraft:packed_ice
setblock 171 158 316 minecraft:snow_block
setblock 172 158 315 minecraft:snow_block
fill 172 158 316 175 158 316 minecraft:packed_ice
fill 173 158 315 176 158 315 minecraft:packed_ice
fill 176 158 314 177 158 314 minecraft:packed_ice
setblock 176 158 316 minecraft:snow_block
setblock 177 158 315 minecraft:snow_block
fill 177 158 316 177 161 316 minecraft:packed_ice
setblock 178 158 314 minecraft:snow_block
fill 178 158 315 178 161 315 minecraft:packed_ice
fill 179 158 306 179 158 307 minecraft:packed_ice
setblock 179 158 308 minecraft:snow_block
fill 179 158 309 179 160 309 minecraft:packed_ice
setblock 179 158 313 minecraft:snow_block
fill 179 158 314 179 161 314 minecraft:packed_ice
setblock 180 158 276 minecraft:packed_ice
setblock 180 158 286 minecraft:packed_ice
setblock 180 158 287 minecraft:snow_block
fill 180 158 288 180 161 288 minecraft:packed_ice
setblock 180 158 292 minecraft:snow_block
fill 180 158 293 180 161 293 minecraft:packed_ice
setblock 180 158 296 minecraft:packed_ice
setblock 180 158 297 minecraft:snow_block
fill 180 158 298 180 158 301 minecraft:packed_ice
setblock 180 158 302 minecraft:snow_block
fill 180 158 303 180 160 303 minecraft:packed_ice
setblock 180 158 307 minecraft:snow_block
fill 180 158 308 180 161 308 minecraft:packed_ice
setblock 180 158 311 minecraft:packed_ice
setblock 180 158 312 minecraft:snow_block
fill 180 158 313 180 161 313 minecraft:packed_ice
setblock 181 158 276 minecraft:snow_block
fill 181 158 283 181 158 285 minecraft:packed_ice
setblock 181 158 286 minecraft:snow_block
fill 181 158 287 181 161 287 minecraft:packed_ice
setblock 181 158 291 minecraft:snow_block
fill 181 158 292 181 161 292 minecraft:packed_ice
setblock 181 158 295 minecraft:packed_ice
setblock 181 158 296 minecraft:snow_block
fill 181 158 297 181 161 297 minecraft:packed_ice
setblock 181 158 301 minecraft:snow_block
fill 181 158 302 181 161 302 minecraft:packed_ice
setblock 181 158 306 minecraft:snow_block
fill 181 158 307 181 161 307 minecraft:packed_ice
setblock 181 158 311 minecraft:snow_block
fill 181 158 312 181 161 312 minecraft:packed_ice
setblock 181 158 316 minecraft:snow_block
fill 182 158 276 182 159 278 minecraft:packed_ice
setblock 182 158 280 minecraft:snow_block
fill 182 158 281 182 161 281 minecraft:packed_ice
setblock 182 158 285 minecraft:snow_block
fill 182 158 286 182 161 286 minecraft:packed_ice
setblock 182 158 290 minecraft:snow_block
fill 182 158 291 182 161 291 minecraft:packed_ice
setblock 182 158 295 minecraft:snow_block
fill 182 158 296 182 161 296 minecraft:packed_ice
setblock 182 158 300 minecraft:snow_block
fill 182 158 301 182 161 301 minecraft:packed_ice
setblock 182 158 305 minecraft:snow_block
fill 182 158 306 182 161 306 minecraft:packed_ice
setblock 182 158 310 minecraft:snow_block
fill 182 158 311 182 161 311 minecraft:packed_ice
setblock 182 158 315 minecraft:snow_block
fill 182 158 316 182 161 316 minecraft:packed_ice
fill 183 158 299 183 167 299 minecraft:blue_ice
setblock 141 159 288 minecraft:light_blue_concrete
fill 141 159 289 141 164 290 minecraft:blue_ice
fill 141 159 308 141 164 308 minecraft:blue_ice
fill 142 159 276 142 159 278 minecraft:packed_ice
setblock 142 159 279 minecraft:snow_block
fill 142 159 280 142 159 283 minecraft:packed_ice
setblock 142 159 284 minecraft:snow_block
fill 142 159 285 142 159 288 minecraft:packed_ice
setblock 142 159 289 minecraft:snow_block
fill 142 159 290 142 162 290 minecraft:packed_ice
setblock 142 159 294 minecraft:snow_block
setblock 142 159 299 minecraft:snow_block
fill 142 159 300 142 162 300 minecraft:packed_ice
setblock 142 159 304 minecraft:snow_block
fill 142 159 305 142 161 305 minecraft:packed_ice
setblock 142 159 309 minecraft:snow_block
fill 142 159 310 142 162 310 minecraft:packed_ice
setblock 142 159 314 minecraft:snow_block
fill 142 159 315 142 162 315 minecraft:packed_ice
setblock 143 159 279 minecraft:packed_ice
setblock 143 159 283 minecraft:snow_block
fill 143 159 284 143 162 284 minecraft:packed_ice
setblock 143 159 288 minecraft:snow_block
fill 143 159 289 143 162 289 minecraft:packed_ice
setblock 143 159 293 minecraft:snow_block
setblock 143 159 298 minecraft:snow_block
fill 143 159 299 143 161 299 minecraft:packed_ice
setblock 143 159 304 minecraft:packed_ice
setblock 143 159 308 minecraft:snow_block
fill 143 159 309 143 160 309 minecraft:packed_ice
setblock 143 159 313 minecraft:snow_block
fill 143 159 314 143 162 314 minecraft:packed_ice
setblock 144 159 276 minecraft:packed_ice
setblock 144 159 287 minecraft:snow_block
fill 144 159 288 144 162 288 minecraft:packed_ice
setblock 144 159 291 minecraft:packed_ice
setblock 144 159 292 minecraft:snow_block
fill 144 159 293 144 162 293 minecraft:packed_ice
setblock 144 159 316 minecraft:packed_ice
setblock 145 159 276 minecraft:snow_block
setblock 145 159 287 minecraft:packed_ice
setblock 145 159 291 minecraft:snow_block
fill 145 159 292 145 160 292 minecraft:packed_ice
setblock 145 159 316 minecraft:snow_block
fill 146 159 276 146 162 276 minecraft:packed_ice
fill 146 159 316 146 162 316 minecraft:packed_ice
fill 148 159 316 148 160 316 minecraft:packed_ice
setblock 149 159 276 minecraft:packed_ice
setblock 150 159 276 minecraft:snow_block
fill 151 159 276 154 159 276 minecraft:packed_ice
fill 151 159 316 154 159 316 minecraft:packed_ice
fill 154 159 315 155 159 315 minecraft:packed_ice
setblock 155 159 276 minecraft:snow_block
fill 155 159 277 158 159 277 minecraft:packed_ice
setblock 155 159 316 minecraft:snow_block
fill 156 159 276 159 159 276 minecraft:packed_ice
setblock 156 159 314 minecraft:packed_ice
setblock 156 159 315 minecraft:snow_block
fill 156 159 316 159 159 316 minecraft:packed_ice
setblock 157 159 314 minecraft:snow_block
fill 157 159 315 160 159 315 minecraft:packed_ice
setblock 158 159 313 minecraft:snow_block
fill 158 159 314 161 159 314 minecraft:packed_ice
setblock 159 159 277 minecraft:snow_block
fill 159 159 313 159 162 313 minecraft:packed_ice
setblock 160 159 276 minecraft:snow_block
fill 160 159 277 160 160 278 minecraft:packed_ice
setblock 160 159 316 minecraft:snow_block
fill 161 159 275 161 179 275 minecraft:blue_ice
fill 161 159 276 161 162 276 minecraft:packed_ice
fill 161 159 313 162 159 313 minecraft:packed_ice
setblock 161 159 315 minecraft:snow_block
fill 161 159 316 161 162 316 minecraft:packed_ice
setblock 162 159 275 minecraft:white_concrete
setblock 162 159 314 minecraft:snow_block
fill 162 159 315 162 162 315 minecraft:packed_ice
setblock 163 159 313 minecraft:snow_block
fill 163 159 314 163 162 314 minecraft:packed_ice
setblock 164 159 277 minecraft:snow_block
fill 164 159 313 164 161 313 minecraft:packed_ice
setblock 165 159 276 minecraft:snow_block
setblock 165 159 277 minecraft:packed_ice
setblock 165 159 316 minecraft:snow_block
fill 166 159 276 166 162 276 minecraft:packed_ice
setblock 166 159 315 minecraft:snow_block
fill 166 159 316 166 162 316 minecraft:packed_ice
setblock 167 159 314 minecraft:snow_block
fill 167 159 315 167 162 315 minecraft:packed_ice
fill 168 159 314 168 161 314 minecraft:packed_ice
setblock 170 159 316 minecraft:snow_block
setblock 171 159 315 minecraft:snow_block
fill 171 159 316 174 159 316 minecraft:packed_ice
fill 172 159 315 175 159 315 minecraft:packed_ice
fill 174 159 314 176 159 314 minecraft:packed_ice
setblock 175 159 316 minecraft:snow_block
setblock 176 159 315 minecraft:snow_block
fill 176 159 316 176 162 316 minecraft:packed_ice
setblock 177 159 314 minecraft:snow_block
fill 177 159 315 177 162 315 minecraft:packed_ice
fill 178 159 276 179 159 276 minecraft:packed_ice
fill 178 159 314 178 162 314 minecraft:packed_ice
fill 179 159 290 179 159 291 minecraft:packed_ice
setblock 179 159 292 minecraft:snow_block
fill 179 159 293 179 162 293 minecraft:packed_ice
setblock 179 159 307 minecraft:snow_block
fill 179 159 308 179 160 308 minecraft:packed_ice
fill 179 159 310 179 159 311 minecraft:packed_ice
setblock 179 159 312 minecraft:snow_block
fill 179 159 313 179 161 313 minecraft:packed_ice
setblock 180 159 276 minecraft:snow_block
setblock 180 159 286 minecraft:snow_block
fill 180 159 287 180 161 287 minecraft:packed_ice
setblock 180 159 290 minecraft:packed_ice
setblock 180 159 291 minecraft:snow_block
fill 180 159 292 180 162 292 minecraft:packed_ice
setblock 180 159 296 minecraft:snow_block
fill 180 159 297 180 159 300 minecraft:packed_ice
setblock 180 159 301 minecraft:snow_block
fill 180 159 302 180 160 302 minecraft:packed_ice
setblock 180 159 306 minecraft:snow_block
fill 180 159 307 180 161 307 minecraft:packed_ice
setblock 180 159 311 minecraft:snow_block
fill 180 159 312 180 162 312 minecraft:packed_ice
setblock 180 159 316 minecraft:snow_block
fill 181 159 276 181 162 276 minecraft:packed_ice
fill 181 159 283 181 159 284 minecraft:packed_ice
setblock 181 159 285 minecraft:snow_block
fill 181 159 286 181 162 286 minecraft:packed_ice
setblock 181 159 290 minecraft:snow_block
fill 181 159 291 181 162 291 minecraft:packed_ice
setblock 181 159 295 minecraft:snow_block
fill 181 159 296 181 162 296 minecraft:packed_ice
setblock 181 159 300 minecraft:snow_block
fill 181 159 301 181 162 301 minecraft:packed_ice
setblock 181 159 305 minecraft:snow_block
fill 181 159 306 181 162 306 minecraft:packed_ice
setblock 181 159 310 minecraft:snow_block
fill 181 159 311 181 162 311 minecraft:packed_ice
setblock 181 159 315 minecraft:snow_block
fill 181 159 316 181 162 316 minecraft:packed_ice
setblock 182 159 279 minecraft:snow_block
fill 182 159 280 182 160 280 minecraft:packed_ice
setblock 182 159 284 minecraft:snow_block
fill 182 159 285 182 162 285 minecraft:packed_ice
setblock 182 159 289 minecraft:snow_block
fill 182 159 290 182 162 290 minecraft:packed_ice
setblock 182 159 294 minecraft:snow_block
fill 182 159 295 182 162 295 minecraft:packed_ice
setblock 182 159 299 minecraft:snow_block
fill 182 159 300 182 162 300 minecraft:packed_ice
setblock 182 159 304 minecraft:snow_block
fill 182 159 305 182 162 305 minecraft:packed_ice
setblock 182 159 309 minecraft:snow_block
fill 182 159 310 182 162 310 minecraft:packed_ice
setblock 182 159 314 minecraft:snow_block
fill 182 159 315 182 162 315 minecraft:packed_ice
setblock 183 159 285 minecraft:white_concrete
fill 141 160 288 141 179 288 minecraft:blue_ice
setblock 141 160 316 minecraft:light_blue_concrete
fill 142 160 276 142 160 277 minecraft:packed_ice
setblock 142 160 278 minecraft:snow_block
fill 142 160 279 142 160 282 minecraft:packed_ice
setblock 142 160 283 minecraft:snow_block
fill 142 160 284 142 160 287 minecraft:packed_ice
setblock 142 160 288 minecraft:snow_block
fill 142 160 289 142 163 289 minecraft:packed_ice
setblock 142 160 293 minecraft:snow_block
fill 142 160 294 142 163 294 minecraft:packed_ice
setblock 142 160 298 minecraft:snow_block
fill 142 160 299 142 163 299 minecraft:packed_ice
setblock 142 160 303 minecraft:snow_block
fill 142 160 304 142 161 304 minecraft:packed_ice
setblock 142 160 308 minecraft:snow_block
fill 142 160 309 142 162 309 minecraft:packed_ice
setblock 142 160 313 minecraft:snow_block
fill 142 160 314 142 163 314 minecraft:packed_ice
setblock 143 160 282 minecraft:snow_block
fill 143 160 283 143 161 283 minecraft:packed_ice
setblock 143 160 287 minecraft:snow_block
fill 143 160 288 143 163 288 minecraft:packed_ice
setblock 143 160 292 minecraft:snow_block
fill 143 160 293 143 163 293 minecraft:packed_ice
setblock 143 160 296 minecraft:packed_ice
setblock 143 160 297 minecraft:snow_block
fill 143 160 298 143 162 298 minecraft:packed_ice
setblock 143 160 307 minecraft:snow_block
setblock 143 160 308 minecraft:packed_ice
setblock 143 160 312 minecraft:snow_block
fill 143 160 313 143 162 313 minecraft:packed_ice
setblock 144 160 276 minecraft:snow_block
setblock 144 160 278 minecraft:light[level=12]
setblock 144 160 286 minecraft:snow_block
fill 144 160 287 144 161 287 minecraft:packed_ice
setblock 144 160 291 minecraft:snow_block
fill 144 160 292 144 163 292 minecraft:packed_ice
setblock 144 160 296 minecraft:snow_block
setblock 144 160 299 minecraft:light[level=12]
setblock 144 160 306 minecraft:light[level=12]
setblock 144 160 313 minecraft:light[level=12]
setblock 144 160 316 minecraft:snow_block
fill 145 160 276 145 163 276 minecraft:packed_ice
setblock 145 160 290 minecraft:snow_block
setblock 145 160 291 minecraft:packed_ice
fill 145 160 316 145 163 316 minecraft:packed_ice
setblock 149 160 276 minecraft:snow_block
setblock 149 160 316 minecraft:snow_block
fill 150 160 276 153 160 276 minecraft:packed_ice
fill 150 160 316 153 160 316 minecraft:packed_ice
setblock 151 160 278 minecraft:light[level=12]
setblock 151 160 285 minecraft:light[level=12]
setblock 151 160 292 minecraft:light[level=12]
setblock 151 160 299 minecraft:light[level=12]
setblock 151 160 306 minecraft:light[level=12]
setblock 151 160 313 minecraft:light[level=12]
fill 153 160 315 154 161 315 minecraft:packed_ice
setblock 154 160 276 minecraft:snow_block
fill 154 160 277 157 160 277 minecraft:packed_ice
setblock 154 160 316 minecraft:snow_block
fill 155 160 276 158 160 276 minecraft:packed_ice
fill 155 160 314 155 165 314 minecraft:packed_ice
setblock 155 160 315 minecraft:snow_block
fill 155 160 316 158 160 316 minecraft:packed_ice
setblock 156 160 314 minecraft:snow_block
fill 156 160 315 159 160 315 minecraft:packed_ice
fill 157 160 314 160 160 314 minecraft:packed_ice
setblock 158 160 277 minecraft:snow_block
setblock 158 160 278 minecraft:light[level=12]
setblock 158 160 285 minecraft:light[level=12]
setblock 158 160 292 minecraft:light[level=12]
setblock 158 160 299 minecraft:light[level=12]
setblock 158 160 306 minecraft:light[level=12]
fill 158 160 313 158 163 313 minecraft:packed_ice
setblock 159 160 276 minecraft:snow_block
fill 159 160 277 159 161 278 minecraft:packed_ice
setblock 159 160 316 minecraft:snow_block
fill 160 160 276 160 163 276 minecraft:packed_ice
setblock 160 160 315 minecraft:snow_block
fill 160 160 316 160 163 316 minecraft:packed_ice
setblock 161 160 313 minecraft:packed_ice
setblock 161 160 314 minecraft:snow_block
fill 161 160 315 161 163 315 minecraft:packed_ice
fill 162 160 275 162 179 275 minecraft:blue_ice
setblock 162 160 313 minecraft:snow_block
fill 162 160 314 162 163 314 minecraft:packed_ice
setblock 163 160 277 minecraft:snow_block
fill 163 160 313 163 162 313 minecraft:packed_ice
setblock 164 160 276 minecraft:snow_block
fill 164 160 277 164 161 277 minecraft:packed_ice
setblock 164 160 316 minecraft:snow_block
fill 165 160 276 165 163 276 minecraft:packed_ice
setblock 165 160 278 minecraft:light[level=12]
setblock 165 160 285 minecraft:light[level=12]
setblock 165 160 292 minecraft:light[level=12]
setblock 165 160 299 minecraft:light[level=12]
setblock 165 160 306 minecraft:light[level=12]
setblock 165 160 315 minecraft:snow_block
fill 165 160 316 165 163 316 minecraft:packed_ice
setblock 166 160 314 minecraft:snow_block
fill 166 160 315 166 163 315 minecraft:packed_ice
fill 167 160 314 167 162 314 minecraft:packed_ice
setblock 169 160 316 minecraft:snow_block
setblock 170 160 315 minecraft:snow_block
fill 170 160 316 173 160 316 minecraft:packed_ice
fill 171 160 315 174 160 315 minecraft:packed_ice
setblock 172 160 278 minecraft:light[level=12]
setblock 172 160 285 minecraft:light[level=12]
setblock 172 160 292 minecraft:light[level=12]
setblock 172 160 299 minecraft:light[level=12]
setblock 172 160 306 minecraft:light[level=12]
setblock 172 160 313 minecraft:light[level=12]
fill 173 160 314 175 160 314 minecraft:packed_ice
setblock 174 160 316 minecraft:snow_block
fill 175 160 311 177 211 313 minecraft:snow_block
setblock 175 160 315 minecraft:snow_block
fill 175 160 316 175 163 316 minecraft:packed_ice
setblock 176 160 314 minecraft:snow_block
fill 176 160 315 176 163 315 minecraft:packed_ice
fill 177 160 276 178 160 276 minecraft:packed_ice
fill 177 160 314 177 163 314 minecraft:packed_ice
fill 178 160 311 178 211 312 minecraft:snow_block
fill 178 160 313 178 161 313 minecraft:packed_ice
setblock 179 160 276 minecraft:snow_block
setblock 179 160 278 minecraft:light[level=12]
setblock 179 160 285 minecraft:light[level=12]
setblock 179 160 290 minecraft:packed_ice
setblock 179 160 291 minecraft:snow_block
fill 179 160 292 179 163 292 minecraft:packed_ice
fill 179 160 294 179 160 295 minecraft:packed_ice
setblock 179 160 299 minecraft:light[level=12]
setblock 179 160 306 minecraft:light[level=12]
setblock 179 160 310 minecraft:packed_ice
setblock 179 160 311 minecraft:snow_block
fill 179 160 312 179 161 312 minecraft:packed_ice
setblock 179 160 316 minecraft:snow_block
fill 180 160 276 180 163 276 minecraft:packed_ice
setblock 180 160 286 minecraft:packed_ice
setblock 180 160 290 minecraft:snow_block
fill 180 160 291 180 163 291 minecraft:packed_ice
setblock 180 160 294 minecraft:packed_ice
setblock 180 160 295 minecraft:snow_block
fill 180 160 296 180 160 299 minecraft:packed_ice
setblock 180 160 300 minecraft:snow_block
fill 180 160 301 180 161 301 minecraft:packed_ice
setblock 180 160 305 minecraft:snow_block
fill 180 160 306 180 161 306 minecraft:packed_ice
setblock 180 160 310 minecraft:snow_block
fill 180 160 311 180 163 311 minecraft:packed_ice
setblock 180 160 315 minecraft:snow_block
fill 180 160 316 180 163 316 minecraft:packed_ice
setblock 181 160 284 minecraft:snow_block
fill 181 160 285 181 162 285 minecraft:packed_ice
setblock 181 160 289 minecraft:snow_block
fill 181 160 290 181 163 290 minecraft:packed_ice
setblock 181 160 294 minecraft:snow_block
fill 181 160 295 181 163 295 minecraft:packed_ice
setblock 181 160 299 minecraft:snow_block
fill 181 160 300 181 163 300 minecraft:packed_ice
setblock 181 160 304 minecraft:snow_block
fill 181 160 305 181 162 305 minecraft:packed_ice
setblock 181 160 309 minecraft:snow_block
fill 181 160 310 181 163 310 minecraft:packed_ice
setblock 181 160 314 minecraft:snow_block
fill 181 160 315 181 163 315 minecraft:packed_ice
fill 182 160 276 182 160 277 minecraft:packed_ice
setblock 182 160 278 minecraft:snow_block
fill 182 160 279 182 161 279 minecraft:packed_ice
setblock 182 160 283 minecraft:snow_block
fill 182 160 284 182 163 284 minecraft:packed_ice
setblock 182 160 288 minecraft:snow_block
fill 182 160 289 182 163 289 minecraft:packed_ice
setblock 182 160 293 minecraft:snow_block
fill 182 160 294 182 163 294 minecraft:packed_ice
setblock 182 160 298 minecraft:snow_block
fill 182 160 299 182 163 299 minecraft:packed_ice
setblock 182 160 303 minecraft:snow_block
fill 182 160 304 182 163 304 minecraft:packed_ice
setblock 182 160 308 minecraft:snow_block
fill 182 160 309 182 163 309 minecraft:packed_ice
setblock 182 160 313 minecraft:snow_block
fill 182 160 314 182 163 314 minecraft:packed_ice
fill 183 160 285 183 171 285 minecraft:blue_ice
setblock 183 160 306 minecraft:white_concrete
fill 183 160 307 183 161 307 minecraft:light_blue_concrete
fill 141 161 316 141 179 316 minecraft:blue_ice
setblock 142 161 276 minecraft:packed_ice
setblock 142 161 277 minecraft:snow_block
fill 142 161 278 142 161 281 minecraft:packed_ice
setblock 142 161 282 minecraft:snow_block
fill 142 161 283 142 161 286 minecraft:packed_ice
setblock 142 161 287 minecraft:snow_block
fill 142 161 288 142 164 288 minecraft:packed_ice
setblock 142 161 292 minecraft:snow_block
fill 142 161 293 142 164 293 minecraft:packed_ice
setblock 142 161 297 minecraft:snow_block
fill 142 161 298 142 164 298 minecraft:packed_ice
setblock 142 161 302 minecraft:snow_block
setblock 142 161 303 minecraft:packed_ice
setblock 142 161 307 minecraft:snow_block
fill 142 161 308 142 162 308 minecraft:packed_ice
setblock 142 161 312 minecraft:snow_block
fill 142 161 313 142 164 313 minecraft:packed_ice
setblock 143 161 276 minecraft:snow_block
setblock 143 161 282 minecraft:packed_ice
setblock 143 161 286 minecraft:snow_block
fill 143 161 287 143 163 287 minecraft:packed_ice
setblock 143 161 291 minecraft:snow_block
fill 143 161 292 143 164 292 minecraft:packed_ice
setblock 143 161 296 minecraft:snow_block
fill 143 161 297 143 164 297 minecraft:packed_ice
setblock 143 161 311 minecraft:snow_block
setblock 143 161 312 minecraft:packed_ice
setblock 143 161 315 minecraft:packed_ice
setblock 143 161 316 minecraft:snow_block
fill 144 161 276 144 164 276 minecraft:packed_ice
setblock 144 161 286 minecraft:packed_ice
setblock 144 161 290 minecraft:snow_block
fill 144 161 291 144 163 291 minecraft:packed_ice
setblock 144 161 295 minecraft:snow_block
setblock 144 161 315 minecraft:snow_block
fill 144 161 316 144 164 316 minecraft:packed_ice
fill 145 161 299 145 171 299 minecraft:snow_block
setblock 147 161 276 minecraft:packed_ice
setblock 148 161 276 minecraft:snow_block
setblock 148 161 316 minecraft:snow_block
fill 149 161 276 152 161 276 minecraft:packed_ice
fill 149 161 316 152 161 316 minecraft:packed_ice
setblock 153 161 276 minecraft:snow_block
fill 153 161 314 153 162 314 minecraft:packed_ice
setblock 153 161 316 minecraft:snow_block
fill 154 161 276 156 161 277 minecraft:packed_ice
fill 154 161 313 154 162 313 minecraft:packed_ice
fill 154 161 316 157 161 316 minecraft:packed_ice
fill 155 161 287 155 162 287 minecraft:white_concrete
fill 155 161 315 158 161 315 minecraft:packed_ice
fill 156 161 278 156 164 278 minecraft:blue_ice
fill 156 161 314 159 161 314 minecraft:packed_ice
setblock 157 161 276 minecraft:packed_ice
setblock 157 161 277 minecraft:snow_block
fill 157 161 313 157 162 313 minecraft:packed_ice
setblock 158 161 276 minecraft:snow_block
fill 158 161 277 158 164 277 minecraft:packed_ice
setblock 158 161 316 minecraft:snow_block
fill 159 161 276 159 164 276 minecraft:packed_ice
setblock 159 161 315 minecraft:snow_block
fill 159 161 316 159 164 316 minecraft:packed_ice
setblock 159 161 317 minecraft:light_blue_concrete
fill 160 161 277 160 162 277 minecraft:packed_ice
setblock 160 161 314 minecraft:snow_block
fill 160 161 315 160 164 315 minecraft:packed_ice
setblock 161 161 313 minecraft:snow_block
fill 161 161 314 161 164 314 minecraft:packed_ice
setblock 162 161 277 minecraft:snow_block
fill 162 161 313 162 163 313 minecraft:packed_ice
setblock 163 161 276 minecraft:snow_block
fill 163 161 277 163 162 277 minecraft:packed_ice
setblock 163 161 316 minecraft:snow_block
fill 164 161 276 164 164 276 minecraft:packed_ice
setblock 164 161 315 minecraft:snow_block
fill 164 161 316 164 164 316 minecraft:packed_ice
setblock 165 161 314 minecraft:snow_block
fill 165 161 315 165 164 315 minecraft:packed_ice
fill 166 161 314 166 162 314 minecraft:packed_ice
setblock 168 161 316 minecraft:snow_block
setblock 169 161 315 minecraft:snow_block
fill 169 161 316 172 161 316 minecraft:packed_ice
fill 170 161 315 173 161 315 minecraft:packed_ice
fill 173 161 314 174 161 314 minecraft:packed_ice
setblock 173 161 316 minecraft:snow_block
setblock 174 161 315 minecraft:snow_block
fill 174 161 316 174 164 316 minecraft:packed_ice
setblock 175 161 314 minecraft:snow_block
fill 175 161 315 175 164 315 minecraft:packed_ice
fill 176 161 276 177 161 276 minecraft:packed_ice
fill 176 161 314 176 164 314 minecraft:packed_ice
setblock 178 161 276 minecraft:snow_block
setblock 178 161 316 minecraft:snow_block
fill 179 161 276 179 164 276 minecraft:packed_ice
setblock 179 161 290 minecraft:snow_block
fill 179 161 291 179 163 291 minecraft:packed_ice
setblock 179 161 294 minecraft:packed_ice
setblock 179 161 295 minecraft:snow_block
fill 179 161 296 180 163 296 minecraft:packed_ice
setblock 179 161 310 minecraft:snow_block
setblock 179 161 311 minecraft:packed_ice
setblock 179 161 315 minecraft:snow_block
fill 179 161 316 179 164 316 minecraft:packed_ice
setblock 180 161 289 minecraft:snow_block
fill 180 161 290 180 164 290 minecraft:packed_ice
setblock 180 161 294 minecraft:snow_block
fill 180 161 295 180 164 295 minecraft:packed_ice
fill 180 161 297 180 161 298 minecraft:packed_ice
setblock 180 161 299 minecraft:snow_block
fill 180 161 300 180 163 300 minecraft:packed_ice
setblock 180 161 304 minecraft:snow_block
setblock 180 161 305 minecraft:packed_ice
setblock 180 161 309 minecraft:snow_block
fill 180 161 310 180 162 310 minecraft:packed_ice
setblock 180 161 314 minecraft:snow_block
fill 180 161 315 180 164 315 minecraft:packed_ice
setblock 181 161 288 minecraft:snow_block
fill 181 161 289 181 164 289 minecraft:packed_ice
setblock 181 161 293 minecraft:snow_block
fill 181 161 294 181 164 294 minecraft:packed_ice
setblock 181 161 298 minecraft:snow_block
fill 181 161 299 181 164 299 minecraft:packed_ice
setblock 181 161 303 minecraft:snow_block
fill 181 161 304 181 163 304 minecraft:packed_ice
setblock 181 161 308 minecraft:snow_block
fill 181 161 309 181 163 309 minecraft:packed_ice
setblock 181 161 313 minecraft:snow_block
fill 181 161 314 181 164 314 minecraft:packed_ice
setblock 182 161 276 minecraft:packed_ice
setblock 182 161 277 minecraft:snow_block
fill 182 161 278 182 162 278 minecraft:packed_ice
setblock 182 161 282 minecraft:snow_block
fill 182 161 283 182 162 283 minecraft:packed_ice
setblock 182 161 287 minecraft:snow_block
fill 182 161 288 182 164 288 minecraft:packed_ice
setblock 182 161 292 minecraft:snow_block
fill 182 161 293 182 164 293 minecraft:packed_ice
setblock 182 161 297 minecraft:snow_block
fill 182 161 298 182 164 298 minecraft:packed_ice
setblock 182 161 302 minecraft:snow_block
fill 182 161 303 182 164 303 minecraft:packed_ice
setblock 182 161 307 minecraft:snow_block
fill 182 161 308 182 164 308 minecraft:packed_ice
setblock 182 161 312 minecraft:snow_block
fill 182 161 313 182 164 313 minecraft:packed_ice
setblock 183 161 277 minecraft:light_blue_concrete
fill 183 161 306 183 176 306 minecraft:blue_ice
setblock 142 162 276 minecraft:snow_block
fill 142 162 277 142 162 280 minecraft:packed_ice
setblock 142 162 281 minecraft:snow_block
fill 142 162 282 142 162 285 minecraft:packed_ice
setblock 142 162 286 minecraft:snow_block
fill 142 162 287 142 165 287 minecraft:packed_ice
setblock 142 162 291 minecraft:snow_block
fill 142 162 292 142 165 292 minecraft:packed_ice
setblock 142 162 296 minecraft:snow_block
fill 142 162 297 142 165 297 minecraft:packed_ice
setblock 142 162 301 minecraft:snow_block
setblock 142 162 302 minecraft:packed_ice
setblock 142 162 307 minecraft:packed_ice
setblock 142 162 311 minecraft:snow_block
fill 142 162 312 142 164 312 minecraft:packed_ice
setblock 142 162 316 minecraft:snow_block
fill 143 162 276 143 165 276 minecraft:packed_ice
setblock 143 162 285 minecraft:snow_block
fill 143 162 286 143 163 286 minecraft:packed_ice
setblock 143 162 290 minecraft:snow_block
fill 143 162 291 143 165 291 minecraft:packed_ice
setblock 143 162 295 minecraft:snow_block
fill 143 162 296 143 165 296 minecraft:packed_ice
setblock 143 162 315 minecraft:snow_block
fill 143 162 316 143 165 316 minecraft:packed_ice
setblock 144 162 289 minecraft:snow_block
fill 144 162 290 144 163 290 minecraft:packed_ice
setblock 144 162 294 minecraft:snow_block
setblock 144 162 295 minecraft:packed_ice
setblock 147 162 276 minecraft:snow_block
setblock 147 162 316 minecraft:snow_block
fill 148 162 276 151 162 276 minecraft:packed_ice
fill 148 162 316 151 162 316 minecraft:packed_ice
setblock 152 162 276 minecraft:snow_block
setblock 152 162 315 minecraft:packed_ice
setblock 152 162 316 minecraft:snow_block
fill 153 162 276 155 162 277 minecraft:packed_ice
setblock 153 162 315 minecraft:snow_block
fill 153 162 316 156 162 316 minecraft:packed_ice
fill 154 162 315 157 162 315 minecraft:packed_ice
fill 155 162 278 155 163 278 minecraft:blue_ice
setblock 156 162 276 minecraft:packed_ice
setblock 156 162 277 minecraft:snow_block
fill 156 162 279 156 163 279 minecraft:blue_ice
fill 156 162 314 158 162 314 minecraft:packed_ice
setblock 157 162 276 minecraft:snow_block
fill 157 162 277 157 165 277 minecraft:packed_ice
fill 157 162 278 157 163 278 minecraft:blue_ice
setblock 157 162 316 minecraft:snow_block
fill 158 162 276 158 165 276 minecraft:packed_ice
setblock 158 162 315 minecraft:snow_block
fill 158 162 316 158 165 316 minecraft:packed_ice
fill 159 162 277 159 163 277 minecraft:packed_ice
setblock 159 162 314 minecraft:snow_block
fill 159 162 315 159 165 315 minecraft:packed_ice
fill 159 162 317 159 179 317 minecraft:blue_ice
setblock 160 162 313 minecraft:snow_block
fill 160 162 314 160 165 314 minecraft:packed_ice
setblock 161 162 277 minecraft:snow_block
fill 161 162 313 161 163 313 minecraft:packed_ice
setblock 162 162 276 minecraft:snow_block
fill 162 162 277 162 164 277 minecraft:packed_ice
setblock 162 162 316 minecraft:snow_block
fill 163 162 276 163 165 276 minecraft:packed_ice
setblock 163 162 315 minecraft:snow_block
fill 163 162 316 163 165 316 minecraft:packed_ice
setblock 164 162 314 minecraft:snow_block
fill 164 162 315 164 165 315 minecraft:packed_ice
fill 165 162 314 165 163 314 minecraft:packed_ice
setblock 167 162 316 minecraft:snow_block
setblock 168 162 315 minecraft:snow_block
fill 168 162 316 171 162 316 minecraft:packed_ice
fill 169 162 315 172 162 315 minecraft:packed_ice
setblock 172 162 316 minecraft:snow_block
setblock 173 162 315 minecraft:snow_block
fill 173 162 316 173 165 316 minecraft:packed_ice
setblock 174 162 314 minecraft:snow_block
fill 174 162 315 174 165 315 minecraft:packed_ice
fill 175 162 314 175 163 314 minecraft:packed_ice
setblock 176 162 276 minecraft:packed_ice
setblock 177 162 276 minecraft:snow_block
setblock 177 162 316 minecraft:snow_block
fill 178 162 276 178 165 276 minecraft:packed_ice
fill 178 162 296 178 163 296 minecraft:blue_ice
fill 178 162 313 178 211 313 minecraft:snow_block
setblock 178 162 315 minecraft:snow_block
fill 178 162 316 178 165 316 minecraft:packed_ice
setblock 179 162 294 minecraft:snow_block
fill 179 162 295 179 165 295 minecraft:packed_ice
setblock 179 162 314 minecraft:snow_block
fill 179 162 315 179 165 315 minecraft:packed_ice
setblock 180 162 288 minecraft:snow_block
fill 180 162 289 180 163 289 minecraft:packed_ice
setblock 180 162 293 minecraft:snow_block
fill 180 162 294 180 165 294 minecraft:packed_ice
setblock 180 162 297 minecraft:packed_ice
setblock 180 162 298 minecraft:snow_block
fill 180 162 299 180 165 299 minecraft:packed_ice
setblock 180 162 308 minecraft:snow_block
setblock 180 162 309 minecraft:packed_ice
setblock 180 162 313 minecraft:snow_block
fill 180 162 314 180 163 314 minecraft:packed_ice
setblock 181 162 287 minecraft:snow_block
fill 181 162 288 181 164 288 minecraft:packed_ice
setblock 181 162 292 minecraft:snow_block
fill 181 162 293 181 165 293 minecraft:packed_ice
setblock 181 162 297 minecraft:snow_block
fill 181 162 298 181 165 298 minecraft:packed_ice
setblock 181 162 302 minecraft:snow_block
fill 181 162 303 181 163 303 minecraft:packed_ice
setblock 181 162 307 minecraft:snow_block
fill 181 162 308 181 163 308 minecraft:packed_ice
setblock 181 162 312 minecraft:snow_block
fill 181 162 313 181 164 313 minecraft:packed_ice
setblock 182 162 276 minecraft:snow_block
fill 182 162 277 182 164 277 minecraft:packed_ice
setblock 182 162 286 minecraft:snow_block
fill 182 162 287 182 165 287 minecraft:packed_ice
setblock 182 162 291 minecraft:snow_block
fill 182 162 292 182 165 292 minecraft:packed_ice
setblock 182 162 296 minecraft:snow_block
fill 182 162 297 182 165 297 minecraft:packed_ice
setblock 182 162 301 minecraft:snow_block
fill 182 162 302 182 165 302 minecraft:packed_ice
setblock 182 162 306 minecraft:snow_block
fill 182 162 307 182 164 307 minecraft:packed_ice
setblock 182 162 311 minecraft:snow_block
fill 182 162 312 182 165 312 minecraft:packed_ice
setblock 182 162 316 minecraft:snow_block
fill 183 162 277 183 169 277 minecraft:blue_ice
fill 183 162 307 183 177 307 minecraft:blue_ice
fill 142 163 276 142 163 279 minecraft:packed_ice
setblock 142 163 280 minecraft:snow_block
fill 142 163 281 142 163 284 minecraft:packed_ice
setblock 142 163 285 minecraft:snow_block
fill 142 163 286 142 166 286 minecraft:packed_ice
setblock 142 163 290 minecraft:snow_block
fill 142 163 291 142 166 291 minecraft:packed_ice
setblock 142 163 295 minecraft:snow_block
fill 142 163 296 142 166 296 minecraft:packed_ice
setblock 142 163 300 minecraft:snow_block
setblock 142 163 301 minecraft:packed_ice
setblock 142 163 310 minecraft:snow_block
setblock 142 163 311 minecraft:packed_ice
setblock 142 163 315 minecraft:snow_block
fill 142 163 316 142 166 316 minecraft:packed_ice
setblock 143 163 289 minecraft:snow_block
fill 143 163 290 143 165 290 minecraft:packed_ice
setblock 143 163 294 minecraft:snow_block
fill 143 163 295 143 166 295 minecraft:packed_ice
setblock 144 163 293 minecraft:snow_block
setblock 146 163 276 minecraft:snow_block
setblock 146 163 316 minecraft:snow_block
fill 147 163 276 150 163 276 minecraft:packed_ice
fill 147 163 316 150 163 316 minecraft:packed_ice
setblock 151 163 276 minecraft:snow_block
setblock 151 163 316 minecraft:snow_block
fill 152 163 276 155 163 276 minecraft:packed_ice
setblock 152 163 315 minecraft:snow_block
fill 152 163 316 155 163 316 minecraft:packed_ice
fill 153 163 277 154 163 277 minecraft:packed_ice
fill 153 163 315 156 163 315 minecraft:packed_ice
setblock 155 163 277 minecraft:snow_block
setblock 155 163 317 minecraft:white_concrete
setblock 156 163 276 minecraft:snow_block
fill 156 163 277 156 166 277 minecraft:packed_ice
setblock 156 163 280 minecraft:blue_ice
fill 156 163 314 157 163 314 minecraft:packed_ice
setblock 156 163 316 minecraft:snow_block
fill 157 163 276 157 166 276 minecraft:packed_ice
setblock 157 163 315 minecraft:snow_block
fill 157 163 316 157 166 316 minecraft:packed_ice
setblock 158 163 314 minecraft:snow_block
fill 158 163 315 158 166 315 minecraft:packed_ice
setblock 159 163 313 minecraft:snow_block
fill 159 163 314 159 166 314 minecraft:packed_ice
setblock 160 163 277 minecraft:snow_block
setblock 160 163 313 minecraft:packed_ice
setblock 161 163 276 minecraft:snow_block
fill 161 163 277 161 166 277 minecraft:packed_ice
setblock 161 163 316 minecraft:snow_block
fill 162 163 276 162 166 276 minecraft:packed_ice
setblock 162 163 315 minecraft:snow_block
fill 162 163 316 162 166 316 minecraft:packed_ice
setblock 163 163 314 minecraft:snow_block
fill 163 163 315 163 166 315 minecraft:packed_ice
fill 164 163 314 164 164 314 minecraft:packed_ice
setblock 166 163 276 minecraft:snow_block
setblock 166 163 316 minecraft:snow_block
setblock 167 163 315 minecraft:snow_block
fill 167 163 316 170 163 316 minecraft:packed_ice
fill 168 163 315 171 163 315 minecraft:packed_ice
setblock 171 163 316 minecraft:snow_block
setblock 172 163 315 minecraft:snow_block
fill 172 163 316 172 166 316 minecraft:packed_ice
fill 173 163 315 173 166 315 minecraft:packed_ice
setblock 175 163 276 minecraft:packed_ice
setblock 176 163 276 minecraft:snow_block
setblock 176 163 316 minecraft:snow_block
fill 177 163 276 177 166 276 minecraft:packed_ice
setblock 177 163 315 minecraft:snow_block
fill 177 163 316 177 166 316 minecraft:packed_ice
setblock 178 163 314 minecraft:snow_block
fill 178 163 315 178 166 315 minecraft:packed_ice
setblock 179 163 293 minecraft:snow_block
fill 179 163 294 179 166 294 minecraft:packed_ice
setblock 179 163 297 minecraft:packed_ice
setblock 179 163 314 minecraft:packed_ice
setblock 180 163 292 minecraft:snow_block
fill 180 163 293 180 166 293 minecraft:packed_ice
setblock 180 163 297 minecraft:snow_block
fill 180 163 298 180 166 298 minecraft:packed_ice
setblock 180 163 312 minecraft:snow_block
setblock 180 163 313 minecraft:packed_ice
setblock 181 163 276 minecraft:snow_block
setblock 181 163 287 minecraft:packed_ice
setblock 181 163 291 minecraft:snow_block
fill 181 163 292 181 166 292 minecraft:packed_ice
setblock 181 163 296 minecraft:snow_block
fill 181 163 297 181 166 297 minecraft:packed_ice
setblock 181 163 301 minecraft:snow_block
fill 181 163 302 181 164 302 minecraft:packed_ice
setblock 181 163 307 minecraft:packed_ice
setblock 181 163 311 minecraft:snow_block
fill 181 163 312 181 164 312 minecraft:packed_ice
setblock 181 163 316 minecraft:snow_block
fill 182 163 276 182 166 276 minecraft:packed_ice
setblock 182 163 285 minecraft:snow_block
fill 182 163 286 182 165 286 minecraft:packed_ice
setblock 182 163 290 minecraft:snow_block
fill 182 163 291 182 166 291 minecraft:packed_ice
setblock 182 163 295 minecraft:snow_block
fill 182 163 296 182 166 296 minecraft:packed_ice
setblock 182 163 300 minecraft:snow_block
fill 182 163 301 182 166 301 minecraft:packed_ice
setblock 182 163 305 minecraft:snow_block
fill 182 163 306 182 164 306 minecraft:packed_ice
setblock 182 163 310 minecraft:snow_block
fill 182 163 311 182 165 311 minecraft:packed_ice
setblock 182 163 315 minecraft:snow_block
fill 182 163 316 182 166 316 minecraft:packed_ice
setblock 183 163 292 minecraft:light_blue_concrete
fill 183 163 303 183 167 303 minecraft:blue_ice
setblock 183 163 304 minecraft:white_concrete
fill 183 163 305 183 179 305 minecraft:blue_ice
fill 142 164 276 142 164 278 minecraft:packed_ice
setblock 142 164 279 minecraft:snow_block
fill 142 164 280 142 164 283 minecraft:packed_ice
setblock 142 164 284 minecraft:snow_block
fill 142 164 285 142 166 285 minecraft:packed_ice
setblock 142 164 289 minecraft:snow_block
fill 142 164 290 142 167 290 minecraft:packed_ice
setblock 142 164 294 minecraft:snow_block
fill 142 164 295 142 167 295 minecraft:packed_ice
setblock 142 164 299 minecraft:snow_block
fill 142 164 300 142 165 300 minecraft:packed_ice
setblock 142 164 314 minecraft:snow_block
fill 142 164 315 142 166 315 minecraft:packed_ice
setblock 143 164 288 minecraft:snow_block
setblock 143 164 289 minecraft:packed_ice
setblock 143 164 293 minecraft:snow_block
fill 143 164 294 143 166 294 minecraft:packed_ice
setblock 144 164 278 minecraft:light[level=15]
setblock 144 164 286 minecraft:light[level=15]
setblock 144 164 294 minecraft:light[level=15]
setblock 144 164 302 minecraft:light[level=15]
setblock 144 164 310 minecraft:light[level=15]
setblock 145 164 276 minecraft:snow_block
setblock 145 164 316 minecraft:snow_block
fill 146 164 276 149 164 276 minecraft:packed_ice
fill 147 164 288 149 211 288 minecraft:snow_block
fill 148 164 287 149 211 287 minecraft:snow_block
fill 148 164 289 149 211 289 minecraft:snow_block
fill 149 164 314 151 166 315 minecraft:blue_ice
setblock 149 164 316 minecraft:packed_ice
setblock 150 164 276 minecraft:snow_block
fill 150 164 313 150 167 313 minecraft:blue_ice
setblock 150 164 316 minecraft:snow_block
fill 151 164 276 154 164 276 minecraft:packed_ice
fill 151 164 316 154 164 316 minecraft:packed_ice
fill 152 164 277 153 164 277 minecraft:packed_ice
setblock 152 164 278 minecraft:light[level=15]
setblock 152 164 286 minecraft:light[level=15]
setblock 152 164 294 minecraft:light[level=15]
setblock 152 164 302 minecraft:light[level=15]
setblock 152 164 310 minecraft:light[level=15]
fill 152 164 313 152 169 313 minecraft:snow_block
fill 152 164 315 155 164 315 minecraft:packed_ice
setblock 154 164 277 minecraft:snow_block
setblock 155 164 276 minecraft:snow_block
fill 155 164 277 155 167 277 minecraft:packed_ice
setblock 155 164 316 minecraft:snow_block
fill 155 164 317 155 179 317 minecraft:blue_ice
fill 156 164 276 156 167 276 minecraft:packed_ice
setblock 156 164 314 minecraft:packed_ice
setblock 156 164 315 minecraft:snow_block
fill 156 164 316 156 167 316 minecraft:packed_ice
fill 157 164 275 157 169 275 minecraft:blue_ice
setblock 157 164 314 minecraft:snow_block
fill 157 164 315 157 167 315 minecraft:packed_ice
setblock 158 164 275 minecraft:white_concrete
fill 158 164 279 158 170 279 minecraft:packed_ice
fill 158 164 314 158 167 314 minecraft:packed_ice
setblock 159 164 277 minecraft:snow_block
setblock 160 164 276 minecraft:snow_block
fill 160 164 277 160 167 277 minecraft:packed_ice
setblock 160 164 278 minecraft:light[level=15]
setblock 160 164 286 minecraft:light[level=15]
setblock 160 164 294 minecraft:light[level=15]
setblock 160 164 302 minecraft:light[level=15]
setblock 160 164 310 minecraft:light[level=15]
setblock 160 164 316 minecraft:snow_block
fill 161 164 276 161 167 276 minecraft:packed_ice
setblock 161 164 315 minecraft:snow_block
fill 161 164 316 161 167 316 minecraft:packed_ice
setblock 162 164 314 minecraft:snow_block
fill 162 164 315 162 167 315 minecraft:packed_ice
fill 163 164 314 163 165 314 minecraft:packed_ice
setblock 165 164 276 minecraft:snow_block
setblock 165 164 316 minecraft:snow_block
setblock 166 164 315 minecraft:snow_block
fill 166 164 316 169 164 316 minecraft:packed_ice
fill 167 164 315 170 164 315 minecraft:packed_ice
setblock 168 164 278 minecraft:light[level=15]
setblock 168 164 286 minecraft:light[level=15]
setblock 168 164 294 minecraft:light[level=15]
setblock 168 164 302 minecraft:light[level=15]
setblock 168 164 310 minecraft:light[level=15]
setblock 170 164 316 minecraft:snow_block
setblock 171 164 315 minecraft:snow_block
fill 171 164 316 171 167 316 minecraft:packed_ice
fill 172 164 315 172 167 315 minecraft:packed_ice
setblock 175 164 276 minecraft:snow_block
setblock 175 164 316 minecraft:snow_block
setblock 175 164 317 minecraft:white_concrete
fill 176 164 276 176 167 276 minecraft:packed_ice
setblock 176 164 278 minecraft:light[level=15]
setblock 176 164 286 minecraft:light[level=15]
setblock 176 164 294 minecraft:light[level=15]
setblock 176 164 302 minecraft:light[level=15]
setblock 176 164 315 minecraft:snow_block
schedule function dropper:buildpart/63_5 1t
