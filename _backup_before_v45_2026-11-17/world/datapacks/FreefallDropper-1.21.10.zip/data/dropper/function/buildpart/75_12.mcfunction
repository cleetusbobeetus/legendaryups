setblock 142 251 329 minecraft:dark_prismarine
fill 142 251 330 142 251 333 minecraft:blue_terracotta
setblock 142 251 334 minecraft:dark_prismarine
fill 142 251 335 142 251 338 minecraft:blue_terracotta
setblock 142 251 339 minecraft:dark_prismarine
fill 142 251 340 142 251 343 minecraft:blue_terracotta
setblock 142 251 344 minecraft:dark_prismarine
fill 142 251 345 142 252 345 minecraft:blue_terracotta
setblock 142 251 349 minecraft:dark_prismarine
fill 142 251 350 142 253 350 minecraft:blue_terracotta
fill 142 251 352 142 252 352 minecraft:blue_terracotta
setblock 142 251 354 minecraft:dark_prismarine
fill 142 251 355 142 253 355 minecraft:blue_terracotta
setblock 143 251 328 minecraft:dark_prismarine
fill 143 251 329 143 253 329 minecraft:blue_terracotta
setblock 143 251 332 minecraft:blue_terracotta
setblock 143 251 333 minecraft:dark_prismarine
fill 143 251 334 143 254 334 minecraft:blue_terracotta
setblock 144 251 325 minecraft:light[level=12]
setblock 144 251 331 minecraft:blue_terracotta
setblock 144 251 332 minecraft:dark_prismarine
fill 144 251 339 144 253 339 minecraft:purple_concrete
fill 144 251 341 144 253 341 minecraft:purple_concrete
setblock 144 251 346 minecraft:light[level=12]
setblock 144 251 353 minecraft:light[level=12]
setblock 144 251 360 minecraft:light[level=12]
setblock 144 251 363 minecraft:purple_concrete
fill 145 251 338 145 253 338 minecraft:purple_concrete
fill 145 251 342 145 253 342 minecraft:purple_concrete
setblock 147 251 323 minecraft:blue_terracotta
fill 147 251 339 147 253 341 minecraft:purple_concrete
setblock 148 251 323 minecraft:dark_prismarine
fill 149 251 323 151 251 324 minecraft:blue_terracotta
setblock 150 251 325 minecraft:blue_terracotta
setblock 151 251 325 minecraft:dark_prismarine
setblock 151 251 332 minecraft:light[level=12]
setblock 151 251 339 minecraft:light[level=12]
setblock 151 251 346 minecraft:light[level=12]
setblock 151 251 353 minecraft:light[level=12]
setblock 151 251 360 minecraft:light[level=12]
fill 151 251 363 152 251 363 minecraft:blue_terracotta
setblock 152 251 323 minecraft:blue_terracotta
setblock 152 251 324 minecraft:dark_prismarine
fill 152 251 325 155 251 325 minecraft:blue_terracotta
fill 152 251 341 153 254 341 minecraft:jungle_leaves[persistent=true]
setblock 153 251 323 minecraft:dark_prismarine
fill 153 251 324 156 251 324 minecraft:blue_terracotta
fill 153 251 337 153 254 340 minecraft:jungle_leaves[persistent=true]
fill 153 251 342 153 254 345 minecraft:jungle_leaves[persistent=true]
setblock 153 251 363 minecraft:dark_prismarine
fill 154 251 323 157 251 323 minecraft:blue_terracotta
fill 154 251 336 154 254 339 minecraft:jungle_leaves[persistent=true]
fill 154 251 343 154 254 346 minecraft:jungle_leaves[persistent=true]
setblock 154 251 362 minecraft:dark_prismarine
fill 154 251 363 157 251 363 minecraft:blue_terracotta
setblock 155 251 326 minecraft:dark_prismarine
fill 155 251 335 155 254 337 minecraft:jungle_leaves[persistent=true]
fill 155 251 345 155 254 347 minecraft:jungle_leaves[persistent=true]
fill 155 251 362 155 254 362 minecraft:blue_terracotta
setblock 156 251 325 minecraft:dark_prismarine
fill 156 251 326 156 252 326 minecraft:blue_terracotta
fill 156 251 334 156 254 335 minecraft:jungle_leaves[persistent=true]
fill 156 251 347 156 254 348 minecraft:jungle_leaves[persistent=true]
setblock 157 251 324 minecraft:dark_prismarine
fill 157 251 325 157 253 325 minecraft:blue_terracotta
fill 157 251 333 158 254 334 minecraft:jungle_leaves[persistent=true]
fill 157 251 348 158 254 349 minecraft:jungle_leaves[persistent=true]
setblock 158 251 323 minecraft:dark_prismarine
fill 158 251 324 158 253 324 minecraft:blue_terracotta
setblock 158 251 332 minecraft:light[level=12]
setblock 158 251 353 minecraft:light[level=12]
setblock 158 251 360 minecraft:light[level=12]
setblock 158 251 363 minecraft:dark_prismarine
fill 159 251 323 162 251 323 minecraft:blue_terracotta
fill 159 251 332 160 254 333 minecraft:jungle_leaves[persistent=true]
fill 159 251 349 160 254 350 minecraft:jungle_leaves[persistent=true]
setblock 159 251 362 minecraft:dark_prismarine
fill 159 251 363 159 254 363 minecraft:blue_terracotta
fill 161 251 332 169 254 332 minecraft:jungle_leaves[persistent=true]
fill 161 251 350 169 254 350 minecraft:jungle_leaves[persistent=true]
fill 162 251 331 166 254 331 minecraft:jungle_leaves[persistent=true]
fill 162 251 351 166 254 351 minecraft:jungle_leaves[persistent=true]
setblock 163 251 323 minecraft:dark_prismarine
setblock 163 251 363 minecraft:dark_prismarine
setblock 164 251 323 minecraft:blue_terracotta
fill 164 251 363 167 251 363 minecraft:blue_terracotta
setblock 165 251 325 minecraft:light[level=12]
setblock 165 251 353 minecraft:light[level=12]
setblock 165 251 360 minecraft:light[level=12]
fill 166 251 341 169 251 341 minecraft:jungle_log
setblock 168 251 323 minecraft:dark_prismarine
fill 168 251 333 168 254 335 minecraft:jungle_leaves[persistent=true]
fill 168 251 347 168 254 349 minecraft:jungle_leaves[persistent=true]
setblock 168 251 363 minecraft:dark_prismarine
fill 169 251 323 172 251 323 minecraft:blue_terracotta
fill 169 251 333 171 254 333 minecraft:jungle_leaves[persistent=true]
fill 169 251 335 169 255 335 minecraft:jungle_leaves[persistent=true]
setblock 169 251 336 minecraft:jungle_log
fill 169 251 337 169 259 337 minecraft:jungle_leaves[persistent=true]
fill 169 251 345 169 259 345 minecraft:jungle_leaves[persistent=true]
setblock 169 251 346 minecraft:jungle_log
fill 169 251 347 169 255 347 minecraft:jungle_leaves[persistent=true]
fill 169 251 349 171 254 349 minecraft:jungle_leaves[persistent=true]
fill 169 251 363 172 251 363 minecraft:blue_terracotta
fill 170 251 322 170 308 322 minecraft:blue_concrete
fill 170 251 334 172 254 334 minecraft:jungle_leaves[persistent=true]
fill 170 251 337 170 251 338 minecraft:jungle_log
fill 170 251 339 175 251 339 minecraft:jungle_leaves[persistent=true]
fill 170 251 343 175 251 343 minecraft:jungle_leaves[persistent=true]
fill 170 251 344 170 251 345 minecraft:jungle_log
fill 170 251 348 172 254 348 minecraft:jungle_leaves[persistent=true]
fill 170 251 362 170 254 362 minecraft:blue_terracotta
fill 171 251 337 173 254 338 minecraft:jungle_leaves[persistent=true]
fill 171 251 344 173 254 345 minecraft:jungle_leaves[persistent=true]
setblock 172 251 325 minecraft:light[level=12]
fill 172 251 335 173 254 335 minecraft:jungle_leaves[persistent=true]
fill 172 251 347 173 254 347 minecraft:jungle_leaves[persistent=true]
setblock 172 251 353 minecraft:light[level=12]
setblock 172 251 360 minecraft:light[level=12]
setblock 173 251 323 minecraft:dark_prismarine
setblock 173 251 324 minecraft:blue_terracotta
fill 173 251 336 174 254 336 minecraft:jungle_leaves[persistent=true]
fill 173 251 346 174 254 346 minecraft:jungle_leaves[persistent=true]
setblock 173 251 363 minecraft:dark_prismarine
fill 174 251 323 174 253 323 minecraft:blue_terracotta
fill 174 251 337 174 251 338 minecraft:jungle_log
fill 174 251 344 174 251 345 minecraft:jungle_log
setblock 174 251 362 minecraft:dark_prismarine
fill 174 251 363 174 254 363 minecraft:blue_terracotta
setblock 175 251 336 minecraft:jungle_log
fill 175 251 337 175 254 338 minecraft:jungle_leaves[persistent=true]
fill 175 251 340 175 260 340 minecraft:jungle_leaves[persistent=true]
fill 175 251 341 178 251 341 minecraft:jungle_log
fill 175 251 342 175 260 342 minecraft:jungle_leaves[persistent=true]
fill 175 251 344 175 254 345 minecraft:jungle_leaves[persistent=true]
setblock 175 251 346 minecraft:jungle_log
fill 175 251 362 175 254 362 minecraft:blue_terracotta
fill 176 251 334 176 272 334 minecraft:dark_prismarine
setblock 178 251 323 minecraft:dark_prismarine
setblock 178 251 363 minecraft:dark_prismarine
setblock 179 251 325 minecraft:light[level=12]
setblock 179 251 339 minecraft:light[level=12]
setblock 179 251 346 minecraft:light[level=12]
setblock 179 251 348 minecraft:blue_terracotta
setblock 179 251 352 minecraft:dark_prismarine
fill 179 251 353 179 252 353 minecraft:blue_terracotta
setblock 179 251 360 minecraft:light[level=12]
setblock 179 251 363 minecraft:blue_terracotta
setblock 180 251 323 minecraft:purple_concrete
setblock 180 251 346 minecraft:dark_prismarine
setblock 180 251 347 minecraft:blue_terracotta
setblock 180 251 351 minecraft:dark_prismarine
fill 180 251 352 180 253 352 minecraft:blue_terracotta
setblock 180 251 356 minecraft:dark_prismarine
fill 181 251 328 181 268 328 minecraft:dark_prismarine
setblock 181 251 329 minecraft:blue_terracotta
setblock 181 251 330 minecraft:dark_prismarine
fill 181 251 331 181 252 331 minecraft:blue_terracotta
setblock 181 251 334 minecraft:blue_terracotta
setblock 181 251 335 minecraft:dark_prismarine
setblock 181 251 345 minecraft:dark_prismarine
fill 181 251 346 181 252 346 minecraft:blue_terracotta
setblock 181 251 350 minecraft:dark_prismarine
fill 181 251 351 181 254 351 minecraft:blue_terracotta
setblock 181 251 355 minecraft:dark_prismarine
fill 181 251 356 181 254 356 minecraft:blue_terracotta
setblock 182 251 329 minecraft:dark_prismarine
fill 182 251 330 182 254 330 minecraft:blue_terracotta
setblock 182 251 334 minecraft:dark_prismarine
fill 182 251 335 182 251 338 minecraft:blue_terracotta
setblock 182 251 339 minecraft:dark_prismarine
fill 182 251 340 182 254 340 minecraft:blue_terracotta
setblock 182 251 344 minecraft:dark_prismarine
fill 182 251 345 182 253 345 minecraft:blue_terracotta
setblock 182 251 349 minecraft:dark_prismarine
fill 182 251 350 182 254 350 minecraft:blue_terracotta
setblock 182 251 354 minecraft:dark_prismarine
fill 182 251 355 182 254 355 minecraft:blue_terracotta
fill 183 251 351 183 308 351 minecraft:blue_concrete
fill 142 252 326 142 252 327 minecraft:blue_terracotta
setblock 142 252 328 minecraft:dark_prismarine
fill 142 252 329 142 252 332 minecraft:blue_terracotta
setblock 142 252 333 minecraft:dark_prismarine
fill 142 252 334 142 252 337 minecraft:blue_terracotta
setblock 142 252 338 minecraft:dark_prismarine
fill 142 252 339 142 252 341 minecraft:blue_terracotta
setblock 142 252 348 minecraft:dark_prismarine
fill 142 252 349 142 253 349 minecraft:blue_terracotta
setblock 142 252 353 minecraft:dark_prismarine
fill 142 252 354 142 253 354 minecraft:blue_terracotta
setblock 143 252 328 minecraft:blue_terracotta
setblock 143 252 332 minecraft:dark_prismarine
fill 143 252 333 143 255 333 minecraft:blue_terracotta
fill 143 252 339 143 253 341 minecraft:purple_concrete
setblock 144 252 331 minecraft:dark_prismarine
setblock 144 252 332 minecraft:blue_terracotta
fill 144 252 338 144 253 338 minecraft:purple_concrete
fill 144 252 342 144 253 342 minecraft:purple_concrete
fill 146 252 338 146 253 338 minecraft:purple_concrete
fill 146 252 342 146 253 342 minecraft:purple_concrete
setblock 147 252 323 minecraft:dark_prismarine
fill 148 252 323 151 252 323 minecraft:blue_terracotta
fill 149 252 324 150 252 324 minecraft:blue_terracotta
setblock 150 252 325 minecraft:dark_prismarine
setblock 150 252 363 minecraft:purple_concrete
setblock 151 252 324 minecraft:dark_prismarine
fill 151 252 325 154 252 325 minecraft:blue_terracotta
setblock 151 252 363 minecraft:blue_terracotta
setblock 152 252 323 minecraft:dark_prismarine
fill 152 252 324 155 252 324 minecraft:blue_terracotta
fill 152 252 337 152 253 340 minecraft:jungle_leaves[persistent=true]
fill 152 252 342 152 253 345 minecraft:jungle_leaves[persistent=true]
setblock 152 252 363 minecraft:dark_prismarine
fill 153 252 323 156 252 323 minecraft:blue_terracotta
fill 153 252 336 153 253 336 minecraft:jungle_leaves[persistent=true]
fill 153 252 346 153 253 346 minecraft:jungle_leaves[persistent=true]
setblock 153 252 362 minecraft:dark_prismarine
fill 153 252 363 156 252 363 minecraft:blue_terracotta
setblock 154 252 326 minecraft:dark_prismarine
fill 154 252 335 154 253 335 minecraft:jungle_leaves[persistent=true]
fill 154 252 340 155 255 342 minecraft:jungle_leaves[persistent=true]
fill 154 252 347 154 253 347 minecraft:jungle_leaves[persistent=true]
fill 154 252 362 154 255 362 minecraft:blue_terracotta
setblock 155 252 325 minecraft:dark_prismarine
setblock 155 252 326 minecraft:blue_terracotta
fill 155 252 328 155 262 328 minecraft:magenta_terracotta
fill 155 252 334 155 253 334 minecraft:jungle_leaves[persistent=true]
fill 155 252 348 155 253 348 minecraft:jungle_leaves[persistent=true]
setblock 156 252 324 minecraft:dark_prismarine
fill 156 252 325 156 253 325 minecraft:blue_terracotta
fill 156 252 333 156 253 333 minecraft:jungle_leaves[persistent=true]
fill 156 252 336 157 255 337 minecraft:jungle_leaves[persistent=true]
setblock 156 252 340 minecraft:jungle_leaves[persistent=true]
setblock 156 252 342 minecraft:jungle_leaves[persistent=true]
fill 156 252 345 157 255 346 minecraft:jungle_leaves[persistent=true]
fill 156 252 349 156 253 349 minecraft:jungle_leaves[persistent=true]
setblock 157 252 323 minecraft:dark_prismarine
fill 157 252 324 157 254 324 minecraft:blue_terracotta
fill 157 252 332 158 253 332 minecraft:jungle_leaves[persistent=true]
fill 157 252 350 158 253 350 minecraft:jungle_leaves[persistent=true]
setblock 157 252 363 minecraft:dark_prismarine
fill 158 252 323 161 252 323 minecraft:blue_terracotta
fill 158 252 336 160 252 336 minecraft:jungle_leaves[persistent=true]
fill 158 252 346 160 252 346 minecraft:jungle_leaves[persistent=true]
setblock 158 252 362 minecraft:dark_prismarine
fill 158 252 363 158 255 363 minecraft:blue_terracotta
fill 159 252 331 161 253 331 minecraft:jungle_leaves[persistent=true]
fill 159 252 351 161 253 351 minecraft:jungle_leaves[persistent=true]
setblock 162 252 323 minecraft:dark_prismarine
setblock 162 252 363 minecraft:dark_prismarine
setblock 163 252 363 minecraft:blue_terracotta
fill 165 252 337 168 256 337 minecraft:jungle_leaves[persistent=true]
fill 165 252 345 168 256 345 minecraft:jungle_leaves[persistent=true]
fill 165 252 363 166 252 363 minecraft:blue_terracotta
fill 166 252 338 170 257 338 minecraft:jungle_leaves[persistent=true]
fill 166 252 344 170 257 344 minecraft:jungle_leaves[persistent=true]
fill 167 252 331 169 253 331 minecraft:jungle_leaves[persistent=true]
fill 167 252 341 168 259 341 minecraft:jungle_leaves[persistent=true]
fill 167 252 351 169 253 351 minecraft:jungle_leaves[persistent=true]
setblock 167 252 363 minecraft:dark_prismarine
fill 168 252 363 171 252 363 minecraft:blue_terracotta
fill 169 252 323 171 252 323 minecraft:blue_terracotta
fill 169 252 336 169 259 336 minecraft:jungle_leaves[persistent=true]
fill 169 252 341 175 252 341 minecraft:jungle_log
fill 169 252 346 169 259 346 minecraft:jungle_leaves[persistent=true]
fill 170 252 332 171 253 332 minecraft:jungle_leaves[persistent=true]
fill 170 252 337 170 259 337 minecraft:jungle_leaves[persistent=true]
fill 170 252 339 170 260 340 minecraft:jungle_leaves[persistent=true]
fill 170 252 342 170 260 343 minecraft:jungle_leaves[persistent=true]
fill 170 252 345 170 259 345 minecraft:jungle_leaves[persistent=true]
fill 170 252 350 171 253 350 minecraft:jungle_leaves[persistent=true]
fill 171 252 339 171 252 340 minecraft:jungle_log
fill 171 252 342 171 252 343 minecraft:jungle_log
setblock 172 252 323 minecraft:dark_prismarine
fill 172 252 327 174 272 332 minecraft:dark_prismarine
fill 172 252 333 172 253 333 minecraft:jungle_leaves[persistent=true]
fill 172 252 339 172 260 339 minecraft:jungle_leaves[persistent=true]
fill 172 252 340 173 252 340 minecraft:jungle_log
fill 172 252 342 173 252 342 minecraft:jungle_log
fill 172 252 343 172 260 343 minecraft:jungle_leaves[persistent=true]
fill 172 252 349 172 253 349 minecraft:jungle_leaves[persistent=true]
setblock 172 252 363 minecraft:dark_prismarine
fill 173 252 323 173 253 323 minecraft:blue_terracotta
fill 173 252 333 174 272 333 minecraft:dark_prismarine
fill 173 252 334 173 253 334 minecraft:jungle_leaves[persistent=true]
setblock 173 252 339 minecraft:jungle_log
setblock 173 252 343 minecraft:jungle_log
fill 173 252 348 173 253 348 minecraft:jungle_leaves[persistent=true]
setblock 173 252 362 minecraft:dark_prismarine
fill 173 252 363 173 255 363 minecraft:blue_terracotta
fill 174 252 335 174 253 335 minecraft:jungle_leaves[persistent=true]
fill 174 252 337 174 254 340 minecraft:jungle_leaves[persistent=true]
fill 174 252 342 174 254 345 minecraft:jungle_leaves[persistent=true]
fill 174 252 347 174 253 347 minecraft:jungle_leaves[persistent=true]
fill 174 252 362 174 255 362 minecraft:blue_terracotta
fill 175 252 336 175 253 336 minecraft:jungle_leaves[persistent=true]
fill 175 252 339 176 253 339 minecraft:jungle_leaves[persistent=true]
fill 175 252 343 176 253 343 minecraft:jungle_leaves[persistent=true]
fill 175 252 346 175 253 346 minecraft:jungle_leaves[persistent=true]
fill 176 252 337 176 253 338 minecraft:jungle_leaves[persistent=true]
fill 176 252 340 176 253 342 minecraft:jungle_leaves[persistent=true]
fill 176 252 344 176 253 345 minecraft:jungle_leaves[persistent=true]
setblock 177 252 323 minecraft:dark_prismarine
setblock 177 252 363 minecraft:dark_prismarine
setblock 178 252 363 minecraft:blue_terracotta
setblock 179 252 351 minecraft:dark_prismarine
setblock 179 252 352 minecraft:blue_terracotta
setblock 179 252 354 minecraft:blue_terracotta
setblock 180 252 350 minecraft:dark_prismarine
fill 180 252 351 180 253 351 minecraft:blue_terracotta
setblock 180 252 355 minecraft:dark_prismarine
setblock 180 252 356 minecraft:blue_terracotta
fill 181 252 329 181 268 329 minecraft:dark_prismarine
setblock 181 252 330 minecraft:blue_terracotta
setblock 181 252 333 minecraft:blue_terracotta
setblock 181 252 334 minecraft:dark_prismarine
fill 181 252 335 182 254 335 minecraft:blue_terracotta
setblock 181 252 345 minecraft:blue_terracotta
setblock 181 252 349 minecraft:dark_prismarine
fill 181 252 350 181 254 350 minecraft:blue_terracotta
setblock 181 252 354 minecraft:dark_prismarine
fill 181 252 355 181 254 355 minecraft:blue_terracotta
fill 182 252 327 182 252 328 minecraft:dark_prismarine
fill 182 252 329 182 253 329 minecraft:blue_terracotta
setblock 182 252 333 minecraft:dark_prismarine
fill 182 252 334 182 255 334 minecraft:blue_terracotta
fill 182 252 336 182 252 337 minecraft:blue_terracotta
setblock 182 252 338 minecraft:dark_prismarine
fill 182 252 339 182 255 339 minecraft:blue_terracotta
setblock 182 252 343 minecraft:dark_prismarine
fill 182 252 344 182 253 344 minecraft:blue_terracotta
setblock 182 252 348 minecraft:dark_prismarine
fill 182 252 349 182 255 349 minecraft:blue_terracotta
setblock 182 252 353 minecraft:dark_prismarine
fill 182 252 354 182 255 354 minecraft:blue_terracotta
setblock 182 252 358 minecraft:dark_prismarine
setblock 182 252 359 minecraft:purple_concrete
setblock 142 253 326 minecraft:blue_terracotta
setblock 142 253 327 minecraft:dark_prismarine
fill 142 253 328 142 253 331 minecraft:blue_terracotta
setblock 142 253 332 minecraft:dark_prismarine
fill 142 253 333 142 253 336 minecraft:blue_terracotta
setblock 142 253 337 minecraft:dark_prismarine
fill 142 253 338 142 253 340 minecraft:blue_terracotta
setblock 142 253 352 minecraft:dark_prismarine
fill 142 253 353 142 254 353 minecraft:blue_terracotta
setblock 142 253 358 minecraft:purple_concrete
setblock 143 253 323 minecraft:purple_concrete
setblock 143 253 331 minecraft:dark_prismarine
fill 143 253 332 143 256 332 minecraft:blue_terracotta
setblock 143 253 335 minecraft:blue_terracotta
setblock 143 253 336 minecraft:dark_prismarine
setblock 143 253 338 minecraft:purple_concrete
setblock 143 253 342 minecraft:purple_concrete
setblock 144 253 325 minecraft:light[level=13]
setblock 144 253 333 minecraft:light[level=13]
setblock 144 253 349 minecraft:light[level=13]
setblock 144 253 357 minecraft:light[level=13]
fill 145 253 337 146 253 337 minecraft:purple_concrete
fill 145 253 343 146 253 343 minecraft:purple_concrete
setblock 147 253 338 minecraft:purple_concrete
setblock 147 253 342 minecraft:purple_concrete
fill 148 253 323 150 253 323 minecraft:blue_terracotta
fill 148 253 339 148 253 341 minecraft:purple_concrete
setblock 149 253 324 minecraft:blue_terracotta
setblock 150 253 324 minecraft:dark_prismarine
setblock 150 253 363 minecraft:blue_terracotta
setblock 151 253 323 minecraft:dark_prismarine
fill 151 253 324 153 253 325 minecraft:blue_terracotta
setblock 151 253 363 minecraft:dark_prismarine
fill 152 253 323 155 253 323 minecraft:blue_terracotta
setblock 152 253 333 minecraft:light[level=13]
setblock 152 253 349 minecraft:light[level=13]
setblock 152 253 357 minecraft:light[level=13]
fill 152 253 363 155 253 363 minecraft:blue_terracotta
fill 153 253 362 153 256 362 minecraft:blue_terracotta
setblock 154 253 324 minecraft:blue_terracotta
setblock 154 253 325 minecraft:dark_prismarine
setblock 155 253 324 minecraft:dark_prismarine
fill 155 253 325 155 254 325 minecraft:blue_terracotta
setblock 156 253 323 minecraft:dark_prismarine
fill 156 253 324 156 255 324 minecraft:blue_terracotta
setblock 156 253 363 minecraft:dark_prismarine
fill 157 253 323 160 253 323 minecraft:blue_terracotta
setblock 157 253 362 minecraft:dark_prismarine
fill 157 253 363 157 256 363 minecraft:blue_terracotta
fill 158 253 336 159 254 336 minecraft:jungle_leaves[persistent=true]
fill 158 253 346 159 254 346 minecraft:jungle_leaves[persistent=true]
setblock 158 253 362 minecraft:blue_terracotta
setblock 160 253 325 minecraft:light[level=13]
setblock 160 253 357 minecraft:light[level=13]
setblock 161 253 323 minecraft:dark_prismarine
setblock 161 253 363 minecraft:dark_prismarine
fill 162 253 323 162 254 323 minecraft:purple_concrete
setblock 162 253 363 minecraft:blue_terracotta
fill 163 253 336 166 254 336 minecraft:jungle_leaves[persistent=true]
fill 163 253 346 166 254 346 minecraft:jungle_leaves[persistent=true]
fill 166 253 339 169 254 339 minecraft:jungle_leaves[persistent=true]
fill 166 253 343 169 254 343 minecraft:jungle_leaves[persistent=true]
setblock 166 253 363 minecraft:dark_prismarine
fill 167 253 340 169 259 340 minecraft:jungle_leaves[persistent=true]
fill 167 253 342 169 259 342 minecraft:jungle_leaves[persistent=true]
fill 167 253 363 170 253 363 minecraft:blue_terracotta
setblock 168 253 323 minecraft:purple_concrete
setblock 168 253 325 minecraft:light[level=13]
setblock 168 253 357 minecraft:light[level=13]
fill 169 253 341 171 260 341 minecraft:jungle_leaves[persistent=true]
fill 169 253 362 169 255 362 minecraft:blue_terracotta
setblock 170 253 323 minecraft:blue_terracotta
setblock 171 253 323 minecraft:dark_prismarine
fill 171 253 339 171 260 340 minecraft:jungle_leaves[persistent=true]
fill 171 253 342 171 260 343 minecraft:jungle_leaves[persistent=true]
setblock 171 253 363 minecraft:dark_prismarine
setblock 172 253 323 minecraft:blue_terracotta
fill 172 253 340 173 260 340 minecraft:jungle_leaves[persistent=true]
setblock 172 253 341 minecraft:jungle_log
fill 172 253 342 173 260 342 minecraft:jungle_leaves[persistent=true]
setblock 172 253 362 minecraft:dark_prismarine
fill 172 253 363 172 256 363 minecraft:blue_terracotta
fill 173 253 339 173 260 339 minecraft:jungle_leaves[persistent=true]
fill 173 253 341 175 260 341 minecraft:jungle_leaves[persistent=true]
fill 173 253 343 173 260 343 minecraft:jungle_leaves[persistent=true]
fill 173 253 362 173 256 362 minecraft:blue_terracotta
fill 174 253 353 175 254 354 minecraft:spruce_planks
setblock 176 253 325 minecraft:light[level=13]
setblock 176 253 349 minecraft:light[level=13]
setblock 176 253 357 minecraft:light[level=13]
setblock 176 253 363 minecraft:dark_prismarine
fill 177 253 363 177 254 363 minecraft:blue_terracotta
setblock 180 253 350 minecraft:blue_terracotta
setblock 180 253 354 minecraft:dark_prismarine
setblock 180 253 355 minecraft:blue_terracotta
fill 181 253 330 181 269 331 minecraft:dark_prismarine
setblock 181 253 333 minecraft:dark_prismarine
fill 181 253 334 181 254 334 minecraft:blue_terracotta
setblock 181 253 348 minecraft:dark_prismarine
setblock 181 253 349 minecraft:blue_terracotta
setblock 181 253 353 minecraft:dark_prismarine
fill 181 253 354 181 254 354 minecraft:blue_terracotta
setblock 181 253 363 minecraft:purple_concrete
fill 182 253 327 182 263 327 minecraft:dark_prismarine
setblock 182 253 328 minecraft:purple_concrete
setblock 182 253 332 minecraft:dark_prismarine
fill 182 253 333 182 256 333 minecraft:blue_terracotta
setblock 182 253 336 minecraft:blue_terracotta
setblock 182 253 337 minecraft:dark_prismarine
fill 182 253 338 182 256 338 minecraft:blue_terracotta
setblock 182 253 343 minecraft:blue_terracotta
setblock 182 253 347 minecraft:dark_prismarine
fill 182 253 348 182 254 348 minecraft:blue_terracotta
setblock 182 253 352 minecraft:dark_prismarine
fill 182 253 353 182 256 353 minecraft:blue_terracotta
setblock 182 253 357 minecraft:dark_prismarine
setblock 182 253 358 minecraft:blue_terracotta
fill 142 254 327 142 254 330 minecraft:blue_terracotta
setblock 142 254 331 minecraft:dark_prismarine
fill 142 254 332 142 254 335 minecraft:blue_terracotta
setblock 142 254 336 minecraft:dark_prismarine
fill 142 254 337 142 255 339 minecraft:blue_terracotta
fill 142 254 340 147 254 345 minecraft:dark_prismarine
setblock 143 254 330 minecraft:dark_prismarine
fill 143 254 331 143 255 331 minecraft:blue_terracotta
fill 143 254 335 149 254 335 minecraft:dark_prismarine
fill 143 254 336 143 255 336 minecraft:blue_terracotta
fill 143 254 337 149 255 339 minecraft:dark_prismarine
setblock 143 254 363 minecraft:purple_concrete
fill 144 254 336 149 255 336 minecraft:dark_prismarine
fill 148 254 323 149 254 323 minecraft:blue_terracotta
fill 148 254 340 149 255 343 minecraft:dark_prismarine
setblock 149 254 324 minecraft:dark_prismarine
setblock 150 254 323 minecraft:dark_prismarine
fill 150 254 324 153 254 324 minecraft:blue_terracotta
setblock 150 254 363 minecraft:dark_prismarine
fill 151 254 323 154 254 323 minecraft:blue_terracotta
fill 151 254 325 152 254 325 minecraft:blue_terracotta
fill 151 254 363 154 254 363 minecraft:blue_terracotta
fill 152 254 362 152 257 362 minecraft:blue_terracotta
setblock 153 254 325 minecraft:dark_prismarine
setblock 154 254 324 minecraft:dark_prismarine
setblock 154 254 325 minecraft:blue_terracotta
setblock 155 254 323 minecraft:dark_prismarine
fill 155 254 324 155 255 324 minecraft:blue_terracotta
setblock 155 254 363 minecraft:dark_prismarine
fill 156 254 323 159 254 323 minecraft:blue_terracotta
setblock 156 254 362 minecraft:dark_prismarine
fill 156 254 363 156 257 363 minecraft:blue_terracotta
setblock 157 254 362 minecraft:blue_terracotta
setblock 160 254 363 minecraft:dark_prismarine
setblock 161 254 363 minecraft:blue_terracotta
setblock 162 254 363 minecraft:purple_concrete
fill 166 254 363 169 254 363 minecraft:blue_terracotta
setblock 170 254 363 minecraft:dark_prismarine
setblock 171 254 362 minecraft:dark_prismarine
fill 171 254 363 171 257 363 minecraft:blue_terracotta
fill 172 254 333 172 272 333 minecraft:dark_prismarine
fill 172 254 341 172 260 341 minecraft:jungle_leaves[persistent=true]
fill 172 254 362 172 257 362 minecraft:blue_terracotta
fill 175 254 339 175 260 339 minecraft:jungle_leaves[persistent=true]
fill 175 254 343 175 260 343 minecraft:jungle_leaves[persistent=true]
setblock 175 254 363 minecraft:dark_prismarine
setblock 176 254 341 minecraft:jungle_leaves[persistent=true]
fill 176 254 342 176 255 342 minecraft:magenta_terracotta
fill 176 254 363 176 255 363 minecraft:blue_terracotta
setblock 181 254 323 minecraft:purple_concrete
fill 181 254 332 181 271 332 minecraft:dark_prismarine
setblock 181 254 333 minecraft:blue_terracotta
setblock 181 254 352 minecraft:dark_prismarine
setblock 181 254 353 minecraft:blue_terracotta
fill 182 254 328 182 255 329 minecraft:dark_prismarine
setblock 182 254 331 minecraft:dark_prismarine
fill 182 254 332 182 257 332 minecraft:blue_terracotta
setblock 182 254 336 minecraft:dark_prismarine
fill 182 254 337 182 257 337 minecraft:blue_terracotta
fill 182 254 341 182 255 341 minecraft:purple_concrete
setblock 182 254 347 minecraft:blue_terracotta
setblock 182 254 351 minecraft:dark_prismarine
fill 182 254 352 182 256 352 minecraft:blue_terracotta
setblock 182 254 356 minecraft:dark_prismarine
fill 182 254 357 182 255 357 minecraft:blue_terracotta
fill 183 254 347 183 268 349 minecraft:blue_concrete
setblock 183 254 350 minecraft:cyan_concrete
setblock 141 255 356 minecraft:light_blue_wool
fill 141 255 357 141 308 360 minecraft:blue_concrete
setblock 142 255 326 minecraft:purple_concrete
fill 142 255 328 142 255 329 minecraft:blue_terracotta
setblock 142 255 330 minecraft:dark_prismarine
fill 142 255 331 142 255 334 minecraft:blue_terracotta
setblock 142 255 335 minecraft:dark_prismarine
fill 142 255 336 142 258 336 minecraft:blue_terracotta
fill 142 255 340 147 255 344 minecraft:dark_prismarine
setblock 142 255 345 minecraft:purple_concrete
setblock 143 255 334 minecraft:dark_prismarine
fill 143 255 335 143 258 335 minecraft:blue_terracotta
fill 143 255 345 147 255 345 minecraft:dark_prismarine
fill 144 255 335 149 255 335 minecraft:dark_prismarine
setblock 148 255 323 minecraft:blue_terracotta
setblock 149 255 323 minecraft:dark_prismarine
setblock 149 255 363 minecraft:purple_concrete
fill 150 255 323 152 255 324 minecraft:blue_terracotta
fill 150 255 363 153 255 363 minecraft:blue_terracotta
setblock 153 255 323 minecraft:blue_terracotta
setblock 153 255 324 minecraft:dark_prismarine
setblock 154 255 323 minecraft:dark_prismarine
fill 154 255 324 154 256 324 minecraft:blue_terracotta
setblock 154 255 363 minecraft:dark_prismarine
fill 155 255 323 158 255 323 minecraft:blue_terracotta
fill 155 255 338 155 255 339 minecraft:jungle_leaves[persistent=true]
fill 155 255 343 155 255 344 minecraft:jungle_leaves[persistent=true]
setblock 155 255 362 minecraft:dark_prismarine
fill 155 255 363 155 258 363 minecraft:blue_terracotta
setblock 156 255 338 minecraft:jungle_leaves[persistent=true]
setblock 156 255 344 minecraft:jungle_leaves[persistent=true]
fill 156 255 362 156 258 362 minecraft:blue_terracotta
setblock 158 255 336 minecraft:jungle_leaves[persistent=true]
setblock 158 255 346 minecraft:jungle_leaves[persistent=true]
setblock 159 255 363 minecraft:dark_prismarine
setblock 160 255 363 minecraft:blue_terracotta
fill 164 255 336 166 256 336 minecraft:jungle_leaves[persistent=true]
fill 164 255 346 166 256 346 minecraft:jungle_leaves[persistent=true]
fill 166 255 363 168 255 363 minecraft:blue_terracotta
fill 167 255 339 169 259 339 minecraft:jungle_leaves[persistent=true]
fill 167 255 343 169 259 343 minecraft:jungle_leaves[persistent=true]
fill 168 255 334 168 255 335 minecraft:jungle_leaves[persistent=true]
fill 168 255 347 168 255 348 minecraft:jungle_leaves[persistent=true]
setblock 169 255 363 minecraft:dark_prismarine
setblock 170 255 362 minecraft:dark_prismarine
fill 170 255 363 170 258 363 minecraft:blue_terracotta
fill 171 255 337 172 259 338 minecraft:jungle_leaves[persistent=true]
fill 171 255 344 172 259 345 minecraft:jungle_leaves[persistent=true]
fill 171 255 362 171 258 362 minecraft:blue_terracotta
fill 173 255 338 174 260 338 minecraft:jungle_leaves[persistent=true]
fill 173 255 344 174 260 344 minecraft:jungle_leaves[persistent=true]
fill 174 255 339 174 260 340 minecraft:jungle_leaves[persistent=true]
fill 174 255 342 174 260 343 minecraft:jungle_leaves[persistent=true]
setblock 174 255 363 minecraft:dark_prismarine
setblock 175 255 323 minecraft:purple_concrete
fill 175 255 363 175 257 363 minecraft:blue_terracotta
setblock 176 255 341 minecraft:magenta_terracotta
fill 181 255 333 181 272 333 minecraft:dark_prismarine
fill 182 255 330 182 259 330 minecraft:dark_prismarine
setblock 182 255 331 minecraft:blue_terracotta
setblock 182 255 335 minecraft:dark_prismarine
fill 182 255 336 182 258 336 minecraft:blue_terracotta
setblock 182 255 350 minecraft:dark_prismarine
setblock 182 255 351 minecraft:blue_terracotta
setblock 182 255 355 minecraft:dark_prismarine
fill 182 255 356 182 256 356 minecraft:blue_terracotta
setblock 182 255 360 minecraft:purple_concrete
fill 183 255 350 183 308 350 minecraft:blue_concrete
fill 141 256 356 141 274 356 minecraft:blue_concrete
setblock 142 256 329 minecraft:dark_prismarine
fill 142 256 330 142 256 333 minecraft:blue_terracotta
setblock 142 256 334 minecraft:dark_prismarine
setblock 142 256 335 minecraft:sea_lantern
setblock 142 256 337 minecraft:sea_lantern
setblock 142 256 338 minecraft:blue_terracotta
setblock 142 256 339 minecraft:sea_lantern
fill 142 256 340 142 258 340 minecraft:dark_prismarine
setblock 142 256 341 minecraft:sea_lantern
fill 142 256 342 142 260 342 minecraft:dark_prismarine
setblock 142 256 343 minecraft:sea_lantern
fill 142 256 344 142 257 344 minecraft:dark_prismarine
setblock 142 256 345 minecraft:sea_lantern
setblock 142 256 351 minecraft:purple_concrete
fill 142 256 357 142 257 357 minecraft:purple_concrete
setblock 143 256 333 minecraft:dark_prismarine
fill 143 256 334 143 259 334 minecraft:blue_terracotta
setblock 143 256 336 minecraft:sea_lantern
fill 143 256 337 143 257 337 minecraft:dark_prismarine
setblock 143 256 338 minecraft:sea_lantern
fill 143 256 339 143 260 339 minecraft:dark_prismarine
setblock 143 256 340 minecraft:sea_lantern
fill 143 256 341 143 261 341 minecraft:dark_prismarine
setblock 143 256 342 minecraft:sea_lantern
fill 143 256 343 143 263 343 minecraft:dark_prismarine
setblock 143 256 344 minecraft:sea_lantern
fill 143 256 345 143 265 345 minecraft:dark_prismarine
setblock 144 256 323 minecraft:purple_concrete
setblock 144 256 335 minecraft:sea_lantern
fill 144 256 336 144 262 336 minecraft:dark_prismarine
setblock 144 256 337 minecraft:sea_lantern
fill 144 256 338 144 261 338 minecraft:dark_prismarine
setblock 144 256 339 minecraft:sea_lantern
fill 144 256 340 144 263 340 minecraft:dark_prismarine
setblock 144 256 341 minecraft:sea_lantern
fill 144 256 342 144 264 342 minecraft:dark_prismarine
setblock 144 256 343 minecraft:sea_lantern
fill 144 256 344 144 272 344 minecraft:dark_prismarine
setblock 144 256 345 minecraft:sea_lantern
fill 145 256 335 145 272 335 minecraft:dark_prismarine
setblock 145 256 336 minecraft:sea_lantern
fill 145 256 337 145 272 337 minecraft:dark_prismarine
setblock 145 256 338 minecraft:sea_lantern
fill 145 256 339 145 272 339 minecraft:dark_prismarine
setblock 145 256 340 minecraft:sea_lantern
fill 145 256 341 145 272 341 minecraft:dark_prismarine
setblock 145 256 342 minecraft:sea_lantern
fill 145 256 343 145 272 343 minecraft:dark_prismarine
setblock 145 256 344 minecraft:sea_lantern
fill 145 256 345 145 272 345 minecraft:dark_prismarine
setblock 146 256 335 minecraft:sea_lantern
fill 146 256 336 146 272 336 minecraft:dark_prismarine
setblock 146 256 337 minecraft:sea_lantern
fill 146 256 338 146 272 338 minecraft:dark_prismarine
setblock 146 256 339 minecraft:sea_lantern
fill 146 256 340 146 272 340 minecraft:dark_prismarine
setblock 146 256 341 minecraft:sea_lantern
fill 146 256 342 146 272 342 minecraft:dark_prismarine
setblock 146 256 343 minecraft:sea_lantern
fill 146 256 344 146 272 344 minecraft:dark_prismarine
setblock 146 256 345 minecraft:sea_lantern
fill 147 256 335 147 272 335 minecraft:dark_prismarine
setblock 147 256 336 minecraft:sea_lantern
fill 147 256 337 147 272 337 minecraft:dark_prismarine
setblock 147 256 338 minecraft:sea_lantern
fill 147 256 339 147 272 339 minecraft:dark_prismarine
setblock 147 256 340 minecraft:sea_lantern
fill 147 256 341 147 272 341 minecraft:dark_prismarine
setblock 147 256 342 minecraft:sea_lantern
fill 147 256 343 147 272 343 minecraft:dark_prismarine
setblock 147 256 344 minecraft:sea_lantern
fill 147 256 345 147 272 345 minecraft:dark_prismarine
setblock 148 256 323 minecraft:dark_prismarine
setblock 148 256 335 minecraft:sea_lantern
fill 148 256 336 148 272 336 minecraft:dark_prismarine
setblock 148 256 337 minecraft:sea_lantern
fill 148 256 338 148 272 338 minecraft:dark_prismarine
setblock 148 256 339 minecraft:sea_lantern
fill 148 256 340 148 272 340 minecraft:dark_prismarine
setblock 148 256 341 minecraft:sea_lantern
fill 148 256 342 148 272 342 minecraft:dark_prismarine
setblock 148 256 343 minecraft:sea_lantern
setblock 148 256 345 minecraft:sea_lantern
fill 149 256 323 152 256 323 minecraft:blue_terracotta
fill 149 256 335 149 272 335 minecraft:dark_prismarine
setblock 149 256 336 minecraft:sea_lantern
fill 149 256 337 149 272 337 minecraft:dark_prismarine
setblock 149 256 338 minecraft:sea_lantern
fill 149 256 339 149 272 339 minecraft:dark_prismarine
setblock 149 256 340 minecraft:sea_lantern
fill 149 256 341 149 272 341 minecraft:dark_prismarine
setblock 149 256 342 minecraft:sea_lantern
fill 149 256 343 149 267 343 minecraft:dark_prismarine
setblock 149 256 344 minecraft:sea_lantern
fill 149 256 345 149 272 345 minecraft:dark_prismarine
fill 149 256 363 152 256 363 minecraft:blue_terracotta
fill 150 256 324 151 256 324 minecraft:blue_terracotta
fill 151 256 362 151 258 362 minecraft:blue_terracotta
setblock 152 256 324 minecraft:dark_prismarine
setblock 153 256 323 minecraft:dark_prismarine
fill 153 256 324 153 257 324 minecraft:blue_terracotta
fill 153 256 348 153 257 348 minecraft:black_concrete
setblock 153 256 363 minecraft:dark_prismarine
fill 154 256 323 157 256 323 minecraft:blue_terracotta
setblock 154 256 362 minecraft:dark_prismarine
fill 154 256 363 154 259 363 minecraft:blue_terracotta
fill 155 256 362 155 259 362 minecraft:blue_terracotta
setblock 158 256 363 minecraft:dark_prismarine
fill 159 256 363 159 259 363 minecraft:blue_terracotta
fill 166 256 363 167 256 363 minecraft:blue_terracotta
setblock 168 256 362 minecraft:blue_terracotta
setblock 168 256 363 minecraft:dark_prismarine
setblock 169 256 323 minecraft:purple_concrete
fill 169 256 327 169 277 327 minecraft:magenta_terracotta
setblock 169 256 362 minecraft:dark_prismarine
fill 169 256 363 169 259 363 minecraft:blue_terracotta
fill 170 256 336 171 259 336 minecraft:jungle_leaves[persistent=true]
fill 170 256 346 171 259 346 minecraft:jungle_leaves[persistent=true]
fill 170 256 362 170 259 362 minecraft:blue_terracotta
fill 172 256 335 172 259 335 minecraft:jungle_leaves[persistent=true]
fill 172 256 347 172 259 347 minecraft:jungle_leaves[persistent=true]
fill 173 256 336 175 259 337 minecraft:jungle_leaves[persistent=true]
fill 173 256 345 175 259 346 minecraft:jungle_leaves[persistent=true]
setblock 173 256 363 minecraft:dark_prismarine
setblock 174 256 362 minecraft:dark_prismarine
fill 174 256 363 174 259 363 minecraft:blue_terracotta
fill 175 256 338 177 259 338 minecraft:jungle_leaves[persistent=true]
fill 175 256 344 177 259 344 minecraft:jungle_leaves[persistent=true]
fill 176 256 337 176 259 337 minecraft:jungle_leaves[persistent=true]
fill 176 256 339 177 259 343 minecraft:jungle_leaves[persistent=true]
fill 176 256 345 176 259 345 minecraft:jungle_leaves[persistent=true]
fill 178 256 341 178 259 341 minecraft:jungle_leaves[persistent=true]
setblock 180 256 363 minecraft:purple_concrete
fill 182 256 328 182 263 328 minecraft:dark_prismarine
setblock 182 256 329 minecraft:purple_concrete
fill 182 256 331 182 261 331 minecraft:dark_prismarine
setblock 182 256 334 minecraft:dark_prismarine
fill 182 256 335 182 259 335 minecraft:blue_terracotta
setblock 182 256 339 minecraft:dark_prismarine
fill 182 256 340 182 259 340 minecraft:blue_terracotta
setblock 182 256 354 minecraft:dark_prismarine
setblock 182 256 355 minecraft:blue_terracotta
setblock 141 257 361 minecraft:cyan_concrete
fill 141 257 362 141 308 363 minecraft:blue_concrete
fill 142 257 330 142 257 332 minecraft:blue_terracotta
setblock 142 257 333 minecraft:dark_prismarine
fill 142 257 334 142 258 335 minecraft:blue_terracotta
setblock 142 257 337 minecraft:blue_terracotta
fill 142 257 338 143 257 338 minecraft:dark_prismarine
fill 142 257 339 142 258 339 minecraft:blue_terracotta
fill 142 257 341 142 258 341 minecraft:dark_prismarine
fill 142 257 343 142 258 343 minecraft:dark_prismarine
fill 142 257 345 142 258 345 minecraft:dark_prismarine
setblock 142 257 363 minecraft:purple_concrete
setblock 143 257 332 minecraft:dark_prismarine
fill 143 257 333 143 260 333 minecraft:blue_terracotta
setblock 143 257 336 minecraft:blue_terracotta
fill 143 257 340 143 258 340 minecraft:dark_prismarine
fill 143 257 342 143 258 342 minecraft:dark_prismarine
fill 143 257 344 143 258 344 minecraft:dark_prismarine
setblock 144 257 325 minecraft:light[level=12]
setblock 144 257 332 minecraft:light[level=12]
fill 144 257 335 144 258 335 minecraft:dark_prismarine
fill 144 257 337 144 258 337 minecraft:dark_prismarine
fill 144 257 339 144 258 339 minecraft:dark_prismarine
fill 144 257 341 144 258 341 minecraft:dark_prismarine
fill 144 257 343 144 258 343 minecraft:dark_prismarine
fill 144 257 345 144 258 345 minecraft:dark_prismarine
setblock 144 257 346 minecraft:light[level=12]
setblock 144 257 353 minecraft:light[level=12]
setblock 144 257 360 minecraft:light[level=12]
fill 145 257 336 145 258 336 minecraft:dark_prismarine
fill 145 257 338 145 258 338 minecraft:dark_prismarine
fill 145 257 340 145 258 340 minecraft:dark_prismarine
fill 145 257 342 145 258 342 minecraft:dark_prismarine
fill 145 257 344 145 258 344 minecraft:dark_prismarine
fill 146 257 335 146 258 335 minecraft:dark_prismarine
fill 146 257 337 146 258 337 minecraft:dark_prismarine
fill 146 257 339 146 258 339 minecraft:dark_prismarine
fill 146 257 341 146 258 341 minecraft:dark_prismarine
fill 146 257 343 146 258 343 minecraft:dark_prismarine
fill 146 257 345 146 258 345 minecraft:dark_prismarine
setblock 147 257 323 minecraft:dark_prismarine
fill 147 257 336 147 258 336 minecraft:dark_prismarine
fill 147 257 338 147 258 338 minecraft:dark_prismarine
fill 147 257 340 147 258 340 minecraft:dark_prismarine
fill 147 257 342 147 258 342 minecraft:dark_prismarine
fill 147 257 344 147 258 344 minecraft:dark_prismarine
fill 148 257 323 151 257 323 minecraft:blue_terracotta
fill 148 257 335 148 258 335 minecraft:dark_prismarine
fill 148 257 337 148 258 337 minecraft:dark_prismarine
fill 148 257 339 148 258 339 minecraft:dark_prismarine
fill 148 257 341 148 258 341 minecraft:dark_prismarine
fill 148 257 343 148 258 343 minecraft:dark_prismarine
fill 148 257 345 148 258 345 minecraft:magenta_terracotta
fill 148 257 363 151 257 363 minecraft:blue_terracotta
fill 149 257 336 149 258 336 minecraft:dark_prismarine
fill 149 257 338 149 258 338 minecraft:dark_prismarine
fill 149 257 340 149 258 340 minecraft:dark_prismarine
fill 149 257 342 149 258 342 minecraft:dark_prismarine
fill 149 257 344 149 258 344 minecraft:magenta_terracotta
setblock 150 257 324 minecraft:blue_terracotta
fill 150 257 362 150 259 362 minecraft:blue_terracotta
setblock 151 257 324 minecraft:dark_prismarine
setblock 151 257 325 minecraft:light[level=12]
setblock 151 257 332 minecraft:light[level=12]
setblock 151 257 339 minecraft:light[level=12]
setblock 151 257 346 minecraft:light[level=12]
setblock 151 257 353 minecraft:light[level=12]
setblock 151 257 360 minecraft:light[level=12]
setblock 152 257 323 minecraft:dark_prismarine
fill 152 257 324 152 260 324 minecraft:blue_terracotta
setblock 152 257 363 minecraft:dark_prismarine
fill 153 257 323 156 257 323 minecraft:blue_terracotta
setblock 153 257 362 minecraft:dark_prismarine
fill 153 257 363 153 260 363 minecraft:blue_terracotta
fill 154 257 362 154 260 362 minecraft:blue_terracotta
setblock 157 257 363 minecraft:dark_prismarine
setblock 158 257 325 minecraft:light[level=12]
setblock 158 257 332 minecraft:light[level=12]
setblock 158 257 346 minecraft:light[level=12]
setblock 158 257 353 minecraft:light[level=12]
setblock 158 257 360 minecraft:light[level=12]
fill 158 257 363 158 260 363 minecraft:blue_terracotta
setblock 161 257 363 minecraft:purple_concrete
setblock 163 257 323 minecraft:purple_concrete
setblock 165 257 325 minecraft:light[level=12]
setblock 165 257 332 minecraft:light[level=12]
setblock 165 257 346 minecraft:light[level=12]
setblock 165 257 353 minecraft:light[level=12]
setblock 165 257 360 minecraft:light[level=12]
fill 165 257 363 166 257 363 minecraft:blue_terracotta
fill 167 257 337 168 258 337 minecraft:jungle_leaves[persistent=true]
fill 167 257 345 168 258 345 minecraft:jungle_leaves[persistent=true]
setblock 167 257 362 minecraft:blue_terracotta
setblock 167 257 363 minecraft:dark_prismarine
fill 168 257 336 168 258 336 minecraft:jungle_leaves[persistent=true]
fill 168 257 346 168 258 346 minecraft:jungle_leaves[persistent=true]
setblock 168 257 362 minecraft:dark_prismarine
fill 168 257 363 168 260 363 minecraft:blue_terracotta
fill 169 257 335 171 258 335 minecraft:jungle_leaves[persistent=true]
fill 169 257 347 171 258 347 minecraft:jungle_leaves[persistent=true]
fill 169 257 362 169 260 362 minecraft:blue_terracotta
setblock 172 257 325 minecraft:light[level=12]
setblock 172 257 353 minecraft:light[level=12]
setblock 172 257 360 minecraft:light[level=12]
setblock 172 257 363 minecraft:dark_prismarine
fill 173 257 335 175 258 335 minecraft:jungle_leaves[persistent=true]
fill 173 257 347 175 258 347 minecraft:jungle_leaves[persistent=true]
setblock 173 257 362 minecraft:dark_prismarine
fill 173 257 363 173 260 363 minecraft:blue_terracotta
fill 176 257 336 176 258 336 minecraft:jungle_leaves[persistent=true]
fill 176 257 346 176 258 346 minecraft:jungle_leaves[persistent=true]
fill 177 257 337 177 258 337 minecraft:jungle_leaves[persistent=true]
fill 177 257 345 177 258 345 minecraft:jungle_leaves[persistent=true]
fill 178 257 338 178 258 340 minecraft:jungle_leaves[persistent=true]
fill 178 257 342 178 258 344 minecraft:jungle_leaves[persistent=true]
setblock 179 257 325 minecraft:light[level=12]
setblock 179 257 339 minecraft:light[level=12]
setblock 179 257 346 minecraft:light[level=12]
setblock 179 257 353 minecraft:light[level=12]
setblock 179 257 360 minecraft:light[level=12]
setblock 182 257 323 minecraft:purple_concrete
fill 182 257 329 182 263 329 minecraft:dark_prismarine
setblock 182 257 333 minecraft:dark_prismarine
fill 182 257 334 182 260 334 minecraft:blue_terracotta
setblock 182 257 338 minecraft:dark_prismarine
fill 182 257 339 182 260 339 minecraft:blue_terracotta
setblock 182 257 348 minecraft:purple_concrete
fill 141 258 361 141 308 361 minecraft:blue_concrete
setblock 142 258 325 minecraft:purple_concrete
fill 142 258 330 142 258 331 minecraft:blue_terracotta
setblock 142 258 332 minecraft:dark_prismarine
fill 142 258 333 142 261 333 minecraft:blue_terracotta
setblock 142 258 337 minecraft:dark_prismarine
fill 142 258 338 142 261 338 minecraft:blue_terracotta
setblock 142 258 344 minecraft:purple_concrete
setblock 143 258 336 minecraft:dark_prismarine
fill 143 258 337 143 261 337 minecraft:blue_terracotta
setblock 143 258 338 minecraft:dark_prismarine
fill 147 258 323 150 258 323 minecraft:blue_terracotta
fill 147 258 363 150 258 363 minecraft:blue_terracotta
fill 149 258 362 149 260 362 minecraft:blue_terracotta
setblock 150 258 324 minecraft:dark_prismarine
setblock 151 258 323 minecraft:dark_prismarine
fill 151 258 324 151 261 324 minecraft:blue_terracotta
setblock 151 258 363 minecraft:dark_prismarine
fill 152 258 323 155 258 323 minecraft:blue_terracotta
setblock 152 258 362 minecraft:dark_prismarine
fill 152 258 363 152 261 363 minecraft:blue_terracotta
fill 153 258 362 153 261 362 minecraft:blue_terracotta
setblock 156 258 323 minecraft:dark_prismarine
setblock 156 258 363 minecraft:dark_prismarine
setblock 157 258 323 minecraft:purple_concrete
fill 157 258 363 157 261 363 minecraft:blue_terracotta
fill 163 258 363 165 258 363 minecraft:blue_terracotta
setblock 166 258 362 minecraft:blue_terracotta
setblock 166 258 363 minecraft:dark_prismarine
fill 167 258 338 170 259 338 minecraft:jungle_leaves[persistent=true]
fill 167 258 344 170 259 344 minecraft:jungle_leaves[persistent=true]
setblock 167 258 362 minecraft:dark_prismarine
fill 167 258 363 167 261 363 minecraft:blue_terracotta
fill 168 258 362 168 261 362 minecraft:blue_terracotta
fill 169 258 361 171 259 361 minecraft:blue_terracotta
setblock 171 258 363 minecraft:dark_prismarine
setblock 172 258 362 minecraft:dark_prismarine
fill 172 258 363 172 261 363 minecraft:blue_terracotta
fill 173 258 362 173 261 362 minecraft:blue_terracotta
setblock 176 258 323 minecraft:purple_concrete
fill 182 258 332 182 259 332 minecraft:dark_prismarine
fill 182 258 333 182 261 333 minecraft:blue_terracotta
setblock 182 258 337 minecraft:dark_prismarine
fill 182 258 338 182 261 338 minecraft:blue_terracotta
setblock 182 258 341 minecraft:blue_terracotta
setblock 182 258 342 minecraft:purple_concrete
setblock 182 258 361 minecraft:purple_concrete
setblock 142 259 331 minecraft:dark_prismarine
fill 142 259 332 142 262 332 minecraft:blue_terracotta
fill 142 259 334 142 260 334 minecraft:blue_terracotta
setblock 142 259 335 minecraft:sea_lantern
setblock 142 259 336 minecraft:dark_prismarine
setblock 142 259 337 minecraft:sea_lantern
setblock 142 259 339 minecraft:sea_lantern
setblock 142 259 340 minecraft:blue_terracotta
setblock 142 259 341 minecraft:sea_lantern
setblock 142 259 343 minecraft:sea_lantern
fill 142 259 344 142 262 344 minecraft:dark_prismarine
setblock 142 259 345 minecraft:sea_lantern
setblock 142 259 350 minecraft:purple_concrete
setblock 143 259 335 minecraft:dark_prismarine
setblock 143 259 336 minecraft:sea_lantern
setblock 143 259 338 minecraft:sea_lantern
setblock 143 259 340 minecraft:sea_lantern
setblock 143 259 342 minecraft:sea_lantern
setblock 143 259 344 minecraft:sea_lantern
setblock 144 259 335 minecraft:sea_lantern
setblock 144 259 337 minecraft:sea_lantern
setblock 144 259 339 minecraft:sea_lantern
setblock 144 259 341 minecraft:sea_lantern
setblock 144 259 343 minecraft:sea_lantern
setblock 144 259 345 minecraft:sea_lantern
fill 144 259 364 146 291 364 minecraft:blue_concrete
setblock 145 259 336 minecraft:sea_lantern
setblock 145 259 338 minecraft:sea_lantern
setblock 145 259 340 minecraft:sea_lantern
setblock 145 259 342 minecraft:sea_lantern
setblock 145 259 344 minecraft:sea_lantern
fill 146 259 323 149 259 323 minecraft:blue_terracotta
setblock 146 259 335 minecraft:sea_lantern
setblock 146 259 337 minecraft:sea_lantern
setblock 146 259 339 minecraft:sea_lantern
setblock 146 259 341 minecraft:sea_lantern
setblock 146 259 343 minecraft:sea_lantern
setblock 146 259 345 minecraft:sea_lantern
fill 146 259 363 149 259 363 minecraft:blue_terracotta
setblock 147 259 336 minecraft:sea_lantern
setblock 147 259 338 minecraft:sea_lantern
setblock 147 259 340 minecraft:sea_lantern
setblock 147 259 342 minecraft:sea_lantern
setblock 147 259 344 minecraft:sea_lantern
setblock 147 259 364 minecraft:light_blue_wool
setblock 148 259 335 minecraft:sea_lantern
setblock 148 259 337 minecraft:sea_lantern
setblock 148 259 339 minecraft:sea_lantern
setblock 148 259 341 minecraft:sea_lantern
setblock 148 259 343 minecraft:sea_lantern
setblock 148 259 345 minecraft:sea_lantern
fill 148 259 362 148 261 362 minecraft:blue_terracotta
fill 148 259 364 148 308 364 minecraft:blue_concrete
setblock 149 259 324 minecraft:dark_prismarine
setblock 149 259 336 minecraft:sea_lantern
setblock 149 259 338 minecraft:sea_lantern
setblock 149 259 340 minecraft:sea_lantern
setblock 149 259 342 minecraft:sea_lantern
setblock 149 259 344 minecraft:sea_lantern
setblock 150 259 323 minecraft:dark_prismarine
fill 150 259 324 150 262 324 minecraft:blue_terracotta
setblock 150 259 363 minecraft:dark_prismarine
fill 151 259 323 154 259 323 minecraft:blue_terracotta
setblock 151 259 361 minecraft:blue_terracotta
setblock 151 259 362 minecraft:dark_prismarine
fill 151 259 363 151 262 363 minecraft:blue_terracotta
setblock 152 259 361 minecraft:dark_prismarine
fill 152 259 362 152 262 362 minecraft:blue_terracotta
fill 153 259 361 153 262 361 minecraft:blue_terracotta
setblock 155 259 323 minecraft:dark_prismarine
setblock 155 259 363 minecraft:dark_prismarine
setblock 156 259 362 minecraft:dark_prismarine
fill 156 259 363 156 262 363 minecraft:blue_terracotta
setblock 160 259 363 minecraft:dark_prismarine
setblock 161 259 322 minecraft:light_blue_wool
fill 161 259 363 164 259 363 minecraft:blue_terracotta
fill 162 259 322 163 308 322 minecraft:blue_concrete
setblock 165 259 362 minecraft:blue_terracotta
setblock 165 259 363 minecraft:dark_prismarine
setblock 166 259 341 minecraft:jungle_leaves[persistent=true]
setblock 166 259 362 minecraft:dark_prismarine
fill 166 259 363 166 262 363 minecraft:blue_terracotta
setblock 167 259 361 minecraft:dark_prismarine
fill 167 259 362 167 262 362 minecraft:blue_terracotta
setblock 168 259 337 minecraft:jungle_leaves[persistent=true]
setblock 168 259 345 minecraft:jungle_leaves[persistent=true]
fill 168 259 361 168 262 361 minecraft:blue_terracotta
setblock 170 259 323 minecraft:purple_concrete
setblock 170 259 363 minecraft:dark_prismarine
setblock 171 259 362 minecraft:dark_prismarine
fill 171 259 363 171 262 363 minecraft:blue_terracotta
setblock 172 259 361 minecraft:dark_prismarine
fill 172 259 362 172 262 362 minecraft:blue_terracotta
setblock 182 259 336 minecraft:dark_prismarine
fill 182 259 337 182 262 337 minecraft:blue_terracotta
setblock 182 259 341 minecraft:dark_prismarine
fill 182 259 342 182 262 342 minecraft:blue_terracotta
setblock 182 259 355 minecraft:purple_concrete
setblock 142 260 330 minecraft:dark_prismarine
fill 142 260 331 142 263 331 minecraft:blue_terracotta
setblock 142 260 335 minecraft:dark_prismarine
fill 142 260 336 142 261 337 minecraft:blue_terracotta
setblock 142 260 339 minecraft:blue_terracotta
fill 142 260 340 143 260 340 minecraft:dark_prismarine
fill 142 260 341 142 261 341 minecraft:blue_terracotta
setblock 142 260 343 minecraft:dark_prismarine
fill 142 260 345 142 261 345 minecraft:dark_prismarine
setblock 142 260 356 minecraft:purple_concrete
setblock 143 260 334 minecraft:dark_prismarine
fill 143 260 335 143 261 336 minecraft:blue_terracotta
setblock 143 260 338 minecraft:blue_terracotta
fill 143 260 342 143 261 342 minecraft:dark_prismarine
fill 143 260 344 143 261 344 minecraft:dark_prismarine
fill 144 260 335 144 261 335 minecraft:dark_prismarine
fill 144 260 337 144 261 337 minecraft:dark_prismarine
fill 144 260 339 144 261 339 minecraft:dark_prismarine
fill 144 260 341 144 261 341 minecraft:dark_prismarine
fill 144 260 343 144 261 343 minecraft:dark_prismarine
fill 144 260 345 144 261 345 minecraft:dark_prismarine
fill 145 260 323 148 260 323 minecraft:blue_terracotta
fill 145 260 336 145 261 336 minecraft:dark_prismarine
fill 145 260 338 145 261 338 minecraft:dark_prismarine
fill 145 260 340 145 261 340 minecraft:dark_prismarine
fill 145 260 342 145 261 342 minecraft:dark_prismarine
fill 145 260 344 145 261 344 minecraft:dark_prismarine
fill 145 260 363 148 260 363 minecraft:blue_terracotta
fill 146 260 335 146 261 335 minecraft:dark_prismarine
fill 146 260 337 146 261 337 minecraft:dark_prismarine
fill 146 260 339 146 261 339 minecraft:dark_prismarine
fill 146 260 341 146 261 341 minecraft:dark_prismarine
fill 146 260 343 146 261 343 minecraft:dark_prismarine
fill 146 260 345 146 261 345 minecraft:dark_prismarine
setblock 147 260 324 minecraft:blue_terracotta
fill 147 260 336 147 261 336 minecraft:dark_prismarine
fill 147 260 338 147 261 338 minecraft:dark_prismarine
fill 147 260 340 147 261 340 minecraft:dark_prismarine
fill 147 260 342 147 261 342 minecraft:dark_prismarine
fill 147 260 344 147 261 344 minecraft:dark_prismarine
fill 147 260 362 147 262 362 minecraft:blue_terracotta
fill 147 260 364 147 308 364 minecraft:blue_concrete
setblock 148 260 324 minecraft:dark_prismarine
fill 148 260 335 148 261 335 minecraft:dark_prismarine
fill 148 260 337 148 261 337 minecraft:dark_prismarine
fill 148 260 339 148 261 339 minecraft:dark_prismarine
fill 148 260 341 148 261 341 minecraft:dark_prismarine
fill 148 260 343 148 261 343 minecraft:magenta_terracotta
fill 148 260 345 148 261 345 minecraft:dark_prismarine
setblock 149 260 323 minecraft:dark_prismarine
fill 149 260 324 149 263 324 minecraft:blue_terracotta
fill 149 260 336 149 261 336 minecraft:dark_prismarine
fill 149 260 338 149 261 338 minecraft:dark_prismarine
fill 149 260 340 149 261 340 minecraft:dark_prismarine
fill 149 260 342 149 261 342 minecraft:dark_prismarine
fill 149 260 344 149 261 344 minecraft:magenta_terracotta
fill 149 260 361 150 260 361 minecraft:blue_terracotta
setblock 149 260 363 minecraft:dark_prismarine
fill 150 260 323 153 260 323 minecraft:blue_terracotta
setblock 150 260 362 minecraft:dark_prismarine
fill 150 260 363 150 263 363 minecraft:blue_terracotta
setblock 151 260 361 minecraft:dark_prismarine
fill 151 260 362 151 263 362 minecraft:blue_terracotta
fill 152 260 361 152 263 361 minecraft:blue_terracotta
setblock 154 260 323 minecraft:dark_prismarine
fill 154 260 361 154 261 361 minecraft:blue_terracotta
setblock 154 260 363 minecraft:dark_prismarine
fill 155 260 323 156 262 323 minecraft:blue_terracotta
setblock 155 260 362 minecraft:dark_prismarine
fill 155 260 363 155 263 363 minecraft:blue_terracotta
fill 156 260 362 157 262 362 minecraft:blue_terracotta
setblock 159 260 363 minecraft:dark_prismarine
fill 160 260 363 163 260 363 minecraft:blue_terracotta
fill 161 260 322 161 308 322 minecraft:blue_concrete
fill 163 260 362 164 260 362 minecraft:blue_terracotta
setblock 164 260 323 minecraft:purple_concrete
setblock 164 260 363 minecraft:dark_prismarine
setblock 165 260 362 minecraft:dark_prismarine
fill 165 260 363 165 263 363 minecraft:blue_terracotta
setblock 166 260 361 minecraft:dark_prismarine
fill 166 260 362 166 263 362 minecraft:blue_terracotta
fill 167 260 361 167 263 361 minecraft:blue_terracotta
fill 169 260 339 169 260 340 minecraft:jungle_leaves[persistent=true]
fill 169 260 342 169 260 343 minecraft:jungle_leaves[persistent=true]
fill 169 260 361 170 260 361 minecraft:blue_terracotta
setblock 169 260 363 minecraft:dark_prismarine
fill 170 260 338 172 260 338 minecraft:jungle_leaves[persistent=true]
fill 170 260 344 172 260 344 minecraft:jungle_leaves[persistent=true]
setblock 170 260 362 minecraft:dark_prismarine
fill 170 260 363 170 263 363 minecraft:blue_terracotta
setblock 171 260 361 minecraft:dark_prismarine
fill 171 260 362 171 263 362 minecraft:blue_terracotta
fill 172 260 361 172 263 361 minecraft:blue_terracotta
setblock 174 260 363 minecraft:dark_prismarine
fill 175 260 363 175 263 363 minecraft:blue_terracotta
fill 176 260 341 176 262 342 minecraft:magenta_terracotta
setblock 179 260 363 minecraft:purple_concrete
setblock 181 260 336 minecraft:dark_prismarine
fill 181 260 337 181 261 339 minecraft:blue_terracotta
setblock 182 260 330 minecraft:purple_concrete
fill 182 260 332 182 262 332 minecraft:blue_terracotta
setblock 182 260 335 minecraft:dark_prismarine
fill 182 260 336 182 263 336 minecraft:blue_terracotta
setblock 182 260 340 minecraft:dark_prismarine
fill 182 260 341 182 263 341 minecraft:blue_terracotta
fill 182 260 343 182 261 343 minecraft:blue_terracotta
setblock 182 260 349 minecraft:purple_concrete
setblock 141 261 348 minecraft:light_blue_wool
fill 141 261 349 141 272 354 minecraft:blue_concrete
fill 142 261 330 142 264 330 minecraft:blue_terracotta
setblock 142 261 334 minecraft:dark_prismarine
setblock 142 261 335 minecraft:blue_terracotta
setblock 142 261 339 minecraft:dark_prismarine
fill 142 261 340 143 261 340 minecraft:blue_terracotta
fill 142 261 342 142 262 342 minecraft:blue_terracotta
setblock 142 261 343 minecraft:purple_concrete
setblock 142 261 362 minecraft:purple_concrete
setblock 143 261 323 minecraft:dark_prismarine
setblock 143 261 332 minecraft:blue_terracotta
setblock 143 261 333 minecraft:dark_prismarine
fill 143 261 334 143 264 334 minecraft:blue_terracotta
setblock 143 261 338 minecraft:dark_prismarine
fill 143 261 339 143 264 339 minecraft:blue_terracotta
setblock 143 261 363 minecraft:dark_prismarine
fill 144 261 323 147 261 323 minecraft:blue_terracotta
setblock 144 261 325 minecraft:light[level=13]
setblock 144 261 333 minecraft:light[level=13]
setblock 144 261 349 minecraft:light[level=13]
setblock 144 261 357 minecraft:light[level=13]
fill 144 261 363 147 261 363 minecraft:blue_terracotta
fill 145 261 362 146 263 362 minecraft:blue_terracotta
setblock 146 261 324 minecraft:blue_terracotta
setblock 147 261 324 minecraft:dark_prismarine
fill 147 261 361 149 261 361 minecraft:blue_terracotta
setblock 148 261 323 minecraft:dark_prismarine
fill 148 261 324 148 264 324 minecraft:blue_terracotta
setblock 148 261 363 minecraft:dark_prismarine
fill 149 261 323 152 261 323 minecraft:blue_terracotta
setblock 149 261 362 minecraft:dark_prismarine
fill 149 261 363 149 264 363 minecraft:blue_terracotta
setblock 150 261 361 minecraft:dark_prismarine
fill 150 261 362 150 264 362 minecraft:blue_terracotta
fill 151 261 361 151 264 361 minecraft:blue_terracotta
setblock 152 261 324 minecraft:dark_prismarine
setblock 152 261 325 minecraft:light[level=13]
setblock 152 261 333 minecraft:light[level=13]
setblock 152 261 341 minecraft:light[level=13]
setblock 152 261 349 minecraft:light[level=13]
setblock 152 261 357 minecraft:light[level=13]
setblock 153 261 323 minecraft:dark_prismarine
fill 153 261 324 153 264 324 minecraft:blue_terracotta
setblock 153 261 363 minecraft:dark_prismarine
fill 154 261 323 154 264 323 minecraft:blue_terracotta
setblock 154 261 362 minecraft:dark_prismarine
fill 154 261 363 154 264 363 minecraft:blue_terracotta
setblock 155 261 361 minecraft:dark_prismarine
fill 155 261 362 155 264 362 minecraft:blue_terracotta
fill 156 261 328 156 277 328 minecraft:magenta_terracotta
setblock 158 261 323 minecraft:purple_concrete
setblock 158 261 362 minecraft:blue_terracotta
setblock 158 261 363 minecraft:dark_prismarine
setblock 159 261 362 minecraft:dark_prismarine
fill 159 261 363 162 261 363 minecraft:blue_terracotta
setblock 160 261 325 minecraft:light[level=13]
setblock 160 261 333 minecraft:light[level=13]
setblock 160 261 341 minecraft:light[level=13]
setblock 160 261 349 minecraft:light[level=13]
setblock 160 261 357 minecraft:light[level=13]
fill 160 261 362 163 261 362 minecraft:blue_terracotta
setblock 163 261 363 minecraft:dark_prismarine
setblock 164 261 361 minecraft:blue_terracotta
setblock 164 261 362 minecraft:dark_prismarine
fill 164 261 363 164 264 363 minecraft:blue_terracotta
setblock 165 261 361 minecraft:dark_prismarine
fill 165 261 362 165 264 362 minecraft:blue_terracotta
fill 166 261 361 166 264 361 minecraft:blue_terracotta
setblock 167 261 323 minecraft:blue_terracotta
fill 167 261 360 170 261 360 minecraft:blue_terracotta
setblock 168 261 323 minecraft:dark_prismarine
setblock 168 261 325 minecraft:light[level=13]
setblock 168 261 333 minecraft:light[level=13]
setblock 168 261 341 minecraft:light[level=13]
setblock 168 261 349 minecraft:light[level=13]
setblock 168 261 357 minecraft:light[level=13]
setblock 168 261 363 minecraft:dark_prismarine
fill 169 261 323 170 263 323 minecraft:blue_terracotta
setblock 169 261 361 minecraft:blue_terracotta
setblock 169 261 362 minecraft:dark_prismarine
fill 169 261 363 169 264 363 minecraft:blue_terracotta
fill 170 261 358 170 272 358 minecraft:magenta_terracotta
setblock 170 261 361 minecraft:dark_prismarine
fill 170 261 362 170 264 362 minecraft:blue_terracotta
fill 171 261 361 171 264 361 minecraft:blue_terracotta
setblock 173 261 363 minecraft:dark_prismarine
setblock 174 261 362 minecraft:dark_prismarine
fill 174 261 363 174 264 363 minecraft:blue_terracotta
fill 175 261 342 175 268 342 minecraft:magenta_terracotta
setblock 176 261 325 minecraft:light[level=13]
setblock 176 261 349 minecraft:light[level=13]
setblock 176 261 357 minecraft:light[level=13]
setblock 181 261 335 minecraft:dark_prismarine
fill 181 261 336 181 264 336 minecraft:blue_terracotta
setblock 181 261 340 minecraft:dark_prismarine
fill 181 261 341 181 264 341 minecraft:blue_terracotta
setblock 182 261 324 minecraft:purple_concrete
fill 182 261 330 182 263 330 minecraft:dark_prismarine
setblock 182 261 334 minecraft:dark_prismarine
fill 182 261 335 182 264 335 minecraft:blue_terracotta
setblock 182 261 339 minecraft:dark_prismarine
fill 182 261 340 182 264 340 minecraft:blue_terracotta
setblock 182 261 344 minecraft:dark_prismarine
fill 141 262 348 141 308 348 minecraft:blue_concrete
setblock 142 262 323 minecraft:dark_prismarine
fill 142 262 324 142 262 327 minecraft:blue_terracotta
setblock 142 262 328 minecraft:dark_prismarine
fill 142 262 329 142 265 329 minecraft:blue_terracotta
setblock 142 262 333 minecraft:dark_prismarine
fill 142 262 334 142 265 334 minecraft:blue_terracotta
setblock 142 262 335 minecraft:sea_lantern
fill 142 262 336 142 263 336 minecraft:blue_terracotta
setblock 142 262 337 minecraft:sea_lantern
setblock 142 262 338 minecraft:dark_prismarine
setblock 142 262 339 minecraft:sea_lantern
fill 142 262 340 142 264 340 minecraft:blue_terracotta
setblock 142 262 341 minecraft:sea_lantern
setblock 142 262 343 minecraft:sea_lantern
setblock 142 262 345 minecraft:sea_lantern
setblock 142 262 349 minecraft:purple_concrete
setblock 142 262 358 minecraft:dark_prismarine
fill 142 262 359 142 262 362 minecraft:blue_terracotta
setblock 142 262 363 minecraft:dark_prismarine
fill 143 262 323 146 262 323 minecraft:blue_terracotta
setblock 143 262 332 minecraft:dark_prismarine
fill 143 262 333 143 265 333 minecraft:blue_terracotta
fill 143 262 335 143 263 335 minecraft:blue_terracotta
setblock 143 262 336 minecraft:sea_lantern
setblock 143 262 337 minecraft:dark_prismarine
setblock 143 262 338 minecraft:sea_lantern
setblock 143 262 340 minecraft:sea_lantern
setblock 143 262 341 minecraft:blue_terracotta
setblock 143 262 342 minecraft:sea_lantern
setblock 143 262 344 minecraft:sea_lantern
fill 143 262 363 146 262 363 minecraft:blue_terracotta
fill 144 262 324 145 262 324 minecraft:blue_terracotta
setblock 144 262 335 minecraft:sea_lantern
setblock 144 262 337 minecraft:sea_lantern
fill 144 262 338 144 264 338 minecraft:blue_terracotta
setblock 144 262 339 minecraft:sea_lantern
setblock 144 262 341 minecraft:sea_lantern
setblock 144 262 343 minecraft:sea_lantern
setblock 144 262 345 minecraft:sea_lantern
fill 144 262 362 144 265 362 minecraft:blue_terracotta
setblock 145 262 336 minecraft:sea_lantern
setblock 145 262 338 minecraft:sea_lantern
setblock 145 262 340 minecraft:sea_lantern
setblock 145 262 342 minecraft:sea_lantern
setblock 145 262 344 minecraft:sea_lantern
setblock 146 262 324 minecraft:dark_prismarine
setblock 146 262 335 minecraft:sea_lantern
setblock 146 262 337 minecraft:sea_lantern
setblock 146 262 339 minecraft:sea_lantern
setblock 146 262 341 minecraft:sea_lantern
setblock 146 262 343 minecraft:sea_lantern
setblock 146 262 345 minecraft:sea_lantern
fill 146 262 361 148 262 361 minecraft:blue_terracotta
setblock 147 262 323 minecraft:dark_prismarine
fill 147 262 324 147 265 324 minecraft:blue_terracotta
setblock 147 262 336 minecraft:sea_lantern
setblock 147 262 338 minecraft:sea_lantern
setblock 147 262 340 minecraft:sea_lantern
setblock 147 262 342 minecraft:sea_lantern
setblock 147 262 344 minecraft:sea_lantern
setblock 147 262 363 minecraft:dark_prismarine
fill 148 262 323 151 262 323 minecraft:blue_terracotta
fill 148 262 325 149 262 325 minecraft:blue_terracotta
setblock 148 262 335 minecraft:sea_lantern
setblock 148 262 337 minecraft:sea_lantern
setblock 148 262 339 minecraft:sea_lantern
setblock 148 262 341 minecraft:sea_lantern
setblock 148 262 343 minecraft:sea_lantern
setblock 148 262 345 minecraft:sea_lantern
setblock 148 262 362 minecraft:dark_prismarine
fill 148 262 363 148 265 363 minecraft:blue_terracotta
setblock 149 262 336 minecraft:sea_lantern
setblock 149 262 338 minecraft:sea_lantern
setblock 149 262 340 minecraft:sea_lantern
setblock 149 262 342 minecraft:sea_lantern
setblock 149 262 344 minecraft:sea_lantern
setblock 149 262 361 minecraft:dark_prismarine
fill 149 262 362 149 265 362 minecraft:blue_terracotta
setblock 150 262 360 minecraft:dark_prismarine
fill 150 262 361 150 265 361 minecraft:blue_terracotta
setblock 151 262 324 minecraft:dark_prismarine
setblock 152 262 323 minecraft:dark_prismarine
fill 152 262 324 152 265 324 minecraft:blue_terracotta
setblock 152 262 363 minecraft:dark_prismarine
fill 153 262 323 153 265 323 minecraft:blue_terracotta
setblock 153 262 362 minecraft:dark_prismarine
fill 153 262 363 153 265 363 minecraft:blue_terracotta
setblock 154 262 361 minecraft:dark_prismarine
fill 154 262 362 154 265 362 minecraft:blue_terracotta
fill 155 262 361 156 264 361 minecraft:blue_terracotta
setblock 157 262 323 minecraft:dark_prismarine
setblock 157 262 363 minecraft:dark_prismarine
setblock 158 262 362 minecraft:dark_prismarine
fill 158 262 363 161 262 363 minecraft:blue_terracotta
fill 159 262 362 162 262 362 minecraft:blue_terracotta
fill 162 262 361 163 262 361 minecraft:blue_terracotta
setblock 162 262 363 minecraft:dark_prismarine
setblock 163 262 362 minecraft:dark_prismarine
fill 163 262 363 163 265 363 minecraft:blue_terracotta
fill 164 262 323 166 262 323 minecraft:blue_terracotta
setblock 164 262 361 minecraft:dark_prismarine
fill 164 262 362 164 265 362 minecraft:blue_terracotta
setblock 165 262 360 minecraft:dark_prismarine
fill 165 262 361 165 265 361 minecraft:blue_terracotta
fill 166 262 360 169 262 360 minecraft:blue_terracotta
setblock 167 262 323 minecraft:dark_prismarine
setblock 167 262 363 minecraft:dark_prismarine
fill 168 262 323 168 265 323 minecraft:blue_terracotta
setblock 168 262 362 minecraft:dark_prismarine
fill 168 262 363 168 265 363 minecraft:blue_terracotta
setblock 169 262 361 minecraft:dark_prismarine
fill 169 262 362 169 265 362 minecraft:blue_terracotta
setblock 170 262 360 minecraft:dark_prismarine
fill 170 262 361 170 265 361 minecraft:blue_terracotta
setblock 171 262 323 minecraft:blue_terracotta
setblock 172 262 363 minecraft:dark_prismarine
setblock 173 262 362 minecraft:dark_prismarine
fill 173 262 363 173 265 363 minecraft:blue_terracotta
fill 174 262 362 174 265 362 minecraft:blue_terracotta
setblock 177 262 323 minecraft:purple_concrete
fill 181 262 335 181 265 335 minecraft:blue_terracotta
fill 181 262 337 181 262 338 minecraft:blue_terracotta
setblock 181 262 339 minecraft:dark_prismarine
fill 181 262 340 181 265 340 minecraft:blue_terracotta
fill 181 262 342 181 263 342 minecraft:blue_terracotta
fill 182 262 331 182 263 331 minecraft:blue_terracotta
setblock 182 262 333 minecraft:dark_prismarine
fill 182 262 334 182 265 334 minecraft:blue_terracotta
setblock 182 262 338 minecraft:dark_prismarine
fill 182 262 339 182 265 339 minecraft:blue_terracotta
setblock 182 262 343 minecraft:dark_prismarine
fill 182 262 344 182 264 345 minecraft:blue_terracotta
fill 182 262 359 182 264 360 minecraft:blue_terracotta
setblock 182 262 362 minecraft:purple_concrete
fill 142 263 323 142 263 326 minecraft:blue_terracotta
setblock 142 263 327 minecraft:dark_prismarine
fill 142 263 328 142 266 328 minecraft:blue_terracotta
setblock 142 263 332 minecraft:dark_prismarine
fill 142 263 333 142 266 333 minecraft:blue_terracotta
fill 142 263 335 142 264 335 minecraft:blue_terracotta
setblock 142 263 337 minecraft:dark_prismarine
fill 142 263 338 142 264 339 minecraft:blue_terracotta
setblock 142 263 341 minecraft:blue_terracotta
setblock 142 263 342 minecraft:dark_prismarine
fill 142 263 343 142 264 344 minecraft:blue_terracotta
setblock 142 263 345 minecraft:dark_prismarine
setblock 142 263 355 minecraft:purple_concrete
setblock 142 263 357 minecraft:dark_prismarine
fill 142 263 358 142 263 361 minecraft:blue_terracotta
setblock 142 263 362 minecraft:dark_prismarine
fill 142 263 363 145 263 363 minecraft:blue_terracotta
fill 143 263 323 143 263 325 minecraft:blue_terracotta
setblock 143 263 331 minecraft:dark_prismarine
fill 143 263 332 143 266 332 minecraft:blue_terracotta
setblock 143 263 336 minecraft:dark_prismarine
fill 143 263 337 143 264 338 minecraft:blue_terracotta
setblock 143 263 340 minecraft:blue_terracotta
fill 143 263 341 144 263 341 minecraft:dark_prismarine
fill 143 263 342 143 264 342 minecraft:blue_terracotta
setblock 143 263 344 minecraft:dark_prismarine
fill 143 263 359 143 263 360 minecraft:blue_terracotta
setblock 143 263 361 minecraft:dark_prismarine
fill 143 263 362 143 266 362 minecraft:blue_terracotta
fill 144 263 323 144 263 324 minecraft:blue_terracotta
setblock 144 263 325 minecraft:light[level=12]
setblock 144 263 332 minecraft:light[level=12]
setblock 144 263 334 minecraft:blue_terracotta
setblock 144 263 335 minecraft:dark_prismarine
fill 144 263 336 144 264 337 minecraft:blue_terracotta
setblock 144 263 339 minecraft:blue_terracotta
fill 144 263 343 144 264 343 minecraft:dark_prismarine
fill 144 263 345 144 264 345 minecraft:dark_prismarine
setblock 144 263 346 minecraft:light[level=12]
setblock 144 263 353 minecraft:light[level=12]
setblock 144 263 360 minecraft:light[level=12]
setblock 145 263 323 minecraft:blue_terracotta
setblock 145 263 324 minecraft:dark_prismarine
fill 145 263 336 145 264 336 minecraft:dark_prismarine
fill 145 263 338 145 264 338 minecraft:dark_prismarine
fill 145 263 340 145 264 340 minecraft:dark_prismarine
fill 145 263 342 145 264 342 minecraft:dark_prismarine
fill 145 263 344 145 264 344 minecraft:dark_prismarine
fill 145 263 361 147 263 361 minecraft:blue_terracotta
setblock 146 263 323 minecraft:dark_prismarine
fill 146 263 324 146 265 325 minecraft:blue_terracotta
fill 146 263 335 146 264 335 minecraft:dark_prismarine
fill 146 263 337 146 264 337 minecraft:dark_prismarine
fill 146 263 339 146 264 339 minecraft:dark_prismarine
fill 146 263 341 146 264 341 minecraft:dark_prismarine
fill 146 263 343 146 264 343 minecraft:dark_prismarine
fill 146 263 345 146 264 345 minecraft:dark_prismarine
setblock 146 263 363 minecraft:dark_prismarine
fill 147 263 323 150 263 323 minecraft:blue_terracotta
fill 147 263 325 148 263 325 minecraft:blue_terracotta
fill 147 263 336 147 264 336 minecraft:dark_prismarine
fill 147 263 338 147 264 338 minecraft:dark_prismarine
fill 147 263 340 147 264 340 minecraft:dark_prismarine
fill 147 263 342 147 264 342 minecraft:dark_prismarine
fill 147 263 344 147 264 344 minecraft:dark_prismarine
setblock 147 263 362 minecraft:dark_prismarine
fill 147 263 363 147 266 363 minecraft:blue_terracotta
fill 148 263 335 148 264 335 minecraft:dark_prismarine
fill 148 263 337 148 264 337 minecraft:dark_prismarine
fill 148 263 339 148 264 339 minecraft:dark_prismarine
fill 148 263 341 148 264 341 minecraft:dark_prismarine
fill 148 263 343 148 264 343 minecraft:magenta_terracotta
setblock 148 263 344 minecraft:pink_terracotta
fill 148 263 345 148 264 345 minecraft:dark_prismarine
setblock 148 263 360 minecraft:blue_terracotta
setblock 148 263 361 minecraft:dark_prismarine
fill 148 263 362 148 266 362 minecraft:blue_terracotta
setblock 149 263 325 minecraft:dark_prismarine
fill 149 263 336 149 264 336 minecraft:dark_prismarine
fill 149 263 338 149 264 338 minecraft:dark_prismarine
fill 149 263 340 149 264 340 minecraft:dark_prismarine
fill 149 263 342 149 264 342 minecraft:dark_prismarine
fill 149 263 344 149 264 344 minecraft:magenta_terracotta
setblock 149 263 360 minecraft:dark_prismarine
fill 149 263 361 149 266 361 minecraft:blue_terracotta
setblock 150 263 324 minecraft:dark_prismarine
fill 150 263 325 150 266 325 minecraft:blue_terracotta
fill 150 263 360 151 265 360 minecraft:blue_terracotta
setblock 151 263 323 minecraft:dark_prismarine
fill 151 263 324 151 266 324 minecraft:blue_terracotta
setblock 151 263 325 minecraft:light[level=12]
setblock 151 263 332 minecraft:light[level=12]
setblock 151 263 339 minecraft:light[level=12]
setblock 151 263 346 minecraft:light[level=12]
setblock 151 263 353 minecraft:light[level=12]
setblock 151 263 363 minecraft:dark_prismarine
fill 152 263 323 152 266 323 minecraft:blue_terracotta
setblock 152 263 362 minecraft:dark_prismarine
fill 152 263 363 152 266 363 minecraft:blue_terracotta
setblock 153 263 361 minecraft:dark_prismarine
fill 153 263 362 153 266 362 minecraft:blue_terracotta
fill 154 263 361 154 266 361 minecraft:blue_terracotta
setblock 155 263 323 minecraft:blue_terracotta
setblock 155 263 328 minecraft:pink_terracotta
setblock 155 263 358 minecraft:pink_terracotta
fill 155 263 359 155 275 359 minecraft:magenta_terracotta
setblock 156 263 323 minecraft:dark_prismarine
fill 156 263 358 156 277 358 minecraft:magenta_terracotta
setblock 156 263 362 minecraft:blue_terracotta
setblock 156 263 363 minecraft:dark_prismarine
fill 157 263 323 158 265 323 minecraft:blue_terracotta
setblock 157 263 361 minecraft:blue_terracotta
setblock 157 263 362 minecraft:dark_prismarine
fill 157 263 363 160 263 363 minecraft:blue_terracotta
setblock 158 263 325 minecraft:light[level=12]
setblock 158 263 332 minecraft:light[level=12]
setblock 158 263 339 minecraft:light[level=12]
setblock 158 263 346 minecraft:light[level=12]
setblock 158 263 353 minecraft:light[level=12]
setblock 158 263 360 minecraft:light[level=12]
fill 158 263 362 161 263 362 minecraft:blue_terracotta
fill 159 263 361 162 263 361 minecraft:blue_terracotta
setblock 161 263 323 minecraft:dark_prismarine
setblock 161 263 363 minecraft:dark_prismarine
fill 162 263 323 165 263 323 minecraft:blue_terracotta
setblock 162 263 362 minecraft:dark_prismarine
fill 162 263 363 162 266 363 minecraft:blue_terracotta
setblock 163 263 361 minecraft:dark_prismarine
fill 163 263 362 163 266 362 minecraft:blue_terracotta
setblock 164 263 360 minecraft:dark_prismarine
fill 164 263 361 164 266 361 minecraft:blue_terracotta
setblock 165 263 325 minecraft:light[level=12]
setblock 165 263 332 minecraft:light[level=12]
setblock 165 263 339 minecraft:light[level=12]
setblock 165 263 346 minecraft:light[level=12]
setblock 165 263 353 minecraft:light[level=12]
fill 165 263 360 168 263 360 minecraft:blue_terracotta
setblock 166 263 323 minecraft:dark_prismarine
fill 166 263 340 179 264 340 minecraft:dark_prismarine
setblock 166 263 363 minecraft:dark_prismarine
fill 167 263 323 167 266 323 minecraft:blue_terracotta
setblock 167 263 362 minecraft:dark_prismarine
fill 167 263 363 167 266 363 minecraft:blue_terracotta
setblock 168 263 361 minecraft:dark_prismarine
fill 168 263 362 168 266 362 minecraft:blue_terracotta
setblock 169 263 328 minecraft:pink_terracotta
setblock 169 263 358 minecraft:pink_terracotta
setblock 169 263 360 minecraft:dark_prismarine
fill 169 263 361 169 266 361 minecraft:blue_terracotta
fill 170 263 360 170 264 360 minecraft:blue_terracotta
setblock 171 263 323 minecraft:dark_prismarine
setblock 171 263 363 minecraft:dark_prismarine
fill 172 263 323 172 266 323 minecraft:blue_terracotta
setblock 172 263 325 minecraft:light[level=12]
setblock 172 263 339 minecraft:light[level=12]
setblock 172 263 346 minecraft:light[level=12]
setblock 172 263 353 minecraft:light[level=12]
setblock 172 263 360 minecraft:light[level=12]
setblock 172 263 362 minecraft:dark_prismarine
fill 172 263 363 172 266 363 minecraft:blue_terracotta
fill 173 263 362 173 266 362 minecraft:blue_terracotta
fill 174 263 341 175 264 341 minecraft:dark_prismarine
setblock 176 263 341 minecraft:magenta_terracotta
setblock 176 263 342 minecraft:pink_terracotta
fill 176 263 343 176 277 343 minecraft:magenta_terracotta
setblock 176 263 363 minecraft:dark_prismarine
fill 177 263 341 180 263 341 minecraft:dark_prismarine
setblock 178 263 363 minecraft:purple_concrete
setblock 179 263 325 minecraft:light[level=12]
setblock 179 263 339 minecraft:light[level=12]
setblock 179 263 346 minecraft:light[level=12]
setblock 179 263 353 minecraft:light[level=12]
setblock 179 263 360 minecraft:light[level=12]
setblock 180 263 338 minecraft:blue_terracotta
setblock 180 263 339 minecraft:dark_prismarine
fill 180 263 340 180 266 340 minecraft:blue_terracotta
fill 181 263 334 181 266 334 minecraft:blue_terracotta
setblock 181 263 337 minecraft:blue_terracotta
setblock 181 263 338 minecraft:dark_prismarine
fill 181 263 339 181 266 339 minecraft:blue_terracotta
setblock 181 263 343 minecraft:dark_prismarine
fill 181 263 344 181 266 344 minecraft:blue_terracotta
setblock 182 263 332 minecraft:dark_prismarine
fill 182 263 333 182 266 333 minecraft:blue_terracotta
setblock 182 263 337 minecraft:dark_prismarine
fill 182 263 338 182 266 338 minecraft:blue_terracotta
setblock 182 263 342 minecraft:dark_prismarine
fill 182 263 343 182 266 343 minecraft:blue_terracotta
setblock 182 263 346 minecraft:blue_terracotta
setblock 182 263 347 minecraft:dark_prismarine
setblock 182 263 356 minecraft:purple_concrete
fill 182 263 358 182 266 358 minecraft:blue_terracotta
setblock 182 263 361 minecraft:blue_terracotta
setblock 182 263 362 minecraft:dark_prismarine
fill 182 263 363 182 266 363 minecraft:blue_terracotta
setblock 183 263 323 minecraft:cyan_concrete
setblock 141 264 323 minecraft:light_blue_wool
fill 142 264 323 142 264 325 minecraft:blue_terracotta
setblock 142 264 326 minecraft:dark_prismarine
fill 142 264 327 143 266 327 minecraft:blue_terracotta
setblock 142 264 331 minecraft:dark_prismarine
fill 142 264 332 142 267 332 minecraft:blue_terracotta
setblock 142 264 336 minecraft:dark_prismarine
setblock 142 264 337 minecraft:blue_terracotta
setblock 142 264 341 minecraft:dark_prismarine
fill 142 264 342 142 267 342 minecraft:blue_terracotta
setblock 142 264 345 minecraft:blue_terracotta
fill 142 264 357 142 264 360 minecraft:blue_terracotta
setblock 142 264 361 minecraft:dark_prismarine
fill 142 264 362 142 266 363 minecraft:blue_terracotta
fill 143 264 323 143 264 324 minecraft:blue_terracotta
setblock 143 264 325 minecraft:dark_prismarine
fill 143 264 326 143 267 326 minecraft:blue_terracotta
fill 143 264 328 143 264 329 minecraft:blue_terracotta
setblock 143 264 330 minecraft:dark_prismarine
fill 143 264 331 143 267 331 minecraft:blue_terracotta
setblock 143 264 335 minecraft:dark_prismarine
setblock 143 264 336 minecraft:blue_terracotta
setblock 143 264 340 minecraft:dark_prismarine
fill 143 264 341 144 264 341 minecraft:blue_terracotta
fill 143 264 343 143 264 344 minecraft:blue_terracotta
fill 143 264 358 143 264 359 minecraft:blue_terracotta
setblock 143 264 360 minecraft:dark_prismarine
fill 143 264 361 146 264 361 minecraft:blue_terracotta
fill 143 264 363 144 264 363 minecraft:blue_terracotta
setblock 144 264 323 minecraft:blue_terracotta
setblock 144 264 324 minecraft:dark_prismarine
fill 144 264 325 145 266 325 minecraft:blue_terracotta
setblock 144 264 334 minecraft:dark_prismarine
setblock 144 264 335 minecraft:blue_terracotta
setblock 144 264 339 minecraft:dark_prismarine
fill 144 264 340 144 267 340 minecraft:blue_terracotta
fill 144 264 360 144 267 360 minecraft:blue_terracotta
setblock 145 264 323 minecraft:dark_prismarine
fill 145 264 324 145 267 324 minecraft:blue_terracotta
setblock 145 264 362 minecraft:blue_terracotta
setblock 145 264 363 minecraft:dark_prismarine
fill 146 264 323 149 264 323 minecraft:blue_terracotta
setblock 146 264 362 minecraft:dark_prismarine
fill 146 264 363 146 267 363 minecraft:blue_terracotta
setblock 147 264 325 minecraft:blue_terracotta
setblock 147 264 360 minecraft:blue_terracotta
setblock 147 264 361 minecraft:dark_prismarine
fill 147 264 362 147 267 362 minecraft:blue_terracotta
setblock 148 264 325 minecraft:dark_prismarine
fill 148 264 344 148 273 344 minecraft:magenta_terracotta
setblock 148 264 360 minecraft:dark_prismarine
fill 148 264 361 148 267 361 minecraft:blue_terracotta
setblock 149 264 324 minecraft:dark_prismarine
fill 149 264 325 149 267 325 minecraft:blue_terracotta
fill 149 264 360 149 266 360 minecraft:blue_terracotta
setblock 150 264 323 minecraft:dark_prismarine
fill 150 264 324 150 267 324 minecraft:blue_terracotta
fill 150 264 338 157 264 339 minecraft:dark_prismarine
setblock 150 264 363 minecraft:dark_prismarine
fill 151 264 323 151 267 323 minecraft:blue_terracotta
fill 151 264 325 151 265 325 minecraft:blue_terracotta
setblock 151 264 362 minecraft:dark_prismarine
fill 151 264 363 151 267 363 minecraft:blue_terracotta
setblock 152 264 361 minecraft:dark_prismarine
fill 152 264 362 152 267 362 minecraft:blue_terracotta
fill 153 264 361 153 267 361 minecraft:blue_terracotta
setblock 154 264 324 minecraft:dark_prismarine
setblock 155 264 323 minecraft:dark_prismarine
fill 155 264 328 155 277 328 minecraft:magenta_terracotta
fill 155 264 358 155 277 358 minecraft:magenta_terracotta
setblock 155 264 363 minecraft:dark_prismarine
fill 156 264 323 156 267 323 minecraft:blue_terracotta
setblock 156 264 362 minecraft:dark_prismarine
fill 156 264 363 159 264 363 minecraft:blue_terracotta
setblock 157 264 361 minecraft:dark_prismarine
fill 157 264 362 160 264 362 minecraft:blue_terracotta
fill 158 264 339 170 264 339 minecraft:dark_prismarine
fill 158 264 361 161 264 361 minecraft:blue_terracotta
setblock 159 264 323 minecraft:blue_terracotta
setblock 159 264 340 minecraft:dark_prismarine
setblock 160 264 323 minecraft:dark_prismarine
setblock 160 264 363 minecraft:dark_prismarine
fill 161 264 323 164 264 323 minecraft:blue_terracotta
fill 161 264 340 165 264 340 minecraft:dark_prismarine
setblock 161 264 362 minecraft:dark_prismarine
fill 161 264 363 161 267 363 minecraft:blue_terracotta
setblock 162 264 361 minecraft:dark_prismarine
fill 162 264 362 162 267 362 minecraft:blue_terracotta
setblock 163 264 360 minecraft:dark_prismarine
fill 163 264 361 163 267 361 minecraft:blue_terracotta
fill 164 264 360 167 264 360 minecraft:blue_terracotta
setblock 165 264 323 minecraft:dark_prismarine
setblock 165 264 363 minecraft:dark_prismarine
fill 166 264 323 166 267 323 minecraft:blue_terracotta
setblock 166 264 362 minecraft:dark_prismarine
fill 166 264 363 166 267 363 minecraft:blue_terracotta
fill 167 264 324 167 265 324 minecraft:blue_terracotta
setblock 167 264 361 minecraft:dark_prismarine
fill 167 264 362 167 267 362 minecraft:blue_terracotta
setblock 168 264 360 minecraft:dark_prismarine
fill 168 264 361 168 267 361 minecraft:blue_terracotta
setblock 169 264 323 minecraft:blue_terracotta
fill 169 264 328 169 277 328 minecraft:magenta_terracotta
fill 169 264 358 169 277 358 minecraft:magenta_terracotta
fill 169 264 360 169 265 360 minecraft:blue_terracotta
setblock 170 264 323 minecraft:dark_prismarine
setblock 170 264 363 minecraft:dark_prismarine
fill 171 264 323 171 267 323 minecraft:blue_terracotta
fill 171 264 341 173 264 341 minecraft:dark_prismarine
setblock 171 264 362 minecraft:dark_prismarine
fill 171 264 363 171 267 363 minecraft:blue_terracotta
setblock 172 264 361 minecraft:dark_prismarine
fill 172 264 362 172 267 362 minecraft:blue_terracotta
fill 173 264 323 173 265 323 minecraft:blue_terracotta
setblock 175 264 363 minecraft:dark_prismarine
fill 176 264 341 179 264 341 minecraft:dark_prismarine
fill 176 264 342 176 276 342 minecraft:magenta_terracotta
fill 176 264 363 177 266 363 minecraft:blue_terracotta
fill 179 264 322 179 308 322 minecraft:blue_concrete
setblock 180 264 322 minecraft:light_blue_wool
setblock 180 264 338 minecraft:dark_prismarine
fill 180 264 339 180 267 339 minecraft:blue_terracotta
fill 180 264 341 180 264 342 minecraft:blue_terracotta
setblock 180 264 363 minecraft:dark_prismarine
fill 181 264 322 182 308 322 minecraft:blue_concrete
fill 181 264 323 182 266 323 minecraft:blue_terracotta
setblock 181 264 337 minecraft:dark_prismarine
fill 181 264 338 181 267 338 minecraft:blue_terracotta
setblock 181 264 342 minecraft:dark_prismarine
fill 181 264 343 181 267 343 minecraft:blue_terracotta
fill 181 264 345 181 265 345 minecraft:blue_terracotta
fill 181 264 363 181 267 363 minecraft:blue_terracotta
fill 182 264 324 182 264 325 minecraft:blue_terracotta
setblock 182 264 326 minecraft:dark_prismarine
fill 182 264 327 182 264 330 minecraft:blue_terracotta
setblock 182 264 331 minecraft:dark_prismarine
fill 182 264 332 182 267 332 minecraft:blue_terracotta
setblock 182 264 336 minecraft:dark_prismarine
fill 182 264 337 182 267 337 minecraft:blue_terracotta
setblock 182 264 341 minecraft:dark_prismarine
fill 182 264 342 182 267 342 minecraft:blue_terracotta
setblock 182 264 346 minecraft:dark_prismarine
fill 182 264 347 182 266 348 minecraft:blue_terracotta
setblock 182 264 350 minecraft:purple_concrete
fill 182 264 357 182 265 357 minecraft:blue_terracotta
setblock 182 264 361 minecraft:dark_prismarine
fill 182 264 362 182 267 362 minecraft:blue_terracotta
fill 183 264 323 183 308 323 minecraft:blue_concrete
fill 141 265 323 141 308 323 minecraft:blue_concrete
fill 142 265 323 142 265 324 minecraft:blue_terracotta
setblock 142 265 325 minecraft:dark_prismarine
fill 142 265 326 142 268 326 minecraft:blue_terracotta
setblock 142 265 330 minecraft:dark_prismarine
fill 142 265 331 142 268 331 minecraft:blue_terracotta
setblock 142 265 335 minecraft:sea_lantern
fill 142 265 336 142 268 336 minecraft:blue_terracotta
setblock 142 265 337 minecraft:sea_lantern
fill 142 265 338 142 266 338 minecraft:blue_terracotta
setblock 142 265 339 minecraft:sea_lantern
setblock 142 265 340 minecraft:dark_prismarine
setblock 142 265 341 minecraft:sea_lantern
setblock 142 265 343 minecraft:sea_lantern
setblock 142 265 344 minecraft:blue_terracotta
setblock 142 265 345 minecraft:sea_lantern
fill 142 265 346 142 268 346 minecraft:blue_terracotta
fill 142 265 357 142 265 359 minecraft:blue_terracotta
setblock 142 265 360 minecraft:dark_prismarine
fill 142 265 361 145 265 361 minecraft:blue_terracotta
setblock 143 265 323 minecraft:blue_terracotta
setblock 143 265 324 minecraft:dark_prismarine
fill 143 265 325 143 268 325 minecraft:blue_terracotta
setblock 143 265 328 minecraft:blue_terracotta
setblock 143 265 329 minecraft:dark_prismarine
fill 143 265 330 143 268 330 minecraft:blue_terracotta
setblock 143 265 334 minecraft:dark_prismarine
fill 143 265 335 143 268 335 minecraft:blue_terracotta
setblock 143 265 336 minecraft:sea_lantern
fill 143 265 337 143 266 337 minecraft:blue_terracotta
setblock 143 265 338 minecraft:sea_lantern
setblock 143 265 339 minecraft:dark_prismarine
setblock 143 265 340 minecraft:sea_lantern
fill 143 265 341 143 267 341 minecraft:blue_terracotta
setblock 143 265 342 minecraft:sea_lantern
setblock 143 265 343 minecraft:blue_terracotta
setblock 143 265 344 minecraft:sea_lantern
setblock 143 265 358 minecraft:blue_terracotta
setblock 143 265 359 minecraft:dark_prismarine
fill 143 265 360 143 268 360 minecraft:blue_terracotta
setblock 143 265 363 minecraft:blue_terracotta
setblock 144 265 323 minecraft:dark_prismarine
fill 144 265 324 144 268 324 minecraft:blue_terracotta
fill 144 265 326 144 265 327 minecraft:blue_terracotta
setblock 144 265 334 minecraft:blue_terracotta
setblock 144 265 335 minecraft:sea_lantern
fill 144 265 336 144 266 336 minecraft:blue_terracotta
setblock 144 265 337 minecraft:sea_lantern
setblock 144 265 338 minecraft:dark_prismarine
setblock 144 265 339 minecraft:sea_lantern
setblock 144 265 341 minecraft:sea_lantern
setblock 144 265 342 minecraft:blue_terracotta
setblock 144 265 343 minecraft:sea_lantern
setblock 144 265 345 minecraft:sea_lantern
setblock 144 265 363 minecraft:dark_prismarine
fill 145 265 323 148 265 323 minecraft:blue_terracotta
setblock 145 265 336 minecraft:sea_lantern
setblock 145 265 338 minecraft:sea_lantern
setblock 145 265 340 minecraft:sea_lantern
setblock 145 265 342 minecraft:sea_lantern
setblock 145 265 344 minecraft:sea_lantern
setblock 145 265 362 minecraft:dark_prismarine
fill 145 265 363 145 268 363 minecraft:blue_terracotta
setblock 146 265 335 minecraft:sea_lantern
setblock 146 265 337 minecraft:sea_lantern
setblock 146 265 339 minecraft:sea_lantern
setblock 146 265 341 minecraft:sea_lantern
setblock 146 265 343 minecraft:sea_lantern
setblock 146 265 345 minecraft:sea_lantern
setblock 146 265 360 minecraft:blue_terracotta
setblock 146 265 361 minecraft:dark_prismarine
fill 146 265 362 146 268 362 minecraft:blue_terracotta
setblock 147 265 325 minecraft:dark_prismarine
setblock 147 265 336 minecraft:sea_lantern
setblock 147 265 338 minecraft:sea_lantern
setblock 147 265 340 minecraft:sea_lantern
setblock 147 265 342 minecraft:sea_lantern
setblock 147 265 344 minecraft:sea_lantern
setblock 147 265 360 minecraft:dark_prismarine
fill 147 265 361 147 268 361 minecraft:blue_terracotta
setblock 148 265 324 minecraft:dark_prismarine
fill 148 265 325 148 268 325 minecraft:blue_terracotta
setblock 148 265 335 minecraft:sea_lantern
setblock 148 265 337 minecraft:sea_lantern
setblock 148 265 339 minecraft:sea_lantern
setblock 148 265 341 minecraft:sea_lantern
setblock 148 265 343 minecraft:sea_lantern
setblock 148 265 345 minecraft:sea_lantern
fill 148 265 360 148 266 360 minecraft:blue_terracotta
setblock 149 265 323 minecraft:dark_prismarine
fill 149 265 324 149 268 324 minecraft:blue_terracotta
setblock 149 265 336 minecraft:sea_lantern
setblock 149 265 338 minecraft:sea_lantern
setblock 149 265 340 minecraft:sea_lantern
setblock 149 265 342 minecraft:sea_lantern
setblock 149 265 344 minecraft:sea_lantern
setblock 149 265 363 minecraft:dark_prismarine
fill 150 265 323 150 268 323 minecraft:blue_terracotta
fill 150 265 338 153 265 339 minecraft:dark_prismarine
setblock 150 265 362 minecraft:dark_prismarine
fill 150 265 363 150 268 363 minecraft:blue_terracotta
setblock 151 265 361 minecraft:dark_prismarine
fill 151 265 362 151 268 362 minecraft:blue_terracotta
fill 152 265 361 152 267 361 minecraft:blue_terracotta
setblock 153 265 324 minecraft:dark_prismarine
setblock 154 265 323 minecraft:dark_prismarine
fill 154 265 324 154 267 324 minecraft:blue_terracotta
fill 154 265 339 160 265 339 minecraft:dark_prismarine
setblock 154 265 363 minecraft:dark_prismarine
fill 155 265 323 155 268 323 minecraft:blue_terracotta
setblock 155 265 361 minecraft:blue_terracotta
setblock 155 265 362 minecraft:dark_prismarine
fill 155 265 363 158 265 363 minecraft:blue_terracotta
setblock 156 265 361 minecraft:dark_prismarine
fill 156 265 362 159 265 362 minecraft:blue_terracotta
fill 157 265 361 160 265 361 minecraft:blue_terracotta
setblock 159 265 323 minecraft:dark_prismarine
setblock 159 265 363 minecraft:dark_prismarine
fill 160 265 323 163 265 323 minecraft:blue_terracotta
setblock 160 265 362 minecraft:dark_prismarine
fill 160 265 363 160 268 363 minecraft:blue_terracotta
fill 161 265 339 163 265 339 minecraft:purple_concrete
setblock 161 265 361 minecraft:dark_prismarine
fill 161 265 362 161 268 362 minecraft:blue_terracotta
fill 162 265 361 162 268 361 minecraft:blue_terracotta
fill 163 265 360 166 265 360 minecraft:blue_terracotta
setblock 164 265 323 minecraft:dark_prismarine
fill 164 265 324 166 266 324 minecraft:blue_terracotta
setblock 164 265 363 minecraft:dark_prismarine
fill 165 265 323 165 268 323 minecraft:blue_terracotta
fill 165 265 340 177 265 340 minecraft:purple_concrete
setblock 165 265 362 minecraft:dark_prismarine
fill 165 265 363 165 268 363 minecraft:blue_terracotta
setblock 166 265 361 minecraft:dark_prismarine
fill 166 265 362 166 268 362 minecraft:blue_terracotta
setblock 167 265 360 minecraft:dark_prismarine
fill 167 265 361 167 268 361 minecraft:blue_terracotta
setblock 168 265 324 minecraft:dark_prismarine
fill 168 265 360 168 266 360 minecraft:blue_terracotta
setblock 169 265 323 minecraft:dark_prismarine
fill 169 265 324 169 268 324 minecraft:blue_terracotta
setblock 169 265 363 minecraft:dark_prismarine
fill 170 265 323 170 268 323 minecraft:blue_terracotta
setblock 170 265 362 minecraft:dark_prismarine
fill 170 265 363 170 268 363 minecraft:blue_terracotta
setblock 171 265 361 minecraft:dark_prismarine
fill 171 265 362 171 268 362 minecraft:blue_terracotta
setblock 174 265 363 minecraft:dark_prismarine
fill 175 265 363 175 267 363 minecraft:blue_terracotta
fill 176 265 341 179 265 341 minecraft:purple_concrete
setblock 178 265 323 minecraft:purple_concrete
setblock 178 265 363 minecraft:blue_terracotta
setblock 179 265 363 minecraft:dark_prismarine
fill 180 265 322 180 308 322 minecraft:blue_concrete
fill 180 265 323 180 268 323 minecraft:blue_terracotta
setblock 180 265 337 minecraft:dark_prismarine
fill 180 265 338 180 267 338 minecraft:blue_terracotta
setblock 180 265 341 minecraft:blue_terracotta
setblock 180 265 342 minecraft:dark_prismarine
fill 180 265 343 180 268 343 minecraft:blue_terracotta
fill 180 265 363 180 268 363 minecraft:blue_terracotta
setblock 181 265 336 minecraft:dark_prismarine
fill 181 265 337 181 268 337 minecraft:blue_terracotta
setblock 181 265 341 minecraft:dark_prismarine
fill 181 265 342 181 268 342 minecraft:blue_terracotta
setblock 181 265 346 minecraft:dark_prismarine
setblock 182 265 324 minecraft:blue_terracotta
setblock 182 265 325 minecraft:dark_prismarine
fill 182 265 326 182 265 329 minecraft:blue_terracotta
setblock 182 265 330 minecraft:dark_prismarine
fill 182 265 331 182 268 331 minecraft:blue_terracotta
setblock 182 265 335 minecraft:dark_prismarine
fill 182 265 336 182 268 336 minecraft:blue_terracotta
setblock 182 265 340 minecraft:dark_prismarine
fill 182 265 341 182 268 341 minecraft:blue_terracotta
setblock 182 265 344 minecraft:blue_terracotta
setblock 182 265 345 minecraft:dark_prismarine
fill 182 265 346 182 268 346 minecraft:blue_terracotta
setblock 182 265 349 minecraft:blue_terracotta
setblock 182 265 359 minecraft:blue_terracotta
setblock 182 265 360 minecraft:dark_prismarine
fill 182 265 361 182 268 361 minecraft:blue_terracotta
setblock 183 265 336 minecraft:light_blue_wool
fill 183 265 352 183 265 353 minecraft:blue_concrete
setblock 183 265 354 minecraft:light_blue_wool
setblock 142 266 323 minecraft:blue_terracotta
setblock 142 266 324 minecraft:dark_prismarine
fill 142 266 325 142 269 325 minecraft:blue_terracotta
setblock 142 266 329 minecraft:dark_prismarine
fill 142 266 330 142 269 330 minecraft:blue_terracotta
setblock 142 266 334 minecraft:dark_prismarine
fill 142 266 335 142 267 335 minecraft:blue_terracotta
fill 142 266 337 142 267 337 minecraft:blue_terracotta
setblock 142 266 339 minecraft:dark_prismarine
fill 142 266 340 142 267 341 minecraft:blue_terracotta
setblock 142 266 343 minecraft:blue_terracotta
setblock 142 266 344 minecraft:dark_prismarine
fill 142 266 345 143 267 345 minecraft:blue_terracotta
fill 142 266 347 142 267 347 minecraft:blue_terracotta
setblock 142 266 348 minecraft:purple_concrete
fill 142 266 354 142 267 354 minecraft:purple_concrete
fill 142 266 357 142 266 358 minecraft:blue_terracotta
setblock 142 266 359 minecraft:dark_prismarine
fill 142 266 360 142 268 361 minecraft:blue_terracotta
setblock 143 266 323 minecraft:dark_prismarine
fill 143 266 324 143 269 324 minecraft:blue_terracotta
setblock 143 266 328 minecraft:dark_prismarine
fill 143 266 329 143 269 329 minecraft:blue_terracotta
setblock 143 266 333 minecraft:dark_prismarine
fill 143 266 334 143 268 334 minecraft:blue_terracotta
fill 143 266 336 143 267 336 minecraft:blue_terracotta
setblock 143 266 338 minecraft:dark_prismarine
fill 143 266 339 143 267 340 minecraft:blue_terracotta
setblock 143 266 342 minecraft:blue_terracotta
setblock 143 266 343 minecraft:dark_prismarine
fill 143 266 344 143 267 344 minecraft:blue_terracotta
setblock 143 266 358 minecraft:dark_prismarine
fill 143 266 359 143 269 359 minecraft:blue_terracotta
fill 143 266 361 144 266 361 minecraft:blue_terracotta
setblock 143 266 363 minecraft:dark_prismarine
fill 144 266 323 147 266 323 minecraft:blue_terracotta
setblock 144 266 326 minecraft:blue_terracotta
setblock 144 266 327 minecraft:dark_prismarine
fill 144 266 328 144 269 328 minecraft:blue_terracotta
fill 144 266 335 144 267 335 minecraft:dark_prismarine
setblock 144 266 337 minecraft:dark_prismarine
fill 144 266 338 144 267 339 minecraft:blue_terracotta
setblock 144 266 341 minecraft:blue_terracotta
fill 144 266 342 145 266 342 minecraft:dark_prismarine
fill 144 266 343 144 267 343 minecraft:blue_terracotta
fill 144 266 345 144 267 345 minecraft:dark_prismarine
setblock 144 266 362 minecraft:dark_prismarine
fill 144 266 363 144 269 363 minecraft:blue_terracotta
fill 145 266 336 145 267 336 minecraft:dark_prismarine
fill 145 266 338 145 267 338 minecraft:dark_prismarine
fill 145 266 340 145 267 340 minecraft:dark_prismarine
fill 145 266 344 145 267 344 minecraft:dark_prismarine
setblock 145 266 361 minecraft:dark_prismarine
fill 145 266 362 145 269 362 minecraft:blue_terracotta
setblock 146 266 324 minecraft:blue_terracotta
setblock 146 266 325 minecraft:dark_prismarine
fill 146 266 335 146 267 335 minecraft:dark_prismarine
fill 146 266 337 146 267 337 minecraft:dark_prismarine
fill 146 266 339 146 267 339 minecraft:dark_prismarine
fill 146 266 341 146 267 341 minecraft:dark_prismarine
fill 146 266 343 146 267 343 minecraft:dark_prismarine
fill 146 266 345 146 267 345 minecraft:dark_prismarine
fill 146 266 361 146 269 361 minecraft:blue_terracotta
setblock 147 266 324 minecraft:dark_prismarine
fill 147 266 325 147 269 325 minecraft:blue_terracotta
fill 147 266 336 147 267 336 minecraft:dark_prismarine
fill 147 266 338 147 267 338 minecraft:dark_prismarine
fill 147 266 340 147 267 340 minecraft:dark_prismarine
fill 147 266 342 147 267 342 minecraft:dark_prismarine
fill 147 266 344 147 267 344 minecraft:dark_prismarine
setblock 147 266 360 minecraft:blue_terracotta
setblock 148 266 323 minecraft:dark_prismarine
fill 148 266 324 148 269 324 minecraft:blue_terracotta
fill 148 266 335 148 267 335 minecraft:dark_prismarine
fill 148 266 337 148 267 337 minecraft:dark_prismarine
fill 148 266 339 148 267 339 minecraft:dark_prismarine
fill 148 266 341 148 267 341 minecraft:dark_prismarine
fill 148 266 343 148 267 343 minecraft:magenta_terracotta
fill 148 266 345 148 267 345 minecraft:dark_prismarine
setblock 148 266 363 minecraft:dark_prismarine
fill 149 266 323 149 269 323 minecraft:blue_terracotta
fill 149 266 336 149 267 336 minecraft:dark_prismarine
fill 149 266 338 149 267 338 minecraft:dark_prismarine
fill 149 266 340 149 267 340 minecraft:dark_prismarine
fill 149 266 342 149 267 342 minecraft:dark_prismarine
setblock 149 266 344 minecraft:magenta_terracotta
setblock 149 266 362 minecraft:dark_prismarine
fill 149 266 363 149 269 363 minecraft:blue_terracotta
fill 150 266 338 151 266 338 minecraft:purple_concrete
setblock 150 266 361 minecraft:dark_prismarine
fill 150 266 362 150 269 362 minecraft:blue_terracotta
setblock 151 266 325 minecraft:dark_prismarine
fill 151 266 361 151 268 361 minecraft:blue_terracotta
setblock 152 266 324 minecraft:dark_prismarine
setblock 153 266 323 minecraft:dark_prismarine
fill 153 266 324 153 268 324 minecraft:blue_terracotta
setblock 153 266 363 minecraft:dark_prismarine
fill 154 266 323 154 269 323 minecraft:blue_terracotta
fill 154 266 339 159 266 339 minecraft:purple_concrete
setblock 154 266 362 minecraft:dark_prismarine
fill 154 266 363 157 266 363 minecraft:blue_terracotta
setblock 155 266 361 minecraft:dark_prismarine
fill 155 266 362 158 266 362 minecraft:blue_terracotta
fill 156 266 361 159 266 361 minecraft:blue_terracotta
setblock 157 266 323 minecraft:blue_terracotta
setblock 158 266 323 minecraft:dark_prismarine
setblock 158 266 363 minecraft:dark_prismarine
fill 159 266 323 162 266 323 minecraft:blue_terracotta
setblock 159 266 362 minecraft:dark_prismarine
fill 159 266 363 159 269 363 minecraft:blue_terracotta
setblock 160 266 361 minecraft:dark_prismarine
fill 160 266 362 160 269 362 minecraft:blue_terracotta
fill 161 266 361 161 269 361 minecraft:blue_terracotta
setblock 163 266 323 minecraft:dark_prismarine
fill 163 266 324 163 269 324 minecraft:blue_terracotta
fill 163 266 360 165 266 360 minecraft:blue_terracotta
setblock 163 266 363 minecraft:dark_prismarine
setblock 164 266 322 minecraft:cyan_concrete
fill 164 266 323 164 269 323 minecraft:blue_terracotta
setblock 164 266 362 minecraft:dark_prismarine
fill 164 266 363 164 269 363 minecraft:blue_terracotta
setblock 165 266 361 minecraft:dark_prismarine
fill 165 266 362 165 269 362 minecraft:blue_terracotta
setblock 166 266 360 minecraft:dark_prismarine
fill 166 266 361 166 269 361 minecraft:blue_terracotta
setblock 167 266 324 minecraft:dark_prismarine
fill 167 266 355 168 267 356 minecraft:black_concrete
setblock 167 266 360 minecraft:blue_terracotta
setblock 168 266 323 minecraft:dark_prismarine
fill 168 266 324 168 269 324 minecraft:blue_terracotta
setblock 168 266 363 minecraft:dark_prismarine
fill 169 266 323 169 269 323 minecraft:blue_terracotta
setblock 169 266 362 minecraft:dark_prismarine
fill 169 266 363 169 269 363 minecraft:blue_terracotta
setblock 170 266 361 minecraft:dark_prismarine
fill 170 266 362 170 268 362 minecraft:blue_terracotta
setblock 171 266 361 minecraft:blue_terracotta
setblock 173 266 323 minecraft:dark_prismarine
setblock 173 266 363 minecraft:dark_prismarine
fill 174 266 323 174 267 323 minecraft:blue_terracotta
fill 174 266 346 175 267 346 minecraft:black_concrete
fill 174 266 363 174 267 363 minecraft:blue_terracotta
setblock 178 266 323 minecraft:dark_prismarine
setblock 178 266 363 minecraft:dark_prismarine
fill 179 266 323 179 269 323 minecraft:blue_terracotta
fill 179 266 363 179 268 363 minecraft:blue_terracotta
setblock 180 266 341 minecraft:dark_prismarine
fill 180 266 342 180 269 342 minecraft:blue_terracotta
setblock 181 266 335 minecraft:dark_prismarine
fill 181 266 336 181 269 336 minecraft:blue_terracotta
setblock 181 266 340 minecraft:dark_prismarine
fill 181 266 341 181 269 341 minecraft:blue_terracotta
setblock 181 266 345 minecraft:dark_prismarine
fill 181 266 346 181 269 346 minecraft:blue_terracotta
setblock 182 266 324 minecraft:dark_prismarine
fill 182 266 325 182 266 328 minecraft:blue_terracotta
setblock 182 266 329 minecraft:dark_prismarine
fill 182 266 330 182 269 330 minecraft:blue_terracotta
setblock 182 266 334 minecraft:dark_prismarine
fill 182 266 335 182 269 335 minecraft:blue_terracotta
setblock 182 266 339 minecraft:dark_prismarine
fill 182 266 340 182 269 340 minecraft:blue_terracotta
setblock 182 266 344 minecraft:dark_prismarine
fill 182 266 345 182 269 345 minecraft:blue_terracotta
setblock 182 266 349 minecraft:dark_prismarine
setblock 182 266 357 minecraft:purple_concrete
setblock 182 266 359 minecraft:dark_prismarine
fill 182 266 360 182 269 360 minecraft:blue_terracotta
fill 183 266 336 183 288 336 minecraft:blue_concrete
fill 183 266 352 183 271 352 minecraft:blue_concrete
setblock 183 266 353 minecraft:cyan_concrete
fill 183 266 354 183 308 354 minecraft:blue_concrete
setblock 142 267 323 minecraft:dark_prismarine
fill 142 267 324 142 270 324 minecraft:blue_terracotta
setblock 142 267 327 minecraft:blue_terracotta
setblock 142 267 328 minecraft:dark_prismarine
fill 142 267 329 142 270 329 minecraft:blue_terracotta
setblock 142 267 333 minecraft:dark_prismarine
fill 142 267 334 142 270 334 minecraft:blue_terracotta
setblock 142 267 338 minecraft:dark_prismarine
setblock 142 267 339 minecraft:blue_terracotta
setblock 142 267 343 minecraft:dark_prismarine
fill 142 267 344 142 270 344 minecraft:blue_terracotta
setblock 142 267 348 minecraft:dark_prismarine
setblock 142 267 357 minecraft:blue_terracotta
setblock 142 267 358 minecraft:dark_prismarine
fill 142 267 359 142 270 359 minecraft:blue_terracotta
setblock 142 267 362 minecraft:blue_terracotta
setblock 142 267 363 minecraft:dark_prismarine
fill 143 267 323 146 267 323 minecraft:blue_terracotta
setblock 143 267 327 minecraft:dark_prismarine
fill 143 267 328 143 270 328 minecraft:blue_terracotta
setblock 143 267 332 minecraft:dark_prismarine
fill 143 267 333 143 268 333 minecraft:blue_terracotta
setblock 143 267 337 minecraft:dark_prismarine
setblock 143 267 338 minecraft:blue_terracotta
setblock 143 267 342 minecraft:dark_prismarine
fill 143 267 343 143 270 343 minecraft:blue_terracotta
setblock 143 267 346 minecraft:blue_terracotta
setblock 143 267 358 minecraft:blue_terracotta
setblock 143 267 361 minecraft:blue_terracotta
setblock 143 267 362 minecraft:dark_prismarine
fill 143 267 363 143 270 363 minecraft:blue_terracotta
setblock 144 267 325 minecraft:blue_terracotta
setblock 144 267 326 minecraft:dark_prismarine
fill 144 267 327 144 270 327 minecraft:blue_terracotta
fill 144 267 336 144 272 336 minecraft:dark_prismarine
setblock 144 267 337 minecraft:blue_terracotta
setblock 144 267 341 minecraft:dark_prismarine
fill 144 267 342 144 268 342 minecraft:blue_terracotta
setblock 144 267 361 minecraft:dark_prismarine
fill 144 267 362 144 270 362 minecraft:blue_terracotta
setblock 145 267 325 minecraft:dark_prismarine
fill 145 267 326 146 268 326 minecraft:blue_terracotta
setblock 145 267 342 minecraft:dark_prismarine
fill 145 267 361 145 270 361 minecraft:blue_terracotta
setblock 146 267 324 minecraft:dark_prismarine
fill 146 267 325 146 270 325 minecraft:blue_terracotta
setblock 147 267 323 minecraft:dark_prismarine
fill 147 267 324 147 270 324 minecraft:blue_terracotta
setblock 147 267 363 minecraft:dark_prismarine
fill 148 267 323 148 270 323 minecraft:blue_terracotta
setblock 148 267 362 minecraft:dark_prismarine
fill 148 267 363 148 270 363 minecraft:blue_terracotta
setblock 149 267 344 minecraft:dark_prismarine
setblock 149 267 361 minecraft:dark_prismarine
fill 149 267 362 149 270 362 minecraft:blue_terracotta
setblock 150 267 325 minecraft:dark_prismarine
fill 150 267 361 150 268 361 minecraft:blue_terracotta
setblock 151 267 324 minecraft:dark_prismarine
setblock 152 267 323 minecraft:dark_prismarine
fill 152 267 324 152 269 324 minecraft:blue_terracotta
setblock 152 267 363 minecraft:dark_prismarine
fill 153 267 323 153 270 323 minecraft:blue_terracotta
setblock 153 267 362 minecraft:dark_prismarine
fill 153 267 363 156 267 363 minecraft:blue_terracotta
setblock 154 267 361 minecraft:dark_prismarine
fill 154 267 362 157 267 362 minecraft:blue_terracotta
setblock 157 267 323 minecraft:dark_prismarine
setblock 157 267 363 minecraft:dark_prismarine
fill 158 267 323 161 267 323 minecraft:blue_terracotta
setblock 158 267 362 minecraft:dark_prismarine
fill 158 267 363 158 270 363 minecraft:blue_terracotta
setblock 159 267 361 minecraft:dark_prismarine
fill 159 267 362 159 270 362 minecraft:blue_terracotta
fill 160 267 361 160 268 361 minecraft:blue_terracotta
setblock 162 267 323 minecraft:dark_prismarine
fill 162 267 324 162 270 324 minecraft:blue_terracotta
setblock 162 267 363 minecraft:dark_prismarine
fill 163 267 323 163 270 323 minecraft:blue_terracotta
setblock 163 267 362 minecraft:dark_prismarine
fill 163 267 363 163 270 363 minecraft:blue_terracotta
fill 164 267 322 164 308 322 minecraft:blue_concrete
fill 164 267 324 165 267 324 minecraft:blue_terracotta
setblock 164 267 360 minecraft:blue_terracotta
setblock 164 267 361 minecraft:dark_prismarine
fill 164 267 362 164 270 362 minecraft:blue_terracotta
setblock 165 267 360 minecraft:dark_prismarine
fill 165 267 361 165 269 361 minecraft:blue_terracotta
setblock 166 267 324 minecraft:dark_prismarine
setblock 166 267 360 minecraft:blue_terracotta
setblock 167 267 323 minecraft:dark_prismarine
fill 167 267 324 167 270 324 minecraft:blue_terracotta
setblock 167 267 363 minecraft:dark_prismarine
fill 168 267 323 168 270 323 minecraft:blue_terracotta
setblock 168 267 362 minecraft:dark_prismarine
fill 168 267 363 168 270 363 minecraft:blue_terracotta
setblock 169 267 361 minecraft:dark_prismarine
fill 169 267 362 169 269 362 minecraft:blue_terracotta
setblock 170 267 361 minecraft:blue_terracotta
setblock 172 267 323 minecraft:dark_prismarine
setblock 172 267 363 minecraft:dark_prismarine
fill 173 267 323 173 268 323 minecraft:blue_terracotta
fill 173 267 363 173 268 363 minecraft:blue_terracotta
setblock 177 267 323 minecraft:dark_prismarine
fill 178 267 323 178 270 323 minecraft:blue_terracotta
setblock 178 267 363 minecraft:blue_terracotta
setblock 180 267 340 minecraft:dark_prismarine
fill 180 267 341 180 269 341 minecraft:blue_terracotta
setblock 180 267 344 minecraft:blue_terracotta
setblock 181 267 323 minecraft:blue_terracotta
setblock 181 267 324 minecraft:dark_prismarine
fill 181 267 325 182 268 326 minecraft:blue_terracotta
setblock 181 267 334 minecraft:dark_prismarine
fill 181 267 335 181 269 335 minecraft:blue_terracotta
setblock 181 267 339 minecraft:dark_prismarine
fill 181 267 340 181 270 340 minecraft:blue_terracotta
setblock 181 267 344 minecraft:dark_prismarine
fill 181 267 345 181 270 345 minecraft:blue_terracotta
fill 181 267 347 182 267 347 minecraft:blue_terracotta
setblock 182 267 323 minecraft:dark_prismarine
fill 182 267 324 182 270 324 minecraft:blue_terracotta
setblock 182 267 327 minecraft:blue_terracotta
setblock 182 267 328 minecraft:dark_prismarine
fill 182 267 329 182 270 329 minecraft:blue_terracotta
setblock 182 267 333 minecraft:dark_prismarine
fill 182 267 334 182 270 334 minecraft:blue_terracotta
setblock 182 267 338 minecraft:dark_prismarine
fill 182 267 339 182 270 339 minecraft:blue_terracotta
setblock 182 267 343 minecraft:dark_prismarine
fill 182 267 344 182 270 344 minecraft:blue_terracotta
setblock 182 267 348 minecraft:dark_prismarine
fill 182 267 349 182 269 350 minecraft:blue_terracotta
setblock 182 267 351 minecraft:purple_concrete
setblock 182 267 358 minecraft:dark_prismarine
fill 182 267 359 182 268 359 minecraft:blue_terracotta
setblock 182 267 363 minecraft:dark_prismarine
fill 183 267 324 183 308 324 minecraft:blue_concrete
setblock 183 267 325 minecraft:light_blue_wool
fill 183 267 353 183 308 353 minecraft:blue_concrete
fill 142 268 323 145 268 323 minecraft:blue_terracotta
setblock 142 268 327 minecraft:dark_prismarine
fill 142 268 328 142 271 328 minecraft:blue_terracotta
setblock 142 268 332 minecraft:dark_prismarine
fill 142 268 333 142 271 333 minecraft:blue_terracotta
setblock 142 268 335 minecraft:sea_lantern
setblock 142 268 337 minecraft:sea_lantern
fill 142 268 338 142 271 338 minecraft:blue_terracotta
setblock 142 268 339 minecraft:sea_lantern
fill 142 268 340 142 269 340 minecraft:blue_terracotta
setblock 142 268 341 minecraft:sea_lantern
setblock 142 268 342 minecraft:dark_prismarine
setblock 142 268 343 minecraft:sea_lantern
setblock 142 268 345 minecraft:sea_lantern
setblock 142 268 347 minecraft:dark_prismarine
fill 142 268 348 142 271 348 minecraft:blue_terracotta
setblock 142 268 357 minecraft:dark_prismarine
fill 142 268 358 142 270 358 minecraft:blue_terracotta
setblock 142 268 362 minecraft:dark_prismarine
fill 142 268 363 142 271 363 minecraft:blue_terracotta
setblock 143 268 326 minecraft:dark_prismarine
fill 143 268 327 143 271 327 minecraft:blue_terracotta
setblock 143 268 331 minecraft:dark_prismarine
fill 143 268 332 143 269 332 minecraft:blue_terracotta
setblock 143 268 336 minecraft:sea_lantern
fill 143 268 337 143 269 337 minecraft:blue_terracotta
setblock 143 268 338 minecraft:sea_lantern
fill 143 268 339 143 269 339 minecraft:blue_terracotta
setblock 143 268 340 minecraft:sea_lantern
setblock 143 268 341 minecraft:dark_prismarine
setblock 143 268 342 minecraft:sea_lantern
setblock 143 268 344 minecraft:sea_lantern
setblock 143 268 345 minecraft:blue_terracotta
setblock 143 268 346 minecraft:dark_prismarine
setblock 143 268 361 minecraft:dark_prismarine
fill 143 268 362 143 271 362 minecraft:blue_terracotta
setblock 144 268 325 minecraft:dark_prismarine
fill 144 268 326 144 271 326 minecraft:blue_terracotta
setblock 144 268 335 minecraft:sea_lantern
setblock 144 268 337 minecraft:sea_lantern
fill 144 268 338 144 272 338 minecraft:dark_prismarine
setblock 144 268 339 minecraft:sea_lantern
fill 144 268 340 144 272 340 minecraft:dark_prismarine
setblock 144 268 341 minecraft:sea_lantern
setblock 144 268 343 minecraft:sea_lantern
setblock 144 268 345 minecraft:sea_lantern
setblock 144 268 360 minecraft:dark_prismarine
fill 144 268 361 144 269 361 minecraft:blue_terracotta
setblock 145 268 324 minecraft:dark_prismarine
fill 145 268 325 145 271 325 minecraft:blue_terracotta
setblock 145 268 336 minecraft:sea_lantern
setblock 145 268 338 minecraft:sea_lantern
setblock 145 268 340 minecraft:sea_lantern
setblock 145 268 342 minecraft:sea_lantern
setblock 145 268 344 minecraft:sea_lantern
setblock 146 268 323 minecraft:dark_prismarine
fill 146 268 324 146 271 324 minecraft:blue_terracotta
setblock 146 268 335 minecraft:sea_lantern
setblock 146 268 337 minecraft:sea_lantern
setblock 146 268 339 minecraft:sea_lantern
setblock 146 268 341 minecraft:sea_lantern
setblock 146 268 343 minecraft:sea_lantern
setblock 146 268 345 minecraft:sea_lantern
setblock 146 268 363 minecraft:dark_prismarine
fill 147 268 323 147 271 323 minecraft:blue_terracotta
setblock 147 268 336 minecraft:sea_lantern
setblock 147 268 338 minecraft:sea_lantern
setblock 147 268 340 minecraft:sea_lantern
setblock 147 268 342 minecraft:sea_lantern
setblock 147 268 344 minecraft:sea_lantern
setblock 147 268 362 minecraft:dark_prismarine
fill 147 268 363 147 271 363 minecraft:blue_terracotta
setblock 148 268 335 minecraft:sea_lantern
setblock 148 268 337 minecraft:sea_lantern
setblock 148 268 339 minecraft:sea_lantern
setblock 148 268 341 minecraft:sea_lantern
setblock 148 268 343 minecraft:sea_lantern
setblock 148 268 345 minecraft:sea_lantern
setblock 148 268 361 minecraft:dark_prismarine
fill 148 268 362 148 271 362 minecraft:blue_terracotta
setblock 149 268 325 minecraft:dark_prismarine
setblock 149 268 336 minecraft:sea_lantern
setblock 149 268 338 minecraft:sea_lantern
setblock 149 268 340 minecraft:sea_lantern
setblock 149 268 342 minecraft:sea_lantern
fill 149 268 343 149 275 343 minecraft:magenta_terracotta
setblock 149 268 344 minecraft:sea_lantern
fill 149 268 361 149 269 361 minecraft:blue_terracotta
setblock 150 268 324 minecraft:dark_prismarine
setblock 150 268 325 minecraft:blue_terracotta
setblock 151 268 323 minecraft:dark_prismarine
fill 151 268 324 151 271 324 minecraft:blue_terracotta
setblock 151 268 363 minecraft:dark_prismarine
fill 152 268 323 152 271 323 minecraft:blue_terracotta
setblock 152 268 362 minecraft:dark_prismarine
fill 152 268 363 155 268 363 minecraft:blue_terracotta
fill 153 268 362 156 268 362 minecraft:blue_terracotta
setblock 154 268 364 minecraft:cyan_concrete
setblock 156 268 323 minecraft:dark_prismarine
setblock 156 268 363 minecraft:dark_prismarine
fill 157 268 323 160 268 323 minecraft:blue_terracotta
setblock 157 268 362 minecraft:dark_prismarine
fill 157 268 363 157 271 363 minecraft:blue_terracotta
fill 158 268 362 158 270 362 minecraft:blue_terracotta
setblock 161 268 323 minecraft:dark_prismarine
setblock 161 268 363 minecraft:dark_prismarine
fill 162 268 323 162 271 323 minecraft:blue_terracotta
setblock 162 268 362 minecraft:dark_prismarine
fill 162 268 363 162 271 363 minecraft:blue_terracotta
setblock 163 268 361 minecraft:dark_prismarine
fill 163 268 362 163 271 362 minecraft:blue_terracotta
setblock 164 268 324 minecraft:blue_terracotta
fill 164 268 361 164 269 361 minecraft:blue_terracotta
setblock 165 268 324 minecraft:dark_prismarine
setblock 166 268 323 minecraft:dark_prismarine
fill 166 268 324 166 271 324 minecraft:blue_terracotta
setblock 166 268 363 minecraft:dark_prismarine
fill 167 268 323 167 271 323 minecraft:blue_terracotta
setblock 167 268 362 minecraft:dark_prismarine
fill 167 268 363 167 271 363 minecraft:blue_terracotta
setblock 168 268 361 minecraft:dark_prismarine
fill 168 268 362 168 270 362 minecraft:blue_terracotta
fill 170 268 328 170 277 328 minecraft:magenta_terracotta
setblock 171 268 323 minecraft:dark_prismarine
setblock 171 268 363 minecraft:dark_prismarine
fill 172 268 323 172 269 323 minecraft:blue_terracotta
fill 172 268 363 172 269 363 minecraft:blue_terracotta
fill 177 268 323 177 271 323 minecraft:blue_terracotta
setblock 180 268 324 minecraft:dark_prismarine
setblock 180 268 339 minecraft:dark_prismarine
fill 180 268 340 180 269 340 minecraft:blue_terracotta
setblock 180 268 344 minecraft:dark_prismarine
setblock 181 268 323 minecraft:dark_prismarine
fill 181 268 324 181 271 324 minecraft:blue_terracotta
setblock 181 268 327 minecraft:blue_terracotta
setblock 181 268 334 minecraft:blue_terracotta
setblock 181 268 338 minecraft:dark_prismarine
fill 181 268 339 181 271 339 minecraft:blue_terracotta
setblock 181 268 343 minecraft:dark_prismarine
fill 181 268 344 181 271 344 minecraft:blue_terracotta
setblock 181 268 347 minecraft:blue_terracotta
setblock 181 268 363 minecraft:dark_prismarine
fill 182 268 323 182 271 323 minecraft:blue_terracotta
setblock 182 268 327 minecraft:dark_prismarine
fill 182 268 328 182 271 328 minecraft:blue_terracotta
setblock 182 268 332 minecraft:dark_prismarine
fill 182 268 333 182 271 333 minecraft:blue_terracotta
setblock 182 268 337 minecraft:dark_prismarine
fill 182 268 338 182 271 338 minecraft:blue_terracotta
setblock 182 268 342 minecraft:dark_prismarine
fill 182 268 343 182 271 343 minecraft:blue_terracotta
setblock 182 268 347 minecraft:dark_prismarine
fill 182 268 348 182 271 348 minecraft:blue_terracotta
setblock 182 268 362 minecraft:dark_prismarine
fill 182 268 363 182 271 363 minecraft:blue_terracotta
fill 183 268 325 183 275 325 minecraft:blue_concrete
fill 142 269 323 144 269 323 minecraft:blue_terracotta
setblock 142 269 326 minecraft:dark_prismarine
fill 142 269 327 142 272 327 minecraft:blue_terracotta
setblock 142 269 331 minecraft:dark_prismarine
fill 142 269 332 142 272 332 minecraft:blue_terracotta
setblock 142 269 335 minecraft:blue_terracotta
fill 142 269 336 143 269 336 minecraft:dark_prismarine
fill 142 269 337 142 270 337 minecraft:blue_terracotta
fill 142 269 339 142 270 339 minecraft:blue_terracotta
setblock 142 269 341 minecraft:dark_prismarine
fill 142 269 342 142 270 343 minecraft:blue_terracotta
setblock 142 269 345 minecraft:blue_terracotta
setblock 142 269 346 minecraft:dark_prismarine
fill 142 269 347 142 272 347 minecraft:blue_terracotta
fill 142 269 349 142 270 349 minecraft:blue_terracotta
setblock 142 269 360 minecraft:blue_terracotta
setblock 142 269 361 minecraft:dark_prismarine
fill 142 269 362 142 272 362 minecraft:blue_terracotta
setblock 143 269 325 minecraft:dark_prismarine
fill 143 269 326 143 272 326 minecraft:blue_terracotta
setblock 143 269 330 minecraft:dark_prismarine
fill 143 269 331 143 272 331 minecraft:blue_terracotta
fill 143 269 335 144 270 335 minecraft:dark_prismarine
setblock 143 269 338 minecraft:blue_terracotta
setblock 143 269 340 minecraft:dark_prismarine
fill 143 269 341 143 270 342 minecraft:blue_terracotta
setblock 143 269 344 minecraft:blue_terracotta
fill 143 269 345 144 269 345 minecraft:dark_prismarine
fill 143 269 346 143 272 346 minecraft:blue_terracotta
setblock 143 269 360 minecraft:dark_prismarine
fill 143 269 361 143 272 361 minecraft:blue_terracotta
setblock 144 269 324 minecraft:dark_prismarine
fill 144 269 325 144 272 325 minecraft:blue_terracotta
setblock 144 269 332 minecraft:light[level=12]
setblock 144 269 333 minecraft:light[level=13]
fill 144 269 337 144 270 337 minecraft:dark_prismarine
fill 144 269 339 144 270 339 minecraft:dark_prismarine
fill 144 269 341 144 270 343 minecraft:dark_prismarine
setblock 144 269 346 minecraft:light[level=12]
setblock 144 269 349 minecraft:light[level=13]
setblock 144 269 353 minecraft:light[level=12]
setblock 144 269 357 minecraft:light[level=13]
setblock 144 269 360 minecraft:light[level=12]
setblock 145 269 323 minecraft:dark_prismarine
fill 145 269 324 145 272 324 minecraft:blue_terracotta
setblock 145 269 326 minecraft:blue_terracotta
fill 145 269 336 145 270 336 minecraft:dark_prismarine
fill 145 269 338 145 270 338 minecraft:dark_prismarine
fill 145 269 340 145 270 340 minecraft:dark_prismarine
fill 145 269 342 145 270 342 minecraft:dark_prismarine
fill 145 269 344 145 270 344 minecraft:dark_prismarine
setblock 145 269 363 minecraft:dark_prismarine
fill 146 269 323 146 272 323 minecraft:blue_terracotta
fill 146 269 335 146 270 335 minecraft:dark_prismarine
fill 146 269 337 146 270 337 minecraft:dark_prismarine
fill 146 269 339 146 270 339 minecraft:dark_prismarine
fill 146 269 341 146 270 341 minecraft:dark_prismarine
fill 146 269 343 146 270 343 minecraft:dark_prismarine
fill 146 269 345 146 270 345 minecraft:dark_prismarine
setblock 146 269 362 minecraft:dark_prismarine
fill 146 269 363 146 272 363 minecraft:blue_terracotta
fill 147 269 336 147 270 336 minecraft:dark_prismarine
fill 147 269 338 147 270 338 minecraft:dark_prismarine
fill 147 269 340 147 270 340 minecraft:dark_prismarine
fill 147 269 342 147 270 342 minecraft:dark_prismarine
fill 147 269 344 147 270 344 minecraft:dark_prismarine
setblock 147 269 361 minecraft:dark_prismarine
fill 147 269 362 147 272 362 minecraft:blue_terracotta
setblock 148 269 325 minecraft:dark_prismarine
fill 148 269 335 148 270 335 minecraft:dark_prismarine
fill 148 269 337 148 270 337 minecraft:dark_prismarine
fill 148 269 339 148 270 339 minecraft:dark_prismarine
fill 148 269 341 148 270 341 minecraft:dark_prismarine
fill 148 269 343 148 270 343 minecraft:magenta_terracotta
fill 148 269 345 148 270 345 minecraft:dark_prismarine
setblock 148 269 361 minecraft:blue_terracotta
setblock 149 269 324 minecraft:dark_prismarine
setblock 149 269 325 minecraft:blue_terracotta
fill 149 269 336 149 270 336 minecraft:dark_prismarine
fill 149 269 338 149 270 338 minecraft:dark_prismarine
fill 149 269 340 149 270 340 minecraft:dark_prismarine
fill 149 269 342 149 270 342 minecraft:dark_prismarine
fill 149 269 344 149 270 344 minecraft:dark_prismarine
setblock 150 269 323 minecraft:dark_prismarine
fill 150 269 324 150 272 324 minecraft:blue_terracotta
setblock 150 269 363 minecraft:dark_prismarine
fill 151 269 323 151 272 323 minecraft:blue_terracotta
setblock 151 269 325 minecraft:light[level=12]
setblock 151 269 332 minecraft:light[level=12]
setblock 151 269 339 minecraft:light[level=12]
setblock 151 269 346 minecraft:light[level=12]
setblock 151 269 353 minecraft:light[level=12]
setblock 151 269 360 minecraft:light[level=12]
setblock 151 269 362 minecraft:dark_prismarine
fill 151 269 363 154 269 363 minecraft:blue_terracotta
setblock 152 269 325 minecraft:light[level=13]
setblock 152 269 333 minecraft:light[level=13]
setblock 152 269 341 minecraft:light[level=13]
setblock 152 269 349 minecraft:light[level=13]
setblock 152 269 357 minecraft:light[level=13]
fill 152 269 362 155 269 362 minecraft:blue_terracotta
fill 154 269 364 154 308 364 minecraft:blue_concrete
setblock 155 269 323 minecraft:dark_prismarine
setblock 155 269 363 minecraft:dark_prismarine
fill 156 269 323 159 269 323 minecraft:blue_terracotta
setblock 156 269 362 minecraft:dark_prismarine
fill 156 269 363 156 272 363 minecraft:blue_terracotta
fill 157 269 362 157 270 362 minecraft:blue_terracotta
setblock 158 269 325 minecraft:light[level=12]
setblock 158 269 332 minecraft:light[level=12]
setblock 158 269 339 minecraft:light[level=12]
setblock 158 269 346 minecraft:light[level=12]
setblock 158 269 353 minecraft:light[level=12]
setblock 158 269 360 minecraft:light[level=12]
setblock 160 269 323 minecraft:dark_prismarine
setblock 160 269 325 minecraft:light[level=13]
setblock 160 269 333 minecraft:light[level=13]
setblock 160 269 341 minecraft:light[level=13]
setblock 160 269 349 minecraft:light[level=13]
setblock 160 269 357 minecraft:light[level=13]
setblock 160 269 363 minecraft:dark_prismarine
fill 161 269 323 161 271 324 minecraft:blue_terracotta
setblock 161 269 362 minecraft:dark_prismarine
fill 161 269 363 161 272 363 minecraft:blue_terracotta
setblock 162 269 361 minecraft:dark_prismarine
fill 162 269 362 162 272 362 minecraft:blue_terracotta
setblock 163 269 361 minecraft:blue_terracotta
setblock 164 269 324 minecraft:dark_prismarine
setblock 165 269 323 minecraft:dark_prismarine
fill 165 269 324 165 272 324 minecraft:blue_terracotta
setblock 165 269 325 minecraft:light[level=12]
setblock 165 269 332 minecraft:light[level=12]
setblock 165 269 339 minecraft:light[level=12]
setblock 165 269 346 minecraft:light[level=12]
setblock 165 269 353 minecraft:light[level=12]
setblock 165 269 360 minecraft:light[level=12]
setblock 165 269 363 minecraft:dark_prismarine
fill 166 269 323 166 272 323 minecraft:blue_terracotta
setblock 166 269 362 minecraft:dark_prismarine
fill 166 269 363 166 272 363 minecraft:blue_terracotta
fill 167 269 362 167 270 362 minecraft:blue_terracotta
setblock 168 269 325 minecraft:light[level=13]
setblock 168 269 333 minecraft:light[level=13]
setblock 168 269 341 minecraft:light[level=13]
setblock 168 269 349 minecraft:light[level=13]
setblock 168 269 357 minecraft:light[level=13]
setblock 170 269 323 minecraft:dark_prismarine
setblock 170 269 363 minecraft:dark_prismarine
fill 171 269 323 171 270 323 minecraft:blue_terracotta
setblock 171 269 363 minecraft:blue_terracotta
setblock 172 269 325 minecraft:light[level=12]
setblock 172 269 339 minecraft:light[level=12]
setblock 172 269 346 minecraft:light[level=12]
setblock 172 269 353 minecraft:light[level=12]
setblock 172 269 360 minecraft:light[level=12]
schedule function dropper:buildpart/75_13 1t
