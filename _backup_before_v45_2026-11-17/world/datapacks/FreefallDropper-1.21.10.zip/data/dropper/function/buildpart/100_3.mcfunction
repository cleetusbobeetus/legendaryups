fill 222 292 416 222 307 416 minecraft:stone
fill 224 292 458 224 307 458 minecraft:stone
fill 225 292 458 226 292 458 minecraft:shroomlight
fill 227 292 458 227 307 458 minecraft:stone
fill 230 292 417 230 307 417 minecraft:stone
fill 230 292 418 230 292 419 minecraft:shroomlight
fill 230 292 420 230 307 420 minecraft:stone
fill 230 292 429 230 307 429 minecraft:stone
fill 230 292 430 230 292 431 minecraft:shroomlight
fill 230 292 432 230 307 432 minecraft:stone
fill 230 292 441 230 307 441 minecraft:stone
fill 230 292 442 230 292 443 minecraft:shroomlight
fill 230 292 444 230 307 444 minecraft:stone
fill 230 292 453 230 307 453 minecraft:stone
fill 230 292 454 230 292 455 minecraft:shroomlight
fill 230 292 456 230 307 456 minecraft:stone
fill 188 293 423 188 307 424 minecraft:stone
fill 188 293 435 188 307 436 minecraft:stone
fill 188 293 447 188 307 448 minecraft:stone
fill 189 293 458 190 307 458 minecraft:stone
fill 196 293 416 197 307 416 minecraft:stone
fill 201 293 458 202 307 458 minecraft:stone
fill 208 293 416 209 307 416 minecraft:stone
fill 213 293 458 214 307 458 minecraft:stone
fill 220 293 416 221 307 416 minecraft:stone
fill 225 293 458 226 307 458 minecraft:stone
fill 230 293 418 230 307 419 minecraft:stone
fill 230 293 430 230 307 431 minecraft:stone
fill 230 293 442 230 307 443 minecraft:stone
fill 230 293 454 230 307 455 minecraft:stone
setblock 191 294 419 minecraft:light[level=13]
setblock 191 294 427 minecraft:light[level=13]
setblock 191 294 435 minecraft:light[level=13]
setblock 191 294 443 minecraft:light[level=13]
setblock 191 294 451 minecraft:light[level=13]
setblock 199 294 419 minecraft:light[level=13]
setblock 199 294 427 minecraft:light[level=13]
setblock 199 294 435 minecraft:light[level=13]
setblock 199 294 443 minecraft:light[level=13]
setblock 199 294 451 minecraft:light[level=13]
setblock 207 294 419 minecraft:light[level=13]
setblock 207 294 427 minecraft:light[level=13]
setblock 207 294 435 minecraft:light[level=13]
setblock 207 294 443 minecraft:light[level=13]
setblock 207 294 451 minecraft:light[level=13]
setblock 215 294 419 minecraft:light[level=13]
setblock 215 294 427 minecraft:light[level=13]
setblock 215 294 435 minecraft:light[level=13]
setblock 215 294 443 minecraft:light[level=13]
setblock 215 294 451 minecraft:light[level=13]
setblock 223 294 419 minecraft:light[level=13]
setblock 223 294 427 minecraft:light[level=13]
setblock 223 294 435 minecraft:light[level=13]
setblock 223 294 443 minecraft:light[level=13]
setblock 223 294 451 minecraft:light[level=13]
fill 190 297 445 191 297 445 minecraft:gold_block
fill 191 297 443 192 297 444 minecraft:gold_block
fill 191 297 446 192 297 447 minecraft:gold_block
fill 192 297 442 196 297 442 minecraft:gold_block
fill 192 297 448 196 297 448 minecraft:gold_block
fill 193 297 443 193 299 443 minecraft:gold_block
fill 193 297 447 193 299 447 minecraft:gold_block
setblock 194 297 441 minecraft:gold_block
setblock 194 297 449 minecraft:gold_block
fill 195 297 443 197 297 443 minecraft:gold_block
fill 195 297 447 197 297 447 minecraft:gold_block
fill 196 297 444 197 298 444 minecraft:gold_block
fill 196 297 446 197 298 446 minecraft:gold_block
fill 197 297 445 198 297 445 minecraft:gold_block
fill 191 298 444 191 298 446 minecraft:gold_block
fill 192 298 443 192 298 444 minecraft:gold_block
fill 192 298 446 192 298 447 minecraft:gold_block
fill 193 298 442 195 298 442 minecraft:gold_block
fill 193 298 448 195 298 448 minecraft:gold_block
fill 195 298 443 196 298 443 minecraft:gold_block
fill 195 298 447 196 298 447 minecraft:gold_block
setblock 197 298 445 minecraft:gold_block
setblock 192 299 444 minecraft:gold_block
setblock 192 299 446 minecraft:gold_block
setblock 195 299 443 minecraft:gold_block
setblock 195 299 447 minecraft:gold_block
setblock 196 299 444 minecraft:gold_block
setblock 196 299 446 minecraft:gold_block
fill 190 300 426 190 300 428 minecraft:polished_deepslate
fill 190 300 438 190 300 440 minecraft:polished_deepslate
fill 190 300 450 190 300 452 minecraft:polished_deepslate
fill 196 300 456 198 300 456 minecraft:polished_deepslate
fill 200 300 418 202 300 418 minecraft:polished_deepslate
fill 208 300 456 210 300 456 minecraft:polished_deepslate
fill 212 300 418 214 300 418 minecraft:polished_deepslate
fill 220 300 456 222 300 456 minecraft:polished_deepslate
fill 224 300 418 226 300 418 minecraft:polished_deepslate
fill 228 300 426 228 300 428 minecraft:polished_deepslate
fill 228 300 438 228 300 440 minecraft:polished_deepslate
fill 228 300 450 228 300 452 minecraft:polished_deepslate
setblock 191 302 419 minecraft:light[level=13]
setblock 191 302 427 minecraft:light[level=13]
setblock 191 302 435 minecraft:light[level=13]
setblock 191 302 443 minecraft:light[level=13]
setblock 191 302 451 minecraft:light[level=13]
setblock 199 302 419 minecraft:light[level=13]
setblock 199 302 427 minecraft:light[level=13]
setblock 199 302 435 minecraft:light[level=13]
setblock 199 302 443 minecraft:light[level=13]
setblock 199 302 451 minecraft:light[level=13]
setblock 207 302 419 minecraft:light[level=13]
setblock 207 302 427 minecraft:light[level=13]
setblock 207 302 435 minecraft:light[level=13]
setblock 207 302 443 minecraft:light[level=13]
setblock 207 302 451 minecraft:light[level=13]
setblock 215 302 419 minecraft:light[level=13]
setblock 215 302 427 minecraft:light[level=13]
setblock 215 302 435 minecraft:light[level=13]
setblock 215 302 443 minecraft:light[level=13]
setblock 215 302 451 minecraft:light[level=13]
setblock 223 302 419 minecraft:light[level=13]
setblock 223 302 427 minecraft:light[level=13]
setblock 223 302 435 minecraft:light[level=13]
setblock 223 302 443 minecraft:light[level=13]
setblock 223 302 451 minecraft:light[level=13]
