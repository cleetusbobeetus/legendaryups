setblock 528 173 584 minecraft:black_concrete
setblock 528 173 590 minecraft:black_concrete
fill 530 173 583 533 173 583 minecraft:black_concrete
fill 530 173 591 532 173 591 minecraft:black_concrete
setblock 534 173 584 minecraft:black_concrete
setblock 534 173 590 minecraft:black_concrete
fill 535 173 585 535 173 586 minecraft:black_concrete
fill 535 173 588 535 173 589 minecraft:black_concrete
setblock 536 173 557 minecraft:white_concrete
setblock 541 173 557 minecraft:white_stained_glass
fill 542 173 599 542 174 599 minecraft:black_concrete
fill 547 173 557 547 181 557 minecraft:black_concrete
setblock 559 173 559 minecraft:white_concrete
setblock 559 173 571 minecraft:white_stained_glass
fill 517 174 565 517 179 565 minecraft:black_concrete
fill 517 174 581 517 179 582 minecraft:black_concrete
fill 517 174 597 517 178 597 minecraft:black_concrete
fill 521 174 557 521 179 557 minecraft:black_concrete
fill 530 174 588 530 178 588 minecraft:obsidian
fill 531 174 586 531 178 586 minecraft:obsidian
fill 531 174 599 531 179 599 minecraft:black_concrete
fill 533 174 587 533 177 587 minecraft:obsidian
fill 536 174 557 537 177 557 minecraft:black_concrete
setblock 541 174 557 minecraft:black_concrete
fill 547 174 599 547 179 599 minecraft:black_concrete
fill 549 174 573 549 182 573 minecraft:black_concrete
setblock 552 174 557 minecraft:white_stained_glass
fill 553 174 557 553 179 557 minecraft:black_concrete
setblock 559 174 559 minecraft:white_stained_glass
fill 559 174 567 559 177 567 minecraft:black_concrete
fill 559 174 571 559 182 571 minecraft:black_concrete
fill 559 174 583 559 177 583 minecraft:black_concrete
setblock 517 175 574 minecraft:white_concrete
fill 517 175 575 517 181 576 minecraft:black_concrete
fill 532 175 561 534 180 563 minecraft:orange_concrete
setblock 541 175 557 minecraft:white_stained_glass
setblock 542 175 599 minecraft:white_stained_glass
fill 548 175 573 548 182 573 minecraft:black_concrete
fill 552 175 557 552 181 557 minecraft:black_concrete
fill 559 175 559 559 182 559 minecraft:black_concrete
setblock 559 175 563 minecraft:sea_lantern
fill 559 175 564 559 181 564 minecraft:black_concrete
setblock 559 175 565 minecraft:sea_lantern
setblock 517 176 560 minecraft:white_concrete
fill 517 176 574 517 178 574 minecraft:black_concrete
setblock 524 176 599 minecraft:white_stained_glass
fill 525 176 599 526 179 599 minecraft:black_concrete
fill 531 176 561 531 179 563 minecraft:orange_concrete
fill 532 176 560 534 179 560 minecraft:orange_concrete
fill 532 176 564 534 179 564 minecraft:orange_concrete
fill 535 176 561 535 179 563 minecraft:orange_concrete
fill 541 176 557 541 181 557 minecraft:black_concrete
fill 542 176 599 542 181 599 minecraft:black_concrete
fill 548 176 572 549 182 572 minecraft:black_concrete
fill 549 176 574 549 182 574 minecraft:black_concrete
fill 550 176 573 550 182 573 minecraft:black_concrete
fill 559 176 563 559 181 563 minecraft:black_concrete
fill 559 176 565 559 182 565 minecraft:black_concrete
setblock 559 176 594 minecraft:sea_lantern
fill 517 177 560 517 181 560 minecraft:black_concrete
setblock 517 177 570 minecraft:white_concrete
setblock 524 177 599 minecraft:black_concrete
setblock 527 177 557 minecraft:sea_lantern
fill 530 177 562 530 178 562 minecraft:orange_concrete
fill 531 177 560 531 178 560 minecraft:orange_concrete
fill 531 177 564 531 178 564 minecraft:orange_concrete
fill 533 177 559 533 178 559 minecraft:orange_concrete
fill 533 177 565 533 178 565 minecraft:orange_concrete
fill 535 177 560 535 178 560 minecraft:orange_concrete
fill 535 177 564 535 178 564 minecraft:orange_concrete
fill 536 177 562 536 178 562 minecraft:orange_concrete
fill 548 177 574 548 182 574 minecraft:black_concrete
fill 550 177 572 550 182 572 minecraft:black_concrete
fill 550 177 574 550 182 574 minecraft:black_concrete
fill 559 177 594 559 181 594 minecraft:black_concrete
setblock 517 178 562 minecraft:blue_concrete
fill 517 178 570 517 181 570 minecraft:black_concrete
setblock 517 178 571 minecraft:blue_concrete
setblock 517 178 578 minecraft:blue_concrete
setblock 517 178 584 minecraft:blue_concrete
setblock 517 178 590 minecraft:sea_lantern
setblock 517 178 596 minecraft:white_stained_glass
setblock 520 178 560 minecraft:light[level=14]
setblock 520 178 568 minecraft:light[level=14]
setblock 520 178 576 minecraft:light[level=14]
setblock 520 178 584 minecraft:light[level=14]
setblock 520 178 592 minecraft:light[level=14]
setblock 524 178 599 minecraft:sea_lantern
fill 527 178 557 528 181 557 minecraft:black_concrete
setblock 527 178 599 minecraft:blue_concrete
setblock 528 178 560 minecraft:light[level=14]
setblock 528 178 568 minecraft:light[level=14]
setblock 528 178 576 minecraft:light[level=14]
setblock 528 178 584 minecraft:light[level=14]
setblock 528 178 592 minecraft:light[level=14]
fill 529 178 557 530 178 557 minecraft:blue_concrete
setblock 536 178 557 minecraft:black_concrete
setblock 536 178 560 minecraft:light[level=14]
setblock 536 178 568 minecraft:light[level=14]
setblock 536 178 576 minecraft:light[level=14]
setblock 536 178 584 minecraft:light[level=14]
setblock 536 178 592 minecraft:light[level=14]
setblock 537 178 557 minecraft:white_concrete
setblock 537 178 599 minecraft:blue_concrete
setblock 544 178 560 minecraft:light[level=14]
setblock 544 178 568 minecraft:light[level=14]
setblock 544 178 576 minecraft:light[level=14]
setblock 544 178 584 minecraft:light[level=14]
setblock 544 178 592 minecraft:light[level=14]
setblock 545 178 599 minecraft:blue_concrete
fill 547 178 572 547 182 574 minecraft:black_concrete
fill 548 178 571 550 182 571 minecraft:black_concrete
fill 549 178 575 549 182 575 minecraft:black_concrete
setblock 549 178 599 minecraft:blue_concrete
fill 551 178 573 551 182 573 minecraft:black_concrete
setblock 552 178 560 minecraft:light[level=14]
setblock 552 178 568 minecraft:light[level=14]
setblock 552 178 576 minecraft:light[level=14]
setblock 552 178 584 minecraft:light[level=14]
setblock 552 178 592 minecraft:light[level=14]
setblock 556 178 557 minecraft:white_concrete
setblock 556 178 599 minecraft:blue_concrete
setblock 558 178 599 minecraft:blue_concrete
setblock 559 178 560 minecraft:sea_lantern
fill 559 178 561 559 178 562 minecraft:blue_concrete
setblock 559 178 567 minecraft:blue_concrete
setblock 559 178 575 minecraft:blue_concrete
setblock 559 178 577 minecraft:blue_concrete
setblock 559 178 583 minecraft:blue_concrete
setblock 559 178 586 minecraft:white_stained_glass
fill 559 178 590 559 179 591 minecraft:black_concrete
fill 559 178 592 559 178 593 minecraft:blue_concrete
setblock 559 178 596 minecraft:sea_lantern
setblock 517 179 558 minecraft:blue_concrete
setblock 517 179 561 minecraft:blue_concrete
fill 517 179 562 517 181 562 minecraft:black_concrete
fill 517 179 571 517 181 571 minecraft:black_concrete
setblock 517 179 574 minecraft:blue_concrete
fill 517 179 578 517 181 578 minecraft:black_concrete
fill 517 179 584 517 181 584 minecraft:black_concrete
fill 517 179 586 517 181 588 minecraft:black_concrete
setblock 517 179 589 minecraft:blue_concrete
fill 517 179 590 517 181 590 minecraft:black_concrete
fill 517 179 596 517 181 596 minecraft:black_concrete
fill 517 179 597 517 179 598 minecraft:blue_concrete
fill 517 179 599 517 181 599 minecraft:black_concrete
setblock 519 179 599 minecraft:blue_concrete
setblock 522 179 557 minecraft:white_stained_glass
setblock 522 179 599 minecraft:blue_concrete
fill 524 179 599 524 181 599 minecraft:black_concrete
setblock 526 179 557 minecraft:blue_concrete
fill 527 179 599 527 183 599 minecraft:black_concrete
fill 529 179 557 529 181 557 minecraft:black_concrete
setblock 529 179 599 minecraft:blue_concrete
setblock 530 179 557 minecraft:blue_concrete
setblock 533 179 599 minecraft:white_concrete
setblock 536 179 557 minecraft:blue_concrete
setblock 537 179 557 minecraft:black_concrete
fill 537 179 599 537 182 599 minecraft:black_concrete
setblock 538 179 557 minecraft:blue_concrete
fill 539 179 557 539 181 557 minecraft:black_concrete
setblock 544 179 557 minecraft:blue_concrete
fill 545 179 599 545 181 599 minecraft:black_concrete
fill 547 179 571 547 182 571 minecraft:black_concrete
fill 548 179 575 548 182 575 minecraft:black_concrete
fill 549 179 599 549 181 599 minecraft:black_concrete
fill 550 179 575 550 182 575 minecraft:black_concrete
setblock 550 179 599 minecraft:blue_concrete
fill 551 179 572 551 182 572 minecraft:black_concrete
fill 551 179 574 551 182 574 minecraft:black_concrete
setblock 555 179 599 minecraft:blue_concrete
fill 556 179 557 556 181 557 minecraft:black_concrete
fill 556 179 599 556 181 599 minecraft:black_concrete
setblock 558 179 557 minecraft:blue_concrete
fill 558 179 599 558 181 599 minecraft:black_concrete
setblock 559 179 558 minecraft:blue_concrete
fill 559 179 560 559 179 562 minecraft:black_concrete
setblock 559 179 567 minecraft:black_concrete
setblock 559 179 568 minecraft:blue_concrete
setblock 559 179 574 minecraft:blue_concrete
fill 559 179 575 559 180 575 minecraft:black_concrete
fill 559 179 577 559 181 577 minecraft:black_concrete
setblock 559 179 581 minecraft:blue_concrete
fill 559 179 582 559 181 582 minecraft:black_concrete
setblock 559 179 583 minecraft:sea_lantern
fill 559 179 586 559 181 586 minecraft:black_concrete
setblock 559 179 592 minecraft:blue_concrete
fill 559 179 593 559 181 593 minecraft:black_concrete
fill 559 179 596 559 181 596 minecraft:black_concrete
fill 517 180 558 517 181 558 minecraft:black_concrete
fill 517 180 561 517 181 561 minecraft:black_concrete
fill 517 180 565 517 182 565 minecraft:white_concrete
fill 517 180 574 517 181 574 minecraft:black_concrete
fill 517 180 581 517 182 581 minecraft:white_concrete
fill 517 180 582 517 182 582 minecraft:black_concrete
setblock 517 180 585 minecraft:white_stained_glass
fill 517 180 589 517 181 589 minecraft:black_concrete
fill 517 180 597 517 182 597 minecraft:white_concrete
fill 517 180 598 517 181 598 minecraft:black_concrete
fill 519 180 599 519 182 599 minecraft:black_concrete
fill 521 180 557 521 182 557 minecraft:white_concrete
setblock 521 180 599 minecraft:white_concrete
setblock 522 180 557 minecraft:blue_concrete
fill 522 180 599 522 181 599 minecraft:black_concrete
setblock 525 180 599 minecraft:sea_lantern
fill 526 180 557 526 181 557 minecraft:black_concrete
fill 526 180 599 526 181 599 minecraft:black_concrete
fill 529 180 599 529 181 599 minecraft:black_concrete
fill 530 180 557 530 181 557 minecraft:black_concrete
fill 531 180 599 531 182 599 minecraft:white_concrete
fill 533 180 599 533 181 599 minecraft:black_concrete
fill 536 180 557 536 182 557 minecraft:black_concrete
fill 537 180 557 537 182 557 minecraft:white_concrete
fill 538 180 557 538 181 557 minecraft:black_concrete
setblock 543 180 599 minecraft:blue_concrete
fill 544 180 557 544 181 557 minecraft:black_concrete
fill 546 180 572 546 182 574 minecraft:black_concrete
fill 547 180 575 547 182 575 minecraft:black_concrete
fill 547 180 599 547 182 599 minecraft:white_concrete
fill 548 180 557 548 181 557 minecraft:black_concrete
fill 548 180 570 550 182 570 minecraft:black_concrete
setblock 549 180 557 minecraft:blue_concrete
fill 549 180 576 549 182 576 minecraft:black_concrete
fill 550 180 599 550 181 599 minecraft:black_concrete
fill 551 180 571 551 182 571 minecraft:black_concrete
fill 551 180 575 551 182 575 minecraft:black_concrete
fill 553 180 557 553 182 557 minecraft:white_concrete
setblock 555 180 557 minecraft:blue_concrete
fill 555 180 599 555 181 599 minecraft:black_concrete
fill 558 180 557 558 181 557 minecraft:black_concrete
fill 559 180 558 559 181 558 minecraft:black_concrete
fill 559 180 560 559 181 561 minecraft:black_concrete
setblock 559 180 562 minecraft:blue_concrete
fill 559 180 567 559 182 567 minecraft:white_concrete
fill 559 180 568 559 183 568 minecraft:black_concrete
setblock 559 180 569 minecraft:blue_concrete
fill 559 180 574 559 181 574 minecraft:black_concrete
fill 559 180 581 559 181 581 minecraft:black_concrete
fill 559 180 583 559 182 583 minecraft:white_concrete
fill 559 180 590 559 181 590 minecraft:black_concrete
setblock 559 180 591 minecraft:blue_concrete
fill 559 180 592 559 181 592 minecraft:black_concrete
setblock 517 181 585 minecraft:black_concrete
setblock 518 181 599 minecraft:white_stained_glass
setblock 520 181 557 minecraft:white_stained_glass
setblock 521 181 599 minecraft:black_concrete
setblock 522 181 557 minecraft:black_concrete
setblock 525 181 599 minecraft:black_concrete
setblock 543 181 599 minecraft:black_concrete
fill 546 181 571 546 182 571 minecraft:black_concrete
fill 546 181 575 546 182 575 minecraft:black_concrete
fill 547 181 570 547 182 570 minecraft:black_concrete
fill 547 181 576 548 182 576 minecraft:black_concrete
setblock 549 181 557 minecraft:black_concrete
fill 550 181 576 550 182 576 minecraft:black_concrete
fill 551 181 570 551 182 570 minecraft:black_concrete
fill 552 181 572 552 182 574 minecraft:black_concrete
setblock 555 181 557 minecraft:black_concrete
setblock 559 181 562 minecraft:black_concrete
setblock 559 181 569 minecraft:black_concrete
setblock 559 181 570 minecraft:white_concrete
setblock 559 181 575 minecraft:white_stained_glass
setblock 559 181 591 minecraft:black_concrete
fill 517 182 557 517 182 564 minecraft:blue_concrete
fill 517 182 566 517 201 566 minecraft:blue_concrete
fill 517 182 568 517 182 578 minecraft:blue_concrete
fill 517 182 580 517 234 580 minecraft:blue_concrete
fill 517 182 583 517 182 585 minecraft:blue_concrete
setblock 517 182 586 minecraft:black_concrete
fill 517 182 587 517 182 596 minecraft:blue_concrete
fill 517 182 598 517 185 599 minecraft:blue_concrete
fill 518 182 557 520 200 557 minecraft:blue_concrete
fill 518 182 599 518 214 599 minecraft:blue_concrete
fill 520 182 599 526 182 599 minecraft:blue_concrete
fill 522 182 557 530 182 557 minecraft:blue_concrete
fill 528 182 599 530 182 599 minecraft:blue_concrete
fill 532 182 557 534 182 557 minecraft:blue_concrete
fill 532 182 599 534 182 599 minecraft:blue_concrete
setblock 535 182 599 minecraft:white_concrete
fill 536 182 599 536 211 599 minecraft:blue_concrete
fill 538 182 557 544 182 557 minecraft:blue_concrete
fill 538 182 599 545 182 599 minecraft:blue_concrete
fill 545 182 572 545 182 574 minecraft:black_concrete
setblock 546 182 557 minecraft:blue_concrete
setblock 546 182 570 minecraft:black_concrete
setblock 547 182 557 minecraft:white_concrete
fill 548 182 557 552 183 557 minecraft:blue_concrete
fill 548 182 569 550 182 569 minecraft:black_concrete
fill 548 182 599 559 182 599 minecraft:blue_concrete
fill 549 182 582 549 183 584 minecraft:obsidian
fill 550 182 583 550 183 584 minecraft:obsidian
setblock 551 182 576 minecraft:black_concrete
setblock 552 182 571 minecraft:black_concrete
setblock 552 182 575 minecraft:black_concrete
fill 554 182 557 559 188 557 minecraft:blue_concrete
fill 559 182 558 559 183 558 minecraft:blue_concrete
fill 559 182 560 559 182 564 minecraft:blue_concrete
fill 559 182 566 559 213 566 minecraft:blue_concrete
fill 559 182 569 559 198 570 minecraft:blue_concrete
fill 559 182 572 559 182 582 minecraft:blue_concrete
fill 559 182 584 559 182 598 minecraft:blue_concrete
fill 517 183 557 517 231 558 minecraft:blue_concrete
setblock 517 183 559 minecraft:white_concrete
setblock 517 183 560 minecraft:black_concrete
fill 517 183 561 517 188 565 minecraft:blue_concrete
fill 517 183 568 517 198 571 minecraft:blue_concrete
setblock 517 183 572 minecraft:black_concrete
fill 517 183 573 517 194 573 minecraft:blue_concrete
setblock 517 183 574 minecraft:black_concrete
fill 517 183 575 517 190 579 minecraft:blue_concrete
fill 517 183 581 517 188 582 minecraft:blue_concrete
setblock 517 183 583 minecraft:white_stained_glass
fill 517 183 584 517 187 592 minecraft:blue_concrete
setblock 517 183 593 minecraft:black_concrete
fill 517 183 594 517 183 597 minecraft:blue_concrete
fill 519 183 599 522 190 599 minecraft:blue_concrete
fill 521 183 557 525 183 557 minecraft:blue_concrete
fill 523 183 599 524 183 599 minecraft:black_concrete
fill 525 183 599 526 191 599 minecraft:blue_concrete
fill 526 183 557 527 183 557 minecraft:black_concrete
fill 528 183 557 531 183 557 minecraft:blue_concrete
setblock 528 183 599 minecraft:black_concrete
fill 529 183 599 531 185 599 minecraft:blue_concrete
setblock 532 183 557 minecraft:black_concrete
setblock 532 183 599 minecraft:black_concrete
fill 533 183 557 534 186 557 minecraft:blue_concrete
fill 533 183 599 534 194 599 minecraft:blue_concrete
setblock 535 183 599 minecraft:black_concrete
fill 536 183 557 537 183 557 minecraft:blue_concrete
fill 537 183 599 537 197 599 minecraft:blue_concrete
setblock 538 183 557 minecraft:black_concrete
setblock 538 183 599 minecraft:black_concrete
fill 539 183 557 541 231 557 minecraft:blue_concrete
fill 539 183 599 551 183 599 minecraft:blue_concrete
fill 542 183 557 542 184 557 minecraft:black_concrete
fill 543 183 557 543 233 557 minecraft:blue_concrete
setblock 544 183 557 minecraft:black_concrete
setblock 545 183 557 minecraft:blue_concrete
setblock 546 183 557 minecraft:sea_lantern
fill 547 183 557 547 189 557 minecraft:blue_concrete
fill 547 183 572 547 186 572 minecraft:obsidian
fill 549 183 574 549 185 574 minecraft:obsidian
fill 550 183 572 550 184 572 minecraft:obsidian
fill 552 183 599 552 184 599 minecraft:black_concrete
fill 553 183 557 553 188 557 minecraft:blue_concrete
fill 553 183 599 555 189 599 minecraft:blue_concrete
setblock 556 183 599 minecraft:black_concrete
fill 557 183 599 558 244 599 minecraft:blue_concrete
fill 559 183 559 559 183 562 minecraft:blue_concrete
setblock 559 183 563 minecraft:black_concrete
fill 559 183 564 559 230 565 minecraft:blue_concrete
fill 559 183 567 559 188 567 minecraft:blue_concrete
fill 559 183 571 559 183 573 minecraft:blue_concrete
setblock 559 183 574 minecraft:black_concrete
fill 559 183 575 559 198 576 minecraft:blue_concrete
setblock 559 183 577 minecraft:black_concrete
fill 559 183 578 559 183 579 minecraft:blue_concrete
setblock 559 183 580 minecraft:black_concrete
fill 559 183 581 559 186 582 minecraft:blue_concrete
setblock 559 183 583 minecraft:black_concrete
fill 559 183 584 559 191 585 minecraft:blue_concrete
setblock 559 183 586 minecraft:black_concrete
fill 559 183 587 559 185 589 minecraft:blue_concrete
fill 559 183 590 559 184 590 minecraft:black_concrete
fill 559 183 591 559 185 592 minecraft:blue_concrete
setblock 559 183 593 minecraft:black_concrete
fill 559 183 594 559 216 594 minecraft:blue_concrete
setblock 559 183 595 minecraft:black_concrete
fill 559 183 596 559 183 598 minecraft:blue_concrete
fill 559 183 599 559 184 599 minecraft:black_concrete
fill 517 184 559 517 187 560 minecraft:blue_concrete
fill 517 184 567 517 187 567 minecraft:blue_concrete
fill 517 184 572 517 240 572 minecraft:blue_concrete
fill 517 184 574 517 185 574 minecraft:blue_concrete
fill 517 184 583 517 244 583 minecraft:blue_concrete
fill 517 184 593 517 184 595 minecraft:blue_concrete
setblock 517 184 596 minecraft:black_concrete
fill 517 184 597 517 188 597 minecraft:blue_concrete
fill 521 184 557 522 184 557 minecraft:black_concrete
fill 523 184 557 529 185 557 minecraft:blue_concrete
fill 523 184 599 523 247 599 minecraft:blue_concrete
setblock 524 184 599 minecraft:black_concrete
fill 527 184 599 528 186 599 minecraft:blue_concrete
setblock 530 184 557 minecraft:sea_lantern
fill 531 184 557 532 186 557 minecraft:blue_concrete
fill 532 184 599 532 206 599 minecraft:blue_concrete
fill 535 184 599 535 226 599 minecraft:blue_concrete
fill 536 184 557 537 184 557 minecraft:black_concrete
fill 538 184 557 538 219 557 minecraft:blue_concrete
fill 538 184 599 547 188 599 minecraft:blue_concrete
fill 544 184 557 544 194 557 minecraft:blue_concrete
setblock 545 184 557 minecraft:white_stained_glass
setblock 546 184 557 minecraft:blue_concrete
fill 548 184 557 548 204 557 minecraft:blue_concrete
setblock 548 184 599 minecraft:black_concrete
setblock 549 184 557 minecraft:black_concrete
fill 549 184 599 551 190 599 minecraft:blue_concrete
fill 550 184 557 552 186 557 minecraft:blue_concrete
fill 556 184 599 556 244 599 minecraft:blue_concrete
setblock 559 184 558 minecraft:black_concrete
fill 559 184 559 559 185 559 minecraft:blue_concrete
setblock 559 184 560 minecraft:black_concrete
fill 559 184 561 559 192 563 minecraft:blue_concrete
fill 559 184 568 559 188 568 minecraft:blue_concrete
fill 559 184 571 559 224 571 minecraft:blue_concrete
setblock 559 184 572 minecraft:black_concrete
fill 559 184 573 559 199 574 minecraft:blue_concrete
fill 559 184 577 559 189 578 minecraft:blue_concrete
setblock 559 184 579 minecraft:black_concrete
fill 559 184 580 559 242 580 minecraft:blue_concrete
fill 559 184 583 559 185 583 minecraft:blue_concrete
fill 559 184 586 559 239 586 minecraft:blue_concrete
fill 559 184 593 559 208 593 minecraft:blue_concrete
fill 559 184 595 559 200 596 minecraft:blue_concrete
setblock 559 184 597 minecraft:sea_lantern
fill 559 184 598 559 235 598 minecraft:blue_concrete
setblock 517 185 593 minecraft:sea_lantern
fill 517 185 594 517 189 596 minecraft:blue_concrete
fill 521 185 557 522 188 557 minecraft:blue_concrete
setblock 524 185 599 minecraft:sea_lantern
fill 530 185 557 530 211 557 minecraft:blue_concrete
fill 531 185 590 533 186 590 minecraft:obsidian
fill 532 185 589 533 186 589 minecraft:obsidian
fill 535 185 557 537 188 557 minecraft:blue_concrete
fill 542 185 557 542 240 557 minecraft:blue_concrete
fill 545 185 557 545 205 557 minecraft:blue_concrete
setblock 546 185 557 minecraft:white_concrete
fill 548 185 599 548 230 599 minecraft:blue_concrete
fill 549 185 557 549 191 557 minecraft:blue_concrete
fill 552 185 599 552 214 599 minecraft:blue_concrete
fill 559 185 558 559 198 558 minecraft:blue_concrete
fill 559 185 560 559 228 560 minecraft:blue_concrete
fill 559 185 572 559 203 572 minecraft:blue_concrete
fill 559 185 579 559 242 579 minecraft:blue_concrete
fill 559 185 590 559 195 590 minecraft:blue_concrete
fill 559 185 597 559 232 597 minecraft:blue_concrete
fill 559 185 599 559 244 599 minecraft:blue_concrete
setblock 517 186 574 minecraft:sea_lantern
fill 517 186 593 517 229 593 minecraft:blue_concrete
setblock 517 186 598 minecraft:white_concrete
fill 517 186 599 517 244 599 minecraft:blue_concrete
setblock 520 186 560 minecraft:light[level=14]
setblock 520 186 568 minecraft:light[level=14]
setblock 520 186 576 minecraft:light[level=14]
setblock 520 186 584 minecraft:light[level=14]
setblock 520 186 592 minecraft:light[level=14]
setblock 523 186 557 minecraft:sea_lantern
fill 524 186 557 529 208 557 minecraft:blue_concrete
fill 524 186 599 524 194 599 minecraft:blue_concrete
setblock 528 186 560 minecraft:light[level=14]
setblock 528 186 568 minecraft:light[level=14]
setblock 528 186 576 minecraft:light[level=14]
setblock 528 186 584 minecraft:light[level=14]
setblock 528 186 592 minecraft:light[level=14]
fill 529 186 599 529 188 599 minecraft:blue_concrete
setblock 530 186 599 minecraft:white_stained_glass
fill 531 186 599 531 188 599 minecraft:blue_concrete
setblock 536 186 560 minecraft:light[level=14]
setblock 536 186 568 minecraft:light[level=14]
setblock 536 186 576 minecraft:light[level=14]
setblock 536 186 584 minecraft:light[level=14]
setblock 536 186 592 minecraft:light[level=14]
setblock 544 186 560 minecraft:light[level=14]
setblock 544 186 568 minecraft:light[level=14]
setblock 544 186 576 minecraft:light[level=14]
setblock 544 186 584 minecraft:light[level=14]
setblock 544 186 592 minecraft:light[level=14]
fill 546 186 557 546 229 557 minecraft:blue_concrete
setblock 552 186 560 minecraft:light[level=14]
setblock 552 186 568 minecraft:light[level=14]
setblock 552 186 576 minecraft:light[level=14]
setblock 552 186 584 minecraft:light[level=14]
setblock 552 186 592 minecraft:light[level=14]
setblock 559 186 559 minecraft:white_stained_glass
setblock 559 186 583 minecraft:white_stained_glass
setblock 559 186 587 minecraft:white_stained_glass
fill 559 186 588 559 198 589 minecraft:blue_concrete
setblock 559 186 591 minecraft:white_concrete
fill 559 186 592 559 205 592 minecraft:blue_concrete
fill 517 187 574 517 209 574 minecraft:blue_concrete
fill 517 187 598 517 237 598 minecraft:blue_concrete
fill 523 187 557 523 241 557 minecraft:blue_concrete
setblock 527 187 599 minecraft:white_stained_glass
fill 528 187 599 528 188 599 minecraft:blue_concrete
fill 530 187 599 530 190 599 minecraft:blue_concrete
setblock 531 187 557 minecraft:white_concrete
fill 532 187 557 532 194 557 minecraft:blue_concrete
setblock 533 187 557 minecraft:white_concrete
fill 534 187 557 534 198 557 minecraft:blue_concrete
fill 550 187 557 550 210 557 minecraft:blue_concrete
setblock 551 187 557 minecraft:sea_lantern
fill 552 187 557 552 240 557 minecraft:blue_concrete
fill 559 187 559 559 239 559 minecraft:blue_concrete
fill 559 187 581 559 241 581 minecraft:blue_concrete
setblock 559 187 582 minecraft:white_stained_glass
fill 559 187 583 559 188 583 minecraft:blue_concrete
fill 559 187 587 559 188 587 minecraft:blue_concrete
fill 559 187 591 559 241 591 minecraft:blue_concrete
fill 517 188 559 517 225 559 minecraft:blue_concrete
setblock 517 188 560 minecraft:white_stained_glass
setblock 517 188 567 minecraft:white_stained_glass
fill 517 188 584 517 228 584 minecraft:blue_concrete
setblock 517 188 585 minecraft:sea_lantern
fill 517 188 586 517 200 592 minecraft:blue_concrete
fill 527 188 599 527 244 599 minecraft:blue_concrete
fill 531 188 557 531 223 557 minecraft:blue_concrete
fill 533 188 557 533 244 557 minecraft:blue_concrete
fill 551 188 557 551 210 557 minecraft:blue_concrete
fill 559 188 582 559 244 582 minecraft:blue_concrete
fill 517 189 560 517 203 564 minecraft:blue_concrete
fill 517 189 565 517 191 565 minecraft:white_concrete
fill 517 189 567 517 201 567 minecraft:blue_concrete
fill 517 189 581 517 191 581 minecraft:white_concrete
fill 517 189 582 517 224 582 minecraft:blue_concrete
fill 517 189 585 517 192 585 minecraft:blue_concrete
fill 517 189 597 517 191 597 minecraft:white_concrete
fill 521 189 557 521 191 557 minecraft:white_concrete
fill 522 189 557 522 203 557 minecraft:blue_concrete
fill 528 189 599 529 189 599 minecraft:sea_lantern
fill 531 189 599 531 191 599 minecraft:white_concrete
fill 535 189 557 536 226 557 minecraft:blue_concrete
fill 537 189 557 537 191 557 minecraft:white_concrete
fill 538 189 599 546 196 599 minecraft:blue_concrete
fill 547 189 599 547 191 599 minecraft:white_concrete
fill 553 189 557 553 191 557 minecraft:white_concrete
fill 554 189 557 557 201 557 minecraft:blue_concrete
setblock 558 189 557 minecraft:sea_lantern
fill 559 189 557 559 245 557 minecraft:blue_concrete
fill 559 189 567 559 189 568 minecraft:white_concrete
fill 559 189 583 559 191 583 minecraft:white_concrete
setblock 559 189 587 minecraft:white_concrete
fill 517 190 594 517 217 594 minecraft:blue_concrete
setblock 517 190 595 minecraft:white_concrete
fill 517 190 596 517 192 596 minecraft:blue_concrete
fill 528 190 599 529 194 599 minecraft:blue_concrete
setblock 547 190 557 minecraft:white_concrete
setblock 553 190 599 minecraft:white_concrete
fill 554 190 599 555 192 599 minecraft:blue_concrete
fill 558 190 557 558 217 557 minecraft:blue_concrete
fill 559 190 567 559 191 567 minecraft:white_concrete
fill 559 190 568 559 198 568 minecraft:blue_concrete
fill 559 190 577 559 235 577 minecraft:blue_concrete
setblock 559 190 578 minecraft:sea_lantern
fill 559 190 587 559 244 587 minecraft:blue_concrete
fill 517 191 575 517 198 577 minecraft:blue_concrete
setblock 517 191 578 minecraft:white_concrete
fill 517 191 579 517 238 579 minecraft:blue_concrete
fill 517 191 595 517 240 595 minecraft:blue_concrete
fill 519 191 599 521 214 599 minecraft:blue_concrete
setblock 522 191 599 minecraft:sea_lantern
setblock 530 191 599 minecraft:white_concrete
fill 547 191 557 547 226 557 minecraft:blue_concrete
fill 549 191 599 549 245 599 minecraft:blue_concrete
setblock 550 191 599 minecraft:sea_lantern
fill 551 191 599 551 217 599 minecraft:blue_concrete
fill 553 191 599 553 213 599 minecraft:blue_concrete
fill 559 191 578 559 242 578 minecraft:blue_concrete
fill 517 192 565 517 194 565 minecraft:blue_concrete
fill 517 192 578 517 227 578 minecraft:blue_concrete
fill 517 192 581 517 206 581 minecraft:blue_concrete
fill 517 192 597 517 198 597 minecraft:blue_concrete
fill 521 192 557 521 200 557 minecraft:blue_concrete
fill 522 192 599 522 242 599 minecraft:blue_concrete
fill 525 192 599 525 244 599 minecraft:blue_concrete
setblock 526 192 599 minecraft:white_stained_glass
fill 530 192 599 531 206 599 minecraft:blue_concrete
fill 537 192 557 537 206 557 minecraft:blue_concrete
fill 547 192 599 547 206 599 minecraft:blue_concrete
fill 549 192 557 549 193 557 minecraft:white_stained_glass
fill 550 192 599 550 244 599 minecraft:blue_concrete
fill 553 192 557 553 193 557 minecraft:blue_concrete
fill 559 192 567 559 206 567 minecraft:blue_concrete
fill 559 192 583 559 206 584 minecraft:blue_concrete
setblock 559 192 585 minecraft:sea_lantern
setblock 517 193 585 minecraft:white_concrete
setblock 517 193 596 minecraft:sea_lantern
fill 526 193 599 526 242 599 minecraft:blue_concrete
fill 554 193 599 554 209 599 minecraft:blue_concrete
setblock 555 193 599 minecraft:sea_lantern
fill 559 193 561 559 193 562 minecraft:white_concrete
fill 559 193 563 559 196 563 minecraft:blue_concrete
fill 559 193 585 559 238 585 minecraft:blue_concrete
fill 517 194 585 517 196 585 minecraft:blue_concrete
fill 517 194 596 517 216 596 minecraft:blue_concrete
setblock 520 194 560 minecraft:light[level=14]
setblock 520 194 568 minecraft:light[level=14]
setblock 520 194 576 minecraft:light[level=14]
setblock 520 194 584 minecraft:light[level=14]
setblock 520 194 592 minecraft:light[level=14]
setblock 528 194 560 minecraft:light[level=14]
setblock 528 194 568 minecraft:light[level=14]
setblock 528 194 576 minecraft:light[level=14]
setblock 528 194 584 minecraft:light[level=14]
setblock 528 194 592 minecraft:light[level=14]
setblock 536 194 560 minecraft:light[level=14]
setblock 536 194 568 minecraft:light[level=14]
setblock 536 194 576 minecraft:light[level=14]
setblock 536 194 584 minecraft:light[level=14]
setblock 536 194 592 minecraft:light[level=14]
setblock 544 194 560 minecraft:light[level=14]
setblock 544 194 568 minecraft:light[level=14]
setblock 544 194 576 minecraft:light[level=14]
setblock 544 194 584 minecraft:light[level=14]
setblock 544 194 592 minecraft:light[level=14]
fill 549 194 557 549 214 557 minecraft:blue_concrete
setblock 552 194 560 minecraft:light[level=14]
setblock 552 194 568 minecraft:light[level=14]
setblock 552 194 576 minecraft:light[level=14]
setblock 552 194 584 minecraft:light[level=14]
setblock 552 194 592 minecraft:light[level=14]
setblock 553 194 557 minecraft:white_stained_glass
fill 555 194 599 555 204 599 minecraft:blue_concrete
fill 559 194 561 559 224 562 minecraft:blue_concrete
setblock 517 195 565 minecraft:sea_lantern
setblock 517 195 573 minecraft:white_stained_glass
setblock 524 195 599 minecraft:white_concrete
setblock 528 195 599 minecraft:white_concrete
fill 529 195 599 529 237 599 minecraft:blue_concrete
setblock 532 195 557 minecraft:sea_lantern
setblock 533 195 599 minecraft:white_stained_glass
fill 534 195 599 534 198 599 minecraft:blue_concrete
setblock 544 195 557 minecraft:white_concrete
fill 553 195 557 553 206 557 minecraft:blue_concrete
fill 517 196 565 517 206 565 minecraft:blue_concrete
fill 517 196 573 517 244 573 minecraft:blue_concrete
fill 524 196 599 524 238 599 minecraft:blue_concrete
fill 528 196 599 528 244 599 minecraft:blue_concrete
fill 532 196 557 532 244 557 minecraft:blue_concrete
fill 533 196 599 533 197 599 minecraft:blue_concrete
fill 544 196 557 544 240 557 minecraft:blue_concrete
setblock 559 196 590 minecraft:white_stained_glass
setblock 517 197 585 minecraft:sea_lantern
fill 538 197 599 539 199 599 minecraft:blue_concrete
setblock 540 197 599 minecraft:white_concrete
fill 541 197 599 546 208 599 minecraft:blue_concrete
setblock 559 197 563 minecraft:white_stained_glass
fill 559 197 590 559 242 590 minecraft:blue_concrete
fill 517 198 585 517 244 585 minecraft:blue_concrete
setblock 533 198 599 minecraft:white_concrete
setblock 537 198 599 minecraft:sea_lantern
setblock 540 198 599 minecraft:white_stained_glass
fill 559 198 563 559 223 563 minecraft:blue_concrete
fill 517 199 568 517 244 568 minecraft:blue_concrete
setblock 517 199 569 minecraft:white_stained_glass
fill 517 199 570 517 240 571 minecraft:blue_concrete
fill 517 199 575 517 244 576 minecraft:blue_concrete
setblock 517 199 577 minecraft:sea_lantern
setblock 517 199 597 minecraft:white_stained_glass
fill 533 199 582 535 199 584 minecraft:redstone_block
fill 533 199 599 533 239 599 minecraft:blue_concrete
setblock 534 199 557 minecraft:white_concrete
fill 534 199 575 536 199 577 minecraft:redstone_block
setblock 534 199 599 minecraft:sea_lantern
fill 537 199 599 537 200 599 minecraft:white_concrete
fill 540 199 575 542 199 577 minecraft:redstone_block
fill 540 199 599 540 227 599 minecraft:blue_concrete
fill 541 199 582 543 199 584 minecraft:redstone_block
setblock 559 199 558 minecraft:white_stained_glass
setblock 559 199 568 minecraft:white_stained_glass
fill 559 199 569 559 228 569 minecraft:blue_concrete
setblock 559 199 570 minecraft:white_stained_glass
fill 559 199 575 559 240 575 minecraft:blue_concrete
setblock 559 199 576 minecraft:sea_lantern
setblock 559 199 588 minecraft:sea_lantern
fill 559 199 589 559 242 589 minecraft:blue_concrete
fill 517 200 569 517 207 569 minecraft:blue_concrete
fill 517 200 577 517 220 577 minecraft:blue_concrete
fill 517 200 597 517 206 597 minecraft:blue_concrete
fill 519 200 579 536 200 581 minecraft:white_concrete
fill 534 200 557 534 244 557 minecraft:blue_concrete
fill 534 200 599 534 244 599 minecraft:blue_concrete
fill 537 200 561 539 200 578 minecraft:white_concrete
fill 537 200 582 539 200 598 minecraft:white_concrete
fill 538 200 599 539 200 599 minecraft:white_concrete
fill 540 200 579 557 200 581 minecraft:white_concrete
fill 559 200 558 559 240 558 minecraft:blue_concrete
fill 559 200 568 559 240 568 minecraft:blue_concrete
fill 559 200 570 559 241 570 minecraft:blue_concrete
setblock 559 200 573 minecraft:white_stained_glass
fill 559 200 574 559 244 574 minecraft:blue_concrete
fill 559 200 576 559 244 576 minecraft:blue_concrete
fill 559 200 588 559 218 588 minecraft:blue_concrete
fill 517 201 586 517 244 588 minecraft:blue_concrete
setblock 517 201 589 minecraft:white_stained_glass
fill 517 201 590 517 220 592 minecraft:blue_concrete
fill 518 201 557 519 202 557 minecraft:blue_concrete
fill 518 201 558 518 201 598 minecraft:black_concrete
fill 519 201 558 532 201 578 minecraft:black_concrete
fill 519 201 579 535 201 579 minecraft:sea_lantern
fill 519 201 580 535 201 580 minecraft:white_concrete
fill 519 201 581 535 201 581 minecraft:sea_lantern
fill 519 201 582 531 201 598 minecraft:black_concrete
setblock 520 201 557 minecraft:white_concrete
setblock 521 201 557 minecraft:sea_lantern
fill 532 201 582 532 201 585 minecraft:sea_lantern
fill 532 201 586 536 201 598 minecraft:black_concrete
fill 533 201 558 536 201 573 minecraft:black_concrete
fill 533 201 574 533 201 578 minecraft:sea_lantern
fill 533 201 582 535 201 584 minecraft:black_concrete
fill 533 201 585 537 201 585 minecraft:sea_lantern
fill 534 201 574 537 201 574 minecraft:sea_lantern
fill 534 201 575 536 201 577 minecraft:black_concrete
fill 534 201 578 536 201 578 minecraft:sea_lantern
fill 536 201 579 536 201 581 minecraft:pearlescent_froglight
fill 536 201 582 536 201 584 minecraft:sea_lantern
fill 537 201 558 558 201 560 minecraft:black_concrete
fill 537 201 561 537 201 573 minecraft:sea_lantern
fill 537 201 575 537 201 577 minecraft:sea_lantern
fill 537 201 578 539 201 578 minecraft:pearlescent_froglight
fill 537 201 582 539 201 582 minecraft:pearlescent_froglight
fill 537 201 583 537 201 584 minecraft:sea_lantern
fill 537 201 586 537 201 599 minecraft:sea_lantern
fill 538 201 561 538 201 577 minecraft:white_concrete
fill 538 201 583 538 201 599 minecraft:white_concrete
fill 539 201 561 539 201 577 minecraft:sea_lantern
fill 539 201 583 539 201 599 minecraft:sea_lantern
fill 540 201 561 558 201 573 minecraft:black_concrete
fill 540 201 574 543 201 574 minecraft:sea_lantern
fill 540 201 575 542 201 577 minecraft:black_concrete
fill 540 201 578 543 201 578 minecraft:sea_lantern
fill 540 201 579 540 201 581 minecraft:pearlescent_froglight
fill 540 201 582 540 201 585 minecraft:sea_lantern
fill 540 201 586 558 201 598 minecraft:black_concrete
fill 541 201 579 557 201 579 minecraft:sea_lantern
fill 541 201 580 557 201 580 minecraft:white_concrete
fill 541 201 581 557 201 581 minecraft:sea_lantern
fill 541 201 582 543 201 584 minecraft:black_concrete
fill 541 201 585 544 201 585 minecraft:sea_lantern
fill 543 201 575 543 201 577 minecraft:sea_lantern
fill 544 201 574 558 201 578 minecraft:black_concrete
fill 544 201 582 544 201 584 minecraft:sea_lantern
fill 545 201 582 558 201 585 minecraft:black_concrete
fill 558 201 579 558 201 581 minecraft:black_concrete
fill 559 201 573 559 231 573 minecraft:blue_concrete
fill 559 201 595 559 239 595 minecraft:blue_concrete
setblock 559 201 596 minecraft:white_concrete
fill 517 202 566 517 202 567 minecraft:sea_lantern
fill 517 202 589 517 242 589 minecraft:blue_concrete
fill 520 202 557 521 206 557 minecraft:blue_concrete
setblock 520 202 560 minecraft:light[level=14]
setblock 520 202 568 minecraft:light[level=14]
setblock 520 202 576 minecraft:light[level=14]
setblock 520 202 584 minecraft:light[level=14]
setblock 520 202 592 minecraft:light[level=14]
fill 526 202 580 526 203 581 minecraft:cobblestone
setblock 528 202 560 minecraft:light[level=14]
setblock 528 202 568 minecraft:light[level=14]
fill 528 202 573 528 203 574 minecraft:cobblestone
setblock 528 202 576 minecraft:light[level=14]
setblock 528 202 584 minecraft:light[level=14]
fill 528 202 588 528 203 589 minecraft:cobblestone
setblock 528 202 592 minecraft:light[level=14]
fill 529 202 573 534 202 587 minecraft:dark_oak_planks
fill 535 202 569 535 203 570 minecraft:cobblestone
fill 535 202 573 547 202 576 minecraft:dark_oak_planks
fill 535 202 585 547 202 587 minecraft:dark_oak_planks
fill 535 202 592 535 203 593 minecraft:cobblestone
setblock 536 202 560 minecraft:light[level=14]
setblock 536 202 568 minecraft:light[level=14]
setblock 536 202 592 minecraft:light[level=14]
fill 537 202 599 539 208 599 minecraft:blue_concrete
fill 542 202 569 542 203 570 minecraft:cobblestone
fill 542 202 592 542 203 593 minecraft:cobblestone
fill 543 202 577 547 202 584 minecraft:dark_oak_planks
setblock 544 202 560 minecraft:light[level=14]
setblock 544 202 568 minecraft:light[level=14]
setblock 544 202 592 minecraft:light[level=14]
fill 549 202 573 549 203 574 minecraft:cobblestone
fill 549 202 588 549 203 589 minecraft:cobblestone
fill 551 202 580 551 203 581 minecraft:cobblestone
setblock 552 202 560 minecraft:light[level=14]
setblock 552 202 568 minecraft:light[level=14]
setblock 552 202 576 minecraft:light[level=14]
setblock 552 202 584 minecraft:light[level=14]
setblock 552 202 592 minecraft:light[level=14]
fill 554 202 557 556 207 557 minecraft:blue_concrete
setblock 557 202 557 minecraft:white_stained_glass
fill 559 202 596 559 237 596 minecraft:blue_concrete
fill 517 203 566 517 205 567 minecraft:blue_concrete
setblock 518 203 557 minecraft:sea_lantern
fill 519 203 557 519 244 557 minecraft:blue_concrete
fill 529 203 573 529 203 587 minecraft:dark_oak_planks
fill 530 203 573 547 203 573 minecraft:dark_oak_planks
fill 530 203 587 547 203 587 minecraft:dark_oak_planks
fill 547 203 574 547 203 586 minecraft:dark_oak_planks
fill 557 203 557 557 242 557 minecraft:blue_concrete
setblock 517 204 560 minecraft:white_concrete
fill 517 204 561 517 208 564 minecraft:blue_concrete
fill 518 204 557 518 244 557 minecraft:blue_concrete
setblock 522 204 557 minecraft:white_concrete
fill 529 204 573 529 209 573 minecraft:dark_oak_planks
setblock 529 204 574 minecraft:ochre_froglight
fill 529 204 575 529 209 576 minecraft:dark_oak_planks
setblock 529 204 577 minecraft:ochre_froglight
fill 529 204 578 529 209 579 minecraft:dark_oak_planks
setblock 529 204 580 minecraft:ochre_froglight
fill 529 204 581 529 209 582 minecraft:dark_oak_planks
setblock 529 204 583 minecraft:ochre_froglight
fill 529 204 584 529 209 585 minecraft:dark_oak_planks
setblock 529 204 586 minecraft:ochre_froglight
fill 529 204 587 530 209 587 minecraft:dark_oak_planks
setblock 530 204 573 minecraft:ochre_froglight
fill 531 204 573 532 209 573 minecraft:dark_oak_planks
setblock 531 204 587 minecraft:ochre_froglight
fill 532 204 587 533 209 587 minecraft:dark_oak_planks
setblock 533 204 573 minecraft:ochre_froglight
fill 534 204 573 535 209 573 minecraft:dark_oak_planks
setblock 534 204 587 minecraft:ochre_froglight
fill 535 204 587 536 209 587 minecraft:dark_oak_planks
setblock 536 204 573 minecraft:ochre_froglight
fill 537 204 573 538 209 573 minecraft:dark_oak_planks
setblock 537 204 587 minecraft:ochre_froglight
fill 538 204 587 539 209 587 minecraft:dark_oak_planks
setblock 539 204 573 minecraft:ochre_froglight
fill 540 204 573 541 209 573 minecraft:dark_oak_planks
setblock 540 204 587 minecraft:ochre_froglight
fill 541 204 587 542 209 587 minecraft:dark_oak_planks
setblock 542 204 573 minecraft:ochre_froglight
fill 543 204 573 544 209 573 minecraft:dark_oak_planks
setblock 543 204 587 minecraft:ochre_froglight
fill 544 204 587 545 209 587 minecraft:dark_oak_planks
setblock 545 204 573 minecraft:ochre_froglight
fill 546 204 573 547 209 573 minecraft:dark_oak_planks
setblock 546 204 587 minecraft:ochre_froglight
setblock 547 204 574 minecraft:ochre_froglight
fill 547 204 575 547 209 576 minecraft:dark_oak_planks
setblock 547 204 577 minecraft:ochre_froglight
fill 547 204 578 547 209 579 minecraft:dark_oak_planks
setblock 547 204 580 minecraft:ochre_froglight
fill 547 204 581 547 209 582 minecraft:dark_oak_planks
setblock 547 204 583 minecraft:ochre_froglight
fill 547 204 584 547 209 585 minecraft:dark_oak_planks
setblock 547 204 586 minecraft:ochre_froglight
fill 547 204 587 547 209 587 minecraft:dark_oak_planks
setblock 559 204 572 minecraft:white_concrete
fill 517 205 560 517 219 560 minecraft:blue_concrete
fill 522 205 557 522 244 557 minecraft:blue_concrete
fill 529 205 574 529 207 574 minecraft:dark_oak_planks
fill 529 205 577 529 207 577 minecraft:dark_oak_planks
fill 529 205 580 529 207 580 minecraft:dark_oak_planks
fill 529 205 583 529 207 583 minecraft:dark_oak_planks
fill 529 205 586 529 207 586 minecraft:dark_oak_planks
fill 530 205 573 530 207 573 minecraft:dark_oak_planks
fill 531 205 587 531 207 587 minecraft:dark_oak_planks
fill 533 205 573 533 207 573 minecraft:dark_oak_planks
fill 534 205 587 534 207 587 minecraft:dark_oak_planks
fill 536 205 573 536 207 573 minecraft:dark_oak_planks
fill 537 205 587 537 207 587 minecraft:dark_oak_planks
fill 538 205 592 544 206 595 minecraft:black_concrete
fill 539 205 573 539 207 573 minecraft:dark_oak_planks
fill 539 205 591 544 206 591 minecraft:black_concrete
fill 539 205 596 544 206 596 minecraft:black_concrete
fill 540 205 587 540 207 587 minecraft:dark_oak_planks
fill 540 205 590 542 206 590 minecraft:black_concrete
fill 540 205 597 543 206 597 minecraft:black_concrete
fill 542 205 573 542 207 573 minecraft:dark_oak_planks
fill 543 205 587 543 207 587 minecraft:dark_oak_planks
fill 545 205 573 545 207 573 minecraft:dark_oak_planks
fill 545 205 593 545 206 594 minecraft:black_concrete
fill 546 205 587 546 207 587 minecraft:dark_oak_planks
fill 547 205 574 547 207 574 minecraft:dark_oak_planks
fill 547 205 577 547 207 577 minecraft:dark_oak_planks
fill 547 205 580 547 207 580 minecraft:dark_oak_planks
fill 547 205 583 547 207 583 minecraft:dark_oak_planks
fill 547 205 586 547 207 586 minecraft:dark_oak_planks
setblock 548 205 557 minecraft:white_concrete
fill 551 205 579 557 207 583 minecraft:black_concrete
fill 552 205 578 556 207 578 minecraft:black_concrete
fill 552 205 584 556 207 584 minecraft:black_concrete
fill 554 205 577 554 207 577 minecraft:black_concrete
setblock 555 205 599 minecraft:white_stained_glass
fill 558 205 581 558 207 581 minecraft:black_concrete
fill 559 205 572 559 214 572 minecraft:blue_concrete
fill 517 206 566 517 244 566 minecraft:blue_concrete
setblock 517 206 567 minecraft:sea_lantern
fill 537 206 593 537 206 594 minecraft:black_concrete
setblock 538 206 591 minecraft:black_concrete
setblock 538 206 596 minecraft:black_concrete
setblock 539 206 590 minecraft:black_concrete
setblock 539 206 597 minecraft:black_concrete
setblock 543 206 590 minecraft:black_concrete
setblock 545 206 557 minecraft:white_concrete
setblock 545 206 592 minecraft:black_concrete
setblock 545 206 595 minecraft:black_concrete
fill 548 206 557 548 244 557 minecraft:blue_concrete
fill 550 206 580 550 207 582 minecraft:black_concrete
fill 551 206 578 551 207 578 minecraft:black_concrete
fill 551 206 584 551 207 584 minecraft:black_concrete
fill 553 206 577 553 207 577 minecraft:black_concrete
fill 553 206 585 556 207 585 minecraft:black_concrete
fill 555 206 577 556 207 577 minecraft:black_concrete
setblock 555 206 599 minecraft:blue_concrete
fill 557 206 578 557 207 578 minecraft:black_concrete
fill 557 206 584 557 207 584 minecraft:black_concrete
fill 558 206 579 558 207 580 minecraft:black_concrete
fill 558 206 582 558 207 583 minecraft:black_concrete
setblock 559 206 592 minecraft:sea_lantern
fill 517 207 565 517 209 565 minecraft:white_concrete
fill 517 207 567 517 240 567 minecraft:blue_concrete
fill 517 207 581 517 209 581 minecraft:white_concrete
fill 517 207 597 517 209 597 minecraft:white_concrete
fill 520 207 557 520 209 557 minecraft:blue_concrete
fill 521 207 557 521 209 557 minecraft:white_concrete
fill 530 207 599 530 244 599 minecraft:blue_concrete
fill 531 207 599 532 207 599 minecraft:white_concrete
fill 537 207 557 537 209 557 minecraft:white_concrete
fill 540 207 593 540 210 593 minecraft:obsidian
fill 542 207 592 542 208 592 minecraft:obsidian
fill 542 207 595 542 208 595 minecraft:obsidian
fill 545 207 557 545 244 557 minecraft:blue_concrete
fill 547 207 599 547 209 599 minecraft:white_concrete
fill 549 207 582 549 208 583 minecraft:obsidian
setblock 550 207 579 minecraft:black_concrete
setblock 550 207 583 minecraft:black_concrete
setblock 552 207 577 minecraft:black_concrete
setblock 552 207 585 minecraft:black_concrete
fill 553 207 557 553 209 557 minecraft:white_concrete
setblock 555 207 599 minecraft:white_stained_glass
setblock 557 207 577 minecraft:black_concrete
setblock 557 207 585 minecraft:black_concrete
setblock 558 207 578 minecraft:black_concrete
setblock 558 207 584 minecraft:black_concrete
fill 559 207 567 559 209 567 minecraft:white_concrete
fill 559 207 583 559 209 583 minecraft:white_concrete
fill 559 207 584 559 244 584 minecraft:blue_concrete
fill 559 207 592 559 231 592 minecraft:blue_concrete
setblock 517 208 569 minecraft:white_concrete
setblock 529 208 574 minecraft:ochre_froglight
setblock 529 208 577 minecraft:ochre_froglight
setblock 529 208 580 minecraft:ochre_froglight
setblock 529 208 583 minecraft:ochre_froglight
setblock 529 208 586 minecraft:ochre_froglight
setblock 530 208 573 minecraft:ochre_froglight
setblock 531 208 587 minecraft:ochre_froglight
fill 531 208 599 531 209 599 minecraft:white_concrete
fill 532 208 599 532 222 599 minecraft:blue_concrete
setblock 533 208 573 minecraft:ochre_froglight
setblock 534 208 587 minecraft:ochre_froglight
setblock 536 208 573 minecraft:ochre_froglight
setblock 537 208 587 minecraft:ochre_froglight
setblock 539 208 573 minecraft:ochre_froglight
setblock 540 208 587 minecraft:ochre_froglight
setblock 542 208 573 minecraft:ochre_froglight
setblock 543 208 587 minecraft:ochre_froglight
setblock 545 208 573 minecraft:ochre_froglight
setblock 546 208 587 minecraft:ochre_froglight
setblock 547 208 574 minecraft:ochre_froglight
setblock 547 208 577 minecraft:ochre_froglight
setblock 547 208 580 minecraft:ochre_froglight
setblock 547 208 583 minecraft:ochre_froglight
setblock 547 208 586 minecraft:ochre_froglight
fill 553 208 582 553 211 582 minecraft:obsidian
fill 554 208 557 555 241 557 minecraft:blue_concrete
fill 554 208 579 554 209 579 minecraft:obsidian
fill 555 208 599 555 244 599 minecraft:blue_concrete
setblock 556 208 557 minecraft:white_stained_glass
fill 556 208 581 556 209 581 minecraft:obsidian
setblock 517 209 561 minecraft:white_stained_glass
fill 517 209 562 517 229 564 minecraft:blue_concrete
fill 517 209 569 517 240 569 minecraft:blue_concrete
fill 524 209 557 525 218 557 minecraft:blue_concrete
setblock 526 209 557 minecraft:white_stained_glass
fill 527 209 557 529 213 557 minecraft:blue_concrete
fill 529 209 574 547 209 574 minecraft:dark_oak_planks
fill 529 209 577 534 209 577 minecraft:dark_oak_planks
fill 529 209 580 534 209 580 minecraft:dark_oak_planks
fill 529 209 583 534 209 583 minecraft:dark_oak_planks
fill 529 209 586 547 209 586 minecraft:dark_oak_planks
setblock 530 209 573 minecraft:dark_oak_planks
fill 530 209 575 546 209 576 minecraft:dark_oak_planks
fill 530 209 578 534 209 579 minecraft:dark_oak_planks
fill 530 209 581 534 209 582 minecraft:dark_oak_planks
fill 530 209 584 534 209 585 minecraft:dark_oak_planks
setblock 531 209 587 minecraft:dark_oak_planks
setblock 533 209 573 minecraft:dark_oak_planks
setblock 534 209 587 minecraft:dark_oak_planks
fill 535 209 585 546 209 585 minecraft:dark_oak_planks
setblock 536 209 573 minecraft:dark_oak_planks
setblock 537 209 587 minecraft:dark_oak_planks
setblock 537 209 599 minecraft:sea_lantern
fill 538 209 599 538 234 599 minecraft:blue_concrete
setblock 539 209 573 minecraft:dark_oak_planks
setblock 539 209 599 minecraft:white_concrete
setblock 540 209 587 minecraft:dark_oak_planks
fill 541 209 599 543 244 599 minecraft:blue_concrete
setblock 542 209 573 minecraft:dark_oak_planks
fill 543 209 577 546 209 584 minecraft:dark_oak_planks
setblock 543 209 587 minecraft:dark_oak_planks
setblock 544 209 599 minecraft:sea_lantern
setblock 545 209 573 minecraft:dark_oak_planks
fill 545 209 599 546 215 599 minecraft:blue_concrete
setblock 546 209 587 minecraft:dark_oak_planks
setblock 547 209 577 minecraft:dark_oak_planks
setblock 547 209 580 minecraft:dark_oak_planks
setblock 547 209 583 minecraft:dark_oak_planks
fill 556 209 557 556 222 557 minecraft:blue_concrete
setblock 559 209 593 minecraft:sea_lantern
fill 517 210 561 517 241 561 minecraft:blue_concrete
fill 517 210 565 517 215 565 minecraft:blue_concrete
setblock 517 210 574 minecraft:sea_lantern
fill 517 210 581 517 215 581 minecraft:blue_concrete
fill 517 210 597 517 215 597 minecraft:blue_concrete
setblock 520 210 557 minecraft:sea_lantern
setblock 520 210 560 minecraft:light[level=14]
setblock 520 210 568 minecraft:light[level=14]
setblock 520 210 576 minecraft:light[level=14]
setblock 520 210 584 minecraft:light[level=14]
setblock 520 210 592 minecraft:light[level=14]
fill 521 210 557 521 215 557 minecraft:blue_concrete
fill 526 210 557 526 245 557 minecraft:blue_concrete
setblock 528 210 560 minecraft:light[level=14]
setblock 528 210 568 minecraft:light[level=14]
setblock 528 210 576 minecraft:light[level=14]
setblock 528 210 584 minecraft:light[level=14]
setblock 528 210 592 minecraft:light[level=14]
fill 529 210 573 534 210 587 minecraft:deepslate_tiles
fill 531 210 599 531 215 599 minecraft:blue_concrete
fill 535 210 573 547 210 576 minecraft:deepslate_tiles
fill 535 210 585 547 210 587 minecraft:deepslate_tiles
setblock 536 210 560 minecraft:light[level=14]
setblock 536 210 568 minecraft:light[level=14]
setblock 536 210 592 minecraft:light[level=14]
fill 537 210 557 537 215 557 minecraft:blue_concrete
fill 537 210 599 537 224 599 minecraft:blue_concrete
fill 539 210 599 539 244 599 minecraft:blue_concrete
fill 543 210 577 547 210 584 minecraft:deepslate_tiles
setblock 544 210 560 minecraft:light[level=14]
setblock 544 210 568 minecraft:light[level=14]
setblock 544 210 592 minecraft:light[level=14]
fill 544 210 599 544 244 599 minecraft:blue_concrete
fill 547 210 599 547 215 599 minecraft:blue_concrete
setblock 552 210 560 minecraft:light[level=14]
setblock 552 210 568 minecraft:light[level=14]
setblock 552 210 576 minecraft:light[level=14]
setblock 552 210 584 minecraft:light[level=14]
setblock 552 210 592 minecraft:light[level=14]
fill 553 210 557 553 215 557 minecraft:blue_concrete
setblock 554 210 599 minecraft:sea_lantern
fill 559 210 567 559 215 567 minecraft:blue_concrete
fill 559 210 583 559 215 583 minecraft:blue_concrete
fill 559 210 593 559 244 593 minecraft:blue_concrete
fill 517 211 574 517 220 574 minecraft:blue_concrete
fill 520 211 557 520 241 557 minecraft:blue_concrete
fill 530 211 574 534 211 586 minecraft:deepslate_tiles
fill 535 211 574 546 211 576 minecraft:deepslate_tiles
fill 535 211 585 546 211 586 minecraft:deepslate_tiles
fill 543 211 577 546 211 584 minecraft:deepslate_tiles
setblock 550 211 557 minecraft:white_stained_glass
setblock 551 211 557 minecraft:white_concrete
fill 554 211 599 554 244 599 minecraft:blue_concrete
setblock 530 212 557 minecraft:white_concrete
fill 531 212 575 534 212 585 minecraft:deepslate_tiles
fill 535 212 575 545 212 576 minecraft:deepslate_tiles
fill 535 212 585 545 212 585 minecraft:deepslate_tiles
setblock 536 212 599 minecraft:sea_lantern
fill 543 212 577 545 212 584 minecraft:deepslate_tiles
fill 550 212 557 551 212 557 minecraft:blue_concrete
fill 530 213 557 530 215 557 minecraft:blue_concrete
fill 532 213 576 534 213 584 minecraft:deepslate_tiles
fill 535 213 576 544 213 576 minecraft:deepslate_tiles
fill 536 213 599 536 244 599 minecraft:blue_concrete
fill 543 213 577 544 213 584 minecraft:deepslate_tiles
fill 550 213 557 550 244 557 minecraft:blue_concrete
setblock 551 213 557 minecraft:white_stained_glass
setblock 527 214 557 minecraft:sea_lantern
fill 528 214 557 529 225 557 minecraft:blue_concrete
fill 533 214 577 534 214 583 minecraft:deepslate_tiles
fill 543 214 577 543 214 583 minecraft:deepslate_tiles
fill 543 214 591 543 215 592 minecraft:obsidian
fill 551 214 557 551 221 557 minecraft:blue_concrete
setblock 553 214 599 minecraft:white_stained_glass
setblock 559 214 566 minecraft:sea_lantern
setblock 518 215 599 minecraft:white_stained_glass
setblock 519 215 599 minecraft:white_concrete
fill 520 215 599 521 238 599 minecraft:blue_concrete
fill 527 215 557 527 239 557 minecraft:blue_concrete
fill 534 215 578 534 215 582 minecraft:deepslate_tiles
setblock 549 215 557 minecraft:sea_lantern
setblock 552 215 599 minecraft:white_concrete
fill 553 215 599 553 218 599 minecraft:blue_concrete
fill 559 215 566 559 244 566 minecraft:blue_concrete
setblock 559 215 572 minecraft:white_stained_glass
fill 517 216 565 517 218 565 minecraft:white_concrete
fill 517 216 581 517 218 581 minecraft:white_concrete
fill 517 216 597 517 218 597 minecraft:white_concrete
fill 518 216 599 519 240 599 minecraft:blue_concrete
fill 521 216 557 521 218 557 minecraft:white_concrete
fill 528 216 576 529 217 576 minecraft:white_concrete
setblock 530 216 557 minecraft:sea_lantern
fill 531 216 599 531 218 599 minecraft:white_concrete
fill 534 216 585 535 217 586 minecraft:white_concrete
fill 537 216 557 537 218 557 minecraft:white_concrete
setblock 545 216 599 minecraft:white_stained_glass
fill 546 216 599 546 240 599 minecraft:blue_concrete
fill 547 216 599 547 218 599 minecraft:white_concrete
fill 549 216 557 549 244 557 minecraft:blue_concrete
fill 552 216 599 552 244 599 minecraft:blue_concrete
fill 553 216 557 553 218 557 minecraft:white_concrete
fill 559 216 567 559 218 567 minecraft:white_concrete
fill 559 216 572 559 221 572 minecraft:blue_concrete
fill 559 216 583 559 218 583 minecraft:white_concrete
setblock 517 217 596 minecraft:sea_lantern
fill 530 217 557 530 230 557 minecraft:blue_concrete
fill 535 217 595 537 218 595 minecraft:obsidian
fill 536 217 594 536 218 594 minecraft:obsidian
fill 536 217 596 536 218 596 minecraft:obsidian
fill 545 217 599 545 241 599 minecraft:blue_concrete
setblock 559 217 594 minecraft:sea_lantern
setblock 517 218 594 minecraft:white_stained_glass
fill 517 218 596 517 235 596 minecraft:blue_concrete
setblock 520 218 560 minecraft:light[level=14]
setblock 520 218 568 minecraft:light[level=14]
setblock 520 218 576 minecraft:light[level=14]
setblock 520 218 584 minecraft:light[level=14]
setblock 520 218 592 minecraft:light[level=14]
setblock 528 218 560 minecraft:light[level=14]
setblock 528 218 568 minecraft:light[level=14]
setblock 528 218 576 minecraft:light[level=14]
setblock 528 218 584 minecraft:light[level=14]
setblock 528 218 592 minecraft:light[level=14]
setblock 536 218 560 minecraft:light[level=14]
setblock 536 218 568 minecraft:light[level=14]
setblock 536 218 576 minecraft:light[level=14]
setblock 536 218 584 minecraft:light[level=14]
setblock 536 218 592 minecraft:light[level=14]
setblock 544 218 560 minecraft:light[level=14]
setblock 544 218 568 minecraft:light[level=14]
setblock 544 218 576 minecraft:light[level=14]
setblock 544 218 584 minecraft:light[level=14]
setblock 544 218 592 minecraft:light[level=14]
setblock 551 218 599 minecraft:white_stained_glass
setblock 552 218 560 minecraft:light[level=14]
setblock 552 218 568 minecraft:light[level=14]
setblock 552 218 576 minecraft:light[level=14]
setblock 552 218 584 minecraft:light[level=14]
setblock 552 218 592 minecraft:light[level=14]
setblock 558 218 557 minecraft:sea_lantern
fill 559 218 594 559 244 594 minecraft:blue_concrete
fill 517 219 565 517 224 565 minecraft:blue_concrete
fill 517 219 581 517 224 581 minecraft:blue_concrete
fill 517 219 594 517 244 594 minecraft:blue_concrete
fill 517 219 597 517 224 597 minecraft:blue_concrete
fill 521 219 557 521 224 557 minecraft:blue_concrete
fill 524 219 557 524 228 557 minecraft:blue_concrete
setblock 525 219 557 minecraft:sea_lantern
fill 531 219 599 531 224 599 minecraft:blue_concrete
fill 537 219 557 537 224 557 minecraft:blue_concrete
fill 547 219 599 547 224 599 minecraft:blue_concrete
fill 551 219 599 551 241 599 minecraft:blue_concrete
fill 553 219 557 553 224 557 minecraft:blue_concrete
setblock 553 219 599 minecraft:white_stained_glass
fill 558 219 557 558 227 557 minecraft:blue_concrete
fill 559 219 567 559 224 567 minecraft:blue_concrete
fill 559 219 583 559 224 583 minecraft:blue_concrete
setblock 559 219 588 minecraft:white_stained_glass
setblock 517 220 560 minecraft:sea_lantern
fill 525 220 557 525 240 557 minecraft:blue_concrete
setblock 538 220 557 minecraft:sea_lantern
fill 553 220 599 553 242 599 minecraft:blue_concrete
fill 559 220 588 559 240 588 minecraft:blue_concrete
fill 517 221 560 517 244 560 minecraft:blue_concrete
setblock 517 221 574 minecraft:white_stained_glass
setblock 517 221 577 minecraft:white_concrete
fill 517 221 590 517 229 590 minecraft:blue_concrete
setblock 517 221 591 minecraft:sea_lantern
fill 517 221 592 517 244 592 minecraft:blue_concrete
fill 538 221 557 538 242 557 minecraft:blue_concrete
fill 542 221 596 543 222 597 minecraft:white_concrete
fill 517 222 574 517 241 574 minecraft:blue_concrete
fill 517 222 577 517 244 577 minecraft:blue_concrete
fill 517 222 591 517 244 591 minecraft:blue_concrete
fill 541 222 569 541 223 570 minecraft:blue_concrete
setblock 551 222 557 minecraft:sea_lantern
setblock 559 222 572 minecraft:sea_lantern
setblock 532 223 599 minecraft:white_stained_glass
fill 551 223 557 551 231 557 minecraft:blue_concrete
setblock 556 223 557 minecraft:sea_lantern
fill 559 223 572 559 242 572 minecraft:blue_concrete
setblock 531 224 557 minecraft:white_concrete
fill 532 224 599 532 244 599 minecraft:blue_concrete
fill 544 224 590 544 225 590 minecraft:blue_concrete
fill 546 224 594 546 225 594 minecraft:white_concrete
fill 547 224 564 547 225 564 minecraft:white_stained_glass
setblock 556 224 557 minecraft:blue_concrete
setblock 559 224 563 minecraft:white_stained_glass
fill 517 225 565 517 227 565 minecraft:white_concrete
fill 517 225 581 517 225 582 minecraft:white_concrete
fill 517 225 597 517 227 597 minecraft:white_concrete
fill 521 225 557 521 227 557 minecraft:white_concrete
fill 531 225 557 531 244 557 minecraft:blue_concrete
fill 531 225 599 531 227 599 minecraft:white_concrete
fill 537 225 557 537 227 557 minecraft:white_concrete
setblock 537 225 599 minecraft:white_concrete
fill 547 225 599 547 227 599 minecraft:white_concrete
fill 553 225 557 553 227 557 minecraft:white_concrete
setblock 556 225 557 minecraft:white_concrete
fill 559 225 561 559 245 561 minecraft:blue_concrete
setblock 559 225 562 minecraft:sea_lantern
fill 559 225 563 559 234 563 minecraft:blue_concrete
fill 559 225 567 559 227 567 minecraft:white_concrete
setblock 559 225 571 minecraft:white_stained_glass
fill 559 225 583 559 227 583 minecraft:white_concrete
setblock 517 226 559 minecraft:white_concrete
fill 517 226 581 517 227 581 minecraft:white_concrete
fill 517 226 582 517 229 582 minecraft:blue_concrete
setblock 520 226 560 minecraft:light[level=14]
setblock 520 226 568 minecraft:light[level=14]
setblock 520 226 576 minecraft:light[level=14]
setblock 520 226 584 minecraft:light[level=14]
setblock 520 226 592 minecraft:light[level=14]
fill 521 226 571 522 227 571 minecraft:blue_concrete
setblock 528 226 557 minecraft:white_concrete
setblock 528 226 560 minecraft:light[level=14]
setblock 528 226 568 minecraft:light[level=14]
setblock 528 226 576 minecraft:light[level=14]
setblock 528 226 584 minecraft:light[level=14]
setblock 528 226 592 minecraft:light[level=14]
setblock 529 226 557 minecraft:blue_concrete
setblock 536 226 560 minecraft:light[level=14]
setblock 536 226 568 minecraft:light[level=14]
setblock 536 226 576 minecraft:light[level=14]
setblock 536 226 584 minecraft:light[level=14]
setblock 536 226 592 minecraft:light[level=14]
fill 537 226 599 537 242 599 minecraft:blue_concrete
setblock 544 226 560 minecraft:light[level=14]
setblock 544 226 568 minecraft:light[level=14]
setblock 544 226 576 minecraft:light[level=14]
setblock 544 226 584 minecraft:light[level=14]
fill 544 226 591 544 227 591 minecraft:white_stained_glass
setblock 544 226 592 minecraft:light[level=14]
fill 547 226 564 547 232 564 minecraft:black_concrete
setblock 552 226 560 minecraft:light[level=14]
setblock 552 226 568 minecraft:light[level=14]
setblock 552 226 576 minecraft:light[level=14]
setblock 552 226 584 minecraft:light[level=14]
setblock 552 226 592 minecraft:light[level=14]
fill 556 226 557 556 244 557 minecraft:blue_concrete
fill 559 226 562 559 244 562 minecraft:blue_concrete
fill 559 226 571 559 229 571 minecraft:blue_concrete
fill 517 227 559 517 244 559 minecraft:blue_concrete
fill 528 227 557 528 241 557 minecraft:blue_concrete
setblock 529 227 557 minecraft:white_stained_glass
setblock 535 227 557 minecraft:white_concrete
setblock 535 227 599 minecraft:sea_lantern
fill 536 227 557 536 244 557 minecraft:blue_concrete
fill 546 227 564 546 232 564 minecraft:black_concrete
setblock 547 227 557 minecraft:white_concrete
fill 547 227 565 547 232 565 minecraft:black_concrete
fill 517 228 565 517 233 565 minecraft:blue_concrete
setblock 517 228 578 minecraft:sea_lantern
fill 517 228 581 517 233 581 minecraft:blue_concrete
fill 517 228 597 517 233 597 minecraft:blue_concrete
fill 521 228 557 521 233 557 minecraft:blue_concrete
fill 529 228 557 529 230 557 minecraft:blue_concrete
fill 529 228 570 529 229 570 minecraft:blue_concrete
fill 531 228 599 531 233 599 minecraft:blue_concrete
fill 535 228 557 535 238 557 minecraft:blue_concrete
fill 535 228 599 535 244 599 minecraft:blue_concrete
fill 537 228 557 537 233 557 minecraft:blue_concrete
setblock 540 228 599 minecraft:sea_lantern
fill 544 228 591 544 235 591 minecraft:black_concrete
fill 546 228 563 547 232 563 minecraft:black_concrete
fill 546 228 565 546 232 565 minecraft:black_concrete
fill 547 228 557 547 241 557 minecraft:blue_concrete
fill 547 228 599 547 233 599 minecraft:blue_concrete
fill 548 228 564 548 232 564 minecraft:black_concrete
fill 553 228 557 553 233 557 minecraft:blue_concrete
setblock 558 228 557 minecraft:white_concrete
fill 559 228 567 559 233 567 minecraft:blue_concrete
fill 559 228 583 559 231 583 minecraft:blue_concrete
fill 517 229 578 517 230 578 minecraft:blue_concrete
setblock 517 229 584 minecraft:white_concrete
setblock 524 229 557 minecraft:sea_lantern
fill 540 229 599 540 245 599 minecraft:blue_concrete
fill 545 229 564 545 232 565 minecraft:black_concrete
fill 546 229 566 547 232 566 minecraft:black_concrete
fill 548 229 563 548 232 563 minecraft:black_concrete
fill 548 229 565 548 232 565 minecraft:black_concrete
fill 558 229 557 558 244 557 minecraft:blue_concrete
setblock 559 229 560 minecraft:white_concrete
setblock 559 229 569 minecraft:white_stained_glass
setblock 517 230 562 minecraft:white_concrete
fill 517 230 563 517 242 564 minecraft:blue_concrete
setblock 517 230 582 minecraft:white_concrete
fill 517 230 584 517 244 584 minecraft:blue_concrete
setblock 517 230 590 minecraft:white_stained_glass
setblock 517 230 593 minecraft:sea_lantern
fill 524 230 557 524 235 557 minecraft:blue_concrete
fill 543 230 591 543 235 591 minecraft:black_concrete
fill 544 230 592 544 235 592 minecraft:black_concrete
fill 545 230 563 545 232 563 minecraft:black_concrete
fill 545 230 591 545 235 591 minecraft:black_concrete
setblock 546 230 557 minecraft:sea_lantern
fill 546 230 562 547 232 562 minecraft:black_concrete
fill 548 230 566 548 232 566 minecraft:black_concrete
fill 549 230 564 549 232 564 minecraft:black_concrete
fill 559 230 560 559 244 560 minecraft:blue_concrete
fill 559 230 569 559 244 569 minecraft:blue_concrete
setblock 559 230 571 minecraft:white_stained_glass
fill 517 231 562 517 236 562 minecraft:blue_concrete
setblock 517 231 578 minecraft:white_stained_glass
fill 517 231 582 517 242 582 minecraft:blue_concrete
fill 517 231 590 517 244 590 minecraft:blue_concrete
fill 517 231 593 517 237 593 minecraft:blue_concrete
setblock 529 231 557 minecraft:sea_lantern
setblock 530 231 557 minecraft:white_stained_glass
fill 543 231 590 545 235 590 minecraft:black_concrete
fill 543 231 592 543 235 592 minecraft:black_concrete
fill 544 231 564 544 232 565 minecraft:black_concrete
fill 545 231 562 545 232 562 minecraft:black_concrete
fill 545 231 566 545 232 566 minecraft:black_concrete
fill 545 231 592 545 235 592 minecraft:black_concrete
fill 546 231 557 546 244 557 minecraft:blue_concrete
fill 547 231 567 547 232 567 minecraft:black_concrete
fill 548 231 562 548 232 562 minecraft:black_concrete
setblock 548 231 599 minecraft:sea_lantern
fill 549 231 563 549 232 563 minecraft:black_concrete
fill 549 231 565 549 232 565 minecraft:black_concrete
setblock 559 231 564 minecraft:white_concrete
fill 559 231 565 559 235 565 minecraft:blue_concrete
fill 559 231 571 559 244 571 minecraft:blue_concrete
fill 517 232 557 517 244 557 minecraft:blue_concrete
setblock 517 232 558 minecraft:sea_lantern
fill 517 232 578 517 244 578 minecraft:blue_concrete
fill 529 232 557 530 244 557 minecraft:blue_concrete
fill 539 232 557 540 242 557 minecraft:blue_concrete
setblock 541 232 557 minecraft:white_concrete
fill 542 232 591 542 235 591 minecraft:black_concrete
fill 543 232 593 545 235 593 minecraft:black_concrete
setblock 544 232 563 minecraft:black_concrete
setblock 544 232 566 minecraft:black_concrete
fill 545 232 567 546 232 567 minecraft:black_concrete
fill 546 232 561 547 232 561 minecraft:black_concrete
fill 546 232 591 546 235 591 minecraft:black_concrete
setblock 548 232 567 minecraft:black_concrete
fill 548 232 599 548 238 599 minecraft:blue_concrete
setblock 549 232 562 minecraft:black_concrete
setblock 549 232 566 minecraft:black_concrete
setblock 551 232 557 minecraft:sea_lantern
fill 559 232 564 559 244 564 minecraft:blue_concrete
setblock 559 232 573 minecraft:white_stained_glass
setblock 559 232 583 minecraft:sea_lantern
setblock 559 232 592 minecraft:sea_lantern
fill 517 233 558 517 242 558 minecraft:blue_concrete
fill 541 233 557 541 235 557 minecraft:blue_concrete
fill 542 233 590 542 235 590 minecraft:black_concrete
fill 542 233 592 542 235 592 minecraft:black_concrete
fill 543 233 589 545 235 589 minecraft:black_concrete
fill 545 233 564 545 235 564 minecraft:obsidian
fill 546 233 590 546 235 590 minecraft:black_concrete
fill 546 233 592 546 235 592 minecraft:black_concrete
fill 547 233 566 547 235 566 minecraft:obsidian
fill 548 233 563 548 236 563 minecraft:obsidian
fill 551 233 557 551 244 557 minecraft:blue_concrete
fill 559 233 573 559 244 573 minecraft:blue_concrete
setblock 559 233 583 minecraft:blue_concrete
fill 559 233 592 559 240 592 minecraft:blue_concrete
setblock 559 233 597 minecraft:white_concrete
fill 517 234 565 517 236 565 minecraft:white_concrete
fill 517 234 581 517 236 581 minecraft:white_concrete
fill 517 234 597 517 236 597 minecraft:white_concrete
setblock 520 234 560 minecraft:light[level=14]
setblock 520 234 568 minecraft:light[level=14]
setblock 520 234 576 minecraft:light[level=14]
setblock 520 234 584 minecraft:light[level=14]
setblock 520 234 592 minecraft:light[level=14]
fill 521 234 557 521 236 557 minecraft:white_concrete
setblock 528 234 560 minecraft:light[level=14]
setblock 528 234 568 minecraft:light[level=14]
setblock 528 234 576 minecraft:light[level=14]
setblock 528 234 584 minecraft:light[level=14]
setblock 528 234 592 minecraft:light[level=14]
fill 531 234 599 531 236 599 minecraft:white_concrete
setblock 536 234 560 minecraft:light[level=14]
setblock 536 234 568 minecraft:light[level=14]
setblock 536 234 576 minecraft:light[level=14]
setblock 536 234 584 minecraft:light[level=14]
setblock 536 234 592 minecraft:light[level=14]
fill 537 234 557 537 236 557 minecraft:white_concrete
fill 541 234 591 541 235 591 minecraft:black_concrete
fill 542 234 589 542 235 589 minecraft:black_concrete
fill 542 234 593 542 235 593 minecraft:black_concrete
setblock 543 234 557 minecraft:white_stained_glass
fill 543 234 594 545 235 594 minecraft:black_concrete
setblock 544 234 560 minecraft:light[level=14]
setblock 544 234 568 minecraft:light[level=14]
setblock 544 234 576 minecraft:light[level=14]
setblock 544 234 584 minecraft:light[level=14]
fill 546 234 589 546 235 589 minecraft:black_concrete
fill 546 234 593 546 235 593 minecraft:black_concrete
fill 547 234 599 547 236 599 minecraft:white_concrete
setblock 552 234 560 minecraft:light[level=14]
setblock 552 234 568 minecraft:light[level=14]
setblock 552 234 576 minecraft:light[level=14]
setblock 552 234 584 minecraft:light[level=14]
setblock 552 234 592 minecraft:light[level=14]
fill 553 234 557 553 236 557 minecraft:white_concrete
fill 559 234 567 559 236 567 minecraft:white_concrete
fill 559 234 583 559 236 583 minecraft:white_concrete
fill 559 234 597 559 245 597 minecraft:blue_concrete
setblock 517 235 580 minecraft:white_concrete
setblock 538 235 599 minecraft:white_concrete
setblock 541 235 590 minecraft:black_concrete
fill 541 235 592 541 235 593 minecraft:black_concrete
setblock 542 235 594 minecraft:black_concrete
fill 543 235 557 543 244 557 minecraft:blue_concrete
fill 543 235 588 545 235 588 minecraft:black_concrete
setblock 546 235 594 minecraft:black_concrete
fill 547 235 590 547 235 592 minecraft:black_concrete
setblock 559 235 563 minecraft:sea_lantern
fill 517 236 580 517 242 580 minecraft:blue_concrete
setblock 517 236 596 minecraft:white_concrete
setblock 524 236 557 minecraft:white_concrete
fill 538 236 599 538 244 599 minecraft:blue_concrete
setblock 541 236 557 minecraft:white_stained_glass
fill 542 236 591 542 238 591 minecraft:obsidian
fill 545 236 590 545 238 590 minecraft:obsidian
fill 545 236 593 545 237 593 minecraft:obsidian
fill 559 236 563 559 245 563 minecraft:blue_concrete
setblock 559 236 565 minecraft:white_stained_glass
setblock 559 236 577 minecraft:sea_lantern
setblock 559 236 598 minecraft:white_stained_glass
setblock 517 237 562 minecraft:white_stained_glass
fill 517 237 565 517 244 565 minecraft:blue_concrete
fill 517 237 581 517 240 581 minecraft:blue_concrete
fill 517 237 596 517 244 597 minecraft:blue_concrete
fill 521 237 557 521 240 557 minecraft:blue_concrete
fill 521 237 576 522 238 577 minecraft:obsidian
fill 523 237 577 523 238 577 minecraft:obsidian
fill 524 237 557 524 241 557 minecraft:blue_concrete
setblock 531 237 599 minecraft:blue_concrete
fill 537 237 557 537 244 557 minecraft:blue_concrete
fill 541 237 557 541 244 557 minecraft:blue_concrete
fill 547 237 599 547 244 599 minecraft:blue_concrete
fill 553 237 557 553 244 557 minecraft:blue_concrete
fill 559 237 565 559 244 565 minecraft:blue_concrete
fill 559 237 567 559 241 567 minecraft:blue_concrete
fill 559 237 577 559 244 577 minecraft:blue_concrete
fill 559 237 583 559 244 583 minecraft:blue_concrete
fill 559 237 598 559 240 598 minecraft:blue_concrete
fill 517 238 562 517 242 562 minecraft:blue_concrete
setblock 517 238 593 minecraft:white_concrete
setblock 517 238 598 minecraft:sea_lantern
setblock 529 238 599 minecraft:sea_lantern
setblock 531 238 599 minecraft:white_concrete
setblock 559 238 596 minecraft:white_concrete
setblock 517 239 579 minecraft:sea_lantern
fill 517 239 593 517 244 593 minecraft:blue_concrete
fill 517 239 598 517 244 598 minecraft:blue_concrete
fill 520 239 599 520 240 599 minecraft:blue_concrete
setblock 521 239 599 minecraft:sea_lantern
setblock 524 239 599 minecraft:sea_lantern
fill 529 239 599 529 244 599 minecraft:blue_concrete
fill 531 239 599 531 244 599 minecraft:blue_concrete
setblock 535 239 557 minecraft:white_concrete
setblock 548 239 599 minecraft:white_stained_glass
setblock 559 239 585 minecraft:white_stained_glass
fill 559 239 596 559 244 596 minecraft:blue_concrete
fill 517 240 579 517 244 579 minecraft:blue_concrete
fill 521 240 599 521 245 599 minecraft:blue_concrete
fill 524 240 599 524 244 599 minecraft:blue_concrete
setblock 527 240 557 minecraft:white_concrete
setblock 533 240 599 minecraft:sea_lantern
fill 535 240 557 535 244 557 minecraft:blue_concrete
fill 548 240 599 548 246 599 minecraft:blue_concrete
setblock 559 240 559 minecraft:white_concrete
setblock 559 240 585 minecraft:blue_concrete
setblock 559 240 586 minecraft:white_concrete
setblock 559 240 595 minecraft:white_concrete
setblock 517 241 567 minecraft:sea_lantern
setblock 517 241 569 minecraft:white_stained_glass
setblock 517 241 570 minecraft:black_concrete
fill 517 241 571 517 244 571 minecraft:blue_concrete
setblock 517 241 572 minecraft:black_concrete
setblock 517 241 581 minecraft:black_concrete
setblock 517 241 595 minecraft:sea_lantern
setblock 518 241 599 minecraft:black_concrete
fill 519 241 599 519 244 599 minecraft:blue_concrete
fill 520 241 599 520 242 599 minecraft:black_concrete
setblock 521 241 557 minecraft:black_concrete
setblock 525 241 557 minecraft:white_concrete
fill 527 241 557 527 242 557 minecraft:blue_concrete
fill 533 241 599 533 244 599 minecraft:blue_concrete
setblock 542 241 557 minecraft:black_concrete
setblock 544 241 557 minecraft:black_concrete
setblock 546 241 599 minecraft:black_concrete
setblock 552 241 557 minecraft:black_concrete
setblock 559 241 558 minecraft:black_concrete
fill 559 241 559 559 244 559 minecraft:blue_concrete
setblock 559 241 568 minecraft:black_concrete
setblock 559 241 575 minecraft:black_concrete
fill 559 241 585 559 241 586 minecraft:black_concrete
setblock 559 241 588 minecraft:white_concrete
setblock 559 241 592 minecraft:black_concrete
fill 559 241 595 559 244 595 minecraft:blue_concrete
setblock 559 241 598 minecraft:black_concrete
setblock 517 242 561 minecraft:black_concrete
fill 517 242 567 517 243 567 minecraft:blue_concrete
setblock 517 242 569 minecraft:black_concrete
fill 517 242 570 517 245 570 minecraft:blue_concrete
fill 517 242 572 517 244 572 minecraft:blue_concrete
setblock 517 242 574 minecraft:white_concrete
fill 517 242 581 517 244 581 minecraft:blue_concrete
fill 517 242 595 517 244 595 minecraft:blue_concrete
fill 518 242 599 518 244 599 minecraft:blue_concrete
setblock 520 242 557 minecraft:black_concrete
setblock 520 242 560 minecraft:light[level=14]
setblock 520 242 568 minecraft:light[level=14]
setblock 520 242 576 minecraft:light[level=14]
setblock 520 242 584 minecraft:light[level=14]
setblock 520 242 592 minecraft:light[level=14]
fill 521 242 557 521 244 557 minecraft:blue_concrete
setblock 523 242 557 minecraft:black_concrete
setblock 524 242 557 minecraft:white_stained_glass
fill 525 242 557 525 244 557 minecraft:blue_concrete
fill 528 242 557 528 243 557 minecraft:black_concrete
setblock 528 242 560 minecraft:light[level=14]
setblock 528 242 568 minecraft:light[level=14]
setblock 528 242 576 minecraft:light[level=14]
setblock 528 242 584 minecraft:light[level=14]
setblock 528 242 592 minecraft:light[level=14]
setblock 536 242 560 minecraft:light[level=14]
setblock 536 242 568 minecraft:light[level=14]
setblock 536 242 576 minecraft:light[level=14]
setblock 536 242 584 minecraft:light[level=14]
setblock 536 242 592 minecraft:light[level=14]
fill 542 242 557 542 244 557 minecraft:blue_concrete
fill 544 242 557 544 244 557 minecraft:blue_concrete
setblock 544 242 560 minecraft:light[level=14]
setblock 544 242 568 minecraft:light[level=14]
setblock 544 242 576 minecraft:light[level=14]
setblock 544 242 584 minecraft:light[level=14]
setblock 544 242 592 minecraft:light[level=14]
setblock 545 242 599 minecraft:black_concrete
fill 546 242 599 546 244 599 minecraft:blue_concrete
setblock 547 242 557 minecraft:black_concrete
setblock 551 242 599 minecraft:sea_lantern
fill 552 242 557 552 244 557 minecraft:blue_concrete
setblock 552 242 560 minecraft:light[level=14]
setblock 552 242 568 minecraft:light[level=14]
setblock 552 242 576 minecraft:light[level=14]
setblock 552 242 584 minecraft:light[level=14]
setblock 552 242 592 minecraft:light[level=14]
fill 554 242 557 554 244 557 minecraft:blue_concrete
setblock 555 242 557 minecraft:sea_lantern
fill 559 242 558 559 244 558 minecraft:blue_concrete
setblock 559 242 567 minecraft:sea_lantern
fill 559 242 568 559 244 568 minecraft:blue_concrete
setblock 559 242 570 minecraft:black_concrete
fill 559 242 575 559 244 575 minecraft:blue_concrete
fill 559 242 581 559 243 581 minecraft:black_concrete
fill 559 242 585 559 244 585 minecraft:blue_concrete
setblock 559 242 586 minecraft:black_concrete
fill 559 242 588 559 244 588 minecraft:blue_concrete
setblock 559 242 591 minecraft:black_concrete
fill 559 242 592 559 244 592 minecraft:blue_concrete
fill 559 242 598 559 244 598 minecraft:blue_concrete
setblock 517 243 558 minecraft:black_concrete
setblock 517 243 561 minecraft:blue_concrete
fill 517 243 562 517 243 563 minecraft:black_concrete
fill 517 243 564 517 244 564 minecraft:blue_concrete
fill 517 243 569 517 244 569 minecraft:blue_concrete
fill 517 243 574 517 246 574 minecraft:blue_concrete
setblock 517 243 580 minecraft:black_concrete
setblock 517 243 582 minecraft:black_concrete
setblock 517 243 589 minecraft:black_concrete
fill 520 243 557 520 245 557 minecraft:blue_concrete
fill 520 243 599 520 246 599 minecraft:blue_concrete
setblock 522 243 599 minecraft:black_concrete
fill 523 243 557 524 244 557 minecraft:blue_concrete
setblock 526 243 599 minecraft:black_concrete
setblock 527 243 557 minecraft:black_concrete
fill 533 243 573 535 243 575 minecraft:redstone_block
fill 533 243 581 535 243 583 minecraft:redstone_block
setblock 537 243 599 minecraft:black_concrete
setblock 538 243 557 minecraft:black_concrete
fill 539 243 557 539 244 557 minecraft:blue_concrete
setblock 540 243 557 minecraft:black_concrete
fill 540 243 574 542 243 576 minecraft:redstone_block
fill 540 243 580 542 243 582 minecraft:redstone_block
fill 545 243 599 545 244 599 minecraft:blue_concrete
fill 547 243 557 547 244 557 minecraft:blue_concrete
setblock 551 243 599 minecraft:blue_concrete
setblock 553 243 599 minecraft:black_concrete
fill 555 243 557 555 244 557 minecraft:blue_concrete
setblock 557 243 557 minecraft:black_concrete
fill 559 243 567 559 245 567 minecraft:blue_concrete
fill 559 243 570 559 244 570 minecraft:blue_concrete
setblock 559 243 572 minecraft:black_concrete
setblock 559 243 578 minecraft:black_concrete
setblock 559 243 579 minecraft:sea_lantern
setblock 559 243 580 minecraft:black_concrete
setblock 559 243 586 minecraft:blue_concrete
fill 559 243 589 559 243 590 minecraft:black_concrete
fill 559 243 591 559 244 591 minecraft:blue_concrete
setblock 517 244 558 minecraft:blue_concrete
setblock 517 244 561 minecraft:white_concrete
fill 517 244 562 517 244 563 minecraft:blue_concrete
setblock 517 244 567 minecraft:white_stained_glass
setblock 517 244 580 minecraft:blue_concrete
fill 517 244 582 517 246 582 minecraft:blue_concrete
setblock 517 244 589 minecraft:blue_concrete
setblock 522 244 599 minecraft:blue_concrete
fill 525 244 569 531 244 572 minecraft:black_concrete
fill 525 244 584 531 244 587 minecraft:black_concrete
fill 526 244 573 532 244 574 minecraft:black_concrete
fill 526 244 582 532 244 583 minecraft:black_concrete
fill 526 244 599 526 245 599 minecraft:blue_concrete
fill 527 244 557 528 244 557 minecraft:blue_concrete
fill 527 244 575 532 244 575 minecraft:black_concrete
fill 527 244 581 532 244 581 minecraft:black_concrete
fill 528 244 576 539 244 576 minecraft:black_concrete
fill 528 244 580 539 244 580 minecraft:black_concrete
fill 529 244 577 535 244 577 minecraft:black_concrete
fill 529 244 579 535 244 579 minecraft:black_concrete
fill 530 244 578 535 244 578 minecraft:black_concrete
fill 532 244 570 533 244 572 minecraft:black_concrete
fill 532 244 584 533 244 586 minecraft:black_concrete
fill 534 244 571 543 244 572 minecraft:black_concrete
fill 534 244 584 543 244 585 minecraft:black_concrete
fill 536 244 568 543 244 570 minecraft:black_concrete
fill 536 244 573 539 244 575 minecraft:black_concrete
fill 536 244 581 539 244 583 minecraft:black_concrete
fill 536 244 586 543 244 588 minecraft:black_concrete
fill 537 244 567 543 245 567 minecraft:black_concrete
fill 537 244 589 543 245 589 minecraft:black_concrete
fill 537 244 599 537 245 599 minecraft:blue_concrete
setblock 538 244 557 minecraft:blue_concrete
fill 538 244 566 543 245 566 minecraft:black_concrete
fill 538 244 590 543 245 590 minecraft:black_concrete
fill 539 244 565 543 245 565 minecraft:black_concrete
fill 539 244 577 552 244 579 minecraft:black_concrete
fill 539 244 591 543 245 591 minecraft:black_concrete
setblock 540 244 557 minecraft:blue_concrete
fill 540 244 564 542 245 564 minecraft:black_concrete
fill 540 244 573 543 244 573 minecraft:black_concrete
fill 540 244 583 543 244 583 minecraft:black_concrete
fill 540 244 592 542 245 592 minecraft:black_concrete
fill 542 244 563 542 245 563 minecraft:black_concrete
fill 542 244 593 542 245 593 minecraft:black_concrete
fill 543 244 574 546 244 576 minecraft:black_concrete
fill 543 244 580 546 244 582 minecraft:black_concrete
fill 547 244 575 549 245 576 minecraft:black_concrete
fill 547 244 580 549 245 581 minecraft:black_concrete
fill 550 244 576 550 245 576 minecraft:black_concrete
fill 550 244 580 550 245 580 minecraft:black_concrete
setblock 551 244 599 minecraft:sea_lantern
fill 553 244 578 553 245 578 minecraft:black_concrete
setblock 553 244 599 minecraft:blue_concrete
setblock 557 244 557 minecraft:blue_concrete
setblock 559 244 572 minecraft:blue_concrete
fill 559 244 578 559 244 581 minecraft:blue_concrete
setblock 559 244 586 minecraft:white_concrete
fill 559 244 589 559 244 590 minecraft:blue_concrete
fill 517 245 557 517 245 569 minecraft:black_concrete
fill 517 245 571 517 246 573 minecraft:black_concrete
fill 517 245 575 517 306 575 minecraft:black_concrete
setblock 517 245 576 minecraft:blue_concrete
fill 517 245 577 517 269 580 minecraft:black_concrete
setblock 517 245 581 minecraft:white_concrete
fill 517 245 583 517 245 599 minecraft:black_concrete
fill 518 245 557 519 246 557 minecraft:black_concrete
fill 518 245 558 524 245 598 minecraft:obsidian
fill 518 245 599 519 246 599 minecraft:black_concrete
fill 521 245 557 525 245 557 minecraft:black_concrete
fill 522 245 599 522 282 599 minecraft:black_concrete
fill 524 245 599 525 246 599 minecraft:black_concrete
fill 525 245 558 535 245 568 minecraft:obsidian
fill 525 245 569 528 245 572 minecraft:black_concrete
fill 525 245 573 525 245 583 minecraft:obsidian
fill 525 245 584 528 245 587 minecraft:black_concrete
fill 525 245 588 535 245 598 minecraft:obsidian
fill 526 245 573 528 245 574 minecraft:black_concrete
fill 526 245 575 526 245 581 minecraft:obsidian
fill 526 245 582 528 245 583 minecraft:black_concrete
fill 527 245 557 529 246 557 minecraft:black_concrete
fill 527 245 575 528 245 575 minecraft:black_concrete
fill 527 245 576 527 245 580 minecraft:obsidian
fill 527 245 581 528 245 581 minecraft:black_concrete
fill 527 245 599 536 245 599 minecraft:black_concrete
fill 528 245 576 529 245 576 minecraft:black_concrete
fill 528 245 577 528 245 579 minecraft:obsidian
fill 528 245 580 529 245 580 minecraft:black_concrete
fill 529 245 569 531 245 571 minecraft:black_concrete
fill 529 245 572 531 245 575 minecraft:white_stained_glass
fill 529 245 577 530 245 577 minecraft:black_concrete
setblock 529 245 578 minecraft:obsidian
fill 529 245 579 530 245 579 minecraft:black_concrete
fill 529 245 581 531 245 584 minecraft:white_stained_glass
fill 529 245 585 531 245 587 minecraft:black_concrete
setblock 530 245 557 minecraft:blue_concrete
fill 530 245 576 531 245 576 minecraft:white_stained_glass
fill 530 245 578 531 245 578 minecraft:black_concrete
fill 530 245 580 531 245 580 minecraft:white_stained_glass
fill 531 245 557 538 245 557 minecraft:black_concrete
fill 531 245 577 533 245 577 minecraft:white_stained_glass
fill 531 245 579 533 245 579 minecraft:white_stained_glass
fill 532 245 569 535 245 569 minecraft:obsidian
fill 532 245 570 533 245 571 minecraft:black_concrete
fill 532 245 572 532 245 576 minecraft:sea_lantern
setblock 532 245 578 minecraft:white_stained_glass
fill 532 245 580 532 245 584 minecraft:sea_lantern
fill 532 245 585 533 245 586 minecraft:black_concrete
fill 532 245 587 535 245 587 minecraft:obsidian
fill 533 245 572 536 245 572 minecraft:sea_lantern
fill 533 245 573 535 245 575 minecraft:obsidian
fill 533 245 576 539 245 576 minecraft:sea_lantern
fill 533 245 578 535 245 578 minecraft:sea_lantern
fill 533 245 580 539 245 580 minecraft:sea_lantern
fill 533 245 581 535 245 583 minecraft:obsidian
fill 533 245 584 536 245 584 minecraft:sea_lantern
fill 534 245 570 535 245 570 minecraft:obsidian
fill 534 245 571 536 245 571 minecraft:black_concrete
fill 534 245 577 535 245 577 minecraft:sea_lantern
fill 534 245 579 535 245 579 minecraft:sea_lantern
fill 534 245 585 536 245 585 minecraft:black_concrete
fill 534 245 586 535 245 586 minecraft:obsidian
fill 536 245 558 536 245 567 minecraft:obsidian
fill 536 245 568 536 245 570 minecraft:black_concrete
fill 536 245 573 536 245 575 minecraft:sea_lantern
fill 536 245 581 536 245 583 minecraft:sea_lantern
fill 536 245 586 536 245 588 minecraft:black_concrete
fill 536 245 589 536 245 598 minecraft:obsidian
fill 537 245 558 537 245 566 minecraft:obsidian
fill 537 245 568 537 245 569 minecraft:black_concrete
fill 537 245 570 538 245 573 minecraft:white_stained_glass
fill 537 245 574 537 245 575 minecraft:sea_lantern
fill 537 245 581 537 245 582 minecraft:sea_lantern
fill 537 245 583 538 245 586 minecraft:white_stained_glass
fill 537 245 587 537 245 588 minecraft:black_concrete
fill 537 245 590 537 245 598 minecraft:obsidian
fill 538 245 558 538 245 565 minecraft:obsidian
fill 538 245 568 539 245 568 minecraft:black_concrete
fill 538 245 569 541 245 569 minecraft:white_stained_glass
setblock 538 245 574 minecraft:white_stained_glass
fill 538 245 575 539 245 575 minecraft:sea_lantern
fill 538 245 581 539 245 581 minecraft:sea_lantern
setblock 538 245 582 minecraft:white_stained_glass
fill 538 245 587 541 245 587 minecraft:white_stained_glass
fill 538 245 588 539 245 588 minecraft:black_concrete
fill 538 245 591 538 245 598 minecraft:obsidian
fill 538 245 599 539 245 599 minecraft:black_concrete
setblock 539 245 557 minecraft:white_stained_glass
fill 539 245 558 539 245 564 minecraft:obsidian
fill 539 245 570 541 245 572 minecraft:white_stained_glass
fill 539 245 573 539 245 574 minecraft:sea_lantern
fill 539 245 577 541 245 579 minecraft:sea_lantern
fill 539 245 582 539 245 583 minecraft:sea_lantern
fill 539 245 584 541 245 586 minecraft:white_stained_glass
fill 539 245 592 539 245 598 minecraft:obsidian
fill 540 245 557 544 249 557 minecraft:black_concrete
fill 540 245 558 541 245 563 minecraft:obsidian
setblock 540 245 568 minecraft:white_stained_glass
fill 540 245 573 543 245 573 minecraft:sea_lantern
fill 540 245 574 542 245 576 minecraft:obsidian
fill 540 245 580 542 245 582 minecraft:obsidian
fill 540 245 583 543 245 583 minecraft:sea_lantern
setblock 540 245 588 minecraft:white_stained_glass
fill 540 245 593 541 245 598 minecraft:obsidian
fill 541 245 568 543 245 568 minecraft:black_concrete
fill 541 245 588 543 245 588 minecraft:black_concrete
fill 541 245 599 547 246 599 minecraft:black_concrete
fill 542 245 558 558 245 562 minecraft:obsidian
fill 542 245 569 543 245 572 minecraft:black_concrete
fill 542 245 577 543 245 577 minecraft:sea_lantern
fill 542 245 578 548 245 578 minecraft:white_stained_glass
fill 542 245 579 543 245 579 minecraft:sea_lantern
fill 542 245 584 543 245 587 minecraft:black_concrete
fill 542 245 594 558 245 598 minecraft:obsidian
fill 543 245 563 558 245 564 minecraft:obsidian
fill 543 245 574 543 245 576 minecraft:sea_lantern
fill 543 245 580 543 245 582 minecraft:sea_lantern
fill 543 245 592 558 245 593 minecraft:obsidian
fill 544 245 565 558 245 573 minecraft:obsidian
fill 544 245 574 546 245 575 minecraft:black_concrete
fill 544 245 576 545 245 577 minecraft:white_stained_glass
fill 544 245 579 545 245 580 minecraft:white_stained_glass
fill 544 245 581 546 245 582 minecraft:black_concrete
fill 544 245 583 558 245 591 minecraft:obsidian
setblock 545 245 557 minecraft:white_stained_glass
fill 546 245 557 558 245 557 minecraft:black_concrete
setblock 546 245 576 minecraft:black_concrete
fill 546 245 577 547 245 577 minecraft:white_stained_glass
fill 546 245 579 547 245 579 minecraft:white_stained_glass
setblock 546 245 580 minecraft:black_concrete
fill 547 245 574 558 245 574 minecraft:obsidian
fill 547 245 582 558 245 582 minecraft:obsidian
fill 548 245 577 552 245 577 minecraft:black_concrete
fill 548 245 579 552 245 579 minecraft:black_concrete
fill 549 245 578 552 245 578 minecraft:black_concrete
fill 550 245 575 558 245 575 minecraft:obsidian
fill 550 245 581 558 245 581 minecraft:obsidian
fill 550 245 599 550 246 599 minecraft:black_concrete
fill 551 245 576 558 245 576 minecraft:obsidian
fill 551 245 580 558 245 580 minecraft:obsidian
setblock 551 245 599 minecraft:blue_concrete
fill 552 245 599 559 245 599 minecraft:black_concrete
fill 553 245 577 558 245 577 minecraft:obsidian
fill 553 245 579 558 245 579 minecraft:obsidian
fill 554 245 578 558 245 578 minecraft:obsidian
fill 559 245 558 559 246 559 minecraft:black_concrete
setblock 559 245 560 minecraft:sea_lantern
fill 559 245 562 559 247 562 minecraft:black_concrete
setblock 559 245 564 minecraft:white_concrete
fill 559 245 565 559 255 566 minecraft:black_concrete
fill 559 245 568 559 245 582 minecraft:black_concrete
setblock 559 245 583 minecraft:white_concrete
setblock 559 245 584 minecraft:white_stained_glass
fill 559 245 585 559 245 596 minecraft:black_concrete
fill 559 245 598 559 307 598 minecraft:black_concrete
fill 517 246 557 517 246 559 minecraft:black_concrete
setblock 517 246 560 minecraft:blue_concrete
fill 517 246 561 517 250 564 minecraft:black_concrete
setblock 517 246 565 minecraft:blue_concrete
fill 517 246 566 517 264 570 minecraft:black_concrete
fill 517 246 576 517 259 576 minecraft:black_concrete
fill 517 246 581 517 251 581 minecraft:black_concrete
setblock 517 246 583 minecraft:blue_concrete
fill 517 246 584 517 246 586 minecraft:black_concrete
setblock 517 246 587 minecraft:blue_concrete
fill 517 246 588 517 257 592 minecraft:black_concrete
setblock 517 246 593 minecraft:blue_concrete
fill 517 246 594 517 251 599 minecraft:black_concrete
fill 520 246 557 521 251 557 minecraft:black_concrete
fill 521 246 599 521 257 599 minecraft:black_concrete
setblock 522 246 557 minecraft:blue_concrete
setblock 523 246 557 minecraft:black_concrete
setblock 524 246 557 minecraft:sea_lantern
fill 525 246 557 526 262 557 minecraft:black_concrete
fill 526 246 599 528 246 599 minecraft:black_concrete
fill 529 246 599 530 246 599 minecraft:blue_concrete
fill 530 246 557 533 248 557 minecraft:black_concrete
fill 531 246 599 538 246 599 minecraft:black_concrete
fill 534 246 557 534 247 557 minecraft:blue_concrete
fill 535 246 557 536 284 557 minecraft:black_concrete
setblock 537 246 557 minecraft:blue_concrete
fill 538 246 557 538 307 557 minecraft:black_concrete
setblock 539 246 557 minecraft:blue_concrete
setblock 539 246 599 minecraft:blue_concrete
fill 540 246 599 540 262 599 minecraft:black_concrete
setblock 545 246 557 minecraft:sea_lantern
setblock 546 246 557 minecraft:blue_concrete
fill 547 246 557 549 257 557 minecraft:black_concrete
fill 549 246 599 549 299 599 minecraft:black_concrete
fill 550 246 557 551 246 557 minecraft:blue_concrete
fill 551 246 599 552 284 599 minecraft:black_concrete
fill 552 246 557 555 247 557 minecraft:black_concrete
setblock 553 246 599 minecraft:blue_concrete
fill 554 246 599 558 252 599 minecraft:black_concrete
setblock 556 246 557 minecraft:sea_lantern
fill 557 246 557 559 269 557 minecraft:black_concrete
fill 559 246 560 559 256 561 minecraft:black_concrete
fill 559 246 563 559 283 564 minecraft:black_concrete
fill 559 246 567 559 251 568 minecraft:black_concrete
setblock 559 246 569 minecraft:white_concrete
fill 559 246 570 559 246 575 minecraft:black_concrete
fill 559 246 576 559 246 577 minecraft:blue_concrete
fill 559 246 578 559 246 584 minecraft:black_concrete
setblock 559 246 585 minecraft:sea_lantern
fill 559 246 586 559 246 593 minecraft:black_concrete
setblock 559 246 594 minecraft:blue_concrete
fill 559 246 595 559 251 597 minecraft:black_concrete
setblock 559 246 599 minecraft:blue_concrete
fill 517 247 557 517 247 558 minecraft:blue_concrete
fill 517 247 559 517 263 560 minecraft:black_concrete
fill 517 247 565 517 251 565 minecraft:black_concrete
fill 517 247 571 517 293 572 minecraft:black_concrete
setblock 517 247 573 minecraft:sea_lantern
fill 517 247 574 517 291 574 minecraft:black_concrete
fill 517 247 582 517 260 584 minecraft:black_concrete
setblock 517 247 585 minecraft:blue_concrete
fill 517 247 586 517 250 587 minecraft:black_concrete
fill 517 247 593 517 292 593 minecraft:black_concrete
fill 518 247 557 518 262 557 minecraft:black_concrete
fill 518 247 599 518 298 599 minecraft:black_concrete
setblock 519 247 557 minecraft:blue_concrete
setblock 519 247 599 minecraft:blue_concrete
fill 520 247 599 520 307 599 minecraft:black_concrete
fill 522 247 557 522 266 557 minecraft:black_concrete
setblock 523 247 557 minecraft:white_stained_glass
fill 524 247 557 524 261 557 minecraft:black_concrete
fill 524 247 599 524 258 599 minecraft:black_concrete
fill 525 247 599 526 247 599 minecraft:blue_concrete
setblock 527 247 557 minecraft:blue_concrete
fill 527 247 599 529 251 599 minecraft:black_concrete
fill 528 247 557 529 307 557 minecraft:black_concrete
setblock 530 247 599 minecraft:blue_concrete
fill 531 247 599 531 251 599 minecraft:black_concrete
setblock 532 247 599 minecraft:sea_lantern
fill 533 247 599 539 253 599 minecraft:black_concrete
fill 537 247 557 537 251 557 minecraft:black_concrete
fill 539 247 557 539 307 557 minecraft:black_concrete
fill 541 247 599 544 259 599 minecraft:black_concrete
fill 545 247 557 546 272 557 minecraft:black_concrete
setblock 545 247 599 minecraft:blue_concrete
fill 546 247 599 548 251 599 minecraft:black_concrete
fill 550 247 557 551 254 557 minecraft:black_concrete
setblock 550 247 599 minecraft:blue_concrete
fill 553 247 599 553 249 599 minecraft:black_concrete
fill 556 247 557 556 303 557 minecraft:black_concrete
setblock 559 247 558 minecraft:blue_concrete
fill 559 247 559 559 307 559 minecraft:black_concrete
fill 559 247 569 559 260 569 minecraft:black_concrete
setblock 559 247 570 minecraft:blue_concrete
fill 559 247 571 559 267 580 minecraft:black_concrete
setblock 559 247 581 minecraft:blue_concrete
fill 559 247 582 559 247 588 minecraft:black_concrete
setblock 559 247 589 minecraft:sea_lantern
fill 559 247 590 559 257 592 minecraft:black_concrete
setblock 559 247 593 minecraft:white_concrete
fill 559 247 594 559 307 594 minecraft:black_concrete
fill 559 247 599 559 307 599 minecraft:black_concrete
fill 517 248 557 517 250 558 minecraft:black_concrete
fill 517 248 573 517 300 573 minecraft:black_concrete
fill 517 248 585 517 253 585 minecraft:black_concrete
fill 519 248 557 519 260 557 minecraft:black_concrete
fill 519 248 599 519 273 599 minecraft:black_concrete
fill 523 248 557 523 307 557 minecraft:black_concrete
fill 523 248 599 523 278 599 minecraft:black_concrete
fill 525 248 599 526 255 599 minecraft:black_concrete
fill 527 248 557 527 307 557 minecraft:black_concrete
fill 530 248 599 530 280 599 minecraft:black_concrete
fill 532 248 599 532 264 599 minecraft:black_concrete
fill 534 248 557 534 278 557 minecraft:black_concrete
fill 545 248 599 545 283 599 minecraft:black_concrete
setblock 550 248 599 minecraft:white_concrete
setblock 552 248 557 minecraft:sea_lantern
fill 553 248 557 555 251 557 minecraft:black_concrete
fill 559 248 558 559 249 558 minecraft:black_concrete
setblock 559 248 562 minecraft:sea_lantern
fill 559 248 570 559 307 570 minecraft:black_concrete
fill 559 248 581 559 250 582 minecraft:black_concrete
setblock 559 248 583 minecraft:white_concrete
fill 559 248 584 559 252 589 minecraft:black_concrete
fill 559 248 593 559 307 593 minecraft:black_concrete
fill 528 249 591 528 256 591 minecraft:black_concrete
setblock 530 249 557 minecraft:sea_lantern
fill 531 249 557 533 302 557 minecraft:black_concrete
fill 546 249 565 547 256 565 minecraft:black_concrete
fill 548 249 586 551 254 588 minecraft:black_concrete
fill 549 249 589 551 254 589 minecraft:black_concrete
fill 550 249 585 550 254 585 minecraft:black_concrete
fill 550 249 599 550 253 599 minecraft:black_concrete
fill 552 249 557 552 252 557 minecraft:black_concrete
fill 552 249 587 552 254 587 minecraft:black_concrete
fill 559 249 562 559 307 562 minecraft:black_concrete
fill 559 249 583 559 251 583 minecraft:black_concrete
setblock 520 250 560 minecraft:light[level=14]
setblock 520 250 568 minecraft:light[level=14]
setblock 520 250 576 minecraft:light[level=14]
setblock 520 250 584 minecraft:light[level=14]
setblock 520 250 592 minecraft:light[level=14]
setblock 528 250 560 minecraft:light[level=14]
setblock 528 250 568 minecraft:light[level=14]
setblock 528 250 576 minecraft:light[level=14]
setblock 528 250 584 minecraft:light[level=14]
setblock 528 250 592 minecraft:light[level=14]
fill 530 250 557 530 253 557 minecraft:black_concrete
setblock 536 250 560 minecraft:light[level=14]
setblock 536 250 568 minecraft:light[level=14]
setblock 536 250 576 minecraft:light[level=14]
setblock 536 250 584 minecraft:light[level=14]
setblock 536 250 592 minecraft:light[level=14]
fill 540 250 557 542 262 557 minecraft:black_concrete
setblock 543 250 557 minecraft:white_concrete
fill 544 250 557 544 307 557 minecraft:black_concrete
setblock 544 250 560 minecraft:light[level=14]
setblock 544 250 568 minecraft:light[level=14]
setblock 544 250 576 minecraft:light[level=14]
setblock 544 250 584 minecraft:light[level=14]
setblock 544 250 592 minecraft:light[level=14]
fill 546 250 566 547 256 566 minecraft:black_concrete
fill 549 250 585 549 254 585 minecraft:black_concrete
fill 551 250 585 551 254 585 minecraft:black_concrete
setblock 552 250 560 minecraft:light[level=14]
setblock 552 250 568 minecraft:light[level=14]
setblock 552 250 576 minecraft:light[level=14]
setblock 552 250 584 minecraft:light[level=14]
fill 552 250 586 552 254 586 minecraft:black_concrete
fill 552 250 588 552 254 588 minecraft:black_concrete
setblock 552 250 592 minecraft:light[level=14]
setblock 553 250 599 minecraft:sea_lantern
setblock 559 250 558 minecraft:white_concrete
fill 517 251 557 517 307 557 minecraft:black_concrete
setblock 517 251 558 minecraft:sea_lantern
fill 517 251 561 517 252 563 minecraft:black_concrete
setblock 517 251 564 minecraft:white_stained_glass
fill 517 251 586 517 283 586 minecraft:black_concrete
setblock 517 251 587 minecraft:white_concrete
fill 527 251 590 527 256 591 minecraft:black_concrete
fill 528 251 590 528 256 590 minecraft:black_concrete
fill 528 251 592 528 256 592 minecraft:black_concrete
fill 529 251 591 529 256 591 minecraft:black_concrete
fill 543 251 557 543 258 557 minecraft:black_concrete
fill 545 251 565 545 256 566 minecraft:black_concrete
fill 546 251 564 547 256 564 minecraft:black_concrete
fill 547 251 586 547 254 588 minecraft:black_concrete
fill 548 251 565 548 256 566 minecraft:black_concrete
fill 548 251 585 548 254 585 minecraft:black_concrete
fill 548 251 589 548 254 589 minecraft:black_concrete
fill 549 251 590 551 254 590 minecraft:black_concrete
fill 550 251 584 550 254 584 minecraft:black_concrete
fill 552 251 585 552 254 585 minecraft:black_concrete
fill 552 251 589 552 254 589 minecraft:black_concrete
fill 553 251 587 553 254 587 minecraft:black_concrete
fill 553 251 599 553 291 599 minecraft:black_concrete
fill 559 251 558 559 300 558 minecraft:black_concrete
fill 559 251 581 559 302 581 minecraft:black_concrete
setblock 559 251 582 minecraft:sea_lantern
fill 517 252 558 517 265 558 minecraft:black_concrete
fill 517 252 564 517 298 564 minecraft:black_concrete
fill 517 252 565 517 254 565 minecraft:white_concrete
fill 517 252 581 517 254 581 minecraft:white_concrete
fill 517 252 587 517 277 587 minecraft:black_concrete
fill 517 252 594 517 257 596 minecraft:black_concrete
fill 517 252 597 517 254 597 minecraft:white_concrete
fill 517 252 598 517 252 599 minecraft:black_concrete
fill 520 252 557 520 259 557 minecraft:black_concrete
fill 521 252 557 521 254 557 minecraft:white_concrete
fill 527 252 592 527 256 592 minecraft:black_concrete
fill 527 252 599 528 257 599 minecraft:black_concrete
fill 529 252 590 529 256 590 minecraft:black_concrete
fill 529 252 592 529 256 592 minecraft:black_concrete
setblock 529 252 599 minecraft:white_stained_glass
fill 531 252 599 531 254 599 minecraft:white_concrete
fill 537 252 557 537 254 557 minecraft:white_concrete
fill 545 252 564 545 256 564 minecraft:black_concrete
fill 546 252 567 547 256 567 minecraft:black_concrete
fill 546 252 599 546 274 599 minecraft:black_concrete
fill 547 252 585 547 254 585 minecraft:black_concrete
fill 547 252 589 547 254 589 minecraft:black_concrete
fill 547 252 599 547 254 599 minecraft:white_concrete
fill 548 252 564 548 256 564 minecraft:black_concrete
fill 548 252 584 549 254 584 minecraft:black_concrete
fill 548 252 590 548 254 590 minecraft:black_concrete
fill 548 252 599 548 265 599 minecraft:black_concrete
fill 551 252 584 551 254 584 minecraft:black_concrete
fill 552 252 590 552 254 590 minecraft:black_concrete
fill 553 252 557 553 254 557 minecraft:white_concrete
fill 553 252 586 553 254 586 minecraft:black_concrete
fill 553 252 588 553 254 589 minecraft:black_concrete
fill 554 252 557 555 305 557 minecraft:black_concrete
fill 559 252 567 559 254 567 minecraft:white_concrete
fill 559 252 568 559 274 568 minecraft:black_concrete
fill 559 252 582 559 307 582 minecraft:black_concrete
fill 559 252 583 559 254 583 minecraft:white_concrete
setblock 559 252 595 minecraft:white_stained_glass
fill 559 252 596 559 307 597 minecraft:black_concrete
fill 517 253 561 517 307 561 minecraft:black_concrete
setblock 517 253 562 minecraft:white_concrete
fill 517 253 563 517 286 563 minecraft:black_concrete
setblock 517 253 598 minecraft:white_stained_glass
fill 517 253 599 517 307 599 minecraft:black_concrete
fill 526 253 590 526 256 591 minecraft:black_concrete
fill 527 253 589 528 256 589 minecraft:black_concrete
fill 529 253 599 529 307 599 minecraft:black_concrete
fill 544 253 565 544 256 566 minecraft:black_concrete
fill 545 253 567 545 256 567 minecraft:black_concrete
fill 546 253 563 547 256 563 minecraft:black_concrete
fill 546 253 586 546 254 588 minecraft:black_concrete
fill 547 253 590 547 254 590 minecraft:black_concrete
fill 548 253 567 548 256 567 minecraft:black_concrete
fill 549 253 565 549 256 566 minecraft:black_concrete
fill 549 253 591 551 254 591 minecraft:black_concrete
fill 550 253 583 550 254 583 minecraft:black_concrete
setblock 552 253 557 minecraft:white_stained_glass
fill 552 253 584 552 254 584 minecraft:black_concrete
fill 553 253 585 553 254 585 minecraft:black_concrete
fill 554 253 587 554 254 587 minecraft:black_concrete
fill 554 253 599 554 307 599 minecraft:black_concrete
setblock 555 253 599 minecraft:white_concrete
fill 556 253 599 558 291 599 minecraft:black_concrete
fill 559 253 584 559 254 588 minecraft:black_concrete
setblock 559 253 589 minecraft:sea_lantern
fill 559 253 595 559 269 595 minecraft:black_concrete
fill 517 254 562 517 286 562 minecraft:black_concrete
setblock 517 254 585 minecraft:sea_lantern
fill 517 254 598 517 280 598 minecraft:black_concrete
fill 525 254 590 525 254 591 minecraft:obsidian
fill 526 254 592 526 256 592 minecraft:black_concrete
fill 527 254 593 529 256 593 minecraft:black_concrete
fill 529 254 589 529 256 589 minecraft:black_concrete
setblock 530 254 557 minecraft:white_stained_glass
fill 530 254 590 530 256 592 minecraft:black_concrete
fill 533 254 599 538 265 599 minecraft:black_concrete
fill 534 254 562 535 255 563 minecraft:white_concrete
setblock 539 254 599 minecraft:white_concrete
fill 544 254 564 544 256 564 minecraft:black_concrete
fill 544 254 567 544 256 567 minecraft:black_concrete
fill 545 254 563 545 256 563 minecraft:black_concrete
fill 545 254 568 548 256 568 minecraft:black_concrete
setblock 546 254 585 minecraft:black_concrete
setblock 546 254 589 minecraft:black_concrete
setblock 547 254 584 minecraft:black_concrete
fill 548 254 563 548 256 563 minecraft:black_concrete
fill 548 254 583 549 254 583 minecraft:black_concrete
setblock 548 254 591 minecraft:black_concrete
fill 549 254 564 549 256 564 minecraft:black_concrete
fill 549 254 567 549 256 567 minecraft:black_concrete
setblock 550 254 599 minecraft:sea_lantern
fill 551 254 583 552 254 583 minecraft:black_concrete
fill 552 254 557 552 283 557 minecraft:black_concrete
setblock 552 254 591 minecraft:black_concrete
setblock 553 254 584 minecraft:black_concrete
setblock 553 254 590 minecraft:black_concrete
fill 554 254 585 554 254 586 minecraft:black_concrete
fill 554 254 588 554 254 589 minecraft:black_concrete
fill 555 254 599 555 274 599 minecraft:black_concrete
fill 559 254 589 559 281 589 minecraft:black_concrete
fill 517 255 565 517 260 565 minecraft:black_concrete
fill 517 255 581 517 260 581 minecraft:black_concrete
fill 517 255 585 517 273 585 minecraft:black_concrete
fill 517 255 597 517 260 597 minecraft:black_concrete
fill 521 255 557 521 260 557 minecraft:black_concrete
fill 525 255 590 525 256 591 minecraft:black_concrete
fill 526 255 589 526 256 589 minecraft:black_concrete
fill 526 255 593 526 256 593 minecraft:black_concrete
fill 527 255 588 529 256 588 minecraft:black_concrete
fill 530 255 557 530 307 557 minecraft:black_concrete
fill 530 255 589 530 256 589 minecraft:black_concrete
setblock 531 255 599 minecraft:white_stained_glass
fill 537 255 557 537 260 557 minecraft:black_concrete
fill 539 255 599 539 307 599 minecraft:black_concrete
fill 543 255 565 543 256 566 minecraft:black_concrete
fill 544 255 563 544 256 563 minecraft:black_concrete
fill 546 255 562 547 256 562 minecraft:black_concrete
fill 547 255 599 547 260 599 minecraft:black_concrete
fill 548 255 588 548 256 588 minecraft:obsidian
fill 549 255 563 549 256 563 minecraft:black_concrete
setblock 550 255 557 minecraft:sea_lantern
fill 550 255 565 550 256 566 minecraft:black_concrete
fill 550 255 585 550 256 585 minecraft:obsidian
fill 550 255 599 550 264 599 minecraft:black_concrete
fill 551 255 557 551 287 557 minecraft:black_concrete
fill 551 255 588 551 258 588 minecraft:obsidian
fill 553 255 557 553 260 557 minecraft:black_concrete
fill 559 255 567 559 260 567 minecraft:black_concrete
fill 559 255 583 559 260 584 minecraft:black_concrete
setblock 559 255 585 minecraft:sea_lantern
fill 559 255 586 559 272 588 minecraft:black_concrete
setblock 525 256 589 minecraft:black_concrete
setblock 525 256 592 minecraft:black_concrete
setblock 525 256 599 minecraft:white_stained_glass
setblock 526 256 588 minecraft:black_concrete
setblock 526 256 599 minecraft:black_concrete
fill 527 256 594 529 256 594 minecraft:black_concrete
setblock 530 256 593 minecraft:black_concrete
fill 531 256 590 531 256 592 minecraft:black_concrete
fill 531 256 599 531 260 599 minecraft:black_concrete
setblock 543 256 564 minecraft:black_concrete
setblock 543 256 567 minecraft:black_concrete
setblock 544 256 568 minecraft:black_concrete
setblock 545 256 562 minecraft:black_concrete
fill 545 256 569 548 256 569 minecraft:black_concrete
setblock 548 256 562 minecraft:black_concrete
setblock 549 256 568 minecraft:black_concrete
fill 550 256 557 550 274 557 minecraft:black_concrete
setblock 550 256 564 minecraft:black_concrete
setblock 550 256 567 minecraft:black_concrete
fill 559 256 565 559 301 565 minecraft:black_concrete
setblock 559 256 566 minecraft:sea_lantern
fill 559 256 585 559 307 585 minecraft:black_concrete
fill 525 257 599 525 272 599 minecraft:black_concrete
setblock 526 257 599 minecraft:sea_lantern
fill 527 257 589 527 260 589 minecraft:obsidian
fill 527 257 592 527 260 592 minecraft:obsidian
fill 529 257 591 529 258 591 minecraft:obsidian
fill 538 257 565 538 258 565 minecraft:white_stained_glass
fill 543 257 584 543 258 585 minecraft:blue_concrete
fill 545 257 565 545 261 565 minecraft:obsidian
fill 546 257 571 548 258 571 minecraft:obsidian
fill 547 257 564 547 260 564 minecraft:obsidian
fill 547 257 567 547 260 567 minecraft:obsidian
fill 547 257 570 547 258 570 minecraft:obsidian
fill 547 257 572 547 258 572 minecraft:obsidian
setblock 559 257 560 minecraft:white_stained_glass
fill 559 257 561 559 307 561 minecraft:black_concrete
fill 559 257 566 559 307 566 minecraft:black_concrete
fill 517 258 588 517 259 589 minecraft:black_concrete
setblock 517 258 590 minecraft:white_concrete
fill 517 258 591 517 266 592 minecraft:black_concrete
fill 517 258 594 517 307 595 minecraft:black_concrete
setblock 517 258 596 minecraft:white_concrete
setblock 520 258 560 minecraft:light[level=14]
setblock 520 258 568 minecraft:light[level=14]
setblock 520 258 576 minecraft:light[level=14]
setblock 520 258 584 minecraft:light[level=14]
setblock 520 258 592 minecraft:light[level=14]
setblock 521 258 599 minecraft:white_stained_glass
fill 526 258 599 526 268 599 minecraft:black_concrete
setblock 527 258 599 minecraft:white_stained_glass
setblock 528 258 560 minecraft:light[level=14]
setblock 528 258 568 minecraft:light[level=14]
setblock 528 258 576 minecraft:light[level=14]
setblock 528 258 584 minecraft:light[level=14]
setblock 528 258 592 minecraft:light[level=14]
fill 528 258 599 528 307 599 minecraft:black_concrete
setblock 536 258 560 minecraft:light[level=14]
setblock 536 258 568 minecraft:light[level=14]
setblock 536 258 576 minecraft:light[level=14]
setblock 536 258 584 minecraft:light[level=14]
setblock 536 258 592 minecraft:light[level=14]
setblock 544 258 560 minecraft:light[level=14]
setblock 544 258 568 minecraft:light[level=14]
setblock 544 258 576 minecraft:light[level=14]
setblock 544 258 584 minecraft:light[level=14]
setblock 544 258 592 minecraft:light[level=14]
fill 547 258 557 547 286 557 minecraft:black_concrete
setblock 548 258 557 minecraft:white_stained_glass
fill 549 258 557 549 303 557 minecraft:black_concrete
setblock 552 258 560 minecraft:light[level=14]
setblock 552 258 568 minecraft:light[level=14]
setblock 552 258 576 minecraft:light[level=14]
fill 552 258 578 554 259 578 minecraft:blue_concrete
setblock 552 258 584 minecraft:light[level=14]
setblock 552 258 592 minecraft:light[level=14]
fill 553 258 577 553 259 577 minecraft:blue_concrete
fill 553 258 579 553 259 579 minecraft:blue_concrete
fill 559 258 560 559 282 560 minecraft:black_concrete
fill 559 258 590 559 280 591 minecraft:black_concrete
setblock 559 258 592 minecraft:white_stained_glass
fill 517 259 590 517 307 590 minecraft:black_concrete
fill 517 259 596 517 265 596 minecraft:black_concrete
fill 521 259 599 521 307 599 minecraft:black_concrete
setblock 524 259 599 minecraft:white_concrete
fill 527 259 599 527 290 599 minecraft:black_concrete
fill 538 259 565 538 266 565 minecraft:black_concrete
setblock 543 259 557 minecraft:sea_lantern
fill 548 259 557 548 277 557 minecraft:black_concrete
fill 549 259 569 551 264 571 minecraft:yellow_concrete
fill 550 259 572 550 264 572 minecraft:yellow_concrete
fill 552 259 570 552 264 571 minecraft:yellow_concrete
fill 559 259 592 559 307 592 minecraft:black_concrete
setblock 517 260 576 minecraft:sea_lantern
fill 517 260 588 517 268 588 minecraft:black_concrete
setblock 517 260 589 minecraft:white_concrete
setblock 520 260 557 minecraft:white_concrete
fill 524 260 599 524 275 599 minecraft:black_concrete
fill 537 260 565 537 266 566 minecraft:black_concrete
fill 538 260 566 538 266 566 minecraft:black_concrete
fill 541 260 599 543 272 599 minecraft:black_concrete
fill 543 260 557 543 284 557 minecraft:black_concrete
setblock 544 260 599 minecraft:sea_lantern
fill 548 260 569 548 263 571 minecraft:yellow_concrete
fill 549 260 568 552 263 568 minecraft:yellow_concrete
fill 549 260 572 549 263 572 minecraft:yellow_concrete
fill 551 260 572 552 263 572 minecraft:yellow_concrete
fill 552 260 569 552 263 569 minecraft:yellow_concrete
fill 553 260 570 553 263 570 minecraft:yellow_concrete
fill 517 261 565 517 263 565 minecraft:white_concrete
setblock 517 261 576 minecraft:white_concrete
fill 517 261 581 517 263 581 minecraft:white_concrete
setblock 517 261 582 minecraft:sea_lantern
fill 517 261 583 517 274 584 minecraft:black_concrete
fill 517 261 589 517 307 589 minecraft:black_concrete
fill 517 261 597 517 263 597 minecraft:white_concrete
setblock 519 261 557 minecraft:white_concrete
fill 520 261 557 520 307 557 minecraft:black_concrete
fill 521 261 557 521 263 557 minecraft:white_concrete
fill 531 261 599 531 263 599 minecraft:white_concrete
fill 537 261 557 537 263 557 minecraft:white_concrete
fill 537 261 564 538 266 564 minecraft:black_concrete
fill 539 261 565 539 266 565 minecraft:black_concrete
fill 544 261 599 544 307 599 minecraft:black_concrete
fill 547 261 599 547 263 599 minecraft:white_concrete
fill 548 261 572 548 262 572 minecraft:yellow_concrete
fill 549 261 573 551 262 573 minecraft:yellow_concrete
fill 553 261 557 553 263 557 minecraft:white_concrete
fill 553 261 569 553 262 569 minecraft:yellow_concrete
fill 553 261 571 553 262 571 minecraft:yellow_concrete
fill 559 261 567 559 263 567 minecraft:white_concrete
setblock 559 261 569 minecraft:sea_lantern
fill 559 261 583 559 263 583 minecraft:white_concrete
fill 559 261 584 559 307 584 minecraft:black_concrete
fill 517 262 576 517 307 576 minecraft:black_concrete
fill 517 262 582 517 290 582 minecraft:black_concrete
fill 519 262 557 519 294 557 minecraft:black_concrete
setblock 524 262 557 minecraft:white_stained_glass
fill 536 262 565 536 266 566 minecraft:black_concrete
fill 537 262 567 538 266 567 minecraft:black_concrete
fill 539 262 564 539 266 564 minecraft:black_concrete
fill 539 262 566 539 266 566 minecraft:black_concrete
fill 551 262 580 552 263 581 minecraft:blue_concrete
fill 553 262 580 553 263 580 minecraft:blue_concrete
fill 559 262 569 559 274 569 minecraft:black_concrete
setblock 518 263 557 minecraft:white_stained_glass
fill 524 263 557 524 307 557 minecraft:black_concrete
setblock 525 263 557 minecraft:white_concrete
fill 526 263 557 526 271 557 minecraft:black_concrete
fill 536 263 564 536 266 564 minecraft:black_concrete
fill 536 263 567 536 266 567 minecraft:black_concrete
fill 537 263 563 538 266 563 minecraft:black_concrete
fill 539 263 567 539 266 567 minecraft:black_concrete
fill 540 263 557 541 266 557 minecraft:black_concrete
fill 540 263 565 540 266 566 minecraft:black_concrete
setblock 540 263 599 minecraft:white_stained_glass
setblock 542 263 557 minecraft:white_stained_glass
fill 517 264 559 517 307 559 minecraft:black_concrete
setblock 517 264 560 minecraft:white_stained_glass
fill 517 264 565 517 269 565 minecraft:black_concrete
fill 517 264 581 517 269 581 minecraft:black_concrete
fill 517 264 597 517 269 597 minecraft:black_concrete
fill 518 264 557 518 306 557 minecraft:black_concrete
fill 521 264 557 521 269 557 minecraft:black_concrete
fill 525 264 557 525 265 557 minecraft:black_concrete
fill 531 264 599 531 269 599 minecraft:black_concrete
fill 535 264 565 535 266 566 minecraft:black_concrete
fill 536 264 563 536 266 563 minecraft:black_concrete
fill 537 264 557 537 269 557 minecraft:black_concrete
fill 537 264 568 538 266 568 minecraft:black_concrete
fill 539 264 563 539 266 563 minecraft:black_concrete
fill 540 264 564 540 266 564 minecraft:black_concrete
fill 540 264 567 540 266 567 minecraft:black_concrete
fill 540 264 599 540 265 599 minecraft:black_concrete
fill 542 264 557 542 270 557 minecraft:black_concrete
setblock 547 264 599 minecraft:black_concrete
fill 553 264 557 553 269 557 minecraft:black_concrete
fill 559 264 567 559 269 567 minecraft:black_concrete
fill 559 264 583 559 267 583 minecraft:black_concrete
fill 517 265 560 517 307 560 minecraft:black_concrete
fill 517 265 566 517 280 566 minecraft:black_concrete
fill 517 265 567 517 266 567 minecraft:white_stained_glass
fill 517 265 568 517 268 570 minecraft:black_concrete
fill 522 265 571 523 266 572 minecraft:obsidian
fill 524 265 572 524 266 572 minecraft:obsidian
setblock 532 265 599 minecraft:sea_lantern
fill 535 265 564 535 266 564 minecraft:black_concrete
fill 535 265 567 535 266 567 minecraft:black_concrete
fill 536 265 568 536 266 568 minecraft:black_concrete
fill 537 265 562 538 266 562 minecraft:black_concrete
fill 539 265 568 539 266 568 minecraft:black_concrete
fill 540 265 563 540 266 563 minecraft:black_concrete
fill 541 265 565 541 266 565 minecraft:black_concrete
setblock 547 265 599 minecraft:white_stained_glass
setblock 550 265 599 minecraft:white_concrete
setblock 517 266 558 minecraft:white_stained_glass
setblock 517 266 596 minecraft:sea_lantern
setblock 520 266 560 minecraft:light[level=14]
setblock 520 266 568 minecraft:light[level=14]
setblock 520 266 576 minecraft:light[level=14]
setblock 520 266 584 minecraft:light[level=14]
setblock 520 266 592 minecraft:light[level=14]
setblock 525 266 557 minecraft:white_concrete
setblock 528 266 560 minecraft:light[level=14]
setblock 528 266 568 minecraft:light[level=14]
setblock 528 266 576 minecraft:light[level=14]
setblock 528 266 584 minecraft:light[level=14]
setblock 528 266 592 minecraft:light[level=14]
fill 532 266 599 533 291 599 minecraft:black_concrete
fill 534 266 565 534 266 566 minecraft:black_concrete
setblock 534 266 599 minecraft:white_concrete
setblock 535 266 563 minecraft:black_concrete
setblock 535 266 568 minecraft:black_concrete
fill 535 266 599 538 267 599 minecraft:black_concrete
setblock 536 266 560 minecraft:light[level=14]
setblock 536 266 562 minecraft:black_concrete
setblock 536 266 576 minecraft:light[level=14]
setblock 536 266 584 minecraft:light[level=14]
setblock 536 266 592 minecraft:light[level=14]
fill 537 266 569 538 266 569 minecraft:black_concrete
setblock 539 266 562 minecraft:black_concrete
setblock 540 266 568 minecraft:black_concrete
setblock 540 266 599 minecraft:sea_lantern
setblock 541 266 564 minecraft:black_concrete
fill 541 266 566 541 266 567 minecraft:black_concrete
setblock 544 266 560 minecraft:light[level=14]
setblock 544 266 568 minecraft:light[level=14]
setblock 544 266 576 minecraft:light[level=14]
setblock 544 266 584 minecraft:light[level=14]
setblock 544 266 592 minecraft:light[level=14]
fill 547 266 599 547 269 599 minecraft:black_concrete
setblock 548 266 599 minecraft:sea_lantern
fill 550 266 599 550 288 599 minecraft:black_concrete
setblock 552 266 560 minecraft:light[level=14]
setblock 552 266 568 minecraft:light[level=14]
setblock 552 266 576 minecraft:light[level=14]
setblock 552 266 584 minecraft:light[level=14]
setblock 552 266 592 minecraft:light[level=14]
fill 517 267 558 517 307 558 minecraft:black_concrete
fill 517 267 567 517 307 567 minecraft:black_concrete
setblock 517 267 591 minecraft:white_concrete
fill 517 267 592 517 307 592 minecraft:black_concrete
fill 517 267 596 517 307 596 minecraft:black_concrete
setblock 522 267 557 minecraft:white_concrete
fill 524 267 577 525 268 578 minecraft:obsidian
fill 525 267 557 525 307 557 minecraft:black_concrete
fill 534 267 599 534 296 599 minecraft:black_concrete
fill 536 267 566 536 269 566 minecraft:obsidian
fill 538 267 564 538 269 564 minecraft:obsidian
fill 539 267 566 539 268 566 minecraft:obsidian
setblock 540 267 557 minecraft:white_concrete
fill 540 267 599 540 307 599 minecraft:black_concrete
fill 541 267 557 541 276 557 minecraft:black_concrete
fill 548 267 599 548 284 599 minecraft:black_concrete
fill 517 268 591 517 293 591 minecraft:black_concrete
fill 522 268 557 522 281 557 minecraft:black_concrete
fill 535 268 599 535 282 599 minecraft:black_concrete
setblock 536 268 599 minecraft:sea_lantern
fill 537 268 599 538 307 599 minecraft:black_concrete
fill 540 268 557 540 294 557 minecraft:black_concrete
fill 555 268 570 555 269 570 minecraft:white_concrete
fill 559 268 571 559 307 571 minecraft:black_concrete
setblock 559 268 572 minecraft:white_concrete
setblock 559 268 573 minecraft:white_stained_glass
fill 559 268 574 559 280 580 minecraft:black_concrete
setblock 559 268 583 minecraft:white_concrete
setblock 517 269 568 minecraft:sea_lantern
fill 517 269 569 517 287 570 minecraft:black_concrete
setblock 517 269 588 minecraft:sea_lantern
setblock 526 269 599 minecraft:sea_lantern
setblock 536 269 599 minecraft:black_concrete
fill 559 269 572 559 283 573 minecraft:black_concrete
setblock 559 269 583 minecraft:black_concrete
fill 517 270 565 517 272 565 minecraft:white_concrete
fill 517 270 568 517 279 568 minecraft:black_concrete
fill 517 270 577 517 277 579 minecraft:black_concrete
setblock 517 270 580 minecraft:sea_lantern
fill 517 270 581 517 272 581 minecraft:white_concrete
fill 517 270 588 517 290 588 minecraft:black_concrete
fill 517 270 597 517 272 597 minecraft:white_concrete
fill 521 270 557 521 272 557 minecraft:white_concrete
fill 526 270 599 526 278 599 minecraft:black_concrete
fill 531 270 599 531 272 599 minecraft:white_concrete
setblock 536 270 599 minecraft:sea_lantern
fill 537 270 557 537 272 557 minecraft:white_concrete
fill 547 270 599 547 272 599 minecraft:white_concrete
fill 553 270 557 553 272 557 minecraft:white_concrete
fill 557 270 557 557 289 557 minecraft:black_concrete
setblock 558 270 557 minecraft:white_concrete
fill 559 270 557 559 307 557 minecraft:black_concrete
fill 559 270 567 559 272 567 minecraft:white_concrete
fill 559 270 583 559 272 583 minecraft:white_concrete
setblock 559 270 595 minecraft:white_concrete
fill 517 271 580 517 284 580 minecraft:black_concrete
fill 536 271 599 536 285 599 minecraft:black_concrete
setblock 542 271 557 minecraft:white_stained_glass
fill 558 271 557 558 273 557 minecraft:black_concrete
fill 559 271 595 559 307 595 minecraft:black_concrete
setblock 526 272 557 minecraft:white_stained_glass
fill 542 272 557 542 290 557 minecraft:black_concrete
fill 551 272 590 552 273 591 minecraft:blue_concrete
fill 517 273 565 517 286 565 minecraft:black_concrete
fill 517 273 581 517 287 581 minecraft:black_concrete
fill 517 273 597 517 287 597 minecraft:black_concrete
fill 521 273 557 521 287 557 minecraft:black_concrete
setblock 525 273 599 minecraft:white_stained_glass
fill 526 273 557 526 291 557 minecraft:black_concrete
setblock 531 273 599 minecraft:white_stained_glass
fill 537 273 557 537 287 557 minecraft:black_concrete
fill 541 273 599 541 288 599 minecraft:black_concrete
setblock 542 273 599 minecraft:white_concrete
fill 543 273 599 543 302 599 minecraft:black_concrete
setblock 545 273 557 minecraft:white_stained_glass
fill 546 273 557 546 307 557 minecraft:black_concrete
fill 547 273 599 547 287 599 minecraft:black_concrete
fill 553 273 557 553 287 557 minecraft:black_concrete
fill 559 273 567 559 287 567 minecraft:black_concrete
fill 559 273 583 559 287 583 minecraft:black_concrete
fill 559 273 586 559 291 587 minecraft:black_concrete
setblock 559 273 588 minecraft:white_concrete
setblock 517 274 585 minecraft:white_stained_glass
setblock 519 274 599 minecraft:white_stained_glass
setblock 520 274 560 minecraft:light[level=14]
setblock 520 274 568 minecraft:light[level=14]
setblock 520 274 576 minecraft:light[level=14]
setblock 520 274 584 minecraft:light[level=14]
setblock 520 274 592 minecraft:light[level=14]
fill 525 274 599 525 307 599 minecraft:black_concrete
setblock 528 274 560 minecraft:light[level=14]
setblock 528 274 568 minecraft:light[level=14]
setblock 528 274 576 minecraft:light[level=14]
setblock 528 274 584 minecraft:light[level=14]
setblock 528 274 592 minecraft:light[level=14]
fill 531 274 599 531 282 599 minecraft:black_concrete
setblock 536 274 560 minecraft:light[level=14]
setblock 536 274 568 minecraft:light[level=14]
setblock 536 274 576 minecraft:light[level=14]
setblock 536 274 584 minecraft:light[level=14]
setblock 536 274 592 minecraft:light[level=14]
fill 542 274 599 542 307 599 minecraft:black_concrete
setblock 544 274 560 minecraft:light[level=14]
setblock 544 274 568 minecraft:light[level=14]
setblock 544 274 576 minecraft:light[level=14]
setblock 544 274 584 minecraft:light[level=14]
setblock 544 274 592 minecraft:light[level=14]
fill 545 274 557 545 300 557 minecraft:black_concrete
setblock 552 274 560 minecraft:light[level=14]
setblock 552 274 568 minecraft:light[level=14]
setblock 552 274 576 minecraft:light[level=14]
setblock 552 274 584 minecraft:light[level=14]
setblock 552 274 592 minecraft:light[level=14]
setblock 558 274 557 minecraft:white_stained_glass
fill 559 274 588 559 294 588 minecraft:black_concrete
fill 517 275 583 517 307 583 minecraft:black_concrete
setblock 517 275 584 minecraft:white_stained_glass
setblock 517 275 585 minecraft:black_concrete
fill 519 275 599 519 281 599 minecraft:black_concrete
setblock 546 275 599 minecraft:white_stained_glass
setblock 550 275 557 minecraft:sea_lantern
setblock 555 275 599 minecraft:white_concrete
schedule function dropper:buildpart/143_2 1t
