setblock 230 76 377 minecraft:green_concrete
setblock 230 76 379 minecraft:lime_terracotta
fill 230 76 380 230 79 381 minecraft:green_concrete
fill 230 76 382 230 77 383 minecraft:lime_terracotta
fill 230 76 388 230 76 389 minecraft:green_concrete
fill 230 76 390 230 76 391 minecraft:lime_terracotta
fill 230 76 392 230 77 392 minecraft:green_concrete
setblock 230 76 395 minecraft:moss_block
fill 230 76 400 230 79 401 minecraft:green_concrete
fill 230 76 402 230 77 403 minecraft:lime_terracotta
fill 230 76 409 230 79 409 minecraft:green_concrete
setblock 230 76 410 minecraft:lime_terracotta
setblock 188 77 369 minecraft:lime_terracotta
setblock 188 77 372 minecraft:moss_block
fill 188 77 373 188 79 374 minecraft:green_concrete
setblock 188 77 390 minecraft:lime_terracotta
setblock 188 77 392 minecraft:green_concrete
setblock 188 77 393 minecraft:lime_terracotta
fill 188 77 394 188 79 394 minecraft:green_concrete
setblock 188 77 401 minecraft:lime_terracotta
fill 188 77 403 188 80 403 minecraft:green_concrete
fill 188 77 405 188 79 405 minecraft:green_concrete
setblock 188 77 411 minecraft:green_concrete
setblock 192 77 369 minecraft:lime_terracotta
setblock 193 77 369 minecraft:moss_block
setblock 194 77 369 minecraft:green_concrete
fill 194 77 411 194 79 411 minecraft:green_concrete
fill 195 77 369 195 78 369 minecraft:moss_block
setblock 195 77 411 minecraft:moss_block
setblock 196 77 369 minecraft:green_concrete
fill 196 77 411 196 78 411 minecraft:green_concrete
fill 198 77 411 199 77 411 minecraft:lime_terracotta
fill 199 77 369 199 79 369 minecraft:green_concrete
setblock 200 77 369 minecraft:lime_terracotta
setblock 202 77 411 minecraft:lime_terracotta
setblock 203 77 369 minecraft:lime_terracotta
fill 203 77 411 203 79 411 minecraft:green_concrete
fill 207 77 369 207 78 369 minecraft:moss_block
setblock 207 77 411 minecraft:moss_block
setblock 208 77 411 minecraft:green_concrete
fill 209 77 369 210 77 369 minecraft:moss_block
fill 214 77 411 216 78 411 minecraft:green_concrete
fill 215 77 369 215 79 369 minecraft:green_concrete
fill 217 77 411 218 77 411 minecraft:moss_block
setblock 218 77 369 minecraft:moss_block
fill 219 77 369 220 79 369 minecraft:green_concrete
setblock 219 77 411 minecraft:lime_terracotta
setblock 224 77 369 minecraft:lime_terracotta
setblock 225 77 369 minecraft:green_concrete
fill 229 77 369 229 79 369 minecraft:green_concrete
setblock 230 77 369 minecraft:moss_block
setblock 230 77 374 minecraft:lime_terracotta
fill 230 77 375 230 79 375 minecraft:green_concrete
setblock 230 77 377 minecraft:moss_block
fill 230 77 379 230 80 379 minecraft:green_concrete
fill 230 77 388 230 80 388 minecraft:green_concrete
setblock 230 77 389 minecraft:moss_block
fill 230 77 390 230 79 390 minecraft:green_concrete
setblock 230 77 391 minecraft:lime_terracotta
fill 230 77 394 230 77 395 minecraft:lime_terracotta
setblock 230 77 404 minecraft:green_concrete
fill 230 77 405 230 77 406 minecraft:moss_block
fill 230 77 407 230 79 407 minecraft:green_concrete
fill 230 77 410 230 79 410 minecraft:green_concrete
setblock 230 77 411 minecraft:lime_terracotta
fill 188 78 369 188 79 370 minecraft:green_concrete
setblock 188 78 371 minecraft:lime_terracotta
fill 188 78 372 188 80 372 minecraft:green_concrete
fill 188 78 379 188 79 380 minecraft:lime_terracotta
fill 188 78 381 188 79 382 minecraft:green_concrete
fill 188 78 388 188 79 388 minecraft:lime_terracotta
fill 188 78 390 188 79 390 minecraft:green_concrete
fill 188 78 391 188 78 392 minecraft:lime_terracotta
fill 188 78 393 188 79 393 minecraft:green_concrete
fill 188 78 399 188 79 400 minecraft:lime_terracotta
fill 188 78 401 188 79 402 minecraft:green_concrete
setblock 188 78 409 minecraft:moss_block
fill 188 78 410 188 79 410 minecraft:green_concrete
fill 188 78 411 189 78 411 minecraft:lime_terracotta
fill 189 78 370 191 78 370 minecraft:mud
fill 189 78 372 189 78 374 minecraft:mud
fill 189 78 376 189 80 378 minecraft:mud
fill 189 78 380 189 78 382 minecraft:mud
fill 189 78 384 189 78 386 minecraft:mud
fill 189 78 388 189 78 390 minecraft:mud
fill 189 78 392 189 78 394 minecraft:mud
fill 189 78 396 189 78 398 minecraft:mud
fill 189 78 400 189 78 402 minecraft:mud
fill 189 78 404 189 78 406 minecraft:mud
fill 189 78 408 189 78 410 minecraft:mud
fill 190 78 377 192 133 379 minecraft:mud
fill 190 78 411 191 79 411 minecraft:green_concrete
fill 191 78 369 192 79 369 minecraft:green_concrete
fill 191 78 380 191 133 380 minecraft:mud
fill 191 78 410 193 78 410 minecraft:mud
fill 193 78 369 194 79 369 minecraft:lime_terracotta
fill 193 78 370 195 78 370 minecraft:mud
fill 195 78 410 197 78 410 minecraft:mud
fill 195 78 411 195 79 411 minecraft:green_concrete
setblock 196 78 369 minecraft:moss_block
fill 197 78 370 199 78 370 minecraft:mud
fill 197 78 411 197 79 411 minecraft:lime_terracotta
fill 198 78 411 199 79 411 minecraft:green_concrete
fill 199 78 410 201 78 410 minecraft:mud
fill 200 78 369 200 79 369 minecraft:green_concrete
setblock 200 78 411 minecraft:lime_terracotta
fill 201 78 369 202 78 369 minecraft:lime_terracotta
fill 201 78 370 203 78 370 minecraft:mud
fill 202 78 411 202 80 411 minecraft:green_concrete
fill 203 78 369 203 80 369 minecraft:green_concrete
fill 203 78 410 205 78 410 minecraft:mud
fill 204 78 411 205 79 411 minecraft:green_concrete
fill 205 78 369 205 79 369 minecraft:lime_terracotta
fill 205 78 370 207 78 370 minecraft:mud
setblock 206 78 411 minecraft:moss_block
fill 207 78 410 209 78 410 minecraft:mud
fill 207 78 411 207 79 411 minecraft:green_concrete
fill 208 78 369 212 79 369 minecraft:green_concrete
fill 208 78 411 209 79 411 minecraft:lime_terracotta
fill 209 78 370 211 78 370 minecraft:mud
fill 210 78 411 211 80 411 minecraft:green_concrete
fill 211 78 410 213 78 410 minecraft:mud
fill 213 78 369 214 79 369 minecraft:lime_terracotta
fill 213 78 370 215 78 370 minecraft:mud
fill 215 78 410 217 78 410 minecraft:mud
setblock 217 78 369 minecraft:moss_block
fill 217 78 370 219 78 370 minecraft:mud
fill 217 78 411 219 78 411 minecraft:green_concrete
fill 218 78 369 218 81 369 minecraft:green_concrete
fill 219 78 410 221 78 410 minecraft:mud
fill 220 78 411 221 78 411 minecraft:lime_terracotta
fill 221 78 370 223 78 370 minecraft:mud
setblock 222 78 369 minecraft:lime_terracotta
fill 222 78 411 222 79 411 minecraft:green_concrete
fill 223 78 369 224 79 369 minecraft:green_concrete
fill 223 78 410 225 78 410 minecraft:mud
setblock 223 78 411 minecraft:moss_block
fill 224 78 411 224 79 411 minecraft:green_concrete
fill 225 78 369 226 79 369 minecraft:lime_terracotta
fill 225 78 370 227 78 370 minecraft:mud
setblock 225 78 411 minecraft:moss_block
fill 226 78 411 226 79 411 minecraft:green_concrete
fill 227 78 410 229 78 410 minecraft:mud
setblock 227 78 411 minecraft:moss_block
fill 228 78 411 229 79 411 minecraft:lime_terracotta
fill 229 78 370 229 78 372 minecraft:mud
fill 229 78 374 229 78 376 minecraft:mud
fill 229 78 378 229 78 380 minecraft:mud
fill 229 78 382 229 78 384 minecraft:mud
fill 229 78 386 229 78 388 minecraft:mud
fill 229 78 390 229 78 392 minecraft:mud
fill 229 78 394 229 78 396 minecraft:mud
fill 229 78 398 229 78 400 minecraft:mud
fill 229 78 402 229 78 404 minecraft:mud
fill 229 78 406 229 78 408 minecraft:mud
fill 230 78 369 230 79 371 minecraft:green_concrete
fill 230 78 372 230 78 373 minecraft:lime_terracotta
fill 230 78 374 230 79 374 minecraft:green_concrete
setblock 230 78 377 minecraft:green_concrete
fill 230 78 382 230 79 383 minecraft:green_concrete
fill 230 78 384 230 79 385 minecraft:lime_terracotta
fill 230 78 386 230 79 386 minecraft:green_concrete
setblock 230 78 387 minecraft:moss_block
fill 230 78 389 230 79 389 minecraft:green_concrete
fill 230 78 391 230 80 391 minecraft:green_concrete
fill 230 78 392 230 78 393 minecraft:lime_terracotta
fill 230 78 394 230 79 395 minecraft:green_concrete
fill 230 78 396 230 79 396 minecraft:lime_terracotta
fill 230 78 397 230 78 398 minecraft:moss_block
fill 230 78 399 230 79 399 minecraft:green_concrete
fill 230 78 402 230 79 403 minecraft:green_concrete
fill 230 78 404 230 79 405 minecraft:lime_terracotta
fill 230 78 406 230 79 406 minecraft:green_concrete
fill 230 78 411 230 79 411 minecraft:green_concrete
setblock 188 79 371 minecraft:green_concrete
setblock 188 79 376 minecraft:lime_terracotta
setblock 188 79 387 minecraft:lime_terracotta
fill 188 79 391 188 79 392 minecraft:green_concrete
setblock 188 79 408 minecraft:lime_terracotta
setblock 188 79 409 minecraft:green_concrete
setblock 188 79 411 minecraft:lime_terracotta
fill 189 79 379 189 80 380 minecraft:mud
setblock 189 79 411 minecraft:green_concrete
fill 190 79 376 192 80 376 minecraft:mud
fill 190 79 380 190 80 380 minecraft:mud
setblock 191 79 372 minecraft:light[level=14]
setblock 191 79 388 minecraft:light[level=14]
setblock 191 79 396 minecraft:light[level=14]
setblock 191 79 404 minecraft:light[level=14]
fill 192 79 380 192 80 380 minecraft:mud
fill 193 79 377 193 80 379 minecraft:mud
fill 195 79 369 196 79 369 minecraft:green_concrete
setblock 196 79 411 minecraft:lime_terracotta
setblock 199 79 372 minecraft:light[level=14]
setblock 199 79 380 minecraft:light[level=14]
setblock 199 79 388 minecraft:light[level=14]
setblock 199 79 396 minecraft:light[level=14]
setblock 199 79 404 minecraft:light[level=14]
fill 200 79 411 200 80 411 minecraft:green_concrete
fill 201 79 369 202 79 369 minecraft:green_concrete
setblock 206 79 369 minecraft:lime_terracotta
setblock 206 79 411 minecraft:green_concrete
setblock 207 79 369 minecraft:green_concrete
setblock 207 79 372 minecraft:light[level=14]
setblock 207 79 380 minecraft:light[level=14]
setblock 207 79 388 minecraft:light[level=14]
setblock 207 79 396 minecraft:light[level=14]
setblock 207 79 404 minecraft:light[level=14]
fill 214 79 411 215 79 411 minecraft:green_concrete
setblock 215 79 372 minecraft:light[level=14]
setblock 215 79 380 minecraft:light[level=14]
setblock 215 79 388 minecraft:light[level=14]
setblock 215 79 396 minecraft:light[level=14]
setblock 215 79 404 minecraft:light[level=14]
fill 216 79 411 217 79 411 minecraft:lime_terracotta
setblock 217 79 369 minecraft:lime_terracotta
fill 218 79 411 219 79 411 minecraft:green_concrete
setblock 220 79 411 minecraft:lime_terracotta
setblock 221 79 411 minecraft:green_concrete
setblock 222 79 369 minecraft:green_concrete
setblock 223 79 372 minecraft:light[level=14]
setblock 223 79 380 minecraft:light[level=14]
setblock 223 79 388 minecraft:light[level=14]
setblock 223 79 396 minecraft:light[level=14]
setblock 223 79 404 minecraft:light[level=14]
setblock 223 79 411 minecraft:green_concrete
setblock 225 79 411 minecraft:green_concrete
setblock 227 79 411 minecraft:green_concrete
setblock 230 79 372 minecraft:green_concrete
setblock 230 79 373 minecraft:lime_terracotta
fill 230 79 376 230 79 377 minecraft:lime_terracotta
setblock 230 79 387 minecraft:green_concrete
fill 230 79 392 230 79 393 minecraft:green_concrete
setblock 230 79 397 minecraft:lime_terracotta
setblock 230 79 398 minecraft:green_concrete
setblock 230 79 408 minecraft:lime_terracotta
fill 188 80 369 188 80 371 minecraft:moss_block
fill 188 80 373 188 80 376 minecraft:moss_block
fill 188 80 377 188 80 378 minecraft:lime_terracotta
fill 188 80 379 188 80 384 minecraft:moss_block
fill 188 80 385 188 81 386 minecraft:lime_terracotta
fill 188 80 387 188 85 388 minecraft:moss_block
setblock 188 80 389 minecraft:lime_terracotta
fill 188 80 390 188 80 396 minecraft:moss_block
fill 188 80 397 188 81 398 minecraft:lime_terracotta
fill 188 80 399 188 81 400 minecraft:moss_block
setblock 188 80 401 minecraft:green_concrete
fill 188 80 402 188 83 402 minecraft:moss_block
fill 188 80 404 188 80 405 minecraft:moss_block
fill 188 80 406 188 81 406 minecraft:lime_terracotta
fill 188 80 408 188 85 408 minecraft:moss_block
fill 188 80 409 188 80 410 minecraft:lime_terracotta
fill 188 80 411 193 81 411 minecraft:moss_block
fill 189 80 369 190 81 369 minecraft:moss_block
fill 189 80 375 192 80 375 minecraft:mud
fill 189 80 381 193 80 381 minecraft:mud
setblock 191 80 369 minecraft:green_concrete
fill 192 80 369 194 80 369 minecraft:moss_block
setblock 193 80 376 minecraft:mud
setblock 193 80 380 minecraft:mud
fill 194 80 377 194 80 379 minecraft:mud
fill 194 80 411 195 81 411 minecraft:lime_terracotta
fill 195 80 369 196 81 369 minecraft:lime_terracotta
setblock 196 80 411 minecraft:green_concrete
fill 197 80 369 202 80 369 minecraft:moss_block
fill 197 80 411 198 81 411 minecraft:moss_block
fill 199 80 411 199 81 411 minecraft:green_concrete
fill 201 80 411 201 81 411 minecraft:moss_block
setblock 203 80 411 minecraft:moss_block
setblock 204 80 369 minecraft:lime_terracotta
setblock 204 80 411 minecraft:green_concrete
fill 205 80 369 206 85 369 minecraft:moss_block
fill 205 80 411 205 81 411 minecraft:moss_block
fill 206 80 411 207 80 411 minecraft:lime_terracotta
fill 207 80 369 208 81 369 minecraft:lime_terracotta
fill 208 80 411 209 81 411 minecraft:moss_block
fill 209 80 369 212 81 369 minecraft:moss_block
fill 212 80 411 212 81 411 minecraft:green_concrete
setblock 213 80 369 minecraft:green_concrete
fill 213 80 411 214 80 411 minecraft:moss_block
fill 214 80 369 214 85 369 minecraft:moss_block
fill 215 80 369 216 80 369 minecraft:lime_terracotta
fill 215 80 411 215 81 411 minecraft:lime_terracotta
fill 216 80 411 217 85 411 minecraft:moss_block
fill 217 80 369 217 85 369 minecraft:moss_block
setblock 218 80 411 minecraft:lime_terracotta
fill 219 80 369 224 80 369 minecraft:moss_block
fill 219 80 411 225 80 411 minecraft:moss_block
setblock 225 80 369 minecraft:green_concrete
fill 226 80 369 226 85 369 minecraft:moss_block
fill 226 80 411 227 81 411 minecraft:lime_terracotta
fill 227 80 369 228 81 369 minecraft:lime_terracotta
fill 228 80 411 228 85 411 minecraft:moss_block
fill 229 80 369 230 81 369 minecraft:moss_block
setblock 229 80 411 minecraft:green_concrete
fill 230 80 370 230 80 373 minecraft:moss_block
fill 230 80 374 230 80 375 minecraft:lime_terracotta
fill 230 80 376 230 80 377 minecraft:moss_block
fill 230 80 378 230 81 378 minecraft:lime_terracotta
fill 230 80 380 230 80 385 minecraft:moss_block
fill 230 80 386 230 81 387 minecraft:lime_terracotta
fill 230 80 389 230 80 390 minecraft:moss_block
fill 230 80 392 230 81 394 minecraft:moss_block
setblock 230 80 395 minecraft:lime_terracotta
fill 230 80 396 230 85 397 minecraft:moss_block
fill 230 80 398 230 81 399 minecraft:lime_terracotta
fill 230 80 400 230 80 405 minecraft:moss_block
fill 230 80 406 230 80 407 minecraft:lime_terracotta
fill 230 80 408 230 80 411 minecraft:moss_block
setblock 188 81 369 minecraft:green_concrete
fill 188 81 370 188 81 372 minecraft:moss_block
fill 188 81 373 188 81 374 minecraft:lime_terracotta
setblock 188 81 375 minecraft:green_concrete
fill 188 81 376 188 85 376 minecraft:moss_block
setblock 188 81 377 minecraft:lime_terracotta
fill 188 81 378 188 84 380 minecraft:moss_block
fill 188 81 381 188 82 381 minecraft:green_concrete
fill 188 81 382 188 81 384 minecraft:moss_block
fill 188 81 389 188 82 393 minecraft:moss_block
setblock 188 81 394 minecraft:lime_terracotta
fill 188 81 395 188 81 396 minecraft:moss_block
fill 188 81 401 188 83 401 minecraft:moss_block
fill 188 81 403 188 81 404 minecraft:moss_block
setblock 188 81 405 minecraft:lime_terracotta
setblock 188 81 407 minecraft:moss_block
fill 188 81 409 188 81 410 minecraft:moss_block
fill 189 81 378 189 133 378 minecraft:mud
fill 191 81 369 192 81 369 minecraft:moss_block
setblock 193 81 369 minecraft:green_concrete
fill 194 81 369 194 85 369 minecraft:moss_block
fill 196 81 411 196 85 411 minecraft:moss_block
fill 197 81 369 198 81 369 minecraft:moss_block
setblock 199 81 369 minecraft:lime_terracotta
fill 200 81 369 204 81 369 minecraft:moss_block
fill 200 81 411 200 82 411 minecraft:moss_block
fill 202 81 411 202 83 411 minecraft:moss_block
setblock 203 81 411 minecraft:lime_terracotta
setblock 204 81 411 minecraft:moss_block
setblock 206 81 411 minecraft:lime_terracotta
fill 207 81 411 207 84 411 minecraft:moss_block
fill 210 81 411 211 83 411 minecraft:moss_block
fill 213 81 369 213 85 369 minecraft:moss_block
setblock 213 81 411 minecraft:moss_block
setblock 214 81 411 minecraft:lime_terracotta
fill 215 81 369 215 84 369 minecraft:moss_block
setblock 216 81 369 minecraft:lime_terracotta
fill 218 81 411 219 83 411 minecraft:moss_block
fill 219 81 369 220 81 369 minecraft:lime_terracotta
setblock 220 81 411 minecraft:green_concrete
fill 221 81 369 225 81 369 minecraft:moss_block
fill 221 81 411 225 81 411 minecraft:moss_block
fill 229 81 411 229 85 411 minecraft:moss_block
setblock 230 81 370 minecraft:green_concrete
fill 230 81 371 230 81 375 minecraft:moss_block
setblock 230 81 376 minecraft:green_concrete
setblock 230 81 377 minecraft:moss_block
setblock 230 81 379 minecraft:lime_terracotta
fill 230 81 380 230 81 384 minecraft:moss_block
setblock 230 81 385 minecraft:green_concrete
fill 230 81 388 230 81 389 minecraft:moss_block
setblock 230 81 390 minecraft:lime_terracotta
fill 230 81 391 230 83 391 minecraft:moss_block
fill 230 81 395 230 83 395 minecraft:moss_block
setblock 230 81 400 minecraft:moss_block
setblock 230 81 401 minecraft:green_concrete
fill 230 81 402 230 82 406 minecraft:moss_block
setblock 230 81 407 minecraft:lime_terracotta
fill 230 81 408 230 81 409 minecraft:moss_block
setblock 230 81 410 minecraft:lime_terracotta
setblock 230 81 411 minecraft:green_concrete
fill 188 82 369 188 82 371 minecraft:moss_block
fill 188 82 372 188 83 372 minecraft:lime_terracotta
fill 188 82 373 188 87 374 minecraft:moss_block
setblock 188 82 375 minecraft:lime_terracotta
fill 188 82 377 188 87 377 minecraft:moss_block
fill 188 82 382 188 83 382 minecraft:moss_block
fill 188 82 383 188 83 384 minecraft:lime_terracotta
fill 188 82 385 188 87 386 minecraft:moss_block
fill 188 82 394 188 87 394 minecraft:moss_block
fill 188 82 395 188 82 396 minecraft:lime_terracotta
fill 188 82 397 188 85 399 minecraft:moss_block
setblock 188 82 400 minecraft:green_concrete
fill 188 82 403 188 83 404 minecraft:lime_terracotta
fill 188 82 405 188 87 406 minecraft:moss_block
setblock 188 82 407 minecraft:lime_terracotta
setblock 188 82 409 minecraft:green_concrete
fill 188 82 410 188 84 411 minecraft:moss_block
fill 189 82 369 190 83 369 minecraft:lime_terracotta
setblock 189 82 411 minecraft:green_concrete
fill 190 82 411 191 83 411 minecraft:moss_block
setblock 191 82 369 minecraft:green_concrete
fill 192 82 369 193 83 369 minecraft:moss_block
fill 192 82 411 193 83 411 minecraft:lime_terracotta
fill 194 82 411 195 87 411 minecraft:moss_block
fill 195 82 369 196 87 369 minecraft:moss_block
fill 197 82 369 198 82 369 minecraft:lime_terracotta
setblock 197 82 411 minecraft:green_concrete
fill 198 82 411 199 83 411 minecraft:moss_block
fill 199 82 369 203 82 369 minecraft:moss_block
fill 201 82 411 201 83 411 minecraft:lime_terracotta
fill 203 82 411 203 87 411 minecraft:moss_block
setblock 204 82 369 minecraft:green_concrete
fill 204 82 411 205 82 411 minecraft:lime_terracotta
fill 206 82 411 206 87 411 minecraft:moss_block
fill 207 82 369 207 87 369 minecraft:moss_block
setblock 208 82 369 minecraft:green_concrete
setblock 208 82 411 minecraft:green_concrete
fill 209 82 369 210 83 369 minecraft:lime_terracotta
fill 209 82 411 209 85 411 minecraft:moss_block
fill 211 82 369 212 83 369 minecraft:moss_block
fill 212 82 411 213 83 411 minecraft:lime_terracotta
setblock 214 82 411 minecraft:green_concrete
fill 215 82 411 215 87 411 minecraft:moss_block
fill 216 82 369 216 87 369 minecraft:moss_block
setblock 218 82 369 minecraft:lime_terracotta
fill 219 82 369 220 87 369 minecraft:moss_block
fill 220 82 411 223 82 411 minecraft:moss_block
fill 221 82 369 221 83 369 minecraft:lime_terracotta
fill 222 82 369 224 82 369 minecraft:moss_block
fill 224 82 411 225 82 411 minecraft:lime_terracotta
setblock 225 82 369 minecraft:green_concrete
fill 226 82 411 227 87 411 minecraft:moss_block
fill 227 82 369 228 87 369 minecraft:moss_block
fill 229 82 369 230 82 369 minecraft:lime_terracotta
fill 230 82 370 230 82 372 minecraft:moss_block
setblock 230 82 373 minecraft:green_concrete
fill 230 82 374 230 83 376 minecraft:moss_block
setblock 230 82 377 minecraft:lime_terracotta
fill 230 82 378 230 87 379 minecraft:moss_block
fill 230 82 380 230 83 381 minecraft:lime_terracotta
setblock 230 82 382 minecraft:green_concrete
fill 230 82 383 230 83 387 minecraft:moss_block
fill 230 82 388 230 82 389 minecraft:lime_terracotta
fill 230 82 390 230 87 390 minecraft:moss_block
fill 230 82 392 230 83 392 minecraft:lime_terracotta
fill 230 82 393 230 82 394 minecraft:moss_block
fill 230 82 398 230 87 399 minecraft:moss_block
fill 230 82 400 230 83 401 minecraft:lime_terracotta
fill 230 82 407 230 84 407 minecraft:moss_block
setblock 230 82 408 minecraft:green_concrete
setblock 230 82 409 minecraft:lime_terracotta
fill 230 82 410 230 83 411 minecraft:moss_block
fill 188 83 369 188 83 370 minecraft:moss_block
setblock 188 83 371 minecraft:lime_terracotta
fill 188 83 375 188 86 375 minecraft:moss_block
setblock 188 83 381 minecraft:moss_block
fill 188 83 389 188 83 390 minecraft:moss_block
fill 188 83 391 188 83 392 minecraft:lime_terracotta
setblock 188 83 393 minecraft:moss_block
setblock 188 83 395 minecraft:lime_terracotta
fill 188 83 396 188 86 396 minecraft:moss_block
fill 188 83 400 188 85 400 minecraft:moss_block
fill 188 83 407 188 86 407 minecraft:moss_block
fill 188 83 409 188 84 409 minecraft:moss_block
setblock 189 83 411 minecraft:lime_terracotta
setblock 191 83 369 minecraft:moss_block
fill 197 83 369 197 86 369 minecraft:moss_block
fill 197 83 411 197 85 411 minecraft:moss_block
setblock 198 83 369 minecraft:lime_terracotta
fill 199 83 369 200 83 369 minecraft:moss_block
setblock 200 83 411 minecraft:lime_terracotta
fill 201 83 369 202 83 369 minecraft:lime_terracotta
fill 203 83 369 204 83 369 minecraft:moss_block
fill 204 83 411 205 86 411 minecraft:moss_block
fill 208 83 369 208 87 369 minecraft:moss_block
fill 208 83 411 208 85 411 minecraft:moss_block
fill 214 83 411 214 87 411 minecraft:moss_block
fill 218 83 369 218 86 369 minecraft:moss_block
fill 220 83 411 220 85 411 minecraft:moss_block
setblock 221 83 411 minecraft:lime_terracotta
setblock 222 83 369 minecraft:lime_terracotta
fill 222 83 411 223 83 411 minecraft:moss_block
fill 223 83 369 225 83 369 minecraft:moss_block
setblock 224 83 411 minecraft:lime_terracotta
fill 225 83 411 225 86 411 minecraft:moss_block
fill 229 83 369 229 86 369 minecraft:moss_block
setblock 230 83 369 minecraft:lime_terracotta
fill 230 83 370 230 83 371 minecraft:moss_block
setblock 230 83 372 minecraft:lime_terracotta
fill 230 83 373 230 85 373 minecraft:moss_block
fill 230 83 377 230 85 377 minecraft:moss_block
setblock 230 83 382 minecraft:moss_block
fill 230 83 388 230 86 388 minecraft:moss_block
setblock 230 83 389 minecraft:lime_terracotta
setblock 230 83 393 minecraft:lime_terracotta
setblock 230 83 394 minecraft:moss_block
fill 230 83 402 230 83 403 minecraft:moss_block
setblock 230 83 404 minecraft:lime_terracotta
fill 230 83 405 230 84 406 minecraft:moss_block
fill 230 83 408 230 85 409 minecraft:moss_block
fill 188 84 369 188 85 370 minecraft:lime_terracotta
fill 188 84 371 188 89 372 minecraft:moss_block
fill 188 84 381 188 84 382 minecraft:lime_terracotta
fill 188 84 383 188 89 384 minecraft:moss_block
setblock 188 84 389 minecraft:moss_block
fill 188 84 390 188 85 390 minecraft:lime_terracotta
fill 188 84 391 188 89 392 minecraft:moss_block
setblock 188 84 393 minecraft:lime_terracotta
fill 188 84 395 188 89 395 minecraft:moss_block
fill 188 84 401 188 85 402 minecraft:lime_terracotta
fill 188 84 403 188 89 404 minecraft:moss_block
fill 189 84 369 190 89 369 minecraft:moss_block
fill 189 84 370 191 84 370 minecraft:mud
fill 189 84 372 189 84 374 minecraft:mud
fill 189 84 376 189 84 377 minecraft:mud
fill 189 84 380 189 84 382 minecraft:mud
fill 189 84 384 189 84 386 minecraft:mud
fill 189 84 388 189 84 390 minecraft:mud
fill 189 84 392 189 84 394 minecraft:mud
fill 189 84 396 189 84 398 minecraft:mud
fill 189 84 400 189 84 402 minecraft:mud
fill 189 84 404 189 84 406 minecraft:mud
fill 189 84 408 189 84 410 minecraft:mud
fill 189 84 411 189 89 411 minecraft:moss_block
fill 190 84 411 191 84 411 minecraft:lime_terracotta
fill 191 84 369 192 85 369 minecraft:lime_terracotta
fill 191 84 410 193 84 410 minecraft:mud
fill 192 84 411 193 89 411 minecraft:moss_block
fill 193 84 369 193 85 369 minecraft:moss_block
fill 193 84 370 195 84 370 minecraft:mud
fill 195 84 410 197 84 410 minecraft:mud
fill 197 84 370 199 84 370 minecraft:mud
fill 198 84 369 199 87 369 minecraft:moss_block
fill 198 84 385 201 133 386 minecraft:mud
fill 198 84 411 199 85 411 minecraft:lime_terracotta
fill 199 84 384 201 133 384 minecraft:mud
fill 199 84 387 201 133 387 minecraft:mud
fill 199 84 410 201 84 410 minecraft:mud
setblock 200 84 369 minecraft:lime_terracotta
fill 200 84 411 201 89 411 minecraft:moss_block
fill 201 84 369 202 89 369 minecraft:moss_block
fill 201 84 370 203 84 370 minecraft:mud
fill 202 84 385 202 133 385 minecraft:mud
setblock 202 84 411 minecraft:lime_terracotta
fill 203 84 369 203 85 369 minecraft:lime_terracotta
fill 203 84 410 205 84 410 minecraft:mud
setblock 204 84 369 minecraft:moss_block
fill 205 84 370 207 84 370 minecraft:mud
fill 207 84 410 209 84 410 minecraft:mud
fill 209 84 369 210 89 369 minecraft:moss_block
fill 209 84 370 211 84 370 minecraft:mud
fill 210 84 411 211 85 411 minecraft:lime_terracotta
fill 211 84 369 212 84 369 minecraft:lime_terracotta
fill 211 84 410 213 84 410 minecraft:mud
fill 212 84 411 213 89 411 minecraft:moss_block
fill 213 84 370 215 84 370 minecraft:mud
fill 215 84 410 217 84 410 minecraft:mud
fill 217 84 370 219 84 370 minecraft:mud
setblock 218 84 411 minecraft:moss_block
fill 219 84 410 221 84 410 minecraft:mud
fill 219 84 411 219 85 411 minecraft:lime_terracotta
fill 221 84 369 222 89 369 minecraft:moss_block
fill 221 84 370 223 84 370 minecraft:mud
fill 221 84 411 221 89 411 minecraft:moss_block
fill 222 84 411 223 84 411 minecraft:lime_terracotta
fill 223 84 369 224 85 369 minecraft:lime_terracotta
fill 223 84 410 225 84 410 minecraft:mud
fill 224 84 411 224 89 411 minecraft:moss_block
fill 225 84 369 225 85 369 minecraft:moss_block
fill 225 84 370 227 84 370 minecraft:mud
fill 227 84 410 229 84 410 minecraft:mud
fill 229 84 370 229 84 372 minecraft:mud
fill 229 84 374 229 84 376 minecraft:mud
fill 229 84 378 229 84 380 minecraft:mud
fill 229 84 382 229 84 384 minecraft:mud
fill 229 84 386 229 84 388 minecraft:mud
fill 229 84 390 229 84 392 minecraft:mud
fill 229 84 394 229 84 396 minecraft:mud
fill 229 84 398 229 84 400 minecraft:mud
fill 229 84 402 229 84 404 minecraft:mud
fill 229 84 406 229 84 408 minecraft:mud
fill 230 84 369 230 89 369 minecraft:moss_block
fill 230 84 370 230 84 371 minecraft:lime_terracotta
fill 230 84 372 230 89 372 minecraft:moss_block
fill 230 84 374 230 85 374 minecraft:lime_terracotta
fill 230 84 375 230 84 376 minecraft:moss_block
fill 230 84 380 230 89 381 minecraft:moss_block
fill 230 84 382 230 85 383 minecraft:lime_terracotta
fill 230 84 384 230 84 387 minecraft:moss_block
fill 230 84 389 230 86 389 minecraft:moss_block
setblock 230 84 391 minecraft:lime_terracotta
fill 230 84 392 230 89 393 minecraft:moss_block
fill 230 84 394 230 85 395 minecraft:lime_terracotta
fill 230 84 400 230 89 401 minecraft:moss_block
fill 230 84 402 230 84 403 minecraft:lime_terracotta
fill 230 84 404 230 85 404 minecraft:moss_block
fill 230 84 410 230 87 410 minecraft:moss_block
fill 230 84 411 230 85 411 minecraft:lime_terracotta
setblock 188 85 378 minecraft:lime_terracotta
fill 188 85 379 188 85 380 minecraft:moss_block
setblock 188 85 381 minecraft:lime_terracotta
fill 188 85 382 188 88 382 minecraft:moss_block
setblock 188 85 389 minecraft:lime_terracotta
fill 188 85 393 188 88 393 minecraft:moss_block
fill 188 85 409 188 85 410 minecraft:lime_terracotta
setblock 188 85 411 minecraft:moss_block
setblock 190 85 411 minecraft:lime_terracotta
fill 191 85 411 191 88 411 minecraft:moss_block
fill 198 85 384 198 86 384 minecraft:mud
fill 198 85 387 198 86 387 minecraft:mud
fill 199 85 383 201 86 383 minecraft:mud
fill 199 85 388 201 86 388 minecraft:mud
fill 200 85 369 200 88 369 minecraft:moss_block
fill 202 85 384 202 86 384 minecraft:mud
fill 202 85 386 202 86 387 minecraft:mud
fill 202 85 411 202 88 411 minecraft:moss_block
setblock 204 85 369 minecraft:lime_terracotta
setblock 207 85 411 minecraft:lime_terracotta
fill 211 85 369 211 88 369 minecraft:moss_block
setblock 212 85 369 minecraft:lime_terracotta
setblock 215 85 369 minecraft:lime_terracotta
setblock 218 85 411 minecraft:lime_terracotta
fill 222 85 411 223 88 411 minecraft:moss_block
fill 230 85 370 230 88 371 minecraft:moss_block
setblock 230 85 375 minecraft:lime_terracotta
setblock 230 85 376 minecraft:moss_block
fill 230 85 384 230 85 385 minecraft:moss_block
setblock 230 85 386 minecraft:lime_terracotta
fill 230 85 387 230 87 387 minecraft:moss_block
fill 230 85 391 230 88 391 minecraft:moss_block
fill 230 85 402 230 88 402 minecraft:moss_block
setblock 230 85 403 minecraft:lime_terracotta
setblock 230 85 405 minecraft:moss_block
fill 230 85 406 230 85 407 minecraft:lime_terracotta
fill 188 86 369 188 91 370 minecraft:moss_block
fill 188 86 376 188 87 376 minecraft:lime_terracotta
fill 188 86 378 188 91 378 minecraft:moss_block
fill 188 86 379 188 86 380 minecraft:lime_terracotta
fill 188 86 381 188 91 381 minecraft:moss_block
fill 188 86 387 188 87 388 minecraft:lime_terracotta
fill 188 86 389 188 91 390 minecraft:moss_block
fill 188 86 397 188 87 398 minecraft:moss_block
fill 188 86 399 188 86 400 minecraft:lime_terracotta
fill 188 86 401 188 91 402 minecraft:moss_block
fill 188 86 408 188 87 408 minecraft:lime_terracotta
fill 188 86 409 188 91 410 minecraft:moss_block
setblock 188 86 411 minecraft:lime_terracotta
fill 190 86 411 190 91 411 minecraft:moss_block
fill 191 86 369 192 91 369 minecraft:moss_block
fill 193 86 369 194 86 369 minecraft:lime_terracotta
fill 196 86 411 197 87 411 minecraft:lime_terracotta
fill 197 86 383 197 86 387 minecraft:mud
setblock 198 86 383 minecraft:mud
setblock 198 86 388 minecraft:mud
fill 198 86 411 199 91 411 minecraft:moss_block
fill 199 86 382 201 86 382 minecraft:mud
setblock 200 86 389 minecraft:mud
setblock 202 86 383 minecraft:mud
setblock 202 86 388 minecraft:mud
fill 203 86 369 204 91 369 minecraft:moss_block
fill 203 86 384 203 86 387 minecraft:mud
fill 205 86 369 206 87 369 minecraft:lime_terracotta
fill 207 86 411 207 91 411 minecraft:moss_block
fill 208 86 411 209 86 411 minecraft:lime_terracotta
fill 210 86 411 211 91 411 minecraft:moss_block
fill 212 86 369 212 91 369 minecraft:moss_block
fill 213 86 369 214 86 369 minecraft:lime_terracotta
fill 215 86 369 215 91 369 minecraft:moss_block
fill 216 86 411 217 87 411 minecraft:lime_terracotta
fill 217 86 369 217 87 369 minecraft:lime_terracotta
fill 218 86 411 219 91 411 minecraft:moss_block
setblock 220 86 411 minecraft:lime_terracotta
fill 223 86 369 224 91 369 minecraft:moss_block
fill 225 86 369 226 87 369 minecraft:lime_terracotta
fill 228 86 411 229 87 411 minecraft:lime_terracotta
setblock 230 86 373 minecraft:lime_terracotta
fill 230 86 374 230 91 375 minecraft:moss_block
fill 230 86 376 230 87 377 minecraft:lime_terracotta
fill 230 86 382 230 91 383 minecraft:moss_block
fill 230 86 384 230 86 385 minecraft:lime_terracotta
fill 230 86 386 230 87 386 minecraft:moss_block
fill 230 86 394 230 91 395 minecraft:moss_block
fill 230 86 396 230 87 397 minecraft:lime_terracotta
fill 230 86 403 230 91 403 minecraft:moss_block
fill 230 86 404 230 86 405 minecraft:lime_terracotta
fill 230 86 406 230 87 407 minecraft:moss_block
fill 230 86 408 230 87 408 minecraft:lime_terracotta
setblock 230 86 409 minecraft:moss_block
fill 230 86 411 230 91 411 minecraft:moss_block
setblock 188 87 375 minecraft:lime_terracotta
fill 188 87 379 188 90 380 minecraft:moss_block
setblock 188 87 396 minecraft:lime_terracotta
setblock 188 87 399 minecraft:lime_terracotta
fill 188 87 400 188 90 400 minecraft:moss_block
setblock 188 87 407 minecraft:lime_terracotta
fill 188 87 411 188 90 411 minecraft:moss_block
setblock 191 87 372 minecraft:light[level=14]
setblock 191 87 388 minecraft:light[level=14]
setblock 191 87 396 minecraft:light[level=14]
setblock 191 87 404 minecraft:light[level=14]
fill 193 87 369 193 90 369 minecraft:moss_block
setblock 194 87 369 minecraft:lime_terracotta
setblock 197 87 369 minecraft:lime_terracotta
setblock 199 87 372 minecraft:light[level=14]
setblock 199 87 380 minecraft:light[level=14]
setblock 199 87 388 minecraft:light[level=14]
setblock 199 87 396 minecraft:light[level=14]
setblock 199 87 404 minecraft:light[level=14]
fill 204 87 411 205 87 411 minecraft:lime_terracotta
setblock 207 87 372 minecraft:light[level=14]
setblock 207 87 380 minecraft:light[level=14]
setblock 207 87 388 minecraft:light[level=14]
setblock 207 87 396 minecraft:light[level=14]
setblock 207 87 404 minecraft:light[level=14]
setblock 208 87 411 minecraft:lime_terracotta
fill 209 87 411 209 90 411 minecraft:moss_block
fill 213 87 369 214 90 369 minecraft:moss_block
setblock 215 87 372 minecraft:light[level=14]
setblock 215 87 380 minecraft:light[level=14]
setblock 215 87 388 minecraft:light[level=14]
setblock 215 87 396 minecraft:light[level=14]
setblock 215 87 404 minecraft:light[level=14]
setblock 218 87 369 minecraft:lime_terracotta
fill 220 87 411 220 90 411 minecraft:moss_block
setblock 223 87 372 minecraft:light[level=14]
setblock 223 87 380 minecraft:light[level=14]
setblock 223 87 388 minecraft:light[level=14]
setblock 223 87 396 minecraft:light[level=14]
setblock 223 87 404 minecraft:light[level=14]
setblock 225 87 411 minecraft:lime_terracotta
setblock 229 87 369 minecraft:lime_terracotta
fill 230 87 373 230 90 373 minecraft:moss_block
fill 230 87 384 230 90 384 minecraft:moss_block
setblock 230 87 385 minecraft:lime_terracotta
fill 230 87 388 230 87 389 minecraft:lime_terracotta
fill 230 87 404 230 89 405 minecraft:moss_block
setblock 230 87 409 minecraft:lime_terracotta
fill 188 88 373 188 89 374 minecraft:lime_terracotta
fill 188 88 375 188 93 376 minecraft:moss_block
setblock 188 88 377 minecraft:lime_terracotta
fill 188 88 385 188 89 386 minecraft:lime_terracotta
fill 188 88 387 188 93 388 minecraft:moss_block
fill 188 88 394 188 89 394 minecraft:lime_terracotta
fill 188 88 396 188 93 396 minecraft:moss_block
fill 188 88 397 188 88 398 minecraft:lime_terracotta
fill 188 88 399 188 93 399 minecraft:moss_block
fill 188 88 405 188 89 406 minecraft:lime_terracotta
fill 188 88 407 188 93 408 minecraft:moss_block
fill 194 88 369 194 93 369 minecraft:moss_block
fill 194 88 411 195 88 411 minecraft:lime_terracotta
fill 195 88 369 196 88 369 minecraft:lime_terracotta
fill 196 88 411 197 93 411 minecraft:moss_block
fill 197 88 369 198 89 369 minecraft:moss_block
fill 199 88 369 199 89 369 minecraft:lime_terracotta
fill 203 88 411 203 89 411 minecraft:lime_terracotta
fill 204 88 411 205 93 411 minecraft:moss_block
fill 205 88 369 206 93 369 minecraft:moss_block
setblock 206 88 411 minecraft:lime_terracotta
fill 207 88 369 208 89 369 minecraft:lime_terracotta
fill 208 88 411 208 93 411 minecraft:moss_block
fill 214 88 411 215 89 411 minecraft:lime_terracotta
setblock 216 88 369 minecraft:lime_terracotta
fill 216 88 411 217 93 411 minecraft:moss_block
fill 217 88 369 218 93 369 minecraft:moss_block
fill 219 88 369 220 89 369 minecraft:lime_terracotta
fill 225 88 369 226 93 369 minecraft:moss_block
fill 225 88 411 225 93 411 minecraft:moss_block
fill 226 88 411 227 88 411 minecraft:lime_terracotta
fill 227 88 369 228 88 369 minecraft:lime_terracotta
fill 228 88 411 229 90 411 minecraft:moss_block
fill 229 88 369 229 93 369 minecraft:moss_block
fill 230 88 376 230 93 377 minecraft:moss_block
fill 230 88 378 230 89 379 minecraft:lime_terracotta
fill 230 88 385 230 93 385 minecraft:moss_block
fill 230 88 386 230 88 387 minecraft:lime_terracotta
fill 230 88 388 230 89 389 minecraft:moss_block
fill 230 88 390 230 89 390 minecraft:lime_terracotta
fill 230 88 396 230 93 397 minecraft:moss_block
fill 230 88 398 230 89 399 minecraft:lime_terracotta
fill 230 88 406 230 91 406 minecraft:moss_block
setblock 230 88 407 minecraft:lime_terracotta
fill 230 88 408 230 93 409 minecraft:moss_block
fill 230 88 410 230 89 410 minecraft:lime_terracotta
fill 188 89 377 188 92 377 minecraft:moss_block
setblock 188 89 382 minecraft:lime_terracotta
setblock 188 89 393 minecraft:lime_terracotta
fill 188 89 397 188 92 398 minecraft:moss_block
setblock 191 89 411 minecraft:lime_terracotta
setblock 194 89 411 minecraft:lime_terracotta
fill 195 89 369 196 92 369 minecraft:moss_block
fill 195 89 411 195 92 411 minecraft:moss_block
setblock 200 89 369 minecraft:lime_terracotta
setblock 202 89 411 minecraft:lime_terracotta
fill 206 89 411 206 92 411 minecraft:moss_block
setblock 211 89 369 minecraft:lime_terracotta
fill 216 89 369 216 92 369 minecraft:moss_block
fill 222 89 411 223 89 411 minecraft:lime_terracotta
setblock 226 89 411 minecraft:lime_terracotta
fill 227 89 369 227 92 369 minecraft:moss_block
fill 227 89 411 227 92 411 minecraft:moss_block
setblock 228 89 369 minecraft:lime_terracotta
fill 230 89 370 230 89 371 minecraft:lime_terracotta
fill 230 89 386 230 91 387 minecraft:moss_block
setblock 230 89 391 minecraft:lime_terracotta
setblock 230 89 402 minecraft:lime_terracotta
fill 230 89 407 230 91 407 minecraft:moss_block
fill 188 90 371 188 91 372 minecraft:lime_terracotta
fill 188 90 373 188 95 374 minecraft:moss_block
fill 188 90 382 188 95 382 minecraft:moss_block
fill 188 90 383 188 90 384 minecraft:lime_terracotta
fill 188 90 385 188 95 386 minecraft:moss_block
fill 188 90 391 188 91 392 minecraft:lime_terracotta
fill 188 90 393 188 95 394 minecraft:moss_block
setblock 188 90 395 minecraft:lime_terracotta
fill 188 90 403 188 91 404 minecraft:lime_terracotta
fill 188 90 405 188 95 406 minecraft:moss_block
fill 189 90 369 190 91 369 minecraft:lime_terracotta
fill 189 90 370 191 90 370 minecraft:mud
fill 189 90 372 189 90 374 minecraft:mud
fill 189 90 376 189 90 377 minecraft:mud
fill 189 90 380 189 90 382 minecraft:mud
fill 189 90 384 189 90 386 minecraft:mud
fill 189 90 388 189 90 390 minecraft:mud
fill 189 90 392 189 90 394 minecraft:mud
fill 189 90 396 189 90 398 minecraft:mud
fill 189 90 400 189 90 402 minecraft:mud
fill 189 90 404 189 90 406 minecraft:mud
fill 189 90 408 189 90 410 minecraft:mud
fill 189 90 411 189 91 411 minecraft:lime_terracotta
fill 191 90 410 193 90 410 minecraft:mud
fill 191 90 411 191 95 411 minecraft:moss_block
fill 192 90 411 193 90 411 minecraft:lime_terracotta
fill 193 90 370 195 90 370 minecraft:mud
fill 194 90 411 194 95 411 minecraft:moss_block
fill 195 90 410 197 90 410 minecraft:mud
fill 197 90 369 197 93 369 minecraft:moss_block
fill 197 90 370 199 90 370 minecraft:mud
setblock 198 90 369 minecraft:lime_terracotta
fill 199 90 369 200 95 369 minecraft:moss_block
fill 199 90 410 201 90 410 minecraft:mud
fill 200 90 411 201 91 411 minecraft:lime_terracotta
fill 201 90 369 202 91 369 minecraft:lime_terracotta
fill 201 90 370 203 90 370 minecraft:mud
fill 202 90 411 203 95 411 minecraft:moss_block
fill 203 90 410 205 90 410 minecraft:mud
fill 205 90 370 207 90 370 minecraft:mud
fill 207 90 369 208 95 369 minecraft:moss_block
fill 207 90 410 209 90 410 minecraft:mud
fill 209 90 369 210 90 369 minecraft:lime_terracotta
fill 209 90 370 211 90 370 minecraft:mud
fill 211 90 369 211 95 369 minecraft:moss_block
fill 211 90 410 213 90 410 minecraft:mud
fill 212 90 411 213 90 411 minecraft:lime_terracotta
fill 213 90 370 215 90 370 minecraft:mud
fill 214 90 411 215 95 411 minecraft:moss_block
fill 215 90 410 217 90 410 minecraft:mud
fill 217 90 370 219 90 370 minecraft:mud
fill 219 90 369 220 95 369 minecraft:moss_block
fill 219 90 410 221 90 410 minecraft:mud
fill 221 90 369 222 91 369 minecraft:lime_terracotta
fill 221 90 370 223 90 370 minecraft:mud
fill 221 90 411 221 91 411 minecraft:lime_terracotta
fill 222 90 411 223 95 411 minecraft:moss_block
fill 223 90 410 225 90 410 minecraft:mud
setblock 224 90 411 minecraft:lime_terracotta
fill 225 90 370 227 90 370 minecraft:mud
fill 226 90 411 226 92 411 minecraft:moss_block
fill 227 90 410 229 90 410 minecraft:mud
fill 228 90 369 228 95 369 minecraft:moss_block
fill 229 90 370 229 90 372 minecraft:mud
fill 229 90 374 229 90 376 minecraft:mud
fill 229 90 378 229 90 380 minecraft:mud
fill 229 90 382 229 90 384 minecraft:mud
fill 229 90 386 229 90 388 minecraft:mud
fill 229 90 390 229 90 392 minecraft:mud
fill 229 90 394 229 90 396 minecraft:mud
fill 229 90 398 229 90 400 minecraft:mud
fill 229 90 402 229 90 404 minecraft:mud
fill 229 90 406 229 90 408 minecraft:mud
setblock 230 90 369 minecraft:lime_terracotta
fill 230 90 370 230 95 371 minecraft:moss_block
fill 230 90 372 230 91 372 minecraft:lime_terracotta
fill 230 90 378 230 95 379 minecraft:moss_block
fill 230 90 380 230 90 381 minecraft:lime_terracotta
fill 230 90 388 230 93 388 minecraft:moss_block
setblock 230 90 389 minecraft:lime_terracotta
fill 230 90 390 230 95 391 minecraft:moss_block
fill 230 90 392 230 91 393 minecraft:lime_terracotta
fill 230 90 398 230 92 399 minecraft:moss_block
fill 230 90 400 230 90 401 minecraft:lime_terracotta
fill 230 90 402 230 95 402 minecraft:moss_block
fill 230 90 404 230 91 404 minecraft:lime_terracotta
setblock 230 90 405 minecraft:moss_block
fill 230 90 410 230 95 410 minecraft:moss_block
fill 188 91 379 188 91 380 minecraft:lime_terracotta
setblock 188 91 383 minecraft:lime_terracotta
fill 188 91 384 188 94 384 minecraft:moss_block
fill 188 91 395 188 94 395 minecraft:moss_block
setblock 188 91 400 minecraft:lime_terracotta
setblock 188 91 411 minecraft:lime_terracotta
fill 192 91 411 193 94 411 minecraft:moss_block
setblock 193 91 369 minecraft:lime_terracotta
fill 198 91 369 198 94 369 minecraft:moss_block
fill 209 91 369 209 94 369 minecraft:moss_block
setblock 209 91 411 minecraft:lime_terracotta
setblock 210 91 369 minecraft:lime_terracotta
setblock 212 91 411 minecraft:lime_terracotta
fill 213 91 369 214 91 369 minecraft:lime_terracotta
fill 213 91 411 213 94 411 minecraft:moss_block
fill 214 91 375 215 92 376 minecraft:moss_block
setblock 220 91 411 minecraft:lime_terracotta
fill 224 91 411 224 94 411 minecraft:moss_block
fill 228 91 411 228 93 411 minecraft:moss_block
setblock 229 91 411 minecraft:lime_terracotta
fill 230 91 369 230 94 369 minecraft:moss_block
setblock 230 91 373 minecraft:lime_terracotta
fill 230 91 380 230 94 380 minecraft:moss_block
setblock 230 91 381 minecraft:lime_terracotta
setblock 230 91 384 minecraft:lime_terracotta
fill 230 91 389 230 93 389 minecraft:moss_block
fill 230 91 400 230 94 400 minecraft:moss_block
setblock 230 91 401 minecraft:lime_terracotta
setblock 230 91 405 minecraft:lime_terracotta
fill 188 92 369 188 92 370 minecraft:lime_terracotta
fill 188 92 371 188 97 372 minecraft:moss_block
fill 188 92 378 188 93 378 minecraft:lime_terracotta
fill 188 92 379 188 97 380 minecraft:moss_block
setblock 188 92 381 minecraft:lime_terracotta
fill 188 92 383 188 97 383 minecraft:moss_block
fill 188 92 389 188 93 390 minecraft:lime_terracotta
fill 188 92 391 188 97 392 minecraft:moss_block
fill 188 92 400 188 97 400 minecraft:moss_block
fill 188 92 401 188 92 402 minecraft:lime_terracotta
fill 188 92 403 188 97 404 minecraft:moss_block
fill 188 92 409 188 93 410 minecraft:lime_terracotta
fill 188 92 411 189 97 411 minecraft:moss_block
fill 189 92 369 190 97 369 minecraft:moss_block
setblock 190 92 411 minecraft:lime_terracotta
fill 191 92 369 192 92 369 minecraft:lime_terracotta
fill 193 92 369 193 97 369 minecraft:moss_block
fill 198 92 411 199 93 411 minecraft:lime_terracotta
fill 200 92 411 201 97 411 minecraft:moss_block
fill 201 92 369 202 97 369 minecraft:moss_block
fill 201 92 380 204 93 380 minecraft:spruce_log
fill 202 92 379 206 93 379 minecraft:spruce_log
fill 203 92 369 204 93 369 minecraft:lime_terracotta
fill 204 92 378 205 93 378 minecraft:spruce_log
fill 207 92 411 207 93 411 minecraft:lime_terracotta
fill 209 92 411 209 97 411 minecraft:moss_block
fill 210 92 369 210 97 369 minecraft:moss_block
fill 210 92 411 211 92 411 minecraft:lime_terracotta
setblock 212 92 369 minecraft:lime_terracotta
fill 212 92 411 212 97 411 minecraft:moss_block
fill 213 92 369 214 97 369 minecraft:moss_block
fill 215 92 369 215 93 369 minecraft:lime_terracotta
fill 218 92 411 219 93 411 minecraft:lime_terracotta
fill 220 92 411 221 97 411 minecraft:moss_block
fill 221 92 369 222 97 369 minecraft:moss_block
fill 223 92 369 224 92 369 minecraft:lime_terracotta
fill 229 92 411 229 93 411 minecraft:moss_block
fill 230 92 372 230 97 373 minecraft:moss_block
fill 230 92 374 230 93 375 minecraft:lime_terracotta
fill 230 92 381 230 97 381 minecraft:moss_block
fill 230 92 382 230 92 383 minecraft:lime_terracotta
fill 230 92 384 230 97 384 minecraft:moss_block
fill 230 92 386 230 93 386 minecraft:lime_terracotta
setblock 230 92 387 minecraft:moss_block
fill 230 92 392 230 97 393 minecraft:moss_block
fill 230 92 394 230 93 395 minecraft:lime_terracotta
fill 230 92 401 230 94 401 minecraft:moss_block
setblock 230 92 403 minecraft:lime_terracotta
fill 230 92 404 230 97 405 minecraft:moss_block
fill 230 92 406 230 93 407 minecraft:lime_terracotta
fill 230 92 411 230 93 411 minecraft:lime_terracotta
setblock 188 93 369 minecraft:lime_terracotta
fill 188 93 370 188 96 370 minecraft:moss_block
setblock 188 93 377 minecraft:lime_terracotta
fill 188 93 381 188 96 381 minecraft:moss_block
fill 188 93 397 188 93 398 minecraft:lime_terracotta
setblock 188 93 401 minecraft:lime_terracotta
fill 188 93 402 188 96 402 minecraft:moss_block
fill 190 93 411 190 96 411 minecraft:moss_block
fill 191 93 369 191 96 369 minecraft:moss_block
setblock 192 93 369 minecraft:lime_terracotta
fill 195 93 369 196 93 369 minecraft:lime_terracotta
setblock 195 93 411 minecraft:lime_terracotta
fill 197 93 381 198 94 382 minecraft:spruce_log
fill 199 93 380 200 94 381 minecraft:spruce_log
fill 201 93 379 201 94 379 minecraft:spruce_log
fill 201 93 381 202 93 381 minecraft:spruce_log
setblock 206 93 411 minecraft:lime_terracotta
fill 210 93 411 211 96 411 minecraft:moss_block
fill 212 93 369 212 96 369 minecraft:moss_block
setblock 216 93 369 minecraft:lime_terracotta
fill 223 93 369 223 96 369 minecraft:moss_block
setblock 224 93 369 minecraft:lime_terracotta
fill 226 93 411 227 93 411 minecraft:lime_terracotta
setblock 227 93 369 minecraft:lime_terracotta
fill 230 93 382 230 96 383 minecraft:moss_block
setblock 230 93 387 minecraft:lime_terracotta
setblock 230 93 398 minecraft:lime_terracotta
fill 230 93 399 230 95 399 minecraft:moss_block
fill 230 93 403 230 96 403 minecraft:moss_block
fill 188 94 369 188 99 369 minecraft:moss_block
fill 188 94 375 188 95 376 minecraft:lime_terracotta
fill 188 94 377 188 99 378 minecraft:moss_block
fill 188 94 387 188 94 388 minecraft:lime_terracotta
fill 188 94 389 188 99 390 minecraft:moss_block
fill 188 94 396 188 95 396 minecraft:lime_terracotta
fill 188 94 397 188 99 398 minecraft:moss_block
setblock 188 94 399 minecraft:lime_terracotta
fill 188 94 401 188 99 401 minecraft:moss_block
fill 188 94 407 188 95 408 minecraft:lime_terracotta
fill 188 94 409 188 99 410 minecraft:moss_block
fill 192 94 369 192 99 369 minecraft:moss_block
setblock 194 94 369 minecraft:lime_terracotta
fill 194 94 382 196 95 382 minecraft:spruce_log
fill 195 94 369 196 99 369 minecraft:moss_block
fill 195 94 381 196 95 381 minecraft:spruce_log
fill 195 94 383 196 94 383 minecraft:spruce_log
fill 195 94 411 195 99 411 minecraft:moss_block
fill 196 94 411 197 94 411 minecraft:lime_terracotta
fill 197 94 369 197 95 369 minecraft:lime_terracotta
setblock 198 94 380 minecraft:spruce_log
fill 198 94 411 199 99 411 minecraft:moss_block
setblock 199 94 382 minecraft:spruce_log
fill 201 94 380 201 94 381 minecraft:spruce_log
fill 202 94 379 203 94 380 minecraft:spruce_log
fill 203 94 369 204 99 369 minecraft:moss_block
fill 204 94 411 205 95 411 minecraft:lime_terracotta
fill 205 94 369 206 94 369 minecraft:lime_terracotta
fill 206 94 411 207 99 411 minecraft:moss_block
setblock 208 94 411 minecraft:lime_terracotta
fill 215 94 369 216 99 369 minecraft:moss_block
fill 216 94 411 217 95 411 minecraft:lime_terracotta
fill 217 94 369 218 95 369 minecraft:lime_terracotta
fill 218 94 411 219 99 411 minecraft:moss_block
fill 224 94 369 224 99 369 minecraft:moss_block
fill 225 94 369 226 94 369 minecraft:lime_terracotta
fill 225 94 411 225 95 411 minecraft:lime_terracotta
fill 226 94 411 227 95 411 minecraft:moss_block
fill 227 94 369 227 99 369 minecraft:moss_block
fill 228 94 411 229 94 411 minecraft:lime_terracotta
fill 229 94 369 229 95 369 minecraft:lime_terracotta
fill 230 94 374 230 99 375 minecraft:moss_block
fill 230 94 376 230 95 377 minecraft:lime_terracotta
setblock 230 94 385 minecraft:lime_terracotta
fill 230 94 386 230 99 387 minecraft:moss_block
fill 230 94 388 230 95 389 minecraft:lime_terracotta
fill 230 94 394 230 99 395 minecraft:moss_block
fill 230 94 396 230 94 397 minecraft:lime_terracotta
fill 230 94 398 230 95 398 minecraft:moss_block
fill 230 94 406 230 99 407 minecraft:moss_block
fill 230 94 408 230 95 409 minecraft:lime_terracotta
fill 230 94 411 230 99 411 minecraft:moss_block
setblock 188 95 384 minecraft:lime_terracotta
setblock 188 95 387 minecraft:lime_terracotta
fill 188 95 388 188 98 388 minecraft:moss_block
setblock 188 95 395 minecraft:lime_terracotta
fill 188 95 399 188 98 399 minecraft:moss_block
setblock 191 95 372 minecraft:light[level=14]
setblock 191 95 388 minecraft:light[level=14]
setblock 191 95 396 minecraft:light[level=14]
setblock 191 95 404 minecraft:light[level=14]
fill 192 95 411 193 95 411 minecraft:lime_terracotta
fill 194 95 369 194 98 369 minecraft:moss_block
setblock 195 95 383 minecraft:spruce_log
setblock 196 95 411 minecraft:lime_terracotta
fill 197 95 381 197 95 382 minecraft:spruce_log
fill 197 95 411 197 98 411 minecraft:moss_block
setblock 198 95 369 minecraft:lime_terracotta
fill 198 95 381 199 95 381 minecraft:spruce_log
setblock 199 95 372 minecraft:light[level=14]
setblock 199 95 380 minecraft:light[level=14]
setblock 199 95 388 minecraft:light[level=14]
setblock 199 95 396 minecraft:light[level=14]
setblock 199 95 404 minecraft:light[level=14]
fill 205 95 369 205 98 369 minecraft:moss_block
setblock 206 95 369 minecraft:lime_terracotta
setblock 207 95 372 minecraft:light[level=14]
setblock 207 95 380 minecraft:light[level=14]
setblock 207 95 388 minecraft:light[level=14]
setblock 207 95 396 minecraft:light[level=14]
setblock 207 95 404 minecraft:light[level=14]
fill 208 95 411 208 98 411 minecraft:moss_block
setblock 209 95 369 minecraft:lime_terracotta
setblock 213 95 411 minecraft:lime_terracotta
setblock 215 95 372 minecraft:light[level=14]
fill 215 95 373 217 95 376 minecraft:lime_concrete
setblock 215 95 380 minecraft:light[level=14]
setblock 215 95 388 minecraft:light[level=14]
setblock 215 95 396 minecraft:light[level=14]
setblock 215 95 404 minecraft:light[level=14]
fill 218 95 374 218 95 376 minecraft:lime_concrete
setblock 223 95 372 minecraft:light[level=14]
setblock 223 95 380 minecraft:light[level=14]
setblock 223 95 388 minecraft:light[level=14]
setblock 223 95 396 minecraft:light[level=14]
setblock 223 95 404 minecraft:light[level=14]
setblock 224 95 411 minecraft:lime_terracotta
fill 225 95 369 226 98 369 minecraft:moss_block
fill 228 95 411 229 97 411 minecraft:moss_block
setblock 230 95 369 minecraft:lime_terracotta
setblock 230 95 380 minecraft:lime_terracotta
fill 230 95 385 230 98 385 minecraft:moss_block
fill 230 95 396 230 98 396 minecraft:moss_block
setblock 230 95 397 minecraft:lime_terracotta
fill 230 95 400 230 95 401 minecraft:lime_terracotta
fill 188 96 373 188 97 374 minecraft:lime_terracotta
fill 188 96 375 188 101 376 minecraft:moss_block
fill 188 96 382 188 97 382 minecraft:lime_terracotta
fill 188 96 384 188 101 384 minecraft:moss_block
fill 188 96 385 188 96 386 minecraft:lime_terracotta
fill 188 96 387 188 101 387 minecraft:moss_block
fill 188 96 393 188 97 394 minecraft:lime_terracotta
fill 188 96 395 188 101 396 minecraft:moss_block
fill 188 96 405 188 96 406 minecraft:lime_terracotta
fill 188 96 407 188 101 408 minecraft:moss_block
fill 189 96 370 191 96 370 minecraft:mud
fill 189 96 372 189 96 374 minecraft:mud
fill 189 96 376 189 96 377 minecraft:mud
fill 189 96 380 189 96 382 minecraft:mud
fill 189 96 384 189 96 386 minecraft:mud
fill 189 96 388 189 96 390 minecraft:mud
fill 189 96 392 189 96 394 minecraft:mud
fill 189 96 396 189 96 398 minecraft:mud
fill 189 96 400 189 96 402 minecraft:mud
fill 189 96 404 189 96 406 minecraft:mud
fill 189 96 408 189 96 410 minecraft:mud
fill 191 96 410 193 96 410 minecraft:mud
fill 191 96 411 191 97 411 minecraft:lime_terracotta
fill 192 96 411 193 101 411 minecraft:moss_block
fill 193 96 370 195 96 370 minecraft:mud
setblock 194 96 411 minecraft:lime_terracotta
fill 195 96 410 197 96 410 minecraft:mud
fill 196 96 411 196 101 411 minecraft:moss_block
fill 197 96 369 198 101 369 minecraft:moss_block
fill 197 96 370 199 96 370 minecraft:mud
fill 199 96 369 200 97 369 minecraft:lime_terracotta
fill 199 96 410 201 96 410 minecraft:mud
fill 201 96 370 203 96 370 minecraft:mud
fill 202 96 411 203 97 411 minecraft:lime_terracotta
fill 203 96 410 205 96 410 minecraft:mud
fill 204 96 411 205 101 411 minecraft:moss_block
fill 205 96 370 207 96 370 minecraft:mud
fill 206 96 369 206 101 369 minecraft:moss_block
fill 207 96 369 208 96 369 minecraft:lime_terracotta
fill 207 96 410 209 96 410 minecraft:mud
fill 209 96 369 209 101 369 minecraft:moss_block
fill 209 96 370 211 96 370 minecraft:mud
fill 211 96 369 211 97 369 minecraft:lime_terracotta
fill 211 96 410 213 96 410 minecraft:mud
fill 213 96 370 215 96 370 minecraft:mud
fill 213 96 411 213 101 411 minecraft:moss_block
fill 214 96 411 215 96 411 minecraft:lime_terracotta
fill 215 96 410 217 96 410 minecraft:mud
fill 216 96 411 217 98 411 minecraft:moss_block
fill 217 96 369 218 101 369 minecraft:moss_block
fill 217 96 370 219 96 370 minecraft:mud
fill 219 96 369 220 97 369 minecraft:lime_terracotta
fill 219 96 410 221 96 410 minecraft:mud
fill 221 96 370 223 96 370 minecraft:mud
fill 222 96 411 223 97 411 minecraft:lime_terracotta
fill 223 96 410 225 96 410 minecraft:mud
fill 224 96 411 225 101 411 minecraft:moss_block
fill 225 96 370 227 96 370 minecraft:mud
setblock 226 96 411 minecraft:lime_terracotta
fill 227 96 410 229 96 410 minecraft:mud
fill 227 96 411 227 99 411 minecraft:moss_block
setblock 228 96 369 minecraft:lime_terracotta
fill 229 96 369 230 101 369 minecraft:moss_block
fill 229 96 370 229 96 372 minecraft:mud
fill 229 96 374 229 96 376 minecraft:mud
fill 229 96 378 229 96 380 minecraft:mud
fill 229 96 382 229 96 384 minecraft:mud
fill 229 96 386 229 96 388 minecraft:mud
fill 229 96 390 229 96 392 minecraft:mud
fill 229 96 394 229 96 396 minecraft:mud
fill 229 96 398 229 96 400 minecraft:mud
fill 229 96 402 229 96 404 minecraft:mud
fill 229 96 406 229 96 408 minecraft:mud
fill 230 96 370 230 97 371 minecraft:lime_terracotta
fill 230 96 376 230 101 377 minecraft:moss_block
fill 230 96 378 230 96 379 minecraft:lime_terracotta
fill 230 96 380 230 101 380 minecraft:moss_block
fill 230 96 388 230 101 389 minecraft:moss_block
fill 230 96 390 230 97 391 minecraft:lime_terracotta
fill 230 96 397 230 101 397 minecraft:moss_block
fill 230 96 398 230 96 399 minecraft:lime_terracotta
fill 230 96 400 230 97 401 minecraft:moss_block
fill 230 96 402 230 97 402 minecraft:lime_terracotta
fill 230 96 408 230 101 409 minecraft:moss_block
fill 230 96 410 230 97 410 minecraft:lime_terracotta
setblock 188 97 370 minecraft:lime_terracotta
setblock 188 97 381 minecraft:lime_terracotta
fill 188 97 385 188 100 386 minecraft:moss_block
setblock 188 97 402 minecraft:lime_terracotta
setblock 188 97 405 minecraft:lime_terracotta
fill 188 97 406 188 100 406 minecraft:moss_block
setblock 190 97 411 minecraft:lime_terracotta
setblock 191 97 369 minecraft:lime_terracotta
fill 194 97 411 194 100 411 minecraft:moss_block
fill 207 97 369 208 100 369 minecraft:moss_block
fill 210 97 411 211 97 411 minecraft:lime_terracotta
setblock 212 97 369 minecraft:lime_terracotta
setblock 214 97 411 minecraft:lime_terracotta
fill 215 97 411 215 100 411 minecraft:moss_block
setblock 223 97 369 minecraft:lime_terracotta
fill 226 97 411 226 99 411 minecraft:moss_block
fill 228 97 369 228 100 369 minecraft:moss_block
fill 230 97 378 230 100 378 minecraft:moss_block
setblock 230 97 379 minecraft:lime_terracotta
fill 230 97 382 230 97 383 minecraft:lime_terracotta
fill 230 97 398 230 99 399 minecraft:moss_block
setblock 230 97 403 minecraft:lime_terracotta
fill 188 98 370 188 103 370 minecraft:moss_block
fill 188 98 371 188 98 372 minecraft:lime_terracotta
fill 188 98 373 188 103 374 minecraft:moss_block
fill 188 98 379 188 99 380 minecraft:lime_terracotta
fill 188 98 381 188 103 382 minecraft:moss_block
setblock 188 98 383 minecraft:lime_terracotta
fill 188 98 391 188 99 392 minecraft:lime_terracotta
fill 188 98 393 188 103 394 minecraft:moss_block
fill 188 98 400 188 99 400 minecraft:lime_terracotta
fill 188 98 402 188 103 402 minecraft:moss_block
fill 188 98 403 188 98 404 minecraft:lime_terracotta
fill 188 98 405 188 103 405 minecraft:moss_block
fill 188 98 411 189 99 411 minecraft:lime_terracotta
fill 189 98 369 190 98 369 minecraft:lime_terracotta
fill 190 98 411 191 103 411 minecraft:moss_block
fill 191 98 369 191 103 369 minecraft:moss_block
fill 193 98 369 193 99 369 minecraft:lime_terracotta
fill 199 98 369 200 103 369 minecraft:moss_block
fill 200 98 411 201 98 411 minecraft:lime_terracotta
fill 201 98 369 202 99 369 minecraft:lime_terracotta
fill 202 98 411 203 103 411 minecraft:moss_block
fill 204 98 407 204 107 407 minecraft:iron_block
fill 209 98 411 209 99 411 minecraft:lime_terracotta
setblock 210 98 369 minecraft:lime_terracotta
fill 210 98 411 211 103 411 minecraft:moss_block
fill 211 98 369 212 103 369 minecraft:moss_block
setblock 212 98 411 minecraft:lime_terracotta
fill 213 98 369 214 99 369 minecraft:lime_terracotta
fill 214 98 411 214 100 411 minecraft:moss_block
fill 219 98 369 220 103 369 minecraft:moss_block
fill 220 98 411 221 99 411 minecraft:lime_terracotta
fill 221 98 369 222 98 369 minecraft:lime_terracotta
fill 222 98 411 223 103 411 minecraft:moss_block
fill 223 98 369 223 103 369 minecraft:moss_block
setblock 228 98 411 minecraft:moss_block
fill 229 98 411 229 99 411 minecraft:lime_terracotta
fill 230 98 370 230 103 371 minecraft:moss_block
fill 230 98 372 230 99 373 minecraft:lime_terracotta
fill 230 98 379 230 103 379 minecraft:moss_block
setblock 230 98 381 minecraft:lime_terracotta
fill 230 98 382 230 103 383 minecraft:moss_block
fill 230 98 384 230 99 384 minecraft:lime_terracotta
fill 230 98 390 230 103 391 minecraft:moss_block
fill 230 98 392 230 98 393 minecraft:lime_terracotta
fill 230 98 400 230 101 400 minecraft:moss_block
setblock 230 98 401 minecraft:lime_terracotta
fill 230 98 402 230 103 403 minecraft:moss_block
fill 230 98 404 230 99 405 minecraft:lime_terracotta
fill 230 98 410 230 100 410 minecraft:moss_block
setblock 188 99 371 minecraft:lime_terracotta
fill 188 99 372 188 102 372 minecraft:moss_block
fill 188 99 383 188 102 383 minecraft:moss_block
setblock 188 99 388 minecraft:lime_terracotta
setblock 188 99 399 minecraft:lime_terracotta
fill 188 99 403 188 102 404 minecraft:moss_block
fill 189 99 369 190 102 369 minecraft:moss_block
fill 193 99 394 194 100 395 minecraft:lime_concrete
setblock 194 99 369 minecraft:lime_terracotta
setblock 197 99 411 minecraft:lime_terracotta
setblock 200 99 411 minecraft:lime_terracotta
fill 201 99 411 201 102 411 minecraft:moss_block
setblock 205 99 369 minecraft:lime_terracotta
setblock 208 99 411 minecraft:lime_terracotta
fill 210 99 369 210 102 369 minecraft:moss_block
fill 212 99 411 212 102 411 minecraft:moss_block
fill 216 99 411 216 101 411 minecraft:moss_block
setblock 217 99 411 minecraft:lime_terracotta
fill 221 99 369 221 102 369 minecraft:moss_block
setblock 222 99 369 minecraft:lime_terracotta
fill 225 99 369 226 99 369 minecraft:lime_terracotta
setblock 228 99 411 minecraft:lime_terracotta
fill 230 99 381 230 102 381 minecraft:moss_block
setblock 230 99 385 minecraft:lime_terracotta
fill 230 99 392 230 102 392 minecraft:moss_block
setblock 230 99 393 minecraft:lime_terracotta
setblock 230 99 396 minecraft:lime_terracotta
fill 230 99 401 230 101 401 minecraft:moss_block
setblock 188 100 369 minecraft:lime_terracotta
fill 188 100 371 188 105 371 minecraft:moss_block
fill 188 100 377 188 101 378 minecraft:lime_terracotta
fill 188 100 379 188 105 380 minecraft:moss_block
fill 188 100 388 188 105 388 minecraft:moss_block
fill 188 100 389 188 100 390 minecraft:lime_terracotta
fill 188 100 391 188 105 392 minecraft:moss_block
fill 188 100 397 188 101 398 minecraft:lime_terracotta
fill 188 100 399 188 105 400 minecraft:moss_block
setblock 188 100 401 minecraft:lime_terracotta
fill 188 100 409 188 101 410 minecraft:lime_terracotta
fill 188 100 411 189 105 411 minecraft:moss_block
setblock 192 100 369 minecraft:lime_terracotta
fill 193 100 369 194 105 369 minecraft:moss_block
fill 195 100 369 196 101 369 minecraft:lime_terracotta
fill 195 100 411 195 101 411 minecraft:lime_terracotta
fill 197 100 411 197 105 411 minecraft:moss_block
fill 198 100 411 199 100 411 minecraft:lime_terracotta
fill 200 100 411 200 105 411 minecraft:moss_block
fill 201 100 369 202 105 369 minecraft:moss_block
fill 203 100 369 204 100 369 minecraft:lime_terracotta
fill 205 100 369 205 105 369 minecraft:moss_block
fill 206 100 411 207 101 411 minecraft:lime_terracotta
fill 208 100 411 209 105 411 minecraft:moss_block
fill 213 100 369 214 105 369 minecraft:moss_block
fill 215 100 369 216 101 369 minecraft:lime_terracotta
fill 217 100 411 217 101 411 minecraft:moss_block
fill 218 100 411 219 100 411 minecraft:lime_terracotta
fill 220 100 411 221 105 411 minecraft:moss_block
fill 222 100 369 222 105 369 minecraft:moss_block
setblock 224 100 369 minecraft:lime_terracotta
fill 225 100 369 226 105 369 minecraft:moss_block
fill 226 100 411 227 101 411 minecraft:lime_terracotta
fill 227 100 369 227 101 369 minecraft:lime_terracotta
fill 228 100 411 229 105 411 minecraft:moss_block
fill 230 100 372 230 105 373 minecraft:moss_block
fill 230 100 374 230 100 375 minecraft:lime_terracotta
fill 230 100 384 230 105 385 minecraft:moss_block
fill 230 100 386 230 101 387 minecraft:lime_terracotta
fill 230 100 393 230 105 393 minecraft:moss_block
fill 230 100 394 230 100 395 minecraft:lime_terracotta
fill 230 100 396 230 105 396 minecraft:moss_block
fill 230 100 398 230 101 398 minecraft:lime_terracotta
setblock 230 100 399 minecraft:moss_block
fill 230 100 404 230 105 405 minecraft:moss_block
fill 230 100 406 230 101 407 minecraft:lime_terracotta
setblock 230 100 411 minecraft:lime_terracotta
fill 188 101 369 188 104 369 minecraft:moss_block
fill 188 101 385 188 101 386 minecraft:lime_terracotta
setblock 188 101 389 minecraft:lime_terracotta
fill 188 101 390 188 104 390 minecraft:moss_block
fill 188 101 401 188 104 401 minecraft:moss_block
setblock 188 101 406 minecraft:lime_terracotta
fill 192 101 369 192 104 369 minecraft:moss_block
setblock 194 101 411 minecraft:lime_terracotta
fill 198 101 411 199 104 411 minecraft:moss_block
fill 203 101 369 203 104 369 minecraft:moss_block
setblock 204 101 369 minecraft:lime_terracotta
fill 207 101 369 208 101 369 minecraft:lime_terracotta
fill 214 101 411 215 101 411 minecraft:lime_terracotta
setblock 218 101 411 minecraft:lime_terracotta
fill 219 101 411 219 104 411 minecraft:moss_block
fill 224 101 369 224 104 369 minecraft:moss_block
setblock 228 101 369 minecraft:lime_terracotta
fill 230 101 374 230 104 374 minecraft:moss_block
setblock 230 101 375 minecraft:lime_terracotta
setblock 230 101 378 minecraft:lime_terracotta
fill 230 101 394 230 104 395 minecraft:moss_block
setblock 230 101 399 minecraft:lime_terracotta
setblock 230 101 410 minecraft:lime_terracotta
fill 230 101 411 230 104 411 minecraft:moss_block
fill 188 102 375 188 102 376 minecraft:lime_terracotta
fill 188 102 377 188 107 378 minecraft:moss_block
fill 188 102 384 188 103 384 minecraft:lime_terracotta
fill 188 102 385 188 107 386 minecraft:moss_block
setblock 188 102 387 minecraft:lime_terracotta
fill 188 102 389 188 107 389 minecraft:moss_block
fill 188 102 395 188 103 396 minecraft:lime_terracotta
fill 188 102 397 188 107 398 minecraft:moss_block
fill 188 102 406 188 107 406 minecraft:moss_block
fill 188 102 407 188 102 408 minecraft:lime_terracotta
fill 188 102 409 188 107 410 minecraft:moss_block
fill 189 102 370 191 102 370 minecraft:mud
fill 189 102 372 189 102 374 minecraft:mud
fill 189 102 376 189 102 377 minecraft:mud
fill 189 102 380 189 102 382 minecraft:mud
fill 189 102 384 189 102 386 minecraft:mud
fill 189 102 388 189 102 390 minecraft:mud
fill 189 102 392 189 102 394 minecraft:mud
fill 189 102 396 189 102 398 minecraft:mud
fill 189 102 400 189 102 402 minecraft:mud
fill 189 102 404 189 102 406 minecraft:mud
fill 189 102 408 189 102 410 minecraft:mud
fill 191 102 410 193 102 410 minecraft:mud
fill 192 102 411 193 103 411 minecraft:lime_terracotta
fill 193 102 370 195 102 370 minecraft:mud
fill 194 102 411 195 107 411 minecraft:moss_block
fill 195 102 369 196 107 369 minecraft:moss_block
fill 195 102 410 197 102 410 minecraft:mud
setblock 196 102 411 minecraft:lime_terracotta
fill 197 102 369 198 103 369 minecraft:lime_terracotta
fill 197 102 370 199 102 370 minecraft:mud
fill 199 102 410 201 102 410 minecraft:mud
fill 201 102 370 203 102 370 minecraft:mud
fill 203 102 410 205 102 410 minecraft:mud
fill 204 102 369 204 107 369 minecraft:moss_block
fill 204 102 411 205 103 411 minecraft:lime_terracotta
fill 205 102 370 207 102 370 minecraft:mud
setblock 206 102 369 minecraft:lime_terracotta
fill 206 102 411 207 107 411 minecraft:moss_block
fill 207 102 369 208 107 369 minecraft:moss_block
fill 207 102 410 209 102 410 minecraft:mud
fill 209 102 369 209 103 369 minecraft:lime_terracotta
fill 209 102 370 211 102 370 minecraft:mud
fill 211 102 410 213 102 410 minecraft:mud
fill 213 102 370 215 102 370 minecraft:mud
fill 213 102 411 213 103 411 minecraft:lime_terracotta
fill 214 102 411 215 103 411 minecraft:moss_block
fill 215 102 369 216 107 369 minecraft:moss_block
fill 215 102 410 217 102 410 minecraft:mud
fill 216 102 411 217 102 411 minecraft:lime_terracotta
fill 217 102 369 218 102 369 minecraft:lime_terracotta
fill 217 102 370 219 102 370 minecraft:mud
fill 218 102 411 218 107 411 minecraft:moss_block
fill 219 102 410 221 102 410 minecraft:mud
fill 221 102 370 223 102 370 minecraft:mud
fill 223 102 410 225 102 410 minecraft:mud
fill 224 102 411 225 103 411 minecraft:lime_terracotta
fill 225 102 370 227 102 370 minecraft:mud
fill 226 102 411 227 107 411 minecraft:moss_block
fill 227 102 369 228 107 369 minecraft:moss_block
fill 227 102 410 229 102 410 minecraft:mud
fill 229 102 369 230 103 369 minecraft:lime_terracotta
fill 229 102 370 229 102 372 minecraft:mud
fill 229 102 374 229 102 376 minecraft:mud
fill 229 102 378 229 102 380 minecraft:mud
fill 229 102 382 229 102 384 minecraft:mud
fill 229 102 386 229 102 388 minecraft:mud
fill 229 102 390 229 102 392 minecraft:mud
fill 229 102 394 229 102 396 minecraft:mud
fill 229 102 398 229 102 400 minecraft:mud
fill 229 102 402 229 102 404 minecraft:mud
fill 229 102 406 229 102 408 minecraft:mud
fill 230 102 375 230 107 375 minecraft:moss_block
fill 230 102 376 230 102 377 minecraft:lime_terracotta
fill 230 102 378 230 107 378 minecraft:moss_block
fill 230 102 380 230 103 380 minecraft:lime_terracotta
fill 230 102 386 230 107 387 minecraft:moss_block
fill 230 102 388 230 103 389 minecraft:lime_terracotta
setblock 230 102 397 minecraft:lime_terracotta
fill 230 102 398 230 107 399 minecraft:moss_block
fill 230 102 400 230 103 401 minecraft:lime_terracotta
fill 230 102 406 230 107 407 minecraft:moss_block
fill 230 102 408 230 102 409 minecraft:lime_terracotta
fill 230 102 410 230 103 410 minecraft:moss_block
setblock 188 103 372 minecraft:lime_terracotta
setblock 188 103 375 minecraft:lime_terracotta
fill 188 103 376 188 106 376 minecraft:moss_block
setblock 188 103 383 minecraft:lime_terracotta
fill 188 103 387 188 106 387 minecraft:moss_block
fill 188 103 403 188 103 404 minecraft:lime_terracotta
setblock 188 103 407 minecraft:lime_terracotta
fill 188 103 408 188 106 408 minecraft:moss_block
fill 189 103 369 190 103 369 minecraft:lime_terracotta
setblock 191 103 372 minecraft:light[level=14]
setblock 191 103 388 minecraft:light[level=14]
setblock 191 103 396 minecraft:light[level=14]
setblock 191 103 404 minecraft:light[level=14]
fill 196 103 411 196 106 411 minecraft:moss_block
setblock 199 103 372 minecraft:light[level=14]
setblock 199 103 380 minecraft:light[level=14]
setblock 199 103 388 minecraft:light[level=14]
setblock 199 103 396 minecraft:light[level=14]
setblock 199 103 404 minecraft:light[level=14]
setblock 201 103 411 minecraft:lime_terracotta
fill 206 103 369 206 106 369 minecraft:moss_block
setblock 207 103 372 minecraft:light[level=14]
setblock 207 103 380 minecraft:light[level=14]
setblock 207 103 388 minecraft:light[level=14]
setblock 207 103 396 minecraft:light[level=14]
setblock 207 103 404 minecraft:light[level=14]
setblock 210 103 369 minecraft:lime_terracotta
setblock 212 103 411 minecraft:lime_terracotta
setblock 215 103 372 minecraft:light[level=14]
setblock 215 103 380 minecraft:light[level=14]
setblock 215 103 388 minecraft:light[level=14]
setblock 215 103 396 minecraft:light[level=14]
setblock 215 103 404 minecraft:light[level=14]
fill 216 103 411 217 105 411 minecraft:moss_block
fill 217 103 369 217 106 369 minecraft:moss_block
setblock 218 103 369 minecraft:lime_terracotta
setblock 221 103 369 minecraft:lime_terracotta
fill 222 103 390 222 118 390 minecraft:mangrove_leaves[persistent=true]
setblock 223 103 372 minecraft:light[level=14]
setblock 223 103 380 minecraft:light[level=14]
setblock 223 103 388 minecraft:light[level=14]
setblock 223 103 396 minecraft:light[level=14]
setblock 223 103 404 minecraft:light[level=14]
fill 230 103 376 230 106 377 minecraft:moss_block
setblock 230 103 381 minecraft:lime_terracotta
setblock 230 103 392 minecraft:lime_terracotta
fill 230 103 397 230 106 397 minecraft:moss_block
fill 230 103 408 230 106 408 minecraft:moss_block
setblock 230 103 409 minecraft:lime_terracotta
fill 188 104 370 188 105 370 minecraft:lime_terracotta
fill 188 104 372 188 109 372 minecraft:moss_block
fill 188 104 373 188 104 374 minecraft:lime_terracotta
fill 188 104 375 188 109 375 minecraft:moss_block
fill 188 104 381 188 105 382 minecraft:lime_terracotta
fill 188 104 383 188 109 384 minecraft:moss_block
fill 188 104 393 188 104 394 minecraft:lime_terracotta
fill 188 104 395 188 109 396 minecraft:moss_block
fill 188 104 402 188 105 402 minecraft:lime_terracotta
fill 188 104 403 188 109 404 minecraft:moss_block
setblock 188 104 405 minecraft:lime_terracotta
fill 188 104 407 188 109 407 minecraft:moss_block
fill 189 104 369 190 109 369 minecraft:moss_block
fill 190 104 411 191 105 411 minecraft:lime_terracotta
fill 191 104 369 191 105 369 minecraft:lime_terracotta
fill 192 104 411 193 109 411 minecraft:moss_block
fill 197 104 369 198 109 369 minecraft:moss_block
fill 199 104 369 200 104 369 minecraft:lime_terracotta
fill 201 104 411 201 109 411 minecraft:moss_block
fill 202 104 411 203 104 411 minecraft:lime_terracotta
fill 204 104 411 205 106 411 minecraft:moss_block
fill 209 104 369 210 109 369 minecraft:moss_block
fill 210 104 411 211 105 411 minecraft:lime_terracotta
fill 211 104 369 212 105 369 minecraft:lime_terracotta
fill 212 104 411 213 109 411 minecraft:moss_block
setblock 214 104 411 minecraft:lime_terracotta
fill 215 104 411 215 107 411 minecraft:moss_block
fill 218 104 369 218 109 369 minecraft:moss_block
fill 219 104 369 220 104 369 minecraft:lime_terracotta
fill 221 104 369 221 109 369 minecraft:moss_block
fill 222 104 411 223 105 411 minecraft:lime_terracotta
fill 223 104 369 223 105 369 minecraft:lime_terracotta
fill 224 104 411 225 109 411 minecraft:moss_block
fill 229 104 369 230 109 369 minecraft:moss_block
fill 230 104 370 230 105 371 minecraft:lime_terracotta
setblock 230 104 379 minecraft:lime_terracotta
fill 230 104 380 230 109 381 minecraft:moss_block
fill 230 104 382 230 105 383 minecraft:lime_terracotta
fill 230 104 388 230 109 389 minecraft:moss_block
fill 230 104 390 230 104 391 minecraft:lime_terracotta
fill 230 104 392 230 109 392 minecraft:moss_block
fill 230 104 400 230 109 401 minecraft:moss_block
fill 230 104 402 230 105 403 minecraft:lime_terracotta
fill 230 104 409 230 109 409 minecraft:moss_block
setblock 230 104 410 minecraft:lime_terracotta
setblock 188 105 369 minecraft:lime_terracotta
fill 188 105 373 188 108 374 minecraft:moss_block
setblock 188 105 390 minecraft:lime_terracotta
setblock 188 105 393 minecraft:lime_terracotta
fill 188 105 394 188 108 394 minecraft:moss_block
setblock 188 105 401 minecraft:lime_terracotta
fill 188 105 405 188 108 405 minecraft:moss_block
setblock 192 105 369 minecraft:lime_terracotta
fill 198 105 411 199 105 411 minecraft:lime_terracotta
fill 199 105 369 199 108 369 minecraft:moss_block
setblock 200 105 369 minecraft:lime_terracotta
setblock 202 105 411 minecraft:lime_terracotta
setblock 203 105 369 minecraft:lime_terracotta
fill 203 105 411 203 108 411 minecraft:moss_block
fill 214 105 411 214 107 411 minecraft:moss_block
fill 219 105 369 220 108 369 minecraft:moss_block
setblock 219 105 411 minecraft:lime_terracotta
setblock 224 105 369 minecraft:lime_terracotta
setblock 230 105 374 minecraft:lime_terracotta
fill 230 105 379 230 108 379 minecraft:moss_block
fill 230 105 390 230 108 390 minecraft:moss_block
setblock 230 105 391 minecraft:lime_terracotta
fill 230 105 394 230 105 395 minecraft:lime_terracotta
fill 230 105 410 230 107 410 minecraft:moss_block
setblock 230 105 411 minecraft:lime_terracotta
fill 188 106 369 188 111 370 minecraft:moss_block
setblock 188 106 371 minecraft:lime_terracotta
fill 188 106 379 188 107 380 minecraft:lime_terracotta
fill 188 106 381 188 111 382 minecraft:moss_block
fill 188 106 388 188 107 388 minecraft:lime_terracotta
fill 188 106 390 188 111 390 minecraft:moss_block
fill 188 106 391 188 106 392 minecraft:lime_terracotta
fill 188 106 393 188 111 393 minecraft:moss_block
fill 188 106 399 188 107 400 minecraft:lime_terracotta
fill 188 106 401 188 111 402 minecraft:moss_block
fill 188 106 411 189 106 411 minecraft:lime_terracotta
fill 190 106 411 191 111 411 minecraft:moss_block
fill 191 106 369 192 111 369 minecraft:moss_block
fill 193 106 369 194 107 369 minecraft:lime_terracotta
fill 197 106 411 197 107 411 minecraft:lime_terracotta
fill 198 106 411 199 111 411 minecraft:moss_block
fill 200 106 369 200 111 369 minecraft:moss_block
setblock 200 106 411 minecraft:lime_terracotta
fill 201 106 369 202 106 369 minecraft:lime_terracotta
fill 202 106 411 202 108 411 minecraft:moss_block
fill 203 106 369 203 111 369 minecraft:moss_block
fill 205 106 369 205 107 369 minecraft:lime_terracotta
fill 208 106 411 209 107 411 minecraft:lime_terracotta
fill 210 106 411 211 111 411 minecraft:moss_block
fill 211 106 369 212 111 369 minecraft:moss_block
fill 213 106 369 214 107 369 minecraft:lime_terracotta
setblock 216 106 411 minecraft:moss_block
fill 217 106 411 217 107 411 minecraft:lime_terracotta
fill 219 106 411 219 111 411 minecraft:moss_block
fill 220 106 411 221 106 411 minecraft:lime_terracotta
setblock 222 106 369 minecraft:lime_terracotta
fill 222 106 411 223 108 411 minecraft:moss_block
fill 223 106 369 224 111 369 minecraft:moss_block
fill 225 106 369 226 107 369 minecraft:lime_terracotta
fill 228 106 411 229 107 411 minecraft:lime_terracotta
fill 230 106 370 230 111 371 minecraft:moss_block
fill 230 106 372 230 106 373 minecraft:lime_terracotta
fill 230 106 374 230 111 374 minecraft:moss_block
fill 230 106 382 230 111 383 minecraft:moss_block
fill 230 106 384 230 107 385 minecraft:lime_terracotta
fill 230 106 391 230 111 391 minecraft:moss_block
setblock 230 106 393 minecraft:lime_terracotta
fill 230 106 394 230 111 395 minecraft:moss_block
fill 230 106 396 230 107 396 minecraft:lime_terracotta
fill 230 106 402 230 111 403 minecraft:moss_block
fill 230 106 404 230 106 405 minecraft:lime_terracotta
fill 230 106 411 230 111 411 minecraft:moss_block
fill 188 107 371 188 110 371 minecraft:moss_block
setblock 188 107 376 minecraft:lime_terracotta
setblock 188 107 387 minecraft:lime_terracotta
fill 188 107 391 188 110 392 minecraft:moss_block
setblock 188 107 408 minecraft:lime_terracotta
setblock 188 107 411 minecraft:lime_terracotta
fill 189 107 411 189 110 411 minecraft:moss_block
setblock 196 107 411 minecraft:lime_terracotta
fill 200 107 411 200 110 411 minecraft:moss_block
fill 201 107 369 202 110 369 minecraft:moss_block
fill 204 107 411 204 109 411 minecraft:moss_block
setblock 205 107 411 minecraft:lime_terracotta
setblock 206 107 369 minecraft:lime_terracotta
setblock 216 107 411 minecraft:lime_terracotta
setblock 217 107 369 minecraft:lime_terracotta
setblock 220 107 411 minecraft:lime_terracotta
fill 221 107 411 221 110 411 minecraft:moss_block
fill 222 107 369 222 110 369 minecraft:moss_block
fill 230 107 372 230 110 372 minecraft:moss_block
setblock 230 107 373 minecraft:lime_terracotta
fill 230 107 376 230 107 377 minecraft:lime_terracotta
fill 230 107 393 230 110 393 minecraft:moss_block
setblock 230 107 397 minecraft:lime_terracotta
fill 230 107 404 230 110 404 minecraft:moss_block
setblock 230 107 405 minecraft:lime_terracotta
setblock 230 107 408 minecraft:lime_terracotta
fill 188 108 376 188 113 376 minecraft:moss_block
fill 188 108 377 188 108 378 minecraft:lime_terracotta
fill 188 108 379 188 113 380 minecraft:moss_block
fill 188 108 385 188 109 386 minecraft:lime_terracotta
fill 188 108 387 188 113 388 minecraft:moss_block
setblock 188 108 389 minecraft:lime_terracotta
fill 188 108 397 188 109 398 minecraft:lime_terracotta
fill 188 108 399 188 113 400 minecraft:moss_block
fill 188 108 406 188 109 406 minecraft:lime_terracotta
fill 188 108 408 188 113 408 minecraft:moss_block
fill 188 108 409 188 108 410 minecraft:lime_terracotta
fill 188 108 411 188 113 411 minecraft:moss_block
fill 189 108 370 191 108 370 minecraft:mud
fill 189 108 372 189 108 374 minecraft:mud
fill 189 108 376 189 108 377 minecraft:mud
fill 189 108 380 189 108 382 minecraft:mud
fill 189 108 384 189 108 386 minecraft:mud
fill 189 108 388 189 108 390 minecraft:mud
fill 189 108 392 189 108 394 minecraft:mud
fill 189 108 396 189 108 398 minecraft:mud
fill 189 108 400 189 108 402 minecraft:mud
fill 189 108 404 189 108 406 minecraft:mud
fill 189 108 408 189 108 410 minecraft:mud
fill 191 108 410 193 108 410 minecraft:mud
fill 193 108 369 194 113 369 minecraft:moss_block
fill 193 108 370 195 108 370 minecraft:mud
fill 194 108 411 195 109 411 minecraft:lime_terracotta
fill 195 108 369 196 109 369 minecraft:lime_terracotta
fill 195 108 410 197 108 410 minecraft:mud
fill 196 108 411 197 113 411 minecraft:moss_block
fill 197 108 370 199 108 370 minecraft:mud
fill 199 108 410 201 108 410 minecraft:mud
fill 201 108 370 203 108 370 minecraft:mud
fill 203 108 410 205 108 410 minecraft:mud
setblock 204 108 369 minecraft:lime_terracotta
fill 205 108 369 206 113 369 minecraft:moss_block
fill 205 108 370 207 108 370 minecraft:mud
fill 205 108 411 205 109 411 minecraft:moss_block
fill 206 108 411 207 108 411 minecraft:lime_terracotta
fill 207 108 369 208 109 369 minecraft:lime_terracotta
fill 207 108 410 209 108 410 minecraft:mud
fill 208 108 411 209 113 411 minecraft:moss_block
fill 209 108 370 211 108 370 minecraft:mud
fill 211 108 410 213 108 410 minecraft:mud
fill 213 108 369 214 113 369 minecraft:moss_block
fill 213 108 370 215 108 370 minecraft:mud
fill 214 108 411 215 109 411 minecraft:lime_terracotta
fill 215 108 369 216 108 369 minecraft:lime_terracotta
fill 215 108 410 217 108 410 minecraft:mud
fill 216 108 411 217 113 411 minecraft:moss_block
fill 217 108 369 217 113 369 minecraft:moss_block
fill 217 108 370 219 108 370 minecraft:mud
setblock 218 108 411 minecraft:lime_terracotta
fill 219 108 410 221 108 410 minecraft:mud
fill 220 108 411 220 110 411 minecraft:moss_block
fill 221 108 370 223 108 370 minecraft:mud
fill 223 108 410 225 108 410 minecraft:mud
fill 225 108 369 226 113 369 minecraft:moss_block
fill 225 108 370 227 108 370 minecraft:mud
fill 226 108 411 227 109 411 minecraft:lime_terracotta
fill 227 108 369 228 109 369 minecraft:lime_terracotta
fill 227 108 410 229 108 410 minecraft:mud
fill 228 108 411 229 113 411 minecraft:moss_block
fill 229 108 370 229 108 372 minecraft:mud
fill 229 108 374 229 108 376 minecraft:mud
fill 229 108 378 229 108 380 minecraft:mud
fill 229 108 382 229 108 384 minecraft:mud
fill 229 108 386 229 108 388 minecraft:mud
fill 229 108 390 229 108 392 minecraft:mud
fill 229 108 394 229 108 396 minecraft:mud
fill 229 108 398 229 108 400 minecraft:mud
fill 229 108 402 229 108 404 minecraft:mud
fill 229 108 406 229 108 408 minecraft:mud
fill 230 108 373 230 113 373 minecraft:moss_block
setblock 230 108 375 minecraft:lime_terracotta
fill 230 108 376 230 113 377 minecraft:moss_block
fill 230 108 378 230 109 378 minecraft:lime_terracotta
fill 230 108 384 230 113 385 minecraft:moss_block
fill 230 108 386 230 108 387 minecraft:lime_terracotta
fill 230 108 396 230 113 397 minecraft:moss_block
fill 230 108 398 230 109 399 minecraft:lime_terracotta
fill 230 108 405 230 113 405 minecraft:moss_block
fill 230 108 406 230 108 407 minecraft:lime_terracotta
fill 230 108 408 230 113 408 minecraft:moss_block
fill 230 108 410 230 109 410 minecraft:lime_terracotta
fill 188 109 373 188 109 374 minecraft:lime_terracotta
setblock 188 109 377 minecraft:lime_terracotta
fill 188 109 378 188 112 378 minecraft:moss_block
fill 188 109 389 188 112 389 minecraft:moss_block
setblock 188 109 394 minecraft:lime_terracotta
setblock 188 109 405 minecraft:lime_terracotta
fill 188 109 409 188 112 410 minecraft:moss_block
fill 198 109 406 198 124 406 minecraft:mangrove_leaves[persistent=true]
setblock 199 109 369 minecraft:lime_terracotta
fill 202 109 411 203 109 411 minecraft:lime_terracotta
fill 204 109 369 204 112 369 minecraft:moss_block
setblock 206 109 411 minecraft:lime_terracotta
fill 207 109 411 207 112 411 minecraft:moss_block
fill 215 109 369 215 112 369 minecraft:moss_block
setblock 216 109 369 minecraft:lime_terracotta
fill 218 109 411 218 112 411 minecraft:moss_block
fill 219 109 369 220 109 369 minecraft:lime_terracotta
fill 222 109 411 222 111 411 minecraft:moss_block
setblock 223 109 411 minecraft:lime_terracotta
fill 230 109 375 230 112 375 minecraft:moss_block
setblock 230 109 379 minecraft:lime_terracotta
fill 230 109 386 230 112 386 minecraft:moss_block
setblock 230 109 387 minecraft:lime_terracotta
setblock 230 109 390 minecraft:lime_terracotta
fill 230 109 406 230 112 407 minecraft:moss_block
fill 188 110 372 188 111 372 minecraft:lime_terracotta
fill 188 110 373 188 115 374 minecraft:moss_block
setblock 188 110 375 minecraft:lime_terracotta
fill 188 110 377 188 115 377 minecraft:moss_block
fill 188 110 383 188 111 384 minecraft:lime_terracotta
fill 188 110 385 188 115 386 minecraft:moss_block
fill 188 110 394 188 115 394 minecraft:moss_block
fill 188 110 395 188 110 396 minecraft:lime_terracotta
fill 188 110 397 188 115 398 minecraft:moss_block
fill 188 110 403 188 111 404 minecraft:lime_terracotta
fill 188 110 405 188 115 406 minecraft:moss_block
setblock 188 110 407 minecraft:lime_terracotta
fill 189 110 369 190 111 369 minecraft:lime_terracotta
fill 192 110 411 193 111 411 minecraft:lime_terracotta
fill 194 110 411 195 115 411 minecraft:moss_block
fill 195 110 369 196 115 369 minecraft:moss_block
fill 197 110 369 198 110 369 minecraft:lime_terracotta
fill 199 110 369 199 115 369 minecraft:moss_block
fill 201 110 411 201 111 411 minecraft:lime_terracotta
fill 202 110 411 203 111 411 minecraft:moss_block
fill 204 110 411 205 110 411 minecraft:lime_terracotta
fill 206 110 411 206 115 411 minecraft:moss_block
fill 207 110 369 208 115 369 minecraft:moss_block
fill 209 110 369 210 111 369 minecraft:lime_terracotta
fill 212 110 411 213 111 411 minecraft:lime_terracotta
fill 214 110 411 215 115 411 minecraft:moss_block
fill 216 110 369 216 115 369 minecraft:moss_block
setblock 218 110 369 minecraft:lime_terracotta
fill 219 110 369 220 115 369 minecraft:moss_block
fill 221 110 369 221 111 369 minecraft:lime_terracotta
fill 223 110 411 223 111 411 minecraft:moss_block
fill 224 110 411 225 110 411 minecraft:lime_terracotta
fill 226 110 411 227 115 411 minecraft:moss_block
fill 227 110 369 228 115 369 minecraft:moss_block
fill 229 110 369 230 110 369 minecraft:lime_terracotta
fill 230 110 378 230 115 379 minecraft:moss_block
fill 230 110 380 230 111 381 minecraft:lime_terracotta
fill 230 110 387 230 115 387 minecraft:moss_block
fill 230 110 388 230 110 389 minecraft:lime_terracotta
fill 230 110 390 230 115 390 minecraft:moss_block
fill 230 110 392 230 111 392 minecraft:lime_terracotta
fill 230 110 398 230 115 399 minecraft:moss_block
fill 230 110 400 230 111 401 minecraft:lime_terracotta
setblock 230 110 409 minecraft:lime_terracotta
fill 230 110 410 230 115 410 minecraft:moss_block
setblock 188 111 371 minecraft:lime_terracotta
fill 188 111 375 188 114 375 minecraft:moss_block
fill 188 111 391 188 111 392 minecraft:lime_terracotta
setblock 188 111 395 minecraft:lime_terracotta
fill 188 111 396 188 114 396 minecraft:moss_block
fill 188 111 407 188 114 407 minecraft:moss_block
setblock 189 111 411 minecraft:lime_terracotta
setblock 191 111 372 minecraft:light[level=14]
setblock 191 111 388 minecraft:light[level=14]
setblock 191 111 396 minecraft:light[level=14]
setblock 191 111 404 minecraft:light[level=14]
fill 197 111 369 197 114 369 minecraft:moss_block
setblock 198 111 369 minecraft:lime_terracotta
setblock 199 111 372 minecraft:light[level=14]
setblock 199 111 380 minecraft:light[level=14]
setblock 199 111 388 minecraft:light[level=14]
setblock 199 111 396 minecraft:light[level=14]
setblock 199 111 404 minecraft:light[level=14]
setblock 200 111 411 minecraft:lime_terracotta
fill 201 111 369 202 111 369 minecraft:lime_terracotta
fill 204 111 411 205 113 411 minecraft:moss_block
setblock 207 111 372 minecraft:light[level=14]
setblock 207 111 380 minecraft:light[level=14]
setblock 207 111 388 minecraft:light[level=14]
setblock 207 111 396 minecraft:light[level=14]
setblock 207 111 404 minecraft:light[level=14]
setblock 215 111 372 minecraft:light[level=14]
setblock 215 111 380 minecraft:light[level=14]
setblock 215 111 388 minecraft:light[level=14]
setblock 215 111 396 minecraft:light[level=14]
setblock 215 111 404 minecraft:light[level=14]
fill 218 111 369 218 114 369 minecraft:moss_block
fill 220 111 411 221 111 411 minecraft:lime_terracotta
setblock 222 111 369 minecraft:lime_terracotta
setblock 223 111 372 minecraft:light[level=14]
setblock 223 111 380 minecraft:light[level=14]
setblock 223 111 388 minecraft:light[level=14]
setblock 223 111 396 minecraft:light[level=14]
setblock 223 111 404 minecraft:light[level=14]
setblock 224 111 411 minecraft:lime_terracotta
fill 225 111 411 225 114 411 minecraft:moss_block
fill 229 111 369 229 114 369 minecraft:moss_block
setblock 230 111 369 minecraft:lime_terracotta
setblock 230 111 372 minecraft:lime_terracotta
fill 230 111 388 230 114 389 minecraft:moss_block
setblock 230 111 393 minecraft:lime_terracotta
setblock 230 111 404 minecraft:lime_terracotta
fill 230 111 409 230 114 409 minecraft:moss_block
fill 188 112 369 188 113 370 minecraft:lime_terracotta
fill 188 112 371 188 117 372 minecraft:moss_block
fill 188 112 381 188 112 382 minecraft:lime_terracotta
fill 188 112 383 188 117 384 minecraft:moss_block
fill 188 112 390 188 113 390 minecraft:lime_terracotta
fill 188 112 391 188 117 392 minecraft:moss_block
setblock 188 112 393 minecraft:lime_terracotta
fill 188 112 395 188 117 395 minecraft:moss_block
fill 188 112 401 188 113 402 minecraft:lime_terracotta
fill 188 112 403 188 117 404 minecraft:moss_block
fill 189 112 369 190 117 369 minecraft:moss_block
fill 189 112 411 189 117 411 minecraft:moss_block
fill 190 112 411 191 112 411 minecraft:lime_terracotta
fill 191 112 369 192 113 369 minecraft:lime_terracotta
fill 192 112 411 193 114 411 minecraft:moss_block
fill 198 112 369 198 117 369 minecraft:moss_block
fill 198 112 411 199 113 411 minecraft:lime_terracotta
setblock 200 112 369 minecraft:lime_terracotta
fill 200 112 411 201 117 411 minecraft:moss_block
fill 201 112 369 202 117 369 minecraft:moss_block
setblock 202 112 411 minecraft:lime_terracotta
fill 203 112 369 203 113 369 minecraft:lime_terracotta
fill 203 112 411 203 115 411 minecraft:moss_block
fill 209 112 369 210 117 369 minecraft:moss_block
fill 210 112 411 211 113 411 minecraft:lime_terracotta
fill 211 112 369 212 112 369 minecraft:lime_terracotta
fill 212 112 411 213 117 411 minecraft:moss_block
fill 219 112 411 219 113 411 minecraft:lime_terracotta
fill 220 112 411 221 113 411 minecraft:moss_block
fill 221 112 369 222 117 369 minecraft:moss_block
fill 222 112 411 223 112 411 minecraft:lime_terracotta
fill 223 112 369 224 113 369 minecraft:lime_terracotta
fill 224 112 411 224 117 411 minecraft:moss_block
fill 230 112 369 230 117 369 minecraft:moss_block
fill 230 112 370 230 112 371 minecraft:lime_terracotta
fill 230 112 372 230 117 372 minecraft:moss_block
fill 230 112 374 230 113 374 minecraft:lime_terracotta
fill 230 112 380 230 117 381 minecraft:moss_block
fill 230 112 382 230 113 383 minecraft:lime_terracotta
setblock 230 112 391 minecraft:lime_terracotta
fill 230 112 392 230 117 393 minecraft:moss_block
fill 230 112 394 230 113 395 minecraft:lime_terracotta
fill 230 112 400 230 117 401 minecraft:moss_block
fill 230 112 402 230 112 403 minecraft:lime_terracotta
fill 230 112 404 230 117 404 minecraft:moss_block
fill 230 112 411 230 113 411 minecraft:lime_terracotta
setblock 188 113 378 minecraft:lime_terracotta
setblock 188 113 381 minecraft:lime_terracotta
fill 188 113 382 188 116 382 minecraft:moss_block
setblock 188 113 389 minecraft:lime_terracotta
fill 188 113 393 188 116 393 minecraft:moss_block
fill 188 113 409 188 113 410 minecraft:lime_terracotta
setblock 190 113 411 minecraft:lime_terracotta
fill 191 113 411 191 116 411 minecraft:moss_block
fill 200 113 369 200 116 369 minecraft:moss_block
fill 202 113 411 202 115 411 minecraft:moss_block
setblock 204 113 369 minecraft:lime_terracotta
setblock 207 113 411 minecraft:lime_terracotta
fill 211 113 369 211 116 369 minecraft:moss_block
setblock 212 113 369 minecraft:lime_terracotta
setblock 215 113 369 minecraft:lime_terracotta
setblock 218 113 411 minecraft:lime_terracotta
fill 222 113 411 223 115 411 minecraft:moss_block
fill 230 113 370 230 116 371 minecraft:moss_block
setblock 230 113 375 minecraft:lime_terracotta
setblock 230 113 386 minecraft:lime_terracotta
fill 230 113 391 230 116 391 minecraft:moss_block
fill 230 113 402 230 116 402 minecraft:moss_block
setblock 230 113 403 minecraft:lime_terracotta
fill 230 113 406 230 113 407 minecraft:lime_terracotta
fill 188 114 369 188 119 370 minecraft:moss_block
fill 188 114 376 188 115 376 minecraft:lime_terracotta
fill 188 114 378 188 119 378 minecraft:moss_block
fill 188 114 379 188 114 380 minecraft:lime_terracotta
fill 188 114 381 188 119 381 minecraft:moss_block
fill 188 114 387 188 115 388 minecraft:lime_terracotta
fill 188 114 389 188 119 390 minecraft:moss_block
fill 188 114 399 188 114 400 minecraft:lime_terracotta
fill 188 114 401 188 119 402 minecraft:moss_block
fill 188 114 408 188 115 408 minecraft:lime_terracotta
fill 188 114 409 188 119 410 minecraft:moss_block
setblock 188 114 411 minecraft:lime_terracotta
fill 189 114 370 191 114 370 minecraft:mud
fill 189 114 372 189 114 374 minecraft:mud
fill 189 114 376 189 114 377 minecraft:mud
fill 189 114 380 189 114 382 minecraft:mud
fill 189 114 384 189 114 386 minecraft:mud
fill 189 114 388 189 114 390 minecraft:mud
fill 189 114 392 189 114 394 minecraft:mud
fill 189 114 396 189 114 398 minecraft:mud
fill 189 114 400 189 114 402 minecraft:mud
fill 189 114 404 189 114 406 minecraft:mud
fill 189 114 408 189 114 410 minecraft:mud
fill 190 114 411 190 116 411 minecraft:moss_block
fill 191 114 369 192 119 369 minecraft:moss_block
fill 191 114 410 193 114 410 minecraft:mud
fill 193 114 369 194 114 369 minecraft:lime_terracotta
fill 193 114 370 195 114 370 minecraft:mud
fill 195 114 410 197 114 410 minecraft:mud
fill 196 114 411 197 115 411 minecraft:lime_terracotta
fill 197 114 370 199 114 370 minecraft:mud
fill 198 114 411 199 119 411 minecraft:moss_block
fill 199 114 410 201 114 410 minecraft:mud
fill 201 114 370 203 114 370 minecraft:mud
fill 203 114 369 204 119 369 minecraft:moss_block
fill 203 114 410 205 114 410 minecraft:mud
setblock 204 114 411 minecraft:moss_block
fill 205 114 369 206 115 369 minecraft:lime_terracotta
fill 205 114 370 207 114 370 minecraft:mud
fill 205 114 411 205 115 411 minecraft:lime_terracotta
fill 207 114 410 209 114 410 minecraft:mud
fill 207 114 411 207 119 411 minecraft:moss_block
fill 208 114 411 209 114 411 minecraft:lime_terracotta
fill 209 114 370 211 114 370 minecraft:mud
fill 210 114 411 211 116 411 minecraft:moss_block
fill 211 114 410 213 114 410 minecraft:mud
fill 212 114 369 212 119 369 minecraft:moss_block
fill 213 114 369 214 114 369 minecraft:lime_terracotta
fill 213 114 370 215 114 370 minecraft:mud
fill 215 114 369 215 119 369 minecraft:moss_block
fill 215 114 410 217 114 410 minecraft:mud
fill 216 114 411 217 115 411 minecraft:lime_terracotta
fill 217 114 369 217 115 369 minecraft:lime_terracotta
fill 217 114 370 219 114 370 minecraft:mud
fill 218 114 411 219 119 411 minecraft:moss_block
fill 219 114 410 221 114 410 minecraft:mud
setblock 220 114 411 minecraft:lime_terracotta
fill 221 114 370 223 114 370 minecraft:mud
fill 221 114 411 221 117 411 minecraft:moss_block
fill 223 114 369 224 119 369 minecraft:moss_block
fill 223 114 410 225 114 410 minecraft:mud
fill 225 114 369 226 115 369 minecraft:lime_terracotta
fill 225 114 370 227 114 370 minecraft:mud
fill 227 114 410 229 114 410 minecraft:mud
fill 228 114 411 229 114 411 minecraft:lime_terracotta
fill 229 114 370 229 114 372 minecraft:mud
fill 229 114 374 229 114 376 minecraft:mud
fill 229 114 378 229 114 380 minecraft:mud
fill 229 114 382 229 114 384 minecraft:mud
fill 229 114 386 229 114 388 minecraft:mud
fill 229 114 390 229 114 392 minecraft:mud
fill 229 114 394 229 114 396 minecraft:mud
fill 229 114 398 229 114 400 minecraft:mud
fill 229 114 402 229 114 404 minecraft:mud
fill 229 114 406 229 114 408 minecraft:mud
setblock 230 114 373 minecraft:lime_terracotta
fill 230 114 374 230 119 375 minecraft:moss_block
fill 230 114 376 230 115 377 minecraft:lime_terracotta
fill 230 114 382 230 119 383 minecraft:moss_block
fill 230 114 384 230 114 385 minecraft:lime_terracotta
fill 230 114 386 230 119 386 minecraft:moss_block
fill 230 114 394 230 119 395 minecraft:moss_block
fill 230 114 396 230 115 397 minecraft:lime_terracotta
fill 230 114 403 230 119 403 minecraft:moss_block
setblock 230 114 405 minecraft:lime_terracotta
fill 230 114 406 230 119 407 minecraft:moss_block
fill 230 114 408 230 115 408 minecraft:lime_terracotta
fill 230 114 411 230 119 411 minecraft:moss_block
setblock 188 115 375 minecraft:lime_terracotta
fill 188 115 379 188 118 380 minecraft:moss_block
setblock 188 115 396 minecraft:lime_terracotta
setblock 188 115 399 minecraft:lime_terracotta
fill 188 115 400 188 118 400 minecraft:moss_block
setblock 188 115 407 minecraft:lime_terracotta
fill 188 115 411 188 118 411 minecraft:moss_block
fill 192 115 411 192 117 411 minecraft:moss_block
fill 193 115 369 193 118 369 minecraft:moss_block
setblock 193 115 411 minecraft:lime_terracotta
setblock 194 115 369 minecraft:lime_terracotta
setblock 197 115 369 minecraft:lime_terracotta
setblock 204 115 411 minecraft:lime_terracotta
setblock 208 115 411 minecraft:lime_terracotta
fill 209 115 411 209 118 411 minecraft:moss_block
fill 213 115 369 214 118 369 minecraft:moss_block
setblock 218 115 369 minecraft:lime_terracotta
fill 220 115 411 220 117 411 minecraft:moss_block
setblock 225 115 411 minecraft:lime_terracotta
setblock 228 115 411 minecraft:lime_terracotta
setblock 229 115 369 minecraft:lime_terracotta
fill 229 115 411 229 118 411 minecraft:moss_block
fill 230 115 373 230 118 373 minecraft:moss_block
fill 230 115 384 230 118 384 minecraft:moss_block
setblock 230 115 385 minecraft:lime_terracotta
fill 230 115 388 230 115 389 minecraft:lime_terracotta
fill 230 115 405 230 118 405 minecraft:moss_block
setblock 230 115 409 minecraft:lime_terracotta
fill 188 116 373 188 117 374 minecraft:lime_terracotta
fill 188 116 375 188 121 376 minecraft:moss_block
setblock 188 116 377 minecraft:lime_terracotta
fill 188 116 385 188 117 386 minecraft:lime_terracotta
fill 188 116 387 188 121 388 minecraft:moss_block
fill 188 116 394 188 117 394 minecraft:lime_terracotta
fill 188 116 396 188 121 396 minecraft:moss_block
fill 188 116 397 188 116 398 minecraft:lime_terracotta
fill 188 116 399 188 121 399 minecraft:moss_block
fill 188 116 405 188 117 406 minecraft:lime_terracotta
fill 188 116 407 188 121 408 minecraft:moss_block
fill 193 116 411 193 117 411 minecraft:moss_block
fill 194 116 369 194 121 369 minecraft:moss_block
fill 194 116 411 195 116 411 minecraft:lime_terracotta
fill 195 116 369 196 116 369 minecraft:lime_terracotta
fill 196 116 411 197 121 411 minecraft:moss_block
fill 197 116 369 197 121 369 minecraft:moss_block
fill 199 116 369 199 117 369 minecraft:lime_terracotta
fill 202 116 411 203 117 411 minecraft:lime_terracotta
fill 204 116 411 205 121 411 minecraft:moss_block
fill 205 116 369 206 121 369 minecraft:moss_block
setblock 206 116 411 minecraft:lime_terracotta
fill 207 116 369 208 117 369 minecraft:lime_terracotta
fill 208 116 411 208 118 411 minecraft:moss_block
fill 214 116 411 215 117 411 minecraft:lime_terracotta
setblock 216 116 369 minecraft:lime_terracotta
fill 216 116 411 217 121 411 minecraft:moss_block
fill 217 116 369 218 121 369 minecraft:moss_block
fill 219 116 369 220 117 369 minecraft:lime_terracotta
setblock 222 116 411 minecraft:moss_block
fill 223 116 411 223 117 411 minecraft:lime_terracotta
fill 225 116 369 226 121 369 minecraft:moss_block
fill 225 116 411 225 121 411 minecraft:moss_block
fill 226 116 411 227 116 411 minecraft:lime_terracotta
fill 227 116 369 228 116 369 minecraft:lime_terracotta
fill 228 116 411 228 121 411 minecraft:moss_block
fill 229 116 369 229 121 369 minecraft:moss_block
fill 230 116 376 230 121 377 minecraft:moss_block
fill 230 116 378 230 117 379 minecraft:lime_terracotta
fill 230 116 385 230 121 385 minecraft:moss_block
setblock 230 116 387 minecraft:lime_terracotta
fill 230 116 388 230 121 389 minecraft:moss_block
fill 230 116 390 230 117 390 minecraft:lime_terracotta
fill 230 116 396 230 121 397 minecraft:moss_block
fill 230 116 398 230 116 399 minecraft:lime_terracotta
fill 230 116 408 230 121 409 minecraft:moss_block
fill 230 116 410 230 117 410 minecraft:lime_terracotta
fill 188 117 377 188 120 377 minecraft:moss_block
setblock 188 117 382 minecraft:lime_terracotta
setblock 188 117 393 minecraft:lime_terracotta
fill 188 117 397 188 120 398 minecraft:moss_block
fill 190 117 411 191 117 411 minecraft:lime_terracotta
setblock 194 117 411 minecraft:lime_terracotta
fill 195 117 369 196 120 369 minecraft:moss_block
fill 195 117 411 195 120 411 minecraft:moss_block
setblock 200 117 369 minecraft:lime_terracotta
fill 206 117 411 206 120 411 minecraft:moss_block
fill 210 117 411 210 119 411 minecraft:moss_block
setblock 211 117 369 minecraft:lime_terracotta
setblock 211 117 411 minecraft:lime_terracotta
fill 216 117 369 216 120 369 minecraft:moss_block
setblock 222 117 411 minecraft:lime_terracotta
fill 226 117 411 227 120 411 minecraft:moss_block
fill 227 117 369 227 120 369 minecraft:moss_block
setblock 228 117 369 minecraft:lime_terracotta
fill 230 117 370 230 117 371 minecraft:lime_terracotta
fill 230 117 387 230 120 387 minecraft:moss_block
setblock 230 117 391 minecraft:lime_terracotta
fill 230 117 398 230 120 398 minecraft:moss_block
setblock 230 117 399 minecraft:lime_terracotta
setblock 230 117 402 minecraft:lime_terracotta
fill 188 118 371 188 119 372 minecraft:lime_terracotta
fill 188 118 373 188 123 374 minecraft:moss_block
fill 188 118 382 188 123 382 minecraft:moss_block
fill 188 118 383 188 118 384 minecraft:lime_terracotta
fill 188 118 385 188 123 386 minecraft:moss_block
fill 188 118 391 188 119 392 minecraft:lime_terracotta
fill 188 118 393 188 123 394 minecraft:moss_block
setblock 188 118 395 minecraft:lime_terracotta
fill 188 118 403 188 119 404 minecraft:lime_terracotta
fill 188 118 405 188 123 406 minecraft:moss_block
fill 189 118 369 190 119 369 minecraft:lime_terracotta
fill 189 118 411 189 119 411 minecraft:lime_terracotta
fill 190 118 411 191 119 411 minecraft:moss_block
fill 192 118 411 193 118 411 minecraft:lime_terracotta
fill 194 118 411 194 123 411 minecraft:moss_block
setblock 198 118 369 minecraft:lime_terracotta
fill 199 118 369 200 123 369 minecraft:moss_block
fill 200 118 411 201 119 411 minecraft:lime_terracotta
fill 201 118 369 202 119 369 minecraft:lime_terracotta
fill 202 118 411 203 123 411 minecraft:moss_block
fill 207 118 369 208 123 369 minecraft:moss_block
fill 209 118 369 210 118 369 minecraft:lime_terracotta
fill 211 118 369 211 123 369 minecraft:moss_block
fill 211 118 411 211 119 411 minecraft:moss_block
fill 212 118 411 213 118 411 minecraft:lime_terracotta
fill 214 118 411 215 123 411 minecraft:moss_block
fill 219 118 369 220 123 369 minecraft:moss_block
fill 220 118 411 221 119 411 minecraft:lime_terracotta
fill 221 118 369 222 119 369 minecraft:lime_terracotta
fill 222 118 411 223 123 411 minecraft:moss_block
setblock 224 118 411 minecraft:lime_terracotta
fill 228 118 369 228 123 369 minecraft:moss_block
setblock 230 118 369 minecraft:lime_terracotta
fill 230 118 370 230 123 371 minecraft:moss_block
fill 230 118 372 230 119 372 minecraft:lime_terracotta
fill 230 118 378 230 123 379 minecraft:moss_block
fill 230 118 380 230 118 381 minecraft:lime_terracotta
fill 230 118 390 230 123 391 minecraft:moss_block
fill 230 118 392 230 119 393 minecraft:lime_terracotta
fill 230 118 399 230 123 399 minecraft:moss_block
fill 230 118 400 230 118 401 minecraft:lime_terracotta
fill 230 118 402 230 123 402 minecraft:moss_block
fill 230 118 404 230 119 404 minecraft:lime_terracotta
fill 230 118 410 230 123 410 minecraft:moss_block
fill 188 119 379 188 119 380 minecraft:lime_terracotta
setblock 188 119 383 minecraft:lime_terracotta
fill 188 119 384 188 122 384 minecraft:moss_block
fill 188 119 395 188 122 395 minecraft:moss_block
setblock 188 119 400 minecraft:lime_terracotta
setblock 188 119 411 minecraft:lime_terracotta
setblock 191 119 372 minecraft:light[level=14]
setblock 191 119 388 minecraft:light[level=14]
setblock 191 119 396 minecraft:light[level=14]
setblock 191 119 404 minecraft:light[level=14]
fill 192 119 411 193 121 411 minecraft:moss_block
setblock 193 119 369 minecraft:lime_terracotta
fill 198 119 369 198 122 369 minecraft:moss_block
setblock 199 119 372 minecraft:light[level=14]
setblock 199 119 380 minecraft:light[level=14]
setblock 199 119 388 minecraft:light[level=14]
setblock 199 119 396 minecraft:light[level=14]
setblock 199 119 404 minecraft:light[level=14]
setblock 207 119 372 minecraft:light[level=14]
setblock 207 119 380 minecraft:light[level=14]
setblock 207 119 388 minecraft:light[level=14]
setblock 207 119 396 minecraft:light[level=14]
setblock 207 119 404 minecraft:light[level=14]
fill 208 119 411 209 119 411 minecraft:lime_terracotta
fill 209 119 369 209 122 369 minecraft:moss_block
setblock 210 119 369 minecraft:lime_terracotta
setblock 212 119 411 minecraft:lime_terracotta
fill 213 119 369 214 119 369 minecraft:lime_terracotta
fill 213 119 411 213 122 411 minecraft:moss_block
setblock 215 119 372 minecraft:light[level=14]
setblock 215 119 380 minecraft:light[level=14]
setblock 215 119 388 minecraft:light[level=14]
setblock 215 119 396 minecraft:light[level=14]
setblock 215 119 404 minecraft:light[level=14]
setblock 223 119 372 minecraft:light[level=14]
setblock 223 119 380 minecraft:light[level=14]
setblock 223 119 388 minecraft:light[level=14]
setblock 223 119 396 minecraft:light[level=14]
setblock 223 119 404 minecraft:light[level=14]
fill 224 119 411 224 122 411 minecraft:moss_block
fill 225 119 385 225 126 385 minecraft:mangrove_leaves[persistent=true]
setblock 229 119 411 minecraft:lime_terracotta
fill 230 119 369 230 122 369 minecraft:moss_block
setblock 230 119 373 minecraft:lime_terracotta
fill 230 119 380 230 122 380 minecraft:moss_block
setblock 230 119 381 minecraft:lime_terracotta
setblock 230 119 384 minecraft:lime_terracotta
fill 230 119 400 230 122 401 minecraft:moss_block
setblock 230 119 405 minecraft:lime_terracotta
fill 188 120 369 188 120 370 minecraft:lime_terracotta
fill 188 120 371 188 125 372 minecraft:moss_block
fill 188 120 378 188 121 378 minecraft:lime_terracotta
fill 188 120 379 188 125 380 minecraft:moss_block
setblock 188 120 381 minecraft:lime_terracotta
fill 188 120 383 188 125 383 minecraft:moss_block
fill 188 120 389 188 121 390 minecraft:lime_terracotta
fill 188 120 391 188 125 392 minecraft:moss_block
fill 188 120 400 188 125 400 minecraft:moss_block
fill 188 120 401 188 120 402 minecraft:lime_terracotta
fill 188 120 403 188 122 404 minecraft:moss_block
fill 188 120 409 188 121 410 minecraft:lime_terracotta
fill 188 120 411 189 125 411 minecraft:moss_block
fill 189 120 369 190 125 369 minecraft:moss_block
fill 189 120 370 191 120 370 minecraft:mud
fill 189 120 372 189 120 374 minecraft:mud
fill 189 120 376 189 120 377 minecraft:mud
fill 189 120 380 189 120 382 minecraft:mud
fill 189 120 384 189 120 386 minecraft:mud
fill 189 120 388 189 120 390 minecraft:mud
fill 189 120 392 189 120 394 minecraft:mud
fill 189 120 396 189 120 398 minecraft:mud
fill 189 120 400 189 120 402 minecraft:mud
fill 189 120 404 189 120 406 minecraft:mud
fill 189 120 408 189 120 410 minecraft:mud
setblock 190 120 411 minecraft:lime_terracotta
fill 191 120 369 192 120 369 minecraft:lime_terracotta
fill 191 120 410 193 120 410 minecraft:mud
fill 191 120 411 191 123 411 minecraft:moss_block
fill 193 120 369 193 125 369 minecraft:moss_block
fill 193 120 370 195 120 370 minecraft:mud
fill 195 120 410 197 120 410 minecraft:mud
fill 197 120 370 199 120 370 minecraft:mud
fill 198 120 411 199 121 411 minecraft:lime_terracotta
fill 199 120 410 201 120 410 minecraft:mud
fill 200 120 411 201 125 411 minecraft:moss_block
fill 201 120 369 202 125 369 minecraft:moss_block
fill 201 120 370 203 120 370 minecraft:mud
fill 203 120 369 204 121 369 minecraft:lime_terracotta
fill 203 120 410 205 120 410 minecraft:mud
fill 205 120 370 207 120 370 minecraft:mud
fill 207 120 410 209 120 410 minecraft:mud
fill 207 120 411 207 121 411 minecraft:lime_terracotta
fill 208 120 411 209 121 411 minecraft:moss_block
fill 209 120 370 211 120 370 minecraft:mud
fill 210 120 369 210 125 369 minecraft:moss_block
fill 210 120 411 211 120 411 minecraft:lime_terracotta
fill 211 120 410 213 120 410 minecraft:mud
setblock 212 120 369 minecraft:lime_terracotta
fill 212 120 411 212 125 411 minecraft:moss_block
fill 213 120 369 214 125 369 minecraft:moss_block
fill 213 120 370 215 120 370 minecraft:mud
fill 215 120 369 215 121 369 minecraft:lime_terracotta
fill 215 120 410 217 120 410 minecraft:mud
fill 217 120 370 219 120 370 minecraft:mud
fill 218 120 411 219 121 411 minecraft:lime_terracotta
fill 219 120 410 221 120 410 minecraft:mud
fill 220 120 411 221 125 411 minecraft:moss_block
fill 221 120 369 222 125 369 minecraft:moss_block
fill 221 120 370 223 120 370 minecraft:mud
fill 223 120 369 224 120 369 minecraft:lime_terracotta
fill 223 120 410 225 120 410 minecraft:mud
fill 225 120 370 227 120 370 minecraft:mud
fill 227 120 410 229 120 410 minecraft:mud
fill 229 120 370 229 120 372 minecraft:mud
fill 229 120 374 229 120 376 minecraft:mud
fill 229 120 378 229 120 380 minecraft:mud
fill 229 120 382 229 120 384 minecraft:mud
fill 229 120 386 229 120 388 minecraft:mud
fill 229 120 390 229 120 392 minecraft:mud
fill 229 120 394 229 120 396 minecraft:mud
fill 229 120 398 229 120 400 minecraft:mud
fill 229 120 402 229 120 404 minecraft:mud
fill 229 120 406 229 120 408 minecraft:mud
fill 229 120 411 229 125 411 minecraft:moss_block
fill 230 120 372 230 125 373 minecraft:moss_block
fill 230 120 374 230 121 375 minecraft:lime_terracotta
fill 230 120 381 230 125 381 minecraft:moss_block
fill 230 120 382 230 120 383 minecraft:lime_terracotta
fill 230 120 384 230 125 384 minecraft:moss_block
fill 230 120 386 230 121 386 minecraft:lime_terracotta
fill 230 120 392 230 125 393 minecraft:moss_block
fill 230 120 394 230 121 395 minecraft:lime_terracotta
setblock 230 120 403 minecraft:lime_terracotta
fill 230 120 404 230 125 405 minecraft:moss_block
fill 230 120 406 230 121 407 minecraft:lime_terracotta
fill 230 120 411 230 121 411 minecraft:lime_terracotta
setblock 188 121 369 minecraft:lime_terracotta
fill 188 121 370 188 124 370 minecraft:moss_block
setblock 188 121 377 minecraft:lime_terracotta
fill 188 121 381 188 124 381 minecraft:moss_block
fill 188 121 397 188 121 398 minecraft:lime_terracotta
setblock 188 121 401 minecraft:lime_terracotta
fill 188 121 402 188 124 402 minecraft:moss_block
fill 190 121 411 190 123 411 minecraft:moss_block
fill 191 121 369 191 124 369 minecraft:moss_block
setblock 192 121 369 minecraft:lime_terracotta
fill 195 121 369 196 121 369 minecraft:lime_terracotta
setblock 195 121 411 minecraft:lime_terracotta
setblock 206 121 411 minecraft:lime_terracotta
fill 210 121 411 211 123 411 minecraft:moss_block
fill 212 121 369 212 124 369 minecraft:moss_block
setblock 216 121 369 minecraft:lime_terracotta
fill 223 121 369 223 124 369 minecraft:moss_block
setblock 224 121 369 minecraft:lime_terracotta
fill 226 121 411 227 121 411 minecraft:lime_terracotta
setblock 227 121 369 minecraft:lime_terracotta
fill 230 121 382 230 124 383 minecraft:moss_block
setblock 230 121 387 minecraft:lime_terracotta
setblock 230 121 398 minecraft:lime_terracotta
fill 230 121 403 230 124 403 minecraft:moss_block
fill 188 122 369 188 127 369 minecraft:moss_block
fill 188 122 375 188 123 376 minecraft:lime_terracotta
fill 188 122 377 188 127 378 minecraft:moss_block
fill 188 122 387 188 122 388 minecraft:lime_terracotta
fill 188 122 389 188 127 390 minecraft:moss_block
fill 188 122 396 188 123 396 minecraft:lime_terracotta
fill 188 122 397 188 127 398 minecraft:moss_block
setblock 188 122 399 minecraft:lime_terracotta
fill 188 122 401 188 124 401 minecraft:moss_block
fill 188 122 407 188 123 408 minecraft:lime_terracotta
fill 188 122 409 188 127 410 minecraft:moss_block
fill 192 122 369 192 127 369 minecraft:moss_block
setblock 192 122 411 minecraft:moss_block
fill 193 122 411 193 123 411 minecraft:lime_terracotta
setblock 194 122 369 minecraft:lime_terracotta
fill 195 122 369 196 127 369 minecraft:moss_block
fill 195 122 411 195 127 411 minecraft:moss_block
fill 196 122 411 197 122 411 minecraft:lime_terracotta
fill 197 122 369 197 123 369 minecraft:lime_terracotta
fill 198 122 411 199 124 411 minecraft:moss_block
fill 203 122 369 204 127 369 minecraft:moss_block
fill 204 122 411 205 123 411 minecraft:lime_terracotta
fill 205 122 369 206 122 369 minecraft:lime_terracotta
fill 206 122 411 207 127 411 minecraft:moss_block
setblock 208 122 411 minecraft:lime_terracotta
fill 209 122 411 209 125 411 minecraft:moss_block
fill 215 122 369 216 127 369 minecraft:moss_block
fill 216 122 411 217 122 411 minecraft:lime_terracotta
fill 217 122 369 218 123 369 minecraft:lime_terracotta
fill 218 122 411 219 127 411 minecraft:moss_block
fill 224 122 369 224 127 369 minecraft:moss_block
fill 225 122 369 226 122 369 minecraft:lime_terracotta
fill 225 122 411 225 123 411 minecraft:lime_terracotta
fill 226 122 411 227 127 411 minecraft:moss_block
fill 227 122 369 227 127 369 minecraft:moss_block
setblock 228 122 411 minecraft:lime_terracotta
fill 229 122 369 229 123 369 minecraft:lime_terracotta
fill 230 122 374 230 127 375 minecraft:moss_block
fill 230 122 376 230 123 377 minecraft:lime_terracotta
setblock 230 122 385 minecraft:lime_terracotta
fill 230 122 386 230 127 387 minecraft:moss_block
fill 230 122 388 230 123 389 minecraft:lime_terracotta
fill 230 122 394 230 127 395 minecraft:moss_block
fill 230 122 396 230 122 397 minecraft:lime_terracotta
fill 230 122 398 230 127 398 minecraft:moss_block
fill 230 122 406 230 127 407 minecraft:moss_block
fill 230 122 408 230 123 409 minecraft:lime_terracotta
fill 230 122 411 230 127 411 minecraft:moss_block
setblock 188 123 384 minecraft:lime_terracotta
setblock 188 123 387 minecraft:lime_terracotta
fill 188 123 388 188 126 388 minecraft:moss_block
setblock 188 123 395 minecraft:lime_terracotta
fill 188 123 399 188 126 399 minecraft:moss_block
fill 188 123 403 188 125 403 minecraft:moss_block
setblock 188 123 404 minecraft:lime_terracotta
setblock 192 123 411 minecraft:lime_terracotta
fill 194 123 369 194 126 369 minecraft:moss_block
setblock 196 123 411 minecraft:lime_terracotta
fill 197 123 411 197 126 411 minecraft:moss_block
setblock 198 123 369 minecraft:lime_terracotta
fill 205 123 369 205 126 369 minecraft:moss_block
setblock 206 123 369 minecraft:lime_terracotta
fill 208 123 411 208 125 411 minecraft:moss_block
setblock 209 123 369 minecraft:lime_terracotta
setblock 213 123 411 minecraft:lime_terracotta
setblock 216 123 411 minecraft:lime_terracotta
fill 217 123 411 217 126 411 minecraft:moss_block
setblock 224 123 411 minecraft:lime_terracotta
fill 225 123 369 226 126 369 minecraft:moss_block
fill 228 123 411 228 126 411 minecraft:moss_block
setblock 230 123 369 minecraft:lime_terracotta
setblock 230 123 380 minecraft:lime_terracotta
fill 230 123 385 230 126 385 minecraft:moss_block
fill 230 123 396 230 126 396 minecraft:moss_block
setblock 230 123 397 minecraft:lime_terracotta
fill 230 123 400 230 123 401 minecraft:lime_terracotta
fill 188 124 373 188 125 374 minecraft:lime_terracotta
fill 188 124 375 188 129 376 minecraft:moss_block
fill 188 124 382 188 125 382 minecraft:lime_terracotta
fill 188 124 384 188 129 384 minecraft:moss_block
fill 188 124 385 188 124 386 minecraft:lime_terracotta
fill 188 124 387 188 129 387 minecraft:moss_block
fill 188 124 393 188 125 394 minecraft:lime_terracotta
fill 188 124 395 188 129 396 minecraft:moss_block
fill 188 124 404 188 125 404 minecraft:moss_block
fill 188 124 405 188 124 406 minecraft:lime_terracotta
fill 188 124 407 188 129 408 minecraft:moss_block
fill 190 124 411 191 125 411 minecraft:lime_terracotta
fill 192 124 411 193 129 411 minecraft:moss_block
setblock 194 124 411 minecraft:lime_terracotta
fill 196 124 411 196 126 411 minecraft:moss_block
fill 197 124 369 198 129 369 minecraft:moss_block
fill 199 124 369 200 125 369 minecraft:lime_terracotta
fill 202 124 411 203 125 411 minecraft:lime_terracotta
fill 204 124 411 205 129 411 minecraft:moss_block
fill 206 124 369 206 129 369 minecraft:moss_block
fill 207 124 369 208 124 369 minecraft:lime_terracotta
fill 209 124 369 209 129 369 minecraft:moss_block
setblock 210 124 411 minecraft:moss_block
fill 211 124 369 211 125 369 minecraft:lime_terracotta
fill 211 124 411 211 125 411 minecraft:lime_terracotta
fill 213 124 411 213 129 411 minecraft:moss_block
fill 214 124 411 215 124 411 minecraft:lime_terracotta
fill 216 124 411 216 129 411 minecraft:moss_block
fill 217 124 369 218 129 369 minecraft:moss_block
fill 218 124 402 220 125 402 minecraft:lime_concrete
fill 219 124 369 220 125 369 minecraft:lime_terracotta
fill 219 124 403 220 125 403 minecraft:lime_concrete
fill 222 124 411 223 125 411 minecraft:lime_terracotta
fill 224 124 411 225 129 411 minecraft:moss_block
setblock 228 124 369 minecraft:lime_terracotta
fill 229 124 369 230 129 369 minecraft:moss_block
fill 230 124 370 230 125 371 minecraft:lime_terracotta
fill 230 124 376 230 129 377 minecraft:moss_block
fill 230 124 378 230 124 379 minecraft:lime_terracotta
fill 230 124 380 230 129 380 minecraft:moss_block
fill 230 124 388 230 129 389 minecraft:moss_block
fill 230 124 390 230 125 391 minecraft:lime_terracotta
fill 230 124 397 230 129 397 minecraft:moss_block
setblock 230 124 399 minecraft:lime_terracotta
fill 230 124 400 230 129 401 minecraft:moss_block
fill 230 124 402 230 125 402 minecraft:lime_terracotta
fill 230 124 408 230 129 409 minecraft:moss_block
setblock 230 124 410 minecraft:lime_terracotta
setblock 188 125 370 minecraft:lime_terracotta
setblock 188 125 381 minecraft:lime_terracotta
fill 188 125 385 188 128 386 minecraft:moss_block
fill 188 125 401 188 125 402 minecraft:lime_terracotta
setblock 188 125 405 minecraft:lime_terracotta
fill 188 125 406 188 128 406 minecraft:moss_block
setblock 191 125 369 minecraft:lime_terracotta
fill 194 125 411 194 128 411 minecraft:moss_block
fill 198 125 411 198 127 411 minecraft:moss_block
setblock 199 125 411 minecraft:lime_terracotta
fill 207 125 369 208 128 369 minecraft:moss_block
setblock 210 125 411 minecraft:lime_terracotta
setblock 212 125 369 minecraft:lime_terracotta
fill 214 125 411 215 128 411 minecraft:moss_block
setblock 223 125 369 minecraft:lime_terracotta
fill 228 125 369 228 128 369 minecraft:moss_block
fill 230 125 378 230 128 378 minecraft:moss_block
setblock 230 125 379 minecraft:lime_terracotta
fill 230 125 382 230 125 383 minecraft:lime_terracotta
fill 230 125 399 230 128 399 minecraft:moss_block
setblock 230 125 403 minecraft:lime_terracotta
fill 230 125 410 230 128 410 minecraft:moss_block
fill 188 126 370 188 131 370 minecraft:moss_block
fill 188 126 371 188 126 372 minecraft:lime_terracotta
fill 188 126 373 188 131 374 minecraft:moss_block
fill 188 126 379 188 127 380 minecraft:lime_terracotta
fill 188 126 381 188 131 382 minecraft:moss_block
setblock 188 126 383 minecraft:lime_terracotta
fill 188 126 391 188 127 392 minecraft:lime_terracotta
fill 188 126 393 188 131 394 minecraft:moss_block
fill 188 126 400 188 127 400 minecraft:lime_terracotta
fill 188 126 401 188 127 402 minecraft:moss_block
fill 188 126 403 188 126 404 minecraft:lime_terracotta
fill 188 126 405 188 131 405 minecraft:moss_block
fill 188 126 411 189 127 411 minecraft:lime_terracotta
fill 189 126 369 190 126 369 minecraft:lime_terracotta
fill 189 126 370 191 126 370 minecraft:mud
fill 189 126 372 189 126 374 minecraft:mud
fill 189 126 376 189 126 377 minecraft:mud
fill 189 126 380 189 126 382 minecraft:mud
fill 189 126 384 189 126 386 minecraft:mud
fill 189 126 388 189 126 390 minecraft:mud
fill 189 126 392 189 126 394 minecraft:mud
fill 189 126 396 189 126 398 minecraft:mud
fill 189 126 400 189 126 402 minecraft:mud
fill 189 126 404 189 126 406 minecraft:mud
fill 189 126 408 189 126 410 minecraft:mud
fill 190 126 411 191 131 411 minecraft:moss_block
fill 191 126 369 191 131 369 minecraft:moss_block
fill 191 126 410 193 126 410 minecraft:mud
fill 193 126 369 193 127 369 minecraft:lime_terracotta
fill 193 126 370 195 126 370 minecraft:mud
fill 195 126 410 197 126 410 minecraft:mud
fill 197 126 370 199 126 370 minecraft:mud
fill 199 126 369 200 131 369 minecraft:moss_block
fill 199 126 410 201 126 410 minecraft:mud
fill 199 126 411 199 127 411 minecraft:moss_block
fill 200 126 411 201 126 411 minecraft:lime_terracotta
fill 201 126 369 202 127 369 minecraft:lime_terracotta
fill 201 126 370 203 126 370 minecraft:mud
fill 202 126 411 203 131 411 minecraft:moss_block
fill 203 126 410 205 126 410 minecraft:mud
fill 205 126 370 207 126 370 minecraft:mud
fill 207 126 410 209 126 410 minecraft:mud
fill 208 126 411 209 127 411 minecraft:lime_terracotta
fill 209 126 370 211 126 370 minecraft:mud
setblock 210 126 369 minecraft:lime_terracotta
fill 210 126 411 211 131 411 minecraft:moss_block
fill 211 126 369 212 131 369 minecraft:moss_block
fill 211 126 410 213 126 410 minecraft:mud
setblock 212 126 411 minecraft:lime_terracotta
fill 213 126 369 214 127 369 minecraft:lime_terracotta
fill 213 126 370 215 126 370 minecraft:mud
fill 215 126 410 217 126 410 minecraft:mud
fill 217 126 370 219 126 370 minecraft:mud
fill 219 126 369 220 131 369 minecraft:moss_block
fill 219 126 410 221 126 410 minecraft:mud
fill 220 126 411 221 127 411 minecraft:lime_terracotta
fill 221 126 369 222 126 369 minecraft:lime_terracotta
fill 221 126 370 223 126 370 minecraft:mud
fill 222 126 411 223 131 411 minecraft:moss_block
fill 223 126 369 223 131 369 minecraft:moss_block
fill 223 126 410 225 126 410 minecraft:mud
schedule function dropper:buildpart/88_3 1t
