setblock 176 197 333 minecraft:light[level=13]
setblock 176 197 341 minecraft:light[level=13]
setblock 176 197 349 minecraft:light[level=13]
setblock 176 197 357 minecraft:light[level=13]
setblock 177 197 322 minecraft:light_blue_wool
setblock 179 197 325 minecraft:light[level=12]
setblock 179 197 332 minecraft:light[level=12]
setblock 179 197 339 minecraft:light[level=12]
setblock 179 197 346 minecraft:light[level=12]
setblock 179 197 353 minecraft:light[level=12]
setblock 179 197 360 minecraft:light[level=12]
setblock 179 197 363 minecraft:purple_concrete
setblock 180 197 335 minecraft:dark_prismarine
fill 180 197 336 180 200 336 minecraft:blue_terracotta
setblock 181 197 329 minecraft:dark_prismarine
fill 181 197 330 181 200 330 minecraft:blue_terracotta
setblock 181 197 334 minecraft:dark_prismarine
fill 181 197 335 181 200 335 minecraft:blue_terracotta
setblock 181 197 339 minecraft:dark_prismarine
fill 181 197 340 181 200 340 minecraft:blue_terracotta
setblock 181 197 354 minecraft:dark_prismarine
fill 181 197 355 181 197 356 minecraft:blue_terracotta
setblock 182 197 323 minecraft:dark_prismarine
fill 182 197 324 182 200 324 minecraft:blue_terracotta
setblock 182 197 328 minecraft:dark_prismarine
fill 182 197 329 182 200 329 minecraft:blue_terracotta
setblock 182 197 333 minecraft:dark_prismarine
fill 182 197 334 182 200 334 minecraft:blue_terracotta
setblock 182 197 338 minecraft:dark_prismarine
fill 182 197 339 182 200 339 minecraft:blue_terracotta
setblock 182 197 343 minecraft:dark_prismarine
fill 182 197 344 182 200 344 minecraft:blue_terracotta
setblock 182 197 348 minecraft:dark_prismarine
fill 182 197 349 182 198 349 minecraft:blue_terracotta
setblock 182 197 353 minecraft:dark_prismarine
fill 182 197 354 182 200 354 minecraft:blue_terracotta
setblock 182 197 358 minecraft:dark_prismarine
fill 182 197 359 182 200 359 minecraft:blue_terracotta
setblock 182 197 362 minecraft:blue_terracotta
fill 183 197 333 183 220 333 minecraft:blue_terracotta
setblock 141 198 331 minecraft:cyan_concrete
fill 142 198 323 142 200 324 minecraft:blue_terracotta
setblock 142 198 327 minecraft:dark_prismarine
fill 142 198 328 142 201 328 minecraft:blue_terracotta
setblock 142 198 332 minecraft:dark_prismarine
fill 142 198 333 142 198 336 minecraft:blue_terracotta
setblock 142 198 337 minecraft:dark_prismarine
fill 142 198 338 142 201 338 minecraft:blue_terracotta
setblock 142 198 342 minecraft:dark_prismarine
setblock 142 198 343 minecraft:purple_concrete
setblock 142 198 352 minecraft:dark_prismarine
fill 142 198 353 142 201 353 minecraft:blue_terracotta
setblock 142 198 357 minecraft:dark_prismarine
fill 142 198 358 142 201 358 minecraft:blue_terracotta
setblock 142 198 361 minecraft:blue_terracotta
setblock 142 198 362 minecraft:dark_prismarine
fill 142 198 363 142 201 363 minecraft:blue_terracotta
fill 143 198 324 144 198 324 minecraft:blue_terracotta
setblock 143 198 326 minecraft:dark_prismarine
fill 143 198 327 143 201 327 minecraft:blue_terracotta
setblock 143 198 331 minecraft:dark_prismarine
fill 143 198 332 143 201 332 minecraft:blue_terracotta
setblock 143 198 336 minecraft:dark_prismarine
fill 143 198 337 143 201 337 minecraft:blue_terracotta
setblock 143 198 356 minecraft:dark_prismarine
fill 143 198 357 143 201 357 minecraft:blue_terracotta
setblock 143 198 361 minecraft:dark_prismarine
fill 143 198 362 143 201 362 minecraft:blue_terracotta
setblock 144 198 330 minecraft:dark_prismarine
setblock 144 198 331 minecraft:blue_terracotta
setblock 144 198 335 minecraft:dark_prismarine
fill 144 198 336 144 199 336 minecraft:blue_terracotta
setblock 145 198 324 minecraft:dark_prismarine
fill 146 198 322 146 220 322 minecraft:blue_terracotta
setblock 146 198 323 minecraft:dark_prismarine
setblock 146 198 363 minecraft:dark_prismarine
fill 147 198 323 148 200 323 minecraft:blue_terracotta
setblock 147 198 362 minecraft:dark_prismarine
fill 147 198 363 147 201 363 minecraft:blue_terracotta
fill 148 198 362 148 201 362 minecraft:blue_terracotta
setblock 151 198 363 minecraft:dark_prismarine
fill 152 198 363 152 201 363 minecraft:blue_terracotta
setblock 155 198 363 minecraft:blue_terracotta
setblock 156 198 363 minecraft:dark_prismarine
fill 157 198 363 160 198 363 minecraft:blue_terracotta
setblock 158 198 323 minecraft:purple_concrete
fill 158 198 362 158 201 362 minecraft:blue_terracotta
fill 160 198 361 160 200 361 minecraft:blue_terracotta
setblock 161 198 363 minecraft:dark_prismarine
setblock 162 198 362 minecraft:dark_prismarine
fill 162 198 363 162 201 363 minecraft:blue_terracotta
setblock 163 198 361 minecraft:dark_prismarine
fill 163 198 362 163 201 362 minecraft:blue_terracotta
fill 164 198 361 164 201 361 minecraft:blue_terracotta
setblock 166 198 363 minecraft:dark_prismarine
fill 167 198 363 167 201 363 minecraft:blue_terracotta
fill 177 198 322 177 220 322 minecraft:blue_terracotta
setblock 180 198 334 minecraft:dark_prismarine
fill 180 198 335 180 201 335 minecraft:blue_terracotta
fill 180 198 337 180 198 338 minecraft:blue_terracotta
setblock 180 198 339 minecraft:dark_prismarine
fill 181 198 329 181 201 329 minecraft:blue_terracotta
setblock 181 198 333 minecraft:dark_prismarine
fill 181 198 334 181 201 334 minecraft:blue_terracotta
setblock 181 198 337 minecraft:blue_terracotta
setblock 181 198 338 minecraft:dark_prismarine
fill 181 198 339 181 201 339 minecraft:blue_terracotta
fill 182 198 323 182 201 323 minecraft:blue_terracotta
setblock 182 198 327 minecraft:dark_prismarine
fill 182 198 328 182 201 328 minecraft:blue_terracotta
setblock 182 198 332 minecraft:dark_prismarine
fill 182 198 333 182 201 333 minecraft:blue_terracotta
setblock 182 198 337 minecraft:dark_prismarine
fill 182 198 338 182 201 338 minecraft:blue_terracotta
setblock 182 198 342 minecraft:dark_prismarine
fill 182 198 343 182 201 343 minecraft:blue_terracotta
setblock 182 198 352 minecraft:dark_prismarine
fill 182 198 353 182 201 353 minecraft:blue_terracotta
setblock 182 198 357 minecraft:dark_prismarine
fill 182 198 358 182 201 358 minecraft:blue_terracotta
setblock 182 198 362 minecraft:dark_prismarine
fill 141 199 331 141 220 331 minecraft:blue_terracotta
setblock 142 199 325 minecraft:blue_terracotta
setblock 142 199 326 minecraft:dark_prismarine
fill 142 199 327 142 202 327 minecraft:blue_terracotta
setblock 142 199 331 minecraft:dark_prismarine
fill 142 199 332 142 199 335 minecraft:blue_terracotta
setblock 142 199 336 minecraft:dark_prismarine
fill 142 199 337 142 202 337 minecraft:blue_terracotta
setblock 142 199 341 minecraft:dark_prismarine
fill 142 199 342 142 202 342 minecraft:blue_terracotta
setblock 142 199 349 minecraft:purple_concrete
setblock 142 199 356 minecraft:dark_prismarine
fill 142 199 357 142 202 357 minecraft:blue_terracotta
setblock 142 199 361 minecraft:dark_prismarine
fill 142 199 362 142 202 362 minecraft:blue_terracotta
setblock 143 199 324 minecraft:blue_terracotta
setblock 143 199 325 minecraft:dark_prismarine
fill 143 199 326 143 202 326 minecraft:blue_terracotta
setblock 143 199 330 minecraft:dark_prismarine
fill 143 199 331 143 202 331 minecraft:blue_terracotta
setblock 143 199 335 minecraft:dark_prismarine
fill 143 199 336 143 202 336 minecraft:blue_terracotta
setblock 143 199 340 minecraft:dark_prismarine
setblock 143 199 355 minecraft:dark_prismarine
fill 143 199 356 143 202 356 minecraft:blue_terracotta
setblock 143 199 360 minecraft:dark_prismarine
fill 143 199 361 143 202 361 minecraft:blue_terracotta
setblock 144 199 324 minecraft:dark_prismarine
setblock 144 199 334 minecraft:dark_prismarine
setblock 144 199 335 minecraft:blue_terracotta
setblock 144 199 359 minecraft:dark_prismarine
setblock 145 199 323 minecraft:dark_prismarine
setblock 145 199 363 minecraft:dark_prismarine
fill 146 199 323 146 202 323 minecraft:blue_terracotta
setblock 146 199 362 minecraft:dark_prismarine
fill 146 199 363 146 202 363 minecraft:blue_terracotta
fill 147 199 362 147 202 362 minecraft:blue_terracotta
setblock 150 199 363 minecraft:dark_prismarine
fill 151 199 363 151 202 363 minecraft:blue_terracotta
setblock 152 199 323 minecraft:purple_concrete
fill 153 199 363 154 199 363 minecraft:blue_terracotta
setblock 155 199 363 minecraft:dark_prismarine
fill 156 199 363 159 199 363 minecraft:blue_terracotta
fill 157 199 362 157 202 362 minecraft:blue_terracotta
setblock 160 199 363 minecraft:dark_prismarine
setblock 161 199 362 minecraft:dark_prismarine
fill 161 199 363 161 202 363 minecraft:blue_terracotta
setblock 162 199 361 minecraft:dark_prismarine
fill 162 199 362 162 202 362 minecraft:blue_terracotta
fill 163 199 361 163 202 361 minecraft:blue_terracotta
setblock 165 199 363 minecraft:dark_prismarine
setblock 166 199 362 minecraft:dark_prismarine
fill 166 199 363 166 202 363 minecraft:blue_terracotta
setblock 172 199 363 minecraft:purple_concrete
setblock 177 199 323 minecraft:purple_concrete
setblock 180 199 333 minecraft:dark_prismarine
fill 180 199 334 180 202 334 minecraft:blue_terracotta
setblock 180 199 337 minecraft:blue_terracotta
setblock 180 199 338 minecraft:dark_prismarine
fill 180 199 339 180 201 340 minecraft:blue_terracotta
fill 181 199 323 181 202 323 minecraft:blue_terracotta
fill 181 199 327 181 200 328 minecraft:dark_prismarine
setblock 181 199 332 minecraft:dark_prismarine
fill 181 199 333 181 202 333 minecraft:blue_terracotta
setblock 181 199 337 minecraft:dark_prismarine
fill 181 199 338 181 202 338 minecraft:blue_terracotta
setblock 181 199 342 minecraft:dark_prismarine
setblock 182 199 326 minecraft:dark_prismarine
fill 182 199 327 182 202 327 minecraft:blue_terracotta
setblock 182 199 331 minecraft:dark_prismarine
fill 182 199 332 182 202 332 minecraft:blue_terracotta
setblock 182 199 336 minecraft:dark_prismarine
fill 182 199 337 182 202 337 minecraft:blue_terracotta
setblock 182 199 341 minecraft:dark_prismarine
fill 182 199 342 182 202 342 minecraft:blue_terracotta
setblock 182 199 351 minecraft:dark_prismarine
setblock 182 199 352 minecraft:blue_terracotta
setblock 182 199 356 minecraft:dark_prismarine
fill 182 199 357 182 202 357 minecraft:blue_terracotta
setblock 182 199 360 minecraft:blue_terracotta
setblock 182 199 361 minecraft:dark_prismarine
fill 182 199 362 182 201 363 minecraft:blue_terracotta
fill 183 199 356 183 218 356 minecraft:blue_terracotta
setblock 142 200 325 minecraft:dark_prismarine
fill 142 200 326 142 203 326 minecraft:blue_terracotta
setblock 142 200 330 minecraft:dark_prismarine
fill 142 200 331 142 200 334 minecraft:blue_terracotta
setblock 142 200 335 minecraft:dark_prismarine
fill 142 200 336 142 203 336 minecraft:blue_terracotta
setblock 142 200 340 minecraft:dark_prismarine
fill 142 200 341 142 203 341 minecraft:blue_terracotta
fill 142 200 343 142 201 343 minecraft:blue_terracotta
setblock 142 200 355 minecraft:dark_prismarine
fill 142 200 356 142 203 356 minecraft:blue_terracotta
setblock 142 200 360 minecraft:dark_prismarine
fill 142 200 361 142 203 361 minecraft:blue_terracotta
setblock 143 200 324 minecraft:dark_prismarine
fill 143 200 325 143 203 325 minecraft:blue_terracotta
setblock 143 200 329 minecraft:dark_prismarine
fill 143 200 330 143 202 330 minecraft:blue_terracotta
setblock 143 200 334 minecraft:dark_prismarine
fill 143 200 335 143 203 335 minecraft:blue_terracotta
setblock 143 200 339 minecraft:dark_prismarine
fill 143 200 340 143 203 340 minecraft:blue_terracotta
setblock 143 200 355 minecraft:blue_terracotta
setblock 143 200 359 minecraft:dark_prismarine
fill 143 200 360 144 202 360 minecraft:blue_terracotta
setblock 144 200 323 minecraft:dark_prismarine
fill 144 200 324 144 203 324 minecraft:blue_terracotta
fill 144 200 328 144 203 328 minecraft:dark_prismarine
fill 144 200 359 144 203 359 minecraft:blue_terracotta
fill 144 200 361 144 201 361 minecraft:blue_terracotta
setblock 144 200 363 minecraft:dark_prismarine
fill 145 200 323 145 203 323 minecraft:blue_terracotta
setblock 145 200 362 minecraft:dark_prismarine
fill 145 200 363 145 203 363 minecraft:blue_terracotta
fill 146 200 362 146 203 362 minecraft:blue_terracotta
setblock 149 200 362 minecraft:blue_terracotta
setblock 149 200 363 minecraft:dark_prismarine
fill 150 200 363 150 203 363 minecraft:blue_terracotta
setblock 153 200 363 minecraft:blue_terracotta
setblock 154 200 363 minecraft:dark_prismarine
fill 154 200 364 154 220 364 minecraft:blue_terracotta
fill 155 200 363 158 200 363 minecraft:blue_terracotta
setblock 155 200 364 minecraft:cyan_concrete
fill 156 200 362 156 203 362 minecraft:blue_terracotta
fill 156 200 364 156 220 364 minecraft:blue_terracotta
fill 158 200 361 159 201 361 minecraft:blue_terracotta
setblock 159 200 363 minecraft:dark_prismarine
setblock 160 200 362 minecraft:dark_prismarine
fill 160 200 363 160 203 363 minecraft:blue_terracotta
setblock 161 200 361 minecraft:dark_prismarine
fill 161 200 362 161 203 362 minecraft:blue_terracotta
fill 162 200 355 162 201 355 minecraft:dark_prismarine
fill 162 200 361 162 203 361 minecraft:blue_terracotta
setblock 164 200 363 minecraft:dark_prismarine
setblock 165 200 362 minecraft:dark_prismarine
fill 165 200 363 165 203 363 minecraft:blue_terracotta
fill 166 200 362 166 203 362 minecraft:blue_terracotta
fill 169 200 355 169 233 355 minecraft:magenta_terracotta
setblock 171 200 323 minecraft:purple_concrete
fill 178 200 344 179 201 345 minecraft:spruce_planks
setblock 178 200 363 minecraft:purple_concrete
fill 179 200 322 179 217 322 minecraft:blue_terracotta
fill 179 200 328 180 202 328 minecraft:dark_prismarine
setblock 180 200 322 minecraft:light_blue_wool
fill 180 200 323 180 203 323 minecraft:blue_terracotta
fill 180 200 327 180 201 327 minecraft:dark_prismarine
fill 180 200 329 180 201 329 minecraft:dark_prismarine
fill 180 200 333 180 203 333 minecraft:blue_terracotta
setblock 180 200 337 minecraft:dark_prismarine
fill 180 200 338 180 203 338 minecraft:blue_terracotta
fill 180 200 363 181 202 363 minecraft:blue_terracotta
setblock 181 200 331 minecraft:dark_prismarine
fill 181 200 332 181 203 332 minecraft:blue_terracotta
setblock 181 200 336 minecraft:dark_prismarine
fill 181 200 337 181 203 337 minecraft:blue_terracotta
setblock 181 200 341 minecraft:dark_prismarine
fill 181 200 342 181 202 343 minecraft:blue_terracotta
setblock 182 200 325 minecraft:dark_prismarine
fill 182 200 326 182 203 326 minecraft:blue_terracotta
setblock 182 200 330 minecraft:dark_prismarine
fill 182 200 331 182 203 331 minecraft:blue_terracotta
setblock 182 200 335 minecraft:dark_prismarine
fill 182 200 336 182 203 336 minecraft:blue_terracotta
setblock 182 200 340 minecraft:dark_prismarine
fill 182 200 341 182 203 341 minecraft:blue_terracotta
setblock 182 200 345 minecraft:dark_prismarine
fill 182 200 346 182 203 346 minecraft:blue_terracotta
setblock 182 200 355 minecraft:dark_prismarine
fill 182 200 356 182 203 356 minecraft:blue_terracotta
setblock 182 200 360 minecraft:dark_prismarine
fill 182 200 361 182 203 361 minecraft:blue_terracotta
setblock 142 201 323 minecraft:blue_terracotta
setblock 142 201 324 minecraft:dark_prismarine
fill 142 201 325 142 204 325 minecraft:blue_terracotta
setblock 142 201 329 minecraft:dark_prismarine
fill 142 201 330 142 201 333 minecraft:blue_terracotta
setblock 142 201 334 minecraft:dark_prismarine
fill 142 201 335 142 204 335 minecraft:blue_terracotta
setblock 142 201 339 minecraft:dark_prismarine
fill 142 201 340 142 204 340 minecraft:blue_terracotta
setblock 142 201 354 minecraft:dark_prismarine
fill 142 201 355 142 204 355 minecraft:blue_terracotta
setblock 142 201 359 minecraft:dark_prismarine
fill 142 201 360 142 204 360 minecraft:blue_terracotta
setblock 143 201 323 minecraft:dark_prismarine
fill 143 201 324 143 204 324 minecraft:blue_terracotta
fill 143 201 328 143 202 328 minecraft:dark_prismarine
setblock 143 201 329 minecraft:blue_terracotta
setblock 143 201 333 minecraft:dark_prismarine
fill 143 201 334 143 204 334 minecraft:blue_terracotta
setblock 143 201 338 minecraft:dark_prismarine
fill 143 201 339 143 204 339 minecraft:blue_terracotta
setblock 143 201 358 minecraft:dark_prismarine
fill 143 201 359 143 204 359 minecraft:blue_terracotta
setblock 143 201 363 minecraft:dark_prismarine
fill 144 201 323 144 204 323 minecraft:blue_terracotta
fill 144 201 327 144 202 327 minecraft:dark_prismarine
fill 144 201 329 144 202 329 minecraft:dark_prismarine
setblock 144 201 362 minecraft:dark_prismarine
fill 144 201 363 144 204 363 minecraft:blue_terracotta
fill 145 201 328 145 203 328 minecraft:dark_prismarine
setblock 145 201 361 minecraft:dark_prismarine
fill 145 201 362 145 204 362 minecraft:blue_terracotta
setblock 147 201 323 minecraft:blue_terracotta
setblock 148 201 323 minecraft:dark_prismarine
setblock 148 201 363 minecraft:dark_prismarine
setblock 149 201 362 minecraft:dark_prismarine
fill 149 201 363 149 204 363 minecraft:blue_terracotta
fill 150 201 362 150 204 362 minecraft:blue_terracotta
setblock 153 201 363 minecraft:dark_prismarine
setblock 154 201 362 minecraft:dark_prismarine
fill 154 201 363 157 201 363 minecraft:blue_terracotta
fill 155 201 362 155 204 362 minecraft:blue_terracotta
fill 155 201 364 155 220 364 minecraft:blue_terracotta
fill 157 201 361 157 203 361 minecraft:blue_terracotta
setblock 158 201 363 minecraft:dark_prismarine
setblock 159 201 362 minecraft:dark_prismarine
fill 159 201 363 159 204 363 minecraft:blue_terracotta
setblock 160 201 361 minecraft:dark_prismarine
fill 160 201 362 160 204 362 minecraft:blue_terracotta
fill 161 201 361 161 204 361 minecraft:blue_terracotta
setblock 163 201 363 minecraft:dark_prismarine
setblock 164 201 362 minecraft:dark_prismarine
fill 164 201 363 164 204 363 minecraft:blue_terracotta
setblock 165 201 323 minecraft:purple_concrete
fill 165 201 362 165 204 362 minecraft:blue_terracotta
fill 178 201 328 178 203 328 minecraft:dark_prismarine
fill 179 201 323 179 204 323 minecraft:blue_terracotta
fill 179 201 327 179 202 327 minecraft:dark_prismarine
fill 179 201 329 179 202 329 minecraft:dark_prismarine
fill 179 201 363 179 204 363 minecraft:blue_terracotta
fill 180 201 322 180 220 322 minecraft:blue_terracotta
fill 180 201 332 180 204 332 minecraft:blue_terracotta
setblock 180 201 336 minecraft:dark_prismarine
fill 180 201 337 180 204 337 minecraft:blue_terracotta
setblock 180 201 341 minecraft:dark_prismarine
setblock 181 201 328 minecraft:dark_prismarine
setblock 181 201 330 minecraft:dark_prismarine
fill 181 201 331 181 204 331 minecraft:blue_terracotta
setblock 181 201 335 minecraft:dark_prismarine
fill 181 201 336 181 204 336 minecraft:blue_terracotta
setblock 181 201 340 minecraft:dark_prismarine
fill 181 201 341 181 204 341 minecraft:blue_terracotta
setblock 181 201 344 minecraft:blue_terracotta
fill 181 201 358 181 201 359 minecraft:blue_terracotta
setblock 181 201 360 minecraft:dark_prismarine
fill 181 201 361 181 204 361 minecraft:blue_terracotta
setblock 182 201 324 minecraft:dark_prismarine
fill 182 201 325 182 204 325 minecraft:blue_terracotta
setblock 182 201 329 minecraft:dark_prismarine
fill 182 201 330 182 204 330 minecraft:blue_terracotta
setblock 182 201 334 minecraft:dark_prismarine
fill 182 201 335 182 204 335 minecraft:blue_terracotta
setblock 182 201 339 minecraft:dark_prismarine
fill 182 201 340 182 204 340 minecraft:blue_terracotta
setblock 182 201 344 minecraft:dark_prismarine
fill 182 201 345 182 204 345 minecraft:blue_terracotta
setblock 182 201 350 minecraft:purple_concrete
setblock 182 201 354 minecraft:dark_prismarine
fill 182 201 355 182 204 355 minecraft:blue_terracotta
setblock 182 201 359 minecraft:dark_prismarine
fill 182 201 360 182 204 360 minecraft:blue_terracotta
setblock 142 202 323 minecraft:dark_prismarine
fill 142 202 324 142 205 324 minecraft:blue_terracotta
setblock 142 202 328 minecraft:dark_prismarine
fill 142 202 329 142 202 332 minecraft:blue_terracotta
setblock 142 202 333 minecraft:dark_prismarine
fill 142 202 334 142 205 334 minecraft:blue_terracotta
setblock 142 202 338 minecraft:dark_prismarine
fill 142 202 339 142 205 339 minecraft:blue_terracotta
setblock 142 202 343 minecraft:dark_prismarine
fill 142 202 344 142 205 344 minecraft:blue_terracotta
setblock 142 202 353 minecraft:dark_prismarine
fill 142 202 354 142 205 354 minecraft:blue_terracotta
setblock 142 202 358 minecraft:dark_prismarine
fill 142 202 359 142 205 359 minecraft:blue_terracotta
setblock 142 202 363 minecraft:dark_prismarine
fill 143 202 323 143 205 323 minecraft:blue_terracotta
setblock 143 202 327 minecraft:dark_prismarine
setblock 143 202 332 minecraft:dark_prismarine
fill 143 202 333 143 204 333 minecraft:blue_terracotta
setblock 143 202 337 minecraft:dark_prismarine
fill 143 202 338 143 205 338 minecraft:blue_terracotta
setblock 143 202 341 minecraft:blue_terracotta
setblock 143 202 357 minecraft:dark_prismarine
fill 143 202 358 144 204 358 minecraft:blue_terracotta
setblock 143 202 362 minecraft:dark_prismarine
fill 143 202 363 143 205 363 minecraft:blue_terracotta
setblock 144 202 361 minecraft:dark_prismarine
fill 144 202 362 144 205 362 minecraft:blue_terracotta
setblock 145 202 324 minecraft:blue_terracotta
fill 145 202 327 145 203 327 minecraft:dark_prismarine
fill 145 202 329 145 203 329 minecraft:dark_prismarine
fill 145 202 361 146 204 361 minecraft:blue_terracotta
fill 146 202 328 146 203 328 minecraft:dark_prismarine
setblock 147 202 323 minecraft:dark_prismarine
setblock 147 202 363 minecraft:dark_prismarine
fill 148 202 323 148 205 323 minecraft:blue_terracotta
setblock 148 202 362 minecraft:dark_prismarine
fill 148 202 363 148 205 363 minecraft:blue_terracotta
fill 149 202 362 149 205 362 minecraft:blue_terracotta
fill 151 202 362 152 202 362 minecraft:blue_terracotta
setblock 152 202 363 minecraft:dark_prismarine
setblock 153 202 362 minecraft:dark_prismarine
fill 153 202 363 156 202 363 minecraft:blue_terracotta
fill 154 202 362 154 205 362 minecraft:blue_terracotta
fill 156 202 361 156 204 361 minecraft:blue_terracotta
setblock 157 202 363 minecraft:dark_prismarine
fill 158 202 323 161 202 323 minecraft:blue_terracotta
setblock 158 202 361 minecraft:blue_terracotta
setblock 158 202 362 minecraft:dark_prismarine
fill 158 202 363 158 205 363 minecraft:blue_terracotta
setblock 159 202 360 minecraft:blue_terracotta
setblock 159 202 361 minecraft:dark_prismarine
fill 159 202 362 159 205 362 minecraft:blue_terracotta
setblock 160 202 360 minecraft:dark_prismarine
fill 160 202 361 160 205 361 minecraft:blue_terracotta
fill 161 202 360 162 204 360 minecraft:blue_terracotta
setblock 162 202 323 minecraft:dark_prismarine
setblock 162 202 363 minecraft:dark_prismarine
setblock 163 202 362 minecraft:dark_prismarine
fill 163 202 363 163 205 363 minecraft:blue_terracotta
setblock 164 202 361 minecraft:dark_prismarine
fill 164 202 362 164 205 362 minecraft:blue_terracotta
setblock 167 202 363 minecraft:dark_prismarine
fill 171 202 355 171 204 355 minecraft:magenta_terracotta
fill 177 202 328 177 204 328 minecraft:dark_prismarine
setblock 177 202 363 minecraft:dark_prismarine
fill 178 202 323 178 205 323 minecraft:blue_terracotta
fill 178 202 327 178 203 327 minecraft:dark_prismarine
fill 178 202 329 178 203 329 minecraft:dark_prismarine
fill 178 202 363 178 205 363 minecraft:blue_terracotta
setblock 179 202 336 minecraft:dark_prismarine
fill 179 202 337 179 203 339 minecraft:blue_terracotta
setblock 180 202 335 minecraft:dark_prismarine
fill 180 202 336 180 205 336 minecraft:blue_terracotta
setblock 180 202 339 minecraft:blue_terracotta
setblock 180 202 340 minecraft:dark_prismarine
fill 180 202 341 180 204 342 minecraft:blue_terracotta
fill 180 202 362 182 202 362 minecraft:blue_terracotta
setblock 181 202 324 minecraft:dark_prismarine
fill 181 202 325 181 202 328 minecraft:blue_terracotta
setblock 181 202 329 minecraft:dark_prismarine
fill 181 202 330 181 205 330 minecraft:blue_terracotta
setblock 181 202 334 minecraft:dark_prismarine
fill 181 202 335 181 205 335 minecraft:blue_terracotta
setblock 181 202 339 minecraft:dark_prismarine
fill 181 202 340 181 205 340 minecraft:blue_terracotta
setblock 181 202 344 minecraft:dark_prismarine
fill 181 202 357 181 202 358 minecraft:blue_terracotta
setblock 181 202 359 minecraft:dark_prismarine
fill 181 202 360 181 205 360 minecraft:blue_terracotta
setblock 182 202 323 minecraft:dark_prismarine
fill 182 202 324 182 205 324 minecraft:blue_terracotta
setblock 182 202 328 minecraft:dark_prismarine
fill 182 202 329 182 205 329 minecraft:blue_terracotta
setblock 182 202 333 minecraft:dark_prismarine
fill 182 202 334 182 205 334 minecraft:blue_terracotta
setblock 182 202 338 minecraft:dark_prismarine
fill 182 202 339 182 205 339 minecraft:blue_terracotta
setblock 182 202 343 minecraft:dark_prismarine
fill 182 202 344 182 205 344 minecraft:blue_terracotta
setblock 182 202 347 minecraft:blue_terracotta
fill 182 202 354 182 205 354 minecraft:blue_terracotta
setblock 182 202 358 minecraft:dark_prismarine
fill 182 202 359 182 205 359 minecraft:blue_terracotta
setblock 182 202 363 minecraft:dark_prismarine
fill 142 203 323 142 206 323 minecraft:blue_terracotta
setblock 142 203 327 minecraft:dark_prismarine
fill 142 203 328 142 203 331 minecraft:blue_terracotta
setblock 142 203 332 minecraft:dark_prismarine
fill 142 203 333 142 206 333 minecraft:blue_terracotta
setblock 142 203 337 minecraft:dark_prismarine
fill 142 203 338 142 206 338 minecraft:blue_terracotta
setblock 142 203 342 minecraft:dark_prismarine
fill 142 203 343 142 206 343 minecraft:blue_terracotta
fill 142 203 345 142 204 345 minecraft:blue_terracotta
setblock 142 203 348 minecraft:purple_concrete
fill 142 203 353 142 206 353 minecraft:blue_terracotta
setblock 142 203 357 minecraft:dark_prismarine
fill 142 203 358 142 206 358 minecraft:blue_terracotta
setblock 142 203 362 minecraft:dark_prismarine
fill 142 203 363 142 206 363 minecraft:blue_terracotta
setblock 143 203 326 minecraft:dark_prismarine
fill 143 203 327 143 206 327 minecraft:blue_terracotta
setblock 143 203 328 minecraft:purple_concrete
setblock 143 203 331 minecraft:dark_prismarine
setblock 143 203 332 minecraft:blue_terracotta
setblock 143 203 336 minecraft:dark_prismarine
fill 143 203 337 143 206 337 minecraft:blue_terracotta
setblock 143 203 341 minecraft:dark_prismarine
fill 143 203 342 143 206 342 minecraft:blue_terracotta
setblock 143 203 356 minecraft:dark_prismarine
fill 143 203 357 143 206 357 minecraft:blue_terracotta
setblock 143 203 360 minecraft:blue_terracotta
setblock 143 203 361 minecraft:dark_prismarine
fill 143 203 362 143 206 362 minecraft:blue_terracotta
setblock 144 203 325 minecraft:light[level=12]
setblock 144 203 332 minecraft:light[level=12]
setblock 144 203 339 minecraft:light[level=12]
setblock 144 203 346 minecraft:light[level=12]
setblock 144 203 353 minecraft:light[level=12]
setblock 144 203 360 minecraft:dark_prismarine
fill 144 203 361 144 206 361 minecraft:blue_terracotta
setblock 145 203 324 minecraft:dark_prismarine
setblock 146 203 323 minecraft:dark_prismarine
fill 146 203 327 147 203 327 minecraft:dark_prismarine
fill 146 203 329 147 203 329 minecraft:dark_prismarine
setblock 146 203 363 minecraft:dark_prismarine
fill 147 203 323 147 206 323 minecraft:blue_terracotta
fill 147 203 328 148 205 328 minecraft:dark_prismarine
setblock 147 203 361 minecraft:blue_terracotta
setblock 147 203 362 minecraft:dark_prismarine
fill 147 203 363 147 206 363 minecraft:blue_terracotta
fill 148 203 362 148 206 362 minecraft:blue_terracotta
fill 149 203 323 149 204 323 minecraft:blue_terracotta
setblock 151 203 325 minecraft:light[level=12]
setblock 151 203 332 minecraft:light[level=12]
setblock 151 203 339 minecraft:light[level=12]
setblock 151 203 346 minecraft:light[level=12]
setblock 151 203 353 minecraft:light[level=12]
setblock 151 203 360 minecraft:light[level=12]
setblock 151 203 362 minecraft:blue_terracotta
setblock 151 203 363 minecraft:dark_prismarine
setblock 152 203 362 minecraft:dark_prismarine
fill 152 203 363 155 203 363 minecraft:blue_terracotta
setblock 153 203 323 minecraft:purple_concrete
fill 153 203 362 153 206 362 minecraft:blue_terracotta
fill 154 203 361 155 205 361 minecraft:blue_terracotta
fill 155 203 331 155 234 331 minecraft:magenta_terracotta
setblock 156 203 323 minecraft:dark_prismarine
setblock 156 203 363 minecraft:dark_prismarine
fill 157 203 323 160 203 323 minecraft:blue_terracotta
setblock 157 203 362 minecraft:dark_prismarine
fill 157 203 363 157 206 363 minecraft:blue_terracotta
setblock 158 203 325 minecraft:light[level=12]
setblock 158 203 332 minecraft:light[level=12]
setblock 158 203 339 minecraft:light[level=12]
setblock 158 203 346 minecraft:light[level=12]
setblock 158 203 353 minecraft:light[level=12]
setblock 158 203 360 minecraft:blue_terracotta
setblock 158 203 361 minecraft:dark_prismarine
fill 158 203 362 158 206 362 minecraft:blue_terracotta
setblock 159 203 360 minecraft:dark_prismarine
fill 159 203 361 159 206 361 minecraft:blue_terracotta
fill 160 203 360 160 206 360 minecraft:blue_terracotta
setblock 161 203 323 minecraft:dark_prismarine
setblock 161 203 363 minecraft:dark_prismarine
fill 162 203 323 163 205 323 minecraft:blue_terracotta
setblock 162 203 362 minecraft:dark_prismarine
fill 162 203 363 162 206 363 minecraft:blue_terracotta
setblock 163 203 361 minecraft:dark_prismarine
fill 163 203 362 163 206 362 minecraft:blue_terracotta
fill 164 203 361 164 205 361 minecraft:blue_terracotta
setblock 165 203 325 minecraft:light[level=12]
setblock 165 203 332 minecraft:light[level=12]
setblock 165 203 339 minecraft:light[level=12]
setblock 165 203 346 minecraft:light[level=12]
setblock 165 203 353 minecraft:light[level=12]
setblock 165 203 360 minecraft:light[level=12]
setblock 166 203 363 minecraft:dark_prismarine
fill 167 203 363 167 206 363 minecraft:blue_terracotta
setblock 169 203 322 minecraft:cyan_concrete
fill 170 203 322 170 216 322 minecraft:blue_terracotta
setblock 171 203 363 minecraft:purple_concrete
setblock 172 203 323 minecraft:purple_concrete
setblock 172 203 325 minecraft:light[level=12]
setblock 172 203 332 minecraft:light[level=12]
setblock 172 203 339 minecraft:light[level=12]
setblock 172 203 346 minecraft:light[level=12]
setblock 172 203 353 minecraft:light[level=12]
setblock 172 203 360 minecraft:light[level=12]
fill 175 203 328 176 205 328 minecraft:dark_prismarine
setblock 176 203 323 minecraft:dark_prismarine
fill 176 203 327 177 203 327 minecraft:dark_prismarine
fill 176 203 329 177 203 329 minecraft:dark_prismarine
setblock 176 203 363 minecraft:dark_prismarine
fill 177 203 323 177 206 323 minecraft:blue_terracotta
fill 177 203 363 177 206 363 minecraft:blue_terracotta
fill 178 203 362 181 203 362 minecraft:blue_terracotta
setblock 179 203 324 minecraft:blue_terracotta
setblock 179 203 325 minecraft:light[level=12]
setblock 179 203 328 minecraft:dark_prismarine
setblock 179 203 332 minecraft:light[level=12]
fill 179 203 336 179 206 336 minecraft:blue_terracotta
setblock 179 203 340 minecraft:dark_prismarine
setblock 179 203 346 minecraft:light[level=12]
setblock 179 203 353 minecraft:light[level=12]
setblock 179 203 360 minecraft:light[level=12]
setblock 179 203 364 minecraft:light_blue_wool
setblock 180 203 324 minecraft:dark_prismarine
setblock 180 203 328 minecraft:purple_concrete
setblock 180 203 334 minecraft:dark_prismarine
fill 180 203 335 180 206 335 minecraft:blue_terracotta
setblock 180 203 339 minecraft:dark_prismarine
fill 180 203 340 180 206 340 minecraft:blue_terracotta
setblock 180 203 343 minecraft:blue_terracotta
setblock 180 203 363 minecraft:blue_terracotta
setblock 181 203 323 minecraft:dark_prismarine
fill 181 203 324 181 203 327 minecraft:blue_terracotta
setblock 181 203 328 minecraft:dark_prismarine
fill 181 203 329 181 206 329 minecraft:blue_terracotta
setblock 181 203 333 minecraft:dark_prismarine
fill 181 203 334 181 206 334 minecraft:blue_terracotta
setblock 181 203 338 minecraft:dark_prismarine
fill 181 203 339 181 206 339 minecraft:blue_terracotta
setblock 181 203 342 minecraft:blue_terracotta
setblock 181 203 343 minecraft:dark_prismarine
fill 181 203 344 181 205 345 minecraft:blue_terracotta
setblock 181 203 357 minecraft:blue_terracotta
setblock 181 203 358 minecraft:dark_prismarine
fill 181 203 359 181 206 359 minecraft:blue_terracotta
setblock 181 203 363 minecraft:dark_prismarine
fill 182 203 323 182 206 323 minecraft:blue_terracotta
setblock 182 203 327 minecraft:dark_prismarine
fill 182 203 328 182 206 328 minecraft:blue_terracotta
setblock 182 203 332 minecraft:dark_prismarine
fill 182 203 333 182 206 333 minecraft:blue_terracotta
setblock 182 203 337 minecraft:dark_prismarine
fill 182 203 338 182 206 338 minecraft:blue_terracotta
setblock 182 203 342 minecraft:dark_prismarine
fill 182 203 343 182 206 343 minecraft:blue_terracotta
setblock 182 203 347 minecraft:dark_prismarine
setblock 182 203 357 minecraft:dark_prismarine
fill 182 203 358 182 206 358 minecraft:blue_terracotta
setblock 182 203 362 minecraft:dark_prismarine
fill 182 203 363 182 206 363 minecraft:blue_terracotta
setblock 142 204 326 minecraft:dark_prismarine
fill 142 204 327 142 204 330 minecraft:blue_terracotta
setblock 142 204 331 minecraft:dark_prismarine
fill 142 204 332 142 207 332 minecraft:blue_terracotta
setblock 142 204 336 minecraft:dark_prismarine
fill 142 204 337 142 207 337 minecraft:blue_terracotta
setblock 142 204 341 minecraft:dark_prismarine
fill 142 204 342 142 207 342 minecraft:blue_terracotta
setblock 142 204 346 minecraft:dark_prismarine
setblock 142 204 356 minecraft:dark_prismarine
fill 142 204 357 142 207 357 minecraft:blue_terracotta
setblock 142 204 361 minecraft:dark_prismarine
fill 142 204 362 142 207 362 minecraft:blue_terracotta
setblock 143 204 325 minecraft:dark_prismarine
fill 143 204 326 143 207 326 minecraft:blue_terracotta
fill 143 204 328 143 205 328 minecraft:blue_terracotta
setblock 143 204 335 minecraft:dark_prismarine
fill 143 204 336 143 205 336 minecraft:blue_terracotta
setblock 143 204 340 minecraft:dark_prismarine
fill 143 204 341 143 207 341 minecraft:blue_terracotta
fill 143 204 343 143 205 343 minecraft:blue_terracotta
fill 143 204 356 143 206 356 minecraft:blue_terracotta
setblock 143 204 360 minecraft:dark_prismarine
fill 143 204 361 143 207 361 minecraft:blue_terracotta
setblock 144 204 324 minecraft:dark_prismarine
setblock 144 204 359 minecraft:dark_prismarine
fill 144 204 360 144 207 360 minecraft:blue_terracotta
setblock 145 204 323 minecraft:dark_prismarine
fill 145 204 324 146 206 324 minecraft:blue_terracotta
fill 145 204 328 146 204 328 minecraft:purple_concrete
setblock 145 204 363 minecraft:dark_prismarine
fill 146 204 323 146 207 323 minecraft:blue_terracotta
setblock 146 204 362 minecraft:dark_prismarine
fill 146 204 363 146 207 363 minecraft:blue_terracotta
fill 147 204 327 148 204 327 minecraft:dark_prismarine
fill 147 204 329 148 204 329 minecraft:dark_prismarine
setblock 147 204 361 minecraft:dark_prismarine
fill 147 204 362 147 207 362 minecraft:blue_terracotta
fill 148 204 346 148 234 346 minecraft:magenta_terracotta
fill 148 204 361 148 206 361 minecraft:blue_terracotta
fill 149 204 328 149 206 328 minecraft:dark_prismarine
setblock 150 204 323 minecraft:dark_prismarine
setblock 150 204 363 minecraft:dark_prismarine
fill 151 204 323 154 204 323 minecraft:blue_terracotta
setblock 151 204 362 minecraft:dark_prismarine
fill 151 204 363 154 204 363 minecraft:blue_terracotta
setblock 152 204 361 minecraft:dark_prismarine
fill 152 204 362 152 207 362 minecraft:blue_terracotta
fill 153 204 361 153 207 361 minecraft:blue_terracotta
setblock 155 204 323 minecraft:dark_prismarine
setblock 155 204 363 minecraft:dark_prismarine
fill 156 204 323 159 204 323 minecraft:blue_terracotta
fill 156 204 360 157 204 360 minecraft:blue_terracotta
setblock 156 204 362 minecraft:dark_prismarine
fill 156 204 363 156 207 363 minecraft:blue_terracotta
setblock 157 204 361 minecraft:dark_prismarine
fill 157 204 362 157 207 362 minecraft:blue_terracotta
setblock 158 204 360 minecraft:dark_prismarine
fill 158 204 361 158 207 361 minecraft:blue_terracotta
fill 159 204 360 159 207 360 minecraft:blue_terracotta
setblock 160 204 323 minecraft:dark_prismarine
setblock 160 204 363 minecraft:dark_prismarine
fill 161 204 323 161 207 323 minecraft:blue_terracotta
setblock 161 204 362 minecraft:dark_prismarine
fill 161 204 363 161 207 363 minecraft:blue_terracotta
setblock 162 204 361 minecraft:dark_prismarine
fill 162 204 362 162 207 362 minecraft:blue_terracotta
fill 163 204 361 163 206 361 minecraft:blue_terracotta
setblock 164 204 323 minecraft:blue_terracotta
setblock 165 204 363 minecraft:dark_prismarine
setblock 166 204 323 minecraft:purple_concrete
setblock 166 204 362 minecraft:dark_prismarine
fill 166 204 363 166 207 363 minecraft:blue_terracotta
fill 168 204 363 168 205 363 minecraft:blue_terracotta
fill 169 204 322 169 220 322 minecraft:blue_terracotta
fill 174 204 328 174 206 328 minecraft:dark_prismarine
setblock 174 204 363 minecraft:blue_terracotta
setblock 175 204 323 minecraft:dark_prismarine
fill 175 204 327 176 204 327 minecraft:dark_prismarine
fill 175 204 329 176 204 329 minecraft:dark_prismarine
setblock 175 204 363 minecraft:dark_prismarine
fill 176 204 323 176 207 323 minecraft:blue_terracotta
fill 176 204 363 176 207 363 minecraft:blue_terracotta
fill 177 204 324 178 204 324 minecraft:blue_terracotta
fill 177 204 340 177 234 340 minecraft:magenta_terracotta
fill 177 204 362 180 204 362 minecraft:blue_terracotta
setblock 178 204 328 minecraft:purple_concrete
setblock 179 204 324 minecraft:dark_prismarine
fill 179 204 335 179 205 335 minecraft:blue_terracotta
fill 179 204 337 179 204 338 minecraft:blue_terracotta
setblock 179 204 339 minecraft:dark_prismarine
fill 179 204 340 179 205 342 minecraft:blue_terracotta
fill 179 204 364 179 216 364 minecraft:blue_terracotta
setblock 180 204 323 minecraft:dark_prismarine
fill 180 204 324 181 206 324 minecraft:blue_terracotta
fill 180 204 331 180 205 331 minecraft:blue_terracotta
setblock 180 204 333 minecraft:dark_prismarine
fill 180 204 334 180 207 334 minecraft:blue_terracotta
setblock 180 204 338 minecraft:dark_prismarine
fill 180 204 339 180 207 339 minecraft:blue_terracotta
setblock 180 204 343 minecraft:dark_prismarine
fill 180 204 344 180 207 344 minecraft:blue_terracotta
fill 180 204 361 180 205 361 minecraft:blue_terracotta
setblock 180 204 363 minecraft:dark_prismarine
fill 181 204 323 181 207 323 minecraft:blue_terracotta
fill 181 204 325 181 204 326 minecraft:blue_terracotta
setblock 181 204 327 minecraft:dark_prismarine
fill 181 204 328 181 207 328 minecraft:blue_terracotta
setblock 181 204 332 minecraft:dark_prismarine
fill 181 204 333 181 207 333 minecraft:blue_terracotta
setblock 181 204 337 minecraft:dark_prismarine
fill 181 204 338 181 207 338 minecraft:blue_terracotta
setblock 181 204 342 minecraft:dark_prismarine
fill 181 204 343 181 207 343 minecraft:blue_terracotta
setblock 181 204 346 minecraft:blue_terracotta
setblock 181 204 357 minecraft:dark_prismarine
fill 181 204 358 181 207 358 minecraft:blue_terracotta
setblock 181 204 362 minecraft:dark_prismarine
fill 181 204 363 181 207 363 minecraft:blue_terracotta
setblock 182 204 326 minecraft:dark_prismarine
fill 182 204 327 182 207 327 minecraft:blue_terracotta
setblock 182 204 331 minecraft:dark_prismarine
fill 182 204 332 182 207 332 minecraft:blue_terracotta
setblock 182 204 336 minecraft:dark_prismarine
fill 182 204 337 182 207 337 minecraft:blue_terracotta
setblock 182 204 341 minecraft:dark_prismarine
fill 182 204 342 182 207 342 minecraft:blue_terracotta
setblock 182 204 346 minecraft:dark_prismarine
fill 182 204 347 182 206 348 minecraft:blue_terracotta
setblock 182 204 351 minecraft:purple_concrete
setblock 182 204 356 minecraft:dark_prismarine
fill 182 204 357 182 207 357 minecraft:blue_terracotta
setblock 182 204 361 minecraft:dark_prismarine
fill 182 204 362 182 207 362 minecraft:blue_terracotta
setblock 142 205 325 minecraft:dark_prismarine
fill 142 205 326 142 205 329 minecraft:blue_terracotta
setblock 142 205 330 minecraft:dark_prismarine
fill 142 205 331 142 208 331 minecraft:blue_terracotta
setblock 142 205 335 minecraft:dark_prismarine
fill 142 205 336 142 208 336 minecraft:blue_terracotta
setblock 142 205 340 minecraft:dark_prismarine
fill 142 205 341 142 208 341 minecraft:blue_terracotta
setblock 142 205 345 minecraft:dark_prismarine
fill 142 205 346 142 206 348 minecraft:blue_terracotta
setblock 142 205 355 minecraft:dark_prismarine
fill 142 205 356 142 208 356 minecraft:blue_terracotta
setblock 142 205 360 minecraft:dark_prismarine
fill 142 205 361 142 208 361 minecraft:blue_terracotta
setblock 143 205 324 minecraft:dark_prismarine
fill 143 205 325 143 208 325 minecraft:blue_terracotta
setblock 143 205 335 minecraft:blue_terracotta
setblock 143 205 339 minecraft:dark_prismarine
fill 143 205 340 143 207 340 minecraft:blue_terracotta
setblock 143 205 358 minecraft:blue_terracotta
setblock 143 205 359 minecraft:dark_prismarine
fill 143 205 360 143 208 360 minecraft:blue_terracotta
setblock 144 205 323 minecraft:dark_prismarine
fill 144 205 324 144 208 324 minecraft:blue_terracotta
setblock 144 205 325 minecraft:light[level=13]
setblock 144 205 333 minecraft:light[level=13]
setblock 144 205 341 minecraft:light[level=13]
setblock 144 205 349 minecraft:light[level=13]
setblock 144 205 357 minecraft:light[level=13]
fill 144 205 359 144 206 359 minecraft:blue_terracotta
setblock 144 205 363 minecraft:dark_prismarine
fill 145 205 323 145 208 323 minecraft:blue_terracotta
setblock 145 205 361 minecraft:blue_terracotta
setblock 145 205 362 minecraft:dark_prismarine
fill 145 205 363 145 208 363 minecraft:blue_terracotta
setblock 146 205 328 minecraft:purple_concrete
setblock 146 205 361 minecraft:dark_prismarine
fill 146 205 362 146 208 362 minecraft:blue_terracotta
fill 147 205 361 147 207 361 minecraft:blue_terracotta
fill 148 205 327 150 205 327 minecraft:dark_prismarine
fill 148 205 329 150 205 329 minecraft:dark_prismarine
setblock 149 205 323 minecraft:dark_prismarine
fill 149 205 361 150 205 361 minecraft:blue_terracotta
setblock 149 205 363 minecraft:dark_prismarine
fill 150 205 323 153 205 323 minecraft:blue_terracotta
fill 150 205 328 151 206 328 minecraft:dark_prismarine
setblock 150 205 362 minecraft:dark_prismarine
fill 150 205 363 153 205 363 minecraft:blue_terracotta
setblock 151 205 361 minecraft:dark_prismarine
fill 151 205 362 151 208 362 minecraft:blue_terracotta
setblock 152 205 325 minecraft:light[level=13]
setblock 152 205 333 minecraft:light[level=13]
setblock 152 205 341 minecraft:light[level=13]
setblock 152 205 349 minecraft:light[level=13]
setblock 152 205 357 minecraft:light[level=13]
fill 152 205 361 152 208 361 minecraft:blue_terracotta
setblock 154 205 323 minecraft:dark_prismarine
setblock 154 205 363 minecraft:dark_prismarine
fill 155 205 323 158 205 323 minecraft:blue_terracotta
setblock 155 205 362 minecraft:dark_prismarine
fill 155 205 363 155 208 363 minecraft:blue_terracotta
setblock 156 205 360 minecraft:blue_terracotta
setblock 156 205 361 minecraft:dark_prismarine
fill 156 205 362 156 208 362 minecraft:blue_terracotta
setblock 157 205 324 minecraft:blue_terracotta
setblock 157 205 360 minecraft:dark_prismarine
fill 157 205 361 157 208 361 minecraft:blue_terracotta
setblock 158 205 324 minecraft:dark_prismarine
fill 158 205 360 158 208 360 minecraft:blue_terracotta
setblock 159 205 323 minecraft:dark_prismarine
fill 159 205 324 160 207 324 minecraft:blue_terracotta
setblock 159 205 363 minecraft:dark_prismarine
fill 160 205 323 160 208 323 minecraft:blue_terracotta
setblock 160 205 325 minecraft:light[level=13]
setblock 160 205 333 minecraft:light[level=13]
setblock 160 205 349 minecraft:light[level=13]
setblock 160 205 357 minecraft:light[level=13]
setblock 160 205 362 minecraft:dark_prismarine
fill 160 205 363 160 208 363 minecraft:blue_terracotta
setblock 161 205 360 minecraft:blue_terracotta
setblock 161 205 361 minecraft:dark_prismarine
fill 161 205 362 161 208 362 minecraft:blue_terracotta
fill 162 205 361 162 207 361 minecraft:blue_terracotta
setblock 164 205 323 minecraft:dark_prismarine
setblock 164 205 363 minecraft:dark_prismarine
fill 165 205 323 165 208 323 minecraft:blue_terracotta
setblock 165 205 362 minecraft:dark_prismarine
fill 165 205 363 165 208 363 minecraft:blue_terracotta
setblock 166 205 362 minecraft:blue_terracotta
setblock 168 205 325 minecraft:light[level=13]
setblock 168 205 333 minecraft:light[level=13]
setblock 168 205 341 minecraft:light[level=13]
setblock 168 205 349 minecraft:light[level=13]
setblock 168 205 357 minecraft:light[level=13]
setblock 169 205 363 minecraft:dark_prismarine
fill 172 205 328 173 207 328 minecraft:dark_prismarine
fill 172 205 363 173 205 363 minecraft:blue_terracotta
setblock 173 205 323 minecraft:blue_terracotta
fill 173 205 327 175 205 327 minecraft:dark_prismarine
fill 173 205 329 175 205 329 minecraft:dark_prismarine
setblock 174 205 323 minecraft:dark_prismarine
setblock 174 205 363 minecraft:dark_prismarine
fill 175 205 323 175 208 323 minecraft:blue_terracotta
fill 175 205 363 175 208 363 minecraft:blue_terracotta
fill 176 205 324 177 205 324 minecraft:blue_terracotta
setblock 176 205 325 minecraft:light[level=13]
setblock 176 205 333 minecraft:light[level=13]
setblock 176 205 341 minecraft:light[level=13]
setblock 176 205 349 minecraft:light[level=13]
setblock 176 205 357 minecraft:light[level=13]
fill 176 205 362 179 205 362 minecraft:blue_terracotta
setblock 177 205 328 minecraft:purple_concrete
setblock 178 205 324 minecraft:dark_prismarine
fill 178 205 325 181 205 325 minecraft:blue_terracotta
setblock 179 205 323 minecraft:dark_prismarine
fill 179 205 324 179 208 324 minecraft:blue_terracotta
setblock 179 205 337 minecraft:blue_terracotta
setblock 179 205 338 minecraft:dark_prismarine
fill 179 205 339 179 208 339 minecraft:blue_terracotta
setblock 179 205 343 minecraft:dark_prismarine
fill 179 205 361 179 206 361 minecraft:blue_terracotta
setblock 179 205 363 minecraft:dark_prismarine
fill 180 205 323 180 208 323 minecraft:blue_terracotta
setblock 180 205 326 minecraft:blue_terracotta
setblock 180 205 327 minecraft:dark_prismarine
fill 180 205 328 180 206 330 minecraft:blue_terracotta
setblock 180 205 332 minecraft:dark_prismarine
fill 180 205 333 180 208 333 minecraft:blue_terracotta
setblock 180 205 337 minecraft:dark_prismarine
fill 180 205 338 180 208 338 minecraft:blue_terracotta
setblock 180 205 341 minecraft:blue_terracotta
setblock 180 205 342 minecraft:dark_prismarine
fill 180 205 343 180 208 343 minecraft:blue_terracotta
fill 180 205 345 180 206 345 minecraft:blue_terracotta
fill 180 205 360 180 206 360 minecraft:blue_terracotta
setblock 180 205 362 minecraft:dark_prismarine
fill 180 205 363 180 208 363 minecraft:blue_terracotta
setblock 181 205 326 minecraft:dark_prismarine
fill 181 205 327 181 208 327 minecraft:blue_terracotta
setblock 181 205 331 minecraft:dark_prismarine
fill 181 205 332 181 208 332 minecraft:blue_terracotta
setblock 181 205 336 minecraft:dark_prismarine
fill 181 205 337 181 208 337 minecraft:blue_terracotta
setblock 181 205 341 minecraft:dark_prismarine
fill 181 205 342 181 208 342 minecraft:blue_terracotta
setblock 181 205 346 minecraft:dark_prismarine
fill 181 205 347 181 208 347 minecraft:blue_terracotta
setblock 181 205 357 minecraft:blue_terracotta
setblock 181 205 361 minecraft:dark_prismarine
fill 181 205 362 181 208 362 minecraft:blue_terracotta
setblock 182 205 325 minecraft:dark_prismarine
fill 182 205 326 182 208 326 minecraft:blue_terracotta
setblock 182 205 330 minecraft:dark_prismarine
fill 182 205 331 182 208 331 minecraft:blue_terracotta
setblock 182 205 335 minecraft:dark_prismarine
fill 182 205 336 182 208 336 minecraft:blue_terracotta
setblock 182 205 340 minecraft:dark_prismarine
fill 182 205 341 182 208 341 minecraft:blue_terracotta
setblock 182 205 345 minecraft:dark_prismarine
fill 182 205 346 182 208 346 minecraft:blue_terracotta
setblock 182 205 349 minecraft:blue_terracotta
setblock 182 205 355 minecraft:dark_prismarine
fill 182 205 356 182 207 356 minecraft:blue_terracotta
setblock 182 205 360 minecraft:dark_prismarine
fill 182 205 361 182 208 361 minecraft:blue_terracotta
setblock 142 206 324 minecraft:dark_prismarine
fill 142 206 325 142 206 328 minecraft:blue_terracotta
setblock 142 206 329 minecraft:dark_prismarine
fill 142 206 330 142 209 330 minecraft:blue_terracotta
setblock 142 206 334 minecraft:dark_prismarine
fill 142 206 335 142 208 335 minecraft:blue_terracotta
setblock 142 206 339 minecraft:dark_prismarine
fill 142 206 340 142 209 340 minecraft:blue_terracotta
setblock 142 206 344 minecraft:dark_prismarine
fill 142 206 345 142 209 345 minecraft:blue_terracotta
setblock 142 206 349 minecraft:dark_prismarine
setblock 142 206 354 minecraft:dark_prismarine
fill 142 206 355 142 209 355 minecraft:blue_terracotta
setblock 142 206 359 minecraft:dark_prismarine
fill 142 206 360 142 209 360 minecraft:blue_terracotta
setblock 143 206 323 minecraft:dark_prismarine
fill 143 206 324 143 209 324 minecraft:blue_terracotta
setblock 143 206 328 minecraft:dark_prismarine
setblock 143 206 338 minecraft:dark_prismarine
fill 143 206 339 143 207 339 minecraft:blue_terracotta
setblock 143 206 343 minecraft:dark_prismarine
fill 143 206 344 143 207 344 minecraft:blue_terracotta
setblock 143 206 358 minecraft:dark_prismarine
fill 143 206 359 143 209 359 minecraft:blue_terracotta
setblock 143 206 363 minecraft:dark_prismarine
fill 144 206 323 144 209 323 minecraft:blue_terracotta
setblock 144 206 362 minecraft:dark_prismarine
fill 144 206 363 144 209 363 minecraft:blue_terracotta
setblock 145 206 361 minecraft:dark_prismarine
fill 145 206 362 145 209 362 minecraft:blue_terracotta
fill 146 206 361 146 207 361 minecraft:blue_terracotta
setblock 147 206 324 minecraft:dark_prismarine
fill 147 206 328 147 210 328 minecraft:iron_bars
fill 147 206 346 147 234 346 minecraft:magenta_terracotta
setblock 148 206 323 minecraft:dark_prismarine
setblock 148 206 328 minecraft:purple_concrete
setblock 148 206 363 minecraft:dark_prismarine
fill 149 206 323 152 206 323 minecraft:blue_terracotta
setblock 149 206 361 minecraft:blue_terracotta
setblock 149 206 362 minecraft:dark_prismarine
fill 149 206 363 152 206 363 minecraft:blue_terracotta
fill 150 206 327 152 206 327 minecraft:dark_prismarine
fill 150 206 329 152 206 329 minecraft:dark_prismarine
setblock 150 206 361 minecraft:dark_prismarine
fill 150 206 362 150 209 362 minecraft:blue_terracotta
fill 151 206 361 151 208 361 minecraft:blue_terracotta
fill 152 206 328 153 208 328 minecraft:dark_prismarine
setblock 153 206 323 minecraft:dark_prismarine
setblock 153 206 363 minecraft:dark_prismarine
fill 154 206 323 157 206 323 minecraft:blue_terracotta
setblock 154 206 361 minecraft:blue_terracotta
setblock 154 206 362 minecraft:dark_prismarine
fill 154 206 363 154 209 363 minecraft:blue_terracotta
fill 155 206 324 156 206 324 minecraft:blue_terracotta
setblock 155 206 360 minecraft:blue_terracotta
setblock 155 206 361 minecraft:dark_prismarine
fill 155 206 362 155 209 362 minecraft:blue_terracotta
setblock 156 206 360 minecraft:dark_prismarine
fill 156 206 361 156 209 361 minecraft:blue_terracotta
setblock 157 206 324 minecraft:dark_prismarine
fill 157 206 360 157 208 360 minecraft:blue_terracotta
setblock 158 206 323 minecraft:dark_prismarine
fill 158 206 324 158 209 324 minecraft:blue_terracotta
setblock 158 206 363 minecraft:dark_prismarine
fill 159 206 323 159 209 323 minecraft:blue_terracotta
fill 159 206 330 160 207 331 minecraft:dark_prismarine
setblock 159 206 362 minecraft:dark_prismarine
fill 159 206 363 159 209 363 minecraft:blue_terracotta
setblock 160 206 361 minecraft:dark_prismarine
fill 160 206 362 160 209 362 minecraft:blue_terracotta
setblock 161 206 324 minecraft:blue_terracotta
setblock 161 206 360 minecraft:dark_prismarine
fill 161 206 361 161 208 361 minecraft:blue_terracotta
setblock 162 206 323 minecraft:blue_terracotta
setblock 163 206 323 minecraft:dark_prismarine
setblock 163 206 363 minecraft:dark_prismarine
fill 164 206 323 164 209 323 minecraft:blue_terracotta
setblock 164 206 362 minecraft:dark_prismarine
fill 164 206 363 164 209 363 minecraft:blue_terracotta
fill 165 206 362 165 207 362 minecraft:blue_terracotta
fill 166 206 323 166 207 323 minecraft:blue_terracotta
setblock 168 206 363 minecraft:dark_prismarine
fill 169 206 363 172 206 363 minecraft:blue_terracotta
fill 170 206 328 171 208 328 minecraft:dark_prismarine
fill 171 206 323 172 206 323 minecraft:blue_terracotta
fill 171 206 327 173 206 327 minecraft:dark_prismarine
fill 171 206 329 173 206 329 minecraft:dark_prismarine
setblock 173 206 323 minecraft:dark_prismarine
setblock 173 206 363 minecraft:dark_prismarine
fill 174 206 323 174 208 324 minecraft:blue_terracotta
fill 174 206 363 174 209 363 minecraft:blue_terracotta
fill 175 206 324 176 206 324 minecraft:blue_terracotta
setblock 175 206 328 minecraft:purple_concrete
fill 175 206 362 178 206 362 minecraft:blue_terracotta
setblock 177 206 324 minecraft:dark_prismarine
fill 177 206 325 180 206 325 minecraft:blue_terracotta
setblock 178 206 323 minecraft:dark_prismarine
fill 178 206 324 178 209 324 minecraft:blue_terracotta
fill 178 206 361 178 207 361 minecraft:blue_terracotta
setblock 178 206 363 minecraft:dark_prismarine
fill 179 206 323 179 209 323 minecraft:blue_terracotta
setblock 179 206 337 minecraft:dark_prismarine
fill 179 206 338 179 208 338 minecraft:blue_terracotta
fill 179 206 340 179 206 341 minecraft:blue_terracotta
setblock 179 206 342 minecraft:dark_prismarine
fill 179 206 343 179 208 343 minecraft:blue_terracotta
setblock 179 206 362 minecraft:dark_prismarine
fill 179 206 363 179 209 363 minecraft:blue_terracotta
setblock 180 206 326 minecraft:dark_prismarine
fill 180 206 327 180 209 327 minecraft:blue_terracotta
setblock 180 206 331 minecraft:dark_prismarine
fill 180 206 332 180 208 332 minecraft:blue_terracotta
setblock 180 206 336 minecraft:dark_prismarine
fill 180 206 337 180 209 337 minecraft:blue_terracotta
setblock 180 206 341 minecraft:dark_prismarine
fill 180 206 342 180 209 342 minecraft:blue_terracotta
setblock 180 206 361 minecraft:dark_prismarine
fill 180 206 362 180 209 362 minecraft:blue_terracotta
setblock 181 206 325 minecraft:dark_prismarine
fill 181 206 326 181 209 326 minecraft:blue_terracotta
setblock 181 206 330 minecraft:dark_prismarine
fill 181 206 331 181 209 331 minecraft:blue_terracotta
setblock 181 206 335 minecraft:dark_prismarine
fill 181 206 336 181 209 336 minecraft:blue_terracotta
setblock 181 206 340 minecraft:dark_prismarine
fill 181 206 341 181 209 341 minecraft:blue_terracotta
setblock 181 206 344 minecraft:blue_terracotta
setblock 181 206 345 minecraft:dark_prismarine
fill 181 206 346 181 209 346 minecraft:blue_terracotta
setblock 181 206 360 minecraft:dark_prismarine
fill 181 206 361 181 209 361 minecraft:blue_terracotta
setblock 182 206 324 minecraft:dark_prismarine
fill 182 206 325 182 209 325 minecraft:blue_terracotta
setblock 182 206 329 minecraft:dark_prismarine
fill 182 206 330 182 209 330 minecraft:blue_terracotta
setblock 182 206 334 minecraft:dark_prismarine
fill 182 206 335 182 209 335 minecraft:blue_terracotta
setblock 182 206 339 minecraft:dark_prismarine
fill 182 206 340 182 209 340 minecraft:blue_terracotta
setblock 182 206 344 minecraft:dark_prismarine
fill 182 206 345 182 209 345 minecraft:blue_terracotta
setblock 182 206 349 minecraft:dark_prismarine
setblock 182 206 355 minecraft:blue_terracotta
setblock 182 206 359 minecraft:dark_prismarine
fill 182 206 360 182 209 360 minecraft:blue_terracotta
fill 183 206 362 183 220 362 minecraft:blue_terracotta
setblock 183 206 363 minecraft:light_blue_wool
setblock 142 207 323 minecraft:dark_prismarine
fill 142 207 324 142 207 327 minecraft:blue_terracotta
setblock 142 207 328 minecraft:dark_prismarine
fill 142 207 329 142 210 329 minecraft:blue_terracotta
setblock 142 207 333 minecraft:dark_prismarine
fill 142 207 334 142 208 334 minecraft:blue_terracotta
setblock 142 207 338 minecraft:dark_prismarine
fill 142 207 339 142 209 339 minecraft:blue_terracotta
setblock 142 207 343 minecraft:dark_prismarine
fill 142 207 344 142 210 344 minecraft:blue_terracotta
fill 142 207 346 142 207 347 minecraft:blue_terracotta
setblock 142 207 348 minecraft:dark_prismarine
fill 142 207 349 142 209 350 minecraft:blue_terracotta
setblock 142 207 353 minecraft:dark_prismarine
fill 142 207 354 142 208 354 minecraft:blue_terracotta
setblock 142 207 358 minecraft:dark_prismarine
fill 142 207 359 142 210 359 minecraft:blue_terracotta
setblock 142 207 363 minecraft:dark_prismarine
fill 143 207 323 143 210 323 minecraft:blue_terracotta
setblock 143 207 327 minecraft:dark_prismarine
setblock 143 207 328 minecraft:blue_terracotta
setblock 143 207 342 minecraft:dark_prismarine
fill 143 207 343 143 208 343 minecraft:blue_terracotta
setblock 143 207 357 minecraft:dark_prismarine
fill 143 207 358 143 208 358 minecraft:blue_terracotta
setblock 143 207 362 minecraft:dark_prismarine
fill 143 207 363 143 210 363 minecraft:blue_terracotta
setblock 144 207 361 minecraft:dark_prismarine
fill 144 207 362 144 210 362 minecraft:blue_terracotta
setblock 145 207 324 minecraft:blue_terracotta
fill 145 207 361 145 208 361 minecraft:blue_terracotta
setblock 146 207 324 minecraft:dark_prismarine
setblock 147 207 323 minecraft:dark_prismarine
fill 147 207 324 147 208 324 minecraft:blue_terracotta
setblock 147 207 363 minecraft:dark_prismarine
fill 148 207 323 151 207 323 minecraft:blue_terracotta
setblock 148 207 362 minecraft:dark_prismarine
fill 148 207 363 151 207 363 minecraft:blue_terracotta
fill 149 207 328 150 207 328 minecraft:purple_concrete
fill 149 207 362 149 210 362 minecraft:blue_terracotta
setblock 150 207 361 minecraft:blue_terracotta
fill 151 207 327 151 207 329 minecraft:dark_prismarine
setblock 152 207 323 minecraft:dark_prismarine
fill 152 207 327 154 207 327 minecraft:dark_prismarine
fill 152 207 329 154 207 329 minecraft:dark_prismarine
setblock 152 207 363 minecraft:dark_prismarine
fill 153 207 323 155 207 324 minecraft:blue_terracotta
setblock 153 207 362 minecraft:dark_prismarine
fill 153 207 363 153 210 363 minecraft:blue_terracotta
fill 154 207 328 155 208 328 minecraft:dark_prismarine
setblock 154 207 361 minecraft:dark_prismarine
fill 154 207 362 154 210 362 minecraft:blue_terracotta
setblock 155 207 360 minecraft:dark_prismarine
fill 155 207 361 155 210 361 minecraft:blue_terracotta
setblock 156 207 323 minecraft:blue_terracotta
setblock 156 207 324 minecraft:dark_prismarine
fill 156 207 360 156 208 360 minecraft:blue_terracotta
setblock 157 207 323 minecraft:dark_prismarine
fill 157 207 324 157 210 324 minecraft:blue_terracotta
setblock 157 207 363 minecraft:dark_prismarine
fill 158 207 323 158 210 323 minecraft:blue_terracotta
setblock 158 207 362 minecraft:dark_prismarine
fill 158 207 363 158 210 363 minecraft:blue_terracotta
setblock 159 207 361 minecraft:dark_prismarine
fill 159 207 362 159 210 362 minecraft:blue_terracotta
setblock 160 207 360 minecraft:dark_prismarine
fill 160 207 361 160 209 361 minecraft:blue_terracotta
setblock 161 207 324 minecraft:dark_prismarine
setblock 162 207 323 minecraft:dark_prismarine
fill 162 207 324 162 208 324 minecraft:blue_terracotta
setblock 162 207 363 minecraft:dark_prismarine
fill 163 207 323 163 210 323 minecraft:blue_terracotta
setblock 163 207 362 minecraft:dark_prismarine
fill 163 207 363 163 210 363 minecraft:blue_terracotta
fill 164 207 362 164 208 362 minecraft:blue_terracotta
setblock 167 207 323 minecraft:dark_prismarine
setblock 167 207 363 minecraft:dark_prismarine
fill 168 207 363 171 207 363 minecraft:blue_terracotta
fill 169 207 323 171 207 323 minecraft:blue_terracotta
fill 169 207 329 172 207 329 minecraft:dark_prismarine
fill 170 207 327 172 207 327 minecraft:dark_prismarine
setblock 172 207 323 minecraft:dark_prismarine
setblock 172 207 363 minecraft:dark_prismarine
fill 173 207 323 173 209 324 minecraft:blue_terracotta
fill 173 207 363 173 210 363 minecraft:blue_terracotta
setblock 174 207 328 minecraft:purple_concrete
fill 174 207 362 177 207 362 minecraft:blue_terracotta
setblock 175 207 324 minecraft:blue_terracotta
setblock 176 207 324 minecraft:dark_prismarine
fill 176 207 325 179 207 325 minecraft:blue_terracotta
setblock 177 207 323 minecraft:dark_prismarine
fill 177 207 324 177 210 324 minecraft:blue_terracotta
setblock 177 207 363 minecraft:dark_prismarine
fill 178 207 323 178 210 323 minecraft:blue_terracotta
setblock 178 207 362 minecraft:dark_prismarine
fill 178 207 363 178 210 363 minecraft:blue_terracotta
setblock 179 207 336 minecraft:dark_prismarine
setblock 179 207 337 minecraft:blue_terracotta
setblock 179 207 340 minecraft:blue_terracotta
setblock 179 207 341 minecraft:dark_prismarine
fill 179 207 342 179 208 342 minecraft:blue_terracotta
setblock 179 207 344 minecraft:blue_terracotta
setblock 179 207 361 minecraft:dark_prismarine
fill 179 207 362 179 210 362 minecraft:blue_terracotta
setblock 180 207 324 minecraft:blue_terracotta
setblock 180 207 325 minecraft:dark_prismarine
fill 180 207 326 180 210 326 minecraft:blue_terracotta
fill 180 207 328 180 207 329 minecraft:blue_terracotta
setblock 180 207 330 minecraft:dark_prismarine
fill 180 207 331 180 208 331 minecraft:blue_terracotta
setblock 180 207 335 minecraft:dark_prismarine
fill 180 207 336 180 208 336 minecraft:blue_terracotta
setblock 180 207 340 minecraft:dark_prismarine
fill 180 207 341 180 210 341 minecraft:blue_terracotta
setblock 180 207 345 minecraft:dark_prismarine
fill 180 207 346 180 208 346 minecraft:blue_terracotta
fill 180 207 361 180 208 361 minecraft:blue_terracotta
setblock 181 207 324 minecraft:dark_prismarine
fill 181 207 325 181 210 325 minecraft:blue_terracotta
setblock 181 207 329 minecraft:dark_prismarine
fill 181 207 330 181 210 330 minecraft:blue_terracotta
setblock 181 207 334 minecraft:dark_prismarine
fill 181 207 335 181 209 335 minecraft:blue_terracotta
setblock 181 207 339 minecraft:dark_prismarine
fill 181 207 340 181 210 340 minecraft:blue_terracotta
setblock 181 207 344 minecraft:dark_prismarine
fill 181 207 345 181 210 345 minecraft:blue_terracotta
setblock 181 207 359 minecraft:dark_prismarine
fill 181 207 360 181 209 360 minecraft:blue_terracotta
setblock 182 207 323 minecraft:dark_prismarine
fill 182 207 324 182 210 324 minecraft:blue_terracotta
setblock 182 207 328 minecraft:dark_prismarine
fill 182 207 329 182 210 329 minecraft:blue_terracotta
setblock 182 207 333 minecraft:dark_prismarine
fill 182 207 334 182 210 334 minecraft:blue_terracotta
setblock 182 207 338 minecraft:dark_prismarine
fill 182 207 339 182 210 339 minecraft:blue_terracotta
setblock 182 207 343 minecraft:dark_prismarine
fill 182 207 344 182 210 344 minecraft:blue_terracotta
setblock 182 207 347 minecraft:blue_terracotta
setblock 182 207 348 minecraft:dark_prismarine
fill 182 207 349 182 209 349 minecraft:blue_terracotta
setblock 182 207 352 minecraft:purple_concrete
setblock 182 207 358 minecraft:dark_prismarine
fill 182 207 359 182 209 359 minecraft:blue_terracotta
setblock 182 207 363 minecraft:dark_prismarine
setblock 183 207 324 minecraft:cyan_concrete
fill 183 207 363 183 217 363 minecraft:blue_terracotta
fill 142 208 323 142 208 326 minecraft:blue_terracotta
setblock 142 208 327 minecraft:dark_prismarine
fill 142 208 328 142 211 328 minecraft:blue_terracotta
setblock 142 208 332 minecraft:dark_prismarine
setblock 142 208 333 minecraft:blue_terracotta
setblock 142 208 337 minecraft:dark_prismarine
fill 142 208 338 142 209 338 minecraft:blue_terracotta
setblock 142 208 342 minecraft:dark_prismarine
fill 142 208 343 142 211 343 minecraft:blue_terracotta
setblock 142 208 346 minecraft:blue_terracotta
setblock 142 208 347 minecraft:dark_prismarine
fill 142 208 348 142 211 348 minecraft:blue_terracotta
setblock 142 208 357 minecraft:dark_prismarine
fill 142 208 358 142 211 358 minecraft:blue_terracotta
setblock 142 208 362 minecraft:dark_prismarine
fill 142 208 363 142 211 363 minecraft:blue_terracotta
setblock 143 208 326 minecraft:dark_prismarine
fill 143 208 327 143 209 327 minecraft:blue_terracotta
setblock 143 208 342 minecraft:blue_terracotta
setblock 143 208 361 minecraft:dark_prismarine
fill 143 208 362 143 211 362 minecraft:blue_terracotta
setblock 144 208 361 minecraft:blue_terracotta
setblock 145 208 324 minecraft:dark_prismarine
setblock 146 208 323 minecraft:dark_prismarine
fill 146 208 324 146 209 324 minecraft:blue_terracotta
setblock 146 208 363 minecraft:dark_prismarine
fill 147 208 323 150 208 323 minecraft:blue_terracotta
setblock 147 208 362 minecraft:dark_prismarine
fill 147 208 363 150 208 363 minecraft:blue_terracotta
fill 148 208 362 148 210 362 minecraft:blue_terracotta
setblock 151 208 323 minecraft:dark_prismarine
setblock 151 208 328 minecraft:purple_concrete
setblock 151 208 363 minecraft:dark_prismarine
fill 152 208 323 154 208 324 minecraft:blue_terracotta
fill 152 208 325 152 213 325 minecraft:purple_concrete
setblock 152 208 362 minecraft:dark_prismarine
fill 152 208 363 152 211 363 minecraft:blue_terracotta
fill 153 208 327 156 208 327 minecraft:dark_prismarine
fill 153 208 329 156 208 329 minecraft:dark_prismarine
setblock 153 208 361 minecraft:dark_prismarine
fill 153 208 362 153 211 362 minecraft:blue_terracotta
fill 154 208 361 154 210 361 minecraft:blue_terracotta
setblock 155 208 323 minecraft:blue_terracotta
setblock 155 208 324 minecraft:dark_prismarine
setblock 156 208 323 minecraft:dark_prismarine
fill 156 208 324 156 211 324 minecraft:blue_terracotta
fill 156 208 328 159 209 328 minecraft:dark_prismarine
setblock 156 208 363 minecraft:dark_prismarine
fill 157 208 323 157 211 323 minecraft:blue_terracotta
setblock 157 208 362 minecraft:dark_prismarine
fill 157 208 363 157 211 363 minecraft:blue_terracotta
setblock 158 208 361 minecraft:dark_prismarine
fill 158 208 362 158 211 362 minecraft:blue_terracotta
setblock 159 208 324 minecraft:blue_terracotta
fill 159 208 361 159 209 361 minecraft:blue_terracotta
setblock 160 208 324 minecraft:dark_prismarine
fill 161 208 322 161 220 322 minecraft:blue_terracotta
setblock 161 208 323 minecraft:dark_prismarine
fill 161 208 324 161 209 324 minecraft:blue_terracotta
setblock 161 208 363 minecraft:dark_prismarine
setblock 162 208 322 minecraft:light_blue_wool
fill 162 208 323 162 211 323 minecraft:blue_terracotta
setblock 162 208 362 minecraft:dark_prismarine
fill 162 208 363 162 211 363 minecraft:blue_terracotta
fill 163 208 322 163 220 322 minecraft:blue_terracotta
setblock 163 208 362 minecraft:blue_terracotta
fill 164 208 328 167 209 328 minecraft:dark_prismarine
setblock 166 208 323 minecraft:dark_prismarine
setblock 166 208 363 minecraft:dark_prismarine
fill 167 208 323 170 208 323 minecraft:blue_terracotta
fill 167 208 327 167 209 327 minecraft:dark_prismarine
fill 167 208 329 170 208 329 minecraft:dark_prismarine
setblock 167 208 363 minecraft:blue_terracotta
setblock 170 208 327 minecraft:dark_prismarine
setblock 170 208 363 minecraft:blue_terracotta
setblock 171 208 323 minecraft:dark_prismarine
setblock 171 208 363 minecraft:dark_prismarine
fill 172 208 323 172 210 324 minecraft:blue_terracotta
setblock 172 208 328 minecraft:purple_concrete
fill 172 208 363 172 211 363 minecraft:blue_terracotta
fill 174 208 362 176 208 362 minecraft:blue_terracotta
setblock 175 208 324 minecraft:dark_prismarine
fill 175 208 325 178 208 325 minecraft:blue_terracotta
setblock 176 208 323 minecraft:dark_prismarine
fill 176 208 324 176 211 324 minecraft:blue_terracotta
fill 176 208 340 176 234 340 minecraft:magenta_terracotta
setblock 176 208 363 minecraft:dark_prismarine
fill 177 208 323 177 211 323 minecraft:blue_terracotta
setblock 177 208 362 minecraft:dark_prismarine
fill 177 208 363 177 211 363 minecraft:blue_terracotta
setblock 178 208 326 minecraft:dark_prismarine
fill 178 208 362 178 211 362 minecraft:blue_terracotta
setblock 179 208 325 minecraft:dark_prismarine
fill 179 208 326 179 211 326 minecraft:blue_terracotta
setblock 179 208 340 minecraft:dark_prismarine
setblock 179 208 341 minecraft:blue_terracotta
setblock 179 208 361 minecraft:blue_terracotta
setblock 180 208 324 minecraft:dark_prismarine
fill 180 208 325 180 211 325 minecraft:blue_terracotta
setblock 180 208 328 minecraft:blue_terracotta
setblock 180 208 329 minecraft:dark_prismarine
fill 180 208 330 180 209 330 minecraft:blue_terracotta
setblock 180 208 334 minecraft:dark_prismarine
setblock 180 208 335 minecraft:blue_terracotta
setblock 180 208 339 minecraft:dark_prismarine
fill 180 208 340 180 209 340 minecraft:blue_terracotta
setblock 180 208 344 minecraft:dark_prismarine
fill 180 208 345 180 209 345 minecraft:blue_terracotta
setblock 181 208 323 minecraft:dark_prismarine
fill 181 208 324 181 211 324 minecraft:blue_terracotta
setblock 181 208 328 minecraft:dark_prismarine
fill 181 208 329 181 211 329 minecraft:blue_terracotta
setblock 181 208 333 minecraft:dark_prismarine
fill 181 208 334 181 209 334 minecraft:blue_terracotta
setblock 181 208 338 minecraft:dark_prismarine
fill 181 208 339 181 210 339 minecraft:blue_terracotta
setblock 181 208 343 minecraft:dark_prismarine
fill 181 208 344 181 211 344 minecraft:blue_terracotta
setblock 181 208 359 minecraft:blue_terracotta
setblock 181 208 363 minecraft:dark_prismarine
fill 182 208 323 182 211 323 minecraft:blue_terracotta
setblock 182 208 327 minecraft:dark_prismarine
fill 182 208 328 182 211 328 minecraft:blue_terracotta
setblock 182 208 332 minecraft:dark_prismarine
fill 182 208 333 182 210 333 minecraft:blue_terracotta
setblock 182 208 337 minecraft:dark_prismarine
fill 182 208 338 182 210 338 minecraft:blue_terracotta
setblock 182 208 342 minecraft:dark_prismarine
fill 182 208 343 182 211 343 minecraft:blue_terracotta
setblock 182 208 347 minecraft:dark_prismarine
fill 182 208 348 182 210 348 minecraft:blue_terracotta
setblock 182 208 357 minecraft:dark_prismarine
fill 182 208 358 182 209 358 minecraft:blue_terracotta
setblock 182 208 362 minecraft:dark_prismarine
fill 182 208 363 182 211 363 minecraft:blue_terracotta
fill 183 208 324 183 220 324 minecraft:blue_terracotta
setblock 183 208 337 minecraft:light_blue_wool
fill 142 209 323 142 209 325 minecraft:blue_terracotta
setblock 142 209 326 minecraft:dark_prismarine
fill 142 209 327 142 212 327 minecraft:blue_terracotta
setblock 142 209 331 minecraft:dark_prismarine
setblock 142 209 341 minecraft:dark_prismarine
fill 142 209 342 142 210 342 minecraft:blue_terracotta
setblock 142 209 346 minecraft:dark_prismarine
fill 142 209 347 142 212 347 minecraft:blue_terracotta
setblock 142 209 356 minecraft:dark_prismarine
fill 142 209 357 142 210 357 minecraft:blue_terracotta
setblock 142 209 361 minecraft:dark_prismarine
fill 142 209 362 142 212 362 minecraft:blue_terracotta
setblock 143 209 325 minecraft:dark_prismarine
fill 143 209 326 143 210 326 minecraft:blue_terracotta
setblock 143 209 360 minecraft:dark_prismarine
fill 143 209 361 143 210 361 minecraft:blue_terracotta
setblock 144 209 324 minecraft:dark_prismarine
setblock 144 209 325 minecraft:light[level=12]
setblock 144 209 332 minecraft:light[level=12]
setblock 144 209 339 minecraft:light[level=12]
setblock 144 209 346 minecraft:light[level=12]
setblock 144 209 353 minecraft:light[level=12]
setblock 144 209 360 minecraft:light[level=12]
setblock 145 209 323 minecraft:dark_prismarine
fill 145 209 324 145 210 324 minecraft:blue_terracotta
setblock 145 209 363 minecraft:dark_prismarine
fill 146 209 323 149 209 323 minecraft:blue_terracotta
setblock 146 209 362 minecraft:dark_prismarine
fill 146 209 363 149 209 363 minecraft:blue_terracotta
fill 147 209 362 147 210 362 minecraft:blue_terracotta
setblock 150 209 323 minecraft:dark_prismarine
setblock 150 209 363 minecraft:dark_prismarine
fill 151 209 323 154 209 323 minecraft:blue_terracotta
setblock 151 209 325 minecraft:light[level=12]
setblock 151 209 332 minecraft:light[level=12]
setblock 151 209 339 minecraft:light[level=12]
setblock 151 209 346 minecraft:light[level=12]
setblock 151 209 353 minecraft:light[level=12]
setblock 151 209 360 minecraft:light[level=12]
setblock 151 209 362 minecraft:dark_prismarine
fill 151 209 363 151 212 363 minecraft:blue_terracotta
fill 152 209 324 153 209 324 minecraft:blue_terracotta
fill 152 209 328 154 209 328 minecraft:purple_concrete
setblock 152 209 361 minecraft:dark_prismarine
fill 152 209 362 152 212 362 minecraft:blue_terracotta
fill 153 209 361 153 210 361 minecraft:blue_terracotta
setblock 154 209 324 minecraft:dark_prismarine
setblock 155 209 323 minecraft:dark_prismarine
fill 155 209 324 155 212 324 minecraft:blue_terracotta
setblock 155 209 328 minecraft:dark_prismarine
setblock 155 209 363 minecraft:dark_prismarine
fill 156 209 323 156 212 323 minecraft:blue_terracotta
fill 156 209 327 166 209 327 minecraft:dark_prismarine
fill 156 209 329 167 209 329 minecraft:dark_prismarine
setblock 156 209 362 minecraft:dark_prismarine
fill 156 209 363 156 212 363 minecraft:blue_terracotta
setblock 157 209 361 minecraft:dark_prismarine
fill 157 209 362 157 212 362 minecraft:blue_terracotta
setblock 158 209 325 minecraft:light[level=12]
setblock 158 209 332 minecraft:light[level=12]
setblock 158 209 339 minecraft:light[level=12]
setblock 158 209 346 minecraft:light[level=12]
setblock 158 209 353 minecraft:light[level=12]
setblock 158 209 360 minecraft:light[level=12]
fill 158 209 361 158 210 361 minecraft:blue_terracotta
setblock 159 209 324 minecraft:dark_prismarine
setblock 160 209 323 minecraft:dark_prismarine
fill 160 209 324 160 210 324 minecraft:blue_terracotta
fill 160 209 328 163 210 328 minecraft:dark_prismarine
setblock 160 209 363 minecraft:dark_prismarine
fill 161 209 323 161 212 323 minecraft:blue_terracotta
setblock 161 209 362 minecraft:dark_prismarine
fill 161 209 363 161 212 363 minecraft:blue_terracotta
fill 162 209 322 162 220 322 minecraft:blue_terracotta
setblock 162 209 362 minecraft:blue_terracotta
setblock 165 209 323 minecraft:dark_prismarine
setblock 165 209 325 minecraft:light[level=12]
setblock 165 209 332 minecraft:light[level=12]
setblock 165 209 339 minecraft:light[level=12]
setblock 165 209 346 minecraft:light[level=12]
setblock 165 209 353 minecraft:light[level=12]
setblock 165 209 360 minecraft:light[level=12]
setblock 165 209 363 minecraft:dark_prismarine
fill 166 209 323 169 209 323 minecraft:blue_terracotta
setblock 169 209 363 minecraft:purple_concrete
setblock 170 209 323 minecraft:dark_prismarine
fill 170 209 328 171 209 328 minecraft:purple_concrete
fill 171 209 323 171 212 323 minecraft:blue_terracotta
fill 171 209 363 171 210 363 minecraft:blue_terracotta
setblock 172 209 325 minecraft:light[level=12]
setblock 172 209 332 minecraft:light[level=12]
setblock 172 209 339 minecraft:light[level=12]
setblock 172 209 346 minecraft:light[level=12]
setblock 172 209 353 minecraft:light[level=12]
setblock 172 209 360 minecraft:light[level=12]
setblock 174 209 323 minecraft:blue_terracotta
setblock 174 209 324 minecraft:dark_prismarine
fill 174 209 325 177 209 325 minecraft:blue_terracotta
fill 174 209 362 175 209 362 minecraft:blue_terracotta
setblock 175 209 323 minecraft:dark_prismarine
fill 175 209 324 175 212 324 minecraft:blue_terracotta
setblock 175 209 363 minecraft:dark_prismarine
fill 176 209 323 176 212 323 minecraft:blue_terracotta
setblock 176 209 362 minecraft:dark_prismarine
fill 176 209 363 176 212 363 minecraft:blue_terracotta
setblock 177 209 326 minecraft:dark_prismarine
fill 177 209 362 177 211 362 minecraft:blue_terracotta
setblock 178 209 325 minecraft:dark_prismarine
fill 178 209 326 178 212 326 minecraft:blue_terracotta
setblock 179 209 324 minecraft:dark_prismarine
fill 179 209 325 179 212 325 minecraft:blue_terracotta
setblock 179 209 327 minecraft:blue_terracotta
setblock 179 209 332 minecraft:light[level=12]
setblock 179 209 339 minecraft:light[level=12]
setblock 179 209 346 minecraft:light[level=12]
setblock 179 209 353 minecraft:light[level=12]
setblock 179 209 360 minecraft:light[level=12]
setblock 180 209 323 minecraft:dark_prismarine
fill 180 209 324 180 212 324 minecraft:blue_terracotta
setblock 180 209 328 minecraft:dark_prismarine
fill 180 209 329 180 210 329 minecraft:blue_terracotta
setblock 180 209 338 minecraft:dark_prismarine
setblock 180 209 339 minecraft:blue_terracotta
setblock 180 209 343 minecraft:dark_prismarine
fill 180 209 344 180 210 344 minecraft:blue_terracotta
setblock 180 209 363 minecraft:dark_prismarine
fill 181 209 323 181 212 323 minecraft:blue_terracotta
setblock 181 209 327 minecraft:dark_prismarine
fill 181 209 328 181 212 328 minecraft:blue_terracotta
setblock 181 209 332 minecraft:dark_prismarine
setblock 181 209 333 minecraft:blue_terracotta
setblock 181 209 337 minecraft:dark_prismarine
fill 181 209 338 181 210 338 minecraft:blue_terracotta
setblock 181 209 342 minecraft:dark_prismarine
fill 181 209 343 181 211 343 minecraft:blue_terracotta
setblock 181 209 347 minecraft:dark_prismarine
setblock 181 209 362 minecraft:dark_prismarine
fill 181 209 363 181 212 363 minecraft:blue_terracotta
setblock 182 209 326 minecraft:dark_prismarine
fill 182 209 327 182 212 327 minecraft:blue_terracotta
setblock 182 209 331 minecraft:dark_prismarine
fill 182 209 332 182 211 332 minecraft:blue_terracotta
setblock 182 209 336 minecraft:dark_prismarine
fill 182 209 337 183 210 337 minecraft:blue_terracotta
setblock 182 209 341 minecraft:dark_prismarine
fill 182 209 342 182 211 342 minecraft:blue_terracotta
setblock 182 209 346 minecraft:dark_prismarine
fill 182 209 347 182 211 347 minecraft:blue_terracotta
setblock 182 209 361 minecraft:dark_prismarine
fill 182 209 362 182 212 362 minecraft:blue_terracotta
setblock 183 209 349 minecraft:light_blue_wool
fill 142 210 323 142 210 324 minecraft:blue_terracotta
setblock 142 210 325 minecraft:dark_prismarine
fill 142 210 326 142 213 326 minecraft:blue_terracotta
setblock 142 210 340 minecraft:dark_prismarine
setblock 142 210 341 minecraft:blue_terracotta
setblock 142 210 345 minecraft:dark_prismarine
fill 142 210 346 142 212 346 minecraft:blue_terracotta
setblock 142 210 349 minecraft:blue_terracotta
setblock 142 210 352 minecraft:purple_concrete
setblock 142 210 360 minecraft:dark_prismarine
fill 142 210 361 142 213 361 minecraft:blue_terracotta
setblock 143 210 324 minecraft:dark_prismarine
fill 143 210 325 143 211 325 minecraft:blue_terracotta
setblock 143 210 360 minecraft:blue_terracotta
setblock 144 210 323 minecraft:dark_prismarine
fill 144 210 324 144 211 324 minecraft:blue_terracotta
setblock 144 210 363 minecraft:dark_prismarine
fill 145 210 323 148 210 323 minecraft:blue_terracotta
setblock 145 210 362 minecraft:dark_prismarine
fill 145 210 363 148 210 363 minecraft:blue_terracotta
setblock 146 210 362 minecraft:blue_terracotta
setblock 149 210 323 minecraft:dark_prismarine
setblock 149 210 363 minecraft:dark_prismarine
fill 150 210 323 153 210 323 minecraft:blue_terracotta
setblock 150 210 362 minecraft:dark_prismarine
fill 150 210 363 150 213 363 minecraft:blue_terracotta
fill 151 210 325 151 213 325 minecraft:purple_concrete
fill 151 210 362 151 212 362 minecraft:blue_terracotta
setblock 152 210 324 minecraft:blue_terracotta
fill 152 210 326 152 213 326 minecraft:purple_concrete
setblock 153 210 324 minecraft:dark_prismarine
fill 153 210 325 153 213 325 minecraft:purple_concrete
setblock 154 210 323 minecraft:dark_prismarine
fill 154 210 324 154 213 324 minecraft:blue_terracotta
fill 154 210 328 156 210 328 minecraft:purple_concrete
setblock 154 210 363 minecraft:dark_prismarine
fill 155 210 323 155 213 323 minecraft:blue_terracotta
setblock 155 210 362 minecraft:dark_prismarine
fill 155 210 363 155 213 363 minecraft:blue_terracotta
setblock 156 210 361 minecraft:dark_prismarine
fill 156 210 362 156 213 362 minecraft:blue_terracotta
fill 157 210 328 159 210 328 minecraft:dark_prismarine
setblock 157 210 361 minecraft:blue_terracotta
setblock 158 210 324 minecraft:dark_prismarine
setblock 159 210 323 minecraft:dark_prismarine
fill 159 210 324 159 211 324 minecraft:blue_terracotta
fill 159 210 359 159 211 359 minecraft:sea_lantern
setblock 159 210 363 minecraft:dark_prismarine
fill 160 210 323 160 213 323 minecraft:blue_terracotta
fill 160 210 327 163 210 327 minecraft:dark_prismarine
fill 160 210 329 163 210 329 minecraft:dark_prismarine
setblock 160 210 362 minecraft:dark_prismarine
fill 160 210 363 160 212 363 minecraft:blue_terracotta
setblock 161 210 362 minecraft:blue_terracotta
setblock 164 210 323 minecraft:dark_prismarine
fill 164 210 328 166 210 328 minecraft:dark_prismarine
setblock 164 210 363 minecraft:dark_prismarine
setblock 167 210 328 minecraft:purple_concrete
setblock 168 210 323 minecraft:blue_terracotta
setblock 169 210 323 minecraft:dark_prismarine
fill 170 210 323 170 213 323 minecraft:blue_terracotta
fill 171 210 324 171 211 324 minecraft:blue_terracotta
setblock 173 210 323 minecraft:blue_terracotta
setblock 173 210 324 minecraft:dark_prismarine
fill 173 210 325 176 210 325 minecraft:blue_terracotta
setblock 174 210 323 minecraft:dark_prismarine
fill 174 210 324 174 213 324 minecraft:blue_terracotta
setblock 174 210 363 minecraft:dark_prismarine
fill 175 210 323 175 213 323 minecraft:blue_terracotta
setblock 175 210 362 minecraft:dark_prismarine
fill 175 210 363 175 213 363 minecraft:blue_terracotta
setblock 176 210 326 minecraft:dark_prismarine
fill 176 210 362 176 211 362 minecraft:blue_terracotta
setblock 177 210 325 minecraft:dark_prismarine
fill 177 210 326 177 213 326 minecraft:blue_terracotta
setblock 178 210 324 minecraft:dark_prismarine
fill 178 210 325 178 213 325 minecraft:blue_terracotta
setblock 179 210 323 minecraft:dark_prismarine
fill 179 210 324 179 213 324 minecraft:blue_terracotta
setblock 179 210 363 minecraft:dark_prismarine
fill 180 210 323 180 213 323 minecraft:blue_terracotta
setblock 180 210 327 minecraft:dark_prismarine
fill 180 210 328 180 213 328 minecraft:blue_terracotta
setblock 180 210 342 minecraft:dark_prismarine
setblock 180 210 343 minecraft:blue_terracotta
setblock 180 210 362 minecraft:dark_prismarine
fill 180 210 363 180 213 363 minecraft:blue_terracotta
setblock 181 210 326 minecraft:dark_prismarine
fill 181 210 327 181 213 327 minecraft:blue_terracotta
setblock 181 210 331 minecraft:dark_prismarine
setblock 181 210 332 minecraft:blue_terracotta
setblock 181 210 337 minecraft:blue_terracotta
setblock 181 210 341 minecraft:dark_prismarine
fill 181 210 342 181 211 342 minecraft:blue_terracotta
setblock 181 210 346 minecraft:dark_prismarine
setblock 181 210 361 minecraft:dark_prismarine
setblock 181 210 362 minecraft:blue_terracotta
setblock 182 210 325 minecraft:dark_prismarine
fill 182 210 326 182 213 326 minecraft:blue_terracotta
setblock 182 210 330 minecraft:dark_prismarine
fill 182 210 331 182 213 331 minecraft:blue_terracotta
setblock 182 210 335 minecraft:dark_prismarine
setblock 182 210 336 minecraft:blue_terracotta
setblock 182 210 340 minecraft:dark_prismarine
fill 182 210 341 182 211 341 minecraft:blue_terracotta
setblock 182 210 345 minecraft:dark_prismarine
fill 182 210 346 182 212 346 minecraft:blue_terracotta
setblock 182 210 359 minecraft:purple_concrete
setblock 182 210 360 minecraft:dark_prismarine
fill 182 210 361 182 211 361 minecraft:blue_terracotta
fill 183 210 349 183 220 349 minecraft:blue_terracotta
setblock 142 211 323 minecraft:blue_terracotta
setblock 142 211 324 minecraft:dark_prismarine
fill 142 211 325 142 214 325 minecraft:blue_terracotta
setblock 142 211 329 minecraft:dark_prismarine
setblock 142 211 333 minecraft:purple_concrete
setblock 142 211 344 minecraft:dark_prismarine
fill 142 211 345 142 212 345 minecraft:blue_terracotta
setblock 142 211 349 minecraft:dark_prismarine
setblock 142 211 359 minecraft:dark_prismarine
fill 142 211 360 142 212 360 minecraft:blue_terracotta
setblock 143 211 323 minecraft:dark_prismarine
fill 143 211 324 143 212 324 minecraft:blue_terracotta
setblock 143 211 363 minecraft:dark_prismarine
fill 144 211 323 147 211 323 minecraft:blue_terracotta
setblock 144 211 362 minecraft:dark_prismarine
fill 144 211 363 147 211 363 minecraft:blue_terracotta
setblock 146 211 364 minecraft:light_blue_wool
setblock 148 211 323 minecraft:dark_prismarine
setblock 148 211 363 minecraft:dark_prismarine
fill 149 211 323 152 211 323 minecraft:blue_terracotta
setblock 149 211 362 minecraft:dark_prismarine
fill 149 211 363 149 214 363 minecraft:blue_terracotta
setblock 150 211 362 minecraft:blue_terracotta
fill 151 211 326 151 213 326 minecraft:purple_concrete
setblock 152 211 324 minecraft:dark_prismarine
setblock 153 211 323 minecraft:dark_prismarine
fill 153 211 324 153 214 324 minecraft:blue_terracotta
fill 153 211 326 153 213 326 minecraft:purple_concrete
setblock 153 211 363 minecraft:dark_prismarine
fill 154 211 323 154 214 323 minecraft:blue_terracotta
setblock 154 211 362 minecraft:dark_prismarine
fill 154 211 363 154 214 363 minecraft:blue_terracotta
fill 155 211 362 155 213 362 minecraft:blue_terracotta
setblock 157 211 324 minecraft:dark_prismarine
fill 157 211 328 166 211 328 minecraft:purple_concrete
setblock 158 211 323 minecraft:dark_prismarine
fill 158 211 324 158 212 324 minecraft:blue_terracotta
setblock 158 211 363 minecraft:dark_prismarine
fill 159 211 323 159 214 323 minecraft:blue_terracotta
setblock 159 211 362 minecraft:dark_prismarine
fill 159 211 363 159 213 363 minecraft:blue_terracotta
setblock 163 211 323 minecraft:dark_prismarine
setblock 168 211 323 minecraft:dark_prismarine
fill 169 211 323 169 214 323 minecraft:blue_terracotta
fill 170 211 328 170 213 328 minecraft:magenta_terracotta
fill 170 211 356 170 234 356 minecraft:magenta_terracotta
setblock 172 211 323 minecraft:blue_terracotta
setblock 172 211 324 minecraft:dark_prismarine
setblock 173 211 323 minecraft:dark_prismarine
fill 173 211 324 173 213 325 minecraft:blue_terracotta
setblock 173 211 363 minecraft:dark_prismarine
fill 174 211 323 174 214 323 minecraft:blue_terracotta
fill 174 211 325 175 211 325 minecraft:blue_terracotta
fill 174 211 363 174 214 363 minecraft:blue_terracotta
setblock 176 211 325 minecraft:dark_prismarine
fill 176 211 326 176 214 326 minecraft:blue_terracotta
setblock 177 211 324 minecraft:dark_prismarine
fill 177 211 325 177 214 325 minecraft:blue_terracotta
setblock 178 211 323 minecraft:dark_prismarine
fill 178 211 324 178 214 324 minecraft:blue_terracotta
setblock 178 211 363 minecraft:dark_prismarine
fill 179 211 323 179 214 323 minecraft:blue_terracotta
setblock 179 211 362 minecraft:dark_prismarine
fill 179 211 363 179 214 363 minecraft:blue_terracotta
setblock 180 211 326 minecraft:dark_prismarine
fill 180 211 327 180 214 327 minecraft:blue_terracotta
setblock 180 211 362 minecraft:blue_terracotta
setblock 181 211 325 minecraft:dark_prismarine
fill 181 211 326 181 214 326 minecraft:blue_terracotta
setblock 181 211 330 minecraft:dark_prismarine
setblock 181 211 345 minecraft:dark_prismarine
setblock 182 211 324 minecraft:dark_prismarine
fill 182 211 325 182 214 325 minecraft:blue_terracotta
setblock 182 211 329 minecraft:dark_prismarine
fill 182 211 330 182 214 330 minecraft:blue_terracotta
setblock 182 211 339 minecraft:dark_prismarine
setblock 182 211 340 minecraft:blue_terracotta
setblock 182 211 344 minecraft:dark_prismarine
fill 182 211 345 182 212 345 minecraft:blue_terracotta
setblock 182 211 353 minecraft:purple_concrete
fill 183 211 337 183 220 337 minecraft:blue_terracotta
setblock 183 211 348 minecraft:cyan_concrete
setblock 142 212 323 minecraft:dark_prismarine
fill 142 212 324 142 215 324 minecraft:blue_terracotta
setblock 142 212 328 minecraft:dark_prismarine
setblock 142 212 339 minecraft:purple_concrete
setblock 142 212 348 minecraft:dark_prismarine
setblock 142 212 363 minecraft:dark_prismarine
fill 143 212 323 146 212 323 minecraft:blue_terracotta
fill 143 212 363 146 212 363 minecraft:blue_terracotta
fill 146 212 364 146 218 364 minecraft:blue_terracotta
setblock 147 212 323 minecraft:dark_prismarine
setblock 147 212 363 minecraft:dark_prismarine
fill 148 212 323 151 212 323 minecraft:blue_terracotta
setblock 148 212 347 minecraft:pink_terracotta
fill 148 212 363 148 215 363 minecraft:blue_terracotta
fill 149 212 347 149 213 347 minecraft:magenta_terracotta
fill 151 212 324 151 213 324 minecraft:purple_concrete
setblock 152 212 323 minecraft:dark_prismarine
setblock 152 212 324 minecraft:blue_terracotta
fill 152 212 327 152 213 327 minecraft:purple_concrete
setblock 152 212 363 minecraft:dark_prismarine
fill 153 212 323 153 215 323 minecraft:blue_terracotta
setblock 153 212 362 minecraft:dark_prismarine
fill 153 212 363 153 215 363 minecraft:blue_terracotta
setblock 154 212 331 minecraft:pink_terracotta
fill 154 212 362 154 213 362 minecraft:blue_terracotta
setblock 156 212 324 minecraft:dark_prismarine
setblock 157 212 323 minecraft:dark_prismarine
fill 157 212 324 157 213 324 minecraft:blue_terracotta
setblock 157 212 363 minecraft:dark_prismarine
fill 158 212 323 158 215 323 minecraft:blue_terracotta
setblock 158 212 362 minecraft:dark_prismarine
fill 158 212 363 158 214 363 minecraft:blue_terracotta
fill 159 212 359 159 219 359 minecraft:black_concrete
setblock 162 212 323 minecraft:purple_concrete
setblock 162 212 363 minecraft:purple_concrete
setblock 169 212 328 minecraft:pink_terracotta
setblock 170 212 355 minecraft:pink_terracotta
setblock 171 212 324 minecraft:dark_prismarine
setblock 172 212 323 minecraft:dark_prismarine
fill 172 212 324 172 215 324 minecraft:blue_terracotta
setblock 172 212 363 minecraft:dark_prismarine
fill 173 212 323 173 215 323 minecraft:blue_terracotta
fill 173 212 363 173 215 363 minecraft:blue_terracotta
setblock 174 212 325 minecraft:blue_terracotta
setblock 175 212 325 minecraft:dark_prismarine
setblock 176 212 324 minecraft:dark_prismarine
fill 176 212 325 176 215 325 minecraft:blue_terracotta
fill 176 212 339 177 212 339 minecraft:pink_terracotta
setblock 177 212 323 minecraft:dark_prismarine
fill 177 212 324 177 215 324 minecraft:blue_terracotta
setblock 177 212 363 minecraft:dark_prismarine
fill 178 212 323 178 215 323 minecraft:blue_terracotta
fill 178 212 363 178 215 363 minecraft:blue_terracotta
setblock 180 212 325 minecraft:dark_prismarine
fill 180 212 326 180 215 326 minecraft:blue_terracotta
setblock 181 212 324 minecraft:dark_prismarine
fill 181 212 325 181 215 325 minecraft:blue_terracotta
setblock 181 212 329 minecraft:dark_prismarine
setblock 181 212 330 minecraft:blue_terracotta
setblock 182 212 323 minecraft:dark_prismarine
fill 182 212 324 182 215 324 minecraft:blue_terracotta
setblock 182 212 328 minecraft:dark_prismarine
fill 182 212 329 182 215 329 minecraft:blue_terracotta
setblock 182 212 343 minecraft:dark_prismarine
setblock 182 212 344 minecraft:blue_terracotta
setblock 182 212 347 minecraft:purple_concrete
setblock 182 212 363 minecraft:dark_prismarine
fill 183 212 348 183 214 348 minecraft:blue_terracotta
fill 142 213 323 145 213 323 minecraft:blue_terracotta
setblock 142 213 327 minecraft:dark_prismarine
setblock 142 213 328 minecraft:blue_terracotta
setblock 142 213 345 minecraft:purple_concrete
setblock 142 213 362 minecraft:dark_prismarine
fill 142 213 363 145 213 363 minecraft:blue_terracotta
setblock 144 213 325 minecraft:light[level=13]
setblock 144 213 333 minecraft:light[level=13]
setblock 144 213 341 minecraft:light[level=13]
setblock 144 213 349 minecraft:light[level=13]
setblock 144 213 357 minecraft:light[level=13]
setblock 146 213 323 minecraft:dark_prismarine
setblock 146 213 363 minecraft:dark_prismarine
fill 147 213 323 150 213 323 minecraft:blue_terracotta
fill 147 213 363 147 214 363 minecraft:blue_terracotta
fill 148 213 347 148 230 347 minecraft:magenta_terracotta
fill 150 213 325 150 213 326 minecraft:purple_concrete
setblock 151 213 323 minecraft:dark_prismarine
setblock 151 213 327 minecraft:purple_concrete
setblock 151 213 363 minecraft:dark_prismarine
fill 152 213 323 152 216 323 minecraft:blue_terracotta
setblock 152 213 324 minecraft:purple_concrete
setblock 152 213 333 minecraft:light[level=13]
setblock 152 213 341 minecraft:light[level=13]
setblock 152 213 349 minecraft:light[level=13]
setblock 152 213 357 minecraft:light[level=13]
setblock 152 213 362 minecraft:dark_prismarine
fill 152 213 363 152 216 363 minecraft:blue_terracotta
setblock 153 213 327 minecraft:purple_concrete
setblock 153 213 362 minecraft:blue_terracotta
fill 154 213 325 154 213 326 minecraft:purple_concrete
fill 154 213 331 154 231 331 minecraft:magenta_terracotta
setblock 155 213 324 minecraft:dark_prismarine
setblock 156 213 323 minecraft:dark_prismarine
fill 156 213 324 156 214 324 minecraft:blue_terracotta
setblock 156 213 363 minecraft:dark_prismarine
fill 157 213 323 157 216 323 minecraft:blue_terracotta
fill 157 213 363 157 215 363 minecraft:blue_terracotta
fill 158 213 359 158 219 359 minecraft:black_concrete
fill 159 213 360 159 219 360 minecraft:black_concrete
setblock 160 213 325 minecraft:light[level=13]
setblock 160 213 333 minecraft:light[level=13]
setblock 160 213 349 minecraft:light[level=13]
setblock 160 213 357 minecraft:light[level=13]
setblock 168 213 325 minecraft:light[level=13]
setblock 168 213 333 minecraft:light[level=13]
setblock 168 213 341 minecraft:light[level=13]
setblock 168 213 349 minecraft:light[level=13]
setblock 168 213 357 minecraft:light[level=13]
setblock 168 213 363 minecraft:purple_concrete
fill 169 213 328 169 234 328 minecraft:magenta_terracotta
fill 169 213 356 169 234 356 minecraft:magenta_terracotta
setblock 170 213 324 minecraft:dark_prismarine
fill 170 213 355 170 229 355 minecraft:magenta_terracotta
setblock 171 213 323 minecraft:dark_prismarine
fill 171 213 324 171 216 324 minecraft:blue_terracotta
fill 172 213 323 172 216 323 minecraft:blue_terracotta
fill 172 213 325 172 214 325 minecraft:blue_terracotta
setblock 174 213 325 minecraft:dark_prismarine
setblock 175 213 324 minecraft:dark_prismarine
fill 175 213 325 175 215 326 minecraft:blue_terracotta
setblock 176 213 323 minecraft:dark_prismarine
fill 176 213 324 176 216 324 minecraft:blue_terracotta
setblock 176 213 333 minecraft:light[level=13]
fill 176 213 339 177 229 339 minecraft:magenta_terracotta
setblock 176 213 341 minecraft:light[level=13]
setblock 176 213 349 minecraft:light[level=13]
setblock 176 213 357 minecraft:light[level=13]
setblock 176 213 363 minecraft:dark_prismarine
fill 177 213 323 177 216 323 minecraft:blue_terracotta
fill 177 213 363 177 216 363 minecraft:blue_terracotta
setblock 179 213 325 minecraft:dark_prismarine
setblock 180 213 324 minecraft:dark_prismarine
fill 180 213 325 180 215 325 minecraft:blue_terracotta
setblock 181 213 323 minecraft:dark_prismarine
fill 181 213 324 181 216 324 minecraft:blue_terracotta
setblock 181 213 328 minecraft:dark_prismarine
fill 181 213 329 181 216 329 minecraft:blue_terracotta
setblock 181 213 363 minecraft:dark_prismarine
fill 182 213 323 182 216 323 minecraft:blue_terracotta
setblock 182 213 327 minecraft:dark_prismarine
fill 182 213 328 182 216 328 minecraft:blue_terracotta
setblock 182 213 341 minecraft:purple_concrete
setblock 182 213 360 minecraft:purple_concrete
setblock 182 213 363 minecraft:blue_terracotta
fill 142 214 323 144 214 323 minecraft:blue_terracotta
setblock 142 214 326 minecraft:dark_prismarine
fill 142 214 327 142 217 327 minecraft:blue_terracotta
setblock 142 214 332 minecraft:purple_concrete
setblock 142 214 351 minecraft:purple_concrete
fill 142 214 362 142 214 363 minecraft:blue_terracotta
fill 143 214 363 144 214 363 minecraft:blue_terracotta
setblock 145 214 323 minecraft:dark_prismarine
fill 148 214 323 149 214 323 minecraft:blue_terracotta
fill 149 214 324 152 216 328 minecraft:dark_prismarine
setblock 150 214 323 minecraft:dark_prismarine
setblock 150 214 363 minecraft:dark_prismarine
fill 151 214 323 151 217 323 minecraft:blue_terracotta
fill 151 214 363 151 217 363 minecraft:blue_terracotta
fill 153 214 325 155 216 328 minecraft:dark_prismarine
setblock 154 214 324 minecraft:dark_prismarine
setblock 155 214 323 minecraft:dark_prismarine
fill 155 214 324 155 215 324 minecraft:blue_terracotta
setblock 155 214 363 minecraft:dark_prismarine
fill 156 214 323 156 217 323 minecraft:blue_terracotta
fill 156 214 363 156 216 363 minecraft:blue_terracotta
fill 158 214 360 158 219 360 minecraft:black_concrete
fill 159 214 358 159 219 358 minecraft:black_concrete
fill 160 214 359 160 219 359 minecraft:black_concrete
setblock 170 214 323 minecraft:dark_prismarine
fill 170 214 324 170 217 324 minecraft:blue_terracotta
fill 171 214 323 171 217 323 minecraft:blue_terracotta
setblock 173 214 324 minecraft:blue_terracotta
setblock 173 214 325 minecraft:dark_prismarine
setblock 174 214 324 minecraft:dark_prismarine
fill 174 214 325 174 216 326 minecraft:blue_terracotta
setblock 175 214 323 minecraft:dark_prismarine
fill 175 214 324 175 217 324 minecraft:blue_terracotta
setblock 175 214 363 minecraft:dark_prismarine
fill 176 214 323 176 217 323 minecraft:blue_terracotta
fill 176 214 363 176 217 363 minecraft:blue_terracotta
setblock 177 214 326 minecraft:dark_prismarine
setblock 178 214 325 minecraft:dark_prismarine
setblock 179 214 324 minecraft:dark_prismarine
fill 179 214 325 179 217 325 minecraft:blue_terracotta
setblock 180 214 323 minecraft:dark_prismarine
fill 180 214 324 180 217 324 minecraft:blue_terracotta
setblock 180 214 363 minecraft:dark_prismarine
fill 181 214 323 181 217 323 minecraft:blue_terracotta
setblock 181 214 327 minecraft:dark_prismarine
fill 181 214 328 181 217 328 minecraft:blue_terracotta
setblock 181 214 363 minecraft:blue_terracotta
setblock 182 214 326 minecraft:dark_prismarine
fill 182 214 327 182 217 327 minecraft:blue_terracotta
setblock 182 214 335 minecraft:purple_concrete
setblock 182 214 354 minecraft:purple_concrete
fill 142 215 323 143 215 323 minecraft:blue_terracotta
setblock 142 215 325 minecraft:dark_prismarine
fill 142 215 326 142 218 326 minecraft:blue_terracotta
setblock 142 215 338 minecraft:purple_concrete
setblock 142 215 357 minecraft:purple_concrete
setblock 142 215 363 minecraft:blue_terracotta
setblock 144 215 325 minecraft:light[level=12]
setblock 144 215 332 minecraft:light[level=12]
setblock 144 215 339 minecraft:light[level=12]
setblock 144 215 346 minecraft:light[level=12]
setblock 144 215 353 minecraft:light[level=12]
setblock 144 215 360 minecraft:light[level=12]
setblock 148 215 323 minecraft:blue_terracotta
setblock 149 215 323 minecraft:dark_prismarine
setblock 149 215 363 minecraft:dark_prismarine
fill 150 215 323 150 216 323 minecraft:blue_terracotta
fill 150 215 363 150 218 363 minecraft:blue_terracotta
setblock 151 215 332 minecraft:light[level=12]
setblock 151 215 339 minecraft:light[level=12]
setblock 151 215 346 minecraft:light[level=12]
setblock 151 215 353 minecraft:light[level=12]
setblock 151 215 360 minecraft:light[level=12]
setblock 153 215 324 minecraft:dark_prismarine
setblock 154 215 323 minecraft:dark_prismarine
fill 154 215 324 154 216 324 minecraft:blue_terracotta
setblock 154 215 363 minecraft:dark_prismarine
fill 155 215 323 155 218 323 minecraft:blue_terracotta
fill 155 215 363 155 218 363 minecraft:blue_terracotta
fill 157 215 359 157 219 360 minecraft:black_concrete
setblock 158 215 325 minecraft:light[level=12]
setblock 158 215 332 minecraft:light[level=12]
setblock 158 215 339 minecraft:light[level=12]
setblock 158 215 346 minecraft:light[level=12]
setblock 158 215 353 minecraft:light[level=12]
fill 158 215 358 158 219 358 minecraft:black_concrete
fill 158 215 361 159 219 361 minecraft:black_concrete
fill 160 215 358 160 219 358 minecraft:black_concrete
fill 160 215 360 160 219 360 minecraft:black_concrete
setblock 161 215 363 minecraft:purple_concrete
setblock 163 215 323 minecraft:purple_concrete
setblock 165 215 325 minecraft:light[level=12]
setblock 165 215 332 minecraft:light[level=12]
setblock 165 215 339 minecraft:light[level=12]
setblock 165 215 346 minecraft:light[level=12]
setblock 165 215 353 minecraft:light[level=12]
setblock 165 215 360 minecraft:light[level=12]
setblock 168 215 323 minecraft:blue_terracotta
setblock 169 215 323 minecraft:dark_prismarine
fill 170 215 323 170 218 323 minecraft:blue_terracotta
setblock 171 215 325 minecraft:blue_terracotta
setblock 172 215 325 minecraft:dark_prismarine
setblock 172 215 332 minecraft:light[level=12]
setblock 172 215 339 minecraft:light[level=12]
setblock 172 215 346 minecraft:light[level=12]
setblock 172 215 353 minecraft:light[level=12]
setblock 172 215 360 minecraft:light[level=12]
setblock 173 215 324 minecraft:dark_prismarine
fill 173 215 325 173 218 325 minecraft:blue_terracotta
setblock 174 215 323 minecraft:dark_prismarine
fill 174 215 324 174 218 324 minecraft:blue_terracotta
setblock 174 215 363 minecraft:dark_prismarine
fill 175 215 323 175 218 323 minecraft:blue_terracotta
fill 175 215 363 175 218 363 minecraft:blue_terracotta
setblock 176 215 326 minecraft:dark_prismarine
setblock 177 215 325 minecraft:dark_prismarine
fill 177 215 326 177 217 326 minecraft:blue_terracotta
setblock 178 215 324 minecraft:dark_prismarine
fill 178 215 325 178 218 325 minecraft:blue_terracotta
setblock 179 215 323 minecraft:dark_prismarine
fill 179 215 324 179 218 324 minecraft:blue_terracotta
setblock 179 215 332 minecraft:light[level=12]
setblock 179 215 339 minecraft:light[level=12]
setblock 179 215 346 minecraft:light[level=12]
setblock 179 215 353 minecraft:light[level=12]
setblock 179 215 360 minecraft:light[level=12]
setblock 179 215 363 minecraft:dark_prismarine
fill 180 215 323 180 218 323 minecraft:blue_terracotta
setblock 180 215 327 minecraft:dark_prismarine
setblock 180 215 363 minecraft:purple_concrete
setblock 181 215 326 minecraft:dark_prismarine
fill 181 215 327 181 218 327 minecraft:blue_terracotta
setblock 182 215 325 minecraft:dark_prismarine
fill 182 215 326 182 218 326 minecraft:blue_terracotta
setblock 182 215 330 minecraft:dark_prismarine
setblock 182 215 348 minecraft:purple_concrete
setblock 183 215 348 minecraft:cyan_concrete
setblock 142 216 323 minecraft:blue_terracotta
setblock 142 216 324 minecraft:dark_prismarine
fill 142 216 325 142 219 325 minecraft:blue_terracotta
setblock 142 216 344 minecraft:purple_concrete
setblock 142 216 348 minecraft:blue_terracotta
setblock 142 216 349 minecraft:dark_prismarine
fill 142 216 350 142 217 352 minecraft:blue_terracotta
setblock 142 216 363 minecraft:purple_concrete
setblock 148 216 323 minecraft:dark_prismarine
setblock 148 216 363 minecraft:dark_prismarine
fill 149 216 323 149 219 323 minecraft:blue_terracotta
fill 149 216 363 149 219 363 minecraft:blue_terracotta
setblock 153 216 323 minecraft:dark_prismarine
setblock 153 216 324 minecraft:blue_terracotta
setblock 153 216 363 minecraft:dark_prismarine
setblock 154 216 323 minecraft:blue_terracotta
fill 154 216 363 154 219 363 minecraft:blue_terracotta
setblock 155 216 324 minecraft:dark_prismarine
fill 157 216 358 157 219 358 minecraft:black_concrete
fill 159 216 357 159 219 357 minecraft:black_concrete
setblock 160 216 322 minecraft:cyan_concrete
fill 160 216 361 160 219 361 minecraft:black_concrete
fill 161 216 359 161 219 360 minecraft:black_concrete
setblock 167 216 363 minecraft:purple_concrete
setblock 168 216 323 minecraft:dark_prismarine
fill 169 216 323 169 218 324 minecraft:blue_terracotta
setblock 171 216 325 minecraft:dark_prismarine
setblock 172 216 324 minecraft:dark_prismarine
fill 172 216 325 172 219 325 minecraft:blue_terracotta
setblock 173 216 323 minecraft:dark_prismarine
fill 173 216 324 173 219 324 minecraft:blue_terracotta
fill 173 216 326 173 217 326 minecraft:blue_terracotta
setblock 173 216 363 minecraft:dark_prismarine
fill 174 216 323 174 219 323 minecraft:blue_terracotta
fill 174 216 363 174 219 363 minecraft:blue_terracotta
setblock 175 216 325 minecraft:blue_terracotta
setblock 175 216 326 minecraft:dark_prismarine
setblock 176 216 325 minecraft:dark_prismarine
fill 176 216 326 176 219 326 minecraft:blue_terracotta
setblock 177 216 324 minecraft:dark_prismarine
fill 177 216 325 177 219 325 minecraft:blue_terracotta
setblock 178 216 323 minecraft:dark_prismarine
fill 178 216 324 178 219 324 minecraft:blue_terracotta
setblock 178 216 363 minecraft:dark_prismarine
fill 179 216 323 179 219 323 minecraft:blue_terracotta
setblock 180 216 326 minecraft:dark_prismarine
setblock 180 216 327 minecraft:blue_terracotta
setblock 181 216 325 minecraft:dark_prismarine
fill 181 216 326 181 219 326 minecraft:blue_terracotta
setblock 182 216 324 minecraft:dark_prismarine
fill 182 216 325 182 219 325 minecraft:blue_terracotta
setblock 182 216 329 minecraft:dark_prismarine
fill 182 216 330 182 218 331 minecraft:blue_terracotta
setblock 182 216 342 minecraft:purple_concrete
setblock 182 216 361 minecraft:purple_concrete
fill 183 216 348 183 220 348 minecraft:blue_terracotta
fill 141 217 348 141 217 349 minecraft:blue_concrete
setblock 141 217 357 minecraft:blue_concrete
fill 142 217 324 142 218 324 minecraft:blue_terracotta
setblock 142 217 328 minecraft:dark_prismarine
fill 142 217 331 142 218 331 minecraft:purple_concrete
setblock 142 217 348 minecraft:dark_prismarine
fill 142 217 349 142 220 349 minecraft:blue_terracotta
setblock 142 217 353 minecraft:dark_prismarine
fill 142 217 354 142 220 354 minecraft:blue_terracotta
setblock 143 217 322 minecraft:blue_concrete
setblock 147 217 363 minecraft:dark_prismarine
fill 148 217 323 148 220 323 minecraft:blue_terracotta
fill 148 217 363 148 220 363 minecraft:blue_terracotta
setblock 149 217 324 minecraft:sea_lantern
fill 149 217 325 149 229 325 minecraft:dark_prismarine
setblock 149 217 326 minecraft:sea_lantern
fill 149 217 327 149 229 327 minecraft:dark_prismarine
setblock 149 217 328 minecraft:sea_lantern
setblock 150 217 323 minecraft:sea_lantern
fill 150 217 324 150 229 324 minecraft:dark_prismarine
setblock 150 217 325 minecraft:sea_lantern
fill 150 217 326 150 229 326 minecraft:dark_prismarine
setblock 150 217 327 minecraft:sea_lantern
fill 150 217 328 150 229 328 minecraft:dark_prismarine
setblock 151 217 324 minecraft:sea_lantern
fill 151 217 325 151 229 325 minecraft:dark_prismarine
setblock 151 217 326 minecraft:sea_lantern
fill 151 217 327 151 229 327 minecraft:dark_prismarine
setblock 151 217 328 minecraft:sea_lantern
setblock 152 217 323 minecraft:sea_lantern
fill 152 217 324 152 219 324 minecraft:blue_terracotta
setblock 152 217 325 minecraft:sea_lantern
fill 152 217 326 152 229 326 minecraft:dark_prismarine
setblock 152 217 327 minecraft:sea_lantern
fill 152 217 328 152 229 328 minecraft:dark_prismarine
setblock 152 217 363 minecraft:dark_prismarine
setblock 153 217 322 minecraft:blue_concrete
fill 153 217 323 153 220 323 minecraft:blue_terracotta
setblock 153 217 324 minecraft:sea_lantern
fill 153 217 325 153 229 325 minecraft:dark_prismarine
setblock 153 217 326 minecraft:sea_lantern
fill 153 217 327 153 229 327 minecraft:dark_prismarine
setblock 153 217 328 minecraft:sea_lantern
fill 153 217 363 153 220 363 minecraft:blue_terracotta
setblock 154 217 323 minecraft:sea_lantern
fill 154 217 324 154 229 324 minecraft:dark_prismarine
setblock 154 217 325 minecraft:sea_lantern
fill 154 217 326 154 229 326 minecraft:dark_prismarine
setblock 154 217 327 minecraft:sea_lantern
fill 154 217 328 154 229 328 minecraft:dark_prismarine
fill 154 217 330 155 234 330 minecraft:magenta_terracotta
setblock 155 217 324 minecraft:sea_lantern
fill 155 217 325 155 229 325 minecraft:dark_prismarine
setblock 155 217 326 minecraft:sea_lantern
fill 155 217 327 155 229 327 minecraft:dark_prismarine
setblock 155 217 328 minecraft:sea_lantern
setblock 156 217 322 minecraft:blue_concrete
fill 156 217 360 156 219 360 minecraft:black_concrete
setblock 157 217 323 minecraft:dark_prismarine
fill 157 217 361 157 219 361 minecraft:black_concrete
fill 158 217 357 158 219 357 minecraft:black_concrete
fill 158 217 362 159 219 362 minecraft:black_concrete
fill 160 217 322 160 220 322 minecraft:blue_terracotta
fill 160 217 357 160 219 357 minecraft:black_concrete
fill 161 217 358 161 219 358 minecraft:black_concrete
fill 161 217 361 161 219 361 minecraft:black_concrete
setblock 167 217 322 minecraft:blue_concrete
setblock 167 217 323 minecraft:dark_prismarine
fill 168 217 322 168 219 323 minecraft:blue_terracotta
fill 170 217 322 171 217 322 minecraft:blue_concrete
setblock 170 217 325 minecraft:dark_prismarine
setblock 171 217 324 minecraft:dark_prismarine
fill 171 217 325 171 220 325 minecraft:blue_terracotta
setblock 172 217 323 minecraft:dark_prismarine
fill 172 217 324 172 220 324 minecraft:blue_terracotta
fill 172 217 326 172 218 326 minecraft:blue_terracotta
setblock 172 217 363 minecraft:dark_prismarine
fill 173 217 323 173 220 323 minecraft:blue_terracotta
fill 173 217 363 173 220 363 minecraft:blue_terracotta
setblock 174 217 325 minecraft:blue_terracotta
setblock 174 217 326 minecraft:dark_prismarine
setblock 175 217 322 minecraft:blue_concrete
setblock 175 217 325 minecraft:dark_prismarine
fill 175 217 326 175 220 326 minecraft:blue_terracotta
setblock 176 217 324 minecraft:dark_prismarine
fill 176 217 325 176 220 325 minecraft:blue_terracotta
setblock 177 217 323 minecraft:dark_prismarine
fill 177 217 324 177 220 324 minecraft:blue_terracotta
setblock 177 217 363 minecraft:dark_prismarine
fill 178 217 323 178 220 323 minecraft:blue_terracotta
fill 178 217 363 178 220 363 minecraft:blue_terracotta
setblock 179 217 364 minecraft:blue_concrete
setblock 181 217 322 minecraft:light_blue_wool
setblock 181 217 324 minecraft:dark_prismarine
fill 181 217 325 181 220 325 minecraft:blue_terracotta
setblock 181 217 329 minecraft:dark_prismarine
fill 181 217 330 181 220 330 minecraft:blue_terracotta
setblock 182 217 323 minecraft:dark_prismarine
fill 182 217 324 182 220 324 minecraft:blue_terracotta
setblock 182 217 328 minecraft:dark_prismarine
fill 182 217 329 182 220 329 minecraft:blue_terracotta
setblock 182 217 336 minecraft:purple_concrete
setblock 182 217 355 minecraft:purple_concrete
setblock 183 217 323 minecraft:blue_concrete
fill 183 217 329 183 219 329 minecraft:blue_concrete
setblock 183 217 344 minecraft:blue_concrete
setblock 141 218 328 minecraft:blue_concrete
setblock 141 218 337 minecraft:blue_concrete
fill 141 218 338 141 220 339 minecraft:blue_terracotta
setblock 141 218 348 minecraft:blue_concrete
fill 141 218 349 141 220 349 minecraft:blue_terracotta
fill 141 218 350 141 218 351 minecraft:blue_concrete
fill 141 218 357 141 220 357 minecraft:blue_terracotta
fill 141 218 362 141 220 362 minecraft:blue_terracotta
fill 141 218 363 141 218 364 minecraft:blue_concrete
setblock 142 218 327 minecraft:dark_prismarine
fill 142 218 328 142 221 328 minecraft:blue_terracotta
setblock 142 218 337 minecraft:purple_concrete
setblock 142 218 347 minecraft:dark_prismarine
fill 142 218 348 142 221 348 minecraft:blue_terracotta
fill 142 218 350 142 218 351 minecraft:blue_terracotta
setblock 142 218 352 minecraft:dark_prismarine
fill 142 218 353 142 221 353 minecraft:blue_terracotta
fill 142 218 355 142 218 356 minecraft:blue_terracotta
fill 143 218 322 143 220 322 minecraft:blue_terracotta
setblock 143 218 351 minecraft:dark_prismarine
fill 143 218 352 143 221 352 minecraft:blue_terracotta
fill 143 218 364 143 219 364 minecraft:blue_concrete
setblock 144 218 322 minecraft:light_blue_wool
setblock 145 218 323 minecraft:purple_concrete
setblock 146 218 363 minecraft:dark_prismarine
fill 147 218 323 147 221 323 minecraft:blue_terracotta
fill 147 218 363 147 221 363 minecraft:blue_terracotta
setblock 148 218 322 minecraft:blue_concrete
fill 149 218 324 149 219 324 minecraft:dark_prismarine
fill 149 218 326 149 219 326 minecraft:dark_prismarine
fill 149 218 328 149 219 328 minecraft:dark_prismarine
fill 149 218 364 151 220 364 minecraft:blue_terracotta
setblock 150 218 323 minecraft:blue_terracotta
fill 150 218 325 150 219 325 minecraft:dark_prismarine
fill 150 218 327 150 219 327 minecraft:dark_prismarine
setblock 151 218 323 minecraft:dark_prismarine
fill 151 218 324 151 219 324 minecraft:blue_terracotta
fill 151 218 326 151 219 326 minecraft:dark_prismarine
fill 151 218 328 151 219 328 minecraft:dark_prismarine
setblock 151 218 363 minecraft:dark_prismarine
fill 152 218 323 152 219 323 minecraft:blue_terracotta
fill 152 218 325 152 219 325 minecraft:dark_prismarine
fill 152 218 327 152 219 327 minecraft:dark_prismarine
fill 152 218 363 152 221 363 minecraft:blue_terracotta
setblock 152 218 364 minecraft:blue_concrete
setblock 153 218 322 minecraft:blue_terracotta
setblock 153 218 324 minecraft:blue_terracotta
fill 153 218 326 153 219 326 minecraft:dark_prismarine
fill 153 218 328 153 219 328 minecraft:dark_prismarine
fill 154 218 323 154 219 323 minecraft:blue_terracotta
fill 154 218 325 154 219 325 minecraft:dark_prismarine
fill 154 218 327 154 219 327 minecraft:dark_prismarine
fill 155 218 324 155 219 324 minecraft:dark_prismarine
fill 155 218 326 155 219 326 minecraft:dark_prismarine
fill 155 218 328 155 219 328 minecraft:dark_prismarine
fill 156 218 322 156 221 322 minecraft:blue_terracotta
setblock 156 218 323 minecraft:dark_prismarine
fill 156 218 361 156 219 361 minecraft:black_concrete
setblock 157 218 322 minecraft:blue_concrete
fill 157 218 357 157 219 357 minecraft:black_concrete
fill 157 218 362 157 219 362 minecraft:black_concrete
fill 158 218 322 158 220 322 minecraft:blue_terracotta
setblock 158 218 364 minecraft:blue_concrete
fill 159 218 327 160 219 328 minecraft:black_concrete
fill 159 218 356 159 219 356 minecraft:black_concrete
fill 159 218 364 159 220 364 minecraft:blue_terracotta
fill 160 218 362 160 219 362 minecraft:black_concrete
setblock 160 218 363 minecraft:purple_concrete
fill 161 218 357 161 219 357 minecraft:black_concrete
fill 162 218 359 162 219 359 minecraft:black_concrete
fill 162 218 364 162 220 364 minecraft:blue_terracotta
setblock 163 218 364 minecraft:blue_concrete
setblock 164 218 323 minecraft:purple_concrete
setblock 165 218 322 minecraft:blue_concrete
fill 166 218 322 167 220 322 minecraft:blue_terracotta
fill 167 218 323 167 221 323 minecraft:blue_terracotta
fill 168 218 324 168 219 324 minecraft:blue_terracotta
setblock 169 218 325 minecraft:dark_prismarine
fill 170 218 322 171 220 322 minecraft:blue_terracotta
setblock 170 218 324 minecraft:dark_prismarine
fill 170 218 325 170 221 325 minecraft:blue_terracotta
setblock 171 218 323 minecraft:dark_prismarine
fill 171 218 324 171 221 324 minecraft:blue_terracotta
fill 171 218 326 171 219 326 minecraft:blue_terracotta
setblock 171 218 363 minecraft:dark_prismarine
fill 172 218 323 172 221 323 minecraft:blue_terracotta
fill 172 218 363 172 221 363 minecraft:blue_terracotta
setblock 173 218 326 minecraft:dark_prismarine
setblock 174 218 325 minecraft:dark_prismarine
fill 174 218 326 174 221 326 minecraft:blue_terracotta
fill 175 218 322 175 220 322 minecraft:blue_terracotta
setblock 175 218 324 minecraft:dark_prismarine
fill 175 218 325 175 221 325 minecraft:blue_terracotta
setblock 176 218 323 minecraft:dark_prismarine
fill 176 218 324 176 221 324 minecraft:blue_terracotta
setblock 176 218 363 minecraft:dark_prismarine
fill 177 218 323 177 221 323 minecraft:blue_terracotta
fill 177 218 363 177 221 363 minecraft:blue_terracotta
setblock 179 218 322 minecraft:blue_concrete
setblock 179 218 325 minecraft:dark_prismarine
setblock 179 218 363 minecraft:purple_concrete
fill 179 218 364 179 220 364 minecraft:blue_terracotta
setblock 180 218 324 minecraft:dark_prismarine
fill 181 218 322 181 220 322 minecraft:blue_terracotta
setblock 181 218 323 minecraft:dark_prismarine
fill 181 218 324 181 219 324 minecraft:blue_terracotta
setblock 181 218 328 minecraft:dark_prismarine
fill 181 218 329 181 221 329 minecraft:blue_terracotta
fill 182 218 323 183 220 323 minecraft:blue_terracotta
setblock 182 218 327 minecraft:dark_prismarine
fill 182 218 328 182 221 328 minecraft:blue_terracotta
setblock 182 218 332 minecraft:dark_prismarine
setblock 182 218 349 minecraft:purple_concrete
setblock 183 218 322 minecraft:blue_concrete
fill 183 218 344 183 220 344 minecraft:blue_terracotta
fill 183 218 353 183 219 353 minecraft:blue_concrete
fill 183 218 363 183 218 364 minecraft:blue_concrete
fill 141 219 323 141 219 324 minecraft:blue_concrete
fill 141 219 328 141 220 328 minecraft:blue_terracotta
fill 141 219 337 141 220 337 minecraft:blue_terracotta
fill 141 219 348 141 221 348 minecraft:blue_terracotta
fill 141 219 350 141 220 351 minecraft:blue_terracotta
setblock 141 219 358 minecraft:blue_concrete
fill 141 219 363 141 220 363 minecraft:blue_terracotta
setblock 141 219 364 minecraft:blue_concrete
setblock 142 219 326 minecraft:dark_prismarine
fill 142 219 327 142 221 327 minecraft:blue_terracotta
fill 142 219 329 142 220 329 minecraft:blue_terracotta
setblock 142 219 343 minecraft:purple_concrete
fill 142 219 347 142 222 347 minecraft:blue_terracotta
setblock 142 219 350 minecraft:blue_terracotta
setblock 142 219 351 minecraft:dark_prismarine
fill 142 219 352 142 222 352 minecraft:blue_terracotta
setblock 142 219 355 minecraft:blue_terracotta
setblock 142 219 356 minecraft:dark_prismarine
fill 142 219 357 142 221 358 minecraft:blue_terracotta
setblock 142 219 362 minecraft:purple_concrete
setblock 143 219 349 minecraft:blue_terracotta
setblock 143 219 350 minecraft:dark_prismarine
fill 143 219 351 143 222 351 minecraft:blue_terracotta
fill 143 219 353 143 219 354 minecraft:blue_terracotta
setblock 143 219 355 minecraft:dark_prismarine
fill 144 219 322 144 220 322 minecraft:blue_terracotta
setblock 145 219 363 minecraft:dark_prismarine
fill 146 219 363 146 222 363 minecraft:blue_terracotta
setblock 146 219 364 minecraft:blue_concrete
fill 148 219 322 150 220 322 minecraft:blue_terracotta
fill 148 219 333 150 220 333 minecraft:black_concrete
fill 149 219 334 150 220 334 minecraft:black_concrete
setblock 150 219 323 minecraft:dark_prismarine
setblock 150 219 363 minecraft:dark_prismarine
setblock 151 219 322 minecraft:blue_concrete
fill 151 219 323 151 222 323 minecraft:blue_terracotta
fill 151 219 363 151 222 363 minecraft:blue_terracotta
fill 152 219 364 152 220 364 minecraft:blue_terracotta
setblock 153 219 322 minecraft:blue_concrete
setblock 153 219 324 minecraft:dark_prismarine
setblock 155 219 323 minecraft:dark_prismarine
setblock 155 219 360 minecraft:black_concrete
setblock 155 219 363 minecraft:dark_prismarine
setblock 156 219 323 minecraft:blue_terracotta
setblock 156 219 357 minecraft:black_concrete
fill 157 219 322 157 220 322 minecraft:blue_terracotta
fill 157 219 356 158 219 356 minecraft:black_concrete
setblock 158 219 323 minecraft:purple_concrete
fill 158 219 363 159 219 363 minecraft:black_concrete
fill 158 219 364 158 220 364 minecraft:blue_terracotta
setblock 160 219 356 minecraft:black_concrete
setblock 161 219 362 minecraft:black_concrete
setblock 162 219 358 minecraft:black_concrete
fill 162 219 360 162 219 361 minecraft:black_concrete
setblock 163 219 364 minecraft:cyan_concrete
fill 165 219 322 165 220 322 minecraft:blue_terracotta
fill 166 219 323 166 222 323 minecraft:blue_terracotta
setblock 166 219 363 minecraft:purple_concrete
fill 167 219 324 167 220 324 minecraft:blue_terracotta
setblock 168 219 325 minecraft:dark_prismarine
setblock 169 219 323 minecraft:blue_terracotta
setblock 169 219 324 minecraft:dark_prismarine
fill 169 219 325 169 222 325 minecraft:blue_terracotta
setblock 170 219 323 minecraft:dark_prismarine
fill 170 219 324 170 222 324 minecraft:blue_terracotta
fill 170 219 326 170 220 326 minecraft:blue_terracotta
fill 170 219 327 170 234 327 minecraft:magenta_terracotta
setblock 170 219 363 minecraft:dark_prismarine
fill 171 219 323 171 222 323 minecraft:blue_terracotta
fill 171 219 363 171 222 363 minecraft:blue_terracotta
setblock 172 219 326 minecraft:dark_prismarine
setblock 173 219 325 minecraft:dark_prismarine
fill 173 219 326 173 222 326 minecraft:blue_terracotta
setblock 174 219 324 minecraft:dark_prismarine
fill 174 219 325 174 222 325 minecraft:blue_terracotta
fill 174 219 364 175 220 364 minecraft:blue_terracotta
setblock 175 219 323 minecraft:dark_prismarine
fill 175 219 324 175 222 324 minecraft:blue_terracotta
setblock 175 219 363 minecraft:dark_prismarine
fill 176 219 323 176 222 323 minecraft:blue_terracotta
fill 176 219 363 176 222 363 minecraft:blue_terracotta
setblock 176 219 364 minecraft:blue_concrete
setblock 178 219 325 minecraft:dark_prismarine
fill 179 219 322 179 220 322 minecraft:blue_terracotta
setblock 179 219 324 minecraft:dark_prismarine
setblock 180 219 323 minecraft:dark_prismarine
fill 180 219 324 180 220 324 minecraft:blue_terracotta
fill 181 219 323 181 222 323 minecraft:blue_terracotta
setblock 181 219 327 minecraft:dark_prismarine
fill 181 219 328 181 222 328 minecraft:blue_terracotta
setblock 181 219 331 minecraft:blue_terracotta
setblock 182 219 326 minecraft:dark_prismarine
fill 182 219 327 182 222 327 minecraft:blue_terracotta
setblock 182 219 330 minecraft:blue_terracotta
setblock 182 219 331 minecraft:dark_prismarine
fill 182 219 332 182 221 333 minecraft:blue_terracotta
setblock 182 219 343 minecraft:purple_concrete
fill 182 219 350 183 219 350 minecraft:blue_terracotta
setblock 182 219 351 minecraft:dark_prismarine
fill 182 219 352 182 220 354 minecraft:blue_terracotta
fill 183 219 322 183 220 322 minecraft:blue_terracotta
setblock 183 219 339 minecraft:blue_concrete
setblock 183 219 351 minecraft:blue_concrete
setblock 183 219 356 minecraft:blue_concrete
fill 183 219 358 183 220 359 minecraft:blue_terracotta
setblock 183 219 360 minecraft:blue_concrete
fill 183 219 363 183 220 364 minecraft:blue_terracotta
fill 141 220 323 141 220 324 minecraft:blue_terracotta
setblock 141 220 358 minecraft:blue_terracotta
fill 141 220 364 141 223 364 minecraft:blue_terracotta
setblock 142 220 324 minecraft:purple_concrete
setblock 142 220 326 minecraft:blue_terracotta
setblock 142 220 330 minecraft:dark_prismarine
fill 142 220 331 142 223 331 minecraft:blue_terracotta
setblock 142 220 350 minecraft:dark_prismarine
fill 142 220 351 142 223 351 minecraft:blue_terracotta
setblock 142 220 355 minecraft:dark_prismarine
fill 142 220 356 143 222 356 minecraft:blue_terracotta
setblock 142 220 359 minecraft:blue_terracotta
setblock 142 220 360 minecraft:dark_prismarine
setblock 143 220 349 minecraft:dark_prismarine
fill 143 220 350 143 223 350 minecraft:blue_terracotta
setblock 143 220 353 minecraft:blue_terracotta
setblock 143 220 354 minecraft:dark_prismarine
fill 143 220 355 143 223 355 minecraft:blue_terracotta
fill 143 220 357 143 221 357 minecraft:blue_terracotta
setblock 143 220 364 minecraft:blue_terracotta
fill 144 220 351 144 220 352 minecraft:blue_terracotta
setblock 144 220 353 minecraft:dark_prismarine
fill 144 220 354 144 223 354 minecraft:blue_terracotta
setblock 144 220 363 minecraft:dark_prismarine
fill 145 220 363 145 223 363 minecraft:blue_terracotta
setblock 146 220 364 minecraft:blue_terracotta
setblock 149 220 323 minecraft:dark_prismarine
setblock 149 220 324 minecraft:sea_lantern
setblock 149 220 326 minecraft:sea_lantern
setblock 149 220 328 minecraft:sea_lantern
fill 149 220 346 149 234 346 minecraft:magenta_terracotta
setblock 149 220 362 minecraft:blue_terracotta
setblock 149 220 363 minecraft:dark_prismarine
setblock 150 220 323 minecraft:sea_lantern
setblock 150 220 325 minecraft:sea_lantern
setblock 150 220 327 minecraft:sea_lantern
setblock 150 220 362 minecraft:dark_prismarine
fill 150 220 363 150 223 363 minecraft:blue_terracotta
setblock 151 220 322 minecraft:blue_terracotta
setblock 151 220 324 minecraft:sea_lantern
setblock 151 220 326 minecraft:sea_lantern
setblock 151 220 328 minecraft:sea_lantern
fill 151 220 362 151 222 362 minecraft:blue_terracotta
setblock 152 220 323 minecraft:sea_lantern
fill 152 220 324 152 229 324 minecraft:dark_prismarine
setblock 152 220 325 minecraft:sea_lantern
setblock 152 220 327 minecraft:sea_lantern
setblock 153 220 322 minecraft:blue_terracotta
setblock 153 220 324 minecraft:sea_lantern
setblock 153 220 326 minecraft:sea_lantern
setblock 153 220 328 minecraft:sea_lantern
setblock 154 220 323 minecraft:sea_lantern
setblock 154 220 325 minecraft:sea_lantern
setblock 154 220 327 minecraft:sea_lantern
setblock 154 220 363 minecraft:dark_prismarine
setblock 155 220 323 minecraft:blue_terracotta
setblock 155 220 324 minecraft:sea_lantern
setblock 155 220 326 minecraft:sea_lantern
setblock 155 220 328 minecraft:sea_lantern
fill 158 220 358 158 224 358 minecraft:dark_prismarine
fill 158 220 361 158 221 361 minecraft:dark_prismarine
fill 160 220 359 160 221 359 minecraft:dark_prismarine
setblock 163 220 364 minecraft:blue_terracotta
setblock 168 220 322 minecraft:light_blue_wool
setblock 168 220 323 minecraft:blue_terracotta
setblock 168 220 324 minecraft:dark_prismarine
fill 168 220 325 168 223 325 minecraft:blue_terracotta
setblock 169 220 323 minecraft:dark_prismarine
fill 169 220 324 169 223 324 minecraft:blue_terracotta
fill 169 220 326 169 221 326 minecraft:blue_terracotta
fill 170 220 323 170 223 323 minecraft:blue_terracotta
fill 170 220 328 170 221 328 minecraft:magenta_terracotta
fill 170 220 363 170 223 363 minecraft:blue_terracotta
setblock 171 220 326 minecraft:dark_prismarine
setblock 172 220 325 minecraft:dark_prismarine
fill 172 220 326 172 222 326 minecraft:blue_terracotta
fill 172 220 338 172 221 338 minecraft:spruce_planks
setblock 173 220 324 minecraft:dark_prismarine
fill 173 220 325 173 223 325 minecraft:blue_terracotta
setblock 174 220 323 minecraft:dark_prismarine
fill 174 220 324 174 223 324 minecraft:blue_terracotta
setblock 174 220 363 minecraft:dark_prismarine
fill 175 220 323 175 223 323 minecraft:blue_terracotta
fill 175 220 363 175 223 363 minecraft:blue_terracotta
fill 176 220 364 176 221 364 minecraft:blue_terracotta
setblock 177 220 325 minecraft:dark_prismarine
setblock 178 220 324 minecraft:dark_prismarine
setblock 179 220 323 minecraft:dark_prismarine
fill 179 220 324 179 221 324 minecraft:blue_terracotta
fill 180 220 323 180 223 323 minecraft:blue_terracotta
setblock 181 220 326 minecraft:dark_prismarine
fill 181 220 327 181 222 327 minecraft:blue_terracotta
setblock 181 220 331 minecraft:dark_prismarine
setblock 182 220 325 minecraft:dark_prismarine
fill 182 220 326 182 223 326 minecraft:blue_terracotta
setblock 182 220 330 minecraft:dark_prismarine
fill 182 220 331 182 223 331 minecraft:blue_terracotta
setblock 182 220 337 minecraft:purple_concrete
setblock 182 220 350 minecraft:dark_prismarine
schedule function dropper:buildpart/75_11 1t
