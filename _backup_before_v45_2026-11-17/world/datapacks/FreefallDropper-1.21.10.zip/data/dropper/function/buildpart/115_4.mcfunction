fill 358 115 464 358 118 464 minecraft:pink_terracotta
setblock 358 115 503 minecraft:red_nether_bricks
fill 358 115 504 358 118 504 minecraft:pink_terracotta
fill 359 115 503 359 118 503 minecraft:pink_terracotta
setblock 360 115 466 minecraft:red_nether_bricks
setblock 361 115 465 minecraft:red_nether_bricks
setblock 361 115 466 minecraft:pink_terracotta
setblock 362 115 464 minecraft:red_nether_bricks
fill 362 115 465 362 117 465 minecraft:pink_terracotta
setblock 362 115 504 minecraft:red_nether_bricks
fill 363 115 464 363 118 464 minecraft:pink_terracotta
fill 363 115 504 363 118 504 minecraft:pink_terracotta
fill 370 115 478 370 116 478 minecraft:white_concrete
setblock 370 115 484 minecraft:white_concrete
setblock 370 115 486 minecraft:red_nether_bricks
fill 370 115 487 370 118 487 minecraft:pink_terracotta
setblock 370 115 491 minecraft:red_nether_bricks
fill 370 115 492 370 118 492 minecraft:pink_terracotta
fill 370 115 494 370 116 494 minecraft:pink_terracotta
setblock 370 115 503 minecraft:white_concrete
setblock 330 116 471 minecraft:white_concrete
fill 330 116 482 330 118 482 minecraft:pink_terracotta
setblock 330 116 485 minecraft:red_nether_bricks
fill 330 116 486 330 119 486 minecraft:pink_terracotta
setblock 330 116 490 minecraft:red_nether_bricks
fill 330 116 491 330 119 491 minecraft:pink_terracotta
setblock 330 116 494 minecraft:pink_terracotta
setblock 331 116 484 minecraft:red_nether_bricks
fill 331 116 485 331 119 485 minecraft:pink_terracotta
setblock 331 116 489 minecraft:red_nether_bricks
fill 331 116 490 332 118 490 minecraft:pink_terracotta
fill 331 116 492 331 117 492 minecraft:pink_terracotta
setblock 332 116 487 minecraft:pink_terracotta
setblock 332 116 488 minecraft:red_nether_bricks
fill 332 116 489 332 119 489 minecraft:pink_terracotta
setblock 334 116 465 minecraft:pink_terracotta
setblock 335 116 465 minecraft:red_nether_bricks
setblock 336 116 464 minecraft:red_nether_bricks
fill 336 116 465 336 118 466 minecraft:pink_terracotta
fill 337 116 464 340 116 464 minecraft:pink_terracotta
setblock 339 116 466 minecraft:red_nether_bricks
setblock 340 116 465 minecraft:red_nether_bricks
fill 340 116 466 340 119 466 minecraft:pink_terracotta
setblock 341 116 464 minecraft:red_nether_bricks
fill 341 116 465 344 116 465 minecraft:pink_terracotta
setblock 341 116 504 minecraft:white_concrete
fill 342 116 464 345 116 464 minecraft:pink_terracotta
setblock 345 116 465 minecraft:red_nether_bricks
setblock 346 116 464 minecraft:red_nether_bricks
fill 347 116 464 347 119 464 minecraft:pink_terracotta
fill 348 116 465 348 117 465 minecraft:pink_terracotta
setblock 350 116 465 minecraft:red_nether_bricks
setblock 351 116 464 minecraft:red_nether_bricks
fill 351 116 465 351 119 465 minecraft:pink_terracotta
fill 352 116 464 352 119 464 minecraft:pink_terracotta
fill 352 116 466 352 117 466 minecraft:pink_terracotta
fill 352 116 504 352 119 504 minecraft:pink_terracotta
setblock 354 116 466 minecraft:red_nether_bricks
setblock 355 116 465 minecraft:red_nether_bricks
fill 355 116 466 355 119 466 minecraft:pink_terracotta
fill 355 116 503 355 117 503 minecraft:pink_terracotta
setblock 356 116 464 minecraft:red_nether_bricks
fill 356 116 465 356 119 465 minecraft:pink_terracotta
setblock 356 116 504 minecraft:red_nether_bricks
fill 357 116 464 357 119 464 minecraft:pink_terracotta
setblock 357 116 503 minecraft:red_nether_bricks
fill 357 116 504 357 119 504 minecraft:pink_terracotta
fill 358 116 503 358 119 503 minecraft:pink_terracotta
setblock 359 116 466 minecraft:red_nether_bricks
setblock 360 116 465 minecraft:red_nether_bricks
fill 360 116 466 360 117 466 minecraft:pink_terracotta
setblock 361 116 464 minecraft:red_nether_bricks
fill 361 116 465 361 119 465 minecraft:pink_terracotta
setblock 361 116 504 minecraft:red_nether_bricks
fill 362 116 464 362 119 464 minecraft:pink_terracotta
fill 362 116 504 362 119 504 minecraft:pink_terracotta
fill 366 116 504 366 117 504 minecraft:white_concrete
fill 369 116 489 369 116 490 minecraft:pink_terracotta
setblock 369 116 491 minecraft:red_nether_bricks
setblock 370 116 472 minecraft:white_concrete
setblock 370 116 485 minecraft:red_nether_bricks
fill 370 116 486 370 119 486 minecraft:pink_terracotta
setblock 370 116 490 minecraft:red_nether_bricks
fill 370 116 491 370 119 491 minecraft:pink_terracotta
setblock 370 116 495 minecraft:red_nether_bricks
fill 370 116 496 370 119 496 minecraft:pink_terracotta
setblock 370 116 497 minecraft:white_concrete
fill 330 117 467 330 117 468 minecraft:pink_terracotta
setblock 330 117 469 minecraft:red_nether_bricks
fill 330 117 470 330 117 473 minecraft:pink_terracotta
setblock 330 117 477 minecraft:white_concrete
setblock 330 117 484 minecraft:red_nether_bricks
fill 330 117 485 330 120 485 minecraft:pink_terracotta
setblock 330 117 489 minecraft:red_nether_bricks
fill 330 117 490 330 120 490 minecraft:pink_terracotta
setblock 330 117 494 minecraft:red_nether_bricks
fill 330 117 495 330 120 495 minecraft:pink_terracotta
setblock 330 117 496 minecraft:white_concrete
fill 330 117 502 330 118 502 minecraft:white_concrete
fill 331 117 484 331 120 484 minecraft:pink_terracotta
setblock 331 117 488 minecraft:red_nether_bricks
fill 331 117 489 331 120 489 minecraft:pink_terracotta
setblock 331 117 493 minecraft:red_nether_bricks
fill 332 117 464 332 119 464 minecraft:pink_terracotta
setblock 332 117 486 minecraft:pink_terracotta
setblock 332 117 487 minecraft:red_nether_bricks
fill 332 117 488 332 120 488 minecraft:pink_terracotta
setblock 332 117 491 minecraft:pink_terracotta
setblock 334 117 465 minecraft:red_nether_bricks
setblock 335 117 464 minecraft:red_nether_bricks
fill 335 117 465 335 119 466 minecraft:pink_terracotta
fill 336 117 464 339 117 464 minecraft:pink_terracotta
setblock 338 117 465 minecraft:pink_terracotta
setblock 338 117 466 minecraft:red_nether_bricks
setblock 339 117 465 minecraft:red_nether_bricks
fill 339 117 466 339 120 466 minecraft:pink_terracotta
setblock 340 117 464 minecraft:red_nether_bricks
fill 340 117 465 343 117 465 minecraft:pink_terracotta
fill 341 117 464 344 117 464 minecraft:pink_terracotta
setblock 344 117 465 minecraft:red_nether_bricks
setblock 345 117 464 minecraft:red_nether_bricks
fill 345 117 465 347 118 465 minecraft:pink_terracotta
fill 346 117 464 346 120 464 minecraft:pink_terracotta
setblock 347 117 504 minecraft:white_concrete
setblock 349 117 465 minecraft:red_nether_bricks
setblock 350 117 464 minecraft:red_nether_bricks
fill 350 117 465 350 120 465 minecraft:pink_terracotta
fill 351 117 464 351 120 464 minecraft:pink_terracotta
fill 351 117 466 351 118 466 minecraft:pink_terracotta
fill 351 117 504 351 120 504 minecraft:pink_terracotta
setblock 353 117 465 minecraft:pink_terracotta
setblock 353 117 466 minecraft:red_nether_bricks
setblock 354 117 465 minecraft:red_nether_bricks
fill 354 117 466 354 120 466 minecraft:pink_terracotta
fill 354 117 503 354 118 503 minecraft:pink_terracotta
setblock 355 117 464 minecraft:red_nether_bricks
fill 355 117 465 355 120 465 minecraft:pink_terracotta
fill 355 117 467 356 117 467 minecraft:pink_terracotta
setblock 355 117 504 minecraft:red_nether_bricks
fill 356 117 464 356 120 464 minecraft:pink_terracotta
setblock 356 117 503 minecraft:red_nether_bricks
fill 356 117 504 356 120 504 minecraft:pink_terracotta
setblock 357 117 467 minecraft:red_nether_bricks
fill 357 117 503 357 120 503 minecraft:pink_terracotta
setblock 358 117 466 minecraft:red_nether_bricks
setblock 359 117 465 minecraft:red_nether_bricks
fill 359 117 466 359 119 466 minecraft:pink_terracotta
setblock 360 117 464 minecraft:red_nether_bricks
fill 360 117 465 360 120 465 minecraft:pink_terracotta
setblock 360 117 504 minecraft:red_nether_bricks
fill 361 117 464 361 120 464 minecraft:pink_terracotta
setblock 361 117 503 minecraft:red_nether_bricks
fill 361 117 504 361 120 504 minecraft:pink_terracotta
fill 369 117 488 369 117 489 minecraft:pink_terracotta
setblock 369 117 490 minecraft:red_nether_bricks
fill 369 117 491 369 117 494 minecraft:pink_terracotta
setblock 370 117 466 minecraft:white_concrete
setblock 370 117 484 minecraft:red_nether_bricks
fill 370 117 485 370 120 485 minecraft:pink_terracotta
setblock 370 117 489 minecraft:red_nether_bricks
fill 370 117 490 370 120 490 minecraft:pink_terracotta
setblock 370 117 494 minecraft:red_nether_bricks
fill 370 117 495 370 120 495 minecraft:pink_terracotta
fill 370 117 497 370 118 497 minecraft:pink_terracotta
fill 330 118 464 330 119 464 minecraft:white_concrete
fill 330 118 466 330 118 467 minecraft:pink_terracotta
setblock 330 118 468 minecraft:red_nether_bricks
fill 330 118 469 330 118 472 minecraft:pink_terracotta
setblock 330 118 473 minecraft:red_nether_bricks
fill 330 118 474 330 118 477 minecraft:pink_terracotta
setblock 330 118 478 minecraft:red_nether_bricks
fill 330 118 479 330 119 481 minecraft:pink_terracotta
setblock 330 118 483 minecraft:red_nether_bricks
fill 330 118 484 330 121 484 minecraft:pink_terracotta
setblock 330 118 488 minecraft:red_nether_bricks
fill 330 118 489 330 121 489 minecraft:pink_terracotta
setblock 330 118 492 minecraft:pink_terracotta
setblock 330 118 493 minecraft:red_nether_bricks
fill 330 118 494 331 120 494 minecraft:pink_terracotta
fill 330 118 496 330 119 496 minecraft:pink_terracotta
setblock 331 118 467 minecraft:red_nether_bricks
fill 331 118 468 331 118 471 minecraft:pink_terracotta
setblock 331 118 472 minecraft:red_nether_bricks
fill 331 118 473 331 120 474 minecraft:pink_terracotta
fill 331 118 483 331 121 483 minecraft:pink_terracotta
setblock 331 118 487 minecraft:red_nether_bricks
fill 331 118 488 331 121 488 minecraft:pink_terracotta
setblock 331 118 492 minecraft:red_nether_bricks
fill 331 118 493 332 120 493 minecraft:pink_terracotta
fill 331 118 495 331 119 495 minecraft:pink_terracotta
setblock 332 118 470 minecraft:pink_terracotta
setblock 332 118 471 minecraft:red_nether_bricks
setblock 332 118 485 minecraft:pink_terracotta
setblock 332 118 486 minecraft:red_nether_bricks
fill 332 118 487 332 121 487 minecraft:pink_terracotta
setblock 332 118 491 minecraft:red_nether_bricks
fill 332 118 492 332 121 492 minecraft:pink_terracotta
setblock 333 118 465 minecraft:red_nether_bricks
setblock 334 118 464 minecraft:red_nether_bricks
fill 334 118 465 334 120 466 minecraft:pink_terracotta
setblock 334 118 504 minecraft:white_concrete
fill 335 118 464 338 118 464 minecraft:pink_terracotta
setblock 337 118 465 minecraft:pink_terracotta
setblock 337 118 466 minecraft:red_nether_bricks
setblock 338 118 465 minecraft:red_nether_bricks
fill 338 118 466 338 121 466 minecraft:pink_terracotta
setblock 339 118 464 minecraft:red_nether_bricks
fill 339 118 465 342 118 465 minecraft:pink_terracotta
fill 340 118 464 343 118 464 minecraft:pink_terracotta
setblock 343 118 465 minecraft:red_nether_bricks
setblock 344 118 464 minecraft:red_nether_bricks
fill 344 118 465 344 120 465 minecraft:pink_terracotta
fill 345 118 464 345 121 464 minecraft:pink_terracotta
setblock 348 118 465 minecraft:red_nether_bricks
setblock 349 118 464 minecraft:red_nether_bricks
fill 349 118 465 349 121 465 minecraft:pink_terracotta
fill 350 118 464 350 121 464 minecraft:pink_terracotta
fill 350 118 466 350 119 466 minecraft:pink_terracotta
setblock 352 118 466 minecraft:red_nether_bricks
setblock 353 118 465 minecraft:red_nether_bricks
fill 353 118 466 353 120 467 minecraft:pink_terracotta
setblock 354 118 464 minecraft:red_nether_bricks
fill 354 118 465 354 121 465 minecraft:pink_terracotta
fill 354 118 467 355 118 467 minecraft:pink_terracotta
setblock 354 118 504 minecraft:red_nether_bricks
fill 355 118 464 355 121 464 minecraft:pink_terracotta
setblock 355 118 503 minecraft:red_nether_bricks
fill 355 118 504 355 121 504 minecraft:pink_terracotta
setblock 356 118 467 minecraft:red_nether_bricks
fill 356 118 503 356 121 503 minecraft:pink_terracotta
setblock 357 118 466 minecraft:red_nether_bricks
fill 357 118 467 357 119 467 minecraft:pink_terracotta
setblock 358 118 465 minecraft:red_nether_bricks
fill 358 118 466 358 120 466 minecraft:pink_terracotta
setblock 359 118 464 minecraft:red_nether_bricks
fill 359 118 465 359 121 465 minecraft:pink_terracotta
setblock 359 118 504 minecraft:red_nether_bricks
fill 360 118 464 360 121 464 minecraft:pink_terracotta
setblock 360 118 503 minecraft:red_nether_bricks
fill 360 118 504 360 121 504 minecraft:pink_terracotta
setblock 366 118 464 minecraft:white_concrete
fill 369 118 487 369 118 488 minecraft:pink_terracotta
setblock 369 118 489 minecraft:red_nether_bricks
fill 369 118 490 369 118 493 minecraft:pink_terracotta
setblock 369 118 494 minecraft:red_nether_bricks
fill 369 118 495 369 121 495 minecraft:pink_terracotta
setblock 370 118 467 minecraft:pink_terracotta
setblock 370 118 468 minecraft:red_nether_bricks
fill 370 118 469 370 119 471 minecraft:pink_terracotta
fill 370 118 484 370 121 484 minecraft:pink_terracotta
setblock 370 118 488 minecraft:red_nether_bricks
fill 370 118 489 370 121 489 minecraft:pink_terracotta
setblock 370 118 493 minecraft:red_nether_bricks
fill 370 118 494 370 121 494 minecraft:pink_terracotta
setblock 370 118 498 minecraft:red_nether_bricks
fill 370 118 499 370 121 499 minecraft:pink_terracotta
fill 330 119 465 330 119 466 minecraft:pink_terracotta
setblock 330 119 467 minecraft:red_nether_bricks
fill 330 119 468 330 119 471 minecraft:pink_terracotta
setblock 330 119 472 minecraft:red_nether_bricks
fill 330 119 473 330 119 476 minecraft:pink_terracotta
setblock 330 119 477 minecraft:red_nether_bricks
fill 330 119 478 331 121 478 minecraft:pink_terracotta
setblock 330 119 482 minecraft:red_nether_bricks
fill 330 119 483 330 122 483 minecraft:pink_terracotta
setblock 330 119 487 minecraft:red_nether_bricks
fill 330 119 488 330 122 488 minecraft:pink_terracotta
setblock 330 119 492 minecraft:red_nether_bricks
fill 330 119 493 330 122 493 minecraft:pink_terracotta
setblock 330 119 497 minecraft:red_nether_bricks
fill 330 119 498 330 122 498 minecraft:pink_terracotta
fill 331 119 464 331 120 464 minecraft:pink_terracotta
setblock 331 119 466 minecraft:red_nether_bricks
fill 331 119 467 331 119 470 minecraft:pink_terracotta
setblock 331 119 471 minecraft:red_nether_bricks
fill 331 119 472 332 121 472 minecraft:pink_terracotta
setblock 331 119 475 minecraft:pink_terracotta
setblock 331 119 476 minecraft:red_nether_bricks
fill 331 119 477 331 122 477 minecraft:pink_terracotta
fill 331 119 479 331 119 480 minecraft:pink_terracotta
setblock 331 119 481 minecraft:red_nether_bricks
fill 331 119 482 331 122 482 minecraft:pink_terracotta
setblock 331 119 486 minecraft:red_nether_bricks
fill 331 119 487 331 122 487 minecraft:pink_terracotta
setblock 331 119 490 minecraft:pink_terracotta
setblock 331 119 491 minecraft:red_nether_bricks
fill 331 119 492 331 122 492 minecraft:pink_terracotta
setblock 331 119 496 minecraft:red_nether_bricks
setblock 332 119 465 minecraft:red_nether_bricks
setblock 332 119 466 minecraft:light[level=12]
fill 332 119 468 332 119 469 minecraft:pink_terracotta
setblock 332 119 470 minecraft:red_nether_bricks
fill 332 119 471 333 121 471 minecraft:pink_terracotta
fill 332 119 473 332 119 474 minecraft:pink_terracotta
setblock 332 119 475 minecraft:red_nether_bricks
setblock 332 119 482 minecraft:light[level=12]
setblock 332 119 485 minecraft:red_nether_bricks
fill 332 119 486 332 122 486 minecraft:pink_terracotta
setblock 332 119 490 minecraft:red_nether_bricks
fill 332 119 491 333 121 491 minecraft:pink_terracotta
setblock 332 119 494 minecraft:pink_terracotta
setblock 332 119 498 minecraft:light[level=12]
setblock 333 119 464 minecraft:red_nether_bricks
fill 333 119 465 333 122 465 minecraft:pink_terracotta
setblock 333 119 489 minecraft:red_nether_bricks
fill 333 119 490 333 121 490 minecraft:pink_terracotta
fill 334 119 464 337 119 464 minecraft:pink_terracotta
setblock 336 119 465 minecraft:pink_terracotta
setblock 336 119 466 minecraft:red_nether_bricks
fill 336 119 467 337 120 467 minecraft:pink_terracotta
fill 336 119 504 336 120 504 minecraft:pink_terracotta
setblock 337 119 465 minecraft:red_nether_bricks
fill 337 119 466 337 122 466 minecraft:pink_terracotta
setblock 338 119 464 minecraft:red_nether_bricks
fill 338 119 465 341 119 465 minecraft:pink_terracotta
fill 339 119 464 342 119 464 minecraft:pink_terracotta
setblock 340 119 474 minecraft:light[level=12]
setblock 340 119 482 minecraft:light[level=12]
setblock 340 119 490 minecraft:light[level=12]
setblock 340 119 498 minecraft:light[level=12]
setblock 340 119 504 minecraft:white_concrete
setblock 341 119 466 minecraft:red_nether_bricks
setblock 342 119 465 minecraft:red_nether_bricks
setblock 343 119 464 minecraft:red_nether_bricks
fill 343 119 465 343 120 465 minecraft:pink_terracotta
fill 344 119 464 344 122 464 minecraft:pink_terracotta
fill 345 119 465 346 119 465 minecraft:pink_terracotta
setblock 347 119 465 minecraft:red_nether_bricks
setblock 348 119 464 minecraft:red_nether_bricks
fill 348 119 465 348 122 465 minecraft:pink_terracotta
setblock 348 119 466 minecraft:light[level=12]
setblock 348 119 474 minecraft:light[level=12]
setblock 348 119 482 minecraft:light[level=12]
setblock 348 119 490 minecraft:light[level=12]
setblock 348 119 498 minecraft:light[level=12]
fill 349 119 464 349 122 464 minecraft:pink_terracotta
fill 350 119 504 350 121 504 minecraft:pink_terracotta
setblock 351 119 466 minecraft:red_nether_bricks
setblock 352 119 465 minecraft:red_nether_bricks
fill 352 119 466 352 122 466 minecraft:pink_terracotta
setblock 353 119 464 minecraft:red_nether_bricks
fill 353 119 465 353 122 465 minecraft:pink_terracotta
setblock 353 119 503 minecraft:pink_terracotta
setblock 353 119 504 minecraft:red_nether_bricks
fill 354 119 464 354 122 464 minecraft:pink_terracotta
setblock 354 119 467 minecraft:pink_terracotta
setblock 354 119 503 minecraft:red_nether_bricks
fill 354 119 504 354 122 504 minecraft:pink_terracotta
setblock 355 119 467 minecraft:red_nether_bricks
fill 355 119 503 355 122 503 minecraft:pink_terracotta
setblock 356 119 466 minecraft:red_nether_bricks
fill 356 119 467 356 120 467 minecraft:pink_terracotta
setblock 356 119 474 minecraft:light[level=12]
setblock 356 119 482 minecraft:light[level=12]
setblock 356 119 490 minecraft:light[level=12]
setblock 356 119 498 minecraft:light[level=12]
setblock 357 119 465 minecraft:red_nether_bricks
fill 357 119 466 357 121 466 minecraft:pink_terracotta
setblock 358 119 464 minecraft:red_nether_bricks
fill 358 119 465 358 122 465 minecraft:pink_terracotta
setblock 358 119 504 minecraft:red_nether_bricks
fill 359 119 464 359 122 464 minecraft:pink_terracotta
setblock 359 119 503 minecraft:red_nether_bricks
fill 359 119 504 359 122 504 minecraft:pink_terracotta
fill 360 119 503 360 121 503 minecraft:pink_terracotta
setblock 363 119 464 minecraft:red_nether_bricks
setblock 363 119 504 minecraft:red_nether_bricks
setblock 364 119 466 minecraft:light[level=12]
setblock 364 119 474 minecraft:light[level=12]
setblock 364 119 482 minecraft:light[level=12]
setblock 364 119 490 minecraft:light[level=12]
setblock 364 119 498 minecraft:light[level=12]
fill 368 119 490 368 119 493 minecraft:pink_terracotta
fill 369 119 486 369 119 487 minecraft:pink_terracotta
setblock 369 119 488 minecraft:red_nether_bricks
fill 369 119 489 369 119 492 minecraft:pink_terracotta
setblock 369 119 493 minecraft:red_nether_bricks
fill 369 119 494 369 122 494 minecraft:pink_terracotta
fill 369 119 496 369 119 497 minecraft:pink_terracotta
setblock 370 119 466 minecraft:pink_terracotta
setblock 370 119 467 minecraft:red_nether_bricks
fill 370 119 468 370 122 468 minecraft:pink_terracotta
setblock 370 119 472 minecraft:red_nether_bricks
fill 370 119 473 370 121 474 minecraft:pink_terracotta
setblock 370 119 479 minecraft:white_concrete
fill 370 119 483 370 122 483 minecraft:pink_terracotta
setblock 370 119 487 minecraft:red_nether_bricks
fill 370 119 488 370 122 488 minecraft:pink_terracotta
setblock 370 119 492 minecraft:red_nether_bricks
fill 370 119 493 370 122 493 minecraft:pink_terracotta
setblock 370 119 497 minecraft:red_nether_bricks
fill 370 119 498 370 122 498 minecraft:pink_terracotta
fill 370 119 500 370 120 500 minecraft:pink_terracotta
setblock 330 120 465 minecraft:pink_terracotta
setblock 330 120 466 minecraft:red_nether_bricks
fill 330 120 467 330 120 470 minecraft:pink_terracotta
setblock 330 120 471 minecraft:red_nether_bricks
fill 330 120 472 330 120 475 minecraft:pink_terracotta
setblock 330 120 476 minecraft:red_nether_bricks
fill 330 120 477 330 123 477 minecraft:pink_terracotta
fill 330 120 479 330 120 480 minecraft:pink_terracotta
setblock 330 120 481 minecraft:red_nether_bricks
fill 330 120 482 330 123 482 minecraft:pink_terracotta
setblock 330 120 486 minecraft:red_nether_bricks
fill 330 120 487 330 123 487 minecraft:pink_terracotta
setblock 330 120 491 minecraft:red_nether_bricks
fill 330 120 492 330 123 492 minecraft:pink_terracotta
setblock 330 120 496 minecraft:red_nether_bricks
fill 330 120 497 331 122 497 minecraft:pink_terracotta
fill 330 120 499 330 121 499 minecraft:pink_terracotta
fill 331 120 466 331 120 469 minecraft:pink_terracotta
setblock 331 120 470 minecraft:red_nether_bricks
fill 331 120 471 331 123 471 minecraft:pink_terracotta
setblock 331 120 475 minecraft:red_nether_bricks
fill 331 120 476 332 122 476 minecraft:pink_terracotta
setblock 331 120 479 minecraft:pink_terracotta
setblock 331 120 480 minecraft:red_nether_bricks
fill 331 120 481 331 123 481 minecraft:pink_terracotta
setblock 331 120 485 minecraft:red_nether_bricks
fill 331 120 486 331 123 486 minecraft:pink_terracotta
setblock 331 120 490 minecraft:red_nether_bricks
fill 331 120 491 331 123 491 minecraft:pink_terracotta
setblock 331 120 495 minecraft:red_nether_bricks
fill 331 120 496 331 123 496 minecraft:pink_terracotta
setblock 332 120 464 minecraft:red_nether_bricks
fill 332 120 465 332 123 465 minecraft:pink_terracotta
fill 332 120 467 332 120 468 minecraft:pink_terracotta
setblock 332 120 469 minecraft:red_nether_bricks
fill 332 120 470 333 122 470 minecraft:pink_terracotta
setblock 332 120 473 minecraft:pink_terracotta
setblock 332 120 474 minecraft:red_nether_bricks
fill 332 120 475 333 122 475 minecraft:pink_terracotta
fill 332 120 477 332 120 478 minecraft:pink_terracotta
setblock 332 120 484 minecraft:red_nether_bricks
fill 332 120 485 332 122 485 minecraft:pink_terracotta
setblock 332 120 489 minecraft:red_nether_bricks
fill 332 120 490 332 123 490 minecraft:pink_terracotta
setblock 332 120 494 minecraft:red_nether_bricks
fill 332 120 495 332 123 495 minecraft:pink_terracotta
fill 333 120 464 336 120 464 minecraft:pink_terracotta
fill 333 120 466 333 121 466 minecraft:pink_terracotta
fill 333 120 469 333 123 469 minecraft:pink_terracotta
setblock 333 120 472 minecraft:pink_terracotta
setblock 333 120 473 minecraft:red_nether_bricks
fill 333 120 474 333 123 474 minecraft:pink_terracotta
fill 333 120 489 333 121 489 minecraft:pink_terracotta
setblock 333 120 492 minecraft:pink_terracotta
setblock 335 120 465 minecraft:pink_terracotta
setblock 335 120 466 minecraft:red_nether_bricks
fill 335 120 504 335 121 504 minecraft:pink_terracotta
setblock 336 120 465 minecraft:red_nether_bricks
fill 336 120 466 336 122 466 minecraft:pink_terracotta
setblock 337 120 464 minecraft:red_nether_bricks
fill 337 120 465 340 120 465 minecraft:pink_terracotta
fill 338 120 464 341 120 464 minecraft:pink_terracotta
setblock 340 120 466 minecraft:red_nether_bricks
setblock 341 120 465 minecraft:red_nether_bricks
setblock 342 120 464 minecraft:red_nether_bricks
fill 342 120 465 342 121 465 minecraft:pink_terracotta
fill 343 120 464 343 123 464 minecraft:pink_terracotta
setblock 345 120 465 minecraft:pink_terracotta
setblock 346 120 465 minecraft:red_nether_bricks
setblock 346 120 504 minecraft:white_concrete
setblock 347 120 464 minecraft:red_nether_bricks
fill 347 120 465 347 122 465 minecraft:pink_terracotta
fill 348 120 464 348 123 464 minecraft:pink_terracotta
setblock 349 120 466 minecraft:pink_terracotta
fill 349 120 504 349 122 504 minecraft:pink_terracotta
setblock 350 120 466 minecraft:red_nether_bricks
setblock 351 120 465 minecraft:red_nether_bricks
fill 351 120 466 351 123 466 minecraft:pink_terracotta
setblock 352 120 464 minecraft:red_nether_bricks
fill 352 120 465 352 123 465 minecraft:pink_terracotta
fill 352 120 467 352 121 467 minecraft:pink_terracotta
setblock 352 120 503 minecraft:pink_terracotta
setblock 352 120 504 minecraft:red_nether_bricks
fill 353 120 464 353 123 464 minecraft:pink_terracotta
setblock 353 120 503 minecraft:red_nether_bricks
fill 353 120 504 353 123 504 minecraft:pink_terracotta
setblock 354 120 467 minecraft:red_nether_bricks
fill 354 120 503 354 123 503 minecraft:pink_terracotta
setblock 355 120 466 minecraft:red_nether_bricks
fill 355 120 467 355 121 467 minecraft:pink_terracotta
fill 355 120 502 356 122 502 minecraft:pink_terracotta
setblock 356 120 465 minecraft:red_nether_bricks
fill 356 120 466 356 122 466 minecraft:pink_terracotta
setblock 357 120 464 minecraft:red_nether_bricks
fill 357 120 465 357 123 465 minecraft:pink_terracotta
setblock 357 120 504 minecraft:red_nether_bricks
fill 358 120 464 358 123 464 minecraft:pink_terracotta
setblock 358 120 503 minecraft:red_nether_bricks
fill 358 120 504 358 123 504 minecraft:pink_terracotta
fill 359 120 503 359 122 503 minecraft:pink_terracotta
setblock 362 120 464 minecraft:red_nether_bricks
setblock 362 120 504 minecraft:red_nether_bricks
setblock 363 120 504 minecraft:pink_terracotta
setblock 365 120 504 minecraft:white_concrete
fill 368 120 490 368 120 492 minecraft:pink_terracotta
setblock 368 120 493 minecraft:red_nether_bricks
fill 368 120 494 368 122 495 minecraft:pink_terracotta
setblock 369 120 486 minecraft:pink_terracotta
setblock 369 120 487 minecraft:red_nether_bricks
fill 369 120 488 369 120 491 minecraft:pink_terracotta
setblock 369 120 492 minecraft:red_nether_bricks
fill 369 120 493 369 123 493 minecraft:pink_terracotta
setblock 369 120 496 minecraft:pink_terracotta
setblock 369 120 497 minecraft:red_nether_bricks
fill 369 120 498 369 123 498 minecraft:pink_terracotta
setblock 370 120 466 minecraft:red_nether_bricks
fill 370 120 467 370 123 467 minecraft:pink_terracotta
fill 370 120 469 370 120 470 minecraft:pink_terracotta
setblock 370 120 471 minecraft:red_nether_bricks
fill 370 120 472 370 123 472 minecraft:pink_terracotta
setblock 370 120 475 minecraft:pink_terracotta
setblock 370 120 476 minecraft:red_nether_bricks
fill 370 120 477 370 122 478 minecraft:pink_terracotta
setblock 370 120 481 minecraft:red_nether_bricks
fill 370 120 482 370 123 482 minecraft:pink_terracotta
setblock 370 120 486 minecraft:red_nether_bricks
fill 370 120 487 370 123 487 minecraft:pink_terracotta
setblock 370 120 491 minecraft:red_nether_bricks
fill 370 120 492 370 123 492 minecraft:pink_terracotta
setblock 370 120 496 minecraft:red_nether_bricks
fill 370 120 497 370 123 497 minecraft:pink_terracotta
setblock 370 120 501 minecraft:red_nether_bricks
fill 370 120 502 370 123 502 minecraft:pink_terracotta
setblock 330 121 464 minecraft:pink_terracotta
setblock 330 121 465 minecraft:red_nether_bricks
fill 330 121 466 330 121 469 minecraft:pink_terracotta
setblock 330 121 470 minecraft:red_nether_bricks
fill 330 121 471 330 121 474 minecraft:pink_terracotta
setblock 330 121 475 minecraft:red_nether_bricks
fill 330 121 476 330 124 476 minecraft:pink_terracotta
setblock 330 121 479 minecraft:pink_terracotta
setblock 330 121 480 minecraft:red_nether_bricks
fill 330 121 481 330 124 481 minecraft:pink_terracotta
setblock 330 121 485 minecraft:red_nether_bricks
fill 330 121 486 330 124 486 minecraft:pink_terracotta
setblock 330 121 490 minecraft:red_nether_bricks
fill 330 121 491 330 124 491 minecraft:pink_terracotta
setblock 330 121 494 minecraft:pink_terracotta
setblock 330 121 495 minecraft:red_nether_bricks
fill 330 121 496 330 124 496 minecraft:pink_terracotta
setblock 330 121 500 minecraft:red_nether_bricks
setblock 330 121 501 minecraft:white_concrete
setblock 331 121 464 minecraft:red_nether_bricks
fill 331 121 466 331 121 468 minecraft:pink_terracotta
setblock 331 121 469 minecraft:red_nether_bricks
fill 331 121 470 331 124 470 minecraft:pink_terracotta
setblock 331 121 473 minecraft:pink_terracotta
setblock 331 121 474 minecraft:red_nether_bricks
fill 331 121 475 331 124 475 minecraft:pink_terracotta
setblock 331 121 479 minecraft:red_nether_bricks
fill 331 121 480 332 123 480 minecraft:pink_terracotta
setblock 331 121 484 minecraft:red_nether_bricks
fill 331 121 485 331 124 485 minecraft:pink_terracotta
setblock 331 121 489 minecraft:red_nether_bricks
fill 331 121 490 331 124 490 minecraft:pink_terracotta
setblock 331 121 493 minecraft:pink_terracotta
setblock 331 121 494 minecraft:red_nether_bricks
fill 331 121 495 331 124 495 minecraft:pink_terracotta
setblock 331 121 498 minecraft:pink_terracotta
fill 332 121 464 335 121 464 minecraft:pink_terracotta
setblock 332 121 467 minecraft:pink_terracotta
setblock 332 121 468 minecraft:red_nether_bricks
fill 332 121 469 332 124 469 minecraft:pink_terracotta
setblock 332 121 473 minecraft:red_nether_bricks
fill 332 121 474 332 124 474 minecraft:pink_terracotta
setblock 332 121 477 minecraft:pink_terracotta
setblock 332 121 478 minecraft:red_nether_bricks
fill 332 121 479 332 124 479 minecraft:pink_terracotta
setblock 332 121 484 minecraft:pink_terracotta
setblock 332 121 488 minecraft:red_nether_bricks
fill 332 121 489 332 123 489 minecraft:pink_terracotta
setblock 332 121 493 minecraft:red_nether_bricks
fill 332 121 494 332 124 494 minecraft:pink_terracotta
fill 332 121 496 332 122 496 minecraft:pink_terracotta
setblock 333 121 472 minecraft:red_nether_bricks
fill 333 121 473 334 123 473 minecraft:pink_terracotta
setblock 333 121 476 minecraft:pink_terracotta
setblock 333 121 477 minecraft:red_nether_bricks
setblock 333 121 492 minecraft:red_nether_bricks
setblock 333 121 493 minecraft:pink_terracotta
setblock 334 121 465 minecraft:pink_terracotta
setblock 334 121 466 minecraft:red_nether_bricks
fill 334 121 472 334 123 472 minecraft:pink_terracotta
fill 334 121 504 334 122 504 minecraft:pink_terracotta
setblock 335 121 465 minecraft:red_nether_bricks
fill 335 121 466 335 122 466 minecraft:pink_terracotta
setblock 336 121 464 minecraft:red_nether_bricks
fill 336 121 465 339 121 465 minecraft:pink_terracotta
setblock 336 121 504 minecraft:red_nether_bricks
fill 337 121 464 340 121 464 minecraft:pink_terracotta
setblock 339 121 466 minecraft:red_nether_bricks
setblock 340 121 465 minecraft:red_nether_bricks
setblock 341 121 464 minecraft:red_nether_bricks
setblock 341 121 465 minecraft:pink_terracotta
fill 342 121 464 342 123 464 minecraft:pink_terracotta
setblock 346 121 464 minecraft:red_nether_bricks
setblock 346 121 465 minecraft:pink_terracotta
fill 347 121 464 347 124 464 minecraft:pink_terracotta
fill 348 121 504 348 123 504 minecraft:pink_terracotta
setblock 349 121 466 minecraft:red_nether_bricks
setblock 350 121 465 minecraft:red_nether_bricks
fill 350 121 466 350 123 466 minecraft:pink_terracotta
setblock 351 121 464 minecraft:red_nether_bricks
fill 351 121 465 351 124 465 minecraft:pink_terracotta
setblock 351 121 503 minecraft:pink_terracotta
setblock 351 121 504 minecraft:red_nether_bricks
fill 352 121 464 352 124 464 minecraft:pink_terracotta
setblock 352 121 503 minecraft:red_nether_bricks
fill 352 121 504 352 124 504 minecraft:pink_terracotta
setblock 353 121 466 minecraft:pink_terracotta
setblock 353 121 467 minecraft:red_nether_bricks
fill 353 121 503 353 124 503 minecraft:pink_terracotta
setblock 354 121 466 minecraft:red_nether_bricks
setblock 354 121 467 minecraft:pink_terracotta
fill 354 121 502 354 124 502 minecraft:pink_terracotta
setblock 355 121 465 minecraft:red_nether_bricks
fill 355 121 466 355 122 466 minecraft:pink_terracotta
setblock 356 121 464 minecraft:red_nether_bricks
fill 356 121 465 356 123 465 minecraft:pink_terracotta
setblock 356 121 504 minecraft:red_nether_bricks
fill 357 121 464 357 124 464 minecraft:pink_terracotta
setblock 357 121 502 minecraft:pink_terracotta
setblock 357 121 503 minecraft:red_nether_bricks
fill 357 121 504 357 124 504 minecraft:pink_terracotta
fill 358 121 503 358 124 503 minecraft:pink_terracotta
setblock 361 121 464 minecraft:red_nether_bricks
setblock 361 121 504 minecraft:red_nether_bricks
setblock 362 121 504 minecraft:pink_terracotta
fill 368 121 489 368 121 491 minecraft:pink_terracotta
setblock 368 121 492 minecraft:red_nether_bricks
fill 368 121 493 368 124 493 minecraft:pink_terracotta
setblock 368 121 496 minecraft:pink_terracotta
setblock 369 121 486 minecraft:red_nether_bricks
fill 369 121 487 369 121 490 minecraft:pink_terracotta
setblock 369 121 491 minecraft:red_nether_bricks
fill 369 121 492 369 124 492 minecraft:pink_terracotta
setblock 369 121 496 minecraft:red_nether_bricks
fill 369 121 497 369 124 497 minecraft:pink_terracotta
fill 369 121 499 369 122 499 minecraft:pink_terracotta
fill 370 121 466 370 122 466 minecraft:pink_terracotta
setblock 370 121 469 minecraft:pink_terracotta
setblock 370 121 470 minecraft:red_nether_bricks
fill 370 121 471 370 124 471 minecraft:pink_terracotta
setblock 370 121 475 minecraft:red_nether_bricks
fill 370 121 476 370 124 476 minecraft:pink_terracotta
setblock 370 121 479 minecraft:pink_terracotta
setblock 370 121 480 minecraft:red_nether_bricks
fill 370 121 481 370 124 481 minecraft:pink_terracotta
setblock 370 121 485 minecraft:red_nether_bricks
fill 370 121 486 370 124 486 minecraft:pink_terracotta
setblock 370 121 490 minecraft:red_nether_bricks
fill 370 121 491 370 124 491 minecraft:pink_terracotta
setblock 370 121 495 minecraft:red_nether_bricks
fill 370 121 496 370 124 496 minecraft:pink_terracotta
setblock 370 121 500 minecraft:red_nether_bricks
fill 370 121 501 370 124 501 minecraft:pink_terracotta
fill 370 121 503 370 122 503 minecraft:pink_terracotta
setblock 330 122 464 minecraft:red_nether_bricks
fill 330 122 465 330 122 468 minecraft:pink_terracotta
setblock 330 122 469 minecraft:red_nether_bricks
fill 330 122 470 330 122 473 minecraft:pink_terracotta
setblock 330 122 474 minecraft:red_nether_bricks
fill 330 122 475 330 125 475 minecraft:pink_terracotta
setblock 330 122 478 minecraft:pink_terracotta
setblock 330 122 479 minecraft:red_nether_bricks
fill 330 122 480 330 125 480 minecraft:pink_terracotta
setblock 330 122 484 minecraft:red_nether_bricks
fill 330 122 485 330 125 485 minecraft:pink_terracotta
setblock 330 122 489 minecraft:red_nether_bricks
fill 330 122 490 330 125 490 minecraft:pink_terracotta
setblock 330 122 494 minecraft:red_nether_bricks
fill 330 122 495 330 125 495 minecraft:pink_terracotta
setblock 330 122 499 minecraft:red_nether_bricks
fill 330 122 500 330 125 500 minecraft:pink_terracotta
fill 331 122 464 334 122 464 minecraft:pink_terracotta
fill 331 122 466 331 122 467 minecraft:pink_terracotta
setblock 331 122 468 minecraft:red_nether_bricks
fill 331 122 469 331 125 469 minecraft:pink_terracotta
setblock 331 122 472 minecraft:pink_terracotta
setblock 331 122 473 minecraft:red_nether_bricks
fill 331 122 474 331 125 474 minecraft:pink_terracotta
setblock 331 122 478 minecraft:red_nether_bricks
fill 331 122 479 331 125 479 minecraft:pink_terracotta
setblock 331 122 483 minecraft:red_nether_bricks
fill 331 122 484 331 125 484 minecraft:pink_terracotta
setblock 331 122 488 minecraft:red_nether_bricks
fill 331 122 489 331 125 489 minecraft:pink_terracotta
setblock 331 122 493 minecraft:red_nether_bricks
fill 331 122 494 331 125 494 minecraft:pink_terracotta
setblock 331 122 498 minecraft:red_nether_bricks
setblock 332 122 467 minecraft:red_nether_bricks
fill 332 122 468 332 124 468 minecraft:pink_terracotta
setblock 332 122 471 minecraft:pink_terracotta
setblock 332 122 472 minecraft:red_nether_bricks
fill 332 122 473 332 125 473 minecraft:pink_terracotta
setblock 332 122 477 minecraft:red_nether_bricks
fill 332 122 478 333 124 478 minecraft:pink_terracotta
setblock 332 122 481 minecraft:pink_terracotta
setblock 332 122 487 minecraft:red_nether_bricks
fill 332 122 488 332 123 488 minecraft:pink_terracotta
setblock 332 122 491 minecraft:pink_terracotta
setblock 332 122 492 minecraft:red_nether_bricks
fill 332 122 493 332 125 493 minecraft:pink_terracotta
setblock 333 122 466 minecraft:red_nether_bricks
setblock 333 122 471 minecraft:red_nether_bricks
fill 333 122 472 333 125 472 minecraft:pink_terracotta
setblock 333 122 476 minecraft:red_nether_bricks
fill 333 122 477 333 125 477 minecraft:pink_terracotta
setblock 333 122 492 minecraft:pink_terracotta
setblock 333 122 504 minecraft:white_concrete
setblock 334 122 465 minecraft:red_nether_bricks
setblock 334 122 466 minecraft:pink_terracotta
setblock 334 122 471 minecraft:pink_terracotta
setblock 334 122 474 minecraft:pink_terracotta
setblock 335 122 464 minecraft:red_nether_bricks
fill 335 122 465 338 122 465 minecraft:pink_terracotta
setblock 335 122 504 minecraft:red_nether_bricks
fill 336 122 464 339 122 464 minecraft:pink_terracotta
setblock 339 122 465 minecraft:red_nether_bricks
setblock 340 122 464 minecraft:red_nether_bricks
setblock 340 122 465 minecraft:pink_terracotta
fill 341 122 464 341 123 464 minecraft:pink_terracotta
fill 341 122 480 342 123 480 minecraft:pink_concrete
setblock 345 122 464 minecraft:red_nether_bricks
fill 346 122 464 346 125 464 minecraft:pink_terracotta
setblock 349 122 465 minecraft:red_nether_bricks
setblock 350 122 464 minecraft:red_nether_bricks
fill 350 122 465 350 125 465 minecraft:pink_terracotta
setblock 350 122 503 minecraft:pink_terracotta
setblock 350 122 504 minecraft:red_nether_bricks
fill 351 122 464 351 125 464 minecraft:pink_terracotta
setblock 351 122 503 minecraft:red_nether_bricks
fill 351 122 504 351 125 504 minecraft:pink_terracotta
fill 352 122 503 352 125 503 minecraft:pink_terracotta
setblock 353 122 466 minecraft:red_nether_bricks
fill 353 122 502 353 125 502 minecraft:pink_terracotta
setblock 354 122 465 minecraft:red_nether_bricks
fill 354 122 466 354 123 466 minecraft:pink_terracotta
setblock 355 122 464 minecraft:red_nether_bricks
fill 355 122 465 355 124 465 minecraft:pink_terracotta
setblock 355 122 504 minecraft:red_nether_bricks
fill 356 122 464 356 125 464 minecraft:pink_terracotta
setblock 356 122 503 minecraft:red_nether_bricks
fill 356 122 504 356 125 504 minecraft:pink_terracotta
setblock 357 122 502 minecraft:red_nether_bricks
fill 357 122 503 357 125 503 minecraft:pink_terracotta
setblock 360 122 464 minecraft:red_nether_bricks
setblock 360 122 504 minecraft:red_nether_bricks
fill 361 122 504 361 123 504 minecraft:pink_terracotta
setblock 367 122 464 minecraft:white_concrete
fill 368 122 489 368 122 490 minecraft:pink_terracotta
setblock 368 122 491 minecraft:red_nether_bricks
fill 368 122 492 368 125 492 minecraft:pink_terracotta
setblock 368 122 496 minecraft:red_nether_bricks
fill 368 122 497 368 125 497 minecraft:pink_terracotta
fill 369 122 471 369 122 474 minecraft:pink_terracotta
setblock 369 122 475 minecraft:red_nether_bricks
fill 369 122 486 369 122 489 minecraft:pink_terracotta
setblock 369 122 490 minecraft:red_nether_bricks
fill 369 122 491 369 125 491 minecraft:pink_terracotta
setblock 369 122 495 minecraft:red_nether_bricks
fill 369 122 496 369 125 496 minecraft:pink_terracotta
setblock 369 122 500 minecraft:red_nether_bricks
setblock 370 122 469 minecraft:red_nether_bricks
fill 370 122 470 370 125 470 minecraft:pink_terracotta
setblock 370 122 473 minecraft:pink_terracotta
setblock 370 122 474 minecraft:red_nether_bricks
fill 370 122 475 370 125 475 minecraft:pink_terracotta
setblock 370 122 479 minecraft:red_nether_bricks
fill 370 122 480 370 125 480 minecraft:pink_terracotta
setblock 370 122 484 minecraft:red_nether_bricks
fill 370 122 485 370 125 485 minecraft:pink_terracotta
setblock 370 122 489 minecraft:red_nether_bricks
fill 370 122 490 370 125 490 minecraft:pink_terracotta
setblock 370 122 494 minecraft:red_nether_bricks
fill 370 122 495 370 125 495 minecraft:pink_terracotta
setblock 370 122 499 minecraft:red_nether_bricks
fill 370 122 500 370 125 500 minecraft:pink_terracotta
fill 330 123 464 330 123 467 minecraft:pink_terracotta
setblock 330 123 468 minecraft:red_nether_bricks
fill 330 123 469 330 123 472 minecraft:pink_terracotta
setblock 330 123 473 minecraft:red_nether_bricks
fill 330 123 474 330 126 474 minecraft:pink_terracotta
setblock 330 123 478 minecraft:red_nether_bricks
fill 330 123 479 330 126 479 minecraft:pink_terracotta
setblock 330 123 483 minecraft:red_nether_bricks
fill 330 123 484 330 126 484 minecraft:pink_terracotta
setblock 330 123 488 minecraft:red_nether_bricks
fill 330 123 489 330 126 489 minecraft:pink_terracotta
setblock 330 123 493 minecraft:red_nether_bricks
fill 330 123 494 330 126 494 minecraft:pink_terracotta
setblock 330 123 497 minecraft:pink_terracotta
setblock 330 123 498 minecraft:red_nether_bricks
fill 330 123 499 331 125 499 minecraft:pink_terracotta
fill 330 123 501 330 124 501 minecraft:pink_terracotta
fill 331 123 464 333 123 464 minecraft:pink_terracotta
setblock 331 123 466 minecraft:pink_terracotta
setblock 331 123 467 minecraft:red_nether_bricks
fill 331 123 468 331 126 468 minecraft:pink_terracotta
setblock 331 123 472 minecraft:red_nether_bricks
fill 331 123 473 331 126 473 minecraft:pink_terracotta
setblock 331 123 476 minecraft:pink_terracotta
setblock 331 123 477 minecraft:red_nether_bricks
fill 331 123 478 331 126 478 minecraft:pink_terracotta
setblock 331 123 482 minecraft:red_nether_bricks
fill 331 123 483 331 126 483 minecraft:pink_terracotta
setblock 331 123 487 minecraft:red_nether_bricks
fill 331 123 488 331 125 488 minecraft:pink_terracotta
setblock 331 123 492 minecraft:red_nether_bricks
fill 331 123 493 331 126 493 minecraft:pink_terracotta
setblock 331 123 497 minecraft:red_nether_bricks
fill 331 123 498 331 126 498 minecraft:pink_terracotta
setblock 332 123 467 minecraft:pink_terracotta
setblock 332 123 470 minecraft:pink_terracotta
setblock 332 123 471 minecraft:red_nether_bricks
fill 332 123 472 332 126 472 minecraft:pink_terracotta
setblock 332 123 475 minecraft:pink_terracotta
setblock 332 123 476 minecraft:red_nether_bricks
fill 332 123 477 332 126 477 minecraft:pink_terracotta
setblock 332 123 481 minecraft:red_nether_bricks
setblock 332 123 487 minecraft:pink_terracotta
setblock 332 123 491 minecraft:red_nether_bricks
fill 332 123 492 332 124 492 minecraft:pink_terracotta
setblock 332 123 496 minecraft:red_nether_bricks
setblock 333 123 465 minecraft:red_nether_bricks
setblock 333 123 470 minecraft:red_nether_bricks
fill 333 123 471 333 125 471 minecraft:pink_terracotta
setblock 333 123 475 minecraft:red_nether_bricks
fill 333 123 476 333 126 476 minecraft:pink_terracotta
setblock 334 123 464 minecraft:red_nether_bricks
fill 334 123 465 337 123 465 minecraft:pink_terracotta
setblock 334 123 474 minecraft:red_nether_bricks
fill 335 123 464 338 123 464 minecraft:pink_terracotta
setblock 338 123 465 minecraft:red_nether_bricks
setblock 339 123 464 minecraft:red_nether_bricks
setblock 339 123 504 minecraft:white_concrete
setblock 340 123 464 minecraft:pink_terracotta
setblock 344 123 464 minecraft:red_nether_bricks
fill 345 123 464 345 124 464 minecraft:pink_terracotta
setblock 348 123 465 minecraft:red_nether_bricks
setblock 349 123 464 minecraft:red_nether_bricks
fill 349 123 465 349 125 465 minecraft:pink_terracotta
setblock 349 123 504 minecraft:red_nether_bricks
fill 350 123 464 350 126 464 minecraft:pink_terracotta
setblock 350 123 503 minecraft:red_nether_bricks
fill 350 123 504 350 126 504 minecraft:pink_terracotta
fill 351 123 503 351 126 503 minecraft:pink_terracotta
setblock 352 123 466 minecraft:red_nether_bricks
fill 352 123 502 352 126 502 minecraft:pink_terracotta
setblock 353 123 465 minecraft:red_nether_bricks
setblock 353 123 466 minecraft:pink_terracotta
setblock 354 123 464 minecraft:red_nether_bricks
fill 354 123 465 354 124 465 minecraft:pink_terracotta
setblock 354 123 504 minecraft:red_nether_bricks
fill 355 123 464 355 126 464 minecraft:pink_terracotta
setblock 355 123 502 minecraft:pink_terracotta
setblock 355 123 503 minecraft:red_nether_bricks
fill 355 123 504 355 126 504 minecraft:pink_terracotta
setblock 356 123 502 minecraft:red_nether_bricks
fill 356 123 503 356 126 503 minecraft:pink_terracotta
setblock 359 123 464 minecraft:red_nether_bricks
setblock 359 123 504 minecraft:red_nether_bricks
fill 360 123 504 360 124 504 minecraft:pink_terracotta
setblock 361 123 464 minecraft:white_concrete
setblock 364 123 504 minecraft:white_concrete
setblock 368 123 490 minecraft:red_nether_bricks
fill 368 123 491 368 125 491 minecraft:pink_terracotta
setblock 368 123 494 minecraft:pink_terracotta
setblock 368 123 495 minecraft:red_nether_bricks
fill 368 123 496 368 126 496 minecraft:pink_terracotta
fill 369 123 471 369 123 473 minecraft:pink_terracotta
setblock 369 123 474 minecraft:red_nether_bricks
fill 369 123 475 369 124 477 minecraft:pink_terracotta
fill 369 123 486 369 123 488 minecraft:pink_terracotta
setblock 369 123 489 minecraft:red_nether_bricks
fill 369 123 490 369 126 490 minecraft:pink_terracotta
setblock 369 123 494 minecraft:red_nether_bricks
fill 369 123 495 369 126 495 minecraft:pink_terracotta
setblock 369 123 499 minecraft:red_nether_bricks
fill 369 123 500 369 126 500 minecraft:pink_terracotta
setblock 370 123 468 minecraft:red_nether_bricks
fill 370 123 469 370 126 469 minecraft:pink_terracotta
setblock 370 123 473 minecraft:red_nether_bricks
fill 370 123 474 370 126 474 minecraft:pink_terracotta
setblock 370 123 477 minecraft:pink_terracotta
setblock 370 123 478 minecraft:red_nether_bricks
fill 370 123 479 370 126 479 minecraft:pink_terracotta
setblock 370 123 483 minecraft:red_nether_bricks
fill 370 123 484 370 126 484 minecraft:pink_terracotta
setblock 370 123 488 minecraft:red_nether_bricks
fill 370 123 489 370 126 489 minecraft:pink_terracotta
setblock 370 123 493 minecraft:red_nether_bricks
fill 370 123 494 370 126 494 minecraft:pink_terracotta
setblock 370 123 498 minecraft:red_nether_bricks
fill 370 123 499 370 126 499 minecraft:pink_terracotta
setblock 370 123 503 minecraft:red_nether_bricks
fill 330 124 465 330 124 466 minecraft:pink_terracotta
setblock 330 124 467 minecraft:red_nether_bricks
fill 330 124 468 330 124 471 minecraft:pink_terracotta
setblock 330 124 472 minecraft:red_nether_bricks
fill 330 124 473 330 127 473 minecraft:pink_terracotta
setblock 330 124 477 minecraft:red_nether_bricks
fill 330 124 478 330 127 478 minecraft:pink_terracotta
setblock 330 124 482 minecraft:red_nether_bricks
fill 330 124 483 330 127 483 minecraft:pink_terracotta
setblock 330 124 487 minecraft:red_nether_bricks
fill 330 124 488 330 127 488 minecraft:pink_terracotta
setblock 330 124 492 minecraft:red_nether_bricks
fill 330 124 493 330 127 493 minecraft:pink_terracotta
setblock 330 124 497 minecraft:red_nether_bricks
fill 330 124 498 330 127 498 minecraft:pink_terracotta
fill 331 124 464 332 124 464 minecraft:pink_terracotta
setblock 331 124 466 minecraft:red_nether_bricks
fill 331 124 467 331 125 467 minecraft:pink_terracotta
setblock 331 124 471 minecraft:red_nether_bricks
fill 331 124 472 331 127 472 minecraft:pink_terracotta
setblock 331 124 476 minecraft:red_nether_bricks
fill 331 124 477 331 127 477 minecraft:pink_terracotta
setblock 331 124 480 minecraft:pink_terracotta
setblock 331 124 481 minecraft:red_nether_bricks
fill 331 124 482 331 127 482 minecraft:pink_terracotta
setblock 331 124 486 minecraft:red_nether_bricks
fill 331 124 487 331 125 487 minecraft:pink_terracotta
setblock 331 124 491 minecraft:red_nether_bricks
fill 331 124 492 331 127 492 minecraft:pink_terracotta
setblock 331 124 496 minecraft:red_nether_bricks
fill 331 124 497 331 127 497 minecraft:pink_terracotta
setblock 332 124 470 minecraft:red_nether_bricks
fill 332 124 471 332 127 471 minecraft:pink_terracotta
setblock 332 124 475 minecraft:red_nether_bricks
fill 332 124 476 332 127 476 minecraft:pink_terracotta
setblock 332 124 480 minecraft:red_nether_bricks
fill 332 124 481 332 127 481 minecraft:pink_terracotta
setblock 332 124 490 minecraft:red_nether_bricks
setblock 332 124 491 minecraft:pink_terracotta
setblock 332 124 495 minecraft:red_nether_bricks
setblock 332 124 496 minecraft:pink_terracotta
setblock 333 124 464 minecraft:red_nether_bricks
fill 333 124 465 336 124 465 minecraft:pink_terracotta
setblock 333 124 470 minecraft:pink_terracotta
setblock 333 124 473 minecraft:pink_terracotta
setblock 333 124 474 minecraft:red_nether_bricks
fill 333 124 475 333 127 475 minecraft:pink_terracotta
fill 334 124 464 337 124 464 minecraft:pink_terracotta
setblock 338 124 464 minecraft:red_nether_bricks
setblock 339 124 464 minecraft:pink_terracotta
setblock 345 124 504 minecraft:white_concrete
setblock 347 124 504 minecraft:pink_terracotta
setblock 348 124 464 minecraft:red_nether_bricks
setblock 348 124 465 minecraft:pink_terracotta
setblock 348 124 504 minecraft:red_nether_bricks
fill 349 124 464 349 127 464 minecraft:pink_terracotta
setblock 349 124 503 minecraft:red_nether_bricks
fill 349 124 504 349 127 504 minecraft:pink_terracotta
fill 350 124 503 350 127 503 minecraft:pink_terracotta
setblock 352 124 465 minecraft:red_nether_bricks
setblock 353 124 464 minecraft:red_nether_bricks
fill 353 124 465 353 125 465 minecraft:pink_terracotta
setblock 353 124 504 minecraft:red_nether_bricks
fill 354 124 464 354 127 464 minecraft:pink_terracotta
setblock 354 124 503 minecraft:red_nether_bricks
fill 354 124 504 354 127 504 minecraft:pink_terracotta
setblock 355 124 502 minecraft:red_nether_bricks
fill 355 124 503 355 127 503 minecraft:pink_terracotta
setblock 356 124 502 minecraft:pink_terracotta
setblock 358 124 504 minecraft:red_nether_bricks
fill 359 124 504 359 125 504 minecraft:pink_terracotta
setblock 368 124 494 minecraft:red_nether_bricks
fill 368 124 495 368 127 495 minecraft:pink_terracotta
setblock 368 124 498 minecraft:pink_terracotta
fill 369 124 471 369 124 472 minecraft:pink_terracotta
setblock 369 124 473 minecraft:red_nether_bricks
fill 369 124 474 369 127 474 minecraft:pink_terracotta
setblock 369 124 478 minecraft:red_nether_bricks
fill 369 124 479 369 127 479 minecraft:pink_terracotta
fill 369 124 486 369 124 487 minecraft:pink_terracotta
setblock 369 124 488 minecraft:red_nether_bricks
fill 369 124 489 369 127 489 minecraft:pink_terracotta
setblock 369 124 493 minecraft:red_nether_bricks
fill 369 124 494 369 127 494 minecraft:pink_terracotta
setblock 369 124 498 minecraft:red_nether_bricks
fill 369 124 499 369 127 499 minecraft:pink_terracotta
setblock 370 124 467 minecraft:red_nether_bricks
fill 370 124 468 370 125 468 minecraft:pink_terracotta
setblock 370 124 472 minecraft:red_nether_bricks
fill 370 124 473 370 127 473 minecraft:pink_terracotta
setblock 370 124 477 minecraft:red_nether_bricks
fill 370 124 478 370 127 478 minecraft:pink_terracotta
setblock 370 124 482 minecraft:red_nether_bricks
fill 370 124 483 370 127 483 minecraft:pink_terracotta
setblock 370 124 487 minecraft:red_nether_bricks
fill 370 124 488 370 127 488 minecraft:pink_terracotta
setblock 370 124 492 minecraft:red_nether_bricks
fill 370 124 493 370 127 493 minecraft:pink_terracotta
setblock 370 124 497 minecraft:red_nether_bricks
fill 370 124 498 370 127 498 minecraft:pink_terracotta
setblock 370 124 502 minecraft:red_nether_bricks
fill 370 124 503 370 127 503 minecraft:pink_terracotta
setblock 370 124 504 minecraft:white_concrete
setblock 330 125 465 minecraft:pink_terracotta
setblock 330 125 466 minecraft:red_nether_bricks
fill 330 125 467 330 125 470 minecraft:pink_terracotta
setblock 330 125 471 minecraft:red_nether_bricks
fill 330 125 472 330 128 472 minecraft:pink_terracotta
setblock 330 125 476 minecraft:red_nether_bricks
fill 330 125 477 330 128 477 minecraft:pink_terracotta
setblock 330 125 481 minecraft:red_nether_bricks
fill 330 125 482 330 128 482 minecraft:pink_terracotta
setblock 330 125 486 minecraft:red_nether_bricks
fill 330 125 487 330 128 487 minecraft:pink_terracotta
setblock 330 125 491 minecraft:red_nether_bricks
fill 330 125 492 330 128 492 minecraft:pink_terracotta
setblock 330 125 496 minecraft:red_nether_bricks
fill 330 125 497 330 128 497 minecraft:pink_terracotta
setblock 330 125 501 minecraft:red_nether_bricks
fill 330 125 502 330 128 502 minecraft:pink_terracotta
setblock 331 125 464 minecraft:pink_terracotta
setblock 331 125 470 minecraft:red_nether_bricks
fill 331 125 471 331 128 471 minecraft:pink_terracotta
setblock 331 125 475 minecraft:red_nether_bricks
fill 331 125 476 331 128 476 minecraft:pink_terracotta
setblock 331 125 480 minecraft:red_nether_bricks
fill 331 125 481 331 128 481 minecraft:pink_terracotta
setblock 331 125 485 minecraft:red_nether_bricks
setblock 331 125 486 minecraft:pink_terracotta
setblock 331 125 490 minecraft:red_nether_bricks
fill 331 125 491 331 126 491 minecraft:pink_terracotta
setblock 331 125 495 minecraft:red_nether_bricks
fill 331 125 496 331 128 496 minecraft:pink_terracotta
setblock 332 125 464 minecraft:red_nether_bricks
setblock 332 125 469 minecraft:red_nether_bricks
fill 332 125 470 332 127 470 minecraft:pink_terracotta
setblock 332 125 474 minecraft:red_nether_bricks
fill 332 125 475 332 128 475 minecraft:pink_terracotta
setblock 332 125 478 minecraft:pink_terracotta
setblock 332 125 479 minecraft:red_nether_bricks
fill 332 125 480 332 128 480 minecraft:pink_terracotta
setblock 332 125 494 minecraft:red_nether_bricks
setblock 332 125 495 minecraft:pink_terracotta
setblock 332 125 504 minecraft:white_concrete
fill 333 125 464 336 125 464 minecraft:pink_terracotta
setblock 333 125 473 minecraft:red_nether_bricks
fill 333 125 474 333 127 474 minecraft:pink_terracotta
setblock 333 125 478 minecraft:red_nether_bricks
setblock 337 125 464 minecraft:red_nether_bricks
setblock 343 125 464 minecraft:white_concrete
setblock 347 125 464 minecraft:red_nether_bricks
setblock 347 125 504 minecraft:red_nether_bricks
fill 348 125 464 348 128 464 minecraft:pink_terracotta
fill 348 125 504 348 128 504 minecraft:pink_terracotta
fill 349 125 503 349 128 503 minecraft:pink_terracotta
setblock 351 125 465 minecraft:red_nether_bricks
fill 351 125 502 351 127 502 minecraft:pink_terracotta
setblock 352 125 464 minecraft:red_nether_bricks
setblock 352 125 465 minecraft:pink_terracotta
setblock 352 125 504 minecraft:red_nether_bricks
fill 353 125 464 353 128 464 minecraft:pink_terracotta
setblock 353 125 503 minecraft:red_nether_bricks
fill 353 125 504 353 128 504 minecraft:pink_terracotta
setblock 354 125 502 minecraft:red_nether_bricks
fill 354 125 503 354 128 503 minecraft:pink_terracotta
fill 355 125 502 355 126 502 minecraft:pink_terracotta
setblock 357 125 504 minecraft:red_nether_bricks
fill 358 125 504 358 127 504 minecraft:pink_terracotta
setblock 368 125 464 minecraft:white_concrete
setblock 368 125 493 minecraft:red_nether_bricks
fill 368 125 494 368 127 494 minecraft:pink_terracotta
setblock 368 125 498 minecraft:red_nether_bricks
setblock 369 125 472 minecraft:red_nether_bricks
fill 369 125 473 369 128 473 minecraft:pink_terracotta
fill 369 125 475 369 125 476 minecraft:pink_terracotta
setblock 369 125 477 minecraft:red_nether_bricks
fill 369 125 478 369 128 478 minecraft:pink_terracotta
fill 369 125 480 369 125 481 minecraft:pink_terracotta
setblock 369 125 486 minecraft:pink_terracotta
setblock 369 125 487 minecraft:red_nether_bricks
fill 369 125 488 369 127 488 minecraft:pink_terracotta
setblock 369 125 492 minecraft:red_nether_bricks
fill 369 125 493 369 128 493 minecraft:pink_terracotta
setblock 369 125 497 minecraft:red_nether_bricks
fill 369 125 498 369 128 498 minecraft:pink_terracotta
setblock 370 125 471 minecraft:red_nether_bricks
fill 370 125 472 370 128 472 minecraft:pink_terracotta
setblock 370 125 476 minecraft:red_nether_bricks
fill 370 125 477 370 128 477 minecraft:pink_terracotta
setblock 370 125 481 minecraft:red_nether_bricks
fill 370 125 482 370 128 482 minecraft:pink_terracotta
setblock 370 125 486 minecraft:red_nether_bricks
fill 370 125 487 370 128 487 minecraft:pink_terracotta
setblock 370 125 491 minecraft:red_nether_bricks
fill 370 125 492 370 128 492 minecraft:pink_terracotta
setblock 370 125 496 minecraft:red_nether_bricks
fill 370 125 497 370 128 497 minecraft:pink_terracotta
setblock 370 125 501 minecraft:red_nether_bricks
fill 370 125 502 370 128 502 minecraft:pink_terracotta
setblock 330 126 465 minecraft:red_nether_bricks
fill 330 126 466 330 126 469 minecraft:pink_terracotta
setblock 330 126 470 minecraft:red_nether_bricks
fill 330 126 471 330 129 471 minecraft:pink_terracotta
setblock 330 126 475 minecraft:red_nether_bricks
fill 330 126 476 330 129 476 minecraft:pink_terracotta
setblock 330 126 480 minecraft:red_nether_bricks
fill 330 126 481 330 129 481 minecraft:pink_terracotta
setblock 330 126 485 minecraft:red_nether_bricks
fill 330 126 486 330 129 486 minecraft:pink_terracotta
setblock 330 126 490 minecraft:red_nether_bricks
fill 330 126 491 330 129 491 minecraft:pink_terracotta
setblock 330 126 495 minecraft:red_nether_bricks
fill 330 126 496 330 129 496 minecraft:pink_terracotta
setblock 330 126 499 minecraft:pink_terracotta
setblock 330 126 500 minecraft:red_nether_bricks
fill 330 126 501 330 129 501 minecraft:pink_terracotta
setblock 331 126 464 minecraft:red_nether_bricks
setblock 331 126 469 minecraft:red_nether_bricks
fill 331 126 470 331 129 470 minecraft:pink_terracotta
setblock 331 126 474 minecraft:red_nether_bricks
fill 331 126 475 331 129 475 minecraft:pink_terracotta
setblock 331 126 479 minecraft:red_nether_bricks
fill 331 126 480 331 129 480 minecraft:pink_terracotta
setblock 331 126 484 minecraft:red_nether_bricks
setblock 331 126 490 minecraft:pink_terracotta
setblock 331 126 494 minecraft:red_nether_bricks
fill 331 126 495 331 128 495 minecraft:pink_terracotta
setblock 331 126 499 minecraft:red_nether_bricks
fill 332 126 464 335 126 464 minecraft:pink_terracotta
setblock 332 126 473 minecraft:red_nether_bricks
fill 332 126 474 332 129 474 minecraft:pink_terracotta
setblock 332 126 478 minecraft:red_nether_bricks
fill 332 126 479 332 129 479 minecraft:pink_terracotta
setblock 333 126 472 minecraft:red_nether_bricks
fill 333 126 473 333 127 473 minecraft:pink_terracotta
setblock 333 126 477 minecraft:red_nether_bricks
setblock 333 126 478 minecraft:pink_terracotta
setblock 337 126 464 minecraft:white_concrete
setblock 338 126 504 minecraft:white_concrete
setblock 346 126 464 minecraft:red_nether_bricks
setblock 346 126 504 minecraft:red_nether_bricks
fill 347 126 464 347 129 464 minecraft:pink_terracotta
fill 347 126 504 347 129 504 minecraft:pink_terracotta
fill 348 126 503 348 129 503 minecraft:pink_terracotta
fill 350 126 502 350 128 502 minecraft:pink_terracotta
setblock 351 126 464 minecraft:red_nether_bricks
setblock 351 126 465 minecraft:pink_terracotta
setblock 351 126 504 minecraft:red_nether_bricks
fill 352 126 464 352 129 464 minecraft:pink_terracotta
setblock 352 126 503 minecraft:red_nether_bricks
fill 352 126 504 352 129 504 minecraft:pink_terracotta
setblock 353 126 502 minecraft:red_nether_bricks
fill 353 126 503 353 129 503 minecraft:pink_terracotta
fill 354 126 502 354 129 502 minecraft:pink_terracotta
setblock 356 126 504 minecraft:red_nether_bricks
fill 357 126 504 357 129 504 minecraft:pink_terracotta
setblock 362 126 464 minecraft:white_concrete
fill 363 126 504 363 127 504 minecraft:white_concrete
setblock 368 126 492 minecraft:red_nether_bricks
setblock 368 126 493 minecraft:pink_terracotta
setblock 368 126 497 minecraft:red_nether_bricks
fill 368 126 498 368 129 498 minecraft:pink_terracotta
fill 369 126 472 369 127 472 minecraft:pink_terracotta
setblock 369 126 475 minecraft:pink_terracotta
setblock 369 126 476 minecraft:red_nether_bricks
fill 369 126 477 369 129 477 minecraft:pink_terracotta
setblock 369 126 480 minecraft:pink_terracotta
setblock 369 126 481 minecraft:red_nether_bricks
fill 369 126 482 369 129 482 minecraft:pink_terracotta
setblock 369 126 487 minecraft:pink_terracotta
setblock 369 126 491 minecraft:red_nether_bricks
fill 369 126 492 369 129 492 minecraft:pink_terracotta
setblock 369 126 496 minecraft:red_nether_bricks
fill 369 126 497 369 129 497 minecraft:pink_terracotta
setblock 369 126 501 minecraft:red_nether_bricks
setblock 370 126 470 minecraft:red_nether_bricks
fill 370 126 471 370 129 471 minecraft:pink_terracotta
setblock 370 126 475 minecraft:red_nether_bricks
fill 370 126 476 370 129 476 minecraft:pink_terracotta
setblock 370 126 480 minecraft:red_nether_bricks
fill 370 126 481 370 129 481 minecraft:pink_terracotta
setblock 370 126 485 minecraft:red_nether_bricks
fill 370 126 486 370 129 486 minecraft:pink_terracotta
setblock 370 126 490 minecraft:red_nether_bricks
fill 370 126 491 370 129 491 minecraft:pink_terracotta
setblock 370 126 495 minecraft:red_nether_bricks
fill 370 126 496 370 129 496 minecraft:pink_terracotta
setblock 370 126 500 minecraft:red_nether_bricks
fill 370 126 501 370 129 501 minecraft:pink_terracotta
fill 330 127 466 330 127 468 minecraft:pink_terracotta
setblock 330 127 469 minecraft:red_nether_bricks
fill 330 127 470 330 130 470 minecraft:pink_terracotta
setblock 330 127 474 minecraft:red_nether_bricks
fill 330 127 475 330 130 475 minecraft:pink_terracotta
setblock 330 127 479 minecraft:red_nether_bricks
fill 330 127 480 330 130 480 minecraft:pink_terracotta
setblock 330 127 484 minecraft:red_nether_bricks
fill 330 127 485 330 130 485 minecraft:pink_terracotta
setblock 330 127 489 minecraft:red_nether_bricks
fill 330 127 490 330 130 490 minecraft:pink_terracotta
setblock 330 127 494 minecraft:red_nether_bricks
fill 330 127 495 330 130 495 minecraft:pink_terracotta
setblock 330 127 499 minecraft:red_nether_bricks
fill 330 127 500 330 130 500 minecraft:pink_terracotta
fill 331 127 464 334 127 464 minecraft:pink_terracotta
setblock 331 127 468 minecraft:red_nether_bricks
fill 331 127 469 331 130 469 minecraft:pink_terracotta
setblock 331 127 473 minecraft:red_nether_bricks
fill 331 127 474 331 130 474 minecraft:pink_terracotta
setblock 331 127 478 minecraft:red_nether_bricks
fill 331 127 479 331 130 479 minecraft:pink_terracotta
setblock 331 127 483 minecraft:red_nether_bricks
fill 331 127 484 331 130 484 minecraft:pink_terracotta
setblock 331 127 493 minecraft:red_nether_bricks
setblock 331 127 494 minecraft:pink_terracotta
setblock 331 127 498 minecraft:red_nether_bricks
fill 331 127 499 331 130 499 minecraft:pink_terracotta
setblock 332 127 466 minecraft:light[level=12]
setblock 332 127 472 minecraft:red_nether_bricks
fill 332 127 473 332 130 473 minecraft:pink_terracotta
setblock 332 127 477 minecraft:red_nether_bricks
fill 332 127 478 332 130 478 minecraft:pink_terracotta
setblock 332 127 482 minecraft:light[level=12]
setblock 332 127 490 minecraft:light[level=12]
setblock 332 127 498 minecraft:light[level=12]
setblock 333 127 476 minecraft:red_nether_bricks
setblock 333 127 477 minecraft:pink_terracotta
setblock 340 127 466 minecraft:light[level=12]
setblock 340 127 474 minecraft:light[level=12]
setblock 340 127 482 minecraft:light[level=12]
setblock 340 127 490 minecraft:light[level=12]
setblock 340 127 498 minecraft:light[level=12]
setblock 344 127 504 minecraft:white_concrete
fill 346 127 464 346 130 464 minecraft:pink_terracotta
fill 346 127 504 346 130 504 minecraft:pink_terracotta
setblock 348 127 466 minecraft:light[level=12]
setblock 348 127 474 minecraft:light[level=12]
setblock 348 127 482 minecraft:light[level=12]
setblock 348 127 490 minecraft:light[level=12]
setblock 348 127 498 minecraft:light[level=12]
setblock 350 127 464 minecraft:red_nether_bricks
setblock 350 127 504 minecraft:red_nether_bricks
fill 351 127 464 351 130 464 minecraft:pink_terracotta
setblock 351 127 503 minecraft:red_nether_bricks
fill 351 127 504 351 130 504 minecraft:pink_terracotta
setblock 352 127 502 minecraft:red_nether_bricks
fill 352 127 503 352 130 503 minecraft:pink_terracotta
fill 353 127 502 353 130 502 minecraft:pink_terracotta
setblock 355 127 504 minecraft:red_nether_bricks
setblock 356 127 464 minecraft:white_concrete
setblock 356 127 466 minecraft:light[level=12]
setblock 356 127 474 minecraft:light[level=12]
setblock 356 127 482 minecraft:light[level=12]
setblock 356 127 490 minecraft:light[level=12]
setblock 356 127 498 minecraft:light[level=12]
setblock 356 127 503 minecraft:red_nether_bricks
fill 356 127 504 356 130 504 minecraft:pink_terracotta
setblock 364 127 466 minecraft:light[level=12]
setblock 364 127 474 minecraft:light[level=12]
setblock 364 127 482 minecraft:light[level=12]
setblock 364 127 490 minecraft:light[level=12]
setblock 364 127 498 minecraft:light[level=12]
setblock 368 127 496 minecraft:red_nether_bricks
fill 368 127 497 368 130 497 minecraft:pink_terracotta
setblock 369 127 475 minecraft:red_nether_bricks
fill 369 127 476 369 130 476 minecraft:pink_terracotta
setblock 369 127 480 minecraft:red_nether_bricks
fill 369 127 481 369 130 481 minecraft:pink_terracotta
fill 369 127 483 369 127 484 minecraft:pink_terracotta
setblock 369 127 490 minecraft:red_nether_bricks
fill 369 127 491 369 130 491 minecraft:pink_terracotta
setblock 369 127 495 minecraft:red_nether_bricks
fill 369 127 496 369 130 496 minecraft:pink_terracotta
setblock 369 127 500 minecraft:red_nether_bricks
fill 369 127 501 369 130 501 minecraft:pink_terracotta
setblock 369 127 504 minecraft:white_concrete
setblock 370 127 469 minecraft:red_nether_bricks
fill 370 127 470 370 130 470 minecraft:pink_terracotta
setblock 370 127 474 minecraft:red_nether_bricks
fill 370 127 475 370 130 475 minecraft:pink_terracotta
setblock 370 127 479 minecraft:red_nether_bricks
fill 370 127 480 370 130 480 minecraft:pink_terracotta
setblock 370 127 484 minecraft:red_nether_bricks
fill 370 127 485 370 130 485 minecraft:pink_terracotta
setblock 370 127 489 minecraft:red_nether_bricks
fill 370 127 490 370 130 490 minecraft:pink_terracotta
setblock 370 127 494 minecraft:red_nether_bricks
fill 370 127 495 370 130 495 minecraft:pink_terracotta
setblock 370 127 499 minecraft:red_nether_bricks
fill 370 127 500 370 130 500 minecraft:pink_terracotta
fill 330 128 466 330 128 467 minecraft:pink_terracotta
setblock 330 128 468 minecraft:red_nether_bricks
fill 330 128 469 330 131 469 minecraft:pink_terracotta
setblock 330 128 473 minecraft:red_nether_bricks
fill 330 128 474 330 131 474 minecraft:pink_terracotta
setblock 330 128 478 minecraft:red_nether_bricks
fill 330 128 479 330 131 479 minecraft:pink_terracotta
setblock 330 128 483 minecraft:red_nether_bricks
fill 330 128 484 330 131 484 minecraft:pink_terracotta
setblock 330 128 488 minecraft:red_nether_bricks
fill 330 128 489 330 131 489 minecraft:pink_terracotta
setblock 330 128 493 minecraft:red_nether_bricks
fill 330 128 494 330 131 494 minecraft:pink_terracotta
setblock 330 128 498 minecraft:red_nether_bricks
fill 330 128 499 330 131 499 minecraft:pink_terracotta
setblock 330 128 503 minecraft:red_nether_bricks
fill 331 128 464 333 128 464 minecraft:pink_terracotta
setblock 331 128 472 minecraft:red_nether_bricks
fill 331 128 473 331 131 473 minecraft:pink_terracotta
setblock 331 128 477 minecraft:red_nether_bricks
fill 331 128 478 331 131 478 minecraft:pink_terracotta
setblock 331 128 482 minecraft:red_nether_bricks
fill 331 128 483 331 131 483 minecraft:pink_terracotta
setblock 331 128 497 minecraft:red_nether_bricks
fill 331 128 498 331 131 498 minecraft:pink_terracotta
setblock 331 128 504 minecraft:white_concrete
setblock 332 128 471 minecraft:red_nether_bricks
fill 332 128 472 332 129 472 minecraft:pink_terracotta
setblock 332 128 476 minecraft:red_nether_bricks
fill 332 128 477 332 131 477 minecraft:pink_terracotta
setblock 332 128 481 minecraft:red_nether_bricks
setblock 333 128 475 minecraft:red_nether_bricks
setblock 333 128 476 minecraft:pink_terracotta
fill 345 128 504 345 131 504 minecraft:pink_terracotta
fill 347 128 503 347 130 503 minecraft:pink_terracotta
setblock 349 128 464 minecraft:red_nether_bricks
fill 349 128 502 349 129 502 minecraft:pink_terracotta
setblock 349 128 504 minecraft:red_nether_bricks
fill 350 128 464 350 131 464 minecraft:pink_terracotta
setblock 350 128 503 minecraft:red_nether_bricks
fill 350 128 504 350 131 504 minecraft:pink_terracotta
setblock 351 128 502 minecraft:red_nether_bricks
fill 351 128 503 351 131 503 minecraft:pink_terracotta
fill 352 128 502 352 131 502 minecraft:pink_terracotta
setblock 354 128 504 minecraft:red_nether_bricks
setblock 355 128 503 minecraft:red_nether_bricks
fill 355 128 504 355 131 504 minecraft:pink_terracotta
fill 356 128 503 356 131 503 minecraft:pink_terracotta
setblock 368 128 495 minecraft:red_nether_bricks
fill 368 128 496 368 131 496 minecraft:pink_terracotta
setblock 369 128 464 minecraft:white_concrete
setblock 369 128 474 minecraft:red_nether_bricks
fill 369 128 475 369 131 475 minecraft:pink_terracotta
setblock 369 128 479 minecraft:red_nether_bricks
fill 369 128 480 369 131 480 minecraft:pink_terracotta
setblock 369 128 483 minecraft:pink_terracotta
setblock 369 128 484 minecraft:red_nether_bricks
fill 369 128 485 369 131 485 minecraft:pink_terracotta
setblock 369 128 489 minecraft:red_nether_bricks
fill 369 128 490 369 131 490 minecraft:pink_terracotta
setblock 369 128 494 minecraft:red_nether_bricks
fill 369 128 495 369 131 495 minecraft:pink_terracotta
setblock 369 128 499 minecraft:red_nether_bricks
fill 369 128 500 369 131 500 minecraft:pink_terracotta
setblock 370 128 473 minecraft:red_nether_bricks
fill 370 128 474 370 131 474 minecraft:pink_terracotta
setblock 370 128 478 minecraft:red_nether_bricks
fill 370 128 479 370 131 479 minecraft:pink_terracotta
setblock 370 128 483 minecraft:red_nether_bricks
fill 370 128 484 370 131 484 minecraft:pink_terracotta
setblock 370 128 488 minecraft:red_nether_bricks
fill 370 128 489 370 131 489 minecraft:pink_terracotta
setblock 370 128 493 minecraft:red_nether_bricks
fill 370 128 494 370 131 494 minecraft:pink_terracotta
setblock 370 128 498 minecraft:red_nether_bricks
fill 370 128 499 370 131 499 minecraft:pink_terracotta
setblock 370 128 503 minecraft:red_nether_bricks
fill 370 128 504 370 131 504 minecraft:pink_terracotta
fill 330 129 464 330 129 466 minecraft:pink_terracotta
setblock 330 129 467 minecraft:red_nether_bricks
fill 330 129 468 330 132 468 minecraft:pink_terracotta
setblock 330 129 472 minecraft:red_nether_bricks
fill 330 129 473 330 132 473 minecraft:pink_terracotta
setblock 330 129 477 minecraft:red_nether_bricks
fill 330 129 478 330 132 478 minecraft:pink_terracotta
setblock 330 129 482 minecraft:red_nether_bricks
fill 330 129 483 330 132 483 minecraft:pink_terracotta
setblock 330 129 487 minecraft:red_nether_bricks
fill 330 129 488 330 132 488 minecraft:pink_terracotta
setblock 330 129 492 minecraft:red_nether_bricks
fill 330 129 493 330 132 493 minecraft:pink_terracotta
setblock 330 129 497 minecraft:red_nether_bricks
fill 330 129 498 330 132 498 minecraft:pink_terracotta
setblock 330 129 502 minecraft:red_nether_bricks
fill 330 129 503 330 131 504 minecraft:pink_terracotta
fill 331 129 464 332 129 464 minecraft:pink_terracotta
setblock 331 129 471 minecraft:red_nether_bricks
fill 331 129 472 331 132 472 minecraft:pink_terracotta
setblock 331 129 476 minecraft:red_nether_bricks
fill 331 129 477 331 132 477 minecraft:pink_terracotta
setblock 331 129 481 minecraft:red_nether_bricks
fill 331 129 482 331 132 482 minecraft:pink_terracotta
setblock 331 129 497 minecraft:pink_terracotta
setblock 331 129 500 minecraft:pink_terracotta
fill 331 129 504 332 129 504 minecraft:pink_terracotta
setblock 332 129 475 minecraft:red_nether_bricks
fill 332 129 476 332 132 476 minecraft:pink_terracotta
setblock 332 129 480 minecraft:red_nether_bricks
fill 332 129 481 332 132 481 minecraft:pink_terracotta
setblock 333 129 464 minecraft:red_nether_bricks
setblock 337 129 504 minecraft:white_concrete
setblock 344 129 464 minecraft:white_concrete
fill 344 129 504 344 132 504 minecraft:pink_terracotta
fill 345 129 464 345 131 464 minecraft:pink_terracotta
fill 346 129 503 346 131 503 minecraft:pink_terracotta
setblock 348 129 464 minecraft:red_nether_bricks
fill 348 129 502 348 130 502 minecraft:pink_terracotta
setblock 348 129 504 minecraft:red_nether_bricks
fill 349 129 464 349 132 464 minecraft:pink_terracotta
setblock 349 129 503 minecraft:red_nether_bricks
fill 349 129 504 349 132 504 minecraft:pink_terracotta
setblock 350 129 502 minecraft:red_nether_bricks
fill 350 129 503 350 132 503 minecraft:pink_terracotta
fill 351 129 502 351 132 502 minecraft:pink_terracotta
setblock 353 129 464 minecraft:red_nether_bricks
setblock 353 129 504 minecraft:red_nether_bricks
setblock 354 129 503 minecraft:red_nether_bricks
fill 354 129 504 354 132 504 minecraft:pink_terracotta
fill 355 129 503 355 132 503 minecraft:pink_terracotta
setblock 363 129 464 minecraft:white_concrete
fill 368 129 476 368 129 478 minecraft:pink_terracotta
setblock 368 129 479 minecraft:red_nether_bricks
fill 368 129 480 368 132 480 minecraft:pink_terracotta
setblock 368 129 504 minecraft:red_nether_bricks
setblock 369 129 473 minecraft:red_nether_bricks
fill 369 129 474 369 132 474 minecraft:pink_terracotta
setblock 369 129 478 minecraft:red_nether_bricks
fill 369 129 479 369 132 479 minecraft:pink_terracotta
setblock 369 129 483 minecraft:red_nether_bricks
fill 369 129 484 369 132 484 minecraft:pink_terracotta
fill 369 129 486 369 129 487 minecraft:pink_terracotta
setblock 369 129 488 minecraft:red_nether_bricks
fill 369 129 489 369 132 489 minecraft:pink_terracotta
setblock 369 129 493 minecraft:red_nether_bricks
fill 369 129 494 369 132 494 minecraft:pink_terracotta
setblock 369 129 498 minecraft:red_nether_bricks
fill 369 129 499 369 132 499 minecraft:pink_terracotta
setblock 369 129 502 minecraft:pink_terracotta
fill 369 129 504 369 132 504 minecraft:pink_terracotta
setblock 370 129 472 minecraft:red_nether_bricks
fill 370 129 473 370 132 473 minecraft:pink_terracotta
setblock 370 129 477 minecraft:red_nether_bricks
fill 370 129 478 370 132 478 minecraft:pink_terracotta
setblock 370 129 482 minecraft:red_nether_bricks
fill 370 129 483 370 132 483 minecraft:pink_terracotta
setblock 370 129 487 minecraft:red_nether_bricks
fill 370 129 488 370 132 488 minecraft:pink_terracotta
setblock 370 129 492 minecraft:red_nether_bricks
fill 370 129 493 370 132 493 minecraft:pink_terracotta
setblock 370 129 497 minecraft:red_nether_bricks
fill 370 129 498 370 132 498 minecraft:pink_terracotta
setblock 370 129 502 minecraft:red_nether_bricks
fill 370 129 503 370 132 503 minecraft:pink_terracotta
fill 330 130 464 330 130 465 minecraft:pink_terracotta
setblock 330 130 466 minecraft:red_nether_bricks
fill 330 130 467 330 133 467 minecraft:pink_terracotta
setblock 330 130 471 minecraft:red_nether_bricks
fill 330 130 472 330 133 472 minecraft:pink_terracotta
setblock 330 130 476 minecraft:red_nether_bricks
fill 330 130 477 330 133 477 minecraft:pink_terracotta
setblock 330 130 481 minecraft:red_nether_bricks
fill 330 130 482 330 133 482 minecraft:pink_terracotta
setblock 330 130 486 minecraft:red_nether_bricks
fill 330 130 487 330 133 487 minecraft:pink_terracotta
setblock 330 130 491 minecraft:red_nether_bricks
fill 330 130 492 330 131 492 minecraft:pink_terracotta
setblock 330 130 496 minecraft:red_nether_bricks
fill 330 130 497 330 133 497 minecraft:pink_terracotta
setblock 330 130 501 minecraft:red_nether_bricks
fill 330 130 502 330 133 502 minecraft:pink_terracotta
setblock 331 130 464 minecraft:pink_terracotta
setblock 331 130 470 minecraft:red_nether_bricks
fill 331 130 471 331 133 471 minecraft:pink_terracotta
setblock 331 130 475 minecraft:red_nether_bricks
fill 331 130 476 331 133 476 minecraft:pink_terracotta
setblock 331 130 480 minecraft:red_nether_bricks
fill 331 130 481 331 133 481 minecraft:pink_terracotta
setblock 331 130 500 minecraft:red_nether_bricks
fill 331 130 501 331 133 501 minecraft:pink_terracotta
setblock 331 130 504 minecraft:pink_terracotta
setblock 332 130 464 minecraft:red_nether_bricks
setblock 332 130 474 minecraft:red_nether_bricks
fill 332 130 475 332 133 475 minecraft:pink_terracotta
setblock 332 130 479 minecraft:red_nether_bricks
fill 332 130 480 332 133 480 minecraft:pink_terracotta
setblock 332 130 504 minecraft:red_nether_bricks
fill 333 130 464 334 132 464 minecraft:pink_terracotta
fill 333 130 504 333 133 504 minecraft:pink_terracotta
setblock 338 130 464 minecraft:white_concrete
fill 339 130 488 339 131 488 minecraft:red_concrete
setblock 342 130 504 minecraft:red_nether_bricks
fill 343 130 504 343 133 504 minecraft:pink_terracotta
fill 344 130 464 344 132 464 minecraft:pink_terracotta
fill 344 130 503 345 132 503 minecraft:pink_terracotta
fill 346 130 502 347 131 502 minecraft:pink_terracotta
setblock 347 130 464 minecraft:red_nether_bricks
setblock 347 130 504 minecraft:red_nether_bricks
fill 348 130 464 348 133 464 minecraft:pink_terracotta
setblock 348 130 503 minecraft:red_nether_bricks
fill 348 130 504 348 133 504 minecraft:pink_terracotta
setblock 349 130 501 minecraft:pink_terracotta
setblock 349 130 502 minecraft:red_nether_bricks
fill 349 130 503 349 133 503 minecraft:pink_terracotta
setblock 350 130 501 minecraft:red_nether_bricks
fill 350 130 502 350 133 502 minecraft:pink_terracotta
fill 351 130 501 352 132 501 minecraft:pink_terracotta
setblock 352 130 464 minecraft:red_nether_bricks
setblock 352 130 504 minecraft:red_nether_bricks
fill 353 130 464 353 133 464 minecraft:pink_terracotta
setblock 353 130 503 minecraft:red_nether_bricks
fill 353 130 504 353 133 504 minecraft:pink_terracotta
setblock 354 130 502 minecraft:red_nether_bricks
fill 354 130 503 354 133 503 minecraft:pink_terracotta
setblock 357 130 464 minecraft:white_concrete
setblock 357 130 504 minecraft:red_nether_bricks
fill 358 130 504 358 133 504 minecraft:pink_terracotta
setblock 362 130 504 minecraft:white_concrete
fill 364 130 503 364 131 503 minecraft:white_concrete
setblock 366 130 504 minecraft:pink_terracotta
setblock 367 130 504 minecraft:red_nether_bricks
fill 368 130 476 368 130 477 minecraft:pink_terracotta
setblock 368 130 478 minecraft:red_nether_bricks
fill 368 130 479 368 133 479 minecraft:pink_terracotta
fill 368 130 481 368 130 482 minecraft:pink_terracotta
setblock 368 130 483 minecraft:red_nether_bricks
setblock 368 130 498 minecraft:red_nether_bricks
fill 368 130 499 368 133 499 minecraft:pink_terracotta
fill 368 130 504 368 133 504 minecraft:pink_terracotta
fill 369 130 473 369 133 473 minecraft:pink_terracotta
setblock 369 130 477 minecraft:red_nether_bricks
fill 369 130 478 369 133 478 minecraft:pink_terracotta
setblock 369 130 482 minecraft:red_nether_bricks
fill 369 130 483 369 133 483 minecraft:pink_terracotta
setblock 369 130 486 minecraft:pink_terracotta
setblock 369 130 487 minecraft:red_nether_bricks
fill 369 130 488 369 133 488 minecraft:pink_terracotta
setblock 369 130 492 minecraft:red_nether_bricks
fill 369 130 493 369 133 493 minecraft:pink_terracotta
setblock 369 130 497 minecraft:red_nether_bricks
fill 369 130 498 369 133 498 minecraft:pink_terracotta
setblock 369 130 502 minecraft:red_nether_bricks
setblock 370 130 471 minecraft:red_nether_bricks
fill 370 130 472 370 133 472 minecraft:pink_terracotta
setblock 370 130 476 minecraft:red_nether_bricks
fill 370 130 477 370 133 477 minecraft:pink_terracotta
setblock 370 130 481 minecraft:red_nether_bricks
fill 370 130 482 370 133 482 minecraft:pink_terracotta
setblock 370 130 486 minecraft:red_nether_bricks
fill 370 130 487 370 133 487 minecraft:pink_terracotta
setblock 370 130 491 minecraft:red_nether_bricks
fill 370 130 492 370 133 492 minecraft:pink_terracotta
setblock 370 130 496 minecraft:red_nether_bricks
fill 370 130 497 370 133 497 minecraft:pink_terracotta
setblock 370 130 501 minecraft:red_nether_bricks
fill 370 130 502 370 133 502 minecraft:pink_terracotta
setblock 330 131 464 minecraft:pink_terracotta
setblock 330 131 465 minecraft:red_nether_bricks
fill 330 131 466 330 134 466 minecraft:pink_terracotta
setblock 330 131 470 minecraft:red_nether_bricks
fill 330 131 471 330 134 471 minecraft:pink_terracotta
setblock 330 131 475 minecraft:red_nether_bricks
fill 330 131 476 330 134 476 minecraft:pink_terracotta
setblock 330 131 480 minecraft:red_nether_bricks
fill 330 131 481 330 134 481 minecraft:pink_terracotta
setblock 330 131 485 minecraft:red_nether_bricks
fill 330 131 486 330 134 486 minecraft:pink_terracotta
setblock 330 131 495 minecraft:red_nether_bricks
fill 330 131 496 330 134 496 minecraft:pink_terracotta
setblock 330 131 500 minecraft:red_nether_bricks
fill 330 131 501 330 134 501 minecraft:pink_terracotta
setblock 331 131 464 minecraft:red_nether_bricks
setblock 331 131 469 minecraft:red_nether_bricks
fill 331 131 470 331 134 470 minecraft:pink_terracotta
setblock 331 131 474 minecraft:red_nether_bricks
fill 331 131 475 331 134 475 minecraft:pink_terracotta
setblock 331 131 479 minecraft:red_nether_bricks
fill 331 131 480 331 134 480 minecraft:pink_terracotta
setblock 331 131 484 minecraft:red_nether_bricks
fill 331 131 485 331 134 485 minecraft:pink_terracotta
setblock 331 131 499 minecraft:red_nether_bricks
fill 331 131 500 331 134 500 minecraft:pink_terracotta
fill 331 131 502 331 132 502 minecraft:pink_terracotta
setblock 331 131 504 minecraft:red_nether_bricks
fill 332 131 464 332 134 464 minecraft:pink_terracotta
setblock 332 131 473 minecraft:red_nether_bricks
fill 332 131 474 332 133 474 minecraft:pink_terracotta
setblock 332 131 478 minecraft:red_nether_bricks
fill 332 131 479 332 134 479 minecraft:pink_terracotta
fill 332 131 504 332 134 504 minecraft:pink_terracotta
fill 334 131 504 335 131 504 minecraft:pink_terracotta
setblock 335 131 464 minecraft:pink_terracotta
fill 339 131 489 341 132 489 minecraft:red_concrete
fill 340 131 488 340 132 488 minecraft:red_concrete
fill 340 131 490 340 132 490 minecraft:red_concrete
setblock 340 131 504 minecraft:pink_terracotta
setblock 341 131 504 minecraft:red_nether_bricks
fill 342 131 464 343 133 464 minecraft:pink_terracotta
fill 342 131 504 342 134 504 minecraft:pink_terracotta
fill 343 131 503 343 134 503 minecraft:pink_terracotta
fill 345 131 502 345 133 502 minecraft:pink_terracotta
setblock 346 131 464 minecraft:red_nether_bricks
setblock 346 131 504 minecraft:red_nether_bricks
fill 347 131 464 347 133 465 minecraft:pink_terracotta
fill 347 131 501 348 131 501 minecraft:pink_terracotta
setblock 347 131 503 minecraft:red_nether_bricks
fill 347 131 504 347 134 504 minecraft:pink_terracotta
fill 348 131 465 349 131 465 minecraft:pink_terracotta
setblock 348 131 502 minecraft:red_nether_bricks
fill 348 131 503 348 134 503 minecraft:pink_terracotta
setblock 349 131 501 minecraft:red_nether_bricks
fill 349 131 502 349 134 502 minecraft:pink_terracotta
fill 350 131 501 350 134 501 minecraft:pink_terracotta
setblock 351 131 464 minecraft:red_nether_bricks
setblock 351 131 504 minecraft:red_nether_bricks
fill 352 131 464 352 134 464 minecraft:pink_terracotta
setblock 352 131 503 minecraft:red_nether_bricks
fill 352 131 504 352 134 504 minecraft:pink_terracotta
setblock 353 131 502 minecraft:red_nether_bricks
fill 353 131 503 353 134 503 minecraft:pink_terracotta
fill 354 131 502 354 134 502 minecraft:pink_terracotta
setblock 356 131 504 minecraft:red_nether_bricks
fill 357 131 504 357 134 504 minecraft:pink_terracotta
fill 359 131 504 359 132 504 minecraft:pink_terracotta
fill 362 131 503 363 132 503 minecraft:white_concrete
fill 363 131 502 365 132 502 minecraft:white_concrete
fill 363 131 504 365 131 504 minecraft:pink_terracotta
fill 364 131 501 364 134 501 minecraft:white_concrete
setblock 365 131 503 minecraft:white_concrete
setblock 366 131 503 minecraft:pink_terracotta
setblock 366 131 504 minecraft:red_nether_bricks
setblock 367 131 503 minecraft:red_nether_bricks
fill 367 131 504 367 134 504 minecraft:pink_terracotta
fill 368 131 475 368 131 476 minecraft:pink_terracotta
setblock 368 131 477 minecraft:red_nether_bricks
fill 368 131 478 368 134 478 minecraft:pink_terracotta
setblock 368 131 481 minecraft:pink_terracotta
setblock 368 131 482 minecraft:red_nether_bricks
fill 368 131 483 368 133 484 minecraft:pink_terracotta
setblock 368 131 497 minecraft:red_nether_bricks
fill 368 131 498 368 134 498 minecraft:pink_terracotta
fill 368 131 500 368 132 500 minecraft:pink_terracotta
fill 368 131 503 369 133 503 minecraft:pink_terracotta
fill 369 131 472 369 134 472 minecraft:pink_terracotta
setblock 369 131 476 minecraft:red_nether_bricks
fill 369 131 477 369 134 477 minecraft:pink_terracotta
setblock 369 131 481 minecraft:red_nether_bricks
fill 369 131 482 369 134 482 minecraft:pink_terracotta
setblock 369 131 486 minecraft:red_nether_bricks
fill 369 131 487 369 134 487 minecraft:pink_terracotta
setblock 369 131 491 minecraft:red_nether_bricks
fill 369 131 492 369 134 492 minecraft:pink_terracotta
setblock 369 131 496 minecraft:red_nether_bricks
fill 369 131 497 369 134 497 minecraft:pink_terracotta
setblock 369 131 501 minecraft:red_nether_bricks
fill 369 131 502 369 134 502 minecraft:pink_terracotta
setblock 370 131 469 minecraft:pink_terracotta
setblock 370 131 470 minecraft:red_nether_bricks
fill 370 131 471 370 134 471 minecraft:pink_terracotta
setblock 370 131 475 minecraft:red_nether_bricks
fill 370 131 476 370 134 476 minecraft:pink_terracotta
setblock 370 131 480 minecraft:red_nether_bricks
fill 370 131 481 370 134 481 minecraft:pink_terracotta
setblock 370 131 485 minecraft:red_nether_bricks
fill 370 131 486 370 134 486 minecraft:pink_terracotta
setblock 370 131 490 minecraft:red_nether_bricks
fill 370 131 491 370 134 491 minecraft:pink_terracotta
setblock 370 131 495 minecraft:red_nether_bricks
fill 370 131 496 370 134 496 minecraft:pink_terracotta
setblock 370 131 500 minecraft:red_nether_bricks
fill 370 131 501 370 134 501 minecraft:pink_terracotta
setblock 330 132 464 minecraft:red_nether_bricks
fill 330 132 465 331 134 465 minecraft:pink_terracotta
setblock 330 132 469 minecraft:red_nether_bricks
fill 330 132 470 330 135 470 minecraft:pink_terracotta
setblock 330 132 474 minecraft:red_nether_bricks
fill 330 132 475 330 135 475 minecraft:pink_terracotta
setblock 330 132 479 minecraft:red_nether_bricks
fill 330 132 480 330 135 480 minecraft:pink_terracotta
setblock 330 132 484 minecraft:red_nether_bricks
fill 330 132 485 330 135 485 minecraft:pink_terracotta
setblock 330 132 489 minecraft:red_nether_bricks
setblock 330 132 494 minecraft:red_nether_bricks
fill 330 132 495 330 134 495 minecraft:pink_terracotta
setblock 330 132 499 minecraft:red_nether_bricks
fill 330 132 500 330 135 500 minecraft:pink_terracotta
setblock 330 132 503 minecraft:pink_terracotta
setblock 330 132 504 minecraft:red_nether_bricks
fill 331 132 464 331 135 464 minecraft:pink_terracotta
fill 331 132 466 331 133 466 minecraft:pink_terracotta
setblock 331 132 468 minecraft:red_nether_bricks
fill 331 132 469 331 135 469 minecraft:pink_terracotta
setblock 331 132 473 minecraft:red_nether_bricks
fill 331 132 474 331 135 474 minecraft:pink_terracotta
setblock 331 132 478 minecraft:red_nether_bricks
fill 331 132 479 331 135 479 minecraft:pink_terracotta
setblock 331 132 483 minecraft:red_nether_bricks
fill 331 132 484 331 135 484 minecraft:pink_terracotta
setblock 331 132 498 minecraft:red_nether_bricks
fill 331 132 499 331 134 499 minecraft:pink_terracotta
setblock 331 132 503 minecraft:red_nether_bricks
fill 331 132 504 331 135 504 minecraft:pink_terracotta
setblock 332 132 477 minecraft:red_nether_bricks
fill 332 132 478 332 135 478 minecraft:pink_terracotta
setblock 332 132 482 minecraft:red_nether_bricks
fill 332 132 503 332 135 503 minecraft:pink_terracotta
setblock 334 132 504 minecraft:pink_terracotta
setblock 335 132 464 minecraft:red_nether_bricks
setblock 335 132 504 minecraft:red_nether_bricks
fill 336 132 464 339 132 464 minecraft:pink_terracotta
fill 336 132 504 339 132 504 minecraft:pink_terracotta
setblock 340 132 464 minecraft:red_nether_bricks
setblock 340 132 504 minecraft:red_nether_bricks
fill 341 132 464 341 135 464 minecraft:pink_terracotta
setblock 341 132 503 minecraft:red_nether_bricks
fill 341 132 504 341 135 504 minecraft:pink_terracotta
fill 342 132 503 342 135 503 minecraft:pink_terracotta
fill 344 132 502 344 134 502 minecraft:pink_terracotta
setblock 345 132 464 minecraft:red_nether_bricks
fill 345 132 465 346 134 465 minecraft:pink_terracotta
setblock 345 132 504 minecraft:red_nether_bricks
fill 346 132 464 346 135 464 minecraft:pink_terracotta
fill 346 132 501 346 132 502 minecraft:pink_terracotta
setblock 346 132 503 minecraft:red_nether_bricks
fill 346 132 504 346 135 504 minecraft:pink_terracotta
setblock 347 132 501 minecraft:pink_terracotta
setblock 347 132 502 minecraft:red_nether_bricks
fill 347 132 503 347 135 503 minecraft:pink_terracotta
setblock 348 132 465 minecraft:pink_terracotta
setblock 348 132 501 minecraft:red_nether_bricks
fill 348 132 502 348 135 502 minecraft:pink_terracotta
setblock 349 132 465 minecraft:red_nether_bricks
fill 349 132 501 349 135 501 minecraft:pink_terracotta
setblock 350 132 464 minecraft:red_nether_bricks
fill 350 132 465 350 135 465 minecraft:pink_terracotta
setblock 350 132 504 minecraft:red_nether_bricks
fill 351 132 464 351 135 464 minecraft:pink_terracotta
setblock 351 132 503 minecraft:red_nether_bricks
fill 351 132 504 351 135 504 minecraft:pink_terracotta
setblock 352 132 502 minecraft:red_nether_bricks
fill 352 132 503 352 135 503 minecraft:pink_terracotta
fill 353 132 502 353 135 502 minecraft:pink_terracotta
fill 355 132 502 355 133 502 minecraft:pink_terracotta
setblock 355 132 504 minecraft:red_nether_bricks
setblock 356 132 503 minecraft:red_nether_bricks
fill 356 132 504 356 135 504 minecraft:pink_terracotta
fill 357 132 503 357 135 503 minecraft:pink_terracotta
setblock 360 132 504 minecraft:red_nether_bricks
fill 361 132 504 364 132 504 minecraft:pink_terracotta
fill 362 132 502 362 133 502 minecraft:white_concrete
fill 363 132 501 363 133 501 minecraft:white_concrete
fill 364 132 503 365 132 503 minecraft:pink_terracotta
fill 365 132 501 365 133 501 minecraft:white_concrete
setblock 365 132 504 minecraft:red_nether_bricks
setblock 366 132 502 minecraft:white_concrete
setblock 366 132 503 minecraft:red_nether_bricks
fill 366 132 504 366 135 504 minecraft:pink_terracotta
fill 367 132 478 367 132 481 minecraft:pink_terracotta
setblock 367 132 482 minecraft:red_nether_bricks
fill 367 132 503 367 135 503 minecraft:pink_terracotta
fill 368 132 464 369 132 464 minecraft:pink_terracotta
setblock 368 132 475 minecraft:pink_terracotta
setblock 368 132 476 minecraft:red_nether_bricks
fill 368 132 477 368 135 477 minecraft:pink_terracotta
setblock 368 132 481 minecraft:red_nether_bricks
fill 368 132 482 368 135 482 minecraft:pink_terracotta
setblock 368 132 485 minecraft:pink_terracotta
setblock 368 132 486 minecraft:red_nether_bricks
setblock 368 132 496 minecraft:red_nether_bricks
fill 368 132 497 368 134 497 minecraft:pink_terracotta
setblock 368 132 501 minecraft:red_nether_bricks
setblock 369 132 475 minecraft:red_nether_bricks
fill 369 132 476 369 135 476 minecraft:pink_terracotta
setblock 369 132 480 minecraft:red_nether_bricks
fill 369 132 481 369 135 481 minecraft:pink_terracotta
setblock 369 132 485 minecraft:red_nether_bricks
fill 369 132 486 369 135 486 minecraft:pink_terracotta
setblock 369 132 490 minecraft:red_nether_bricks
fill 369 132 491 369 135 491 minecraft:pink_terracotta
setblock 369 132 495 minecraft:red_nether_bricks
fill 369 132 496 369 135 496 minecraft:pink_terracotta
setblock 369 132 500 minecraft:red_nether_bricks
fill 369 132 501 369 135 501 minecraft:pink_terracotta
setblock 370 132 464 minecraft:red_nether_bricks
fill 370 132 465 370 132 468 minecraft:pink_terracotta
setblock 370 132 469 minecraft:red_nether_bricks
fill 370 132 470 370 135 470 minecraft:pink_terracotta
setblock 370 132 474 minecraft:red_nether_bricks
fill 370 132 475 370 135 475 minecraft:pink_terracotta
setblock 370 132 479 minecraft:red_nether_bricks
fill 370 132 480 370 135 480 minecraft:pink_terracotta
setblock 370 132 484 minecraft:red_nether_bricks
fill 370 132 485 370 135 485 minecraft:pink_terracotta
setblock 370 132 489 minecraft:red_nether_bricks
fill 370 132 490 370 135 490 minecraft:pink_terracotta
setblock 370 132 494 minecraft:red_nether_bricks
fill 370 132 495 370 135 495 minecraft:pink_terracotta
setblock 370 132 499 minecraft:red_nether_bricks
fill 370 132 500 370 135 500 minecraft:pink_terracotta
setblock 370 132 504 minecraft:red_nether_bricks
fill 330 133 464 330 136 464 minecraft:pink_terracotta
setblock 330 133 468 minecraft:red_nether_bricks
fill 330 133 469 330 136 469 minecraft:pink_terracotta
setblock 330 133 473 minecraft:red_nether_bricks
fill 330 133 474 330 136 474 minecraft:pink_terracotta
setblock 330 133 478 minecraft:red_nether_bricks
fill 330 133 479 330 136 479 minecraft:pink_terracotta
setblock 330 133 483 minecraft:red_nether_bricks
fill 330 133 484 330 136 484 minecraft:pink_terracotta
setblock 330 133 488 minecraft:red_nether_bricks
fill 330 133 489 330 135 490 minecraft:pink_terracotta
setblock 330 133 491 minecraft:white_concrete
setblock 330 133 494 minecraft:pink_terracotta
setblock 330 133 498 minecraft:red_nether_bricks
fill 330 133 499 330 136 499 minecraft:pink_terracotta
setblock 330 133 503 minecraft:red_nether_bricks
fill 330 133 504 330 136 504 minecraft:pink_terracotta
setblock 331 133 467 minecraft:red_nether_bricks
fill 331 133 468 331 136 468 minecraft:pink_terracotta
setblock 331 133 472 minecraft:red_nether_bricks
fill 331 133 473 331 136 473 minecraft:pink_terracotta
setblock 331 133 477 minecraft:red_nether_bricks
fill 331 133 478 331 136 478 minecraft:pink_terracotta
setblock 331 133 482 minecraft:red_nether_bricks
fill 331 133 483 331 136 483 minecraft:pink_terracotta
setblock 331 133 502 minecraft:red_nether_bricks
fill 331 133 503 331 136 503 minecraft:pink_terracotta
setblock 332 133 465 minecraft:pink_terracotta
setblock 332 133 476 minecraft:red_nether_bricks
fill 332 133 477 332 135 477 minecraft:pink_terracotta
setblock 332 133 481 minecraft:red_nether_bricks
fill 332 133 482 332 136 482 minecraft:pink_terracotta
setblock 333 133 464 minecraft:pink_terracotta
setblock 333 133 465 minecraft:red_nether_bricks
fill 333 133 503 333 134 503 minecraft:pink_terracotta
setblock 334 133 464 minecraft:red_nether_bricks
setblock 334 133 504 minecraft:red_nether_bricks
fill 335 133 464 338 133 464 minecraft:pink_terracotta
fill 335 133 504 338 133 504 minecraft:pink_terracotta
setblock 339 133 464 minecraft:red_nether_bricks
setblock 339 133 504 minecraft:red_nether_bricks
fill 340 133 464 340 136 464 minecraft:pink_terracotta
setblock 340 133 503 minecraft:red_nether_bricks
fill 340 133 504 340 136 504 minecraft:pink_terracotta
fill 341 133 503 341 136 503 minecraft:pink_terracotta
fill 342 133 502 343 135 502 minecraft:pink_terracotta
setblock 343 133 465 minecraft:red_nether_bricks
setblock 344 133 464 minecraft:red_nether_bricks
fill 344 133 465 344 136 465 minecraft:pink_terracotta
setblock 344 133 503 minecraft:pink_terracotta
setblock 344 133 504 minecraft:red_nether_bricks
fill 345 133 464 345 136 464 minecraft:pink_terracotta
fill 345 133 501 346 133 501 minecraft:pink_terracotta
setblock 345 133 503 minecraft:red_nether_bricks
fill 345 133 504 345 136 504 minecraft:pink_terracotta
setblock 346 133 502 minecraft:red_nether_bricks
fill 346 133 503 346 136 503 minecraft:pink_terracotta
setblock 347 133 501 minecraft:red_nether_bricks
fill 347 133 502 347 136 502 minecraft:pink_terracotta
setblock 348 133 465 minecraft:red_nether_bricks
fill 348 133 501 348 136 501 minecraft:pink_terracotta
setblock 349 133 464 minecraft:red_nether_bricks
fill 349 133 465 349 136 465 minecraft:pink_terracotta
setblock 349 133 504 minecraft:red_nether_bricks
fill 350 133 464 350 136 464 minecraft:pink_terracotta
setblock 350 133 503 minecraft:red_nether_bricks
fill 350 133 504 350 136 504 minecraft:pink_terracotta
fill 351 133 465 351 134 465 minecraft:pink_terracotta
setblock 351 133 501 minecraft:pink_terracotta
setblock 351 133 502 minecraft:red_nether_bricks
fill 351 133 503 351 136 503 minecraft:pink_terracotta
setblock 352 133 501 minecraft:red_nether_bricks
fill 352 133 502 352 136 502 minecraft:pink_terracotta
setblock 353 133 501 minecraft:pink_terracotta
setblock 354 133 464 minecraft:red_nether_bricks
setblock 354 133 504 minecraft:red_nether_bricks
setblock 355 133 503 minecraft:red_nether_bricks
fill 355 133 504 355 136 504 minecraft:pink_terracotta
fill 356 133 503 356 136 503 minecraft:pink_terracotta
fill 358 133 503 359 133 503 minecraft:pink_terracotta
setblock 359 133 504 minecraft:red_nether_bricks
setblock 360 133 503 minecraft:red_nether_bricks
fill 360 133 504 363 133 504 minecraft:pink_terracotta
fill 361 133 503 364 133 503 minecraft:pink_terracotta
fill 363 133 502 364 133 502 minecraft:white_concrete
setblock 364 133 464 minecraft:white_concrete
setblock 364 133 500 minecraft:black_concrete
setblock 364 133 504 minecraft:red_nether_bricks
fill 365 133 464 368 133 464 minecraft:pink_terracotta
setblock 365 133 502 minecraft:pink_terracotta
setblock 365 133 503 minecraft:red_nether_bricks
fill 365 133 504 365 136 504 minecraft:pink_terracotta
setblock 366 133 502 minecraft:red_nether_bricks
fill 366 133 503 366 136 503 minecraft:pink_terracotta
fill 367 133 477 367 133 480 minecraft:pink_terracotta
setblock 367 133 481 minecraft:red_nether_bricks
fill 367 133 482 367 134 484 minecraft:pink_terracotta
fill 367 133 502 368 135 502 minecraft:pink_terracotta
setblock 368 133 474 minecraft:pink_terracotta
setblock 368 133 475 minecraft:red_nether_bricks
fill 368 133 476 368 136 476 minecraft:pink_terracotta
setblock 368 133 480 minecraft:red_nether_bricks
fill 368 133 481 368 136 481 minecraft:pink_terracotta
setblock 368 133 485 minecraft:red_nether_bricks
fill 368 133 486 368 134 488 minecraft:pink_terracotta
setblock 368 133 500 minecraft:red_nether_bricks
fill 368 133 501 368 136 501 minecraft:pink_terracotta
setblock 369 133 464 minecraft:red_nether_bricks
setblock 369 133 474 minecraft:red_nether_bricks
fill 369 133 475 369 136 475 minecraft:pink_terracotta
setblock 369 133 479 minecraft:red_nether_bricks
fill 369 133 480 369 136 480 minecraft:pink_terracotta
setblock 369 133 484 minecraft:red_nether_bricks
fill 369 133 485 369 136 485 minecraft:pink_terracotta
setblock 369 133 489 minecraft:red_nether_bricks
fill 369 133 490 369 136 490 minecraft:pink_terracotta
setblock 369 133 494 minecraft:red_nether_bricks
fill 369 133 495 369 135 495 minecraft:pink_terracotta
setblock 369 133 499 minecraft:red_nether_bricks
fill 369 133 500 369 136 500 minecraft:pink_terracotta
setblock 369 133 504 minecraft:red_nether_bricks
fill 370 133 464 370 133 467 minecraft:pink_terracotta
setblock 370 133 468 minecraft:red_nether_bricks
fill 370 133 469 370 136 469 minecraft:pink_terracotta
setblock 370 133 473 minecraft:red_nether_bricks
fill 370 133 474 370 136 474 minecraft:pink_terracotta
setblock 370 133 478 minecraft:red_nether_bricks
fill 370 133 479 370 136 479 minecraft:pink_terracotta
setblock 370 133 483 minecraft:red_nether_bricks
fill 370 133 484 370 136 484 minecraft:pink_terracotta
setblock 370 133 488 minecraft:red_nether_bricks
fill 370 133 489 370 136 489 minecraft:pink_terracotta
setblock 370 133 493 minecraft:red_nether_bricks
fill 370 133 494 370 136 494 minecraft:pink_terracotta
setblock 370 133 498 minecraft:red_nether_bricks
fill 370 133 499 370 136 499 minecraft:pink_terracotta
setblock 370 133 503 minecraft:red_nether_bricks
fill 370 133 504 370 136 504 minecraft:pink_terracotta
setblock 330 134 467 minecraft:red_nether_bricks
fill 330 134 468 330 137 468 minecraft:pink_terracotta
setblock 330 134 472 minecraft:red_nether_bricks
fill 330 134 473 330 137 473 minecraft:pink_terracotta
setblock 330 134 477 minecraft:red_nether_bricks
fill 330 134 478 330 137 478 minecraft:pink_terracotta
setblock 330 134 482 minecraft:red_nether_bricks
fill 330 134 483 330 137 483 minecraft:pink_terracotta
setblock 330 134 487 minecraft:red_nether_bricks
fill 330 134 488 330 137 488 minecraft:pink_terracotta
setblock 330 134 497 minecraft:red_nether_bricks
fill 330 134 498 330 137 498 minecraft:pink_terracotta
setblock 330 134 502 minecraft:red_nether_bricks
fill 330 134 503 330 137 503 minecraft:pink_terracotta
setblock 331 134 466 minecraft:red_nether_bricks
fill 331 134 467 331 137 467 minecraft:pink_terracotta
setblock 331 134 471 minecraft:red_nether_bricks
fill 331 134 472 331 136 472 minecraft:pink_terracotta
setblock 331 134 476 minecraft:red_nether_bricks
fill 331 134 477 331 137 477 minecraft:pink_terracotta
setblock 331 134 481 minecraft:red_nether_bricks
fill 331 134 482 331 137 482 minecraft:pink_terracotta
setblock 331 134 486 minecraft:red_nether_bricks
setblock 331 134 501 minecraft:red_nether_bricks
fill 331 134 502 331 137 502 minecraft:pink_terracotta
setblock 332 134 465 minecraft:red_nether_bricks
setblock 332 134 475 minecraft:red_nether_bricks
setblock 332 134 476 minecraft:pink_terracotta
setblock 332 134 480 minecraft:red_nether_bricks
fill 332 134 481 332 136 481 minecraft:pink_terracotta
setblock 333 134 464 minecraft:red_nether_bricks
fill 333 134 465 334 136 465 minecraft:pink_terracotta
setblock 333 134 504 minecraft:red_nether_bricks
fill 334 134 464 337 134 464 minecraft:pink_terracotta
setblock 334 134 503 minecraft:red_nether_bricks
fill 334 134 504 337 134 504 minecraft:pink_terracotta
fill 335 134 503 335 137 503 minecraft:pink_terracotta
fill 337 134 503 338 134 503 minecraft:pink_terracotta
setblock 338 134 464 minecraft:red_nether_bricks
setblock 338 134 504 minecraft:red_nether_bricks
fill 339 134 464 339 137 464 minecraft:pink_terracotta
setblock 339 134 503 minecraft:red_nether_bricks
fill 339 134 504 339 137 504 minecraft:pink_terracotta
fill 340 134 465 341 134 465 minecraft:pink_terracotta
fill 340 134 503 340 137 503 minecraft:pink_terracotta
fill 341 134 502 341 137 502 minecraft:pink_terracotta
setblock 342 134 464 minecraft:pink_terracotta
setblock 342 134 465 minecraft:red_nether_bricks
setblock 343 134 464 minecraft:red_nether_bricks
fill 343 134 465 343 137 465 minecraft:pink_terracotta
setblock 343 134 504 minecraft:red_nether_bricks
fill 344 134 464 344 137 464 minecraft:pink_terracotta
fill 344 134 501 345 134 501 minecraft:pink_terracotta
setblock 344 134 503 minecraft:red_nether_bricks
fill 344 134 504 344 137 504 minecraft:pink_terracotta
setblock 345 134 502 minecraft:red_nether_bricks
fill 345 134 503 345 137 503 minecraft:pink_terracotta
setblock 346 134 501 minecraft:red_nether_bricks
fill 346 134 502 346 137 502 minecraft:pink_terracotta
setblock 347 134 464 minecraft:pink_terracotta
setblock 347 134 465 minecraft:red_nether_bricks
fill 347 134 501 347 137 501 minecraft:pink_terracotta
setblock 348 134 464 minecraft:red_nether_bricks
fill 348 134 465 348 137 465 minecraft:pink_terracotta
setblock 348 134 504 minecraft:red_nether_bricks
fill 349 134 464 349 137 464 minecraft:pink_terracotta
setblock 349 134 503 minecraft:red_nether_bricks
fill 349 134 504 349 137 504 minecraft:pink_terracotta
setblock 350 134 502 minecraft:red_nether_bricks
fill 350 134 503 350 137 503 minecraft:pink_terracotta
setblock 351 134 501 minecraft:red_nether_bricks
fill 351 134 502 351 137 502 minecraft:pink_terracotta
fill 352 134 501 352 135 501 minecraft:pink_terracotta
setblock 353 134 464 minecraft:red_nether_bricks
setblock 353 134 504 minecraft:red_nether_bricks
fill 354 134 464 354 137 464 minecraft:pink_terracotta
setblock 354 134 503 minecraft:red_nether_bricks
fill 354 134 504 354 137 504 minecraft:pink_terracotta
setblock 355 134 502 minecraft:red_nether_bricks
fill 355 134 503 355 137 503 minecraft:pink_terracotta
setblock 358 134 464 minecraft:white_concrete
setblock 358 134 503 minecraft:pink_terracotta
setblock 358 134 504 minecraft:red_nether_bricks
setblock 359 134 503 minecraft:red_nether_bricks
fill 359 134 504 362 134 504 minecraft:pink_terracotta
fill 360 134 503 363 134 503 minecraft:pink_terracotta
setblock 363 134 464 minecraft:red_nether_bricks
setblock 363 134 502 minecraft:white_concrete
setblock 363 134 504 minecraft:red_nether_bricks
fill 364 134 464 367 134 464 minecraft:pink_terracotta
setblock 364 134 502 minecraft:pink_terracotta
setblock 364 134 503 minecraft:red_nether_bricks
fill 364 134 504 364 137 504 minecraft:pink_terracotta
setblock 365 134 502 minecraft:red_nether_bricks
fill 365 134 503 365 137 503 minecraft:pink_terracotta
fill 366 134 502 366 137 502 minecraft:pink_terracotta
fill 367 134 477 367 134 479 minecraft:pink_terracotta
setblock 367 134 480 minecraft:red_nether_bricks
fill 367 134 481 367 137 481 minecraft:pink_terracotta
setblock 367 134 485 minecraft:red_nether_bricks
fill 367 134 486 367 137 486 minecraft:pink_terracotta
setblock 368 134 464 minecraft:red_nether_bricks
setblock 368 134 474 minecraft:red_nether_bricks
fill 368 134 475 368 137 475 minecraft:pink_terracotta
setblock 368 134 479 minecraft:red_nether_bricks
fill 368 134 480 368 137 480 minecraft:pink_terracotta
setblock 368 134 483 minecraft:pink_terracotta
setblock 368 134 484 minecraft:red_nether_bricks
fill 368 134 485 368 137 485 minecraft:pink_terracotta
setblock 368 134 489 minecraft:red_nether_bricks
setblock 368 134 499 minecraft:red_nether_bricks
fill 368 134 500 368 136 500 minecraft:pink_terracotta
setblock 368 134 503 minecraft:pink_terracotta
setblock 368 134 504 minecraft:red_nether_bricks
fill 369 134 464 370 135 465 minecraft:pink_terracotta
fill 369 134 471 369 135 471 minecraft:pink_terracotta
setblock 369 134 473 minecraft:red_nether_bricks
fill 369 134 474 369 137 474 minecraft:pink_terracotta
setblock 369 134 478 minecraft:red_nether_bricks
fill 369 134 479 369 137 479 minecraft:pink_terracotta
setblock 369 134 483 minecraft:red_nether_bricks
fill 369 134 484 369 137 484 minecraft:pink_terracotta
setblock 369 134 488 minecraft:red_nether_bricks
fill 369 134 489 369 137 489 minecraft:pink_terracotta
setblock 369 134 493 minecraft:red_nether_bricks
fill 369 134 494 369 135 494 minecraft:pink_terracotta
setblock 369 134 498 minecraft:red_nether_bricks
fill 369 134 499 369 137 499 minecraft:pink_terracotta
setblock 369 134 503 minecraft:red_nether_bricks
fill 369 134 504 369 137 504 minecraft:pink_terracotta
setblock 370 134 466 minecraft:pink_terracotta
setblock 370 134 467 minecraft:red_nether_bricks
fill 370 134 468 370 137 468 minecraft:pink_terracotta
setblock 370 134 472 minecraft:red_nether_bricks
fill 370 134 473 370 137 473 minecraft:pink_terracotta
setblock 370 134 477 minecraft:red_nether_bricks
fill 370 134 478 370 137 478 minecraft:pink_terracotta
setblock 370 134 482 minecraft:red_nether_bricks
fill 370 134 483 370 137 483 minecraft:pink_terracotta
setblock 370 134 487 minecraft:red_nether_bricks
fill 370 134 488 370 137 488 minecraft:pink_terracotta
setblock 370 134 492 minecraft:red_nether_bricks
fill 370 134 493 370 137 493 minecraft:pink_terracotta
setblock 370 134 497 minecraft:red_nether_bricks
fill 370 134 498 370 137 498 minecraft:pink_terracotta
setblock 370 134 502 minecraft:red_nether_bricks
fill 370 134 503 370 137 503 minecraft:pink_terracotta
setblock 330 135 465 minecraft:pink_terracotta
setblock 330 135 466 minecraft:red_nether_bricks
fill 330 135 467 330 138 467 minecraft:pink_terracotta
setblock 330 135 471 minecraft:red_nether_bricks
fill 330 135 472 330 138 472 minecraft:pink_terracotta
setblock 330 135 476 minecraft:red_nether_bricks
fill 330 135 477 330 138 477 minecraft:pink_terracotta
setblock 330 135 481 minecraft:red_nether_bricks
fill 330 135 482 330 138 482 minecraft:pink_terracotta
setblock 330 135 486 minecraft:red_nether_bricks
fill 330 135 487 330 138 487 minecraft:pink_terracotta
setblock 330 135 496 minecraft:red_nether_bricks
fill 330 135 497 330 136 497 minecraft:pink_terracotta
setblock 330 135 501 minecraft:red_nether_bricks
fill 330 135 502 330 138 502 minecraft:pink_terracotta
setblock 331 135 465 minecraft:red_nether_bricks
fill 331 135 466 331 138 466 minecraft:pink_terracotta
setblock 331 135 470 minecraft:red_nether_bricks
fill 331 135 471 331 137 471 minecraft:pink_terracotta
setblock 331 135 475 minecraft:red_nether_bricks
fill 331 135 476 331 137 476 minecraft:pink_terracotta
setblock 331 135 480 minecraft:red_nether_bricks
fill 331 135 481 331 138 481 minecraft:pink_terracotta
setblock 331 135 485 minecraft:red_nether_bricks
fill 331 135 486 331 137 486 minecraft:pink_terracotta
setblock 331 135 500 minecraft:red_nether_bricks
fill 331 135 501 331 136 501 minecraft:pink_terracotta
setblock 332 135 464 minecraft:red_nether_bricks
fill 332 135 465 332 138 465 minecraft:pink_terracotta
setblock 332 135 466 minecraft:light[level=12]
setblock 332 135 474 minecraft:light[level=12]
setblock 332 135 479 minecraft:red_nether_bricks
fill 332 135 480 332 136 480 minecraft:pink_terracotta
setblock 332 135 490 minecraft:light[level=12]
setblock 332 135 498 minecraft:light[level=12]
setblock 332 135 504 minecraft:red_nether_bricks
fill 333 135 464 336 135 464 minecraft:pink_terracotta
setblock 333 135 503 minecraft:red_nether_bricks
fill 333 135 504 336 135 504 minecraft:pink_terracotta
fill 334 135 503 334 137 503 minecraft:pink_terracotta
setblock 335 135 465 minecraft:pink_terracotta
setblock 336 135 465 minecraft:red_nether_bricks
fill 336 135 503 337 135 503 minecraft:pink_terracotta
setblock 337 135 464 minecraft:red_nether_bricks
fill 337 135 465 340 135 465 minecraft:pink_terracotta
setblock 337 135 504 minecraft:red_nether_bricks
fill 338 135 464 338 138 464 minecraft:pink_terracotta
setblock 338 135 503 minecraft:red_nether_bricks
fill 338 135 504 338 138 504 minecraft:pink_terracotta
fill 339 135 503 339 138 503 minecraft:pink_terracotta
setblock 340 135 466 minecraft:light[level=12]
setblock 340 135 474 minecraft:light[level=12]
setblock 340 135 482 minecraft:light[level=12]
setblock 340 135 490 minecraft:light[level=12]
setblock 340 135 498 minecraft:light[level=12]
setblock 341 135 465 minecraft:red_nether_bricks
setblock 342 135 464 minecraft:red_nether_bricks
fill 342 135 465 342 138 465 minecraft:pink_terracotta
setblock 342 135 504 minecraft:red_nether_bricks
fill 343 135 464 343 138 464 minecraft:pink_terracotta
fill 343 135 501 344 135 501 minecraft:pink_terracotta
setblock 343 135 503 minecraft:red_nether_bricks
fill 343 135 504 343 138 504 minecraft:pink_terracotta
setblock 344 135 466 minecraft:pink_terracotta
setblock 344 135 502 minecraft:red_nether_bricks
fill 344 135 503 344 138 503 minecraft:pink_terracotta
setblock 345 135 465 minecraft:pink_terracotta
setblock 345 135 466 minecraft:red_nether_bricks
setblock 345 135 501 minecraft:red_nether_bricks
fill 345 135 502 345 138 502 minecraft:pink_terracotta
setblock 346 135 465 minecraft:red_nether_bricks
fill 346 135 466 347 137 466 minecraft:pink_terracotta
fill 346 135 501 346 138 501 minecraft:pink_terracotta
setblock 347 135 464 minecraft:red_nether_bricks
fill 347 135 465 347 138 465 minecraft:pink_terracotta
setblock 347 135 504 minecraft:red_nether_bricks
fill 348 135 464 348 138 464 minecraft:pink_terracotta
setblock 348 135 466 minecraft:light[level=12]
setblock 348 135 474 minecraft:light[level=12]
setblock 348 135 482 minecraft:light[level=12]
setblock 348 135 490 minecraft:light[level=12]
setblock 348 135 498 minecraft:light[level=12]
setblock 348 135 503 minecraft:red_nether_bricks
fill 348 135 504 348 138 504 minecraft:pink_terracotta
setblock 349 135 502 minecraft:red_nether_bricks
fill 349 135 503 349 138 503 minecraft:pink_terracotta
setblock 350 135 501 minecraft:red_nether_bricks
fill 350 135 502 350 138 502 minecraft:pink_terracotta
setblock 351 135 465 minecraft:red_nether_bricks
fill 351 135 501 351 136 501 minecraft:pink_terracotta
setblock 352 135 464 minecraft:red_nether_bricks
setblock 352 135 504 minecraft:red_nether_bricks
fill 353 135 464 353 138 464 minecraft:pink_terracotta
setblock 353 135 503 minecraft:red_nether_bricks
fill 353 135 504 353 138 504 minecraft:pink_terracotta
setblock 354 135 502 minecraft:red_nether_bricks
fill 354 135 503 354 138 503 minecraft:pink_terracotta
setblock 355 135 502 minecraft:pink_terracotta
setblock 356 135 466 minecraft:light[level=12]
setblock 356 135 474 minecraft:light[level=12]
setblock 356 135 482 minecraft:light[level=12]
setblock 356 135 490 minecraft:light[level=12]
setblock 356 135 498 minecraft:light[level=12]
setblock 357 135 504 minecraft:red_nether_bricks
setblock 358 135 503 minecraft:red_nether_bricks
fill 358 135 504 361 135 504 minecraft:pink_terracotta
fill 359 135 503 362 135 503 minecraft:pink_terracotta
setblock 362 135 464 minecraft:red_nether_bricks
setblock 362 135 504 minecraft:red_nether_bricks
fill 363 135 464 366 135 464 minecraft:pink_terracotta
setblock 363 135 502 minecraft:pink_terracotta
setblock 363 135 503 minecraft:red_nether_bricks
fill 363 135 504 363 138 504 minecraft:pink_terracotta
setblock 364 135 466 minecraft:light[level=12]
setblock 364 135 474 minecraft:light[level=12]
setblock 364 135 482 minecraft:light[level=12]
setblock 364 135 490 minecraft:light[level=12]
setblock 364 135 498 minecraft:light[level=12]
setblock 364 135 502 minecraft:red_nether_bricks
fill 364 135 503 364 138 503 minecraft:pink_terracotta
fill 365 135 502 365 137 502 minecraft:pink_terracotta
setblock 366 135 465 minecraft:red_nether_bricks
setblock 366 135 480 minecraft:red_nether_bricks
fill 366 135 481 366 136 483 minecraft:pink_terracotta
setblock 367 135 464 minecraft:red_nether_bricks
fill 367 135 465 368 137 465 minecraft:pink_terracotta
fill 367 135 477 367 135 478 minecraft:pink_terracotta
setblock 367 135 479 minecraft:red_nether_bricks
fill 367 135 480 367 138 480 minecraft:pink_terracotta
fill 367 135 482 367 135 483 minecraft:pink_terracotta
setblock 367 135 484 minecraft:red_nether_bricks
fill 367 135 485 367 138 485 minecraft:pink_terracotta
fill 367 135 487 368 135 487 minecraft:pink_terracotta
setblock 367 135 504 minecraft:red_nether_bricks
fill 368 135 464 368 138 464 minecraft:pink_terracotta
setblock 368 135 474 minecraft:pink_terracotta
setblock 368 135 478 minecraft:red_nether_bricks
fill 368 135 479 368 138 479 minecraft:pink_terracotta
setblock 368 135 483 minecraft:red_nether_bricks
fill 368 135 484 368 138 484 minecraft:pink_terracotta
fill 368 135 486 368 136 486 minecraft:pink_terracotta
setblock 368 135 488 minecraft:red_nether_bricks
fill 368 135 489 368 138 489 minecraft:pink_terracotta
setblock 368 135 499 minecraft:pink_terracotta
setblock 368 135 503 minecraft:red_nether_bricks
fill 368 135 504 368 138 504 minecraft:pink_terracotta
setblock 369 135 466 minecraft:pink_terracotta
setblock 369 135 467 minecraft:red_nether_bricks
setblock 369 135 472 minecraft:red_nether_bricks
fill 369 135 473 369 138 473 minecraft:pink_terracotta
setblock 369 135 477 minecraft:red_nether_bricks
fill 369 135 478 369 138 478 minecraft:pink_terracotta
setblock 369 135 482 minecraft:red_nether_bricks
fill 369 135 483 369 138 483 minecraft:pink_terracotta
setblock 369 135 487 minecraft:red_nether_bricks
fill 369 135 488 369 138 488 minecraft:pink_terracotta
setblock 369 135 492 minecraft:red_nether_bricks
setblock 369 135 493 minecraft:pink_terracotta
setblock 369 135 497 minecraft:red_nether_bricks
fill 369 135 498 369 136 498 minecraft:pink_terracotta
setblock 369 135 502 minecraft:red_nether_bricks
fill 369 135 503 369 138 503 minecraft:pink_terracotta
setblock 370 135 466 minecraft:red_nether_bricks
fill 370 135 467 370 138 467 minecraft:pink_terracotta
setblock 370 135 471 minecraft:red_nether_bricks
fill 370 135 472 370 138 472 minecraft:pink_terracotta
setblock 370 135 476 minecraft:red_nether_bricks
fill 370 135 477 370 138 477 minecraft:pink_terracotta
setblock 370 135 481 minecraft:red_nether_bricks
fill 370 135 482 370 138 482 minecraft:pink_terracotta
setblock 370 135 486 minecraft:red_nether_bricks
fill 370 135 487 370 138 487 minecraft:pink_terracotta
setblock 370 135 491 minecraft:red_nether_bricks
fill 370 135 492 370 138 492 minecraft:pink_terracotta
setblock 370 135 496 minecraft:red_nether_bricks
fill 370 135 497 370 137 497 minecraft:pink_terracotta
setblock 370 135 501 minecraft:red_nether_bricks
fill 370 135 502 370 138 502 minecraft:pink_terracotta
setblock 330 136 465 minecraft:red_nether_bricks
fill 330 136 466 330 139 466 minecraft:pink_terracotta
setblock 330 136 470 minecraft:red_nether_bricks
fill 330 136 471 330 139 471 minecraft:pink_terracotta
setblock 330 136 475 minecraft:red_nether_bricks
fill 330 136 476 330 139 476 minecraft:pink_terracotta
setblock 330 136 480 minecraft:red_nether_bricks
fill 330 136 481 330 139 481 minecraft:pink_terracotta
setblock 330 136 485 minecraft:red_nether_bricks
fill 330 136 486 330 139 486 minecraft:pink_terracotta
setblock 330 136 489 minecraft:pink_terracotta
setblock 330 136 490 minecraft:red_nether_bricks
setblock 330 136 500 minecraft:red_nether_bricks
fill 330 136 501 330 139 501 minecraft:pink_terracotta
setblock 331 136 464 minecraft:red_nether_bricks
fill 331 136 465 331 139 465 minecraft:pink_terracotta
setblock 331 136 469 minecraft:red_nether_bricks
fill 331 136 470 331 137 470 minecraft:pink_terracotta
setblock 331 136 474 minecraft:red_nether_bricks
fill 331 136 475 331 137 475 minecraft:pink_terracotta
setblock 331 136 479 minecraft:red_nether_bricks
fill 331 136 480 331 138 480 minecraft:pink_terracotta
setblock 331 136 484 minecraft:red_nether_bricks
fill 331 136 485 331 138 485 minecraft:pink_terracotta
setblock 331 136 504 minecraft:red_nether_bricks
fill 332 136 464 335 136 464 minecraft:pink_terracotta
setblock 332 136 479 minecraft:pink_terracotta
setblock 332 136 503 minecraft:red_nether_bricks
fill 332 136 504 335 136 504 minecraft:pink_terracotta
fill 333 136 503 333 137 503 minecraft:pink_terracotta
setblock 335 136 465 minecraft:red_nether_bricks
setblock 336 136 464 minecraft:red_nether_bricks
fill 336 136 465 339 136 465 minecraft:pink_terracotta
setblock 336 136 503 minecraft:pink_terracotta
setblock 336 136 504 minecraft:red_nether_bricks
fill 337 136 464 337 139 464 minecraft:pink_terracotta
setblock 337 136 503 minecraft:red_nether_bricks
fill 337 136 504 337 139 504 minecraft:pink_terracotta
fill 338 136 503 338 139 503 minecraft:pink_terracotta
setblock 340 136 465 minecraft:red_nether_bricks
fill 340 136 502 340 138 502 minecraft:pink_terracotta
setblock 341 136 464 minecraft:red_nether_bricks
fill 341 136 465 341 139 465 minecraft:pink_terracotta
setblock 341 136 504 minecraft:red_nether_bricks
fill 342 136 464 342 139 464 minecraft:pink_terracotta
setblock 342 136 502 minecraft:pink_terracotta
setblock 342 136 503 minecraft:red_nether_bricks
fill 342 136 504 342 139 504 minecraft:pink_terracotta
setblock 343 136 466 minecraft:pink_terracotta
setblock 343 136 501 minecraft:pink_terracotta
setblock 343 136 502 minecraft:red_nether_bricks
fill 343 136 503 343 139 503 minecraft:pink_terracotta
setblock 344 136 466 minecraft:red_nether_bricks
setblock 344 136 501 minecraft:red_nether_bricks
fill 344 136 502 344 139 502 minecraft:pink_terracotta
setblock 345 136 465 minecraft:red_nether_bricks
fill 345 136 466 345 139 466 minecraft:pink_terracotta
fill 345 136 501 345 139 501 minecraft:pink_terracotta
setblock 346 136 464 minecraft:red_nether_bricks
fill 346 136 465 346 139 465 minecraft:pink_terracotta
setblock 346 136 504 minecraft:red_nether_bricks
fill 347 136 464 347 139 464 minecraft:pink_terracotta
setblock 347 136 503 minecraft:red_nether_bricks
fill 347 136 504 347 139 504 minecraft:pink_terracotta
setblock 348 136 466 minecraft:pink_terracotta
setblock 348 136 502 minecraft:red_nether_bricks
fill 348 136 503 348 139 503 minecraft:pink_terracotta
setblock 349 136 501 minecraft:red_nether_bricks
fill 349 136 502 349 139 502 minecraft:pink_terracotta
setblock 350 136 465 minecraft:red_nether_bricks
fill 350 136 501 350 137 501 minecraft:pink_terracotta
setblock 351 136 464 minecraft:red_nether_bricks
fill 351 136 465 351 137 465 minecraft:pink_terracotta
setblock 351 136 504 minecraft:red_nether_bricks
fill 352 136 464 352 139 464 minecraft:pink_terracotta
setblock 352 136 503 minecraft:red_nether_bricks
fill 352 136 504 352 139 504 minecraft:pink_terracotta
setblock 353 136 502 minecraft:red_nether_bricks
fill 353 136 503 353 139 503 minecraft:pink_terracotta
setblock 354 136 502 minecraft:pink_terracotta
setblock 355 136 464 minecraft:pink_terracotta
setblock 356 136 504 minecraft:red_nether_bricks
setblock 357 136 503 minecraft:red_nether_bricks
fill 357 136 504 360 136 504 minecraft:pink_terracotta
fill 358 136 503 361 136 503 minecraft:pink_terracotta
setblock 360 136 464 minecraft:pink_terracotta
setblock 361 136 464 minecraft:red_nether_bricks
setblock 361 136 504 minecraft:red_nether_bricks
fill 362 136 464 365 136 464 minecraft:pink_terracotta
setblock 362 136 502 minecraft:pink_terracotta
setblock 362 136 503 minecraft:red_nether_bricks
fill 362 136 504 362 139 504 minecraft:pink_terracotta
setblock 363 136 502 minecraft:red_nether_bricks
fill 363 136 503 363 139 503 minecraft:pink_terracotta
setblock 364 136 465 minecraft:pink_terracotta
fill 364 136 502 364 137 502 minecraft:pink_terracotta
setblock 365 136 465 minecraft:red_nether_bricks
setblock 366 136 464 minecraft:red_nether_bricks
fill 366 136 465 366 139 465 minecraft:pink_terracotta
setblock 366 136 480 minecraft:pink_terracotta
setblock 366 136 484 minecraft:red_nether_bricks
setblock 366 136 504 minecraft:red_nether_bricks
fill 367 136 464 367 139 464 minecraft:pink_terracotta
setblock 367 136 477 minecraft:pink_terracotta
setblock 367 136 478 minecraft:red_nether_bricks
fill 367 136 479 367 138 479 minecraft:pink_terracotta
setblock 367 136 482 minecraft:pink_terracotta
setblock 367 136 483 minecraft:red_nether_bricks
fill 367 136 484 367 139 484 minecraft:pink_terracotta
setblock 367 136 487 minecraft:pink_terracotta
setblock 367 136 502 minecraft:pink_terracotta
setblock 367 136 503 minecraft:red_nether_bricks
fill 367 136 504 367 139 504 minecraft:pink_terracotta
setblock 368 136 477 minecraft:red_nether_bricks
fill 368 136 478 368 139 478 minecraft:pink_terracotta
setblock 368 136 482 minecraft:red_nether_bricks
fill 368 136 483 368 139 483 minecraft:pink_terracotta
setblock 368 136 487 minecraft:red_nether_bricks
fill 368 136 488 368 139 488 minecraft:pink_terracotta
setblock 368 136 502 minecraft:red_nether_bricks
fill 368 136 503 368 139 503 minecraft:pink_terracotta
fill 369 136 464 369 136 465 minecraft:pink_terracotta
setblock 369 136 466 minecraft:red_nether_bricks
fill 369 136 467 369 136 470 minecraft:pink_terracotta
setblock 369 136 471 minecraft:red_nether_bricks
fill 369 136 472 369 137 472 minecraft:pink_terracotta
setblock 369 136 476 minecraft:red_nether_bricks
fill 369 136 477 369 139 477 minecraft:pink_terracotta
setblock 369 136 481 minecraft:red_nether_bricks
fill 369 136 482 369 139 482 minecraft:pink_terracotta
setblock 369 136 486 minecraft:red_nether_bricks
fill 369 136 487 369 139 487 minecraft:pink_terracotta
setblock 369 136 491 minecraft:red_nether_bricks
setblock 369 136 492 minecraft:pink_terracotta
setblock 369 136 497 minecraft:pink_terracotta
setblock 369 136 501 minecraft:red_nether_bricks
fill 369 136 502 369 138 502 minecraft:pink_terracotta
setblock 370 136 464 minecraft:pink_terracotta
setblock 370 136 465 minecraft:red_nether_bricks
fill 370 136 466 370 139 466 minecraft:pink_terracotta
setblock 370 136 470 minecraft:red_nether_bricks
fill 370 136 471 370 139 471 minecraft:pink_terracotta
setblock 370 136 475 minecraft:red_nether_bricks
fill 370 136 476 370 139 476 minecraft:pink_terracotta
setblock 370 136 480 minecraft:red_nether_bricks
fill 370 136 481 370 139 481 minecraft:pink_terracotta
setblock 370 136 485 minecraft:red_nether_bricks
fill 370 136 486 370 139 486 minecraft:pink_terracotta
setblock 370 136 490 minecraft:red_nether_bricks
fill 370 136 491 370 139 491 minecraft:pink_terracotta
setblock 370 136 495 minecraft:red_nether_bricks
fill 370 136 496 370 137 496 minecraft:pink_terracotta
setblock 370 136 500 minecraft:red_nether_bricks
fill 370 136 501 370 138 501 minecraft:pink_terracotta
setblock 330 137 464 minecraft:red_nether_bricks
fill 330 137 465 330 140 465 minecraft:pink_terracotta
setblock 330 137 469 minecraft:red_nether_bricks
fill 330 137 470 330 140 470 minecraft:pink_terracotta
setblock 330 137 474 minecraft:red_nether_bricks
fill 330 137 475 330 139 475 minecraft:pink_terracotta
setblock 330 137 479 minecraft:red_nether_bricks
fill 330 137 480 330 140 480 minecraft:pink_terracotta
setblock 330 137 484 minecraft:red_nether_bricks
fill 330 137 485 330 140 485 minecraft:pink_terracotta
setblock 330 137 489 minecraft:red_nether_bricks
setblock 330 137 490 minecraft:white_concrete
fill 330 137 496 330 138 496 minecraft:white_concrete
setblock 330 137 499 minecraft:red_nether_bricks
fill 330 137 500 330 138 500 minecraft:pink_terracotta
setblock 330 137 504 minecraft:red_nether_bricks
fill 331 137 464 334 137 464 minecraft:pink_terracotta
setblock 331 137 468 minecraft:red_nether_bricks
fill 331 137 469 331 138 469 minecraft:pink_terracotta
setblock 331 137 474 minecraft:pink_terracotta
setblock 331 137 478 minecraft:red_nether_bricks
fill 331 137 479 331 138 479 minecraft:pink_terracotta
setblock 331 137 483 minecraft:red_nether_bricks
fill 331 137 484 331 138 484 minecraft:pink_terracotta
setblock 331 137 503 minecraft:red_nether_bricks
fill 331 137 504 334 137 504 minecraft:pink_terracotta
fill 332 137 503 332 138 503 minecraft:pink_terracotta
setblock 333 137 465 minecraft:pink_terracotta
setblock 334 137 465 minecraft:red_nether_bricks
setblock 335 137 464 minecraft:red_nether_bricks
fill 335 137 465 338 137 465 minecraft:pink_terracotta
setblock 335 137 504 minecraft:red_nether_bricks
fill 336 137 464 336 140 464 minecraft:pink_terracotta
setblock 336 137 503 minecraft:red_nether_bricks
fill 336 137 504 336 140 504 minecraft:pink_terracotta
fill 337 137 503 337 140 503 minecraft:pink_terracotta
setblock 339 137 465 minecraft:red_nether_bricks
setblock 340 137 464 minecraft:red_nether_bricks
fill 340 137 465 340 140 465 minecraft:pink_terracotta
setblock 340 137 504 minecraft:red_nether_bricks
fill 341 137 464 341 140 464 minecraft:pink_terracotta
fill 341 137 466 342 137 466 minecraft:pink_terracotta
setblock 341 137 503 minecraft:red_nether_bricks
fill 341 137 504 341 140 504 minecraft:pink_terracotta
setblock 342 137 502 minecraft:red_nether_bricks
fill 342 137 503 342 140 503 minecraft:pink_terracotta
setblock 343 137 466 minecraft:red_nether_bricks
setblock 343 137 501 minecraft:red_nether_bricks
fill 343 137 502 343 140 502 minecraft:pink_terracotta
setblock 344 137 465 minecraft:red_nether_bricks
fill 344 137 466 344 140 466 minecraft:pink_terracotta
fill 344 137 501 344 139 501 minecraft:pink_terracotta
setblock 345 137 464 minecraft:red_nether_bricks
fill 345 137 465 345 140 465 minecraft:pink_terracotta
setblock 345 137 504 minecraft:red_nether_bricks
fill 346 137 464 346 140 464 minecraft:pink_terracotta
setblock 346 137 503 minecraft:red_nether_bricks
fill 346 137 504 346 140 504 minecraft:pink_terracotta
setblock 347 137 502 minecraft:red_nether_bricks
fill 347 137 503 347 140 503 minecraft:pink_terracotta
setblock 348 137 501 minecraft:red_nether_bricks
fill 348 137 502 348 140 502 minecraft:pink_terracotta
setblock 349 137 465 minecraft:red_nether_bricks
setblock 349 137 501 minecraft:pink_terracotta
setblock 350 137 464 minecraft:red_nether_bricks
fill 350 137 465 350 139 465 minecraft:pink_terracotta
setblock 350 137 504 minecraft:red_nether_bricks
fill 351 137 464 351 140 464 minecraft:pink_terracotta
setblock 351 137 503 minecraft:red_nether_bricks
fill 351 137 504 351 140 504 minecraft:pink_terracotta
setblock 352 137 502 minecraft:red_nether_bricks
fill 352 137 503 352 139 503 minecraft:pink_terracotta
setblock 353 137 502 minecraft:pink_terracotta
setblock 355 137 504 minecraft:red_nether_bricks
setblock 356 137 503 minecraft:red_nether_bricks
fill 356 137 504 359 137 504 minecraft:pink_terracotta
fill 357 137 503 360 137 503 minecraft:pink_terracotta
setblock 359 137 464 minecraft:pink_terracotta
setblock 360 137 464 minecraft:red_nether_bricks
setblock 360 137 504 minecraft:red_nether_bricks
fill 361 137 464 364 137 464 minecraft:pink_terracotta
setblock 361 137 503 minecraft:red_nether_bricks
fill 361 137 504 361 140 504 minecraft:pink_terracotta
fill 362 137 503 362 140 503 minecraft:pink_terracotta
setblock 363 137 465 minecraft:pink_terracotta
schedule function dropper:buildpart/115_5 1t
