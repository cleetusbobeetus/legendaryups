fill 95 204 332 95 204 335 minecraft:stone
setblock 95 204 336 minecraft:stripped_spruce_log
fill 95 204 337 95 204 339 minecraft:stone
fill 95 204 343 95 204 345 minecraft:stone
setblock 95 204 346 minecraft:stripped_spruce_log
fill 95 204 347 95 204 350 minecraft:stone
setblock 95 204 351 minecraft:stripped_spruce_log
fill 95 204 352 95 204 355 minecraft:stone
setblock 95 204 356 minecraft:stripped_spruce_log
fill 95 204 357 95 207 357 minecraft:stone
fill 95 204 359 95 204 360 minecraft:stone
setblock 95 204 361 minecraft:stripped_spruce_log
fill 95 204 362 95 205 363 minecraft:stone
fill 96 204 323 96 204 324 minecraft:stone
setblock 96 204 325 minecraft:stripped_spruce_log
fill 96 204 326 96 204 329 minecraft:stone
setblock 96 204 330 minecraft:stripped_spruce_log
fill 96 204 331 96 207 331 minecraft:stone
setblock 96 204 350 minecraft:stripped_spruce_log
setblock 96 204 351 minecraft:stone
fill 96 204 363 97 204 363 minecraft:stone
setblock 97 204 323 minecraft:stone
setblock 97 204 324 minecraft:stripped_spruce_log
setblock 97 204 325 minecraft:stone
setblock 97 204 329 minecraft:stripped_spruce_log
fill 97 204 330 97 205 330 minecraft:stone
setblock 98 204 323 minecraft:stripped_spruce_log
fill 98 204 324 101 204 324 minecraft:stone
setblock 98 204 363 minecraft:stripped_spruce_log
fill 99 204 323 102 204 323 minecraft:stone
setblock 102 204 324 minecraft:stripped_spruce_log
setblock 102 204 363 minecraft:stone
setblock 103 204 323 minecraft:stripped_spruce_log
fill 103 204 324 106 204 324 minecraft:stone
setblock 103 204 363 minecraft:stripped_spruce_log
fill 104 204 323 107 204 323 minecraft:stone
fill 104 204 363 107 204 363 minecraft:stone
setblock 106 204 325 minecraft:stripped_spruce_log
fill 106 204 362 108 204 362 minecraft:stone
setblock 107 204 324 minecraft:stripped_spruce_log
fill 107 204 325 107 205 325 minecraft:stone
setblock 108 204 323 minecraft:stripped_spruce_log
fill 108 204 324 111 204 324 minecraft:stone
setblock 108 204 363 minecraft:stripped_spruce_log
fill 109 204 323 112 204 323 minecraft:stone
setblock 109 204 361 minecraft:stone
setblock 109 204 362 minecraft:stripped_spruce_log
fill 109 204 363 112 204 363 minecraft:stone
setblock 110 204 361 minecraft:stripped_spruce_log
fill 110 204 362 113 204 362 minecraft:stone
setblock 111 204 325 minecraft:stripped_spruce_log
fill 111 204 361 111 205 361 minecraft:stone
setblock 112 204 324 minecraft:stripped_spruce_log
setblock 112 204 325 minecraft:stone
setblock 113 204 323 minecraft:stripped_spruce_log
fill 113 204 324 114 204 324 minecraft:stone
setblock 113 204 363 minecraft:stripped_spruce_log
fill 114 204 323 116 204 323 minecraft:stone
setblock 114 204 362 minecraft:stripped_spruce_log
fill 114 204 363 116 205 363 minecraft:stone
setblock 116 204 364 minecraft:diamond_block
fill 117 204 364 117 247 364 minecraft:andesite
fill 126 204 323 127 204 323 minecraft:stone
setblock 128 204 323 minecraft:stripped_spruce_log
fill 128 204 324 131 204 324 minecraft:stone
fill 129 204 323 132 204 323 minecraft:stone
fill 129 204 325 130 204 325 minecraft:stone
fill 129 204 363 132 204 363 minecraft:stone
setblock 131 204 325 minecraft:stripped_spruce_log
fill 131 204 326 132 204 326 minecraft:stone
setblock 132 204 324 minecraft:stripped_spruce_log
fill 132 204 325 132 206 325 minecraft:stone
fill 132 204 327 132 204 328 minecraft:stone
setblock 132 204 329 minecraft:stripped_spruce_log
fill 132 204 330 132 207 330 minecraft:stone
setblock 132 204 334 minecraft:stripped_spruce_log
setblock 132 204 348 minecraft:stone
setblock 132 204 349 minecraft:stripped_spruce_log
setblock 132 204 350 minecraft:stone
setblock 133 204 323 minecraft:stripped_spruce_log
fill 133 204 324 133 207 324 minecraft:stone
setblock 133 204 328 minecraft:stripped_spruce_log
fill 133 204 329 133 207 329 minecraft:stone
setblock 133 204 332 minecraft:stone
setblock 133 204 333 minecraft:stripped_spruce_log
fill 133 204 334 133 207 334 minecraft:stone
setblock 133 204 338 minecraft:stripped_spruce_log
setblock 133 204 343 minecraft:stripped_spruce_log
setblock 133 204 344 minecraft:stone
setblock 133 204 348 minecraft:stripped_spruce_log
fill 133 204 349 133 206 349 minecraft:stone
setblock 133 204 353 minecraft:stripped_spruce_log
setblock 133 204 363 minecraft:stripped_spruce_log
fill 134 204 323 134 207 323 minecraft:stone
setblock 134 204 326 minecraft:stone
setblock 134 204 327 minecraft:stripped_spruce_log
fill 134 204 328 134 207 328 minecraft:stone
setblock 134 204 331 minecraft:stone
setblock 134 204 332 minecraft:stripped_spruce_log
fill 134 204 333 134 207 333 minecraft:stone
setblock 134 204 336 minecraft:stone
setblock 134 204 337 minecraft:stripped_spruce_log
fill 134 204 338 134 207 338 minecraft:stone
fill 134 204 340 134 204 341 minecraft:stone
setblock 134 204 342 minecraft:stripped_spruce_log
fill 134 204 343 134 205 343 minecraft:stone
setblock 134 204 346 minecraft:stone
setblock 134 204 347 minecraft:stripped_spruce_log
fill 134 204 348 134 206 348 minecraft:stone
setblock 134 204 351 minecraft:stone
setblock 134 204 352 minecraft:stripped_spruce_log
fill 134 204 353 134 207 353 minecraft:stone
setblock 135 204 326 minecraft:stripped_spruce_log
fill 135 204 327 135 207 327 minecraft:stone
setblock 135 204 331 minecraft:stripped_spruce_log
fill 135 204 332 135 207 332 minecraft:stone
setblock 135 204 336 minecraft:stripped_spruce_log
fill 135 204 337 135 207 337 minecraft:stone
setblock 135 204 340 minecraft:stone
setblock 135 204 341 minecraft:stripped_spruce_log
fill 135 204 342 135 206 342 minecraft:stone
setblock 135 204 346 minecraft:stripped_spruce_log
fill 135 204 347 135 207 347 minecraft:stone
setblock 135 204 351 minecraft:stripped_spruce_log
fill 135 204 352 135 207 352 minecraft:stone
setblock 135 204 356 minecraft:stripped_spruce_log
fill 135 204 357 135 205 357 minecraft:stone
fill 136 204 332 136 224 332 minecraft:andesite
setblock 136 204 333 minecraft:gold_block
setblock 136 204 341 minecraft:diamond_block
fill 136 204 356 136 229 356 minecraft:andesite
setblock 94 205 341 minecraft:raw_gold_block
fill 94 205 359 94 247 359 minecraft:andesite
fill 95 205 323 95 205 324 minecraft:stone
setblock 95 205 325 minecraft:stripped_spruce_log
fill 95 205 326 95 205 329 minecraft:stone
setblock 95 205 330 minecraft:stripped_spruce_log
fill 95 205 331 95 205 334 minecraft:stone
setblock 95 205 335 minecraft:stripped_spruce_log
fill 95 205 336 95 205 338 minecraft:stone
fill 95 205 346 95 205 349 minecraft:stone
setblock 95 205 350 minecraft:stripped_spruce_log
fill 95 205 351 95 205 354 minecraft:stone
setblock 95 205 355 minecraft:stripped_spruce_log
fill 95 205 356 95 208 356 minecraft:stone
setblock 95 205 359 minecraft:stone
setblock 95 205 360 minecraft:stripped_spruce_log
setblock 95 205 361 minecraft:stone
setblock 96 205 323 minecraft:stone
setblock 96 205 324 minecraft:stripped_spruce_log
fill 96 205 325 96 205 328 minecraft:stone
setblock 96 205 329 minecraft:stripped_spruce_log
fill 96 205 330 96 208 330 minecraft:stone
fill 96 205 332 96 205 333 minecraft:stone
setblock 96 205 334 minecraft:stripped_spruce_log
setblock 96 205 363 minecraft:stone
setblock 97 205 323 minecraft:stripped_spruce_log
fill 97 205 324 99 205 324 minecraft:stone
setblock 97 205 325 minecraft:light[level=12]
setblock 97 205 328 minecraft:stripped_spruce_log
setblock 97 205 329 minecraft:stone
setblock 97 205 332 minecraft:light[level=12]
setblock 97 205 339 minecraft:light[level=12]
setblock 97 205 346 minecraft:light[level=12]
setblock 97 205 353 minecraft:light[level=12]
setblock 97 205 360 minecraft:light[level=12]
fill 98 205 323 101 205 323 minecraft:stone
setblock 102 205 323 minecraft:stripped_spruce_log
setblock 102 205 363 minecraft:stripped_spruce_log
fill 103 205 323 105 205 324 minecraft:stone
fill 103 205 363 106 205 363 minecraft:stone
setblock 104 205 325 minecraft:light[level=12]
setblock 104 205 332 minecraft:light[level=12]
setblock 104 205 339 minecraft:light[level=12]
setblock 104 205 346 minecraft:light[level=12]
setblock 104 205 353 minecraft:light[level=12]
setblock 104 205 360 minecraft:light[level=12]
fill 105 205 362 107 205 362 minecraft:stone
setblock 106 205 323 minecraft:stone
setblock 106 205 324 minecraft:stripped_spruce_log
setblock 107 205 323 minecraft:stripped_spruce_log
fill 107 205 324 110 205 324 minecraft:stone
fill 107 205 361 107 210 361 minecraft:cobbled_deepslate
setblock 107 205 363 minecraft:stripped_spruce_log
fill 108 205 323 111 205 323 minecraft:stone
setblock 108 205 362 minecraft:stripped_spruce_log
fill 108 205 363 111 205 363 minecraft:stone
setblock 109 205 361 minecraft:stripped_spruce_log
fill 109 205 362 112 205 362 minecraft:stone
setblock 110 205 325 minecraft:stripped_spruce_log
fill 110 205 361 110 206 361 minecraft:stone
setblock 111 205 324 minecraft:stripped_spruce_log
setblock 111 205 325 minecraft:light[level=12]
setblock 111 205 332 minecraft:light[level=12]
setblock 111 205 339 minecraft:light[level=12]
setblock 111 205 346 minecraft:light[level=12]
setblock 111 205 353 minecraft:light[level=12]
setblock 111 205 360 minecraft:light[level=12]
setblock 112 205 323 minecraft:stripped_spruce_log
fill 112 205 324 113 205 324 minecraft:stone
setblock 112 205 363 minecraft:stripped_spruce_log
fill 113 205 323 115 205 323 minecraft:stone
setblock 113 205 362 minecraft:stripped_spruce_log
fill 113 205 363 113 208 363 minecraft:stone
setblock 114 205 322 minecraft:gold_block
setblock 114 205 362 minecraft:stone
fill 115 205 322 115 209 322 minecraft:andesite
fill 116 205 364 116 206 364 minecraft:andesite
setblock 118 205 325 minecraft:light[level=12]
setblock 118 205 332 minecraft:light[level=12]
setblock 118 205 339 minecraft:light[level=12]
setblock 118 205 346 minecraft:light[level=12]
setblock 118 205 353 minecraft:light[level=12]
setblock 118 205 360 minecraft:light[level=12]
fill 119 205 322 120 239 322 minecraft:andesite
setblock 121 205 322 minecraft:raw_gold_block
setblock 125 205 325 minecraft:light[level=12]
setblock 125 205 332 minecraft:light[level=12]
setblock 125 205 339 minecraft:light[level=12]
setblock 125 205 346 minecraft:light[level=12]
setblock 125 205 353 minecraft:light[level=12]
setblock 125 205 360 minecraft:light[level=12]
setblock 126 205 323 minecraft:stone
setblock 127 205 323 minecraft:stripped_spruce_log
fill 128 205 323 130 205 324 minecraft:stone
setblock 129 205 325 minecraft:stone
setblock 130 205 325 minecraft:stripped_spruce_log
fill 130 205 363 131 205 363 minecraft:stone
setblock 131 205 323 minecraft:stone
setblock 131 205 324 minecraft:stripped_spruce_log
fill 131 205 325 131 206 325 minecraft:stone
setblock 131 205 364 minecraft:raw_gold_block
setblock 132 205 323 minecraft:stripped_spruce_log
fill 132 205 324 132 207 324 minecraft:stone
setblock 132 205 327 minecraft:stone
setblock 132 205 328 minecraft:stripped_spruce_log
fill 132 205 329 132 207 329 minecraft:stone
fill 132 205 331 132 205 332 minecraft:stone
setblock 132 205 333 minecraft:stripped_spruce_log
fill 132 205 334 132 207 335 minecraft:stone
setblock 132 205 339 minecraft:light[level=12]
setblock 132 205 346 minecraft:light[level=12]
setblock 132 205 353 minecraft:light[level=12]
setblock 132 205 360 minecraft:light[level=12]
setblock 132 205 363 minecraft:stripped_spruce_log
fill 133 205 323 133 208 323 minecraft:stone
fill 133 205 325 134 205 325 minecraft:stone
setblock 133 205 327 minecraft:stripped_spruce_log
fill 133 205 328 133 208 328 minecraft:stone
fill 133 205 330 134 205 330 minecraft:stone
setblock 133 205 332 minecraft:stripped_spruce_log
fill 133 205 333 133 208 333 minecraft:stone
fill 133 205 335 133 205 336 minecraft:stone
setblock 133 205 337 minecraft:stripped_spruce_log
setblock 133 205 338 minecraft:stone
fill 133 205 345 134 205 345 minecraft:stone
setblock 133 205 347 minecraft:stripped_spruce_log
setblock 133 205 348 minecraft:stone
fill 133 205 350 134 205 350 minecraft:stone
setblock 133 205 352 minecraft:stripped_spruce_log
setblock 133 205 353 minecraft:stone
setblock 134 205 326 minecraft:stripped_spruce_log
fill 134 205 327 134 208 327 minecraft:stone
setblock 134 205 331 minecraft:stripped_spruce_log
fill 134 205 332 134 208 332 minecraft:stone
setblock 134 205 335 minecraft:stone
setblock 134 205 336 minecraft:stripped_spruce_log
fill 134 205 337 134 208 337 minecraft:stone
setblock 134 205 340 minecraft:stone
setblock 134 205 341 minecraft:stripped_spruce_log
setblock 134 205 342 minecraft:stone
setblock 134 205 346 minecraft:stripped_spruce_log
fill 134 205 347 134 206 347 minecraft:stone
setblock 134 205 351 minecraft:stripped_spruce_log
fill 134 205 352 134 207 352 minecraft:stone
fill 134 205 354 134 205 355 minecraft:stone
setblock 135 205 325 minecraft:stripped_spruce_log
fill 135 205 326 135 208 326 minecraft:stone
setblock 135 205 330 minecraft:stripped_spruce_log
fill 135 205 331 135 208 331 minecraft:stone
setblock 135 205 335 minecraft:stripped_spruce_log
fill 135 205 336 135 208 336 minecraft:stone
setblock 135 205 340 minecraft:stripped_spruce_log
fill 135 205 341 135 206 341 minecraft:stone
setblock 135 205 345 minecraft:stripped_spruce_log
fill 135 205 346 135 206 346 minecraft:stone
setblock 135 205 350 minecraft:stripped_spruce_log
fill 135 205 351 135 208 351 minecraft:stone
setblock 135 205 354 minecraft:stone
setblock 135 205 355 minecraft:stripped_spruce_log
fill 135 205 356 135 207 356 minecraft:stone
fill 136 205 333 136 243 333 minecraft:andesite
fill 136 205 341 136 247 341 minecraft:andesite
setblock 136 205 357 minecraft:raw_iron_block
fill 136 205 358 136 221 360 minecraft:andesite
fill 94 206 341 94 238 341 minecraft:andesite
setblock 94 206 342 minecraft:raw_iron_block
fill 94 206 343 94 208 345 minecraft:andesite
setblock 95 206 323 minecraft:stone
setblock 95 206 324 minecraft:stripped_spruce_log
fill 95 206 325 95 206 328 minecraft:stone
setblock 95 206 329 minecraft:stripped_spruce_log
fill 95 206 330 95 206 333 minecraft:stone
setblock 95 206 334 minecraft:stripped_spruce_log
fill 95 206 335 95 206 337 minecraft:stone
setblock 95 206 348 minecraft:stone
setblock 95 206 349 minecraft:stripped_spruce_log
fill 95 206 350 95 206 353 minecraft:stone
setblock 95 206 354 minecraft:stripped_spruce_log
fill 95 206 355 95 209 355 minecraft:stone
setblock 95 206 359 minecraft:stripped_spruce_log
setblock 95 206 363 minecraft:stone
fill 95 206 364 103 208 364 minecraft:andesite
setblock 96 206 323 minecraft:stripped_spruce_log
fill 96 206 324 96 206 327 minecraft:stone
setblock 96 206 328 minecraft:stripped_spruce_log
fill 96 206 329 96 208 329 minecraft:stone
setblock 96 206 332 minecraft:stone
setblock 96 206 333 minecraft:stripped_spruce_log
setblock 96 206 334 minecraft:stone
fill 97 206 323 97 206 324 minecraft:stone
fill 98 206 323 100 206 323 minecraft:stone
setblock 101 206 323 minecraft:stripped_spruce_log
fill 102 206 323 105 206 323 minecraft:stone
fill 102 206 363 105 206 363 minecraft:stone
setblock 104 206 324 minecraft:stone
setblock 104 206 364 minecraft:gold_block
setblock 105 206 324 minecraft:stripped_spruce_log
fill 105 206 362 106 206 362 minecraft:stone
fill 105 206 364 105 234 364 minecraft:andesite
setblock 106 206 323 minecraft:stripped_spruce_log
fill 106 206 324 109 206 324 minecraft:stone
setblock 106 206 363 minecraft:stripped_spruce_log
fill 107 206 323 110 206 323 minecraft:stone
setblock 107 206 362 minecraft:stripped_spruce_log
fill 107 206 363 110 206 363 minecraft:stone
setblock 108 206 361 minecraft:stripped_spruce_log
fill 108 206 362 111 206 362 minecraft:stone
fill 109 206 361 109 207 361 minecraft:stone
setblock 110 206 324 minecraft:stripped_spruce_log
setblock 111 206 323 minecraft:stripped_spruce_log
setblock 111 206 324 minecraft:stone
setblock 111 206 363 minecraft:stripped_spruce_log
fill 112 206 323 113 206 323 minecraft:stone
setblock 112 206 362 minecraft:stripped_spruce_log
fill 112 206 363 112 209 363 minecraft:stone
setblock 113 206 362 minecraft:stone
fill 114 206 322 114 247 322 minecraft:andesite
fill 114 206 363 115 206 363 minecraft:stone
fill 121 206 322 121 243 322 minecraft:andesite
setblock 126 206 323 minecraft:stripped_spruce_log
fill 127 206 323 130 206 323 minecraft:stone
fill 128 206 324 129 206 324 minecraft:stone
setblock 130 206 324 minecraft:stripped_spruce_log
setblock 130 206 325 minecraft:stone
setblock 131 206 323 minecraft:stripped_spruce_log
fill 131 206 324 131 207 324 minecraft:stone
fill 131 206 364 131 230 364 minecraft:andesite
fill 132 206 323 132 209 323 minecraft:stone
setblock 132 206 327 minecraft:stripped_spruce_log
setblock 132 206 328 minecraft:stone
setblock 132 206 331 minecraft:stone
setblock 132 206 332 minecraft:stripped_spruce_log
fill 132 206 333 132 208 333 minecraft:stone
setblock 133 206 325 minecraft:stone
setblock 133 206 326 minecraft:stripped_spruce_log
fill 133 206 327 133 207 327 minecraft:stone
setblock 133 206 330 minecraft:stone
setblock 133 206 331 minecraft:stripped_spruce_log
fill 133 206 332 133 209 332 minecraft:stone
setblock 133 206 335 minecraft:stone
setblock 133 206 336 minecraft:stripped_spruce_log
fill 133 206 337 133 207 337 minecraft:stone
setblock 133 206 350 minecraft:stone
setblock 133 206 351 minecraft:stripped_spruce_log
setblock 133 206 352 minecraft:stone
setblock 134 206 324 minecraft:stone
setblock 134 206 325 minecraft:stripped_spruce_log
fill 134 206 326 134 208 326 minecraft:stone
setblock 134 206 329 minecraft:stone
setblock 134 206 330 minecraft:stripped_spruce_log
fill 134 206 331 134 209 331 minecraft:stone
setblock 134 206 334 minecraft:stone
setblock 134 206 335 minecraft:stripped_spruce_log
fill 134 206 336 134 209 336 minecraft:stone
setblock 134 206 339 minecraft:stone
setblock 134 206 346 minecraft:stone
setblock 134 206 349 minecraft:stone
setblock 134 206 350 minecraft:stripped_spruce_log
fill 134 206 351 134 207 351 minecraft:stone
setblock 134 206 354 minecraft:stone
setblock 135 206 324 minecraft:stripped_spruce_log
fill 135 206 325 135 209 325 minecraft:stone
setblock 135 206 329 minecraft:stripped_spruce_log
fill 135 206 330 135 209 330 minecraft:stone
setblock 135 206 334 minecraft:stripped_spruce_log
fill 135 206 335 135 209 335 minecraft:stone
setblock 135 206 339 minecraft:stripped_spruce_log
fill 135 206 340 135 207 340 minecraft:stone
setblock 135 206 344 minecraft:stripped_spruce_log
setblock 135 206 345 minecraft:stone
setblock 135 206 349 minecraft:stripped_spruce_log
fill 135 206 350 135 207 350 minecraft:stone
setblock 135 206 354 minecraft:stripped_spruce_log
fill 135 206 355 135 208 355 minecraft:stone
fill 136 206 357 136 210 357 minecraft:andesite
setblock 94 207 324 minecraft:gold_block
setblock 94 207 330 minecraft:diamond_block
fill 94 207 342 94 245 342 minecraft:andesite
setblock 94 207 348 minecraft:raw_iron_block
fill 94 207 349 94 248 349 minecraft:andesite
setblock 95 207 323 minecraft:stripped_spruce_log
fill 95 207 324 95 207 327 minecraft:stone
setblock 95 207 328 minecraft:stripped_spruce_log
fill 95 207 329 95 207 332 minecraft:stone
setblock 95 207 333 minecraft:stripped_spruce_log
fill 95 207 334 95 208 336 minecraft:stone
fill 95 207 350 95 207 352 minecraft:stone
setblock 95 207 353 minecraft:stripped_spruce_log
fill 95 207 354 95 209 354 minecraft:stone
setblock 95 207 358 minecraft:stripped_spruce_log
fill 96 207 323 98 207 323 minecraft:stone
fill 96 207 325 96 207 326 minecraft:stone
setblock 96 207 327 minecraft:stripped_spruce_log
fill 96 207 328 96 208 328 minecraft:stone
setblock 96 207 332 minecraft:stripped_spruce_log
setblock 96 207 333 minecraft:stone
fill 101 207 323 104 207 323 minecraft:stone
fill 102 207 363 104 207 363 minecraft:stone
fill 104 207 364 104 244 364 minecraft:andesite
setblock 105 207 323 minecraft:stripped_spruce_log
setblock 105 207 362 minecraft:stone
setblock 105 207 363 minecraft:stripped_spruce_log
fill 106 207 323 108 207 324 minecraft:stone
setblock 106 207 362 minecraft:stripped_spruce_log
fill 106 207 363 109 207 363 minecraft:stone
fill 107 207 362 110 207 362 minecraft:stone
setblock 108 207 361 minecraft:stone
setblock 109 207 323 minecraft:stone
setblock 109 207 324 minecraft:stripped_spruce_log
setblock 110 207 323 minecraft:stripped_spruce_log
setblock 110 207 363 minecraft:stripped_spruce_log
fill 111 207 323 112 207 323 minecraft:stone
setblock 111 207 362 minecraft:stripped_spruce_log
fill 111 207 363 111 210 363 minecraft:stone
setblock 112 207 362 minecraft:stone
setblock 114 207 363 minecraft:stone
setblock 116 207 364 minecraft:gold_block
fill 127 207 323 129 207 323 minecraft:stone
setblock 128 207 322 minecraft:diamond_block
setblock 129 207 324 minecraft:stripped_spruce_log
setblock 130 207 323 minecraft:stripped_spruce_log
setblock 130 207 324 minecraft:stone
fill 131 207 323 131 209 323 minecraft:stone
fill 132 207 325 132 208 325 minecraft:iron_bars
setblock 132 207 331 minecraft:stripped_spruce_log
fill 132 207 332 132 208 332 minecraft:stone
setblock 133 207 326 minecraft:stone
setblock 133 207 330 minecraft:stripped_spruce_log
fill 133 207 331 133 210 331 minecraft:stone
setblock 133 207 335 minecraft:stripped_spruce_log
fill 133 207 336 133 208 336 minecraft:stone
setblock 134 207 325 minecraft:stone
setblock 134 207 329 minecraft:stripped_spruce_log
fill 134 207 330 134 210 330 minecraft:stone
setblock 134 207 334 minecraft:stripped_spruce_log
fill 134 207 335 134 210 335 minecraft:stone
setblock 134 207 350 minecraft:stone
setblock 135 207 323 minecraft:stripped_spruce_log
fill 135 207 324 135 208 324 minecraft:stone
setblock 135 207 328 minecraft:stripped_spruce_log
fill 135 207 329 135 210 329 minecraft:stone
setblock 135 207 333 minecraft:stripped_spruce_log
fill 135 207 334 135 210 334 minecraft:stone
setblock 135 207 338 minecraft:stripped_spruce_log
fill 135 207 339 135 208 339 minecraft:stone
setblock 135 207 348 minecraft:stripped_spruce_log
setblock 135 207 349 minecraft:stone
setblock 135 207 353 minecraft:stripped_spruce_log
fill 135 207 354 135 208 354 minecraft:stone
fill 136 207 344 136 247 344 minecraft:andesite
setblock 136 207 345 minecraft:gold_block
fill 136 207 346 136 214 347 minecraft:andesite
fill 94 208 324 94 211 324 minecraft:andesite
fill 94 208 330 94 224 330 minecraft:andesite
fill 94 208 348 94 247 348 minecraft:andesite
fill 95 208 323 95 208 326 minecraft:stone
setblock 95 208 327 minecraft:stripped_spruce_log
fill 95 208 328 95 208 331 minecraft:stone
setblock 95 208 332 minecraft:stripped_spruce_log
fill 95 208 333 95 211 333 minecraft:stone
setblock 95 208 352 minecraft:stripped_spruce_log
setblock 95 208 353 minecraft:stone
setblock 95 208 357 minecraft:stripped_spruce_log
fill 95 208 358 95 209 358 minecraft:stone
setblock 96 208 331 minecraft:stripped_spruce_log
setblock 96 208 332 minecraft:stone
fill 102 208 363 103 208 363 minecraft:stone
setblock 103 208 323 minecraft:stone
setblock 104 208 323 minecraft:stripped_spruce_log
setblock 104 208 363 minecraft:stripped_spruce_log
fill 105 208 323 108 208 323 minecraft:stone
setblock 105 208 362 minecraft:stripped_spruce_log
fill 105 208 363 108 208 363 minecraft:stone
fill 106 208 361 106 210 361 minecraft:cobbled_deepslate
fill 106 208 362 109 208 362 minecraft:stone
fill 107 208 360 107 210 360 minecraft:cobbled_deepslate
fill 108 208 361 108 210 361 minecraft:cobbled_deepslate
setblock 109 208 323 minecraft:stripped_spruce_log
setblock 109 208 363 minecraft:stripped_spruce_log
setblock 110 208 323 minecraft:stone
setblock 110 208 362 minecraft:stripped_spruce_log
fill 110 208 363 110 211 363 minecraft:stone
setblock 111 208 362 minecraft:stone
fill 116 208 364 116 247 364 minecraft:andesite
setblock 122 208 322 minecraft:gold_block
fill 126 208 364 127 213 364 minecraft:andesite
fill 127 208 323 128 208 323 minecraft:stone
fill 128 208 322 128 223 322 minecraft:andesite
setblock 128 208 364 minecraft:raw_gold_block
setblock 129 208 323 minecraft:stripped_spruce_log
fill 129 208 364 130 247 364 minecraft:andesite
fill 130 208 323 130 209 323 minecraft:stone
setblock 132 208 324 minecraft:iron_bars
setblock 132 208 330 minecraft:stripped_spruce_log
setblock 132 208 331 minecraft:stone
setblock 132 208 334 minecraft:stone
setblock 133 208 329 minecraft:stripped_spruce_log
fill 133 208 330 133 209 330 minecraft:stone
setblock 133 208 334 minecraft:stripped_spruce_log
fill 133 208 335 133 210 335 minecraft:stone
setblock 134 208 323 minecraft:stripped_spruce_log
setblock 134 208 328 minecraft:stripped_spruce_log
fill 134 208 329 134 210 329 minecraft:stone
setblock 134 208 333 minecraft:stripped_spruce_log
fill 134 208 334 134 211 334 minecraft:stone
setblock 135 208 327 minecraft:stripped_spruce_log
fill 135 208 328 135 211 328 minecraft:stone
setblock 135 208 332 minecraft:stripped_spruce_log
fill 135 208 333 135 211 333 minecraft:stone
setblock 135 208 337 minecraft:stripped_spruce_log
fill 135 208 338 135 211 338 minecraft:stone
setblock 135 208 352 minecraft:stripped_spruce_log
setblock 135 208 353 minecraft:stone
fill 136 208 345 136 247 345 minecraft:andesite
fill 94 209 343 94 218 344 minecraft:andesite
setblock 94 209 345 minecraft:gold_block
setblock 94 209 357 minecraft:raw_iron_block
setblock 95 209 325 minecraft:stone
setblock 95 209 326 minecraft:stripped_spruce_log
fill 95 209 327 95 209 330 minecraft:stone
setblock 95 209 331 minecraft:stripped_spruce_log
fill 95 209 332 95 211 332 minecraft:stone
fill 95 209 334 95 209 335 minecraft:stone
setblock 95 209 356 minecraft:stripped_spruce_log
fill 95 209 357 95 212 357 minecraft:stone
fill 95 209 364 96 238 364 minecraft:andesite
setblock 97 209 364 minecraft:diamond_block
fill 98 209 364 103 221 364 minecraft:andesite
setblock 102 209 363 minecraft:stone
setblock 103 209 363 minecraft:stripped_spruce_log
fill 104 209 323 107 209 323 minecraft:stone
setblock 104 209 362 minecraft:stripped_spruce_log
fill 104 209 363 107 209 363 minecraft:stone
fill 105 209 322 108 212 322 minecraft:andesite
fill 105 209 362 108 209 362 minecraft:stone
setblock 108 209 323 minecraft:stripped_spruce_log
setblock 108 209 363 minecraft:stripped_spruce_log
setblock 109 209 322 minecraft:raw_gold_block
setblock 109 209 323 minecraft:stone
setblock 109 209 362 minecraft:stripped_spruce_log
fill 109 209 363 109 212 363 minecraft:stone
fill 110 209 362 110 210 362 minecraft:stone
fill 122 209 322 122 210 322 minecraft:andesite
setblock 128 209 323 minecraft:stripped_spruce_log
fill 128 209 364 128 224 364 minecraft:andesite
setblock 129 209 323 minecraft:stone
setblock 133 209 329 minecraft:stone
setblock 133 209 333 minecraft:stripped_spruce_log
fill 133 209 334 133 210 334 minecraft:stone
setblock 134 209 327 minecraft:stripped_spruce_log
setblock 134 209 328 minecraft:stone
setblock 134 209 332 minecraft:stripped_spruce_log
fill 134 209 333 134 212 333 minecraft:stone
setblock 134 209 337 minecraft:stripped_spruce_log
setblock 135 209 326 minecraft:stripped_spruce_log
fill 135 209 327 135 210 327 minecraft:stone
setblock 135 209 331 minecraft:stripped_spruce_log
fill 135 209 332 135 212 332 minecraft:stone
setblock 135 209 336 minecraft:stripped_spruce_log
fill 135 209 337 135 212 337 minecraft:stone
setblock 136 209 352 minecraft:raw_iron_block
fill 136 209 353 136 227 353 minecraft:andesite
fill 94 210 345 94 247 345 minecraft:andesite
fill 94 210 357 94 235 357 minecraft:andesite
fill 95 210 328 95 210 329 minecraft:stone
setblock 95 210 330 minecraft:stripped_spruce_log
fill 95 210 331 95 211 331 minecraft:stone
setblock 95 210 334 minecraft:stone
setblock 95 210 335 minecraft:stripped_spruce_log
setblock 95 210 355 minecraft:stripped_spruce_log
fill 95 210 356 95 213 356 minecraft:stone
fill 97 210 364 97 248 364 minecraft:andesite
setblock 102 210 363 minecraft:stripped_spruce_log
fill 103 210 363 106 210 363 minecraft:stone
fill 104 210 362 107 210 362 minecraft:stone
setblock 106 210 323 minecraft:stone
setblock 106 210 360 minecraft:cobbled_deepslate
setblock 107 210 363 minecraft:stripped_spruce_log
setblock 108 210 360 minecraft:cobbled_deepslate
setblock 108 210 362 minecraft:stripped_spruce_log
fill 108 210 363 108 213 363 minecraft:stone
fill 109 210 322 109 226 322 minecraft:andesite
fill 109 210 362 109 213 362 minecraft:stone
setblock 115 210 322 minecraft:raw_gold_block
fill 122 210 335 123 210 337 minecraft:stripped_dark_oak_log
fill 123 210 334 127 210 334 minecraft:stripped_dark_oak_log
fill 123 210 338 127 210 338 minecraft:stripped_dark_oak_log
fill 124 210 333 126 210 333 minecraft:stripped_dark_oak_log
fill 124 210 339 126 210 339 minecraft:stripped_dark_oak_log
fill 127 210 335 128 210 337 minecraft:stripped_dark_oak_log
setblock 133 210 332 minecraft:stripped_spruce_log
setblock 133 210 333 minecraft:stone
setblock 134 210 331 minecraft:stripped_spruce_log
fill 134 210 332 134 212 332 minecraft:stone
setblock 134 210 336 minecraft:stripped_spruce_log
setblock 135 210 330 minecraft:stripped_spruce_log
fill 135 210 331 135 213 331 minecraft:stone
setblock 135 210 335 minecraft:stripped_spruce_log
fill 135 210 336 135 213 336 minecraft:stone
fill 136 210 352 136 247 352 minecraft:andesite
setblock 95 211 330 minecraft:stone
setblock 95 211 334 minecraft:stripped_spruce_log
setblock 95 211 358 minecraft:stone
setblock 97 211 325 minecraft:light[level=15]
setblock 97 211 332 minecraft:light[level=12]
setblock 97 211 333 minecraft:light[level=15]
setblock 97 211 339 minecraft:light[level=12]
setblock 97 211 341 minecraft:light[level=15]
setblock 97 211 346 minecraft:light[level=12]
setblock 97 211 349 minecraft:light[level=15]
setblock 97 211 353 minecraft:light[level=12]
setblock 97 211 357 minecraft:light[level=15]
setblock 97 211 360 minecraft:light[level=12]
setblock 101 211 363 minecraft:stripped_spruce_log
fill 102 211 363 105 211 363 minecraft:stone
fill 103 211 362 106 211 362 minecraft:stone
setblock 104 211 325 minecraft:light[level=12]
setblock 104 211 332 minecraft:light[level=12]
setblock 104 211 339 minecraft:light[level=12]
setblock 104 211 346 minecraft:light[level=12]
setblock 104 211 353 minecraft:light[level=12]
setblock 104 211 360 minecraft:light[level=12]
setblock 105 211 325 minecraft:light[level=15]
setblock 105 211 333 minecraft:light[level=15]
setblock 105 211 341 minecraft:light[level=15]
setblock 105 211 349 minecraft:light[level=15]
setblock 105 211 357 minecraft:light[level=15]
fill 106 211 361 107 211 361 minecraft:stone
setblock 106 211 363 minecraft:stripped_spruce_log
setblock 107 211 362 minecraft:stripped_spruce_log
fill 107 211 363 107 213 363 minecraft:stone
fill 108 211 362 108 213 362 minecraft:stone
setblock 111 211 325 minecraft:light[level=12]
setblock 111 211 332 minecraft:light[level=12]
setblock 111 211 339 minecraft:light[level=12]
setblock 111 211 346 minecraft:light[level=12]
setblock 111 211 353 minecraft:light[level=12]
setblock 111 211 360 minecraft:light[level=12]
setblock 111 211 363 minecraft:stripped_spruce_log
setblock 113 211 325 minecraft:light[level=15]
setblock 113 211 333 minecraft:light[level=15]
setblock 113 211 341 minecraft:light[level=15]
setblock 113 211 349 minecraft:light[level=15]
setblock 113 211 357 minecraft:light[level=15]
fill 115 211 322 115 221 322 minecraft:andesite
setblock 118 211 325 minecraft:light[level=12]
setblock 118 211 332 minecraft:light[level=12]
setblock 118 211 339 minecraft:light[level=12]
setblock 118 211 346 minecraft:light[level=12]
setblock 118 211 353 minecraft:light[level=12]
setblock 118 211 360 minecraft:light[level=12]
setblock 121 211 325 minecraft:light[level=15]
setblock 121 211 333 minecraft:light[level=15]
setblock 121 211 341 minecraft:light[level=15]
setblock 121 211 349 minecraft:light[level=15]
setblock 121 211 357 minecraft:light[level=15]
setblock 122 211 322 minecraft:raw_gold_block
fill 123 211 335 123 211 337 minecraft:stripped_dark_oak_log
fill 124 211 334 126 211 334 minecraft:stripped_dark_oak_log
fill 124 211 338 127 211 338 minecraft:stripped_dark_oak_log
setblock 125 211 325 minecraft:light[level=12]
setblock 125 211 332 minecraft:light[level=12]
setblock 125 211 339 minecraft:light[level=12]
setblock 125 211 346 minecraft:light[level=12]
setblock 125 211 353 minecraft:light[level=12]
setblock 125 211 360 minecraft:light[level=12]
fill 127 211 335 127 212 337 minecraft:stripped_dark_oak_log
setblock 129 211 325 minecraft:light[level=15]
setblock 129 211 333 minecraft:light[level=15]
setblock 129 211 341 minecraft:light[level=15]
setblock 129 211 349 minecraft:light[level=15]
setblock 129 211 357 minecraft:light[level=15]
setblock 132 211 325 minecraft:light[level=12]
setblock 132 211 332 minecraft:light[level=12]
setblock 132 211 339 minecraft:light[level=12]
setblock 132 211 346 minecraft:light[level=12]
setblock 132 211 353 minecraft:light[level=12]
setblock 132 211 360 minecraft:light[level=12]
setblock 134 211 330 minecraft:stripped_spruce_log
fill 134 211 331 134 212 331 minecraft:stone
setblock 134 211 335 minecraft:stripped_spruce_log
fill 134 211 336 134 213 336 minecraft:stone
setblock 135 211 329 minecraft:stripped_spruce_log
fill 135 211 330 135 213 330 minecraft:stone
setblock 135 211 334 minecraft:stripped_spruce_log
fill 135 211 335 135 213 335 minecraft:stone
setblock 136 211 357 minecraft:diamond_block
setblock 94 212 324 minecraft:diamond_block
setblock 95 212 358 minecraft:stripped_spruce_log
fill 95 212 359 95 213 360 minecraft:stone
fill 96 212 324 96 215 324 minecraft:spruce_log
fill 96 212 343 96 215 343 minecraft:spruce_log
fill 96 212 362 96 215 362 minecraft:spruce_log
setblock 100 212 363 minecraft:stripped_spruce_log
fill 101 212 363 104 212 363 minecraft:stone
fill 102 212 362 105 212 362 minecraft:stone
fill 104 212 361 106 212 361 minecraft:stone
setblock 105 212 363 minecraft:stripped_spruce_log
setblock 106 212 362 minecraft:stripped_spruce_log
fill 106 212 363 106 213 363 minecraft:stone
setblock 107 212 361 minecraft:stripped_spruce_log
fill 107 212 362 107 213 362 minecraft:stone
fill 108 212 361 108 213 361 minecraft:stone
setblock 110 212 363 minecraft:stripped_spruce_log
fill 115 212 324 115 215 324 minecraft:spruce_log
fill 115 212 362 115 215 362 minecraft:spruce_log
fill 122 212 322 122 228 322 minecraft:andesite
fill 123 212 336 123 212 337 minecraft:stripped_dark_oak_log
fill 124 212 338 126 212 338 minecraft:stripped_dark_oak_log
fill 125 212 334 126 212 334 minecraft:stripped_dark_oak_log
fill 134 212 324 134 215 324 minecraft:spruce_log
setblock 134 212 334 minecraft:stripped_spruce_log
fill 134 212 335 134 213 335 minecraft:stone
fill 134 212 343 134 215 343 minecraft:spruce_log
fill 134 212 362 134 215 362 minecraft:spruce_log
setblock 135 212 329 minecraft:stone
setblock 135 212 333 minecraft:stripped_spruce_log
fill 135 212 334 135 213 334 minecraft:stone
setblock 135 212 338 minecraft:stripped_spruce_log
fill 136 212 357 136 247 357 minecraft:andesite
fill 94 213 324 94 248 324 minecraft:andesite
setblock 95 213 357 minecraft:stripped_spruce_log
setblock 95 213 358 minecraft:stone
setblock 95 213 361 minecraft:stone
setblock 98 213 363 minecraft:stone
setblock 99 213 363 minecraft:stripped_spruce_log
setblock 100 213 362 minecraft:stripped_spruce_log
fill 100 213 363 103 213 363 minecraft:stone
fill 101 213 362 104 213 362 minecraft:stone
fill 102 213 361 105 213 361 minecraft:stone
setblock 104 213 323 minecraft:stripped_spruce_log
setblock 104 213 363 minecraft:stripped_spruce_log
fill 105 213 322 105 247 322 minecraft:andesite
setblock 105 213 323 minecraft:stone
setblock 105 213 362 minecraft:stripped_spruce_log
setblock 105 213 363 minecraft:stone
setblock 106 213 322 minecraft:gold_block
setblock 106 213 361 minecraft:stripped_spruce_log
setblock 106 213 362 minecraft:stone
fill 107 213 322 108 247 322 minecraft:andesite
setblock 107 213 361 minecraft:stone
setblock 109 213 363 minecraft:stripped_spruce_log
fill 110 213 363 111 213 363 minecraft:stone
fill 126 213 323 128 213 323 minecraft:stone
setblock 129 213 323 minecraft:stripped_spruce_log
setblock 134 213 333 minecraft:stripped_spruce_log
setblock 134 213 334 minecraft:stone
setblock 135 213 332 minecraft:stripped_spruce_log
setblock 135 213 333 minecraft:stone
setblock 135 213 337 minecraft:stripped_spruce_log
setblock 135 213 338 minecraft:stone
fill 106 214 322 106 221 322 minecraft:andesite
fill 126 214 364 126 245 364 minecraft:andesite
setblock 127 214 364 minecraft:gold_block
fill 94 215 332 94 243 333 minecraft:andesite
setblock 94 215 334 minecraft:raw_iron_block
fill 94 215 335 94 228 337 minecraft:andesite
setblock 97 215 322 minecraft:andesite
setblock 98 215 322 minecraft:raw_gold_block
fill 99 215 322 99 247 322 minecraft:andesite
fill 106 215 364 107 228 364 minecraft:andesite
setblock 108 215 364 minecraft:gold_block
fill 109 215 364 109 247 364 minecraft:andesite
fill 127 215 364 127 247 364 minecraft:andesite
fill 136 215 346 136 243 346 minecraft:andesite
setblock 136 215 347 minecraft:gold_block
setblock 94 216 326 minecraft:diamond_block
fill 94 216 334 94 247 334 minecraft:andesite
setblock 94 216 362 minecraft:gold_block
setblock 96 216 324 minecraft:glowstone
setblock 96 216 343 minecraft:glowstone
setblock 96 216 362 minecraft:glowstone
setblock 97 216 322 minecraft:raw_iron_block
fill 98 216 322 98 223 322 minecraft:andesite
fill 108 216 364 108 236 364 minecraft:andesite
setblock 115 216 324 minecraft:glowstone
setblock 115 216 362 minecraft:glowstone
setblock 134 216 324 minecraft:glowstone
setblock 134 216 343 minecraft:glowstone
setblock 134 216 362 minecraft:glowstone
fill 136 216 347 136 242 347 minecraft:andesite
fill 94 217 326 94 221 326 minecraft:andesite
fill 94 217 362 94 221 362 minecraft:andesite
fill 96 217 324 96 218 324 minecraft:spruce_log
fill 96 217 343 96 218 343 minecraft:spruce_log
fill 96 217 362 96 218 362 minecraft:spruce_log
fill 97 217 322 97 243 322 minecraft:andesite
setblock 97 217 325 minecraft:light[level=12]
setblock 97 217 332 minecraft:light[level=12]
setblock 97 217 339 minecraft:light[level=12]
setblock 97 217 346 minecraft:light[level=12]
setblock 97 217 353 minecraft:light[level=12]
setblock 97 217 360 minecraft:light[level=12]
setblock 104 217 325 minecraft:light[level=12]
setblock 104 217 332 minecraft:light[level=12]
setblock 104 217 339 minecraft:light[level=12]
setblock 104 217 346 minecraft:light[level=12]
setblock 104 217 353 minecraft:light[level=12]
setblock 104 217 360 minecraft:light[level=12]
setblock 111 217 325 minecraft:light[level=12]
setblock 111 217 332 minecraft:light[level=12]
setblock 111 217 339 minecraft:light[level=12]
setblock 111 217 346 minecraft:light[level=12]
setblock 111 217 353 minecraft:light[level=12]
setblock 111 217 360 minecraft:light[level=12]
fill 115 217 324 115 218 324 minecraft:spruce_log
fill 115 217 362 115 218 362 minecraft:spruce_log
setblock 117 217 322 minecraft:raw_iron_block
fill 118 217 322 118 247 322 minecraft:andesite
setblock 118 217 325 minecraft:light[level=12]
setblock 118 217 332 minecraft:light[level=12]
setblock 118 217 339 minecraft:light[level=12]
setblock 118 217 346 minecraft:light[level=12]
setblock 118 217 353 minecraft:light[level=12]
setblock 118 217 360 minecraft:light[level=12]
setblock 125 217 325 minecraft:light[level=12]
setblock 125 217 332 minecraft:light[level=12]
setblock 125 217 339 minecraft:light[level=12]
setblock 125 217 346 minecraft:light[level=12]
setblock 125 217 353 minecraft:light[level=12]
setblock 125 217 360 minecraft:light[level=12]
setblock 132 217 325 minecraft:light[level=12]
setblock 132 217 332 minecraft:light[level=12]
setblock 132 217 339 minecraft:light[level=12]
setblock 132 217 346 minecraft:light[level=12]
setblock 132 217 353 minecraft:light[level=12]
setblock 132 217 360 minecraft:light[level=12]
fill 134 217 324 134 218 324 minecraft:spruce_log
fill 134 217 343 134 218 343 minecraft:spruce_log
fill 134 217 362 134 218 362 minecraft:spruce_log
fill 95 218 323 95 218 363 minecraft:spruce_planks
fill 96 218 323 135 218 323 minecraft:spruce_planks
fill 96 218 325 96 218 342 minecraft:spruce_planks
fill 96 218 344 96 218 361 minecraft:spruce_planks
fill 96 218 363 135 218 363 minecraft:spruce_planks
fill 97 218 324 114 218 324 minecraft:spruce_planks
fill 97 218 362 114 218 362 minecraft:spruce_planks
setblock 101 218 322 minecraft:diamond_block
fill 116 218 324 133 218 324 minecraft:spruce_planks
fill 116 218 362 133 218 362 minecraft:spruce_planks
fill 117 218 322 117 245 322 minecraft:andesite
fill 124 218 322 124 231 322 minecraft:andesite
setblock 125 218 322 minecraft:gold_block
fill 126 218 322 126 220 322 minecraft:andesite
fill 134 218 325 135 218 342 minecraft:spruce_planks
fill 134 218 344 135 218 361 minecraft:spruce_planks
setblock 135 218 324 minecraft:spruce_planks
setblock 135 218 343 minecraft:spruce_planks
setblock 135 218 362 minecraft:spruce_planks
fill 136 218 328 136 243 328 minecraft:andesite
setblock 136 218 329 minecraft:raw_gold_block
fill 136 218 330 136 247 331 minecraft:andesite
fill 94 219 343 94 247 343 minecraft:andesite
setblock 94 219 344 minecraft:diamond_block
fill 94 219 360 94 243 360 minecraft:andesite
setblock 94 219 361 minecraft:gold_block
setblock 97 219 325 minecraft:light[level=15]
setblock 97 219 333 minecraft:light[level=15]
setblock 97 219 341 minecraft:light[level=15]
setblock 97 219 349 minecraft:light[level=15]
setblock 97 219 357 minecraft:light[level=15]
fill 101 219 322 101 244 322 minecraft:andesite
fill 103 219 322 103 247 322 minecraft:andesite
setblock 104 219 322 minecraft:gold_block
setblock 105 219 325 minecraft:light[level=15]
setblock 105 219 333 minecraft:light[level=15]
setblock 105 219 341 minecraft:light[level=15]
setblock 105 219 349 minecraft:light[level=15]
setblock 105 219 357 minecraft:light[level=15]
fill 106 219 334 113 219 336 minecraft:iron_block
fill 106 219 339 123 219 339 minecraft:iron_block
fill 107 219 331 122 219 331 minecraft:iron_block
fill 107 219 340 107 220 340 minecraft:iron_block
fill 108 219 330 108 220 330 minecraft:iron_block
fill 108 219 332 123 219 332 minecraft:iron_block
fill 108 219 337 113 219 338 minecraft:iron_block
fill 109 219 333 126 219 333 minecraft:iron_block
fill 109 219 340 124 219 340 minecraft:iron_block
fill 109 219 342 110 220 343 minecraft:iron_block
fill 110 219 328 112 220 328 minecraft:iron_block
fill 110 219 330 123 220 330 minecraft:iron_block
fill 110 219 341 125 219 341 minecraft:iron_block
fill 111 219 327 111 220 327 minecraft:iron_block
fill 111 219 329 120 220 329 minecraft:iron_block
fill 111 219 342 122 220 342 minecraft:iron_block
fill 112 219 343 121 220 343 minecraft:iron_block
fill 112 219 345 113 220 345 minecraft:iron_block
setblock 113 219 325 minecraft:light[level=15]
fill 113 219 344 118 220 344 minecraft:iron_block
fill 113 219 346 113 220 346 minecraft:iron_block
setblock 113 219 349 minecraft:light[level=15]
setblock 113 219 357 minecraft:light[level=15]
fill 114 219 326 115 220 328 minecraft:iron_block
setblock 114 219 334 minecraft:iron_block
setblock 114 219 338 minecraft:iron_block
fill 116 219 328 119 220 328 minecraft:iron_block
fill 117 219 345 118 220 346 minecraft:iron_block
fill 118 219 334 124 219 334 minecraft:iron_block
fill 118 219 338 126 219 338 minecraft:iron_block
fill 119 219 326 119 220 327 minecraft:iron_block
fill 119 219 335 124 219 337 minecraft:iron_block
fill 120 219 327 120 220 327 minecraft:iron_block
fill 120 219 344 122 220 344 minecraft:iron_block
setblock 121 219 325 minecraft:light[level=15]
fill 121 219 345 121 220 345 minecraft:iron_block
setblock 121 219 349 minecraft:light[level=15]
setblock 121 219 357 minecraft:light[level=15]
fill 122 219 329 123 220 329 minecraft:iron_block
fill 124 219 342 124 220 342 minecraft:iron_block
fill 125 219 322 125 243 322 minecraft:andesite
fill 125 219 332 125 220 332 minecraft:iron_block
fill 125 219 336 126 220 337 minecraft:iron_block
setblock 129 219 325 minecraft:light[level=15]
setblock 129 219 333 minecraft:light[level=15]
setblock 129 219 341 minecraft:light[level=15]
setblock 129 219 349 minecraft:light[level=15]
setblock 129 219 357 minecraft:light[level=15]
fill 131 219 322 134 223 322 minecraft:andesite
setblock 135 219 322 minecraft:diamond_block
fill 136 219 322 136 248 322 minecraft:andesite
fill 136 219 329 136 243 329 minecraft:andesite
fill 94 220 344 94 247 344 minecraft:andesite
fill 94 220 361 94 224 361 minecraft:andesite
fill 95 220 323 135 220 324 minecraft:cobbled_deepslate
setblock 95 220 325 minecraft:raw_gold_block
fill 95 220 326 95 220 330 minecraft:cobbled_deepslate
setblock 95 220 331 minecraft:raw_gold_block
fill 95 220 332 95 220 336 minecraft:cobbled_deepslate
setblock 95 220 337 minecraft:raw_gold_block
fill 95 220 338 95 220 342 minecraft:cobbled_deepslate
setblock 95 220 343 minecraft:raw_gold_block
fill 95 220 344 95 220 348 minecraft:cobbled_deepslate
setblock 95 220 349 minecraft:raw_gold_block
fill 95 220 350 95 220 354 minecraft:cobbled_deepslate
setblock 95 220 355 minecraft:raw_gold_block
fill 95 220 356 95 220 360 minecraft:cobbled_deepslate
setblock 95 220 361 minecraft:raw_gold_block
fill 95 220 362 135 220 363 minecraft:cobbled_deepslate
fill 96 220 325 96 220 327 minecraft:cobbled_deepslate
setblock 96 220 328 minecraft:raw_gold_block
fill 96 220 329 96 220 333 minecraft:cobbled_deepslate
setblock 96 220 334 minecraft:raw_gold_block
fill 96 220 335 96 220 339 minecraft:cobbled_deepslate
setblock 96 220 340 minecraft:raw_gold_block
fill 96 220 341 96 220 345 minecraft:cobbled_deepslate
setblock 96 220 346 minecraft:raw_gold_block
fill 96 220 347 96 220 351 minecraft:cobbled_deepslate
setblock 96 220 352 minecraft:raw_gold_block
fill 96 220 353 96 220 357 minecraft:cobbled_deepslate
setblock 96 220 358 minecraft:raw_gold_block
fill 96 220 359 96 220 361 minecraft:cobbled_deepslate
setblock 97 220 325 minecraft:raw_gold_block
fill 97 220 326 97 220 330 minecraft:cobbled_deepslate
setblock 97 220 331 minecraft:raw_gold_block
fill 97 220 332 97 220 336 minecraft:cobbled_deepslate
setblock 97 220 337 minecraft:raw_gold_block
fill 97 220 338 97 220 342 minecraft:cobbled_deepslate
setblock 97 220 343 minecraft:raw_gold_block
fill 97 220 344 97 220 348 minecraft:cobbled_deepslate
setblock 97 220 349 minecraft:raw_gold_block
fill 97 220 350 97 220 354 minecraft:cobbled_deepslate
setblock 97 220 355 minecraft:raw_gold_block
fill 97 220 356 97 220 360 minecraft:cobbled_deepslate
setblock 97 220 361 minecraft:raw_gold_block
fill 98 220 325 98 220 327 minecraft:cobbled_deepslate
setblock 98 220 328 minecraft:raw_gold_block
fill 98 220 329 98 220 333 minecraft:cobbled_deepslate
setblock 98 220 334 minecraft:raw_gold_block
fill 98 220 335 98 220 339 minecraft:cobbled_deepslate
setblock 98 220 340 minecraft:raw_gold_block
fill 98 220 341 98 220 345 minecraft:cobbled_deepslate
setblock 98 220 346 minecraft:raw_gold_block
fill 98 220 347 98 220 351 minecraft:cobbled_deepslate
setblock 98 220 352 minecraft:raw_gold_block
fill 98 220 353 98 220 357 minecraft:cobbled_deepslate
setblock 98 220 358 minecraft:raw_gold_block
fill 98 220 359 98 220 361 minecraft:cobbled_deepslate
setblock 99 220 325 minecraft:raw_gold_block
fill 99 220 326 99 220 330 minecraft:cobbled_deepslate
setblock 99 220 331 minecraft:raw_gold_block
fill 99 220 332 99 220 336 minecraft:cobbled_deepslate
setblock 99 220 337 minecraft:raw_gold_block
fill 99 220 338 99 220 342 minecraft:cobbled_deepslate
setblock 99 220 343 minecraft:raw_gold_block
fill 99 220 344 99 220 348 minecraft:cobbled_deepslate
setblock 99 220 349 minecraft:raw_gold_block
fill 99 220 350 99 220 354 minecraft:cobbled_deepslate
setblock 99 220 355 minecraft:raw_gold_block
fill 99 220 356 99 220 360 minecraft:cobbled_deepslate
setblock 99 220 361 minecraft:raw_gold_block
fill 100 220 325 100 220 327 minecraft:cobbled_deepslate
setblock 100 220 328 minecraft:raw_gold_block
fill 100 220 329 100 220 333 minecraft:cobbled_deepslate
setblock 100 220 334 minecraft:raw_gold_block
fill 100 220 335 100 220 339 minecraft:cobbled_deepslate
setblock 100 220 340 minecraft:raw_gold_block
fill 100 220 341 100 220 345 minecraft:cobbled_deepslate
setblock 100 220 346 minecraft:raw_gold_block
fill 100 220 347 100 220 351 minecraft:cobbled_deepslate
setblock 100 220 352 minecraft:raw_gold_block
fill 100 220 353 100 220 357 minecraft:cobbled_deepslate
setblock 100 220 358 minecraft:raw_gold_block
fill 100 220 359 100 220 361 minecraft:cobbled_deepslate
setblock 101 220 325 minecraft:raw_gold_block
fill 101 220 326 101 220 330 minecraft:cobbled_deepslate
setblock 101 220 331 minecraft:raw_gold_block
fill 101 220 332 101 220 336 minecraft:cobbled_deepslate
setblock 101 220 337 minecraft:raw_gold_block
fill 101 220 338 101 220 342 minecraft:cobbled_deepslate
setblock 101 220 343 minecraft:raw_gold_block
fill 101 220 344 101 220 348 minecraft:cobbled_deepslate
setblock 101 220 349 minecraft:raw_gold_block
fill 101 220 350 101 220 354 minecraft:cobbled_deepslate
setblock 101 220 355 minecraft:raw_gold_block
fill 101 220 356 101 220 360 minecraft:cobbled_deepslate
setblock 101 220 361 minecraft:raw_gold_block
fill 102 220 325 102 220 327 minecraft:cobbled_deepslate
setblock 102 220 328 minecraft:raw_gold_block
fill 102 220 329 102 220 333 minecraft:cobbled_deepslate
setblock 102 220 334 minecraft:raw_gold_block
fill 102 220 335 102 220 339 minecraft:cobbled_deepslate
setblock 102 220 340 minecraft:raw_gold_block
fill 102 220 341 102 220 345 minecraft:cobbled_deepslate
setblock 102 220 346 minecraft:raw_gold_block
fill 102 220 347 102 220 351 minecraft:cobbled_deepslate
setblock 102 220 352 minecraft:raw_gold_block
fill 102 220 353 102 220 357 minecraft:cobbled_deepslate
setblock 102 220 358 minecraft:raw_gold_block
fill 102 220 359 102 220 361 minecraft:cobbled_deepslate
setblock 103 220 325 minecraft:raw_gold_block
fill 103 220 326 103 220 330 minecraft:cobbled_deepslate
setblock 103 220 331 minecraft:raw_gold_block
fill 103 220 332 103 220 336 minecraft:cobbled_deepslate
setblock 103 220 337 minecraft:raw_gold_block
fill 103 220 338 103 220 342 minecraft:cobbled_deepslate
setblock 103 220 343 minecraft:raw_gold_block
fill 103 220 344 103 220 348 minecraft:cobbled_deepslate
setblock 103 220 349 minecraft:raw_gold_block
fill 103 220 350 103 220 354 minecraft:cobbled_deepslate
setblock 103 220 355 minecraft:raw_gold_block
fill 103 220 356 103 220 360 minecraft:cobbled_deepslate
setblock 103 220 361 minecraft:raw_gold_block
fill 104 220 322 104 247 322 minecraft:andesite
fill 104 220 325 104 220 327 minecraft:cobbled_deepslate
setblock 104 220 328 minecraft:raw_gold_block
fill 104 220 329 104 220 333 minecraft:cobbled_deepslate
setblock 104 220 334 minecraft:raw_gold_block
fill 104 220 335 104 220 339 minecraft:cobbled_deepslate
setblock 104 220 340 minecraft:raw_gold_block
fill 104 220 341 104 220 345 minecraft:cobbled_deepslate
setblock 104 220 346 minecraft:raw_gold_block
fill 104 220 347 104 220 351 minecraft:cobbled_deepslate
setblock 104 220 352 minecraft:raw_gold_block
fill 104 220 353 104 220 357 minecraft:cobbled_deepslate
setblock 104 220 358 minecraft:raw_gold_block
fill 104 220 359 104 220 361 minecraft:cobbled_deepslate
setblock 105 220 325 minecraft:raw_gold_block
fill 105 220 326 105 220 330 minecraft:cobbled_deepslate
setblock 105 220 331 minecraft:raw_gold_block
fill 105 220 332 105 220 336 minecraft:cobbled_deepslate
setblock 105 220 337 minecraft:raw_gold_block
fill 105 220 338 105 220 342 minecraft:cobbled_deepslate
setblock 105 220 343 minecraft:raw_gold_block
fill 105 220 344 105 220 348 minecraft:cobbled_deepslate
setblock 105 220 349 minecraft:raw_gold_block
fill 105 220 350 105 220 354 minecraft:cobbled_deepslate
setblock 105 220 355 minecraft:raw_gold_block
fill 105 220 356 105 220 360 minecraft:cobbled_deepslate
setblock 105 220 361 minecraft:raw_gold_block
fill 106 220 325 106 220 327 minecraft:cobbled_deepslate
setblock 106 220 328 minecraft:raw_gold_block
fill 106 220 329 106 220 333 minecraft:cobbled_deepslate
fill 106 220 334 112 220 336 minecraft:iron_block
fill 106 220 337 106 220 338 minecraft:cobbled_deepslate
fill 106 220 339 110 220 339 minecraft:iron_block
setblock 106 220 340 minecraft:raw_gold_block
fill 106 220 341 106 220 345 minecraft:cobbled_deepslate
setblock 106 220 346 minecraft:raw_gold_block
fill 106 220 347 106 220 351 minecraft:cobbled_deepslate
setblock 106 220 352 minecraft:raw_gold_block
fill 106 220 353 106 220 357 minecraft:cobbled_deepslate
setblock 106 220 358 minecraft:raw_gold_block
fill 106 220 359 106 220 361 minecraft:cobbled_deepslate
setblock 107 220 325 minecraft:raw_gold_block
fill 107 220 326 107 220 330 minecraft:cobbled_deepslate
fill 107 220 331 113 220 331 minecraft:iron_block
fill 107 220 332 107 220 333 minecraft:cobbled_deepslate
setblock 107 220 337 minecraft:raw_gold_block
setblock 107 220 338 minecraft:cobbled_deepslate
fill 107 220 341 108 220 342 minecraft:cobbled_deepslate
setblock 107 220 343 minecraft:raw_gold_block
fill 107 220 344 107 220 348 minecraft:cobbled_deepslate
setblock 107 220 349 minecraft:raw_gold_block
fill 107 220 350 107 220 354 minecraft:cobbled_deepslate
setblock 107 220 355 minecraft:raw_gold_block
fill 107 220 356 107 220 360 minecraft:cobbled_deepslate
setblock 107 220 361 minecraft:raw_gold_block
fill 108 220 325 108 220 327 minecraft:cobbled_deepslate
setblock 108 220 328 minecraft:raw_gold_block
fill 108 220 329 110 220 329 minecraft:cobbled_deepslate
fill 108 220 332 113 220 332 minecraft:iron_block
setblock 108 220 333 minecraft:cobbled_deepslate
fill 108 220 337 110 220 338 minecraft:iron_block
setblock 108 220 340 minecraft:raw_gold_block
fill 108 220 343 108 220 345 minecraft:cobbled_deepslate
setblock 108 220 346 minecraft:raw_gold_block
fill 108 220 347 108 220 351 minecraft:cobbled_deepslate
setblock 108 220 352 minecraft:raw_gold_block
fill 108 220 353 108 220 357 minecraft:cobbled_deepslate
setblock 108 220 358 minecraft:raw_gold_block
fill 108 220 359 108 220 361 minecraft:cobbled_deepslate
setblock 109 220 325 minecraft:raw_gold_block
fill 109 220 326 109 220 328 minecraft:cobbled_deepslate
setblock 109 220 330 minecraft:cobbled_deepslate
fill 109 220 333 113 220 333 minecraft:iron_block
fill 109 220 340 111 220 340 minecraft:iron_block
setblock 109 220 341 minecraft:cobbled_deepslate
fill 109 220 344 109 220 348 minecraft:cobbled_deepslate
setblock 109 220 349 minecraft:raw_gold_block
fill 109 220 350 109 220 354 minecraft:cobbled_deepslate
setblock 109 220 355 minecraft:raw_gold_block
fill 109 220 356 109 220 360 minecraft:cobbled_deepslate
setblock 109 220 361 minecraft:raw_gold_block
fill 110 220 325 110 220 327 minecraft:cobbled_deepslate
fill 110 220 341 112 220 341 minecraft:iron_block
fill 110 220 344 111 220 345 minecraft:cobbled_deepslate
setblock 110 220 346 minecraft:raw_gold_block
fill 110 220 347 110 220 351 minecraft:cobbled_deepslate
setblock 110 220 352 minecraft:raw_gold_block
fill 110 220 353 110 220 357 minecraft:cobbled_deepslate
setblock 110 220 358 minecraft:raw_gold_block
fill 110 220 359 110 220 361 minecraft:cobbled_deepslate
setblock 111 220 325 minecraft:raw_gold_block
fill 111 220 326 113 220 326 minecraft:cobbled_deepslate
fill 111 220 337 112 220 339 minecraft:gray_concrete
setblock 111 220 343 minecraft:raw_gold_block
fill 111 220 346 111 220 348 minecraft:cobbled_deepslate
setblock 111 220 349 minecraft:raw_gold_block
fill 111 220 350 111 220 354 minecraft:cobbled_deepslate
setblock 111 220 355 minecraft:raw_gold_block
fill 111 220 356 111 220 360 minecraft:cobbled_deepslate
setblock 111 220 361 minecraft:raw_gold_block
setblock 112 220 325 minecraft:cobbled_deepslate
fill 112 220 327 113 220 327 minecraft:cobbled_deepslate
fill 112 220 340 113 220 340 minecraft:gray_concrete
setblock 112 220 344 minecraft:cobbled_deepslate
setblock 112 220 346 minecraft:raw_gold_block
fill 112 220 347 112 220 351 minecraft:cobbled_deepslate
setblock 112 220 352 minecraft:raw_gold_block
fill 112 220 353 112 220 357 minecraft:cobbled_deepslate
setblock 112 220 358 minecraft:raw_gold_block
fill 112 220 359 112 220 361 minecraft:cobbled_deepslate
setblock 113 220 325 minecraft:raw_gold_block
setblock 113 220 328 minecraft:cobbled_deepslate
fill 113 220 334 113 220 338 minecraft:glowstone
setblock 113 220 339 minecraft:gray_concrete
setblock 113 220 341 minecraft:gray_concrete
fill 113 220 347 135 220 348 minecraft:cobbled_deepslate
setblock 113 220 349 minecraft:raw_gold_block
fill 113 220 350 113 220 354 minecraft:cobbled_deepslate
setblock 113 220 355 minecraft:raw_gold_block
fill 113 220 356 113 220 360 minecraft:cobbled_deepslate
setblock 113 220 361 minecraft:raw_gold_block
setblock 114 220 325 minecraft:cobbled_deepslate
fill 114 220 331 118 220 332 minecraft:gray_concrete
fill 114 220 333 114 220 334 minecraft:glowstone
fill 114 220 338 114 220 339 minecraft:glowstone
fill 114 220 340 118 220 341 minecraft:iron_block
fill 114 220 345 116 220 345 minecraft:cobbled_deepslate
setblock 114 220 346 minecraft:raw_gold_block
fill 114 220 349 114 220 351 minecraft:cobbled_deepslate
setblock 114 220 352 minecraft:raw_gold_block
fill 114 220 353 114 220 357 minecraft:cobbled_deepslate
setblock 114 220 358 minecraft:raw_gold_block
fill 114 220 359 114 220 361 minecraft:cobbled_deepslate
setblock 115 220 325 minecraft:raw_gold_block
fill 115 220 333 118 220 333 minecraft:glowstone
fill 115 220 339 118 220 339 minecraft:glowstone
setblock 115 220 346 minecraft:cobbled_deepslate
setblock 115 220 349 minecraft:raw_gold_block
fill 115 220 350 115 220 354 minecraft:cobbled_deepslate
setblock 115 220 355 minecraft:raw_gold_block
fill 115 220 356 115 220 360 minecraft:cobbled_deepslate
setblock 115 220 361 minecraft:raw_gold_block
fill 116 220 325 116 220 327 minecraft:cobbled_deepslate
setblock 116 220 346 minecraft:raw_gold_block
fill 116 220 349 116 220 351 minecraft:cobbled_deepslate
setblock 116 220 352 minecraft:raw_gold_block
fill 116 220 353 116 220 357 minecraft:cobbled_deepslate
setblock 116 220 358 minecraft:raw_gold_block
fill 116 220 359 116 220 361 minecraft:cobbled_deepslate
setblock 117 220 325 minecraft:raw_gold_block
fill 117 220 326 118 220 327 minecraft:cobbled_deepslate
setblock 117 220 349 minecraft:raw_gold_block
fill 117 220 350 117 220 354 minecraft:cobbled_deepslate
setblock 117 220 355 minecraft:raw_gold_block
fill 117 220 356 117 220 360 minecraft:cobbled_deepslate
setblock 117 220 361 minecraft:raw_gold_block
setblock 118 220 325 minecraft:cobbled_deepslate
fill 118 220 334 119 220 334 minecraft:glowstone
fill 118 220 338 119 220 338 minecraft:glowstone
fill 118 220 349 118 220 351 minecraft:cobbled_deepslate
setblock 118 220 352 minecraft:raw_gold_block
fill 118 220 353 118 220 357 minecraft:cobbled_deepslate
setblock 118 220 358 minecraft:raw_gold_block
fill 118 220 359 118 220 361 minecraft:cobbled_deepslate
setblock 119 220 325 minecraft:raw_gold_block
fill 119 220 331 122 220 333 minecraft:iron_block
fill 119 220 335 119 220 337 minecraft:glowstone
fill 119 220 339 119 220 341 minecraft:gray_concrete
fill 119 220 344 119 220 346 minecraft:cobbled_deepslate
setblock 119 220 349 minecraft:raw_gold_block
fill 119 220 350 119 220 354 minecraft:cobbled_deepslate
setblock 119 220 355 minecraft:raw_gold_block
fill 119 220 356 119 220 360 minecraft:cobbled_deepslate
setblock 119 220 361 minecraft:raw_gold_block
fill 120 220 325 120 220 326 minecraft:cobbled_deepslate
setblock 120 220 328 minecraft:raw_gold_block
fill 120 220 334 124 220 335 minecraft:iron_block
fill 120 220 336 120 220 340 minecraft:gray_concrete
fill 120 220 341 125 220 341 minecraft:iron_block
setblock 120 220 345 minecraft:cobbled_deepslate
setblock 120 220 346 minecraft:raw_gold_block
fill 120 220 349 120 220 351 minecraft:cobbled_deepslate
setblock 120 220 352 minecraft:raw_gold_block
fill 120 220 353 120 220 357 minecraft:cobbled_deepslate
setblock 120 220 358 minecraft:raw_gold_block
fill 120 220 359 120 220 361 minecraft:cobbled_deepslate
setblock 121 220 325 minecraft:raw_gold_block
fill 121 220 326 121 220 329 minecraft:cobbled_deepslate
fill 121 220 336 121 220 339 minecraft:gray_concrete
fill 121 220 340 124 220 340 minecraft:iron_block
setblock 121 220 346 minecraft:cobbled_deepslate
setblock 121 220 349 minecraft:raw_gold_block
fill 121 220 350 121 220 354 minecraft:cobbled_deepslate
setblock 121 220 355 minecraft:raw_gold_block
fill 121 220 356 121 220 360 minecraft:cobbled_deepslate
setblock 121 220 361 minecraft:raw_gold_block
fill 122 220 325 122 220 327 minecraft:cobbled_deepslate
setblock 122 220 328 minecraft:raw_gold_block
fill 122 220 336 123 220 339 minecraft:iron_block
setblock 122 220 343 minecraft:cobbled_deepslate
fill 122 220 345 135 220 345 minecraft:cobbled_deepslate
setblock 122 220 346 minecraft:raw_gold_block
fill 122 220 349 122 220 351 minecraft:cobbled_deepslate
setblock 122 220 352 minecraft:raw_gold_block
fill 122 220 353 122 220 357 minecraft:cobbled_deepslate
setblock 122 220 358 minecraft:raw_gold_block
fill 122 220 359 122 220 361 minecraft:cobbled_deepslate
setblock 123 220 325 minecraft:raw_gold_block
fill 123 220 326 123 220 328 minecraft:cobbled_deepslate
setblock 123 220 331 minecraft:raw_gold_block
fill 123 220 332 123 220 333 minecraft:iron_block
setblock 123 220 342 minecraft:cobbled_deepslate
setblock 123 220 343 minecraft:raw_gold_block
fill 123 220 344 135 220 344 minecraft:cobbled_deepslate
setblock 123 220 346 minecraft:cobbled_deepslate
setblock 123 220 349 minecraft:raw_gold_block
fill 123 220 350 123 220 354 minecraft:cobbled_deepslate
setblock 123 220 355 minecraft:raw_gold_block
fill 123 220 356 123 220 360 minecraft:cobbled_deepslate
setblock 123 220 361 minecraft:raw_gold_block
fill 124 220 325 124 220 327 minecraft:cobbled_deepslate
setblock 124 220 328 minecraft:raw_gold_block
fill 124 220 329 124 220 332 minecraft:cobbled_deepslate
fill 124 220 333 126 220 333 minecraft:iron_block
fill 124 220 336 124 220 338 minecraft:iron_block
fill 124 220 339 135 220 339 minecraft:cobbled_deepslate
setblock 124 220 343 minecraft:cobbled_deepslate
setblock 124 220 346 minecraft:raw_gold_block
fill 124 220 349 124 220 351 minecraft:cobbled_deepslate
setblock 124 220 352 minecraft:raw_gold_block
fill 124 220 353 124 220 357 minecraft:cobbled_deepslate
setblock 124 220 358 minecraft:raw_gold_block
fill 124 220 359 124 220 361 minecraft:cobbled_deepslate
setblock 125 220 325 minecraft:raw_gold_block
fill 125 220 326 125 220 330 minecraft:cobbled_deepslate
setblock 125 220 331 minecraft:raw_gold_block
fill 125 220 334 125 220 335 minecraft:cobbled_deepslate
fill 125 220 338 126 220 338 minecraft:iron_block
setblock 125 220 340 minecraft:cobbled_deepslate
fill 125 220 342 135 220 342 minecraft:cobbled_deepslate
setblock 125 220 343 minecraft:raw_gold_block
setblock 125 220 346 minecraft:cobbled_deepslate
setblock 125 220 349 minecraft:raw_gold_block
fill 125 220 350 125 220 354 minecraft:cobbled_deepslate
setblock 125 220 355 minecraft:raw_gold_block
fill 125 220 356 125 220 360 minecraft:cobbled_deepslate
setblock 125 220 361 minecraft:raw_gold_block
fill 126 220 325 126 220 327 minecraft:cobbled_deepslate
setblock 126 220 328 minecraft:raw_gold_block
fill 126 220 329 126 220 332 minecraft:cobbled_deepslate
setblock 126 220 334 minecraft:raw_gold_block
fill 126 220 335 135 220 335 minecraft:cobbled_deepslate
setblock 126 220 340 minecraft:raw_gold_block
fill 126 220 341 135 220 341 minecraft:cobbled_deepslate
setblock 126 220 343 minecraft:cobbled_deepslate
setblock 126 220 346 minecraft:raw_gold_block
fill 126 220 349 126 220 351 minecraft:cobbled_deepslate
setblock 126 220 352 minecraft:raw_gold_block
fill 126 220 353 126 220 357 minecraft:cobbled_deepslate
setblock 126 220 358 minecraft:raw_gold_block
fill 126 220 359 126 220 361 minecraft:cobbled_deepslate
setblock 127 220 325 minecraft:raw_gold_block
fill 127 220 326 127 220 330 minecraft:cobbled_deepslate
setblock 127 220 331 minecraft:raw_gold_block
fill 127 220 332 127 220 334 minecraft:cobbled_deepslate
fill 127 220 336 135 220 336 minecraft:cobbled_deepslate
setblock 127 220 337 minecraft:raw_gold_block
fill 127 220 338 135 220 338 minecraft:cobbled_deepslate
setblock 127 220 340 minecraft:cobbled_deepslate
setblock 127 220 343 minecraft:raw_gold_block
setblock 127 220 346 minecraft:cobbled_deepslate
setblock 127 220 349 minecraft:raw_gold_block
fill 127 220 350 127 220 354 minecraft:cobbled_deepslate
setblock 127 220 355 minecraft:raw_gold_block
fill 127 220 356 127 220 360 minecraft:cobbled_deepslate
setblock 127 220 361 minecraft:raw_gold_block
fill 128 220 325 128 220 327 minecraft:cobbled_deepslate
setblock 128 220 328 minecraft:raw_gold_block
fill 128 220 329 128 220 333 minecraft:cobbled_deepslate
setblock 128 220 334 minecraft:raw_gold_block
setblock 128 220 337 minecraft:cobbled_deepslate
setblock 128 220 340 minecraft:raw_gold_block
setblock 128 220 343 minecraft:cobbled_deepslate
setblock 128 220 346 minecraft:raw_gold_block
fill 128 220 349 128 220 351 minecraft:cobbled_deepslate
setblock 128 220 352 minecraft:raw_gold_block
fill 128 220 353 128 220 357 minecraft:cobbled_deepslate
setblock 128 220 358 minecraft:raw_gold_block
fill 128 220 359 128 220 361 minecraft:cobbled_deepslate
setblock 129 220 325 minecraft:raw_gold_block
fill 129 220 326 129 220 330 minecraft:cobbled_deepslate
setblock 129 220 331 minecraft:raw_gold_block
fill 129 220 332 129 220 334 minecraft:cobbled_deepslate
setblock 129 220 337 minecraft:raw_gold_block
setblock 129 220 340 minecraft:cobbled_deepslate
setblock 129 220 343 minecraft:raw_gold_block
setblock 129 220 346 minecraft:cobbled_deepslate
setblock 129 220 349 minecraft:raw_gold_block
fill 129 220 350 129 220 354 minecraft:cobbled_deepslate
setblock 129 220 355 minecraft:raw_gold_block
fill 129 220 356 129 220 360 minecraft:cobbled_deepslate
setblock 129 220 361 minecraft:raw_gold_block
fill 130 220 325 130 220 327 minecraft:cobbled_deepslate
setblock 130 220 328 minecraft:raw_gold_block
fill 130 220 329 130 220 333 minecraft:cobbled_deepslate
setblock 130 220 334 minecraft:raw_gold_block
setblock 130 220 337 minecraft:cobbled_deepslate
setblock 130 220 340 minecraft:raw_gold_block
setblock 130 220 343 minecraft:cobbled_deepslate
setblock 130 220 346 minecraft:raw_gold_block
fill 130 220 349 130 220 351 minecraft:cobbled_deepslate
setblock 130 220 352 minecraft:raw_gold_block
fill 130 220 353 130 220 357 minecraft:cobbled_deepslate
setblock 130 220 358 minecraft:raw_gold_block
fill 130 220 359 130 220 361 minecraft:cobbled_deepslate
setblock 131 220 325 minecraft:raw_gold_block
fill 131 220 326 131 220 330 minecraft:cobbled_deepslate
setblock 131 220 331 minecraft:raw_gold_block
fill 131 220 332 131 220 334 minecraft:cobbled_deepslate
setblock 131 220 337 minecraft:raw_gold_block
setblock 131 220 340 minecraft:cobbled_deepslate
setblock 131 220 343 minecraft:raw_gold_block
setblock 131 220 346 minecraft:cobbled_deepslate
setblock 131 220 349 minecraft:raw_gold_block
fill 131 220 350 131 220 354 minecraft:cobbled_deepslate
setblock 131 220 355 minecraft:raw_gold_block
fill 131 220 356 131 220 360 minecraft:cobbled_deepslate
setblock 131 220 361 minecraft:raw_gold_block
fill 132 220 325 132 220 327 minecraft:cobbled_deepslate
setblock 132 220 328 minecraft:raw_gold_block
fill 132 220 329 132 220 333 minecraft:cobbled_deepslate
setblock 132 220 334 minecraft:raw_gold_block
setblock 132 220 337 minecraft:cobbled_deepslate
setblock 132 220 340 minecraft:raw_gold_block
setblock 132 220 343 minecraft:cobbled_deepslate
setblock 132 220 346 minecraft:raw_gold_block
fill 132 220 349 132 220 351 minecraft:cobbled_deepslate
setblock 132 220 352 minecraft:raw_gold_block
fill 132 220 353 132 220 357 minecraft:cobbled_deepslate
setblock 132 220 358 minecraft:raw_gold_block
fill 132 220 359 132 220 361 minecraft:cobbled_deepslate
setblock 133 220 325 minecraft:raw_gold_block
fill 133 220 326 133 220 330 minecraft:cobbled_deepslate
setblock 133 220 331 minecraft:raw_gold_block
fill 133 220 332 133 220 334 minecraft:cobbled_deepslate
setblock 133 220 337 minecraft:raw_gold_block
setblock 133 220 340 minecraft:cobbled_deepslate
setblock 133 220 343 minecraft:raw_gold_block
setblock 133 220 346 minecraft:cobbled_deepslate
setblock 133 220 349 minecraft:raw_gold_block
fill 133 220 350 133 220 354 minecraft:cobbled_deepslate
setblock 133 220 355 minecraft:raw_gold_block
fill 133 220 356 133 220 360 minecraft:cobbled_deepslate
setblock 133 220 361 minecraft:raw_gold_block
fill 134 220 325 134 220 327 minecraft:cobbled_deepslate
setblock 134 220 328 minecraft:raw_gold_block
fill 134 220 329 134 220 333 minecraft:cobbled_deepslate
setblock 134 220 334 minecraft:raw_gold_block
setblock 134 220 337 minecraft:cobbled_deepslate
setblock 134 220 340 minecraft:raw_gold_block
setblock 134 220 343 minecraft:cobbled_deepslate
setblock 134 220 346 minecraft:raw_gold_block
fill 134 220 349 134 220 351 minecraft:cobbled_deepslate
setblock 134 220 352 minecraft:raw_gold_block
fill 134 220 353 134 220 357 minecraft:cobbled_deepslate
setblock 134 220 358 minecraft:raw_gold_block
fill 134 220 359 134 220 361 minecraft:cobbled_deepslate
fill 135 220 322 135 247 322 minecraft:andesite
setblock 135 220 325 minecraft:raw_gold_block
fill 135 220 326 135 220 330 minecraft:cobbled_deepslate
setblock 135 220 331 minecraft:raw_gold_block
fill 135 220 332 135 220 334 minecraft:cobbled_deepslate
setblock 135 220 337 minecraft:raw_gold_block
setblock 135 220 340 minecraft:cobbled_deepslate
setblock 135 220 343 minecraft:raw_gold_block
setblock 135 220 346 minecraft:cobbled_deepslate
setblock 135 220 349 minecraft:raw_gold_block
fill 135 220 350 135 220 354 minecraft:cobbled_deepslate
setblock 135 220 355 minecraft:raw_gold_block
fill 135 220 356 135 220 360 minecraft:cobbled_deepslate
setblock 135 220 361 minecraft:raw_gold_block
setblock 126 221 322 minecraft:diamond_block
setblock 136 221 337 minecraft:raw_iron_block
setblock 94 222 326 minecraft:raw_gold_block
setblock 94 222 362 minecraft:raw_iron_block
fill 98 222 364 99 223 364 minecraft:andesite
setblock 100 222 364 minecraft:raw_iron_block
fill 101 222 364 103 243 364 minecraft:andesite
setblock 106 222 322 minecraft:raw_gold_block
fill 111 222 364 111 245 364 minecraft:andesite
setblock 112 222 364 minecraft:raw_gold_block
setblock 115 222 322 minecraft:raw_gold_block
fill 126 222 322 126 236 322 minecraft:andesite
fill 136 222 337 136 248 337 minecraft:andesite
setblock 136 222 358 minecraft:diamond_block
fill 136 222 359 136 243 360 minecraft:andesite
fill 94 223 326 94 243 326 minecraft:andesite
fill 94 223 362 94 239 362 minecraft:andesite
setblock 97 223 325 minecraft:light[level=12]
setblock 97 223 332 minecraft:light[level=12]
setblock 97 223 339 minecraft:light[level=12]
setblock 97 223 346 minecraft:light[level=12]
setblock 97 223 353 minecraft:light[level=12]
setblock 97 223 360 minecraft:light[level=12]
fill 100 223 364 100 247 364 minecraft:andesite
setblock 104 223 325 minecraft:light[level=12]
setblock 104 223 332 minecraft:light[level=12]
setblock 104 223 339 minecraft:light[level=12]
setblock 104 223 346 minecraft:light[level=12]
setblock 104 223 353 minecraft:light[level=12]
setblock 104 223 360 minecraft:light[level=12]
fill 106 223 322 106 248 322 minecraft:andesite
setblock 111 223 325 minecraft:light[level=12]
setblock 111 223 332 minecraft:light[level=12]
setblock 111 223 339 minecraft:light[level=12]
setblock 111 223 346 minecraft:light[level=12]
setblock 111 223 353 minecraft:light[level=12]
setblock 111 223 360 minecraft:light[level=12]
fill 112 223 364 112 243 364 minecraft:andesite
fill 115 223 322 115 247 322 minecraft:andesite
setblock 118 223 325 minecraft:light[level=12]
setblock 118 223 332 minecraft:light[level=12]
setblock 118 223 339 minecraft:light[level=12]
setblock 118 223 346 minecraft:light[level=12]
setblock 118 223 353 minecraft:light[level=12]
setblock 118 223 360 minecraft:light[level=12]
setblock 125 223 325 minecraft:light[level=12]
setblock 125 223 332 minecraft:light[level=12]
setblock 125 223 339 minecraft:light[level=12]
setblock 125 223 346 minecraft:light[level=12]
setblock 125 223 353 minecraft:light[level=12]
setblock 125 223 360 minecraft:light[level=12]
setblock 132 223 325 minecraft:light[level=12]
setblock 132 223 332 minecraft:light[level=12]
setblock 132 223 339 minecraft:light[level=12]
setblock 132 223 346 minecraft:light[level=12]
setblock 132 223 353 minecraft:light[level=12]
setblock 132 223 360 minecraft:light[level=12]
setblock 136 223 350 minecraft:diamond_block
fill 136 223 358 136 245 358 minecraft:andesite
fill 95 224 323 95 224 325 minecraft:stone
setblock 95 224 326 minecraft:stripped_spruce_log
setblock 95 224 340 minecraft:stone
setblock 95 224 341 minecraft:stripped_spruce_log
fill 95 224 342 95 224 345 minecraft:stone
setblock 95 224 346 minecraft:stripped_spruce_log
fill 95 224 347 95 224 350 minecraft:stone
setblock 95 224 351 minecraft:stripped_spruce_log
fill 95 224 354 95 224 355 minecraft:stone
setblock 95 224 356 minecraft:stripped_spruce_log
fill 95 224 357 95 224 360 minecraft:stone
setblock 95 224 361 minecraft:stripped_spruce_log
fill 95 224 362 97 224 363 minecraft:stone
fill 96 224 323 96 224 324 minecraft:stone
fill 96 224 342 96 224 344 minecraft:stone
setblock 96 224 345 minecraft:stripped_spruce_log
fill 96 224 346 96 226 347 minecraft:stone
fill 96 224 357 96 224 359 minecraft:stone
setblock 96 224 360 minecraft:stripped_spruce_log
fill 96 224 361 99 224 361 minecraft:stone
setblock 97 224 323 minecraft:stone
setblock 97 224 324 minecraft:stripped_spruce_log
setblock 97 224 360 minecraft:stone
setblock 98 224 322 minecraft:raw_iron_block
setblock 98 224 323 minecraft:stripped_spruce_log
fill 98 224 324 101 224 324 minecraft:stone
setblock 98 224 362 minecraft:stone
setblock 98 224 363 minecraft:stripped_spruce_log
fill 98 224 364 98 245 364 minecraft:andesite
fill 99 224 323 102 224 323 minecraft:stone
setblock 99 224 362 minecraft:stripped_spruce_log
fill 99 224 363 102 224 363 minecraft:stone
setblock 99 224 364 minecraft:raw_gold_block
fill 100 224 325 102 225 325 minecraft:cobbled_deepslate
setblock 100 224 361 minecraft:stripped_spruce_log
fill 100 224 362 103 224 362 minecraft:stone
fill 101 224 326 101 225 326 minecraft:cobbled_deepslate
fill 101 224 361 102 224 361 minecraft:stone
setblock 102 224 324 minecraft:stripped_spruce_log
setblock 103 224 323 minecraft:stripped_spruce_log
setblock 103 224 363 minecraft:stripped_spruce_log
fill 104 224 323 105 224 323 minecraft:stone
setblock 104 224 362 minecraft:stripped_spruce_log
fill 104 224 363 107 224 363 minecraft:stone
fill 105 224 333 105 227 339 minecraft:iron_block
fill 106 224 331 106 227 332 minecraft:iron_block
fill 106 224 340 106 227 341 minecraft:iron_block
fill 107 224 329 107 227 330 minecraft:iron_block
fill 107 224 342 107 227 343 minecraft:iron_block
fill 108 224 328 108 224 329 minecraft:iron_block
fill 108 224 343 108 224 344 minecraft:iron_block
fill 109 224 325 109 229 325 minecraft:cobbled_deepslate
fill 109 224 327 109 227 328 minecraft:iron_block
fill 109 224 344 109 227 345 minecraft:iron_block
fill 110 224 327 110 227 327 minecraft:iron_block
fill 110 224 345 110 227 345 minecraft:iron_block
fill 111 224 326 112 227 326 minecraft:iron_block
fill 111 224 346 112 227 346 minecraft:iron_block
setblock 112 224 325 minecraft:cobbled_deepslate
fill 113 224 325 119 227 325 minecraft:iron_block
fill 113 224 347 119 227 347 minecraft:iron_block
fill 114 224 323 117 224 323 minecraft:stone
fill 115 224 363 117 224 363 minecraft:stone
setblock 117 224 324 minecraft:stripped_spruce_log
setblock 118 224 323 minecraft:stripped_spruce_log
fill 118 224 324 121 224 324 minecraft:stone
setblock 118 224 363 minecraft:stripped_spruce_log
fill 119 224 323 122 224 323 minecraft:stone
fill 119 224 363 122 224 363 minecraft:stone
setblock 120 224 325 minecraft:stone
fill 120 224 326 121 227 326 minecraft:iron_block
fill 120 224 346 121 227 346 minecraft:iron_block
fill 120 224 362 122 224 362 minecraft:stone
setblock 121 224 325 minecraft:stripped_spruce_log
setblock 122 224 324 minecraft:stripped_spruce_log
fill 122 224 325 123 226 325 minecraft:stone
fill 122 224 327 123 227 327 minecraft:iron_block
fill 122 224 345 123 227 345 minecraft:iron_block
setblock 123 224 323 minecraft:stripped_spruce_log
fill 123 224 324 126 224 324 minecraft:stone
fill 123 224 328 124 224 328 minecraft:iron_block
fill 123 224 344 124 224 344 minecraft:iron_block
setblock 123 224 363 minecraft:stripped_spruce_log
fill 124 224 323 127 224 323 minecraft:stone
fill 124 224 329 125 227 329 minecraft:iron_block
fill 124 224 343 125 227 343 minecraft:iron_block
fill 124 224 363 127 224 363 minecraft:stone
fill 125 224 330 125 227 330 minecraft:iron_block
fill 125 224 342 125 227 342 minecraft:iron_block
fill 126 224 331 126 227 332 minecraft:iron_block
fill 126 224 340 126 227 341 minecraft:iron_block
setblock 127 224 324 minecraft:stripped_spruce_log
fill 127 224 333 127 227 339 minecraft:iron_block
setblock 128 224 322 minecraft:gold_block
setblock 128 224 323 minecraft:stripped_spruce_log
fill 128 224 324 131 224 324 minecraft:stone
setblock 128 224 363 minecraft:stripped_spruce_log
fill 129 224 323 132 224 323 minecraft:stone
fill 129 224 363 132 224 363 minecraft:stone
setblock 131 224 322 minecraft:raw_iron_block
fill 132 224 322 134 233 322 minecraft:andesite
setblock 132 224 324 minecraft:stripped_spruce_log
fill 132 224 357 132 232 357 minecraft:iron_bars
setblock 133 224 323 minecraft:stripped_spruce_log
fill 133 224 324 135 225 324 minecraft:stone
setblock 133 224 363 minecraft:stripped_spruce_log
fill 134 224 323 135 226 323 minecraft:stone
fill 134 224 325 134 224 326 minecraft:stone
setblock 134 224 362 minecraft:stripped_spruce_log
fill 134 224 363 135 226 363 minecraft:stone
setblock 135 224 325 minecraft:stone
setblock 135 224 326 minecraft:stripped_spruce_log
fill 135 224 327 135 226 328 minecraft:stone
setblock 135 224 341 minecraft:stripped_spruce_log
fill 135 224 342 135 224 345 minecraft:stone
fill 135 224 359 135 224 360 minecraft:stone
setblock 135 224 361 minecraft:stripped_spruce_log
fill 135 224 362 135 227 362 minecraft:stone
fill 136 224 350 136 247 350 minecraft:andesite
setblock 94 225 330 minecraft:diamond_block
setblock 94 225 361 minecraft:raw_gold_block
fill 95 225 323 95 225 324 minecraft:stone
setblock 95 225 325 minecraft:stripped_spruce_log
fill 95 225 326 95 227 327 minecraft:stone
fill 95 225 341 95 225 344 minecraft:stone
setblock 95 225 345 minecraft:stripped_spruce_log
fill 95 225 346 95 225 349 minecraft:stone
setblock 95 225 350 minecraft:stripped_spruce_log
fill 95 225 351 95 225 354 minecraft:stone
setblock 95 225 355 minecraft:stripped_spruce_log
fill 95 225 356 95 225 359 minecraft:stone
setblock 95 225 360 minecraft:stripped_spruce_log
fill 95 225 361 96 225 363 minecraft:stone
setblock 96 225 323 minecraft:stone
setblock 96 225 324 minecraft:stripped_spruce_log
fill 96 225 325 96 228 325 minecraft:stone
fill 96 225 342 96 225 343 minecraft:stone
setblock 96 225 344 minecraft:stripped_spruce_log
fill 96 225 345 96 228 345 minecraft:stone
setblock 96 225 348 minecraft:stone
setblock 96 225 349 minecraft:stripped_spruce_log
setblock 96 225 358 minecraft:stone
setblock 96 225 359 minecraft:stripped_spruce_log
fill 96 225 360 96 228 360 minecraft:stone
setblock 97 225 323 minecraft:stripped_spruce_log
fill 97 225 324 100 225 324 minecraft:stone
fill 97 225 361 97 225 362 minecraft:stone
setblock 97 225 363 minecraft:stripped_spruce_log
fill 98 225 322 98 243 322 minecraft:andesite
fill 98 225 323 101 225 323 minecraft:stone
setblock 98 225 361 minecraft:stone
setblock 98 225 362 minecraft:stripped_spruce_log
fill 98 225 363 101 225 363 minecraft:stone
setblock 99 225 361 minecraft:stripped_spruce_log
fill 99 225 362 102 225 362 minecraft:stone
fill 99 225 364 99 243 364 minecraft:andesite
setblock 100 225 361 minecraft:stone
setblock 101 225 324 minecraft:stripped_spruce_log
setblock 102 225 323 minecraft:stripped_spruce_log
setblock 102 225 363 minecraft:stripped_spruce_log
fill 103 225 323 104 226 323 minecraft:stone
setblock 103 225 362 minecraft:stripped_spruce_log
fill 103 225 363 106 225 363 minecraft:stone
fill 104 225 333 104 225 339 minecraft:iron_block
fill 105 225 331 105 226 332 minecraft:iron_block
fill 105 225 340 105 226 341 minecraft:iron_block
fill 106 225 329 106 226 330 minecraft:iron_block
fill 106 225 333 106 226 339 minecraft:iron_block
fill 106 225 342 106 226 343 minecraft:iron_block
fill 107 225 328 107 226 328 minecraft:iron_block
fill 107 225 331 107 226 333 minecraft:iron_block
fill 107 225 339 107 226 341 minecraft:iron_block
fill 107 225 344 107 226 344 minecraft:iron_block
fill 108 225 327 108 226 327 minecraft:iron_block
fill 108 225 328 108 226 328 minecraft:light_gray_concrete
fill 108 225 329 108 226 330 minecraft:iron_block
fill 108 225 342 108 226 343 minecraft:iron_block
fill 108 225 344 108 226 344 minecraft:light_gray_concrete
fill 108 225 345 108 226 345 minecraft:iron_block
fill 109 225 326 110 226 326 minecraft:iron_block
fill 109 225 329 109 226 329 minecraft:light_gray_concrete
fill 109 225 343 109 226 343 minecraft:light_gray_concrete
fill 109 225 346 110 226 346 minecraft:iron_block
fill 110 225 328 110 226 328 minecraft:iron_block
fill 110 225 330 110 226 330 minecraft:light_gray_concrete
fill 110 225 342 110 226 342 minecraft:light_gray_concrete
fill 110 225 344 110 226 344 minecraft:iron_block
fill 111 225 325 112 226 325 minecraft:iron_block
fill 111 225 327 113 226 327 minecraft:iron_block
fill 111 225 331 111 226 331 minecraft:light_gray_concrete
fill 111 225 335 112 226 337 minecraft:white_concrete
fill 111 225 341 111 226 341 minecraft:light_gray_concrete
fill 111 225 345 113 226 345 minecraft:iron_block
fill 111 225 347 112 226 347 minecraft:iron_block
fill 112 225 332 112 226 332 minecraft:light_gray_concrete
fill 112 225 333 112 226 334 minecraft:white_concrete
fill 112 225 338 112 226 339 minecraft:white_concrete
fill 112 225 340 112 226 340 minecraft:light_gray_concrete
fill 113 225 324 119 226 324 minecraft:iron_block
fill 113 225 326 119 226 326 minecraft:iron_block
fill 113 225 332 113 226 333 minecraft:white_concrete
fill 113 225 339 113 226 340 minecraft:white_concrete
fill 113 225 346 119 226 346 minecraft:iron_block
fill 113 225 348 119 226 348 minecraft:iron_block
fill 114 225 323 116 225 323 minecraft:stone
fill 114 225 332 119 226 332 minecraft:white_concrete
fill 114 225 340 119 226 340 minecraft:white_concrete
fill 115 225 331 117 226 331 minecraft:white_concrete
fill 115 225 341 117 226 341 minecraft:white_concrete
fill 115 225 363 116 225 363 minecraft:stone
setblock 117 225 323 minecraft:stripped_spruce_log
setblock 117 225 363 minecraft:stripped_spruce_log
fill 118 225 323 121 225 323 minecraft:stone
fill 118 225 363 121 225 363 minecraft:stone
fill 119 225 327 121 226 327 minecraft:iron_block
fill 119 225 333 120 226 333 minecraft:white_concrete
fill 119 225 339 120 226 339 minecraft:white_concrete
fill 119 225 345 121 226 345 minecraft:iron_block
setblock 120 225 324 minecraft:stone
fill 120 225 325 121 226 325 minecraft:iron_block
fill 120 225 332 120 226 332 minecraft:light_gray_concrete
fill 120 225 334 120 226 338 minecraft:white_concrete
fill 120 225 340 120 226 340 minecraft:light_gray_concrete
fill 120 225 347 121 226 347 minecraft:iron_block
setblock 121 225 324 minecraft:stripped_spruce_log
fill 121 225 331 121 226 331 minecraft:light_gray_concrete
fill 121 225 335 121 226 337 minecraft:white_concrete
fill 121 225 341 121 226 341 minecraft:light_gray_concrete
setblock 122 225 323 minecraft:stripped_spruce_log
fill 122 225 324 125 225 324 minecraft:stone
fill 122 225 326 123 226 326 minecraft:iron_block
fill 122 225 328 123 226 328 minecraft:iron_block
fill 122 225 330 122 226 330 minecraft:light_gray_concrete
fill 122 225 342 122 226 342 minecraft:light_gray_concrete
fill 122 225 344 123 226 344 minecraft:iron_block
fill 122 225 346 123 226 346 minecraft:iron_block
setblock 122 225 363 minecraft:stripped_spruce_log
fill 123 225 323 126 225 323 minecraft:stone
fill 123 225 329 123 226 329 minecraft:light_gray_concrete
fill 123 225 343 123 226 343 minecraft:light_gray_concrete
fill 123 225 363 126 225 363 minecraft:stone
fill 124 225 327 124 226 327 minecraft:iron_block
fill 124 225 328 124 226 328 minecraft:light_gray_concrete
fill 124 225 330 124 226 330 minecraft:iron_block
fill 124 225 342 124 226 342 minecraft:iron_block
fill 124 225 344 124 226 344 minecraft:light_gray_concrete
fill 124 225 345 124 226 345 minecraft:iron_block
fill 125 225 328 125 226 328 minecraft:iron_block
fill 125 225 331 125 226 333 minecraft:iron_block
fill 125 225 339 125 226 341 minecraft:iron_block
fill 125 225 344 125 226 344 minecraft:iron_block
setblock 126 225 324 minecraft:stripped_spruce_log
fill 126 225 329 126 226 330 minecraft:iron_block
fill 126 225 333 126 226 339 minecraft:iron_block
fill 126 225 342 126 226 343 minecraft:iron_block
setblock 127 225 323 minecraft:stripped_spruce_log
fill 127 225 324 130 225 324 minecraft:stone
fill 127 225 331 127 226 332 minecraft:iron_block
fill 127 225 340 127 226 341 minecraft:iron_block
setblock 127 225 363 minecraft:stripped_spruce_log
fill 128 225 322 128 244 322 minecraft:andesite
fill 128 225 323 131 225 323 minecraft:stone
fill 128 225 333 128 225 339 minecraft:iron_block
fill 128 225 363 131 225 363 minecraft:stone
setblock 128 225 364 minecraft:raw_gold_block
setblock 131 225 322 minecraft:diamond_block
setblock 131 225 324 minecraft:stripped_spruce_log
setblock 132 225 323 minecraft:stripped_spruce_log
fill 132 225 324 132 228 324 minecraft:stone
setblock 132 225 363 minecraft:stripped_spruce_log
fill 133 225 323 133 228 323 minecraft:stone
fill 133 225 363 133 228 363 minecraft:stone
setblock 134 225 325 minecraft:stone
setblock 134 225 326 minecraft:stripped_spruce_log
fill 134 225 362 134 227 362 minecraft:stone
setblock 135 225 325 minecraft:stripped_spruce_log
fill 135 225 326 135 228 326 minecraft:stone
setblock 135 225 329 minecraft:stone
fill 135 225 342 135 225 344 minecraft:stone
setblock 135 225 345 minecraft:stripped_spruce_log
fill 135 225 346 135 228 346 minecraft:stone
setblock 135 225 359 minecraft:stone
setblock 135 225 360 minecraft:stripped_spruce_log
fill 135 225 361 135 228 361 minecraft:stone
setblock 136 225 332 minecraft:raw_iron_block
fill 94 226 330 94 244 330 minecraft:andesite
fill 94 226 361 94 244 361 minecraft:andesite
setblock 95 226 323 minecraft:stone
setblock 95 226 324 minecraft:stripped_spruce_log
fill 95 226 325 95 229 325 minecraft:stone
fill 95 226 341 95 226 343 minecraft:stone
setblock 95 226 344 minecraft:stripped_spruce_log
fill 95 226 345 95 226 348 minecraft:stone
setblock 95 226 349 minecraft:stripped_spruce_log
fill 95 226 350 95 226 353 minecraft:stone
setblock 95 226 354 minecraft:stripped_spruce_log
fill 95 226 355 95 226 358 minecraft:stone
setblock 95 226 359 minecraft:stripped_spruce_log
fill 95 226 360 95 226 363 minecraft:stone
setblock 96 226 323 minecraft:stripped_spruce_log
fill 96 226 324 99 226 324 minecraft:stone
setblock 96 226 342 minecraft:stone
setblock 96 226 343 minecraft:stripped_spruce_log
fill 96 226 344 96 229 344 minecraft:stone
setblock 96 226 348 minecraft:stripped_spruce_log
fill 96 226 349 96 227 351 minecraft:stone
setblock 96 226 358 minecraft:stripped_spruce_log
fill 96 226 359 96 229 359 minecraft:stone
fill 96 226 361 96 226 362 minecraft:stone
setblock 96 226 363 minecraft:stripped_spruce_log
fill 97 226 323 100 226 323 minecraft:stone
fill 97 226 345 97 226 346 minecraft:stone
setblock 97 226 347 minecraft:stripped_spruce_log
fill 97 226 348 97 229 348 minecraft:stone
setblock 97 226 362 minecraft:stripped_spruce_log
fill 97 226 363 100 226 363 minecraft:stone
setblock 98 226 361 minecraft:stripped_spruce_log
fill 98 226 362 101 226 362 minecraft:stone
setblock 100 226 324 minecraft:stripped_spruce_log
fill 100 226 333 104 226 339 minecraft:blue_stained_glass
setblock 101 226 323 minecraft:stripped_spruce_log
setblock 101 226 324 minecraft:stone
setblock 101 226 363 minecraft:stripped_spruce_log
fill 102 226 323 102 229 323 minecraft:stone
setblock 102 226 362 minecraft:stripped_spruce_log
fill 102 226 363 104 227 363 minecraft:stone
fill 113 226 323 115 226 323 minecraft:stone
setblock 116 226 323 minecraft:stripped_spruce_log
setblock 116 226 363 minecraft:stripped_spruce_log
fill 117 226 323 120 226 323 minecraft:stone
fill 117 226 363 120 226 363 minecraft:stone
setblock 120 226 324 minecraft:stripped_spruce_log
setblock 121 226 323 minecraft:stripped_spruce_log
fill 121 226 324 124 226 324 minecraft:stone
setblock 121 226 363 minecraft:stripped_spruce_log
fill 122 226 323 125 226 323 minecraft:stone
fill 122 226 363 125 226 363 minecraft:stone
setblock 125 226 324 minecraft:stripped_spruce_log
setblock 126 226 323 minecraft:stripped_spruce_log
fill 126 226 324 129 226 324 minecraft:stone
fill 127 226 323 130 226 323 minecraft:stone
fill 128 226 333 132 226 339 minecraft:blue_stained_glass
fill 128 226 364 128 247 364 minecraft:andesite
setblock 130 226 324 minecraft:stripped_spruce_log
setblock 130 226 363 minecraft:stone
fill 131 226 322 131 247 322 minecraft:andesite
setblock 131 226 323 minecraft:stripped_spruce_log
fill 131 226 324 131 229 324 minecraft:stone
setblock 131 226 363 minecraft:stripped_spruce_log
fill 132 226 323 132 229 323 minecraft:stone
fill 132 226 363 132 229 363 minecraft:stone
fill 133 226 324 134 226 324 minecraft:stone
setblock 134 226 325 minecraft:stripped_spruce_log
fill 134 226 326 134 228 327 minecraft:stone
setblock 135 226 324 minecraft:stripped_spruce_log
fill 135 226 325 135 229 325 minecraft:stone
setblock 135 226 329 minecraft:stripped_spruce_log
fill 135 226 342 135 226 343 minecraft:stone
setblock 135 226 344 minecraft:stripped_spruce_log
fill 135 226 345 135 229 345 minecraft:stone
fill 135 226 347 135 226 348 minecraft:stone
setblock 135 226 359 minecraft:stripped_spruce_log
fill 135 226 360 135 229 360 minecraft:stone
fill 136 226 332 136 243 332 minecraft:andesite
setblock 95 227 323 minecraft:stripped_spruce_log
fill 95 227 324 98 227 324 minecraft:stone
setblock 95 227 328 minecraft:stripped_spruce_log
fill 95 227 341 95 227 342 minecraft:stone
setblock 95 227 343 minecraft:stripped_spruce_log
fill 95 227 344 95 227 347 minecraft:stone
setblock 95 227 348 minecraft:stripped_spruce_log
fill 95 227 349 95 227 352 minecraft:stone
setblock 95 227 353 minecraft:stripped_spruce_log
fill 95 227 354 95 227 357 minecraft:stone
setblock 95 227 358 minecraft:stripped_spruce_log
fill 95 227 359 95 227 362 minecraft:stone
setblock 95 227 363 minecraft:stripped_spruce_log
fill 96 227 323 99 227 323 minecraft:stone
setblock 96 227 326 minecraft:stone
setblock 96 227 342 minecraft:stripped_spruce_log
setblock 96 227 343 minecraft:stone
setblock 96 227 346 minecraft:stone
setblock 96 227 347 minecraft:stripped_spruce_log
fill 96 227 348 96 230 348 minecraft:stone
setblock 96 227 352 minecraft:stripped_spruce_log
fill 96 227 353 96 229 354 minecraft:stone
fill 96 227 358 96 230 358 minecraft:stone
setblock 96 227 361 minecraft:stone
setblock 96 227 362 minecraft:stripped_spruce_log
fill 96 227 363 99 227 363 minecraft:stone
setblock 97 227 325 minecraft:light[level=15]
setblock 97 227 333 minecraft:light[level=15]
setblock 97 227 341 minecraft:light[level=15]
fill 97 227 344 97 227 345 minecraft:stone
setblock 97 227 346 minecraft:stripped_spruce_log
fill 97 227 347 97 230 347 minecraft:stone
fill 97 227 349 97 227 350 minecraft:stone
setblock 97 227 357 minecraft:light[level=15]
fill 97 227 362 100 227 362 minecraft:stone
setblock 99 227 324 minecraft:stripped_spruce_log
setblock 100 227 323 minecraft:stripped_spruce_log
fill 100 227 324 100 230 324 minecraft:stone
setblock 100 227 363 minecraft:stripped_spruce_log
fill 101 227 323 101 230 323 minecraft:stone
setblock 101 227 362 minecraft:stripped_spruce_log
fill 101 227 363 101 230 363 minecraft:stone
fill 103 227 323 103 228 323 minecraft:stone
setblock 105 227 325 minecraft:light[level=15]
setblock 105 227 341 minecraft:light[level=15]
setblock 105 227 349 minecraft:light[level=15]
setblock 105 227 357 minecraft:light[level=15]
fill 108 227 325 108 229 325 minecraft:cobbled_deepslate
fill 108 227 328 108 227 329 minecraft:iron_block
fill 108 227 343 108 227 344 minecraft:iron_block
setblock 109 227 322 minecraft:gold_block
fill 109 227 324 109 229 324 minecraft:cobbled_deepslate
fill 109 227 326 109 229 326 minecraft:cobbled_deepslate
fill 110 227 325 112 229 325 minecraft:cobbled_deepslate
fill 112 227 324 112 229 324 minecraft:cobbled_deepslate
fill 113 227 323 114 227 323 minecraft:stone
setblock 113 227 333 minecraft:light[level=15]
setblock 113 227 341 minecraft:light[level=15]
setblock 113 227 349 minecraft:light[level=15]
setblock 113 227 357 minecraft:light[level=15]
setblock 115 227 323 minecraft:stripped_spruce_log
fill 115 227 324 118 227 324 minecraft:stone
fill 116 227 323 119 227 323 minecraft:stone
fill 116 227 363 119 227 363 minecraft:stone
fill 118 227 326 118 228 326 minecraft:raw_gold_block
setblock 119 227 324 minecraft:stripped_spruce_log
setblock 120 227 323 minecraft:stripped_spruce_log
fill 120 227 324 122 227 325 minecraft:stone
setblock 120 227 363 minecraft:stripped_spruce_log
fill 121 227 323 124 227 323 minecraft:stone
setblock 121 227 333 minecraft:light[level=15]
setblock 121 227 341 minecraft:light[level=15]
setblock 121 227 349 minecraft:light[level=15]
setblock 121 227 357 minecraft:light[level=15]
fill 121 227 363 124 227 363 minecraft:stone
setblock 123 227 324 minecraft:stone
setblock 123 227 325 minecraft:stripped_spruce_log
fill 123 227 328 124 227 328 minecraft:iron_block
fill 123 227 344 124 227 344 minecraft:iron_block
setblock 124 227 324 minecraft:stripped_spruce_log
setblock 125 227 323 minecraft:stripped_spruce_log
fill 125 227 324 128 227 324 minecraft:stone
fill 126 227 323 129 227 323 minecraft:stone
setblock 129 227 324 minecraft:stripped_spruce_log
setblock 129 227 325 minecraft:light[level=15]
setblock 129 227 333 minecraft:light[level=15]
setblock 129 227 341 minecraft:light[level=15]
setblock 129 227 349 minecraft:light[level=15]
setblock 129 227 357 minecraft:light[level=15]
setblock 130 227 323 minecraft:stripped_spruce_log
fill 130 227 324 130 230 324 minecraft:stone
setblock 130 227 363 minecraft:stripped_spruce_log
fill 131 227 323 131 230 323 minecraft:stone
fill 131 227 363 131 230 363 minecraft:stone
setblock 133 227 324 minecraft:stone
setblock 134 227 323 minecraft:stone
setblock 134 227 324 minecraft:stripped_spruce_log
fill 134 227 325 134 230 325 minecraft:stone
setblock 134 227 363 minecraft:stone
setblock 135 227 323 minecraft:stripped_spruce_log
fill 135 227 324 135 230 324 minecraft:stone
setblock 135 227 327 minecraft:stone
setblock 135 227 328 minecraft:stripped_spruce_log
fill 135 227 329 135 229 330 minecraft:stone
setblock 135 227 342 minecraft:stone
setblock 135 227 343 minecraft:stripped_spruce_log
fill 135 227 344 135 230 344 minecraft:stone
setblock 135 227 347 minecraft:stone
setblock 135 227 348 minecraft:stripped_spruce_log
fill 135 227 349 135 228 351 minecraft:stone
setblock 135 227 358 minecraft:stripped_spruce_log
fill 135 227 359 135 230 359 minecraft:stone
setblock 135 227 363 minecraft:stripped_spruce_log
fill 95 228 323 95 230 324 minecraft:stone
setblock 95 228 326 minecraft:stone
setblock 95 228 327 minecraft:stripped_spruce_log
fill 95 228 328 95 230 329 minecraft:stone
fill 95 228 340 95 228 341 minecraft:stone
setblock 95 228 342 minecraft:stripped_spruce_log
fill 95 228 343 95 228 346 minecraft:stone
setblock 95 228 347 minecraft:stripped_spruce_log
fill 95 228 348 95 228 351 minecraft:stone
setblock 95 228 352 minecraft:stripped_spruce_log
fill 95 228 353 95 228 356 minecraft:stone
setblock 95 228 357 minecraft:stripped_spruce_log
fill 95 228 358 95 228 361 minecraft:stone
setblock 95 228 362 minecraft:stripped_spruce_log
fill 95 228 363 98 228 363 minecraft:stone
fill 96 228 323 98 228 323 minecraft:stone
fill 96 228 324 96 231 324 minecraft:spruce_log
setblock 96 228 326 minecraft:stripped_spruce_log
fill 96 228 327 96 231 327 minecraft:stone
fill 96 228 342 96 231 342 minecraft:stone
fill 96 228 343 96 231 343 minecraft:spruce_log
setblock 96 228 346 minecraft:stripped_spruce_log
fill 96 228 347 96 231 347 minecraft:stone
fill 96 228 349 96 228 350 minecraft:stone
setblock 96 228 351 minecraft:stripped_spruce_log
fill 96 228 352 97 230 352 minecraft:stone
setblock 96 228 355 minecraft:stone
setblock 96 228 356 minecraft:stripped_spruce_log
fill 96 228 357 96 231 357 minecraft:stone
setblock 96 228 361 minecraft:stripped_spruce_log
fill 96 228 362 96 231 362 minecraft:spruce_log
setblock 97 228 324 minecraft:stone
setblock 97 228 344 minecraft:stone
setblock 97 228 345 minecraft:stripped_spruce_log
fill 97 228 346 97 231 346 minecraft:stone
setblock 97 228 349 minecraft:stone
setblock 97 228 350 minecraft:stripped_spruce_log
fill 97 228 351 97 231 351 minecraft:stone
fill 97 228 362 99 228 362 minecraft:stone
setblock 98 228 324 minecraft:stripped_spruce_log
fill 98 228 347 98 229 347 minecraft:stone
setblock 99 228 323 minecraft:stripped_spruce_log
fill 99 228 324 99 231 324 minecraft:stone
setblock 99 228 363 minecraft:stripped_spruce_log
fill 100 228 323 100 231 323 minecraft:stone
setblock 100 228 362 minecraft:stripped_spruce_log
fill 100 228 363 100 231 363 minecraft:stone
fill 102 228 363 103 228 363 minecraft:stone
fill 109 228 322 109 247 322 minecraft:andesite
fill 112 228 323 113 228 323 minecraft:stone
fill 112 228 326 112 230 326 minecraft:cobbled_deepslate
fill 113 228 325 113 229 325 minecraft:cobbled_deepslate
setblock 114 228 323 minecraft:stripped_spruce_log
fill 114 228 324 114 231 324 minecraft:stone
fill 115 228 323 118 228 323 minecraft:stone
fill 115 228 324 115 231 324 minecraft:spruce_log
fill 115 228 362 115 231 362 minecraft:spruce_log
fill 115 228 363 118 228 363 minecraft:stone
fill 116 228 324 116 228 325 minecraft:stone
setblock 117 228 324 minecraft:stone
setblock 117 228 325 minecraft:stripped_spruce_log
setblock 117 228 326 minecraft:raw_gold_block
setblock 118 228 324 minecraft:stripped_spruce_log
fill 118 228 325 121 228 325 minecraft:stone
fill 118 228 327 118 230 327 minecraft:raw_gold_block
setblock 119 228 323 minecraft:stripped_spruce_log
fill 119 228 324 122 228 324 minecraft:stone
setblock 119 228 326 minecraft:raw_gold_block
setblock 119 228 363 minecraft:stripped_spruce_log
fill 120 228 323 123 228 323 minecraft:stone
fill 120 228 363 123 228 363 minecraft:stone
fill 120 228 364 122 229 364 minecraft:andesite
setblock 122 228 325 minecraft:stripped_spruce_log
setblock 123 228 324 minecraft:stripped_spruce_log
fill 123 228 325 123 231 325 minecraft:stone
setblock 123 228 364 minecraft:raw_gold_block
setblock 124 228 323 minecraft:stripped_spruce_log
fill 124 228 324 127 228 324 minecraft:stone
fill 125 228 323 128 228 323 minecraft:stone
setblock 128 228 324 minecraft:stripped_spruce_log
fill 128 228 326 128 229 332 minecraft:stripped_spruce_log
setblock 129 228 323 minecraft:stripped_spruce_log
fill 129 228 324 129 231 324 minecraft:stone
fill 129 228 325 129 229 328 minecraft:stripped_spruce_log
fill 130 228 323 130 231 323 minecraft:stone
fill 130 228 363 130 231 363 minecraft:stone
setblock 133 228 324 minecraft:stripped_spruce_log
fill 133 228 325 133 231 325 minecraft:stone
setblock 134 228 323 minecraft:stripped_spruce_log
fill 134 228 324 134 231 324 minecraft:spruce_log
setblock 134 228 328 minecraft:stripped_spruce_log
fill 134 228 343 134 231 343 minecraft:spruce_log
fill 134 228 362 134 231 362 minecraft:spruce_log
setblock 134 228 363 minecraft:stripped_spruce_log
fill 135 228 323 135 231 323 minecraft:stone
setblock 135 228 327 minecraft:stripped_spruce_log
fill 135 228 328 135 231 328 minecraft:stone
setblock 135 228 331 minecraft:stone
setblock 135 228 342 minecraft:stripped_spruce_log
fill 135 228 343 135 231 343 minecraft:stone
setblock 135 228 347 minecraft:stripped_spruce_log
fill 135 228 348 135 231 348 minecraft:stone
setblock 135 228 352 minecraft:stripped_spruce_log
fill 135 228 353 135 228 356 minecraft:stone
setblock 135 228 357 minecraft:stripped_spruce_log
fill 135 228 358 135 231 358 minecraft:stone
setblock 135 228 362 minecraft:stripped_spruce_log
fill 135 228 363 135 231 363 minecraft:stone
setblock 136 228 353 minecraft:raw_iron_block
setblock 94 229 335 minecraft:diamond_block
fill 94 229 336 94 247 337 minecraft:andesite
setblock 95 229 326 minecraft:stripped_spruce_log
fill 95 229 327 95 232 327 minecraft:stone
setblock 95 229 330 minecraft:stone
setblock 95 229 331 minecraft:stripped_spruce_log
setblock 95 229 340 minecraft:stone
setblock 95 229 341 minecraft:stripped_spruce_log
fill 95 229 342 95 229 345 minecraft:stone
setblock 95 229 346 minecraft:stripped_spruce_log
fill 95 229 347 95 229 350 minecraft:stone
setblock 95 229 351 minecraft:stripped_spruce_log
fill 95 229 352 95 229 355 minecraft:stone
setblock 95 229 356 minecraft:stripped_spruce_log
fill 95 229 357 95 229 360 minecraft:stone
setblock 95 229 361 minecraft:stripped_spruce_log
fill 95 229 362 95 231 363 minecraft:stone
fill 96 229 323 97 229 323 minecraft:stone
setblock 96 229 325 minecraft:stripped_spruce_log
fill 96 229 326 96 232 326 minecraft:stone
fill 96 229 328 96 230 328 minecraft:stone
fill 96 229 341 96 232 341 minecraft:stone
setblock 96 229 345 minecraft:stripped_spruce_log
fill 96 229 346 96 232 346 minecraft:stone
setblock 96 229 349 minecraft:stone
setblock 96 229 350 minecraft:stripped_spruce_log
fill 96 229 351 96 232 351 minecraft:stone
setblock 96 229 355 minecraft:stripped_spruce_log
fill 96 229 356 96 232 356 minecraft:stone
setblock 96 229 360 minecraft:stripped_spruce_log
fill 96 229 361 96 232 361 minecraft:stone
fill 96 229 363 97 229 363 minecraft:stone
setblock 97 229 324 minecraft:stripped_spruce_log
setblock 97 229 325 minecraft:light[level=12]
setblock 97 229 332 minecraft:light[level=12]
setblock 97 229 339 minecraft:light[level=12]
setblock 97 229 343 minecraft:stone
setblock 97 229 344 minecraft:stripped_spruce_log
fill 97 229 345 97 232 345 minecraft:stone
setblock 97 229 349 minecraft:stripped_spruce_log
fill 97 229 350 98 231 350 minecraft:stone
setblock 97 229 353 minecraft:stone
setblock 97 229 354 minecraft:stripped_spruce_log
setblock 97 229 360 minecraft:light[level=12]
fill 97 229 362 98 229 362 minecraft:stone
setblock 98 229 323 minecraft:stripped_spruce_log
fill 98 229 324 98 232 324 minecraft:stone
fill 98 229 346 98 230 346 minecraft:stone
setblock 98 229 348 minecraft:stripped_spruce_log
fill 98 229 349 98 232 349 minecraft:stone
setblock 98 229 363 minecraft:stripped_spruce_log
fill 99 229 323 99 232 323 minecraft:stone
setblock 99 229 362 minecraft:stripped_spruce_log
fill 99 229 363 99 232 363 minecraft:stone
setblock 100 229 362 minecraft:stone
setblock 102 229 363 minecraft:stone
setblock 104 229 325 minecraft:light[level=12]
setblock 104 229 332 minecraft:light[level=12]
setblock 104 229 339 minecraft:light[level=12]
setblock 104 229 346 minecraft:light[level=12]
setblock 104 229 353 minecraft:light[level=12]
setblock 104 229 360 minecraft:light[level=12]
setblock 106 229 364 minecraft:diamond_block
fill 107 229 364 107 247 364 minecraft:andesite
setblock 108 229 324 minecraft:cobbled_deepslate
setblock 108 229 326 minecraft:cobbled_deepslate
fill 110 229 324 111 229 324 minecraft:cobbled_deepslate
fill 110 229 326 111 229 326 minecraft:cobbled_deepslate
fill 111 229 323 112 229 323 minecraft:stone
setblock 111 229 332 minecraft:light[level=12]
setblock 111 229 339 minecraft:light[level=12]
setblock 111 229 346 minecraft:light[level=12]
setblock 111 229 353 minecraft:light[level=12]
setblock 111 229 360 minecraft:light[level=12]
setblock 113 229 323 minecraft:stripped_spruce_log
fill 113 229 324 113 232 324 minecraft:stone
fill 113 229 326 113 230 326 minecraft:cobbled_deepslate
fill 114 229 323 117 229 323 minecraft:stone
fill 114 229 325 115 229 325 minecraft:stone
fill 115 229 363 117 229 363 minecraft:stone
setblock 115 229 364 minecraft:raw_iron_block
setblock 116 229 324 minecraft:stone
setblock 116 229 325 minecraft:stripped_spruce_log
setblock 117 229 324 minecraft:stripped_spruce_log
fill 117 229 325 119 229 326 minecraft:stone
fill 117 229 327 117 229 328 minecraft:raw_gold_block
setblock 118 229 323 minecraft:stripped_spruce_log
fill 118 229 324 121 229 324 minecraft:stone
fill 118 229 328 119 229 328 minecraft:raw_gold_block
setblock 118 229 332 minecraft:light[level=12]
setblock 118 229 339 minecraft:light[level=12]
setblock 118 229 346 minecraft:light[level=12]
setblock 118 229 353 minecraft:light[level=12]
setblock 118 229 360 minecraft:light[level=12]
setblock 118 229 363 minecraft:stripped_spruce_log
fill 119 229 323 122 229 323 minecraft:stone
fill 119 229 327 119 230 327 minecraft:raw_gold_block
fill 119 229 363 122 229 363 minecraft:stone
setblock 120 229 325 minecraft:stone
setblock 120 229 326 minecraft:stripped_spruce_log
setblock 121 229 325 minecraft:stripped_spruce_log
setblock 122 229 322 minecraft:gold_block
setblock 122 229 324 minecraft:stripped_spruce_log
fill 122 229 325 122 232 325 minecraft:stone
setblock 123 229 323 minecraft:stripped_spruce_log
fill 123 229 324 126 229 324 minecraft:stone
fill 123 229 364 123 247 364 minecraft:andesite
fill 124 229 323 127 229 323 minecraft:stone
fill 124 229 325 124 230 325 minecraft:stone
setblock 124 229 364 minecraft:raw_iron_block
setblock 125 229 325 minecraft:light[level=12]
setblock 125 229 332 minecraft:light[level=12]
setblock 125 229 339 minecraft:light[level=12]
setblock 125 229 346 minecraft:light[level=12]
setblock 125 229 353 minecraft:light[level=12]
setblock 125 229 360 minecraft:light[level=12]
fill 126 229 340 126 229 350 minecraft:stripped_spruce_log
setblock 127 229 324 minecraft:stripped_spruce_log
fill 127 229 332 127 229 344 minecraft:stripped_spruce_log
setblock 128 229 323 minecraft:stripped_spruce_log
fill 128 229 324 128 232 324 minecraft:stone
setblock 128 229 325 minecraft:stripped_spruce_log
fill 128 229 333 128 229 338 minecraft:stripped_spruce_log
fill 129 229 323 129 232 323 minecraft:stone
fill 129 229 329 129 229 331 minecraft:stripped_spruce_log
fill 129 229 363 129 232 363 minecraft:stone
setblock 132 229 324 minecraft:stripped_spruce_log
fill 132 229 325 132 232 325 minecraft:stone
setblock 132 229 332 minecraft:light[level=12]
setblock 132 229 339 minecraft:light[level=12]
setblock 132 229 346 minecraft:light[level=12]
setblock 132 229 353 minecraft:light[level=12]
setblock 132 229 360 minecraft:light[level=12]
setblock 133 229 323 minecraft:stripped_spruce_log
fill 133 229 324 133 232 324 minecraft:stone
fill 133 229 326 133 229 327 minecraft:stone
setblock 133 229 362 minecraft:stone
setblock 133 229 363 minecraft:stripped_spruce_log
fill 134 229 323 134 232 323 minecraft:stone
setblock 134 229 326 minecraft:stone
setblock 134 229 327 minecraft:stripped_spruce_log
fill 134 229 328 134 230 330 minecraft:stone
setblock 134 229 346 minecraft:stone
setblock 134 229 347 minecraft:stripped_spruce_log
fill 134 229 348 134 230 350 minecraft:stone
setblock 134 229 361 minecraft:stone
fill 134 229 363 134 232 363 minecraft:stone
setblock 135 229 326 minecraft:stripped_spruce_log
fill 135 229 327 135 232 327 minecraft:stone
setblock 135 229 331 minecraft:stripped_spruce_log
fill 135 229 332 135 232 332 minecraft:stone
fill 135 229 342 135 232 342 minecraft:stone
setblock 135 229 346 minecraft:stripped_spruce_log
fill 135 229 347 135 232 347 minecraft:stone
fill 135 229 349 135 229 350 minecraft:stone
setblock 135 229 351 minecraft:stripped_spruce_log
fill 135 229 352 135 229 355 minecraft:stone
setblock 135 229 356 minecraft:stripped_spruce_log
fill 135 229 357 135 232 357 minecraft:stone
setblock 135 229 361 minecraft:stripped_spruce_log
fill 135 229 362 135 232 362 minecraft:stone
fill 136 229 353 136 247 353 minecraft:andesite
fill 94 230 335 94 247 335 minecraft:andesite
setblock 94 230 363 minecraft:raw_iron_block
setblock 95 230 325 minecraft:stripped_spruce_log
fill 95 230 326 95 233 326 minecraft:stone
setblock 95 230 330 minecraft:stripped_spruce_log
fill 95 230 331 95 231 333 minecraft:stone
setblock 95 230 339 minecraft:stone
setblock 95 230 340 minecraft:stripped_spruce_log
fill 95 230 341 95 230 344 minecraft:stone
setblock 95 230 345 minecraft:stripped_spruce_log
fill 95 230 346 95 230 349 minecraft:stone
setblock 95 230 350 minecraft:stripped_spruce_log
fill 95 230 351 95 230 354 minecraft:stone
setblock 95 230 355 minecraft:stripped_spruce_log
fill 95 230 356 95 230 359 minecraft:stone
setblock 95 230 360 minecraft:stripped_spruce_log
fill 95 230 361 95 233 361 minecraft:stone
setblock 96 230 323 minecraft:stone
fill 96 230 325 96 233 325 minecraft:stone
setblock 96 230 329 minecraft:stripped_spruce_log
fill 96 230 330 96 233 330 minecraft:stone
setblock 96 230 344 minecraft:stripped_spruce_log
fill 96 230 345 96 233 345 minecraft:stone
setblock 96 230 349 minecraft:stripped_spruce_log
fill 96 230 350 96 233 350 minecraft:stone
setblock 96 230 353 minecraft:stone
setblock 96 230 354 minecraft:stripped_spruce_log
fill 96 230 355 97 232 355 minecraft:stone
setblock 96 230 359 minecraft:stripped_spruce_log
fill 96 230 360 96 233 360 minecraft:stone
setblock 96 230 363 minecraft:stone
setblock 97 230 323 minecraft:stripped_spruce_log
fill 97 230 324 97 233 324 minecraft:stone
setblock 97 230 343 minecraft:stripped_spruce_log
fill 97 230 344 97 233 344 minecraft:stone
setblock 97 230 348 minecraft:stripped_spruce_log
fill 97 230 349 97 233 349 minecraft:stone
setblock 97 230 353 minecraft:stripped_spruce_log
fill 97 230 354 97 233 354 minecraft:stone
setblock 97 230 362 minecraft:stone
setblock 97 230 363 minecraft:stripped_spruce_log
fill 98 230 323 98 233 323 minecraft:stone
fill 98 230 345 98 231 345 minecraft:stone
setblock 98 230 347 minecraft:stripped_spruce_log
fill 98 230 348 98 233 348 minecraft:stone
setblock 98 230 351 minecraft:stone
setblock 98 230 352 minecraft:stripped_spruce_log
setblock 98 230 362 minecraft:stripped_spruce_log
fill 98 230 363 98 233 363 minecraft:stone
fill 99 230 362 99 231 362 minecraft:stone
setblock 102 230 323 minecraft:stripped_spruce_log
setblock 102 230 363 minecraft:stripped_spruce_log
fill 106 230 364 106 247 364 minecraft:andesite
fill 110 230 323 111 230 323 minecraft:stone
fill 111 230 324 111 230 326 minecraft:cobbled_deepslate
setblock 112 230 323 minecraft:stripped_spruce_log
fill 112 230 324 112 233 324 minecraft:stone
setblock 112 230 325 minecraft:cobbled_deepslate
fill 113 230 323 116 230 323 minecraft:stone
fill 113 230 325 114 230 325 minecraft:stone
fill 114 230 363 116 230 363 minecraft:stone
setblock 115 230 325 minecraft:stripped_spruce_log
fill 115 230 326 118 230 326 minecraft:stone
fill 115 230 364 115 238 364 minecraft:andesite
setblock 116 230 324 minecraft:stripped_spruce_log
fill 116 230 325 119 230 325 minecraft:stone
setblock 117 230 323 minecraft:stripped_spruce_log
fill 117 230 324 120 230 324 minecraft:stone
setblock 117 230 327 minecraft:raw_gold_block
setblock 117 230 363 minecraft:stripped_spruce_log
fill 118 230 323 121 230 323 minecraft:stone
fill 118 230 328 118 231 329 minecraft:raw_gold_block
fill 118 230 363 121 230 363 minecraft:stone
setblock 119 230 326 minecraft:stripped_spruce_log
setblock 120 230 325 minecraft:stripped_spruce_log
fill 120 230 326 121 232 326 minecraft:stone
setblock 120 230 364 minecraft:diamond_block
setblock 121 230 324 minecraft:stripped_spruce_log
fill 121 230 325 121 233 325 minecraft:stone
fill 121 230 364 122 242 364 minecraft:andesite
fill 122 230 322 122 248 322 minecraft:andesite
setblock 122 230 323 minecraft:stripped_spruce_log
fill 122 230 324 125 230 324 minecraft:stone
setblock 122 230 363 minecraft:stripped_spruce_log
fill 123 230 323 126 230 323 minecraft:stone
fill 124 230 354 124 230 363 minecraft:stripped_spruce_log
fill 124 230 364 124 247 364 minecraft:andesite
fill 125 230 347 125 230 360 minecraft:stripped_spruce_log
setblock 126 230 324 minecraft:stripped_spruce_log
fill 126 230 341 126 230 354 minecraft:stripped_spruce_log
setblock 127 230 323 minecraft:stripped_spruce_log
fill 127 230 324 127 233 324 minecraft:stone
fill 127 230 336 127 230 346 minecraft:stripped_spruce_log
fill 128 230 323 128 233 323 minecraft:stone
fill 128 230 328 128 230 333 minecraft:stripped_dark_oak_log
setblock 128 230 334 minecraft:stripped_spruce_log
fill 129 230 325 129 230 327 minecraft:stripped_dark_oak_log
setblock 130 230 325 minecraft:stripped_spruce_log
setblock 131 230 324 minecraft:stripped_spruce_log
fill 131 230 325 131 233 325 minecraft:stone
setblock 132 230 323 minecraft:stripped_spruce_log
fill 132 230 324 132 233 324 minecraft:stone
setblock 132 230 363 minecraft:stripped_spruce_log
fill 133 230 323 133 233 323 minecraft:stone
setblock 133 230 326 minecraft:stone
setblock 133 230 327 minecraft:stripped_spruce_log
fill 133 230 328 133 233 328 minecraft:stone
setblock 133 230 362 minecraft:stripped_spruce_log
fill 133 230 363 133 233 363 minecraft:stone
setblock 134 230 326 minecraft:stripped_spruce_log
fill 134 230 327 134 233 327 minecraft:stone
setblock 134 230 331 minecraft:stripped_spruce_log
setblock 134 230 345 minecraft:stone
setblock 134 230 346 minecraft:stripped_spruce_log
fill 134 230 347 134 233 347 minecraft:stone
setblock 134 230 351 minecraft:stripped_spruce_log
fill 134 230 352 135 230 354 minecraft:stone
setblock 134 230 360 minecraft:stone
setblock 134 230 361 minecraft:stripped_spruce_log
setblock 135 230 325 minecraft:stripped_spruce_log
fill 135 230 326 135 233 326 minecraft:stone
setblock 135 230 329 minecraft:stone
setblock 135 230 330 minecraft:stripped_spruce_log
fill 135 230 331 135 233 331 minecraft:stone
fill 135 230 333 135 231 333 minecraft:stone
fill 135 230 341 135 233 341 minecraft:stone
setblock 135 230 345 minecraft:stripped_spruce_log
fill 135 230 346 135 233 346 minecraft:stone
setblock 135 230 349 minecraft:stone
setblock 135 230 350 minecraft:stripped_spruce_log
fill 135 230 351 135 233 351 minecraft:stone
setblock 135 230 355 minecraft:stripped_spruce_log
fill 135 230 356 135 233 356 minecraft:stone
setblock 135 230 360 minecraft:stripped_spruce_log
fill 135 230 361 135 233 361 minecraft:stone
setblock 136 230 356 minecraft:raw_gold_block
setblock 94 231 339 minecraft:gold_block
fill 94 231 363 94 248 363 minecraft:andesite
setblock 95 231 323 minecraft:stone
setblock 95 231 324 minecraft:stripped_spruce_log
fill 95 231 325 95 233 325 minecraft:stone
setblock 95 231 328 minecraft:stone
setblock 95 231 329 minecraft:stripped_spruce_log
fill 95 231 330 95 233 330 minecraft:stone
setblock 95 231 334 minecraft:stripped_spruce_log
fill 95 231 335 95 231 338 minecraft:stone
setblock 95 231 339 minecraft:stripped_spruce_log
fill 95 231 340 95 231 343 minecraft:stone
setblock 95 231 344 minecraft:stripped_spruce_log
fill 95 231 345 95 231 348 minecraft:stone
setblock 95 231 349 minecraft:stripped_spruce_log
fill 95 231 350 95 231 353 minecraft:stone
setblock 95 231 354 minecraft:stripped_spruce_log
fill 95 231 355 95 231 358 minecraft:stone
setblock 95 231 359 minecraft:stripped_spruce_log
fill 95 231 360 95 233 360 minecraft:stone
setblock 96 231 323 minecraft:stripped_spruce_log
setblock 96 231 328 minecraft:stripped_spruce_log
fill 96 231 329 96 233 329 minecraft:stone
fill 96 231 331 96 232 331 minecraft:stone
fill 96 231 344 96 233 344 minecraft:stone
setblock 96 231 348 minecraft:stripped_spruce_log
fill 96 231 349 96 233 349 minecraft:stone
setblock 96 231 352 minecraft:stone
setblock 96 231 353 minecraft:stripped_spruce_log
fill 96 231 354 96 233 354 minecraft:stone
setblock 96 231 358 minecraft:stripped_spruce_log
fill 96 231 359 96 233 359 minecraft:stone
setblock 96 231 363 minecraft:stripped_spruce_log
fill 97 231 323 97 233 323 minecraft:stone
setblock 97 231 326 minecraft:stone
fill 97 231 343 97 233 343 minecraft:stone
setblock 97 231 347 minecraft:stripped_spruce_log
fill 97 231 348 97 234 348 minecraft:stone
setblock 97 231 352 minecraft:stripped_spruce_log
fill 97 231 353 98 233 353 minecraft:stone
setblock 97 231 356 minecraft:stone
setblock 97 231 362 minecraft:stripped_spruce_log
fill 97 231 363 97 233 363 minecraft:stone
setblock 98 231 346 minecraft:stripped_spruce_log
fill 98 231 347 98 234 347 minecraft:stone
setblock 98 231 351 minecraft:stripped_spruce_log
fill 98 231 352 98 234 352 minecraft:stone
fill 98 231 362 98 232 362 minecraft:stone
setblock 101 231 323 minecraft:stripped_spruce_log
setblock 101 231 363 minecraft:stripped_spruce_log
setblock 102 231 323 minecraft:stone
setblock 110 231 323 minecraft:stone
setblock 111 231 323 minecraft:stripped_spruce_log
fill 111 231 324 111 233 324 minecraft:stone
fill 112 231 323 115 231 323 minecraft:stone
setblock 113 231 325 minecraft:stone
setblock 114 231 325 minecraft:stripped_spruce_log
fill 114 231 326 117 231 326 minecraft:stone
fill 114 231 363 115 231 363 minecraft:stone
fill 115 231 325 118 231 325 minecraft:stone
setblock 116 231 323 minecraft:stripped_spruce_log
fill 116 231 324 119 231 324 minecraft:stone
setblock 116 231 363 minecraft:stripped_spruce_log
fill 117 231 323 120 231 323 minecraft:stone
fill 117 231 363 120 231 363 minecraft:stone
setblock 118 231 326 minecraft:stripped_spruce_log
setblock 118 231 330 minecraft:raw_gold_block
setblock 119 231 325 minecraft:stripped_spruce_log
fill 119 231 326 119 234 326 minecraft:stone
setblock 120 231 324 minecraft:stripped_spruce_log
fill 120 231 325 120 234 325 minecraft:stone
fill 120 231 364 120 244 364 minecraft:andesite
setblock 121 231 323 minecraft:stripped_spruce_log
fill 121 231 324 124 231 324 minecraft:stone
setblock 121 231 363 minecraft:stripped_spruce_log
fill 122 231 323 125 231 323 minecraft:stone
setblock 124 231 325 minecraft:stripped_spruce_log
fill 124 231 357 124 231 363 minecraft:stripped_spruce_log
setblock 125 231 324 minecraft:stripped_spruce_log
fill 125 231 351 125 231 352 minecraft:stripped_dark_oak_log
fill 125 231 353 125 231 359 minecraft:stripped_spruce_log
setblock 126 231 323 minecraft:stripped_spruce_log
fill 126 231 324 126 233 324 minecraft:stone
fill 126 231 343 126 231 350 minecraft:stripped_dark_oak_log
fill 127 231 323 127 233 323 minecraft:stone
fill 127 231 337 127 231 342 minecraft:stripped_dark_oak_log
fill 128 231 363 128 233 363 minecraft:stone
setblock 129 231 325 minecraft:stripped_spruce_log
setblock 130 231 324 minecraft:stripped_spruce_log
fill 130 231 325 130 234 325 minecraft:stone
setblock 131 231 323 minecraft:stripped_spruce_log
fill 131 231 324 131 233 324 minecraft:stone
setblock 131 231 363 minecraft:stripped_spruce_log
setblock 131 231 364 minecraft:gold_block
fill 132 231 323 132 233 323 minecraft:stone
setblock 132 231 362 minecraft:stripped_spruce_log
fill 132 231 363 132 233 363 minecraft:stone
setblock 133 231 326 minecraft:stripped_spruce_log
fill 133 231 327 133 234 327 minecraft:stone
fill 133 231 329 134 231 329 minecraft:stone
fill 133 231 362 133 233 362 minecraft:stone
setblock 134 231 325 minecraft:stripped_spruce_log
fill 134 231 326 134 233 326 minecraft:stone
schedule function dropper:buildpart/74_7 1t
