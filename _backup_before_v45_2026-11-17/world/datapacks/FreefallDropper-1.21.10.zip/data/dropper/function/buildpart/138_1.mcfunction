setblock 322 164 557 minecraft:white_concrete
fill 324 164 561 324 189 561 minecraft:magenta_stained_glass
setblock 324 164 565 minecraft:sea_lantern
fill 299 165 599 299 218 599 minecraft:magenta_stained_glass
fill 306 165 592 306 172 592 minecraft:amethyst_block
setblock 314 165 599 minecraft:white_concrete
fill 317 165 557 317 184 557 minecraft:magenta_stained_glass
fill 322 165 557 322 216 557 minecraft:magenta_stained_glass
fill 324 165 565 324 220 565 minecraft:magenta_stained_glass
setblock 282 166 590 minecraft:sea_lantern
fill 292 166 557 293 178 557 minecraft:magenta_stained_glass
setblock 294 166 557 minecraft:sea_lantern
fill 301 166 558 302 167 560 minecraft:amethyst_block
fill 306 166 593 307 172 593 minecraft:amethyst_block
fill 314 166 599 314 220 599 minecraft:magenta_stained_glass
fill 324 166 596 324 172 596 minecraft:magenta_stained_glass
setblock 324 166 597 minecraft:light_blue_stained_glass
fill 282 167 590 282 189 590 minecraft:magenta_stained_glass
fill 294 167 557 294 216 557 minecraft:magenta_stained_glass
fill 303 167 599 303 220 599 minecraft:magenta_stained_glass
setblock 304 167 599 minecraft:light_blue_stained_glass
fill 306 167 591 307 172 591 minecraft:amethyst_block
fill 308 167 592 308 172 592 minecraft:amethyst_block
setblock 324 167 571 minecraft:white_concrete
setblock 324 167 582 minecraft:white_concrete
setblock 324 167 588 minecraft:light_blue_stained_glass
setblock 324 167 589 minecraft:sea_lantern
fill 324 167 597 324 210 597 minecraft:magenta_stained_glass
fill 282 168 568 282 170 569 minecraft:magenta_stained_glass
setblock 282 168 570 minecraft:sea_lantern
fill 282 168 571 282 196 572 minecraft:magenta_stained_glass
fill 296 168 557 296 220 557 minecraft:magenta_stained_glass
setblock 297 168 557 minecraft:light_blue_stained_glass
fill 298 168 557 298 209 557 minecraft:magenta_stained_glass
setblock 299 168 557 minecraft:light_blue_stained_glass
setblock 301 168 557 minecraft:light_blue_stained_glass
fill 304 168 599 304 198 599 minecraft:magenta_stained_glass
fill 305 168 591 305 172 593 minecraft:amethyst_block
fill 306 168 594 307 172 594 minecraft:amethyst_block
fill 308 168 591 308 172 591 minecraft:amethyst_block
fill 308 168 593 308 172 593 minecraft:amethyst_block
fill 318 168 579 318 169 580 minecraft:magenta_stained_glass
setblock 323 168 599 minecraft:sea_lantern
fill 324 168 571 324 217 571 minecraft:magenta_stained_glass
fill 324 168 582 324 182 582 minecraft:magenta_stained_glass
setblock 324 168 585 minecraft:light_blue_stained_glass
fill 324 168 588 324 201 589 minecraft:magenta_stained_glass
fill 282 169 570 282 182 570 minecraft:magenta_stained_glass
setblock 283 169 599 minecraft:sea_lantern
setblock 285 169 560 minecraft:light[level=14]
setblock 285 169 568 minecraft:light[level=14]
setblock 285 169 576 minecraft:light[level=14]
setblock 285 169 584 minecraft:light[level=14]
setblock 285 169 592 minecraft:light[level=14]
setblock 293 169 560 minecraft:light[level=14]
setblock 293 169 568 minecraft:light[level=14]
setblock 293 169 576 minecraft:light[level=14]
setblock 293 169 584 minecraft:light[level=14]
setblock 293 169 592 minecraft:light[level=14]
fill 297 169 557 297 221 557 minecraft:magenta_stained_glass
fill 299 169 557 299 178 557 minecraft:magenta_stained_glass
fill 301 169 557 301 183 557 minecraft:magenta_stained_glass
setblock 301 169 560 minecraft:light[level=14]
setblock 301 169 568 minecraft:light[level=14]
setblock 301 169 576 minecraft:light[level=14]
setblock 301 169 584 minecraft:light[level=14]
setblock 301 169 592 minecraft:light[level=14]
fill 305 169 594 305 172 594 minecraft:amethyst_block
fill 306 169 590 308 172 590 minecraft:amethyst_block
fill 308 169 594 308 172 594 minecraft:amethyst_block
setblock 309 169 560 minecraft:light[level=14]
setblock 309 169 568 minecraft:light[level=14]
setblock 309 169 576 minecraft:light[level=14]
setblock 309 169 584 minecraft:light[level=14]
fill 309 169 592 309 172 593 minecraft:amethyst_block
setblock 310 169 599 minecraft:sea_lantern
setblock 317 169 560 minecraft:light[level=14]
setblock 317 169 568 minecraft:light[level=14]
setblock 317 169 576 minecraft:light[level=14]
setblock 317 169 584 minecraft:light[level=14]
setblock 317 169 592 minecraft:light[level=14]
fill 323 169 599 323 208 599 minecraft:magenta_stained_glass
setblock 324 169 568 minecraft:white_concrete
fill 324 169 585 324 198 585 minecraft:magenta_stained_glass
setblock 282 170 579 minecraft:sea_lantern
setblock 282 170 586 minecraft:light_blue_stained_glass
fill 283 170 599 283 217 599 minecraft:magenta_stained_glass
fill 300 170 599 300 200 599 minecraft:magenta_stained_glass
setblock 301 170 599 minecraft:sea_lantern
fill 304 170 591 304 172 593 minecraft:amethyst_block
fill 305 170 590 305 172 590 minecraft:amethyst_block
fill 306 170 595 307 172 595 minecraft:amethyst_block
fill 309 170 591 309 172 591 minecraft:amethyst_block
fill 310 170 599 310 174 599 minecraft:magenta_stained_glass
setblock 324 170 560 minecraft:light_blue_stained_glass
fill 324 170 568 324 220 568 minecraft:magenta_stained_glass
setblock 324 170 576 minecraft:white_concrete
fill 324 170 578 324 173 579 minecraft:magenta_stained_glass
setblock 324 170 580 minecraft:sea_lantern
setblock 282 171 568 minecraft:white_concrete
fill 282 171 569 282 214 569 minecraft:magenta_stained_glass
fill 282 171 579 282 189 579 minecraft:magenta_stained_glass
setblock 282 171 580 minecraft:sea_lantern
fill 282 171 586 282 174 586 minecraft:magenta_stained_glass
fill 301 171 599 301 194 599 minecraft:magenta_stained_glass
fill 304 171 590 304 172 590 minecraft:amethyst_block
fill 304 171 594 304 172 594 minecraft:amethyst_block
fill 305 171 589 308 172 589 minecraft:amethyst_block
fill 305 171 595 305 172 595 minecraft:amethyst_block
fill 308 171 595 308 172 595 minecraft:amethyst_block
fill 309 171 590 309 172 590 minecraft:amethyst_block
fill 309 171 594 309 172 594 minecraft:amethyst_block
fill 310 171 592 310 172 592 minecraft:amethyst_block
fill 324 171 560 324 193 560 minecraft:magenta_stained_glass
setblock 324 171 576 minecraft:light_blue_stained_glass
fill 324 171 580 324 172 580 minecraft:magenta_stained_glass
fill 282 172 568 282 206 568 minecraft:magenta_stained_glass
fill 282 172 580 282 188 580 minecraft:magenta_stained_glass
fill 303 172 591 303 172 593 minecraft:amethyst_block
setblock 304 172 595 minecraft:amethyst_block
fill 306 172 596 307 172 596 minecraft:amethyst_block
fill 307 172 597 307 175 597 minecraft:light_blue_stained_glass
setblock 309 172 589 minecraft:amethyst_block
setblock 309 172 595 minecraft:amethyst_block
setblock 310 172 591 minecraft:amethyst_block
fill 310 172 593 310 172 594 minecraft:amethyst_block
fill 324 172 576 324 200 576 minecraft:magenta_stained_glass
setblock 298 173 599 minecraft:light_blue_stained_glass
setblock 305 173 557 minecraft:white_concrete
fill 306 173 591 307 173 593 minecraft:light_blue_stained_glass
fill 306 173 596 306 174 598 minecraft:light_blue_stained_glass
fill 307 173 594 307 175 596 minecraft:light_blue_stained_glass
fill 307 173 598 308 174 598 minecraft:light_blue_stained_glass
fill 308 173 596 308 174 597 minecraft:light_blue_stained_glass
fill 310 173 558 312 175 560 minecraft:light_blue_stained_glass
fill 311 173 561 311 173 564 minecraft:light_blue_stained_glass
setblock 324 173 580 minecraft:white_concrete
setblock 324 173 596 minecraft:sea_lantern
fill 298 174 599 298 176 599 minecraft:magenta_stained_glass
fill 305 174 557 305 175 557 minecraft:magenta_stained_glass
fill 306 174 592 307 175 592 minecraft:light_blue_stained_glass
fill 306 174 594 306 174 595 minecraft:light_blue_stained_glass
fill 307 174 593 307 175 593 minecraft:light_blue_stained_glass
fill 308 174 594 308 174 595 minecraft:light_blue_stained_glass
fill 309 174 558 309 175 558 minecraft:light_blue_stained_glass
fill 310 174 561 312 174 562 minecraft:light_blue_stained_glass
setblock 311 174 563 minecraft:light_blue_stained_glass
fill 313 174 558 313 175 558 minecraft:light_blue_stained_glass
fill 324 174 578 324 206 578 minecraft:magenta_stained_glass
setblock 324 174 579 minecraft:light_blue_stained_glass
fill 324 174 580 324 220 580 minecraft:magenta_stained_glass
fill 324 174 596 324 214 596 minecraft:magenta_stained_glass
setblock 282 175 586 minecraft:sea_lantern
setblock 307 175 591 minecraft:light_blue_stained_glass
setblock 310 175 599 minecraft:white_concrete
setblock 311 175 561 minecraft:light_blue_stained_glass
setblock 324 175 563 minecraft:light_blue_stained_glass
fill 324 175 579 324 218 579 minecraft:magenta_stained_glass
fill 282 176 586 282 220 586 minecraft:magenta_stained_glass
setblock 305 176 557 minecraft:sea_lantern
setblock 307 176 592 minecraft:light_blue_stained_glass
fill 310 176 558 312 176 559 minecraft:light_blue_stained_glass
setblock 310 176 599 minecraft:magenta_stained_glass
fill 324 176 563 324 190 563 minecraft:magenta_stained_glass
setblock 285 177 560 minecraft:light[level=14]
setblock 285 177 568 minecraft:light[level=14]
setblock 285 177 576 minecraft:light[level=14]
setblock 285 177 584 minecraft:light[level=14]
setblock 285 177 592 minecraft:light[level=14]
fill 290 177 597 290 180 597 minecraft:light_blue_stained_glass
setblock 293 177 560 minecraft:light[level=14]
setblock 293 177 568 minecraft:light[level=14]
setblock 293 177 576 minecraft:light[level=14]
setblock 293 177 584 minecraft:light[level=14]
setblock 293 177 592 minecraft:light[level=14]
setblock 298 177 599 minecraft:light_blue_stained_glass
setblock 301 177 560 minecraft:light[level=14]
setblock 301 177 568 minecraft:light[level=14]
setblock 301 177 576 minecraft:light[level=14]
setblock 301 177 584 minecraft:light[level=14]
setblock 301 177 592 minecraft:light[level=14]
fill 305 177 557 305 216 557 minecraft:magenta_stained_glass
setblock 306 177 557 minecraft:white_concrete
fill 307 177 557 307 208 557 minecraft:magenta_stained_glass
setblock 308 177 557 minecraft:sea_lantern
setblock 309 177 560 minecraft:light[level=14]
setblock 309 177 568 minecraft:light[level=14]
setblock 309 177 576 minecraft:light[level=14]
setblock 309 177 584 minecraft:light[level=14]
setblock 309 177 592 minecraft:light[level=14]
setblock 310 177 599 minecraft:light_blue_stained_glass
setblock 317 177 560 minecraft:light[level=14]
setblock 317 177 568 minecraft:light[level=14]
setblock 317 177 576 minecraft:light[level=14]
setblock 317 177 584 minecraft:light[level=14]
setblock 317 177 592 minecraft:light[level=14]
fill 321 177 582 323 180 582 minecraft:light_blue_stained_glass
fill 322 177 581 322 180 581 minecraft:light_blue_stained_glass
fill 322 177 583 322 180 583 minecraft:light_blue_stained_glass
setblock 324 177 566 minecraft:sea_lantern
fill 282 178 574 282 216 574 minecraft:magenta_stained_glass
setblock 282 178 575 minecraft:white_concrete
setblock 282 178 596 minecraft:sea_lantern
fill 289 178 594 289 179 598 minecraft:light_blue_stained_glass
fill 290 178 589 290 178 596 minecraft:light_blue_stained_glass
fill 290 178 598 291 179 598 minecraft:light_blue_stained_glass
fill 291 178 594 291 179 597 minecraft:light_blue_stained_glass
fill 294 178 578 294 179 578 minecraft:magenta_stained_glass
fill 298 178 599 298 220 599 minecraft:magenta_stained_glass
fill 306 178 557 306 220 557 minecraft:magenta_stained_glass
setblock 308 178 557 minecraft:light_blue_stained_glass
fill 310 178 599 310 220 599 minecraft:magenta_stained_glass
fill 317 178 582 320 179 582 minecraft:light_blue_stained_glass
fill 319 178 581 321 179 581 minecraft:light_blue_stained_glass
fill 319 178 583 321 179 583 minecraft:light_blue_stained_glass
fill 323 178 581 323 179 581 minecraft:light_blue_stained_glass
fill 323 178 583 323 179 583 minecraft:light_blue_stained_glass
fill 324 178 566 324 198 566 minecraft:magenta_stained_glass
setblock 282 179 567 minecraft:sea_lantern
fill 282 179 575 282 214 575 minecraft:magenta_stained_glass
setblock 282 179 593 minecraft:light_blue_stained_glass
fill 282 179 596 282 214 596 minecraft:magenta_stained_glass
setblock 283 179 557 minecraft:light_blue_stained_glass
fill 290 179 591 290 179 596 minecraft:light_blue_stained_glass
fill 292 179 557 292 220 557 minecraft:magenta_stained_glass
setblock 293 179 557 minecraft:sea_lantern
setblock 299 179 557 minecraft:white_concrete
fill 308 179 557 308 202 557 minecraft:magenta_stained_glass
fill 315 179 582 316 179 582 minecraft:light_blue_stained_glass
setblock 318 179 581 minecraft:light_blue_stained_glass
setblock 318 179 583 minecraft:light_blue_stained_glass
setblock 282 180 563 minecraft:sea_lantern
fill 282 180 567 282 220 567 minecraft:magenta_stained_glass
fill 282 180 593 282 190 593 minecraft:magenta_stained_glass
fill 283 180 557 283 201 557 minecraft:magenta_stained_glass
fill 293 180 557 293 220 557 minecraft:magenta_stained_glass
fill 299 180 557 299 220 557 minecraft:magenta_stained_glass
fill 303 180 591 304 181 593 minecraft:magenta_stained_glass
fill 319 180 582 320 180 582 minecraft:light_blue_stained_glass
fill 282 181 563 282 216 563 minecraft:magenta_stained_glass
setblock 292 181 599 minecraft:sea_lantern
fill 314 181 557 315 181 557 minecraft:light_blue_stained_glass
fill 324 181 590 324 216 590 minecraft:magenta_stained_glass
setblock 324 181 591 minecraft:sea_lantern
fill 292 182 599 292 183 599 minecraft:magenta_stained_glass
setblock 313 182 557 minecraft:sea_lantern
fill 314 182 557 315 204 557 minecraft:magenta_stained_glass
fill 318 182 557 319 205 557 minecraft:magenta_stained_glass
setblock 320 182 557 minecraft:white_concrete
setblock 322 182 599 minecraft:sea_lantern
setblock 324 182 564 minecraft:white_concrete
fill 324 182 591 324 190 591 minecraft:magenta_stained_glass
setblock 282 183 570 minecraft:light_blue_stained_glass
fill 312 183 577 313 184 577 minecraft:amethyst_block
fill 313 183 557 313 218 557 minecraft:magenta_stained_glass
fill 320 183 557 320 184 557 minecraft:magenta_stained_glass
fill 322 183 599 322 220 599 minecraft:magenta_stained_glass
fill 324 183 564 324 192 564 minecraft:magenta_stained_glass
setblock 324 183 582 minecraft:white_concrete
fill 282 184 557 282 221 557 minecraft:magenta_stained_glass
setblock 282 184 558 minecraft:white_concrete
fill 282 184 570 282 190 570 minecraft:magenta_stained_glass
setblock 292 184 599 minecraft:sea_lantern
setblock 301 184 557 minecraft:white_concrete
fill 324 184 582 324 218 582 minecraft:magenta_stained_glass
fill 282 185 558 282 202 558 minecraft:magenta_stained_glass
setblock 282 185 577 minecraft:sea_lantern
fill 282 185 578 282 217 578 minecraft:magenta_stained_glass
setblock 285 185 560 minecraft:light[level=14]
setblock 285 185 568 minecraft:light[level=14]
setblock 285 185 576 minecraft:light[level=14]
setblock 285 185 584 minecraft:light[level=14]
setblock 285 185 592 minecraft:light[level=14]
fill 292 185 599 292 220 599 minecraft:magenta_stained_glass
setblock 293 185 560 minecraft:light[level=14]
setblock 293 185 568 minecraft:light[level=14]
setblock 293 185 576 minecraft:light[level=14]
setblock 293 185 584 minecraft:light[level=14]
setblock 293 185 592 minecraft:light[level=14]
fill 301 185 557 301 208 557 minecraft:magenta_stained_glass
setblock 301 185 560 minecraft:light[level=14]
setblock 301 185 568 minecraft:light[level=14]
setblock 301 185 576 minecraft:light[level=14]
setblock 301 185 584 minecraft:light[level=14]
setblock 301 185 592 minecraft:light[level=14]
setblock 309 185 560 minecraft:light[level=14]
setblock 309 185 568 minecraft:light[level=14]
setblock 309 185 576 minecraft:light[level=14]
setblock 309 185 584 minecraft:light[level=14]
setblock 309 185 592 minecraft:light[level=14]
setblock 309 185 599 minecraft:white_concrete
setblock 317 185 557 minecraft:light_blue_stained_glass
setblock 317 185 560 minecraft:light[level=14]
setblock 317 185 568 minecraft:light[level=14]
setblock 317 185 576 minecraft:light[level=14]
setblock 317 185 584 minecraft:light[level=14]
setblock 317 185 592 minecraft:light[level=14]
setblock 320 185 557 minecraft:light_blue_stained_glass
fill 321 185 568 323 188 568 minecraft:light_blue_stained_glass
fill 322 185 567 322 188 567 minecraft:light_blue_stained_glass
fill 322 185 569 322 188 569 minecraft:light_blue_stained_glass
fill 282 186 577 282 220 577 minecraft:magenta_stained_glass
setblock 282 186 584 minecraft:white_concrete
fill 309 186 599 309 194 599 minecraft:magenta_stained_glass
fill 317 186 557 317 193 557 minecraft:magenta_stained_glass
fill 320 186 557 320 216 557 minecraft:magenta_stained_glass
fill 320 186 567 320 188 569 minecraft:light_blue_stained_glass
fill 321 186 567 321 188 567 minecraft:light_blue_stained_glass
fill 321 186 569 321 188 569 minecraft:light_blue_stained_glass
fill 323 186 567 323 187 567 minecraft:light_blue_stained_glass
fill 323 186 569 323 187 569 minecraft:light_blue_stained_glass
setblock 324 186 584 minecraft:white_concrete
setblock 282 187 559 minecraft:sea_lantern
fill 282 187 584 282 220 584 minecraft:magenta_stained_glass
setblock 312 187 557 minecraft:white_concrete
fill 318 187 568 319 188 568 minecraft:light_blue_stained_glass
fill 319 187 567 319 188 567 minecraft:light_blue_stained_glass
fill 319 187 569 319 188 569 minecraft:light_blue_stained_glass
fill 324 187 584 324 200 584 minecraft:magenta_stained_glass
fill 282 188 559 282 220 559 minecraft:magenta_stained_glass
setblock 282 188 573 minecraft:white_concrete
setblock 290 188 557 minecraft:white_concrete
fill 312 188 557 312 190 557 minecraft:magenta_stained_glass
setblock 317 188 568 minecraft:light_blue_stained_glass
setblock 282 189 566 minecraft:light_blue_stained_glass
fill 282 189 573 282 191 573 minecraft:magenta_stained_glass
setblock 282 189 580 minecraft:light_blue_stained_glass
fill 290 189 557 290 203 557 minecraft:magenta_stained_glass
fill 296 189 579 302 206 581 minecraft:jungle_log
fill 297 189 578 301 207 578 minecraft:jungle_log
fill 297 189 582 301 207 582 minecraft:jungle_log
fill 298 189 577 300 207 577 minecraft:jungle_log
fill 298 189 583 300 207 583 minecraft:jungle_log
fill 282 190 566 282 220 566 minecraft:magenta_stained_glass
setblock 282 190 579 minecraft:white_concrete
fill 282 190 580 282 208 580 minecraft:magenta_stained_glass
setblock 282 190 590 minecraft:sea_lantern
setblock 286 190 557 minecraft:sea_lantern
setblock 324 190 561 minecraft:light_blue_stained_glass
setblock 282 191 570 minecraft:white_concrete
fill 282 191 579 282 206 579 minecraft:magenta_stained_glass
fill 282 191 590 282 218 590 minecraft:magenta_stained_glass
setblock 282 191 593 minecraft:white_concrete
setblock 284 191 599 minecraft:white_concrete
fill 286 191 557 286 220 557 minecraft:magenta_stained_glass
setblock 311 191 557 minecraft:sea_lantern
setblock 312 191 557 minecraft:light_blue_stained_glass
fill 317 191 599 317 202 599 minecraft:magenta_stained_glass
setblock 318 191 599 minecraft:light_blue_stained_glass
fill 319 191 599 319 220 599 minecraft:magenta_stained_glass
fill 324 191 561 324 202 561 minecraft:magenta_stained_glass
setblock 324 191 563 minecraft:sea_lantern
setblock 324 191 591 minecraft:sea_lantern
fill 282 192 570 282 220 570 minecraft:magenta_stained_glass
setblock 282 192 573 minecraft:sea_lantern
setblock 282 192 593 minecraft:magenta_stained_glass
fill 284 192 599 284 204 599 minecraft:magenta_stained_glass
setblock 285 192 557 minecraft:white_concrete
setblock 311 192 557 minecraft:white_concrete
fill 312 192 557 312 203 557 minecraft:magenta_stained_glass
fill 318 192 599 318 216 599 minecraft:magenta_stained_glass
fill 324 192 563 324 195 563 minecraft:magenta_stained_glass
fill 324 192 591 324 220 591 minecraft:magenta_stained_glass
fill 282 193 573 282 220 573 minecraft:magenta_stained_glass
setblock 282 193 593 minecraft:sea_lantern
fill 285 193 557 285 220 557 minecraft:magenta_stained_glass
setblock 285 193 560 minecraft:light[level=14]
setblock 285 193 568 minecraft:light[level=14]
setblock 285 193 576 minecraft:light[level=14]
setblock 285 193 584 minecraft:light[level=14]
setblock 285 193 592 minecraft:light[level=14]
setblock 293 193 560 minecraft:light[level=14]
setblock 293 193 568 minecraft:light[level=14]
setblock 293 193 576 minecraft:light[level=14]
setblock 293 193 584 minecraft:light[level=14]
setblock 293 193 592 minecraft:light[level=14]
setblock 301 193 560 minecraft:light[level=14]
setblock 301 193 568 minecraft:light[level=14]
setblock 301 193 576 minecraft:light[level=14]
setblock 301 193 584 minecraft:light[level=14]
setblock 301 193 592 minecraft:light[level=14]
fill 305 193 576 307 193 578 minecraft:redstone_block
fill 305 193 582 307 193 584 minecraft:redstone_block
setblock 309 193 560 minecraft:light[level=14]
setblock 309 193 568 minecraft:light[level=14]
setblock 309 193 576 minecraft:light[level=14]
setblock 309 193 584 minecraft:light[level=14]
setblock 309 193 592 minecraft:light[level=14]
fill 311 193 557 311 207 557 minecraft:magenta_stained_glass
fill 312 193 575 314 193 577 minecraft:redstone_block
fill 314 193 580 316 193 582 minecraft:redstone_block
setblock 317 193 560 minecraft:light[level=14]
setblock 317 193 568 minecraft:light[level=14]
setblock 317 193 576 minecraft:light[level=14]
setblock 317 193 584 minecraft:light[level=14]
setblock 317 193 592 minecraft:light[level=14]
setblock 324 193 564 minecraft:sea_lantern
setblock 324 193 595 minecraft:white_concrete
setblock 282 194 591 minecraft:sea_lantern
fill 282 194 593 282 206 593 minecraft:magenta_stained_glass
fill 283 194 558 295 194 598 minecraft:purple_stained_glass
fill 296 194 558 296 194 578 minecraft:purple_stained_glass
fill 296 194 582 296 194 598 minecraft:purple_stained_glass
fill 297 194 558 297 194 577 minecraft:purple_stained_glass
fill 297 194 583 297 194 598 minecraft:purple_stained_glass
fill 298 194 558 304 194 576 minecraft:purple_stained_glass
fill 298 194 584 304 194 598 minecraft:purple_stained_glass
fill 301 194 577 304 194 577 minecraft:purple_stained_glass
fill 301 194 583 304 194 583 minecraft:purple_stained_glass
fill 302 194 578 304 194 578 minecraft:purple_stained_glass
fill 302 194 582 304 194 582 minecraft:purple_stained_glass
fill 303 194 579 308 194 581 minecraft:purple_stained_glass
fill 305 194 558 311 194 575 minecraft:purple_stained_glass
fill 305 194 585 323 194 598 minecraft:purple_stained_glass
fill 308 194 576 311 194 578 minecraft:purple_stained_glass
fill 308 194 582 313 194 584 minecraft:purple_stained_glass
fill 312 194 558 323 194 574 minecraft:purple_stained_glass
fill 312 194 578 313 194 581 minecraft:purple_stained_glass
fill 314 194 578 323 194 579 minecraft:purple_stained_glass
fill 314 194 583 323 194 584 minecraft:purple_stained_glass
fill 315 194 575 323 194 577 minecraft:purple_stained_glass
setblock 317 194 557 minecraft:sea_lantern
fill 317 194 580 323 194 582 minecraft:purple_stained_glass
setblock 324 194 560 minecraft:sea_lantern
fill 324 194 564 324 216 564 minecraft:magenta_stained_glass
fill 324 194 595 324 220 595 minecraft:magenta_stained_glass
fill 282 195 591 282 220 591 minecraft:magenta_stained_glass
fill 283 195 558 283 195 559 minecraft:amethyst_block
fill 283 195 560 323 195 561 minecraft:purple_stained_glass
fill 283 195 562 283 195 565 minecraft:amethyst_block
fill 283 195 566 323 195 567 minecraft:purple_stained_glass
fill 283 195 568 283 195 571 minecraft:amethyst_block
fill 283 195 572 323 195 573 minecraft:purple_stained_glass
fill 283 195 574 283 195 577 minecraft:amethyst_block
fill 283 195 578 295 195 579 minecraft:purple_stained_glass
fill 283 195 580 283 195 583 minecraft:amethyst_block
fill 283 195 584 303 195 585 minecraft:purple_stained_glass
fill 283 195 586 283 195 589 minecraft:amethyst_block
fill 283 195 590 323 195 591 minecraft:purple_stained_glass
fill 283 195 592 283 195 595 minecraft:amethyst_block
fill 283 195 596 323 195 597 minecraft:purple_stained_glass
fill 283 195 598 323 195 598 minecraft:amethyst_block
fill 284 195 558 285 195 558 minecraft:purple_stained_glass
fill 284 195 559 323 195 559 minecraft:amethyst_block
fill 284 195 562 323 195 562 minecraft:amethyst_block
fill 284 195 563 285 195 564 minecraft:purple_stained_glass
fill 284 195 565 323 195 565 minecraft:amethyst_block
fill 284 195 568 323 195 568 minecraft:amethyst_block
fill 284 195 569 285 195 570 minecraft:purple_stained_glass
fill 284 195 571 323 195 571 minecraft:amethyst_block
fill 284 195 574 310 195 574 minecraft:amethyst_block
fill 284 195 575 285 195 576 minecraft:purple_stained_glass
fill 284 195 577 297 195 577 minecraft:amethyst_block
fill 284 195 580 295 195 580 minecraft:amethyst_block
fill 284 195 581 285 195 582 minecraft:purple_stained_glass
fill 284 195 583 297 195 583 minecraft:amethyst_block
fill 284 195 586 323 195 586 minecraft:amethyst_block
fill 284 195 587 285 195 588 minecraft:purple_stained_glass
fill 284 195 589 323 195 589 minecraft:amethyst_block
fill 284 195 592 323 195 592 minecraft:amethyst_block
fill 284 195 593 285 195 594 minecraft:purple_stained_glass
fill 284 195 595 323 195 595 minecraft:amethyst_block
setblock 286 195 558 minecraft:amethyst_block
fill 286 195 563 286 195 564 minecraft:amethyst_block
fill 286 195 569 286 195 570 minecraft:amethyst_block
fill 286 195 575 286 195 576 minecraft:amethyst_block
fill 286 195 581 286 195 582 minecraft:amethyst_block
fill 286 195 587 286 195 588 minecraft:amethyst_block
fill 286 195 593 286 195 594 minecraft:amethyst_block
fill 287 195 558 288 195 558 minecraft:purple_stained_glass
fill 287 195 563 288 195 564 minecraft:purple_stained_glass
fill 287 195 569 288 195 570 minecraft:purple_stained_glass
fill 287 195 575 288 195 576 minecraft:purple_stained_glass
fill 287 195 581 288 195 582 minecraft:purple_stained_glass
fill 287 195 587 288 195 588 minecraft:purple_stained_glass
fill 287 195 593 288 195 594 minecraft:purple_stained_glass
setblock 289 195 558 minecraft:amethyst_block
fill 289 195 563 289 195 564 minecraft:amethyst_block
fill 289 195 569 289 195 570 minecraft:amethyst_block
fill 289 195 575 289 195 576 minecraft:amethyst_block
fill 289 195 581 289 195 582 minecraft:amethyst_block
fill 289 195 587 289 195 588 minecraft:amethyst_block
fill 289 195 593 289 195 594 minecraft:amethyst_block
fill 290 195 558 291 195 558 minecraft:purple_stained_glass
fill 290 195 563 291 195 564 minecraft:purple_stained_glass
fill 290 195 569 291 195 570 minecraft:purple_stained_glass
fill 290 195 575 291 195 576 minecraft:purple_stained_glass
fill 290 195 581 291 195 582 minecraft:purple_stained_glass
fill 290 195 587 291 195 588 minecraft:purple_stained_glass
fill 290 195 593 291 195 594 minecraft:purple_stained_glass
setblock 292 195 558 minecraft:amethyst_block
fill 292 195 563 292 195 564 minecraft:amethyst_block
fill 292 195 569 292 195 570 minecraft:amethyst_block
fill 292 195 575 292 195 576 minecraft:amethyst_block
fill 292 195 581 292 195 582 minecraft:amethyst_block
fill 292 195 587 292 195 588 minecraft:amethyst_block
fill 292 195 593 292 195 594 minecraft:amethyst_block
fill 293 195 558 294 195 558 minecraft:purple_stained_glass
fill 293 195 563 294 195 564 minecraft:purple_stained_glass
fill 293 195 569 294 195 570 minecraft:purple_stained_glass
fill 293 195 575 294 195 576 minecraft:purple_stained_glass
fill 293 195 581 294 195 582 minecraft:purple_stained_glass
fill 293 195 587 294 195 588 minecraft:purple_stained_glass
fill 293 195 593 294 195 594 minecraft:purple_stained_glass
setblock 295 195 558 minecraft:amethyst_block
fill 295 195 563 295 195 564 minecraft:amethyst_block
fill 295 195 569 295 195 570 minecraft:amethyst_block
fill 295 195 575 295 195 576 minecraft:amethyst_block
fill 295 195 581 295 195 582 minecraft:amethyst_block
fill 295 195 587 295 195 588 minecraft:amethyst_block
fill 295 195 593 295 195 594 minecraft:amethyst_block
fill 296 195 558 297 195 558 minecraft:purple_stained_glass
fill 296 195 563 297 195 564 minecraft:purple_stained_glass
fill 296 195 569 297 195 570 minecraft:purple_stained_glass
fill 296 195 575 297 195 576 minecraft:purple_stained_glass
setblock 296 195 578 minecraft:purple_stained_glass
setblock 296 195 582 minecraft:purple_stained_glass
fill 296 195 587 297 195 588 minecraft:purple_stained_glass
fill 296 195 593 297 195 594 minecraft:purple_stained_glass
setblock 298 195 558 minecraft:amethyst_block
fill 298 195 563 298 195 564 minecraft:amethyst_block
fill 298 195 569 298 195 570 minecraft:amethyst_block
fill 298 195 575 298 195 576 minecraft:amethyst_block
fill 298 195 587 298 195 588 minecraft:amethyst_block
fill 298 195 593 298 195 594 minecraft:amethyst_block
fill 299 195 558 300 195 558 minecraft:purple_stained_glass
fill 299 195 563 300 195 564 minecraft:purple_stained_glass
fill 299 195 569 300 195 570 minecraft:purple_stained_glass
fill 299 195 575 300 195 576 minecraft:purple_stained_glass
fill 299 195 587 300 195 588 minecraft:purple_stained_glass
fill 299 195 593 300 195 594 minecraft:purple_stained_glass
setblock 300 195 557 minecraft:sea_lantern
setblock 301 195 558 minecraft:amethyst_block
fill 301 195 563 301 195 564 minecraft:amethyst_block
fill 301 195 569 301 195 570 minecraft:amethyst_block
fill 301 195 575 301 195 577 minecraft:amethyst_block
fill 301 195 583 303 195 583 minecraft:amethyst_block
fill 301 195 587 301 195 588 minecraft:amethyst_block
fill 301 195 593 301 195 594 minecraft:amethyst_block
setblock 301 195 599 minecraft:white_concrete
fill 302 195 558 303 195 558 minecraft:purple_stained_glass
fill 302 195 563 303 195 564 minecraft:purple_stained_glass
fill 302 195 569 303 195 570 minecraft:purple_stained_glass
fill 302 195 575 303 195 576 minecraft:purple_stained_glass
fill 302 195 577 303 195 577 minecraft:amethyst_block
fill 302 195 578 303 195 578 minecraft:purple_stained_glass
fill 302 195 582 303 195 582 minecraft:purple_stained_glass
fill 302 195 587 303 195 588 minecraft:purple_stained_glass
fill 302 195 593 303 195 594 minecraft:purple_stained_glass
setblock 303 195 579 minecraft:purple_stained_glass
fill 303 195 580 307 195 580 minecraft:amethyst_block
setblock 303 195 581 minecraft:purple_stained_glass
setblock 304 195 558 minecraft:amethyst_block
fill 304 195 563 304 195 564 minecraft:amethyst_block
fill 304 195 569 304 195 570 minecraft:amethyst_block
fill 304 195 575 304 195 579 minecraft:sea_lantern
fill 304 195 581 304 195 585 minecraft:sea_lantern
fill 304 195 587 304 195 588 minecraft:amethyst_block
fill 304 195 593 304 195 594 minecraft:amethyst_block
fill 305 195 558 306 195 558 minecraft:purple_stained_glass
fill 305 195 563 306 195 564 minecraft:purple_stained_glass
fill 305 195 569 306 195 570 minecraft:purple_stained_glass
fill 305 195 575 308 195 575 minecraft:sea_lantern
fill 305 195 576 307 195 578 minecraft:purple_stained_glass
fill 305 195 579 307 195 579 minecraft:sea_lantern
fill 305 195 581 307 195 581 minecraft:sea_lantern
fill 305 195 582 307 195 584 minecraft:purple_stained_glass
fill 305 195 585 308 195 585 minecraft:sea_lantern
fill 305 195 587 306 195 588 minecraft:purple_stained_glass
fill 305 195 593 306 195 594 minecraft:purple_stained_glass
setblock 307 195 558 minecraft:amethyst_block
fill 307 195 563 307 195 564 minecraft:amethyst_block
fill 307 195 569 307 195 570 minecraft:amethyst_block
fill 307 195 587 307 195 588 minecraft:amethyst_block
fill 307 195 593 307 195 594 minecraft:amethyst_block
fill 308 195 558 309 195 558 minecraft:purple_stained_glass
fill 308 195 563 309 195 564 minecraft:purple_stained_glass
fill 308 195 569 309 195 570 minecraft:purple_stained_glass
fill 308 195 576 308 195 578 minecraft:sea_lantern
fill 308 195 579 308 195 581 minecraft:ochre_froglight
fill 308 195 582 308 195 584 minecraft:sea_lantern
fill 308 195 587 309 195 588 minecraft:purple_stained_glass
fill 308 195 593 309 195 594 minecraft:purple_stained_glass
fill 309 195 575 309 195 576 minecraft:purple_stained_glass
fill 309 195 577 310 195 577 minecraft:amethyst_block
fill 309 195 578 311 195 578 minecraft:ochre_froglight
fill 309 195 582 311 195 582 minecraft:ochre_froglight
fill 309 195 583 312 195 583 minecraft:amethyst_block
fill 309 195 584 323 195 585 minecraft:purple_stained_glass
setblock 309 195 599 minecraft:sea_lantern
setblock 310 195 558 minecraft:amethyst_block
fill 310 195 563 310 195 564 minecraft:amethyst_block
fill 310 195 569 310 195 570 minecraft:amethyst_block
fill 310 195 575 310 195 576 minecraft:amethyst_block
fill 310 195 587 310 195 588 minecraft:amethyst_block
fill 310 195 593 310 195 594 minecraft:amethyst_block
fill 311 195 558 312 195 558 minecraft:purple_stained_glass
fill 311 195 563 312 195 564 minecraft:purple_stained_glass
fill 311 195 569 312 195 570 minecraft:purple_stained_glass
fill 311 195 574 311 195 577 minecraft:sea_lantern
fill 311 195 587 312 195 588 minecraft:purple_stained_glass
fill 311 195 593 312 195 594 minecraft:purple_stained_glass
fill 312 195 574 315 195 574 minecraft:sea_lantern
fill 312 195 575 314 195 577 minecraft:purple_stained_glass
fill 312 195 578 315 195 578 minecraft:sea_lantern
fill 312 195 579 312 195 581 minecraft:ochre_froglight
fill 312 195 582 313 195 582 minecraft:sea_lantern
setblock 313 195 558 minecraft:amethyst_block
fill 313 195 563 313 195 564 minecraft:amethyst_block
fill 313 195 569 313 195 570 minecraft:amethyst_block
fill 313 195 579 313 195 581 minecraft:sea_lantern
fill 313 195 583 317 195 583 minecraft:sea_lantern
fill 313 195 587 313 195 588 minecraft:amethyst_block
fill 313 195 593 313 195 594 minecraft:amethyst_block
fill 314 195 558 315 195 558 minecraft:purple_stained_glass
fill 314 195 563 315 195 564 minecraft:purple_stained_glass
fill 314 195 569 315 195 570 minecraft:purple_stained_glass
fill 314 195 579 317 195 579 minecraft:sea_lantern
fill 314 195 580 316 195 582 minecraft:purple_stained_glass
fill 314 195 587 315 195 588 minecraft:purple_stained_glass
fill 314 195 593 315 195 594 minecraft:purple_stained_glass
fill 315 195 575 315 195 577 minecraft:sea_lantern
setblock 316 195 558 minecraft:amethyst_block
fill 316 195 563 316 195 564 minecraft:amethyst_block
fill 316 195 569 316 195 570 minecraft:amethyst_block
fill 316 195 574 316 195 577 minecraft:amethyst_block
fill 316 195 578 323 195 578 minecraft:purple_stained_glass
fill 316 195 587 316 195 588 minecraft:amethyst_block
fill 316 195 593 316 195 594 minecraft:amethyst_block
fill 317 195 557 317 220 557 minecraft:magenta_stained_glass
fill 317 195 558 318 195 558 minecraft:purple_stained_glass
fill 317 195 563 318 195 564 minecraft:purple_stained_glass
fill 317 195 569 318 195 570 minecraft:purple_stained_glass
fill 317 195 574 323 195 574 minecraft:amethyst_block
fill 317 195 575 318 195 576 minecraft:purple_stained_glass
fill 317 195 577 323 195 577 minecraft:amethyst_block
fill 317 195 580 317 195 582 minecraft:sea_lantern
fill 317 195 587 318 195 588 minecraft:purple_stained_glass
fill 317 195 593 318 195 594 minecraft:purple_stained_glass
fill 318 195 579 323 195 579 minecraft:purple_stained_glass
fill 318 195 580 323 195 580 minecraft:amethyst_block
fill 318 195 581 318 195 582 minecraft:purple_stained_glass
fill 318 195 583 323 195 583 minecraft:amethyst_block
setblock 319 195 558 minecraft:amethyst_block
fill 319 195 563 319 195 564 minecraft:amethyst_block
fill 319 195 569 319 195 570 minecraft:amethyst_block
fill 319 195 575 319 195 576 minecraft:amethyst_block
fill 319 195 581 319 195 582 minecraft:amethyst_block
fill 319 195 587 319 195 588 minecraft:amethyst_block
fill 319 195 593 319 195 594 minecraft:amethyst_block
fill 320 195 558 321 195 558 minecraft:purple_stained_glass
fill 320 195 563 321 195 564 minecraft:purple_stained_glass
fill 320 195 569 321 195 570 minecraft:purple_stained_glass
fill 320 195 575 321 195 576 minecraft:purple_stained_glass
fill 320 195 581 321 195 582 minecraft:purple_stained_glass
fill 320 195 587 321 195 588 minecraft:purple_stained_glass
fill 320 195 593 321 195 594 minecraft:purple_stained_glass
setblock 322 195 558 minecraft:amethyst_block
fill 322 195 563 322 195 564 minecraft:amethyst_block
fill 322 195 569 322 195 570 minecraft:amethyst_block
fill 322 195 575 322 195 576 minecraft:amethyst_block
fill 322 195 581 322 195 582 minecraft:amethyst_block
fill 322 195 587 322 195 588 minecraft:amethyst_block
fill 322 195 593 322 195 594 minecraft:amethyst_block
setblock 323 195 558 minecraft:purple_stained_glass
fill 323 195 563 323 195 564 minecraft:purple_stained_glass
fill 323 195 569 323 195 570 minecraft:purple_stained_glass
fill 323 195 575 323 195 576 minecraft:purple_stained_glass
fill 323 195 581 323 195 582 minecraft:purple_stained_glass
fill 323 195 587 323 195 588 minecraft:purple_stained_glass
fill 323 195 593 323 195 594 minecraft:purple_stained_glass
fill 324 195 560 324 216 560 minecraft:magenta_stained_glass
setblock 324 195 569 minecraft:sea_lantern
setblock 282 196 598 minecraft:light_blue_stained_glass
setblock 284 196 557 minecraft:sea_lantern
fill 300 196 557 300 197 557 minecraft:magenta_stained_glass
fill 301 196 599 301 220 599 minecraft:magenta_stained_glass
fill 309 196 599 309 220 599 minecraft:magenta_stained_glass
setblock 316 196 557 minecraft:white_concrete
setblock 324 196 563 minecraft:white_concrete
fill 324 196 569 324 220 569 minecraft:magenta_stained_glass
fill 282 197 571 282 216 571 minecraft:magenta_stained_glass
setblock 282 197 572 minecraft:sea_lantern
fill 282 197 598 282 217 598 minecraft:magenta_stained_glass
fill 284 197 557 284 220 557 minecraft:magenta_stained_glass
setblock 293 197 599 minecraft:sea_lantern
fill 294 197 599 294 220 599 minecraft:magenta_stained_glass
fill 316 197 557 316 207 557 minecraft:magenta_stained_glass
setblock 321 197 557 minecraft:white_concrete
fill 324 197 563 324 216 563 minecraft:magenta_stained_glass
fill 282 198 572 282 212 572 minecraft:magenta_stained_glass
setblock 290 198 599 minecraft:sea_lantern
fill 293 198 599 293 220 599 minecraft:magenta_stained_glass
setblock 300 198 557 minecraft:sea_lantern
setblock 304 198 557 minecraft:sea_lantern
fill 321 198 557 321 220 557 minecraft:magenta_stained_glass
setblock 324 198 592 minecraft:white_concrete
fill 290 199 599 290 204 599 minecraft:magenta_stained_glass
fill 300 199 557 300 214 557 minecraft:magenta_stained_glass
fill 304 199 557 304 221 557 minecraft:magenta_stained_glass
setblock 304 199 599 minecraft:white_concrete
fill 321 199 582 323 204 584 minecraft:light_blue_stained_glass
setblock 324 199 566 minecraft:light_blue_stained_glass
setblock 324 199 585 minecraft:light_blue_stained_glass
fill 324 199 592 324 217 592 minecraft:magenta_stained_glass
setblock 282 200 564 minecraft:light_blue_stained_glass
fill 304 200 599 304 221 599 minecraft:magenta_stained_glass
fill 319 200 583 320 204 583 minecraft:light_blue_stained_glass
fill 320 200 582 320 203 582 minecraft:light_blue_stained_glass
fill 320 200 584 320 203 584 minecraft:light_blue_stained_glass
fill 321 200 581 323 203 581 minecraft:light_blue_stained_glass
fill 321 200 585 323 203 585 minecraft:light_blue_stained_glass
fill 324 200 566 324 220 566 minecraft:magenta_stained_glass
fill 324 200 585 324 220 585 minecraft:magenta_stained_glass
fill 282 201 564 282 210 564 minecraft:magenta_stained_glass
setblock 285 201 560 minecraft:light[level=14]
setblock 285 201 568 minecraft:light[level=14]
setblock 285 201 576 minecraft:light[level=14]
setblock 285 201 584 minecraft:light[level=14]
setblock 285 201 592 minecraft:light[level=14]
setblock 293 201 560 minecraft:light[level=14]
setblock 293 201 568 minecraft:light[level=14]
setblock 293 201 576 minecraft:light[level=14]
setblock 293 201 584 minecraft:light[level=14]
setblock 293 201 592 minecraft:light[level=14]
setblock 295 201 557 minecraft:sea_lantern
setblock 300 201 599 minecraft:white_concrete
setblock 301 201 560 minecraft:light[level=14]
setblock 301 201 568 minecraft:light[level=14]
setblock 301 201 576 minecraft:light[level=14]
setblock 301 201 584 minecraft:light[level=14]
setblock 301 201 592 minecraft:light[level=14]
setblock 309 201 560 minecraft:light[level=14]
setblock 309 201 568 minecraft:light[level=14]
setblock 309 201 576 minecraft:light[level=14]
setblock 309 201 584 minecraft:light[level=14]
setblock 309 201 592 minecraft:light[level=14]
setblock 317 201 560 minecraft:light[level=14]
setblock 317 201 568 minecraft:light[level=14]
setblock 317 201 576 minecraft:light[level=14]
setblock 317 201 584 minecraft:light[level=14]
setblock 317 201 592 minecraft:light[level=14]
fill 318 201 582 318 203 584 minecraft:light_blue_stained_glass
fill 319 201 582 319 203 582 minecraft:light_blue_stained_glass
fill 319 201 584 319 203 584 minecraft:light_blue_stained_glass
fill 320 201 581 320 203 581 minecraft:light_blue_stained_glass
fill 320 201 585 320 203 585 minecraft:light_blue_stained_glass
setblock 324 201 576 minecraft:sea_lantern
setblock 324 201 584 minecraft:light_blue_stained_glass
setblock 283 202 557 minecraft:sea_lantern
fill 295 202 557 295 217 557 minecraft:magenta_stained_glass
fill 300 202 599 300 218 599 minecraft:magenta_stained_glass
fill 316 202 583 317 203 583 minecraft:light_blue_stained_glass
fill 317 202 582 317 203 582 minecraft:light_blue_stained_glass
fill 317 202 584 317 203 584 minecraft:light_blue_stained_glass
fill 317 202 597 317 205 597 minecraft:light_blue_stained_glass
setblock 319 202 581 minecraft:light_blue_stained_glass
setblock 319 202 585 minecraft:light_blue_stained_glass
setblock 323 202 557 minecraft:sea_lantern
fill 324 202 572 324 220 572 minecraft:magenta_stained_glass
setblock 324 202 573 minecraft:white_concrete
fill 324 202 576 324 216 576 minecraft:magenta_stained_glass
fill 324 202 584 324 216 584 minecraft:magenta_stained_glass
fill 324 202 588 324 206 588 minecraft:magenta_stained_glass
setblock 324 202 589 minecraft:light_blue_stained_glass
setblock 282 203 558 minecraft:light_blue_stained_glass
setblock 282 203 592 minecraft:sea_lantern
fill 283 203 557 283 217 557 minecraft:magenta_stained_glass
fill 287 203 557 287 220 557 minecraft:magenta_stained_glass
setblock 288 203 557 minecraft:white_concrete
fill 307 203 586 307 204 587 minecraft:light_blue_stained_glass
setblock 308 203 557 minecraft:white_concrete
setblock 308 203 599 minecraft:light_blue_stained_glass
setblock 315 203 583 minecraft:light_blue_stained_glass
fill 316 203 596 316 204 598 minecraft:light_blue_stained_glass
fill 317 203 595 317 205 596 minecraft:light_blue_stained_glass
fill 317 203 598 317 203 599 minecraft:light_blue_stained_glass
fill 318 203 596 318 204 598 minecraft:light_blue_stained_glass
fill 323 203 557 323 221 557 minecraft:magenta_stained_glass
setblock 324 203 561 minecraft:light_blue_stained_glass
fill 324 203 573 324 220 573 minecraft:magenta_stained_glass
fill 324 203 589 324 220 589 minecraft:magenta_stained_glass
fill 282 204 558 282 220 558 minecraft:magenta_stained_glass
fill 282 204 592 282 207 592 minecraft:magenta_stained_glass
fill 288 204 557 288 220 557 minecraft:magenta_stained_glass
setblock 290 204 557 minecraft:light_blue_stained_glass
fill 308 204 557 308 220 557 minecraft:magenta_stained_glass
fill 308 204 599 308 220 599 minecraft:magenta_stained_glass
setblock 312 204 557 minecraft:white_concrete
setblock 316 204 595 minecraft:light_blue_stained_glass
fill 317 204 593 317 205 594 minecraft:light_blue_stained_glass
setblock 317 204 598 minecraft:light_blue_stained_glass
fill 317 204 599 317 218 599 minecraft:magenta_stained_glass
setblock 318 204 595 minecraft:light_blue_stained_glass
fill 324 204 561 324 220 561 minecraft:magenta_stained_glass
setblock 324 204 598 minecraft:light_blue_stained_glass
setblock 284 205 599 minecraft:white_concrete
fill 290 205 557 290 218 557 minecraft:magenta_stained_glass
setblock 290 205 599 minecraft:white_concrete
fill 312 205 557 312 207 557 minecraft:magenta_stained_glass
setblock 314 205 557 minecraft:sea_lantern
fill 315 205 557 315 208 557 minecraft:magenta_stained_glass
fill 321 205 563 323 210 563 minecraft:light_blue_stained_glass
fill 322 205 562 322 210 562 minecraft:light_blue_stained_glass
fill 322 205 564 322 210 564 minecraft:light_blue_stained_glass
setblock 324 205 577 minecraft:light_blue_stained_glass
fill 324 205 598 324 220 598 minecraft:magenta_stained_glass
setblock 282 206 588 minecraft:white_concrete
fill 284 206 599 284 220 599 minecraft:magenta_stained_glass
fill 290 206 599 290 208 599 minecraft:magenta_stained_glass
setblock 302 206 599 minecraft:white_concrete
fill 314 206 557 314 220 557 minecraft:magenta_stained_glass
fill 317 206 563 320 207 563 minecraft:light_blue_stained_glass
setblock 318 206 557 minecraft:sea_lantern
fill 318 206 562 321 208 562 minecraft:light_blue_stained_glass
fill 318 206 564 321 208 564 minecraft:light_blue_stained_glass
fill 319 206 557 319 218 557 minecraft:magenta_stained_glass
fill 321 206 561 323 209 561 minecraft:light_blue_stained_glass
fill 321 206 565 323 209 565 minecraft:light_blue_stained_glass
fill 323 206 562 323 209 562 minecraft:light_blue_stained_glass
fill 323 206 564 323 209 564 minecraft:light_blue_stained_glass
fill 324 206 577 324 220 577 minecraft:magenta_stained_glass
setblock 282 207 568 minecraft:white_concrete
setblock 282 207 579 minecraft:light_blue_stained_glass
fill 282 207 588 282 223 588 minecraft:magenta_stained_glass
setblock 282 207 593 minecraft:light_blue_stained_glass
fill 290 207 580 290 208 580 minecraft:jungle_log
fill 296 207 579 300 207 581 minecraft:jungle_log
fill 301 207 579 306 207 581 minecraft:jungle_leaves[persistent=true]
fill 302 207 577 306 212 578 minecraft:jungle_leaves[persistent=true]
fill 302 207 582 306 212 583 minecraft:jungle_leaves[persistent=true]
fill 302 207 599 302 216 599 minecraft:magenta_stained_glass
fill 303 207 576 311 209 576 minecraft:jungle_leaves[persistent=true]
fill 303 207 584 311 209 584 minecraft:jungle_leaves[persistent=true]
fill 305 207 575 309 214 575 minecraft:jungle_leaves[persistent=true]
fill 305 207 585 309 214 585 minecraft:jungle_leaves[persistent=true]
fill 307 207 577 307 211 577 minecraft:jungle_leaves[persistent=true]
fill 307 207 583 307 211 583 minecraft:jungle_leaves[persistent=true]
fill 308 207 580 308 208 580 minecraft:jungle_log
setblock 316 207 563 minecraft:light_blue_stained_glass
fill 318 207 557 318 220 557 minecraft:magenta_stained_glass
fill 320 207 561 320 208 561 minecraft:light_blue_stained_glass
fill 320 207 565 320 208 565 minecraft:light_blue_stained_glass
setblock 324 207 578 minecraft:sea_lantern
setblock 324 207 588 minecraft:sea_lantern
fill 282 208 568 282 220 568 minecraft:magenta_stained_glass
fill 282 208 579 282 217 579 minecraft:magenta_stained_glass
setblock 282 208 592 minecraft:white_concrete
fill 282 208 593 282 220 593 minecraft:magenta_stained_glass
fill 291 208 580 293 208 580 minecraft:jungle_log
fill 295 208 573 295 208 574 minecraft:jungle_log
fill 295 208 586 295 208 587 minecraft:jungle_log
fill 296 208 574 296 208 575 minecraft:jungle_log
fill 296 208 579 296 208 581 minecraft:jungle_log
fill 296 208 585 296 208 586 minecraft:jungle_log
setblock 297 208 578 minecraft:jungle_log
fill 297 208 579 304 208 581 minecraft:jungle_leaves[persistent=true]
setblock 297 208 582 minecraft:jungle_log
fill 298 208 577 301 208 578 minecraft:jungle_leaves[persistent=true]
fill 298 208 582 301 208 583 minecraft:jungle_leaves[persistent=true]
fill 299 208 575 301 208 576 minecraft:jungle_leaves[persistent=true]
fill 299 208 584 301 208 585 minecraft:jungle_leaves[persistent=true]
fill 300 208 574 301 213 574 minecraft:jungle_leaves[persistent=true]
fill 300 208 586 301 213 586 minecraft:jungle_leaves[persistent=true]
fill 302 208 573 302 213 573 minecraft:jungle_leaves[persistent=true]
fill 302 208 574 302 208 575 minecraft:jungle_log
fill 302 208 576 302 217 576 minecraft:jungle_leaves[persistent=true]
fill 302 208 584 302 217 584 minecraft:jungle_leaves[persistent=true]
fill 302 208 585 302 208 586 minecraft:jungle_log
fill 302 208 587 302 213 587 minecraft:jungle_leaves[persistent=true]
fill 303 208 573 303 208 574 minecraft:jungle_log
fill 303 208 575 304 213 575 minecraft:jungle_leaves[persistent=true]
fill 303 208 585 304 213 585 minecraft:jungle_leaves[persistent=true]
fill 303 208 586 303 208 587 minecraft:jungle_log
fill 304 208 572 310 213 574 minecraft:jungle_leaves[persistent=true]
fill 304 208 586 310 213 588 minecraft:jungle_leaves[persistent=true]
fill 305 208 579 306 210 579 minecraft:jungle_leaves[persistent=true]
fill 305 208 580 307 208 580 minecraft:jungle_log
fill 305 208 581 306 210 581 minecraft:jungle_leaves[persistent=true]
fill 310 208 575 315 213 575 minecraft:jungle_leaves[persistent=true]
fill 310 208 585 315 213 585 minecraft:jungle_leaves[persistent=true]
setblock 311 208 557 minecraft:white_concrete
fill 311 208 573 312 213 574 minecraft:jungle_leaves[persistent=true]
fill 311 208 586 312 213 587 minecraft:jungle_leaves[persistent=true]
setblock 312 208 557 minecraft:sea_lantern
fill 312 208 576 315 212 576 minecraft:jungle_leaves[persistent=true]
fill 312 208 584 315 212 584 minecraft:jungle_leaves[persistent=true]
fill 313 208 574 314 213 574 minecraft:jungle_leaves[persistent=true]
fill 313 208 577 316 211 577 minecraft:jungle_leaves[persistent=true]
fill 313 208 583 316 211 583 minecraft:jungle_leaves[persistent=true]
fill 313 208 586 314 213 586 minecraft:jungle_leaves[persistent=true]
fill 314 208 578 316 209 582 minecraft:jungle_leaves[persistent=true]
setblock 316 208 557 minecraft:white_concrete
fill 317 208 579 317 213 581 minecraft:jungle_leaves[persistent=true]
fill 318 208 563 320 208 563 minecraft:light_blue_stained_glass
setblock 324 208 574 minecraft:light_blue_stained_glass
fill 324 208 578 324 218 578 minecraft:magenta_stained_glass
fill 324 208 588 324 218 588 minecraft:magenta_stained_glass
setblock 282 209 580 minecraft:light_blue_stained_glass
fill 282 209 592 282 220 592 minecraft:magenta_stained_glass
setblock 285 209 560 minecraft:light[level=14]
setblock 285 209 568 minecraft:light[level=14]
setblock 285 209 576 minecraft:light[level=14]
setblock 285 209 584 minecraft:light[level=14]
setblock 285 209 592 minecraft:light[level=14]
setblock 290 209 599 minecraft:white_concrete
setblock 293 209 560 minecraft:light[level=14]
setblock 293 209 568 minecraft:light[level=14]
setblock 293 209 576 minecraft:light[level=14]
fill 293 209 580 296 209 580 minecraft:jungle_log
setblock 293 209 584 minecraft:light[level=14]
setblock 293 209 592 minecraft:light[level=14]
setblock 296 209 575 minecraft:jungle_log
fill 296 209 576 296 212 579 minecraft:jungle_leaves[persistent=true]
fill 296 209 581 296 212 584 minecraft:jungle_leaves[persistent=true]
setblock 296 209 585 minecraft:jungle_log
fill 297 209 575 301 212 575 minecraft:jungle_leaves[persistent=true]
fill 297 209 576 297 209 577 minecraft:jungle_log
fill 297 209 578 301 209 582 minecraft:jungle_leaves[persistent=true]
fill 297 209 583 297 209 584 minecraft:jungle_log
fill 297 209 585 301 212 585 minecraft:jungle_leaves[persistent=true]
fill 298 209 574 299 212 574 minecraft:jungle_leaves[persistent=true]
fill 298 209 576 300 212 577 minecraft:jungle_leaves[persistent=true]
fill 298 209 583 300 212 584 minecraft:jungle_leaves[persistent=true]
fill 298 209 586 299 212 586 minecraft:jungle_leaves[persistent=true]
fill 299 209 573 301 212 573 minecraft:jungle_leaves[persistent=true]
fill 299 209 587 301 212 587 minecraft:jungle_leaves[persistent=true]
fill 300 209 572 303 212 572 minecraft:jungle_leaves[persistent=true]
fill 300 209 588 303 212 588 minecraft:jungle_leaves[persistent=true]
setblock 301 209 557 minecraft:light_blue_stained_glass
setblock 301 209 560 minecraft:light[level=14]
setblock 301 209 568 minecraft:light[level=14]
fill 301 209 576 301 209 577 minecraft:jungle_log
fill 301 209 583 301 209 584 minecraft:jungle_log
setblock 301 209 592 minecraft:light[level=14]
fill 302 209 571 312 212 571 minecraft:jungle_leaves[persistent=true]
fill 302 209 574 303 213 574 minecraft:jungle_leaves[persistent=true]
setblock 302 209 575 minecraft:jungle_log
fill 302 209 579 304 217 579 minecraft:jungle_leaves[persistent=true]
fill 302 209 580 305 209 580 minecraft:jungle_log
fill 302 209 581 304 217 581 minecraft:jungle_leaves[persistent=true]
setblock 302 209 585 minecraft:jungle_log
fill 302 209 586 303 213 586 minecraft:jungle_leaves[persistent=true]
fill 302 209 589 312 212 589 minecraft:jungle_leaves[persistent=true]
fill 303 209 573 303 213 573 minecraft:jungle_leaves[persistent=true]
fill 303 209 587 303 213 587 minecraft:jungle_leaves[persistent=true]
fill 305 209 570 309 212 570 minecraft:jungle_leaves[persistent=true]
fill 305 209 590 309 212 590 minecraft:jungle_leaves[persistent=true]
setblock 306 209 580 minecraft:jungle_leaves[persistent=true]
setblock 307 209 557 minecraft:light_blue_stained_glass
setblock 309 209 560 minecraft:light[level=14]
setblock 309 209 568 minecraft:light[level=14]
setblock 309 209 592 minecraft:light[level=14]
fill 311 209 557 312 220 557 minecraft:magenta_stained_glass
fill 311 209 572 314 212 572 minecraft:jungle_leaves[persistent=true]
fill 311 209 588 314 212 588 minecraft:jungle_leaves[persistent=true]
fill 313 209 573 315 212 573 minecraft:jungle_leaves[persistent=true]
fill 313 209 587 315 212 587 minecraft:jungle_leaves[persistent=true]
setblock 315 209 557 minecraft:white_concrete
fill 315 209 574 316 212 574 minecraft:jungle_leaves[persistent=true]
fill 315 209 586 316 212 586 minecraft:jungle_leaves[persistent=true]
fill 316 209 557 316 220 557 minecraft:magenta_stained_glass
fill 316 209 575 317 212 576 minecraft:jungle_leaves[persistent=true]
fill 316 209 584 317 212 585 minecraft:jungle_leaves[persistent=true]
setblock 317 209 560 minecraft:light[level=14]
setblock 317 209 568 minecraft:light[level=14]
fill 317 209 577 318 212 578 minecraft:jungle_leaves[persistent=true]
fill 317 209 582 318 212 583 minecraft:jungle_leaves[persistent=true]
setblock 317 209 592 minecraft:light[level=14]
fill 318 209 576 318 212 576 minecraft:jungle_leaves[persistent=true]
fill 318 209 579 318 212 581 minecraft:jungle_leaves[persistent=true]
fill 318 209 584 318 212 584 minecraft:jungle_leaves[persistent=true]
fill 319 209 563 320 209 563 minecraft:light_blue_stained_glass
fill 319 209 580 319 212 580 minecraft:jungle_leaves[persistent=true]
fill 320 209 562 321 209 562 minecraft:light_blue_stained_glass
fill 320 209 564 321 209 564 minecraft:light_blue_stained_glass
setblock 323 209 599 minecraft:sea_lantern
fill 324 209 574 324 221 574 minecraft:magenta_stained_glass
setblock 324 209 586 minecraft:light_blue_stained_glass
fill 324 209 587 324 220 587 minecraft:magenta_stained_glass
fill 282 210 580 282 220 580 minecraft:magenta_stained_glass
fill 290 210 599 290 220 599 minecraft:magenta_stained_glass
fill 295 210 576 295 211 584 minecraft:jungle_leaves[persistent=true]
fill 296 210 575 296 211 575 minecraft:jungle_leaves[persistent=true]
fill 296 210 580 302 210 580 minecraft:jungle_log
fill 296 210 585 296 211 585 minecraft:jungle_leaves[persistent=true]
fill 297 210 574 297 211 574 minecraft:jungle_leaves[persistent=true]
fill 297 210 576 297 212 579 minecraft:jungle_leaves[persistent=true]
fill 297 210 581 297 212 584 minecraft:jungle_leaves[persistent=true]
fill 297 210 586 297 211 586 minecraft:jungle_leaves[persistent=true]
setblock 298 210 557 minecraft:light_blue_stained_glass
fill 298 210 573 298 211 573 minecraft:jungle_leaves[persistent=true]
fill 298 210 578 298 210 579 minecraft:jungle_log
fill 298 210 581 298 210 582 minecraft:jungle_log
fill 298 210 587 298 211 587 minecraft:jungle_leaves[persistent=true]
fill 299 210 572 299 211 572 minecraft:jungle_leaves[persistent=true]
fill 299 210 578 299 218 578 minecraft:jungle_leaves[persistent=true]
fill 299 210 579 300 210 579 minecraft:jungle_log
fill 299 210 581 300 210 581 minecraft:jungle_log
fill 299 210 582 299 218 582 minecraft:jungle_leaves[persistent=true]
fill 299 210 588 299 211 588 minecraft:jungle_leaves[persistent=true]
fill 300 210 571 301 211 571 minecraft:jungle_leaves[persistent=true]
setblock 300 210 578 minecraft:jungle_log
setblock 300 210 582 minecraft:jungle_log
fill 300 210 589 301 211 589 minecraft:jungle_leaves[persistent=true]
fill 301 210 557 301 220 557 minecraft:magenta_stained_glass
fill 301 210 576 301 217 579 minecraft:jungle_leaves[persistent=true]
fill 301 210 581 301 217 584 minecraft:jungle_leaves[persistent=true]
fill 302 210 570 304 211 570 minecraft:jungle_leaves[persistent=true]
fill 302 210 575 302 217 575 minecraft:jungle_leaves[persistent=true]
fill 302 210 585 302 217 585 minecraft:jungle_leaves[persistent=true]
fill 302 210 590 304 211 590 minecraft:jungle_leaves[persistent=true]
fill 303 210 576 309 210 576 minecraft:jungle_leaves[persistent=true]
fill 303 210 580 305 217 580 minecraft:jungle_leaves[persistent=true]
fill 303 210 584 309 210 584 minecraft:jungle_leaves[persistent=true]
fill 307 210 557 307 217 557 minecraft:magenta_stained_glass
fill 310 210 570 312 211 570 minecraft:jungle_leaves[persistent=true]
fill 310 210 590 312 211 590 minecraft:jungle_leaves[persistent=true]
setblock 311 210 576 minecraft:jungle_leaves[persistent=true]
setblock 311 210 584 minecraft:jungle_leaves[persistent=true]
fill 313 210 571 314 211 571 minecraft:jungle_leaves[persistent=true]
fill 313 210 589 314 211 589 minecraft:jungle_leaves[persistent=true]
fill 314 210 578 316 210 579 minecraft:jungle_leaves[persistent=true]
fill 314 210 581 316 210 582 minecraft:jungle_leaves[persistent=true]
fill 315 210 557 315 221 557 minecraft:magenta_stained_glass
fill 315 210 572 315 211 572 minecraft:jungle_leaves[persistent=true]
fill 315 210 580 316 213 580 minecraft:jungle_leaves[persistent=true]
fill 315 210 588 315 211 588 minecraft:jungle_leaves[persistent=true]
fill 316 210 573 316 211 573 minecraft:jungle_leaves[persistent=true]
fill 316 210 587 316 211 587 minecraft:jungle_leaves[persistent=true]
fill 317 210 574 317 211 574 minecraft:jungle_leaves[persistent=true]
fill 317 210 586 317 211 586 minecraft:jungle_leaves[persistent=true]
fill 318 210 575 318 211 575 minecraft:jungle_leaves[persistent=true]
fill 318 210 585 318 211 585 minecraft:jungle_leaves[persistent=true]
fill 319 210 576 319 211 579 minecraft:jungle_leaves[persistent=true]
fill 319 210 581 319 211 584 minecraft:jungle_leaves[persistent=true]
fill 323 210 599 323 220 599 minecraft:magenta_stained_glass
fill 324 210 586 324 220 586 minecraft:magenta_stained_glass
setblock 282 211 564 minecraft:light_blue_stained_glass
setblock 287 211 599 minecraft:light_blue_stained_glass
fill 288 211 599 289 220 599 minecraft:magenta_stained_glass
fill 296 211 580 298 218 580 minecraft:jungle_leaves[persistent=true]
fill 298 211 557 298 217 557 minecraft:magenta_stained_glass
fill 298 211 578 298 218 579 minecraft:jungle_leaves[persistent=true]
fill 298 211 581 298 218 582 minecraft:jungle_leaves[persistent=true]
fill 299 211 579 300 218 579 minecraft:jungle_leaves[persistent=true]
setblock 299 211 580 minecraft:jungle_log
fill 299 211 581 300 218 581 minecraft:jungle_leaves[persistent=true]
fill 300 211 578 300 218 578 minecraft:jungle_leaves[persistent=true]
fill 300 211 580 302 218 580 minecraft:jungle_leaves[persistent=true]
fill 300 211 582 300 218 582 minecraft:jungle_leaves[persistent=true]
fill 303 211 576 308 212 576 minecraft:jungle_leaves[persistent=true]
fill 303 211 584 308 212 584 minecraft:jungle_leaves[persistent=true]
fill 305 211 579 305 216 579 minecraft:jungle_leaves[persistent=true]
fill 305 211 581 305 216 581 minecraft:jungle_leaves[persistent=true]
setblock 313 211 599 minecraft:light_blue_stained_glass
fill 314 211 578 316 212 578 minecraft:jungle_leaves[persistent=true]
fill 314 211 582 316 212 582 minecraft:jungle_leaves[persistent=true]
fill 315 211 579 316 213 579 minecraft:jungle_leaves[persistent=true]
fill 315 211 581 316 213 581 minecraft:jungle_leaves[persistent=true]
setblock 324 211 594 minecraft:white_concrete
setblock 324 211 597 minecraft:white_concrete
fill 282 212 564 282 220 564 minecraft:magenta_stained_glass
fill 287 212 599 287 216 599 minecraft:magenta_stained_glass
setblock 295 212 580 minecraft:jungle_leaves[persistent=true]
fill 297 212 565 297 213 565 minecraft:light_blue_stained_glass
fill 299 212 580 299 218 580 minecraft:jungle_leaves[persistent=true]
setblock 306 212 599 minecraft:white_concrete
fill 307 212 599 307 217 599 minecraft:magenta_stained_glass
fill 313 212 599 313 220 599 minecraft:magenta_stained_glass
fill 314 212 577 316 213 577 minecraft:jungle_leaves[persistent=true]
fill 314 212 583 316 213 583 minecraft:jungle_leaves[persistent=true]
fill 324 212 594 324 218 594 minecraft:magenta_stained_glass
fill 324 212 597 324 221 597 minecraft:magenta_stained_glass
setblock 282 213 572 minecraft:light_blue_stained_glass
setblock 282 213 587 minecraft:light_blue_stained_glass
fill 296 213 578 297 218 579 minecraft:jungle_leaves[persistent=true]
fill 296 213 581 297 218 582 minecraft:jungle_leaves[persistent=true]
fill 297 213 577 300 218 577 minecraft:jungle_leaves[persistent=true]
fill 297 213 583 300 218 583 minecraft:jungle_leaves[persistent=true]
setblock 297 213 599 minecraft:white_concrete
fill 299 213 575 300 217 576 minecraft:jungle_leaves[persistent=true]
fill 299 213 584 300 217 585 minecraft:jungle_leaves[persistent=true]
fill 301 213 575 301 217 575 minecraft:jungle_leaves[persistent=true]
fill 301 213 585 301 217 585 minecraft:jungle_leaves[persistent=true]
fill 302 213 577 305 216 578 minecraft:jungle_leaves[persistent=true]
fill 302 213 582 305 216 583 minecraft:jungle_leaves[persistent=true]
fill 303 213 576 307 214 576 minecraft:jungle_leaves[persistent=true]
fill 303 213 584 307 214 584 minecraft:jungle_leaves[persistent=true]
fill 306 213 577 306 214 577 minecraft:jungle_leaves[persistent=true]
fill 306 213 583 306 214 583 minecraft:jungle_leaves[persistent=true]
fill 306 213 599 306 220 599 minecraft:magenta_stained_glass
setblock 309 213 557 minecraft:sea_lantern
fill 313 213 576 315 213 576 minecraft:jungle_leaves[persistent=true]
fill 313 213 584 315 213 584 minecraft:jungle_leaves[persistent=true]
fill 315 213 578 316 213 578 minecraft:jungle_leaves[persistent=true]
fill 315 213 582 316 213 582 minecraft:jungle_leaves[persistent=true]
fill 282 214 572 282 220 572 minecraft:magenta_stained_glass
fill 282 214 587 282 220 587 minecraft:magenta_stained_glass
fill 293 214 580 295 217 580 minecraft:jungle_leaves[persistent=true]
fill 294 214 577 295 217 579 minecraft:jungle_leaves[persistent=true]
fill 294 214 581 295 217 583 minecraft:jungle_leaves[persistent=true]
fill 295 214 576 298 217 576 minecraft:jungle_leaves[persistent=true]
fill 295 214 584 298 217 584 minecraft:jungle_leaves[persistent=true]
fill 296 214 575 298 217 575 minecraft:jungle_leaves[persistent=true]
fill 296 214 577 296 217 577 minecraft:jungle_leaves[persistent=true]
fill 296 214 583 296 217 583 minecraft:jungle_leaves[persistent=true]
fill 296 214 585 298 217 585 minecraft:jungle_leaves[persistent=true]
fill 297 214 599 297 216 599 minecraft:magenta_stained_glass
fill 299 214 574 299 217 574 minecraft:jungle_leaves[persistent=true]
fill 299 214 586 299 217 586 minecraft:jungle_leaves[persistent=true]
fill 309 214 557 309 220 557 minecraft:magenta_stained_glass
setblock 282 215 569 minecraft:white_concrete
setblock 282 215 575 minecraft:sea_lantern
setblock 282 215 596 minecraft:light_blue_stained_glass
fill 293 215 577 293 216 579 minecraft:jungle_leaves[persistent=true]
fill 293 215 581 293 216 583 minecraft:jungle_leaves[persistent=true]
fill 294 215 576 294 216 576 minecraft:jungle_leaves[persistent=true]
fill 294 215 584 294 216 584 minecraft:jungle_leaves[persistent=true]
fill 295 215 575 295 216 575 minecraft:jungle_leaves[persistent=true]
fill 295 215 585 295 216 585 minecraft:jungle_leaves[persistent=true]
fill 296 215 574 298 216 574 minecraft:jungle_leaves[persistent=true]
fill 296 215 586 298 216 586 minecraft:jungle_leaves[persistent=true]
setblock 300 215 557 minecraft:light_blue_stained_glass
fill 300 215 574 302 216 574 minecraft:jungle_leaves[persistent=true]
fill 300 215 586 302 216 586 minecraft:jungle_leaves[persistent=true]
fill 303 215 575 303 216 576 minecraft:jungle_leaves[persistent=true]
fill 303 215 584 303 216 585 minecraft:jungle_leaves[persistent=true]
fill 304 215 576 304 216 576 minecraft:jungle_leaves[persistent=true]
fill 304 215 584 304 216 584 minecraft:jungle_leaves[persistent=true]
setblock 324 215 596 minecraft:light_blue_stained_glass
fill 282 216 569 282 218 569 minecraft:magenta_stained_glass
fill 282 216 575 282 217 575 minecraft:magenta_stained_glass
setblock 282 216 595 minecraft:light_blue_stained_glass
fill 282 216 596 282 217 596 minecraft:magenta_stained_glass
setblock 286 216 599 minecraft:white_concrete
fill 300 216 557 300 220 557 minecraft:magenta_stained_glass
fill 319 216 587 320 217 588 minecraft:amethyst_block
fill 324 216 596 324 220 596 minecraft:magenta_stained_glass
fill 282 217 563 282 218 563 minecraft:purple_stained_glass
setblock 282 217 571 minecraft:purple_stained_glass
setblock 282 217 574 minecraft:purple_stained_glass
setblock 282 217 595 minecraft:magenta_stained_glass
setblock 285 217 560 minecraft:light[level=14]
setblock 285 217 568 minecraft:light[level=14]
setblock 285 217 576 minecraft:light[level=14]
setblock 285 217 584 minecraft:light[level=14]
setblock 285 217 592 minecraft:light[level=14]
setblock 286 217 599 minecraft:magenta_stained_glass
setblock 287 217 599 minecraft:purple_stained_glass
setblock 291 217 599 minecraft:white_concrete
setblock 293 217 560 minecraft:light[level=14]
setblock 293 217 568 minecraft:light[level=14]
setblock 293 217 576 minecraft:light[level=14]
setblock 293 217 584 minecraft:light[level=14]
setblock 293 217 592 minecraft:light[level=14]
setblock 294 217 557 minecraft:purple_stained_glass
fill 297 217 597 297 222 597 minecraft:light_blue_stained_glass
setblock 297 217 599 minecraft:light_blue_stained_glass
setblock 301 217 560 minecraft:light[level=14]
setblock 301 217 568 minecraft:light[level=14]
setblock 301 217 592 minecraft:light[level=14]
fill 302 217 577 304 217 578 minecraft:jungle_leaves[persistent=true]
fill 302 217 582 304 217 583 minecraft:jungle_leaves[persistent=true]
setblock 302 217 599 minecraft:purple_stained_glass
setblock 303 217 576 minecraft:jungle_leaves[persistent=true]
setblock 303 217 584 minecraft:jungle_leaves[persistent=true]
setblock 305 217 557 minecraft:white_concrete
setblock 309 217 560 minecraft:light[level=14]
setblock 309 217 568 minecraft:light[level=14]
setblock 309 217 576 minecraft:light[level=14]
setblock 309 217 584 minecraft:light[level=14]
setblock 309 217 592 minecraft:light[level=14]
setblock 316 217 599 minecraft:purple_stained_glass
setblock 317 217 560 minecraft:light[level=14]
setblock 317 217 568 minecraft:light[level=14]
setblock 317 217 576 minecraft:light[level=14]
setblock 317 217 584 minecraft:light[level=14]
setblock 317 217 592 minecraft:light[level=14]
setblock 318 217 599 minecraft:purple_stained_glass
fill 320 217 557 320 218 557 minecraft:purple_stained_glass
setblock 322 217 557 minecraft:purple_stained_glass
setblock 324 217 560 minecraft:purple_stained_glass
fill 324 217 563 324 217 564 minecraft:purple_stained_glass
fill 324 217 575 324 217 576 minecraft:purple_stained_glass
setblock 324 217 584 minecraft:white_concrete
setblock 324 217 590 minecraft:purple_stained_glass
fill 324 217 599 324 218 599 minecraft:purple_stained_glass
setblock 282 218 571 minecraft:magenta_stained_glass
fill 282 218 574 282 220 574 minecraft:magenta_stained_glass
setblock 282 218 575 minecraft:purple_stained_glass
setblock 282 218 578 minecraft:white_concrete
setblock 282 218 579 minecraft:purple_stained_glass
fill 282 218 585 282 219 585 minecraft:purple_stained_glass
fill 282 218 595 282 218 596 minecraft:purple_stained_glass
setblock 282 218 598 minecraft:light_blue_stained_glass
setblock 283 218 557 minecraft:purple_stained_glass
setblock 283 218 599 minecraft:purple_stained_glass
setblock 286 218 599 minecraft:purple_stained_glass
fill 287 218 599 287 220 599 minecraft:magenta_stained_glass
fill 291 218 599 291 220 599 minecraft:magenta_stained_glass
setblock 294 218 557 minecraft:magenta_stained_glass
setblock 295 218 557 minecraft:purple_stained_glass
fill 295 218 597 296 221 597 minecraft:light_blue_stained_glass
fill 296 218 595 298 221 596 minecraft:light_blue_stained_glass
fill 296 218 598 298 221 598 minecraft:light_blue_stained_glass
setblock 297 218 599 minecraft:magenta_stained_glass
setblock 298 218 557 minecraft:purple_stained_glass
fill 298 218 597 299 221 597 minecraft:light_blue_stained_glass
fill 301 218 577 301 218 579 minecraft:jungle_leaves[persistent=true]
fill 301 218 581 301 218 583 minecraft:jungle_leaves[persistent=true]
fill 302 218 578 302 218 579 minecraft:jungle_leaves[persistent=true]
fill 302 218 581 302 218 582 minecraft:jungle_leaves[persistent=true]
fill 302 218 599 302 220 599 minecraft:magenta_stained_glass
setblock 303 218 557 minecraft:purple_stained_glass
fill 305 218 557 305 220 557 minecraft:magenta_stained_glass
setblock 307 218 557 minecraft:purple_stained_glass
setblock 307 218 599 minecraft:purple_stained_glass
setblock 315 218 599 minecraft:purple_stained_glass
fill 316 218 599 316 220 599 minecraft:magenta_stained_glass
fill 318 218 599 318 220 599 minecraft:magenta_stained_glass
setblock 322 218 557 minecraft:magenta_stained_glass
fill 324 218 560 324 220 560 minecraft:magenta_stained_glass
setblock 324 218 562 minecraft:purple_stained_glass
fill 324 218 563 324 218 564 minecraft:magenta_stained_glass
setblock 324 218 571 minecraft:purple_stained_glass
fill 324 218 575 324 219 576 minecraft:magenta_stained_glass
setblock 324 218 584 minecraft:purple_stained_glass
fill 324 218 590 324 220 590 minecraft:magenta_stained_glass
fill 324 218 592 324 218 593 minecraft:purple_stained_glass
setblock 282 219 560 minecraft:purple_stained_glass
fill 282 219 563 282 220 563 minecraft:magenta_stained_glass
setblock 282 219 569 minecraft:purple_stained_glass
setblock 282 219 571 minecraft:light_blue_stained_glass
fill 282 219 575 282 220 575 minecraft:magenta_stained_glass
fill 282 219 578 282 220 579 minecraft:magenta_stained_glass
setblock 282 219 583 minecraft:purple_stained_glass
setblock 282 219 590 minecraft:purple_stained_glass
fill 282 219 595 282 220 596 minecraft:magenta_stained_glass
fill 282 219 598 282 220 598 minecraft:magenta_stained_glass
setblock 282 219 599 minecraft:purple_stained_glass
fill 283 219 557 283 220 557 minecraft:magenta_stained_glass
fill 283 219 576 283 224 578 minecraft:light_blue_stained_glass
fill 283 219 599 283 220 599 minecraft:magenta_stained_glass
fill 284 219 577 284 224 577 minecraft:light_blue_stained_glass
fill 286 219 599 286 220 599 minecraft:magenta_stained_glass
setblock 290 219 557 minecraft:purple_stained_glass
setblock 294 219 557 minecraft:purple_stained_glass
fill 295 219 557 295 220 557 minecraft:magenta_stained_glass
fill 295 219 596 295 220 596 minecraft:light_blue_stained_glass
fill 295 219 598 295 220 598 minecraft:light_blue_stained_glass
fill 296 219 594 298 221 594 minecraft:light_blue_stained_glass
fill 297 219 593 297 221 593 minecraft:light_blue_stained_glass
setblock 297 219 599 minecraft:purple_stained_glass
fill 298 219 557 298 220 557 minecraft:magenta_stained_glass
fill 299 219 596 299 220 596 minecraft:light_blue_stained_glass
fill 299 219 598 299 220 598 minecraft:light_blue_stained_glass
setblock 299 219 599 minecraft:purple_stained_glass
setblock 300 219 599 minecraft:light_blue_stained_glass
fill 302 219 563 302 220 563 minecraft:amethyst_block
fill 303 219 557 303 220 557 minecraft:magenta_stained_glass
fill 307 219 557 307 220 557 minecraft:magenta_stained_glass
fill 307 219 599 307 220 599 minecraft:magenta_stained_glass
setblock 313 219 557 minecraft:purple_stained_glass
fill 315 219 599 315 220 599 minecraft:magenta_stained_glass
setblock 317 219 599 minecraft:sea_lantern
setblock 319 219 557 minecraft:purple_stained_glass
fill 320 219 557 320 220 557 minecraft:magenta_stained_glass
setblock 322 219 557 minecraft:purple_stained_glass
fill 324 219 562 324 220 563 minecraft:magenta_stained_glass
setblock 324 219 564 minecraft:purple_stained_glass
setblock 324 219 571 minecraft:magenta_stained_glass
fill 324 219 578 324 219 579 minecraft:purple_stained_glass
setblock 324 219 582 minecraft:purple_stained_glass
fill 324 219 584 324 220 584 minecraft:magenta_stained_glass
setblock 324 219 588 minecraft:purple_stained_glass
fill 324 219 592 324 220 592 minecraft:magenta_stained_glass
setblock 324 219 593 minecraft:purple_stained_glass
setblock 324 219 594 minecraft:sea_lantern
fill 324 219 599 324 220 599 minecraft:magenta_stained_glass
setblock 282 220 560 minecraft:magenta_stained_glass
setblock 282 220 569 minecraft:magenta_stained_glass
fill 282 220 571 282 221 571 minecraft:magenta_stained_glass
setblock 282 220 583 minecraft:magenta_stained_glass
setblock 282 220 585 minecraft:magenta_stained_glass
setblock 282 220 590 minecraft:magenta_stained_glass
setblock 282 220 599 minecraft:magenta_stained_glass
fill 283 220 575 284 223 575 minecraft:light_blue_stained_glass
fill 283 220 579 284 223 579 minecraft:light_blue_stained_glass
fill 284 220 576 286 222 576 minecraft:light_blue_stained_glass
fill 284 220 578 286 222 578 minecraft:light_blue_stained_glass
fill 285 220 577 288 221 577 minecraft:light_blue_stained_glass
setblock 290 220 557 minecraft:magenta_stained_glass
setblock 294 220 557 minecraft:magenta_stained_glass
setblock 295 220 595 minecraft:light_blue_stained_glass
setblock 296 220 593 minecraft:light_blue_stained_glass
setblock 297 220 592 minecraft:light_blue_stained_glass
setblock 297 220 599 minecraft:magenta_stained_glass
setblock 298 220 593 minecraft:light_blue_stained_glass
setblock 299 220 595 minecraft:light_blue_stained_glass
fill 299 220 599 300 220 599 minecraft:magenta_stained_glass
setblock 313 220 557 minecraft:magenta_stained_glass
setblock 317 220 599 minecraft:magenta_stained_glass
fill 319 220 557 319 221 557 minecraft:magenta_stained_glass
setblock 322 220 557 minecraft:magenta_stained_glass
setblock 324 220 564 minecraft:light_blue_stained_glass
setblock 324 220 571 minecraft:white_concrete
setblock 324 220 575 minecraft:light_blue_stained_glass
setblock 324 220 576 minecraft:magenta_stained_glass
fill 324 220 578 324 220 579 minecraft:magenta_stained_glass
setblock 324 220 582 minecraft:magenta_stained_glass
setblock 324 220 588 minecraft:magenta_stained_glass
fill 324 220 593 324 220 594 minecraft:magenta_stained_glass
fill 282 221 558 282 222 561 minecraft:purple_stained_glass
setblock 282 221 562 minecraft:white_concrete
fill 282 221 563 282 222 570 minecraft:purple_stained_glass
fill 282 221 572 282 222 575 minecraft:purple_stained_glass
fill 282 221 577 282 221 587 minecraft:purple_stained_glass
fill 282 221 589 282 221 599 minecraft:purple_stained_glass
fill 283 221 557 296 221 557 minecraft:purple_stained_glass
fill 283 221 599 284 239 599 minecraft:purple_stained_glass
setblock 285 221 575 minecraft:light_blue_stained_glass
setblock 285 221 579 minecraft:light_blue_stained_glass
setblock 285 221 599 minecraft:light_blue_stained_glass
fill 286 221 599 294 221 599 minecraft:purple_stained_glass
setblock 287 221 576 minecraft:light_blue_stained_glass
setblock 287 221 578 minecraft:light_blue_stained_glass
setblock 295 221 599 minecraft:white_concrete
fill 296 221 599 303 222 599 minecraft:purple_stained_glass
fill 298 221 557 300 239 557 minecraft:purple_stained_glass
setblock 301 221 557 minecraft:white_concrete
fill 302 221 557 303 221 557 minecraft:purple_stained_glass
fill 305 221 557 314 221 557 minecraft:purple_stained_glass
fill 305 221 599 324 221 599 minecraft:purple_stained_glass
fill 316 221 557 318 223 557 minecraft:purple_stained_glass
fill 320 221 557 322 222 557 minecraft:purple_stained_glass
fill 324 221 557 324 307 557 minecraft:purple_stained_glass
fill 324 221 559 324 221 573 minecraft:purple_stained_glass
fill 324 221 575 324 227 576 minecraft:purple_stained_glass
setblock 324 221 577 minecraft:light_blue_stained_glass
fill 324 221 578 324 221 586 minecraft:purple_stained_glass
setblock 324 221 587 minecraft:white_concrete
fill 324 221 588 324 221 592 minecraft:purple_stained_glass
setblock 324 221 593 minecraft:magenta_stained_glass
fill 324 221 594 324 241 596 minecraft:purple_stained_glass
fill 324 221 598 324 273 598 minecraft:purple_stained_glass
fill 282 222 557 288 224 557 minecraft:purple_stained_glass
fill 282 222 562 282 239 562 minecraft:purple_stained_glass
fill 282 222 571 282 247 571 minecraft:purple_stained_glass
fill 282 222 576 282 224 582 minecraft:purple_stained_glass
setblock 282 222 583 minecraft:magenta_stained_glass
fill 282 222 584 282 235 587 minecraft:purple_stained_glass
fill 282 222 589 282 222 595 minecraft:purple_stained_glass
setblock 282 222 596 minecraft:magenta_stained_glass
fill 282 222 597 282 222 599 minecraft:purple_stained_glass
fill 285 222 577 286 222 577 minecraft:light_blue_stained_glass
fill 285 222 599 285 276 599 minecraft:purple_stained_glass
setblock 286 222 599 minecraft:magenta_stained_glass
fill 287 222 599 293 238 599 minecraft:purple_stained_glass
setblock 289 222 557 minecraft:magenta_stained_glass
fill 290 222 557 297 227 557 minecraft:purple_stained_glass
setblock 294 222 599 minecraft:light_blue_stained_glass
fill 295 222 599 295 307 599 minecraft:purple_stained_glass
fill 301 222 557 302 222 557 minecraft:purple_stained_glass
setblock 303 222 557 minecraft:magenta_stained_glass
fill 304 222 557 304 270 557 minecraft:purple_stained_glass
setblock 304 222 599 minecraft:purple_stained_glass
setblock 305 222 557 minecraft:magenta_stained_glass
setblock 305 222 599 minecraft:magenta_stained_glass
fill 306 222 557 310 238 557 minecraft:purple_stained_glass
fill 306 222 599 307 249 599 minecraft:purple_stained_glass
setblock 308 222 599 minecraft:magenta_stained_glass
fill 309 222 599 324 222 599 minecraft:purple_stained_glass
setblock 311 222 557 minecraft:magenta_stained_glass
fill 312 222 557 315 223 557 minecraft:purple_stained_glass
fill 319 222 557 319 307 557 minecraft:purple_stained_glass
fill 323 222 557 323 230 557 minecraft:purple_stained_glass
fill 324 222 558 324 222 563 minecraft:purple_stained_glass
setblock 324 222 564 minecraft:magenta_stained_glass
fill 324 222 565 324 222 570 minecraft:purple_stained_glass
setblock 324 222 571 minecraft:magenta_stained_glass
fill 324 222 572 324 225 574 minecraft:purple_stained_glass
fill 324 222 577 324 223 580 minecraft:purple_stained_glass
fill 324 222 581 324 222 582 minecraft:magenta_stained_glass
fill 324 222 583 324 222 591 minecraft:purple_stained_glass
setblock 324 222 592 minecraft:magenta_stained_glass
fill 324 222 593 324 232 593 minecraft:purple_stained_glass
fill 324 222 597 324 282 597 minecraft:purple_stained_glass
fill 282 223 558 282 244 559 minecraft:purple_stained_glass
setblock 282 223 560 minecraft:magenta_stained_glass
fill 282 223 561 282 280 561 minecraft:purple_stained_glass
fill 282 223 563 282 224 566 minecraft:purple_stained_glass
setblock 282 223 567 minecraft:magenta_stained_glass
fill 282 223 568 282 225 570 minecraft:purple_stained_glass
fill 282 223 572 282 240 572 minecraft:purple_stained_glass
fill 282 223 573 282 223 574 minecraft:magenta_stained_glass
fill 282 223 575 282 260 575 minecraft:purple_stained_glass
fill 282 223 583 282 307 583 minecraft:purple_stained_glass
fill 282 223 589 282 231 591 minecraft:purple_stained_glass
setblock 282 223 592 minecraft:magenta_stained_glass
fill 282 223 593 282 224 597 minecraft:purple_stained_glass
setblock 282 223 598 minecraft:magenta_stained_glass
fill 282 223 599 282 307 599 minecraft:purple_stained_glass
fill 284 223 576 285 223 576 minecraft:light_blue_stained_glass
fill 284 223 578 285 223 578 minecraft:light_blue_stained_glass
setblock 285 223 577 minecraft:light_blue_stained_glass
fill 286 223 599 286 307 599 minecraft:purple_stained_glass
fill 289 223 557 289 271 557 minecraft:purple_stained_glass
fill 294 223 599 294 272 599 minecraft:purple_stained_glass
fill 296 223 599 301 224 599 minecraft:purple_stained_glass
fill 301 223 557 301 232 557 minecraft:purple_stained_glass
setblock 302 223 557 minecraft:magenta_stained_glass
setblock 302 223 599 minecraft:magenta_stained_glass
fill 303 223 557 303 234 557 minecraft:purple_stained_glass
fill 303 223 599 303 267 599 minecraft:purple_stained_glass
setblock 304 223 599 minecraft:magenta_stained_glass
fill 305 223 557 305 297 557 minecraft:purple_stained_glass
fill 305 223 599 305 224 599 minecraft:purple_stained_glass
fill 308 223 599 313 224 599 minecraft:purple_stained_glass
fill 311 223 557 311 289 557 minecraft:purple_stained_glass
fill 314 223 599 315 223 599 minecraft:magenta_stained_glass
fill 316 223 599 324 242 599 minecraft:purple_stained_glass
setblock 320 223 557 minecraft:magenta_stained_glass
fill 321 223 557 321 307 557 minecraft:purple_stained_glass
setblock 322 223 557 minecraft:magenta_stained_glass
fill 324 223 558 324 262 560 minecraft:purple_stained_glass
setblock 324 223 561 minecraft:magenta_stained_glass
fill 324 223 562 324 245 565 minecraft:purple_stained_glass
fill 324 223 566 324 223 567 minecraft:magenta_stained_glass
fill 324 223 568 324 226 571 minecraft:purple_stained_glass
fill 324 223 581 324 307 581 minecraft:purple_stained_glass
setblock 324 223 582 minecraft:magenta_stained_glass
fill 324 223 583 324 224 583 minecraft:purple_stained_glass
setblock 324 223 584 minecraft:magenta_stained_glass
fill 324 223 585 324 227 587 minecraft:purple_stained_glass
setblock 324 223 588 minecraft:magenta_stained_glass
fill 324 223 589 324 236 592 minecraft:purple_stained_glass
fill 282 224 560 282 290 560 minecraft:purple_stained_glass
fill 282 224 567 282 227 567 minecraft:purple_stained_glass
fill 282 224 573 282 232 574 minecraft:purple_stained_glass
fill 282 224 588 282 228 588 minecraft:purple_stained_glass
setblock 282 224 592 minecraft:white_concrete
fill 282 224 598 282 261 598 minecraft:purple_stained_glass
fill 283 224 574 283 229 574 minecraft:light_blue_stained_glass
setblock 302 224 557 minecraft:purple_stained_glass
fill 302 224 599 302 307 599 minecraft:purple_stained_glass
fill 304 224 599 304 285 599 minecraft:purple_stained_glass
setblock 312 224 557 minecraft:white_concrete
fill 313 224 557 317 225 557 minecraft:purple_stained_glass
fill 314 224 599 315 229 599 minecraft:purple_stained_glass
setblock 318 224 557 minecraft:white_concrete
fill 320 224 557 320 266 557 minecraft:purple_stained_glass
fill 322 224 557 322 233 557 minecraft:purple_stained_glass
fill 324 224 561 324 232 561 minecraft:purple_stained_glass
fill 324 224 566 324 224 567 minecraft:purple_stained_glass
fill 324 224 577 324 277 578 minecraft:purple_stained_glass
setblock 324 224 579 minecraft:white_concrete
setblock 324 224 580 minecraft:purple_stained_glass
fill 324 224 582 324 233 582 minecraft:purple_stained_glass
fill 324 224 584 324 260 584 minecraft:purple_stained_glass
fill 324 224 588 324 281 588 minecraft:purple_stained_glass
fill 282 225 557 285 229 557 minecraft:purple_stained_glass
fill 282 225 563 282 228 564 minecraft:purple_stained_glass
fill 282 225 565 282 227 565 minecraft:magenta_stained_glass
fill 282 225 566 282 250 566 minecraft:purple_stained_glass
fill 282 225 576 282 232 580 minecraft:purple_stained_glass
fill 282 225 581 282 227 581 minecraft:magenta_stained_glass
fill 282 225 582 282 264 582 minecraft:purple_stained_glass
fill 282 225 592 282 228 596 minecraft:purple_stained_glass
fill 282 225 597 282 227 597 minecraft:magenta_stained_glass
fill 283 225 572 283 228 573 minecraft:light_blue_stained_glass
fill 283 225 575 283 228 576 minecraft:light_blue_stained_glass
fill 284 225 573 284 229 575 minecraft:light_blue_stained_glass
setblock 285 225 560 minecraft:light[level=14]
setblock 285 225 568 minecraft:light[level=14]
fill 285 225 574 285 229 574 minecraft:light_blue_stained_glass
setblock 285 225 576 minecraft:light[level=14]
setblock 285 225 584 minecraft:light[level=14]
setblock 285 225 592 minecraft:light[level=14]
fill 286 225 557 286 227 557 minecraft:magenta_stained_glass
fill 287 225 557 288 226 557 minecraft:purple_stained_glass
setblock 293 225 560 minecraft:light[level=14]
setblock 293 225 568 minecraft:light[level=14]
setblock 293 225 576 minecraft:light[level=14]
setblock 293 225 584 minecraft:light[level=14]
setblock 293 225 592 minecraft:light[level=14]
fill 296 225 599 296 227 599 minecraft:magenta_stained_glass
fill 297 225 599 301 231 599 minecraft:purple_stained_glass
setblock 301 225 560 minecraft:light[level=14]
setblock 301 225 568 minecraft:light[level=14]
setblock 301 225 576 minecraft:light[level=14]
setblock 301 225 584 minecraft:light[level=14]
setblock 301 225 592 minecraft:light[level=14]
fill 302 225 557 302 227 557 minecraft:magenta_stained_glass
setblock 305 225 599 minecraft:sea_lantern
fill 308 225 599 311 248 599 minecraft:purple_stained_glass
setblock 309 225 560 minecraft:light[level=14]
setblock 309 225 568 minecraft:light[level=14]
setblock 309 225 576 minecraft:light[level=14]
setblock 309 225 584 minecraft:light[level=14]
setblock 309 225 592 minecraft:light[level=14]
fill 312 225 557 312 307 557 minecraft:purple_stained_glass
fill 312 225 582 312 226 582 minecraft:amethyst_block
fill 312 225 599 312 227 599 minecraft:magenta_stained_glass
fill 313 225 599 313 250 599 minecraft:purple_stained_glass
setblock 317 225 560 minecraft:light[level=14]
setblock 317 225 568 minecraft:light[level=14]
setblock 317 225 576 minecraft:light[level=14]
setblock 317 225 584 minecraft:light[level=14]
setblock 317 225 592 minecraft:light[level=14]
fill 318 225 557 318 227 557 minecraft:magenta_stained_glass
fill 324 225 566 324 307 566 minecraft:purple_stained_glass
fill 324 225 567 324 227 567 minecraft:magenta_stained_glass
fill 324 225 579 324 241 579 minecraft:purple_stained_glass
setblock 324 225 580 minecraft:white_concrete
fill 324 225 583 324 227 583 minecraft:magenta_stained_glass
fill 282 226 568 282 226 569 minecraft:purple_stained_glass
setblock 282 226 570 minecraft:white_concrete
fill 284 226 572 284 227 572 minecraft:light_blue_stained_glass
fill 284 226 576 284 227 576 minecraft:light_blue_stained_glass
fill 285 226 573 285 229 573 minecraft:light_blue_stained_glass
fill 285 226 575 285 229 575 minecraft:light_blue_stained_glass
fill 286 226 574 286 229 574 minecraft:light_blue_stained_glass
fill 305 226 599 305 297 599 minecraft:purple_stained_glass
fill 313 226 557 313 233 557 minecraft:purple_stained_glass
setblock 314 226 557 minecraft:sea_lantern
fill 315 226 557 317 251 557 minecraft:purple_stained_glass
setblock 324 226 572 minecraft:sea_lantern
fill 324 226 573 324 229 574 minecraft:purple_stained_glass
fill 324 226 580 324 278 580 minecraft:purple_stained_glass
fill 282 227 568 282 259 568 minecraft:purple_stained_glass
setblock 282 227 569 minecraft:sea_lantern
fill 282 227 570 282 228 570 minecraft:purple_stained_glass
setblock 285 227 572 minecraft:light_blue_stained_glass
setblock 285 227 576 minecraft:light_blue_stained_glass
fill 286 227 573 286 229 573 minecraft:light_blue_stained_glass
fill 286 227 575 286 229 575 minecraft:light_blue_stained_glass
fill 287 227 557 287 247 557 minecraft:purple_stained_glass
fill 287 227 574 287 229 574 minecraft:light_blue_stained_glass
setblock 288 227 557 minecraft:sea_lantern
fill 314 227 557 314 232 557 minecraft:purple_stained_glass
setblock 324 227 568 minecraft:white_concrete
fill 324 227 569 324 236 572 minecraft:purple_stained_glass
fill 282 228 565 282 233 565 minecraft:purple_stained_glass
setblock 282 228 567 minecraft:white_concrete
fill 282 228 569 282 274 569 minecraft:purple_stained_glass
fill 282 228 581 282 233 581 minecraft:purple_stained_glass
fill 282 228 597 282 233 597 minecraft:purple_stained_glass
fill 286 228 557 286 233 557 minecraft:purple_stained_glass
fill 287 228 573 287 229 573 minecraft:light_blue_stained_glass
fill 287 228 575 287 229 575 minecraft:light_blue_stained_glass
fill 288 228 557 288 259 557 minecraft:purple_stained_glass
fill 288 228 574 288 230 574 minecraft:light_blue_stained_glass
fill 290 228 557 292 256 557 minecraft:purple_stained_glass
setblock 293 228 557 minecraft:white_concrete
fill 294 228 557 297 236 557 minecraft:purple_stained_glass
fill 296 228 599 296 233 599 minecraft:purple_stained_glass
fill 302 228 557 302 233 557 minecraft:purple_stained_glass
fill 312 228 599 312 230 599 minecraft:purple_stained_glass
fill 318 228 557 318 233 557 minecraft:purple_stained_glass
fill 324 228 567 324 233 568 minecraft:purple_stained_glass
setblock 324 228 575 minecraft:white_concrete
fill 324 228 576 324 242 576 minecraft:purple_stained_glass
fill 324 228 583 324 233 583 minecraft:purple_stained_glass
fill 324 228 585 324 234 586 minecraft:purple_stained_glass
setblock 324 228 587 minecraft:light_blue_stained_glass
setblock 282 229 563 minecraft:sea_lantern
fill 282 229 564 282 307 564 minecraft:purple_stained_glass
fill 282 229 567 282 307 567 minecraft:purple_stained_glass
setblock 282 229 570 minecraft:sea_lantern
setblock 282 229 588 minecraft:white_concrete
setblock 282 229 592 minecraft:white_concrete
fill 282 229 593 282 237 596 minecraft:purple_stained_glass
fill 285 229 570 289 229 570 minecraft:light_blue_stained_glass
setblock 288 229 573 minecraft:light_blue_stained_glass
setblock 288 229 575 minecraft:light_blue_stained_glass
fill 289 229 574 289 230 574 minecraft:light_blue_stained_glass
fill 293 229 557 293 307 557 minecraft:purple_stained_glass
fill 320 229 575 320 230 576 minecraft:amethyst_block
fill 324 229 575 324 246 575 minecraft:purple_stained_glass
fill 324 229 587 324 239 587 minecraft:purple_stained_glass
fill 282 230 557 283 292 557 minecraft:purple_stained_glass
fill 282 230 563 282 243 563 minecraft:purple_stained_glass
fill 282 230 570 282 304 570 minecraft:purple_stained_glass
fill 282 230 588 282 242 588 minecraft:purple_stained_glass
fill 282 230 592 282 258 592 minecraft:purple_stained_glass
fill 283 230 569 287 230 571 minecraft:light_blue_stained_glass
setblock 284 230 557 minecraft:sea_lantern
fill 285 230 557 285 276 557 minecraft:purple_stained_glass
setblock 288 230 570 minecraft:light_blue_stained_glass
setblock 290 230 574 minecraft:light_blue_stained_glass
setblock 314 230 599 minecraft:sea_lantern
fill 315 230 599 315 266 599 minecraft:purple_stained_glass
fill 324 230 573 324 259 573 minecraft:purple_stained_glass
setblock 324 230 574 minecraft:white_concrete
fill 283 231 568 283 232 572 minecraft:light_blue_stained_glass
setblock 284 231 557 minecraft:light_blue_stained_glass
fill 284 231 569 286 231 571 minecraft:light_blue_stained_glass
setblock 287 231 570 minecraft:light_blue_stained_glass
setblock 312 231 599 minecraft:light_blue_stained_glass
fill 314 231 599 314 278 599 minecraft:purple_stained_glass
setblock 323 231 557 minecraft:white_concrete
fill 324 231 574 324 241 574 minecraft:purple_stained_glass
setblock 282 232 589 minecraft:light_blue_stained_glass
fill 282 232 590 282 241 591 minecraft:purple_stained_glass
fill 284 232 557 284 278 557 minecraft:purple_stained_glass
fill 284 232 569 285 232 571 minecraft:light_blue_stained_glass
setblock 286 232 570 minecraft:light_blue_stained_glass
fill 297 232 599 300 248 599 minecraft:purple_stained_glass
setblock 301 232 599 minecraft:light_blue_stained_glass
fill 312 232 599 312 233 599 minecraft:purple_stained_glass
fill 323 232 557 323 268 557 minecraft:purple_stained_glass
fill 282 233 573 282 239 573 minecraft:purple_stained_glass
setblock 282 233 574 minecraft:white_concrete
fill 282 233 576 282 240 577 minecraft:purple_stained_glass
setblock 282 233 578 minecraft:sea_lantern
fill 282 233 579 282 243 580 minecraft:purple_stained_glass
fill 282 233 589 282 307 589 minecraft:purple_stained_glass
fill 283 233 569 284 233 571 minecraft:light_blue_stained_glass
setblock 285 233 560 minecraft:light[level=14]
setblock 285 233 568 minecraft:light[level=14]
setblock 285 233 576 minecraft:light[level=14]
setblock 285 233 584 minecraft:light[level=14]
setblock 285 233 592 minecraft:light[level=14]
setblock 293 233 560 minecraft:light[level=14]
setblock 293 233 568 minecraft:light[level=14]
setblock 293 233 576 minecraft:light[level=14]
setblock 293 233 584 minecraft:light[level=14]
setblock 293 233 592 minecraft:light[level=14]
setblock 301 233 557 minecraft:sea_lantern
setblock 301 233 560 minecraft:light[level=14]
setblock 301 233 568 minecraft:light[level=14]
setblock 301 233 576 minecraft:light[level=14]
setblock 301 233 584 minecraft:light[level=14]
setblock 301 233 592 minecraft:light[level=14]
fill 301 233 599 301 253 599 minecraft:purple_stained_glass
setblock 309 233 560 minecraft:light[level=14]
setblock 309 233 568 minecraft:light[level=14]
setblock 309 233 576 minecraft:light[level=14]
setblock 309 233 584 minecraft:light[level=14]
setblock 309 233 592 minecraft:light[level=14]
fill 311 233 597 313 236 597 minecraft:light_blue_stained_glass
fill 312 233 595 312 235 596 minecraft:light_blue_stained_glass
fill 312 233 598 312 236 598 minecraft:light_blue_stained_glass
setblock 314 233 557 minecraft:light_blue_stained_glass
setblock 317 233 560 minecraft:light[level=14]
setblock 317 233 568 minecraft:light[level=14]
setblock 317 233 576 minecraft:light[level=14]
setblock 317 233 584 minecraft:light[level=14]
setblock 317 233 592 minecraft:light[level=14]
setblock 324 233 561 minecraft:white_concrete
setblock 324 233 593 minecraft:light_blue_stained_glass
fill 282 234 565 282 236 565 minecraft:magenta_stained_glass
fill 282 234 574 282 271 574 minecraft:purple_stained_glass
fill 282 234 578 282 256 578 minecraft:purple_stained_glass
fill 282 234 581 282 236 581 minecraft:magenta_stained_glass
fill 282 234 597 282 236 597 minecraft:magenta_stained_glass
fill 286 234 557 286 236 557 minecraft:magenta_stained_glass
fill 296 234 599 296 236 599 minecraft:magenta_stained_glass
fill 301 234 557 301 285 557 minecraft:purple_stained_glass
fill 302 234 557 302 236 557 minecraft:magenta_stained_glass
fill 311 234 593 311 234 596 minecraft:light_blue_stained_glass
fill 311 234 598 311 235 598 minecraft:light_blue_stained_glass
fill 312 234 591 312 234 594 minecraft:light_blue_stained_glass
fill 312 234 599 312 236 599 minecraft:magenta_stained_glass
setblock 313 234 557 minecraft:sea_lantern
fill 313 234 593 313 234 596 minecraft:light_blue_stained_glass
fill 313 234 598 313 235 598 minecraft:light_blue_stained_glass
fill 314 234 557 314 251 557 minecraft:purple_stained_glass
fill 318 234 557 318 236 557 minecraft:magenta_stained_glass
setblock 322 234 557 minecraft:light_blue_stained_glass
fill 324 234 561 324 261 561 minecraft:purple_stained_glass
fill 324 234 567 324 236 567 minecraft:magenta_stained_glass
fill 324 234 568 324 307 568 minecraft:purple_stained_glass
setblock 324 234 582 minecraft:light_blue_stained_glass
fill 324 234 583 324 236 583 minecraft:magenta_stained_glass
fill 324 234 593 324 262 593 minecraft:purple_stained_glass
setblock 303 235 557 minecraft:white_concrete
fill 311 235 594 311 235 596 minecraft:light_blue_stained_glass
fill 312 235 592 312 235 594 minecraft:light_blue_stained_glass
fill 313 235 557 313 252 557 minecraft:purple_stained_glass
fill 313 235 594 313 235 596 minecraft:light_blue_stained_glass
fill 322 235 557 322 254 557 minecraft:purple_stained_glass
setblock 324 235 582 minecraft:purple_stained_glass
fill 324 235 585 324 287 585 minecraft:purple_stained_glass
setblock 324 235 586 minecraft:white_concrete
fill 282 236 584 282 253 586 minecraft:purple_stained_glass
setblock 282 236 587 minecraft:sea_lantern
fill 303 236 557 303 281 557 minecraft:purple_stained_glass
setblock 312 236 596 minecraft:light_blue_stained_glass
setblock 324 236 582 minecraft:white_concrete
fill 324 236 586 324 249 586 minecraft:purple_stained_glass
fill 282 237 565 282 251 565 minecraft:purple_stained_glass
fill 282 237 581 282 251 581 minecraft:purple_stained_glass
fill 282 237 587 282 240 587 minecraft:purple_stained_glass
fill 282 237 597 282 251 597 minecraft:purple_stained_glass
fill 286 237 557 286 251 557 minecraft:purple_stained_glass
fill 294 237 557 294 261 557 minecraft:purple_stained_glass
setblock 295 237 557 minecraft:sea_lantern
fill 296 237 557 297 307 557 minecraft:purple_stained_glass
fill 296 237 599 296 251 599 minecraft:purple_stained_glass
fill 302 237 557 302 251 557 minecraft:purple_stained_glass
fill 312 237 599 312 251 599 minecraft:purple_stained_glass
setblock 318 237 557 minecraft:white_concrete
fill 324 237 567 324 251 567 minecraft:purple_stained_glass
fill 324 237 569 324 255 571 minecraft:purple_stained_glass
setblock 324 237 572 minecraft:white_concrete
fill 324 237 582 324 251 583 minecraft:purple_stained_glass
fill 324 237 589 324 261 590 minecraft:purple_stained_glass
setblock 324 237 591 minecraft:white_concrete
fill 324 237 592 324 307 592 minecraft:purple_stained_glass
setblock 282 238 593 minecraft:sea_lantern
fill 282 238 594 282 240 596 minecraft:purple_stained_glass
fill 295 238 557 295 248 557 minecraft:purple_stained_glass
fill 318 238 557 318 251 557 minecraft:purple_stained_glass
fill 324 238 572 324 259 572 minecraft:purple_stained_glass
fill 324 238 591 324 307 591 minecraft:purple_stained_glass
fill 282 239 593 282 307 593 minecraft:purple_stained_glass
fill 287 239 599 287 252 599 minecraft:purple_stained_glass
setblock 288 239 599 minecraft:sea_lantern
fill 289 239 599 293 240 599 minecraft:purple_stained_glass
fill 306 239 557 309 244 557 minecraft:purple_stained_glass
setblock 310 239 557 minecraft:white_concrete
setblock 282 240 562 minecraft:white_concrete
setblock 282 240 573 minecraft:light_blue_stained_glass
setblock 283 240 599 minecraft:light_blue_stained_glass
fill 284 240 599 284 280 599 minecraft:purple_stained_glass
fill 288 240 599 288 292 599 minecraft:purple_stained_glass
fill 298 240 557 298 294 557 minecraft:purple_stained_glass
setblock 299 240 557 minecraft:white_concrete
fill 300 240 557 300 267 557 minecraft:purple_stained_glass
fill 310 240 557 310 252 557 minecraft:purple_stained_glass
setblock 324 240 587 minecraft:sea_lantern
fill 282 241 562 282 284 562 minecraft:purple_stained_glass
setblock 282 241 572 minecraft:light_blue_stained_glass
fill 282 241 573 282 288 573 minecraft:purple_stained_glass
fill 282 241 576 282 296 576 minecraft:purple_stained_glass
setblock 282 241 577 minecraft:light_blue_stained_glass
setblock 282 241 587 minecraft:sea_lantern
setblock 282 241 594 minecraft:light_blue_stained_glass
fill 282 241 595 282 246 596 minecraft:purple_stained_glass
fill 283 241 599 283 270 599 minecraft:purple_stained_glass
setblock 285 241 560 minecraft:light[level=14]
setblock 285 241 568 minecraft:light[level=14]
setblock 285 241 576 minecraft:light[level=14]
setblock 285 241 584 minecraft:light[level=14]
setblock 285 241 592 minecraft:light[level=14]
fill 289 241 599 292 257 599 minecraft:purple_stained_glass
setblock 293 241 560 minecraft:light[level=14]
setblock 293 241 568 minecraft:light[level=14]
setblock 293 241 576 minecraft:light[level=14]
setblock 293 241 584 minecraft:light[level=14]
setblock 293 241 592 minecraft:light[level=14]
setblock 293 241 599 minecraft:light_blue_stained_glass
fill 299 241 557 299 248 557 minecraft:purple_stained_glass
setblock 301 241 560 minecraft:light[level=14]
setblock 301 241 568 minecraft:light[level=14]
setblock 301 241 576 minecraft:light[level=14]
setblock 301 241 584 minecraft:light[level=14]
setblock 301 241 592 minecraft:light[level=14]
fill 303 241 575 305 241 577 minecraft:redstone_block
fill 304 241 582 306 241 584 minecraft:redstone_block
setblock 309 241 560 minecraft:light[level=14]
setblock 309 241 568 minecraft:light[level=14]
setblock 309 241 576 minecraft:light[level=14]
setblock 309 241 584 minecraft:light[level=14]
setblock 309 241 592 minecraft:light[level=14]
fill 312 241 578 314 241 580 minecraft:redstone_block
setblock 317 241 560 minecraft:light[level=14]
setblock 317 241 568 minecraft:light[level=14]
setblock 317 241 576 minecraft:light[level=14]
setblock 317 241 584 minecraft:light[level=14]
setblock 317 241 592 minecraft:light[level=14]
fill 324 241 587 324 307 587 minecraft:purple_stained_glass
fill 282 242 572 282 307 572 minecraft:purple_stained_glass
fill 282 242 577 282 250 577 minecraft:purple_stained_glass
fill 282 242 587 282 258 587 minecraft:purple_stained_glass
setblock 282 242 590 minecraft:white_concrete
fill 282 242 591 282 244 591 minecraft:purple_stained_glass
setblock 282 242 594 minecraft:purple_stained_glass
fill 292 242 579 295 243 579 minecraft:magenta_stained_glass
fill 293 242 574 293 243 577 minecraft:light_blue_stained_glass
fill 293 242 578 296 243 578 minecraft:magenta_stained_glass
fill 293 242 580 293 243 584 minecraft:magenta_stained_glass
fill 293 242 599 293 293 599 minecraft:purple_stained_glass
fill 294 242 572 294 243 576 minecraft:light_blue_stained_glass
fill 294 242 577 298 243 577 minecraft:magenta_stained_glass
fill 294 242 580 294 243 581 minecraft:magenta_stained_glass
fill 294 242 582 298 243 586 minecraft:light_blue_stained_glass
fill 295 242 570 295 243 575 minecraft:light_blue_stained_glass
fill 295 242 576 300 243 576 minecraft:magenta_stained_glass
fill 295 242 580 295 243 580 minecraft:magenta_stained_glass
fill 295 242 581 300 243 581 minecraft:light_blue_stained_glass
fill 295 242 587 298 243 588 minecraft:light_blue_stained_glass
fill 296 242 569 297 243 574 minecraft:light_blue_stained_glass
fill 296 242 575 302 242 575 minecraft:magenta_stained_glass
fill 296 242 579 301 243 580 minecraft:light_blue_stained_glass
fill 296 242 589 298 243 589 minecraft:light_blue_stained_glass
fill 297 242 568 307 243 568 minecraft:magenta_stained_glass
fill 297 242 578 306 242 578 minecraft:light_blue_stained_glass
fill 297 242 590 298 243 590 minecraft:light_blue_stained_glass
fill 298 242 567 306 243 567 minecraft:magenta_stained_glass
fill 298 242 569 303 243 573 minecraft:light_blue_stained_glass
fill 298 242 574 304 242 574 minecraft:magenta_stained_glass
fill 298 242 591 298 243 591 minecraft:light_blue_stained_glass
fill 299 242 566 304 243 566 minecraft:magenta_stained_glass
fill 299 242 577 302 242 577 minecraft:light_blue_stained_glass
fill 299 242 582 299 243 583 minecraft:light_blue_stained_glass
fill 299 242 584 301 243 591 minecraft:magenta_stained_glass
fill 299 242 592 299 243 592 minecraft:light_blue_stained_glass
fill 300 242 582 302 243 583 minecraft:magenta_stained_glass
fill 300 242 592 303 243 592 minecraft:magenta_stained_glass
fill 301 242 565 301 243 565 minecraft:magenta_stained_glass
fill 301 242 576 302 242 576 minecraft:light_blue_stained_glass
fill 301 242 581 303 242 581 minecraft:magenta_stained_glass
fill 301 242 593 303 243 593 minecraft:magenta_stained_glass
fill 302 242 565 312 243 565 minecraft:light_blue_stained_glass
fill 302 242 579 302 243 579 minecraft:light_blue_stained_glass
fill 302 242 580 304 243 580 minecraft:magenta_stained_glass
fill 302 242 584 303 242 589 minecraft:light_blue_stained_glass
fill 302 242 590 302 243 591 minecraft:magenta_stained_glass
fill 303 242 564 311 243 564 minecraft:light_blue_stained_glass
fill 303 242 579 306 242 579 minecraft:magenta_stained_glass
fill 303 242 582 303 242 583 minecraft:light_blue_stained_glass
fill 303 242 590 308 243 591 minecraft:light_blue_stained_glass
fill 303 242 594 304 243 594 minecraft:magenta_stained_glass
fill 304 242 569 308 243 569 minecraft:magenta_stained_glass
fill 304 242 570 305 243 573 minecraft:light_blue_stained_glass
fill 304 242 581 306 242 581 minecraft:light_blue_stained_glass
fill 304 242 585 305 242 589 minecraft:light_blue_stained_glass
fill 304 242 592 311 243 593 minecraft:light_blue_stained_glass
fill 305 242 566 312 243 566 minecraft:light_blue_stained_glass
fill 305 242 574 308 242 574 minecraft:light_blue_stained_glass
fill 305 242 580 306 242 580 minecraft:light_blue_stained_glass
fill 305 242 594 313 243 594 minecraft:light_blue_stained_glass
fill 306 242 570 309 243 570 minecraft:magenta_stained_glass
fill 306 242 571 306 243 573 minecraft:light_blue_stained_glass
fill 306 242 575 308 242 575 minecraft:light_blue_stained_glass
setblock 306 242 576 minecraft:magenta_stained_glass
setblock 306 242 577 minecraft:light_blue_stained_glass
fill 306 242 585 307 242 586 minecraft:magenta_stained_glass
fill 306 242 587 306 243 589 minecraft:light_blue_stained_glass
fill 307 242 567 313 243 567 minecraft:light_blue_stained_glass
fill 307 242 571 309 243 571 minecraft:magenta_stained_glass
fill 307 242 572 307 243 573 minecraft:light_blue_stained_glass
fill 307 242 576 308 243 576 minecraft:light_blue_stained_glass
setblock 307 242 577 minecraft:magenta_stained_glass
fill 307 242 581 307 242 584 minecraft:magenta_stained_glass
fill 307 242 587 309 243 588 minecraft:magenta_stained_glass
fill 307 242 589 307 243 589 minecraft:light_blue_stained_glass
fill 308 242 563 308 243 563 minecraft:light_blue_stained_glass
fill 308 242 568 313 243 568 minecraft:light_blue_stained_glass
fill 308 242 572 310 243 572 minecraft:magenta_stained_glass
fill 308 242 573 308 243 573 minecraft:light_blue_stained_glass
setblock 308 242 577 minecraft:light_blue_stained_glass
fill 308 242 581 308 242 585 minecraft:light_blue_stained_glass
fill 308 242 586 308 243 586 minecraft:magenta_stained_glass
fill 308 242 589 312 243 589 minecraft:magenta_stained_glass
fill 308 242 595 308 243 595 minecraft:light_blue_stained_glass
fill 309 242 569 314 243 569 minecraft:light_blue_stained_glass
fill 309 242 573 309 242 577 minecraft:magenta_stained_glass
setblock 309 242 581 minecraft:magenta_stained_glass
fill 309 242 582 309 243 586 minecraft:light_blue_stained_glass
fill 309 242 590 319 243 590 minecraft:magenta_stained_glass
fill 309 242 591 309 243 591 minecraft:light_blue_stained_glass
fill 310 242 570 314 243 571 minecraft:light_blue_stained_glass
fill 310 242 573 310 243 576 minecraft:magenta_stained_glass
fill 310 242 577 311 242 578 minecraft:light_blue_stained_glass
fill 310 242 579 311 242 579 minecraft:magenta_stained_glass
fill 310 242 580 311 242 581 minecraft:light_blue_stained_glass
fill 310 242 582 311 243 582 minecraft:magenta_stained_glass
fill 310 242 583 310 243 587 minecraft:light_blue_stained_glass
fill 310 242 588 310 243 588 minecraft:magenta_stained_glass
fill 310 242 591 318 243 591 minecraft:magenta_stained_glass
fill 311 242 572 313 243 576 minecraft:light_blue_stained_glass
fill 311 242 583 320 243 583 minecraft:magenta_stained_glass
fill 311 242 584 311 243 588 minecraft:light_blue_stained_glass
fill 312 242 564 313 243 564 minecraft:magenta_stained_glass
setblock 312 242 577 minecraft:light_blue_stained_glass
fill 312 242 581 315 242 582 minecraft:light_blue_stained_glass
fill 312 242 584 318 243 584 minecraft:magenta_stained_glass
fill 312 242 585 321 243 588 minecraft:light_blue_stained_glass
fill 312 242 592 317 243 592 minecraft:magenta_stained_glass
fill 312 242 593 314 243 593 minecraft:light_blue_stained_glass
fill 313 242 565 315 243 566 minecraft:magenta_stained_glass
fill 313 242 577 315 242 577 minecraft:magenta_stained_glass
fill 313 242 589 320 243 589 minecraft:light_blue_stained_glass
fill 314 242 567 317 243 568 minecraft:magenta_stained_glass
fill 314 242 572 314 243 574 minecraft:light_blue_stained_glass
fill 314 242 575 316 243 576 minecraft:magenta_stained_glass
fill 315 242 569 317 243 574 minecraft:magenta_stained_glass
fill 315 242 578 319 242 580 minecraft:light_blue_stained_glass
fill 315 242 593 315 243 593 minecraft:magenta_stained_glass
fill 316 242 566 316 243 566 minecraft:magenta_stained_glass
fill 316 242 577 321 243 577 minecraft:light_blue_stained_glass
fill 316 242 581 317 243 581 minecraft:light_blue_stained_glass
fill 316 242 582 321 243 582 minecraft:magenta_stained_glass
fill 317 242 566 317 243 566 minecraft:light_blue_stained_glass
fill 317 242 575 322 243 576 minecraft:light_blue_stained_glass
fill 318 242 567 318 243 574 minecraft:light_blue_stained_glass
fill 318 242 581 322 243 581 minecraft:magenta_stained_glass
fill 319 242 568 319 243 574 minecraft:light_blue_stained_glass
fill 319 242 584 323 243 584 minecraft:light_blue_stained_glass
fill 320 242 569 320 243 574 minecraft:light_blue_stained_glass
fill 320 242 578 320 243 579 minecraft:light_blue_stained_glass
fill 320 242 580 323 243 580 minecraft:magenta_stained_glass
fill 321 242 570 321 243 574 minecraft:light_blue_stained_glass
fill 321 242 578 323 243 579 minecraft:magenta_stained_glass
fill 321 242 583 323 243 583 minecraft:light_blue_stained_glass
fill 322 242 572 322 243 574 minecraft:light_blue_stained_glass
fill 322 242 577 323 243 577 minecraft:magenta_stained_glass
fill 322 242 582 323 243 582 minecraft:light_blue_stained_glass
fill 322 242 585 322 243 586 minecraft:light_blue_stained_glass
fill 323 242 574 323 243 576 minecraft:magenta_stained_glass
fill 323 242 581 323 243 581 minecraft:light_blue_stained_glass
setblock 324 242 574 minecraft:light_blue_stained_glass
fill 324 242 579 324 243 579 minecraft:magenta_stained_glass
fill 324 242 594 324 263 594 minecraft:purple_stained_glass
setblock 324 242 595 minecraft:light_blue_stained_glass
fill 324 242 596 324 256 596 minecraft:purple_stained_glass
setblock 282 243 588 minecraft:white_concrete
fill 282 243 590 296 243 590 minecraft:purple_stained_glass
setblock 282 243 594 minecraft:light_blue_stained_glass
fill 283 243 558 291 243 589 minecraft:purple_stained_glass
fill 283 243 591 297 243 598 minecraft:purple_stained_glass
fill 292 243 558 292 243 578 minecraft:purple_stained_glass
fill 292 243 580 292 243 589 minecraft:purple_stained_glass
fill 293 243 558 293 243 573 minecraft:purple_stained_glass
fill 293 243 585 293 243 589 minecraft:purple_stained_glass
fill 294 243 558 294 243 571 minecraft:purple_stained_glass
fill 294 243 587 294 243 589 minecraft:purple_stained_glass
fill 295 243 558 295 243 569 minecraft:purple_stained_glass
setblock 295 243 589 minecraft:purple_stained_glass
fill 296 243 558 296 243 568 minecraft:purple_stained_glass
fill 296 243 575 301 243 575 minecraft:magenta_stained_glass
fill 297 243 558 297 243 567 minecraft:purple_stained_glass
fill 297 243 578 301 243 578 minecraft:light_blue_stained_glass
fill 298 243 558 298 243 566 minecraft:purple_stained_glass
fill 298 243 574 301 243 574 minecraft:magenta_stained_glass
fill 298 243 592 298 243 598 minecraft:purple_stained_glass
fill 299 243 558 300 243 565 minecraft:purple_stained_glass
fill 299 243 577 301 243 577 minecraft:light_blue_stained_glass
fill 299 243 593 300 243 598 minecraft:purple_stained_glass
fill 301 243 558 302 243 564 minecraft:purple_stained_glass
setblock 301 243 576 minecraft:light_blue_stained_glass
fill 301 243 581 302 243 581 minecraft:magenta_stained_glass
fill 301 243 594 302 243 598 minecraft:purple_stained_glass
fill 302 243 574 302 243 578 minecraft:sea_lantern
fill 302 243 584 302 243 589 minecraft:light_blue_stained_glass
fill 303 243 558 307 243 563 minecraft:purple_stained_glass
fill 303 243 574 306 243 574 minecraft:sea_lantern
fill 303 243 575 305 243 577 minecraft:purple_stained_glass
fill 303 243 578 306 243 578 minecraft:sea_lantern
fill 303 243 579 305 243 579 minecraft:magenta_stained_glass
fill 303 243 581 303 243 585 minecraft:sea_lantern
fill 303 243 586 305 243 589 minecraft:light_blue_stained_glass
fill 303 243 595 307 243 598 minecraft:purple_stained_glass
fill 304 243 581 315 243 581 minecraft:sea_lantern
fill 304 243 582 306 243 584 minecraft:purple_stained_glass
fill 304 243 585 307 243 585 minecraft:sea_lantern
setblock 305 243 580 minecraft:light_blue_stained_glass
fill 306 243 575 306 243 577 minecraft:sea_lantern
fill 306 243 579 306 243 580 minecraft:sea_lantern
fill 306 243 586 307 243 586 minecraft:magenta_stained_glass
fill 307 243 574 308 243 575 minecraft:light_blue_stained_glass
fill 307 243 577 315 243 577 minecraft:sea_lantern
fill 307 243 582 307 243 584 minecraft:sea_lantern
fill 308 243 558 323 243 562 minecraft:purple_stained_glass
fill 308 243 582 308 243 585 minecraft:light_blue_stained_glass
fill 308 243 596 323 243 598 minecraft:purple_stained_glass
fill 309 243 563 323 243 563 minecraft:purple_stained_glass
fill 309 243 573 309 243 576 minecraft:magenta_stained_glass
fill 309 243 595 324 243 595 minecraft:purple_stained_glass
fill 310 243 578 311 243 580 minecraft:sea_lantern
fill 312 243 578 314 243 580 minecraft:purple_stained_glass
fill 312 243 582 315 243 582 minecraft:light_blue_stained_glass
fill 314 243 564 323 243 564 minecraft:purple_stained_glass
fill 314 243 594 323 243 594 minecraft:purple_stained_glass
fill 315 243 578 315 243 580 minecraft:sea_lantern
fill 316 243 565 323 243 565 minecraft:purple_stained_glass
fill 316 243 578 319 243 580 minecraft:light_blue_stained_glass
fill 316 243 593 323 243 593 minecraft:purple_stained_glass
fill 316 243 599 316 252 599 minecraft:purple_stained_glass
setblock 317 243 599 minecraft:sea_lantern
fill 318 243 566 323 243 566 minecraft:purple_stained_glass
fill 318 243 592 323 243 592 minecraft:purple_stained_glass
fill 318 243 599 324 244 599 minecraft:purple_stained_glass
fill 319 243 567 323 243 567 minecraft:purple_stained_glass
fill 319 243 591 323 243 591 minecraft:purple_stained_glass
fill 320 243 568 323 243 568 minecraft:purple_stained_glass
fill 320 243 590 323 243 590 minecraft:purple_stained_glass
fill 321 243 569 323 243 569 minecraft:purple_stained_glass
fill 321 243 589 323 243 589 minecraft:purple_stained_glass
fill 322 243 570 323 243 571 minecraft:purple_stained_glass
fill 322 243 587 323 243 588 minecraft:purple_stained_glass
fill 323 243 572 323 243 573 minecraft:purple_stained_glass
fill 323 243 585 323 243 586 minecraft:purple_stained_glass
fill 324 243 574 324 262 574 minecraft:purple_stained_glass
setblock 324 243 576 minecraft:light_blue_stained_glass
setblock 282 244 563 minecraft:light_blue_stained_glass
setblock 282 244 579 minecraft:white_concrete
fill 282 244 580 282 269 580 minecraft:purple_stained_glass
fill 282 244 588 282 275 588 minecraft:purple_stained_glass
fill 282 244 590 282 295 590 minecraft:purple_stained_glass
fill 282 244 594 282 262 594 minecraft:purple_stained_glass
fill 317 244 599 317 265 599 minecraft:purple_stained_glass
fill 324 244 576 324 269 576 minecraft:purple_stained_glass
fill 324 244 579 324 307 579 minecraft:purple_stained_glass
fill 324 244 595 324 263 595 minecraft:purple_stained_glass
fill 282 245 558 282 252 558 minecraft:purple_stained_glass
setblock 282 245 559 minecraft:sea_lantern
fill 282 245 563 282 307 563 minecraft:purple_stained_glass
fill 282 245 579 282 249 579 minecraft:purple_stained_glass
setblock 282 245 591 minecraft:white_concrete
fill 306 245 557 307 252 557 minecraft:purple_stained_glass
setblock 308 245 557 minecraft:white_concrete
fill 309 245 557 309 307 557 minecraft:purple_stained_glass
setblock 318 245 599 minecraft:white_concrete
fill 319 245 599 324 249 599 minecraft:purple_stained_glass
fill 282 246 559 282 307 559 minecraft:purple_stained_glass
fill 282 246 591 282 307 591 minecraft:purple_stained_glass
fill 308 246 557 308 307 557 minecraft:purple_stained_glass
fill 318 246 599 318 251 599 minecraft:purple_stained_glass
fill 324 246 562 324 246 564 minecraft:purple_stained_glass
setblock 324 246 565 minecraft:light_blue_stained_glass
setblock 282 247 595 minecraft:white_concrete
fill 282 247 596 282 307 596 minecraft:purple_stained_glass
fill 297 247 576 297 250 582 minecraft:iron_block
fill 298 247 574 298 250 575 minecraft:iron_block
fill 298 247 583 298 250 584 minecraft:iron_block
fill 299 247 572 299 250 573 minecraft:iron_block
fill 299 247 585 299 250 586 minecraft:iron_block
fill 300 247 571 300 247 572 minecraft:iron_block
fill 300 247 586 300 247 587 minecraft:iron_block
fill 301 247 570 301 250 571 minecraft:iron_block
fill 301 247 587 301 250 588 minecraft:iron_block
fill 302 247 570 302 250 570 minecraft:iron_block
fill 302 247 588 302 250 588 minecraft:iron_block
fill 303 247 569 304 250 569 minecraft:iron_block
fill 303 247 589 304 250 589 minecraft:iron_block
fill 305 247 568 311 250 568 minecraft:iron_block
fill 305 247 590 311 250 590 minecraft:iron_block
fill 312 247 569 313 250 569 minecraft:iron_block
fill 312 247 589 313 250 589 minecraft:iron_block
fill 314 247 570 315 250 570 minecraft:iron_block
fill 314 247 588 315 250 588 minecraft:iron_block
fill 315 247 571 316 247 571 minecraft:iron_block
fill 315 247 583 316 247 585 minecraft:amethyst_block
fill 315 247 587 316 247 587 minecraft:iron_block
fill 316 247 572 317 250 572 minecraft:iron_block
fill 316 247 586 317 250 586 minecraft:iron_block
fill 317 247 573 317 250 573 minecraft:iron_block
fill 317 247 583 317 247 584 minecraft:amethyst_block
fill 317 247 585 317 250 585 minecraft:iron_block
fill 318 247 574 318 250 575 minecraft:iron_block
fill 318 247 583 318 250 584 minecraft:iron_block
fill 318 247 585 318 247 586 minecraft:amethyst_block
fill 319 247 576 319 250 582 minecraft:iron_block
fill 324 247 562 324 307 562 minecraft:purple_stained_glass
setblock 324 247 563 minecraft:light_blue_stained_glass
fill 324 247 564 324 269 565 minecraft:purple_stained_glass
setblock 324 247 575 minecraft:light_blue_stained_glass
setblock 282 248 571 minecraft:light_blue_stained_glass
fill 282 248 595 282 254 595 minecraft:purple_stained_glass
setblock 287 248 557 minecraft:white_concrete
fill 296 248 576 296 248 582 minecraft:iron_block
fill 297 248 574 297 249 575 minecraft:iron_block
fill 297 248 583 297 249 584 minecraft:iron_block
fill 298 248 572 298 249 573 minecraft:iron_block
fill 298 248 576 298 249 582 minecraft:iron_block
fill 298 248 585 298 249 586 minecraft:iron_block
fill 299 248 571 299 249 571 minecraft:iron_block
fill 299 248 574 299 249 576 minecraft:iron_block
fill 299 248 582 299 249 584 minecraft:iron_block
fill 299 248 587 299 249 587 minecraft:iron_block
fill 300 248 570 300 249 570 minecraft:iron_block
fill 300 248 571 300 249 571 minecraft:light_gray_concrete
fill 300 248 572 300 249 573 minecraft:iron_block
fill 300 248 585 300 249 586 minecraft:iron_block
fill 300 248 587 300 249 587 minecraft:light_gray_concrete
fill 300 248 588 300 249 588 minecraft:iron_block
fill 301 248 569 302 249 569 minecraft:iron_block
fill 301 248 572 301 249 572 minecraft:light_gray_concrete
fill 301 248 586 301 249 586 minecraft:light_gray_concrete
fill 301 248 589 302 249 589 minecraft:iron_block
fill 302 248 571 302 249 571 minecraft:iron_block
fill 302 248 573 302 249 573 minecraft:light_gray_concrete
fill 302 248 585 302 249 585 minecraft:light_gray_concrete
fill 302 248 587 302 249 587 minecraft:iron_block
fill 303 248 568 304 249 568 minecraft:iron_block
fill 303 248 570 305 249 570 minecraft:iron_block
fill 303 248 574 303 249 574 minecraft:light_gray_concrete
fill 303 248 584 303 249 584 minecraft:light_gray_concrete
fill 303 248 588 305 249 588 minecraft:iron_block
fill 303 248 590 304 249 590 minecraft:iron_block
fill 304 248 575 304 249 575 minecraft:light_gray_concrete
fill 304 248 578 305 249 580 minecraft:white_concrete
fill 304 248 583 304 249 583 minecraft:light_gray_concrete
fill 305 248 567 311 249 567 minecraft:iron_block
fill 305 248 569 311 249 569 minecraft:iron_block
fill 305 248 576 305 249 576 minecraft:light_gray_concrete
fill 305 248 577 305 249 577 minecraft:white_concrete
fill 305 248 581 305 249 581 minecraft:white_concrete
fill 305 248 582 305 249 582 minecraft:light_gray_concrete
fill 305 248 589 311 249 589 minecraft:iron_block
fill 305 248 591 311 249 591 minecraft:iron_block
fill 306 248 576 310 249 576 minecraft:white_concrete
fill 306 248 582 310 249 582 minecraft:white_concrete
fill 307 248 575 309 249 575 minecraft:white_concrete
fill 307 248 583 309 249 583 minecraft:white_concrete
fill 311 248 570 313 249 570 minecraft:iron_block
fill 311 248 576 311 249 576 minecraft:light_gray_concrete
fill 311 248 577 311 249 581 minecraft:white_concrete
fill 311 248 582 311 249 582 minecraft:light_gray_concrete
fill 311 248 588 313 249 588 minecraft:iron_block
fill 312 248 568 313 249 568 minecraft:iron_block
fill 312 248 575 312 249 575 minecraft:light_gray_concrete
fill 312 248 578 312 249 580 minecraft:white_concrete
fill 312 248 583 312 249 583 minecraft:light_gray_concrete
fill 312 248 590 313 249 590 minecraft:iron_block
fill 313 248 574 313 249 574 minecraft:light_gray_concrete
fill 313 248 584 313 249 584 minecraft:light_gray_concrete
fill 314 248 569 315 249 569 minecraft:iron_block
fill 314 248 571 315 249 571 minecraft:iron_block
fill 314 248 573 314 249 573 minecraft:light_gray_concrete
fill 314 248 585 314 249 585 minecraft:light_gray_concrete
fill 314 248 587 315 249 587 minecraft:iron_block
fill 314 248 589 315 249 589 minecraft:iron_block
fill 315 248 572 315 249 572 minecraft:light_gray_concrete
fill 315 248 583 315 251 585 minecraft:amethyst_block
fill 315 248 586 315 249 586 minecraft:light_gray_concrete
fill 316 248 570 316 249 570 minecraft:iron_block
fill 316 248 571 316 249 571 minecraft:light_gray_concrete
fill 316 248 573 316 249 573 minecraft:iron_block
fill 316 248 582 316 251 584 minecraft:amethyst_block
fill 316 248 585 316 249 585 minecraft:iron_block
fill 316 248 587 316 249 587 minecraft:light_gray_concrete
fill 316 248 588 316 249 588 minecraft:iron_block
fill 317 248 571 317 249 571 minecraft:iron_block
fill 317 248 574 317 249 576 minecraft:iron_block
fill 317 248 582 317 249 584 minecraft:iron_block
fill 317 248 587 317 249 587 minecraft:iron_block
fill 318 248 572 318 249 573 minecraft:iron_block
fill 318 248 576 318 249 582 minecraft:iron_block
fill 318 248 585 318 249 586 minecraft:iron_block
fill 319 248 574 319 249 575 minecraft:iron_block
fill 319 248 583 319 249 584 minecraft:iron_block
fill 319 248 585 319 251 585 minecraft:amethyst_block
fill 320 248 576 320 248 582 minecraft:iron_block
fill 324 248 563 324 307 563 minecraft:purple_stained_glass
fill 324 248 575 324 307 575 minecraft:purple_stained_glass
fill 282 249 571 282 262 571 minecraft:purple_stained_glass
setblock 285 249 560 minecraft:light[level=14]
setblock 285 249 568 minecraft:light[level=14]
setblock 285 249 576 minecraft:light[level=14]
setblock 285 249 584 minecraft:light[level=14]
setblock 285 249 592 minecraft:light[level=14]
fill 287 249 557 287 292 557 minecraft:purple_stained_glass
fill 292 249 576 296 249 582 minecraft:blue_stained_glass
setblock 293 249 560 minecraft:light[level=14]
setblock 293 249 568 minecraft:light[level=14]
setblock 293 249 584 minecraft:light[level=14]
setblock 293 249 592 minecraft:light[level=14]
setblock 295 249 557 minecraft:sea_lantern
fill 297 249 599 299 261 599 minecraft:purple_stained_glass
setblock 299 249 557 minecraft:light_blue_stained_glass
setblock 300 249 599 minecraft:sea_lantern
setblock 301 249 560 minecraft:light[level=14]
setblock 301 249 568 minecraft:light[level=14]
setblock 301 249 576 minecraft:light[level=14]
setblock 301 249 584 minecraft:light[level=14]
setblock 301 249 592 minecraft:light[level=14]
fill 308 249 599 309 260 599 minecraft:purple_stained_glass
setblock 309 249 560 minecraft:light[level=14]
setblock 309 249 584 minecraft:light[level=14]
setblock 309 249 592 minecraft:light[level=14]
setblock 310 249 599 minecraft:white_concrete
fill 311 249 599 311 306 599 minecraft:purple_stained_glass
fill 314 249 583 314 251 584 minecraft:amethyst_block
fill 314 249 586 314 251 586 minecraft:amethyst_block
fill 315 249 582 315 251 582 minecraft:amethyst_block
setblock 317 249 560 minecraft:light[level=14]
setblock 317 249 568 minecraft:light[level=14]
setblock 317 249 592 minecraft:light[level=14]
fill 318 249 587 318 251 587 minecraft:amethyst_block
fill 319 249 586 319 251 586 minecraft:amethyst_block
fill 320 249 576 323 249 582 minecraft:blue_stained_glass
setblock 282 250 579 minecraft:sea_lantern
fill 285 250 583 286 251 583 minecraft:magenta_stained_glass
fill 295 250 557 295 257 557 minecraft:purple_stained_glass
fill 299 250 557 299 307 557 minecraft:purple_stained_glass
fill 300 250 571 300 250 572 minecraft:iron_block
fill 300 250 586 300 250 587 minecraft:iron_block
fill 300 250 599 300 258 599 minecraft:purple_stained_glass
fill 306 250 599 306 255 599 minecraft:purple_stained_glass
setblock 307 250 599 minecraft:light_blue_stained_glass
fill 310 250 599 310 272 599 minecraft:purple_stained_glass
fill 314 250 582 314 251 582 minecraft:amethyst_block
fill 314 250 585 314 251 585 minecraft:amethyst_block
fill 315 250 571 316 250 571 minecraft:iron_block
fill 315 250 586 315 251 586 minecraft:amethyst_block
fill 315 250 587 316 250 587 minecraft:iron_block
fill 316 250 581 318 251 581 minecraft:amethyst_block
fill 316 250 585 316 251 585 minecraft:amethyst_block
fill 316 250 588 317 251 588 minecraft:amethyst_block
fill 317 250 582 317 251 584 minecraft:amethyst_block
fill 317 250 587 317 251 587 minecraft:amethyst_block
fill 318 250 582 318 251 582 minecraft:amethyst_block
fill 318 250 585 318 251 586 minecraft:amethyst_block
fill 319 250 583 320 251 584 minecraft:amethyst_block
fill 319 250 587 319 251 587 minecraft:amethyst_block
fill 319 250 599 320 269 599 minecraft:purple_stained_glass
fill 320 250 585 320 251 586 minecraft:amethyst_block
setblock 321 250 599 minecraft:white_concrete
fill 322 250 599 324 274 599 minecraft:purple_stained_glass
setblock 324 250 586 minecraft:light_blue_stained_glass
setblock 282 251 566 minecraft:light_blue_stained_glass
setblock 282 251 577 minecraft:sea_lantern
fill 282 251 579 282 272 579 minecraft:purple_stained_glass
fill 307 251 599 307 254 599 minecraft:purple_stained_glass
fill 313 251 583 313 251 586 minecraft:amethyst_block
setblock 313 251 599 minecraft:white_concrete
fill 314 251 587 316 251 587 minecraft:amethyst_block
setblock 315 251 581 minecraft:amethyst_block
setblock 315 251 588 minecraft:amethyst_block
fill 316 251 586 317 251 586 minecraft:amethyst_block
setblock 317 251 585 minecraft:amethyst_block
fill 318 251 583 318 251 584 minecraft:amethyst_block
setblock 318 251 588 minecraft:amethyst_block
fill 319 251 581 319 251 582 minecraft:amethyst_block
setblock 320 251 582 minecraft:amethyst_block
fill 321 251 599 321 260 599 minecraft:purple_stained_glass
setblock 324 251 586 minecraft:purple_stained_glass
fill 282 252 565 282 254 565 minecraft:magenta_stained_glass
fill 282 252 566 282 258 566 minecraft:purple_stained_glass
fill 282 252 577 282 257 577 minecraft:purple_stained_glass
fill 282 252 581 282 254 581 minecraft:magenta_stained_glass
fill 282 252 597 282 254 597 minecraft:magenta_stained_glass
fill 286 252 557 286 254 557 minecraft:magenta_stained_glass
fill 296 252 599 296 254 599 minecraft:magenta_stained_glass
fill 302 252 557 302 254 557 minecraft:magenta_stained_glass
fill 304 252 589 304 253 590 minecraft:magenta_stained_glass
fill 307 252 558 309 257 558 minecraft:light_blue_stained_glass
fill 308 252 559 308 257 559 minecraft:light_blue_stained_glass
fill 312 252 599 312 254 599 minecraft:magenta_stained_glass
setblock 313 252 599 minecraft:light_blue_stained_glass
setblock 314 252 557 minecraft:white_concrete
setblock 315 252 557 minecraft:sea_lantern
fill 316 252 557 317 259 557 minecraft:purple_stained_glass
fill 316 252 584 317 253 585 minecraft:light_blue_stained_glass
fill 318 252 557 318 254 557 minecraft:magenta_stained_glass
setblock 318 252 599 minecraft:sea_lantern
fill 324 252 567 324 254 567 minecraft:magenta_stained_glass
setblock 324 252 582 minecraft:light_blue_stained_glass
fill 324 252 583 324 254 583 minecraft:magenta_stained_glass
setblock 324 252 586 minecraft:light_blue_stained_glass
setblock 282 253 558 minecraft:sea_lantern
setblock 287 253 599 minecraft:sea_lantern
setblock 306 253 557 minecraft:white_concrete
fill 306 253 558 306 256 559 minecraft:light_blue_stained_glass
fill 307 253 557 307 287 557 minecraft:purple_stained_glass
fill 307 253 559 307 255 561 minecraft:light_blue_stained_glass
fill 308 253 560 308 254 563 minecraft:light_blue_stained_glass
fill 309 253 559 309 255 561 minecraft:light_blue_stained_glass
setblock 310 253 557 minecraft:sea_lantern
fill 310 253 558 310 256 559 minecraft:light_blue_stained_glass
setblock 313 253 557 minecraft:light_blue_stained_glass
fill 313 253 599 313 282 599 minecraft:purple_stained_glass
fill 314 253 557 315 272 557 minecraft:purple_stained_glass
setblock 316 253 599 minecraft:white_concrete
fill 318 253 599 318 304 599 minecraft:purple_stained_glass
fill 324 253 582 324 288 582 minecraft:purple_stained_glass
fill 324 253 586 324 296 586 minecraft:purple_stained_glass
fill 282 254 558 282 297 558 minecraft:purple_stained_glass
fill 282 254 584 282 261 584 minecraft:purple_stained_glass
setblock 282 254 585 minecraft:white_concrete
fill 282 254 586 282 291 586 minecraft:purple_stained_glass
fill 287 254 599 287 307 599 minecraft:purple_stained_glass
setblock 301 254 599 minecraft:white_concrete
fill 306 254 557 306 261 557 minecraft:purple_stained_glass
setblock 306 254 560 minecraft:light_blue_stained_glass
setblock 307 254 562 minecraft:light_blue_stained_glass
setblock 309 254 562 minecraft:light_blue_stained_glass
fill 310 254 557 310 307 557 minecraft:purple_stained_glass
setblock 310 254 560 minecraft:light_blue_stained_glass
fill 313 254 557 313 291 557 minecraft:purple_stained_glass
fill 316 254 599 316 307 599 minecraft:purple_stained_glass
fill 317 254 584 317 254 585 minecraft:light_blue_stained_glass
fill 282 255 565 282 260 565 minecraft:purple_stained_glass
fill 282 255 581 282 260 581 minecraft:purple_stained_glass
fill 282 255 585 282 284 585 minecraft:purple_stained_glass
setblock 282 255 595 minecraft:light_blue_stained_glass
fill 282 255 597 282 260 597 minecraft:purple_stained_glass
fill 286 255 557 286 260 557 minecraft:purple_stained_glass
fill 296 255 599 296 260 599 minecraft:purple_stained_glass
fill 301 255 599 301 307 599 minecraft:purple_stained_glass
fill 302 255 557 302 260 557 minecraft:purple_stained_glass
setblock 307 255 599 minecraft:sea_lantern
fill 308 255 560 308 255 562 minecraft:light_blue_stained_glass
fill 312 255 599 312 260 599 minecraft:purple_stained_glass
setblock 317 255 584 minecraft:light_blue_stained_glass
fill 318 255 557 318 260 557 minecraft:purple_stained_glass
setblock 322 255 557 minecraft:sea_lantern
fill 324 255 567 324 260 567 minecraft:purple_stained_glass
fill 324 255 583 324 260 583 minecraft:purple_stained_glass
fill 282 256 595 282 307 595 minecraft:purple_stained_glass
setblock 306 256 599 minecraft:white_concrete
fill 307 256 559 307 256 560 minecraft:light_blue_stained_glass
fill 307 256 599 307 290 599 minecraft:purple_stained_glass
fill 308 256 560 309 256 560 minecraft:light_blue_stained_glass
setblock 309 256 559 minecraft:light_blue_stained_glass
fill 322 256 557 322 307 557 minecraft:purple_stained_glass
fill 324 256 569 324 267 570 minecraft:purple_stained_glass
setblock 324 256 571 minecraft:sea_lantern
setblock 282 257 578 minecraft:white_concrete
setblock 285 257 560 minecraft:light[level=14]
setblock 285 257 568 minecraft:light[level=14]
setblock 285 257 576 minecraft:light[level=14]
setblock 285 257 584 minecraft:light[level=14]
setblock 285 257 592 minecraft:light[level=14]
fill 290 257 557 291 271 557 minecraft:purple_stained_glass
setblock 292 257 557 minecraft:white_concrete
setblock 293 257 560 minecraft:light[level=14]
setblock 293 257 568 minecraft:light[level=14]
setblock 293 257 576 minecraft:light[level=14]
setblock 293 257 584 minecraft:light[level=14]
setblock 293 257 592 minecraft:light[level=14]
setblock 301 257 560 minecraft:light[level=14]
setblock 301 257 568 minecraft:light[level=14]
setblock 301 257 576 minecraft:light[level=14]
setblock 301 257 584 minecraft:light[level=14]
setblock 301 257 592 minecraft:light[level=14]
fill 303 257 592 304 258 592 minecraft:light_blue_stained_glass
fill 306 257 599 306 267 599 minecraft:purple_stained_glass
setblock 309 257 560 minecraft:light[level=14]
setblock 309 257 568 minecraft:light[level=14]
setblock 309 257 576 minecraft:light[level=14]
setblock 309 257 584 minecraft:light[level=14]
setblock 309 257 592 minecraft:light[level=14]
setblock 317 257 560 minecraft:light[level=14]
setblock 317 257 568 minecraft:light[level=14]
setblock 317 257 576 minecraft:light[level=14]
setblock 317 257 584 minecraft:light[level=14]
setblock 317 257 592 minecraft:light[level=14]
fill 324 257 571 324 270 571 minecraft:purple_stained_glass
setblock 324 257 596 minecraft:light_blue_stained_glass
setblock 282 258 577 minecraft:white_concrete
fill 282 258 578 282 307 578 minecraft:purple_stained_glass
fill 289 258 599 290 273 599 minecraft:purple_stained_glass
setblock 291 258 599 minecraft:sea_lantern
fill 292 258 557 292 261 557 minecraft:purple_stained_glass
fill 292 258 599 292 273 599 minecraft:purple_stained_glass
setblock 295 258 557 minecraft:sea_lantern
fill 324 258 596 324 307 596 minecraft:purple_stained_glass
setblock 282 259 566 minecraft:light_blue_stained_glass
fill 282 259 577 282 307 577 minecraft:purple_stained_glass
setblock 282 259 587 minecraft:light_blue_stained_glass
setblock 282 259 592 minecraft:light_blue_stained_glass
fill 291 259 599 291 307 599 minecraft:purple_stained_glass
fill 295 259 557 295 262 557 minecraft:purple_stained_glass
setblock 300 259 599 minecraft:light_blue_stained_glass
fill 282 260 566 282 291 566 minecraft:purple_stained_glass
setblock 282 260 568 minecraft:white_concrete
fill 282 260 587 282 297 587 minecraft:purple_stained_glass
fill 282 260 592 282 282 592 minecraft:purple_stained_glass
fill 286 260 583 286 261 583 minecraft:amethyst_block
setblock 288 260 557 minecraft:light_blue_stained_glass
fill 300 260 599 300 280 599 minecraft:purple_stained_glass
fill 315 260 569 315 261 569 minecraft:light_blue_stained_glass
fill 316 260 557 316 307 557 minecraft:purple_stained_glass
setblock 317 260 557 minecraft:sea_lantern
fill 324 260 572 324 260 573 minecraft:sea_lantern
fill 282 261 565 282 263 565 minecraft:magenta_stained_glass
fill 282 261 568 282 307 568 minecraft:purple_stained_glass
setblock 282 261 575 minecraft:white_concrete
fill 282 261 581 282 263 581 minecraft:magenta_stained_glass
fill 282 261 597 282 263 597 minecraft:magenta_stained_glass
fill 286 261 557 286 263 557 minecraft:magenta_stained_glass
fill 288 261 557 288 307 557 minecraft:purple_stained_glass
fill 296 261 599 296 263 599 minecraft:magenta_stained_glass
fill 302 261 557 302 263 557 minecraft:magenta_stained_glass
fill 308 261 599 308 291 599 minecraft:purple_stained_glass
setblock 309 261 599 minecraft:sea_lantern
fill 312 261 599 312 263 599 minecraft:magenta_stained_glass
fill 317 261 557 317 307 557 minecraft:purple_stained_glass
fill 318 261 557 318 263 557 minecraft:magenta_stained_glass
setblock 321 261 599 minecraft:sea_lantern
fill 324 261 567 324 263 567 minecraft:magenta_stained_glass
fill 324 261 572 324 283 573 minecraft:purple_stained_glass
fill 324 261 583 324 263 583 minecraft:magenta_stained_glass
setblock 324 261 584 minecraft:light_blue_stained_glass
fill 282 262 575 282 301 575 minecraft:purple_stained_glass
setblock 282 262 584 minecraft:sea_lantern
setblock 282 262 598 minecraft:sea_lantern
setblock 292 262 557 minecraft:light_blue_stained_glass
setblock 294 262 557 minecraft:white_concrete
setblock 297 262 599 minecraft:sea_lantern
fill 298 262 599 299 277 599 minecraft:purple_stained_glass
setblock 306 262 557 minecraft:sea_lantern
setblock 309 262 599 minecraft:light_blue_stained_glass
fill 321 262 599 321 269 599 minecraft:purple_stained_glass
setblock 324 262 561 minecraft:light_blue_stained_glass
fill 324 262 584 324 266 584 minecraft:purple_stained_glass
setblock 324 262 589 minecraft:light_blue_stained_glass
fill 324 262 590 324 263 590 minecraft:purple_stained_glass
setblock 282 263 571 minecraft:light_blue_stained_glass
fill 282 263 584 282 289 584 minecraft:purple_stained_glass
setblock 282 263 594 minecraft:light_blue_stained_glass
fill 282 263 598 282 279 598 minecraft:purple_stained_glass
fill 292 263 557 292 307 557 minecraft:purple_stained_glass
fill 294 263 557 294 307 557 minecraft:purple_stained_glass
setblock 295 263 557 minecraft:white_concrete
fill 297 263 599 297 280 599 minecraft:purple_stained_glass
fill 306 263 557 306 294 557 minecraft:purple_stained_glass
fill 309 263 599 309 307 599 minecraft:purple_stained_glass
fill 324 263 558 324 295 558 minecraft:purple_stained_glass
setblock 324 263 559 minecraft:sea_lantern
fill 324 263 560 324 264 561 minecraft:purple_stained_glass
setblock 324 263 574 minecraft:sea_lantern
fill 324 263 589 324 266 589 minecraft:purple_stained_glass
setblock 324 263 593 minecraft:light_blue_stained_glass
fill 282 264 565 282 269 565 minecraft:purple_stained_glass
fill 282 264 571 282 265 571 minecraft:purple_stained_glass
fill 282 264 581 282 269 581 minecraft:purple_stained_glass
fill 282 264 594 282 284 594 minecraft:purple_stained_glass
fill 282 264 597 282 269 597 minecraft:purple_stained_glass
fill 286 264 557 286 269 557 minecraft:purple_stained_glass
fill 295 264 557 295 307 557 minecraft:purple_stained_glass
fill 296 264 599 296 269 599 minecraft:purple_stained_glass
fill 302 264 557 302 269 557 minecraft:purple_stained_glass
fill 312 264 599 312 269 599 minecraft:purple_stained_glass
fill 318 264 557 318 269 557 minecraft:purple_stained_glass
fill 324 264 559 324 280 559 minecraft:purple_stained_glass
fill 324 264 567 324 269 567 minecraft:purple_stained_glass
fill 324 264 574 324 307 574 minecraft:purple_stained_glass
fill 324 264 583 324 269 583 minecraft:purple_stained_glass
setblock 324 264 590 minecraft:white_concrete
fill 324 264 593 324 296 593 minecraft:purple_stained_glass
fill 324 264 594 324 264 595 minecraft:white_concrete
setblock 282 265 582 minecraft:white_concrete
setblock 285 265 560 minecraft:light[level=14]
setblock 285 265 568 minecraft:light[level=14]
setblock 285 265 576 minecraft:light[level=14]
setblock 285 265 584 minecraft:light[level=14]
setblock 285 265 592 minecraft:light[level=14]
setblock 293 265 560 minecraft:light[level=14]
setblock 293 265 568 minecraft:light[level=14]
setblock 293 265 576 minecraft:light[level=14]
setblock 293 265 584 minecraft:light[level=14]
setblock 293 265 592 minecraft:light[level=14]
setblock 301 265 560 minecraft:light[level=14]
setblock 301 265 568 minecraft:light[level=14]
setblock 301 265 576 minecraft:light[level=14]
setblock 301 265 584 minecraft:light[level=14]
setblock 301 265 592 minecraft:light[level=14]
setblock 309 265 560 minecraft:light[level=14]
setblock 309 265 568 minecraft:light[level=14]
setblock 309 265 576 minecraft:light[level=14]
setblock 309 265 584 minecraft:light[level=14]
setblock 309 265 592 minecraft:light[level=14]
setblock 317 265 560 minecraft:light[level=14]
setblock 317 265 568 minecraft:light[level=14]
setblock 317 265 576 minecraft:light[level=14]
setblock 317 265 584 minecraft:light[level=14]
setblock 317 265 592 minecraft:light[level=14]
fill 324 265 560 324 307 560 minecraft:purple_stained_glass
setblock 324 265 561 minecraft:white_concrete
fill 324 265 590 324 307 590 minecraft:purple_stained_glass
fill 324 265 594 324 265 595 minecraft:purple_stained_glass
setblock 282 266 571 minecraft:white_concrete
fill 282 266 582 282 307 582 minecraft:purple_stained_glass
setblock 317 266 599 minecraft:white_concrete
fill 321 266 589 323 269 591 minecraft:light_blue_stained_glass
fill 324 266 561 324 270 561 minecraft:purple_stained_glass
setblock 324 266 594 minecraft:light_blue_stained_glass
fill 324 266 595 324 302 595 minecraft:purple_stained_glass
fill 282 267 571 282 278 571 minecraft:purple_stained_glass
setblock 315 267 599 minecraft:white_concrete
fill 317 267 599 317 307 599 minecraft:purple_stained_glass
setblock 320 267 557 minecraft:sea_lantern
fill 320 267 590 320 270 590 minecraft:light_blue_stained_glass
fill 322 267 588 322 268 588 minecraft:light_blue_stained_glass
fill 322 267 592 322 268 592 minecraft:light_blue_stained_glass
setblock 324 267 584 minecraft:light_blue_stained_glass
setblock 324 267 589 minecraft:white_concrete
fill 324 267 594 324 279 594 minecraft:purple_stained_glass
setblock 300 268 557 minecraft:white_concrete
setblock 303 268 599 minecraft:light_blue_stained_glass
setblock 306 268 599 minecraft:sea_lantern
fill 315 268 599 315 307 599 minecraft:purple_stained_glass
fill 320 268 557 320 307 557 minecraft:purple_stained_glass
fill 320 268 589 320 270 589 minecraft:light_blue_stained_glass
fill 320 268 591 320 270 591 minecraft:light_blue_stained_glass
fill 324 268 569 324 307 569 minecraft:purple_stained_glass
setblock 324 268 570 minecraft:light_blue_stained_glass
fill 324 268 584 324 274 584 minecraft:purple_stained_glass
setblock 324 268 589 minecraft:sea_lantern
setblock 300 269 557 minecraft:purple_stained_glass
fill 303 269 599 303 307 599 minecraft:purple_stained_glass
fill 306 269 599 306 307 599 minecraft:purple_stained_glass
schedule function dropper:buildpart/138_2 1t
