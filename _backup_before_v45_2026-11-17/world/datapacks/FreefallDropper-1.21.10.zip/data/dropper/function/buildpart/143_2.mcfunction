fill 558 275 557 558 276 557 minecraft:black_concrete
fill 559 275 568 559 275 569 minecraft:white_stained_glass
fill 517 276 584 517 307 584 minecraft:black_concrete
setblock 517 276 585 minecraft:white_stained_glass
setblock 524 276 599 minecraft:white_concrete
fill 546 276 599 546 302 599 minecraft:black_concrete
setblock 550 276 557 minecraft:black_concrete
fill 555 276 599 555 280 599 minecraft:black_concrete
fill 559 276 568 559 307 569 minecraft:black_concrete
fill 517 277 585 517 300 585 minecraft:black_concrete
fill 524 277 599 524 307 599 minecraft:black_concrete
setblock 541 277 557 minecraft:sea_lantern
setblock 550 277 557 minecraft:white_concrete
setblock 558 277 557 minecraft:white_stained_glass
fill 517 278 577 517 307 577 minecraft:black_concrete
setblock 517 278 578 minecraft:white_concrete
setblock 517 278 579 minecraft:sea_lantern
setblock 517 278 587 minecraft:white_stained_glass
fill 532 278 583 534 278 585 minecraft:redstone_block
fill 535 278 574 537 278 576 minecraft:redstone_block
fill 539 278 582 541 278 584 minecraft:redstone_block
fill 541 278 557 541 301 557 minecraft:black_concrete
setblock 548 278 557 minecraft:sea_lantern
fill 550 278 557 550 307 557 minecraft:black_concrete
fill 558 278 557 558 307 557 minecraft:black_concrete
fill 517 279 578 517 307 579 minecraft:black_concrete
fill 517 279 587 517 306 587 minecraft:black_concrete
fill 518 279 558 519 280 582 minecraft:blue_concrete
fill 518 279 583 518 280 583 minecraft:white_concrete
fill 518 279 584 525 280 586 minecraft:blue_concrete
fill 518 279 587 518 280 587 minecraft:white_concrete
fill 518 279 588 520 280 590 minecraft:blue_concrete
fill 518 279 591 518 280 591 minecraft:white_concrete
fill 518 279 592 520 280 598 minecraft:blue_concrete
fill 519 279 583 531 279 583 minecraft:blue_concrete
fill 519 279 587 542 280 587 minecraft:blue_concrete
fill 519 279 591 523 280 591 minecraft:blue_concrete
fill 520 279 558 521 280 565 minecraft:blue_concrete
fill 520 279 566 520 280 566 minecraft:white_concrete
fill 520 279 567 527 280 569 minecraft:blue_concrete
fill 520 279 570 520 280 570 minecraft:white_concrete
fill 520 279 571 522 280 573 minecraft:blue_concrete
fill 520 279 574 520 280 574 minecraft:white_concrete
fill 520 279 575 522 280 582 minecraft:blue_concrete
fill 521 279 566 538 280 566 minecraft:blue_concrete
fill 521 279 570 538 280 570 minecraft:blue_concrete
fill 521 279 574 534 279 574 minecraft:blue_concrete
fill 521 279 588 528 280 588 minecraft:blue_concrete
fill 521 279 589 521 280 589 minecraft:white_concrete
fill 521 279 590 531 280 590 minecraft:blue_concrete
fill 521 279 592 534 280 592 minecraft:blue_concrete
fill 521 279 593 521 280 593 minecraft:white_concrete
fill 521 279 594 523 280 598 minecraft:blue_concrete
fill 522 279 558 524 280 560 minecraft:blue_concrete
fill 522 279 561 522 280 561 minecraft:white_concrete
fill 522 279 562 524 280 565 minecraft:blue_concrete
fill 522 279 589 539 280 589 minecraft:blue_concrete
fill 522 279 593 545 280 593 minecraft:blue_concrete
fill 523 279 561 527 280 561 minecraft:blue_concrete
fill 523 279 571 530 280 571 minecraft:blue_concrete
fill 523 279 572 523 280 572 minecraft:white_concrete
fill 523 279 573 533 280 573 minecraft:blue_concrete
fill 523 279 575 530 280 575 minecraft:blue_concrete
fill 523 279 576 523 280 576 minecraft:white_concrete
fill 523 279 577 525 280 579 minecraft:blue_concrete
fill 523 279 580 523 280 580 minecraft:white_concrete
fill 523 279 581 525 280 582 minecraft:blue_concrete
setblock 523 279 599 minecraft:white_stained_glass
fill 524 279 572 541 280 572 minecraft:blue_concrete
fill 524 279 576 534 279 576 minecraft:blue_concrete
fill 524 279 580 534 279 580 minecraft:blue_concrete
fill 524 279 591 524 280 591 minecraft:white_concrete
fill 524 279 594 531 280 594 minecraft:blue_concrete
fill 524 279 595 524 280 595 minecraft:white_concrete
fill 524 279 596 526 280 598 minecraft:blue_concrete
fill 525 279 558 532 280 558 minecraft:blue_concrete
fill 525 279 559 525 280 559 minecraft:white_concrete
fill 525 279 560 535 280 560 minecraft:blue_concrete
fill 525 279 562 538 280 562 minecraft:blue_concrete
fill 525 279 563 525 280 563 minecraft:white_concrete
fill 525 279 564 527 280 565 minecraft:blue_concrete
fill 525 279 591 542 280 591 minecraft:blue_concrete
fill 525 279 595 542 280 595 minecraft:blue_concrete
fill 526 279 559 543 280 559 minecraft:blue_concrete
fill 526 279 563 549 280 563 minecraft:blue_concrete
fill 526 279 577 533 280 577 minecraft:blue_concrete
fill 526 279 578 526 280 578 minecraft:white_concrete
fill 526 279 579 534 279 579 minecraft:blue_concrete
fill 526 279 581 533 280 581 minecraft:blue_concrete
fill 526 279 582 526 280 582 minecraft:white_concrete
fill 526 279 584 528 280 585 minecraft:blue_concrete
fill 526 279 586 526 280 586 minecraft:white_concrete
setblock 526 279 599 minecraft:white_concrete
fill 527 279 578 544 279 578 minecraft:blue_concrete
fill 527 279 582 538 279 582 minecraft:blue_concrete
fill 527 279 586 531 279 586 minecraft:blue_concrete
fill 527 279 596 534 280 596 minecraft:blue_concrete
fill 527 279 597 527 280 597 minecraft:white_concrete
fill 527 279 598 537 280 598 minecraft:blue_concrete
fill 528 279 561 528 280 561 minecraft:white_concrete
fill 528 279 564 535 280 564 minecraft:blue_concrete
fill 528 279 565 528 280 565 minecraft:white_concrete
fill 528 279 567 530 280 568 minecraft:blue_concrete
fill 528 279 569 528 280 569 minecraft:white_concrete
fill 528 279 597 545 280 597 minecraft:blue_concrete
fill 529 279 561 546 280 561 minecraft:blue_concrete
fill 529 279 565 546 280 565 minecraft:blue_concrete
fill 529 279 569 552 280 569 minecraft:blue_concrete
fill 529 279 584 529 280 584 minecraft:white_concrete
fill 529 279 585 531 279 585 minecraft:blue_concrete
fill 529 279 588 529 280 588 minecraft:white_concrete
fill 530 279 584 531 279 584 minecraft:blue_concrete
fill 530 279 588 553 280 588 minecraft:blue_concrete
fill 531 279 567 531 280 567 minecraft:white_concrete
fill 531 279 568 541 280 568 minecraft:blue_concrete
fill 531 279 571 531 280 571 minecraft:white_concrete
fill 531 279 575 531 280 575 minecraft:white_concrete
fill 532 279 567 549 280 567 minecraft:blue_concrete
fill 532 279 571 549 280 571 minecraft:blue_concrete
fill 532 279 575 534 279 575 minecraft:blue_concrete
setblock 532 279 586 minecraft:white_concrete
fill 532 279 590 532 280 590 minecraft:white_concrete
fill 532 279 594 532 280 594 minecraft:white_concrete
fill 533 279 558 533 280 558 minecraft:white_concrete
fill 533 279 586 550 279 586 minecraft:blue_concrete
fill 533 279 590 550 280 590 minecraft:blue_concrete
fill 533 279 594 556 280 594 minecraft:blue_concrete
setblock 534 279 557 minecraft:white_stained_glass
fill 534 279 558 557 280 558 minecraft:blue_concrete
setblock 534 279 573 minecraft:white_concrete
setblock 534 279 577 minecraft:white_concrete
setblock 534 279 581 minecraft:white_concrete
fill 535 279 573 552 279 573 minecraft:blue_concrete
fill 535 279 577 558 279 577 minecraft:blue_concrete
fill 535 279 583 536 279 585 minecraft:blue_concrete
fill 535 279 592 535 280 592 minecraft:white_concrete
fill 535 279 596 535 280 596 minecraft:white_concrete
fill 536 279 560 536 280 560 minecraft:white_concrete
fill 536 279 564 536 280 564 minecraft:white_concrete
fill 536 279 592 553 280 592 minecraft:blue_concrete
fill 536 279 596 558 280 596 minecraft:blue_concrete
fill 537 279 560 554 280 560 minecraft:blue_concrete
fill 537 279 564 558 280 564 minecraft:blue_concrete
fill 537 279 583 537 280 583 minecraft:white_concrete
fill 537 279 584 538 279 585 minecraft:blue_concrete
fill 538 279 574 541 279 576 minecraft:blue_concrete
fill 538 279 579 539 279 581 minecraft:blue_concrete
setblock 538 279 583 minecraft:blue_concrete
fill 538 279 598 538 280 598 minecraft:white_concrete
fill 539 279 562 539 280 562 minecraft:white_concrete
fill 539 279 566 539 280 566 minecraft:white_concrete
fill 539 279 570 539 280 570 minecraft:white_concrete
setblock 539 279 585 minecraft:blue_concrete
fill 539 279 598 556 280 598 minecraft:blue_concrete
fill 540 279 562 557 280 562 minecraft:blue_concrete
fill 540 279 566 557 280 566 minecraft:blue_concrete
fill 540 279 570 558 280 570 minecraft:blue_concrete
fill 540 279 579 547 280 580 minecraft:blue_concrete
setblock 540 279 581 minecraft:white_concrete
setblock 540 279 585 minecraft:white_concrete
fill 540 279 589 540 280 589 minecraft:white_concrete
fill 541 279 581 558 279 581 minecraft:blue_concrete
fill 541 279 585 558 279 585 minecraft:blue_concrete
fill 541 279 589 558 280 589 minecraft:blue_concrete
fill 542 279 568 542 280 568 minecraft:white_concrete
fill 542 279 572 542 280 572 minecraft:white_concrete
fill 542 279 574 544 280 575 minecraft:blue_concrete
fill 542 279 576 542 280 576 minecraft:white_concrete
fill 542 279 582 547 279 584 minecraft:blue_concrete
fill 543 279 568 558 280 568 minecraft:blue_concrete
fill 543 279 572 558 280 572 minecraft:blue_concrete
fill 543 279 576 547 280 576 minecraft:blue_concrete
fill 543 279 587 543 280 587 minecraft:white_concrete
fill 543 279 591 543 280 591 minecraft:white_concrete
fill 543 279 595 543 280 595 minecraft:white_concrete
fill 544 279 559 544 280 559 minecraft:white_concrete
fill 544 279 587 558 280 587 minecraft:blue_concrete
fill 544 279 591 558 280 591 minecraft:blue_concrete
fill 544 279 595 548 280 595 minecraft:blue_concrete
fill 545 279 559 558 280 559 minecraft:blue_concrete
fill 545 279 574 545 280 574 minecraft:white_concrete
fill 545 279 575 555 280 575 minecraft:blue_concrete
fill 545 279 578 545 280 578 minecraft:white_concrete
fill 546 279 574 558 280 574 minecraft:blue_concrete
fill 546 279 578 558 280 578 minecraft:blue_concrete
fill 546 279 593 546 280 593 minecraft:white_concrete
fill 546 279 597 546 280 597 minecraft:white_concrete
fill 547 279 561 547 280 561 minecraft:white_concrete
fill 547 279 565 547 280 565 minecraft:white_concrete
fill 547 279 593 558 280 593 minecraft:blue_concrete
fill 547 279 597 558 280 597 minecraft:blue_concrete
fill 548 279 557 548 307 557 minecraft:black_concrete
fill 548 279 561 558 280 561 minecraft:blue_concrete
fill 548 279 565 558 280 565 minecraft:blue_concrete
fill 548 279 576 548 280 576 minecraft:white_concrete
fill 548 279 579 555 280 579 minecraft:blue_concrete
fill 548 279 580 548 280 580 minecraft:white_concrete
fill 548 279 582 550 280 583 minecraft:blue_concrete
fill 548 279 584 548 280 584 minecraft:white_concrete
fill 549 279 576 558 280 576 minecraft:blue_concrete
fill 549 279 580 558 280 580 minecraft:blue_concrete
fill 549 279 584 558 280 584 minecraft:blue_concrete
fill 549 279 595 549 280 595 minecraft:white_concrete
fill 550 279 563 550 280 563 minecraft:white_concrete
fill 550 279 567 550 280 567 minecraft:white_concrete
fill 550 279 571 550 280 571 minecraft:white_concrete
fill 550 279 595 558 280 595 minecraft:blue_concrete
fill 551 279 563 558 280 563 minecraft:blue_concrete
fill 551 279 567 558 280 567 minecraft:blue_concrete
fill 551 279 571 555 280 571 minecraft:blue_concrete
fill 551 279 582 551 280 582 minecraft:white_concrete
fill 551 279 583 558 280 583 minecraft:blue_concrete
fill 551 279 586 551 280 586 minecraft:white_concrete
fill 551 279 590 551 280 590 minecraft:white_concrete
fill 552 279 582 558 280 582 minecraft:blue_concrete
fill 552 279 586 558 280 586 minecraft:blue_concrete
fill 552 279 590 556 280 590 minecraft:blue_concrete
fill 553 279 569 553 280 569 minecraft:white_concrete
fill 553 279 573 553 280 573 minecraft:white_concrete
fill 554 279 569 558 280 569 minecraft:blue_concrete
fill 554 279 573 558 280 573 minecraft:blue_concrete
fill 554 279 588 554 280 588 minecraft:white_concrete
fill 554 279 592 554 280 592 minecraft:white_concrete
fill 555 279 560 555 280 560 minecraft:white_concrete
fill 555 279 588 558 280 588 minecraft:blue_concrete
fill 555 279 592 558 280 592 minecraft:blue_concrete
fill 556 279 560 558 280 560 minecraft:blue_concrete
fill 556 279 571 556 280 571 minecraft:white_concrete
fill 556 279 575 556 280 575 minecraft:white_concrete
fill 556 279 579 556 280 579 minecraft:white_concrete
fill 557 279 571 558 280 571 minecraft:blue_concrete
fill 557 279 575 558 280 575 minecraft:blue_concrete
fill 557 279 579 558 280 579 minecraft:blue_concrete
fill 557 279 590 557 280 590 minecraft:white_concrete
fill 557 279 594 557 280 594 minecraft:white_concrete
fill 557 279 598 557 280 598 minecraft:white_concrete
fill 558 279 558 558 280 558 minecraft:white_concrete
fill 558 279 562 558 280 562 minecraft:white_concrete
fill 558 279 566 558 280 566 minecraft:white_concrete
fill 558 279 590 558 280 590 minecraft:blue_concrete
fill 558 279 594 558 280 594 minecraft:blue_concrete
fill 558 279 598 558 280 598 minecraft:blue_concrete
setblock 517 280 568 minecraft:white_stained_glass
fill 519 280 583 530 280 583 minecraft:blue_concrete
fill 521 280 574 533 280 574 minecraft:blue_concrete
fill 523 280 599 523 307 599 minecraft:black_concrete
fill 524 280 576 533 280 576 minecraft:blue_concrete
fill 524 280 580 533 280 580 minecraft:blue_concrete
fill 526 280 579 533 280 579 minecraft:blue_concrete
fill 526 280 599 526 307 599 minecraft:black_concrete
fill 527 280 578 533 280 578 minecraft:blue_concrete
fill 527 280 582 530 280 582 minecraft:blue_concrete
fill 527 280 586 530 280 586 minecraft:blue_concrete
fill 529 280 585 530 280 585 minecraft:blue_concrete
setblock 530 280 584 minecraft:blue_concrete
fill 531 280 582 531 280 586 minecraft:sea_lantern
fill 532 280 575 533 280 575 minecraft:blue_concrete
fill 532 280 582 538 280 582 minecraft:sea_lantern
fill 532 280 583 534 280 585 minecraft:blue_concrete
fill 532 280 586 535 280 586 minecraft:sea_lantern
fill 534 280 557 534 286 557 minecraft:black_concrete
fill 534 280 573 534 280 581 minecraft:sea_lantern
fill 535 280 573 538 280 573 minecraft:sea_lantern
fill 535 280 574 537 280 576 minecraft:blue_concrete
fill 535 280 577 538 280 578 minecraft:sea_lantern
fill 535 280 583 535 280 585 minecraft:sea_lantern
fill 536 280 583 536 280 586 minecraft:blue_concrete
fill 537 280 584 537 280 586 minecraft:blue_concrete
fill 538 280 574 538 280 576 minecraft:sea_lantern
fill 538 280 579 538 280 581 minecraft:sea_lantern
fill 538 280 583 538 280 585 minecraft:sea_lantern
fill 538 280 586 550 280 586 minecraft:blue_concrete
fill 539 280 573 539 280 580 minecraft:blue_concrete
fill 539 280 581 542 280 581 minecraft:sea_lantern
fill 539 280 582 541 280 584 minecraft:blue_concrete
fill 539 280 585 542 280 585 minecraft:sea_lantern
fill 540 280 573 541 280 578 minecraft:blue_concrete
fill 542 280 573 552 280 573 minecraft:blue_concrete
fill 542 280 577 544 280 578 minecraft:blue_concrete
fill 542 280 582 542 280 584 minecraft:sea_lantern
fill 543 280 581 547 280 585 minecraft:blue_concrete
fill 545 280 577 558 280 577 minecraft:blue_concrete
fill 548 280 581 558 280 581 minecraft:blue_concrete
fill 548 280 585 558 280 585 minecraft:blue_concrete
setblock 517 281 566 minecraft:white_concrete
fill 517 281 568 517 307 568 minecraft:black_concrete
setblock 517 281 598 minecraft:white_stained_glass
setblock 530 281 599 minecraft:white_stained_glass
setblock 555 281 599 minecraft:sea_lantern
fill 559 281 574 559 297 578 minecraft:black_concrete
setblock 559 281 579 minecraft:white_stained_glass
fill 559 281 580 559 307 580 minecraft:black_concrete
setblock 559 281 590 minecraft:sea_lantern
fill 559 281 591 559 296 591 minecraft:black_concrete
fill 517 282 566 517 299 566 minecraft:black_concrete
fill 517 282 598 517 307 598 minecraft:black_concrete
setblock 519 282 599 minecraft:sea_lantern
setblock 520 282 560 minecraft:light[level=14]
setblock 520 282 568 minecraft:light[level=14]
setblock 520 282 576 minecraft:light[level=14]
setblock 520 282 584 minecraft:light[level=14]
setblock 520 282 592 minecraft:light[level=14]
setblock 522 282 557 minecraft:sea_lantern
setblock 528 282 560 minecraft:light[level=14]
setblock 528 282 568 minecraft:light[level=14]
setblock 528 282 576 minecraft:light[level=14]
setblock 528 282 584 minecraft:light[level=14]
setblock 528 282 592 minecraft:light[level=14]
fill 530 282 599 530 307 599 minecraft:black_concrete
setblock 536 282 560 minecraft:light[level=14]
setblock 536 282 568 minecraft:light[level=14]
setblock 536 282 576 minecraft:light[level=14]
setblock 536 282 584 minecraft:light[level=14]
setblock 536 282 592 minecraft:light[level=14]
setblock 544 282 560 minecraft:light[level=14]
setblock 544 282 568 minecraft:light[level=14]
setblock 544 282 576 minecraft:light[level=14]
setblock 544 282 584 minecraft:light[level=14]
setblock 544 282 592 minecraft:light[level=14]
setblock 552 282 560 minecraft:light[level=14]
setblock 552 282 568 minecraft:light[level=14]
setblock 552 282 576 minecraft:light[level=14]
setblock 552 282 584 minecraft:light[level=14]
setblock 552 282 592 minecraft:light[level=14]
fill 555 282 599 555 307 599 minecraft:black_concrete
fill 559 282 579 559 283 579 minecraft:black_concrete
setblock 559 282 589 minecraft:white_stained_glass
fill 559 282 590 559 303 590 minecraft:black_concrete
fill 519 283 599 519 307 599 minecraft:black_concrete
fill 522 283 557 522 307 557 minecraft:black_concrete
setblock 522 283 599 minecraft:white_concrete
setblock 531 283 599 minecraft:sea_lantern
setblock 535 283 599 minecraft:white_stained_glass
setblock 559 283 560 minecraft:white_concrete
fill 559 283 589 559 307 589 minecraft:black_concrete
setblock 517 284 586 minecraft:white_concrete
fill 522 284 599 522 307 599 minecraft:black_concrete
fill 531 284 599 531 287 599 minecraft:black_concrete
fill 535 284 599 535 307 599 minecraft:black_concrete
setblock 545 284 599 minecraft:sea_lantern
setblock 552 284 557 minecraft:sea_lantern
fill 559 284 560 559 289 560 minecraft:black_concrete
setblock 559 284 563 minecraft:white_stained_glass
fill 559 284 564 559 307 564 minecraft:black_concrete
fill 559 284 572 559 300 572 minecraft:black_concrete
setblock 559 284 573 minecraft:white_concrete
setblock 559 284 579 minecraft:sea_lantern
setblock 517 285 580 minecraft:sea_lantern
fill 517 285 586 517 302 586 minecraft:black_concrete
fill 535 285 557 535 286 557 minecraft:black_concrete
setblock 536 285 557 minecraft:white_stained_glass
setblock 543 285 557 minecraft:white_concrete
fill 545 285 599 545 288 599 minecraft:black_concrete
setblock 548 285 599 minecraft:white_stained_glass
setblock 551 285 599 minecraft:white_stained_glass
fill 552 285 557 552 299 557 minecraft:black_concrete
fill 552 285 599 552 307 599 minecraft:black_concrete
fill 559 285 563 559 307 563 minecraft:black_concrete
fill 559 285 573 559 307 573 minecraft:black_concrete
fill 559 285 579 559 307 579 minecraft:black_concrete
fill 517 286 580 517 299 580 minecraft:black_concrete
fill 536 286 557 536 307 557 minecraft:black_concrete
setblock 536 286 599 minecraft:white_stained_glass
fill 543 286 557 543 307 557 minecraft:black_concrete
fill 548 286 599 548 307 599 minecraft:black_concrete
fill 551 286 599 551 307 599 minecraft:black_concrete
setblock 517 287 562 minecraft:white_concrete
setblock 517 287 563 minecraft:white_stained_glass
fill 517 287 565 517 290 565 minecraft:white_concrete
setblock 534 287 557 minecraft:sea_lantern
setblock 535 287 557 minecraft:white_stained_glass
fill 536 287 599 536 307 599 minecraft:black_concrete
setblock 547 287 557 minecraft:sea_lantern
fill 517 288 562 517 292 563 minecraft:black_concrete
setblock 517 288 569 minecraft:sea_lantern
fill 517 288 570 517 307 570 minecraft:black_concrete
fill 517 288 581 517 290 581 minecraft:white_concrete
fill 517 288 597 517 290 597 minecraft:white_concrete
fill 521 288 557 521 290 557 minecraft:white_concrete
fill 531 288 599 531 290 599 minecraft:white_concrete
fill 534 288 557 535 304 557 minecraft:black_concrete
fill 537 288 557 537 290 557 minecraft:white_concrete
fill 547 288 557 547 307 557 minecraft:black_concrete
fill 547 288 599 547 290 599 minecraft:white_concrete
setblock 551 288 557 minecraft:white_concrete
fill 553 288 557 553 290 557 minecraft:white_concrete
fill 559 288 567 559 290 567 minecraft:white_concrete
fill 559 288 583 559 290 583 minecraft:white_concrete
fill 517 289 569 517 307 569 minecraft:black_concrete
setblock 541 289 599 minecraft:white_concrete
setblock 545 289 599 minecraft:white_stained_glass
setblock 550 289 599 minecraft:white_concrete
fill 551 289 557 551 307 557 minecraft:black_concrete
setblock 520 290 560 minecraft:light[level=14]
setblock 520 290 568 minecraft:light[level=14]
setblock 520 290 576 minecraft:light[level=14]
setblock 520 290 584 minecraft:light[level=14]
setblock 520 290 592 minecraft:light[level=14]
fill 525 290 580 525 291 580 minecraft:obsidian
setblock 528 290 560 minecraft:light[level=14]
setblock 528 290 568 minecraft:light[level=14]
setblock 528 290 576 minecraft:light[level=14]
setblock 528 290 584 minecraft:light[level=14]
setblock 528 290 592 minecraft:light[level=14]
setblock 536 290 560 minecraft:light[level=14]
setblock 536 290 568 minecraft:light[level=14]
setblock 536 290 576 minecraft:light[level=14]
setblock 536 290 584 minecraft:light[level=14]
setblock 536 290 592 minecraft:light[level=14]
fill 541 290 599 541 299 599 minecraft:black_concrete
setblock 544 290 560 minecraft:light[level=14]
setblock 544 290 568 minecraft:light[level=14]
setblock 544 290 576 minecraft:light[level=14]
setblock 544 290 584 minecraft:light[level=14]
setblock 544 290 592 minecraft:light[level=14]
fill 545 290 599 545 307 599 minecraft:black_concrete
fill 550 290 599 550 305 599 minecraft:black_concrete
setblock 552 290 560 minecraft:light[level=14]
setblock 552 290 568 minecraft:light[level=14]
setblock 552 290 576 minecraft:light[level=14]
fill 552 290 581 555 297 583 minecraft:yellow_concrete
setblock 552 290 584 minecraft:light[level=14]
setblock 552 290 592 minecraft:light[level=14]
fill 553 290 580 555 297 580 minecraft:yellow_concrete
fill 553 290 584 554 297 584 minecraft:yellow_concrete
fill 556 290 581 556 297 582 minecraft:yellow_concrete
setblock 557 290 557 minecraft:white_stained_glass
setblock 559 290 560 minecraft:white_stained_glass
fill 517 291 565 517 296 565 minecraft:black_concrete
fill 517 291 581 517 296 581 minecraft:black_concrete
setblock 517 291 582 minecraft:white_stained_glass
setblock 517 291 588 minecraft:sea_lantern
fill 517 291 597 517 296 597 minecraft:black_concrete
fill 521 291 557 521 292 557 minecraft:black_concrete
setblock 527 291 599 minecraft:white_stained_glass
fill 531 291 599 531 296 599 minecraft:black_concrete
fill 537 291 557 537 296 557 minecraft:black_concrete
setblock 542 291 557 minecraft:white_concrete
fill 547 291 599 547 295 599 minecraft:black_concrete
fill 551 291 580 551 296 583 minecraft:yellow_concrete
fill 552 291 579 552 296 580 minecraft:yellow_concrete
fill 552 291 584 552 296 584 minecraft:yellow_concrete
fill 553 291 557 553 296 557 minecraft:black_concrete
fill 553 291 579 555 296 579 minecraft:yellow_concrete
fill 553 291 585 555 296 585 minecraft:yellow_concrete
fill 555 291 584 556 296 584 minecraft:yellow_concrete
fill 556 291 580 556 296 580 minecraft:yellow_concrete
fill 556 291 583 557 296 583 minecraft:yellow_concrete
fill 557 291 557 557 307 557 minecraft:black_concrete
fill 557 291 581 557 296 582 minecraft:yellow_concrete
fill 559 291 560 559 307 560 minecraft:black_concrete
fill 559 291 567 559 296 567 minecraft:black_concrete
fill 559 291 583 559 296 583 minecraft:black_concrete
setblock 517 292 574 minecraft:white_concrete
fill 517 292 582 517 307 582 minecraft:black_concrete
fill 517 292 588 517 300 588 minecraft:black_concrete
setblock 526 292 557 minecraft:sea_lantern
fill 527 292 599 527 307 599 minecraft:black_concrete
fill 532 292 599 532 307 599 minecraft:black_concrete
setblock 533 292 599 minecraft:sea_lantern
fill 542 292 557 542 307 557 minecraft:black_concrete
fill 550 292 581 550 295 582 minecraft:yellow_concrete
fill 551 292 584 551 295 584 minecraft:yellow_concrete
fill 552 292 585 552 295 585 minecraft:yellow_concrete
fill 553 292 578 554 295 578 minecraft:yellow_concrete
setblock 553 292 599 minecraft:white_concrete
fill 556 292 579 556 295 579 minecraft:yellow_concrete
fill 556 292 585 556 295 585 minecraft:yellow_concrete
fill 556 292 599 557 296 599 minecraft:black_concrete
fill 557 292 580 557 295 580 minecraft:yellow_concrete
fill 557 292 584 557 295 584 minecraft:yellow_concrete
setblock 558 292 599 minecraft:white_stained_glass
setblock 559 292 586 minecraft:white_stained_glass
fill 559 292 587 559 307 587 minecraft:black_concrete
fill 517 293 562 517 307 562 minecraft:black_concrete
setblock 517 293 563 minecraft:sea_lantern
fill 517 293 574 517 307 574 minecraft:black_concrete
setblock 517 293 593 minecraft:white_concrete
setblock 521 293 557 minecraft:white_concrete
fill 526 293 557 526 307 557 minecraft:black_concrete
fill 533 293 599 533 307 599 minecraft:black_concrete
fill 550 293 583 550 294 583 minecraft:yellow_concrete
fill 551 293 579 551 294 579 minecraft:yellow_concrete
fill 553 293 599 553 298 599 minecraft:black_concrete
fill 554 293 586 554 294 586 minecraft:yellow_concrete
fill 555 293 578 555 294 578 minecraft:yellow_concrete
fill 558 293 582 558 294 582 minecraft:yellow_concrete
setblock 558 293 599 minecraft:sea_lantern
fill 559 293 586 559 295 586 minecraft:black_concrete
fill 517 294 563 517 307 563 minecraft:black_concrete
setblock 517 294 571 minecraft:white_concrete
fill 517 294 572 517 307 572 minecraft:black_concrete
setblock 517 294 591 minecraft:white_concrete
fill 517 294 593 517 307 593 minecraft:black_concrete
fill 521 294 557 521 296 557 minecraft:black_concrete
setblock 558 294 599 minecraft:white_stained_glass
fill 517 295 571 517 307 571 minecraft:black_concrete
fill 517 295 591 517 296 591 minecraft:black_concrete
setblock 519 295 557 minecraft:sea_lantern
fill 533 295 586 533 296 586 minecraft:white_concrete
setblock 540 295 557 minecraft:white_concrete
fill 558 295 599 558 305 599 minecraft:black_concrete
setblock 559 295 588 minecraft:sea_lantern
fill 519 296 557 519 299 557 minecraft:black_concrete
fill 540 296 557 540 307 557 minecraft:black_concrete
setblock 547 296 599 minecraft:sea_lantern
setblock 559 296 586 minecraft:sea_lantern
fill 559 296 588 559 304 588 minecraft:black_concrete
fill 517 297 565 517 299 565 minecraft:white_concrete
fill 517 297 581 517 299 581 minecraft:white_concrete
setblock 517 297 591 minecraft:white_stained_glass
fill 517 297 597 517 299 597 minecraft:white_concrete
fill 521 297 557 521 299 557 minecraft:white_concrete
fill 531 297 599 531 299 599 minecraft:white_concrete
setblock 534 297 599 minecraft:white_concrete
fill 537 297 557 537 299 557 minecraft:white_concrete
fill 547 297 599 547 299 599 minecraft:white_concrete
fill 553 297 557 553 299 557 minecraft:white_concrete
setblock 556 297 599 minecraft:sea_lantern
fill 557 297 599 557 306 599 minecraft:black_concrete
fill 559 297 567 559 299 567 minecraft:white_concrete
fill 559 297 583 559 299 583 minecraft:white_concrete
fill 559 297 586 559 307 586 minecraft:black_concrete
setblock 559 297 591 minecraft:white_concrete
fill 517 298 591 517 307 591 minecraft:black_concrete
setblock 520 298 560 minecraft:light[level=14]
setblock 520 298 568 minecraft:light[level=14]
setblock 520 298 576 minecraft:light[level=14]
setblock 520 298 584 minecraft:light[level=14]
setblock 520 298 592 minecraft:light[level=14]
setblock 528 298 560 minecraft:light[level=14]
setblock 528 298 568 minecraft:light[level=14]
setblock 528 298 576 minecraft:light[level=14]
setblock 528 298 584 minecraft:light[level=14]
setblock 528 298 592 minecraft:light[level=14]
fill 534 298 599 534 307 599 minecraft:black_concrete
setblock 536 298 560 minecraft:light[level=14]
setblock 536 298 568 minecraft:light[level=14]
setblock 536 298 576 minecraft:light[level=14]
setblock 536 298 584 minecraft:light[level=14]
setblock 536 298 592 minecraft:light[level=14]
setblock 544 298 560 minecraft:light[level=14]
setblock 544 298 568 minecraft:light[level=14]
setblock 544 298 576 minecraft:light[level=14]
setblock 544 298 584 minecraft:light[level=14]
setblock 544 298 592 minecraft:light[level=14]
setblock 552 298 560 minecraft:light[level=14]
setblock 552 298 568 minecraft:light[level=14]
setblock 552 298 576 minecraft:light[level=14]
setblock 552 298 584 minecraft:light[level=14]
setblock 552 298 592 minecraft:light[level=14]
fill 556 298 599 556 307 599 minecraft:black_concrete
fill 559 298 574 559 306 577 minecraft:black_concrete
setblock 559 298 578 minecraft:white_stained_glass
fill 559 298 591 559 307 591 minecraft:black_concrete
setblock 517 299 564 minecraft:sea_lantern
setblock 518 299 599 minecraft:sea_lantern
setblock 553 299 599 minecraft:white_concrete
fill 559 299 578 559 307 578 minecraft:black_concrete
fill 517 300 564 517 307 565 minecraft:black_concrete
setblock 517 300 566 minecraft:white_concrete
setblock 517 300 580 minecraft:white_stained_glass
fill 517 300 581 517 307 581 minecraft:black_concrete
fill 517 300 597 517 303 597 minecraft:black_concrete
fill 518 300 599 518 307 599 minecraft:black_concrete
setblock 519 300 557 minecraft:sea_lantern
fill 521 300 557 521 307 557 minecraft:black_concrete
fill 531 300 599 531 307 599 minecraft:black_concrete
fill 537 300 557 537 307 557 minecraft:black_concrete
setblock 541 300 599 minecraft:sea_lantern
fill 547 300 599 547 307 599 minecraft:black_concrete
setblock 549 300 599 minecraft:white_concrete
setblock 552 300 557 minecraft:white_stained_glass
fill 553 300 557 553 303 557 minecraft:black_concrete
fill 553 300 599 553 307 599 minecraft:black_concrete
fill 559 300 567 559 307 567 minecraft:black_concrete
fill 559 300 583 559 307 583 minecraft:black_concrete
fill 517 301 566 517 307 566 minecraft:black_concrete
setblock 517 301 573 minecraft:sea_lantern
fill 517 301 580 517 307 580 minecraft:black_concrete
setblock 517 301 585 minecraft:white_concrete
setblock 517 301 588 minecraft:white_stained_glass
fill 519 301 557 519 302 557 minecraft:black_concrete
fill 541 301 599 541 307 599 minecraft:black_concrete
setblock 545 301 557 minecraft:white_concrete
fill 549 301 599 549 307 599 minecraft:black_concrete
fill 552 301 557 552 307 557 minecraft:black_concrete
setblock 559 301 558 minecraft:white_stained_glass
setblock 559 301 572 minecraft:white_stained_glass
fill 517 302 573 517 307 573 minecraft:black_concrete
fill 517 302 585 517 307 585 minecraft:black_concrete
fill 517 302 588 517 307 588 minecraft:black_concrete
setblock 541 302 557 minecraft:white_concrete
fill 545 302 557 545 307 557 minecraft:black_concrete
fill 559 302 558 559 307 558 minecraft:black_concrete
setblock 559 302 565 minecraft:white_stained_glass
fill 559 302 572 559 307 572 minecraft:black_concrete
setblock 517 303 586 minecraft:white_stained_glass
setblock 519 303 557 minecraft:white_concrete
setblock 531 303 557 minecraft:sea_lantern
fill 532 303 557 533 303 557 minecraft:black_concrete
fill 541 303 557 541 307 557 minecraft:black_concrete
setblock 543 303 599 minecraft:white_concrete
setblock 546 303 599 minecraft:white_concrete
fill 559 303 565 559 307 565 minecraft:black_concrete
setblock 559 303 581 minecraft:sea_lantern
fill 517 304 586 517 307 586 minecraft:black_concrete
setblock 517 304 597 minecraft:white_concrete
fill 519 304 557 519 307 557 minecraft:black_concrete
fill 531 304 557 531 307 557 minecraft:black_concrete
setblock 532 304 557 minecraft:white_concrete
fill 533 304 557 533 307 557 minecraft:black_concrete
fill 543 304 599 543 307 599 minecraft:black_concrete
fill 546 304 599 546 307 599 minecraft:black_concrete
setblock 549 304 557 minecraft:sea_lantern
setblock 553 304 557 minecraft:white_concrete
setblock 556 304 557 minecraft:white_stained_glass
fill 559 304 581 559 307 581 minecraft:black_concrete
setblock 559 304 590 minecraft:white_stained_glass
fill 517 305 597 517 307 597 minecraft:black_concrete
fill 532 305 557 532 307 557 minecraft:black_concrete
fill 534 305 557 534 307 557 minecraft:black_concrete
setblock 535 305 557 minecraft:white_concrete
fill 549 305 557 549 307 557 minecraft:black_concrete
fill 553 305 557 553 307 557 minecraft:black_concrete
fill 556 305 557 556 307 557 minecraft:black_concrete
setblock 559 305 588 minecraft:sea_lantern
fill 559 305 590 559 307 590 minecraft:black_concrete
fill 535 306 557 535 307 557 minecraft:black_concrete
setblock 550 306 599 minecraft:sea_lantern
fill 554 306 557 554 307 557 minecraft:black_concrete
setblock 555 306 557 minecraft:sea_lantern
setblock 558 306 599 minecraft:sea_lantern
fill 559 306 588 559 307 588 minecraft:black_concrete
setblock 517 307 575 minecraft:white_stained_glass
setblock 517 307 587 minecraft:white_stained_glass
setblock 518 307 557 minecraft:white_concrete
setblock 550 307 599 minecraft:black_concrete
setblock 555 307 557 minecraft:black_concrete
setblock 557 307 599 minecraft:white_stained_glass
setblock 558 307 599 minecraft:black_concrete
fill 559 307 574 559 307 575 minecraft:black_concrete
setblock 559 307 576 minecraft:white_concrete
setblock 559 307 577 minecraft:black_concrete
